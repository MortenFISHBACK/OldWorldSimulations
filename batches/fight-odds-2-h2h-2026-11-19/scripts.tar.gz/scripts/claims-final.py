"""Claimed v happened, first round, matched the way scripts/compare-batches.py does it:
the claim for the same side, turn, chargers AND target; won = the first combat result after contact.
python3 -I claims-by-band.py <root holding <arm>-N/<batch>/game-*.log.jsonl> [<repo>]
arm 'mine' = Mine is the exact-round (ON) side, 'opp' = Opponent is. Needs the repo's scripts/compare-batches.py."""
import sys, os, json, importlib.util, glob, collections
ROOT = sys.argv[1]
REPO = sys.argv[2] if len(sys.argv) > 2 else "/home/user/WarhammerOldWorldSimulator"
spec = importlib.util.spec_from_file_location("cb", os.path.join(REPO, "scripts/compare-batches.py"))
sys.path.insert(0, os.path.join(REPO, "scripts"))
cb = importlib.util.module_from_spec(spec); spec.loader.exec_module(cb)
R = collections.defaultdict(list)
dirs = sorted({os.path.dirname(f) for f in glob.glob(ROOT + "/**/game-*.log.jsonl", recursive=True)})
for d in dirs:
    arm = os.path.relpath(d, ROOT).split("/")[0].split("-")[0]
    on_side = "Mine" if arm == "mine" else "Opponent"
    recs = cb._records_by_game(d)
    for name in sorted(os.listdir(d)):
        if not name.endswith(".log.jsonl"): continue
        actions, calls = [], []
        for line in open(os.path.join(d, name), encoding="utf-8"):
            try: x = json.loads(line)
            except ValueError: continue
            if x.get("kind") == "action": actions.append(x)
            elif x.get("kind") == "call" and x.get("ok", True): calls.append(x)
        names = {a.get("actor") for a in actions} | {a.get("target") for a in actions}
        best = None
        for gid, u in recs.items():
            fit = len(names & set(u)) / max(1, len(u))
            if best is None or fit > best[0]: best = (fit, u)
        if not best or best[0] < 0.6: continue
        odds = {**cb._static_odds(actions), **cb._declared_odds(calls)}
        for f in cb._game_fights(actions, best[1]):
            o = cb._fight_odds(f, odds)
            if o is None or "first_round" not in f: continue
            b = "ON" if f["side"] == on_side else "OFF"
            R[b].append((o / 100, bool(f["first_round"]), len(f["chargers"]) > 1))
m = lambda v: sum(v) / len(v) if v else float("nan")
bands = [(0, .2), (.2, .4), (.4, .6), (.6, .8), (.8, 1.01)]
def table(sel, title):
    print(f"\n### {title}\n\n| Claimed win | ON fights | ON claimed v won | OFF fights | OFF claimed v won |\n|---|---|---|---|---|")
    for lo, hi in bands:
        row = [f"{lo:.0%}-{min(hi, 1):.0%}"]
        for b in ("ON", "OFF"):
            P = [p for p in R[b] if sel(p) and lo <= p[0] < hi]
            row += [str(len(P)), f"{m([p[0] for p in P]):.0%} v {m([p[1] for p in P]):.0%}" if P else "-"]
        print("| " + " | ".join(row) + " |")
    for b in ("ON", "OFF"):
        P = [p for p in R[b] if sel(p)]
        gap = sum(abs(m([p[0] for p in P if lo <= p[0] < hi]) - m([p[1] for p in P if lo <= p[0] < hi])) * len([p for p in P if lo <= p[0] < hi]) for lo, hi in bands if any(lo <= p[0] < hi for p in P)) / max(1, len(P))
        brier = m([(p[0] - p[1]) ** 2 for p in P])
        print(f"{b}: fights {len(P)}; claimed {m([p[0] for p in P]):.1%} v won {m([p[1] for p in P]):.1%}; band gap {gap:.1%}; Brier {brier:.3f}")
table(lambda p: True, "All charged fights")
table(lambda p: not p[2], "One charger")
table(lambda p: p[2], "Two or more chargers")

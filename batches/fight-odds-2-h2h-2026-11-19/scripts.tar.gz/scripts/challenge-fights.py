import json,glob,re,collections,sys
ROOT=sys.argv[1]
rows=[]
for f in sorted(glob.glob(ROOT+'/*/*/game-*.log.jsonl')):
    arm=f[len(ROOT)+1:].split('-')[0]; on='Mine' if arm=='mine' else 'Opponent'
    A=[]
    for l in open(f):
        try: x=json.loads(l)
        except: continue
        if x.get('kind')=='action': A.append(x)
    # rounds
    rounds=[]; cur=None
    for i,x in enumerate(A):
        s=x.get('summary') or ''
        if x['type']=='Computer' and s.startswith('Fights the combat:'):
            cur={'i':i,'turn':x['turn'],'side':x['side'],'title':s,'rows':[],'pre':[]}
            # preceding challenge rows
            j=i-1
            while j>=0 and A[j]['phase']=='Combat' and not (A[j]['type'] in('CombatResult',) ) and i-j<14:
                cur['pre'].append(A[j]); j-=1
            rounds.append(cur)
        elif cur is not None:
            cur['rows'].append(x)
            if x['type']=='CombatResult': cur['res']=s; cur=None
    # max sources per actor
    maxsrc=collections.Counter()
    for r in rounds:
        c=collections.Counter(x['actor'] for x in r['rows'] if x['type'] in('CombatAttack','StompAttacks'))
        for k,v in c.items(): maxsrc[k]=max(maxsrc[k],v)
    # claims
    claims={}
    for x in A:
        s=x.get('summary') or ''
        m=re.match(r'Objective for (.+?): charge #\d+ (.+?)(?: \(joins.*?\)\))?: .*win first round (\d+)%',s)
        if m: claims[(x['turn'],x['side'],m.group(1))]=(m.group(2),int(m.group(3)))
    charged={}
    for x in A:
        if x['type']=='Charge' and 'made contact' in (x.get('summary') or ''):
            charged[(x['turn'],x['side'],x['actor'])]=x['target']
    seen=set()
    for r in rounds:
        m=re.match(r'Fights the combat: (.+) against (.+)',r['title'])
        if not m: continue
        for (t,side,actor),tgt in charged.items():
            if t!=r['turn'] or side!=r['side'] or (t,side,actor) in seen: continue
            if actor not in r['title'] or tgt not in r['title']: continue
            seen.add((t,side,actor))
            cl=claims.get((t,side,actor))
            if not cl or 'res' not in r or cl[0]!=tgt: continue
            ours=m.group(1) if actor in m.group(1) else m.group(2)
            pure=ours.strip()==actor
            js=[x.get('summary') or '' for x in A if x['type']=='JobSplit' and x['turn']==t and x['side']==side and x.get('actor')==actor and '[TAKEN]' in (x.get('summary') or '')]
            sf=None
            for q in js:
                k=re.search(r'charge #\d+ [^|]*?\[TAKEN\][^|]*?slain or flees (\d+)%',q)
                if k: sf=int(k.group(1))
            mm=re.search(r'Mine (\d+) vs Opponent (\d+)',r['res'])
            if not mm: continue
            a,b=int(mm.group(1)),int(mm.group(2))
            if side=='Opponent': a,b=b,a
            chal=any(p['type']=='ChallengeAccepted' for p in r['pre'])
            acc=[p for p in r['pre'] if p['type']=='ChallengeAccepted']
            slain=any(x['type']=='ChampionSlain' or (x['type']=='CombatAttack' and 'destroyed' in x['summary'] and x['actor']==actor) for x in r['rows'])
            nsrc=sum(1 for x in r['rows'] if x['type'] in('CombatAttack','StompAttacks') and x['actor']==actor)
            lone=m.group(1).strip()==actor or m.group(2).strip()==actor
            fled=any(x['type'] in ('BreakTest','BreakTestMove') and x.get('actor')==actor and ('flee' in (x.get('summary') or '').lower()) for x in r['rows']+A[A.index(r['rows'][-1]) if r['rows'] else 0:][:40])
            rows.append(dict(fled=fled,f=f.split('/')[-1],arm='ON' if side==on else 'OFF',turn=t,actor=actor,tgt=tgt,claim=cl[1],won=a>b,a=a,b=b,chal=chal,slain=slain,nsrc=nsrc,maxsrc=maxsrc[actor],lone=lone,pure=pure,sf=sf))
json.dump(rows,open(sys.argv[2],'w'))

P=[r for r in rows if r['pure']]
print(len(rows),len(P))
def t(sel,n):
    for arm in ('ON','OFF','both'):
        Q=[r for r in P if sel(r) and (arm=='both' or r['arm']==arm)]
        if Q: print(f"{n:46s} {arm:4s} {len(Q):4d} fights claimed {sum(r['claim'] for r in Q)/len(Q):5.1f}% won {100*sum(r['won'] for r in Q)/len(Q):5.1f}% Brier {sum((r['claim']/100-r['won'])**2 for r in Q)/len(Q):.3f} fled {sum(r['fled'] for r in Q)}")
lo=lambda r:r['claim']<20
hi=lambda r:r['claim']>=80
cut=lambda r:r['chal'] and r['slain'] and r['maxsrc']>=2 and r['nsrc']<r['maxsrc']
t(lambda r:True,'all'); t(hi,'80+'); t(lambda r:hi(r) and r['chal'],'80+ challenge'); t(lambda r:hi(r) and cut(r),'80+ challenge cut short'); t(lambda r:hi(r) and r['chal'] and not cut(r),'80+ challenge other'); t(lambda r:hi(r) and not r['chal'],'80+ no challenge')
t(lo,'<20'); t(lambda r:lo(r) and r['chal'],'<20 challenge'); t(lambda r:lo(r) and not r['chal'],'<20 no challenge')
t(lambda r:lo(r) and (r['sf'] or 0)>=40,'<20 with slain-or-flees 40+')
t(lambda r:r['chal'],'challenge fought (all bands)')
t(lambda r:r['lone'],'lone charger (all bands)'); t(lambda r:r['lone'] and lo(r),'lone charger <20'); t(lambda r:r['lone'] and hi(r),'lone charger 80+')
for r in P:
    if lo(r): print(f"  {r['arm']:3s} {r['f'][5:14]} T{r['turn']} {r['actor'][:30]:30s} -> {r['tgt'][:28]:28s} claim {r['claim']:3d} sf {r['sf']} res {r['a']}v{r['b']} fled={r['fled']} chal={r['chal']} src {r['nsrc']}/{r['maxsrc']}")

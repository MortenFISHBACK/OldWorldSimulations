#!/bin/bash
set -uo pipefail
D=/mnt/project-files/fight-odds-2-h2h-2026-11-19
SHA=dde35ebbab2bf607fa7c36dd04e8385e2f8d6715
REPO=/home/user/WarhammerOldWorldSimulator
/usr/local/share/dotnet/dotnet --list-sdks | grep -q "^10\." || { curl -sSL https://dot.net/v1/dotnet-install.sh -o /tmp/di.sh && bash /tmp/di.sh --version 10.0.100 --install-dir /usr/local/share/dotnet; }
export DOTNET_ROOT=/usr/local/share/dotnet PATH=/usr/local/share/dotnet:$PATH
git -C "$REPO" checkout -q -B fo2 "$SHA" || exit 3
B=fo2-smoke-dde35eb; W="$HOME/owwt-sim/$B"; mkdir -p "$W"
if [ ! -d "$W/data/.git" ]; then
  git clone -q --filter=blob:none --no-checkout --depth 1 --branch simulation-data "$(git -C "$REPO" remote get-url origin)" "$W/data" || exit 5
  git -C "$W/data" sparse-checkout set --no-cone '/README.md' '/batches/*/lessons.jsonl' '/batches/*/units.jsonl' "/measurements/$B/"
  git -C "$W/data" checkout -q simulation-data
fi
cd "$REPO" && scripts/simulate-local.sh --opponent static-static --pairs L0102,L0717 --seeds 1 --scenarios mix \
  --rules-off "$(cat $D/off-for-opponent.txt)" --keep-as measurement --batch "$B" --look-for "$D/look-for.md"
echo SMOKE END

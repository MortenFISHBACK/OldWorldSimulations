# Doctrine scorecard: jc-mine-1e5408d-p1

### Scorecard: jc-mine-1e5408d-p1

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0102 | 6 | 1 | Mine | no | 12 | 3 | 1 | 1 | 0 | 0 | 0 | 77 |
| L0102 | 6 | 1 | Opponent | no | 6 | 1 | 5 | 4 | 0 | 0 | 0 | 170 |
| L0118 | 4 | 1 | Mine | no | 5 | 5 | 1 | 1 | 1 | 0 | 0 | 0 |
| L0118 | 4 | 1 | Opponent | no | 0 | 3 | 4 | 3 | 1 | 0 | 0 | 516 |
| L0135 | 3 | 1 | Mine | no | 3 | 4 | 2 | 2 | 0 | 0 | 0 | 442 |
| L0135 | 3 | 1 | Opponent | no | 0 | 2 | 2 | 3 | 0 | 0 | 0 | 0 |
| L0218 | 2 | 1 | Mine | - | - | 2 | 2 | 2 | 0 | 0 | 0 | 0 |
| L0218 | 2 | 1 | Opponent | - | - | - | 1 | 2 | 1 | 0 | 0 | 0 |
| L0235 | 1 | 1 | Mine | no | 1 | 2 | 2 | 4 | 0 | 0 | 0 | 0 |
| L0235 | 1 | 1 | Opponent | no | 0 | 4 | 1 | 3 | 0 | 0 | 0 | 250 |
| L0319 | 1 | 1 | Mine | no | 7 | 3 | 2 | 0 | 1 | 0 | 0 | 675 |
| L0319 | 1 | 1 | Opponent | no | 0 | 2 | 3 | 1 | 0 | 0 | 0 | 255 |
| L0405 | 3 | 1 | Mine | yes | 8 | 2 | 1 | 1 | 0 | 0 | 0 | 0 |
| L0405 | 3 | 1 | Opponent | no | 0 | - | 2 | 1 | 0 | 0 | 0 | 1193 |
| L0421 | 1 | 1 | Mine | no | 0 | 2 | 4 | 0 | 0 | 0 | 0 | 0 |
| L0421 | 1 | 1 | Opponent | no | 0 | 5 | 1 | 3 | 1 | 0 | 0 | 420 |
| L0508 | 4 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 548 |
| L0508 | 4 | 1 | Opponent | no | 0 | 2 | 3 | 1 | 0 | 0 | 0 | 769 |
| L0524 | 2 | 1 | Mine | - | - | 2 | 1 | 1 | 0 | 0 | 0 | 548 |
| L0524 | 2 | 1 | Opponent | - | - | 3 | 2 | 3 | 0 | 0 | 0 | 0 |
| L0612 | 6 | 1 | Mine | no | 0 | - | 1 | 2 | 0 | 0 | 0 | 743 |
| L0612 | 6 | 1 | Opponent | no | 4 | 3 | 1 | 0 | 0 | 0 | 0 | 330 |
| L0628 | 4 | 1 | Mine | no | 0 | 4 | 2 | 2 | 0 | 0 | 0 | 981 |
| L0628 | 4 | 1 | Opponent | no | 1 | 3 | 2 | 0 | 0 | 0 | 0 | 238 |
| L0717 | 3 | 1 | Mine | yes | 0 | 2 | 3 | 1 | 0 | 0 | 0 | 420 |
| L0717 | 3 | 1 | Opponent | yes | 4 | 2 | 6 | 1 | 1 | 0 | 0 | 175 |
| L0733 | 1 | 1 | Mine | no | 1 | 1 | 0 | 2 | 2 | 0 | 0 | 375 |
| L0733 | 1 | 1 | Opponent | no | 6 | 4 | 1 | 3 | 0 | 0 | 0 | 144 |
| L0823 | 1 | 1 | Mine | no | 0 | 2 | 1 | 1 | 0 | 0 | 0 | 515 |
| L0823 | 1 | 1 | Opponent | no | 0 | 2 | 2 | 2 | 2 | 0 | 0 | 130 |
| L0913 | 1 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 524 |
| L0913 | 1 | 1 | Opponent | no | 2 | 2 | 5 | 1 | 0 | 0 | 0 | 140 |
| L0930 | 6 | 1 | Mine | no | 2 | 6 | 1 | 1 | 0 | 0 | 0 | 733 |
| L0930 | 6 | 1 | Opponent | no | 2 | 2 | 5 | 0 | 1 | 0 | 0 | 0 |
| L1021 | 1 | 1 | Mine | no | 1 | 2 | 8 | 0 | 1 | 0 | 0 | 330 |
| L1021 | 1 | 1 | Opponent | no | 0 | - | 0 | 4 | 0 | 0 | 0 | 355 |
| L1114 | 4 | 1 | Mine | no | 7 | 2 | 1 | 1 | 1 | 0 | 0 | 330 |
| L1114 | 4 | 1 | Opponent | no | 3 | 2 | 2 | 1 | 1 | 0 | 0 | 500 |
| L1131 | 3 | 1 | Mine | no | 3 | - | 4 | 0 | 1 | 0 | 0 | 676 |
| L1131 | 3 | 1 | Opponent | no | 0 | 5 | 1 | 1 | 3 | 0 | 0 | 170 |
| L1224 | 6 | 1 | Mine | no | 4 | 2 | 4 | 1 | 0 | 0 | 0 | 330 |
| L1224 | 6 | 1 | Opponent | no | 2 | 2 | 2 | 2 | 0 | 0 | 0 | 0 |
| L1319 | 5 | 1 | Mine | yes | - | 3 | 2 | 1 | 0 | 0 | 0 | 302 |
| L1319 | 5 | 1 | Opponent | yes | - | 2 | 2 | 0 | 0 | 0 | 0 | 0 |
| L1335 | 3 | 1 | Mine | no | 6 | 2 | 3 | 0 | 0 | 0 | 0 | 140 |
| L1335 | 3 | 1 | Opponent | no | 0 | 2 | 4 | 2 | 0 | 0 | 0 | 126 |
| L1431 | 3 | 1 | Mine | no | 6 | 2 | 8 | 1 | 0 | 0 | 0 | 0 |
| L1431 | 3 | 1 | Opponent | no | 1 | 3 | 2 | 0 | 1 | 0 | 0 | 340 |
| L1527 | 3 | 1 | Mine | yes | 8 | 2 | 0 | 1 | 1 | 0 | 0 | 0 |
| L1527 | 3 | 1 | Opponent | no | 0 | 3 | 7 | 2 | 0 | 0 | 0 | 0 |
| L1625 | 5 | 1 | Mine | yes | - | 3 | 2 | 2 | 0 | 0 | 0 | 200 |
| L1625 | 5 | 1 | Opponent | no | - | 4 | 0 | 2 | 0 | 0 | 0 | 0 |
| L1723 | 1 | 1 | Mine | no | 1 | 3 | 5 | 0 | 1 | 0 | 0 | 207 |
| L1723 | 1 | 1 | Opponent | yes | 9 | 2 | 5 | 0 | 0 | 0 | 0 | 0 |
| L1823 | 5 | 1 | Mine | yes | - | - | 4 | 1 | 2 | 0 | 0 | 234 |
| L1823 | 5 | 1 | Opponent | yes | - | 1 | 3 | 1 | 2 | 0 | 0 | 72 |
| L1923 | 3 | 1 | Mine | no | 2 | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L1923 | 3 | 1 | Opponent | no | 0 | 2 | 1 | 1 | 1 | 0 | 0 | 66 |
| L2025 | 3 | 1 | Mine | yes | 4 | - | 1 | 2 | 2 | 0 | 0 | 860 |
| L2025 | 3 | 1 | Opponent | no | 9 | 2 | 6 | 2 | 0 | 0 | 0 | 211 |
| L2127 | 3 | 1 | Mine | no | 4 | - | 0 | 4 | 0 | 0 | 0 | 355 |
| L2127 | 3 | 1 | Opponent | no | 7 | 2 | 9 | 3 | 0 | 0 | 0 | 0 |
| L2231 | 5 | 1 | Mine | yes | - | 1 | 6 | 2 | 0 | 0 | 0 | 0 |
| L2231 | 5 | 1 | Opponent | yes | - | - | 0 | 1 | 3 | 0 | 0 | 848 |
| L2335 | 1 | 1 | Mine | no | 0 | 2 | 2 | 1 | 0 | 0 | 0 | 245 |
| L2335 | 1 | 1 | Opponent | no | 0 | 2 | 3 | 1 | 1 | 0 | 0 | 0 |
| L2531 | 5 | 1 | Mine | yes | - | 4 | 2 | 3 | 0 | 0 | 0 | 0 |
| L2531 | 5 | 1 | Opponent | no | - | - | 0 | 4 | 0 | 0 | 0 | 0 |
| L2730 | 6 | 1 | Mine | no | 1 | 2 | 5 | 3 | 0 | 0 | 0 | 0 |
| L2730 | 6 | 1 | Opponent | no | 0 | 2 | 1 | 1 | 0 | 0 | 0 | 0 |
| L2934 | 6 | 1 | Mine | no | 4 | 4 | 2 | 1 | 1 | 0 | 0 | 0 |
| L2934 | 6 | 1 | Opponent | no | 0 | 1 | 4 | 0 | 1 | 0 | 0 | 0 |
| **Average** | | | Mine | 26% | 3.1 | 2.6 | 2.4 | 1.3 | 0.4 | 0.0 | 0.0 | 299.7 |
| **Average** | | | Opponent | 15% | 1.9 | 2.5 | 2.7 | 1.6 | 0.6 | 0.0 | 0.0 | 206.1 |

### KPIs: jc-mine-1e5408d-p1

Rules off - Opponent only: SECOND CHARGER ADDS.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 27% (48 of 176) | 3% (5 of 172) | 15% (53 of 348) |
| Winner chose to follow up after the loser gave ground |  | 98% (53 of 54); on the table 98% | 95% (52 of 55); on the table 98% | 96% (105 of 109); on the table 98% |
| Winner chose to pursue after the loser fell back in good order |  | 83% (10 of 12); on the table 83% | 86% (19 of 22); on the table 91% | 85% (29 of 34); on the table 88% |
| Winner chose to pursue after the loser fled |  | 72% (18 of 25); on the table 72% | 82% (33 of 40); on the table 82% | 78% (51 of 65); on the table 78% |
| Winner chose to follow up or pursue (all three) |  | 89% (81 of 91); on the table 89% | 89% (104 of 117); on the table 91% | 89% (185 of 208); on the table 90% |
| Magic missiles tried each own turn | 50%+ | 28% (93 of 330) | 31% (66 of 210) | 29% (159 of 540) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 40% (93 of 234) | 42% (66 of 158) | 41% (159 of 392) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 68% (21 of 31) | 44% (23 of 52) | 53% (44 of 83) |
| Points that never fought | lower | 40% (28624 of 71484) | 39% (27931 of 71889) | 39% (56555 of 143373) |
|   infantry points that never fought | lower | 47% (7866 of 16863) | 67% (9003 of 13348) | 56% (16869 of 30211) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 55% (154 of 279) | 61% (181 of 295) | 58% (335 of 574) |
| Bound items with a magic missile used (at least once a game) |  | 86% (19 of 22); 1.7 uses a game | 70% (14 of 20); 1.2 uses a game | 79% (33 of 42); 1.4 uses a game |
| Bound items with another spell used |  | 69% (11 of 16); 0.7 uses a game | 38% (3 of 8); 0.2 uses a game | 58% (14 of 24); 0.4 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 53% (10 of 19); 0.3 uses a game | 67% (8 of 12); 0.2 uses a game | 58% (18 of 31); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 51% (30665 of 59666) | 57% (35856 of 62699) | 54% (66521 of 122365) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 2.4 (37%) | 1.4 (35%) | 3.9 (36%) |
| MARCHED: its unit marched | 0.7 (10%) | 0.6 (16%) | 1.3 (12%) |
| CHARGED: its unit charged | 0.6 (8%) | 0.1 (3%) | 0.7 (6%) |
| IN COMBAT: engaged in combat | 1.3 (20%) | 0.3 (8%) | 1.7 (16%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.4 (9%) | 0.4 (3%) |
| FLEEING: fleeing | 0.1 (1%) | 0.0 (1%) | 0.1 (1%) |
| GONE: slain | 1.1 (17%) | 0.9 (23%) | 2.0 (19%) |
| OFF THE TABLE: off the table or not arrived | 0.2 (3%) | 0.2 (4%) | 0.3 (3%) |
| STUPIDITY: Stupidity | 0.2 (3%) | 0.0 (1%) | 0.2 (2%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.3 | 1.3 | 1.4 | 4.4 | 0.5 | 1.8 |
| not cast | 3.7 | 3.0 | 3.3 | 10.6 | 1.8 | 22.2 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.1 (2%) | 0.0 (0%) | 0.0 (0%) | 1.1 (5%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.3 (44%) | 0.4 (12%) | 3.9 (36%) | 0.4 (25%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.3 (12%) | 0.1 (6%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (6%) | 0.1 (8%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.2 (6%) | 0.3 (10%) | 0.2 (8%) | 1.7 (16%) | 0.2 (11%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.2 (6%) | 0.3 (8%) | 0.4 (3%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.1 (2%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.2 (1%) |
| GONE: slain | 0.7 (20%) | 0.8 (26%) | 0.8 (25%) | 2.0 (19%) | 0.1 (5%) | 3.5 (16%) |
| OFF THE TABLE: off the table or not arrived | 0.2 (7%) | 0.2 (6%) | 0.3 (10%) | 0.3 (3%) | 0.0 (0%) | 1.0 (5%) |
| STUPIDITY: Stupidity | 0.1 (2%) | 0.0 (1%) | 0.1 (3%) | 0.2 (2%) | 0.0 (0%) | 0.3 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (2%) | 0.1 (2%) | 0.0 (0%) | 0.0 (0%) | 0.8 (46%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.3 (63%) | 0.2 (6%) | 1.1 (33%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 16.0 (72%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.1 a game | 0.4 a game | 0.8 a game |
| stood (cast and not dispelled) | 65% (22 of 34) | 75% (12 of 16) | 68% (34 of 50) |
| the unit moved after it | 50% (11 of 22) | 75% (9 of 12) | 59% (20 of 34) |
| it charged on its next turn | 0% (0 of 22) | 0% (0 of 12) | 0% (0 of 34) |
| the enemy charged it first | 18% (4 of 22) | 0% (0 of 12) | 12% (4 of 34) |
| it fought by the end of its next turn | 14% (3 of 22) | 0% (0 of 12) | 9% (3 of 34) |
| it moved out of a charge the enemy had planned (not charged first) | 9% (2 of 22) | 0% (0 of 12) | 6% (2 of 34) |
| none of these (no charge, no fight, no charge escaped) | 73% (16 of 22) | 100% (12 of 12) | 82% (28 of 34) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 61% (559 of 910) | 59% (353 of 600) | 60% (912 of 1510) |
|   cavalry | 57% (44 of 77) | 69% (88 of 127) | 65% (132 of 204) |
|   character | 52% (67 of 130) | 29% (31 of 106) | 42% (98 of 236) |
|   chariot | 46% (42 of 92) | 65% (26 of 40) | 52% (68 of 132) |
|   infantry | 53% (162 of 304) | 58% (138 of 239) | 55% (300 of 543) |
|   monster | 55% (22 of 40) | 41% (9 of 22) | 50% (31 of 62) |
|   war machine | 83% (222 of 267) | 92% (61 of 66) | 85% (283 of 333) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.6 (26%) | 1.5 (21%) | 4.1 (24%) |
| CHARGED: it charged | 1.2 (12%) | 1.3 (19%) | 2.5 (15%) |
| FLEEING: it fled or was fleeing | 0.2 (2%) | 0.1 (1%) | 0.2 (2%) |
| IN COMBAT: it fought this turn or the last | 0.8 (8%) | 0.5 (8%) | 1.3 (8%) |
| MOVED: a war machine that moved | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| HELD FIRE: a target, but it held its fire | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NO TARGET IN RANGE | 1.7 (18%) | 1.8 (26%) | 3.5 (21%) |
| ONLY IN COMBAT: the only targets were in combat | 0.9 (10%) | 0.7 (10%) | 1.6 (10%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.7 (17%) | 0.9 (13%) | 2.6 (16%) |
| SHELTERED: the target was sheltered | 0.1 (1%) | 0.1 (1%) | 0.2 (1%) |
| OTHER BAR | 0.5 (5%) | 0.1 (1%) | 0.6 (3%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 5.3 | 1.2 | 80% | 4.8 pts | 26 pts |
| character | 3.2 | 1.1 | 74% | 6.7 pts | 21 pts |
| chariot | 1.9 | 1.2 | 67% | 14.0 pts | 27 pts |
| infantry | 12.4 | 4.1 | 75% | 8.2 pts | 102 pts |
| monster | 1.1 | 0.3 | 88% | 3.2 pts | 4 pts |
| war machine | 7.9 | 5.4 | 68% | 24.7 pts | 194 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.2 | 5.2 | 4.7 |
| Charges that made contact a game | 3.1 | 3.3 | 3.2 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.14 declared, 0.73 contact (22 units) | 0.36 declared, 0.21 contact (14 units) | 0.83 declared, 0.53 contact (36 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.67 declared, 0.33 contact (6 units) | 1.33 declared, 0.89 contact (9 units) | 1.07 declared, 0.67 contact (15 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.49 declared, 0.39 contact (245 units) | 0.61 declared, 0.39 contact (276 units) | 0.56 declared, 0.39 contact (521 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 56% (39 of 70) | 52% (11 of 21) | 38% (3 of 8) | 54% (53 of 99) |
| Character in a unit | 77% (27 of 35) | 59% (13 of 22) | 75% (3 of 4) | 70% (43 of 61) |
| Character on its own | 83% (43 of 52) | 53% (20 of 38) | 35% (22 of 62) | 56% (85 of 152) |
| Chariot | 44% (7 of 16) | 60% (6 of 10) | - | 50% (13 of 26) |
| Infantry | 60% (53 of 89) | 42% (15 of 36) | 50% (1 of 2) | 54% (69 of 127) |
| Monster | 56% (18 of 32) | 80% (8 of 10) | - | 62% (26 of 42) |
| Monstrous | 45% (5 of 11) | 79% (11 of 14) | - | 64% (16 of 25) |
| War Machines | 71% (29 of 41) | 100% (1 of 1) | - | 71% (30 of 42) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 6 | 81% (13 of 16); on the table 88% | 19% (26 of 138) | 39% | 52% (17 of 33) | 89% (8 of 9); 3.3 uses a game | 100% (3 of 3); 1.2 uses a game | 89% (8 of 9); 1.3 uses a game |
| Chaos Dwarfs | 3 | 100% (7 of 7); on the table 100% | 42% (10 of 24) | 31% | 33% (8 of 24) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Dwarfen Mountain Holds | 5 | 89% (8 of 9); on the table 89% | - | 49% | 73% (30 of 41) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 6 | 80% (8 of 10); on the table 80% | 44% (16 of 36) | 56% | 59% (38 of 64) | 0.0 uses a game | 100% (2 of 2); 1.3 uses a game | 25% (1 of 4); 0.2 uses a game |
| Grand Cathay | 5 | 89% (16 of 18); on the table 89% | 31% (34 of 108) | 43% | 43% (19 of 44) | 92% (11 of 12); 7.8 uses a game | 100% (1 of 1); 0.4 uses a game | 60% (3 of 5); 0.6 uses a game |
| High Elf Realms | 6 | 88% (15 of 17); on the table 88% | 17% (5 of 30) | 44% | 55% (27 of 49) | 100% (5 of 5); 3.2 uses a game | 44% (8 of 18); 2.2 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | 100% (3 of 3); on the table 100% | - | 43% | 33% (2 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Lizardmen | 2 | 100% (5 of 5); on the table 100% | - | 22% | 64% (9 of 14) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 3 | 83% (10 of 12); on the table 83% | 8% (1 of 12) | 55% | 76% (16 of 21) | 0% (0 of 3); 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 3 | 33% (1 of 3); on the table 100% | 6% (2 of 36) | 12% | 75% (18 of 24) | 0.0 uses a game | 0.0 uses a game | 67% (2 of 3); 0.7 uses a game |
| Skaven | 4 | 75% (9 of 12); on the table 75% | 50% (15 of 30) | 29% | 59% (20 of 34) | 100% (3 of 3); 1.0 uses a game | 0.0 uses a game | 50% (2 of 4); 0.5 uses a game |
| Tomb Kings of Khemri | 6 | 90% (19 of 21); on the table 90% | 17% (2 of 12) | 33% | 47% (14 of 30) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 8 | 93% (27 of 29); on the table 93% | 48% (26 of 54) | 36% | 60% (30 of 50) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 8 | 92% (24 of 26); on the table 92% | 40% (12 of 30) | 36% | 68% (50 of 74) | 100% (4 of 4); 1.5 uses a game | 0.0 uses a game | 50% (1 of 2); 0.1 uses a game |
| Wood Elf Realms | 6 | 100% (20 of 20); on the table 100% | 33% (10 of 30) | 46% | 56% (37 of 66) | 33% (2 of 6); 1.7 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (jc-mine-1e5408d-p1, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 39% (25) | 47% (35) | 43% (60) |
| ...free all their last turn and able to turn (per game) | 0.42 | 0.67 | 1.08 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.11 | 0.14 | 0.25 |
| ...with the charger already in that arc before they moved (per game) | 0.36 | 0.47 | 0.83 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 1.75 | 0.94 | 2.69 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.89 | 0.78 | 1.67 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 4.89 | 4.78 | 9.67 |

### Quality by phase: jc-mine-1e5408d-p1

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.1 | 3.4 |
| Strategy | Charge objectives carried out (made contact) | 48% (63 of 131) | 38% (59 of 155) |
| Strategy | Shoot objectives carried out (shot that target) | 41% (178 of 437) | 59% (133 of 225) |
| Strategy | Close-in objectives charged next turn | 10% (15 of 157) | 16% (39 of 240) |
| Strategy | Support requests answered (helper made contact too) | 38% (14 of 37) | 39% (9 of 23) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (1 of 1) | 100% (2 of 2) |
| Strategy | Hexes on a unit its side charged or shot that turn | 62% (8 of 13) | 62% (5 of 8) |
| Strategy | Joined characters whose unit fought | 34% (20 of 58) | 35% (13 of 37) |
| Strategy | Lone characters that fought | 74% (65 of 88) | 75% (74 of 99) |
| Movement | Charges halted short of contact | 0.3 | 0.1 |
| Movement | Idle units | 1.3 | 1.6 |
| Movement | Points that never moved of their own | 299.7 | 206.1 |
| Movement | Fights charged into per game | 2.7 | 2.9 |
| Movement | Charges with odds: long shots (under 50%) | 16 of 84, net +81 | 12 of 86, net +153 |
| Movement | Charges with odds: sweet spot (55-75%) | 7 of 84, net +85 | 20 of 86, net +80 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 15 of 84, net +80 | 0 of 86 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 27 of 84, net +123 | 24 of 86, net +161 |
| Shooting | Shots by shooting units (incl. breath weapons) | 10.3 | 9.1 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 44% (162 of 370) | 36% (117 of 326) |
| Shooting | Points destroyed by shooting units | 69.6 | 27.2 |
| Shooting | War machine shots | 6.2 | 1.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 48% (107 of 222) | 34% (21 of 61) |
| Shooting | Points destroyed by war machines | 113.1 | 18.8 |
| Magic | Magic missiles cast | 1.6 | 1.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 33% (19 of 58) | 33% (15 of 46) |
| Magic | Wounds caused by magic missiles | 4.6 | 1.2 |
| Magic | Wounds caused by other spells | 1.5 | 0.3 |
| Magic | Points destroyed by magic (all spells) | 72.4 | 17.5 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.5 / 0.4 / 0.9 / 0.3 | 1.5 / 0.3 / 0.2 / 0.1 |
| Combat | Points destroyed in combat | 369.1 | 335.4 |
| Combat | Points run down | 42.2 | 185.9 |
| Combat | Net points per charged fight, damage counted | +82 | +94 |
| Combat | Net per 100 charger points, damage counted | +27.2 | +35.1 |
| Combat | First round won (charged fights) | 75% | 74% |
| Combat | Net points per charged fight | +89 | +104 |
| Combat | Net points per supported fight / lone fight | +114 / +84 | +194 / +93 |
| Combat | Charged fights on a top-3 enemy unit | 38 of 98 | 49 of 105 |
| Game | Points lost | 710.8 | 774.1 |
| Game | VP from objectives | 675.6 | 592.2 |
| Game | Lone holders (player turns) | 3.1 | 1.9 |

- Mine won / drew / lost: 17 / 6 / 13 of 36 ended games (of 36); mean margin (Mine - Opponent) +130 VP
- The side that went first won 11 of 30 games with a winner
- Points traded per game (both sides' losses): 1485
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: jc-mine-1e5408d-p1

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.6 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| ADVANCE WORTH | 5.4 | -152.1 | 233.0 | 118.5 | 4.7 | -136.1 | 116.2 | 71.6 |
| ALREADY CARRIED | 0.0 | +0.0 | 0.0 | 3.6 | - | - | - | - |
| ARRIVAL HUNT | - | - | - | - | 0.0 | +0.2 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.0 | +0.0 | 0.0 | 17.4 | 0.2 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | 0.3 | +0.9 | 0.0 | 4.6 | 0.7 | +3.4 | 0.0 | 22.5 |
| BEST FACING | 0.4 | +8.1 | 0.0 | 26.3 | 0.2 | +6.9 | 0.0 | 13.7 |
| BEST FIRST | 1.2 | +51.3 | 49.9 | 16.3 | 0.9 | +38.2 | 15.2 | 28.9 |
| BEST OVERALL | 0.3 | +17.8 | 0.0 | 20.6 | 0.2 | +7.6 | 0.0 | 0.0 |
| BEST PREY | 0.5 | +18.0 | 12.5 | 4.2 | 0.6 | +29.9 | 5.6 | 15.4 |
| BEST PRIZE | 0.1 | -3.0 | 4.7 | 0.0 | 0.1 | -3.8 | 2.9 | 0.0 |
| BIG CHARACTER SAFETY | 0.1 | -1.2 | 0.0 | 15.0 | 0.2 | -0.8 | 0.0 | 0.0 |
| BLOCKED CHARGE SKIPPED | 0.1 | +0.0 | 4.1 | 0.0 | 0.1 | +0.0 | 2.6 | 1.4 |
| BLOCKED WHEEL | 0.3 | +11.6 | 0.0 | 3.5 | 0.2 | +7.7 | 0.0 | 13.3 |
| BLOWS WHERE AIMED | 0.3 | -64.0 | 50.9 | 6.5 | 0.2 | -11.0 | 37.2 | 21.0 |
| BOMBING RUN | 0.0 | +0.3 | 0.0 | 0.0 | - | - | - | - |
| BOUND ASSAILMENT | 0.0 | +0.0 | 0.0 | 4.2 | - | - | - | - |
| CANNON PLAN MISSED | 0.8 | +0.0 | 103.0 | 9.2 | 0.1 | +0.0 | 10.9 | 3.6 |
| CANNON PLANNED TARGET | 4.9 | +185.6 | 480.1 | 98.2 | 1.5 | +26.5 | 51.3 | 14.0 |
| CANNON SIGHT KEPT | 1.0 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT SET-UP | 0.1 | +0.0 | 9.5 | 0.0 | 0.2 | +0.0 | 3.3 | 3.5 |
| CAST JOB | 1.2 | +61.2 | 86.7 | 38.5 | 0.8 | +16.8 | 30.0 | 0.0 |
| CASTER AWAY FROM SCREEN | 0.4 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.4 | +32.1 | 34.6 | 10.9 | 0.2 | +10.7 | 9.3 | 13.9 |
| CASTS AFTER FRIENDS | 0.6 | +0.0 | 0.0 | 43.2 | 0.3 | +0.0 | 0.0 | 18.7 |
| CASTS FROM BEHIND | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.1 | +1.0 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | 1.1 | +57.1 | 0.0 | 23.8 | 1.8 | +96.3 | 0.0 | 36.1 |
| CHAFF PASSED | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | -0.1 | 0.0 | 8.6 |
| CHARGE NOW FIRST | 2.4 | +0.0 | 221.9 | 40.2 | 2.3 | +0.0 | 228.5 | 118.0 |
| CHARGE NOW WEIGHED | 0.5 | -27.7 | 62.7 | 11.7 | 0.5 | -36.5 | 1.8 | 24.3 |
| CHARGER SLAIN LOST | 0.3 | -20.4 | 4.9 | 5.4 | 0.8 | -18.6 | 99.4 | 43.3 |
| CHARIOT NO STATIC JOB | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHARIOT WIZARD CAREFUL | 0.0 | -2.9 | 9.5 | 0.0 | 0.1 | -2.2 | 0.0 | 0.0 |
| CHEAP HELPER | - | - | - | - | 0.2 | +0.0 | 7.2 | 0.0 |
| COMBAT PIVOT | 0.5 | +0.0 | 90.1 | 17.1 | 0.4 | +0.0 | 16.0 | 12.6 |
| CONTINUE AHEAD WEIGHED | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CONVEYANCE SEARCH | 0.5 | +44.7 | 0.0 | 24.7 | 0.3 | +104.8 | 3.2 | 15.2 |
| COVER ONCE | 7.8 | -669.4 | 0.0 | 180.7 | 6.2 | -433.0 | 0.0 | 152.6 |
| DEFENSIVE ARMY | 0.2 | +0.0 | 48.2 | 5.2 | - | - | - | - |
| EDGE GIVE GROUND | 0.1 | +2.5 | 4.4 | 9.4 | 0.2 | +4.4 | 13.2 | 0.9 |
| ELIXIR WORTH | 0.0 | +0.3 | 0.0 | 8.2 | 0.1 | +2.0 | 0.0 | 0.0 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 1.8 | +104.8 | 0.0 | 56.1 | 0.9 | +58.2 | 0.0 | 26.0 |
| FALLBACK BY WORTH | 3.7 | +38.7 | 0.0 | 62.0 | 5.4 | +61.6 | 0.0 | 88.0 |
| FIRE AND FLEE | - | - | - | - | 0.0 | +0.5 | 0.0 | 3.2 |
| FLANK NOT WEIGHED | 4.8 | +0.0 | 0.0 | 150.7 | 4.4 | +0.0 | 0.0 | 80.5 |
| FOCUS FIRE | 0.0 | +2.5 | 0.0 | 0.0 | 0.0 | +0.8 | 0.0 | 0.0 |
| FOLLOW UP WEIGHED | 1.0 | +127.5 | 0.0 | 41.6 | 0.9 | +137.8 | 0.0 | 57.2 |
| FRIEND IN REACH | 3.8 | +97.3 | 308.6 | 78.6 | 4.5 | +100.7 | 385.9 | 160.2 |
| FRIENDS SHOTS CHECKED | 0.2 | +19.5 | 0.0 | 0.0 | 0.3 | +16.5 | 0.0 | 11.5 |
| GIVES UP | 0.0 | -0.1 | 0.0 | 4.0 | 0.1 | -1.9 | 9.6 | 12.3 |
| GIVES UP ITS SCREEN | 0.0 | -0.1 | 3.1 | 0.0 | - | - | - | - |
| GROUND FLIERS | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |
| HELPER UNSEEN | 0.4 | +0.0 | 44.7 | 3.3 | 0.3 | +0.0 | 34.4 | 23.8 |
| HILL BY ITS CHANCE | - | - | - | - | 0.1 | -11.8 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.8 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 7.5 | -151.1 | 426.2 | 98.9 | 9.9 | -188.8 | 500.3 | 208.7 |
| HUNT ADVANCE | 0.0 | +0.2 | 0.0 | 0.0 | 0.2 | +8.2 | 3.5 | 6.1 |
| HUNT DROPPED | - | - | - | - | 0.1 | +0.0 | 3.5 | 0.0 |
| HUNT IN PAIRS | 0.3 | +17.7 | 0.0 | 5.4 | 0.6 | +38.3 | 0.0 | 0.0 |
| HUNT KEPT | - | - | - | - | 0.1 | +0.5 | 0.0 | 0.0 |
| HUNT RESULT | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 3.5 | 3.2 |
| HUNT THE GUNS | 0.0 | +12.5 | 0.0 | 0.0 | 0.2 | +49.4 | 3.5 | 6.1 |
| IDLE COST | 15.1 | -257.0 | 0.0 | 157.5 | 18.1 | -282.2 | 0.0 | 196.9 |
| INVITES THE FIGHT | 1.3 | +11.2 | 62.8 | 30.9 | 1.2 | +7.3 | 21.4 | 21.8 |
| JOINT CHARGE PLAN | 0.2 | +13.1 | 28.6 | 12.0 | 0.4 | +16.1 | 0.0 | 4.0 |
| JOINT KNOWS CHALLENGE | 0.1 | -3.6 | 0.0 | 0.0 | 0.1 | -2.5 | 0.0 | 0.0 |
| KEEP FALLS | 0.0 | +0.2 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| KEEPS ITS PREY | - | - | - | - | 0.1 | +0.4 | 0.0 | 3.5 |
| KEEPS ITS TARGET | 1.4 | +40.8 | 127.8 | 16.7 | 2.3 | +69.2 | 150.1 | 56.6 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KILLS COUNT | 1.8 | +77.9 | 106.1 | 19.6 | 1.8 | +119.8 | 132.0 | 66.8 |
| KILLS COUNT NEXT TURN | 4.4 | +158.8 | 181.3 | 107.0 | 6.5 | +247.1 | 238.7 | 145.6 |
| LONE CHARACTER SAFE SPOT | 0.4 | +5.5 | 3.0 | 16.2 | 0.4 | +24.8 | 0.0 | 5.0 |
| LONE WIZARD HOLDS BACK | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| LONE WIZARD KEPT IN | 0.7 | +49.1 | 0.0 | 0.0 | 0.2 | +24.5 | 0.0 | 0.0 |
| LONG SHOT | 0.4 | -2.3 | 27.2 | 1.8 | 0.6 | -1.3 | 36.3 | 24.8 |
| LOST CHARGE | 2.7 | -33.8 | 109.1 | 90.9 | 2.6 | -36.8 | 43.3 | 95.4 |
| LURE BY WHAT IT DRAWS | 0.2 | -13.5 | 0.0 | 5.1 | 0.1 | -12.5 | 0.0 | 10.3 |
| MAKE SURE TOGETHER | 0.8 | +59.9 | 12.8 | 28.6 | 1.3 | +87.8 | 2.6 | 35.7 |
| MANOEUVRE | 0.2 | +4.7 | 0.0 | 0.0 | 0.2 | +5.1 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.0 | +0.4 | 0.0 | 0.0 | 0.1 | +2.4 | 0.0 | 0.0 |
| MARCH CHECK | 0.5 | +11.8 | 0.0 | 18.7 | 0.3 | +14.2 | 0.0 | 0.0 |
| MARCH ODDS | 0.2 | +11.9 | 28.2 | 0.0 | 0.1 | +14.6 | 16.9 | 0.0 |
| MARCH OVER CASTS | 0.5 | +54.7 | 0.0 | 36.7 | 0.3 | +33.4 | 0.0 | 18.6 |
| MAX FOR POSITIONING | 4.9 | +75.3 | 0.0 | 136.6 | 6.8 | +83.5 | 0.0 | 139.8 |
| MISSILES IN THE MOVE | 4.1 | +175.3 | 0.0 | 98.2 | 3.6 | +64.4 | 0.0 | 40.6 |
| MISSILES NEXT TURN | 4.9 | +109.3 | 0.0 | 140.1 | 4.1 | +44.1 | 0.0 | 70.3 |
| MODEL FACING | 0.3 | +81.7 | 0.0 | 3.3 | - | - | - | - |
| MONSTER WIZARD ROAMS | 0.1 | +0.0 | 18.9 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| MOVE AND CAST | 0.2 | +10.7 | 0.0 | 2.2 | 0.4 | +22.1 | 0.0 | 11.1 |
| MOVE SPELL IN RANGE | 0.2 | +5.8 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.3 | -70.3 | 0.0 | 26.9 | 0.1 | -0.2 | 0.0 | 0.0 |
| MOVE SPELL SPOT | 0.2 | +0.0 | 0.0 | 11.1 | 0.1 | +0.0 | 0.0 | 11.1 |
| MOVE TO CHARGE | 3.2 | +291.8 | 117.1 | 86.6 | 5.4 | +310.2 | 155.2 | 139.5 |
| MOVES UNITS SPELL | 0.1 | +3.4 | 0.0 | 0.0 | 0.1 | +1.8 | 0.0 | 0.0 |
| NO RALLY LEFT | 0.0 | +9.1 | 0.0 | 0.0 | 0.0 | +5.4 | 0.0 | 0.0 |
| NOT NEEDED | - | - | - | - | 0.2 | -8.1 | 36.8 | 1.9 |
| NOT TURNED | 4.9 | +144.4 | 0.0 | 128.1 | 4.8 | +48.4 | 0.0 | 83.5 |
| NOT WORTH A CAST | 0.9 | -0.6 | 0.0 | 59.4 | 0.3 | -0.3 | 0.0 | 0.0 |
| OFF BEST | 16.2 | -619.3 | 0.0 | 278.0 | 16.5 | -748.5 | 24.1 | 229.0 |
| ONE FIGHT FORMULA | 7.2 | -136.8 | 45.4 | 172.1 | 8.4 | -163.7 | 13.8 | 260.2 |
| ONE OBJECTIVE FORMULA | 2.4 | -75.6 | 0.0 | 31.3 | 2.2 | -18.3 | 0.0 | 34.0 |
| OPENS A LANE | 0.1 | +0.8 | 17.1 | 0.0 | - | - | - | - |
| OPENS UP | 0.3 | +24.5 | 12.9 | 13.7 | 0.1 | +3.1 | 3.1 | 7.9 |
| OVERRUNS AWAY | 0.4 | +10.0 | 17.1 | 9.4 | 0.6 | +22.3 | 40.6 | 29.8 |
| PAIR SET-UP | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 8.2 |
| PATHS CROSS | 2.0 | +137.5 | 0.0 | 24.1 | 2.7 | +196.9 | 0.0 | 54.2 |
| PERIAPT WORTH | - | - | - | - | 0.1 | +6.3 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.1 | -1.7 | 0.0 | 0.0 | 0.1 | -2.4 | 0.0 | 10.6 |
| PLAN RESULT | 37.4 | +1534.4 | 1752.5 | 849.3 | 37.8 | +1045.1 | 1302.4 | 1010.5 |
| PURSUES BIG PREY | 0.1 | -9.6 | 0.0 | 0.0 | 0.1 | -2.7 | 0.0 | 0.0 |
| PURSUES ON | - | - | - | - | 0.0 | +0.5 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE NEXT TURN | 0.0 | +3.3 | 0.0 | 0.0 | 0.0 | +2.4 | 0.0 | 0.0 |
| RANDOM MOVE BY FIGURES | 0.9 | +11.6 | 0.0 | 22.6 | 1.4 | +21.5 | 0.0 | 37.5 |
| RANDOM MOVER NO PROMISE | 0.1 | -7.9 | 0.0 | 0.0 | 0.2 | -8.9 | 8.9 | 9.4 |
| REDIRECT BY WHAT IT STOPS | 0.7 | -12.4 | 0.0 | 16.0 | 1.4 | -42.8 | 0.0 | 17.9 |
| REDIRECT COUNTER | 1.6 | +69.2 | 0.0 | 36.3 | 3.5 | +311.9 | 0.0 | 65.2 |
| REDIRECT WEIGHED | 0.3 | +7.8 | 7.3 | 11.8 | 0.3 | +4.8 | 7.8 | 6.2 |
| REFUSING RETIRES | 0.2 | +0.0 | 0.0 | 5.4 | 0.3 | +0.0 | 0.0 | 6.2 |
| RESERVE FALL BACK | 0.4 | +15.3 | 0.0 | 3.1 | 0.8 | +22.8 | 0.0 | 17.9 |
| RESTRAINS TO SHOOT | 0.1 | +3.6 | 0.0 | 6.5 | 0.1 | +3.7 | 0.0 | 0.0 |
| RISK BY ARC | 2.1 | +97.9 | 162.1 | 51.2 | 2.4 | +43.3 | 188.9 | 124.2 |
| RISK ONCE | 2.6 | +44.7 | 20.4 | 118.8 | 5.8 | +356.8 | 28.6 | 279.1 |
| SAFER THAN THE JOB | 0.9 | +42.4 | 0.0 | 18.8 | 0.8 | +36.4 | 0.0 | 33.2 |
| SCOUT SPOT | 0.4 | +0.7 | 0.0 | 0.0 | 0.3 | +0.6 | 0.0 | 0.9 |
| SCOUT WAITS | 0.4 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.9 |
| SCREEN BY WHAT IT SAVES | 0.2 | -7.6 | 0.0 | 1.8 | 0.4 | -14.4 | 0.0 | 5.1 |
| SEARCH SPOT | 1.6 | +72.3 | 0.0 | 43.4 | 2.0 | +88.7 | 0.0 | 36.6 |
| SECOND CHARGER ADDS | 0.3 | -15.4 | 37.0 | 0.0 | - | - | - | - |
| SELF MOVE SPELL | 0.2 | +29.8 | 0.0 | 40.1 | 0.1 | -0.2 | 0.0 | 9.1 |
| SET UP TOGETHER | 1.3 | +123.9 | 61.8 | 32.8 | 2.5 | +175.0 | 5.0 | 69.9 |
| SET-UP ANY TARGET | 0.2 | +31.3 | 0.0 | 0.0 | 0.1 | +13.9 | 3.2 | 7.6 |
| SET-UP MISSED | - | - | - | - | 0.0 | +3.9 | 3.5 | 7.6 |
| SHOOTER COUNTED ONCE | - | - | - | - | 0.1 | -0.2 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.4 | +0.9 | 0.0 | 0.0 | 0.3 | +0.8 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.9 | +86.1 | 127.5 | 15.5 | 0.8 | +33.5 | 14.4 | 18.5 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 3.2 | 0.0 | +0.0 | 0.0 | 0.0 |
| SHOT REPLANNED | 0.6 | +0.0 | 133.0 | 15.5 | 0.2 | +0.0 | 8.9 | 5.1 |
| SHOTS IN THE MOVE | 14.2 | +655.5 | 0.0 | 210.4 | 8.8 | +202.4 | 0.0 | 154.2 |
| SPELL SETS UP CHARGE | 0.3 | +47.2 | 0.0 | 0.0 | 0.2 | +68.8 | 3.2 | 7.6 |
| SPELL WORTH | 1.2 | +19.3 | 85.6 | 94.4 | 1.7 | +37.0 | 55.9 | 55.9 |
| SPELLS IN THE FIGHT | 0.6 | +6.4 | 28.3 | 7.3 | 0.8 | -13.1 | 83.4 | 36.9 |
| STABLE ROLE | 11.2 | +0.0 | 505.5 | 153.5 | 11.3 | +0.0 | 346.6 | 230.1 |
| STANDS TO CAST | 0.0 | +1.0 | 0.0 | 10.9 | 0.1 | +1.1 | 0.0 | 3.2 |
| STAY WEIGHED | 0.0 | +0.1 | 0.0 | 0.0 | - | - | - | - |
| STOPS SHORT OF THE FLANK | 0.4 | +18.4 | 0.0 | 0.0 | 0.4 | +9.6 | 0.0 | 3.2 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 4.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| SUPPORT NARROWED | 5.2 | -58.9 | 343.9 | 69.5 | 7.0 | -62.1 | 418.8 | 94.4 |
| SUPPORTS | 3.6 | +63.9 | 202.4 | 38.4 | 4.9 | +63.4 | 248.6 | 45.3 |
| SURE CHARGE BEATS ADVANCE | 0.1 | -3.0 | 0.0 | 0.0 | 0.1 | -3.9 | 17.9 | 0.0 |
| SURE REACH TOGETHER | 0.8 | -4.1 | 0.0 | 20.8 | 0.7 | +1.0 | 3.8 | 15.0 |
| THROUGH LINE OF FIRE | 0.5 | +21.4 | 0.0 | 9.4 | 0.3 | +12.4 | 0.0 | 9.5 |
| TURN WORTH | 0.4 | -29.9 | 38.6 | 18.9 | 0.1 | -6.9 | 16.8 | 0.0 |
| TWO OR MORE ARRIVE | 0.2 | +1.5 | 36.6 | 3.2 | 0.7 | +3.4 | 2.6 | 25.1 |
| WAIT AFTER COSTS | 6.5 | -333.3 | 279.9 | 148.1 | 8.8 | -431.7 | 281.8 | 189.1 |
| WALKS TO THE FIGHT | 1.6 | +13.6 | 54.1 | 23.4 | 1.1 | +10.9 | 44.3 | 4.9 |
| WAR ENGINE CHARGES | 0.1 | +8.8 | 12.2 | 0.0 | 0.0 | +2.0 | 4.0 | 0.0 |
| WAR ENGINE JOBS | 0.6 | +0.0 | 47.4 | 16.9 | 0.3 | +0.0 | 8.5 | 5.1 |
| WEARS DOWN | 0.9 | +60.9 | 104.1 | 17.9 | 1.3 | +41.5 | 116.5 | 71.3 |
| WHO HITS BACK | 0.2 | +17.3 | 0.0 | 15.8 | 0.2 | +12.9 | 0.0 | 16.7 |
| WHOLE FIGHT | 0.3 | +11.6 | 42.6 | 0.0 | 0.2 | +15.8 | 58.3 | 3.2 |
| WHOLE FIGHT GAIN | 0.6 | +38.3 | 63.5 | 1.5 | 0.5 | +20.5 | 30.2 | 7.6 |
| WIDER SPREAD | 2.6 | -10.1 | 237.4 | 36.9 | 3.2 | -10.7 | 265.9 | 102.3 |
| WOUNDED STAYS OUT | 0.0 | +0.0 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |

### Rule changes: jc-mine-1e5408d-p1

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 1176 | 1176 | 1176 | 32.67 | -49243 | -41.9 |
| PATHS CROSS | 170 | 170 | 170 | 4.72 | +12040 | +70.8 |
| MOVE TO CHARGE | 309 | 309 | 150 | 4.17 | +7514 | +50.1 |
| SUPPORTS | 307 | 307 | 136 | 3.78 | +1601 | +11.8 |
| KILLS COUNT NEXT TURN | 391 | 391 | 130 | 3.61 | +4112 | +31.6 |
| SEARCH SPOT | 132 | 132 | 130 | 3.61 | +5797 | +44.6 |
| WAIT AFTER COSTS | 551 | 551 | 105 | 2.92 | +2327 | +22.2 |
| FACES THE THREAT | 97 | 97 | 97 | 2.69 | +5870 | +60.5 |
| COVER ONCE | 505 | 287 | 85 | 2.36 | +1099 | +12.9 |
| RISK ONCE | 301 | 227 | 79 | 2.19 | +3156 | +39.9 |
| BEST FIRST | 77 | 77 | 77 | 2.14 | +3220 | +41.8 |
| SHOTS IN THE MOVE | 830 | 570 | 77 | 2.14 | +2118 | +27.5 |
| FALLBACK BY WORTH | 326 | 326 | 71 | 1.97 | +3611 | +50.9 |
| CHAFF IN THE MOVE | 102 | 100 | 70 | 1.94 | +2246 | +32.1 |
| FOLLOW UP WEIGHED | 69 | 69 | 69 | 1.92 | +9551 | +138.4 |
| SET UP TOGETHER | 135 | 121 | 63 | 1.75 | +3790 | +60.2 |
| ADVANCE WORTH | 364 | 364 | 61 | 1.69 | +1165 | +19.1 |
| SAFER THAN THE JOB | 60 | 60 | 60 | 1.67 | +2837 | +47.3 |
| ONE FIGHT FORMULA | 562 | 355 | 56 | 1.56 | +193 | +3.5 |
| CANNON SIGHT KEPT | 51 | 51 | 51 | 1.42 | +0 | +0.0 |
| CANNON PLANNED TARGET | 230 | 230 | 50 | 1.39 | -111 | -2.2 |
| MISSILES IN THE MOVE | 277 | 177 | 49 | 1.36 | +1573 | +32.1 |
| ADVANCE LANE KEPT | 46 | 46 | 46 | 1.28 | +0 | +0.0 |
| ARTILLERY RE-ROLL WEIGHED | 46 | 46 | 46 | 1.28 | +0 | +0.0 |
| RESERVE FALL BACK | 45 | 45 | 45 | 1.25 | +1370 | +30.4 |
| WALKS TO THE FIGHT | 100 | 100 | 45 | 1.25 | +277 | +6.2 |
| HOLDS AMBUSHERS | 44 | 44 | 44 | 1.22 | +0 | +0.0 |
| RANDOM MOVE BY FIGURES | 83 | 83 | 44 | 1.22 | +1192 | +27.1 |
| INVITES THE FIGHT | 88 | 88 | 40 | 1.11 | +280 | +7.0 |
| REDIRECT COUNTER | 183 | 93 | 40 | 1.11 | +3216 | +80.4 |
| RISK BY ARC | 161 | 159 | 40 | 1.11 | +1512 | +37.8 |
| KILLS COUNT | 129 | 128 | 39 | 1.08 | +2251 | +57.7 |
| SHOOTS FROM THE BEST SPOT | 98 | 98 | 39 | 1.08 | +1150 | +29.5 |
| CHARGE NOW WEIGHED | 35 | 35 | 35 | 0.97 | +1891 | +54.0 |
| LONE WIZARD KEPT IN | 34 | 34 | 34 | 0.94 | +2648 | +77.9 |
| CAST JOB | 71 | 71 | 33 | 0.92 | +1319 | +40.0 |
| COMBAT PIVOT | 32 | 32 | 32 | 0.89 | +0 | +0.0 |
| HONEST WORTH | 626 | 624 | 31 | 0.86 | +356 | +11.5 |
| MAX FOR POSITIONING | 424 | 264 | 31 | 0.86 | +74 | +2.4 |
| CHARGE NOW FIRST | 169 | 169 | 30 | 0.83 | -1312 | -43.7 |
| THROUGH LINE OF FIRE | 30 | 30 | 30 | 0.83 | +1215 | +40.5 |
| IDLE COST | 1195 | 654 | 27 | 0.75 | +225 | +8.3 |
| SHOT REPLANNED | 27 | 27 | 27 | 0.75 | +0 | +0.0 |
| STOPS SHORT OF THE FLANK | 27 | 27 | 27 | 0.75 | +1008 | +37.3 |
| CASTER AWAY FROM SCREEN | 26 | 26 | 26 | 0.72 | +0 | +0.0 |
| MARCH CHECK | 28 | 26 | 26 | 0.72 | +1307 | +50.3 |
| SCOUT WAITS | 26 | 26 | 26 | 0.72 | +0 | +0.0 |
| MOVE AND CAST | 24 | 24 | 24 | 0.67 | +1180 | +49.1 |
| REDIRECT WEIGHED | 24 | 24 | 24 | 0.67 | +912 | +38.0 |
| SHOOTERS IN TWO RANKS | 24 | 24 | 24 | 0.67 | +58 | +2.4 |
| MAKE SURE TOGETHER | 78 | 58 | 23 | 0.64 | +1315 | +57.2 |
| BEST FACING | 22 | 22 | 22 | 0.61 | +538 | +24.5 |
| BLOCKED WHEEL | 21 | 21 | 21 | 0.58 | +695 | +33.1 |
| BEST OVERALL | 18 | 18 | 18 | 0.50 | +916 | +50.9 |
| FRIENDS SHOTS CHECKED | 18 | 18 | 18 | 0.50 | +1296 | +72.0 |
| KEEPS ITS TARGET | 132 | 132 | 16 | 0.44 | +298 | +18.6 |
| LOST CHARGE | 192 | 192 | 16 | 0.44 | +648 | +40.5 |
| CASTING BLOCK | 22 | 22 | 15 | 0.42 | +665 | +44.3 |
| WHO HITS BACK | 15 | 15 | 15 | 0.42 | +773 | +51.5 |
| CASTS FROM BEHIND | 14 | 14 | 14 | 0.39 | +0 | +0.0 |
| MARCH ODDS | 14 | 14 | 14 | 0.39 | +105 | +7.5 |
| WAR ENGINE JOBS | 33 | 33 | 14 | 0.39 | -751 | -53.6 |
| MANOEUVRE | 17 | 17 | 13 | 0.36 | +351 | +27.0 |
| BIG CHARACTER SAFETY | 12 | 12 | 12 | 0.33 | -70 | -5.9 |
| MODEL FACING | 12 | 12 | 12 | 0.33 | +2942 | +245.2 |
| STUCK PIVOT | 12 | 12 | 12 | 0.33 | +0 | +0.0 |
| BEST PREY | 42 | 42 | 11 | 0.31 | +368 | +33.5 |
| WHOLE FIGHT GAIN | 41 | 40 | 11 | 0.31 | +493 | +44.8 |
| WEARS DOWN | 77 | 75 | 10 | 0.28 | +582 | +58.2 |
| CHAFF PASSED | 9 | 9 | 9 | 0.25 | -2 | -0.2 |
| OPENS UP | 13 | 13 | 9 | 0.25 | +441 | +49.0 |
| REFUSING RETIRES | 19 | 19 | 9 | 0.25 | -3 | -0.3 |
| HUNT IN PAIRS | 32 | 20 | 8 | 0.22 | +387 | +48.4 |
| RESTRAINS TO SHOOT | 8 | 8 | 8 | 0.22 | +263 | +32.9 |
| SHORT GUN FORWARD | 8 | 8 | 8 | 0.22 | +0 | +0.0 |
| SUPPORT NARROWED | 440 | 440 | 8 | 0.22 | -160 | -20.0 |
| WHOLE FIGHT | 19 | 19 | 8 | 0.22 | +392 | +49.0 |
| MISSILES NEXT TURN | 324 | 193 | 7 | 0.19 | +12 | +1.8 |
| MOVES UNITS SPELL | 7 | 7 | 7 | 0.19 | +186 | +26.5 |
| PIVOT GUARDS FLANK | 7 | 7 | 7 | 0.19 | -148 | -21.2 |
| PURSUES BIG PREY | 7 | 7 | 7 | 0.19 | -444 | -63.4 |
| SURE CHARGE BEATS ADVANCE | 7 | 7 | 7 | 0.19 | -249 | -35.6 |
| BEST PRIZE | 5 | 5 | 5 | 0.14 | -274 | -54.9 |
| BLOCKED CHARGE SKIPPED | 5 | 5 | 5 | 0.14 | +0 | +0.0 |
| HUNT ADVANCE | 8 | 8 | 5 | 0.14 | +132 | +26.4 |
| OVERRUNS AWAY | 33 | 33 | 5 | 0.14 | +154 | +30.7 |
| SPELLS IN THE FIGHT | 48 | 45 | 5 | 0.14 | +86 | +17.1 |
| SURE REACH TOGETHER | 52 | 42 | 5 | 0.14 | +9 | +1.8 |
| ONE OBJECTIVE FORMULA | 167 | 79 | 4 | 0.11 | +190 | +47.4 |
| BACKUP TARGETS | 34 | 18 | 3 | 0.08 | -0 | -0.0 |
| ELIXIR WORTH | 3 | 3 | 3 | 0.08 | +85 | +28.4 |
| JOINT CHARGE PLAN | 21 | 21 | 3 | 0.08 | +212 | +70.7 |
| STANDS TO CAST | 3 | 3 | 3 | 0.08 | +3 | +0.9 |
| BLOWS WHERE AIMED | 21 | 19 | 2 | 0.06 | +109 | +54.3 |
| CONTINUE AHEAD WEIGHED | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| FOCUS FIRE | 2 | 2 | 2 | 0.06 | +116 | +57.8 |
| KEEP FALLS | 2 | 2 | 2 | 0.06 | +9 | +4.6 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| NO RALLY LEFT | 2 | 2 | 2 | 0.06 | +371 | +185.6 |
| PERIAPT WORTH | 2 | 2 | 2 | 0.06 | +225 | +112.5 |
| RAIDS THE BAGGAGE NEXT TURN | 2 | 2 | 2 | 0.06 | +91 | +45.3 |
| BOMBING RUN | 1 | 1 | 1 | 0.03 | +12 | +11.5 |
| BOUND ASSAILMENT | 1 | 1 | 1 | 0.03 | +0 | +0.1 |
| DEFENSIVE ARMY | 7 | 7 | 1 | 0.03 | -17 | -17.2 |
| EDGE GIVE GROUND | 8 | 8 | 1 | 0.03 | +16 | +16.1 |
| FIRE AND FLEE | 1 | 1 | 1 | 0.03 | +16 | +16.5 |
| PURSUES ON | 1 | 1 | 1 | 0.03 | +16 | +16.4 |
| REDIRECT BY WHAT IT STOPS | 76 | 76 | 1 | 0.03 | +32 | +32.5 |
| SECOND CHARGER ADDS | 11 | 11 | 1 | 0.03 | +12 | +11.7 |
| STAY WEIGHED | 1 | 1 | 1 | 0.03 | +3 | +3.0 |
| WIDER SPREAD | 208 | 201 | 1 | 0.03 | +9 | +9.1 |
| WOUNDED STAYS OUT | 2 | 2 | 1 | 0.03 | -20 | -20.3 |
| ALREADY CARRIED | 1 | not checked | - | - | - | - |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 35 | 35 | 0 | 0.00 | - | - |
| CARRIES OUT SET-UP | 10 | 10 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 32 | trace | - | - | - | - |
| CATCH FLIERS | 2 | not checked | - | - | - | - |
| CHARGER SLAIN LOST | 38 | 36 | 0 | 0.00 | - | - |
| CHARIOT NO STATIC JOB | 1 | 1 | 0 | 0.00 | - | - |
| CHARIOT WIZARD CAREFUL | 4 | 4 | 0 | 0.00 | - | - |
| CHEAP HELPER | 8 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 29 | not checked | - | - | - | - |
| ENGINEER BY LORE | 2 | 2 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 330 | not checked | - | - | - | - |
| FRIEND IN REACH | 300 | not checked | - | - | - | - |
| GIVES UP | 6 | 6 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 1 | 1 | 0 | 0.00 | - | - |
| GROUND FLIERS | 1 | not checked | - | - | - | - |
| HELPER UNSEEN | 27 | 25 | 0 | 0.00 | - | - |
| HILL BY ITS CHANCE | 4 | 4 | 0 | 0.00 | - | - |
| HUNT DROPPED | 3 | trace | - | - | - | - |
| HUNT KEPT | 2 | trace | - | - | - | - |
| HUNT RESULT | 6 | trace | - | - | - | - |
| HUNT THE GUNS | 7 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 4 | 4 | 0 | 0.00 | - | - |
| KEEPS ITS PREY | 2 | 2 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 29 | not checked | - | - | - | - |
| LONE WIZARD HOLDS BACK | 14 | 14 | 0 | 0.00 | - | - |
| LONG SHOT | 35 | 34 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 12 | 12 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 5 | trace | - | - | - | - |
| MARCH OVER CASTS | 30 | 30 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 10 | 10 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 7 | 2 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 14 | trace | - | - | - | - |
| MOVE SPELL SPOT | 10 | not checked | - | - | - | - |
| NOT NEEDED | 7 | 7 | 0 | 0.00 | - | - |
| NOT TURNED | 348 | 348 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 45 | not checked | - | - | - | - |
| OPENS A LANE | 4 | 3 | 0 | 0.00 | - | - |
| PAIR SET-UP | 4 | not checked | - | - | - | - |
| PLAN RESULT | 2708 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 12 | 12 | 0 | 0.00 | - | - |
| SCOUT SPOT | 23 | 23 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 19 | 19 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 12 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 12 | not checked | - | - | - | - |
| SET-UP MISSED | 1 | trace | - | - | - | - |
| SHOOTER COUNTED ONCE | 2 | 2 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 17 | not checked | - | - | - | - |
| SPELL WORTH | 105 | not checked | - | - | - | - |
| STABLE ROLE | 809 | 808 | 0 | 0.00 | - | - |
| TURN WORTH | 19 | 19 | 0 | 0.00 | - | - |
| TWO OR MORE ARRIVE | 34 | 28 | 0 | 0.00 | - | - |
| WAR ENGINE CHARGES | 3 | 3 | 0 | 0.00 | - | - |

### Off best figure: jc-mine-1e5408d-p1

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 14.97 | 14.42 | 43.7 |
| FALLBACK | gate | 0.47 | 1.11 | 35.7 |
| CHARGE NOW FIRST | rule | 0.44 | 0.39 | 43.7 |
| TURN GATE | gate | 0.33 | 0.42 | 10.3 |
| WAR ENGINE JOBS | rule | 0.33 | 0.06 | 53.6 |
| CANNON PLANNED TARGET | rule | 0.31 | - | 20.7 |
| AFTERMATH BAND | gate | 0.14 | 0.11 | 2.6 |
| SUPPORT REQUEST | gate | 0.06 | 0.19 | 58.7 |
| SUPPORT NARROWED | rule | 0.14 | 0.08 | 20.0 |
| CHARGE NOW WEIGHED | rule | 0.11 | 0.08 | 41.2 |
| PATHS CROSS | rule | 0.11 | 0.08 | 9.2 |
| PIVOT GUARDS FLANK | rule | 0.06 | 0.14 | 21.2 |
| PURSUES BIG PREY | rule | 0.14 | 0.06 | 63.4 |
| SURE CHARGE BEATS ADVANCE | rule | 0.06 | 0.14 | 35.6 |
| BIG CHARACTER SAFETY | rule | 0.11 | 0.06 | 14.2 |
| FIGHT ORDER BAND | gate | 0.08 | 0.08 | 2.5 |
| BEST PRIZE | rule | 0.06 | 0.08 | 54.9 |
| FACES THE THREAT | rule | 0.11 | - | 10.9 |
| LONE CHARACTER SAFE SPOT | gate | 0.06 | 0.06 | 10.2 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.03 | 0.06 | 13.4 |
| BLOCKED WHEEL | rule | - | 0.06 | 4.5 |
| CHAFF PASSED | rule | - | 0.06 | 1.0 |
| MARCH ODDS | rule | 0.06 | - | 2.8 |
| NO REASON | gate | 0.06 | - | 19.2 |
| REDIRECT WEIGHED | rule | 0.06 | - | 68.2 |
| REFUSING RETIRES | rule | 0.03 | 0.03 | 0.8 |
| SAFER THAN THE JOB | rule | - | 0.06 | 20.9 |
| DEFENSIVE ARMY | rule | 0.03 | - | 17.2 |
| FRIENDS SHOTS CHECKED | rule | 0.03 | - | 1.7 |
| MOVE AND CAST | rule | - | 0.03 | 11.0 |
| RULE SWITCHED OFF | gate | - | 0.03 | 15.0 |
| STANDS TO CAST | rule | - | 0.03 | 1.8 |
| THROUGH LINE OF FIRE | rule | 0.03 | - | 2.7 |
| WHO HITS BACK | rule | 0.03 | - | 4.0 |
| WOUNDED STAYS OUT | rule | - | 0.03 | 20.3 |

### Plans: jc-mine-1e5408d-p1

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 9.5 | 19% | 174 | 315 | 181% |
| Mine | charge | 2.9 | 58% | 249 | 248 | 100% |
| Mine | close in | 4.4 | 25% | 292 | 167 | 57% |
| Mine | hold | 5.3 | 37% | 326 | 0 | 0% |
| Mine | join | 0.6 | 100% | 19 | 0 | 0% |
| Mine | shoot | 10.0 | 59% | 423 | 805 | 191% |
| Mine | support | 4.6 | 87% | 52 | 0 | 0% |
| Opponent | advance | 10.2 | 17% | 150 | 219 | 146% |
| Opponent | charge | 3.8 | 65% | 303 | 402 | 133% |
| Opponent | close in | 6.6 | 27% | 411 | 195 | 47% |
| Opponent | hold | 4.6 | 42% | 304 | 0 | 0% |
| Opponent | join | 1.1 | 97% | 48 | 0 | 0% |
| Opponent | shoot | 5.2 | 58% | 111 | 230 | 208% |
| Opponent | support | 6.4 | 90% | 61 | 0 | 0% |

### Packages: hunt the guns, jc-mine-1e5408d-p1

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.0 | 1 | 0 | 0% | 0% | 0% | - | 450 | 0 | 0% | 23 |
| Opponent | 0.2 | 6 | 1 | 0% | 0% | 0% | - | 304 | 0 | 0% | 104 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Dwarfen Mountain Holds | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 450 | 0 | 0% | 118 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 70 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 231 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 175 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 70 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Tomb Kings of Khemri | 0.5 | 3 | 1 | 0% | 0% | 0% | - | 320 | 0 | 0% | 84 |
| Vampire Counts | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 22 |
| Warriors of Chaos | 0.2 | 2 | 0 | 0% | 0% | 0% | - | 277 | 0 | 0% | 76 |
| Wood Elf Realms | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 329 | 0 | 0% | 58 |

### Battle groups: jc-mine-1e5408d-p1

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 1.6 | 35% | 55% | 20% | 50% | 12% | 0% | 6% | 75% | 6% |
| Opponent | REDIRECT COUNTER | 3.5 | 25% | 65% | 13% | 25% | 19% | 4% | 19% | 48% | 11% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: jc-mine-1e5408d-p1

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 3 | 0 (3) | 0 | 0 | 37 | 67% | 4.0 | 0 (1) | 0 (2) | - | - | 0 (3) |
| Mine | Chaff | 37 | 14 (37) | 0 | 14 | 43 | 43% | 2.2 | 3 (16) | 5 (9) | 34 (12) | 19 (24) | 6 (13) |
| Mine | Character | 123 | 54 (123) | 54 | 0 | 37 | 20% | 2.3 | 74 (35) | 54 (57) | 21 (10) | 71 (56) | 46 (46) |
| Mine | Clean-up | 24 | 57 (24) | 29 | 27 | 34 | 38% | 2.8 | 56 (9) | 69 (11) | 8 (4) | 83 (14) | 26 (10) |
| Mine | Fast | 4 | 30 (4) | 30 | 0 | 34 | 0% | 1.5 | 57 (1) | 0 (2) | 0 (1) | 30 (4) | - |
| Mine | Fast Hammer | 41 | 38 (41) | 18 | 21 | 43 | 37% | 2.9 | 39 (18) | 37 (12) | 39 (11) | 48 (28) | 20 (13) |
| Mine | Fragile | 5 | 14 (5) | 14 | 0 | 40 | 0% | 1.8 | - | 17 (4) | 0 (1) | 0 (1) | 17 (4) |
| Mine | Hammer | 58 | 47 (58) | 31 | 15 | 40 | 14% | 2.4 | 18 (10) | 54 (38) | 42 (10) | 51 (34) | 42 (24) |
| Mine | Holder | 25 | 97 (25) | 14 | 83 | 14 | 48% | 3.7 | 111 (6) | 74 (12) | 178 (5) | 144 (9) | 75 (14) |
| Mine | Shooter | 44 | 73 (44) | 16 | 57 | 42 | 5% | 1.8 | 0 (5) | 98 (31) | 47 (8) | 90 (25) | 52 (19) |
| Mine | Support | 5 | 0 (5) | 0 | 0 | 42 | 20% | 3.0 | - | 0 (2) | - | 0 (2) | - |
| Mine | War machine | 56 | 57 (56) | 57 | 0 | 45 | 5% | 1.2 | 44 (13) | 71 (37) | 0 (6) | 17 (11) | 68 (45) |
| Mine | Wizard | 23 | 23 (23) | 23 | 0 | 32 | 13% | 3.0 | 0 (6) | 52 (11) | 23 (3) | 96 (4) | 5 (16) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 100 | 0% | 4.0 | 0 (1) | - | - | - | 0 (1) |
| Opponent | Chaff | 66 | 81 (66) | 39 | 42 | 41 | 39% | 2.7 | 101 (28) | 29 (16) | 99 (22) | 100 (48) | 29 (18) |
| Opponent | Character | 114 | 49 (114) | 49 | 0 | 38 | 25% | 2.5 | 63 (39) | 46 (56) | 33 (6) | 48 (69) | 64 (32) |
| Opponent | Clean-up | 16 | 54 (16) | 54 | 0 | 41 | 38% | 2.6 | 93 (5) | 15 (8) | 62 (3) | 92 (8) | 25 (8) |
| Opponent | Early | 1 | 1058 (1) | 1058 | 0 | 100 | 0% | 5.0 | - | 1058 (1) | - | 1058 (1) | - |
| Opponent | Fast Hammer | 58 | 40 (58) | 22 | 18 | 44 | 19% | 2.7 | 36 (25) | 36 (19) | 55 (14) | 42 (42) | 34 (16) |
| Opponent | Fragile | 10 | 0 (10) | 0 | 0 | 54 | 30% | 2.0 | 0 (3) | 0 (4) | 0 (3) | 0 (9) | 0 (1) |
| Opponent | Hammer | 65 | 24 (65) | 19 | 6 | 54 | 25% | 2.7 | 21 (16) | 26 (42) | 16 (7) | 16 (40) | 41 (25) |
| Opponent | Holder | 40 | 68 (40) | 6 | 63 | 30 | 48% | 3.0 | 72 (7) | 107 (18) | 28 (10) | 130 (17) | 37 (18) |
| Opponent | Shooter | 30 | 63 (30) | 11 | 52 | 39 | 3% | 1.3 | 31 (7) | 77 (18) | 49 (5) | 57 (16) | 71 (14) |
| Opponent | Support | 2 | 0 (2) | 0 | 0 | 0 | 100% | - | 0 (2) | - | - | - | 0 (2) |
| Opponent | War machine | 13 | 58 (13) | 58 | 0 | 40 | 0% | 1.2 | 0 (5) | 59 (5) | 159 (3) | 95 (3) | 46 (10) |
| Opponent | Wizard | 22 | 0 (22) | 0 | 0 | 32 | 9% | 1.9 | 0 (9) | 0 (4) | 0 (3) | 0 (9) | 0 (7) |

### Charged fights: jc-mine-1e5408d-p1

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 5 | 219 | 15 | 1.2 | 1.0 | 13 | 0 | +13 | 1 of 6 | 2 of 6 | - | +13 |
| Mine | Chaos Dwarfs | 3 | 294 | 760 | 3.7 | 1.2 | 207 | 0 | +207 | 7 of 11 | 8 of 11 | +203 | +208 |
| Mine | Dwarfen Mountain Holds | 4 | 330 | 53 | 1.5 | 1.2 | 35 | 10 | +25 | 2 of 6 | 5 of 6 | -60 | +42 |
| Mine | Empire of Man | 5 | 565 | 31 | 1.4 | 1.0 | 22 | 0 | +22 | 1 of 7 | 6 of 7 | - | +22 |
| Mine | Grand Cathay | 4 | 601 | 414 | 3.5 | 1.1 | 118 | 38 | +80 | 9 of 14 | 8 of 14 | +196 | +61 |
| Mine | High Elf Realms | 4 | 45 | 323 | 3.8 | 1.3 | 86 | 28 | +58 | 4 of 15 | 14 of 15 | +13 | +81 |
| Mine | Kingdom of Bretonnia | 1 | 0 | 1039 | 5.0 | 1.2 | 208 | 0 | +208 | 2 of 5 | 5 of 5 | +85 | +238 |
| Mine | Lizardmen | 1 | 66 | 186 | 3.0 | 1.0 | 62 | 47 | +15 | 1 of 3 | 2 of 3 | - | +15 |
| Mine | Ogre Kingdoms | 1 | 195 | 195 | 4.0 | 1.0 | 49 | 81 | -32 | 3 of 4 | 1 of 4 | - | -32 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 0 | 3.0 | 1.0 | 0 | 37 | -37 | 2 of 3 | 0 of 2 | - | -37 |
| Mine | Skaven | 2 | 48 | 127 | 0.5 | 1.0 | 254 | 0 | +254 | 1 of 1 | 1 of 1 | - | +254 |
| Mine | Tomb Kings of Khemri | 2 | 58 | 1214 | 5.5 | 1.2 | 221 | 18 | +203 | 3 of 11 | 9 of 11 | +514 | +134 |
| Mine | Vampire Counts | 2 | 0 | 220 | 3.5 | 1.1 | 63 | 0 | +63 | 1 of 7 | 7 of 7 | +173 | +45 |
| Mine | Warriors of Chaos | 1 | 0 | 756 | 5.0 | 1.2 | 151 | 99 | +52 | 1 of 5 | 5 of 5 | -385 | +162 |
| **Mine** | all armies | 36 | 255 | 305 | 2.7 | 1.2 | 112 | 23 | +89 | 38 of 98 | 73 of 97 | +114 | +84 |
| Opponent | Beastmen Brayherds | 1 | 0 | 337 | 5.0 | 1.0 | 67 | 23 | +44 | 1 of 5 | 5 of 5 | - | +44 |
| Opponent | Dwarfen Mountain Holds | 1 | 0 | 112 | 2.0 | 1.0 | 56 | 0 | +56 | 0 of 2 | 1 of 2 | - | +56 |
| Opponent | Empire of Man | 1 | 255 | 0 | 2.0 | 1.0 | 0 | 132 | -132 | 1 of 2 | 1 of 2 | - | -132 |
| Opponent | Grand Cathay | 1 | 400 | 813 | 3.0 | 1.7 | 271 | 0 | +271 | 2 of 3 | 3 of 3 | +613 | +100 |
| Opponent | High Elf Realms | 2 | 177 | 214 | 2.5 | 1.0 | 86 | 0 | +86 | 2 of 5 | 3 of 5 | - | +86 |
| Opponent | Lizardmen | 1 | 0 | 618 | 4.0 | 1.0 | 154 | 35 | +119 | 4 of 4 | 2 of 4 | - | +119 |
| Opponent | Ogre Kingdoms | 2 | 68 | 598 | 4.5 | 1.1 | 133 | 53 | +80 | 3 of 9 | 5 of 9 | +30 | +86 |
| Opponent | Orc & Goblin Tribes | 2 | 0 | 741 | 4.5 | 1.1 | 165 | 135 | +29 | 5 of 9 | 6 of 9 | +310 | -6 |
| Opponent | Skaven | 2 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Tomb Kings of Khemri | 4 | 44 | 1064 | 5.0 | 1.2 | 213 | 56 | +156 | 9 of 20 | 15 of 20 | +318 | +116 |
| Opponent | Vampire Counts | 6 | 9 | 592 | 4.0 | 1.1 | 148 | 11 | +137 | 12 of 24 | 20 of 24 | -15 | +151 |
| Opponent | Warriors of Chaos | 7 | 0 | 192 | 1.1 | 1.0 | 168 | 0 | +168 | 5 of 8 | 7 of 8 | - | +168 |
| Opponent | Wood Elf Realms | 6 | 151 | 212 | 2.3 | 1.3 | 91 | 61 | +30 | 5 of 14 | 10 of 14 | +44 | +26 |
| **Opponent** | all armies | 36 | 63 | 428 | 2.9 | 1.1 | 147 | 43 | +104 | 49 of 105 | 78 of 105 | +194 | +93 |

### Effective charges: jc-mine-1e5408d-p1

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 6 | 1 (net +0) | 0 | 0 | 1 (net +0) | 0 | 4 (net +19) | 0 | 0% (0 of 6) |
| Mine | Chaos Dwarfs | 11 | 1 (net +506) | 0 | 0 | 4 (net +208) | 2 (net +48) | 4 (net +212) | 0 | 0% (0 of 11) |
| Mine | Dwarfen Mountain Holds | 6 | 3 (net -20) | 0 | 0 | 2 (net +76) | 0 | 1 (net +60) | 0 | 0% (0 of 6) |
| Mine | Empire of Man | 7 | 1 (net +0) | 0 | 0 | 2 (net +42) | 2 (net +35) | 2 (net +0) | 0 | 0% (0 of 7) |
| Mine | Grand Cathay | 14 | 4 (net +34) | 0 | 1 (net +470) | 2 (net -82) | 0 | 6 (net +99) | 1 | 8% (1 of 13) |
| Mine | High Elf Realms | 15 | 2 (net -72) | 0 | 3 (net -12) | 2 (net +0) | 3 (net +72) | 4 (net +180) | 1 | 21% (3 of 14) |
| Mine | Kingdom of Bretonnia | 5 | 0 | 0 | 1 (net +85) | 1 (net +580) | 1 (net +45) | 2 (net +164) | 0 | 20% (1 of 5) |
| Mine | Ogre Kingdoms | 4 | 0 | 0 | 1 (net -39) | 0 | 0 | 0 | 3 | 100% (1 of 1) |
| Mine | Skaven | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +254) | 0 | 0% (0 of 1) |
| Mine | Tomb Kings of Khemri | 11 | 2 (net +430) | 0 | 1 (net +116) | 3 (net +129) | 3 (net +98) | 1 (net +432) | 1 | 10% (1 of 10) |
| Mine | Vampire Counts | 7 | 1 (net +0) | 0 | 0 | 2 (net +0) | 2 (net +136) | 1 (net +0) | 1 | 0% (0 of 6) |
| Mine | Warriors of Chaos | 5 | 1 (net +0) | 0 | 0 | 0 | 2 (net +103) | 1 (net +0) | 1 | 0% (0 of 4) |
| Opponent | Beastmen Brayherds | 5 | 0 | 0 | 3 (net +47) | 1 (net +15) | 0 | 1 (net +65) | 0 | 60% (3 of 5) |
| Opponent | Dwarfen Mountain Holds | 2 | 1 (net +0) | 0 | 0 | 0 | 0 | 1 (net +112) | 0 | 0% (0 of 2) |
| Opponent | Empire of Man | 2 | 0 | 0 | 1 (net -265) | 0 | 0 | 0 | 1 | 100% (1 of 1) |
| Opponent | Grand Cathay | 3 | 1 (net +95) | 0 | 1 (net +613) | 1 (net +105) | 0 | 0 | 0 | 33% (1 of 3) |
| Opponent | High Elf Realms | 5 | 0 | 0 | 1 (net +227) | 1 (net +97) | 0 | 2 (net +52) | 1 | 25% (1 of 4) |
| Opponent | Lizardmen | 4 | 2 (net +48) | 0 | 0 | 0 | 0 | 0 | 2 | 0% (0 of 2) |
| Opponent | Ogre Kingdoms | 9 | 0 | 0 | 2 (net +476) | 3 (net -62) | 0 | 1 (net +65) | 3 | 33% (2 of 6) |
| Opponent | Orc & Goblin Tribes | 9 | 1 (net +219) | 0 | 0 | 0 | 0 | 0 | 8 | 0% (0 of 1) |
| Opponent | Tomb Kings of Khemri | 20 | 1 (net +499) | 1 (net -540) | 5 (net +6) | 8 (net +278) | 0 | 4 (net +229) | 1 | 26% (5 of 19) |
| Opponent | Vampire Counts | 24 | 3 (net +87) | 2 (net +98) | 5 (net +109) | 6 (net +94) | 0 | 7 (net +232) | 1 | 22% (5 of 23) |
| Opponent | Warriors of Chaos | 8 | 1 (net +663) | 0 | 0 | 2 (net +93) | 0 | 3 (net +149) | 2 | 0% (0 of 6) |
| Opponent | Wood Elf Realms | 14 | 2 (net +0) | 2 (net +222) | 2 (net -320) | 3 (net +30) | 0 | 5 (net +106) | 0 | 14% (2 of 14) |

### Charged fights, damage counted: jc-mine-1e5408d-p1

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 16 | 243 | 223 | +81 | 155 | 43 | +112 | +46.1 |
| Mine | Effective (55-75%) | 7 | 344 | 170 | +85 | 148 | 75 | +73 | +21.2 |
| Mine | 76-89% | 19 | 246 | 186 | +98 | 120 | 60 | +60 | +24.3 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 27 | 261 | 183 | +123 | 155 | 25 | +130 | +49.7 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 15 | 522 | 128 | +80 | 139 | 81 | +58 | +11.2 |
| Mine | No odds | 14 | 272 | 194 | +30 | 59 | 42 | +17 | +6.3 |
| Mine | All fights | 98 | 302 | 182 | +89 | 132 | 49 | +82 | +27.2 |
| Opponent | Long shot (under 50%) | 12 | 300 | 314 | +153 | 186 | 52 | +135 | +44.9 |
| Opponent | 50-54% | 5 | 341 | 278 | +20 | 147 | 163 | -16 | -4.5 |
| Opponent | Effective (55-75%) | 20 | 212 | 178 | +80 | 155 | 76 | +79 | +37.3 |
| Opponent | 76-89% | 25 | 222 | 152 | +124 | 170 | 42 | +129 | +58.0 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 24 | 375 | 215 | +161 | 199 | 48 | +151 | +40.2 |
| Opponent | No odds | 19 | 214 | 228 | +23 | 109 | 113 | -4 | -1.9 |
| Opponent | All fights | 105 | 268 | 210 | +104 | 164 | 69 | +94 | +35.1 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| jc-mine-1e5408d-p1 | move | 360 | 89 (25%) | 62 (17%) | 51 (14%) | 220 (61%) |
| jc-mine-1e5408d-p1 | objective | 397 | 54 (14%) | 38 (10%) | 56 (14%) | 287 (72%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0102, L0118, L0135, L2531, L2730 |
| Charmed Shield | Opponent | L0524, L1224, L1527, L1625, L2025, L2127, L2934 |
| Clockwork Compass | Mine | L1224 |
| Clockwork Compass | Opponent | L0612 |
| Elixir of Power | Mine | L1114, L1131, L1923 |
| Elixir of Power | Opponent | L0319, L1319 |
| Fistful of Laurels | Mine | L1823 |
| Fistful of Laurels | Opponent | L0118, L0218 |
| Horn of the Wild Hunt | Opponent | L0733 |
| Invocation of Nehek | Mine | L2531, L2730 |
| Invocation of Nehek | Opponent | L0524, L1224, L1527, L1625, L2025, L2127 |
| Opal Amulet | Mine | L1431 |
| Opal Amulet | Opponent | L1114 |
| Periapt of Soul Exchange | Mine | L2025, L2127 |
| Periapt of Soul Exchange | Opponent | L0421, L1021 |
| Ring of Doom | Mine | L0218, L0235, L1114, L1131, L1224, L1527 |
| Ring of Doom | Opponent | L0102, L0612, L0733, L1131, L1431, L2231, L2531 |
| Ring of Jet | Mine | L1021, L1114, L1131, L1224 |
| Ring of Jet | Opponent | L0612 |
| Standard of the Fell Warrior | Mine | L1319, L1335 |
| Standard of the Fell Warrior | Opponent | L0913 |
| Storm Daemon (Renegade 2.0) | Mine | L2127 |
| Storm Daemon (Renegade 2.0) | Opponent | L0421, L1021 |
| Twice-Blessed Armour | Mine | L0717, L0733, L1021 |
| Witch Hunter's Ward | Mine | L0717, L0733, L0823 |
| Witch Hunter's Ward | Opponent | L0508 |

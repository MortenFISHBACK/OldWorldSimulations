# Doctrine scorecard: jc-opp-1e5408d-p2

### Scorecard: jc-opp-1e5408d-p2

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0106 | 4 | 1 | Mine | no | 4 | 5 | 1 | 3 | 0 | 0 | 0 | 322 |
| L0106 | 4 | 1 | Opponent | no | 0 | 2 | 2 | 2 | 0 | 0 | 0 | 981 |
| L0122 | 2 | 1 | Mine | - | - | 6 | 1 | 2 | 1 | 0 | 0 | 317 |
| L0122 | 2 | 1 | Opponent | - | - | 2 | 1 | 1 | 0 | 0 | 0 | 72 |
| L0206 | 2 | 1 | Mine | - | - | - | 1 | 5 | 0 | 0 | 0 | 0 |
| L0206 | 2 | 1 | Opponent | - | - | 1 | 1 | 1 | 0 | 0 | 0 | 615 |
| L0222 | 6 | 1 | Mine | no | 4 | 2 | 3 | 3 | 0 | 0 | 0 | 200 |
| L0222 | 6 | 1 | Opponent | no | 14 | 3 | 1 | 0 | 0 | 0 | 0 | 55 |
| L0307 | 1 | 1 | Mine | yes | 2 | 3 | 2 | 2 | 0 | 0 | 0 | 675 |
| L0307 | 1 | 1 | Opponent | yes | 5 | 2 | 0 | 0 | 0 | 0 | 0 | 420 |
| L0323 | 5 | 1 | Mine | no | - | 6 | 1 | 2 | 0 | 0 | 0 | 760 |
| L0323 | 5 | 1 | Opponent | yes | - | 2 | 3 | 2 | 0 | 0 | 0 | 0 |
| L0409 | 1 | 1 | Mine | no | 4 | 2 | 3 | 2 | 1 | 0 | 0 | 0 |
| L0409 | 1 | 1 | Opponent | no | 3 | - | 0 | 0 | 0 | 0 | 0 | 537 |
| L0425 | 5 | 1 | Mine | yes | - | 2 | 6 | 1 | 0 | 0 | 0 | 0 |
| L0425 | 5 | 1 | Opponent | yes | - | 4 | 3 | 4 | 0 | 0 | 0 | 0 |
| L0512 | 2 | 1 | Mine | - | - | - | 0 | 2 | 0 | 0 | 0 | 966 |
| L0512 | 2 | 1 | Opponent | - | - | 2 | 0 | 1 | 2 | 0 | 0 | 330 |
| L0528 | 6 | 1 | Mine | no | 0 | 4 | 1 | 1 | 0 | 0 | 0 | 475 |
| L0528 | 6 | 1 | Opponent | no | 8 | 5 | 1 | 2 | 0 | 0 | 0 | 0 |
| L0616 | 4 | 1 | Mine | no | 2 | 2 | 2 | 1 | 0 | 0 | 0 | 615 |
| L0616 | 4 | 1 | Opponent | no | 0 | 3 | 1 | 0 | 1 | 0 | 0 | 200 |
| L0632 | 2 | 1 | Mine | - | - | 2 | 1 | 0 | 0 | 0 | 0 | 926 |
| L0632 | 2 | 1 | Opponent | - | - | 2 | 5 | 4 | 1 | 0 | 0 | 0 |
| L0721 | 1 | 1 | Mine | yes | 3 | 2 | 2 | 0 | 1 | 0 | 0 | 558 |
| L0721 | 1 | 1 | Opponent | yes | 3 | - | 1 | 3 | 1 | 0 | 0 | 145 |
| L0810 | 6 | 1 | Mine | no | 0 | 3 | 1 | 3 | 0 | 0 | 0 | 864 |
| L0810 | 6 | 1 | Opponent | no | 5 | 2 | 1 | 0 | 1 | 0 | 0 | 330 |
| L0827 | 5 | 1 | Mine | no | - | 6 | 1 | 1 | 0 | 0 | 0 | 769 |
| L0827 | 5 | 1 | Opponent | yes | - | 2 | 7 | 5 | 0 | 0 | 0 | 0 |
| L0918 | 6 | 1 | Mine | no | 1 | 2 | 0 | 0 | 0 | 0 | 0 | 420 |
| L0918 | 6 | 1 | Opponent | no | 15 | 2 | 7 | 1 | 0 | 0 | 0 | 419 |
| L0934 | 4 | 1 | Mine | no | 0 | 3 | 0 | 1 | 0 | 0 | 0 | 827 |
| L0934 | 4 | 1 | Opponent | no | 0 | 2 | 2 | 4 | 1 | 0 | 0 | 160 |
| L1026 | 6 | 1 | Mine | no | 0 | 2 | 2 | 0 | 0 | 0 | 0 | 330 |
| L1026 | 6 | 1 | Opponent | no | 2 | 3 | 3 | 3 | 0 | 0 | 0 | 0 |
| L1118 | 2 | 1 | Mine | - | - | 2 | 4 | 0 | 1 | 0 | 0 | 330 |
| L1118 | 2 | 1 | Opponent | - | - | 5 | 3 | 3 | 1 | 0 | 0 | 225 |
| L1135 | 1 | 1 | Mine | yes | 0 | 5 | 0 | 0 | 0 | 0 | 0 | 330 |
| L1135 | 1 | 1 | Opponent | yes | 2 | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L1228 | 4 | 1 | Mine | no | 4 | 4 | 2 | 1 | 0 | 0 | 0 | 330 |
| L1228 | 4 | 1 | Opponent | no | 3 | 2 | 3 | 1 | 0 | 0 | 0 | 111 |
| L1323 | 3 | 1 | Mine | no | 5 | 5 | 2 | 1 | 2 | 0 | 0 | 140 |
| L1323 | 3 | 1 | Opponent | no | 1 | 2 | 4 | 0 | 0 | 0 | 0 | 0 |
| L1418 | 2 | 1 | Mine | - | - | 2 | 3 | 2 | 1 | 0 | 0 | 0 |
| L1418 | 2 | 1 | Opponent | - | - | - | 3 | 2 | 1 | 0 | 0 | 305 |
| L1435 | 1 | 1 | Mine | no | 0 | 2 | 2 | 0 | 0 | 0 | 0 | 0 |
| L1435 | 1 | 1 | Opponent | no | 0 | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L1531 | 1 | 1 | Mine | no | 0 | 3 | 4 | 0 | 1 | 0 | 0 | 0 |
| L1531 | 1 | 1 | Opponent | no | 5 | 4 | 3 | 0 | 1 | 0 | 0 | 340 |
| L1629 | 3 | 1 | Mine | no | 1 | 1 | 2 | 2 | 0 | 0 | 0 | 536 |
| L1629 | 3 | 1 | Opponent | no | 0 | 2 | 2 | 2 | 0 | 0 | 0 | 170 |
| L1727 | 5 | 1 | Mine | yes | - | 4 | 3 | 0 | 1 | 0 | 0 | 0 |
| L1727 | 5 | 1 | Opponent | no | - | 2 | 3 | 3 | 0 | 0 | 0 | 0 |
| L1827 | 3 | 1 | Mine | no | 0 | - | 1 | 0 | 1 | 0 | 0 | 413 |
| L1827 | 3 | 1 | Opponent | no | 6 | 2 | 2 | 3 | 0 | 0 | 0 | 0 |
| L1927 | 1 | 1 | Mine | no | 1 | 1 | 2 | 0 | 1 | 0 | 0 | 0 |
| L1927 | 1 | 1 | Opponent | no | 2 | 2 | 1 | 1 | 0 | 0 | 0 | 190 |
| L2029 | 1 | 1 | Mine | no | 0 | - | 2 | 1 | 2 | 0 | 0 | 420 |
| L2029 | 1 | 1 | Opponent | no | 0 | 3 | 3 | 1 | 0 | 0 | 0 | 0 |
| L2131 | 1 | 1 | Mine | yes | 2 | - | 2 | 3 | 0 | 0 | 0 | 145 |
| L2131 | 1 | 1 | Opponent | no | 1 | 4 | 2 | 1 | 1 | 0 | 0 | 170 |
| L2235 | 3 | 1 | Mine | no | 0 | 2 | 2 | 0 | 0 | 0 | 0 | 0 |
| L2235 | 3 | 1 | Opponent | no | 0 | 2 | 2 | 0 | 1 | 0 | 0 | 126 |
| L2429 | 5 | 1 | Mine | yes | - | - | 1 | 2 | 0 | 0 | 0 | 0 |
| L2429 | 5 | 1 | Opponent | yes | - | 3 | 4 | 3 | 0 | 0 | 0 | 0 |
| L2535 | 3 | 1 | Mine | no | 9 | 3 | 1 | 1 | 0 | 0 | 0 | 0 |
| L2535 | 3 | 1 | Opponent | no | 0 | 1 | 4 | 0 | 0 | 0 | 0 | 0 |
| L2735 | 5 | 1 | Mine | yes | - | 4 | 1 | 5 | 1 | 0 | 0 | 0 |
| L2735 | 5 | 1 | Opponent | yes | - | 3 | 1 | 4 | 0 | 0 | 0 | 0 |
| L3033 | 3 | 1 | Mine | yes | 5 | 4 | 3 | 0 | 0 | 0 | 0 | 0 |
| L3033 | 3 | 1 | Opponent | no | 2 | 1 | 7 | 2 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 30% | 2.0 | 3.1 | 1.8 | 1.3 | 0.4 | 0.0 | 0.0 | 324.1 |
| **Average** | | | Opponent | 27% | 3.2 | 2.5 | 2.6 | 1.7 | 0.3 | 0.0 | 0.0 | 163.9 |

### KPIs: jc-opp-1e5408d-p2

Rules off - Mine only: SECOND CHARGER ADDS.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 25% (44 of 173) | 19% (33 of 175) | 22% (77 of 348) |
| Winner chose to follow up after the loser gave ground |  | 98% (52 of 53); on the table 100% | 98% (44 of 45); on the table 98% | 98% (96 of 98); on the table 99% |
| Winner chose to pursue after the loser fell back in good order |  | 78% (7 of 9); on the table 78% | 82% (14 of 17); on the table 88% | 81% (21 of 26); on the table 85% |
| Winner chose to pursue after the loser fled |  | 82% (14 of 17); on the table 88% | 80% (20 of 25); on the table 88% | 81% (34 of 42); on the table 88% |
| Winner chose to follow up or pursue (all three) |  | 92% (73 of 79); on the table 95% | 90% (78 of 87); on the table 93% | 91% (151 of 166); on the table 94% |
| Magic missiles tried each own turn | 50%+ | 33% (114 of 342) | 40% (63 of 156) | 36% (177 of 498) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 50% (114 of 228) | 55% (63 of 115) | 52% (177 of 343) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 52% (14 of 27) | 62% (30 of 48) | 59% (44 of 75) |
| Points that never fought | lower | 39% (28070 of 71583) | 45% (32371 of 71989) | 42% (60441 of 143572) |
|   infantry points that never fought | lower | 49% (8051 of 16324) | 61% (8546 of 14029) | 55% (16597 of 30353) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 59% (167 of 284) | 60% (178 of 297) | 59% (345 of 581) |
| Bound items with a magic missile used (at least once a game) |  | 90% (18 of 20); 1.6 uses a game | 78% (14 of 18); 1.2 uses a game | 84% (32 of 38); 1.4 uses a game |
| Bound items with another spell used |  | 44% (8 of 18); 0.5 uses a game | 0% (0 of 2); 0.0 uses a game | 40% (8 of 20); 0.3 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 50% (10 of 20); 0.3 uses a game | 29% (2 of 7); 0.1 uses a game | 44% (12 of 27); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 54% (32791 of 60231) | 57% (36133 of 63281) | 56% (68924 of 123512) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.7 (26%) | 0.6 (23%) | 2.2 (25%) |
| MARCHED: its unit marched | 0.9 (14%) | 0.4 (16%) | 1.3 (15%) |
| CHARGED: its unit charged | 0.1 (2%) | 0.1 (2%) | 0.2 (2%) |
| IN COMBAT: engaged in combat | 1.3 (21%) | 0.4 (17%) | 1.8 (20%) |
| REAR RANK: in a rear rank | 0.1 (2%) | 0.1 (5%) | 0.3 (3%) |
| FLEEING: fleeing | 0.1 (2%) | 0.0 (0%) | 0.1 (1%) |
| GONE: slain | 1.2 (20%) | 0.6 (25%) | 1.9 (21%) |
| OFF THE TABLE: off the table or not arrived | 0.5 (7%) | 0.1 (2%) | 0.5 (6%) |
| STUPIDITY: Stupidity | 0.2 (3%) | 0.0 (1%) | 0.2 (2%) |
| NOT OFFERED: not in the cast list | 0.1 (2%) | 0.2 (9%) | 0.4 (4%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.0 | 1.6 | 1.1 | 4.9 | 0.4 | 1.5 |
| not cast | 3.8 | 3.3 | 3.9 | 8.9 | 1.9 | 20.1 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.1 (2%) | 0.0 (0%) | 0.0 (0%) | 1.1 (5%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.3 (40%) | 0.3 (7%) | 2.2 (25%) | 0.4 (24%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.3 (15%) | 0.2 (13%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (2%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.1 (4%) | 0.3 (10%) | 0.6 (15%) | 1.8 (20%) | 0.2 (10%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.3 (9%) | 0.3 (10%) | 0.4 (9%) | 0.3 (3%) | 0.0 (0%) | 0.0 (0%) |
| NO CASTS LEFT: every cast used on other spells | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (7%) | 0.0 (0%) |
| FLEEING: fleeing | 0.1 (2%) | 0.2 (5%) | 0.1 (2%) | 0.1 (1%) | 0.1 (4%) | 0.4 (2%) |
| GONE: slain | 0.5 (14%) | 0.6 (19%) | 0.5 (13%) | 1.9 (21%) | 0.4 (22%) | 3.8 (19%) |
| OFF THE TABLE: off the table or not arrived | 0.4 (10%) | 0.3 (8%) | 0.2 (5%) | 0.5 (6%) | 0.1 (4%) | 0.7 (3%) |
| STUPIDITY: Stupidity | 0.1 (4%) | 0.0 (1%) | 0.1 (3%) | 0.2 (2%) | 0.0 (0%) | 0.6 (3%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (2%) | 0.2 (5%) | 0.0 (0%) | 0.0 (0%) | 0.3 (15%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.4 (4%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.1 (56%) | 0.1 (2%) | 1.7 (43%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 13.6 (68%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.5 a game | 0.7 a game | 0.6 a game |
| stood (cast and not dispelled) | 69% (11 of 16) | 50% (12 of 24) | 58% (23 of 40) |
| the unit moved after it | 73% (8 of 11) | 42% (5 of 12) | 57% (13 of 23) |
| it charged on its next turn | 9% (1 of 11) | 0% (0 of 12) | 4% (1 of 23) |
| the enemy charged it first | 9% (1 of 11) | 8% (1 of 12) | 9% (2 of 23) |
| it fought by the end of its next turn | 9% (1 of 11) | 8% (1 of 12) | 9% (2 of 23) |
| it moved out of a charge the enemy had planned (not charged first) | 9% (1 of 11) | 8% (1 of 12) | 9% (2 of 23) |
| none of these (no charge, no fight, no charge escaped) | 73% (8 of 11) | 83% (10 of 12) | 78% (18 of 23) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 67% (571 of 854) | 56% (438 of 779) | 62% (1009 of 1633) |
|   cavalry | 58% (43 of 74) | 63% (105 of 167) | 61% (148 of 241) |
|   character | 55% (57 of 104) | 32% (31 of 96) | 44% (88 of 200) |
|   chariot | 58% (60 of 103) | 56% (27 of 48) | 58% (87 of 151) |
|   infantry | 60% (160 of 266) | 56% (170 of 303) | 58% (330 of 569) |
|   monster | 40% (18 of 45) | 56% (20 of 36) | 47% (38 of 81) |
|   war machine | 89% (233 of 262) | 66% (85 of 129) | 81% (318 of 391) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.2 (28%) | 2.1 (23%) | 4.3 (25%) |
| CHARGED: it charged | 1.2 (15%) | 1.7 (18%) | 2.9 (17%) |
| FLEEING: it fled or was fleeing | 0.1 (1%) | 0.1 (1%) | 0.2 (1%) |
| IN COMBAT: it fought this turn or the last | 0.8 (11%) | 0.5 (5%) | 1.3 (8%) |
| MOVED: a war machine that moved | 0.1 (1%) | 0.0 (0%) | 0.1 (0%) |
| NO TARGET IN RANGE | 1.3 (17%) | 1.9 (20%) | 3.2 (19%) |
| ONLY IN COMBAT: the only targets were in combat | 0.6 (7%) | 0.5 (5%) | 1.0 (6%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.2 (16%) | 1.8 (19%) | 3.0 (17%) |
| SHELTERED: the target was sheltered | 0.2 (2%) | 0.2 (3%) | 0.4 (3%) |
| STUPIDITY | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR | 0.2 (3%) | 0.6 (6%) | 0.8 (5%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 6.0 | 1.3 | 82% | 4.2 pts | 25 pts |
| character | 2.5 | 0.7 | 78% | 7.7 pts | 19 pts |
| chariot | 2.4 | 1.8 | 66% | 15.0 pts | 36 pts |
| infantry | 12.5 | 5.4 | 68% | 10.6 pts | 132 pts |
| monster | 1.2 | 0.3 | 82% | 7.2 pts | 9 pts |
| war machine | 8.8 | 7.2 | 59% | 26.4 pts | 234 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.9 | 5.0 | 4.4 |
| Charges that made contact a game | 3.0 | 3.7 | 3.3 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.52 declared, 0.44 contact (25 units) | 0.58 declared, 0.58 contact (12 units) | 0.54 declared, 0.49 contact (37 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.62 declared, 0.38 contact (8 units) | 1.00 declared, 1.00 contact (10 units) | 0.83 declared, 0.72 contact (18 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.50 declared, 0.38 contact (244 units) | 0.56 declared, 0.40 contact (290 units) | 0.53 declared, 0.39 contact (534 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 49% (36 of 73) | 61% (11 of 18) | 50% (6 of 12) | 51% (53 of 103) |
| Character in a unit | 86% (30 of 35) | 76% (13 of 17) | 80% (4 of 5) | 82% (47 of 57) |
| Character on its own | 81% (30 of 37) | 68% (25 of 37) | 33% (20 of 61) | 56% (75 of 135) |
| Chariot | 71% (12 of 17) | 62% (8 of 13) | - | 67% (20 of 30) |
| Infantry | 49% (46 of 94) | 65% (22 of 34) | 33% (1 of 3) | 53% (69 of 131) |
| Monster | 52% (15 of 29) | 67% (6 of 9) | - | 55% (21 of 38) |
| Monstrous | 50% (7 of 14) | 71% (10 of 14) | - | 61% (17 of 28) |
| War Machines | 72% (41 of 57) | 100% (2 of 2) | - | 73% (43 of 59) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 100% (11 of 11); on the table 100% | 36% (37 of 102) | 52% | 73% (16 of 22) | 83% (5 of 6); 4.2 uses a game | 50% (1 of 2); 0.8 uses a game | 83% (5 of 6); 1.2 uses a game |
| Chaos Dwarfs | 4 | 75% (6 of 8); on the table 75% | 47% (17 of 36) | 43% | 59% (19 of 32) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
| Dwarfen Mountain Holds | 6 | 92% (12 of 13); on the table 92% | - | 68% | 74% (40 of 54) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 7 | 86% (12 of 14); on the table 93% | 35% (17 of 48) | 39% | 61% (46 of 76) | 0.0 uses a game | 50% (1 of 2); 0.4 uses a game | 0% (0 of 4); 0.0 uses a game |
| Grand Cathay | 6 | 100% (7 of 7); on the table 100% | 33% (45 of 138) | 42% | 48% (26 of 54) | 93% (13 of 14); 6.2 uses a game | 0% (0 of 2); 0.0 uses a game | 17% (1 of 6); 0.2 uses a game |
| High Elf Realms | 4 | 100% (9 of 9); on the table 100% | 22% (4 of 18) | 22% | 48% (16 of 33) | 100% (3 of 3); 1.8 uses a game | 43% (6 of 14); 3.2 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 2 | 33% (1 of 3); on the table 33% | - | 40% | 58% (7 of 12) | 0.0 uses a game | 0.0 uses a game | 100% (2 of 2); 1.0 uses a game |
| Lizardmen | 1 | 100% (4 of 4); on the table 100% | - | 22% | 43% (3 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 4 | 100% (14 of 14); on the table 100% | 6% (1 of 18) | 47% | 79% (22 of 28) | 100% (4 of 4); 3.5 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 1 | 100% (1 of 1); on the table 100% | 0% (0 of 12) | 0% | 38% (3 of 8) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Skaven | 3 | 50% (4 of 8); on the table 75% | 28% (5 of 18) | 39% | 48% (12 of 25) | 100% (2 of 2); 2.0 uses a game | 0.0 uses a game | 67% (2 of 3); 0.7 uses a game |
| Tomb Kings of Khemri | 5 | 100% (7 of 7); on the table 100% | - | 51% | 28% (7 of 25) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 9 | 93% (27 of 29); on the table 97% | 44% (29 of 66) | 37% | 67% (36 of 54) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 9 | 95% (18 of 19); on the table 100% | 28% (5 of 18) | 35% | 56% (41 of 73) | 100% (2 of 2); 0.9 uses a game | 0.0 uses a game | 100% (1 of 1); 0.1 uses a game |
| Wood Elf Realms | 7 | 95% (18 of 19); on the table 95% | 71% (17 of 24) | 46% | 65% (51 of 78) | 43% (3 of 7); 1.6 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (jc-opp-1e5408d-p2, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 47% (39) | 48% (36) | 47% (75) |
| ...free all their last turn and able to turn (per game) | 0.61 | 0.67 | 1.28 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.28 | 0.14 | 0.42 |
| ...with the charger already in that arc before they moved (per game) | 0.44 | 0.39 | 0.83 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 1.58 | 1.50 | 3.08 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 1.17 | 0.67 | 1.83 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 5.44 | 5.56 | 11.00 |

### Quality by phase: jc-opp-1e5408d-p2

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.8 | 3.3 |
| Strategy | Charge objectives carried out (made contact) | 55% (70 of 127) | 48% (84 of 175) |
| Strategy | Shoot objectives carried out (shot that target) | 35% (131 of 376) | 48% (125 of 259) |
| Strategy | Close-in objectives charged next turn | 17% (27 of 155) | 15% (38 of 259) |
| Strategy | Support requests answered (helper made contact too) | 75% (12 of 16) | 30% (14 of 46) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 50% (1 of 2) | 25% (1 of 4) |
| Strategy | Hexes on a unit its side charged or shot that turn | 60% (9 of 15) | 53% (8 of 15) |
| Strategy | Joined characters whose unit fought | 23% (11 of 48) | 40% (18 of 45) |
| Strategy | Lone characters that fought | 78% (76 of 97) | 63% (49 of 78) |
| Movement | Charges halted short of contact | 0.2 | 0.0 |
| Movement | Idle units | 1.3 | 1.7 |
| Movement | Points that never moved of their own | 324.1 | 163.9 |
| Movement | Fights charged into per game | 2.6 | 3.2 |
| Movement | Charges with odds: long shots (under 50%) | 11 of 88, net -4 | 23 of 102, net +142 |
| Movement | Charges with odds: sweet spot (55-75%) | 21 of 88, net +146 | 16 of 102, net +177 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 11 of 88, net +52 | 3 of 102, net +94 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 24 of 88, net +91 | 26 of 102, net +81 |
| Shooting | Shots by shooting units (incl. breath weapons) | 10.1 | 10.8 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 39% (142 of 364) | 43% (167 of 389) |
| Shooting | Points destroyed by shooting units | 135.2 | 48.0 |
| Shooting | War machine shots | 6.5 | 2.4 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 57% (132 of 233) | 45% (38 of 85) |
| Shooting | Points destroyed by war machines | 70.9 | 59.0 |
| Magic | Magic missiles cast | 2.0 | 1.2 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 32% (23 of 73) | 36% (15 of 42) |
| Magic | Wounds caused by magic missiles | 3.9 | 1.8 |
| Magic | Wounds caused by other spells | 1.4 | 0.9 |
| Magic | Points destroyed by magic (all spells) | 61.9 | 31.6 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.1 / 0.5 / 0.6 / 0.1 | 2.0 / 0.4 / 0.3 / 0.2 |
| Combat | Points destroyed in combat | 296.1 | 333.2 |
| Combat | Points run down | 32.7 | 111.2 |
| Combat | Net points per charged fight, damage counted | +75 | +116 |
| Combat | Net per 100 charger points, damage counted | +28.9 | +46.5 |
| Combat | First round won (charged fights) | 77% | 75% |
| Combat | Net points per charged fight | +76 | +122 |
| Combat | Net points per supported fight / lone fight | +100 / +73 | +124 / +121 |
| Combat | Charged fights on a top-3 enemy unit | 32 of 95 | 45 of 116 |
| Game | Points lost | 796.6 | 684.7 |
| Game | VP from objectives | 502.5 | 652.2 |
| Game | Lone holders (player turns) | 2.0 | 3.2 |

- Mine won / drew / lost: 10 / 7 / 19 of 36 ended games (of 36); mean margin (Mine - Opponent) -249 VP
- The side that went first won 17 of 29 games with a winner
- Points traded per game (both sides' losses): 1481
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: jc-opp-1e5408d-p2

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 0.5 | +0.0 | 0.0 | 0.0 |
| ADVANCE WORTH | 5.8 | -170.6 | 192.0 | 95.9 | 5.2 | -204.5 | 160.9 | 50.6 |
| ARRIVAL HUNT | - | - | - | - | 0.1 | +4.3 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.2 | +0.0 | 0.0 | 31.7 | 0.2 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | 0.7 | +3.3 | 0.0 | 20.8 | 0.6 | +4.3 | 0.0 | 27.7 |
| BEST FACING | 0.4 | +13.6 | 0.0 | 19.3 | 0.3 | +13.1 | 0.0 | 26.1 |
| BEST FIRST | 1.3 | +72.4 | 17.3 | 19.7 | 1.1 | +28.7 | 21.2 | 19.8 |
| BEST OVERALL | 0.4 | +20.9 | 0.0 | 22.7 | 0.4 | +17.4 | 0.0 | 19.4 |
| BEST PREY | 0.9 | +58.0 | 48.2 | 22.8 | 0.6 | +45.5 | 23.7 | 5.1 |
| BEST PRIZE | 0.0 | -0.0 | 0.0 | 0.0 | 0.1 | -3.8 | 6.8 | 16.6 |
| BIG CHARACTER SAFETY | 0.2 | +0.4 | 0.0 | 32.5 | 0.0 | -0.0 | 0.0 | 0.0 |
| BLOCKED CHARGE SKIPPED | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 7.1 | 0.0 |
| BLOCKED WHEEL | 0.3 | +5.0 | 0.0 | 0.0 | 0.7 | +17.4 | 0.0 | 23.7 |
| BLOWS WHERE AIMED | 0.2 | -11.5 | 22.1 | 16.6 | 0.2 | -23.4 | 21.0 | 19.6 |
| BOMBING RUN | 0.1 | +3.9 | 0.0 | 0.0 | - | - | - | - |
| BOUND ASSAILMENT | 0.1 | +0.0 | 0.0 | 6.8 | - | - | - | - |
| CANNON PLAN MISSED | 0.7 | +0.0 | 136.5 | 18.6 | 0.1 | +0.0 | 2.9 | 0.0 |
| CANNON PLANNED TARGET | 4.8 | +201.9 | 480.5 | 94.9 | 2.0 | +87.0 | 150.5 | 3.5 |
| CANNON SIGHT KEPT | 1.3 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT COUNTER | 0.1 | +0.0 | 2.5 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT SET-UP | 0.1 | +0.0 | 10.9 | 0.0 | 0.2 | +0.0 | 47.7 | 12.1 |
| CAST JOB | 0.9 | +19.4 | 48.7 | 22.1 | 0.5 | +11.4 | 33.8 | 14.9 |
| CASTER AWAY FROM SCREEN | 0.3 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.6 | +33.2 | 25.6 | 7.6 | 0.3 | +13.8 | 16.9 | 0.0 |
| CASTS AFTER FRIENDS | 0.3 | +0.0 | 0.0 | 2.6 | 0.3 | +0.0 | 0.0 | 16.5 |
| CASTS FROM BEHIND | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.1 | +2.4 | 0.0 | 0.0 | - | - | - | - |
| CATCH ODDS | 0.0 | +0.7 | 0.0 | 0.0 | 0.0 | +0.4 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | 0.9 | +56.4 | 0.0 | 21.6 | 1.8 | +92.0 | 0.0 | 47.6 |
| CHAFF PASSED | 0.1 | -0.2 | 0.0 | 4.5 | 0.4 | -0.4 | 0.0 | 16.0 |
| CHARGE NOW FIRST | 2.4 | +0.0 | 274.3 | 97.7 | 2.5 | +0.0 | 328.7 | 96.6 |
| CHARGE NOW WEIGHED | 0.5 | -27.0 | 19.7 | 11.7 | 0.5 | -61.8 | 18.0 | 36.2 |
| CHARGER SLAIN LOST | 0.5 | -5.3 | 88.5 | 11.8 | 0.6 | -7.1 | 56.6 | 10.1 |
| CHARIOT NO STATIC JOB | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHARIOT WIZARD CAREFUL | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHEAP HELPER | 0.1 | +0.0 | 0.0 | 1.7 | - | - | - | - |
| COMBAT PIVOT | 0.2 | +0.0 | 1.7 | 27.6 | 0.3 | +0.0 | 2.4 | 19.6 |
| CONTINUE AHEAD WEIGHED | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | 0.4 | +44.0 | 13.9 | 16.5 | 0.6 | +49.7 | 29.0 | 29.4 |
| COVER ONCE | 8.8 | -658.9 | 0.0 | 220.8 | 7.6 | -573.7 | 0.0 | 199.1 |
| DEFENSIVE ARMY | 0.4 | +0.0 | 44.8 | 8.7 | 0.1 | +0.0 | 15.1 | 0.0 |
| DEFENSIVE FLOOR | 0.1 | +1.8 | 4.7 | 5.2 | - | - | - | - |
| EDGE GIVE GROUND | 0.1 | +1.8 | 13.5 | 0.0 | 0.4 | +9.1 | 31.3 | 5.1 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 1.6 | +99.4 | 0.0 | 47.5 | 1.5 | +129.3 | 0.0 | 57.5 |
| FALLBACK BY WORTH | 4.2 | +42.1 | 0.0 | 59.2 | 5.6 | +37.3 | 0.0 | 61.4 |
| FIGHT LIFT | 0.0 | +0.2 | 2.9 | 0.0 | 0.1 | +3.7 | 0.0 | 0.0 |
| FIRE AND FLEE | 0.0 | +3.0 | 0.0 | 0.0 | 0.0 | +0.2 | 0.0 | 2.2 |
| FLANK NOT WEIGHED | 5.3 | +0.0 | 0.0 | 134.8 | 4.9 | +0.0 | 0.0 | 185.6 |
| FOCUS FIRE | 0.1 | +4.9 | 3.1 | 0.0 | 0.0 | +0.4 | 1.5 | 0.0 |
| FOLLOW UP WEIGHED | 0.8 | +104.9 | 0.0 | 57.1 | 1.0 | +117.1 | 0.0 | 22.9 |
| FRIEND IN REACH | 3.7 | +44.3 | 373.8 | 119.3 | 5.2 | +107.7 | 560.9 | 127.7 |
| FRIENDS SHOTS CHECKED | 0.2 | +15.1 | 0.0 | 8.8 | 0.2 | +8.5 | 0.0 | 16.7 |
| GIVES UP | - | - | - | - | 0.1 | -1.6 | 22.6 | 0.0 |
| GIVES UP ITS SCREEN | 0.0 | -0.2 | 5.4 | 0.0 | 0.1 | -0.5 | 3.4 | 0.0 |
| HELPER ALREADY ASKED | 0.1 | +0.0 | 8.1 | 6.8 | 0.0 | +0.0 | 3.1 | 0.0 |
| HELPER UNSEEN | 0.3 | +0.0 | 47.3 | 8.6 | 0.6 | +0.0 | 26.2 | 7.6 |
| HILL BY ITS CHANCE | 0.4 | -43.1 | 0.0 | 6.5 | 0.7 | -74.9 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 7.2 | -109.8 | 326.2 | 134.2 | 10.5 | -225.8 | 753.4 | 338.6 |
| HORN WORTH | - | - | - | - | 0.0 | +0.1 | 0.0 | 0.0 |
| HUNT ADVANCE | 0.0 | +0.2 | 0.0 | 0.0 | 0.5 | +5.5 | 17.8 | 0.0 |
| HUNT DROPPED | - | - | - | - | 0.2 | +0.0 | 14.0 | 1.8 |
| HUNT IN PAIRS | 0.4 | +22.0 | 0.0 | 0.0 | 0.8 | +57.3 | 0.0 | 65.2 |
| HUNT KEPT | 0.1 | +0.5 | 10.8 | 0.0 | 0.4 | +5.6 | 15.0 | 0.0 |
| HUNT RESULT | 0.0 | +5.9 | 0.0 | 0.0 | 0.4 | +74.9 | 23.2 | 2.8 |
| HUNT THE GUNS | 0.0 | +6.5 | 0.0 | 0.0 | 0.5 | +149.0 | 31.1 | 1.8 |
| IDLE COST | 14.6 | -232.4 | 0.0 | 176.0 | 19.4 | -312.8 | 0.0 | 288.6 |
| INVITES THE FIGHT | 1.4 | +9.7 | 56.0 | 32.8 | 0.8 | +5.7 | 52.8 | 1.8 |
| JOINT CHARGE PLAN | 0.1 | +2.9 | 0.0 | 1.4 | 0.1 | +8.8 | 8.2 | 7.7 |
| JOINT KNOWS CHALLENGE | 0.1 | -2.4 | 0.0 | 6.8 | 0.1 | -0.4 | 4.5 | 0.0 |
| KEEP FALLS | 0.1 | +0.9 | 0.0 | 0.0 | - | - | - | - |
| KEEPS ITS PREY | 0.1 | +0.9 | 0.0 | 0.0 | 0.1 | +0.3 | 3.1 | 5.1 |
| KEEPS ITS TARGET | 1.2 | +35.8 | 130.6 | 49.3 | 2.5 | +74.2 | 207.0 | 65.4 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| KILLS COUNT | 1.6 | +89.8 | 147.6 | 27.1 | 2.1 | +90.7 | 236.6 | 48.0 |
| KILLS COUNT NEXT TURN | 5.0 | +195.8 | 151.3 | 80.2 | 7.2 | +268.5 | 402.0 | 272.0 |
| LONE CHARACTER SAFE SPOT | 0.3 | +7.1 | 4.1 | 0.0 | 0.2 | +12.0 | 10.9 | 21.8 |
| LONE WIZARD HOLDS BACK | 0.2 | +0.0 | 10.2 | 3.2 | 0.2 | +0.0 | 1.7 | 10.7 |
| LONE WIZARD KEPT IN | 0.6 | +39.4 | 0.0 | 0.0 | 0.3 | +23.5 | 0.0 | 0.0 |
| LONG SHOT | 0.9 | -5.6 | 57.6 | 22.0 | 0.7 | +3.9 | 39.1 | 9.1 |
| LOST CHARGE | 2.7 | -47.4 | 88.3 | 119.5 | 2.4 | -41.7 | 48.1 | 86.1 |
| LURE BY WHAT IT DRAWS | 0.1 | -13.0 | 0.0 | 1.2 | 0.2 | -19.6 | 0.0 | 12.9 |
| MAKE SURE TOGETHER | 0.3 | +9.7 | 5.1 | 13.4 | 0.8 | +59.0 | 49.7 | 8.1 |
| MANOEUVRE | 0.3 | +11.8 | 0.0 | 7.5 | 0.1 | +2.1 | 0.0 | 0.0 |
| MARCH AT ESCAPER | - | - | - | - | 0.1 | +1.4 | 0.0 | 4.4 |
| MARCH CHECK | 0.4 | +8.5 | 0.0 | 2.2 | 0.4 | +10.1 | 0.0 | 7.2 |
| MARCH ODDS | 0.2 | +7.7 | 0.0 | 7.6 | 0.1 | +5.5 | 0.0 | 0.0 |
| MARCH OVER CASTS | 0.4 | +46.4 | 0.0 | 29.7 | 0.2 | +18.1 | 0.0 | 16.4 |
| MAX FOR POSITIONING | 6.0 | +81.7 | 0.0 | 176.8 | 6.5 | +97.9 | 0.0 | 155.6 |
| MISSILES IN THE MOVE | 4.2 | +106.4 | 0.0 | 118.9 | 3.2 | +64.0 | 0.0 | 80.6 |
| MISSILES NEXT TURN | 4.7 | +72.2 | 0.0 | 151.9 | 3.6 | +43.7 | 0.0 | 109.1 |
| MODEL FACING | 0.2 | +53.7 | 0.0 | 3.3 | 0.3 | +98.1 | 0.0 | 5.0 |
| MONSTER WIZARD ROAMS | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 19.9 | 12.1 |
| MOVE AND CAST | 0.2 | +10.0 | 0.0 | 4.5 | 0.4 | +14.1 | 0.0 | 16.2 |
| MOVE SPELL IN RANGE | 0.2 | +9.1 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.3 | -12.1 | 0.0 | 32.2 | 0.3 | -6.5 | 0.0 | 0.0 |
| MOVE SPELL SPOT | 0.1 | +0.0 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE | 2.7 | +121.3 | 91.7 | 72.1 | 5.7 | +362.5 | 319.9 | 219.4 |
| MOVES UNITS SPELL | 0.1 | +3.4 | 0.0 | 0.0 | - | - | - | - |
| NEEDED THERE | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +8.6 | 9.7 | 0.0 |
| NOT NEEDED | 0.2 | -5.2 | 19.3 | 4.9 | - | - | - | - |
| NOT TURNED | 5.4 | +71.8 | 0.0 | 155.0 | 5.6 | +66.2 | 0.0 | 142.6 |
| NOT WORTH A CAST | 0.4 | -0.2 | 0.0 | 0.0 | 0.8 | -0.6 | 0.0 | 0.0 |
| OFF BEST | 15.7 | -656.5 | 12.9 | 238.9 | 17.4 | -807.9 | 5.2 | 237.9 |
| ONE FIGHT FORMULA | 9.0 | -142.1 | 49.1 | 233.9 | 9.2 | -186.3 | 43.2 | 296.6 |
| ONE OBJECTIVE FORMULA | 2.1 | -101.8 | 0.0 | 31.3 | 2.1 | -115.4 | 0.0 | 28.9 |
| OPENS A LANE | 0.2 | +1.4 | 18.2 | 3.5 | 0.1 | +0.2 | 4.0 | 0.0 |
| OPENS UP | 0.1 | +4.7 | 3.2 | 0.0 | 0.1 | +8.0 | 12.5 | 0.0 |
| OVERRUN THREAT | - | - | - | - | 0.0 | +0.7 | 0.0 | 0.0 |
| OVERRUNS AWAY | 0.4 | +3.7 | 48.0 | 8.0 | 0.8 | +19.7 | 64.1 | 46.6 |
| PAIR SET-UP | - | - | - | - | 0.2 | +0.0 | 0.0 | 0.0 |
| PATHS CROSS | 1.9 | +101.8 | 0.0 | 25.4 | 3.0 | +183.7 | 0.0 | 126.1 |
| PERIAPT WORTH | 0.0 | +1.9 | 0.0 | 0.0 | 0.0 | +2.0 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.2 | -2.4 | 0.0 | 27.7 | 0.1 | -5.7 | 0.0 | 2.4 |
| PLAN RESULT | 36.5 | +1640.8 | 1580.4 | 989.6 | 41.4 | +1416.9 | 1610.7 | 963.1 |
| PURSUES BIG PREY | 0.1 | -10.3 | 0.0 | 0.0 | 0.2 | -16.1 | 0.0 | 0.0 |
| PURSUES ON | - | - | - | - | 0.0 | +0.5 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE NEXT TURN | 0.1 | +5.0 | 0.0 | 3.4 | 0.0 | +2.4 | 0.0 | 0.0 |
| RANDOM MOVE BY FIGURES | 0.8 | +9.0 | 0.0 | 15.7 | 1.3 | +39.5 | 0.0 | 55.7 |
| RANDOM MOVER NO PROMISE | 0.1 | -4.4 | 4.0 | 0.0 | 0.1 | -5.2 | 12.9 | 0.0 |
| REDIRECT BY WHAT IT STOPS | 0.8 | -17.6 | 0.0 | 19.1 | 1.1 | -28.4 | 0.0 | 29.1 |
| REDIRECT COUNTER | 2.2 | +143.1 | 0.0 | 47.1 | 3.3 | +286.1 | 0.0 | 46.4 |
| REDIRECT WEIGHED | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.5 | 3.1 | 13.6 |
| REFUSING RETIRES | 0.4 | +0.0 | 0.0 | 8.8 | 0.3 | +0.0 | 0.0 | 25.7 |
| RESERVE FALL BACK | 0.2 | +4.2 | 0.0 | 5.3 | 1.3 | +39.7 | 0.0 | 35.5 |
| RESTRAINS TO SHOOT | 0.1 | +2.2 | 0.0 | 2.9 | 0.0 | +0.3 | 0.0 | 0.0 |
| RISK BY ARC | 2.2 | +78.0 | 263.8 | 70.0 | 2.9 | +62.2 | 276.5 | 104.4 |
| RISK ONCE | 4.4 | +113.8 | 50.3 | 147.1 | 4.3 | +145.6 | 63.0 | 279.2 |
| SAFE SURE CHARGE | - | - | - | - | 0.0 | -1.2 | 0.0 | 0.0 |
| SAFER THAN THE JOB | 1.2 | +54.0 | 0.0 | 28.3 | 0.7 | +47.6 | 0.0 | 19.5 |
| SCOUT SPOT | 0.3 | +0.9 | 0.0 | 0.0 | 0.5 | +2.4 | 0.0 | 0.0 |
| SCOUT WAITS | 0.3 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.2 | -4.5 | 0.0 | 1.2 | 0.6 | -47.7 | 0.0 | 4.3 |
| SEARCH SPOT | 2.0 | +115.4 | 0.0 | 27.3 | 2.4 | +93.8 | 0.0 | 60.5 |
| SECOND CHARGER ADDS | - | - | - | - | 0.5 | -30.5 | 61.3 | 7.1 |
| SECOND HUNTER | - | - | - | - | 0.1 | -0.7 | 4.6 | 1.8 |
| SELF MOVE SPELL | 0.2 | +2.0 | 0.0 | 21.9 | - | - | - | - |
| SET UP TOGETHER | 0.6 | +15.2 | 5.1 | 37.0 | 1.9 | +138.7 | 83.2 | 91.1 |
| SET-UP ANY TARGET | 0.1 | +7.8 | 0.0 | 0.0 | 0.1 | +6.8 | 0.0 | 0.0 |
| SET-UP MISSED | - | - | - | - | 0.1 | +16.5 | 0.0 | 0.0 |
| SHOOTER COUNTED ONCE | 0.0 | -0.0 | 0.0 | 0.0 | 0.1 | -0.1 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.4 | +0.8 | 0.0 | 0.0 | 0.3 | +0.6 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.2 | +34.8 | 68.3 | 15.7 | 0.8 | +38.3 | 49.7 | 17.9 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| SHOT REPLANNED | 0.8 | +0.0 | 191.7 | 20.9 | 0.4 | +0.0 | 52.6 | 9.9 |
| SHOTS IN THE MOVE | 13.6 | +602.1 | 0.0 | 258.2 | 11.7 | +407.0 | 0.0 | 167.9 |
| SPELL SETS UP CHARGE | 0.1 | +23.5 | 0.0 | 0.0 | 0.2 | +46.5 | 4.4 | 0.0 |
| SPELL WORTH | 0.9 | +16.4 | 85.7 | 69.7 | 1.5 | +31.3 | 54.2 | 54.2 |
| SPELLS IN THE FIGHT | 0.4 | -0.5 | 74.9 | 17.7 | 0.6 | -11.2 | 86.8 | 30.8 |
| STABLE ROLE | 10.5 | +0.0 | 479.9 | 142.7 | 11.9 | +0.0 | 354.9 | 145.1 |
| STANDS TO CAST | 0.1 | +1.6 | 2.4 | 11.1 | - | - | - | - |
| STAY WEIGHED | - | - | - | - | 0.1 | +3.2 | 0.0 | 2.0 |
| STOPS | 0.0 | +0.5 | 5.4 | 0.0 | 0.2 | +11.6 | 28.3 | 1.8 |
| STOPS SHORT OF THE FLANK | 0.4 | +18.3 | 0.0 | 38.3 | 0.2 | +12.0 | 0.0 | 25.9 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 14.6 |
| SUPPORT NARROWED | 6.5 | -62.5 | 421.5 | 121.4 | 8.7 | -89.1 | 459.4 | 138.5 |
| SUPPORTS | 4.4 | +62.5 | 260.7 | 48.1 | 5.9 | +93.5 | 218.4 | 72.4 |
| SURE CHARGE BEATS ADVANCE | 0.1 | -1.0 | 5.9 | 1.4 | 0.2 | -15.0 | 14.0 | 12.9 |
| SURE REACH TOGETHER | 0.4 | +1.2 | 2.2 | 35.9 | 0.8 | +0.3 | 30.8 | 10.7 |
| THROUGH LINE OF FIRE | 0.3 | +18.3 | 0.0 | 0.0 | 0.3 | +13.2 | 0.0 | 0.0 |
| TURN WORTH | 0.3 | -24.2 | 34.8 | 1.4 | 0.2 | -13.4 | 22.2 | 16.6 |
| TWO OR MORE ARRIVE | 0.2 | +0.6 | 0.0 | 0.0 | 0.3 | +1.0 | 11.7 | 14.8 |
| WAIT AFTER COSTS | 6.1 | -279.4 | 179.8 | 116.7 | 8.9 | -430.7 | 489.6 | 274.0 |
| WALKS TO THE FIGHT | 1.5 | +14.3 | 30.5 | 14.9 | 1.4 | +7.3 | 37.2 | 23.9 |
| WAR ENGINE CHARGES | 0.1 | +7.6 | 0.0 | 2.1 | 0.0 | +5.2 | 0.0 | 5.1 |
| WAR ENGINE JOBS | 0.7 | +0.0 | 42.2 | 19.7 | 0.5 | +0.0 | 53.2 | 14.3 |
| WEARS DOWN | 1.1 | +37.6 | 124.5 | 38.7 | 1.5 | +46.8 | 166.2 | 45.4 |
| WHO HITS BACK | 0.2 | +12.9 | 0.0 | 19.8 | 0.1 | +5.2 | 0.0 | 24.4 |
| WHOLE FIGHT | 0.3 | +6.2 | 42.9 | 3.6 | 0.3 | +19.1 | 66.8 | 0.0 |
| WHOLE FIGHT GAIN | 0.3 | +20.5 | 35.3 | 11.6 | 0.9 | +37.5 | 82.4 | 17.9 |
| WIDER SPREAD | 2.3 | -6.2 | 233.1 | 51.4 | 3.1 | -5.9 | 336.6 | 92.8 |

### Rule changes: jc-opp-1e5408d-p2

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 1192 | 1192 | 1192 | 33.11 | -52717 | -44.2 |
| PATHS CROSS | 178 | 178 | 178 | 4.94 | +10279 | +57.7 |
| SUPPORTS | 371 | 371 | 156 | 4.33 | +2003 | +12.8 |
| MOVE TO CHARGE | 301 | 301 | 154 | 4.28 | +5667 | +36.8 |
| SEARCH SPOT | 157 | 157 | 151 | 4.19 | +7549 | +50.0 |
| KILLS COUNT NEXT TURN | 439 | 439 | 141 | 3.92 | +4875 | +34.6 |
| FACES THE THREAT | 111 | 111 | 111 | 3.08 | +8236 | +74.2 |
| SHOTS IN THE MOVE | 910 | 598 | 102 | 2.83 | +3464 | +34.0 |
| COVER ONCE | 588 | 351 | 91 | 2.53 | +1441 | +15.8 |
| BEST FIRST | 88 | 88 | 88 | 2.44 | +3639 | +41.3 |
| WAIT AFTER COSTS | 540 | 540 | 87 | 2.42 | +1862 | +21.4 |
| ADVANCE WORTH | 394 | 394 | 71 | 1.97 | +1015 | +14.3 |
| FALLBACK BY WORTH | 352 | 352 | 71 | 1.97 | +2858 | +40.3 |
| CANNON SIGHT KEPT | 70 | 70 | 70 | 1.94 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 66 | 66 | 66 | 1.83 | +7993 | +121.1 |
| SAFER THAN THE JOB | 66 | 66 | 66 | 1.83 | +3657 | +55.4 |
| CHAFF IN THE MOVE | 100 | 96 | 62 | 1.72 | +1901 | +30.7 |
| RISK ONCE | 315 | 214 | 59 | 1.64 | +1672 | +28.3 |
| RESERVE FALL BACK | 55 | 55 | 55 | 1.53 | +1582 | +28.8 |
| MISSILES IN THE MOVE | 266 | 161 | 53 | 1.47 | +1188 | +22.4 |
| ARTILLERY RE-ROLL WEIGHED | 50 | 50 | 50 | 1.39 | +0 | +0.0 |
| IDLE COST | 1223 | 728 | 48 | 1.33 | +565 | +11.8 |
| ONE FIGHT FORMULA | 655 | 383 | 46 | 1.28 | +121 | +2.6 |
| RANDOM MOVE BY FIGURES | 75 | 75 | 44 | 1.22 | +1748 | +39.7 |
| SHOT REPLANNED | 43 | 43 | 43 | 1.19 | +0 | +0.0 |
| ADVANCE LANE KEPT | 42 | 42 | 42 | 1.17 | +0 | +0.0 |
| KILLS COUNT | 136 | 135 | 42 | 1.17 | +2014 | +47.9 |
| REDIRECT COUNTER | 199 | 97 | 42 | 1.17 | +3684 | +87.7 |
| SET UP TOGETHER | 89 | 75 | 42 | 1.17 | +2069 | +49.3 |
| WALKS TO THE FIGHT | 103 | 103 | 41 | 1.14 | +236 | +5.8 |
| HOLDS AMBUSHERS | 40 | 40 | 40 | 1.11 | +0 | +0.0 |
| RISK BY ARC | 187 | 185 | 40 | 1.11 | +961 | +24.0 |
| CHARGE NOW WEIGHED | 38 | 38 | 38 | 1.06 | +3443 | +90.6 |
| HONEST WORTH | 638 | 638 | 38 | 1.06 | +261 | +6.9 |
| MAX FOR POSITIONING | 452 | 275 | 36 | 1.00 | +71 | +2.0 |
| BLOCKED WHEEL | 34 | 34 | 34 | 0.94 | +806 | +23.7 |
| CANNON PLANNED TARGET | 244 | 244 | 33 | 0.92 | -103 | -3.1 |
| LONE WIZARD KEPT IN | 33 | 33 | 33 | 0.92 | +2266 | +68.7 |
| SCOUT WAITS | 32 | 32 | 32 | 0.89 | +0 | +0.0 |
| MARCH CHECK | 30 | 30 | 29 | 0.81 | +1263 | +43.5 |
| CHARGE NOW FIRST | 176 | 176 | 28 | 0.78 | -1234 | -44.1 |
| INVITES THE FIGHT | 76 | 76 | 27 | 0.75 | +209 | +7.7 |
| SHOOTS FROM THE BEST SPOT | 72 | 72 | 27 | 0.75 | +934 | +34.6 |
| BEST OVERALL | 26 | 26 | 26 | 0.72 | +1379 | +53.0 |
| BEST FACING | 25 | 25 | 25 | 0.69 | +960 | +38.4 |
| SHOOTERS IN TWO RANKS | 25 | 25 | 25 | 0.69 | +50 | +2.0 |
| MOVE AND CAST | 24 | 24 | 24 | 0.67 | +869 | +36.2 |
| STOPS SHORT OF THE FLANK | 24 | 24 | 24 | 0.67 | +1090 | +45.4 |
| WHOLE FIGHT GAIN | 44 | 43 | 23 | 0.64 | +577 | +25.1 |
| BEST PREY | 54 | 54 | 22 | 0.61 | +1274 | +57.9 |
| CASTING BLOCK | 32 | 32 | 22 | 0.61 | +807 | +36.7 |
| MODEL FACING | 20 | 20 | 20 | 0.56 | +5462 | +273.1 |
| THROUGH LINE OF FIRE | 20 | 20 | 20 | 0.56 | +1134 | +56.7 |
| WAR ENGINE JOBS | 41 | 41 | 18 | 0.50 | -866 | -48.1 |
| WEARS DOWN | 91 | 91 | 18 | 0.50 | +501 | +27.8 |
| CASTER AWAY FROM SCREEN | 16 | 16 | 16 | 0.44 | +0 | +0.0 |
| CHAFF PASSED | 16 | 16 | 16 | 0.44 | -20 | -1.3 |
| COMBAT PIVOT | 16 | 16 | 16 | 0.44 | +0 | +0.0 |
| KEEPS ITS TARGET | 132 | 132 | 16 | 0.44 | +310 | +19.4 |
| CAST JOB | 51 | 51 | 15 | 0.42 | +299 | +19.9 |
| CASTS FROM BEHIND | 15 | 15 | 15 | 0.42 | +0 | +0.0 |
| SHORT GUN FORWARD | 14 | 14 | 14 | 0.39 | +0 | +0.0 |
| STUCK PIVOT | 14 | 14 | 14 | 0.39 | +0 | +0.0 |
| FRIENDS SHOTS CHECKED | 13 | 13 | 13 | 0.36 | +850 | +65.4 |
| HUNT IN PAIRS | 41 | 27 | 12 | 0.33 | +857 | +71.5 |
| WHO HITS BACK | 12 | 12 | 12 | 0.33 | +457 | +38.1 |
| MANOEUVRE | 15 | 15 | 11 | 0.31 | +501 | +45.5 |
| REDIRECT WEIGHED | 11 | 11 | 11 | 0.31 | +602 | +54.7 |
| MAKE SURE TOGETHER | 39 | 24 | 10 | 0.28 | +334 | +33.4 |
| MARCH ODDS | 10 | 10 | 10 | 0.28 | +90 | +9.0 |
| SURE CHARGE BEATS ADVANCE | 10 | 10 | 10 | 0.28 | -576 | -57.6 |
| PIVOT GUARDS FLANK | 9 | 9 | 9 | 0.25 | -292 | -32.4 |
| PURSUES BIG PREY | 9 | 9 | 9 | 0.25 | -950 | -105.5 |
| REFUSING RETIRES | 25 | 25 | 9 | 0.25 | -0 | -0.0 |
| SUPPORT NARROWED | 547 | 547 | 8 | 0.22 | -97 | -12.1 |
| BIG CHARACTER SAFETY | 7 | 7 | 7 | 0.19 | +15 | +2.1 |
| SURE REACH TOGETHER | 45 | 31 | 7 | 0.19 | +23 | +3.2 |
| WHOLE FIGHT | 22 | 22 | 6 | 0.17 | +374 | +62.4 |
| BLOCKED CHARGE SKIPPED | 5 | 5 | 5 | 0.14 | +0 | +0.0 |
| MISSILES NEXT TURN | 296 | 168 | 5 | 0.14 | +23 | +4.6 |
| ONE OBJECTIVE FORMULA | 148 | 83 | 5 | 0.14 | +161 | +32.3 |
| OPENS UP | 7 | 7 | 5 | 0.14 | +234 | +46.8 |
| BOMBING RUN | 4 | 4 | 4 | 0.11 | +139 | +34.8 |
| CHARIOT NO STATIC JOB | 5 | 5 | 4 | 0.11 | -291 | -72.8 |
| KEEPS SCOUTS OR AMBUSH | 4 | 4 | 4 | 0.11 | +0 | +0.0 |
| LOST CHARGE | 185 | 185 | 4 | 0.11 | +116 | +28.9 |
| MOVES UNITS SPELL | 4 | 4 | 4 | 0.11 | +122 | +30.4 |
| NEEDED THERE | 6 | 6 | 4 | 0.11 | +0 | +0.0 |
| RESTRAINS TO SHOOT | 4 | 4 | 4 | 0.11 | +93 | +23.3 |
| WIDER SPREAD | 192 | 189 | 4 | 0.11 | +6 | +1.6 |
| BEST PRIZE | 3 | 3 | 3 | 0.08 | -137 | -45.8 |
| FOCUS FIRE | 3 | 3 | 3 | 0.08 | +189 | +63.0 |
| LONG SHOT | 56 | 55 | 3 | 0.08 | +36 | +12.2 |
| OVERRUNS AWAY | 40 | 40 | 3 | 0.08 | +22 | +7.5 |
| RAIDS THE BAGGAGE NEXT TURN | 3 | 3 | 3 | 0.08 | +214 | +71.4 |
| STANDS TO CAST | 3 | 3 | 3 | 0.08 | -10 | -3.5 |
| STAY WEIGHED | 3 | 3 | 3 | 0.08 | +117 | +38.9 |
| TWO OR MORE ARRIVE | 17 | 17 | 3 | 0.08 | +16 | +5.2 |
| BOUND ASSAILMENT | 2 | 2 | 2 | 0.06 | +0 | +0.2 |
| CATCH ODDS | 2 | 2 | 2 | 0.06 | -29 | -14.5 |
| FIRE AND FLEE | 2 | 2 | 2 | 0.06 | +117 | +58.4 |
| HUNT ADVANCE | 19 | 19 | 2 | 0.06 | +27 | +13.5 |
| JOINT CHARGE PLAN | 8 | 8 | 2 | 0.06 | +86 | +43.2 |
| KEEP FALLS | 2 | 2 | 2 | 0.06 | +126 | +63.1 |
| OPENS A LANE | 10 | 6 | 2 | 0.06 | +12 | +5.9 |
| PERIAPT WORTH | 2 | 2 | 2 | 0.06 | +140 | +70.0 |
| BACKUP TARGETS | 47 | 29 | 1 | 0.03 | +1 | +0.7 |
| BLOWS WHERE AIMED | 16 | 16 | 1 | 0.03 | +149 | +148.7 |
| CONTINUE AHEAD WEIGHED | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| DEFENSIVE ARMY | 16 | 16 | 1 | 0.03 | -60 | -60.4 |
| EDGE GIVE GROUND | 19 | 19 | 1 | 0.03 | +1 | +1.3 |
| HORN WORTH | 1 | 1 | 1 | 0.03 | +3 | +3.0 |
| LONE WIZARD HOLDS BACK | 13 | 13 | 1 | 0.03 | -11 | -10.9 |
| MOVE SPELL IN RANGE | 7 | 4 | 1 | 0.03 | +1 | +1.1 |
| PURSUES ON | 1 | 1 | 1 | 0.03 | +18 | +18.5 |
| SAFE SURE CHARGE | 1 | 1 | 1 | 0.03 | -35 | -35.4 |
| SECOND CHARGER ADDS | 18 | 18 | 1 | 0.03 | +56 | +55.6 |
| SPELLS IN THE FIGHT | 38 | 37 | 1 | 0.03 | +42 | +42.1 |
| STOPS | 10 | 10 | 1 | 0.03 | +9 | +9.3 |
| WAR ENGINE CHARGES | 5 | 5 | 1 | 0.03 | +26 | +26.1 |
| ARRIVAL HUNT | 4 | 4 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 31 | 31 | 0 | 0.00 | - | - |
| CARRIES OUT COUNTER | 4 | 4 | 0 | 0.00 | - | - |
| CARRIES OUT SET-UP | 10 | 10 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 24 | trace | - | - | - | - |
| CATCH FLIERS | 2 | not checked | - | - | - | - |
| CHARGER SLAIN LOST | 40 | 39 | 0 | 0.00 | - | - |
| CHARIOT WIZARD CAREFUL | 2 | 2 | 0 | 0.00 | - | - |
| CHEAP HELPER | 2 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 33 | not checked | - | - | - | - |
| DEFENSIVE FLOOR | 2 | 2 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT LIFT | 3 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 367 | not checked | - | - | - | - |
| FRIEND IN REACH | 320 | not checked | - | - | - | - |
| GIVES UP | 4 | 4 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 4 | 4 | 0 | 0.00 | - | - |
| HELPER ALREADY ASKED | 4 | not checked | - | - | - | - |
| HELPER UNSEEN | 31 | 30 | 0 | 0.00 | - | - |
| HILL BY ITS CHANCE | 38 | 38 | 0 | 0.00 | - | - |
| HUNT DROPPED | 7 | trace | - | - | - | - |
| HUNT KEPT | 15 | trace | - | - | - | - |
| HUNT RESULT | 16 | trace | - | - | - | - |
| HUNT THE GUNS | 20 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 5 | 5 | 0 | 0.00 | - | - |
| KEEPS ITS PREY | 5 | 5 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 19 | not checked | - | - | - | - |
| LURE BY WHAT IT DRAWS | 13 | 13 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 3 | trace | - | - | - | - |
| MARCH OVER CASTS | 21 | 21 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 5 | 5 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 22 | trace | - | - | - | - |
| MOVE SPELL SPOT | 5 | not checked | - | - | - | - |
| NOT NEEDED | 9 | 9 | 0 | 0.00 | - | - |
| NOT TURNED | 396 | 396 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 41 | not checked | - | - | - | - |
| OVERRUN THREAT | 1 | not checked | - | - | - | - |
| PAIR SET-UP | 6 | not checked | - | - | - | - |
| PLAN RESULT | 2804 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 7 | 7 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 67 | 67 | 0 | 0.00 | - | - |
| SCOUT SPOT | 28 | 28 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 28 | 28 | 0 | 0.00 | - | - |
| SECOND HUNTER | 5 | 5 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 6 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 6 | not checked | - | - | - | - |
| SET-UP MISSED | 3 | trace | - | - | - | - |
| SHOOTER COUNTED ONCE | 3 | 3 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 11 | not checked | - | - | - | - |
| SPELL WORTH | 86 | not checked | - | - | - | - |
| STABLE ROLE | 805 | 804 | 0 | 0.00 | - | - |
| TURN WORTH | 19 | 19 | 0 | 0.00 | - | - |

### Off best figure: jc-opp-1e5408d-p2

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 14.33 | 15.72 | 45.3 |
| FALLBACK | gate | 0.53 | 0.78 | 40.9 |
| TURN GATE | gate | 0.42 | 0.42 | 34.0 |
| CHARGE NOW FIRST | rule | 0.39 | 0.36 | 45.7 |
| WAR ENGINE JOBS | rule | 0.31 | 0.19 | 48.1 |
| AFTERMATH BAND | gate | 0.17 | 0.14 | 2.0 |
| SURE CHARGE BEATS ADVANCE | rule | 0.06 | 0.22 | 57.6 |
| PIVOT GUARDS FLANK | rule | 0.17 | 0.08 | 32.4 |
| PURSUES BIG PREY | rule | 0.06 | 0.19 | 105.5 |
| LONE CHARACTER SAFE SPOT | gate | 0.08 | 0.14 | 26.6 |
| SUPPORT NARROWED | rule | 0.14 | 0.08 | 12.1 |
| CANNON PLANNED TARGET | rule | 0.14 | 0.06 | 19.6 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.11 | 0.03 | 71.0 |
| CHAFF PASSED | rule | 0.06 | 0.08 | 4.0 |
| CHARGE NOW WEIGHED | rule | 0.06 | 0.06 | 19.0 |
| CHARIOT NO STATIC JOB | rule | 0.11 | - | 72.8 |
| FIGHT ORDER BAND | gate | 0.06 | 0.06 | 1.3 |
| NO REASON | gate | - | 0.08 | 2.8 |
| BEST PRIZE | rule | - | 0.06 | 68.5 |
| BIG CHARACTER SAFETY | rule | 0.06 | - | 6.0 |
| BLOCKED WHEEL | rule | - | 0.06 | 19.4 |
| CATCH ODDS | rule | 0.03 | 0.03 | 14.5 |
| FOLLOW UP WEIGHED | rule | 0.03 | 0.03 | 1.5 |
| MARCH ODDS | rule | 0.03 | 0.03 | 3.5 |
| PATHS CROSS | rule | 0.06 | - | 38.0 |
| SUPPORT REQUEST | gate | 0.03 | 0.03 | 62.5 |
| DEFENSIVE ARMY | rule | 0.03 | - | 60.4 |
| FACES THE THREAT | rule | 0.03 | - | 11.3 |
| FRIENDS SHOTS CHECKED | rule | 0.03 | - | 2.0 |
| LONE WIZARD HOLDS BACK | rule | 0.03 | - | 10.9 |
| MOVE AND CAST | rule | - | 0.03 | 9.3 |
| REFUSING RETIRES | rule | 0.03 | - | 0.9 |
| SAFE SURE CHARGE | rule | - | 0.03 | 35.4 |
| STANDS TO CAST | rule | 0.03 | - | 10.5 |
| STOPS SHORT OF THE FLANK | rule | 0.03 | - | 0.7 |
| THROUGH LINE OF FIRE | rule | 0.03 | - | 2.2 |

### Plans: jc-opp-1e5408d-p2

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 9.7 | 19% | 236 | 333 | 142% |
| Mine | charge | 2.9 | 59% | 224 | 304 | 136% |
| Mine | close in | 4.3 | 23% | 196 | 137 | 70% |
| Mine | hold | 4.9 | 28% | 311 | 0 | 0% |
| Mine | join | 0.6 | 95% | 21 | 0 | 0% |
| Mine | shoot | 8.6 | 66% | 296 | 867 | 293% |
| Mine | support | 5.4 | 89% | 45 | 0 | 0% |
| Opponent | advance | 11.2 | 16% | 148 | 332 | 224% |
| Opponent | charge | 4.6 | 56% | 419 | 468 | 112% |
| Opponent | close in | 7.1 | 26% | 435 | 215 | 49% |
| Opponent | hold | 4.5 | 43% | 320 | 0 | 0% |
| Opponent | join | 0.8 | 97% | 39 | 0 | 0% |
| Opponent | shoot | 5.7 | 58% | 248 | 402 | 162% |
| Opponent | support | 7.4 | 90% | 94 | 0 | 0% |

### Packages: hunt the guns, jc-opp-1e5408d-p2

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.0 | 1 | 0 | 100% | 100% | 0% | 4.0 | 233 | 214 | 100% | 59 |
| Opponent | 0.5 | 19 | 4 | 33% | 53% | 0% | 2.5 | 336 | 180 | 53% | 111 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 68 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 315 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 78 |
| Empire of Man | 0.1 | 1 | 0 | 0% | 0% | 0% | - | 142 | 0 | 0% | 58 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 179 |
| High Elf Realms | 0.2 | 1 | 0 | 100% | 100% | 0% | 4.0 | 233 | 214 | 100% | 0 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 236 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Ogre Kingdoms | 1.2 | 5 | 0 | 80% | 80% | 0% | 2.5 | 489 | 341 | 80% | 160 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 48 |
| Tomb Kings of Khemri | 2.0 | 10 | 4 | 17% | 50% | 0% | 2.3 | 195 | 112 | 50% | 0 |
| Vampire Counts | 0.1 | 1 | 0 | 0% | 0% | 0% | - | 374 | 0 | 0% | 0 |
| Warriors of Chaos | 0.1 | 1 | 0 | 0% | 0% | 0% | - | 452 | 0 | 0% | 85 |
| Wood Elf Realms | 0.1 | 1 | 0 | 0% | 100% | 0% | 3.0 | 446 | 318 | 100% | 86 |

### Battle groups: jc-opp-1e5408d-p2

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 2.2 | 30% | 67% | 4% | 0% | 22% | 0% | 9% | 70% | 0% |
| Opponent | REDIRECT COUNTER | 3.3 | 23% | 59% | 7% | 0% | 24% | 4% | 16% | 52% | 4% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: jc-opp-1e5408d-p2

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 5 | 0 (5) | 0 | 0 | 84 | 80% | 4.0 | 0 (1) | 0 (1) | - | 0 (1) | 0 (1) |
| Mine | Chaff | 34 | 79 (34) | 34 | 45 | 48 | 38% | 2.8 | 60 (19) | 202 (7) | 16 (8) | 108 (23) | 14 (11) |
| Mine | Character | 123 | 44 (123) | 44 | 0 | 42 | 19% | 2.6 | 58 (38) | 45 (54) | 11 (11) | 55 (50) | 41 (53) |
| Mine | Clean-up | 21 | 41 (21) | 10 | 31 | 36 | 57% | 3.0 | 34 (5) | 39 (13) | 71 (3) | 66 (13) | 15 (8) |
| Mine | Fast | 1 | 0 (1) | 0 | 0 | 100 | 0% | 3.0 | - | 0 (1) | - | 0 (1) | - |
| Mine | Fast Hammer | 48 | 40 (48) | 22 | 18 | 39 | 17% | 3.0 | 29 (23) | 68 (16) | 30 (9) | 44 (29) | 35 (19) |
| Mine | Fragile | 5 | 105 (5) | 105 | 0 | 20 | 0% | 2.6 | - | 87 (3) | 131 (2) | 105 (5) | - |
| Mine | Hammer | 57 | 32 (57) | 21 | 10 | 46 | 18% | 2.5 | 12 (18) | 37 (29) | 54 (10) | 35 (38) | 25 (19) |
| Mine | Holder | 28 | 56 (28) | 4 | 52 | 43 | 39% | 2.5 | 43 (9) | 102 (10) | 9 (9) | 84 (19) | 0 (9) |
| Mine | Shooter | 41 | 100 (41) | 58 | 42 | 40 | 2% | 1.4 | 96 (5) | 109 (30) | 60 (6) | 121 (25) | 67 (16) |
| Mine | Support | 2 | 0 (2) | 0 | 0 | 34 | 100% | - | - | 0 (2) | - | - | 0 (2) |
| Mine | War machine | 59 | 55 (59) | 55 | 0 | 47 | 2% | 1.2 | 0 (10) | 57 (37) | 92 (12) | 0 (10) | 66 (49) |
| Mine | Wizard | 22 | 23 (22) | 23 | 0 | 51 | 5% | 2.9 | 0 (5) | 107 (6) | 4 (3) | 0 (5) | 57 (9) |
| Opponent | Blocker | 2 | 85 (2) | 85 | 0 | 38 | 0% | 5.0 | 137 (1) | 0 (1) | - | 137 (1) | 0 (1) |
| Opponent | Chaff | 76 | 53 (76) | 23 | 31 | 49 | 42% | 2.2 | 66 (32) | 37 (19) | 53 (25) | 71 (54) | 11 (22) |
| Opponent | Character | 97 | 54 (97) | 54 | 0 | 38 | 27% | 2.5 | 72 (42) | 42 (41) | 0 (6) | 49 (61) | 65 (28) |
| Opponent | Clean-up | 19 | 29 (19) | 16 | 13 | 42 | 47% | 2.4 | 21 (9) | 42 (10) | - | 38 (14) | 0 (5) |
| Opponent | Early | 2 | 0 (2) | 0 | 0 | 50 | 0% | 5.0 | - | 0 (2) | - | 0 (1) | 0 (1) |
| Opponent | Fast Hammer | 48 | 60 (48) | 48 | 12 | 32 | 21% | 2.6 | 77 (22) | 31 (16) | 76 (10) | 59 (28) | 63 (20) |
| Opponent | Fragile | 5 | 193 (5) | 193 | 0 | 39 | 20% | 4.5 | - | 250 (4) | 0 (1) | 229 (4) | 0 (1) |
| Opponent | Hammer | 70 | 31 (70) | 28 | 3 | 42 | 26% | 2.9 | 28 (17) | 28 (42) | 57 (11) | 38 (43) | 22 (27) |
| Opponent | Holder | 35 | 110 (35) | 6 | 104 | 15 | 37% | 3.0 | 92 (7) | 123 (22) | 103 (4) | 139 (22) | 66 (11) |
| Opponent | Shooter | 33 | 57 (33) | 9 | 48 | 37 | 0% | 1.8 | 34 (8) | 72 (19) | 37 (6) | 87 (22) | 11 (11) |
| Opponent | Support | 3 | 0 (3) | 0 | 0 | 25 | 33% | 5.5 | 0 (1) | 0 (1) | 0 (1) | 0 (2) | 0 (1) |
| Opponent | War machine | 24 | 75 (24) | 75 | 0 | 17 | 12% | 1.6 | 44 (6) | 100 (14) | 33 (4) | 38 (3) | 80 (21) |
| Opponent | Wizard | 26 | 7 (26) | 7 | 0 | 42 | 8% | 1.7 | 0 (10) | 24 (7) | 0 (7) | 18 (8) | 0 (16) |

### Charged fights: jc-opp-1e5408d-p2

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 146 | 145 | 1.5 | 1.2 | 97 | 9 | +88 | 1 of 6 | 6 of 6 | +120 | +82 |
| Mine | Chaos Dwarfs | 4 | 295 | 324 | 3.0 | 1.0 | 108 | 0 | +108 | 9 of 12 | 8 of 12 | - | +108 |
| Mine | Dwarfen Mountain Holds | 4 | 810 | 104 | 1.8 | 1.3 | 59 | 9 | +51 | 1 of 7 | 5 of 7 | +0 | +71 |
| Mine | Empire of Man | 5 | 473 | 98 | 1.8 | 1.1 | 55 | 75 | -20 | 3 of 9 | 6 of 9 | +210 | -49 |
| Mine | Grand Cathay | 4 | 315 | 88 | 2.0 | 1.2 | 44 | 29 | +15 | 3 of 8 | 5 of 8 | +62 | -1 |
| Mine | High Elf Realms | 4 | 16 | 476 | 3.2 | 1.2 | 147 | 57 | +90 | 5 of 13 | 12 of 13 | +76 | +92 |
| Mine | Kingdom of Bretonnia | 1 | 170 | 1249 | 5.0 | 1.2 | 250 | 0 | +250 | 2 of 5 | 5 of 5 | +465 | +196 |
| Mine | Lizardmen | 1 | 45 | 967 | 5.0 | 1.0 | 193 | 63 | +130 | 2 of 5 | 3 of 5 | - | +130 |
| Mine | Ogre Kingdoms | 1 | 261 | 45 | 4.0 | 1.2 | 11 | 31 | -20 | 1 of 4 | 2 of 4 | -34 | -15 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 349 | 5.0 | 1.2 | 70 | 11 | +59 | 1 of 5 | 4 of 5 | +45 | +62 |
| Mine | Skaven | 2 | 182 | 185 | 3.0 | 1.0 | 62 | 67 | -5 | 1 of 6 | 5 of 6 | - | -5 |
| Mine | Tomb Kings of Khemri | 1 | 110 | 909 | 5.0 | 1.0 | 182 | 24 | +157 | 1 of 5 | 5 of 5 | - | +157 |
| Mine | Vampire Counts | 3 | 0 | 279 | 2.3 | 1.1 | 120 | 0 | +120 | 2 of 7 | 5 of 7 | +114 | +121 |
| Mine | Warriors of Chaos | 1 | 0 | 258 | 3.0 | 1.0 | 86 | 0 | +86 | 0 of 3 | 2 of 3 | - | +86 |
| **Mine** | all armies | 36 | 268 | 279 | 2.6 | 1.1 | 106 | 29 | +76 | 32 of 95 | 73 of 95 | +100 | +73 |
| Opponent | Dwarfen Mountain Holds | 2 | 263 | 90 | 4.0 | 1.4 | 22 | 13 | +9 | 1 of 8 | 6 of 8 | +22 | +2 |
| Opponent | Empire of Man | 2 | 630 | 100 | 1.0 | 1.0 | 100 | 0 | +100 | 0 of 2 | 2 of 2 | - | +100 |
| Opponent | Grand Cathay | 2 | 613 | 710 | 2.5 | 1.2 | 284 | 0 | +284 | 4 of 5 | 5 of 5 | +562 | +215 |
| Opponent | Kingdom of Bretonnia | 1 | 285 | 120 | 2.0 | 1.0 | 60 | 0 | +60 | 0 of 2 | 2 of 2 | - | +60 |
| Opponent | Ogre Kingdoms | 3 | 167 | 283 | 5.3 | 1.1 | 53 | 31 | +22 | 5 of 16 | 9 of 16 | +0 | +25 |
| Opponent | Skaven | 1 | 425 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 1 of 1 | 0 of 1 | - | +0 |
| Opponent | Tomb Kings of Khemri | 4 | 85 | 954 | 3.5 | 1.3 | 273 | 50 | +222 | 5 of 14 | 11 of 14 | +62 | +266 |
| Opponent | Vampire Counts | 6 | 10 | 804 | 3.8 | 1.1 | 210 | 34 | +176 | 13 of 23 | 18 of 23 | +308 | +156 |
| Opponent | Warriors of Chaos | 8 | 25 | 189 | 2.0 | 1.0 | 95 | 0 | +95 | 7 of 16 | 12 of 16 | - | +95 |
| Opponent | Wood Elf Realms | 7 | 24 | 533 | 4.1 | 1.1 | 129 | 15 | +113 | 9 of 29 | 22 of 29 | +39 | +122 |
| **Opponent** | all armies | 36 | 139 | 463 | 3.2 | 1.1 | 144 | 22 | +122 | 45 of 116 | 87 of 116 | +124 | +121 |

### Effective charges: jc-opp-1e5408d-p2

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 6 | 1 (net +278) | 0 | 0 | 3 (net +58) | 0 | 1 (net +20) | 1 | 0% (0 of 5) |
| Mine | Chaos Dwarfs | 12 | 1 (net +60) | 2 (net +203) | 3 (net +89) | 2 (net +132) | 0 | 4 (net +75) | 0 | 25% (3 of 12) |
| Mine | Dwarfen Mountain Holds | 7 | 0 | 1 (net +0) | 1 (net -30) | 2 (net +0) | 0 | 3 (net +129) | 0 | 14% (1 of 7) |
| Mine | Empire of Man | 9 | 1 (net +0) | 0 | 3 (net -45) | 1 (net -104) | 1 (net -288) | 3 (net +116) | 0 | 33% (3 of 9) |
| Mine | Grand Cathay | 8 | 3 (net -2) | 0 | 1 (net +0) | 0 | 2 (net +62) | 2 (net +0) | 0 | 12% (1 of 8) |
| Mine | High Elf Realms | 13 | 0 | 1 (net -597) | 3 (net +307) | 2 (net +150) | 3 (net +34) | 3 (net +112) | 1 | 25% (3 of 12) |
| Mine | Kingdom of Bretonnia | 5 | 0 | 0 | 3 (net +388) | 1 (net +0) | 1 (net +85) | 0 | 0 | 60% (3 of 5) |
| Mine | Lizardmen | 5 | 1 (net -141) | 0 | 1 (net +54) | 2 (net +339) | 0 | 0 | 1 | 25% (1 of 4) |
| Mine | Ogre Kingdoms | 4 | 0 | 0 | 1 (net +0) | 0 | 0 | 2 (net +6) | 1 | 33% (1 of 3) |
| Mine | Orc & Goblin Tribes | 5 | 0 | 0 | 1 (net +45) | 0 | 1 (net +54) | 1 (net +190) | 2 | 33% (1 of 3) |
| Mine | Skaven | 6 | 2 (net -116) | 0 | 2 (net +85) | 0 | 0 | 2 (net +15) | 0 | 33% (2 of 6) |
| Mine | Tomb Kings of Khemri | 5 | 0 | 0 | 1 (net +3) | 1 (net +102) | 1 (net +125) | 2 (net +278) | 0 | 20% (1 of 5) |
| Mine | Vampire Counts | 7 | 2 (net +0) | 0 | 1 (net +599) | 2 (net +62) | 1 (net +114) | 1 (net +0) | 0 | 14% (1 of 7) |
| Mine | Warriors of Chaos | 3 | 0 | 0 | 0 | 1 (net +0) | 1 (net +258) | 0 | 1 | 0% (0 of 2) |
| Opponent | Dwarfen Mountain Holds | 8 | 3 (net +0) | 0 | 0 | 3 (net -13) | 0 | 2 (net +58) | 0 | 0% (0 of 8) |
| Opponent | Empire of Man | 2 | 0 | 1 (net +110) | 0 | 0 | 0 | 0 | 1 | 0% (0 of 1) |
| Opponent | Grand Cathay | 5 | 0 | 0 | 1 (net +691) | 3 (net +243) | 0 | 1 (net +0) | 0 | 20% (1 of 5) |
| Opponent | Kingdom of Bretonnia | 2 | 0 | 0 | 0 | 1 (net +120) | 1 (net +0) | 0 | 0 | 0% (0 of 2) |
| Opponent | Ogre Kingdoms | 16 | 4 (net +114) | 0 | 5 (net -69) | 1 (net +45) | 0 | 2 (net +96) | 4 | 42% (5 of 12) |
| Opponent | Skaven | 1 | 1 (net +0) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 1) |
| Opponent | Tomb Kings of Khemri | 14 | 2 (net +468) | 0 | 2 (net +404) | 6 (net +144) | 1 (net +177) | 2 (net +83) | 1 | 15% (2 of 13) |
| Opponent | Vampire Counts | 23 | 3 (net +144) | 3 (net +107) | 3 (net +380) | 7 (net +173) | 0 | 4 (net +152) | 3 | 15% (3 of 20) |
| Opponent | Warriors of Chaos | 16 | 3 (net +37) | 1 (net +250) | 1 (net +192) | 2 (net +235) | 0 | 7 (net +43) | 2 | 7% (1 of 14) |
| Opponent | Wood Elf Realms | 29 | 7 (net +189) | 1 (net +227) | 4 (net +88) | 5 (net +98) | 1 (net +104) | 8 (net +89) | 3 | 15% (4 of 26) |

### Charged fights, damage counted: jc-opp-1e5408d-p2

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 11 | 211 | 317 | -4 | 88 | 86 | +2 | +1.0 |
| Mine | 50-54% | 4 | 314 | 304 | -48 | 109 | 179 | -70 | -22.3 |
| Mine | Effective (55-75%) | 21 | 250 | 241 | +146 | 201 | 30 | +171 | +68.4 |
| Mine | 76-89% | 17 | 248 | 154 | +91 | 119 | 56 | +63 | +25.3 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 24 | 199 | 152 | +91 | 102 | 12 | +89 | +44.8 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 11 | 442 | 103 | +52 | 98 | 59 | +39 | +8.9 |
| Mine | No odds | 7 | 270 | 150 | +19 | 63 | 46 | +17 | +6.4 |
| Mine | All fights | 95 | 259 | 192 | +76 | 122 | 48 | +75 | +28.9 |
| Opponent | Long shot (under 50%) | 23 | 180 | 218 | +142 | 174 | 32 | +142 | +79.2 |
| Opponent | 50-54% | 6 | 336 | 223 | +151 | 216 | 65 | +151 | +45.1 |
| Opponent | Effective (55-75%) | 16 | 219 | 229 | +177 | 217 | 31 | +185 | +84.5 |
| Opponent | 76-89% | 28 | 294 | 192 | +139 | 199 | 72 | +128 | +43.4 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 26 | 245 | 160 | +81 | 87 | 26 | +61 | +24.9 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 3 | 512 | 110 | +94 | 94 | 19 | +75 | +14.7 |
| Opponent | No odds | 14 | 227 | 156 | +60 | 90 | 24 | +67 | +29.5 |
| Opponent | All fights | 116 | 250 | 190 | +122 | 156 | 40 | +116 | +46.5 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| jc-opp-1e5408d-p2 | move | 381 | 75 (20%) | 58 (15%) | 41 (11%) | 265 (70%) |
| jc-opp-1e5408d-p2 | objective | 414 | 65 (16%) | 52 (13%) | 41 (10%) | 308 (74%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0106, L0122, L2429, L2535, L2735 |
| Charmed Shield | Opponent | L0425, L0827, L0934, L1026, L1727, L1827, L1927 |
| Clockwork Compass | Mine | L1228 |
| Clockwork Compass | Opponent | L0512 |
| Elixir of Power | Mine | L1118, L1135, L1927 |
| Fistful of Laurels | Mine | L1827 |
| Fistful of Laurels | Opponent | L0918, L1118, L1418 |
| Horn of the Wild Hunt | Opponent | L3033 |
| Invocation of Nehek | Mine | L2429, L2535, L2735 |
| Invocation of Nehek | Opponent | L0425, L0827, L1727, L1827, L1927 |
| Opal Amulet | Mine | L1418, L1435 |
| Periapt of Soul Exchange | Mine | L2029, L2131 |
| Periapt of Soul Exchange | Opponent | L0721 |
| Ring of Doom | Mine | L0206, L0222, L1118, L1135, L1228, L1531 |
| Ring of Doom | Opponent | L0512, L1531, L2131, L3033 |
| Ring of Jet | Mine | L1026, L1118, L1135, L1228 |
| Ring of Jet | Opponent | L0512, L0810 |
| Standard of the Fell Warrior | Mine | L1323 |
| Storm Daemon (Renegade 2.0) | Mine | L2131 |
| Storm Daemon (Renegade 2.0) | Opponent | L0721 |
| Twice-Blessed Armour | Mine | L0721, L1026 |
| Twice-Blessed Armour | Opponent | L0307, L0810 |
| Witch Hunter's Ward | Mine | L0721, L0810, L0827 |
| Witch Hunter's Ward | Opponent | L0307 |

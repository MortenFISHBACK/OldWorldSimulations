# Doctrine scorecard: jc-mine-1e5408d-p4

### Scorecard: jc-mine-1e5408d-p4

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0114 | 6 | 1 | Mine | no | 4 | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| L0114 | 6 | 1 | Opponent | no | 8 | 1 | 1 | 1 | 0 | 0 | 0 | 0 |
| L0130 | 4 | 1 | Mine | no | 5 | - | 0 | 2 | 0 | 0 | 0 | 0 |
| L0130 | 4 | 1 | Opponent | no | 8 | 1 | 6 | 2 | 0 | 0 | 0 | 0 |
| L0214 | 4 | 1 | Mine | yes | 0 | 2 | 2 | 2 | 0 | 0 | 0 | 30 |
| L0214 | 4 | 1 | Opponent | no | 1 | 1 | 1 | 2 | 0 | 0 | 0 | 0 |
| L0230 | 2 | 1 | Mine | - | - | 1 | 6 | 4 | 0 | 0 | 0 | 0 |
| L0230 | 2 | 1 | Opponent | - | - | 2 | 1 | 0 | 0 | 0 | 0 | 0 |
| L0315 | 3 | 1 | Mine | no | 1 | 2 | 2 | 1 | 0 | 0 | 0 | 565 |
| L0315 | 3 | 1 | Opponent | yes | 11 | 2 | 1 | 1 | 0 | 0 | 0 | 0 |
| L0332 | 2 | 1 | Mine | - | - | 6 | 0 | 1 | 0 | 0 | 0 | 590 |
| L0332 | 2 | 1 | Opponent | - | - | 2 | 3 | 5 | 0 | 0 | 0 | 0 |
| L0417 | 3 | 1 | Mine | yes | 7 | 2 | 5 | 1 | 0 | 0 | 0 | 0 |
| L0417 | 3 | 1 | Opponent | yes | 5 | 2 | 2 | 0 | 0 | 0 | 0 | 0 |
| L0434 | 2 | 1 | Mine | - | - | 2 | 2 | 2 | 0 | 0 | 0 | 0 |
| L0434 | 2 | 1 | Opponent | - | - | 1 | 4 | 3 | 0 | 0 | 0 | 0 |
| L0520 | 4 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 1416 |
| L0520 | 4 | 1 | Opponent | no | 7 | - | 1 | 3 | 1 | 0 | 0 | 210 |
| L0608 | 2 | 1 | Mine | - | - | 6 | 3 | 3 | 1 | 0 | 0 | 984 |
| L0608 | 2 | 1 | Opponent | - | - | - | 0 | 3 | 0 | 0 | 0 | 605 |
| L0624 | 6 | 1 | Mine | no | 0 | 4 | 5 | 1 | 0 | 0 | 0 | 984 |
| L0624 | 6 | 1 | Opponent | no | 6 | 3 | 0 | 0 | 0 | 0 | 0 | 0 |
| L0713 | 5 | 1 | Mine | yes | - | 3 | 0 | 2 | 2 | 0 | 0 | 564 |
| L0713 | 5 | 1 | Opponent | no | - | 2 | 3 | 0 | 0 | 0 | 0 | 302 |
| L0729 | 3 | 1 | Mine | no | 3 | 1 | 3 | 1 | 1 | 0 | 0 | 452 |
| L0729 | 3 | 1 | Opponent | no | 1 | 2 | 5 | 1 | 1 | 0 | 0 | 170 |
| L0819 | 3 | 1 | Mine | no | 0 | - | 0 | 0 | 1 | 0 | 0 | 1007 |
| L0819 | 3 | 1 | Opponent | no | 8 | 2 | 3 | 2 | 1 | 0 | 0 | 0 |
| L0835 | 1 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 515 |
| L0835 | 1 | 1 | Opponent | no | 0 | 3 | 1 | 3 | 0 | 0 | 0 | 114 |
| L0926 | 2 | 1 | Mine | - | - | 6 | 1 | 1 | 0 | 0 | 0 | 537 |
| L0926 | 2 | 1 | Opponent | - | - | 2 | 4 | 4 | 0 | 0 | 0 | 40 |
| L1017 | 3 | 1 | Mine | no | 0 | 2 | 5 | 0 | 0 | 0 | 0 | 330 |
| L1017 | 3 | 1 | Opponent | yes | 3 | 4 | 2 | 1 | 3 | 0 | 0 | 0 |
| L1034 | 2 | 1 | Mine | - | - | 3 | 0 | 0 | 0 | 0 | 0 | 330 |
| L1034 | 2 | 1 | Opponent | - | - | 3 | 3 | 2 | 0 | 0 | 0 | 500 |
| L1126 | 4 | 1 | Mine | no | 1 | - | 0 | 0 | 0 | 0 | 0 | 330 |
| L1126 | 4 | 1 | Opponent | no | 4 | 3 | 2 | 1 | 1 | 0 | 0 | 0 |
| L1220 | 2 | 1 | Mine | - | - | 2 | 4 | 0 | 0 | 0 | 0 | 330 |
| L1220 | 2 | 1 | Opponent | - | - | - | 1 | 4 | 0 | 0 | 0 | 0 |
| L1314 | 6 | 1 | Mine | no | 0 | 3 | 0 | 0 | 0 | 0 | 0 | 140 |
| L1314 | 6 | 1 | Opponent | no | 24 | 2 | 2 | 1 | 1 | 0 | 0 | 300 |
| L1331 | 5 | 1 | Mine | yes | - | - | 5 | 1 | 1 | 0 | 0 | 479 |
| L1331 | 5 | 1 | Opponent | yes | - | 1 | 1 | 3 | 1 | 0 | 0 | 170 |
| L1427 | 5 | 1 | Mine | no | - | 5 | 3 | 2 | 0 | 0 | 0 | 0 |
| L1427 | 5 | 1 | Opponent | yes | - | 3 | 1 | 4 | 0 | 0 | 0 | 0 |
| L1523 | 5 | 1 | Mine | yes | - | 3 | 2 | 1 | 1 | 0 | 0 | 0 |
| L1523 | 5 | 1 | Opponent | yes | - | 2 | 6 | 1 | 0 | 0 | 0 | 245 |
| L1621 | 1 | 1 | Mine | no | 5 | 2 | 5 | 1 | 0 | 0 | 0 | 200 |
| L1621 | 1 | 1 | Opponent | no | 0 | - | 2 | 2 | 0 | 0 | 0 | 565 |
| L1719 | 3 | 1 | Mine | no | 0 | 2 | 2 | 0 | 1 | 0 | 0 | 0 |
| L1719 | 3 | 1 | Opponent | yes | 4 | 2 | 9 | 0 | 0 | 0 | 0 | 0 |
| L1819 | 1 | 1 | Mine | no | 2 | 2 | 5 | 1 | 0 | 0 | 0 | 0 |
| L1819 | 1 | 1 | Opponent | no | 0 | 2 | 7 | 1 | 0 | 0 | 0 | 0 |
| L1835 | 5 | 1 | Mine | yes | - | 3 | 0 | 2 | 0 | 0 | 0 | 0 |
| L1835 | 5 | 1 | Opponent | yes | - | 1 | 2 | 1 | 0 | 0 | 0 | 0 |
| L2021 | 5 | 1 | Mine | yes | - | - | 2 | 4 | 0 | 0 | 0 | 650 |
| L2021 | 5 | 1 | Opponent | no | - | 4 | 3 | 4 | 0 | 0 | 0 | 355 |
| L2123 | 5 | 1 | Mine | no | - | - | 2 | 3 | 0 | 0 | 0 | 940 |
| L2123 | 5 | 1 | Opponent | yes | - | 2 | 6 | 0 | 1 | 0 | 0 | 0 |
| L2227 | 1 | 1 | Mine | yes | 0 | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L2227 | 1 | 1 | Opponent | yes | 0 | 1 | 7 | 2 | 0 | 0 | 0 | 190 |
| L2331 | 3 | 1 | Mine | no | 0 | 2 | 2 | 0 | 1 | 0 | 0 | 0 |
| L2331 | 3 | 1 | Opponent | yes | 8 | 5 | 3 | 1 | 1 | 0 | 0 | 170 |
| L2527 | 1 | 1 | Mine | no | 0 | 3 | 2 | 4 | 0 | 0 | 0 | 0 |
| L2527 | 1 | 1 | Opponent | no | 0 | 1 | 2 | 6 | 0 | 0 | 0 | 190 |
| L2634 | 6 | 1 | Mine | no | 10 | 2 | 6 | 1 | 0 | 0 | 0 | 0 |
| L2634 | 6 | 1 | Opponent | no | 2 | 2 | 0 | 1 | 1 | 0 | 0 | 0 |
| L2930 | 2 | 1 | Mine | - | - | 2 | 6 | 1 | 0 | 0 | 0 | 0 |
| L2930 | 2 | 1 | Opponent | - | - | 2 | 3 | 0 | 1 | 0 | 0 | 0 |
| L3234 | 6 | 1 | Mine | no | 2 | 2 | 2 | 3 | 0 | 0 | 0 | 477 |
| L3234 | 6 | 1 | Opponent | no | 1 | 2 | 3 | 2 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 29% | 1.9 | 2.8 | 2.4 | 1.4 | 0.2 | 0.0 | 0.0 | 329.2 |
| **Average** | | | Opponent | 39% | 4.8 | 2.1 | 2.8 | 1.9 | 0.4 | 0.0 | 0.0 | 114.6 |

### KPIs: jc-mine-1e5408d-p4

Rules off - Opponent only: SECOND CHARGER ADDS.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 25% (41 of 167) | 1% (1 of 183) | 12% (42 of 350) |
| Winner chose to follow up after the loser gave ground |  | 98% (44 of 45); on the table 98% | 100% (36 of 36); on the table 100% | 99% (80 of 81); on the table 99% |
| Winner chose to pursue after the loser fell back in good order |  | 100% (10 of 10); on the table 100% | 94% (15 of 16); on the table 94% | 96% (25 of 26); on the table 96% |
| Winner chose to pursue after the loser fled |  | 77% (20 of 26); on the table 85% | 79% (26 of 33); on the table 82% | 78% (46 of 59); on the table 83% |
| Winner chose to follow up or pursue (all three) |  | 91% (74 of 81); on the table 94% | 91% (77 of 85); on the table 92% | 91% (151 of 166); on the table 93% |
| Magic missiles tried each own turn | 50%+ | 25% (65 of 265) | 36% (64 of 176) | 29% (129 of 441) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 38% (65 of 171) | 50% (64 of 127) | 43% (129 of 298) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 67% (32 of 48) | 60% (39 of 65) | 63% (71 of 113) |
| Points that never fought | lower | 38% (25996 of 67942) | 34% (24676 of 71984) | 36% (50672 of 139926) |
|   infantry points that never fought | lower | 44% (6687 of 15347) | 54% (7464 of 13804) | 49% (14151 of 29151) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 64% (174 of 270) | 52% (147 of 280) | 58% (321 of 550) |
| Bound items with a magic missile used (at least once a game) |  | 82% (18 of 22); 1.5 uses a game | 89% (8 of 9); 0.7 uses a game | 84% (26 of 31); 1.1 uses a game |
| Bound items with another spell used |  | 31% (5 of 16); 0.4 uses a game | 30% (6 of 20); 0.2 uses a game | 31% (11 of 36); 0.3 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 63% (12 of 19); 0.3 uses a game | 80% (12 of 15); 0.3 uses a game | 71% (24 of 34); 0.3 uses a game |
|   their share of the points of units over 100 pts | lower | 60% (34553 of 57750) | 43% (27521 of 63347) | 51% (62074 of 121097) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.2 (22%) | 0.9 (28%) | 2.1 (24%) |
| MARCHED: its unit marched | 1.2 (22%) | 0.4 (13%) | 1.7 (19%) |
| CHARGED: its unit charged | 0.4 (8%) | 0.2 (5%) | 0.6 (7%) |
| IN COMBAT: engaged in combat | 1.1 (20%) | 0.6 (19%) | 1.7 (20%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.2 (8%) | 0.2 (3%) |
| FLEEING: fleeing | 0.1 (2%) | 0.0 (0%) | 0.1 (1%) |
| GONE: slain | 1.2 (22%) | 0.7 (23%) | 1.9 (22%) |
| OFF THE TABLE: off the table or not arrived | 0.2 (4%) | 0.1 (2%) | 0.2 (3%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.1 | 1.3 | 1.9 | 3.6 | 0.4 | 2.2 |
| not cast | 3.1 | 2.5 | 2.9 | 8.7 | 1.6 | 20.7 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.1 (5%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.4 (54%) | 0.2 (8%) | 2.1 (24%) | 0.2 (14%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.7 (19%) | 0.4 (26%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.6 (7%) | 0.0 (2%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.1 (2%) | 0.2 (7%) | 0.7 (23%) | 1.7 (20%) | 0.4 (25%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.2 (5%) | 0.2 (7%) | 0.3 (11%) | 0.2 (3%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.1 (4%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.3 (1%) |
| GONE: slain | 0.9 (31%) | 0.3 (12%) | 0.7 (24%) | 1.9 (22%) | 0.2 (16%) | 4.5 (22%) |
| OFF THE TABLE: off the table or not arrived | 0.3 (10%) | 0.1 (4%) | 0.1 (2%) | 0.2 (3%) | 0.0 (0%) | 0.9 (4%) |
| STUPIDITY: Stupidity | 0.1 (5%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.2 (9%) | 0.0 (0%) | 0.0 (0%) | 0.3 (18%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.3 (44%) | 0.2 (8%) | 0.9 (32%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 13.8 (67%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.4 a game | 0.6 a game | 1.0 a game |
| stood (cast and not dispelled) | 58% (25 of 43) | 54% (7 of 13) | 57% (32 of 56) |
| the unit moved after it | 76% (19 of 25) | 71% (5 of 7) | 75% (24 of 32) |
| it charged on its next turn | 12% (3 of 25) | 14% (1 of 7) | 12% (4 of 32) |
| the enemy charged it first | 32% (8 of 25) | 0% (0 of 7) | 25% (8 of 32) |
| it fought by the end of its next turn | 16% (4 of 25) | 14% (1 of 7) | 16% (5 of 32) |
| it moved out of a charge the enemy had planned (not charged first) | 16% (4 of 25) | 0% (0 of 7) | 12% (4 of 32) |
| none of these (no charge, no fight, no charge escaped) | 52% (13 of 25) | 71% (5 of 7) | 56% (18 of 32) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 66% (593 of 898) | 55% (288 of 523) | 62% (881 of 1421) |
|   cavalry | 58% (46 of 80) | 70% (80 of 114) | 65% (126 of 194) |
|   character | 47% (49 of 104) | 20% (24 of 119) | 33% (73 of 223) |
|   chariot | 55% (59 of 107) | 76% (13 of 17) | 58% (72 of 124) |
|   infantry | 65% (178 of 273) | 65% (149 of 231) | 65% (327 of 504) |
|   monster | 50% (24 of 48) | 14% (3 of 21) | 39% (27 of 69) |
|   war machine | 83% (237 of 286) | 90% (19 of 21) | 83% (256 of 307) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.8 (21%) | 1.4 (22%) | 3.2 (21%) |
| CHARGED: it charged | 1.1 (12%) | 1.6 (25%) | 2.7 (18%) |
| FLEEING: it fled or was fleeing | 0.2 (2%) | 0.1 (1%) | 0.2 (1%) |
| IN COMBAT: it fought this turn or the last | 0.8 (9%) | 0.3 (5%) | 1.1 (7%) |
| MOVED: a war machine that moved | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| HELD FIRE: a target, but it held its fire | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NO TARGET IN RANGE | 2.1 (25%) | 1.2 (18%) | 3.3 (22%) |
| ONLY IN COMBAT: the only targets were in combat | 0.5 (6%) | 0.6 (9%) | 1.0 (7%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.5 (17%) | 1.3 (20%) | 2.8 (19%) |
| SHELTERED: the target was sheltered | 0.2 (2%) | 0.0 (0%) | 0.2 (1%) |
| OTHER BAR | 0.4 (4%) | 0.1 (1%) | 0.4 (3%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 5.8 | 1.5 | 82% | 5.6 pts | 33 pts |
| character | 2.2 | 0.7 | 77% | 8.0 pts | 18 pts |
| chariot | 2.0 | 1.0 | 64% | 13.5 pts | 27 pts |
| infantry | 13.4 | 5.2 | 73% | 10.1 pts | 135 pts |
| monster | 0.9 | 0.1 | 88% | 4.9 pts | 4 pts |
| war machine | 7.1 | 5.7 | 66% | 29.8 pts | 212 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.9 | 6.5 | 5.2 |
| Charges that made contact a game | 2.8 | 4.7 | 3.8 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.88 declared, 0.82 contact (17 units) | 0.44 declared, 0.38 contact (16 units) | 0.67 declared, 0.61 contact (33 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.56 declared, 0.56 contact (9 units) | 1.36 declared, 1.00 contact (14 units) | 1.04 declared, 0.83 contact (23 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.48 declared, 0.33 contact (249 units) | 0.72 declared, 0.51 contact (292 units) | 0.61 declared, 0.43 contact (541 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 62% (50 of 81) | 44% (7 of 16) | 50% (3 of 6) | 58% (60 of 103) |
| Character in a unit | 84% (26 of 31) | 56% (9 of 16) | 100% (1 of 1) | 75% (36 of 48) |
| Character on its own | 88% (30 of 34) | 54% (14 of 26) | 27% (21 of 77) | 47% (65 of 137) |
| Chariot | 53% (8 of 15) | 75% (9 of 12) | - | 63% (17 of 27) |
| Infantry | 55% (46 of 83) | 28% (7 of 25) | 50% (3 of 6) | 49% (56 of 114) |
| Monster | 65% (22 of 34) | 71% (10 of 14) | - | 67% (32 of 48) |
| Monstrous | 71% (10 of 14) | 57% (8 of 14) | - | 64% (18 of 28) |
| War Machines | 81% (35 of 43) | 100% (2 of 2) | - | 82% (37 of 45) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 92% (12 of 13); on the table 92% | 25% (26 of 102) | 17% | 59% (13 of 22) | 67% (4 of 6); 2.5 uses a game | 50% (1 of 2); 0.8 uses a game | 67% (4 of 6); 1.0 uses a game |
| Chaos Dwarfs | 4 | 40% (2 of 5); on the table 60% | 33% (8 of 24) | 38% | 78% (25 of 32) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
| Dwarfen Mountain Holds | 3 | 100% (3 of 3); on the table 100% | - | 72% | 70% (19 of 27) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 6 | 71% (5 of 7); on the table 86% | 50% (9 of 18) | 54% | 74% (46 of 62) | 0.0 uses a game | 50% (1 of 2); 0.7 uses a game | 100% (5 of 5); 0.8 uses a game |
| Grand Cathay | 4 | 100% (17 of 17); on the table 100% | 20% (17 of 84) | 42% | 49% (18 of 37) | 89% (8 of 9); 5.8 uses a game | 0% (0 of 2); 0.0 uses a game | 50% (2 of 4); 0.5 uses a game |
| High Elf Realms | 9 | 100% (12 of 12); on the table 100% | 19% (7 of 36) | 32% | 49% (34 of 70) | 100% (7 of 7); 3.0 uses a game | 30% (9 of 30); 1.3 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | 100% (2 of 2); on the table 100% | - | 49% | 17% (1 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Lizardmen | 3 | 88% (15 of 17); on the table 88% | 100% (6 of 6) | 24% | 52% (11 of 21) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 2 | 100% (5 of 5); on the table 100% | 33% (2 of 6) | 37% | 93% (13 of 14) | 50% (1 of 2); 1.5 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 3 | 100% (7 of 7); on the table 100% | 29% (12 of 42) | 13% | 33% (8 of 24) | 0.0 uses a game | 0.0 uses a game | 67% (2 of 3); 0.7 uses a game |
| Skaven | 6 | 92% (12 of 13); on the table 100% | 30% (12 of 40) | 56% | 67% (30 of 45) | 100% (3 of 3); 1.2 uses a game | 0.0 uses a game | 67% (4 of 6); 0.7 uses a game |
| Tomb Kings of Khemri | 4 | 78% (7 of 9); on the table 78% | 0% (0 of 6) | 32% | 45% (9 of 20) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 8 | 93% (13 of 14); on the table 93% | 37% (22 of 59) | 31% | 52% (22 of 42) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 9 | 96% (24 of 25); on the table 96% | 25% (3 of 12) | 26% | 56% (40 of 72) | 100% (2 of 2); 0.7 uses a game | 0.0 uses a game | 100% (3 of 3); 0.3 uses a game |
| Wood Elf Realms | 6 | 88% (15 of 17); on the table 88% | 83% (5 of 6) | 37% | 57% (32 of 56) | 50% (1 of 2); 0.2 uses a game | 0.0 uses a game | 50% (2 of 4); 0.3 uses a game |

Flank and rear charges a unit could have turned to face (jc-mine-1e5408d-p4, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 50% (50) | 35% (22) | 44% (72) |
| ...free all their last turn and able to turn (per game) | 0.69 | 0.36 | 1.06 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.33 | 0.11 | 0.44 |
| ...with the charger already in that arc before they moved (per game) | 0.42 | 0.33 | 0.75 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 1.50 | 1.06 | 2.56 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 1.11 | 0.53 | 1.64 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 5.17 | 5.94 | 11.11 |

### Quality by phase: jc-mine-1e5408d-p4

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.1 | 3.6 |
| Strategy | Charge objectives carried out (made contact) | 48% (57 of 119) | 50% (97 of 195) |
| Strategy | Shoot objectives carried out (shot that target) | 44% (185 of 423) | 43% (85 of 196) |
| Strategy | Close-in objectives charged next turn | 10% (18 of 179) | 15% (34 of 230) |
| Strategy | Support requests answered (helper made contact too) | 41% (11 of 27) | 52% (16 of 31) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 75% (3 of 4) | 100% (1 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | 47% (7 of 15) | 100% (8 of 8) |
| Strategy | Joined characters whose unit fought | 50% (18 of 36) | 38% (13 of 34) |
| Strategy | Lone characters that fought | 70% (61 of 87) | 80% (66 of 82) |
| Movement | Charges halted short of contact | 0.1 | 0.4 |
| Movement | Idle units | 1.4 | 1.9 |
| Movement | Points that never moved of their own | 329.2 | 114.6 |
| Movement | Fights charged into per game | 2.6 | 3.9 |
| Movement | Charges with odds: long shots (under 50%) | 13 of 83, net +132 | 27 of 121, net +28 |
| Movement | Charges with odds: sweet spot (55-75%) | 7 of 83, net -33 | 26 of 121, net +50 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 12 of 83, net +65 | 14 of 121, net +124 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 21 of 83, net +68 | 28 of 121, net +112 |
| Shooting | Shots by shooting units (incl. breath weapons) | 10.8 | 9.2 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 49% (191 of 390) | 43% (142 of 330) |
| Shooting | Points destroyed by shooting units | 76.0 | 42.1 |
| Shooting | War machine shots | 6.6 | 0.5 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 63% (150 of 237) | 16% (3 of 19) |
| Shooting | Points destroyed by war machines | 68.6 | 3.3 |
| Magic | Magic missiles cast | 1.3 | 1.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 41% (19 of 46) | 30% (13 of 43) |
| Magic | Wounds caused by magic missiles | 3.1 | 1.7 |
| Magic | Wounds caused by other spells | 1.9 | 1.3 |
| Magic | Points destroyed by magic (all spells) | 114.8 | 30.6 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.1 / 0.5 / 0.8 / 0.1 | 1.8 / 0.4 / 0.6 / 0.1 |
| Combat | Points destroyed in combat | 257.0 | 408.5 |
| Combat | Points run down | 95.2 | 114.8 |
| Combat | Net points per charged fight, damage counted | +67 | +87 |
| Combat | Net per 100 charger points, damage counted | +22.6 | +28.0 |
| Combat | First round won (charged fights) | 72% | 67% |
| Combat | Net points per charged fight | +55 | +90 |
| Combat | Net points per supported fight / lone fight | +38 / +59 | +95 / +89 |
| Combat | Charged fights on a top-3 enemy unit | 30 of 93 | 61 of 141 |
| Game | Points lost | 752.6 | 675.2 |
| Game | VP from objectives | 468.3 | 518.6 |
| Game | Lone holders (player turns) | 1.9 | 4.8 |

- Mine won / drew / lost: 13 / 3 / 20 of 36 ended games (of 36); mean margin (Mine - Opponent) -147 VP
- The side that went first won 13 of 33 games with a winner
- Points traded per game (both sides' losses): 1428
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: jc-mine-1e5408d-p4

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 0.8 | +0.0 | 0.0 | 4.0 |
| ADVANCE WORTH | 5.8 | -116.4 | 197.3 | 77.2 | 4.4 | -123.5 | 124.9 | 89.9 |
| ALREADY CARRIED | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARTILLERY RE-ROLL WEIGHED | 1.3 | +0.0 | 0.0 | 13.5 | 0.1 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | 0.5 | +2.4 | 0.0 | 4.7 | 0.4 | +2.5 | 0.0 | 5.4 |
| BEST FACING | 0.4 | +8.8 | 0.0 | 21.8 | 0.2 | +4.5 | 0.0 | 0.0 |
| BEST FIRST | 1.2 | +57.6 | 49.7 | 30.9 | 0.9 | +52.7 | 27.9 | 37.9 |
| BEST OVERALL | 0.3 | +19.7 | 0.0 | 4.9 | 0.2 | +6.9 | 0.0 | 13.5 |
| BEST PREY | 0.4 | +20.7 | 5.5 | 10.1 | 0.5 | +13.4 | 15.9 | 0.0 |
| BEST PRIZE | 0.1 | -3.6 | 1.8 | 6.9 | 0.1 | +2.8 | 7.9 | 0.0 |
| BIG CHARACTER SAFETY | 0.1 | -0.5 | 0.0 | 0.0 | 0.2 | -1.4 | 0.0 | 0.0 |
| BLOCKED CHARGE SKIPPED | 0.1 | +0.0 | 4.7 | 0.0 | 0.1 | +0.0 | 10.1 | 0.0 |
| BLOCKED WHEEL | 0.3 | +6.9 | 0.0 | 0.0 | 0.5 | +12.8 | 0.0 | 19.1 |
| BLOWS WHERE AIMED | 0.1 | -6.7 | 10.9 | 1.4 | 0.4 | -46.1 | 76.8 | 14.2 |
| BOMBING RUN | 0.1 | +3.1 | 0.0 | 0.0 | - | - | - | - |
| CANNON PLAN MISSED | 0.7 | +0.0 | 77.3 | 20.3 | - | - | - | - |
| CANNON PLANNED TARGET | 5.1 | +220.4 | 391.1 | 108.9 | 0.5 | +17.4 | 20.1 | 3.9 |
| CANNON SIGHT KEPT | 1.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT COUNTER | - | - | - | - | 0.0 | +0.0 | 0.0 | 16.6 |
| CARRIES OUT SET-UP | 0.1 | +0.0 | 5.1 | 22.3 | 0.2 | -6.6 | 42.8 | 4.0 |
| CAST JOB | 0.9 | +27.4 | 61.5 | 11.9 | 0.6 | +8.5 | 31.8 | 0.0 |
| CASTER AWAY FROM SCREEN | 0.3 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.3 | +23.1 | 10.3 | 8.9 | 0.1 | +3.3 | 6.5 | 0.0 |
| CASTS AFTER FRIENDS | 0.8 | +0.0 | 0.0 | 32.6 | 0.3 | +0.0 | 0.0 | 9.1 |
| CASTS FROM BEHIND | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.1 | +3.0 | 0.0 | 6.1 | - | - | - | - |
| CHAFF IN THE MOVE | 0.6 | +32.3 | 0.0 | 12.6 | 2.2 | +126.1 | 0.0 | 41.4 |
| CHAFF PASSED | 0.1 | -0.6 | 0.0 | 3.5 | 0.1 | -0.3 | 2.9 | 0.0 |
| CHARGE NOW FIRST | 2.1 | +0.0 | 214.9 | 106.4 | 2.6 | +0.0 | 294.0 | 63.6 |
| CHARGE NOW WEIGHED | 0.6 | -40.3 | 4.2 | 7.8 | 0.7 | -33.6 | 17.4 | 13.8 |
| CHARGER SLAIN LOST | 0.4 | -8.9 | 50.5 | 27.1 | 0.9 | -21.2 | 70.7 | 15.6 |
| CHARIOT WIZARD CAREFUL | 0.1 | -0.5 | 6.5 | 11.1 | 0.1 | +0.0 | 0.0 | 30.0 |
| CHEAP HELPER | - | - | - | - | 0.1 | +0.0 | 3.1 | 4.9 |
| COMBAT PIVOT | 0.3 | +0.0 | 41.3 | 23.3 | 0.4 | +0.0 | 32.7 | 56.2 |
| CONTINUE AHEAD WEIGHED | 0.1 | +0.0 | 1.8 | 7.1 | 0.0 | +0.0 | 0.0 | 9.7 |
| CONVEYANCE SEARCH | 0.7 | +52.6 | 25.8 | 32.8 | 0.3 | +51.7 | 8.2 | 0.0 |
| COVER ONCE | 8.6 | -488.9 | 0.0 | 184.5 | 6.1 | -394.5 | 0.0 | 137.6 |
| DEFENSIVE ARMY | 0.2 | -0.0 | 13.7 | 3.1 | - | - | - | - |
| DEFENSIVE FLOOR | - | - | - | - | 0.0 | +2.0 | 3.1 | 0.0 |
| EDGE GIVE GROUND | 0.1 | +1.5 | 6.0 | 0.0 | 0.3 | +6.4 | 20.1 | 4.0 |
| ELIXIR WORTH | 0.0 | +0.4 | 0.0 | 0.0 | 0.1 | +0.4 | 0.0 | 9.7 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 1.5 | +98.2 | 0.0 | 72.0 | 1.1 | +80.4 | 0.0 | 49.7 |
| FALLBACK BY WORTH | 4.5 | +60.9 | 0.0 | 93.4 | 5.8 | +52.5 | 0.0 | 77.7 |
| FIGHT LIFT | 0.1 | +1.3 | 4.0 | 0.0 | 0.0 | +0.1 | 0.0 | 0.0 |
| FIRE AND FLEE | - | - | - | - | 0.1 | +0.4 | 1.8 | 3.0 |
| FLANK NOT WEIGHED | 5.1 | +0.0 | 0.0 | 157.3 | 5.2 | +0.0 | 0.0 | 124.8 |
| FOLLOW UP WEIGHED | 0.6 | +97.8 | 0.0 | 46.0 | 0.8 | +77.6 | 0.0 | 5.3 |
| FRIEND IN REACH | 3.5 | +79.3 | 318.8 | 155.3 | 5.8 | +158.3 | 584.2 | 110.8 |
| FRIENDS SHOTS CHECKED | 0.2 | +2.9 | 0.0 | 9.0 | 0.2 | +7.5 | 0.0 | 0.8 |
| GIVES UP | 0.0 | -0.6 | 4.7 | 0.0 | 0.1 | -1.6 | 24.4 | 13.7 |
| GIVES UP ITS SCREEN | - | - | - | - | 0.0 | -0.5 | 0.0 | 1.2 |
| GROUND FLIERS | 0.0 | +0.1 | 0.0 | 0.0 | 0.1 | +1.3 | 0.0 | 3.2 |
| HELPER ALREADY ASKED | 0.0 | +0.0 | 1.2 | 0.0 | 0.0 | +0.0 | 6.1 | 3.1 |
| HELPER UNSEEN | 0.6 | +0.0 | 63.5 | 25.8 | 0.7 | +0.0 | 50.5 | 32.2 |
| HILL BY ITS CHANCE | 0.6 | -79.9 | 0.0 | 3.4 | 0.6 | -50.9 | 0.0 | 10.5 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 7.7 | -134.5 | 440.1 | 229.6 | 9.3 | -220.1 | 689.1 | 179.8 |
| HUNT ADVANCE | - | - | - | - | 0.1 | +2.5 | 2.4 | 0.0 |
| HUNT DROPPED | - | - | - | - | 0.1 | +0.0 | 0.0 | 0.0 |
| HUNT IN PAIRS | 0.2 | +4.0 | 0.0 | 0.0 | 0.4 | +24.4 | 0.0 | 0.0 |
| HUNT KEPT | - | - | - | - | 0.1 | +0.8 | 6.9 | 1.2 |
| HUNT RESULT | - | - | - | - | 0.2 | +10.8 | 3.9 | 1.2 |
| HUNT THE GUNS | - | - | - | - | 0.2 | +54.5 | 6.9 | 0.0 |
| IDLE COST | 16.9 | -276.4 | 0.0 | 219.0 | 20.3 | -327.1 | 0.0 | 203.9 |
| INVITES THE FIGHT | 1.2 | +7.6 | 25.3 | 1.7 | 0.9 | +6.1 | 17.8 | 37.0 |
| JOINT CHARGE PLAN | 0.1 | +0.1 | 0.0 | 7.8 | 0.1 | +2.0 | 0.0 | 0.0 |
| JOINT KNOWS CHALLENGE | - | - | - | - | 0.2 | -5.0 | 14.3 | 1.7 |
| KEEP FALLS | 0.1 | +1.7 | 0.0 | 0.0 | 0.0 | +0.1 | 0.0 | 0.0 |
| KEEPS ITS PREY | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |
| KEEPS ITS TARGET | 1.4 | +42.5 | 140.6 | 37.4 | 1.9 | +55.8 | 195.6 | 12.3 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KILLS COUNT | 1.4 | +56.3 | 109.1 | 68.1 | 1.9 | +90.3 | 180.7 | 20.6 |
| KILLS COUNT NEXT TURN | 5.3 | +191.8 | 296.5 | 115.3 | 6.4 | +279.8 | 276.1 | 131.2 |
| LONE CHARACTER SAFE SPOT | 0.3 | +9.6 | 4.7 | 2.5 | 0.1 | +7.9 | 0.0 | 0.0 |
| LONE WIZARD HOLDS BACK | 0.0 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 5.2 | 10.7 |
| LONE WIZARD KEPT IN | 0.6 | +26.9 | 0.0 | 0.0 | 0.2 | +20.3 | 0.0 | 0.0 |
| LONG SHOT | 0.3 | +1.9 | 17.3 | 12.8 | 0.5 | -0.5 | 11.5 | 6.0 |
| LOST CHARGE | 2.8 | -27.0 | 90.8 | 64.8 | 1.6 | -26.7 | 50.1 | 60.5 |
| LURE BY WHAT IT DRAWS | 0.1 | -11.5 | 0.0 | 0.0 | 0.2 | -20.1 | 0.0 | 10.4 |
| MAKE SURE TOGETHER | 0.8 | +68.1 | 5.3 | 20.3 | 0.8 | +43.3 | 17.5 | 13.2 |
| MANOEUVRE | 0.3 | +14.5 | 0.0 | 12.1 | 0.0 | +0.5 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.2 | 0.0 | 5.4 |
| MARCH CHECK | 0.4 | +11.5 | 0.0 | 0.0 | 0.3 | +10.4 | 0.0 | 3.2 |
| MARCH ODDS | 0.2 | +10.7 | 1.5 | 12.1 | 0.3 | +14.6 | 8.9 | 0.0 |
| MARCH OVER CASTS | 0.5 | +17.2 | 0.0 | 50.7 | 0.3 | +17.2 | 0.0 | 5.4 |
| MAX FOR POSITIONING | 5.1 | +92.8 | 0.0 | 129.0 | 6.1 | +71.1 | 0.0 | 122.8 |
| MISSILES IN THE MOVE | 3.6 | +132.1 | 0.0 | 86.3 | 2.3 | +41.4 | 0.0 | 86.3 |
| MISSILES NEXT TURN | 4.2 | +82.1 | 0.0 | 150.4 | 2.9 | +26.5 | 0.0 | 81.8 |
| MODEL FACING | 0.2 | +51.1 | 0.0 | 5.0 | - | - | - | - |
| MONSTER WIZARD ROAMS | 0.2 | +0.0 | 5.3 | 5.7 | 0.2 | +0.0 | 10.5 | 0.0 |
| MOVE AND CAST | 0.2 | +2.3 | 0.0 | 4.5 | 0.2 | +13.4 | 0.0 | 0.0 |
| MOVE SPELL IN RANGE | 0.2 | +4.3 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL NOT WORTH | - | - | - | - | 0.0 | -0.0 | 0.0 | 0.0 |
| MOVE SPELL OUT OF RANGE | 0.4 | -32.0 | 20.2 | 42.8 | 0.0 | -0.2 | 0.0 | 2.6 |
| MOVE SPELL SPOT | 0.5 | +0.0 | 0.0 | 10.2 | 0.1 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE | 3.4 | +161.4 | 185.1 | 83.4 | 4.7 | +330.0 | 277.5 | 104.0 |
| MOVES UNITS SPELL | 0.1 | +3.3 | 0.0 | 0.0 | 0.1 | +0.6 | 0.0 | 0.0 |
| NEEDED THERE | 0.1 | +5.9 | 0.0 | 0.0 | 0.1 | +7.6 | 11.3 | 0.0 |
| NO RALLY LEFT | 0.0 | +0.8 | 0.0 | 0.0 | - | - | - | - |
| NOT NEEDED | - | - | - | - | 0.3 | -18.1 | 43.7 | 3.1 |
| NOT TURNED | 5.2 | +41.9 | 0.0 | 116.7 | 5.9 | +94.3 | 0.0 | 129.3 |
| NOT WORTH A CAST | 0.5 | -0.4 | 0.0 | 33.9 | 0.4 | -0.2 | 0.0 | 0.0 |
| OFF BEST | 15.7 | -712.8 | 6.2 | 219.4 | 15.5 | -738.0 | 28.1 | 237.4 |
| ONE FIGHT FORMULA | 8.6 | -153.1 | 15.6 | 169.5 | 8.2 | -169.3 | 16.1 | 173.2 |
| ONE OBJECTIVE FORMULA | 2.2 | -140.4 | 0.0 | 28.7 | 2.2 | -166.2 | 0.0 | 61.1 |
| OPENS A LANE | 0.2 | +1.6 | 18.6 | 0.0 | - | - | - | - |
| OPENS UP | 0.2 | +15.4 | 10.6 | 0.0 | 0.3 | +39.2 | 10.1 | 23.4 |
| OVERRUNS AWAY | 0.4 | +12.6 | 63.2 | 37.5 | 0.8 | +18.9 | 81.7 | 23.1 |
| PAIR SET-UP | 0.1 | +0.0 | 0.0 | 22.6 | 0.1 | +0.0 | 0.0 | 0.0 |
| PATHS CROSS | 2.2 | +156.8 | 0.0 | 35.2 | 3.0 | +225.7 | 0.0 | 55.1 |
| PERIAPT WORTH | 0.0 | +3.4 | 0.0 | 0.0 | 0.1 | +6.1 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.1 | -1.0 | 0.0 | 0.0 | 0.1 | -3.5 | 0.0 | 15.0 |
| PLAN RESULT | 38.4 | +1569.3 | 1713.4 | 1082.1 | 39.6 | +1290.5 | 1725.8 | 976.2 |
| PURSUES BIG PREY | 0.1 | -2.4 | 0.0 | 0.0 | 0.1 | -1.6 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE NEXT TURN | 0.1 | +7.2 | 0.0 | 2.2 | 0.1 | +8.2 | 0.0 | 0.0 |
| RANDOM MOVE BY FIGURES | 1.3 | +21.6 | 0.0 | 22.6 | 1.8 | +20.2 | 0.0 | 51.8 |
| RANDOM MOVER NO PROMISE | 0.2 | -8.0 | 22.5 | 4.0 | 0.3 | -9.6 | 6.7 | 12.8 |
| REDIRECT BY WHAT IT STOPS | 0.6 | -9.5 | 0.0 | 11.7 | 1.9 | -48.4 | 0.0 | 28.9 |
| REDIRECT COUNTER | 1.9 | +100.2 | 0.0 | 37.6 | 3.7 | +223.5 | 0.0 | 52.9 |
| REDIRECT WEIGHED | 0.2 | +0.6 | 1.8 | 0.8 | 0.5 | +27.8 | 24.5 | 14.9 |
| REFUSING RETIRES | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 13.9 |
| RESERVE FALL BACK | 0.4 | +15.6 | 0.0 | 8.3 | 0.5 | +23.4 | 0.0 | 11.4 |
| RESTRAINS TO SHOOT | 0.1 | +9.5 | 0.0 | 0.0 | 0.1 | +3.4 | 0.0 | 0.0 |
| RISK BY ARC | 2.3 | +106.9 | 218.4 | 140.0 | 2.6 | +61.5 | 272.5 | 86.9 |
| RISK ONCE | 2.1 | +56.7 | 14.6 | 89.9 | 4.2 | +131.8 | 73.2 | 229.1 |
| SAFE SURE CHARGE | - | - | - | - | 0.0 | -0.8 | 0.0 | 0.0 |
| SAFER THAN THE JOB | 1.1 | +71.1 | 0.0 | 16.7 | 0.5 | +19.3 | 0.0 | 9.3 |
| SCOUT SPOT | 0.4 | +0.5 | 0.0 | 0.9 | 0.1 | +0.0 | 0.0 | 1.8 |
| SCOUT WAITS | 0.5 | +0.0 | 0.0 | 0.9 | 0.1 | +0.0 | 0.0 | 1.8 |
| SCREEN BY WHAT IT SAVES | 0.1 | -12.1 | 0.0 | 0.8 | 0.4 | -27.3 | 0.0 | 0.8 |
| SEARCH SPOT | 2.3 | +103.1 | 0.0 | 30.3 | 2.6 | +81.1 | 0.0 | 37.4 |
| SECOND CHARGER ADDS | 0.2 | -27.3 | 28.2 | 20.3 | - | - | - | - |
| SELF MOVE SPELL | 0.2 | +44.0 | 0.0 | 0.0 | 0.4 | +31.2 | 0.0 | 18.1 |
| SET UP TOGETHER | 0.9 | +70.1 | 27.2 | 20.3 | 1.6 | +94.0 | 48.5 | 16.1 |
| SET-UP ANY TARGET | 0.4 | +59.9 | 19.3 | 21.5 | 0.1 | +14.1 | 8.2 | 0.0 |
| SET-UP MISSED | 0.0 | +4.0 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | 0.3 | +0.8 | 0.0 | 0.0 | 0.2 | +0.3 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.3 | +47.7 | 35.2 | 11.6 | 1.2 | +30.7 | 45.6 | 13.3 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 3.8 |
| SHOT REPLANNED | 0.4 | +0.0 | 81.5 | 21.8 | 0.2 | +0.0 | 17.3 | 4.5 |
| SHOTS IN THE MOVE | 15.5 | +633.1 | 0.0 | 283.8 | 7.7 | +203.4 | 0.0 | 88.7 |
| SPELL CATCH ODDS | 0.1 | -0.9 | 0.0 | 0.0 | 0.0 | -0.3 | 0.0 | 0.0 |
| SPELL SETS UP CHARGE | 0.4 | +66.7 | 19.3 | 21.5 | 0.2 | +41.8 | 8.2 | 0.0 |
| SPELL WORTH | 1.2 | +19.8 | 91.1 | 91.9 | 2.3 | +40.6 | 45.0 | 47.6 |
| SPELLS IN THE FIGHT | 0.5 | -1.9 | 86.9 | 49.4 | 0.9 | -6.3 | 163.7 | 11.8 |
| STABLE ROLE | 10.8 | +0.0 | 451.1 | 234.2 | 9.5 | +0.0 | 372.5 | 185.3 |
| STANDS TO CAST | - | - | - | - | 0.0 | +0.8 | 0.0 | 0.0 |
| STAY WEIGHED | 0.2 | +15.6 | 0.0 | 0.0 | - | - | - | - |
| STOPS | - | - | - | - | 0.1 | +2.7 | 6.9 | 0.0 |
| STOPS SHORT OF THE FLANK | 0.5 | +30.2 | 0.0 | 0.0 | 0.3 | +7.6 | 0.0 | 4.0 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| SUPPORT NARROWED | 6.2 | -61.0 | 346.1 | 138.9 | 7.6 | -64.5 | 340.3 | 121.4 |
| SUPPORTS | 4.4 | +62.8 | 194.1 | 72.2 | 5.2 | +66.4 | 113.2 | 64.5 |
| SURE CHARGE BEATS ADVANCE | 0.1 | -1.7 | 0.0 | 1.4 | 0.0 | -0.7 | 5.8 | 0.0 |
| SURE REACH TOGETHER | 0.3 | +3.5 | 0.0 | 10.7 | 0.6 | +0.4 | 10.1 | 24.6 |
| THROUGH LINE OF FIRE | 0.2 | +12.9 | 0.0 | 5.7 | 0.3 | +8.7 | 0.0 | 1.9 |
| TURN WORTH | 0.4 | -33.6 | 37.3 | 0.0 | 0.1 | -3.8 | 2.3 | 9.7 |
| TWO OR MORE ARRIVE | 0.2 | +0.7 | 10.9 | 0.0 | 0.5 | +2.6 | 0.0 | 5.2 |
| WAIT AFTER COSTS | 6.7 | -276.8 | 273.3 | 114.3 | 7.5 | -397.6 | 368.6 | 157.2 |
| WALKS TO THE FIGHT | 1.7 | +11.4 | 35.1 | 44.1 | 0.8 | +6.2 | 41.9 | 4.4 |
| WAR ENGINE CHARGES | 0.2 | +9.5 | 4.1 | 10.3 | 0.0 | +1.5 | 0.0 | 0.0 |
| WAR ENGINE JOBS | 0.8 | +0.0 | 33.4 | 13.8 | 0.1 | +0.0 | 7.4 | 0.0 |
| WEARS DOWN | 1.0 | +32.3 | 133.4 | 66.9 | 1.8 | +56.3 | 207.8 | 41.1 |
| WHO HITS BACK | 0.2 | +14.1 | 0.0 | 8.2 | 0.2 | +14.3 | 0.0 | 4.7 |
| WHOLE FIGHT | 0.2 | +7.2 | 11.5 | 0.0 | 0.6 | +48.6 | 90.0 | 1.7 |
| WHOLE FIGHT GAIN | 0.7 | +32.3 | 61.5 | 29.3 | 0.8 | +58.8 | 58.3 | 9.8 |
| WIDER SPREAD | 2.2 | -8.4 | 204.5 | 102.2 | 3.6 | -3.0 | 373.4 | 70.4 |
| WOUNDED STAYS OUT | - | - | - | - | 0.0 | +0.0 | 6.5 | 3.5 |

### Rule changes: jc-mine-1e5408d-p4

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 1125 | 1125 | 1125 | 31.25 | -52227 | -46.4 |
| PATHS CROSS | 190 | 190 | 190 | 5.28 | +13770 | +72.5 |
| SEARCH SPOT | 175 | 175 | 170 | 4.72 | +6658 | +39.2 |
| MOVE TO CHARGE | 293 | 293 | 168 | 4.67 | +6078 | +36.2 |
| KILLS COUNT NEXT TURN | 422 | 422 | 151 | 4.19 | +4960 | +32.8 |
| SUPPORTS | 347 | 347 | 146 | 4.06 | +1630 | +11.2 |
| WAIT AFTER COSTS | 511 | 511 | 98 | 2.72 | +1455 | +14.8 |
| FACES THE THREAT | 92 | 92 | 92 | 2.56 | +6431 | +69.9 |
| SHOTS IN THE MOVE | 835 | 597 | 86 | 2.39 | +1567 | +18.2 |
| COVER ONCE | 528 | 310 | 82 | 2.28 | +1333 | +16.3 |
| BEST FIRST | 76 | 76 | 76 | 2.11 | +3972 | +52.3 |
| RANDOM MOVE BY FIGURES | 113 | 113 | 71 | 1.97 | +1506 | +21.2 |
| FALLBACK BY WORTH | 370 | 370 | 64 | 1.78 | +4083 | +63.8 |
| ADVANCE WORTH | 366 | 366 | 62 | 1.72 | +2482 | +40.0 |
| CHAFF IN THE MOVE | 103 | 101 | 60 | 1.67 | +1836 | +30.6 |
| ONE FIGHT FORMULA | 608 | 376 | 59 | 1.64 | +191 | +3.2 |
| SAFER THAN THE JOB | 59 | 59 | 59 | 1.64 | +3256 | +55.2 |
| ADVANCE LANE KEPT | 55 | 55 | 55 | 1.53 | +0 | +0.0 |
| IDLE COST | 1338 | 756 | 54 | 1.50 | +642 | +11.9 |
| FOLLOW UP WEIGHED | 53 | 53 | 53 | 1.47 | +6312 | +119.1 |
| ARTILLERY RE-ROLL WEIGHED | 50 | 50 | 50 | 1.39 | +0 | +0.0 |
| RISK ONCE | 225 | 179 | 47 | 1.31 | +1843 | +39.2 |
| CHARGE NOW WEIGHED | 45 | 45 | 45 | 1.25 | +2412 | +53.6 |
| REDIRECT COUNTER | 199 | 103 | 45 | 1.25 | +2649 | +58.9 |
| CANNON SIGHT KEPT | 42 | 42 | 42 | 1.17 | +0 | +0.0 |
| SET UP TOGETHER | 90 | 74 | 41 | 1.14 | +1966 | +48.0 |
| HONEST WORTH | 611 | 606 | 39 | 1.08 | +297 | +7.6 |
| SHOOTS FROM THE BEST SPOT | 90 | 90 | 39 | 1.08 | +975 | +25.0 |
| WALKS TO THE FIGHT | 91 | 91 | 39 | 1.08 | +191 | +4.9 |
| MISSILES IN THE MOVE | 210 | 153 | 38 | 1.06 | +1054 | +27.7 |
| HOLDS AMBUSHERS | 35 | 35 | 35 | 0.97 | +0 | +0.0 |
| RESERVE FALL BACK | 35 | 35 | 35 | 0.97 | +1404 | +40.1 |
| RISK BY ARC | 177 | 173 | 31 | 0.86 | +977 | +31.5 |
| CHARGE NOW FIRST | 170 | 170 | 29 | 0.81 | -1705 | -58.8 |
| BLOCKED WHEEL | 28 | 28 | 28 | 0.78 | +709 | +25.3 |
| LONE WIZARD KEPT IN | 28 | 28 | 28 | 0.78 | +1699 | +60.7 |
| STOPS SHORT OF THE FLANK | 27 | 27 | 27 | 0.75 | +1358 | +50.3 |
| COMBAT PIVOT | 26 | 26 | 26 | 0.72 | +0 | +0.0 |
| INVITES THE FIGHT | 77 | 77 | 26 | 0.72 | +94 | +3.6 |
| CANNON PLANNED TARGET | 203 | 203 | 25 | 0.69 | -404 | -16.1 |
| REDIRECT WEIGHED | 25 | 25 | 25 | 0.69 | +1382 | +55.3 |
| KILLS COUNT | 116 | 112 | 24 | 0.67 | +982 | +40.9 |
| WHOLE FIGHT GAIN | 53 | 49 | 24 | 0.67 | +1196 | +49.8 |
| BEST FACING | 23 | 23 | 23 | 0.64 | +480 | +20.9 |
| CAST JOB | 53 | 53 | 23 | 0.64 | +471 | +20.5 |
| MARCH CHECK | 23 | 23 | 22 | 0.61 | +1325 | +60.2 |
| MAX FOR POSITIONING | 403 | 249 | 22 | 0.61 | +147 | +6.7 |
| SHOT REPLANNED | 22 | 22 | 22 | 0.61 | +0 | +0.0 |
| SCOUT WAITS | 21 | 21 | 21 | 0.58 | +0 | +0.0 |
| KEEPS ITS TARGET | 118 | 118 | 20 | 0.56 | +456 | +22.8 |
| BEST OVERALL | 18 | 18 | 18 | 0.50 | +959 | +53.3 |
| MAKE SURE TOGETHER | 59 | 35 | 18 | 0.50 | +1012 | +56.2 |
| MARCH ODDS | 18 | 18 | 18 | 0.50 | +80 | +4.4 |
| SHOOTERS IN TWO RANKS | 18 | 18 | 18 | 0.50 | +41 | +2.3 |
| CASTER AWAY FROM SCREEN | 17 | 17 | 17 | 0.47 | +0 | +0.0 |
| MOVE AND CAST | 17 | 17 | 17 | 0.47 | +568 | +33.4 |
| STUCK PIVOT | 17 | 17 | 17 | 0.47 | +0 | +0.0 |
| THROUGH LINE OF FIRE | 16 | 16 | 16 | 0.44 | +780 | +48.7 |
| WEARS DOWN | 100 | 95 | 16 | 0.44 | +590 | +36.9 |
| WHO HITS BACK | 16 | 16 | 16 | 0.44 | +812 | +50.8 |
| WAR ENGINE JOBS | 32 | 32 | 14 | 0.39 | -491 | -35.1 |
| FRIENDS SHOTS CHECKED | 13 | 13 | 13 | 0.36 | +373 | +28.7 |
| BIG CHARACTER SAFETY | 12 | 12 | 12 | 0.33 | -67 | -5.6 |
| MISSILES NEXT TURN | 258 | 176 | 12 | 0.33 | +12 | +1.0 |
| CASTS FROM BEHIND | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| MANOEUVRE | 12 | 12 | 9 | 0.25 | +541 | +60.1 |
| MODEL FACING | 9 | 9 | 9 | 0.25 | +1840 | +204.5 |
| OPENS UP | 18 | 18 | 9 | 0.25 | +374 | +41.6 |
| SHORT GUN FORWARD | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| SUPPORT NARROWED | 498 | 498 | 9 | 0.25 | -270 | -30.0 |
| WHOLE FIGHT | 27 | 27 | 9 | 0.25 | +1127 | +125.2 |
| BEST PREY | 33 | 33 | 8 | 0.22 | +159 | +19.9 |
| BEST PRIZE | 8 | 8 | 8 | 0.22 | -346 | -43.3 |
| CASTING BLOCK | 14 | 14 | 8 | 0.22 | +196 | +24.6 |
| LOST CHARGE | 158 | 157 | 8 | 0.22 | +142 | +17.8 |
| RESTRAINS TO SHOOT | 8 | 8 | 8 | 0.22 | +464 | +58.0 |
| WIDER SPREAD | 211 | 202 | 8 | 0.22 | +20 | +2.4 |
| BLOCKED CHARGE SKIPPED | 7 | 7 | 7 | 0.19 | +0 | +0.0 |
| CHAFF PASSED | 7 | 7 | 7 | 0.19 | -30 | -4.4 |
| MOVES UNITS SPELL | 7 | 7 | 7 | 0.19 | +138 | +19.7 |
| PIVOT GUARDS FLANK | 6 | 6 | 6 | 0.17 | -160 | -26.8 |
| RAIDS THE BAGGAGE NEXT TURN | 6 | 6 | 6 | 0.17 | +249 | +41.4 |
| STAY WEIGHED | 6 | 6 | 6 | 0.17 | +560 | +93.3 |
| EDGE GIVE GROUND | 14 | 13 | 5 | 0.14 | +120 | +24.1 |
| LONG SHOT | 31 | 31 | 5 | 0.14 | -7 | -1.5 |
| NEEDED THERE | 5 | 5 | 5 | 0.14 | +0 | +0.0 |
| OVERRUNS AWAY | 43 | 43 | 5 | 0.14 | +126 | +25.3 |
| BACKUP TARGETS | 33 | 16 | 4 | 0.11 | +18 | +4.6 |
| KEEP FALLS | 4 | 4 | 4 | 0.11 | +104 | +26.1 |
| PERIAPT WORTH | 4 | 4 | 4 | 0.11 | +341 | +85.2 |
| PURSUES BIG PREY | 4 | 4 | 4 | 0.11 | -144 | -35.9 |
| BOMBING RUN | 3 | 3 | 3 | 0.08 | +112 | +37.4 |
| CONTINUE AHEAD WEIGHED | 3 | 3 | 3 | 0.08 | +0 | +0.0 |
| ELIXIR WORTH | 3 | 3 | 3 | 0.08 | +30 | +10.1 |
| HUNT IN PAIRS | 23 | 9 | 3 | 0.08 | +40 | +13.2 |
| ONE OBJECTIVE FORMULA | 159 | 67 | 3 | 0.08 | +92 | +30.8 |
| SPELLS IN THE FIGHT | 48 | 46 | 3 | 0.08 | +24 | +8.2 |
| STOPS | 5 | 5 | 3 | 0.08 | +10 | +3.3 |
| SURE CHARGE BEATS ADVANCE | 3 | 3 | 3 | 0.08 | -89 | -29.5 |
| SURE REACH TOGETHER | 35 | 24 | 3 | 0.08 | +19 | +6.2 |
| CARRIES OUT SET-UP | 12 | 12 | 2 | 0.06 | -239 | -119.5 |
| CHARGER SLAIN LOST | 47 | 44 | 2 | 0.06 | +179 | +89.3 |
| FIRE AND FLEE | 2 | 2 | 2 | 0.06 | +14 | +6.9 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| REFUSING RETIRES | 13 | 13 | 2 | 0.06 | -0 | -0.2 |
| WAR ENGINE CHARGES | 7 | 7 | 2 | 0.06 | +146 | +73.0 |
| DEFENSIVE FLOOR | 1 | 1 | 1 | 0.03 | +14 | +13.5 |
| HUNT ADVANCE | 4 | 4 | 1 | 0.03 | +29 | +29.1 |
| JOINT CHARGE PLAN | 4 | 4 | 1 | 0.03 | +22 | +21.5 |
| LONE WIZARD HOLDS BACK | 9 | 9 | 1 | 0.03 | -119 | -119.3 |
| NO RALLY LEFT | 1 | 1 | 1 | 0.03 | +8 | +7.8 |
| SAFE SURE CHARGE | 1 | 1 | 1 | 0.03 | -27 | -27.2 |
| STANDS TO CAST | 1 | 1 | 1 | 0.03 | +5 | +5.1 |
| TWO OR MORE ARRIVE | 26 | 24 | 1 | 0.03 | +0 | +0.3 |
| ALREADY CARRIED | 1 | not checked | - | - | - | - |
| BLOWS WHERE AIMED | 17 | 16 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 26 | 26 | 0 | 0.00 | - | - |
| CARRIES OUT COUNTER | 1 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 39 | trace | - | - | - | - |
| CATCH FLIERS | 3 | not checked | - | - | - | - |
| CHARIOT WIZARD CAREFUL | 6 | 6 | 0 | 0.00 | - | - |
| CHEAP HELPER | 3 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 38 | not checked | - | - | - | - |
| DEFENSIVE ARMY | 8 | 8 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT LIFT | 6 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 370 | not checked | - | - | - | - |
| FRIEND IN REACH | 335 | not checked | - | - | - | - |
| GIVES UP | 5 | 5 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 1 | 1 | 0 | 0.00 | - | - |
| GROUND FLIERS | 4 | not checked | - | - | - | - |
| HELPER ALREADY ASKED | 2 | not checked | - | - | - | - |
| HELPER UNSEEN | 47 | 44 | 0 | 0.00 | - | - |
| HILL BY ITS CHANCE | 43 | 43 | 0 | 0.00 | - | - |
| HUNT DROPPED | 4 | trace | - | - | - | - |
| HUNT KEPT | 3 | trace | - | - | - | - |
| HUNT RESULT | 7 | trace | - | - | - | - |
| HUNT THE GUNS | 7 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 6 | 6 | 0 | 0.00 | - | - |
| KEEPS ITS PREY | 1 | 1 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 16 | not checked | - | - | - | - |
| LURE BY WHAT IT DRAWS | 9 | 9 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 4 | trace | - | - | - | - |
| MARCH OVER CASTS | 31 | 31 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 13 | 13 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 6 | 2 | 0 | 0.00 | - | - |
| MOVE SPELL NOT WORTH | 1 | not checked | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 17 | trace | - | - | - | - |
| MOVE SPELL SPOT | 22 | not checked | - | - | - | - |
| NOT NEEDED | 12 | 12 | 0 | 0.00 | - | - |
| NOT TURNED | 400 | 400 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 32 | not checked | - | - | - | - |
| OPENS A LANE | 7 | 2 | 0 | 0.00 | - | - |
| PAIR SET-UP | 6 | not checked | - | - | - | - |
| PLAN RESULT | 2805 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 19 | 19 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 90 | 90 | 0 | 0.00 | - | - |
| SCOUT SPOT | 19 | 19 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 19 | 19 | 0 | 0.00 | - | - |
| SECOND CHARGER ADDS | 9 | 9 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 22 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 18 | not checked | - | - | - | - |
| SET-UP MISSED | 1 | trace | - | - | - | - |
| SPELL CATCH ODDS | 3 | not checked | - | - | - | - |
| SPELL SETS UP CHARGE | 23 | not checked | - | - | - | - |
| SPELL WORTH | 126 | not checked | - | - | - | - |
| STABLE ROLE | 732 | 730 | 0 | 0.00 | - | - |
| TURN WORTH | 16 | 16 | 0 | 0.00 | - | - |
| WOUNDED STAYS OUT | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: jc-mine-1e5408d-p4

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 14.50 | 13.97 | 48.0 |
| FALLBACK | gate | 0.47 | 0.69 | 31.7 |
| TURN GATE | gate | 0.50 | 0.47 | 28.6 |
| CHARGE NOW FIRST | rule | 0.31 | 0.50 | 58.8 |
| WAR ENGINE JOBS | rule | 0.31 | 0.08 | 35.1 |
| CANNON PLANNED TARGET | rule | 0.31 | 0.03 | 39.2 |
| SUPPORT NARROWED | rule | 0.06 | 0.19 | 30.0 |
| BEST PRIZE | rule | 0.11 | 0.11 | 43.3 |
| BIG CHARACTER SAFETY | rule | 0.08 | 0.11 | 10.7 |
| FIGHT ORDER BAND | gate | 0.08 | 0.11 | 2.4 |
| PATHS CROSS | rule | 0.11 | 0.08 | 31.7 |
| PIVOT GUARDS FLANK | rule | 0.08 | 0.08 | 26.8 |
| SUPPORT REQUEST | gate | 0.03 | 0.14 | 63.9 |
| AFTERMATH BAND | gate | 0.06 | 0.06 | 2.9 |
| CHARGE NOW WEIGHED | rule | 0.11 | - | 10.3 |
| MARCH ODDS | rule | 0.08 | 0.03 | 32.2 |
| PURSUES BIG PREY | rule | 0.06 | 0.06 | 35.9 |
| STOPS SHORT OF THE FLANK | rule | 0.06 | 0.06 | 4.8 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.06 | 0.03 | 82.7 |
| LONE CHARACTER SAFE SPOT | gate | 0.03 | 0.06 | 23.6 |
| SURE CHARGE BEATS ADVANCE | rule | 0.06 | 0.03 | 29.5 |
| CARRIES OUT SET-UP | rule | - | 0.06 | 119.5 |
| CHAFF PASSED | rule | 0.03 | 0.03 | 15.2 |
| FACES THE THREAT | rule | - | 0.06 | 20.7 |
| REDIRECT WEIGHED | rule | - | 0.06 | 71.4 |
| FRIENDS SHOTS CHECKED | rule | 0.03 | - | 1.4 |
| LONE WIZARD HOLDS BACK | rule | - | 0.03 | 119.3 |
| LONG SHOT | rule | - | 0.03 | 36.7 |
| SAFE SURE CHARGE | rule | - | 0.03 | 27.2 |
| SAFER THAN THE JOB | rule | 0.03 | - | 13.9 |

### Plans: jc-mine-1e5408d-p4

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 10.2 | 17% | 184 | 327 | 178% |
| Mine | charge | 2.7 | 59% | 205 | 237 | 115% |
| Mine | close in | 4.9 | 29% | 220 | 222 | 101% |
| Mine | hold | 5.0 | 31% | 316 | 0 | 0% |
| Mine | join | 0.5 | 95% | 10 | 0 | 0% |
| Mine | shoot | 9.8 | 59% | 368 | 784 | 213% |
| Mine | support | 5.2 | 91% | 48 | 0 | 0% |
| Opponent | advance | 11.7 | 17% | 178 | 352 | 197% |
| Opponent | charge | 4.7 | 58% | 406 | 469 | 116% |
| Opponent | close in | 6.3 | 26% | 366 | 237 | 65% |
| Opponent | hold | 4.6 | 34% | 311 | 0 | 0% |
| Opponent | join | 0.6 | 91% | 25 | 0 | 0% |
| Opponent | shoot | 4.2 | 62% | 70 | 241 | 343% |
| Opponent | support | 7.4 | 91% | 45 | 0 | 0% |

### Packages: hunt the guns, jc-mine-1e5408d-p4

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 5 |
| Opponent | 0.2 | 7 | 0 | 29% | 29% | 0% | 3.0 | 280 | 55 | 29% | 86 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 20 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 88 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| High Elf Realms | 0.1 | 1 | 0 | 100% | 100% | 0% | 3.0 | 109 | 97 | 100% | 41 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 58 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 195 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 149 |
| Tomb Kings of Khemri | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Vampire Counts | 0.6 | 5 | 0 | 20% | 20% | 0% | 3.0 | 325 | 58 | 20% | 0 |
| Warriors of Chaos | 0.1 | 1 | 0 | 0% | 0% | 0% | - | 228 | 0 | 0% | 74 |
| Wood Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |

### Battle groups: jc-mine-1e5408d-p4

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 1.9 | 45% | 63% | 13% | 25% | 19% | 0% | 8% | 62% | 12% |
| Opponent | REDIRECT COUNTER | 3.7 | 21% | 79% | 29% | 25% | 0% | 5% | 20% | 75% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: jc-mine-1e5408d-p4

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 4 | 0 (4) | 0 | 0 | 0 | 25% | 2.0 | - | 0 (4) | - | - | 0 (4) |
| Mine | Chaff | 34 | 47 (34) | 15 | 31 | 57 | 26% | 2.5 | 9 (14) | 35 (7) | 88 (13) | 24 (22) | 90 (12) |
| Mine | Character | 106 | 41 (106) | 41 | 0 | 39 | 21% | 2.3 | 52 (28) | 41 (53) | 4 (7) | 33 (39) | 50 (49) |
| Mine | Clean-up | 22 | 63 (22) | 40 | 23 | 44 | 27% | 2.9 | 0 (2) | 65 (16) | 87 (4) | 97 (10) | 45 (12) |
| Mine | Early | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Mine | Fast | 4 | 65 (4) | 65 | 0 | 100 | 25% | 3.7 | 0 (2) | 131 (2) | - | 0 (3) | 243 (1) |
| Mine | Fast Hammer | 41 | 56 (41) | 35 | 21 | 32 | 24% | 2.5 | 48 (27) | 93 (9) | 25 (5) | 68 (25) | 37 (16) |
| Mine | Fragile | 4 | 0 (4) | 0 | 0 | 100 | 50% | 2.5 | 0 (1) | 0 (2) | - | 0 (1) | 0 (2) |
| Mine | Hammer | 65 | 24 (65) | 15 | 9 | 48 | 18% | 2.6 | 18 (13) | 27 (45) | 16 (7) | 21 (40) | 28 (25) |
| Mine | Holder | 31 | 70 (31) | 15 | 55 | 35 | 29% | 3.0 | 61 (7) | 99 (17) | 4 (7) | 83 (18) | 55 (13) |
| Mine | Shooter | 34 | 54 (34) | 28 | 26 | 49 | 3% | 1.6 | 52 (8) | 68 (21) | 0 (5) | 55 (25) | 54 (9) |
| Mine | Support | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Mine | War machine | 56 | 45 (56) | 45 | 0 | 45 | 5% | 1.3 | 80 (16) | 26 (30) | 35 (10) | 35 (9) | 47 (47) |
| Mine | Wizard | 17 | 39 (17) | 39 | 0 | 45 | 0% | 2.1 | 156 (5) | 0 (7) | 0 (1) | 136 (6) | 0 (7) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | 0 (1) | - | - | - | 0 (1) |
| Opponent | Chaff | 75 | 56 (75) | 37 | 19 | 48 | 40% | 2.9 | 43 (31) | 35 (17) | 86 (27) | 61 (56) | 38 (19) |
| Opponent | Character | 97 | 50 (97) | 50 | 0 | 25 | 23% | 2.3 | 51 (43) | 50 (39) | 67 (7) | 48 (52) | 57 (37) |
| Opponent | Clean-up | 11 | 46 (11) | 14 | 32 | 27 | 18% | 3.0 | 0 (3) | 49 (6) | 66 (2) | 35 (6) | 52 (5) |
| Opponent | Fast | 1 | 142 (1) | 142 | 0 | 0 | 0% | 4.0 | - | 142 (1) | - | 142 (1) | - |
| Opponent | Fast Hammer | 60 | 53 (60) | 33 | 20 | 46 | 27% | 3.0 | 69 (26) | 37 (25) | 37 (9) | 52 (39) | 54 (21) |
| Opponent | Fragile | 17 | 0 (17) | 0 | 0 | 76 | 24% | 1.8 | 0 (2) | 0 (8) | 0 (4) | 0 (11) | 0 (3) |
| Opponent | Hammer | 65 | 42 (65) | 27 | 16 | 41 | 32% | 3.1 | 23 (20) | 51 (38) | 21 (7) | 50 (41) | 31 (24) |
| Opponent | Holder | 29 | 34 (29) | 8 | 26 | 39 | 48% | 3.9 | 27 (10) | 24 (14) | 96 (5) | 50 (16) | 13 (13) |
| Opponent | Shooter | 33 | 81 (33) | 28 | 54 | 34 | 0% | 1.4 | 33 (9) | 108 (21) | 37 (3) | 82 (18) | 81 (15) |
| Opponent | Support | 6 | 0 (6) | 0 | 0 | 0 | 50% | 2.0 | 0 (5) | 0 (1) | - | 0 (3) | 0 (3) |
| Opponent | War machine | 6 | 28 (6) | 28 | 0 | 69 | 17% | 1.0 | 0 (3) | 69 (3) | - | 0 (3) | 69 (3) |
| Opponent | Wizard | 19 | 7 (19) | 7 | 0 | 48 | 11% | 1.9 | 7 (10) | 26 (2) | 0 (2) | 0 (8) | 26 (6) |

### Charged fights: jc-mine-1e5408d-p4

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 245 | 144 | 2.0 | 1.1 | 72 | 6 | +66 | 1 of 8 | 7 of 8 | +151 | +54 |
| Mine | Chaos Dwarfs | 4 | 186 | 88 | 2.0 | 1.2 | 44 | 14 | +30 | 2 of 8 | 4 of 8 | +0 | +40 |
| Mine | Dwarfen Mountain Holds | 3 | 503 | 20 | 2.0 | 1.0 | 10 | 81 | -71 | 2 of 6 | 2 of 6 | - | -71 |
| Mine | Empire of Man | 5 | 359 | 57 | 1.2 | 1.0 | 47 | 18 | +29 | 1 of 6 | 5 of 6 | - | +29 |
| Mine | Grand Cathay | 4 | 268 | 382 | 3.8 | 1.1 | 102 | 69 | +33 | 5 of 15 | 11 of 15 | -217 | +72 |
| Mine | High Elf Realms | 4 | 146 | 308 | 2.8 | 1.1 | 112 | 32 | +80 | 4 of 11 | 7 of 11 | +151 | +73 |
| Mine | Kingdom of Bretonnia | 1 | 355 | 275 | 4.0 | 1.0 | 69 | 0 | +69 | 3 of 4 | 3 of 4 | - | +69 |
| Mine | Lizardmen | 1 | 350 | 1469 | 4.0 | 1.5 | 367 | 46 | +321 | 3 of 4 | 3 of 4 | +152 | +490 |
| Mine | Ogre Kingdoms | 2 | 57 | 0 | 2.5 | 1.2 | 0 | 7 | -7 | 1 of 5 | 3 of 5 | +0 | -8 |
| Mine | Skaven | 2 | 310 | 33 | 1.5 | 1.0 | 22 | 0 | +22 | 1 of 3 | 3 of 3 | - | +22 |
| Mine | Tomb Kings of Khemri | 2 | 158 | 477 | 4.0 | 1.1 | 119 | 33 | +86 | 2 of 8 | 7 of 8 | +144 | +78 |
| Mine | Vampire Counts | 2 | 450 | 320 | 2.5 | 1.2 | 128 | 66 | +62 | 3 of 5 | 5 of 5 | +200 | +28 |
| Mine | Warriors of Chaos | 2 | 0 | 417 | 5.0 | 1.3 | 83 | 17 | +66 | 2 of 10 | 7 of 10 | +3 | +94 |
| **Mine** | all armies | 36 | 259 | 230 | 2.6 | 1.2 | 89 | 34 | +55 | 30 of 93 | 67 of 93 | +38 | +59 |
| Opponent | Empire of Man | 1 | 340 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | High Elf Realms | 5 | 249 | 655 | 4.4 | 1.3 | 149 | 6 | +142 | 14 of 22 | 14 of 22 | +235 | +108 |
| Opponent | Lizardmen | 2 | 0 | 340 | 2.5 | 1.0 | 136 | 28 | +108 | 4 of 5 | 4 of 5 | - | +108 |
| Opponent | Orc & Goblin Tribes | 3 | 0 | 807 | 5.3 | 1.0 | 151 | 43 | +108 | 4 of 16 | 13 of 16 | - | +108 |
| Opponent | Skaven | 4 | 88 | 157 | 2.2 | 1.1 | 70 | 81 | -11 | 4 of 9 | 5 of 9 | -362 | +33 |
| Opponent | Tomb Kings of Khemri | 2 | 180 | 214 | 3.5 | 1.0 | 61 | 66 | -5 | 2 of 7 | 3 of 7 | - | -5 |
| Opponent | Vampire Counts | 6 | 0 | 396 | 4.3 | 1.4 | 91 | 5 | +86 | 11 of 26 | 18 of 26 | +112 | +72 |
| Opponent | Warriors of Chaos | 7 | 0 | 529 | 3.3 | 1.0 | 161 | 14 | +147 | 12 of 23 | 15 of 23 | +122 | +148 |
| Opponent | Wood Elf Realms | 6 | 74 | 469 | 5.5 | 1.2 | 85 | 30 | +55 | 10 of 33 | 23 of 33 | -0 | +67 |
| **Opponent** | all armies | 36 | 76 | 453 | 3.9 | 1.2 | 116 | 26 | +90 | 61 of 141 | 95 of 141 | +95 | +89 |

### Effective charges: jc-mine-1e5408d-p4

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 8 | 1 (net -52) | 1 (net +178) | 0 | 1 (net +0) | 0 | 4 (net +62) | 1 | 0% (0 of 7) |
| Mine | Chaos Dwarfs | 8 | 0 | 1 (net +0) | 2 (net +0) | 3 (net +21) | 1 (net +0) | 1 (net +176) | 0 | 25% (2 of 8) |
| Mine | Dwarfen Mountain Holds | 6 | 2 (net -30) | 0 | 1 (net +0) | 2 (net -184) | 0 | 1 (net +0) | 0 | 17% (1 of 6) |
| Mine | Empire of Man | 6 | 1 (net -110) | 0 | 0 | 5 (net +57) | 0 | 0 | 0 | 0% (0 of 6) |
| Mine | Grand Cathay | 15 | 1 (net +0) | 1 (net -221) | 0 | 10 (net +104) | 1 (net -434) | 1 (net +109) | 1 | 0% (0 of 14) |
| Mine | High Elf Realms | 11 | 2 (net +332) | 0 | 0 | 2 (net +35) | 1 (net +151) | 4 (net +87) | 2 | 0% (0 of 9) |
| Mine | Kingdom of Bretonnia | 4 | 1 (net +210) | 0 | 0 | 0 | 0 | 1 (net +0) | 2 | 0% (0 of 2) |
| Mine | Lizardmen | 4 | 2 (net +490) | 0 | 0 | 0 | 0 | 2 (net +152) | 0 | 0% (0 of 4) |
| Mine | Ogre Kingdoms | 5 | 1 (net -34) | 1 (net +0) | 2 (net +0) | 0 | 0 | 1 (net +0) | 0 | 40% (2 of 5) |
| Mine | Skaven | 3 | 0 | 0 | 0 | 0 | 0 | 3 (net +22) | 0 | 0% (0 of 3) |
| Mine | Tomb Kings of Khemri | 8 | 0 | 0 | 1 (net +100) | 2 (net +132) | 3 (net +108) | 1 (net +0) | 1 | 14% (1 of 7) |
| Mine | Vampire Counts | 5 | 0 | 0 | 1 (net -329) | 1 (net +190) | 2 (net +180) | 0 | 1 | 25% (1 of 4) |
| Mine | Warriors of Chaos | 10 | 2 (net +58) | 0 | 0 | 0 | 4 (net +94) | 2 (net +86) | 2 | 0% (0 of 8) |
| Opponent | High Elf Realms | 22 | 2 (net +190) | 0 | 7 (net +88) | 8 (net +183) | 1 (net +0) | 2 (net +270) | 2 | 35% (7 of 20) |
| Opponent | Lizardmen | 5 | 0 | 0 | 2 (net +155) | 0 | 0 | 2 (net +184) | 1 | 50% (2 of 4) |
| Opponent | Orc & Goblin Tribes | 16 | 2 (net +148) | 1 (net +234) | 0 | 3 (net +82) | 0 | 2 (net -55) | 8 | 0% (0 of 8) |
| Opponent | Skaven | 9 | 3 (net -96) | 1 (net -41) | 1 (net +0) | 1 (net +434) | 0 | 3 (net -67) | 0 | 11% (1 of 9) |
| Opponent | Tomb Kings of Khemri | 7 | 3 (net -154) | 0 | 1 (net +92) | 2 (net +105) | 0 | 0 | 1 | 17% (1 of 6) |
| Opponent | Vampire Counts | 26 | 5 (net +108) | 1 (net +72) | 4 (net +35) | 1 (net +104) | 7 (net +120) | 7 (net +36) | 1 | 16% (4 of 25) |
| Opponent | Warriors of Chaos | 23 | 6 (net +85) | 0 | 4 (net +20) | 2 (net +359) | 4 (net +164) | 4 (net +383) | 3 | 20% (4 of 20) |
| Opponent | Wood Elf Realms | 33 | 6 (net -39) | 0 | 7 (net +10) | 6 (net +94) | 2 (net +116) | 8 (net +93) | 4 | 24% (7 of 29) |

### Charged fights, damage counted: jc-mine-1e5408d-p4

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 13 | 207 | 353 | +132 | 205 | 47 | +158 | +76.5 |
| Mine | 50-54% | 4 | 99 | 235 | -11 | 130 | 70 | +60 | +60.5 |
| Mine | Effective (55-75%) | 7 | 276 | 269 | -33 | 52 | 92 | -40 | -14.6 |
| Mine | 76-89% | 26 | 275 | 174 | +59 | 123 | 49 | +75 | +27.2 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 21 | 254 | 172 | +68 | 95 | 22 | +73 | +28.9 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 12 | 552 | 105 | +65 | 105 | 43 | +63 | +11.4 |
| Mine | No odds | 10 | 330 | 207 | -4 | 61 | 66 | -4 | -1.3 |
| Mine | All fights | 93 | 295 | 203 | +55 | 114 | 48 | +67 | +22.6 |
| Opponent | Long shot (under 50%) | 27 | 154 | 258 | +28 | 88 | 73 | +14 | +9.2 |
| Opponent | 50-54% | 3 | 147 | 129 | +88 | 118 | 14 | +104 | +71.0 |
| Opponent | Effective (55-75%) | 26 | 316 | 229 | +50 | 99 | 67 | +32 | +10.1 |
| Opponent | 76-89% | 23 | 325 | 216 | +163 | 193 | 27 | +167 | +51.2 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 28 | 348 | 216 | +112 | 152 | 29 | +123 | +35.3 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 14 | 512 | 108 | +124 | 129 | 4 | +125 | +24.4 |
| Opponent | No odds | 20 | 329 | 177 | +90 | 136 | 50 | +86 | +26.3 |
| Opponent | All fights | 141 | 310 | 208 | +90 | 131 | 44 | +87 | +28.0 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| jc-mine-1e5408d-p4 | move | 354 | 85 (24%) | 62 (18%) | 51 (14%) | 218 (62%) |
| jc-mine-1e5408d-p4 | objective | 409 | 52 (13%) | 43 (11%) | 47 (11%) | 310 (76%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0114, L0130, L2527, L2634 |
| Charmed Shield | Opponent | L0434, L0624, L0926, L1034, L1126, L1427, L2227, L2527, L2634, L3234 |
| Clockwork Compass | Mine | L1220 |
| Elixir of Power | Mine | L1126 |
| Elixir of Power | Opponent | L0819, L1719, L1819 |
| Fistful of Laurels | Mine | L1819, L1835 |
| Invocation of Nehek | Mine | L2527 |
| Invocation of Nehek | Opponent | L0624, L1427, L2227, L2527 |
| Opal Amulet | Mine | L1427 |
| Opal Amulet | Opponent | L0114, L0214, L1314 |
| Periapt of Soul Exchange | Mine | L2021, L2123 |
| Periapt of Soul Exchange | Opponent | L0520, L1220, L1621, L2021 |
| Ring of Doom | Mine | L0214, L0230, L1126, L1220, L1523 |
| Ring of Doom | Opponent | L0315, L1331, L2331 |
| Ring of Jet | Mine | L1017, L1034, L1126, L1220 |
| Standard of the Fell Warrior | Mine | L1314, L1331 |
| Standard of the Fell Warrior | Opponent | L0713 |
| Storm Daemon (Renegade 2.0) | Mine | L2123 |
| Storm Daemon (Renegade 2.0) | Opponent | L1621, L2021 |
| Twice-Blessed Armour | Mine | L0713, L0729, L1017, L1034 |
| Witch Hunter's Ward | Mine | L0713, L0729, L0819, L0835 |
| Witch Hunter's Ward | Opponent | L0608 |

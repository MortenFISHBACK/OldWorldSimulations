# Doctrine scorecard: jc-opp-1e5408d-p3

### Scorecard: jc-opp-1e5408d-p3

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0110 | 2 | 1 | Mine | - | - | 3 | 3 | 2 | 1 | 0 | 0 | 322 |
| L0110 | 2 | 1 | Opponent | - | - | 2 | 5 | 1 | 0 | 0 | 0 | 330 |
| L0126 | 6 | 1 | Mine | no | 8 | - | 0 | 1 | 0 | 0 | 0 | 317 |
| L0126 | 6 | 1 | Opponent | no | 17 | 2 | 2 | 0 | 0 | 0 | 0 | 0 |
| L0210 | 6 | 1 | Mine | no | 0 | - | 0 | 5 | 0 | 0 | 0 | 0 |
| L0210 | 6 | 1 | Opponent | no | 11 | 2 | 3 | 0 | 0 | 0 | 0 | 330 |
| L0226 | 4 | 1 | Mine | no | 0 | 6 | 3 | 3 | 0 | 0 | 0 | 170 |
| L0226 | 4 | 1 | Opponent | no | 4 | 2 | 1 | 4 | 1 | 0 | 0 | 0 |
| L0311 | 5 | 1 | Mine | no | - | 3 | 0 | 1 | 0 | 0 | 0 | 590 |
| L0311 | 5 | 1 | Opponent | yes | - | 3 | 1 | 1 | 0 | 0 | 0 | 427 |
| L0327 | 3 | 1 | Mine | yes | 2 | 3 | 4 | 0 | 0 | 0 | 0 | 685 |
| L0327 | 3 | 1 | Opponent | no | 4 | 2 | 4 | 3 | 0 | 0 | 0 | 0 |
| L0413 | 5 | 1 | Mine | yes | - | 2 | 5 | 1 | 0 | 0 | 0 | 0 |
| L0413 | 5 | 1 | Opponent | no | - | 3 | 2 | 1 | 1 | 0 | 0 | 317 |
| L0429 | 3 | 1 | Mine | yes | 2 | 2 | 3 | 1 | 1 | 0 | 0 | 0 |
| L0429 | 3 | 1 | Opponent | no | 1 | 2 | 4 | 2 | 0 | 0 | 0 | 170 |
| L0516 | 6 | 1 | Mine | no | 2 | 5 | 2 | 0 | 0 | 0 | 0 | 548 |
| L0516 | 6 | 1 | Opponent | no | 6 | 2 | 3 | 1 | 2 | 0 | 0 | 200 |
| L0533 | 5 | 1 | Mine | no | - | - | 0 | 1 | 0 | 0 | 0 | 1193 |
| L0533 | 5 | 1 | Opponent | yes | - | 2 | 2 | 5 | 0 | 0 | 0 | 0 |
| L0620 | 2 | 1 | Mine | - | - | 4 | 4 | 0 | 0 | 0 | 0 | 798 |
| L0620 | 2 | 1 | Opponent | - | - | 4 | 1 | 2 | 0 | 0 | 0 | 210 |
| L0709 | 1 | 1 | Mine | yes | 7 | 3 | 1 | 0 | 1 | 0 | 0 | 420 |
| L0709 | 1 | 1 | Opponent | no | 0 | - | 0 | 0 | 0 | 0 | 0 | 925 |
| L0725 | 5 | 1 | Mine | yes | - | 6 | 1 | 3 | 0 | 0 | 0 | 420 |
| L0725 | 5 | 1 | Opponent | yes | - | 2 | 5 | 3 | 0 | 0 | 0 | 0 |
| L0815 | 5 | 1 | Mine | no | - | - | 0 | 1 | 0 | 0 | 0 | 515 |
| L0815 | 5 | 1 | Opponent | yes | - | 2 | 2 | 2 | 0 | 0 | 0 | 115 |
| L0831 | 3 | 1 | Mine | no | 2 | 4 | 2 | 1 | 0 | 0 | 0 | 605 |
| L0831 | 3 | 1 | Opponent | no | 10 | 2 | 2 | 3 | 2 | 0 | 0 | 340 |
| L0922 | 4 | 1 | Mine | no | 0 | 5 | 1 | 0 | 0 | 0 | 0 | 841 |
| L0922 | 4 | 1 | Opponent | no | 0 | 2 | 5 | 2 | 1 | 0 | 0 | 55 |
| L1013 | 5 | 1 | Mine | no | - | 2 | 3 | 0 | 1 | 0 | 0 | 330 |
| L1013 | 5 | 1 | Opponent | no | - | 6 | 2 | 2 | 0 | 0 | 0 | 387 |
| L1030 | 4 | 1 | Mine | no | 0 | 2 | 4 | 0 | 0 | 0 | 0 | 330 |
| L1030 | 4 | 1 | Opponent | no | 1 | 3 | 3 | 1 | 1 | 0 | 0 | 0 |
| L1122 | 6 | 1 | Mine | no | 0 | 3 | 1 | 0 | 0 | 0 | 0 | 330 |
| L1122 | 6 | 1 | Opponent | no | 2 | 2 | 3 | 2 | 1 | 0 | 0 | 72 |
| L1216 | 4 | 1 | Mine | no | 6 | 2 | 2 | 0 | 0 | 0 | 0 | 330 |
| L1216 | 4 | 1 | Opponent | no | 4 | 2 | 6 | 1 | 0 | 0 | 0 | 414 |
| L1232 | 2 | 1 | Mine | - | - | 2 | 1 | 0 | 0 | 0 | 0 | 330 |
| L1232 | 2 | 1 | Opponent | - | - | 3 | 4 | 2 | 2 | 0 | 0 | 340 |
| L1327 | 1 | 1 | Mine | no | 10 | 4 | 2 | 0 | 0 | 0 | 0 | 302 |
| L1327 | 1 | 1 | Opponent | no | 3 | 2 | 3 | 1 | 1 | 0 | 0 | 0 |
| L1422 | 6 | 1 | Mine | no | 7 | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L1422 | 6 | 1 | Opponent | no | 0 | 2 | 2 | 0 | 0 | 0 | 0 | 242 |
| L1519 | 1 | 1 | Mine | no | 0 | 2 | 3 | 0 | 0 | 0 | 0 | 0 |
| L1519 | 1 | 1 | Opponent | no | 0 | 2 | 5 | 2 | 1 | 0 | 0 | 0 |
| L1535 | 5 | 1 | Mine | yes | - | 4 | 3 | 2 | 0 | 0 | 0 | 0 |
| L1535 | 5 | 1 | Opponent | no | - | 2 | 3 | 3 | 0 | 0 | 0 | 414 |
| L1633 | 1 | 1 | Mine | no | 12 | 3 | 3 | 1 | 0 | 0 | 0 | 200 |
| L1633 | 1 | 1 | Opponent | no | 0 | 1 | 1 | 3 | 0 | 0 | 0 | 0 |
| L1731 | 3 | 1 | Mine | yes | 7 | 3 | 6 | 0 | 1 | 0 | 0 | 0 |
| L1731 | 3 | 1 | Opponent | no | 4 | 2 | 3 | 0 | 1 | 0 | 0 | 340 |
| L1831 | 1 | 1 | Mine | no | 0 | 4 | 4 | 0 | 1 | 0 | 0 | 0 |
| L1831 | 1 | 1 | Opponent | no | 9 | 2 | 5 | 0 | 2 | 0 | 0 | 170 |
| L1932 | 6 | 1 | Mine | no | 2 | 2 | 4 | 0 | 0 | 0 | 0 | 500 |
| L1932 | 6 | 1 | Opponent | no | 4 | 2 | 3 | 0 | 1 | 0 | 0 | 340 |
| L2033 | 5 | 1 | Mine | no | - | 3 | 0 | 6 | 1 | 0 | 0 | 420 |
| L2033 | 5 | 1 | Opponent | yes | - | 3 | 2 | 2 | 0 | 0 | 0 | 0 |
| L2223 | 3 | 1 | Mine | no | 0 | 1 | 9 | 0 | 1 | 0 | 0 | 0 |
| L2223 | 3 | 1 | Opponent | no | 0 | 2 | 3 | 0 | 0 | 0 | 0 | 0 |
| L2327 | 5 | 1 | Mine | no | - | 2 | 3 | 0 | 0 | 0 | 0 | 0 |
| L2327 | 5 | 1 | Opponent | no | - | 2 | 5 | 3 | 0 | 0 | 0 | 60 |
| L2433 | 3 | 1 | Mine | no | 6 | 3 | 5 | 2 | 0 | 0 | 0 | 0 |
| L2433 | 3 | 1 | Opponent | no | 0 | 1 | 4 | 1 | 2 | 0 | 0 | 641 |
| L2630 | 2 | 1 | Mine | - | - | 3 | 3 | 1 | 0 | 0 | 0 | 0 |
| L2630 | 2 | 1 | Opponent | - | - | 2 | 5 | 1 | 0 | 0 | 0 | 0 |
| L2832 | 6 | 1 | Mine | no | 3 | 2 | 3 | 0 | 2 | 0 | 0 | 0 |
| L2832 | 6 | 1 | Opponent | no | 3 | 2 | 4 | 1 | 1 | 0 | 0 | 170 |
| L3133 | 1 | 1 | Mine | no | 9 | 1 | 3 | 0 | 0 | 0 | 0 | 170 |
| L3133 | 1 | 1 | Opponent | no | 6 | 6 | 2 | 0 | 0 | 0 | 0 | 144 |
| **Average** | | | Mine | 22% | 3.7 | 3.0 | 2.6 | 0.9 | 0.3 | 0.0 | 0.0 | 296.3 |
| **Average** | | | Opponent | 16% | 3.9 | 2.4 | 3.1 | 1.5 | 0.6 | 0.0 | 0.0 | 198.7 |

### KPIs: jc-opp-1e5408d-p3

Rules off - Mine only: SECOND CHARGER ADDS.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 25% (43 of 172) | 10% (17 of 176) | 17% (60 of 348) |
| Winner chose to follow up after the loser gave ground |  | 98% (64 of 65); on the table 98% | 100% (49 of 49); on the table 100% | 99% (113 of 114); on the table 99% |
| Winner chose to pursue after the loser fell back in good order |  | 73% (8 of 11); on the table 73% | 94% (15 of 16); on the table 94% | 85% (23 of 27); on the table 85% |
| Winner chose to pursue after the loser fled |  | 81% (22 of 27); on the table 81% | 69% (22 of 32); on the table 72% | 75% (44 of 59); on the table 76% |
| Winner chose to follow up or pursue (all three) |  | 91% (94 of 103); on the table 91% | 89% (86 of 97); on the table 90% | 90% (180 of 200); on the table 90% |
| Magic missiles tried each own turn | 50%+ | 30% (103 of 342) | 35% (68 of 192) | 32% (171 of 534) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 48% (103 of 215) | 47% (68 of 144) | 48% (171 of 359) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 40% (8 of 20) | 51% (26 of 51) | 48% (34 of 71) |
| Points that never fought | lower | 37% (25342 of 68801) | 38% (27586 of 71990) | 38% (52928 of 140791) |
|   infantry points that never fought | lower | 38% (5419 of 14174) | 55% (7889 of 14220) | 47% (13308 of 28394) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 55% (149 of 272) | 57% (163 of 285) | 56% (312 of 557) |
| Bound items with a magic missile used (at least once a game) |  | 96% (24 of 25); 1.7 uses a game | 83% (20 of 24); 1.9 uses a game | 90% (44 of 49); 1.8 uses a game |
| Bound items with another spell used |  | 21% (3 of 14); 0.2 uses a game | 33% (2 of 6); 0.1 uses a game | 25% (5 of 20); 0.1 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 50% (10 of 20); 0.3 uses a game | 43% (6 of 14); 0.2 uses a game | 47% (16 of 34); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 50% (29482 of 59391) | 52% (33064 of 64043) | 51% (62546 of 123434) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.2 (18%) | 1.0 (30%) | 2.2 (22%) |
| MARCHED: its unit marched | 1.4 (21%) | 0.7 (21%) | 2.1 (21%) |
| CHARGED: its unit charged | 0.1 (2%) | 0.2 (6%) | 0.3 (3%) |
| IN COMBAT: engaged in combat | 1.6 (23%) | 0.9 (25%) | 2.4 (24%) |
| REAR RANK: in a rear rank | 0.1 (2%) | 0.2 (5%) | 0.3 (3%) |
| FLEEING: fleeing | 0.0 (0%) | 0.2 (5%) | 0.2 (2%) |
| GONE: slain | 1.7 (25%) | 0.3 (9%) | 2.0 (20%) |
| OFF THE TABLE: off the table or not arrived | 0.3 (4%) | 0.0 (0%) | 0.3 (3%) |
| STUPIDITY: Stupidity | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.9 | 1.1 | 1.6 | 4.8 | 0.9 | 1.8 |
| not cast | 4.0 | 1.5 | 4.5 | 10.1 | 2.4 | 18.9 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) | 0.0 (0%) | 1.5 (8%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (1%) | 0.7 (47%) | 0.3 (6%) | 2.2 (22%) | 0.3 (13%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.1 (21%) | 0.4 (17%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (3%) | 0.1 (5%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.2 (5%) | 0.2 (11%) | 0.8 (17%) | 2.4 (24%) | 0.4 (16%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.2 (4%) | 0.0 (0%) | 0.3 (7%) | 0.3 (3%) | 0.1 (6%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (0%) | 0.1 (7%) | 0.0 (0%) | 0.2 (2%) | 0.0 (0%) | 0.4 (2%) |
| GONE: slain | 1.1 (28%) | 0.3 (18%) | 1.2 (26%) | 2.0 (20%) | 0.3 (13%) | 2.9 (16%) |
| OFF THE TABLE: off the table or not arrived | 0.1 (2%) | 0.1 (4%) | 0.3 (6%) | 0.3 (3%) | 0.1 (5%) | 0.5 (3%) |
| STUPIDITY: Stupidity | 0.1 (3%) | 0.0 (0%) | 0.1 (2%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (3%) | 0.1 (5%) | 0.0 (1%) | 0.1 (1%) | 0.6 (26%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.1 (54%) | 0.1 (7%) | 1.5 (34%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 13.6 (72%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.1 a game | 0.6 a game | 0.8 a game |
| stood (cast and not dispelled) | 56% (18 of 32) | 65% (11 of 17) | 59% (29 of 49) |
| the unit moved after it | 56% (10 of 18) | 73% (8 of 11) | 62% (18 of 29) |
| it charged on its next turn | 0% (0 of 18) | 9% (1 of 11) | 3% (1 of 29) |
| the enemy charged it first | 22% (4 of 18) | 36% (4 of 11) | 28% (8 of 29) |
| it fought by the end of its next turn | 11% (2 of 18) | 0% (0 of 11) | 7% (2 of 29) |
| it moved out of a charge the enemy had planned (not charged first) | 11% (2 of 18) | 0% (0 of 11) | 7% (2 of 29) |
| none of these (no charge, no fight, no charge escaped) | 61% (11 of 18) | 55% (6 of 11) | 59% (17 of 29) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 65% (501 of 773) | 60% (367 of 609) | 63% (868 of 1382) |
|   cavalry | 55% (39 of 71) | 67% (64 of 96) | 62% (103 of 167) |
|   character | 60% (61 of 101) | 26% (32 of 125) | 41% (93 of 226) |
|   chariot | 44% (43 of 97) | 65% (20 of 31) | 49% (63 of 128) |
|   infantry | 53% (111 of 208) | 67% (174 of 260) | 61% (285 of 468) |
|   monster | 47% (18 of 38) | 80% (4 of 5) | 51% (22 of 43) |
|   war machine | 89% (229 of 258) | 79% (73 of 92) | 86% (302 of 350) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.2 (29%) | 1.3 (19%) | 3.5 (25%) |
| CHARGED: it charged | 1.2 (15%) | 1.7 (25%) | 2.8 (20%) |
| FLEEING: it fled or was fleeing | 0.1 (1%) | 0.1 (1%) | 0.2 (1%) |
| IN COMBAT: it fought this turn or the last | 0.8 (11%) | 0.4 (7%) | 1.3 (9%) |
| MOVED: a war machine that moved | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| NO TARGET IN RANGE | 0.9 (12%) | 0.8 (12%) | 1.8 (12%) |
| ONLY IN COMBAT: the only targets were in combat | 0.4 (5%) | 0.5 (8%) | 0.9 (6%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.4 (19%) | 1.3 (20%) | 2.8 (19%) |
| SHELTERED: the target was sheltered | 0.1 (1%) | 0.2 (2%) | 0.2 (2%) |
| STUPIDITY | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR | 0.3 (4%) | 0.3 (5%) | 0.7 (5%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 4.6 | 1.3 | 78% | 6.8 pts | 32 pts |
| character | 3.1 | 1.0 | 77% | 8.9 pts | 28 pts |
| chariot | 1.8 | 0.5 | 78% | 9.1 pts | 16 pts |
| infantry | 12.8 | 3.8 | 79% | 8.1 pts | 104 pts |
| monster | 0.9 | 0.2 | 81% | 9.6 pts | 9 pts |
| war machine | 8.7 | 7.6 | 59% | 22.7 pts | 198 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.1 | 5.9 | 5.0 |
| Charges that made contact a game | 3.1 | 4.0 | 3.5 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.74 declared, 0.59 contact (27 units) | 1.15 declared, 0.90 contact (20 units) | 0.91 declared, 0.72 contact (47 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.33 declared, 0.33 contact (3 units) | 0.89 declared, 0.33 contact (9 units) | 0.75 declared, 0.33 contact (12 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.57 declared, 0.42 contact (221 units) | 0.68 declared, 0.46 contact (267 units) | 0.63 declared, 0.44 contact (488 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 43% (33 of 77) | 47% (7 of 15) | 50% (5 of 10) | 44% (45 of 102) |
| Character in a unit | 72% (28 of 39) | 60% (9 of 15) | 57% (4 of 7) | 67% (41 of 61) |
| Character on its own | 76% (29 of 38) | 54% (22 of 41) | 26% (18 of 68) | 47% (69 of 147) |
| Chariot | 82% (9 of 11) | 75% (9 of 12) | - | 78% (18 of 23) |
| Infantry | 61% (43 of 70) | 57% (24 of 42) | 20% (1 of 5) | 58% (68 of 117) |
| Monster | 71% (24 of 34) | 57% (4 of 7) | - | 68% (28 of 41) |
| Monstrous | 80% (8 of 10) | 45% (5 of 11) | - | 62% (13 of 21) |
| War Machines | 65% (28 of 43) | 100% (2 of 2) | - | 67% (30 of 45) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 100% (12 of 12); on the table 100% | 29% (28 of 96) | 48% | 77% (17 of 22) | 83% (5 of 6); 3.5 uses a game | 50% (1 of 2); 0.5 uses a game | 67% (4 of 6); 1.0 uses a game |
| Chaos Dwarfs | 4 | 93% (13 of 14); on the table 93% | 39% (14 of 36) | 45% | 59% (19 of 32) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
| Dwarfen Mountain Holds | 3 | 60% (3 of 5); on the table 60% | - | 60% | 50% (12 of 24) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 6 | 78% (7 of 9); on the table 78% | 33% (10 of 30) | 43% | 61% (36 of 59) | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game | 0% (0 of 4); 0.0 uses a game |
| Grand Cathay | 8 | 96% (23 of 24); on the table 96% | 34% (65 of 192) | 47% | 53% (39 of 74) | 89% (16 of 18); 6.0 uses a game | 0% (0 of 4); 0.0 uses a game | 50% (4 of 8); 0.5 uses a game |
| High Elf Realms | 7 | 100% (18 of 18); on the table 100% | 31% (13 of 42) | 33% | 54% (29 of 54) | 89% (8 of 9); 3.6 uses a game | 33% (4 of 12); 0.9 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 3 | 100% (4 of 4); on the table 100% | - | 53% | 50% (9 of 18) | 0.0 uses a game | 0.0 uses a game | 100% (3 of 3); 1.0 uses a game |
| Lizardmen | 1 | 100% (4 of 4); on the table 100% | 33% (2 of 6) | 8% | 57% (4 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 1 | 75% (3 of 4); on the table 75% | 0% (0 of 6) | 15% | 43% (3 of 7) | 100% (1 of 1); 1.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 2 | 100% (3 of 3); on the table 100% | 25% (3 of 12) | 9% | 50% (8 of 16) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.5 uses a game |
| Skaven | 2 | 86% (6 of 7); on the table 86% | 8% (1 of 12) | 49% | 64% (9 of 14) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.5 uses a game |
| Tomb Kings of Khemri | 6 | 92% (11 of 12); on the table 92% | 0% (0 of 6) | 32% | 46% (12 of 26) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 8 | 92% (22 of 24); on the table 92% | 35% (19 of 54) | 27% | 37% (17 of 46) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 11 | 83% (45 of 54); on the table 85% | 40% (12 of 30) | 31% | 58% (56 of 96) | 100% (4 of 4); 1.0 uses a game | 0.0 uses a game | 100% (2 of 2); 0.2 uses a game |
| Wood Elf Realms | 6 | 100% (6 of 6); on the table 100% | 33% (4 of 12) | 41% | 68% (42 of 62) | 91% (10 of 11); 5.2 uses a game | 0.0 uses a game | 0% (0 of 5); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (jc-opp-1e5408d-p3, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 29% (24) | 51% (38) | 39% (62) |
| ...free all their last turn and able to turn (per game) | 0.47 | 0.58 | 1.06 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.14 | 0.14 | 0.28 |
| ...with the charger already in that arc before they moved (per game) | 0.36 | 0.42 | 0.78 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 2.03 | 1.69 | 3.72 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.94 | 0.67 | 1.61 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 5.94 | 4.92 | 10.86 |

### Quality by phase: jc-opp-1e5408d-p3

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.2 | 3.6 |
| Strategy | Charge objectives carried out (made contact) | 55% (63 of 115) | 48% (76 of 159) |
| Strategy | Shoot objectives carried out (shot that target) | 48% (177 of 368) | 47% (120 of 258) |
| Strategy | Close-in objectives charged next turn | 16% (31 of 194) | 16% (41 of 255) |
| Strategy | Support requests answered (helper made contact too) | 33% (2 of 6) | 44% (15 of 34) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (2 of 2) | 100% (1 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | 67% (6 of 9) | 100% (2 of 2) |
| Strategy | Joined characters whose unit fought | 43% (19 of 44) | 50% (22 of 44) |
| Strategy | Lone characters that fought | 71% (65 of 91) | 71% (64 of 90) |
| Movement | Charges halted short of contact | 0.2 | 0.2 |
| Movement | Idle units | 0.9 | 1.5 |
| Movement | Points that never moved of their own | 296.3 | 198.7 |
| Movement | Fights charged into per game | 2.9 | 3.3 |
| Movement | Charges with odds: long shots (under 50%) | 8 of 91, net -53 | 23 of 106, net +66 |
| Movement | Charges with odds: sweet spot (55-75%) | 18 of 91, net +10 | 22 of 106, net +80 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 11 of 91, net +189 | 11 of 106, net +61 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 26 of 91, net +172 | 23 of 106, net +132 |
| Shooting | Shots by shooting units (incl. breath weapons) | 8.1 | 10.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 46% (135 of 291) | 51% (184 of 360) |
| Shooting | Points destroyed by shooting units | 70.2 | 30.9 |
| Shooting | War machine shots | 6.4 | 2.4 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 52% (120 of 229) | 44% (37 of 85) |
| Shooting | Points destroyed by war machines | 65.1 | 18.9 |
| Magic | Magic missiles cast | 1.9 | 1.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 29% (20 of 70) | 26% (12 of 47) |
| Magic | Wounds caused by magic missiles | 3.1 | 3.2 |
| Magic | Wounds caused by other spells | 0.8 | 1.2 |
| Magic | Points destroyed by magic (all spells) | 69.4 | 88.6 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.4 / 0.2 / 0.4 / 0.1 | 1.9 / 0.1 / 0.5 / 0.4 |
| Combat | Points destroyed in combat | 311.1 | 388.4 |
| Combat | Points run down | 60.8 | 103.2 |
| Combat | Net points per charged fight, damage counted | +74 | +102 |
| Combat | Net per 100 charger points, damage counted | +26.7 | +34.9 |
| Combat | First round won (charged fights) | 76% | 69% |
| Combat | Net points per charged fight | +72 | +99 |
| Combat | Net points per supported fight / lone fight | +205 / +58 | +97 / +99 |
| Combat | Charged fights on a top-3 enemy unit | 39 of 104 | 50 of 118 |
| Game | Points lost | 733.2 | 655.0 |
| Game | VP from objectives | 490.3 | 582.8 |
| Game | Lone holders (player turns) | 3.7 | 3.9 |

- Mine won / drew / lost: 11 / 11 / 14 of 36 ended games (of 36); mean margin (Mine - Opponent) -172 VP
- The side that went first won 14 of 25 games with a winner
- Points traded per game (both sides' losses): 1388
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: jc-opp-1e5408d-p3

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.6 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 0.0 |
| ADVANCE WORTH | 5.6 | -199.3 | 201.2 | 94.9 | 3.3 | -94.3 | 121.2 | 69.3 |
| ALREADY CARRIED | 0.2 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARRIVAL HUNT | - | - | - | - | 0.1 | +0.3 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.7 | +0.0 | 0.0 | 54.9 | 0.1 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | 0.8 | +3.1 | 0.0 | 19.2 | 0.7 | +3.2 | 0.0 | 8.6 |
| BEST FACING | 0.4 | +22.3 | 0.0 | 23.7 | 0.5 | +23.2 | 0.0 | 16.6 |
| BEST FIRST | 1.5 | +61.2 | 50.9 | 40.6 | 0.9 | +66.8 | 34.2 | 20.9 |
| BEST OVERALL | 0.4 | +27.9 | 0.0 | 0.0 | 0.4 | +10.5 | 0.0 | 1.7 |
| BEST PREY | 0.5 | +21.8 | 2.5 | 25.2 | 0.6 | +25.6 | 22.9 | 14.8 |
| BEST PRIZE | 0.1 | -5.0 | 7.9 | 0.0 | 0.1 | -0.4 | 3.2 | 0.0 |
| BIG CHARACTER SAFETY | 0.2 | -1.1 | 0.0 | 0.0 | 0.2 | -1.3 | 0.0 | 0.0 |
| BLOCKED CHARGE SKIPPED | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 5.3 | 0.0 |
| BLOCKED WHEEL | 0.4 | +25.0 | 0.0 | 0.0 | 0.3 | +4.3 | 0.0 | 1.4 |
| BLOWS WHERE AIMED | 0.2 | -13.4 | 42.0 | 5.4 | 0.3 | -42.8 | 34.9 | 0.0 |
| BOMBING RUN | 0.0 | +0.8 | 5.4 | 4.2 | - | - | - | - |
| BOUND ASSAILMENT | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |
| CANNON PLAN MISSED | 0.6 | +0.0 | 82.3 | 11.7 | 0.2 | +0.0 | 7.8 | 0.0 |
| CANNON PLANNED TARGET | 5.5 | +115.6 | 352.3 | 116.5 | 1.2 | +66.9 | 93.0 | 23.5 |
| CANNON SIGHT KEPT | 1.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT COUNTER | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CARRIES OUT SET-UP | 0.1 | +0.0 | 13.9 | 6.0 | 0.2 | -0.8 | 19.9 | 0.0 |
| CAST JOB | 0.8 | +21.2 | 44.2 | 31.2 | 0.9 | +22.5 | 52.4 | 18.2 |
| CASTER AWAY FROM SCREEN | 0.2 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.2 | +12.2 | 1.2 | 0.0 | 0.1 | +1.0 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 0.5 | +0.0 | 0.0 | 20.8 | 0.4 | +0.0 | 0.0 | 24.1 |
| CASTS FROM BEHIND | 0.0 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CATCH ODDS | 0.0 | +0.2 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | 0.9 | +44.7 | 0.0 | 24.9 | 1.6 | +74.8 | 0.0 | 35.1 |
| CHAFF PASSED | 0.2 | -0.0 | 0.0 | 1.7 | 0.2 | -0.6 | 16.2 | 5.7 |
| CHARGE NOW FIRST | 2.1 | +0.0 | 160.7 | 41.2 | 2.5 | +0.0 | 241.4 | 61.1 |
| CHARGE NOW WEIGHED | 0.6 | -67.3 | 26.9 | 10.6 | 0.4 | -50.1 | 10.9 | 5.4 |
| CHARGER SLAIN LOST | 0.4 | -11.7 | 38.9 | 7.9 | 0.6 | -17.4 | 70.6 | 8.8 |
| CHARIOT WIZARD CAREFUL | 0.0 | -2.1 | 0.0 | 11.0 | 0.1 | -0.0 | 12.1 | 11.1 |
| CHEAP HELPER | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| COMBAT PIVOT | 0.6 | +0.0 | 15.9 | 39.3 | 0.4 | +0.0 | 26.6 | 25.3 |
| CONTINUE AHEAD WEIGHED | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CONVEYANCE SEARCH | 0.7 | +110.2 | 0.0 | 9.9 | 0.3 | +25.5 | 20.8 | 24.0 |
| COVER ONCE | 7.9 | -520.4 | 0.0 | 151.7 | 5.8 | -413.3 | 0.0 | 123.4 |
| DEFENSIVE ARMY | 0.2 | +0.0 | 2.2 | 5.4 | 0.1 | +0.0 | 6.7 | 0.0 |
| DEFENSIVE FLOOR | 0.0 | +1.7 | 3.2 | 0.0 | - | - | - | - |
| EDGE GIVE GROUND | 0.2 | +1.1 | 15.1 | 0.0 | 0.3 | +6.9 | 34.2 | 1.2 |
| ELIXIR WORTH | 0.1 | +1.0 | 0.0 | 0.0 | - | - | - | - |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 2.0 | +162.1 | 0.0 | 106.8 | 1.7 | +119.2 | 0.0 | 49.8 |
| FALLBACK BY WORTH | 4.4 | +44.9 | 0.0 | 47.8 | 5.2 | +31.8 | 0.0 | 36.7 |
| FIGHT LIFT | 0.1 | +1.5 | 0.0 | 0.0 | 0.1 | +2.3 | 0.0 | 0.0 |
| FIRE AND FLEE | 0.0 | +0.4 | 2.9 | 2.2 | - | - | - | - |
| FLANK NOT WEIGHED | 5.6 | +0.0 | 0.0 | 127.3 | 4.9 | +0.0 | 0.0 | 103.8 |
| FOLLOW UP WEIGHED | 1.2 | +197.8 | 0.0 | 22.7 | 1.0 | +129.7 | 0.0 | 29.8 |
| FRIEND IN REACH | 3.3 | +38.2 | 251.4 | 54.4 | 4.8 | +85.0 | 412.8 | 86.6 |
| FRIENDS SHOTS CHECKED | 0.3 | +27.8 | 0.0 | 34.7 | 0.1 | +13.1 | 0.0 | 13.1 |
| GIVES UP | 0.0 | -0.3 | 0.0 | 3.2 | 0.1 | -0.7 | 5.7 | 0.0 |
| GIVES UP ITS SCREEN | - | - | - | - | 0.0 | -0.1 | 4.5 | 0.0 |
| HELPER ALREADY ASKED | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 1.8 | 0.0 |
| HELPER UNSEEN | 0.2 | +0.0 | 13.9 | 11.0 | 0.5 | +0.0 | 46.4 | 14.3 |
| HILL BY ITS CHANCE | 0.2 | -13.8 | 0.0 | 1.8 | 0.5 | -65.9 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 8.3 | -148.4 | 446.1 | 98.4 | 8.8 | -219.5 | 468.7 | 149.1 |
| HORN WORTH | - | - | - | - | 0.1 | +0.8 | 0.0 | 0.0 |
| HUNT ADVANCE | 0.1 | +7.1 | 3.5 | 0.0 | 0.2 | +5.4 | 3.5 | 2.9 |
| HUNT DROPPED | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 6.9 | 2.9 |
| HUNT IN PAIRS | 0.3 | +17.4 | 0.0 | 0.0 | 0.7 | +30.7 | 0.0 | 16.2 |
| HUNT KEPT | 0.3 | +8.0 | 3.5 | 2.5 | 0.1 | +1.8 | 0.0 | 3.4 |
| HUNT RESULT | 0.1 | +5.8 | 0.0 | 0.0 | 0.2 | +9.3 | 6.9 | 6.6 |
| HUNT THE GUNS | 0.1 | +44.0 | 3.5 | 2.5 | 0.2 | +63.1 | 5.4 | 0.0 |
| IDLE COST | 15.1 | -261.0 | 0.0 | 128.1 | 18.5 | -332.5 | 0.0 | 189.1 |
| INVITES THE FIGHT | 1.3 | +9.1 | 57.2 | 21.1 | 0.5 | +3.9 | 27.6 | 33.2 |
| JOINT CHARGE PLAN | 0.1 | +3.7 | 0.0 | 7.6 | 0.2 | +9.6 | 0.0 | 0.0 |
| JOINT KNOWS CHALLENGE | - | - | - | - | 0.1 | -5.8 | 31.0 | 0.0 |
| KEEP FALLS | 0.1 | +2.8 | 0.0 | 6.8 | 0.0 | +0.1 | 0.0 | 0.0 |
| KEEPS ITS PREY | 0.2 | +2.2 | 0.0 | 1.4 | 0.1 | +0.1 | 0.0 | 0.0 |
| KEEPS ITS TARGET | 1.8 | +55.0 | 125.7 | 29.9 | 2.4 | +72.5 | 203.4 | 31.3 |
| KEEPS SCOUTS OR AMBUSH | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KILLS COUNT | 1.4 | +80.5 | 79.9 | 14.1 | 1.9 | +109.3 | 140.6 | 41.5 |
| KILLS COUNT NEXT TURN | 5.4 | +205.7 | 201.2 | 47.6 | 7.5 | +261.2 | 270.5 | 147.9 |
| LONE CHARACTER SAFE SPOT | 0.2 | +16.7 | 7.5 | 0.0 | 0.3 | +12.1 | 0.0 | 4.6 |
| LONE WIZARD HOLDS BACK | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 8.0 | 10.6 |
| LONE WIZARD KEPT IN | 0.6 | +37.3 | 0.0 | 0.0 | 0.4 | +25.4 | 0.0 | 0.0 |
| LONG SHOT | 0.3 | -0.2 | 19.1 | 6.9 | 0.2 | +2.4 | 14.5 | 3.2 |
| LOST CHARGE | 3.1 | -49.2 | 107.8 | 68.0 | 2.2 | -31.9 | 75.4 | 47.1 |
| LURE BY WHAT IT DRAWS | 0.1 | -17.3 | 0.0 | 4.2 | 0.1 | -10.2 | 0.0 | 3.2 |
| MAKE SURE TOGETHER | 1.0 | +129.9 | 49.9 | 22.9 | 1.1 | +95.7 | 8.6 | 20.4 |
| MANOEUVRE | 0.3 | +3.4 | 0.0 | 8.6 | 0.3 | +8.8 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.2 | +0.7 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | 0.5 | +18.0 | 0.0 | 7.9 | 0.7 | +37.6 | 0.0 | 18.8 |
| MARCH ODDS | 0.3 | +12.3 | 6.9 | 0.0 | 0.2 | +7.4 | 5.2 | 0.0 |
| MARCH OVER CASTS | 0.8 | +65.5 | 0.0 | 48.5 | 0.4 | +22.3 | 0.0 | 3.0 |
| MAX FOR POSITIONING | 6.4 | +81.1 | 0.0 | 167.0 | 6.8 | +96.4 | 0.0 | 133.0 |
| MISSILES IN THE MOVE | 3.8 | +101.5 | 0.0 | 126.4 | 4.0 | +75.0 | 0.0 | 96.6 |
| MISSILES NEXT TURN | 5.1 | +76.3 | 0.0 | 150.3 | 4.9 | +51.4 | 0.0 | 93.4 |
| MODEL FACING | 0.1 | +38.7 | 0.0 | 0.0 | - | - | - | - |
| MONSTER WIZARD ROAMS | 0.2 | +0.0 | 17.4 | 10.6 | 0.2 | +0.0 | 6.4 | 0.0 |
| MOVE AND CAST | 0.4 | +22.9 | 0.0 | 19.5 | 0.6 | +19.8 | 0.0 | 6.4 |
| MOVE SPELL IN RANGE | 0.3 | +10.3 | 0.0 | 10.6 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.4 | -14.9 | 1.8 | 44.7 | 0.1 | -1.8 | 0.0 | 14.1 |
| MOVE SPELL SPOT | 0.2 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 11.1 |
| MOVE TO CHARGE | 3.9 | +385.1 | 171.9 | 59.5 | 4.8 | +393.4 | 118.6 | 77.9 |
| MOVES UNITS SPELL | 0.1 | +3.6 | 0.0 | 0.0 | 0.1 | +0.3 | 0.0 | 0.0 |
| NEEDED THERE | 0.0 | +2.7 | 0.0 | 0.0 | 0.0 | +0.1 | 0.0 | 0.0 |
| NO RALLY LEFT | 0.1 | +4.3 | 0.0 | 13.9 | - | - | - | - |
| NOT NEEDED | 0.1 | -4.2 | 13.7 | 0.0 | - | - | - | - |
| NOT TURNED | 5.9 | +113.7 | 0.0 | 105.5 | 4.9 | +14.3 | 0.0 | 87.5 |
| NOT WORTH A CAST | 0.5 | -0.3 | 0.0 | 34.7 | 0.9 | -0.9 | 0.0 | 14.1 |
| OFF BEST | 16.4 | -679.9 | 6.1 | 311.6 | 15.4 | -812.1 | 0.0 | 203.1 |
| ONE FIGHT FORMULA | 8.6 | -147.2 | 39.1 | 180.4 | 8.0 | -191.0 | 15.6 | 170.8 |
| ONE OBJECTIVE FORMULA | 2.4 | -59.2 | 0.0 | 54.8 | 1.4 | -80.2 | 0.0 | 12.3 |
| OPENS A LANE | 0.1 | +0.1 | 2.5 | 0.0 | 0.2 | +1.6 | 32.0 | 0.0 |
| OPENS UP | 0.1 | +13.3 | 3.9 | 0.0 | 0.1 | +5.1 | 5.2 | 0.0 |
| OVERRUNS AWAY | 0.4 | +11.3 | 54.7 | 1.5 | 0.5 | +3.9 | 67.5 | 25.2 |
| PAIR SET-UP | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 15.1 | 0.0 |
| PATHS CROSS | 1.9 | +126.9 | 0.0 | 21.5 | 2.3 | +169.6 | 0.0 | 22.7 |
| PERIAPT WORTH | - | - | - | - | 0.0 | +2.8 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.2 | -1.2 | 0.0 | 22.5 | 0.1 | -1.2 | 0.0 | 0.0 |
| PLAN RESULT | 36.1 | +1110.8 | 1085.0 | 934.5 | 37.2 | +1224.3 | 1429.3 | 885.1 |
| PURSUES BIG PREY | 0.1 | -2.1 | 0.0 | 0.0 | 0.1 | -4.4 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE | - | - | - | - | 0.1 | +11.5 | 0.0 | 1.5 |
| RAIDS THE BAGGAGE NEXT TURN | 0.1 | +7.3 | 0.0 | 4.7 | 0.1 | +3.5 | 0.0 | 0.0 |
| RANDOM MOVE BY FIGURES | 0.6 | +4.3 | 0.0 | 4.7 | 1.4 | +21.1 | 0.0 | 61.4 |
| RANDOM MOVER NO PROMISE | 0.2 | -20.8 | 13.1 | 0.0 | 0.3 | -20.8 | 30.3 | 9.4 |
| REDIRECT BY WHAT IT STOPS | 0.6 | -14.0 | 0.0 | 21.8 | 1.2 | -39.2 | 0.0 | 28.3 |
| REDIRECT COUNTER | 1.9 | +163.7 | 0.0 | 43.4 | 3.3 | +286.4 | 0.0 | 46.1 |
| REDIRECT WEIGHED | 0.1 | +2.8 | 4.9 | 0.0 | 0.4 | +3.5 | 6.7 | 3.5 |
| REFUSING RETIRES | 0.2 | +0.0 | 0.0 | 14.3 | 0.3 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | 0.3 | +13.2 | 0.0 | 7.1 | 1.0 | +45.8 | 0.0 | 19.3 |
| RESTRAINS TO SHOOT | 0.1 | +10.5 | 0.0 | 0.0 | 0.1 | +1.7 | 0.0 | 0.0 |
| RISK BY ARC | 2.1 | +86.9 | 191.6 | 43.1 | 2.6 | +64.0 | 229.0 | 61.6 |
| RISK ONCE | 4.2 | +104.0 | 55.2 | 142.8 | 4.4 | +220.8 | 49.8 | 181.4 |
| SAFE SURE CHARGE | 0.0 | -2.4 | 0.0 | 0.0 | - | - | - | - |
| SAFER THAN THE JOB | 0.9 | +66.2 | 0.0 | 9.2 | 0.7 | +37.9 | 0.0 | 11.3 |
| SCOUT SPOT | 0.4 | +0.6 | 0.0 | 0.0 | 0.3 | +1.0 | 0.0 | 0.0 |
| SCOUT WAITS | 0.4 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.2 | -2.6 | 0.0 | 0.0 | 0.5 | -42.7 | 0.0 | 3.7 |
| SEARCH SPOT | 2.4 | +102.9 | 0.0 | 23.2 | 2.2 | +128.2 | 0.0 | 58.0 |
| SECOND CHARGER ADDS | - | - | - | - | 0.3 | -28.7 | 43.0 | 0.0 |
| SELF MOVE SPELL | 0.3 | +43.5 | 0.0 | 32.9 | 0.2 | +65.8 | 0.0 | 0.0 |
| SET UP TOGETHER | 1.4 | +160.7 | 57.9 | 35.8 | 2.1 | +183.8 | 20.9 | 38.3 |
| SET-UP ANY TARGET | 0.3 | +43.7 | 0.0 | 0.0 | 0.2 | +20.1 | 15.5 | 18.7 |
| SET-UP MISSED | 0.1 | +16.5 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | 0.4 | +0.7 | 0.0 | 0.0 | 0.1 | +0.3 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 0.9 | +24.4 | 39.1 | 0.0 | 1.4 | +33.9 | 62.8 | 11.7 |
| SHORT GUN FORWARD | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SHOT REPLANNED | 0.6 | +0.0 | 132.8 | 10.7 | 0.1 | +0.0 | 15.6 | 0.0 |
| SHOTS IN THE MOVE | 13.6 | +518.4 | 0.0 | 307.2 | 10.1 | +291.1 | 0.0 | 153.3 |
| SPELL SETS UP CHARGE | 0.4 | +59.8 | 0.0 | 0.0 | 0.2 | +27.9 | 15.5 | 18.7 |
| SPELL WORTH | 1.4 | +25.1 | 23.9 | 43.5 | 2.4 | +42.9 | 98.7 | 83.7 |
| SPELLS IN THE FIGHT | 0.5 | -6.5 | 59.8 | 20.2 | 0.5 | -14.0 | 52.2 | 0.5 |
| STABLE ROLE | 9.5 | +0.0 | 222.8 | 159.8 | 9.6 | +0.0 | 348.6 | 81.5 |
| STANDS TO CAST | 0.1 | +4.8 | 0.0 | 0.0 | - | - | - | - |
| STAY WEIGHED | - | - | - | - | 0.0 | +4.4 | 0.0 | 0.0 |
| STOPS | 0.2 | +5.8 | 3.5 | 2.5 | 0.1 | +1.9 | 1.9 | 0.5 |
| STOPS SHORT OF THE FLANK | 0.5 | +23.6 | 0.0 | 4.5 | 0.5 | +21.5 | 0.0 | 7.1 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| SUPPORT NARROWED | 5.8 | -58.0 | 177.0 | 161.2 | 6.1 | -51.4 | 367.0 | 84.8 |
| SUPPORTS | 4.1 | +68.6 | 69.7 | 115.1 | 4.3 | +55.0 | 200.4 | 53.9 |
| SURE CHARGE BEATS ADVANCE | 0.2 | -3.0 | 22.2 | 0.0 | 0.2 | -4.7 | 8.7 | 5.2 |
| SURE REACH TOGETHER | 0.4 | +1.8 | 7.9 | 17.0 | 0.8 | -8.8 | 6.8 | 2.0 |
| THROUGH LINE OF FIRE | 0.4 | +17.0 | 0.0 | 0.0 | 0.2 | +17.9 | 0.0 | 6.2 |
| TURN WORTH | 0.3 | -22.9 | 36.1 | 1.5 | 0.3 | -18.5 | 22.6 | 5.4 |
| TWO OR MORE ARRIVE | 0.4 | +5.7 | 13.9 | 6.5 | 0.7 | +3.5 | 8.6 | 29.0 |
| WAIT AFTER COSTS | 7.4 | -357.6 | 288.0 | 91.1 | 7.2 | -338.3 | 282.0 | 117.5 |
| WALKS TO THE FIGHT | 1.6 | +13.5 | 23.3 | 6.5 | 1.0 | +4.6 | 67.8 | 0.0 |
| WAR ENGINE CHARGES | 0.0 | +3.6 | 0.0 | 0.0 | 0.1 | +5.6 | 2.4 | 0.0 |
| WAR ENGINE JOBS | 0.8 | +0.0 | 23.7 | 30.7 | 0.2 | +0.0 | 4.6 | 0.0 |
| WEARS DOWN | 1.0 | +39.9 | 100.6 | 25.7 | 1.2 | +42.8 | 159.8 | 26.4 |
| WHO HITS BACK | 0.2 | +14.8 | 0.0 | 0.0 | 0.1 | +3.9 | 0.0 | 3.9 |
| WHOLE FIGHT | 0.2 | +10.8 | 67.2 | 1.5 | 0.3 | -0.3 | 23.8 | 0.0 |
| WHOLE FIGHT GAIN | 0.1 | +4.9 | 1.1 | 0.0 | 0.8 | +35.9 | 98.7 | 10.4 |
| WIDER SPREAD | 1.8 | -8.5 | 128.4 | 36.6 | 2.8 | -10.2 | 253.8 | 17.9 |
| WOUNDED STAYS OUT | - | - | - | - | 0.0 | +0.0 | 6.5 | 0.0 |

### Rule changes: jc-opp-1e5408d-p3

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 1144 | 1144 | 1144 | 31.78 | -53705 | -46.9 |
| MOVE TO CHARGE | 313 | 313 | 171 | 4.75 | +11399 | +66.7 |
| SEARCH SPOT | 167 | 167 | 163 | 4.53 | +8322 | +51.1 |
| KILLS COUNT NEXT TURN | 463 | 463 | 151 | 4.19 | +4043 | +26.8 |
| PATHS CROSS | 150 | 150 | 150 | 4.17 | +10674 | +71.2 |
| FACES THE THREAT | 134 | 134 | 134 | 3.72 | +10127 | +75.6 |
| SUPPORTS | 301 | 301 | 123 | 3.42 | +1532 | +12.5 |
| BEST FIRST | 88 | 88 | 88 | 2.44 | +4606 | +52.3 |
| SHOTS IN THE MOVE | 853 | 580 | 84 | 2.33 | +2374 | +28.3 |
| WAIT AFTER COSTS | 526 | 526 | 82 | 2.28 | +1525 | +18.6 |
| FOLLOW UP WEIGHED | 79 | 79 | 79 | 2.19 | +11788 | +149.2 |
| COVER ONCE | 492 | 259 | 75 | 2.08 | +1504 | +20.1 |
| FALLBACK BY WORTH | 343 | 343 | 70 | 1.94 | +2764 | +39.5 |
| ADVANCE WORTH | 321 | 321 | 65 | 1.81 | +1004 | +15.4 |
| ARTILLERY RE-ROLL WEIGHED | 65 | 65 | 65 | 1.81 | +0 | +0.0 |
| SAFER THAN THE JOB | 58 | 58 | 58 | 1.61 | +3748 | +64.6 |
| CANNON SIGHT KEPT | 56 | 56 | 56 | 1.56 | +0 | +0.0 |
| RISK ONCE | 313 | 218 | 56 | 1.56 | +1754 | +31.3 |
| SET UP TOGETHER | 126 | 106 | 52 | 1.44 | +4636 | +89.2 |
| CANNON PLANNED TARGET | 241 | 241 | 49 | 1.36 | -582 | -11.9 |
| CHAFF IN THE MOVE | 89 | 87 | 48 | 1.33 | +1416 | +29.5 |
| RESERVE FALL BACK | 48 | 48 | 48 | 1.33 | +2124 | +44.3 |
| MISSILES IN THE MOVE | 280 | 164 | 47 | 1.31 | +823 | +17.5 |
| ONE FIGHT FORMULA | 600 | 343 | 45 | 1.25 | +194 | +4.3 |
| REDIRECT COUNTER | 187 | 90 | 43 | 1.19 | +4326 | +100.6 |
| HOLDS AMBUSHERS | 39 | 39 | 39 | 1.08 | +0 | +0.0 |
| MARCH CHECK | 42 | 41 | 38 | 1.06 | +1628 | +42.8 |
| STOPS SHORT OF THE FLANK | 36 | 36 | 36 | 1.00 | +1623 | +45.1 |
| ADVANCE LANE KEPT | 35 | 35 | 35 | 0.97 | +0 | +0.0 |
| CHARGE NOW WEIGHED | 35 | 35 | 35 | 0.97 | +3913 | +111.8 |
| COMBAT PIVOT | 34 | 34 | 34 | 0.94 | +0 | +0.0 |
| RANDOM MOVE BY FIGURES | 71 | 71 | 34 | 0.94 | +917 | +27.0 |
| WALKS TO THE FIGHT | 92 | 92 | 34 | 0.94 | +212 | +6.2 |
| BEST FACING | 33 | 33 | 33 | 0.92 | +1637 | +49.6 |
| LONE WIZARD KEPT IN | 33 | 33 | 33 | 0.92 | +2259 | +68.5 |
| MOVE AND CAST | 33 | 33 | 33 | 0.92 | +1535 | +46.5 |
| RISK BY ARC | 169 | 168 | 33 | 0.92 | +1033 | +31.3 |
| CAST JOB | 62 | 62 | 31 | 0.86 | +478 | +15.4 |
| IDLE COST | 1209 | 669 | 31 | 0.86 | +358 | +11.5 |
| KILLS COUNT | 122 | 121 | 30 | 0.83 | +1209 | +40.3 |
| SHOOTS FROM THE BEST SPOT | 82 | 82 | 30 | 0.83 | +762 | +25.4 |
| BEST OVERALL | 29 | 29 | 29 | 0.81 | +1380 | +47.6 |
| CHARGE NOW FIRST | 166 | 166 | 29 | 0.81 | -1986 | -68.5 |
| MAX FOR POSITIONING | 477 | 269 | 27 | 0.75 | +62 | +2.3 |
| HONEST WORTH | 617 | 616 | 25 | 0.69 | +177 | +7.1 |
| KEEPS ITS TARGET | 153 | 152 | 25 | 0.69 | +417 | +16.7 |
| SCOUT WAITS | 25 | 25 | 25 | 0.69 | +0 | +0.0 |
| BLOCKED WHEEL | 23 | 23 | 23 | 0.64 | +1057 | +46.0 |
| MAKE SURE TOGETHER | 73 | 49 | 23 | 0.64 | +2484 | +108.0 |
| SHOT REPLANNED | 23 | 23 | 23 | 0.64 | +0 | +0.0 |
| THROUGH LINE OF FIRE | 23 | 23 | 23 | 0.64 | +1258 | +54.7 |
| WAR ENGINE JOBS | 36 | 36 | 23 | 0.64 | -1174 | -51.0 |
| INVITES THE FIGHT | 65 | 65 | 21 | 0.58 | +127 | +6.0 |
| REDIRECT WEIGHED | 20 | 20 | 20 | 0.56 | +318 | +15.9 |
| MANOEUVRE | 23 | 23 | 18 | 0.50 | +439 | +24.4 |
| SHOOTERS IN TWO RANKS | 18 | 18 | 18 | 0.50 | +36 | +2.0 |
| BIG CHARACTER SAFETY | 17 | 17 | 17 | 0.47 | -86 | -5.1 |
| MARCH ODDS | 17 | 17 | 17 | 0.47 | +127 | +7.4 |
| CHAFF PASSED | 16 | 16 | 16 | 0.44 | -23 | -1.5 |
| BEST PREY | 41 | 41 | 14 | 0.39 | +238 | +17.0 |
| FRIENDS SHOTS CHECKED | 14 | 14 | 14 | 0.39 | +1472 | +105.2 |
| SURE CHARGE BEATS ADVANCE | 14 | 14 | 14 | 0.39 | -278 | -19.9 |
| LOST CHARGE | 190 | 190 | 13 | 0.36 | +211 | +16.2 |
| WHO HITS BACK | 13 | 13 | 13 | 0.36 | +401 | +30.8 |
| WHOLE FIGHT GAIN | 34 | 34 | 12 | 0.33 | +352 | +29.3 |
| HUNT IN PAIRS | 34 | 19 | 11 | 0.31 | +221 | +20.1 |
| SUPPORT NARROWED | 430 | 430 | 11 | 0.31 | -104 | -9.5 |
| PIVOT GUARDS FLANK | 10 | 10 | 10 | 0.28 | -87 | -8.7 |
| CASTER AWAY FROM SCREEN | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| CASTS FROM BEHIND | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| MISSILES NEXT TURN | 361 | 213 | 8 | 0.22 | +66 | +8.3 |
| WEARS DOWN | 80 | 80 | 8 | 0.22 | +160 | +19.9 |
| MOVES UNITS SPELL | 7 | 7 | 7 | 0.19 | +141 | +20.1 |
| BEST PRIZE | 6 | 6 | 6 | 0.17 | -512 | -85.3 |
| CASTING BLOCK | 9 | 9 | 6 | 0.17 | +78 | +13.0 |
| KEEP FALLS | 6 | 6 | 6 | 0.17 | +149 | +24.8 |
| STUCK PIVOT | 6 | 6 | 6 | 0.17 | +0 | +0.0 |
| ONE OBJECTIVE FORMULA | 135 | 62 | 5 | 0.14 | +288 | +57.5 |
| OPENS UP | 9 | 9 | 5 | 0.14 | +237 | +47.4 |
| PURSUES BIG PREY | 5 | 5 | 5 | 0.14 | -232 | -46.3 |
| RAIDS THE BAGGAGE NEXT TURN | 5 | 5 | 5 | 0.14 | +174 | +34.8 |
| SHORT GUN FORWARD | 5 | 5 | 5 | 0.14 | +0 | +0.0 |
| HUNT ADVANCE | 12 | 12 | 4 | 0.11 | +181 | +45.2 |
| MODEL FACING | 4 | 4 | 4 | 0.11 | +1392 | +347.9 |
| OVERRUNS AWAY | 35 | 35 | 4 | 0.11 | +60 | +15.1 |
| RESTRAINS TO SHOOT | 4 | 4 | 4 | 0.11 | +440 | +110.1 |
| STANDS TO CAST | 4 | 4 | 4 | 0.11 | -40 | -10.0 |
| SURE REACH TOGETHER | 40 | 31 | 4 | 0.11 | +7 | +1.7 |
| BLOCKED CHARGE SKIPPED | 3 | 3 | 3 | 0.08 | +0 | +0.0 |
| EDGE GIVE GROUND | 18 | 18 | 3 | 0.08 | +72 | +24.0 |
| REFUSING RETIRES | 17 | 17 | 3 | 0.08 | -0 | -0.1 |
| ELIXIR WORTH | 2 | 2 | 2 | 0.06 | +38 | +18.9 |
| HORN WORTH | 2 | 2 | 2 | 0.06 | +27 | +13.7 |
| LONE WIZARD HOLDS BACK | 15 | 15 | 2 | 0.06 | -176 | -88.1 |
| LONG SHOT | 19 | 19 | 2 | 0.06 | +11 | +5.6 |
| NEEDED THERE | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| NO RALLY LEFT | 2 | 2 | 2 | 0.06 | +30 | +15.2 |
| RAIDS THE BAGGAGE | 2 | 2 | 2 | 0.06 | +322 | +160.9 |
| SPELLS IN THE FIGHT | 38 | 37 | 2 | 0.06 | +28 | +13.8 |
| WAR ENGINE CHARGES | 4 | 4 | 2 | 0.06 | +104 | +51.9 |
| WIDER SPREAD | 165 | 164 | 2 | 0.06 | +8 | +3.8 |
| BACKUP TARGETS | 51 | 30 | 1 | 0.03 | +0 | +0.0 |
| BOMBING RUN | 1 | 1 | 1 | 0.03 | +27 | +27.1 |
| BOUND ASSAILMENT | 1 | 1 | 1 | 0.03 | +0 | +0.1 |
| CARRIES OUT SET-UP | 9 | 9 | 1 | 0.03 | -28 | -28.1 |
| CATCH ODDS | 1 | 1 | 1 | 0.03 | -5 | -5.3 |
| CHARGER SLAIN LOST | 36 | 35 | 1 | 0.03 | +48 | +48.1 |
| CONTINUE AHEAD WEIGHED | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| DEFENSIVE ARMY | 9 | 9 | 1 | 0.03 | -7 | -7.2 |
| DEFENSIVE FLOOR | 1 | 1 | 1 | 0.03 | +52 | +52.2 |
| FIRE AND FLEE | 1 | 1 | 1 | 0.03 | +15 | +15.1 |
| JOINT CHARGE PLAN | 11 | 11 | 1 | 0.03 | +26 | +26.2 |
| KEEPS ITS PREY | 8 | 8 | 1 | 0.03 | +8 | +8.4 |
| KEEPS SCOUTS OR AMBUSH | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.03 | +99 | +99.4 |
| SAFE SURE CHARGE | 1 | 1 | 1 | 0.03 | -87 | -87.2 |
| SCREEN BY WHAT IT SAVES | 25 | 25 | 1 | 0.03 | +5 | +4.6 |
| STAY WEIGHED | 1 | 1 | 1 | 0.03 | +157 | +157.0 |
| STOPS | 12 | 12 | 1 | 0.03 | +5 | +5.0 |
| TWO OR MORE ARRIVE | 38 | 33 | 1 | 0.03 | +14 | +14.1 |
| WHOLE FIGHT | 20 | 20 | 1 | 0.03 | +2 | +2.3 |
| ALREADY CARRIED | 6 | not checked | - | - | - | - |
| ARRIVAL HUNT | 2 | 2 | 0 | 0.00 | - | - |
| BLOWS WHERE AIMED | 19 | 19 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 31 | 31 | 0 | 0.00 | - | - |
| CARRIES OUT COUNTER | 2 | 2 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 32 | trace | - | - | - | - |
| CHARIOT WIZARD CAREFUL | 6 | 6 | 0 | 0.00 | - | - |
| CHEAP HELPER | 1 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 35 | not checked | - | - | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT LIFT | 5 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 380 | not checked | - | - | - | - |
| FRIEND IN REACH | 292 | not checked | - | - | - | - |
| GIVES UP | 6 | 6 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 1 | 1 | 0 | 0.00 | - | - |
| HELPER ALREADY ASKED | 4 | not checked | - | - | - | - |
| HELPER UNSEEN | 28 | 28 | 0 | 0.00 | - | - |
| HILL BY ITS CHANCE | 23 | 23 | 0 | 0.00 | - | - |
| HUNT DROPPED | 5 | trace | - | - | - | - |
| HUNT KEPT | 14 | trace | - | - | - | - |
| HUNT RESULT | 9 | trace | - | - | - | - |
| HUNT THE GUNS | 13 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 5 | 5 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 18 | not checked | - | - | - | - |
| LURE BY WHAT IT DRAWS | 8 | 8 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 6 | trace | - | - | - | - |
| MARCH OVER CASTS | 44 | 44 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 15 | 15 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 11 | 6 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 19 | trace | - | - | - | - |
| MOVE SPELL SPOT | 11 | not checked | - | - | - | - |
| NOT NEEDED | 5 | 5 | 0 | 0.00 | - | - |
| NOT TURNED | 391 | 391 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 49 | not checked | - | - | - | - |
| OPENS A LANE | 10 | 4 | 0 | 0.00 | - | - |
| PAIR SET-UP | 6 | not checked | - | - | - | - |
| PLAN RESULT | 2638 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 21 | 21 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 67 | 67 | 0 | 0.00 | - | - |
| SCOUT SPOT | 24 | 24 | 0 | 0.00 | - | - |
| SECOND CHARGER ADDS | 11 | 11 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 17 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 17 | not checked | - | - | - | - |
| SET-UP MISSED | 3 | trace | - | - | - | - |
| SPELL SETS UP CHARGE | 21 | not checked | - | - | - | - |
| SPELL WORTH | 136 | not checked | - | - | - | - |
| STABLE ROLE | 686 | 685 | 0 | 0.00 | - | - |
| TURN WORTH | 22 | 22 | 0 | 0.00 | - | - |
| WOUNDED STAYS OUT | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: jc-opp-1e5408d-p3

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 15.03 | 14.03 | 47.4 |
| FALLBACK | gate | 0.50 | 0.67 | 62.7 |
| CHARGE NOW FIRST | rule | 0.47 | 0.33 | 68.5 |
| TURN GATE | gate | 0.44 | 0.33 | 39.2 |
| WAR ENGINE JOBS | rule | 0.53 | 0.08 | 53.3 |
| CANNON PLANNED TARGET | rule | 0.28 | 0.08 | 50.7 |
| SURE CHARGE BEATS ADVANCE | rule | 0.17 | 0.19 | 21.4 |
| AFTERMATH BAND | gate | 0.25 | 0.08 | 2.6 |
| SUPPORT NARROWED | rule | 0.17 | 0.14 | 9.5 |
| BIG CHARACTER SAFETY | rule | 0.14 | 0.14 | 10.8 |
| PIVOT GUARDS FLANK | rule | 0.17 | 0.11 | 8.7 |
| CHAFF PASSED | rule | - | 0.22 | 2.9 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.08 | 0.06 | 23.1 |
| BEST PRIZE | rule | 0.08 | 0.06 | 102.4 |
| PURSUES BIG PREY | rule | 0.06 | 0.08 | 46.3 |
| CHARGE NOW WEIGHED | rule | 0.06 | 0.06 | 74.8 |
| FIGHT ORDER BAND | gate | 0.03 | 0.08 | 2.0 |
| PATHS CROSS | rule | 0.08 | 0.03 | 22.5 |
| STOPS SHORT OF THE FLANK | rule | 0.03 | 0.08 | 11.9 |
| FACES THE THREAT | rule | 0.06 | 0.03 | 8.3 |
| LONE CHARACTER SAFE SPOT | gate | 0.03 | 0.06 | 20.1 |
| SAFER THAN THE JOB | rule | 0.06 | 0.03 | 11.7 |
| STANDS TO CAST | rule | 0.08 | - | 13.1 |
| WHO HITS BACK | rule | 0.06 | 0.03 | 4.4 |
| LONE WIZARD HOLDS BACK | rule | 0.03 | 0.03 | 88.1 |
| MARCH ODDS | rule | 0.03 | 0.03 | 3.0 |
| NO REASON | gate | - | 0.06 | 11.8 |
| SUPPORT REQUEST | gate | 0.03 | 0.03 | 77.0 |
| THROUGH LINE OF FIRE | rule | 0.06 | - | 3.5 |
| BLOCKED WHEEL | rule | - | 0.03 | 122.2 |
| CARRIES OUT SET-UP | rule | - | 0.03 | 28.1 |
| CATCH ODDS | rule | 0.03 | - | 5.3 |
| DEFENSIVE ARMY | rule | 0.03 | - | 7.2 |
| FALLBACK BY WORTH | rule | - | 0.03 | 3.5 |
| MOVE AND CAST | rule | - | 0.03 | 6.0 |
| REDIRECT WEIGHED | rule | 0.03 | - | 28.3 |
| SAFE SURE CHARGE | rule | 0.03 | - | 87.2 |

### Plans: jc-opp-1e5408d-p3

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 9.6 | 16% | 126 | 171 | 136% |
| Mine | charge | 2.6 | 62% | 238 | 206 | 86% |
| Mine | close in | 5.3 | 24% | 385 | 176 | 46% |
| Mine | hold | 4.9 | 38% | 291 | 0 | 0% |
| Mine | join | 0.4 | 93% | 17 | 0 | 0% |
| Mine | shoot | 8.6 | 59% | 189 | 557 | 294% |
| Mine | support | 4.7 | 88% | 53 | 0 | 0% |
| Opponent | advance | 10.1 | 20% | 159 | 327 | 206% |
| Opponent | charge | 3.8 | 62% | 331 | 376 | 113% |
| Opponent | close in | 7.1 | 24% | 435 | 225 | 52% |
| Opponent | hold | 3.7 | 28% | 281 | 0 | 0% |
| Opponent | join | 0.6 | 100% | 31 | 0 | 0% |
| Opponent | shoot | 5.8 | 54% | 133 | 301 | 226% |
| Opponent | support | 5.9 | 85% | 40 | 0 | 0% |

### Packages: hunt the guns, jc-opp-1e5408d-p3

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.1 | 5 | 3 | 50% | 50% | 0% | 3.0 | 412 | 104 | 0% | 27 |
| Opponent | 0.2 | 8 | 1 | 14% | 29% | 0% | 2.0 | 294 | 48 | 29% | 76 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.8 | 3 | 2 | 0% | 0% | 0% | - | 448 | 0 | 0% | 34 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Empire of Man | 0.2 | 1 | 0 | 100% | 100% | 0% | 3.0 | 375 | 208 | 0% | 110 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 21 |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 110 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Ogre Kingdoms | 1.0 | 1 | 1 | - | - | - | - | - | - | - | 0 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 270 |
| Tomb Kings of Khemri | 0.3 | 2 | 0 | 0% | 0% | 0% | - | 315 | 0 | 0% | 77 |
| Vampire Counts | 0.1 | 1 | 0 | 100% | 100% | 0% | 2.0 | 78 | 76 | 100% | 21 |
| Warriors of Chaos | 0.1 | 1 | 0 | 0% | 100% | 0% | 2.0 | 304 | 259 | 100% | 50 |
| Wood Elf Realms | 0.7 | 4 | 1 | 0% | 0% | 0% | - | 348 | 0 | 0% | 42 |

### Battle groups: jc-opp-1e5408d-p3

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 1.9 | 41% | 75% | 11% | 33% | 20% | 0% | 12% | 68% | 0% |
| Opponent | REDIRECT COUNTER | 3.3 | 19% | 78% | 17% | 25% | 26% | 0% | 11% | 63% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: jc-opp-1e5408d-p3

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 1 | 0 (1) | 0 | 0 | 100 | 0% | 5.0 | - | - | 0 (1) | - | 0 (1) |
| Mine | Chaff | 34 | 74 (34) | 23 | 51 | 45 | 29% | 2.4 | 84 (21) | 0 (4) | 72 (9) | 94 (24) | 32 (10) |
| Mine | Character | 118 | 45 (118) | 45 | 0 | 34 | 20% | 2.4 | 59 (40) | 44 (60) | 29 (3) | 44 (57) | 56 (46) |
| Mine | Clean-up | 18 | 58 (18) | 22 | 36 | 50 | 33% | 2.8 | 59 (3) | 50 (13) | 157 (2) | 80 (12) | 24 (6) |
| Mine | Fast | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Mine | Fast Hammer | 44 | 24 (44) | 10 | 14 | 37 | 36% | 2.6 | 23 (22) | 24 (14) | 27 (8) | 29 (30) | 15 (14) |
| Mine | Fragile | 3 | 0 (3) | 0 | 0 | 33 | 67% | 4.0 | 0 (3) | - | - | 0 (1) | 0 (2) |
| Mine | Hammer | 52 | 37 (52) | 26 | 10 | 35 | 12% | 2.6 | 15 (14) | 41 (35) | 79 (3) | 39 (36) | 33 (16) |
| Mine | Holder | 25 | 63 (25) | 20 | 43 | 39 | 36% | 3.5 | 40 (8) | 77 (10) | 61 (7) | 67 (15) | 58 (10) |
| Mine | Shooter | 37 | 57 (37) | 26 | 31 | 54 | 0% | 2.0 | 33 (6) | 66 (29) | 0 (2) | 62 (22) | 51 (15) |
| Mine | Support | 4 | 0 (4) | 0 | 0 | 100 | 0% | 2.5 | 0 (1) | - | - | 0 (1) | - |
| Mine | War machine | 52 | 42 (52) | 42 | 0 | 50 | 2% | 1.1 | 64 (13) | 33 (36) | 55 (3) | 59 (13) | 36 (39) |
| Mine | Wizard | 17 | 18 (17) | 18 | 0 | 36 | 6% | 2.4 | 46 (4) | 18 (8) | 0 (1) | 17 (8) | 39 (5) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Chaff | 68 | 43 (68) | 19 | 24 | 55 | 44% | 3.0 | 57 (29) | 32 (11) | 37 (28) | 49 (48) | 29 (20) |
| Opponent | Character | 102 | 57 (102) | 57 | 1 | 27 | 21% | 2.1 | 54 (37) | 66 (52) | 29 (6) | 60 (54) | 59 (41) |
| Opponent | Clean-up | 11 | 75 (11) | 10 | 65 | 11 | 55% | 3.4 | 9 (4) | 95 (6) | 204 (1) | 40 (6) | 109 (5) |
| Opponent | Fast | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Fast Hammer | 60 | 49 (60) | 31 | 18 | 48 | 20% | 2.9 | 46 (30) | 57 (20) | 38 (10) | 65 (28) | 33 (32) |
| Opponent | Fragile | 3 | 0 (3) | 0 | 0 | 67 | 0% | 2.3 | - | 0 (2) | 0 (1) | 0 (2) | 0 (1) |
| Opponent | Hammer | 50 | 22 (50) | 16 | 6 | 55 | 28% | 2.7 | 34 (17) | 15 (30) | 60 (3) | 25 (30) | 16 (20) |
| Opponent | Holder | 40 | 63 (40) | 10 | 53 | 26 | 25% | 3.1 | 34 (10) | 88 (20) | 36 (10) | 74 (27) | 42 (13) |
| Opponent | Shooter | 27 | 48 (27) | 27 | 21 | 27 | 7% | 1.3 | 84 (6) | 33 (19) | 87 (2) | 62 (16) | 28 (11) |
| Opponent | Support | 4 | 0 (4) | 0 | 0 | 17 | 50% | 6.0 | 0 (2) | 0 (1) | 0 (1) | 0 (1) | 0 (3) |
| Opponent | War machine | 17 | 47 (17) | 47 | 0 | 27 | 0% | 1.5 | 0 (3) | 50 (10) | 66 (4) | 0 (3) | 55 (14) |
| Opponent | Wizard | 32 | 20 (32) | 20 | 0 | 25 | 12% | 2.2 | 16 (15) | 38 (8) | 26 (3) | 35 (16) | 0 (10) |

### Charged fights: jc-opp-1e5408d-p3

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 39 | 0 | 0.5 | 1.0 | 0 | 0 | +0 | 0 of 2 | 1 of 2 | - | +0 |
| Mine | Chaos Dwarfs | 4 | 103 | 290 | 3.2 | 1.0 | 89 | 24 | +65 | 6 of 13 | 11 of 13 | - | +65 |
| Mine | Dwarfen Mountain Holds | 3 | 467 | 157 | 2.3 | 1.1 | 67 | 9 | +59 | 2 of 7 | 4 of 7 | +0 | +68 |
| Mine | Empire of Man | 5 | 523 | 201 | 1.2 | 1.2 | 167 | 0 | +167 | 0 of 6 | 6 of 6 | +663 | +68 |
| Mine | Grand Cathay | 5 | 241 | 374 | 2.8 | 1.1 | 134 | 15 | +119 | 8 of 14 | 12 of 14 | +223 | +102 |
| Mine | High Elf Realms | 4 | 152 | 588 | 4.0 | 1.2 | 147 | 23 | +124 | 8 of 16 | 12 of 16 | +185 | +110 |
| Mine | Kingdom of Bretonnia | 1 | 19 | 0 | 2.0 | 1.0 | 0 | 191 | -191 | 0 of 2 | 0 of 2 | - | -191 |
| Mine | Lizardmen | 1 | 0 | 484 | 5.0 | 1.0 | 97 | 28 | +69 | 1 of 5 | 4 of 5 | - | +69 |
| Mine | Ogre Kingdoms | 1 | 232 | 0 | 4.0 | 1.0 | 0 | 31 | -31 | 3 of 4 | 2 of 4 | - | -31 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 616 | 5.0 | 1.0 | 123 | 11 | +112 | 1 of 5 | 3 of 5 | - | +112 |
| Mine | Skaven | 1 | 0 | 19 | 1.0 | 2.0 | 19 | 0 | +19 | 0 of 1 | 1 of 1 | +19 | - |
| Mine | Tomb Kings of Khemri | 2 | 0 | 504 | 6.5 | 1.2 | 78 | 63 | +14 | 4 of 13 | 9 of 13 | +185 | -17 |
| Mine | Vampire Counts | 2 | 358 | 464 | 4.0 | 1.0 | 116 | 82 | +34 | 3 of 8 | 7 of 8 | - | +34 |
| Mine | Warriors of Chaos | 2 | 0 | 412 | 4.0 | 1.0 | 103 | 14 | +88 | 3 of 8 | 7 of 8 | - | +88 |
| **Mine** | all armies | 36 | 205 | 298 | 2.9 | 1.1 | 103 | 31 | +72 | 39 of 104 | 79 of 104 | +205 | +58 |
| Opponent | Empire of Man | 1 | 569 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Grand Cathay | 3 | 458 | 382 | 3.0 | 1.1 | 127 | 48 | +79 | 5 of 9 | 4 of 9 | +0 | +89 |
| Opponent | High Elf Realms | 3 | 376 | 42 | 2.0 | 1.2 | 21 | 58 | -37 | 2 of 6 | 3 of 6 | +125 | -69 |
| Opponent | Kingdom of Bretonnia | 2 | 272 | 347 | 4.0 | 1.0 | 87 | 27 | +60 | 4 of 8 | 6 of 8 | - | +60 |
| Opponent | Orc & Goblin Tribes | 1 | 0 | 571 | 4.0 | 1.2 | 143 | 26 | +117 | 2 of 4 | 3 of 4 | +0 | +156 |
| Opponent | Skaven | 1 | 235 | 186 | 2.0 | 1.5 | 93 | 50 | +43 | 1 of 2 | 1 of 2 | -100 | +186 |
| Opponent | Tomb Kings of Khemri | 4 | 46 | 724 | 3.8 | 1.1 | 193 | 26 | +167 | 8 of 15 | 10 of 15 | +95 | +172 |
| Opponent | Vampire Counts | 6 | 83 | 449 | 3.8 | 1.3 | 117 | 40 | +77 | 9 of 23 | 16 of 23 | +123 | +61 |
| Opponent | Warriors of Chaos | 9 | 0 | 555 | 4.0 | 1.2 | 139 | 0 | +139 | 16 of 36 | 27 of 36 | +204 | +128 |
| Opponent | Wood Elf Realms | 6 | 75 | 220 | 2.5 | 1.3 | 88 | 32 | +56 | 3 of 15 | 12 of 15 | +14 | +71 |
| **Opponent** | all armies | 36 | 138 | 406 | 3.3 | 1.2 | 124 | 25 | +99 | 50 of 118 | 82 of 118 | +97 | +99 |

### Effective charges: jc-opp-1e5408d-p3

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 2 | 0 | 0 | 1 (net +0) | 0 | 0 | 0 | 1 | 100% (1 of 1) |
| Mine | Chaos Dwarfs | 13 | 1 (net +0) | 0 | 2 (net +200) | 7 (net +9) | 0 | 2 (net +104) | 1 | 17% (2 of 12) |
| Mine | Dwarfen Mountain Holds | 7 | 2 (net +0) | 0 | 1 (net +0) | 2 (net -30) | 0 | 2 (net +236) | 0 | 14% (1 of 7) |
| Mine | Empire of Man | 6 | 0 | 0 | 1 (net +125) | 1 (net +0) | 2 (net +368) | 2 (net +72) | 0 | 17% (1 of 6) |
| Mine | Grand Cathay | 14 | 1 (net +0) | 3 (net +71) | 2 (net +40) | 1 (net +70) | 1 (net +55) | 5 (net +216) | 1 | 15% (2 of 13) |
| Mine | High Elf Realms | 16 | 1 (net -175) | 0 | 2 (net +0) | 2 (net -100) | 7 (net +184) | 3 (net +330) | 1 | 13% (2 of 15) |
| Mine | Kingdom of Bretonnia | 2 | 1 (net -275) | 0 | 0 | 0 | 0 | 0 | 1 | 0% (0 of 1) |
| Mine | Lizardmen | 5 | 0 | 0 | 1 (net +0) | 1 (net +144) | 1 (net +0) | 0 | 2 | 33% (1 of 3) |
| Mine | Ogre Kingdoms | 4 | 0 | 0 | 1 (net -90) | 1 (net +0) | 0 | 1 (net +0) | 1 | 33% (1 of 3) |
| Mine | Orc & Goblin Tribes | 5 | 1 (net +0) | 0 | 1 (net +0) | 0 | 0 | 1 (net +254) | 2 | 33% (1 of 3) |
| Mine | Skaven | 1 | 0 | 0 | 0 | 1 (net +19) | 0 | 0 | 0 | 0% (0 of 1) |
| Mine | Tomb Kings of Khemri | 13 | 0 | 0 | 4 (net +64) | 6 (net -22) | 0 | 3 (net +22) | 0 | 31% (4 of 13) |
| Mine | Vampire Counts | 8 | 0 | 1 (net -60) | 1 (net -599) | 1 (net +80) | 0 | 5 (net +169) | 0 | 12% (1 of 8) |
| Mine | Warriors of Chaos | 8 | 1 (net +28) | 0 | 1 (net +0) | 1 (net +109) | 0 | 2 (net +203) | 3 | 20% (1 of 5) |
| Opponent | Grand Cathay | 9 | 2 (net -217) | 0 | 2 (net +42) | 4 (net +266) | 0 | 1 (net +0) | 0 | 22% (2 of 9) |
| Opponent | High Elf Realms | 6 | 2 (net -174) | 0 | 2 (net +0) | 0 | 0 | 1 (net +125) | 1 | 40% (2 of 5) |
| Opponent | Kingdom of Bretonnia | 8 | 2 (net +2) | 2 (net +122) | 1 (net +65) | 1 (net +168) | 0 | 2 (net +0) | 0 | 12% (1 of 8) |
| Opponent | Orc & Goblin Tribes | 4 | 0 | 0 | 0 | 0 | 0 | 2 (net +198) | 2 | 0% (0 of 2) |
| Opponent | Skaven | 2 | 0 | 0 | 0 | 2 (net +43) | 0 | 0 | 0 | 0% (0 of 2) |
| Opponent | Tomb Kings of Khemri | 15 | 4 (net +230) | 0 | 2 (net +250) | 3 (net +129) | 3 (net +32) | 3 (net +201) | 0 | 13% (2 of 15) |
| Opponent | Vampire Counts | 23 | 7 (net +111) | 0 | 4 (net -19) | 5 (net +140) | 5 (net +74) | 2 (net +0) | 0 | 17% (4 of 23) |
| Opponent | Warriors of Chaos | 36 | 5 (net +93) | 1 (net +104) | 10 (net +120) | 5 (net +270) | 2 (net +74) | 10 (net +164) | 3 | 30% (10 of 33) |
| Opponent | Wood Elf Realms | 15 | 1 (net +126) | 1 (net -163) | 1 (net +0) | 3 (net +120) | 1 (net +60) | 2 (net +132) | 6 | 11% (1 of 9) |

### Charged fights, damage counted: jc-opp-1e5408d-p3

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 8 | 137 | 221 | -53 | 50 | 84 | -34 | -25.2 |
| Mine | 50-54% | 4 | 233 | 246 | +38 | 116 | 100 | +16 | +7.0 |
| Mine | Effective (55-75%) | 18 | 208 | 269 | +10 | 71 | 44 | +27 | +12.8 |
| Mine | 76-89% | 24 | 293 | 186 | +4 | 83 | 83 | +0 | +0.1 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 26 | 266 | 195 | +172 | 186 | 26 | +160 | +60.1 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 11 | 494 | 112 | +189 | 207 | 17 | +189 | +38.3 |
| Mine | No odds | 13 | 290 | 141 | +73 | 121 | 29 | +92 | +31.6 |
| Mine | All fights | 104 | 278 | 194 | +72 | 123 | 49 | +74 | +26.7 |
| Opponent | Long shot (under 50%) | 23 | 220 | 243 | +66 | 155 | 96 | +59 | +26.7 |
| Opponent | 50-54% | 4 | 228 | 287 | +46 | 87 | 41 | +46 | +20.3 |
| Opponent | Effective (55-75%) | 22 | 265 | 221 | +80 | 125 | 33 | +92 | +34.7 |
| Opponent | 76-89% | 23 | 356 | 226 | +179 | 203 | 39 | +164 | +46.1 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 23 | 357 | 231 | +132 | 177 | 19 | +158 | +44.1 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 11 | 426 | 103 | +61 | 89 | 25 | +64 | +15.0 |
| Opponent | No odds | 12 | 141 | 175 | +30 | 91 | 57 | +34 | +24.2 |
| Opponent | All fights | 118 | 293 | 215 | +99 | 148 | 46 | +102 | +34.9 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| jc-opp-1e5408d-p3 | move | 386 | 86 (22%) | 67 (17%) | 52 (13%) | 248 (64%) |
| jc-opp-1e5408d-p3 | objective | 449 | 71 (16%) | 50 (11%) | 64 (14%) | 314 (70%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0110, L0126, L2433, L2630 |
| Charmed Shield | Opponent | L0126, L0226, L0327, L0725, L1327, L2327 |
| Clockwork Compass | Mine | L1216, L1232 |
| Elixir of Power | Mine | L1122, L1932 |
| Elixir of Power | Opponent | L0311, L1519 |
| Fistful of Laurels | Mine | L1831 |
| Horn of the Wild Hunt | Opponent | L0533, L1633, L2033, L2433, L3133 |
| Invocation of Nehek | Mine | L2433 |
| Invocation of Nehek | Opponent | L0327, L0725, L1327, L2327 |
| Opal Amulet | Mine | L1422 |
| Periapt of Soul Exchange | Mine | L2033 |
| Periapt of Soul Exchange | Opponent | L0620 |
| Ring of Doom | Mine | L0210, L0226, L1122, L1216, L1232, L1519, L1535, L3133 |
| Ring of Doom | Opponent | L0311, L0533, L0815, L0831, L1633, L1731, L1831, L2033, L2433, L3133 |
| Ring of Jet | Mine | L1013, L1030, L1122, L1216, L1232 |
| Ring of Jet | Opponent | L0110, L0210, L0311 |
| Standard of the Fell Warrior | Mine | L1327 |
| Standard of the Fell Warrior | Opponent | L0413, L1013 |
| Twice-Blessed Armour | Mine | L0709, L0725, L1013, L1030 |
| Twice-Blessed Armour | Opponent | L0110, L0210 |
| Witch Hunter's Ward | Mine | L0709, L0725, L0815, L0831 |

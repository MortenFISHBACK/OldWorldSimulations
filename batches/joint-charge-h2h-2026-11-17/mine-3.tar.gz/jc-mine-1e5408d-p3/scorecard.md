# Doctrine scorecard: jc-mine-1e5408d-p3

### Scorecard: jc-mine-1e5408d-p3

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0110 | 2 | 1 | Mine | - | - | 3 | 3 | 2 | 1 | 0 | 0 | 322 |
| L0110 | 2 | 1 | Opponent | - | - | 2 | 5 | 1 | 0 | 0 | 0 | 330 |
| L0126 | 6 | 1 | Mine | no | 8 | - | 0 | 1 | 0 | 0 | 0 | 317 |
| L0126 | 6 | 1 | Opponent | no | 17 | 2 | 2 | 0 | 0 | 0 | 0 | 0 |
| L0210 | 6 | 1 | Mine | no | 2 | 2 | 0 | 4 | 0 | 0 | 0 | 0 |
| L0210 | 6 | 1 | Opponent | no | 10 | 2 | 1 | 0 | 0 | 0 | 0 | 501 |
| L0226 | 4 | 1 | Mine | no | 7 | 3 | 3 | 2 | 1 | 0 | 0 | 442 |
| L0226 | 4 | 1 | Opponent | no | 2 | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L0311 | 5 | 1 | Mine | no | - | 3 | 0 | 1 | 0 | 0 | 0 | 590 |
| L0311 | 5 | 1 | Opponent | yes | - | 3 | 1 | 1 | 0 | 0 | 0 | 427 |
| L0327 | 3 | 1 | Mine | yes | 2 | 3 | 4 | 0 | 0 | 0 | 0 | 685 |
| L0327 | 3 | 1 | Opponent | no | 4 | 2 | 4 | 3 | 0 | 0 | 0 | 0 |
| L0413 | 5 | 1 | Mine | yes | - | 2 | 5 | 1 | 0 | 0 | 0 | 0 |
| L0413 | 5 | 1 | Opponent | no | - | 3 | 2 | 1 | 1 | 0 | 0 | 317 |
| L0429 | 3 | 1 | Mine | yes | 6 | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| L0429 | 3 | 1 | Opponent | no | 0 | 2 | 6 | 1 | 1 | 0 | 0 | 255 |
| L0516 | 6 | 1 | Mine | no | 2 | 4 | 1 | 1 | 0 | 0 | 0 | 666 |
| L0516 | 6 | 1 | Opponent | no | 5 | 2 | 3 | 1 | 1 | 0 | 0 | 200 |
| L0533 | 5 | 1 | Mine | no | - | - | 0 | 1 | 0 | 0 | 0 | 1193 |
| L0533 | 5 | 1 | Opponent | yes | - | 2 | 2 | 5 | 0 | 0 | 0 | 0 |
| L0620 | 2 | 1 | Mine | - | - | 4 | 4 | 0 | 0 | 0 | 0 | 798 |
| L0620 | 2 | 1 | Opponent | - | - | 4 | 1 | 2 | 0 | 0 | 0 | 210 |
| L0709 | 1 | 1 | Mine | yes | 5 | 3 | 1 | 0 | 0 | 0 | 0 | 420 |
| L0709 | 1 | 1 | Opponent | no | 0 | - | 0 | 0 | 0 | 0 | 0 | 664 |
| L0725 | 5 | 1 | Mine | yes | - | 6 | 1 | 3 | 0 | 0 | 0 | 420 |
| L0725 | 5 | 1 | Opponent | yes | - | 2 | 5 | 3 | 0 | 0 | 0 | 0 |
| L0815 | 5 | 1 | Mine | no | - | 6 | 1 | 1 | 0 | 0 | 0 | 515 |
| L0815 | 5 | 1 | Opponent | no | - | 2 | 2 | 2 | 0 | 0 | 0 | 115 |
| L0831 | 3 | 1 | Mine | no | 2 | 4 | 2 | 1 | 0 | 0 | 0 | 605 |
| L0831 | 3 | 1 | Opponent | no | 10 | 2 | 2 | 3 | 2 | 0 | 0 | 340 |
| L0922 | 4 | 1 | Mine | no | 0 | 5 | 1 | 0 | 0 | 0 | 0 | 841 |
| L0922 | 4 | 1 | Opponent | no | 0 | 2 | 5 | 2 | 1 | 0 | 0 | 55 |
| L1013 | 5 | 1 | Mine | no | - | 2 | 3 | 0 | 1 | 0 | 0 | 330 |
| L1013 | 5 | 1 | Opponent | no | - | 6 | 2 | 2 | 0 | 0 | 0 | 387 |
| L1030 | 4 | 1 | Mine | no | 0 | 2 | 3 | 0 | 0 | 0 | 0 | 330 |
| L1030 | 4 | 1 | Opponent | no | 1 | 3 | 3 | 1 | 1 | 0 | 0 | 0 |
| L1122 | 6 | 1 | Mine | no | 2 | 3 | 3 | 0 | 1 | 0 | 0 | 330 |
| L1122 | 6 | 1 | Opponent | no | 1 | 2 | 4 | 2 | 1 | 0 | 0 | 144 |
| L1216 | 4 | 1 | Mine | no | 4 | 2 | 4 | 0 | 0 | 0 | 0 | 524 |
| L1216 | 4 | 1 | Opponent | no | 7 | 2 | 5 | 1 | 0 | 0 | 0 | 414 |
| L1232 | 2 | 1 | Mine | - | - | 2 | 4 | 0 | 0 | 0 | 0 | 498 |
| L1232 | 2 | 1 | Opponent | - | - | 3 | 2 | 3 | 1 | 0 | 0 | 340 |
| L1327 | 1 | 1 | Mine | no | 12 | 4 | 2 | 0 | 0 | 0 | 0 | 302 |
| L1327 | 1 | 1 | Opponent | no | 2 | 2 | 6 | 1 | 0 | 0 | 0 | 323 |
| L1422 | 6 | 1 | Mine | no | 6 | 2 | 2 | 0 | 0 | 0 | 0 | 0 |
| L1422 | 6 | 1 | Opponent | no | 1 | 2 | 5 | 0 | 0 | 0 | 0 | 72 |
| L1519 | 1 | 1 | Mine | no | 0 | 2 | 3 | 0 | 0 | 0 | 0 | 0 |
| L1519 | 1 | 1 | Opponent | no | 0 | 2 | 5 | 2 | 1 | 0 | 0 | 0 |
| L1535 | 5 | 1 | Mine | yes | - | 4 | 3 | 2 | 0 | 0 | 0 | 0 |
| L1535 | 5 | 1 | Opponent | yes | - | 2 | 2 | 3 | 0 | 0 | 0 | 414 |
| L1633 | 1 | 1 | Mine | no | 12 | 3 | 2 | 1 | 0 | 0 | 0 | 200 |
| L1633 | 1 | 1 | Opponent | no | 0 | 1 | 1 | 3 | 0 | 0 | 0 | 0 |
| L1731 | 3 | 1 | Mine | yes | 7 | 3 | 6 | 0 | 1 | 0 | 0 | 0 |
| L1731 | 3 | 1 | Opponent | no | 1 | 2 | 2 | 0 | 1 | 0 | 0 | 340 |
| L1831 | 1 | 1 | Mine | no | 0 | 4 | 4 | 0 | 1 | 0 | 0 | 0 |
| L1831 | 1 | 1 | Opponent | no | 9 | 2 | 5 | 0 | 2 | 0 | 0 | 170 |
| L1932 | 6 | 1 | Mine | no | 1 | 2 | 3 | 0 | 0 | 0 | 0 | 565 |
| L1932 | 6 | 1 | Opponent | no | 2 | 2 | 5 | 0 | 1 | 0 | 0 | 340 |
| L2033 | 5 | 1 | Mine | no | - | - | 0 | 7 | 1 | 0 | 0 | 420 |
| L2033 | 5 | 1 | Opponent | no | - | 3 | 1 | 4 | 0 | 0 | 0 | 0 |
| L2223 | 3 | 1 | Mine | no | 0 | 1 | 7 | 0 | 1 | 0 | 0 | 0 |
| L2223 | 3 | 1 | Opponent | no | 2 | 2 | 2 | 0 | 0 | 0 | 0 | 185 |
| L2327 | 5 | 1 | Mine | yes | - | 2 | 4 | 0 | 0 | 0 | 0 | 0 |
| L2327 | 5 | 1 | Opponent | no | - | 2 | 4 | 0 | 0 | 0 | 0 | 60 |
| L2433 | 3 | 1 | Mine | no | 4 | 3 | 4 | 1 | 0 | 0 | 0 | 0 |
| L2433 | 3 | 1 | Opponent | no | 0 | 1 | 5 | 1 | 2 | 0 | 0 | 641 |
| L2630 | 2 | 1 | Mine | - | - | 3 | 3 | 1 | 0 | 0 | 0 | 0 |
| L2630 | 2 | 1 | Opponent | - | - | 2 | 5 | 1 | 0 | 0 | 0 | 0 |
| L2832 | 6 | 1 | Mine | no | 3 | 2 | 3 | 0 | 2 | 0 | 0 | 0 |
| L2832 | 6 | 1 | Opponent | no | 3 | 2 | 4 | 1 | 1 | 0 | 0 | 170 |
| L3133 | 1 | 1 | Mine | no | 9 | 1 | 3 | 0 | 0 | 0 | 0 | 170 |
| L3133 | 1 | 1 | Opponent | no | 6 | 6 | 2 | 0 | 0 | 0 | 0 | 144 |
| **Average** | | | Mine | 25% | 4.1 | 2.9 | 2.6 | 0.9 | 0.3 | 0.0 | 0.0 | 319.0 |
| **Average** | | | Opponent | 12% | 3.6 | 2.4 | 3.2 | 1.4 | 0.5 | 0.0 | 0.0 | 209.9 |

### KPIs: jc-mine-1e5408d-p3

Rules off - Opponent only: SECOND CHARGER ADDS.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 26% (45 of 172) | 9% (15 of 172) | 17% (60 of 344) |
| Winner chose to follow up after the loser gave ground |  | 99% (77 of 78); on the table 99% | 100% (46 of 46); on the table 100% | 99% (123 of 124); on the table 99% |
| Winner chose to pursue after the loser fell back in good order |  | 67% (8 of 12); on the table 67% | 92% (12 of 13); on the table 92% | 80% (20 of 25); on the table 80% |
| Winner chose to pursue after the loser fled |  | 84% (21 of 25); on the table 84% | 71% (24 of 34); on the table 74% | 76% (45 of 59); on the table 78% |
| Winner chose to follow up or pursue (all three) |  | 92% (106 of 115); on the table 92% | 88% (82 of 93); on the table 89% | 90% (188 of 208); on the table 91% |
| Magic missiles tried each own turn | 50%+ | 27% (91 of 342) | 35% (68 of 192) | 30% (159 of 534) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 45% (91 of 202) | 47% (68 of 144) | 46% (159 of 346) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 50% (11 of 22) | 51% (26 of 51) | 51% (37 of 73) |
| Points that never fought | lower | 35% (24294 of 68801) | 34% (24542 of 71990) | 35% (48836 of 140791) |
|   infantry points that never fought | lower | 33% (4731 of 14174) | 50% (7082 of 14220) | 42% (11813 of 28394) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 54% (147 of 272) | 58% (164 of 285) | 56% (311 of 557) |
| Bound items with a magic missile used (at least once a game) |  | 96% (24 of 25); 1.7 uses a game | 83% (20 of 24); 2.1 uses a game | 90% (44 of 49); 1.9 uses a game |
| Bound items with another spell used |  | 36% (5 of 14); 0.2 uses a game | 33% (2 of 6); 0.1 uses a game | 35% (7 of 20); 0.1 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 50% (10 of 20); 0.3 uses a game | 43% (6 of 14); 0.2 uses a game | 47% (16 of 34); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 49% (29140 of 59391) | 51% (32922 of 64043) | 50% (62062 of 123434) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.3 (19%) | 1.0 (30%) | 2.4 (23%) |
| MARCHED: its unit marched | 1.4 (20%) | 0.8 (23%) | 2.2 (21%) |
| CHARGED: its unit charged | 0.1 (1%) | 0.1 (3%) | 0.2 (2%) |
| IN COMBAT: engaged in combat | 1.6 (23%) | 0.9 (27%) | 2.5 (24%) |
| REAR RANK: in a rear rank | 0.1 (2%) | 0.2 (5%) | 0.3 (3%) |
| FLEEING: fleeing | 0.2 (2%) | 0.2 (6%) | 0.4 (3%) |
| GONE: slain | 1.9 (27%) | 0.2 (6%) | 2.1 (20%) |
| OFF THE TABLE: off the table or not arrived | 0.3 (4%) | 0.0 (0%) | 0.3 (3%) |
| STUPIDITY: Stupidity | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 5.0 | 1.1 | 1.6 | 4.4 | 0.9 | 1.8 |
| not cast | 3.8 | 1.5 | 4.6 | 10.4 | 2.4 | 18.9 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) | 0.0 (0%) | 1.5 (8%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (1%) | 0.8 (49%) | 0.2 (5%) | 2.4 (23%) | 0.3 (14%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.2 (21%) | 0.4 (19%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (2%) | 0.1 (2%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.2 (4%) | 0.1 (9%) | 0.9 (20%) | 2.5 (24%) | 0.4 (16%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.2 (4%) | 0.0 (0%) | 0.3 (7%) | 0.3 (3%) | 0.1 (6%) | 0.0 (0%) |
| FLEEING: fleeing | 0.1 (1%) | 0.1 (7%) | 0.1 (2%) | 0.4 (3%) | 0.1 (2%) | 0.7 (4%) |
| GONE: slain | 1.1 (28%) | 0.4 (24%) | 1.4 (30%) | 2.1 (20%) | 0.3 (12%) | 3.2 (17%) |
| OFF THE TABLE: off the table or not arrived | 0.1 (2%) | 0.0 (0%) | 0.3 (6%) | 0.3 (3%) | 0.1 (5%) | 0.4 (2%) |
| STUPIDITY: Stupidity | 0.1 (2%) | 0.0 (0%) | 0.1 (2%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (4%) | 0.1 (4%) | 0.0 (0%) | 0.1 (1%) | 0.6 (24%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.0 (53%) | 0.1 (7%) | 1.2 (27%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 13.1 (69%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.0 a game | 0.6 a game | 0.8 a game |
| stood (cast and not dispelled) | 53% (16 of 30) | 71% (12 of 17) | 60% (28 of 47) |
| the unit moved after it | 62% (10 of 16) | 75% (9 of 12) | 68% (19 of 28) |
| it charged on its next turn | 0% (0 of 16) | 8% (1 of 12) | 4% (1 of 28) |
| the enemy charged it first | 25% (4 of 16) | 33% (4 of 12) | 29% (8 of 28) |
| it fought by the end of its next turn | 6% (1 of 16) | 0% (0 of 12) | 4% (1 of 28) |
| it moved out of a charge the enemy had planned (not charged first) | 12% (2 of 16) | 17% (2 of 12) | 14% (4 of 28) |
| none of these (no charge, no fight, no charge escaped) | 62% (10 of 16) | 42% (5 of 12) | 54% (15 of 28) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 65% (504 of 776) | 61% (368 of 607) | 63% (872 of 1383) |
|   cavalry | 53% (36 of 68) | 66% (69 of 104) | 61% (105 of 172) |
|   character | 62% (64 of 104) | 26% (33 of 125) | 42% (97 of 229) |
|   chariot | 43% (44 of 102) | 70% (21 of 30) | 49% (65 of 132) |
|   infantry | 52% (106 of 202) | 66% (169 of 255) | 60% (275 of 457) |
|   monster | 50% (19 of 38) | 100% (6 of 6) | 57% (25 of 44) |
|   war machine | 90% (235 of 262) | 80% (70 of 87) | 87% (305 of 349) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.2 (30%) | 1.3 (19%) | 3.5 (25%) |
| CHARGED: it charged | 1.1 (15%) | 1.5 (23%) | 2.7 (19%) |
| FLEEING: it fled or was fleeing | 0.1 (1%) | 0.1 (1%) | 0.2 (1%) |
| IN COMBAT: it fought this turn or the last | 0.8 (11%) | 0.5 (8%) | 1.4 (10%) |
| MOVED: a war machine that moved | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| NO TARGET IN RANGE | 0.9 (12%) | 0.7 (10%) | 1.6 (12%) |
| ONLY IN COMBAT: the only targets were in combat | 0.5 (7%) | 0.5 (8%) | 1.0 (7%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.4 (18%) | 1.5 (22%) | 2.8 (20%) |
| SHELTERED: the target was sheltered | 0.1 (1%) | 0.1 (2%) | 0.2 (1%) |
| STUPIDITY | 0.0 (0%) | 0.1 (1%) | 0.1 (1%) |
| OTHER BAR | 0.3 (4%) | 0.3 (5%) | 0.6 (5%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 4.5 | 1.0 | 81% | 5.8 pts | 26 pts |
| character | 3.2 | 1.0 | 77% | 8.1 pts | 26 pts |
| chariot | 1.8 | 0.6 | 75% | 9.6 pts | 17 pts |
| infantry | 12.3 | 4.1 | 77% | 8.1 pts | 100 pts |
| monster | 1.0 | 0.4 | 74% | 12.7 pts | 12 pts |
| war machine | 8.8 | 6.9 | 63% | 22.2 pts | 195 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.2 | 5.8 | 5.0 |
| Charges that made contact a game | 3.3 | 4.2 | 3.8 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.81 declared, 0.69 contact (26 units) | 0.95 declared, 0.85 contact (20 units) | 0.87 declared, 0.76 contact (46 units) |
|   per unit a game, units carrying another wizard (or one alone) | 1.25 declared, 1.25 contact (4 units) | 0.88 declared, 0.38 contact (8 units) | 1.00 declared, 0.67 contact (12 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.57 declared, 0.44 contact (221 units) | 0.69 declared, 0.49 contact (267 units) | 0.64 declared, 0.47 contact (488 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 49% (38 of 77) | 40% (6 of 15) | 50% (5 of 10) | 48% (49 of 102) |
| Character in a unit | 66% (23 of 35) | 54% (7 of 13) | 67% (4 of 6) | 63% (34 of 54) |
| Character on its own | 74% (31 of 42) | 51% (22 of 43) | 28% (19 of 69) | 47% (72 of 154) |
| Chariot | 91% (10 of 11) | 67% (8 of 12) | - | 78% (18 of 23) |
| Infantry | 64% (45 of 70) | 52% (22 of 42) | 20% (1 of 5) | 58% (68 of 117) |
| Monster | 59% (20 of 34) | 57% (4 of 7) | - | 59% (24 of 41) |
| Monstrous | 80% (8 of 10) | 45% (5 of 11) | - | 62% (13 of 21) |
| War Machines | 72% (31 of 43) | 100% (2 of 2) | - | 73% (33 of 45) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 100% (18 of 18); on the table 100% | 21% (20 of 96) | 33% | 73% (16 of 22) | 83% (5 of 6); 3.2 uses a game | 50% (1 of 2); 0.5 uses a game | 67% (4 of 6); 1.0 uses a game |
| Chaos Dwarfs | 4 | 94% (16 of 17); on the table 94% | 36% (13 of 36) | 42% | 56% (18 of 32) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
| Dwarfen Mountain Holds | 3 | 33% (1 of 3); on the table 33% | - | 59% | 58% (14 of 24) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 6 | 89% (8 of 9); on the table 89% | 33% (10 of 30) | 42% | 59% (35 of 59) | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game | 25% (1 of 4); 0.2 uses a game |
| Grand Cathay | 8 | 82% (14 of 17); on the table 82% | 32% (61 of 192) | 45% | 58% (43 of 74) | 89% (16 of 18); 6.0 uses a game | 25% (1 of 4); 0.1 uses a game | 38% (3 of 8); 0.4 uses a game |
| High Elf Realms | 7 | 100% (24 of 24); on the table 100% | 26% (11 of 42) | 36% | 57% (31 of 54) | 89% (8 of 9); 3.6 uses a game | 42% (5 of 12); 1.0 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 3 | 100% (1 of 1); on the table 100% | - | 48% | 50% (9 of 18) | 0.0 uses a game | 0.0 uses a game | 100% (3 of 3); 1.0 uses a game |
| Lizardmen | 1 | 100% (4 of 4); on the table 100% | 50% (3 of 6) | 20% | 57% (4 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 1 | 75% (3 of 4); on the table 75% | 0% (0 of 6) | 15% | 43% (3 of 7) | 100% (1 of 1); 1.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 2 | 100% (4 of 4); on the table 100% | 33% (4 of 12) | 9% | 31% (5 of 16) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |
| Skaven | 2 | 86% (6 of 7); on the table 86% | 8% (1 of 12) | 58% | 64% (9 of 14) | 0.0 uses a game | 0.0 uses a game | 100% (2 of 2); 1.0 uses a game |
| Tomb Kings of Khemri | 6 | 86% (19 of 22); on the table 86% | 17% (1 of 6) | 26% | 35% (9 of 26) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 8 | 96% (25 of 26); on the table 96% | 35% (19 of 54) | 18% | 37% (17 of 46) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 11 | 85% (41 of 48); on the table 88% | 40% (12 of 30) | 25% | 59% (57 of 96) | 100% (4 of 4); 1.1 uses a game | 0.0 uses a game | 100% (2 of 2); 0.2 uses a game |
| Wood Elf Realms | 6 | 100% (4 of 4); on the table 100% | 33% (4 of 12) | 45% | 66% (41 of 62) | 91% (10 of 11); 5.8 uses a game | 0.0 uses a game | 0% (0 of 5); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (jc-mine-1e5408d-p3, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 35% (32) | 53% (44) | 44% (76) |
| ...free all their last turn and able to turn (per game) | 0.53 | 0.75 | 1.28 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.11 | 0.19 | 0.31 |
| ...with the charger already in that arc before they moved (per game) | 0.44 | 0.50 | 0.94 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 1.75 | 1.58 | 3.33 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.86 | 0.64 | 1.50 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 5.81 | 4.78 | 10.58 |

### Quality by phase: jc-mine-1e5408d-p3

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.2 | 3.6 |
| Strategy | Charge objectives carried out (made contact) | 56% (68 of 122) | 50% (81 of 162) |
| Strategy | Shoot objectives carried out (shot that target) | 47% (177 of 375) | 49% (118 of 241) |
| Strategy | Close-in objectives charged next turn | 15% (30 of 199) | 14% (36 of 259) |
| Strategy | Support requests answered (helper made contact too) | 52% (11 of 21) | 58% (14 of 24) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (4 of 4) | 100% (1 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | 57% (4 of 7) | 60% (3 of 5) |
| Strategy | Joined characters whose unit fought | 51% (20 of 39) | 50% (20 of 40) |
| Strategy | Lone characters that fought | 72% (69 of 96) | 74% (70 of 94) |
| Movement | Charges halted short of contact | 0.2 | 0.2 |
| Movement | Idle units | 0.9 | 1.4 |
| Movement | Points that never moved of their own | 319.0 | 209.9 |
| Movement | Fights charged into per game | 3.1 | 3.4 |
| Movement | Charges with odds: long shots (under 50%) | 8 of 95, net -56 | 33 of 109, net +59 |
| Movement | Charges with odds: sweet spot (55-75%) | 16 of 95, net +43 | 16 of 109, net +72 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 16 of 95, net +148 | 10 of 109, net +88 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 28 of 95, net +120 | 28 of 109, net +103 |
| Shooting | Shots by shooting units (incl. breath weapons) | 7.9 | 10.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 42% (120 of 283) | 45% (164 of 361) |
| Shooting | Points destroyed by shooting units | 38.6 | 17.6 |
| Shooting | War machine shots | 6.5 | 2.2 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 54% (126 of 235) | 32% (26 of 80) |
| Shooting | Points destroyed by war machines | 76.8 | 8.7 |
| Magic | Magic missiles cast | 1.7 | 1.2 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 31% (19 of 62) | 27% (12 of 45) |
| Magic | Wounds caused by magic missiles | 2.8 | 2.6 |
| Magic | Wounds caused by other spells | 1.2 | 1.3 |
| Magic | Points destroyed by magic (all spells) | 68.4 | 98.4 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.5 / 0.2 / 0.6 / 0.1 | 2.0 / 0.2 / 0.5 / 0.4 |
| Combat | Points destroyed in combat | 407.9 | 365.4 |
| Combat | Points run down | 70.0 | 122.4 |
| Combat | Net points per charged fight, damage counted | +86 | +80 |
| Combat | Net per 100 charger points, damage counted | +30.4 | +26.8 |
| Combat | First round won (charged fights) | 79% | 65% |
| Combat | Net points per charged fight | +79 | +82 |
| Combat | Net points per supported fight / lone fight | +165 / +69 | +102 / +78 |
| Combat | Charged fights on a top-3 enemy unit | 38 of 112 | 58 of 124 |
| Game | Points lost | 701.4 | 725.6 |
| Game | VP from objectives | 533.6 | 575.6 |
| Game | Lone holders (player turns) | 4.1 | 3.6 |

- Mine won / drew / lost: 14 / 9 / 13 of 36 ended games (of 36); mean margin (Mine - Opponent) -17 VP
- The side that went first won 14 of 27 games with a winner
- Points traded per game (both sides' losses): 1427
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: jc-mine-1e5408d-p3

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.6 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 0.0 |
| ADVANCE WORTH | 5.2 | -177.7 | 190.6 | 77.3 | 3.5 | -112.8 | 116.1 | 63.8 |
| ALREADY CARRIED | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARRIVAL HUNT | - | - | - | - | 0.1 | +0.2 | 0.0 | 2.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.8 | +0.0 | 0.0 | 45.8 | 0.1 | +0.0 | 0.0 | 4.6 |
| BACKUP TARGETS | 0.7 | +3.2 | 0.0 | 8.6 | 0.7 | +4.8 | 0.0 | 13.8 |
| BEST FACING | 0.3 | +22.2 | 0.0 | 24.4 | 0.4 | +15.7 | 0.0 | 16.6 |
| BEST FIRST | 1.5 | +60.9 | 37.3 | 40.6 | 1.1 | +83.6 | 32.0 | 26.3 |
| BEST OVERALL | 0.5 | +33.5 | 0.0 | 0.0 | 0.3 | +8.2 | 0.0 | 5.2 |
| BEST PREY | 0.5 | +29.3 | 11.0 | 0.0 | 0.6 | +26.4 | 20.5 | 14.8 |
| BEST PRIZE | 0.1 | -8.2 | 8.2 | 10.5 | 0.1 | -2.2 | 0.0 | 0.0 |
| BIG CHARACTER SAFETY | 0.2 | -1.1 | 0.0 | 10.5 | 0.2 | -1.3 | 0.0 | 0.0 |
| BLOCKED CHARGE SKIPPED | 0.1 | +0.0 | 4.7 | 0.0 | 0.0 | +0.0 | 10.9 | 0.0 |
| BLOCKED WHEEL | 0.4 | +23.4 | 0.0 | 0.0 | 0.2 | +4.3 | 0.0 | 1.4 |
| BLOWS WHERE AIMED | 0.2 | -8.6 | 43.7 | 5.4 | 0.4 | -51.8 | 23.6 | 5.4 |
| BOUND ASSAILMENT | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |
| CANNON PLAN MISSED | 0.5 | +0.0 | 43.2 | 7.2 | 0.2 | +0.0 | 19.8 | 0.0 |
| CANNON PLANNED TARGET | 5.7 | +129.6 | 384.7 | 109.7 | 1.1 | +59.1 | 50.9 | 38.9 |
| CANNON SIGHT KEPT | 1.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT COUNTER | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CARRIES OUT SET-UP | 0.1 | -0.3 | 27.6 | 6.0 | 0.1 | +0.0 | 13.1 | 5.5 |
| CAST JOB | 0.8 | +17.7 | 43.1 | 12.6 | 0.9 | +22.0 | 37.2 | 15.0 |
| CASTER AWAY FROM SCREEN | 0.2 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.2 | +28.7 | 9.2 | 0.0 | 0.1 | +1.0 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 0.5 | +0.0 | 0.0 | 31.4 | 0.4 | +0.0 | 0.0 | 24.1 |
| CASTS FROM BEHIND | 0.0 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | 0.7 | +36.6 | 0.0 | 15.8 | 1.4 | +65.6 | 0.0 | 27.2 |
| CHAFF PASSED | 0.2 | -0.0 | 0.0 | 1.8 | 0.3 | -0.6 | 16.2 | 5.7 |
| CHAMPION TAKES THE CHALLENGE | 0.1 | +0.0 | 23.9 | 0.0 | - | - | - | - |
| CHARGE NOW FIRST | 2.1 | +0.0 | 183.3 | 64.0 | 2.8 | +0.0 | 283.8 | 81.1 |
| CHARGE NOW WEIGHED | 0.5 | -59.7 | 23.1 | 10.5 | 0.5 | -49.5 | 4.1 | 1.9 |
| CHARGER SLAIN LOST | 0.4 | -11.1 | 43.2 | 6.4 | 0.7 | -28.0 | 63.6 | 8.5 |
| CHARIOT NO STATIC JOB | 0.0 | +0.0 | 0.0 | 2.4 | - | - | - | - |
| CHARIOT WIZARD CAREFUL | 0.0 | -2.1 | 0.0 | 11.0 | 0.1 | -0.0 | 12.1 | 11.1 |
| CHEAP HELPER | - | - | - | - | 0.1 | +0.0 | 7.8 | 3.0 |
| COMBAT PIVOT | 0.8 | +0.0 | 43.2 | 22.1 | 0.6 | +0.0 | 28.9 | 32.5 |
| CONVEYANCE SEARCH | 0.5 | +65.3 | 0.0 | 20.4 | 0.3 | +26.8 | 15.5 | 18.7 |
| COVER ONCE | 7.6 | -516.5 | 0.0 | 149.3 | 5.6 | -372.0 | 0.0 | 153.3 |
| DEFENSIVE ARMY | 0.1 | +0.0 | 10.8 | 8.2 | 0.1 | +0.0 | 6.7 | 0.0 |
| DEFENSIVE FLOOR | 0.0 | +1.7 | 3.2 | 0.0 | 0.0 | +0.9 | 0.0 | 0.0 |
| EDGE GIVE GROUND | 0.1 | +0.9 | 7.3 | 16.9 | 0.3 | +6.6 | 23.5 | 1.2 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 1.8 | +120.3 | 0.0 | 69.4 | 1.6 | +98.4 | 0.0 | 41.2 |
| FALLBACK BY WORTH | 4.4 | +55.2 | 0.0 | 34.0 | 4.8 | +30.5 | 0.0 | 32.9 |
| FIGHT LIFT | 0.0 | +1.1 | 0.0 | 0.0 | 0.1 | +3.5 | 0.0 | 0.0 |
| FIRE AND FLEE | 0.0 | +0.4 | 2.9 | 2.2 | - | - | - | - |
| FLANK NOT WEIGHED | 5.3 | +0.0 | 0.0 | 109.9 | 4.8 | +0.0 | 0.0 | 121.2 |
| FOLLOW UP WEIGHED | 1.2 | +207.0 | 0.0 | 41.4 | 1.1 | +155.9 | 0.0 | 29.4 |
| FRIEND IN REACH | 3.6 | +57.3 | 327.6 | 92.1 | 4.8 | +94.8 | 393.0 | 120.3 |
| FRIENDS SHOTS CHECKED | 0.3 | +23.5 | 0.0 | 23.4 | 0.1 | +12.6 | 0.0 | 7.2 |
| GIVES UP | 0.1 | -0.3 | 2.1 | 3.2 | 0.1 | -0.6 | 5.7 | 0.0 |
| GIVES UP ITS SCREEN | - | - | - | - | 0.1 | -0.2 | 6.3 | 0.0 |
| GROUND FLIERS | 0.0 | +2.9 | 0.0 | 0.0 | - | - | - | - |
| HELPER ALREADY ASKED | 0.0 | +0.0 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| HELPER UNSEEN | 0.5 | +0.0 | 54.3 | 26.9 | 0.3 | +0.0 | 27.9 | 14.3 |
| HILL BY ITS CHANCE | 0.2 | -13.8 | 0.0 | 1.8 | 0.5 | -62.1 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 8.6 | -149.4 | 429.1 | 152.4 | 8.9 | -229.3 | 485.8 | 180.3 |
| HORN WORTH | - | - | - | - | 0.1 | +0.8 | 0.0 | 0.0 |
| HUNT ADVANCE | 0.1 | +6.6 | 12.6 | 0.0 | 0.2 | +5.4 | 3.5 | 2.9 |
| HUNT DROPPED | 0.0 | +0.0 | 4.6 | 0.0 | 0.1 | +0.0 | 6.9 | 2.9 |
| HUNT IN PAIRS | 0.3 | +16.7 | 0.0 | 10.5 | 0.7 | +27.8 | 0.0 | 18.2 |
| HUNT KEPT | 0.2 | +8.1 | 12.6 | 5.6 | 0.1 | +1.8 | 0.0 | 3.4 |
| HUNT RESULT | 0.1 | +13.5 | 4.6 | 3.1 | 0.2 | +9.3 | 6.9 | 6.1 |
| HUNT THE GUNS | 0.1 | +45.6 | 8.1 | 2.5 | 0.2 | +63.1 | 5.4 | 0.5 |
| IDLE COST | 15.4 | -263.5 | 0.0 | 130.9 | 18.1 | -319.9 | 0.0 | 225.1 |
| INVITES THE FIGHT | 1.1 | +8.2 | 49.2 | 16.4 | 0.5 | +3.8 | 33.2 | 22.5 |
| JOINT CHARGE PLAN | 0.1 | +3.8 | 0.0 | 7.6 | 0.2 | +9.6 | 0.0 | 0.0 |
| JOINT KNOWS CHALLENGE | 0.0 | -0.1 | 3.5 | 0.0 | 0.1 | -3.5 | 31.0 | 0.0 |
| KEEP FALLS | 0.1 | +2.7 | 0.0 | 0.0 | 0.0 | +0.1 | 0.0 | 0.0 |
| KEEPS ITS PREY | 0.1 | +0.3 | 0.0 | 1.4 | 0.1 | +0.1 | 0.0 | 0.0 |
| KEEPS ITS TARGET | 1.8 | +55.0 | 140.8 | 64.5 | 2.2 | +66.7 | 185.8 | 36.9 |
| KEEPS SCOUTS OR AMBUSH | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KILLS COUNT | 1.6 | +82.0 | 112.6 | 27.6 | 1.8 | +88.2 | 140.9 | 52.1 |
| KILLS COUNT NEXT TURN | 5.4 | +202.7 | 225.4 | 40.8 | 7.5 | +262.7 | 264.8 | 142.8 |
| LONE CHARACTER SAFE SPOT | 0.2 | +12.2 | 7.5 | 3.2 | 0.3 | +12.4 | 6.5 | 4.6 |
| LONE WIZARD HOLDS BACK | 0.1 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 10.3 | 5.3 |
| LONE WIZARD KEPT IN | 0.6 | +37.3 | 0.0 | 0.0 | 0.4 | +25.4 | 0.0 | 0.0 |
| LONG SHOT | 0.2 | -0.4 | 17.3 | 3.9 | 0.3 | +1.9 | 30.2 | 4.8 |
| LOST CHARGE | 3.1 | -51.4 | 81.8 | 93.3 | 2.3 | -33.7 | 73.3 | 99.6 |
| LURE BY WHAT IT DRAWS | 0.1 | -12.9 | 0.0 | 4.9 | 0.1 | -10.2 | 0.0 | 3.2 |
| MAKE SURE TOGETHER | 1.0 | +130.8 | 31.9 | 28.8 | 1.1 | +102.8 | 17.4 | 19.8 |
| MANOEUVRE | 0.3 | +3.6 | 0.0 | 3.3 | 0.2 | +6.4 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.2 | +0.7 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | 0.6 | +22.5 | 0.0 | 18.2 | 0.6 | +20.1 | 0.0 | 18.8 |
| MARCH ODDS | 0.3 | +12.4 | 6.2 | 0.0 | 0.2 | +9.2 | 5.2 | 0.0 |
| MARCH OVER CASTS | 0.8 | +53.8 | 0.0 | 34.6 | 0.4 | +12.0 | 0.0 | 3.0 |
| MAX FOR POSITIONING | 6.3 | +82.6 | 0.0 | 174.1 | 6.8 | +96.0 | 0.0 | 141.2 |
| MISSILES IN THE MOVE | 3.6 | +104.4 | 0.0 | 105.7 | 4.0 | +74.8 | 0.0 | 86.8 |
| MISSILES NEXT TURN | 4.9 | +74.7 | 0.0 | 156.9 | 5.0 | +50.6 | 0.0 | 83.6 |
| MODEL FACING | 0.1 | +38.7 | 0.0 | 0.0 | - | - | - | - |
| MONSTER WIZARD ROAMS | 0.2 | +0.0 | 12.6 | 10.5 | 0.2 | +0.0 | 6.4 | 0.0 |
| MOVE AND CAST | 0.4 | +26.8 | 0.0 | 5.6 | 0.4 | +13.3 | 0.0 | 6.4 |
| MOVE SPELL IN RANGE | 0.3 | +12.1 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.5 | -20.2 | 5.1 | 30.6 | 0.1 | -1.8 | 0.0 | 14.1 |
| MOVE SPELL SPOT | 0.2 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 11.1 |
| MOVE TO CHARGE | 4.1 | +406.0 | 141.4 | 90.8 | 5.1 | +412.9 | 157.5 | 105.0 |
| MOVES UNITS SPELL | 0.1 | +3.6 | 0.0 | 0.0 | 0.1 | +0.3 | 0.0 | 0.0 |
| NOT NEEDED | - | - | - | - | 0.3 | -11.6 | 41.2 | 12.9 |
| NOT TURNED | 5.8 | +90.9 | 0.0 | 65.1 | 4.8 | +49.6 | 0.0 | 102.2 |
| NOT WORTH A CAST | 0.5 | -0.3 | 0.0 | 11.0 | 0.9 | -1.0 | 0.0 | 14.1 |
| OFF BEST | 15.7 | -724.6 | 0.0 | 315.7 | 15.4 | -754.4 | 0.0 | 262.8 |
| ONE FIGHT FORMULA | 8.7 | -154.7 | 34.2 | 141.6 | 7.8 | -181.5 | 21.1 | 173.5 |
| ONE OBJECTIVE FORMULA | 2.1 | -65.9 | 0.0 | 36.8 | 1.5 | -91.5 | 0.0 | 13.1 |
| OPENS A LANE | 0.0 | +0.0 | 0.0 | 0.0 | 0.2 | +0.5 | 14.3 | 0.0 |
| OPENS UP | 0.1 | +15.7 | 4.0 | 10.5 | 0.1 | +5.0 | 2.4 | 0.0 |
| OVERRUNS AWAY | 0.4 | +14.9 | 55.1 | 36.5 | 0.5 | +6.1 | 54.3 | 25.2 |
| PAIR SET-UP | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 15.1 | 0.0 |
| PATHS CROSS | 1.9 | +121.8 | 0.0 | 12.8 | 2.3 | +165.6 | 0.0 | 13.2 |
| PERIAPT WORTH | 0.0 | +2.8 | 0.0 | 0.0 | 0.0 | +2.8 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.1 | -0.8 | 0.0 | 0.0 | 0.1 | -0.6 | 0.0 | 0.0 |
| PLAN RESULT | 36.2 | +1261.6 | 1223.3 | 893.7 | 36.6 | +1137.8 | 1373.9 | 992.7 |
| PURSUES BIG PREY | 0.1 | -1.6 | 0.0 | 0.0 | 0.0 | -0.5 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE | - | - | - | - | 0.1 | +11.5 | 0.0 | 1.5 |
| RAIDS THE BAGGAGE NEXT TURN | 0.1 | +4.9 | 0.0 | 0.0 | 0.1 | +3.5 | 0.0 | 0.0 |
| RANDOM MOVE BY FIGURES | 0.6 | +6.9 | 0.0 | 4.7 | 1.4 | +22.2 | 0.0 | 51.9 |
| RANDOM MOVER NO PROMISE | 0.2 | -18.9 | 13.1 | 0.0 | 0.3 | -20.8 | 30.3 | 9.4 |
| REDIRECT BY WHAT IT STOPS | 0.5 | -9.0 | 0.0 | 11.9 | 1.1 | -33.9 | 0.0 | 21.3 |
| REDIRECT COUNTER | 1.8 | +143.0 | 0.0 | 32.5 | 3.1 | +242.2 | 0.0 | 42.0 |
| REDIRECT WEIGHED | 0.2 | +1.7 | 8.4 | 0.0 | 0.5 | +1.2 | 3.5 | 3.5 |
| REFUSING RETIRES | 0.1 | +0.0 | 0.0 | 8.9 | 0.4 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | 0.2 | +11.8 | 0.0 | 1.1 | 1.1 | +50.1 | 0.0 | 21.3 |
| RESTRAINS TO SHOOT | 0.0 | +0.6 | 0.0 | 0.0 | 0.1 | +1.7 | 0.0 | 0.0 |
| RISK BY ARC | 2.3 | +83.1 | 233.3 | 82.7 | 2.7 | +78.2 | 219.9 | 85.0 |
| RISK ONCE | 4.3 | +109.1 | 66.3 | 110.6 | 4.3 | +219.2 | 54.0 | 176.0 |
| SAFE SURE CHARGE | 0.0 | -2.4 | 0.0 | 0.0 | - | - | - | - |
| SAFER THAN THE JOB | 0.9 | +75.6 | 0.0 | 19.2 | 0.6 | +38.6 | 0.0 | 31.7 |
| SCOUT SPOT | 0.4 | +0.6 | 0.0 | 0.0 | 0.3 | +1.0 | 0.0 | 0.0 |
| SCOUT WAITS | 0.4 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.2 | -3.7 | 0.0 | 0.0 | 0.4 | -28.8 | 0.0 | 2.7 |
| SEARCH SPOT | 2.2 | +96.5 | 0.0 | 27.6 | 2.0 | +115.2 | 0.0 | 51.3 |
| SECOND CHARGER ADDS | 0.2 | -10.6 | 19.9 | 7.6 | - | - | - | - |
| SECOND HUNTER | 0.0 | -0.9 | 4.6 | 0.0 | - | - | - | - |
| SELF MOVE SPELL | 0.3 | +43.5 | 0.0 | 32.9 | 0.1 | +54.8 | 0.0 | 0.0 |
| SET UP TOGETHER | 1.6 | +172.9 | 39.8 | 36.4 | 2.1 | +182.2 | 29.6 | 43.2 |
| SET-UP ANY TARGET | 0.3 | +50.0 | 0.0 | 10.5 | 0.2 | +20.1 | 15.5 | 18.7 |
| SET-UP MISSED | 0.1 | +11.3 | 10.5 | 10.5 | - | - | - | - |
| SHOOTERS IN TWO RANKS | 0.4 | +0.7 | 0.0 | 0.0 | 0.1 | +0.3 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.1 | +33.0 | 61.5 | 0.0 | 1.3 | +34.8 | 49.3 | 8.0 |
| SHORT GUN FORWARD | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SHOT REPLANNED | 0.5 | +0.0 | 123.2 | 5.5 | 0.0 | +0.0 | 1.7 | 0.0 |
| SHOTS IN THE MOVE | 13.4 | +538.9 | 0.0 | 278.2 | 9.7 | +282.0 | 0.0 | 170.0 |
| SPELL SETS UP CHARGE | 0.4 | +66.1 | 0.0 | 10.5 | 0.2 | +27.9 | 15.5 | 18.7 |
| SPELL WORTH | 1.5 | +25.8 | 60.2 | 79.8 | 2.4 | +43.9 | 91.3 | 85.4 |
| SPELLS IN THE FIGHT | 0.5 | -5.2 | 49.7 | 42.8 | 0.6 | -8.1 | 84.8 | 17.8 |
| STABLE ROLE | 9.8 | +0.0 | 261.6 | 142.2 | 9.4 | +0.0 | 362.3 | 122.1 |
| STANDS TO CAST | 0.1 | +3.2 | 0.0 | 0.0 | - | - | - | - |
| STAY WEIGHED | - | - | - | - | 0.0 | +4.4 | 0.0 | 0.0 |
| STOPS | 0.2 | +7.5 | 8.1 | 5.6 | 0.1 | +1.9 | 1.9 | 1.1 |
| STOPS SHORT OF THE FLANK | 0.6 | +26.6 | 0.0 | 19.0 | 0.4 | +19.0 | 0.0 | 7.1 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| SUPPORT NARROWED | 5.9 | -57.7 | 254.6 | 143.9 | 6.2 | -49.4 | 361.7 | 127.2 |
| SUPPORTS | 4.1 | +68.3 | 103.8 | 99.4 | 4.2 | +52.9 | 193.2 | 64.1 |
| SURE CHARGE BEATS ADVANCE | 0.2 | -2.8 | 16.8 | 0.0 | 0.2 | -4.2 | 5.6 | 0.0 |
| SURE REACH TOGETHER | 0.4 | +1.8 | 7.9 | 17.0 | 0.8 | -8.3 | 0.0 | 2.0 |
| THROUGH LINE OF FIRE | 0.4 | +15.4 | 0.0 | 0.0 | 0.2 | +12.1 | 0.0 | 6.2 |
| TURN WORTH | 0.3 | -19.4 | 33.1 | 1.4 | 0.4 | -29.6 | 37.2 | 10.8 |
| TWO OR MORE ARRIVE | 0.4 | +5.7 | 13.9 | 1.2 | 0.7 | +3.6 | 1.8 | 29.0 |
| WAIT AFTER COSTS | 7.3 | -358.5 | 229.8 | 113.8 | 7.4 | -361.8 | 278.7 | 141.2 |
| WALKS TO THE FIGHT | 1.6 | +13.3 | 26.0 | 6.5 | 0.9 | +3.8 | 36.6 | 3.3 |
| WAR ENGINE CHARGES | 0.1 | +5.9 | 10.4 | 0.0 | 0.1 | +4.2 | 0.0 | 0.0 |
| WAR ENGINE JOBS | 0.8 | +0.0 | 34.2 | 7.5 | 0.2 | +0.0 | 0.0 | 2.1 |
| WEARS DOWN | 1.2 | +47.7 | 115.0 | 26.6 | 1.2 | +44.6 | 141.8 | 35.8 |
| WHO HITS BACK | 0.3 | +25.6 | 0.0 | 18.3 | 0.1 | +14.3 | 0.0 | 0.0 |
| WHOLE FIGHT | 0.2 | +9.6 | 76.6 | 0.0 | 0.4 | +3.1 | 33.1 | 1.9 |
| WHOLE FIGHT GAIN | 0.4 | +31.6 | 58.8 | 0.0 | 0.6 | +34.1 | 74.2 | 4.3 |
| WIDER SPREAD | 1.8 | -8.1 | 161.5 | 60.0 | 2.9 | -8.4 | 263.8 | 32.5 |
| WOUNDED STAYS OUT | - | - | - | - | 0.0 | +0.0 | 6.5 | 0.0 |

### Rule changes: jc-mine-1e5408d-p3

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 1120 | 1120 | 1120 | 31.11 | -53242 | -47.5 |
| MOVE TO CHARGE | 328 | 328 | 182 | 5.06 | +11686 | +64.2 |
| KILLS COUNT NEXT TURN | 462 | 462 | 152 | 4.22 | +4003 | +26.3 |
| PATHS CROSS | 150 | 150 | 150 | 4.17 | +10346 | +69.0 |
| SEARCH SPOT | 153 | 153 | 148 | 4.11 | +7628 | +51.5 |
| FACES THE THREAT | 120 | 120 | 120 | 3.33 | +7874 | +65.6 |
| SUPPORTS | 300 | 300 | 118 | 3.28 | +1427 | +12.1 |
| BEST FIRST | 94 | 94 | 94 | 2.61 | +5203 | +55.4 |
| FOLLOW UP WEIGHED | 84 | 84 | 84 | 2.33 | +13065 | +155.5 |
| WAIT AFTER COSTS | 529 | 529 | 82 | 2.28 | +1470 | +17.9 |
| SHOTS IN THE MOVE | 833 | 571 | 78 | 2.17 | +2275 | +29.2 |
| COVER ONCE | 474 | 251 | 76 | 2.11 | +1579 | +20.8 |
| ARTILLERY RE-ROLL WEIGHED | 69 | 69 | 69 | 1.92 | +0 | +0.0 |
| FALLBACK BY WORTH | 328 | 328 | 66 | 1.83 | +3084 | +46.7 |
| ADVANCE WORTH | 314 | 314 | 64 | 1.78 | +915 | +14.3 |
| SET UP TOGETHER | 133 | 111 | 59 | 1.64 | +4857 | +82.3 |
| CANNON PLANNED TARGET | 246 | 246 | 58 | 1.61 | -694 | -12.0 |
| CANNON SIGHT KEPT | 56 | 56 | 56 | 1.56 | +0 | +0.0 |
| MISSILES IN THE MOVE | 274 | 170 | 56 | 1.56 | +1033 | +18.4 |
| RISK ONCE | 311 | 219 | 56 | 1.56 | +1809 | +32.3 |
| SAFER THAN THE JOB | 54 | 54 | 54 | 1.50 | +4110 | +76.1 |
| COMBAT PIVOT | 49 | 49 | 49 | 1.36 | +0 | +0.0 |
| RESERVE FALL BACK | 49 | 49 | 49 | 1.36 | +2228 | +45.5 |
| REDIRECT COUNTER | 175 | 87 | 45 | 1.25 | +4883 | +108.5 |
| CHAFF IN THE MOVE | 74 | 73 | 40 | 1.11 | +1228 | +30.7 |
| MARCH CHECK | 44 | 43 | 40 | 1.11 | +1348 | +33.7 |
| RISK BY ARC | 181 | 180 | 40 | 1.11 | +1129 | +28.2 |
| HOLDS AMBUSHERS | 39 | 39 | 39 | 1.08 | +0 | +0.0 |
| STOPS SHORT OF THE FLANK | 38 | 38 | 38 | 1.06 | +1639 | +43.1 |
| RANDOM MOVE BY FIGURES | 73 | 73 | 37 | 1.03 | +1049 | +28.4 |
| CHARGE NOW WEIGHED | 36 | 36 | 36 | 1.00 | +3974 | +110.4 |
| ONE FIGHT FORMULA | 592 | 333 | 36 | 1.00 | +162 | +4.5 |
| WALKS TO THE FIGHT | 92 | 92 | 36 | 1.00 | +204 | +5.7 |
| ADVANCE LANE KEPT | 35 | 35 | 35 | 0.97 | +0 | +0.0 |
| KILLS COUNT | 123 | 123 | 35 | 0.97 | +1459 | +41.7 |
| LONE WIZARD KEPT IN | 33 | 33 | 33 | 0.92 | +2259 | +68.5 |
| SHOOTS FROM THE BEST SPOT | 84 | 84 | 32 | 0.89 | +762 | +23.8 |
| MOVE AND CAST | 31 | 31 | 31 | 0.86 | +1443 | +46.5 |
| BEST OVERALL | 28 | 28 | 28 | 0.78 | +1498 | +53.5 |
| CHARGE NOW FIRST | 176 | 176 | 28 | 0.78 | -1616 | -57.7 |
| IDLE COST | 1205 | 667 | 28 | 0.78 | +298 | +10.7 |
| BEST FACING | 27 | 27 | 27 | 0.75 | +1365 | +50.6 |
| MAKE SURE TOGETHER | 78 | 52 | 27 | 0.75 | +2704 | +100.2 |
| MAX FOR POSITIONING | 470 | 265 | 27 | 0.75 | +60 | +2.2 |
| KEEPS ITS TARGET | 146 | 145 | 26 | 0.72 | +423 | +16.3 |
| REDIRECT WEIGHED | 25 | 25 | 25 | 0.69 | +202 | +8.1 |
| SCOUT WAITS | 25 | 25 | 25 | 0.69 | +0 | +0.0 |
| CAST JOB | 60 | 60 | 24 | 0.67 | +382 | +15.9 |
| HONEST WORTH | 628 | 627 | 24 | 0.67 | +208 | +8.7 |
| BLOCKED WHEEL | 23 | 23 | 23 | 0.64 | +1000 | +43.5 |
| THROUGH LINE OF FIRE | 22 | 22 | 22 | 0.61 | +990 | +45.0 |
| WAR ENGINE JOBS | 34 | 34 | 22 | 0.61 | -1459 | -66.3 |
| CHAFF PASSED | 18 | 18 | 18 | 0.50 | -23 | -1.3 |
| INVITES THE FIGHT | 59 | 59 | 18 | 0.50 | +123 | +6.8 |
| MARCH ODDS | 18 | 18 | 18 | 0.50 | +134 | +7.5 |
| SHOOTERS IN TWO RANKS | 18 | 18 | 18 | 0.50 | +36 | +2.0 |
| SHOT REPLANNED | 18 | 18 | 18 | 0.50 | +0 | +0.0 |
| BIG CHARACTER SAFETY | 17 | 17 | 17 | 0.47 | -86 | -5.1 |
| WHO HITS BACK | 16 | 16 | 16 | 0.44 | +974 | +60.9 |
| LOST CHARGE | 196 | 196 | 15 | 0.42 | +281 | +18.7 |
| MANOEUVRE | 21 | 21 | 15 | 0.42 | +363 | +24.2 |
| FRIENDS SHOTS CHECKED | 13 | 13 | 13 | 0.36 | +1296 | +99.7 |
| SURE CHARGE BEATS ADVANCE | 13 | 13 | 13 | 0.36 | -253 | -19.5 |
| BEST PREY | 39 | 39 | 12 | 0.33 | +360 | +30.0 |
| HUNT IN PAIRS | 36 | 20 | 12 | 0.33 | +227 | +18.9 |
| WHOLE FIGHT GAIN | 36 | 35 | 12 | 0.33 | +489 | +40.8 |
| MISSILES NEXT TURN | 356 | 211 | 10 | 0.28 | +69 | +6.9 |
| CASTER AWAY FROM SCREEN | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| CASTING BLOCK | 12 | 12 | 9 | 0.25 | +437 | +48.6 |
| CASTS FROM BEHIND | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| SUPPORT NARROWED | 436 | 436 | 9 | 0.25 | -120 | -13.3 |
| WEARS DOWN | 87 | 86 | 8 | 0.22 | +296 | +37.0 |
| MOVES UNITS SPELL | 7 | 7 | 7 | 0.19 | +141 | +20.1 |
| PIVOT GUARDS FLANK | 7 | 7 | 7 | 0.19 | -51 | -7.3 |
| BEST PRIZE | 6 | 6 | 6 | 0.17 | -491 | -81.8 |
| STUCK PIVOT | 6 | 6 | 6 | 0.17 | +0 | +0.0 |
| HUNT ADVANCE | 11 | 11 | 5 | 0.14 | +204 | +40.8 |
| KEEP FALLS | 5 | 5 | 5 | 0.14 | +131 | +26.1 |
| OPENS UP | 8 | 8 | 5 | 0.14 | +278 | +55.5 |
| REFUSING RETIRES | 18 | 18 | 5 | 0.14 | -1 | -0.2 |
| SHORT GUN FORWARD | 5 | 5 | 5 | 0.14 | +0 | +0.0 |
| MODEL FACING | 4 | 4 | 4 | 0.11 | +1392 | +347.9 |
| ONE OBJECTIVE FORMULA | 130 | 57 | 4 | 0.11 | +216 | +54.0 |
| OVERRUNS AWAY | 33 | 33 | 4 | 0.11 | +165 | +41.3 |
| RAIDS THE BAGGAGE NEXT TURN | 4 | 4 | 4 | 0.11 | +101 | +25.3 |
| SPELLS IN THE FIGHT | 41 | 41 | 4 | 0.11 | +192 | +48.0 |
| SURE REACH TOGETHER | 43 | 34 | 4 | 0.11 | +7 | +1.7 |
| BLOCKED CHARGE SKIPPED | 3 | 3 | 3 | 0.08 | +0 | +0.0 |
| EDGE GIVE GROUND | 15 | 15 | 3 | 0.08 | +72 | +24.0 |
| LONE WIZARD HOLDS BACK | 19 | 19 | 3 | 0.08 | -250 | -83.2 |
| PURSUES BIG PREY | 3 | 3 | 3 | 0.08 | -78 | -25.9 |
| RESTRAINS TO SHOOT | 3 | 3 | 3 | 0.08 | +84 | +28.0 |
| WHOLE FIGHT | 24 | 24 | 3 | 0.08 | +150 | +49.9 |
| BACKUP TARGETS | 50 | 29 | 2 | 0.06 | +10 | +5.1 |
| HORN WORTH | 2 | 2 | 2 | 0.06 | +27 | +13.7 |
| LONG SHOT | 20 | 20 | 2 | 0.06 | +11 | +5.6 |
| MOVE SPELL IN RANGE | 12 | 7 | 2 | 0.06 | +31 | +15.3 |
| PERIAPT WORTH | 2 | 2 | 2 | 0.06 | +199 | +99.4 |
| RAIDS THE BAGGAGE | 2 | 2 | 2 | 0.06 | +322 | +160.9 |
| STANDS TO CAST | 2 | 2 | 2 | 0.06 | -34 | -16.8 |
| TWO OR MORE ARRIVE | 39 | 34 | 2 | 0.06 | +14 | +7.1 |
| WIDER SPREAD | 170 | 169 | 2 | 0.06 | +25 | +12.5 |
| BOUND ASSAILMENT | 1 | 1 | 1 | 0.03 | +0 | +0.1 |
| CARRIES OUT SET-UP | 10 | 10 | 1 | 0.03 | -11 | -10.7 |
| DEFENSIVE ARMY | 8 | 8 | 1 | 0.03 | -12 | -11.9 |
| DEFENSIVE FLOOR | 2 | 2 | 1 | 0.03 | +52 | +52.2 |
| FIRE AND FLEE | 1 | 1 | 1 | 0.03 | +15 | +15.1 |
| JOINT CHARGE PLAN | 12 | 12 | 1 | 0.03 | +26 | +26.2 |
| KEEPS ITS PREY | 4 | 4 | 1 | 0.03 | +8 | +8.4 |
| KEEPS SCOUTS OR AMBUSH | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| SAFE SURE CHARGE | 1 | 1 | 1 | 0.03 | -87 | -87.2 |
| SECOND CHARGER ADDS | 7 | 7 | 1 | 0.03 | +82 | +82.3 |
| STAY WEIGHED | 1 | 1 | 1 | 0.03 | +157 | +157.0 |
| STOPS | 13 | 13 | 1 | 0.03 | +5 | +5.0 |
| WAR ENGINE CHARGES | 4 | 4 | 1 | 0.03 | +95 | +95.1 |
| ALREADY CARRIED | 1 | not checked | - | - | - | - |
| ARRIVAL HUNT | 2 | 2 | 0 | 0.00 | - | - |
| BLOWS WHERE AIMED | 22 | 22 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 25 | 25 | 0 | 0.00 | - | - |
| CARRIES OUT COUNTER | 2 | 2 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 32 | trace | - | - | - | - |
| CHAMPION TAKES THE CHALLENGE | 2 | 2 | 0 | 0.00 | - | - |
| CHARGER SLAIN LOST | 41 | 41 | 0 | 0.00 | - | - |
| CHARIOT NO STATIC JOB | 1 | 1 | 0 | 0.00 | - | - |
| CHARIOT WIZARD CAREFUL | 6 | 6 | 0 | 0.00 | - | - |
| CHEAP HELPER | 3 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 29 | not checked | - | - | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT LIFT | 5 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 363 | not checked | - | - | - | - |
| FRIEND IN REACH | 300 | not checked | - | - | - | - |
| GIVES UP | 6 | 6 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 2 | 2 | 0 | 0.00 | - | - |
| GROUND FLIERS | 1 | not checked | - | - | - | - |
| HELPER ALREADY ASKED | 2 | not checked | - | - | - | - |
| HELPER UNSEEN | 30 | 29 | 0 | 0.00 | - | - |
| HILL BY ITS CHANCE | 23 | 23 | 0 | 0.00 | - | - |
| HUNT DROPPED | 5 | trace | - | - | - | - |
| HUNT KEPT | 13 | trace | - | - | - | - |
| HUNT RESULT | 10 | trace | - | - | - | - |
| HUNT THE GUNS | 13 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 5 | 5 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 19 | not checked | - | - | - | - |
| LURE BY WHAT IT DRAWS | 8 | 8 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 6 | trace | - | - | - | - |
| MARCH OVER CASTS | 42 | 42 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 14 | 14 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 23 | trace | - | - | - | - |
| MOVE SPELL SPOT | 12 | not checked | - | - | - | - |
| NOT NEEDED | 10 | 10 | 0 | 0.00 | - | - |
| NOT TURNED | 381 | 381 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 49 | not checked | - | - | - | - |
| OPENS A LANE | 7 | 2 | 0 | 0.00 | - | - |
| PAIR SET-UP | 7 | not checked | - | - | - | - |
| PLAN RESULT | 2622 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 19 | 19 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 57 | 57 | 0 | 0.00 | - | - |
| SCOUT SPOT | 24 | 24 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 21 | 21 | 0 | 0.00 | - | - |
| SECOND HUNTER | 1 | 1 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 16 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 17 | not checked | - | - | - | - |
| SET-UP MISSED | 2 | trace | - | - | - | - |
| SPELL SETS UP CHARGE | 21 | not checked | - | - | - | - |
| SPELL WORTH | 141 | not checked | - | - | - | - |
| STABLE ROLE | 693 | 692 | 0 | 0.00 | - | - |
| TURN WORTH | 24 | 24 | 0 | 0.00 | - | - |
| WOUNDED STAYS OUT | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: jc-mine-1e5408d-p3

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 14.50 | 13.92 | 48.0 |
| FALLBACK | gate | 0.50 | 0.75 | 45.7 |
| CHARGE NOW FIRST | rule | 0.44 | 0.33 | 57.7 |
| TURN GATE | gate | 0.39 | 0.36 | 62.4 |
| WAR ENGINE JOBS | rule | 0.47 | 0.11 | 69.5 |
| CANNON PLANNED TARGET | rule | 0.31 | 0.14 | 53.8 |
| SURE CHARGE BEATS ADVANCE | rule | 0.19 | 0.17 | 19.5 |
| BIG CHARACTER SAFETY | rule | 0.14 | 0.14 | 10.8 |
| AFTERMATH BAND | gate | 0.17 | 0.08 | 2.6 |
| SUPPORT NARROWED | rule | 0.06 | 0.19 | 13.3 |
| CHAFF PASSED | rule | - | 0.22 | 2.9 |
| PATHS CROSS | rule | 0.17 | 0.03 | 15.4 |
| PIVOT GUARDS FLANK | rule | 0.14 | 0.06 | 7.3 |
| BEST PRIZE | rule | 0.11 | 0.06 | 81.8 |
| LONE CHARACTER SAFE SPOT | gate | 0.06 | 0.08 | 18.9 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.06 | 0.06 | 40.0 |
| STOPS SHORT OF THE FLANK | rule | 0.03 | 0.08 | 11.9 |
| FACES THE THREAT | rule | 0.06 | 0.03 | 8.3 |
| LONE WIZARD HOLDS BACK | rule | 0.03 | 0.06 | 83.2 |
| PURSUES BIG PREY | rule | 0.06 | 0.03 | 25.9 |
| REDIRECT WEIGHED | rule | 0.06 | 0.03 | 64.9 |
| SAFER THAN THE JOB | rule | 0.06 | 0.03 | 11.7 |
| CHARGE NOW WEIGHED | rule | - | 0.06 | 83.7 |
| FIGHT ORDER BAND | gate | - | 0.06 | 2.6 |
| MARCH ODDS | rule | 0.03 | 0.03 | 3.0 |
| NO REASON | gate | 0.06 | - | 8.7 |
| RULE SWITCHED OFF | gate | - | 0.06 | 11.8 |
| STANDS TO CAST | rule | 0.06 | - | 16.8 |
| WHO HITS BACK | rule | 0.03 | 0.03 | 4.9 |
| BLOCKED WHEEL | rule | - | 0.03 | 122.2 |
| CARRIES OUT SET-UP | rule | 0.03 | - | 10.7 |
| DEFENSIVE ARMY | rule | 0.03 | - | 11.9 |
| REFUSING RETIRES | rule | - | 0.03 | 0.7 |
| SAFE SURE CHARGE | rule | 0.03 | - | 87.2 |
| SUPPORT REQUEST | gate | - | 0.03 | 99.5 |
| THROUGH LINE OF FIRE | rule | 0.03 | - | 2.5 |

### Plans: jc-mine-1e5408d-p3

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 9.5 | 16% | 124 | 177 | 143% |
| Mine | charge | 2.8 | 62% | 249 | 271 | 109% |
| Mine | close in | 5.5 | 25% | 403 | 191 | 47% |
| Mine | hold | 4.7 | 39% | 269 | 0 | 0% |
| Mine | join | 0.4 | 100% | 16 | 0 | 0% |
| Mine | shoot | 8.6 | 60% | 214 | 623 | 291% |
| Mine | support | 4.8 | 89% | 53 | 0 | 0% |
| Opponent | advance | 10.2 | 19% | 143 | 302 | 212% |
| Opponent | charge | 3.9 | 54% | 363 | 341 | 94% |
| Opponent | close in | 7.1 | 24% | 421 | 228 | 54% |
| Opponent | hold | 3.8 | 29% | 276 | 0 | 0% |
| Opponent | join | 0.6 | 100% | 28 | 0 | 0% |
| Opponent | shoot | 5.4 | 52% | 116 | 269 | 231% |
| Opponent | support | 5.6 | 84% | 40 | 0 | 0% |

### Packages: hunt the guns, jc-mine-1e5408d-p3

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.1 | 5 | 2 | 67% | 67% | 0% | 3.5 | 386 | 162 | 0% | 16 |
| Opponent | 0.2 | 8 | 1 | 14% | 29% | 0% | 2.0 | 294 | 48 | 29% | 87 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.8 | 3 | 1 | 50% | 50% | 0% | 4.0 | 392 | 139 | 0% | 13 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 32 |
| Empire of Man | 0.2 | 1 | 0 | 100% | 100% | 0% | 3.0 | 375 | 208 | 0% | 47 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 21 |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 110 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 190 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Ogre Kingdoms | 1.0 | 1 | 1 | - | - | - | - | - | - | - | 0 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 270 |
| Tomb Kings of Khemri | 0.3 | 2 | 0 | 0% | 0% | 0% | - | 315 | 0 | 0% | 44 |
| Vampire Counts | 0.1 | 1 | 0 | 100% | 100% | 0% | 2.0 | 78 | 76 | 100% | 21 |
| Warriors of Chaos | 0.1 | 1 | 0 | 0% | 100% | 0% | 2.0 | 304 | 259 | 100% | 50 |
| Wood Elf Realms | 0.7 | 4 | 1 | 0% | 0% | 0% | - | 348 | 0 | 0% | 42 |

### Battle groups: jc-mine-1e5408d-p3

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 1.8 | 30% | 84% | 11% | 50% | 35% | 0% | 6% | 59% | 0% |
| Opponent | REDIRECT COUNTER | 3.1 | 19% | 90% | 29% | 0% | 20% | 0% | 20% | 60% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: jc-mine-1e5408d-p3

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 1 | 0 (1) | 0 | 0 | 100 | 0% | 5.0 | - | - | 0 (1) | - | 0 (1) |
| Mine | Chaff | 34 | 64 (34) | 18 | 46 | 40 | 35% | 2.2 | 70 (21) | 0 (4) | 72 (9) | 80 (24) | 32 (10) |
| Mine | Character | 118 | 53 (118) | 52 | 1 | 37 | 18% | 2.5 | 67 (38) | 56 (56) | 22 (3) | 44 (55) | 78 (42) |
| Mine | Clean-up | 18 | 65 (18) | 26 | 39 | 55 | 28% | 3.0 | 79 (3) | 45 (13) | 273 (2) | 87 (12) | 31 (6) |
| Mine | Fast | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Mine | Fast Hammer | 44 | 36 (44) | 20 | 17 | 34 | 25% | 2.8 | 42 (22) | 31 (14) | 33 (8) | 47 (30) | 17 (14) |
| Mine | Fragile | 3 | 10 (3) | 10 | 0 | 100 | 67% | 4.0 | 10 (3) | - | - | 29 (1) | 0 (2) |
| Mine | Hammer | 52 | 42 (52) | 31 | 11 | 29 | 12% | 2.6 | 15 (14) | 50 (35) | 79 (3) | 44 (36) | 38 (16) |
| Mine | Holder | 25 | 66 (25) | 20 | 46 | 31 | 32% | 3.4 | 57 (8) | 77 (10) | 53 (7) | 72 (15) | 58 (10) |
| Mine | Shooter | 37 | 39 (37) | 9 | 30 | 54 | 3% | 1.9 | 33 (6) | 43 (29) | 0 (2) | 48 (22) | 26 (15) |
| Mine | Support | 4 | 0 (4) | 0 | 0 | 100 | 0% | 2.5 | 0 (1) | - | - | 0 (1) | - |
| Mine | War machine | 52 | 48 (52) | 48 | 0 | 42 | 2% | 1.1 | 64 (13) | 35 (36) | 133 (3) | 59 (13) | 44 (39) |
| Mine | Wizard | 17 | 20 (17) | 20 | 0 | 41 | 18% | 2.2 | 47 (5) | 21 (6) | 0 (1) | 20 (8) | 47 (4) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Chaff | 68 | 32 (68) | 7 | 26 | 59 | 40% | 3.1 | 49 (29) | 13 (11) | 28 (28) | 30 (48) | 39 (20) |
| Opponent | Character | 102 | 57 (102) | 56 | 1 | 34 | 17% | 2.1 | 44 (35) | 72 (53) | 33 (6) | 56 (54) | 64 (40) |
| Opponent | Clean-up | 11 | 79 (11) | 20 | 59 | 13 | 36% | 3.3 | 9 (4) | 111 (6) | 130 (1) | 47 (6) | 109 (5) |
| Opponent | Fast | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Fast Hammer | 60 | 44 (60) | 25 | 19 | 50 | 17% | 2.9 | 38 (30) | 48 (20) | 56 (10) | 59 (28) | 29 (32) |
| Opponent | Fragile | 3 | 0 (3) | 0 | 0 | 67 | 0% | 2.3 | - | 0 (2) | 0 (1) | 0 (2) | 0 (1) |
| Opponent | Hammer | 50 | 39 (50) | 28 | 11 | 47 | 28% | 2.6 | 39 (17) | 37 (30) | 60 (3) | 30 (30) | 52 (20) |
| Opponent | Holder | 40 | 45 (40) | 4 | 41 | 36 | 20% | 3.1 | 33 (11) | 62 (20) | 20 (8) | 57 (27) | 25 (12) |
| Opponent | Shooter | 27 | 43 (27) | 24 | 19 | 34 | 7% | 1.3 | 70 (6) | 33 (19) | 58 (2) | 58 (16) | 23 (11) |
| Opponent | Support | 4 | 87 (4) | 87 | 0 | 17 | 25% | 6.0 | 519 (1) | 0 (2) | 0 (1) | 0 (2) | 259 (2) |
| Opponent | War machine | 17 | 29 (17) | 29 | 0 | 54 | 0% | 1.5 | 0 (3) | 26 (10) | 51 (4) | 0 (3) | 34 (14) |
| Opponent | Wizard | 32 | 21 (32) | 21 | 0 | 23 | 16% | 2.1 | 19 (13) | 34 (10) | 26 (3) | 37 (15) | 0 (11) |

### Charged fights: jc-mine-1e5408d-p3

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 41 | 66 | 1.8 | 1.0 | 38 | 24 | +14 | 0 of 7 | 5 of 7 | - | +14 |
| Mine | Chaos Dwarfs | 4 | 89 | 448 | 3.5 | 1.1 | 128 | 22 | +106 | 8 of 14 | 12 of 14 | +186 | +92 |
| Mine | Dwarfen Mountain Holds | 3 | 565 | 0 | 2.0 | 1.2 | 0 | 10 | -10 | 1 of 6 | 3 of 6 | +0 | -12 |
| Mine | Empire of Man | 5 | 446 | 222 | 1.4 | 1.1 | 158 | 0 | +158 | 1 of 7 | 6 of 7 | +663 | +74 |
| Mine | Grand Cathay | 5 | 207 | 338 | 3.8 | 1.1 | 89 | 11 | +78 | 7 of 19 | 16 of 19 | +80 | +78 |
| Mine | High Elf Realms | 4 | 26 | 300 | 3.0 | 1.2 | 100 | 31 | +69 | 6 of 12 | 9 of 12 | +64 | +70 |
| Mine | Kingdom of Bretonnia | 1 | 19 | 0 | 2.0 | 1.0 | 0 | 191 | -191 | 0 of 2 | 0 of 2 | - | -191 |
| Mine | Lizardmen | 1 | 0 | 1127 | 5.0 | 1.0 | 225 | 0 | +225 | 1 of 5 | 5 of 5 | - | +225 |
| Mine | Ogre Kingdoms | 1 | 232 | 0 | 4.0 | 1.0 | 0 | 31 | -31 | 3 of 4 | 2 of 4 | - | -31 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 446 | 5.0 | 1.2 | 89 | 11 | +78 | 1 of 5 | 4 of 5 | +82 | +77 |
| Mine | Skaven | 1 | 19 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Mine | Tomb Kings of Khemri | 2 | 0 | 1083 | 7.5 | 1.3 | 144 | 14 | +130 | 4 of 15 | 12 of 15 | +165 | +117 |
| Mine | Vampire Counts | 2 | 382 | 464 | 4.0 | 1.0 | 116 | 82 | +34 | 3 of 8 | 7 of 8 | - | +34 |
| Mine | Warriors of Chaos | 2 | 0 | 412 | 4.0 | 1.0 | 103 | 14 | +88 | 3 of 8 | 7 of 8 | - | +88 |
| **Mine** | all armies | 36 | 184 | 321 | 3.1 | 1.1 | 103 | 24 | +79 | 38 of 112 | 88 of 112 | +165 | +69 |
| Opponent | Empire of Man | 1 | 299 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Grand Cathay | 3 | 403 | 354 | 2.3 | 1.3 | 152 | 62 | +90 | 5 of 7 | 2 of 7 | +55 | +104 |
| Opponent | High Elf Realms | 3 | 374 | 0 | 1.7 | 1.0 | 0 | 109 | -109 | 2 of 5 | 3 of 5 | - | -109 |
| Opponent | Kingdom of Bretonnia | 2 | 130 | 632 | 3.5 | 1.1 | 181 | 70 | +111 | 5 of 7 | 4 of 7 | +379 | +66 |
| Opponent | Orc & Goblin Tribes | 1 | 0 | 571 | 4.0 | 1.2 | 143 | 26 | +117 | 2 of 4 | 3 of 4 | +0 | +156 |
| Opponent | Skaven | 1 | 235 | 186 | 2.0 | 1.5 | 93 | 50 | +43 | 1 of 2 | 1 of 2 | -100 | +186 |
| Opponent | Tomb Kings of Khemri | 4 | 41 | 806 | 4.8 | 1.1 | 170 | 85 | +85 | 10 of 19 | 13 of 19 | +95 | +84 |
| Opponent | Vampire Counts | 6 | 103 | 630 | 4.7 | 1.3 | 135 | 60 | +75 | 14 of 28 | 17 of 28 | +93 | +70 |
| Opponent | Warriors of Chaos | 9 | 0 | 484 | 4.2 | 1.1 | 115 | 7 | +108 | 16 of 38 | 27 of 38 | +143 | +104 |
| Opponent | Wood Elf Realms | 6 | 97 | 205 | 2.3 | 1.3 | 88 | 22 | +66 | 3 of 14 | 10 of 14 | +105 | +50 |
| **Opponent** | all armies | 36 | 125 | 435 | 3.4 | 1.2 | 126 | 45 | +82 | 58 of 124 | 80 of 124 | +102 | +78 |

### Effective charges: jc-mine-1e5408d-p3

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 7 | 1 (net -30) | 0 | 2 (net +40) | 2 (net +30) | 0 | 1 (net -12) | 1 | 33% (2 of 6) |
| Mine | Chaos Dwarfs | 14 | 0 | 0 | 2 (net +200) | 6 (net -23) | 1 (net +0) | 3 (net +193) | 2 | 17% (2 of 12) |
| Mine | Dwarfen Mountain Holds | 6 | 2 (net +0) | 0 | 0 | 3 (net -20) | 0 | 1 (net +0) | 0 | 0% (0 of 6) |
| Mine | Empire of Man | 7 | 0 | 0 | 0 | 1 (net +0) | 2 (net +368) | 2 (net +124) | 2 | 0% (0 of 5) |
| Mine | Grand Cathay | 19 | 1 (net +0) | 3 (net +71) | 1 (net +0) | 1 (net +70) | 3 (net +69) | 8 (net +103) | 2 | 6% (1 of 17) |
| Mine | High Elf Realms | 12 | 1 (net -175) | 0 | 2 (net +0) | 1 (net -199) | 6 (net +157) | 2 (net +128) | 0 | 17% (2 of 12) |
| Mine | Kingdom of Bretonnia | 2 | 1 (net -275) | 0 | 0 | 0 | 0 | 0 | 1 | 0% (0 of 1) |
| Mine | Lizardmen | 5 | 0 | 0 | 1 (net +0) | 2 (net +72) | 0 | 0 | 2 | 33% (1 of 3) |
| Mine | Ogre Kingdoms | 4 | 0 | 0 | 1 (net -90) | 1 (net +0) | 0 | 1 (net +0) | 1 | 33% (1 of 3) |
| Mine | Orc & Goblin Tribes | 5 | 1 (net +0) | 0 | 0 | 0 | 0 | 1 (net +82) | 3 | 0% (0 of 2) |
| Mine | Tomb Kings of Khemri | 15 | 0 | 0 | 5 (net +180) | 4 (net +109) | 4 (net +121) | 2 (net +66) | 0 | 33% (5 of 15) |
| Mine | Vampire Counts | 8 | 0 | 1 (net -60) | 1 (net -599) | 1 (net +80) | 0 | 5 (net +169) | 0 | 12% (1 of 8) |
| Mine | Warriors of Chaos | 8 | 1 (net +28) | 0 | 1 (net +0) | 1 (net +109) | 0 | 2 (net +203) | 3 | 20% (1 of 5) |
| Opponent | Grand Cathay | 7 | 2 (net -217) | 0 | 1 (net +0) | 4 (net +266) | 0 | 0 | 0 | 14% (1 of 7) |
| Opponent | High Elf Realms | 5 | 2 (net -174) | 0 | 3 (net -66) | 0 | 0 | 0 | 0 | 60% (3 of 5) |
| Opponent | Kingdom of Bretonnia | 7 | 3 (net -52) | 0 | 0 | 2 (net +248) | 0 | 1 (net +0) | 1 | 0% (0 of 6) |
| Opponent | Orc & Goblin Tribes | 4 | 0 | 0 | 0 | 0 | 0 | 2 (net +198) | 2 | 0% (0 of 2) |
| Opponent | Skaven | 2 | 0 | 0 | 0 | 2 (net +43) | 0 | 0 | 0 | 0% (0 of 2) |
| Opponent | Tomb Kings of Khemri | 19 | 6 (net +156) | 0 | 1 (net +410) | 2 (net +72) | 4 (net +120) | 4 (net +145) | 2 | 6% (1 of 17) |
| Opponent | Vampire Counts | 28 | 8 (net +104) | 1 (net +492) | 3 (net -49) | 6 (net +102) | 4 (net +35) | 6 (net +30) | 0 | 11% (3 of 28) |
| Opponent | Warriors of Chaos | 38 | 10 (net +98) | 0 | 7 (net +155) | 3 (net +98) | 0 | 14 (net +106) | 4 | 21% (7 of 34) |
| Opponent | Wood Elf Realms | 14 | 2 (net +63) | 0 | 1 (net +0) | 2 (net +36) | 2 (net +130) | 1 (net +264) | 6 | 12% (1 of 8) |

### Charged fights, damage counted: jc-mine-1e5408d-p3

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 8 | 126 | 227 | -56 | 54 | 98 | -44 | -34.8 |
| Mine | 50-54% | 4 | 233 | 246 | +38 | 116 | 76 | +40 | +17.2 |
| Mine | Effective (55-75%) | 16 | 258 | 277 | +43 | 126 | 72 | +54 | +20.9 |
| Mine | 76-89% | 23 | 268 | 195 | +22 | 73 | 47 | +26 | +9.8 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 28 | 273 | 174 | +120 | 135 | 8 | +127 | +46.5 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 16 | 417 | 93 | +148 | 158 | 19 | +139 | +33.2 |
| Mine | No odds | 17 | 308 | 186 | +133 | 166 | 13 | +154 | +50.0 |
| Mine | All fights | 112 | 284 | 190 | +79 | 123 | 36 | +86 | +30.4 |
| Opponent | Long shot (under 50%) | 33 | 216 | 253 | +59 | 173 | 116 | +57 | +26.3 |
| Opponent | 50-54% | 1 | 499 | 272 | +492 | 492 | 62 | +430 | +86.1 |
| Opponent | Effective (55-75%) | 16 | 308 | 283 | +72 | 146 | 56 | +90 | +29.2 |
| Opponent | 76-89% | 21 | 363 | 210 | +132 | 147 | 30 | +117 | +32.1 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 28 | 334 | 225 | +103 | 130 | 40 | +90 | +26.9 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 10 | 499 | 134 | +88 | 119 | 27 | +91 | +18.3 |
| Opponent | No odds | 15 | 170 | 218 | +1 | 115 | 94 | +21 | +12.4 |
| Opponent | All fights | 124 | 299 | 230 | +82 | 147 | 67 | +80 | +26.8 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| jc-mine-1e5408d-p3 | move | 381 | 86 (23%) | 66 (17%) | 57 (15%) | 238 (62%) |
| jc-mine-1e5408d-p3 | objective | 458 | 65 (14%) | 47 (10%) | 64 (14%) | 329 (72%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0110, L0126, L2433, L2630 |
| Charmed Shield | Opponent | L0126, L0226, L0327, L0725, L1327, L2327 |
| Clockwork Compass | Mine | L1216, L1232 |
| Elixir of Power | Mine | L1122, L1932 |
| Elixir of Power | Opponent | L0311, L1519 |
| Fistful of Laurels | Mine | L1831 |
| Horn of the Wild Hunt | Opponent | L0533, L1633, L2033, L2433, L3133 |
| Invocation of Nehek | Mine | L2433 |
| Invocation of Nehek | Opponent | L0327, L0725, L1327, L2327 |
| Opal Amulet | Mine | L1422 |
| Periapt of Soul Exchange | Mine | L2033 |
| Periapt of Soul Exchange | Opponent | L0620 |
| Ring of Doom | Mine | L0210, L0226, L1122, L1216, L1232, L1519, L1535, L3133 |
| Ring of Doom | Opponent | L0311, L0533, L0815, L0831, L1633, L1731, L1831, L2033, L2433, L3133 |
| Ring of Jet | Mine | L1013, L1030, L1122, L1216, L1232 |
| Ring of Jet | Opponent | L0110, L0210, L0311 |
| Standard of the Fell Warrior | Mine | L1327 |
| Standard of the Fell Warrior | Opponent | L0413, L1013 |
| Twice-Blessed Armour | Mine | L0709, L0725, L1013, L1030 |
| Twice-Blessed Armour | Opponent | L0110, L0210 |
| Witch Hunter's Ward | Mine | L0709, L0725, L0815, L0831 |

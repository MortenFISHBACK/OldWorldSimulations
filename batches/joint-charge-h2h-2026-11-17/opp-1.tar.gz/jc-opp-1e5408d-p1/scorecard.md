# Doctrine scorecard: jc-opp-1e5408d-p1

### Scorecard: jc-opp-1e5408d-p1

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0102 | 6 | 1 | Mine | no | 12 | 3 | 1 | 1 | 0 | 0 | 0 | 77 |
| L0102 | 6 | 1 | Opponent | no | 6 | 1 | 5 | 4 | 0 | 0 | 0 | 170 |
| L0118 | 4 | 1 | Mine | no | 4 | - | 0 | 2 | 0 | 0 | 0 | 322 |
| L0118 | 4 | 1 | Opponent | no | 0 | 3 | 2 | 5 | 1 | 0 | 0 | 516 |
| L0135 | 3 | 1 | Mine | no | 1 | 6 | 0 | 1 | 0 | 0 | 0 | 120 |
| L0135 | 3 | 1 | Opponent | no | 0 | 2 | 2 | 3 | 0 | 0 | 0 | 0 |
| L0218 | 2 | 1 | Mine | - | - | 2 | 2 | 2 | 0 | 0 | 0 | 84 |
| L0218 | 2 | 1 | Opponent | - | - | 6 | 1 | 2 | 1 | 0 | 0 | 0 |
| L0235 | 1 | 1 | Mine | no | 1 | 2 | 2 | 4 | 0 | 0 | 0 | 0 |
| L0235 | 1 | 1 | Opponent | no | 0 | 4 | 1 | 2 | 0 | 0 | 0 | 250 |
| L0319 | 1 | 1 | Mine | no | 4 | 3 | 2 | 0 | 0 | 0 | 0 | 675 |
| L0319 | 1 | 1 | Opponent | no | 0 | 2 | 2 | 1 | 1 | 0 | 0 | 255 |
| L0405 | 3 | 1 | Mine | yes | 5 | 2 | 1 | 1 | 0 | 0 | 0 | 0 |
| L0405 | 3 | 1 | Opponent | no | 1 | - | 2 | 1 | 0 | 0 | 0 | 1193 |
| L0421 | 1 | 1 | Mine | no | 0 | 2 | 5 | 0 | 0 | 0 | 0 | 0 |
| L0421 | 1 | 1 | Opponent | no | 0 | 5 | 1 | 3 | 1 | 0 | 0 | 420 |
| L0508 | 4 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 548 |
| L0508 | 4 | 1 | Opponent | no | 0 | 2 | 3 | 1 | 0 | 0 | 0 | 769 |
| L0524 | 2 | 1 | Mine | - | - | 2 | 2 | 1 | 0 | 0 | 0 | 686 |
| L0524 | 2 | 1 | Opponent | - | - | 3 | 0 | 2 | 0 | 0 | 0 | 0 |
| L0612 | 6 | 1 | Mine | no | 2 | - | 0 | 2 | 1 | 0 | 0 | 743 |
| L0612 | 6 | 1 | Opponent | no | 6 | 2 | 3 | 0 | 1 | 0 | 0 | 330 |
| L0628 | 4 | 1 | Mine | no | 0 | 4 | 2 | 2 | 0 | 0 | 0 | 981 |
| L0628 | 4 | 1 | Opponent | no | 1 | 3 | 2 | 0 | 0 | 0 | 0 | 238 |
| L0717 | 3 | 1 | Mine | yes | 0 | 2 | 3 | 1 | 0 | 0 | 0 | 420 |
| L0717 | 3 | 1 | Opponent | yes | 4 | 2 | 6 | 1 | 1 | 0 | 0 | 175 |
| L0733 | 1 | 1 | Mine | no | 0 | 1 | 3 | 1 | 1 | 0 | 0 | 375 |
| L0733 | 1 | 1 | Opponent | no | 3 | 4 | 2 | 2 | 0 | 0 | 0 | 0 |
| L0823 | 1 | 1 | Mine | no | 3 | 2 | 1 | 0 | 1 | 0 | 0 | 515 |
| L0823 | 1 | 1 | Opponent | no | 3 | 2 | 2 | 3 | 2 | 0 | 0 | 70 |
| L0913 | 1 | 1 | Mine | no | 5 | - | 1 | 2 | 0 | 0 | 0 | 701 |
| L0913 | 1 | 1 | Opponent | no | 4 | 2 | 1 | 2 | 2 | 0 | 0 | 140 |
| L0930 | 6 | 1 | Mine | no | 2 | 6 | 1 | 1 | 0 | 0 | 0 | 733 |
| L0930 | 6 | 1 | Opponent | no | 2 | 2 | 5 | 0 | 1 | 0 | 0 | 0 |
| L1021 | 1 | 1 | Mine | no | 0 | 2 | 6 | 0 | 1 | 0 | 0 | 330 |
| L1021 | 1 | 1 | Opponent | no | 0 | 3 | 1 | 3 | 1 | 0 | 0 | 577 |
| L1114 | 4 | 1 | Mine | no | 0 | 3 | 1 | 1 | 0 | 0 | 0 | 427 |
| L1114 | 4 | 1 | Opponent | no | 0 | 4 | 1 | 3 | 0 | 0 | 0 | 500 |
| L1131 | 3 | 1 | Mine | no | 3 | - | 4 | 0 | 1 | 0 | 0 | 676 |
| L1131 | 3 | 1 | Opponent | no | 0 | 5 | 1 | 1 | 3 | 0 | 0 | 170 |
| L1224 | 6 | 1 | Mine | no | 4 | 2 | 2 | 0 | 0 | 0 | 0 | 330 |
| L1224 | 6 | 1 | Opponent | no | 4 | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| L1319 | 5 | 1 | Mine | yes | - | 3 | 1 | 0 | 0 | 0 | 0 | 140 |
| L1319 | 5 | 1 | Opponent | yes | - | 2 | 3 | 0 | 1 | 0 | 0 | 0 |
| L1335 | 3 | 1 | Mine | no | 5 | 2 | 2 | 0 | 0 | 0 | 0 | 140 |
| L1335 | 3 | 1 | Opponent | no | 0 | 2 | 4 | 4 | 0 | 0 | 0 | 236 |
| L1431 | 3 | 1 | Mine | no | 4 | 2 | 8 | 0 | 0 | 0 | 0 | 0 |
| L1431 | 3 | 1 | Opponent | no | 2 | 3 | 2 | 0 | 4 | 0 | 0 | 535 |
| L1527 | 3 | 1 | Mine | yes | 11 | 6 | 1 | 0 | 0 | 0 | 0 | 0 |
| L1527 | 3 | 1 | Opponent | no | 0 | 4 | 3 | 1 | 0 | 0 | 0 | 0 |
| L1625 | 5 | 1 | Mine | yes | - | 3 | 5 | 2 | 0 | 0 | 0 | 200 |
| L1625 | 5 | 1 | Opponent | yes | - | 4 | 2 | 1 | 1 | 0 | 0 | 0 |
| L1723 | 1 | 1 | Mine | no | 1 | 3 | 5 | 0 | 0 | 0 | 0 | 207 |
| L1723 | 1 | 1 | Opponent | yes | 11 | 2 | 1 | 0 | 1 | 0 | 0 | 0 |
| L1823 | 5 | 1 | Mine | no | - | - | 3 | 0 | 0 | 0 | 0 | 0 |
| L1823 | 5 | 1 | Opponent | yes | - | 1 | 3 | 1 | 2 | 0 | 0 | 0 |
| L1923 | 3 | 1 | Mine | no | 4 | 2 | 5 | 0 | 1 | 0 | 0 | 0 |
| L1923 | 3 | 1 | Opponent | no | 0 | 2 | 4 | 2 | 0 | 0 | 0 | 0 |
| L2025 | 3 | 1 | Mine | yes | 4 | - | 1 | 2 | 2 | 0 | 0 | 860 |
| L2025 | 3 | 1 | Opponent | no | 11 | 2 | 5 | 2 | 0 | 0 | 0 | 211 |
| L2127 | 3 | 1 | Mine | no | 5 | 3 | 1 | 3 | 0 | 0 | 0 | 500 |
| L2127 | 3 | 1 | Opponent | no | 13 | 2 | 6 | 3 | 0 | 0 | 0 | 0 |
| L2231 | 5 | 1 | Mine | yes | - | 1 | 4 | 0 | 0 | 0 | 0 | 0 |
| L2231 | 5 | 1 | Opponent | no | - | - | 0 | 2 | 1 | 0 | 0 | 657 |
| L2335 | 1 | 1 | Mine | no | 0 | 2 | 2 | 2 | 1 | 0 | 0 | 245 |
| L2335 | 1 | 1 | Opponent | no | 0 | 2 | 3 | 1 | 1 | 0 | 0 | 0 |
| L2531 | 5 | 1 | Mine | yes | - | 4 | 2 | 3 | 0 | 0 | 0 | 0 |
| L2531 | 5 | 1 | Opponent | no | - | - | 0 | 4 | 0 | 0 | 0 | 0 |
| L2730 | 6 | 1 | Mine | no | 0 | 1 | 5 | 4 | 0 | 0 | 0 | 0 |
| L2730 | 6 | 1 | Opponent | no | 6 | 2 | 1 | 1 | 0 | 0 | 0 | 0 |
| L2934 | 6 | 1 | Mine | no | 3 | 6 | 1 | 0 | 0 | 0 | 0 | 170 |
| L2934 | 6 | 1 | Opponent | no | 0 | 1 | 5 | 0 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 24% | 2.9 | 2.8 | 2.4 | 1.1 | 0.2 | 0.0 | 0.0 | 311.2 |
| **Average** | | | Opponent | 15% | 2.7 | 2.7 | 2.4 | 1.7 | 0.7 | 0.0 | 0.0 | 205.9 |

### KPIs: jc-opp-1e5408d-p1

Rules off - Mine only: SECOND CHARGER ADDS.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 29% (50 of 172) | 2% (4 of 177) | 15% (54 of 349) |
| Winner chose to follow up after the loser gave ground |  | 98% (50 of 51); on the table 98% | 95% (52 of 55); on the table 96% | 96% (102 of 106); on the table 97% |
| Winner chose to pursue after the loser fell back in good order |  | 64% (7 of 11); on the table 64% | 83% (29 of 35); on the table 91% | 78% (36 of 46); on the table 85% |
| Winner chose to pursue after the loser fled |  | 89% (16 of 18); on the table 89% | 77% (40 of 52); on the table 83% | 80% (56 of 70); on the table 84% |
| Winner chose to follow up or pursue (all three) |  | 91% (73 of 80); on the table 91% | 85% (121 of 142); on the table 90% | 87% (194 of 222); on the table 91% |
| Magic missiles tried each own turn | 50%+ | 33% (109 of 330) | 25% (52 of 210) | 30% (161 of 540) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 43% (109 of 255) | 35% (52 of 148) | 40% (161 of 403) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 64% (18 of 28) | 45% (22 of 49) | 52% (40 of 77) |
| Points that never fought | lower | 40% (28692 of 71484) | 38% (27127 of 71889) | 39% (55819 of 143373) |
|   infantry points that never fought | lower | 47% (7895 of 16863) | 63% (8439 of 13348) | 54% (16334 of 30211) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 56% (156 of 279) | 60% (177 of 295) | 58% (333 of 574) |
| Bound items with a magic missile used (at least once a game) |  | 95% (21 of 22); 1.7 uses a game | 70% (14 of 20); 1.1 uses a game | 83% (35 of 42); 1.4 uses a game |
| Bound items with another spell used |  | 75% (12 of 16); 0.8 uses a game | 0% (0 of 8); 0.0 uses a game | 50% (12 of 24); 0.4 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 53% (10 of 19); 0.3 uses a game | 67% (8 of 12); 0.2 uses a game | 58% (18 of 31); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 51% (30664 of 59666) | 55% (34425 of 62699) | 53% (65089 of 122365) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 2.6 (43%) | 1.6 (35%) | 4.2 (40%) |
| MARCHED: its unit marched | 0.9 (14%) | 0.6 (13%) | 1.4 (14%) |
| CHARGED: its unit charged | 0.3 (5%) | 0.2 (4%) | 0.5 (4%) |
| IN COMBAT: engaged in combat | 1.2 (19%) | 0.8 (18%) | 2.0 (19%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.4 (8%) | 0.4 (3%) |
| FLEEING: fleeing | 0.1 (1%) | 0.0 (1%) | 0.1 (1%) |
| GONE: slain | 0.8 (13%) | 0.7 (16%) | 1.5 (14%) |
| OFF THE TABLE: off the table or not arrived | 0.1 (1%) | 0.2 (4%) | 0.2 (2%) |
| STUPIDITY: Stupidity | 0.2 (4%) | 0.0 (1%) | 0.2 (2%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.4 | 1.2 | 1.4 | 4.5 | 0.6 | 1.6 |
| not cast | 3.6 | 3.1 | 3.2 | 10.5 | 1.7 | 22.4 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) | 0.0 (0%) | 1.6 (7%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.5 (50%) | 0.4 (12%) | 4.2 (40%) | 0.4 (25%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.4 (14%) | 0.1 (7%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.5 (4%) | 0.1 (8%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.1 (3%) | 0.1 (5%) | 0.2 (8%) | 2.0 (19%) | 0.3 (16%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.0 (1%) | 0.2 (5%) | 0.3 (9%) | 0.4 (3%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.1 (3%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.3 (1%) |
| GONE: slain | 0.5 (15%) | 0.6 (21%) | 0.8 (26%) | 1.5 (14%) | 0.1 (3%) | 2.9 (13%) |
| OFF THE TABLE: off the table or not arrived | 0.2 (5%) | 0.2 (5%) | 0.2 (5%) | 0.2 (2%) | 0.0 (0%) | 0.6 (3%) |
| STUPIDITY: Stupidity | 0.1 (2%) | 0.0 (1%) | 0.1 (3%) | 0.2 (2%) | 0.0 (0%) | 0.2 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.2 (6%) | 0.0 (0%) | 0.0 (0%) | 0.7 (41%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.6 (71%) | 0.2 (7%) | 1.2 (38%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 16.8 (75%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.2 a game | 0.5 a game | 0.8 a game |
| stood (cast and not dispelled) | 61% (23 of 38) | 75% (12 of 16) | 65% (35 of 54) |
| the unit moved after it | 39% (9 of 23) | 75% (9 of 12) | 51% (18 of 35) |
| it charged on its next turn | 0% (0 of 23) | 0% (0 of 12) | 0% (0 of 35) |
| the enemy charged it first | 13% (3 of 23) | 0% (0 of 12) | 9% (3 of 35) |
| it fought by the end of its next turn | 13% (3 of 23) | 0% (0 of 12) | 9% (3 of 35) |
| it moved out of a charge the enemy had planned (not charged first) | 9% (2 of 23) | 0% (0 of 12) | 6% (2 of 35) |
| none of these (no charge, no fight, no charge escaped) | 78% (18 of 23) | 100% (12 of 12) | 86% (30 of 35) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 63% (566 of 897) | 57% (346 of 610) | 61% (912 of 1507) |
|   cavalry | 60% (46 of 77) | 70% (90 of 128) | 66% (136 of 205) |
|   character | 53% (62 of 116) | 28% (31 of 109) | 41% (93 of 225) |
|   chariot | 50% (45 of 90) | 63% (24 of 38) | 54% (69 of 128) |
|   infantry | 56% (171 of 306) | 55% (137 of 249) | 55% (308 of 555) |
|   monster | 58% (23 of 40) | 41% (9 of 22) | 52% (32 of 62) |
|   war machine | 82% (219 of 268) | 86% (55 of 64) | 83% (274 of 332) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.5 (27%) | 1.8 (24%) | 4.2 (26%) |
| CHARGED: it charged | 1.1 (12%) | 1.5 (20%) | 2.6 (16%) |
| FLEEING: it fled or was fleeing | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| IN COMBAT: it fought this turn or the last | 0.8 (8%) | 0.4 (6%) | 1.2 (7%) |
| HELD FIRE: a target, but it held its fire | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NO TARGET IN RANGE | 1.6 (18%) | 1.8 (25%) | 3.4 (21%) |
| ONLY IN COMBAT: the only targets were in combat | 0.9 (9%) | 0.7 (9%) | 1.6 (9%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.7 (19%) | 0.9 (13%) | 2.7 (16%) |
| SHELTERED: the target was sheltered | 0.1 (1%) | 0.1 (2%) | 0.2 (1%) |
| STUPIDITY | 0.0 (0%) | 0.1 (1%) | 0.1 (0%) |
| OTHER BAR | 0.4 (5%) | 0.0 (0%) | 0.5 (3%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 5.6 | 1.1 | 84% | 3.8 pts | 21 pts |
| character | 3.1 | 0.9 | 82% | 4.4 pts | 14 pts |
| chariot | 2.0 | 1.5 | 61% | 18.0 pts | 36 pts |
| infantry | 12.4 | 4.2 | 75% | 8.2 pts | 102 pts |
| monster | 1.1 | 0.3 | 87% | 3.7 pts | 4 pts |
| war machine | 7.6 | 5.1 | 66% | 22.8 pts | 173 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.0 | 5.6 | 4.8 |
| Charges that made contact a game | 3.1 | 4.0 | 3.6 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.00 declared, 0.71 contact (21 units) | 0.71 declared, 0.50 contact (14 units) | 0.89 declared, 0.63 contact (35 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.80 declared, 0.80 contact (5 units) | 0.89 declared, 0.78 contact (9 units) | 0.86 declared, 0.79 contact (14 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.48 declared, 0.38 contact (249 units) | 0.66 declared, 0.47 contact (279 units) | 0.58 declared, 0.42 contact (528 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 61% (43 of 70) | 48% (10 of 21) | 38% (3 of 8) | 57% (56 of 99) |
| Character in a unit | 84% (26 of 31) | 67% (16 of 24) | 75% (3 of 4) | 76% (45 of 59) |
| Character on its own | 86% (48 of 56) | 50% (18 of 36) | 29% (18 of 62) | 55% (84 of 154) |
| Chariot | 44% (7 of 16) | 70% (7 of 10) | - | 54% (14 of 26) |
| Infantry | 55% (49 of 89) | 44% (16 of 36) | 50% (1 of 2) | 52% (66 of 127) |
| Monster | 50% (16 of 32) | 80% (8 of 10) | - | 57% (24 of 42) |
| Monstrous | 55% (6 of 11) | 79% (11 of 14) | - | 68% (17 of 25) |
| War Machines | 63% (26 of 41) | 100% (1 of 1) | - | 64% (27 of 42) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 6 | 84% (16 of 19); on the table 89% | 28% (39 of 138) | 47% | 55% (18 of 33) | 100% (9 of 9); 4.0 uses a game | 100% (3 of 3); 1.7 uses a game | 89% (8 of 9); 1.3 uses a game |
| Chaos Dwarfs | 3 | 100% (3 of 3); on the table 100% | 46% (11 of 24) | 26% | 33% (8 of 24) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Dwarfen Mountain Holds | 5 | 100% (9 of 9); on the table 100% | - | 58% | 76% (31 of 41) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 6 | 94% (16 of 17); on the table 94% | 47% (17 of 36) | 54% | 61% (39 of 64) | 0.0 uses a game | 100% (2 of 2); 1.7 uses a game | 25% (1 of 4); 0.2 uses a game |
| Grand Cathay | 5 | 100% (19 of 19); on the table 100% | 21% (23 of 108) | 50% | 34% (15 of 44) | 100% (12 of 12); 6.0 uses a game | 0% (0 of 1); 0.0 uses a game | 40% (2 of 5); 0.4 uses a game |
| High Elf Realms | 6 | 64% (7 of 11); on the table 64% | 13% (4 of 30) | 34% | 53% (26 of 49) | 100% (5 of 5); 3.0 uses a game | 39% (7 of 18); 1.5 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | 100% (7 of 7); on the table 100% | - | 43% | 33% (2 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Lizardmen | 2 | 100% (2 of 2); on the table 100% | - | 28% | 57% (8 of 14) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 3 | 78% (7 of 9); on the table 78% | 42% (5 of 12) | 57% | 86% (18 of 21) | 0% (0 of 3); 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 3 | 100% (7 of 7); on the table 100% | 3% (1 of 36) | 12% | 75% (18 of 24) | 0.0 uses a game | 0.0 uses a game | 67% (2 of 3); 0.7 uses a game |
| Skaven | 4 | 90% (9 of 10); on the table 90% | 60% (18 of 30) | 37% | 50% (17 of 34) | 100% (3 of 3); 1.2 uses a game | 0.0 uses a game | 75% (3 of 4); 0.8 uses a game |
| Tomb Kings of Khemri | 6 | 86% (19 of 22); on the table 86% | 17% (2 of 12) | 36% | 47% (14 of 30) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 8 | 79% (27 of 34); on the table 88% | 41% (22 of 54) | 27% | 64% (32 of 50) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 8 | 84% (27 of 32); on the table 94% | 27% (8 of 30) | 35% | 70% (52 of 74) | 100% (4 of 4); 1.8 uses a game | 0.0 uses a game | 50% (1 of 2); 0.1 uses a game |
| Wood Elf Realms | 6 | 90% (19 of 21); on the table 90% | 37% (11 of 30) | 36% | 53% (35 of 66) | 33% (2 of 6); 1.7 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (jc-opp-1e5408d-p1, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 41% (30) | 47% (34) | 44% (64) |
| ...free all their last turn and able to turn (per game) | 0.42 | 0.53 | 0.94 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.19 | 0.11 | 0.31 |
| ...with the charger already in that arc before they moved (per game) | 0.33 | 0.42 | 0.75 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 1.72 | 0.94 | 2.67 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.94 | 0.86 | 1.81 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 4.75 | 4.61 | 9.36 |

### Quality by phase: jc-opp-1e5408d-p1

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.1 | 3.4 |
| Strategy | Charge objectives carried out (made contact) | 53% (64 of 120) | 45% (73 of 163) |
| Strategy | Shoot objectives carried out (shot that target) | 44% (199 of 455) | 50% (113 of 227) |
| Strategy | Close-in objectives charged next turn | 10% (17 of 174) | 17% (42 of 251) |
| Strategy | Support requests answered (helper made contact too) | 43% (6 of 14) | 43% (21 of 49) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (1 of 1) | 100% (4 of 4) |
| Strategy | Hexes on a unit its side charged or shot that turn | 60% (9 of 15) | 73% (8 of 11) |
| Strategy | Joined characters whose unit fought | 21% (11 of 53) | 33% (13 of 39) |
| Strategy | Lone characters that fought | 74% (69 of 93) | 79% (77 of 97) |
| Movement | Charges halted short of contact | 0.1 | 0.2 |
| Movement | Idle units | 1.1 | 1.7 |
| Movement | Points that never moved of their own | 311.2 | 205.9 |
| Movement | Fights charged into per game | 2.8 | 3.2 |
| Movement | Charges with odds: long shots (under 50%) | 17 of 87, net +86 | 16 of 97, net +14 |
| Movement | Charges with odds: sweet spot (55-75%) | 8 of 87, net +193 | 19 of 97, net +89 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 12 of 87, net +96 | 7 of 97, net +104 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 24 of 87, net +89 | 24 of 97, net +112 |
| Shooting | Shots by shooting units (incl. breath weapons) | 10.4 | 9.1 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 43% (162 of 374) | 43% (141 of 328) |
| Shooting | Points destroyed by shooting units | 76.5 | 34.4 |
| Shooting | War machine shots | 6.1 | 1.5 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 48% (106 of 219) | 40% (22 of 55) |
| Shooting | Points destroyed by war machines | 92.8 | 15.8 |
| Magic | Magic missiles cast | 1.8 | 1.0 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 37% (24 of 65) | 31% (11 of 36) |
| Magic | Wounds caused by magic missiles | 5.4 | 0.9 |
| Magic | Wounds caused by other spells | 1.4 | 0.4 |
| Magic | Points destroyed by magic (all spells) | 85.9 | 17.5 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.5 / 0.4 / 0.6 / 0.3 | 1.6 / 0.4 / 0.3 / 0.1 |
| Combat | Points destroyed in combat | 390.2 | 385.9 |
| Combat | Points run down | 28.1 | 146.7 |
| Combat | Net points per charged fight, damage counted | +79 | +93 |
| Combat | Net per 100 charger points, damage counted | +26.7 | +31.1 |
| Combat | First round won (charged fights) | 68% | 78% |
| Combat | Net points per charged fight | +79 | +90 |
| Combat | Net points per supported fight / lone fight | +103 / +76 | +131 / +77 |
| Combat | Charged fights on a top-3 enemy unit | 39 of 99 | 49 of 116 |
| Game | Points lost | 721.8 | 772.9 |
| Game | VP from objectives | 606.7 | 684.2 |
| Game | Lone holders (player turns) | 2.9 | 2.7 |

- Mine won / drew / lost: 14 / 7 / 15 of 36 ended games (of 36); mean margin (Mine - Opponent) +2 VP
- The side that went first won 13 of 29 games with a winner
- Points traded per game (both sides' losses): 1495
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: jc-opp-1e5408d-p1

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.6 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| ADVANCE WORTH | 4.8 | -157.5 | 188.5 | 85.4 | 4.0 | -151.1 | 111.2 | 70.0 |
| ALREADY CARRIED | 0.0 | +0.0 | 0.0 | 3.6 | - | - | - | - |
| ARRIVAL HUNT | - | - | - | - | 0.0 | +0.2 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.1 | +0.0 | 0.0 | 9.9 | 0.4 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | 0.4 | +0.8 | 0.0 | 20.0 | 0.6 | +3.6 | 0.0 | 22.0 |
| BEST FACING | 0.4 | +14.2 | 0.0 | 5.5 | 0.2 | +6.6 | 0.0 | 29.8 |
| BEST FIRST | 1.0 | +41.8 | 16.0 | 5.7 | 0.9 | +45.4 | 15.2 | 28.4 |
| BEST OVERALL | 0.2 | +7.6 | 0.0 | 10.6 | 0.2 | +8.2 | 0.0 | 0.0 |
| BEST PREY | 0.6 | +36.3 | 14.1 | 22.9 | 0.8 | +35.9 | 15.6 | 24.9 |
| BEST PRIZE | 0.0 | -1.2 | 4.7 | 0.0 | 0.1 | -2.0 | 0.0 | 0.0 |
| BIG CHARACTER SAFETY | 0.1 | +0.8 | 0.0 | 0.0 | 0.2 | -1.0 | 0.0 | 0.0 |
| BLOCKED CHARGE SKIPPED | 0.1 | +0.0 | 4.1 | 0.0 | 0.1 | +0.0 | 0.0 | 4.0 |
| BLOCKED WHEEL | 0.3 | +7.5 | 0.0 | 9.0 | 0.1 | +11.3 | 0.0 | 7.9 |
| BLOWS WHERE AIMED | 0.4 | -41.4 | 32.8 | 6.5 | 0.1 | -4.8 | 28.4 | 0.0 |
| BOMBING RUN | 0.0 | +1.3 | 4.2 | 0.0 | - | - | - | - |
| BOUND ASSAILMENT | 0.0 | +0.0 | 0.0 | 4.2 | - | - | - | - |
| CANNON PLAN MISSED | 0.9 | +0.0 | 101.6 | 12.6 | 0.1 | +0.0 | 3.5 | 3.6 |
| CANNON PLANNED TARGET | 5.0 | +168.1 | 408.4 | 74.2 | 1.4 | +21.7 | 39.7 | 17.9 |
| CANNON SIGHT KEPT | 1.0 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT COUNTER | 0.0 | -0.2 | 0.0 | 0.0 | 0.0 | -1.0 | 0.0 | 0.0 |
| CARRIES OUT SET-UP | 0.1 | +0.0 | 6.5 | 4.2 | 0.1 | -0.3 | 1.5 | 0.0 |
| CAST JOB | 1.1 | +47.3 | 72.8 | 23.5 | 0.8 | +9.9 | 28.5 | 7.0 |
| CASTER AWAY FROM SCREEN | 0.4 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.5 | +61.5 | 35.6 | 21.2 | 0.2 | +5.8 | 1.5 | 4.4 |
| CASTS AFTER FRIENDS | 0.6 | +0.0 | 0.0 | 9.9 | 0.3 | +0.0 | 0.0 | 18.7 |
| CASTS FROM BEHIND | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.0 | +0.6 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | 1.1 | +58.3 | 0.0 | 22.7 | 1.6 | +93.9 | 0.0 | 50.6 |
| CHAFF PASSED | 0.2 | -0.2 | 0.0 | 0.0 | 0.1 | -0.1 | 0.0 | 6.9 |
| CHAMPION TAKES THE CHALLENGE | 0.0 | +0.0 | 0.0 | 0.0 | 0.0 | +0.8 | 8.0 | 0.0 |
| CHARGE NOW FIRST | 2.0 | +0.0 | 210.6 | 71.4 | 2.5 | +0.0 | 220.6 | 97.9 |
| CHARGE NOW WEIGHED | 0.4 | -19.8 | 25.5 | 8.6 | 0.5 | -29.1 | 8.5 | 27.6 |
| CHARGER SLAIN LOST | 0.4 | -22.4 | 31.6 | 15.9 | 0.7 | -28.9 | 81.8 | 28.6 |
| CHARIOT NO STATIC JOB | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHARIOT WIZARD CAREFUL | 0.1 | -6.7 | 9.5 | 0.0 | 0.1 | -1.2 | 0.0 | 0.0 |
| CHEAP HELPER | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| COMBAT PIVOT | 0.4 | +0.0 | 32.2 | 21.8 | 0.3 | +0.0 | 14.7 | 12.6 |
| CONTINUE AHEAD WEIGHED | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | 0.6 | +60.1 | 12.1 | 23.3 | 0.3 | +104.8 | 3.2 | 15.2 |
| COVER ONCE | 7.1 | -549.4 | 0.0 | 156.9 | 5.6 | -389.2 | 0.0 | 138.8 |
| DEFENSIVE ARMY | 0.2 | +0.0 | 26.2 | 8.1 | - | - | - | - |
| DEFENSIVE FLOOR | - | - | - | - | 0.0 | +2.0 | 11.9 | 0.0 |
| EDGE GIVE GROUND | 0.0 | +1.1 | 0.0 | 9.4 | 0.2 | +13.4 | 5.8 | 17.1 |
| ELIXIR WORTH | 0.0 | +0.3 | 0.0 | 8.2 | 0.1 | +2.3 | 0.0 | 0.0 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 1.7 | +130.3 | 0.0 | 21.9 | 0.9 | +52.5 | 0.0 | 40.4 |
| FALLBACK BY WORTH | 3.5 | +50.5 | 0.0 | 64.4 | 5.5 | +65.4 | 0.0 | 65.7 |
| FIGHT LIFT | 0.0 | +0.3 | 0.0 | 0.0 | - | - | - | - |
| FIRE AND FLEE | - | - | - | - | 0.1 | +1.0 | 0.0 | 3.2 |
| FLANK NOT WEIGHED | 4.7 | +0.0 | 0.0 | 143.1 | 4.1 | +0.0 | 0.0 | 114.2 |
| FOCUS FIRE | 0.0 | +2.5 | 0.0 | 0.0 | 0.0 | +0.8 | 0.0 | 0.0 |
| FOLLOW UP WEIGHED | 1.0 | +125.2 | 0.0 | 18.0 | 0.9 | +167.8 | 0.0 | 38.9 |
| FRIEND IN REACH | 3.4 | +70.4 | 351.9 | 96.2 | 5.1 | +180.8 | 427.7 | 143.6 |
| FRIENDS SHOTS CHECKED | 0.3 | +30.6 | 0.0 | 14.0 | 0.2 | +14.3 | 0.0 | 11.0 |
| GIVES UP | 0.0 | -0.1 | 7.0 | 4.0 | 0.1 | -0.7 | 21.9 | 0.0 |
| GIVES UP ITS SCREEN | 0.0 | -0.1 | 3.1 | 0.0 | 0.1 | -1.1 | 6.6 | 1.3 |
| GROUND FLIERS | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |
| HELPER ALREADY ASKED | 0.1 | +0.0 | 16.9 | 3.4 | 0.1 | +0.0 | 5.7 | 2.8 |
| HELPER UNSEEN | 0.2 | +0.0 | 21.4 | 0.0 | 0.9 | +0.0 | 45.7 | 33.2 |
| HILL BY ITS CHANCE | - | - | - | - | 0.1 | -11.8 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.8 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 7.7 | -146.9 | 439.4 | 165.5 | 10.4 | -195.6 | 452.1 | 227.1 |
| HUNT ADVANCE | 0.0 | +0.2 | 0.0 | 0.0 | 0.1 | +6.2 | 0.0 | 6.1 |
| HUNT DROPPED | - | - | - | - | 0.1 | +0.0 | 0.0 | 1.9 |
| HUNT IN PAIRS | 0.3 | +19.0 | 0.0 | 5.4 | 0.6 | +31.1 | 0.0 | 11.4 |
| HUNT RESULT | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 5.2 |
| HUNT THE GUNS | 0.0 | +12.5 | 0.0 | 0.0 | 0.1 | +40.7 | 0.0 | 6.1 |
| IDLE COST | 14.7 | -248.3 | 0.0 | 184.9 | 18.2 | -286.6 | 0.0 | 209.4 |
| INVITES THE FIGHT | 1.4 | +11.4 | 62.8 | 27.9 | 1.1 | +6.5 | 25.2 | 18.4 |
| JOINT CHARGE PLAN | 0.3 | +13.8 | 19.1 | 12.6 | 0.3 | +13.9 | 0.0 | 0.0 |
| JOINT KNOWS CHALLENGE | 0.1 | -0.3 | 11.9 | 0.0 | 0.1 | -2.9 | 17.8 | 0.0 |
| KEEP FALLS | 0.0 | +0.2 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| KEEPS ITS PREY | - | - | - | - | 0.1 | +0.7 | 0.0 | 3.5 |
| KEEPS ITS TARGET | 1.4 | +43.3 | 97.9 | 22.2 | 2.1 | +61.7 | 96.9 | 46.1 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KILLS COUNT | 1.6 | +63.5 | 147.2 | 54.6 | 2.0 | +155.6 | 150.1 | 82.4 |
| KILLS COUNT NEXT TURN | 4.6 | +161.9 | 136.2 | 141.5 | 6.6 | +235.7 | 222.6 | 150.3 |
| LONE CHARACTER SAFE SPOT | 0.5 | +7.1 | 5.2 | 0.0 | 0.4 | +29.1 | 10.9 | 5.0 |
| LONE WIZARD HOLDS BACK | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| LONE WIZARD KEPT IN | 0.7 | +49.1 | 0.0 | 0.0 | 0.2 | +24.5 | 0.0 | 0.0 |
| LONG SHOT | 0.4 | -5.9 | 27.8 | 6.2 | 0.6 | +4.8 | 27.4 | 5.3 |
| LOST CHARGE | 2.8 | -37.2 | 76.8 | 87.8 | 2.6 | -36.9 | 48.9 | 96.7 |
| LURE BY WHAT IT DRAWS | 0.2 | -14.2 | 0.0 | 5.1 | 0.2 | -23.6 | 0.0 | 20.4 |
| MAKE SURE TOGETHER | 0.6 | +45.3 | 8.0 | 14.5 | 1.3 | +93.3 | 2.6 | 43.3 |
| MANOEUVRE | 0.2 | +2.1 | 0.0 | 7.4 | 0.2 | +4.8 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.0 | +0.4 | 0.0 | 0.0 | 0.1 | +2.4 | 0.0 | 0.0 |
| MARCH CHECK | 0.5 | +4.5 | 0.0 | 13.2 | 0.4 | +23.2 | 0.0 | 0.0 |
| MARCH ODDS | 0.2 | +12.0 | 21.8 | 0.0 | 0.2 | +17.6 | 20.4 | 0.0 |
| MARCH OVER CASTS | 0.7 | +66.9 | 0.0 | 15.2 | 0.3 | +31.4 | 0.0 | 13.1 |
| MAX FOR POSITIONING | 5.1 | +84.3 | 0.0 | 121.6 | 6.7 | +89.6 | 0.0 | 150.0 |
| MISSILES IN THE MOVE | 4.4 | +203.8 | 0.0 | 76.9 | 3.4 | +57.8 | 0.0 | 43.1 |
| MISSILES NEXT TURN | 5.0 | +128.9 | 0.0 | 98.8 | 4.1 | +36.7 | 0.0 | 65.7 |
| MODEL FACING | 0.2 | +56.7 | 0.0 | 3.3 | - | - | - | - |
| MONSTER WIZARD ROAMS | 0.1 | +0.0 | 18.9 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| MOVE AND CAST | 0.4 | +15.6 | 0.0 | 2.2 | 0.6 | +20.8 | 0.0 | 18.1 |
| MOVE SPELL IN RANGE | 0.2 | +8.7 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.3 | -70.3 | 0.0 | 26.9 | 0.1 | -0.2 | 0.0 | 0.0 |
| MOVE SPELL SPOT | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 11.1 |
| MOVE TO CHARGE | 3.5 | +312.7 | 111.5 | 94.3 | 5.8 | +345.9 | 152.2 | 152.8 |
| MOVES UNITS SPELL | 0.1 | +3.4 | 0.0 | 0.0 | 0.1 | +1.8 | 0.0 | 0.0 |
| NEEDED THERE | 0.0 | +0.6 | 3.2 | 0.0 | - | - | - | - |
| NO RALLY LEFT | 0.1 | +13.9 | 0.0 | 0.0 | - | - | - | - |
| NOT NEEDED | 0.3 | -10.0 | 44.9 | 4.7 | - | - | - | - |
| NOT TURNED | 4.8 | +89.6 | 0.0 | 159.7 | 4.6 | +42.8 | 0.0 | 116.1 |
| NOT WORTH A CAST | 1.0 | -0.7 | 0.0 | 55.8 | 0.4 | -0.3 | 0.0 | 0.0 |
| OFF BEST | 16.8 | -677.2 | 11.9 | 324.4 | 17.0 | -746.4 | 0.0 | 306.1 |
| ONE FIGHT FORMULA | 7.8 | -143.6 | 43.1 | 198.1 | 8.5 | -170.2 | 15.6 | 268.6 |
| ONE OBJECTIVE FORMULA | 2.4 | -86.8 | 0.0 | 49.2 | 2.1 | -28.7 | 0.0 | 37.1 |
| OPENS A LANE | 0.1 | +1.8 | 1.1 | 0.0 | 0.1 | +0.1 | 9.3 | 0.0 |
| OPENS UP | 0.1 | +6.2 | 10.5 | 0.0 | 0.1 | +7.1 | 6.1 | 7.9 |
| OVERRUN THREAT | 0.0 | +2.3 | 0.0 | 0.0 | - | - | - | - |
| OVERRUNS AWAY | 0.4 | +4.5 | 26.7 | 19.4 | 0.5 | +17.6 | 33.8 | 40.6 |
| PAIR SET-UP | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| PATHS CROSS | 1.9 | +122.4 | 0.0 | 37.7 | 2.6 | +183.0 | 0.0 | 54.9 |
| PERIAPT WORTH | 0.0 | +1.1 | 0.0 | 0.0 | 0.1 | +4.4 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.1 | -1.5 | 0.0 | 15.5 | 0.1 | -1.9 | 0.0 | 7.9 |
| PLAN RESULT | 36.7 | +1569.1 | 1337.7 | 849.1 | 38.2 | +1142.8 | 1320.2 | 988.7 |
| PURSUES BIG PREY | 0.1 | -8.2 | 0.0 | 0.0 | 0.1 | -18.9 | 0.0 | 0.0 |
| PURSUES ON | - | - | - | - | 0.0 | +0.5 | 0.0 | 7.0 |
| RAIDS THE BAGGAGE NEXT TURN | 0.0 | +3.3 | 0.0 | 0.0 | 0.0 | +2.4 | 0.0 | 0.0 |
| RANDOM MOVE BY FIGURES | 0.8 | +8.2 | 0.0 | 22.2 | 1.4 | +19.3 | 0.0 | 36.8 |
| RANDOM MOVER NO PROMISE | 0.1 | -4.8 | 0.0 | 9.4 | 0.2 | -8.7 | 13.1 | 14.2 |
| REDIRECT BY WHAT IT STOPS | 0.8 | -13.9 | 0.0 | 13.8 | 1.1 | -26.7 | 0.0 | 23.1 |
| REDIRECT COUNTER | 1.7 | +96.3 | 0.0 | 39.9 | 3.2 | +263.4 | 0.0 | 51.1 |
| REDIRECT WEIGHED | 0.2 | +0.3 | 7.3 | 1.4 | 0.4 | +6.2 | 10.9 | 1.9 |
| REFUSING RETIRES | 0.2 | +0.0 | 0.0 | 0.0 | 0.5 | +0.0 | 0.0 | 15.7 |
| RESERVE FALL BACK | 0.5 | +17.1 | 0.0 | 3.1 | 0.7 | +23.2 | 0.0 | 12.6 |
| RESTRAINS TO SHOOT | 0.1 | +5.6 | 0.0 | 3.5 | 0.2 | +6.5 | 0.0 | 0.0 |
| RISK BY ARC | 2.1 | +97.5 | 212.0 | 92.9 | 2.7 | +66.9 | 259.0 | 98.2 |
| RISK ONCE | 2.4 | +34.7 | 10.8 | 98.0 | 5.4 | +328.4 | 71.3 | 297.5 |
| SAFER THAN THE JOB | 0.9 | +55.3 | 0.0 | 19.3 | 0.9 | +47.5 | 0.0 | 52.9 |
| SCOUT SPOT | 0.4 | +0.7 | 0.0 | 0.0 | 0.3 | +0.6 | 0.0 | 0.9 |
| SCOUT WAITS | 0.4 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.9 |
| SCREEN BY WHAT IT SAVES | 0.2 | -7.3 | 0.0 | 1.9 | 0.5 | -31.8 | 0.0 | 7.1 |
| SEARCH SPOT | 1.7 | +81.7 | 0.0 | 35.5 | 2.2 | +96.9 | 0.0 | 26.6 |
| SECOND CHARGER ADDS | - | - | - | - | 0.5 | -37.5 | 73.4 | 1.7 |
| SELF MOVE SPELL | 0.2 | +35.8 | 0.0 | 18.1 | 0.2 | -0.2 | 0.0 | 9.1 |
| SET UP TOGETHER | 1.2 | +153.5 | 47.5 | 31.3 | 2.3 | +173.6 | 18.3 | 71.7 |
| SET-UP ANY TARGET | 0.3 | +37.9 | 10.3 | 0.0 | 0.1 | +13.9 | 3.2 | 7.6 |
| SET-UP MISSED | 0.0 | +2.6 | 0.0 | 0.0 | 0.0 | +3.9 | 3.5 | 7.6 |
| SHOOTER COUNTED ONCE | - | - | - | - | 0.1 | -0.2 | 0.0 | 1.7 |
| SHOOTERS IN TWO RANKS | 0.4 | +0.9 | 0.0 | 0.0 | 0.3 | +0.8 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.9 | +78.5 | 169.9 | 14.6 | 1.0 | +16.3 | 37.4 | 16.0 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 3.2 | 0.0 | +0.0 | 0.0 | 0.0 |
| SHOT REPLANNED | 0.7 | +0.0 | 136.1 | 17.2 | 0.1 | +0.0 | 13.9 | 5.1 |
| SHOTS IN THE MOVE | 14.5 | +609.7 | 0.0 | 223.2 | 8.8 | +175.3 | 0.0 | 123.2 |
| SPELL CATCH ODDS | 0.0 | -0.1 | 1.8 | 0.0 | - | - | - | - |
| SPELL SETS UP CHARGE | 0.4 | +60.2 | 12.1 | 0.0 | 0.2 | +68.8 | 3.2 | 7.6 |
| SPELL WORTH | 1.2 | +16.2 | 23.9 | 41.9 | 1.7 | +40.5 | 48.3 | 61.3 |
| SPELLS IN THE FIGHT | 0.5 | +3.6 | 55.2 | 44.1 | 0.6 | -16.1 | 56.5 | 23.4 |
| STABLE ROLE | 10.2 | +0.0 | 382.7 | 175.8 | 11.1 | +0.0 | 344.1 | 215.2 |
| STANDS TO CAST | 0.0 | +1.0 | 0.0 | 10.9 | 0.0 | +1.0 | 7.0 | 0.0 |
| STAY WEIGHED | 0.0 | +0.1 | 0.0 | 0.0 | - | - | - | - |
| STOPS SHORT OF THE FLANK | 0.3 | +19.5 | 0.0 | 11.1 | 0.4 | +12.9 | 0.0 | 17.4 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| SUPPORT NARROWED | 4.3 | -44.5 | 289.6 | 100.3 | 7.3 | -64.1 | 369.5 | 97.8 |
| SUPPORTS | 3.0 | +46.7 | 122.8 | 51.4 | 5.0 | +65.4 | 214.9 | 42.8 |
| SURE CHARGE BEATS ADVANCE | 0.1 | -1.4 | 0.0 | 0.0 | 0.0 | -0.8 | 0.0 | 0.0 |
| SURE REACH TOGETHER | 0.6 | -13.0 | 19.1 | 21.8 | 0.8 | -2.1 | 17.0 | 37.4 |
| THROUGH LINE OF FIRE | 0.4 | +17.4 | 0.0 | 0.0 | 0.2 | +10.2 | 0.0 | 3.5 |
| TURN WORTH | 0.2 | -12.4 | 18.5 | 1.4 | 0.1 | -12.9 | 8.0 | 0.0 |
| TWO OR MORE ARRIVE | 0.2 | +1.8 | 8.0 | 3.2 | 0.7 | +4.2 | 9.3 | 10.8 |
| WAIT AFTER COSTS | 7.0 | -358.1 | 276.3 | 163.4 | 8.9 | -444.0 | 255.9 | 201.2 |
| WALKS TO THE FIGHT | 1.8 | +15.9 | 68.4 | 34.3 | 0.9 | +8.4 | 35.7 | 4.9 |
| WAR ENGINE CHARGES | 0.1 | +9.3 | 10.7 | 0.0 | - | - | - | - |
| WAR ENGINE JOBS | 0.6 | +0.0 | 42.1 | 10.6 | 0.3 | +0.0 | 9.9 | 10.3 |
| WEARS DOWN | 0.9 | +53.0 | 110.5 | 22.3 | 1.3 | +44.3 | 123.9 | 22.1 |
| WHO HITS BACK | 0.1 | +3.6 | 0.0 | 0.0 | 0.2 | +13.9 | 0.0 | 16.5 |
| WHOLE FIGHT | 0.2 | +2.5 | 16.6 | 0.0 | 0.3 | +8.9 | 45.1 | 1.2 |
| WHOLE FIGHT GAIN | 0.3 | +27.6 | 48.5 | 25.1 | 1.4 | +104.8 | 146.6 | 25.5 |
| WIDER SPREAD | 2.4 | -7.7 | 269.0 | 73.7 | 3.2 | -11.3 | 282.6 | 103.5 |
| WOUNDED STAYS OUT | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |

### Rule changes: jc-opp-1e5408d-p1

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 1216 | 1216 | 1216 | 33.78 | -51252 | -42.1 |
| MOVE TO CHARGE | 334 | 334 | 175 | 4.86 | +8219 | +47.0 |
| PATHS CROSS | 164 | 164 | 164 | 4.56 | +10993 | +67.0 |
| KILLS COUNT NEXT TURN | 402 | 402 | 139 | 3.86 | +4099 | +29.5 |
| SEARCH SPOT | 138 | 138 | 136 | 3.78 | +6428 | +47.3 |
| SUPPORTS | 286 | 286 | 131 | 3.64 | +1477 | +11.3 |
| WAIT AFTER COSTS | 571 | 571 | 111 | 3.08 | +2327 | +21.0 |
| FACES THE THREAT | 96 | 96 | 96 | 2.67 | +6583 | +68.6 |
| COVER ONCE | 458 | 241 | 75 | 2.08 | +1007 | +13.4 |
| FALLBACK BY WORTH | 324 | 324 | 75 | 2.08 | +4171 | +55.6 |
| BEST FIRST | 70 | 70 | 70 | 1.94 | +3139 | +44.8 |
| FOLLOW UP WEIGHED | 70 | 70 | 70 | 1.94 | +10545 | +150.6 |
| RISK ONCE | 281 | 207 | 70 | 1.94 | +2461 | +35.2 |
| SHOTS IN THE MOVE | 836 | 572 | 68 | 1.89 | +1773 | +26.1 |
| ONE FIGHT FORMULA | 585 | 356 | 67 | 1.86 | +184 | +2.7 |
| CHAFF IN THE MOVE | 97 | 95 | 66 | 1.83 | +2397 | +36.3 |
| SAFER THAN THE JOB | 65 | 65 | 65 | 1.81 | +3699 | +56.9 |
| ADVANCE WORTH | 315 | 315 | 60 | 1.67 | +1119 | +18.7 |
| SET UP TOGETHER | 126 | 112 | 59 | 1.64 | +3836 | +65.0 |
| CANNON PLANNED TARGET | 230 | 230 | 57 | 1.58 | -101 | -1.8 |
| ARTILLERY RE-ROLL WEIGHED | 52 | 52 | 52 | 1.44 | +0 | +0.0 |
| MISSILES IN THE MOVE | 282 | 172 | 52 | 1.44 | +2202 | +42.3 |
| CANNON SIGHT KEPT | 51 | 51 | 51 | 1.42 | +0 | +0.0 |
| ADVANCE LANE KEPT | 46 | 46 | 46 | 1.28 | +0 | +0.0 |
| SHOOTS FROM THE BEST SPOT | 104 | 104 | 45 | 1.25 | +1343 | +29.8 |
| HOLDS AMBUSHERS | 44 | 44 | 44 | 1.22 | +0 | +0.0 |
| REDIRECT COUNTER | 176 | 87 | 43 | 1.19 | +3226 | +75.0 |
| RESERVE FALL BACK | 43 | 43 | 43 | 1.19 | +1450 | +33.7 |
| INVITES THE FIGHT | 89 | 89 | 42 | 1.17 | +238 | +5.7 |
| RISK BY ARC | 172 | 168 | 41 | 1.14 | +1696 | +41.4 |
| WALKS TO THE FIGHT | 99 | 99 | 41 | 1.14 | +284 | +6.9 |
| KILLS COUNT | 128 | 126 | 40 | 1.11 | +2372 | +59.3 |
| RANDOM MOVE BY FIGURES | 77 | 77 | 40 | 1.11 | +989 | +24.7 |
| LONE WIZARD KEPT IN | 34 | 34 | 34 | 0.94 | +2648 | +77.9 |
| CAST JOB | 68 | 68 | 33 | 0.92 | +782 | +23.7 |
| HONEST WORTH | 652 | 649 | 33 | 0.92 | +310 | +9.4 |
| MOVE AND CAST | 33 | 33 | 33 | 0.92 | +1311 | +39.7 |
| CHARGE NOW WEIGHED | 32 | 32 | 32 | 0.89 | +1890 | +59.1 |
| IDLE COST | 1185 | 652 | 30 | 0.83 | +292 | +9.7 |
| MARCH CHECK | 32 | 30 | 30 | 0.83 | +1890 | +63.0 |
| SHOT REPLANNED | 30 | 30 | 30 | 0.83 | +0 | +0.0 |
| CHARGE NOW FIRST | 162 | 162 | 29 | 0.81 | -1391 | -48.0 |
| MAX FOR POSITIONING | 425 | 262 | 29 | 0.81 | +122 | +4.2 |
| STOPS SHORT OF THE FLANK | 27 | 27 | 27 | 0.75 | +1166 | +43.2 |
| CASTER AWAY FROM SCREEN | 26 | 26 | 26 | 0.72 | +0 | +0.0 |
| COMBAT PIVOT | 26 | 26 | 26 | 0.72 | +0 | +0.0 |
| SCOUT WAITS | 26 | 26 | 26 | 0.72 | +0 | +0.0 |
| MAKE SURE TOGETHER | 70 | 52 | 24 | 0.67 | +1588 | +66.2 |
| SHOOTERS IN TWO RANKS | 24 | 24 | 24 | 0.67 | +58 | +2.4 |
| THROUGH LINE OF FIRE | 24 | 24 | 24 | 0.67 | +996 | +41.5 |
| REDIRECT WEIGHED | 23 | 23 | 23 | 0.64 | +298 | +13.0 |
| WHOLE FIGHT GAIN | 62 | 61 | 22 | 0.61 | +1387 | +63.0 |
| BEST FACING | 21 | 21 | 21 | 0.58 | +748 | +35.6 |
| FRIENDS SHOTS CHECKED | 20 | 20 | 20 | 0.56 | +1615 | +80.8 |
| CASTING BLOCK | 26 | 26 | 19 | 0.53 | +1361 | +71.6 |
| KEEPS ITS TARGET | 126 | 126 | 17 | 0.47 | +338 | +19.9 |
| BEST OVERALL | 16 | 16 | 16 | 0.44 | +567 | +35.4 |
| BLOCKED WHEEL | 16 | 16 | 16 | 0.44 | +676 | +42.3 |
| BEST PREY | 47 | 47 | 15 | 0.42 | +736 | +49.0 |
| MARCH ODDS | 15 | 15 | 15 | 0.42 | +132 | +8.8 |
| CASTS FROM BEHIND | 14 | 14 | 14 | 0.39 | +0 | +0.0 |
| WAR ENGINE JOBS | 33 | 33 | 14 | 0.39 | -610 | -43.6 |
| MANOEUVRE | 16 | 16 | 13 | 0.36 | +249 | +19.2 |
| MISSILES NEXT TURN | 327 | 188 | 11 | 0.31 | +45 | +4.1 |
| WEARS DOWN | 78 | 78 | 11 | 0.31 | +357 | +32.4 |
| WHO HITS BACK | 11 | 11 | 11 | 0.31 | +282 | +25.7 |
| CHAFF PASSED | 10 | 10 | 10 | 0.28 | -10 | -1.0 |
| LOST CHARGE | 194 | 194 | 10 | 0.28 | +529 | +52.9 |
| REFUSING RETIRES | 24 | 24 | 10 | 0.28 | -3 | -0.3 |
| RESTRAINS TO SHOOT | 10 | 10 | 10 | 0.28 | +436 | +43.6 |
| STUCK PIVOT | 10 | 10 | 10 | 0.28 | +0 | +0.0 |
| BIG CHARACTER SAFETY | 9 | 9 | 9 | 0.25 | -6 | -0.6 |
| MODEL FACING | 9 | 9 | 9 | 0.25 | +2042 | +226.9 |
| PURSUES BIG PREY | 8 | 8 | 8 | 0.22 | -975 | -121.9 |
| SHORT GUN FORWARD | 8 | 8 | 8 | 0.22 | +0 | +0.0 |
| SUPPORT NARROWED | 419 | 419 | 8 | 0.22 | -101 | -12.6 |
| MOVES UNITS SPELL | 7 | 7 | 7 | 0.19 | +186 | +26.5 |
| BLOCKED CHARGE SKIPPED | 6 | 6 | 6 | 0.17 | +0 | +0.0 |
| PIVOT GUARDS FLANK | 6 | 6 | 6 | 0.17 | -123 | -20.6 |
| WHOLE FIGHT | 20 | 19 | 6 | 0.17 | +559 | +93.2 |
| HUNT IN PAIRS | 34 | 19 | 5 | 0.14 | +231 | +46.3 |
| ONE OBJECTIVE FORMULA | 162 | 71 | 5 | 0.14 | +261 | +52.2 |
| OPENS UP | 10 | 10 | 5 | 0.14 | +111 | +22.2 |
| OVERRUNS AWAY | 34 | 34 | 4 | 0.11 | +68 | +17.0 |
| SURE REACH TOGETHER | 50 | 43 | 4 | 0.11 | +6 | +1.5 |
| BACKUP TARGETS | 36 | 18 | 3 | 0.08 | -0 | -0.0 |
| BEST PRIZE | 3 | 3 | 3 | 0.08 | -144 | -48.2 |
| CONTINUE AHEAD WEIGHED | 3 | 3 | 3 | 0.08 | +0 | +0.0 |
| ELIXIR WORTH | 3 | 3 | 3 | 0.08 | +95 | +31.8 |
| HUNT ADVANCE | 6 | 6 | 3 | 0.08 | +75 | +25.1 |
| PERIAPT WORTH | 3 | 3 | 3 | 0.08 | +198 | +65.9 |
| SPELLS IN THE FIGHT | 37 | 34 | 3 | 0.08 | +15 | +4.9 |
| SURE CHARGE BEATS ADVANCE | 3 | 3 | 3 | 0.08 | -77 | -25.8 |
| WIDER SPREAD | 201 | 195 | 3 | 0.08 | +13 | +4.2 |
| CARRIES OUT COUNTER | 2 | 2 | 2 | 0.06 | -44 | -22.1 |
| FIRE AND FLEE | 2 | 2 | 2 | 0.06 | +36 | +17.9 |
| FOCUS FIRE | 2 | 2 | 2 | 0.06 | +116 | +57.8 |
| JOINT CHARGE PLAN | 20 | 20 | 2 | 0.06 | +152 | +76.2 |
| KEEP FALLS | 2 | 2 | 2 | 0.06 | +9 | +4.6 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| NO RALLY LEFT | 2 | 2 | 2 | 0.06 | +356 | +177.9 |
| RAIDS THE BAGGAGE NEXT TURN | 2 | 2 | 2 | 0.06 | +91 | +45.3 |
| STANDS TO CAST | 2 | 2 | 2 | 0.06 | +5 | +2.3 |
| WAR ENGINE CHARGES | 3 | 3 | 2 | 0.06 | +226 | +113.1 |
| BLOWS WHERE AIMED | 19 | 18 | 1 | 0.03 | +457 | +457.2 |
| BOMBING RUN | 1 | 1 | 1 | 0.03 | +47 | +47.0 |
| BOUND ASSAILMENT | 1 | 1 | 1 | 0.03 | +0 | +0.1 |
| CARRIES OUT SET-UP | 7 | 7 | 1 | 0.03 | -12 | -11.8 |
| CHARGER SLAIN LOST | 38 | 37 | 1 | 0.03 | +9 | +9.1 |
| DEFENSIVE ARMY | 6 | 6 | 1 | 0.03 | -17 | -17.2 |
| EDGE GIVE GROUND | 8 | 8 | 1 | 0.03 | +16 | +16.1 |
| LONG SHOT | 34 | 32 | 1 | 0.03 | -58 | -58.0 |
| MOVE SPELL IN RANGE | 8 | 5 | 1 | 0.03 | +28 | +28.2 |
| NEEDED THERE | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| PURSUES ON | 1 | 1 | 1 | 0.03 | +16 | +16.4 |
| REDIRECT BY WHAT IT STOPS | 65 | 65 | 1 | 0.03 | +32 | +32.5 |
| STAY WEIGHED | 1 | 1 | 1 | 0.03 | +3 | +3.0 |
| TWO OR MORE ARRIVE | 33 | 27 | 1 | 0.03 | +12 | +12.3 |
| WOUNDED STAYS OUT | 1 | 1 | 1 | 0.03 | -20 | -20.3 |
| ALREADY CARRIED | 1 | not checked | - | - | - | - |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 36 | 36 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 35 | trace | - | - | - | - |
| CATCH FLIERS | 1 | not checked | - | - | - | - |
| CHAMPION TAKES THE CHALLENGE | 2 | 2 | 0 | 0.00 | - | - |
| CHARIOT NO STATIC JOB | 1 | 1 | 0 | 0.00 | - | - |
| CHARIOT WIZARD CAREFUL | 6 | 6 | 0 | 0.00 | - | - |
| CHEAP HELPER | 2 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 33 | not checked | - | - | - | - |
| DEFENSIVE FLOOR | 1 | 1 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 2 | 2 | 0 | 0.00 | - | - |
| FIGHT LIFT | 1 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 319 | not checked | - | - | - | - |
| FRIEND IN REACH | 305 | not checked | - | - | - | - |
| GIVES UP | 6 | 6 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 3 | 3 | 0 | 0.00 | - | - |
| GROUND FLIERS | 1 | not checked | - | - | - | - |
| HELPER ALREADY ASKED | 6 | not checked | - | - | - | - |
| HELPER UNSEEN | 37 | 37 | 0 | 0.00 | - | - |
| HILL BY ITS CHANCE | 4 | 4 | 0 | 0.00 | - | - |
| HUNT DROPPED | 3 | trace | - | - | - | - |
| HUNT RESULT | 6 | trace | - | - | - | - |
| HUNT THE GUNS | 6 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 6 | 5 | 0 | 0.00 | - | - |
| KEEPS ITS PREY | 4 | 4 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 33 | not checked | - | - | - | - |
| LONE WIZARD HOLDS BACK | 14 | 14 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 14 | 14 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 4 | trace | - | - | - | - |
| MARCH OVER CASTS | 37 | 37 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 8 | 8 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 14 | trace | - | - | - | - |
| MOVE SPELL SPOT | 8 | not checked | - | - | - | - |
| NOT NEEDED | 11 | 11 | 0 | 0.00 | - | - |
| NOT TURNED | 337 | 337 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 49 | not checked | - | - | - | - |
| OPENS A LANE | 6 | 4 | 0 | 0.00 | - | - |
| OVERRUN THREAT | 1 | not checked | - | - | - | - |
| PAIR SET-UP | 4 | not checked | - | - | - | - |
| PLAN RESULT | 2695 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 11 | 11 | 0 | 0.00 | - | - |
| SCOUT SPOT | 23 | 23 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 25 | 25 | 0 | 0.00 | - | - |
| SECOND CHARGER ADDS | 18 | 18 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 14 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 15 | not checked | - | - | - | - |
| SET-UP MISSED | 2 | trace | - | - | - | - |
| SHOOTER COUNTED ONCE | 4 | 4 | 0 | 0.00 | - | - |
| SPELL CATCH ODDS | 1 | not checked | - | - | - | - |
| SPELL SETS UP CHARGE | 21 | not checked | - | - | - | - |
| SPELL WORTH | 106 | not checked | - | - | - | - |
| STABLE ROLE | 769 | 767 | 0 | 0.00 | - | - |
| TURN WORTH | 12 | 12 | 0 | 0.00 | - | - |

### Off best figure: jc-opp-1e5408d-p1

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 15.33 | 15.00 | 42.8 |
| FALLBACK | gate | 0.33 | 1.03 | 40.0 |
| TURN GATE | gate | 0.47 | 0.50 | 22.2 |
| CHARGE NOW FIRST | rule | 0.42 | 0.36 | 49.7 |
| WAR ENGINE JOBS | rule | 0.36 | 0.03 | 43.6 |
| AFTERMATH BAND | gate | 0.17 | 0.11 | 2.0 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.14 | 0.14 | 117.6 |
| CANNON PLANNED TARGET | rule | 0.25 | 0.03 | 26.4 |
| FIGHT ORDER BAND | gate | 0.14 | 0.14 | 2.2 |
| PURSUES BIG PREY | rule | 0.08 | 0.14 | 121.9 |
| SUPPORT NARROWED | rule | 0.11 | 0.11 | 12.6 |
| CHARGE NOW WEIGHED | rule | 0.08 | 0.08 | 24.2 |
| PIVOT GUARDS FLANK | rule | 0.11 | 0.06 | 20.6 |
| PATHS CROSS | rule | 0.06 | 0.06 | 10.1 |
| SUPPORT REQUEST | gate | 0.11 | - | 111.5 |
| BEST PRIZE | rule | 0.03 | 0.06 | 48.2 |
| BIG CHARACTER SAFETY | rule | - | 0.08 | 15.3 |
| CHAFF PASSED | rule | 0.03 | 0.06 | 3.3 |
| FRIENDS SHOTS CHECKED | rule | 0.06 | 0.03 | 1.6 |
| LONE CHARACTER SAFE SPOT | gate | 0.03 | 0.06 | 12.9 |
| MARCH ODDS | rule | 0.08 | - | 2.4 |
| SAFER THAN THE JOB | rule | - | 0.08 | 15.3 |
| SURE CHARGE BEATS ADVANCE | rule | 0.06 | 0.03 | 25.8 |
| CARRIES OUT COUNTER | rule | 0.03 | 0.03 | 22.1 |
| NO REASON | gate | - | 0.06 | 14.4 |
| CARRIES OUT SET-UP | rule | - | 0.03 | 11.8 |
| DEFENSIVE ARMY | rule | 0.03 | - | 17.2 |
| FOLLOW UP WEIGHED | rule | 0.03 | - | 3.8 |
| LONG SHOT | rule | - | 0.03 | 58.0 |
| REDIRECT WEIGHED | rule | 0.03 | - | 72.0 |
| REFUSING RETIRES | rule | 0.03 | - | 0.7 |
| RULE SWITCHED OFF | gate | 0.03 | - | 37.2 |
| WOUNDED STAYS OUT | rule | - | 0.03 | 20.3 |

### Plans: jc-opp-1e5408d-p1

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 9.1 | 19% | 186 | 265 | 142% |
| Mine | charge | 2.6 | 62% | 237 | 254 | 107% |
| Mine | close in | 4.8 | 25% | 341 | 190 | 56% |
| Mine | hold | 5.2 | 38% | 299 | 0 | 0% |
| Mine | join | 0.7 | 100% | 19 | 0 | 0% |
| Mine | shoot | 10.3 | 62% | 449 | 859 | 191% |
| Mine | support | 3.9 | 85% | 41 | 0 | 0% |
| Opponent | advance | 9.7 | 16% | 127 | 253 | 200% |
| Opponent | charge | 4.2 | 68% | 346 | 430 | 124% |
| Opponent | close in | 6.9 | 25% | 420 | 146 | 35% |
| Opponent | hold | 4.7 | 46% | 319 | 0 | 0% |
| Opponent | join | 1.1 | 98% | 59 | 0 | 0% |
| Opponent | shoot | 5.2 | 63% | 99 | 316 | 320% |
| Opponent | support | 6.4 | 90% | 67 | 0 | 0% |

### Packages: hunt the guns, jc-opp-1e5408d-p1

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.0 | 1 | 0 | 0% | 0% | 0% | - | 450 | 0 | 0% | 13 |
| Opponent | 0.1 | 5 | 0 | 0% | 0% | 0% | - | 293 | 0 | 0% | 97 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Dwarfen Mountain Holds | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 450 | 0 | 0% | 97 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 28 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 120 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 175 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 179 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 36 |
| Tomb Kings of Khemri | 0.3 | 2 | 0 | 0% | 0% | 0% | - | 292 | 0 | 0% | 56 |
| Vampire Counts | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 48 |
| Warriors of Chaos | 0.2 | 2 | 0 | 0% | 0% | 0% | - | 277 | 0 | 0% | 76 |
| Wood Elf Realms | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 329 | 0 | 0% | 41 |

### Battle groups: jc-opp-1e5408d-p1

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 1.7 | 36% | 64% | 5% | 0% | 14% | 0% | 5% | 81% | 0% |
| Opponent | REDIRECT COUNTER | 3.2 | 23% | 63% | 19% | 40% | 32% | 0% | 9% | 45% | 14% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: jc-opp-1e5408d-p1

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 3 | 0 (3) | 0 | 0 | 37 | 67% | 3.0 | 0 (1) | 0 (2) | - | - | 0 (3) |
| Mine | Chaff | 37 | 17 (37) | 0 | 17 | 50 | 38% | 2.5 | 9 (16) | 5 (9) | 34 (12) | 23 (24) | 6 (13) |
| Mine | Character | 123 | 57 (123) | 57 | 0 | 31 | 21% | 2.3 | 78 (34) | 56 (57) | 30 (12) | 75 (56) | 48 (47) |
| Mine | Clean-up | 24 | 47 (24) | 19 | 28 | 43 | 38% | 2.7 | 66 (9) | 34 (11) | 8 (4) | 86 (14) | 2 (10) |
| Mine | Fast | 4 | 30 (4) | 30 | 0 | 47 | 0% | 1.5 | 57 (1) | 0 (2) | 0 (1) | 30 (4) | - |
| Mine | Fast Hammer | 41 | 35 (41) | 19 | 16 | 57 | 24% | 2.9 | 40 (18) | 38 (12) | 23 (11) | 41 (28) | 25 (13) |
| Mine | Fragile | 5 | 0 (5) | 0 | 0 | 60 | 0% | 1.8 | - | 0 (4) | 0 (1) | 0 (1) | 0 (4) |
| Mine | Hammer | 58 | 39 (58) | 23 | 16 | 45 | 17% | 2.5 | 40 (10) | 39 (38) | 40 (10) | 52 (34) | 24 (24) |
| Mine | Holder | 25 | 83 (25) | 12 | 71 | 25 | 36% | 3.4 | 77 (6) | 72 (15) | 178 (3) | 114 (9) | 67 (15) |
| Mine | Shooter | 44 | 100 (44) | 35 | 65 | 40 | 2% | 2.0 | 30 (6) | 123 (31) | 86 (7) | 150 (25) | 36 (19) |
| Mine | Support | 5 | 0 (5) | 0 | 0 | 58 | 0% | 3.6 | - | 0 (2) | - | 0 (2) | - |
| Mine | War machine | 56 | 53 (56) | 53 | 0 | 39 | 5% | 1.2 | 74 (13) | 44 (37) | 65 (6) | 35 (11) | 58 (45) |
| Mine | Wizard | 23 | 3 (23) | 3 | 0 | 32 | 17% | 2.8 | 0 (6) | 0 (11) | 23 (3) | 0 (4) | 5 (16) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 100 | 0% | 4.0 | 0 (1) | - | - | - | 0 (1) |
| Opponent | Chaff | 66 | 66 (66) | 25 | 42 | 45 | 42% | 2.6 | 91 (28) | 31 (16) | 65 (22) | 81 (48) | 26 (18) |
| Opponent | Character | 114 | 48 (114) | 48 | 0 | 35 | 23% | 2.4 | 46 (40) | 59 (55) | 5 (5) | 49 (67) | 57 (33) |
| Opponent | Clean-up | 16 | 29 (16) | 29 | 0 | 63 | 44% | 2.6 | 6 (5) | 45 (8) | 37 (3) | 19 (8) | 37 (8) |
| Opponent | Early | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Fast Hammer | 58 | 41 (58) | 21 | 20 | 48 | 28% | 2.6 | 42 (25) | 28 (19) | 57 (14) | 43 (42) | 36 (16) |
| Opponent | Fragile | 10 | 0 (10) | 0 | 0 | 24 | 30% | 2.1 | 0 (3) | 0 (4) | 0 (3) | 0 (10) | - |
| Opponent | Hammer | 65 | 44 (65) | 39 | 6 | 51 | 25% | 2.7 | 50 (16) | 45 (42) | 16 (7) | 33 (40) | 67 (25) |
| Opponent | Holder | 40 | 77 (40) | 12 | 65 | 27 | 48% | 3.2 | 71 (8) | 103 (21) | 33 (9) | 129 (17) | 45 (21) |
| Opponent | Shooter | 30 | 71 (30) | 22 | 50 | 30 | 3% | 1.3 | 27 (7) | 84 (18) | 82 (5) | 77 (16) | 64 (14) |
| Opponent | Support | 2 | 0 (2) | 0 | 0 | 0 | 100% | - | 0 (2) | - | - | - | 0 (2) |
| Opponent | War machine | 13 | 33 (13) | 33 | 0 | 45 | 0% | 1.2 | 0 (5) | 41 (5) | 77 (3) | 58 (3) | 26 (10) |
| Opponent | Wizard | 22 | 5 (22) | 5 | 0 | 50 | 9% | 2.2 | 11 (10) | 0 (4) | 0 (3) | 11 (8) | 0 (9) |

### Charged fights: jc-opp-1e5408d-p1

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 5 | 310 | 22 | 1.2 | 1.0 | 18 | 137 | -118 | 0 of 6 | 3 of 6 | - | -118 |
| Mine | Chaos Dwarfs | 3 | 371 | 760 | 3.7 | 1.3 | 207 | 8 | +199 | 6 of 11 | 8 of 11 | +250 | +188 |
| Mine | Dwarfen Mountain Holds | 4 | 254 | 53 | 1.8 | 1.3 | 30 | 17 | +13 | 2 of 7 | 5 of 7 | -60 | +42 |
| Mine | Empire of Man | 5 | 306 | 179 | 2.2 | 1.0 | 81 | 51 | +31 | 4 of 11 | 9 of 11 | - | +31 |
| Mine | Grand Cathay | 4 | 726 | 289 | 2.5 | 1.2 | 116 | 23 | +92 | 7 of 10 | 6 of 10 | +266 | +49 |
| Mine | High Elf Realms | 4 | 184 | 676 | 4.5 | 1.3 | 150 | 66 | +84 | 7 of 18 | 11 of 18 | +25 | +102 |
| Mine | Kingdom of Bretonnia | 1 | 0 | 710 | 6.0 | 1.0 | 118 | 0 | +118 | 3 of 6 | 6 of 6 | - | +118 |
| Mine | Lizardmen | 1 | 70 | 196 | 4.0 | 1.0 | 49 | 79 | -30 | 1 of 4 | 3 of 4 | - | -30 |
| Mine | Ogre Kingdoms | 1 | 265 | 0 | 3.0 | 1.0 | 0 | 41 | -41 | 2 of 3 | 0 of 3 | - | -41 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 0 | 2.0 | 1.0 | 0 | 55 | -55 | 2 of 2 | 0 of 2 | - | -55 |
| Mine | Skaven | 2 | 0 | 242 | 1.5 | 1.0 | 162 | 0 | +162 | 1 of 3 | 3 of 3 | - | +162 |
| Mine | Tomb Kings of Khemri | 2 | 0 | 1180 | 4.5 | 1.2 | 262 | 22 | +241 | 2 of 9 | 7 of 9 | +114 | +277 |
| Mine | Vampire Counts | 2 | 0 | 206 | 3.5 | 1.0 | 59 | 0 | +59 | 2 of 7 | 5 of 7 | - | +59 |
| Mine | Warriors of Chaos | 1 | 0 | 91 | 2.0 | 1.0 | 46 | 15 | +30 | 0 of 2 | 1 of 2 | - | +30 |
| **Mine** | all armies | 36 | 255 | 323 | 2.8 | 1.1 | 117 | 38 | +79 | 39 of 99 | 67 of 99 | +103 | +76 |
| Opponent | Beastmen Brayherds | 1 | 0 | 337 | 5.0 | 1.0 | 67 | 23 | +44 | 1 of 5 | 5 of 5 | - | +44 |
| Opponent | Dwarfen Mountain Holds | 1 | 0 | 112 | 2.0 | 1.0 | 56 | 0 | +56 | 0 of 2 | 1 of 2 | - | +56 |
| Opponent | Empire of Man | 1 | 255 | 0 | 2.0 | 1.0 | 0 | 132 | -132 | 1 of 2 | 1 of 2 | - | -132 |
| Opponent | Grand Cathay | 1 | 295 | 1019 | 7.0 | 1.3 | 146 | 0 | +146 | 4 of 7 | 6 of 7 | +306 | +81 |
| Opponent | High Elf Realms | 2 | 114 | 195 | 1.5 | 1.3 | 130 | 0 | +130 | 0 of 3 | 2 of 3 | +0 | +195 |
| Opponent | Lizardmen | 1 | 0 | 618 | 4.0 | 1.0 | 154 | 35 | +119 | 4 of 4 | 2 of 4 | - | +119 |
| Opponent | Ogre Kingdoms | 2 | 68 | 48 | 4.0 | 1.2 | 12 | 20 | -9 | 1 of 8 | 4 of 8 | -2 | -11 |
| Opponent | Orc & Goblin Tribes | 2 | 0 | 889 | 4.0 | 1.2 | 222 | 26 | +196 | 3 of 8 | 8 of 8 | +337 | +149 |
| Opponent | Skaven | 2 | 84 | 0 | 0.5 | 1.0 | 0 | 0 | +0 | 0 of 1 | 1 of 1 | - | +0 |
| Opponent | Tomb Kings of Khemri | 4 | 115 | 902 | 4.5 | 1.3 | 200 | 41 | +160 | 7 of 18 | 15 of 18 | +156 | +161 |
| Opponent | Vampire Counts | 6 | 9 | 359 | 4.0 | 1.4 | 90 | 71 | +19 | 12 of 24 | 19 of 24 | +29 | +13 |
| Opponent | Warriors of Chaos | 7 | 0 | 312 | 1.6 | 1.0 | 198 | 0 | +198 | 8 of 11 | 9 of 11 | - | +198 |
| Opponent | Wood Elf Realms | 6 | 140 | 408 | 3.8 | 1.3 | 106 | 43 | +63 | 8 of 23 | 17 of 23 | +196 | +16 |
| **Opponent** | all armies | 36 | 68 | 409 | 3.2 | 1.2 | 127 | 37 | +90 | 49 of 116 | 90 of 116 | +131 | +77 |

### Effective charges: jc-opp-1e5408d-p1

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 6 | 1 (net +0) | 0 | 0 | 0 | 0 | 4 (net +28) | 1 | 0% (0 of 5) |
| Mine | Chaos Dwarfs | 11 | 1 (net +506) | 0 | 0 | 5 (net +167) | 1 (net +406) | 3 (net +147) | 1 | 0% (0 of 10) |
| Mine | Dwarfen Mountain Holds | 7 | 4 (net -30) | 0 | 0 | 2 (net +76) | 0 | 1 (net +60) | 0 | 0% (0 of 7) |
| Mine | Empire of Man | 11 | 1 (net +0) | 0 | 0 | 3 (net +142) | 2 (net +35) | 5 (net -32) | 0 | 0% (0 of 11) |
| Mine | Grand Cathay | 10 | 2 (net -116) | 0 | 1 (net +470) | 3 (net +67) | 0 | 3 (net +131) | 1 | 11% (1 of 9) |
| Mine | High Elf Realms | 18 | 3 (net +444) | 1 (net +0) | 4 (net -28) | 4 (net -49) | 2 (net +58) | 2 (net +190) | 2 | 25% (4 of 16) |
| Mine | Kingdom of Bretonnia | 6 | 1 (net +0) | 1 (net +0) | 1 (net +85) | 1 (net +580) | 1 (net +45) | 1 (net +0) | 0 | 17% (1 of 6) |
| Mine | Lizardmen | 4 | 0 | 0 | 0 | 1 (net -105) | 2 (net +63) | 0 | 1 | 0% (0 of 3) |
| Mine | Skaven | 3 | 0 | 0 | 0 | 1 (net +186) | 0 | 2 (net +150) | 0 | 0% (0 of 3) |
| Mine | Tomb Kings of Khemri | 9 | 1 (net +0) | 0 | 1 (net +925) | 3 (net +137) | 2 (net +114) | 2 (net +301) | 0 | 11% (1 of 9) |
| Mine | Vampire Counts | 7 | 2 (net +0) | 0 | 1 (net +173) | 1 (net +0) | 1 (net +70) | 1 (net +0) | 1 | 17% (1 of 6) |
| Mine | Warriors of Chaos | 2 | 1 (net -30) | 0 | 0 | 0 | 1 (net +91) | 0 | 0 | 0% (0 of 2) |
| Opponent | Beastmen Brayherds | 5 | 0 | 0 | 3 (net +47) | 1 (net +15) | 0 | 1 (net +65) | 0 | 60% (3 of 5) |
| Opponent | Dwarfen Mountain Holds | 2 | 1 (net +0) | 0 | 0 | 0 | 0 | 1 (net +112) | 0 | 0% (0 of 2) |
| Opponent | Empire of Man | 2 | 0 | 0 | 1 (net -265) | 0 | 0 | 0 | 1 | 100% (1 of 1) |
| Opponent | Grand Cathay | 7 | 2 (net +0) | 0 | 1 (net +613) | 4 (net +102) | 0 | 0 | 0 | 14% (1 of 7) |
| Opponent | High Elf Realms | 3 | 0 | 0 | 1 (net +390) | 0 | 1 (net +0) | 0 | 1 | 50% (1 of 2) |
| Opponent | Lizardmen | 4 | 2 (net +48) | 0 | 0 | 0 | 0 | 0 | 2 | 0% (0 of 2) |
| Opponent | Ogre Kingdoms | 8 | 0 | 0 | 1 (net +0) | 3 (net -3) | 0 | 2 (net -17) | 2 | 17% (1 of 6) |
| Opponent | Orc & Goblin Tribes | 8 | 1 (net +364) | 0 | 0 | 0 | 0 | 0 | 7 | 0% (0 of 1) |
| Opponent | Skaven | 1 | 0 | 0 | 1 (net +0) | 0 | 0 | 0 | 0 | 100% (1 of 1) |
| Opponent | Tomb Kings of Khemri | 18 | 1 (net +0) | 1 (net -540) | 2 (net +146) | 7 (net +277) | 3 (net +173) | 4 (net +166) | 0 | 11% (2 of 18) |
| Opponent | Vampire Counts | 24 | 4 (net -290) | 1 (net +392) | 4 (net -8) | 5 (net +46) | 1 (net +92) | 8 (net +116) | 1 | 17% (4 of 23) |
| Opponent | Warriors of Chaos | 11 | 1 (net +663) | 0 | 1 (net +708) | 3 (net +103) | 1 (net +54) | 3 (net +149) | 2 | 11% (1 of 9) |
| Opponent | Wood Elf Realms | 23 | 4 (net +64) | 1 (net +70) | 4 (net -39) | 5 (net +75) | 1 (net +65) | 5 (net +100) | 3 | 20% (4 of 20) |

### Charged fights, damage counted: jc-opp-1e5408d-p1

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 17 | 220 | 239 | +86 | 142 | 34 | +107 | +48.7 |
| Mine | 50-54% | 2 | 387 | 224 | +0 | 20 | 0 | +20 | +5.3 |
| Mine | Effective (55-75%) | 8 | 325 | 180 | +193 | 296 | 96 | +200 | +61.6 |
| Mine | 76-89% | 24 | 321 | 189 | +104 | 143 | 45 | +98 | +30.6 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 24 | 222 | 181 | +89 | 134 | 43 | +91 | +40.9 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 12 | 495 | 100 | +96 | 96 | 38 | +57 | +11.6 |
| Mine | No odds | 12 | 276 | 174 | -78 | 35 | 105 | -70 | -25.4 |
| Mine | All fights | 99 | 297 | 183 | +79 | 132 | 52 | +79 | +26.7 |
| Opponent | Long shot (under 50%) | 16 | 237 | 295 | +14 | 124 | 100 | +23 | +9.8 |
| Opponent | 50-54% | 3 | 341 | 224 | -26 | 165 | 263 | -98 | -28.7 |
| Opponent | Effective (55-75%) | 19 | 191 | 187 | +89 | 167 | 82 | +85 | +44.5 |
| Opponent | 76-89% | 28 | 273 | 160 | +117 | 157 | 22 | +135 | +49.4 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 24 | 410 | 227 | +112 | 169 | 54 | +115 | +28.1 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 7 | 519 | 88 | +104 | 104 | 0 | +104 | +20.1 |
| Opponent | No odds | 19 | 271 | 175 | +100 | 131 | 34 | +97 | +35.9 |
| Opponent | All fights | 116 | 299 | 197 | +90 | 149 | 56 | +93 | +31.1 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| jc-opp-1e5408d-p1 | move | 381 | 88 (23%) | 68 (18%) | 57 (15%) | 236 (62%) |
| jc-opp-1e5408d-p1 | objective | 425 | 59 (14%) | 45 (11%) | 64 (15%) | 302 (71%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0102, L0118, L0135, L2531, L2730 |
| Charmed Shield | Opponent | L0524, L1224, L1527, L1625, L2025, L2127, L2934 |
| Clockwork Compass | Mine | L1224 |
| Clockwork Compass | Opponent | L0612 |
| Elixir of Power | Mine | L1114, L1131, L1923 |
| Elixir of Power | Opponent | L0319, L1319 |
| Fistful of Laurels | Mine | L1823 |
| Fistful of Laurels | Opponent | L0118, L0218 |
| Horn of the Wild Hunt | Opponent | L0733 |
| Invocation of Nehek | Mine | L2531, L2730 |
| Invocation of Nehek | Opponent | L0524, L1224, L1527, L1625, L2025, L2127 |
| Opal Amulet | Mine | L1431 |
| Opal Amulet | Opponent | L1114 |
| Periapt of Soul Exchange | Mine | L2025, L2127 |
| Periapt of Soul Exchange | Opponent | L0421, L1021 |
| Ring of Doom | Mine | L0218, L0235, L1114, L1131, L1224, L1527 |
| Ring of Doom | Opponent | L0102, L0612, L0733, L1131, L1431, L2231, L2531 |
| Ring of Jet | Mine | L1021, L1114, L1131, L1224 |
| Ring of Jet | Opponent | L0612 |
| Standard of the Fell Warrior | Mine | L1319, L1335 |
| Standard of the Fell Warrior | Opponent | L0913 |
| Storm Daemon (Renegade 2.0) | Mine | L2127 |
| Storm Daemon (Renegade 2.0) | Opponent | L0421, L1021 |
| Twice-Blessed Armour | Mine | L0717, L0733, L1021 |
| Witch Hunter's Ward | Mine | L0717, L0733, L0823 |
| Witch Hunter's Ward | Opponent | L0508 |

# Doctrine scorecard: jc-mine-1e5408d-p2

### Scorecard: jc-mine-1e5408d-p2

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0106 | 4 | 1 | Mine | no | 1 | - | 0 | 4 | 0 | 0 | 0 | 322 |
| L0106 | 4 | 1 | Opponent | no | 0 | 2 | 1 | 2 | 0 | 0 | 0 | 981 |
| L0122 | 2 | 1 | Mine | - | - | - | 0 | 2 | 0 | 0 | 0 | 317 |
| L0122 | 2 | 1 | Opponent | - | - | 2 | 6 | 1 | 0 | 0 | 0 | 0 |
| L0206 | 2 | 1 | Mine | - | - | 5 | 1 | 4 | 0 | 0 | 0 | 0 |
| L0206 | 2 | 1 | Opponent | - | - | 4 | 0 | 1 | 0 | 0 | 0 | 615 |
| L0222 | 6 | 1 | Mine | no | 2 | 2 | 3 | 3 | 0 | 0 | 0 | 200 |
| L0222 | 6 | 1 | Opponent | no | 14 | 3 | 2 | 0 | 0 | 0 | 0 | 55 |
| L0307 | 1 | 1 | Mine | yes | 2 | 3 | 2 | 2 | 0 | 0 | 0 | 675 |
| L0307 | 1 | 1 | Opponent | yes | 5 | 2 | 0 | 0 | 0 | 0 | 0 | 420 |
| L0323 | 5 | 1 | Mine | no | - | - | 0 | 2 | 0 | 0 | 0 | 675 |
| L0323 | 5 | 1 | Opponent | yes | - | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L0409 | 1 | 1 | Mine | no | 4 | 2 | 3 | 2 | 1 | 0 | 0 | 0 |
| L0409 | 1 | 1 | Opponent | no | 3 | - | 0 | 0 | 0 | 0 | 0 | 537 |
| L0425 | 5 | 1 | Mine | yes | - | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L0425 | 5 | 1 | Opponent | yes | - | - | 2 | 3 | 0 | 0 | 0 | 0 |
| L0512 | 2 | 1 | Mine | - | - | - | 0 | 2 | 0 | 0 | 0 | 966 |
| L0512 | 2 | 1 | Opponent | - | - | 2 | 0 | 3 | 1 | 0 | 0 | 330 |
| L0528 | 6 | 1 | Mine | no | 0 | 4 | 1 | 1 | 0 | 0 | 0 | 475 |
| L0528 | 6 | 1 | Opponent | no | 8 | 5 | 1 | 2 | 0 | 0 | 0 | 0 |
| L0616 | 4 | 1 | Mine | no | 0 | - | 2 | 2 | 0 | 0 | 0 | 615 |
| L0616 | 4 | 1 | Opponent | no | 4 | 3 | 1 | 1 | 1 | 0 | 0 | 200 |
| L0632 | 2 | 1 | Mine | - | - | 4 | 4 | 0 | 0 | 0 | 0 | 743 |
| L0632 | 2 | 1 | Opponent | - | - | 2 | 2 | 3 | 1 | 0 | 0 | 0 |
| L0721 | 1 | 1 | Mine | yes | 3 | 2 | 2 | 0 | 1 | 0 | 0 | 558 |
| L0721 | 1 | 1 | Opponent | yes | 3 | - | 1 | 3 | 1 | 0 | 0 | 145 |
| L0810 | 6 | 1 | Mine | no | 0 | 3 | 1 | 3 | 0 | 0 | 0 | 864 |
| L0810 | 6 | 1 | Opponent | no | 5 | 2 | 1 | 0 | 1 | 0 | 0 | 330 |
| L0827 | 5 | 1 | Mine | no | - | 6 | 1 | 1 | 0 | 0 | 0 | 769 |
| L0827 | 5 | 1 | Opponent | yes | - | 2 | 7 | 5 | 0 | 0 | 0 | 0 |
| L0918 | 6 | 1 | Mine | no | 1 | 2 | 0 | 0 | 0 | 0 | 0 | 420 |
| L0918 | 6 | 1 | Opponent | no | 14 | 2 | 8 | 1 | 0 | 0 | 0 | 419 |
| L0934 | 4 | 1 | Mine | no | 0 | 3 | 0 | 0 | 0 | 0 | 0 | 768 |
| L0934 | 4 | 1 | Opponent | no | 0 | 2 | 4 | 2 | 0 | 0 | 0 | 160 |
| L1026 | 6 | 1 | Mine | no | 0 | 2 | 2 | 0 | 0 | 0 | 0 | 330 |
| L1026 | 6 | 1 | Opponent | no | 2 | 3 | 3 | 2 | 0 | 0 | 0 | 0 |
| L1118 | 2 | 1 | Mine | - | - | 2 | 2 | 0 | 0 | 0 | 0 | 330 |
| L1118 | 2 | 1 | Opponent | - | - | - | 3 | 3 | 0 | 0 | 0 | 225 |
| L1135 | 1 | 1 | Mine | yes | 0 | 5 | 0 | 0 | 1 | 0 | 0 | 501 |
| L1135 | 1 | 1 | Opponent | yes | 0 | 2 | 2 | 4 | 0 | 0 | 0 | 0 |
| L1228 | 4 | 1 | Mine | no | 2 | 3 | 0 | 1 | 0 | 0 | 0 | 524 |
| L1228 | 4 | 1 | Opponent | no | 5 | 2 | 2 | 1 | 0 | 0 | 0 | 398 |
| L1323 | 3 | 1 | Mine | no | 4 | 4 | 1 | 1 | 1 | 0 | 0 | 140 |
| L1323 | 3 | 1 | Opponent | no | 4 | 2 | 4 | 0 | 1 | 0 | 0 | 0 |
| L1418 | 2 | 1 | Mine | - | - | 2 | 4 | 3 | 1 | 0 | 0 | 0 |
| L1418 | 2 | 1 | Opponent | - | - | 4 | 3 | 2 | 1 | 0 | 0 | 305 |
| L1435 | 1 | 1 | Mine | no | 3 | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| L1435 | 1 | 1 | Opponent | no | 0 | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L1531 | 1 | 1 | Mine | no | 1 | 2 | 1 | 0 | 0 | 0 | 0 | 0 |
| L1531 | 1 | 1 | Opponent | yes | 4 | 2 | 5 | 2 | 0 | 0 | 0 | 170 |
| L1629 | 3 | 1 | Mine | no | 3 | 1 | 1 | 1 | 0 | 0 | 0 | 536 |
| L1629 | 3 | 1 | Opponent | no | 0 | 2 | 4 | 1 | 1 | 0 | 0 | 170 |
| L1727 | 5 | 1 | Mine | yes | - | 2 | 3 | 0 | 0 | 0 | 0 | 0 |
| L1727 | 5 | 1 | Opponent | yes | - | 2 | 5 | 2 | 0 | 0 | 0 | 0 |
| L1827 | 3 | 1 | Mine | no | 0 | 4 | 2 | 2 | 0 | 0 | 0 | 185 |
| L1827 | 3 | 1 | Opponent | no | 4 | 2 | 5 | 2 | 0 | 0 | 0 | 0 |
| L1927 | 1 | 1 | Mine | no | 1 | 1 | 3 | 1 | 0 | 0 | 0 | 0 |
| L1927 | 1 | 1 | Opponent | no | 2 | 2 | 1 | 1 | 1 | 0 | 0 | 190 |
| L2029 | 1 | 1 | Mine | no | 0 | - | 2 | 1 | 2 | 0 | 0 | 420 |
| L2029 | 1 | 1 | Opponent | no | 0 | 3 | 3 | 1 | 0 | 0 | 0 | 0 |
| L2131 | 1 | 1 | Mine | yes | 3 | - | 4 | 4 | 0 | 0 | 0 | 145 |
| L2131 | 1 | 1 | Opponent | no | 3 | 4 | 2 | 1 | 1 | 0 | 0 | 170 |
| L2235 | 3 | 1 | Mine | no | 0 | 2 | 2 | 0 | 0 | 0 | 0 | 0 |
| L2235 | 3 | 1 | Opponent | no | 0 | 2 | 2 | 1 | 1 | 0 | 0 | 126 |
| L2429 | 5 | 1 | Mine | no | - | - | 1 | 2 | 0 | 0 | 0 | 0 |
| L2429 | 5 | 1 | Opponent | yes | - | 3 | 4 | 3 | 0 | 0 | 0 | 0 |
| L2535 | 3 | 1 | Mine | no | 7 | 3 | 3 | 1 | 1 | 0 | 0 | 0 |
| L2535 | 3 | 1 | Opponent | no | 0 | 1 | 4 | 0 | 0 | 0 | 0 | 0 |
| L2735 | 5 | 1 | Mine | yes | - | 4 | 1 | 6 | 0 | 0 | 0 | 0 |
| L2735 | 5 | 1 | Opponent | no | - | 3 | 1 | 3 | 0 | 0 | 0 | 0 |
| L3033 | 3 | 1 | Mine | yes | 5 | 4 | 3 | 0 | 0 | 0 | 0 | 0 |
| L3033 | 3 | 1 | Opponent | no | 2 | 1 | 7 | 2 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 27% | 1.8 | 2.9 | 1.7 | 1.5 | 0.2 | 0.0 | 0.0 | 318.8 |
| **Average** | | | Opponent | 30% | 3.4 | 2.4 | 2.9 | 1.7 | 0.3 | 0.0 | 0.0 | 165.2 |

### KPIs: jc-mine-1e5408d-p2

Rules off - Opponent only: SECOND CHARGER ADDS.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 27% (46 of 172) | 19% (33 of 176) | 23% (79 of 348) |
| Winner chose to follow up after the loser gave ground |  | 98% (46 of 47); on the table 100% | 98% (58 of 59); on the table 98% | 98% (104 of 106); on the table 99% |
| Winner chose to pursue after the loser fell back in good order |  | 80% (8 of 10); on the table 80% | 82% (9 of 11); on the table 82% | 81% (17 of 21); on the table 81% |
| Winner chose to pursue after the loser fled |  | 77% (20 of 26); on the table 88% | 85% (28 of 33); on the table 91% | 81% (48 of 59); on the table 90% |
| Winner chose to follow up or pursue (all three) |  | 89% (74 of 83); on the table 94% | 92% (95 of 103); on the table 94% | 91% (169 of 186); on the table 94% |
| Magic missiles tried each own turn | 50%+ | 33% (112 of 342) | 38% (59 of 156) | 34% (171 of 498) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 46% (112 of 245) | 49% (59 of 120) | 47% (171 of 365) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 59% (16 of 27) | 57% (31 of 54) | 58% (47 of 81) |
| Points that never fought | lower | 42% (29929 of 71583) | 45% (32118 of 71989) | 43% (62047 of 143572) |
|   infantry points that never fought | lower | 45% (7381 of 16324) | 63% (8800 of 14029) | 53% (16181 of 30353) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 61% (172 of 284) | 60% (179 of 297) | 60% (351 of 581) |
| Bound items with a magic missile used (at least once a game) |  | 90% (18 of 20); 1.6 uses a game | 67% (12 of 18); 1.1 uses a game | 79% (30 of 38); 1.3 uses a game |
| Bound items with another spell used |  | 39% (7 of 18); 0.4 uses a game | 0% (0 of 2); 0.0 uses a game | 35% (7 of 20); 0.2 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 60% (12 of 20); 0.3 uses a game | 29% (2 of 7); 0.1 uses a game | 52% (14 of 27); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 57% (34155 of 60231) | 57% (35877 of 63281) | 57% (70032 of 123512) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.8 (28%) | 0.8 (29%) | 2.6 (28%) |
| MARCHED: its unit marched | 1.1 (18%) | 0.4 (13%) | 1.5 (17%) |
| CHARGED: its unit charged | 0.2 (3%) | 0.2 (6%) | 0.4 (4%) |
| IN COMBAT: engaged in combat | 1.4 (21%) | 0.4 (13%) | 1.7 (19%) |
| REAR RANK: in a rear rank | 0.1 (1%) | 0.1 (4%) | 0.2 (2%) |
| FLEEING: fleeing | 0.2 (3%) | 0.0 (0%) | 0.2 (2%) |
| GONE: slain | 0.8 (13%) | 0.4 (15%) | 1.2 (14%) |
| OFF THE TABLE: off the table or not arrived | 0.3 (5%) | 0.2 (8%) | 0.6 (6%) |
| STUPIDITY: Stupidity | 0.3 (4%) | 0.0 (1%) | 0.3 (3%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.2 (3%) | 0.2 (9%) | 0.4 (5%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 3.9 | 1.3 | 1.1 | 4.8 | 0.5 | 1.6 |
| not cast | 3.9 | 3.6 | 3.9 | 9.1 | 1.9 | 20.1 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.1 (2%) | 0.0 (0%) | 0.0 (0%) | 1.2 (6%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.3 (36%) | 0.2 (6%) | 2.6 (28%) | 0.4 (24%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.5 (17%) | 0.2 (13%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.4 (4%) | 0.0 (1%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.1 (3%) | 0.4 (11%) | 0.6 (16%) | 1.7 (19%) | 0.2 (12%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.3 (9%) | 0.3 (9%) | 0.4 (9%) | 0.2 (2%) | 0.0 (0%) | 0.0 (0%) |
| NO CASTS LEFT: every cast used on other spells | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (6%) | 0.0 (0%) |
| FLEEING: fleeing | 0.1 (2%) | 0.2 (5%) | 0.1 (2%) | 0.2 (2%) | 0.1 (4%) | 0.4 (2%) |
| GONE: slain | 0.7 (19%) | 0.8 (22%) | 0.5 (14%) | 1.2 (14%) | 0.4 (19%) | 3.6 (18%) |
| OFF THE TABLE: off the table or not arrived | 0.3 (8%) | 0.1 (4%) | 0.2 (4%) | 0.6 (6%) | 0.1 (4%) | 0.4 (2%) |
| STUPIDITY: Stupidity | 0.1 (2%) | 0.0 (1%) | 0.2 (5%) | 0.3 (3%) | 0.0 (0%) | 0.6 (3%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (4%) | 0.2 (7%) | 0.0 (0%) | 0.0 (0%) | 0.3 (15%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.4 (5%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.1 (54%) | 0.2 (5%) | 1.6 (41%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 13.8 (69%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.6 a game | 0.6 a game | 0.6 a game |
| stood (cast and not dispelled) | 67% (14 of 21) | 50% (11 of 22) | 58% (25 of 43) |
| the unit moved after it | 64% (9 of 14) | 55% (6 of 11) | 60% (15 of 25) |
| it charged on its next turn | 14% (2 of 14) | 0% (0 of 11) | 8% (2 of 25) |
| the enemy charged it first | 7% (1 of 14) | 9% (1 of 11) | 8% (2 of 25) |
| it fought by the end of its next turn | 7% (1 of 14) | 9% (1 of 11) | 8% (2 of 25) |
| it moved out of a charge the enemy had planned (not charged first) | 29% (4 of 14) | 9% (1 of 11) | 20% (5 of 25) |
| none of these (no charge, no fight, no charge escaped) | 57% (8 of 14) | 82% (9 of 11) | 68% (17 of 25) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 69% (586 of 849) | 57% (442 of 779) | 63% (1028 of 1628) |
|   cavalry | 55% (40 of 73) | 62% (110 of 176) | 60% (150 of 249) |
|   character | 58% (61 of 105) | 27% (23 of 85) | 44% (84 of 190) |
|   chariot | 58% (61 of 105) | 54% (27 of 50) | 57% (88 of 155) |
|   infantry | 63% (165 of 262) | 56% (168 of 301) | 59% (333 of 563) |
|   monster | 57% (25 of 44) | 54% (19 of 35) | 56% (44 of 79) |
|   war machine | 90% (234 of 260) | 72% (95 of 132) | 84% (329 of 392) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.1 (29%) | 2.0 (22%) | 4.1 (25%) |
| CHARGED: it charged | 1.0 (13%) | 1.6 (18%) | 2.6 (16%) |
| FLEEING: it fled or was fleeing | 0.1 (1%) | 0.2 (2%) | 0.3 (2%) |
| IN COMBAT: it fought this turn or the last | 0.7 (10%) | 0.5 (5%) | 1.2 (7%) |
| MOVED: a war machine that moved | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NO TARGET IN RANGE | 1.0 (14%) | 1.7 (18%) | 2.8 (16%) |
| ONLY IN COMBAT: the only targets were in combat | 0.4 (6%) | 0.5 (5%) | 0.9 (5%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.6 (22%) | 2.0 (21%) | 3.6 (22%) |
| SHELTERED: the target was sheltered | 0.2 (2%) | 0.2 (2%) | 0.4 (2%) |
| STUPIDITY | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR | 0.2 (2%) | 0.6 (6%) | 0.7 (4%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 6.0 | 1.5 | 81% | 4.1 pts | 25 pts |
| character | 2.4 | 0.8 | 74% | 11.0 pts | 26 pts |
| chariot | 2.4 | 1.6 | 69% | 12.8 pts | 31 pts |
| infantry | 12.6 | 5.0 | 71% | 9.6 pts | 120 pts |
| monster | 1.4 | 0.4 | 78% | 6.4 pts | 9 pts |
| war machine | 9.1 | 7.5 | 61% | 27.6 pts | 252 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.7 | 5.7 | 4.7 |
| Charges that made contact a game | 2.9 | 4.1 | 3.5 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.75 declared, 0.58 contact (24 units) | 0.91 declared, 0.73 contact (11 units) | 0.80 declared, 0.63 contact (35 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.29 declared, 0.14 contact (7 units) | 1.30 declared, 1.20 contact (10 units) | 0.88 declared, 0.76 contact (17 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.45 declared, 0.36 contact (249 units) | 0.63 declared, 0.44 contact (288 units) | 0.55 declared, 0.40 contact (537 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 64% (47 of 73) | 56% (10 of 18) | 58% (7 of 12) | 62% (64 of 103) |
| Character in a unit | 79% (31 of 39) | 75% (15 of 20) | 60% (3 of 5) | 77% (49 of 64) |
| Character on its own | 79% (26 of 33) | 59% (20 of 34) | 34% (21 of 61) | 52% (67 of 128) |
| Chariot | 65% (11 of 17) | 69% (9 of 13) | - | 67% (20 of 30) |
| Infantry | 47% (44 of 94) | 65% (22 of 34) | 33% (1 of 3) | 51% (67 of 131) |
| Monster | 59% (17 of 29) | 78% (7 of 9) | - | 63% (24 of 38) |
| Monstrous | 50% (7 of 14) | 64% (9 of 14) | - | 57% (16 of 28) |
| War Machines | 74% (42 of 57) | 100% (2 of 2) | - | 75% (44 of 59) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 100% (14 of 14); on the table 100% | 35% (36 of 102) | 50% | 64% (14 of 22) | 83% (5 of 6); 3.2 uses a game | 100% (2 of 2); 1.2 uses a game | 100% (6 of 6); 1.5 uses a game |
| Chaos Dwarfs | 4 | 86% (12 of 14); on the table 86% | 53% (19 of 36) | 51% | 59% (19 of 32) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
| Dwarfen Mountain Holds | 6 | 82% (9 of 11); on the table 82% | - | 64% | 74% (40 of 54) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 7 | 80% (12 of 15); on the table 93% | 29% (14 of 48) | 37% | 59% (45 of 76) | 0.0 uses a game | 50% (1 of 2); 0.4 uses a game | 0% (0 of 4); 0.0 uses a game |
| Grand Cathay | 6 | 100% (6 of 6); on the table 100% | 38% (53 of 138) | 51% | 52% (28 of 54) | 79% (11 of 14); 6.8 uses a game | 0% (0 of 2); 0.0 uses a game | 17% (1 of 6); 0.2 uses a game |
| High Elf Realms | 4 | 100% (5 of 5); on the table 100% | 17% (3 of 18) | 37% | 55% (18 of 33) | 100% (3 of 3); 1.2 uses a game | 29% (4 of 14); 1.5 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 2 | 100% (8 of 8); on the table 100% | - | 46% | 50% (6 of 12) | 0.0 uses a game | 0.0 uses a game | 100% (2 of 2); 1.0 uses a game |
| Lizardmen | 1 | 100% (1 of 1); on the table 100% | - | 17% | 71% (5 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 4 | 100% (12 of 12); on the table 100% | 0% (0 of 18) | 56% | 82% (23 of 28) | 100% (4 of 4); 4.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 1 | - | 0% (0 of 12) | 3% | 38% (3 of 8) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Skaven | 3 | 64% (7 of 11); on the table 82% | 17% (3 of 18) | 39% | 52% (13 of 25) | 100% (2 of 2); 1.3 uses a game | 0.0 uses a game | 100% (3 of 3); 1.0 uses a game |
| Tomb Kings of Khemri | 5 | 90% (9 of 10); on the table 90% | - | 44% | 20% (5 of 25) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 9 | 92% (33 of 36); on the table 97% | 30% (20 of 66) | 36% | 69% (37 of 54) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 9 | 100% (19 of 19); on the table 100% | 33% (6 of 18) | 36% | 56% (41 of 73) | 100% (2 of 2); 0.6 uses a game | 0.0 uses a game | 100% (1 of 1); 0.1 uses a game |
| Wood Elf Realms | 7 | 92% (22 of 24); on the table 92% | 71% (17 of 24) | 42% | 69% (54 of 78) | 43% (3 of 7); 1.6 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (jc-mine-1e5408d-p2, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 54% (47) | 41% (26) | 48% (73) |
| ...free all their last turn and able to turn (per game) | 0.83 | 0.47 | 1.31 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.19 | 0.11 | 0.31 |
| ...with the charger already in that arc before they moved (per game) | 0.58 | 0.31 | 0.89 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 1.78 | 1.25 | 3.03 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.92 | 0.58 | 1.50 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 5.83 | 5.00 | 10.83 |

### Quality by phase: jc-mine-1e5408d-p2

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.8 | 3.3 |
| Strategy | Charge objectives carried out (made contact) | 56% (60 of 107) | 46% (87 of 190) |
| Strategy | Shoot objectives carried out (shot that target) | 40% (161 of 401) | 51% (125 of 244) |
| Strategy | Close-in objectives charged next turn | 15% (22 of 146) | 17% (44 of 264) |
| Strategy | Support requests answered (helper made contact too) | 40% (10 of 25) | 48% (16 of 33) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (3 of 3) | 75% (3 of 4) |
| Strategy | Hexes on a unit its side charged or shot that turn | 60% (9 of 15) | 75% (9 of 12) |
| Strategy | Joined characters whose unit fought | 33% (18 of 55) | 34% (15 of 44) |
| Strategy | Lone characters that fought | 76% (68 of 90) | 67% (53 of 79) |
| Movement | Charges halted short of contact | 0.1 | 0.1 |
| Movement | Idle units | 1.5 | 1.7 |
| Movement | Points that never moved of their own | 318.8 | 165.2 |
| Movement | Fights charged into per game | 2.4 | 3.4 |
| Movement | Charges with odds: long shots (under 50%) | 11 of 79, net +34 | 23 of 111, net +122 |
| Movement | Charges with odds: sweet spot (55-75%) | 20 of 79, net +107 | 25 of 111, net +146 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 13 of 79, net +109 | 5 of 111, net +71 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 26 of 79, net +100 | 31 of 111, net +65 |
| Shooting | Shots by shooting units (incl. breath weapons) | 10.7 | 10.6 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 40% (155 of 386) | 44% (168 of 381) |
| Shooting | Points destroyed by shooting units | 149.6 | 54.4 |
| Shooting | War machine shots | 6.5 | 2.6 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 57% (133 of 234) | 40% (38 of 95) |
| Shooting | Points destroyed by war machines | 65.2 | 50.1 |
| Magic | Magic missiles cast | 2.0 | 1.0 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 27% (20 of 73) | 34% (12 of 35) |
| Magic | Wounds caused by magic missiles | 3.6 | 1.8 |
| Magic | Wounds caused by other spells | 1.1 | 1.1 |
| Magic | Points destroyed by magic (all spells) | 81.8 | 25.9 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.9 / 0.5 / 0.6 / 0.1 | 1.9 / 0.3 / 0.4 / 0.2 |
| Combat | Points destroyed in combat | 264.3 | 297.2 |
| Combat | Points run down | 47.6 | 158.4 |
| Combat | Net points per charged fight, damage counted | +93 | +107 |
| Combat | Net per 100 charger points, damage counted | +31.7 | +42.9 |
| Combat | First round won (charged fights) | 77% | 75% |
| Combat | Net points per charged fight | +92 | +116 |
| Combat | Net points per supported fight / lone fight | +121 / +85 | +156 / +108 |
| Combat | Charged fights on a top-3 enemy unit | 26 of 86 | 50 of 121 |
| Game | Points lost | 749.3 | 683.6 |
| Game | VP from objectives | 499.4 | 706.7 |
| Game | Lone holders (player turns) | 1.8 | 3.4 |

- Mine won / drew / lost: 11 / 5 / 20 of 36 ended games (of 36); mean margin (Mine - Opponent) -251 VP
- The side that went first won 19 of 31 games with a winner
- Points traded per game (both sides' losses): 1433
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: jc-mine-1e5408d-p2

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 0.5 | +0.0 | 0.0 | 0.0 |
| ADVANCE WORTH | 5.6 | -174.4 | 244.0 | 89.9 | 5.4 | -185.9 | 206.9 | 49.4 |
| ARRIVAL HUNT | - | - | - | - | 0.1 | +4.3 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.3 | +0.0 | 0.0 | 39.3 | 0.3 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | 0.8 | +3.4 | 0.0 | 28.2 | 0.6 | +4.9 | 0.0 | 11.2 |
| BEST FACING | 0.5 | +21.9 | 0.0 | 11.1 | 0.2 | +7.0 | 0.0 | 43.7 |
| BEST FIRST | 1.4 | +75.6 | 7.5 | 23.1 | 1.0 | +43.7 | 26.2 | 22.5 |
| BEST OVERALL | 0.4 | +16.1 | 0.0 | 17.8 | 0.3 | +18.4 | 0.0 | 17.6 |
| BEST PREY | 0.8 | +59.0 | 64.9 | 15.7 | 0.9 | +30.3 | 17.6 | 3.5 |
| BIG CHARACTER SAFETY | 0.2 | +0.8 | 0.0 | 32.5 | 0.1 | +0.4 | 0.0 | 16.6 |
| BLOCKED CHARGE SKIPPED | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 7.1 | 6.5 |
| BLOCKED WHEEL | 0.4 | +9.0 | 0.0 | 0.0 | 0.6 | +7.4 | 0.0 | 16.6 |
| BLOWS WHERE AIMED | 0.1 | +1.5 | 4.4 | 0.0 | 0.3 | -46.2 | 45.9 | 6.0 |
| BOMBING RUN | 0.1 | +3.4 | 0.0 | 0.0 | - | - | - | - |
| BOUND ASSAILMENT | 0.1 | +0.0 | 0.0 | 6.8 | - | - | - | - |
| CANNON PLAN MISSED | 0.8 | +0.0 | 178.7 | 19.3 | 0.2 | +0.0 | 1.4 | 0.0 |
| CANNON PLANNED TARGET | 5.2 | +228.8 | 476.6 | 115.6 | 1.9 | +79.0 | 100.3 | 3.5 |
| CANNON SIGHT KEPT | 1.3 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT SET-UP | 0.0 | +0.0 | 5.8 | 0.0 | 0.2 | +0.0 | 44.5 | 12.1 |
| CAST JOB | 0.8 | +21.2 | 78.2 | 0.0 | 0.5 | +14.2 | 46.0 | 25.4 |
| CASTER AWAY FROM SCREEN | 0.3 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.8 | +47.4 | 50.3 | 0.0 | 0.3 | +11.2 | 11.5 | 0.0 |
| CASTS AFTER FRIENDS | 0.4 | +0.0 | 0.0 | 2.6 | 0.2 | +0.0 | 0.0 | 16.5 |
| CASTS FROM BEHIND | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.1 | +2.3 | 0.0 | 0.0 | - | - | - | - |
| CATCH ODDS | - | - | - | - | 0.0 | +0.4 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | 0.9 | +43.9 | 0.0 | 24.7 | 1.8 | +84.7 | 0.0 | 49.5 |
| CHAFF PASSED | 0.1 | -0.2 | 0.0 | 7.9 | 0.3 | -0.3 | 0.0 | 4.0 |
| CHARGE NOW FIRST | 2.2 | +0.0 | 212.2 | 73.5 | 2.4 | +0.0 | 341.6 | 61.1 |
| CHARGE NOW WEIGHED | 0.5 | -22.7 | 16.3 | 11.7 | 0.4 | -52.8 | 24.6 | 29.3 |
| CHARGER SLAIN LOST | 0.4 | -3.4 | 49.4 | 4.8 | 0.7 | -13.6 | 74.1 | 9.9 |
| CHARIOT WIZARD CAREFUL | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHEAP HELPER | - | - | - | - | 0.2 | +0.0 | 21.8 | 1.7 |
| COMBAT PIVOT | 0.4 | +0.0 | 5.1 | 23.3 | 0.3 | +0.0 | 10.0 | 0.0 |
| CONTINUE AHEAD WEIGHED | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | 0.4 | +62.2 | 13.9 | 16.5 | 0.4 | +29.3 | 24.6 | 29.4 |
| COVER ONCE | 8.8 | -707.8 | 0.0 | 206.0 | 6.7 | -478.4 | 0.0 | 181.5 |
| DEFENSIVE ARMY | 0.3 | +0.0 | 36.4 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| DEFENSIVE FLOOR | 0.1 | +1.4 | 4.7 | 2.6 | - | - | - | - |
| EDGE GIVE GROUND | 0.1 | +3.4 | 15.5 | 0.0 | 0.4 | +7.6 | 25.6 | 2.0 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 1.8 | +112.2 | 0.0 | 52.4 | 1.2 | +91.9 | 0.0 | 66.9 |
| FALLBACK BY WORTH | 4.1 | +44.8 | 0.0 | 54.1 | 5.5 | +32.5 | 0.0 | 100.2 |
| FIGHT LIFT | 0.0 | +0.7 | 0.0 | 0.0 | 0.0 | +0.6 | 0.0 | 0.0 |
| FIRE AND FLEE | 0.1 | +3.1 | 0.0 | 0.0 | 0.0 | +0.2 | 0.0 | 0.0 |
| FLANK NOT WEIGHED | 5.8 | +0.0 | 0.0 | 134.2 | 4.4 | +0.0 | 0.0 | 202.6 |
| FOCUS FIRE | 0.0 | +2.4 | 3.1 | 0.0 | 0.1 | +2.9 | 1.5 | 0.0 |
| FOLLOW UP WEIGHED | 0.8 | +114.9 | 0.0 | 57.2 | 0.9 | +133.5 | 0.0 | 42.8 |
| FRIEND IN REACH | 3.3 | +58.2 | 348.8 | 82.4 | 5.6 | +129.4 | 581.1 | 132.1 |
| FRIENDS SHOTS CHECKED | 0.1 | +9.0 | 0.0 | 0.0 | 0.1 | +2.4 | 0.0 | 0.0 |
| GIVES UP | - | - | - | - | 0.1 | -1.6 | 21.2 | 0.0 |
| GIVES UP ITS SCREEN | 0.0 | -0.2 | 5.4 | 0.0 | 0.1 | -0.1 | 3.4 | 0.0 |
| HELPER ALREADY ASKED | - | - | - | - | 0.1 | +0.0 | 6.3 | 0.8 |
| HELPER UNSEEN | 0.4 | +0.0 | 28.4 | 3.4 | 0.4 | +0.0 | 29.2 | 18.7 |
| HILL BY ITS CHANCE | 0.4 | -41.0 | 0.0 | 0.0 | 0.5 | -47.7 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 7.2 | -109.1 | 397.1 | 159.4 | 10.4 | -197.6 | 732.5 | 249.1 |
| HORN WORTH | - | - | - | - | 0.0 | +0.1 | 0.0 | 0.0 |
| HUNT ADVANCE | 0.0 | +0.2 | 5.4 | 0.0 | 0.6 | +5.6 | 36.2 | 0.0 |
| HUNT DROPPED | - | - | - | - | 0.3 | +0.0 | 30.8 | 0.0 |
| HUNT IN PAIRS | 0.3 | +16.9 | 0.0 | 0.0 | 0.6 | +42.1 | 0.0 | 53.2 |
| HUNT KEPT | 0.0 | +0.5 | 5.4 | 0.0 | 0.3 | +5.5 | 13.9 | 0.0 |
| HUNT RESULT | 0.1 | +9.5 | 0.0 | 1.4 | 0.6 | +95.9 | 43.5 | 2.8 |
| HUNT THE GUNS | 0.1 | +9.9 | 8.8 | 1.4 | 0.6 | +194.6 | 60.7 | 1.8 |
| IDLE COST | 14.6 | -233.6 | 0.0 | 206.1 | 18.8 | -297.9 | 0.0 | 228.2 |
| INVITES THE FIGHT | 1.2 | +10.1 | 84.0 | 30.9 | 0.9 | +5.2 | 54.7 | 13.0 |
| JOINT CHARGE PLAN | 0.0 | +1.3 | 0.0 | 0.0 | 0.2 | +3.0 | 5.1 | 7.7 |
| JOINT KNOWS CHALLENGE | 0.1 | -2.3 | 0.0 | 0.0 | 0.2 | -3.3 | 17.8 | 30.1 |
| KEEP FALLS | 0.1 | +0.9 | 0.0 | 0.0 | - | - | - | - |
| KEEPS ITS PREY | 0.1 | +1.0 | 11.9 | 0.0 | 0.1 | +0.0 | 3.1 | 0.0 |
| KEEPS ITS TARGET | 1.4 | +43.3 | 148.6 | 49.3 | 2.5 | +74.2 | 193.2 | 59.9 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| KILLS COUNT | 1.6 | +87.3 | 135.2 | 41.4 | 2.4 | +109.9 | 237.9 | 24.4 |
| KILLS COUNT NEXT TURN | 4.7 | +180.4 | 175.6 | 103.1 | 7.4 | +267.3 | 460.3 | 208.6 |
| LONE CHARACTER SAFE SPOT | 0.2 | +6.1 | 17.6 | 2.4 | 0.2 | +8.6 | 10.9 | 29.5 |
| LONE WIZARD HOLDS BACK | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 12.7 | 10.7 |
| LONE WIZARD KEPT IN | 0.6 | +39.4 | 0.0 | 0.0 | 0.3 | +23.5 | 0.0 | 0.0 |
| LONG SHOT | 0.7 | -3.1 | 32.5 | 21.7 | 0.6 | -2.4 | 38.4 | 11.2 |
| LOST CHARGE | 2.7 | -50.8 | 130.8 | 129.2 | 2.1 | -32.8 | 66.3 | 94.1 |
| LURE BY WHAT IT DRAWS | 0.2 | -13.5 | 0.0 | 2.5 | 0.2 | -19.4 | 0.0 | 5.1 |
| MAKE SURE TOGETHER | 0.2 | +4.3 | 0.0 | 13.6 | 0.4 | +33.1 | 35.1 | 3.0 |
| MANOEUVRE | 0.3 | +10.3 | 0.0 | 1.0 | 0.2 | +4.7 | 0.0 | 2.8 |
| MARCH AT ESCAPER | - | - | - | - | 0.1 | +0.9 | 0.0 | 0.0 |
| MARCH CHECK | 0.4 | +8.5 | 0.0 | 4.5 | 0.4 | +12.9 | 0.0 | 7.2 |
| MARCH ODDS | 0.4 | +33.4 | 6.3 | 0.0 | 0.1 | +6.8 | 0.0 | 5.7 |
| MARCH OVER CASTS | 0.4 | +46.0 | 0.0 | 48.5 | 0.2 | +3.9 | 0.0 | 12.1 |
| MAX FOR POSITIONING | 6.4 | +96.3 | 0.0 | 183.6 | 6.1 | +91.7 | 0.0 | 140.3 |
| MISSILES IN THE MOVE | 4.0 | +134.6 | 0.0 | 93.2 | 3.2 | +67.4 | 0.0 | 86.0 |
| MISSILES NEXT TURN | 4.6 | +76.0 | 0.0 | 137.2 | 3.6 | +45.2 | 0.0 | 114.6 |
| MODEL FACING | 0.3 | +73.0 | 0.0 | 0.0 | 0.2 | +54.5 | 0.0 | 1.7 |
| MONSTER WIZARD ROAMS | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 19.9 | 0.0 |
| MOVE AND CAST | 0.2 | +3.9 | 0.0 | 4.5 | 0.3 | +11.9 | 0.0 | 16.2 |
| MOVE SPELL IN RANGE | 0.1 | +5.5 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.2 | -9.9 | 0.0 | 32.2 | 0.3 | -5.9 | 0.0 | 0.0 |
| MOVE SPELL SPOT | 0.2 | +0.0 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE | 2.6 | +129.9 | 82.3 | 89.9 | 5.5 | +331.0 | 326.4 | 172.6 |
| MOVES UNITS SPELL | 0.1 | +3.4 | 0.0 | 0.0 | - | - | - | - |
| NEEDED THERE | 0.1 | +3.6 | 5.7 | 0.0 | 0.1 | +11.3 | 7.4 | 7.0 |
| NOT NEEDED | - | - | - | - | 0.3 | -15.6 | 59.4 | 4.6 |
| NOT TURNED | 5.8 | +89.9 | 0.0 | 144.5 | 5.0 | +46.0 | 0.0 | 130.4 |
| NOT WORTH A CAST | 0.6 | -0.4 | 0.0 | 0.0 | 0.7 | -0.6 | 0.0 | 7.6 |
| OFF BEST | 15.9 | -631.7 | 0.0 | 273.2 | 16.9 | -822.3 | 13.3 | 230.6 |
| ONE FIGHT FORMULA | 9.1 | -136.9 | 62.0 | 219.5 | 8.9 | -169.4 | 53.1 | 280.9 |
| ONE OBJECTIVE FORMULA | 1.9 | -106.5 | 0.0 | 28.6 | 2.1 | -131.7 | 0.0 | 21.4 |
| OPENS A LANE | 0.4 | +2.1 | 16.7 | 3.5 | 0.1 | +1.1 | 2.7 | 0.0 |
| OPENS UP | 0.0 | +1.8 | 3.1 | 0.0 | 0.1 | +1.7 | 0.0 | 0.0 |
| OVERRUN THREAT | - | - | - | - | 0.0 | +0.7 | 0.0 | 0.0 |
| OVERRUNS AWAY | 0.4 | +11.8 | 46.6 | 2.4 | 0.5 | +3.7 | 36.0 | 3.2 |
| PAIR SET-UP | - | - | - | - | 0.2 | +0.0 | 9.6 | 10.5 |
| PATHS CROSS | 1.9 | +110.8 | 0.0 | 35.8 | 2.9 | +171.5 | 0.0 | 101.9 |
| PERIAPT WORTH | 0.1 | +4.6 | 0.0 | 0.0 | 0.0 | +2.0 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.1 | -2.5 | 0.0 | 27.7 | 0.0 | -4.3 | 0.0 | 0.0 |
| PLAN RESULT | 36.8 | +1709.5 | 1677.2 | 984.9 | 41.5 | +1434.1 | 1690.8 | 911.5 |
| PURSUES BIG PREY | 0.1 | -10.3 | 0.0 | 0.0 | 0.1 | -11.5 | 0.0 | 13.9 |
| RAIDS THE BAGGAGE NEXT TURN | 0.1 | +5.0 | 0.0 | 3.4 | 0.0 | +2.4 | 0.0 | 0.0 |
| RANDOM MOVE BY FIGURES | 0.8 | +15.3 | 0.0 | 15.7 | 1.5 | +29.6 | 0.0 | 46.2 |
| RANDOM MOVER NO PROMISE | 0.1 | -4.0 | 8.0 | 0.0 | 0.1 | -1.9 | 7.3 | 4.7 |
| REDIRECT BY WHAT IT STOPS | 0.6 | -11.3 | 0.0 | 19.4 | 1.1 | -30.2 | 0.0 | 38.2 |
| REDIRECT COUNTER | 2.2 | +137.1 | 0.0 | 52.9 | 3.4 | +233.4 | 0.0 | 64.6 |
| REDIRECT WEIGHED | 0.1 | +1.1 | 3.5 | 0.0 | 0.2 | +0.5 | 3.1 | 0.9 |
| REFUSING RETIRES | 0.4 | +0.0 | 0.0 | 11.2 | 0.4 | +0.0 | 0.0 | 24.0 |
| RESERVE FALL BACK | 0.3 | +5.7 | 0.0 | 2.2 | 1.1 | +32.3 | 0.0 | 27.4 |
| RESTRAINS TO SHOOT | 0.1 | +6.0 | 0.0 | 0.0 | 0.0 | +0.2 | 0.0 | 0.0 |
| RISK BY ARC | 2.0 | +67.5 | 207.0 | 67.9 | 3.4 | +75.8 | 333.1 | 63.3 |
| RISK ONCE | 4.9 | +126.4 | 56.4 | 154.1 | 3.9 | +167.7 | 72.4 | 322.8 |
| SAFER THAN THE JOB | 0.9 | +29.0 | 0.0 | 24.6 | 0.6 | +40.7 | 0.0 | 21.1 |
| SCOUT SPOT | 0.3 | +0.9 | 0.0 | 0.0 | 0.5 | +2.4 | 0.0 | 0.0 |
| SCOUT WAITS | 0.3 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.2 | -9.6 | 0.0 | 1.2 | 0.5 | -36.4 | 0.0 | 5.7 |
| SEARCH SPOT | 2.1 | +106.2 | 0.0 | 39.3 | 2.7 | +102.1 | 0.0 | 85.1 |
| SECOND CHARGER ADDS | 0.2 | -9.4 | 50.7 | 0.8 | - | - | - | - |
| SECOND HUNTER | - | - | - | - | 0.2 | -0.7 | 25.6 | 1.8 |
| SELF MOVE SPELL | 0.1 | +2.0 | 0.0 | 21.9 | - | - | - | - |
| SET UP TOGETHER | 0.5 | +9.6 | 0.0 | 35.6 | 2.0 | +133.6 | 87.1 | 62.2 |
| SET-UP ANY TARGET | 0.1 | +19.4 | 0.0 | 0.0 | 0.1 | +8.2 | 0.0 | 0.0 |
| SET-UP MISSED | - | - | - | - | 0.0 | +5.6 | 0.0 | 0.0 |
| SHOOTER COUNTED ONCE | 0.0 | -0.2 | 0.0 | 0.0 | 0.1 | -0.2 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.4 | +0.8 | 0.0 | 0.0 | 0.3 | +0.6 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.1 | +31.7 | 59.2 | 25.1 | 0.6 | +22.7 | 49.9 | 5.7 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| SHOT REPLANNED | 0.8 | +0.0 | 224.5 | 24.5 | 0.1 | +0.0 | 7.0 | 0.0 |
| SHOTS IN THE MOVE | 13.8 | +740.0 | 0.0 | 276.5 | 11.8 | +367.1 | 0.0 | 191.9 |
| SPELL SETS UP CHARGE | 0.2 | +43.4 | 0.0 | 0.0 | 0.1 | +15.7 | 0.0 | 0.0 |
| SPELL WORTH | 0.8 | +14.4 | 82.8 | 69.7 | 1.5 | +28.3 | 43.8 | 43.8 |
| SPELLS IN THE FIGHT | 0.4 | +2.4 | 49.1 | 17.7 | 0.7 | -14.0 | 85.4 | 5.4 |
| STABLE ROLE | 10.9 | +0.0 | 539.7 | 171.9 | 12.2 | +0.0 | 386.8 | 104.2 |
| STANDS TO CAST | 0.1 | +1.9 | 2.4 | 11.1 | - | - | - | - |
| STAY WEIGHED | 0.1 | +11.9 | 0.0 | 0.0 | 0.0 | +2.0 | 0.0 | 0.0 |
| STOPS | 0.1 | +0.5 | 8.8 | 1.4 | 0.3 | +11.4 | 38.3 | 1.8 |
| STOPS SHORT OF THE FLANK | 0.4 | +17.3 | 0.0 | 31.1 | 0.3 | +16.3 | 0.0 | 25.9 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 14.6 |
| SUPPORT NARROWED | 7.1 | -75.4 | 397.1 | 155.4 | 8.6 | -86.8 | 491.2 | 79.6 |
| SUPPORTS | 5.1 | +83.4 | 240.5 | 78.4 | 6.1 | +87.7 | 182.4 | 63.1 |
| SURE CHARGE BEATS ADVANCE | 0.1 | -2.4 | 12.9 | 0.0 | 0.3 | -10.0 | 23.1 | 0.0 |
| SURE REACH TOGETHER | 0.4 | +2.1 | 0.0 | 32.8 | 0.9 | -1.2 | 5.5 | 2.9 |
| THROUGH LINE OF FIRE | 0.2 | +8.7 | 0.0 | 4.5 | 0.2 | +10.1 | 0.0 | 12.0 |
| TURN WORTH | 0.4 | -29.0 | 24.2 | 5.8 | 0.2 | -9.5 | 15.5 | 0.0 |
| TWO OR MORE ARRIVE | 0.1 | +0.4 | 0.0 | 0.0 | 0.3 | +1.2 | 16.8 | 3.0 |
| WAIT AFTER COSTS | 5.7 | -294.6 | 193.1 | 130.8 | 8.9 | -398.0 | 523.9 | 229.0 |
| WALKS TO THE FIGHT | 1.6 | +15.4 | 43.6 | 8.5 | 1.4 | +8.4 | 28.9 | 17.0 |
| WAR ENGINE CHARGES | 0.0 | +4.9 | 0.0 | 0.0 | 0.1 | +1.8 | 0.0 | 0.0 |
| WAR ENGINE JOBS | 0.9 | +0.0 | 61.4 | 12.5 | 0.6 | +0.0 | 46.1 | 13.3 |
| WEARS DOWN | 0.9 | +35.0 | 111.6 | 23.5 | 1.5 | +45.0 | 162.0 | 56.8 |
| WHO HITS BACK | 0.1 | +2.7 | 0.0 | 12.0 | 0.1 | +7.1 | 0.0 | 3.5 |
| WHOLE FIGHT | 0.1 | +1.7 | 28.1 | 0.0 | 0.3 | +27.0 | 84.2 | 0.0 |
| WHOLE FIGHT GAIN | 0.4 | +13.5 | 55.6 | 6.2 | 0.9 | +66.3 | 66.8 | 11.7 |
| WIDER SPREAD | 2.1 | -7.4 | 223.8 | 57.0 | 3.3 | -3.4 | 380.4 | 33.8 |
| WOUNDED STAYS OUT | - | - | - | - | 0.0 | +0.0 | 0.0 | 16.6 |

### Rule changes: jc-mine-1e5408d-p2

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 1184 | 1184 | 1184 | 32.89 | -52342 | -44.2 |
| PATHS CROSS | 172 | 172 | 172 | 4.78 | +10164 | +59.1 |
| SUPPORTS | 403 | 403 | 169 | 4.69 | +2214 | +13.1 |
| SEARCH SPOT | 172 | 172 | 167 | 4.64 | +7496 | +44.9 |
| MOVE TO CHARGE | 290 | 290 | 149 | 4.14 | +5516 | +37.0 |
| KILLS COUNT NEXT TURN | 434 | 434 | 142 | 3.94 | +4997 | +35.2 |
| FACES THE THREAT | 109 | 109 | 109 | 3.03 | +7349 | +67.4 |
| SHOTS IN THE MOVE | 923 | 615 | 97 | 2.69 | +3052 | +31.5 |
| BEST FIRST | 89 | 89 | 89 | 2.47 | +4297 | +48.3 |
| COVER ONCE | 557 | 327 | 83 | 2.31 | +1449 | +17.5 |
| WAIT AFTER COSTS | 527 | 527 | 82 | 2.28 | +1677 | +20.4 |
| FALLBACK BY WORTH | 344 | 344 | 75 | 2.08 | +2783 | +37.1 |
| ADVANCE WORTH | 398 | 398 | 70 | 1.94 | +1086 | +15.5 |
| CANNON SIGHT KEPT | 70 | 70 | 70 | 1.94 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 64 | 64 | 64 | 1.78 | +8943 | +139.7 |
| RISK ONCE | 320 | 222 | 60 | 1.67 | +1691 | +28.2 |
| ARTILLERY RE-ROLL WEIGHED | 58 | 58 | 58 | 1.61 | +0 | +0.0 |
| CHAFF IN THE MOVE | 96 | 90 | 56 | 1.56 | +1543 | +27.6 |
| SAFER THAN THE JOB | 54 | 54 | 54 | 1.50 | +2509 | +46.5 |
| RESERVE FALL BACK | 50 | 50 | 50 | 1.39 | +1368 | +27.4 |
| RISK BY ARC | 196 | 192 | 50 | 1.39 | +1285 | +25.7 |
| CANNON PLANNED TARGET | 256 | 256 | 49 | 1.36 | -1119 | -22.8 |
| KILLS COUNT | 142 | 141 | 48 | 1.33 | +2263 | +47.1 |
| MISSILES IN THE MOVE | 257 | 161 | 47 | 1.31 | +1371 | +29.2 |
| RANDOM MOVE BY FIGURES | 81 | 81 | 47 | 1.31 | +1619 | +34.4 |
| WALKS TO THE FIGHT | 108 | 108 | 46 | 1.28 | +282 | +6.1 |
| ONE FIGHT FORMULA | 649 | 390 | 45 | 1.25 | +167 | +3.7 |
| IDLE COST | 1203 | 704 | 44 | 1.22 | +521 | +11.8 |
| ADVANCE LANE KEPT | 42 | 42 | 42 | 1.17 | +0 | +0.0 |
| SET UP TOGETHER | 92 | 77 | 42 | 1.17 | +1914 | +45.6 |
| REDIRECT COUNTER | 204 | 100 | 41 | 1.14 | +2709 | +66.1 |
| HOLDS AMBUSHERS | 40 | 40 | 40 | 1.11 | +0 | +0.0 |
| HONEST WORTH | 633 | 631 | 36 | 1.00 | +252 | +7.0 |
| CHARGE NOW WEIGHED | 34 | 34 | 34 | 0.94 | +3320 | +97.7 |
| BLOCKED WHEEL | 33 | 33 | 33 | 0.92 | +591 | +17.9 |
| CHARGE NOW FIRST | 166 | 166 | 33 | 0.92 | -1286 | -39.0 |
| LONE WIZARD KEPT IN | 33 | 33 | 33 | 0.92 | +2266 | +68.7 |
| SCOUT WAITS | 32 | 32 | 32 | 0.89 | +0 | +0.0 |
| SHOT REPLANNED | 32 | 32 | 32 | 0.89 | +0 | +0.0 |
| MARCH CHECK | 31 | 31 | 30 | 0.83 | +1347 | +44.9 |
| MAX FOR POSITIONING | 447 | 278 | 28 | 0.78 | +115 | +4.1 |
| BEST OVERALL | 26 | 26 | 26 | 0.72 | +1242 | +47.8 |
| STOPS SHORT OF THE FLANK | 26 | 26 | 26 | 0.72 | +1210 | +46.5 |
| SHOOTERS IN TWO RANKS | 25 | 25 | 25 | 0.69 | +50 | +2.0 |
| BEST FACING | 24 | 24 | 24 | 0.67 | +1038 | +43.3 |
| INVITES THE FIGHT | 74 | 74 | 24 | 0.67 | +198 | +8.3 |
| WAR ENGINE JOBS | 55 | 55 | 24 | 0.67 | -1052 | -43.8 |
| COMBAT PIVOT | 23 | 23 | 23 | 0.64 | +0 | +0.0 |
| WHOLE FIGHT GAIN | 44 | 43 | 23 | 0.64 | +640 | +27.8 |
| CASTING BLOCK | 37 | 37 | 22 | 0.61 | +687 | +31.2 |
| MOVE AND CAST | 21 | 21 | 21 | 0.58 | +569 | +27.1 |
| BEST PREY | 60 | 60 | 19 | 0.53 | +763 | +40.2 |
| CAST JOB | 46 | 46 | 19 | 0.53 | +449 | +23.6 |
| MARCH ODDS | 18 | 18 | 18 | 0.50 | +325 | +18.1 |
| MODEL FACING | 17 | 17 | 17 | 0.47 | +4589 | +269.9 |
| SHOOTS FROM THE BEST SPOT | 61 | 61 | 17 | 0.47 | +685 | +40.3 |
| CASTER AWAY FROM SCREEN | 16 | 16 | 16 | 0.44 | +0 | +0.0 |
| WEARS DOWN | 84 | 82 | 16 | 0.44 | +352 | +22.0 |
| CASTS FROM BEHIND | 15 | 15 | 15 | 0.42 | +0 | +0.0 |
| KEEPS ITS TARGET | 141 | 141 | 15 | 0.42 | +265 | +17.7 |
| THROUGH LINE OF FIRE | 15 | 15 | 15 | 0.42 | +676 | +45.1 |
| CHAFF PASSED | 14 | 14 | 14 | 0.39 | -18 | -1.3 |
| SHORT GUN FORWARD | 14 | 14 | 14 | 0.39 | +0 | +0.0 |
| SURE CHARGE BEATS ADVANCE | 14 | 14 | 14 | 0.39 | -446 | -31.9 |
| MANOEUVRE | 16 | 16 | 13 | 0.36 | +539 | +41.5 |
| STUCK PIVOT | 13 | 13 | 13 | 0.36 | +0 | +0.0 |
| REDIRECT WEIGHED | 12 | 12 | 12 | 0.33 | +795 | +66.3 |
| HUNT IN PAIRS | 31 | 20 | 11 | 0.31 | +501 | +45.6 |
| SUPPORT NARROWED | 565 | 565 | 10 | 0.28 | -105 | -10.5 |
| BIG CHARACTER SAFETY | 8 | 8 | 8 | 0.22 | +43 | +5.4 |
| FRIENDS SHOTS CHECKED | 8 | 8 | 8 | 0.22 | +413 | +51.6 |
| REFUSING RETIRES | 27 | 27 | 8 | 0.22 | -1 | -0.1 |
| WHO HITS BACK | 8 | 8 | 8 | 0.22 | +276 | +34.5 |
| PURSUES BIG PREY | 7 | 7 | 7 | 0.19 | -786 | -112.2 |
| BLOCKED CHARGE SKIPPED | 6 | 6 | 6 | 0.17 | +0 | +0.0 |
| MISSILES NEXT TURN | 295 | 172 | 6 | 0.17 | +36 | +6.1 |
| PIVOT GUARDS FLANK | 6 | 6 | 6 | 0.17 | -244 | -40.6 |
| LOST CHARGE | 175 | 175 | 5 | 0.14 | +168 | +33.6 |
| ONE OBJECTIVE FORMULA | 141 | 78 | 5 | 0.14 | +127 | +25.5 |
| FOCUS FIRE | 4 | 4 | 4 | 0.11 | +190 | +47.5 |
| KEEPS SCOUTS OR AMBUSH | 4 | 4 | 4 | 0.11 | +0 | +0.0 |
| MOVES UNITS SPELL | 4 | 4 | 4 | 0.11 | +122 | +30.4 |
| NEEDED THERE | 5 | 5 | 4 | 0.11 | +0 | +0.0 |
| OVERRUNS AWAY | 33 | 33 | 4 | 0.11 | +170 | +42.6 |
| RESTRAINS TO SHOOT | 4 | 4 | 4 | 0.11 | +222 | +55.5 |
| SURE REACH TOGETHER | 44 | 33 | 4 | 0.11 | +0 | +0.0 |
| WHOLE FIGHT | 17 | 17 | 4 | 0.11 | +344 | +86.0 |
| BOMBING RUN | 3 | 3 | 3 | 0.08 | +122 | +40.8 |
| DEFENSIVE ARMY | 15 | 15 | 3 | 0.08 | -117 | -39.0 |
| FIRE AND FLEE | 3 | 3 | 3 | 0.08 | +122 | +40.6 |
| LONE WIZARD HOLDS BACK | 13 | 13 | 3 | 0.08 | +0 | +0.0 |
| PERIAPT WORTH | 3 | 3 | 3 | 0.08 | +239 | +79.7 |
| RAIDS THE BAGGAGE NEXT TURN | 3 | 3 | 3 | 0.08 | +214 | +71.4 |
| SPELLS IN THE FIGHT | 38 | 37 | 3 | 0.08 | +62 | +20.5 |
| STANDS TO CAST | 3 | 3 | 3 | 0.08 | -45 | -14.9 |
| STAY WEIGHED | 3 | 3 | 3 | 0.08 | +499 | +166.5 |
| WIDER SPREAD | 196 | 192 | 3 | 0.08 | +5 | +1.7 |
| BOUND ASSAILMENT | 2 | 2 | 2 | 0.06 | +0 | +0.2 |
| EDGE GIVE GROUND | 19 | 18 | 2 | 0.06 | +38 | +18.9 |
| HUNT ADVANCE | 21 | 21 | 2 | 0.06 | +11 | +5.5 |
| KEEP FALLS | 2 | 2 | 2 | 0.06 | +126 | +63.1 |
| MAKE SURE TOGETHER | 25 | 15 | 2 | 0.06 | +45 | +22.6 |
| BACKUP TARGETS | 49 | 29 | 1 | 0.03 | +1 | +0.7 |
| BLOWS WHERE AIMED | 16 | 15 | 1 | 0.03 | +45 | +45.3 |
| CATCH ODDS | 1 | 1 | 1 | 0.03 | -5 | -4.7 |
| CHARGER SLAIN LOST | 37 | 35 | 1 | 0.03 | +28 | +28.1 |
| CONTINUE AHEAD WEIGHED | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| HORN WORTH | 1 | 1 | 1 | 0.03 | +3 | +3.0 |
| JOINT CHARGE PLAN | 7 | 7 | 1 | 0.03 | +62 | +61.6 |
| KEEPS ITS PREY | 5 | 5 | 1 | 0.03 | +2 | +1.5 |
| MOVE SPELL IN RANGE | 4 | 3 | 1 | 0.03 | +1 | +1.1 |
| STOPS | 14 | 13 | 1 | 0.03 | +9 | +9.3 |
| TWO OR MORE ARRIVE | 17 | 14 | 1 | 0.03 | +10 | +10.5 |
| WOUNDED STAYS OUT | 1 | 1 | 1 | 0.03 | -288 | -287.7 |
| ARRIVAL HUNT | 4 | 4 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 38 | 38 | 0 | 0.00 | - | - |
| CARRIES OUT SET-UP | 9 | 9 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 24 | trace | - | - | - | - |
| CATCH FLIERS | 2 | not checked | - | - | - | - |
| CHARIOT WIZARD CAREFUL | 2 | 2 | 0 | 0.00 | - | - |
| CHEAP HELPER | 7 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 30 | not checked | - | - | - | - |
| DEFENSIVE FLOOR | 2 | 2 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT LIFT | 2 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 366 | not checked | - | - | - | - |
| FRIEND IN REACH | 319 | not checked | - | - | - | - |
| GIVES UP | 4 | 3 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 3 | 3 | 0 | 0.00 | - | - |
| HELPER ALREADY ASKED | 2 | not checked | - | - | - | - |
| HELPER UNSEEN | 28 | 27 | 0 | 0.00 | - | - |
| HILL BY ITS CHANCE | 33 | 33 | 0 | 0.00 | - | - |
| HUNT DROPPED | 10 | trace | - | - | - | - |
| HUNT KEPT | 13 | trace | - | - | - | - |
| HUNT RESULT | 22 | trace | - | - | - | - |
| HUNT THE GUNS | 24 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 8 | 6 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 17 | not checked | - | - | - | - |
| LONG SHOT | 46 | 45 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 13 | 13 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 3 | trace | - | - | - | - |
| MARCH OVER CASTS | 21 | 21 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 8 | 8 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 20 | trace | - | - | - | - |
| MOVE SPELL SPOT | 8 | not checked | - | - | - | - |
| NOT NEEDED | 12 | 12 | 0 | 0.00 | - | - |
| NOT TURNED | 390 | 390 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 47 | not checked | - | - | - | - |
| OPENS A LANE | 16 | 8 | 0 | 0.00 | - | - |
| OPENS UP | 3 | 3 | 0 | 0.00 | - | - |
| OVERRUN THREAT | 1 | not checked | - | - | - | - |
| PAIR SET-UP | 6 | not checked | - | - | - | - |
| PLAN RESULT | 2818 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 7 | 7 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 60 | 60 | 0 | 0.00 | - | - |
| SCOUT SPOT | 28 | 28 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 25 | 25 | 0 | 0.00 | - | - |
| SECOND CHARGER ADDS | 7 | 7 | 0 | 0.00 | - | - |
| SECOND HUNTER | 7 | 7 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 4 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 8 | not checked | - | - | - | - |
| SET-UP MISSED | 1 | trace | - | - | - | - |
| SHOOTER COUNTED ONCE | 3 | 3 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 11 | not checked | - | - | - | - |
| SPELL WORTH | 82 | not checked | - | - | - | - |
| STABLE ROLE | 833 | 833 | 0 | 0.00 | - | - |
| TURN WORTH | 23 | 23 | 0 | 0.00 | - | - |
| WAR ENGINE CHARGES | 4 | 4 | 0 | 0.00 | - | - |

### Off best figure: jc-mine-1e5408d-p2

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 14.22 | 15.03 | 45.1 |
| FALLBACK | gate | 0.64 | 0.75 | 42.3 |
| TURN GATE | gate | 0.67 | 0.56 | 34.0 |
| CHARGE NOW FIRST | rule | 0.42 | 0.47 | 40.2 |
| WAR ENGINE JOBS | rule | 0.42 | 0.25 | 43.9 |
| AFTERMATH BAND | gate | 0.19 | 0.22 | 2.0 |
| CANNON PLANNED TARGET | rule | 0.39 | 0.03 | 79.3 |
| SURE CHARGE BEATS ADVANCE | rule | 0.11 | 0.28 | 31.9 |
| SUPPORT NARROWED | rule | 0.14 | 0.11 | 11.6 |
| PURSUES BIG PREY | rule | 0.06 | 0.14 | 112.2 |
| SUPPORT REQUEST | gate | - | 0.19 | 123.6 |
| CHAFF PASSED | rule | 0.06 | 0.11 | 2.9 |
| LONE CHARACTER SAFE SPOT | gate | 0.08 | 0.08 | 20.7 |
| PIVOT GUARDS FLANK | rule | 0.14 | 0.03 | 40.6 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.08 | 0.03 | 46.6 |
| FIGHT ORDER BAND | gate | 0.06 | 0.06 | 1.4 |
| CHARGE NOW WEIGHED | rule | 0.06 | 0.03 | 21.9 |
| DEFENSIVE ARMY | rule | 0.03 | 0.06 | 39.0 |
| MOVE AND CAST | rule | 0.03 | 0.06 | 17.6 |
| PATHS CROSS | rule | 0.03 | 0.06 | 27.5 |
| BLOCKED WHEEL | rule | - | 0.06 | 19.4 |
| FRIENDS SHOTS CHECKED | rule | 0.03 | 0.03 | 2.8 |
| REFUSING RETIRES | rule | 0.06 | - | 0.8 |
| THROUGH LINE OF FIRE | rule | 0.06 | - | 22.1 |
| BIG CHARACTER SAFETY | rule | 0.03 | - | 0.7 |
| CATCH ODDS | rule | - | 0.03 | 4.7 |
| FOLLOW UP WEIGHED | rule | 0.03 | - | 1.2 |
| MARCH ODDS | rule | - | 0.03 | 2.7 |
| RULE SWITCHED OFF | gate | - | 0.03 | 18.9 |
| STANDS TO CAST | rule | 0.03 | - | 44.8 |
| STOPS SHORT OF THE FLANK | rule | 0.03 | - | 0.7 |
| WOUNDED STAYS OUT | rule | - | 0.03 | 287.7 |

### Plans: jc-mine-1e5408d-p2

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 9.8 | 19% | 225 | 356 | 158% |
| Mine | charge | 2.7 | 67% | 201 | 245 | 122% |
| Mine | close in | 4.0 | 22% | 220 | 132 | 60% |
| Mine | hold | 4.8 | 29% | 311 | 0 | 0% |
| Mine | join | 0.6 | 95% | 21 | 0 | 0% |
| Mine | shoot | 9.1 | 68% | 346 | 977 | 282% |
| Mine | support | 5.9 | 90% | 59 | 0 | 0% |
| Opponent | advance | 11.5 | 17% | 153 | 286 | 187% |
| Opponent | charge | 4.8 | 64% | 404 | 517 | 128% |
| Opponent | close in | 7.3 | 30% | 434 | 262 | 60% |
| Opponent | hold | 4.2 | 48% | 294 | 0 | 0% |
| Opponent | join | 0.8 | 96% | 35 | 0 | 0% |
| Opponent | shoot | 5.5 | 49% | 210 | 368 | 175% |
| Opponent | support | 7.5 | 89% | 85 | 0 | 0% |

### Packages: hunt the guns, jc-mine-1e5408d-p2

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.1 | 2 | 0 | 100% | 100% | 0% | 2.5 | 178 | 171 | 100% | 50 |
| Opponent | 0.6 | 22 | 2 | 40% | 50% | 0% | 2.2 | 342 | 173 | 45% | 77 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.2 | 1 | 0 | 100% | 100% | 0% | 2.0 | 122 | 122 | 100% | 0 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 315 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 70 |
| Empire of Man | 0.1 | 1 | 0 | 0% | 0% | 0% | - | 142 | 0 | 0% | 58 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 143 |
| High Elf Realms | 0.2 | 1 | 0 | 100% | 100% | 0% | 3.0 | 233 | 221 | 100% | 0 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Ogre Kingdoms | 1.5 | 6 | 0 | 83% | 100% | 0% | 2.3 | 470 | 356 | 83% | 151 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 48 |
| Tomb Kings of Khemri | 1.8 | 9 | 2 | 29% | 43% | 0% | 2.0 | 185 | 103 | 43% | 0 |
| Vampire Counts | 0.1 | 1 | 0 | 0% | 0% | 0% | - | 374 | 0 | 0% | 0 |
| Warriors of Chaos | 0.2 | 2 | 0 | 0% | 0% | 0% | - | 467 | 0 | 0% | 20 |
| Wood Elf Realms | 0.4 | 3 | 0 | 33% | 33% | 0% | 2.0 | 423 | 200 | 33% | 103 |

### Battle groups: jc-mine-1e5408d-p2

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 2.2 | 31% | 76% | 8% | 0% | 0% | 0% | 9% | 91% | 0% |
| Opponent | REDIRECT COUNTER | 3.4 | 20% | 76% | 16% | 50% | 52% | 5% | 5% | 33% | 5% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: jc-mine-1e5408d-p2

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 5 | 0 (5) | 0 | 0 | 52 | 20% | 2.8 | 0 (1) | 0 (1) | - | 0 (1) | 0 (1) |
| Mine | Chaff | 34 | 91 (34) | 48 | 43 | 58 | 47% | 2.7 | 69 (19) | 227 (7) | 22 (8) | 123 (23) | 19 (11) |
| Mine | Character | 123 | 53 (123) | 53 | 0 | 38 | 20% | 2.6 | 47 (41) | 62 (51) | 51 (17) | 71 (53) | 39 (56) |
| Mine | Clean-up | 21 | 34 (21) | 4 | 30 | 42 | 57% | 2.8 | 15 (5) | 37 (13) | 71 (3) | 62 (13) | 5 (8) |
| Mine | Fast | 1 | 0 (1) | 0 | 0 | 0 | 0% | 5.0 | - | 0 (1) | - | 0 (1) | - |
| Mine | Fast Hammer | 48 | 39 (48) | 19 | 20 | 38 | 21% | 3.0 | 35 (23) | 58 (16) | 18 (9) | 44 (29) | 32 (19) |
| Mine | Fragile | 5 | 149 (5) | 149 | 0 | 20 | 0% | 2.6 | - | 87 (3) | 242 (2) | 149 (5) | - |
| Mine | Hammer | 57 | 30 (57) | 22 | 8 | 35 | 21% | 2.5 | 19 (18) | 39 (29) | 26 (10) | 28 (38) | 33 (19) |
| Mine | Holder | 28 | 55 (28) | 1 | 54 | 29 | 36% | 2.7 | 39 (10) | 105 (9) | 12 (9) | 94 (17) | 0 (11) |
| Mine | Shooter | 41 | 90 (41) | 54 | 36 | 45 | 2% | 1.5 | 139 (5) | 98 (30) | 26 (6) | 118 (25) | 47 (16) |
| Mine | Support | 2 | 0 (2) | 0 | 0 | 34 | 50% | 6.0 | 0 (1) | 0 (1) | - | - | 0 (2) |
| Mine | War machine | 59 | 39 (59) | 39 | 0 | 54 | 2% | 1.2 | 0 (10) | 50 (37) | 30 (12) | 0 (10) | 46 (49) |
| Mine | Wizard | 22 | 15 (22) | 15 | 0 | 50 | 9% | 2.8 | 0 (5) | 70 (6) | 0 (5) | 0 (5) | 27 (11) |
| Opponent | Blocker | 2 | 85 (2) | 85 | 0 | 38 | 0% | 5.0 | 137 (1) | 0 (1) | - | 137 (1) | 0 (1) |
| Opponent | Chaff | 76 | 66 (76) | 20 | 45 | 54 | 41% | 2.2 | 93 (32) | 48 (19) | 45 (25) | 88 (54) | 14 (22) |
| Opponent | Character | 97 | 58 (97) | 58 | 0 | 41 | 27% | 2.3 | 68 (42) | 58 (41) | 0 (6) | 51 (62) | 74 (27) |
| Opponent | Clean-up | 19 | 39 (19) | 26 | 13 | 29 | 37% | 3.0 | 21 (9) | 68 (10) | - | 43 (14) | 25 (5) |
| Opponent | Early | 2 | 0 (2) | 0 | 0 | 0 | 50% | 5.0 | - | 0 (2) | - | 0 (1) | 0 (1) |
| Opponent | Fast Hammer | 48 | 35 (48) | 25 | 10 | 29 | 23% | 2.5 | 27 (22) | 33 (16) | 55 (10) | 29 (28) | 45 (20) |
| Opponent | Fragile | 5 | 193 (5) | 193 | 0 | 39 | 20% | 4.5 | - | 250 (4) | 0 (1) | 229 (4) | 0 (1) |
| Opponent | Hammer | 70 | 23 (70) | 19 | 4 | 41 | 27% | 3.2 | 22 (17) | 18 (42) | 51 (11) | 25 (43) | 19 (27) |
| Opponent | Holder | 35 | 111 (35) | 7 | 104 | 13 | 34% | 2.8 | 104 (8) | 126 (21) | 103 (4) | 143 (22) | 63 (11) |
| Opponent | Shooter | 33 | 76 (33) | 18 | 58 | 42 | 0% | 1.9 | 102 (8) | 77 (19) | 38 (6) | 117 (22) | 12 (11) |
| Opponent | Support | 3 | 0 (3) | 0 | 0 | 0 | 100% | - | 0 (1) | 0 (2) | - | 0 (1) | 0 (2) |
| Opponent | War machine | 24 | 63 (24) | 63 | 0 | 13 | 8% | 1.5 | 0 (6) | 97 (14) | 33 (4) | 38 (3) | 67 (21) |
| Opponent | Wizard | 26 | 0 (26) | 0 | 0 | 39 | 15% | 1.6 | 0 (10) | 0 (7) | 0 (7) | 0 (8) | 0 (16) |

### Charged fights: jc-mine-1e5408d-p2

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 292 | 76 | 1.2 | 1.4 | 60 | 10 | +50 | 0 of 5 | 5 of 5 | +88 | +25 |
| Mine | Chaos Dwarfs | 4 | 414 | 506 | 2.5 | 1.2 | 202 | 12 | +190 | 7 of 10 | 9 of 10 | -62 | +253 |
| Mine | Dwarfen Mountain Holds | 4 | 644 | 62 | 1.8 | 1.1 | 35 | 42 | -6 | 1 of 7 | 4 of 7 | +137 | -30 |
| Mine | Empire of Man | 5 | 462 | 98 | 1.6 | 1.1 | 62 | 71 | -10 | 3 of 8 | 6 of 8 | +210 | -41 |
| Mine | Grand Cathay | 4 | 452 | 195 | 2.2 | 1.3 | 87 | 0 | +87 | 3 of 9 | 6 of 9 | +218 | +21 |
| Mine | High Elf Realms | 4 | 74 | 502 | 2.2 | 1.1 | 223 | 16 | +207 | 3 of 9 | 7 of 9 | -18 | +235 |
| Mine | Kingdom of Bretonnia | 1 | 0 | 869 | 3.0 | 1.3 | 290 | 0 | +290 | 1 of 3 | 3 of 3 | +664 | +102 |
| Mine | Lizardmen | 1 | 0 | 45 | 3.0 | 1.0 | 15 | 0 | +15 | 2 of 3 | 2 of 3 | - | +15 |
| Mine | Ogre Kingdoms | 1 | 0 | 120 | 4.0 | 1.2 | 30 | 8 | +22 | 0 of 4 | 2 of 4 | -34 | +40 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 349 | 5.0 | 1.2 | 70 | 11 | +59 | 1 of 5 | 4 of 5 | +45 | +62 |
| Mine | Skaven | 2 | 254 | 185 | 4.0 | 1.0 | 46 | 62 | -16 | 1 of 8 | 6 of 8 | - | -16 |
| Mine | Tomb Kings of Khemri | 1 | 250 | 659 | 5.0 | 1.6 | 132 | 24 | +107 | 1 of 5 | 5 of 5 | +114 | +103 |
| Mine | Vampire Counts | 3 | 37 | 432 | 2.3 | 1.3 | 185 | 0 | +185 | 3 of 7 | 5 of 7 | +62 | +234 |
| Mine | Warriors of Chaos | 1 | 0 | 258 | 3.0 | 1.0 | 86 | 0 | +86 | 0 of 3 | 2 of 3 | - | +86 |
| **Mine** | all armies | 36 | 297 | 273 | 2.4 | 1.2 | 114 | 22 | +92 | 26 of 86 | 66 of 86 | +121 | +85 |
| Opponent | Dwarfen Mountain Holds | 2 | 94 | 116 | 4.0 | 1.8 | 29 | 0 | +29 | 1 of 8 | 4 of 8 | +30 | +27 |
| Opponent | Empire of Man | 2 | 630 | 100 | 1.0 | 1.0 | 100 | 0 | +100 | 0 of 2 | 2 of 2 | - | +100 |
| Opponent | Grand Cathay | 2 | 613 | 758 | 3.0 | 1.2 | 253 | 0 | +253 | 4 of 6 | 6 of 6 | +562 | +191 |
| Opponent | Kingdom of Bretonnia | 1 | 235 | 330 | 4.0 | 1.2 | 82 | 0 | +82 | 2 of 4 | 4 of 4 | +0 | +110 |
| Opponent | Ogre Kingdoms | 3 | 167 | 318 | 4.7 | 1.2 | 68 | 47 | +21 | 3 of 14 | 10 of 14 | -142 | +48 |
| Opponent | Skaven | 1 | 425 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 1 of 1 | 0 of 1 | - | +0 |
| Opponent | Tomb Kings of Khemri | 4 | 159 | 745 | 3.8 | 1.0 | 199 | 29 | +170 | 6 of 15 | 10 of 15 | - | +170 |
| Opponent | Vampire Counts | 6 | 0 | 756 | 3.8 | 1.3 | 197 | 52 | +146 | 14 of 23 | 18 of 23 | +314 | +86 |
| Opponent | Warriors of Chaos | 8 | 0 | 362 | 2.6 | 1.1 | 138 | 0 | +138 | 9 of 21 | 17 of 21 | +230 | +128 |
| Opponent | Wood Elf Realms | 7 | 32 | 427 | 3.9 | 1.2 | 111 | 12 | +99 | 10 of 27 | 20 of 27 | +124 | +95 |
| **Opponent** | all armies | 36 | 130 | 462 | 3.4 | 1.2 | 137 | 21 | +116 | 50 of 121 | 91 of 121 | +156 | +108 |

### Effective charges: jc-mine-1e5408d-p2

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 5 | 0 | 0 | 1 (net +120) | 2 (net +28) | 0 | 2 (net +38) | 0 | 20% (1 of 5) |
| Mine | Chaos Dwarfs | 10 | 1 (net +60) | 1 (net +406) | 4 (net +136) | 1 (net +265) | 0 | 3 (net +208) | 0 | 40% (4 of 10) |
| Mine | Dwarfen Mountain Holds | 7 | 0 | 0 | 2 (net -30) | 1 (net +0) | 0 | 4 (net +4) | 0 | 29% (2 of 7) |
| Mine | Empire of Man | 8 | 1 (net +0) | 0 | 3 (net -45) | 0 | 1 (net -288) | 3 (net +116) | 0 | 38% (3 of 8) |
| Mine | Grand Cathay | 9 | 3 (net +181) | 0 | 1 (net +0) | 0 | 1 (net +111) | 3 (net +0) | 1 | 12% (1 of 8) |
| Mine | High Elf Realms | 9 | 1 (net +0) | 0 | 2 (net +376) | 1 (net +301) | 3 (net +158) | 1 (net +234) | 1 | 25% (2 of 8) |
| Mine | Kingdom of Bretonnia | 3 | 0 | 0 | 2 (net +102) | 0 | 0 | 1 (net +664) | 0 | 67% (2 of 3) |
| Mine | Lizardmen | 3 | 1 (net +0) | 1 (net +0) | 0 | 0 | 0 | 0 | 1 | 0% (0 of 2) |
| Mine | Ogre Kingdoms | 4 | 0 | 0 | 0 | 0 | 2 (net +60) | 1 (net -34) | 1 | 0% (0 of 3) |
| Mine | Orc & Goblin Tribes | 5 | 0 | 0 | 1 (net +45) | 0 | 1 (net +54) | 1 (net +190) | 2 | 33% (1 of 3) |
| Mine | Skaven | 8 | 2 (net -116) | 0 | 3 (net +26) | 0 | 0 | 3 (net +10) | 0 | 38% (3 of 8) |
| Mine | Tomb Kings of Khemri | 5 | 0 | 0 | 0 | 1 (net +102) | 1 (net +125) | 3 (net +103) | 0 | 0% (0 of 5) |
| Mine | Vampire Counts | 7 | 2 (net +0) | 0 | 1 (net +599) | 0 | 3 (net +186) | 1 (net +140) | 0 | 14% (1 of 7) |
| Mine | Warriors of Chaos | 3 | 0 | 0 | 0 | 1 (net +0) | 1 (net +258) | 0 | 1 | 0% (0 of 2) |
| Opponent | Dwarfen Mountain Holds | 8 | 2 (net +0) | 0 | 3 (net +27) | 2 (net +75) | 0 | 1 (net +0) | 0 | 38% (3 of 8) |
| Opponent | Empire of Man | 2 | 0 | 1 (net +110) | 0 | 0 | 0 | 0 | 1 | 0% (0 of 1) |
| Opponent | Grand Cathay | 6 | 0 | 0 | 2 (net +626) | 3 (net +88) | 0 | 1 (net +0) | 0 | 33% (2 of 6) |
| Opponent | Kingdom of Bretonnia | 4 | 0 | 0 | 0 | 1 (net +120) | 1 (net +0) | 1 (net +95) | 1 | 0% (0 of 3) |
| Opponent | Ogre Kingdoms | 14 | 4 (net +42) | 0 | 4 (net -86) | 1 (net +45) | 0 | 3 (net +99) | 2 | 33% (4 of 12) |
| Opponent | Skaven | 1 | 1 (net +0) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 1) |
| Opponent | Tomb Kings of Khemri | 15 | 6 (net +196) | 0 | 2 (net +140) | 1 (net +420) | 1 (net +85) | 4 (net +107) | 1 | 14% (2 of 14) |
| Opponent | Vampire Counts | 23 | 2 (net +202) | 2 (net -194) | 6 (net +307) | 5 (net +246) | 1 (net +0) | 6 (net +8) | 1 | 27% (6 of 22) |
| Opponent | Warriors of Chaos | 21 | 4 (net +50) | 1 (net +563) | 3 (net +104) | 5 (net +240) | 1 (net +183) | 6 (net +54) | 1 | 15% (3 of 20) |
| Opponent | Wood Elf Realms | 27 | 4 (net +214) | 2 (net +141) | 5 (net +44) | 3 (net +111) | 1 (net +85) | 9 (net +91) | 3 | 21% (5 of 24) |

### Charged fights, damage counted: jc-mine-1e5408d-p2

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 11 | 271 | 312 | +34 | 97 | 100 | -3 | -0.9 |
| Mine | 50-54% | 2 | 240 | 284 | +203 | 203 | 0 | +203 | +84.6 |
| Mine | Effective (55-75%) | 20 | 248 | 232 | +107 | 175 | 32 | +143 | +57.6 |
| Mine | 76-89% | 7 | 352 | 124 | +103 | 106 | 46 | +61 | +17.2 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 26 | 225 | 174 | +100 | 132 | 19 | +113 | +50.2 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 13 | 509 | 109 | +109 | 147 | 63 | +84 | +16.5 |
| Mine | No odds | 7 | 277 | 97 | +40 | 71 | 24 | +47 | +16.9 |
| Mine | All fights | 86 | 294 | 187 | +92 | 135 | 41 | +93 | +31.7 |
| Opponent | Long shot (under 50%) | 23 | 242 | 248 | +122 | 204 | 85 | +118 | +48.9 |
| Opponent | 50-54% | 6 | 279 | 183 | +94 | 159 | 135 | +24 | +8.6 |
| Opponent | Effective (55-75%) | 25 | 244 | 206 | +146 | 169 | 48 | +121 | +49.5 |
| Opponent | 76-89% | 21 | 277 | 215 | +179 | 223 | 39 | +183 | +66.2 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 31 | 210 | 166 | +65 | 88 | 23 | +65 | +31.0 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 5 | 521 | 137 | +71 | 104 | 57 | +47 | +9.0 |
| Opponent | No odds | 10 | 202 | 150 | +90 | 109 | 8 | +102 | +50.2 |
| Opponent | All fights | 121 | 250 | 197 | +116 | 156 | 49 | +107 | +42.9 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| jc-mine-1e5408d-p2 | move | 389 | 87 (22%) | 61 (16%) | 42 (11%) | 260 (67%) |
| jc-mine-1e5408d-p2 | objective | 410 | 66 (16%) | 49 (12%) | 55 (13%) | 289 (70%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0106, L0122, L2429, L2535, L2735 |
| Charmed Shield | Opponent | L0425, L0827, L0934, L1026, L1727, L1827, L1927 |
| Clockwork Compass | Mine | L1228 |
| Clockwork Compass | Opponent | L0512 |
| Elixir of Power | Mine | L1118, L1135, L1927 |
| Fistful of Laurels | Mine | L1827 |
| Fistful of Laurels | Opponent | L0918, L1118, L1418 |
| Horn of the Wild Hunt | Opponent | L3033 |
| Invocation of Nehek | Mine | L2429, L2535, L2735 |
| Invocation of Nehek | Opponent | L0425, L0827, L1727, L1827, L1927 |
| Opal Amulet | Mine | L1418, L1435 |
| Periapt of Soul Exchange | Mine | L2029, L2131 |
| Periapt of Soul Exchange | Opponent | L0721 |
| Ring of Doom | Mine | L0206, L0222, L1118, L1135, L1228, L1531 |
| Ring of Doom | Opponent | L0512, L1531, L2131, L3033 |
| Ring of Jet | Mine | L1026, L1118, L1135, L1228 |
| Ring of Jet | Opponent | L0512, L0810 |
| Standard of the Fell Warrior | Mine | L1323 |
| Storm Daemon (Renegade 2.0) | Mine | L2131 |
| Storm Daemon (Renegade 2.0) | Opponent | L0721 |
| Twice-Blessed Armour | Mine | L0721, L1026 |
| Twice-Blessed Armour | Opponent | L0307, L0810 |
| Witch Hunter's Ward | Mine | L0721, L0810, L0827 |
| Witch Hunter's Ward | Opponent | L0307 |

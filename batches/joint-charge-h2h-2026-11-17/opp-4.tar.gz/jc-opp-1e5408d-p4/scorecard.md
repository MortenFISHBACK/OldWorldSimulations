# Doctrine scorecard: jc-opp-1e5408d-p4

### Scorecard: jc-opp-1e5408d-p4

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0114 | 6 | 1 | Mine | no | 4 | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| L0114 | 6 | 1 | Opponent | no | 8 | 1 | 1 | 1 | 0 | 0 | 0 | 0 |
| L0130 | 4 | 1 | Mine | no | 4 | - | 0 | 2 | 0 | 0 | 0 | 0 |
| L0130 | 4 | 1 | Opponent | no | 6 | 1 | 6 | 2 | 0 | 0 | 0 | 0 |
| L0214 | 4 | 1 | Mine | yes | 12 | 2 | 5 | 0 | 0 | 0 | 0 | 200 |
| L0214 | 4 | 1 | Opponent | yes | 3 | 1 | 3 | 0 | 0 | 0 | 0 | 177 |
| L0230 | 2 | 1 | Mine | - | - | 1 | 5 | 4 | 0 | 0 | 0 | 0 |
| L0230 | 2 | 1 | Opponent | - | - | 2 | 1 | 0 | 0 | 0 | 0 | 0 |
| L0315 | 3 | 1 | Mine | yes | 7 | 4 | 3 | 0 | 0 | 0 | 0 | 675 |
| L0315 | 3 | 1 | Opponent | yes | 7 | 2 | 5 | 1 | 0 | 0 | 0 | 0 |
| L0332 | 2 | 1 | Mine | - | - | - | 0 | 1 | 0 | 0 | 0 | 760 |
| L0332 | 2 | 1 | Opponent | - | - | 2 | 3 | 7 | 0 | 0 | 0 | 0 |
| L0417 | 3 | 1 | Mine | yes | 5 | 2 | 6 | 0 | 0 | 0 | 0 | 0 |
| L0417 | 3 | 1 | Opponent | yes | 3 | 2 | 3 | 0 | 0 | 0 | 0 | 0 |
| L0434 | 2 | 1 | Mine | - | - | 2 | 3 | 2 | 0 | 0 | 0 | 0 |
| L0434 | 2 | 1 | Opponent | - | - | 1 | 4 | 1 | 0 | 0 | 0 | 0 |
| L0520 | 4 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 1193 |
| L0520 | 4 | 1 | Opponent | no | 2 | 2 | 0 | 5 | 1 | 0 | 0 | 210 |
| L0608 | 2 | 1 | Mine | - | - | - | 1 | 3 | 0 | 0 | 0 | 984 |
| L0608 | 2 | 1 | Opponent | - | - | - | 0 | 3 | 0 | 0 | 0 | 769 |
| L0624 | 6 | 1 | Mine | no | 0 | 4 | 3 | 2 | 0 | 0 | 0 | 984 |
| L0624 | 6 | 1 | Opponent | no | 6 | 3 | 1 | 0 | 0 | 0 | 0 | 0 |
| L0713 | 5 | 1 | Mine | no | - | 4 | 1 | 0 | 1 | 0 | 0 | 561 |
| L0713 | 5 | 1 | Opponent | yes | - | 2 | 3 | 0 | 1 | 0 | 0 | 479 |
| L0729 | 3 | 1 | Mine | no | 1 | 2 | 2 | 1 | 0 | 0 | 0 | 375 |
| L0729 | 3 | 1 | Opponent | no | 8 | 2 | 4 | 1 | 1 | 0 | 0 | 170 |
| L0819 | 3 | 1 | Mine | no | 0 | - | 0 | 0 | 1 | 0 | 0 | 1007 |
| L0819 | 3 | 1 | Opponent | no | 8 | 2 | 3 | 2 | 1 | 0 | 0 | 0 |
| L0835 | 1 | 1 | Mine | no | 1 | - | 0 | 0 | 0 | 0 | 0 | 515 |
| L0835 | 1 | 1 | Opponent | no | 4 | 3 | 2 | 2 | 0 | 0 | 0 | 0 |
| L0926 | 2 | 1 | Mine | - | - | 5 | 1 | 1 | 0 | 0 | 0 | 537 |
| L0926 | 2 | 1 | Opponent | - | - | 2 | 3 | 6 | 0 | 0 | 0 | 0 |
| L1017 | 3 | 1 | Mine | no | 0 | 2 | 2 | 0 | 0 | 0 | 0 | 330 |
| L1017 | 3 | 1 | Opponent | yes | 9 | 2 | 5 | 1 | 1 | 0 | 0 | 0 |
| L1034 | 2 | 1 | Mine | - | - | 3 | 2 | 1 | 0 | 0 | 0 | 330 |
| L1034 | 2 | 1 | Opponent | - | - | 3 | 3 | 0 | 0 | 0 | 0 | 647 |
| L1126 | 4 | 1 | Mine | no | 1 | 6 | 1 | 0 | 1 | 0 | 0 | 526 |
| L1126 | 4 | 1 | Opponent | no | 4 | 3 | 3 | 2 | 1 | 0 | 0 | 0 |
| L1220 | 2 | 1 | Mine | - | - | 2 | 3 | 0 | 0 | 0 | 0 | 330 |
| L1220 | 2 | 1 | Opponent | - | - | - | 2 | 4 | 1 | 0 | 0 | 650 |
| L1314 | 6 | 1 | Mine | no | 7 | 3 | 2 | 0 | 1 | 0 | 0 | 317 |
| L1314 | 6 | 1 | Opponent | no | 16 | 2 | 1 | 1 | 1 | 0 | 0 | 123 |
| L1331 | 5 | 1 | Mine | yes | - | 5 | 3 | 3 | 1 | 0 | 0 | 302 |
| L1331 | 5 | 1 | Opponent | yes | - | 1 | 1 | 3 | 1 | 0 | 0 | 170 |
| L1427 | 5 | 1 | Mine | yes | - | 5 | 1 | 3 | 0 | 0 | 0 | 177 |
| L1427 | 5 | 1 | Opponent | yes | - | 3 | 2 | 3 | 0 | 0 | 0 | 0 |
| L1523 | 5 | 1 | Mine | yes | - | 3 | 2 | 1 | 1 | 0 | 0 | 0 |
| L1523 | 5 | 1 | Opponent | yes | - | 2 | 6 | 1 | 0 | 0 | 0 | 245 |
| L1621 | 1 | 1 | Mine | no | 4 | 2 | 4 | 1 | 1 | 0 | 0 | 200 |
| L1621 | 1 | 1 | Opponent | no | 0 | - | 5 | 1 | 0 | 0 | 0 | 565 |
| L1719 | 3 | 1 | Mine | no | 0 | 2 | 4 | 0 | 0 | 0 | 0 | 98 |
| L1719 | 3 | 1 | Opponent | yes | 2 | 2 | 9 | 0 | 0 | 0 | 0 | 0 |
| L1819 | 1 | 1 | Mine | no | 2 | 2 | 5 | 1 | 0 | 0 | 0 | 0 |
| L1819 | 1 | 1 | Opponent | no | 0 | 2 | 7 | 1 | 0 | 0 | 0 | 0 |
| L1835 | 5 | 1 | Mine | yes | - | 2 | 2 | 2 | 1 | 0 | 0 | 0 |
| L1835 | 5 | 1 | Opponent | no | - | 1 | 1 | 2 | 0 | 0 | 0 | 0 |
| L2021 | 5 | 1 | Mine | yes | - | 6 | 4 | 2 | 1 | 0 | 0 | 210 |
| L2021 | 5 | 1 | Opponent | no | - | 5 | 3 | 3 | 0 | 0 | 0 | 355 |
| L2123 | 5 | 1 | Mine | yes | - | - | 1 | 4 | 1 | 0 | 0 | 940 |
| L2123 | 5 | 1 | Opponent | yes | - | 2 | 4 | 1 | 2 | 0 | 0 | 0 |
| L2227 | 1 | 1 | Mine | yes | 3 | 2 | 4 | 0 | 0 | 0 | 0 | 0 |
| L2227 | 1 | 1 | Opponent | yes | 5 | 1 | 5 | 0 | 0 | 0 | 0 | 190 |
| L2331 | 3 | 1 | Mine | no | 0 | 2 | 2 | 0 | 1 | 0 | 0 | 0 |
| L2331 | 3 | 1 | Opponent | yes | 8 | 5 | 3 | 1 | 1 | 0 | 0 | 170 |
| L2527 | 1 | 1 | Mine | no | 0 | 3 | 2 | 4 | 0 | 0 | 0 | 0 |
| L2527 | 1 | 1 | Opponent | no | 0 | 1 | 2 | 6 | 0 | 0 | 0 | 190 |
| L2634 | 6 | 1 | Mine | no | 10 | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L2634 | 6 | 1 | Opponent | no | 2 | 2 | 1 | 2 | 1 | 0 | 0 | 0 |
| L2930 | 2 | 1 | Mine | - | - | 2 | 7 | 2 | 0 | 0 | 0 | 0 |
| L2930 | 2 | 1 | Opponent | - | - | 2 | 3 | 1 | 1 | 0 | 0 | 0 |
| L3234 | 6 | 1 | Mine | no | 0 | 2 | 3 | 4 | 0 | 0 | 0 | 170 |
| L3234 | 6 | 1 | Opponent | no | 1 | 1 | 4 | 2 | 0 | 0 | 0 | 56 |
| **Average** | | | Mine | 36% | 2.9 | 2.9 | 2.5 | 1.3 | 0.3 | 0.0 | 0.0 | 325.6 |
| **Average** | | | Opponent | 43% | 4.9 | 2.1 | 3.1 | 1.8 | 0.4 | 0.0 | 0.0 | 143.5 |

### KPIs: jc-opp-1e5408d-p4

Rules off - Mine only: SECOND CHARGER ADDS.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 27% (46 of 170) | 1% (2 of 180) | 14% (48 of 350) |
| Winner chose to follow up after the loser gave ground |  | 90% (56 of 62); on the table 90% | 100% (46 of 46); on the table 100% | 94% (102 of 108); on the table 94% |
| Winner chose to pursue after the loser fell back in good order |  | 85% (11 of 13); on the table 92% | 72% (13 of 18); on the table 72% | 77% (24 of 31); on the table 81% |
| Winner chose to pursue after the loser fled |  | 73% (22 of 30); on the table 80% | 77% (24 of 31); on the table 81% | 75% (46 of 61); on the table 80% |
| Winner chose to follow up or pursue (all three) |  | 85% (89 of 105); on the table 88% | 87% (83 of 95); on the table 88% | 86% (172 of 200); on the table 88% |
| Magic missiles tried each own turn | 50%+ | 28% (76 of 267) | 32% (56 of 175) | 30% (132 of 442) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 41% (76 of 185) | 50% (56 of 113) | 44% (132 of 298) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 64% (29 of 45) | 60% (38 of 63) | 62% (67 of 108) |
| Points that never fought | lower | 36% (24303 of 67942) | 34% (24279 of 71984) | 35% (48582 of 139926) |
|   infantry points that never fought | lower | 47% (7227 of 15347) | 53% (7378 of 13804) | 50% (14605 of 29151) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 62% (167 of 270) | 52% (146 of 280) | 57% (313 of 550) |
| Bound items with a magic missile used (at least once a game) |  | 91% (20 of 22); 1.6 uses a game | 89% (8 of 9); 0.5 uses a game | 90% (28 of 31); 1.0 uses a game |
| Bound items with another spell used |  | 25% (4 of 16); 0.3 uses a game | 35% (7 of 20); 0.4 uses a game | 31% (11 of 36); 0.3 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 53% (10 of 19); 0.3 uses a game | 80% (12 of 15); 0.4 uses a game | 65% (22 of 34); 0.3 uses a game |
|   their share of the points of units over 100 pts | lower | 57% (32895 of 57750) | 42% (26358 of 63347) | 49% (59253 of 121097) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.7 (32%) | 0.8 (24%) | 2.5 (29%) |
| MARCHED: its unit marched | 1.2 (23%) | 0.3 (9%) | 1.5 (17%) |
| CHARGED: its unit charged | 0.1 (3%) | 0.2 (6%) | 0.3 (4%) |
| IN COMBAT: engaged in combat | 1.1 (20%) | 0.8 (23%) | 1.8 (21%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.2 (8%) | 0.2 (3%) |
| FLEEING: fleeing | 0.3 (5%) | 0.1 (2%) | 0.3 (4%) |
| GONE: slain | 0.6 (12%) | 0.8 (25%) | 1.5 (17%) |
| OFF THE TABLE: off the table or not arrived | 0.3 (5%) | 0.1 (3%) | 0.4 (4%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.1 (2%) | 0.1 (1%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 3.9 | 1.4 | 2.0 | 3.7 | 0.4 | 1.9 |
| not cast | 3.3 | 2.5 | 2.8 | 8.6 | 1.6 | 20.9 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) | 0.0 (0%) | 1.4 (7%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (1%) | 1.3 (52%) | 0.2 (8%) | 2.5 (29%) | 0.3 (18%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.5 (17%) | 0.4 (25%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (4%) | 0.1 (4%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (1%) | 0.1 (3%) | 0.6 (20%) | 1.8 (21%) | 0.2 (12%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.2 (5%) | 0.2 (7%) | 0.3 (12%) | 0.2 (3%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.1 (4%) | 0.0 (0%) | 0.1 (4%) | 0.3 (4%) | 0.1 (5%) | 0.8 (4%) |
| GONE: slain | 0.9 (27%) | 0.4 (15%) | 0.4 (16%) | 1.5 (17%) | 0.2 (11%) | 3.7 (18%) |
| OFF THE TABLE: off the table or not arrived | 0.4 (11%) | 0.2 (8%) | 0.1 (4%) | 0.4 (4%) | 0.0 (0%) | 1.1 (5%) |
| STUPIDITY: Stupidity | 0.1 (3%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.2 (10%) | 0.0 (0%) | 0.1 (1%) | 0.4 (25%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.6 (49%) | 0.1 (6%) | 1.0 (36%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 13.8 (66%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.5 a game | 0.6 a game | 1.1 a game |
| stood (cast and not dispelled) | 65% (32 of 49) | 75% (9 of 12) | 67% (41 of 61) |
| the unit moved after it | 62% (20 of 32) | 67% (6 of 9) | 63% (26 of 41) |
| it charged on its next turn | 3% (1 of 32) | 11% (1 of 9) | 5% (2 of 41) |
| the enemy charged it first | 28% (9 of 32) | 11% (1 of 9) | 24% (10 of 41) |
| it fought by the end of its next turn | 16% (5 of 32) | 0% (0 of 9) | 12% (5 of 41) |
| it moved out of a charge the enemy had planned (not charged first) | 22% (7 of 32) | 0% (0 of 9) | 17% (7 of 41) |
| none of these (no charge, no fight, no charge escaped) | 50% (16 of 32) | 78% (7 of 9) | 56% (23 of 41) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 64% (576 of 902) | 52% (280 of 535) | 60% (856 of 1437) |
|   cavalry | 47% (37 of 78) | 67% (74 of 110) | 59% (111 of 188) |
|   character | 53% (60 of 113) | 17% (23 of 133) | 34% (83 of 246) |
|   chariot | 52% (54 of 103) | 67% (10 of 15) | 54% (64 of 118) |
|   infantry | 62% (168 of 271) | 64% (143 of 225) | 63% (311 of 496) |
|   monster | 36% (19 of 53) | 20% (5 of 25) | 31% (24 of 78) |
|   war machine | 84% (238 of 284) | 93% (25 of 27) | 85% (263 of 311) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.6 (18%) | 1.6 (23%) | 3.2 (20%) |
| CHARGED: it charged | 1.2 (14%) | 1.8 (25%) | 3.1 (19%) |
| FLEEING: it fled or was fleeing | 0.2 (2%) | 0.2 (3%) | 0.4 (2%) |
| IN COMBAT: it fought this turn or the last | 1.0 (11%) | 0.3 (4%) | 1.3 (8%) |
| MOVED: a war machine that moved | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| HELD FIRE: a target, but it held its fire | 0.1 (1%) | 0.0 (0%) | 0.1 (0%) |
| NO TARGET IN RANGE | 2.2 (24%) | 1.3 (18%) | 3.5 (22%) |
| ONLY IN COMBAT: the only targets were in combat | 0.7 (7%) | 0.4 (5%) | 1.1 (7%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.6 (17%) | 1.4 (20%) | 3.0 (18%) |
| SHELTERED: the target was sheltered | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| OTHER BAR | 0.3 (3%) | 0.1 (2%) | 0.4 (2%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 5.1 | 1.3 | 82% | 5.1 pts | 26 pts |
| character | 2.4 | 0.8 | 80% | 5.3 pts | 13 pts |
| chariot | 1.8 | 1.0 | 66% | 12.8 pts | 23 pts |
| infantry | 12.6 | 4.2 | 77% | 8.7 pts | 109 pts |
| monster | 0.8 | 0.2 | 81% | 5.6 pts | 4 pts |
| war machine | 7.3 | 6.1 | 63% | 28.9 pts | 211 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.9 | 6.7 | 5.3 |
| Charges that made contact a game | 2.9 | 4.5 | 3.7 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.65 declared, 0.53 contact (17 units) | 0.81 declared, 0.50 contact (16 units) | 0.73 declared, 0.52 contact (33 units) |
|   per unit a game, units carrying another wizard (or one alone) | 1.00 declared, 0.89 contact (9 units) | 1.23 declared, 1.00 contact (13 units) | 1.14 declared, 0.95 contact (22 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.48 declared, 0.35 contact (250 units) | 0.71 declared, 0.47 contact (297 units) | 0.60 declared, 0.42 contact (547 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 60% (49 of 81) | 38% (6 of 16) | 67% (4 of 6) | 57% (59 of 103) |
| Character in a unit | 80% (24 of 30) | 39% (7 of 18) | 100% (1 of 1) | 65% (32 of 49) |
| Character on its own | 91% (32 of 35) | 54% (13 of 24) | 23% (18 of 77) | 46% (63 of 136) |
| Chariot | 73% (11 of 15) | 50% (6 of 12) | - | 63% (17 of 27) |
| Infantry | 60% (50 of 83) | 52% (13 of 25) | 17% (1 of 6) | 56% (64 of 114) |
| Monster | 59% (20 of 34) | 71% (10 of 14) | - | 62% (30 of 48) |
| Monstrous | 57% (8 of 14) | 50% (7 of 14) | - | 54% (15 of 28) |
| War Machines | 72% (31 of 43) | 100% (2 of 2) | - | 73% (33 of 45) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 80% (8 of 10); on the table 80% | 35% (36 of 102) | 14% | 50% (11 of 22) | 83% (5 of 6); 3.2 uses a game | 100% (2 of 2); 1.5 uses a game | 67% (4 of 6); 1.0 uses a game |
| Chaos Dwarfs | 4 | 85% (11 of 13); on the table 92% | 38% (9 of 24) | 22% | 62% (20 of 32) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
| Dwarfen Mountain Holds | 3 | 33% (1 of 3); on the table 33% | - | 80% | 70% (19 of 27) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 6 | 91% (10 of 11); on the table 91% | 56% (10 of 18) | 51% | 66% (41 of 62) | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game | 80% (4 of 5); 0.7 uses a game |
| Grand Cathay | 4 | 92% (11 of 12); on the table 92% | 19% (16 of 84) | 34% | 57% (21 of 37) | 100% (9 of 9); 6.0 uses a game | 0% (0 of 2); 0.0 uses a game | 25% (1 of 4); 0.2 uses a game |
| High Elf Realms | 9 | 83% (29 of 35); on the table 83% | 11% (4 of 36) | 32% | 50% (35 of 70) | 100% (7 of 7); 2.6 uses a game | 27% (8 of 30); 2.0 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | 100% (3 of 3); on the table 100% | - | 35% | 33% (2 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Lizardmen | 3 | 89% (17 of 19); on the table 89% | 67% (4 of 6) | 26% | 57% (12 of 21) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 2 | 100% (7 of 7); on the table 100% | 33% (2 of 6) | 44% | 93% (13 of 14) | 50% (1 of 2); 1.5 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 3 | 100% (9 of 9); on the table 100% | 29% (12 of 42) | 13% | 33% (8 of 24) | 0.0 uses a game | 0.0 uses a game | 67% (2 of 3); 0.7 uses a game |
| Skaven | 6 | 75% (6 of 8); on the table 100% | 22% (9 of 41) | 46% | 71% (32 of 45) | 100% (3 of 3); 0.8 uses a game | 0.0 uses a game | 50% (3 of 6); 0.7 uses a game |
| Tomb Kings of Khemri | 4 | 75% (9 of 12); on the table 75% | 0% (0 of 6) | 22% | 35% (7 of 20) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 8 | 100% (17 of 17); on the table 100% | 41% (24 of 59) | 34% | 45% (19 of 42) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 9 | 68% (13 of 19); on the table 74% | 33% (4 of 12) | 29% | 56% (40 of 72) | 100% (2 of 2); 0.3 uses a game | 0.0 uses a game | 100% (3 of 3); 0.3 uses a game |
| Wood Elf Realms | 6 | 95% (21 of 22); on the table 95% | 33% (2 of 6) | 41% | 59% (33 of 56) | 50% (1 of 2); 0.5 uses a game | 0.0 uses a game | 75% (3 of 4); 0.5 uses a game |

Flank and rear charges a unit could have turned to face (jc-opp-1e5408d-p4, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 55% (53) | 41% (30) | 49% (83) |
| ...free all their last turn and able to turn (per game) | 0.81 | 0.53 | 1.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.33 | 0.14 | 0.47 |
| ...with the charger already in that arc before they moved (per game) | 0.50 | 0.42 | 0.92 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 2.03 | 1.06 | 3.08 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 1.14 | 0.47 | 1.61 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 5.42 | 5.69 | 11.11 |

### Quality by phase: jc-opp-1e5408d-p4

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.1 | 3.6 |
| Strategy | Charge objectives carried out (made contact) | 49% (65 of 134) | 38% (74 of 195) |
| Strategy | Shoot objectives carried out (shot that target) | 48% (199 of 417) | 39% (79 of 204) |
| Strategy | Close-in objectives charged next turn | 11% (19 of 168) | 14% (33 of 232) |
| Strategy | Support requests answered (helper made contact too) | 53% (8 of 15) | 24% (12 of 49) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (2 of 2) | 100% (1 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | 54% (7 of 13) | 83% (5 of 6) |
| Strategy | Joined characters whose unit fought | 55% (23 of 42) | 48% (15 of 31) |
| Strategy | Lone characters that fought | 72% (58 of 81) | 80% (68 of 85) |
| Movement | Charges halted short of contact | 0.1 | 0.2 |
| Movement | Idle units | 1.3 | 1.8 |
| Movement | Points that never moved of their own | 325.6 | 143.5 |
| Movement | Fights charged into per game | 2.7 | 3.8 |
| Movement | Charges with odds: long shots (under 50%) | 12 of 89, net +75 | 24 of 111, net +10 |
| Movement | Charges with odds: sweet spot (55-75%) | 18 of 89, net -6 | 19 of 111, net +122 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 10 of 89, net +89 | 10 of 111, net +125 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 25 of 89, net +73 | 24 of 111, net +121 |
| Shooting | Shots by shooting units (incl. breath weapons) | 10.3 | 8.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 50% (185 of 370) | 41% (124 of 299) |
| Shooting | Points destroyed by shooting units | 51.4 | 35.9 |
| Shooting | War machine shots | 6.6 | 0.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 59% (141 of 238) | 28% (7 of 25) |
| Shooting | Points destroyed by war machines | 115.7 | 4.9 |
| Magic | Magic missiles cast | 1.1 | 1.0 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 22% (9 of 41) | 22% (7 of 32) |
| Magic | Wounds caused by magic missiles | 3.5 | 1.3 |
| Magic | Wounds caused by other spells | 1.3 | 1.4 |
| Magic | Points destroyed by magic (all spells) | 112.8 | 23.2 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.1 / 0.4 / 0.8 / 0.2 | 1.8 / 0.4 / 0.6 / 0.1 |
| Combat | Points destroyed in combat | 235.0 | 450.1 |
| Combat | Points run down | 64.6 | 87.1 |
| Combat | Net points per charged fight, damage counted | +65 | +102 |
| Combat | Net per 100 charger points, damage counted | +23.0 | +31.9 |
| Combat | First round won (charged fights) | 77% | 70% |
| Combat | Net points per charged fight | +52 | +103 |
| Combat | Net points per supported fight / lone fight | +74 / +48 | +192 / +87 |
| Combat | Charged fights on a top-3 enemy unit | 28 of 98 | 66 of 135 |
| Game | Points lost | 786.2 | 662.2 |
| Game | VP from objectives | 494.2 | 529.7 |
| Game | Lone holders (player turns) | 2.9 | 4.9 |

- Mine won / drew / lost: 13 / 5 / 18 of 36 ended games (of 36); mean margin (Mine - Opponent) -155 VP
- The side that went first won 15 of 31 games with a winner
- Points traded per game (both sides' losses): 1448
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: jc-opp-1e5408d-p4

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 0.8 | +0.0 | 0.0 | 0.0 |
| ADVANCE WORTH | 5.5 | -108.0 | 207.9 | 117.8 | 4.5 | -91.7 | 147.8 | 42.4 |
| ALREADY CARRIED | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARRIVAL HUNT | - | - | - | - | 0.0 | +0.5 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.2 | +0.0 | 0.0 | 13.5 | 0.1 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | 0.6 | +2.6 | 0.0 | 13.4 | 0.5 | +2.9 | 0.0 | 5.4 |
| BEST FACING | 0.6 | +7.4 | 0.0 | 50.0 | 0.2 | +7.1 | 0.0 | 0.0 |
| BEST FIRST | 1.1 | +52.1 | 23.2 | 42.5 | 0.8 | +44.9 | 28.8 | 17.4 |
| BEST OVERALL | 0.4 | +19.8 | 0.0 | 26.8 | 0.1 | +5.3 | 0.0 | 6.2 |
| BEST PREY | 0.4 | +14.7 | 3.8 | 6.3 | 0.5 | +14.2 | 10.4 | 8.0 |
| BEST PRIZE | 0.2 | -1.8 | 1.2 | 13.4 | 0.1 | -0.4 | 12.8 | 0.0 |
| BIG CHARACTER SAFETY | 0.1 | -0.6 | 0.0 | 0.0 | 0.2 | -0.2 | 0.0 | 0.0 |
| BLOCKED CHARGE SKIPPED | 0.1 | +0.0 | 4.7 | 0.0 | 0.2 | +0.0 | 12.1 | 0.0 |
| BLOCKED WHEEL | 0.3 | +8.1 | 0.0 | 8.3 | 0.4 | +5.0 | 0.0 | 0.0 |
| BLOWS WHERE AIMED | 0.2 | -9.5 | 31.0 | 1.4 | 0.5 | -90.1 | 49.8 | 20.0 |
| BOMBING RUN | 0.0 | +1.0 | 0.0 | 4.2 | - | - | - | - |
| CANNON PLAN MISSED | 0.5 | +0.0 | 88.1 | 6.5 | 0.1 | +0.0 | 16.0 | 0.0 |
| CANNON PLANNED TARGET | 5.4 | +198.1 | 429.6 | 114.3 | 0.6 | +25.7 | 48.3 | 3.5 |
| CANNON SIGHT KEPT | 1.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT COUNTER | 0.0 | +0.0 | 0.0 | 0.0 | 0.0 | +0.0 | 5.2 | 0.0 |
| CARRIES OUT SET-UP | 0.1 | +0.0 | 59.0 | 22.6 | 0.2 | -3.8 | 22.2 | 0.0 |
| CAST JOB | 1.0 | +30.1 | 54.2 | 43.2 | 0.4 | +4.3 | 37.2 | 0.0 |
| CASTER AWAY FROM SCREEN | 0.3 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.4 | +39.1 | 23.6 | 8.9 | 0.1 | +3.2 | 6.5 | 0.0 |
| CASTS AFTER FRIENDS | 1.0 | +0.0 | 0.0 | 42.2 | 0.4 | +0.0 | 0.0 | 20.2 |
| CASTS FROM BEHIND | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.1 | +0.7 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | 0.8 | +50.8 | 0.0 | 24.7 | 2.7 | +151.8 | 0.0 | 45.2 |
| CHAFF PASSED | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | -0.1 | 0.0 | 0.0 |
| CHARGE NOW FIRST | 2.5 | +0.0 | 210.8 | 136.8 | 2.8 | +0.0 | 272.0 | 54.3 |
| CHARGE NOW WEIGHED | 0.6 | -42.8 | 18.8 | 13.2 | 0.6 | -50.8 | 15.1 | 7.5 |
| CHARGER SLAIN LOST | 0.4 | -19.0 | 12.2 | 30.1 | 0.7 | -24.6 | 80.4 | 31.8 |
| CHARIOT WIZARD CAREFUL | 0.1 | -0.5 | 6.5 | 11.1 | 0.1 | -0.5 | 7.7 | 0.0 |
| CHEAP HELPER | 0.1 | +0.0 | 1.5 | 5.8 | - | - | - | - |
| COMBAT PIVOT | 0.6 | +0.0 | 28.9 | 50.8 | 0.3 | +0.0 | 15.5 | 18.7 |
| CONTINUE AHEAD WEIGHED | 0.1 | +0.0 | 0.0 | 7.1 | 0.0 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | 0.9 | +76.0 | 12.5 | 15.3 | 0.2 | +40.1 | 1.8 | 0.0 |
| COVER ONCE | 8.4 | -478.8 | 0.0 | 308.9 | 6.2 | -433.0 | 0.0 | 84.5 |
| DEFENSIVE ARMY | 0.2 | +0.0 | 28.4 | 1.0 | - | - | - | - |
| EDGE GIVE GROUND | 0.1 | +1.5 | 4.6 | 0.0 | 0.1 | +4.9 | 11.2 | 7.0 |
| ELIXIR WORTH | - | - | - | - | 0.1 | +0.7 | 0.0 | 0.0 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 2.0 | +119.4 | 0.0 | 100.6 | 1.1 | +81.5 | 0.0 | 22.1 |
| FALLBACK BY WORTH | 4.8 | +50.3 | 0.0 | 63.0 | 6.0 | +57.6 | 0.0 | 75.0 |
| FIGHT LIFT | 0.1 | +0.7 | 7.7 | 0.0 | 0.0 | +0.1 | 0.0 | 0.0 |
| FIRE AND FLEE | 0.0 | +0.1 | 0.0 | 0.0 | 0.1 | +0.4 | 1.8 | 3.0 |
| FLANK NOT WEIGHED | 5.6 | +0.0 | 0.0 | 248.0 | 4.8 | +0.0 | 0.0 | 89.2 |
| FOLLOW UP WEIGHED | 1.0 | +141.3 | 0.0 | 70.8 | 0.8 | +79.6 | 0.0 | 0.0 |
| FRIEND IN REACH | 3.8 | +80.9 | 278.9 | 162.2 | 6.0 | +139.2 | 603.2 | 122.4 |
| FRIENDS SHOTS CHECKED | 0.1 | +7.5 | 0.0 | 0.0 | 0.3 | +12.5 | 0.0 | 0.8 |
| GIVES UP | 0.1 | -0.3 | 5.1 | 0.0 | 0.2 | -3.5 | 30.6 | 5.7 |
| GIVES UP ITS SCREEN | - | - | - | - | 0.0 | -1.1 | 4.9 | 0.0 |
| GROUND FLIERS | 0.1 | +2.6 | 0.0 | 6.1 | 0.1 | +1.3 | 0.0 | 0.0 |
| HELPER ALREADY ASKED | - | - | - | - | 0.1 | +0.0 | 5.3 | 5.0 |
| HELPER UNSEEN | 0.2 | +0.0 | 6.9 | 9.7 | 1.1 | +0.0 | 117.7 | 31.6 |
| HILL BY ITS CHANCE | 0.6 | -82.5 | 0.0 | 3.4 | 0.5 | -39.3 | 0.0 | 17.4 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 7.4 | -134.4 | 421.7 | 244.3 | 9.7 | -230.9 | 688.6 | 174.7 |
| HUNT ADVANCE | - | - | - | - | 0.1 | +2.1 | 2.4 | 0.0 |
| HUNT DROPPED | - | - | - | - | 0.1 | +0.0 | 0.0 | 0.0 |
| HUNT IN PAIRS | 0.3 | +6.2 | 0.0 | 0.0 | 0.4 | +20.9 | 0.0 | 3.1 |
| HUNT KEPT | - | - | - | - | 0.1 | +0.2 | 6.9 | 1.2 |
| HUNT RESULT | - | - | - | - | 0.1 | +10.8 | 0.0 | 1.2 |
| HUNT THE GUNS | - | - | - | - | 0.1 | +35.4 | 6.9 | 0.0 |
| IDLE COST | 17.3 | -288.7 | 0.0 | 249.9 | 20.4 | -334.7 | 0.0 | 208.3 |
| INVITES THE FIGHT | 1.2 | +7.4 | 46.5 | 16.5 | 1.1 | +7.2 | 50.6 | 23.2 |
| JOINT CHARGE PLAN | 0.1 | +3.2 | 0.0 | 0.0 | 0.1 | +2.0 | 0.0 | 0.0 |
| JOINT KNOWS CHALLENGE | - | - | - | - | 0.2 | -2.0 | 30.8 | 0.0 |
| KEEP FALLS | 0.1 | +0.6 | 0.0 | 0.0 | 0.1 | +1.0 | 0.0 | 0.0 |
| KEEPS ITS PREY | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |
| KEEPS ITS TARGET | 1.5 | +45.0 | 145.9 | 42.2 | 1.8 | +54.2 | 172.7 | 20.8 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KILLS COUNT | 1.3 | +42.7 | 71.4 | 55.7 | 2.1 | +108.0 | 190.1 | 37.3 |
| KILLS COUNT NEXT TURN | 5.1 | +192.3 | 213.5 | 112.4 | 6.5 | +296.9 | 200.1 | 128.7 |
| LONE CHARACTER SAFE SPOT | 0.4 | +19.7 | 0.0 | 19.1 | 0.2 | +11.0 | 0.0 | 3.2 |
| LONE WIZARD HOLDS BACK | 0.0 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 5.2 | 10.7 |
| LONE WIZARD KEPT IN | 0.6 | +26.9 | 0.0 | 0.0 | 0.2 | +20.3 | 0.0 | 0.0 |
| LONG SHOT | 0.2 | -0.4 | 6.7 | 9.4 | 0.5 | +0.9 | 28.7 | 17.5 |
| LOST CHARGE | 2.6 | -31.5 | 71.4 | 103.6 | 1.8 | -30.7 | 55.2 | 36.8 |
| LURE BY WHAT IT DRAWS | 0.2 | -25.1 | 0.0 | 7.6 | 0.2 | -19.0 | 0.0 | 11.9 |
| MAKE SURE TOGETHER | 0.5 | +49.9 | 0.0 | 31.8 | 0.9 | +92.6 | 20.3 | 20.6 |
| MANOEUVRE | 0.3 | +8.1 | 0.0 | 16.6 | 0.1 | +0.4 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.1 | +0.2 | 0.0 | 0.0 | 0.1 | +0.2 | 0.0 | 5.4 |
| MARCH CHECK | 0.5 | +21.9 | 0.0 | 14.8 | 0.2 | +5.0 | 0.0 | 3.2 |
| MARCH ODDS | 0.4 | +28.8 | 14.2 | 10.2 | 0.2 | +13.4 | 8.9 | 0.0 |
| MARCH OVER CASTS | 0.5 | +29.3 | 0.0 | 51.0 | 0.2 | +13.9 | 0.0 | 5.4 |
| MAX FOR POSITIONING | 5.6 | +94.6 | 0.0 | 173.7 | 6.4 | +79.4 | 0.0 | 117.3 |
| MISSILES IN THE MOVE | 3.8 | +139.2 | 0.0 | 111.7 | 2.1 | +25.9 | 0.0 | 51.5 |
| MISSILES NEXT TURN | 4.6 | +87.5 | 0.0 | 195.4 | 2.7 | +19.6 | 0.0 | 62.6 |
| MODEL FACING | 0.2 | +34.3 | 0.0 | 5.0 | - | - | - | - |
| MONSTER WIZARD ROAMS | 0.1 | +0.0 | 0.0 | 20.8 | 0.2 | +0.0 | 10.5 | 0.0 |
| MOVE AND CAST | 0.2 | +1.3 | 0.0 | 13.5 | 0.4 | +12.9 | 0.0 | 11.1 |
| MOVE SPELL IN RANGE | 0.2 | +4.2 | 0.0 | 10.6 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.7 | -55.7 | 27.3 | 27.5 | 0.1 | -5.5 | 0.0 | 0.0 |
| MOVE SPELL SPOT | 0.5 | +0.0 | 0.0 | 20.5 | 0.1 | +0.0 | 0.0 | 11.1 |
| MOVE TO CHARGE | 2.9 | +144.5 | 137.8 | 108.3 | 4.8 | +382.2 | 204.1 | 87.1 |
| MOVES UNITS SPELL | 0.1 | +3.3 | 0.0 | 0.0 | 0.1 | +0.6 | 0.0 | 0.0 |
| NEEDED THERE | 0.0 | +0.9 | 0.0 | 0.0 | 0.1 | +6.0 | 14.9 | 0.0 |
| NOT NEEDED | 0.2 | -16.1 | 54.6 | 13.5 | - | - | - | - |
| NOT TURNED | 5.4 | +55.8 | 0.0 | 154.1 | 5.7 | +88.3 | 0.0 | 110.3 |
| NOT WORTH A CAST | 0.6 | -0.6 | 0.0 | 56.5 | 0.3 | -0.1 | 0.0 | 0.0 |
| OFF BEST | 15.8 | -715.4 | 13.6 | 287.0 | 15.0 | -686.3 | 4.9 | 196.6 |
| ONE FIGHT FORMULA | 8.9 | -153.0 | 19.0 | 247.3 | 8.5 | -175.7 | 36.9 | 138.5 |
| ONE OBJECTIVE FORMULA | 2.2 | -127.0 | 0.0 | 25.7 | 2.1 | -148.7 | 0.0 | 50.2 |
| OPENS A LANE | 0.3 | +2.6 | 49.1 | 10.2 | 0.0 | +0.2 | 5.9 | 0.0 |
| OPENS UP | 0.3 | +19.2 | 20.8 | 6.5 | 0.3 | +28.8 | 18.2 | 13.7 |
| OVERRUNS AWAY | 0.6 | +16.9 | 57.7 | 28.4 | 0.9 | +30.4 | 94.9 | 31.0 |
| PAIR SET-UP | 0.0 | +0.0 | 15.0 | 12.1 | 0.1 | +0.0 | 0.0 | 0.0 |
| PATHS CROSS | 2.1 | +162.6 | 0.0 | 49.5 | 3.2 | +223.0 | 0.0 | 36.4 |
| PERIAPT WORTH | 0.0 | +3.4 | 0.0 | 0.0 | 0.1 | +7.9 | 0.0 | 15.0 |
| PIVOT GUARDS FLANK | 0.1 | -2.4 | 0.0 | 3.8 | 0.1 | -0.1 | 0.0 | 0.0 |
| PLAN RESULT | 38.9 | +1595.1 | 1643.3 | 1153.6 | 39.6 | +1291.0 | 1463.9 | 931.1 |
| PURSUES BIG PREY | 0.1 | -8.7 | 0.0 | 0.0 | 0.1 | -1.0 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE | - | - | - | - | 0.0 | +4.9 | 0.0 | 4.5 |
| RAIDS THE BAGGAGE NEXT TURN | 0.1 | +7.2 | 0.0 | 2.2 | 0.1 | +10.6 | 0.0 | 0.0 |
| RANDOM MOVE BY FIGURES | 1.2 | +27.4 | 0.0 | 30.3 | 1.8 | +16.9 | 0.0 | 65.3 |
| RANDOM MOVER NO PROMISE | 0.3 | -10.1 | 12.3 | 8.8 | 0.4 | -14.1 | 6.7 | 12.8 |
| REDIRECT BY WHAT IT STOPS | 0.6 | -7.7 | 0.0 | 17.1 | 2.2 | -54.1 | 0.0 | 30.7 |
| REDIRECT COUNTER | 2.2 | +124.8 | 0.0 | 45.1 | 4.0 | +248.0 | 0.0 | 66.1 |
| REDIRECT WEIGHED | 0.2 | +3.0 | 4.9 | 6.5 | 0.7 | +30.6 | 26.9 | 15.0 |
| REFUSING RETIRES | 0.2 | +0.0 | 0.0 | 4.6 | 0.2 | +0.0 | 0.0 | 38.4 |
| RESERVE FALL BACK | 0.3 | +10.4 | 0.0 | 16.6 | 0.7 | +31.6 | 0.0 | 12.8 |
| RESTRAINS TO SHOOT | 0.2 | +4.6 | 0.0 | 10.6 | 0.0 | +0.4 | 0.0 | 0.0 |
| RISK BY ARC | 2.7 | +113.5 | 222.9 | 147.4 | 3.1 | +36.7 | 326.1 | 92.8 |
| RISK ONCE | 1.8 | +34.6 | 10.9 | 136.1 | 4.3 | +123.3 | 38.0 | 181.4 |
| SAFE SURE CHARGE | - | - | - | - | 0.0 | -0.8 | 0.0 | 0.0 |
| SAFER THAN THE JOB | 1.1 | +69.3 | 0.0 | 21.5 | 0.5 | +19.0 | 0.0 | 10.9 |
| SCOUT SPOT | 0.4 | +0.5 | 0.0 | 0.9 | 0.1 | +0.0 | 0.0 | 1.8 |
| SCOUT WAITS | 0.5 | +0.0 | 0.0 | 0.9 | 0.1 | +0.0 | 0.0 | 1.8 |
| SCREEN BY WHAT IT SAVES | 0.2 | -13.8 | 0.0 | 0.0 | 0.5 | -32.9 | 0.0 | 2.5 |
| SEARCH SPOT | 2.1 | +75.4 | 0.0 | 28.2 | 2.7 | +97.8 | 0.0 | 42.6 |
| SECOND CHARGER ADDS | - | - | - | - | 0.4 | -23.0 | 67.2 | 6.7 |
| SELF MOVE SPELL | 0.2 | +44.0 | 0.0 | 0.0 | 0.5 | +19.3 | 0.0 | 18.1 |
| SET UP TOGETHER | 0.6 | +54.2 | 0.0 | 31.8 | 1.7 | +132.9 | 41.1 | 31.9 |
| SET-UP ANY TARGET | 0.5 | +82.6 | 7.8 | 10.6 | 0.1 | +9.7 | 0.0 | 0.0 |
| SET-UP MISSED | 0.1 | +9.4 | 10.6 | 10.6 | 0.0 | +9.3 | 0.0 | 0.0 |
| SHOOTER COUNTED ONCE | - | - | - | - | 0.0 | -0.0 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.3 | +0.8 | 0.0 | 0.0 | 0.2 | +0.3 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.1 | +39.0 | 40.9 | 10.5 | 1.5 | +27.1 | 43.7 | 33.6 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 3.8 |
| SHOT REPLANNED | 0.5 | +0.0 | 110.8 | 13.3 | 0.0 | +0.0 | 0.9 | 0.0 |
| SHOTS IN THE MOVE | 14.5 | +578.4 | 0.0 | 296.8 | 7.4 | +160.3 | 0.0 | 112.8 |
| SPELL CATCH ODDS | 0.1 | -0.9 | 0.0 | 0.0 | - | - | - | - |
| SPELL OFF EDGE | 0.0 | +1.5 | 4.0 | 0.0 | - | - | - | - |
| SPELL SETS UP CHARGE | 0.5 | +82.6 | 7.8 | 10.6 | 0.1 | +30.4 | 0.0 | 0.0 |
| SPELL WORTH | 1.1 | +19.2 | 71.2 | 68.8 | 2.2 | +40.8 | 76.6 | 74.8 |
| SPELLS IN THE FIGHT | 0.9 | -6.3 | 112.3 | 53.2 | 0.9 | -10.4 | 170.1 | 18.8 |
| STABLE ROLE | 11.0 | +0.0 | 370.5 | 261.0 | 10.0 | +0.0 | 353.9 | 156.7 |
| STAY WEIGHED | 0.2 | +19.4 | 0.0 | 3.9 | - | - | - | - |
| STOPS | - | - | - | - | 0.1 | +1.5 | 6.9 | 0.0 |
| STOPS SHORT OF THE FLANK | 0.5 | +28.4 | 0.0 | 0.0 | 0.3 | +8.0 | 0.0 | 4.0 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 4.0 |
| SUPPORT NARROWED | 6.3 | -59.6 | 319.2 | 102.8 | 7.7 | -70.3 | 426.8 | 106.1 |
| SUPPORTS | 4.7 | +70.7 | 231.6 | 65.2 | 5.4 | +75.8 | 169.0 | 55.0 |
| SURE CHARGE BEATS ADVANCE | - | - | - | - | 0.1 | -2.3 | 2.0 | 0.0 |
| SURE REACH TOGETHER | 0.4 | -0.2 | 0.0 | 3.8 | 0.6 | -0.3 | 0.0 | 12.9 |
| THROUGH LINE OF FIRE | 0.1 | +5.7 | 0.0 | 0.0 | 0.3 | +8.9 | 0.0 | 1.9 |
| TURN WORTH | 0.4 | -35.4 | 33.6 | 6.5 | 0.1 | -8.3 | 7.0 | 0.0 |
| TWO OR MORE ARRIVE | 0.2 | +0.6 | 0.0 | 12.1 | 0.5 | +3.1 | 0.0 | 8.7 |
| WAIT AFTER COSTS | 6.2 | -263.2 | 253.9 | 154.8 | 7.6 | -397.3 | 319.7 | 124.7 |
| WALKS TO THE FIGHT | 1.8 | +11.3 | 43.9 | 47.8 | 0.7 | +5.1 | 17.0 | 4.9 |
| WAR ENGINE CHARGES | 0.2 | +10.9 | 2.5 | 14.0 | - | - | - | - |
| WAR ENGINE JOBS | 0.6 | +0.0 | 31.2 | 17.2 | 0.1 | +0.0 | 2.2 | 4.0 |
| WEARS DOWN | 1.3 | +48.6 | 132.9 | 83.9 | 1.7 | +56.3 | 195.9 | 32.8 |
| WHO HITS BACK | 0.3 | +23.9 | 0.0 | 7.7 | 0.3 | +16.3 | 0.0 | 22.4 |
| WHOLE FIGHT | 0.2 | +19.4 | 16.2 | 0.0 | 0.5 | +37.5 | 105.3 | 3.1 |
| WHOLE FIGHT GAIN | 0.2 | +13.1 | 22.8 | 11.4 | 1.0 | +51.7 | 112.9 | 10.5 |
| WIDER SPREAD | 2.5 | -9.4 | 169.6 | 148.2 | 3.8 | -7.9 | 408.2 | 75.0 |
| WOUNDED STAYS OUT | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |

### Rule changes: jc-opp-1e5408d-p4

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 1108 | 1108 | 1108 | 30.78 | -50460 | -45.5 |
| PATHS CROSS | 190 | 190 | 190 | 5.28 | +13882 | +73.1 |
| SEARCH SPOT | 172 | 172 | 165 | 4.58 | +6275 | +38.0 |
| MOVE TO CHARGE | 275 | 275 | 163 | 4.53 | +7624 | +46.8 |
| KILLS COUNT NEXT TURN | 418 | 418 | 152 | 4.22 | +5637 | +37.1 |
| SUPPORTS | 361 | 361 | 144 | 4.00 | +1764 | +12.2 |
| FACES THE THREAT | 111 | 111 | 111 | 3.08 | +7230 | +65.1 |
| WAIT AFTER COSTS | 498 | 498 | 93 | 2.58 | +1458 | +15.7 |
| COVER ONCE | 526 | 304 | 86 | 2.39 | +1398 | +16.3 |
| CHAFF IN THE MOVE | 125 | 122 | 77 | 2.14 | +2973 | +38.6 |
| FALLBACK BY WORTH | 388 | 388 | 77 | 2.14 | +3885 | +50.5 |
| SHOTS IN THE MOVE | 790 | 564 | 77 | 2.14 | +2039 | +26.5 |
| BEST FIRST | 68 | 68 | 68 | 1.89 | +3494 | +51.4 |
| RANDOM MOVE BY FIGURES | 108 | 108 | 67 | 1.86 | +1595 | +23.8 |
| FOLLOW UP WEIGHED | 65 | 65 | 65 | 1.81 | +7951 | +122.3 |
| REDIRECT COUNTER | 222 | 117 | 62 | 1.72 | +4550 | +73.4 |
| ONE FIGHT FORMULA | 624 | 377 | 60 | 1.67 | +211 | +3.5 |
| ADVANCE WORTH | 362 | 362 | 59 | 1.64 | +2949 | +50.0 |
| SAFER THAN THE JOB | 58 | 58 | 58 | 1.61 | +3176 | +54.8 |
| ADVANCE LANE KEPT | 55 | 55 | 55 | 1.53 | +0 | +0.0 |
| IDLE COST | 1358 | 797 | 51 | 1.42 | +676 | +13.2 |
| MISSILES IN THE MOVE | 209 | 135 | 48 | 1.33 | +1066 | +22.2 |
| ARTILLERY RE-ROLL WEIGHED | 47 | 47 | 47 | 1.31 | +0 | +0.0 |
| CHARGE NOW WEIGHED | 45 | 45 | 45 | 1.25 | +3491 | +77.6 |
| CANNON SIGHT KEPT | 42 | 42 | 42 | 1.17 | +0 | +0.0 |
| CHARGE NOW FIRST | 190 | 190 | 41 | 1.14 | -2564 | -62.5 |
| HONEST WORTH | 617 | 613 | 39 | 1.08 | +398 | +10.2 |
| SHOOTS FROM THE BEST SPOT | 94 | 94 | 38 | 1.06 | +917 | +24.1 |
| WALKS TO THE FIGHT | 87 | 87 | 36 | 1.00 | +145 | +4.0 |
| HOLDS AMBUSHERS | 35 | 35 | 35 | 0.97 | +0 | +0.0 |
| RESERVE FALL BACK | 34 | 34 | 34 | 0.94 | +1510 | +44.4 |
| RISK BY ARC | 211 | 204 | 34 | 0.94 | +967 | +28.4 |
| SET UP TOGETHER | 80 | 64 | 33 | 0.92 | +2421 | +73.4 |
| COMBAT PIVOT | 32 | 32 | 32 | 0.89 | +0 | +0.0 |
| CANNON PLANNED TARGET | 217 | 217 | 31 | 0.86 | -524 | -16.9 |
| REDIRECT WEIGHED | 31 | 31 | 31 | 0.86 | +2190 | +70.6 |
| RISK ONCE | 222 | 166 | 31 | 0.86 | +1354 | +43.7 |
| BEST FACING | 29 | 29 | 29 | 0.81 | +521 | +18.0 |
| INVITES THE FIGHT | 82 | 82 | 29 | 0.81 | +105 | +3.6 |
| MAX FOR POSITIONING | 433 | 263 | 29 | 0.81 | +180 | +6.2 |
| LONE WIZARD KEPT IN | 28 | 28 | 28 | 0.78 | +1699 | +60.7 |
| CAST JOB | 50 | 50 | 27 | 0.75 | +384 | +14.2 |
| STOPS SHORT OF THE FLANK | 27 | 27 | 27 | 0.75 | +1312 | +48.6 |
| BLOCKED WHEEL | 26 | 26 | 26 | 0.72 | +473 | +18.2 |
| KILLS COUNT | 122 | 118 | 26 | 0.72 | +1160 | +44.6 |
| MARCH ODDS | 24 | 24 | 24 | 0.67 | +154 | +6.4 |
| WEARS DOWN | 109 | 105 | 24 | 0.67 | +652 | +27.1 |
| KEEPS ITS TARGET | 119 | 119 | 23 | 0.64 | +444 | +19.3 |
| MARCH CHECK | 24 | 23 | 23 | 0.64 | +1251 | +54.4 |
| WHO HITS BACK | 23 | 23 | 23 | 0.64 | +947 | +41.2 |
| SCOUT WAITS | 21 | 21 | 21 | 0.58 | +0 | +0.0 |
| MOVE AND CAST | 20 | 20 | 20 | 0.56 | +511 | +25.5 |
| SHOT REPLANNED | 20 | 20 | 20 | 0.56 | +0 | +0.0 |
| BEST OVERALL | 19 | 19 | 19 | 0.53 | +904 | +47.6 |
| SHOOTERS IN TWO RANKS | 18 | 18 | 18 | 0.50 | +41 | +2.3 |
| CASTER AWAY FROM SCREEN | 17 | 17 | 17 | 0.47 | +0 | +0.0 |
| THROUGH LINE OF FIRE | 17 | 17 | 17 | 0.47 | +526 | +30.9 |
| WHOLE FIGHT GAIN | 44 | 42 | 16 | 0.44 | +746 | +46.6 |
| FRIENDS SHOTS CHECKED | 15 | 15 | 15 | 0.42 | +719 | +47.9 |
| MAKE SURE TOGETHER | 48 | 32 | 15 | 0.42 | +1594 | +106.3 |
| MISSILES NEXT TURN | 261 | 167 | 13 | 0.36 | +6 | +0.4 |
| WAR ENGINE JOBS | 26 | 26 | 13 | 0.36 | -465 | -35.8 |
| OPENS UP | 23 | 23 | 12 | 0.33 | +501 | +41.7 |
| STUCK PIVOT | 12 | 12 | 12 | 0.33 | +0 | +0.0 |
| BEST PRIZE | 11 | 11 | 11 | 0.31 | -362 | -32.9 |
| BIG CHARACTER SAFETY | 11 | 11 | 11 | 0.31 | -27 | -2.5 |
| CASTING BLOCK | 17 | 17 | 11 | 0.31 | +565 | +51.4 |
| OVERRUNS AWAY | 54 | 52 | 11 | 0.31 | +115 | +10.5 |
| BLOCKED CHARGE SKIPPED | 10 | 10 | 10 | 0.28 | +0 | +0.0 |
| MANOEUVRE | 13 | 13 | 10 | 0.28 | +304 | +30.4 |
| CASTS FROM BEHIND | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| LOST CHARGE | 155 | 154 | 9 | 0.25 | +194 | +21.6 |
| SHORT GUN FORWARD | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| STAY WEIGHED | 8 | 8 | 8 | 0.22 | +698 | +87.2 |
| BEST PREY | 33 | 33 | 7 | 0.19 | +87 | +12.4 |
| CHAFF PASSED | 7 | 7 | 7 | 0.19 | -2 | -0.3 |
| MODEL FACING | 7 | 7 | 7 | 0.19 | +1236 | +176.6 |
| MOVES UNITS SPELL | 7 | 7 | 7 | 0.19 | +138 | +19.7 |
| PIVOT GUARDS FLANK | 7 | 7 | 7 | 0.19 | -90 | -12.8 |
| RAIDS THE BAGGAGE NEXT TURN | 7 | 7 | 7 | 0.19 | +262 | +37.4 |
| RESTRAINS TO SHOOT | 7 | 7 | 7 | 0.19 | +179 | +25.5 |
| SPELLS IN THE FIGHT | 67 | 65 | 7 | 0.19 | +102 | +14.6 |
| WIDER SPREAD | 226 | 218 | 7 | 0.19 | +54 | +7.8 |
| PURSUES BIG PREY | 6 | 6 | 6 | 0.17 | -350 | -58.4 |
| SUPPORT NARROWED | 504 | 504 | 6 | 0.17 | -83 | -13.9 |
| WHOLE FIGHT | 24 | 24 | 6 | 0.17 | +630 | +105.0 |
| HUNT IN PAIRS | 26 | 12 | 5 | 0.14 | +80 | +15.9 |
| KEEP FALLS | 5 | 5 | 5 | 0.14 | +155 | +31.0 |
| ONE OBJECTIVE FORMULA | 154 | 64 | 4 | 0.11 | +108 | +27.0 |
| PERIAPT WORTH | 4 | 4 | 4 | 0.11 | +406 | +101.5 |
| REFUSING RETIRES | 14 | 14 | 4 | 0.11 | -1 | -0.2 |
| SURE CHARGE BEATS ADVANCE | 4 | 4 | 4 | 0.11 | -82 | -20.4 |
| CONTINUE AHEAD WEIGHED | 3 | 3 | 3 | 0.08 | +0 | +0.0 |
| FIRE AND FLEE | 3 | 3 | 3 | 0.08 | +19 | +6.4 |
| NEEDED THERE | 3 | 3 | 3 | 0.08 | +0 | +0.0 |
| SECOND CHARGER ADDS | 16 | 16 | 3 | 0.08 | +12 | +4.0 |
| SURE REACH TOGETHER | 34 | 27 | 3 | 0.08 | +7 | +2.3 |
| BACKUP TARGETS | 38 | 16 | 2 | 0.06 | +8 | +4.1 |
| CHARGER SLAIN LOST | 42 | 40 | 2 | 0.06 | +173 | +86.3 |
| EDGE GIVE GROUND | 6 | 6 | 2 | 0.06 | +48 | +23.9 |
| ELIXIR WORTH | 2 | 2 | 2 | 0.06 | +26 | +12.9 |
| JOINT CHARGE PLAN | 4 | 4 | 2 | 0.06 | +77 | +38.3 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| LONG SHOT | 27 | 26 | 2 | 0.06 | +23 | +11.6 |
| WAR ENGINE CHARGES | 6 | 6 | 2 | 0.06 | +204 | +101.8 |
| BLOWS WHERE AIMED | 28 | 26 | 1 | 0.03 | +115 | +115.4 |
| BOMBING RUN | 1 | 1 | 1 | 0.03 | +37 | +37.4 |
| CARRIES OUT SET-UP | 11 | 11 | 1 | 0.03 | -138 | -137.5 |
| DEFENSIVE ARMY | 7 | 7 | 1 | 0.03 | -6 | -5.7 |
| HUNT ADVANCE | 3 | 3 | 1 | 0.03 | +29 | +29.1 |
| LONE WIZARD HOLDS BACK | 8 | 8 | 1 | 0.03 | -119 | -119.3 |
| MOVE SPELL IN RANGE | 6 | 2 | 1 | 0.03 | +4 | +4.1 |
| REDIRECT BY WHAT IT STOPS | 101 | 101 | 1 | 0.03 | +9 | +8.6 |
| SAFE SURE CHARGE | 1 | 1 | 1 | 0.03 | -27 | -27.2 |
| ALREADY CARRIED | 3 | not checked | - | - | - | - |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 20 | 20 | 0 | 0.00 | - | - |
| CARRIES OUT COUNTER | 2 | 2 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 51 | trace | - | - | - | - |
| CATCH FLIERS | 2 | not checked | - | - | - | - |
| CHARIOT WIZARD CAREFUL | 5 | 5 | 0 | 0.00 | - | - |
| CHEAP HELPER | 4 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 41 | not checked | - | - | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT LIFT | 5 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 373 | not checked | - | - | - | - |
| FRIEND IN REACH | 352 | not checked | - | - | - | - |
| GIVES UP | 8 | 8 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 1 | not checked | - | - | - | - |
| GROUND FLIERS | 5 | not checked | - | - | - | - |
| HELPER ALREADY ASKED | 4 | not checked | - | - | - | - |
| HELPER UNSEEN | 47 | 45 | 0 | 0.00 | - | - |
| HILL BY ITS CHANCE | 39 | 39 | 0 | 0.00 | - | - |
| HUNT DROPPED | 2 | trace | - | - | - | - |
| HUNT KEPT | 2 | trace | - | - | - | - |
| HUNT RESULT | 4 | trace | - | - | - | - |
| HUNT THE GUNS | 4 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 7 | 7 | 0 | 0.00 | - | - |
| KEEPS ITS PREY | 1 | 1 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 21 | not checked | - | - | - | - |
| LURE BY WHAT IT DRAWS | 12 | 12 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 5 | trace | - | - | - | - |
| MARCH OVER CASTS | 24 | 24 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 13 | 13 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 29 | trace | - | - | - | - |
| MOVE SPELL SPOT | 21 | not checked | - | - | - | - |
| NOT NEEDED | 9 | 9 | 0 | 0.00 | - | - |
| NOT TURNED | 400 | 400 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 34 | not checked | - | - | - | - |
| OPENS A LANE | 11 | 5 | 0 | 0.00 | - | - |
| PAIR SET-UP | 5 | not checked | - | - | - | - |
| PLAN RESULT | 2825 | trace | - | - | - | - |
| RAIDS THE BAGGAGE | 1 | 1 | 0 | 0.00 | - | - |
| RANDOM MOVER NO PROMISE | 25 | 25 | 0 | 0.00 | - | - |
| SCOUT SPOT | 19 | 19 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 25 | 25 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 23 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 20 | not checked | - | - | - | - |
| SET-UP MISSED | 3 | trace | - | - | - | - |
| SHOOTER COUNTED ONCE | 1 | 1 | 0 | 0.00 | - | - |
| SPELL CATCH ODDS | 2 | not checked | - | - | - | - |
| SPELL OFF EDGE | 1 | not checked | - | - | - | - |
| SPELL SETS UP CHARGE | 22 | not checked | - | - | - | - |
| SPELL WORTH | 120 | not checked | - | - | - | - |
| STABLE ROLE | 758 | 757 | 0 | 0.00 | - | - |
| STOPS | 2 | 2 | 0 | 0.00 | - | - |
| TURN WORTH | 19 | 19 | 0 | 0.00 | - | - |
| TWO OR MORE ARRIVE | 26 | 23 | 0 | 0.00 | - | - |
| WOUNDED STAYS OUT | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: jc-opp-1e5408d-p4

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 14.17 | 13.56 | 46.6 |
| FALLBACK | gate | 0.61 | 0.72 | 33.6 |
| CHARGE NOW FIRST | rule | 0.44 | 0.69 | 62.5 |
| TURN GATE | gate | 0.53 | 0.33 | 46.9 |
| CANNON PLANNED TARGET | rule | 0.39 | - | 42.7 |
| WAR ENGINE JOBS | rule | 0.28 | 0.08 | 35.8 |
| BEST PRIZE | rule | 0.17 | 0.14 | 32.9 |
| AFTERMATH BAND | gate | 0.08 | 0.19 | 2.5 |
| SUPPORT REQUEST | gate | 0.19 | 0.03 | 71.7 |
| PIVOT GUARDS FLANK | rule | 0.14 | 0.06 | 12.8 |
| BIG CHARACTER SAFETY | rule | 0.11 | 0.06 | 6.1 |
| FIGHT ORDER BAND | gate | 0.06 | 0.11 | 2.1 |
| PURSUES BIG PREY | rule | 0.11 | 0.06 | 58.4 |
| SUPPORT NARROWED | rule | 0.08 | 0.08 | 13.9 |
| PATHS CROSS | rule | 0.06 | 0.08 | 14.4 |
| STOPS SHORT OF THE FLANK | rule | 0.08 | 0.06 | 4.5 |
| MARCH ODDS | rule | 0.08 | 0.03 | 32.2 |
| SURE CHARGE BEATS ADVANCE | rule | - | 0.11 | 20.4 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.06 | 0.03 | 30.9 |
| CHARGE NOW WEIGHED | rule | 0.08 | - | 32.0 |
| REDIRECT WEIGHED | rule | 0.06 | 0.03 | 6.2 |
| LONE CHARACTER SAFE SPOT | gate | 0.06 | - | 45.3 |
| WHO HITS BACK | rule | 0.06 | - | 1.0 |
| BLOCKED WHEEL | rule | - | 0.03 | 1.1 |
| CARRIES OUT SET-UP | rule | - | 0.03 | 137.5 |
| CHAFF PASSED | rule | - | 0.03 | 2.4 |
| DEFENSIVE ARMY | rule | 0.03 | - | 5.7 |
| FRIENDS SHOTS CHECKED | rule | - | 0.03 | 4.5 |
| LONE WIZARD HOLDS BACK | rule | - | 0.03 | 119.3 |
| NO REASON | gate | - | 0.03 | 70.2 |
| RULE SWITCHED OFF | gate | 0.03 | - | 51.7 |
| SAFE SURE CHARGE | rule | - | 0.03 | 27.2 |
| SAFER THAN THE JOB | rule | 0.03 | - | 13.9 |

### Plans: jc-opp-1e5408d-p4

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 10.3 | 18% | 173 | 316 | 182% |
| Mine | charge | 3.0 | 50% | 209 | 218 | 104% |
| Mine | close in | 4.7 | 30% | 211 | 175 | 83% |
| Mine | hold | 5.0 | 30% | 299 | 0 | 0% |
| Mine | join | 0.5 | 95% | 10 | 0 | 0% |
| Mine | shoot | 10.0 | 63% | 394 | 887 | 225% |
| Mine | support | 5.4 | 93% | 55 | 0 | 0% |
| Opponent | advance | 10.9 | 19% | 174 | 307 | 176% |
| Opponent | charge | 4.8 | 56% | 389 | 460 | 118% |
| Opponent | close in | 6.4 | 27% | 382 | 214 | 56% |
| Opponent | hold | 4.2 | 33% | 301 | 0 | 0% |
| Opponent | join | 0.6 | 90% | 25 | 0 | 0% |
| Opponent | shoot | 4.6 | 55% | 94 | 319 | 339% |
| Opponent | support | 7.9 | 88% | 59 | 0 | 0% |

### Packages: hunt the guns, jc-opp-1e5408d-p4

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 19 |
| Opponent | 0.1 | 4 | 0 | 50% | 50% | 0% | 3.0 | 318 | 97 | 50% | 129 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 58 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 151 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| High Elf Realms | 0.1 | 1 | 0 | 100% | 100% | 0% | 3.0 | 109 | 97 | 100% | 76 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 28 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 195 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 309 |
| Tomb Kings of Khemri | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Vampire Counts | 0.4 | 3 | 0 | 33% | 33% | 0% | 3.0 | 388 | 97 | 33% | 26 |
| Warriors of Chaos | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 78 |
| Wood Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 21 |

### Battle groups: jc-opp-1e5408d-p4

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 2.2 | 52% | 54% | 15% | 33% | 17% | 0% | 9% | 66% | 9% |
| Opponent | REDIRECT COUNTER | 4.0 | 27% | 82% | 28% | 36% | 11% | 4% | 18% | 61% | 7% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: jc-opp-1e5408d-p4

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 4 | 0 (4) | 0 | 0 | 62 | 25% | 2.0 | 0 (1) | 0 (2) | - | 0 (2) | 0 (1) |
| Mine | Chaff | 34 | 35 (34) | 7 | 28 | 60 | 26% | 2.4 | 13 (14) | 0 (7) | 73 (13) | 17 (22) | 70 (12) |
| Mine | Character | 106 | 34 (106) | 34 | 0 | 39 | 15% | 2.5 | 38 (31) | 32 (57) | 31 (6) | 28 (46) | 39 (48) |
| Mine | Clean-up | 22 | 78 (22) | 51 | 27 | 40 | 36% | 2.9 | 0 (2) | 90 (16) | 78 (4) | 87 (10) | 72 (12) |
| Mine | Early | 1 | 0 (1) | 0 | 0 | 0 | 0% | 6.0 | - | - | 0 (1) | 0 (1) | - |
| Mine | Fast | 4 | 148 (4) | 148 | 0 | 100 | 0% | 3.2 | 0 (2) | 295 (2) | - | 113 (3) | 243 (1) |
| Mine | Fast Hammer | 41 | 52 (41) | 39 | 12 | 49 | 15% | 2.8 | 43 (27) | 90 (9) | 29 (5) | 55 (25) | 47 (16) |
| Mine | Fragile | 4 | 0 (4) | 0 | 0 | 73 | 25% | 3.0 | 0 (1) | 0 (2) | - | 0 (1) | 0 (2) |
| Mine | Hammer | 65 | 29 (65) | 17 | 12 | 43 | 18% | 2.5 | 28 (13) | 31 (45) | 16 (7) | 24 (40) | 35 (25) |
| Mine | Holder | 31 | 83 (31) | 14 | 69 | 31 | 45% | 2.4 | 63 (8) | 110 (17) | 41 (6) | 96 (19) | 66 (12) |
| Mine | Shooter | 34 | 52 (34) | 26 | 26 | 55 | 3% | 1.6 | 47 (8) | 55 (21) | 44 (5) | 50 (25) | 56 (9) |
| Mine | Support | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Mine | War machine | 56 | 68 (56) | 68 | 0 | 48 | 4% | 1.3 | 60 (16) | 58 (30) | 111 (10) | 54 (9) | 70 (47) |
| Mine | Wizard | 17 | 3 (17) | 3 | 0 | 60 | 0% | 2.2 | 0 (5) | 0 (7) | - | 0 (5) | 0 (7) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | 0 (1) | - | - | - | 0 (1) |
| Opponent | Chaff | 75 | 44 (75) | 21 | 23 | 53 | 40% | 2.7 | 49 (31) | 15 (17) | 62 (27) | 55 (56) | 7 (19) |
| Opponent | Character | 97 | 57 (97) | 57 | 0 | 23 | 20% | 2.5 | 57 (43) | 72 (37) | 28 (7) | 53 (49) | 68 (38) |
| Opponent | Clean-up | 11 | 55 (11) | 23 | 32 | 32 | 36% | 2.9 | 0 (3) | 44 (6) | 131 (2) | 15 (6) | 79 (5) |
| Opponent | Fast | 1 | 142 (1) | 142 | 0 | 0 | 0% | 4.0 | - | 142 (1) | - | 142 (1) | - |
| Opponent | Fast Hammer | 60 | 43 (60) | 23 | 20 | 38 | 30% | 3.0 | 41 (26) | 34 (25) | 79 (9) | 40 (39) | 47 (21) |
| Opponent | Fragile | 17 | 0 (17) | 0 | 0 | 42 | 29% | 2.0 | 0 (5) | 0 (8) | 0 (4) | 0 (14) | 0 (3) |
| Opponent | Hammer | 65 | 47 (65) | 29 | 17 | 41 | 31% | 3.2 | 25 (20) | 55 (38) | 45 (7) | 47 (41) | 46 (24) |
| Opponent | Holder | 29 | 29 (29) | 12 | 18 | 29 | 48% | 3.9 | 0 (8) | 37 (17) | 42 (4) | 42 (17) | 10 (12) |
| Opponent | Shooter | 33 | 58 (33) | 14 | 44 | 56 | 0% | 1.5 | 56 (9) | 62 (21) | 37 (3) | 44 (18) | 73 (15) |
| Opponent | Support | 6 | 0 (6) | 0 | 0 | 85 | 17% | 3.6 | 0 (1) | 0 (2) | - | - | 0 (3) |
| Opponent | War machine | 6 | 104 (6) | 104 | 0 | 40 | 17% | 1.0 | 30 (3) | 209 (3) | - | 30 (3) | 209 (3) |
| Opponent | Wizard | 19 | 3 (19) | 3 | 0 | 53 | 11% | 2.1 | 8 (9) | 0 (3) | 0 (2) | 0 (9) | 17 (5) |

### Charged fights: jc-opp-1e5408d-p4

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 222 | 107 | 1.8 | 1.1 | 61 | 22 | +39 | 0 of 7 | 5 of 7 | -104 | +62 |
| Mine | Chaos Dwarfs | 4 | 69 | 199 | 2.2 | 1.1 | 88 | 0 | +88 | 1 of 9 | 8 of 9 | +0 | +100 |
| Mine | Dwarfen Mountain Holds | 3 | 564 | 209 | 2.3 | 1.4 | 90 | 9 | +81 | 2 of 7 | 5 of 7 | +20 | +127 |
| Mine | Empire of Man | 5 | 487 | 86 | 1.4 | 1.3 | 62 | 54 | +7 | 1 of 7 | 6 of 7 | -190 | +86 |
| Mine | Grand Cathay | 4 | 343 | 75 | 2.8 | 1.0 | 27 | 66 | -39 | 6 of 11 | 7 of 11 | - | -39 |
| Mine | High Elf Realms | 4 | 141 | 109 | 2.8 | 1.0 | 40 | 32 | +8 | 0 of 11 | 8 of 11 | - | +8 |
| Mine | Kingdom of Bretonnia | 1 | 895 | 377 | 5.0 | 1.2 | 75 | 0 | +75 | 3 of 5 | 4 of 5 | +55 | +80 |
| Mine | Lizardmen | 1 | 55 | 1680 | 6.0 | 1.3 | 280 | 0 | +280 | 4 of 6 | 4 of 6 | +595 | +122 |
| Mine | Ogre Kingdoms | 2 | 62 | 0 | 3.0 | 1.2 | 0 | 39 | -39 | 1 of 6 | 4 of 6 | +0 | -47 |
| Mine | Skaven | 2 | 280 | 33 | 3.0 | 1.0 | 11 | 0 | +11 | 2 of 6 | 4 of 6 | - | +11 |
| Mine | Tomb Kings of Khemri | 2 | 158 | 657 | 5.0 | 1.2 | 131 | 26 | +105 | 3 of 10 | 9 of 10 | +72 | +113 |
| Mine | Vampire Counts | 2 | 450 | 175 | 2.0 | 1.0 | 88 | 82 | +5 | 3 of 4 | 3 of 4 | - | +5 |
| Mine | Warriors of Chaos | 2 | 0 | 394 | 4.5 | 1.0 | 88 | 3 | +84 | 2 of 9 | 8 of 9 | - | +84 |
| **Mine** | all armies | 36 | 280 | 211 | 2.7 | 1.1 | 77 | 26 | +52 | 28 of 98 | 75 of 98 | +74 | +48 |
| Opponent | Empire of Man | 1 | 235 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | High Elf Realms | 5 | 229 | 752 | 5.0 | 1.2 | 150 | 39 | +112 | 16 of 25 | 17 of 25 | +272 | +72 |
| Opponent | Lizardmen | 2 | 0 | 568 | 4.5 | 1.0 | 126 | 16 | +111 | 5 of 9 | 8 of 9 | - | +111 |
| Opponent | Orc & Goblin Tribes | 3 | 0 | 918 | 6.0 | 1.0 | 153 | 35 | +118 | 4 of 18 | 14 of 18 | - | +118 |
| Opponent | Skaven | 4 | 89 | 161 | 2.5 | 1.0 | 64 | 82 | -17 | 8 of 10 | 3 of 10 | - | -17 |
| Opponent | Tomb Kings of Khemri | 2 | 148 | 130 | 2.5 | 1.0 | 52 | 65 | -13 | 1 of 5 | 3 of 5 | - | -13 |
| Opponent | Vampire Counts | 6 | 32 | 557 | 3.7 | 1.3 | 152 | 9 | +143 | 11 of 22 | 16 of 22 | +256 | +100 |
| Opponent | Warriors of Chaos | 7 | 0 | 353 | 2.6 | 1.2 | 137 | 6 | +131 | 9 of 18 | 10 of 18 | +69 | +143 |
| Opponent | Wood Elf Realms | 6 | 13 | 568 | 4.7 | 1.2 | 122 | 23 | +99 | 12 of 28 | 24 of 28 | +133 | +88 |
| **Opponent** | all armies | 36 | 64 | 494 | 3.8 | 1.2 | 132 | 28 | +103 | 66 of 135 | 95 of 135 | +192 | +87 |

### Effective charges: jc-opp-1e5408d-p4

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 7 | 1 (net -104) | 1 (net +178) | 1 (net -52) | 1 (net +0) | 0 | 2 (net +49) | 1 | 17% (1 of 6) |
| Mine | Chaos Dwarfs | 9 | 0 | 0 | 2 (net +0) | 1 (net +0) | 2 (net +28) | 3 (net +188) | 1 | 25% (2 of 8) |
| Mine | Dwarfen Mountain Holds | 7 | 4 (net +127) | 0 | 1 (net +60) | 1 (net +0) | 0 | 1 (net +0) | 0 | 14% (1 of 7) |
| Mine | Empire of Man | 7 | 1 (net +0) | 0 | 1 (net +0) | 2 (net -105) | 0 | 2 (net +42) | 1 | 17% (1 of 6) |
| Mine | Grand Cathay | 11 | 0 | 0 | 3 (net -2) | 5 (net -103) | 0 | 3 (net +30) | 0 | 27% (3 of 11) |
| Mine | High Elf Realms | 11 | 0 | 1 (net +0) | 1 (net +0) | 2 (net +35) | 1 (net +54) | 5 (net +62) | 1 | 10% (1 of 10) |
| Mine | Kingdom of Bretonnia | 5 | 1 (net +210) | 0 | 0 | 1 (net +55) | 0 | 1 (net +0) | 2 | 0% (0 of 3) |
| Mine | Lizardmen | 6 | 2 (net +0) | 0 | 1 (net +0) | 2 (net +712) | 0 | 1 (net +255) | 0 | 17% (1 of 6) |
| Mine | Ogre Kingdoms | 6 | 1 (net +0) | 1 (net +0) | 3 (net +0) | 0 | 0 | 0 | 1 | 60% (3 of 5) |
| Mine | Skaven | 6 | 1 (net +0) | 0 | 0 | 1 (net +0) | 0 | 4 (net +16) | 0 | 0% (0 of 6) |
| Mine | Tomb Kings of Khemri | 10 | 0 | 0 | 2 (net +110) | 3 (net +108) | 3 (net +106) | 1 (net +186) | 1 | 22% (2 of 9) |
| Mine | Vampire Counts | 4 | 0 | 0 | 1 (net -329) | 2 (net +95) | 1 (net +160) | 0 | 0 | 25% (1 of 4) |
| Mine | Warriors of Chaos | 9 | 1 (net +285) | 0 | 2 (net -2) | 0 | 3 (net +101) | 2 (net +86) | 1 | 25% (2 of 8) |
| Opponent | High Elf Realms | 25 | 3 (net -107) | 1 (net +85) | 5 (net +153) | 7 (net +193) | 0 | 5 (net +218) | 4 | 24% (5 of 21) |
| Opponent | Lizardmen | 9 | 0 | 0 | 2 (net +155) | 2 (net +184) | 0 | 2 (net +0) | 3 | 33% (2 of 6) |
| Opponent | Orc & Goblin Tribes | 18 | 2 (net +148) | 3 (net +189) | 0 | 3 (net +73) | 1 (net +83) | 1 (net -110) | 8 | 0% (0 of 10) |
| Opponent | Skaven | 10 | 3 (net -107) | 1 (net -41) | 3 (net +0) | 2 (net +322) | 0 | 1 (net -454) | 0 | 30% (3 of 10) |
| Opponent | Tomb Kings of Khemri | 5 | 1 (net -325) | 0 | 1 (net +92) | 2 (net +20) | 0 | 0 | 1 | 25% (1 of 4) |
| Opponent | Vampire Counts | 22 | 5 (net +114) | 0 | 2 (net +14) | 3 (net +0) | 4 (net +76) | 6 (net +300) | 2 | 10% (2 of 20) |
| Opponent | Warriors of Chaos | 18 | 3 (net +112) | 1 (net +0) | 2 (net +40) | 3 (net +363) | 4 (net +207) | 2 (net +70) | 3 | 13% (2 of 15) |
| Opponent | Wood Elf Realms | 28 | 7 (net +1) | 0 | 4 (net +262) | 6 (net +163) | 1 (net +36) | 7 (net +63) | 3 | 16% (4 of 25) |

### Charged fights, damage counted: jc-opp-1e5408d-p4

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 12 | 208 | 259 | +75 | 96 | 34 | +62 | +29.6 |
| Mine | 50-54% | 3 | 79 | 93 | +59 | 99 | 0 | +99 | +124.9 |
| Mine | Effective (55-75%) | 18 | 249 | 219 | -6 | 52 | 59 | -7 | -2.8 |
| Mine | 76-89% | 21 | 332 | 210 | +64 | 130 | 51 | +80 | +24.0 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 25 | 229 | 145 | +73 | 127 | 25 | +102 | +44.5 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 10 | 456 | 103 | +89 | 107 | 0 | +107 | +23.5 |
| Mine | No odds | 9 | 374 | 148 | +4 | 92 | 71 | +22 | +5.8 |
| Mine | All fights | 98 | 284 | 181 | +52 | 104 | 39 | +65 | +23.0 |
| Opponent | Long shot (under 50%) | 24 | 232 | 327 | +10 | 89 | 86 | +2 | +0.9 |
| Opponent | 50-54% | 6 | 220 | 166 | +102 | 121 | 55 | +65 | +29.7 |
| Opponent | Effective (55-75%) | 19 | 298 | 262 | +122 | 132 | 38 | +94 | +31.5 |
| Opponent | 76-89% | 28 | 349 | 203 | +168 | 198 | 23 | +175 | +50.2 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 24 | 323 | 185 | +121 | 178 | 47 | +131 | +40.5 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 10 | 442 | 95 | +125 | 130 | 14 | +116 | +26.3 |
| Opponent | No odds | 24 | 353 | 168 | +80 | 158 | 63 | +95 | +27.0 |
| Opponent | All fights | 135 | 318 | 214 | +103 | 150 | 48 | +102 | +31.9 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| jc-opp-1e5408d-p4 | move | 358 | 83 (23%) | 59 (16%) | 49 (14%) | 226 (63%) |
| jc-opp-1e5408d-p4 | objective | 400 | 52 (13%) | 41 (10%) | 58 (14%) | 290 (72%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0114, L0130, L2527, L2634 |
| Charmed Shield | Opponent | L0434, L0624, L0926, L1034, L1126, L1427, L2227, L2527, L2634, L3234 |
| Clockwork Compass | Mine | L1220 |
| Elixir of Power | Mine | L1126 |
| Elixir of Power | Opponent | L0819, L1719, L1819 |
| Fistful of Laurels | Mine | L1819, L1835 |
| Invocation of Nehek | Mine | L2527 |
| Invocation of Nehek | Opponent | L0624, L1427, L2227, L2527 |
| Opal Amulet | Mine | L1427 |
| Opal Amulet | Opponent | L0114, L0214, L1314 |
| Periapt of Soul Exchange | Mine | L2021, L2123 |
| Periapt of Soul Exchange | Opponent | L0520, L1220, L1621, L2021 |
| Ring of Doom | Mine | L0214, L0230, L1126, L1220, L1523 |
| Ring of Doom | Opponent | L0315, L1331, L2331 |
| Ring of Jet | Mine | L1017, L1034, L1126, L1220 |
| Standard of the Fell Warrior | Mine | L1314, L1331 |
| Standard of the Fell Warrior | Opponent | L0713 |
| Storm Daemon (Renegade 2.0) | Mine | L2123 |
| Storm Daemon (Renegade 2.0) | Opponent | L1621, L2021 |
| Twice-Blessed Armour | Mine | L0713, L0729, L1017, L1034 |
| Witch Hunter's Ward | Mine | L0713, L0729, L0819, L0835 |
| Witch Hunter's Ward | Opponent | L0608 |

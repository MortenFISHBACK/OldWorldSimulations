# Doctrine scorecard: jb-h2h-opp-b54c226-p4

### Scorecard: jb-h2h-opp-b54c226-p4

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0114 | 6 | 1 | Mine | no | 5 | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| L0114 | 6 | 1 | Opponent | no | 6 | 1 | 1 | 1 | 0 | 0 | 0 | 0 |
| L0130 | 4 | 1 | Mine | yes | 6 | - | 0 | 2 | 1 | 0 | 0 | 0 |
| L0130 | 4 | 1 | Opponent | no | 0 | 1 | 4 | 1 | 0 | 0 | 0 | 0 |
| L0214 | 4 | 1 | Mine | no | 0 | 2 | 2 | 2 | 0 | 0 | 0 | 30 |
| L0214 | 4 | 1 | Opponent | no | 2 | 1 | 1 | 1 | 0 | 0 | 0 | 0 |
| L0230 | 2 | 1 | Mine | - | - | 1 | 5 | 3 | 1 | 0 | 0 | 170 |
| L0230 | 2 | 1 | Opponent | - | - | 2 | 3 | 3 | 0 | 0 | 0 | 0 |
| L0315 | 3 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 590 |
| L0315 | 3 | 1 | Opponent | yes | 5 | 2 | 1 | 1 | 0 | 0 | 0 | 0 |
| L0332 | 2 | 1 | Mine | - | - | - | 1 | 0 | 1 | 0 | 0 | 360 |
| L0332 | 2 | 1 | Opponent | - | - | 2 | 1 | 5 | 1 | 0 | 0 | 0 |
| L0417 | 3 | 1 | Mine | yes | 4 | 2 | 9 | 1 | 1 | 0 | 0 | 0 |
| L0417 | 3 | 1 | Opponent | yes | 1 | 2 | 5 | 0 | 1 | 0 | 0 | 135 |
| L0434 | 2 | 1 | Mine | - | - | 2 | 2 | 0 | 0 | 0 | 0 | 0 |
| L0434 | 2 | 1 | Opponent | - | - | 1 | 3 | 1 | 0 | 0 | 0 | 0 |
| L0520 | 4 | 1 | Mine | no | 0 | 6 | 1 | 1 | 0 | 0 | 0 | 1120 |
| L0520 | 4 | 1 | Opponent | no | 1 | - | 1 | 3 | 1 | 0 | 0 | 210 |
| L0608 | 2 | 1 | Mine | - | - | - | 0 | 2 | 0 | 0 | 0 | 801 |
| L0608 | 2 | 1 | Opponent | - | - | - | 0 | 2 | 0 | 0 | 0 | 605 |
| L0624 | 6 | 1 | Mine | no | 0 | 3 | 2 | 0 | 0 | 0 | 0 | 801 |
| L0624 | 6 | 1 | Opponent | no | 6 | 3 | 1 | 1 | 0 | 0 | 0 | 0 |
| L0713 | 5 | 1 | Mine | yes | - | 1 | 4 | 2 | 0 | 0 | 0 | 420 |
| L0713 | 5 | 1 | Opponent | no | - | 4 | 3 | 0 | 2 | 0 | 0 | 317 |
| L0729 | 3 | 1 | Mine | no | 2 | 3 | 0 | 0 | 0 | 0 | 0 | 590 |
| L0729 | 3 | 1 | Opponent | no | 0 | 2 | 5 | 1 | 1 | 0 | 0 | 170 |
| L0819 | 3 | 1 | Mine | no | 0 | 3 | 1 | 0 | 0 | 0 | 0 | 715 |
| L0819 | 3 | 1 | Opponent | no | 0 | 2 | 2 | 2 | 2 | 0 | 0 | 543 |
| L0835 | 1 | 1 | Mine | no | 0 | 4 | 0 | 0 | 0 | 0 | 0 | 717 |
| L0835 | 1 | 1 | Opponent | no | 2 | 6 | 2 | 1 | 0 | 0 | 0 | 0 |
| L0926 | 2 | 1 | Mine | - | - | 4 | 1 | 2 | 0 | 0 | 0 | 537 |
| L0926 | 2 | 1 | Opponent | - | - | 2 | 1 | 6 | 0 | 0 | 0 | 0 |
| L1017 | 3 | 1 | Mine | no | 6 | 2 | 3 | 0 | 1 | 0 | 0 | 330 |
| L1017 | 3 | 1 | Opponent | yes | 1 | 2 | 4 | 0 | 3 | 0 | 0 | 224 |
| L1034 | 2 | 1 | Mine | - | - | 2 | 1 | 1 | 1 | 0 | 0 | 330 |
| L1034 | 2 | 1 | Opponent | - | - | 3 | 3 | 7 | 1 | 0 | 0 | 527 |
| L1126 | 4 | 1 | Mine | no | 0 | 5 | 1 | 0 | 1 | 0 | 0 | 330 |
| L1126 | 4 | 1 | Opponent | no | 7 | 2 | 6 | 3 | 1 | 0 | 0 | 0 |
| L1220 | 2 | 1 | Mine | - | - | 2 | 4 | 0 | 0 | 0 | 0 | 330 |
| L1220 | 2 | 1 | Opponent | - | - | - | 2 | 2 | 0 | 0 | 0 | 440 |
| L1314 | 6 | 1 | Mine | no | 2 | 3 | 2 | 0 | 0 | 0 | 0 | 302 |
| L1314 | 6 | 1 | Opponent | no | 5 | 2 | 4 | 0 | 1 | 0 | 0 | 123 |
| L1331 | 5 | 1 | Mine | yes | - | - | 0 | 3 | 0 | 0 | 0 | 140 |
| L1331 | 5 | 1 | Opponent | no | - | - | 0 | 4 | 1 | 0 | 0 | 170 |
| L1427 | 5 | 1 | Mine | yes | - | 3 | 3 | 1 | 0 | 0 | 0 | 0 |
| L1427 | 5 | 1 | Opponent | yes | - | 2 | 2 | 2 | 0 | 0 | 0 | 0 |
| L1523 | 5 | 1 | Mine | yes | - | 2 | 2 | 2 | 0 | 0 | 0 | 0 |
| L1523 | 5 | 1 | Opponent | yes | - | 2 | 6 | 1 | 0 | 0 | 0 | 126 |
| L1621 | 1 | 1 | Mine | no | 0 | 2 | 4 | 1 | 0 | 0 | 0 | 200 |
| L1621 | 1 | 1 | Opponent | no | 1 | 3 | 2 | 2 | 1 | 0 | 0 | 565 |
| L1719 | 3 | 1 | Mine | yes | 1 | 2 | 7 | 0 | 0 | 0 | 0 | 184 |
| L1719 | 3 | 1 | Opponent | yes | 2 | 2 | 7 | 0 | 0 | 0 | 0 | 0 |
| L1819 | 1 | 1 | Mine | no | 2 | 4 | 3 | 0 | 1 | 0 | 0 | 185 |
| L1819 | 1 | 1 | Opponent | no | 4 | 2 | 5 | 0 | 0 | 0 | 0 | 0 |
| L1835 | 5 | 1 | Mine | yes | - | 6 | 1 | 2 | 1 | 0 | 0 | 0 |
| L1835 | 5 | 1 | Opponent | yes | - | 2 | 3 | 2 | 0 | 0 | 0 | 0 |
| L2021 | 5 | 1 | Mine | no | - | 6 | 2 | 3 | 1 | 0 | 0 | 420 |
| L2021 | 5 | 1 | Opponent | no | - | 6 | 1 | 4 | 0 | 0 | 0 | 355 |
| L2123 | 5 | 1 | Mine | yes | - | - | 3 | 3 | 0 | 0 | 0 | 355 |
| L2123 | 5 | 1 | Opponent | yes | - | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L2227 | 1 | 1 | Mine | no | 0 | 2 | 3 | 0 | 0 | 0 | 0 | 0 |
| L2227 | 1 | 1 | Opponent | yes | 1 | 1 | 3 | 1 | 0 | 0 | 0 | 0 |
| L2331 | 3 | 1 | Mine | no | 0 | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L2331 | 3 | 1 | Opponent | yes | 3 | 6 | 3 | 0 | 1 | 0 | 0 | 170 |
| L2527 | 1 | 1 | Mine | no | 0 | 3 | 3 | 1 | 0 | 0 | 0 | 0 |
| L2527 | 1 | 1 | Opponent | no | 0 | 1 | 1 | 2 | 0 | 0 | 0 | 190 |
| L2634 | 6 | 1 | Mine | no | 5 | 2 | 5 | 1 | 0 | 0 | 0 | 0 |
| L2634 | 6 | 1 | Opponent | no | 3 | 2 | 2 | 1 | 1 | 0 | 0 | 0 |
| L2930 | 2 | 1 | Mine | - | - | 5 | 4 | 1 | 0 | 0 | 0 | 0 |
| L2930 | 2 | 1 | Opponent | - | - | 6 | 0 | 3 | 0 | 0 | 0 | 0 |
| L3234 | 6 | 1 | Mine | no | 0 | 2 | 5 | 2 | 0 | 0 | 0 | 170 |
| L3234 | 6 | 1 | Opponent | no | 0 | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 32% | 1.6 | 2.9 | 2.5 | 1.1 | 0.3 | 0.0 | 0.0 | 281.3 |
| **Average** | | | Opponent | 36% | 2.4 | 2.5 | 2.7 | 1.8 | 0.5 | 0.0 | 0.0 | 135.3 |

### KPIs: jb-h2h-opp-b54c226-p4

Rules off - Mine only: JOINS A FRIEND.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 28% (48 of 169) | 1% (2 of 179) | 14% (50 of 348) |
| Winner chose to follow up after the loser gave ground |  | 98% (62 of 63); on the table 98% | 98% (48 of 49); on the table 100% | 98% (110 of 112); on the table 99% |
| Winner chose to pursue after the loser fell back in good order |  | 100% (14 of 14); on the table 100% | 100% (18 of 18); on the table 100% | 100% (32 of 32); on the table 100% |
| Winner chose to pursue after the loser fled |  | 81% (21 of 26); on the table 81% | 80% (20 of 25); on the table 84% | 80% (41 of 51); on the table 82% |
| Winner chose to follow up or pursue (all three) |  | 94% (97 of 103); on the table 94% | 93% (86 of 92); on the table 96% | 94% (183 of 195); on the table 95% |
| Magic missiles tried each own turn | 50%+ | 29% (78 of 269) | 34% (58 of 173) | 31% (136 of 442) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 41% (78 of 188) | 47% (58 of 124) | 44% (136 of 312) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 55% (24 of 44) | 52% (34 of 65) | 53% (58 of 109) |
| Points that never fought | lower | 36% (24625 of 67942) | 36% (26058 of 71984) | 36% (50683 of 139926) |
|   infantry points that never fought | lower | 45% (6944 of 15347) | 62% (8552 of 13804) | 53% (15496 of 29151) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 54% (147 of 270) | 56% (157 of 280) | 55% (304 of 550) |
| Bound items with a magic missile used (at least once a game) |  | 91% (20 of 22); 1.8 uses a game | 89% (8 of 9); 0.8 uses a game | 90% (28 of 31); 1.3 uses a game |
| Bound items with another spell used |  | 44% (7 of 16); 0.5 uses a game | 30% (6 of 20); 0.2 uses a game | 36% (13 of 36); 0.3 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 58% (11 of 19); 0.3 uses a game | 80% (12 of 15); 0.3 uses a game | 68% (23 of 34); 0.3 uses a game |
|   their share of the points of units over 100 pts | lower | 51% (29236 of 57750) | 48% (30260 of 63347) | 49% (59496 of 121097) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.3 (25%) | 1.0 (30%) | 2.3 (27%) |
| MARCHED: its unit marched | 1.4 (27%) | 0.4 (13%) | 1.9 (22%) |
| CHARGED: its unit charged | 0.3 (5%) | 0.1 (3%) | 0.4 (4%) |
| IN COMBAT: engaged in combat | 1.3 (25%) | 0.4 (13%) | 1.8 (21%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.3 (10%) | 0.3 (4%) |
| FLEEING: fleeing | 0.0 (1%) | 0.1 (3%) | 0.1 (1%) |
| GONE: slain | 0.6 (11%) | 0.9 (27%) | 1.4 (17%) |
| OFF THE TABLE: off the table or not arrived | 0.3 (6%) | 0.0 (0%) | 0.3 (4%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.1 | 1.6 | 2.2 | 3.8 | 0.5 | 2.4 |
| not cast | 3.0 | 2.4 | 2.6 | 8.5 | 1.5 | 20.6 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.7 (8%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.1 (45%) | 0.1 (5%) | 2.3 (27%) | 0.4 (24%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.9 (22%) | 0.4 (30%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.4 (4%) | 0.1 (6%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.2 (6%) | 0.2 (9%) | 0.7 (27%) | 1.8 (21%) | 0.3 (22%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.2 (6%) | 0.1 (5%) | 0.3 (11%) | 0.3 (4%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.1 (4%) | 0.0 (0%) | 0.0 (1%) | 0.1 (1%) | 0.0 (0%) | 0.3 (1%) |
| GONE: slain | 0.6 (18%) | 0.5 (20%) | 0.3 (11%) | 1.4 (17%) | 0.1 (9%) | 3.1 (15%) |
| OFF THE TABLE: off the table or not arrived | 0.3 (11%) | 0.1 (3%) | 0.2 (6%) | 0.3 (4%) | 0.0 (2%) | 0.7 (4%) |
| STUPIDITY: Stupidity | 0.1 (5%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (2%) | 0.3 (13%) | 0.0 (0%) | 0.0 (0%) | 0.1 (7%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.5 (49%) | 0.1 (5%) | 1.0 (39%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 14.6 (71%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.6 a game | 0.7 a game | 1.2 a game |
| stood (cast and not dispelled) | 62% (32 of 52) | 73% (11 of 15) | 64% (43 of 67) |
| the unit moved after it | 84% (27 of 32) | 64% (7 of 11) | 79% (34 of 43) |
| it charged on its next turn | 9% (3 of 32) | 0% (0 of 11) | 7% (3 of 43) |
| the enemy charged it first | 19% (6 of 32) | 18% (2 of 11) | 19% (8 of 43) |
| it fought by the end of its next turn | 19% (6 of 32) | 18% (2 of 11) | 19% (8 of 43) |
| it moved out of a charge the enemy had planned (not charged first) | 19% (6 of 32) | 18% (2 of 11) | 19% (8 of 43) |
| none of these (no charge, no fight, no charge escaped) | 50% (16 of 32) | 64% (7 of 11) | 53% (23 of 43) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 65% (606 of 930) | 54% (284 of 529) | 61% (890 of 1459) |
|   cavalry | 60% (50 of 83) | 68% (81 of 120) | 65% (131 of 203) |
|   character | 45% (50 of 111) | 17% (21 of 122) | 30% (71 of 233) |
|   chariot | 49% (51 of 104) | 57% (12 of 21) | 50% (63 of 125) |
|   infantry | 62% (171 of 276) | 66% (146 of 222) | 64% (317 of 498) |
|   monster | 39% (18 of 46) | 23% (5 of 22) | 34% (23 of 68) |
|   war machine | 86% (266 of 310) | 86% (19 of 22) | 86% (285 of 332) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.2 (24%) | 1.6 (23%) | 3.8 (24%) |
| CHARGED: it charged | 1.1 (12%) | 1.6 (24%) | 2.8 (17%) |
| FLEEING: it fled or was fleeing | 0.2 (2%) | 0.1 (2%) | 0.4 (2%) |
| IN COMBAT: it fought this turn or the last | 0.9 (10%) | 0.5 (8%) | 1.4 (9%) |
| MOVED: a war machine that moved | 0.1 (1%) | 0.0 (0%) | 0.1 (0%) |
| HELD FIRE: a target, but it held its fire | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NO TARGET IN RANGE | 1.9 (22%) | 1.2 (18%) | 3.1 (20%) |
| ONLY IN COMBAT: the only targets were in combat | 0.6 (7%) | 0.4 (6%) | 1.1 (7%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.3 (15%) | 1.2 (17%) | 2.5 (16%) |
| SHELTERED: the target was sheltered | 0.3 (3%) | 0.0 (0%) | 0.3 (2%) |
| STUPIDITY | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR | 0.2 (3%) | 0.1 (2%) | 0.4 (2%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 5.9 | 1.4 | 81% | 5.3 pts | 31 pts |
| character | 2.3 | 0.8 | 77% | 8.3 pts | 19 pts |
| chariot | 1.8 | 0.7 | 70% | 11.3 pts | 20 pts |
| infantry | 13.1 | 4.5 | 75% | 8.4 pts | 111 pts |
| monster | 0.6 | 0.1 | 91% | 2.7 pts | 2 pts |
| war machine | 7.9 | 6.6 | 64% | 30.3 pts | 240 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.4 | 6.1 | 5.2 |
| Charges that made contact a game | 3.3 | 4.0 | 3.7 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.76 declared, 0.53 contact (17 units) | 0.75 declared, 0.56 contact (16 units) | 0.76 declared, 0.55 contact (33 units) |
|   per unit a game, units carrying another wizard (or one alone) | 1.00 declared, 1.00 contact (7 units) | 1.38 declared, 1.15 contact (13 units) | 1.25 declared, 1.10 contact (20 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.55 declared, 0.42 contact (247 units) | 0.64 declared, 0.41 contact (294 units) | 0.60 declared, 0.42 contact (541 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 59% (48 of 81) | 31% (5 of 16) | 67% (4 of 6) | 55% (57 of 103) |
| Character in a unit | 72% (23 of 32) | 62% (10 of 16) | 100% (1 of 1) | 69% (34 of 49) |
| Character on its own | 73% (24 of 33) | 46% (12 of 26) | 31% (24 of 77) | 44% (60 of 136) |
| Chariot | 73% (11 of 15) | 83% (10 of 12) | - | 78% (21 of 27) |
| Infantry | 58% (48 of 83) | 28% (7 of 25) | 0% (0 of 6) | 48% (55 of 114) |
| Monster | 62% (21 of 34) | 64% (9 of 14) | - | 62% (30 of 48) |
| Monstrous | 79% (11 of 14) | 57% (8 of 14) | - | 68% (19 of 28) |
| War Machines | 60% (26 of 43) | 100% (2 of 2) | - | 62% (28 of 45) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 92% (12 of 13); on the table 92% | 23% (23 of 102) | 22% | 32% (7 of 22) | 83% (5 of 6); 2.8 uses a game | 50% (1 of 2); 1.0 uses a game | 67% (4 of 6); 1.0 uses a game |
| Chaos Dwarfs | 4 | 93% (14 of 15); on the table 93% | 58% (14 of 24) | 30% | 62% (20 of 32) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
| Dwarfen Mountain Holds | 3 | - | - | 78% | 63% (17 of 27) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 6 | 88% (7 of 8); on the table 88% | 56% (10 of 18) | 53% | 61% (38 of 62) | 0.0 uses a game | 100% (2 of 2); 1.2 uses a game | 80% (4 of 5); 0.7 uses a game |
| Grand Cathay | 4 | 100% (22 of 22); on the table 100% | 30% (25 of 84) | 31% | 41% (15 of 37) | 100% (9 of 9); 8.5 uses a game | 50% (1 of 2); 0.2 uses a game | 25% (1 of 4); 0.2 uses a game |
| High Elf Realms | 9 | 96% (25 of 26); on the table 96% | 31% (11 of 36) | 37% | 53% (37 of 70) | 100% (7 of 7); 3.3 uses a game | 30% (9 of 30); 1.4 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | 100% (4 of 4); on the table 100% | - | 19% | 17% (1 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Lizardmen | 3 | 88% (7 of 8); on the table 88% | 50% (3 of 6) | 25% | 67% (14 of 21) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 2 | 100% (4 of 4); on the table 100% | 17% (1 of 6) | 42% | 79% (11 of 14) | 50% (1 of 2); 0.5 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 3 | 100% (14 of 14); on the table 100% | 26% (11 of 42) | 12% | 25% (6 of 24) | 0.0 uses a game | 0.0 uses a game | 67% (2 of 3); 0.7 uses a game |
| Skaven | 6 | 100% (4 of 4); on the table 100% | 22% (9 of 41) | 42% | 69% (31 of 45) | 100% (3 of 3); 0.8 uses a game | 0.0 uses a game | 67% (4 of 6); 0.7 uses a game |
| Tomb Kings of Khemri | 4 | 93% (14 of 15); on the table 93% | 0% (0 of 6) | 24% | 40% (8 of 20) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 8 | 100% (15 of 15); on the table 100% | 37% (22 of 59) | 35% | 55% (23 of 42) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 9 | 88% (23 of 26); on the table 88% | 33% (4 of 12) | 36% | 58% (42 of 72) | 100% (2 of 2); 0.8 uses a game | 0.0 uses a game | 100% (3 of 3); 0.3 uses a game |
| Wood Elf Realms | 6 | 86% (18 of 21); on the table 95% | 50% (3 of 6) | 37% | 61% (34 of 56) | 50% (1 of 2); 0.8 uses a game | 0.0 uses a game | 75% (3 of 4); 0.5 uses a game |

Flank and rear charges a unit could have turned to face (jb-h2h-opp-b54c226-p4, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 49% (43) | 44% (32) | 47% (75) |
| ...free all their last turn and able to turn (per game) | 0.78 | 0.53 | 1.31 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.17 | 0.22 | 0.39 |
| ...with the charger already in that arc before they moved (per game) | 0.44 | 0.25 | 0.69 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 2.33 | 1.31 | 3.64 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 1.19 | 0.61 | 1.81 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 5.19 | 6.56 | 11.75 |

### Quality by phase: jb-h2h-opp-b54c226-p4

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.1 | 3.6 |
| Strategy | Charge objectives carried out (made contact) | 51% (76 of 150) | 40% (70 of 173) |
| Strategy | Shoot objectives carried out (shot that target) | 46% (201 of 435) | 42% (69 of 164) |
| Strategy | Close-in objectives charged next turn | 12% (19 of 154) | 13% (30 of 234) |
| Strategy | Support requests answered (helper made contact too) | 82% (14 of 17) | 35% (13 of 37) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (2 of 2) | 100% (1 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | 58% (7 of 12) | 40% (4 of 10) |
| Strategy | Joined characters whose unit fought | 52% (21 of 40) | 38% (12 of 32) |
| Strategy | Lone characters that fought | 73% (61 of 83) | 80% (67 of 84) |
| Movement | Charges halted short of contact | 0.3 | 0.2 |
| Movement | Idle units | 1.1 | 1.8 |
| Movement | Points that never moved of their own | 281.3 | 135.3 |
| Movement | Fights charged into per game | 3.1 | 3.4 |
| Movement | Charges with odds: long shots (under 50%) | 15 of 99, net +152 | 22 of 102, net +33 |
| Movement | Charges with odds: sweet spot (55-75%) | 15 of 99, net +52 | 23 of 102, net +128 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 15 of 99, net +96 | 8 of 102, net +47 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 26 of 99, net +86 | 23 of 102, net +74 |
| Shooting | Shots by shooting units (incl. breath weapons) | 10.4 | 8.9 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 48% (179 of 376) | 39% (126 of 320) |
| Shooting | Points destroyed by shooting units | 53.7 | 38.6 |
| Shooting | War machine shots | 7.4 | 0.5 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 53% (140 of 266) | 21% (4 of 19) |
| Shooting | Points destroyed by war machines | 111.7 | 12.6 |
| Magic | Magic missiles cast | 1.5 | 1.1 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 35% (19 of 55) | 34% (13 of 38) |
| Magic | Wounds caused by magic missiles | 3.7 | 1.1 |
| Magic | Wounds caused by other spells | 2.3 | 1.1 |
| Magic | Points destroyed by magic (all spells) | 136.8 | 21.9 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.0 / 0.4 / 1.1 / 0.2 | 1.6 / 0.6 / 0.6 / 0.1 |
| Combat | Points destroyed in combat | 330.1 | 331.9 |
| Combat | Points run down | 83.8 | 49.7 |
| Combat | Net points per charged fight, damage counted | +90 | +82 |
| Combat | Net per 100 charger points, damage counted | +32.0 | +27.1 |
| Combat | First round won (charged fights) | 80% | 63% |
| Combat | Net points per charged fight | +83 | +78 |
| Combat | Net points per supported fight / lone fight | +184 / +66 | +70 / +80 |
| Combat | Charged fights on a top-3 enemy unit | 36 of 111 | 56 of 121 |
| Game | Points lost | 598.6 | 802.3 |
| Game | VP from objectives | 605.6 | 505.0 |
| Game | Lone holders (player turns) | 1.6 | 2.4 |

- Mine won / drew / lost: 20 / 7 / 9 of 36 ended games (of 36); mean margin (Mine - Opponent) +306 VP
- The side that went first won 17 of 29 games with a winner
- Points traded per game (both sides' losses): 1401
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: jb-h2h-opp-b54c226-p4

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 0.8 | +0.0 | 0.0 | 0.0 |
| ALREADY CARRIED | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARRIVAL HUNT | - | - | - | - | 0.0 | +0.4 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.4 | +0.0 | 0.0 | 30.3 | 0.1 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | 1.1 | +7.9 | 0.0 | 26.4 | 0.9 | +10.4 | 0.0 | 3.2 |
| BEST FACING | 1.1 | +29.5 | 0.0 | 27.9 | 0.5 | +23.9 | 0.0 | 49.7 |
| BEST FIRST | 4.3 | +176.0 | 181.3 | 75.4 | 4.2 | +155.0 | 127.2 | 118.8 |
| BEST OVERALL | 0.8 | +65.1 | 0.0 | 11.9 | 0.6 | +34.3 | 0.0 | 22.0 |
| BEST PREY | 0.4 | +22.8 | 6.1 | 3.2 | 0.9 | +29.8 | 15.0 | 29.7 |
| BEST PRIZE | 0.1 | -2.6 | 0.0 | 3.9 | 0.1 | -10.3 | 6.1 | 18.0 |
| BIG CHARACTER SAFETY | 0.3 | +0.5 | 0.0 | 0.0 | 0.2 | +0.6 | 0.0 | 42.8 |
| BLOCKED CHARGE SKIPPED | 0.2 | +0.0 | 0.0 | 16.2 | 0.1 | +0.0 | 8.9 | 0.0 |
| BLOCKED WHEEL | 0.5 | +0.6 | 0.0 | 13.6 | 0.8 | +24.1 | 0.0 | 3.3 |
| BLOWS WHERE AIMED | 0.2 | -10.4 | 19.7 | 8.8 | 0.2 | -20.6 | 32.8 | 6.5 |
| BOMBING RUN | 0.0 | +0.5 | 0.0 | 0.0 | - | - | - | - |
| BOUND ASSAILMENT | 0.0 | +0.0 | 0.0 | 3.5 | 0.1 | +0.0 | 0.0 | 8.2 |
| CANNON PLAN MISSED | 0.8 | +0.0 | 146.4 | 5.6 | 0.0 | +0.0 | 1.7 | 0.0 |
| CANNON PLANNED TARGET | 5.8 | +312.3 | 533.1 | 64.4 | 0.5 | +31.3 | 22.4 | 3.9 |
| CANNON SIGHT KEPT | 1.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 1.9 |
| CARRIES OUT COUNTER | 0.0 | +0.0 | 9.7 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT SET-UP | 0.2 | -0.0 | 48.0 | 0.0 | 0.1 | +0.0 | 15.1 | 0.0 |
| CAST JOB | 0.8 | +55.9 | 142.1 | 16.7 | 0.4 | +3.9 | 19.3 | 0.0 |
| CASTER AWAY FROM SCREEN | 0.3 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.2 | +10.5 | 11.8 | 8.2 | 0.1 | +2.6 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 1.0 | +0.0 | 0.0 | 45.8 | 0.4 | +0.0 | 0.0 | 11.1 |
| CASTS FROM BEHIND | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.1 | +0.9 | 0.0 | 0.0 | - | - | - | - |
| CATCH ODDS | 0.0 | +0.8 | 0.0 | 6.2 | - | - | - | - |
| CHAFF PASSED | 0.2 | -0.3 | 9.5 | 0.0 | 0.2 | -0.6 | 0.0 | 5.6 |
| CHARGE BAND | 0.2 | +0.0 | 34.7 | 1.4 | 0.1 | +0.0 | 13.9 | 0.0 |
| CHARGE NOW FIRST | 2.6 | +0.0 | 338.1 | 70.7 | 2.4 | +0.0 | 197.3 | 50.0 |
| CHARGE NOW WEIGHED | 0.5 | -23.3 | 8.8 | 10.0 | 0.6 | -77.5 | 4.5 | 32.3 |
| CHARGER SLAIN LOST | 0.5 | -7.9 | 64.3 | 4.2 | 0.6 | -13.2 | 18.3 | 22.5 |
| CHARIOT NO STATIC JOB | 0.1 | +0.0 | 11.6 | 0.0 | - | - | - | - |
| CHARIOT WIZARD CAREFUL | 0.1 | -0.8 | 0.0 | 15.0 | 0.2 | -0.5 | 0.0 | 41.1 |
| CHEAP HELPER | 0.0 | +0.0 | 4.5 | 0.0 | 0.1 | +0.0 | 0.0 | 1.4 |
| COMBAT PIVOT | 0.4 | +0.0 | 4.0 | 27.6 | 0.4 | +0.0 | 14.8 | 56.8 |
| CONTINUE AHEAD WEIGHED | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | 1.0 | +154.9 | 12.6 | 35.5 | 0.2 | +45.9 | 11.1 | 11.1 |
| COUNTER-CHARGE COVER | 9.6 | +777.4 | 0.0 | 195.8 | 7.8 | +687.9 | 0.0 | 192.2 |
| DEFENSIVE ARMY | 0.3 | +0.0 | 96.1 | 3.1 | - | - | - | - |
| EDGE GIVE GROUND | 0.1 | +7.9 | 16.4 | 0.0 | 0.2 | +3.1 | 19.4 | 0.0 |
| ELIXIR WORTH | - | - | - | - | 0.1 | +2.3 | 0.0 | 9.7 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 2.3 | +172.5 | 0.0 | 78.6 | 1.3 | +89.5 | 0.0 | 72.0 |
| FALLBACK BY WORTH | 4.6 | +46.7 | 0.0 | 50.5 | 6.4 | +82.1 | 0.0 | 96.1 |
| FIGHT LIFT | 0.2 | +2.7 | 22.2 | 9.3 | - | - | - | - |
| FIRE AND FLEE | 0.0 | +0.1 | 0.0 | 0.0 | 0.1 | +0.7 | 0.0 | 5.9 |
| FLANK NOT WEIGHED | 5.5 | +0.0 | 0.0 | 115.9 | 6.2 | +0.0 | 0.0 | 151.0 |
| FOLLOW UP WEIGHED | 0.9 | +147.8 | 0.0 | 13.1 | 0.8 | +78.8 | 0.0 | 5.7 |
| FRIENDS SHOTS CHECKED | 0.3 | +14.2 | 0.0 | 7.9 | 0.1 | +15.1 | 0.0 | 0.0 |
| GIVES UP | - | - | - | - | 0.1 | -0.6 | 12.2 | 0.0 |
| GIVES UP ITS SCREEN | 0.0 | -0.1 | 0.0 | 0.0 | - | - | - | - |
| GROUND FLIERS | 0.1 | +1.0 | 0.0 | 0.0 | 0.1 | +1.8 | 0.0 | 3.2 |
| HELPER ALREADY ASKED | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |
| HELPER UNSEEN | 0.3 | +0.0 | 30.1 | 4.9 | 0.6 | +0.0 | 24.0 | 39.1 |
| HILL BY ITS CHANCE | 0.6 | -56.2 | 0.0 | 0.0 | 0.5 | -33.3 | 0.0 | 7.8 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 7.7 | -147.3 | 595.5 | 146.1 | 8.7 | -212.6 | 481.7 | 187.4 |
| HUNT ADVANCE | - | - | - | - | 0.2 | +2.5 | 3.9 | 6.4 |
| HUNT DROPPED | - | - | - | - | 0.1 | +0.0 | 0.0 | 6.2 |
| HUNT IN PAIRS | 0.4 | +10.5 | 0.0 | 5.1 | 0.4 | +27.8 | 0.0 | 4.9 |
| HUNT KEPT | 0.0 | +0.0 | 0.0 | 1.7 | 0.1 | +1.4 | 0.0 | 1.2 |
| HUNT RESULT | 0.0 | +0.0 | 0.0 | 2.9 | 0.2 | +5.3 | 3.5 | 8.8 |
| HUNT THE GUNS | 0.1 | +26.7 | 0.0 | 4.6 | 0.2 | +50.8 | 3.9 | 7.6 |
| INVITES THE FIGHT | 2.1 | +34.0 | 79.6 | 48.4 | 1.3 | +19.5 | 33.2 | 24.0 |
| JOINS A FRIEND | - | - | - | - | 2.7 | +16.7 | 136.2 | 49.2 |
| JOINT CHARGE PLAN | 0.2 | +3.0 | 46.1 | 0.0 | 0.1 | +2.7 | 6.4 | 0.0 |
| JOINT KNOWS CHALLENGE | 0.2 | -2.9 | 38.1 | 0.0 | 0.2 | -20.9 | 17.6 | 7.4 |
| KEEP FALLS | 0.1 | +0.2 | 0.0 | 0.0 | 0.1 | +1.8 | 0.0 | 3.2 |
| KEEPS ITS PREY | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +1.0 | 0.0 | 9.5 |
| KEEPS ITS TARGET | 1.4 | +43.3 | 145.0 | 50.5 | 2.2 | +67.5 | 129.9 | 25.5 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KILLS COUNT | 1.6 | +60.1 | 151.3 | 21.1 | 2.1 | +117.5 | 163.1 | 59.3 |
| KILLS COUNT NEXT TURN | 5.0 | +129.4 | 305.5 | 118.5 | 6.8 | +227.9 | 255.4 | 217.8 |
| LONE CHARACTER SAFE SPOT | 0.3 | +7.5 | 13.9 | 2.4 | 0.2 | +9.8 | 0.0 | 13.9 |
| LONE WIZARD HOLDS BACK | 0.0 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 1.8 | 5.3 |
| LONE WIZARD KEPT IN | 0.6 | +26.9 | 0.0 | 0.0 | 0.2 | +20.3 | 0.0 | 0.0 |
| LONG SHOT | 0.5 | -1.0 | 51.7 | 3.4 | 0.7 | +5.8 | 12.5 | 13.1 |
| LOST CHARGE | 2.8 | -43.5 | 240.9 | 82.9 | 2.0 | -28.1 | 39.2 | 64.9 |
| LURE BY WHAT IT DRAWS | 0.0 | -0.9 | 0.0 | 0.9 | 0.0 | -3.4 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 0.6 | +54.9 | 75.1 | 9.6 | 0.7 | +42.7 | 24.8 | 34.8 |
| MANOEUVRE | 0.4 | +7.6 | 0.0 | 1.9 | 0.1 | +1.3 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | 0.6 | +30.1 | 0.0 | 32.6 | 0.4 | +18.0 | 0.0 | 0.0 |
| MARCH ODDS | 0.3 | +18.9 | 25.4 | 21.4 | 0.2 | +15.3 | 6.8 | 0.0 |
| MARCH OVER CASTS | 0.4 | +25.1 | 0.0 | 5.5 | 0.3 | +35.3 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 4.9 | +174.8 | 0.0 | 110.8 | 5.0 | +180.8 | 0.0 | 119.7 |
| MISSILES IN THE MOVE | 4.1 | +166.4 | 0.0 | 113.6 | 2.4 | +36.7 | 0.0 | 96.1 |
| MISSILES NEXT TURN | 4.8 | +95.7 | 0.0 | 122.6 | 3.1 | +26.1 | 0.0 | 107.2 |
| MODEL FACING | 0.2 | +50.7 | 0.0 | 1.7 | - | - | - | - |
| MONSTER WIZARD ROAMS | 0.2 | +0.0 | 22.6 | 0.0 | 0.2 | +0.0 | 19.1 | 13.9 |
| MOVE AND CAST | 0.5 | +14.8 | 0.0 | 12.9 | 0.2 | +7.7 | 0.0 | 0.0 |
| MOVE SPELL IN RANGE | 0.3 | +6.3 | 0.0 | 2.4 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.7 | -52.0 | 0.0 | 14.9 | 0.2 | -12.9 | 6.7 | 0.0 |
| MOVE SPELL SPOT | 0.8 | +0.0 | 0.0 | 44.6 | 0.1 | +0.0 | 0.0 | 11.1 |
| MOVE TO CHARGE | 2.7 | +150.4 | 218.8 | 75.6 | 3.9 | +358.3 | 139.6 | 107.4 |
| MOVES UNITS SPELL | 0.1 | +3.3 | 0.0 | 0.0 | 0.1 | +0.6 | 0.0 | 0.0 |
| NEEDED THERE | - | - | - | - | 0.1 | +12.9 | 2.8 | 0.0 |
| NO RALLY LEFT | - | - | - | - | 0.0 | +0.7 | 0.0 | 3.0 |
| NOT NEEDED | 0.4 | -15.8 | 43.8 | 5.7 | 0.2 | -11.0 | 31.1 | 7.5 |
| NOT TURNED | 5.2 | +63.2 | 0.0 | 134.4 | 6.6 | +74.4 | 0.0 | 138.2 |
| NOT WORTH A CAST | 0.6 | -0.4 | 0.0 | 0.0 | 0.3 | -0.1 | 0.0 | 0.0 |
| OFF BEST | 15.5 | -729.3 | 12.9 | 277.0 | 14.3 | -822.7 | 20.6 | 317.8 |
| OPENS A LANE | 0.0 | +0.1 | 1.0 | 0.0 | 0.1 | +0.2 | 3.8 | 0.0 |
| OPENS UP | 0.4 | +28.3 | 28.1 | 0.0 | 0.2 | +29.5 | 7.9 | 0.0 |
| OVERRUNS AWAY | 0.7 | +20.4 | 54.0 | 3.4 | 0.4 | +5.2 | 25.1 | 9.5 |
| PATHS CROSS | 2.2 | +138.5 | 0.0 | 27.6 | 2.8 | +201.3 | 0.0 | 35.7 |
| PERIAPT WORTH | 0.1 | +6.8 | 0.0 | 15.0 | 0.1 | +5.1 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.1 | -3.8 | 0.0 | 0.0 | 0.1 | -1.1 | 0.0 | 3.1 |
| PLAN RESULT | 40.3 | +1904.8 | 1726.9 | 844.7 | 38.6 | +1003.9 | 1349.4 | 1208.6 |
| PURSUES BIG PREY | 0.1 | -3.3 | 0.0 | 0.0 | 0.1 | -10.3 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE | - | - | - | - | 0.1 | +13.2 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE NEXT TURN | 0.1 | +9.6 | 0.0 | 0.0 | 0.2 | +21.0 | 0.0 | 7.2 |
| RANDOM MOVE BY FIGURES | 1.2 | +21.5 | 0.0 | 22.6 | 1.8 | +16.3 | 0.0 | 79.2 |
| RANDOM MOVER NO PROMISE | 0.5 | -25.0 | 32.1 | 4.7 | 0.2 | -8.1 | 3.3 | 4.0 |
| REDIRECT BY WHAT IT STOPS | 0.3 | -4.3 | 0.0 | 7.7 | 0.7 | -11.6 | 0.0 | 9.7 |
| REDIRECT COUNTER | 2.4 | +155.4 | 0.0 | 33.7 | 4.4 | +395.5 | 0.0 | 83.9 |
| REDIRECT WEIGHED | 0.2 | +4.9 | 0.0 | 0.0 | 0.5 | +3.1 | 19.1 | 14.9 |
| REFUSING RETIRES | 0.2 | +0.0 | 0.0 | 8.0 | 0.3 | +0.0 | 0.0 | 1.7 |
| RESERVE FALL BACK | 0.5 | +13.8 | 0.0 | 8.8 | 0.8 | +40.8 | 0.0 | 10.7 |
| RESTRAINS TO SHOOT | 0.1 | +9.1 | 0.0 | 13.9 | 0.1 | +0.6 | 0.0 | 3.4 |
| RISK BY ARC | 2.5 | +99.7 | 296.3 | 33.5 | 2.7 | +56.4 | 208.7 | 77.4 |
| SAFE SURE CHARGE | 0.0 | -0.4 | 2.1 | 0.0 | - | - | - | - |
| SAFER THAN THE JOB | 1.2 | +99.3 | 0.0 | 24.3 | 0.6 | +42.6 | 0.0 | 68.4 |
| SCOUT SPOT | 0.4 | +0.5 | 0.0 | 0.9 | 0.1 | +0.0 | 0.0 | 1.8 |
| SCOUT WAITS | 0.5 | +0.0 | 0.0 | 0.9 | 0.1 | +0.0 | 0.0 | 1.8 |
| SCREEN BY WHAT IT SAVES | 0.2 | -14.3 | 0.0 | 0.0 | 0.3 | -18.4 | 0.0 | 2.8 |
| SEARCH SPOT | 2.2 | +87.7 | 0.0 | 60.9 | 2.4 | +121.7 | 0.0 | 40.9 |
| SECOND HUNTER | 0.0 | -0.0 | 0.0 | 1.7 | - | - | - | - |
| SELF MOVE SPELL | 0.2 | +60.5 | 0.0 | 0.0 | 0.5 | +17.5 | 0.0 | 0.0 |
| SET UP TOGETHER | 1.0 | +87.7 | 112.3 | 16.0 | 1.4 | +72.4 | 35.3 | 49.9 |
| SET-UP ANY TARGET | 0.5 | +108.1 | 2.4 | 11.7 | 0.1 | +14.7 | 0.0 | 0.0 |
| SET-UP MISSED | 0.1 | +12.2 | 2.4 | 2.4 | 0.0 | +2.3 | 0.0 | 0.0 |
| SHOOTER COUNTED ONCE | 0.0 | -0.1 | 0.0 | 0.0 | 0.1 | -0.7 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.3 | +0.8 | 0.0 | 0.0 | 0.2 | +0.3 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.1 | +56.3 | 104.1 | 11.0 | 0.7 | +10.3 | 13.9 | 3.6 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| SHOT REPLANNED | 0.7 | +0.0 | 185.9 | 16.2 | 0.2 | +0.0 | 25.3 | 7.4 |
| SHOTS IN THE MOVE | 15.8 | +829.2 | 0.0 | 188.7 | 7.2 | +221.2 | 0.0 | 156.9 |
| SPELL CATCH ODDS | 0.1 | -0.9 | 0.0 | 2.4 | 0.0 | -0.3 | 0.0 | 0.0 |
| SPELL SETS UP CHARGE | 0.6 | +138.9 | 12.6 | 21.9 | 0.1 | +29.3 | 0.0 | 0.0 |
| SPELL WORTH | 1.3 | +24.3 | 129.7 | 118.5 | 2.2 | +40.1 | 67.2 | 67.2 |
| SPELLS IN THE FIGHT | 0.9 | -9.9 | 138.6 | 11.7 | 0.9 | -9.8 | 53.9 | 40.8 |
| STABLE ROLE | 12.0 | +0.0 | 503.8 | 234.8 | 10.8 | +0.0 | 282.8 | 215.8 |
| STANDS TO CAST | - | - | - | - | 0.0 | +0.3 | 0.0 | 0.0 |
| STAY WEIGHED | 0.1 | +6.8 | 0.0 | 0.0 | - | - | - | - |
| STOPS | 0.1 | +0.1 | 0.0 | 4.6 | 0.1 | +3.0 | 0.0 | 1.2 |
| STOPS SHORT OF THE FLANK | 0.5 | +21.9 | 0.0 | 4.0 | 0.5 | +24.5 | 0.0 | 4.0 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 9.9 |
| SUPPORT NARROWED | 6.2 | -61.1 | 322.1 | 83.6 | 7.2 | -50.6 | 326.9 | 131.3 |
| SUPPORTS | 3.9 | +65.9 | 87.8 | 54.0 | 4.8 | +51.9 | 216.4 | 87.2 |
| SURE CHARGE BEATS ADVANCE | 0.1 | -3.7 | 14.2 | 13.9 | 0.1 | -7.7 | 0.0 | 0.0 |
| SURE REACH TOGETHER | 0.3 | +5.7 | 0.0 | 9.6 | 0.4 | -1.3 | 17.2 | 16.8 |
| THROUGH LINE OF FIRE | 0.3 | +5.0 | 0.0 | 18.4 | 0.3 | +11.9 | 0.0 | 3.2 |
| TURN WORTH | 0.4 | -30.1 | 34.6 | 3.9 | 0.1 | -12.2 | 3.1 | 0.0 |
| TWO OR MORE ARRIVE | 0.6 | +2.0 | 97.2 | 6.3 | 0.4 | +2.7 | 12.0 | 1.8 |
| WAIT AFTER COSTS | 6.7 | -299.6 | 387.9 | 154.2 | 6.9 | -392.1 | 258.2 | 166.0 |
| WALKS TO THE FIGHT | 1.4 | +16.0 | 25.4 | 26.7 | 0.6 | +10.5 | 8.9 | 12.2 |
| WAR ENGINE CHARGES | 0.1 | +4.0 | 14.3 | 0.0 | - | - | - | - |
| WAR ENGINE JOBS | 0.7 | +0.0 | 41.3 | 22.9 | 0.1 | +0.0 | 5.8 | 8.1 |
| WEARS DOWN | 1.3 | +50.7 | 167.0 | 34.8 | 1.2 | +46.6 | 69.5 | 17.7 |
| WHO HITS BACK | 0.3 | +22.9 | 0.0 | 12.2 | 0.1 | +6.5 | 0.0 | 4.7 |
| WHOLE FIGHT | 0.4 | +13.5 | 65.7 | 0.0 | 0.3 | +7.0 | 20.4 | 4.1 |
| WHOLE FIGHT GAIN | 0.4 | +31.6 | 58.5 | 4.6 | 0.6 | +30.3 | 33.6 | 4.3 |
| WIDER SPREAD | 2.9 | -8.9 | 343.9 | 40.1 | 3.2 | -4.5 | 240.4 | 71.1 |

### Rule changes: jb-h2h-opp-b54c226-p4

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 1075 | 1075 | 1075 | 29.86 | -55873 | -52.0 |
| BEST FIRST | 306 | 306 | 306 | 8.50 | +11917 | +38.9 |
| PATHS CROSS | 182 | 182 | 182 | 5.06 | +12232 | +67.2 |
| SEARCH SPOT | 165 | 165 | 161 | 4.47 | +7582 | +47.1 |
| COUNTER-CHARGE COVER | 626 | 332 | 150 | 4.17 | +10684 | +71.2 |
| FACES THE THREAT | 131 | 131 | 131 | 3.64 | +9431 | +72.0 |
| MOVE TO CHARGE | 238 | 238 | 125 | 3.47 | +7496 | +60.0 |
| SUPPORTS | 315 | 315 | 113 | 3.14 | +1306 | +11.6 |
| KILLS COUNT NEXT TURN | 425 | 425 | 111 | 3.08 | +2349 | +21.2 |
| SHOTS IN THE MOVE | 828 | 568 | 85 | 2.36 | +3148 | +37.0 |
| FALLBACK BY WORTH | 396 | 396 | 82 | 2.28 | +4639 | +56.6 |
| SAFER THAN THE JOB | 65 | 65 | 65 | 1.81 | +5106 | +78.5 |
| WAIT AFTER COSTS | 490 | 490 | 62 | 1.72 | +1140 | +18.4 |
| FOLLOW UP WEIGHED | 61 | 61 | 61 | 1.69 | +8158 | +133.7 |
| RANDOM MOVE BY FIGURES | 109 | 109 | 58 | 1.61 | +1363 | +23.5 |
| BEST FACING | 57 | 57 | 57 | 1.58 | +1924 | +33.8 |
| ADVANCE LANE KEPT | 55 | 55 | 55 | 1.53 | +0 | +0.0 |
| ARTILLERY RE-ROLL WEIGHED | 53 | 53 | 53 | 1.47 | +0 | +0.0 |
| REDIRECT COUNTER | 242 | 140 | 51 | 1.42 | +5275 | +103.4 |
| BEST OVERALL | 49 | 49 | 49 | 1.36 | +3580 | +73.1 |
| MAX FOR POSITIONING | 358 | 193 | 49 | 1.36 | +515 | +10.5 |
| BLOCKED WHEEL | 47 | 47 | 47 | 1.31 | +887 | +18.9 |
| CHARGE NOW FIRST | 181 | 181 | 45 | 1.25 | -2018 | -44.8 |
| RESERVE FALL BACK | 45 | 45 | 45 | 1.25 | +1966 | +43.7 |
| CANNON SIGHT KEPT | 42 | 42 | 42 | 1.17 | +0 | +0.0 |
| WALKS TO THE FIGHT | 72 | 72 | 42 | 1.17 | +309 | +7.3 |
| CHARGE NOW WEIGHED | 38 | 38 | 38 | 1.06 | +2431 | +64.0 |
| STOPS SHORT OF THE FLANK | 38 | 38 | 38 | 1.06 | +1672 | +44.0 |
| SET UP TOGETHER | 84 | 72 | 36 | 1.00 | +1721 | +47.8 |
| HOLDS AMBUSHERS | 35 | 35 | 35 | 0.97 | +0 | +0.0 |
| SHOT REPLANNED | 34 | 34 | 34 | 0.94 | +0 | +0.0 |
| KILLS COUNT | 134 | 133 | 33 | 0.92 | +1729 | +52.4 |
| MARCH CHECK | 37 | 36 | 33 | 0.92 | +1707 | +51.7 |
| MISSILES IN THE MOVE | 235 | 155 | 33 | 0.92 | +1337 | +40.5 |
| RISK BY ARC | 186 | 179 | 29 | 0.81 | +1017 | +35.1 |
| COMBAT PIVOT | 28 | 28 | 28 | 0.78 | +0 | +0.0 |
| LONE WIZARD KEPT IN | 28 | 28 | 28 | 0.78 | +1699 | +60.7 |
| MOVE AND CAST | 27 | 27 | 27 | 0.75 | +808 | +29.9 |
| REDIRECT WEIGHED | 27 | 27 | 27 | 0.75 | +830 | +30.7 |
| KEEPS ITS TARGET | 133 | 133 | 26 | 0.72 | +453 | +17.4 |
| HONEST WORTH | 592 | 587 | 25 | 0.69 | +309 | +12.4 |
| CAST JOB | 43 | 43 | 24 | 0.67 | +985 | +41.1 |
| SHOOTS FROM THE BEST SPOT | 64 | 64 | 23 | 0.64 | +711 | +30.9 |
| THROUGH LINE OF FIRE | 22 | 22 | 22 | 0.61 | +609 | +27.7 |
| INVITES THE FIGHT | 124 | 124 | 21 | 0.58 | +229 | +10.9 |
| SCOUT WAITS | 21 | 21 | 21 | 0.58 | +0 | +0.0 |
| CANNON PLANNED TARGET | 228 | 228 | 20 | 0.56 | -141 | -7.1 |
| MARCH ODDS | 20 | 20 | 20 | 0.56 | +130 | +6.5 |
| BIG CHARACTER SAFETY | 19 | 19 | 19 | 0.53 | +40 | +2.1 |
| MAKE SURE TOGETHER | 47 | 37 | 19 | 0.53 | +902 | +47.5 |
| SHOOTERS IN TWO RANKS | 18 | 18 | 18 | 0.50 | +41 | +2.3 |
| CASTER AWAY FROM SCREEN | 17 | 17 | 17 | 0.47 | +0 | +0.0 |
| FRIENDS SHOTS CHECKED | 17 | 17 | 17 | 0.47 | +1054 | +62.0 |
| WHOLE FIGHT GAIN | 38 | 34 | 17 | 0.47 | +634 | +37.3 |
| MANOEUVRE | 17 | 17 | 16 | 0.44 | +319 | +19.9 |
| STUCK PIVOT | 16 | 16 | 16 | 0.44 | +0 | +0.0 |
| WHO HITS BACK | 16 | 16 | 16 | 0.44 | +696 | +43.5 |
| OPENS UP | 24 | 24 | 15 | 0.42 | +772 | +51.5 |
| BLOCKED CHARGE SKIPPED | 14 | 14 | 14 | 0.39 | +0 | +0.0 |
| BEST PREY | 47 | 47 | 13 | 0.36 | +494 | +38.0 |
| CHAFF PASSED | 12 | 12 | 12 | 0.33 | -30 | -2.5 |
| WEARS DOWN | 90 | 85 | 11 | 0.31 | +433 | +39.4 |
| CHARGE BAND | 10 | 10 | 10 | 0.28 | +0 | +0.0 |
| RAIDS THE BAGGAGE NEXT TURN | 12 | 12 | 10 | 0.28 | +459 | +45.9 |
| CASTS FROM BEHIND | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| JOINS A FRIEND | 98 | 98 | 9 | 0.25 | +35 | +3.9 |
| SHORT GUN FORWARD | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| PIVOT GUARDS FLANK | 8 | 8 | 8 | 0.22 | -176 | -22.0 |
| SUPPORT NARROWED | 480 | 480 | 8 | 0.22 | -113 | -14.2 |
| WAR ENGINE JOBS | 29 | 29 | 8 | 0.22 | -106 | -13.2 |
| BEST PRIZE | 7 | 7 | 7 | 0.19 | -468 | -66.8 |
| HUNT IN PAIRS | 28 | 15 | 7 | 0.19 | +271 | +38.7 |
| MODEL FACING | 7 | 7 | 7 | 0.19 | +1827 | +260.9 |
| MOVES UNITS SPELL | 7 | 7 | 7 | 0.19 | +138 | +19.7 |
| OVERRUNS AWAY | 41 | 41 | 7 | 0.19 | +239 | +34.1 |
| SURE CHARGE BEATS ADVANCE | 7 | 7 | 7 | 0.19 | -411 | -58.8 |
| MISSILES NEXT TURN | 287 | 179 | 6 | 0.17 | +54 | +9.1 |
| CASTING BLOCK | 9 | 9 | 5 | 0.14 | +219 | +43.8 |
| PURSUES BIG PREY | 5 | 5 | 5 | 0.14 | -489 | -97.8 |
| REFUSING RETIRES | 17 | 17 | 5 | 0.14 | -1 | -0.2 |
| RESTRAINS TO SHOOT | 5 | 5 | 5 | 0.14 | +352 | +70.4 |
| SURE REACH TOGETHER | 24 | 19 | 5 | 0.14 | +44 | +8.8 |
| BACKUP TARGETS | 71 | 32 | 4 | 0.11 | +4 | +1.1 |
| KEEP FALLS | 4 | 4 | 4 | 0.11 | +380 | +95.0 |
| LOST CHARGE | 171 | 171 | 4 | 0.11 | +39 | +9.6 |
| PERIAPT WORTH | 4 | 4 | 4 | 0.11 | +428 | +107.1 |
| WIDER SPREAD | 220 | 212 | 4 | 0.11 | +8 | +2.1 |
| BOUND ASSAILMENT | 3 | 3 | 3 | 0.08 | +0 | +0.2 |
| CHARGER SLAIN LOST | 40 | 38 | 3 | 0.08 | +63 | +21.0 |
| EDGE GIVE GROUND | 12 | 12 | 3 | 0.08 | +118 | +39.3 |
| FIRE AND FLEE | 3 | 3 | 3 | 0.08 | +29 | +9.6 |
| STAY WEIGHED | 3 | 3 | 3 | 0.08 | +245 | +81.6 |
| WHOLE FIGHT | 25 | 25 | 3 | 0.08 | +178 | +59.4 |
| BLOWS WHERE AIMED | 14 | 13 | 2 | 0.06 | +140 | +70.2 |
| ELIXIR WORTH | 2 | 2 | 2 | 0.06 | +84 | +42.1 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| LONE WIZARD HOLDS BACK | 8 | 8 | 2 | 0.06 | -125 | -62.7 |
| LONG SHOT | 43 | 42 | 2 | 0.06 | +21 | +10.3 |
| NEEDED THERE | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| RAIDS THE BAGGAGE | 2 | 2 | 2 | 0.06 | +364 | +182.0 |
| SPELLS IN THE FIGHT | 63 | 60 | 2 | 0.06 | +22 | +10.8 |
| BOMBING RUN | 1 | 1 | 1 | 0.03 | +18 | +18.3 |
| CARRIES OUT SET-UP | 11 | 11 | 1 | 0.03 | -2 | -1.6 |
| CATCH ODDS | 1 | 1 | 1 | 0.03 | -6 | -6.2 |
| CHARIOT NO STATIC JOB | 4 | 4 | 1 | 0.03 | -71 | -71.1 |
| CONTINUE AHEAD WEIGHED | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| DEFENSIVE ARMY | 12 | 12 | 1 | 0.03 | -3 | -2.8 |
| HILL BY ITS CHANCE | 38 | 38 | 1 | 0.03 | +12 | +12.4 |
| JOINT CHARGE PLAN | 12 | 12 | 1 | 0.03 | +16 | +16.2 |
| NO RALLY LEFT | 1 | 1 | 1 | 0.03 | +22 | +21.9 |
| SAFE SURE CHARGE | 1 | 1 | 1 | 0.03 | -50 | -50.5 |
| STANDS TO CAST | 1 | 1 | 1 | 0.03 | -2 | -2.5 |
| STOPS | 6 | 6 | 1 | 0.03 | +2 | +1.9 |
| WAR ENGINE CHARGES | 2 | 2 | 1 | 0.03 | +28 | +27.7 |
| ALREADY CARRIED | 1 | not checked | - | - | - | - |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 29 | 29 | 0 | 0.00 | - | - |
| CARRIES OUT COUNTER | 2 | 2 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 51 | trace | - | - | - | - |
| CATCH FLIERS | 2 | not checked | - | - | - | - |
| CHARIOT WIZARD CAREFUL | 12 | 12 | 0 | 0.00 | - | - |
| CHEAP HELPER | 3 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 46 | not checked | - | - | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT LIFT | 6 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 422 | not checked | - | - | - | - |
| GIVES UP | 3 | 3 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 1 | 1 | 0 | 0.00 | - | - |
| GROUND FLIERS | 4 | not checked | - | - | - | - |
| HELPER ALREADY ASKED | 1 | not checked | - | - | - | - |
| HELPER UNSEEN | 34 | 30 | 0 | 0.00 | - | - |
| HUNT ADVANCE | 6 | 6 | 0 | 0.00 | - | - |
| HUNT DROPPED | 4 | trace | - | - | - | - |
| HUNT KEPT | 5 | trace | - | - | - | - |
| HUNT RESULT | 8 | trace | - | - | - | - |
| HUNT THE GUNS | 9 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 16 | 10 | 0 | 0.00 | - | - |
| KEEPS ITS PREY | 4 | 4 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 17 | not checked | - | - | - | - |
| LURE BY WHAT IT DRAWS | 2 | 2 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 4 | trace | - | - | - | - |
| MARCH OVER CASTS | 25 | 25 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 15 | 15 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 10 | 4 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 32 | trace | - | - | - | - |
| MOVE SPELL SPOT | 31 | not checked | - | - | - | - |
| NOT NEEDED | 25 | 25 | 0 | 0.00 | - | - |
| NOT TURNED | 423 | 423 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 34 | not checked | - | - | - | - |
| OPENS A LANE | 3 | not checked | - | - | - | - |
| PLAN RESULT | 2839 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 26 | 26 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 37 | 37 | 0 | 0.00 | - | - |
| SCOUT SPOT | 19 | 19 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 20 | 20 | 0 | 0.00 | - | - |
| SECOND HUNTER | 1 | 1 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 24 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 22 | not checked | - | - | - | - |
| SET-UP MISSED | 4 | trace | - | - | - | - |
| SHOOTER COUNTED ONCE | 3 | 3 | 0 | 0.00 | - | - |
| SPELL CATCH ODDS | 3 | not checked | - | - | - | - |
| SPELL SETS UP CHARGE | 25 | not checked | - | - | - | - |
| SPELL WORTH | 126 | not checked | - | - | - | - |
| STABLE ROLE | 821 | 819 | 0 | 0.00 | - | - |
| TURN WORTH | 19 | 19 | 0 | 0.00 | - | - |
| TWO OR MORE ARRIVE | 35 | 32 | 0 | 0.00 | - | - |

### Off best figure: jb-h2h-opp-b54c226-p4

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 14.00 | 12.39 | 53.3 |
| FALLBACK | gate | 0.53 | 0.86 | 58.6 |
| CHARGE NOW FIRST | rule | 0.56 | 0.64 | 46.9 |
| TURN GATE | gate | 0.44 | 0.64 | 28.2 |
| PATHS CROSS | rule | 0.17 | 0.19 | 31.2 |
| AFTERMATH BAND | gate | 0.28 | 0.06 | 2.1 |
| SUPPORT REQUEST | gate | 0.06 | 0.19 | 60.7 |
| BIG CHARACTER SAFETY | rule | 0.11 | 0.11 | 6.9 |
| PIVOT GUARDS FLANK | rule | 0.08 | 0.14 | 22.0 |
| WAR ENGINE JOBS | rule | 0.22 | - | 13.2 |
| BEST PRIZE | rule | 0.08 | 0.11 | 66.8 |
| CANNON PLANNED TARGET | rule | 0.19 | - | 29.9 |
| SUPPORT NARROWED | rule | 0.06 | 0.14 | 16.2 |
| SURE CHARGE BEATS ADVANCE | rule | 0.11 | 0.08 | 58.8 |
| LONE CHARACTER SAFE SPOT | gate | 0.08 | 0.08 | 38.7 |
| STOPS SHORT OF THE FLANK | rule | 0.08 | 0.08 | 8.8 |
| CHAFF PASSED | rule | 0.06 | 0.08 | 5.9 |
| PURSUES BIG PREY | rule | 0.08 | 0.06 | 97.8 |
| BLOCKED WHEEL | rule | 0.03 | 0.08 | 38.8 |
| REDIRECT WEIGHED | rule | 0.03 | 0.08 | 47.5 |
| RULE SWITCHED OFF | gate | 0.11 | - | 35.9 |
| CHARGE NOW WEIGHED | rule | 0.06 | 0.03 | 63.6 |
| THROUGH LINE OF FIRE | rule | 0.06 | 0.03 | 7.8 |
| FIGHT ORDER BAND | gate | 0.03 | 0.03 | 1.5 |
| LONE WIZARD HOLDS BACK | rule | - | 0.06 | 62.7 |
| MARCH ODDS | rule | - | 0.06 | 82.8 |
| NO REASON | gate | - | 0.06 | 11.5 |
| SAFER THAN THE JOB | rule | 0.03 | 0.03 | 1.1 |
| AFTERMATH NEEDS NEXT CHARGE | gate | - | 0.03 | 193.2 |
| CARRIES OUT SET-UP | rule | 0.03 | - | 1.6 |
| CATCH ODDS | rule | 0.03 | - | 6.2 |
| CHARIOT NO STATIC JOB | rule | 0.03 | - | 71.1 |
| DEFENSIVE ARMY | rule | 0.03 | - | 2.8 |
| FALLBACK BY WORTH | rule | 0.03 | - | 20.4 |
| FRIENDS SHOTS CHECKED | rule | 0.03 | - | 2.4 |
| SAFE SURE CHARGE | rule | 0.03 | - | 50.5 |
| STANDS TO CAST | rule | - | 0.03 | 2.5 |

### Plans: jb-h2h-opp-b54c226-p4

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 12.5 | 15% | 389 | 345 | 89% |
| Mine | charge | 3.4 | 67% | 230 | 384 | 167% |
| Mine | close in | 4.2 | 28% | 222 | 186 | 84% |
| Mine | hold | 4.9 | 29% | 300 | 0 | 0% |
| Mine | join | 0.7 | 100% | 12 | 0 | 0% |
| Mine | shoot | 10.3 | 64% | 535 | 989 | 185% |
| Mine | support | 4.3 | 92% | 46 | 0 | 0% |
| Opponent | advance | 13.3 | 11% | 333 | 281 | 84% |
| Opponent | charge | 4.4 | 45% | 325 | 366 | 112% |
| Opponent | close in | 6.4 | 21% | 409 | 184 | 45% |
| Opponent | hold | 4.5 | 28% | 324 | 0 | 0% |
| Opponent | join | 0.6 | 90% | 24 | 0 | 0% |
| Opponent | shoot | 3.8 | 59% | 69 | 179 | 258% |
| Opponent | support | 5.6 | 88% | 44 | 0 | 0% |

### Packages: hunt the guns, jb-h2h-opp-b54c226-p4

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.1 | 2 | 1 | 0% | 0% | 0% | - | 481 | 0 | 0% | 13 |
| Opponent | 0.2 | 7 | 0 | 14% | 14% | 0% | 2.0 | 261 | 27 | 14% | 120 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Dwarfen Mountain Holds | 0.7 | 2 | 1 | 0% | 0% | 0% | - | 481 | 0 | 0% | 152 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 67 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| High Elf Realms | 0.3 | 3 | 0 | 0% | 33% | 0% | 2.0 | 179 | 64 | 33% | 98 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 283 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 225 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 136 |
| Tomb Kings of Khemri | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Vampire Counts | 0.5 | 4 | 0 | 25% | 0% | 0% | - | 323 | 0 | 0% | 11 |
| Warriors of Chaos | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 55 |
| Wood Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 17 |

### Battle groups: jb-h2h-opp-b54c226-p4

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 9.6 | 22% | 47% | 12% | 33% | 23% | 9% | 7% | 61% | 0% |
| Mine | REDIRECT COUNTER | 2.4 | 33% | 57% | 11% | 67% | 28% | 4% | 4% | 64% | 0% |
| Opponent | COUNTER-CHARGE COVER | 7.8 | 15% | 76% | 27% | 18% | 40% | 10% | 13% | 37% | 0% |
| Opponent | REDIRECT COUNTER | 4.4 | 28% | 75% | 11% | 20% | 26% | 0% | 10% | 59% | 5% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: jb-h2h-opp-b54c226-p4

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 4 | 0 (4) | 0 | 0 | 79 | 0% | 2.5 | - | 0 (4) | - | 0 (1) | 0 (3) |
| Mine | Chaff | 34 | 10 (34) | 4 | 5 | 68 | 26% | 2.7 | 9 (14) | 0 (7) | 15 (13) | 9 (22) | 10 (12) |
| Mine | Character | 106 | 60 (106) | 60 | 0 | 29 | 16% | 2.2 | 43 (29) | 74 (57) | 111 (6) | 48 (46) | 81 (46) |
| Mine | Clean-up | 22 | 72 (22) | 39 | 33 | 25 | 27% | 3.2 | 0 (2) | 61 (16) | 138 (4) | 71 (10) | 72 (12) |
| Mine | Early | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Mine | Fast | 4 | 0 (4) | 0 | 0 | 73 | 25% | 3.0 | 0 (2) | 0 (2) | - | 0 (3) | 0 (1) |
| Mine | Fast Hammer | 41 | 56 (41) | 26 | 30 | 40 | 15% | 2.7 | 41 (27) | 119 (9) | 22 (5) | 77 (25) | 25 (16) |
| Mine | Fragile | 4 | 0 (4) | 0 | 0 | 73 | 25% | 3.0 | 0 (1) | 0 (2) | - | 0 (1) | 0 (2) |
| Mine | Hammer | 65 | 39 (65) | 24 | 15 | 40 | 17% | 2.5 | 52 (13) | 38 (45) | 22 (7) | 49 (40) | 28 (25) |
| Mine | Holder | 31 | 96 (31) | 17 | 79 | 11 | 29% | 3.3 | 74 (8) | 143 (17) | 0 (6) | 124 (20) | 60 (11) |
| Mine | Shooter | 34 | 65 (34) | 38 | 27 | 33 | 0% | 1.7 | 15 (8) | 94 (21) | 24 (5) | 58 (25) | 85 (9) |
| Mine | Support | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Mine | War machine | 56 | 63 (56) | 63 | 0 | 31 | 2% | 1.3 | 56 (16) | 82 (30) | 17 (10) | 85 (9) | 59 (47) |
| Mine | Wizard | 17 | 13 (17) | 13 | 0 | 50 | 0% | 2.2 | 0 (5) | 25 (7) | 0 (1) | 0 (7) | 29 (6) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 100 | 0% | 5.0 | - | 0 (1) | - | - | 0 (1) |
| Opponent | Chaff | 75 | 25 (75) | 5 | 20 | 57 | 44% | 2.6 | 39 (31) | 28 (17) | 8 (27) | 26 (56) | 22 (19) |
| Opponent | Character | 97 | 46 (97) | 46 | 0 | 36 | 25% | 2.3 | 60 (45) | 38 (39) | 19 (7) | 49 (52) | 45 (39) |
| Opponent | Clean-up | 11 | 61 (11) | 0 | 61 | 34 | 55% | 2.0 | 0 (3) | 79 (6) | 42 (2) | 14 (6) | 88 (5) |
| Opponent | Fast | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Fast Hammer | 60 | 55 (60) | 37 | 17 | 44 | 25% | 2.8 | 43 (26) | 59 (25) | 91 (9) | 42 (39) | 76 (21) |
| Opponent | Fragile | 17 | 27 (17) | 27 | 0 | 54 | 12% | 2.4 | 82 (5) | 0 (8) | 25 (4) | 8 (14) | 113 (3) |
| Opponent | Hammer | 65 | 30 (65) | 16 | 14 | 53 | 23% | 3.5 | 10 (20) | 39 (38) | 10 (7) | 32 (41) | 27 (24) |
| Opponent | Holder | 29 | 23 (29) | 0 | 23 | 37 | 45% | 3.9 | 4 (14) | 39 (11) | 29 (4) | 36 (15) | 9 (14) |
| Opponent | Shooter | 33 | 53 (33) | 16 | 37 | 40 | 3% | 1.3 | 41 (9) | 57 (21) | 64 (3) | 28 (18) | 81 (15) |
| Opponent | Support | 6 | 0 (6) | 0 | 0 | 67 | 83% | 6.0 | 0 (1) | 0 (2) | - | 0 (1) | 0 (2) |
| Opponent | War machine | 6 | 69 (6) | 69 | 0 | 42 | 0% | 1.2 | 91 (3) | 39 (3) | - | 91 (3) | 39 (3) |
| Opponent | Wizard | 19 | 14 (19) | 14 | 0 | 43 | 5% | 2.3 | 9 (10) | 35 (3) | 17 (3) | 19 (12) | 0 (4) |

### Charged fights: jb-h2h-opp-b54c226-p4

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 262 | 334 | 2.2 | 1.3 | 149 | 49 | +100 | 1 of 9 | 9 of 9 | +91 | +104 |
| Mine | Chaos Dwarfs | 4 | 29 | 404 | 2.8 | 1.2 | 147 | 0 | +147 | 5 of 11 | 10 of 11 | +344 | +103 |
| Mine | Dwarfen Mountain Holds | 3 | 513 | 74 | 1.0 | 2.0 | 74 | 0 | +74 | 1 of 3 | 2 of 3 | +80 | +60 |
| Mine | Empire of Man | 5 | 480 | 375 | 2.2 | 1.3 | 170 | 86 | +84 | 7 of 11 | 7 of 11 | +248 | +48 |
| Mine | Grand Cathay | 4 | 870 | 137 | 2.5 | 1.1 | 55 | 20 | +34 | 3 of 10 | 10 of 10 | +242 | +11 |
| Mine | High Elf Realms | 4 | 367 | 112 | 3.2 | 1.1 | 34 | 0 | +34 | 4 of 13 | 9 of 13 | +60 | +32 |
| Mine | Kingdom of Bretonnia | 1 | 210 | 1176 | 7.0 | 1.1 | 168 | 0 | +168 | 3 of 7 | 7 of 7 | +92 | +181 |
| Mine | Lizardmen | 1 | 115 | 996 | 6.0 | 1.0 | 166 | 114 | +52 | 4 of 6 | 4 of 6 | - | +52 |
| Mine | Ogre Kingdoms | 2 | 55 | 128 | 3.0 | 1.0 | 42 | 59 | -16 | 3 of 6 | 3 of 6 | - | -16 |
| Mine | Skaven | 2 | 32 | 33 | 1.5 | 1.0 | 22 | 0 | +22 | 0 of 3 | 3 of 3 | - | +22 |
| Mine | Tomb Kings of Khemri | 2 | 0 | 1004 | 4.0 | 1.4 | 251 | 0 | +251 | 2 of 8 | 8 of 8 | +295 | +224 |
| Mine | Vampire Counts | 2 | 162 | 533 | 6.5 | 1.1 | 82 | 3 | +79 | 2 of 13 | 11 of 13 | +54 | +81 |
| Mine | Warriors of Chaos | 2 | 0 | 126 | 5.5 | 1.0 | 23 | 0 | +23 | 1 of 11 | 6 of 11 | - | +23 |
| **Mine** | all armies | 36 | 302 | 329 | 3.1 | 1.2 | 107 | 24 | +83 | 36 of 111 | 89 of 111 | +184 | +66 |
| Opponent | Empire of Man | 1 | 575 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | High Elf Realms | 5 | 56 | 313 | 3.4 | 1.2 | 92 | 43 | +50 | 9 of 17 | 9 of 17 | +40 | +52 |
| Opponent | Lizardmen | 2 | 81 | 786 | 4.0 | 1.1 | 196 | 23 | +173 | 5 of 8 | 6 of 8 | -185 | +225 |
| Opponent | Orc & Goblin Tribes | 3 | 0 | 386 | 3.3 | 1.0 | 116 | 0 | +116 | 3 of 10 | 8 of 10 | - | +116 |
| Opponent | Skaven | 4 | 52 | 16 | 2.0 | 1.0 | 8 | 74 | -66 | 3 of 8 | 3 of 8 | - | -66 |
| Opponent | Tomb Kings of Khemri | 2 | 128 | 746 | 5.5 | 1.1 | 136 | 36 | +100 | 3 of 11 | 8 of 11 | +572 | +53 |
| Opponent | Vampire Counts | 6 | 78 | 257 | 4.0 | 1.2 | 64 | 24 | +40 | 13 of 24 | 14 of 24 | -28 | +54 |
| Opponent | Warriors of Chaos | 7 | 27 | 443 | 3.1 | 1.1 | 141 | 28 | +113 | 12 of 22 | 14 of 22 | +188 | +106 |
| Opponent | Wood Elf Realms | 6 | 82 | 384 | 3.5 | 1.2 | 110 | 11 | +99 | 8 of 21 | 14 of 21 | +70 | +106 |
| **Opponent** | all armies | 36 | 73 | 356 | 3.4 | 1.1 | 106 | 27 | +78 | 56 of 121 | 76 of 121 | +70 | +80 |

### Effective charges: jb-h2h-opp-b54c226-p4

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 9 | 1 (net -52) | 0 | 2 (net +62) | 3 (net +132) | 0 | 2 (net +167) | 1 | 25% (2 of 8) |
| Mine | Chaos Dwarfs | 11 | 1 (net +615) | 0 | 0 | 2 (net +358) | 1 (net +107) | 3 (net +58) | 4 | 0% (0 of 7) |
| Mine | Dwarfen Mountain Holds | 3 | 1 (net +0) | 0 | 0 | 0 | 0 | 2 (net +110) | 0 | 0% (0 of 3) |
| Mine | Empire of Man | 11 | 3 (net +273) | 0 | 2 (net +186) | 3 (net -130) | 1 (net +122) | 2 (net +0) | 0 | 18% (2 of 11) |
| Mine | Grand Cathay | 10 | 0 | 0 | 2 (net -102) | 4 (net +62) | 1 (net +56) | 3 (net +81) | 0 | 20% (2 of 10) |
| Mine | High Elf Realms | 13 | 1 (net +0) | 0 | 2 (net +0) | 4 (net +46) | 3 (net +62) | 3 (net +25) | 0 | 15% (2 of 13) |
| Mine | Kingdom of Bretonnia | 7 | 0 | 0 | 0 | 2 (net +184) | 3 (net +90) | 2 (net +270) | 0 | 0% (0 of 7) |
| Mine | Lizardmen | 6 | 2 (net -172) | 0 | 0 | 2 (net +200) | 0 | 1 (net +255) | 1 | 0% (0 of 5) |
| Mine | Ogre Kingdoms | 6 | 0 | 0 | 1 (net +0) | 4 (net -16) | 0 | 0 | 1 | 20% (1 of 5) |
| Mine | Skaven | 3 | 0 | 0 | 0 | 0 | 0 | 3 (net +22) | 0 | 0% (0 of 3) |
| Mine | Tomb Kings of Khemri | 8 | 1 (net +783) | 0 | 1 (net +492) | 1 (net +75) | 2 (net +185) | 3 (net +96) | 0 | 12% (1 of 8) |
| Mine | Vampire Counts | 13 | 2 (net +230) | 1 (net +115) | 2 (net +0) | 2 (net +0) | 3 (net +73) | 2 (net +22) | 1 | 17% (2 of 12) |
| Mine | Warriors of Chaos | 11 | 3 (net +0) | 0 | 3 (net +0) | 0 | 1 (net +109) | 0 | 4 | 43% (3 of 7) |
| Opponent | High Elf Realms | 17 | 4 (net -72) | 0 | 2 (net +91) | 3 (net +144) | 1 (net +0) | 4 (net +42) | 3 | 14% (2 of 14) |
| Opponent | Lizardmen | 8 | 2 (net -92) | 0 | 3 (net +221) | 1 (net +330) | 0 | 1 (net +580) | 1 | 43% (3 of 7) |
| Opponent | Orc & Goblin Tribes | 10 | 1 (net +297) | 0 | 0 | 0 | 0 | 1 (net +0) | 8 | 0% (0 of 2) |
| Opponent | Skaven | 8 | 2 (net -18) | 1 (net +0) | 3 (net +0) | 1 (net -560) | 0 | 1 (net +65) | 0 | 38% (3 of 8) |
| Opponent | Tomb Kings of Khemri | 11 | 1 (net -325) | 0 | 3 (net +234) | 3 (net +92) | 0 | 3 (net +107) | 1 | 30% (3 of 10) |
| Opponent | Vampire Counts | 24 | 7 (net +7) | 1 (net +143) | 3 (net +74) | 4 (net +118) | 3 (net +37) | 3 (net -11) | 3 | 14% (3 of 21) |
| Opponent | Warriors of Chaos | 22 | 4 (net +309) | 0 | 2 (net +263) | 6 (net +88) | 2 (net +88) | 5 (net +47) | 3 | 11% (2 of 19) |
| Opponent | Wood Elf Realms | 21 | 1 (net -27) | 1 (net +0) | 7 (net +93) | 5 (net +197) | 2 (net +44) | 5 (net +75) | 0 | 33% (7 of 21) |

### Charged fights, damage counted: jb-h2h-opp-b54c226-p4

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 15 | 174 | 307 | +152 | 267 | 91 | +175 | +100.9 |
| Mine | 50-54% | 1 | 110 | 115 | +115 | 115 | 0 | +115 | +104.5 |
| Mine | Effective (55-75%) | 15 | 278 | 236 | +52 | 75 | 25 | +49 | +17.8 |
| Mine | 76-89% | 27 | 284 | 202 | +72 | 122 | 47 | +75 | +26.3 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 26 | 265 | 176 | +86 | 127 | 30 | +97 | +36.6 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 15 | 488 | 83 | +96 | 96 | 0 | +96 | +19.7 |
| Mine | No odds | 12 | 199 | 115 | +33 | 48 | 7 | +41 | +20.7 |
| Mine | All fights | 111 | 281 | 188 | +83 | 125 | 35 | +90 | +32.0 |
| Opponent | Long shot (under 50%) | 22 | 198 | 316 | +33 | 113 | 66 | +47 | +23.7 |
| Opponent | 50-54% | 3 | 112 | 197 | +48 | 53 | 7 | +46 | +40.8 |
| Opponent | Effective (55-75%) | 23 | 341 | 248 | +128 | 195 | 71 | +124 | +36.4 |
| Opponent | 76-89% | 23 | 333 | 161 | +107 | 156 | 61 | +94 | +28.3 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 23 | 307 | 206 | +74 | 141 | 44 | +97 | +31.5 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 8 | 430 | 77 | +47 | 66 | 34 | +32 | +7.4 |
| Opponent | No odds | 19 | 314 | 161 | +59 | 91 | 24 | +67 | +21.3 |
| Opponent | All fights | 121 | 303 | 210 | +78 | 134 | 52 | +82 | +27.1 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| jb-h2h-opp-b54c226-p4 | move | 398 | 88 (22%) | 56 (14%) | 53 (13%) | 257 (65%) |
| jb-h2h-opp-b54c226-p4 | objective | 388 | 49 (13%) | 33 (9%) | 61 (16%) | 278 (72%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0114, L0130, L2527, L2634 |
| Charmed Shield | Opponent | L0434, L0624, L0926, L1034, L1126, L1427, L2227, L2527, L2634, L3234 |
| Clockwork Compass | Mine | L1220 |
| Elixir of Power | Mine | L1126 |
| Elixir of Power | Opponent | L0819, L1719, L1819 |
| Fistful of Laurels | Mine | L1819, L1835 |
| Invocation of Nehek | Mine | L2527 |
| Invocation of Nehek | Opponent | L0624, L1427, L2227, L2527 |
| Opal Amulet | Mine | L1427 |
| Opal Amulet | Opponent | L0114, L0214, L1314 |
| Periapt of Soul Exchange | Mine | L2021, L2123 |
| Periapt of Soul Exchange | Opponent | L0520, L1220, L1621, L2021 |
| Ring of Doom | Mine | L0214, L0230, L1126, L1220, L1523 |
| Ring of Doom | Opponent | L0315, L1331, L2331 |
| Ring of Jet | Mine | L1017, L1034, L1126, L1220 |
| Standard of the Fell Warrior | Mine | L1314, L1331 |
| Standard of the Fell Warrior | Opponent | L0713 |
| Storm Daemon (Renegade 2.0) | Mine | L2123 |
| Storm Daemon (Renegade 2.0) | Opponent | L1621, L2021 |
| Twice-Blessed Armour | Mine | L0713, L0729, L1017, L1034 |
| Witch Hunter's Ward | Mine | L0713, L0729, L0819, L0835 |
| Witch Hunter's Ward | Opponent | L0608 |

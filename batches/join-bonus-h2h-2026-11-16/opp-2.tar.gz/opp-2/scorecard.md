# Doctrine scorecard: jb-h2h-opp-b54c226-p2

### Scorecard: jb-h2h-opp-b54c226-p2

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0106 | 4 | 1 | Mine | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 387 |
| L0106 | 4 | 1 | Opponent | no | 0 | 4 | 2 | 1 | 1 | 0 | 0 | 981 |
| L0122 | 2 | 1 | Mine | - | - | - | 2 | 1 | 0 | 0 | 0 | 317 |
| L0122 | 2 | 1 | Opponent | - | - | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L0206 | 2 | 1 | Mine | - | - | 2 | 0 | 3 | 1 | 0 | 0 | 0 |
| L0206 | 2 | 1 | Opponent | - | - | 3 | 3 | 0 | 0 | 0 | 0 | 615 |
| L0222 | 6 | 1 | Mine | no | 4 | 2 | 4 | 3 | 1 | 0 | 0 | 251 |
| L0222 | 6 | 1 | Opponent | no | 6 | 2 | 2 | 2 | 0 | 0 | 0 | 55 |
| L0307 | 1 | 1 | Mine | no | 0 | 3 | 0 | 2 | 0 | 0 | 0 | 675 |
| L0307 | 1 | 1 | Opponent | yes | 5 | 2 | 1 | 1 | 1 | 0 | 0 | 420 |
| L0323 | 5 | 1 | Mine | no | - | 2 | 2 | 2 | 0 | 0 | 0 | 590 |
| L0323 | 5 | 1 | Opponent | yes | - | 2 | 0 | 1 | 0 | 0 | 0 | 0 |
| L0409 | 1 | 1 | Mine | no | 2 | 2 | 2 | 3 | 0 | 0 | 0 | 0 |
| L0409 | 1 | 1 | Opponent | no | 7 | - | 0 | 1 | 0 | 0 | 0 | 420 |
| L0425 | 5 | 1 | Mine | yes | - | 2 | 3 | 4 | 0 | 0 | 0 | 0 |
| L0425 | 5 | 1 | Opponent | yes | - | - | 2 | 3 | 0 | 0 | 0 | 0 |
| L0512 | 2 | 1 | Mine | - | - | - | 1 | 1 | 0 | 0 | 0 | 1448 |
| L0512 | 2 | 1 | Opponent | - | - | 2 | 2 | 3 | 1 | 0 | 0 | 330 |
| L0528 | 6 | 1 | Mine | no | 0 | 4 | 1 | 1 | 0 | 0 | 0 | 475 |
| L0528 | 6 | 1 | Opponent | no | 8 | - | 0 | 2 | 0 | 0 | 0 | 0 |
| L0616 | 4 | 1 | Mine | no | 0 | 6 | 3 | 0 | 1 | 0 | 0 | 615 |
| L0616 | 4 | 1 | Opponent | no | 2 | 2 | 3 | 0 | 1 | 0 | 0 | 200 |
| L0632 | 2 | 1 | Mine | - | - | 3 | 3 | 0 | 0 | 0 | 0 | 993 |
| L0632 | 2 | 1 | Opponent | - | - | 2 | 1 | 2 | 1 | 0 | 0 | 170 |
| L0721 | 1 | 1 | Mine | yes | 3 | 2 | 2 | 0 | 1 | 0 | 0 | 420 |
| L0721 | 1 | 1 | Opponent | no | 0 | - | 0 | 5 | 1 | 0 | 0 | 355 |
| L0810 | 6 | 1 | Mine | no | 1 | 4 | 1 | 2 | 0 | 0 | 0 | 560 |
| L0810 | 6 | 1 | Opponent | no | 8 | 2 | 2 | 0 | 0 | 0 | 0 | 330 |
| L0827 | 5 | 1 | Mine | no | - | 3 | 1 | 1 | 0 | 0 | 0 | 807 |
| L0827 | 5 | 1 | Opponent | yes | - | 2 | 2 | 5 | 0 | 0 | 0 | 0 |
| L0918 | 6 | 1 | Mine | no | 4 | 3 | 1 | 1 | 0 | 0 | 0 | 420 |
| L0918 | 6 | 1 | Opponent | no | 11 | 2 | 6 | 1 | 0 | 0 | 0 | 419 |
| L0934 | 4 | 1 | Mine | no | 0 | - | 0 | 0 | 0 | 0 | 0 | 808 |
| L0934 | 4 | 1 | Opponent | yes | 4 | 2 | 6 | 2 | 0 | 0 | 0 | 160 |
| L1026 | 6 | 1 | Mine | no | 0 | 2 | 2 | 1 | 1 | 0 | 0 | 330 |
| L1026 | 6 | 1 | Opponent | no | 1 | 2 | 4 | 3 | 1 | 0 | 0 | 110 |
| L1118 | 2 | 1 | Mine | - | - | 2 | 5 | 1 | 0 | 0 | 0 | 330 |
| L1118 | 2 | 1 | Opponent | - | - | 4 | 5 | 1 | 0 | 0 | 0 | 370 |
| L1135 | 1 | 1 | Mine | yes | 3 | 3 | 1 | 0 | 0 | 0 | 0 | 330 |
| L1135 | 1 | 1 | Opponent | yes | 0 | 3 | 1 | 3 | 2 | 0 | 0 | 0 |
| L1228 | 4 | 1 | Mine | no | 4 | 6 | 1 | 0 | 0 | 0 | 0 | 524 |
| L1228 | 4 | 1 | Opponent | no | 2 | - | 0 | 2 | 0 | 0 | 0 | 111 |
| L1323 | 3 | 1 | Mine | yes | 6 | 2 | 3 | 1 | 1 | 0 | 0 | 317 |
| L1323 | 3 | 1 | Opponent | no | 9 | 1 | 6 | 1 | 0 | 0 | 0 | 0 |
| L1418 | 2 | 1 | Mine | - | - | 2 | 5 | 1 | 0 | 0 | 0 | 0 |
| L1418 | 2 | 1 | Opponent | - | - | - | 3 | 0 | 0 | 0 | 0 | 234 |
| L1435 | 1 | 1 | Mine | no | 0 | 3 | 3 | 1 | 0 | 0 | 0 | 0 |
| L1435 | 1 | 1 | Opponent | no | 0 | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L1531 | 1 | 1 | Mine | no | 3 | 3 | 1 | 0 | 0 | 0 | 0 | 0 |
| L1531 | 1 | 1 | Opponent | no | 1 | 2 | 6 | 1 | 2 | 0 | 0 | 0 |
| L1629 | 3 | 1 | Mine | no | 8 | 1 | 2 | 2 | 0 | 0 | 0 | 200 |
| L1629 | 3 | 1 | Opponent | no | 3 | 2 | 3 | 1 | 0 | 0 | 0 | 170 |
| L1727 | 5 | 1 | Mine | yes | - | 4 | 1 | 0 | 0 | 0 | 0 | 0 |
| L1727 | 5 | 1 | Opponent | yes | - | 2 | 3 | 3 | 0 | 0 | 0 | 0 |
| L1827 | 3 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 297 |
| L1827 | 3 | 1 | Opponent | no | 8 | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| L1927 | 1 | 1 | Mine | no | 2 | 1 | 1 | 1 | 0 | 0 | 0 | 0 |
| L1927 | 1 | 1 | Opponent | no | 0 | 2 | 1 | 2 | 0 | 0 | 0 | 0 |
| L2029 | 1 | 1 | Mine | no | 0 | - | 0 | 0 | 1 | 0 | 0 | 420 |
| L2029 | 1 | 1 | Opponent | no | 0 | 3 | 4 | 1 | 1 | 0 | 0 | 170 |
| L2131 | 1 | 1 | Mine | yes | 6 | - | 2 | 1 | 1 | 0 | 0 | 285 |
| L2131 | 1 | 1 | Opponent | no | 5 | 4 | 1 | 1 | 0 | 0 | 0 | 170 |
| L2235 | 3 | 1 | Mine | no | 2 | 2 | 5 | 1 | 0 | 0 | 0 | 0 |
| L2235 | 3 | 1 | Opponent | no | 0 | 2 | 6 | 0 | 1 | 0 | 0 | 126 |
| L2429 | 5 | 1 | Mine | no | - | 3 | 2 | 2 | 0 | 0 | 0 | 0 |
| L2429 | 5 | 1 | Opponent | yes | - | 3 | 1 | 2 | 0 | 0 | 0 | 0 |
| L2535 | 3 | 1 | Mine | no | 3 | 6 | 3 | 1 | 2 | 0 | 0 | 0 |
| L2535 | 3 | 1 | Opponent | no | 0 | 1 | 5 | 2 | 0 | 0 | 0 | 0 |
| L2735 | 5 | 1 | Mine | yes | - | 3 | 2 | 3 | 0 | 0 | 0 | 0 |
| L2735 | 5 | 1 | Opponent | yes | - | 3 | 3 | 2 | 0 | 0 | 0 | 0 |
| L3033 | 3 | 1 | Mine | yes | 8 | 5 | 1 | 0 | 1 | 0 | 0 | 0 |
| L3033 | 3 | 1 | Opponent | no | 0 | 1 | 5 | 3 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 27% | 2.5 | 3.0 | 1.8 | 1.2 | 0.3 | 0.0 | 0.0 | 327.8 |
| **Average** | | | Opponent | 30% | 3.3 | 2.3 | 2.8 | 1.7 | 0.4 | 0.0 | 0.0 | 164.3 |

### KPIs: jb-h2h-opp-b54c226-p2

Rules off - Mine only: JOINS A FRIEND.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 29% (53 of 183) | 13% (25 of 186) | 21% (78 of 369) |
| Winner chose to follow up after the loser gave ground |  | 99% (73 of 74); on the table 99% | 96% (54 of 56); on the table 98% | 98% (127 of 130); on the table 98% |
| Winner chose to pursue after the loser fell back in good order |  | 100% (5 of 5); on the table 100% | 95% (19 of 20); on the table 95% | 96% (24 of 25); on the table 96% |
| Winner chose to pursue after the loser fled |  | 87% (26 of 30); on the table 87% | 67% (30 of 45); on the table 73% | 75% (56 of 75); on the table 79% |
| Winner chose to follow up or pursue (all three) |  | 95% (104 of 109); on the table 95% | 85% (103 of 121); on the table 88% | 90% (207 of 230); on the table 92% |
| Magic missiles tried each own turn | 50%+ | 31% (105 of 342) | 38% (60 of 156) | 33% (165 of 498) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 48% (105 of 220) | 49% (60 of 123) | 48% (165 of 343) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 50% (12 of 24) | 54% (27 of 50) | 53% (39 of 74) |
| Points that never fought | lower | 38% (27065 of 71583) | 43% (31313 of 71989) | 41% (58378 of 143572) |
|   infantry points that never fought | lower | 46% (7448 of 16324) | 68% (9506 of 14029) | 56% (16954 of 30353) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 60% (170 of 284) | 58% (172 of 297) | 59% (342 of 581) |
| Bound items with a magic missile used (at least once a game) |  | 85% (17 of 20); 1.7 uses a game | 72% (13 of 18); 1.3 uses a game | 79% (30 of 38); 1.5 uses a game |
| Bound items with another spell used |  | 67% (12 of 18); 0.7 uses a game | 50% (1 of 2); 0.0 uses a game | 65% (13 of 20); 0.4 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 55% (11 of 20); 0.3 uses a game | 29% (2 of 7); 0.1 uses a game | 48% (13 of 27); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 58% (34804 of 60231) | 51% (32541 of 63281) | 55% (67345 of 123512) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.8 (27%) | 0.9 (33%) | 2.7 (29%) |
| MARCHED: its unit marched | 1.0 (16%) | 0.5 (18%) | 1.5 (16%) |
| CHARGED: its unit charged | 0.2 (3%) | 0.1 (2%) | 0.3 (3%) |
| IN COMBAT: engaged in combat | 1.4 (21%) | 0.5 (19%) | 1.9 (20%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.2 (6%) | 0.2 (2%) |
| FLEEING: fleeing | 0.0 (0%) | 0.1 (3%) | 0.1 (1%) |
| GONE: slain | 1.4 (22%) | 0.1 (5%) | 1.6 (17%) |
| OFF THE TABLE: off the table or not arrived | 0.6 (9%) | 0.2 (7%) | 0.8 (8%) |
| STUPIDITY: Stupidity | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| NOT OFFERED: not in the cast list | 0.1 (1%) | 0.2 (6%) | 0.2 (3%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.2 | 1.5 | 1.2 | 4.6 | 0.5 | 2.0 |
| not cast | 3.7 | 3.4 | 3.8 | 9.2 | 1.8 | 19.6 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) | 0.9 (4%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (1%) | 1.5 (44%) | 0.2 (7%) | 2.7 (29%) | 0.2 (14%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.5 (16%) | 0.3 (17%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (3%) | 0.1 (5%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.1 (2%) | 0.3 (8%) | 0.6 (15%) | 1.9 (20%) | 0.3 (17%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.2 (7%) | 0.3 (10%) | 0.2 (7%) | 0.2 (2%) | 0.0 (0%) | 0.0 (0%) |
| NO CASTS LEFT: every cast used on other spells | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (2%) | 0.0 (0%) |
| FLEEING: fleeing | 0.1 (3%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.2 (1%) |
| GONE: slain | 0.6 (17%) | 0.6 (17%) | 0.6 (16%) | 1.6 (17%) | 0.4 (20%) | 3.3 (17%) |
| OFF THE TABLE: off the table or not arrived | 0.4 (10%) | 0.2 (6%) | 0.4 (9%) | 0.8 (8%) | 0.3 (15%) | 1.5 (7%) |
| STUPIDITY: Stupidity | 0.1 (3%) | 0.0 (1%) | 0.0 (1%) | 0.1 (1%) | 0.0 (0%) | 0.3 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (1%) | 0.2 (7%) | 0.0 (0%) | 0.0 (0%) | 0.2 (12%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (3%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.1 (57%) | 0.2 (7%) | 1.7 (45%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 13.5 (69%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.6 a game | 0.7 a game | 0.7 a game |
| stood (cast and not dispelled) | 78% (14 of 18) | 65% (17 of 26) | 70% (31 of 44) |
| the unit moved after it | 71% (10 of 14) | 65% (11 of 17) | 68% (21 of 31) |
| it charged on its next turn | 0% (0 of 14) | 24% (4 of 17) | 13% (4 of 31) |
| the enemy charged it first | 7% (1 of 14) | 6% (1 of 17) | 6% (2 of 31) |
| it fought by the end of its next turn | 0% (0 of 14) | 6% (1 of 17) | 3% (1 of 31) |
| it moved out of a charge the enemy had planned (not charged first) | 14% (2 of 14) | 12% (2 of 17) | 13% (4 of 31) |
| none of these (no charge, no fight, no charge escaped) | 79% (11 of 14) | 65% (11 of 17) | 71% (22 of 31) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 65% (557 of 861) | 56% (461 of 827) | 60% (1018 of 1688) |
|   cavalry | 62% (50 of 81) | 62% (104 of 167) | 62% (154 of 248) |
|   character | 47% (51 of 109) | 29% (33 of 114) | 38% (84 of 223) |
|   chariot | 60% (64 of 107) | 68% (25 of 37) | 62% (89 of 144) |
|   infantry | 56% (145 of 257) | 57% (185 of 323) | 57% (330 of 580) |
|   monster | 53% (23 of 43) | 50% (21 of 42) | 52% (44 of 85) |
|   war machine | 85% (224 of 264) | 65% (93 of 144) | 78% (317 of 408) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.3 (27%) | 2.3 (23%) | 4.6 (25%) |
| CHARGED: it charged | 1.1 (12%) | 1.8 (17%) | 2.8 (15%) |
| FLEEING: it fled or was fleeing | 0.1 (2%) | 0.1 (1%) | 0.2 (1%) |
| IN COMBAT: it fought this turn or the last | 0.9 (11%) | 0.7 (7%) | 1.6 (9%) |
| MOVED: a war machine that moved | 0.1 (1%) | 0.0 (0%) | 0.1 (0%) |
| NO TARGET IN RANGE | 1.1 (13%) | 2.0 (19%) | 3.1 (17%) |
| ONLY IN COMBAT: the only targets were in combat | 0.8 (9%) | 0.5 (5%) | 1.3 (7%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.5 (18%) | 1.7 (17%) | 3.2 (17%) |
| SHELTERED: the target was sheltered | 0.2 (3%) | 0.4 (4%) | 0.7 (4%) |
| STUPIDITY | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR | 0.3 (4%) | 0.6 (6%) | 0.9 (5%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 6.5 | 1.4 | 84% | 4.3 pts | 28 pts |
| character | 2.7 | 0.8 | 76% | 8.9 pts | 24 pts |
| chariot | 2.5 | 1.8 | 66% | 16.1 pts | 40 pts |
| infantry | 12.9 | 5.5 | 70% | 9.5 pts | 122 pts |
| monster | 1.6 | 0.5 | 75% | 8.0 pts | 13 pts |
| war machine | 8.8 | 6.6 | 62% | 24.9 pts | 220 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.9 | 5.7 | 4.8 |
| Charges that made contact a game | 2.9 | 4.1 | 3.5 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.88 declared, 0.64 contact (25 units) | 0.82 declared, 0.55 contact (11 units) | 0.86 declared, 0.61 contact (36 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.75 declared, 0.62 contact (8 units) | 0.82 declared, 0.64 contact (11 units) | 0.79 declared, 0.63 contact (19 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.45 declared, 0.33 contact (249 units) | 0.65 declared, 0.47 contact (288 units) | 0.55 declared, 0.41 contact (537 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 58% (42 of 73) | 61% (11 of 18) | 58% (7 of 12) | 58% (60 of 103) |
| Character in a unit | 84% (26 of 31) | 53% (8 of 15) | 60% (3 of 5) | 73% (37 of 51) |
| Character on its own | 83% (34 of 41) | 67% (26 of 39) | 33% (20 of 61) | 57% (80 of 141) |
| Chariot | 53% (9 of 17) | 62% (8 of 13) | - | 57% (17 of 30) |
| Infantry | 50% (47 of 94) | 62% (21 of 34) | 33% (1 of 3) | 53% (69 of 131) |
| Monster | 48% (14 of 29) | 67% (6 of 9) | - | 53% (20 of 38) |
| Monstrous | 64% (9 of 14) | 57% (8 of 14) | - | 61% (17 of 28) |
| War Machines | 70% (40 of 57) | 100% (2 of 2) | - | 71% (42 of 59) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 100% (20 of 20); on the table 100% | 31% (32 of 102) | 39% | 73% (16 of 22) | 83% (5 of 6); 3.8 uses a game | 100% (2 of 2); 1.2 uses a game | 83% (5 of 6); 1.2 uses a game |
| Chaos Dwarfs | 4 | 100% (8 of 8); on the table 100% | 39% (14 of 36) | 63% | 75% (24 of 32) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
| Dwarfen Mountain Holds | 6 | 100% (14 of 14); on the table 100% | - | 53% | 65% (35 of 54) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 7 | 94% (16 of 17); on the table 94% | 33% (16 of 48) | 43% | 64% (49 of 76) | 0.0 uses a game | 50% (1 of 2); 0.1 uses a game | 25% (1 of 4); 0.1 uses a game |
| Grand Cathay | 6 | 96% (23 of 24); on the table 96% | 34% (47 of 138) | 46% | 48% (26 of 54) | 71% (10 of 14); 7.3 uses a game | 50% (1 of 2); 0.3 uses a game | 0% (0 of 6); 0.0 uses a game |
| High Elf Realms | 4 | 82% (14 of 17); on the table 82% | 6% (1 of 18) | 22% | 39% (13 of 33) | 100% (3 of 3); 3.0 uses a game | 64% (9 of 14); 4.8 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 2 | 100% (10 of 10); on the table 100% | - | 43% | 42% (5 of 12) | 0.0 uses a game | 0.0 uses a game | 100% (2 of 2); 1.0 uses a game |
| Lizardmen | 1 | 100% (2 of 2); on the table 100% | - | 29% | 43% (3 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 4 | 77% (10 of 13); on the table 85% | 0% (0 of 18) | 39% | 79% (22 of 28) | 100% (4 of 4); 2.8 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 1 | 100% (4 of 4); on the table 100% | 8% (1 of 12) | 3% | 25% (2 of 8) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Skaven | 3 | 100% (11 of 11); on the table 100% | 39% (7 of 18) | 51% | 56% (14 of 25) | 100% (2 of 2); 1.3 uses a game | 0.0 uses a game | 67% (2 of 3); 0.7 uses a game |
| Tomb Kings of Khemri | 5 | 89% (8 of 9); on the table 89% | - | 48% | 20% (5 of 25) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 9 | 86% (30 of 35); on the table 86% | 39% (26 of 66) | 30% | 67% (36 of 54) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 9 | 67% (14 of 21); on the table 81% | 56% (10 of 18) | 35% | 53% (39 of 73) | 100% (2 of 2); 0.9 uses a game | 0.0 uses a game | 100% (1 of 1); 0.1 uses a game |
| Wood Elf Realms | 7 | 92% (23 of 25); on the table 92% | 46% (11 of 24) | 40% | 68% (53 of 78) | 57% (4 of 7); 2.3 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (jb-h2h-opp-b54c226-p2, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 56% (43) | 45% (21) | 52% (64) |
| ...free all their last turn and able to turn (per game) | 0.78 | 0.36 | 1.14 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.28 | 0.14 | 0.42 |
| ...with the charger already in that arc before they moved (per game) | 0.50 | 0.22 | 0.72 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 1.86 | 1.50 | 3.36 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 1.31 | 1.28 | 2.58 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 6.03 | 5.61 | 11.64 |

### Quality by phase: jb-h2h-opp-b54c226-p2

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.8 | 3.3 |
| Strategy | Charge objectives carried out (made contact) | 50% (58 of 117) | 44% (85 of 193) |
| Strategy | Shoot objectives carried out (shot that target) | 42% (148 of 355) | 50% (132 of 266) |
| Strategy | Close-in objectives charged next turn | 8% (11 of 134) | 17% (38 of 223) |
| Strategy | Support requests answered (helper made contact too) | 38% (6 of 16) | 53% (18 of 34) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (3 of 3) | - |
| Strategy | Hexes on a unit its side charged or shot that turn | 64% (9 of 14) | 75% (9 of 12) |
| Strategy | Joined characters whose unit fought | 53% (20 of 38) | 39% (18 of 46) |
| Strategy | Lone characters that fought | 70% (75 of 107) | 66% (51 of 77) |
| Movement | Charges halted short of contact | 0.2 | 0.2 |
| Movement | Idle units | 1.2 | 1.7 |
| Movement | Points that never moved of their own | 327.8 | 164.3 |
| Movement | Fights charged into per game | 2.5 | 3.4 |
| Movement | Charges with odds: long shots (under 50%) | 7 of 75, net -62 | 22 of 104, net +211 |
| Movement | Charges with odds: sweet spot (55-75%) | 13 of 75, net +27 | 16 of 104, net +127 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 11 of 75, net +109 | 5 of 104, net +31 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 22 of 75, net +80 | 32 of 104, net +144 |
| Shooting | Shots by shooting units (incl. breath weapons) | 10.2 | 11.4 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 43% (158 of 366) | 40% (166 of 412) |
| Shooting | Points destroyed by shooting units | 110.2 | 82.7 |
| Shooting | War machine shots | 6.2 | 2.6 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 54% (120 of 224) | 56% (52 of 93) |
| Shooting | Points destroyed by war machines | 58.7 | 48.7 |
| Magic | Magic missiles cast | 1.7 | 1.0 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 44% (27 of 61) | 51% (18 of 35) |
| Magic | Wounds caused by magic missiles | 2.2 | 2.2 |
| Magic | Wounds caused by other spells | 1.4 | 0.4 |
| Magic | Points destroyed by magic (all spells) | 32.2 | 26.8 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.9 / 0.5 / 0.7 / 0.1 | 2.1 / 0.3 / 0.5 / 0.2 |
| Combat | Points destroyed in combat | 214.4 | 402.9 |
| Combat | Points run down | 60.1 | 119.0 |
| Combat | Net points per charged fight, damage counted | +62 | +138 |
| Combat | Net per 100 charger points, damage counted | +22.9 | +51.7 |
| Combat | First round won (charged fights) | 76% | 76% |
| Combat | Net points per charged fight | +47 | +137 |
| Combat | Net points per supported fight / lone fight | +156 / +26 | +195 / +124 |
| Combat | Charged fights on a top-3 enemy unit | 25 of 89 | 48 of 123 |
| Game | Points lost | 875.9 | 551.5 |
| Game | VP from objectives | 521.7 | 701.4 |
| Game | Lone holders (player turns) | 2.5 | 3.3 |

- Mine won / drew / lost: 12 / 7 / 17 of 36 ended games (of 36); mean margin (Mine - Opponent) -467 VP
- The side that went first won 12 of 29 games with a winner
- Points traded per game (both sides' losses): 1427
- Games not ended: 0; findings 0, warnings 1

### Opponent rules: jb-h2h-opp-b54c226-p2

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 0.5 | +0.0 | 0.0 | 0.0 |
| ALREADY CARRIED | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARRIVAL HUNT | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +5.1 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.3 | +0.0 | 0.0 | 42.2 | 0.2 | +0.0 | 0.0 | 3.5 |
| BACKUP TARGETS | 1.4 | +10.7 | 0.0 | 77.4 | 0.8 | +6.8 | 0.0 | 8.9 |
| BEST FACING | 0.7 | +27.3 | 0.0 | 46.0 | 0.7 | +16.4 | 0.0 | 5.7 |
| BEST FIRST | 4.2 | +190.9 | 197.3 | 88.2 | 4.8 | +183.9 | 177.8 | 75.5 |
| BEST OVERALL | 0.9 | +70.2 | 0.0 | 42.7 | 0.7 | +45.0 | 0.0 | 28.6 |
| BEST PREY | 1.1 | +70.6 | 34.2 | 12.6 | 1.0 | +41.6 | 55.9 | 0.0 |
| BEST PRIZE | 0.1 | -4.2 | 0.8 | 3.8 | 0.1 | -7.9 | 6.4 | 13.1 |
| BIG CHARACTER SAFETY | 0.3 | -0.5 | 0.0 | 11.2 | 0.2 | +0.2 | 0.0 | 0.0 |
| BLOCKED CHARGE SKIPPED | 0.2 | +0.0 | 14.8 | 0.0 | 0.1 | +0.0 | 11.3 | 0.0 |
| BLOCKED WHEEL | 0.2 | +6.3 | 0.0 | 0.0 | 0.5 | -0.8 | 0.0 | 0.0 |
| BLOWS WHERE AIMED | 0.1 | -3.0 | 17.6 | 0.0 | 0.3 | -41.8 | 67.0 | 19.0 |
| BOMBING RUN | 0.1 | +1.3 | 0.0 | 0.0 | - | - | - | - |
| BOUND ASSAILMENT | 0.1 | +0.0 | 0.0 | 13.8 | - | - | - | - |
| CANNON PLAN MISSED | 0.8 | +0.0 | 67.8 | 22.1 | 0.5 | +0.0 | 86.8 | 0.0 |
| CANNON PLANNED TARGET | 4.9 | +161.6 | 348.5 | 110.7 | 2.0 | +136.4 | 236.3 | 6.9 |
| CANNON SIGHT KEPT | 1.3 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 13.1 |
| CARRIES OUT SET-UP | 0.1 | -1.0 | 16.5 | 0.0 | 0.3 | -1.3 | 47.1 | 0.0 |
| CAST JOB | 0.6 | +18.5 | 75.4 | 37.0 | 0.3 | +8.8 | 40.1 | 24.8 |
| CASTER AWAY FROM SCREEN | 0.3 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.3 | +23.1 | 12.8 | 15.8 | 0.2 | +9.7 | 9.8 | 0.0 |
| CASTS AFTER FRIENDS | 0.4 | +0.0 | 0.0 | 9.9 | 0.5 | +0.0 | 0.0 | 24.7 |
| CASTS FROM BEHIND | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.0 | +1.3 | 0.0 | 0.0 | - | - | - | - |
| CATCH ODDS | - | - | - | - | 0.1 | +2.8 | 0.0 | 0.0 |
| CHAFF PASSED | 0.3 | -0.3 | 0.0 | 11.1 | 0.3 | -0.6 | 0.0 | 7.3 |
| CHARGE BAND | 0.1 | +0.0 | 17.2 | 2.4 | 0.2 | +0.0 | 6.0 | 0.0 |
| CHARGE NOW FIRST | 2.0 | +0.0 | 166.5 | 67.2 | 2.4 | +0.0 | 310.9 | 64.1 |
| CHARGE NOW WEIGHED | 0.6 | -43.8 | 20.9 | 15.8 | 0.6 | -59.1 | 20.9 | 29.9 |
| CHARGER SLAIN LOST | 0.4 | -13.9 | 49.7 | 17.4 | 0.5 | -9.7 | 56.1 | 10.0 |
| CHARIOT NO STATIC JOB | 0.1 | +0.0 | 0.0 | 4.7 | - | - | - | - |
| CHARIOT WIZARD CAREFUL | 0.1 | -0.1 | 0.0 | 0.0 | - | - | - | - |
| CHEAP HELPER | - | - | - | - | 0.1 | +0.0 | 9.2 | 1.7 |
| COMBAT PIVOT | 0.5 | +0.0 | 35.9 | 42.2 | 0.7 | +0.0 | 37.5 | 5.4 |
| CONTINUE AHEAD WEIGHED | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | 0.4 | +91.6 | 7.6 | 9.9 | 0.5 | +45.3 | 20.2 | 34.1 |
| COUNTER-CHARGE COVER | 11.0 | +972.5 | 0.0 | 289.4 | 7.6 | +794.4 | 0.0 | 114.9 |
| DEFENSIVE ARMY | 0.4 | +0.0 | 27.2 | 3.6 | 0.1 | +0.0 | 0.0 | 0.0 |
| DEFENSIVE FLOOR | 0.0 | +0.1 | 0.0 | 0.0 | - | - | - | - |
| EDGE GIVE GROUND | 0.1 | +2.3 | 3.9 | 6.4 | 0.3 | +8.2 | 49.5 | 0.0 |
| ELIXIR WORTH | 0.0 | +0.4 | 0.0 | 0.0 | - | - | - | - |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 1.9 | +152.8 | 0.0 | 83.9 | 1.5 | +110.8 | 0.0 | 35.7 |
| FALLBACK BY WORTH | 4.4 | +45.5 | 0.0 | 48.3 | 5.4 | +72.7 | 0.0 | 57.2 |
| FIRE AND FLEE | 0.1 | +0.9 | 7.7 | 0.0 | - | - | - | - |
| FLANK NOT WEIGHED | 6.3 | +0.0 | 0.0 | 203.4 | 5.5 | +0.0 | 0.0 | 95.8 |
| FOCUS FIRE | - | - | - | - | 0.0 | +0.4 | 1.5 | 0.0 |
| FOLLOW UP WEIGHED | 0.9 | +90.6 | 0.0 | 61.5 | 0.9 | +105.8 | 0.0 | 25.8 |
| FRIENDS SHOTS CHECKED | 0.4 | +23.2 | 0.0 | 35.1 | 0.4 | +19.9 | 0.0 | 6.3 |
| GIVES UP | 0.0 | -1.5 | 4.4 | 0.0 | 0.1 | -0.8 | 1.5 | 0.0 |
| GIVES UP ITS SCREEN | 0.0 | -0.4 | 3.5 | 0.0 | 0.1 | -1.6 | 14.5 | 0.0 |
| GROUND FLIERS | 0.1 | +0.7 | 0.0 | 0.0 | - | - | - | - |
| HELPER ALREADY ASKED | - | - | - | - | 0.1 | +0.0 | 20.8 | 0.0 |
| HELPER UNSEEN | 0.2 | +0.0 | 20.2 | 12.0 | 0.5 | +0.0 | 50.6 | 8.1 |
| HILL BY ITS CHANCE | 0.6 | -43.5 | 0.0 | 6.5 | 0.6 | -50.0 | 0.0 | 3.8 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 6.9 | -106.1 | 285.7 | 190.6 | 10.5 | -207.9 | 643.6 | 189.3 |
| HORN WORTH | - | - | - | - | 0.0 | +0.1 | 0.0 | 0.0 |
| HUNT ADVANCE | 0.1 | +0.7 | 5.4 | 0.9 | 0.3 | +3.7 | 15.6 | 0.0 |
| HUNT DROPPED | 0.0 | +0.0 | 5.4 | 0.0 | 0.1 | +0.0 | 3.9 | 0.0 |
| HUNT IN PAIRS | 0.6 | +36.5 | 0.0 | 7.9 | 0.5 | +34.4 | 0.0 | 11.4 |
| HUNT KEPT | - | - | - | - | 0.2 | +5.5 | 29.5 | 0.0 |
| HUNT RESULT | 0.2 | +26.2 | 5.4 | 0.9 | 0.3 | +54.2 | 3.9 | 0.0 |
| HUNT THE GUNS | 0.2 | +42.7 | 22.9 | 2.4 | 0.4 | +116.3 | 23.6 | 3.0 |
| INVITES THE FIGHT | 2.1 | +35.7 | 54.4 | 46.3 | 1.5 | +26.8 | 72.9 | 23.3 |
| JOINS A FRIEND | - | - | - | - | 2.1 | +14.3 | 193.9 | 31.9 |
| JOINT CHARGE PLAN | - | - | - | - | 0.1 | +2.5 | 0.0 | 0.0 |
| JOINT KNOWS CHALLENGE | 0.1 | -0.6 | 16.1 | 0.0 | 0.1 | -1.7 | 10.3 | 0.0 |
| KEEP FALLS | 0.0 | +0.6 | 0.0 | 0.0 | - | - | - | - |
| KEEPS ITS PREY | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |
| KEEPS ITS TARGET | 1.4 | +43.3 | 106.0 | 60.0 | 2.0 | +59.2 | 236.6 | 80.8 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| KILLS COUNT | 1.4 | +71.2 | 93.1 | 35.3 | 2.0 | +83.8 | 198.5 | 50.9 |
| KILLS COUNT NEXT TURN | 5.0 | +174.0 | 150.7 | 130.6 | 7.2 | +260.1 | 334.9 | 117.2 |
| LONE CHARACTER SAFE SPOT | 0.3 | +30.9 | 4.9 | 0.0 | 0.3 | +3.4 | 6.5 | 8.1 |
| LONE WIZARD HOLDS BACK | 0.1 | +0.0 | 0.0 | 3.9 | 0.4 | +0.0 | 0.0 | 22.1 |
| LONE WIZARD KEPT IN | 0.6 | +39.4 | 0.0 | 0.0 | 0.3 | +23.5 | 0.0 | 0.0 |
| LONG SHOT | 0.4 | -3.5 | 7.8 | 0.0 | 0.7 | +5.9 | 43.0 | 13.6 |
| LOST CHARGE | 2.8 | -54.5 | 57.4 | 100.6 | 2.6 | -40.2 | 48.6 | 49.5 |
| LURE BY WHAT IT DRAWS | 0.0 | -1.6 | 0.0 | 0.0 | 0.1 | -8.4 | 0.0 | 4.4 |
| MAKE SURE TOGETHER | 0.3 | +21.5 | 10.4 | 8.8 | 0.7 | +32.5 | 3.5 | 0.0 |
| MANOEUVRE | 0.2 | +9.5 | 0.0 | 2.1 | 0.3 | +7.0 | 0.0 | 6.8 |
| MARCH AT ESCAPER | - | - | - | - | 0.0 | +0.6 | 0.0 | 0.0 |
| MARCH CHECK | 0.5 | +11.3 | 0.0 | 10.6 | 0.4 | +18.4 | 0.0 | 7.6 |
| MARCH ODDS | 0.2 | +12.9 | 2.9 | 0.0 | 0.2 | +22.7 | 4.6 | 0.0 |
| MARCH OVER CASTS | 0.3 | +23.3 | 0.0 | 0.0 | 0.2 | +21.6 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 5.8 | +188.4 | 0.0 | 158.2 | 4.6 | +199.2 | 0.0 | 86.1 |
| MISSILES IN THE MOVE | 3.9 | +106.7 | 0.0 | 150.9 | 3.2 | +72.5 | 0.0 | 78.9 |
| MISSILES NEXT TURN | 4.3 | +71.8 | 0.0 | 160.3 | 3.7 | +50.3 | 0.0 | 89.4 |
| MODEL FACING | 0.4 | +77.2 | 0.0 | 1.7 | 0.2 | +59.7 | 0.0 | 3.3 |
| MONSTER WIZARD ROAMS | 0.1 | +0.0 | 0.0 | 6.5 | 0.2 | +0.0 | 30.8 | 0.0 |
| MOVE AND CAST | 0.2 | +9.9 | 0.0 | 2.4 | 0.3 | +10.4 | 0.0 | 4.4 |
| MOVE SPELL IN RANGE | 0.1 | +3.8 | 0.0 | 32.2 | 0.0 | +0.2 | 0.0 | 7.6 |
| MOVE SPELL OUT OF RANGE | 0.3 | -20.7 | 1.8 | 15.1 | 0.3 | -10.7 | 0.0 | 38.1 |
| MOVE SPELL SPOT | 0.2 | +0.0 | 0.0 | 7.6 | 0.1 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE | 2.6 | +171.4 | 84.5 | 116.1 | 5.0 | +309.1 | 174.9 | 98.1 |
| MOVES UNITS SPELL | 0.1 | +3.4 | 0.0 | 0.0 | - | - | - | - |
| NEEDED THERE | 0.0 | +6.7 | 0.0 | 0.0 | 0.0 | +9.8 | 5.5 | 0.0 |
| NOT NEEDED | 0.3 | -21.1 | 41.0 | 1.4 | 0.5 | -23.6 | 79.6 | 3.5 |
| NOT TURNED | 6.0 | +84.4 | 0.0 | 146.2 | 5.6 | +117.1 | 0.0 | 78.6 |
| NOT WORTH A CAST | 0.5 | -0.3 | 0.0 | 9.9 | 0.7 | -0.7 | 0.0 | 0.0 |
| OFF BEST | 16.0 | -724.2 | 11.5 | 353.7 | 16.5 | -931.5 | 11.2 | 291.1 |
| OPENS A LANE | 0.2 | +1.0 | 3.0 | 0.0 | 0.1 | +0.5 | 1.4 | 0.0 |
| OPENS UP | 0.0 | +3.0 | 3.1 | 0.0 | 0.1 | +18.4 | 6.1 | 0.0 |
| OVERRUNS AWAY | 0.4 | +5.0 | 25.2 | 23.3 | 0.3 | +8.9 | 42.4 | 12.1 |
| PATHS CROSS | 1.9 | +139.8 | 0.0 | 60.2 | 3.1 | +222.1 | 0.0 | 44.0 |
| PERIAPT WORTH | 0.0 | +1.5 | 0.0 | 0.0 | 0.0 | +1.4 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.1 | -2.8 | 0.0 | 7.4 | 0.1 | -1.9 | 0.0 | 5.1 |
| PLAN RESULT | 37.0 | +1365.7 | 1453.7 | 1143.6 | 42.1 | +1310.9 | 1637.5 | 739.9 |
| PURSUES BIG PREY | 0.0 | -1.4 | 0.0 | 0.0 | 0.1 | -14.0 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE NEXT TURN | 0.0 | +1.7 | 0.0 | 3.4 | 0.0 | +2.4 | 0.0 | 0.0 |
| RANDOM MOVE BY FIGURES | 0.7 | +18.6 | 0.0 | 29.9 | 1.4 | +25.9 | 0.0 | 35.0 |
| RANDOM MOVER NO PROMISE | 0.1 | -10.3 | 4.0 | 10.6 | 0.2 | -13.7 | 24.3 | 0.0 |
| REDIRECT BY WHAT IT STOPS | 0.1 | -2.4 | 0.0 | 1.7 | 0.3 | +1.9 | 0.0 | 2.6 |
| REDIRECT COUNTER | 2.5 | +168.1 | 0.0 | 34.8 | 3.8 | +301.4 | 0.0 | 59.2 |
| REDIRECT WEIGHED | 0.2 | +2.0 | 0.8 | 0.0 | 0.3 | +1.7 | 22.0 | 15.2 |
| REFUSING RETIRES | 0.2 | +0.0 | 0.0 | 8.8 | 0.2 | +0.0 | 0.0 | 33.9 |
| RESERVE FALL BACK | 0.3 | +7.3 | 0.0 | 2.2 | 1.1 | +28.2 | 0.0 | 20.0 |
| RESTRAINS TO SHOOT | 0.1 | +3.7 | 0.0 | 12.0 | 0.1 | +3.6 | 0.0 | 19.6 |
| RISK BY ARC | 2.2 | +109.9 | 131.4 | 67.2 | 3.0 | +64.0 | 314.7 | 78.4 |
| SAFE SURE CHARGE | 0.0 | -1.7 | 1.1 | 0.0 | - | - | - | - |
| SAFER THAN THE JOB | 1.3 | +79.1 | 0.0 | 9.4 | 1.3 | +85.7 | 0.0 | 76.9 |
| SCOUT SPOT | 0.3 | +0.9 | 0.0 | 0.0 | 0.5 | +2.4 | 0.0 | 0.0 |
| SCOUT WAITS | 0.3 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.2 | -10.6 | 0.0 | 5.8 | 0.3 | -20.1 | 0.0 | 3.8 |
| SEARCH SPOT | 3.1 | +138.7 | 0.0 | 22.3 | 2.8 | +107.8 | 0.0 | 16.1 |
| SECOND HUNTER | 0.0 | -0.2 | 5.4 | 0.0 | 0.1 | -1.5 | 15.0 | 0.0 |
| SELF MOVE SPELL | 0.2 | +17.8 | 0.0 | 9.1 | - | - | - | - |
| SET UP TOGETHER | 0.7 | +32.5 | 10.4 | 13.6 | 2.0 | +135.5 | 55.7 | 22.2 |
| SET-UP ANY TARGET | 0.1 | +5.8 | 0.0 | 0.0 | 0.2 | +26.0 | 4.4 | 7.6 |
| SET-UP MISSED | - | - | - | - | 0.0 | +1.3 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.4 | +0.8 | 0.0 | 0.0 | 0.3 | +0.6 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.1 | +35.1 | 44.3 | 23.4 | 1.1 | +79.0 | 92.6 | 15.1 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| SHOT REPLANNED | 0.7 | +0.0 | 95.7 | 15.4 | 0.7 | +0.0 | 135.9 | 0.0 |
| SHOTS IN THE MOVE | 13.9 | +566.7 | 0.0 | 301.6 | 12.0 | +485.5 | 0.0 | 145.9 |
| SPELL CATCH ODDS | 0.0 | -0.0 | 0.0 | 0.0 | - | - | - | - |
| SPELL SETS UP CHARGE | 0.2 | +60.1 | 0.0 | 0.0 | 0.2 | +26.0 | 4.4 | 7.6 |
| SPELL WORTH | 0.9 | +15.3 | 53.4 | 38.9 | 1.7 | +24.8 | 99.4 | 99.4 |
| SPELLS IN THE FIGHT | 0.6 | +1.6 | 76.4 | 17.6 | 0.6 | -8.9 | 75.4 | 11.4 |
| STABLE ROLE | 11.9 | +0.0 | 463.4 | 175.1 | 12.3 | +0.0 | 455.3 | 165.9 |
| STANDS TO CAST | 0.0 | +0.5 | 0.0 | 0.0 | 0.1 | +4.4 | 0.0 | 5.4 |
| STAY WEIGHED | 0.1 | +1.0 | 0.0 | 0.8 | - | - | - | - |
| STOPS | 0.1 | +0.6 | 17.5 | 1.4 | 0.2 | +12.9 | 24.6 | 3.0 |
| STOPS SHORT OF THE FLANK | 0.5 | +39.9 | 0.0 | 38.4 | 0.4 | +20.4 | 0.0 | 0.0 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 4.7 | 0.2 | +0.0 | 0.0 | 4.0 |
| SUPPORT NARROWED | 5.9 | -50.0 | 398.4 | 113.3 | 7.4 | -59.1 | 393.1 | 62.8 |
| SUPPORTS | 4.2 | +52.3 | 309.4 | 57.1 | 5.1 | +62.2 | 153.3 | 23.9 |
| SURE CHARGE BEATS ADVANCE | 0.1 | -3.3 | 15.6 | 0.0 | 0.1 | -2.3 | 2.9 | 0.0 |
| SURE REACH TOGETHER | 0.5 | +2.5 | 0.0 | 32.9 | 0.8 | +0.2 | 16.8 | 21.7 |
| THROUGH LINE OF FIRE | 0.2 | +19.4 | 0.0 | 10.7 | 0.2 | -3.3 | 0.0 | 0.0 |
| TURN WORTH | 0.3 | -15.8 | 15.8 | 9.4 | 0.2 | -7.8 | 9.4 | 5.8 |
| TWO OR MORE ARRIVE | 0.1 | +0.1 | 0.0 | 0.0 | 0.4 | +2.4 | 6.2 | 4.3 |
| WAIT AFTER COSTS | 6.4 | -302.2 | 192.8 | 170.8 | 8.6 | -417.4 | 316.1 | 154.1 |
| WALKS TO THE FIGHT | 1.1 | +26.9 | 24.5 | 0.0 | 1.2 | +18.6 | 29.6 | 25.4 |
| WAR ENGINE CHARGES | 0.1 | +1.0 | 0.0 | 0.0 | 0.0 | +0.2 | 0.9 | 0.0 |
| WAR ENGINE JOBS | 0.7 | +0.0 | 35.3 | 7.9 | 0.2 | +0.0 | 32.0 | 10.3 |
| WEARS DOWN | 1.1 | +45.8 | 93.5 | 38.6 | 1.9 | +52.8 | 225.7 | 33.6 |
| WHO HITS BACK | 0.2 | +19.6 | 0.0 | 8.6 | 0.2 | +22.4 | 0.0 | 12.0 |
| WHOLE FIGHT | 0.2 | +11.6 | 33.4 | 0.0 | 0.2 | +22.0 | 27.6 | 0.0 |
| WHOLE FIGHT GAIN | 0.4 | +25.5 | 42.8 | 2.9 | 0.9 | +74.9 | 98.6 | 19.0 |
| WIDER SPREAD | 2.2 | -7.1 | 204.7 | 73.9 | 3.5 | -3.6 | 313.8 | 48.9 |

### Rule changes: jb-h2h-opp-b54c226-p2

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 1172 | 1172 | 1172 | 32.56 | -59606 | -50.9 |
| BEST FIRST | 324 | 324 | 324 | 9.00 | +13495 | +41.7 |
| SEARCH SPOT | 212 | 212 | 208 | 5.78 | +8881 | +42.7 |
| COUNTER-CHARGE COVER | 671 | 389 | 182 | 5.06 | +12066 | +66.3 |
| PATHS CROSS | 180 | 180 | 180 | 5.00 | +13030 | +72.4 |
| MOVE TO CHARGE | 274 | 274 | 145 | 4.03 | +5773 | +39.8 |
| KILLS COUNT NEXT TURN | 441 | 441 | 130 | 3.61 | +3985 | +30.7 |
| SUPPORTS | 333 | 333 | 127 | 3.53 | +1467 | +11.6 |
| FACES THE THREAT | 121 | 121 | 121 | 3.36 | +9489 | +78.4 |
| SAFER THAN THE JOB | 93 | 93 | 93 | 2.58 | +5935 | +63.8 |
| SHOTS IN THE MOVE | 931 | 593 | 91 | 2.53 | +2626 | +28.9 |
| FALLBACK BY WORTH | 353 | 353 | 77 | 2.14 | +4256 | +55.3 |
| CANNON SIGHT KEPT | 70 | 70 | 70 | 1.94 | +0 | +0.0 |
| WAIT AFTER COSTS | 541 | 541 | 66 | 1.83 | +1504 | +22.8 |
| FOLLOW UP WEIGHED | 64 | 64 | 64 | 1.78 | +7069 | +110.5 |
| BEST OVERALL | 59 | 59 | 59 | 1.64 | +4146 | +70.3 |
| ARTILLERY RE-ROLL WEIGHED | 54 | 54 | 54 | 1.50 | +0 | +0.0 |
| RESERVE FALL BACK | 51 | 51 | 51 | 1.42 | +1279 | +25.1 |
| SHOT REPLANNED | 50 | 50 | 50 | 1.39 | +0 | +0.0 |
| BEST FACING | 49 | 49 | 49 | 1.36 | +1573 | +32.1 |
| WALKS TO THE FIGHT | 84 | 84 | 49 | 1.36 | +757 | +15.4 |
| MAX FOR POSITIONING | 373 | 206 | 48 | 1.33 | +764 | +15.9 |
| SHOOTS FROM THE BEST SPOT | 79 | 79 | 47 | 1.31 | +2346 | +49.9 |
| CHARGE NOW WEIGHED | 46 | 46 | 46 | 1.28 | +3696 | +80.3 |
| RISK BY ARC | 189 | 183 | 46 | 1.28 | +1226 | +26.7 |
| SET UP TOGETHER | 99 | 83 | 45 | 1.25 | +2582 | +57.4 |
| COMBAT PIVOT | 43 | 43 | 43 | 1.19 | +0 | +0.0 |
| ADVANCE LANE KEPT | 42 | 42 | 42 | 1.17 | +0 | +0.0 |
| REDIRECT COUNTER | 227 | 129 | 42 | 1.17 | +2920 | +69.5 |
| HOLDS AMBUSHERS | 40 | 40 | 40 | 1.11 | +0 | +0.0 |
| RANDOM MOVE BY FIGURES | 74 | 74 | 39 | 1.08 | +1601 | +41.0 |
| MISSILES IN THE MOVE | 258 | 147 | 34 | 0.94 | +984 | +28.9 |
| CANNON PLANNED TARGET | 247 | 247 | 33 | 0.92 | -111 | -3.4 |
| LONE WIZARD KEPT IN | 33 | 33 | 33 | 0.92 | +2266 | +68.7 |
| MARCH CHECK | 35 | 35 | 33 | 0.92 | +1289 | +39.1 |
| STOPS SHORT OF THE FLANK | 33 | 33 | 33 | 0.92 | +2170 | +65.8 |
| KILLS COUNT | 125 | 123 | 32 | 0.89 | +1345 | +42.0 |
| SCOUT WAITS | 32 | 32 | 32 | 0.89 | +0 | +0.0 |
| INVITES THE FIGHT | 131 | 131 | 31 | 0.86 | +474 | +15.3 |
| CHARGE NOW FIRST | 158 | 158 | 30 | 0.83 | -1746 | -58.2 |
| HONEST WORTH | 628 | 624 | 30 | 0.83 | +155 | +5.2 |
| FRIENDS SHOTS CHECKED | 27 | 27 | 27 | 0.75 | +1552 | +57.5 |
| WHOLE FIGHT GAIN | 44 | 42 | 27 | 0.75 | +897 | +33.2 |
| BEST PREY | 73 | 73 | 26 | 0.72 | +1345 | +51.7 |
| KEEPS ITS TARGET | 123 | 123 | 26 | 0.72 | +495 | +19.0 |
| BLOCKED WHEEL | 25 | 25 | 25 | 0.69 | +197 | +7.9 |
| SHOOTERS IN TWO RANKS | 25 | 25 | 25 | 0.69 | +50 | +2.0 |
| MODEL FACING | 22 | 22 | 22 | 0.61 | +4931 | +224.2 |
| CHAFF PASSED | 20 | 20 | 20 | 0.56 | -35 | -1.8 |
| MANOEUVRE | 20 | 20 | 19 | 0.53 | +592 | +31.2 |
| MOVE AND CAST | 19 | 19 | 19 | 0.53 | +732 | +38.5 |
| REDIRECT WEIGHED | 19 | 19 | 19 | 0.53 | +1378 | +72.6 |
| BIG CHARACTER SAFETY | 16 | 16 | 16 | 0.44 | -12 | -0.8 |
| CASTER AWAY FROM SCREEN | 16 | 16 | 16 | 0.44 | +0 | +0.0 |
| CASTING BLOCK | 21 | 21 | 16 | 0.44 | +607 | +37.9 |
| MARCH ODDS | 16 | 16 | 16 | 0.44 | +214 | +13.3 |
| THROUGH LINE OF FIRE | 16 | 16 | 16 | 0.44 | +582 | +36.4 |
| WHO HITS BACK | 16 | 16 | 16 | 0.44 | +1126 | +70.4 |
| CASTS FROM BEHIND | 15 | 15 | 15 | 0.42 | +0 | +0.0 |
| WEARS DOWN | 106 | 104 | 15 | 0.42 | +355 | +23.6 |
| SHORT GUN FORWARD | 14 | 14 | 14 | 0.39 | +0 | +0.0 |
| CAST JOB | 34 | 34 | 13 | 0.36 | +320 | +24.6 |
| CHARGE BAND | 12 | 12 | 12 | 0.33 | +0 | +0.0 |
| MAKE SURE TOGETHER | 36 | 23 | 11 | 0.31 | +639 | +58.1 |
| REFUSING RETIRES | 17 | 17 | 11 | 0.31 | -0 | -0.0 |
| STUCK PIVOT | 11 | 11 | 11 | 0.31 | +0 | +0.0 |
| PIVOT GUARDS FLANK | 10 | 10 | 10 | 0.28 | -170 | -17.0 |
| SURE CHARGE BEATS ADVANCE | 10 | 10 | 10 | 0.28 | -203 | -20.3 |
| BLOCKED CHARGE SKIPPED | 8 | 8 | 8 | 0.22 | +0 | +0.0 |
| RESTRAINS TO SHOOT | 8 | 8 | 8 | 0.22 | +264 | +33.0 |
| SUPPORT NARROWED | 482 | 482 | 8 | 0.22 | -145 | -18.2 |
| WAR ENGINE JOBS | 32 | 32 | 8 | 0.22 | -385 | -48.2 |
| LOST CHARGE | 196 | 195 | 7 | 0.19 | +87 | +12.4 |
| OVERRUNS AWAY | 27 | 27 | 7 | 0.19 | +65 | +9.3 |
| BEST PRIZE | 6 | 6 | 6 | 0.17 | -449 | -74.8 |
| JOINS A FRIEND | 74 | 74 | 6 | 0.17 | +17 | +2.8 |
| MISSILES NEXT TURN | 288 | 157 | 6 | 0.17 | +8 | +1.3 |
| SURE REACH TOGETHER | 46 | 36 | 6 | 0.17 | +56 | +9.3 |
| HUNT IN PAIRS | 39 | 19 | 5 | 0.14 | +484 | +96.9 |
| OPENS UP | 6 | 6 | 5 | 0.14 | +502 | +100.4 |
| PURSUES BIG PREY | 5 | 5 | 5 | 0.14 | -554 | -110.7 |
| SPELLS IN THE FIGHT | 45 | 44 | 5 | 0.14 | +99 | +19.8 |
| STANDS TO CAST | 5 | 5 | 5 | 0.14 | -12 | -2.5 |
| WHOLE FIGHT | 17 | 15 | 5 | 0.14 | +525 | +105.0 |
| WIDER SPREAD | 207 | 200 | 5 | 0.14 | +26 | +5.3 |
| BACKUP TARGETS | 79 | 39 | 4 | 0.11 | +36 | +9.0 |
| BOUND ASSAILMENT | 4 | 4 | 4 | 0.11 | +1 | +0.2 |
| DEFENSIVE ARMY | 18 | 18 | 4 | 0.11 | -178 | -44.4 |
| KEEPS SCOUTS OR AMBUSH | 4 | 4 | 4 | 0.11 | +0 | +0.0 |
| LONG SHOT | 40 | 38 | 4 | 0.11 | +131 | +32.8 |
| MOVES UNITS SPELL | 4 | 4 | 4 | 0.11 | +122 | +30.4 |
| CARRIES OUT SET-UP | 15 | 15 | 3 | 0.08 | -84 | -28.1 |
| CONTINUE AHEAD WEIGHED | 3 | 3 | 3 | 0.08 | +0 | +0.0 |
| LONE WIZARD HOLDS BACK | 18 | 18 | 3 | 0.08 | -59 | -19.6 |
| STOPS | 10 | 10 | 3 | 0.08 | +43 | +14.4 |
| BOMBING RUN | 2 | 2 | 2 | 0.06 | +47 | +23.4 |
| CATCH ODDS | 2 | 2 | 2 | 0.06 | -49 | -24.4 |
| CHARIOT NO STATIC JOB | 3 | 3 | 2 | 0.06 | -188 | -93.9 |
| FIRE AND FLEE | 2 | 2 | 2 | 0.06 | +34 | +16.9 |
| HUNT ADVANCE | 14 | 14 | 2 | 0.06 | +16 | +8.2 |
| NEEDED THERE | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| PERIAPT WORTH | 2 | 2 | 2 | 0.06 | +106 | +53.0 |
| RAIDS THE BAGGAGE NEXT TURN | 2 | 2 | 2 | 0.06 | +101 | +50.5 |
| STAY WEIGHED | 2 | 2 | 2 | 0.06 | +34 | +17.2 |
| BLOWS WHERE AIMED | 17 | 16 | 1 | 0.03 | +57 | +56.9 |
| ELIXIR WORTH | 1 | 1 | 1 | 0.03 | +13 | +13.0 |
| FOCUS FIRE | 1 | 1 | 1 | 0.03 | +14 | +13.7 |
| HILL BY ITS CHANCE | 41 | 41 | 1 | 0.03 | +31 | +30.9 |
| HORN WORTH | 1 | 1 | 1 | 0.03 | +3 | +3.0 |
| JOINT CHARGE PLAN | 4 | 4 | 1 | 0.03 | +67 | +66.7 |
| KEEP FALLS | 1 | 1 | 1 | 0.03 | +22 | +22.0 |
| MOVE SPELL IN RANGE | 4 | 4 | 1 | 0.03 | +1 | +1.1 |
| OPENS A LANE | 11 | 5 | 1 | 0.03 | +15 | +15.3 |
| SAFE SURE CHARGE | 1 | 1 | 1 | 0.03 | -105 | -105.2 |
| TURN WORTH | 16 | 16 | 1 | 0.03 | +18 | +18.0 |
| ALREADY CARRIED | 1 | not checked | - | - | - | - |
| ARRIVAL HUNT | 6 | 6 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 46 | 46 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 33 | trace | - | - | - | - |
| CATCH FLIERS | 1 | not checked | - | - | - | - |
| CHARGER SLAIN LOST | 33 | 31 | 0 | 0.00 | - | - |
| CHARIOT WIZARD CAREFUL | 2 | 2 | 0 | 0.00 | - | - |
| CHEAP HELPER | 5 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 32 | not checked | - | - | - | - |
| DEFENSIVE FLOOR | 1 | 1 | 0 | 0.00 | - | - |
| EDGE GIVE GROUND | 15 | 14 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 423 | not checked | - | - | - | - |
| GIVES UP | 4 | 3 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 4 | 4 | 0 | 0.00 | - | - |
| GROUND FLIERS | 2 | not checked | - | - | - | - |
| HELPER ALREADY ASKED | 4 | not checked | - | - | - | - |
| HELPER UNSEEN | 26 | 24 | 0 | 0.00 | - | - |
| HUNT DROPPED | 6 | trace | - | - | - | - |
| HUNT KEPT | 8 | trace | - | - | - | - |
| HUNT RESULT | 18 | trace | - | - | - | - |
| HUNT THE GUNS | 20 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 5 | 5 | 0 | 0.00 | - | - |
| KEEPS ITS PREY | 1 | 1 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 22 | not checked | - | - | - | - |
| LURE BY WHAT IT DRAWS | 6 | 6 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 19 | 19 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 14 | 14 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 24 | trace | - | - | - | - |
| MOVE SPELL SPOT | 12 | not checked | - | - | - | - |
| NOT NEEDED | 28 | 28 | 0 | 0.00 | - | - |
| NOT TURNED | 419 | 419 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 43 | not checked | - | - | - | - |
| PLAN RESULT | 2847 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 14 | 14 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 17 | 17 | 0 | 0.00 | - | - |
| SCOUT SPOT | 28 | 28 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 17 | 17 | 0 | 0.00 | - | - |
| SECOND HUNTER | 5 | 5 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 8 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 9 | not checked | - | - | - | - |
| SET-UP MISSED | 1 | trace | - | - | - | - |
| SPELL CATCH ODDS | 1 | not checked | - | - | - | - |
| SPELL SETS UP CHARGE | 13 | not checked | - | - | - | - |
| SPELL WORTH | 94 | not checked | - | - | - | - |
| STABLE ROLE | 871 | 870 | 0 | 0.00 | - | - |
| TWO OR MORE ARRIVE | 15 | 15 | 0 | 0.00 | - | - |
| WAR ENGINE CHARGES | 3 | 3 | 0 | 0.00 | - | - |

### Off best figure: jb-h2h-opp-b54c226-p2

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 14.19 | 15.03 | 52.4 |
| TURN GATE | gate | 0.69 | 0.58 | 38.6 |
| FALLBACK | gate | 0.58 | 0.58 | 33.7 |
| CHARGE NOW FIRST | rule | 0.31 | 0.53 | 58.2 |
| CHAFF PASSED | rule | 0.14 | 0.14 | 3.5 |
| PIVOT GUARDS FLANK | rule | 0.14 | 0.14 | 17.0 |
| SURE CHARGE BEATS ADVANCE | rule | 0.14 | 0.14 | 20.3 |
| LONE CHARACTER SAFE SPOT | gate | 0.17 | 0.08 | 30.3 |
| PATHS CROSS | rule | 0.06 | 0.19 | 37.3 |
| SUPPORT NARROWED | rule | 0.06 | 0.17 | 18.2 |
| WAR ENGINE JOBS | rule | 0.22 | - | 48.2 |
| AFTERMATH BAND | gate | 0.11 | 0.08 | 2.5 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.17 | 0.03 | 55.7 |
| BEST PRIZE | rule | 0.11 | 0.06 | 74.8 |
| CANNON PLANNED TARGET | rule | 0.14 | 0.03 | 21.2 |
| CHARGE NOW WEIGHED | rule | 0.08 | 0.08 | 46.8 |
| SUPPORT REQUEST | gate | 0.08 | 0.08 | 107.1 |
| PURSUES BIG PREY | rule | 0.03 | 0.11 | 110.7 |
| BIG CHARACTER SAFETY | rule | 0.11 | - | 10.7 |
| DEFENSIVE ARMY | rule | 0.03 | 0.08 | 44.4 |
| MARCH ODDS | rule | 0.08 | 0.03 | 21.8 |
| STANDS TO CAST | rule | 0.03 | 0.08 | 4.3 |
| CARRIES OUT SET-UP | rule | 0.03 | 0.06 | 28.1 |
| BLOCKED WHEEL | rule | 0.03 | 0.03 | 32.5 |
| CATCH ODDS | rule | - | 0.06 | 24.4 |
| CHARIOT NO STATIC JOB | rule | 0.06 | - | 93.9 |
| SAFER THAN THE JOB | rule | 0.06 | - | 13.5 |
| FACES THE THREAT | rule | 0.03 | - | 9.2 |
| FIGHT ORDER BAND | gate | - | 0.03 | 3.3 |
| LONE WIZARD HOLDS BACK | rule | - | 0.03 | 58.8 |
| NO REASON | gate | - | 0.03 | 0.8 |
| REFUSING RETIRES | rule | 0.03 | - | 0.6 |
| RULE SWITCHED OFF | gate | 0.03 | - | 10.1 |
| SAFE SURE CHARGE | rule | 0.03 | - | 105.2 |
| STOPS SHORT OF THE FLANK | rule | 0.03 | - | 6.6 |
| THROUGH LINE OF FIRE | rule | - | 0.03 | 323.4 |

### Plans: jb-h2h-opp-b54c226-p2

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 12.2 | 16% | 493 | 327 | 66% |
| Mine | charge | 2.7 | 52% | 250 | 232 | 93% |
| Mine | close in | 3.7 | 16% | 194 | 93 | 48% |
| Mine | hold | 4.9 | 31% | 311 | 0 | 0% |
| Mine | join | 0.7 | 96% | 21 | 0 | 0% |
| Mine | shoot | 8.3 | 61% | 289 | 713 | 246% |
| Mine | support | 4.4 | 90% | 29 | 0 | 0% |
| Opponent | advance | 14.4 | 16% | 408 | 310 | 76% |
| Opponent | charge | 4.4 | 56% | 366 | 437 | 119% |
| Opponent | close in | 6.2 | 25% | 367 | 134 | 37% |
| Opponent | hold | 4.6 | 36% | 342 | 0 | 0% |
| Opponent | join | 0.9 | 91% | 40 | 0 | 0% |
| Opponent | shoot | 5.9 | 61% | 203 | 431 | 212% |
| Opponent | support | 5.6 | 95% | 66 | 0 | 0% |

### Packages: hunt the guns, jb-h2h-opp-b54c226-p2

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.2 | 6 | 0 | 33% | 50% | 0% | 2.0 | 256 | 157 | 50% | 51 |
| Opponent | 0.4 | 14 | 2 | 33% | 58% | 0% | 2.4 | 291 | 163 | 58% | 77 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 122 | 0 | 0% | 81 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 222 |
| Dwarfen Mountain Holds | 0.2 | 1 | 0 | 100% | 100% | 0% | 2.0 | 460 | 453 | 100% | 60 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 36 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 22 |
| High Elf Realms | 0.8 | 3 | 0 | 33% | 67% | 0% | 2.0 | 252 | 163 | 67% | 0 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 374 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Ogre Kingdoms | 1.0 | 4 | 1 | 67% | 67% | 0% | 3.0 | 488 | 318 | 67% | 151 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 277 |
| Tomb Kings of Khemri | 1.2 | 6 | 0 | 0% | 33% | 0% | 2.0 | 122 | 32 | 33% | 13 |
| Vampire Counts | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 12 |
| Warriors of Chaos | 0.3 | 3 | 1 | 50% | 50% | 0% | 2.0 | 318 | 74 | 50% | 20 |
| Wood Elf Realms | 0.3 | 2 | 0 | 50% | 100% | 0% | 2.5 | 428 | 328 | 100% | 16 |

### Battle groups: jb-h2h-opp-b54c226-p2

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 11.0 | 20% | 48% | 10% | 50% | 26% | 22% | 8% | 43% | 0% |
| Mine | REDIRECT COUNTER | 2.5 | 26% | 61% | 17% | 25% | 42% | 0% | 16% | 42% | 0% |
| Opponent | COUNTER-CHARGE COVER | 7.6 | 21% | 71% | 16% | 0% | 31% | 6% | 6% | 57% | 0% |
| Opponent | REDIRECT COUNTER | 3.8 | 23% | 72% | 16% | 20% | 52% | 4% | 15% | 26% | 4% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: jb-h2h-opp-b54c226-p2

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 5 | 99 (5) | 99 | 0 | 0 | 20% | 2.8 | 0 (1) | 117 (4) | - | 151 (3) | 0 (2) |
| Mine | Chaff | 34 | 52 (34) | 13 | 40 | 62 | 38% | 2.6 | 55 (19) | 54 (7) | 45 (8) | 58 (23) | 39 (11) |
| Mine | Character | 123 | 32 (123) | 31 | 1 | 47 | 24% | 2.3 | 37 (37) | 38 (50) | 5 (9) | 42 (49) | 29 (47) |
| Mine | Clean-up | 21 | 50 (21) | 16 | 35 | 46 | 52% | 2.7 | 26 (5) | 58 (13) | 79 (3) | 99 (13) | 0 (8) |
| Mine | Fast | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Mine | Fast Hammer | 48 | 57 (48) | 34 | 23 | 46 | 23% | 2.7 | 49 (23) | 86 (16) | 30 (9) | 67 (29) | 43 (19) |
| Mine | Fragile | 5 | 0 (5) | 0 | 0 | 40 | 0% | 1.4 | - | 0 (3) | 0 (2) | 0 (5) | - |
| Mine | Hammer | 57 | 33 (57) | 23 | 10 | 48 | 21% | 2.6 | 22 (18) | 44 (29) | 22 (10) | 33 (38) | 32 (19) |
| Mine | Holder | 28 | 43 (28) | 4 | 39 | 28 | 39% | 3.2 | 42 (11) | 71 (8) | 10 (8) | 55 (18) | 19 (9) |
| Mine | Shooter | 41 | 73 (41) | 25 | 48 | 57 | 0% | 1.6 | 143 (5) | 78 (30) | 7 (6) | 93 (25) | 41 (16) |
| Mine | Support | 2 | 0 (2) | 0 | 0 | 0 | 100% | - | 0 (1) | 0 (1) | - | - | 0 (2) |
| Mine | War machine | 59 | 39 (59) | 39 | 0 | 53 | 2% | 1.2 | 6 (10) | 53 (37) | 14 (12) | 13 (10) | 44 (49) |
| Mine | Wizard | 22 | 8 (22) | 8 | 0 | 54 | 14% | 2.5 | 0 (6) | 37 (6) | 0 (3) | 0 (5) | 18 (10) |
| Opponent | Blocker | 2 | 0 (2) | 0 | 0 | 38 | 0% | 4.0 | - | 0 (2) | - | - | 0 (2) |
| Opponent | Chaff | 76 | 70 (76) | 30 | 40 | 46 | 34% | 2.7 | 65 (32) | 60 (19) | 87 (25) | 96 (54) | 9 (22) |
| Opponent | Character | 97 | 64 (97) | 64 | 0 | 25 | 24% | 2.6 | 76 (42) | 63 (41) | 7 (7) | 54 (62) | 86 (28) |
| Opponent | Clean-up | 19 | 27 (19) | 13 | 14 | 39 | 42% | 2.5 | 9 (9) | 55 (10) | - | 34 (14) | 5 (5) |
| Opponent | Early | 2 | 129 (2) | 129 | 0 | 0 | 0% | 5.5 | - | 129 (2) | - | 0 (1) | 259 (1) |
| Opponent | Fast Hammer | 48 | 44 (48) | 36 | 8 | 32 | 17% | 2.8 | 61 (22) | 3 (16) | 81 (10) | 39 (28) | 52 (20) |
| Opponent | Fragile | 5 | 142 (5) | 142 | 0 | 23 | 20% | 3.0 | - | 71 (3) | 255 (2) | 176 (4) | 0 (1) |
| Opponent | Hammer | 70 | 30 (70) | 26 | 4 | 41 | 29% | 3.0 | 39 (17) | 26 (42) | 43 (11) | 34 (43) | 24 (27) |
| Opponent | Holder | 35 | 101 (35) | 14 | 88 | 19 | 37% | 3.0 | 47 (6) | 101 (25) | 211 (4) | 126 (23) | 47 (12) |
| Opponent | Shooter | 33 | 85 (33) | 14 | 72 | 12 | 0% | 1.8 | 45 (8) | 106 (19) | 65 (6) | 113 (22) | 43 (11) |
| Opponent | Support | 3 | 28 (3) | 28 | 0 | 50 | 67% | 4.0 | 37 (2) | 0 (1) | - | 56 (1) | 0 (2) |
| Opponent | War machine | 24 | 64 (24) | 64 | 0 | 4 | 8% | 1.6 | 44 (6) | 71 (14) | 66 (4) | 14 (3) | 72 (21) |
| Opponent | Wizard | 26 | 34 (26) | 34 | 0 | 27 | 12% | 1.5 | 0 (10) | 105 (8) | 5 (6) | 76 (8) | 10 (16) |

### Charged fights: jb-h2h-opp-b54c226-p2

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 103 | 91 | 2.5 | 1.1 | 36 | 22 | +15 | 1 of 10 | 6 of 10 | +122 | +3 |
| Mine | Chaos Dwarfs | 4 | 69 | 223 | 2.0 | 1.1 | 112 | 0 | +112 | 5 of 8 | 6 of 8 | +398 | +71 |
| Mine | Dwarfen Mountain Holds | 4 | 439 | 170 | 2.2 | 1.3 | 76 | 18 | +57 | 2 of 9 | 5 of 9 | +26 | +73 |
| Mine | Empire of Man | 5 | 413 | 18 | 1.0 | 1.0 | 18 | 106 | -88 | 3 of 5 | 4 of 5 | - | -88 |
| Mine | Grand Cathay | 4 | 263 | 133 | 2.0 | 1.1 | 66 | 0 | +66 | 4 of 8 | 7 of 8 | +432 | +14 |
| Mine | High Elf Realms | 4 | 222 | 441 | 4.0 | 1.2 | 110 | 28 | +83 | 5 of 16 | 14 of 16 | +245 | +45 |
| Mine | Kingdom of Bretonnia | 1 | 0 | 357 | 5.0 | 1.0 | 71 | 94 | -23 | 1 of 5 | 4 of 5 | - | -23 |
| Mine | Lizardmen | 1 | 186 | 120 | 3.0 | 1.0 | 40 | 0 | +40 | 0 of 3 | 2 of 3 | - | +40 |
| Mine | Ogre Kingdoms | 1 | 0 | 278 | 2.0 | 1.0 | 139 | 17 | +122 | 0 of 2 | 1 of 2 | - | +122 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 332 | 4.0 | 1.2 | 83 | 14 | +69 | 1 of 4 | 4 of 4 | +45 | +77 |
| Mine | Skaven | 2 | 156 | 58 | 2.0 | 1.2 | 29 | 46 | -17 | 0 of 4 | 2 of 4 | -145 | +26 |
| Mine | Tomb Kings of Khemri | 1 | 274 | 393 | 4.0 | 1.0 | 98 | 108 | -10 | 2 of 4 | 3 of 4 | - | -10 |
| Mine | Vampire Counts | 3 | 0 | 272 | 3.3 | 1.4 | 82 | 6 | +76 | 1 of 10 | 10 of 10 | +173 | +34 |
| Mine | Warriors of Chaos | 1 | 19 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 0 of 1 | 0 of 1 | - | +0 |
| **Mine** | all armies | 36 | 201 | 187 | 2.5 | 1.2 | 76 | 29 | +47 | 25 of 89 | 68 of 89 | +156 | +26 |
| Opponent | Dwarfen Mountain Holds | 2 | 247 | 178 | 3.5 | 1.1 | 51 | 24 | +27 | 1 of 7 | 5 of 7 | -60 | +42 |
| Opponent | Empire of Man | 2 | 632 | 46 | 1.5 | 1.3 | 30 | 127 | -96 | 1 of 3 | 3 of 3 | +0 | -144 |
| Opponent | Grand Cathay | 2 | 300 | 954 | 2.5 | 2.0 | 382 | 0 | +382 | 4 of 5 | 4 of 5 | +365 | +408 |
| Opponent | Kingdom of Bretonnia | 1 | 175 | 390 | 5.0 | 1.0 | 78 | 0 | +78 | 2 of 5 | 5 of 5 | - | +78 |
| Opponent | Ogre Kingdoms | 3 | 156 | 395 | 6.0 | 1.1 | 66 | 21 | +45 | 7 of 18 | 8 of 18 | +0 | +51 |
| Opponent | Skaven | 1 | 661 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Tomb Kings of Khemri | 4 | 93 | 1021 | 3.8 | 1.3 | 272 | 42 | +231 | 7 of 15 | 10 of 15 | +339 | +191 |
| Opponent | Vampire Counts | 6 | 9 | 752 | 3.5 | 1.2 | 215 | 37 | +177 | 11 of 21 | 16 of 21 | +101 | +201 |
| Opponent | Warriors of Chaos | 8 | 8 | 389 | 2.4 | 1.2 | 164 | 8 | +156 | 5 of 19 | 18 of 19 | +305 | +128 |
| Opponent | Wood Elf Realms | 7 | 220 | 602 | 4.3 | 1.1 | 140 | 15 | +125 | 10 of 30 | 24 of 30 | +170 | +118 |
| **Opponent** | all armies | 36 | 158 | 551 | 3.4 | 1.2 | 161 | 24 | +137 | 48 of 123 | 93 of 123 | +195 | +124 |

### Effective charges: jb-h2h-opp-b54c226-p2

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 10 | 0 | 0 | 1 (net +0) | 5 (net +20) | 0 | 1 (net +72) | 3 | 14% (1 of 7) |
| Mine | Chaos Dwarfs | 8 | 2 (net +0) | 0 | 0 | 3 (net +100) | 0 | 2 (net +296) | 1 | 0% (0 of 7) |
| Mine | Dwarfen Mountain Holds | 9 | 0 | 0 | 0 | 2 (net +68) | 0 | 6 (net +63) | 1 | 0% (0 of 8) |
| Mine | Empire of Man | 5 | 0 | 0 | 2 (net -265) | 0 | 0 | 1 (net +0) | 2 | 67% (2 of 3) |
| Mine | Grand Cathay | 8 | 2 (net +0) | 0 | 1 (net +0) | 0 | 3 (net +177) | 2 (net +0) | 0 | 12% (1 of 8) |
| Mine | High Elf Realms | 16 | 0 | 0 | 3 (net +28) | 3 (net +62) | 3 (net +103) | 5 (net +124) | 2 | 21% (3 of 14) |
| Mine | Kingdom of Bretonnia | 5 | 0 | 0 | 1 (net +205) | 3 (net -116) | 0 | 0 | 1 | 25% (1 of 4) |
| Mine | Lizardmen | 3 | 0 | 0 | 0 | 1 (net +75) | 2 (net +22) | 0 | 0 | 0% (0 of 3) |
| Mine | Ogre Kingdoms | 2 | 0 | 0 | 0 | 1 (net +278) | 0 | 0 | 1 | 0% (0 of 1) |
| Mine | Orc & Goblin Tribes | 4 | 0 | 0 | 2 (net +139) | 0 | 0 | 0 | 2 | 100% (2 of 2) |
| Mine | Skaven | 4 | 1 (net +0) | 0 | 0 | 1 (net +116) | 0 | 2 (net -92) | 0 | 0% (0 of 4) |
| Mine | Tomb Kings of Khemri | 4 | 1 (net -431) | 0 | 0 | 0 | 1 (net +110) | 2 (net +142) | 0 | 0% (0 of 4) |
| Mine | Vampire Counts | 10 | 1 (net +0) | 0 | 2 (net +156) | 3 (net +42) | 2 (net +102) | 1 (net +0) | 1 | 22% (2 of 9) |
| Mine | Warriors of Chaos | 1 | 0 | 0 | 1 (net +0) | 0 | 0 | 0 | 0 | 100% (1 of 1) |
| Opponent | Dwarfen Mountain Holds | 7 | 2 (net +12) | 0 | 3 (net +20) | 1 (net +55) | 1 (net +52) | 0 | 0 | 43% (3 of 7) |
| Opponent | Empire of Man | 3 | 1 (net -380) | 0 | 0 | 0 | 1 (net +0) | 1 (net +91) | 0 | 0% (0 of 3) |
| Opponent | Grand Cathay | 5 | 2 (net +691) | 0 | 1 (net +138) | 1 (net +85) | 0 | 1 (net +304) | 0 | 20% (1 of 5) |
| Opponent | Kingdom of Bretonnia | 5 | 0 | 0 | 1 (net +95) | 1 (net +0) | 0 | 1 (net +115) | 2 | 33% (1 of 3) |
| Opponent | Ogre Kingdoms | 18 | 5 (net +98) | 0 | 1 (net +369) | 2 (net -128) | 0 | 3 (net +69) | 7 | 9% (1 of 11) |
| Opponent | Tomb Kings of Khemri | 15 | 2 (net +338) | 0 | 1 (net +347) | 3 (net +245) | 0 | 7 (net +196) | 2 | 8% (1 of 13) |
| Opponent | Vampire Counts | 21 | 5 (net +265) | 1 (net +297) | 5 (net +192) | 6 (net +81) | 1 (net +0) | 3 (net +219) | 0 | 24% (5 of 21) |
| Opponent | Warriors of Chaos | 19 | 2 (net +98) | 2 (net +282) | 1 (net +0) | 3 (net +152) | 1 (net +0) | 5 (net +188) | 5 | 7% (1 of 14) |
| Opponent | Wood Elf Realms | 30 | 3 (net +308) | 1 (net +268) | 3 (net +20) | 8 (net +184) | 1 (net +104) | 11 (net +84) | 3 | 11% (3 of 27) |

### Charged fights, damage counted: jb-h2h-opp-b54c226-p2

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 7 | 253 | 279 | -62 | 101 | 124 | -23 | -9.1 |
| Mine | Effective (55-75%) | 13 | 379 | 226 | +27 | 136 | 82 | +54 | +14.2 |
| Mine | 76-89% | 22 | 197 | 140 | +44 | 84 | 38 | +46 | +23.4 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 22 | 258 | 191 | +80 | 133 | 20 | +113 | +43.9 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 11 | 436 | 94 | +109 | 114 | 11 | +103 | +23.5 |
| Mine | No odds | 14 | 196 | 96 | +22 | 46 | 19 | +27 | +13.8 |
| Mine | All fights | 89 | 273 | 163 | +47 | 103 | 40 | +62 | +22.9 |
| Opponent | Long shot (under 50%) | 22 | 236 | 242 | +211 | 314 | 96 | +217 | +92.1 |
| Opponent | 50-54% | 4 | 518 | 274 | +282 | 282 | 14 | +268 | +51.8 |
| Opponent | Effective (55-75%) | 16 | 229 | 185 | +127 | 153 | 20 | +133 | +58.0 |
| Opponent | 76-89% | 25 | 278 | 193 | +121 | 179 | 71 | +108 | +38.9 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 32 | 294 | 187 | +144 | 179 | 35 | +144 | +49.0 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 5 | 425 | 88 | +31 | 31 | 18 | +13 | +3.1 |
| Opponent | No odds | 19 | 174 | 210 | +69 | 95 | 14 | +81 | +46.7 |
| Opponent | All fights | 123 | 266 | 200 | +137 | 184 | 47 | +138 | +51.7 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| jb-h2h-opp-b54c226-p2 | move | 448 | 90 (20%) | 65 (15%) | 46 (10%) | 312 (70%) |
| jb-h2h-opp-b54c226-p2 | objective | 357 | 49 (14%) | 35 (10%) | 39 (11%) | 269 (75%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0106, L0122, L2429, L2535, L2735 |
| Charmed Shield | Opponent | L0425, L0827, L0934, L1026, L1727, L1827, L1927 |
| Clockwork Compass | Mine | L1228 |
| Clockwork Compass | Opponent | L0512 |
| Elixir of Power | Mine | L1118, L1135, L1927 |
| Fistful of Laurels | Mine | L1827 |
| Fistful of Laurels | Opponent | L0918, L1118, L1418 |
| Horn of the Wild Hunt | Opponent | L3033 |
| Invocation of Nehek | Mine | L2429, L2535, L2735 |
| Invocation of Nehek | Opponent | L0425, L0827, L1727, L1827, L1927 |
| Opal Amulet | Mine | L1418, L1435 |
| Periapt of Soul Exchange | Mine | L2029, L2131 |
| Periapt of Soul Exchange | Opponent | L0721 |
| Ring of Doom | Mine | L0206, L0222, L1118, L1135, L1228, L1531 |
| Ring of Doom | Opponent | L0512, L1531, L2131, L3033 |
| Ring of Jet | Mine | L1026, L1118, L1135, L1228 |
| Ring of Jet | Opponent | L0512, L0810 |
| Standard of the Fell Warrior | Mine | L1323 |
| Storm Daemon (Renegade 2.0) | Mine | L2131 |
| Storm Daemon (Renegade 2.0) | Opponent | L0721 |
| Twice-Blessed Armour | Mine | L0721, L1026 |
| Twice-Blessed Armour | Opponent | L0307, L0810 |
| Witch Hunter's Ward | Mine | L0721, L0810, L0827 |
| Witch Hunter's Ward | Opponent | L0307 |

# Doctrine scorecard: jb-h2h-mine-b54c226-p2

### Scorecard: jb-h2h-mine-b54c226-p2

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0106 | 4 | 1 | Mine | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 387 |
| L0106 | 4 | 1 | Opponent | no | 0 | 4 | 2 | 1 | 1 | 0 | 0 | 981 |
| L0122 | 2 | 1 | Mine | - | - | - | 2 | 1 | 0 | 0 | 0 | 317 |
| L0122 | 2 | 1 | Opponent | - | - | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L0206 | 2 | 1 | Mine | - | - | 2 | 0 | 3 | 1 | 0 | 0 | 0 |
| L0206 | 2 | 1 | Opponent | - | - | 3 | 3 | 0 | 0 | 0 | 0 | 615 |
| L0222 | 6 | 1 | Mine | no | 4 | 2 | 4 | 3 | 1 | 0 | 0 | 251 |
| L0222 | 6 | 1 | Opponent | no | 6 | 2 | 2 | 2 | 0 | 0 | 0 | 55 |
| L0307 | 1 | 1 | Mine | no | 0 | 3 | 0 | 2 | 0 | 0 | 0 | 675 |
| L0307 | 1 | 1 | Opponent | yes | 5 | 2 | 1 | 1 | 1 | 0 | 0 | 420 |
| L0323 | 5 | 1 | Mine | no | - | 2 | 2 | 2 | 0 | 0 | 0 | 590 |
| L0323 | 5 | 1 | Opponent | yes | - | 2 | 0 | 1 | 0 | 0 | 0 | 0 |
| L0409 | 1 | 1 | Mine | no | 2 | 2 | 2 | 3 | 0 | 0 | 0 | 0 |
| L0409 | 1 | 1 | Opponent | no | 7 | - | 0 | 1 | 0 | 0 | 0 | 420 |
| L0425 | 5 | 1 | Mine | yes | - | 2 | 3 | 4 | 0 | 0 | 0 | 0 |
| L0425 | 5 | 1 | Opponent | yes | - | - | 2 | 3 | 0 | 0 | 0 | 0 |
| L0512 | 2 | 1 | Mine | - | - | - | 1 | 1 | 0 | 0 | 0 | 1448 |
| L0512 | 2 | 1 | Opponent | - | - | 2 | 2 | 3 | 1 | 0 | 0 | 330 |
| L0528 | 6 | 1 | Mine | no | 0 | 4 | 1 | 1 | 0 | 0 | 0 | 475 |
| L0528 | 6 | 1 | Opponent | no | 8 | - | 0 | 2 | 0 | 0 | 0 | 0 |
| L0616 | 4 | 1 | Mine | no | 0 | 6 | 3 | 0 | 1 | 0 | 0 | 615 |
| L0616 | 4 | 1 | Opponent | no | 2 | 2 | 3 | 0 | 1 | 0 | 0 | 200 |
| L0632 | 2 | 1 | Mine | - | - | 2 | 2 | 0 | 0 | 0 | 0 | 926 |
| L0632 | 2 | 1 | Opponent | - | - | 2 | 3 | 2 | 0 | 0 | 0 | 340 |
| L0721 | 1 | 1 | Mine | yes | 3 | 2 | 2 | 0 | 1 | 0 | 0 | 420 |
| L0721 | 1 | 1 | Opponent | no | 0 | - | 0 | 5 | 1 | 0 | 0 | 355 |
| L0810 | 6 | 1 | Mine | no | 0 | 6 | 1 | 2 | 0 | 0 | 0 | 605 |
| L0810 | 6 | 1 | Opponent | no | 10 | 2 | 2 | 0 | 0 | 0 | 0 | 330 |
| L0827 | 5 | 1 | Mine | no | - | 3 | 1 | 1 | 0 | 0 | 0 | 807 |
| L0827 | 5 | 1 | Opponent | yes | - | 2 | 2 | 5 | 0 | 0 | 0 | 0 |
| L0918 | 6 | 1 | Mine | no | 4 | 3 | 1 | 1 | 0 | 0 | 0 | 420 |
| L0918 | 6 | 1 | Opponent | no | 11 | 2 | 6 | 1 | 0 | 0 | 0 | 419 |
| L0934 | 4 | 1 | Mine | no | 0 | - | 0 | 0 | 0 | 0 | 0 | 808 |
| L0934 | 4 | 1 | Opponent | yes | 4 | 2 | 6 | 2 | 0 | 0 | 0 | 160 |
| L1026 | 6 | 1 | Mine | no | 0 | 2 | 2 | 1 | 1 | 0 | 0 | 330 |
| L1026 | 6 | 1 | Opponent | no | 1 | 2 | 4 | 3 | 1 | 0 | 0 | 110 |
| L1118 | 2 | 1 | Mine | - | - | 2 | 5 | 1 | 0 | 0 | 0 | 330 |
| L1118 | 2 | 1 | Opponent | - | - | 4 | 5 | 1 | 0 | 0 | 0 | 370 |
| L1135 | 1 | 1 | Mine | yes | 3 | 3 | 1 | 0 | 0 | 0 | 0 | 330 |
| L1135 | 1 | 1 | Opponent | yes | 0 | 3 | 1 | 3 | 2 | 0 | 0 | 0 |
| L1228 | 4 | 1 | Mine | no | 4 | 6 | 1 | 0 | 0 | 0 | 0 | 524 |
| L1228 | 4 | 1 | Opponent | no | 2 | - | 0 | 2 | 0 | 0 | 0 | 111 |
| L1323 | 3 | 1 | Mine | yes | 6 | 2 | 3 | 1 | 1 | 0 | 0 | 317 |
| L1323 | 3 | 1 | Opponent | no | 9 | 1 | 6 | 1 | 0 | 0 | 0 | 0 |
| L1418 | 2 | 1 | Mine | - | - | 2 | 5 | 1 | 0 | 0 | 0 | 0 |
| L1418 | 2 | 1 | Opponent | - | - | - | 3 | 0 | 0 | 0 | 0 | 234 |
| L1435 | 1 | 1 | Mine | no | 0 | 3 | 3 | 1 | 0 | 0 | 0 | 0 |
| L1435 | 1 | 1 | Opponent | no | 0 | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L1531 | 1 | 1 | Mine | no | 3 | 3 | 1 | 0 | 0 | 0 | 0 | 0 |
| L1531 | 1 | 1 | Opponent | no | 1 | 2 | 6 | 1 | 2 | 0 | 0 | 0 |
| L1629 | 3 | 1 | Mine | no | 8 | 1 | 2 | 2 | 0 | 0 | 0 | 200 |
| L1629 | 3 | 1 | Opponent | no | 3 | 2 | 3 | 1 | 0 | 0 | 0 | 170 |
| L1727 | 5 | 1 | Mine | yes | - | 4 | 1 | 0 | 0 | 0 | 0 | 0 |
| L1727 | 5 | 1 | Opponent | yes | - | 2 | 3 | 3 | 0 | 0 | 0 | 0 |
| L1827 | 3 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 297 |
| L1827 | 3 | 1 | Opponent | no | 8 | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| L1927 | 1 | 1 | Mine | no | 2 | 1 | 1 | 1 | 0 | 0 | 0 | 0 |
| L1927 | 1 | 1 | Opponent | no | 0 | 2 | 1 | 2 | 0 | 0 | 0 | 0 |
| L2029 | 1 | 1 | Mine | no | 0 | - | 2 | 1 | 0 | 0 | 0 | 860 |
| L2029 | 1 | 1 | Opponent | no | 0 | 3 | 3 | 1 | 0 | 0 | 0 | 170 |
| L2131 | 1 | 1 | Mine | yes | 6 | - | 2 | 1 | 1 | 0 | 0 | 285 |
| L2131 | 1 | 1 | Opponent | no | 5 | 4 | 1 | 1 | 0 | 0 | 0 | 170 |
| L2235 | 3 | 1 | Mine | no | 2 | 2 | 5 | 1 | 0 | 0 | 0 | 0 |
| L2235 | 3 | 1 | Opponent | no | 0 | 2 | 6 | 0 | 1 | 0 | 0 | 126 |
| L2429 | 5 | 1 | Mine | no | - | 3 | 2 | 2 | 0 | 0 | 0 | 0 |
| L2429 | 5 | 1 | Opponent | yes | - | 3 | 1 | 2 | 0 | 0 | 0 | 0 |
| L2535 | 3 | 1 | Mine | no | 1 | 5 | 2 | 1 | 0 | 0 | 0 | 0 |
| L2535 | 3 | 1 | Opponent | no | 0 | 1 | 3 | 2 | 0 | 0 | 0 | 0 |
| L2735 | 5 | 1 | Mine | yes | - | 3 | 2 | 3 | 0 | 0 | 0 | 0 |
| L2735 | 5 | 1 | Opponent | yes | - | 3 | 3 | 2 | 0 | 0 | 0 | 0 |
| L3033 | 3 | 1 | Mine | yes | 5 | 5 | 4 | 0 | 0 | 0 | 0 | 519 |
| L3033 | 3 | 1 | Opponent | no | 0 | 1 | 8 | 2 | 0 | 0 | 0 | 144 |
| **Average** | | | Mine | 27% | 2.2 | 3.0 | 1.9 | 1.2 | 0.2 | 0.0 | 0.0 | 353.8 |
| **Average** | | | Opponent | 30% | 3.4 | 2.3 | 2.8 | 1.6 | 0.3 | 0.0 | 0.0 | 173.1 |

### KPIs: jb-h2h-mine-b54c226-p2

Rules off - Opponent only: JOINS A FRIEND.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 29% (53 of 184) | 13% (24 of 183) | 21% (77 of 367) |
| Winner chose to follow up after the loser gave ground |  | 99% (80 of 81); on the table 99% | 94% (51 of 54); on the table 96% | 97% (131 of 135); on the table 98% |
| Winner chose to pursue after the loser fell back in good order |  | 100% (5 of 5); on the table 100% | 94% (15 of 16); on the table 94% | 95% (20 of 21); on the table 95% |
| Winner chose to pursue after the loser fled |  | 85% (22 of 26); on the table 85% | 70% (33 of 47); on the table 74% | 75% (55 of 73); on the table 78% |
| Winner chose to follow up or pursue (all three) |  | 96% (107 of 112); on the table 96% | 85% (99 of 117); on the table 87% | 90% (206 of 229); on the table 91% |
| Magic missiles tried each own turn | 50%+ | 30% (103 of 342) | 40% (62 of 156) | 33% (165 of 498) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 46% (103 of 222) | 50% (62 of 124) | 48% (165 of 346) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 48% (11 of 23) | 54% (28 of 52) | 52% (39 of 75) |
| Points that never fought | lower | 39% (28191 of 71583) | 45% (32126 of 71989) | 42% (60317 of 143572) |
|   infantry points that never fought | lower | 45% (7410 of 16324) | 66% (9277 of 14029) | 55% (16687 of 30353) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 62% (177 of 284) | 56% (166 of 297) | 59% (343 of 581) |
| Bound items with a magic missile used (at least once a game) |  | 85% (17 of 20); 1.7 uses a game | 72% (13 of 18); 1.3 uses a game | 79% (30 of 38); 1.5 uses a game |
| Bound items with another spell used |  | 67% (12 of 18); 0.7 uses a game | 50% (1 of 2); 0.0 uses a game | 65% (13 of 20); 0.4 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 55% (11 of 20); 0.3 uses a game | 29% (2 of 7); 0.1 uses a game | 48% (13 of 27); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 60% (36208 of 60231) | 51% (32026 of 63281) | 55% (68234 of 123512) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.9 (28%) | 0.8 (30%) | 2.6 (29%) |
| MARCHED: its unit marched | 1.0 (15%) | 0.6 (21%) | 1.6 (17%) |
| CHARGED: its unit charged | 0.2 (4%) | 0.0 (1%) | 0.3 (3%) |
| IN COMBAT: engaged in combat | 1.3 (20%) | 0.5 (18%) | 1.8 (19%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.2 (6%) | 0.2 (2%) |
| FLEEING: fleeing | 0.0 (0%) | 0.1 (3%) | 0.1 (1%) |
| GONE: slain | 1.6 (23%) | 0.1 (5%) | 1.7 (18%) |
| OFF THE TABLE: off the table or not arrived | 0.5 (7%) | 0.2 (7%) | 0.7 (7%) |
| STUPIDITY: Stupidity | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.1 (1%) | 0.2 (6%) | 0.2 (3%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.1 | 1.5 | 1.1 | 4.6 | 0.4 | 2.0 |
| not cast | 3.7 | 3.4 | 3.9 | 9.2 | 1.9 | 19.7 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) | 1.0 (5%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (1%) | 1.5 (45%) | 0.2 (6%) | 2.6 (29%) | 0.2 (13%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.6 (17%) | 0.4 (19%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (3%) | 0.1 (3%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.1 (2%) | 0.3 (8%) | 0.6 (17%) | 1.8 (19%) | 0.4 (20%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.2 (7%) | 0.3 (10%) | 0.2 (6%) | 0.2 (2%) | 0.0 (0%) | 0.0 (0%) |
| NO CASTS LEFT: every cast used on other spells | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) |
| FLEEING: fleeing | 0.1 (3%) | 0.0 (0%) | 0.0 (1%) | 0.1 (1%) | 0.0 (1%) | 0.2 (1%) |
| GONE: slain | 0.7 (20%) | 0.6 (17%) | 0.6 (16%) | 1.7 (18%) | 0.4 (19%) | 3.4 (17%) |
| OFF THE TABLE: off the table or not arrived | 0.2 (7%) | 0.2 (6%) | 0.3 (7%) | 0.7 (7%) | 0.2 (10%) | 1.3 (6%) |
| STUPIDITY: Stupidity | 0.1 (3%) | 0.0 (1%) | 0.0 (1%) | 0.1 (1%) | 0.0 (0%) | 0.3 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (1%) | 0.2 (7%) | 0.0 (0%) | 0.0 (0%) | 0.2 (13%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (3%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.1 (57%) | 0.2 (7%) | 1.8 (45%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 13.5 (69%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.6 a game | 0.7 a game | 0.6 a game |
| stood (cast and not dispelled) | 78% (14 of 18) | 58% (14 of 24) | 67% (28 of 42) |
| the unit moved after it | 71% (10 of 14) | 57% (8 of 14) | 64% (18 of 28) |
| it charged on its next turn | 0% (0 of 14) | 21% (3 of 14) | 11% (3 of 28) |
| the enemy charged it first | 7% (1 of 14) | 0% (0 of 14) | 4% (1 of 28) |
| it fought by the end of its next turn | 0% (0 of 14) | 0% (0 of 14) | 0% (0 of 28) |
| it moved out of a charge the enemy had planned (not charged first) | 14% (2 of 14) | 14% (2 of 14) | 14% (4 of 28) |
| none of these (no charge, no fight, no charge escaped) | 79% (11 of 14) | 64% (9 of 14) | 71% (20 of 28) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 65% (556 of 855) | 56% (462 of 832) | 60% (1018 of 1687) |
|   cavalry | 59% (47 of 79) | 61% (102 of 168) | 60% (149 of 247) |
|   character | 50% (56 of 111) | 27% (32 of 119) | 38% (88 of 230) |
|   chariot | 61% (67 of 109) | 68% (25 of 37) | 63% (92 of 146) |
|   infantry | 56% (140 of 251) | 57% (184 of 322) | 57% (324 of 573) |
|   monster | 53% (23 of 43) | 50% (21 of 42) | 52% (44 of 85) |
|   war machine | 85% (223 of 262) | 68% (98 of 144) | 79% (321 of 406) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.3 (27%) | 2.4 (23%) | 4.7 (25%) |
| CHARGED: it charged | 1.0 (12%) | 1.9 (18%) | 2.9 (15%) |
| FLEEING: it fled or was fleeing | 0.1 (2%) | 0.1 (1%) | 0.2 (1%) |
| IN COMBAT: it fought this turn or the last | 1.0 (12%) | 0.6 (6%) | 1.6 (9%) |
| MOVED: a war machine that moved | 0.1 (1%) | 0.0 (0%) | 0.1 (0%) |
| NO TARGET IN RANGE | 1.2 (14%) | 2.0 (19%) | 3.2 (17%) |
| ONLY IN COMBAT: the only targets were in combat | 0.6 (8%) | 0.6 (6%) | 1.2 (7%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.5 (18%) | 1.7 (16%) | 3.2 (17%) |
| SHELTERED: the target was sheltered | 0.2 (3%) | 0.4 (4%) | 0.6 (3%) |
| STUPIDITY | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR | 0.3 (3%) | 0.6 (6%) | 0.9 (5%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 6.3 | 1.4 | 83% | 4.7 pts | 29 pts |
| character | 2.8 | 0.9 | 74% | 9.5 pts | 26 pts |
| chariot | 2.6 | 1.9 | 66% | 15.9 pts | 41 pts |
| infantry | 12.6 | 5.5 | 70% | 9.9 pts | 125 pts |
| monster | 1.6 | 0.5 | 73% | 8.1 pts | 13 pts |
| war machine | 8.9 | 6.7 | 62% | 24.8 pts | 221 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.8 | 5.8 | 4.8 |
| Charges that made contact a game | 2.7 | 4.2 | 3.4 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.92 declared, 0.64 contact (25 units) | 0.75 declared, 0.58 contact (12 units) | 0.86 declared, 0.62 contact (37 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.75 declared, 0.62 contact (8 units) | 0.82 declared, 0.64 contact (11 units) | 0.79 declared, 0.63 contact (19 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.43 declared, 0.30 contact (250 units) | 0.66 declared, 0.47 contact (288 units) | 0.56 declared, 0.39 contact (538 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 56% (41 of 73) | 67% (12 of 18) | 58% (7 of 12) | 58% (60 of 103) |
| Character in a unit | 81% (25 of 31) | 77% (10 of 13) | 60% (3 of 5) | 78% (38 of 49) |
| Character on its own | 83% (34 of 41) | 66% (27 of 41) | 33% (20 of 61) | 57% (81 of 143) |
| Chariot | 53% (9 of 17) | 62% (8 of 13) | - | 57% (17 of 30) |
| Infantry | 53% (50 of 94) | 59% (20 of 34) | 33% (1 of 3) | 54% (71 of 131) |
| Monster | 45% (13 of 29) | 89% (8 of 9) | - | 55% (21 of 38) |
| Monstrous | 36% (5 of 14) | 57% (8 of 14) | - | 46% (13 of 28) |
| War Machines | 70% (40 of 57) | 100% (2 of 2) | - | 71% (42 of 59) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 100% (20 of 20); on the table 100% | 31% (32 of 102) | 39% | 73% (16 of 22) | 83% (5 of 6); 3.8 uses a game | 100% (2 of 2); 1.2 uses a game | 83% (5 of 6); 1.2 uses a game |
| Chaos Dwarfs | 4 | 100% (8 of 8); on the table 100% | 39% (14 of 36) | 63% | 75% (24 of 32) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
| Dwarfen Mountain Holds | 6 | 100% (7 of 7); on the table 100% | - | 57% | 70% (38 of 54) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 7 | 94% (15 of 16); on the table 94% | 33% (16 of 48) | 49% | 64% (49 of 76) | 0.0 uses a game | 50% (1 of 2); 0.1 uses a game | 25% (1 of 4); 0.1 uses a game |
| Grand Cathay | 6 | 95% (20 of 21); on the table 95% | 34% (47 of 138) | 49% | 50% (27 of 54) | 71% (10 of 14); 7.5 uses a game | 50% (1 of 2); 0.3 uses a game | 0% (0 of 6); 0.0 uses a game |
| High Elf Realms | 4 | 83% (15 of 18); on the table 83% | 6% (1 of 18) | 22% | 39% (13 of 33) | 100% (3 of 3); 3.0 uses a game | 64% (9 of 14); 4.8 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 2 | 100% (10 of 10); on the table 100% | - | 43% | 42% (5 of 12) | 0.0 uses a game | 0.0 uses a game | 100% (2 of 2); 1.0 uses a game |
| Lizardmen | 1 | 100% (2 of 2); on the table 100% | - | 29% | 43% (3 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 4 | 77% (10 of 13); on the table 85% | 0% (0 of 18) | 39% | 79% (22 of 28) | 100% (4 of 4); 2.8 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 1 | 100% (4 of 4); on the table 100% | 8% (1 of 12) | 3% | 25% (2 of 8) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Skaven | 3 | 100% (18 of 18); on the table 100% | 39% (7 of 18) | 44% | 68% (17 of 25) | 100% (2 of 2); 1.3 uses a game | 0.0 uses a game | 67% (2 of 3); 0.7 uses a game |
| Tomb Kings of Khemri | 5 | 89% (8 of 9); on the table 89% | - | 48% | 20% (5 of 25) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 9 | 86% (32 of 37); on the table 86% | 36% (24 of 66) | 32% | 65% (35 of 54) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 9 | 74% (17 of 23); on the table 83% | 56% (10 of 18) | 40% | 52% (38 of 73) | 100% (2 of 2); 0.9 uses a game | 0.0 uses a game | 100% (1 of 1); 0.1 uses a game |
| Wood Elf Realms | 7 | 87% (20 of 23); on the table 87% | 54% (13 of 24) | 35% | 63% (49 of 78) | 57% (4 of 7); 1.9 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (jb-h2h-mine-b54c226-p2, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 59% (49) | 44% (19) | 54% (68) |
| ...free all their last turn and able to turn (per game) | 0.83 | 0.31 | 1.14 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.31 | 0.14 | 0.44 |
| ...with the charger already in that arc before they moved (per game) | 0.53 | 0.19 | 0.72 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 1.86 | 1.53 | 3.39 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 1.28 | 1.31 | 2.58 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 5.89 | 5.25 | 11.14 |

### Quality by phase: jb-h2h-mine-b54c226-p2

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.8 | 3.3 |
| Strategy | Charge objectives carried out (made contact) | 46% (56 of 122) | 47% (91 of 195) |
| Strategy | Shoot objectives carried out (shot that target) | 44% (153 of 351) | 49% (134 of 271) |
| Strategy | Close-in objectives charged next turn | 7% (9 of 131) | 18% (40 of 228) |
| Strategy | Support requests answered (helper made contact too) | 31% (5 of 16) | 52% (17 of 33) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (3 of 3) | - |
| Strategy | Hexes on a unit its side charged or shot that turn | 64% (9 of 14) | 83% (10 of 12) |
| Strategy | Joined characters whose unit fought | 34% (13 of 38) | 36% (16 of 45) |
| Strategy | Lone characters that fought | 72% (77 of 107) | 65% (51 of 78) |
| Movement | Charges halted short of contact | 0.2 | 0.2 |
| Movement | Idle units | 1.2 | 1.6 |
| Movement | Points that never moved of their own | 353.8 | 173.1 |
| Movement | Fights charged into per game | 2.4 | 3.5 |
| Movement | Charges with odds: long shots (under 50%) | 6 of 70, net -72 | 22 of 109, net +206 |
| Movement | Charges with odds: sweet spot (55-75%) | 14 of 70, net -8 | 18 of 109, net +140 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 11 of 70, net +109 | 6 of 109, net +42 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 18 of 70, net +101 | 36 of 109, net +142 |
| Shooting | Shots by shooting units (incl. breath weapons) | 10.2 | 11.2 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 43% (157 of 367) | 41% (167 of 404) |
| Shooting | Points destroyed by shooting units | 112.6 | 66.6 |
| Shooting | War machine shots | 6.2 | 2.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 52% (115 of 223) | 58% (57 of 98) |
| Shooting | Points destroyed by war machines | 58.7 | 48.7 |
| Magic | Magic missiles cast | 1.6 | 1.0 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 46% (27 of 59) | 46% (16 of 35) |
| Magic | Wounds caused by magic missiles | 2.2 | 1.6 |
| Magic | Wounds caused by other spells | 1.4 | 0.5 |
| Magic | Points destroyed by magic (all spells) | 31.6 | 11.8 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.9 / 0.5 / 0.7 / 0.1 | 2.1 / 0.3 / 0.5 / 0.1 |
| Combat | Points destroyed in combat | 208.1 | 436.9 |
| Combat | Points run down | 56.3 | 107.7 |
| Combat | Net points per charged fight, damage counted | +51 | +134 |
| Combat | Net per 100 charger points, damage counted | +18.7 | +51.2 |
| Combat | First round won (charged fights) | 79% | 75% |
| Combat | Net points per charged fight | +38 | +132 |
| Combat | Net points per supported fight / lone fight | +191 / +15 | +173 / +122 |
| Combat | Charged fights on a top-3 enemy unit | 24 of 85 | 49 of 126 |
| Game | Points lost | 867.3 | 527.0 |
| Game | VP from objectives | 500.0 | 738.9 |
| Game | Lone holders (player turns) | 2.2 | 3.4 |

- Mine won / drew / lost: 12 / 6 / 18 of 36 ended games (of 36); mean margin (Mine - Opponent) -574 VP
- The side that went first won 13 of 30 games with a winner
- Points traded per game (both sides' losses): 1394
- Games not ended: 0; findings 0, warnings 1

### Opponent rules: jb-h2h-mine-b54c226-p2

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 0.5 | +0.0 | 0.0 | 0.0 |
| ALREADY CARRIED | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARRIVAL HUNT | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +5.1 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.2 | +0.0 | 0.0 | 42.2 | 0.2 | +0.0 | 0.0 | 3.5 |
| BACKUP TARGETS | 1.4 | +10.7 | 0.0 | 77.4 | 0.8 | +6.8 | 0.0 | 8.9 |
| BEST FACING | 0.7 | +24.6 | 0.0 | 30.7 | 0.7 | +17.6 | 0.0 | 5.7 |
| BEST FIRST | 4.1 | +177.1 | 186.1 | 78.7 | 4.9 | +188.0 | 156.7 | 75.5 |
| BEST OVERALL | 1.0 | +67.7 | 0.0 | 27.4 | 0.7 | +46.8 | 0.0 | 28.6 |
| BEST PREY | 1.1 | +75.1 | 34.2 | 12.6 | 1.0 | +43.1 | 55.9 | 0.0 |
| BEST PRIZE | 0.1 | -3.5 | 0.8 | 3.8 | 0.1 | -9.4 | 10.6 | 13.1 |
| BIG CHARACTER SAFETY | 0.3 | -0.5 | 0.0 | 11.2 | 0.1 | +0.2 | 0.0 | 0.0 |
| BLOCKED CHARGE SKIPPED | 0.2 | +0.0 | 14.8 | 0.0 | 0.1 | +0.0 | 11.3 | 0.0 |
| BLOCKED WHEEL | 0.2 | +6.3 | 0.0 | 1.4 | 0.6 | -0.7 | 0.0 | 0.0 |
| BLOWS WHERE AIMED | 0.2 | -2.8 | 17.6 | 5.5 | 0.3 | -35.5 | 61.5 | 5.4 |
| BOMBING RUN | 0.1 | +1.3 | 0.0 | 0.0 | - | - | - | - |
| BOUND ASSAILMENT | 0.1 | +0.0 | 0.0 | 13.8 | - | - | - | - |
| CANNON PLAN MISSED | 0.7 | +0.0 | 67.8 | 22.1 | 0.5 | +0.0 | 86.8 | 0.0 |
| CANNON PLANNED TARGET | 4.9 | +159.2 | 349.4 | 105.0 | 2.1 | +154.5 | 221.6 | 6.9 |
| CANNON SIGHT KEPT | 1.3 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 13.1 |
| CARRIES OUT SET-UP | 0.1 | -1.0 | 16.5 | 0.0 | 0.4 | -1.3 | 57.2 | 0.0 |
| CAST JOB | 0.6 | +18.3 | 71.9 | 37.0 | 0.4 | +13.3 | 40.1 | 24.8 |
| CASTER AWAY FROM SCREEN | 0.3 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.3 | +23.1 | 12.8 | 15.8 | 0.2 | +8.0 | 2.7 | 0.0 |
| CASTS AFTER FRIENDS | 0.4 | +0.0 | 0.0 | 9.9 | 0.4 | +0.0 | 0.0 | 24.7 |
| CASTS FROM BEHIND | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.0 | +1.3 | 0.0 | 0.0 | - | - | - | - |
| CATCH ODDS | - | - | - | - | 0.1 | +2.8 | 0.0 | 0.0 |
| CHAFF PASSED | 0.3 | -0.3 | 0.0 | 11.1 | 0.2 | -0.5 | 0.0 | 7.3 |
| CHAMPION TAKES THE CHALLENGE | - | - | - | - | 0.1 | +0.1 | 10.7 | 0.0 |
| CHARGE BAND | 0.1 | +0.0 | 17.2 | 2.4 | 0.2 | +0.0 | 6.0 | 0.0 |
| CHARGE NOW FIRST | 2.1 | +0.0 | 170.0 | 65.3 | 2.5 | +0.0 | 329.2 | 50.5 |
| CHARGE NOW WEIGHED | 0.7 | -46.3 | 20.9 | 17.2 | 0.6 | -57.4 | 20.9 | 29.9 |
| CHARGER SLAIN LOST | 0.4 | -15.1 | 49.7 | 17.4 | 0.5 | -9.7 | 56.1 | 10.0 |
| CHARIOT NO STATIC JOB | 0.1 | +0.0 | 0.0 | 4.7 | - | - | - | - |
| CHARIOT WIZARD CAREFUL | 0.1 | -0.1 | 0.0 | 0.0 | - | - | - | - |
| CHEAP HELPER | - | - | - | - | 0.1 | +0.0 | 9.2 | 2.5 |
| COMBAT PIVOT | 0.4 | +0.0 | 35.9 | 42.2 | 0.8 | +0.0 | 52.5 | 10.1 |
| CONTINUE AHEAD WEIGHED | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | 0.4 | +91.6 | 7.6 | 9.9 | 0.5 | +45.3 | 20.2 | 34.1 |
| COUNTER-CHARGE COVER | 10.9 | +979.0 | 0.0 | 254.0 | 7.7 | +808.0 | 0.0 | 114.9 |
| DEFENSIVE ARMY | 0.4 | +0.0 | 27.2 | 3.6 | 0.1 | +0.0 | 0.0 | 0.0 |
| DEFENSIVE FLOOR | 0.0 | +0.1 | 0.0 | 0.0 | - | - | - | - |
| EDGE GIVE GROUND | 0.1 | +5.8 | 3.9 | 6.4 | 0.3 | +8.2 | 49.5 | 0.0 |
| ELIXIR WORTH | 0.0 | +0.4 | 0.0 | 0.0 | - | - | - | - |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 1.9 | +150.1 | 0.0 | 60.7 | 1.5 | +111.4 | 0.0 | 35.7 |
| FALLBACK BY WORTH | 4.4 | +46.4 | 0.0 | 51.6 | 5.2 | +71.1 | 0.0 | 57.2 |
| FIRE AND FLEE | 0.1 | +0.9 | 7.7 | 0.0 | - | - | - | - |
| FLANK NOT WEIGHED | 6.2 | +0.0 | 0.0 | 182.2 | 5.3 | +0.0 | 0.0 | 88.2 |
| FOCUS FIRE | - | - | - | - | 0.0 | +0.4 | 1.5 | 0.0 |
| FOLLOW UP WEIGHED | 0.9 | +95.1 | 0.0 | 61.5 | 0.9 | +95.1 | 0.0 | 25.8 |
| FRIENDS SHOTS CHECKED | 0.3 | +23.0 | 0.0 | 35.1 | 0.3 | +15.0 | 0.0 | 6.3 |
| GIVES UP | 0.0 | -1.5 | 4.4 | 0.0 | 0.1 | -1.1 | 6.9 | 0.0 |
| GIVES UP ITS SCREEN | 0.0 | -0.4 | 3.5 | 0.0 | 0.1 | -1.6 | 14.5 | 0.0 |
| GROUND FLIERS | 0.1 | +0.7 | 0.0 | 0.0 | - | - | - | - |
| HELPER ALREADY ASKED | - | - | - | - | 0.1 | +0.0 | 20.8 | 0.0 |
| HELPER UNSEEN | 0.2 | +0.0 | 23.6 | 17.4 | 0.5 | +0.0 | 57.7 | 8.1 |
| HILL BY ITS CHANCE | 0.5 | -34.3 | 0.0 | 0.0 | 0.5 | -44.2 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 7.1 | -110.6 | 290.7 | 186.1 | 10.7 | -212.8 | 698.8 | 171.1 |
| HORN WORTH | - | - | - | - | 0.0 | +0.1 | 0.0 | 0.0 |
| HUNT ADVANCE | 0.1 | +0.7 | 5.4 | 0.9 | 0.3 | +3.6 | 15.6 | 0.0 |
| HUNT DROPPED | 0.0 | +0.0 | 5.4 | 0.0 | 0.1 | +0.0 | 3.9 | 0.0 |
| HUNT IN PAIRS | 0.6 | +36.5 | 0.0 | 0.0 | 0.4 | +29.8 | 0.0 | 11.4 |
| HUNT KEPT | - | - | - | - | 0.2 | +5.5 | 29.5 | 0.0 |
| HUNT RESULT | 0.2 | +26.2 | 5.4 | 0.9 | 0.3 | +54.2 | 3.9 | 0.0 |
| HUNT THE GUNS | 0.2 | +42.7 | 22.9 | 2.4 | 0.4 | +104.2 | 23.6 | 3.0 |
| INVITES THE FIGHT | 2.1 | +35.7 | 47.4 | 40.3 | 1.6 | +28.1 | 72.9 | 23.3 |
| JOINS A FRIEND | 1.6 | +10.0 | 122.3 | 26.1 | - | - | - | - |
| JOINT CHARGE PLAN | - | - | - | - | 0.1 | +2.7 | 5.1 | 0.0 |
| JOINT KNOWS CHALLENGE | 0.1 | -0.6 | 16.1 | 0.0 | 0.1 | -0.5 | 10.3 | 0.0 |
| KEEP FALLS | 0.0 | +0.6 | 0.0 | 0.0 | - | - | - | - |
| KEEPS ITS PREY | 0.0 | +1.0 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| KEEPS ITS TARGET | 1.4 | +41.7 | 102.2 | 65.5 | 2.1 | +64.2 | 280.6 | 67.2 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| KILLS COUNT | 1.6 | +96.8 | 93.1 | 51.8 | 2.0 | +77.9 | 209.1 | 37.4 |
| KILLS COUNT NEXT TURN | 4.9 | +172.0 | 146.9 | 124.8 | 7.4 | +258.2 | 334.2 | 107.9 |
| LONE CHARACTER SAFE SPOT | 0.3 | +30.9 | 4.9 | 0.0 | 0.3 | +3.4 | 6.5 | 8.1 |
| LONE WIZARD HOLDS BACK | 0.1 | +0.0 | 0.0 | 3.9 | 0.4 | +0.0 | 0.0 | 22.1 |
| LONE WIZARD KEPT IN | 0.6 | +39.4 | 0.0 | 0.0 | 0.3 | +23.5 | 0.0 | 0.0 |
| LONG SHOT | 0.4 | -3.4 | 7.8 | 7.3 | 0.8 | +5.8 | 56.2 | 13.6 |
| LOST CHARGE | 2.9 | -56.2 | 57.4 | 93.2 | 2.6 | -40.9 | 48.6 | 49.5 |
| LURE BY WHAT IT DRAWS | 0.0 | -1.6 | 0.0 | 0.0 | 0.1 | -7.6 | 0.0 | 4.4 |
| MAKE SURE TOGETHER | 0.3 | +21.5 | 10.4 | 10.5 | 0.6 | +35.0 | 8.6 | 0.0 |
| MANOEUVRE | 0.2 | +9.5 | 0.0 | 7.6 | 0.3 | +7.0 | 0.0 | 6.8 |
| MARCH AT ESCAPER | - | - | - | - | 0.0 | +0.6 | 0.0 | 0.0 |
| MARCH CHECK | 0.5 | +11.3 | 0.0 | 10.6 | 0.4 | +18.4 | 0.0 | 7.6 |
| MARCH ODDS | 0.2 | +11.8 | 2.9 | 0.0 | 0.3 | +26.9 | 5.8 | 0.0 |
| MARCH OVER CASTS | 0.3 | +21.1 | 0.0 | 0.0 | 0.2 | +24.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 5.7 | +187.5 | 0.0 | 144.8 | 4.5 | +202.7 | 0.0 | 82.3 |
| MISSILES IN THE MOVE | 3.9 | +106.7 | 0.0 | 150.9 | 3.3 | +72.8 | 0.0 | 78.9 |
| MISSILES NEXT TURN | 4.4 | +71.9 | 0.0 | 160.3 | 3.7 | +47.0 | 0.0 | 89.4 |
| MODEL FACING | 0.4 | +62.7 | 0.0 | 3.3 | 0.2 | +59.7 | 0.0 | 3.3 |
| MONSTER WIZARD ROAMS | 0.1 | +0.0 | 0.0 | 6.5 | 0.2 | +0.0 | 24.1 | 0.0 |
| MOVE AND CAST | 0.2 | +9.9 | 0.0 | 2.4 | 0.3 | +12.7 | 0.0 | 4.4 |
| MOVE SPELL IN RANGE | 0.1 | +3.8 | 0.0 | 32.2 | 0.0 | +0.2 | 0.0 | 7.6 |
| MOVE SPELL OUT OF RANGE | 0.4 | -22.7 | 1.8 | 15.1 | 0.3 | -10.7 | 0.0 | 38.1 |
| MOVE SPELL SPOT | 0.2 | +0.0 | 0.0 | 7.6 | 0.0 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE | 2.5 | +140.8 | 89.9 | 120.6 | 5.1 | +325.9 | 191.0 | 97.2 |
| MOVES UNITS SPELL | 0.1 | +3.4 | 0.0 | 0.0 | - | - | - | - |
| NEEDED THERE | 0.0 | +6.7 | 0.0 | 0.0 | - | - | - | - |
| NOT NEEDED | 0.3 | -22.5 | 41.0 | 1.4 | 0.6 | -29.6 | 95.1 | 3.5 |
| NOT TURNED | 5.9 | +69.6 | 0.0 | 139.7 | 5.2 | +115.8 | 0.0 | 70.2 |
| NOT WORTH A CAST | 0.5 | -0.3 | 0.0 | 9.9 | 0.8 | -0.7 | 0.0 | 0.0 |
| OFF BEST | 15.8 | -723.2 | 11.5 | 350.0 | 16.1 | -917.1 | 11.2 | 267.0 |
| OPENS A LANE | 0.2 | +1.0 | 3.0 | 0.0 | 0.1 | +0.5 | 1.4 | 0.0 |
| OPENS UP | 0.0 | +3.0 | 3.1 | 0.0 | 0.2 | +20.0 | 7.4 | 0.0 |
| OVERRUNS AWAY | 0.4 | +5.0 | 28.7 | 28.8 | 0.4 | +9.0 | 49.4 | 12.1 |
| PATHS CROSS | 1.9 | +133.1 | 0.0 | 60.2 | 3.1 | +205.1 | 0.0 | 44.0 |
| PERIAPT WORTH | 0.0 | +1.5 | 0.0 | 0.0 | 0.0 | +1.4 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.1 | -2.2 | 0.0 | 0.0 | 0.1 | -1.9 | 0.0 | 5.1 |
| PLAN RESULT | 36.6 | +1351.6 | 1340.2 | 1095.2 | 42.1 | +1283.0 | 1656.8 | 678.7 |
| PURSUES BIG PREY | 0.0 | -1.4 | 0.0 | 0.0 | 0.2 | -20.7 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE NEXT TURN | 0.0 | +1.7 | 0.0 | 3.4 | 0.1 | +4.9 | 0.0 | 0.0 |
| RANDOM MOVE BY FIGURES | 0.6 | +14.3 | 0.0 | 24.0 | 1.4 | +25.6 | 0.0 | 20.8 |
| RANDOM MOVER NO PROMISE | 0.1 | -8.0 | 4.0 | 4.7 | 0.2 | -12.0 | 15.9 | 0.0 |
| REDIRECT BY WHAT IT STOPS | 0.1 | -2.4 | 0.0 | 1.7 | 0.3 | +3.2 | 0.0 | 2.1 |
| REDIRECT COUNTER | 2.5 | +187.2 | 0.0 | 36.1 | 3.7 | +296.0 | 0.0 | 50.2 |
| REDIRECT WEIGHED | 0.2 | +3.0 | 0.8 | 0.0 | 0.3 | -2.0 | 20.4 | 15.2 |
| REFUSING RETIRES | 0.2 | +0.0 | 0.0 | 8.8 | 0.2 | +0.0 | 0.0 | 33.9 |
| RESERVE FALL BACK | 0.3 | +7.3 | 0.0 | 2.2 | 1.1 | +26.5 | 0.0 | 20.0 |
| RESTRAINS TO SHOOT | 0.1 | +3.7 | 0.0 | 12.0 | 0.2 | +4.1 | 0.0 | 19.6 |
| RISK BY ARC | 2.3 | +111.8 | 131.1 | 70.8 | 3.0 | +64.6 | 323.3 | 64.9 |
| SAFE SURE CHARGE | 0.0 | -1.7 | 1.1 | 0.0 | - | - | - | - |
| SAFER THAN THE JOB | 1.3 | +79.6 | 0.0 | 7.8 | 1.3 | +88.3 | 0.0 | 76.9 |
| SCOUT SPOT | 0.3 | +0.9 | 0.0 | 0.0 | 0.5 | +2.4 | 0.0 | 0.0 |
| SCOUT WAITS | 0.3 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.2 | -10.3 | 0.0 | 5.8 | 0.3 | -20.1 | 0.0 | 3.8 |
| SEARCH SPOT | 3.0 | +137.0 | 0.0 | 24.3 | 2.8 | +110.7 | 0.0 | 16.1 |
| SECOND HUNTER | 0.0 | -0.2 | 5.4 | 0.0 | 0.1 | -1.5 | 15.0 | 0.0 |
| SELF MOVE SPELL | 0.2 | +17.8 | 0.0 | 9.1 | - | - | - | - |
| SET UP TOGETHER | 0.7 | +32.4 | 10.4 | 15.2 | 2.1 | +153.2 | 58.9 | 22.2 |
| SET-UP ANY TARGET | 0.1 | +5.8 | 0.0 | 0.0 | 0.2 | +26.0 | 4.4 | 7.6 |
| SET-UP MISSED | - | - | - | - | 0.0 | +1.3 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.4 | +0.8 | 0.0 | 0.0 | 0.3 | +0.6 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.1 | +35.5 | 41.9 | 25.2 | 1.0 | +57.8 | 44.3 | 15.1 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| SHOT REPLANNED | 0.7 | +0.0 | 95.7 | 15.4 | 0.7 | +0.0 | 135.9 | 0.0 |
| SHOTS IN THE MOVE | 13.6 | +567.3 | 0.0 | 291.9 | 12.0 | +473.0 | 0.0 | 132.4 |
| SPELL CATCH ODDS | 0.0 | -0.0 | 0.0 | 0.0 | - | - | - | - |
| SPELL SETS UP CHARGE | 0.2 | +60.1 | 0.0 | 0.0 | 0.2 | +26.0 | 4.4 | 7.6 |
| SPELL WORTH | 0.9 | +15.3 | 53.4 | 38.9 | 1.7 | +26.2 | 99.4 | 99.4 |
| SPELLS IN THE FIGHT | 0.6 | -0.5 | 76.4 | 15.7 | 0.7 | -8.1 | 97.0 | 11.4 |
| STABLE ROLE | 11.7 | +0.0 | 440.5 | 144.1 | 12.4 | +0.0 | 422.9 | 162.1 |
| STANDS TO CAST | 0.0 | +0.5 | 0.0 | 0.0 | 0.1 | +4.4 | 0.0 | 5.4 |
| STAY WEIGHED | 0.1 | +1.0 | 0.0 | 0.8 | - | - | - | - |
| STOPS | 0.1 | +0.6 | 17.5 | 1.4 | 0.2 | +12.9 | 24.6 | 3.0 |
| STOPS SHORT OF THE FLANK | 0.6 | +39.4 | 0.0 | 38.4 | 0.4 | +20.4 | 0.0 | 0.0 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 4.7 | 0.1 | +0.0 | 0.0 | 4.0 |
| SUPPORT NARROWED | 5.9 | -51.8 | 365.3 | 101.8 | 7.6 | -60.6 | 375.1 | 49.2 |
| SUPPORTS | 4.2 | +54.2 | 280.1 | 54.9 | 5.2 | +63.7 | 135.9 | 23.9 |
| SURE CHARGE BEATS ADVANCE | 0.1 | -3.3 | 15.6 | 0.0 | 0.1 | -1.5 | 2.9 | 0.0 |
| SURE REACH TOGETHER | 0.5 | +2.5 | 0.0 | 32.9 | 0.8 | +3.0 | 15.3 | 21.7 |
| THROUGH LINE OF FIRE | 0.2 | +19.4 | 0.0 | 10.7 | 0.3 | -3.1 | 0.0 | 0.0 |
| TURN WORTH | 0.3 | -17.3 | 12.0 | 9.4 | 0.1 | -5.5 | 0.0 | 5.8 |
| TWO OR MORE ARRIVE | 0.1 | +0.2 | 0.0 | 0.0 | 0.4 | +3.6 | 6.2 | 4.3 |
| WAIT AFTER COSTS | 6.2 | -285.6 | 191.1 | 169.4 | 8.8 | -421.8 | 343.0 | 149.4 |
| WALKS TO THE FIGHT | 1.2 | +28.0 | 24.5 | 0.0 | 1.2 | +19.0 | 40.6 | 25.4 |
| WAR ENGINE CHARGES | 0.0 | +0.7 | 0.0 | 0.0 | 0.0 | +0.2 | 0.9 | 0.0 |
| WAR ENGINE JOBS | 0.7 | +0.0 | 42.4 | 10.0 | 0.2 | +0.0 | 32.0 | 10.3 |
| WEARS DOWN | 1.0 | +42.2 | 89.7 | 31.2 | 1.9 | +54.1 | 238.8 | 33.6 |
| WHO HITS BACK | 0.1 | +17.6 | 0.0 | 8.6 | 0.2 | +19.8 | 0.0 | 12.0 |
| WHOLE FIGHT | 0.2 | +11.5 | 36.9 | 0.0 | 0.3 | +27.3 | 44.7 | 0.0 |
| WHOLE FIGHT GAIN | 0.4 | +25.8 | 42.8 | 2.9 | 0.9 | +81.5 | 105.4 | 19.0 |
| WIDER SPREAD | 2.3 | -8.1 | 204.3 | 83.0 | 3.6 | -4.5 | 357.1 | 35.4 |

### Rule changes: jb-h2h-mine-b54c226-p2

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 1147 | 1147 | 1147 | 31.86 | -59046 | -51.5 |
| BEST FIRST | 324 | 324 | 324 | 9.00 | +13143 | +40.6 |
| SEARCH SPOT | 209 | 209 | 205 | 5.69 | +8927 | +43.5 |
| COUNTER-CHARGE COVER | 668 | 388 | 186 | 5.17 | +12201 | +65.6 |
| PATHS CROSS | 180 | 180 | 180 | 5.00 | +12176 | +67.6 |
| MOVE TO CHARGE | 273 | 273 | 143 | 3.97 | +5378 | +37.6 |
| KILLS COUNT NEXT TURN | 445 | 445 | 130 | 3.61 | +4092 | +31.5 |
| SUPPORTS | 339 | 339 | 129 | 3.58 | +1501 | +11.6 |
| FACES THE THREAT | 122 | 122 | 122 | 3.39 | +9415 | +77.2 |
| SAFER THAN THE JOB | 93 | 93 | 93 | 2.58 | +6045 | +65.0 |
| SHOTS IN THE MOVE | 920 | 587 | 85 | 2.36 | +2599 | +30.6 |
| FALLBACK BY WORTH | 347 | 347 | 78 | 2.17 | +4232 | +54.3 |
| CANNON SIGHT KEPT | 70 | 70 | 70 | 1.94 | +0 | +0.0 |
| WAIT AFTER COSTS | 541 | 541 | 69 | 1.92 | +1474 | +21.4 |
| FOLLOW UP WEIGHED | 65 | 65 | 65 | 1.81 | +6849 | +105.4 |
| BEST OVERALL | 61 | 61 | 61 | 1.69 | +4123 | +67.6 |
| ARTILLERY RE-ROLL WEIGHED | 52 | 52 | 52 | 1.44 | +0 | +0.0 |
| BEST FACING | 51 | 51 | 51 | 1.42 | +1519 | +29.8 |
| RESERVE FALL BACK | 51 | 51 | 51 | 1.42 | +1216 | +23.8 |
| WALKS TO THE FIGHT | 86 | 86 | 50 | 1.39 | +696 | +13.9 |
| SET UP TOGETHER | 103 | 87 | 49 | 1.36 | +2647 | +54.0 |
| SHOT REPLANNED | 49 | 49 | 49 | 1.36 | +0 | +0.0 |
| RISK BY ARC | 191 | 186 | 48 | 1.33 | +1350 | +28.1 |
| MAX FOR POSITIONING | 369 | 206 | 47 | 1.31 | +748 | +15.9 |
| CHARGE NOW WEIGHED | 45 | 45 | 45 | 1.25 | +3643 | +81.0 |
| SHOOTS FROM THE BEST SPOT | 75 | 75 | 45 | 1.25 | +1721 | +38.2 |
| REDIRECT COUNTER | 223 | 129 | 44 | 1.22 | +3107 | +70.6 |
| COMBAT PIVOT | 43 | 43 | 43 | 1.19 | +0 | +0.0 |
| ADVANCE LANE KEPT | 42 | 42 | 42 | 1.17 | +0 | +0.0 |
| HOLDS AMBUSHERS | 40 | 40 | 40 | 1.11 | +0 | +0.0 |
| MISSILES IN THE MOVE | 261 | 150 | 40 | 1.11 | +1232 | +30.8 |
| RANDOM MOVE BY FIGURES | 75 | 75 | 39 | 1.08 | +1437 | +36.9 |
| CANNON PLANNED TARGET | 253 | 253 | 37 | 1.03 | -108 | -2.9 |
| STOPS SHORT OF THE FLANK | 35 | 35 | 35 | 0.97 | +2152 | +61.5 |
| KILLS COUNT | 130 | 129 | 33 | 0.92 | +1394 | +42.3 |
| LONE WIZARD KEPT IN | 33 | 33 | 33 | 0.92 | +2266 | +68.7 |
| MARCH CHECK | 34 | 34 | 32 | 0.89 | +1237 | +38.7 |
| SCOUT WAITS | 32 | 32 | 32 | 0.89 | +0 | +0.0 |
| BLOCKED WHEEL | 31 | 31 | 31 | 0.86 | +202 | +6.5 |
| INVITES THE FIGHT | 131 | 131 | 30 | 0.83 | +459 | +15.3 |
| CHARGE NOW FIRST | 166 | 166 | 29 | 0.81 | -1400 | -48.3 |
| HONEST WORTH | 639 | 636 | 29 | 0.81 | +253 | +8.7 |
| WHOLE FIGHT GAIN | 45 | 42 | 26 | 0.72 | +856 | +32.9 |
| KEEPS ITS TARGET | 127 | 127 | 25 | 0.69 | +504 | +20.2 |
| SHOOTERS IN TWO RANKS | 25 | 25 | 25 | 0.69 | +50 | +2.0 |
| BEST PREY | 76 | 76 | 24 | 0.67 | +1262 | +52.6 |
| FRIENDS SHOTS CHECKED | 24 | 24 | 24 | 0.67 | +1367 | +57.0 |
| MODEL FACING | 22 | 22 | 22 | 0.61 | +4407 | +200.3 |
| REDIRECT WEIGHED | 21 | 21 | 21 | 0.58 | +1270 | +60.5 |
| CHAFF PASSED | 20 | 20 | 20 | 0.56 | -29 | -1.4 |
| MOVE AND CAST | 20 | 20 | 20 | 0.56 | +815 | +40.8 |
| MANOEUVRE | 20 | 20 | 19 | 0.53 | +592 | +31.2 |
| MARCH ODDS | 17 | 17 | 17 | 0.47 | +272 | +16.0 |
| THROUGH LINE OF FIRE | 17 | 17 | 17 | 0.47 | +589 | +34.7 |
| CASTER AWAY FROM SCREEN | 16 | 16 | 16 | 0.44 | +0 | +0.0 |
| BIG CHARACTER SAFETY | 15 | 15 | 15 | 0.42 | -12 | -0.8 |
| CAST JOB | 36 | 36 | 15 | 0.42 | +360 | +24.0 |
| CASTING BLOCK | 20 | 20 | 15 | 0.42 | +541 | +36.1 |
| CASTS FROM BEHIND | 15 | 15 | 15 | 0.42 | +0 | +0.0 |
| WEARS DOWN | 106 | 106 | 15 | 0.42 | +363 | +24.2 |
| SHORT GUN FORWARD | 14 | 14 | 14 | 0.39 | +0 | +0.0 |
| WHO HITS BACK | 13 | 13 | 13 | 0.36 | +1001 | +77.0 |
| MAKE SURE TOGETHER | 35 | 24 | 12 | 0.33 | +727 | +60.6 |
| REFUSING RETIRES | 16 | 16 | 10 | 0.28 | -3 | -0.3 |
| CHARGE BAND | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| RESTRAINS TO SHOOT | 9 | 9 | 9 | 0.25 | +281 | +31.2 |
| STUCK PIVOT | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| SURE CHARGE BEATS ADVANCE | 9 | 9 | 9 | 0.25 | -174 | -19.4 |
| BLOCKED CHARGE SKIPPED | 8 | 8 | 8 | 0.22 | +0 | +0.0 |
| LOST CHARGE | 197 | 196 | 8 | 0.22 | +88 | +11.0 |
| PIVOT GUARDS FLANK | 8 | 8 | 8 | 0.22 | -148 | -18.5 |
| PURSUES BIG PREY | 8 | 8 | 8 | 0.22 | -795 | -99.4 |
| WAR ENGINE JOBS | 33 | 33 | 8 | 0.22 | -385 | -48.2 |
| BEST PRIZE | 7 | 7 | 7 | 0.19 | -476 | -68.0 |
| SURE REACH TOGETHER | 46 | 35 | 7 | 0.19 | +56 | +8.0 |
| JOINS A FRIEND | 57 | 57 | 6 | 0.17 | +18 | +3.1 |
| MISSILES NEXT TURN | 289 | 159 | 6 | 0.17 | +8 | +1.3 |
| OPENS UP | 7 | 7 | 6 | 0.17 | +476 | +79.4 |
| OVERRUNS AWAY | 29 | 29 | 6 | 0.17 | +64 | +10.7 |
| SUPPORT NARROWED | 486 | 486 | 6 | 0.17 | -138 | -23.0 |
| HUNT IN PAIRS | 36 | 18 | 5 | 0.14 | +484 | +96.9 |
| SPELLS IN THE FIGHT | 48 | 46 | 5 | 0.14 | +73 | +14.7 |
| STANDS TO CAST | 5 | 5 | 5 | 0.14 | -12 | -2.5 |
| WHOLE FIGHT | 21 | 19 | 5 | 0.14 | +525 | +105.0 |
| WIDER SPREAD | 213 | 207 | 5 | 0.14 | +26 | +5.3 |
| BACKUP TARGETS | 79 | 40 | 4 | 0.11 | +36 | +9.0 |
| BOUND ASSAILMENT | 4 | 4 | 4 | 0.11 | +1 | +0.2 |
| DEFENSIVE ARMY | 18 | 18 | 4 | 0.11 | -178 | -44.4 |
| KEEPS SCOUTS OR AMBUSH | 4 | 4 | 4 | 0.11 | +0 | +0.0 |
| LONG SHOT | 43 | 41 | 4 | 0.11 | +131 | +32.8 |
| MOVES UNITS SPELL | 4 | 4 | 4 | 0.11 | +122 | +30.4 |
| CARRIES OUT SET-UP | 16 | 16 | 3 | 0.08 | -84 | -28.1 |
| CONTINUE AHEAD WEIGHED | 3 | 3 | 3 | 0.08 | +0 | +0.0 |
| LONE WIZARD HOLDS BACK | 18 | 18 | 3 | 0.08 | -59 | -19.6 |
| RAIDS THE BAGGAGE NEXT TURN | 3 | 3 | 3 | 0.08 | +126 | +41.8 |
| STOPS | 10 | 10 | 3 | 0.08 | +43 | +14.4 |
| BOMBING RUN | 2 | 2 | 2 | 0.06 | +47 | +23.4 |
| CATCH ODDS | 2 | 2 | 2 | 0.06 | -49 | -24.4 |
| CHARIOT NO STATIC JOB | 3 | 3 | 2 | 0.06 | -188 | -93.9 |
| FIRE AND FLEE | 2 | 2 | 2 | 0.06 | +34 | +16.9 |
| HUNT ADVANCE | 13 | 13 | 2 | 0.06 | +16 | +8.2 |
| PERIAPT WORTH | 2 | 2 | 2 | 0.06 | +106 | +53.0 |
| STAY WEIGHED | 2 | 2 | 2 | 0.06 | +34 | +17.2 |
| BLOWS WHERE AIMED | 19 | 18 | 1 | 0.03 | +57 | +56.9 |
| ELIXIR WORTH | 1 | 1 | 1 | 0.03 | +13 | +13.0 |
| FOCUS FIRE | 1 | 1 | 1 | 0.03 | +14 | +13.7 |
| HILL BY ITS CHANCE | 36 | 36 | 1 | 0.03 | +31 | +30.9 |
| HORN WORTH | 1 | 1 | 1 | 0.03 | +3 | +3.0 |
| JOINT CHARGE PLAN | 5 | 5 | 1 | 0.03 | +62 | +61.6 |
| KEEP FALLS | 1 | 1 | 1 | 0.03 | +22 | +22.0 |
| MOVE SPELL IN RANGE | 4 | 4 | 1 | 0.03 | +1 | +1.1 |
| NEEDED THERE | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| OPENS A LANE | 11 | 5 | 1 | 0.03 | +15 | +15.3 |
| SAFE SURE CHARGE | 1 | 1 | 1 | 0.03 | -105 | -105.2 |
| TURN WORTH | 17 | 17 | 1 | 0.03 | +18 | +18.0 |
| TWO OR MORE ARRIVE | 19 | 19 | 1 | 0.03 | +10 | +10.5 |
| ALREADY CARRIED | 1 | not checked | - | - | - | - |
| ARRIVAL HUNT | 6 | 6 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 45 | 45 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 30 | trace | - | - | - | - |
| CATCH FLIERS | 1 | not checked | - | - | - | - |
| CHAMPION TAKES THE CHALLENGE | 2 | 2 | 0 | 0.00 | - | - |
| CHARGER SLAIN LOST | 32 | 29 | 0 | 0.00 | - | - |
| CHARIOT WIZARD CAREFUL | 2 | 2 | 0 | 0.00 | - | - |
| CHEAP HELPER | 5 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 32 | not checked | - | - | - | - |
| DEFENSIVE FLOOR | 1 | 1 | 0 | 0.00 | - | - |
| EDGE GIVE GROUND | 17 | 16 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 415 | not checked | - | - | - | - |
| GIVES UP | 5 | 4 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 4 | 4 | 0 | 0.00 | - | - |
| GROUND FLIERS | 2 | not checked | - | - | - | - |
| HELPER ALREADY ASKED | 4 | not checked | - | - | - | - |
| HELPER UNSEEN | 27 | 26 | 0 | 0.00 | - | - |
| HUNT DROPPED | 5 | trace | - | - | - | - |
| HUNT KEPT | 8 | trace | - | - | - | - |
| HUNT RESULT | 17 | trace | - | - | - | - |
| HUNT THE GUNS | 19 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 4 | 4 | 0 | 0.00 | - | - |
| KEEPS ITS PREY | 2 | 2 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 21 | not checked | - | - | - | - |
| LURE BY WHAT IT DRAWS | 4 | 4 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 18 | 18 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 12 | 12 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 25 | trace | - | - | - | - |
| MOVE SPELL SPOT | 10 | not checked | - | - | - | - |
| NOT NEEDED | 32 | 32 | 0 | 0.00 | - | - |
| NOT TURNED | 401 | 401 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 44 | not checked | - | - | - | - |
| PLAN RESULT | 2834 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 13 | 13 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 16 | 16 | 0 | 0.00 | - | - |
| SCOUT SPOT | 28 | 28 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 16 | 16 | 0 | 0.00 | - | - |
| SECOND HUNTER | 5 | 5 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 8 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 9 | not checked | - | - | - | - |
| SET-UP MISSED | 1 | trace | - | - | - | - |
| SPELL CATCH ODDS | 1 | not checked | - | - | - | - |
| SPELL SETS UP CHARGE | 13 | not checked | - | - | - | - |
| SPELL WORTH | 93 | not checked | - | - | - | - |
| STABLE ROLE | 869 | 868 | 0 | 0.00 | - | - |
| WAR ENGINE CHARGES | 2 | 2 | 0 | 0.00 | - | - |

### Off best figure: jb-h2h-mine-b54c226-p2

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 13.94 | 14.64 | 52.9 |
| TURN GATE | gate | 0.69 | 0.56 | 41.1 |
| FALLBACK | gate | 0.56 | 0.61 | 35.8 |
| CHARGE NOW FIRST | rule | 0.22 | 0.58 | 48.3 |
| PATHS CROSS | rule | 0.08 | 0.22 | 34.7 |
| LONE CHARACTER SAFE SPOT | gate | 0.17 | 0.11 | 28.6 |
| CHAFF PASSED | rule | 0.14 | 0.11 | 3.1 |
| SURE CHARGE BEATS ADVANCE | rule | 0.14 | 0.11 | 19.4 |
| PIVOT GUARDS FLANK | rule | 0.11 | 0.11 | 18.5 |
| PURSUES BIG PREY | rule | 0.03 | 0.19 | 99.4 |
| WAR ENGINE JOBS | rule | 0.22 | - | 48.2 |
| AFTERMATH BAND | gate | 0.11 | 0.08 | 2.5 |
| BEST PRIZE | rule | 0.08 | 0.11 | 68.0 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.14 | 0.03 | 60.1 |
| CANNON PLANNED TARGET | rule | 0.14 | 0.03 | 21.2 |
| SUPPORT NARROWED | rule | 0.06 | 0.11 | 23.0 |
| SUPPORT REQUEST | gate | 0.11 | 0.06 | 101.0 |
| CHARGE NOW WEIGHED | rule | 0.08 | 0.06 | 46.7 |
| BIG CHARACTER SAFETY | rule | 0.11 | - | 10.7 |
| DEFENSIVE ARMY | rule | 0.03 | 0.08 | 44.4 |
| STANDS TO CAST | rule | 0.03 | 0.08 | 4.3 |
| BLOCKED WHEEL | rule | 0.06 | 0.03 | 22.4 |
| CARRIES OUT SET-UP | rule | 0.03 | 0.06 | 28.1 |
| MARCH ODDS | rule | 0.06 | 0.03 | 18.8 |
| CATCH ODDS | rule | - | 0.06 | 24.4 |
| CHARIOT NO STATIC JOB | rule | 0.06 | - | 93.9 |
| SAFER THAN THE JOB | rule | 0.06 | - | 13.5 |
| FACES THE THREAT | rule | 0.03 | - | 9.2 |
| FIGHT ORDER BAND | gate | - | 0.03 | 3.3 |
| LONE WIZARD HOLDS BACK | rule | - | 0.03 | 58.8 |
| NO REASON | gate | 0.03 | - | 10.1 |
| REDIRECT WEIGHED | rule | - | 0.03 | 31.6 |
| REFUSING RETIRES | rule | 0.03 | - | 0.6 |
| SAFE SURE CHARGE | rule | 0.03 | - | 105.2 |
| STOPS SHORT OF THE FLANK | rule | 0.03 | - | 6.6 |
| THROUGH LINE OF FIRE | rule | - | 0.03 | 323.4 |

### Plans: jb-h2h-mine-b54c226-p2

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 12.2 | 16% | 507 | 323 | 64% |
| Mine | charge | 2.8 | 53% | 272 | 233 | 85% |
| Mine | close in | 3.6 | 15% | 178 | 90 | 51% |
| Mine | hold | 4.7 | 31% | 306 | 0 | 0% |
| Mine | join | 0.6 | 95% | 21 | 0 | 0% |
| Mine | shoot | 8.2 | 60% | 280 | 706 | 252% |
| Mine | support | 4.5 | 90% | 30 | 0 | 0% |
| Opponent | advance | 14.3 | 16% | 400 | 295 | 74% |
| Opponent | charge | 4.6 | 56% | 378 | 438 | 116% |
| Opponent | close in | 6.3 | 26% | 366 | 159 | 44% |
| Opponent | hold | 4.4 | 36% | 333 | 0 | 0% |
| Opponent | join | 0.9 | 91% | 40 | 0 | 0% |
| Opponent | shoot | 5.9 | 60% | 200 | 390 | 195% |
| Opponent | support | 5.7 | 95% | 55 | 0 | 0% |

### Packages: hunt the guns, jb-h2h-mine-b54c226-p2

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.2 | 6 | 0 | 33% | 50% | 0% | 2.0 | 256 | 157 | 50% | 51 |
| Opponent | 0.4 | 13 | 2 | 36% | 64% | 0% | 2.4 | 277 | 177 | 64% | 77 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 122 | 0 | 0% | 81 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 222 |
| Dwarfen Mountain Holds | 0.2 | 1 | 0 | 100% | 100% | 0% | 2.0 | 460 | 453 | 100% | 60 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 36 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 22 |
| High Elf Realms | 0.8 | 3 | 0 | 33% | 67% | 0% | 2.0 | 252 | 163 | 67% | 0 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 374 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Ogre Kingdoms | 1.0 | 4 | 1 | 67% | 67% | 0% | 3.0 | 488 | 318 | 67% | 151 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 277 |
| Tomb Kings of Khemri | 1.2 | 6 | 0 | 0% | 33% | 0% | 2.0 | 122 | 32 | 33% | 13 |
| Vampire Counts | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 12 |
| Warriors of Chaos | 0.2 | 2 | 1 | 100% | 100% | 0% | 2.0 | 198 | 149 | 100% | 20 |
| Wood Elf Realms | 0.3 | 2 | 0 | 50% | 100% | 0% | 2.5 | 428 | 328 | 100% | 16 |

### Battle groups: jb-h2h-mine-b54c226-p2

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 10.9 | 20% | 48% | 12% | 40% | 29% | 16% | 9% | 47% | 0% |
| Mine | REDIRECT COUNTER | 2.5 | 27% | 52% | 16% | 25% | 29% | 0% | 14% | 57% | 0% |
| Opponent | COUNTER-CHARGE COVER | 7.7 | 20% | 73% | 15% | 0% | 30% | 6% | 6% | 57% | 0% |
| Opponent | REDIRECT COUNTER | 3.7 | 21% | 71% | 21% | 17% | 36% | 5% | 18% | 36% | 5% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: jb-h2h-mine-b54c226-p2

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 5 | 99 (5) | 99 | 0 | 0 | 20% | 2.8 | 0 (1) | 117 (4) | - | 151 (3) | 0 (2) |
| Mine | Chaff | 34 | 40 (34) | 6 | 34 | 69 | 38% | 2.6 | 49 (19) | 54 (7) | 11 (8) | 54 (23) | 9 (11) |
| Mine | Character | 123 | 32 (123) | 31 | 1 | 44 | 24% | 2.3 | 38 (35) | 38 (52) | 5 (9) | 43 (49) | 29 (47) |
| Mine | Clean-up | 21 | 49 (21) | 16 | 34 | 48 | 48% | 2.7 | 26 (5) | 56 (13) | 79 (3) | 97 (13) | 0 (8) |
| Mine | Fast | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Mine | Fast Hammer | 48 | 56 (48) | 33 | 23 | 45 | 23% | 2.7 | 48 (23) | 85 (16) | 30 (9) | 66 (29) | 42 (19) |
| Mine | Fragile | 5 | 26 (5) | 26 | 0 | 60 | 0% | 1.6 | - | 44 (3) | 0 (2) | 26 (5) | - |
| Mine | Hammer | 57 | 34 (57) | 24 | 9 | 46 | 23% | 2.5 | 21 (18) | 46 (29) | 22 (10) | 32 (38) | 37 (19) |
| Mine | Holder | 28 | 39 (28) | 3 | 36 | 23 | 39% | 3.2 | 35 (11) | 71 (8) | 7 (8) | 53 (18) | 14 (9) |
| Mine | Shooter | 41 | 65 (41) | 19 | 46 | 60 | 2% | 1.6 | 143 (5) | 67 (30) | 7 (6) | 87 (25) | 30 (16) |
| Mine | Support | 2 | 0 (2) | 0 | 0 | 0 | 100% | - | 0 (1) | 0 (1) | - | - | 0 (2) |
| Mine | War machine | 59 | 39 (59) | 39 | 0 | 58 | 2% | 1.2 | 6 (10) | 53 (37) | 14 (12) | 13 (10) | 44 (49) |
| Mine | Wizard | 22 | 8 (22) | 8 | 0 | 51 | 18% | 2.4 | 0 (7) | 37 (6) | 0 (3) | 0 (5) | 16 (11) |
| Opponent | Blocker | 2 | 0 (2) | 0 | 0 | 38 | 0% | 4.0 | - | 0 (2) | - | - | 0 (2) |
| Opponent | Chaff | 76 | 90 (76) | 37 | 53 | 41 | 34% | 2.8 | 95 (32) | 68 (19) | 105 (25) | 117 (54) | 26 (22) |
| Opponent | Character | 97 | 60 (97) | 60 | 0 | 24 | 26% | 2.5 | 71 (42) | 62 (41) | 7 (7) | 52 (62) | 81 (28) |
| Opponent | Clean-up | 19 | 27 (19) | 13 | 14 | 39 | 42% | 2.5 | 9 (9) | 55 (10) | - | 34 (14) | 5 (5) |
| Opponent | Early | 2 | 129 (2) | 129 | 0 | 0 | 0% | 5.5 | - | 129 (2) | - | 0 (1) | 259 (1) |
| Opponent | Fast Hammer | 48 | 34 (48) | 25 | 9 | 31 | 19% | 2.7 | 38 (22) | 3 (16) | 83 (10) | 32 (28) | 38 (20) |
| Opponent | Fragile | 5 | 142 (5) | 142 | 0 | 23 | 20% | 3.0 | - | 71 (3) | 255 (2) | 176 (4) | 0 (1) |
| Opponent | Hammer | 70 | 40 (70) | 35 | 4 | 40 | 29% | 3.0 | 55 (17) | 36 (42) | 37 (11) | 46 (43) | 30 (27) |
| Opponent | Holder | 35 | 102 (35) | 14 | 88 | 16 | 34% | 3.0 | 47 (6) | 98 (24) | 202 (5) | 126 (23) | 47 (12) |
| Opponent | Shooter | 33 | 85 (33) | 14 | 72 | 17 | 0% | 1.8 | 45 (8) | 106 (19) | 65 (6) | 113 (22) | 43 (11) |
| Opponent | Support | 3 | 28 (3) | 28 | 0 | 50 | 67% | 4.0 | 37 (2) | 0 (1) | - | 56 (1) | 0 (2) |
| Opponent | War machine | 24 | 64 (24) | 64 | 0 | 4 | 8% | 1.6 | 44 (6) | 71 (14) | 66 (4) | 14 (3) | 72 (21) |
| Opponent | Wizard | 26 | 35 (26) | 35 | 0 | 27 | 12% | 1.5 | 0 (10) | 107 (8) | 5 (6) | 76 (8) | 11 (16) |

### Charged fights: jb-h2h-mine-b54c226-p2

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 103 | 91 | 2.5 | 1.1 | 36 | 22 | +15 | 1 of 10 | 6 of 10 | +122 | +3 |
| Mine | Chaos Dwarfs | 4 | 69 | 223 | 2.0 | 1.1 | 112 | 0 | +112 | 5 of 8 | 6 of 8 | +398 | +71 |
| Mine | Dwarfen Mountain Holds | 4 | 439 | 136 | 1.2 | 1.0 | 109 | 45 | +64 | 1 of 5 | 3 of 5 | - | +64 |
| Mine | Empire of Man | 5 | 413 | 18 | 0.8 | 1.0 | 23 | 66 | -43 | 2 of 4 | 4 of 4 | - | -43 |
| Mine | Grand Cathay | 4 | 263 | 133 | 2.0 | 1.1 | 66 | 0 | +66 | 4 of 8 | 7 of 8 | +432 | +14 |
| Mine | High Elf Realms | 4 | 222 | 441 | 4.0 | 1.2 | 110 | 28 | +83 | 5 of 16 | 14 of 16 | +245 | +45 |
| Mine | Kingdom of Bretonnia | 1 | 0 | 357 | 5.0 | 1.0 | 71 | 94 | -23 | 1 of 5 | 4 of 5 | - | -23 |
| Mine | Lizardmen | 1 | 186 | 120 | 3.0 | 1.0 | 40 | 0 | +40 | 0 of 3 | 2 of 3 | - | +40 |
| Mine | Ogre Kingdoms | 1 | 0 | 278 | 2.0 | 1.0 | 139 | 17 | +122 | 0 of 2 | 1 of 2 | - | +122 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 332 | 4.0 | 1.2 | 83 | 14 | +69 | 1 of 4 | 4 of 4 | +45 | +77 |
| Mine | Skaven | 2 | 198 | 58 | 2.5 | 1.2 | 23 | 170 | -147 | 1 of 5 | 3 of 5 | -145 | -147 |
| Mine | Tomb Kings of Khemri | 1 | 274 | 393 | 4.0 | 1.0 | 98 | 108 | -10 | 2 of 4 | 3 of 4 | - | -10 |
| Mine | Vampire Counts | 3 | 0 | 314 | 3.0 | 1.4 | 105 | 35 | +70 | 1 of 9 | 8 of 9 | +173 | +18 |
| Mine | Warriors of Chaos | 1 | 0 | 0 | 2.0 | 1.0 | 0 | 99 | -99 | 0 of 2 | 2 of 2 | - | -99 |
| **Mine** | all armies | 36 | 203 | 187 | 2.4 | 1.1 | 79 | 41 | +38 | 24 of 85 | 67 of 85 | +191 | +15 |
| Opponent | Dwarfen Mountain Holds | 2 | 247 | 178 | 3.5 | 1.1 | 51 | 24 | +27 | 1 of 7 | 5 of 7 | -60 | +42 |
| Opponent | Empire of Man | 2 | 632 | 46 | 1.5 | 1.3 | 30 | 127 | -96 | 1 of 3 | 3 of 3 | +0 | -144 |
| Opponent | Grand Cathay | 2 | 300 | 934 | 2.5 | 1.8 | 374 | 0 | +374 | 3 of 5 | 4 of 5 | +351 | +408 |
| Opponent | Kingdom of Bretonnia | 1 | 175 | 390 | 5.0 | 1.0 | 78 | 0 | +78 | 2 of 5 | 5 of 5 | - | +78 |
| Opponent | Ogre Kingdoms | 3 | 156 | 395 | 6.0 | 1.1 | 66 | 21 | +45 | 7 of 18 | 8 of 18 | +0 | +51 |
| Opponent | Skaven | 1 | 661 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Tomb Kings of Khemri | 4 | 93 | 1021 | 3.8 | 1.3 | 272 | 42 | +231 | 7 of 15 | 10 of 15 | +339 | +191 |
| Opponent | Vampire Counts | 6 | 9 | 752 | 3.5 | 1.2 | 215 | 37 | +177 | 11 of 21 | 16 of 21 | +101 | +201 |
| Opponent | Warriors of Chaos | 8 | 8 | 302 | 2.5 | 1.1 | 121 | 8 | +113 | 6 of 20 | 18 of 20 | +148 | +107 |
| Opponent | Wood Elf Realms | 7 | 60 | 641 | 4.6 | 1.1 | 140 | 10 | +130 | 11 of 32 | 26 of 32 | +170 | +124 |
| **Opponent** | all armies | 36 | 127 | 539 | 3.5 | 1.2 | 154 | 22 | +132 | 49 of 126 | 95 of 126 | +173 | +122 |

### Effective charges: jb-h2h-mine-b54c226-p2

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 10 | 0 | 0 | 1 (net +0) | 5 (net +20) | 0 | 1 (net +72) | 3 | 14% (1 of 7) |
| Mine | Chaos Dwarfs | 8 | 2 (net +0) | 0 | 0 | 3 (net +100) | 0 | 2 (net +296) | 1 | 0% (0 of 7) |
| Mine | Dwarfen Mountain Holds | 5 | 0 | 0 | 1 (net +0) | 0 | 0 | 3 (net +147) | 1 | 25% (1 of 4) |
| Mine | Empire of Man | 4 | 0 | 0 | 1 (net -265) | 0 | 0 | 1 (net +0) | 2 | 50% (1 of 2) |
| Mine | Grand Cathay | 8 | 2 (net +0) | 0 | 1 (net +0) | 0 | 3 (net +177) | 2 (net +0) | 0 | 12% (1 of 8) |
| Mine | High Elf Realms | 16 | 0 | 0 | 3 (net +28) | 3 (net +62) | 3 (net +103) | 5 (net +124) | 2 | 21% (3 of 14) |
| Mine | Kingdom of Bretonnia | 5 | 0 | 0 | 1 (net +205) | 3 (net -116) | 0 | 0 | 1 | 25% (1 of 4) |
| Mine | Lizardmen | 3 | 0 | 0 | 0 | 1 (net +75) | 2 (net +22) | 0 | 0 | 0% (0 of 3) |
| Mine | Ogre Kingdoms | 2 | 0 | 0 | 0 | 1 (net +278) | 0 | 0 | 1 | 0% (0 of 1) |
| Mine | Orc & Goblin Tribes | 4 | 0 | 0 | 2 (net +139) | 0 | 0 | 0 | 2 | 100% (2 of 2) |
| Mine | Skaven | 5 | 0 | 0 | 1 (net -602) | 2 (net +26) | 0 | 2 (net -92) | 0 | 20% (1 of 5) |
| Mine | Tomb Kings of Khemri | 4 | 1 (net -431) | 0 | 0 | 0 | 1 (net +110) | 2 (net +142) | 0 | 0% (0 of 4) |
| Mine | Vampire Counts | 9 | 1 (net +0) | 0 | 3 (net +61) | 2 (net +62) | 2 (net +102) | 0 | 1 | 38% (3 of 8) |
| Mine | Warriors of Chaos | 2 | 0 | 0 | 0 | 1 (net -198) | 0 | 0 | 1 | 0% (0 of 1) |
| Opponent | Dwarfen Mountain Holds | 7 | 2 (net +12) | 0 | 3 (net +20) | 1 (net +55) | 1 (net +52) | 0 | 0 | 43% (3 of 7) |
| Opponent | Empire of Man | 3 | 1 (net -380) | 0 | 0 | 0 | 1 (net +0) | 1 (net +91) | 0 | 0% (0 of 3) |
| Opponent | Grand Cathay | 5 | 2 (net +691) | 0 | 2 (net +92) | 0 | 0 | 1 (net +304) | 0 | 40% (2 of 5) |
| Opponent | Kingdom of Bretonnia | 5 | 0 | 0 | 1 (net +95) | 1 (net +0) | 0 | 1 (net +115) | 2 | 33% (1 of 3) |
| Opponent | Ogre Kingdoms | 18 | 5 (net +98) | 0 | 1 (net +369) | 2 (net -128) | 0 | 3 (net +69) | 7 | 9% (1 of 11) |
| Opponent | Tomb Kings of Khemri | 15 | 2 (net +338) | 0 | 1 (net +347) | 3 (net +245) | 0 | 7 (net +196) | 2 | 8% (1 of 13) |
| Opponent | Vampire Counts | 21 | 5 (net +265) | 1 (net +297) | 5 (net +192) | 6 (net +81) | 1 (net +0) | 3 (net +219) | 0 | 24% (5 of 21) |
| Opponent | Warriors of Chaos | 20 | 2 (net +50) | 2 (net +189) | 2 (net +116) | 3 (net +56) | 2 (net +48) | 7 (net +177) | 2 | 11% (2 of 18) |
| Opponent | Wood Elf Realms | 32 | 3 (net +308) | 1 (net +666) | 3 (net +89) | 7 (net +153) | 1 (net +104) | 13 (net +86) | 4 | 11% (3 of 28) |

### Charged fights, damage counted: jb-h2h-mine-b54c226-p2

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 6 | 295 | 291 | -72 | 118 | 145 | -27 | -9.1 |
| Mine | Effective (55-75%) | 14 | 331 | 229 | -8 | 140 | 118 | +22 | +6.5 |
| Mine | 76-89% | 21 | 203 | 146 | +27 | 80 | 52 | +28 | +13.8 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 18 | 282 | 190 | +101 | 148 | 27 | +121 | +42.9 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 11 | 436 | 94 | +109 | 114 | 11 | +103 | +23.5 |
| Mine | No odds | 15 | 191 | 111 | +12 | 49 | 26 | +22 | +11.7 |
| Mine | All fights | 85 | 275 | 166 | +38 | 106 | 54 | +51 | +18.7 |
| Opponent | Long shot (under 50%) | 22 | 233 | 242 | +206 | 310 | 95 | +215 | +92.0 |
| Opponent | 50-54% | 4 | 518 | 274 | +335 | 335 | 0 | +335 | +64.7 |
| Opponent | Effective (55-75%) | 18 | 251 | 177 | +140 | 154 | 11 | +144 | +57.4 |
| Opponent | 76-89% | 23 | 248 | 180 | +98 | 135 | 43 | +91 | +36.8 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 36 | 292 | 188 | +142 | 177 | 33 | +144 | +49.5 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 6 | 460 | 104 | +42 | 57 | 26 | +31 | +6.8 |
| Opponent | No odds | 17 | 132 | 192 | +33 | 58 | 16 | +42 | +32.2 |
| Opponent | All fights | 126 | 261 | 194 | +132 | 172 | 39 | +134 | +51.2 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| jb-h2h-mine-b54c226-p2 | move | 453 | 93 (21%) | 66 (15%) | 49 (11%) | 311 (69%) |
| jb-h2h-mine-b54c226-p2 | objective | 359 | 49 (14%) | 36 (10%) | 41 (11%) | 269 (75%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0106, L0122, L2429, L2535, L2735 |
| Charmed Shield | Opponent | L0425, L0827, L0934, L1026, L1727, L1827, L1927 |
| Clockwork Compass | Mine | L1228 |
| Clockwork Compass | Opponent | L0512 |
| Elixir of Power | Mine | L1118, L1135, L1927 |
| Fistful of Laurels | Mine | L1827 |
| Fistful of Laurels | Opponent | L0918, L1118, L1418 |
| Horn of the Wild Hunt | Opponent | L3033 |
| Invocation of Nehek | Mine | L2429, L2535, L2735 |
| Invocation of Nehek | Opponent | L0425, L0827, L1727, L1827, L1927 |
| Opal Amulet | Mine | L1418, L1435 |
| Periapt of Soul Exchange | Mine | L2029, L2131 |
| Periapt of Soul Exchange | Opponent | L0721 |
| Ring of Doom | Mine | L0206, L0222, L1118, L1135, L1228, L1531 |
| Ring of Doom | Opponent | L0512, L1531, L2131, L3033 |
| Ring of Jet | Mine | L1026, L1118, L1135, L1228 |
| Ring of Jet | Opponent | L0512, L0810 |
| Standard of the Fell Warrior | Mine | L1323 |
| Storm Daemon (Renegade 2.0) | Mine | L2131 |
| Storm Daemon (Renegade 2.0) | Opponent | L0721 |
| Twice-Blessed Armour | Mine | L0721, L1026 |
| Twice-Blessed Armour | Opponent | L0307, L0810 |
| Witch Hunter's Ward | Mine | L0721, L0810, L0827 |
| Witch Hunter's Ward | Opponent | L0307 |

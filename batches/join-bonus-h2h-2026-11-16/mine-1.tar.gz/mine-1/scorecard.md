# Doctrine scorecard: jb-h2h-mine-b54c226-p1

### Scorecard: jb-h2h-mine-b54c226-p1

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0102 | 6 | 1 | Mine | no | 6 | - | 0 | 0 | 0 | 0 | 0 | 0 |
| L0102 | 6 | 1 | Opponent | no | 4 | 2 | 2 | 4 | 0 | 0 | 0 | 307 |
| L0118 | 4 | 1 | Mine | no | 2 | - | 0 | 0 | 0 | 0 | 0 | 322 |
| L0118 | 4 | 1 | Opponent | no | 2 | 2 | 1 | 3 | 0 | 0 | 0 | 268 |
| L0135 | 3 | 1 | Mine | no | 12 | 2 | 1 | 2 | 0 | 0 | 0 | 55 |
| L0135 | 3 | 1 | Opponent | no | 1 | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L0218 | 2 | 1 | Mine | - | - | 2 | 4 | 3 | 1 | 0 | 0 | 170 |
| L0218 | 2 | 1 | Opponent | - | - | 4 | 2 | 2 | 0 | 0 | 0 | 0 |
| L0235 | 1 | 1 | Mine | no | 0 | 2 | 1 | 4 | 1 | 0 | 0 | 170 |
| L0235 | 1 | 1 | Opponent | no | 2 | 2 | 2 | 2 | 0 | 0 | 0 | 126 |
| L0319 | 1 | 1 | Mine | no | 7 | 3 | 3 | 0 | 0 | 0 | 0 | 675 |
| L0319 | 1 | 1 | Opponent | no | 1 | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| L0405 | 3 | 1 | Mine | yes | 5 | 2 | 2 | 0 | 0 | 0 | 0 | 0 |
| L0405 | 3 | 1 | Opponent | yes | 0 | 4 | 1 | 0 | 0 | 0 | 0 | 1193 |
| L0421 | 1 | 1 | Mine | no | 0 | 2 | 6 | 0 | 0 | 0 | 0 | 0 |
| L0421 | 1 | 1 | Opponent | no | 2 | - | 1 | 3 | 0 | 0 | 0 | 355 |
| L0508 | 4 | 1 | Mine | no | 3 | - | 0 | 2 | 0 | 0 | 0 | 771 |
| L0508 | 4 | 1 | Opponent | no | 0 | 4 | 2 | 1 | 0 | 0 | 0 | 971 |
| L0524 | 2 | 1 | Mine | - | - | 2 | 1 | 1 | 0 | 0 | 0 | 560 |
| L0524 | 2 | 1 | Opponent | - | - | 4 | 3 | 2 | 0 | 0 | 0 | 0 |
| L0612 | 6 | 1 | Mine | no | 2 | - | 1 | 3 | 0 | 0 | 0 | 615 |
| L0612 | 6 | 1 | Opponent | no | 5 | 3 | 2 | 0 | 0 | 0 | 0 | 330 |
| L0628 | 4 | 1 | Mine | no | 0 | 5 | 2 | 1 | 0 | 0 | 0 | 1252 |
| L0628 | 4 | 1 | Opponent | no | 1 | - | 0 | 1 | 0 | 0 | 0 | 462 |
| L0717 | 3 | 1 | Mine | no | 0 | 2 | 1 | 1 | 1 | 0 | 0 | 420 |
| L0717 | 3 | 1 | Opponent | yes | 5 | 2 | 4 | 1 | 1 | 0 | 0 | 175 |
| L0733 | 1 | 1 | Mine | no | 8 | 1 | 3 | 1 | 1 | 0 | 0 | 375 |
| L0733 | 1 | 1 | Opponent | no | 0 | 3 | 0 | 2 | 0 | 0 | 0 | 0 |
| L0823 | 1 | 1 | Mine | no | 0 | 2 | 1 | 0 | 1 | 0 | 0 | 560 |
| L0823 | 1 | 1 | Opponent | no | 1 | 2 | 3 | 3 | 2 | 0 | 0 | 315 |
| L0913 | 1 | 1 | Mine | no | 2 | 1 | 2 | 1 | 0 | 0 | 0 | 609 |
| L0913 | 1 | 1 | Opponent | no | 2 | 2 | 4 | 0 | 0 | 0 | 0 | 140 |
| L0930 | 6 | 1 | Mine | no | 1 | 5 | 2 | 1 | 0 | 0 | 0 | 629 |
| L0930 | 6 | 1 | Opponent | no | 6 | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L1021 | 1 | 1 | Mine | no | 0 | 2 | 4 | 0 | 0 | 0 | 0 | 330 |
| L1021 | 1 | 1 | Opponent | no | 1 | - | 0 | 4 | 1 | 0 | 0 | 355 |
| L1114 | 4 | 1 | Mine | no | 1 | 2 | 3 | 1 | 0 | 0 | 0 | 427 |
| L1114 | 4 | 1 | Opponent | no | 0 | 4 | 1 | 3 | 0 | 0 | 0 | 677 |
| L1131 | 3 | 1 | Mine | no | 2 | - | 2 | 0 | 0 | 0 | 0 | 330 |
| L1131 | 3 | 1 | Opponent | no | 0 | 6 | 1 | 2 | 0 | 0 | 0 | 365 |
| L1224 | 6 | 1 | Mine | no | 5 | 2 | 3 | 0 | 0 | 0 | 0 | 330 |
| L1224 | 6 | 1 | Opponent | no | 2 | 2 | 3 | 2 | 1 | 0 | 0 | 0 |
| L1319 | 5 | 1 | Mine | yes | - | 3 | 4 | 0 | 0 | 0 | 0 | 302 |
| L1319 | 5 | 1 | Opponent | no | - | 2 | 4 | 1 | 0 | 0 | 0 | 161 |
| L1335 | 3 | 1 | Mine | no | 1 | 2 | 3 | 1 | 0 | 0 | 0 | 140 |
| L1335 | 3 | 1 | Opponent | no | 0 | 4 | 1 | 3 | 0 | 0 | 0 | 126 |
| L1431 | 3 | 1 | Mine | yes | 5 | 2 | 5 | 0 | 0 | 0 | 0 | 177 |
| L1431 | 3 | 1 | Opponent | no | 0 | - | 3 | 2 | 1 | 0 | 0 | 732 |
| L1527 | 3 | 1 | Mine | yes | 4 | 3 | 2 | 0 | 1 | 0 | 0 | 0 |
| L1527 | 3 | 1 | Opponent | no | 0 | 3 | 3 | 1 | 0 | 0 | 0 | 0 |
| L1625 | 5 | 1 | Mine | yes | - | 4 | 2 | 2 | 1 | 0 | 0 | 200 |
| L1625 | 5 | 1 | Opponent | yes | - | 1 | 2 | 3 | 0 | 0 | 0 | 0 |
| L1723 | 1 | 1 | Mine | no | 5 | 1 | 3 | 0 | 2 | 0 | 0 | 233 |
| L1723 | 1 | 1 | Opponent | yes | 7 | 2 | 3 | 1 | 1 | 0 | 0 | 0 |
| L1823 | 5 | 1 | Mine | yes | - | - | 3 | 0 | 0 | 0 | 0 | 234 |
| L1823 | 5 | 1 | Opponent | yes | - | 1 | 3 | 2 | 2 | 0 | 0 | 0 |
| L1923 | 3 | 1 | Mine | no | 0 | 2 | 8 | 0 | 1 | 0 | 0 | 0 |
| L1923 | 3 | 1 | Opponent | no | 2 | 2 | 3 | 0 | 0 | 0 | 0 | 0 |
| L2025 | 3 | 1 | Mine | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 650 |
| L2025 | 3 | 1 | Opponent | no | 13 | 2 | 6 | 1 | 0 | 0 | 0 | 0 |
| L2127 | 3 | 1 | Mine | no | 0 | 4 | 4 | 2 | 0 | 0 | 0 | 145 |
| L2127 | 3 | 1 | Opponent | no | 5 | 2 | 4 | 3 | 0 | 0 | 0 | 0 |
| L2231 | 5 | 1 | Mine | yes | - | 2 | 3 | 0 | 0 | 0 | 0 | 0 |
| L2231 | 5 | 1 | Opponent | no | - | 2 | 4 | 1 | 2 | 0 | 0 | 541 |
| L2335 | 1 | 1 | Mine | no | 10 | 2 | 6 | 1 | 2 | 0 | 0 | 185 |
| L2335 | 1 | 1 | Opponent | no | 2 | 3 | 5 | 1 | 1 | 0 | 0 | 0 |
| L2531 | 5 | 1 | Mine | yes | - | 4 | 1 | 3 | 0 | 0 | 0 | 0 |
| L2531 | 5 | 1 | Opponent | no | - | 3 | 1 | 3 | 0 | 0 | 0 | 0 |
| L2730 | 6 | 1 | Mine | no | 0 | 1 | 3 | 4 | 0 | 0 | 0 | 0 |
| L2730 | 6 | 1 | Opponent | no | 6 | 3 | 2 | 0 | 0 | 0 | 0 | 0 |
| L2934 | 6 | 1 | Mine | no | 5 | 2 | 7 | 0 | 1 | 0 | 0 | 0 |
| L2934 | 6 | 1 | Opponent | no | 0 | 2 | 4 | 2 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 24% | 3.0 | 2.4 | 2.7 | 1.0 | 0.4 | 0.0 | 0.0 | 301.8 |
| **Average** | | | Opponent | 15% | 2.4 | 2.6 | 2.5 | 1.7 | 0.3 | 0.0 | 0.0 | 211.1 |

### KPIs: jb-h2h-mine-b54c226-p1

Rules off - Opponent only: JOINS A FRIEND.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 28% (48 of 174) | 3% (5 of 180) | 15% (53 of 354) |
| Winner chose to follow up after the loser gave ground |  | 95% (53 of 56); on the table 95% | 98% (63 of 64); on the table 100% | 97% (116 of 120); on the table 98% |
| Winner chose to pursue after the loser fell back in good order |  | 100% (6 of 6); on the table 100% | 90% (9 of 10); on the table 90% | 94% (15 of 16); on the table 94% |
| Winner chose to pursue after the loser fled |  | 67% (29 of 43); on the table 70% | 92% (36 of 39); on the table 92% | 79% (65 of 82); on the table 80% |
| Winner chose to follow up or pursue (all three) |  | 84% (88 of 105); on the table 85% | 96% (108 of 113); on the table 96% | 90% (196 of 218); on the table 91% |
| Magic missiles tried each own turn | 50%+ | 33% (109 of 330) | 31% (66 of 210) | 32% (175 of 540) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 47% (109 of 233) | 42% (66 of 157) | 45% (175 of 390) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 52% (13 of 25) | 73% (40 of 55) | 66% (53 of 80) |
| Points that never fought | lower | 40% (28706 of 71484) | 38% (27352 of 71889) | 39% (56058 of 143373) |
|   infantry points that never fought | lower | 56% (9458 of 16863) | 55% (7356 of 13348) | 56% (16814 of 30211) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 56% (156 of 279) | 58% (170 of 295) | 57% (326 of 574) |
| Bound items with a magic missile used (at least once a game) |  | 95% (21 of 22); 2.1 uses a game | 80% (16 of 20); 1.3 uses a game | 88% (37 of 42); 1.7 uses a game |
| Bound items with another spell used |  | 69% (11 of 16); 0.7 uses a game | 25% (2 of 8); 0.1 uses a game | 54% (13 of 24); 0.4 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 47% (9 of 19); 0.2 uses a game | 67% (8 of 12); 0.2 uses a game | 55% (17 of 31); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 49% (29454 of 59666) | 53% (33050 of 62699) | 51% (62504 of 122365) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.9 (30%) | 1.4 (36%) | 3.3 (33%) |
| MARCHED: its unit marched | 0.9 (15%) | 0.5 (12%) | 1.4 (14%) |
| CHARGED: its unit charged | 0.5 (8%) | 0.0 (1%) | 0.5 (5%) |
| IN COMBAT: engaged in combat | 1.3 (22%) | 0.4 (11%) | 1.8 (18%) |
| REAR RANK: in a rear rank | 0.1 (2%) | 0.5 (12%) | 0.6 (6%) |
| NO CASTS LEFT: every cast used on other spells | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | 0.7 (11%) | 1.0 (26%) | 1.7 (17%) |
| OFF THE TABLE: off the table or not arrived | 0.7 (11%) | 0.0 (0%) | 0.7 (7%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.4 | 1.6 | 1.4 | 4.9 | 0.6 | 1.7 |
| not cast | 3.6 | 2.7 | 3.3 | 10.1 | 1.8 | 22.3 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) | 0.0 (0%) | 1.2 (6%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.0 (37%) | 0.3 (10%) | 3.3 (33%) | 0.3 (19%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.4 (14%) | 0.3 (16%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.5 (5%) | 0.0 (2%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.1 (2%) | 0.2 (9%) | 0.4 (11%) | 1.8 (18%) | 0.3 (17%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.2 (5%) | 0.3 (12%) | 0.6 (17%) | 0.6 (6%) | 0.0 (0%) | 0.0 (0%) |
| NO CASTS LEFT: every cast used on other spells | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.4 (2%) |
| GONE: slain | 0.9 (26%) | 0.4 (15%) | 0.6 (19%) | 1.7 (17%) | 0.0 (2%) | 2.8 (12%) |
| OFF THE TABLE: off the table or not arrived | 0.2 (5%) | 0.1 (5%) | 0.1 (3%) | 0.7 (7%) | 0.0 (0%) | 0.8 (4%) |
| STUPIDITY: Stupidity | 0.1 (3%) | 0.1 (2%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.5 (2%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.3 (12%) | 0.0 (0%) | 0.0 (0%) | 0.8 (44%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.1 (58%) | 0.2 (7%) | 1.2 (38%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 16.7 (75%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.1 a game | 0.4 a game | 0.8 a game |
| stood (cast and not dispelled) | 74% (26 of 35) | 67% (10 of 15) | 72% (36 of 50) |
| the unit moved after it | 73% (19 of 26) | 60% (6 of 10) | 69% (25 of 36) |
| it charged on its next turn | 0% (0 of 26) | 0% (0 of 10) | 0% (0 of 36) |
| the enemy charged it first | 12% (3 of 26) | 10% (1 of 10) | 11% (4 of 36) |
| it fought by the end of its next turn | 8% (2 of 26) | 10% (1 of 10) | 8% (3 of 36) |
| it moved out of a charge the enemy had planned (not charged first) | 8% (2 of 26) | 10% (1 of 10) | 8% (3 of 36) |
| none of these (no charge, no fight, no charge escaped) | 81% (21 of 26) | 80% (8 of 10) | 81% (29 of 36) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 63% (579 of 914) | 59% (350 of 594) | 62% (929 of 1508) |
|   cavalry | 60% (49 of 82) | 69% (83 of 120) | 65% (132 of 202) |
|   character | 48% (55 of 115) | 28% (31 of 110) | 38% (86 of 225) |
|   chariot | 48% (44 of 92) | 71% (29 of 41) | 55% (73 of 133) |
|   infantry | 60% (190 of 316) | 60% (143 of 240) | 60% (333 of 556) |
|   monster | 61% (22 of 36) | 24% (4 of 17) | 49% (26 of 53) |
|   war machine | 80% (219 of 273) | 91% (60 of 66) | 82% (279 of 339) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.8 (30%) | 1.6 (24%) | 4.4 (27%) |
| CHARGED: it charged | 1.2 (13%) | 1.5 (22%) | 2.7 (17%) |
| FLEEING: it fled or was fleeing | 0.2 (2%) | 0.1 (2%) | 0.3 (2%) |
| IN COMBAT: it fought this turn or the last | 0.7 (8%) | 0.3 (5%) | 1.0 (6%) |
| MOVED: a war machine that moved | 0.1 (1%) | 0.0 (0%) | 0.1 (0%) |
| NO TARGET IN RANGE | 1.6 (17%) | 1.4 (20%) | 2.9 (18%) |
| ONLY IN COMBAT: the only targets were in combat | 0.5 (6%) | 0.4 (6%) | 0.9 (6%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.7 (18%) | 1.2 (18%) | 2.9 (18%) |
| SHELTERED: the target was sheltered | 0.3 (3%) | 0.2 (2%) | 0.4 (3%) |
| OTHER BAR | 0.3 (3%) | 0.1 (1%) | 0.4 (2%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 5.4 | 1.4 | 80% | 4.7 pts | 25 pts |
| character | 3.1 | 0.6 | 87% | 2.3 pts | 7 pts |
| chariot | 2.1 | 1.1 | 74% | 10.2 pts | 22 pts |
| infantry | 13.2 | 5.2 | 73% | 9.0 pts | 119 pts |
| monster | 0.8 | 0.2 | 79% | 4.9 pts | 4 pts |
| war machine | 7.8 | 5.6 | 65% | 21.0 pts | 162 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.5 | 5.6 | 5.0 |
| Charges that made contact a game | 3.5 | 4.2 | 3.8 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.00 declared, 0.76 contact (21 units) | 0.36 declared, 0.29 contact (14 units) | 0.74 declared, 0.57 contact (35 units) |
|   per unit a game, units carrying another wizard (or one alone) | 1.00 declared, 0.80 contact (5 units) | 1.12 declared, 0.75 contact (8 units) | 1.08 declared, 0.77 contact (13 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.55 declared, 0.43 contact (246 units) | 0.66 declared, 0.50 contact (282 units) | 0.61 declared, 0.47 contact (528 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 51% (36 of 70) | 62% (13 of 21) | 50% (4 of 8) | 54% (53 of 99) |
| Character in a unit | 89% (32 of 36) | 79% (19 of 24) | 100% (3 of 3) | 86% (54 of 63) |
| Character on its own | 75% (38 of 51) | 42% (15 of 36) | 27% (17 of 63) | 47% (70 of 150) |
| Chariot | 69% (11 of 16) | 60% (6 of 10) | - | 65% (17 of 26) |
| Infantry | 54% (48 of 89) | 33% (12 of 36) | 50% (1 of 2) | 48% (61 of 127) |
| Monster | 66% (21 of 32) | 70% (7 of 10) | - | 67% (28 of 42) |
| Monstrous | 55% (6 of 11) | 36% (5 of 14) | - | 44% (11 of 25) |
| War Machines | 76% (31 of 41) | 100% (1 of 1) | - | 76% (32 of 42) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 6 | 86% (12 of 14); on the table 86% | 32% (44 of 138) | 44% | 55% (18 of 33) | 100% (9 of 9); 4.2 uses a game | 100% (3 of 3); 1.2 uses a game | 89% (8 of 9); 1.3 uses a game |
| Chaos Dwarfs | 3 | 100% (11 of 11); on the table 100% | 29% (7 of 24) | 35% | 38% (9 of 24) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Dwarfen Mountain Holds | 5 | 88% (14 of 16); on the table 88% | - | 57% | 76% (31 of 41) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 6 | 77% (10 of 13); on the table 77% | 31% (11 of 36) | 52% | 62% (40 of 64) | 0.0 uses a game | 100% (2 of 2); 1.0 uses a game | 25% (1 of 4); 0.2 uses a game |
| Grand Cathay | 5 | 93% (13 of 14); on the table 100% | 33% (36 of 108) | 50% | 48% (21 of 44) | 100% (12 of 12); 9.4 uses a game | 100% (1 of 1); 0.2 uses a game | 40% (2 of 5); 0.4 uses a game |
| High Elf Realms | 6 | 75% (18 of 24); on the table 75% | 33% (10 of 30) | 28% | 35% (17 of 49) | 100% (5 of 5); 3.0 uses a game | 39% (7 of 18); 2.3 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | 100% (1 of 1); on the table 100% | - | 29% | 67% (4 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Lizardmen | 2 | 100% (4 of 4); on the table 100% | - | 42% | 57% (8 of 14) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 3 | 83% (5 of 6); on the table 83% | 25% (3 of 12) | 45% | 57% (12 of 21) | 67% (2 of 3); 2.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 3 | 100% (8 of 8); on the table 100% | 8% (3 of 36) | 4% | 67% (16 of 24) | 0.0 uses a game | 0.0 uses a game | 67% (2 of 3); 0.7 uses a game |
| Skaven | 4 | 100% (6 of 6); on the table 100% | 43% (13 of 30) | 36% | 56% (19 of 34) | 100% (3 of 3); 2.0 uses a game | 0.0 uses a game | 50% (2 of 4); 0.5 uses a game |
| Tomb Kings of Khemri | 6 | 93% (26 of 28); on the table 93% | 8% (1 of 12) | 30% | 37% (11 of 30) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 8 | 90% (35 of 39); on the table 92% | 43% (23 of 54) | 37% | 62% (31 of 50) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 8 | 94% (15 of 16); on the table 94% | 37% (11 of 30) | 38% | 72% (53 of 74) | 100% (4 of 4); 1.5 uses a game | 0.0 uses a game | 50% (1 of 2); 0.1 uses a game |
| Wood Elf Realms | 6 | 100% (18 of 18); on the table 100% | 43% (13 of 30) | 42% | 55% (36 of 66) | 33% (2 of 6); 1.3 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (jb-h2h-mine-b54c226-p1, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 44% (35) | 47% (37) | 45% (72) |
| ...free all their last turn and able to turn (per game) | 0.50 | 0.64 | 1.14 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.28 | 0.08 | 0.36 |
| ...with the charger already in that arc before they moved (per game) | 0.39 | 0.33 | 0.72 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 2.25 | 1.31 | 3.56 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 1.00 | 0.56 | 1.56 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 5.08 | 5.97 | 11.06 |

### Quality by phase: jb-h2h-mine-b54c226-p1

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.1 | 3.4 |
| Strategy | Charge objectives carried out (made contact) | 58% (76 of 131) | 50% (81 of 163) |
| Strategy | Shoot objectives carried out (shot that target) | 50% (201 of 404) | 61% (122 of 201) |
| Strategy | Close-in objectives charged next turn | 16% (27 of 169) | 20% (40 of 204) |
| Strategy | Support requests answered (helper made contact too) | 62% (13 of 21) | 55% (17 of 31) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 50% (1 of 2) | 100% (3 of 3) |
| Strategy | Hexes on a unit its side charged or shot that turn | 78% (14 of 18) | 59% (10 of 17) |
| Strategy | Joined characters whose unit fought | 29% (15 of 52) | 40% (17 of 42) |
| Strategy | Lone characters that fought | 78% (73 of 94) | 80% (75 of 94) |
| Movement | Charges halted short of contact | 0.1 | 0.1 |
| Movement | Idle units | 1.0 | 1.7 |
| Movement | Points that never moved of their own | 301.8 | 211.1 |
| Movement | Fights charged into per game | 3.1 | 3.5 |
| Movement | Charges with odds: long shots (under 50%) | 14 of 94, net +162 | 14 of 106, net +52 |
| Movement | Charges with odds: sweet spot (55-75%) | 13 of 94, net +227 | 28 of 106, net +42 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 6 of 94, net +95 | 3 of 106, net +123 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 30 of 94, net +68 | 29 of 106, net +125 |
| Shooting | Shots by shooting units (incl. breath weapons) | 10.9 | 9.1 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 40% (158 of 391) | 44% (143 of 328) |
| Shooting | Points destroyed by shooting units | 60.8 | 39.2 |
| Shooting | War machine shots | 6.1 | 1.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 46% (100 of 219) | 43% (26 of 60) |
| Shooting | Points destroyed by war machines | 56.1 | 25.3 |
| Magic | Magic missiles cast | 2.1 | 1.1 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 41% (30 of 74) | 42% (17 of 40) |
| Magic | Wounds caused by magic missiles | 5.0 | 1.4 |
| Magic | Wounds caused by other spells | 1.5 | 0.7 |
| Magic | Points destroyed by magic (all spells) | 106.5 | 23.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.4 / 0.6 / 0.7 / 0.3 | 1.6 / 0.6 / 0.4 / 0.2 |
| Combat | Points destroyed in combat | 353.7 | 320.8 |
| Combat | Points run down | 121.4 | 145.7 |
| Combat | Net points per charged fight, damage counted | +83 | +75 |
| Combat | Net per 100 charger points, damage counted | +28.6 | +29.8 |
| Combat | First round won (charged fights) | 68% | 72% |
| Combat | Net points per charged fight | +93 | +70 |
| Combat | Net points per supported fight / lone fight | +242 / +68 | +176 / +49 |
| Combat | Charged fights on a top-3 enemy unit | 44 of 111 | 51 of 126 |
| Game | Points lost | 657.2 | 768.7 |
| Game | VP from objectives | 612.5 | 622.5 |
| Game | Lone holders (player turns) | 3.0 | 2.4 |

- Mine won / drew / lost: 15 / 3 / 18 of 36 ended games (of 36); mean margin (Mine - Opponent) +80 VP
- The side that went first won 12 of 33 games with a winner
- Points traded per game (both sides' losses): 1426
- Games not ended: 0; findings 1, warnings 0

### Opponent rules: jb-h2h-mine-b54c226-p1

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.6 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| ALREADY CARRIED | 0.0 | +0.0 | 10.3 | 3.6 | - | - | - | - |
| ARRIVAL HUNT | - | - | - | - | 0.0 | +0.2 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.1 | +0.0 | 0.0 | 17.9 | 0.3 | +0.0 | 0.0 | 2.6 |
| BACKUP TARGETS | 0.7 | +7.6 | 0.0 | 3.5 | 1.2 | +11.8 | 0.0 | 39.8 |
| BEST FACING | 1.0 | +36.4 | 0.0 | 54.2 | 0.6 | +27.2 | 0.0 | 11.6 |
| BEST FIRST | 5.0 | +246.4 | 153.5 | 66.2 | 4.2 | +191.9 | 101.0 | 58.1 |
| BEST OVERALL | 0.7 | +64.4 | 0.0 | 26.2 | 0.5 | +36.5 | 0.0 | 9.9 |
| BEST PREY | 0.9 | +25.1 | 10.9 | 24.2 | 1.0 | +51.8 | 46.2 | 27.3 |
| BEST PRIZE | - | - | - | - | 0.1 | +0.2 | 1.5 | 0.0 |
| BIG CHARACTER SAFETY | 0.2 | -0.2 | 0.0 | 15.0 | 0.1 | -0.0 | 0.0 | 0.0 |
| BLOCKED CHARGE SKIPPED | 0.1 | +0.0 | 2.9 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| BLOCKED WHEEL | 0.3 | +8.2 | 0.0 | 15.3 | 0.1 | +0.0 | 0.0 | 0.0 |
| BLOWS WHERE AIMED | 0.3 | -45.8 | 44.3 | 0.0 | 0.2 | -27.2 | 23.6 | 8.0 |
| BOMBING RUN | 0.1 | +2.5 | 4.0 | 0.0 | - | - | - | - |
| BOUND ASSAILMENT | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CANNON PLAN MISSED | 0.9 | +0.0 | 132.2 | 15.0 | 0.1 | +0.0 | 10.3 | 0.0 |
| CANNON PLANNED TARGET | 4.8 | +149.1 | 328.4 | 64.0 | 1.3 | +27.3 | 39.4 | 7.9 |
| CANNON SIGHT KEPT | 1.0 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT COUNTER | 0.1 | -0.1 | 28.0 | 0.0 | 0.1 | +0.0 | 9.1 | 0.0 |
| CARRIES OUT SET-UP | 0.1 | +0.0 | 38.3 | 0.0 | 0.1 | -4.8 | 14.7 | 0.0 |
| CAST JOB | 0.7 | +27.5 | 33.5 | 29.7 | 0.4 | +7.7 | 16.6 | 7.8 |
| CASTER AWAY FROM SCREEN | 0.4 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.4 | +37.0 | 20.8 | 0.0 | 0.1 | +4.1 | 5.7 | 4.4 |
| CASTS AFTER FRIENDS | 0.7 | +0.0 | 0.0 | 40.0 | 0.3 | +0.0 | 0.0 | 7.6 |
| CASTS FROM BEHIND | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.0 | +0.5 | 0.0 | 0.0 | 0.0 | +0.3 | 0.0 | 0.0 |
| CATCH ODDS | 0.1 | +6.8 | 0.0 | 0.0 | 0.1 | +1.8 | 0.0 | 0.0 |
| CHAFF PASSED | 0.2 | -0.1 | 0.0 | 3.5 | 0.1 | -0.5 | 2.9 | 3.8 |
| CHARGE BAND | 0.1 | +0.0 | 2.7 | 0.0 | 0.2 | +0.0 | 35.8 | 0.0 |
| CHARGE NOW FIRST | 2.4 | +0.0 | 300.5 | 96.1 | 2.6 | +0.0 | 224.4 | 57.6 |
| CHARGE NOW WEIGHED | 0.4 | -23.8 | 8.3 | 11.4 | 0.6 | -89.0 | 9.5 | 21.6 |
| CHARGER SLAIN LOST | 0.6 | -15.6 | 99.3 | 13.9 | 0.8 | -16.1 | 66.0 | 12.3 |
| CHARIOT NO STATIC JOB | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHARIOT WIZARD CAREFUL | 0.1 | -3.3 | 18.0 | 0.0 | 0.1 | -0.0 | 0.0 | 0.0 |
| CHEAP HELPER | 0.1 | +0.0 | 11.3 | 1.7 | 0.1 | +0.0 | 4.3 | 1.9 |
| COMBAT PIVOT | 0.8 | +0.0 | 25.2 | 25.8 | 0.5 | +0.0 | 13.1 | 89.8 |
| CONTINUE AHEAD WEIGHED | - | - | - | - | 0.1 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | 0.6 | +95.7 | 20.7 | 24.7 | 0.3 | +63.5 | 6.0 | 15.2 |
| COUNTER-CHARGE COVER | 9.2 | +806.0 | 0.0 | 180.1 | 7.6 | +764.3 | 0.0 | 207.6 |
| DEFENSIVE ARMY | 0.2 | +0.0 | 27.4 | 2.8 | 0.1 | +0.0 | 0.0 | 0.0 |
| DEFENSIVE FLOOR | 0.0 | +1.3 | 4.7 | 0.0 | - | - | - | - |
| EDGE GIVE GROUND | 0.1 | +4.1 | 7.4 | 2.4 | 0.1 | +1.3 | 21.1 | 0.0 |
| ELIXIR WORTH | - | - | - | - | 0.1 | +2.1 | 0.0 | 9.7 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 2.2 | +177.5 | 0.0 | 83.3 | 1.3 | +112.3 | 0.0 | 31.6 |
| FALLBACK BY WORTH | 4.3 | +84.5 | 0.0 | 47.5 | 5.2 | +66.8 | 0.0 | 46.4 |
| FIGHT LIFT | 0.1 | +0.2 | 1.7 | 0.0 | - | - | - | - |
| FIRE AND FLEE | 0.1 | +1.6 | 0.0 | 0.0 | 0.0 | +0.1 | 0.0 | 3.9 |
| FLANK NOT WEIGHED | 5.1 | +0.0 | 0.0 | 145.2 | 5.8 | +0.0 | 0.0 | 178.0 |
| FOCUS FIRE | 0.1 | +3.6 | 0.8 | 1.8 | 0.0 | +0.3 | 0.8 | 0.0 |
| FOLLOW UP WEIGHED | 0.9 | +104.1 | 0.0 | 22.1 | 1.1 | +119.9 | 0.0 | 48.2 |
| FRIENDS SHOTS CHECKED | 0.3 | +26.6 | 0.0 | 1.9 | 0.2 | +7.4 | 0.0 | 0.0 |
| GIVES UP | - | - | - | - | 0.1 | -0.3 | 0.0 | 7.9 |
| GIVES UP ITS SCREEN | 0.1 | -0.7 | 7.1 | 4.2 | 0.0 | -0.1 | 0.0 | 0.0 |
| GROUND FLIERS | 0.0 | +0.5 | 0.0 | 0.0 | 0.0 | +0.5 | 0.0 | 0.0 |
| HELPER ALREADY ASKED | - | - | - | - | 0.0 | +0.0 | 4.9 | 0.0 |
| HELPER UNSEEN | 0.1 | +0.0 | 35.6 | 0.0 | 0.4 | +0.0 | 25.8 | 29.0 |
| HILL BY ITS CHANCE | - | - | - | - | 0.1 | -11.4 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.8 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 7.3 | -133.7 | 448.8 | 154.5 | 9.1 | -162.3 | 321.8 | 244.6 |
| HORN WORTH | - | - | - | - | 0.0 | +0.5 | 0.0 | 0.0 |
| HUNT ADVANCE | 0.1 | +1.6 | 0.0 | 0.0 | 0.1 | +7.8 | 0.0 | 2.9 |
| HUNT DROPPED | - | - | - | - | 0.1 | +0.0 | 3.5 | 5.2 |
| HUNT IN PAIRS | 0.5 | +18.7 | 0.0 | 0.0 | 0.4 | +25.6 | 0.0 | 16.9 |
| HUNT KEPT | 0.0 | +0.8 | 0.0 | 0.0 | 0.1 | +0.6 | 0.0 | 0.0 |
| HUNT RESULT | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +13.2 | 3.5 | 7.7 |
| HUNT THE GUNS | 0.0 | +10.7 | 0.0 | 0.0 | 0.2 | +66.9 | 2.8 | 4.1 |
| INVITES THE FIGHT | 1.4 | +28.8 | 63.1 | 22.7 | 1.8 | +27.3 | 51.2 | 31.4 |
| JOINS A FRIEND | 1.7 | +10.2 | 91.6 | 16.4 | - | - | - | - |
| JOINT CHARGE PLAN | 0.1 | +2.7 | 0.0 | 0.0 | 0.2 | +8.8 | 6.1 | 0.0 |
| JOINT KNOWS CHALLENGE | 0.0 | -0.4 | 10.9 | 0.0 | 0.1 | -3.7 | 10.3 | 16.1 |
| KEEP FALLS | 0.0 | +0.4 | 0.0 | 0.0 | - | - | - | - |
| KEEPS ITS TARGET | 1.7 | +50.0 | 220.5 | 51.9 | 1.9 | +58.3 | 125.9 | 50.5 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KILLS COUNT | 1.5 | +56.4 | 130.3 | 43.7 | 1.9 | +78.7 | 116.6 | 52.4 |
| KILLS COUNT NEXT TURN | 4.9 | +170.8 | 182.1 | 101.0 | 6.3 | +262.3 | 205.5 | 175.8 |
| LONE CHARACTER SAFE SPOT | 0.4 | +29.0 | 8.5 | 0.0 | 0.3 | +6.4 | 0.0 | 10.7 |
| LONE WIZARD HOLDS BACK | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 16.1 |
| LONE WIZARD KEPT IN | 0.7 | +49.1 | 0.0 | 0.0 | 0.2 | +24.5 | 0.0 | 0.0 |
| LONG SHOT | 0.6 | -4.7 | 32.2 | 6.3 | 0.6 | +0.3 | 18.1 | 18.2 |
| LOST CHARGE | 2.8 | -41.2 | 111.5 | 86.0 | 3.0 | -43.2 | 40.8 | 78.7 |
| LURE BY WHAT IT DRAWS | 0.0 | +0.0 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 0.7 | +77.2 | 21.8 | 24.3 | 0.9 | +50.6 | 28.2 | 26.2 |
| MANOEUVRE | 0.1 | +7.2 | 0.0 | 0.0 | 0.3 | +5.2 | 0.0 | 4.0 |
| MARCH AT ESCAPER | 0.0 | +0.7 | 0.0 | 0.0 | 0.0 | +0.5 | 0.0 | 0.0 |
| MARCH CHECK | 0.6 | +29.5 | 0.0 | 17.6 | 0.4 | +25.3 | 0.0 | 4.4 |
| MARCH ODDS | 0.2 | +16.5 | 2.9 | 0.0 | 0.3 | +23.1 | 4.6 | 16.4 |
| MARCH OVER CASTS | 0.4 | +30.8 | 0.0 | 25.6 | 0.4 | +7.0 | 0.0 | 3.0 |
| MAX FOR POSITIONING | 5.2 | +184.1 | 0.0 | 77.9 | 5.2 | +186.7 | 0.0 | 177.5 |
| MISSILES IN THE MOVE | 4.3 | +155.6 | 0.0 | 108.7 | 3.5 | +52.2 | 0.0 | 61.4 |
| MISSILES NEXT TURN | 4.9 | +105.7 | 0.0 | 100.3 | 4.2 | +41.8 | 0.0 | 69.8 |
| MODEL FACING | 0.3 | +91.2 | 0.0 | 3.3 | - | - | - | - |
| MONSTER WIZARD ROAMS | 0.1 | +0.0 | 8.0 | 10.6 | 0.2 | +0.0 | 0.0 | 12.1 |
| MOVE AND CAST | 0.3 | +30.9 | 0.0 | 6.1 | 0.5 | +19.8 | 0.0 | 6.1 |
| MOVE SPELL IN RANGE | 0.2 | +6.9 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.3 | -60.8 | 0.0 | 26.9 | 0.1 | -0.9 | 0.0 | 0.0 |
| MOVE SPELL SPOT | 0.3 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE | 3.1 | +285.1 | 179.5 | 72.2 | 4.5 | +317.5 | 149.2 | 135.0 |
| MOVES UNITS SPELL | 0.1 | +3.4 | 0.0 | 0.0 | 0.1 | +1.8 | 0.0 | 0.0 |
| NEEDED THERE | 0.0 | +7.2 | 0.0 | 0.0 | - | - | - | - |
| NO RALLY LEFT | 0.0 | +1.4 | 0.0 | 0.0 | 0.0 | +0.5 | 0.0 | 0.0 |
| NOT NEEDED | 0.2 | -8.6 | 27.8 | 4.1 | 0.2 | -7.3 | 41.4 | 0.0 |
| NOT TURNED | 5.1 | +86.5 | 0.0 | 98.7 | 6.0 | +77.6 | 0.0 | 150.4 |
| NOT WORTH A CAST | 0.9 | -0.7 | 0.0 | 31.0 | 0.3 | -0.2 | 0.0 | 0.0 |
| OFF BEST | 17.4 | -890.7 | 7.0 | 337.6 | 16.0 | -847.1 | 0.9 | 311.8 |
| OPENS A LANE | 0.2 | +2.8 | 6.7 | 6.1 | 0.1 | +0.4 | 0.0 | 0.0 |
| OPENS UP | 0.2 | +10.0 | 11.0 | 30.2 | 0.1 | +5.8 | 6.6 | 7.9 |
| OVERRUNS AWAY | 0.5 | +10.3 | 41.1 | 24.0 | 0.4 | +4.9 | 31.1 | 16.4 |
| PATHS CROSS | 2.2 | +140.1 | 0.0 | 7.6 | 2.4 | +160.5 | 0.0 | 39.9 |
| PERIAPT WORTH | - | - | - | - | 0.1 | +3.6 | 0.0 | 30.0 |
| PIVOT GUARDS FLANK | 0.1 | -0.8 | 0.0 | 1.4 | 0.2 | -1.9 | 0.0 | 15.7 |
| PLAN RESULT | 38.1 | +1371.1 | 1597.7 | 929.3 | 37.5 | +893.3 | 1142.7 | 984.7 |
| PURSUES BIG PREY | 0.1 | -15.3 | 0.0 | 0.0 | 0.1 | -12.2 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE NEXT TURN | - | - | - | - | 0.1 | +9.0 | 0.0 | 1.5 |
| RANDOM MOVE BY FIGURES | 0.7 | +5.4 | 0.0 | 17.5 | 1.5 | +21.1 | 0.0 | 57.9 |
| RANDOM MOVER NO PROMISE | 0.1 | -3.5 | 0.0 | 4.7 | 0.3 | -8.3 | 4.9 | 4.7 |
| REDIRECT BY WHAT IT STOPS | 0.2 | +1.5 | 0.0 | 3.4 | 0.4 | -5.8 | 0.0 | 12.7 |
| REDIRECT COUNTER | 2.1 | +131.3 | 0.0 | 33.4 | 3.9 | +322.3 | 0.0 | 75.5 |
| REDIRECT WEIGHED | 0.3 | +2.4 | 8.7 | 0.0 | 0.4 | +6.5 | 10.1 | 3.5 |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 11.9 |
| RESERVE FALL BACK | 0.5 | +15.2 | 0.0 | 17.7 | 0.8 | +40.0 | 0.0 | 18.6 |
| RESTRAINS TO SHOOT | 0.1 | +2.6 | 0.0 | 0.0 | 0.1 | +3.7 | 0.0 | 6.5 |
| RISK BY ARC | 2.4 | +85.8 | 262.6 | 98.8 | 2.6 | +88.0 | 199.6 | 86.0 |
| SAFE SURE CHARGE | - | - | - | - | 0.0 | -13.3 | 0.0 | 10.9 |
| SAFER THAN THE JOB | 1.0 | +88.8 | 0.0 | 30.8 | 0.6 | +31.8 | 0.0 | 9.6 |
| SCOUT SPOT | 0.4 | +0.7 | 0.0 | 0.0 | 0.3 | +0.6 | 0.0 | 0.9 |
| SCOUT WAITS | 0.4 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.9 |
| SCREEN BY WHAT IT SAVES | 0.1 | -4.6 | 0.0 | 3.2 | 0.3 | -5.8 | 0.0 | 7.4 |
| SEARCH SPOT | 2.1 | +103.3 | 0.0 | 22.8 | 2.7 | +141.2 | 0.0 | 18.5 |
| SELF MOVE SPELL | 0.3 | +39.3 | 0.0 | 18.1 | 0.1 | -0.0 | 0.0 | 0.0 |
| SET UP TOGETHER | 1.3 | +143.6 | 56.8 | 45.8 | 2.0 | +138.8 | 50.9 | 44.4 |
| SET-UP ANY TARGET | 0.3 | +27.7 | 20.7 | 3.6 | 0.2 | +15.9 | 0.0 | 0.0 |
| SET-UP MISSED | 0.0 | +2.6 | 0.0 | 0.0 | 0.1 | +10.2 | 3.5 | 7.6 |
| SHOOTER COUNTED ONCE | - | - | - | - | 0.1 | -0.2 | 0.0 | 1.7 |
| SHOOTERS IN TWO RANKS | 0.4 | +0.9 | 0.0 | 0.0 | 0.3 | +0.8 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.3 | +30.0 | 52.6 | 11.4 | 0.7 | +17.8 | 26.8 | 1.8 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 3.2 | 0.0 | +0.0 | 0.0 | 0.0 |
| SHOT REPLANNED | 0.8 | +0.0 | 131.4 | 8.8 | 0.1 | +0.0 | 10.4 | 0.0 |
| SHOTS IN THE MOVE | 15.1 | +586.8 | 0.0 | 200.7 | 8.8 | +206.7 | 0.0 | 116.1 |
| SPELL CATCH ODDS | 0.0 | -1.0 | 0.0 | 0.0 | - | - | - | - |
| SPELL SETS UP CHARGE | 0.4 | +67.8 | 20.7 | 3.6 | 0.2 | +42.1 | 0.0 | 0.0 |
| SPELL WORTH | 1.1 | +17.5 | 82.2 | 82.1 | 1.7 | +46.4 | 83.2 | 96.2 |
| SPELLS IN THE FIGHT | 0.5 | +4.4 | 106.2 | 14.0 | 0.5 | -5.6 | 55.7 | 25.6 |
| STABLE ROLE | 12.0 | +0.0 | 428.9 | 191.9 | 10.9 | +0.0 | 262.7 | 198.4 |
| STANDS TO CAST | 0.0 | +3.4 | 0.0 | 0.0 | - | - | - | - |
| STOPS | - | - | - | - | 0.1 | +2.4 | 2.8 | 1.2 |
| STOPS SHORT OF THE FLANK | 0.4 | +13.3 | 0.0 | 1.4 | 0.4 | +11.7 | 0.0 | 10.6 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 8.1 |
| SUPPORT NARROWED | 5.3 | -34.1 | 368.3 | 106.0 | 7.1 | -55.1 | 314.7 | 111.6 |
| SUPPORTS | 3.3 | +35.0 | 142.9 | 34.7 | 4.9 | +55.4 | 176.1 | 62.5 |
| SURE CHARGE BEATS ADVANCE | 0.1 | -2.4 | 10.4 | 0.0 | 0.1 | -4.1 | 6.6 | 0.0 |
| SURE REACH TOGETHER | 0.7 | -3.2 | 0.0 | 20.7 | 0.6 | +0.9 | 14.1 | 24.1 |
| THROUGH LINE OF FIRE | 0.5 | +24.8 | 0.0 | 15.1 | 0.2 | +8.6 | 0.0 | 0.0 |
| TURN WORTH | 0.4 | -20.4 | 32.2 | 15.3 | 0.2 | -8.8 | 16.9 | 0.0 |
| TWO OR MORE ARRIVE | 0.2 | +2.0 | 0.0 | 8.1 | 0.5 | +3.7 | 0.0 | 0.0 |
| WAIT AFTER COSTS | 6.5 | -333.7 | 310.4 | 110.0 | 8.2 | -430.8 | 234.8 | 196.3 |
| WALKS TO THE FIGHT | 1.5 | +32.0 | 40.9 | 13.7 | 1.1 | +23.0 | 29.3 | 15.0 |
| WAR ENGINE CHARGES | 0.1 | +19.0 | 17.7 | 0.0 | - | - | - | - |
| WAR ENGINE JOBS | 0.6 | +0.0 | 25.8 | 17.1 | 0.6 | +0.0 | 6.5 | 5.1 |
| WEARS DOWN | 1.1 | +71.0 | 159.6 | 27.1 | 1.4 | +41.7 | 129.0 | 35.2 |
| WHO HITS BACK | 0.2 | +8.2 | 0.0 | 0.0 | 0.3 | +28.2 | 0.0 | 19.5 |
| WHOLE FIGHT | 0.4 | +24.5 | 86.4 | 0.0 | 0.4 | +5.1 | 18.8 | 1.4 |
| WHOLE FIGHT GAIN | 0.4 | +23.5 | 33.2 | 5.9 | 0.6 | +36.7 | 64.2 | 10.9 |
| WIDER SPREAD | 2.6 | -7.6 | 326.8 | 96.8 | 3.1 | -5.4 | 243.9 | 88.0 |

### Rule changes: jb-h2h-mine-b54c226-p1

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 1203 | 1203 | 1203 | 33.42 | -62560 | -52.0 |
| BEST FIRST | 333 | 333 | 333 | 9.25 | +15778 | +47.4 |
| SEARCH SPOT | 173 | 173 | 171 | 4.75 | +8812 | +51.5 |
| COUNTER-CHARGE COVER | 605 | 309 | 164 | 4.56 | +13132 | +80.1 |
| PATHS CROSS | 164 | 164 | 164 | 4.56 | +10822 | +66.0 |
| MOVE TO CHARGE | 273 | 273 | 143 | 3.97 | +8006 | +56.0 |
| FACES THE THREAT | 128 | 128 | 128 | 3.56 | +10431 | +81.5 |
| KILLS COUNT NEXT TURN | 402 | 402 | 128 | 3.56 | +4299 | +33.6 |
| SUPPORTS | 294 | 294 | 106 | 2.94 | +851 | +8.0 |
| FALLBACK BY WORTH | 344 | 344 | 80 | 2.22 | +5448 | +68.1 |
| SHOTS IN THE MOVE | 862 | 543 | 71 | 1.97 | +2448 | +34.5 |
| FOLLOW UP WEIGHED | 69 | 69 | 69 | 1.92 | +8065 | +116.9 |
| WAIT AFTER COSTS | 528 | 528 | 66 | 1.83 | +1286 | +19.5 |
| WALKS TO THE FIGHT | 92 | 92 | 58 | 1.61 | +841 | +14.5 |
| BEST FACING | 57 | 57 | 57 | 1.58 | +2289 | +40.1 |
| CANNON PLANNED TARGET | 220 | 220 | 56 | 1.56 | -21 | -0.4 |
| SAFER THAN THE JOB | 56 | 56 | 56 | 1.56 | +4341 | +77.5 |
| SET UP TOGETHER | 120 | 105 | 56 | 1.56 | +3388 | +60.5 |
| RANDOM MOVE BY FIGURES | 80 | 80 | 53 | 1.47 | +954 | +18.0 |
| ARTILLERY RE-ROLL WEIGHED | 52 | 52 | 52 | 1.44 | +0 | +0.0 |
| CANNON SIGHT KEPT | 51 | 51 | 51 | 1.42 | +0 | +0.0 |
| REDIRECT COUNTER | 217 | 102 | 50 | 1.39 | +3819 | +76.4 |
| RESERVE FALL BACK | 49 | 49 | 49 | 1.36 | +1989 | +40.6 |
| RISK BY ARC | 181 | 174 | 49 | 1.36 | +1314 | +26.8 |
| ADVANCE LANE KEPT | 46 | 46 | 46 | 1.28 | +0 | +0.0 |
| COMBAT PIVOT | 46 | 46 | 46 | 1.28 | +0 | +0.0 |
| CHARGE NOW FIRST | 182 | 182 | 45 | 1.25 | -3340 | -74.2 |
| HOLDS AMBUSHERS | 44 | 44 | 44 | 1.22 | +0 | +0.0 |
| BEST OVERALL | 42 | 42 | 42 | 1.17 | +3633 | +86.5 |
| MAX FOR POSITIONING | 372 | 193 | 42 | 1.17 | +603 | +14.4 |
| CHARGE NOW WEIGHED | 38 | 38 | 38 | 1.06 | +2866 | +75.4 |
| KILLS COUNT | 124 | 120 | 34 | 0.94 | +1258 | +37.0 |
| LONE WIZARD KEPT IN | 34 | 34 | 34 | 0.94 | +2648 | +77.9 |
| SHOT REPLANNED | 34 | 34 | 34 | 0.94 | +0 | +0.0 |
| MARCH CHECK | 34 | 33 | 32 | 0.89 | +2020 | +63.1 |
| MISSILES IN THE MOVE | 281 | 139 | 31 | 0.86 | +691 | +22.3 |
| STOPS SHORT OF THE FLANK | 31 | 31 | 31 | 0.86 | +899 | +29.0 |
| KEEPS ITS TARGET | 130 | 129 | 29 | 0.81 | +466 | +16.1 |
| MOVE AND CAST | 29 | 29 | 29 | 0.81 | +1825 | +62.9 |
| SHOOTS FROM THE BEST SPOT | 72 | 72 | 29 | 0.81 | +840 | +29.0 |
| HONEST WORTH | 592 | 589 | 28 | 0.78 | +218 | +7.8 |
| CASTER AWAY FROM SCREEN | 26 | 26 | 26 | 0.72 | +0 | +0.0 |
| SCOUT WAITS | 26 | 26 | 26 | 0.72 | +0 | +0.0 |
| THROUGH LINE OF FIRE | 26 | 26 | 26 | 0.72 | +1205 | +46.3 |
| CAST JOB | 40 | 40 | 25 | 0.69 | +461 | +18.4 |
| INVITES THE FIGHT | 115 | 115 | 24 | 0.67 | +427 | +17.8 |
| SHOOTERS IN TWO RANKS | 24 | 24 | 24 | 0.67 | +58 | +2.4 |
| REDIRECT WEIGHED | 23 | 23 | 23 | 0.64 | +645 | +28.1 |
| FRIENDS SHOTS CHECKED | 21 | 21 | 21 | 0.58 | +1221 | +58.1 |
| WEARS DOWN | 88 | 85 | 20 | 0.56 | +647 | +32.3 |
| MARCH ODDS | 19 | 19 | 19 | 0.53 | +229 | +12.1 |
| WHO HITS BACK | 19 | 19 | 19 | 0.53 | +899 | +47.3 |
| MAKE SURE TOGETHER | 59 | 41 | 17 | 0.47 | +841 | +49.5 |
| WHOLE FIGHT GAIN | 36 | 32 | 17 | 0.47 | +586 | +34.5 |
| BEST PREY | 67 | 67 | 16 | 0.44 | +376 | +23.5 |
| BLOCKED WHEEL | 15 | 15 | 15 | 0.42 | +296 | +19.7 |
| CASTS FROM BEHIND | 14 | 14 | 14 | 0.39 | +0 | +0.0 |
| BIG CHARACTER SAFETY | 13 | 13 | 13 | 0.36 | -7 | -0.6 |
| CHAFF PASSED | 12 | 12 | 12 | 0.33 | -23 | -1.9 |
| MANOEUVRE | 14 | 14 | 12 | 0.33 | +443 | +36.9 |
| CASTING BLOCK | 18 | 18 | 11 | 0.31 | +685 | +62.3 |
| MODEL FACING | 11 | 11 | 11 | 0.31 | +3283 | +298.4 |
| WAR ENGINE JOBS | 41 | 41 | 11 | 0.31 | -909 | -82.6 |
| CHARGE BAND | 10 | 10 | 10 | 0.28 | +0 | +0.0 |
| PURSUES BIG PREY | 10 | 10 | 10 | 0.28 | -990 | -99.0 |
| STUCK PIVOT | 10 | 10 | 10 | 0.28 | +0 | +0.0 |
| PIVOT GUARDS FLANK | 9 | 9 | 9 | 0.25 | -98 | -10.9 |
| SHORT GUN FORWARD | 8 | 8 | 8 | 0.22 | +0 | +0.0 |
| MOVES UNITS SPELL | 7 | 7 | 7 | 0.19 | +186 | +26.5 |
| REFUSING RETIRES | 26 | 26 | 7 | 0.19 | -3 | -0.4 |
| RESTRAINS TO SHOOT | 7 | 7 | 7 | 0.19 | +225 | +32.1 |
| HUNT IN PAIRS | 31 | 17 | 6 | 0.17 | +321 | +53.6 |
| OPENS UP | 11 | 11 | 6 | 0.17 | +88 | +14.8 |
| SPELLS IN THE FIGHT | 36 | 34 | 6 | 0.17 | +147 | +24.6 |
| SURE CHARGE BEATS ADVANCE | 6 | 6 | 6 | 0.17 | -234 | -38.9 |
| WHOLE FIGHT | 27 | 27 | 6 | 0.17 | +94 | +15.6 |
| BLOCKED CHARGE SKIPPED | 5 | 5 | 5 | 0.14 | +0 | +0.0 |
| JOINT CHARGE PLAN | 13 | 13 | 5 | 0.14 | +147 | +29.5 |
| OPENS A LANE | 8 | 7 | 5 | 0.14 | +31 | +6.2 |
| SUPPORT NARROWED | 447 | 447 | 5 | 0.14 | -104 | -20.9 |
| WIDER SPREAD | 206 | 199 | 5 | 0.14 | +54 | +10.8 |
| CATCH ODDS | 4 | 4 | 4 | 0.11 | -149 | -37.2 |
| LOST CHARGE | 211 | 211 | 4 | 0.11 | +74 | +18.4 |
| REDIRECT BY WHAT IT STOPS | 22 | 22 | 4 | 0.11 | +165 | +41.2 |
| SURE REACH TOGETHER | 49 | 41 | 4 | 0.11 | +27 | +6.8 |
| BACKUP TARGETS | 70 | 27 | 3 | 0.08 | +46 | +15.3 |
| FIRE AND FLEE | 3 | 3 | 3 | 0.08 | +62 | +20.8 |
| FOCUS FIRE | 3 | 3 | 3 | 0.08 | +141 | +47.1 |
| HUNT ADVANCE | 7 | 7 | 3 | 0.08 | +78 | +25.9 |
| LONG SHOT | 46 | 46 | 3 | 0.08 | +4 | +1.3 |
| OVERRUNS AWAY | 33 | 33 | 3 | 0.08 | +13 | +4.2 |
| WAR ENGINE CHARGES | 5 | 5 | 3 | 0.08 | +251 | +83.7 |
| BEST PRIZE | 2 | 2 | 2 | 0.06 | -73 | -36.3 |
| BOMBING RUN | 2 | 2 | 2 | 0.06 | +92 | +45.9 |
| CARRIES OUT SET-UP | 8 | 8 | 2 | 0.06 | -172 | -86.0 |
| CONTINUE AHEAD WEIGHED | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| ELIXIR WORTH | 2 | 2 | 2 | 0.06 | +76 | +38.0 |
| JOINS A FRIEND | 60 | 60 | 2 | 0.06 | +2 | +1.1 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| MISSILES NEXT TURN | 328 | 159 | 2 | 0.06 | +1 | +0.5 |
| NO RALLY LEFT | 2 | 2 | 2 | 0.06 | +36 | +17.8 |
| PERIAPT WORTH | 2 | 2 | 2 | 0.06 | +131 | +65.3 |
| RAIDS THE BAGGAGE NEXT TURN | 3 | 3 | 2 | 0.06 | +70 | +35.1 |
| STOPS | 2 | 2 | 2 | 0.06 | +53 | +26.5 |
| BLOWS WHERE AIMED | 21 | 20 | 1 | 0.03 | +66 | +66.4 |
| BOUND ASSAILMENT | 1 | 1 | 1 | 0.03 | +0 | +0.1 |
| CARRIES OUT COUNTER | 8 | 8 | 1 | 0.03 | -5 | -4.6 |
| CHARGER SLAIN LOST | 48 | 47 | 1 | 0.03 | +60 | +59.5 |
| CHARIOT NO STATIC JOB | 1 | 1 | 1 | 0.03 | -271 | -271.3 |
| DEFENSIVE FLOOR | 1 | 1 | 1 | 0.03 | +45 | +44.8 |
| HORN WORTH | 1 | 1 | 1 | 0.03 | +16 | +16.5 |
| KEEP FALLS | 1 | 1 | 1 | 0.03 | +28 | +27.9 |
| LONE WIZARD HOLDS BACK | 10 | 10 | 1 | 0.03 | -183 | -183.0 |
| NEEDED THERE | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| SAFE SURE CHARGE | 1 | 1 | 1 | 0.03 | -587 | -587.1 |
| SCREEN BY WHAT IT SAVES | 15 | 15 | 1 | 0.03 | +16 | +16.4 |
| STANDS TO CAST | 1 | 1 | 1 | 0.03 | +4 | +3.6 |
| TWO OR MORE ARRIVE | 28 | 26 | 1 | 0.03 | +7 | +7.1 |
| ALREADY CARRIED | 1 | not checked | - | - | - | - |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 37 | 37 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 36 | trace | - | - | - | - |
| CATCH FLIERS | 2 | not checked | - | - | - | - |
| CHARIOT WIZARD CAREFUL | 8 | 8 | 0 | 0.00 | - | - |
| CHEAP HELPER | 5 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 31 | not checked | - | - | - | - |
| DEFENSIVE ARMY | 9 | 9 | 0 | 0.00 | - | - |
| EDGE GIVE GROUND | 8 | 8 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 2 | 2 | 0 | 0.00 | - | - |
| FIGHT LIFT | 2 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 392 | not checked | - | - | - | - |
| GIVES UP | 2 | 2 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 3 | 3 | 0 | 0.00 | - | - |
| GROUND FLIERS | 2 | not checked | - | - | - | - |
| HELPER ALREADY ASKED | 1 | not checked | - | - | - | - |
| HELPER UNSEEN | 20 | 19 | 0 | 0.00 | - | - |
| HILL BY ITS CHANCE | 3 | 3 | 0 | 0.00 | - | - |
| HUNT DROPPED | 2 | trace | - | - | - | - |
| HUNT KEPT | 3 | trace | - | - | - | - |
| HUNT RESULT | 6 | trace | - | - | - | - |
| HUNT THE GUNS | 7 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 6 | 5 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 27 | not checked | - | - | - | - |
| LURE BY WHAT IT DRAWS | 2 | 2 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 2 | trace | - | - | - | - |
| MARCH OVER CASTS | 29 | 29 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 10 | 10 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 8 | 3 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 13 | trace | - | - | - | - |
| MOVE SPELL SPOT | 17 | not checked | - | - | - | - |
| NOT NEEDED | 14 | 14 | 0 | 0.00 | - | - |
| NOT TURNED | 398 | 398 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 44 | not checked | - | - | - | - |
| PLAN RESULT | 2723 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 12 | 12 | 0 | 0.00 | - | - |
| SCOUT SPOT | 23 | 23 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 15 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 16 | not checked | - | - | - | - |
| SET-UP MISSED | 4 | trace | - | - | - | - |
| SHOOTER COUNTED ONCE | 3 | 3 | 0 | 0.00 | - | - |
| SPELL CATCH ODDS | 1 | not checked | - | - | - | - |
| SPELL SETS UP CHARGE | 20 | not checked | - | - | - | - |
| SPELL WORTH | 102 | not checked | - | - | - | - |
| STABLE ROLE | 825 | 823 | 0 | 0.00 | - | - |
| TURN WORTH | 19 | 19 | 0 | 0.00 | - | - |

### Off best figure: jb-h2h-mine-b54c226-p1

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 15.58 | 14.08 | 53.4 |
| FALLBACK | gate | 0.78 | 0.81 | 50.8 |
| CHARGE NOW FIRST | rule | 0.67 | 0.56 | 75.9 |
| TURN GATE | gate | 0.47 | 0.61 | 34.3 |
| LONE CHARACTER SAFE SPOT | gate | 0.19 | 0.19 | 57.2 |
| PATHS CROSS | rule | 0.17 | 0.19 | 34.3 |
| AFTERMATH BAND | gate | 0.11 | 0.17 | 2.2 |
| PURSUES BIG PREY | rule | 0.14 | 0.14 | 99.0 |
| WAR ENGINE JOBS | rule | 0.11 | 0.17 | 90.9 |
| CANNON PLANNED TARGET | rule | 0.25 | - | 43.1 |
| PIVOT GUARDS FLANK | rule | 0.08 | 0.17 | 10.9 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.08 | 0.06 | 39.2 |
| CHARGE NOW WEIGHED | rule | 0.06 | 0.08 | 14.7 |
| FIGHT ORDER BAND | gate | 0.11 | 0.03 | 2.0 |
| SUPPORT NARROWED | rule | 0.14 | - | 20.9 |
| SURE CHARGE BEATS ADVANCE | rule | 0.08 | 0.06 | 46.6 |
| BIG CHARACTER SAFETY | rule | 0.06 | 0.06 | 4.9 |
| CATCH ODDS | rule | 0.06 | 0.06 | 37.2 |
| CHAFF PASSED | rule | 0.03 | 0.08 | 5.8 |
| MARCH ODDS | rule | - | 0.11 | 19.0 |
| SUPPORT REQUEST | gate | 0.06 | 0.06 | 54.7 |
| BLOCKED WHEEL | rule | - | 0.08 | 4.3 |
| STOPS SHORT OF THE FLANK | rule | 0.06 | 0.03 | 6.3 |
| THROUGH LINE OF FIRE | rule | 0.03 | 0.06 | 19.1 |
| BEST PRIZE | rule | - | 0.06 | 36.3 |
| CARRIES OUT SET-UP | rule | - | 0.06 | 86.0 |
| MOVE AND CAST | rule | - | 0.06 | 17.1 |
| WHO HITS BACK | rule | - | 0.06 | 3.2 |
| CARRIES OUT COUNTER | rule | 0.03 | - | 4.6 |
| CHARIOT NO STATIC JOB | rule | 0.03 | - | 271.3 |
| FRIENDS SHOTS CHECKED | rule | - | 0.03 | 2.6 |
| LONE WIZARD HOLDS BACK | rule | - | 0.03 | 183.0 |
| LONG SHOT | rule | 0.03 | - | 0.7 |
| NO REASON | gate | 0.03 | - | 7.3 |
| REDIRECT WEIGHED | rule | - | 0.03 | 47.5 |
| REFUSING RETIRES | rule | - | 0.03 | 1.4 |
| SAFE SURE CHARGE | rule | - | 0.03 | 587.1 |
| SAFER THAN THE JOB | rule | - | 0.03 | 0.8 |

### Plans: jb-h2h-mine-b54c226-p1

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 11.1 | 15% | 426 | 244 | 57% |
| Mine | charge | 3.4 | 69% | 272 | 347 | 128% |
| Mine | close in | 4.7 | 27% | 283 | 170 | 60% |
| Mine | hold | 5.3 | 42% | 351 | 0 | 0% |
| Mine | join | 0.5 | 100% | 18 | 0 | 0% |
| Mine | shoot | 9.6 | 58% | 302 | 610 | 202% |
| Mine | support | 3.5 | 87% | 24 | 0 | 0% |
| Opponent | advance | 12.8 | 15% | 432 | 290 | 67% |
| Opponent | charge | 4.0 | 56% | 308 | 320 | 104% |
| Opponent | close in | 5.6 | 22% | 327 | 90 | 28% |
| Opponent | hold | 4.1 | 44% | 256 | 0 | 0% |
| Opponent | join | 0.8 | 87% | 51 | 0 | 0% |
| Opponent | shoot | 4.6 | 53% | 119 | 197 | 165% |
| Opponent | support | 5.5 | 90% | 48 | 0 | 0% |

### Packages: hunt the guns, jb-h2h-mine-b54c226-p1

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.0 | 1 | 0 | 0% | 0% | 0% | - | 385 | 0 | 0% | 22 |
| Opponent | 0.2 | 6 | 1 | 20% | 20% | 0% | 2.0 | 422 | 95 | 20% | 61 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Dwarfen Mountain Holds | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 385 | 0 | 0% | 159 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 29 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 87 |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 83 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 216 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 48 |
| Tomb Kings of Khemri | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 281 | 0 | 0% | 12 |
| Vampire Counts | 0.2 | 2 | 0 | 50% | 50% | 0% | 2.0 | 408 | 238 | 50% | 8 |
| Warriors of Chaos | 0.2 | 2 | 1 | 0% | 0% | 0% | - | 685 | 0 | 0% | 25 |
| Wood Elf Realms | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 329 | 0 | 0% | 24 |

### Battle groups: jb-h2h-mine-b54c226-p1

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 9.2 | 23% | 59% | 11% | 50% | 31% | 6% | 4% | 59% | 0% |
| Mine | REDIRECT COUNTER | 2.1 | 36% | 68% | 0% | - | 21% | 4% | 18% | 54% | 4% |
| Opponent | COUNTER-CHARGE COVER | 7.6 | 17% | 49% | 30% | 21% | 24% | 12% | 12% | 52% | 0% |
| Opponent | REDIRECT COUNTER | 3.9 | 29% | 73% | 12% | 40% | 31% | 0% | 3% | 61% | 6% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: jb-h2h-mine-b54c226-p1

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 3 | 29 (3) | 29 | 0 | 0 | 33% | 5.0 | 36 (2) | 0 (1) | - | 78 (1) | 0 (2) |
| Mine | Chaff | 37 | 25 (37) | 9 | 16 | 58 | 30% | 2.3 | 11 (16) | 10 (9) | 51 (12) | 37 (24) | 6 (13) |
| Mine | Character | 123 | 51 (123) | 51 | 0 | 32 | 24% | 2.3 | 89 (36) | 39 (55) | 13 (10) | 71 (56) | 39 (45) |
| Mine | Clean-up | 24 | 76 (24) | 41 | 35 | 23 | 50% | 2.8 | 59 (9) | 111 (11) | 16 (4) | 76 (14) | 76 (10) |
| Mine | Fast | 4 | 111 (4) | 111 | 0 | 47 | 0% | 2.2 | 124 (1) | 0 (2) | 362 (1) | 111 (4) | - |
| Mine | Fast Hammer | 41 | 38 (41) | 26 | 12 | 55 | 22% | 2.7 | 34 (18) | 7 (12) | 73 (11) | 42 (28) | 31 (13) |
| Mine | Fragile | 5 | 0 (5) | 0 | 0 | 60 | 0% | 1.6 | - | 0 (4) | 0 (1) | 0 (1) | 0 (4) |
| Mine | Hammer | 58 | 46 (58) | 31 | 14 | 40 | 17% | 2.4 | 57 (10) | 42 (38) | 51 (10) | 47 (34) | 45 (24) |
| Mine | Holder | 25 | 80 (25) | 7 | 73 | 21 | 48% | 3.0 | 66 (8) | 100 (11) | 68 (5) | 117 (11) | 55 (13) |
| Mine | Shooter | 44 | 113 (44) | 41 | 73 | 26 | 5% | 1.7 | 64 (5) | 132 (32) | 79 (7) | 149 (24) | 73 (20) |
| Mine | Support | 5 | 19 (5) | 19 | 0 | 84 | 0% | 2.4 | 63 (2) | 0 (2) | - | 32 (2) | 0 (2) |
| Mine | War machine | 56 | 34 (56) | 34 | 0 | 35 | 7% | 1.2 | 46 (13) | 22 (37) | 80 (6) | 24 (11) | 36 (45) |
| Mine | Wizard | 23 | 22 (23) | 22 | 0 | 35 | 17% | 2.6 | 34 (6) | 31 (10) | 0 (2) | 67 (2) | 18 (16) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Chaff | 66 | 75 (66) | 38 | 37 | 37 | 35% | 2.9 | 120 (28) | 44 (16) | 46 (22) | 90 (48) | 34 (18) |
| Opponent | Character | 114 | 48 (114) | 47 | 1 | 35 | 22% | 2.5 | 78 (41) | 32 (56) | 0 (4) | 55 (68) | 46 (33) |
| Opponent | Clean-up | 16 | 24 (16) | 21 | 3 | 49 | 38% | 3.4 | 0 (5) | 20 (8) | 72 (3) | 23 (8) | 25 (8) |
| Opponent | Early | 1 | 0 (1) | 0 | 0 | 0 | 0% | 6.0 | - | 0 (1) | - | - | 0 (1) |
| Opponent | Fast Hammer | 58 | 50 (58) | 32 | 18 | 63 | 33% | 2.6 | 39 (25) | 24 (19) | 111 (14) | 51 (42) | 50 (16) |
| Opponent | Fragile | 10 | 0 (10) | 0 | 0 | 43 | 30% | 1.6 | 0 (3) | 0 (3) | 0 (4) | 0 (10) | - |
| Opponent | Hammer | 65 | 32 (65) | 21 | 11 | 48 | 22% | 2.5 | 3 (16) | 41 (42) | 23 (7) | 31 (40) | 32 (25) |
| Opponent | Holder | 40 | 69 (40) | 14 | 55 | 33 | 42% | 3.8 | 29 (10) | 84 (22) | 63 (8) | 78 (21) | 58 (19) |
| Opponent | Shooter | 30 | 82 (30) | 21 | 61 | 39 | 3% | 1.2 | 57 (7) | 81 (18) | 120 (5) | 95 (16) | 65 (14) |
| Opponent | Support | 2 | 0 (2) | 0 | 0 | 0 | 100% | - | 0 (1) | - | 0 (1) | 0 (1) | 0 (1) |
| Opponent | War machine | 13 | 54 (13) | 54 | 0 | 31 | 0% | 1.2 | 0 (5) | 95 (5) | 72 (3) | 101 (3) | 41 (10) |
| Opponent | Wizard | 22 | 10 (22) | 10 | 0 | 20 | 14% | 1.7 | 10 (12) | 8 (6) | 0 (2) | 10 (11) | 5 (9) |

### Charged fights: jb-h2h-mine-b54c226-p1

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 5 | 185 | 0 | 1.2 | 1.0 | 0 | 23 | -23 | 0 of 6 | 3 of 6 | - | -23 |
| Mine | Chaos Dwarfs | 3 | 115 | 865 | 5.0 | 1.1 | 173 | 21 | +152 | 9 of 15 | 10 of 15 | +402 | +114 |
| Mine | Dwarfen Mountain Holds | 4 | 364 | 130 | 1.2 | 1.2 | 104 | 49 | +55 | 1 of 5 | 4 of 5 | +162 | +28 |
| Mine | Empire of Man | 5 | 275 | 130 | 2.0 | 1.0 | 65 | 0 | +65 | 3 of 10 | 6 of 10 | - | +65 |
| Mine | Grand Cathay | 4 | 752 | 357 | 3.5 | 1.1 | 102 | 0 | +102 | 8 of 14 | 8 of 14 | +393 | +80 |
| Mine | High Elf Realms | 4 | 130 | 634 | 4.2 | 1.3 | 149 | 16 | +133 | 8 of 17 | 13 of 17 | +193 | +108 |
| Mine | Kingdom of Bretonnia | 1 | 0 | 374 | 4.0 | 1.0 | 94 | 118 | -24 | 2 of 4 | 3 of 4 | - | -24 |
| Mine | Lizardmen | 1 | 140 | 752 | 4.0 | 1.0 | 188 | 79 | +109 | 2 of 4 | 3 of 4 | - | +109 |
| Mine | Ogre Kingdoms | 1 | 0 | 70 | 2.0 | 1.0 | 35 | 0 | +35 | 1 of 2 | 0 of 2 | - | +35 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 395 | 7.0 | 1.1 | 56 | 16 | +41 | 3 of 7 | 3 of 7 | +195 | +15 |
| Mine | Skaven | 2 | 0 | 22 | 1.5 | 1.3 | 15 | 0 | +15 | 0 of 3 | 2 of 2 | +45 | +0 |
| Mine | Tomb Kings of Khemri | 2 | 125 | 1398 | 5.5 | 1.1 | 254 | 0 | +254 | 3 of 11 | 10 of 11 | +938 | +186 |
| Mine | Vampire Counts | 2 | 0 | 268 | 4.0 | 1.5 | 67 | 101 | -34 | 1 of 8 | 6 of 8 | +92 | -160 |
| Mine | Warriors of Chaos | 1 | 27 | 267 | 5.0 | 1.0 | 53 | 0 | +53 | 3 of 5 | 4 of 5 | - | +53 |
| **Mine** | all armies | 36 | 223 | 360 | 3.1 | 1.1 | 117 | 24 | +93 | 44 of 111 | 75 of 110 | +242 | +68 |
| Opponent | Beastmen Brayherds | 1 | 0 | 1137 | 4.0 | 1.8 | 284 | 37 | +248 | 1 of 4 | 3 of 4 | +857 | +44 |
| Opponent | Dwarfen Mountain Holds | 1 | 0 | 0 | 2.0 | 1.0 | 0 | 0 | +0 | 1 of 2 | 2 of 2 | - | +0 |
| Opponent | Empire of Man | 1 | 399 | 0 | 2.0 | 1.0 | 0 | 0 | +0 | 2 of 2 | 1 of 2 | - | +0 |
| Opponent | Grand Cathay | 1 | 706 | 185 | 2.0 | 1.0 | 92 | 0 | +92 | 2 of 2 | 1 of 2 | - | +92 |
| Opponent | High Elf Realms | 2 | 104 | 465 | 4.5 | 1.1 | 103 | 49 | +54 | 3 of 9 | 7 of 9 | +316 | +22 |
| Opponent | Lizardmen | 1 | 189 | 344 | 4.0 | 1.0 | 86 | 0 | +86 | 2 of 4 | 3 of 4 | - | +86 |
| Opponent | Ogre Kingdoms | 2 | 52 | 190 | 3.5 | 1.1 | 54 | 76 | -21 | 1 of 7 | 4 of 7 | -399 | +42 |
| Opponent | Orc & Goblin Tribes | 2 | 35 | 404 | 3.5 | 1.1 | 115 | 109 | +6 | 2 of 7 | 6 of 7 | -55 | +16 |
| Opponent | Skaven | 2 | 179 | 102 | 1.0 | 1.5 | 102 | 0 | +102 | 1 of 2 | 1 of 1 | +205 | +0 |
| Opponent | Tomb Kings of Khemri | 4 | 17 | 899 | 5.0 | 1.3 | 180 | 69 | +111 | 10 of 20 | 14 of 20 | +192 | +84 |
| Opponent | Vampire Counts | 6 | 37 | 367 | 5.0 | 1.2 | 73 | 42 | +32 | 14 of 30 | 22 of 30 | +112 | +16 |
| Opponent | Warriors of Chaos | 7 | 27 | 195 | 2.0 | 1.1 | 97 | 29 | +68 | 5 of 14 | 8 of 14 | +123 | +64 |
| Opponent | Wood Elf Realms | 6 | 107 | 462 | 3.8 | 1.2 | 121 | 6 | +115 | 7 of 23 | 18 of 23 | +227 | +84 |
| **Opponent** | all armies | 36 | 88 | 387 | 3.5 | 1.2 | 111 | 40 | +70 | 51 of 126 | 90 of 125 | +176 | +49 |

### Effective charges: jb-h2h-mine-b54c226-p1

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 6 | 1 (net -52) | 1 (net +0) | 1 (net -85) | 0 | 0 | 1 (net +0) | 2 | 25% (1 of 4) |
| Mine | Chaos Dwarfs | 15 | 1 (net +388) | 2 (net +105) | 0 | 2 (net +402) | 1 (net +540) | 9 (net +38) | 0 | 0% (0 of 15) |
| Mine | Dwarfen Mountain Holds | 5 | 1 (net +162) | 0 | 0 | 2 (net +56) | 0 | 2 (net +0) | 0 | 0% (0 of 5) |
| Mine | Empire of Man | 10 | 2 (net +0) | 0 | 0 | 3 (net +114) | 3 (net +23) | 2 (net +118) | 0 | 0% (0 of 10) |
| Mine | Grand Cathay | 14 | 0 | 0 | 3 (net +80) | 6 (net +154) | 0 | 4 (net +67) | 1 | 23% (3 of 13) |
| Mine | High Elf Realms | 17 | 3 (net +52) | 0 | 4 (net +426) | 5 (net +102) | 1 (net -151) | 3 (net +0) | 1 | 25% (4 of 16) |
| Mine | Kingdom of Bretonnia | 4 | 0 | 0 | 0 | 3 (net -117) | 0 | 1 (net +254) | 0 | 0% (0 of 4) |
| Mine | Lizardmen | 4 | 0 | 0 | 1 (net +451) | 0 | 0 | 0 | 3 | 100% (1 of 1) |
| Mine | Ogre Kingdoms | 2 | 1 (net +70) | 0 | 0 | 0 | 0 | 0 | 1 | 0% (0 of 1) |
| Mine | Orc & Goblin Tribes | 7 | 0 | 0 | 1 (net +195) | 0 | 0 | 0 | 6 | 100% (1 of 1) |
| Mine | Skaven | 3 | 1 (net +0) | 0 | 1 (net +45) | 0 | 0 | 1 (net +0) | 0 | 33% (1 of 3) |
| Mine | Tomb Kings of Khemri | 11 | 2 (net +768) | 0 | 1 (net +232) | 4 (net +86) | 1 (net +110) | 2 (net +288) | 1 | 10% (1 of 10) |
| Mine | Vampire Counts | 8 | 0 | 0 | 1 (net +170) | 2 (net -282) | 0 | 3 (net +33) | 2 | 17% (1 of 6) |
| Mine | Warriors of Chaos | 5 | 2 (net +0) | 0 | 0 | 1 (net +0) | 0 | 2 (net +134) | 0 | 0% (0 of 5) |
| Opponent | Beastmen Brayherds | 4 | 0 | 0 | 2 (net +65) | 1 (net +3) | 0 | 1 (net +857) | 0 | 50% (2 of 4) |
| Opponent | Dwarfen Mountain Holds | 2 | 0 | 0 | 0 | 0 | 0 | 2 (net +0) | 0 | 0% (0 of 2) |
| Opponent | Empire of Man | 2 | 0 | 0 | 1 (net +0) | 1 (net +0) | 0 | 0 | 0 | 50% (1 of 2) |
| Opponent | Grand Cathay | 2 | 1 (net +185) | 0 | 0 | 1 (net +0) | 0 | 0 | 0 | 0% (0 of 2) |
| Opponent | High Elf Realms | 9 | 1 (net +0) | 0 | 3 (net -106) | 2 (net +289) | 0 | 1 (net +0) | 2 | 43% (3 of 7) |
| Opponent | Lizardmen | 4 | 0 | 0 | 0 | 0 | 0 | 1 (net +189) | 3 | 0% (0 of 1) |
| Opponent | Ogre Kingdoms | 7 | 0 | 0 | 2 (net -200) | 0 | 0 | 2 (net +0) | 3 | 50% (2 of 4) |
| Opponent | Orc & Goblin Tribes | 7 | 0 | 0 | 1 (net +195) | 0 | 0 | 1 (net -708) | 5 | 50% (1 of 2) |
| Opponent | Skaven | 2 | 0 | 0 | 1 (net +0) | 0 | 0 | 1 (net +205) | 0 | 50% (1 of 2) |
| Opponent | Tomb Kings of Khemri | 20 | 2 (net +20) | 1 (net -735) | 4 (net +207) | 6 (net +111) | 2 (net +184) | 4 (net +195) | 1 | 21% (4 of 19) |
| Opponent | Vampire Counts | 30 | 4 (net -168) | 1 (net +0) | 7 (net +20) | 6 (net +37) | 1 (net +0) | 9 (net +162) | 2 | 25% (7 of 28) |
| Opponent | Warriors of Chaos | 14 | 3 (net +170) | 0 | 2 (net +148) | 3 (net +91) | 0 | 2 (net +72) | 4 | 20% (2 of 10) |
| Opponent | Wood Elf Realms | 23 | 3 (net +223) | 0 | 5 (net +63) | 10 (net +96) | 0 | 5 (net +140) | 0 | 22% (5 of 23) |

### Charged fights, damage counted: jb-h2h-mine-b54c226-p1

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 14 | 295 | 275 | +162 | 206 | 57 | +148 | +50.3 |
| Mine | 50-54% | 3 | 245 | 215 | +70 | 82 | 7 | +75 | +30.8 |
| Mine | Effective (55-75%) | 13 | 350 | 195 | +227 | 258 | 78 | +180 | +51.4 |
| Mine | 76-89% | 28 | 292 | 192 | +76 | 136 | 63 | +73 | +25.1 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 30 | 250 | 191 | +68 | 93 | 26 | +67 | +26.9 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 6 | 335 | 95 | +95 | 141 | 70 | +72 | +21.3 |
| Mine | No odds | 17 | 294 | 159 | +9 | 45 | 43 | +2 | +0.5 |
| Mine | All fights | 111 | 289 | 193 | +93 | 132 | 50 | +83 | +28.6 |
| Opponent | Long shot (under 50%) | 14 | 179 | 280 | +52 | 142 | 102 | +40 | +22.1 |
| Opponent | 50-54% | 2 | 245 | 228 | -368 | 0 | 368 | -368 | -150.0 |
| Opponent | Effective (55-75%) | 28 | 211 | 168 | +42 | 119 | 65 | +53 | +25.1 |
| Opponent | 76-89% | 30 | 320 | 177 | +90 | 121 | 18 | +103 | +32.3 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 29 | 271 | 196 | +125 | 174 | 44 | +131 | +48.1 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 3 | 426 | 99 | +123 | 162 | 2 | +160 | +37.6 |
| Opponent | No odds | 20 | 209 | 200 | +50 | 92 | 51 | +40 | +19.3 |
| Opponent | All fights | 126 | 253 | 193 | +70 | 130 | 54 | +75 | +29.8 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| jb-h2h-mine-b54c226-p1 | move | 468 | 103 (22%) | 82 (18%) | 62 (13%) | 303 (65%) |
| jb-h2h-mine-b54c226-p1 | objective | 373 | 67 (18%) | 53 (14%) | 45 (12%) | 261 (70%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0102, L0118, L0135, L2531, L2730 |
| Charmed Shield | Opponent | L0524, L1224, L1527, L1625, L2025, L2127, L2934 |
| Clockwork Compass | Mine | L1224 |
| Clockwork Compass | Opponent | L0612 |
| Elixir of Power | Mine | L1114, L1131, L1923 |
| Elixir of Power | Opponent | L0319, L1319 |
| Fistful of Laurels | Mine | L1823 |
| Fistful of Laurels | Opponent | L0118, L0218 |
| Horn of the Wild Hunt | Opponent | L0733 |
| Invocation of Nehek | Mine | L2531, L2730 |
| Invocation of Nehek | Opponent | L0524, L1224, L1527, L1625, L2025, L2127 |
| Opal Amulet | Mine | L1431 |
| Opal Amulet | Opponent | L1114 |
| Periapt of Soul Exchange | Mine | L2025, L2127 |
| Periapt of Soul Exchange | Opponent | L0421, L1021 |
| Ring of Doom | Mine | L0218, L0235, L1114, L1131, L1224, L1527 |
| Ring of Doom | Opponent | L0102, L0612, L0733, L1131, L1431, L2231, L2531 |
| Ring of Jet | Mine | L1021, L1114, L1131, L1224 |
| Ring of Jet | Opponent | L0612 |
| Standard of the Fell Warrior | Mine | L1319, L1335 |
| Standard of the Fell Warrior | Opponent | L0913 |
| Storm Daemon (Renegade 2.0) | Mine | L2127 |
| Storm Daemon (Renegade 2.0) | Opponent | L0421, L1021 |
| Twice-Blessed Armour | Mine | L0717, L0733, L1021 |
| Witch Hunter's Ward | Mine | L0717, L0733, L0823 |
| Witch Hunter's Ward | Opponent | L0508 |

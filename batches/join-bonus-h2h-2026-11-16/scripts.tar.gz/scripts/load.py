import json,glob,os,re,pickle,math
D='/root/jb'
def files(): return sorted([f for f in glob.glob(D+'/*/game-*.log.jsonl')+glob.glob(D+'/*/*/game-*.log.jsonl') if '/parts/' not in f])
def load(f):
    c='/tmp/claude-0/-home-user/4ad0e2d2-ad5c-5fec-98a7-be09d5f63b1b/scratchpad/an/cache/'+os.path.basename(os.path.dirname(f))+'_'+os.path.basename(f)+'.pkl'
    if os.path.exists(c): return pickle.load(open(c,'rb'))
    board=None;acts=[];frames=[]
    for l in open(f):
        try:d=json.loads(l)
        except ValueError: continue
        k=d.get('kind')
        if k=='board': board=d
        elif k=='action': acts.append(d)
        elif k=='frame': frames.append(d)
    acts.sort(key=lambda a:a['id']); frames.sort(key=lambda a:a['after'])
    g=dict(board=board,acts=acts,frames=frames,f=f)
    os.makedirs('/tmp/claude-0/-home-user/4ad0e2d2-ad5c-5fec-98a7-be09d5f63b1b/scratchpad/an/cache',exist_ok=True); pickle.dump(g,open(c,'wb'))
    return g
def corners(p):
    x,y,f,bw,bd=p['x'],p['y'],p['f'],p['bw'],p['bd']
    r=math.radians(f); c,s=math.cos(r),math.sin(r)
    return [(x+dd*c-dw*s,y+dd*s+dw*c) for dw,dd in((-bw/2,-bd/2),(bw/2,-bd/2),(bw/2,bd/2),(-bw/2,bd/2))]
def segd(p,a,b):
    ax,ay=a;bx,by=b;px,py=p;dx,dy=bx-ax,by-ay;L=dx*dx+dy*dy
    t=0 if L==0 else max(0,min(1,((px-ax)*dx+(py-ay)*dy)/L))
    return math.hypot(px-ax-t*dx,py-ay-t*dy)
def gap(p,q):
    if not p or not q: return None
    A=corners(p);B=corners(q);m=1e9
    for i in range(4):
        for j in range(4):
            m=min(m,segd(A[i],B[j],B[(j+1)%4]),segd(B[j],A[i],A[(i+1)%4]))
    return m

def inarc(p,q):
    """any corner of q within the 90 degree front arc of p (from p's front centre, a little generous)"""
    if not p or not q: return None
    r=math.radians(p['f']); fx=p['x']+math.cos(r)*p['bd']/2; fy=p['y']+math.sin(r)*p['bd']/2
    best=999
    pts=corners(q)+[(q['x'],q['y'])]
    for (x,y) in pts:
        b=math.degrees(math.atan2(y-p['y'],x-p['x'])); d=abs((b-p['f']+180)%360-180); best=min(best,d)
    return best<=50

import json,glob,os,re,collections,sys
D='/root/jb'
TAGS=('SET-UP SPOT','JOINT AS ONE','CARRIES OUT CLOSE-IN','NO CHARGE WHY')
C=collections.Counter(); CH=collections.Counter(); WHY=collections.Counter(); G=collections.Counter()
RNG={}  # (file,unit name, side)-> max charge range
for f in sorted(glob.glob(D+'/*/game-*.log.jsonl')):
  if '/parts/' in f: continue
  arm=f.split('/')[-2].split('-')[0]; fix='Mine' if arm=='mine' else 'Opponent'
  G[arm]+=1
  for l in open(f):
    if '"OpponentRule"' not in l: continue
    try: a=json.loads(l)
    except ValueError: continue
    s=a.get('summary') or ''
    for t in TAGS:
      if s.startswith(t+':'):
        b='on' if a['side']==fix else 'off'
        C[(t,b)]+=1
        if ' | CHANGED' in s: CH[(t,b)]+=1
        if t=='NO CHARGE WHY':
          m=re.match(r'NO CHARGE WHY: [^:]*: ([a-z ]+):',s); WHY[(m.group(1) if m else '?',b)]+=1
          m=re.search(r'it charges up to ([\d.]+)"',s)
          if m: RNG[(f,a['side'],a.get('actor'))]=float(m.group(1))
json.dump({f"{k[0]}|{k[1]}|{k[2]}":v for k,v in RNG.items()},open(os.path.dirname(os.path.abspath(__file__))+'/rng-units.json','w'))
ng=sum(G.values())
print('games',dict(G))
for t in TAGS:
  print(f"{t}: on {C[(t,'on')]} ({C[(t,'on')]/ng:.2f}/game, changed {CH[(t,'on')]} = {CH[(t,'on')]/ng:.2f}/game) | off {C[(t,'off')]} (changed {CH[(t,'off')]})")
print('NO CHARGE WHY classes (on / off):')
ks=sorted(set(k for k,_ in WHY),key=lambda k:-(WHY[(k,'on')]+WHY[(k,'off')]))
ton=sum(v for (k,b),v in WHY.items() if b=='on'); toff=sum(v for (k,b),v in WHY.items() if b=='off')
for k in ks: print(f"| {k} | {WHY[(k,'on')]} ({WHY[(k,'on')]/max(1,ton):.0%}) | {WHY[(k,'off')]} ({WHY[(k,'off')]/max(1,toff):.0%}) |")

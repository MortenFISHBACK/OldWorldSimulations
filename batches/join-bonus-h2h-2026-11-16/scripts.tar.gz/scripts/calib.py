# Per-fight rows with the first round read from the "Fights the combat: ..." line that names the fight's units (not from whatever
# Combat-phase line mentions them first).
import sys, os, glob, json, re, collections, importlib.util
S=os.path.expanduser("~/an")
spec=importlib.util.spec_from_file_location("cb", S+"/cb.py"); cb=importlib.util.module_from_spec(spec); spec.loader.exec_module(cb)
H='/mnt/project-files/join-bonus-h2h-2026-11-16'
RES=re.compile(r"Combat result: Mine (-?\d+) vs Opponent (-?\d+)"); W=re.compile(r"(\d+) wound\(s\)"); SE=re.compile(r"(\d+) wounds? caused to (.+)$")
def parts_of(text, names):
    body=text[len("Fights the combat: "):]
    found=set()
    # exact names, longest first, so "Gors" does not match inside "Gors (Obsidian Lodestone)"
    rest=' and '+body.replace(' against ',' and ')+' and '
    for n in sorted(names,key=len,reverse=True):
        k=' and '+n+' and '
        while k in rest:
            found.add(n); rest=rest.replace(k,' and  and ',1)
    return found
rows=[]; seen=set(); nolines=0
for arm, fwside in (("mine","Mine"),("opp","Opponent")):
    dirs=sorted(set(os.path.dirname(x) for x in [g for g in glob.glob(f"{H}/{arm}-*/games.csv")+glob.glob(f"{H}/{arm}-*/*/games.csv") if "/parts/" not in g]))
    for p in dirs:
        for path in sorted(glob.glob(p+"/game-*.log.jsonl")):
            key=(arm,os.path.basename(path))
            if key in seen: continue
            seen.add(key)
            actions=[]; board=None
            for line in open(path):
                try: d=json.loads(line)
                except ValueError: continue
                if d.get("kind")=="action": actions.append(d)
                elif d.get("kind")=="board": board=d
            U={u["n"]:u for u in board["units"]}
            side_of={n:u["s"] for n,u in U.items()}
            ischar=lambda n:(U.get(n,{}).get('lk') or {}).get('tt')=='Character'
            units={n:{"side":s} for n,s in side_of.items()}
            fights=cb._game_fights(actions, units)
            odds=cb._static_odds(actions)
            combat=[a for a in actions if a.get("phase")=="Combat"]
            # the rounds of the game: (start id, participants, lines, result action)
            rounds=[]; cur=None
            for a in combat:
                s=a.get("summary") or ""
                if a.get("type")=="Computer" and s.startswith("Fights the combat: "):
                    cur=dict(id=a["id"],turn=a["turn"],names=parts_of(s,U.keys()),lines=[],res=None,pre=[]); rounds.append(cur)
                elif cur is not None and cur["res"] is None:
                    if a.get("type")=="CombatResult": cur["res"]=a
                    else: cur["lines"].append(a)
            # challenge lines come before "Fights the combat": keep the Combat lines since the previous result for each round
            last=0
            for r in rounds:
                r["pre"]=[a for a in combat if last<a["id"]<r["id"]]
                last=r["res"]["id"] if r["res"] else r["id"]
            for f in fights:
                f["odds"]=cb._fight_odds(f, odds)
                own=[odds.get((f["side"],f["turn"],ch,f["target"]),(None,))[0] for ch in f["chargers"]]
                start=min(a["id"] for a in actions if a.get("type")=="Charge" and a.get("turn")==f["turn"] and a.get("side")==f["side"] and a.get("target")==f["target"] and "made contact" in (a.get("summary") or ""))
                arcs=[re.search(r"in its (front|flank|rear)", (a.get("summary") or "")) for a in actions if a.get("type")=="Charge" and a.get("turn")==f["turn"] and a.get("side")==f["side"] and a.get("target")==f["target"] and "made contact" in (a.get("summary") or "")]
                inches=[re.search(r"\((\d+) full inch", (a.get("summary") or "")) for a in actions if a.get("type")=="Charge" and a.get("turn")==f["turn"] and a.get("side")==f["side"] and a.get("target")==f["target"] and "made contact" in (a.get("summary") or "")]
                side=f["side"]; other="Opponent" if side=="Mine" else "Mine"
                rd=next((r for r in rounds if r["id"]>start and (f["target"] in r["names"] or any(c in r["names"] for c in f["chargers"]))),None)
                row=dict(brain="fix" if side==fwside else "off", odds=f["odds"], own=own, n=len(f["chargers"]), game=key[1], arm=arm, path=path, start=start, side=side,
                         turn=f["turn"], target=f["target"], chargers=f["chargers"], arc=[m.group(1) if m else None for m in arcs], inches=[int(m.group(1)) if m else None for m in inches],
                         joins=any("joins the fight" in (a.get("summary") or "") and a.get("turn")==f["turn"] and a.get("side")==side and f["target"] in (a.get("summary") or "") and any((a.get("summary") or "").startswith("Objective for "+c+":") for c in f["chargers"]) for a in actions if a.get("type")=="Computer"))
                if rd is None or rd["res"] is None:
                    # no round fought: why? (target fled or was destroyed before the Combat phase, game ended)
                    row.update(res="none"); rows.append(row); continue
                text=rd["res"].get("summary") or ""; m=RES.search(text)
                sc=(int(m.group(1)),int(m.group(2))) if m else None
                if sc and side=="Opponent": sc=(sc[1],sc[0])
                res="win" if f"{side} wins" in text else "draw" if "draw" in text.lower() else "loss"
                wounds={side:0,other:0}; kinds=collections.Counter(); spells=[]
                for s in rd["lines"]:
                    t=s.get("type"); sm=s.get("summary") or ""
                    if t in("CombatAttack","ImpactHits","StompAttacks","TreeWhack","TrollVomit"):
                        mm=W.search(sm); nn=int(mm.group(1)) if mm else 0; sd=side_of.get(s.get("actor"))
                        if sd: wounds[sd]+=nn; kinds[("mine" if sd==side else "their")+":"+t]+=nn
                    elif t=="SpellEffect":
                        mm=SE.search(sm)
                        if mm and side_of.get(mm.group(2).strip()):
                            sd=other if side_of[mm.group(2).strip()]==side else side
                            wounds[sd]+=int(mm.group(1)); kinds[("mine" if sd==side else "their")+":Spell"]+=int(mm.group(1))
                names=rd["names"]
                atk=[s for s in rd["lines"] if s.get("type")=="CombatAttack" and s.get("actor") in f["chargers"]]
                allp=rd["pre"]+rd["lines"]
                row.update(res=res, score=sc, auto="automatically" in text, text=text[:160], round_turn_same=(rd["turn"]==f["turn"]),
                    mine=sorted(n for n in names if side_of[n]==side), their=sorted(n for n in names if side_of[n]==other),
                    mine_units=sorted(n for n in names if side_of[n]==side and (not ischar(n) or n in f["chargers"])),
                    their_units=sorted(n for n in names if side_of[n]==other and (not ischar(n) or n==f["target"])),
                    their_chars=sorted(n for n in names if side_of[n]==other and ischar(n) and n!=f["target"]),
                    w_mine=wounds[side], w_their=wounds[other], kinds=dict(kinds),
                    lines=len(atk), at_char=sum(1 for s in atk if ischar(s.get("target")) and s.get("target")!=f["target"]),
                    chall_acc=any(s.get("type")=="ChallengeAccepted" for s in allp), retired=[s.get("actor") for s in allp if s.get("type")=="ChallengeRetired"],
                    chall_issued=[s.get("side") for s in allp if s.get("type")=="ChallengeIssued"],
                    duel=[n for s in allp if s.get("type") in("ChallengeAccepted","ChallengeIssued") for n in [s.get("actor")] if n],
                    spells_enemy=sum(1 for s in rd["lines"] if s.get("type")=="SpellCast" and s.get("side")!=side),
                    spellw_enemy=kinds.get("their:Spell",0), spellw_mine=kinds.get("mine:Spell",0),
                    stomp=sum(1 for s in rd["lines"] if s.get("type")=="StompAttacks" and s.get("actor") in f["chargers"]),
                    impact=sum(1 for s in rd["lines"] if s.get("type")=="ImpactHits" and s.get("actor") in f["chargers"]),
                    noenemy=[(s.get("summary") or "")[:90] for s in rd["lines"] if s.get("type")=="NoEnemyToStrike"],
                    fear_failed=sum(1 for s in allp if s.get("type")=="FearTest" and "failed" in (s.get("summary") or "") and s.get("side")==side),
                    round_id=rd["id"], res_id=rd["res"]["id"])
                # old readings for comparison
                rows.append(row)
        print(p, len(rows), file=sys.stderr, flush=True)
# unit info
boards={}
for x in rows:
    p=x['path']
    if p not in boards:
        with open(p) as fh:
            for l in fh:
                d=json.loads(l)
                if d.get('kind')=='board': boards[p]=d; break
    b=boards[p]; U={u['n']:u for u in b['units']}
    x['army']=b['mine'] if x['side']=='Mine' else b['opponent']; x['enemy_army']=b['opponent'] if x['side']=='Mine' else b['mine']
    def info(n):
        u=U.get(n)
        if not u: return None
        lk=u.get('lk') or {}
        return dict(tt=lk.get('tt'),rt=lk.get('rt'),mc=lk.get('mc'),w=lk.get('w'),cn=lk.get('cn'))
    x['ci']=[info(c) for c in x['chargers']]; x['ti']=info(x['target'])
json.dump(rows, open(S+"/out/fights.json","w"))
print(len(rows), collections.Counter(r['res'] for r in rows))

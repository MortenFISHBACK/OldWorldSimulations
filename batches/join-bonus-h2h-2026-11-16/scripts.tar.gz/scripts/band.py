import json,glob,os,re,collections
D='/root/jb'
F=json.load(open('out/fights.json')); N=json.load(open('out/net.json'))
idx=collections.defaultdict(list)
for x in F: idx[(x['arm'],x['game'],x['side'],x['turn'],x['target'])].append(x)
R=re.compile(r"CHARGE BAND: .*?(?:charge on|charge) #\d+ (.+?): win (\d+)% alone, (\d+)% (?:together|with it)")
rows=[]
for f in sorted(glob.glob(D+'/*/game-*.log.jsonl')):
  arm=os.path.basename(os.path.dirname(f)).split('-')[0]; g=os.path.basename(f)
  for l in open(f):
    if 'CHARGE BAND' not in l or '"OpponentRule"' not in l: continue
    d=json.loads(l); m=R.search(d['summary'])
    if not m: print('NOMATCH',d['summary'][:200]); continue
    tgt,alone,tog=m.group(1),int(m.group(2)),int(m.group(3))
    fx=idx.get((arm,g,d['side'],d['turn'],tgt),[])
    nt=N.get(f"{arm}|{g}|{d['side']}|{d['turn']}|{tgt}")
    rows.append(dict(arm=arm,g=g,side=d['side'],turn=d['turn'],phase=d['phase'],tgt=tgt,alone=alone,tog=tog,
      fought=bool(fx),res=fx[0]['res'] if fx else None,said=fx[0]['odds'] if fx else None,chargers=len(fx[0]['chargers']) if fx else None,net=nt))
print(len(rows),'rows;',collections.Counter(r['phase'] for r in rows))
u={(r['arm'],r['g'],r['side'],r['turn'],r['tgt']):r for r in rows}
print(len(u),'distinct charges')
fo=[r for r in u.values() if r['fought']]
print('fought',len(fo),collections.Counter(r['res'] for r in fo),'chargers',collections.Counter(r['chargers'] for r in fo))
nets=[r['net'] for r in fo if r['net']]
if nets:
  cp=sum(n['cp'] for n in nets); net=sum(n['won']-n['lost'] for n in nets)
  print('net a fight %+.0f, per 100 charger pts %+.0f, avg cp %.0f tp %.0f, said avg %.0f'%(net/len(nets),100*net/cp,cp/len(nets),sum(n['tp'] for n in nets)/len(nets),sum(r['said'] or 0 for r in fo)/max(1,sum(r['said'] is not None for r in fo))))
print('alone avg %.0f together avg %.0f'%(sum(r['alone'] for r in u.values())/len(u),sum(r['tog'] for r in u.values())/len(u)))
for r in u.values(): print(r['arm'],r['g'][5:16],r['side'],r['turn'],r['phase'],r['tgt'][:28],r['alone'],r['tog'],r['res'],r['said'],r['chargers'],(r['net'] or {}).get('won'),(r['net'] or {}).get('lost'))

# Doctrine scorecard: jb-h2h-opp-b54c226-p3

### Scorecard: jb-h2h-opp-b54c226-p3

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0110 | 2 | 1 | Mine | - | - | 3 | 1 | 2 | 0 | 0 | 0 | 0 |
| L0110 | 2 | 1 | Opponent | - | - | 2 | 3 | 0 | 0 | 0 | 0 | 330 |
| L0126 | 6 | 1 | Mine | no | 4 | 3 | 3 | 2 | 0 | 0 | 0 | 65 |
| L0126 | 6 | 1 | Opponent | no | 10 | 3 | 3 | 3 | 0 | 0 | 0 | 0 |
| L0210 | 6 | 1 | Mine | no | 0 | 2 | 0 | 4 | 0 | 0 | 0 | 0 |
| L0210 | 6 | 1 | Opponent | no | 11 | 3 | 2 | 0 | 0 | 0 | 0 | 330 |
| L0226 | 4 | 1 | Mine | no | 1 | 2 | 1 | 3 | 0 | 0 | 0 | 170 |
| L0226 | 4 | 1 | Opponent | no | 8 | 2 | 2 | 3 | 1 | 0 | 0 | 0 |
| L0311 | 5 | 1 | Mine | no | - | 5 | 2 | 1 | 0 | 0 | 0 | 590 |
| L0311 | 5 | 1 | Opponent | yes | - | 3 | 1 | 0 | 0 | 0 | 0 | 427 |
| L0327 | 3 | 1 | Mine | yes | 4 | 3 | 1 | 0 | 0 | 0 | 0 | 590 |
| L0327 | 3 | 1 | Opponent | no | 4 | 4 | 2 | 2 | 2 | 0 | 0 | 0 |
| L0413 | 5 | 1 | Mine | yes | - | 2 | 4 | 2 | 0 | 0 | 0 | 0 |
| L0413 | 5 | 1 | Opponent | no | - | 2 | 2 | 1 | 2 | 0 | 0 | 317 |
| L0429 | 3 | 1 | Mine | yes | 4 | 2 | 2 | 2 | 0 | 0 | 0 | 0 |
| L0429 | 3 | 1 | Opponent | no | 2 | 2 | 4 | 0 | 0 | 0 | 0 | 170 |
| L0516 | 6 | 1 | Mine | no | 0 | 4 | 1 | 0 | 0 | 0 | 0 | 666 |
| L0516 | 6 | 1 | Opponent | no | 2 | 2 | 3 | 1 | 0 | 0 | 0 | 200 |
| L0533 | 5 | 1 | Mine | no | - | 5 | 0 | 0 | 0 | 0 | 0 | 548 |
| L0533 | 5 | 1 | Opponent | yes | - | 2 | 2 | 5 | 0 | 0 | 0 | 0 |
| L0620 | 2 | 1 | Mine | - | - | 3 | 3 | 0 | 0 | 0 | 0 | 929 |
| L0620 | 2 | 1 | Opponent | - | - | 4 | 0 | 4 | 0 | 0 | 0 | 210 |
| L0709 | 1 | 1 | Mine | yes | 3 | 4 | 3 | 0 | 1 | 0 | 0 | 420 |
| L0709 | 1 | 1 | Opponent | no | 2 | 2 | 1 | 1 | 0 | 0 | 0 | 420 |
| L0725 | 5 | 1 | Mine | yes | - | 3 | 3 | 1 | 0 | 0 | 0 | 613 |
| L0725 | 5 | 1 | Opponent | yes | - | 2 | 5 | 0 | 0 | 0 | 0 | 0 |
| L0815 | 5 | 1 | Mine | yes | - | 6 | 1 | 1 | 0 | 0 | 0 | 515 |
| L0815 | 5 | 1 | Opponent | yes | - | 2 | 3 | 1 | 1 | 0 | 0 | 115 |
| L0831 | 3 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 807 |
| L0831 | 3 | 1 | Opponent | no | 2 | - | 0 | 2 | 1 | 0 | 0 | 170 |
| L0922 | 4 | 1 | Mine | no | 0 | - | 0 | 0 | 0 | 0 | 0 | 677 |
| L0922 | 4 | 1 | Opponent | no | 0 | 2 | 5 | 1 | 1 | 0 | 0 | 0 |
| L1013 | 5 | 1 | Mine | yes | - | 2 | 2 | 1 | 2 | 0 | 0 | 330 |
| L1013 | 5 | 1 | Opponent | no | - | 1 | 1 | 3 | 0 | 0 | 0 | 302 |
| L1030 | 4 | 1 | Mine | no | 1 | 2 | 2 | 0 | 1 | 0 | 0 | 501 |
| L1030 | 4 | 1 | Opponent | no | 0 | 2 | 2 | 2 | 2 | 0 | 0 | 0 |
| L1122 | 6 | 1 | Mine | no | 0 | - | 0 | 0 | 1 | 0 | 0 | 330 |
| L1122 | 6 | 1 | Opponent | no | 3 | 2 | 3 | 2 | 1 | 0 | 0 | 72 |
| L1216 | 4 | 1 | Mine | no | 0 | 2 | 3 | 0 | 1 | 0 | 0 | 330 |
| L1216 | 4 | 1 | Opponent | no | 0 | 2 | 3 | 0 | 0 | 0 | 0 | 200 |
| L1232 | 2 | 1 | Mine | - | - | 2 | 2 | 0 | 0 | 0 | 0 | 330 |
| L1232 | 2 | 1 | Opponent | - | - | 3 | 2 | 4 | 0 | 0 | 0 | 340 |
| L1327 | 1 | 1 | Mine | no | 4 | 4 | 1 | 0 | 1 | 0 | 0 | 140 |
| L1327 | 1 | 1 | Opponent | no | 4 | 1 | 5 | 1 | 0 | 0 | 0 | 0 |
| L1422 | 6 | 1 | Mine | no | 5 | 3 | 2 | 1 | 0 | 0 | 0 | 177 |
| L1422 | 6 | 1 | Opponent | no | 2 | 2 | 6 | 1 | 1 | 0 | 0 | 0 |
| L1519 | 1 | 1 | Mine | no | 3 | 2 | 5 | 1 | 0 | 0 | 0 | 0 |
| L1519 | 1 | 1 | Opponent | no | 0 | 2 | 5 | 1 | 1 | 0 | 0 | 161 |
| L1535 | 5 | 1 | Mine | yes | - | 3 | 3 | 1 | 0 | 0 | 0 | 0 |
| L1535 | 5 | 1 | Opponent | yes | - | 2 | 4 | 3 | 1 | 0 | 0 | 0 |
| L1633 | 1 | 1 | Mine | yes | 2 | 2 | 1 | 1 | 0 | 0 | 0 | 200 |
| L1633 | 1 | 1 | Opponent | no | 1 | 1 | 3 | 3 | 1 | 0 | 0 | 549 |
| L1731 | 3 | 1 | Mine | yes | 1 | 4 | 1 | 0 | 0 | 0 | 0 | 0 |
| L1731 | 3 | 1 | Opponent | no | 2 | 2 | 2 | 1 | 3 | 0 | 0 | 170 |
| L1831 | 1 | 1 | Mine | no | 2 | 3 | 5 | 1 | 1 | 0 | 0 | 0 |
| L1831 | 1 | 1 | Opponent | no | 2 | - | 0 | 0 | 0 | 0 | 0 | 0 |
| L1932 | 6 | 1 | Mine | no | 0 | 2 | 5 | 0 | 1 | 0 | 0 | 235 |
| L1932 | 6 | 1 | Opponent | no | 1 | 2 | 2 | 2 | 2 | 0 | 0 | 340 |
| L2033 | 5 | 1 | Mine | no | - | 6 | 1 | 5 | 1 | 0 | 0 | 210 |
| L2033 | 5 | 1 | Opponent | yes | - | 6 | 1 | 4 | 0 | 0 | 0 | 0 |
| L2223 | 3 | 1 | Mine | no | 1 | 1 | 4 | 0 | 2 | 0 | 0 | 170 |
| L2223 | 3 | 1 | Opponent | no | 0 | 2 | 6 | 0 | 1 | 0 | 0 | 0 |
| L2327 | 5 | 1 | Mine | no | - | 2 | 5 | 1 | 1 | 0 | 0 | 0 |
| L2327 | 5 | 1 | Opponent | yes | - | 2 | 3 | 4 | 0 | 0 | 0 | 0 |
| L2433 | 3 | 1 | Mine | no | 1 | 3 | 5 | 0 | 0 | 0 | 0 | 0 |
| L2433 | 3 | 1 | Opponent | no | 0 | 2 | 2 | 1 | 1 | 0 | 0 | 0 |
| L2630 | 2 | 1 | Mine | - | - | 2 | 5 | 0 | 0 | 0 | 0 | 0 |
| L2630 | 2 | 1 | Opponent | - | - | 2 | 6 | 1 | 1 | 0 | 0 | 0 |
| L2832 | 6 | 1 | Mine | no | 0 | 2 | 2 | 0 | 0 | 0 | 0 | 0 |
| L2832 | 6 | 1 | Opponent | no | 0 | 2 | 3 | 2 | 0 | 0 | 0 | 139 |
| L3133 | 1 | 1 | Mine | no | 7 | 2 | 0 | 1 | 0 | 0 | 0 | 120 |
| L3133 | 1 | 1 | Opponent | no | 7 | 4 | 2 | 1 | 0 | 0 | 0 | 405 |
| **Average** | | | Mine | 31% | 1.9 | 2.9 | 2.2 | 0.9 | 0.4 | 0.0 | 0.0 | 268.4 |
| **Average** | | | Opponent | 22% | 2.7 | 2.3 | 2.8 | 1.7 | 0.6 | 0.0 | 0.0 | 149.1 |

### KPIs: jb-h2h-opp-b54c226-p3

Rules off - Mine only: JOINS A FRIEND.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 23% (40 of 174) | 13% (22 of 175) | 18% (62 of 349) |
| Winner chose to follow up after the loser gave ground |  | 92% (49 of 53); on the table 96% | 98% (43 of 44); on the table 98% | 95% (92 of 97); on the table 97% |
| Winner chose to pursue after the loser fell back in good order |  | 100% (10 of 10); on the table 100% | 82% (9 of 11); on the table 82% | 90% (19 of 21); on the table 90% |
| Winner chose to pursue after the loser fled |  | 83% (20 of 24); on the table 96% | 76% (16 of 21); on the table 86% | 80% (36 of 45); on the table 91% |
| Winner chose to follow up or pursue (all three) |  | 91% (79 of 87); on the table 97% | 89% (68 of 76); on the table 92% | 90% (147 of 163); on the table 94% |
| Magic missiles tried each own turn | 50%+ | 32% (110 of 342) | 47% (91 of 192) | 38% (201 of 534) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 46% (110 of 240) | 58% (91 of 157) | 51% (201 of 397) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 61% (14 of 23) | 51% (33 of 65) | 53% (47 of 88) |
| Points that never fought | lower | 34% (23222 of 68801) | 41% (29850 of 71990) | 38% (53072 of 140791) |
|   infantry points that never fought | lower | 41% (5761 of 14174) | 60% (8475 of 14220) | 50% (14236 of 28394) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 58% (158 of 272) | 58% (164 of 285) | 58% (322 of 557) |
| Bound items with a magic missile used (at least once a game) |  | 100% (25 of 25); 2.2 uses a game | 88% (21 of 24); 1.9 uses a game | 94% (46 of 49); 2.1 uses a game |
| Bound items with another spell used |  | 36% (5 of 14); 0.3 uses a game | 33% (2 of 6); 0.1 uses a game | 35% (7 of 20); 0.2 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 65% (13 of 20); 0.4 uses a game | 43% (6 of 14); 0.2 uses a game | 56% (19 of 34); 0.3 uses a game |
|   their share of the points of units over 100 pts | lower | 54% (32137 of 59391) | 51% (32631 of 64043) | 52% (64768 of 123434) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.6 (24%) | 0.8 (29%) | 2.4 (26%) |
| MARCHED: its unit marched | 1.4 (22%) | 0.7 (24%) | 2.1 (23%) |
| CHARGED: its unit charged | 0.4 (6%) | 0.2 (9%) | 0.6 (7%) |
| IN COMBAT: engaged in combat | 1.3 (20%) | 0.5 (18%) | 1.8 (19%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.1 (4%) | 0.1 (2%) |
| FLEEING: fleeing | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) |
| GONE: slain | 1.3 (21%) | 0.3 (12%) | 1.7 (18%) |
| OFF THE TABLE: off the table or not arrived | 0.2 (3%) | 0.1 (4%) | 0.3 (4%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| NOT OFFERED: not in the cast list | 0.1 (2%) | 0.0 (0%) | 0.1 (2%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 5.0 | 1.1 | 1.7 | 5.6 | 0.9 | 1.6 |
| not cast | 3.8 | 1.5 | 4.4 | 9.2 | 2.4 | 19.1 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) | 1.2 (7%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.1 (1%) | 0.6 (40%) | 0.4 (10%) | 2.4 (26%) | 0.3 (12%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.1 (23%) | 0.3 (13%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.6 (7%) | 0.1 (4%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.2 (6%) | 0.1 (7%) | 0.6 (14%) | 1.8 (19%) | 0.3 (14%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.2 (4%) | 0.0 (0%) | 0.3 (6%) | 0.1 (2%) | 0.1 (4%) | 0.0 (0%) |
| FLEEING: fleeing | 0.1 (1%) | 0.0 (2%) | 0.0 (1%) | 0.0 (0%) | 0.0 (0%) | 0.2 (1%) |
| GONE: slain | 1.2 (32%) | 0.4 (25%) | 1.2 (28%) | 1.7 (18%) | 0.7 (29%) | 3.2 (17%) |
| OFF THE TABLE: off the table or not arrived | 0.1 (1%) | 0.1 (5%) | 0.1 (2%) | 0.3 (4%) | 0.2 (8%) | 0.5 (3%) |
| STUPIDITY: Stupidity | 0.0 (1%) | 0.0 (0%) | 0.1 (2%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.2 (4%) | 0.0 (2%) | 0.0 (0%) | 0.1 (1%) | 0.4 (16%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (2%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.8 (48%) | 0.3 (18%) | 1.6 (36%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 14.0 (73%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.3 a game | 0.6 a game | 0.9 a game |
| stood (cast and not dispelled) | 62% (24 of 39) | 47% (7 of 15) | 57% (31 of 54) |
| the unit moved after it | 79% (19 of 24) | 86% (6 of 7) | 81% (25 of 31) |
| it charged on its next turn | 4% (1 of 24) | 14% (1 of 7) | 6% (2 of 31) |
| the enemy charged it first | 21% (5 of 24) | 29% (2 of 7) | 23% (7 of 31) |
| it fought by the end of its next turn | 12% (3 of 24) | 14% (1 of 7) | 13% (4 of 31) |
| it moved out of a charge the enemy had planned (not charged first) | 46% (11 of 24) | 14% (1 of 7) | 39% (12 of 31) |
| none of these (no charge, no fight, no charge escaped) | 29% (7 of 24) | 43% (3 of 7) | 32% (10 of 31) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 65% (497 of 765) | 56% (351 of 625) | 61% (848 of 1390) |
|   cavalry | 61% (36 of 59) | 57% (65 of 114) | 58% (101 of 173) |
|   character | 64% (56 of 87) | 22% (26 of 119) | 40% (82 of 206) |
|   chariot | 43% (43 of 99) | 46% (11 of 24) | 44% (54 of 123) |
|   infantry | 58% (127 of 219) | 64% (174 of 272) | 61% (301 of 491) |
|   monster | 33% (12 of 36) | 20% (1 of 5) | 32% (13 of 41) |
|   war machine | 84% (223 of 265) | 81% (74 of 91) | 83% (297 of 356) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.5 (33%) | 1.8 (24%) | 4.3 (29%) |
| CHARGED: it charged | 0.8 (10%) | 1.4 (18%) | 2.2 (14%) |
| FLEEING: it fled or was fleeing | 0.1 (1%) | 0.2 (3%) | 0.3 (2%) |
| IN COMBAT: it fought this turn or the last | 0.8 (10%) | 0.6 (8%) | 1.3 (9%) |
| MOVED: a war machine that moved | 0.1 (1%) | 0.0 (0%) | 0.1 (0%) |
| NO TARGET IN RANGE | 1.0 (14%) | 1.0 (13%) | 2.0 (13%) |
| ONLY IN COMBAT: the only targets were in combat | 0.2 (3%) | 0.9 (11%) | 1.1 (7%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.4 (18%) | 1.4 (18%) | 2.8 (18%) |
| SHELTERED: the target was sheltered | 0.3 (4%) | 0.1 (2%) | 0.4 (3%) |
| STUPIDITY | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR | 0.4 (5%) | 0.2 (3%) | 0.6 (4%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 4.5 | 1.2 | 79% | 7.7 pts | 34 pts |
| character | 2.8 | 1.2 | 73% | 7.3 pts | 20 pts |
| chariot | 1.5 | 1.1 | 65% | 19.3 pts | 29 pts |
| infantry | 12.9 | 4.5 | 75% | 8.8 pts | 113 pts |
| monster | 0.4 | 0.2 | 79% | 22.7 pts | 9 pts |
| war machine | 8.7 | 7.8 | 59% | 23.3 pts | 203 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.9 | 5.2 | 4.5 |
| Charges that made contact a game | 2.7 | 3.8 | 3.2 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.58 declared, 0.42 contact (26 units) | 1.15 declared, 0.77 contact (13 units) | 0.77 declared, 0.54 contact (39 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.25 declared, 0.25 contact (4 units) | 0.90 declared, 0.60 contact (10 units) | 0.71 declared, 0.50 contact (14 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.55 declared, 0.38 contact (222 units) | 0.60 declared, 0.45 contact (268 units) | 0.58 declared, 0.42 contact (490 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 44% (34 of 77) | 47% (7 of 15) | 60% (6 of 10) | 46% (47 of 102) |
| Character in a unit | 92% (35 of 38) | 53% (9 of 17) | 60% (3 of 5) | 78% (47 of 60) |
| Character on its own | 79% (31 of 39) | 46% (18 of 39) | 33% (23 of 70) | 49% (72 of 148) |
| Chariot | 91% (10 of 11) | 75% (9 of 12) | - | 83% (19 of 23) |
| Infantry | 59% (41 of 70) | 48% (20 of 42) | 20% (1 of 5) | 53% (62 of 117) |
| Monster | 68% (23 of 34) | 57% (4 of 7) | - | 66% (27 of 41) |
| Monstrous | 70% (7 of 10) | 82% (9 of 11) | - | 76% (16 of 21) |
| War Machines | 70% (30 of 43) | 100% (2 of 2) | - | 71% (32 of 45) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 100% (7 of 7); on the table 100% | 40% (38 of 96) | 16% | 59% (13 of 22) | 100% (6 of 6); 5.8 uses a game | 50% (1 of 2); 1.0 uses a game | 67% (4 of 6); 1.0 uses a game |
| Chaos Dwarfs | 4 | 67% (10 of 15); on the table 93% | 42% (15 of 36) | 38% | 56% (18 of 32) | 0.0 uses a game | 0.0 uses a game | 100% (2 of 2); 0.5 uses a game |
| Dwarfen Mountain Holds | 3 | 100% (2 of 2); on the table 100% | - | 51% | 75% (18 of 24) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 6 | 100% (7 of 7); on the table 100% | 50% (15 of 30) | 53% | 68% (40 of 59) | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game | 25% (1 of 4); 0.2 uses a game |
| Grand Cathay | 8 | 87% (13 of 15); on the table 93% | 40% (76 of 192) | 43% | 58% (43 of 74) | 94% (17 of 18); 6.6 uses a game | 50% (2 of 4); 0.4 uses a game | 62% (5 of 8); 0.6 uses a game |
| High Elf Realms | 7 | 94% (16 of 17); on the table 94% | 29% (12 of 42) | 31% | 50% (27 of 54) | 100% (9 of 9); 4.4 uses a game | 33% (4 of 12); 1.0 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 3 | 91% (10 of 11); on the table 100% | - | 35% | 28% (5 of 18) | 0.0 uses a game | 0.0 uses a game | 100% (3 of 3); 1.0 uses a game |
| Lizardmen | 1 | 100% (3 of 3); on the table 100% | 67% (4 of 6) | 22% | 71% (5 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 1 | 100% (4 of 4); on the table 100% | 0% (0 of 6) | 68% | 71% (5 of 7) | 100% (1 of 1); 5.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 2 | 100% (9 of 9); on the table 100% | 8% (1 of 12) | 2% | 75% (12 of 16) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.5 uses a game |
| Skaven | 2 | 100% (5 of 5); on the table 100% | 8% (1 of 12) | 60% | 50% (7 of 14) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.5 uses a game |
| Tomb Kings of Khemri | 6 | 83% (10 of 12); on the table 83% | 17% (1 of 6) | 36% | 42% (11 of 26) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 8 | 100% (16 of 16); on the table 100% | 37% (20 of 54) | 30% | 59% (27 of 46) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 11 | 87% (27 of 31); on the table 90% | 50% (15 of 30) | 39% | 54% (52 of 96) | 100% (4 of 4); 1.0 uses a game | 0.0 uses a game | 100% (2 of 2); 0.2 uses a game |
| Wood Elf Realms | 6 | 89% (8 of 9); on the table 89% | 25% (3 of 12) | 43% | 63% (39 of 62) | 82% (9 of 11); 4.7 uses a game | 0.0 uses a game | 0% (0 of 5); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (jb-h2h-opp-b54c226-p3, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 56% (50) | 46% (30) | 52% (80) |
| ...free all their last turn and able to turn (per game) | 1.00 | 0.53 | 1.53 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.22 | 0.14 | 0.36 |
| ...with the charger already in that arc before they moved (per game) | 0.72 | 0.44 | 1.17 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 1.97 | 1.28 | 3.25 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 1.14 | 0.75 | 1.89 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 6.31 | 6.28 | 12.58 |

### Quality by phase: jb-h2h-opp-b54c226-p3

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.2 | 3.6 |
| Strategy | Charge objectives carried out (made contact) | 54% (67 of 123) | 51% (81 of 159) |
| Strategy | Shoot objectives carried out (shot that target) | 47% (176 of 376) | 47% (103 of 218) |
| Strategy | Close-in objectives charged next turn | 15% (24 of 159) | 12% (27 of 218) |
| Strategy | Support requests answered (helper made contact too) | 53% (8 of 15) | 52% (14 of 27) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (3 of 3) | 100% (2 of 2) |
| Strategy | Hexes on a unit its side charged or shot that turn | 33% (4 of 12) | 67% (2 of 3) |
| Strategy | Joined characters whose unit fought | 67% (31 of 46) | 16% (7 of 44) |
| Strategy | Lone characters that fought | 74% (66 of 89) | 80% (72 of 90) |
| Movement | Charges halted short of contact | 0.2 | 0.2 |
| Movement | Idle units | 0.9 | 1.7 |
| Movement | Points that never moved of their own | 268.4 | 149.1 |
| Movement | Fights charged into per game | 2.3 | 3.2 |
| Movement | Charges with odds: long shots (under 50%) | 7 of 76, net +30 | 22 of 103, net +21 |
| Movement | Charges with odds: sweet spot (55-75%) | 12 of 76, net +87 | 15 of 103, net +32 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 7 of 76, net +214 | 6 of 103, net +56 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 24 of 76, net +69 | 28 of 103, net +186 |
| Shooting | Shots by shooting units (incl. breath weapons) | 8.3 | 9.4 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 43% (127 of 298) | 46% (154 of 338) |
| Shooting | Points destroyed by shooting units | 33.1 | 64.6 |
| Shooting | War machine shots | 6.2 | 2.5 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 52% (115 of 223) | 42% (38 of 90) |
| Shooting | Points destroyed by war machines | 58.2 | 29.9 |
| Magic | Magic missiles cast | 2.0 | 1.5 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 43% (31 of 72) | 38% (21 of 55) |
| Magic | Wounds caused by magic missiles | 4.1 | 2.5 |
| Magic | Wounds caused by other spells | 1.4 | 1.2 |
| Magic | Points destroyed by magic (all spells) | 107.4 | 53.3 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.7 / 0.3 / 0.6 / 0.2 | 2.0 / 0.1 / 0.3 / 0.3 |
| Combat | Points destroyed in combat | 359.8 | 352.7 |
| Combat | Points run down | 73.9 | 110.1 |
| Combat | Net points per charged fight, damage counted | +101 | +81 |
| Combat | Net per 100 charger points, damage counted | +34.8 | +28.4 |
| Combat | First round won (charged fights) | 79% | 71% |
| Combat | Net points per charged fight | +99 | +74 |
| Combat | Net points per supported fight / lone fight | +116 / +96 | +152 / +64 |
| Combat | Charged fights on a top-3 enemy unit | 29 of 84 | 61 of 117 |
| Game | Points lost | 743.9 | 674.9 |
| Game | VP from objectives | 561.7 | 542.8 |
| Game | Lone holders (player turns) | 1.9 | 2.7 |

- Mine won / drew / lost: 13 / 13 / 10 of 36 ended games (of 36); mean margin (Mine - Opponent) -25 VP
- The side that went first won 11 of 23 games with a winner
- Points traded per game (both sides' losses): 1419
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: jb-h2h-opp-b54c226-p3

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.6 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 0.0 |
| ALREADY CARRIED | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARRIVAL HUNT | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +0.3 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.6 | +0.0 | 0.0 | 30.1 | 0.2 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | 1.0 | +6.9 | 0.0 | 50.5 | 0.9 | +6.7 | 0.0 | 22.2 |
| BEST FACING | 0.9 | +52.5 | 0.0 | 26.2 | 0.4 | +28.5 | 0.0 | 21.2 |
| BEST FIRST | 4.7 | +196.5 | 209.1 | 115.3 | 3.4 | +153.5 | 93.1 | 29.9 |
| BEST OVERALL | 1.0 | +63.2 | 0.0 | 11.2 | 0.3 | +27.4 | 0.0 | 0.0 |
| BEST PREY | 0.8 | +43.6 | 15.7 | 16.8 | 0.9 | +28.1 | 11.5 | 0.0 |
| BEST PRIZE | - | - | - | - | 0.1 | -0.7 | 0.0 | 1.7 |
| BIG CHARACTER SAFETY | 0.2 | -1.3 | 0.0 | 21.5 | 0.2 | -1.7 | 0.0 | 0.0 |
| BLOCKED CHARGE SKIPPED | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| BLOCKED WHEEL | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +8.1 | 0.0 | 0.0 |
| BLOWS WHERE AIMED | 0.4 | -47.2 | 56.6 | 15.4 | 0.2 | -39.5 | 13.8 | 0.0 |
| CANNON PLAN MISSED | 0.5 | +0.0 | 21.6 | 3.1 | 0.2 | +0.0 | 55.9 | 0.0 |
| CANNON PLANNED TARGET | 5.5 | +145.3 | 288.1 | 133.9 | 1.5 | +80.6 | 130.6 | 18.9 |
| CANNON SIGHT KEPT | 1.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT COUNTER | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CARRIES OUT SET-UP | 0.3 | -9.7 | 51.7 | 15.4 | 0.1 | +0.0 | 0.0 | 3.2 |
| CAST JOB | 1.1 | +29.7 | 92.9 | 11.1 | 0.4 | +11.4 | 30.0 | 17.4 |
| CASTER AWAY FROM SCREEN | 0.2 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.3 | +27.2 | 13.6 | 0.0 | 0.1 | +2.4 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 0.7 | +0.0 | 0.0 | 55.1 | 0.3 | +0.0 | 0.0 | 11.1 |
| CASTS FROM BEHIND | 0.0 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CATCH ODDS | 0.1 | +1.5 | 0.0 | 7.2 | - | - | - | - |
| CHAFF PASSED | 0.3 | -0.8 | 0.0 | 14.4 | 0.1 | -0.2 | 0.0 | 0.0 |
| CHARGE BAND | 0.1 | +0.0 | 13.6 | 4.5 | 0.1 | +0.0 | 13.4 | 0.0 |
| CHARGE NOW FIRST | 2.3 | +0.0 | 225.9 | 96.8 | 2.2 | +0.0 | 196.7 | 146.8 |
| CHARGE NOW WEIGHED | 0.9 | -87.1 | 56.6 | 32.8 | 0.6 | -45.3 | 10.2 | 26.9 |
| CHARGER SLAIN LOST | 0.5 | -15.3 | 37.6 | 18.5 | 0.8 | -17.4 | 33.4 | 67.5 |
| CHARIOT NO STATIC JOB | 0.1 | +0.0 | 0.0 | 2.4 | - | - | - | - |
| CHARIOT WIZARD CAREFUL | 0.0 | -0.8 | 0.0 | 0.0 | 0.2 | -2.1 | 0.0 | 11.1 |
| CHEAP HELPER | 0.1 | +0.0 | 0.0 | 5.0 | 0.1 | +0.0 | 7.7 | 2.0 |
| COMBAT PIVOT | 0.6 | +0.0 | 23.8 | 53.1 | 0.4 | +0.0 | 34.8 | 9.4 |
| CONTINUE AHEAD WEIGHED | 0.1 | +0.0 | 3.2 | 0.0 | - | - | - | - |
| CONVEYANCE SEARCH | 0.7 | +83.7 | 31.4 | 36.2 | 0.3 | +27.3 | 22.2 | 28.7 |
| COUNTER-CHARGE COVER | 9.9 | +839.9 | 0.0 | 246.5 | 7.2 | +609.3 | 0.0 | 136.5 |
| DEFENSIVE ARMY | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 10.6 | 6.6 |
| EDGE GIVE GROUND | 0.3 | +16.9 | 13.1 | 4.0 | 0.2 | +8.3 | 10.6 | 17.9 |
| ELIXIR WORTH | 0.1 | +0.9 | 0.0 | 8.2 | - | - | - | - |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 2.0 | +164.4 | 0.0 | 48.8 | 1.3 | +121.3 | 0.0 | 53.2 |
| FALLBACK BY WORTH | 5.0 | +97.4 | 0.0 | 45.9 | 5.8 | +56.6 | 0.0 | 31.7 |
| FIGHT LIFT | - | - | - | - | 0.0 | +0.5 | 13.1 | 0.0 |
| FIRE AND FLEE | 0.0 | +0.4 | 2.9 | 2.2 | - | - | - | - |
| FLANK NOT WEIGHED | 6.9 | +0.0 | 0.0 | 168.9 | 6.0 | +0.0 | 0.0 | 114.8 |
| FOCUS FIRE | 0.0 | +0.4 | 3.9 | 0.0 | 0.0 | +1.0 | 1.8 | 0.0 |
| FOLLOW UP WEIGHED | 1.0 | +145.0 | 0.0 | 53.7 | 1.1 | +160.6 | 0.0 | 23.2 |
| FRIENDS SHOTS CHECKED | 0.2 | +8.4 | 0.0 | 16.1 | 0.2 | +27.4 | 0.0 | 0.0 |
| GIVES UP | 0.1 | -1.0 | 7.9 | 0.0 | 0.1 | -0.2 | 7.7 | 0.0 |
| GIVES UP ITS SCREEN | - | - | - | - | 0.1 | -0.9 | 0.0 | 0.0 |
| GROUND FLIERS | 0.1 | +7.0 | 0.0 | 0.0 | - | - | - | - |
| HELPER ALREADY ASKED | 0.0 | +0.0 | 7.6 | 4.5 | 0.1 | +0.0 | 10.3 | 0.0 |
| HELPER UNSEEN | 0.4 | +0.0 | 31.7 | 17.0 | 0.3 | +0.0 | 33.2 | 5.0 |
| HILL BY ITS CHANCE | 0.2 | -28.8 | 0.0 | 0.0 | 0.5 | -78.9 | 0.0 | 2.2 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 7.2 | -132.4 | 443.8 | 195.0 | 7.8 | -206.7 | 407.3 | 181.1 |
| HORN WORTH | - | - | - | - | 0.0 | +0.4 | 0.0 | 0.0 |
| HUNT ADVANCE | 0.2 | +12.2 | 9.2 | 6.2 | 0.1 | +2.7 | 0.0 | 0.0 |
| HUNT DROPPED | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 3.5 | 0.0 |
| HUNT IN PAIRS | 0.4 | +13.8 | 0.0 | 21.4 | 0.7 | +53.3 | 0.0 | 8.5 |
| HUNT KEPT | 0.1 | +5.7 | 4.6 | 3.9 | 0.1 | +1.1 | 0.0 | 1.5 |
| HUNT RESULT | 0.2 | +9.3 | 0.0 | 3.9 | 0.3 | +26.0 | 31.5 | 3.9 |
| HUNT THE GUNS | 0.2 | +67.0 | 4.6 | 3.8 | 0.3 | +109.7 | 27.8 | 5.4 |
| INVITES THE FIGHT | 1.6 | +27.7 | 30.1 | 35.9 | 1.1 | +15.9 | 53.4 | 14.7 |
| JOINS A FRIEND | - | - | - | - | 3.1 | +15.7 | 87.5 | 41.2 |
| JOINT CHARGE PLAN | 0.1 | +2.7 | 0.0 | 3.2 | 0.4 | +16.8 | 10.3 | 3.2 |
| JOINT KNOWS CHALLENGE | - | - | - | - | 0.1 | -9.2 | 15.5 | 3.2 |
| KEEP FALLS | 0.1 | +3.7 | 0.0 | 0.0 | 0.0 | +0.1 | 0.0 | 0.0 |
| KEEPS ITS PREY | 0.0 | +0.6 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| KEEPS ITS TARGET | 1.6 | +46.7 | 150.6 | 74.5 | 1.9 | +58.3 | 141.6 | 52.0 |
| KEEPS SCOUTS OR AMBUSH | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KILLS COUNT | 1.5 | +71.2 | 94.9 | 55.5 | 1.6 | +90.5 | 156.6 | 33.8 |
| KILLS COUNT NEXT TURN | 5.1 | +158.0 | 188.4 | 145.4 | 7.1 | +237.7 | 156.3 | 81.3 |
| LONE CHARACTER SAFE SPOT | 0.3 | +12.0 | 7.5 | 5.8 | 0.5 | +13.6 | 18.4 | 38.6 |
| LONE WIZARD HOLDS BACK | 0.1 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 0.0 |
| LONE WIZARD KEPT IN | 0.6 | +37.3 | 0.0 | 0.0 | 0.4 | +25.4 | 0.0 | 0.0 |
| LONG SHOT | 0.4 | +2.2 | 19.4 | 8.4 | 0.1 | +0.4 | 3.1 | 1.2 |
| LOST CHARGE | 2.8 | -51.9 | 168.0 | 136.5 | 2.6 | -40.6 | 68.4 | 53.5 |
| LURE BY WHAT IT DRAWS | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MAKE SURE TOGETHER | 1.1 | +132.7 | 65.0 | 20.9 | 0.8 | +65.7 | 23.6 | 17.6 |
| MANOEUVRE | 0.2 | +3.9 | 0.0 | 1.5 | 0.2 | +8.3 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.1 | +1.3 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| MARCH CHECK | 0.8 | +45.3 | 0.0 | 12.8 | 0.6 | +29.9 | 0.0 | 0.0 |
| MARCH ODDS | 0.4 | +16.2 | 4.8 | 6.5 | 0.3 | +18.2 | 16.3 | 10.9 |
| MARCH OVER CASTS | 0.6 | +35.0 | 0.0 | 26.2 | 0.3 | +8.2 | 0.0 | 22.2 |
| MAX FOR POSITIONING | 5.0 | +199.7 | 0.0 | 171.0 | 4.1 | +174.2 | 0.0 | 98.3 |
| MISSILES IN THE MOVE | 4.5 | +142.4 | 0.0 | 121.6 | 4.1 | +63.6 | 0.0 | 80.1 |
| MISSILES NEXT TURN | 5.4 | +96.0 | 0.0 | 130.3 | 5.1 | +54.4 | 0.0 | 102.1 |
| MODEL FACING | 0.1 | +29.2 | 0.0 | 0.0 | - | - | - | - |
| MONSTER WIZARD ROAMS | 0.2 | +0.0 | 19.0 | 12.1 | 0.2 | +0.0 | 10.3 | 0.0 |
| MOVE AND CAST | 0.4 | +34.0 | 0.0 | 0.0 | 0.4 | +27.8 | 0.0 | 31.0 |
| MOVE SPELL IN RANGE | 0.3 | +8.9 | 0.0 | 21.1 | - | - | - | - |
| MOVE SPELL NOT WORTH | 0.0 | -0.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.6 | -15.8 | 0.0 | 33.6 | 0.1 | -0.8 | 2.9 | 20.6 |
| MOVE SPELL SPOT | 0.4 | +0.0 | 0.0 | 21.1 | 0.1 | +0.0 | 0.0 | 11.1 |
| MOVE TO CHARGE | 3.0 | +258.0 | 172.8 | 110.1 | 4.2 | +387.0 | 97.0 | 69.4 |
| MOVES UNITS SPELL | 0.1 | +3.6 | 0.0 | 0.0 | 0.1 | +0.3 | 0.0 | 0.0 |
| NEEDED THERE | 0.1 | +5.9 | 6.5 | 0.0 | - | - | - | - |
| NOT NEEDED | 0.1 | -11.1 | 15.8 | 17.9 | 0.1 | -5.7 | 6.3 | 0.0 |
| NOT TURNED | 6.3 | +118.3 | 0.0 | 144.4 | 6.3 | +107.8 | 0.0 | 87.1 |
| NOT WORTH A CAST | 0.5 | -0.4 | 0.0 | 21.1 | 0.7 | -0.8 | 0.0 | 0.0 |
| OFF BEST | 15.8 | -822.0 | 10.9 | 244.2 | 15.0 | -885.3 | 18.5 | 205.2 |
| OPENS A LANE | 0.1 | +0.3 | 4.4 | 10.5 | 0.1 | +0.4 | 7.7 | 20.5 |
| OPENS UP | 0.1 | +3.2 | 3.7 | 0.0 | 0.1 | +7.0 | 4.7 | 5.4 |
| OVERRUNS AWAY | 0.4 | +4.9 | 57.2 | 4.0 | 0.3 | +10.3 | 16.2 | 16.2 |
| PATHS CROSS | 1.8 | +133.7 | 0.0 | 59.3 | 2.4 | +160.5 | 0.0 | 11.5 |
| PERIAPT WORTH | - | - | - | - | 0.0 | +1.5 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.1 | -1.1 | 0.0 | 5.1 | 0.1 | -3.1 | 0.0 | 5.4 |
| PLAN RESULT | 36.3 | +1276.5 | 1237.2 | 1022.2 | 37.4 | +1361.4 | 1465.5 | 781.4 |
| PURSUES BIG PREY | 0.1 | -7.1 | 0.0 | 0.0 | 0.1 | -1.5 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE | - | - | - | - | 0.0 | +4.9 | 0.0 | 1.5 |
| RAIDS THE BAGGAGE NEXT TURN | 0.1 | +8.2 | 0.0 | 0.0 | 0.1 | +3.5 | 0.0 | 1.5 |
| RANDOM MOVE BY FIGURES | 0.6 | +7.8 | 0.0 | 14.2 | 1.8 | +32.0 | 0.0 | 37.8 |
| RANDOM MOVER NO PROMISE | 0.0 | -1.2 | 0.0 | 0.0 | 0.3 | -15.8 | 6.2 | 0.0 |
| REDIRECT BY WHAT IT STOPS | 0.4 | -5.4 | 0.0 | 0.0 | 0.8 | +2.3 | 0.0 | 5.4 |
| REDIRECT COUNTER | 1.7 | +125.1 | 0.0 | 40.9 | 3.5 | +290.7 | 0.0 | 42.5 |
| REDIRECT WEIGHED | 0.2 | +0.9 | 3.5 | 0.0 | 0.4 | +2.2 | 7.4 | 19.3 |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 3.2 | 0.4 | +0.0 | 0.0 | 3.2 |
| RESERVE FALL BACK | 0.4 | +9.0 | 0.0 | 4.1 | 1.0 | +45.8 | 0.0 | 17.6 |
| RESTRAINS TO SHOOT | 0.1 | +1.9 | 0.0 | 3.2 | 0.1 | +2.0 | 0.0 | 0.0 |
| RISK BY ARC | 2.1 | +64.7 | 189.9 | 89.0 | 2.9 | +88.8 | 213.2 | 117.8 |
| SAFER THAN THE JOB | 1.1 | +77.6 | 0.0 | 15.7 | 0.8 | +44.0 | 0.0 | 3.3 |
| SCOUT SPOT | 0.4 | +0.6 | 0.0 | 0.9 | 0.3 | +1.0 | 0.0 | 0.0 |
| SCOUT WAITS | 0.4 | +0.0 | 0.0 | 0.9 | 0.3 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.1 | -2.2 | 0.0 | 0.9 | 0.1 | -7.9 | 0.0 | 1.1 |
| SEARCH SPOT | 2.6 | +135.4 | 0.0 | 74.3 | 2.3 | +90.3 | 0.0 | 83.4 |
| SECOND HUNTER | 0.0 | -1.2 | 0.0 | 0.0 | - | - | - | - |
| SELF MOVE SPELL | 0.3 | +38.8 | 0.0 | 40.1 | 0.2 | +54.8 | 0.0 | 9.1 |
| SET UP TOGETHER | 1.4 | +150.3 | 65.0 | 27.4 | 1.7 | +142.6 | 23.6 | 45.9 |
| SET-UP ANY TARGET | 0.4 | +73.4 | 31.4 | 26.4 | 0.2 | +26.2 | 11.1 | 17.6 |
| SET-UP MISSED | 0.1 | +6.2 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | 0.4 | +0.7 | 0.0 | 0.0 | 0.1 | +0.3 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.1 | +54.5 | 63.0 | 4.8 | 0.7 | +21.8 | 17.5 | 9.4 |
| SHORT GUN FORWARD | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SHOT REPLANNED | 0.3 | +0.0 | 39.1 | 15.8 | 0.2 | +0.0 | 31.9 | 1.7 |
| SHOTS IN THE MOVE | 14.0 | +501.7 | 0.0 | 273.2 | 9.5 | +355.5 | 0.0 | 86.3 |
| SPELL SETS UP CHARGE | 0.5 | +98.4 | 31.4 | 26.4 | 0.2 | +30.4 | 22.2 | 28.7 |
| SPELL WORTH | 1.4 | +19.6 | 16.1 | 35.7 | 2.3 | +34.6 | 124.9 | 105.9 |
| SPELLS IN THE FIGHT | 0.3 | -1.3 | 39.6 | 13.4 | 0.7 | -20.8 | 57.2 | 71.6 |
| STABLE ROLE | 10.5 | +0.0 | 310.8 | 173.1 | 8.6 | +0.0 | 244.2 | 146.2 |
| STANDS TO CAST | 0.1 | +3.6 | 0.0 | 10.2 | - | - | - | - |
| STOPS | 0.1 | +4.2 | 0.0 | 1.5 | 0.3 | +6.8 | 27.8 | 6.9 |
| STOPS SHORT OF THE FLANK | 0.6 | +24.1 | 0.0 | 41.4 | 0.3 | +20.2 | 0.0 | 0.0 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 4.7 |
| SUPPORT NARROWED | 5.1 | -45.6 | 237.0 | 160.4 | 6.8 | -61.0 | 377.6 | 191.3 |
| SUPPORTS | 3.4 | +51.0 | 107.8 | 93.3 | 4.6 | +63.5 | 218.2 | 62.1 |
| SURE CHARGE BEATS ADVANCE | 0.2 | -3.8 | 17.2 | 15.1 | 0.1 | -3.2 | 12.1 | 0.0 |
| SURE REACH TOGETHER | 0.6 | +7.1 | 15.2 | 11.4 | 0.5 | -4.2 | 2.9 | 11.1 |
| THROUGH LINE OF FIRE | 0.6 | +20.2 | 0.0 | 10.0 | 0.2 | +20.8 | 0.0 | 0.0 |
| TURN WORTH | 0.2 | -12.5 | 12.8 | 1.9 | 0.2 | -15.7 | 25.5 | 2.9 |
| TWO OR MORE ARRIVE | 0.4 | +3.5 | 21.2 | 6.3 | 0.5 | +5.1 | 20.7 | 15.4 |
| WAIT AFTER COSTS | 6.8 | -314.7 | 292.2 | 173.1 | 6.7 | -357.2 | 188.6 | 101.1 |
| WALKS TO THE FIGHT | 1.4 | +27.9 | 29.4 | 11.0 | 0.7 | +8.3 | 15.9 | 14.0 |
| WAR ENGINE CHARGES | 0.0 | +3.6 | 0.0 | 0.0 | - | - | - | - |
| WAR ENGINE JOBS | 0.6 | +0.0 | 29.4 | 21.2 | 0.2 | +0.0 | 0.0 | 3.8 |
| WEARS DOWN | 1.3 | +53.6 | 144.6 | 46.3 | 1.2 | +58.0 | 61.9 | 82.2 |
| WHO HITS BACK | 0.3 | +19.2 | 0.0 | 6.4 | 0.2 | +5.7 | 0.0 | 4.2 |
| WHOLE FIGHT | 0.2 | +8.2 | 33.9 | 19.0 | 0.4 | +26.2 | 53.4 | 2.8 |
| WHOLE FIGHT GAIN | 0.4 | +44.0 | 65.6 | 7.7 | 0.6 | +23.6 | 33.9 | 25.9 |
| WIDER SPREAD | 2.1 | -4.6 | 220.7 | 68.7 | 2.9 | -5.4 | 252.2 | 91.4 |
| WOUNDED STAYS OUT | - | - | - | - | 0.0 | +0.0 | 2.9 | 0.0 |

### Rule changes: jb-h2h-opp-b54c226-p3

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 1106 | 1106 | 1106 | 30.72 | -61465 | -55.6 |
| BEST FIRST | 293 | 293 | 293 | 8.14 | +12601 | +43.0 |
| SEARCH SPOT | 179 | 179 | 178 | 4.94 | +8142 | +45.7 |
| PATHS CROSS | 149 | 149 | 149 | 4.14 | +10593 | +71.1 |
| COUNTER-CHARGE COVER | 619 | 330 | 146 | 4.06 | +9007 | +61.7 |
| KILLS COUNT NEXT TURN | 437 | 437 | 128 | 3.56 | +3037 | +23.7 |
| MOVE TO CHARGE | 261 | 261 | 128 | 3.56 | +9471 | +74.0 |
| FACES THE THREAT | 117 | 117 | 117 | 3.25 | +10286 | +87.9 |
| SUPPORTS | 291 | 291 | 115 | 3.19 | +1135 | +9.9 |
| FALLBACK BY WORTH | 386 | 386 | 84 | 2.33 | +5545 | +66.0 |
| FOLLOW UP WEIGHED | 74 | 74 | 74 | 2.06 | +10998 | +148.6 |
| SHOTS IN THE MOVE | 847 | 577 | 72 | 2.00 | +1877 | +26.1 |
| WAIT AFTER COSTS | 486 | 486 | 69 | 1.92 | +1070 | +15.5 |
| SAFER THAN THE JOB | 68 | 68 | 68 | 1.89 | +4380 | +64.4 |
| ARTILLERY RE-ROLL WEIGHED | 67 | 67 | 67 | 1.86 | +0 | +0.0 |
| CANNON SIGHT KEPT | 56 | 56 | 56 | 1.56 | +0 | +0.0 |
| CHARGE NOW WEIGHED | 52 | 52 | 52 | 1.44 | +3415 | +65.7 |
| MAX FOR POSITIONING | 330 | 173 | 52 | 1.44 | +460 | +8.8 |
| RESERVE FALL BACK | 51 | 51 | 51 | 1.42 | +1975 | +38.7 |
| BEST FACING | 50 | 50 | 50 | 1.39 | +2913 | +58.3 |
| RANDOM MOVE BY FIGURES | 88 | 88 | 47 | 1.31 | +1432 | +30.5 |
| BEST OVERALL | 46 | 46 | 46 | 1.28 | +3260 | +70.9 |
| SET UP TOGETHER | 112 | 95 | 45 | 1.25 | +3285 | +73.0 |
| MARCH CHECK | 49 | 47 | 42 | 1.17 | +2443 | +58.2 |
| MISSILES IN THE MOVE | 311 | 156 | 40 | 1.11 | +425 | +10.6 |
| WALKS TO THE FIGHT | 77 | 77 | 40 | 1.11 | +588 | +14.7 |
| HOLDS AMBUSHERS | 39 | 39 | 39 | 1.08 | +0 | +0.0 |
| REDIRECT COUNTER | 187 | 101 | 37 | 1.03 | +2706 | +73.1 |
| CANNON PLANNED TARGET | 253 | 253 | 36 | 1.00 | -437 | -12.2 |
| ADVANCE LANE KEPT | 35 | 35 | 35 | 0.97 | +0 | +0.0 |
| RISK BY ARC | 179 | 176 | 35 | 0.97 | +970 | +27.7 |
| SHOOTS FROM THE BEST SPOT | 65 | 65 | 35 | 0.97 | +1156 | +33.0 |
| CHARGE NOW FIRST | 163 | 163 | 34 | 0.94 | -2242 | -66.0 |
| COMBAT PIVOT | 33 | 33 | 33 | 0.92 | +0 | +0.0 |
| LONE WIZARD KEPT IN | 33 | 33 | 33 | 0.92 | +2259 | +68.5 |
| STOPS SHORT OF THE FLANK | 33 | 33 | 33 | 0.92 | +1597 | +48.4 |
| MOVE AND CAST | 32 | 32 | 32 | 0.89 | +2227 | +69.6 |
| HONEST WORTH | 541 | 540 | 30 | 0.83 | +264 | +8.8 |
| THROUGH LINE OF FIRE | 29 | 29 | 29 | 0.81 | +1477 | +50.9 |
| CAST JOB | 55 | 55 | 27 | 0.75 | +462 | +17.1 |
| KILLS COUNT | 109 | 108 | 27 | 0.75 | +1244 | +46.1 |
| SCOUT WAITS | 25 | 25 | 25 | 0.69 | +0 | +0.0 |
| BEST PREY | 60 | 60 | 24 | 0.67 | +925 | +38.5 |
| BLOCKED WHEEL | 24 | 24 | 24 | 0.67 | +293 | +12.2 |
| KEEPS ITS TARGET | 126 | 125 | 24 | 0.67 | +397 | +16.5 |
| MARCH ODDS | 25 | 25 | 24 | 0.67 | +183 | +7.6 |
| REDIRECT WEIGHED | 22 | 22 | 22 | 0.61 | +855 | +38.9 |
| MAKE SURE TOGETHER | 70 | 50 | 21 | 0.58 | +1857 | +88.4 |
| INVITES THE FIGHT | 97 | 97 | 20 | 0.56 | +243 | +12.2 |
| SHOT REPLANNED | 20 | 20 | 20 | 0.56 | +0 | +0.0 |
| SHOOTERS IN TWO RANKS | 18 | 18 | 18 | 0.50 | +36 | +2.0 |
| BIG CHARACTER SAFETY | 17 | 17 | 17 | 0.47 | -108 | -6.3 |
| STUCK PIVOT | 16 | 16 | 16 | 0.44 | +0 | +0.0 |
| WHO HITS BACK | 16 | 16 | 16 | 0.44 | +658 | +41.1 |
| WEARS DOWN | 91 | 90 | 15 | 0.42 | +487 | +32.5 |
| CASTING BLOCK | 15 | 15 | 14 | 0.39 | +681 | +48.6 |
| CHAFF PASSED | 13 | 13 | 13 | 0.36 | -36 | -2.8 |
| FRIENDS SHOTS CHECKED | 13 | 13 | 13 | 0.36 | +1291 | +99.3 |
| HUNT IN PAIRS | 38 | 23 | 13 | 0.36 | +591 | +45.5 |
| WHOLE FIGHT GAIN | 33 | 32 | 13 | 0.36 | +724 | +55.7 |
| JOINS A FRIEND | 112 | 112 | 12 | 0.33 | +56 | +4.7 |
| MANOEUVRE | 16 | 16 | 12 | 0.33 | +440 | +36.6 |
| SURE CHARGE BEATS ADVANCE | 12 | 12 | 12 | 0.33 | -253 | -21.1 |
| WAR ENGINE JOBS | 26 | 26 | 11 | 0.31 | -186 | -16.9 |
| LOST CHARGE | 196 | 196 | 10 | 0.28 | +272 | +27.2 |
| REFUSING RETIRES | 26 | 26 | 10 | 0.28 | -3 | -0.3 |
| CASTER AWAY FROM SCREEN | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| CASTS FROM BEHIND | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| CHARGE BAND | 8 | 8 | 8 | 0.22 | +0 | +0.0 |
| PIVOT GUARDS FLANK | 8 | 8 | 8 | 0.22 | -150 | -18.8 |
| SUPPORT NARROWED | 429 | 429 | 8 | 0.22 | -185 | -23.1 |
| WHOLE FIGHT | 23 | 23 | 8 | 0.22 | +514 | +64.2 |
| WIDER SPREAD | 180 | 176 | 8 | 0.22 | +72 | +9.1 |
| MISSILES NEXT TURN | 377 | 195 | 7 | 0.19 | +9 | +1.3 |
| MOVES UNITS SPELL | 7 | 7 | 7 | 0.19 | +141 | +20.1 |
| EDGE GIVE GROUND | 17 | 17 | 6 | 0.17 | +492 | +82.0 |
| LONE WIZARD HOLDS BACK | 18 | 18 | 6 | 0.17 | -485 | -80.8 |
| OPENS UP | 7 | 7 | 6 | 0.17 | +75 | +12.4 |
| BLOCKED CHARGE SKIPPED | 5 | 5 | 5 | 0.14 | +0 | +0.0 |
| KEEP FALLS | 5 | 5 | 5 | 0.14 | +288 | +57.6 |
| PURSUES BIG PREY | 5 | 5 | 5 | 0.14 | -311 | -62.1 |
| RAIDS THE BAGGAGE NEXT TURN | 5 | 5 | 5 | 0.14 | +177 | +35.4 |
| RESTRAINS TO SHOOT | 5 | 5 | 5 | 0.14 | +139 | +27.8 |
| SHORT GUN FORWARD | 5 | 5 | 5 | 0.14 | +0 | +0.0 |
| CONTINUE AHEAD WEIGHED | 4 | 4 | 4 | 0.11 | +0 | +0.0 |
| MODEL FACING | 4 | 4 | 4 | 0.11 | +1053 | +263.2 |
| OVERRUNS AWAY | 25 | 25 | 4 | 0.11 | +53 | +13.2 |
| SURE REACH TOGETHER | 39 | 30 | 4 | 0.11 | +44 | +10.9 |
| CHARIOT NO STATIC JOB | 3 | 3 | 3 | 0.08 | -218 | -72.6 |
| HUNT ADVANCE | 10 | 10 | 3 | 0.08 | +166 | +55.5 |
| LONG SHOT | 19 | 19 | 3 | 0.08 | -9 | -2.9 |
| SPELLS IN THE FIGHT | 37 | 36 | 3 | 0.08 | +29 | +9.6 |
| STANDS TO CAST | 3 | 3 | 3 | 0.08 | -7 | -2.4 |
| BACKUP TARGETS | 67 | 27 | 2 | 0.06 | +15 | +7.3 |
| BEST PRIZE | 2 | 2 | 2 | 0.06 | -26 | -13.0 |
| CARRIES OUT SET-UP | 14 | 14 | 2 | 0.06 | -348 | -174.0 |
| CATCH ODDS | 2 | 2 | 2 | 0.06 | -15 | -7.3 |
| ELIXIR WORTH | 2 | 2 | 2 | 0.06 | +33 | +16.4 |
| FOCUS FIRE | 2 | 2 | 2 | 0.06 | +50 | +25.2 |
| NEEDED THERE | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| REDIRECT BY WHAT IT STOPS | 42 | 42 | 2 | 0.06 | +178 | +89.2 |
| STOPS | 15 | 15 | 2 | 0.06 | +61 | +30.5 |
| BLOWS WHERE AIMED | 25 | 24 | 1 | 0.03 | +160 | +159.7 |
| DEFENSIVE ARMY | 8 | 8 | 1 | 0.03 | -54 | -53.8 |
| FIRE AND FLEE | 1 | 1 | 1 | 0.03 | +15 | +15.1 |
| HORN WORTH | 1 | 1 | 1 | 0.03 | +14 | +13.5 |
| JOINT CHARGE PLAN | 17 | 17 | 1 | 0.03 | +12 | +11.9 |
| KEEPS SCOUTS OR AMBUSH | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.03 | +54 | +54.4 |
| RAIDS THE BAGGAGE | 1 | 1 | 1 | 0.03 | +156 | +155.7 |
| WOUNDED STAYS OUT | 1 | 1 | 1 | 0.03 | -21 | -21.0 |
| ALREADY CARRIED | 1 | not checked | - | - | - | - |
| ARRIVAL HUNT | 3 | 3 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 28 | 28 | 0 | 0.00 | - | - |
| CARRIES OUT COUNTER | 1 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 37 | trace | - | - | - | - |
| CHARGER SLAIN LOST | 48 | 48 | 0 | 0.00 | - | - |
| CHARIOT WIZARD CAREFUL | 7 | 7 | 0 | 0.00 | - | - |
| CHEAP HELPER | 6 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 37 | not checked | - | - | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT LIFT | 1 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 464 | not checked | - | - | - | - |
| GIVES UP | 4 | 4 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 2 | 2 | 0 | 0.00 | - | - |
| GROUND FLIERS | 3 | not checked | - | - | - | - |
| HELPER ALREADY ASKED | 3 | not checked | - | - | - | - |
| HELPER UNSEEN | 23 | 22 | 0 | 0.00 | - | - |
| HILL BY ITS CHANCE | 25 | 25 | 0 | 0.00 | - | - |
| HUNT DROPPED | 6 | trace | - | - | - | - |
| HUNT KEPT | 8 | trace | - | - | - | - |
| HUNT RESULT | 16 | trace | - | - | - | - |
| HUNT THE GUNS | 18 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 5 | 4 | 0 | 0.00 | - | - |
| KEEPS ITS PREY | 2 | 2 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 30 | not checked | - | - | - | - |
| LURE BY WHAT IT DRAWS | 1 | 1 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 5 | trace | - | - | - | - |
| MARCH OVER CASTS | 33 | 33 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 14 | 14 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 11 | 7 | 0 | 0.00 | - | - |
| MOVE SPELL NOT WORTH | 1 | not checked | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 25 | trace | - | - | - | - |
| MOVE SPELL SPOT | 21 | not checked | - | - | - | - |
| NOT NEEDED | 9 | 9 | 0 | 0.00 | - | - |
| NOT TURNED | 453 | 453 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 43 | not checked | - | - | - | - |
| OPENS A LANE | 9 | 2 | 0 | 0.00 | - | - |
| PLAN RESULT | 2654 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 13 | 13 | 0 | 0.00 | - | - |
| SCOUT SPOT | 24 | 24 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 7 | 7 | 0 | 0.00 | - | - |
| SECOND HUNTER | 1 | 1 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 17 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 23 | not checked | - | - | - | - |
| SET-UP MISSED | 2 | trace | - | - | - | - |
| SPELL SETS UP CHARGE | 28 | not checked | - | - | - | - |
| SPELL WORTH | 136 | not checked | - | - | - | - |
| STABLE ROLE | 688 | 686 | 0 | 0.00 | - | - |
| TURN WORTH | 14 | 14 | 0 | 0.00 | - | - |
| TWO OR MORE ARRIVE | 35 | 31 | 0 | 0.00 | - | - |
| WAR ENGINE CHARGES | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: jb-h2h-opp-b54c226-p3

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 14.00 | 12.81 | 57.2 |
| FALLBACK | gate | 0.69 | 0.78 | 47.3 |
| TURN GATE | gate | 0.64 | 0.61 | 32.6 |
| CHARGE NOW FIRST | rule | 0.47 | 0.44 | 67.9 |
| LONE CHARACTER SAFE SPOT | gate | 0.11 | 0.36 | 67.9 |
| CANNON PLANNED TARGET | rule | 0.25 | 0.08 | 52.6 |
| SURE CHARGE BEATS ADVANCE | rule | 0.19 | 0.14 | 21.1 |
| WAR ENGINE JOBS | rule | 0.25 | 0.03 | 18.5 |
| AFTERMATH BAND | gate | 0.03 | 0.22 | 2.1 |
| BIG CHARACTER SAFETY | rule | 0.14 | 0.11 | 13.9 |
| CHARGE NOW WEIGHED | rule | 0.19 | 0.06 | 45.5 |
| PIVOT GUARDS FLANK | rule | 0.14 | 0.08 | 18.8 |
| SUPPORT NARROWED | rule | 0.14 | 0.08 | 23.1 |
| SUPPORT REQUEST | gate | 0.06 | 0.14 | 131.5 |
| CHAFF PASSED | rule | 0.11 | 0.06 | 5.9 |
| LONE WIZARD HOLDS BACK | rule | 0.03 | 0.14 | 80.8 |
| FIGHT ORDER BAND | gate | 0.08 | 0.06 | 2.1 |
| PATHS CROSS | rule | 0.03 | 0.11 | 5.8 |
| PURSUES BIG PREY | rule | 0.08 | 0.06 | 62.1 |
| STOPS SHORT OF THE FLANK | rule | 0.11 | 0.03 | 13.1 |
| MARCH ODDS | rule | 0.06 | 0.06 | 15.9 |
| SAFER THAN THE JOB | rule | 0.03 | 0.08 | 15.0 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.08 | - | 43.0 |
| BLOCKED WHEEL | rule | 0.06 | 0.03 | 44.6 |
| CHARIOT NO STATIC JOB | rule | 0.08 | - | 72.6 |
| FALLBACK BY WORTH | rule | - | 0.08 | 7.7 |
| BEST PRIZE | rule | - | 0.06 | 13.0 |
| CARRIES OUT SET-UP | rule | 0.06 | - | 174.0 |
| CATCH ODDS | rule | 0.06 | - | 7.3 |
| RULE SWITCHED OFF | gate | 0.06 | - | 8.7 |
| DEFENSIVE ARMY | rule | - | 0.03 | 53.8 |
| LONG SHOT | rule | 0.03 | - | 38.0 |
| REFUSING RETIRES | rule | 0.03 | - | 0.7 |
| STANDS TO CAST | rule | 0.03 | - | 12.1 |
| THROUGH LINE OF FIRE | rule | 0.03 | - | 4.2 |
| WOUNDED STAYS OUT | rule | - | 0.03 | 21.0 |

### Plans: jb-h2h-opp-b54c226-p3

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 11.5 | 15% | 409 | 318 | 78% |
| Mine | charge | 3.0 | 56% | 299 | 254 | 85% |
| Mine | close in | 4.4 | 31% | 273 | 152 | 56% |
| Mine | hold | 4.2 | 39% | 267 | 0 | 0% |
| Mine | join | 0.3 | 75% | 8 | 0 | 0% |
| Mine | shoot | 9.1 | 60% | 194 | 552 | 285% |
| Mine | support | 3.8 | 89% | 33 | 0 | 0% |
| Opponent | advance | 12.2 | 15% | 332 | 319 | 96% |
| Opponent | charge | 3.8 | 61% | 306 | 399 | 130% |
| Opponent | close in | 6.0 | 20% | 375 | 163 | 43% |
| Opponent | hold | 4.0 | 38% | 282 | 0 | 0% |
| Opponent | join | 0.9 | 97% | 35 | 0 | 0% |
| Opponent | shoot | 5.1 | 61% | 182 | 481 | 264% |
| Opponent | support | 5.4 | 90% | 50 | 0 | 0% |

### Packages: hunt the guns, jb-h2h-opp-b54c226-p3

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.2 | 6 | 0 | 0% | 17% | 0% | 3.0 | 402 | 56 | 17% | 58 |
| Opponent | 0.3 | 12 | 2 | 30% | 30% | 0% | 2.0 | 358 | 94 | 30% | 48 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 1.2 | 5 | 0 | 0% | 20% | 0% | 3.0 | 391 | 67 | 20% | 56 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 145 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 32 |
| Empire of Man | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 458 | 0 | 0% | 63 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 102 |
| High Elf Realms | 0.1 | 1 | 0 | 0% | 0% | 0% | - | 506 | 0 | 0% | 25 |
| Kingdom of Bretonnia | 0.3 | 1 | 0 | 0% | 0% | 0% | - | 434 | 0 | 0% | 0 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Orc & Goblin Tribes | 0.5 | 1 | 0 | 0% | 0% | 0% | - | 441 | 0 | 0% | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 32 |
| Tomb Kings of Khemri | 0.7 | 4 | 1 | 33% | 33% | 0% | 2.0 | 408 | 180 | 33% | 44 |
| Vampire Counts | 0.4 | 3 | 1 | 100% | 100% | 0% | 2.0 | 235 | 198 | 100% | 45 |
| Warriors of Chaos | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 37 |
| Wood Elf Realms | 0.3 | 2 | 0 | 0% | 0% | 0% | - | 251 | 0 | 0% | 78 |

### Battle groups: jb-h2h-opp-b54c226-p3

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 9.9 | 21% | 59% | 8% | 50% | 38% | 6% | 6% | 51% | 0% |
| Mine | REDIRECT COUNTER | 1.7 | 32% | 75% | 5% | 0% | 21% | 5% | 5% | 68% | 0% |
| Opponent | COUNTER-CHARGE COVER | 7.2 | 18% | 61% | 7% | 0% | 35% | 9% | 9% | 47% | 0% |
| Opponent | REDIRECT COUNTER | 3.5 | 21% | 85% | 19% | 0% | 5% | 0% | 14% | 81% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: jb-h2h-opp-b54c226-p3

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 1 | 0 (1) | 0 | 0 | 100 | 0% | 4.0 | - | 0 (1) | - | 0 (1) | - |
| Mine | Chaff | 34 | 35 (34) | 7 | 28 | 63 | 35% | 2.5 | 50 (21) | 0 (4) | 10 (9) | 52 (24) | 0 (10) |
| Mine | Character | 118 | 46 (118) | 46 | 0 | 35 | 15% | 2.5 | 52 (37) | 50 (62) | 8 (7) | 38 (63) | 60 (43) |
| Mine | Clean-up | 18 | 52 (18) | 12 | 40 | 48 | 39% | 2.3 | 92 (3) | 36 (13) | 164 (2) | 63 (12) | 36 (6) |
| Mine | Fast | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Mine | Fast Hammer | 44 | 43 (44) | 33 | 10 | 56 | 20% | 2.7 | 46 (22) | 39 (14) | 41 (8) | 57 (30) | 18 (14) |
| Mine | Fragile | 3 | 19 (3) | 19 | 0 | 67 | 0% | 3.3 | 19 (3) | - | - | 29 (1) | 15 (2) |
| Mine | Hammer | 52 | 40 (52) | 22 | 18 | 34 | 12% | 3.2 | 14 (14) | 48 (35) | 58 (3) | 40 (36) | 39 (16) |
| Mine | Holder | 25 | 53 (25) | 5 | 48 | 11 | 44% | 3.1 | 53 (8) | 44 (13) | 97 (4) | 97 (12) | 12 (13) |
| Mine | Shooter | 37 | 68 (37) | 37 | 31 | 32 | 3% | 1.8 | 64 (6) | 74 (28) | 22 (3) | 65 (22) | 73 (15) |
| Mine | Support | 4 | 79 (4) | 79 | 0 | 0 | 25% | 2.0 | 0 (1) | 137 (3) | - | 25 (2) | 165 (2) |
| Mine | War machine | 52 | 27 (52) | 27 | 0 | 50 | 0% | 1.1 | 21 (13) | 26 (36) | 55 (3) | 28 (13) | 26 (39) |
| Mine | Wizard | 17 | 42 (17) | 42 | 0 | 38 | 6% | 2.7 | 25 (4) | 102 (8) | 10 (1) | 117 (6) | 16 (7) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 0% | 5.0 | - | 0 (1) | - | - | 0 (1) |
| Opponent | Chaff | 68 | 58 (68) | 24 | 35 | 52 | 40% | 2.8 | 68 (29) | 99 (11) | 30 (28) | 55 (48) | 68 (20) |
| Opponent | Character | 102 | 49 (102) | 49 | 0 | 34 | 21% | 2.3 | 52 (37) | 54 (51) | 16 (6) | 42 (53) | 61 (41) |
| Opponent | Clean-up | 11 | 48 (11) | 0 | 48 | 32 | 36% | 4.4 | 0 (4) | 54 (6) | 204 (1) | 33 (6) | 62 (5) |
| Opponent | Fast | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Fast Hammer | 60 | 44 (60) | 26 | 18 | 38 | 37% | 2.7 | 32 (30) | 44 (20) | 82 (10) | 48 (28) | 39 (32) |
| Opponent | Fragile | 3 | 0 (3) | 0 | 0 | 100 | 33% | 2.0 | - | 0 (2) | 0 (1) | 0 (2) | 0 (1) |
| Opponent | Hammer | 50 | 48 (50) | 34 | 14 | 42 | 34% | 2.8 | 16 (17) | 62 (30) | 7 (3) | 58 (30) | 32 (20) |
| Opponent | Holder | 40 | 64 (40) | 8 | 56 | 22 | 35% | 2.9 | 44 (8) | 90 (20) | 37 (11) | 77 (28) | 41 (11) |
| Opponent | Shooter | 27 | 64 (27) | 35 | 29 | 34 | 4% | 1.1 | 66 (6) | 44 (19) | 351 (2) | 90 (16) | 30 (11) |
| Opponent | Support | 4 | 0 (4) | 0 | 0 | 0 | 75% | 5.0 | 0 (1) | 0 (1) | 0 (2) | 0 (2) | 0 (2) |
| Opponent | War machine | 17 | 102 (17) | 102 | 0 | 24 | 0% | 1.4 | 142 (3) | 127 (10) | 26 (4) | 190 (3) | 87 (14) |
| Opponent | Wizard | 32 | 6 (32) | 6 | 0 | 33 | 16% | 2.0 | 10 (16) | 0 (8) | 0 (2) | 11 (13) | 0 (13) |

### Charged fights: jb-h2h-opp-b54c226-p3

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 65 | 59 | 1.5 | 1.2 | 39 | 0 | +39 | 1 of 6 | 5 of 6 | +135 | +20 |
| Mine | Chaos Dwarfs | 4 | 204 | 468 | 2.8 | 1.0 | 170 | 0 | +170 | 7 of 11 | 9 of 11 | - | +170 |
| Mine | Dwarfen Mountain Holds | 3 | 183 | 0 | 1.0 | 1.3 | 0 | 42 | -42 | 0 of 3 | 1 of 3 | +0 | -62 |
| Mine | Empire of Man | 5 | 325 | 141 | 1.0 | 1.0 | 141 | 0 | +141 | 2 of 5 | 5 of 5 | - | +141 |
| Mine | Grand Cathay | 5 | 540 | 179 | 2.0 | 1.2 | 90 | 20 | +69 | 6 of 10 | 9 of 10 | +0 | +86 |
| Mine | High Elf Realms | 4 | 161 | 547 | 2.8 | 1.0 | 199 | 0 | +199 | 5 of 11 | 9 of 11 | - | +199 |
| Mine | Kingdom of Bretonnia | 1 | 38 | 1208 | 4.0 | 1.8 | 302 | 0 | +302 | 0 of 4 | 3 of 4 | +203 | +600 |
| Mine | Lizardmen | 1 | 116 | 144 | 2.0 | 1.0 | 72 | 0 | +72 | 1 of 2 | 1 of 2 | - | +72 |
| Mine | Ogre Kingdoms | 1 | 116 | 0 | 3.0 | 1.0 | 0 | 130 | -130 | 0 of 3 | 2 of 3 | - | -130 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 340 | 4.0 | 1.2 | 85 | 14 | +71 | 2 of 4 | 2 of 4 | +0 | +95 |
| Mine | Skaven | 1 | 38 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 0 of 1 | 1 of 1 | - | +0 |
| Mine | Tomb Kings of Khemri | 2 | 0 | 183 | 3.0 | 1.0 | 61 | 0 | +61 | 1 of 6 | 4 of 6 | - | +61 |
| Mine | Vampire Counts | 2 | 118 | 714 | 6.0 | 1.4 | 119 | 12 | +107 | 3 of 12 | 10 of 12 | +138 | +96 |
| Mine | Warriors of Chaos | 2 | 10 | 358 | 3.0 | 1.5 | 119 | 148 | -28 | 1 of 6 | 5 of 6 | +172 | -129 |
| **Mine** | all armies | 36 | 199 | 281 | 2.3 | 1.2 | 120 | 22 | +99 | 29 of 84 | 66 of 84 | +116 | +96 |
| Opponent | Empire of Man | 1 | 618 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Grand Cathay | 3 | 485 | 184 | 2.3 | 1.4 | 79 | 0 | +79 | 3 of 7 | 6 of 7 | +234 | +17 |
| Opponent | High Elf Realms | 3 | 498 | 287 | 2.0 | 1.0 | 144 | 150 | -6 | 4 of 6 | 5 of 6 | - | -6 |
| Opponent | Kingdom of Bretonnia | 2 | 237 | 412 | 4.0 | 1.0 | 103 | 59 | +44 | 4 of 8 | 5 of 8 | - | +44 |
| Opponent | Orc & Goblin Tribes | 1 | 0 | 176 | 3.0 | 1.0 | 59 | 37 | +22 | 2 of 3 | 1 of 3 | - | +22 |
| Opponent | Skaven | 1 | 186 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 1 of 1 | 1 of 1 | - | +0 |
| Opponent | Tomb Kings of Khemri | 4 | 93 | 851 | 5.8 | 1.1 | 148 | 36 | +112 | 14 of 23 | 16 of 23 | +562 | +70 |
| Opponent | Vampire Counts | 6 | 23 | 375 | 4.3 | 1.2 | 87 | 29 | +57 | 14 of 26 | 18 of 26 | +27 | +64 |
| Opponent | Warriors of Chaos | 9 | 0 | 541 | 3.3 | 1.1 | 162 | 38 | +124 | 15 of 30 | 21 of 30 | +98 | +126 |
| Opponent | Wood Elf Realms | 6 | 97 | 235 | 2.2 | 1.2 | 109 | 111 | -2 | 4 of 13 | 10 of 13 | +70 | -24 |
| **Opponent** | all armies | 36 | 148 | 399 | 3.2 | 1.1 | 123 | 48 | +74 | 61 of 117 | 83 of 117 | +152 | +64 |

### Effective charges: jb-h2h-opp-b54c226-p3

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 6 | 0 | 0 | 0 | 2 (net +20) | 1 (net +0) | 1 (net +135) | 2 | 0% (0 of 4) |
| Mine | Chaos Dwarfs | 11 | 1 (net +0) | 0 | 2 (net +221) | 4 (net +272) | 0 | 3 (net +74) | 1 | 20% (2 of 10) |
| Mine | Dwarfen Mountain Holds | 3 | 1 (net +0) | 1 (net -65) | 0 | 1 (net -60) | 0 | 0 | 0 | 0% (0 of 3) |
| Mine | Empire of Man | 5 | 0 | 0 | 0 | 2 (net +238) | 0 | 2 (net +52) | 1 | 0% (0 of 4) |
| Mine | Grand Cathay | 10 | 0 | 1 (net -205) | 3 (net +105) | 2 (net +0) | 0 | 4 (net +145) | 0 | 30% (3 of 10) |
| Mine | High Elf Realms | 11 | 1 (net +104) | 1 (net +1225) | 2 (net +0) | 3 (net +103) | 2 (net +148) | 2 (net +128) | 0 | 18% (2 of 11) |
| Mine | Kingdom of Bretonnia | 4 | 2 (net +72) | 0 | 0 | 1 (net +464) | 1 (net +600) | 0 | 0 | 0% (0 of 4) |
| Mine | Lizardmen | 2 | 0 | 0 | 1 (net +0) | 1 (net +144) | 0 | 0 | 0 | 50% (1 of 2) |
| Mine | Ogre Kingdoms | 3 | 0 | 0 | 0 | 0 | 0 | 1 (net +0) | 2 | 0% (0 of 1) |
| Mine | Orc & Goblin Tribes | 4 | 1 (net +0) | 0 | 0 | 0 | 0 | 1 (net +0) | 2 | 0% (0 of 2) |
| Mine | Skaven | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +0) | 0 | 0% (0 of 1) |
| Mine | Tomb Kings of Khemri | 6 | 0 | 0 | 0 | 2 (net +98) | 1 (net +60) | 3 (net +37) | 0 | 0% (0 of 6) |
| Mine | Vampire Counts | 12 | 1 (net -40) | 1 (net -60) | 3 (net +95) | 1 (net -50) | 2 (net +272) | 4 (net +150) | 0 | 25% (3 of 12) |
| Mine | Warriors of Chaos | 6 | 0 | 1 (net +47) | 1 (net +0) | 2 (net +70) | 0 | 2 (net -178) | 0 | 17% (1 of 6) |
| Opponent | Grand Cathay | 7 | 0 | 1 (net +0) | 1 (net +0) | 2 (net +42) | 1 (net +0) | 2 (net +234) | 0 | 14% (1 of 7) |
| Opponent | High Elf Realms | 6 | 1 (net -347) | 0 | 1 (net -400) | 1 (net +102) | 0 | 3 (net +203) | 0 | 17% (1 of 6) |
| Opponent | Kingdom of Bretonnia | 8 | 2 (net +116) | 0 | 0 | 4 (net +96) | 0 | 2 (net -130) | 0 | 0% (0 of 8) |
| Opponent | Orc & Goblin Tribes | 3 | 1 (net -55) | 0 | 0 | 0 | 0 | 0 | 2 | 0% (0 of 1) |
| Opponent | Skaven | 1 | 0 | 0 | 0 | 1 (net +0) | 0 | 0 | 0 | 0% (0 of 1) |
| Opponent | Tomb Kings of Khemri | 23 | 2 (net +388) | 1 (net +296) | 3 (net -144) | 7 (net +41) | 1 (net +0) | 5 (net +305) | 4 | 16% (3 of 19) |
| Opponent | Vampire Counts | 26 | 11 (net -14) | 0 | 5 (net +78) | 6 (net +162) | 3 (net +92) | 1 (net +0) | 0 | 19% (5 of 26) |
| Opponent | Warriors of Chaos | 30 | 4 (net -50) | 2 (net -10) | 5 (net +185) | 5 (net +78) | 0 | 11 (net +196) | 3 | 19% (5 of 27) |
| Opponent | Wood Elf Realms | 13 | 1 (net +210) | 0 | 0 | 2 (net -304) | 1 (net +60) | 4 (net +177) | 5 | 0% (0 of 8) |

### Charged fights, damage counted: jb-h2h-opp-b54c226-p3

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 7 | 300 | 287 | +30 | 49 | 55 | -6 | -2.0 |
| Mine | 50-54% | 5 | 212 | 224 | +188 | 322 | 89 | +233 | +110.0 |
| Mine | Effective (55-75%) | 12 | 319 | 278 | +87 | 98 | 32 | +66 | +20.7 |
| Mine | 76-89% | 21 | 244 | 169 | +131 | 149 | 19 | +130 | +53.1 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 24 | 249 | 169 | +69 | 135 | 57 | +78 | +31.4 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 7 | 465 | 107 | +214 | 226 | 0 | +226 | +48.6 |
| Mine | No odds | 8 | 379 | 157 | +25 | 125 | 75 | +50 | +13.1 |
| Mine | All fights | 84 | 290 | 191 | +99 | 144 | 43 | +101 | +34.8 |
| Opponent | Long shot (under 50%) | 22 | 205 | 214 | +21 | 107 | 77 | +29 | +14.4 |
| Opponent | 50-54% | 4 | 287 | 294 | +69 | 220 | 80 | +140 | +48.7 |
| Opponent | Effective (55-75%) | 15 | 376 | 288 | +32 | 133 | 89 | +43 | +11.6 |
| Opponent | 76-89% | 28 | 273 | 174 | +57 | 123 | 64 | +60 | +21.8 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 28 | 356 | 251 | +186 | 253 | 78 | +175 | +49.1 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 6 | 364 | 67 | +56 | 56 | 4 | +52 | +14.4 |
| Opponent | No odds | 14 | 164 | 235 | +24 | 118 | 65 | +54 | +32.8 |
| Opponent | All fights | 117 | 285 | 221 | +74 | 152 | 71 | +81 | +28.4 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| jb-h2h-opp-b54c226-p3 | move | 446 | 89 (20%) | 69 (15%) | 52 (12%) | 305 (68%) |
| jb-h2h-opp-b54c226-p3 | objective | 377 | 51 (14%) | 40 (11%) | 52 (14%) | 274 (73%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0110, L0126, L2433, L2630 |
| Charmed Shield | Opponent | L0126, L0226, L0327, L0725, L1327, L2327 |
| Clockwork Compass | Mine | L1216, L1232 |
| Elixir of Power | Mine | L1122, L1932 |
| Elixir of Power | Opponent | L0311, L1519 |
| Fistful of Laurels | Mine | L1831 |
| Horn of the Wild Hunt | Opponent | L0533, L1633, L2033, L2433, L3133 |
| Invocation of Nehek | Mine | L2433 |
| Invocation of Nehek | Opponent | L0327, L0725, L1327, L2327 |
| Opal Amulet | Mine | L1422 |
| Periapt of Soul Exchange | Mine | L2033 |
| Periapt of Soul Exchange | Opponent | L0620 |
| Ring of Doom | Mine | L0210, L0226, L1122, L1216, L1232, L1519, L1535, L3133 |
| Ring of Doom | Opponent | L0311, L0533, L0815, L0831, L1633, L1731, L1831, L2033, L2433, L3133 |
| Ring of Jet | Mine | L1013, L1030, L1122, L1216, L1232 |
| Ring of Jet | Opponent | L0110, L0210, L0311 |
| Standard of the Fell Warrior | Mine | L1327 |
| Standard of the Fell Warrior | Opponent | L0413, L1013 |
| Twice-Blessed Armour | Mine | L0709, L0725, L1013, L1030 |
| Twice-Blessed Armour | Opponent | L0110, L0210 |
| Witch Hunter's Ward | Mine | L0709, L0725, L0815, L0831 |

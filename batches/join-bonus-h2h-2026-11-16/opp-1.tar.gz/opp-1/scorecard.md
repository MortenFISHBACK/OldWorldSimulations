# Doctrine scorecard: jb-h2h-opp-b54c226-p1

### Scorecard: jb-h2h-opp-b54c226-p1

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0102 | 6 | 1 | Mine | no | 6 | - | 0 | 0 | 0 | 0 | 0 | 0 |
| L0102 | 6 | 1 | Opponent | no | 4 | 2 | 2 | 4 | 0 | 0 | 0 | 307 |
| L0118 | 4 | 1 | Mine | no | 2 | - | 0 | 0 | 0 | 0 | 0 | 322 |
| L0118 | 4 | 1 | Opponent | no | 2 | 2 | 1 | 3 | 0 | 0 | 0 | 268 |
| L0135 | 3 | 1 | Mine | no | 12 | 2 | 1 | 2 | 0 | 0 | 0 | 55 |
| L0135 | 3 | 1 | Opponent | no | 1 | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L0218 | 2 | 1 | Mine | - | - | 2 | 4 | 3 | 1 | 0 | 0 | 170 |
| L0218 | 2 | 1 | Opponent | - | - | 4 | 2 | 2 | 0 | 0 | 0 | 0 |
| L0235 | 1 | 1 | Mine | no | 0 | 2 | 1 | 4 | 1 | 0 | 0 | 170 |
| L0235 | 1 | 1 | Opponent | no | 2 | 2 | 2 | 2 | 0 | 0 | 0 | 126 |
| L0319 | 1 | 1 | Mine | no | 10 | 3 | 3 | 0 | 0 | 0 | 0 | 760 |
| L0319 | 1 | 1 | Opponent | no | 0 | 2 | 2 | 2 | 0 | 0 | 0 | 0 |
| L0405 | 3 | 1 | Mine | yes | 5 | 2 | 2 | 0 | 0 | 0 | 0 | 0 |
| L0405 | 3 | 1 | Opponent | yes | 0 | 4 | 1 | 0 | 0 | 0 | 0 | 1193 |
| L0421 | 1 | 1 | Mine | no | 0 | 2 | 6 | 1 | 0 | 0 | 0 | 0 |
| L0421 | 1 | 1 | Opponent | no | 0 | - | 0 | 3 | 1 | 0 | 0 | 355 |
| L0508 | 4 | 1 | Mine | no | 3 | - | 0 | 2 | 0 | 0 | 0 | 771 |
| L0508 | 4 | 1 | Opponent | no | 0 | 4 | 2 | 1 | 0 | 0 | 0 | 971 |
| L0524 | 2 | 1 | Mine | - | - | 2 | 1 | 1 | 0 | 0 | 0 | 560 |
| L0524 | 2 | 1 | Opponent | - | - | 4 | 3 | 2 | 0 | 0 | 0 | 0 |
| L0612 | 6 | 1 | Mine | no | 2 | - | 1 | 3 | 0 | 0 | 0 | 615 |
| L0612 | 6 | 1 | Opponent | no | 5 | 3 | 2 | 0 | 0 | 0 | 0 | 330 |
| L0628 | 4 | 1 | Mine | no | 0 | 5 | 2 | 1 | 0 | 0 | 0 | 1252 |
| L0628 | 4 | 1 | Opponent | no | 1 | - | 0 | 1 | 0 | 0 | 0 | 462 |
| L0717 | 3 | 1 | Mine | no | 0 | 2 | 1 | 1 | 1 | 0 | 0 | 420 |
| L0717 | 3 | 1 | Opponent | yes | 5 | 2 | 4 | 1 | 1 | 0 | 0 | 175 |
| L0733 | 1 | 1 | Mine | no | 8 | 1 | 3 | 1 | 1 | 0 | 0 | 375 |
| L0733 | 1 | 1 | Opponent | no | 0 | 3 | 0 | 2 | 0 | 0 | 0 | 0 |
| L0823 | 1 | 1 | Mine | no | 0 | 2 | 3 | 1 | 1 | 0 | 0 | 515 |
| L0823 | 1 | 1 | Opponent | no | 0 | 2 | 4 | 2 | 2 | 0 | 0 | 130 |
| L0913 | 1 | 1 | Mine | no | 2 | 1 | 2 | 1 | 0 | 0 | 0 | 609 |
| L0913 | 1 | 1 | Opponent | no | 2 | 2 | 4 | 0 | 0 | 0 | 0 | 140 |
| L0930 | 6 | 1 | Mine | no | 1 | 5 | 2 | 1 | 0 | 0 | 0 | 629 |
| L0930 | 6 | 1 | Opponent | no | 6 | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L1021 | 1 | 1 | Mine | no | 0 | 2 | 4 | 0 | 0 | 0 | 0 | 330 |
| L1021 | 1 | 1 | Opponent | no | 1 | - | 0 | 4 | 1 | 0 | 0 | 355 |
| L1114 | 4 | 1 | Mine | no | 1 | 2 | 3 | 1 | 0 | 0 | 0 | 427 |
| L1114 | 4 | 1 | Opponent | no | 0 | 4 | 1 | 3 | 0 | 0 | 0 | 677 |
| L1131 | 3 | 1 | Mine | no | 3 | - | 2 | 0 | 2 | 0 | 0 | 330 |
| L1131 | 3 | 1 | Opponent | no | 0 | 5 | 2 | 1 | 0 | 0 | 0 | 365 |
| L1224 | 6 | 1 | Mine | no | 5 | 2 | 3 | 0 | 0 | 0 | 0 | 330 |
| L1224 | 6 | 1 | Opponent | no | 2 | 2 | 3 | 2 | 1 | 0 | 0 | 0 |
| L1319 | 5 | 1 | Mine | yes | - | 3 | 4 | 0 | 0 | 0 | 0 | 302 |
| L1319 | 5 | 1 | Opponent | no | - | 2 | 4 | 1 | 0 | 0 | 0 | 161 |
| L1335 | 3 | 1 | Mine | no | 1 | 2 | 3 | 1 | 0 | 0 | 0 | 140 |
| L1335 | 3 | 1 | Opponent | no | 0 | 4 | 1 | 3 | 0 | 0 | 0 | 126 |
| L1431 | 3 | 1 | Mine | yes | 5 | 2 | 5 | 0 | 0 | 0 | 0 | 177 |
| L1431 | 3 | 1 | Opponent | no | 0 | - | 3 | 2 | 1 | 0 | 0 | 732 |
| L1527 | 3 | 1 | Mine | yes | 4 | 3 | 2 | 0 | 1 | 0 | 0 | 0 |
| L1527 | 3 | 1 | Opponent | no | 0 | 3 | 3 | 1 | 0 | 0 | 0 | 0 |
| L1625 | 5 | 1 | Mine | yes | - | 4 | 2 | 2 | 1 | 0 | 0 | 200 |
| L1625 | 5 | 1 | Opponent | yes | - | 1 | 2 | 3 | 0 | 0 | 0 | 0 |
| L1723 | 1 | 1 | Mine | no | 5 | 1 | 3 | 0 | 2 | 0 | 0 | 233 |
| L1723 | 1 | 1 | Opponent | yes | 7 | 2 | 3 | 1 | 1 | 0 | 0 | 0 |
| L1823 | 5 | 1 | Mine | yes | - | - | 3 | 0 | 0 | 0 | 0 | 234 |
| L1823 | 5 | 1 | Opponent | yes | - | 1 | 3 | 2 | 2 | 0 | 0 | 0 |
| L1923 | 3 | 1 | Mine | no | 0 | 2 | 8 | 0 | 1 | 0 | 0 | 0 |
| L1923 | 3 | 1 | Opponent | no | 2 | 2 | 3 | 0 | 0 | 0 | 0 | 0 |
| L2025 | 3 | 1 | Mine | yes | 0 | - | 3 | 0 | 1 | 0 | 0 | 860 |
| L2025 | 3 | 1 | Opponent | no | 8 | 3 | 4 | 2 | 0 | 0 | 0 | 0 |
| L2127 | 3 | 1 | Mine | no | 0 | 4 | 4 | 2 | 0 | 0 | 0 | 145 |
| L2127 | 3 | 1 | Opponent | no | 5 | 2 | 4 | 3 | 0 | 0 | 0 | 0 |
| L2231 | 5 | 1 | Mine | yes | - | 2 | 3 | 0 | 0 | 0 | 0 | 0 |
| L2231 | 5 | 1 | Opponent | no | - | 2 | 4 | 1 | 2 | 0 | 0 | 541 |
| L2335 | 1 | 1 | Mine | no | 10 | 2 | 6 | 1 | 2 | 0 | 0 | 185 |
| L2335 | 1 | 1 | Opponent | no | 2 | 3 | 5 | 1 | 1 | 0 | 0 | 0 |
| L2531 | 5 | 1 | Mine | yes | - | 4 | 1 | 3 | 0 | 0 | 0 | 0 |
| L2531 | 5 | 1 | Opponent | no | - | 3 | 1 | 3 | 0 | 0 | 0 | 0 |
| L2730 | 6 | 1 | Mine | no | 0 | 1 | 3 | 4 | 0 | 0 | 0 | 0 |
| L2730 | 6 | 1 | Opponent | no | 6 | 3 | 2 | 0 | 0 | 0 | 0 | 0 |
| L2934 | 6 | 1 | Mine | no | 5 | 2 | 7 | 0 | 1 | 0 | 0 | 0 |
| L2934 | 6 | 1 | Opponent | no | 0 | 2 | 4 | 2 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 26% | 3.1 | 2.4 | 2.8 | 1.0 | 0.4 | 0.0 | 0.0 | 308.8 |
| **Average** | | | Opponent | 15% | 2.1 | 2.6 | 2.5 | 1.7 | 0.4 | 0.0 | 0.0 | 205.9 |

### KPIs: jb-h2h-opp-b54c226-p1

Rules off - Mine only: JOINS A FRIEND.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 26% (46 of 174) | 3% (5 of 176) | 15% (51 of 350) |
| Winner chose to follow up after the loser gave ground |  | 95% (56 of 59); on the table 95% | 98% (50 of 51); on the table 100% | 96% (106 of 110); on the table 97% |
| Winner chose to pursue after the loser fell back in good order |  | 100% (7 of 7); on the table 100% | 90% (9 of 10); on the table 90% | 94% (16 of 17); on the table 94% |
| Winner chose to pursue after the loser fled |  | 70% (33 of 47); on the table 70% | 88% (37 of 42); on the table 88% | 79% (70 of 89); on the table 79% |
| Winner chose to follow up or pursue (all three) |  | 85% (96 of 113); on the table 85% | 93% (96 of 103); on the table 94% | 89% (192 of 216); on the table 89% |
| Magic missiles tried each own turn | 50%+ | 32% (105 of 330) | 30% (63 of 210) | 31% (168 of 540) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 45% (105 of 234) | 41% (63 of 154) | 43% (168 of 388) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 55% (11 of 20) | 65% (34 of 52) | 62% (45 of 72) |
| Points that never fought | lower | 38% (27479 of 71484) | 37% (26526 of 71889) | 38% (54005 of 143373) |
|   infantry points that never fought | lower | 53% (8865 of 16863) | 57% (7571 of 13348) | 54% (16436 of 30211) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 55% (153 of 279) | 56% (166 of 295) | 56% (319 of 574) |
| Bound items with a magic missile used (at least once a game) |  | 95% (21 of 22); 2.1 uses a game | 80% (16 of 20); 1.3 uses a game | 88% (37 of 42); 1.7 uses a game |
| Bound items with another spell used |  | 69% (11 of 16); 0.7 uses a game | 25% (2 of 8); 0.1 uses a game | 54% (13 of 24); 0.4 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 47% (9 of 19); 0.2 uses a game | 67% (8 of 12); 0.2 uses a game | 55% (17 of 31); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 48% (28669 of 59666) | 52% (32347 of 62699) | 50% (61016 of 122365) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 2.0 (32%) | 1.5 (36%) | 3.4 (33%) |
| MARCHED: its unit marched | 1.0 (16%) | 0.5 (12%) | 1.5 (14%) |
| CHARGED: its unit charged | 0.5 (8%) | 0.0 (1%) | 0.5 (5%) |
| IN COMBAT: engaged in combat | 1.4 (23%) | 0.4 (11%) | 1.9 (18%) |
| REAR RANK: in a rear rank | 0.1 (2%) | 0.4 (11%) | 0.6 (5%) |
| NO CASTS LEFT: every cast used on other spells | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (0%) | 0.1 (1%) | 0.1 (1%) |
| GONE: slain | 0.5 (8%) | 1.1 (26%) | 1.5 (15%) |
| OFF THE TABLE: off the table or not arrived | 0.7 (12%) | 0.0 (0%) | 0.7 (7%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (1%) | 0.1 (1%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.4 | 1.6 | 1.4 | 4.7 | 0.6 | 1.9 |
| not cast | 3.6 | 2.7 | 3.3 | 10.3 | 1.8 | 22.1 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) | 0.0 (0%) | 1.2 (6%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.0 (36%) | 0.3 (8%) | 3.4 (33%) | 0.4 (20%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.5 (14%) | 0.3 (16%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.5 (5%) | 0.0 (2%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.1 (3%) | 0.3 (12%) | 0.4 (14%) | 1.9 (18%) | 0.3 (19%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.2 (5%) | 0.3 (12%) | 0.5 (16%) | 0.6 (5%) | 0.0 (0%) | 0.0 (0%) |
| NO CASTS LEFT: every cast used on other spells | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.1 (2%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.5 (2%) |
| GONE: slain | 0.9 (24%) | 0.4 (15%) | 0.6 (19%) | 1.5 (15%) | 0.0 (2%) | 2.8 (12%) |
| OFF THE TABLE: off the table or not arrived | 0.2 (5%) | 0.1 (5%) | 0.1 (3%) | 0.7 (7%) | 0.0 (0%) | 0.8 (3%) |
| STUPIDITY: Stupidity | 0.1 (3%) | 0.1 (2%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.5 (2%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.2 (9%) | 0.0 (0%) | 0.1 (1%) | 0.8 (42%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.1 (58%) | 0.2 (7%) | 1.2 (38%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 16.4 (74%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.2 a game | 0.4 a game | 0.8 a game |
| stood (cast and not dispelled) | 75% (27 of 36) | 64% (9 of 14) | 72% (36 of 50) |
| the unit moved after it | 70% (19 of 27) | 56% (5 of 9) | 67% (24 of 36) |
| it charged on its next turn | 0% (0 of 27) | 0% (0 of 9) | 0% (0 of 36) |
| the enemy charged it first | 11% (3 of 27) | 11% (1 of 9) | 11% (4 of 36) |
| it fought by the end of its next turn | 7% (2 of 27) | 11% (1 of 9) | 8% (3 of 36) |
| it moved out of a charge the enemy had planned (not charged first) | 7% (2 of 27) | 11% (1 of 9) | 8% (3 of 36) |
| none of these (no charge, no fight, no charge escaped) | 81% (22 of 27) | 78% (7 of 9) | 81% (29 of 36) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 63% (575 of 914) | 59% (351 of 590) | 62% (926 of 1504) |
|   cavalry | 56% (44 of 78) | 71% (85 of 120) | 65% (129 of 198) |
|   character | 48% (55 of 115) | 28% (31 of 110) | 38% (86 of 225) |
|   chariot | 49% (46 of 94) | 67% (26 of 39) | 54% (72 of 133) |
|   infantry | 59% (185 of 315) | 61% (145 of 238) | 60% (330 of 553) |
|   monster | 61% (22 of 36) | 24% (4 of 17) | 49% (26 of 53) |
|   war machine | 81% (223 of 276) | 91% (60 of 66) | 83% (283 of 342) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.7 (29%) | 1.6 (24%) | 4.3 (27%) |
| CHARGED: it charged | 1.2 (13%) | 1.4 (21%) | 2.6 (16%) |
| FLEEING: it fled or was fleeing | 0.2 (2%) | 0.1 (2%) | 0.3 (2%) |
| IN COMBAT: it fought this turn or the last | 0.8 (9%) | 0.3 (5%) | 1.1 (7%) |
| MOVED: a war machine that moved | 0.1 (1%) | 0.0 (0%) | 0.1 (0%) |
| NO TARGET IN RANGE | 1.6 (17%) | 1.3 (20%) | 2.9 (18%) |
| ONLY IN COMBAT: the only targets were in combat | 0.6 (6%) | 0.5 (8%) | 1.1 (7%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.7 (18%) | 1.2 (18%) | 2.9 (18%) |
| SHELTERED: the target was sheltered | 0.3 (3%) | 0.2 (3%) | 0.4 (3%) |
| OTHER BAR | 0.2 (3%) | 0.1 (1%) | 0.3 (2%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 5.3 | 1.2 | 82% | 4.2 pts | 22 pts |
| character | 3.1 | 0.6 | 87% | 2.3 pts | 7 pts |
| chariot | 2.1 | 1.5 | 71% | 10.5 pts | 22 pts |
| infantry | 13.2 | 5.3 | 73% | 8.8 pts | 116 pts |
| monster | 0.8 | 0.2 | 79% | 4.9 pts | 4 pts |
| war machine | 7.9 | 5.7 | 66% | 21.5 pts | 169 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.6 | 5.5 | 5.1 |
| Charges that made contact a game | 3.6 | 4.1 | 3.8 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.00 declared, 0.76 contact (21 units) | 0.43 declared, 0.36 contact (14 units) | 0.77 declared, 0.60 contact (35 units) |
|   per unit a game, units carrying another wizard (or one alone) | 1.00 declared, 0.80 contact (5 units) | 1.00 declared, 0.75 contact (8 units) | 1.00 declared, 0.77 contact (13 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.57 declared, 0.45 contact (246 units) | 0.65 declared, 0.48 contact (282 units) | 0.61 declared, 0.47 contact (528 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 50% (35 of 70) | 62% (13 of 21) | 50% (4 of 8) | 53% (52 of 99) |
| Character in a unit | 88% (30 of 34) | 75% (18 of 24) | 100% (3 of 3) | 84% (51 of 61) |
| Character on its own | 75% (40 of 53) | 42% (15 of 36) | 27% (17 of 63) | 47% (72 of 152) |
| Chariot | 69% (11 of 16) | 30% (3 of 10) | - | 54% (14 of 26) |
| Infantry | 54% (48 of 89) | 33% (12 of 36) | 50% (1 of 2) | 48% (61 of 127) |
| Monster | 59% (19 of 32) | 80% (8 of 10) | - | 64% (27 of 42) |
| Monstrous | 55% (6 of 11) | 36% (5 of 14) | - | 44% (11 of 25) |
| War Machines | 73% (30 of 41) | 100% (1 of 1) | - | 74% (31 of 42) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 6 | 86% (12 of 14); on the table 86% | 32% (44 of 138) | 44% | 55% (18 of 33) | 100% (9 of 9); 4.2 uses a game | 100% (3 of 3); 1.2 uses a game | 89% (8 of 9); 1.3 uses a game |
| Chaos Dwarfs | 3 | 94% (15 of 16); on the table 94% | 25% (6 of 24) | 33% | 25% (6 of 24) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Dwarfen Mountain Holds | 5 | 88% (14 of 16); on the table 88% | - | 57% | 76% (31 of 41) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 6 | 79% (11 of 14); on the table 79% | 31% (11 of 36) | 49% | 61% (39 of 64) | 0.0 uses a game | 100% (2 of 2); 1.0 uses a game | 25% (1 of 4); 0.2 uses a game |
| Grand Cathay | 5 | 100% (16 of 16); on the table 100% | 31% (33 of 108) | 46% | 48% (21 of 44) | 100% (12 of 12); 9.4 uses a game | 100% (1 of 1); 0.2 uses a game | 40% (2 of 5); 0.4 uses a game |
| High Elf Realms | 6 | 75% (18 of 24); on the table 75% | 33% (10 of 30) | 28% | 35% (17 of 49) | 100% (5 of 5); 3.0 uses a game | 39% (7 of 18); 2.3 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | 100% (1 of 1); on the table 100% | - | 29% | 67% (4 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Lizardmen | 2 | 100% (4 of 4); on the table 100% | - | 42% | 57% (8 of 14) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 3 | 83% (5 of 6); on the table 83% | 25% (3 of 12) | 45% | 57% (12 of 21) | 67% (2 of 3); 2.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 3 | 100% (6 of 6); on the table 100% | 11% (4 of 36) | 4% | 71% (17 of 24) | 0.0 uses a game | 0.0 uses a game | 67% (2 of 3); 0.7 uses a game |
| Skaven | 4 | 100% (7 of 7); on the table 100% | 43% (13 of 30) | 32% | 62% (21 of 34) | 100% (3 of 3); 1.8 uses a game | 0.0 uses a game | 50% (2 of 4); 0.5 uses a game |
| Tomb Kings of Khemri | 6 | 93% (25 of 27); on the table 93% | 8% (1 of 12) | 29% | 33% (10 of 30) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 8 | 84% (26 of 31); on the table 87% | 35% (19 of 54) | 34% | 58% (29 of 50) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 8 | 88% (14 of 16); on the table 88% | 37% (11 of 30) | 37% | 68% (50 of 74) | 100% (4 of 4); 1.5 uses a game | 0.0 uses a game | 50% (1 of 2); 0.1 uses a game |
| Wood Elf Realms | 6 | 100% (18 of 18); on the table 100% | 43% (13 of 30) | 42% | 55% (36 of 66) | 33% (2 of 6); 1.3 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (jb-h2h-opp-b54c226-p1, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 45% (35) | 46% (38) | 46% (73) |
| ...free all their last turn and able to turn (per game) | 0.47 | 0.64 | 1.11 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.31 | 0.11 | 0.42 |
| ...with the charger already in that arc before they moved (per game) | 0.36 | 0.33 | 0.69 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 2.22 | 1.31 | 3.53 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 1.06 | 0.56 | 1.61 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 5.08 | 5.58 | 10.67 |

### Quality by phase: jb-h2h-opp-b54c226-p1

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.1 | 3.4 |
| Strategy | Charge objectives carried out (made contact) | 55% (77 of 139) | 51% (83 of 163) |
| Strategy | Shoot objectives carried out (shot that target) | 50% (202 of 404) | 61% (120 of 197) |
| Strategy | Close-in objectives charged next turn | 17% (27 of 162) | 21% (43 of 207) |
| Strategy | Support requests answered (helper made contact too) | 62% (13 of 21) | 57% (16 of 28) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 50% (1 of 2) | 100% (3 of 3) |
| Strategy | Hexes on a unit its side charged or shot that turn | 78% (14 of 18) | 62% (10 of 16) |
| Strategy | Joined characters whose unit fought | 29% (15 of 51) | 41% (17 of 41) |
| Strategy | Lone characters that fought | 79% (75 of 95) | 80% (76 of 95) |
| Movement | Charges halted short of contact | 0.1 | 0.1 |
| Movement | Idle units | 1.0 | 1.7 |
| Movement | Points that never moved of their own | 308.8 | 205.9 |
| Movement | Fights charged into per game | 3.2 | 3.4 |
| Movement | Charges with odds: long shots (under 50%) | 15 of 97, net +179 | 14 of 106, net +68 |
| Movement | Charges with odds: sweet spot (55-75%) | 17 of 97, net +158 | 26 of 106, net +38 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 6 of 97, net +119 | 3 of 106, net +111 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 29 of 97, net +71 | 32 of 106, net +113 |
| Shooting | Shots by shooting units (incl. breath weapons) | 10.7 | 9.1 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 39% (149 of 384) | 44% (146 of 329) |
| Shooting | Points destroyed by shooting units | 66.7 | 47.9 |
| Shooting | War machine shots | 6.2 | 1.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 50% (111 of 223) | 43% (26 of 60) |
| Shooting | Points destroyed by war machines | 60.4 | 25.3 |
| Magic | Magic missiles cast | 2.1 | 1.0 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 42% (32 of 76) | 49% (17 of 35) |
| Magic | Wounds caused by magic missiles | 5.0 | 1.3 |
| Magic | Wounds caused by other spells | 1.4 | 0.8 |
| Magic | Points destroyed by magic (all spells) | 100.7 | 23.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.6 / 0.6 / 0.8 / 0.3 | 1.6 / 0.6 / 0.6 / 0.2 |
| Combat | Points destroyed in combat | 367.1 | 316.0 |
| Combat | Points run down | 138.0 | 115.4 |
| Combat | Net points per charged fight, damage counted | +79 | +69 |
| Combat | Net per 100 charger points, damage counted | +27.5 | +27.6 |
| Combat | First round won (charged fights) | 69% | 71% |
| Combat | Net points per charged fight | +91 | +67 |
| Combat | Net points per supported fight / lone fight | +242 / +67 | +190 / +43 |
| Combat | Charged fights on a top-3 enemy unit | 45 of 114 | 50 of 124 |
| Game | Points lost | 645.5 | 803.5 |
| Game | VP from objectives | 633.3 | 586.4 |
| Game | Lone holders (player turns) | 3.1 | 2.1 |

- Mine won / drew / lost: 15 / 4 / 17 of 36 ended games (of 36); mean margin (Mine - Opponent) +193 VP
- The side that went first won 12 of 32 games with a winner
- Points traded per game (both sides' losses): 1449
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: jb-h2h-opp-b54c226-p1

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.6 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| ALREADY CARRIED | 0.0 | +0.0 | 10.3 | 3.6 | - | - | - | - |
| ARRIVAL HUNT | - | - | - | - | 0.0 | +0.2 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.2 | +0.0 | 0.0 | 14.9 | 0.3 | +0.0 | 0.0 | 2.6 |
| BACKUP TARGETS | 0.6 | +6.7 | 0.0 | 3.5 | 1.2 | +12.3 | 0.0 | 39.8 |
| BEST FACING | 0.8 | +25.9 | 0.0 | 42.6 | 0.6 | +27.8 | 0.0 | 23.5 |
| BEST FIRST | 4.9 | +246.7 | 154.3 | 66.2 | 4.1 | +186.8 | 97.2 | 58.1 |
| BEST OVERALL | 0.7 | +63.7 | 0.0 | 26.2 | 0.5 | +37.6 | 0.0 | 16.4 |
| BEST PREY | 0.9 | +30.4 | 24.2 | 24.2 | 0.9 | +49.6 | 55.1 | 27.3 |
| BEST PRIZE | - | - | - | - | 0.0 | -0.7 | 1.5 | 0.0 |
| BIG CHARACTER SAFETY | 0.2 | -0.2 | 0.0 | 15.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| BLOCKED CHARGE SKIPPED | 0.1 | +0.0 | 2.9 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| BLOCKED WHEEL | 0.3 | +8.2 | 0.0 | 15.3 | 0.1 | +0.0 | 0.0 | 0.0 |
| BLOWS WHERE AIMED | 0.3 | -38.4 | 44.3 | 0.0 | 0.2 | -33.4 | 33.9 | 8.0 |
| BOMBING RUN | 0.1 | +2.5 | 0.0 | 0.0 | - | - | - | - |
| BOUND ASSAILMENT | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CANNON PLAN MISSED | 0.9 | +0.0 | 148.5 | 11.5 | 0.1 | +0.0 | 10.3 | 0.0 |
| CANNON PLANNED TARGET | 4.9 | +164.1 | 334.7 | 61.0 | 1.3 | +27.3 | 39.4 | 7.9 |
| CANNON SIGHT KEPT | 1.0 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT COUNTER | 0.1 | -0.1 | 28.0 | 0.0 | 0.1 | +0.0 | 9.1 | 0.0 |
| CARRIES OUT SET-UP | 0.1 | +0.0 | 38.3 | 0.0 | 0.1 | -0.5 | 13.7 | 0.0 |
| CAST JOB | 0.8 | +28.6 | 33.5 | 17.0 | 0.4 | +7.3 | 16.6 | 1.7 |
| CASTER AWAY FROM SCREEN | 0.4 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.4 | +37.0 | 20.8 | 0.0 | 0.1 | +4.1 | 5.7 | 4.4 |
| CASTS AFTER FRIENDS | 0.7 | +0.0 | 0.0 | 40.0 | 0.3 | +0.0 | 0.0 | 7.6 |
| CASTS FROM BEHIND | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.0 | +0.5 | 0.0 | 0.0 | 0.0 | +0.3 | 0.0 | 0.0 |
| CATCH ODDS | 0.1 | +6.8 | 0.0 | 0.0 | 0.1 | +1.8 | 0.0 | 0.0 |
| CHAFF PASSED | 0.2 | -0.8 | 0.0 | 3.5 | 0.2 | -0.5 | 2.9 | 3.8 |
| CHARGE BAND | 0.1 | +0.0 | 2.7 | 0.0 | 0.2 | +0.0 | 40.0 | 0.0 |
| CHARGE NOW FIRST | 2.6 | +0.0 | 329.8 | 92.8 | 2.6 | +0.0 | 204.6 | 57.6 |
| CHARGE NOW WEIGHED | 0.4 | -25.1 | 1.8 | 11.4 | 0.5 | -72.5 | 9.5 | 27.1 |
| CHARGER SLAIN LOST | 0.6 | -15.6 | 99.3 | 13.9 | 0.8 | -17.5 | 86.4 | 13.6 |
| CHARIOT NO STATIC JOB | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHARIOT WIZARD CAREFUL | 0.1 | -3.3 | 18.0 | 0.0 | 0.1 | -0.0 | 0.0 | 0.0 |
| CHEAP HELPER | 0.1 | +0.0 | 11.3 | 1.7 | 0.1 | +0.0 | 3.3 | 0.0 |
| COMBAT PIVOT | 0.6 | +0.0 | 40.2 | 11.1 | 0.6 | +0.0 | 33.6 | 102.9 |
| CONTINUE AHEAD WEIGHED | - | - | - | - | 0.1 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | 0.6 | +97.6 | 20.7 | 24.7 | 0.3 | +63.5 | 6.0 | 15.2 |
| COUNTER-CHARGE COVER | 9.4 | +810.4 | 0.0 | 165.1 | 7.3 | +742.6 | 0.0 | 208.4 |
| DEFENSIVE ARMY | 0.2 | +0.0 | 27.4 | 1.8 | 0.1 | +0.0 | 0.0 | 0.0 |
| DEFENSIVE FLOOR | 0.1 | +2.0 | 4.7 | 5.3 | - | - | - | - |
| EDGE GIVE GROUND | 0.1 | +4.1 | 7.4 | 2.4 | 0.1 | +1.3 | 21.1 | 0.0 |
| ELIXIR WORTH | - | - | - | - | 0.1 | +1.7 | 0.0 | 9.7 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 2.2 | +173.7 | 0.0 | 69.3 | 1.3 | +110.3 | 0.0 | 49.8 |
| FALLBACK BY WORTH | 4.3 | +80.1 | 0.0 | 53.0 | 5.2 | +66.1 | 0.0 | 49.5 |
| FIGHT LIFT | 0.1 | +0.2 | 1.7 | 0.0 | - | - | - | - |
| FIRE AND FLEE | - | - | - | - | 0.0 | +0.1 | 0.0 | 3.9 |
| FLANK NOT WEIGHED | 5.1 | +0.0 | 0.0 | 121.1 | 5.6 | +0.0 | 0.0 | 181.5 |
| FOCUS FIRE | 0.1 | +3.6 | 0.8 | 1.8 | 0.0 | +0.3 | 0.8 | 0.0 |
| FOLLOW UP WEIGHED | 0.8 | +105.9 | 0.0 | 32.3 | 1.0 | +113.0 | 0.0 | 48.2 |
| FRIENDS SHOTS CHECKED | 0.4 | +28.0 | 0.0 | 6.1 | 0.3 | +8.1 | 0.0 | 5.4 |
| GIVES UP | - | - | - | - | 0.1 | -0.3 | 0.0 | 7.9 |
| GIVES UP ITS SCREEN | 0.1 | -0.8 | 3.1 | 8.3 | 0.0 | -0.1 | 0.0 | 0.0 |
| GROUND FLIERS | 0.0 | +0.5 | 0.0 | 0.0 | 0.0 | +0.5 | 0.0 | 0.0 |
| HELPER ALREADY ASKED | - | - | - | - | 0.0 | +0.0 | 4.9 | 0.0 |
| HELPER UNSEEN | 0.1 | +0.0 | 35.6 | 0.0 | 0.4 | +0.0 | 25.8 | 29.0 |
| HILL BY ITS CHANCE | - | - | - | - | 0.1 | -11.4 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.8 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 7.4 | -137.8 | 492.5 | 147.2 | 9.2 | -163.1 | 295.5 | 228.2 |
| HORN WORTH | - | - | - | - | 0.0 | +0.5 | 0.0 | 0.0 |
| HUNT ADVANCE | 0.1 | +1.6 | 0.0 | 0.0 | 0.1 | +5.5 | 0.0 | 2.9 |
| HUNT DROPPED | - | - | - | - | 0.0 | +0.0 | 0.0 | 3.2 |
| HUNT IN PAIRS | 0.5 | +19.0 | 0.0 | 0.0 | 0.4 | +25.6 | 0.0 | 16.9 |
| HUNT KEPT | 0.0 | +0.8 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| HUNT RESULT | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +13.2 | 0.0 | 5.7 |
| HUNT THE GUNS | 0.0 | +10.7 | 0.0 | 0.0 | 0.1 | +57.9 | 2.8 | 4.1 |
| INVITES THE FIGHT | 1.4 | +24.3 | 60.9 | 22.7 | 1.7 | +26.7 | 54.3 | 37.6 |
| JOINS A FRIEND | - | - | - | - | 2.4 | +15.5 | 107.4 | 50.2 |
| JOINT CHARGE PLAN | 0.1 | +2.7 | 0.0 | 0.0 | 0.3 | +9.4 | 6.1 | 0.0 |
| JOINT KNOWS CHALLENGE | 0.0 | -0.4 | 10.9 | 0.0 | 0.1 | -3.7 | 10.3 | 16.1 |
| KEEP FALLS | 0.0 | +0.4 | 0.0 | 0.0 | - | - | - | - |
| KEEPS ITS TARGET | 1.6 | +48.3 | 208.6 | 35.9 | 2.1 | +61.7 | 117.6 | 49.2 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KILLS COUNT | 1.6 | +68.5 | 141.9 | 35.1 | 2.0 | +73.2 | 113.7 | 51.3 |
| KILLS COUNT NEXT TURN | 4.9 | +182.4 | 188.4 | 88.4 | 6.4 | +252.5 | 194.0 | 162.6 |
| LONE CHARACTER SAFE SPOT | 0.4 | +29.6 | 6.5 | 0.0 | 0.2 | +4.5 | 0.0 | 10.7 |
| LONE WIZARD HOLDS BACK | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 16.1 |
| LONE WIZARD KEPT IN | 0.7 | +49.1 | 0.0 | 0.0 | 0.2 | +24.5 | 0.0 | 0.0 |
| LONG SHOT | 0.6 | -3.7 | 32.2 | 11.6 | 0.6 | +0.2 | 19.9 | 18.2 |
| LOST CHARGE | 2.9 | -40.3 | 121.3 | 78.7 | 3.0 | -42.9 | 30.7 | 78.7 |
| LURE BY WHAT IT DRAWS | 0.0 | +0.0 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 0.7 | +77.2 | 21.8 | 24.3 | 0.9 | +53.2 | 38.5 | 26.2 |
| MANOEUVRE | 0.1 | +1.9 | 0.0 | 5.5 | 0.3 | +5.2 | 0.0 | 4.0 |
| MARCH AT ESCAPER | 0.0 | +0.7 | 0.0 | 0.0 | 0.0 | +0.5 | 0.0 | 0.0 |
| MARCH CHECK | 0.5 | +24.8 | 0.0 | 15.2 | 0.4 | +25.3 | 0.0 | 4.4 |
| MARCH ODDS | 0.2 | +16.2 | 2.9 | 0.0 | 0.3 | +19.6 | 4.6 | 16.4 |
| MARCH OVER CASTS | 0.4 | +28.8 | 0.0 | 35.8 | 0.4 | +7.0 | 0.0 | 3.0 |
| MAX FOR POSITIONING | 5.2 | +184.1 | 0.0 | 81.0 | 5.0 | +179.7 | 0.0 | 172.1 |
| MISSILES IN THE MOVE | 4.3 | +153.1 | 0.0 | 96.0 | 3.4 | +51.5 | 0.0 | 76.4 |
| MISSILES NEXT TURN | 4.9 | +103.4 | 0.0 | 97.9 | 4.1 | +40.4 | 0.0 | 84.8 |
| MODEL FACING | 0.3 | +91.2 | 0.0 | 3.3 | - | - | - | - |
| MONSTER WIZARD ROAMS | 0.1 | +0.0 | 8.0 | 10.6 | 0.2 | +0.0 | 0.0 | 12.1 |
| MOVE AND CAST | 0.4 | +33.0 | 0.0 | 6.1 | 0.5 | +20.3 | 0.0 | 21.1 |
| MOVE SPELL IN RANGE | 0.2 | +5.6 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.3 | -62.0 | 0.0 | 26.9 | 0.1 | -0.9 | 0.0 | 0.0 |
| MOVE SPELL SPOT | 0.3 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE | 3.1 | +286.6 | 179.5 | 73.6 | 4.6 | +311.3 | 128.9 | 127.5 |
| MOVES UNITS SPELL | 0.1 | +3.4 | 0.0 | 0.0 | 0.1 | +1.8 | 0.0 | 0.0 |
| NO RALLY LEFT | 0.0 | +1.4 | 0.0 | 0.0 | - | - | - | - |
| NOT NEEDED | 0.3 | -12.3 | 27.8 | 4.1 | 0.2 | -7.3 | 41.4 | 0.0 |
| NOT TURNED | 5.1 | +72.1 | 0.0 | 84.4 | 5.6 | +67.4 | 0.0 | 158.4 |
| NOT WORTH A CAST | 0.9 | -0.7 | 0.0 | 31.0 | 0.3 | -0.2 | 0.0 | 0.0 |
| OFF BEST | 16.9 | -841.9 | 7.0 | 272.8 | 16.1 | -868.4 | 5.1 | 320.9 |
| OPENS A LANE | 0.2 | +2.8 | 6.7 | 6.1 | 0.1 | +0.4 | 0.0 | 0.0 |
| OPENS UP | 0.2 | +10.1 | 11.0 | 30.2 | 0.1 | +7.7 | 6.6 | 7.9 |
| OVERRUNS AWAY | 0.6 | +10.5 | 47.3 | 24.0 | 0.4 | +5.1 | 21.0 | 16.4 |
| PATHS CROSS | 2.0 | +123.9 | 0.0 | 13.1 | 2.3 | +156.9 | 0.0 | 39.9 |
| PERIAPT WORTH | - | - | - | - | 0.1 | +1.7 | 0.0 | 30.0 |
| PIVOT GUARDS FLANK | 0.1 | -0.8 | 0.0 | 1.4 | 0.2 | -1.9 | 0.0 | 15.7 |
| PLAN RESULT | 38.0 | +1400.9 | 1622.9 | 874.1 | 37.2 | +866.8 | 1079.9 | 1053.1 |
| PURSUES BIG PREY | 0.2 | -24.6 | 0.0 | 0.0 | 0.1 | -10.4 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE NEXT TURN | - | - | - | - | 0.1 | +9.0 | 0.0 | 1.5 |
| RANDOM MOVE BY FIGURES | 0.6 | +5.2 | 0.0 | 23.3 | 1.4 | +21.0 | 0.0 | 68.2 |
| RANDOM MOVER NO PROMISE | 0.1 | -3.5 | 0.0 | 4.7 | 0.3 | -9.7 | 4.9 | 10.6 |
| REDIRECT BY WHAT IT STOPS | 0.2 | +1.5 | 0.0 | 3.4 | 0.4 | -5.6 | 0.0 | 15.8 |
| REDIRECT COUNTER | 2.1 | +127.3 | 0.0 | 34.5 | 3.9 | +323.4 | 0.0 | 72.7 |
| REDIRECT WEIGHED | 0.3 | +2.4 | 8.7 | 0.0 | 0.4 | +5.8 | 10.1 | 3.5 |
| REFUSING RETIRES | 0.2 | +0.0 | 0.0 | 0.0 | 0.5 | +0.0 | 0.0 | 18.1 |
| RESERVE FALL BACK | 0.5 | +12.9 | 0.0 | 17.7 | 0.8 | +40.0 | 0.0 | 18.6 |
| RESTRAINS TO SHOOT | 0.1 | +8.3 | 0.0 | 0.0 | 0.1 | +3.7 | 0.0 | 6.5 |
| RISK BY ARC | 2.5 | +89.1 | 250.1 | 108.3 | 2.6 | +87.4 | 198.8 | 84.8 |
| SAFE SURE CHARGE | - | - | - | - | 0.0 | -13.3 | 0.0 | 10.9 |
| SAFER THAN THE JOB | 1.1 | +88.5 | 0.0 | 30.8 | 0.6 | +31.8 | 0.0 | 9.6 |
| SCOUT SPOT | 0.4 | +0.7 | 0.0 | 0.0 | 0.3 | +0.6 | 0.0 | 0.9 |
| SCOUT WAITS | 0.4 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.9 |
| SCREEN BY WHAT IT SAVES | 0.1 | -4.6 | 0.0 | 3.2 | 0.3 | -8.3 | 0.0 | 8.9 |
| SEARCH SPOT | 2.1 | +103.7 | 0.0 | 33.8 | 2.7 | +139.5 | 0.0 | 19.8 |
| SELF MOVE SPELL | 0.3 | +39.3 | 0.0 | 18.1 | 0.2 | -0.1 | 0.0 | 0.0 |
| SET UP TOGETHER | 1.3 | +143.6 | 56.8 | 48.9 | 1.9 | +140.9 | 61.2 | 44.4 |
| SET-UP ANY TARGET | 0.3 | +27.7 | 20.7 | 3.6 | 0.1 | +15.8 | 0.0 | 0.0 |
| SET-UP MISSED | 0.0 | +2.6 | 0.0 | 0.0 | 0.1 | +10.2 | 3.5 | 7.6 |
| SHOOTER COUNTED ONCE | - | - | - | - | 0.1 | -0.2 | 0.0 | 1.7 |
| SHOOTERS IN TWO RANKS | 0.4 | +0.9 | 0.0 | 0.0 | 0.3 | +0.8 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.1 | +26.0 | 56.0 | 11.4 | 0.7 | +18.1 | 26.8 | 20.4 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 3.2 | 0.0 | +0.0 | 0.0 | 0.0 |
| SHOT REPLANNED | 0.8 | +0.0 | 116.7 | 5.3 | 0.1 | +0.0 | 10.4 | 0.0 |
| SHOTS IN THE MOVE | 15.1 | +577.9 | 0.0 | 198.0 | 9.1 | +207.9 | 0.0 | 129.9 |
| SPELL CATCH ODDS | 0.0 | -1.0 | 0.0 | 0.0 | - | - | - | - |
| SPELL SETS UP CHARGE | 0.4 | +67.8 | 20.7 | 3.6 | 0.2 | +42.0 | 0.0 | 0.0 |
| SPELL WORTH | 1.2 | +18.2 | 72.7 | 67.1 | 1.6 | +39.9 | 83.2 | 96.2 |
| SPELLS IN THE FIGHT | 0.5 | +4.4 | 106.2 | 14.0 | 0.4 | -4.8 | 55.7 | 25.6 |
| STABLE ROLE | 11.8 | +0.0 | 440.9 | 171.6 | 10.9 | +0.0 | 283.5 | 223.9 |
| STANDS TO CAST | 0.0 | +3.4 | 0.0 | 0.0 | - | - | - | - |
| STOPS | - | - | - | - | 0.1 | +2.4 | 2.8 | 1.2 |
| STOPS SHORT OF THE FLANK | 0.5 | +12.6 | 0.0 | 1.4 | 0.4 | +12.4 | 0.0 | 5.1 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 8.1 |
| SUPPORT NARROWED | 5.4 | -31.6 | 367.4 | 121.4 | 6.9 | -51.5 | 321.0 | 115.0 |
| SUPPORTS | 3.2 | +32.6 | 139.3 | 44.7 | 4.6 | +51.8 | 182.2 | 67.0 |
| SURE CHARGE BEATS ADVANCE | 0.1 | -3.5 | 14.5 | 0.0 | 0.1 | -4.1 | 6.6 | 0.0 |
| SURE REACH TOGETHER | 0.7 | -3.2 | 0.0 | 20.7 | 0.7 | +1.1 | 14.1 | 24.1 |
| THROUGH LINE OF FIRE | 0.6 | +25.2 | 0.0 | 15.1 | 0.2 | +8.6 | 0.0 | 0.0 |
| TURN WORTH | 0.4 | -29.7 | 34.8 | 15.3 | 0.2 | -9.9 | 16.9 | 0.0 |
| TWO OR MORE ARRIVE | 0.2 | +2.0 | 0.0 | 8.1 | 0.6 | +4.0 | 0.0 | 0.0 |
| WAIT AFTER COSTS | 6.4 | -322.1 | 312.0 | 105.7 | 8.2 | -429.5 | 215.9 | 188.4 |
| WALKS TO THE FIGHT | 1.5 | +29.9 | 44.8 | 13.7 | 1.0 | +22.1 | 27.5 | 15.0 |
| WAR ENGINE CHARGES | 0.2 | +21.2 | 15.2 | 0.0 | - | - | - | - |
| WAR ENGINE JOBS | 0.6 | +0.0 | 19.3 | 17.1 | 0.5 | +0.0 | 4.7 | 5.1 |
| WEARS DOWN | 1.1 | +64.3 | 165.8 | 27.1 | 1.4 | +44.2 | 133.4 | 35.2 |
| WHO HITS BACK | 0.2 | +8.2 | 0.0 | 0.0 | 0.3 | +28.2 | 0.0 | 19.5 |
| WHOLE FIGHT | 0.4 | +24.9 | 77.9 | 0.0 | 0.4 | +11.9 | 39.4 | 1.4 |
| WHOLE FIGHT GAIN | 0.4 | +23.5 | 33.2 | 5.9 | 0.6 | +36.1 | 67.4 | 10.9 |
| WIDER SPREAD | 2.7 | -8.1 | 351.2 | 93.5 | 3.2 | -5.6 | 262.1 | 88.1 |

### Rule changes: jb-h2h-opp-b54c226-p1

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 1189 | 1189 | 1189 | 33.03 | -61570 | -51.8 |
| BEST FIRST | 325 | 325 | 325 | 9.03 | +15606 | +48.0 |
| SEARCH SPOT | 171 | 171 | 170 | 4.72 | +8756 | +51.5 |
| COUNTER-CHARGE COVER | 602 | 309 | 160 | 4.44 | +12739 | +79.6 |
| PATHS CROSS | 156 | 156 | 156 | 4.33 | +10110 | +64.8 |
| MOVE TO CHARGE | 279 | 279 | 146 | 4.06 | +7897 | +54.1 |
| KILLS COUNT NEXT TURN | 408 | 408 | 130 | 3.61 | +4236 | +32.6 |
| FACES THE THREAT | 127 | 127 | 127 | 3.53 | +10225 | +80.5 |
| SUPPORTS | 284 | 284 | 101 | 2.81 | +736 | +7.3 |
| FALLBACK BY WORTH | 345 | 345 | 85 | 2.36 | +5263 | +61.9 |
| SHOTS IN THE MOVE | 869 | 550 | 74 | 2.06 | +2559 | +34.6 |
| WAIT AFTER COSTS | 526 | 526 | 67 | 1.86 | +1388 | +20.7 |
| FOLLOW UP WEIGHED | 65 | 65 | 65 | 1.81 | +7879 | +121.2 |
| SAFER THAN THE JOB | 58 | 58 | 58 | 1.61 | +4331 | +74.7 |
| SET UP TOGETHER | 118 | 103 | 58 | 1.61 | +3576 | +61.7 |
| ARTILLERY RE-ROLL WEIGHED | 56 | 56 | 56 | 1.56 | +0 | +0.0 |
| RISK BY ARC | 184 | 178 | 54 | 1.50 | +1404 | +26.0 |
| WALKS TO THE FIGHT | 89 | 89 | 54 | 1.50 | +852 | +15.8 |
| CANNON SIGHT KEPT | 51 | 51 | 51 | 1.42 | +0 | +0.0 |
| BEST FACING | 50 | 50 | 50 | 1.39 | +1933 | +38.7 |
| CANNON PLANNED TARGET | 223 | 223 | 50 | 1.39 | -13 | -0.3 |
| REDIRECT COUNTER | 214 | 103 | 50 | 1.39 | +3640 | +72.8 |
| RESERVE FALL BACK | 48 | 48 | 48 | 1.33 | +1904 | +39.7 |
| ADVANCE LANE KEPT | 46 | 46 | 46 | 1.28 | +0 | +0.0 |
| RANDOM MOVE BY FIGURES | 72 | 72 | 45 | 1.25 | +945 | +21.0 |
| CHARGE NOW FIRST | 187 | 187 | 44 | 1.22 | -3201 | -72.8 |
| HOLDS AMBUSHERS | 44 | 44 | 44 | 1.22 | +0 | +0.0 |
| COMBAT PIVOT | 43 | 43 | 43 | 1.19 | +0 | +0.0 |
| BEST OVERALL | 42 | 42 | 42 | 1.17 | +3645 | +86.8 |
| MAX FOR POSITIONING | 369 | 193 | 41 | 1.14 | +587 | +14.3 |
| CHARGE NOW WEIGHED | 35 | 35 | 35 | 0.97 | +2777 | +79.3 |
| KILLS COUNT | 130 | 127 | 35 | 0.97 | +1217 | +34.8 |
| LONE WIZARD KEPT IN | 34 | 34 | 34 | 0.94 | +2648 | +77.9 |
| STOPS SHORT OF THE FLANK | 33 | 33 | 33 | 0.92 | +898 | +27.2 |
| SHOT REPLANNED | 32 | 32 | 32 | 0.89 | +0 | +0.0 |
| KEEPS ITS TARGET | 132 | 131 | 31 | 0.86 | +479 | +15.5 |
| MOVE AND CAST | 31 | 31 | 31 | 0.86 | +1921 | +62.0 |
| MISSILES IN THE MOVE | 277 | 145 | 30 | 0.83 | +653 | +21.8 |
| MARCH CHECK | 30 | 30 | 29 | 0.81 | +1900 | +65.5 |
| SHOOTS FROM THE BEST SPOT | 65 | 65 | 29 | 0.81 | +750 | +25.9 |
| HONEST WORTH | 598 | 596 | 28 | 0.78 | +219 | +7.8 |
| THROUGH LINE OF FIRE | 27 | 27 | 27 | 0.75 | +1218 | +45.1 |
| CASTER AWAY FROM SCREEN | 26 | 26 | 26 | 0.72 | +0 | +0.0 |
| SCOUT WAITS | 26 | 26 | 26 | 0.72 | +0 | +0.0 |
| CAST JOB | 43 | 43 | 25 | 0.69 | +456 | +18.2 |
| FRIENDS SHOTS CHECKED | 24 | 24 | 24 | 0.67 | +1299 | +54.1 |
| SHOOTERS IN TWO RANKS | 24 | 24 | 24 | 0.67 | +58 | +2.4 |
| INVITES THE FIGHT | 112 | 112 | 23 | 0.64 | +406 | +17.7 |
| REDIRECT WEIGHED | 23 | 23 | 23 | 0.64 | +714 | +31.1 |
| MAKE SURE TOGETHER | 58 | 42 | 20 | 0.56 | +1014 | +50.7 |
| WHO HITS BACK | 19 | 19 | 19 | 0.53 | +899 | +47.3 |
| WHOLE FIGHT GAIN | 35 | 32 | 19 | 0.53 | +603 | +31.7 |
| WEARS DOWN | 87 | 83 | 18 | 0.50 | +606 | +33.7 |
| MARCH ODDS | 17 | 17 | 17 | 0.47 | +169 | +9.9 |
| BEST PREY | 65 | 65 | 16 | 0.44 | +377 | +23.6 |
| BLOCKED WHEEL | 16 | 16 | 16 | 0.44 | +296 | +18.5 |
| BIG CHARACTER SAFETY | 14 | 14 | 14 | 0.39 | -5 | -0.3 |
| CASTS FROM BEHIND | 14 | 14 | 14 | 0.39 | +0 | +0.0 |
| CHAFF PASSED | 14 | 14 | 14 | 0.39 | -50 | -3.6 |
| MANOEUVRE | 15 | 15 | 13 | 0.36 | +255 | +19.6 |
| CASTING BLOCK | 18 | 18 | 11 | 0.31 | +685 | +62.3 |
| CHARGE BAND | 11 | 11 | 11 | 0.31 | +0 | +0.0 |
| MODEL FACING | 11 | 11 | 11 | 0.31 | +3283 | +298.4 |
| WAR ENGINE JOBS | 39 | 39 | 11 | 0.31 | -909 | -82.6 |
| JOINS A FRIEND | 85 | 85 | 10 | 0.28 | +28 | +2.8 |
| PURSUES BIG PREY | 10 | 10 | 10 | 0.28 | -1259 | -125.9 |
| PIVOT GUARDS FLANK | 9 | 9 | 9 | 0.25 | -98 | -10.9 |
| REFUSING RETIRES | 26 | 26 | 9 | 0.25 | -3 | -0.4 |
| RESTRAINS TO SHOOT | 9 | 9 | 9 | 0.25 | +430 | +47.7 |
| STUCK PIVOT | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| SHORT GUN FORWARD | 8 | 8 | 8 | 0.22 | +0 | +0.0 |
| HUNT IN PAIRS | 31 | 18 | 7 | 0.19 | +374 | +53.4 |
| MOVES UNITS SPELL | 7 | 7 | 7 | 0.19 | +186 | +26.5 |
| SURE CHARGE BEATS ADVANCE | 7 | 7 | 7 | 0.19 | -275 | -39.2 |
| JOINT CHARGE PLAN | 14 | 14 | 6 | 0.17 | +165 | +27.6 |
| SPELLS IN THE FIGHT | 35 | 33 | 6 | 0.17 | +147 | +24.6 |
| SUPPORT NARROWED | 443 | 443 | 6 | 0.17 | -105 | -17.5 |
| WHOLE FIGHT | 28 | 28 | 6 | 0.17 | +123 | +20.5 |
| BLOCKED CHARGE SKIPPED | 5 | 5 | 5 | 0.14 | +0 | +0.0 |
| OPENS A LANE | 8 | 7 | 5 | 0.14 | +31 | +6.2 |
| OPENS UP | 11 | 11 | 5 | 0.14 | +89 | +17.9 |
| WIDER SPREAD | 214 | 207 | 5 | 0.14 | +54 | +10.8 |
| CATCH ODDS | 4 | 4 | 4 | 0.11 | -149 | -37.2 |
| OVERRUNS AWAY | 37 | 37 | 4 | 0.11 | +18 | +4.5 |
| REDIRECT BY WHAT IT STOPS | 22 | 22 | 4 | 0.11 | +165 | +41.2 |
| SURE REACH TOGETHER | 50 | 41 | 4 | 0.11 | +27 | +6.8 |
| WAR ENGINE CHARGES | 6 | 6 | 4 | 0.11 | +276 | +69.0 |
| FOCUS FIRE | 3 | 3 | 3 | 0.08 | +141 | +47.1 |
| HUNT ADVANCE | 5 | 5 | 3 | 0.08 | +75 | +24.9 |
| LOST CHARGE | 210 | 210 | 3 | 0.08 | +62 | +20.6 |
| BACKUP TARGETS | 68 | 28 | 2 | 0.06 | +26 | +13.2 |
| BOMBING RUN | 2 | 2 | 2 | 0.06 | +92 | +45.9 |
| CONTINUE AHEAD WEIGHED | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| ELIXIR WORTH | 2 | 2 | 2 | 0.06 | +62 | +31.2 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| LONG SHOT | 45 | 45 | 2 | 0.06 | +5 | +2.3 |
| MISSILES NEXT TURN | 323 | 164 | 2 | 0.06 | +1 | +0.5 |
| PERIAPT WORTH | 2 | 2 | 2 | 0.06 | +61 | +30.6 |
| RAIDS THE BAGGAGE NEXT TURN | 3 | 3 | 2 | 0.06 | +70 | +35.1 |
| STOPS | 2 | 2 | 2 | 0.06 | +53 | +26.5 |
| TWO OR MORE ARRIVE | 29 | 27 | 2 | 0.06 | +12 | +5.9 |
| BEST PRIZE | 1 | 1 | 1 | 0.03 | -25 | -25.2 |
| BLOWS WHERE AIMED | 20 | 19 | 1 | 0.03 | +66 | +66.4 |
| BOUND ASSAILMENT | 1 | 1 | 1 | 0.03 | +0 | +0.1 |
| CARRIES OUT COUNTER | 8 | 8 | 1 | 0.03 | -5 | -4.6 |
| CARRIES OUT SET-UP | 7 | 7 | 1 | 0.03 | -17 | -17.0 |
| CHARGER SLAIN LOST | 51 | 49 | 1 | 0.03 | +19 | +18.7 |
| CHARIOT NO STATIC JOB | 1 | 1 | 1 | 0.03 | -271 | -271.3 |
| DEFENSIVE FLOOR | 3 | 3 | 1 | 0.03 | +45 | +44.8 |
| FIRE AND FLEE | 1 | 1 | 1 | 0.03 | +4 | +3.7 |
| HORN WORTH | 1 | 1 | 1 | 0.03 | +16 | +16.5 |
| KEEP FALLS | 1 | 1 | 1 | 0.03 | +28 | +27.9 |
| LONE WIZARD HOLDS BACK | 10 | 10 | 1 | 0.03 | -183 | -183.0 |
| NO RALLY LEFT | 1 | 1 | 1 | 0.03 | +28 | +28.4 |
| SAFE SURE CHARGE | 1 | 1 | 1 | 0.03 | -587 | -587.1 |
| SCREEN BY WHAT IT SAVES | 16 | 16 | 1 | 0.03 | +16 | +16.4 |
| STANDS TO CAST | 1 | 1 | 1 | 0.03 | +4 | +3.6 |
| ALREADY CARRIED | 1 | not checked | - | - | - | - |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 36 | 36 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 36 | trace | - | - | - | - |
| CATCH FLIERS | 2 | not checked | - | - | - | - |
| CHARIOT WIZARD CAREFUL | 8 | 8 | 0 | 0.00 | - | - |
| CHEAP HELPER | 4 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 31 | not checked | - | - | - | - |
| DEFENSIVE ARMY | 8 | 8 | 0 | 0.00 | - | - |
| EDGE GIVE GROUND | 8 | 8 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 2 | 2 | 0 | 0.00 | - | - |
| FIGHT LIFT | 2 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 384 | not checked | - | - | - | - |
| GIVES UP | 2 | 2 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 4 | 4 | 0 | 0.00 | - | - |
| GROUND FLIERS | 2 | not checked | - | - | - | - |
| HELPER ALREADY ASKED | 1 | not checked | - | - | - | - |
| HELPER UNSEEN | 20 | 19 | 0 | 0.00 | - | - |
| HILL BY ITS CHANCE | 3 | 3 | 0 | 0.00 | - | - |
| HUNT DROPPED | 1 | trace | - | - | - | - |
| HUNT KEPT | 2 | trace | - | - | - | - |
| HUNT RESULT | 5 | trace | - | - | - | - |
| HUNT THE GUNS | 6 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 6 | 5 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 25 | not checked | - | - | - | - |
| LURE BY WHAT IT DRAWS | 2 | 2 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 2 | trace | - | - | - | - |
| MARCH OVER CASTS | 28 | 28 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 10 | 10 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 7 | 4 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 15 | trace | - | - | - | - |
| MOVE SPELL SPOT | 17 | not checked | - | - | - | - |
| NOT NEEDED | 16 | 16 | 0 | 0.00 | - | - |
| NOT TURNED | 384 | 384 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 43 | not checked | - | - | - | - |
| PLAN RESULT | 2708 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 12 | 12 | 0 | 0.00 | - | - |
| SCOUT SPOT | 23 | 23 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 16 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 15 | not checked | - | - | - | - |
| SET-UP MISSED | 4 | trace | - | - | - | - |
| SHOOTER COUNTED ONCE | 3 | 3 | 0 | 0.00 | - | - |
| SPELL CATCH ODDS | 1 | not checked | - | - | - | - |
| SPELL SETS UP CHARGE | 19 | not checked | - | - | - | - |
| SPELL WORTH | 103 | not checked | - | - | - | - |
| STABLE ROLE | 817 | 815 | 0 | 0.00 | - | - |
| TURN WORTH | 23 | 23 | 0 | 0.00 | - | - |

### Off best figure: jb-h2h-opp-b54c226-p1

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 15.14 | 14.36 | 53.2 |
| FALLBACK | gate | 0.64 | 0.78 | 55.1 |
| CHARGE NOW FIRST | rule | 0.64 | 0.56 | 74.4 |
| TURN GATE | gate | 0.50 | 0.50 | 33.8 |
| LONE CHARACTER SAFE SPOT | gate | 0.19 | 0.14 | 51.0 |
| AFTERMATH BAND | gate | 0.17 | 0.14 | 2.2 |
| PURSUES BIG PREY | rule | 0.17 | 0.11 | 125.9 |
| WAR ENGINE JOBS | rule | 0.11 | 0.17 | 90.9 |
| PATHS CROSS | rule | 0.11 | 0.14 | 23.1 |
| PIVOT GUARDS FLANK | rule | 0.08 | 0.17 | 10.9 |
| CANNON PLANNED TARGET | rule | 0.17 | - | 58.5 |
| CHAFF PASSED | rule | 0.06 | 0.11 | 8.3 |
| FIGHT ORDER BAND | gate | 0.14 | 0.03 | 2.0 |
| SURE CHARGE BEATS ADVANCE | rule | 0.11 | 0.06 | 45.7 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.08 | 0.06 | 39.2 |
| CHARGE NOW WEIGHED | rule | 0.06 | 0.08 | 14.7 |
| SUPPORT NARROWED | rule | 0.14 | - | 20.9 |
| SUPPORT REQUEST | gate | 0.06 | 0.08 | 47.1 |
| BIG CHARACTER SAFETY | rule | 0.06 | 0.06 | 4.9 |
| CATCH ODDS | rule | 0.06 | 0.06 | 37.2 |
| MARCH ODDS | rule | - | 0.11 | 19.0 |
| BLOCKED WHEEL | rule | - | 0.08 | 4.3 |
| STOPS SHORT OF THE FLANK | rule | 0.06 | 0.03 | 6.3 |
| THROUGH LINE OF FIRE | rule | 0.03 | 0.06 | 19.1 |
| MOVE AND CAST | rule | - | 0.06 | 17.1 |
| WHO HITS BACK | rule | - | 0.06 | 3.2 |
| BEST PRIZE | rule | - | 0.03 | 25.2 |
| CARRIES OUT COUNTER | rule | 0.03 | - | 4.6 |
| CARRIES OUT SET-UP | rule | - | 0.03 | 17.0 |
| CHARIOT NO STATIC JOB | rule | 0.03 | - | 271.3 |
| FRIENDS SHOTS CHECKED | rule | 0.03 | - | 3.5 |
| LONE WIZARD HOLDS BACK | rule | - | 0.03 | 183.0 |
| REFUSING RETIRES | rule | - | 0.03 | 1.4 |
| RULE SWITCHED OFF | gate | 0.03 | - | 7.3 |
| SAFE SURE CHARGE | rule | - | 0.03 | 587.1 |
| SAFER THAN THE JOB | rule | - | 0.03 | 0.8 |

### Plans: jb-h2h-opp-b54c226-p1

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 11.1 | 16% | 422 | 251 | 59% |
| Mine | charge | 3.5 | 67% | 268 | 353 | 132% |
| Mine | close in | 4.5 | 28% | 276 | 167 | 60% |
| Mine | hold | 5.1 | 45% | 351 | 0 | 0% |
| Mine | join | 0.6 | 100% | 18 | 0 | 0% |
| Mine | shoot | 9.6 | 60% | 326 | 630 | 193% |
| Mine | support | 3.5 | 88% | 21 | 0 | 0% |
| Opponent | advance | 12.6 | 15% | 424 | 277 | 65% |
| Opponent | charge | 3.9 | 51% | 300 | 300 | 100% |
| Opponent | close in | 5.7 | 22% | 327 | 102 | 31% |
| Opponent | hold | 4.2 | 45% | 280 | 0 | 0% |
| Opponent | join | 0.8 | 87% | 50 | 0 | 0% |
| Opponent | shoot | 4.6 | 52% | 124 | 192 | 155% |
| Opponent | support | 5.3 | 88% | 45 | 0 | 0% |

### Packages: hunt the guns, jb-h2h-opp-b54c226-p1

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.0 | 1 | 0 | 0% | 0% | 0% | - | 385 | 0 | 0% | 22 |
| Opponent | 0.1 | 5 | 1 | 25% | 25% | 0% | 2.0 | 457 | 119 | 25% | 66 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Dwarfen Mountain Holds | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 385 | 0 | 0% | 159 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 29 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 87 |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 83 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 216 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 52 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 48 |
| Tomb Kings of Khemri | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 12 |
| Vampire Counts | 0.2 | 2 | 0 | 50% | 50% | 0% | 2.0 | 408 | 238 | 50% | 8 |
| Warriors of Chaos | 0.2 | 2 | 1 | 0% | 0% | 0% | - | 685 | 0 | 0% | 25 |
| Wood Elf Realms | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 329 | 0 | 0% | 24 |

### Battle groups: jb-h2h-opp-b54c226-p1

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 9.4 | 22% | 60% | 11% | 50% | 36% | 4% | 4% | 55% | 0% |
| Mine | REDIRECT COUNTER | 2.1 | 32% | 67% | 0% | - | 21% | 4% | 21% | 50% | 4% |
| Opponent | COUNTER-CHARGE COVER | 7.3 | 18% | 48% | 29% | 21% | 29% | 15% | 12% | 44% | 0% |
| Opponent | REDIRECT COUNTER | 3.9 | 29% | 73% | 12% | 20% | 31% | 0% | 3% | 61% | 6% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: jb-h2h-opp-b54c226-p1

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 3 | 29 (3) | 29 | 0 | 0 | 33% | 5.0 | 36 (2) | 0 (1) | - | 78 (1) | 0 (2) |
| Mine | Chaff | 37 | 25 (37) | 9 | 16 | 56 | 32% | 2.3 | 11 (16) | 10 (9) | 51 (12) | 37 (24) | 6 (13) |
| Mine | Character | 123 | 53 (123) | 53 | 0 | 32 | 20% | 2.3 | 92 (35) | 43 (55) | 13 (10) | 72 (55) | 44 (45) |
| Mine | Clean-up | 24 | 78 (24) | 40 | 38 | 28 | 33% | 3.2 | 65 (9) | 111 (11) | 16 (4) | 81 (14) | 76 (10) |
| Mine | Fast | 4 | 111 (4) | 111 | 0 | 47 | 0% | 2.2 | 124 (1) | 0 (2) | 362 (1) | 111 (4) | - |
| Mine | Fast Hammer | 41 | 39 (41) | 26 | 13 | 55 | 22% | 2.7 | 34 (18) | 11 (12) | 73 (11) | 43 (28) | 31 (13) |
| Mine | Fragile | 5 | 14 (5) | 14 | 0 | 100 | 0% | 2.0 | - | 17 (4) | 0 (1) | 69 (1) | 0 (4) |
| Mine | Hammer | 58 | 56 (58) | 41 | 16 | 33 | 14% | 2.4 | 57 (10) | 56 (38) | 55 (10) | 63 (34) | 49 (24) |
| Mine | Holder | 25 | 83 (25) | 7 | 76 | 21 | 48% | 2.8 | 76 (8) | 100 (11) | 68 (5) | 132 (11) | 49 (13) |
| Mine | Shooter | 44 | 106 (44) | 36 | 71 | 32 | 7% | 1.7 | 64 (5) | 122 (32) | 79 (7) | 138 (24) | 70 (20) |
| Mine | Support | 5 | 19 (5) | 19 | 0 | 84 | 0% | 2.4 | 63 (2) | 0 (2) | - | 32 (2) | 0 (2) |
| Mine | War machine | 56 | 36 (56) | 36 | 0 | 31 | 7% | 1.2 | 56 (13) | 22 (37) | 80 (6) | 24 (11) | 39 (45) |
| Mine | Wizard | 23 | 18 (23) | 18 | 0 | 49 | 17% | 2.6 | 34 (6) | 19 (10) | 0 (2) | 67 (2) | 11 (16) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Chaff | 66 | 59 (66) | 22 | 37 | 40 | 39% | 2.9 | 86 (28) | 44 (16) | 37 (22) | 72 (48) | 23 (18) |
| Opponent | Character | 114 | 46 (114) | 45 | 1 | 37 | 21% | 2.5 | 74 (41) | 32 (56) | 0 (4) | 51 (68) | 46 (33) |
| Opponent | Clean-up | 16 | 35 (16) | 33 | 3 | 46 | 38% | 3.5 | 0 (5) | 47 (8) | 72 (3) | 49 (8) | 25 (8) |
| Opponent | Early | 1 | 0 (1) | 0 | 0 | 0 | 0% | 6.0 | - | 0 (1) | - | - | 0 (1) |
| Opponent | Fast Hammer | 58 | 52 (58) | 36 | 16 | 63 | 29% | 2.6 | 36 (25) | 24 (19) | 124 (14) | 53 (42) | 50 (16) |
| Opponent | Fragile | 10 | 0 (10) | 0 | 0 | 63 | 30% | 1.6 | 0 (3) | 0 (3) | 0 (3) | 0 (9) | - |
| Opponent | Hammer | 65 | 35 (65) | 25 | 10 | 52 | 20% | 2.5 | 3 (16) | 45 (42) | 37 (7) | 28 (40) | 49 (25) |
| Opponent | Holder | 40 | 67 (40) | 11 | 56 | 34 | 45% | 3.7 | 29 (10) | 84 (21) | 58 (9) | 76 (22) | 57 (18) |
| Opponent | Shooter | 30 | 82 (30) | 21 | 61 | 39 | 3% | 1.2 | 57 (7) | 81 (18) | 120 (5) | 95 (16) | 65 (14) |
| Opponent | Support | 2 | 0 (2) | 0 | 0 | 0 | 100% | - | 0 (1) | - | 0 (1) | 0 (1) | 0 (1) |
| Opponent | War machine | 13 | 54 (13) | 54 | 0 | 31 | 0% | 1.2 | 0 (5) | 95 (5) | 72 (3) | 101 (3) | 41 (10) |
| Opponent | Wizard | 22 | 11 (22) | 11 | 0 | 24 | 18% | 1.7 | 14 (11) | 8 (6) | 0 (2) | 11 (10) | 11 (9) |

### Charged fights: jb-h2h-opp-b54c226-p1

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 5 | 185 | 0 | 1.2 | 1.0 | 0 | 23 | -23 | 0 of 6 | 3 of 6 | - | -23 |
| Mine | Chaos Dwarfs | 3 | 241 | 1034 | 4.7 | 1.1 | 222 | 0 | +222 | 6 of 14 | 12 of 14 | +402 | +191 |
| Mine | Dwarfen Mountain Holds | 4 | 364 | 130 | 1.2 | 1.2 | 104 | 49 | +55 | 1 of 5 | 4 of 5 | +162 | +28 |
| Mine | Empire of Man | 5 | 222 | 255 | 2.4 | 1.0 | 106 | 0 | +106 | 5 of 12 | 7 of 12 | - | +106 |
| Mine | Grand Cathay | 4 | 752 | 292 | 3.5 | 1.1 | 84 | 48 | +36 | 8 of 14 | 8 of 14 | +393 | +9 |
| Mine | High Elf Realms | 4 | 130 | 634 | 4.2 | 1.3 | 149 | 16 | +133 | 8 of 17 | 13 of 17 | +193 | +108 |
| Mine | Kingdom of Bretonnia | 1 | 0 | 374 | 4.0 | 1.0 | 94 | 118 | -24 | 2 of 4 | 3 of 4 | - | -24 |
| Mine | Lizardmen | 1 | 140 | 752 | 4.0 | 1.0 | 188 | 79 | +109 | 2 of 4 | 3 of 4 | - | +109 |
| Mine | Ogre Kingdoms | 1 | 0 | 70 | 2.0 | 1.0 | 35 | 0 | +35 | 1 of 2 | 0 of 2 | - | +35 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 395 | 7.0 | 1.1 | 56 | 16 | +41 | 3 of 7 | 3 of 7 | +195 | +15 |
| Mine | Skaven | 2 | 22 | 22 | 2.5 | 1.2 | 9 | 80 | -71 | 2 of 5 | 2 of 4 | +45 | -100 |
| Mine | Tomb Kings of Khemri | 2 | 125 | 1398 | 5.5 | 1.1 | 254 | 0 | +254 | 3 of 11 | 10 of 11 | +938 | +186 |
| Mine | Vampire Counts | 2 | 0 | 268 | 4.0 | 1.5 | 67 | 101 | -34 | 1 of 8 | 6 of 8 | +92 | -160 |
| Mine | Warriors of Chaos | 1 | 27 | 267 | 5.0 | 1.0 | 53 | 0 | +53 | 3 of 5 | 4 of 5 | - | +53 |
| **Mine** | all armies | 36 | 228 | 384 | 3.2 | 1.1 | 121 | 30 | +91 | 45 of 114 | 78 of 113 | +242 | +67 |
| Opponent | Beastmen Brayherds | 1 | 0 | 1137 | 4.0 | 1.8 | 284 | 37 | +248 | 1 of 4 | 3 of 4 | +857 | +44 |
| Opponent | Dwarfen Mountain Holds | 1 | 0 | 0 | 2.0 | 1.0 | 0 | 0 | +0 | 1 of 2 | 2 of 2 | - | +0 |
| Opponent | Empire of Man | 1 | 399 | 0 | 2.0 | 1.0 | 0 | 0 | +0 | 2 of 2 | 1 of 2 | - | +0 |
| Opponent | Grand Cathay | 1 | 706 | 185 | 2.0 | 1.0 | 92 | 0 | +92 | 2 of 2 | 1 of 2 | - | +92 |
| Opponent | High Elf Realms | 2 | 104 | 465 | 4.5 | 1.1 | 103 | 49 | +54 | 3 of 9 | 7 of 9 | +316 | +22 |
| Opponent | Lizardmen | 1 | 189 | 344 | 4.0 | 1.0 | 86 | 0 | +86 | 2 of 4 | 3 of 4 | - | +86 |
| Opponent | Ogre Kingdoms | 2 | 52 | 190 | 3.5 | 1.1 | 54 | 76 | -21 | 1 of 7 | 4 of 7 | -399 | +42 |
| Opponent | Orc & Goblin Tribes | 2 | 35 | 190 | 3.0 | 1.2 | 64 | 127 | -64 | 3 of 6 | 4 of 6 | -55 | -65 |
| Opponent | Skaven | 2 | 202 | 102 | 0.5 | 2.0 | 205 | 0 | +205 | 1 of 1 | 1 of 1 | +205 | - |
| Opponent | Tomb Kings of Khemri | 4 | 68 | 890 | 4.8 | 1.3 | 187 | 73 | +115 | 10 of 19 | 12 of 19 | +230 | +84 |
| Opponent | Vampire Counts | 6 | 48 | 332 | 5.0 | 1.1 | 66 | 40 | +26 | 12 of 30 | 22 of 30 | +135 | +10 |
| Opponent | Warriors of Chaos | 7 | 27 | 195 | 2.1 | 1.1 | 91 | 27 | +64 | 5 of 15 | 10 of 15 | +136 | +53 |
| Opponent | Wood Elf Realms | 6 | 107 | 462 | 3.8 | 1.2 | 121 | 6 | +115 | 7 of 23 | 18 of 23 | +227 | +84 |
| **Opponent** | all armies | 36 | 96 | 368 | 3.4 | 1.2 | 107 | 40 | +67 | 50 of 124 | 88 of 124 | +190 | +43 |

### Effective charges: jb-h2h-opp-b54c226-p1

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 6 | 1 (net -52) | 1 (net +0) | 1 (net -85) | 0 | 0 | 1 (net +0) | 2 | 25% (1 of 4) |
| Mine | Chaos Dwarfs | 14 | 1 (net +388) | 1 (net +0) | 2 (net +358) | 2 (net +402) | 1 (net +685) | 7 (net +72) | 0 | 14% (2 of 14) |
| Mine | Dwarfen Mountain Holds | 5 | 1 (net +162) | 0 | 0 | 2 (net +56) | 0 | 2 (net +0) | 0 | 0% (0 of 5) |
| Mine | Empire of Man | 12 | 3 (net +144) | 0 | 1 (net +195) | 3 (net +114) | 3 (net +23) | 2 (net +118) | 0 | 8% (1 of 12) |
| Mine | Grand Cathay | 14 | 0 | 0 | 3 (net -181) | 6 (net +154) | 0 | 4 (net +31) | 1 | 23% (3 of 13) |
| Mine | High Elf Realms | 17 | 3 (net +52) | 0 | 4 (net +426) | 5 (net +102) | 1 (net -151) | 3 (net +0) | 1 | 25% (4 of 16) |
| Mine | Kingdom of Bretonnia | 4 | 0 | 0 | 0 | 3 (net -117) | 0 | 1 (net +254) | 0 | 0% (0 of 4) |
| Mine | Lizardmen | 4 | 0 | 0 | 1 (net +451) | 0 | 0 | 0 | 3 | 100% (1 of 1) |
| Mine | Ogre Kingdoms | 2 | 1 (net +70) | 0 | 0 | 0 | 0 | 0 | 1 | 0% (0 of 1) |
| Mine | Orc & Goblin Tribes | 7 | 0 | 0 | 1 (net +195) | 0 | 0 | 0 | 6 | 100% (1 of 1) |
| Mine | Skaven | 5 | 1 (net +0) | 0 | 2 (net -178) | 0 | 0 | 2 (net +0) | 0 | 40% (2 of 5) |
| Mine | Tomb Kings of Khemri | 11 | 2 (net +768) | 0 | 1 (net +232) | 4 (net +86) | 1 (net +110) | 2 (net +288) | 1 | 10% (1 of 10) |
| Mine | Vampire Counts | 8 | 0 | 0 | 1 (net +170) | 2 (net -282) | 0 | 3 (net +33) | 2 | 17% (1 of 6) |
| Mine | Warriors of Chaos | 5 | 2 (net +0) | 0 | 0 | 1 (net +0) | 0 | 2 (net +134) | 0 | 0% (0 of 5) |
| Opponent | Beastmen Brayherds | 4 | 0 | 0 | 2 (net +65) | 1 (net +3) | 0 | 1 (net +857) | 0 | 50% (2 of 4) |
| Opponent | Dwarfen Mountain Holds | 2 | 0 | 0 | 0 | 0 | 0 | 2 (net +0) | 0 | 0% (0 of 2) |
| Opponent | Empire of Man | 2 | 0 | 0 | 1 (net +0) | 1 (net +0) | 0 | 0 | 0 | 50% (1 of 2) |
| Opponent | Grand Cathay | 2 | 1 (net +185) | 0 | 0 | 1 (net +0) | 0 | 0 | 0 | 0% (0 of 2) |
| Opponent | High Elf Realms | 9 | 1 (net +0) | 0 | 3 (net -106) | 2 (net +289) | 0 | 1 (net +0) | 2 | 43% (3 of 7) |
| Opponent | Lizardmen | 4 | 0 | 0 | 0 | 0 | 0 | 1 (net +189) | 3 | 0% (0 of 1) |
| Opponent | Ogre Kingdoms | 7 | 0 | 0 | 2 (net -200) | 0 | 0 | 2 (net +0) | 3 | 50% (2 of 4) |
| Opponent | Orc & Goblin Tribes | 6 | 1 (net +219) | 0 | 0 | 0 | 0 | 1 (net -708) | 4 | 0% (0 of 2) |
| Opponent | Skaven | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +205) | 0 | 0% (0 of 1) |
| Opponent | Tomb Kings of Khemri | 19 | 2 (net +20) | 1 (net -735) | 4 (net +207) | 6 (net +125) | 1 (net +332) | 5 (net +192) | 0 | 21% (4 of 19) |
| Opponent | Vampire Counts | 30 | 4 (net -168) | 1 (net +0) | 7 (net +20) | 5 (net +79) | 2 (net +0) | 9 (net +123) | 2 | 25% (7 of 28) |
| Opponent | Warriors of Chaos | 15 | 2 (net +254) | 0 | 2 (net +148) | 3 (net +41) | 0 | 4 (net +74) | 4 | 18% (2 of 11) |
| Opponent | Wood Elf Realms | 23 | 3 (net +223) | 0 | 5 (net +63) | 10 (net +96) | 0 | 5 (net +140) | 0 | 22% (5 of 23) |

### Charged fights, damage counted: jb-h2h-opp-b54c226-p1

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 15 | 293 | 285 | +179 | 221 | 62 | +158 | +54.0 |
| Mine | 50-54% | 2 | 198 | 212 | +0 | 18 | 11 | +8 | +4.0 |
| Mine | Effective (55-75%) | 17 | 333 | 210 | +158 | 256 | 138 | +118 | +35.5 |
| Mine | 76-89% | 28 | 292 | 192 | +76 | 136 | 63 | +73 | +25.1 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 29 | 237 | 183 | +71 | 90 | 22 | +67 | +28.5 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 6 | 359 | 104 | +119 | 159 | 70 | +90 | +25.0 |
| Mine | No odds | 17 | 294 | 159 | +9 | 45 | 43 | +2 | +0.5 |
| Mine | All fights | 114 | 286 | 196 | +91 | 139 | 60 | +79 | +27.5 |
| Opponent | Long shot (under 50%) | 14 | 196 | 290 | +68 | 153 | 102 | +52 | +26.3 |
| Opponent | 50-54% | 2 | 245 | 228 | -368 | 0 | 368 | -368 | -150.0 |
| Opponent | Effective (55-75%) | 26 | 213 | 175 | +38 | 119 | 70 | +49 | +22.9 |
| Opponent | 76-89% | 29 | 318 | 182 | +97 | 122 | 17 | +105 | +32.9 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 32 | 261 | 184 | +113 | 163 | 46 | +117 | +44.8 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 3 | 430 | 100 | +111 | 153 | 7 | +147 | +34.1 |
| Opponent | No odds | 18 | 189 | 200 | +16 | 58 | 53 | +5 | +2.7 |
| Opponent | All fights | 124 | 250 | 195 | +67 | 125 | 56 | +69 | +27.6 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| jb-h2h-opp-b54c226-p1 | move | 459 | 104 (23%) | 80 (17%) | 58 (13%) | 297 (65%) |
| jb-h2h-opp-b54c226-p1 | objective | 369 | 70 (19%) | 53 (14%) | 42 (11%) | 257 (70%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0102, L0118, L0135, L2531, L2730 |
| Charmed Shield | Opponent | L0524, L1224, L1527, L1625, L2025, L2127, L2934 |
| Clockwork Compass | Mine | L1224 |
| Clockwork Compass | Opponent | L0612 |
| Elixir of Power | Mine | L1114, L1131, L1923 |
| Elixir of Power | Opponent | L0319, L1319 |
| Fistful of Laurels | Mine | L1823 |
| Fistful of Laurels | Opponent | L0118, L0218 |
| Horn of the Wild Hunt | Opponent | L0733 |
| Invocation of Nehek | Mine | L2531, L2730 |
| Invocation of Nehek | Opponent | L0524, L1224, L1527, L1625, L2025, L2127 |
| Opal Amulet | Mine | L1431 |
| Opal Amulet | Opponent | L1114 |
| Periapt of Soul Exchange | Mine | L2025, L2127 |
| Periapt of Soul Exchange | Opponent | L0421, L1021 |
| Ring of Doom | Mine | L0218, L0235, L1114, L1131, L1224, L1527 |
| Ring of Doom | Opponent | L0102, L0612, L0733, L1131, L1431, L2231, L2531 |
| Ring of Jet | Mine | L1021, L1114, L1131, L1224 |
| Ring of Jet | Opponent | L0612 |
| Standard of the Fell Warrior | Mine | L1319, L1335 |
| Standard of the Fell Warrior | Opponent | L0913 |
| Storm Daemon (Renegade 2.0) | Mine | L2127 |
| Storm Daemon (Renegade 2.0) | Opponent | L0421, L1021 |
| Twice-Blessed Armour | Mine | L0717, L0733, L1021 |
| Witch Hunter's Ward | Mine | L0717, L0733, L0823 |
| Witch Hunter's Ward | Opponent | L0508 |

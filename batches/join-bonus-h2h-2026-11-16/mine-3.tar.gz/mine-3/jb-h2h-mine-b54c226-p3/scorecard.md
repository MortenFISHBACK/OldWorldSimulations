# Doctrine scorecard: jb-h2h-mine-b54c226-p3

### Scorecard: jb-h2h-mine-b54c226-p3

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0110 | 2 | 1 | Mine | - | - | 3 | 1 | 2 | 0 | 0 | 0 | 0 |
| L0110 | 2 | 1 | Opponent | - | - | 2 | 3 | 0 | 0 | 0 | 0 | 330 |
| L0126 | 6 | 1 | Mine | no | 4 | 3 | 3 | 2 | 0 | 0 | 0 | 65 |
| L0126 | 6 | 1 | Opponent | no | 10 | 3 | 3 | 3 | 0 | 0 | 0 | 0 |
| L0210 | 6 | 1 | Mine | no | 0 | 2 | 0 | 4 | 0 | 0 | 0 | 0 |
| L0210 | 6 | 1 | Opponent | no | 11 | 3 | 2 | 0 | 0 | 0 | 0 | 330 |
| L0226 | 4 | 1 | Mine | no | 1 | 2 | 1 | 3 | 0 | 0 | 0 | 170 |
| L0226 | 4 | 1 | Opponent | no | 8 | 2 | 2 | 3 | 1 | 0 | 0 | 0 |
| L0311 | 5 | 1 | Mine | no | - | 5 | 2 | 1 | 0 | 0 | 0 | 590 |
| L0311 | 5 | 1 | Opponent | yes | - | 3 | 1 | 0 | 0 | 0 | 0 | 427 |
| L0327 | 3 | 1 | Mine | yes | 9 | 3 | 2 | 0 | 0 | 0 | 0 | 675 |
| L0327 | 3 | 1 | Opponent | no | 2 | 4 | 2 | 2 | 2 | 0 | 0 | 0 |
| L0413 | 5 | 1 | Mine | yes | - | 2 | 4 | 2 | 0 | 0 | 0 | 0 |
| L0413 | 5 | 1 | Opponent | no | - | 2 | 2 | 1 | 2 | 0 | 0 | 317 |
| L0429 | 3 | 1 | Mine | yes | 3 | 2 | 3 | 2 | 0 | 0 | 0 | 0 |
| L0429 | 3 | 1 | Opponent | no | 0 | 2 | 3 | 1 | 0 | 0 | 0 | 170 |
| L0516 | 6 | 1 | Mine | no | 0 | 4 | 1 | 0 | 0 | 0 | 0 | 666 |
| L0516 | 6 | 1 | Opponent | no | 2 | 2 | 3 | 1 | 0 | 0 | 0 | 200 |
| L0533 | 5 | 1 | Mine | no | - | 5 | 0 | 0 | 0 | 0 | 0 | 548 |
| L0533 | 5 | 1 | Opponent | yes | - | 2 | 2 | 5 | 0 | 0 | 0 | 0 |
| L0620 | 2 | 1 | Mine | - | - | 3 | 3 | 0 | 0 | 0 | 0 | 929 |
| L0620 | 2 | 1 | Opponent | - | - | 4 | 0 | 4 | 0 | 0 | 0 | 210 |
| L0709 | 1 | 1 | Mine | yes | 3 | 4 | 3 | 0 | 1 | 0 | 0 | 420 |
| L0709 | 1 | 1 | Opponent | no | 2 | 2 | 1 | 1 | 0 | 0 | 0 | 420 |
| L0725 | 5 | 1 | Mine | yes | - | 3 | 3 | 1 | 0 | 0 | 0 | 613 |
| L0725 | 5 | 1 | Opponent | yes | - | 2 | 5 | 0 | 0 | 0 | 0 | 0 |
| L0815 | 5 | 1 | Mine | yes | - | 6 | 1 | 1 | 0 | 0 | 0 | 515 |
| L0815 | 5 | 1 | Opponent | yes | - | 2 | 3 | 1 | 1 | 0 | 0 | 115 |
| L0831 | 3 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 807 |
| L0831 | 3 | 1 | Opponent | no | 2 | - | 0 | 2 | 1 | 0 | 0 | 170 |
| L0922 | 4 | 1 | Mine | no | 0 | 3 | 1 | 0 | 0 | 0 | 0 | 641 |
| L0922 | 4 | 1 | Opponent | no | 0 | 2 | 6 | 3 | 1 | 0 | 0 | 55 |
| L1013 | 5 | 1 | Mine | yes | - | 2 | 2 | 1 | 2 | 0 | 0 | 330 |
| L1013 | 5 | 1 | Opponent | no | - | 1 | 1 | 3 | 0 | 0 | 0 | 302 |
| L1030 | 4 | 1 | Mine | no | 1 | 2 | 2 | 0 | 1 | 0 | 0 | 501 |
| L1030 | 4 | 1 | Opponent | no | 0 | 2 | 2 | 2 | 2 | 0 | 0 | 0 |
| L1122 | 6 | 1 | Mine | no | 0 | - | 0 | 0 | 1 | 0 | 0 | 330 |
| L1122 | 6 | 1 | Opponent | no | 3 | 2 | 3 | 2 | 1 | 0 | 0 | 72 |
| L1216 | 4 | 1 | Mine | no | 0 | 2 | 3 | 0 | 1 | 0 | 0 | 330 |
| L1216 | 4 | 1 | Opponent | no | 0 | 2 | 3 | 0 | 0 | 0 | 0 | 200 |
| L1232 | 2 | 1 | Mine | - | - | 2 | 2 | 0 | 0 | 0 | 0 | 330 |
| L1232 | 2 | 1 | Opponent | - | - | 3 | 2 | 4 | 0 | 0 | 0 | 340 |
| L1327 | 1 | 1 | Mine | no | 4 | 4 | 1 | 0 | 1 | 0 | 0 | 140 |
| L1327 | 1 | 1 | Opponent | no | 3 | 1 | 5 | 1 | 0 | 0 | 0 | 0 |
| L1422 | 6 | 1 | Mine | no | 5 | 3 | 2 | 1 | 0 | 0 | 0 | 177 |
| L1422 | 6 | 1 | Opponent | no | 2 | 2 | 6 | 1 | 1 | 0 | 0 | 0 |
| L1519 | 1 | 1 | Mine | no | 3 | 2 | 4 | 0 | 0 | 0 | 0 | 0 |
| L1519 | 1 | 1 | Opponent | no | 0 | 2 | 6 | 1 | 1 | 0 | 0 | 0 |
| L1535 | 5 | 1 | Mine | yes | - | 3 | 2 | 1 | 0 | 0 | 0 | 0 |
| L1535 | 5 | 1 | Opponent | yes | - | 2 | 2 | 2 | 0 | 0 | 0 | 0 |
| L1633 | 1 | 1 | Mine | yes | 2 | 2 | 1 | 1 | 0 | 0 | 0 | 200 |
| L1633 | 1 | 1 | Opponent | no | 1 | 1 | 3 | 3 | 1 | 0 | 0 | 549 |
| L1731 | 3 | 1 | Mine | yes | 1 | 4 | 1 | 0 | 0 | 0 | 0 | 0 |
| L1731 | 3 | 1 | Opponent | no | 2 | 2 | 2 | 1 | 3 | 0 | 0 | 170 |
| L1831 | 1 | 1 | Mine | no | 2 | 3 | 5 | 1 | 1 | 0 | 0 | 0 |
| L1831 | 1 | 1 | Opponent | no | 2 | - | 0 | 0 | 0 | 0 | 0 | 0 |
| L1932 | 6 | 1 | Mine | no | 0 | 2 | 5 | 0 | 1 | 0 | 0 | 235 |
| L1932 | 6 | 1 | Opponent | no | 1 | 2 | 2 | 2 | 2 | 0 | 0 | 340 |
| L2033 | 5 | 1 | Mine | yes | - | - | 0 | 6 | 0 | 0 | 0 | 210 |
| L2033 | 5 | 1 | Opponent | no | - | 5 | 2 | 3 | 0 | 0 | 0 | 0 |
| L2223 | 3 | 1 | Mine | no | 1 | 1 | 3 | 1 | 0 | 0 | 0 | 170 |
| L2223 | 3 | 1 | Opponent | no | 4 | 2 | 5 | 1 | 0 | 0 | 0 | 0 |
| L2327 | 5 | 1 | Mine | yes | - | 2 | 2 | 1 | 0 | 0 | 0 | 185 |
| L2327 | 5 | 1 | Opponent | yes | - | 2 | 2 | 4 | 0 | 0 | 0 | 0 |
| L2433 | 3 | 1 | Mine | no | 1 | 3 | 5 | 0 | 0 | 0 | 0 | 0 |
| L2433 | 3 | 1 | Opponent | no | 0 | 2 | 2 | 1 | 1 | 0 | 0 | 0 |
| L2630 | 2 | 1 | Mine | - | - | 2 | 7 | 2 | 0 | 0 | 0 | 0 |
| L2630 | 2 | 1 | Opponent | - | - | 2 | 3 | 2 | 0 | 0 | 0 | 0 |
| L2832 | 6 | 1 | Mine | no | 0 | 2 | 2 | 0 | 0 | 0 | 0 | 0 |
| L2832 | 6 | 1 | Opponent | no | 0 | 2 | 3 | 2 | 0 | 0 | 0 | 139 |
| L3133 | 1 | 1 | Mine | no | 7 | 2 | 0 | 1 | 0 | 0 | 0 | 120 |
| L3133 | 1 | 1 | Opponent | no | 7 | 4 | 2 | 1 | 0 | 0 | 0 | 405 |
| **Average** | | | Mine | 38% | 2.0 | 2.8 | 2.1 | 1.0 | 0.2 | 0.0 | 0.0 | 274.9 |
| **Average** | | | Opponent | 19% | 2.7 | 2.3 | 2.6 | 1.8 | 0.6 | 0.0 | 0.0 | 146.1 |

### KPIs: jb-h2h-mine-b54c226-p3

Rules off - Opponent only: JOINS A FRIEND.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 22% (38 of 173) | 12% (22 of 176) | 17% (60 of 349) |
| Winner chose to follow up after the loser gave ground |  | 100% (52 of 52); on the table 100% | 96% (53 of 55); on the table 96% | 98% (105 of 107); on the table 98% |
| Winner chose to pursue after the loser fell back in good order |  | 100% (10 of 10); on the table 100% | 80% (8 of 10); on the table 80% | 90% (18 of 20); on the table 90% |
| Winner chose to pursue after the loser fled |  | 83% (19 of 23); on the table 96% | 77% (17 of 22); on the table 86% | 80% (36 of 45); on the table 91% |
| Winner chose to follow up or pursue (all three) |  | 95% (81 of 85); on the table 99% | 90% (78 of 87); on the table 92% | 92% (159 of 172); on the table 95% |
| Magic missiles tried each own turn | 50%+ | 34% (116 of 342) | 46% (89 of 192) | 38% (205 of 534) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 49% (116 of 239) | 57% (89 of 157) | 52% (205 of 396) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 57% (13 of 23) | 51% (33 of 65) | 52% (46 of 88) |
| Points that never fought | lower | 33% (23038 of 68801) | 41% (29846 of 71990) | 38% (52884 of 140791) |
|   infantry points that never fought | lower | 44% (6246 of 14174) | 59% (8460 of 14220) | 52% (14706 of 28394) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 57% (155 of 272) | 59% (169 of 285) | 58% (324 of 557) |
| Bound items with a magic missile used (at least once a game) |  | 100% (25 of 25); 2.3 uses a game | 88% (21 of 24); 1.9 uses a game | 94% (46 of 49); 2.1 uses a game |
| Bound items with another spell used |  | 43% (6 of 14); 0.4 uses a game | 33% (2 of 6); 0.1 uses a game | 40% (8 of 20); 0.2 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 65% (13 of 20); 0.4 uses a game | 43% (6 of 14); 0.2 uses a game | 56% (19 of 34); 0.3 uses a game |
|   their share of the points of units over 100 pts | lower | 53% (31329 of 59391) | 53% (34128 of 64043) | 53% (65457 of 123434) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.5 (23%) | 0.9 (30%) | 2.3 (26%) |
| MARCHED: its unit marched | 1.4 (22%) | 0.7 (23%) | 2.0 (22%) |
| CHARGED: its unit charged | 0.3 (5%) | 0.2 (9%) | 0.6 (6%) |
| IN COMBAT: engaged in combat | 1.3 (21%) | 0.5 (17%) | 1.8 (20%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.1 (4%) | 0.1 (2%) |
| FLEEING: fleeing | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) |
| GONE: slain | 1.3 (21%) | 0.3 (12%) | 1.6 (18%) |
| OFF THE TABLE: off the table or not arrived | 0.2 (4%) | 0.1 (4%) | 0.4 (4%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| NOT OFFERED: not in the cast list | 0.1 (2%) | 0.0 (0%) | 0.1 (2%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.8 | 1.0 | 1.7 | 5.7 | 0.9 | 1.6 |
| not cast | 4.1 | 1.5 | 4.4 | 9.1 | 2.4 | 19.1 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) | 1.0 (5%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.1 (1%) | 0.6 (40%) | 0.4 (10%) | 2.3 (26%) | 0.3 (11%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.0 (22%) | 0.3 (13%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.6 (6%) | 0.1 (3%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.2 (5%) | 0.1 (7%) | 0.6 (13%) | 1.8 (20%) | 0.3 (14%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.2 (4%) | 0.0 (0%) | 0.3 (6%) | 0.1 (2%) | 0.1 (3%) | 0.0 (0%) |
| FLEEING: fleeing | 0.1 (3%) | 0.1 (5%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) | 0.2 (1%) |
| GONE: slain | 1.3 (32%) | 0.3 (18%) | 1.2 (28%) | 1.6 (18%) | 0.7 (29%) | 3.7 (19%) |
| OFF THE TABLE: off the table or not arrived | 0.1 (3%) | 0.1 (9%) | 0.2 (4%) | 0.4 (4%) | 0.2 (8%) | 0.7 (3%) |
| STUPIDITY: Stupidity | 0.1 (1%) | 0.0 (0%) | 0.1 (2%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.2 (4%) | 0.0 (2%) | 0.0 (0%) | 0.1 (1%) | 0.4 (18%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (2%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.9 (46%) | 0.3 (18%) | 1.5 (34%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 13.4 (71%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.3 a game | 0.6 a game | 0.9 a game |
| stood (cast and not dispelled) | 62% (24 of 39) | 47% (7 of 15) | 57% (31 of 54) |
| the unit moved after it | 79% (19 of 24) | 86% (6 of 7) | 81% (25 of 31) |
| it charged on its next turn | 4% (1 of 24) | 14% (1 of 7) | 6% (2 of 31) |
| the enemy charged it first | 25% (6 of 24) | 29% (2 of 7) | 26% (8 of 31) |
| it fought by the end of its next turn | 12% (3 of 24) | 14% (1 of 7) | 13% (4 of 31) |
| it moved out of a charge the enemy had planned (not charged first) | 42% (10 of 24) | 14% (1 of 7) | 35% (11 of 31) |
| none of these (no charge, no fight, no charge escaped) | 29% (7 of 24) | 43% (3 of 7) | 32% (10 of 31) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 64% (487 of 764) | 54% (332 of 612) | 60% (819 of 1376) |
|   cavalry | 61% (36 of 59) | 55% (58 of 106) | 57% (94 of 165) |
|   character | 64% (57 of 89) | 25% (28 of 113) | 42% (85 of 202) |
|   chariot | 42% (42 of 101) | 42% (10 of 24) | 42% (52 of 125) |
|   infantry | 55% (119 of 215) | 59% (161 of 273) | 57% (280 of 488) |
|   monster | 33% (13 of 39) | 20% (1 of 5) | 32% (14 of 44) |
|   war machine | 84% (220 of 261) | 81% (74 of 91) | 84% (294 of 352) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.6 (34%) | 1.8 (24%) | 4.5 (29%) |
| CHARGED: it charged | 0.8 (11%) | 1.4 (18%) | 2.2 (14%) |
| FLEEING: it fled or was fleeing | 0.1 (1%) | 0.2 (2%) | 0.3 (2%) |
| IN COMBAT: it fought this turn or the last | 0.8 (10%) | 0.5 (7%) | 1.3 (8%) |
| MOVED: a war machine that moved | 0.1 (1%) | 0.0 (0%) | 0.1 (0%) |
| NO TARGET IN RANGE | 1.0 (13%) | 1.2 (16%) | 2.2 (14%) |
| ONLY IN COMBAT: the only targets were in combat | 0.3 (4%) | 0.9 (11%) | 1.2 (8%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.4 (18%) | 1.4 (18%) | 2.8 (18%) |
| SHELTERED: the target was sheltered | 0.2 (3%) | 0.1 (2%) | 0.4 (3%) |
| STUPIDITY | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR | 0.4 (5%) | 0.2 (3%) | 0.6 (4%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 4.0 | 1.1 | 80% | 6.9 pts | 28 pts |
| character | 2.9 | 1.2 | 74% | 7.2 pts | 21 pts |
| chariot | 1.4 | 1.0 | 65% | 21.1 pts | 31 pts |
| infantry | 11.9 | 4.1 | 76% | 8.6 pts | 102 pts |
| monster | 0.4 | 0.2 | 81% | 19.8 pts | 9 pts |
| war machine | 8.6 | 7.8 | 59% | 24.1 pts | 207 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.0 | 4.9 | 4.5 |
| Charges that made contact a game | 3.0 | 3.4 | 3.2 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.67 declared, 0.52 contact (27 units) | 1.15 declared, 0.77 contact (13 units) | 0.82 declared, 0.60 contact (40 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.25 declared, 0.25 contact (4 units) | 0.91 declared, 0.55 contact (11 units) | 0.73 declared, 0.47 contact (15 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.57 declared, 0.41 contact (222 units) | 0.56 declared, 0.40 contact (268 units) | 0.57 declared, 0.41 contact (490 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 45% (35 of 77) | 53% (8 of 15) | 60% (6 of 10) | 48% (49 of 102) |
| Character in a unit | 91% (31 of 34) | 53% (9 of 17) | 60% (3 of 5) | 77% (43 of 56) |
| Character on its own | 81% (35 of 43) | 46% (18 of 39) | 36% (25 of 70) | 51% (78 of 152) |
| Chariot | 91% (10 of 11) | 75% (9 of 12) | - | 83% (19 of 23) |
| Infantry | 60% (42 of 70) | 45% (19 of 42) | 20% (1 of 5) | 53% (62 of 117) |
| Monster | 65% (22 of 34) | 43% (3 of 7) | - | 61% (25 of 41) |
| Monstrous | 80% (8 of 10) | 73% (8 of 11) | - | 76% (16 of 21) |
| War Machines | 70% (30 of 43) | 100% (2 of 2) | - | 71% (32 of 45) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 100% (7 of 7); on the table 100% | 40% (38 of 96) | 16% | 59% (13 of 22) | 100% (6 of 6); 5.8 uses a game | 50% (1 of 2); 1.0 uses a game | 67% (4 of 6); 1.0 uses a game |
| Chaos Dwarfs | 4 | 80% (8 of 10); on the table 100% | 44% (16 of 36) | 44% | 56% (18 of 32) | 0.0 uses a game | 0.0 uses a game | 100% (2 of 2); 0.5 uses a game |
| Dwarfen Mountain Holds | 3 | 100% (2 of 2); on the table 100% | - | 51% | 75% (18 of 24) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 6 | 100% (6 of 6); on the table 100% | 53% (16 of 30) | 52% | 66% (39 of 59) | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game | 25% (1 of 4); 0.2 uses a game |
| Grand Cathay | 8 | 87% (13 of 15); on the table 93% | 40% (76 of 192) | 43% | 58% (43 of 74) | 94% (17 of 18); 6.6 uses a game | 50% (2 of 4); 0.4 uses a game | 62% (5 of 8); 0.6 uses a game |
| High Elf Realms | 7 | 100% (19 of 19); on the table 100% | 33% (14 of 42) | 28% | 52% (28 of 54) | 100% (9 of 9); 4.6 uses a game | 42% (5 of 12); 1.4 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 3 | 91% (10 of 11); on the table 100% | - | 35% | 28% (5 of 18) | 0.0 uses a game | 0.0 uses a game | 100% (3 of 3); 1.0 uses a game |
| Lizardmen | 1 | 100% (3 of 3); on the table 100% | 67% (4 of 6) | 22% | 71% (5 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 1 | 100% (4 of 4); on the table 100% | 0% (0 of 6) | 68% | 71% (5 of 7) | 100% (1 of 1); 5.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 2 | 100% (9 of 9); on the table 100% | 8% (1 of 12) | 2% | 75% (12 of 16) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.5 uses a game |
| Skaven | 2 | 100% (5 of 5); on the table 100% | 8% (1 of 12) | 61% | 43% (6 of 14) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.5 uses a game |
| Tomb Kings of Khemri | 6 | 85% (11 of 13); on the table 85% | 17% (1 of 6) | 36% | 42% (11 of 26) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 8 | 100% (23 of 23); on the table 100% | 37% (20 of 54) | 29% | 57% (26 of 46) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 11 | 85% (29 of 34); on the table 88% | 50% (15 of 30) | 39% | 57% (55 of 96) | 100% (4 of 4); 1.0 uses a game | 0.0 uses a game | 100% (2 of 2); 0.2 uses a game |
| Wood Elf Realms | 6 | 91% (10 of 11); on the table 91% | 25% (3 of 12) | 42% | 65% (40 of 62) | 82% (9 of 11); 4.5 uses a game | 0.0 uses a game | 0% (0 of 5); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (jb-h2h-mine-b54c226-p3, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 51% (43) | 45% (32) | 48% (75) |
| ...free all their last turn and able to turn (per game) | 0.83 | 0.53 | 1.36 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.22 | 0.14 | 0.36 |
| ...with the charger already in that arc before they moved (per game) | 0.61 | 0.39 | 1.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 2.08 | 1.28 | 3.36 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 1.03 | 0.75 | 1.78 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 6.06 | 6.08 | 12.14 |

### Quality by phase: jb-h2h-mine-b54c226-p3

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.2 | 3.6 |
| Strategy | Charge objectives carried out (made contact) | 61% (77 of 127) | 49% (72 of 146) |
| Strategy | Shoot objectives carried out (shot that target) | 48% (171 of 356) | 48% (102 of 214) |
| Strategy | Close-in objectives charged next turn | 15% (24 of 161) | 13% (28 of 215) |
| Strategy | Support requests answered (helper made contact too) | 58% (11 of 19) | 48% (13 of 27) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (3 of 3) | 100% (1 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | 33% (4 of 12) | 67% (2 of 3) |
| Strategy | Joined characters whose unit fought | 66% (29 of 44) | 18% (7 of 40) |
| Strategy | Lone characters that fought | 75% (68 of 91) | 78% (73 of 94) |
| Movement | Charges halted short of contact | 0.1 | 0.2 |
| Movement | Idle units | 1.0 | 1.8 |
| Movement | Points that never moved of their own | 274.9 | 146.1 |
| Movement | Fights charged into per game | 2.4 | 3.0 |
| Movement | Charges with odds: long shots (under 50%) | 9 of 81, net +145 | 20 of 94, net +28 |
| Movement | Charges with odds: sweet spot (55-75%) | 11 of 81, net +155 | 12 of 94, net +78 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 9 of 81, net +200 | 3 of 94, net +48 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 26 of 81, net +81 | 28 of 94, net +124 |
| Shooting | Shots by shooting units (incl. breath weapons) | 7.9 | 8.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 39% (111 of 286) | 47% (148 of 314) |
| Shooting | Points destroyed by shooting units | 48.6 | 59.3 |
| Shooting | War machine shots | 6.1 | 2.5 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 50% (110 of 220) | 42% (38 of 90) |
| Shooting | Points destroyed by war machines | 53.1 | 29.9 |
| Magic | Magic missiles cast | 2.0 | 1.5 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 40% (29 of 72) | 40% (21 of 53) |
| Magic | Wounds caused by magic missiles | 3.9 | 2.2 |
| Magic | Wounds caused by other spells | 1.4 | 1.2 |
| Magic | Points destroyed by magic (all spells) | 112.6 | 56.9 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.6 / 0.3 / 0.7 / 0.1 | 2.0 / 0.1 / 0.4 / 0.3 |
| Combat | Points destroyed in combat | 402.5 | 372.8 |
| Combat | Points run down | 51.1 | 88.9 |
| Combat | Net points per charged fight, damage counted | +112 | +89 |
| Combat | Net per 100 charger points, damage counted | +36.0 | +31.2 |
| Combat | First round won (charged fights) | 80% | 74% |
| Combat | Net points per charged fight | +110 | +83 |
| Combat | Net points per supported fight / lone fight | +145 / +102 | +87 / +82 |
| Combat | Charged fights on a top-3 enemy unit | 32 of 88 | 57 of 109 |
| Game | Points lost | 741.8 | 736.9 |
| Game | VP from objectives | 569.7 | 516.1 |
| Game | Lone holders (player turns) | 2.0 | 2.7 |

- Mine won / drew / lost: 17 / 10 / 9 of 36 ended games (of 36); mean margin (Mine - Opponent) +71 VP
- The side that went first won 11 of 26 games with a winner
- Points traded per game (both sides' losses): 1479
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: jb-h2h-mine-b54c226-p3

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.6 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 0.0 |
| ALREADY CARRIED | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARRIVAL HUNT | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +0.3 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.7 | +0.0 | 0.0 | 23.8 | 0.2 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | 1.1 | +7.2 | 0.0 | 45.4 | 0.9 | +6.8 | 0.0 | 37.6 |
| BEST FACING | 1.0 | +60.1 | 0.0 | 30.6 | 0.4 | +27.3 | 0.0 | 21.2 |
| BEST FIRST | 4.3 | +195.8 | 251.6 | 90.2 | 3.3 | +150.2 | 105.1 | 24.4 |
| BEST OVERALL | 0.9 | +54.3 | 0.0 | 11.2 | 0.3 | +24.1 | 0.0 | 5.4 |
| BEST PREY | 0.8 | +40.8 | 12.8 | 16.8 | 0.9 | +34.1 | 3.8 | 0.0 |
| BEST PRIZE | - | - | - | - | 0.1 | -0.7 | 0.0 | 1.7 |
| BIG CHARACTER SAFETY | 0.3 | -1.7 | 0.0 | 21.5 | 0.2 | -2.1 | 0.0 | 13.3 |
| BLOCKED CHARGE SKIPPED | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 1.9 | 0.0 |
| BLOCKED WHEEL | 0.3 | +1.1 | 0.0 | 0.0 | 0.4 | +7.1 | 0.0 | 0.5 |
| BLOWS WHERE AIMED | 0.4 | -47.7 | 58.3 | 17.3 | 0.1 | -24.5 | 0.0 | 0.0 |
| CANNON PLAN MISSED | 0.6 | +0.0 | 26.8 | 6.5 | 0.2 | +0.0 | 55.9 | 0.0 |
| CANNON PLANNED TARGET | 5.4 | +148.2 | 284.1 | 124.2 | 1.5 | +80.6 | 130.6 | 18.9 |
| CANNON SIGHT KEPT | 1.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT COUNTER | 0.0 | +0.0 | 13.3 | 0.0 | - | - | - | - |
| CARRIES OUT SET-UP | 0.2 | -9.0 | 48.3 | 15.4 | 0.1 | +0.0 | 2.9 | 3.2 |
| CAST JOB | 1.0 | +33.6 | 75.8 | 37.2 | 0.5 | +12.4 | 24.1 | 17.4 |
| CASTER AWAY FROM SCREEN | 0.2 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.3 | +27.2 | 13.6 | 0.0 | 0.1 | +2.4 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 0.7 | +0.0 | 0.0 | 66.2 | 0.3 | +0.0 | 0.0 | 16.4 |
| CASTS FROM BEHIND | 0.0 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CATCH ODDS | 0.0 | +0.4 | 0.0 | 0.0 | - | - | - | - |
| CHAFF PASSED | 0.2 | -0.6 | 10.3 | 10.8 | 0.1 | -0.3 | 3.5 | 2.0 |
| CHARGE BAND | 0.1 | +0.0 | 13.6 | 4.5 | 0.1 | +0.0 | 10.2 | 0.0 |
| CHARGE NOW FIRST | 2.2 | +0.0 | 252.9 | 68.3 | 2.2 | +0.0 | 191.6 | 157.0 |
| CHARGE NOW WEIGHED | 0.8 | -81.9 | 56.6 | 30.9 | 0.6 | -41.9 | 13.5 | 24.9 |
| CHARGER SLAIN LOST | 0.6 | -17.2 | 51.2 | 21.0 | 0.8 | -18.5 | 32.0 | 46.3 |
| CHARIOT NO STATIC JOB | 0.1 | +0.0 | 0.0 | 2.4 | - | - | - | - |
| CHARIOT WIZARD CAREFUL | - | - | - | - | 0.2 | -2.1 | 0.0 | 11.1 |
| CHEAP HELPER | 0.1 | +0.0 | 0.0 | 5.0 | 0.1 | +0.0 | 7.4 | 2.0 |
| COMBAT PIVOT | 0.5 | +0.0 | 39.7 | 36.4 | 0.4 | +0.0 | 34.8 | 9.4 |
| CONTINUE AHEAD WEIGHED | 0.1 | +0.0 | 5.3 | 0.0 | - | - | - | - |
| CONVEYANCE SEARCH | 0.7 | +87.4 | 42.6 | 47.4 | 0.3 | +27.3 | 22.2 | 34.0 |
| COUNTER-CHARGE COVER | 10.0 | +832.7 | 0.0 | 233.2 | 7.2 | +606.8 | 0.0 | 138.7 |
| DEFENSIVE ARMY | 0.1 | +0.0 | 10.6 | 0.0 | 0.1 | +0.0 | 10.6 | 6.6 |
| EDGE GIVE GROUND | 0.2 | +8.7 | 11.5 | 4.0 | 0.2 | +3.0 | 17.6 | 17.9 |
| ELIXIR WORTH | 0.1 | +0.9 | 0.0 | 8.2 | - | - | - | - |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 2.1 | +156.7 | 0.0 | 53.1 | 1.3 | +109.0 | 0.0 | 64.3 |
| FALLBACK BY WORTH | 4.8 | +80.5 | 0.0 | 24.0 | 5.8 | +58.6 | 0.0 | 40.1 |
| FIGHT LIFT | 0.1 | +0.1 | 0.0 | 0.0 | 0.0 | +0.5 | 13.1 | 0.0 |
| FIRE AND FLEE | 0.0 | +0.4 | 2.9 | 2.2 | - | - | - | - |
| FLANK NOT WEIGHED | 6.5 | +0.0 | 0.0 | 142.8 | 5.8 | +0.0 | 0.0 | 103.2 |
| FOCUS FIRE | - | - | - | - | 0.0 | +1.0 | 1.8 | 0.0 |
| FOLLOW UP WEIGHED | 1.0 | +153.6 | 0.0 | 47.0 | 1.1 | +160.3 | 0.0 | 36.5 |
| FRIENDS SHOTS CHECKED | 0.2 | +11.5 | 0.0 | 16.1 | 0.1 | +20.3 | 0.0 | 0.0 |
| GIVES UP | 0.1 | -1.3 | 23.6 | 0.0 | 0.1 | -0.2 | 7.7 | 0.0 |
| GIVES UP ITS SCREEN | - | - | - | - | 0.1 | -0.9 | 3.2 | 0.0 |
| GROUND FLIERS | 0.1 | +7.0 | 0.0 | 0.0 | - | - | - | - |
| HELPER ALREADY ASKED | 0.1 | +0.0 | 14.7 | 4.5 | 0.1 | +0.0 | 16.1 | 0.0 |
| HELPER UNSEEN | 0.3 | +0.0 | 35.4 | 6.4 | 0.3 | +0.0 | 43.2 | 1.5 |
| HILL BY ITS CHANCE | 0.2 | -28.8 | 0.0 | 0.0 | 0.5 | -70.4 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 7.1 | -119.8 | 481.1 | 162.4 | 7.7 | -199.0 | 395.5 | 188.1 |
| HORN WORTH | - | - | - | - | 0.0 | +0.4 | 0.0 | 0.0 |
| HUNT ADVANCE | 0.2 | +12.2 | 9.2 | 6.2 | 0.1 | +2.7 | 3.5 | 0.0 |
| HUNT DROPPED | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 2.0 |
| HUNT IN PAIRS | 0.3 | +8.7 | 0.0 | 15.9 | 0.8 | +52.5 | 0.0 | 13.9 |
| HUNT KEPT | 0.1 | +5.7 | 4.6 | 3.9 | 0.1 | +1.1 | 3.5 | 1.5 |
| HUNT RESULT | 0.2 | +9.3 | 0.0 | 3.9 | 0.2 | +26.0 | 28.0 | 5.9 |
| HUNT THE GUNS | 0.2 | +67.0 | 4.6 | 3.8 | 0.3 | +101.8 | 27.8 | 5.4 |
| INVITES THE FIGHT | 1.7 | +29.4 | 50.0 | 33.1 | 1.1 | +18.8 | 53.4 | 15.5 |
| JOINS A FRIEND | 1.9 | +13.9 | 190.0 | 21.8 | - | - | - | - |
| JOINT CHARGE PLAN | 0.1 | +2.7 | 0.0 | 3.2 | 0.4 | +16.9 | 10.3 | 4.7 |
| JOINT KNOWS CHALLENGE | - | - | - | - | 0.2 | -11.2 | 26.0 | 3.2 |
| KEEP FALLS | 0.1 | +3.7 | 0.0 | 0.0 | 0.0 | +0.1 | 0.0 | 0.0 |
| KEEPS ITS PREY | - | - | - | - | 0.1 | +0.2 | 0.0 | 0.0 |
| KEEPS ITS TARGET | 1.7 | +51.7 | 183.1 | 50.4 | 1.8 | +54.2 | 140.4 | 29.9 |
| KEEPS SCOUTS OR AMBUSH | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KILLS COUNT | 1.5 | +75.8 | 107.7 | 24.2 | 1.4 | +74.2 | 129.4 | 49.9 |
| KILLS COUNT NEXT TURN | 5.2 | +156.4 | 200.6 | 134.3 | 7.0 | +234.9 | 156.0 | 106.5 |
| LONE CHARACTER SAFE SPOT | 0.3 | +12.0 | 7.5 | 5.8 | 0.5 | +11.2 | 18.4 | 22.0 |
| LONE WIZARD HOLDS BACK | 0.1 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 5.3 |
| LONE WIZARD KEPT IN | 0.6 | +37.3 | 0.0 | 0.0 | 0.4 | +25.4 | 0.0 | 0.0 |
| LONG SHOT | 0.5 | +4.1 | 26.6 | 8.4 | 0.2 | -0.9 | 7.6 | 1.2 |
| LOST CHARGE | 2.8 | -52.7 | 185.9 | 116.4 | 2.6 | -40.6 | 62.3 | 63.4 |
| MAKE SURE TOGETHER | 1.1 | +129.9 | 63.3 | 19.1 | 0.8 | +65.1 | 20.7 | 24.2 |
| MANOEUVRE | 0.2 | +4.3 | 0.0 | 6.8 | 0.2 | +7.9 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.1 | +1.5 | 0.0 | 7.2 | 0.0 | +0.0 | 0.0 | 0.0 |
| MARCH CHECK | 0.7 | +44.4 | 0.0 | 12.8 | 0.6 | +29.9 | 0.0 | 0.0 |
| MARCH ODDS | 0.4 | +15.8 | 4.8 | 6.5 | 0.3 | +18.2 | 16.3 | 10.9 |
| MARCH OVER CASTS | 0.5 | +29.0 | 0.0 | 33.4 | 0.3 | +8.2 | 0.0 | 22.2 |
| MAX FOR POSITIONING | 5.0 | +180.4 | 0.0 | 156.1 | 4.1 | +168.7 | 0.0 | 104.3 |
| MISSILES IN THE MOVE | 4.6 | +141.5 | 0.0 | 140.5 | 4.1 | +65.1 | 0.0 | 75.7 |
| MISSILES NEXT TURN | 5.4 | +96.3 | 0.0 | 145.3 | 5.1 | +54.6 | 0.0 | 97.7 |
| MODEL FACING | 0.1 | +29.2 | 0.0 | 0.0 | - | - | - | - |
| MONSTER WIZARD ROAMS | 0.1 | +0.0 | 32.3 | 12.1 | 0.2 | +0.0 | 10.3 | 0.0 |
| MOVE AND CAST | 0.4 | +34.1 | 0.0 | 0.0 | 0.5 | +27.9 | 0.0 | 31.0 |
| MOVE SPELL IN RANGE | 0.2 | +5.2 | 0.0 | 21.1 | - | - | - | - |
| MOVE SPELL NOT WORTH | 0.0 | -0.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.6 | -18.8 | 0.0 | 33.6 | 0.1 | -0.8 | 2.9 | 13.0 |
| MOVE SPELL SPOT | 0.4 | +0.0 | 0.0 | 32.2 | 0.1 | +0.0 | 0.0 | 11.1 |
| MOVE TO CHARGE | 3.1 | +256.5 | 187.8 | 99.6 | 4.4 | +389.4 | 87.9 | 83.2 |
| MOVES UNITS SPELL | 0.1 | +3.6 | 0.0 | 0.0 | 0.1 | +0.3 | 0.0 | 0.0 |
| NEEDED THERE | 0.0 | +3.8 | 0.0 | 0.0 | - | - | - | - |
| NOT NEEDED | 0.2 | -12.9 | 22.8 | 4.5 | 0.1 | -5.7 | 8.0 | 0.0 |
| NOT TURNED | 6.1 | +122.8 | 0.0 | 122.4 | 6.1 | +98.4 | 0.0 | 71.2 |
| NOT WORTH A CAST | 0.6 | -0.4 | 0.0 | 21.1 | 0.7 | -0.8 | 0.0 | 0.0 |
| OFF BEST | 16.0 | -825.0 | 12.6 | 254.1 | 14.9 | -865.2 | 11.3 | 237.9 |
| OPENS A LANE | 0.1 | +0.3 | 4.4 | 10.5 | 0.1 | +0.4 | 10.9 | 20.5 |
| OPENS UP | 0.0 | +1.8 | 3.1 | 0.0 | 0.1 | +7.0 | 3.5 | 0.0 |
| OVERRUNS AWAY | 0.4 | +5.7 | 45.4 | 4.0 | 0.3 | +10.8 | 19.1 | 10.3 |
| PATHS CROSS | 1.8 | +129.2 | 0.0 | 56.5 | 2.5 | +161.5 | 0.0 | 33.0 |
| PERIAPT WORTH | - | - | - | - | 0.0 | +1.5 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.2 | -2.3 | 0.0 | 5.1 | 0.1 | -3.1 | 0.0 | 2.1 |
| PLAN RESULT | 36.1 | +1317.2 | 1341.5 | 978.1 | 37.2 | +1351.6 | 1395.0 | 893.6 |
| PURSUES BIG PREY | 0.0 | -0.9 | 0.0 | 0.0 | 0.0 | -0.5 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE | - | - | - | - | 0.0 | +4.9 | 0.0 | 1.5 |
| RAIDS THE BAGGAGE NEXT TURN | 0.1 | +8.2 | 0.0 | 0.0 | 0.1 | +3.5 | 0.0 | 1.5 |
| RANDOM MOVE BY FIGURES | 0.6 | +10.1 | 0.0 | 14.2 | 1.8 | +32.0 | 0.0 | 37.8 |
| RANDOM MOVER NO PROMISE | 0.1 | -5.7 | 0.0 | 0.0 | 0.3 | -15.8 | 6.2 | 0.0 |
| REDIRECT BY WHAT IT STOPS | 0.4 | -5.8 | 0.0 | 0.0 | 0.7 | -11.4 | 0.0 | 1.1 |
| REDIRECT COUNTER | 1.7 | +138.3 | 0.0 | 40.4 | 3.4 | +265.6 | 0.0 | 44.3 |
| REDIRECT WEIGHED | 0.2 | +0.9 | 3.5 | 0.0 | 0.4 | +0.1 | 0.0 | 9.6 |
| REFUSING RETIRES | 0.4 | +0.0 | 0.0 | 9.8 | 0.4 | +0.0 | 0.0 | 3.2 |
| RESERVE FALL BACK | 0.5 | +10.2 | 0.0 | 4.1 | 0.9 | +42.3 | 0.0 | 15.2 |
| RESTRAINS TO SHOOT | 0.0 | +0.4 | 0.0 | 0.0 | 0.1 | +2.2 | 0.0 | 0.0 |
| RISK BY ARC | 2.0 | +52.8 | 188.6 | 56.5 | 2.6 | +84.2 | 189.6 | 122.0 |
| SAFER THAN THE JOB | 1.0 | +75.7 | 0.0 | 15.7 | 0.8 | +40.9 | 0.0 | 0.0 |
| SCOUT SPOT | 0.4 | +0.6 | 0.0 | 0.9 | 0.3 | +1.0 | 0.0 | 0.0 |
| SCOUT WAITS | 0.4 | +0.0 | 0.0 | 0.9 | 0.3 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.1 | -1.1 | 0.0 | 0.9 | 0.2 | -9.1 | 0.0 | 1.6 |
| SEARCH SPOT | 2.6 | +137.3 | 0.0 | 56.8 | 2.4 | +98.2 | 0.0 | 56.3 |
| SECOND HUNTER | 0.0 | -1.2 | 0.0 | 0.0 | - | - | - | - |
| SELF MOVE SPELL | 0.3 | +44.0 | 0.0 | 40.1 | 0.2 | +54.8 | 0.0 | 9.1 |
| SET UP TOGETHER | 1.4 | +147.5 | 63.3 | 25.5 | 1.7 | +142.1 | 20.7 | 52.5 |
| SET-UP ANY TARGET | 0.4 | +73.4 | 31.4 | 26.4 | 0.2 | +26.2 | 11.1 | 17.6 |
| SET-UP MISSED | 0.1 | +6.2 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | 0.4 | +0.7 | 0.0 | 0.0 | 0.1 | +0.3 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.0 | +45.6 | 37.2 | 4.8 | 0.7 | +23.3 | 17.2 | 12.5 |
| SHORT GUN FORWARD | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SHOT REPLANNED | 0.4 | +0.0 | 54.8 | 12.6 | 0.2 | +0.0 | 31.9 | 0.0 |
| SHOTS IN THE MOVE | 13.2 | +478.1 | 0.0 | 292.5 | 9.1 | +353.7 | 0.0 | 90.6 |
| SPELL SETS UP CHARGE | 0.5 | +98.4 | 31.4 | 26.4 | 0.2 | +30.4 | 22.2 | 28.7 |
| SPELL WORTH | 1.4 | +18.8 | 38.3 | 57.9 | 2.3 | +34.7 | 136.5 | 117.5 |
| SPELLS IN THE FIGHT | 0.4 | +0.9 | 57.8 | 5.9 | 0.7 | -19.7 | 57.2 | 84.9 |
| STABLE ROLE | 10.4 | +0.0 | 370.6 | 168.3 | 9.2 | +0.0 | 255.4 | 152.6 |
| STANDS TO CAST | 0.1 | +3.6 | 0.0 | 10.2 | - | - | - | - |
| STAY WEIGHED | - | - | - | - | 0.0 | +5.2 | 0.0 | 0.0 |
| STOPS | 0.1 | +4.2 | 0.0 | 1.5 | 0.2 | +5.2 | 24.3 | 6.9 |
| STOPS SHORT OF THE FLANK | 0.7 | +26.3 | 0.0 | 41.4 | 0.3 | +17.5 | 0.0 | 14.7 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 4.7 |
| SUPPORT NARROWED | 4.9 | -41.2 | 296.4 | 138.4 | 6.4 | -58.6 | 385.0 | 179.9 |
| SUPPORTS | 3.2 | +46.8 | 133.6 | 96.3 | 4.6 | +61.1 | 242.2 | 71.2 |
| SURE CHARGE BEATS ADVANCE | 0.2 | -3.8 | 17.2 | 15.1 | 0.1 | -2.0 | 5.8 | 0.0 |
| SURE REACH TOGETHER | 0.6 | +7.1 | 15.2 | 11.4 | 0.4 | -4.5 | 0.0 | 11.1 |
| THROUGH LINE OF FIRE | 0.5 | +19.3 | 0.0 | 4.6 | 0.3 | +22.0 | 0.0 | 0.0 |
| TURN WORTH | 0.2 | -11.0 | 14.3 | 0.0 | 0.2 | -18.5 | 25.5 | 2.9 |
| TWO OR MORE ARRIVE | 0.4 | +3.5 | 21.2 | 4.5 | 0.5 | +5.1 | 20.7 | 15.4 |
| WAIT AFTER COSTS | 6.9 | -322.1 | 332.4 | 162.9 | 6.8 | -364.2 | 170.8 | 115.7 |
| WALKS TO THE FIGHT | 1.5 | +28.9 | 39.1 | 18.2 | 0.7 | +9.0 | 17.0 | 14.0 |
| WAR ENGINE CHARGES | 0.1 | +5.2 | 3.4 | 0.0 | - | - | - | - |
| WAR ENGINE JOBS | 0.5 | +0.0 | 29.4 | 21.2 | 0.2 | +0.0 | 1.7 | 5.8 |
| WEARS DOWN | 1.2 | +50.9 | 140.4 | 45.0 | 1.1 | +56.6 | 68.3 | 84.9 |
| WHO HITS BACK | 0.2 | +18.6 | 0.0 | 4.5 | 0.2 | +9.1 | 0.0 | 4.2 |
| WHOLE FIGHT | 0.3 | +14.1 | 56.9 | 19.0 | 0.4 | +25.1 | 40.4 | 2.2 |
| WHOLE FIGHT GAIN | 0.4 | +52.5 | 69.2 | 9.4 | 0.6 | +27.5 | 37.8 | 22.4 |
| WIDER SPREAD | 2.2 | -3.2 | 248.0 | 51.2 | 2.6 | -3.6 | 228.0 | 94.0 |

### Rule changes: jb-h2h-mine-b54c226-p3

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 1110 | 1110 | 1110 | 30.83 | -60850 | -54.8 |
| BEST FIRST | 275 | 275 | 275 | 7.64 | +12457 | +45.3 |
| SEARCH SPOT | 180 | 180 | 179 | 4.97 | +8496 | +47.5 |
| PATHS CROSS | 157 | 157 | 157 | 4.36 | +10465 | +66.7 |
| COUNTER-CHARGE COVER | 619 | 330 | 145 | 4.03 | +9139 | +63.0 |
| MOVE TO CHARGE | 270 | 270 | 139 | 3.86 | +9428 | +67.8 |
| KILLS COUNT NEXT TURN | 440 | 440 | 127 | 3.53 | +2892 | +22.8 |
| FACES THE THREAT | 121 | 121 | 121 | 3.36 | +9566 | +79.1 |
| SUPPORTS | 280 | 280 | 104 | 2.89 | +1013 | +9.7 |
| FALLBACK BY WORTH | 379 | 379 | 82 | 2.28 | +5011 | +61.1 |
| FOLLOW UP WEIGHED | 77 | 77 | 77 | 2.14 | +11301 | +146.8 |
| ARTILLERY RE-ROLL WEIGHED | 71 | 71 | 71 | 1.97 | +0 | +0.0 |
| SHOTS IN THE MOVE | 803 | 544 | 67 | 1.86 | +1400 | +20.9 |
| WAIT AFTER COSTS | 490 | 490 | 65 | 1.81 | +1014 | +15.6 |
| SAFER THAN THE JOB | 64 | 64 | 64 | 1.78 | +4197 | +65.6 |
| CANNON SIGHT KEPT | 56 | 56 | 56 | 1.56 | +0 | +0.0 |
| CHARGE NOW WEIGHED | 53 | 53 | 53 | 1.47 | +3037 | +57.3 |
| BEST FACING | 51 | 51 | 51 | 1.42 | +3149 | +61.7 |
| RESERVE FALL BACK | 50 | 50 | 50 | 1.39 | +1887 | +37.7 |
| MAX FOR POSITIONING | 326 | 163 | 46 | 1.28 | +503 | +10.9 |
| RANDOM MOVE BY FIGURES | 88 | 88 | 46 | 1.28 | +1515 | +32.9 |
| SET UP TOGETHER | 111 | 95 | 46 | 1.28 | +3283 | +71.4 |
| BEST OVERALL | 42 | 42 | 42 | 1.17 | +2825 | +67.3 |
| MARCH CHECK | 48 | 47 | 42 | 1.17 | +2340 | +55.7 |
| MISSILES IN THE MOVE | 312 | 160 | 40 | 1.11 | +435 | +10.9 |
| HOLDS AMBUSHERS | 39 | 39 | 39 | 1.08 | +0 | +0.0 |
| REDIRECT COUNTER | 186 | 101 | 39 | 1.08 | +2763 | +70.9 |
| WALKS TO THE FIGHT | 79 | 79 | 39 | 1.08 | +622 | +15.9 |
| RISK BY ARC | 165 | 163 | 37 | 1.03 | +1156 | +31.3 |
| CANNON PLANNED TARGET | 248 | 248 | 36 | 1.00 | -437 | -12.2 |
| ADVANCE LANE KEPT | 35 | 35 | 35 | 0.97 | +0 | +0.0 |
| STOPS SHORT OF THE FLANK | 35 | 35 | 35 | 0.97 | +1576 | +45.0 |
| LONE WIZARD KEPT IN | 33 | 33 | 33 | 0.92 | +2259 | +68.5 |
| CAST JOB | 56 | 56 | 32 | 0.89 | +836 | +26.1 |
| CHARGE NOW FIRST | 160 | 160 | 32 | 0.89 | -2061 | -64.4 |
| COMBAT PIVOT | 32 | 32 | 32 | 0.89 | +0 | +0.0 |
| MOVE AND CAST | 32 | 32 | 32 | 0.89 | +2231 | +69.7 |
| SHOOTS FROM THE BEST SPOT | 62 | 62 | 31 | 0.86 | +905 | +29.2 |
| KILLS COUNT | 104 | 103 | 29 | 0.81 | +1276 | +44.0 |
| THROUGH LINE OF FIRE | 29 | 29 | 29 | 0.81 | +1486 | +51.2 |
| BLOCKED WHEEL | 28 | 28 | 28 | 0.78 | +294 | +10.5 |
| KEEPS ITS TARGET | 127 | 127 | 28 | 0.78 | +476 | +17.0 |
| HONEST WORTH | 534 | 533 | 27 | 0.75 | +208 | +7.7 |
| SCOUT WAITS | 25 | 25 | 25 | 0.69 | +0 | +0.0 |
| INVITES THE FIGHT | 99 | 99 | 24 | 0.67 | +432 | +18.0 |
| MARCH ODDS | 25 | 25 | 24 | 0.67 | +179 | +7.4 |
| MAKE SURE TOGETHER | 69 | 50 | 23 | 0.64 | +1860 | +80.9 |
| REDIRECT WEIGHED | 23 | 23 | 23 | 0.64 | +691 | +30.0 |
| BEST PREY | 60 | 60 | 22 | 0.61 | +828 | +37.6 |
| SHOT REPLANNED | 21 | 21 | 21 | 0.58 | +0 | +0.0 |
| BIG CHARACTER SAFETY | 20 | 20 | 20 | 0.56 | -138 | -6.9 |
| SHOOTERS IN TWO RANKS | 18 | 18 | 18 | 0.50 | +36 | +2.0 |
| WHO HITS BACK | 16 | 16 | 16 | 0.44 | +664 | +41.5 |
| STUCK PIVOT | 15 | 15 | 15 | 0.42 | +0 | +0.0 |
| CASTING BLOCK | 15 | 15 | 14 | 0.39 | +681 | +48.6 |
| WEARS DOWN | 83 | 82 | 14 | 0.39 | +429 | +30.6 |
| WHOLE FIGHT GAIN | 36 | 35 | 14 | 0.39 | +737 | +52.6 |
| CHAFF PASSED | 13 | 13 | 13 | 0.36 | -34 | -2.6 |
| FRIENDS SHOTS CHECKED | 12 | 12 | 12 | 0.33 | +1145 | +95.4 |
| MANOEUVRE | 16 | 16 | 12 | 0.33 | +440 | +36.7 |
| HUNT IN PAIRS | 40 | 21 | 11 | 0.31 | +497 | +45.2 |
| REFUSING RETIRES | 29 | 29 | 11 | 0.31 | -4 | -0.4 |
| SURE CHARGE BEATS ADVANCE | 11 | 11 | 11 | 0.31 | -210 | -19.1 |
| JOINS A FRIEND | 70 | 70 | 10 | 0.28 | +45 | +4.5 |
| LOST CHARGE | 195 | 195 | 10 | 0.28 | +292 | +29.2 |
| WAR ENGINE JOBS | 25 | 25 | 10 | 0.28 | -148 | -14.8 |
| CASTER AWAY FROM SCREEN | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| CASTS FROM BEHIND | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| PIVOT GUARDS FLANK | 9 | 9 | 9 | 0.25 | -194 | -21.5 |
| WHOLE FIGHT | 23 | 23 | 9 | 0.25 | +457 | +50.7 |
| CHARGE BAND | 8 | 8 | 8 | 0.22 | +0 | +0.0 |
| WIDER SPREAD | 172 | 167 | 8 | 0.22 | +72 | +9.1 |
| MISSILES NEXT TURN | 378 | 197 | 7 | 0.19 | +9 | +1.3 |
| MOVES UNITS SPELL | 7 | 7 | 7 | 0.19 | +141 | +20.1 |
| LONE WIZARD HOLDS BACK | 18 | 18 | 6 | 0.17 | -485 | -80.8 |
| BLOCKED CHARGE SKIPPED | 5 | 5 | 5 | 0.14 | +0 | +0.0 |
| KEEP FALLS | 5 | 5 | 5 | 0.14 | +288 | +57.6 |
| RAIDS THE BAGGAGE NEXT TURN | 5 | 5 | 5 | 0.14 | +181 | +36.2 |
| SHORT GUN FORWARD | 5 | 5 | 5 | 0.14 | +0 | +0.0 |
| MODEL FACING | 4 | 4 | 4 | 0.11 | +1053 | +263.2 |
| OPENS UP | 5 | 5 | 4 | 0.11 | +66 | +16.5 |
| OVERRUNS AWAY | 25 | 25 | 4 | 0.11 | +58 | +14.5 |
| RESTRAINS TO SHOOT | 4 | 4 | 4 | 0.11 | +93 | +23.2 |
| SPELLS IN THE FIGHT | 38 | 36 | 4 | 0.11 | +69 | +17.2 |
| SURE REACH TOGETHER | 38 | 30 | 4 | 0.11 | +44 | +10.9 |
| CHARIOT NO STATIC JOB | 3 | 3 | 3 | 0.08 | -218 | -72.6 |
| EDGE GIVE GROUND | 16 | 16 | 3 | 0.08 | +156 | +51.8 |
| HUNT ADVANCE | 10 | 10 | 3 | 0.08 | +166 | +55.5 |
| LONG SHOT | 24 | 24 | 3 | 0.08 | -9 | -2.9 |
| STANDS TO CAST | 3 | 3 | 3 | 0.08 | -7 | -2.4 |
| SUPPORT NARROWED | 409 | 409 | 3 | 0.08 | -25 | -8.2 |
| BACKUP TARGETS | 72 | 30 | 2 | 0.06 | +15 | +7.3 |
| BEST PRIZE | 2 | 2 | 2 | 0.06 | -26 | -13.0 |
| CONTINUE AHEAD WEIGHED | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| ELIXIR WORTH | 2 | 2 | 2 | 0.06 | +33 | +16.4 |
| PURSUES BIG PREY | 2 | 2 | 2 | 0.06 | -51 | -25.7 |
| CARRIES OUT SET-UP | 14 | 14 | 1 | 0.03 | -324 | -324.4 |
| CATCH ODDS | 1 | 1 | 1 | 0.03 | -2 | -1.8 |
| DEFENSIVE ARMY | 8 | 8 | 1 | 0.03 | -54 | -53.8 |
| FIRE AND FLEE | 1 | 1 | 1 | 0.03 | +15 | +15.1 |
| FOCUS FIRE | 1 | 1 | 1 | 0.03 | +38 | +37.6 |
| HORN WORTH | 1 | 1 | 1 | 0.03 | +14 | +13.5 |
| JOINT CHARGE PLAN | 18 | 18 | 1 | 0.03 | +12 | +11.9 |
| KEEPS SCOUTS OR AMBUSH | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| NEEDED THERE | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.03 | +54 | +54.4 |
| RAIDS THE BAGGAGE | 1 | 1 | 1 | 0.03 | +156 | +155.7 |
| STAY WEIGHED | 1 | 1 | 1 | 0.03 | +187 | +187.1 |
| STOPS | 14 | 14 | 1 | 0.03 | +28 | +28.3 |
| ALREADY CARRIED | 1 | not checked | - | - | - | - |
| ARRIVAL HUNT | 3 | 3 | 0 | 0.00 | - | - |
| BLOWS WHERE AIMED | 20 | 18 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 29 | 29 | 0 | 0.00 | - | - |
| CARRIES OUT COUNTER | 1 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 36 | trace | - | - | - | - |
| CHARGER SLAIN LOST | 50 | 48 | 0 | 0.00 | - | - |
| CHARIOT WIZARD CAREFUL | 6 | 6 | 0 | 0.00 | - | - |
| CHEAP HELPER | 6 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 38 | not checked | - | - | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT LIFT | 3 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 444 | not checked | - | - | - | - |
| GIVES UP | 6 | 6 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 3 | 3 | 0 | 0.00 | - | - |
| GROUND FLIERS | 3 | not checked | - | - | - | - |
| HELPER ALREADY ASKED | 6 | not checked | - | - | - | - |
| HELPER UNSEEN | 21 | 21 | 0 | 0.00 | - | - |
| HILL BY ITS CHANCE | 25 | 25 | 0 | 0.00 | - | - |
| HUNT DROPPED | 5 | trace | - | - | - | - |
| HUNT KEPT | 8 | trace | - | - | - | - |
| HUNT RESULT | 15 | trace | - | - | - | - |
| HUNT THE GUNS | 17 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 7 | 6 | 0 | 0.00 | - | - |
| KEEPS ITS PREY | 3 | 3 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 29 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 6 | trace | - | - | - | - |
| MARCH OVER CASTS | 29 | 29 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 11 | 11 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 8 | 5 | 0 | 0.00 | - | - |
| MOVE SPELL NOT WORTH | 1 | not checked | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 24 | trace | - | - | - | - |
| MOVE SPELL SPOT | 21 | not checked | - | - | - | - |
| NOT NEEDED | 11 | 11 | 0 | 0.00 | - | - |
| NOT TURNED | 437 | 437 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 46 | not checked | - | - | - | - |
| OPENS A LANE | 10 | 3 | 0 | 0.00 | - | - |
| PLAN RESULT | 2638 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 14 | 14 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 38 | 38 | 0 | 0.00 | - | - |
| SCOUT SPOT | 24 | 24 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 10 | 10 | 0 | 0.00 | - | - |
| SECOND HUNTER | 1 | 1 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 17 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 23 | not checked | - | - | - | - |
| SET-UP MISSED | 2 | trace | - | - | - | - |
| SPELL SETS UP CHARGE | 28 | not checked | - | - | - | - |
| SPELL WORTH | 134 | not checked | - | - | - | - |
| STABLE ROLE | 706 | 704 | 0 | 0.00 | - | - |
| TURN WORTH | 14 | 14 | 0 | 0.00 | - | - |
| TWO OR MORE ARRIVE | 35 | 31 | 0 | 0.00 | - | - |
| WAR ENGINE CHARGES | 2 | 2 | 0 | 0.00 | - | - |

### Off best figure: jb-h2h-mine-b54c226-p3

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 14.22 | 12.81 | 56.3 |
| FALLBACK | gate | 0.56 | 0.72 | 47.7 |
| TURN GATE | gate | 0.67 | 0.61 | 34.4 |
| CHARGE NOW FIRST | rule | 0.36 | 0.50 | 66.5 |
| LONE CHARACTER SAFE SPOT | gate | 0.11 | 0.36 | 67.9 |
| CANNON PLANNED TARGET | rule | 0.25 | 0.08 | 52.6 |
| BIG CHARACTER SAFETY | rule | 0.17 | 0.14 | 14.2 |
| CHARGE NOW WEIGHED | rule | 0.19 | 0.11 | 50.5 |
| SURE CHARGE BEATS ADVANCE | rule | 0.19 | 0.11 | 19.1 |
| AFTERMATH BAND | gate | 0.11 | 0.17 | 1.9 |
| PIVOT GUARDS FLANK | rule | 0.17 | 0.08 | 21.5 |
| WAR ENGINE JOBS | rule | 0.22 | 0.03 | 16.3 |
| SUPPORT REQUEST | gate | 0.11 | 0.11 | 115.9 |
| CHAFF PASSED | rule | 0.08 | 0.11 | 4.9 |
| LONE WIZARD HOLDS BACK | rule | 0.03 | 0.14 | 80.8 |
| BLOCKED WHEEL | rule | 0.06 | 0.08 | 34.4 |
| FIGHT ORDER BAND | gate | 0.08 | 0.06 | 1.7 |
| SAFER THAN THE JOB | rule | 0.03 | 0.11 | 15.3 |
| STOPS SHORT OF THE FLANK | rule | 0.11 | 0.03 | 13.1 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.08 | 0.03 | 40.9 |
| MARCH ODDS | rule | 0.06 | 0.06 | 15.9 |
| CHARIOT NO STATIC JOB | rule | 0.08 | - | 72.6 |
| FALLBACK BY WORTH | rule | - | 0.08 | 7.7 |
| PATHS CROSS | rule | 0.03 | 0.06 | 6.9 |
| SUPPORT NARROWED | rule | 0.03 | 0.06 | 8.2 |
| BEST PRIZE | rule | - | 0.06 | 13.0 |
| PURSUES BIG PREY | rule | 0.03 | 0.03 | 25.7 |
| REFUSING RETIRES | rule | - | 0.06 | 1.0 |
| CARRIES OUT SET-UP | rule | 0.03 | - | 324.4 |
| CATCH ODDS | rule | 0.03 | - | 1.8 |
| DEFENSIVE ARMY | rule | - | 0.03 | 53.8 |
| FACES THE THREAT | rule | 0.03 | - | 13.9 |
| LONG SHOT | rule | 0.03 | - | 38.0 |
| NO REASON | gate | 0.03 | - | 5.0 |
| STANDS TO CAST | rule | 0.03 | - | 12.1 |
| THROUGH LINE OF FIRE | rule | 0.03 | - | 4.2 |

### Plans: jb-h2h-mine-b54c226-p3

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 11.9 | 18% | 421 | 350 | 83% |
| Mine | charge | 3.0 | 61% | 272 | 294 | 108% |
| Mine | close in | 4.5 | 32% | 269 | 157 | 58% |
| Mine | hold | 4.3 | 39% | 269 | 0 | 0% |
| Mine | join | 0.3 | 75% | 8 | 0 | 0% |
| Mine | shoot | 8.6 | 59% | 211 | 517 | 244% |
| Mine | support | 3.6 | 90% | 28 | 0 | 0% |
| Opponent | advance | 12.4 | 17% | 328 | 350 | 107% |
| Opponent | charge | 3.6 | 64% | 297 | 382 | 129% |
| Opponent | close in | 5.9 | 22% | 362 | 145 | 40% |
| Opponent | hold | 4.1 | 37% | 294 | 0 | 0% |
| Opponent | join | 0.9 | 97% | 35 | 0 | 0% |
| Opponent | shoot | 5.1 | 61% | 186 | 475 | 255% |
| Opponent | support | 5.2 | 87% | 43 | 0 | 0% |

### Packages: hunt the guns, jb-h2h-mine-b54c226-p3

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.2 | 6 | 0 | 0% | 17% | 0% | 3.0 | 402 | 56 | 17% | 58 |
| Opponent | 0.3 | 11 | 2 | 33% | 33% | 0% | 2.0 | 366 | 104 | 33% | 54 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 1.2 | 5 | 0 | 0% | 20% | 0% | 3.0 | 391 | 67 | 20% | 56 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 145 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 32 |
| Empire of Man | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 458 | 0 | 0% | 63 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 102 |
| High Elf Realms | 0.1 | 1 | 0 | 0% | 0% | 0% | - | 506 | 0 | 0% | 25 |
| Kingdom of Bretonnia | 0.3 | 1 | 0 | 0% | 0% | 0% | - | 434 | 0 | 0% | 0 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Orc & Goblin Tribes | 0.5 | 1 | 0 | 0% | 0% | 0% | - | 441 | 0 | 0% | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 32 |
| Tomb Kings of Khemri | 0.5 | 3 | 1 | 50% | 50% | 0% | 2.0 | 469 | 270 | 50% | 44 |
| Vampire Counts | 0.4 | 3 | 1 | 100% | 100% | 0% | 2.0 | 235 | 198 | 100% | 69 |
| Warriors of Chaos | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 37 |
| Wood Elf Realms | 0.3 | 2 | 0 | 0% | 0% | 0% | - | 251 | 0 | 0% | 78 |

### Battle groups: jb-h2h-mine-b54c226-p3

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 10.0 | 21% | 56% | 6% | 40% | 35% | 11% | 11% | 43% | 0% |
| Mine | REDIRECT COUNTER | 1.7 | 34% | 67% | 5% | 0% | 10% | 5% | 5% | 75% | 5% |
| Opponent | COUNTER-CHARGE COVER | 7.2 | 17% | 61% | 7% | 0% | 34% | 7% | 7% | 51% | 0% |
| Opponent | REDIRECT COUNTER | 3.4 | 19% | 78% | 9% | 0% | 10% | 0% | 5% | 86% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: jb-h2h-mine-b54c226-p3

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 1 | 0 (1) | 0 | 0 | 100 | 0% | 4.0 | - | 0 (1) | - | 0 (1) | - |
| Mine | Chaff | 34 | 39 (34) | 10 | 29 | 49 | 35% | 2.5 | 56 (21) | 0 (4) | 10 (9) | 58 (24) | 0 (10) |
| Mine | Character | 118 | 54 (118) | 54 | 0 | 38 | 15% | 2.5 | 61 (36) | 60 (62) | 8 (6) | 52 (62) | 63 (42) |
| Mine | Clean-up | 18 | 61 (18) | 22 | 39 | 51 | 33% | 2.5 | 59 (3) | 45 (13) | 264 (2) | 67 (12) | 51 (6) |
| Mine | Fast | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Mine | Fast Hammer | 44 | 34 (44) | 24 | 10 | 48 | 16% | 2.8 | 29 (22) | 40 (14) | 33 (8) | 43 (30) | 18 (14) |
| Mine | Fragile | 3 | 131 (3) | 131 | 0 | 100 | 67% | 3.0 | 131 (3) | - | - | 392 (1) | 0 (2) |
| Mine | Hammer | 52 | 43 (52) | 24 | 19 | 30 | 15% | 3.2 | 14 (14) | 53 (35) | 58 (3) | 41 (36) | 47 (16) |
| Mine | Holder | 25 | 47 (25) | 5 | 42 | 15 | 44% | 2.9 | 29 (7) | 44 (13) | 82 (5) | 84 (12) | 12 (13) |
| Mine | Shooter | 37 | 69 (37) | 37 | 32 | 41 | 3% | 1.8 | 64 (6) | 75 (28) | 22 (3) | 67 (22) | 72 (15) |
| Mine | Support | 4 | 79 (4) | 79 | 0 | 0 | 25% | 2.0 | 0 (1) | 137 (3) | - | 25 (2) | 165 (2) |
| Mine | War machine | 52 | 30 (52) | 30 | 0 | 50 | 0% | 1.1 | 21 (13) | 31 (36) | 55 (3) | 28 (13) | 30 (39) |
| Mine | Wizard | 17 | 42 (17) | 42 | 0 | 42 | 12% | 2.4 | 25 (4) | 115 (7) | 10 (1) | 117 (6) | 18 (6) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 100 | 0% | 5.0 | - | 0 (1) | - | - | 0 (1) |
| Opponent | Chaff | 68 | 58 (68) | 23 | 35 | 55 | 40% | 2.9 | 61 (29) | 103 (11) | 32 (28) | 47 (48) | 83 (20) |
| Opponent | Character | 102 | 47 (102) | 47 | 0 | 38 | 21% | 2.3 | 54 (35) | 51 (51) | 16 (6) | 43 (52) | 58 (40) |
| Opponent | Clean-up | 11 | 48 (11) | 0 | 48 | 41 | 55% | 4.4 | 0 (4) | 54 (6) | 204 (1) | 33 (6) | 62 (5) |
| Opponent | Fast | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Fast Hammer | 60 | 48 (60) | 30 | 19 | 46 | 35% | 2.8 | 46 (30) | 41 (20) | 74 (10) | 50 (28) | 47 (32) |
| Opponent | Fragile | 3 | 0 (3) | 0 | 0 | 100 | 33% | 2.0 | - | 0 (2) | 0 (1) | 0 (2) | 0 (1) |
| Opponent | Hammer | 50 | 43 (50) | 31 | 11 | 40 | 34% | 2.7 | 2 (17) | 60 (30) | 7 (3) | 53 (30) | 27 (20) |
| Opponent | Holder | 40 | 63 (40) | 8 | 55 | 19 | 40% | 2.8 | 41 (8) | 93 (19) | 37 (11) | 78 (29) | 36 (9) |
| Opponent | Shooter | 27 | 67 (27) | 37 | 30 | 40 | 4% | 1.1 | 86 (6) | 42 (19) | 351 (2) | 96 (16) | 30 (11) |
| Opponent | Support | 4 | 0 (4) | 0 | 0 | 0 | 75% | 5.0 | - | 0 (1) | 0 (3) | 0 (2) | 0 (2) |
| Opponent | War machine | 17 | 102 (17) | 102 | 0 | 24 | 0% | 1.4 | 142 (3) | 127 (10) | 26 (4) | 190 (3) | 87 (14) |
| Opponent | Wizard | 32 | 9 (32) | 9 | 0 | 39 | 12% | 2.2 | 13 (16) | 4 (8) | 0 (2) | 14 (13) | 2 (13) |

### Charged fights: jb-h2h-mine-b54c226-p3

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 65 | 59 | 1.5 | 1.2 | 39 | 0 | +39 | 1 of 6 | 5 of 6 | +135 | +20 |
| Mine | Chaos Dwarfs | 4 | 229 | 544 | 3.5 | 1.1 | 156 | 0 | +156 | 8 of 14 | 12 of 14 | +0 | +168 |
| Mine | Dwarfen Mountain Holds | 3 | 183 | 0 | 1.0 | 1.3 | 0 | 42 | -42 | 0 of 3 | 1 of 3 | +0 | -62 |
| Mine | Empire of Man | 5 | 325 | 155 | 1.2 | 1.0 | 130 | 0 | +130 | 2 of 6 | 6 of 6 | - | +130 |
| Mine | Grand Cathay | 5 | 540 | 179 | 2.0 | 1.2 | 90 | 20 | +69 | 6 of 10 | 9 of 10 | +0 | +86 |
| Mine | High Elf Realms | 4 | 250 | 475 | 3.0 | 1.3 | 158 | 5 | +153 | 6 of 12 | 10 of 12 | +255 | +119 |
| Mine | Kingdom of Bretonnia | 1 | 38 | 1208 | 4.0 | 1.8 | 302 | 0 | +302 | 0 of 4 | 3 of 4 | +203 | +600 |
| Mine | Lizardmen | 1 | 116 | 144 | 2.0 | 1.0 | 72 | 0 | +72 | 1 of 2 | 1 of 2 | - | +72 |
| Mine | Ogre Kingdoms | 1 | 116 | 0 | 3.0 | 1.0 | 0 | 130 | -130 | 0 of 3 | 2 of 3 | - | -130 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 340 | 4.0 | 1.2 | 85 | 14 | +71 | 2 of 4 | 2 of 4 | +0 | +95 |
| Mine | Skaven | 1 | 19 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 0 of 1 | 0 of 1 | - | +0 |
| Mine | Tomb Kings of Khemri | 2 | 60 | 587 | 2.5 | 1.2 | 235 | 14 | +221 | 2 of 5 | 3 of 5 | +190 | +228 |
| Mine | Vampire Counts | 2 | 118 | 1000 | 6.0 | 1.3 | 167 | 9 | +158 | 3 of 12 | 11 of 12 | +207 | +148 |
| Mine | Warriors of Chaos | 2 | 10 | 358 | 3.0 | 1.5 | 119 | 148 | -28 | 1 of 6 | 5 of 6 | +172 | -129 |
| **Mine** | all armies | 36 | 214 | 321 | 2.4 | 1.2 | 131 | 22 | +110 | 32 of 88 | 70 of 88 | +145 | +102 |
| Opponent | Empire of Man | 1 | 618 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Grand Cathay | 3 | 485 | 184 | 2.3 | 1.4 | 79 | 0 | +79 | 3 of 7 | 6 of 7 | +234 | +17 |
| Opponent | High Elf Realms | 3 | 498 | 287 | 2.0 | 1.0 | 144 | 150 | -6 | 4 of 6 | 5 of 6 | - | -6 |
| Opponent | Kingdom of Bretonnia | 2 | 237 | 412 | 4.0 | 1.0 | 103 | 59 | +44 | 4 of 8 | 5 of 8 | - | +44 |
| Opponent | Orc & Goblin Tribes | 1 | 0 | 176 | 3.0 | 1.0 | 59 | 37 | +22 | 2 of 3 | 1 of 3 | - | +22 |
| Opponent | Skaven | 1 | 186 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 1 of 1 | 1 of 1 | - | +0 |
| Opponent | Tomb Kings of Khemri | 4 | 62 | 967 | 5.5 | 1.0 | 176 | 28 | +147 | 13 of 22 | 16 of 22 | +466 | +132 |
| Opponent | Vampire Counts | 6 | 23 | 462 | 3.5 | 1.0 | 132 | 69 | +63 | 11 of 21 | 14 of 21 | +0 | +66 |
| Opponent | Warriors of Chaos | 9 | 0 | 502 | 3.0 | 1.1 | 167 | 34 | +134 | 13 of 27 | 22 of 27 | +98 | +136 |
| Opponent | Wood Elf Realms | 6 | 108 | 200 | 2.3 | 1.4 | 86 | 94 | -8 | 6 of 14 | 11 of 14 | -66 | +15 |
| **Opponent** | all armies | 36 | 146 | 410 | 3.0 | 1.1 | 136 | 53 | +83 | 57 of 109 | 81 of 109 | +87 | +82 |

### Effective charges: jb-h2h-mine-b54c226-p3

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 6 | 0 | 0 | 0 | 2 (net +20) | 1 (net +0) | 1 (net +135) | 2 | 0% (0 of 4) |
| Mine | Chaos Dwarfs | 14 | 1 (net +465) | 0 | 2 (net +221) | 6 (net +120) | 0 | 5 (net +110) | 0 | 14% (2 of 14) |
| Mine | Dwarfen Mountain Holds | 3 | 1 (net +0) | 1 (net -65) | 0 | 1 (net -60) | 0 | 0 | 0 | 0% (0 of 3) |
| Mine | Empire of Man | 6 | 0 | 0 | 0 | 2 (net +238) | 1 (net +72) | 2 (net +52) | 1 | 0% (0 of 5) |
| Mine | Grand Cathay | 10 | 0 | 1 (net -205) | 3 (net +105) | 2 (net +0) | 0 | 4 (net +145) | 0 | 30% (3 of 10) |
| Mine | High Elf Realms | 12 | 3 (net +15) | 1 (net +875) | 1 (net +0) | 0 | 4 (net +166) | 3 (net +85) | 0 | 8% (1 of 12) |
| Mine | Kingdom of Bretonnia | 4 | 2 (net +72) | 0 | 0 | 1 (net +464) | 1 (net +600) | 0 | 0 | 0% (0 of 4) |
| Mine | Lizardmen | 2 | 0 | 0 | 1 (net +0) | 1 (net +144) | 0 | 0 | 0 | 50% (1 of 2) |
| Mine | Ogre Kingdoms | 3 | 0 | 0 | 0 | 0 | 0 | 1 (net +0) | 2 | 0% (0 of 1) |
| Mine | Orc & Goblin Tribes | 4 | 1 (net +0) | 0 | 0 | 0 | 0 | 1 (net +0) | 2 | 0% (0 of 2) |
| Mine | Skaven | 1 | 0 | 0 | 0 | 1 (net +0) | 0 | 0 | 0 | 0% (0 of 1) |
| Mine | Tomb Kings of Khemri | 5 | 1 (net +653) | 0 | 1 (net +190) | 2 (net +98) | 0 | 1 (net +66) | 0 | 20% (1 of 5) |
| Mine | Vampire Counts | 12 | 0 | 1 (net -60) | 2 (net +382) | 1 (net -50) | 2 (net +232) | 6 (net +129) | 0 | 17% (2 of 12) |
| Mine | Warriors of Chaos | 6 | 0 | 1 (net +47) | 1 (net +0) | 2 (net +70) | 0 | 2 (net -178) | 0 | 17% (1 of 6) |
| Opponent | Grand Cathay | 7 | 0 | 1 (net +0) | 1 (net +0) | 2 (net +42) | 1 (net +0) | 2 (net +234) | 0 | 14% (1 of 7) |
| Opponent | High Elf Realms | 6 | 1 (net -347) | 0 | 1 (net -400) | 1 (net +102) | 0 | 3 (net +203) | 0 | 17% (1 of 6) |
| Opponent | Kingdom of Bretonnia | 8 | 2 (net +116) | 0 | 0 | 4 (net +96) | 0 | 2 (net -130) | 0 | 0% (0 of 8) |
| Opponent | Orc & Goblin Tribes | 3 | 1 (net -55) | 0 | 0 | 0 | 0 | 0 | 2 | 0% (0 of 1) |
| Opponent | Skaven | 1 | 0 | 0 | 0 | 1 (net +0) | 0 | 0 | 0 | 0% (0 of 1) |
| Opponent | Tomb Kings of Khemri | 22 | 2 (net +353) | 1 (net +296) | 2 (net -216) | 9 (net +189) | 0 | 5 (net +167) | 3 | 11% (2 of 19) |
| Opponent | Vampire Counts | 21 | 11 (net +18) | 0 | 3 (net +238) | 4 (net +225) | 1 (net +85) | 2 (net -286) | 0 | 14% (3 of 21) |
| Opponent | Warriors of Chaos | 27 | 3 (net -57) | 1 (net +185) | 5 (net +209) | 5 (net +78) | 0 | 10 (net +168) | 3 | 21% (5 of 24) |
| Opponent | Wood Elf Realms | 14 | 0 | 0 | 0 | 2 (net -242) | 1 (net +60) | 4 (net +177) | 7 | 0% (0 of 7) |

### Charged fights, damage counted: jb-h2h-mine-b54c226-p3

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 9 | 300 | 327 | +145 | 179 | 52 | +128 | +42.5 |
| Mine | 50-54% | 5 | 212 | 224 | +118 | 252 | 89 | +163 | +77.0 |
| Mine | Effective (55-75%) | 11 | 339 | 257 | +155 | 168 | 41 | +127 | +37.5 |
| Mine | 76-89% | 21 | 257 | 179 | +99 | 115 | 9 | +107 | +41.5 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 26 | 275 | 172 | +81 | 138 | 58 | +80 | +29.2 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 9 | 537 | 123 | +200 | 233 | 6 | +227 | +42.3 |
| Mine | No odds | 7 | 365 | 162 | +11 | 109 | 91 | +19 | +5.1 |
| Mine | All fights | 88 | 312 | 197 | +110 | 155 | 42 | +112 | +36.0 |
| Opponent | Long shot (under 50%) | 20 | 212 | 209 | +28 | 121 | 91 | +30 | +14.2 |
| Opponent | 50-54% | 3 | 315 | 288 | +160 | 220 | 39 | +181 | +57.6 |
| Opponent | Effective (55-75%) | 12 | 399 | 271 | +78 | 174 | 97 | +77 | +19.3 |
| Opponent | 76-89% | 28 | 312 | 198 | +110 | 163 | 54 | +109 | +34.9 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 28 | 320 | 216 | +124 | 218 | 87 | +131 | +40.8 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 3 | 349 | 70 | +48 | 48 | 0 | +48 | +13.8 |
| Opponent | No odds | 15 | 154 | 240 | +22 | 111 | 60 | +50 | +32.6 |
| Opponent | All fights | 109 | 285 | 217 | +83 | 162 | 73 | +89 | +31.2 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| jb-h2h-mine-b54c226-p3 | move | 458 | 90 (20%) | 69 (15%) | 47 (10%) | 321 (70%) |
| jb-h2h-mine-b54c226-p3 | objective | 376 | 52 (14%) | 43 (11%) | 53 (14%) | 271 (72%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0110, L0126, L2433, L2630 |
| Charmed Shield | Opponent | L0126, L0226, L0327, L0725, L1327, L2327 |
| Clockwork Compass | Mine | L1216, L1232 |
| Elixir of Power | Mine | L1122, L1932 |
| Elixir of Power | Opponent | L0311, L1519 |
| Fistful of Laurels | Mine | L1831 |
| Horn of the Wild Hunt | Opponent | L0533, L1633, L2033, L2433, L3133 |
| Invocation of Nehek | Mine | L2433 |
| Invocation of Nehek | Opponent | L0327, L0725, L1327, L2327 |
| Opal Amulet | Mine | L1422 |
| Periapt of Soul Exchange | Mine | L2033 |
| Periapt of Soul Exchange | Opponent | L0620 |
| Ring of Doom | Mine | L0210, L0226, L1122, L1216, L1232, L1519, L1535, L3133 |
| Ring of Doom | Opponent | L0311, L0533, L0815, L0831, L1633, L1731, L1831, L2033, L2433, L3133 |
| Ring of Jet | Mine | L1013, L1030, L1122, L1216, L1232 |
| Ring of Jet | Opponent | L0110, L0210, L0311 |
| Standard of the Fell Warrior | Mine | L1327 |
| Standard of the Fell Warrior | Opponent | L0413, L1013 |
| Twice-Blessed Armour | Mine | L0709, L0725, L1013, L1030 |
| Twice-Blessed Armour | Opponent | L0110, L0210 |
| Witch Hunter's Ward | Mine | L0709, L0725, L0815, L0831 |

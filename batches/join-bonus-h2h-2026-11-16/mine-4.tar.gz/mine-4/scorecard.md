# Doctrine scorecard: jb-h2h-mine-b54c226-p4

### Scorecard: jb-h2h-mine-b54c226-p4

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0114 | 6 | 1 | Mine | no | 5 | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| L0114 | 6 | 1 | Opponent | no | 6 | 1 | 1 | 1 | 0 | 0 | 0 | 0 |
| L0130 | 4 | 1 | Mine | yes | 6 | - | 0 | 2 | 1 | 0 | 0 | 0 |
| L0130 | 4 | 1 | Opponent | no | 0 | 1 | 4 | 1 | 0 | 0 | 0 | 0 |
| L0214 | 4 | 1 | Mine | no | 0 | 2 | 2 | 2 | 0 | 0 | 0 | 30 |
| L0214 | 4 | 1 | Opponent | no | 2 | 1 | 1 | 1 | 0 | 0 | 0 | 0 |
| L0230 | 2 | 1 | Mine | - | - | 1 | 5 | 3 | 1 | 0 | 0 | 170 |
| L0230 | 2 | 1 | Opponent | - | - | 2 | 3 | 3 | 0 | 0 | 0 | 0 |
| L0315 | 3 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 590 |
| L0315 | 3 | 1 | Opponent | yes | 5 | 2 | 1 | 1 | 0 | 0 | 0 | 0 |
| L0332 | 2 | 1 | Mine | - | - | - | 1 | 0 | 1 | 0 | 0 | 360 |
| L0332 | 2 | 1 | Opponent | - | - | 2 | 1 | 5 | 1 | 0 | 0 | 0 |
| L0417 | 3 | 1 | Mine | yes | 4 | 2 | 9 | 1 | 1 | 0 | 0 | 0 |
| L0417 | 3 | 1 | Opponent | yes | 1 | 2 | 5 | 0 | 1 | 0 | 0 | 135 |
| L0434 | 2 | 1 | Mine | - | - | 2 | 2 | 0 | 0 | 0 | 0 | 0 |
| L0434 | 2 | 1 | Opponent | - | - | 1 | 3 | 1 | 0 | 0 | 0 | 0 |
| L0520 | 4 | 1 | Mine | no | 0 | 6 | 1 | 1 | 0 | 0 | 0 | 1120 |
| L0520 | 4 | 1 | Opponent | no | 1 | - | 1 | 3 | 1 | 0 | 0 | 210 |
| L0608 | 2 | 1 | Mine | - | - | - | 0 | 3 | 1 | 0 | 0 | 615 |
| L0608 | 2 | 1 | Opponent | - | - | - | 0 | 2 | 0 | 0 | 0 | 605 |
| L0624 | 6 | 1 | Mine | no | 0 | 3 | 2 | 1 | 0 | 0 | 0 | 801 |
| L0624 | 6 | 1 | Opponent | no | 2 | 3 | 2 | 1 | 1 | 0 | 0 | 0 |
| L0713 | 5 | 1 | Mine | yes | - | 1 | 4 | 2 | 0 | 0 | 0 | 420 |
| L0713 | 5 | 1 | Opponent | no | - | 4 | 3 | 0 | 2 | 0 | 0 | 317 |
| L0729 | 3 | 1 | Mine | no | 2 | 3 | 0 | 0 | 0 | 0 | 0 | 590 |
| L0729 | 3 | 1 | Opponent | no | 0 | 2 | 5 | 1 | 1 | 0 | 0 | 170 |
| L0819 | 3 | 1 | Mine | no | 0 | 3 | 1 | 0 | 0 | 0 | 0 | 715 |
| L0819 | 3 | 1 | Opponent | no | 0 | 2 | 2 | 2 | 2 | 0 | 0 | 543 |
| L0835 | 1 | 1 | Mine | no | 0 | 4 | 0 | 1 | 0 | 0 | 0 | 717 |
| L0835 | 1 | 1 | Opponent | no | 2 | - | 1 | 2 | 1 | 0 | 0 | 0 |
| L0926 | 2 | 1 | Mine | - | - | 4 | 1 | 2 | 0 | 0 | 0 | 537 |
| L0926 | 2 | 1 | Opponent | - | - | 2 | 1 | 6 | 0 | 0 | 0 | 0 |
| L1017 | 3 | 1 | Mine | no | 6 | 2 | 3 | 0 | 1 | 0 | 0 | 330 |
| L1017 | 3 | 1 | Opponent | yes | 1 | 2 | 4 | 0 | 3 | 0 | 0 | 224 |
| L1034 | 2 | 1 | Mine | - | - | 2 | 1 | 1 | 1 | 0 | 0 | 330 |
| L1034 | 2 | 1 | Opponent | - | - | 3 | 3 | 7 | 1 | 0 | 0 | 527 |
| L1126 | 4 | 1 | Mine | no | 0 | 5 | 1 | 0 | 1 | 0 | 0 | 330 |
| L1126 | 4 | 1 | Opponent | no | 7 | 2 | 6 | 3 | 1 | 0 | 0 | 0 |
| L1220 | 2 | 1 | Mine | - | - | 2 | 4 | 0 | 0 | 0 | 0 | 330 |
| L1220 | 2 | 1 | Opponent | - | - | - | 2 | 2 | 0 | 0 | 0 | 440 |
| L1314 | 6 | 1 | Mine | no | 2 | 3 | 2 | 0 | 0 | 0 | 0 | 302 |
| L1314 | 6 | 1 | Opponent | no | 5 | 2 | 4 | 0 | 1 | 0 | 0 | 123 |
| L1331 | 5 | 1 | Mine | yes | - | - | 0 | 3 | 0 | 0 | 0 | 140 |
| L1331 | 5 | 1 | Opponent | no | - | - | 0 | 4 | 1 | 0 | 0 | 170 |
| L1427 | 5 | 1 | Mine | yes | - | 3 | 1 | 2 | 0 | 0 | 0 | 177 |
| L1427 | 5 | 1 | Opponent | no | - | 2 | 1 | 2 | 1 | 0 | 0 | 0 |
| L1523 | 5 | 1 | Mine | yes | - | 2 | 4 | 1 | 1 | 0 | 0 | 0 |
| L1523 | 5 | 1 | Opponent | yes | - | 2 | 4 | 1 | 0 | 0 | 0 | 198 |
| L1621 | 1 | 1 | Mine | no | 0 | 2 | 4 | 1 | 0 | 0 | 0 | 200 |
| L1621 | 1 | 1 | Opponent | no | 1 | 3 | 2 | 2 | 1 | 0 | 0 | 565 |
| L1719 | 3 | 1 | Mine | yes | 1 | 2 | 7 | 0 | 0 | 0 | 0 | 184 |
| L1719 | 3 | 1 | Opponent | yes | 2 | 2 | 7 | 0 | 0 | 0 | 0 | 0 |
| L1819 | 1 | 1 | Mine | no | 2 | 4 | 3 | 0 | 1 | 0 | 0 | 185 |
| L1819 | 1 | 1 | Opponent | no | 4 | 2 | 5 | 0 | 0 | 0 | 0 | 0 |
| L1835 | 5 | 1 | Mine | yes | - | - | 0 | 3 | 1 | 0 | 0 | 0 |
| L1835 | 5 | 1 | Opponent | yes | - | 2 | 5 | 3 | 0 | 0 | 0 | 0 |
| L2021 | 5 | 1 | Mine | no | - | 6 | 2 | 3 | 1 | 0 | 0 | 420 |
| L2021 | 5 | 1 | Opponent | no | - | 6 | 1 | 4 | 0 | 0 | 0 | 355 |
| L2123 | 5 | 1 | Mine | yes | - | - | 3 | 3 | 0 | 0 | 0 | 355 |
| L2123 | 5 | 1 | Opponent | yes | - | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L2227 | 1 | 1 | Mine | no | 0 | 2 | 3 | 0 | 0 | 0 | 0 | 0 |
| L2227 | 1 | 1 | Opponent | yes | 1 | 1 | 4 | 1 | 0 | 0 | 0 | 0 |
| L2331 | 3 | 1 | Mine | no | 0 | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L2331 | 3 | 1 | Opponent | yes | 3 | 6 | 3 | 0 | 1 | 0 | 0 | 170 |
| L2527 | 1 | 1 | Mine | no | 0 | 3 | 3 | 1 | 0 | 0 | 0 | 0 |
| L2527 | 1 | 1 | Opponent | no | 0 | 1 | 1 | 2 | 0 | 0 | 0 | 190 |
| L2634 | 6 | 1 | Mine | no | 6 | 2 | 4 | 1 | 1 | 0 | 0 | 0 |
| L2634 | 6 | 1 | Opponent | no | 3 | 2 | 2 | 2 | 1 | 0 | 0 | 0 |
| L2930 | 2 | 1 | Mine | - | - | 5 | 4 | 1 | 0 | 0 | 0 | 0 |
| L2930 | 2 | 1 | Opponent | - | - | 6 | 0 | 3 | 0 | 0 | 0 | 0 |
| L3234 | 6 | 1 | Mine | no | 0 | 2 | 5 | 2 | 0 | 0 | 0 | 170 |
| L3234 | 6 | 1 | Opponent | no | 0 | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 32% | 1.6 | 2.8 | 2.4 | 1.2 | 0.4 | 0.0 | 0.0 | 281.1 |
| **Average** | | | Opponent | 32% | 2.2 | 2.4 | 2.7 | 1.9 | 0.6 | 0.0 | 0.0 | 137.3 |

### KPIs: jb-h2h-mine-b54c226-p4

Rules off - Opponent only: JOINS A FRIEND.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 28% (48 of 170) | 2% (3 of 177) | 15% (51 of 347) |
| Winner chose to follow up after the loser gave ground |  | 97% (60 of 62); on the table 97% | 98% (58 of 59); on the table 100% | 98% (118 of 121); on the table 98% |
| Winner chose to pursue after the loser fell back in good order |  | 100% (13 of 13); on the table 100% | 100% (18 of 18); on the table 100% | 100% (31 of 31); on the table 100% |
| Winner chose to pursue after the loser fled |  | 81% (21 of 26); on the table 81% | 78% (18 of 23); on the table 83% | 80% (39 of 49); on the table 82% |
| Winner chose to follow up or pursue (all three) |  | 93% (94 of 101); on the table 93% | 94% (94 of 100); on the table 96% | 94% (188 of 201); on the table 95% |
| Magic missiles tried each own turn | 50%+ | 29% (79 of 269) | 34% (59 of 173) | 31% (138 of 442) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 42% (79 of 189) | 48% (59 of 124) | 44% (138 of 313) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 55% (24 of 44) | 52% (34 of 65) | 53% (58 of 109) |
| Points that never fought | lower | 39% (26548 of 67942) | 37% (26585 of 71984) | 38% (53133 of 139926) |
|   infantry points that never fought | lower | 52% (8039 of 15347) | 66% (9078 of 13804) | 59% (17117 of 29151) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 55% (148 of 270) | 58% (163 of 280) | 57% (311 of 550) |
| Bound items with a magic missile used (at least once a game) |  | 91% (20 of 22); 1.8 uses a game | 89% (8 of 9); 0.8 uses a game | 90% (28 of 31); 1.3 uses a game |
| Bound items with another spell used |  | 31% (5 of 16); 0.4 uses a game | 30% (6 of 20); 0.2 uses a game | 31% (11 of 36); 0.3 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 58% (11 of 19); 0.3 uses a game | 80% (12 of 15); 0.3 uses a game | 68% (23 of 34); 0.3 uses a game |
|   their share of the points of units over 100 pts | lower | 52% (29916 of 57750) | 50% (31985 of 63347) | 51% (61901 of 121097) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.3 (25%) | 0.9 (30%) | 2.3 (27%) |
| MARCHED: its unit marched | 1.4 (27%) | 0.4 (13%) | 1.9 (22%) |
| CHARGED: its unit charged | 0.3 (5%) | 0.1 (3%) | 0.4 (4%) |
| IN COMBAT: engaged in combat | 1.3 (25%) | 0.4 (11%) | 1.7 (20%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.3 (11%) | 0.3 (4%) |
| FLEEING: fleeing | 0.0 (1%) | 0.1 (3%) | 0.1 (1%) |
| GONE: slain | 0.6 (11%) | 0.9 (29%) | 1.5 (18%) |
| OFF THE TABLE: off the table or not arrived | 0.3 (6%) | 0.0 (0%) | 0.3 (4%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.2 | 1.5 | 2.1 | 3.8 | 0.5 | 2.3 |
| not cast | 3.0 | 2.4 | 2.7 | 8.4 | 1.5 | 20.7 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.3 (6%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.2 (48%) | 0.1 (5%) | 2.3 (27%) | 0.4 (24%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.9 (22%) | 0.4 (30%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.4 (4%) | 0.1 (6%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.2 (6%) | 0.1 (6%) | 0.6 (24%) | 1.7 (20%) | 0.3 (22%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.2 (6%) | 0.1 (5%) | 0.3 (10%) | 0.3 (4%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.1 (4%) | 0.1 (2%) | 0.1 (2%) | 0.1 (1%) | 0.0 (0%) | 0.4 (2%) |
| GONE: slain | 0.6 (19%) | 0.5 (22%) | 0.3 (10%) | 1.5 (18%) | 0.2 (13%) | 3.3 (16%) |
| OFF THE TABLE: off the table or not arrived | 0.4 (12%) | 0.1 (3%) | 0.2 (6%) | 0.3 (4%) | 0.0 (2%) | 0.7 (3%) |
| STUPIDITY: Stupidity | 0.1 (3%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (2%) | 0.2 (10%) | 0.0 (0%) | 0.0 (0%) | 0.1 (4%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.5 (49%) | 0.1 (5%) | 1.1 (42%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 14.7 (71%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.6 a game | 0.7 a game | 1.1 a game |
| stood (cast and not dispelled) | 62% (31 of 50) | 71% (10 of 14) | 64% (41 of 64) |
| the unit moved after it | 84% (26 of 31) | 70% (7 of 10) | 80% (33 of 41) |
| it charged on its next turn | 10% (3 of 31) | 0% (0 of 10) | 7% (3 of 41) |
| the enemy charged it first | 23% (7 of 31) | 20% (2 of 10) | 22% (9 of 41) |
| it fought by the end of its next turn | 23% (7 of 31) | 20% (2 of 10) | 22% (9 of 41) |
| it moved out of a charge the enemy had planned (not charged first) | 19% (6 of 31) | 20% (2 of 10) | 20% (8 of 41) |
| none of these (no charge, no fight, no charge escaped) | 45% (14 of 31) | 60% (6 of 10) | 49% (20 of 41) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 65% (612 of 938) | 55% (285 of 520) | 62% (897 of 1458) |
|   cavalry | 62% (50 of 81) | 69% (80 of 116) | 66% (130 of 197) |
|   character | 47% (54 of 115) | 17% (20 of 118) | 32% (74 of 233) |
|   chariot | 50% (55 of 110) | 55% (11 of 20) | 51% (66 of 130) |
|   infantry | 62% (171 of 274) | 68% (152 of 223) | 65% (323 of 497) |
|   monster | 42% (20 of 48) | 23% (5 of 22) | 36% (25 of 70) |
|   war machine | 85% (262 of 310) | 81% (17 of 21) | 84% (279 of 331) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.1 (23%) | 1.6 (24%) | 3.7 (24%) |
| CHARGED: it charged | 0.9 (10%) | 1.6 (25%) | 2.5 (16%) |
| FLEEING: it fled or was fleeing | 0.2 (2%) | 0.1 (2%) | 0.3 (2%) |
| IN COMBAT: it fought this turn or the last | 1.0 (11%) | 0.4 (6%) | 1.4 (9%) |
| MOVED: a war machine that moved | 0.1 (1%) | 0.0 (0%) | 0.1 (0%) |
| HELD FIRE: a target, but it held its fire | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NO TARGET IN RANGE | 1.9 (21%) | 1.2 (18%) | 3.1 (20%) |
| ONLY IN COMBAT: the only targets were in combat | 0.8 (9%) | 0.4 (6%) | 1.2 (7%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.4 (16%) | 1.1 (17%) | 2.6 (16%) |
| SHELTERED: the target was sheltered | 0.3 (3%) | 0.1 (1%) | 0.3 (2%) |
| STUPIDITY | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR | 0.3 (3%) | 0.1 (2%) | 0.4 (3%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 6.0 | 1.5 | 79% | 6.3 pts | 38 pts |
| character | 2.4 | 0.7 | 79% | 7.6 pts | 18 pts |
| chariot | 1.8 | 0.8 | 70% | 12.7 pts | 23 pts |
| infantry | 13.3 | 4.8 | 73% | 9.3 pts | 124 pts |
| monster | 0.7 | 0.1 | 85% | 1.8 pts | 1 pts |
| war machine | 7.8 | 6.6 | 65% | 31.0 pts | 240 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.0 | 5.9 | 5.0 |
| Charges that made contact a game | 2.9 | 3.9 | 3.4 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.76 declared, 0.53 contact (17 units) | 0.75 declared, 0.56 contact (16 units) | 0.76 declared, 0.55 contact (33 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.67 declared, 0.50 contact (6 units) | 1.21 declared, 1.07 contact (14 units) | 1.05 declared, 0.90 contact (20 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.51 declared, 0.37 contact (251 units) | 0.63 declared, 0.40 contact (292 units) | 0.57 declared, 0.39 contact (543 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 63% (51 of 81) | 31% (5 of 16) | 67% (4 of 6) | 58% (60 of 103) |
| Character in a unit | 76% (25 of 33) | 67% (10 of 15) | 100% (1 of 1) | 73% (36 of 49) |
| Character on its own | 72% (23 of 32) | 44% (12 of 27) | 35% (27 of 77) | 46% (62 of 136) |
| Chariot | 73% (11 of 15) | 83% (10 of 12) | - | 78% (21 of 27) |
| Infantry | 54% (45 of 83) | 32% (8 of 25) | 33% (2 of 6) | 48% (55 of 114) |
| Monster | 65% (22 of 34) | 64% (9 of 14) | - | 65% (31 of 48) |
| Monstrous | 79% (11 of 14) | 57% (8 of 14) | - | 68% (19 of 28) |
| War Machines | 58% (25 of 43) | 100% (2 of 2) | - | 60% (27 of 45) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 92% (12 of 13); on the table 92% | 23% (23 of 102) | 22% | 32% (7 of 22) | 83% (5 of 6); 2.8 uses a game | 50% (1 of 2); 1.0 uses a game | 67% (4 of 6); 1.0 uses a game |
| Chaos Dwarfs | 4 | 93% (14 of 15); on the table 93% | 58% (14 of 24) | 30% | 62% (20 of 32) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
| Dwarfen Mountain Holds | 3 | 100% (1 of 1); on the table 100% | - | 84% | 63% (17 of 27) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 6 | 88% (7 of 8); on the table 88% | 56% (10 of 18) | 58% | 65% (40 of 62) | 0.0 uses a game | 100% (2 of 2); 1.2 uses a game | 80% (4 of 5); 0.7 uses a game |
| Grand Cathay | 4 | 100% (22 of 22); on the table 100% | 30% (25 of 84) | 31% | 41% (15 of 37) | 100% (9 of 9); 8.5 uses a game | 50% (1 of 2); 0.2 uses a game | 25% (1 of 4); 0.2 uses a game |
| High Elf Realms | 9 | 96% (24 of 25); on the table 96% | 31% (11 of 36) | 39% | 54% (38 of 70) | 100% (7 of 7); 3.6 uses a game | 23% (7 of 30); 1.0 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | 100% (4 of 4); on the table 100% | - | 19% | 17% (1 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Lizardmen | 3 | 88% (7 of 8); on the table 88% | 50% (3 of 6) | 25% | 67% (14 of 21) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 2 | 75% (3 of 4); on the table 75% | 50% (3 of 6) | 32% | 79% (11 of 14) | 50% (1 of 2); 0.5 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 3 | 100% (14 of 14); on the table 100% | 26% (11 of 42) | 12% | 25% (6 of 24) | 0.0 uses a game | 0.0 uses a game | 67% (2 of 3); 0.7 uses a game |
| Skaven | 6 | 100% (4 of 4); on the table 100% | 22% (9 of 41) | 42% | 69% (31 of 45) | 100% (3 of 3); 0.8 uses a game | 0.0 uses a game | 67% (4 of 6); 0.7 uses a game |
| Tomb Kings of Khemri | 4 | 93% (13 of 14); on the table 93% | 0% (0 of 6) | 33% | 45% (9 of 20) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 8 | 100% (21 of 21); on the table 100% | 36% (21 of 59) | 34% | 57% (24 of 42) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 9 | 88% (23 of 26); on the table 88% | 33% (4 of 12) | 36% | 58% (42 of 72) | 100% (2 of 2); 0.8 uses a game | 0.0 uses a game | 100% (3 of 3); 0.3 uses a game |
| Wood Elf Realms | 6 | 86% (19 of 22); on the table 95% | 67% (4 of 6) | 44% | 64% (36 of 56) | 50% (1 of 2); 0.8 uses a game | 0.0 uses a game | 75% (3 of 4); 0.5 uses a game |

Flank and rear charges a unit could have turned to face (jb-h2h-mine-b54c226-p4, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 49% (40) | 49% (33) | 49% (73) |
| ...free all their last turn and able to turn (per game) | 0.75 | 0.58 | 1.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.14 | 0.22 | 0.36 |
| ...with the charger already in that arc before they moved (per game) | 0.42 | 0.31 | 0.72 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 2.25 | 1.33 | 3.58 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 1.11 | 0.67 | 1.78 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 5.56 | 6.56 | 12.11 |

### Quality by phase: jb-h2h-mine-b54c226-p4

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.1 | 3.6 |
| Strategy | Charge objectives carried out (made contact) | 45% (63 of 140) | 38% (63 of 165) |
| Strategy | Shoot objectives carried out (shot that target) | 48% (205 of 430) | 39% (61 of 156) |
| Strategy | Close-in objectives charged next turn | 13% (19 of 151) | 14% (32 of 236) |
| Strategy | Support requests answered (helper made contact too) | 93% (14 of 15) | 37% (13 of 35) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (3 of 3) | - |
| Strategy | Hexes on a unit its side charged or shot that turn | 58% (7 of 12) | 33% (3 of 9) |
| Strategy | Joined characters whose unit fought | 42% (17 of 40) | 38% (12 of 32) |
| Strategy | Lone characters that fought | 70% (58 of 83) | 81% (68 of 84) |
| Movement | Charges halted short of contact | 0.3 | 0.2 |
| Movement | Idle units | 1.2 | 1.9 |
| Movement | Points that never moved of their own | 281.1 | 137.3 |
| Movement | Fights charged into per game | 2.8 | 3.2 |
| Movement | Charges with odds: long shots (under 50%) | 13 of 88, net +137 | 19 of 97, net +58 |
| Movement | Charges with odds: sweet spot (55-75%) | 15 of 88, net +164 | 24 of 97, net +205 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 12 of 88, net +107 | 8 of 97, net +60 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 24 of 88, net +81 | 21 of 97, net +62 |
| Shooting | Shots by shooting units (incl. breath weapons) | 10.6 | 9.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 44% (170 of 383) | 40% (129 of 325) |
| Shooting | Points destroyed by shooting units | 79.8 | 38.3 |
| Shooting | War machine shots | 7.3 | 0.5 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 52% (137 of 262) | 18% (3 of 17) |
| Shooting | Points destroyed by war machines | 127.6 | 6.4 |
| Magic | Magic missiles cast | 1.6 | 1.2 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 32% (18 of 56) | 26% (11 of 42) |
| Magic | Wounds caused by magic missiles | 3.8 | 1.3 |
| Magic | Wounds caused by other spells | 1.9 | 0.9 |
| Magic | Points destroyed by magic (all spells) | 130.3 | 17.4 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.0 / 0.4 / 1.1 / 0.2 | 1.6 / 0.6 / 0.6 / 0.1 |
| Combat | Points destroyed in combat | 327.2 | 343.6 |
| Combat | Points run down | 83.8 | 58.8 |
| Combat | Net points per charged fight, damage counted | +91 | +93 |
| Combat | Net per 100 charger points, damage counted | +33.0 | +30.1 |
| Combat | First round won (charged fights) | 79% | 65% |
| Combat | Net points per charged fight | +96 | +92 |
| Combat | Net points per supported fight / lone fight | +210 / +79 | +81 / +94 |
| Combat | Charged fights on a top-3 enemy unit | 35 of 101 | 56 of 116 |
| Game | Points lost | 599.7 | 842.9 |
| Game | VP from objectives | 596.7 | 526.9 |
| Game | Lone holders (player turns) | 1.6 | 2.2 |

- Mine won / drew / lost: 21 / 6 / 9 of 36 ended games (of 36); mean margin (Mine - Opponent) +291 VP
- The side that went first won 19 of 30 games with a winner
- Points traded per game (both sides' losses): 1443
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: jb-h2h-mine-b54c226-p4

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 0.8 | +0.0 | 0.0 | 0.0 |
| ALREADY CARRIED | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARRIVAL HUNT | - | - | - | - | 0.0 | +0.4 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.4 | +0.0 | 0.0 | 30.3 | 0.1 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | 1.0 | +7.7 | 0.0 | 33.2 | 1.0 | +11.5 | 0.0 | 16.3 |
| BEST FACING | 1.0 | +36.5 | 0.0 | 26.6 | 0.5 | +23.7 | 0.0 | 49.7 |
| BEST FIRST | 4.5 | +185.8 | 220.6 | 85.5 | 4.2 | +153.4 | 129.0 | 147.5 |
| BEST OVERALL | 0.7 | +53.3 | 0.0 | 11.9 | 0.6 | +37.7 | 0.0 | 29.4 |
| BEST PREY | 0.4 | +22.4 | 6.1 | 0.0 | 0.9 | +37.0 | 15.0 | 20.1 |
| BEST PRIZE | 0.1 | -2.6 | 0.0 | 3.9 | 0.1 | -10.4 | 6.1 | 18.0 |
| BIG CHARACTER SAFETY | 0.3 | +0.2 | 0.0 | 0.0 | 0.2 | +0.6 | 0.0 | 42.8 |
| BLOCKED CHARGE SKIPPED | 0.2 | +0.0 | 0.0 | 4.2 | 0.2 | +0.0 | 32.9 | 0.0 |
| BLOCKED WHEEL | 0.5 | +1.2 | 0.0 | 2.0 | 0.7 | +24.1 | 0.0 | 3.3 |
| BLOWS WHERE AIMED | 0.2 | -10.1 | 19.7 | 8.8 | 0.1 | -25.5 | 24.5 | 0.0 |
| BOMBING RUN | 0.0 | +0.5 | 0.0 | 0.0 | - | - | - | - |
| BOUND ASSAILMENT | 0.0 | +0.0 | 0.0 | 3.5 | 0.1 | +0.0 | 0.0 | 8.2 |
| CANNON PLAN MISSED | 0.7 | +0.0 | 152.4 | 2.6 | 0.0 | +0.0 | 1.7 | 0.0 |
| CANNON PLANNED TARGET | 5.8 | +303.1 | 614.1 | 51.4 | 0.4 | +28.6 | 18.5 | 7.4 |
| CANNON SIGHT KEPT | 1.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 1.9 |
| CARRIES OUT COUNTER | 0.1 | +0.0 | 9.7 | 0.0 | 0.1 | +0.0 | 13.9 | 0.0 |
| CARRIES OUT SET-UP | 0.1 | -0.0 | 46.5 | 0.0 | 0.2 | +0.0 | 15.1 | 0.0 |
| CAST JOB | 0.8 | +55.9 | 142.1 | 16.7 | 0.4 | +3.9 | 19.3 | 0.0 |
| CASTER AWAY FROM SCREEN | 0.3 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.2 | +9.9 | 11.8 | 8.2 | - | - | - | - |
| CASTS AFTER FRIENDS | 1.0 | +0.0 | 0.0 | 45.8 | 0.4 | +0.0 | 0.0 | 11.1 |
| CASTS FROM BEHIND | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.1 | +0.9 | 0.0 | 0.0 | - | - | - | - |
| CATCH ODDS | 0.0 | +0.8 | 0.0 | 6.2 | - | - | - | - |
| CHAFF PASSED | 0.2 | -0.3 | 0.0 | 0.0 | 0.1 | -0.3 | 0.0 | 5.6 |
| CHARGE BAND | 0.2 | +0.0 | 34.7 | 1.4 | 0.1 | +0.0 | 25.9 | 0.0 |
| CHARGE NOW FIRST | 2.6 | +0.0 | 330.8 | 92.2 | 2.4 | +0.0 | 220.5 | 42.4 |
| CHARGE NOW WEIGHED | 0.6 | -32.1 | 8.8 | 25.1 | 0.6 | -70.5 | 4.5 | 49.0 |
| CHARGER SLAIN LOST | 0.4 | -7.2 | 58.2 | 5.6 | 0.6 | -12.8 | 14.4 | 21.2 |
| CHARIOT NO STATIC JOB | 0.1 | +0.0 | 11.6 | 0.0 | - | - | - | - |
| CHARIOT WIZARD CAREFUL | 0.1 | -0.8 | 0.0 | 15.0 | 0.2 | -0.5 | 0.0 | 41.1 |
| CHEAP HELPER | - | - | - | - | 0.1 | +0.0 | 0.0 | 1.4 |
| COMBAT PIVOT | 0.5 | +0.0 | 36.5 | 27.6 | 0.4 | +0.0 | 14.8 | 42.9 |
| CONTINUE AHEAD WEIGHED | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | 1.0 | +157.2 | 20.9 | 35.5 | 0.2 | +50.7 | 11.1 | 11.1 |
| COUNTER-CHARGE COVER | 9.7 | +790.0 | 0.0 | 183.6 | 7.9 | +715.3 | 0.0 | 196.4 |
| DEFENSIVE ARMY | 0.3 | +0.0 | 96.1 | 3.1 | 0.0 | +0.0 | 3.1 | 0.0 |
| EDGE GIVE GROUND | 0.1 | +11.1 | 33.0 | 0.0 | 0.2 | +2.6 | 5.6 | 0.0 |
| ELIXIR WORTH | - | - | - | - | 0.1 | +2.3 | 0.0 | 9.7 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 2.2 | +174.0 | 0.0 | 78.6 | 1.3 | +80.9 | 0.0 | 88.6 |
| FALLBACK BY WORTH | 4.9 | +37.4 | 0.0 | 41.9 | 6.5 | +73.1 | 0.0 | 74.2 |
| FIGHT LIFT | 0.2 | +2.7 | 22.2 | 9.3 | - | - | - | - |
| FIRE AND FLEE | 0.0 | +0.1 | 0.0 | 0.0 | 0.1 | +0.7 | 0.0 | 5.9 |
| FLANK NOT WEIGHED | 5.8 | +0.0 | 0.0 | 113.3 | 6.4 | +0.0 | 0.0 | 155.2 |
| FOLLOW UP WEIGHED | 0.7 | +131.8 | 0.0 | 13.1 | 0.9 | +104.2 | 0.0 | 38.2 |
| FRIENDS SHOTS CHECKED | 0.3 | +14.2 | 0.0 | 7.9 | 0.2 | +16.1 | 0.0 | 0.0 |
| GIVES UP | 0.0 | -0.8 | 16.6 | 0.0 | 0.1 | -0.5 | 7.1 | 0.0 |
| GIVES UP ITS SCREEN | - | - | - | - | 0.0 | -0.1 | 0.0 | 0.0 |
| GROUND FLIERS | 0.1 | +1.0 | 0.0 | 0.0 | 0.1 | +1.8 | 0.0 | 3.2 |
| HELPER ALREADY ASKED | - | - | - | - | 0.1 | +0.0 | 0.0 | 0.0 |
| HELPER UNSEEN | 0.3 | +0.0 | 41.6 | 4.9 | 0.6 | +0.0 | 24.0 | 28.1 |
| HILL BY ITS CHANCE | 0.6 | -56.2 | 0.0 | 0.0 | 0.5 | -33.3 | 0.0 | 7.8 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 7.7 | -142.4 | 584.3 | 153.2 | 8.9 | -208.7 | 470.5 | 192.0 |
| HUNT ADVANCE | - | - | - | - | 0.2 | +2.5 | 3.9 | 6.4 |
| HUNT DROPPED | - | - | - | - | 0.1 | +0.0 | 0.0 | 6.2 |
| HUNT IN PAIRS | 0.4 | +10.5 | 0.0 | 5.1 | 0.4 | +30.4 | 0.0 | 4.9 |
| HUNT KEPT | - | - | - | - | 0.1 | +1.4 | 0.0 | 1.2 |
| HUNT RESULT | - | - | - | - | 0.2 | +5.3 | 3.5 | 8.8 |
| HUNT THE GUNS | - | - | - | - | 0.2 | +64.4 | 3.9 | 7.6 |
| INVITES THE FIGHT | 2.1 | +33.7 | 82.1 | 45.9 | 1.3 | +19.0 | 34.9 | 24.0 |
| JOINS A FRIEND | 2.1 | +11.2 | 124.1 | 15.2 | - | - | - | - |
| JOINT CHARGE PLAN | 0.2 | +1.9 | 46.1 | 0.0 | 0.1 | +2.7 | 6.4 | 0.0 |
| JOINT KNOWS CHALLENGE | 0.2 | -2.9 | 38.1 | 0.0 | 0.2 | -20.9 | 17.6 | 7.4 |
| KEEP FALLS | 0.1 | +0.2 | 0.0 | 0.0 | 0.1 | +1.8 | 0.0 | 3.2 |
| KEEPS ITS PREY | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +0.2 | 0.0 | 0.0 |
| KEEPS ITS TARGET | 1.4 | +41.7 | 134.8 | 32.4 | 2.2 | +65.0 | 136.6 | 37.7 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KILLS COUNT | 1.6 | +71.3 | 155.4 | 30.2 | 2.0 | +107.6 | 152.6 | 35.6 |
| KILLS COUNT NEXT TURN | 5.1 | +130.0 | 311.9 | 86.7 | 7.1 | +234.2 | 279.3 | 200.9 |
| LONE CHARACTER SAFE SPOT | 0.3 | +8.1 | 13.9 | 2.4 | 0.2 | +9.1 | 12.0 | 13.9 |
| LONE WIZARD HOLDS BACK | 0.0 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 1.8 | 5.3 |
| LONE WIZARD KEPT IN | 0.6 | +26.9 | 0.0 | 0.0 | 0.2 | +20.3 | 0.0 | 0.0 |
| LONG SHOT | 0.5 | -0.0 | 51.7 | 3.4 | 0.7 | +5.5 | 12.5 | 6.5 |
| LOST CHARGE | 2.9 | -45.1 | 240.9 | 68.5 | 1.9 | -25.8 | 32.9 | 64.9 |
| LURE BY WHAT IT DRAWS | 0.0 | -0.9 | 0.0 | 0.9 | - | - | - | - |
| MAKE SURE TOGETHER | 0.6 | +53.8 | 75.1 | 9.6 | 0.8 | +49.1 | 24.8 | 34.8 |
| MANOEUVRE | 0.4 | +8.4 | 0.0 | 1.9 | 0.1 | +1.3 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | 0.6 | +28.6 | 0.0 | 27.1 | 0.4 | +18.0 | 0.0 | 0.0 |
| MARCH ODDS | 0.3 | +18.1 | 25.4 | 21.4 | 0.2 | +17.1 | 6.8 | 26.1 |
| MARCH OVER CASTS | 0.4 | +28.1 | 0.0 | 5.5 | 0.3 | +35.7 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 4.9 | +173.2 | 0.0 | 95.9 | 5.1 | +195.2 | 0.0 | 123.2 |
| MISSILES IN THE MOVE | 4.1 | +166.6 | 0.0 | 121.8 | 2.5 | +37.6 | 0.0 | 113.6 |
| MISSILES NEXT TURN | 4.9 | +96.2 | 0.0 | 136.4 | 3.1 | +26.0 | 0.0 | 124.7 |
| MODEL FACING | 0.2 | +47.9 | 0.0 | 1.7 | - | - | - | - |
| MONSTER WIZARD ROAMS | 0.2 | +0.0 | 22.6 | 0.0 | 0.1 | +0.0 | 19.1 | 13.9 |
| MOVE AND CAST | 0.5 | +14.8 | 0.0 | 12.9 | 0.2 | +7.2 | 0.0 | 0.0 |
| MOVE SPELL IN RANGE | 0.3 | +6.3 | 0.0 | 2.4 | 0.1 | +2.1 | 0.0 | 0.0 |
| MOVE SPELL OUT OF RANGE | 0.7 | -52.0 | 0.0 | 14.9 | 0.2 | -14.2 | 6.7 | 0.0 |
| MOVE SPELL SPOT | 0.7 | +0.0 | 0.0 | 44.6 | 0.1 | +0.0 | 0.0 | 11.1 |
| MOVE TO CHARGE | 2.8 | +149.9 | 217.1 | 59.3 | 4.1 | +381.8 | 139.8 | 112.6 |
| MOVES UNITS SPELL | 0.1 | +3.3 | 0.0 | 0.0 | 0.1 | +0.6 | 0.0 | 0.0 |
| NEEDED THERE | - | - | - | - | 0.0 | +5.5 | 1.8 | 0.0 |
| NOT NEEDED | 0.4 | -12.2 | 42.1 | 5.7 | 0.2 | -8.0 | 24.5 | 0.0 |
| NOT TURNED | 5.6 | +53.3 | 0.0 | 129.4 | 6.6 | +85.7 | 0.0 | 124.7 |
| NOT WORTH A CAST | 0.6 | -0.4 | 0.0 | 0.0 | 0.3 | -0.1 | 0.0 | 0.0 |
| OFF BEST | 15.6 | -728.5 | 12.9 | 278.6 | 14.1 | -801.4 | 20.6 | 335.6 |
| OPENS A LANE | 0.0 | +0.1 | 1.0 | 0.0 | 0.1 | +0.2 | 3.8 | 0.0 |
| OPENS UP | 0.3 | +22.8 | 19.4 | 0.0 | 0.2 | +20.2 | 6.7 | 0.0 |
| OVERRUNS AWAY | 0.6 | +16.4 | 47.2 | 17.3 | 0.5 | +5.4 | 33.4 | 18.1 |
| PATHS CROSS | 2.4 | +169.2 | 0.0 | 32.9 | 2.9 | +208.5 | 0.0 | 35.7 |
| PERIAPT WORTH | 0.1 | +6.8 | 0.0 | 15.0 | 0.1 | +5.1 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.1 | -2.4 | 0.0 | 0.0 | 0.1 | -1.0 | 0.0 | 3.1 |
| PLAN RESULT | 40.5 | +1934.5 | 1914.8 | 865.3 | 38.4 | +1001.1 | 1465.2 | 1264.7 |
| PURSUES BIG PREY | 0.1 | -3.3 | 0.0 | 0.0 | 0.1 | -10.3 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE | - | - | - | - | 0.1 | +13.2 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE NEXT TURN | 0.1 | +9.6 | 0.0 | 0.0 | 0.2 | +21.0 | 0.0 | 7.2 |
| RANDOM MOVE BY FIGURES | 1.2 | +21.5 | 0.0 | 22.6 | 1.8 | +16.3 | 0.0 | 79.2 |
| RANDOM MOVER NO PROMISE | 0.5 | -25.0 | 32.1 | 4.7 | 0.2 | -8.1 | 3.3 | 4.0 |
| REDIRECT BY WHAT IT STOPS | 0.3 | -2.7 | 0.0 | 7.7 | 0.7 | -10.8 | 0.0 | 8.1 |
| REDIRECT COUNTER | 2.4 | +155.7 | 0.0 | 31.1 | 4.3 | +383.3 | 0.0 | 80.7 |
| REDIRECT WEIGHED | 0.2 | +4.9 | 0.0 | 0.0 | 0.4 | +5.1 | 18.2 | 9.7 |
| REFUSING RETIRES | 0.2 | +0.0 | 0.0 | 8.0 | 0.2 | +0.0 | 0.0 | 1.7 |
| RESERVE FALL BACK | 0.5 | +13.8 | 0.0 | 8.8 | 0.7 | +37.9 | 0.0 | 10.3 |
| RESTRAINS TO SHOOT | 0.1 | +10.0 | 0.0 | 13.9 | 0.1 | +0.6 | 0.0 | 3.4 |
| RISK BY ARC | 2.2 | +83.2 | 262.2 | 53.4 | 2.5 | +46.1 | 201.1 | 66.8 |
| SAFE SURE CHARGE | 0.0 | -0.4 | 2.1 | 0.0 | - | - | - | - |
| SAFER THAN THE JOB | 1.1 | +88.1 | 0.0 | 19.1 | 0.7 | +47.8 | 0.0 | 75.8 |
| SCOUT SPOT | 0.4 | +0.5 | 0.0 | 0.9 | 0.1 | +0.0 | 0.0 | 1.8 |
| SCOUT WAITS | 0.5 | +0.0 | 0.0 | 0.9 | 0.1 | +0.0 | 0.0 | 1.8 |
| SCREEN BY WHAT IT SAVES | 0.2 | -14.3 | 0.0 | 0.0 | 0.3 | -19.7 | 0.0 | 2.8 |
| SEARCH SPOT | 2.2 | +92.6 | 0.0 | 37.9 | 2.5 | +138.7 | 0.0 | 55.2 |
| SELF MOVE SPELL | 0.2 | +60.5 | 0.0 | 0.0 | 0.5 | +18.8 | 0.0 | 0.0 |
| SET UP TOGETHER | 0.9 | +84.5 | 112.3 | 16.0 | 1.4 | +80.9 | 35.3 | 49.9 |
| SET-UP ANY TARGET | 0.5 | +108.1 | 2.4 | 11.7 | 0.1 | +8.5 | 0.0 | 0.0 |
| SET-UP MISSED | 0.1 | +12.2 | 2.4 | 2.4 | 0.0 | +2.3 | 0.0 | 0.0 |
| SHOOTER COUNTED ONCE | - | - | - | - | 0.1 | -0.7 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.3 | +0.8 | 0.0 | 0.0 | 0.2 | +0.3 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.2 | +59.0 | 110.5 | 21.0 | 0.7 | +10.2 | 19.4 | 3.6 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| SHOT REPLANNED | 0.6 | +0.0 | 174.9 | 10.1 | 0.2 | +0.0 | 29.0 | 0.0 |
| SHOTS IN THE MOVE | 15.9 | +811.5 | 0.0 | 171.9 | 7.6 | +247.4 | 0.0 | 166.4 |
| SPELL CATCH ODDS | 0.1 | -0.9 | 0.0 | 2.4 | 0.0 | -0.3 | 0.0 | 0.0 |
| SPELL SETS UP CHARGE | 0.6 | +138.9 | 12.6 | 21.9 | 0.1 | +29.6 | 0.0 | 0.0 |
| SPELL WORTH | 1.3 | +23.4 | 141.7 | 118.5 | 2.2 | +42.2 | 125.1 | 125.1 |
| SPELLS IN THE FIGHT | 0.7 | -5.2 | 139.9 | 7.1 | 0.8 | -9.7 | 63.8 | 48.7 |
| STABLE ROLE | 12.0 | +0.0 | 460.6 | 220.5 | 11.0 | +0.0 | 283.1 | 237.9 |
| STANDS TO CAST | - | - | - | - | 0.0 | +0.3 | 0.0 | 0.0 |
| STAY WEIGHED | 0.1 | +6.8 | 0.0 | 0.0 | - | - | - | - |
| STOPS | - | - | - | - | 0.1 | +6.6 | 0.0 | 1.2 |
| STOPS SHORT OF THE FLANK | 0.5 | +22.9 | 0.0 | 0.0 | 0.5 | +20.1 | 0.0 | 4.0 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 9.9 |
| SUPPORT NARROWED | 6.2 | -60.0 | 339.9 | 93.7 | 7.2 | -51.3 | 320.3 | 131.1 |
| SUPPORTS | 4.0 | +64.9 | 105.0 | 58.0 | 5.0 | +52.6 | 203.4 | 95.9 |
| SURE CHARGE BEATS ADVANCE | 0.1 | -3.7 | 14.2 | 13.9 | 0.1 | -7.8 | 1.7 | 0.0 |
| SURE REACH TOGETHER | 0.3 | +5.7 | 0.0 | 9.6 | 0.4 | -0.6 | 17.2 | 19.7 |
| THROUGH LINE OF FIRE | 0.3 | +6.7 | 0.0 | 18.4 | 0.3 | +11.9 | 0.0 | 3.2 |
| TURN WORTH | 0.4 | -28.9 | 32.6 | 3.9 | 0.1 | -13.7 | 13.5 | 0.0 |
| TWO OR MORE ARRIVE | 0.5 | +1.9 | 97.2 | 6.3 | 0.4 | +3.0 | 12.0 | 1.8 |
| WAIT AFTER COSTS | 6.8 | -298.2 | 395.3 | 135.4 | 7.1 | -405.1 | 259.5 | 171.2 |
| WALKS TO THE FIGHT | 1.4 | +16.1 | 25.4 | 21.6 | 0.7 | +12.6 | 15.4 | 13.6 |
| WAR ENGINE CHARGES | 0.1 | +4.0 | 14.3 | 0.0 | - | - | - | - |
| WAR ENGINE JOBS | 0.7 | +0.0 | 41.3 | 12.6 | 0.1 | +0.0 | 5.8 | 8.1 |
| WEARS DOWN | 1.2 | +49.5 | 165.3 | 34.8 | 1.2 | +39.7 | 75.1 | 17.7 |
| WHO HITS BACK | 0.3 | +23.6 | 0.0 | 12.2 | 0.1 | +6.5 | 0.0 | 4.7 |
| WHOLE FIGHT | 0.3 | +6.8 | 47.3 | 0.0 | 0.3 | +6.9 | 33.4 | 4.1 |
| WHOLE FIGHT GAIN | 0.4 | +28.3 | 58.5 | 0.0 | 0.6 | +28.9 | 28.4 | 3.1 |
| WIDER SPREAD | 2.6 | -9.6 | 327.8 | 37.2 | 3.2 | -3.8 | 247.1 | 62.2 |

### Rule changes: jb-h2h-mine-b54c226-p4

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 1068 | 1068 | 1068 | 29.67 | -55077 | -51.6 |
| BEST FIRST | 315 | 315 | 315 | 8.75 | +12209 | +38.8 |
| PATHS CROSS | 190 | 190 | 190 | 5.28 | +13599 | +71.6 |
| SEARCH SPOT | 171 | 171 | 166 | 4.61 | +8391 | +50.6 |
| COUNTER-CHARGE COVER | 633 | 333 | 154 | 4.28 | +10950 | +71.1 |
| MOVE TO CHARGE | 248 | 248 | 135 | 3.75 | +7926 | +58.7 |
| FACES THE THREAT | 129 | 129 | 129 | 3.58 | +9176 | +71.1 |
| KILLS COUNT NEXT TURN | 438 | 438 | 115 | 3.19 | +2436 | +21.2 |
| SUPPORTS | 323 | 323 | 115 | 3.19 | +1327 | +11.5 |
| SHOTS IN THE MOVE | 844 | 574 | 81 | 2.25 | +3252 | +40.1 |
| FALLBACK BY WORTH | 410 | 410 | 80 | 2.22 | +3980 | +49.7 |
| SAFER THAN THE JOB | 64 | 64 | 64 | 1.78 | +4894 | +76.5 |
| WAIT AFTER COSTS | 500 | 500 | 64 | 1.78 | +1186 | +18.5 |
| FOLLOW UP WEIGHED | 60 | 60 | 60 | 1.67 | +8495 | +141.6 |
| RANDOM MOVE BY FIGURES | 109 | 109 | 58 | 1.61 | +1363 | +23.5 |
| ADVANCE LANE KEPT | 55 | 55 | 55 | 1.53 | +0 | +0.0 |
| ARTILLERY RE-ROLL WEIGHED | 55 | 55 | 55 | 1.53 | +0 | +0.0 |
| BEST FACING | 54 | 54 | 54 | 1.50 | +2165 | +40.1 |
| REDIRECT COUNTER | 239 | 144 | 54 | 1.50 | +5458 | +101.1 |
| MAX FOR POSITIONING | 360 | 194 | 50 | 1.39 | +635 | +12.7 |
| BEST OVERALL | 49 | 49 | 49 | 1.36 | +3276 | +66.8 |
| BLOCKED WHEEL | 45 | 45 | 45 | 1.25 | +910 | +20.2 |
| CHARGE NOW FIRST | 179 | 179 | 45 | 1.25 | -1909 | -42.4 |
| CHARGE NOW WEIGHED | 45 | 45 | 45 | 1.25 | +2326 | +51.7 |
| WALKS TO THE FIGHT | 76 | 76 | 44 | 1.22 | +324 | +7.4 |
| RESERVE FALL BACK | 43 | 43 | 43 | 1.19 | +1864 | +43.3 |
| CANNON SIGHT KEPT | 42 | 42 | 42 | 1.17 | +0 | +0.0 |
| SET UP TOGETHER | 83 | 72 | 37 | 1.03 | +1757 | +47.5 |
| HOLDS AMBUSHERS | 35 | 35 | 35 | 0.97 | +0 | +0.0 |
| KILLS COUNT | 128 | 127 | 35 | 0.97 | +1659 | +47.4 |
| STOPS SHORT OF THE FLANK | 35 | 35 | 35 | 0.97 | +1548 | +44.2 |
| MARCH CHECK | 36 | 36 | 33 | 0.92 | +1707 | +51.7 |
| MISSILES IN THE MOVE | 237 | 160 | 33 | 0.92 | +1337 | +40.5 |
| COMBAT PIVOT | 32 | 32 | 32 | 0.89 | +0 | +0.0 |
| SHOT REPLANNED | 31 | 31 | 31 | 0.86 | +0 | +0.0 |
| LONE WIZARD KEPT IN | 28 | 28 | 28 | 0.78 | +1699 | +60.7 |
| SHOOTS FROM THE BEST SPOT | 68 | 68 | 27 | 0.75 | +760 | +28.2 |
| MOVE AND CAST | 26 | 26 | 26 | 0.72 | +792 | +30.5 |
| HONEST WORTH | 596 | 591 | 24 | 0.67 | +274 | +11.4 |
| INVITES THE FIGHT | 123 | 123 | 24 | 0.67 | +265 | +11.0 |
| KEEPS ITS TARGET | 128 | 128 | 24 | 0.67 | +442 | +18.4 |
| CAST JOB | 43 | 43 | 23 | 0.64 | +983 | +42.7 |
| REDIRECT WEIGHED | 23 | 23 | 23 | 0.64 | +885 | +38.5 |
| RISK BY ARC | 171 | 164 | 23 | 0.64 | +554 | +24.1 |
| THROUGH LINE OF FIRE | 22 | 22 | 22 | 0.61 | +667 | +30.3 |
| SCOUT WAITS | 21 | 21 | 21 | 0.58 | +0 | +0.0 |
| MARCH ODDS | 20 | 20 | 20 | 0.56 | +121 | +6.1 |
| BIG CHARACTER SAFETY | 19 | 19 | 19 | 0.53 | +28 | +1.5 |
| CANNON PLANNED TARGET | 226 | 226 | 19 | 0.53 | -128 | -6.8 |
| MAKE SURE TOGETHER | 49 | 38 | 19 | 0.53 | +920 | +48.4 |
| FRIENDS SHOTS CHECKED | 18 | 18 | 18 | 0.50 | +1089 | +60.5 |
| SHOOTERS IN TWO RANKS | 18 | 18 | 18 | 0.50 | +41 | +2.3 |
| CASTER AWAY FROM SCREEN | 17 | 17 | 17 | 0.47 | +0 | +0.0 |
| MANOEUVRE | 18 | 18 | 17 | 0.47 | +347 | +20.4 |
| WHOLE FIGHT GAIN | 36 | 32 | 17 | 0.47 | +579 | +34.0 |
| STUCK PIVOT | 16 | 16 | 16 | 0.44 | +0 | +0.0 |
| BLOCKED CHARGE SKIPPED | 15 | 15 | 15 | 0.42 | +0 | +0.0 |
| WHO HITS BACK | 15 | 15 | 15 | 0.42 | +683 | +45.5 |
| BEST PREY | 47 | 47 | 13 | 0.36 | +510 | +39.2 |
| CHARGE BAND | 12 | 12 | 12 | 0.33 | +0 | +0.0 |
| OPENS UP | 19 | 19 | 12 | 0.33 | +471 | +39.3 |
| CHAFF PASSED | 11 | 11 | 11 | 0.31 | -20 | -1.9 |
| RAIDS THE BAGGAGE NEXT TURN | 12 | 12 | 10 | 0.28 | +459 | +45.9 |
| CASTS FROM BEHIND | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| SHORT GUN FORWARD | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| WEARS DOWN | 87 | 82 | 9 | 0.25 | +270 | +30.1 |
| BEST PRIZE | 8 | 8 | 8 | 0.22 | -471 | -58.9 |
| SURE CHARGE BEATS ADVANCE | 8 | 8 | 8 | 0.22 | -416 | -52.1 |
| WAR ENGINE JOBS | 30 | 30 | 8 | 0.22 | -106 | -13.2 |
| HUNT IN PAIRS | 30 | 16 | 7 | 0.19 | +271 | +38.7 |
| MOVES UNITS SPELL | 7 | 7 | 7 | 0.19 | +138 | +19.7 |
| SUPPORT NARROWED | 484 | 484 | 7 | 0.19 | -97 | -13.9 |
| BACKUP TARGETS | 74 | 34 | 6 | 0.17 | +13 | +2.1 |
| MISSILES NEXT TURN | 287 | 180 | 6 | 0.17 | +54 | +9.1 |
| MODEL FACING | 6 | 6 | 6 | 0.17 | +1724 | +287.3 |
| OVERRUNS AWAY | 40 | 40 | 6 | 0.17 | +226 | +37.7 |
| PIVOT GUARDS FLANK | 6 | 6 | 6 | 0.17 | -122 | -20.3 |
| SURE REACH TOGETHER | 26 | 21 | 6 | 0.17 | +44 | +7.3 |
| LOST CHARGE | 173 | 173 | 5 | 0.14 | +43 | +8.6 |
| PURSUES BIG PREY | 5 | 5 | 5 | 0.14 | -489 | -97.8 |
| RESTRAINS TO SHOOT | 5 | 5 | 5 | 0.14 | +381 | +76.3 |
| JOINS A FRIEND | 75 | 75 | 4 | 0.11 | +6 | +1.4 |
| KEEP FALLS | 4 | 4 | 4 | 0.11 | +380 | +95.0 |
| PERIAPT WORTH | 4 | 4 | 4 | 0.11 | +428 | +107.1 |
| REFUSING RETIRES | 13 | 13 | 4 | 0.11 | -1 | -0.2 |
| BOUND ASSAILMENT | 3 | 3 | 3 | 0.08 | +0 | +0.2 |
| CASTING BLOCK | 7 | 7 | 3 | 0.08 | +155 | +51.7 |
| EDGE GIVE GROUND | 11 | 11 | 3 | 0.08 | +181 | +60.5 |
| FIRE AND FLEE | 3 | 3 | 3 | 0.08 | +29 | +9.6 |
| LONE WIZARD HOLDS BACK | 10 | 10 | 3 | 0.08 | -223 | -74.3 |
| LONG SHOT | 41 | 40 | 3 | 0.08 | +27 | +8.9 |
| STAY WEIGHED | 3 | 3 | 3 | 0.08 | +245 | +81.6 |
| WIDER SPREAD | 209 | 201 | 3 | 0.08 | +8 | +2.5 |
| CHARGER SLAIN LOST | 34 | 32 | 2 | 0.06 | +57 | +28.3 |
| ELIXIR WORTH | 2 | 2 | 2 | 0.06 | +84 | +42.1 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| RAIDS THE BAGGAGE | 2 | 2 | 2 | 0.06 | +364 | +182.0 |
| SPELLS IN THE FIGHT | 54 | 51 | 2 | 0.06 | +22 | +10.8 |
| STOPS | 5 | 5 | 2 | 0.06 | +77 | +38.4 |
| WHOLE FIGHT | 22 | 22 | 2 | 0.06 | +43 | +21.6 |
| BLOWS WHERE AIMED | 11 | 10 | 1 | 0.03 | +93 | +92.7 |
| BOMBING RUN | 1 | 1 | 1 | 0.03 | +18 | +18.3 |
| CARRIES OUT SET-UP | 11 | 11 | 1 | 0.03 | -2 | -1.6 |
| CATCH ODDS | 1 | 1 | 1 | 0.03 | -6 | -6.2 |
| CHARIOT NO STATIC JOB | 4 | 4 | 1 | 0.03 | -71 | -71.1 |
| CONTINUE AHEAD WEIGHED | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| DEFENSIVE ARMY | 12 | 12 | 1 | 0.03 | -3 | -2.8 |
| HILL BY ITS CHANCE | 38 | 38 | 1 | 0.03 | +12 | +12.4 |
| JOINT CHARGE PLAN | 11 | 11 | 1 | 0.03 | +3 | +2.6 |
| MOVE SPELL IN RANGE | 12 | 5 | 1 | 0.03 | +67 | +66.9 |
| NEEDED THERE | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| REDIRECT BY WHAT IT STOPS | 37 | 37 | 1 | 0.03 | +6 | +5.6 |
| SAFE SURE CHARGE | 1 | 1 | 1 | 0.03 | -50 | -50.5 |
| STANDS TO CAST | 1 | 1 | 1 | 0.03 | -2 | -2.5 |
| WAR ENGINE CHARGES | 2 | 2 | 1 | 0.03 | +28 | +27.7 |
| ALREADY CARRIED | 1 | not checked | - | - | - | - |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 26 | 26 | 0 | 0.00 | - | - |
| CARRIES OUT COUNTER | 4 | 4 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 49 | trace | - | - | - | - |
| CATCH FLIERS | 2 | not checked | - | - | - | - |
| CHARIOT WIZARD CAREFUL | 10 | 10 | 0 | 0.00 | - | - |
| CHEAP HELPER | 3 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 45 | not checked | - | - | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT LIFT | 6 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 437 | not checked | - | - | - | - |
| GIVES UP | 3 | 3 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 1 | 1 | 0 | 0.00 | - | - |
| GROUND FLIERS | 4 | not checked | - | - | - | - |
| HELPER ALREADY ASKED | 2 | not checked | - | - | - | - |
| HELPER UNSEEN | 33 | 29 | 0 | 0.00 | - | - |
| HUNT ADVANCE | 6 | 6 | 0 | 0.00 | - | - |
| HUNT DROPPED | 5 | trace | - | - | - | - |
| HUNT KEPT | 4 | trace | - | - | - | - |
| HUNT RESULT | 8 | trace | - | - | - | - |
| HUNT THE GUNS | 8 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 16 | 10 | 0 | 0.00 | - | - |
| KEEPS ITS PREY | 3 | 3 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 18 | not checked | - | - | - | - |
| LURE BY WHAT IT DRAWS | 1 | 1 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 4 | trace | - | - | - | - |
| MARCH OVER CASTS | 25 | 25 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 14 | 14 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 32 | trace | - | - | - | - |
| MOVE SPELL SPOT | 30 | not checked | - | - | - | - |
| NOT NEEDED | 22 | 22 | 0 | 0.00 | - | - |
| NOT TURNED | 436 | 436 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 33 | not checked | - | - | - | - |
| OPENS A LANE | 3 | not checked | - | - | - | - |
| PLAN RESULT | 2838 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 26 | 26 | 0 | 0.00 | - | - |
| SCOUT SPOT | 19 | 19 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 19 | 19 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 24 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 21 | not checked | - | - | - | - |
| SET-UP MISSED | 4 | trace | - | - | - | - |
| SHOOTER COUNTED ONCE | 2 | 2 | 0 | 0.00 | - | - |
| SPELL CATCH ODDS | 3 | not checked | - | - | - | - |
| SPELL SETS UP CHARGE | 25 | not checked | - | - | - | - |
| SPELL WORTH | 126 | not checked | - | - | - | - |
| STABLE ROLE | 827 | 825 | 0 | 0.00 | - | - |
| TURN WORTH | 19 | 19 | 0 | 0.00 | - | - |
| TWO OR MORE ARRIVE | 35 | 32 | 0 | 0.00 | - | - |

### Off best figure: jb-h2h-mine-b54c226-p4

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 13.89 | 12.08 | 52.4 |
| FALLBACK | gate | 0.58 | 0.92 | 62.8 |
| CHARGE NOW FIRST | rule | 0.50 | 0.69 | 44.4 |
| TURN GATE | gate | 0.50 | 0.67 | 32.9 |
| AFTERMATH BAND | gate | 0.25 | 0.08 | 2.1 |
| PATHS CROSS | rule | 0.17 | 0.14 | 29.5 |
| BIG CHARACTER SAFETY | rule | 0.14 | 0.11 | 6.7 |
| SUPPORT REQUEST | gate | 0.06 | 0.19 | 60.7 |
| BEST PRIZE | rule | 0.08 | 0.14 | 58.9 |
| SURE CHARGE BEATS ADVANCE | rule | 0.11 | 0.11 | 52.1 |
| WAR ENGINE JOBS | rule | 0.22 | - | 13.2 |
| CANNON PLANNED TARGET | rule | 0.19 | - | 29.9 |
| CHARGE NOW WEIGHED | rule | 0.08 | 0.08 | 80.8 |
| LONE CHARACTER SAFE SPOT | gate | 0.11 | 0.06 | 55.6 |
| PIVOT GUARDS FLANK | rule | 0.06 | 0.11 | 20.3 |
| STOPS SHORT OF THE FLANK | rule | 0.08 | 0.08 | 8.8 |
| SUPPORT NARROWED | rule | 0.06 | 0.11 | 16.2 |
| CHAFF PASSED | rule | 0.08 | 0.06 | 4.0 |
| PURSUES BIG PREY | rule | 0.08 | 0.06 | 97.8 |
| BLOCKED WHEEL | rule | 0.03 | 0.08 | 34.2 |
| NO REASON | gate | 0.11 | - | 35.9 |
| FIGHT ORDER BAND | gate | 0.06 | 0.03 | 1.2 |
| LONE WIZARD HOLDS BACK | rule | - | 0.08 | 74.3 |
| REDIRECT WEIGHED | rule | 0.03 | 0.06 | 39.3 |
| SAFER THAN THE JOB | rule | 0.06 | 0.03 | 2.5 |
| MARCH ODDS | rule | - | 0.06 | 82.8 |
| RULE SWITCHED OFF | gate | - | 0.06 | 11.5 |
| THROUGH LINE OF FIRE | rule | 0.03 | 0.03 | 5.8 |
| AFTERMATH NEEDS NEXT CHARGE | gate | - | 0.03 | 193.2 |
| CARRIES OUT SET-UP | rule | 0.03 | - | 1.6 |
| CATCH ODDS | rule | 0.03 | - | 6.2 |
| CHARIOT NO STATIC JOB | rule | 0.03 | - | 71.1 |
| DEFENSIVE ARMY | rule | 0.03 | - | 2.8 |
| FALLBACK BY WORTH | rule | 0.03 | - | 20.4 |
| FOLLOW UP WEIGHED | rule | - | 0.03 | 3.4 |
| FRIENDS SHOTS CHECKED | rule | 0.03 | - | 2.4 |
| SAFE SURE CHARGE | rule | 0.03 | - | 50.5 |
| STANDS TO CAST | rule | - | 0.03 | 2.5 |

### Plans: jb-h2h-mine-b54c226-p4

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 12.8 | 15% | 401 | 372 | 93% |
| Mine | charge | 3.3 | 65% | 231 | 364 | 158% |
| Mine | close in | 4.1 | 27% | 218 | 174 | 80% |
| Mine | hold | 4.9 | 29% | 311 | 0 | 0% |
| Mine | join | 0.7 | 100% | 12 | 0 | 0% |
| Mine | shoot | 10.2 | 64% | 502 | 1024 | 204% |
| Mine | support | 4.4 | 92% | 45 | 0 | 0% |
| Opponent | advance | 13.2 | 12% | 322 | 285 | 89% |
| Opponent | charge | 4.2 | 47% | 315 | 376 | 120% |
| Opponent | close in | 6.4 | 18% | 413 | 167 | 41% |
| Opponent | hold | 4.4 | 28% | 321 | 0 | 0% |
| Opponent | join | 0.6 | 90% | 23 | 0 | 0% |
| Opponent | shoot | 3.7 | 63% | 71 | 178 | 250% |
| Opponent | support | 5.7 | 88% | 46 | 0 | 0% |

### Packages: hunt the guns, jb-h2h-mine-b54c226-p4

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 6 |
| Opponent | 0.2 | 8 | 0 | 12% | 12% | 0% | 2.0 | 290 | 24 | 12% | 140 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 77 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 67 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| High Elf Realms | 0.3 | 3 | 0 | 0% | 33% | 0% | 2.0 | 179 | 64 | 33% | 98 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 283 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 225 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 136 |
| Tomb Kings of Khemri | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Vampire Counts | 0.5 | 4 | 0 | 25% | 0% | 0% | - | 323 | 0 | 0% | 70 |
| Warriors of Chaos | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 55 |
| Wood Elf Realms | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 490 | 0 | 0% | 60 |

### Battle groups: jb-h2h-mine-b54c226-p4

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 9.7 | 21% | 53% | 8% | 17% | 29% | 7% | 7% | 56% | 0% |
| Mine | REDIRECT COUNTER | 2.4 | 28% | 71% | 8% | 100% | 32% | 0% | 0% | 68% | 0% |
| Opponent | COUNTER-CHARGE COVER | 7.9 | 14% | 78% | 32% | 31% | 39% | 11% | 14% | 36% | 0% |
| Opponent | REDIRECT COUNTER | 4.3 | 28% | 74% | 12% | 20% | 32% | 0% | 11% | 53% | 5% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: jb-h2h-mine-b54c226-p4

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 4 | 0 (4) | 0 | 0 | 79 | 0% | 2.5 | - | 0 (4) | - | 0 (1) | 0 (3) |
| Mine | Chaff | 34 | 12 (34) | 4 | 7 | 68 | 29% | 2.6 | 14 (14) | 0 (7) | 15 (13) | 9 (22) | 16 (12) |
| Mine | Character | 106 | 63 (106) | 63 | 0 | 31 | 18% | 2.1 | 48 (29) | 75 (57) | 111 (6) | 43 (46) | 90 (46) |
| Mine | Clean-up | 22 | 68 (22) | 35 | 33 | 29 | 32% | 3.1 | 0 (2) | 55 (16) | 138 (4) | 71 (10) | 66 (12) |
| Mine | Early | 1 | 0 (1) | 0 | 0 | 0 | 0% | 5.0 | - | 0 (1) | - | - | 0 (1) |
| Mine | Fast | 4 | 0 (4) | 0 | 0 | 73 | 25% | 3.0 | 0 (2) | 0 (2) | - | 0 (3) | 0 (1) |
| Mine | Fast Hammer | 41 | 62 (41) | 32 | 30 | 38 | 15% | 2.8 | 38 (27) | 155 (9) | 22 (5) | 89 (25) | 22 (16) |
| Mine | Fragile | 4 | 0 (4) | 0 | 0 | 73 | 25% | 3.0 | 0 (1) | 0 (2) | - | 0 (1) | 0 (2) |
| Mine | Hammer | 65 | 38 (65) | 24 | 15 | 41 | 22% | 2.4 | 52 (13) | 37 (45) | 20 (7) | 47 (40) | 27 (25) |
| Mine | Holder | 31 | 96 (31) | 17 | 79 | 11 | 29% | 3.3 | 74 (8) | 143 (17) | 0 (6) | 124 (20) | 60 (11) |
| Mine | Shooter | 34 | 68 (34) | 41 | 27 | 31 | 3% | 1.6 | 55 (8) | 79 (21) | 45 (5) | 77 (25) | 39 (9) |
| Mine | Support | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Mine | War machine | 56 | 74 (56) | 74 | 0 | 25 | 2% | 1.3 | 64 (16) | 78 (30) | 82 (10) | 100 (9) | 69 (47) |
| Mine | Wizard | 17 | 13 (17) | 13 | 0 | 50 | 0% | 2.2 | 0 (5) | 25 (7) | 0 (1) | 0 (7) | 29 (6) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 100 | 0% | 5.0 | - | 0 (1) | - | - | 0 (1) |
| Opponent | Chaff | 75 | 33 (75) | 15 | 18 | 55 | 44% | 2.6 | 58 (31) | 28 (17) | 11 (27) | 35 (56) | 27 (19) |
| Opponent | Character | 97 | 47 (97) | 47 | 0 | 43 | 25% | 2.3 | 63 (45) | 36 (39) | 17 (7) | 51 (52) | 44 (39) |
| Opponent | Clean-up | 11 | 65 (11) | 3 | 61 | 34 | 55% | 2.0 | 0 (3) | 79 (6) | 58 (2) | 14 (6) | 94 (5) |
| Opponent | Fast | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Fast Hammer | 60 | 50 (60) | 32 | 18 | 41 | 28% | 2.8 | 33 (26) | 60 (25) | 91 (9) | 37 (39) | 73 (21) |
| Opponent | Fragile | 17 | 27 (17) | 27 | 0 | 54 | 12% | 2.4 | 82 (5) | 0 (8) | 25 (4) | 8 (14) | 113 (3) |
| Opponent | Hammer | 65 | 29 (65) | 16 | 13 | 52 | 28% | 3.3 | 7 (20) | 39 (38) | 9 (7) | 32 (41) | 25 (24) |
| Opponent | Holder | 29 | 23 (29) | 0 | 23 | 37 | 45% | 3.9 | 4 (14) | 39 (11) | 29 (4) | 36 (15) | 9 (14) |
| Opponent | Shooter | 33 | 60 (33) | 21 | 39 | 37 | 3% | 1.3 | 56 (9) | 61 (21) | 64 (3) | 41 (18) | 81 (15) |
| Opponent | Support | 6 | 0 (6) | 0 | 0 | 67 | 83% | 6.0 | 0 (1) | 0 (2) | - | 0 (1) | 0 (2) |
| Opponent | War machine | 6 | 35 (6) | 35 | 0 | 61 | 0% | 1.2 | 60 (3) | 0 (3) | - | 60 (3) | 0 (3) |
| Opponent | Wizard | 19 | 14 (19) | 14 | 0 | 42 | 0% | 2.5 | 9 (10) | 15 (3) | 27 (4) | 19 (12) | 0 (5) |

### Charged fights: jb-h2h-mine-b54c226-p4

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 262 | 334 | 2.2 | 1.3 | 149 | 49 | +100 | 1 of 9 | 9 of 9 | +91 | +104 |
| Mine | Chaos Dwarfs | 4 | 29 | 404 | 2.8 | 1.2 | 147 | 0 | +147 | 5 of 11 | 10 of 11 | +344 | +103 |
| Mine | Dwarfen Mountain Holds | 3 | 651 | 0 | 0.3 | 1.0 | 0 | 60 | -60 | 0 of 1 | 0 of 1 | - | -60 |
| Mine | Empire of Man | 5 | 652 | 375 | 2.0 | 1.3 | 187 | 95 | +92 | 7 of 10 | 7 of 10 | +248 | +54 |
| Mine | Grand Cathay | 4 | 870 | 137 | 2.5 | 1.1 | 55 | 20 | +34 | 3 of 10 | 10 of 10 | +242 | +11 |
| Mine | High Elf Realms | 4 | 395 | 174 | 2.5 | 1.0 | 70 | 0 | +70 | 5 of 10 | 6 of 10 | - | +70 |
| Mine | Kingdom of Bretonnia | 1 | 210 | 1176 | 7.0 | 1.1 | 168 | 0 | +168 | 3 of 7 | 7 of 7 | +92 | +181 |
| Mine | Lizardmen | 1 | 115 | 996 | 6.0 | 1.0 | 166 | 114 | +52 | 4 of 6 | 4 of 6 | - | +52 |
| Mine | Ogre Kingdoms | 2 | 55 | 128 | 2.0 | 1.0 | 64 | 88 | -24 | 2 of 4 | 2 of 4 | - | -24 |
| Mine | Skaven | 2 | 32 | 33 | 1.5 | 1.0 | 22 | 0 | +22 | 0 of 3 | 3 of 3 | - | +22 |
| Mine | Tomb Kings of Khemri | 2 | 0 | 1004 | 4.0 | 1.4 | 251 | 0 | +251 | 2 of 8 | 8 of 8 | +295 | +224 |
| Mine | Vampire Counts | 2 | 108 | 787 | 5.5 | 1.1 | 143 | 4 | +139 | 2 of 11 | 8 of 11 | +54 | +148 |
| Mine | Warriors of Chaos | 2 | 0 | 126 | 5.5 | 1.0 | 23 | 0 | +23 | 1 of 11 | 6 of 11 | - | +23 |
| **Mine** | all armies | 36 | 338 | 344 | 2.8 | 1.1 | 123 | 27 | +96 | 35 of 101 | 80 of 101 | +210 | +79 |
| Opponent | Empire of Man | 1 | 455 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | High Elf Realms | 5 | 56 | 313 | 3.4 | 1.2 | 92 | 43 | +50 | 9 of 17 | 9 of 17 | +40 | +52 |
| Opponent | Lizardmen | 2 | 81 | 786 | 4.0 | 1.1 | 196 | 23 | +173 | 5 of 8 | 6 of 8 | -185 | +225 |
| Opponent | Orc & Goblin Tribes | 3 | 0 | 386 | 3.3 | 1.0 | 116 | 0 | +116 | 3 of 10 | 8 of 10 | - | +116 |
| Opponent | Skaven | 4 | 52 | 16 | 2.0 | 1.0 | 8 | 74 | -66 | 3 of 8 | 3 of 8 | - | -66 |
| Opponent | Tomb Kings of Khemri | 2 | 70 | 775 | 3.5 | 1.1 | 221 | 10 | +211 | 3 of 7 | 6 of 7 | +572 | +151 |
| Opponent | Vampire Counts | 6 | 51 | 326 | 4.0 | 1.2 | 82 | 32 | +50 | 14 of 24 | 15 of 24 | -13 | +62 |
| Opponent | Warriors of Chaos | 7 | 27 | 443 | 3.1 | 1.1 | 141 | 28 | +113 | 12 of 22 | 14 of 22 | +188 | +106 |
| Opponent | Wood Elf Realms | 6 | 82 | 467 | 3.3 | 1.2 | 140 | 6 | +134 | 7 of 20 | 14 of 20 | +97 | +143 |
| **Opponent** | all armies | 36 | 62 | 383 | 3.2 | 1.1 | 119 | 26 | +92 | 56 of 116 | 75 of 116 | +81 | +94 |

### Effective charges: jb-h2h-mine-b54c226-p4

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 9 | 1 (net -52) | 0 | 2 (net +62) | 3 (net +132) | 0 | 2 (net +167) | 1 | 25% (2 of 8) |
| Mine | Chaos Dwarfs | 11 | 1 (net +615) | 0 | 0 | 2 (net +358) | 1 (net +107) | 3 (net +58) | 4 | 0% (0 of 7) |
| Mine | Dwarfen Mountain Holds | 1 | 0 | 0 | 0 | 1 (net -60) | 0 | 0 | 0 | 0% (0 of 1) |
| Mine | Empire of Man | 10 | 3 (net +273) | 0 | 2 (net +186) | 2 (net -195) | 1 (net +122) | 2 (net +0) | 0 | 20% (2 of 10) |
| Mine | Grand Cathay | 10 | 0 | 0 | 2 (net -102) | 4 (net +62) | 1 (net +56) | 3 (net +81) | 0 | 20% (2 of 10) |
| Mine | High Elf Realms | 10 | 1 (net +0) | 0 | 2 (net +286) | 3 (net +0) | 1 (net +126) | 3 (net +0) | 0 | 20% (2 of 10) |
| Mine | Kingdom of Bretonnia | 7 | 0 | 0 | 0 | 2 (net +184) | 3 (net +90) | 2 (net +270) | 0 | 0% (0 of 7) |
| Mine | Lizardmen | 6 | 2 (net -172) | 0 | 0 | 2 (net +200) | 0 | 1 (net +255) | 1 | 0% (0 of 5) |
| Mine | Ogre Kingdoms | 4 | 0 | 0 | 0 | 2 (net -32) | 0 | 0 | 2 | 0% (0 of 2) |
| Mine | Skaven | 3 | 0 | 0 | 0 | 0 | 0 | 3 (net +22) | 0 | 0% (0 of 3) |
| Mine | Tomb Kings of Khemri | 8 | 1 (net +783) | 0 | 1 (net +492) | 1 (net +75) | 2 (net +185) | 3 (net +96) | 0 | 12% (1 of 8) |
| Mine | Vampire Counts | 11 | 1 (net -40) | 1 (net +115) | 3 (net +366) | 1 (net +0) | 2 (net +64) | 2 (net +22) | 1 | 30% (3 of 10) |
| Mine | Warriors of Chaos | 11 | 3 (net +0) | 0 | 3 (net +0) | 0 | 1 (net +109) | 0 | 4 | 43% (3 of 7) |
| Opponent | High Elf Realms | 17 | 4 (net -72) | 0 | 2 (net +91) | 3 (net +144) | 1 (net +0) | 4 (net +42) | 3 | 14% (2 of 14) |
| Opponent | Lizardmen | 8 | 2 (net -92) | 0 | 3 (net +221) | 1 (net +330) | 0 | 1 (net +580) | 1 | 43% (3 of 7) |
| Opponent | Orc & Goblin Tribes | 10 | 1 (net +297) | 0 | 0 | 0 | 0 | 1 (net +0) | 8 | 0% (0 of 2) |
| Opponent | Skaven | 8 | 2 (net -18) | 1 (net +0) | 3 (net +0) | 1 (net -560) | 0 | 1 (net +65) | 0 | 38% (3 of 8) |
| Opponent | Tomb Kings of Khemri | 7 | 0 | 0 | 3 (net +311) | 2 (net +138) | 0 | 1 (net +145) | 1 | 50% (3 of 6) |
| Opponent | Vampire Counts | 24 | 5 (net +19) | 0 | 4 (net +180) | 5 (net +106) | 3 (net +37) | 4 (net -66) | 3 | 19% (4 of 21) |
| Opponent | Warriors of Chaos | 22 | 4 (net +309) | 0 | 2 (net +263) | 6 (net +88) | 2 (net +88) | 5 (net +47) | 3 | 11% (2 of 19) |
| Opponent | Wood Elf Realms | 20 | 1 (net -27) | 1 (net +0) | 7 (net +270) | 5 (net +50) | 2 (net +98) | 4 (net +94) | 0 | 35% (7 of 20) |

### Charged fights, damage counted: jb-h2h-mine-b54c226-p4

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 13 | 183 | 280 | +137 | 261 | 122 | +139 | +75.7 |
| Mine | 50-54% | 1 | 110 | 115 | +115 | 115 | 0 | +115 | +104.5 |
| Mine | Effective (55-75%) | 15 | 318 | 277 | +164 | 180 | 70 | +109 | +34.3 |
| Mine | 76-89% | 23 | 276 | 210 | +74 | 129 | 55 | +74 | +26.7 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 24 | 268 | 180 | +81 | 127 | 31 | +96 | +36.0 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 12 | 453 | 86 | +107 | 107 | 0 | +107 | +23.7 |
| Mine | No odds | 13 | 190 | 114 | +30 | 47 | 18 | +29 | +15.4 |
| Mine | All fights | 101 | 277 | 194 | +96 | 140 | 48 | +91 | +33.0 |
| Opponent | Long shot (under 50%) | 19 | 215 | 304 | +58 | 128 | 57 | +71 | +33.0 |
| Opponent | 50-54% | 2 | 75 | 224 | +0 | 8 | 11 | -3 | -4.1 |
| Opponent | Effective (55-75%) | 24 | 353 | 260 | +205 | 269 | 60 | +209 | +59.3 |
| Opponent | 76-89% | 23 | 299 | 156 | +78 | 130 | 80 | +50 | +16.7 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 21 | 329 | 209 | +62 | 137 | 57 | +79 | +24.2 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 8 | 430 | 77 | +60 | 66 | 21 | +45 | +10.5 |
| Opponent | No odds | 19 | 314 | 161 | +59 | 91 | 24 | +67 | +21.3 |
| Opponent | All fights | 116 | 309 | 208 | +92 | 147 | 54 | +93 | +30.1 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| jb-h2h-mine-b54c226-p4 | move | 401 | 88 (22%) | 51 (13%) | 51 (13%) | 262 (65%) |
| jb-h2h-mine-b54c226-p4 | objective | 387 | 51 (13%) | 31 (8%) | 55 (14%) | 281 (73%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0114, L0130, L2527, L2634 |
| Charmed Shield | Opponent | L0434, L0624, L0926, L1034, L1126, L1427, L2227, L2527, L2634, L3234 |
| Clockwork Compass | Mine | L1220 |
| Elixir of Power | Mine | L1126 |
| Elixir of Power | Opponent | L0819, L1719, L1819 |
| Fistful of Laurels | Mine | L1819, L1835 |
| Invocation of Nehek | Mine | L2527 |
| Invocation of Nehek | Opponent | L0624, L1427, L2227, L2527 |
| Opal Amulet | Mine | L1427 |
| Opal Amulet | Opponent | L0114, L0214, L1314 |
| Periapt of Soul Exchange | Mine | L2021, L2123 |
| Periapt of Soul Exchange | Opponent | L0520, L1220, L1621, L2021 |
| Ring of Doom | Mine | L0214, L0230, L1126, L1220, L1523 |
| Ring of Doom | Opponent | L0315, L1331, L2331 |
| Ring of Jet | Mine | L1017, L1034, L1126, L1220 |
| Standard of the Fell Warrior | Mine | L1314, L1331 |
| Standard of the Fell Warrior | Opponent | L0713 |
| Storm Daemon (Renegade 2.0) | Mine | L2123 |
| Storm Daemon (Renegade 2.0) | Opponent | L1621, L2021 |
| Twice-Blessed Armour | Mine | L0713, L0729, L1017, L1034 |
| Witch Hunter's Ward | Mine | L0713, L0729, L0819, L0835 |
| Witch Hunter's Ward | Opponent | L0608 |

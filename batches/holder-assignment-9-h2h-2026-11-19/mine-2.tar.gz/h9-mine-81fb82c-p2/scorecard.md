# Doctrine scorecard: h9-mine-81fb82c-p2

### Scorecard: h9-mine-81fb82c-p2

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0108 | 6 | 1 | Mine | no | 8 | - | 0 | 2 | 0 | 0 | 0 | 55 |
| L0108 | 6 | 1 | Opponent | yes | 0 | 2 | 2 | 2 | 0 | 0 | 0 | 225 |
| L0123 | 3 | 1 | Mine | no | 5 | - | 0 | 2 | 0 | 0 | 0 | 120 |
| L0123 | 3 | 1 | Opponent | no | 2 | 2 | 4 | 3 | 0 | 0 | 0 | 70 |
| L0207 | 3 | 1 | Mine | no | 4 | - | 0 | 7 | 0 | 0 | 0 | 170 |
| L0207 | 3 | 1 | Opponent | no | 3 | 2 | 0 | 0 | 0 | 0 | 0 | 45 |
| L0224 | 2 | 1 | Mine | - | - | 2 | 2 | 5 | 0 | 0 | 0 | 167 |
| L0224 | 2 | 1 | Opponent | - | - | 5 | 2 | 3 | 0 | 0 | 0 | 0 |
| L0308 | 2 | 1 | Mine | - | - | 2 | 1 | 3 | 0 | 0 | 0 | 0 |
| L0308 | 2 | 1 | Opponent | - | - | - | 0 | 2 | 0 | 0 | 0 | 385 |
| L0325 | 1 | 1 | Mine | no | 1 | - | 0 | 0 | 0 | 0 | 0 | 110 |
| L0325 | 1 | 1 | Opponent | no | 2 | 2 | 1 | 3 | 0 | 0 | 0 | 0 |
| L0411 | 3 | 1 | Mine | no | 5 | 2 | 6 | 2 | 0 | 0 | 0 | 0 |
| L0411 | 3 | 1 | Opponent | yes | 5 | 6 | 0 | 0 | 0 | 0 | 0 | 0 |
| L0427 | 1 | 1 | Mine | no | 0 | 2 | 1 | 3 | 0 | 0 | 0 | 65 |
| L0427 | 1 | 1 | Opponent | no | 0 | 1 | 2 | 5 | 0 | 0 | 0 | 0 |
| L0513 | 3 | 1 | Mine | yes | 6 | - | 0 | 1 | 0 | 0 | 0 | 594 |
| L0513 | 3 | 1 | Opponent | no | 7 | 2 | 3 | 0 | 0 | 0 | 0 | 247 |
| L0530 | 2 | 1 | Mine | - | - | - | 0 | 1 | 0 | 0 | 0 | 1036 |
| L0530 | 2 | 1 | Opponent | - | - | 2 | 3 | 4 | 0 | 0 | 0 | 0 |
| L0618 | 6 | 1 | Mine | no | 9 | - | 1 | 2 | 0 | 0 | 0 | 290 |
| L0618 | 6 | 1 | Opponent | no | 7 | 5 | 1 | 0 | 1 | 0 | 0 | 0 |
| L0633 | 3 | 1 | Mine | yes | 3 | - | 1 | 4 | 1 | 0 | 0 | 495 |
| L0633 | 3 | 1 | Opponent | no | 0 | 3 | 5 | 3 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 22% | 4.6 | 2.0 | 1.0 | 2.7 | 0.1 | 0.0 | 0.0 | 258.5 |
| **Average** | | | Opponent | 22% | 2.9 | 2.9 | 1.9 | 2.1 | 0.1 | 0.0 | 0.0 | 81.0 |

### KPIs: h9-mine-81fb82c-p2

Rules off - Opponent only: HOLDER ASSIGNMENT, QUARTER ODDS, WALK PROMISE, REAL GROUND, RISK ON THE WAY, ONE ROUTE, MARCH WHEELS ONLY, LATE ONLY FROM HERE, WALKS ON ITS ROUTE.

Morten 2026-11-10; 12 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 43% (23 of 53) | 15% (9 of 61) | 28% (32 of 114) |
| Winner chose to follow up after the loser gave ground |  | 44% (4 of 9); on the table 67% | 67% (4 of 6); on the table 67% | 53% (8 of 15); on the table 67% |
| Winner chose to pursue after the loser fell back in good order |  | 100% (1 of 1); on the table 100% | 50% (2 of 4); on the table 50% | 60% (3 of 5); on the table 60% |
| Winner chose to pursue after the loser fled |  | 67% (2 of 3); on the table 67% | 91% (10 of 11); on the table 91% | 86% (12 of 14); on the table 86% |
| Winner chose to follow up or pursue (all three) |  | 54% (7 of 13); on the table 69% | 76% (16 of 21); on the table 76% | 68% (23 of 34); on the table 74% |
| Magic missiles tried each own turn | 50%+ | 41% (56 of 138) | 44% (21 of 48) | 41% (77 of 186) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 52% (56 of 107) | 45% (21 of 47) | 50% (77 of 154) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 55% (6 of 11) | - | 55% (6 of 11) |
| Points that never fought | lower | 62% (14700 of 23594) | 58% (13849 of 23995) | 60% (28549 of 47589) |
|   infantry points that never fought | lower | 60% (4369 of 7332) | 76% (3238 of 4287) | 65% (7607 of 11619) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 64% (56 of 88) | 55% (51 of 93) | 59% (107 of 181) |
| Bound items with a magic missile used (at least once a game) |  | 100% (6 of 6); 1.6 uses a game | 100% (6 of 6); 1.7 uses a game | 100% (12 of 12); 1.6 uses a game |
| Bound items with another spell used |  | 100% (2 of 2); 0.6 uses a game | 33% (1 of 3); 0.1 uses a game | 60% (3 of 5); 0.3 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 62% (5 of 8); 0.4 uses a game | 50% (3 of 6); 0.2 uses a game | 57% (8 of 14); 0.3 uses a game |
|   their share of the points of units over 100 pts | lower | 58% (10269 of 17752) | 51% (10546 of 20774) | 54% (20815 of 38526) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.4 (21%) | 0.4 (19%) | 1.8 (20%) |
| MARCHED: its unit marched | 1.6 (23%) | 0.7 (30%) | 2.2 (25%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.2 (7%) | 0.2 (2%) |
| IN COMBAT: engaged in combat | 0.5 (7%) | 0.1 (4%) | 0.6 (6%) |
| REAR RANK: in a rear rank | 0.9 (13%) | 0.2 (11%) | 1.2 (13%) |
| GONE: slain | 1.2 (18%) | 0.0 (0%) | 1.2 (14%) |
| OFF THE TABLE: off the table or not arrived | 0.8 (12%) | 0.0 (0%) | 0.8 (9%) |
| STUPIDITY: Stupidity | 0.3 (5%) | 0.3 (15%) | 0.7 (7%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.1 (4%) | 0.1 (1%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.2 (11%) | 0.2 (3%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 3.9 | 1.1 | 2.2 | 6.4 | 0.5 | 0.8 |
| not cast | 3.6 | 1.8 | 5.3 | 9.1 | 1.5 | 21.2 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.8 (4%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.5 (86%) | 0.5 (9%) | 1.8 (20%) | 0.2 (11%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.2 (25%) | 0.3 (22%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (2%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.1 (2%) | 0.0 (0%) | 0.2 (5%) | 0.6 (6%) | 0.2 (11%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 1.0 (28%) | 0.0 (0%) | 0.5 (9%) | 1.2 (13%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | 0.4 (12%) | 0.0 (0%) | 0.4 (8%) | 1.2 (14%) | 0.0 (0%) | 0.9 (4%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (0%) | 0.0 (0%) | 0.8 (16%) | 0.8 (9%) | 0.0 (0%) | 0.8 (4%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.0 (0%) | 0.2 (3%) | 0.7 (7%) | 0.0 (0%) | 0.7 (3%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.1 (5%) | 0.0 (0%) | 0.1 (1%) | 0.8 (56%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (3%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.1 (58%) | 0.2 (10%) | 2.7 (50%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 17.9 (85%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.7 a game | 1.1 a game | 1.4 a game |
| stood (cast and not dispelled) | 75% (15 of 20) | 85% (11 of 13) | 79% (26 of 33) |
| the unit moved after it | 67% (10 of 15) | 100% (11 of 11) | 81% (21 of 26) |
| it charged on its next turn | 0% (0 of 15) | 0% (0 of 11) | 0% (0 of 26) |
| the enemy charged it first | 7% (1 of 15) | 0% (0 of 11) | 4% (1 of 26) |
| it fought by the end of its next turn | 0% (0 of 15) | 0% (0 of 11) | 0% (0 of 26) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 15) | 0% (0 of 11) | 0% (0 of 26) |
| none of these (no charge, no fight, no charge escaped) | 93% (14 of 15) | 100% (11 of 11) | 96% (25 of 26) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 59% (208 of 353) | 53% (145 of 272) | 56% (353 of 625) |
|   cavalry | 23% (6 of 26) | 50% (21 of 42) | 40% (27 of 68) |
|   character | 87% (33 of 38) | 38% (15 of 40) | 62% (48 of 78) |
|   chariot | 62% (29 of 47) | 83% (20 of 24) | 69% (49 of 71) |
|   infantry | 48% (36 of 75) | 42% (31 of 74) | 45% (67 of 149) |
|   monster | 70% (7 of 10) | 44% (4 of 9) | 58% (11 of 19) |
|   war machine | 62% (97 of 157) | 65% (54 of 83) | 63% (151 of 240) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.9 (24%) | 2.4 (23%) | 5.3 (24%) |
| CHARGED: it charged | 0.3 (3%) | 1.3 (13%) | 1.7 (7%) |
| FLEEING: it fled or was fleeing | 0.2 (2%) | 0.1 (1%) | 0.3 (1%) |
| IN COMBAT: it fought this turn or the last | 0.6 (5%) | 0.5 (5%) | 1.1 (5%) |
| MOVED: a war machine that moved | 1.8 (14%) | 1.3 (13%) | 3.1 (14%) |
| NO TARGET IN RANGE | 3.3 (28%) | 1.8 (17%) | 5.1 (22%) |
| ONLY IN COMBAT: the only targets were in combat | 0.1 (1%) | 0.6 (6%) | 0.7 (3%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 2.3 (19%) | 2.1 (20%) | 4.4 (19%) |
| SHELTERED: the target was sheltered | 0.2 (1%) | 0.1 (1%) | 0.2 (1%) |
| OTHER BAR | 0.3 (3%) | 0.4 (4%) | 0.8 (3%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 3.4 | 2.1 | 63% | 10.7 pts | 36 pts |
| character | 4.5 | 3.1 | 63% | 10.4 pts | 47 pts |
| chariot | 4.1 | 4.7 | 51% | 24.9 pts | 102 pts |
| infantry | 9.9 | 5.8 | 62% | 12.3 pts | 122 pts |
| monster | 0.9 | 0.0 | 100% | 0.0 pts | 0 pts |
| war machine | 12.6 | 10.8 | 64% | 18.9 pts | 238 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 1.3 | 4.6 | 3.0 |
| Charges that made contact a game | 1.0 | 3.2 | 2.1 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.17 declared, 0.17 contact (6 units) | 0.50 declared, 0.17 contact (6 units) | 0.33 declared, 0.17 contact (12 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 1.25 declared, 1.25 contact (4 units) | 1.25 declared, 1.25 contact (4 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.18 declared, 0.13 contact (83 units) | 0.52 declared, 0.35 contact (91 units) | 0.36 declared, 0.25 contact (174 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 47% (7 of 15) | 33% (2 of 6) | 50% (1 of 2) | 43% (10 of 23) |
| Character in a unit | 81% (13 of 16) | 50% (5 of 10) | 0% (0 of 1) | 67% (18 of 27) |
| Character on its own | 93% (14 of 15) | 58% (7 of 12) | 45% (5 of 11) | 68% (26 of 38) |
| Chariot | 100% (3 of 3) | 60% (6 of 10) | - | 69% (9 of 13) |
| Infantry | 33% (6 of 18) | 35% (7 of 20) | 50% (1 of 2) | 35% (14 of 40) |
| Monster | 67% (4 of 6) | 50% (1 of 2) | - | 62% (5 of 8) |
| Monstrous | 100% (1 of 1) | 50% (1 of 2) | - | 67% (2 of 3) |
| War Machines | 78% (21 of 27) | 100% (2 of 2) | - | 79% (23 of 29) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 20% (1 of 5); on the table 60% | 41% (42 of 102) | 68% | 68% (15 of 22) | 100% (6 of 6); 4.8 uses a game | 100% (2 of 2); 1.8 uses a game | 67% (4 of 6); 1.0 uses a game |
| Chaos Dwarfs | 4 | 100% (4 of 4); on the table 100% | 39% (14 of 36) | 69% | 59% (19 of 32) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
| Dwarfen Mountain Holds | 4 | 50% (2 of 4); on the table 50% | - | 50% | 65% (22 of 34) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 3 | 50% (1 of 2); on the table 50% | 67% (8 of 12) | 84% | 60% (18 of 30) | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game | 67% (2 of 3); 0.7 uses a game |
| Grand Cathay | 1 | 33% (1 of 3); on the table 33% | 50% (6 of 12) | 25% | 62% (5 of 8) | 100% (2 of 2); 6.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| High Elf Realms | 1 | 100% (3 of 3); on the table 100% | 50% (3 of 6) | 63% | 25% (2 of 8) | 100% (1 of 1); 4.0 uses a game | 50% (1 of 2); 1.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 1 | 100% (3 of 3); on the table 100% | 0% (0 of 6) | 70% | 57% (4 of 7) | 100% (1 of 1); 3.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Tomb Kings of Khemri | 1 | 0% (0 of 1); on the table 0% | - | 30% | 20% (1 of 5) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 3 | 75% (3 of 4); on the table 75% | 33% (4 of 12) | 57% | 79% (15 of 19) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 1 | 100% (1 of 1); on the table 100% | - | 17% | 0% (0 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Wood Elf Realms | 1 | 100% (4 of 4); on the table 100% | - | 62% | 60% (6 of 10) | 100% (2 of 2); 7.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (h9-mine-81fb82c-p2, 12 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 53% (10) | 22% (2) | 43% (12) |
| ...free all their last turn and able to turn (per game) | 0.67 | 0.08 | 0.75 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.17 | 0.08 | 0.25 |
| ...with the charger already in that arc before they moved (per game) | 0.50 | 0.08 | 0.58 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.33 | 0.08 | 0.42 |

### Quality by phase: h9-mine-81fb82c-p2

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.5 | 2.2 |
| Strategy | Charge objectives carried out (made contact) | 56% (9 of 16) | 48% (22 of 46) |
| Strategy | Shoot objectives carried out (shot that target) | 49% (81 of 167) | 55% (54 of 98) |
| Strategy | Support requests answered (helper made contact too) | - | 60% (3 of 5) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (1 of 1) | 100% (1 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | - | 40% (2 of 5) |
| Strategy | Joined characters whose unit fought | 18% (4 of 22) | 30% (6 of 20) |
| Strategy | Lone characters that fought | 59% (19 of 32) | 50% (14 of 28) |
| Movement | Charges halted short of contact | 0.0 | 0.2 |
| Movement | Idle units | 2.7 | 2.1 |
| Movement | Points that never moved of their own | 258.5 | 81.0 |
| Movement | Fights charged into per game | 1.0 | 2.7 |
| Movement | Charges with odds: long shots (under 50%) | 5 of 11, net +56 | 6 of 26, net -75 |
| Movement | Charges with odds: sweet spot (55-75%) | 1 of 11, net +0 | 1 of 26, net +0 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 1 of 11, net +0 | 10 of 26, net +103 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 of 11, net +158 | 8 of 26, net +303 |
| Shooting | Shots by shooting units (incl. breath weapons) | 9.8 | 7.9 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 35% (41 of 117) | 56% (53 of 95) |
| Shooting | Points destroyed by shooting units | 91.7 | 47.3 |
| Shooting | War machine shots | 8.1 | 4.5 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 52% (50 of 97) | 54% (29 of 54) |
| Shooting | Points destroyed by war machines | 31.8 | 51.7 |
| Magic | Magic missiles cast | 2.5 | 1.2 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 43% (13 of 30) | 33% (5 of 15) |
| Magic | Wounds caused by magic missiles | 6.9 | 1.8 |
| Magic | Wounds caused by other spells | 0.4 | 0.3 |
| Magic | Points destroyed by magic (all spells) | 13.6 | 48.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.8 / 0.0 / 0.4 / 0.0 | 2.1 / 0.6 / 0.2 / 0.4 |
| Combat | Points destroyed in combat | 154.0 | 256.5 |
| Combat | Points run down | 47.9 | 182.4 |
| Combat | Net points per charged fight, damage counted | +64 | +112 |
| Combat | Net per 100 charger points, damage counted | +33.1 | +35.0 |
| Combat | First round won (charged fights) | 50% | 78% |
| Combat | Net points per charged fight | +50 | +104 |
| Combat | Net points per supported fight / lone fight | - / +50 | +237 / +73 |
| Combat | Charged fights on a top-3 enemy unit | 4 of 12 | 14 of 32 |
| Game | Points lost | 698.4 | 356.8 |
| Game | VP from objectives | 557.5 | 891.7 |
| Game | Lone holders (player turns) | 4.6 | 2.9 |

- Mine won / drew / lost: 2 / 4 / 6 of 12 ended games (of 12); mean margin (Mine - Opponent) -735 VP
- The side that went first won 3 of 8 games with a winner
- Points traded per game (both sides' losses): 1055
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: h9-mine-81fb82c-p2

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.8 | +0.0 | 0.0 | 0.0 | 0.8 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.3 | +55.9 | 0.0 | 60.5 | 0.2 | +56.2 | 0.0 | 0.0 |
| ARRIVAL HUNT | - | - | - | - | 0.1 | +4.0 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.7 | +0.0 | 0.0 | 9.2 | 1.2 | +0.0 | 0.0 | 13.8 |
| BACKUP TARGETS | - | - | - | - | 0.2 | +1.0 | 0.0 | 0.0 |
| BEST PRIZE | - | - | - | - | 0.2 | -7.4 | 12.1 | 0.0 |
| BLOWS WHERE AIMED | - | - | - | - | 0.2 | -48.8 | 29.5 | 16.2 |
| BOMBING RUN | - | - | - | - | 0.1 | +2.2 | 0.0 | 12.5 |
| CANNON PLAN MISSED | 0.8 | +0.0 | 16.3 | 17.1 | 0.7 | +0.0 | 64.2 | 10.4 |
| CANNON PLANNED TARGET | 7.0 | +164.8 | 155.2 | 73.8 | 3.6 | +177.8 | 163.2 | 70.8 |
| CANNON SIGHT KEPT | 1.5 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT SET-UP | 0.1 | -0.8 | 0.0 | 0.0 | 0.2 | +0.0 | 9.5 | 0.0 |
| CAST JOB | 0.8 | +5.4 | 21.0 | 7.1 | 0.3 | +3.9 | 0.0 | 0.0 |
| CASTER AWAY FROM SCREEN | 0.6 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CASTING BLOCK | 0.3 | +43.3 | 0.0 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | 1.2 | +0.0 | 0.0 | 47.9 | 0.9 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | - | - | - | - | 0.4 | +0.0 | 0.0 | 0.0 |
| CATCH ODDS | 0.1 | +1.8 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | 0.6 | +31.2 | 0.0 | 23.0 | 0.2 | +9.4 | 0.0 | 12.5 |
| CHAFF PASSED | 0.1 | -0.8 | 0.0 | 0.0 | 0.2 | -1.6 | 0.0 | 0.0 |
| CHARACTER GUNS | 0.8 | +0.0 | 0.0 | 48.2 | 0.8 | +0.0 | 0.0 | 0.0 |
| CHARGE LOSSES | 6.5 | -320.0 | 0.0 | 188.6 | 6.4 | -328.7 | 0.0 | 99.2 |
| CHARGE NOT DECLARED | 0.2 | +0.0 | 12.5 | 0.0 | 1.1 | +0.0 | 95.2 | 2.8 |
| CHARGE NOW FIRST | 0.8 | +0.0 | 85.4 | 0.0 | 1.4 | +0.0 | 187.7 | 21.2 |
| CHARGER SLAIN LOST | 0.1 | -0.6 | 0.0 | 5.0 | 0.1 | -0.6 | 0.0 | 16.2 |
| CHEAPEST HOLDER | - | - | - | - | 0.3 | -25.6 | 60.5 | 0.0 |
| COMBAT PIVOT | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 5.0 | 0.0 |
| CONVEYANCE SEARCH | 1.2 | +89.3 | 5.4 | 47.9 | 0.3 | +13.0 | 0.0 | 0.0 |
| COVER ONCE | 6.9 | -338.8 | 0.0 | 173.6 | 5.5 | -307.6 | 0.0 | 43.3 |
| DEFENSIVE ARMY | - | - | - | - | 0.1 | +0.0 | 0.0 | 6.4 |
| DEFENSIVE FLOOR | 0.1 | -2.1 | 0.0 | 10.0 | - | - | - | - |
| DEPLOY BY FIGURES | 9.6 | +3.8 | 0.0 | 4.6 | 7.8 | -40.5 | 0.0 | 0.0 |
| ENGINEER BY LORE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FALL BACK GOOD ORDER | 0.8 | +3.6 | 70.4 | 10.0 | 2.5 | +0.8 | 294.2 | 8.7 |
| FALLBACK BY WORTH | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| FALLS SHORT | 6.7 | +155.9 | 0.0 | 134.8 | 17.2 | +259.4 | 0.0 | 91.7 |
| FEATURE BUFFS | 1.7 | +45.0 | 0.0 | 37.6 | 0.4 | +9.1 | 0.0 | 18.7 |
| FIGHT LIFT | 0.1 | +0.2 | 0.0 | 48.3 | - | - | - | - |
| FIGHT TO THE END | 0.5 | +3.1 | 86.3 | 0.0 | 1.4 | +38.2 | 177.6 | 40.3 |
| FIRE AND FLEE | - | - | - | - | 0.2 | +7.2 | 0.0 | 34.7 |
| FIRE IN ORDER | 0.1 | +0.0 | 0.0 | 25.8 | 0.2 | +0.0 | 9.2 | 21.0 |
| FIVE ACTION | 48.4 | +2742.0 | 515.8 | 728.7 | 48.8 | +3109.3 | 699.1 | 425.6 |
| FLANK NOT WEIGHED | 5.0 | +0.0 | 0.0 | 156.3 | 3.3 | +0.0 | 0.0 | 32.8 |
| FOCUS FIRE | 0.1 | +3.1 | 0.0 | 0.0 | - | - | - | - |
| FOLLOW UP WEIGHED | 0.2 | +52.5 | 0.0 | 24.1 | 0.4 | +101.9 | 0.0 | 36.8 |
| FOUR ROUNDS | 1.3 | +33.4 | 158.5 | 15.0 | 3.7 | +334.1 | 372.9 | 40.3 |
| FRIEND CHARGES FIRST | - | - | - | - | 0.1 | -0.9 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 0.8 | -11.7 | 0.0 | 0.0 | 0.2 | -1.8 | 0.0 | 0.0 |
| GIVES UP | 0.1 | -0.4 | 6.2 | 0.0 | 0.4 | -10.1 | 17.9 | 0.0 |
| GROUND FLIERS | - | - | - | - | 0.2 | +2.3 | 0.0 | 0.0 |
| GUN FIGURES | 1.8 | +30.9 | 72.2 | 25.8 | 1.8 | +9.1 | 5.4 | 22.1 |
| GUN MASK | 0.4 | +11.6 | 0.0 | 0.0 | 1.3 | +20.5 | 0.0 | 12.6 |
| HARD STAY DROPPED | 2.2 | +0.0 | 0.0 | 9.3 | 0.9 | +0.0 | 0.0 | 0.0 |
| HE SHOOTS OR CHARGES | 1.9 | +0.0 | 0.0 | 74.2 | 2.4 | +0.0 | 0.0 | 20.1 |
| HELPER ALREADY ASKED | - | - | - | - | 0.1 | +0.0 | 7.9 | 0.0 |
| HELPER UNSEEN | - | - | - | - | 0.1 | +0.0 | 5.4 | 0.0 |
| HIS CHARGE DENIED | - | - | - | - | 0.2 | +11.0 | 0.0 | 0.0 |
| HIS CHARGE LIST | 3.5 | +0.0 | 0.0 | 86.1 | 3.8 | +0.0 | 0.0 | 44.2 |
| HIS LEGAL MOVES | 3.1 | +0.0 | 0.0 | 71.6 | 3.8 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 1.2 | -18.5 | 0.0 | 19.8 | 1.6 | -59.5 | 0.0 | 21.0 |
| HIS ONE QUARTER | 2.7 | +0.0 | 0.0 | 85.5 | - | - | - | - |
| HIS RANDOM MOVE | - | - | - | - | 3.8 | +0.0 | 0.0 | 5.0 |
| HIS SHOT LIST | 19.8 | +785.4 | 0.0 | 311.1 | 21.8 | +1207.2 | 0.0 | 145.9 |
| HIS TURN DENIED | 0.9 | +74.2 | 111.4 | 5.0 | 2.2 | +141.6 | 234.8 | 40.3 |
| HOLD ODDS | 11.2 | +0.0 | 0.0 | 221.8 | - | - | - | - |
| HOLDER ASSIGNMENT | 11.7 | +1151.9 | 0.0 | 202.6 | - | - | - | - |
| HOLDER AT DEPLOYMENT | - | - | - | - | 1.1 | +196.6 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 1.2 | -32.0 | 158.5 | 10.0 | 3.2 | -154.4 | 339.7 | 24.1 |
| HORN WORTH | - | - | - | - | 0.1 | +0.7 | 0.0 | 0.0 |
| HUNT IN PAIRS | - | - | - | - | 0.8 | +44.1 | 0.0 | 16.2 |
| HUNT RESULT | - | - | - | - | 0.2 | +29.8 | 0.0 | 0.0 |
| HUNT THE GUNS | - | - | - | - | 0.3 | +54.7 | 25.4 | 0.0 |
| IDLE COST | 3.3 | -42.7 | 0.0 | 32.2 | 9.3 | -142.8 | 0.0 | 49.2 |
| JOINT KNOWS CHALLENGE | - | - | - | - | 0.2 | -3.4 | 48.2 | 0.0 |
| KEEP FALLS | 0.2 | +1.2 | 0.0 | 18.3 | - | - | - | - |
| KEEPS SCOUTS OR AMBUSH | 0.2 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KILLS COUNT | - | - | - | - | 0.1 | +0.5 | 9.2 | 0.0 |
| LANE BY FIGURES | 0.2 | +2.2 | 0.0 | 0.0 | 0.7 | +28.5 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 2.9 | +0.0 | 57.3 | 151.1 | 2.2 | +0.0 | 32.1 | 75.8 |
| LONE WIZARD KEPT IN | 0.7 | +61.6 | 0.0 | 0.0 | 0.3 | +31.3 | 0.0 | 0.0 |
| LONG SHOT | 0.1 | -0.1 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| LURE BY WHAT IT DRAWS | 0.3 | -11.9 | 0.0 | 10.8 | - | - | - | - |
| MAKE SURE TOGETHER | - | - | - | - | 0.2 | +4.6 | 0.0 | 0.0 |
| MANOEUVRE | 1.2 | +7.1 | 0.0 | 29.5 | 1.6 | +16.2 | 0.0 | 55.3 |
| MARCH AT ESCAPER | 0.2 | +0.0 | 0.0 | 0.0 | 0.2 | +2.6 | 0.0 | 0.0 |
| MARCH BY THE SUM | 0.5 | +52.2 | 0.0 | 96.7 | 0.2 | +5.1 | 0.0 | 0.0 |
| MARCH CHECK | 1.2 | +93.8 | 0.0 | 77.8 | 1.0 | +48.8 | 0.0 | 0.0 |
| MARCH ODDS | 0.1 | +5.6 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 0.8 | +12.1 | 0.0 | 62.2 | 0.7 | +55.9 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 0.8 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MAX FOR POSITIONING | 5.4 | +90.7 | 0.0 | 107.2 | 4.2 | +55.7 | 0.0 | 53.4 |
| MISSILES IN THE MOVE | 3.8 | +213.7 | 0.0 | 34.8 | 3.5 | +59.2 | 0.0 | 35.8 |
| MISSILES NEXT TURN | 4.3 | +142.3 | 0.0 | 97.0 | 4.2 | +43.7 | 0.0 | 35.8 |
| MODEL FACING | 0.8 | +158.5 | 0.0 | 10.0 | - | - | - | - |
| MOVE SPELL IN RANGE | 0.5 | +14.5 | 0.0 | 96.7 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.8 | -15.0 | 0.0 | 59.2 | 0.2 | -15.1 | 0.0 | 0.0 |
| MOVE SPELL SPOT | 0.6 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 2.3 | +326.6 | 0.0 | 32.8 | 2.7 | +340.0 | 0.0 | 8.7 |
| MOVES UNITS SPELL | 0.2 | +9.2 | 0.0 | 0.0 | - | - | - | - |
| NEARER NOT NEEDED | 5.6 | +263.0 | 0.0 | 97.9 | 5.2 | +296.1 | 0.0 | 38.0 |
| NEEDED THERE | - | - | - | - | 0.1 | +16.9 | 9.2 | 0.0 |
| NEXT CHARGE BY LIST | 4.2 | -70.7 | 0.0 | 61.5 | 4.8 | -170.1 | 0.0 | 45.9 |
| NEXT OBJECTIVE NEARER | - | - | - | - | 10.9 | -657.8 | 13.8 | 84.2 |
| NO DOUBLE ROUNDS | 1.3 | -35.6 | 158.5 | 15.0 | 3.2 | -115.8 | 321.2 | 40.3 |
| NO RALLY LEFT | 0.1 | +0.2 | 0.0 | 5.4 | - | - | - | - |
| NOT TURNED | 0.3 | +0.0 | 0.0 | 10.8 | 0.1 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 0.2 | -0.4 | 0.0 | 0.0 | 1.2 | -1.0 | 0.0 | 0.0 |
| OFF BEST | 0.3 | -14.4 | 0.0 | 0.0 | 0.8 | -27.0 | 0.0 | 0.0 |
| ONE CHARGE A CHARGER | 1.9 | +0.0 | 0.0 | 34.9 | 1.2 | +0.0 | 0.0 | 4.2 |
| ONE FIGHT FORMULA | 4.5 | -104.1 | 0.0 | 162.7 | 3.9 | -97.5 | 0.0 | 11.5 |
| ONE OBJECTIVE FORMULA | 4.9 | +39.5 | 0.0 | 127.9 | 4.0 | +8.6 | 0.0 | 69.3 |
| ONE ROUTE | 0.8 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ONE TARGET A SHOOTER | 16.1 | +577.5 | 0.0 | 236.9 | 19.5 | +605.7 | 0.0 | 155.8 |
| OPENS A LANE | 0.2 | +0.7 | 0.0 | 15.5 | 0.3 | +3.2 | 11.4 | 0.0 |
| OPENS UP | 0.2 | +10.6 | 6.2 | 0.0 | 0.2 | +8.8 | 7.1 | 0.0 |
| OVERRUNS AWAY | 0.2 | +6.6 | 49.6 | 0.0 | 0.2 | +17.4 | 29.5 | 0.0 |
| PATHS CROSS | 2.2 | +55.8 | 0.0 | 34.2 | 5.2 | +206.1 | 0.0 | 5.5 |
| PIVOT GUARDS FLANK | 0.1 | -0.8 | 0.0 | 5.4 | - | - | - | - |
| PLAN RESULT | 42.6 | +558.0 | 411.7 | 828.1 | 43.2 | +667.1 | 392.0 | 575.0 |
| PURSUES BIG PREY | - | - | - | - | 0.1 | -1.2 | 0.0 | 0.0 |
| QUARTER ODDS | 6.7 | +676.3 | 27.5 | 168.8 | - | - | - | - |
| RANDOM MOVE BY FIGURES | 0.9 | +17.8 | 0.0 | 0.0 | - | - | - | - |
| REAL GROUND | 0.8 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| REDIRECT BY WHAT IT STOPS | - | - | - | - | 0.1 | -3.2 | 0.0 | 0.0 |
| REDIRECT COUNTER | 1.6 | +188.9 | 0.0 | 41.0 | 2.5 | +87.5 | 0.0 | 13.7 |
| REDIRECT WEIGHED | 0.1 | +8.7 | 0.0 | 0.0 | 0.5 | +0.2 | 13.8 | 2.8 |
| REFORMS TO MEET IT | 0.2 | -9.8 | 0.0 | 0.0 | 0.3 | -9.0 | 0.0 | 0.0 |
| REFUSING RETIRES | 0.2 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | 0.4 | +16.3 | 0.0 | 0.0 | 0.6 | +12.0 | 0.0 | 0.0 |
| RESTRAINS TO SHOOT | 0.1 | +3.7 | 0.0 | 0.0 | 0.1 | +3.0 | 0.0 | 0.0 |
| RISK BY ARC | 1.1 | +28.3 | 123.8 | 5.0 | 2.0 | -0.7 | 179.4 | 24.1 |
| RISK BY HIS FIGURE | 12.3 | -177.1 | 0.0 | 289.3 | 9.7 | -161.5 | 0.0 | 93.8 |
| RISK ON THE WAY | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| RUN DOWN | 1.0 | -12.9 | 111.4 | 15.0 | 2.7 | -36.2 | 292.9 | 24.1 |
| SCOUT SPOT | 0.2 | +0.5 | 0.0 | 4.6 | 0.5 | +0.5 | 0.0 | 0.0 |
| SCOUT WAITS | 0.2 | +0.0 | 0.0 | 4.6 | 0.6 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.1 | -1.4 | 0.0 | 0.0 | 0.3 | -12.4 | 0.0 | 0.0 |
| SEARCH SPOT | 4.6 | +205.3 | 0.0 | 55.8 | 7.6 | +340.9 | 0.0 | 59.5 |
| SET UP TOGETHER | - | - | - | - | 0.2 | +4.6 | 0.0 | 0.0 |
| SET-UP ANY TARGET | 0.2 | +30.8 | 0.0 | 18.3 | 0.1 | +2.4 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.7 | +1.3 | 0.0 | 0.0 | 0.1 | +0.4 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.8 | +79.1 | 51.2 | 48.3 | 0.8 | +27.5 | 0.0 | 37.9 |
| SHORT GUN FORWARD | 0.5 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| SHOT OR CHARGE | 0.4 | -9.5 | 47.2 | 10.0 | 0.7 | -24.8 | 43.2 | 12.6 |
| SHOT RISK POINTS | 13.1 | +47.6 | 0.0 | 297.2 | 12.7 | -100.8 | 0.0 | 124.8 |
| SHOTS IN THE MOVE | 17.7 | +755.6 | 0.0 | 257.2 | 14.8 | +540.7 | 0.0 | 236.8 |
| SPELL SETS UP CHARGE | 0.4 | +144.0 | 0.0 | 18.3 | 0.1 | +2.4 | 0.0 | 0.0 |
| SPELL WORTH | 0.2 | +2.4 | 5.4 | 29.6 | 1.8 | +29.8 | 17.3 | 0.0 |
| SPELLS IN THE FIGHT | 0.2 | -8.7 | 36.8 | 0.0 | 0.5 | +14.8 | 32.3 | 12.6 |
| STAND AND SHOOT | 0.3 | -10.7 | 48.3 | 5.0 | 0.8 | -13.2 | 65.9 | 11.5 |
| STANDS FOR A REASON | 0.3 | +0.0 | 13.7 | 0.0 | 0.5 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 25.6 | +0.0 | 343.7 | 258.2 | 15.0 | +0.0 | 271.9 | 158.5 |
| STAY WORTH | 21.8 | +164.6 | 201.4 | 216.3 | 16.9 | +187.5 | 173.6 | 282.9 |
| STOPS | - | - | - | - | 0.3 | +0.7 | 25.4 | 0.0 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SUPPORT NARROWED | 0.6 | +0.0 | 37.4 | 0.0 | 0.8 | +0.0 | 83.0 | 11.5 |
| SURE REACH TOGETHER | 0.1 | +0.1 | 0.0 | 0.0 | 1.0 | +22.4 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 2.7 | +0.0 | 0.0 | 43.2 | 5.8 | +0.0 | 0.0 | 0.0 |
| THE PROMISE ADDS | 0.1 | -1.9 | 0.0 | 0.0 | 0.2 | -23.1 | 33.2 | 0.0 |
| THE PROMISED MOVE | 0.8 | +0.0 | 0.0 | 24.1 | 0.2 | +0.0 | 0.0 | 0.0 |
| TIED UP BY THE SUM | 0.3 | +30.1 | 32.4 | 0.0 | 1.0 | +89.4 | 71.7 | 8.7 |
| TIME ON OUR SIDE | 25.8 | +324.6 | 0.0 | 307.9 | 11.8 | +192.9 | 0.0 | 189.8 |
| TWO OR MORE ARRIVE | - | - | - | - | 0.1 | +0.3 | 0.0 | 0.0 |
| WAITS AGAIN | 1.2 | +0.0 | 0.0 | 0.0 | 1.2 | +0.0 | 0.0 | 0.0 |
| WALKS ON ITS ROUTE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WAR ENGINE JOBS | 0.8 | +0.0 | 13.8 | 10.8 | - | - | - | - |
| WHO HITS BACK | - | - | - | - | 0.2 | +56.8 | 0.0 | 0.0 |
| WHOLE FIGHT | - | - | - | - | 0.1 | +10.9 | 24.1 | 0.0 |
| WHOLE FIGHT GAIN | - | - | - | - | 0.4 | +46.4 | 42.4 | 2.8 |
| WIDER SPREAD | 0.8 | -0.2 | 90.2 | 10.0 | 2.7 | +5.8 | 234.6 | 31.7 |
| WOUNDS ON THE RANKS | 2.6 | +148.7 | 0.0 | 74.8 | 2.3 | +126.3 | 0.0 | 42.0 |

### Rule changes: h9-mine-81fb82c-p2

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| SEARCH SPOT | 146 | 146 | 138 | 11.50 | +6555 | +47.5 |
| HIS SHOT LIST | 498 | 498 | 135 | 11.25 | +3345 | +24.8 |
| DEPLOY BY FIGURES | 208 | 208 | 133 | 11.08 | +2004 | +15.1 |
| HOLDER ASSIGNMENT | 140 | 140 | 130 | 10.83 | +8180 | +62.9 |
| ONE TARGET A SHOOTER | 427 | 427 | 107 | 8.92 | +1469 | +13.7 |
| FIVE ACTION | 1167 | 1166 | 103 | 8.58 | +5466 | +53.1 |
| TIME ON OUR SIDE | 451 | 405 | 99 | 8.25 | +278 | +2.8 |
| PATHS CROSS | 89 | 89 | 89 | 7.42 | +3144 | +35.3 |
| LEGAL CHARGES ONLY | 62 | 62 | 62 | 5.17 | +0 | +0.0 |
| SHOT RISK POINTS | 309 | 309 | 54 | 4.50 | +2024 | +37.5 |
| MOVE TO CHARGE COMPUTED | 60 | 60 | 40 | 3.33 | +3036 | +75.9 |
| HARD STAY DROPPED | 37 | 37 | 37 | 3.08 | +0 | +0.0 |
| ARTILLERY RE-ROLL WEIGHED | 34 | 34 | 34 | 2.83 | +0 | +0.0 |
| FOUR ROUNDS | 60 | 59 | 31 | 2.58 | +1522 | +49.1 |
| MAX FOR POSITIONING | 116 | 114 | 30 | 2.50 | +115 | +3.8 |
| COVER ONCE | 149 | 119 | 27 | 2.25 | +669 | +24.8 |
| CANNON SIGHT KEPT | 25 | 25 | 25 | 2.08 | +0 | +0.0 |
| FALLS SHORT | 287 | 254 | 24 | 2.00 | +196 | +8.2 |
| ADVANCE LANE KEPT | 20 | 20 | 20 | 1.67 | +0 | +0.0 |
| IDLE COST | 152 | 123 | 19 | 1.58 | +202 | +10.6 |
| MANOEUVRE | 33 | 33 | 19 | 1.58 | +363 | +19.1 |
| NEXT OBJECTIVE NEARER | 131 | 131 | 19 | 1.58 | +183 | +9.6 |
| SHOOTS FROM THE BEST SPOT | 31 | 31 | 19 | 1.58 | +285 | +15.0 |
| SHOTS IN THE MOVE | 390 | 368 | 19 | 1.58 | +604 | +31.8 |
| MARCH CHECK | 27 | 27 | 18 | 1.50 | +362 | +20.1 |
| CANNON PLANNED TARGET | 127 | 127 | 15 | 1.25 | -1036 | -69.1 |
| CHARGE NOT DECLARED | 15 | 15 | 15 | 1.25 | -1392 | -92.8 |
| MISSILES IN THE MOVE | 87 | 66 | 15 | 1.25 | +304 | +20.2 |
| OFF BEST | 14 | 14 | 14 | 1.17 | -497 | -35.5 |
| RISK BY ARC | 37 | 36 | 13 | 1.08 | +397 | +30.6 |
| RISK BY HIS FIGURE | 264 | 264 | 13 | 1.08 | +1697 | +130.6 |
| TIED UP BY THE SUM | 16 | 16 | 13 | 1.08 | +422 | +32.4 |
| WOUNDS ON THE RANKS | 59 | 59 | 13 | 1.08 | +809 | +62.2 |
| HIS TURN DENIED | 38 | 38 | 12 | 1.00 | +468 | +39.0 |
| LONE WIZARD KEPT IN | 12 | 12 | 12 | 1.00 | +1114 | +92.9 |
| RESERVE FALL BACK | 12 | 12 | 12 | 1.00 | +340 | +28.3 |
| CHARGE LOSSES | 155 | 155 | 11 | 0.92 | +1022 | +92.9 |
| LANE BY FIGURES | 10 | 10 | 10 | 0.83 | +369 | +36.9 |
| QUARTER ODDS | 80 | 80 | 10 | 0.83 | +783 | +78.3 |
| MODEL FACING | 9 | 9 | 9 | 0.75 | +1902 | +211.3 |
| NEXT CHARGE BY LIST | 109 | 109 | 9 | 0.75 | +268 | +29.7 |
| REDIRECT COUNTER | 49 | 44 | 9 | 0.75 | +923 | +102.6 |
| SCOUT WAITS | 9 | 9 | 9 | 0.75 | +0 | +0.0 |
| SHOOTERS IN TWO RANKS | 9 | 9 | 9 | 0.75 | +21 | +2.3 |
| HOLDS AMBUSHERS | 8 | 8 | 8 | 0.67 | +0 | +0.0 |
| MARCH BY THE SUM | 8 | 8 | 8 | 0.67 | +688 | +86.0 |
| ONE OBJECTIVE FORMULA | 107 | 91 | 8 | 0.67 | +410 | +51.3 |
| SHORT GUN FORWARD | 8 | 8 | 8 | 0.67 | +0 | +0.0 |
| SURE REACH TOGETHER | 13 | 13 | 8 | 0.67 | +40 | +5.0 |
| CASTER AWAY FROM SCREEN | 7 | 7 | 7 | 0.58 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 7 | 7 | 7 | 0.58 | +1854 | +264.8 |
| HOLDER AT DEPLOYMENT | 13 | 13 | 7 | 0.58 | +570 | +81.5 |
| ONE FIGHT FORMULA | 101 | 65 | 7 | 0.58 | +22 | +3.1 |
| REDIRECT WEIGHED | 7 | 7 | 7 | 0.58 | +161 | +23.0 |
| STAY WORTH | 464 | 448 | 7 | 0.58 | +235 | +33.6 |
| AFTERMATH IN POINTS | 6 | 6 | 6 | 0.50 | +1345 | +224.2 |
| CAST JOB | 13 | 13 | 6 | 0.50 | +5 | +0.8 |
| CHAFF IN THE MOVE | 10 | 10 | 6 | 0.50 | +22 | +3.7 |
| CHARGE NOW FIRST | 26 | 26 | 6 | 0.50 | -700 | -116.8 |
| NEARER NOT NEEDED | 129 | 128 | 6 | 0.50 | +210 | +35.0 |
| RANDOM MOVE BY FIGURES | 11 | 11 | 6 | 0.50 | +214 | +35.6 |
| CASTS FROM BEHIND | 5 | 5 | 5 | 0.42 | +0 | +0.0 |
| FEATURE BUFFS | 25 | 25 | 5 | 0.42 | +72 | +14.4 |
| FIGHT TO THE END | 23 | 23 | 4 | 0.33 | +32 | +8.1 |
| CHAFF PASSED | 3 | 3 | 3 | 0.25 | -29 | -9.6 |
| COMBAT PIVOT | 3 | 3 | 3 | 0.25 | +0 | +0.0 |
| FIRE IN ORDER | 3 | 3 | 3 | 0.25 | +0 | +0.0 |
| GUN MASK | 21 | 21 | 3 | 0.25 | +52 | +17.3 |
| KEEP FALLS | 3 | 3 | 3 | 0.25 | +36 | +11.9 |
| MISSILES NEXT TURN | 102 | 74 | 3 | 0.25 | +5 | +1.6 |
| WHO HITS BACK | 3 | 3 | 3 | 0.25 | +371 | +123.6 |
| BEST PRIZE | 2 | 2 | 2 | 0.17 | -88 | -44.1 |
| CASTING BLOCK | 4 | 4 | 2 | 0.17 | +207 | +103.5 |
| FIRE AND FLEE | 2 | 2 | 2 | 0.17 | +86 | +43.1 |
| HUNT IN PAIRS | 9 | 4 | 2 | 0.17 | +178 | +88.9 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.17 | +0 | +0.0 |
| MOVES UNITS SPELL | 2 | 2 | 2 | 0.17 | +110 | +55.1 |
| REFUSING RETIRES | 6 | 6 | 2 | 0.17 | -0 | -0.1 |
| RESTRAINS TO SHOOT | 2 | 2 | 2 | 0.17 | +79 | +39.7 |
| STOPS | 4 | 4 | 2 | 0.17 | +3 | +1.6 |
| BOMBING RUN | 1 | 1 | 1 | 0.08 | +26 | +26.0 |
| CARRIES OUT SET-UP | 3 | 3 | 1 | 0.08 | -10 | -10.2 |
| CATCH ODDS | 1 | 1 | 1 | 0.08 | -5 | -5.1 |
| FOCUS FIRE | 1 | 1 | 1 | 0.08 | +38 | +37.6 |
| HIS CHARGE DENIED | 2 | 2 | 1 | 0.08 | +10 | +10.4 |
| HORN WORTH | 1 | 1 | 1 | 0.08 | +8 | +8.3 |
| KILLS COUNT | 1 | 1 | 1 | 0.08 | +0 | +0.0 |
| MARCH ODDS | 1 | 1 | 1 | 0.08 | -44 | -44.5 |
| MOVE SPELL IN RANGE | 6 | 4 | 1 | 0.08 | +14 | +13.5 |
| NEEDED THERE | 1 | 1 | 1 | 0.08 | +0 | +0.0 |
| NO RALLY LEFT | 1 | 1 | 1 | 0.08 | +0 | +0.3 |
| OPENS A LANE | 7 | 6 | 1 | 0.08 | +3 | +3.0 |
| OPENS UP | 4 | 4 | 1 | 0.08 | +14 | +13.9 |
| OVERRUNS AWAY | 5 | 5 | 1 | 0.08 | +7 | +7.0 |
| PIVOT GUARDS FLANK | 1 | 1 | 1 | 0.08 | -9 | -9.3 |
| PURSUES BIG PREY | 1 | 1 | 1 | 0.08 | -14 | -14.2 |
| SPELLS IN THE FIGHT | 9 | 9 | 1 | 0.08 | +0 | +0.0 |
| STUCK PIVOT | 1 | 1 | 1 | 0.08 | +0 | +0.0 |
| SUPPORT NARROWED | 17 | 17 | 1 | 0.08 | -44 | -44.4 |
| WALKS ON ITS ROUTE | 1 | 1 | 1 | 0.08 | +0 | +0.0 |
| WAR ENGINE JOBS | 9 | 9 | 1 | 0.08 | -0 | -0.4 |
| WHOLE FIGHT | 1 | 1 | 1 | 0.08 | +0 | +0.0 |
| WHOLE FIGHT GAIN | 5 | 5 | 1 | 0.08 | +2 | +2.5 |
| WIDER SPREAD | 41 | 41 | 1 | 0.08 | +2 | +2.5 |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| BACKUP TARGETS | 2 | 1 | 0 | 0.00 | - | - |
| BLOWS WHERE AIMED | 3 | 3 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 18 | 18 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 26 | trace | - | - | - | - |
| CHARACTER GUNS | 20 | 20 | 0 | 0.00 | - | - |
| CHARGER SLAIN LOST | 2 | 2 | 0 | 0.00 | - | - |
| CHEAPEST HOLDER | 4 | 4 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 18 | not checked | - | - | - | - |
| DEFENSIVE ARMY | 1 | 1 | 0 | 0.00 | - | - |
| DEFENSIVE FLOOR | 1 | 1 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 40 | 39 | 0 | 0.00 | - | - |
| FALLBACK BY WORTH | 3 | 3 | 0 | 0.00 | - | - |
| FIGHT LIFT | 1 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 100 | not checked | - | - | - | - |
| FRIEND CHARGES FIRST | 1 | 1 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 11 | 11 | 0 | 0.00 | - | - |
| GIVES UP | 6 | 6 | 0 | 0.00 | - | - |
| GROUND FLIERS | 2 | not checked | - | - | - | - |
| GUN FIGURES | 42 | not checked | - | - | - | - |
| HE SHOOTS OR CHARGES | 52 | 52 | 0 | 0.00 | - | - |
| HELPER ALREADY ASKED | 1 | not checked | - | - | - | - |
| HELPER UNSEEN | 1 | 1 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 87 | 87 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 82 | 82 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 34 | 34 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 32 | 32 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 45 | 45 | 0 | 0.00 | - | - |
| HOLD ODDS | 135 | 135 | 0 | 0.00 | - | - |
| HONEST WORTH | 54 | 53 | 0 | 0.00 | - | - |
| HUNT RESULT | 3 | trace | - | - | - | - |
| HUNT THE GUNS | 4 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 2 | 2 | 0 | 0.00 | - | - |
| LONG SHOT | 2 | 1 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 4 | 4 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 3 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 5 | trace | - | - | - | - |
| MARCH OVER CASTS | 17 | 17 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 9 | 9 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 12 | trace | - | - | - | - |
| MOVE SPELL SPOT | 11 | not checked | - | - | - | - |
| NO DOUBLE ROUNDS | 54 | 53 | 0 | 0.00 | - | - |
| NOT TURNED | 5 | 5 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 18 | not checked | - | - | - | - |
| ONE CHARGE A CHARGER | 38 | 38 | 0 | 0.00 | - | - |
| ONE ROUTE | 9 | 9 | 0 | 0.00 | - | - |
| PLAN RESULT | 1030 | trace | - | - | - | - |
| REAL GROUND | 9 | 9 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 1 | 1 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 7 | 7 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 4 | 4 | 0 | 0.00 | - | - |
| RUN DOWN | 44 | 44 | 0 | 0.00 | - | - |
| SCOUT SPOT | 8 | 8 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 5 | 5 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 3 | 3 | 0 | 0.00 | - | - |
| SET-UP ANY TARGET | 4 | not checked | - | - | - | - |
| SHOT OR CHARGE | 13 | 13 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 6 | not checked | - | - | - | - |
| SPELL WORTH | 24 | not checked | - | - | - | - |
| STAND AND SHOOT | 13 | 13 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 10 | 10 | 0 | 0.00 | - | - |
| STANDS STILL | 487 | 487 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 101 | not checked | - | - | - | - |
| THE PROMISE ADDS | 4 | 4 | 0 | 0.00 | - | - |
| THE PROMISED MOVE | 12 | not checked | - | - | - | - |
| TWO OR MORE ARRIVE | 1 | not checked | - | - | - | - |
| WAITS AGAIN | 29 | 29 | 0 | 0.00 | - | - |

### Off best figure: h9-mine-81fb82c-p2

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| CHARGE NOT DECLARED | rule | 0.17 | 0.92 | 107.1 |
| JOB FIRST | gate | 0.17 | 0.75 | 29.3 |
| HOLDER ASSIGNMENT | rule | 0.83 | - | 21.9 |
| CANNON PLANNED TARGET | rule | 0.58 | - | 151.0 |
| PATHS CROSS | rule | 0.08 | 0.50 | 25.7 |
| CHARGE NOW FIRST | rule | 0.08 | 0.42 | 116.8 |
| CHAFF PASSED | rule | 0.08 | 0.17 | 9.6 |
| BEST PRIZE | rule | - | 0.17 | 44.1 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.08 | - | 121.3 |
| CARRIES OUT SET-UP | rule | 0.08 | - | 10.2 |
| CATCH ODDS | rule | 0.08 | - | 5.1 |
| DEPLOY BY FIGURES | rule | - | 0.08 | 13.2 |
| FALLBACK | gate | - | 0.08 | 5.9 |
| MARCH ODDS | rule | 0.08 | - | 44.5 |
| NO REASON | gate | 0.08 | - | 48.2 |
| PIVOT GUARDS FLANK | rule | 0.08 | - | 9.3 |
| PURSUES BIG PREY | rule | - | 0.08 | 14.2 |
| SUPPORT NARROWED | rule | - | 0.08 | 44.4 |

### Plans: h9-mine-81fb82c-p2

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.0 | 75% | 132 | 99 | 75% |
| Mine | join | 0.6 | 100% | 19 | 0 | 0% |
| Mine | move | 29.0 | 92% | 1651 | 0 | 0% |
| Mine | shoot | 11.7 | 51% | 537 | 459 | 85% |
| Mine | support | 0.3 | 100% | 9 | 0 | 0% |
| Opponent | charge | 3.4 | 71% | 553 | 346 | 63% |
| Opponent | join | 1.1 | 100% | 55 | 0 | 0% |
| Opponent | move | 31.8 | 96% | 1593 | 0 | 0% |
| Opponent | shoot | 6.6 | 66% | 331 | 321 | 97% |
| Opponent | support | 0.3 | 100% | 0 | 0 | - |

### Packages: hunt the guns, h9-mine-81fb82c-p2

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 72 |
| Opponent | 0.3 | 4 | 1 | 100% | 100% | 0% | 2.0 | 127 | 119 | 100% | 35 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 72 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 112 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 30 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 88 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 34 |
| Tomb Kings of Khemri | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Vampire Counts | 1.3 | 4 | 1 | 100% | 100% | 0% | 2.0 | 127 | 119 | 100% | 0 |
| Warriors of Chaos | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 98 |
| Wood Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 19 |

### Battle groups: h9-mine-81fb82c-p2

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 1.6 | 58% | 64% | 0% | - | 0% | 9% | 0% | 91% | 0% |
| Opponent | REDIRECT COUNTER | 2.5 | 7% | 100% | 50% | 100% | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: h9-mine-81fb82c-p2

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 9 | 10 (9) | 0 | 10 | 70 | 56% | 3.5 | 22 (4) | 0 (3) | 0 (2) | 17 (6) | 0 (3) |
| Mine | Character | 51 | 19 (51) | 19 | 0 | 48 | 24% | 2.3 | 29 (26) | 0 (9) | 24 (8) | 25 (27) | 17 (16) |
| Mine | Clean-up | 14 | 41 (14) | 6 | 35 | 48 | 64% | 2.8 | 57 (5) | 0 (4) | 55 (5) | 80 (7) | 0 (7) |
| Mine | Fast Hammer | 4 | 0 (4) | 0 | 0 | 50 | 100% | - | 0 (2) | 0 (2) | - | 0 (1) | 0 (3) |
| Mine | Hammer | 31 | 45 (31) | 18 | 27 | 31 | 32% | 2.9 | 69 (9) | 35 (18) | 23 (4) | 49 (17) | 40 (14) |
| Mine | Holder | 9 | 198 (9) | 71 | 127 | 18 | 78% | 4.0 | 296 (3) | 201 (4) | 0 (1) | 271 (4) | 157 (4) |
| Mine | Shooter | 13 | 72 (13) | 24 | 48 | 45 | 8% | 2.1 | 135 (2) | 47 (8) | 101 (3) | 104 (9) | 6 (4) |
| Mine | War machine | 30 | 12 (30) | 12 | 0 | 32 | 17% | 1.5 | 1 (15) | 34 (6) | 15 (9) | 0 (4) | 15 (26) |
| Mine | Wizard | 3 | 0 (3) | 0 | 0 | 36 | 67% | 5.0 | 0 (1) | 0 (1) | - | - | 0 (2) |
| Opponent | Chaff | 25 | 133 (25) | 0 | 133 | 30 | 64% | 2.3 | 129 (6) | 107 (9) | 161 (10) | 117 (19) | 174 (6) |
| Opponent | Character | 38 | 55 (38) | 55 | 0 | 5 | 39% | 2.3 | 26 (14) | 89 (15) | 54 (7) | 49 (20) | 65 (16) |
| Opponent | Clean-up | 7 | 29 (7) | 14 | 15 | 18 | 43% | 3.8 | 91 (2) | 6 (3) | 0 (2) | 25 (4) | 34 (3) |
| Opponent | Early | 1 | 207 (1) | 207 | 0 | 0 | 0% | 5.0 | - | 207 (1) | - | - | 207 (1) |
| Opponent | Fast | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Fast Hammer | 18 | 44 (18) | 17 | 27 | 28 | 44% | 3.4 | 60 (8) | 37 (9) | 0 (1) | 47 (11) | 39 (7) |
| Opponent | Hammer | 11 | 24 (11) | 0 | 24 | 18 | 36% | 1.9 | 71 (1) | 22 (7) | 8 (3) | 34 (7) | 6 (4) |
| Opponent | Holder | 7 | 42 (7) | 0 | 42 | 8 | 57% | 5.0 | 0 (1) | 62 (5) | 0 (1) | - | 42 (7) |
| Opponent | Shooter | 11 | 104 (11) | 30 | 73 | 57 | 0% | 1.9 | 161 (6) | 67 (4) | 0 (1) | 132 (8) | 50 (3) |
| Opponent | Support | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | War machine | 15 | 46 (15) | 46 | 0 | 38 | 7% | 1.6 | 74 (4) | 42 (10) | 0 (1) | 44 (2) | 46 (13) |
| Opponent | Wizard | 10 | 0 (10) | 0 | 0 | 14 | 40% | 1.7 | 0 (2) | 0 (4) | 0 (2) | 0 (4) | 0 (4) |

### Charged fights: h9-mine-81fb82c-p2

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 28 | 15 | 0.2 | 1.0 | 60 | 0 | +60 | 0 of 1 | 1 of 1 | - | +60 |
| Mine | Chaos Dwarfs | 4 | 166 | 324 | 2.2 | 1.0 | 144 | 78 | +66 | 3 of 9 | 4 of 9 | - | +66 |
| Mine | Dwarfen Mountain Holds | 4 | 217 | 0 | 0.5 | 1.0 | 0 | 30 | -30 | 1 of 2 | 1 of 2 | - | -30 |
| **Mine** | all armies | 12 | 137 | 113 | 1.0 | 1.0 | 113 | 63 | +50 | 4 of 12 | 6 of 12 | - | +50 |
| Opponent | Empire of Man | 3 | 318 | 49 | 0.7 | 1.0 | 73 | 0 | +73 | 0 of 2 | 2 of 2 | - | +73 |
| Opponent | Grand Cathay | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | High Elf Realms | 1 | 470 | 777 | 5.0 | 1.2 | 155 | 0 | +155 | 3 of 5 | 4 of 5 | +138 | +160 |
| Opponent | Ogre Kingdoms | 1 | 120 | 246 | 3.0 | 1.3 | 82 | 11 | +71 | 2 of 3 | 2 of 3 | +186 | +13 |
| Opponent | Tomb Kings of Khemri | 1 | 55 | 550 | 4.0 | 1.0 | 138 | 145 | -8 | 2 of 4 | 1 of 4 | - | -8 |
| Opponent | Vampire Counts | 3 | 0 | 171 | 3.3 | 1.3 | 51 | 8 | +44 | 2 of 10 | 9 of 10 | +101 | +19 |
| Opponent | Warriors of Chaos | 1 | 0 | 1585 | 4.0 | 1.2 | 396 | 0 | +396 | 3 of 4 | 3 of 4 | +795 | +263 |
| Opponent | Wood Elf Realms | 1 | 165 | 185 | 4.0 | 1.0 | 46 | 0 | +46 | 2 of 4 | 4 of 4 | - | +46 |
| **Opponent** | all armies | 12 | 147 | 334 | 2.7 | 1.2 | 125 | 22 | +104 | 14 of 32 | 25 of 32 | +237 | +73 |

### Effective charges: h9-mine-81fb82c-p2

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 1 | 0 | 0 | 0 | 1 (net +60) | 0 | 0 | 0 | 0% (0 of 1) |
| Mine | Chaos Dwarfs | 9 | 5 (net +56) | 0 | 0 | 0 | 1 (net +0) | 2 (net +158) | 1 | 0% (0 of 8) |
| Mine | Dwarfen Mountain Holds | 2 | 0 | 1 (net -60) | 1 (net +0) | 0 | 0 | 0 | 0 | 50% (1 of 2) |
| Opponent | Empire of Man | 2 | 0 | 0 | 0 | 0 | 1 (net +65) | 1 (net +81) | 0 | 0% (0 of 2) |
| Opponent | High Elf Realms | 5 | 1 (net +0) | 0 | 0 | 0 | 1 (net +65) | 3 (net +237) | 0 | 0% (0 of 5) |
| Opponent | Ogre Kingdoms | 3 | 0 | 0 | 0 | 0 | 0 | 1 (net +186) | 2 | 0% (0 of 1) |
| Opponent | Tomb Kings of Khemri | 4 | 1 (net -450) | 0 | 1 (net +0) | 0 | 2 (net +210) | 0 | 0 | 25% (1 of 4) |
| Opponent | Vampire Counts | 10 | 2 (net +0) | 1 (net +95) | 0 | 0 | 5 (net +84) | 1 (net -75) | 1 | 0% (0 of 9) |
| Opponent | Warriors of Chaos | 4 | 1 (net +0) | 0 | 0 | 0 | 1 (net +65) | 2 (net +760) | 0 | 0% (0 of 4) |
| Opponent | Wood Elf Realms | 4 | 1 (net +0) | 0 | 0 | 0 | 0 | 0 | 3 | 0% (0 of 1) |

### Charged fights, damage counted: h9-mine-81fb82c-p2

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 5 | 194 | 250 | +56 | 201 | 140 | +61 | +31.2 |
| Mine | 50-54% | 1 | 60 | 228 | -60 | 57 | 60 | -3 | -5.0 |
| Mine | Effective (55-75%) | 1 | 105 | 236 | +0 | 0 | 0 | +0 | +0.0 |
| Mine | 76-89% | 1 | 52 | 60 | +60 | 60 | 0 | +60 | +115.4 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 232 | 158 | +158 | 158 | 4 | +153 | +66.1 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 339 | 75 | +0 | 0 | 0 | +0 | +0.0 |
| Mine | No odds | 1 | 339 | 369 | +0 | 105 | 0 | +105 | +31.1 |
| Mine | All fights | 12 | 194 | 211 | +50 | 128 | 64 | +64 | +33.1 |
| Opponent | Long shot (under 50%) | 6 | 259 | 368 | -75 | 59 | 119 | -60 | -23.1 |
| Opponent | 50-54% | 1 | 147 | 95 | +95 | 95 | 0 | +95 | +64.6 |
| Opponent | Effective (55-75%) | 1 | 431 | 322 | +0 | 97 | 96 | +1 | +0.2 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 8 | 432 | 207 | +303 | 334 | 20 | +313 | +72.5 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 10 | 418 | 74 | +103 | 108 | 14 | +94 | +22.6 |
| Opponent | No odds | 6 | 70 | 137 | +35 | 70 | 6 | +64 | +90.6 |
| Opponent | All fights | 32 | 318 | 183 | +104 | 147 | 36 | +112 | +35.0 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| h9-mine-81fb82c-p2 | move | 65 | 12 (18%) | 8 (12%) | 5 (8%) | 48 (74%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0108, L0123 |
| Charmed Shield | Opponent | L0224, L0325, L0427 |
| Elixir of Power | Opponent | L0411 |
| Fistful of Laurels | Opponent | L0618 |
| Horn of the Wild Hunt | Opponent | L0633 |
| Invocation of Nehek | Opponent | L0224, L0325, L0427 |
| Ring of Doom | Mine | L0207, L0224 |
| Ring of Doom | Opponent | L0411, L0633 |
| Ring of Jet | Opponent | L0411 |
| Standard of the Fell Warrior | Opponent | L0513 |
| Twice-Blessed Armour | Opponent | L0207 |
| Witch Hunter's Ward | Opponent | L0108, L0207, L0308 |

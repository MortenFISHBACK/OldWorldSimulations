# Doctrine scorecard: h9-mine-81fb82c-p4

### Scorecard: h9-mine-81fb82c-p4

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0115 | 1 | 1 | Mine | no | 4 | - | 0 | 2 | 0 | 0 | 0 | 0 |
| L0115 | 1 | 1 | Opponent | yes | 2 | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L0132 | 6 | 1 | Mine | no | 11 | 3 | 2 | 0 | 0 | 0 | 0 | 0 |
| L0132 | 6 | 1 | Opponent | no | 2 | 3 | 1 | 5 | 0 | 0 | 0 | 0 |
| L0216 | 6 | 1 | Mine | no | 0 | 6 | 1 | 3 | 0 | 0 | 0 | 170 |
| L0216 | 6 | 1 | Opponent | no | 0 | 2 | 2 | 0 | 0 | 0 | 0 | 100 |
| L0232 | 4 | 1 | Mine | no | 3 | 3 | 4 | 2 | 1 | 0 | 0 | 170 |
| L0232 | 4 | 1 | Opponent | no | 0 | 2 | 5 | 1 | 1 | 0 | 0 | 170 |
| L0316 | 4 | 1 | Mine | no | 0 | 2 | 1 | 1 | 0 | 0 | 0 | 140 |
| L0316 | 4 | 1 | Opponent | no | 3 | 3 | 2 | 1 | 1 | 0 | 0 | 0 |
| L0333 | 3 | 1 | Mine | no | 2 | - | 0 | 0 | 0 | 0 | 0 | 340 |
| L0333 | 3 | 1 | Opponent | yes | 2 | 3 | 2 | 5 | 0 | 0 | 0 | 0 |
| L0420 | 6 | 1 | Mine | no | 2 | 2 | 2 | 3 | 0 | 0 | 0 | 310 |
| L0420 | 6 | 1 | Opponent | no | 0 | - | 0 | 5 | 0 | 0 | 0 | 780 |
| **Average** | | | Mine | 0% | 3.1 | 3.2 | 1.4 | 1.6 | 0.1 | 0.0 | 0.0 | 161.4 |
| **Average** | | | Opponent | 29% | 1.3 | 2.5 | 2.1 | 2.6 | 0.3 | 0.0 | 0.0 | 150.0 |

### KPIs: h9-mine-81fb82c-p4

Rules off - Opponent only: HOLDER ASSIGNMENT, QUARTER ODDS, WALK PROMISE, REAL GROUND, RISK ON THE WAY, ONE ROUTE, MARCH WHEELS ONLY, LATE ONLY FROM HERE, WALKS ON ITS ROUTE.

Morten 2026-11-10; 7 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 29% (10 of 34) | 0% (0 of 36) | 14% (10 of 70) |
| Winner chose to follow up after the loser gave ground |  | 75% (9 of 12); on the table 83% | 100% (5 of 5); on the table 100% | 82% (14 of 17); on the table 88% |
| Winner chose to pursue after the loser fell back in good order |  | - | - | - |
| Winner chose to pursue after the loser fled |  | 100% (3 of 3); on the table 100% | 100% (4 of 4); on the table 100% | 100% (7 of 7); on the table 100% |
| Winner chose to follow up or pursue (all three) |  | 80% (12 of 15); on the table 87% | 100% (9 of 9); on the table 100% | 88% (21 of 24); on the table 92% |
| Magic missiles tried each own turn | 50%+ | 40% (51 of 126) | 33% (6 of 18) | 40% (57 of 144) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 53% (51 of 96) | 35% (6 of 17) | 50% (57 of 113) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 75% (3 of 4) | 75% (24 of 32) | 75% (27 of 36) |
| Points that never fought | lower | 45% (6052 of 13595) | 47% (6643 of 13997) | 46% (12695 of 27592) |
|   infantry points that never fought | lower | 61% (2517 of 4124) | 89% (2850 of 3186) | 73% (5367 of 7310) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 57% (26 of 46) | 44% (23 of 52) | 50% (49 of 98) |
| Bound items with a magic missile used (at least once a game) |  | 100% (6 of 6); 2.4 uses a game | 50% (2 of 4); 1.6 uses a game | 80% (8 of 10); 2.0 uses a game |
| Bound items with another spell used |  | 100% (2 of 2); 0.7 uses a game | 0.0 uses a game | 100% (2 of 2); 0.4 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 50% (4 of 8); 0.6 uses a game | 75% (3 of 4); 0.4 uses a game | 58% (7 of 12); 0.5 uses a game |
|   their share of the points of units over 100 pts | lower | 50% (5179 of 10334) | 36% (4422 of 12450) | 42% (9601 of 22784) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 2.6 (24%) | 1.1 (67%) | 3.7 (30%) |
| MARCHED: its unit marched | 3.3 (31%) | 0.4 (25%) | 3.7 (30%) |
| CHARGED: its unit charged | 0.3 (3%) | 0.0 (0%) | 0.3 (2%) |
| IN COMBAT: engaged in combat | 1.3 (12%) | 0.1 (8%) | 1.4 (11%) |
| FLEEING: fleeing | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| GONE: slain | 2.7 (25%) | 0.0 (0%) | 2.7 (22%) |
| OFF THE TABLE: off the table or not arrived | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| STUPIDITY: Stupidity | 0.3 (3%) | 0.0 (0%) | 0.3 (2%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 6.0 | 0.1 | 3.1 | 8.1 | 0.6 |
| not cast | 6.9 | 0.7 | 4.6 | 12.4 | 16.6 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (2%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.0 (0%) | 0.9 (19%) | 3.7 (30%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 3.7 (30%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (2%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.0 (0%) | 0.7 (16%) | 1.4 (11%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.1 (1%) |
| GONE: slain | 1.3 (19%) | 0.0 (0%) | 0.0 (0%) | 2.7 (22%) | 2.4 (15%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.0 (0%) | 0.3 (6%) | 0.3 (2%) | 0.3 (2%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.4 (6%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 5.1 (75%) | 0.7 (100%) | 2.7 (59%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 13.4 (81%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 2.9 a game | 1.0 a game | 1.9 a game |
| stood (cast and not dispelled) | 65% (13 of 20) | 0% (0 of 2) | 59% (13 of 22) |
| the unit moved after it | 85% (11 of 13) | - | 85% (11 of 13) |
| it charged on its next turn | 8% (1 of 13) | - | 8% (1 of 13) |
| the enemy charged it first | 31% (4 of 13) | - | 31% (4 of 13) |
| it fought by the end of its next turn | 8% (1 of 13) | - | 8% (1 of 13) |
| it moved out of a charge the enemy had planned (not charged first) | 8% (1 of 13) | - | 8% (1 of 13) |
| none of these (no charge, no fight, no charge escaped) | 62% (8 of 13) | - | 62% (8 of 13) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 62% (61 of 98) | 48% (57 of 120) | 54% (118 of 218) |
|   cavalry | 67% (4 of 6) | 38% (9 of 24) | 43% (13 of 30) |
|   character | - | 39% (11 of 28) | 39% (11 of 28) |
|   chariot | 50% (18 of 36) | 50% (2 of 4) | 50% (20 of 40) |
|   infantry | 79% (19 of 24) | 56% (23 of 41) | 65% (42 of 65) |
|   war machine | 62% (20 of 32) | 52% (12 of 23) | 58% (32 of 55) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.4 (27%) | 2.9 (32%) | 4.3 (30%) |
| CHARGED: it charged | 0.4 (8%) | 1.4 (16%) | 1.9 (13%) |
| FLEEING: it fled or was fleeing | 0.0 (0%) | 0.1 (2%) | 0.1 (1%) |
| IN COMBAT: it fought this turn or the last | 0.6 (11%) | 0.1 (2%) | 0.7 (5%) |
| MOVED: a war machine that moved | 1.1 (22%) | 1.0 (11%) | 2.1 (15%) |
| NO TARGET IN RANGE | 1.3 (24%) | 2.0 (22%) | 3.3 (23%) |
| ONLY IN COMBAT: the only targets were in combat | 0.0 (0%) | 0.1 (2%) | 0.1 (1%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.4 (8%) | 0.9 (10%) | 1.3 (9%) |
| SHELTERED: the target was sheltered | 0.0 (0%) | 0.1 (2%) | 0.1 (1%) |
| OTHER BAR | 0.0 (0%) | 0.3 (3%) | 0.3 (2%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 2.0 | 0.3 | 86% | 3.5 pts | 7 pts |
| character | 1.7 | 0.3 | 83% | 1.0 pts | 2 pts |
| chariot | 2.9 | 3.7 | 55% | 13.9 pts | 40 pts |
| infantry | 8.1 | 2.0 | 77% | 7.9 pts | 64 pts |
| war machine | 4.6 | 3.9 | 66% | 17.4 pts | 79 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 2.6 | 3.9 | 3.2 |
| Charges that made contact a game | 1.9 | 3.1 | 2.5 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.25 declared, 0.25 contact (4 units) | 0.00 declared, 0.00 contact (2 units) | 0.17 declared, 0.17 contact (6 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 0.00 declared, 0.00 contact (1 units) | 0.00 declared, 0.00 contact (1 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.35 declared, 0.24 contact (49 units) | 0.47 declared, 0.39 contact (57 units) | 0.42 declared, 0.32 contact (106 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 40% (4 of 10) | - | 0% (0 of 1) | 36% (4 of 11) |
| Character in a unit | 80% (8 of 10) | 50% (3 of 6) | - | 69% (11 of 16) |
| Character on its own | 100% (1 of 1) | 62% (5 of 8) | 18% (2 of 11) | 40% (8 of 20) |
| Chariot | 100% (1 of 1) | 67% (4 of 6) | - | 71% (5 of 7) |
| Infantry | 50% (5 of 10) | 20% (3 of 15) | - | 32% (8 of 25) |
| Monster | 50% (3 of 6) | 50% (1 of 2) | - | 50% (4 of 8) |
| Monstrous | 100% (3 of 3) | - | - | 100% (3 of 3) |
| War Machines | 100% (6 of 6) | 0% (0 of 2) | - | 75% (6 of 8) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 75% (9 of 12); on the table 83% | 36% (37 of 102) | 32% | 50% (11 of 22) | 100% (6 of 6); 4.2 uses a game | 100% (2 of 2); 1.2 uses a game | 67% (4 of 6); 1.0 uses a game |
| Chaos Dwarfs | 3 | 100% (3 of 3); on the table 100% | 58% (14 of 24) | 60% | 62% (15 of 24) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |
| High Elf Realms | 1 | 100% (1 of 1); on the table 100% | 17% (1 of 6) | 44% | 29% (2 of 7) | 50% (1 of 2); 5.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 2 | 100% (2 of 2); on the table 100% | - | 47% | 33% (4 of 12) | 0.0 uses a game | 0.0 uses a game | 100% (2 of 2); 1.0 uses a game |
| Skaven | 1 | 100% (2 of 2); on the table 100% | 83% (5 of 6) | 57% | 57% (4 of 7) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Warriors of Chaos | 2 | 100% (3 of 3); on the table 100% | - | 32% | 44% (7 of 16) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 1 | 100% (1 of 1); on the table 100% | 0% (0 of 6) | 75% | 60% (6 of 10) | 50% (1 of 2); 6.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (h9-mine-81fb82c-p4, 7 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 44% (8) | 40% (4) | 43% (12) |
| ...free all their last turn and able to turn (per game) | 0.43 | 0.43 | 0.86 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.57 | 0.14 | 0.71 |
| ...with the charger already in that arc before they moved (per game) | 0.29 | 0.29 | 0.57 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.29 | 0.00 | 0.29 |

### Quality by phase: h9-mine-81fb82c-p4

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 0.9 | 2.1 |
| Strategy | Charge objectives carried out (made contact) | 50% (7 of 14) | 32% (8 of 25) |
| Strategy | Shoot objectives carried out (shot that target) | 34% (23 of 67) | 33% (8 of 24) |
| Strategy | Support requests answered (helper made contact too) | 100% (1 of 1) | 0% (0 of 1) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (1 of 1) | - |
| Strategy | Joined characters whose unit fought | 58% (11 of 19) | 14% (1 of 7) |
| Strategy | Lone characters that fought | 62% (8 of 13) | 79% (11 of 14) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 1.6 | 2.6 |
| Movement | Points that never moved of their own | 161.4 | 150.0 |
| Movement | Fights charged into per game | 1.6 | 3.1 |
| Movement | Charges with odds: long shots (under 50%) | 1 of 9, net +0 | 7 of 20, net +100 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 9 | 3 of 20, net +31 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 9 | 3 of 20, net +49 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 5 of 9, net +16 | 4 of 20, net +120 |
| Shooting | Shots by shooting units (incl. breath weapons) | 5.9 | 8.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 61% (25 of 41) | 43% (26 of 61) |
| Shooting | Points destroyed by shooting units | 22.6 | 0.0 |
| Shooting | War machine shots | 2.9 | 1.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 15% (3 of 20) | 33% (4 of 12) |
| Shooting | Points destroyed by war machines | 15.6 | 15.7 |
| Magic | Magic missiles cast | 4.6 | 0.7 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 53% (17 of 32) | 100% (5 of 5) |
| Magic | Wounds caused by magic missiles | 9.6 | 1.7 |
| Magic | Wounds caused by other spells | 0.3 | - |
| Magic | Points destroyed by magic (all spells) | 139.7 | 12.1 |
| Magic | Augments / hexes / assailments / vortexes cast | 2.4 / 0.0 / 0.4 / 0.0 | 1.9 / 0.0 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 94.0 | 407.6 |
| Combat | Points run down | 69.9 | 33.6 |
| Combat | Net points per charged fight, damage counted | +55 | +74 |
| Combat | Net per 100 charger points, damage counted | +19.1 | +21.7 |
| Combat | First round won (charged fights) | 91% | 68% |
| Combat | Net points per charged fight | -16 | +86 |
| Combat | Net points per supported fight / lone fight | +40 / -29 | - / +86 |
| Combat | Charged fights on a top-3 enemy unit | 5 of 11 | 6 of 22 |
| Game | Points lost | 496.0 | 417.3 |
| Game | VP from objectives | 764.3 | 672.9 |
| Game | Lone holders (player turns) | 3.1 | 1.3 |

- Mine won / drew / lost: 2 / 2 / 3 of 7 ended games (of 7); mean margin (Mine - Opponent) +22 VP
- The side that went first won 2 of 5 games with a winner
- Points traded per game (both sides' losses): 913
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: h9-mine-81fb82c-p4

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.3 | +0.0 | 0.0 | 0.0 | 0.9 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.4 | +46.9 | 0.0 | 7.4 | - | - | - | - |
| ARTILLERY RE-ROLL WEIGHED | 2.4 | +0.0 | 0.0 | 68.6 | - | - | - | - |
| BEST PRIZE | - | - | - | - | 0.6 | -37.6 | 35.3 | 0.0 |
| BLOWS WHERE AIMED | - | - | - | - | 0.4 | -130.9 | 0.0 | 0.0 |
| CANNON PLAN MISSED | 0.4 | +0.0 | 15.6 | 15.7 | 0.4 | +0.0 | 35.9 | 0.0 |
| CANNON PLANNED TARGET | 2.7 | +45.5 | 108.6 | 84.3 | 1.1 | +22.2 | 0.0 | 28.6 |
| CANNON SIGHT KEPT | 0.6 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| CAST JOB | 1.7 | +98.1 | 93.6 | 12.1 | - | - | - | - |
| CASTER AWAY FROM SCREEN | 1.0 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.9 | +67.4 | 19.9 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | 1.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | 0.7 | +27.4 | 0.0 | 12.1 | 1.1 | +46.8 | 0.0 | 31.1 |
| CHAFF PASSED | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| CHARACTER GUNS | - | - | - | - | 0.6 | +0.0 | 0.0 | 0.0 |
| CHARGE LOSSES | 4.6 | -101.6 | 0.0 | 31.7 | 5.0 | -273.4 | 0.0 | 30.6 |
| CHARGE NOT DECLARED | 0.6 | +0.0 | 0.0 | 0.0 | 0.9 | +0.0 | 48.0 | 4.3 |
| CHARGE NOW FIRST | 0.7 | +0.0 | 0.0 | 48.4 | 2.3 | +0.0 | 185.9 | 137.9 |
| CHARGER SLAIN LOST | 0.3 | -10.1 | 0.0 | 0.0 | 0.3 | -0.9 | 48.6 | 79.1 |
| CHEAP HELPER | - | - | - | - | 0.1 | +0.0 | 0.0 | 16.4 |
| CHEAPEST HOLDER | - | - | - | - | 0.6 | -16.7 | 20.0 | 56.9 |
| COMBAT PIVOT | 0.1 | +0.0 | 0.0 | 24.3 | 0.4 | +0.0 | 48.4 | 24.3 |
| CONVEYANCE SEARCH | 2.1 | +305.5 | 0.0 | 0.0 | - | - | - | - |
| COVER ONCE | 7.4 | -805.4 | 0.0 | 68.1 | 3.7 | -141.0 | 0.0 | 0.0 |
| DEPLOY BY FIGURES | 8.3 | +54.0 | 0.0 | 0.0 | 7.9 | +24.4 | 0.0 | 11.3 |
| EDGE GIVE GROUND | - | - | - | - | 0.3 | +9.6 | 20.0 | 0.0 |
| ENGINEER BY LORE | 0.6 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FALL BACK GOOD ORDER | 1.9 | +2.5 | 39.1 | 55.9 | 2.3 | +0.3 | 171.4 | 79.1 |
| FALLBACK BY WORTH | 0.3 | +0.0 | 0.0 | 12.1 | - | - | - | - |
| FALLS SHORT | 5.3 | +76.2 | 0.0 | 19.0 | 20.7 | +292.5 | 0.0 | 321.6 |
| FEATURE BUFFS | 5.4 | +216.1 | 0.0 | 7.4 | 1.1 | +31.7 | 0.0 | 52.4 |
| FIGHT LIFT | - | - | - | - | 0.1 | +0.5 | 48.4 | 0.0 |
| FIGHT TO THE END | 0.9 | +154.4 | 39.1 | 48.4 | 1.7 | +66.0 | 125.7 | 149.0 |
| FIRE IN ORDER | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FIVE ACTION | 44.1 | +4329.0 | 429.7 | 421.3 | 46.1 | +3268.4 | 282.6 | 589.4 |
| FLANK NOT WEIGHED | 7.7 | +0.0 | 0.0 | 56.9 | 4.9 | +0.0 | 0.0 | 93.9 |
| FOLLOW UP WEIGHED | 0.9 | +103.6 | 0.0 | 48.4 | 0.3 | +78.1 | 0.0 | 0.0 |
| FOUR ROUNDS | 2.0 | +382.8 | 39.1 | 55.9 | 3.4 | +379.4 | 234.6 | 181.7 |
| FRIEND CHARGES FIRST | - | - | - | - | 0.1 | -15.6 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 0.9 | -23.0 | 0.0 | 0.0 | - | - | - | - |
| FRIENDS SHOTS CHECKED | - | - | - | - | 0.4 | +19.9 | 0.0 | 43.3 |
| GIVES UP ITS SCREEN | 0.1 | -0.1 | 19.6 | 0.0 | - | - | - | - |
| GROUND FLIERS | 0.1 | +0.2 | 0.0 | 0.0 | - | - | - | - |
| GUN FIGURES | 1.4 | +4.0 | 0.0 | 0.0 | 0.1 | +0.2 | 0.0 | 0.0 |
| GUN MASK | - | - | - | - | 0.9 | +22.2 | 0.0 | 0.0 |
| HARD STAY DROPPED | 2.7 | +0.0 | 0.0 | 0.0 | 0.9 | +0.0 | 0.0 | 0.0 |
| HE SHOOTS OR CHARGES | 1.6 | +0.0 | 0.0 | 47.1 | 2.9 | +0.0 | 0.0 | 35.6 |
| HELPER ALREADY ASKED | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS CHARGE DENIED | 0.1 | +2.8 | 0.0 | 0.0 | - | - | - | - |
| HIS CHARGE LIST | 2.4 | +0.0 | 0.0 | 0.0 | 1.4 | +0.0 | 0.0 | 19.3 |
| HIS LEGAL MOVES | 2.6 | +0.0 | 0.0 | 7.4 | 3.9 | +0.0 | 0.0 | 89.7 |
| HIS MOVE AND SHOT | 1.0 | -24.6 | 0.0 | 0.0 | 1.6 | -61.4 | 0.0 | 16.4 |
| HIS ONE QUARTER | 2.0 | +0.0 | 0.0 | 9.3 | - | - | - | - |
| HIS RANDOM MOVE | 7.1 | +0.0 | 0.0 | 127.1 | 2.6 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 15.7 | +418.3 | 0.0 | 98.4 | 20.9 | +1221.4 | 0.0 | 49.9 |
| HIS TURN DENIED | 0.1 | +0.7 | 0.0 | 0.0 | 2.0 | +83.8 | 153.9 | 149.0 |
| HOLD ODDS | 18.4 | +0.0 | 0.0 | 28.4 | - | - | - | - |
| HOLDER ASSIGNMENT | 15.3 | +1701.1 | 0.0 | 22.9 | - | - | - | - |
| HOLDER AT DEPLOYMENT | - | - | - | - | 1.9 | +281.4 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 0.6 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 1.6 | -32.5 | 39.1 | 55.9 | 3.3 | -212.1 | 242.0 | 177.4 |
| HUNT KEPT | - | - | - | - | 0.3 | +0.0 | 0.0 | 29.7 |
| HUNT RESULT | - | - | - | - | 0.1 | +0.0 | 0.0 | 0.0 |
| HUNT THE GUNS | - | - | - | - | 0.1 | +51.9 | 0.0 | 0.0 |
| IDLE COST | 1.4 | -7.6 | 0.0 | 12.1 | 8.6 | -141.9 | 0.0 | 109.7 |
| KEEP FALLS | 0.1 | +1.0 | 0.0 | 0.0 | - | - | - | - |
| LANE BY FIGURES | 0.3 | +7.7 | 0.0 | 0.0 | 1.0 | +29.8 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 2.3 | +0.0 | 115.6 | 25.0 | 4.7 | +0.0 | 9.3 | 111.3 |
| LONE WIZARD KEPT IN | 1.4 | +92.8 | 0.0 | 0.0 | 0.4 | +27.4 | 0.0 | 0.0 |
| LONG SHOT | 0.1 | +0.1 | 0.0 | 0.0 | 0.1 | -10.1 | 20.0 | 0.0 |
| MAKE SURE TOGETHER | - | - | - | - | 0.3 | +0.5 | 0.0 | 0.0 |
| MANOEUVRE | 1.1 | +11.3 | 0.0 | 0.0 | 0.7 | +12.1 | 0.0 | 30.6 |
| MARCH AT ESCAPER | 0.4 | +61.2 | 0.0 | 0.0 | - | - | - | - |
| MARCH BY THE SUM | 0.6 | +45.7 | 0.0 | 0.0 | 0.1 | +0.6 | 0.0 | 28.4 |
| MARCH CHECK | 1.3 | +88.4 | 0.0 | 0.0 | 0.7 | +44.1 | 0.0 | 28.4 |
| MARCH OVER CASTS | 0.6 | -1.1 | 0.0 | 0.0 | 0.1 | +31.2 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 0.9 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MAX FOR POSITIONING | 8.0 | +110.4 | 0.0 | 27.0 | 5.3 | +35.1 | 0.0 | 95.4 |
| MISSILES IN THE MOVE | 6.7 | +532.3 | 0.0 | 35.9 | 2.4 | +39.5 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 7.6 | +338.1 | 0.0 | 35.9 | 3.0 | +27.1 | 0.0 | 28.4 |
| MOVE SPELL IN RANGE | 0.7 | +39.8 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL NOT WORTH | - | - | - | - | 0.1 | -0.0 | 0.0 | 0.0 |
| MOVE SPELL OUT OF RANGE | 2.3 | -34.9 | 0.0 | 0.0 | 0.4 | -27.6 | 0.0 | 0.0 |
| MOVE SPELL SPOT | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 3.0 | +344.8 | 0.0 | 55.9 | 3.4 | +608.3 | 0.0 | 69.9 |
| MOVES UNITS SPELL | 0.3 | +15.7 | 0.0 | 0.0 | 0.1 | +1.0 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 4.9 | +221.6 | 0.0 | 0.0 | 6.1 | +283.1 | 0.0 | 30.6 |
| NEEDED THERE | - | - | - | - | 0.1 | +14.3 | 7.4 | 0.0 |
| NEXT CHARGE BY LIST | 5.1 | -138.0 | 34.7 | 63.7 | 4.9 | -242.3 | 0.0 | 86.3 |
| NEXT OBJECTIVE NEARER | 0.1 | -0.3 | 0.0 | 9.3 | 12.1 | -706.3 | 12.1 | 141.7 |
| NO DOUBLE ROUNDS | 1.7 | -119.6 | 39.1 | 55.9 | 3.1 | -109.0 | 234.6 | 177.4 |
| NOT TURNED | 0.3 | +0.0 | 0.0 | 12.1 | - | - | - | - |
| NOT WORTH A CAST | 0.4 | -0.6 | 0.0 | 0.0 | 1.1 | -0.9 | 0.0 | 0.0 |
| OFF BEST | 0.3 | -12.6 | 0.0 | 0.0 | 0.7 | -6.5 | 0.0 | 15.6 |
| ONE CHARGE A CHARGER | 5.1 | +0.0 | 0.0 | 36.3 | 2.7 | +0.0 | 0.0 | 8.6 |
| ONE FIGHT FORMULA | 5.1 | -85.2 | 0.0 | 55.9 | 4.6 | -135.8 | 0.0 | 16.4 |
| ONE OBJECTIVE FORMULA | 6.6 | +116.9 | 0.0 | 13.6 | 3.9 | +7.7 | 0.0 | 106.0 |
| ONE ROUTE | 0.9 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ONE TARGET A SHOOTER | 11.3 | +233.6 | 0.0 | 86.3 | 19.9 | +637.2 | 0.0 | 264.7 |
| OPENS A LANE | 0.4 | +2.5 | 0.0 | 0.0 | 0.1 | +3.2 | 12.1 | 0.0 |
| OPENS UP | - | - | - | - | 0.1 | +2.9 | 0.0 | 0.0 |
| OVERRUNS AWAY | 0.3 | +3.7 | 19.6 | 0.0 | 0.4 | +56.9 | 53.6 | 0.0 |
| PATHS CROSS | 2.4 | +74.6 | 0.0 | 0.0 | 4.7 | +200.7 | 0.0 | 131.9 |
| PERIAPT WORTH | - | - | - | - | 0.1 | +7.8 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.1 | -2.7 | 0.0 | 7.4 | 0.1 | -0.5 | 0.0 | 4.3 |
| PLAN RESULT | 38.3 | +711.2 | 340.3 | 595.4 | 40.9 | +231.2 | 113.0 | 668.6 |
| PURSUES ON | 0.1 | +0.7 | 0.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | 7.0 | +928.5 | 70.3 | 52.0 | - | - | - | - |
| RANDOM MOVE BY FIGURES | 0.6 | +34.6 | 0.0 | 72.9 | 4.6 | +48.3 | 0.0 | 0.0 |
| REAL GROUND | 0.9 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| REDIRECT BY WHAT IT STOPS | 0.3 | -3.0 | 0.0 | 12.1 | 0.3 | -11.9 | 0.0 | 15.6 |
| REDIRECT COUNTER | 2.7 | +233.7 | 0.0 | 0.0 | 4.6 | +220.7 | 0.0 | 91.7 |
| REDIRECT WEIGHED | - | - | - | - | 0.6 | -37.6 | 35.3 | 0.0 |
| REFORMS TO MEET IT | 0.3 | -9.1 | 0.0 | 0.0 | 0.9 | -82.3 | 0.0 | 0.0 |
| REFUSING RETIRES | 0.4 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| RESERVE FALL BACK | - | - | - | - | 0.4 | +11.1 | 0.0 | 11.4 |
| RISK BY ARC | 1.4 | +7.7 | 39.1 | 55.9 | 2.0 | -24.3 | 190.9 | 111.9 |
| RISK BY HIS FIGURE | 14.3 | -91.8 | 0.0 | 142.1 | 16.7 | -173.3 | 0.0 | 123.0 |
| RISK ON THE WAY | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| RUN DOWN | 1.1 | -10.1 | 39.1 | 7.4 | 2.6 | -21.8 | 186.0 | 107.6 |
| SAME CHARGE LATER | 0.1 | -9.4 | 0.0 | 0.0 | 0.1 | -0.8 | 0.0 | 0.0 |
| SCOUT SPOT | 0.1 | -0.0 | 0.0 | 0.0 | - | - | - | - |
| SCOUT WAITS | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SEARCH SPOT | 5.3 | +201.5 | 0.0 | 13.6 | 8.4 | +410.9 | 0.0 | 23.9 |
| SELF MOVE SPELL | - | - | - | - | 0.9 | +48.0 | 0.0 | 0.0 |
| SET UP TOGETHER | 0.1 | +0.8 | 0.0 | 0.0 | 0.6 | +2.6 | 0.0 | 11.4 |
| SET-UP ANY TARGET | 0.7 | +29.7 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | - | - | - | - | 0.3 | +0.3 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 2.1 | +100.3 | 95.6 | 12.1 | 0.4 | +7.7 | 0.0 | 28.4 |
| SHOT OR CHARGE | 0.3 | -1.7 | 0.0 | 0.0 | 0.3 | -3.4 | 23.7 | 0.0 |
| SHOT RISK POINTS | 7.4 | +61.1 | 0.0 | 27.0 | 15.0 | +234.8 | 0.0 | 147.9 |
| SHOTS IN THE MOVE | 9.9 | +297.9 | 0.0 | 145.0 | 10.7 | +265.2 | 0.0 | 67.9 |
| SPELL SETS UP CHARGE | 0.7 | +29.7 | 0.0 | 0.0 | - | - | - | - |
| SPELL WORTH | 0.9 | +13.8 | 0.0 | 50.7 | 2.7 | +62.4 | 48.4 | 0.0 |
| SPELLS IN THE FIGHT | 0.1 | +1.0 | 0.0 | 0.0 | 0.1 | -1.7 | 0.0 | 0.0 |
| STAND AND SHOOT | 0.1 | -0.3 | 0.0 | 0.0 | 0.1 | -1.1 | 9.3 | 0.0 |
| STANDS FOR A REASON | - | - | - | - | 0.6 | +0.0 | 0.0 | 28.4 |
| STANDS STILL | 17.9 | +0.0 | 390.6 | 184.3 | 10.0 | +0.0 | 48.0 | 66.3 |
| STAY WORTH | 9.9 | +71.2 | 112.1 | 0.0 | 10.7 | +79.9 | 36.4 | 166.3 |
| STOPS | - | - | - | - | 0.1 | +8.4 | 0.0 | 0.0 |
| STUCK PIVOT | - | - | - | - | 0.9 | +0.0 | 0.0 | 0.0 |
| SUPPORT NARROWED | 1.1 | +0.0 | 49.3 | 48.4 | 1.4 | +0.0 | 52.9 | 142.1 |
| SURE REACH TOGETHER | 0.1 | +0.2 | 0.0 | 48.4 | 0.1 | +0.1 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 2.9 | +0.0 | 0.0 | 0.0 | 4.9 | +0.0 | 0.0 | 62.0 |
| THE PROMISE ADDS | 0.3 | -8.4 | 0.0 | 0.0 | - | - | - | - |
| THE PROMISED MOVE | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| TIED UP BY THE SUM | 0.1 | +5.3 | 19.6 | 0.0 | 0.7 | +80.9 | 80.1 | 28.4 |
| TIME ON OUR SIDE | 29.9 | +490.0 | 0.0 | 96.9 | 5.9 | +112.8 | 0.0 | 11.4 |
| WAITS AGAIN | 1.6 | +0.0 | 0.0 | 7.4 | 0.7 | +0.0 | 0.0 | 69.9 |
| WALKS ON ITS ROUTE | 0.3 | -6.3 | 0.0 | 0.0 | - | - | - | - |
| WAR ENGINE CHARGES | 0.3 | +33.4 | 0.0 | 0.0 | - | - | - | - |
| WAR ENGINE JOBS | 1.1 | +0.0 | 70.1 | 0.0 | - | - | - | - |
| WHO HITS BACK | - | - | - | - | 0.3 | +17.8 | 0.0 | 0.0 |
| WHOLE FIGHT | - | - | - | - | 0.4 | +1.9 | 7.4 | 4.3 |
| WHOLE FIGHT GAIN | 0.3 | +53.4 | 0.0 | 0.0 | - | - | - | - |
| WIDER SPREAD | 1.7 | -8.0 | 39.1 | 55.9 | 1.7 | -14.1 | 141.0 | 79.1 |
| WOUNDS ON THE RANKS | 2.3 | +75.6 | 0.0 | 0.0 | - | - | - | - |

### Rule changes: h9-mine-81fb82c-p4

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HOLDER ASSIGNMENT | 107 | 107 | 98 | 14.00 | +5276 | +53.8 |
| SEARCH SPOT | 96 | 96 | 92 | 13.14 | +4288 | +46.6 |
| HIS SHOT LIST | 256 | 256 | 76 | 10.86 | +1804 | +23.7 |
| DEPLOY BY FIGURES | 113 | 113 | 73 | 10.43 | +995 | +13.6 |
| FIVE ACTION | 632 | 632 | 70 | 10.00 | +2014 | +28.8 |
| ONE TARGET A SHOOTER | 218 | 218 | 51 | 7.29 | +504 | +9.9 |
| PATHS CROSS | 50 | 50 | 50 | 7.14 | +1927 | +38.5 |
| LEGAL CHARGES ONLY | 49 | 49 | 49 | 7.00 | +0 | +0.0 |
| TIME ON OUR SIDE | 250 | 212 | 45 | 6.43 | +195 | +4.3 |
| SHOT RISK POINTS | 157 | 157 | 29 | 4.14 | +1481 | +51.1 |
| MOVE TO CHARGE COMPUTED | 45 | 45 | 28 | 4.00 | +2382 | +85.1 |
| RANDOM MOVE BY FIGURES | 36 | 36 | 27 | 3.86 | +580 | +21.5 |
| HARD STAY DROPPED | 25 | 25 | 25 | 3.57 | +0 | +0.0 |
| FOUR ROUNDS | 38 | 38 | 22 | 3.14 | +1796 | +81.6 |
| COVER ONCE | 78 | 54 | 21 | 3.00 | +283 | +13.5 |
| REDIRECT COUNTER | 51 | 42 | 20 | 2.86 | +1392 | +69.6 |
| MISSILES IN THE MOVE | 64 | 39 | 18 | 2.57 | +1159 | +64.4 |
| ARTILLERY RE-ROLL WEIGHED | 17 | 17 | 17 | 2.43 | +0 | +0.0 |
| NEXT OBJECTIVE NEARER | 86 | 86 | 17 | 2.43 | +141 | +8.3 |
| LONE WIZARD KEPT IN | 13 | 13 | 13 | 1.86 | +841 | +64.7 |
| MAX FOR POSITIONING | 93 | 90 | 13 | 1.86 | +48 | +3.7 |
| FALLS SHORT | 182 | 153 | 12 | 1.71 | +3 | +0.3 |
| SHOTS IN THE MOVE | 144 | 126 | 12 | 1.71 | +162 | +13.5 |
| CHARGE NOT DECLARED | 10 | 10 | 10 | 1.43 | -2716 | -271.6 |
| FEATURE BUFFS | 46 | 46 | 10 | 1.43 | +390 | +39.0 |
| CANNON SIGHT KEPT | 9 | 9 | 9 | 1.29 | +0 | +0.0 |
| LANE BY FIGURES | 9 | 9 | 9 | 1.29 | +263 | +29.2 |
| SHOOTS FROM THE BEST SPOT | 18 | 18 | 9 | 1.29 | +121 | +13.5 |
| ADVANCE LANE KEPT | 8 | 8 | 8 | 1.14 | +0 | +0.0 |
| CANNON PLANNED TARGET | 27 | 27 | 8 | 1.14 | -71 | -8.8 |
| CASTER AWAY FROM SCREEN | 8 | 8 | 8 | 1.14 | +0 | +0.0 |
| CHAFF IN THE MOVE | 13 | 13 | 8 | 1.14 | +89 | +11.2 |
| FOLLOW UP WEIGHED | 8 | 8 | 8 | 1.14 | +1272 | +158.9 |
| HOLDS AMBUSHERS | 8 | 8 | 8 | 1.14 | +0 | +0.0 |
| NEXT CHARGE BY LIST | 70 | 70 | 8 | 1.14 | +173 | +21.6 |
| RISK BY HIS FIGURE | 217 | 217 | 8 | 1.14 | +226 | +28.2 |
| MANOEUVRE | 13 | 13 | 7 | 1.00 | +168 | +24.0 |
| MARCH CHECK | 14 | 14 | 7 | 1.00 | +119 | +17.1 |
| NEARER NOT NEEDED | 77 | 70 | 7 | 1.00 | +310 | +44.2 |
| OFF BEST | 7 | 7 | 7 | 1.00 | -134 | -19.1 |
| QUARTER ODDS | 49 | 49 | 7 | 1.00 | +925 | +132.2 |
| RISK BY ARC | 24 | 24 | 7 | 1.00 | +172 | +24.6 |
| IDLE COST | 70 | 50 | 6 | 0.86 | +79 | +13.2 |
| MISSILES NEXT TURN | 74 | 48 | 6 | 0.86 | +28 | +4.6 |
| STUCK PIVOT | 6 | 6 | 6 | 0.86 | +0 | +0.0 |
| CHAFF PASSED | 5 | 5 | 5 | 0.71 | +0 | +0.0 |
| HOLDER AT DEPLOYMENT | 13 | 13 | 5 | 0.71 | +167 | +33.4 |
| MARCH BY THE SUM | 5 | 5 | 5 | 0.71 | +324 | +64.8 |
| TIED UP BY THE SUM | 6 | 6 | 5 | 0.71 | +174 | +34.8 |
| WOUNDS ON THE RANKS | 16 | 16 | 5 | 0.71 | +133 | +26.5 |
| BEST PRIZE | 4 | 4 | 4 | 0.57 | -278 | -69.4 |
| CAST JOB | 12 | 12 | 4 | 0.57 | +20 | +4.9 |
| CHARGE LOSSES | 67 | 67 | 4 | 0.57 | +106 | +26.5 |
| COMBAT PIVOT | 4 | 4 | 4 | 0.57 | +0 | +0.0 |
| REDIRECT WEIGHED | 4 | 4 | 4 | 0.57 | +642 | +160.5 |
| AFTERMATH IN POINTS | 3 | 3 | 3 | 0.43 | +328 | +109.4 |
| CASTING BLOCK | 6 | 6 | 3 | 0.43 | +85 | +28.4 |
| CHARGE NOW FIRST | 21 | 21 | 3 | 0.43 | -162 | -54.0 |
| FIGHT TO THE END | 18 | 18 | 3 | 0.43 | +231 | +77.1 |
| FRIENDS SHOTS CHECKED | 3 | 3 | 3 | 0.43 | +139 | +46.4 |
| HIS MOVE AND SHOT | 18 | 18 | 3 | 0.43 | +51 | +16.9 |
| MOVES UNITS SPELL | 3 | 3 | 3 | 0.43 | +118 | +39.2 |
| ONE FIGHT FORMULA | 68 | 31 | 3 | 0.43 | +6 | +2.0 |
| ONE OBJECTIVE FORMULA | 73 | 59 | 3 | 0.43 | +21 | +6.9 |
| RESERVE FALL BACK | 3 | 3 | 3 | 0.43 | +78 | +26.0 |
| STAY WORTH | 144 | 132 | 3 | 0.43 | +55 | +18.4 |
| HIS TURN DENIED | 15 | 15 | 2 | 0.29 | +39 | +19.3 |
| HONEST WORTH | 34 | 34 | 2 | 0.29 | +23 | +11.7 |
| OVERRUNS AWAY | 5 | 5 | 2 | 0.29 | +192 | +95.9 |
| PIVOT GUARDS FLANK | 2 | 2 | 2 | 0.29 | -23 | -11.4 |
| SHOOTERS IN TWO RANKS | 2 | 2 | 2 | 0.29 | +2 | +1.0 |
| SUPPORT NARROWED | 18 | 18 | 2 | 0.29 | -8 | -3.8 |
| WALKS ON ITS ROUTE | 2 | 2 | 2 | 0.29 | -44 | -22.1 |
| WAR ENGINE JOBS | 8 | 8 | 2 | 0.29 | -59 | -29.5 |
| WHO HITS BACK | 2 | 2 | 2 | 0.29 | +114 | +56.9 |
| EDGE GIVE GROUND | 2 | 2 | 1 | 0.14 | +1 | +1.0 |
| FALL BACK GOOD ORDER | 29 | 29 | 1 | 0.14 | +1 | +1.0 |
| FIRE IN ORDER | 1 | 1 | 1 | 0.14 | +0 | +0.0 |
| KEEP FALLS | 1 | 1 | 1 | 0.14 | +10 | +10.5 |
| MOVE SPELL IN RANGE | 5 | 1 | 1 | 0.14 | +41 | +41.2 |
| NEEDED THERE | 1 | 1 | 1 | 0.14 | +0 | +0.0 |
| NO DOUBLE ROUNDS | 34 | 34 | 1 | 0.14 | +12 | +11.8 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.14 | +54 | +54.4 |
| PURSUES ON | 1 | 1 | 1 | 0.14 | +5 | +5.0 |
| REFUSING RETIRES | 3 | 3 | 1 | 0.14 | +0 | +0.0 |
| SCOUT WAITS | 1 | 1 | 1 | 0.14 | +0 | +0.0 |
| STOPS | 1 | 1 | 1 | 0.14 | +35 | +35.4 |
| SURE REACH TOGETHER | 2 | 2 | 1 | 0.14 | +0 | +0.0 |
| WAR ENGINE CHARGES | 2 | 2 | 1 | 0.14 | +80 | +79.8 |
| WHOLE FIGHT GAIN | 2 | 2 | 1 | 0.14 | +220 | +219.9 |
| BLOWS WHERE AIMED | 3 | 3 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 6 | 6 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 14 | trace | - | - | - | - |
| CHARACTER GUNS | 4 | 4 | 0 | 0.00 | - | - |
| CHARGER SLAIN LOST | 4 | 4 | 0 | 0.00 | - | - |
| CHEAP HELPER | 1 | not checked | - | - | - | - |
| CHEAPEST HOLDER | 4 | 4 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 15 | not checked | - | - | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FALLBACK BY WORTH | 2 | 2 | 0 | 0.00 | - | - |
| FIGHT LIFT | 1 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 88 | not checked | - | - | - | - |
| FRIEND CHARGES FIRST | 1 | 1 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 6 | 6 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 1 | 1 | 0 | 0.00 | - | - |
| GROUND FLIERS | 1 | not checked | - | - | - | - |
| GUN FIGURES | 11 | not checked | - | - | - | - |
| GUN MASK | 6 | 6 | 0 | 0.00 | - | - |
| HE SHOOTS OR CHARGES | 31 | 31 | 0 | 0.00 | - | - |
| HELPER ALREADY ASKED | 1 | not checked | - | - | - | - |
| HIS CHARGE DENIED | 1 | 1 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 27 | 27 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 45 | 45 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 14 | 14 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 68 | 68 | 0 | 0.00 | - | - |
| HOLD ODDS | 129 | 129 | 0 | 0.00 | - | - |
| HUNT KEPT | 2 | trace | - | - | - | - |
| HUNT RESULT | 1 | trace | - | - | - | - |
| HUNT THE GUNS | 1 | trace | - | - | - | - |
| LONG SHOT | 2 | 2 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 2 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 3 | trace | - | - | - | - |
| MARCH OVER CASTS | 5 | 5 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 6 | 6 | 0 | 0.00 | - | - |
| MOVE SPELL NOT WORTH | 1 | not checked | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 19 | trace | - | - | - | - |
| MOVE SPELL SPOT | 9 | not checked | - | - | - | - |
| NOT TURNED | 2 | 2 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 11 | not checked | - | - | - | - |
| ONE CHARGE A CHARGER | 55 | 55 | 0 | 0.00 | - | - |
| ONE ROUTE | 6 | 6 | 0 | 0.00 | - | - |
| OPENS A LANE | 4 | 2 | 0 | 0.00 | - | - |
| OPENS UP | 1 | 1 | 0 | 0.00 | - | - |
| PLAN RESULT | 554 | trace | - | - | - | - |
| REAL GROUND | 6 | 6 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 4 | 4 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 8 | 8 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 2 | 2 | 0 | 0.00 | - | - |
| RUN DOWN | 26 | 26 | 0 | 0.00 | - | - |
| SAME CHARGE LATER | 2 | 2 | 0 | 0.00 | - | - |
| SCOUT SPOT | 1 | 1 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 6 | not checked | - | - | - | - |
| SET UP TOGETHER | 5 | 4 | 0 | 0.00 | - | - |
| SET-UP ANY TARGET | 5 | not checked | - | - | - | - |
| SHOT OR CHARGE | 4 | 4 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 5 | not checked | - | - | - | - |
| SPELL WORTH | 25 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 2 | 2 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 4 | 4 | 0 | 0.00 | - | - |
| STANDS STILL | 195 | 195 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 54 | not checked | - | - | - | - |
| THE PROMISE ADDS | 2 | 2 | 0 | 0.00 | - | - |
| THE PROMISED MOVE | 9 | not checked | - | - | - | - |
| WAITS AGAIN | 16 | 16 | 0 | 0.00 | - | - |
| WHOLE FIGHT | 3 | 3 | 0 | 0.00 | - | - |
| WIDER SPREAD | 24 | 24 | 0 | 0.00 | - | - |

### Off best figure: h9-mine-81fb82c-p4

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| HOLDER ASSIGNMENT | rule | 1.86 | - | 16.6 |
| CHARGE NOT DECLARED | rule | 0.57 | 0.86 | 271.6 |
| BEST PRIZE | rule | - | 0.57 | 69.4 |
| JOB FIRST | gate | - | 0.43 | 14.2 |
| PATHS CROSS | rule | 0.29 | 0.14 | 4.8 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.29 | - | 44.2 |
| CHARGE NOW FIRST | rule | 0.14 | 0.14 | 80.9 |
| PIVOT GUARDS FLANK | rule | 0.14 | 0.14 | 11.4 |
| SUPPORT NARROWED | rule | 0.29 | - | 3.8 |
| WAR ENGINE JOBS | rule | 0.29 | - | 29.5 |
| AFTERMATH BAND | gate | - | 0.14 | 2.1 |
| CANNON PLANNED TARGET | rule | - | 0.14 | 70.8 |
| FIGHT ORDER BAND | gate | - | 0.14 | 0.7 |
| REDIRECT WEIGHED | rule | - | 0.14 | 23.8 |
| WALKS ON ITS ROUTE | rule | 0.14 | - | 44.2 |

### Plans: h9-mine-81fb82c-p4

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.1 | 25% | 247 | 44 | 18% |
| Mine | move | 28.0 | 94% | 2565 | 0 | 0% |
| Mine | shoot | 8.9 | 58% | 692 | 668 | 96% |
| Mine | support | 0.3 | 50% | 0 | 0 | - |
| Opponent | charge | 2.7 | 53% | 596 | 172 | 29% |
| Opponent | join | 0.6 | 100% | 33 | 0 | 0% |
| Opponent | move | 34.4 | 94% | 1859 | 0 | 0% |
| Opponent | shoot | 3.0 | 33% | 144 | 59 | 41% |
| Opponent | support | 0.1 | 100% | 0 | 0 | - |

### Packages: hunt the guns, h9-mine-81fb82c-p4

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Opponent | 0.1 | 1 | 0 | 100% | 0% | 0% | - | 363 | 0 | 0% | 46 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 55 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Warriors of Chaos | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Wood Elf Realms | 1.0 | 1 | 0 | 100% | 0% | 0% | - | 363 | 0 | 0% | 213 |

### Battle groups: h9-mine-81fb82c-p4

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 2.7 | 16% | 67% | 0% | - | 33% | 0% | 0% | 33% | 33% |
| Opponent | REDIRECT COUNTER | 4.6 | 31% | 80% | 20% | 0% | 25% | 0% | 0% | 75% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: h9-mine-81fb82c-p4

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 4 | 0 (4) | 0 | 0 | 65 | 50% | 3.0 | - | 0 (3) | 0 (1) | 0 (3) | 0 (1) |
| Mine | Character | 26 | 20 (26) | 20 | 0 | 41 | 19% | 2.2 | 26 (8) | 25 (9) | 28 (4) | 43 (7) | 20 (14) |
| Mine | Clean-up | 4 | 56 (4) | 0 | 56 | 22 | 100% | - | 14 (2) | 100 (2) | - | 56 (4) | - |
| Mine | Fast Hammer | 10 | 21 (10) | 21 | 0 | 37 | 40% | 4.5 | 0 (1) | 0 (5) | 40 (4) | 27 (8) | 0 (2) |
| Mine | Hammer | 19 | 35 (19) | 18 | 17 | 9 | 32% | 2.4 | 74 (6) | 23 (9) | 12 (4) | 45 (12) | 18 (7) |
| Mine | Holder | 7 | 125 (7) | 0 | 125 | 0 | 71% | 5.5 | 148 (2) | 131 (3) | 87 (2) | 113 (5) | 148 (2) |
| Mine | Shooter | 5 | 223 (5) | 37 | 185 | 17 | 0% | 2.2 | - | 223 (5) | - | 136 (3) | 384 (2) |
| Mine | War machine | 8 | 27 (8) | 27 | 0 | 71 | 0% | 1.2 | 27 (8) | - | - | 0 (2) | 34 (6) |
| Mine | Wizard | 6 | 0 (6) | 0 | 0 | 15 | 50% | 4.3 | 0 (5) | 0 (1) | - | 0 (1) | 0 (5) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 0% | 6.0 | 0 (1) | - | - | - | 0 (1) |
| Opponent | Chaff | 13 | 14 (13) | 0 | 14 | 60 | 46% | 3.9 | 0 (6) | 33 (3) | 19 (4) | 16 (11) | 0 (2) |
| Opponent | Character | 17 | 46 (17) | 46 | 0 | 12 | 18% | 1.9 | 44 (2) | 22 (7) | 63 (8) | 49 (10) | 41 (7) |
| Opponent | Clean-up | 5 | 51 (5) | 0 | 51 | 8 | 80% | 2.0 | 0 (1) | 53 (3) | 61 (1) | 52 (3) | 49 (2) |
| Opponent | Fast Hammer | 8 | 50 (8) | 5 | 45 | 59 | 25% | 3.2 | 21 (3) | 197 (2) | 0 (3) | 60 (6) | 0 (2) |
| Opponent | Hammer | 11 | 38 (11) | 34 | 4 | 8 | 45% | 3.7 | 18 (1) | 51 (7) | 26 (3) | 47 (6) | 26 (5) |
| Opponent | Holder | 6 | 71 (6) | 0 | 71 | 47 | 83% | 6.0 | 11 (2) | 205 (2) | 0 (2) | 71 (6) | - |
| Opponent | Shooter | 7 | 82 (7) | 9 | 73 | 14 | 29% | 1.8 | 75 (2) | 132 (2) | 0 (3) | 50 (4) | 127 (3) |
| Opponent | Support | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | 0 (1) | - | - | - | 0 (1) |
| Opponent | War machine | 4 | 0 (4) | 0 | 0 | 25 | 0% | 3.0 | 0 (2) | 0 (1) | 0 (1) | - | 0 (4) |
| Opponent | Wizard | 4 | 0 (4) | 0 | 0 | 0 | 25% | 2.0 | 0 (1) | 0 (1) | 0 (2) | 0 (1) | 0 (3) |

### Charged fights: h9-mine-81fb82c-p4

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 178 | 34 | 1.8 | 1.1 | 20 | 8 | +12 | 2 of 7 | 6 of 7 | +0 | +14 |
| Mine | Chaos Dwarfs | 3 | 178 | 27 | 1.3 | 1.2 | 20 | 85 | -65 | 3 of 4 | 4 of 4 | +80 | -113 |
| **Mine** | all armies | 7 | 178 | 31 | 1.6 | 1.2 | 20 | 36 | -16 | 5 of 11 | 10 of 11 | +40 | -29 |
| Opponent | High Elf Realms | 1 | 0 | 420 | 4.0 | 1.0 | 105 | 0 | +105 | 2 of 4 | 2 of 4 | - | +105 |
| Opponent | Kingdom of Bretonnia | 2 | 55 | 434 | 3.5 | 1.0 | 124 | 0 | +124 | 0 of 7 | 7 of 7 | - | +124 |
| Opponent | Skaven | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Warriors of Chaos | 2 | 0 | 636 | 4.0 | 1.0 | 159 | 103 | +56 | 4 of 8 | 4 of 8 | - | +56 |
| Opponent | Wood Elf Realms | 1 | 85 | 250 | 3.0 | 1.0 | 83 | 35 | +49 | 0 of 3 | 2 of 3 | - | +49 |
| **Opponent** | all armies | 7 | 28 | 402 | 3.1 | 1.0 | 128 | 42 | +86 | 6 of 22 | 15 of 22 | - | +86 |

### Effective charges: h9-mine-81fb82c-p4

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 7 | 1 (net +0) | 0 | 0 | 2 (net -28) | 0 | 2 (net +0) | 2 | 0% (0 of 5) |
| Mine | Chaos Dwarfs | 4 | 0 | 0 | 0 | 1 (net -339) | 0 | 3 (net +27) | 0 | 0% (0 of 4) |
| Opponent | High Elf Realms | 4 | 1 (net +355) | 0 | 1 (net +0) | 0 | 2 (net +32) | 0 | 0 | 25% (1 of 4) |
| Opponent | Kingdom of Bretonnia | 7 | 1 (net +85) | 0 | 1 (net +230) | 2 (net +125) | 1 (net +81) | 1 (net +170) | 1 | 17% (1 of 6) |
| Opponent | Warriors of Chaos | 8 | 4 (net +90) | 0 | 1 (net -137) | 1 (net +52) | 0 | 2 (net +85) | 0 | 12% (1 of 8) |
| Opponent | Wood Elf Realms | 3 | 1 (net -104) | 0 | 0 | 0 | 0 | 1 (net +140) | 1 | 0% (0 of 2) |

### Charged fights, damage counted: h9-mine-81fb82c-p4

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 1 | 84 | 80 | +0 | 40 | 0 | +40 | +47.6 |
| Mine | 76-89% | 3 | 149 | 161 | -131 | 86 | 131 | -46 | -30.6 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 5 | 370 | 324 | +16 | 131 | 18 | +113 | +30.4 |
| Mine | No odds | 2 | 386 | 154 | +68 | 68 | 0 | +68 | +17.7 |
| Mine | All fights | 11 | 287 | 226 | -16 | 99 | 44 | +55 | +19.1 |
| Opponent | Long shot (under 50%) | 7 | 339 | 279 | +100 | 261 | 148 | +112 | +33.1 |
| Opponent | Effective (55-75%) | 3 | 299 | 212 | +31 | 79 | 134 | -55 | -18.4 |
| Opponent | 76-89% | 3 | 382 | 101 | +101 | 101 | 17 | +84 | +22.0 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 4 | 354 | 141 | +120 | 130 | 21 | +109 | +30.9 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 3 | 334 | 67 | +49 | 63 | 9 | +54 | +16.1 |
| Opponent | No odds | 2 | 340 | 81 | +81 | 81 | 0 | +81 | +23.8 |
| Opponent | All fights | 22 | 342 | 174 | +86 | 147 | 73 | +74 | +21.7 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| h9-mine-81fb82c-p4 | move | 46 | 7 (15%) | 6 (13%) | 8 (17%) | 31 (67%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0115, L0132 |
| Horn of the Wild Hunt | Opponent | L0333 |
| Periapt of Soul Exchange | Opponent | L0420 |
| Ring of Doom | Mine | L0216, L0232 |
| Ring of Doom | Opponent | L0115, L0333 |

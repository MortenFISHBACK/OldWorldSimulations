# Doctrine scorecard: h9-opp-81fb82c-p4

### Scorecard: h9-opp-81fb82c-p4

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0115 | 1 | 1 | Mine | no | 0 | - | 0 | 3 | 0 | 0 | 0 | 0 |
| L0115 | 1 | 1 | Opponent | yes | 15 | 2 | 5 | 2 | 1 | 0 | 0 | 0 |
| L0132 | 6 | 1 | Mine | no | 1 | - | 0 | 1 | 0 | 0 | 0 | 55 |
| L0132 | 6 | 1 | Opponent | no | 4 | 3 | 3 | 7 | 1 | 0 | 0 | 340 |
| L0216 | 6 | 1 | Mine | no | 4 | 4 | 0 | 3 | 1 | 0 | 0 | 30 |
| L0216 | 6 | 1 | Opponent | no | 6 | 2 | 2 | 0 | 0 | 0 | 0 | 100 |
| L0232 | 4 | 1 | Mine | no | 2 | 4 | 6 | 0 | 0 | 0 | 0 | 170 |
| L0232 | 4 | 1 | Opponent | no | 0 | 2 | 3 | 2 | 1 | 0 | 0 | 0 |
| L0316 | 4 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 140 |
| L0316 | 4 | 1 | Opponent | no | 0 | 2 | 1 | 3 | 1 | 0 | 0 | 200 |
| L0333 | 3 | 1 | Mine | no | 2 | - | 0 | 0 | 0 | 0 | 0 | 110 |
| L0333 | 3 | 1 | Opponent | no | 0 | 2 | 2 | 5 | 0 | 0 | 0 | 0 |
| L0420 | 6 | 1 | Mine | no | 4 | 3 | 4 | 1 | 0 | 0 | 0 | 65 |
| L0420 | 6 | 1 | Opponent | no | 9 | - | 0 | 1 | 2 | 0 | 0 | 420 |
| **Average** | | | Mine | 0% | 1.9 | 3.7 | 1.4 | 1.3 | 0.1 | 0.0 | 0.0 | 81.4 |
| **Average** | | | Opponent | 14% | 4.9 | 2.2 | 2.3 | 2.9 | 0.9 | 0.0 | 0.0 | 151.4 |

### KPIs: h9-opp-81fb82c-p4

Rules off - Mine only: HOLDER ASSIGNMENT, QUARTER ODDS, WALK PROMISE, REAL GROUND, RISK ON THE WAY, ONE ROUTE, MARCH WHEELS ONLY, LATE ONLY FROM HERE, WALKS ON ITS ROUTE.

Morten 2026-11-10; 7 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 28% (7 of 25) | 0% (0 of 35) | 12% (7 of 60) |
| Winner chose to follow up after the loser gave ground |  | 71% (5 of 7); on the table 86% | 86% (6 of 7); on the table 86% | 79% (11 of 14); on the table 86% |
| Winner chose to pursue after the loser fell back in good order |  | - | 0% (0 of 1); on the table 0% | 0% (0 of 1); on the table 0% |
| Winner chose to pursue after the loser fled |  | 100% (1 of 1); on the table 100% | 100% (3 of 3); on the table 100% | 100% (4 of 4); on the table 100% |
| Winner chose to follow up or pursue (all three) |  | 75% (6 of 8); on the table 88% | 82% (9 of 11); on the table 82% | 79% (15 of 19); on the table 84% |
| Magic missiles tried each own turn | 50%+ | 46% (58 of 126) | 44% (8 of 18) | 46% (66 of 144) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 53% (58 of 109) | 57% (8 of 14) | 54% (66 of 123) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 83% (5 of 6) | 74% (20 of 27) | 76% (25 of 33) |
| Points that never fought | lower | 55% (7543 of 13595) | 61% (8476 of 13997) | 58% (16019 of 27592) |
|   infantry points that never fought | lower | 65% (2671 of 4124) | 94% (2994 of 3186) | 77% (5665 of 7310) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 57% (26 of 46) | 46% (24 of 52) | 51% (50 of 98) |
| Bound items with a magic missile used (at least once a game) |  | 100% (6 of 6); 3.3 uses a game | 100% (4 of 4); 1.3 uses a game | 100% (10 of 10); 2.3 uses a game |
| Bound items with another spell used |  | 50% (1 of 2); 0.1 uses a game | 0.0 uses a game | 50% (1 of 2); 0.1 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 62% (5 of 8); 0.7 uses a game | 75% (3 of 4); 0.4 uses a game | 67% (8 of 12); 0.6 uses a game |
|   their share of the points of units over 100 pts | lower | 48% (4950 of 10334) | 43% (5342 of 12450) | 45% (10292 of 22784) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 4.9 (50%) | 0.6 (40%) | 5.4 (49%) |
| MARCHED: its unit marched | 1.9 (19%) | 0.3 (20%) | 2.1 (19%) |
| CHARGED: its unit charged | 0.6 (6%) | 0.0 (0%) | 0.6 (5%) |
| IN COMBAT: engaged in combat | 0.9 (9%) | 0.0 (0%) | 0.9 (8%) |
| GONE: slain | 1.6 (16%) | 0.6 (40%) | 2.1 (19%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 6.7 | 0.3 | 4.1 | 9.4 | 0.6 |
| not cast | 6.1 | 0.6 | 3.6 | 11.1 | 16.6 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.9 (5%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.0 (0%) | 0.9 (24%) | 5.4 (49%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.1 (19%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.6 (5%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.1 (25%) | 0.4 (12%) | 0.9 (8%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) |
| GONE: slain | 1.0 (16%) | 0.0 (0%) | 0.6 (16%) | 2.1 (19%) | 2.3 (14%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.3 (5%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 4.9 (79%) | 0.4 (75%) | 1.7 (48%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 13.3 (80%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 3.3 a game | 1.0 a game | 2.1 a game |
| stood (cast and not dispelled) | 61% (14 of 23) | 75% (3 of 4) | 63% (17 of 27) |
| the unit moved after it | 86% (12 of 14) | 100% (3 of 3) | 88% (15 of 17) |
| it charged on its next turn | 0% (0 of 14) | 0% (0 of 3) | 0% (0 of 17) |
| the enemy charged it first | 7% (1 of 14) | 0% (0 of 3) | 6% (1 of 17) |
| it fought by the end of its next turn | 0% (0 of 14) | 0% (0 of 3) | 0% (0 of 17) |
| it moved out of a charge the enemy had planned (not charged first) | 14% (2 of 14) | 0% (0 of 3) | 12% (2 of 17) |
| none of these (no charge, no fight, no charge escaped) | 79% (11 of 14) | 100% (3 of 3) | 82% (14 of 17) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 67% (63 of 94) | 40% (52 of 129) | 52% (115 of 223) |
|   cavalry | 67% (4 of 6) | 35% (9 of 26) | 41% (13 of 32) |
|   character | - | 31% (8 of 26) | 31% (8 of 26) |
|   chariot | 56% (20 of 36) | 0% (0 of 4) | 50% (20 of 40) |
|   infantry | 86% (18 of 21) | 53% (26 of 49) | 63% (44 of 70) |
|   war machine | 68% (21 of 31) | 38% (9 of 24) | 55% (30 of 55) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 0.7 (16%) | 2.3 (21%) | 3.0 (19%) |
| CHARGED: it charged | 0.3 (6%) | 2.0 (18%) | 2.3 (15%) |
| IN COMBAT: it fought this turn or the last | 0.4 (10%) | 0.1 (1%) | 0.6 (4%) |
| MOVED: a war machine that moved | 1.4 (32%) | 0.1 (1%) | 1.6 (10%) |
| NO TARGET IN RANGE | 0.9 (19%) | 3.1 (29%) | 4.0 (26%) |
| ONLY IN COMBAT: the only targets were in combat | 0.3 (6%) | 0.1 (1%) | 0.4 (3%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.4 (10%) | 2.4 (22%) | 2.9 (19%) |
| SHELTERED: the target was sheltered | 0.0 (0%) | 0.6 (5%) | 0.6 (4%) |
| OTHER BAR | 0.0 (0%) | 0.1 (1%) | 0.1 (1%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 1.9 | 1.3 | 54% | 7.0 pts | 13 pts |
| character | 1.4 | 0.4 | 70% | 1.5 pts | 2 pts |
| chariot | 2.9 | 4.6 | 35% | 46.5 pts | 133 pts |
| infantry | 7.9 | 1.9 | 80% | 2.6 pts | 20 pts |
| war machine | 4.3 | 4.6 | 53% | 14.3 pts | 61 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 2.0 | 3.9 | 2.9 |
| Charges that made contact a game | 1.6 | 3.4 | 2.5 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.00 declared, 0.00 contact (4 units) | 0.00 declared, 0.00 contact (2 units) | 0.00 declared, 0.00 contact (6 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | - | - |
|   per unit a game, the other units (no war machines, no joined characters) | 0.29 declared, 0.23 contact (48 units) | 0.47 declared, 0.41 contact (58 units) | 0.39 declared, 0.33 contact (106 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 20% (2 of 10) | - | 100% (1 of 1) | 27% (3 of 11) |
| Character in a unit | 78% (7 of 9) | 60% (3 of 5) | 0% (0 of 1) | 67% (10 of 15) |
| Character on its own | 100% (2 of 2) | 33% (3 of 9) | 30% (3 of 10) | 38% (8 of 21) |
| Chariot | 0% (0 of 1) | 50% (3 of 6) | - | 43% (3 of 7) |
| Infantry | 40% (4 of 10) | 40% (6 of 15) | - | 40% (10 of 25) |
| Monster | 67% (4 of 6) | 100% (2 of 2) | - | 75% (6 of 8) |
| Monstrous | 67% (2 of 3) | - | - | 67% (2 of 3) |
| War Machines | 100% (6 of 6) | 100% (2 of 2) | - | 100% (8 of 8) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 80% (4 of 5); on the table 80% | 46% (47 of 102) | 47% | 50% (11 of 22) | 100% (6 of 6); 5.8 uses a game | 50% (1 of 2); 0.2 uses a game | 83% (5 of 6); 1.2 uses a game |
| Chaos Dwarfs | 3 | 67% (2 of 3); on the table 100% | 46% (11 of 24) | 66% | 62% (15 of 24) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |
| High Elf Realms | 1 | 67% (2 of 3); on the table 67% | 33% (2 of 6) | 69% | 29% (2 of 7) | 100% (2 of 2); 4.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 2 | 80% (4 of 5); on the table 80% | - | 61% | 33% (4 of 12) | 0.0 uses a game | 0.0 uses a game | 100% (2 of 2); 1.0 uses a game |
| Skaven | 1 | - | 67% (4 of 6) | 65% | 71% (5 of 7) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Warriors of Chaos | 2 | 100% (2 of 2); on the table 100% | - | 44% | 31% (5 of 16) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 1 | 100% (1 of 1); on the table 100% | 33% (2 of 6) | 80% | 80% (8 of 10) | 100% (2 of 2); 5.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (h9-opp-81fb82c-p4, 7 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 50% (10) | 56% (5) | 52% (15) |
| ...free all their last turn and able to turn (per game) | 1.00 | 0.00 | 1.00 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.14 | 0.29 | 0.43 |
| ...with the charger already in that arc before they moved (per game) | 1.00 | 0.00 | 1.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.14 | 0.00 | 0.14 |

### Quality by phase: h9-opp-81fb82c-p4

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 0.9 | 2.1 |
| Strategy | Charge objectives carried out (made contact) | 50% (5 of 10) | 48% (12 of 25) |
| Strategy | Shoot objectives carried out (shot that target) | 30% (21 of 71) | 24% (5 of 21) |
| Strategy | Support requests answered (helper made contact too) | 100% (2 of 2) | - |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (3 of 3) | - |
| Strategy | Hexes on a unit its side charged or shot that turn | - | 0% (0 of 2) |
| Strategy | Joined characters whose unit fought | 28% (5 of 18) | 29% (2 of 7) |
| Strategy | Lone characters that fought | 57% (8 of 14) | 64% (9 of 14) |
| Movement | Charges halted short of contact | 0.1 | 0.0 |
| Movement | Idle units | 1.3 | 2.9 |
| Movement | Points that never moved of their own | 81.4 | 151.4 |
| Movement | Fights charged into per game | 1.3 | 3.4 |
| Movement | Charges with odds: long shots (under 50%) | 2 of 9, net -42 | 5 of 23, net +100 |
| Movement | Charges with odds: sweet spot (55-75%) | 4 of 9, net +134 | 6 of 23, net +131 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 9 | 5 of 23, net +81 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 of 9, net +68 | 4 of 23, net +49 |
| Shooting | Shots by shooting units (incl. breath weapons) | 6.0 | 7.4 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 33% (14 of 42) | 37% (19 of 52) |
| Shooting | Points destroyed by shooting units | 133.0 | 0.0 |
| Shooting | War machine shots | 3.0 | 1.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 29% (6 of 21) | 78% (7 of 9) |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | 5.7 | 0.9 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 40% (16 of 40) | 33% (2 of 6) |
| Magic | Wounds caused by magic missiles | 11.1 | 0.9 |
| Magic | Wounds caused by other spells | 0.3 | 0.6 |
| Magic | Points destroyed by magic (all spells) | 241.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 3.3 / 0.0 / 0.1 / 0.0 | 1.7 / 0.3 / 0.3 / 0.0 |
| Combat | Points destroyed in combat | 139.9 | 422.6 |
| Combat | Points run down | 0.0 | 25.1 |
| Combat | Net points per charged fight, damage counted | +68 | +87 |
| Combat | Net per 100 charger points, damage counted | +38.2 | +31.1 |
| Combat | First round won (charged fights) | 67% | 67% |
| Combat | Net points per charged fight | +81 | +89 |
| Combat | Net points per supported fight / lone fight | -42 / +116 | - / +89 |
| Combat | Charged fights on a top-3 enemy unit | 5 of 9 | 7 of 24 |
| Game | Points lost | 455.9 | 661.4 |
| Game | VP from objectives | 708.6 | 738.6 |
| Game | Lone holders (player turns) | 1.9 | 4.9 |

- Mine won / drew / lost: 2 / 4 / 1 of 7 ended games (of 7); mean margin (Mine - Opponent) +163 VP
- The side that went first won 2 of 3 games with a winner
- Points traded per game (both sides' losses): 1117
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: h9-opp-81fb82c-p4

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.4 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.3 | +48.9 | 0.0 | 0.0 | 0.1 | +0.9 | 0.0 | 0.0 |
| ALREADY CARRIED | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARTILLERY RE-ROLL WEIGHED | 1.3 | +0.0 | 0.0 | 72.9 | - | - | - | - |
| BLOWS WHERE AIMED | - | - | - | - | 0.9 | -107.4 | 48.6 | 16.4 |
| CANNON PLAN MISSED | 1.0 | +0.0 | 99.0 | 55.7 | 0.3 | +0.0 | 48.6 | 0.0 |
| CANNON PLANNED TARGET | 2.0 | +16.1 | 62.4 | 68.6 | 1.0 | +14.1 | 20.0 | 0.0 |
| CANNON SIGHT KEPT | 0.9 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT COUNTER | - | - | - | - | 0.1 | +0.0 | 11.6 | 0.0 |
| CAST JOB | 0.9 | +10.6 | 0.0 | 0.0 | 0.3 | +0.5 | 0.0 | 0.0 |
| CASTER AWAY FROM SCREEN | 1.0 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 1.7 | +151.1 | 209.7 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | 1.4 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 89.9 |
| CHAFF IN THE MOVE | 0.7 | +42.0 | 0.0 | 20.0 | 0.1 | +8.4 | 0.0 | 0.0 |
| CHAFF PASSED | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHARACTER GUNS | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| CHARGE LOSSES | 4.4 | -150.6 | 0.0 | 14.9 | 5.6 | -196.4 | 0.0 | 163.4 |
| CHARGE NOT DECLARED | 0.7 | +0.0 | 113.0 | 7.4 | 0.1 | +0.0 | 12.1 | 0.0 |
| CHARGE NOW FIRST | 0.4 | +0.0 | 5.0 | 0.0 | 2.1 | +0.0 | 117.7 | 171.9 |
| CHARGER SLAIN LOST | 0.3 | -1.8 | 43.9 | 7.4 | 0.1 | -0.2 | 15.7 | 39.6 |
| CHARIOT NO STATIC JOB | - | - | - | - | 0.1 | +0.0 | 0.0 | 16.4 |
| CHEAP HELPER | 0.1 | +0.0 | 0.0 | 12.1 | - | - | - | - |
| CHEAPEST HOLDER | 0.9 | -77.3 | 85.6 | 0.0 | - | - | - | - |
| COMBAT PIVOT | 0.4 | +0.0 | 0.0 | 24.3 | 0.4 | +0.0 | 0.0 | 0.0 |
| CONTINUE AHEAD WEIGHED | - | - | - | - | 0.1 | +0.0 | 7.4 | 0.0 |
| CONVEYANCE SEARCH | 2.6 | +233.2 | 0.0 | 50.7 | 0.3 | +6.1 | 15.4 | 0.0 |
| COVER ONCE | 7.0 | -590.0 | 0.0 | 20.4 | 2.4 | -115.8 | 0.0 | 0.0 |
| DEPLOY BY FIGURES | 8.1 | +52.5 | 0.0 | 0.0 | 7.7 | +29.4 | 0.0 | 4.3 |
| EDGE GIVE GROUND | - | - | - | - | 0.1 | +0.8 | 20.0 | 0.0 |
| ENGINEER BY LORE | 0.6 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FALL BACK GOOD ORDER | 1.0 | +3.2 | 83.0 | 7.4 | 2.9 | +0.9 | 158.0 | 211.4 |
| FALLBACK BY WORTH | 0.3 | +0.0 | 0.0 | 12.1 | 0.1 | +0.0 | 0.0 | 0.0 |
| FALLS SHORT | 5.6 | +93.6 | 0.0 | 7.4 | 18.9 | +251.7 | 0.0 | 368.6 |
| FEATURE BUFFS | 4.9 | +167.5 | 0.0 | 21.4 | 0.9 | +45.7 | 0.0 | 0.0 |
| FIGHT TO THE END | 0.3 | +8.7 | 0.0 | 0.0 | 1.6 | +33.1 | 85.0 | 141.6 |
| FIRE IN ORDER | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FIVE ACTION | 41.6 | +3514.8 | 792.6 | 333.9 | 48.4 | +3078.9 | 295.9 | 983.7 |
| FLANK NOT WEIGHED | 8.1 | +0.0 | 0.0 | 63.1 | 3.6 | +0.0 | 0.0 | 4.3 |
| FOLLOW UP WEIGHED | 0.4 | +82.1 | 0.0 | 0.0 | 0.4 | +84.6 | 0.0 | 0.0 |
| FOUR ROUNDS | 1.1 | +58.3 | 83.0 | 19.0 | 3.6 | +229.6 | 227.3 | 281.3 |
| FRIEND SHOOTS FIRST | 0.6 | -13.6 | 0.0 | 0.0 | 0.3 | -13.1 | 0.0 | 0.0 |
| FRIENDS SHOTS CHECKED | - | - | - | - | 0.3 | +14.3 | 0.0 | 0.0 |
| GIVES UP | - | - | - | - | 0.6 | -6.1 | 62.1 | 0.0 |
| GUN FIGURES | 1.3 | +25.1 | 41.1 | 0.0 | 1.1 | +0.1 | 0.0 | 0.0 |
| GUN MASK | - | - | - | - | 0.1 | +5.0 | 0.0 | 0.0 |
| HARD STAY DROPPED | 1.4 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| HE SHOOTS OR CHARGES | 2.1 | +0.0 | 0.0 | 42.9 | 2.9 | +0.0 | 0.0 | 48.0 |
| HIS CHARGE DENIED | 0.1 | +1.0 | 19.6 | 0.0 | 0.3 | +6.6 | 19.6 | 0.0 |
| HIS CHARGE LIST | 2.3 | +0.0 | 0.0 | 0.0 | 2.6 | +0.0 | 0.0 | 18.0 |
| HIS LEGAL MOVES | 2.3 | +0.0 | 0.0 | 0.0 | 2.4 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 1.4 | -17.7 | 0.0 | 0.0 | 1.1 | -31.5 | 0.0 | 9.0 |
| HIS ONE QUARTER | - | - | - | - | 2.4 | +0.0 | 0.0 | 67.6 |
| HIS RANDOM MOVE | 4.0 | +0.0 | 0.0 | 58.7 | 1.4 | +0.0 | 0.0 | 11.4 |
| HIS SHOT LIST | 15.4 | +458.4 | 0.0 | 66.1 | 23.4 | +1045.1 | 0.0 | 509.4 |
| HIS TURN DENIED | - | - | - | - | 1.7 | +197.5 | 93.6 | 211.4 |
| HOLD ODDS | - | - | - | - | 13.6 | +0.0 | 0.0 | 104.9 |
| HOLDER ASSIGNMENT | - | - | - | - | 15.1 | +1394.0 | 0.0 | 104.9 |
| HOLDER AT DEPLOYMENT | 1.4 | +217.3 | 0.0 | 0.0 | - | - | - | - |
| HOLDS AMBUSHERS | 0.6 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 1.0 | -24.4 | 99.1 | 0.0 | 3.4 | -200.7 | 203.0 | 281.3 |
| HORN WORTH | - | - | - | - | 0.1 | +5.8 | 0.0 | 0.0 |
| IDLE COST | 1.9 | -15.4 | 0.0 | 12.1 | 13.6 | -202.4 | 0.0 | 299.7 |
| KEEP FALLS | 0.1 | +1.9 | 0.0 | 0.0 | - | - | - | - |
| LANE BY FIGURES | 0.3 | +5.2 | 0.0 | 0.0 | 1.0 | +33.8 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | - | - | - | - | 0.1 | +0.0 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 3.4 | +0.0 | 195.1 | 62.1 | 5.4 | +0.0 | 103.7 | 90.0 |
| LONE WIZARD KEPT IN | 1.4 | +92.8 | 0.0 | 0.0 | 0.4 | +27.4 | 0.0 | 0.0 |
| LONG SHOT | 0.3 | +1.8 | 0.0 | 11.6 | - | - | - | - |
| LURE BY WHAT IT DRAWS | - | - | - | - | 0.1 | +0.0 | 0.0 | 0.0 |
| MANOEUVRE | 1.7 | +20.1 | 0.0 | 0.0 | 1.9 | +29.7 | 0.0 | 25.1 |
| MARCH AT ESCAPER | 0.4 | +0.5 | 0.0 | 0.0 | 0.1 | +0.4 | 0.0 | 0.0 |
| MARCH BY THE SUM | 0.6 | +23.3 | 0.0 | 0.0 | 0.1 | +11.3 | 0.0 | 0.0 |
| MARCH CHECK | 1.4 | +136.1 | 0.0 | 0.0 | 0.6 | +27.5 | 0.0 | 56.9 |
| MARCH OVER CASTS | 0.9 | -44.4 | 0.0 | 0.0 | 0.4 | +30.1 | 0.0 | 56.4 |
| MARCH WHEELS ONLY | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 9.1 | +129.4 | 0.0 | 54.4 | 3.7 | +53.9 | 0.0 | 90.1 |
| MISSILES IN THE MOVE | 5.9 | +669.6 | 0.0 | 0.0 | 1.7 | +14.3 | 0.0 | 163.4 |
| MISSILES NEXT TURN | 7.1 | +565.2 | 0.0 | 0.0 | 2.9 | +15.6 | 0.0 | 248.3 |
| MOVE SPELL IN RANGE | 0.6 | +34.7 | 0.0 | 0.0 | 0.1 | +5.0 | 0.0 | 33.4 |
| MOVE SPELL OUT OF RANGE | 0.7 | -30.0 | 0.0 | 0.0 | 0.7 | -34.8 | 0.0 | 33.4 |
| MOVE SPELL SPOT | 1.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 2.9 | +579.3 | 0.0 | 7.4 | 3.6 | +364.6 | 0.0 | 48.6 |
| MOVES UNITS SPELL | 0.3 | +15.7 | 0.0 | 0.0 | 0.1 | +1.0 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 4.6 | +253.6 | 0.0 | 9.3 | 5.7 | +251.4 | 0.0 | 133.6 |
| NEEDED THERE | 0.3 | +75.9 | 60.0 | 0.0 | - | - | - | - |
| NEXT CHARGE BY LIST | 4.6 | -169.5 | 5.0 | 7.4 | 5.6 | -109.5 | 0.0 | 48.6 |
| NEXT OBJECTIVE NEARER | 5.1 | -182.4 | 5.0 | 22.3 | 0.1 | -0.0 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 1.0 | -21.4 | 58.7 | 11.6 | 3.1 | -66.4 | 171.4 | 281.3 |
| NOT TURNED | 0.1 | +0.0 | 0.0 | 12.1 | - | - | - | - |
| NOT WORTH A CAST | 0.3 | -0.4 | 0.0 | 0.0 | 1.1 | -0.9 | 0.0 | 112.9 |
| OFF BEST | 0.3 | -1.7 | 0.0 | 0.0 | 0.3 | -0.4 | 0.0 | 0.0 |
| ONE CHARGE A CHARGER | 3.6 | +0.0 | 0.0 | 28.3 | 1.4 | +0.0 | 0.0 | 11.4 |
| ONE FIGHT FORMULA | 5.1 | -89.9 | 0.0 | 27.0 | 4.9 | -111.3 | 0.0 | 170.4 |
| ONE OBJECTIVE FORMULA | 4.9 | -32.7 | 0.0 | 22.3 | 5.1 | +56.3 | 0.0 | 51.3 |
| ONE ROUTE | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| ONE TARGET A SHOOTER | 11.6 | +145.6 | 0.0 | 81.4 | 19.9 | +543.1 | 0.0 | 286.9 |
| OPENS UP | - | - | - | - | 0.1 | +4.5 | 9.3 | 0.0 |
| OVERRUNS AWAY | 0.1 | +0.5 | 19.6 | 0.0 | 0.4 | +6.3 | 37.3 | 0.0 |
| PATHS CROSS | 3.4 | +157.2 | 0.0 | 7.9 | 3.4 | +188.9 | 0.0 | 43.9 |
| PERIAPT WORTH | - | - | - | - | 0.1 | +7.8 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | - | - | - | - | 0.1 | -4.6 | 0.0 | 0.0 |
| PLAN RESULT | 36.4 | +634.2 | 645.6 | 448.7 | 42.7 | +233.0 | 32.1 | 1049.1 |
| QUARTER ODDS | - | - | - | - | 6.7 | +838.6 | 7.4 | 101.0 |
| RANDOM MOVE BY FIGURES | 0.9 | +25.2 | 0.0 | 48.6 | 3.9 | +75.1 | 0.0 | 54.3 |
| REAL GROUND | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| REDIRECT BY WHAT IT STOPS | 0.6 | -8.4 | 0.0 | 20.0 | 0.1 | -12.6 | 0.0 | 0.0 |
| REDIRECT COUNTER | 3.1 | +177.5 | 0.0 | 63.1 | 3.4 | +171.4 | 0.0 | 33.7 |
| REDIRECT WEIGHED | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| REFORMS TO MEET IT | 0.4 | -6.0 | 0.0 | 7.4 | 0.6 | -10.5 | 0.0 | 0.0 |
| REFUSING RETIRES | 0.4 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| RESERVE FALL BACK | 0.4 | +19.1 | 0.0 | 0.0 | 0.9 | +34.1 | 0.0 | 11.4 |
| RESTRAINS TO SHOOT | - | - | - | - | 0.1 | +4.2 | 0.0 | 16.4 |
| RISK BY ARC | 1.1 | +29.5 | 113.0 | 19.0 | 3.1 | +93.9 | 211.6 | 281.3 |
| RISK BY HIS FIGURE | 13.1 | -114.4 | 0.0 | 110.3 | 9.9 | -80.8 | 0.0 | 95.1 |
| RISK ON THE WAY | - | - | - | - | 0.9 | +0.0 | 0.0 | 0.0 |
| RUN DOWN | 0.7 | -6.8 | 58.7 | 0.0 | 2.9 | -21.7 | 178.7 | 264.9 |
| SCOUT SPOT | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SCOUT WAITS | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 0.3 | -16.5 | 0.0 | 0.0 |
| SEARCH SPOT | 6.0 | +184.8 | 0.0 | 51.0 | 4.1 | +76.7 | 0.0 | 0.0 |
| SELF MOVE SPELL | - | - | - | - | 0.4 | +48.2 | 0.0 | 112.9 |
| SET UP TOGETHER | 0.1 | +0.5 | 0.0 | 0.0 | 0.1 | +0.3 | 0.0 | 0.0 |
| SET-UP ANY TARGET | 0.4 | +77.0 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | - | - | - | - | 0.3 | +0.3 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 2.4 | +291.3 | 236.3 | 0.0 | 0.6 | +6.5 | 0.0 | 0.0 |
| SHOT OR CHARGE | - | - | - | - | 0.3 | -18.8 | 48.6 | 0.0 |
| SHOT RISK POINTS | 7.0 | +69.3 | 0.0 | 7.9 | 16.7 | +338.5 | 0.0 | 511.1 |
| SHOTS IN THE MOVE | 9.9 | +451.4 | 0.0 | 191.4 | 9.6 | +177.6 | 0.0 | 181.7 |
| SPELL SETS UP CHARGE | 0.7 | +177.3 | 0.0 | 0.0 | - | - | - | - |
| SPELL WORTH | 1.6 | +26.0 | 0.0 | 101.4 | 3.0 | +48.4 | 11.4 | 0.0 |
| SPELLS IN THE FIGHT | 0.1 | -1.0 | 0.0 | 0.0 | 0.1 | -1.7 | 0.0 | 0.0 |
| STAND AND SHOOT | - | - | - | - | 0.4 | -3.6 | 18.6 | 69.9 |
| STANDS FOR A REASON | - | - | - | - | 0.4 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 17.6 | +0.0 | 709.6 | 221.4 | 13.3 | +0.0 | 68.6 | 63.6 |
| STAY WORTH | 10.6 | -12.2 | 193.6 | 242.9 | 10.1 | +77.2 | 20.0 | 179.6 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 0.0 |
| SUPPORT NARROWED | 0.7 | +0.0 | 24.6 | 0.0 | 0.9 | +0.0 | 55.4 | 0.0 |
| SURE REACH TOGETHER | - | - | - | - | 0.6 | +1.2 | 0.0 | 39.6 |
| THE DEARER SUM KEEPS ITS PLAN | 4.4 | +0.0 | 0.0 | 7.9 | 3.1 | +0.0 | 0.0 | 43.9 |
| THE PROMISE ADDS | 0.1 | -17.2 | 0.0 | 0.0 | - | - | - | - |
| THE PROMISED MOVE | - | - | - | - | 0.9 | +0.0 | 0.0 | 37.4 |
| TIED UP BY THE SUM | - | - | - | - | 1.3 | +112.8 | 87.0 | 69.9 |
| TIME ON OUR SIDE | 29.0 | +501.4 | 0.0 | 77.4 | 5.9 | +90.5 | 0.0 | 22.9 |
| WAITS AGAIN | 1.4 | +0.0 | 0.0 | 0.0 | 0.9 | +0.0 | 0.0 | 0.0 |
| WAR ENGINE CHARGES | 0.1 | +20.2 | 0.0 | 0.0 | - | - | - | - |
| WAR ENGINE JOBS | 0.6 | +0.0 | 44.9 | 0.0 | - | - | - | - |
| WHO HITS BACK | 0.4 | +32.1 | 0.0 | 0.0 | 0.1 | +4.1 | 0.0 | 0.0 |
| WHOLE FIGHT | 0.6 | -6.4 | 103.9 | 7.4 | 0.3 | +12.4 | 35.9 | 0.0 |
| WHOLE FIGHT GAIN | 0.3 | +16.7 | 0.0 | 11.6 | - | - | - | - |
| WIDER SPREAD | 1.0 | -2.6 | 123.4 | 7.4 | 2.6 | -10.5 | 197.1 | 56.0 |
| WOUNDS ON THE RANKS | 1.6 | +27.4 | 0.0 | 0.0 | 1.4 | +95.6 | 0.0 | 0.0 |

### Rule changes: h9-opp-81fb82c-p4

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HOLDER ASSIGNMENT | 106 | 106 | 97 | 13.86 | +4216 | +43.5 |
| HIS SHOT LIST | 272 | 272 | 73 | 10.43 | +2094 | +28.7 |
| SEARCH SPOT | 71 | 71 | 68 | 9.71 | +1830 | +26.9 |
| DEPLOY BY FIGURES | 111 | 111 | 63 | 9.00 | +723 | +11.5 |
| LEGAL CHARGES ONLY | 62 | 62 | 62 | 8.86 | +0 | +0.0 |
| PATHS CROSS | 48 | 48 | 48 | 6.86 | +2423 | +50.5 |
| ONE TARGET A SHOOTER | 220 | 220 | 44 | 6.29 | +619 | +14.1 |
| TIME ON OUR SIDE | 244 | 199 | 40 | 5.71 | +181 | +4.5 |
| MAX FOR POSITIONING | 90 | 83 | 28 | 4.00 | +106 | +3.8 |
| SHOT RISK POINTS | 166 | 166 | 28 | 4.00 | +1231 | +43.9 |
| FALLS SHORT | 171 | 155 | 25 | 3.57 | +65 | +2.6 |
| RANDOM MOVE BY FIGURES | 33 | 33 | 25 | 3.57 | +702 | +28.1 |
| MOVE TO CHARGE COMPUTED | 45 | 45 | 23 | 3.29 | +2586 | +112.4 |
| FIVE ACTION | 630 | 630 | 20 | 2.86 | +1621 | +81.0 |
| FOUR ROUNDS | 33 | 33 | 16 | 2.29 | +284 | +17.7 |
| REDIRECT COUNTER | 46 | 41 | 16 | 2.29 | +753 | +47.1 |
| HARD STAY DROPPED | 14 | 14 | 14 | 2.00 | +0 | +0.0 |
| SHOOTS FROM THE BEST SPOT | 21 | 21 | 14 | 2.00 | +436 | +31.1 |
| LONE WIZARD KEPT IN | 13 | 13 | 13 | 1.86 | +841 | +64.7 |
| IDLE COST | 108 | 90 | 12 | 1.71 | +172 | +14.4 |
| MANOEUVRE | 25 | 25 | 12 | 1.71 | +362 | +30.1 |
| RISK BY ARC | 30 | 30 | 12 | 1.71 | +171 | +14.2 |
| COVER ONCE | 66 | 49 | 11 | 1.57 | +207 | +18.8 |
| QUARTER ODDS | 47 | 47 | 11 | 1.57 | +1130 | +102.7 |
| ARTILLERY RE-ROLL WEIGHED | 9 | 9 | 9 | 1.29 | +0 | +0.0 |
| CANNON SIGHT KEPT | 9 | 9 | 9 | 1.29 | +0 | +0.0 |
| CASTING BLOCK | 12 | 12 | 9 | 1.29 | +137 | +15.2 |
| LANE BY FIGURES | 9 | 9 | 9 | 1.29 | +273 | +30.4 |
| MARCH CHECK | 14 | 14 | 9 | 1.29 | +275 | +30.5 |
| RESERVE FALL BACK | 9 | 9 | 9 | 1.29 | +372 | +41.4 |
| SHOTS IN THE MOVE | 136 | 121 | 9 | 1.29 | +636 | +70.7 |
| CASTER AWAY FROM SCREEN | 8 | 8 | 8 | 1.14 | +0 | +0.0 |
| HOLDS AMBUSHERS | 8 | 8 | 8 | 1.14 | +0 | +0.0 |
| TIED UP BY THE SUM | 9 | 9 | 8 | 1.14 | +180 | +22.5 |
| MISSILES IN THE MOVE | 53 | 38 | 7 | 1.00 | +119 | +17.0 |
| ADVANCE LANE KEPT | 6 | 6 | 6 | 0.86 | +0 | +0.0 |
| CHAFF IN THE MOVE | 6 | 6 | 6 | 0.86 | +36 | +6.1 |
| CHARGE LOSSES | 70 | 70 | 6 | 0.86 | +641 | +106.9 |
| CHARGE NOT DECLARED | 6 | 6 | 6 | 0.86 | -436 | -72.7 |
| CHARGE NOW FIRST | 18 | 18 | 6 | 0.86 | -319 | -53.2 |
| COMBAT PIVOT | 6 | 6 | 6 | 0.86 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 6 | 6 | 6 | 0.86 | +1167 | +194.5 |
| HIS TURN DENIED | 12 | 12 | 6 | 0.86 | +521 | +86.9 |
| HOLDER AT DEPLOYMENT | 10 | 10 | 6 | 0.86 | +405 | +67.5 |
| NEARER NOT NEEDED | 72 | 64 | 6 | 0.86 | +178 | +29.6 |
| CANNON PLANNED TARGET | 21 | 21 | 5 | 0.71 | -23 | -4.7 |
| MARCH BY THE SUM | 5 | 5 | 5 | 0.71 | +242 | +48.5 |
| NEXT CHARGE BY LIST | 71 | 71 | 5 | 0.71 | +140 | +27.9 |
| NEXT OBJECTIVE NEARER | 37 | 37 | 5 | 0.71 | +63 | +12.5 |
| FEATURE BUFFS | 40 | 40 | 4 | 0.57 | +147 | +36.7 |
| OFF BEST | 4 | 4 | 4 | 0.57 | -15 | -3.7 |
| ONE OBJECTIVE FORMULA | 70 | 57 | 4 | 0.57 | +120 | +29.9 |
| RISK BY HIS FIGURE | 161 | 161 | 4 | 0.57 | +43 | +10.9 |
| STUCK PIVOT | 4 | 4 | 4 | 0.57 | +0 | +0.0 |
| WHO HITS BACK | 4 | 4 | 4 | 0.57 | +177 | +44.2 |
| AFTERMATH IN POINTS | 3 | 3 | 3 | 0.43 | +348 | +116.1 |
| CAST JOB | 8 | 8 | 3 | 0.43 | +2 | +0.7 |
| MISSILES NEXT TURN | 70 | 48 | 3 | 0.43 | +57 | +19.1 |
| MOVES UNITS SPELL | 3 | 3 | 3 | 0.43 | +118 | +39.2 |
| WHOLE FIGHT | 6 | 6 | 3 | 0.43 | +54 | +17.8 |
| FIGHT TO THE END | 13 | 13 | 2 | 0.29 | +39 | +19.4 |
| FRIENDS SHOTS CHECKED | 2 | 2 | 2 | 0.29 | +100 | +50.2 |
| NEEDED THERE | 2 | 2 | 2 | 0.29 | +0 | +0.0 |
| ONE FIGHT FORMULA | 70 | 37 | 2 | 0.29 | +46 | +23.1 |
| REDIRECT WEIGHED | 2 | 2 | 2 | 0.29 | +343 | +171.6 |
| REFUSING RETIRES | 3 | 3 | 2 | 0.29 | -1 | -0.4 |
| SHOOTERS IN TWO RANKS | 2 | 2 | 2 | 0.29 | +2 | +1.0 |
| SURE REACH TOGETHER | 4 | 4 | 2 | 0.29 | +0 | +0.0 |
| CHAFF PASSED | 1 | 1 | 1 | 0.14 | +0 | +0.0 |
| CONTINUE AHEAD WEIGHED | 1 | 1 | 1 | 0.14 | +0 | +0.0 |
| FIRE IN ORDER | 1 | 1 | 1 | 0.14 | +0 | +0.0 |
| HIS CHARGE DENIED | 3 | 3 | 1 | 0.14 | +27 | +26.7 |
| HORN WORTH | 1 | 1 | 1 | 0.14 | +41 | +40.7 |
| KEEP FALLS | 1 | 1 | 1 | 0.14 | +24 | +24.4 |
| LONG SHOT | 2 | 2 | 1 | 0.14 | +1 | +0.9 |
| OPENS UP | 1 | 1 | 1 | 0.14 | +11 | +11.4 |
| OVERRUNS AWAY | 4 | 4 | 1 | 0.14 | +1 | +0.7 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.14 | +54 | +54.4 |
| PIVOT GUARDS FLANK | 1 | 1 | 1 | 0.14 | -32 | -32.0 |
| RESTRAINS TO SHOOT | 1 | 1 | 1 | 0.14 | +29 | +29.4 |
| RUN DOWN | 25 | 25 | 1 | 0.14 | +3 | +2.6 |
| SCOUT WAITS | 1 | 1 | 1 | 0.14 | +0 | +0.0 |
| STAY WORTH | 145 | 136 | 1 | 0.14 | +43 | +43.2 |
| SUPPORT NARROWED | 11 | 11 | 1 | 0.14 | -8 | -8.4 |
| WAR ENGINE CHARGES | 1 | 1 | 1 | 0.14 | +20 | +20.5 |
| WAR ENGINE JOBS | 4 | 4 | 1 | 0.14 | -69 | -68.7 |
| WHOLE FIGHT GAIN | 2 | 2 | 1 | 0.14 | +4 | +4.4 |
| WOUNDS ON THE RANKS | 21 | 21 | 1 | 0.14 | +37 | +37.3 |
| ALREADY CARRIED | 1 | not checked | - | - | - | - |
| BLOWS WHERE AIMED | 6 | 6 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 9 | 9 | 0 | 0.00 | - | - |
| CARRIES OUT COUNTER | 1 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 15 | trace | - | - | - | - |
| CHARACTER GUNS | 7 | 7 | 0 | 0.00 | - | - |
| CHARGER SLAIN LOST | 3 | 3 | 0 | 0.00 | - | - |
| CHARIOT NO STATIC JOB | 1 | 1 | 0 | 0.00 | - | - |
| CHEAP HELPER | 1 | not checked | - | - | - | - |
| CHEAPEST HOLDER | 6 | 6 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 20 | not checked | - | - | - | - |
| EDGE GIVE GROUND | 1 | 1 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 27 | 27 | 0 | 0.00 | - | - |
| FALLBACK BY WORTH | 3 | 3 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 82 | not checked | - | - | - | - |
| FRIEND SHOOTS FIRST | 6 | 6 | 0 | 0.00 | - | - |
| GIVES UP | 4 | 4 | 0 | 0.00 | - | - |
| GUN FIGURES | 17 | not checked | - | - | - | - |
| GUN MASK | 1 | 1 | 0 | 0.00 | - | - |
| HE SHOOTS OR CHARGES | 35 | 35 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 34 | 34 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 33 | 33 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 18 | 18 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 17 | 17 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 38 | 38 | 0 | 0.00 | - | - |
| HOLD ODDS | 95 | 95 | 0 | 0.00 | - | - |
| HONEST WORTH | 31 | 31 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 1 | 1 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 1 | 1 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 4 | trace | - | - | - | - |
| MARCH OVER CASTS | 9 | 9 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 9 | 9 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 5 | 3 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 10 | trace | - | - | - | - |
| MOVE SPELL SPOT | 8 | not checked | - | - | - | - |
| NO DOUBLE ROUNDS | 29 | 29 | 0 | 0.00 | - | - |
| NOT TURNED | 1 | 1 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 10 | not checked | - | - | - | - |
| ONE CHARGE A CHARGER | 35 | 35 | 0 | 0.00 | - | - |
| ONE ROUTE | 9 | 9 | 0 | 0.00 | - | - |
| PLAN RESULT | 554 | trace | - | - | - | - |
| REAL GROUND | 9 | 9 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 5 | 5 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 7 | 7 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 6 | 6 | 0 | 0.00 | - | - |
| SCOUT SPOT | 1 | 1 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 2 | 2 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 3 | not checked | - | - | - | - |
| SET UP TOGETHER | 2 | 1 | 0 | 0.00 | - | - |
| SET-UP ANY TARGET | 3 | not checked | - | - | - | - |
| SHOT OR CHARGE | 2 | 2 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 5 | not checked | - | - | - | - |
| SPELL WORTH | 32 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 3 | 3 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 3 | 3 | 0 | 0.00 | - | - |
| STANDS STILL | 216 | 216 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 53 | not checked | - | - | - | - |
| THE PROMISE ADDS | 1 | 1 | 0 | 0.00 | - | - |
| THE PROMISED MOVE | 6 | not checked | - | - | - | - |
| WAITS AGAIN | 16 | 16 | 0 | 0.00 | - | - |
| WIDER SPREAD | 25 | 25 | 0 | 0.00 | - | - |

### Off best figure: h9-opp-81fb82c-p4

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| HOLDER ASSIGNMENT | rule | - | 1.29 | 16.0 |
| CHARGE NOT DECLARED | rule | 0.71 | 0.14 | 72.6 |
| CHARGE NOW FIRST | rule | 0.29 | 0.57 | 53.2 |
| PATHS CROSS | rule | 0.57 | - | 11.9 |
| CANNON PLANNED TARGET | rule | 0.43 | - | 11.8 |
| FIGHT ORDER BAND | gate | - | 0.29 | 1.4 |
| AFTERMATH BAND | gate | 0.14 | - | 0.9 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.14 | - | 11.1 |
| PIVOT GUARDS FLANK | rule | - | 0.14 | 32.0 |
| REFUSING RETIRES | rule | 0.14 | - | 0.6 |
| SUPPORT NARROWED | rule | 0.14 | - | 8.4 |
| WAR ENGINE JOBS | rule | 0.14 | - | 68.7 |

### Plans: h9-opp-81fb82c-p4

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.0 | 57% | 150 | 76 | 50% |
| Mine | move | 26.4 | 96% | 2286 | 0 | 0% |
| Mine | shoot | 8.4 | 63% | 994 | 559 | 56% |
| Mine | support | 0.6 | 75% | 0 | 0 | - |
| Opponent | charge | 3.0 | 71% | 633 | 200 | 32% |
| Opponent | move | 37.0 | 93% | 1635 | 0 | 0% |
| Opponent | shoot | 2.3 | 50% | 84 | 33 | 39% |
| Opponent | support | 0.4 | 100% | 3 | 0 | 0% |

### Battle groups: h9-opp-81fb82c-p4

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 3.1 | 14% | 100% | 100% | 0% | - | - | - | - | - |
| Opponent | REDIRECT COUNTER | 3.4 | 0% | - | - | - | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: h9-opp-81fb82c-p4

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 5 | 0 (5) | 0 | 0 | 47 | 60% | 5.0 | 0 (1) | 0 (3) | 0 (1) | 0 (4) | 0 (1) |
| Mine | Character | 27 | 53 (27) | 53 | 0 | 32 | 22% | 2.2 | 17 (6) | 16 (8) | 121 (7) | 64 (12) | 31 (9) |
| Mine | Clean-up | 1 | 132 (1) | 0 | 132 | 0 | 0% | 2.0 | 132 (1) | - | - | 132 (1) | - |
| Mine | Fast Hammer | 10 | 58 (10) | 58 | 0 | 63 | 20% | 4.6 | 0 (1) | 153 (3) | 31 (6) | 66 (9) | 0 (1) |
| Mine | Hammer | 18 | 48 (18) | 36 | 12 | 9 | 28% | 2.3 | 65 (4) | 54 (9) | 25 (5) | 23 (8) | 72 (10) |
| Mine | Holder | 10 | 85 (10) | 0 | 85 | 17 | 90% | 6.0 | 25 (1) | 127 (6) | 30 (3) | 84 (5) | 86 (5) |
| Mine | Shooter | 5 | 129 (5) | 0 | 129 | 35 | 0% | 1.4 | - | 129 (5) | - | 99 (3) | 185 (2) |
| Mine | War machine | 8 | 0 (8) | 0 | 0 | 62 | 0% | 1.4 | 0 (7) | 0 (1) | - | 0 (2) | 0 (6) |
| Mine | Wizard | 5 | 0 (5) | 0 | 0 | 0 | 60% | 3.0 | 0 (4) | 0 (1) | - | 0 (3) | 0 (2) |
| Opponent | Chaff | 14 | 62 (14) | 22 | 40 | 49 | 57% | 2.3 | 102 (8) | 17 (4) | 0 (2) | 71 (13) | 0 (1) |
| Opponent | Character | 17 | 38 (17) | 38 | 0 | 42 | 18% | 1.9 | 54 (1) | 22 (8) | 55 (7) | 54 (8) | 26 (8) |
| Opponent | Clean-up | 6 | 76 (6) | 0 | 76 | 10 | 83% | 6.0 | 18 (2) | 104 (2) | 62 (2) | 109 (3) | 51 (3) |
| Opponent | Fast Hammer | 8 | 51 (8) | 25 | 26 | 40 | 62% | 3.3 | 65 (2) | 62 (4) | 0 (2) | 62 (6) | 0 (2) |
| Opponent | Hammer | 10 | 22 (10) | 17 | 5 | 37 | 60% | 3.8 | - | 5 (7) | 50 (3) | 30 (5) | 15 (5) |
| Opponent | Holder | 5 | 104 (5) | 0 | 104 | 5 | 100% | - | 0 (1) | 149 (4) | - | 82 (3) | 140 (2) |
| Opponent | Shooter | 7 | 61 (7) | 0 | 61 | 48 | 0% | 2.4 | 99 (2) | 0 (1) | 57 (4) | 132 (4) | 0 (3) |
| Opponent | Support | 2 | 0 (2) | 0 | 0 | 0 | 100% | - | 0 (1) | - | - | 0 (1) | - |
| Opponent | War machine | 4 | 0 (4) | 0 | 0 | 0 | 25% | 1.0 | 0 (2) | - | 0 (2) | - | 0 (4) |
| Opponent | Wizard | 4 | 0 (4) | 0 | 0 | 0 | 0% | 2.5 | - | 0 (2) | 0 (2) | - | 0 (4) |

### Charged fights: h9-opp-81fb82c-p4

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 386 | 111 | 1.2 | 1.2 | 89 | 27 | +61 | 2 of 5 | 4 of 5 | -85 | +98 |
| Mine | Chaos Dwarfs | 3 | 359 | 140 | 1.3 | 1.2 | 105 | 0 | +105 | 3 of 4 | 2 of 4 | +0 | +140 |
| **Mine** | all armies | 7 | 374 | 123 | 1.3 | 1.2 | 96 | 15 | +81 | 5 of 9 | 6 of 9 | -42 | +116 |
| Opponent | High Elf Realms | 1 | 0 | 450 | 5.0 | 1.0 | 90 | 23 | +67 | 4 of 5 | 2 of 5 | - | +67 |
| Opponent | Kingdom of Bretonnia | 2 | 0 | 319 | 3.5 | 1.0 | 91 | 0 | +91 | 0 of 7 | 6 of 7 | - | +91 |
| Opponent | Skaven | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Warriors of Chaos | 2 | 0 | 656 | 4.0 | 1.0 | 164 | 61 | +103 | 3 of 8 | 5 of 8 | - | +103 |
| Opponent | Wood Elf Realms | 1 | 0 | 340 | 4.0 | 1.0 | 85 | 0 | +85 | 0 of 4 | 3 of 4 | - | +85 |
| **Opponent** | all armies | 7 | 0 | 392 | 3.4 | 1.0 | 114 | 25 | +89 | 7 of 24 | 16 of 24 | - | +89 |

### Effective charges: h9-opp-81fb82c-p4

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 5 | 2 (net -42) | 0 | 1 (net +118) | 1 (net +137) | 0 | 1 (net +137) | 0 | 20% (1 of 5) |
| Mine | Chaos Dwarfs | 4 | 0 | 0 | 3 (net +140) | 0 | 0 | 1 (net +0) | 0 | 75% (3 of 4) |
| Opponent | High Elf Realms | 5 | 1 (net +0) | 0 | 3 (net +112) | 0 | 0 | 1 (net +0) | 0 | 60% (3 of 5) |
| Opponent | Kingdom of Bretonnia | 7 | 1 (net +170) | 0 | 0 | 3 (net +83) | 3 (net +73) | 0 | 0 | 0% (0 of 7) |
| Opponent | Warriors of Chaos | 8 | 3 (net +111) | 0 | 2 (net +111) | 0 | 2 (net +92) | 1 (net +85) | 0 | 25% (2 of 8) |
| Opponent | Wood Elf Realms | 4 | 0 | 0 | 1 (net +230) | 0 | 0 | 2 (net +55) | 1 | 33% (1 of 3) |

### Charged fights, damage counted: h9-opp-81fb82c-p4

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 2 | 98 | 254 | -42 | 31 | 54 | -24 | -24.1 |
| Mine | Effective (55-75%) | 4 | 240 | 196 | +134 | 186 | 45 | +141 | +58.5 |
| Mine | 76-89% | 1 | 52 | 137 | +137 | 137 | 0 | +137 | +263.5 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 198 | 174 | +68 | 68 | 89 | -20 | -10.2 |
| Mine | All fights | 9 | 178 | 197 | +81 | 120 | 52 | +68 | +38.2 |
| Opponent | Long shot (under 50%) | 5 | 450 | 307 | +100 | 198 | 148 | +50 | +11.2 |
| Opponent | Effective (55-75%) | 6 | 230 | 236 | +131 | 177 | 19 | +158 | +68.7 |
| Opponent | 76-89% | 3 | 308 | 140 | +83 | 83 | 23 | +60 | +19.6 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 4 | 63 | 88 | +49 | 75 | 0 | +75 | +119.1 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 5 | 381 | 70 | +81 | 81 | 0 | +81 | +21.2 |
| Opponent | No odds | 1 | 0 | 91 | +0 | 0 | 0 | +0 | - |
| Opponent | All fights | 24 | 279 | 174 | +89 | 125 | 38 | +87 | +31.1 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| h9-opp-81fb82c-p4 | move | 53 | 11 (21%) | 9 (17%) | 7 (13%) | 35 (66%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0115, L0132 |
| Horn of the Wild Hunt | Opponent | L0333 |
| Periapt of Soul Exchange | Opponent | L0420 |
| Ring of Doom | Mine | L0216, L0232 |
| Ring of Doom | Opponent | L0115, L0333 |

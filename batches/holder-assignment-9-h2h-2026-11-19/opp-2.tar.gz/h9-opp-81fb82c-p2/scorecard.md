# Doctrine scorecard: h9-opp-81fb82c-p2

### Scorecard: h9-opp-81fb82c-p2

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0108 | 6 | 1 | Mine | no | 1 | 5 | 1 | 3 | 0 | 0 | 0 | 0 |
| L0108 | 6 | 1 | Opponent | no | 3 | 6 | 0 | 0 | 0 | 0 | 0 | 36 |
| L0123 | 3 | 1 | Mine | yes | 14 | 6 | 1 | 1 | 1 | 0 | 0 | 0 |
| L0123 | 3 | 1 | Opponent | no | 1 | 3 | 4 | 1 | 0 | 0 | 0 | 0 |
| L0207 | 3 | 1 | Mine | no | 4 | - | 0 | 3 | 0 | 0 | 0 | 170 |
| L0207 | 3 | 1 | Opponent | no | 3 | 3 | 1 | 0 | 0 | 0 | 0 | 45 |
| L0224 | 2 | 1 | Mine | - | - | 3 | 4 | 4 | 0 | 0 | 0 | 52 |
| L0224 | 2 | 1 | Opponent | - | - | - | 1 | 3 | 0 | 0 | 0 | 0 |
| L0308 | 2 | 1 | Mine | - | - | 2 | 4 | 3 | 0 | 0 | 0 | 110 |
| L0308 | 2 | 1 | Opponent | - | - | - | 0 | 2 | 0 | 0 | 0 | 380 |
| L0325 | 1 | 1 | Mine | no | 1 | 2 | 1 | 0 | 0 | 0 | 0 | 0 |
| L0325 | 1 | 1 | Opponent | no | 8 | 3 | 1 | 2 | 0 | 0 | 0 | 68 |
| L0411 | 3 | 1 | Mine | no | 2 | 2 | 4 | 2 | 1 | 0 | 0 | 310 |
| L0411 | 3 | 1 | Opponent | yes | 16 | - | 0 | 0 | 0 | 0 | 0 | 165 |
| L0513 | 3 | 1 | Mine | no | 2 | - | 0 | 2 | 0 | 0 | 0 | 263 |
| L0513 | 3 | 1 | Opponent | no | 5 | 6 | 1 | 1 | 1 | 0 | 0 | 339 |
| **Average** | | | Mine | 17% | 4.0 | 3.3 | 1.9 | 2.2 | 0.2 | 0.0 | 0.0 | 113.1 |
| **Average** | | | Opponent | 17% | 6.0 | 4.2 | 1.0 | 1.1 | 0.1 | 0.0 | 0.0 | 129.1 |

### KPIs: h9-opp-81fb82c-p2

Rules off - Mine only: HOLDER ASSIGNMENT, QUARTER ODDS, WALK PROMISE, REAL GROUND, RISK ON THE WAY, ONE ROUTE, MARCH WHEELS ONLY, LATE ONLY FROM HERE, WALKS ON ITS ROUTE.

Morten 2026-11-10; 8 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 21% (7 of 34) | 26% (11 of 42) | 24% (18 of 76) |
| Winner chose to follow up after the loser gave ground |  | 83% (5 of 6); on the table 100% | 83% (5 of 6); on the table 83% | 83% (10 of 12); on the table 92% |
| Winner chose to pursue after the loser fell back in good order |  | - | 100% (3 of 3); on the table 100% | 100% (3 of 3); on the table 100% |
| Winner chose to pursue after the loser fled |  | - | 100% (4 of 4); on the table 100% | 100% (4 of 4); on the table 100% |
| Winner chose to follow up or pursue (all three) |  | 83% (5 of 6); on the table 100% | 92% (12 of 13); on the table 92% | 89% (17 of 19); on the table 95% |
| Magic missiles tried each own turn | 50%+ | 33% (44 of 132) | 47% (17 of 36) | 36% (61 of 168) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 40% (44 of 111) | 57% (17 of 30) | 43% (61 of 141) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 33% (4 of 12) | - | 33% (4 of 12) |
| Points that never fought | lower | 55% (8569 of 15595) | 56% (8951 of 15995) | 55% (17520 of 31590) |
|   infantry points that never fought | lower | 57% (2634 of 4652) | 66% (1951 of 2965) | 60% (4585 of 7617) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 47% (25 of 53) | 56% (36 of 64) | 52% (61 of 117) |
| Bound items with a magic missile used (at least once a game) |  | 83% (5 of 6); 1.8 uses a game | 100% (3 of 3); 1.1 uses a game | 89% (8 of 9); 1.4 uses a game |
| Bound items with another spell used |  | 100% (2 of 2); 1.1 uses a game | 33% (1 of 3); 0.1 uses a game | 60% (3 of 5); 0.6 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 62% (5 of 8); 0.6 uses a game | 0% (0 of 4); 0.0 uses a game | 42% (5 of 12); 0.3 uses a game |
|   their share of the points of units over 100 pts | lower | 44% (5054 of 11586) | 54% (7481 of 13927) | 49% (12535 of 25513) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 5.4 (49%) | 1.2 (53%) | 6.6 (50%) |
| MARCHED: its unit marched | 2.8 (25%) | 0.4 (16%) | 3.1 (23%) |
| CHARGED: its unit charged | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| IN COMBAT: engaged in combat | 1.0 (9%) | 0.2 (11%) | 1.2 (9%) |
| GONE: slain | 1.6 (15%) | 0.5 (21%) | 2.1 (16%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.4 | 1.5 | 3.4 | 7.6 | 0.5 | 1.6 |
| not cast | 3.1 | 2.2 | 5.6 | 13.4 | 1.0 | 23.9 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.0 (4%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.9 (83%) | 0.4 (7%) | 6.6 (50%) | 0.4 (38%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 3.1 (23%) | 0.0 (0%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.4 (12%) | 0.2 (11%) | 0.6 (11%) | 1.2 (9%) | 0.1 (12%) | 0.0 (0%) |
| GONE: slain | 1.0 (32%) | 0.0 (0%) | 1.4 (24%) | 2.1 (16%) | 0.0 (0%) | 2.9 (12%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.1 (6%) | 0.0 (0%) | 0.1 (1%) | 0.5 (50%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.8 (56%) | 0.0 (0%) | 3.2 (58%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 20.0 (84%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 4.0 a game | 0.5 a game | 2.2 a game |
| stood (cast and not dispelled) | 59% (19 of 32) | 50% (2 of 4) | 58% (21 of 36) |
| the unit moved after it | 58% (11 of 19) | 100% (2 of 2) | 62% (13 of 21) |
| it charged on its next turn | 11% (2 of 19) | 0% (0 of 2) | 10% (2 of 21) |
| the enemy charged it first | 5% (1 of 19) | 0% (0 of 2) | 5% (1 of 21) |
| it fought by the end of its next turn | 11% (2 of 19) | 0% (0 of 2) | 10% (2 of 21) |
| it moved out of a charge the enemy had planned (not charged first) | 5% (1 of 19) | 0% (0 of 2) | 5% (1 of 21) |
| none of these (no charge, no fight, no charge escaped) | 79% (15 of 19) | 100% (2 of 2) | 81% (17 of 21) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 65% (104 of 160) | 53% (101 of 191) | 58% (205 of 351) |
|   cavalry | 33% (2 of 6) | 50% (16 of 32) | 47% (18 of 38) |
|   character | 65% (13 of 20) | 6% (1 of 16) | 39% (14 of 36) |
|   chariot | 53% (17 of 32) | 73% (11 of 15) | 60% (28 of 47) |
|   infantry | 62% (21 of 34) | 63% (26 of 41) | 63% (47 of 75) |
|   war machine | 75% (51 of 68) | 54% (47 of 87) | 63% (98 of 155) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.6 (23%) | 2.6 (23%) | 4.2 (23%) |
| CHARGED: it charged | 0.6 (9%) | 0.6 (6%) | 1.2 (7%) |
| IN COMBAT: it fought this turn or the last | 0.2 (4%) | 0.4 (3%) | 0.6 (3%) |
| MOVED: a war machine that moved | 1.0 (14%) | 2.2 (20%) | 3.2 (18%) |
| NO TARGET IN RANGE | 1.6 (23%) | 1.2 (11%) | 2.9 (16%) |
| ONLY IN COMBAT: the only targets were in combat | 0.2 (4%) | 1.4 (12%) | 1.6 (9%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.1 (16%) | 1.9 (17%) | 3.0 (16%) |
| SHELTERED: the target was sheltered | 0.2 (4%) | 0.0 (0%) | 0.2 (1%) |
| OTHER BAR | 0.2 (4%) | 0.9 (8%) | 1.1 (6%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 3.6 | 2.4 | 66% | 10.2 pts | 37 pts |
| character | 2.0 | 1.5 | 50% | 12.1 pts | 24 pts |
| chariot | 3.5 | 6.1 | 43% | 32.3 pts | 113 pts |
| infantry | 9.0 | 4.6 | 69% | 9.5 pts | 86 pts |
| war machine | 12.2 | 15.8 | 57% | 34.3 pts | 420 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 2.9 | 2.9 | 2.9 |
| Charges that made contact a game | 2.0 | 2.6 | 2.3 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.40 declared, 0.20 contact (5 units) | 0.25 declared, 0.25 contact (4 units) | 0.33 declared, 0.22 contact (9 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 0.67 declared, 0.67 contact (3 units) | 0.67 declared, 0.67 contact (3 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.40 declared, 0.29 contact (52 units) | 0.38 declared, 0.34 contact (53 units) | 0.39 declared, 0.31 contact (105 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 33% (3 of 9) | 33% (2 of 6) | 0% (0 of 1) | 31% (5 of 16) |
| Character in a unit | 62% (8 of 13) | 44% (4 of 9) | - | 55% (12 of 22) |
| Character on its own | 75% (6 of 8) | 67% (4 of 6) | 62% (5 of 8) | 68% (15 of 22) |
| Chariot | 100% (1 of 1) | 50% (4 of 8) | - | 56% (5 of 9) |
| Infantry | 50% (4 of 8) | 23% (3 of 13) | 0% (0 of 2) | 30% (7 of 23) |
| Monster | 25% (1 of 4) | - | - | 25% (1 of 4) |
| War Machines | 74% (14 of 19) | 100% (2 of 2) | - | 76% (16 of 21) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 100% (3 of 3); on the table 100% | 32% (33 of 102) | 41% | 32% (7 of 22) | 83% (5 of 6); 3.5 uses a game | 100% (2 of 2); 2.2 uses a game | 83% (5 of 6); 1.2 uses a game |
| Chaos Dwarfs | 3 | 67% (2 of 3); on the table 100% | 37% (11 of 30) | 57% | 62% (15 of 24) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |
| Dwarfen Mountain Holds | 1 | - | - | 100% | 43% (3 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 3 | 100% (7 of 7); on the table 100% | 42% (5 of 12) | 58% | 50% (15 of 30) | 0.0 uses a game | 100% (1 of 1); 0.3 uses a game | 0% (0 of 3); 0.0 uses a game |
| Grand Cathay | 1 | 0% (0 of 1); on the table 0% | 75% (9 of 12) | 44% | 62% (5 of 8) | 100% (2 of 2); 8.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| High Elf Realms | 1 | - | 0% (0 of 6) | 100% | 62% (5 of 8) | 100% (1 of 1); 1.0 uses a game | 0% (0 of 2); 0.0 uses a game | 0.0 uses a game |
| Tomb Kings of Khemri | 1 | 100% (4 of 4); on the table 100% | - | 33% | 40% (2 of 5) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 2 | 100% (1 of 1); on the table 100% | 50% (3 of 6) | 48% | 69% (9 of 13) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (h9-opp-81fb82c-p2, 8 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 38% (6) | 40% (4) | 38% (10) |
| ...free all their last turn and able to turn (per game) | 0.38 | 0.38 | 0.75 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.12 | 0.00 | 0.12 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.25 | 0.25 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.12 | 0.00 | 0.12 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.12 | 0.12 |

### Quality by phase: h9-opp-81fb82c-p2

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.4 | 2.4 |
| Strategy | Charge objectives carried out (made contact) | 55% (11 of 20) | 45% (9 of 20) |
| Strategy | Shoot objectives carried out (shot that target) | 45% (36 of 80) | 41% (38 of 93) |
| Strategy | Support requests answered (helper made contact too) | 50% (1 of 2) | 100% (2 of 2) |
| Strategy | Hexes on a unit its side charged or shot that turn | - | 62% (5 of 8) |
| Strategy | Joined characters whose unit fought | 38% (8 of 21) | 60% (6 of 10) |
| Strategy | Lone characters that fought | 56% (10 of 18) | 52% (12 of 23) |
| Movement | Charges halted short of contact | 0.1 | 0.1 |
| Movement | Idle units | 2.2 | 1.1 |
| Movement | Points that never moved of their own | 113.1 | 129.1 |
| Movement | Fights charged into per game | 1.6 | 2.1 |
| Movement | Charges with odds: long shots (under 50%) | 1 of 12, net +0 | 2 of 16, net -25 |
| Movement | Charges with odds: sweet spot (55-75%) | 2 of 12, net +0 | 0 of 16 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 3 of 12, net +147 | 2 of 16, net +70 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 4 of 12, net -12 | 5 of 16, net +258 |
| Shooting | Shots by shooting units (incl. breath weapons) | 6.6 | 7.4 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 34% (18 of 53) | 46% (27 of 59) |
| Shooting | Points destroyed by shooting units | 58.1 | 55.2 |
| Shooting | War machine shots | 6.4 | 5.9 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 51% (26 of 51) | 60% (28 of 47) |
| Shooting | Points destroyed by war machines | 56.2 | 121.9 |
| Magic | Magic missiles cast | 3.4 | 1.4 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 26% (7 of 27) | 27% (3 of 11) |
| Magic | Wounds caused by magic missiles | 8.4 | 1.1 |
| Magic | Wounds caused by other spells | 0.8 | 0.2 |
| Magic | Points destroyed by magic (all spells) | 67.8 | 10.1 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.2 / 0.0 / 0.9 / 0.0 | 2.2 / 1.0 / 0.1 / 0.2 |
| Combat | Points destroyed in combat | 183.0 | 119.0 |
| Combat | Points run down | 18.4 | 162.5 |
| Combat | Net points per charged fight, damage counted | +64 | +120 |
| Combat | Net per 100 charger points, damage counted | +21.5 | +42.4 |
| Combat | First round won (charged fights) | 75% | 82% |
| Combat | Net points per charged fight | +37 | +132 |
| Combat | Net points per supported fight / lone fight | +0 / +44 | +395 / +76 |
| Combat | Charged fights on a top-3 enemy unit | 5 of 13 | 6 of 17 |
| Game | Points lost | 602.6 | 454.2 |
| Game | VP from objectives | 730.0 | 903.8 |
| Game | Lone holders (player turns) | 4.0 | 6.0 |

- Mine won / drew / lost: 2 / 2 / 4 of 8 ended games (of 8); mean margin (Mine - Opponent) -338 VP
- The side that went first won 2 of 6 games with a winner
- Points traded per game (both sides' losses): 1057
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: h9-opp-81fb82c-p2

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.2 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.1 | +1.6 | 0.0 | 0.0 | 0.1 | +36.2 | 0.0 | 0.0 |
| ALREADY CARRIED | 0.2 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARTILLERY RE-ROLL WEIGHED | 2.6 | +0.0 | 0.0 | 0.0 | 1.2 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | - | - | - | - | 0.1 | +0.9 | 0.0 | 0.0 |
| BEST OVERALL | 0.1 | +0.8 | 0.0 | 0.0 | - | - | - | - |
| BEST PRIZE | 0.1 | -19.3 | 0.0 | 0.0 | - | - | - | - |
| BLOWS WHERE AIMED | 0.6 | -45.4 | 80.8 | 0.0 | 0.6 | -60.5 | 146.4 | 24.4 |
| BOMBING RUN | - | - | - | - | 0.1 | +3.2 | 0.0 | 18.8 |
| CANNON PLAN MISSED | 0.6 | +0.0 | 20.2 | 13.8 | 1.4 | +0.0 | 138.6 | 0.0 |
| CANNON PLANNED TARGET | 5.8 | +117.0 | 201.2 | 31.2 | 4.8 | +385.8 | 622.9 | 0.0 |
| CANNON SIGHT KEPT | 1.4 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT SET-UP | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | -3.7 | 3.8 | 0.0 |
| CAST JOB | 0.5 | +5.7 | 0.0 | 0.0 | 0.6 | +47.9 | 155.1 | 0.0 |
| CASTER AWAY FROM SCREEN | 1.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CASTING BLOCK | 0.5 | +10.9 | 0.0 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | 2.4 | +0.0 | 0.0 | 16.2 | 0.2 | +0.0 | 0.0 | 50.0 |
| CASTS FROM BEHIND | - | - | - | - | 0.4 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | 0.6 | +29.8 | 0.0 | 27.1 | - | - | - | - |
| CHAFF PASSED | - | - | - | - | 0.2 | -0.3 | 17.5 | 0.0 |
| CHARACTER GUNS | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHARGE LOSSES | 6.5 | -422.9 | 0.0 | 282.5 | 5.4 | -229.8 | 0.0 | 189.5 |
| CHARGE NOT DECLARED | 0.8 | +0.0 | 99.1 | 0.0 | 0.1 | +0.0 | 8.1 | 24.4 |
| CHARGE NOW FIRST | 1.0 | +0.0 | 59.9 | 0.0 | 1.4 | +0.0 | 236.6 | 48.8 |
| CHARGER SLAIN LOST | 0.2 | -1.1 | 27.5 | 0.0 | 0.2 | -9.4 | 56.6 | 24.4 |
| CHEAP HELPER | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHEAPEST HOLDER | 0.8 | -39.9 | 18.4 | 0.0 | - | - | - | - |
| COMBAT PIVOT | - | - | - | - | 0.2 | +0.0 | 9.6 | 0.0 |
| CONVEYANCE SEARCH | 3.0 | +408.1 | 86.1 | 74.4 | 0.2 | +3.5 | 50.0 | 50.0 |
| COVER ONCE | 6.8 | -437.7 | 0.0 | 298.9 | 8.2 | -455.6 | 0.0 | 122.9 |
| DEPLOY BY FIGURES | 8.4 | -7.0 | 0.0 | 0.0 | 7.6 | -96.0 | 0.0 | 0.0 |
| EDGE GIVE GROUND | 0.1 | +0.1 | 0.0 | 0.0 | 0.1 | +0.1 | 10.1 | 0.0 |
| ENGINEER BY LORE | 0.5 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FALL BACK GOOD ORDER | 1.5 | +10.9 | 92.2 | 0.0 | 2.2 | +0.1 | 272.6 | 55.0 |
| FALLBACK BY WORTH | - | - | - | - | 0.8 | +0.0 | 0.0 | 0.0 |
| FALLS SHORT | 11.4 | +224.5 | 0.0 | 174.1 | 11.0 | +169.0 | 0.0 | 193.9 |
| FEATURE BUFFS | 3.8 | +98.6 | 0.0 | 3.8 | 1.0 | +31.9 | 0.0 | 7.5 |
| FIGHT LIFT | 0.1 | +2.2 | 0.0 | 0.0 | - | - | - | - |
| FIGHT TO THE END | 0.2 | +8.3 | 0.0 | 0.0 | 0.9 | +20.4 | 127.5 | 24.4 |
| FIRE AND FLEE | - | - | - | - | 0.1 | +3.1 | 0.0 | 20.5 |
| FIRE IN ORDER | 0.1 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 46.9 | 26.6 |
| FIVE ACTION | 45.4 | +2197.5 | 472.6 | 638.5 | 48.1 | +3907.2 | 1498.4 | 567.0 |
| FLANK NOT WEIGHED | 5.6 | +0.0 | 0.0 | 279.5 | 4.4 | +0.0 | 0.0 | 142.2 |
| FOCUS FIRE | - | - | - | - | 0.1 | +0.4 | 0.0 | 0.0 |
| FOLLOW UP WEIGHED | 0.4 | +77.7 | 0.0 | 45.5 | 0.2 | +37.4 | 0.0 | 0.0 |
| FOUR ROUNDS | 2.5 | +223.3 | 158.6 | 38.8 | 2.4 | +139.0 | 312.2 | 55.0 |
| FRIEND SHOOTS FIRST | 0.5 | -1.9 | 0.0 | 0.0 | 0.5 | -21.8 | 14.6 | 0.0 |
| FRIENDS SHOTS CHECKED | - | - | - | - | 0.1 | +9.9 | 0.0 | 0.0 |
| GROUND FLIERS | 0.1 | +0.5 | 0.0 | 0.0 | - | - | - | - |
| GUN FIGURES | 1.5 | +22.9 | 46.0 | 0.0 | 1.1 | +5.5 | 72.5 | 0.0 |
| GUN MASK | 0.4 | +4.7 | 0.0 | 0.0 | 2.0 | +33.1 | 0.0 | 0.0 |
| HARD STAY DROPPED | 1.9 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| HE SHOOTS OR CHARGES | 2.1 | +0.0 | 0.0 | 38.1 | 2.4 | +0.0 | 0.0 | 57.6 |
| HELPER UNSEEN | 0.2 | +0.0 | 27.5 | 0.0 | - | - | - | - |
| HIS CHARGE DENIED | 0.2 | +0.8 | 5.6 | 0.0 | 0.6 | +106.2 | 89.9 | 0.0 |
| HIS CHARGE LIST | 3.1 | +0.0 | 0.0 | 64.9 | 1.5 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 2.1 | +0.0 | 0.0 | 24.4 | 4.9 | +0.0 | 0.0 | 24.4 |
| HIS MOVE AND SHOT | 1.0 | -19.8 | 0.0 | 119.0 | 1.8 | -41.0 | 0.0 | 27.0 |
| HIS ONE QUARTER | - | - | - | - | 1.8 | +0.0 | 0.0 | 111.8 |
| HIS RANDOM MOVE | - | - | - | - | 3.8 | +0.0 | 0.0 | 38.4 |
| HIS SHOT LIST | 20.1 | +961.3 | 0.0 | 367.1 | 21.9 | +1098.2 | 0.0 | 325.6 |
| HIS TURN DENIED | 0.6 | +105.3 | 38.9 | 38.8 | 1.1 | +21.9 | 116.1 | 55.0 |
| HOLD ODDS | - | - | - | - | 12.6 | +0.0 | 0.0 | 171.6 |
| HOLDER ASSIGNMENT | - | - | - | - | 14.5 | +1416.8 | 0.0 | 179.1 |
| HOLDER AT DEPLOYMENT | 1.1 | +192.6 | 0.0 | 0.0 | - | - | - | - |
| HOLDS AMBUSHERS | 0.5 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 1.9 | -91.5 | 131.1 | 38.8 | 1.8 | -70.4 | 172.8 | 24.4 |
| HUNT IN PAIRS | - | - | - | - | 1.1 | +62.9 | 0.0 | 24.4 |
| IDLE COST | 5.1 | -58.2 | 0.0 | 17.5 | 7.5 | -139.0 | 0.0 | 75.6 |
| JOINT KNOWS CHALLENGE | 0.1 | -26.8 | 0.0 | 0.0 | 0.2 | -8.2 | 79.2 | 0.0 |
| KEEP FALLS | 0.1 | +0.9 | 0.0 | 0.0 | - | - | - | - |
| LANE BY FIGURES | 0.1 | +10.3 | 0.0 | 0.0 | 0.8 | +31.7 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 5.5 | +0.0 | 137.9 | 211.9 | 5.5 | +0.0 | 279.5 | 95.5 |
| LONE CHARACTER SAFE SPOT | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +5.6 | 0.0 | 0.0 |
| LONE WIZARD KEPT IN | 1.2 | +99.4 | 0.0 | 0.0 | 0.4 | +38.0 | 0.0 | 0.0 |
| LONG SHOT | 0.2 | +4.0 | 18.4 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| LURE BY WHAT IT DRAWS | - | - | - | - | 0.1 | -16.2 | 0.0 | 4.5 |
| MANOEUVRE | 1.4 | -8.6 | 0.0 | 13.9 | 1.4 | +24.1 | 0.0 | 20.1 |
| MARCH AT ESCAPER | 0.5 | +0.7 | 0.0 | 0.0 | 0.1 | +0.4 | 0.0 | 0.0 |
| MARCH BY THE SUM | 0.2 | +26.1 | 0.0 | 0.0 | 0.5 | +95.2 | 0.0 | 0.0 |
| MARCH CHECK | 1.2 | +139.3 | 0.0 | 92.8 | 0.8 | +61.1 | 0.0 | 0.0 |
| MARCH OVER CASTS | 0.2 | +5.1 | 0.0 | 10.1 | 0.5 | -70.4 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | - | - | - | - | 0.8 | +0.0 | 0.0 | 24.4 |
| MAX FOR POSITIONING | 6.1 | +101.6 | 0.0 | 172.2 | 4.1 | +109.1 | 0.0 | 80.2 |
| MISSILES IN THE MOVE | 5.1 | +220.0 | 0.0 | 168.8 | 3.8 | +130.9 | 0.0 | 38.6 |
| MISSILES NEXT TURN | 5.9 | +155.0 | 0.0 | 139.2 | 4.5 | +73.0 | 0.0 | 88.6 |
| MOVE SPELL IN RANGE | 0.2 | +11.4 | 0.0 | 72.5 | - | - | - | - |
| MOVE SPELL NOT WORTH | 0.1 | -0.1 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.6 | -17.0 | 39.6 | 41.9 | - | - | - | - |
| MOVE SPELL SPOT | 1.5 | +0.0 | 0.0 | 46.5 | 0.2 | +0.0 | 0.0 | 50.0 |
| MOVE TO CHARGE COMPUTED | 2.9 | +302.4 | 0.0 | 35.0 | 3.8 | +453.1 | 0.0 | 24.4 |
| MOVES UNITS SPELL | 0.2 | +13.8 | 0.0 | 0.0 | - | - | - | - |
| NEARER NOT NEEDED | 3.6 | +187.8 | 0.0 | 45.5 | 7.9 | +297.3 | 0.0 | 76.5 |
| NEXT CHARGE BY LIST | 4.8 | -373.2 | 24.4 | 113.4 | 6.1 | -254.6 | 22.8 | 31.9 |
| NEXT OBJECTIVE NEARER | 5.4 | -273.7 | 24.4 | 0.0 | 0.2 | -2.3 | 0.0 | 44.8 |
| NO DOUBLE ROUNDS | 1.8 | -63.7 | 114.1 | 38.8 | 1.9 | -57.4 | 242.9 | 48.8 |
| NO RALLY LEFT | 0.1 | +0.7 | 0.0 | 0.0 | - | - | - | - |
| NOT TURNED | - | - | - | - | 0.1 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 0.1 | -0.1 | 0.0 | 0.0 | 1.0 | -0.4 | 0.0 | 0.0 |
| OFF BEST | 0.6 | -15.5 | 0.0 | 14.6 | 0.8 | -21.2 | 0.0 | 0.0 |
| ONE CHARGE A CHARGER | 3.1 | +0.0 | 0.0 | 56.0 | 2.8 | +0.0 | 0.0 | 32.1 |
| ONE FIGHT FORMULA | 4.5 | -77.8 | 0.0 | 101.9 | 5.6 | -128.2 | 0.0 | 56.5 |
| ONE OBJECTIVE FORMULA | 4.2 | -19.5 | 0.0 | 56.0 | 4.8 | -65.7 | 0.0 | 128.4 |
| ONE ROUTE | - | - | - | - | 0.8 | +0.0 | 0.0 | 24.4 |
| ONE TARGET A SHOOTER | 17.9 | +689.8 | 0.0 | 241.5 | 16.2 | +545.0 | 0.0 | 187.5 |
| OPENS A LANE | - | - | - | - | 0.1 | +2.4 | 8.1 | 0.0 |
| OPENS UP | - | - | - | - | 0.2 | +17.8 | 27.5 | 0.0 |
| OVERRUNS AWAY | 0.4 | +38.4 | 0.0 | 38.8 | 0.4 | +83.4 | 32.0 | 24.4 |
| PATHS CROSS | 3.6 | +148.1 | 0.0 | 18.2 | 4.4 | +155.3 | 0.0 | 60.1 |
| PLAN RESULT | 39.9 | +510.6 | 446.5 | 921.6 | 43.5 | +925.7 | 835.1 | 688.9 |
| QUARTER ODDS | - | - | - | - | 8.0 | +1048.8 | 364.8 | 145.8 |
| RANDOM MOVE BY FIGURES | 1.5 | +25.4 | 0.0 | 0.0 | - | - | - | - |
| REAL GROUND | - | - | - | - | 0.8 | +0.0 | 0.0 | 24.4 |
| REDIRECT BY WHAT IT STOPS | 0.1 | -1.3 | 0.0 | 0.0 | - | - | - | - |
| REDIRECT COUNTER | 2.9 | +289.1 | 0.0 | 73.2 | 1.0 | -7.2 | 0.0 | 30.8 |
| REFORMS TO MEET IT | 1.2 | -105.2 | 0.0 | 10.6 | 0.5 | -22.9 | 0.0 | 0.0 |
| REFUSING RETIRES | 0.5 | +0.0 | 0.0 | 92.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | - | - | - | - | 0.5 | +10.6 | 0.0 | 18.8 |
| RISK BY ARC | 1.6 | -87.6 | 81.4 | 38.8 | 1.4 | +5.0 | 177.0 | 48.8 |
| RISK BY HIS FIGURE | 13.5 | -374.8 | 0.0 | 374.6 | 11.1 | -100.3 | 0.0 | 212.4 |
| RISK ON THE WAY | - | - | - | - | 0.5 | +0.0 | 0.0 | 24.4 |
| RUN DOWN | 1.4 | -22.7 | 102.0 | 38.8 | 1.9 | -7.3 | 227.1 | 48.8 |
| SAFER THAN THE JOB | 0.1 | +0.8 | 0.0 | 0.0 | - | - | - | - |
| SAME CHARGE LATER | - | - | - | - | 0.2 | -0.6 | 0.0 | 0.0 |
| SCOUT SPOT | 0.2 | +0.8 | 0.0 | 0.0 | 0.5 | -0.1 | 0.0 | 0.0 |
| SCOUT WAITS | 0.2 | +0.0 | 0.0 | 0.0 | 0.5 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.1 | +4.9 | 0.0 | 10.1 | - | - | - | - |
| SEARCH SPOT | 5.8 | +223.2 | 0.0 | 18.2 | 4.0 | +207.4 | 0.0 | 41.0 |
| SET UP TOGETHER | 0.1 | +0.2 | 0.0 | 0.0 | - | - | - | - |
| SET-UP ANY TARGET | 0.2 | +32.8 | 0.0 | 0.0 | 0.1 | +3.6 | 0.0 | 0.0 |
| SET-UP MISSED | 0.2 | +17.7 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | 0.2 | +0.5 | 0.0 | 0.0 | - | - | - | - |
| SHOOTS FROM THE BEST SPOT | 0.9 | +12.8 | 5.6 | 0.0 | 1.1 | +42.7 | 48.9 | 0.0 |
| SHORT GUN FORWARD | - | - | - | - | 0.2 | +0.0 | 0.0 | 0.0 |
| SHOT OR CHARGE | 0.2 | -3.8 | 5.6 | 0.0 | 0.5 | -15.8 | 71.5 | 0.0 |
| SHOT RISK POINTS | 11.5 | -12.6 | 0.0 | 314.0 | 11.6 | +46.7 | 0.0 | 336.1 |
| SHOTS IN THE MOVE | 13.5 | +432.6 | 0.0 | 191.9 | 16.2 | +931.7 | 0.0 | 116.1 |
| SPELL SETS UP CHARGE | 0.9 | +335.7 | 0.0 | 16.2 | 0.1 | +3.6 | 0.0 | 0.0 |
| SPELL WORTH | 0.4 | +8.8 | 46.5 | 44.4 | 1.5 | +14.1 | 50.0 | 50.0 |
| SPELLS IN THE FIGHT | 0.2 | +1.2 | 0.0 | 0.0 | 0.4 | -30.5 | 86.1 | 24.4 |
| STAND AND SHOOT | 0.5 | -9.6 | 38.9 | 38.8 | 0.2 | -4.3 | 8.1 | 24.4 |
| STANDS FOR A REASON | 0.5 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 17.4 | +0.0 | 314.0 | 168.1 | 19.0 | +0.0 | 1139.6 | 65.6 |
| STAY WORTH | 16.6 | +105.2 | 270.5 | 105.0 | 19.0 | +193.6 | 375.6 | 146.2 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SUPPORT NARROWED | 0.9 | +0.0 | 53.9 | 0.0 | 0.8 | +0.0 | 214.2 | 48.8 |
| SURE REACH TOGETHER | 0.4 | +5.5 | 0.0 | 0.0 | 0.5 | +1.7 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 3.9 | +0.0 | 0.0 | 35.8 | 4.6 | +0.0 | 0.0 | 60.1 |
| THE PROMISE ADDS | 0.4 | -2.9 | 13.8 | 0.0 | 0.2 | -86.9 | 39.6 | 0.0 |
| THE PROMISED MOVE | 0.4 | +0.0 | 0.0 | 0.0 | 0.9 | +0.0 | 0.0 | 0.0 |
| TIED UP BY THE SUM | 0.4 | +24.7 | 13.1 | 38.8 | 0.5 | +37.2 | 36.2 | 24.4 |
| TIME ON OUR SIDE | 17.9 | +300.8 | 0.0 | 205.1 | 16.0 | +279.8 | 0.0 | 101.6 |
| WAITS AGAIN | 1.2 | +0.0 | 0.0 | 10.6 | 1.4 | +0.0 | 0.0 | 0.0 |
| WAR ENGINE CHARGES | 0.2 | +20.6 | 20.5 | 0.0 | - | - | - | - |
| WAR ENGINE JOBS | 0.6 | +0.0 | 59.8 | 77.5 | - | - | - | - |
| WHO HITS BACK | 0.4 | +25.6 | 0.0 | 9.6 | 0.2 | +13.0 | 0.0 | 0.0 |
| WHOLE FIGHT | 0.1 | +8.8 | 18.4 | 0.0 | 0.2 | +8.8 | 92.0 | 0.0 |
| WHOLE FIGHT GAIN | - | - | - | - | 0.1 | +0.4 | 39.6 | 0.0 |
| WIDER SPREAD | 1.8 | -6.5 | 104.2 | 38.8 | 1.5 | +3.5 | 156.2 | 48.8 |
| WOUNDS ON THE RANKS | 2.2 | +166.4 | 0.0 | 125.8 | 1.6 | +67.3 | 0.0 | 71.6 |

### Rule changes: h9-opp-81fb82c-p2

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HOLDER ASSIGNMENT | 116 | 116 | 108 | 13.50 | +8426 | +78.0 |
| LEGAL CHARGES ONLY | 88 | 88 | 88 | 11.00 | +0 | +0.0 |
| HIS SHOT LIST | 336 | 336 | 82 | 10.25 | +2420 | +29.5 |
| ONE TARGET A SHOOTER | 273 | 273 | 78 | 9.75 | +985 | +12.6 |
| DEPLOY BY FIGURES | 128 | 128 | 76 | 9.50 | +1250 | +16.4 |
| SEARCH SPOT | 78 | 78 | 72 | 9.00 | +3445 | +47.8 |
| TIME ON OUR SIDE | 271 | 245 | 67 | 8.38 | +365 | +5.4 |
| PATHS CROSS | 64 | 64 | 64 | 8.00 | +2427 | +37.9 |
| FIVE ACTION | 748 | 747 | 42 | 5.25 | +2803 | +66.7 |
| SHOT RISK POINTS | 185 | 185 | 35 | 4.38 | +1616 | +46.2 |
| ARTILLERY RE-ROLL WEIGHED | 31 | 31 | 31 | 3.88 | +0 | +0.0 |
| MOVE TO CHARGE COMPUTED | 53 | 53 | 29 | 3.62 | +1781 | +61.4 |
| HARD STAY DROPPED | 23 | 23 | 23 | 2.88 | +0 | +0.0 |
| FOUR ROUNDS | 39 | 38 | 21 | 2.62 | +1431 | +68.1 |
| COVER ONCE | 120 | 100 | 20 | 2.50 | +378 | +18.9 |
| FALLS SHORT | 179 | 142 | 16 | 2.00 | +169 | +10.6 |
| CANNON SIGHT KEPT | 14 | 14 | 14 | 1.75 | +0 | +0.0 |
| IDLE COST | 101 | 81 | 14 | 1.75 | +196 | +14.0 |
| WOUNDS ON THE RANKS | 31 | 31 | 14 | 1.75 | +507 | +36.2 |
| CHARGE LOSSES | 95 | 95 | 13 | 1.62 | +1160 | +89.2 |
| LONE WIZARD KEPT IN | 13 | 13 | 13 | 1.62 | +1099 | +84.5 |
| MAX FOR POSITIONING | 82 | 80 | 13 | 1.62 | +21 | +1.7 |
| CANNON PLANNED TARGET | 84 | 84 | 12 | 1.50 | +24 | +2.0 |
| MISSILES IN THE MOVE | 71 | 53 | 12 | 1.50 | +113 | +9.4 |
| RISK BY HIS FIGURE | 197 | 197 | 12 | 1.50 | +1151 | +95.9 |
| SHOTS IN THE MOVE | 238 | 214 | 12 | 1.50 | +471 | +39.2 |
| MARCH CHECK | 16 | 16 | 11 | 1.38 | +491 | +44.6 |
| OFF BEST | 11 | 11 | 11 | 1.38 | -293 | -26.7 |
| QUARTER ODDS | 64 | 64 | 11 | 1.38 | +1295 | +117.8 |
| CASTER AWAY FROM SCREEN | 9 | 9 | 9 | 1.12 | +0 | +0.0 |
| FEATURE BUFFS | 38 | 38 | 8 | 1.00 | +144 | +18.0 |
| MANOEUVRE | 22 | 22 | 8 | 1.00 | +266 | +33.2 |
| NEXT OBJECTIVE NEARER | 45 | 45 | 8 | 1.00 | +172 | +21.5 |
| SHOOTS FROM THE BEST SPOT | 16 | 16 | 8 | 1.00 | +55 | +6.9 |
| ADVANCE LANE KEPT | 7 | 7 | 7 | 0.88 | +0 | +0.0 |
| CHARGE NOT DECLARED | 7 | 7 | 7 | 0.88 | -945 | -134.9 |
| LANE BY FIGURES | 7 | 7 | 7 | 0.88 | +336 | +47.9 |
| FIRE IN ORDER | 6 | 6 | 6 | 0.75 | +0 | +0.0 |
| MARCH BY THE SUM | 6 | 6 | 6 | 0.75 | +971 | +161.8 |
| REDIRECT COUNTER | 31 | 25 | 6 | 0.75 | +875 | +145.9 |
| SCOUT WAITS | 6 | 6 | 6 | 0.75 | +0 | +0.0 |
| CHARGE NOW FIRST | 19 | 19 | 5 | 0.62 | -152 | -30.4 |
| FOLLOW UP WEIGHED | 5 | 5 | 5 | 0.62 | +921 | +184.1 |
| HIS TURN DENIED | 14 | 14 | 5 | 0.62 | +430 | +86.0 |
| HOLDER AT DEPLOYMENT | 9 | 9 | 5 | 0.62 | +190 | +37.9 |
| HOLDS AMBUSHERS | 5 | 5 | 5 | 0.62 | +0 | +0.0 |
| NEXT CHARGE BY LIST | 87 | 87 | 5 | 0.62 | +149 | +29.8 |
| ONE OBJECTIVE FORMULA | 72 | 59 | 5 | 0.62 | +217 | +43.3 |
| RISK BY ARC | 24 | 23 | 5 | 0.62 | +195 | +39.0 |
| STAY WORTH | 285 | 272 | 5 | 0.62 | +179 | +35.9 |
| WHO HITS BACK | 5 | 5 | 5 | 0.62 | +224 | +44.8 |
| CAST JOB | 9 | 9 | 4 | 0.50 | +80 | +19.9 |
| RANDOM MOVE BY FIGURES | 12 | 12 | 4 | 0.50 | +203 | +50.9 |
| RESERVE FALL BACK | 4 | 4 | 4 | 0.50 | +84 | +21.1 |
| CASTS FROM BEHIND | 3 | 3 | 3 | 0.38 | +0 | +0.0 |
| CHAFF IN THE MOVE | 5 | 5 | 3 | 0.38 | +75 | +24.9 |
| GUN MASK | 19 | 19 | 3 | 0.38 | +45 | +15.0 |
| NEARER NOT NEEDED | 92 | 89 | 3 | 0.38 | +86 | +28.6 |
| SURE REACH TOGETHER | 7 | 7 | 3 | 0.38 | +2 | +0.5 |
| TIED UP BY THE SUM | 7 | 6 | 3 | 0.38 | +95 | +31.6 |
| AFTERMATH IN POINTS | 2 | 2 | 2 | 0.25 | +303 | +151.4 |
| CHAFF PASSED | 2 | 2 | 2 | 0.25 | -2 | -1.2 |
| COMBAT PIVOT | 2 | 2 | 2 | 0.25 | +0 | +0.0 |
| HIS MOVE AND SHOT | 22 | 22 | 2 | 0.25 | +1 | +0.6 |
| MISSILES NEXT TURN | 83 | 60 | 2 | 0.25 | +13 | +6.3 |
| MOVES UNITS SPELL | 2 | 2 | 2 | 0.25 | +110 | +55.1 |
| ONE FIGHT FORMULA | 81 | 42 | 2 | 0.25 | +7 | +3.7 |
| OPENS UP | 2 | 2 | 2 | 0.25 | +114 | +57.1 |
| OVERRUNS AWAY | 6 | 6 | 2 | 0.25 | +132 | +65.8 |
| REFUSING RETIRES | 5 | 5 | 2 | 0.25 | -0 | -0.1 |
| SHOOTERS IN TWO RANKS | 2 | 2 | 2 | 0.25 | +4 | +2.0 |
| SHORT GUN FORWARD | 2 | 2 | 2 | 0.25 | +0 | +0.0 |
| WAR ENGINE CHARGES | 2 | 2 | 2 | 0.25 | +37 | +18.7 |
| BEST OVERALL | 1 | 1 | 1 | 0.12 | +7 | +6.8 |
| BEST PRIZE | 1 | 1 | 1 | 0.12 | -154 | -154.5 |
| BOMBING RUN | 1 | 1 | 1 | 0.12 | +26 | +26.0 |
| CARRIES OUT SET-UP | 2 | 2 | 1 | 0.12 | -29 | -29.3 |
| FIGHT TO THE END | 9 | 9 | 1 | 0.12 | +150 | +149.6 |
| FIRE AND FLEE | 1 | 1 | 1 | 0.12 | +25 | +24.6 |
| FOCUS FIRE | 1 | 1 | 1 | 0.12 | +3 | +3.3 |
| FRIENDS SHOTS CHECKED | 1 | 1 | 1 | 0.12 | +79 | +79.4 |
| HIS CHARGE DENIED | 7 | 7 | 1 | 0.12 | +357 | +357.0 |
| HONEST WORTH | 29 | 28 | 1 | 0.12 | +8 | +7.8 |
| KEEP FALLS | 1 | 1 | 1 | 0.12 | +7 | +7.2 |
| NO RALLY LEFT | 1 | 1 | 1 | 0.12 | +3 | +3.4 |
| SAFER THAN THE JOB | 1 | 1 | 1 | 0.12 | +7 | +6.8 |
| STUCK PIVOT | 1 | 1 | 1 | 0.12 | +0 | +0.0 |
| WAR ENGINE JOBS | 5 | 5 | 1 | 0.12 | -0 | -0.3 |
| WIDER SPREAD | 26 | 26 | 1 | 0.12 | +0 | +0.5 |
| ALREADY CARRIED | 2 | not checked | - | - | - | - |
| BACKUP TARGETS | 1 | not checked | - | - | - | - |
| BLOWS WHERE AIMED | 10 | 10 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 16 | 16 | 0 | 0.00 | - | - |
| CASTING BLOCK | 4 | 4 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 21 | trace | - | - | - | - |
| CHARACTER GUNS | 1 | 1 | 0 | 0.00 | - | - |
| CHARGER SLAIN LOST | 4 | 4 | 0 | 0.00 | - | - |
| CHEAP HELPER | 1 | not checked | - | - | - | - |
| CHEAPEST HOLDER | 6 | 6 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 26 | not checked | - | - | - | - |
| EDGE GIVE GROUND | 2 | 2 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 30 | 29 | 0 | 0.00 | - | - |
| FALLBACK BY WORTH | 6 | 6 | 0 | 0.00 | - | - |
| FIGHT LIFT | 1 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 80 | not checked | - | - | - | - |
| FRIEND SHOOTS FIRST | 8 | 8 | 0 | 0.00 | - | - |
| GROUND FLIERS | 1 | not checked | - | - | - | - |
| GUN FIGURES | 21 | not checked | - | - | - | - |
| HE SHOOTS OR CHARGES | 36 | 36 | 0 | 0.00 | - | - |
| HELPER UNSEEN | 2 | 2 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 37 | 37 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 56 | 56 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 14 | 14 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 30 | 30 | 0 | 0.00 | - | - |
| HOLD ODDS | 101 | 101 | 0 | 0.00 | - | - |
| HUNT IN PAIRS | 9 | 3 | 0 | 0.00 | - | - |
| JOINT KNOWS CHALLENGE | 3 | 3 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 2 | not checked | - | - | - | - |
| LONG SHOT | 3 | 3 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 1 | 1 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 5 | trace | - | - | - | - |
| MARCH OVER CASTS | 6 | 6 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 6 | 6 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 2 | 2 | 0 | 0.00 | - | - |
| MOVE SPELL NOT WORTH | 1 | not checked | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 5 | trace | - | - | - | - |
| MOVE SPELL SPOT | 14 | not checked | - | - | - | - |
| NO DOUBLE ROUNDS | 29 | 28 | 0 | 0.00 | - | - |
| NOT TURNED | 1 | 1 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 9 | not checked | - | - | - | - |
| ONE CHARGE A CHARGER | 47 | 47 | 0 | 0.00 | - | - |
| ONE ROUTE | 6 | 6 | 0 | 0.00 | - | - |
| OPENS A LANE | 1 | 1 | 0 | 0.00 | - | - |
| PLAN RESULT | 667 | trace | - | - | - | - |
| REAL GROUND | 6 | 6 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 1 | 1 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 14 | 14 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 4 | 4 | 0 | 0.00 | - | - |
| RUN DOWN | 26 | 25 | 0 | 0.00 | - | - |
| SAME CHARGE LATER | 2 | 2 | 0 | 0.00 | - | - |
| SCOUT SPOT | 6 | 6 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 1 | 1 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 1 | 1 | 0 | 0.00 | - | - |
| SET-UP ANY TARGET | 3 | not checked | - | - | - | - |
| SET-UP MISSED | 2 | trace | - | - | - | - |
| SHOT OR CHARGE | 6 | 6 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 8 | not checked | - | - | - | - |
| SPELL WORTH | 15 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 5 | 5 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 6 | 6 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 5 | 5 | 0 | 0.00 | - | - |
| STANDS STILL | 291 | 291 | 0 | 0.00 | - | - |
| SUPPORT NARROWED | 13 | 13 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 68 | not checked | - | - | - | - |
| THE PROMISE ADDS | 5 | 5 | 0 | 0.00 | - | - |
| THE PROMISED MOVE | 10 | not checked | - | - | - | - |
| WAITS AGAIN | 21 | 21 | 0 | 0.00 | - | - |
| WHOLE FIGHT | 3 | 3 | 0 | 0.00 | - | - |
| WHOLE FIGHT GAIN | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: h9-opp-81fb82c-p2

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 0.38 | 0.75 | 23.7 |
| CHARGE NOT DECLARED | rule | 0.75 | 0.12 | 134.9 |
| HOLDER ASSIGNMENT | rule | - | 0.75 | 17.4 |
| CHARGE NOW FIRST | rule | 0.12 | 0.50 | 30.4 |
| PATHS CROSS | rule | - | 0.38 | 25.5 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.12 | - | 78.1 |
| BEST PRIZE | rule | 0.12 | - | 154.5 |
| CARRIES OUT SET-UP | rule | - | 0.12 | 29.3 |
| CHAFF PASSED | rule | - | 0.12 | 2.4 |
| RULE SWITCHED OFF | gate | 0.12 | - | 1.8 |

### Plans: h9-opp-81fb82c-p2

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.5 | 58% | 260 | 97 | 37% |
| Mine | join | 0.4 | 100% | 13 | 0 | 0% |
| Mine | move | 29.1 | 95% | 1636 | 0 | 0% |
| Mine | shoot | 8.6 | 45% | 314 | 414 | 132% |
| Mine | support | 0.2 | 50% | 7 | 0 | 0% |
| Opponent | charge | 1.8 | 71% | 179 | 131 | 73% |
| Opponent | join | 1.5 | 100% | 67 | 0 | 0% |
| Opponent | move | 30.6 | 95% | 1964 | 0 | 0% |
| Opponent | shoot | 9.5 | 63% | 623 | 795 | 128% |
| Opponent | support | 0.1 | 100% | 0 | 0 | - |

### Battle groups: h9-opp-81fb82c-p2

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 2.9 | 26% | 67% | 0% | - | 33% | 0% | 0% | 67% | 0% |
| Opponent | REDIRECT COUNTER | 1.0 | 12% | 0% | 0% | - | 100% | 0% | 0% | 0% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: h9-opp-81fb82c-p2

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 7 | 0 (7) | 0 | 0 | 50 | 71% | 2.5 | 0 (2) | 0 (2) | 0 (3) | 0 (3) | 0 (4) |
| Mine | Character | 34 | 29 (34) | 29 | 0 | 38 | 18% | 2.6 | 40 (8) | 15 (14) | 78 (4) | 45 (5) | 29 (21) |
| Mine | Clean-up | 9 | 128 (9) | 55 | 73 | 0 | 56% | 4.0 | 98 (4) | 199 (3) | 88 (2) | 124 (5) | 134 (4) |
| Mine | Fast Hammer | 4 | 18 (4) | 18 | 0 | 50 | 50% | 3.0 | 35 (2) | 0 (2) | - | 0 (1) | 24 (3) |
| Mine | Hammer | 21 | 47 (21) | 20 | 27 | 34 | 24% | 2.7 | 54 (4) | 56 (14) | 8 (3) | 56 (6) | 44 (15) |
| Mine | Holder | 8 | 62 (8) | 12 | 49 | 21 | 62% | 5.0 | 0 (1) | 72 (5) | 62 (2) | 0 (2) | 85 (6) |
| Mine | Shooter | 4 | 300 (4) | 0 | 300 | 50 | 0% | 2.0 | 554 (1) | 138 (2) | 369 (1) | 354 (3) | 138 (1) |
| Mine | War machine | 13 | 33 (13) | 33 | 0 | 37 | 0% | 1.1 | 38 (8) | 25 (5) | - | 20 (2) | 36 (11) |
| Mine | Wizard | 5 | 25 (5) | 25 | 0 | 0 | 20% | 4.5 | 0 (1) | 31 (4) | - | - | 25 (5) |
| Opponent | Chaff | 10 | 128 (10) | 9 | 119 | 64 | 30% | 2.7 | 223 (2) | 201 (3) | 33 (5) | 159 (8) | 0 (2) |
| Opponent | Character | 27 | 39 (27) | 39 | 0 | 20 | 26% | 3.1 | 7 (10) | 84 (10) | 0 (4) | 44 (16) | 40 (8) |
| Opponent | Clean-up | 3 | 33 (3) | 0 | 33 | 29 | 67% | 3.0 | 76 (1) | 0 (2) | - | 33 (3) | - |
| Opponent | Fast | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Fast Hammer | 14 | 37 (14) | 11 | 25 | 43 | 29% | 3.6 | 56 (7) | 24 (7) | - | 54 (8) | 21 (6) |
| Opponent | Hammer | 4 | 96 (4) | 52 | 44 | 0 | 25% | 3.0 | - | 129 (3) | 16 (1) | 96 (4) | - |
| Opponent | Holder | 5 | 123 (5) | 7 | 116 | 0 | 40% | 3.7 | 90 (1) | 175 (3) | 0 (1) | - | 123 (5) |
| Opponent | Shooter | 11 | 85 (11) | 26 | 60 | 44 | 0% | 2.2 | 105 (4) | 148 (3) | 21 (4) | 136 (5) | 19 (6) |
| Opponent | War machine | 15 | 55 (15) | 55 | 0 | 13 | 0% | 2.1 | 132 (5) | 39 (6) | 0 (4) | 19 (3) | 64 (12) |
| Opponent | Wizard | 6 | 0 (6) | 0 | 0 | 28 | 17% | 3.0 | 0 (2) | 0 (1) | 0 (2) | 0 (3) | 0 (2) |

### Charged fights: h9-opp-81fb82c-p2

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 126 | 39 | 1.5 | 1.3 | 26 | 0 | +26 | 2 of 6 | 5 of 6 | +0 | +31 |
| Mine | Chaos Dwarfs | 3 | 133 | 147 | 2.3 | 1.1 | 63 | 16 | +47 | 3 of 7 | 4 of 6 | +0 | +55 |
| Mine | Dwarfen Mountain Holds | 1 | 551 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| **Mine** | all armies | 8 | 182 | 74 | 1.6 | 1.2 | 46 | 8 | +37 | 5 of 13 | 9 of 12 | +0 | +44 |
| Opponent | Empire of Man | 3 | 205 | 352 | 1.7 | 1.2 | 211 | 90 | +121 | 1 of 5 | 5 of 5 | +886 | -70 |
| Opponent | Grand Cathay | 1 | 580 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | High Elf Realms | 1 | 182 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Tomb Kings of Khemri | 1 | 120 | 1029 | 4.0 | 1.5 | 257 | 98 | +160 | 3 of 4 | 3 of 4 | -65 | +235 |
| Opponent | Vampire Counts | 2 | 0 | 527 | 4.0 | 1.1 | 132 | 6 | +126 | 2 of 8 | 6 of 8 | +364 | +91 |
| **Opponent** | all armies | 8 | 187 | 392 | 2.1 | 1.2 | 185 | 52 | +132 | 6 of 17 | 14 of 17 | +395 | +76 |

### Effective charges: h9-opp-81fb82c-p2

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 6 | 1 (net +0) | 0 | 1 (net +0) | 1 (net +60) | 0 | 2 (net +30) | 1 | 20% (1 of 5) |
| Mine | Chaos Dwarfs | 7 | 0 | 0 | 1 (net +0) | 1 (net +0) | 3 (net +147) | 2 (net -55) | 0 | 14% (1 of 7) |
| Opponent | Empire of Man | 5 | 0 | 0 | 0 | 3 (net +145) | 0 | 2 (net +84) | 0 | 0% (0 of 5) |
| Opponent | Tomb Kings of Khemri | 4 | 0 | 0 | 0 | 1 (net +77) | 0 | 2 (net +378) | 1 | 0% (0 of 3) |
| Opponent | Vampire Counts | 8 | 2 (net -25) | 0 | 0 | 3 (net +183) | 2 (net +70) | 1 (net +364) | 0 | 0% (0 of 8) |

### Charged fights, damage counted: h9-opp-81fb82c-p2

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 1 | 52 | 129 | +0 | 64 | 35 | +30 | +57.4 |
| Mine | Effective (55-75%) | 2 | 264 | 240 | +0 | 79 | 97 | -18 | -6.7 |
| Mine | 76-89% | 2 | 326 | 209 | +30 | 75 | 69 | +6 | +1.8 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 4 | 342 | 200 | -12 | 96 | 56 | +40 | +11.6 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 3 | 310 | 70 | +147 | 147 | 0 | +147 | +47.3 |
| Mine | No odds | 1 | 317 | 371 | +36 | 222 | 0 | +222 | +69.9 |
| Mine | All fights | 13 | 296 | 185 | +37 | 109 | 45 | +64 | +21.5 |
| Opponent | Long shot (under 50%) | 2 | 98 | 184 | -25 | 24 | 25 | -1 | -1.3 |
| Opponent | 76-89% | 7 | 237 | 118 | +152 | 221 | 80 | +141 | +59.4 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 5 | 427 | 225 | +258 | 297 | 76 | +221 | +51.7 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 2 | 304 | 70 | +70 | 70 | 0 | +70 | +23.0 |
| Opponent | No odds | 1 | 195 | 836 | -195 | 0 | 195 | -195 | -100.0 |
| Opponent | All fights | 17 | 282 | 194 | +132 | 189 | 70 | +120 | +42.4 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| h9-opp-81fb82c-p2 | move | 51 | 9 (18%) | 8 (16%) | 2 (4%) | 40 (78%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0108, L0123 |
| Charmed Shield | Opponent | L0224, L0325 |
| Elixir of Power | Opponent | L0411 |
| Invocation of Nehek | Opponent | L0224, L0325 |
| Ring of Doom | Mine | L0207, L0224 |
| Ring of Doom | Opponent | L0411 |
| Ring of Jet | Opponent | L0411 |
| Standard of the Fell Warrior | Opponent | L0513 |
| Twice-Blessed Armour | Opponent | L0207 |
| Witch Hunter's Ward | Opponent | L0108, L0207, L0308 |

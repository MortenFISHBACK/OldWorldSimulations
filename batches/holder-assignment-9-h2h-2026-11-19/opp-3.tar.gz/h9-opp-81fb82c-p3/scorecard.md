# Doctrine scorecard: h9-opp-81fb82c-p3

### Scorecard: h9-opp-81fb82c-p3

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0111 | 3 | 1 | Mine | yes | 3 | 5 | 1 | 2 | 0 | 0 | 0 | 0 |
| L0111 | 3 | 1 | Opponent | no | 0 | 3 | 4 | 0 | 0 | 0 | 0 | 0 |
| L0128 | 2 | 1 | Mine | - | - | - | 0 | 5 | 0 | 0 | 0 | 0 |
| L0128 | 2 | 1 | Opponent | - | - | - | 0 | 4 | 0 | 0 | 0 | 0 |
| L0211 | 1 | 1 | Mine | no | 0 | 2 | 0 | 3 | 0 | 0 | 0 | 200 |
| L0211 | 1 | 1 | Opponent | yes | 10 | 3 | 0 | 0 | 0 | 0 | 0 | 0 |
| L0228 | 6 | 1 | Mine | yes | 9 | 2 | 2 | 2 | 0 | 0 | 0 | 170 |
| L0228 | 6 | 1 | Opponent | no | 8 | 3 | 1 | 0 | 0 | 0 | 0 | 0 |
| L0313 | 1 | 1 | Mine | no | 0 | 4 | 1 | 1 | 0 | 0 | 0 | 85 |
| L0313 | 1 | 1 | Opponent | no | 5 | 2 | 2 | 0 | 1 | 0 | 0 | 0 |
| L0330 | 6 | 1 | Mine | no | 0 | 5 | 1 | 0 | 1 | 0 | 0 | 110 |
| L0330 | 6 | 1 | Opponent | no | 6 | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| L0415 | 1 | 1 | Mine | no | 0 | 2 | 5 | 1 | 0 | 0 | 0 | 310 |
| L0415 | 1 | 1 | Opponent | no | 10 | 2 | 2 | 0 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 33% | 2.0 | 3.3 | 1.4 | 2.0 | 0.1 | 0.0 | 0.0 | 125.0 |
| **Average** | | | Opponent | 17% | 6.5 | 2.5 | 1.6 | 0.7 | 0.1 | 0.0 | 0.0 | 0.0 |

### KPIs: h9-opp-81fb82c-p3

Rules off - Mine only: HOLDER ASSIGNMENT, QUARTER ODDS, WALK PROMISE, REAL GROUND, RISK ON THE WAY, ONE ROUTE, MARCH WHEELS ONLY, LATE ONLY FROM HERE, WALKS ON ITS ROUTE.

Morten 2026-11-10; 7 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 24% (8 of 34) | 13% (4 of 31) | 18% (12 of 65) |
| Winner chose to follow up after the loser gave ground |  | 100% (2 of 2); on the table 100% | 75% (3 of 4); on the table 75% | 83% (5 of 6); on the table 83% |
| Winner chose to pursue after the loser fell back in good order |  | 75% (3 of 4); on the table 75% | 0% (0 of 1); on the table 0% | 60% (3 of 5); on the table 60% |
| Winner chose to pursue after the loser fled |  | 0% (0 of 1); on the table 0% | - | 0% (0 of 1); on the table 0% |
| Winner chose to follow up or pursue (all three) |  | 71% (5 of 7); on the table 71% | 60% (3 of 5); on the table 60% | 67% (8 of 12); on the table 67% |
| Magic missiles tried each own turn | 50%+ | 46% (61 of 132) | 39% (21 of 54) | 44% (82 of 186) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 49% (61 of 125) | 55% (21 of 38) | 50% (82 of 163) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 40% (4 of 10) | - | 40% (4 of 10) |
| Points that never fought | lower | 53% (7144 of 13565) | 53% (7471 of 13998) | 53% (14615 of 27563) |
|   infantry points that never fought | lower | 58% (2396 of 4124) | 65% (1122 of 1730) | 60% (3518 of 5854) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 57% (26 of 46) | 45% (23 of 51) | 51% (49 of 97) |
| Bound items with a magic missile used (at least once a game) |  | 83% (5 of 6); 2.0 uses a game | 100% (7 of 7); 3.0 uses a game | 92% (12 of 13); 2.5 uses a game |
| Bound items with another spell used |  | 100% (2 of 2); 1.1 uses a game | 0% (0 of 2); 0.0 uses a game | 50% (2 of 4); 0.6 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 88% (7 of 8); 1.0 uses a game | 33% (1 of 3); 0.1 uses a game | 73% (8 of 11); 0.6 uses a game |
|   their share of the points of units over 100 pts | lower | 48% (4909 of 10334) | 46% (6026 of 12986) | 47% (10935 of 23320) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 5.9 (58%) | 0.6 (12%) | 6.4 (43%) |
| MARCHED: its unit marched | 1.9 (18%) | 1.7 (36%) | 3.6 (24%) |
| CHARGED: its unit charged | 0.3 (3%) | 0.0 (0%) | 0.3 (2%) |
| IN COMBAT: engaged in combat | 0.3 (3%) | 1.7 (36%) | 2.0 (13%) |
| REAR RANK: in a rear rank | 0.7 (7%) | 0.0 (0%) | 0.7 (5%) |
| FLEEING: fleeing | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| GONE: slain | 0.6 (6%) | 0.6 (12%) | 1.1 (8%) |
| STUPIDITY: Stupidity | 0.4 (4%) | 0.1 (3%) | 0.6 (4%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 3.9 | 4.1 | 2.3 | 11.7 | 0.1 | 0.9 |
| not cast | 4.7 | 5.0 | 3.7 | 14.9 | 1.6 | 26.6 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.4 (5%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 2.6 (51%) | 0.0 (0%) | 6.4 (43%) | 0.6 (36%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 3.6 (24%) | 0.6 (36%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (2%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.0 (0%) | 0.1 (4%) | 2.0 (13%) | 0.3 (18%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.0 (0%) | 0.7 (19%) | 0.7 (5%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.9 (3%) |
| GONE: slain | 0.7 (15%) | 0.0 (0%) | 0.7 (19%) | 1.1 (8%) | 0.0 (0%) | 1.7 (6%) |
| STUPIDITY: Stupidity | 0.1 (3%) | 0.1 (3%) | 0.1 (4%) | 0.6 (4%) | 0.0 (0%) | 0.4 (2%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.9 (17%) | 0.0 (0%) | 0.0 (0%) | 0.1 (9%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 3.9 (82%) | 1.4 (29%) | 2.0 (54%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 22.1 (83%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 2.7 a game | 0.7 a game | 1.7 a game |
| stood (cast and not dispelled) | 37% (7 of 19) | 100% (1 of 1) | 40% (8 of 20) |
| the unit moved after it | 29% (2 of 7) | 100% (1 of 1) | 38% (3 of 8) |
| it charged on its next turn | 0% (0 of 7) | 0% (0 of 1) | 0% (0 of 8) |
| the enemy charged it first | 0% (0 of 7) | 0% (0 of 1) | 0% (0 of 8) |
| it fought by the end of its next turn | 14% (1 of 7) | 0% (0 of 1) | 12% (1 of 8) |
| it moved out of a charge the enemy had planned (not charged first) | 43% (3 of 7) | 0% (0 of 1) | 38% (3 of 8) |
| none of these (no charge, no fight, no charge escaped) | 43% (3 of 7) | 100% (1 of 1) | 50% (4 of 8) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 58% (56 of 96) | 53% (58 of 109) | 56% (114 of 205) |
|   cavalry | 100% (4 of 4) | 57% (4 of 7) | 73% (8 of 11) |
|   character | - | 20% (4 of 20) | 20% (4 of 20) |
|   chariot | 53% (16 of 30) | 69% (9 of 13) | 58% (25 of 43) |
|   infantry | 42% (8 of 19) | 69% (25 of 36) | 60% (33 of 55) |
|   war machine | 65% (28 of 43) | 48% (16 of 33) | 58% (44 of 76) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.1 (20%) | 2.4 (33%) | 3.6 (27%) |
| CHARGED: it charged | 0.3 (5%) | 1.0 (14%) | 1.3 (10%) |
| IN COMBAT: it fought this turn or the last | 0.4 (8%) | 0.1 (2%) | 0.6 (4%) |
| MOVED: a war machine that moved | 1.3 (22%) | 2.3 (31%) | 3.6 (27%) |
| NO TARGET IN RANGE | 1.4 (25%) | 0.9 (12%) | 2.3 (18%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.7 (12%) | 0.4 (6%) | 1.1 (9%) |
| OTHER BAR | 0.4 (8%) | 0.1 (2%) | 0.6 (4%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 1.1 | 0.3 | 75% | 3.5 pts | 4 pts |
| character | 0.7 | 0.0 | 100% | 0.0 pts | 0 pts |
| chariot | 3.6 | 3.7 | 36% | 34.3 pts | 123 pts |
| infantry | 7.7 | 2.9 | 78% | 5.6 pts | 43 pts |
| war machine | 6.3 | 7.4 | 59% | 31.1 pts | 195 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 2.4 | 3.3 | 2.9 |
| Charges that made contact a game | 2.0 | 2.3 | 2.1 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.40 declared, 0.00 contact (5 units) | 1.40 declared, 1.40 contact (5 units) | 0.90 declared, 0.70 contact (10 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 1.00 declared, 0.50 contact (2 units) | 1.00 declared, 0.50 contact (2 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.32 declared, 0.30 contact (47 units) | 0.39 declared, 0.22 contact (36 units) | 0.35 declared, 0.27 contact (83 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 29% (2 of 7) | - | 43% (3 of 7) | 36% (5 of 14) |
| Character in a unit | 90% (9 of 10) | 75% (9 of 12) | 50% (1 of 2) | 79% (19 of 24) |
| Character on its own | 100% (2 of 2) | 71% (5 of 7) | 29% (2 of 7) | 56% (9 of 16) |
| Chariot | 67% (2 of 3) | 33% (2 of 6) | - | 44% (4 of 9) |
| Infantry | 10% (1 of 10) | 11% (1 of 9) | - | 11% (2 of 19) |
| Monster | 50% (1 of 2) | 0% (0 of 1) | - | 33% (1 of 3) |
| War Machines | 80% (8 of 10) | 50% (1 of 2) | - | 75% (9 of 12) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 60% (3 of 5); on the table 60% | 42% (43 of 102) | 50% | 64% (14 of 22) | 83% (5 of 6); 3.5 uses a game | 100% (2 of 2); 2.0 uses a game | 83% (5 of 6); 1.2 uses a game |
| Chaos Dwarfs | 3 | 100% (2 of 2); on the table 100% | 60% (18 of 30) | 56% | 50% (12 of 24) | 0.0 uses a game | 0.0 uses a game | 100% (2 of 2); 0.7 uses a game |
| Grand Cathay | 2 | 0% (0 of 1); on the table 0% | 42% (15 of 36) | 42% | 38% (6 of 16) | 100% (4 of 4); 5.0 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |
| High Elf Realms | 2 | 100% (1 of 1); on the table 100% | 0% (0 of 6) | 67% | 47% (7 of 15) | 100% (3 of 3); 5.5 uses a game | 0% (0 of 2); 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 3 | 67% (2 of 3); on the table 67% | 50% (6 of 12) | 52% | 50% (10 of 20) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 0.3 uses a game |

Flank and rear charges a unit could have turned to face (h9-opp-81fb82c-p3, 7 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 45% (5) | 45% (5) | 45% (10) |
| ...free all their last turn and able to turn (per game) | 0.71 | 0.57 | 1.29 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.14 | 0.14 |
| ...with the charger already in that arc before they moved (per game) | 0.57 | 0.29 | 0.86 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: h9-opp-81fb82c-p3

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 0.9 | 2.3 |
| Strategy | Charge objectives carried out (made contact) | 73% (11 of 15) | 41% (9 of 22) |
| Strategy | Shoot objectives carried out (shot that target) | 32% (21 of 66) | 36% (12 of 33) |
| Strategy | Support requests answered (helper made contact too) | 67% (2 of 3) | 0% (0 of 1) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (2 of 2) | - |
| Strategy | Hexes on a unit its side charged or shot that turn | - | 56% (5 of 9) |
| Strategy | Joined characters whose unit fought | 40% (8 of 20) | 43% (6 of 14) |
| Strategy | Lone characters that fought | 33% (4 of 12) | 60% (6 of 10) |
| Movement | Charges halted short of contact | 0.0 | 0.3 |
| Movement | Idle units | 2.0 | 0.7 |
| Movement | Points that never moved of their own | 125.0 | 0.0 |
| Movement | Fights charged into per game | 1.6 | 2.1 |
| Movement | Charges with odds: long shots (under 50%) | 5 of 10, net +41 | 2 of 12, net +81 |
| Movement | Charges with odds: sweet spot (55-75%) | 1 of 10, net +150 | 0 of 12 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 1 of 10, net +70 | 2 of 12, net +26 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 of 10, net +161 | 4 of 12, net +110 |
| Shooting | Shots by shooting units (incl. breath weapons) | 4.0 | 6.6 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 61% (17 of 28) | 39% (18 of 46) |
| Shooting | Points destroyed by shooting units | 38.0 | 20.0 |
| Shooting | War machine shots | 4.0 | 2.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 46% (13 of 28) | 31% (5 of 16) |
| Shooting | Points destroyed by war machines | 57.1 | 19.6 |
| Magic | Magic missiles cast | 3.9 | 2.0 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 44% (12 of 27) | 7% (1 of 14) |
| Magic | Wounds caused by magic missiles | 6.1 | 4.1 |
| Magic | Wounds caused by other spells | 0.6 | 2.1 |
| Magic | Points destroyed by magic (all spells) | 100.3 | 70.1 |
| Magic | Augments / hexes / assailments / vortexes cast | 2.7 / 0.0 / 0.1 / 0.0 | 0.1 / 1.9 / 0.6 / 0.1 |
| Combat | Points destroyed in combat | 201.4 | 331.4 |
| Combat | Points run down | 42.7 | 90.7 |
| Combat | Net points per charged fight, damage counted | +105 | +144 |
| Combat | Net per 100 charger points, damage counted | +54.2 | +40.3 |
| Combat | First round won (charged fights) | 73% | 73% |
| Combat | Net points per charged fight | +83 | +119 |
| Combat | Net points per supported fight / lone fight | -137 / +132 | +335 / +104 |
| Combat | Charged fights on a top-3 enemy unit | 6 of 11 | 7 of 15 |
| Game | Points lost | 557.3 | 426.9 |
| Game | VP from objectives | 685.7 | 784.3 |
| Game | Lone holders (player turns) | 2.0 | 6.5 |

- Mine won / drew / lost: 3 / 1 / 3 of 7 ended games (of 7); mean margin (Mine - Opponent) -262 VP
- The side that went first won 1 of 6 games with a winner
- Points traded per game (both sides' losses): 984
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: h9-opp-81fb82c-p3

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.6 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | - | - | - | - | 0.3 | +84.3 | 0.0 | 0.0 |
| ALREADY CARRIED | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARTILLERY RE-ROLL WEIGHED | 1.9 | +0.0 | 0.0 | 48.6 | 0.4 | +0.0 | 0.0 | 47.1 |
| BEST PRIZE | - | - | - | - | 0.1 | -3.0 | 0.0 | 0.0 |
| BLOWS WHERE AIMED | - | - | - | - | 0.1 | -5.8 | 52.0 | 0.0 |
| BOMBING RUN | - | - | - | - | 0.3 | +6.8 | 7.9 | 21.4 |
| CANNON PLAN MISSED | 0.3 | +0.0 | 126.3 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CANNON PLANNED TARGET | 3.9 | +27.2 | 314.7 | 64.3 | 2.1 | +100.0 | 77.9 | 70.7 |
| CANNON SIGHT KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| CAST JOB | 1.1 | +19.4 | 57.1 | 0.0 | - | - | - | - |
| CASTER AWAY FROM SCREEN | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CASTING BLOCK | 1.1 | +95.4 | 35.3 | 0.0 | 0.1 | +2.9 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 1.0 | +0.0 | 0.0 | 101.4 | 0.3 | +0.0 | 0.0 | 57.1 |
| CHAFF IN THE MOVE | 0.3 | +12.9 | 0.0 | 20.0 | - | - | - | - |
| CHAFF PASSED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CHARGE LOSSES | 5.0 | -217.4 | 0.0 | 122.6 | 6.3 | -332.2 | 0.0 | 253.1 |
| CHARGE NOT DECLARED | 0.9 | +0.0 | 5.9 | 27.0 | 0.3 | +0.0 | 48.6 | 63.1 |
| CHARGE NOW FIRST | 1.1 | +0.0 | 214.3 | 0.0 | 1.3 | +0.0 | 135.4 | 24.7 |
| CHARGER SLAIN LOST | 1.0 | -83.0 | 66.4 | 27.0 | 0.3 | -20.3 | 68.0 | 8.6 |
| CHEAP HELPER | 0.4 | +0.0 | 21.4 | 7.4 | - | - | - | - |
| COMBAT PIVOT | 0.3 | +0.0 | 0.0 | 44.3 | 0.1 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | 2.3 | +541.5 | 9.3 | 101.4 | 0.1 | +33.1 | 57.1 | 57.1 |
| COVER ONCE | 6.3 | -795.9 | 0.0 | 86.3 | 4.7 | -218.7 | 0.0 | 0.0 |
| DEFENSIVE FLOOR | - | - | - | - | 0.1 | -14.3 | 0.0 | 0.0 |
| DEPLOY BY FIGURES | 7.7 | +68.4 | 0.0 | 4.3 | 6.0 | -14.7 | 0.0 | 0.0 |
| ENGINEER BY LORE | 0.6 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FALL BACK GOOD ORDER | 1.3 | +0.0 | 139.9 | 23.7 | 2.1 | +5.2 | 238.3 | 96.4 |
| FALLBACK BY WORTH | 0.1 | +0.0 | 0.0 | 7.9 | 0.1 | +0.0 | 0.0 | 0.0 |
| FALLS SHORT | 7.3 | +167.9 | 0.0 | 92.1 | 13.3 | +278.0 | 0.0 | 253.6 |
| FEATURE BUFFS | 3.9 | +108.9 | 0.0 | 30.3 | 0.7 | +15.8 | 0.0 | 0.0 |
| FIGHT TO THE END | 0.4 | +12.7 | 90.4 | 0.0 | 1.1 | +161.3 | 121.7 | 24.7 |
| FIRE AND FLEE | 0.1 | +1.3 | 8.6 | 16.0 | - | - | - | - |
| FIRE IN ORDER | - | - | - | - | 0.1 | +0.0 | 7.9 | 0.0 |
| FIVE ACTION | 41.3 | +2413.4 | 1216.6 | 494.9 | 36.0 | +4184.7 | 539.7 | 746.4 |
| FLANK NOT WEIGHED | 4.6 | +0.0 | 0.0 | 156.6 | 4.9 | +0.0 | 0.0 | 45.6 |
| FOLLOW UP WEIGHED | 0.1 | +0.0 | 0.0 | 0.0 | 0.4 | +115.3 | 0.0 | 0.0 |
| FOUR ROUNDS | 2.1 | +224.9 | 232.3 | 38.6 | 3.1 | +543.1 | 388.3 | 159.6 |
| FRIEND SHOOTS FIRST | 0.6 | -16.4 | 0.0 | 44.3 | 0.3 | -13.2 | 0.0 | 57.1 |
| GIVES UP | - | - | - | - | 0.3 | -8.3 | 0.0 | 0.0 |
| GROUND FLIERS | 0.1 | +6.0 | 0.0 | 0.0 | - | - | - | - |
| GUN FIGURES | 1.4 | +19.2 | 143.6 | 44.3 | - | - | - | - |
| GUN MASK | - | - | - | - | 1.3 | +41.5 | 0.0 | 0.0 |
| HARD STAY DROPPED | 1.1 | +0.0 | 0.0 | 52.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| HE SHOOTS OR CHARGES | 2.9 | +0.0 | 0.0 | 77.3 | 1.6 | +0.0 | 0.0 | 125.3 |
| HELPER ALREADY ASKED | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 52.0 | 0.0 |
| HELPER UNSEEN | 0.1 | +0.0 | 0.0 | 11.6 | - | - | - | - |
| HIS CHARGE DENIED | 0.7 | +22.7 | 84.6 | 23.7 | 0.3 | +25.9 | 60.3 | 8.6 |
| HIS CHARGE LIST | 2.1 | +0.0 | 0.0 | 16.0 | 1.4 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 2.4 | +0.0 | 0.0 | 52.0 | 4.3 | +0.0 | 0.0 | 139.1 |
| HIS MOVE AND SHOT | 2.3 | -27.1 | 0.0 | 138.6 | 1.7 | -127.6 | 0.0 | 63.9 |
| HIS ONE QUARTER | - | - | - | - | 1.1 | +0.0 | 0.0 | 18.0 |
| HIS RANDOM MOVE | - | - | - | - | 2.9 | +0.0 | 0.0 | 27.3 |
| HIS SHOT LIST | 16.0 | +420.8 | 0.0 | 157.3 | 16.0 | +721.0 | 0.0 | 307.3 |
| HIS TURN DENIED | 0.4 | +11.9 | 41.6 | 0.0 | 1.7 | +66.1 | 146.6 | 126.3 |
| HOLD ODDS | - | - | - | - | 13.6 | +0.0 | 0.0 | 173.9 |
| HOLDER ASSIGNMENT | - | - | - | - | 15.7 | +1503.9 | 0.0 | 173.9 |
| HOLDER AT DEPLOYMENT | 1.4 | +192.2 | 0.0 | 0.0 | - | - | - | - |
| HOLDS AMBUSHERS | 0.6 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 1.0 | -40.2 | 165.9 | 0.0 | 2.6 | -141.5 | 284.3 | 159.6 |
| HUNT IN PAIRS | - | - | - | - | 0.3 | +28.0 | 0.0 | 0.0 |
| HUNT RESULT | 0.1 | +39.8 | 0.0 | 12.1 | - | - | - | - |
| HUNT THE GUNS | 0.1 | +47.9 | 23.6 | 0.0 | - | - | - | - |
| IDLE COST | 1.7 | -26.4 | 0.0 | 9.3 | 5.4 | -174.2 | 0.0 | 105.4 |
| KEEP FALLS | 0.3 | +3.3 | 0.0 | 0.0 | - | - | - | - |
| LANE BY FIGURES | 0.3 | +24.3 | 0.0 | 0.0 | 0.6 | +9.4 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 5.7 | +0.0 | 57.9 | 291.9 | 1.3 | +0.0 | 72.6 | 154.6 |
| LONE WIZARD KEPT IN | 1.4 | +121.0 | 0.0 | 0.0 | 0.3 | +30.5 | 0.0 | 0.0 |
| LONG SHOT | 0.1 | -0.3 | 0.0 | 11.6 | 0.3 | -2.9 | 0.0 | 24.7 |
| LOST CHARGE | 0.1 | -0.1 | 68.9 | 0.0 | 0.1 | -0.3 | 0.0 | 24.7 |
| MAKE SURE TOGETHER | 0.1 | +0.3 | 0.0 | 0.0 | - | - | - | - |
| MANOEUVRE | 1.4 | +27.5 | 0.0 | 0.0 | 1.9 | +11.3 | 0.0 | 44.4 |
| MARCH AT ESCAPER | 0.4 | +16.6 | 0.0 | 0.0 | 0.3 | +0.7 | 0.0 | 28.4 |
| MARCH BY THE SUM | 0.1 | +3.4 | 0.0 | 0.0 | 0.9 | +39.7 | 0.0 | 28.4 |
| MARCH CHECK | 1.6 | +97.3 | 0.0 | 0.0 | 2.3 | +96.3 | 0.0 | 0.0 |
| MARCH OVER CASTS | 0.9 | +206.4 | 0.0 | 0.0 | 1.9 | +139.7 | 0.0 | 28.4 |
| MARCH WHEELS ONLY | - | - | - | - | 0.3 | +0.0 | 0.0 | 21.6 |
| MAX FOR POSITIONING | 5.4 | +103.2 | 0.0 | 135.6 | 5.3 | +61.1 | 0.0 | 149.6 |
| MISSILES IN THE MOVE | 7.4 | +368.7 | 0.0 | 35.3 | 5.6 | +116.8 | 0.0 | 57.1 |
| MISSILES NEXT TURN | 7.9 | +227.9 | 0.0 | 35.3 | 7.0 | +81.8 | 0.0 | 171.1 |
| MOVE SPELL OUT OF RANGE | 0.9 | -169.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL SPOT | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 57.1 |
| MOVE TO CHARGE COMPUTED | 2.3 | +332.9 | 0.0 | 63.9 | 4.0 | +735.9 | 0.0 | 108.1 |
| MOVES UNITS SPELL | 0.3 | +15.7 | 0.0 | 0.0 | 0.1 | +1.0 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 3.9 | +259.7 | 0.0 | 35.9 | 6.7 | +293.2 | 0.0 | 31.6 |
| NEXT CHARGE BY LIST | 4.0 | -191.9 | 0.0 | 63.9 | 5.7 | -307.4 | 9.3 | 140.4 |
| NEXT OBJECTIVE NEARER | 5.9 | -316.2 | 5.9 | 46.0 | - | - | - | - |
| NO DOUBLE ROUNDS | 2.1 | -104.5 | 232.3 | 38.6 | 2.3 | -153.9 | 245.6 | 33.3 |
| NO RALLY LEFT | 0.1 | +66.5 | 0.0 | 0.0 | 0.1 | +24.8 | 0.0 | 0.0 |
| NOT WORTH A CAST | 1.1 | -1.6 | 0.0 | 0.0 | 0.3 | -0.3 | 0.0 | 0.0 |
| OFF BEST | 0.3 | -15.8 | 0.0 | 7.9 | 0.3 | -6.4 | 0.0 | 0.0 |
| ONE CHARGE A CHARGER | 2.9 | +0.0 | 0.0 | 120.1 | 0.9 | +0.0 | 0.0 | 28.4 |
| ONE FIGHT FORMULA | 5.0 | -89.0 | 0.0 | 94.9 | 4.1 | -143.9 | 0.0 | 187.9 |
| ONE OBJECTIVE FORMULA | 5.0 | -69.8 | 0.0 | 27.1 | 6.9 | +44.5 | 0.0 | 130.7 |
| ONE ROUTE | - | - | - | - | 0.3 | +0.0 | 0.0 | 21.6 |
| ONE TARGET A SHOOTER | 18.4 | +348.8 | 0.0 | 200.3 | 16.1 | +399.1 | 0.0 | 243.3 |
| OPENS UP | - | - | - | - | 0.6 | +74.8 | 38.6 | 0.0 |
| OVERRUNS AWAY | 0.1 | +0.5 | 21.4 | 0.0 | 0.4 | +82.5 | 79.3 | 126.3 |
| PATHS CROSS | 2.7 | +58.0 | 0.0 | 50.1 | 3.9 | +130.3 | 0.0 | 68.9 |
| PLAN RESULT | 36.6 | +1047.0 | 801.6 | 786.1 | 31.3 | +409.3 | 240.7 | 832.0 |
| PURSUES BIG PREY | 0.1 | -17.1 | 0.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | - | - | - | - | 6.4 | +1004.8 | 80.7 | 156.9 |
| RANDOM MOVE BY FIGURES | 1.4 | +23.0 | 0.0 | 24.3 | - | - | - | - |
| REAL GROUND | - | - | - | - | 0.3 | +0.0 | 0.0 | 21.6 |
| REDIRECT BY WHAT IT STOPS | 0.1 | -4.9 | 0.0 | 12.1 | - | - | - | - |
| REDIRECT COUNTER | 2.7 | +146.9 | 0.0 | 97.1 | 1.9 | +175.6 | 0.0 | 39.0 |
| REDIRECT WEIGHED | - | - | - | - | 0.3 | -2.0 | 0.0 | 8.6 |
| REFORMS TO MEET IT | 0.4 | -35.3 | 0.0 | 19.6 | 0.4 | -103.6 | 0.0 | 8.6 |
| REFUSING RETIRES | - | - | - | - | 0.1 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | 0.4 | +21.4 | 0.0 | 16.0 | 0.4 | +19.2 | 0.0 | 0.0 |
| RISK BY ARC | 1.6 | +37.3 | 151.1 | 38.6 | 2.0 | -19.5 | 259.3 | 159.6 |
| RISK BY HIS FIGURE | 11.7 | -183.2 | 0.0 | 333.6 | 11.0 | -263.4 | 0.0 | 322.7 |
| RUN DOWN | 1.4 | -19.8 | 232.3 | 0.0 | 2.3 | -12.9 | 255.4 | 134.9 |
| SCOUT SPOT | 0.3 | +0.4 | 0.0 | 0.0 | - | - | - | - |
| SCOUT WAITS | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SCREEN BY WHAT IT SAVES | 0.6 | -87.1 | 0.0 | 7.9 | 0.1 | -20.5 | 0.0 | 0.0 |
| SEARCH SPOT | 3.7 | +166.5 | 0.0 | 144.4 | 4.1 | +202.4 | 0.0 | 40.1 |
| SELF MOVE SPELL | - | - | - | - | 0.9 | +108.8 | 0.0 | 0.0 |
| SET UP TOGETHER | 0.1 | +0.3 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | - | - | - | - | 0.3 | +0.3 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.1 | +46.7 | 28.4 | 11.6 | 0.3 | +7.8 | 56.4 | 0.0 |
| SHOT OR CHARGE | 0.4 | -3.3 | 126.3 | 12.1 | 0.6 | -50.4 | 119.3 | 0.0 |
| SHOT RISK POINTS | 8.7 | +35.8 | 0.0 | 147.1 | 11.1 | -198.2 | 0.0 | 304.6 |
| SHOTS IN THE MOVE | 10.1 | +381.6 | 0.0 | 143.1 | 11.0 | +484.2 | 0.0 | 260.6 |
| SPELL SETS UP CHARGE | 0.1 | +86.7 | 0.0 | 0.0 | - | - | - | - |
| SPELL WORTH | 0.3 | +0.8 | 0.0 | 0.0 | 0.3 | +8.3 | 114.3 | 114.3 |
| SPELLS IN THE FIGHT | - | - | - | - | 0.1 | +0.9 | 9.3 | 0.0 |
| STAND AND SHOOT | 0.3 | -6.2 | 18.0 | 0.0 | 0.4 | -4.2 | 69.6 | 8.6 |
| STANDS FOR A REASON | - | - | - | - | 0.1 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 17.6 | +0.0 | 984.3 | 171.0 | 7.1 | +0.0 | 151.4 | 70.7 |
| STAY WORTH | 10.4 | -104.7 | 255.0 | 56.4 | 12.4 | +208.2 | 73.6 | 297.1 |
| STOPS | 0.1 | +13.7 | 23.6 | 0.0 | - | - | - | - |
| SUPPORT NARROWED | 0.9 | +0.0 | 135.4 | 12.1 | 1.0 | +0.0 | 51.0 | 33.3 |
| THE DEARER SUM KEEPS ITS PLAN | 2.3 | +0.0 | 0.0 | 50.1 | 3.3 | +0.0 | 0.0 | 68.9 |
| THE PROMISE ADDS | 0.3 | -2.2 | 0.0 | 7.4 | 0.1 | -1.4 | 0.0 | 0.0 |
| THE PROMISED MOVE | 0.3 | +0.0 | 0.0 | 0.0 | 1.1 | +0.0 | 0.0 | 18.0 |
| TIED UP BY THE SUM | 0.3 | +19.1 | 15.9 | 0.0 | 0.4 | +41.0 | 31.1 | 0.0 |
| TIME ON OUR SIDE | 24.6 | +414.5 | 11.7 | 283.3 | 7.3 | +162.6 | 0.0 | 66.3 |
| WAITS AGAIN | 1.6 | +0.0 | 0.0 | 51.7 | 1.4 | +0.0 | 0.0 | 8.6 |
| WAR ENGINE JOBS | 0.4 | +0.0 | 57.1 | 0.0 | - | - | - | - |
| WHO HITS BACK | 0.1 | +9.4 | 0.0 | 13.0 | 0.1 | +1.5 | 0.0 | 0.0 |
| WHOLE FIGHT | 0.1 | -1.3 | 21.4 | 0.0 | - | - | - | - |
| WHOLE FIGHT GAIN | 0.6 | +25.6 | 21.4 | 14.9 | 0.3 | +83.9 | 104.0 | 0.0 |
| WIDER SPREAD | 1.7 | +17.3 | 222.3 | 27.0 | 2.1 | -4.9 | 364.6 | 159.6 |
| WOUNDS ON THE RANKS | 1.7 | +69.2 | 0.0 | 104.0 | 2.6 | +104.3 | 0.0 | 0.0 |

### Rule changes: h9-opp-81fb82c-p3

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HOLDER ASSIGNMENT | 110 | 110 | 103 | 14.71 | +5838 | +56.7 |
| ONE TARGET A SHOOTER | 242 | 242 | 64 | 9.14 | +664 | +10.4 |
| HIS SHOT LIST | 224 | 224 | 60 | 8.57 | +1276 | +21.3 |
| DEPLOY BY FIGURES | 96 | 96 | 57 | 8.14 | +945 | +16.6 |
| SEARCH SPOT | 55 | 55 | 51 | 7.29 | +2582 | +50.6 |
| LEGAL CHARGES ONLY | 49 | 49 | 49 | 7.00 | +0 | +0.0 |
| PATHS CROSS | 46 | 46 | 46 | 6.57 | +1318 | +28.7 |
| TIME ON OUR SIDE | 223 | 185 | 45 | 6.43 | +222 | +4.9 |
| FIVE ACTION | 541 | 541 | 33 | 4.71 | +1809 | +54.8 |
| MOVE TO CHARGE COMPUTED | 44 | 44 | 30 | 4.29 | +2592 | +86.4 |
| FOUR ROUNDS | 37 | 37 | 24 | 3.43 | +1759 | +73.3 |
| SHOT RISK POINTS | 139 | 139 | 22 | 3.14 | +371 | +16.9 |
| MARCH CHECK | 27 | 27 | 20 | 2.86 | +386 | +19.3 |
| MISSILES IN THE MOVE | 91 | 67 | 17 | 2.43 | +746 | +43.9 |
| ARTILLERY RE-ROLL WEIGHED | 16 | 16 | 16 | 2.29 | +0 | +0.0 |
| COVER ONCE | 77 | 63 | 16 | 2.29 | +272 | +17.0 |
| MAX FOR POSITIONING | 75 | 73 | 14 | 2.00 | +31 | +2.2 |
| MANOEUVRE | 23 | 23 | 13 | 1.86 | +278 | +21.4 |
| LONE WIZARD KEPT IN | 12 | 12 | 12 | 1.71 | +1060 | +88.4 |
| CHARGE LOSSES | 79 | 79 | 11 | 1.57 | +849 | +77.2 |
| CANNON SIGHT KEPT | 10 | 10 | 10 | 1.43 | +0 | +0.0 |
| HARD STAY DROPPED | 10 | 10 | 10 | 1.43 | +0 | +0.0 |
| CASTING BLOCK | 9 | 9 | 9 | 1.29 | +182 | +20.2 |
| RISK BY HIS FIGURE | 159 | 159 | 9 | 1.29 | +1014 | +112.6 |
| CHARGE NOT DECLARED | 8 | 8 | 8 | 1.14 | -854 | -106.8 |
| FALLS SHORT | 144 | 129 | 8 | 1.14 | +91 | +11.4 |
| MARCH BY THE SUM | 7 | 7 | 7 | 1.00 | +302 | +43.1 |
| QUARTER ODDS | 45 | 45 | 7 | 1.00 | +710 | +101.4 |
| RISK BY ARC | 25 | 25 | 7 | 1.00 | +236 | +33.6 |
| SHOOTS FROM THE BEST SPOT | 10 | 10 | 7 | 1.00 | +86 | +12.3 |
| HOLDER AT DEPLOYMENT | 10 | 10 | 6 | 0.86 | +288 | +48.0 |
| LANE BY FIGURES | 6 | 6 | 6 | 0.86 | +236 | +39.3 |
| ONE OBJECTIVE FORMULA | 83 | 68 | 6 | 0.86 | +375 | +62.5 |
| REDIRECT COUNTER | 32 | 24 | 6 | 0.86 | +208 | +34.7 |
| RESERVE FALL BACK | 6 | 6 | 6 | 0.86 | +284 | +47.4 |
| SHOTS IN THE MOVE | 148 | 129 | 6 | 0.86 | +160 | +26.7 |
| STAY WORTH | 160 | 147 | 6 | 0.86 | +135 | +22.5 |
| ADVANCE LANE KEPT | 5 | 5 | 5 | 0.71 | +0 | +0.0 |
| CASTER AWAY FROM SCREEN | 5 | 5 | 5 | 0.71 | +0 | +0.0 |
| HOLDS AMBUSHERS | 5 | 5 | 5 | 0.71 | +0 | +0.0 |
| NEXT CHARGE BY LIST | 68 | 68 | 5 | 0.71 | +3 | +0.5 |
| NEXT OBJECTIVE NEARER | 41 | 41 | 5 | 0.71 | +39 | +7.9 |
| TIED UP BY THE SUM | 5 | 5 | 5 | 0.71 | +121 | +24.2 |
| WOUNDS ON THE RANKS | 30 | 30 | 5 | 0.71 | +171 | +34.2 |
| FOLLOW UP WEIGHED | 4 | 4 | 4 | 0.57 | +807 | +201.8 |
| NEARER NOT NEEDED | 74 | 69 | 4 | 0.57 | +162 | +40.6 |
| OFF BEST | 4 | 4 | 4 | 0.57 | -156 | -39.0 |
| ONE FIGHT FORMULA | 64 | 34 | 4 | 0.57 | +57 | +14.3 |
| RANDOM MOVE BY FIGURES | 10 | 10 | 4 | 0.57 | +161 | +40.3 |
| CANNON PLANNED TARGET | 42 | 42 | 3 | 0.43 | +32 | +10.7 |
| COMBAT PIVOT | 3 | 3 | 3 | 0.43 | +0 | +0.0 |
| FEATURE BUFFS | 32 | 32 | 3 | 0.43 | +17 | +5.7 |
| FIGHT TO THE END | 11 | 11 | 3 | 0.43 | +639 | +212.9 |
| IDLE COST | 50 | 38 | 3 | 0.43 | +86 | +28.5 |
| MOVES UNITS SPELL | 3 | 3 | 3 | 0.43 | +118 | +39.2 |
| OPENS UP | 4 | 4 | 3 | 0.43 | +156 | +51.8 |
| AFTERMATH IN POINTS | 2 | 2 | 2 | 0.29 | +590 | +295.1 |
| BOMBING RUN | 2 | 2 | 2 | 0.29 | +47 | +23.7 |
| CHAFF PASSED | 2 | 2 | 2 | 0.29 | +0 | +0.0 |
| CHARGE NOW FIRST | 17 | 17 | 2 | 0.29 | -242 | -121.2 |
| HIS CHARGE DENIED | 7 | 7 | 2 | 0.29 | +30 | +15.0 |
| KEEP FALLS | 2 | 2 | 2 | 0.29 | +52 | +25.8 |
| NO RALLY LEFT | 2 | 2 | 2 | 0.29 | +482 | +241.1 |
| OVERRUNS AWAY | 4 | 4 | 2 | 0.29 | +172 | +86.2 |
| REDIRECT WEIGHED | 2 | 2 | 2 | 0.29 | +256 | +127.8 |
| SCOUT WAITS | 2 | 2 | 2 | 0.29 | +0 | +0.0 |
| SHOOTERS IN TWO RANKS | 2 | 2 | 2 | 0.29 | +2 | +1.0 |
| WHO HITS BACK | 2 | 2 | 2 | 0.29 | +12 | +6.0 |
| BEST PRIZE | 1 | 1 | 1 | 0.14 | -21 | -20.9 |
| CHAFF IN THE MOVE | 2 | 1 | 1 | 0.14 | +0 | +0.0 |
| FIRE AND FLEE | 1 | 1 | 1 | 0.14 | +9 | +8.9 |
| FIRE IN ORDER | 1 | 1 | 1 | 0.14 | +0 | +0.0 |
| HIS MOVE AND SHOT | 28 | 28 | 1 | 0.14 | +22 | +22.3 |
| HIS TURN DENIED | 15 | 15 | 1 | 0.14 | +72 | +71.7 |
| HUNT IN PAIRS | 2 | 2 | 1 | 0.14 | +91 | +91.3 |
| PURSUES BIG PREY | 1 | 1 | 1 | 0.14 | -120 | -120.0 |
| REFORMS TO MEET IT | 6 | 6 | 1 | 0.14 | +8 | +7.6 |
| REFUSING RETIRES | 1 | 1 | 1 | 0.14 | -0 | -0.1 |
| WHOLE FIGHT GAIN | 6 | 6 | 1 | 0.14 | +27 | +26.9 |
| ALREADY CARRIED | 1 | not checked | - | - | - | - |
| BLOWS WHERE AIMED | 1 | 1 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 3 | 3 | 0 | 0.00 | - | - |
| CAST JOB | 8 | 8 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 9 | trace | - | - | - | - |
| CHARGER SLAIN LOST | 9 | 9 | 0 | 0.00 | - | - |
| CHEAP HELPER | 3 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 17 | not checked | - | - | - | - |
| DEFENSIVE FLOOR | 1 | 1 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 24 | 24 | 0 | 0.00 | - | - |
| FALLBACK BY WORTH | 2 | 2 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 66 | not checked | - | - | - | - |
| FRIEND SHOOTS FIRST | 6 | 6 | 0 | 0.00 | - | - |
| GIVES UP | 2 | 2 | 0 | 0.00 | - | - |
| GROUND FLIERS | 1 | not checked | - | - | - | - |
| GUN FIGURES | 10 | not checked | - | - | - | - |
| GUN MASK | 9 | 9 | 0 | 0.00 | - | - |
| HE SHOOTS OR CHARGES | 31 | 31 | 0 | 0.00 | - | - |
| HELPER ALREADY ASKED | 2 | not checked | - | - | - | - |
| HELPER UNSEEN | 1 | 1 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 25 | 25 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 47 | 47 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 8 | 8 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 20 | 20 | 0 | 0.00 | - | - |
| HOLD ODDS | 95 | 95 | 0 | 0.00 | - | - |
| HONEST WORTH | 25 | 25 | 0 | 0.00 | - | - |
| HUNT RESULT | 1 | trace | - | - | - | - |
| HUNT THE GUNS | 1 | trace | - | - | - | - |
| LONG SHOT | 3 | 3 | 0 | 0.00 | - | - |
| LOST CHARGE | 2 | 2 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 1 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 5 | trace | - | - | - | - |
| MARCH OVER CASTS | 19 | 19 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 2 | 2 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 104 | 75 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 6 | trace | - | - | - | - |
| MOVE SPELL SPOT | 2 | not checked | - | - | - | - |
| NO DOUBLE ROUNDS | 31 | 31 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 10 | not checked | - | - | - | - |
| ONE CHARGE A CHARGER | 26 | 26 | 0 | 0.00 | - | - |
| ONE ROUTE | 2 | 2 | 0 | 0.00 | - | - |
| PLAN RESULT | 475 | trace | - | - | - | - |
| REAL GROUND | 2 | 2 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 1 | 1 | 0 | 0.00 | - | - |
| RUN DOWN | 26 | 26 | 0 | 0.00 | - | - |
| SCOUT SPOT | 2 | 2 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 5 | 5 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 6 | not checked | - | - | - | - |
| SET UP TOGETHER | 1 | not checked | - | - | - | - |
| SHOT OR CHARGE | 7 | 7 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 1 | not checked | - | - | - | - |
| SPELL WORTH | 4 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 5 | 5 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 1 | 1 | 0 | 0.00 | - | - |
| STANDS STILL | 173 | 173 | 0 | 0.00 | - | - |
| STOPS | 1 | 1 | 0 | 0.00 | - | - |
| SUPPORT NARROWED | 13 | 13 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 39 | not checked | - | - | - | - |
| THE PROMISE ADDS | 3 | 3 | 0 | 0.00 | - | - |
| THE PROMISED MOVE | 10 | not checked | - | - | - | - |
| WAITS AGAIN | 21 | 21 | 0 | 0.00 | - | - |
| WAR ENGINE JOBS | 3 | 3 | 0 | 0.00 | - | - |
| WHOLE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| WIDER SPREAD | 27 | 27 | 0 | 0.00 | - | - |

### Off best figure: h9-opp-81fb82c-p3

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| PATHS CROSS | rule | 0.86 | 0.43 | 34.7 |
| CHARGE NOT DECLARED | rule | 0.86 | 0.29 | 106.8 |
| HOLDER ASSIGNMENT | rule | - | 1.00 | 16.2 |
| CHARGE NOW FIRST | rule | 0.14 | 0.14 | 121.2 |
| NO REASON | gate | - | 0.29 | 22.5 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.14 | - | 35.4 |
| BEST PRIZE | rule | - | 0.14 | 20.9 |
| DEPLOY BY FIGURES | rule | - | 0.14 | 4.7 |
| FALLBACK | gate | 0.14 | - | 75.5 |
| PURSUES BIG PREY | rule | 0.14 | - | 120.0 |

### Plans: h9-opp-81fb82c-p3

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 2.0 | 50% | 231 | 224 | 97% |
| Mine | move | 25.6 | 95% | 1894 | 0 | 0% |
| Mine | shoot | 8.4 | 69% | 373 | 823 | 221% |
| Mine | support | 0.6 | 75% | 3 | 0 | 0% |
| Opponent | charge | 2.4 | 65% | 699 | 219 | 31% |
| Opponent | move | 25.0 | 95% | 2499 | 0 | 0% |
| Opponent | shoot | 3.9 | 56% | 230 | 190 | 83% |

### Packages: hunt the guns, h9-opp-81fb82c-p3

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.1 | 1 | 0 | 100% | 100% | 0% | 2.0 | 335 | 278 | 100% | 20 |
| Opponent | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 57 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.2 | 1 | 0 | 100% | 100% | 0% | 2.0 | 335 | 278 | 100% | 34 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 200 |
| Warriors of Chaos | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |

### Battle groups: h9-opp-81fb82c-p3

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 2.7 | 16% | 33% | 0% | - | 33% | 0% | 0% | 67% | 0% |
| Opponent | REDIRECT COUNTER | 1.9 | 23% | 100% | 0% | - | 0% | 0% | 67% | 33% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: h9-opp-81fb82c-p3

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 5 | 9 (5) | 0 | 9 | 62 | 80% | 1.0 | 0 (1) | 21 (2) | 0 (2) | 11 (4) | 0 (1) |
| Mine | Character | 24 | 22 (24) | 22 | 0 | 23 | 33% | 2.4 | 8 (3) | 7 (15) | 99 (2) | 33 (12) | 15 (8) |
| Mine | Clean-up | 6 | 34 (6) | 34 | 0 | 67 | 17% | 3.2 | 13 (1) | 0 (2) | 64 (3) | 69 (3) | 0 (3) |
| Mine | Fast Hammer | 4 | 63 (4) | 63 | 0 | 100 | 25% | 3.0 | - | - | 63 (4) | 0 (2) | 126 (2) |
| Mine | Hammer | 18 | 39 (18) | 20 | 18 | 34 | 22% | 2.4 | 46 (3) | 39 (13) | 0 (2) | 42 (13) | 31 (5) |
| Mine | Holder | 11 | 111 (11) | 6 | 106 | 17 | 82% | 3.5 | 0 (3) | 216 (4) | 94 (4) | 161 (5) | 61 (6) |
| Mine | Shooter | 4 | 62 (4) | 0 | 62 | 50 | 25% | 2.3 | 46 (1) | 100 (2) | 0 (1) | 67 (3) | 46 (1) |
| Mine | War machine | 8 | 34 (8) | 34 | 0 | 29 | 0% | 1.6 | 118 (2) | 0 (6) | - | 118 (2) | 0 (6) |
| Mine | Wizard | 8 | 39 (8) | 39 | 0 | 11 | 12% | 3.3 | 0 (1) | 44 (7) | - | 0 (3) | 64 (5) |
| Opponent | Chaff | 5 | 129 (5) | 0 | 129 | 44 | 60% | 3.5 | 300 (1) | 122 (2) | 0 (2) | 144 (4) | 92 (1) |
| Opponent | Character | 21 | 41 (21) | 41 | 0 | 19 | 29% | 2.2 | 7 (4) | 44 (12) | 62 (5) | 27 (15) | 78 (6) |
| Opponent | Clean-up | 2 | 79 (2) | 0 | 79 | 0 | 0% | 2.0 | - | 79 (2) | - | 70 (1) | 88 (1) |
| Opponent | Fast | 1 | 0 (1) | 0 | 0 | 100 | 0% | 4.0 | 0 (1) | - | - | 0 (1) | - |
| Opponent | Fast Hammer | 16 | 55 (16) | 22 | 33 | 28 | 44% | 2.8 | 35 (4) | 28 (8) | 125 (4) | 54 (11) | 56 (5) |
| Opponent | Hammer | 1 | 35 (1) | 0 | 35 | 100 | 0% | 2.0 | - | - | 35 (1) | 35 (1) | - |
| Opponent | Holder | 2 | 39 (2) | 0 | 39 | 0 | 100% | - | - | 39 (2) | - | 39 (1) | 38 (1) |
| Opponent | Shooter | 7 | 137 (7) | 42 | 95 | 13 | 0% | 2.0 | 11 (2) | 196 (4) | 170 (1) | 167 (5) | 66 (2) |
| Opponent | War machine | 6 | 17 (6) | 17 | 0 | 41 | 0% | 2.5 | 21 (4) | 0 (2) | - | - | 17 (6) |
| Opponent | Wizard | 3 | 2 (3) | 2 | 0 | 0 | 0% | 2.7 | - | 0 (2) | 4 (1) | 2 (3) | - |

### Charged fights: h9-opp-81fb82c-p3

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 52 | 89 | 2.0 | 1.4 | 44 | 55 | -10 | 4 of 8 | 5 of 8 | -137 | +32 |
| Mine | Chaos Dwarfs | 3 | 387 | 331 | 1.0 | 1.0 | 331 | 0 | +331 | 2 of 3 | 3 of 3 | - | +331 |
| **Mine** | all armies | 7 | 195 | 193 | 1.6 | 1.3 | 123 | 40 | +83 | 6 of 11 | 8 of 11 | -137 | +132 |
| Opponent | Grand Cathay | 2 | 184 | 446 | 3.5 | 1.1 | 127 | 0 | +127 | 2 of 7 | 6 of 7 | +335 | +93 |
| Opponent | High Elf Realms | 2 | 158 | 310 | 1.5 | 1.0 | 207 | 20 | +187 | 2 of 3 | 1 of 3 | - | +187 |
| Opponent | Warriors of Chaos | 3 | 28 | 170 | 1.7 | 1.0 | 102 | 35 | +68 | 3 of 5 | 4 of 5 | - | +68 |
| **Opponent** | all armies | 7 | 110 | 289 | 2.1 | 1.1 | 135 | 16 | +119 | 7 of 15 | 11 of 15 | +335 | +104 |

### Effective charges: h9-opp-81fb82c-p3

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 8 | 4 (net -69) | 0 | 1 (net +150) | 0 | 0 | 2 (net +20) | 1 | 14% (1 of 7) |
| Mine | Chaos Dwarfs | 3 | 1 (net +482) | 0 | 0 | 0 | 1 (net +70) | 1 (net +442) | 0 | 0% (0 of 3) |
| Opponent | Grand Cathay | 7 | 1 (net +335) | 0 | 0 | 1 (net +0) | 2 (net +26) | 2 (net +220) | 1 | 0% (0 of 6) |
| Opponent | High Elf Realms | 3 | 0 | 0 | 0 | 2 (net +310) | 0 | 0 | 1 | 0% (0 of 2) |
| Opponent | Warriors of Chaos | 5 | 1 (net -173) | 0 | 0 | 1 (net +420) | 0 | 2 (net +0) | 1 | 0% (0 of 4) |

### Charged fights, damage counted: h9-opp-81fb82c-p3

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 5 | 149 | 388 | +41 | 149 | 93 | +56 | +37.3 |
| Mine | Effective (55-75%) | 1 | 85 | 150 | +150 | 150 | 0 | +150 | +176.5 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 | 166 | 178 | +161 | 161 | 0 | +161 | +96.8 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 310 | 70 | +70 | 70 | 0 | +70 | +22.6 |
| Mine | No odds | 1 | 501 | 358 | +0 | 179 | 0 | +179 | +35.7 |
| Mine | All fights | 11 | 195 | 278 | +83 | 148 | 42 | +105 | +54.2 |
| Opponent | Long shot (under 50%) | 2 | 320 | 408 | +81 | 271 | 105 | +166 | +52.0 |
| Opponent | 76-89% | 4 | 460 | 199 | +260 | 260 | 0 | +260 | +56.5 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 4 | 394 | 247 | +110 | 173 | 0 | +173 | +43.9 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 2 | 301 | 66 | +26 | 26 | 0 | +26 | +8.6 |
| Opponent | No odds | 3 | 238 | 92 | +32 | 68 | 52 | +17 | +7.0 |
| Opponent | All fights | 15 | 358 | 201 | +119 | 169 | 24 | +144 | +40.3 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| h9-opp-81fb82c-p3 | move | 46 | 9 (20%) | 4 (9%) | 6 (13%) | 31 (67%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0111, L0128 |
| Elixir of Power | Opponent | L0111, L0211 |
| Ring of Doom | Mine | L0211, L0228 |
| Ring of Doom | Opponent | L0111, L0211, L0415 |
| Ring of Jet | Opponent | L0111, L0211 |
| Standard of the Fell Warrior | Opponent | L0313 |

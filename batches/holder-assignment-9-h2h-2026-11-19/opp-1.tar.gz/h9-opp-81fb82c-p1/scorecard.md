# Doctrine scorecard: h9-opp-81fb82c-p1

### Scorecard: h9-opp-81fb82c-p1

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0103 | 1 | 1 | Mine | no | 3 | - | 0 | 1 | 0 | 0 | 0 | 0 |
| L0103 | 1 | 1 | Opponent | no | 2 | - | 0 | 1 | 0 | 0 | 0 | 455 |
| L0120 | 6 | 1 | Mine | no | 9 | - | 0 | 1 | 0 | 0 | 0 | 0 |
| L0120 | 6 | 1 | Opponent | no | 4 | - | 1 | 2 | 0 | 0 | 0 | 0 |
| L0204 | 6 | 1 | Mine | no | 5 | 6 | 0 | 4 | 0 | 0 | 0 | 0 |
| L0204 | 6 | 1 | Opponent | no | 1 | 1 | 2 | 1 | 0 | 0 | 0 | 0 |
| L0219 | 3 | 1 | Mine | yes | 0 | 2 | 4 | 1 | 0 | 0 | 0 | 170 |
| L0219 | 3 | 1 | Opponent | yes | 8 | 2 | 1 | 0 | 1 | 0 | 0 | 0 |
| L0304 | 4 | 1 | Mine | no | 0 | 4 | 1 | 0 | 0 | 0 | 0 | 110 |
| L0304 | 4 | 1 | Opponent | no | 1 | 2 | 3 | 1 | 0 | 0 | 0 | 112 |
| L0321 | 3 | 1 | Mine | yes | 3 | 6 | 2 | 1 | 0 | 0 | 0 | 140 |
| L0321 | 3 | 1 | Opponent | yes | 4 | - | 0 | 4 | 0 | 0 | 0 | 500 |
| L0406 | 4 | 1 | Mine | no | 0 | 3 | 2 | 3 | 0 | 0 | 0 | 0 |
| L0406 | 4 | 1 | Opponent | no | 0 | 4 | 2 | 0 | 1 | 0 | 0 | 413 |
| L0423 | 3 | 1 | Mine | no | 3 | 2 | 5 | 0 | 0 | 0 | 0 | 0 |
| L0423 | 3 | 1 | Opponent | no | 4 | 2 | 3 | 0 | 1 | 0 | 0 | 0 |
| L0510 | 6 | 1 | Mine | no | 6 | - | 0 | 2 | 0 | 0 | 0 | 350 |
| L0510 | 6 | 1 | Opponent | no | 6 | 2 | 1 | 2 | 0 | 0 | 0 | 330 |
| **Average** | | | Mine | 22% | 3.2 | 3.8 | 1.6 | 1.4 | 0.0 | 0.0 | 0.0 | 85.6 |
| **Average** | | | Opponent | 22% | 3.3 | 2.2 | 1.4 | 1.2 | 0.3 | 0.0 | 0.0 | 201.1 |

### KPIs: h9-opp-81fb82c-p1

Rules off - Mine only: HOLDER ASSIGNMENT, QUARTER ODDS, WALK PROMISE, REAL GROUND, RISK ON THE WAY, ONE ROUTE, MARCH WHEELS ONLY, LATE ONLY FROM HERE, WALKS ON ITS ROUTE.

Morten 2026-11-10; 9 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 30% (12 of 40) | 19% (8 of 42) | 24% (20 of 82) |
| Winner chose to follow up after the loser gave ground |  | 82% (9 of 11); on the table 82% | 80% (4 of 5); on the table 80% | 81% (13 of 16); on the table 81% |
| Winner chose to pursue after the loser fell back in good order |  | 100% (2 of 2); on the table 100% | - | 100% (2 of 2); on the table 100% |
| Winner chose to pursue after the loser fled |  | 25% (2 of 8); on the table 38% | 100% (2 of 2); on the table 100% | 40% (4 of 10); on the table 50% |
| Winner chose to follow up or pursue (all three) |  | 62% (13 of 21); on the table 67% | 86% (6 of 7); on the table 86% | 68% (19 of 28); on the table 71% |
| Magic missiles tried each own turn | 50%+ | 42% (58 of 138) | 33% (24 of 72) | 39% (82 of 210) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 48% (58 of 120) | 44% (24 of 54) | 47% (82 of 174) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 50% (5 of 10) | 64% (14 of 22) | 59% (19 of 32) |
| Points that never fought | lower | 44% (7378 of 16788) | 53% (9526 of 17994) | 49% (16904 of 34782) |
|   infantry points that never fought | lower | 56% (2775 of 4914) | 74% (3243 of 4400) | 65% (6018 of 9314) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 53% (31 of 59) | 56% (41 of 73) | 55% (72 of 132) |
| Bound items with a magic missile used (at least once a game) |  | 100% (6 of 6); 2.0 uses a game | 33% (1 of 3); 0.1 uses a game | 78% (7 of 9); 1.1 uses a game |
| Bound items with another spell used |  | 100% (2 of 2); 0.8 uses a game | 0% (0 of 1); 0.0 uses a game | 67% (2 of 3); 0.4 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 75% (6 of 8); 0.7 uses a game | 40% (2 of 5); 0.2 uses a game | 62% (8 of 13); 0.4 uses a game |
|   their share of the points of units over 100 pts | lower | 45% (5821 of 12900) | 52% (8049 of 15548) | 49% (13870 of 28448) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 3.4 (39%) | 1.9 (35%) | 5.3 (38%) |
| MARCHED: its unit marched | 3.2 (36%) | 1.0 (19%) | 4.2 (30%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.3 (6%) | 0.3 (2%) |
| IN COMBAT: engaged in combat | 1.4 (16%) | 1.6 (29%) | 3.0 (21%) |
| FLEEING: fleeing | 0.0 (0%) | 0.1 (2%) | 0.1 (1%) |
| GONE: slain | 0.6 (6%) | 0.1 (2%) | 0.7 (5%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (0%) | 0.2 (4%) | 0.2 (2%) |
| STUPIDITY: Stupidity | 0.2 (2%) | 0.0 (0%) | 0.2 (2%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.1 (2%) | 0.1 (1%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 5.4 | 0.9 | 2.7 | 9.1 | 0.8 | 1.4 |
| not cast | 1.9 | 1.1 | 5.3 | 14.2 | 2.6 | 21.2 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.9 (4%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.6 (50%) | 1.2 (23%) | 5.3 (38%) | 0.4 (17%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 4.2 (30%) | 0.4 (17%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (2%) | 0.1 (4%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.2 (12%) | 0.0 (0%) | 1.1 (21%) | 3.0 (21%) | 0.8 (30%) | 0.0 (0%) |
| NO CASTS LEFT: every cast used on other spells | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (4%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (0%) | 0.0 (0%) | 0.1 (2%) | 0.1 (1%) | 0.0 (0%) | 0.3 (2%) |
| GONE: slain | 0.2 (12%) | 0.0 (0%) | 0.0 (0%) | 0.7 (5%) | 0.3 (13%) | 1.0 (5%) |
| OFF THE TABLE: off the table or not arrived | 0.1 (6%) | 0.1 (10%) | 0.2 (4%) | 0.2 (2%) | 0.0 (0%) | 0.6 (3%) |
| STUPIDITY: Stupidity | 0.1 (6%) | 0.0 (0%) | 0.0 (0%) | 0.2 (2%) | 0.0 (0%) | 0.4 (2%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (6%) | 0.0 (0%) | 0.1 (2%) | 0.1 (1%) | 0.3 (13%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.1 (59%) | 0.4 (40%) | 2.6 (48%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 18.0 (85%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 3.0 a game | 0.4 a game | 1.7 a game |
| stood (cast and not dispelled) | 56% (15 of 27) | 50% (2 of 4) | 55% (17 of 31) |
| the unit moved after it | 73% (11 of 15) | 100% (2 of 2) | 76% (13 of 17) |
| it charged on its next turn | 0% (0 of 15) | 0% (0 of 2) | 0% (0 of 17) |
| the enemy charged it first | 7% (1 of 15) | 0% (0 of 2) | 6% (1 of 17) |
| it fought by the end of its next turn | 7% (1 of 15) | 0% (0 of 2) | 6% (1 of 17) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 15) | 0% (0 of 2) | 0% (0 of 17) |
| none of these (no charge, no fight, no charge escaped) | 93% (14 of 15) | 100% (2 of 2) | 94% (16 of 17) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 66% (103 of 157) | 63% (132 of 208) | 64% (235 of 365) |
|   cavalry | 75% (9 of 12) | 60% (12 of 20) | 66% (21 of 32) |
|   character | 86% (12 of 14) | 33% (4 of 12) | 62% (16 of 26) |
|   chariot | 52% (17 of 33) | 65% (35 of 54) | 60% (52 of 87) |
|   infantry | 56% (19 of 34) | 59% (39 of 66) | 58% (58 of 100) |
|   monster | - | 100% (3 of 3) | 100% (3 of 3) |
|   war machine | 72% (46 of 64) | 74% (39 of 53) | 73% (85 of 117) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.2 (37%) | 1.7 (20%) | 3.9 (27%) |
| CHARGED: it charged | 0.3 (6%) | 1.2 (14%) | 1.6 (11%) |
| FLEEING: it fled or was fleeing | 0.1 (2%) | 0.0 (0%) | 0.1 (1%) |
| IN COMBAT: it fought this turn or the last | 0.2 (4%) | 0.3 (4%) | 0.6 (4%) |
| MOVED: a war machine that moved | 1.4 (24%) | 0.2 (3%) | 1.7 (12%) |
| NO TARGET IN RANGE | 1.1 (19%) | 2.6 (30%) | 3.7 (25%) |
| ONLY IN COMBAT: the only targets were in combat | 0.0 (0%) | 0.4 (5%) | 0.4 (3%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.1 (2%) | 1.6 (18%) | 1.7 (12%) |
| SHELTERED: the target was sheltered | 0.1 (2%) | 0.0 (0%) | 0.1 (1%) |
| OTHER BAR | 0.3 (6%) | 0.4 (5%) | 0.8 (5%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 2.3 | 0.4 | 81% | 3.1 pts | 7 pts |
| character | 1.8 | 0.9 | 56% | 11.4 pts | 20 pts |
| chariot | 6.1 | 8.6 | 36% | 24.7 pts | 151 pts |
| infantry | 8.9 | 2.0 | 86% | 3.1 pts | 27 pts |
| monster | 0.3 | 0.0 | 100% | 0.0 pts | 0 pts |
| war machine | 9.4 | 6.3 | 71% | 19.1 pts | 180 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 2.6 | 4.2 | 3.4 |
| Charges that made contact a game | 2.0 | 3.3 | 2.7 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.67 declared, 0.67 contact (6 units) | 1.22 declared, 1.00 contact (9 units) | 1.00 declared, 0.87 contact (15 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | - | - |
|   per unit a game, the other units (no war machines, no joined characters) | 0.33 declared, 0.25 contact (57 units) | 0.39 declared, 0.30 contact (69 units) | 0.37 declared, 0.28 contact (126 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 50% (3 of 6) | 100% (1 of 1) | - | 57% (4 of 7) |
| Character in a unit | 75% (9 of 12) | 56% (5 of 9) | - | 67% (14 of 21) |
| Character on its own | 89% (8 of 9) | 43% (3 of 7) | 20% (2 of 10) | 50% (13 of 26) |
| Chariot | 67% (2 of 3) | 50% (6 of 12) | - | 53% (8 of 15) |
| Infantry | 32% (7 of 22) | 31% (4 of 13) | - | 31% (11 of 35) |
| Monster | 80% (4 of 5) | 67% (2 of 3) | - | 75% (6 of 8) |
| Monstrous | - | 50% (1 of 2) | - | 50% (1 of 2) |
| War Machines | 80% (12 of 15) | 100% (3 of 3) | - | 83% (15 of 18) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 58% (7 of 12); on the table 67% | 42% (43 of 102) | 36% | 45% (10 of 22) | 100% (6 of 6); 4.5 uses a game | 100% (2 of 2); 1.8 uses a game | 83% (5 of 6); 1.2 uses a game |
| Chaos Dwarfs | 7 | 70% (7 of 10); on the table 70% | 43% (26 of 60) | 51% | 54% (29 of 54) | 0.0 uses a game | 0.0 uses a game | 33% (1 of 3); 0.1 uses a game |
| Dwarfen Mountain Holds | 2 | 50% (1 of 2); on the table 50% | - | 65% | 71% (12 of 17) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Grand Cathay | 1 | - | 23% (7 of 30) | 48% | 40% (4 of 10) | 50% (1 of 2); 1.0 uses a game | 0% (0 of 1); 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Orc & Goblin Tribes | 1 | - | 17% (1 of 6) | 0% | 62% (5 of 8) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Skaven | 2 | 100% (2 of 2); on the table 100% | 42% (5 of 12) | 82% | 56% (9 of 16) | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 100% (2 of 2); 1.0 uses a game |
| Tomb Kings of Khemri | 1 | 100% (2 of 2); on the table 100% | - | 27% | 60% (3 of 5) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (h9-opp-81fb82c-p1, 9 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 52% (11) | 40% (6) | 47% (17) |
| ...free all their last turn and able to turn (per game) | 0.67 | 0.67 | 1.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.44 | 0.00 | 0.44 |
| ...with the charger already in that arc before they moved (per game) | 0.67 | 0.33 | 1.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: h9-opp-81fb82c-p1

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.4 | 1.8 |
| Strategy | Charge objectives carried out (made contact) | 78% (18 of 23) | 65% (20 of 31) |
| Strategy | Shoot objectives carried out (shot that target) | 28% (25 of 89) | 44% (41 of 93) |
| Strategy | Support requests answered (helper made contact too) | 100% (3 of 3) | 100% (2 of 2) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | - | 100% (3 of 3) |
| Strategy | Hexes on a unit its side charged or shot that turn | 0% (0 of 1) | 67% (2 of 3) |
| Strategy | Joined characters whose unit fought | 56% (15 of 27) | 12% (1 of 8) |
| Strategy | Lone characters that fought | 64% (9 of 14) | 75% (15 of 20) |
| Movement | Charges halted short of contact | 0.1 | 0.0 |
| Movement | Idle units | 1.4 | 1.2 |
| Movement | Points that never moved of their own | 85.6 | 201.1 |
| Movement | Fights charged into per game | 2.0 | 2.4 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 17 | 2 of 21, net +167 |
| Movement | Charges with odds: sweet spot (55-75%) | 4 of 17, net +19 | 6 of 21, net +14 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 2 of 17, net +33 | 3 of 21, net +257 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 6 of 17, net -14 | 4 of 21, net +148 |
| Shooting | Shots by shooting units (incl. breath weapons) | 6.3 | 11.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 21% (12 of 57) | 35% (36 of 102) |
| Shooting | Points destroyed by shooting units | 154.9 | 11.6 |
| Shooting | War machine shots | 5.1 | 4.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 41% (19 of 46) | 85% (33 of 39) |
| Shooting | Points destroyed by war machines | 101.2 | 7.2 |
| Magic | Magic missiles cast | 3.7 | 1.7 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 39% (13 of 33) | 60% (9 of 15) |
| Magic | Wounds caused by magic missiles | 9.9 | 1.7 |
| Magic | Wounds caused by other spells | 0.4 | 0.1 |
| Magic | Points destroyed by magic (all spells) | 23.4 | 17.1 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.2 / 0.1 / 0.9 / 0.3 | 2.8 / 0.3 / 0.2 / 0.1 |
| Combat | Points destroyed in combat | 195.0 | 243.2 |
| Combat | Points run down | 0.0 | 100.9 |
| Combat | Net points per charged fight, damage counted | +77 | +88 |
| Combat | Net per 100 charger points, damage counted | +27.4 | +25.1 |
| Combat | First round won (charged fights) | 89% | 82% |
| Combat | Net points per charged fight | +31 | +102 |
| Combat | Net points per supported fight / lone fight | -68 / +43 | +230 / +73 |
| Combat | Charged fights on a top-3 enemy unit | 7 of 18 | 10 of 22 |
| Game | Points lost | 416.4 | 653.4 |
| Game | VP from objectives | 728.9 | 647.8 |
| Game | Lone holders (player turns) | 3.2 | 3.3 |

- Mine won / drew / lost: 5 / 3 / 1 of 9 ended games (of 9); mean margin (Mine - Opponent) +400 VP
- The side that went first won 3 of 6 games with a winner
- Points traded per game (both sides' losses): 1070
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: h9-opp-81fb82c-p1

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.9 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.1 | +26.8 | 0.0 | 0.0 | 0.1 | +28.1 | 0.0 | 0.0 |
| ALREADY CARRIED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARTILLERY RE-ROLL WEIGHED | 3.2 | +0.0 | 0.0 | 72.8 | 0.7 | +0.0 | 0.0 | 25.6 |
| BACKUP TARGETS | 0.2 | +2.2 | 0.0 | 0.0 | 0.1 | +0.1 | 0.0 | 0.0 |
| BLOWS WHERE AIMED | 0.1 | -15.1 | 0.0 | 0.0 | 0.2 | +2.1 | 0.0 | 0.0 |
| CANNON PLAN MISSED | 0.7 | +0.0 | 119.7 | 10.6 | 0.4 | +0.0 | 10.6 | 29.4 |
| CANNON PLANNED TARGET | 4.8 | +73.1 | 320.6 | 104.4 | 4.2 | +11.4 | 13.3 | 70.6 |
| CANNON SIGHT KEPT | 1.0 | +0.0 | 0.0 | 0.0 | 0.8 | +0.0 | 0.0 | 0.0 |
| CAST JOB | 1.0 | +11.9 | 76.1 | 0.0 | 1.1 | +6.3 | 9.4 | 0.0 |
| CASTER AWAY FROM SCREEN | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CASTING BLOCK | 0.3 | +54.6 | 0.0 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | 1.7 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | - | - | - | - | 0.1 | +5.2 | 0.0 | 0.0 |
| CHAFF PASSED | 0.1 | +0.0 | 0.0 | 12.4 | 0.3 | +0.0 | 0.0 | 23.3 |
| CHARACTER GUNS | 0.2 | +0.0 | 0.0 | 0.0 | 0.8 | +0.0 | 0.0 | 0.0 |
| CHARGE LOSSES | 6.9 | -175.0 | 0.0 | 37.9 | 6.2 | -220.5 | 0.0 | 123.8 |
| CHARGE NOT DECLARED | 0.8 | +0.0 | 15.1 | 24.7 | 0.3 | +0.0 | 89.9 | 64.4 |
| CHARGE NOW FIRST | 1.3 | +0.0 | 63.9 | 0.0 | 1.7 | +0.0 | 170.7 | 7.8 |
| CHARGER SLAIN LOST | 0.6 | -9.6 | 6.1 | 15.2 | 0.2 | -3.6 | 0.0 | 0.0 |
| CHEAP HELPER | 0.2 | +0.0 | 0.0 | 9.4 | - | - | - | - |
| COMBAT PIVOT | 0.4 | +0.0 | 6.1 | 34.4 | 0.7 | +0.0 | 34.4 | 66.7 |
| CONVEYANCE SEARCH | 2.1 | +256.8 | 0.0 | 0.0 | 0.3 | +26.5 | 0.0 | 0.0 |
| COVER ONCE | 5.9 | -307.5 | 0.0 | 131.9 | 7.4 | -511.3 | 0.0 | 99.2 |
| DEPLOY BY FIGURES | 8.3 | +26.5 | 0.0 | 7.2 | 8.7 | +11.7 | 0.0 | 43.2 |
| EDGE GIVE GROUND | - | - | - | - | 0.1 | +0.3 | 15.6 | 0.0 |
| ENGINEER BY LORE | 0.4 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| FALL BACK GOOD ORDER | 1.4 | +9.4 | 64.1 | 43.9 | 2.6 | +12.7 | 224.3 | 7.8 |
| FALLBACK BY WORTH | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| FALLS SHORT | 9.2 | +160.3 | 0.0 | 54.9 | 14.7 | +184.6 | 0.0 | 129.4 |
| FEATURE BUFFS | 2.2 | +74.9 | 0.0 | 0.0 | 1.0 | +23.5 | 0.0 | 0.0 |
| FIGHT LIFT | - | - | - | - | 0.1 | +0.9 | 64.4 | 64.4 |
| FIGHT TO THE END | 0.7 | +88.3 | 50.0 | 5.8 | 0.7 | +44.1 | 73.3 | 7.8 |
| FIVE ACTION | 44.4 | +2613.6 | 843.9 | 736.1 | 49.2 | +2576.0 | 412.6 | 487.3 |
| FLANK NOT WEIGHED | 2.9 | +0.0 | 0.0 | 173.8 | 4.0 | +0.0 | 0.0 | 41.8 |
| FOLLOW UP WEIGHED | 0.7 | +244.2 | 0.0 | 0.0 | 0.4 | +74.5 | 0.0 | 0.0 |
| FOUR ROUNDS | 2.4 | +335.6 | 129.2 | 55.4 | 3.2 | +300.1 | 306.3 | 7.8 |
| FRIEND CHARGES FIRST | 0.2 | -23.5 | 0.0 | 9.4 | - | - | - | - |
| FRIEND SHOOTS FIRST | 0.7 | -3.6 | 0.0 | 0.0 | 0.3 | -6.3 | 0.0 | 0.0 |
| FRIENDS SHOTS CHECKED | - | - | - | - | 0.1 | +4.8 | 0.0 | 0.0 |
| GIVES UP | - | - | - | - | 0.2 | -1.9 | 26.1 | 0.0 |
| GROUND FLIERS | 0.2 | +7.3 | 0.0 | 24.3 | - | - | - | - |
| GUN FIGURES | 1.8 | +24.6 | 99.6 | 137.8 | 2.7 | +7.9 | 56.4 | 56.1 |
| GUN MASK | 0.1 | +4.7 | 0.0 | 0.0 | 0.4 | +3.0 | 0.0 | 0.0 |
| HARD STAY DROPPED | 0.9 | +0.0 | 0.0 | 5.8 | 1.8 | +0.0 | 0.0 | 0.0 |
| HE SHOOTS OR CHARGES | 2.3 | +0.0 | 0.0 | 121.2 | 3.0 | +0.0 | 0.0 | 24.1 |
| HIS CHARGE DENIED | 0.3 | +10.5 | 34.1 | 0.0 | 0.2 | +8.3 | 0.0 | 0.0 |
| HIS CHARGE LIST | 2.9 | +0.0 | 0.0 | 56.8 | 0.7 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 3.0 | +0.0 | 0.0 | 21.0 | 3.3 | +0.0 | 0.0 | 31.0 |
| HIS MOVE AND SHOT | 2.0 | -23.4 | 0.0 | 14.4 | 1.2 | -37.0 | 0.0 | 0.0 |
| HIS ONE QUARTER | - | - | - | - | 1.1 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVE | 3.3 | +0.0 | 0.0 | 6.1 | 1.7 | +0.0 | 0.0 | 6.1 |
| HIS SHOT LIST | 20.3 | +468.1 | 0.0 | 391.9 | 21.7 | +765.8 | 0.0 | 335.4 |
| HIS TURN DENIED | 0.6 | +17.4 | 45.6 | 34.4 | 1.6 | +56.3 | 182.3 | 0.0 |
| HOLD ODDS | - | - | - | - | 12.4 | +0.0 | 0.0 | 35.9 |
| HOLDER ASSIGNMENT | - | - | - | - | 14.1 | +1270.9 | 0.0 | 35.9 |
| HOLDER AT DEPLOYMENT | 1.1 | +210.2 | 0.0 | 0.0 | - | - | - | - |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 1.7 | -82.7 | 88.7 | 5.8 | 2.9 | -147.0 | 271.9 | 0.0 |
| HUNT IN PAIRS | - | - | - | - | 0.7 | +25.2 | 0.0 | 21.7 |
| IDLE COST | 6.6 | -69.2 | 0.0 | 54.7 | 9.3 | -130.7 | 0.0 | 75.8 |
| KEEP FALLS | 0.1 | +6.8 | 0.0 | 0.0 | - | - | - | - |
| KEEPS SCOUTS OR AMBUSH | - | - | - | - | 0.1 | +0.0 | 0.0 | 0.0 |
| KILLS COUNT | - | - | - | - | 0.1 | +1.7 | 13.3 | 0.0 |
| LANE BY FIGURES | 0.3 | +6.0 | 0.0 | 0.0 | 0.9 | +30.2 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 4.1 | +0.0 | 44.6 | 273.4 | 3.2 | +0.0 | 89.9 | 35.1 |
| LONE WIZARD KEPT IN | 1.1 | +68.7 | 0.0 | 12.8 | 0.3 | +36.3 | 0.0 | 0.0 |
| LONG SHOT | 0.1 | -4.7 | 0.0 | 0.0 | 0.2 | +5.5 | 5.8 | 0.0 |
| LOST CHARGE | 0.2 | -0.8 | 6.7 | 0.0 | - | - | - | - |
| MAKE SURE TOGETHER | - | - | - | - | 0.2 | +4.0 | 0.0 | 0.0 |
| MANOEUVRE | 1.6 | +9.3 | 0.0 | 43.4 | 1.0 | +2.8 | 0.0 | 6.1 |
| MARCH AT ESCAPER | 0.3 | +40.7 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| MARCH BY THE SUM | 0.6 | +13.3 | 0.0 | 0.0 | 0.3 | +12.8 | 0.0 | 0.0 |
| MARCH CHECK | 0.9 | +45.8 | 0.0 | 0.0 | 0.3 | +12.2 | 0.0 | 0.0 |
| MARCH OVER CASTS | 0.9 | -31.2 | 0.0 | 0.0 | 0.7 | +25.7 | 0.0 | 36.6 |
| MARCH WHEELS ONLY | - | - | - | - | 0.9 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 4.1 | +38.7 | 0.0 | 41.7 | 5.1 | +53.2 | 0.0 | 73.1 |
| MISSILES IN THE MOVE | 5.0 | +245.7 | 0.0 | 27.0 | 3.6 | +47.2 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 5.6 | +168.6 | 0.0 | 18.0 | 4.9 | +47.5 | 0.0 | 36.6 |
| MODEL FACING | - | - | - | - | 0.9 | +143.0 | 0.0 | 0.0 |
| MOVE SPELL IN RANGE | 0.4 | +12.3 | 0.0 | 0.0 | 0.1 | +1.2 | 0.0 | 0.0 |
| MOVE SPELL OUT OF RANGE | 2.1 | -41.3 | 27.6 | 0.0 | 0.8 | -22.5 | 0.0 | 0.0 |
| MOVE SPELL SPOT | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 3.0 | +250.9 | 0.0 | 43.9 | 3.4 | +374.5 | 0.0 | 26.4 |
| MOVES UNITS SPELL | 0.2 | +12.2 | 0.0 | 0.0 | 0.1 | +0.5 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 4.7 | +262.0 | 0.0 | 108.0 | 6.1 | +252.6 | 0.0 | 35.9 |
| NEEDED THERE | - | - | - | - | 0.1 | +0.4 | 13.3 | 0.0 |
| NEXT CHARGE BY LIST | 4.6 | -159.4 | 31.7 | 68.9 | 5.4 | -207.3 | 0.0 | 60.9 |
| NEXT OBJECTIVE NEARER | 6.0 | -244.9 | 67.4 | 142.3 | - | - | - | - |
| NO DOUBLE ROUNDS | 2.2 | -137.8 | 114.1 | 55.4 | 2.6 | -104.6 | 236.1 | 7.8 |
| NO RALLY LEFT | 0.1 | +5.8 | 0.0 | 21.0 | - | - | - | - |
| NOT WORTH A CAST | 0.4 | -0.8 | 0.0 | 0.0 | 0.1 | -0.1 | 0.0 | 0.0 |
| OFF BEST | 0.3 | -32.3 | 0.0 | 0.0 | 0.1 | -0.4 | 0.0 | 0.0 |
| ONE CHARGE A CHARGER | 2.3 | +0.0 | 0.0 | 104.2 | 2.8 | +0.0 | 0.0 | 56.2 |
| ONE FIGHT FORMULA | 4.4 | -71.2 | 0.0 | 78.3 | 5.1 | -102.7 | 0.0 | 86.1 |
| ONE OBJECTIVE FORMULA | 4.4 | +143.6 | 0.0 | 13.3 | 5.9 | -5.1 | 0.0 | 23.4 |
| ONE ROUTE | - | - | - | - | 0.9 | +0.0 | 0.0 | 0.0 |
| ONE TARGET A SHOOTER | 15.4 | +465.4 | 0.0 | 358.0 | 20.1 | +497.4 | 0.0 | 257.3 |
| OPENS A LANE | - | - | - | - | 0.1 | +0.5 | 5.8 | 0.0 |
| OPENS UP | - | - | - | - | 0.3 | +6.1 | 0.0 | 0.0 |
| OVERRUNS AWAY | 0.6 | +55.9 | 60.7 | 34.4 | 0.8 | +20.5 | 62.7 | 0.0 |
| PATHS CROSS | 2.8 | +122.0 | 0.0 | 0.0 | 3.8 | +135.9 | 0.0 | 19.8 |
| PERIAPT WORTH | - | - | - | - | 0.2 | +20.3 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.2 | -1.7 | 0.0 | 0.0 | - | - | - | - |
| PLAN RESULT | 38.8 | +730.2 | 549.4 | 801.1 | 43.8 | +541.1 | 111.2 | 923.6 |
| QUARTER ODDS | - | - | - | - | 8.3 | +986.4 | 155.1 | 92.6 |
| RANDOM MOVE BY FIGURES | 1.1 | +1.5 | 0.0 | 0.0 | 2.4 | +85.5 | 0.0 | 125.6 |
| REAL GROUND | - | - | - | - | 0.9 | +0.0 | 0.0 | 0.0 |
| REDIRECT BY WHAT IT STOPS | - | - | - | - | 0.3 | -11.8 | 0.0 | 0.0 |
| REDIRECT COUNTER | 1.8 | +131.5 | 0.0 | 38.1 | 1.4 | +40.4 | 0.0 | 22.8 |
| REDIRECT WEIGHED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| REFORMS TO MEET IT | 0.4 | -27.0 | 0.0 | 0.0 | 0.7 | -9.2 | 0.0 | 0.0 |
| REFUSING RETIRES | - | - | - | - | 0.4 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | 1.1 | +60.3 | 0.0 | 24.9 | 0.4 | +11.5 | 0.0 | 12.4 |
| RESTRAINS TO SHOOT | 0.1 | +3.0 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | 1.7 | -58.3 | 73.4 | 49.7 | 2.3 | -3.4 | 225.3 | 7.8 |
| RISK BY HIS FIGURE | 12.3 | -122.4 | 0.0 | 326.7 | 12.9 | -112.3 | 0.0 | 129.3 |
| RISK ON THE WAY | - | - | - | - | 0.9 | +0.0 | 0.0 | 0.0 |
| RUN DOWN | 1.4 | -24.5 | 25.2 | 11.6 | 1.7 | -13.8 | 161.1 | 7.8 |
| SCOUT SPOT | 0.2 | +2.7 | 0.0 | 0.0 | 0.2 | +0.5 | 0.0 | 0.0 |
| SCOUT WAITS | 0.2 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 0.2 | -9.2 | 0.0 | 6.7 |
| SEARCH SPOT | 6.1 | +165.4 | 0.0 | 80.0 | 5.4 | +182.1 | 0.0 | 67.4 |
| SELF MOVE SPELL | - | - | - | - | 0.3 | -0.7 | 0.0 | 0.0 |
| SET UP TOGETHER | 0.3 | +3.0 | 0.0 | 0.0 | 0.6 | +24.0 | 0.0 | 14.0 |
| SET-UP ANY TARGET | 0.4 | +61.0 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | 0.2 | +0.4 | 0.0 | 0.0 | 0.3 | +1.0 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 0.7 | +27.1 | 12.8 | 0.0 | 1.9 | +37.0 | 27.8 | 0.0 |
| SHORT GUN FORWARD | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| SHOT OR CHARGE | 0.4 | -5.5 | 34.4 | 9.4 | 0.4 | -3.9 | 0.0 | 11.1 |
| SHOT RISK POINTS | 11.0 | -74.8 | 0.0 | 110.3 | 10.8 | +12.4 | 0.0 | 257.2 |
| SHOTS IN THE MOVE | 13.2 | +447.7 | 0.0 | 348.0 | 16.4 | +276.1 | 0.0 | 182.4 |
| SPELL SETS UP CHARGE | 0.7 | +108.1 | 0.0 | 0.0 | - | - | - | - |
| SPELL WORTH | 0.9 | +7.0 | 0.0 | 0.0 | 1.8 | +20.9 | 64.4 | 64.4 |
| SPELLS IN THE FIGHT | 0.4 | +4.4 | 61.8 | 0.0 | 0.2 | +2.6 | 26.1 | 0.0 |
| STAND AND SHOOT | 0.2 | -4.3 | 34.4 | 34.4 | 0.2 | -1.7 | 34.4 | 0.0 |
| STANDS FOR A REASON | 0.1 | +0.0 | 0.0 | 0.0 | 1.4 | +0.0 | 9.4 | 0.0 |
| STANDS STILL | 16.8 | +0.0 | 714.7 | 239.0 | 16.8 | +0.0 | 85.1 | 180.0 |
| STAY WORTH | 17.4 | -19.2 | 371.3 | 287.6 | 15.1 | +31.0 | 29.7 | 184.6 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 46.7 |
| SUPPORT NARROWED | 1.0 | +0.0 | 12.8 | 15.2 | 1.2 | +0.0 | 99.9 | 7.8 |
| SURE REACH TOGETHER | 0.6 | +8.5 | 0.0 | 0.0 | 0.6 | +28.3 | 0.0 | 14.0 |
| THE DEARER SUM KEEPS ITS PLAN | 2.7 | +0.0 | 0.0 | 0.0 | 4.7 | +0.0 | 0.0 | 19.8 |
| THE PROMISE ADDS | 0.3 | -16.2 | 0.0 | 0.0 | 0.1 | -3.5 | 13.3 | 7.8 |
| THE PROMISED MOVE | 0.3 | +0.0 | 0.0 | 34.4 | 0.8 | +0.0 | 0.0 | 6.1 |
| TIED UP BY THE SUM | 0.4 | +36.3 | 13.4 | 0.0 | 0.4 | +47.7 | 32.2 | 0.0 |
| TIME ON OUR SIDE | 20.3 | +337.0 | 32.6 | 223.6 | 14.0 | +197.8 | 0.0 | 31.4 |
| WAITS AGAIN | 2.2 | +0.0 | 0.0 | 0.0 | 1.1 | +0.0 | 0.0 | 14.0 |
| WAR ENGINE CHARGES | 0.2 | +1.7 | 7.8 | 0.0 | 0.1 | +6.7 | 10.6 | 0.0 |
| WAR ENGINE JOBS | 0.8 | +0.0 | 18.9 | 0.0 | 0.8 | +0.0 | 16.3 | 0.0 |
| WHO HITS BACK | 0.1 | +121.2 | 0.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT | 0.2 | +0.5 | 0.0 | 9.4 | 0.1 | +11.8 | 0.0 | 0.0 |
| WHOLE FIGHT GAIN | 0.2 | +3.4 | 0.0 | 11.6 | 0.2 | +29.6 | 53.8 | 7.8 |
| WIDER SPREAD | 1.8 | -3.5 | 110.7 | 55.4 | 2.6 | -7.7 | 243.1 | 7.8 |
| WOUNDS ON THE RANKS | 2.4 | +124.3 | 0.0 | 0.0 | 0.7 | +24.9 | 0.0 | 18.6 |

### Rule changes: h9-opp-81fb82c-p1

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HOLDER ASSIGNMENT | 127 | 127 | 116 | 12.89 | +4502 | +38.8 |
| HIS SHOT LIST | 378 | 378 | 110 | 12.22 | +1719 | +15.6 |
| SEARCH SPOT | 104 | 104 | 98 | 10.89 | +3128 | +31.9 |
| DEPLOY BY FIGURES | 153 | 153 | 96 | 10.67 | +2172 | +22.6 |
| ONE TARGET A SHOOTER | 320 | 320 | 90 | 10.00 | +988 | +11.0 |
| LEGAL CHARGES ONLY | 66 | 66 | 66 | 7.33 | +0 | +0.0 |
| PATHS CROSS | 59 | 59 | 59 | 6.56 | +2321 | +39.3 |
| TIME ON OUR SIDE | 309 | 279 | 57 | 6.33 | +370 | +6.5 |
| FIVE ACTION | 843 | 843 | 46 | 5.11 | +1378 | +29.9 |
| MOVE TO CHARGE COMPUTED | 58 | 58 | 40 | 4.44 | +1922 | +48.0 |
| SHOT RISK POINTS | 196 | 196 | 37 | 4.11 | +1152 | +31.1 |
| ARTILLERY RE-ROLL WEIGHED | 35 | 35 | 35 | 3.89 | +0 | +0.0 |
| FOUR ROUNDS | 51 | 51 | 31 | 3.44 | +1965 | +63.4 |
| HARD STAY DROPPED | 24 | 24 | 24 | 2.67 | +0 | +0.0 |
| COVER ONCE | 120 | 96 | 23 | 2.56 | +248 | +10.8 |
| IDLE COST | 143 | 111 | 21 | 2.33 | +134 | +6.4 |
| RANDOM MOVE BY FIGURES | 32 | 32 | 19 | 2.11 | +783 | +41.2 |
| MISSILES IN THE MOVE | 77 | 61 | 17 | 1.89 | +416 | +24.4 |
| SHOTS IN THE MOVE | 267 | 232 | 17 | 1.89 | +764 | +45.0 |
| CANNON SIGHT KEPT | 16 | 16 | 16 | 1.78 | +0 | +0.0 |
| FALLS SHORT | 215 | 184 | 16 | 1.78 | +117 | +7.3 |
| SHOOTS FROM THE BEST SPOT | 23 | 23 | 16 | 1.78 | +145 | +9.0 |
| CANNON PLANNED TARGET | 81 | 81 | 14 | 1.56 | -208 | -14.8 |
| RESERVE FALL BACK | 14 | 14 | 14 | 1.56 | +646 | +46.2 |
| LONE WIZARD KEPT IN | 13 | 13 | 13 | 1.44 | +944 | +72.7 |
| ADVANCE LANE KEPT | 12 | 12 | 12 | 1.33 | +0 | +0.0 |
| MANOEUVRE | 23 | 23 | 12 | 1.33 | +115 | +9.6 |
| MAX FOR POSITIONING | 83 | 82 | 12 | 1.33 | +70 | +5.8 |
| NEXT OBJECTIVE NEARER | 54 | 54 | 12 | 1.33 | +165 | +13.7 |
| ONE OBJECTIVE FORMULA | 93 | 79 | 12 | 1.33 | +500 | +41.6 |
| LANE BY FIGURES | 11 | 11 | 11 | 1.22 | +326 | +29.6 |
| RISK BY ARC | 36 | 36 | 11 | 1.22 | +396 | +36.0 |
| CHARGE NOT DECLARED | 10 | 10 | 10 | 1.11 | -1048 | -104.8 |
| COMBAT PIVOT | 10 | 10 | 10 | 1.11 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 10 | 10 | 10 | 1.11 | +2868 | +286.8 |
| QUARTER ODDS | 75 | 75 | 10 | 1.11 | +1060 | +106.0 |
| CHARGE LOSSES | 118 | 118 | 9 | 1.00 | +479 | +53.2 |
| MARCH BY THE SUM | 8 | 8 | 8 | 0.89 | +234 | +29.3 |
| MODEL FACING | 8 | 8 | 8 | 0.89 | +1287 | +160.9 |
| NEARER NOT NEEDED | 97 | 91 | 8 | 0.89 | +300 | +37.5 |
| WOUNDS ON THE RANKS | 28 | 28 | 8 | 0.89 | +229 | +28.6 |
| CHARGE NOW FIRST | 27 | 27 | 7 | 0.78 | -827 | -118.1 |
| HOLDS AMBUSHERS | 7 | 7 | 7 | 0.78 | +0 | +0.0 |
| NEXT CHARGE BY LIST | 90 | 90 | 7 | 0.78 | +100 | +14.3 |
| RISK BY HIS FIGURE | 227 | 227 | 7 | 0.78 | +442 | +63.1 |
| CAST JOB | 19 | 19 | 6 | 0.67 | +4 | +0.7 |
| FEATURE BUFFS | 29 | 29 | 6 | 0.67 | +107 | +17.8 |
| HOLDER AT DEPLOYMENT | 10 | 10 | 6 | 0.67 | +279 | +46.6 |
| REDIRECT COUNTER | 29 | 24 | 6 | 0.67 | +484 | +80.6 |
| TIED UP BY THE SUM | 8 | 8 | 6 | 0.67 | +94 | +15.6 |
| MARCH CHECK | 11 | 11 | 5 | 0.56 | +73 | +14.5 |
| SHOOTERS IN TWO RANKS | 5 | 5 | 5 | 0.56 | +13 | +2.6 |
| SURE REACH TOGETHER | 10 | 9 | 5 | 0.56 | +29 | +5.7 |
| CHAFF PASSED | 4 | 4 | 4 | 0.44 | +0 | +0.0 |
| FIGHT TO THE END | 12 | 12 | 4 | 0.44 | +452 | +113.0 |
| HIS TURN DENIED | 19 | 19 | 4 | 0.44 | +76 | +18.9 |
| OFF BEST | 4 | 4 | 4 | 0.44 | -294 | -73.5 |
| SCOUT WAITS | 4 | 4 | 4 | 0.44 | +0 | +0.0 |
| STAY WORTH | 293 | 271 | 4 | 0.44 | +3 | +0.8 |
| CASTER AWAY FROM SCREEN | 3 | 3 | 3 | 0.33 | +0 | +0.0 |
| CASTING BLOCK | 3 | 3 | 3 | 0.33 | +348 | +115.9 |
| MOVES UNITS SPELL | 3 | 3 | 3 | 0.33 | +114 | +38.2 |
| OVERRUNS AWAY | 12 | 12 | 3 | 0.33 | +29 | +9.8 |
| REDIRECT WEIGHED | 3 | 3 | 3 | 0.33 | +131 | +43.7 |
| SET UP TOGETHER | 8 | 5 | 3 | 0.33 | +70 | +23.5 |
| SHORT GUN FORWARD | 3 | 3 | 3 | 0.33 | +0 | +0.0 |
| STUCK PIVOT | 3 | 3 | 3 | 0.33 | +0 | +0.0 |
| AFTERMATH IN POINTS | 2 | 2 | 2 | 0.22 | +494 | +246.9 |
| NO DOUBLE ROUNDS | 43 | 43 | 2 | 0.22 | +11 | +5.5 |
| PERIAPT WORTH | 2 | 2 | 2 | 0.22 | +183 | +91.3 |
| PIVOT GUARDS FLANK | 2 | 2 | 2 | 0.22 | -16 | -7.8 |
| WAR ENGINE JOBS | 14 | 14 | 2 | 0.22 | -126 | -63.0 |
| WIDER SPREAD | 39 | 39 | 2 | 0.22 | +8 | +3.8 |
| BACKUP TARGETS | 3 | 2 | 1 | 0.11 | +5 | +5.4 |
| CHAFF IN THE MOVE | 1 | 1 | 1 | 0.11 | +0 | +0.0 |
| FALL BACK GOOD ORDER | 36 | 36 | 1 | 0.11 | +12 | +11.8 |
| FRIEND CHARGES FIRST | 2 | 2 | 1 | 0.11 | +1 | +1.3 |
| FRIENDS SHOTS CHECKED | 1 | 1 | 1 | 0.11 | +43 | +43.3 |
| GUN MASK | 5 | 5 | 1 | 0.11 | +12 | +12.4 |
| HIS CHARGE DENIED | 5 | 5 | 1 | 0.11 | +10 | +9.6 |
| HONEST WORTH | 41 | 41 | 1 | 0.11 | +70 | +69.5 |
| HUNT IN PAIRS | 6 | 4 | 1 | 0.11 | +28 | +28.2 |
| KEEP FALLS | 1 | 1 | 1 | 0.11 | +61 | +60.8 |
| KEEPS SCOUTS OR AMBUSH | 1 | 1 | 1 | 0.11 | +0 | +0.0 |
| KILLS COUNT | 1 | 1 | 1 | 0.11 | +0 | +0.0 |
| LONG SHOT | 3 | 3 | 1 | 0.11 | +4 | +4.1 |
| MISSILES NEXT TURN | 94 | 69 | 1 | 0.11 | +0 | +0.0 |
| NEEDED THERE | 1 | 1 | 1 | 0.11 | +0 | +0.0 |
| NO RALLY LEFT | 1 | 1 | 1 | 0.11 | +41 | +40.6 |
| ONE FIGHT FORMULA | 86 | 43 | 1 | 0.11 | +2 | +1.8 |
| OPENS UP | 3 | 3 | 1 | 0.11 | +24 | +24.2 |
| REFUSING RETIRES | 4 | 4 | 1 | 0.11 | -0 | -0.1 |
| RESTRAINS TO SHOOT | 1 | 1 | 1 | 0.11 | +27 | +26.6 |
| SPELLS IN THE FIGHT | 6 | 6 | 1 | 0.11 | +9 | +9.2 |
| SUPPORT NARROWED | 20 | 20 | 1 | 0.11 | -14 | -14.0 |
| WAR ENGINE CHARGES | 3 | 3 | 1 | 0.11 | +13 | +13.5 |
| WHO HITS BACK | 1 | 1 | 1 | 0.11 | +732 | +731.8 |
| WHOLE FIGHT | 3 | 3 | 1 | 0.11 | +76 | +75.6 |
| WHOLE FIGHT GAIN | 4 | 4 | 1 | 0.11 | +3 | +3.3 |
| ALREADY CARRIED | 3 | not checked | - | - | - | - |
| BLOWS WHERE AIMED | 3 | 3 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 10 | 10 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 17 | trace | - | - | - | - |
| CHARACTER GUNS | 9 | 9 | 0 | 0.00 | - | - |
| CHARGER SLAIN LOST | 7 | 7 | 0 | 0.00 | - | - |
| CHEAP HELPER | 2 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 22 | not checked | - | - | - | - |
| EDGE GIVE GROUND | 1 | 1 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 6 | 6 | 0 | 0.00 | - | - |
| FALLBACK BY WORTH | 2 | 2 | 0 | 0.00 | - | - |
| FIGHT LIFT | 1 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 62 | not checked | - | - | - | - |
| FRIEND SHOOTS FIRST | 9 | 9 | 0 | 0.00 | - | - |
| GIVES UP | 2 | 2 | 0 | 0.00 | - | - |
| GROUND FLIERS | 2 | not checked | - | - | - | - |
| GUN FIGURES | 40 | not checked | - | - | - | - |
| HE SHOOTS OR CHARGES | 48 | 48 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 32 | 32 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 57 | 57 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 29 | 29 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 10 | 10 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 45 | 45 | 0 | 0.00 | - | - |
| HOLD ODDS | 112 | 112 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 3 | 3 | 0 | 0.00 | - | - |
| LOST CHARGE | 2 | 2 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 2 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 4 | trace | - | - | - | - |
| MARCH OVER CASTS | 14 | 14 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 8 | 8 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 5 | 3 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 26 | trace | - | - | - | - |
| MOVE SPELL SPOT | 9 | not checked | - | - | - | - |
| NOT WORTH A CAST | 5 | not checked | - | - | - | - |
| ONE CHARGE A CHARGER | 46 | 46 | 0 | 0.00 | - | - |
| ONE ROUTE | 8 | 8 | 0 | 0.00 | - | - |
| OPENS A LANE | 1 | 1 | 0 | 0.00 | - | - |
| PLAN RESULT | 743 | trace | - | - | - | - |
| REAL GROUND | 8 | 8 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 3 | 3 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 10 | 10 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 8 | 8 | 0 | 0.00 | - | - |
| RUN DOWN | 28 | 28 | 0 | 0.00 | - | - |
| SCOUT SPOT | 4 | 4 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 2 | 2 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 3 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 4 | not checked | - | - | - | - |
| SHOT OR CHARGE | 8 | 8 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 6 | not checked | - | - | - | - |
| SPELL WORTH | 24 | not checked | - | - | - | - |
| STAND AND SHOOT | 4 | 4 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 14 | 14 | 0 | 0.00 | - | - |
| STANDS STILL | 302 | 302 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 66 | not checked | - | - | - | - |
| THE PROMISE ADDS | 4 | 4 | 0 | 0.00 | - | - |
| THE PROMISED MOVE | 10 | not checked | - | - | - | - |
| WAITS AGAIN | 30 | 30 | 0 | 0.00 | - | - |

### Off best figure: h9-opp-81fb82c-p1

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| HOLDER ASSIGNMENT | rule | - | 1.56 | 31.0 |
| CHARGE NOT DECLARED | rule | 0.67 | 0.22 | 131.1 |
| CHARGE NOW FIRST | rule | 0.33 | 0.44 | 118.1 |
| CANNON PLANNED TARGET | rule | 0.22 | 0.11 | 69.3 |
| PATHS CROSS | rule | 0.33 | - | 16.4 |
| AFTERMATH BAND | gate | 0.11 | 0.11 | 3.5 |
| PIVOT GUARDS FLANK | rule | 0.22 | - | 7.8 |
| WAR ENGINE JOBS | rule | 0.11 | 0.11 | 63.0 |
| JOB FIRST | gate | 0.11 | - | 12.7 |
| RULE SWITCHED OFF | gate | 0.11 | - | 274.4 |
| SUPPORT NARROWED | rule | 0.11 | - | 14.0 |

### Plans: h9-opp-81fb82c-p1

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.8 | 69% | 269 | 155 | 58% |
| Mine | join | 0.2 | 100% | 8 | 0 | 0% |
| Mine | move | 28.3 | 93% | 1691 | 0 | 0% |
| Mine | shoot | 8.4 | 66% | 353 | 575 | 163% |
| Opponent | charge | 2.7 | 75% | 401 | 279 | 70% |
| Opponent | move | 31.8 | 93% | 1487 | 0 | 0% |
| Opponent | shoot | 8.9 | 46% | 258 | 262 | 102% |
| Opponent | support | 0.4 | 100% | 0 | 0 | - |

### Battle groups: h9-opp-81fb82c-p1

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 1.8 | 31% | 60% | 40% | 50% | 0% | 33% | 0% | 33% | 33% |
| Opponent | REDIRECT COUNTER | 1.4 | 31% | 100% | 0% | - | 25% | 0% | 0% | 75% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: h9-opp-81fb82c-p1

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 8 | 52 (8) | 0 | 52 | 55 | 62% | 2.0 | 80 (1) | 50 (6) | 0 (1) | 63 (6) | 0 (2) |
| Mine | Character | 34 | 25 (34) | 25 | 0 | 13 | 9% | 2.5 | 87 (2) | 14 (20) | 24 (11) | 12 (19) | 41 (14) |
| Mine | Clean-up | 7 | 72 (7) | 0 | 72 | 64 | 71% | 4.5 | 0 (1) | 100 (4) | 0 (2) | 120 (4) | 30 (3) |
| Mine | Fast Hammer | 7 | 18 (7) | 18 | 0 | 55 | 14% | 4.0 | - | 6 (3) | 24 (4) | 0 (2) | 28 (5) |
| Mine | Hammer | 21 | 42 (21) | 17 | 25 | 17 | 14% | 3.1 | 41 (3) | 46 (9) | 39 (9) | 31 (12) | 60 (9) |
| Mine | Holder | 11 | 39 (11) | 0 | 39 | 24 | 64% | 4.0 | 0 (1) | 36 (8) | 81 (2) | 22 (6) | 57 (5) |
| Mine | Shooter | 2 | 300 (2) | 0 | 300 | 0 | 0% | 1.0 | 46 (1) | 554 (1) | - | 300 (2) | - |
| Mine | War machine | 13 | 55 (13) | 55 | 0 | 51 | 0% | 1.3 | 25 (4) | 96 (5) | 53 (4) | 90 (3) | 46 (10) |
| Mine | Wizard | 7 | 7 (7) | 7 | 0 | 18 | 29% | 1.8 | 26 (2) | 0 (1) | 0 (3) | 0 (3) | 18 (3) |
| Opponent | Chaff | 10 | 38 (10) | 0 | 38 | 82 | 30% | 3.1 | 27 (4) | 0 (1) | 59 (5) | 25 (5) | 51 (5) |
| Opponent | Character | 23 | 50 (23) | 50 | 0 | 23 | 26% | 2.8 | 51 (4) | 65 (10) | 31 (6) | 82 (11) | 10 (9) |
| Opponent | Clean-up | 10 | 59 (10) | 18 | 41 | 26 | 60% | 5.2 | 46 (4) | 69 (5) | 62 (1) | 85 (8) | 0 (2) |
| Opponent | Fast | 1 | 0 (1) | 0 | 0 | 0 | 0% | 1.0 | - | 0 (1) | - | 0 (1) | - |
| Opponent | Fast Hammer | 5 | 9 (5) | 0 | 9 | 87 | 0% | 2.0 | - | 18 (2) | 0 (3) | 54 (1) | 0 (4) |
| Opponent | Fragile | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | - | 0 (1) | 0 (1) | - |
| Opponent | Hammer | 17 | 16 (17) | 7 | 10 | 31 | 24% | 3.0 | 13 (3) | 16 (12) | 22 (2) | 3 (7) | 27 (10) |
| Opponent | Holder | 14 | 149 (14) | 13 | 135 | 8 | 50% | 3.9 | 177 (4) | 122 (8) | 179 (2) | 167 (7) | 122 (7) |
| Opponent | Shooter | 11 | 29 (11) | 0 | 29 | 19 | 0% | 2.3 | 0 (3) | 53 (5) | 0 (3) | 46 (6) | 0 (5) |
| Opponent | War machine | 12 | 4 (12) | 4 | 0 | 54 | 17% | 1.6 | 0 (3) | 0 (3) | 7 (6) | 0 (2) | 5 (10) |
| Opponent | Wizard | 5 | 33 (5) | 33 | 0 | 62 | 0% | 2.4 | 86 (2) | 0 (1) | - | 123 (1) | 0 (2) |

### Charged fights: h9-opp-81fb82c-p1

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 25 | 68 | 1.8 | 1.4 | 39 | 32 | +7 | 2 of 7 | 6 of 7 | -68 | +37 |
| Mine | Chaos Dwarfs | 4 | 408 | 204 | 2.8 | 1.0 | 74 | 28 | +46 | 5 of 11 | 10 of 11 | - | +46 |
| Mine | Dwarfen Mountain Holds | 1 | 785 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| **Mine** | all armies | 9 | 280 | 121 | 2.0 | 1.2 | 60 | 30 | +31 | 7 of 18 | 16 of 18 | -68 | +43 |
| Opponent | Chaos Dwarfs | 3 | 62 | 356 | 2.3 | 1.1 | 153 | 44 | +108 | 6 of 7 | 6 of 7 | +364 | +66 |
| Opponent | Dwarfen Mountain Holds | 1 | 0 | 0 | 3.0 | 1.3 | 0 | 0 | +0 | 2 of 3 | 2 of 3 | +0 | +0 |
| Opponent | Grand Cathay | 1 | 138 | 592 | 5.0 | 1.4 | 118 | 0 | +118 | 0 of 5 | 4 of 5 | +95 | +124 |
| Opponent | Orc & Goblin Tribes | 1 | 0 | 52 | 1.0 | 1.0 | 52 | 0 | +52 | 0 of 1 | 1 of 1 | - | +52 |
| Opponent | Skaven | 2 | 0 | 0 | 0.5 | 1.0 | 0 | 0 | +0 | 1 of 1 | 0 of 1 | - | +0 |
| Opponent | Tomb Kings of Khemri | 1 | 0 | 837 | 5.0 | 1.2 | 167 | 0 | +167 | 1 of 5 | 5 of 5 | +459 | +94 |
| **Opponent** | all armies | 9 | 36 | 283 | 2.4 | 1.2 | 116 | 14 | +102 | 10 of 22 | 18 of 22 | +230 | +73 |

### Effective charges: h9-opp-81fb82c-p1

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 7 | 0 | 0 | 1 (net -52) | 1 (net +271) | 0 | 4 (net -21) | 1 | 17% (1 of 6) |
| Mine | Chaos Dwarfs | 11 | 0 | 0 | 3 (net +43) | 4 (net +78) | 2 (net +33) | 2 (net +0) | 0 | 27% (3 of 11) |
| Opponent | Chaos Dwarfs | 7 | 2 (net +167) | 0 | 2 (net -85) | 1 (net +0) | 0 | 2 (net +297) | 0 | 29% (2 of 7) |
| Opponent | Dwarfen Mountain Holds | 3 | 0 | 0 | 2 (net +0) | 0 | 0 | 1 (net +0) | 0 | 67% (2 of 3) |
| Opponent | Grand Cathay | 5 | 0 | 0 | 1 (net +190) | 4 (net +100) | 0 | 0 | 0 | 20% (1 of 5) |
| Opponent | Skaven | 1 | 0 | 0 | 0 | 1 (net +0) | 0 | 0 | 0 | 0% (0 of 1) |
| Opponent | Tomb Kings of Khemri | 5 | 0 | 0 | 1 (net +65) | 0 | 3 (net +257) | 1 (net +0) | 0 | 20% (1 of 5) |

### Charged fights, damage counted: h9-opp-81fb82c-p1

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Effective (55-75%) | 4 | 273 | 266 | +19 | 93 | 17 | +76 | +27.9 |
| Mine | 76-89% | 5 | 367 | 124 | +116 | 178 | 62 | +116 | +31.7 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 6 | 214 | 182 | -14 | 101 | 19 | +82 | +38.5 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 2 | 395 | 79 | +33 | 44 | 0 | +44 | +11.3 |
| Mine | No odds | 1 | 85 | 120 | -85 | 9 | 85 | -76 | -89.5 |
| Mine | All fights | 18 | 282 | 170 | +31 | 109 | 32 | +77 | +27.4 |
| Opponent | Long shot (under 50%) | 2 | 410 | 293 | +167 | 181 | 137 | +43 | +10.6 |
| Opponent | Effective (55-75%) | 6 | 175 | 181 | +14 | 66 | 66 | -0 | -0.3 |
| Opponent | 76-89% | 6 | 374 | 149 | +67 | 87 | 16 | +71 | +18.9 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 4 | 460 | 298 | +148 | 148 | 0 | +148 | +32.3 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 3 | 460 | 128 | +257 | 257 | 0 | +257 | +55.9 |
| Opponent | No odds | 1 | 350 | 52 | +52 | 52 | 0 | +52 | +14.9 |
| Opponent | All fights | 22 | 349 | 191 | +102 | 123 | 35 | +88 | +25.1 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| h9-opp-81fb82c-p1 | move | 64 | 14 (22%) | 8 (12%) | 16 (25%) | 34 (53%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0103, L0120 |
| Elixir of Power | Opponent | L0219 |
| Periapt of Soul Exchange | Opponent | L0120, L0321 |
| Ring of Doom | Mine | L0204, L0219 |
| Ring of Jet | Opponent | L0510 |
| Storm Daemon (Renegade 2.0) | Opponent | L0321 |
| Twice-Blessed Armour | Opponent | L0510 |

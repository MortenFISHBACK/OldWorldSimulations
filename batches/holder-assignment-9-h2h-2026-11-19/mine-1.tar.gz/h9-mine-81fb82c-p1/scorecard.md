# Doctrine scorecard: h9-mine-81fb82c-p1

### Scorecard: h9-mine-81fb82c-p1

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0103 | 1 | 1 | Mine | no | 4 | - | 0 | 2 | 0 | 0 | 0 | 0 |
| L0103 | 1 | 1 | Opponent | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 590 |
| L0120 | 6 | 1 | Mine | no | 6 | - | 0 | 3 | 0 | 0 | 0 | 0 |
| L0120 | 6 | 1 | Opponent | no | 1 | - | 0 | 4 | 0 | 0 | 0 | 210 |
| L0204 | 6 | 1 | Mine | no | 0 | 5 | 1 | 4 | 1 | 0 | 0 | 170 |
| L0204 | 6 | 1 | Opponent | no | 4 | 2 | 2 | 0 | 0 | 0 | 0 | 0 |
| L0219 | 3 | 1 | Mine | no | 8 | 2 | 4 | 0 | 1 | 0 | 0 | 255 |
| L0219 | 3 | 1 | Opponent | yes | 4 | 2 | 0 | 0 | 0 | 0 | 0 | 0 |
| L0304 | 4 | 1 | Mine | no | 0 | 5 | 1 | 1 | 0 | 0 | 0 | 649 |
| L0304 | 4 | 1 | Opponent | no | 7 | 3 | 2 | 3 | 0 | 0 | 0 | 310 |
| L0321 | 3 | 1 | Mine | no | 2 | 6 | 1 | 0 | 0 | 0 | 0 | 140 |
| L0321 | 3 | 1 | Opponent | no | 4 | 6 | 1 | 5 | 1 | 0 | 0 | 420 |
| L0406 | 4 | 1 | Mine | no | 0 | 3 | 4 | 1 | 0 | 0 | 0 | 0 |
| L0406 | 4 | 1 | Opponent | no | 0 | - | 1 | 0 | 0 | 0 | 0 | 1395 |
| L0423 | 3 | 1 | Mine | no | 3 | 2 | 5 | 1 | 0 | 0 | 0 | 0 |
| L0423 | 3 | 1 | Opponent | no | 0 | 2 | 3 | 1 | 0 | 0 | 0 | 66 |
| L0510 | 6 | 1 | Mine | no | 3 | - | 1 | 0 | 0 | 0 | 0 | 669 |
| L0510 | 6 | 1 | Opponent | no | 4 | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| L0525 | 3 | 1 | Mine | no | 3 | - | 0 | 2 | 0 | 0 | 0 | 276 |
| L0525 | 3 | 1 | Opponent | no | 3 | 3 | 1 | 4 | 0 | 0 | 0 | 85 |
| L0613 | 1 | 1 | Mine | no | 0 | - | 0 | 3 | 1 | 0 | 0 | 641 |
| L0613 | 1 | 1 | Opponent | yes | 2 | 3 | 1 | 2 | 1 | 0 | 0 | 0 |
| **Average** | | | Mine | 0% | 2.6 | 3.8 | 1.5 | 1.5 | 0.3 | 0.0 | 0.0 | 254.5 |
| **Average** | | | Opponent | 18% | 2.6 | 2.9 | 1.2 | 1.9 | 0.2 | 0.0 | 0.0 | 279.6 |

### KPIs: h9-mine-81fb82c-p1

Rules off - Opponent only: HOLDER ASSIGNMENT, QUARTER ODDS, WALK PROMISE, REAL GROUND, RISK ON THE WAY, ONE ROUTE, MARCH WHEELS ONLY, LATE ONLY FROM HERE, WALKS ON ITS ROUTE.

Morten 2026-11-10; 11 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 45% (18 of 40) | 13% (6 of 46) | 28% (24 of 86) |
| Winner chose to follow up after the loser gave ground |  | 60% (3 of 5); on the table 60% | 100% (17 of 17); on the table 100% | 91% (20 of 22); on the table 91% |
| Winner chose to pursue after the loser fell back in good order |  | - | 100% (2 of 2); on the table 100% | 100% (2 of 2); on the table 100% |
| Winner chose to pursue after the loser fled |  | 50% (1 of 2); on the table 50% | 100% (4 of 4); on the table 100% | 83% (5 of 6); on the table 83% |
| Winner chose to follow up or pursue (all three) |  | 57% (4 of 7); on the table 57% | 100% (23 of 23); on the table 100% | 90% (27 of 30); on the table 90% |
| Magic missiles tried each own turn | 50%+ | 41% (56 of 138) | 31% (26 of 84) | 37% (82 of 222) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 43% (56 of 131) | 43% (26 of 60) | 43% (82 of 191) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 43% (3 of 7) | 79% (15 of 19) | 69% (18 of 26) |
| Points that never fought | lower | 61% (12702 of 20788) | 67% (14738 of 21993) | 64% (27440 of 42781) |
|   infantry points that never fought | lower | 75% (4690 of 6294) | 79% (4136 of 5252) | 76% (8826 of 11546) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 51% (39 of 76) | 55% (48 of 87) | 53% (87 of 163) |
| Bound items with a magic missile used (at least once a game) |  | 100% (6 of 6); 1.9 uses a game | 75% (3 of 4); 0.9 uses a game | 90% (9 of 10); 1.4 uses a game |
| Bound items with another spell used |  | 100% (2 of 2); 0.6 uses a game | 33% (1 of 3); 0.2 uses a game | 60% (3 of 5); 0.4 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 75% (6 of 8); 0.5 uses a game | 60% (3 of 5); 0.3 uses a game | 69% (9 of 13); 0.4 uses a game |
|   their share of the points of units over 100 pts | lower | 48% (7530 of 15642) | 54% (10209 of 19016) | 51% (17739 of 34658) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 5.2 (70%) | 1.2 (22%) | 6.4 (50%) |
| MARCHED: its unit marched | 1.3 (17%) | 1.5 (28%) | 2.7 (21%) |
| CHARGED: its unit charged | 0.1 (1%) | 0.5 (9%) | 0.5 (4%) |
| IN COMBAT: engaged in combat | 0.3 (4%) | 1.1 (21%) | 1.4 (11%) |
| GONE: slain | 0.4 (5%) | 1.1 (21%) | 1.5 (11%) |
| STUPIDITY: Stupidity | 0.3 (4%) | 0.0 (0%) | 0.3 (2%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 5.4 | 0.3 | 3.1 | 7.5 | 0.5 | 0.5 |
| not cast | 2.3 | 1.4 | 4.5 | 12.7 | 2.7 | 20.3 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.9 (4%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.7 (53%) | 1.1 (24%) | 6.4 (50%) | 0.3 (10%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.7 (21%) | 0.5 (17%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.5 (4%) | 0.1 (3%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.3 (20%) | 0.3 (6%) | 1.4 (11%) | 0.5 (17%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.5 (20%) | 0.0 (0%) |
| NO CASTS LEFT: every cast used on other spells | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (3%) | 0.0 (0%) |
| GONE: slain | 0.4 (16%) | 0.3 (20%) | 0.3 (6%) | 1.5 (11%) | 0.3 (10%) | 1.2 (6%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.5 (3%) |
| STUPIDITY: Stupidity | 0.1 (4%) | 0.0 (0%) | 0.1 (2%) | 0.3 (2%) | 0.0 (0%) | 0.1 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.5 (20%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.8 (80%) | 0.1 (7%) | 2.8 (62%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 17.5 (87%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 2.5 a game | 1.2 a game | 1.9 a game |
| stood (cast and not dispelled) | 54% (15 of 28) | 38% (5 of 13) | 49% (20 of 41) |
| the unit moved after it | 53% (8 of 15) | 100% (5 of 5) | 65% (13 of 20) |
| it charged on its next turn | 0% (0 of 15) | 0% (0 of 5) | 0% (0 of 20) |
| the enemy charged it first | 0% (0 of 15) | 0% (0 of 5) | 0% (0 of 20) |
| it fought by the end of its next turn | 0% (0 of 15) | 0% (0 of 5) | 0% (0 of 20) |
| it moved out of a charge the enemy had planned (not charged first) | 7% (1 of 15) | 0% (0 of 5) | 5% (1 of 20) |
| none of these (no charge, no fight, no charge escaped) | 93% (14 of 15) | 100% (5 of 5) | 95% (19 of 20) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 67% (191 of 283) | 64% (166 of 258) | 66% (357 of 541) |
|   cavalry | 47% (8 of 17) | 71% (17 of 24) | 61% (25 of 41) |
|   character | 86% (24 of 28) | 30% (6 of 20) | 62% (30 of 48) |
|   chariot | 29% (10 of 34) | 48% (25 of 52) | 41% (35 of 86) |
|   infantry | 61% (43 of 71) | 72% (55 of 76) | 67% (98 of 147) |
|   monster | 67% (2 of 3) | 67% (4 of 6) | 67% (6 of 9) |
|   war machine | 80% (104 of 130) | 74% (59 of 80) | 78% (163 of 210) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.4 (28%) | 1.2 (14%) | 3.5 (21%) |
| CHARGED: it charged | 0.2 (2%) | 0.7 (9%) | 0.9 (5%) |
| FLEEING: it fled or was fleeing | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| IN COMBAT: it fought this turn or the last | 0.8 (10%) | 0.5 (7%) | 1.4 (8%) |
| MOVED: a war machine that moved | 1.6 (20%) | 1.0 (12%) | 2.6 (16%) |
| NO TARGET IN RANGE | 1.7 (21%) | 2.7 (33%) | 4.5 (27%) |
| ONLY IN COMBAT: the only targets were in combat | 0.1 (1%) | 0.2 (2%) | 0.3 (2%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.3 (15%) | 1.4 (16%) | 2.6 (16%) |
| SHELTERED: the target was sheltered | 0.0 (0%) | 0.1 (1%) | 0.1 (1%) |
| OTHER BAR | 0.2 (2%) | 0.5 (7%) | 0.7 (4%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 2.4 | 0.6 | 77% | 5.7 pts | 13 pts |
| character | 2.8 | 1.9 | 61% | 19.4 pts | 55 pts |
| chariot | 3.3 | 4.5 | 42% | 25.2 pts | 82 pts |
| infantry | 13.9 | 4.3 | 78% | 7.9 pts | 110 pts |
| monster | 0.5 | 0.0 | 100% | 0.0 pts | 0 pts |
| war machine | 14.8 | 16.3 | 68% | 37.3 pts | 552 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 1.9 | 3.2 | 2.5 |
| Charges that made contact a game | 1.4 | 2.2 | 1.8 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.50 declared, 0.33 contact (6 units) | 0.64 declared, 0.36 contact (11 units) | 0.59 declared, 0.35 contact (17 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 2.00 declared, 2.00 contact (1 units) | 2.00 declared, 2.00 contact (1 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.26 declared, 0.19 contact (70 units) | 0.30 declared, 0.21 contact (87 units) | 0.28 declared, 0.20 contact (157 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 25% (2 of 8) | 33% (1 of 3) | - | 27% (3 of 11) |
| Character in a unit | 78% (14 of 18) | 60% (6 of 10) | - | 71% (20 of 28) |
| Character on its own | 89% (8 of 9) | 60% (6 of 10) | 42% (5 of 12) | 61% (19 of 31) |
| Chariot | 33% (1 of 3) | 67% (8 of 12) | - | 60% (9 of 15) |
| Infantry | 29% (8 of 28) | 35% (6 of 17) | - | 31% (14 of 45) |
| Monster | 67% (4 of 6) | 100% (3 of 3) | - | 78% (7 of 9) |
| Monstrous | - | 0% (0 of 2) | - | 0% (0 of 2) |
| War Machines | 63% (12 of 19) | 100% (3 of 3) | - | 68% (15 of 22) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 100% (1 of 1); on the table 100% | 50% (51 of 102) | 72% | 64% (14 of 22) | 100% (6 of 6); 5.2 uses a game | 100% (2 of 2); 1.8 uses a game | 83% (5 of 6); 1.2 uses a game |
| Chaos Dwarfs | 7 | 75% (6 of 8); on the table 75% | 23% (14 of 60) | 56% | 46% (25 of 54) | 0.0 uses a game | 0.0 uses a game | 33% (1 of 3); 0.1 uses a game |
| Dwarfen Mountain Holds | 4 | 75% (3 of 4); on the table 75% | - | 63% | 59% (20 of 34) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Grand Cathay | 1 | 100% (6 of 6); on the table 100% | 13% (4 of 30) | 73% | 60% (6 of 10) | 50% (1 of 2); 1.0 uses a game | 0% (0 of 1); 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| High Elf Realms | 1 | - | 0% (0 of 6) | 92% | 75% (6 of 8) | 100% (1 of 1); 5.0 uses a game | 50% (1 of 2); 2.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 1 | 100% (3 of 3); on the table 100% | 33% (2 of 6) | 27% | 12% (1 of 8) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Skaven | 2 | - | 58% (7 of 12) | 90% | 56% (9 of 16) | 100% (1 of 1); 2.0 uses a game | 0.0 uses a game | 100% (2 of 2); 1.0 uses a game |
| Tomb Kings of Khemri | 1 | 100% (7 of 7); on the table 100% | - | 42% | 40% (2 of 5) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 1 | 100% (1 of 1); on the table 100% | 67% (4 of 6) | 63% | 67% (4 of 6) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (h9-mine-81fb82c-p1, 11 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 67% (14) | 33% (3) | 57% (17) |
| ...free all their last turn and able to turn (per game) | 1.00 | 0.09 | 1.09 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.27 | 0.09 | 0.36 |
| ...with the charger already in that arc before they moved (per game) | 0.73 | 0.09 | 0.82 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.09 | 0.09 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.18 | 0.18 | 0.36 |

### Quality by phase: h9-mine-81fb82c-p1

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.5 | 2.1 |
| Strategy | Charge objectives carried out (made contact) | 52% (11 of 21) | 53% (16 of 30) |
| Strategy | Shoot objectives carried out (shot that target) | 36% (62 of 174) | 60% (69 of 115) |
| Strategy | Support requests answered (helper made contact too) | 100% (1 of 1) | 50% (1 of 2) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | - | 100% (4 of 4) |
| Strategy | Hexes on a unit its side charged or shot that turn | - | 100% (1 of 1) |
| Strategy | Joined characters whose unit fought | 18% (6 of 33) | 56% (5 of 9) |
| Strategy | Lone characters that fought | 61% (11 of 18) | 44% (12 of 27) |
| Movement | Charges halted short of contact | 0.2 | 0.0 |
| Movement | Idle units | 1.5 | 1.9 |
| Movement | Points that never moved of their own | 254.5 | 279.6 |
| Movement | Fights charged into per game | 1.3 | 2.2 |
| Movement | Charges with odds: long shots (under 50%) | 4 of 14, net -58 | 6 of 21, net +88 |
| Movement | Charges with odds: sweet spot (55-75%) | 2 of 14, net +64 | 3 of 21, net +135 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 4 of 14, net +88 | 4 of 21, net +147 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 of 14, net -13 | 6 of 21, net +149 |
| Shooting | Shots by shooting units (incl. breath weapons) | 7.9 | 10.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 48% (42 of 87) | 39% (44 of 113) |
| Shooting | Points destroyed by shooting units | 80.4 | 78.3 |
| Shooting | War machine shots | 9.5 | 5.4 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 46% (48 of 104) | 73% (43 of 59) |
| Shooting | Points destroyed by war machines | 177.9 | 8.6 |
| Magic | Magic missiles cast | 3.3 | 1.6 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 36% (13 of 36) | 44% (8 of 18) |
| Magic | Wounds caused by magic missiles | 7.9 | 2.8 |
| Magic | Points destroyed by magic (all spells) | 109.4 | 7.7 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.8 / 0.0 / 0.1 / 0.4 | 3.0 / 0.1 / 0.1 / 0.1 |
| Combat | Points destroyed in combat | 77.3 | 269.6 |
| Combat | Points run down | 0.0 | 11.0 |
| Combat | Net points per charged fight, damage counted | +33 | +103 |
| Combat | Net per 100 charger points, damage counted | +14.5 | +34.8 |
| Combat | First round won (charged fights) | 57% | 83% |
| Combat | Net points per charged fight | +31 | +109 |
| Combat | Net points per supported fight / lone fight | +65 / +28 | - / +109 |
| Combat | Charged fights on a top-3 enemy unit | 6 of 14 | 11 of 24 |
| Game | Points lost | 430.5 | 536.5 |
| Game | VP from objectives | 687.3 | 845.5 |
| Game | Lone holders (player turns) | 2.6 | 2.6 |

- Mine won / drew / lost: 3 / 3 / 5 of 11 ended games (of 11); mean margin (Mine - Opponent) -65 VP
- The side that went first won 1 of 8 games with a winner
- Points traded per game (both sides' losses): 967
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: h9-mine-81fb82c-p1

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.9 | +0.0 | 0.0 | 0.0 | 1.2 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.2 | +2.0 | 0.0 | 12.6 | 0.1 | +1.0 | 0.0 | 0.0 |
| ALREADY CARRIED | 0.5 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARTILLERY RE-ROLL WEIGHED | 2.9 | +0.0 | 0.0 | 60.0 | 1.0 | +0.0 | 0.0 | 12.7 |
| BACKUP TARGETS | 0.2 | +0.2 | 0.0 | 30.8 | 0.2 | +0.5 | 0.0 | 0.0 |
| BEST PRIZE | 0.1 | -0.9 | 0.0 | 0.0 | 0.2 | -0.0 | 0.0 | 0.0 |
| BLOWS WHERE AIMED | 0.2 | -15.3 | 0.0 | 0.0 | 0.1 | -46.6 | 0.0 | 0.0 |
| CANNON PLAN MISSED | 0.8 | +0.0 | 176.3 | 0.0 | 0.5 | +0.0 | 25.3 | 0.0 |
| CANNON PLANNED TARGET | 9.6 | +108.4 | 1229.7 | 98.2 | 4.9 | +91.6 | 242.5 | 12.7 |
| CANNON SIGHT KEPT | 0.8 | +0.0 | 0.0 | 0.0 | 0.5 | +0.0 | 0.0 | 0.0 |
| CAST JOB | 0.3 | +3.1 | 20.2 | 15.5 | 0.4 | +7.4 | 0.0 | 7.7 |
| CASTER AWAY FROM SCREEN | 0.5 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.5 | +27.0 | 5.9 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | 1.3 | +0.0 | 0.0 | 0.0 | 0.5 | +0.0 | 0.0 | 36.4 |
| CASTS FROM BEHIND | - | - | - | - | 0.2 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | 0.3 | +36.2 | 0.0 | 15.5 | 0.4 | +25.2 | 0.0 | 0.0 |
| CHAFF PASSED | 0.1 | -0.4 | 0.0 | 0.0 | - | - | - | - |
| CHARACTER GUNS | 0.5 | +0.0 | 0.0 | 0.0 | 0.9 | +0.0 | 0.0 | 20.2 |
| CHARGE LOSSES | 4.7 | -145.2 | 0.0 | 97.5 | 7.5 | -323.5 | 0.0 | 297.0 |
| CHARGE NOT DECLARED | 0.4 | +0.0 | 22.7 | 0.0 | 0.5 | +0.0 | 41.5 | 0.0 |
| CHARGE NOW FIRST | 1.0 | +0.0 | 30.6 | 53.3 | 1.5 | +0.0 | 122.4 | 13.7 |
| CHARGER SLAIN LOST | 0.5 | -7.3 | 10.9 | 4.7 | 0.2 | -2.5 | 12.6 | 0.0 |
| CHEAP HELPER | - | - | - | - | 0.1 | +0.0 | 10.2 | 0.0 |
| COMBAT PIVOT | 0.8 | +0.0 | 0.0 | 100.0 | 0.1 | +0.0 | 0.0 | 19.1 |
| CONVEYANCE SEARCH | 1.3 | +185.3 | 0.0 | 0.0 | 0.5 | +57.0 | 36.4 | 36.4 |
| COVER ONCE | 5.8 | -372.8 | 0.0 | 97.1 | 6.2 | -309.6 | 0.0 | 79.1 |
| DEPLOY BY FIGURES | 9.0 | +33.3 | 0.0 | 0.0 | 8.5 | +22.2 | 0.0 | 5.0 |
| EDGE GIVE GROUND | 0.3 | +2.2 | 22.6 | 30.8 | 0.2 | +1.6 | 17.9 | 0.0 |
| ELIXIR WORTH | - | - | - | - | 0.1 | +3.1 | 0.0 | 0.0 |
| ENGINEER BY LORE | 0.4 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| FALL BACK GOOD ORDER | 1.3 | +0.1 | 63.1 | 48.5 | 1.8 | +0.0 | 103.4 | 13.7 |
| FALLS SHORT | 6.5 | +127.6 | 0.0 | 29.6 | 17.5 | +223.2 | 0.0 | 255.7 |
| FEATURE BUFFS | 1.7 | +66.1 | 0.0 | 0.0 | 0.4 | +5.6 | 0.0 | 0.0 |
| FIGHT LIFT | - | - | - | - | 0.2 | +1.0 | 0.0 | 0.0 |
| FIGHT TO THE END | 0.4 | +3.8 | 5.9 | 4.7 | 0.9 | +77.6 | 53.6 | 13.7 |
| FIRE IN ORDER | 0.2 | +0.0 | 40.2 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| FIVE ACTION | 47.1 | +2809.3 | 1874.1 | 571.5 | 51.1 | +2495.0 | 583.4 | 668.6 |
| FLANK NOT WEIGHED | 4.5 | +0.0 | 0.0 | 51.2 | 4.1 | +0.0 | 0.0 | 57.9 |
| FOLLOW UP WEIGHED | 0.2 | +13.3 | 0.0 | 0.0 | 1.1 | +408.4 | 0.0 | 0.0 |
| FOUR ROUNDS | 1.9 | +120.2 | 94.5 | 58.0 | 2.7 | +247.9 | 164.4 | 53.9 |
| FRIEND CHARGES FIRST | 0.2 | -10.1 | 0.0 | 0.0 | - | - | - | - |
| FRIEND SHOOTS FIRST | 0.7 | -5.4 | 13.2 | 0.0 | 0.4 | -10.2 | 0.0 | 67.2 |
| FRIENDS SHOTS CHECKED | 0.1 | +4.0 | 0.0 | 0.0 | - | - | - | - |
| GIVES UP | 0.2 | -0.9 | 6.4 | 4.7 | 0.3 | -1.2 | 20.9 | 0.0 |
| GROUND FLIERS | 0.1 | +2.1 | 0.0 | 0.0 | - | - | - | - |
| GUN FIGURES | 1.3 | -0.8 | 57.5 | 84.5 | 1.8 | +18.4 | 71.1 | 39.1 |
| GUN MASK | 0.4 | +11.1 | 0.0 | 0.0 | 0.3 | +19.9 | 0.0 | 0.0 |
| HARD STAY DROPPED | 2.3 | +0.0 | 0.0 | 56.4 | 0.7 | +0.0 | 0.0 | 0.0 |
| HE SHOOTS OR CHARGES | 2.3 | +0.0 | 0.0 | 78.9 | 2.2 | +0.0 | 0.0 | 75.2 |
| HELPER ALREADY ASKED | - | - | - | - | 0.1 | +0.0 | 12.6 | 0.0 |
| HIS CHARGE DENIED | - | - | - | - | 0.4 | +25.4 | 35.9 | 0.0 |
| HIS CHARGE LIST | 3.5 | +0.0 | 0.0 | 22.3 | 3.8 | +0.0 | 0.0 | 199.0 |
| HIS LEGAL MOVES | 2.5 | +0.0 | 0.0 | 82.5 | 2.9 | +0.0 | 0.0 | 42.7 |
| HIS MOVE AND SHOT | 1.6 | -28.8 | 0.0 | 9.5 | 1.2 | -32.5 | 0.0 | 89.3 |
| HIS ONE QUARTER | 3.1 | +0.0 | 0.0 | 28.1 | - | - | - | - |
| HIS RANDOM MOVE | 2.5 | +0.0 | 0.0 | 8.3 | 1.7 | +0.0 | 0.0 | 21.4 |
| HIS SHOT LIST | 18.5 | +541.6 | 0.0 | 203.1 | 22.5 | +1002.9 | 0.0 | 447.2 |
| HIS TURN DENIED | 0.6 | +10.8 | 17.5 | 30.8 | 1.5 | +56.5 | 81.7 | 53.9 |
| HOLD ODDS | 11.6 | +0.0 | 0.0 | 29.4 | - | - | - | - |
| HOLDER ASSIGNMENT | 12.9 | +1339.8 | 0.0 | 29.4 | - | - | - | - |
| HOLDER AT DEPLOYMENT | - | - | - | - | 2.0 | +352.8 | 0.0 | 5.0 |
| HOLDS AMBUSHERS | 0.5 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 1.4 | -64.8 | 88.6 | 43.8 | 2.5 | -126.7 | 164.4 | 53.9 |
| HUNT IN PAIRS | - | - | - | - | 0.4 | +5.5 | 0.0 | 0.0 |
| IDLE COST | 5.4 | -54.8 | 0.0 | 58.0 | 10.0 | -148.0 | 0.0 | 207.6 |
| JOINT KNOWS CHALLENGE | - | - | - | - | 0.1 | -1.7 | 0.0 | 0.0 |
| KEEP FALLS | 0.2 | +0.7 | 0.0 | 0.0 | 0.1 | +0.1 | 0.0 | 0.0 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 0.4 | +9.5 | 0.0 | 0.0 | 1.0 | +53.2 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | 0.4 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| LEGAL CHARGES ONLY | 5.8 | +0.0 | 96.0 | 192.3 | 3.7 | +0.0 | 130.2 | 19.2 |
| LONE WIZARD KEPT IN | 0.9 | +56.2 | 0.0 | 0.0 | 0.3 | +29.7 | 0.0 | 0.0 |
| LONG SHOT | 0.1 | +1.7 | 5.0 | 0.0 | - | - | - | - |
| MAKE SURE TOGETHER | - | - | - | - | 0.2 | +0.7 | 0.0 | 0.0 |
| MANOEUVRE | 1.3 | +6.6 | 0.0 | 56.4 | 0.9 | +18.3 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.1 | +0.5 | 0.0 | 7.7 | 0.1 | +0.0 | 0.0 | 0.0 |
| MARCH BY THE SUM | 0.5 | +30.5 | 0.0 | 0.0 | 0.4 | +12.9 | 0.0 | 72.7 |
| MARCH CHECK | 1.0 | +45.4 | 0.0 | 7.4 | 1.8 | +99.3 | 0.0 | 0.0 |
| MARCH OVER CASTS | 0.7 | -24.5 | 0.0 | 7.7 | 0.8 | +41.3 | 0.0 | 95.6 |
| MARCH WHEELS ONLY | 0.5 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MAX FOR POSITIONING | 3.9 | +39.3 | 0.0 | 58.0 | 3.5 | +33.2 | 0.0 | 57.5 |
| MISSILES IN THE MOVE | 3.6 | +191.4 | 0.0 | 37.5 | 3.5 | +62.5 | 0.0 | 53.7 |
| MISSILES NEXT TURN | 4.6 | +122.7 | 0.0 | 45.3 | 5.4 | +49.1 | 0.0 | 149.4 |
| MODEL FACING | 0.7 | +107.2 | 0.0 | 5.5 | 0.9 | +161.8 | 0.0 | 0.0 |
| MOVE SPELL IN RANGE | 0.6 | +18.3 | 0.0 | 0.0 | 0.4 | +4.6 | 0.0 | 0.0 |
| MOVE SPELL NOT WORTH | 0.3 | -0.2 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 3.2 | -78.0 | 0.0 | 0.0 | 0.5 | -18.0 | 0.0 | 0.0 |
| MOVE SPELL SPOT | 0.5 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 36.4 |
| MOVE TO CHARGE COMPUTED | 2.8 | +254.7 | 0.0 | 43.3 | 2.9 | +439.9 | 0.0 | 67.2 |
| MOVES UNITS SPELL | 0.2 | +10.0 | 0.0 | 0.0 | 0.1 | +0.4 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 4.6 | +223.9 | 0.0 | 8.3 | 6.6 | +267.0 | 0.0 | 32.6 |
| NEXT CHARGE BY LIST | 4.4 | -136.8 | 26.4 | 65.7 | 3.4 | -87.7 | 7.7 | 134.6 |
| NEXT OBJECTIVE NEARER | - | - | - | - | 11.8 | -557.1 | 92.5 | 92.4 |
| NO DOUBLE ROUNDS | 1.2 | -56.0 | 29.5 | 58.0 | 2.0 | -113.8 | 154.4 | 13.7 |
| NOT TURNED | 0.2 | +0.0 | 0.0 | 15.5 | 0.2 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 0.2 | -0.2 | 0.0 | 0.0 | 0.1 | -0.1 | 0.0 | 0.0 |
| OFF BEST | 0.3 | -59.8 | 0.0 | 0.0 | 0.6 | -50.5 | 0.0 | 5.0 |
| ONE CHARGE A CHARGER | 1.9 | +0.0 | 0.0 | 63.8 | 1.7 | +0.0 | 0.0 | 15.7 |
| ONE FIGHT FORMULA | 4.6 | -54.4 | 0.0 | 73.5 | 4.0 | -96.2 | 0.0 | 145.7 |
| ONE OBJECTIVE FORMULA | 4.9 | +56.6 | 0.0 | 0.0 | 3.0 | +60.8 | 0.0 | 25.9 |
| ONE ROUTE | 0.5 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ONE TARGET A SHOOTER | 15.3 | +298.9 | 0.0 | 222.9 | 21.2 | +655.7 | 0.0 | 440.1 |
| OPENS UP | 0.1 | +2.8 | 6.4 | 0.0 | 0.2 | +5.8 | 7.7 | 40.2 |
| OVERRUNS AWAY | 0.2 | +10.5 | 13.2 | 8.3 | 0.3 | +8.7 | 21.1 | 0.0 |
| PATHS CROSS | 3.9 | +113.9 | 0.0 | 47.8 | 5.2 | +221.3 | 0.0 | 88.5 |
| PERIAPT WORTH | - | - | - | - | 0.2 | +13.9 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.1 | -2.0 | 0.0 | 0.0 | - | - | - | - |
| PLAN RESULT | 41.4 | +1387.4 | 987.9 | 691.2 | 44.9 | +1013.7 | 426.3 | 841.2 |
| QUARTER ODDS | 9.3 | +909.6 | 398.5 | 85.8 | - | - | - | - |
| RANDOM MOVE BY FIGURES | 0.6 | +7.0 | 0.0 | 30.9 | 1.7 | +65.0 | 0.0 | 95.5 |
| REAL GROUND | 0.5 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| REDIRECT BY WHAT IT STOPS | 0.2 | -1.9 | 0.0 | 15.5 | 0.4 | -3.6 | 0.0 | 5.0 |
| REDIRECT COUNTER | 1.7 | +73.8 | 0.0 | 45.9 | 1.0 | +28.4 | 0.0 | 14.4 |
| REDIRECT WEIGHED | 0.1 | -0.9 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| REFORMS TO MEET IT | 0.5 | -30.7 | 0.0 | 4.7 | 0.2 | -2.1 | 0.0 | 0.0 |
| REFUSING RETIRES | 0.2 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | 0.3 | +15.5 | 0.0 | 10.2 | 0.5 | +33.5 | 0.0 | 10.2 |
| RESTRAINS TO SHOOT | 0.1 | +4.1 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | 1.5 | +2.0 | 72.5 | 58.0 | 1.8 | +19.5 | 126.2 | 53.9 |
| RISK BY HIS FIGURE | 10.0 | -76.4 | 0.0 | 197.0 | 10.9 | -129.8 | 0.0 | 212.0 |
| RISK ON THE WAY | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| RUN DOWN | 0.9 | -9.7 | 40.7 | 43.8 | 1.3 | -10.7 | 94.8 | 53.9 |
| SAFER THAN THE JOB | - | - | - | - | 0.1 | +11.9 | 0.0 | 0.0 |
| SAME CHARGE LATER | 0.1 | -1.9 | 0.0 | 0.0 | - | - | - | - |
| SCOUT SPOT | 0.2 | +1.6 | 0.0 | 0.0 | 0.2 | +0.7 | 0.0 | 0.0 |
| SCOUT WAITS | 0.2 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| SEARCH SPOT | 3.3 | +105.6 | 0.0 | 28.8 | 7.6 | +276.3 | 0.0 | 68.0 |
| SELF MOVE SPELL | - | - | - | - | 0.5 | -1.1 | 0.0 | 0.0 |
| SET UP TOGETHER | 0.2 | +1.5 | 0.0 | 0.0 | 0.6 | +7.2 | 0.0 | 0.0 |
| SET-UP MISSED | 0.1 | +3.1 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | 0.5 | +1.1 | 0.0 | 0.0 | 0.3 | +0.8 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.4 | +74.3 | 74.7 | 0.0 | 1.0 | +39.9 | 33.4 | 0.0 |
| SHORT GUN FORWARD | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| SHOT OR CHARGE | 0.1 | -4.5 | 13.2 | 8.3 | 0.3 | -6.0 | 12.6 | 0.0 |
| SHOT RISK POINTS | 9.6 | -27.5 | 0.0 | 126.2 | 12.7 | -80.8 | 0.0 | 361.5 |
| SHOTS IN THE MOVE | 18.0 | +558.5 | 0.0 | 279.3 | 17.0 | +445.9 | 0.0 | 143.3 |
| SPELL WORTH | 0.6 | +4.0 | 0.0 | 0.0 | 1.5 | +39.1 | 72.7 | 72.7 |
| SPELLS IN THE FIGHT | 0.3 | -5.0 | 17.3 | 0.0 | 0.3 | -1.7 | 0.0 | 13.7 |
| STAND AND SHOOT | 0.4 | -7.7 | 22.6 | 30.8 | 0.8 | -12.8 | 10.2 | 53.9 |
| STANDS FOR A REASON | 0.2 | +0.0 | 0.0 | 7.4 | 0.7 | +0.0 | 8.3 | 11.5 |
| STANDS STILL | 22.9 | +0.0 | 1779.5 | 232.7 | 16.8 | +0.0 | 419.0 | 134.5 |
| STAY WORTH | 23.6 | -24.6 | 1067.4 | 275.0 | 19.2 | +27.0 | 269.7 | 190.1 |
| STUCK PIVOT | - | - | - | - | 0.3 | +0.0 | 0.0 | 19.1 |
| SUPPORT NARROWED | 0.5 | +0.0 | 11.0 | 14.2 | 1.0 | +0.0 | 56.9 | 53.9 |
| SURE REACH TOGETHER | 0.3 | +5.7 | 0.0 | 10.2 | 1.1 | +21.3 | 0.0 | 27.0 |
| THE DEARER SUM KEEPS ITS PLAN | 3.6 | +0.0 | 0.0 | 47.8 | 4.5 | +0.0 | 0.0 | 52.2 |
| THE PROMISE ADDS | 0.1 | -1.1 | 0.0 | 0.0 | 0.1 | -4.4 | 0.0 | 0.0 |
| THE PROMISED MOVE | 0.7 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| TIED UP BY THE SUM | 0.5 | +50.1 | 23.8 | 30.8 | 0.7 | +73.8 | 65.2 | 13.7 |
| TIME ON OUR SIDE | 23.3 | +374.9 | 4.1 | 243.1 | 11.5 | +162.7 | 0.0 | 21.4 |
| TWO OR MORE ARRIVE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WAITS AGAIN | 1.5 | +0.0 | 0.0 | 12.5 | 0.7 | +0.0 | 0.0 | 0.0 |
| WALKS ON ITS ROUTE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WAR ENGINE CHARGES | 0.3 | +33.8 | 19.1 | 0.0 | - | - | - | - |
| WAR ENGINE JOBS | 0.3 | +0.0 | 32.3 | 0.0 | 0.4 | +0.0 | 15.5 | 0.0 |
| WHO HITS BACK | 0.2 | +28.4 | 0.0 | 0.0 | 0.1 | +12.0 | 0.0 | 0.0 |
| WHOLE FIGHT | 0.2 | +0.8 | 19.1 | 0.0 | 0.1 | +8.2 | 0.0 | 0.0 |
| WHOLE FIGHT GAIN | 0.1 | +1.5 | 5.9 | 0.0 | 0.1 | +0.8 | 0.0 | 0.0 |
| WIDER SPREAD | 1.0 | -7.0 | 41.4 | 4.7 | 1.8 | -7.4 | 139.3 | 53.9 |
| WOUNDS ON THE RANKS | 1.6 | +83.7 | 0.0 | 0.0 | 1.2 | +36.7 | 0.0 | 35.4 |

### Rule changes: h9-mine-81fb82c-p1

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS SHOT LIST | 451 | 451 | 146 | 13.27 | +3495 | +23.9 |
| HOLDER ASSIGNMENT | 142 | 142 | 132 | 12.00 | +7403 | +56.1 |
| SEARCH SPOT | 120 | 120 | 118 | 10.73 | +4200 | +35.6 |
| DEPLOY BY FIGURES | 192 | 192 | 117 | 10.64 | +2275 | +19.4 |
| LEGAL CHARGES ONLY | 105 | 105 | 105 | 9.55 | +0 | +0.0 |
| PATHS CROSS | 100 | 100 | 100 | 9.09 | +3688 | +36.9 |
| ONE TARGET A SHOOTER | 401 | 401 | 96 | 8.73 | +944 | +9.8 |
| TIME ON OUR SIDE | 382 | 354 | 91 | 8.27 | +253 | +2.8 |
| FIVE ACTION | 1080 | 1080 | 78 | 7.09 | +2330 | +29.9 |
| SHOT RISK POINTS | 246 | 246 | 44 | 4.00 | +1421 | +32.3 |
| ARTILLERY RE-ROLL WEIGHED | 43 | 43 | 43 | 3.91 | +0 | +0.0 |
| MOVE TO CHARGE COMPUTED | 63 | 63 | 42 | 3.82 | +3642 | +86.7 |
| HARD STAY DROPPED | 33 | 33 | 33 | 3.00 | +0 | +0.0 |
| FOUR ROUNDS | 51 | 51 | 29 | 2.64 | +1629 | +56.2 |
| CANNON PLANNED TARGET | 160 | 160 | 26 | 2.36 | -12 | -0.4 |
| IDLE COST | 169 | 135 | 25 | 2.27 | +173 | +6.9 |
| SHOTS IN THE MOVE | 385 | 344 | 24 | 2.18 | +603 | +25.1 |
| ADVANCE LANE KEPT | 23 | 23 | 23 | 2.09 | +0 | +0.0 |
| MARCH CHECK | 31 | 31 | 23 | 2.09 | +723 | +31.4 |
| MAX FOR POSITIONING | 82 | 80 | 23 | 2.09 | +63 | +2.8 |
| COVER ONCE | 132 | 109 | 21 | 1.91 | +260 | +12.4 |
| FALLS SHORT | 264 | 225 | 20 | 1.82 | +268 | +13.4 |
| SHOOTS FROM THE BEST SPOT | 26 | 26 | 19 | 1.73 | +290 | +15.3 |
| MODEL FACING | 18 | 18 | 18 | 1.64 | +2959 | +164.4 |
| RANDOM MOVE BY FIGURES | 26 | 26 | 18 | 1.64 | +792 | +44.0 |
| QUARTER ODDS | 102 | 102 | 16 | 1.45 | +793 | +49.5 |
| CANNON SIGHT KEPT | 15 | 15 | 15 | 1.36 | +0 | +0.0 |
| LANE BY FIGURES | 15 | 15 | 15 | 1.36 | +690 | +46.0 |
| FOLLOW UP WEIGHED | 14 | 14 | 14 | 1.27 | +4639 | +331.3 |
| MISSILES IN THE MOVE | 78 | 53 | 14 | 1.27 | +512 | +36.6 |
| CHARGE LOSSES | 135 | 135 | 13 | 1.18 | +1177 | +90.5 |
| HOLDER AT DEPLOYMENT | 22 | 22 | 13 | 1.18 | +640 | +49.2 |
| LONE WIZARD KEPT IN | 13 | 13 | 13 | 1.18 | +944 | +72.7 |
| MANOEUVRE | 24 | 24 | 12 | 1.09 | +318 | +26.5 |
| NEARER NOT NEEDED | 124 | 122 | 12 | 1.09 | +427 | +35.6 |
| NEXT OBJECTIVE NEARER | 130 | 130 | 11 | 1.00 | +167 | +15.2 |
| TIED UP BY THE SUM | 13 | 13 | 11 | 1.00 | +430 | +39.1 |
| CHARGE NOT DECLARED | 10 | 10 | 10 | 0.91 | -1180 | -118.0 |
| COMBAT PIVOT | 10 | 10 | 10 | 0.91 | +0 | +0.0 |
| MARCH BY THE SUM | 10 | 10 | 10 | 0.91 | +477 | +47.7 |
| OFF BEST | 10 | 10 | 10 | 0.91 | -1213 | -121.3 |
| RESERVE FALL BACK | 9 | 9 | 9 | 0.82 | +538 | +59.8 |
| RISK BY ARC | 37 | 37 | 9 | 0.82 | +260 | +28.9 |
| SHOOTERS IN TWO RANKS | 9 | 9 | 9 | 0.82 | +21 | +2.3 |
| SURE REACH TOGETHER | 15 | 15 | 9 | 0.82 | +42 | +4.7 |
| HIS TURN DENIED | 23 | 23 | 8 | 0.73 | +202 | +25.2 |
| HOLDS AMBUSHERS | 8 | 8 | 8 | 0.73 | +0 | +0.0 |
| REDIRECT COUNTER | 30 | 24 | 8 | 0.73 | +329 | +41.1 |
| RISK BY HIS FIGURE | 230 | 230 | 8 | 0.73 | +585 | +73.1 |
| WOUNDS ON THE RANKS | 31 | 31 | 7 | 0.64 | +206 | +29.4 |
| CASTER AWAY FROM SCREEN | 6 | 6 | 6 | 0.55 | +0 | +0.0 |
| CHAFF IN THE MOVE | 7 | 7 | 6 | 0.55 | +310 | +51.7 |
| SHORT GUN FORWARD | 6 | 6 | 6 | 0.55 | +0 | +0.0 |
| STAY WORTH | 471 | 441 | 6 | 0.55 | +36 | +6.0 |
| CHARGE NOW FIRST | 28 | 28 | 5 | 0.45 | -52 | -10.3 |
| FEATURE BUFFS | 23 | 23 | 5 | 0.45 | +148 | +29.6 |
| FIGHT TO THE END | 14 | 14 | 5 | 0.45 | +473 | +94.5 |
| ONE FIGHT FORMULA | 95 | 45 | 5 | 0.45 | +17 | +3.4 |
| ONE OBJECTIVE FORMULA | 87 | 64 | 5 | 0.45 | +177 | +35.4 |
| CASTING BLOCK | 5 | 5 | 4 | 0.36 | +19 | +4.6 |
| NEXT CHARGE BY LIST | 85 | 85 | 4 | 0.36 | +235 | +58.6 |
| SCOUT WAITS | 4 | 4 | 4 | 0.36 | +0 | +0.0 |
| AFTERMATH IN POINTS | 3 | 3 | 3 | 0.27 | +33 | +11.0 |
| BEST PRIZE | 3 | 3 | 3 | 0.27 | -50 | -16.7 |
| FIRE IN ORDER | 3 | 3 | 3 | 0.27 | +0 | +0.0 |
| GUN MASK | 7 | 7 | 3 | 0.27 | +156 | +52.1 |
| KEEP FALLS | 3 | 3 | 3 | 0.27 | +84 | +27.9 |
| MOVES UNITS SPELL | 3 | 3 | 3 | 0.27 | +114 | +38.2 |
| REFUSING RETIRES | 3 | 3 | 3 | 0.27 | -1 | -0.2 |
| STUCK PIVOT | 3 | 3 | 3 | 0.27 | +0 | +0.0 |
| WHO HITS BACK | 3 | 3 | 3 | 0.27 | +231 | +77.2 |
| CASTS FROM BEHIND | 2 | 2 | 2 | 0.18 | +0 | +0.0 |
| HONEST WORTH | 43 | 43 | 2 | 0.18 | +11 | +5.5 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.18 | +0 | +0.0 |
| MISSILES NEXT TURN | 110 | 74 | 2 | 0.18 | +5 | +2.6 |
| OPENS UP | 3 | 3 | 2 | 0.18 | +40 | +20.1 |
| OVERRUNS AWAY | 5 | 5 | 2 | 0.18 | +29 | +14.7 |
| PERIAPT WORTH | 2 | 2 | 2 | 0.18 | +153 | +76.7 |
| REDIRECT WEIGHED | 2 | 2 | 2 | 0.18 | +220 | +110.2 |
| WAR ENGINE JOBS | 7 | 7 | 2 | 0.18 | -74 | -37.2 |
| WHOLE FIGHT GAIN | 2 | 2 | 2 | 0.18 | +16 | +8.0 |
| CAST JOB | 7 | 7 | 1 | 0.09 | +0 | +0.0 |
| CHAFF PASSED | 1 | 1 | 1 | 0.09 | -4 | -3.9 |
| CHARGER SLAIN LOST | 7 | 7 | 1 | 0.09 | +132 | +132.3 |
| EDGE GIVE GROUND | 5 | 5 | 1 | 0.09 | +0 | +0.0 |
| ELIXIR WORTH | 1 | 1 | 1 | 0.09 | +34 | +34.3 |
| FRIENDS SHOTS CHECKED | 1 | 1 | 1 | 0.09 | +44 | +43.9 |
| HIS CHARGE DENIED | 4 | 4 | 1 | 0.09 | +98 | +98.2 |
| HIS MOVE AND SHOT | 31 | 31 | 1 | 0.09 | +0 | +0.0 |
| HUNT IN PAIRS | 4 | 2 | 1 | 0.09 | +11 | +10.6 |
| LONG SHOT | 1 | 1 | 1 | 0.09 | +10 | +10.4 |
| PIVOT GUARDS FLANK | 1 | 1 | 1 | 0.09 | -22 | -22.3 |
| REDIRECT BY WHAT IT STOPS | 6 | 6 | 1 | 0.09 | +86 | +85.6 |
| RESTRAINS TO SHOOT | 1 | 1 | 1 | 0.09 | +45 | +44.9 |
| SAFER THAN THE JOB | 1 | 1 | 1 | 0.09 | +131 | +130.9 |
| SET UP TOGETHER | 9 | 9 | 1 | 0.09 | +8 | +8.5 |
| SPELLS IN THE FIGHT | 6 | 6 | 1 | 0.09 | +9 | +9.0 |
| SUPPORT NARROWED | 17 | 17 | 1 | 0.09 | -3 | -3.3 |
| WALKS ON ITS ROUTE | 1 | 1 | 1 | 0.09 | +0 | +0.0 |
| WHOLE FIGHT | 3 | 3 | 1 | 0.09 | +25 | +25.3 |
| ALREADY CARRIED | 6 | not checked | - | - | - | - |
| BACKUP TARGETS | 4 | not checked | - | - | - | - |
| BLOWS WHERE AIMED | 3 | 3 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 14 | 14 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 19 | trace | - | - | - | - |
| CHARACTER GUNS | 15 | 15 | 0 | 0.00 | - | - |
| CHEAP HELPER | 1 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 19 | not checked | - | - | - | - |
| ENGINEER BY LORE | 6 | 6 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 34 | 34 | 0 | 0.00 | - | - |
| FIGHT LIFT | 2 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 95 | not checked | - | - | - | - |
| FRIEND CHARGES FIRST | 2 | 2 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 12 | 12 | 0 | 0.00 | - | - |
| GIVES UP | 5 | 5 | 0 | 0.00 | - | - |
| GROUND FLIERS | 1 | not checked | - | - | - | - |
| GUN FIGURES | 34 | not checked | - | - | - | - |
| HE SHOOTS OR CHARGES | 49 | 49 | 0 | 0.00 | - | - |
| HELPER ALREADY ASKED | 1 | not checked | - | - | - | - |
| HIS CHARGE LIST | 80 | 80 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 59 | 59 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 34 | 34 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 46 | 46 | 0 | 0.00 | - | - |
| HOLD ODDS | 128 | 128 | 0 | 0.00 | - | - |
| JOINT KNOWS CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 4 | 4 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 2 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 2 | trace | - | - | - | - |
| MARCH OVER CASTS | 17 | 17 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 6 | 6 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 11 | 6 | 0 | 0.00 | - | - |
| MOVE SPELL NOT WORTH | 3 | not checked | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 40 | trace | - | - | - | - |
| MOVE SPELL SPOT | 7 | not checked | - | - | - | - |
| NO DOUBLE ROUNDS | 35 | 35 | 0 | 0.00 | - | - |
| NOT TURNED | 4 | 4 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 3 | not checked | - | - | - | - |
| ONE CHARGE A CHARGER | 40 | 40 | 0 | 0.00 | - | - |
| ONE ROUTE | 6 | 6 | 0 | 0.00 | - | - |
| PLAN RESULT | 949 | trace | - | - | - | - |
| REAL GROUND | 6 | 6 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 7 | 7 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 8 | 8 | 0 | 0.00 | - | - |
| RUN DOWN | 24 | 24 | 0 | 0.00 | - | - |
| SAME CHARGE LATER | 1 | 1 | 0 | 0.00 | - | - |
| SCOUT SPOT | 4 | 4 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 6 | not checked | - | - | - | - |
| SET-UP MISSED | 1 | trace | - | - | - | - |
| SHOT OR CHARGE | 4 | 4 | 0 | 0.00 | - | - |
| SPELL WORTH | 24 | not checked | - | - | - | - |
| STAND AND SHOOT | 13 | 13 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 10 | 10 | 0 | 0.00 | - | - |
| STANDS STILL | 437 | 437 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 90 | not checked | - | - | - | - |
| THE PROMISE ADDS | 2 | 2 | 0 | 0.00 | - | - |
| THE PROMISED MOVE | 10 | not checked | - | - | - | - |
| TWO OR MORE ARRIVE | 1 | not checked | - | - | - | - |
| WAITS AGAIN | 24 | 24 | 0 | 0.00 | - | - |
| WAR ENGINE CHARGES | 3 | 3 | 0 | 0.00 | - | - |
| WIDER SPREAD | 31 | 31 | 0 | 0.00 | - | - |

### Off best figure: h9-mine-81fb82c-p1

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| HOLDER ASSIGNMENT | rule | 0.82 | - | 18.7 |
| CHARGE NOT DECLARED | rule | 0.27 | 0.45 | 147.5 |
| JOB FIRST | gate | 0.09 | 0.45 | 10.9 |
| CHARGE NOW FIRST | rule | 0.27 | 0.18 | 10.3 |
| PATHS CROSS | rule | - | 0.45 | 8.4 |
| BEST PRIZE | rule | 0.09 | 0.18 | 16.7 |
| CANNON PLANNED TARGET | rule | 0.18 | - | 9.0 |
| WAR ENGINE JOBS | rule | - | 0.18 | 37.2 |
| AFTERMATH NEEDS NEXT CHARGE | gate | - | 0.09 | 182.3 |
| CHAFF PASSED | rule | 0.09 | - | 3.9 |
| FIGHT ORDER BAND | gate | 0.09 | - | 0.5 |
| NO REASON | gate | 0.09 | - | 651.4 |
| PIVOT GUARDS FLANK | rule | 0.09 | - | 22.3 |
| RULE SWITCHED OFF | gate | - | 0.09 | 313.3 |
| SUPPORT NARROWED | rule | 0.09 | - | 3.3 |

### Plans: h9-mine-81fb82c-p1

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.6 | 50% | 121 | 94 | 78% |
| Mine | join | 0.5 | 100% | 16 | 0 | 0% |
| Mine | move | 25.9 | 95% | 1674 | 0 | 0% |
| Mine | shoot | 13.2 | 61% | 414 | 1294 | 313% |
| Mine | support | 0.2 | 0% | 0 | 0 | - |
| Opponent | charge | 2.2 | 62% | 363 | 197 | 54% |
| Opponent | join | 0.6 | 100% | 23 | 0 | 0% |
| Opponent | move | 32.9 | 94% | 1562 | 0 | 0% |
| Opponent | shoot | 8.8 | 74% | 225 | 817 | 363% |
| Opponent | support | 0.4 | 100% | 15 | 0 | 0% |

### Battle groups: h9-mine-81fb82c-p1

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 1.7 | 26% | 80% | 0% | - | 0% | 0% | 0% | 100% | 0% |
| Opponent | REDIRECT COUNTER | 1.0 | 27% | 100% | 0% | - | 0% | 0% | 67% | 33% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: h9-mine-81fb82c-p1

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Mine | Chaff | 8 | 57 (8) | 0 | 57 | 30 | 62% | 3.3 | - | 66 (7) | 0 (1) | 85 (5) | 0 (3) |
| Mine | Character | 44 | 27 (44) | 27 | 0 | 14 | 23% | 2.7 | 24 (26) | 36 (12) | 22 (6) | 25 (34) | 32 (10) |
| Mine | Clean-up | 7 | 27 (7) | 0 | 27 | 59 | 43% | 3.8 | 34 (2) | 33 (4) | 0 (1) | 14 (6) | 75 (1) |
| Mine | Fast | 2 | 0 (2) | 0 | 0 | 50 | 50% | 1.0 | - | - | 0 (2) | 0 (1) | 0 (1) |
| Mine | Fast Hammer | 8 | 11 (8) | 6 | 5 | 86 | 25% | 3.2 | - | 20 (5) | 0 (3) | 23 (2) | 7 (6) |
| Mine | Hammer | 25 | 33 (25) | 6 | 28 | 23 | 40% | 2.8 | 56 (7) | 29 (11) | 10 (7) | 45 (15) | 10 (10) |
| Mine | Holder | 12 | 93 (12) | 0 | 93 | 20 | 67% | 2.8 | 181 (2) | 85 (7) | 44 (3) | 105 (5) | 84 (7) |
| Mine | Shooter | 5 | 132 (5) | 22 | 110 | 0 | 0% | 1.2 | 0 (1) | 187 (3) | 138 (1) | 181 (4) | 0 (1) |
| Mine | War machine | 24 | 96 (24) | 96 | 0 | 32 | 0% | 1.3 | 58 (13) | 34 (7) | 337 (4) | 135 (2) | 92 (22) |
| Mine | Wizard | 7 | 7 (7) | 7 | 0 | 27 | 43% | 3.5 | 13 (4) | 0 (1) | 0 (2) | 0 (2) | 10 (5) |
| Opponent | Chaff | 14 | 90 (14) | 3 | 87 | 54 | 50% | 2.1 | 74 (7) | 131 (5) | 0 (2) | 78 (10) | 128 (4) |
| Opponent | Character | 29 | 41 (29) | 41 | 0 | 30 | 28% | 2.4 | 26 (8) | 27 (11) | 96 (6) | 62 (11) | 29 (14) |
| Opponent | Clean-up | 11 | 47 (11) | 8 | 39 | 27 | 73% | 3.7 | 0 (1) | 43 (9) | 237 (1) | 108 (6) | 12 (5) |
| Opponent | Fast | 1 | 187 (1) | 187 | 0 | 0 | 0% | 1.0 | - | 187 (1) | - | 187 (1) | - |
| Opponent | Fast Hammer | 8 | 27 (8) | 8 | 18 | 19 | 50% | 2.8 | 21 (2) | 22 (5) | 62 (1) | 13 (3) | 31 (5) |
| Opponent | Fragile | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | - | 0 (1) | 0 (1) | - |
| Opponent | Hammer | 18 | 26 (18) | 10 | 16 | 37 | 44% | 3.0 | 20 (3) | 29 (13) | 13 (2) | 15 (12) | 48 (6) |
| Opponent | Holder | 15 | 89 (15) | 6 | 82 | 17 | 60% | 3.2 | 139 (8) | 22 (4) | 87 (3) | 95 (8) | 81 (7) |
| Opponent | Shooter | 13 | 64 (13) | 41 | 23 | 24 | 15% | 1.5 | 0 (2) | 70 (11) | - | 67 (5) | 62 (8) |
| Opponent | War machine | 14 | 6 (14) | 6 | 0 | 16 | 0% | 1.6 | 29 (2) | 0 (4) | 0 (8) | 0 (3) | 7 (11) |
| Opponent | Wizard | 7 | 2 (7) | 2 | 0 | 8 | 29% | 1.4 | 0 (2) | 3 (3) | 0 (1) | 0 (2) | 2 (4) |

### Charged fights: h9-mine-81fb82c-p1

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 273 | 16 | 1.2 | 1.2 | 13 | 21 | -8 | 2 of 5 | 2 of 5 | +65 | -26 |
| Mine | Chaos Dwarfs | 4 | 219 | 242 | 2.0 | 1.0 | 121 | 11 | +110 | 3 of 8 | 6 of 8 | - | +110 |
| Mine | Dwarfen Mountain Holds | 3 | 692 | 0 | 0.3 | 1.0 | 0 | 407 | -407 | 1 of 1 | 0 of 1 | - | -407 |
| **Mine** | all armies | 11 | 368 | 94 | 1.3 | 1.1 | 74 | 43 | +31 | 6 of 14 | 8 of 14 | +65 | +28 |
| Opponent | Chaos Dwarfs | 3 | 101 | 245 | 2.0 | 1.0 | 122 | 0 | +122 | 4 of 6 | 5 of 6 | - | +122 |
| Opponent | Dwarfen Mountain Holds | 1 | 478 | 112 | 2.0 | 1.0 | 56 | 0 | +56 | 0 of 2 | 2 of 2 | - | +56 |
| Opponent | Grand Cathay | 1 | 95 | 388 | 2.0 | 1.0 | 194 | 0 | +194 | 1 of 2 | 1 of 2 | - | +194 |
| Opponent | High Elf Realms | 1 | 165 | 0 | 1.0 | 1.0 | 0 | 151 | -151 | 1 of 1 | 0 of 1 | - | -151 |
| Opponent | Orc & Goblin Tribes | 1 | 0 | 503 | 5.0 | 1.0 | 101 | 0 | +101 | 0 of 5 | 5 of 5 | - | +101 |
| Opponent | Skaven | 2 | 0 | 0 | 0.5 | 1.0 | 0 | 0 | +0 | 1 of 1 | 0 of 1 | - | +0 |
| Opponent | Tomb Kings of Khemri | 1 | 0 | 620 | 4.0 | 1.0 | 155 | 0 | +155 | 3 of 4 | 4 of 4 | - | +155 |
| Opponent | Vampire Counts | 1 | 0 | 401 | 3.0 | 1.0 | 134 | 0 | +134 | 1 of 3 | 3 of 3 | - | +134 |
| **Opponent** | all armies | 11 | 95 | 251 | 2.2 | 1.0 | 115 | 6 | +109 | 11 of 24 | 20 of 24 | - | +109 |

### Effective charges: h9-mine-81fb82c-p1

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 5 | 2 (net -52) | 0 | 1 (net +0) | 1 (net +0) | 0 | 1 (net +65) | 0 | 20% (1 of 5) |
| Mine | Chaos Dwarfs | 8 | 1 (net +278) | 0 | 1 (net +128) | 1 (net +210) | 4 (net +88) | 1 (net -91) | 0 | 12% (1 of 8) |
| Mine | Dwarfen Mountain Holds | 1 | 1 (net -407) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 1) |
| Opponent | Chaos Dwarfs | 6 | 1 (net +0) | 1 (net +0) | 0 | 1 (net +0) | 0 | 3 (net +245) | 0 | 0% (0 of 6) |
| Opponent | Dwarfen Mountain Holds | 2 | 1 (net +0) | 0 | 0 | 0 | 0 | 0 | 1 | 0% (0 of 1) |
| Opponent | Grand Cathay | 2 | 1 (net +388) | 0 | 1 (net +0) | 0 | 0 | 0 | 0 | 50% (1 of 2) |
| Opponent | High Elf Realms | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net -151) | 0 | 0% (0 of 1) |
| Opponent | Orc & Goblin Tribes | 5 | 0 | 0 | 0 | 0 | 3 (net +140) | 0 | 2 | 0% (0 of 3) |
| Opponent | Skaven | 1 | 1 (net +0) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 1) |
| Opponent | Tomb Kings of Khemri | 4 | 1 (net +0) | 0 | 1 (net +310) | 0 | 0 | 2 (net +155) | 0 | 25% (1 of 4) |
| Opponent | Vampire Counts | 3 | 1 (net +138) | 0 | 1 (net +95) | 0 | 1 (net +168) | 0 | 0 | 33% (1 of 3) |

### Charged fights, damage counted: h9-mine-81fb82c-p1

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 4 | 158 | 301 | -58 | 81 | 128 | -46 | -29.2 |
| Mine | Effective (55-75%) | 2 | 181 | 187 | +64 | 133 | 79 | +54 | +29.8 |
| Mine | 76-89% | 2 | 198 | 135 | +105 | 120 | 66 | +54 | +27.1 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 130 | 105 | -13 | 32 | 67 | -34 | -26.2 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 4 | 374 | 66 | +88 | 124 | 0 | +124 | +33.0 |
| Mine | All fights | 14 | 225 | 166 | +31 | 99 | 67 | +33 | +14.5 |
| Opponent | Long shot (under 50%) | 6 | 263 | 220 | +88 | 118 | 27 | +92 | +34.8 |
| Opponent | 50-54% | 1 | 339 | 310 | +0 | 0 | 44 | -44 | -13.1 |
| Opponent | Effective (55-75%) | 3 | 297 | 213 | +135 | 181 | 0 | +181 | +60.9 |
| Opponent | 76-89% | 1 | 480 | 310 | +0 | 0 | 137 | -137 | -28.6 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 6 | 305 | 219 | +149 | 189 | 59 | +130 | +42.6 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 4 | 382 | 86 | +147 | 147 | 0 | +147 | +38.5 |
| Opponent | No odds | 3 | 153 | 65 | +65 | 65 | 0 | +65 | +42.4 |
| Opponent | All fights | 24 | 296 | 185 | +109 | 132 | 29 | +103 | +34.8 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| h9-mine-81fb82c-p1 | move | 57 | 15 (26%) | 11 (19%) | 4 (7%) | 38 (67%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0103, L0120 |
| Charmed Shield | Opponent | L0525 |
| Elixir of Power | Opponent | L0219 |
| Invocation of Nehek | Opponent | L0525 |
| Periapt of Soul Exchange | Opponent | L0120, L0321 |
| Ring of Doom | Mine | L0204, L0219 |
| Ring of Jet | Opponent | L0510 |
| Standard of the Fell Warrior | Opponent | L0613 |
| Storm Daemon (Renegade 2.0) | Opponent | L0321 |
| Twice-Blessed Armour | Opponent | L0510 |

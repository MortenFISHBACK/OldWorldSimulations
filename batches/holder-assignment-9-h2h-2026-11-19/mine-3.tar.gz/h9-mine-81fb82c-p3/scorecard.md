# Doctrine scorecard: h9-mine-81fb82c-p3

### Scorecard: h9-mine-81fb82c-p3

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0111 | 3 | 1 | Mine | yes | 1 | - | 0 | 3 | 0 | 0 | 0 | 0 |
| L0111 | 3 | 1 | Opponent | no | 8 | 4 | 3 | 0 | 0 | 0 | 0 | 165 |
| L0128 | 2 | 1 | Mine | - | - | - | 0 | 4 | 0 | 0 | 0 | 0 |
| L0128 | 2 | 1 | Opponent | - | - | - | 0 | 4 | 0 | 0 | 0 | 0 |
| L0211 | 1 | 1 | Mine | no | 0 | 3 | 1 | 5 | 1 | 0 | 0 | 255 |
| L0211 | 1 | 1 | Opponent | yes | 19 | 2 | 1 | 0 | 0 | 0 | 0 | 0 |
| L0228 | 6 | 1 | Mine | no | 0 | 2 | 3 | 3 | 0 | 0 | 0 | 170 |
| L0228 | 6 | 1 | Opponent | no | 11 | - | 0 | 0 | 0 | 0 | 0 | 0 |
| L0313 | 1 | 1 | Mine | no | 5 | - | 0 | 1 | 0 | 0 | 0 | 0 |
| L0313 | 1 | 1 | Opponent | no | 3 | 2 | 1 | 0 | 1 | 0 | 0 | 70 |
| L0330 | 6 | 1 | Mine | no | 9 | - | 0 | 0 | 0 | 0 | 0 | 790 |
| L0330 | 6 | 1 | Opponent | no | 6 | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| L0415 | 1 | 1 | Mine | no | 8 | 2 | 6 | 0 | 0 | 0 | 0 | 310 |
| L0415 | 1 | 1 | Opponent | no | 20 | 2 | 2 | 0 | 0 | 0 | 0 | 0 |
| L0432 | 6 | 1 | Mine | no | 4 | 2 | 2 | 1 | 1 | 0 | 0 | 0 |
| L0432 | 6 | 1 | Opponent | no | 2 | 2 | 3 | 2 | 1 | 0 | 0 | 340 |
| L0518 | 2 | 1 | Mine | - | - | - | 0 | 1 | 0 | 0 | 0 | 138 |
| L0518 | 2 | 1 | Opponent | - | - | - | 0 | 4 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 14% | 3.9 | 2.2 | 1.3 | 2.0 | 0.2 | 0.0 | 0.0 | 184.8 |
| **Average** | | | Opponent | 14% | 9.9 | 2.3 | 1.3 | 1.2 | 0.2 | 0.0 | 0.0 | 63.9 |

### KPIs: h9-mine-81fb82c-p3

Rules off - Opponent only: HOLDER ASSIGNMENT, QUARTER ODDS, WALK PROMISE, REAL GROUND, RISK ON THE WAY, ONE ROUTE, MARCH WHEELS ONLY, LATE ONLY FROM HERE, WALKS ON ITS ROUTE.

Morten 2026-11-10; 9 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 30% (13 of 43) | 12% (5 of 43) | 21% (18 of 86) |
| Winner chose to follow up after the loser gave ground |  | 75% (3 of 4); on the table 75% | 89% (8 of 9); on the table 89% | 85% (11 of 13); on the table 85% |
| Winner chose to pursue after the loser fell back in good order |  | 100% (2 of 2); on the table 100% | 100% (2 of 2); on the table 100% | 100% (4 of 4); on the table 100% |
| Winner chose to pursue after the loser fled |  | 83% (5 of 6); on the table 83% | 80% (4 of 5); on the table 80% | 82% (9 of 11); on the table 82% |
| Winner chose to follow up or pursue (all three) |  | 83% (10 of 12); on the table 83% | 88% (14 of 16); on the table 88% | 86% (24 of 28); on the table 86% |
| Magic missiles tried each own turn | 50%+ | 41% (57 of 138) | 33% (20 of 60) | 39% (77 of 198) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 54% (57 of 106) | 41% (20 of 49) | 50% (77 of 155) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 62% (5 of 8) | 0% (0 of 3) | 45% (5 of 11) |
| Points that never fought | lower | 60% (10560 of 17564) | 54% (9664 of 17997) | 57% (20224 of 35561) |
|   infantry points that never fought | lower | 70% (3574 of 5100) | 65% (1270 of 1950) | 69% (4844 of 7050) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 61% (37 of 61) | 52% (34 of 66) | 56% (71 of 127) |
| Bound items with a magic missile used (at least once a game) |  | 100% (6 of 6); 2.3 uses a game | 100% (8 of 8); 3.2 uses a game | 100% (14 of 14); 2.8 uses a game |
| Bound items with another spell used |  | 100% (2 of 2); 0.4 uses a game | 0% (0 of 2); 0.0 uses a game | 50% (2 of 4); 0.2 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 75% (6 of 8); 0.7 uses a game | 33% (1 of 3); 0.1 uses a game | 64% (7 of 11); 0.4 uses a game |
|   their share of the points of units over 100 pts | lower | 58% (7800 of 13520) | 48% (7987 of 16547) | 53% (15787 of 30067) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 3.8 (42%) | 0.8 (18%) | 4.6 (34%) |
| MARCHED: its unit marched | 1.2 (14%) | 1.2 (28%) | 2.4 (18%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.2 (5%) | 0.2 (2%) |
| IN COMBAT: engaged in combat | 0.4 (5%) | 0.8 (18%) | 1.2 (9%) |
| REAR RANK: in a rear rank | 0.4 (5%) | 0.3 (8%) | 0.8 (6%) |
| FLEEING: fleeing | 0.0 (0%) | 0.2 (5%) | 0.2 (2%) |
| GONE: slain | 3.1 (35%) | 0.2 (5%) | 3.3 (25%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.2 (5%) | 0.2 (2%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.1 (2%) | 0.1 (1%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.3 (8%) | 0.3 (2%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 3.3 | 2.8 | 1.8 | 8.6 | 0.4 | 1.4 |
| not cast | 4.0 | 5.8 | 2.9 | 13.4 | 1.6 | 22.6 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.2 (5%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 2.0 (35%) | 0.0 (0%) | 4.6 (34%) | 0.3 (21%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.4 (18%) | 0.4 (29%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (2%) | 0.2 (14%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.6 (14%) | 0.1 (2%) | 0.0 (0%) | 1.2 (9%) | 0.1 (7%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 1.3 (23%) | 0.0 (0%) | 0.8 (6%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (0%) | 0.2 (4%) | 0.0 (0%) | 0.2 (2%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | 0.4 (11%) | 1.0 (17%) | 0.4 (15%) | 3.3 (25%) | 0.2 (14%) | 3.9 (17%) |
| OFF THE TABLE: off the table or not arrived | 0.2 (6%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| STUPIDITY: Stupidity | 0.1 (3%) | 0.1 (2%) | 0.1 (4%) | 0.2 (2%) | 0.0 (0%) | 0.7 (3%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.6 (10%) | 0.0 (0%) | 0.1 (1%) | 0.2 (14%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (2%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.7 (67%) | 0.4 (8%) | 2.3 (81%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 16.8 (74%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.4 a game | 0.8 a game | 1.1 a game |
| stood (cast and not dispelled) | 69% (9 of 13) | 0% (0 of 1) | 64% (9 of 14) |
| the unit moved after it | 67% (6 of 9) | - | 67% (6 of 9) |
| it charged on its next turn | 0% (0 of 9) | - | 0% (0 of 9) |
| the enemy charged it first | 11% (1 of 9) | - | 11% (1 of 9) |
| it fought by the end of its next turn | 0% (0 of 9) | - | 0% (0 of 9) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 9) | - | 0% (0 of 9) |
| none of these (no charge, no fight, no charge escaped) | 89% (8 of 9) | - | 89% (8 of 9) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 63% (114 of 182) | 52% (79 of 152) | 58% (193 of 334) |
|   cavalry | 56% (5 of 9) | 57% (4 of 7) | 56% (9 of 16) |
|   character | 79% (19 of 24) | 34% (10 of 29) | 55% (29 of 53) |
|   chariot | 35% (14 of 40) | 35% (6 of 17) | 35% (20 of 57) |
|   infantry | 71% (22 of 31) | 62% (32 of 52) | 65% (54 of 83) |
|   monster | - | 36% (4 of 11) | 36% (4 of 11) |
|   war machine | 69% (54 of 78) | 64% (23 of 36) | 68% (77 of 114) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.4 (19%) | 2.4 (30%) | 3.9 (25%) |
| CHARGED: it charged | 0.2 (3%) | 1.1 (14%) | 1.3 (9%) |
| FLEEING: it fled or was fleeing | 0.0 (0%) | 0.2 (3%) | 0.2 (1%) |
| IN COMBAT: it fought this turn or the last | 0.8 (10%) | 0.2 (3%) | 1.0 (6%) |
| MOVED: a war machine that moved | 1.6 (21%) | 1.0 (12%) | 2.6 (16%) |
| NO TARGET IN RANGE | 1.4 (19%) | 1.2 (15%) | 2.7 (17%) |
| ONLY IN COMBAT: the only targets were in combat | 0.2 (3%) | 0.1 (1%) | 0.3 (2%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.8 (10%) | 0.7 (8%) | 1.4 (9%) |
| SHELTERED: the target was sheltered | 0.4 (6%) | 0.9 (11%) | 1.3 (9%) |
| OTHER BAR | 0.7 (9%) | 0.2 (3%) | 0.9 (6%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 1.1 | 0.1 | 90% | 2.0 pts | 2 pts |
| character | 3.7 | 2.6 | 61% | 9.8 pts | 36 pts |
| chariot | 2.2 | 2.2 | 35% | 20.2 pts | 45 pts |
| infantry | 9.7 | 3.2 | 72% | 5.9 pts | 57 pts |
| monster | 0.4 | 0.2 | 75% | 29.2 pts | 13 pts |
| war machine | 8.6 | 9.7 | 56% | 30.8 pts | 264 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 2.1 | 2.7 | 2.4 |
| Charges that made contact a game | 2.0 | 2.2 | 2.1 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.17 declared, 0.17 contact (6 units) | 1.20 declared, 0.80 contact (5 units) | 0.64 declared, 0.45 contact (11 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 0.50 declared, 0.00 contact (2 units) | 0.50 declared, 0.00 contact (2 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.31 declared, 0.29 contact (59 units) | 0.30 declared, 0.28 contact (57 units) | 0.30 declared, 0.28 contact (116 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 36% (4 of 11) | - | 14% (1 of 7) | 28% (5 of 18) |
| Character in a unit | 86% (12 of 14) | 75% (9 of 12) | 50% (1 of 2) | 79% (22 of 28) |
| Character on its own | 100% (2 of 2) | 73% (8 of 11) | 40% (4 of 10) | 61% (14 of 23) |
| Chariot | 60% (3 of 5) | 75% (6 of 8) | - | 69% (9 of 13) |
| Infantry | 31% (4 of 13) | 36% (4 of 11) | - | 33% (8 of 24) |
| Monster | 50% (2 of 4) | 50% (1 of 2) | - | 50% (3 of 6) |
| Monstrous | 100% (1 of 1) | 50% (1 of 2) | - | 67% (2 of 3) |
| War Machines | 80% (8 of 10) | 0% (0 of 2) | - | 67% (8 of 12) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | - | 41% (42 of 102) | 78% | 77% (17 of 22) | 100% (6 of 6); 5.2 uses a game | 100% (2 of 2); 1.0 uses a game | 83% (5 of 6); 1.2 uses a game |
| Chaos Dwarfs | 4 | 83% (10 of 12); on the table 83% | 42% (15 of 36) | 45% | 53% (17 of 32) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
| Dwarfen Mountain Holds | 1 | - | - | 54% | 43% (3 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Grand Cathay | 2 | - | 39% (14 of 36) | 63% | 50% (8 of 16) | 100% (4 of 4); 5.5 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |
| High Elf Realms | 2 | 67% (4 of 6); on the table 67% | 0% (0 of 6) | 40% | 40% (6 of 15) | 100% (3 of 3); 7.5 uses a game | 0% (0 of 2); 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 1 | - | 0% (0 of 6) | 98% | 57% (4 of 7) | 100% (1 of 1); 3.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 4 | 100% (10 of 10); on the table 100% | 50% (6 of 12) | 45% | 57% (16 of 28) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 0.2 uses a game |

Flank and rear charges a unit could have turned to face (h9-mine-81fb82c-p3, 9 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 59% (10) | 45% (5) | 54% (15) |
| ...free all their last turn and able to turn (per game) | 0.56 | 0.44 | 1.00 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.22 | 0.00 | 0.22 |
| ...with the charger already in that arc before they moved (per game) | 0.56 | 0.33 | 0.89 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.11 | 0.22 | 0.33 |

### Quality by phase: h9-mine-81fb82c-p3

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.4 | 2.3 |
| Strategy | Charge objectives carried out (made contact) | 94% (16 of 17) | 62% (13 of 21) |
| Strategy | Shoot objectives carried out (shot that target) | 44% (48 of 108) | 43% (21 of 49) |
| Strategy | Support requests answered (helper made contact too) | 100% (1 of 1) | - |
| Strategy | Hexes on a unit its side charged or shot that turn | - | 50% (3 of 6) |
| Strategy | Joined characters whose unit fought | 23% (6 of 26) | 38% (5 of 13) |
| Strategy | Lone characters that fought | 33% (5 of 15) | 73% (11 of 15) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 2.0 | 1.2 |
| Movement | Points that never moved of their own | 184.8 | 63.9 |
| Movement | Fights charged into per game | 1.8 | 2.2 |
| Movement | Charges with odds: long shots (under 50%) | 5 of 16, net -21 | 1 of 16, net +0 |
| Movement | Charges with odds: sweet spot (55-75%) | 3 of 16, net +132 | 1 of 16, net +0 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 1 of 16, net +63 | 3 of 16, net +0 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 of 16, net +80 | 5 of 16, net +68 |
| Shooting | Shots by shooting units (incl. breath weapons) | 6.8 | 7.9 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 21% (13 of 61) | 48% (34 of 71) |
| Shooting | Points destroyed by shooting units | 42.4 | 28.6 |
| Shooting | War machine shots | 6.0 | 2.6 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 39% (21 of 54) | 61% (14 of 23) |
| Shooting | Points destroyed by war machines | 145.3 | 35.6 |
| Magic | Magic missiles cast | 1.8 | 1.4 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 31% (5 of 16) | 54% (7 of 13) |
| Magic | Wounds caused by magic missiles | 4.9 | 4.9 |
| Magic | Wounds caused by other spells | 0.4 | 0.7 |
| Magic | Points destroyed by magic (all spells) | 51.8 | 33.3 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.6 / 0.0 / 0.8 / 0.3 | 0.3 / 1.2 / 0.2 / 0.0 |
| Combat | Points destroyed in combat | 113.3 | 317.2 |
| Combat | Points run down | 55.1 | 37.7 |
| Combat | Net points per charged fight, damage counted | +62 | +116 |
| Combat | Net per 100 charger points, damage counted | +26.8 | +34.1 |
| Combat | First round won (charged fights) | 56% | 80% |
| Combat | Net points per charged fight | +55 | +118 |
| Combat | Net points per supported fight / lone fight | +199 / +45 | - / +118 |
| Combat | Charged fights on a top-3 enemy unit | 8 of 16 | 9 of 20 |
| Game | Points lost | 540.6 | 461.2 |
| Game | VP from objectives | 618.9 | 894.4 |
| Game | Lone holders (player turns) | 3.9 | 9.9 |

- Mine won / drew / lost: 1 / 3 / 5 of 9 ended games (of 9); mean margin (Mine - Opponent) -471 VP
- The side that went first won 2 of 6 games with a winner
- Points traded per game (both sides' losses): 1002
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: h9-mine-81fb82c-p3

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.4 | +0.0 | 0.0 | 0.0 | 0.8 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.1 | +66.5 | 0.0 | 34.4 | 0.2 | +40.5 | 0.0 | 0.0 |
| ALREADY CARRIED | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARRIVAL HUNT | - | - | - | - | 0.1 | +1.9 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 2.9 | +0.0 | 0.0 | 36.1 | 0.6 | +0.0 | 0.0 | 36.7 |
| BACKUP TARGETS | - | - | - | - | 0.3 | +0.8 | 0.0 | 0.0 |
| BEST PRIZE | - | - | - | - | 0.1 | -1.9 | 5.8 | 0.0 |
| BOMBING RUN | - | - | - | - | 0.2 | +5.7 | 0.0 | 16.7 |
| CANNON PLAN MISSED | 1.6 | +0.0 | 43.6 | 21.1 | 0.4 | +0.0 | 0.0 | 0.0 |
| CANNON PLANNED TARGET | 5.0 | +95.8 | 325.0 | 36.1 | 1.9 | +27.3 | 34.4 | 36.7 |
| CANNON SIGHT KEPT | 1.1 | +0.0 | 0.0 | 0.0 | 0.8 | +0.0 | 0.0 | 49.1 |
| CARRIES OUT COUNTER | - | - | - | - | 0.1 | +0.0 | 37.7 | 0.0 |
| CARRIES OUT SET-UP | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CAST JOB | 1.1 | +28.2 | 138.9 | 28.3 | 0.7 | +8.2 | 6.1 | 22.1 |
| CASTER AWAY FROM SCREEN | 0.4 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.8 | +46.3 | 0.0 | 0.0 | 0.2 | +1.2 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 0.8 | +0.0 | 0.0 | 39.4 | 0.4 | +0.0 | 0.0 | 43.9 |
| CHAFF IN THE MOVE | 0.6 | +31.2 | 0.0 | 25.0 | 0.2 | +16.3 | 0.0 | 0.0 |
| CHAFF PASSED | 0.2 | -0.4 | 0.0 | 0.0 | 0.1 | -0.1 | 0.0 | 0.0 |
| CHARACTER GUNS | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHARGE LOSSES | 6.2 | -353.7 | 0.0 | 89.9 | 5.2 | -188.6 | 0.0 | 130.9 |
| CHARGE NOT DECLARED | 0.1 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 72.1 | 0.0 |
| CHARGE NOW FIRST | 0.7 | +0.0 | 25.9 | 37.7 | 1.4 | +0.0 | 247.1 | 55.1 |
| CHARGER SLAIN LOST | - | - | - | - | 0.1 | -0.2 | 0.0 | 0.0 |
| COMBAT PIVOT | 0.1 | +0.0 | 0.0 | 34.4 | 0.2 | +0.0 | 0.0 | 25.6 |
| CONVEYANCE SEARCH | 1.3 | +219.4 | 0.0 | 78.9 | 0.1 | +4.2 | 0.0 | 0.0 |
| COVER ONCE | 4.8 | -400.8 | 0.0 | 40.0 | 4.6 | -164.1 | 0.0 | 137.1 |
| DEFENSIVE FLOOR | 0.2 | -5.7 | 0.0 | 9.0 | - | - | - | - |
| DEPLOY BY FIGURES | 7.8 | +52.5 | 0.0 | 16.7 | 6.7 | +15.2 | 0.0 | 0.0 |
| EDGE GIVE GROUND | 0.1 | +7.2 | 0.0 | 0.0 | - | - | - | - |
| ENGINEER BY LORE | 0.4 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FALL BACK GOOD ORDER | 1.2 | +0.7 | 11.6 | 47.1 | 1.9 | +2.9 | 259.3 | 39.7 |
| FALLBACK BY WORTH | 0.2 | +0.0 | 0.0 | 9.4 | 0.1 | +0.1 | 0.0 | 0.0 |
| FALLS SHORT | 3.8 | +105.8 | 0.0 | 27.4 | 18.6 | +348.9 | 0.0 | 241.0 |
| FEATURE BUFFS | 3.4 | +119.8 | 0.0 | 16.3 | 1.2 | +30.3 | 0.0 | 0.0 |
| FIGHT LIFT | 0.1 | +0.4 | 0.0 | 0.0 | - | - | - | - |
| FIGHT TO THE END | 0.9 | +57.2 | 35.2 | 37.7 | 1.2 | +291.0 | 202.2 | 39.7 |
| FIRE IN ORDER | 0.4 | +0.0 | 15.2 | 12.4 | 0.1 | +0.0 | 0.0 | 0.0 |
| FIVE ACTION | 44.0 | +2721.6 | 684.9 | 425.0 | 38.4 | +3619.9 | 326.0 | 645.6 |
| FLANK NOT WEIGHED | 3.6 | +0.0 | 0.0 | 27.0 | 5.7 | +0.0 | 0.0 | 98.6 |
| FOLLOW UP WEIGHED | 0.3 | +24.7 | 0.0 | 0.0 | 0.9 | +318.5 | 0.0 | 0.0 |
| FOUR ROUNDS | 1.9 | +254.4 | 68.9 | 65.6 | 2.3 | +629.7 | 259.3 | 39.7 |
| FRIEND CHARGES FIRST | 0.2 | -7.0 | 0.0 | 0.0 | - | - | - | - |
| FRIEND SHOOTS FIRST | 0.3 | -3.9 | 0.0 | 34.4 | 0.1 | -1.7 | 0.0 | 49.1 |
| FRIENDS SHOTS CHECKED | - | - | - | - | 0.1 | +5.9 | 0.0 | 0.0 |
| GIVES UP | 0.1 | -5.4 | 0.0 | 0.0 | 0.1 | -1.4 | 0.0 | 0.0 |
| GUN FIGURES | 0.8 | +11.8 | 12.8 | 34.4 | 0.1 | +6.1 | 7.2 | 0.0 |
| GUN MASK | 0.2 | +1.6 | 0.0 | 0.0 | 1.1 | +10.8 | 0.0 | 20.6 |
| HARD STAY DROPPED | 1.8 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| HE SHOOTS OR CHARGES | 2.0 | +0.0 | 0.0 | 41.7 | 2.3 | +0.0 | 0.0 | 76.2 |
| HIS CHARGE DENIED | 0.2 | +11.3 | 0.0 | 37.7 | 0.3 | +8.7 | 64.4 | 0.0 |
| HIS CHARGE LIST | 1.8 | +0.0 | 0.0 | 7.2 | 1.1 | +0.0 | 0.0 | 25.6 |
| HIS LEGAL MOVES | 3.0 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 44.4 |
| HIS MOVE AND SHOT | 2.7 | -24.2 | 0.0 | 43.9 | 1.0 | -36.1 | 0.0 | 72.1 |
| HIS ONE QUARTER | 1.6 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS RANDOM MOVE | 0.9 | +0.0 | 0.0 | 46.9 | 1.4 | +0.0 | 0.0 | 67.7 |
| HIS SHOT LIST | 19.0 | +525.5 | 0.0 | 174.2 | 18.9 | +1274.9 | 0.0 | 400.2 |
| HIS TURN DENIED | 0.7 | +18.7 | 38.4 | 0.0 | 1.1 | +59.0 | 157.2 | 6.7 |
| HOLD ODDS | 15.0 | +0.0 | 0.0 | 53.0 | - | - | - | - |
| HOLDER ASSIGNMENT | 14.9 | +1582.2 | 0.0 | 48.4 | - | - | - | - |
| HOLDER AT DEPLOYMENT | - | - | - | - | 1.3 | +192.8 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 1.2 | -33.8 | 68.9 | 0.0 | 2.1 | -86.9 | 157.2 | 39.7 |
| IDLE COST | 2.2 | -15.0 | 0.0 | 6.1 | 10.2 | -171.6 | 0.0 | 303.7 |
| KEEP FALLS | 0.2 | +3.3 | 0.0 | 0.0 | - | - | - | - |
| LANE BY FIGURES | 0.3 | +11.7 | 0.0 | 0.0 | 0.6 | +18.7 | 0.0 | 49.1 |
| LATE ONLY FROM HERE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| LEGAL CHARGES ONLY | 5.0 | +0.0 | 131.3 | 656.6 | 2.1 | +0.0 | 208.6 | 146.7 |
| LONE WIZARD KEPT IN | 1.1 | +94.1 | 0.0 | 10.6 | 0.2 | +23.8 | 0.0 | 0.0 |
| LONG SHOT | 0.2 | -0.2 | 0.0 | 9.0 | - | - | - | - |
| LURE BY WHAT IT DRAWS | 0.1 | -2.6 | 0.0 | 0.0 | - | - | - | - |
| MAKE SURE TOGETHER | 0.4 | +12.4 | 0.0 | 0.0 | 0.4 | +3.3 | 0.0 | 33.0 |
| MANOEUVRE | 1.7 | +5.0 | 0.0 | 0.0 | 0.8 | +9.6 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.1 | +6.5 | 0.0 | 0.0 | - | - | - | - |
| MARCH BY THE SUM | 0.2 | +12.2 | 0.0 | 0.0 | 0.9 | +25.1 | 0.0 | 25.9 |
| MARCH CHECK | 0.8 | +23.9 | 0.0 | 0.0 | 2.4 | +152.2 | 0.0 | 25.9 |
| MARCH OVER CASTS | 0.4 | +2.4 | 0.0 | 0.0 | 1.3 | +30.5 | 0.0 | 48.0 |
| MARCH WHEELS ONLY | 0.8 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MAX FOR POSITIONING | 4.3 | +72.3 | 0.0 | 108.4 | 4.6 | +40.0 | 0.0 | 89.1 |
| MISSILES IN THE MOVE | 6.2 | +288.0 | 0.0 | 37.3 | 5.0 | +59.1 | 0.0 | 44.2 |
| MISSILES NEXT TURN | 6.0 | +197.5 | 0.0 | 27.9 | 5.8 | +48.3 | 0.0 | 136.9 |
| MOVE SPELL OUT OF RANGE | 0.2 | -45.9 | 0.0 | 78.9 | - | - | - | - |
| MOVE SPELL SPOT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 2.2 | +270.1 | 0.0 | 72.1 | 3.8 | +657.5 | 0.0 | 135.1 |
| MOVES UNITS SPELL | 0.2 | +12.2 | 0.0 | 0.0 | 0.1 | +0.8 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 7.0 | +317.4 | 0.0 | 19.7 | 2.9 | +193.2 | 0.0 | 16.3 |
| NEXT CHARGE BY LIST | 4.1 | -100.5 | 22.2 | 91.8 | 4.7 | -150.7 | 0.0 | 170.0 |
| NEXT OBJECTIVE NEARER | - | - | - | - | 7.4 | -361.6 | 0.0 | 101.6 |
| NO DOUBLE ROUNDS | 1.8 | -90.1 | 46.8 | 65.6 | 1.9 | -168.1 | 209.4 | 39.7 |
| NO RALLY LEFT | 0.2 | +29.1 | 0.0 | 0.0 | - | - | - | - |
| NOT TURNED | 0.1 | +0.0 | 0.0 | 9.4 | 0.2 | +0.0 | 0.0 | 3.3 |
| NOT WORTH A CAST | 0.2 | -0.4 | 0.0 | 78.9 | 0.3 | -0.5 | 0.0 | 0.0 |
| OFF BEST | 0.2 | -0.5 | 0.0 | 0.0 | - | - | - | - |
| ONE CHARGE A CHARGER | 2.7 | +0.0 | 0.0 | 7.2 | 1.4 | +0.0 | 0.0 | 63.7 |
| ONE FIGHT FORMULA | 4.3 | -88.1 | 0.0 | 99.0 | 4.6 | -152.6 | 0.0 | 142.9 |
| ONE OBJECTIVE FORMULA | 8.8 | +103.5 | 0.0 | 41.2 | 5.9 | -25.9 | 0.0 | 76.9 |
| ONE ROUTE | 0.8 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ONE TARGET A SHOOTER | 15.1 | +262.2 | 0.0 | 110.2 | 15.7 | +370.8 | 0.0 | 274.6 |
| OPENS A LANE | 0.1 | +1.3 | 0.0 | 0.0 | - | - | - | - |
| OPENS UP | 0.1 | +7.8 | 7.0 | 0.0 | 0.1 | +8.3 | 7.2 | 0.0 |
| OVERRUNS AWAY | 0.2 | +0.8 | 16.3 | 0.0 | 0.2 | +10.1 | 0.0 | 6.7 |
| PATHS CROSS | 2.7 | +247.2 | 0.0 | 85.9 | 3.9 | +224.9 | 0.0 | 44.4 |
| PIVOT GUARDS FLANK | 0.2 | -19.5 | 0.0 | 37.7 | 0.1 | -15.7 | 0.0 | 0.0 |
| PLAN RESULT | 38.7 | +818.9 | 423.3 | 715.0 | 33.2 | +369.8 | 258.9 | 709.9 |
| QUARTER ODDS | 4.9 | +510.3 | 22.1 | 0.0 | - | - | - | - |
| RANDOM MOVE BY FIGURES | 0.9 | +33.7 | 0.0 | 56.7 | 0.3 | +0.0 | 0.0 | 37.8 |
| REAL GROUND | 0.8 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| REDIRECT BY WHAT IT STOPS | 0.6 | -21.0 | 0.0 | 25.0 | 0.1 | -3.8 | 0.0 | 0.0 |
| REDIRECT COUNTER | 2.2 | +169.6 | 0.0 | 24.9 | 3.9 | +43.2 | 0.0 | 58.4 |
| REDIRECT WEIGHED | - | - | - | - | 0.1 | -1.9 | 5.8 | 0.0 |
| REFORMS TO MEET IT | 1.0 | -32.8 | 0.0 | 0.0 | 0.7 | -35.1 | 0.0 | 7.6 |
| RESERVE FALL BACK | 0.2 | +1.8 | 0.0 | 0.0 | 0.1 | +9.8 | 0.0 | 0.0 |
| RISK BY ARC | 1.4 | +37.5 | 46.8 | 56.1 | 1.6 | +13.1 | 209.4 | 33.0 |
| RISK BY HIS FIGURE | 11.3 | -299.1 | 0.0 | 116.0 | 11.2 | -106.4 | 0.0 | 297.0 |
| RISK ON THE WAY | 0.2 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| RUN DOWN | 1.4 | -13.9 | 50.0 | 37.7 | 1.7 | -12.5 | 57.1 | 39.7 |
| SAME CHARGE LATER | - | - | - | - | 0.2 | -3.3 | 0.0 | 0.0 |
| SCOUT SPOT | 0.2 | +0.3 | 0.0 | 0.0 | 0.2 | -0.0 | 0.0 | 0.0 |
| SCOUT WAITS | 0.2 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 0.2 | -16.1 | 0.0 | 3.3 |
| SEARCH SPOT | 5.8 | +250.3 | 0.0 | 69.1 | 6.4 | +207.7 | 0.0 | 180.6 |
| SELF MOVE SPELL | - | - | - | - | 0.7 | +117.4 | 0.0 | 87.8 |
| SET UP TOGETHER | 0.4 | +12.4 | 0.0 | 0.0 | 0.6 | +3.4 | 0.0 | 33.0 |
| SET-UP ANY TARGET | 0.1 | +23.6 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | 0.2 | +0.4 | 0.0 | 0.0 | 0.2 | +0.2 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.6 | +51.0 | 3.3 | 0.0 | 0.7 | +7.2 | 0.0 | 0.0 |
| SHOT OR CHARGE | 0.1 | -4.2 | 0.0 | 0.0 | 0.1 | -0.8 | 0.0 | 0.0 |
| SHOT RISK POINTS | 10.1 | +89.7 | 0.0 | 110.4 | 11.6 | -37.5 | 0.0 | 300.2 |
| SHOTS IN THE MOVE | 13.1 | +592.9 | 0.0 | 166.9 | 11.1 | +260.8 | 0.0 | 161.8 |
| SPELL SETS UP CHARGE | 0.7 | +446.8 | 0.0 | 0.0 | - | - | - | - |
| SPELL WORTH | 0.2 | +7.7 | 0.0 | 0.0 | 0.7 | +6.7 | 88.9 | 88.9 |
| SPELLS IN THE FIGHT | 0.1 | +5.6 | 0.0 | 0.0 | 0.3 | -3.0 | 71.7 | 0.0 |
| STAND AND SHOOT | 0.4 | -3.2 | 16.3 | 0.0 | 0.3 | -4.2 | 7.2 | 6.7 |
| STANDS FOR A REASON | - | - | - | - | 0.8 | +0.0 | 0.0 | 44.4 |
| STANDS STILL | 19.6 | +0.0 | 616.0 | 156.1 | 7.8 | +0.0 | 66.7 | 96.6 |
| STAY WORTH | 18.9 | +105.5 | 553.3 | 169.7 | 13.2 | +138.8 | 66.7 | 207.4 |
| SUPPORT NARROWED | 0.4 | +0.0 | 4.6 | 0.0 | 0.7 | +0.0 | 133.3 | 22.1 |
| SURE REACH TOGETHER | 0.1 | +3.2 | 0.0 | 0.0 | 0.6 | +3.4 | 0.0 | 48.2 |
| THE DEARER SUM KEEPS ITS PLAN | 2.8 | +0.0 | 0.0 | 73.4 | 4.1 | +0.0 | 0.0 | 44.4 |
| THE PROMISED MOVE | 0.7 | +0.0 | 0.0 | 37.7 | - | - | - | - |
| TIED UP BY THE SUM | 0.2 | +12.0 | 11.6 | 0.0 | 0.6 | +55.1 | 7.2 | 0.0 |
| TIME ON OUR SIDE | 28.8 | +474.8 | 3.3 | 190.9 | 4.4 | +101.4 | 0.0 | 101.1 |
| WAITS AGAIN | 0.7 | +0.0 | 0.0 | 34.4 | 1.2 | +0.0 | 0.0 | 32.7 |
| WAR ENGINE JOBS | 0.3 | +0.0 | 43.2 | 0.0 | - | - | - | - |
| WHO HITS BACK | 0.1 | +1.6 | 0.0 | 0.0 | 0.1 | +8.0 | 0.0 | 0.0 |
| WHOLE FIGHT | 0.1 | +7.9 | 0.0 | 0.0 | 0.1 | +20.2 | 37.7 | 0.0 |
| WHOLE FIGHT GAIN | 0.1 | +9.2 | 22.1 | 0.0 | - | - | - | - |
| WIDER SPREAD | 1.0 | +0.3 | 61.9 | 0.0 | 2.0 | -10.8 | 259.3 | 39.7 |
| WOUNDS ON THE RANKS | 1.8 | +73.6 | 0.0 | 0.0 | 1.8 | +48.7 | 0.0 | 22.0 |

### Rule changes: h9-mine-81fb82c-p3

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HOLDER ASSIGNMENT | 134 | 134 | 125 | 13.89 | +7257 | +58.1 |
| SEARCH SPOT | 110 | 110 | 101 | 11.22 | +4124 | +40.8 |
| HIS SHOT LIST | 341 | 341 | 89 | 9.89 | +2424 | +27.2 |
| DEPLOY BY FIGURES | 130 | 130 | 77 | 8.56 | +1060 | +13.8 |
| LEGAL CHARGES ONLY | 64 | 64 | 64 | 7.11 | +0 | +0.0 |
| TIME ON OUR SIDE | 299 | 267 | 60 | 6.67 | +252 | +4.2 |
| PATHS CROSS | 59 | 59 | 59 | 6.56 | +4249 | +72.0 |
| ONE TARGET A SHOOTER | 277 | 277 | 57 | 6.33 | +321 | +5.6 |
| FIVE ACTION | 742 | 742 | 49 | 5.44 | +2391 | +48.8 |
| MOVE TO CHARGE COMPUTED | 54 | 54 | 35 | 3.89 | +3120 | +89.1 |
| ARTILLERY RE-ROLL WEIGHED | 31 | 31 | 31 | 3.44 | +0 | +0.0 |
| SHOT RISK POINTS | 195 | 195 | 28 | 3.11 | +663 | +23.7 |
| FOUR ROUNDS | 38 | 38 | 23 | 2.56 | +3244 | +141.0 |
| MARCH CHECK | 29 | 29 | 22 | 2.44 | +331 | +15.0 |
| HARD STAY DROPPED | 18 | 18 | 18 | 2.00 | +0 | +0.0 |
| CANNON SIGHT KEPT | 17 | 17 | 17 | 1.89 | +0 | +0.0 |
| CANNON PLANNED TARGET | 62 | 62 | 15 | 1.67 | -114 | -7.6 |
| MISSILES IN THE MOVE | 101 | 84 | 14 | 1.56 | +375 | +26.8 |
| ONE OBJECTIVE FORMULA | 132 | 110 | 14 | 1.56 | +529 | +37.8 |
| REDIRECT COUNTER | 55 | 46 | 14 | 1.56 | +828 | +59.1 |
| NEARER NOT NEEDED | 89 | 84 | 13 | 1.44 | +326 | +25.1 |
| NEXT CHARGE BY LIST | 79 | 79 | 13 | 1.44 | +456 | +35.1 |
| LONE WIZARD KEPT IN | 12 | 12 | 12 | 1.33 | +1060 | +88.4 |
| MAX FOR POSITIONING | 80 | 80 | 12 | 1.33 | +19 | +1.6 |
| SHOTS IN THE MOVE | 218 | 194 | 12 | 1.33 | +223 | +18.6 |
| ADVANCE LANE KEPT | 11 | 11 | 11 | 1.22 | +0 | +0.0 |
| COVER ONCE | 84 | 64 | 11 | 1.22 | +162 | +14.7 |
| FOLLOW UP WEIGHED | 11 | 11 | 11 | 1.22 | +3090 | +280.9 |
| IDLE COST | 112 | 91 | 11 | 1.22 | +136 | +12.4 |
| STAY WORTH | 289 | 269 | 11 | 1.22 | +93 | +8.4 |
| FALLS SHORT | 201 | 175 | 10 | 1.11 | +80 | +8.0 |
| MARCH BY THE SUM | 10 | 10 | 10 | 1.11 | +336 | +33.6 |
| SHOOTS FROM THE BEST SPOT | 20 | 20 | 10 | 1.11 | +104 | +10.4 |
| CHARGE LOSSES | 103 | 103 | 9 | 1.00 | +238 | +26.4 |
| FEATURE BUFFS | 42 | 42 | 9 | 1.00 | +207 | +23.0 |
| RISK BY ARC | 27 | 27 | 9 | 1.00 | +194 | +21.5 |
| CASTING BLOCK | 9 | 9 | 8 | 0.89 | +90 | +11.2 |
| LANE BY FIGURES | 8 | 8 | 8 | 0.89 | +273 | +34.1 |
| MANOEUVRE | 22 | 22 | 8 | 0.89 | +179 | +22.3 |
| NEXT OBJECTIVE NEARER | 67 | 67 | 8 | 0.89 | +237 | +29.6 |
| CAST JOB | 16 | 16 | 7 | 0.78 | +29 | +4.1 |
| CHARGE NOW FIRST | 19 | 19 | 7 | 0.78 | -198 | -28.2 |
| HOLDER AT DEPLOYMENT | 12 | 12 | 7 | 0.78 | +150 | +21.4 |
| HOLDS AMBUSHERS | 7 | 7 | 7 | 0.78 | +0 | +0.0 |
| RISK BY HIS FIGURE | 203 | 203 | 7 | 0.78 | +420 | +60.0 |
| TIED UP BY THE SUM | 7 | 7 | 7 | 0.78 | +201 | +28.7 |
| FIGHT TO THE END | 19 | 19 | 6 | 0.67 | +1059 | +176.5 |
| QUARTER ODDS | 44 | 44 | 6 | 0.67 | +575 | +95.9 |
| CASTER AWAY FROM SCREEN | 5 | 5 | 5 | 0.56 | +0 | +0.0 |
| CHAFF IN THE MOVE | 7 | 7 | 5 | 0.56 | +0 | +0.0 |
| CHARGE NOT DECLARED | 5 | 5 | 5 | 0.56 | -963 | -192.5 |
| FIRE IN ORDER | 5 | 5 | 5 | 0.56 | +0 | +0.0 |
| ONE FIGHT FORMULA | 80 | 49 | 5 | 0.56 | +94 | +18.8 |
| RANDOM MOVE BY FIGURES | 11 | 11 | 5 | 0.56 | +303 | +60.7 |
| SCOUT WAITS | 5 | 5 | 5 | 0.56 | +0 | +0.0 |
| SHOOTERS IN TWO RANKS | 4 | 4 | 4 | 0.44 | +6 | +1.5 |
| WOUNDS ON THE RANKS | 32 | 32 | 4 | 0.44 | +151 | +37.8 |
| AFTERMATH IN POINTS | 3 | 3 | 3 | 0.33 | +963 | +321.1 |
| CHAFF PASSED | 3 | 3 | 3 | 0.33 | -4 | -1.5 |
| COMBAT PIVOT | 3 | 3 | 3 | 0.33 | +0 | +0.0 |
| HIS TURN DENIED | 16 | 16 | 3 | 0.33 | +67 | +22.3 |
| MOVES UNITS SPELL | 3 | 3 | 3 | 0.33 | +118 | +39.2 |
| PIVOT GUARDS FLANK | 3 | 3 | 3 | 0.33 | -317 | -105.8 |
| RESERVE FALL BACK | 3 | 3 | 3 | 0.33 | +104 | +34.8 |
| SURE REACH TOGETHER | 6 | 6 | 3 | 0.33 | +2 | +0.8 |
| BOMBING RUN | 2 | 2 | 2 | 0.22 | +51 | +25.6 |
| GUN MASK | 12 | 12 | 2 | 0.22 | +56 | +28.1 |
| HIS MOVE AND SHOT | 33 | 33 | 2 | 0.22 | +5 | +2.6 |
| KEEP FALLS | 2 | 2 | 2 | 0.22 | +63 | +31.5 |
| NO RALLY LEFT | 2 | 2 | 2 | 0.22 | +233 | +116.4 |
| OFF BEST | 2 | 2 | 2 | 0.22 | -4 | -2.2 |
| OPENS UP | 2 | 2 | 2 | 0.22 | +62 | +30.8 |
| WHO HITS BACK | 2 | 2 | 2 | 0.22 | +26 | +12.9 |
| BEST PRIZE | 1 | 1 | 1 | 0.11 | -31 | -31.0 |
| DEFENSIVE FLOOR | 2 | 2 | 1 | 0.11 | +9 | +9.2 |
| FALLBACK BY WORTH | 3 | 3 | 1 | 0.11 | +1 | +1.2 |
| FRIENDS SHOTS CHECKED | 1 | 1 | 1 | 0.11 | +53 | +53.2 |
| HIS CHARGE DENIED | 5 | 5 | 1 | 0.11 | +40 | +39.6 |
| HONEST WORTH | 30 | 30 | 1 | 0.11 | +0 | +0.4 |
| NO DOUBLE ROUNDS | 33 | 33 | 1 | 0.11 | +2 | +2.4 |
| OVERRUNS AWAY | 4 | 4 | 1 | 0.11 | +31 | +31.3 |
| REDIRECT WEIGHED | 1 | 1 | 1 | 0.11 | -31 | -31.0 |
| REFORMS TO MEET IT | 15 | 15 | 1 | 0.11 | +8 | +8.3 |
| RUN DOWN | 28 | 28 | 1 | 0.11 | +2 | +2.4 |
| SAME CHARGE LATER | 2 | 2 | 1 | 0.11 | +0 | +0.0 |
| SET UP TOGETHER | 9 | 5 | 1 | 0.11 | +36 | +36.1 |
| SUPPORT NARROWED | 10 | 10 | 1 | 0.11 | -7 | -6.9 |
| WHOLE FIGHT | 2 | 2 | 1 | 0.11 | +34 | +33.9 |
| WIDER SPREAD | 27 | 27 | 1 | 0.11 | +0 | +0.4 |
| ALREADY CARRIED | 1 | not checked | - | - | - | - |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| BACKUP TARGETS | 3 | 1 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 18 | 18 | 0 | 0.00 | - | - |
| CARRIES OUT COUNTER | 1 | 1 | 0 | 0.00 | - | - |
| CARRIES OUT SET-UP | 1 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 11 | trace | - | - | - | - |
| CHARACTER GUNS | 1 | 1 | 0 | 0.00 | - | - |
| CHARGER SLAIN LOST | 1 | 1 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 13 | not checked | - | - | - | - |
| EDGE GIVE GROUND | 1 | 1 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 28 | 28 | 0 | 0.00 | - | - |
| FIGHT LIFT | 1 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 83 | not checked | - | - | - | - |
| FRIEND CHARGES FIRST | 2 | 2 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 4 | 4 | 0 | 0.00 | - | - |
| GIVES UP | 2 | 2 | 0 | 0.00 | - | - |
| GUN FIGURES | 8 | not checked | - | - | - | - |
| HE SHOOTS OR CHARGES | 39 | 39 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 26 | 26 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 54 | 54 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 14 | 14 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 21 | 21 | 0 | 0.00 | - | - |
| HOLD ODDS | 135 | 135 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 1 | 1 | 0 | 0.00 | - | - |
| LONG SHOT | 2 | 2 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 1 | 1 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 8 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 16 | 16 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 7 | 7 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 106 | 82 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 2 | trace | - | - | - | - |
| MOVE SPELL SPOT | 3 | not checked | - | - | - | - |
| NOT TURNED | 3 | 3 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 5 | not checked | - | - | - | - |
| ONE CHARGE A CHARGER | 37 | 37 | 0 | 0.00 | - | - |
| ONE ROUTE | 7 | 7 | 0 | 0.00 | - | - |
| OPENS A LANE | 1 | 1 | 0 | 0.00 | - | - |
| PLAN RESULT | 647 | trace | - | - | - | - |
| REAL GROUND | 7 | 7 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 6 | 6 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 2 | 2 | 0 | 0.00 | - | - |
| SCOUT SPOT | 4 | 4 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 2 | 2 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 6 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 1 | not checked | - | - | - | - |
| SHOT OR CHARGE | 2 | 2 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 6 | not checked | - | - | - | - |
| SPELL WORTH | 8 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 4 | 4 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 7 | 7 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 7 | 7 | 0 | 0.00 | - | - |
| STANDS STILL | 246 | 246 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 62 | not checked | - | - | - | - |
| THE PROMISED MOVE | 6 | not checked | - | - | - | - |
| WAITS AGAIN | 17 | 17 | 0 | 0.00 | - | - |
| WAR ENGINE JOBS | 3 | 3 | 0 | 0.00 | - | - |
| WHOLE FIGHT GAIN | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: h9-mine-81fb82c-p3

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| CHARGE NOW FIRST | rule | 0.22 | 0.56 | 28.2 |
| PATHS CROSS | rule | 0.11 | 0.67 | 42.1 |
| HOLDER ASSIGNMENT | rule | 0.67 | - | 24.1 |
| CHARGE NOT DECLARED | rule | 0.11 | 0.44 | 192.5 |
| PIVOT GUARDS FLANK | rule | 0.22 | 0.11 | 105.8 |
| CANNON PLANNED TARGET | rule | 0.11 | 0.11 | 83.5 |
| CHAFF PASSED | rule | 0.11 | 0.11 | 2.2 |
| BEST PRIZE | rule | - | 0.11 | 31.0 |
| DEPLOY BY FIGURES | rule | - | 0.11 | 4.7 |
| FIGHT ORDER BAND | gate | 0.11 | - | 1.8 |
| JOB FIRST | gate | 0.11 | - | 2.5 |
| REDIRECT WEIGHED | rule | - | 0.11 | 31.0 |
| SUPPORT NARROWED | rule | - | 0.11 | 6.9 |

### Plans: h9-mine-81fb82c-p3

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.7 | 53% | 243 | 125 | 51% |
| Mine | join | 0.1 | 100% | 4 | 0 | 0% |
| Mine | move | 26.2 | 96% | 1666 | 0 | 0% |
| Mine | shoot | 10.1 | 75% | 488 | 694 | 142% |
| Mine | support | 0.6 | 80% | 5 | 0 | 0% |
| Opponent | charge | 1.8 | 44% | 708 | 236 | 33% |
| Opponent | move | 26.7 | 93% | 2244 | 0 | 0% |
| Opponent | shoot | 4.4 | 48% | 190 | 134 | 70% |
| Opponent | support | 0.3 | 67% | 0 | 0 | - |

### Battle groups: h9-mine-81fb82c-p3

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 2.2 | 25% | 40% | 20% | 100% | 50% | 0% | 0% | 50% | 0% |
| Opponent | REDIRECT COUNTER | 3.9 | 11% | 50% | 25% | 0% | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: h9-mine-81fb82c-p3

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 8 | 21 (8) | 16 | 5 | 42 | 50% | 2.5 | 30 (4) | 20 (2) | 0 (2) | 24 (7) | 0 (1) |
| Mine | Character | 33 | 19 (33) | 19 | 0 | 31 | 36% | 1.8 | 0 (6) | 25 (22) | 0 (1) | 25 (17) | 15 (12) |
| Mine | Clean-up | 7 | 53 (7) | 5 | 49 | 12 | 57% | 3.3 | 38 (1) | 94 (3) | 0 (3) | 83 (4) | 0 (3) |
| Mine | Fast Hammer | 4 | 0 (4) | 0 | 0 | 100 | 25% | 3.3 | 0 (1) | - | 0 (3) | 0 (3) | 0 (1) |
| Mine | Hammer | 22 | 23 (22) | 12 | 11 | 29 | 36% | 2.1 | 18 (8) | 27 (12) | 0 (2) | 32 (14) | 11 (8) |
| Mine | Holder | 13 | 113 (13) | 37 | 76 | 9 | 62% | 4.2 | 160 (3) | 8 (4) | 155 (6) | 138 (10) | 0 (3) |
| Mine | Shooter | 5 | 126 (5) | 0 | 126 | 26 | 20% | 1.8 | 46 (1) | 163 (3) | 0 (1) | 145 (4) | 0 (1) |
| Mine | War machine | 13 | 79 (13) | 79 | 0 | 26 | 0% | 1.0 | 201 (2) | 79 (7) | 9 (4) | 78 (3) | 79 (10) |
| Mine | Wizard | 8 | 20 (8) | 20 | 0 | 22 | 62% | 3.3 | - | 20 (8) | - | 0 (2) | 27 (6) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Chaff | 13 | 148 (13) | 0 | 148 | 23 | 54% | 3.5 | 209 (3) | 191 (5) | 76 (5) | 172 (11) | 0 (2) |
| Opponent | Character | 25 | 49 (25) | 46 | 3 | 24 | 32% | 2.0 | 65 (7) | 36 (14) | 63 (4) | 45 (15) | 55 (10) |
| Opponent | Clean-up | 2 | 61 (2) | 0 | 61 | 0 | 0% | 1.5 | 70 (1) | - | 53 (1) | 70 (1) | 53 (1) |
| Opponent | Fast | 1 | 0 (1) | 0 | 0 | 100 | 0% | 3.0 | 0 (1) | - | - | 0 (1) | - |
| Opponent | Fast Hammer | 18 | 54 (18) | 6 | 48 | 26 | 56% | 1.9 | 44 (4) | 51 (10) | 74 (4) | 64 (12) | 26 (6) |
| Opponent | Hammer | 9 | 28 (9) | 11 | 17 | 48 | 11% | 3.0 | - | 38 (4) | 19 (5) | 22 (5) | 33 (4) |
| Opponent | Holder | 3 | 47 (3) | 0 | 47 | 0 | 100% | - | - | 47 (3) | - | - | 47 (3) |
| Opponent | Shooter | 7 | 110 (7) | 9 | 101 | 16 | 0% | 2.0 | 154 (2) | 126 (4) | 0 (1) | 95 (6) | 247 (1) |
| Opponent | War machine | 6 | 32 (6) | 32 | 0 | 21 | 0% | 1.3 | 0 (1) | 0 (4) | 155 (1) | - | 32 (6) |
| Opponent | Wizard | 3 | 16 (3) | 16 | 0 | 0 | 0% | 4.7 | 89 (1) | 0 (1) | 12 (1) | 16 (3) | - |

### Charged fights: h9-mine-81fb82c-p3

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 79 | 105 | 1.5 | 1.0 | 70 | 42 | +28 | 3 of 6 | 3 of 6 | - | +28 |
| Mine | Chaos Dwarfs | 4 | 383 | 207 | 2.5 | 1.2 | 83 | 12 | +70 | 5 of 10 | 6 of 10 | +199 | +56 |
| Mine | Dwarfen Mountain Holds | 1 | 308 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| **Mine** | all armies | 9 | 240 | 139 | 1.8 | 1.1 | 78 | 23 | +55 | 8 of 16 | 9 of 16 | +199 | +45 |
| Opponent | Grand Cathay | 2 | 262 | 178 | 2.0 | 1.0 | 89 | 0 | +89 | 2 of 4 | 4 of 4 | - | +89 |
| Opponent | High Elf Realms | 2 | 42 | 155 | 2.5 | 1.0 | 62 | 59 | +3 | 2 of 5 | 3 of 5 | - | +3 |
| Opponent | Ogre Kingdoms | 1 | 182 | 0 | 1.0 | 1.0 | 0 | 34 | -34 | 0 of 1 | 0 of 1 | - | -34 |
| Opponent | Warriors of Chaos | 4 | 21 | 547 | 2.5 | 1.0 | 219 | 17 | +202 | 5 of 10 | 9 of 10 | - | +202 |
| **Opponent** | all armies | 9 | 97 | 317 | 2.2 | 1.0 | 143 | 25 | +118 | 9 of 20 | 16 of 20 | - | +118 |

### Effective charges: h9-mine-81fb82c-p3

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 6 | 4 (net -26) | 0 | 0 | 1 (net +233) | 0 | 1 (net +41) | 0 | 0% (0 of 6) |
| Mine | Chaos Dwarfs | 10 | 1 (net +0) | 0 | 3 (net +132) | 3 (net +15) | 1 (net +63) | 2 (net +100) | 0 | 30% (3 of 10) |
| Opponent | Grand Cathay | 4 | 0 | 0 | 0 | 1 (net +355) | 2 (net +0) | 1 (net +0) | 0 | 0% (0 of 4) |
| Opponent | High Elf Realms | 5 | 0 | 0 | 1 (net +0) | 2 (net +6) | 0 | 1 (net +0) | 1 | 25% (1 of 4) |
| Opponent | Warriors of Chaos | 10 | 1 (net +0) | 0 | 0 | 3 (net +523) | 1 (net +0) | 3 (net +113) | 2 | 0% (0 of 8) |

### Charged fights, damage counted: h9-mine-81fb82c-p3

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 5 | 80 | 402 | -21 | 39 | 63 | -24 | -30.1 |
| Mine | Effective (55-75%) | 3 | 295 | 340 | +132 | 132 | 0 | +132 | +44.7 |
| Mine | 76-89% | 4 | 276 | 232 | +70 | 122 | 36 | +86 | +31.2 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 | 317 | 139 | +80 | 102 | 0 | +102 | +32.0 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 339 | 63 | +63 | 63 | 0 | +63 | +18.6 |
| Mine | All fights | 16 | 230 | 277 | +55 | 90 | 29 | +62 | +26.8 |
| Opponent | Long shot (under 50%) | 1 | 30 | 65 | +0 | 0 | 15 | -15 | -50.0 |
| Opponent | Effective (55-75%) | 1 | 60 | 112 | +0 | 0 | 40 | -40 | -66.7 |
| Opponent | 76-89% | 6 | 427 | 304 | +323 | 402 | 111 | +291 | +68.2 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 5 | 398 | 269 | +68 | 108 | 14 | +94 | +23.7 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 3 | 409 | 85 | +0 | 39 | 18 | +20 | +5.0 |
| Opponent | No odds | 4 | 238 | 94 | +19 | 39 | 14 | +25 | +10.4 |
| Opponent | All fights | 20 | 341 | 199 | +118 | 161 | 45 | +116 | +34.1 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| h9-mine-81fb82c-p3 | move | 52 | 11 (21%) | 11 (21%) | 5 (10%) | 36 (69%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0111, L0128 |
| Elixir of Power | Opponent | L0111, L0211 |
| Fistful of Laurels | Opponent | L0518 |
| Ring of Doom | Mine | L0211, L0228 |
| Ring of Doom | Opponent | L0111, L0211, L0415 |
| Ring of Jet | Opponent | L0111, L0211 |
| Standard of the Fell Warrior | Opponent | L0313 |

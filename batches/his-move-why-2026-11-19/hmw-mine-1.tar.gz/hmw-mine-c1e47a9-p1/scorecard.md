# Doctrine scorecard: hmw-mine-c1e47a9-p1

### Scorecard: hmw-mine-c1e47a9-p1

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0102 | 6 | 1 | Mine | no | 6 | - | 0 | 1 | 0 | 0 | 0 | 322 |
| L0102 | 6 | 1 | Opponent | no | 2 | 2 | 0 | 3 | 0 | 0 | 0 | 30 |
| L0118 | 4 | 1 | Mine | no | 0 | 2 | 0 | 1 | 0 | 0 | 0 | 322 |
| L0118 | 4 | 1 | Opponent | no | 1 | 3 | 3 | 4 | 0 | 0 | 0 | 225 |
| L0135 | 3 | 1 | Mine | no | 6 | - | 0 | 3 | 0 | 0 | 0 | 55 |
| L0135 | 3 | 1 | Opponent | no | 0 | 3 | 3 | 3 | 0 | 0 | 0 | 0 |
| L0218 | 2 | 1 | Mine | - | - | 2 | 2 | 4 | 0 | 0 | 0 | 307 |
| L0218 | 2 | 1 | Opponent | - | - | 2 | 0 | 3 | 0 | 0 | 0 | 0 |
| L0235 | 1 | 1 | Mine | no | 2 | 2 | 2 | 2 | 1 | 0 | 0 | 0 |
| L0235 | 1 | 1 | Opponent | no | 12 | 2 | 2 | 3 | 0 | 0 | 0 | 0 |
| L0319 | 1 | 1 | Mine | no | 1 | 6 | 1 | 1 | 0 | 0 | 0 | 540 |
| L0319 | 1 | 1 | Opponent | no | 1 | 2 | 4 | 2 | 0 | 0 | 0 | 0 |
| L0405 | 3 | 1 | Mine | yes | 1 | 2 | 3 | 2 | 1 | 0 | 0 | 0 |
| L0405 | 3 | 1 | Opponent | no | 0 | - | 1 | 1 | 0 | 0 | 0 | 1193 |
| L0421 | 1 | 1 | Mine | no | 5 | 1 | 4 | 1 | 0 | 0 | 0 | 65 |
| L0421 | 1 | 1 | Opponent | no | 4 | - | 0 | 5 | 0 | 0 | 0 | 355 |
| L0508 | 4 | 1 | Mine | no | 9 | - | 0 | 3 | 0 | 0 | 0 | 285 |
| L0508 | 4 | 1 | Opponent | no | 0 | - | 0 | 3 | 0 | 0 | 0 | 971 |
| L0524 | 2 | 1 | Mine | - | - | 4 | 1 | 0 | 0 | 0 | 0 | 371 |
| L0524 | 2 | 1 | Opponent | - | - | 4 | 1 | 3 | 1 | 0 | 0 | 0 |
| L0612 | 6 | 1 | Mine | no | 9 | - | 0 | 3 | 0 | 0 | 0 | 443 |
| L0612 | 6 | 1 | Opponent | no | 0 | 2 | 4 | 0 | 1 | 0 | 0 | 330 |
| L0628 | 4 | 1 | Mine | no | 0 | - | 2 | 2 | 0 | 0 | 0 | 977 |
| L0628 | 4 | 1 | Opponent | no | 6 | 2 | 2 | 0 | 0 | 0 | 0 | 111 |
| L0717 | 3 | 1 | Mine | no | 2 | 4 | 2 | 0 | 0 | 0 | 0 | 125 |
| L0717 | 3 | 1 | Opponent | no | 5 | 2 | 6 | 0 | 2 | 0 | 0 | 0 |
| L0733 | 1 | 1 | Mine | no | 1 | 1 | 3 | 0 | 0 | 0 | 0 | 45 |
| L0733 | 1 | 1 | Opponent | no | 3 | - | 0 | 2 | 0 | 0 | 0 | 405 |
| L0823 | 1 | 1 | Mine | no | 3 | 3 | 1 | 1 | 1 | 0 | 0 | 295 |
| L0823 | 1 | 1 | Opponent | no | 0 | 2 | 2 | 2 | 1 | 0 | 0 | 70 |
| L0913 | 1 | 1 | Mine | no | 2 | 5 | 1 | 1 | 0 | 0 | 0 | 453 |
| L0913 | 1 | 1 | Opponent | no | 4 | 2 | 2 | 1 | 1 | 0 | 0 | 140 |
| L0930 | 6 | 1 | Mine | no | 0 | 3 | 1 | 1 | 0 | 0 | 0 | 0 |
| L0930 | 6 | 1 | Opponent | no | 5 | 2 | 1 | 2 | 0 | 0 | 0 | 98 |
| L1021 | 1 | 1 | Mine | no | 0 | 1 | 2 | 0 | 1 | 0 | 0 | 165 |
| L1021 | 1 | 1 | Opponent | no | 2 | - | 1 | 5 | 1 | 0 | 0 | 500 |
| L1114 | 4 | 1 | Mine | no | 0 | 2 | 1 | 0 | 1 | 0 | 0 | 165 |
| L1114 | 4 | 1 | Opponent | no | 1 | 2 | 2 | 2 | 0 | 0 | 0 | 177 |
| L1131 | 3 | 1 | Mine | no | 10 | - | 2 | 0 | 0 | 0 | 0 | 0 |
| L1131 | 3 | 1 | Opponent | no | 0 | 6 | 0 | 3 | 2 | 0 | 0 | 170 |
| L1224 | 6 | 1 | Mine | no | 2 | 1 | 5 | 0 | 1 | 0 | 0 | 165 |
| L1224 | 6 | 1 | Opponent | no | 12 | 2 | 3 | 2 | 1 | 0 | 0 | 60 |
| L1319 | 5 | 1 | Mine | yes | - | 2 | 7 | 3 | 0 | 0 | 0 | 140 |
| L1319 | 5 | 1 | Opponent | no | - | 2 | 3 | 2 | 0 | 0 | 0 | 0 |
| L1335 | 3 | 1 | Mine | yes | 12 | 2 | 3 | 0 | 1 | 0 | 0 | 140 |
| L1335 | 3 | 1 | Opponent | no | 0 | 2 | 1 | 3 | 0 | 0 | 0 | 624 |
| L1431 | 3 | 1 | Mine | no | 0 | 2 | 5 | 1 | 0 | 0 | 0 | 0 |
| L1431 | 3 | 1 | Opponent | no | 2 | - | 0 | 2 | 0 | 0 | 0 | 535 |
| L1527 | 3 | 1 | Mine | no | 6 | 1 | 2 | 0 | 0 | 0 | 0 | 0 |
| L1527 | 3 | 1 | Opponent | no | 1 | 3 | 2 | 1 | 0 | 0 | 0 | 133 |
| L1625 | 5 | 1 | Mine | no | - | 5 | 2 | 0 | 0 | 0 | 0 | 100 |
| L1625 | 5 | 1 | Opponent | yes | - | 2 | 2 | 3 | 0 | 0 | 0 | 0 |
| L1723 | 1 | 1 | Mine | yes | 1 | - | 0 | 0 | 1 | 0 | 0 | 0 |
| L1723 | 1 | 1 | Opponent | no | 0 | 2 | 9 | 0 | 2 | 0 | 0 | 0 |
| L1823 | 5 | 1 | Mine | no | - | 6 | 4 | 2 | 2 | 0 | 0 | 305 |
| L1823 | 5 | 1 | Opponent | yes | - | 1 | 7 | 0 | 0 | 0 | 0 | 0 |
| L1923 | 3 | 1 | Mine | no | 0 | 2 | 6 | 1 | 0 | 0 | 0 | 226 |
| L1923 | 3 | 1 | Opponent | no | 7 | 1 | 3 | 1 | 0 | 0 | 0 | 66 |
| L2025 | 3 | 1 | Mine | yes | 1 | - | 0 | 0 | 0 | 0 | 0 | 210 |
| L2025 | 3 | 1 | Opponent | no | 0 | 2 | 4 | 2 | 0 | 0 | 0 | 0 |
| L2127 | 3 | 1 | Mine | no | 4 | 5 | 2 | 3 | 0 | 0 | 0 | 200 |
| L2127 | 3 | 1 | Opponent | no | 2 | 2 | 3 | 1 | 1 | 0 | 0 | 0 |
| L2231 | 5 | 1 | Mine | yes | - | 2 | 3 | 0 | 0 | 0 | 0 | 0 |
| L2231 | 5 | 1 | Opponent | yes | - | - | 0 | 3 | 1 | 0 | 0 | 0 |
| L2335 | 1 | 1 | Mine | no | 2 | 2 | 2 | 2 | 1 | 0 | 0 | 0 |
| L2335 | 1 | 1 | Opponent | no | 3 | 5 | 3 | 0 | 0 | 0 | 0 | 0 |
| L2531 | 5 | 1 | Mine | yes | - | 6 | 4 | 3 | 0 | 0 | 0 | 0 |
| L2531 | 5 | 1 | Opponent | no | - | 4 | 2 | 1 | 1 | 0 | 0 | 541 |
| L2730 | 6 | 1 | Mine | no | 0 | 2 | 10 | 2 | 0 | 0 | 0 | 0 |
| L2730 | 6 | 1 | Opponent | no | 0 | 2 | 2 | 0 | 0 | 0 | 0 | 98 |
| L2934 | 6 | 1 | Mine | no | 6 | 2 | 3 | 2 | 0 | 0 | 0 | 170 |
| L2934 | 6 | 1 | Opponent | no | 0 | 2 | 4 | 0 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 21% | 3.1 | 2.8 | 2.4 | 1.2 | 0.3 | 0.0 | 0.0 | 183.1 |
| **Average** | | | Opponent | 9% | 2.5 | 2.4 | 2.3 | 1.9 | 0.4 | 0.0 | 0.0 | 189.8 |

### KPIs: hmw-mine-c1e47a9-p1

Rules off - Opponent only: FIVE ACTION, LIKELY CHARGE, FALLS SHORT, TIME ON OUR SIDE, FEATURE BUFFS, GETS AWAY CHANCE, GUN MASK, RUN DOWN, FOUR ROUNDS, CHARGE LOSSES, CHARACTER GUNS, STAND AND SHOOT, FALL BACK GOOD ORDER, AFTERMATH IN POINTS, NEXT CHARGE BY LIST, NEXT OBJECTIVE NEARER, NO DOUBLE ROUNDS, SCALED CHANCE, LEGAL CHARGES ONLY, SHOT OR CHARGE, MOVE CARRIES THE JOB, MOVE TO CHARGE COMPUTED, RISK BY HIS FIGURE, SHOT RISK POINTS, ONE TARGET A SHOOTER, ONE CHARGE A CHARGER, HIS CHARGE LIST, HIS SHOT LIST, HIS MOVE AND SHOT, HIS LEGAL MOVES, HIS TURN DENIED, THE PROMISE ADDS, HE SHOOTS OR CHARGES, HIS RANDOM MOVE, HIS CHARGE DENIED, SAME CHARGE LATER, FRIEND CHARGES FIRST, FRIEND SHOOTS FIRST, WAITS AGAIN, WOUNDS ON THE RANKS, THE PROMISED MOVE, MARCH BY THE SUM, FIGHT TO THE END, THE DEARER SUM KEEPS ITS PLAN, HIS OWN BEST MOVE, TIED UP BY THE SUM, REFORMS TO MEET IT, STANDS FOR A REASON, HOLDER ASSIGNMENT, ARMY TABLE, MOVE ORDER, CHARGE LIST READ AGAIN, PROMISE READS THE TABLE, SUPPORT WORKED OUT, WHO GETS IN, THE TABLE BINDS, HIS ONE MOVE, PROMISE BY ITS OWN SUM, SECOND LOOK, LOST AFTER ESCAPE, PROMISE KNOWS THE FIGHT, SPOT AS THE GAME MOVES, ONE PROMISE A TARGET, WHAT THE JOINER ADDS, DENIED BY THE FIGHT, HIS MOVE AS HE DECIDES, ROUNDS AFTER TERROR, MARCH OF THE TABLE, PROMISE HOLDS THE SPOT, PROMISE SHOT AWAY, OWN CAST FIRST, PROMISE IN STEPS, STUPIDITY NEXT TURN, PROMISE BELOW ZERO, HIS MOVE WHY, THE TABLE AGAIN, SHOTS AFTER THE MOVES, SET FIGHT, JOINT CHARGE NOW, JOINT ON THE TABLE, JOINT LOOK BACK, AFTERMATH WITH FRIENDS, HIS FIGHT TOGETHER, SET UP BY THE SET, QUARTER ODDS, CHEAPEST HOLDER, NEARER NOT NEEDED, NO FORCED ADVANCE, HARD STAY DROPPED.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 33% (55 of 168) | 4% (6 of 167) | 18% (61 of 335) |
| Winner chose to follow up after the loser gave ground |  | 87% (48 of 55); on the table 96% | 98% (52 of 53); on the table 100% | 93% (100 of 108); on the table 98% |
| Winner chose to pursue after the loser fell back in good order |  | 78% (7 of 9); on the table 78% | 86% (12 of 14); on the table 86% | 83% (19 of 23); on the table 83% |
| Winner chose to pursue after the loser fled |  | 61% (11 of 18); on the table 61% | 74% (25 of 34); on the table 76% | 69% (36 of 52); on the table 71% |
| Winner chose to follow up or pursue (all three) |  | 80% (66 of 82); on the table 87% | 88% (89 of 101); on the table 90% | 85% (155 of 183); on the table 89% |
| Magic missiles tried each own turn | 50%+ | 35% (116 of 330) | 38% (80 of 210) | 36% (196 of 540) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 45% (116 of 259) | 48% (80 of 165) | 46% (196 of 424) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 46% (16 of 35) | 49% (27 of 55) | 48% (43 of 90) |
| Points that never fought | lower | 41% (29371 of 71484) | 43% (31153 of 71889) | 42% (60524 of 143373) |
|   infantry points that never fought | lower | 47% (7989 of 16863) | 72% (9636 of 13348) | 58% (17625 of 30211) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 55% (154 of 279) | 63% (187 of 295) | 59% (341 of 574) |
| Bound items with a magic missile used (at least once a game) |  | 86% (19 of 22); 1.6 uses a game | 80% (16 of 20); 1.1 uses a game | 83% (35 of 42); 1.3 uses a game |
| Bound items with another spell used |  | 38% (6 of 16); 0.5 uses a game | 25% (2 of 8); 0.1 uses a game | 33% (8 of 24); 0.3 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 53% (10 of 19); 0.3 uses a game | 42% (5 of 12); 0.1 uses a game | 48% (15 of 31); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 50% (29667 of 59666) | 56% (35315 of 62699) | 53% (64982 of 122365) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 2.1 (36%) | 1.7 (46%) | 3.8 (40%) |
| MARCHED: its unit marched | 1.2 (20%) | 0.2 (7%) | 1.4 (15%) |
| CHARGED: its unit charged | 0.3 (5%) | 0.1 (3%) | 0.4 (4%) |
| IN COMBAT: engaged in combat | 1.0 (17%) | 0.6 (15%) | 1.6 (17%) |
| REAR RANK: in a rear rank | 0.3 (5%) | 0.1 (4%) | 0.4 (4%) |
| FLEEING: fleeing | 0.0 (0%) | 0.1 (2%) | 0.1 (1%) |
| GONE: slain | 0.6 (10%) | 0.4 (12%) | 1.0 (11%) |
| OFF THE TABLE: off the table or not arrived | 0.4 (6%) | 0.2 (5%) | 0.5 (6%) |
| STUPIDITY: Stupidity | 0.1 (1%) | 0.1 (3%) | 0.2 (2%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.1 (2%) | 0.1 (1%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.6 | 2.0 | 1.8 | 5.4 | 0.6 | 1.8 |
| not cast | 3.4 | 2.4 | 2.9 | 9.6 | 1.8 | 22.2 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) | 0.0 (0%) | 1.4 (6%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.3 (54%) | 0.3 (10%) | 3.8 (40%) | 0.4 (22%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.4 (15%) | 0.2 (14%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.4 (4%) | 0.2 (13%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.1 (3%) | 0.1 (5%) | 0.4 (16%) | 1.6 (17%) | 0.4 (21%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.5 (14%) | 0.3 (14%) | 0.5 (17%) | 0.4 (4%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.1 (2%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.3 (1%) |
| GONE: slain | 0.8 (22%) | 0.2 (7%) | 0.2 (7%) | 1.0 (11%) | 0.3 (16%) | 1.3 (6%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (1%) | 0.2 (7%) | 0.1 (5%) | 0.5 (6%) | 0.0 (0%) | 0.6 (3%) |
| STUPIDITY: Stupidity | 0.1 (4%) | 0.0 (0%) | 0.0 (1%) | 0.2 (2%) | 0.0 (0%) | 0.5 (2%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.1 (3%) | 0.0 (1%) | 0.1 (1%) | 0.2 (14%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.8 (53%) | 0.2 (10%) | 1.2 (44%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 18.1 (82%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.5 a game | 0.7 a game | 1.1 a game |
| stood (cast and not dispelled) | 76% (37 of 49) | 47% (9 of 19) | 68% (46 of 68) |
| the unit moved after it | 65% (24 of 37) | 56% (5 of 9) | 63% (29 of 46) |
| it charged on its next turn | 3% (1 of 37) | 11% (1 of 9) | 4% (2 of 46) |
| the enemy charged it first | 5% (2 of 37) | 0% (0 of 9) | 4% (2 of 46) |
| it fought by the end of its next turn | 11% (4 of 37) | 0% (0 of 9) | 9% (4 of 46) |
| it moved out of a charge the enemy had planned (not charged first) | 14% (5 of 37) | 0% (0 of 9) | 11% (5 of 46) |
| none of these (no charge, no fight, no charge escaped) | 68% (25 of 37) | 89% (8 of 9) | 72% (33 of 46) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 63% (588 of 938) | 61% (381 of 628) | 62% (969 of 1566) |
|   cavalry | 67% (54 of 81) | 72% (86 of 119) | 70% (140 of 200) |
|   character | 49% (58 of 119) | 36% (49 of 135) | 42% (107 of 254) |
|   chariot | 65% (60 of 92) | 78% (25 of 32) | 69% (85 of 124) |
|   infantry | 63% (191 of 305) | 60% (148 of 246) | 62% (339 of 551) |
|   monster | 64% (32 of 50) | 32% (9 of 28) | 53% (41 of 78) |
|   war machine | 66% (193 of 291) | 94% (64 of 68) | 72% (257 of 359) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.8 (18%) | 1.4 (21%) | 3.2 (19%) |
| CHARGED: it charged | 0.9 (9%) | 1.8 (26%) | 2.7 (16%) |
| FLEEING: it fled or was fleeing | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| IN COMBAT: it fought this turn or the last | 0.6 (6%) | 0.3 (4%) | 0.9 (5%) |
| MOVED: a war machine that moved | 1.0 (10%) | 0.0 (0%) | 1.0 (6%) |
| NO TARGET IN RANGE | 2.2 (23%) | 1.6 (23%) | 3.8 (23%) |
| ONLY IN COMBAT: the only targets were in combat | 0.6 (7%) | 0.7 (11%) | 1.4 (8%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.8 (18%) | 0.9 (13%) | 2.7 (16%) |
| SHELTERED: the target was sheltered | 0.2 (2%) | 0.1 (1%) | 0.3 (2%) |
| OTHER BAR | 0.5 (5%) | 0.1 (2%) | 0.6 (4%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 5.2 | 1.1 | 80% | 4.5 pts | 23 pts |
| character | 3.4 | 1.4 | 71% | 7.5 pts | 26 pts |
| chariot | 2.4 | 1.8 | 67% | 14.0 pts | 34 pts |
| infantry | 13.9 | 4.5 | 77% | 8.3 pts | 116 pts |
| monster | 1.2 | 0.6 | 67% | 9.3 pts | 12 pts |
| war machine | 7.1 | 5.6 | 60% | 24.8 pts | 177 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.0 | 5.0 | 4.5 |
| Charges that made contact a game | 2.7 | 3.8 | 3.3 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.14 declared, 0.86 contact (22 units) | 0.77 declared, 0.54 contact (13 units) | 1.00 declared, 0.74 contact (35 units) |
|   per unit a game, units carrying another wizard (or one alone) | 1.00 declared, 0.75 contact (8 units) | 1.38 declared, 0.62 contact (8 units) | 1.19 declared, 0.69 contact (16 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.42 declared, 0.28 contact (262 units) | 0.59 declared, 0.46 contact (271 units) | 0.50 declared, 0.37 contact (533 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 63% (44 of 70) | 67% (14 of 21) | 12% (1 of 8) | 60% (59 of 99) |
| Character in a unit | 93% (38 of 41) | 75% (18 of 24) | 67% (2 of 3) | 85% (58 of 68) |
| Character on its own | 89% (41 of 46) | 47% (17 of 36) | 33% (21 of 63) | 54% (79 of 145) |
| Chariot | 75% (12 of 16) | 70% (7 of 10) | - | 73% (19 of 26) |
| Infantry | 52% (46 of 89) | 44% (16 of 36) | 50% (1 of 2) | 50% (63 of 127) |
| Monster | 47% (15 of 32) | 50% (5 of 10) | - | 48% (20 of 42) |
| Monstrous | 64% (7 of 11) | 64% (9 of 14) | - | 64% (16 of 25) |
| War Machines | 63% (26 of 41) | 100% (1 of 1) | - | 64% (27 of 42) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 6 | 50% (4 of 8); on the table 50% | 38% (53 of 138) | 32% | 61% (20 of 33) | 100% (9 of 9); 4.8 uses a game | 100% (3 of 3); 2.0 uses a game | 78% (7 of 9); 1.2 uses a game |
| Chaos Dwarfs | 3 | 50% (3 of 6); on the table 83% | 33% (8 of 24) | 57% | 46% (11 of 24) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Dwarfen Mountain Holds | 5 | 86% (6 of 7); on the table 86% | - | 74% | 76% (31 of 41) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 6 | 75% (9 of 12); on the table 83% | 39% (14 of 36) | 59% | 59% (38 of 64) | 0.0 uses a game | 50% (1 of 2); 0.3 uses a game | 50% (2 of 4); 0.3 uses a game |
| Grand Cathay | 5 | 100% (9 of 9); on the table 100% | 36% (39 of 108) | 44% | 43% (19 of 44) | 83% (10 of 12); 5.0 uses a game | 0% (0 of 1); 0.0 uses a game | 20% (1 of 5); 0.2 uses a game |
| High Elf Realms | 6 | 79% (11 of 14); on the table 79% | 33% (10 of 30) | 36% | 43% (21 of 49) | 100% (5 of 5); 2.3 uses a game | 22% (4 of 18); 1.3 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | 100% (2 of 2); on the table 100% | - | 48% | 67% (4 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Lizardmen | 2 | 100% (5 of 5); on the table 100% | - | 44% | 64% (9 of 14) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 3 | 75% (6 of 8); on the table 75% | 17% (2 of 12) | 47% | 86% (18 of 21) | 67% (2 of 3); 1.7 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 3 | 100% (8 of 8); on the table 100% | 33% (12 of 36) | 32% | 71% (17 of 24) | 0.0 uses a game | 0.0 uses a game | 33% (1 of 3); 0.3 uses a game |
| Skaven | 4 | 91% (10 of 11); on the table 100% | 30% (9 of 30) | 44% | 53% (18 of 34) | 100% (3 of 3); 1.8 uses a game | 0.0 uses a game | 50% (2 of 4); 0.5 uses a game |
| Tomb Kings of Khemri | 6 | 80% (16 of 20); on the table 80% | 0% (0 of 12) | 27% | 20% (6 of 30) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 8 | 88% (30 of 34); on the table 97% | 48% (26 of 54) | 33% | 62% (31 of 50) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 8 | 95% (20 of 21); on the table 95% | 27% (8 of 30) | 32% | 76% (56 of 74) | 100% (4 of 4); 1.1 uses a game | 0.0 uses a game | 50% (1 of 2); 0.1 uses a game |
| Wood Elf Realms | 6 | 89% (16 of 18); on the table 89% | 50% (15 of 30) | 44% | 64% (42 of 66) | 33% (2 of 6); 1.0 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (hmw-mine-c1e47a9-p1, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 61% (43) | 48% (29) | 55% (72) |
| ...free all their last turn and able to turn (per game) | 0.75 | 0.53 | 1.28 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.14 | 0.11 | 0.25 |
| ...with the charger already in that arc before they moved (per game) | 0.53 | 0.42 | 0.94 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.89 | 0.89 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.72 | 0.72 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.22 | 6.14 | 6.36 |

### Quality by phase: hmw-mine-c1e47a9-p1

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.3 | 2.6 |
| Strategy | Charge objectives carried out (made contact) | 54% (65 of 120) | 55% (92 of 166) |
| Strategy | Shoot objectives carried out (shot that target) | 40% (154 of 387) | 49% (108 of 220) |
| Strategy | Close-in objectives charged next turn | - | 18% (46 of 255) |
| Strategy | Support requests answered (helper made contact too) | 78% (7 of 9) | 51% (19 of 37) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (2 of 2) | 67% (2 of 3) |
| Strategy | Hexes on a unit its side charged or shot that turn | 67% (10 of 15) | 67% (14 of 21) |
| Strategy | Joined characters whose unit fought | 54% (27 of 50) | 28% (13 of 47) |
| Strategy | Lone characters that fought | 69% (66 of 96) | 75% (67 of 89) |
| Movement | Charges halted short of contact | 0.1 | 0.1 |
| Movement | Idle units | 1.2 | 1.9 |
| Movement | Points that never moved of their own | 183.1 | 189.8 |
| Movement | Fights charged into per game | 2.5 | 2.9 |
| Movement | Charges with odds: long shots (under 50%) | 11 of 74, net +117 | 13 of 92, net +98 |
| Movement | Charges with odds: sweet spot (55-75%) | 11 of 74, net +3 | 17 of 92, net +6 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 11 of 74, net +76 | 13 of 92, net +95 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 21 of 74, net +107 | 27 of 92, net +111 |
| Shooting | Shots by shooting units (incl. breath weapons) | 11.7 | 9.6 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 49% (204 of 420) | 48% (167 of 345) |
| Shooting | Points destroyed by shooting units | 57.5 | 25.7 |
| Shooting | War machine shots | 5.4 | 1.8 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 54% (104 of 193) | 38% (24 of 64) |
| Shooting | Points destroyed by war machines | 80.0 | 48.6 |
| Magic | Magic missiles cast | 2.2 | 1.4 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 33% (26 of 78) | 38% (20 of 52) |
| Magic | Wounds caused by magic missiles | 4.1 | 1.6 |
| Magic | Wounds caused by other spells | 1.8 | 0.6 |
| Magic | Points destroyed by magic (all spells) | 95.5 | 35.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.8 / 0.5 / 0.9 / 0.1 | 1.6 / 0.8 / 0.4 / 0.2 |
| Combat | Points destroyed in combat | 330.2 | 348.4 |
| Combat | Points run down | 68.3 | 71.0 |
| Combat | Net points per charged fight, damage counted | +75 | +85 |
| Combat | Net per 100 charger points, damage counted | +24.8 | +26.6 |
| Combat | First round won (charged fights) | 72% | 73% |
| Combat | Net points per charged fight | +69 | +82 |
| Combat | Net points per supported fight / lone fight | +90 / +67 | +163 / +55 |
| Combat | Charged fights on a top-3 enemy unit | 29 of 89 | 50 of 104 |
| Game | Points lost | 627.9 | 721.0 |
| Game | VP from objectives | 717.8 | 681.9 |
| Game | Lone holders (player turns) | 3.1 | 2.5 |

- Mine won / drew / lost: 18 / 5 / 13 of 36 ended games (of 36); mean margin (Mine - Opponent) +85 VP
- The side that went first won 12 of 31 games with a winner
- Points traded per game (both sides' losses): 1349
- Games not ended: 0; findings 1, warnings 0

### Opponent rules: hmw-mine-c1e47a9-p1

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.6 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| ADVANCE WORTH | - | - | - | - | 4.8 | -166.8 | 64.0 | 75.0 |
| AFTERMATH IN POINTS | 0.1 | +13.9 | 0.0 | 15.6 | - | - | - | - |
| AFTERMATH WITH FRIENDS | 0.1 | +2.8 | 0.0 | 0.0 | - | - | - | - |
| ALREADY CARRIED | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | 14.7 | +197.9 | 0.0 | 143.5 | - | - | - | - |
| ARRIVAL HUNT | - | - | - | - | 0.0 | +0.1 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.3 | +0.0 | 0.0 | 4.6 | 0.4 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | 0.2 | +1.4 | 0.0 | 0.9 | 0.7 | +3.3 | 0.0 | 22.0 |
| BEST FACING | - | - | - | - | 0.2 | +3.2 | 0.0 | 10.8 |
| BEST FIRST | - | - | - | - | 1.1 | +67.5 | 9.3 | 23.4 |
| BEST MOVE FOR SHOOTERS | - | - | - | - | 0.7 | +28.1 | 0.0 | 22.4 |
| BEST OVERALL | - | - | - | - | 0.2 | +7.2 | 0.0 | 0.0 |
| BEST PREY | - | - | - | - | 0.7 | +29.5 | 11.2 | 18.2 |
| BEST PRIZE | 0.1 | -3.2 | 4.0 | 0.0 | 0.1 | -1.3 | 2.6 | 0.0 |
| BIG CHARACTER SAFETY | - | - | - | - | 0.2 | -0.6 | 0.0 | 0.0 |
| BLOCKED WHEEL | - | - | - | - | 0.2 | +3.3 | 0.0 | 0.0 |
| BLOWS WHERE AIMED | 0.2 | -14.7 | 33.3 | 0.0 | 0.5 | -54.8 | 55.2 | 0.0 |
| BOMBING RUN | 0.1 | +3.0 | 3.4 | 4.2 | - | - | - | - |
| CANNON PLAN MISSED | 0.3 | +0.0 | 32.6 | 0.0 | 0.4 | +0.0 | 86.2 | 0.0 |
| CANNON PLANNED TARGET | 5.1 | +172.7 | 423.5 | 37.8 | 1.7 | +32.0 | 159.6 | 12.8 |
| CANNON SIGHT KEPT | 0.8 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT SET-UP | 0.0 | -2.4 | 0.0 | 0.0 | 0.4 | -0.8 | 31.5 | 5.9 |
| CAST JOB | 1.0 | +29.8 | 101.4 | 0.0 | 0.4 | +6.5 | 5.7 | 16.4 |
| CASTER AWAY FROM SCREEN | 0.3 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.5 | +57.5 | 40.8 | 0.0 | 0.3 | +4.4 | 14.5 | 4.4 |
| CASTS AFTER FRIENDS | 1.0 | +0.0 | 0.0 | 6.1 | 0.4 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.1 | +1.4 | 0.0 | 0.0 | - | - | - | - |
| CATCH ODDS | - | - | - | - | 0.1 | +1.4 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | 0.6 | +27.7 | 0.0 | 7.6 | 1.8 | +104.2 | 0.0 | 45.4 |
| CHAFF PASSED | 0.4 | -3.4 | 4.7 | 1.8 | 0.2 | -0.1 | 0.0 | 0.0 |
| CHAMPION KNOWS CHALLENGE | 0.1 | -1.4 | 0.0 | 0.0 | 0.2 | -6.9 | 11.3 | 23.5 |
| CHARACTER GUNS | 0.9 | +0.0 | 0.0 | 16.1 | - | - | - | - |
| CHARGE LIST READ AGAIN | 0.0 | +0.5 | 0.0 | 0.0 | - | - | - | - |
| CHARGE LOSSES | 10.2 | -483.3 | 0.0 | 303.5 | - | - | - | - |
| CHARGE NOT DECLARED | 0.1 | +0.0 | 0.0 | 2.5 | 0.6 | +0.0 | 39.3 | 6.2 |
| CHARGE NOW FIRST | 2.3 | +0.0 | 198.1 | 28.2 | 2.6 | +0.0 | 278.6 | 130.2 |
| CHARGE NOW WEIGHED | - | - | - | - | 0.5 | -34.7 | 33.4 | 14.6 |
| CHARGER SLAIN LOST | 0.4 | -9.6 | 27.2 | 40.1 | 0.6 | -11.9 | 66.4 | 29.4 |
| CHARIOT NO STATIC JOB | 0.0 | +0.0 | 0.9 | 0.0 | - | - | - | - |
| CHARIOT WIZARD CAREFUL | - | - | - | - | 0.2 | -2.3 | 0.0 | 15.0 |
| CHEAP HELPER | - | - | - | - | 0.2 | +0.0 | 10.1 | 0.0 |
| COMBAT PIVOT | 0.3 | +0.0 | 6.5 | 19.2 | 0.4 | +0.0 | 24.6 | 36.6 |
| CONTINUE AHEAD WEIGHED | 0.0 | +0.0 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | 0.9 | +107.9 | 15.1 | 12.2 | 0.4 | +62.9 | 6.5 | 15.2 |
| COVER ONCE | 6.5 | -466.1 | 0.0 | 141.0 | 4.8 | -293.4 | 0.0 | 132.2 |
| DEFENSIVE ARMY | 0.2 | +0.0 | 6.4 | 5.8 | - | - | - | - |
| DEFENSIVE FLOOR | 0.1 | +3.8 | 5.2 | 0.0 | - | - | - | - |
| DENIED BY THE FIGHT | 0.4 | -4.0 | 39.7 | 18.7 | - | - | - | - |
| DEPLOY BY FIGURES | 8.1 | +18.5 | 0.0 | 14.0 | 7.6 | +71.9 | 0.0 | 21.1 |
| EDGE GIVE GROUND | 0.2 | +6.6 | 13.9 | 0.9 | 0.2 | +8.6 | 37.1 | 3.5 |
| ELIXIR WORTH | - | - | - | - | 0.0 | +1.7 | 0.0 | 0.0 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | - | - | - | - | 0.9 | +54.4 | 0.0 | 53.6 |
| FALL BACK GOOD ORDER | 2.2 | +7.5 | 181.7 | 73.8 | - | - | - | - |
| FALLBACK BY WORTH | 0.1 | +0.0 | 0.0 | 0.8 | 6.0 | +64.2 | 0.0 | 64.0 |
| FALLS SHORT | 4.1 | +71.5 | 0.0 | 85.9 | - | - | - | - |
| FEATURE BUFFS | 1.9 | +71.3 | 0.0 | 13.7 | - | - | - | - |
| FIGHT LIFT | 0.1 | +1.0 | 0.0 | 0.0 | - | - | - | - |
| FIGHT TO THE END | 0.7 | +14.7 | 38.5 | 19.8 | - | - | - | - |
| FIRE AND FLEE | - | - | - | - | 0.0 | +0.2 | 0.0 | 3.5 |
| FIRE IN ORDER | 0.4 | +0.0 | 4.9 | 4.8 | 0.1 | +0.0 | 6.0 | 0.0 |
| FIVE ACTION | 88.0 | +5869.3 | 1799.9 | 1044.5 | - | - | - | - |
| FLANK NOT WEIGHED | 4.7 | +0.0 | 0.0 | 166.1 | 5.0 | +0.0 | 0.0 | 127.0 |
| FOCUS FIRE | 0.1 | +6.2 | 6.9 | 0.0 | 0.0 | +0.1 | 0.8 | 0.0 |
| FOLLOW UP WEIGHED | 0.8 | +118.0 | 0.0 | 7.6 | 1.0 | +198.3 | 0.0 | 20.7 |
| FOUR ROUNDS | 3.8 | +297.2 | 323.3 | 112.4 | - | - | - | - |
| FRIEND SHOOTS FIRST | 0.6 | -14.9 | 6.4 | 0.9 | - | - | - | - |
| FRIENDS SHOTS CHECKED | 0.1 | +10.5 | 0.0 | 22.6 | 0.1 | +7.3 | 0.0 | 0.0 |
| GIVES UP | 0.4 | -6.6 | 45.9 | 24.3 | 0.1 | -1.5 | 7.4 | 0.0 |
| GIVES UP ITS SCREEN | 0.1 | -0.0 | 7.9 | 2.4 | 0.1 | -0.6 | 1.8 | 2.6 |
| GROUND FLIERS | - | - | - | - | 0.1 | +0.6 | 0.0 | 0.0 |
| GUN FIGURES | 1.0 | +3.3 | 11.3 | 3.5 | 0.5 | +12.2 | 5.6 | 5.1 |
| GUN MASK | 1.1 | +19.4 | 0.0 | 0.0 | - | - | - | - |
| HARD STAY DROPPED | 1.7 | +0.0 | 0.0 | 16.4 | - | - | - | - |
| HE SHOOTS OR CHARGES | 2.2 | +0.0 | 0.0 | 88.7 | - | - | - | - |
| HELPER ALREADY ASKED | - | - | - | - | 0.2 | +0.0 | 23.7 | 0.0 |
| HELPER UNSEEN | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| HILL BY ITS CHANCE | - | - | - | - | 0.4 | -55.7 | 0.0 | 2.2 |
| HIS CHARGE DENIED | 0.5 | +23.9 | 47.9 | 29.3 | - | - | - | - |
| HIS CHARGE LIST | 4.2 | +0.0 | 0.0 | 77.6 | - | - | - | - |
| HIS FIGHT TOGETHER | 2.3 | -52.3 | 0.0 | 138.1 | - | - | - | - |
| HIS LEGAL MOVES | 4.9 | +0.0 | 0.0 | 72.1 | - | - | - | - |
| HIS MOVE AND SHOT | 3.4 | -40.5 | 0.0 | 93.3 | - | - | - | - |
| HIS MOVE AS HE DECIDES | 36.4 | +12.8 | 708.7 | 0.0 | - | - | - | - |
| HIS MOVE WHY | - | - | - | - | 36.5 | +0.0 | 0.0 | 574.2 |
| HIS ONE MOVE | 17.2 | +47.4 | 1.4 | 62.8 | - | - | - | - |
| HIS OWN BEST MOVE | 2.2 | +0.0 | 0.0 | 40.2 | - | - | - | - |
| HIS RANDOM MOVE | 5.7 | +0.0 | 0.0 | 14.7 | - | - | - | - |
| HIS SHOT LIST | 33.4 | +891.4 | 0.0 | 484.4 | - | - | - | - |
| HIS TURN DENIED | 1.6 | +24.5 | 155.7 | 38.8 | - | - | - | - |
| HOLD ODDS | 11.6 | +0.0 | 0.0 | 200.7 | - | - | - | - |
| HOLDER ASSIGNMENT | 11.8 | +1124.5 | 0.0 | 149.0 | - | - | - | - |
| HOLDER AT DEPLOYMENT | - | - | - | - | 1.2 | +196.1 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.8 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 3.1 | -121.2 | 269.1 | 60.2 | 9.6 | -197.2 | 507.5 | 258.8 |
| HUNT ADVANCE | - | - | - | - | 0.2 | +9.4 | 0.0 | 8.1 |
| HUNT DROPPED | - | - | - | - | 0.1 | +0.0 | 0.0 | 6.1 |
| HUNT IN PAIRS | 0.2 | +9.9 | 0.0 | 0.0 | 0.5 | +37.1 | 0.0 | 6.0 |
| HUNT KEPT | - | - | - | - | 0.0 | +1.0 | 0.0 | 1.9 |
| HUNT RESULT | - | - | - | - | 0.3 | +12.3 | 0.0 | 12.5 |
| HUNT THE GUNS | - | - | - | - | 0.3 | +86.7 | 8.6 | 8.6 |
| IDLE COST | 3.9 | -51.2 | 0.0 | 39.8 | 18.4 | -288.5 | 0.0 | 218.4 |
| INVITES THE FIGHT | - | - | - | - | 1.0 | +5.7 | 3.3 | 19.9 |
| JOINT CHARGE NOW | 0.6 | -2.2 | 76.9 | 20.0 | - | - | - | - |
| JOINT CHARGE PLAN | - | - | - | - | 0.4 | +31.1 | 0.0 | 14.8 |
| JOINT KNOWS CHALLENGE | 0.1 | -0.8 | 0.0 | 0.0 | 0.2 | -13.3 | 0.0 | 7.0 |
| KEEP FALLS | 0.0 | +0.2 | 0.0 | 0.0 | - | - | - | - |
| KEEPS ITS PREY | - | - | - | - | 0.2 | +1.1 | 0.0 | 4.8 |
| KEEPS ITS TARGET | - | - | - | - | 2.2 | +67.5 | 168.6 | 41.5 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KILLS COUNT | - | - | - | - | 1.7 | +76.0 | 149.9 | 64.5 |
| KILLS COUNT NEXT TURN | - | - | - | - | 7.6 | +264.5 | 229.7 | 186.1 |
| LANE BY FIGURES | 0.8 | +25.9 | 0.0 | 0.0 | 0.8 | +49.4 | 0.0 | 16.6 |
| LEGAL CHARGES ONLY | 5.5 | +0.0 | 211.8 | 259.1 | - | - | - | - |
| LONE CHARACTER SAFE SPOT | 0.1 | +3.9 | 0.0 | 0.0 | 0.4 | +5.0 | 11.2 | 18.7 |
| LONE WIZARD HOLDS BACK | - | - | - | - | 0.3 | +0.0 | 7.1 | 15.2 |
| LONE WIZARD KEPT IN | 0.7 | +50.8 | 0.0 | 0.0 | 0.2 | +24.5 | 0.0 | 0.0 |
| LONG SHOT | 0.1 | -4.1 | 15.8 | 8.6 | 0.5 | +2.8 | 36.0 | 3.5 |
| LOST AFTER ESCAPE | 2.2 | +1.2 | 176.2 | 63.2 | - | - | - | - |
| LOST CHARGE | 0.1 | -0.2 | 13.6 | 0.0 | 2.5 | -33.3 | 68.8 | 82.9 |
| LURE BY WHAT IT DRAWS | 0.3 | -4.5 | 0.0 | 0.0 | 0.2 | -19.9 | 0.0 | 10.2 |
| MAKE SURE TOGETHER | 0.2 | +1.2 | 0.0 | 0.0 | 1.3 | +146.7 | 47.3 | 25.1 |
| MANOEUVRE | 1.1 | -0.8 | 0.0 | 2.5 | 0.1 | +16.9 | 0.0 | 3.0 |
| MARCH AT ESCAPER | 0.1 | +0.4 | 0.0 | 5.3 | 0.2 | +0.7 | 0.0 | 0.0 |
| MARCH BY THE SUM | 0.2 | +23.1 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | 0.9 | +38.5 | 0.0 | 2.2 | 0.2 | +1.3 | 0.0 | 8.4 |
| MARCH ODDS | 0.1 | +1.8 | 0.0 | 0.0 | 0.2 | +14.3 | 8.7 | 11.1 |
| MARCH OF THE TABLE | 0.2 | +5.2 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 1.0 | +81.2 | 0.0 | 11.0 | 0.3 | +3.2 | 0.0 | 3.0 |
| MAX FOR POSITIONING | 2.5 | +56.3 | 0.0 | 21.1 | 6.4 | +82.7 | 0.0 | 136.7 |
| MISSILES IN THE MOVE | 4.2 | +189.5 | 0.0 | 55.9 | 3.7 | +54.9 | 0.0 | 83.7 |
| MISSILES NEXT TURN | 4.9 | +126.7 | 0.0 | 62.6 | 4.2 | +40.4 | 0.0 | 83.7 |
| MODEL FACING | 0.4 | +165.8 | 0.0 | 0.0 | - | - | - | - |
| MONSTER WIZARD ROAMS | - | - | - | - | 0.2 | +0.0 | 0.0 | 0.0 |
| MOVE AND CAST | - | - | - | - | 0.4 | +19.7 | 0.0 | 20.7 |
| MOVE ORDER | 1.9 | +0.0 | 36.5 | 7.5 | - | - | - | - |
| MOVE SPELL IN RANGE | 0.1 | +1.8 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.5 | -61.6 | 10.3 | 11.2 | 0.1 | -0.5 | 0.0 | 15.2 |
| MOVE SPELL SPOT | 0.3 | +0.0 | 0.0 | 7.6 | 0.1 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE | - | - | - | - | 5.6 | +506.0 | 164.1 | 150.1 |
| MOVE TO CHARGE COMPUTED | 7.8 | +725.4 | 0.0 | 46.5 | - | - | - | - |
| MOVES UNITS SPELL | 0.1 | +3.4 | 0.0 | 0.0 | 0.1 | +1.8 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 6.7 | +295.8 | 0.0 | 78.7 | - | - | - | - |
| NEEDED THERE | - | - | - | - | 0.1 | +9.9 | 9.0 | 0.0 |
| NEXT CHARGE BY LIST | 6.7 | -298.6 | 46.7 | 65.9 | - | - | - | - |
| NEXT OBJECTIVE NEARER | 0.4 | -8.1 | 0.0 | 6.5 | - | - | - | - |
| NO DOUBLE ROUNDS | 3.0 | -128.8 | 251.5 | 109.9 | - | - | - | - |
| NO RALLY LEFT | 0.1 | +7.3 | 0.0 | 0.0 | - | - | - | - |
| NOT NEEDED | - | - | - | - | 0.3 | -15.7 | 52.3 | 1.2 |
| NOT TURNED | 0.2 | +0.0 | 0.0 | 1.8 | 6.1 | +72.2 | 0.0 | 154.4 |
| NOT WORTH A CAST | 0.9 | -0.8 | 0.0 | 2.6 | 0.1 | -0.0 | 0.0 | 0.0 |
| OFF BEST | 3.5 | -162.8 | 6.2 | 51.5 | 17.0 | -947.6 | 0.0 | 308.9 |
| ONE CHARGE A CHARGER | 3.6 | +0.0 | 0.0 | 129.3 | - | - | - | - |
| ONE FIGHT FORMULA | 4.7 | -97.6 | 0.0 | 53.9 | 8.3 | -154.7 | 1.8 | 179.2 |
| ONE OBJECTIVE FORMULA | 3.5 | +23.0 | 0.0 | 76.0 | 2.0 | -95.1 | 0.0 | 43.1 |
| ONE PROMISE A TARGET | 0.3 | -14.9 | 0.0 | 0.0 | - | - | - | - |
| ONE TARGET A SHOOTER | 24.6 | +439.0 | 0.0 | 361.5 | - | - | - | - |
| OPENS A LANE | 0.1 | +0.6 | 0.0 | 8.8 | 0.0 | +0.1 | 2.9 | 0.0 |
| OPENS UP | 0.4 | +24.1 | 23.3 | 12.3 | 0.1 | +17.6 | 8.4 | 0.0 |
| OVERRUN THREAT | - | - | - | - | 0.0 | +1.7 | 0.0 | 5.0 |
| OVERRUNS AWAY | 0.5 | +36.6 | 44.2 | 24.8 | 0.7 | +15.3 | 61.1 | 22.9 |
| OWN CAST FIRST | 0.0 | -0.7 | 0.0 | 0.0 | - | - | - | - |
| PATHS CROSS | 0.5 | +20.7 | 0.0 | 1.8 | 2.7 | +178.1 | 0.0 | 37.7 |
| PERIAPT WORTH | 0.0 | +1.5 | 0.0 | 0.0 | 0.0 | +1.5 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.2 | -4.2 | 0.0 | 0.0 | 0.1 | -1.7 | 0.0 | 0.0 |
| PLAN RESULT | 41.4 | +964.3 | 627.5 | 842.7 | 39.4 | +1105.8 | 1280.9 | 908.1 |
| PROMISE BELOW ZERO | 0.2 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE BY ITS OWN SUM | 9.2 | -344.9 | 0.0 | 4.8 | - | - | - | - |
| PROMISE IN STEPS | 0.2 | +0.0 | 6.4 | 0.0 | - | - | - | - |
| PROMISE KNOWS THE FIGHT | 0.8 | -4.2 | 6.4 | 0.0 | - | - | - | - |
| PROMISE READS THE TABLE | 0.4 | -30.9 | 0.0 | 5.7 | - | - | - | - |
| PROMISE SHOT AWAY | 0.1 | -2.8 | 15.7 | 0.0 | - | - | - | - |
| PURSUES BIG PREY | - | - | - | - | 0.1 | -2.1 | 0.0 | 0.0 |
| QUARTER ODDS | 9.5 | +1341.9 | 241.0 | 185.0 | - | - | - | - |
| RAIDS THE BAGGAGE NEXT TURN | - | - | - | - | 0.0 | +2.4 | 0.0 | 3.0 |
| RANDOM MOVE BY FIGURES | 1.0 | +19.9 | 0.0 | 26.9 | 1.5 | +16.0 | 0.0 | 63.1 |
| RANDOM MOVER NO PROMISE | - | - | - | - | 0.2 | -6.2 | 1.8 | 4.7 |
| REDIRECT BY WHAT IT STOPS | 0.4 | -10.7 | 0.0 | 6.7 | 1.1 | -38.7 | 0.0 | 23.4 |
| REDIRECT COUNTER | 1.5 | +59.6 | 0.0 | 25.1 | 3.3 | +229.8 | 0.0 | 59.8 |
| REDIRECT WEIGHED | 0.2 | -0.3 | 0.0 | 12.3 | 0.2 | +2.1 | 1.8 | 13.1 |
| REFORMS TO MEET IT | 1.9 | -53.1 | 0.0 | 12.0 | - | - | - | - |
| REFUSING RETIRES | 0.5 | +0.0 | 0.0 | 14.3 | 0.6 | +0.0 | 0.0 | 31.9 |
| RESERVE FALL BACK | 0.4 | +14.6 | 0.0 | 4.9 | 0.7 | +29.3 | 0.0 | 22.4 |
| RESTRAINS TO SHOOT | 0.0 | +1.6 | 0.0 | 0.0 | 0.2 | +11.4 | 0.0 | 9.6 |
| RISK BY ARC | 2.5 | +21.2 | 205.3 | 85.8 | 2.5 | +59.2 | 227.8 | 80.3 |
| RISK BY HIS FIGURE | 20.7 | -402.2 | 0.0 | 514.2 | - | - | - | - |
| RISK ONCE | - | - | - | - | 5.5 | +235.5 | 67.5 | 307.3 |
| ROUNDS AFTER TERROR | 0.6 | -14.1 | 53.2 | 40.4 | - | - | - | - |
| RUN DOWN | 2.5 | -30.1 | 191.1 | 90.6 | - | - | - | - |
| SAFER THAN THE JOB | - | - | - | - | 0.7 | +31.4 | 0.0 | 10.0 |
| SAME CHARGE LATER | 0.0 | -0.1 | 2.7 | 0.0 | - | - | - | - |
| SCOUT SPOT | 0.4 | +0.7 | 0.0 | 1.5 | 0.3 | +0.8 | 0.0 | 0.0 |
| SCOUT WAITS | 0.4 | +0.0 | 0.0 | 1.5 | 0.3 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.2 | -12.3 | 0.0 | 0.0 | 0.4 | -35.1 | 0.0 | 8.4 |
| SEARCH SPOT | 0.8 | +27.8 | 0.0 | 10.4 | 3.1 | +135.8 | 0.0 | 51.7 |
| SECOND LOOK | 0.4 | +21.6 | 14.1 | 12.1 | - | - | - | - |
| SELF MOVE SPELL | 0.2 | +8.1 | 0.0 | 21.9 | 0.3 | +6.5 | 0.0 | 0.0 |
| SET UP BY THE SET | 1.9 | +92.6 | 6.3 | 22.4 | - | - | - | - |
| SET UP TOGETHER | 0.3 | +3.4 | 0.0 | 0.0 | 2.9 | +396.9 | 47.3 | 68.5 |
| SET-UP ANY TARGET | 0.1 | +18.7 | 7.6 | 6.1 | 0.1 | +17.1 | 0.0 | 0.0 |
| SET-UP MISSED | 0.1 | +2.8 | 1.8 | 0.0 | 0.1 | +38.2 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.4 | +0.9 | 0.0 | 0.0 | 0.2 | +0.6 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 2.7 | +109.2 | 127.6 | 38.4 | 1.2 | +37.1 | 44.4 | 17.8 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| SHOT OR CHARGE | 0.5 | -30.8 | 128.5 | 2.0 | - | - | - | - |
| SHOT RISK POINTS | 16.0 | +126.3 | 0.0 | 254.5 | - | - | - | - |
| SHOTS AFTER THE MOVES | 3.4 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SHOTS IN THE MOVE | 16.6 | +711.7 | 0.0 | 173.9 | 9.8 | +218.3 | 0.0 | 145.3 |
| SPELL CATCH ODDS | - | - | - | - | 0.0 | -0.2 | 0.0 | 0.0 |
| SPELL OFF EDGE | - | - | - | - | 0.0 | +1.8 | 3.5 | 6.5 |
| SPELL SETS UP CHARGE | 0.1 | +32.5 | 7.6 | 6.1 | 0.2 | +37.4 | 0.0 | 0.0 |
| SPELL WORTH | 1.4 | +19.3 | 63.1 | 58.0 | 1.7 | +41.8 | 114.2 | 127.2 |
| SPELLS IN THE FIGHT | 0.4 | -2.5 | 62.0 | 12.1 | 0.5 | -5.8 | 38.0 | 6.4 |
| SPOT AS THE GAME MOVES | 6.7 | +0.0 | 0.0 | 159.9 | - | - | - | - |
| STABLE ROLE | - | - | - | - | 12.6 | +0.0 | 354.8 | 255.4 |
| STAND AND SHOOT | 0.6 | -5.1 | 58.6 | 19.3 | - | - | - | - |
| STANDS FOR A REASON | 0.5 | +0.0 | 15.2 | 0.0 | - | - | - | - |
| STANDS STILL | 40.4 | +0.0 | 1476.6 | 307.8 | - | - | - | - |
| STANDS TO CAST | - | - | - | - | 0.1 | +6.7 | 0.8 | 0.0 |
| STAY WEIGHED | - | - | - | - | 0.0 | +0.9 | 0.0 | 0.0 |
| STAY WORTH | 26.1 | -8.6 | 1025.9 | 162.7 | 11.8 | +84.8 | 281.7 | 128.2 |
| STOPS | - | - | - | - | 0.1 | +1.5 | 8.6 | 2.5 |
| STOPS SHORT OF THE FLANK | - | - | - | - | 0.3 | +23.5 | 0.0 | 0.0 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 4.0 |
| STUPIDITY NEXT TURN | 0.2 | +0.0 | 0.0 | 7.8 | - | - | - | - |
| SUPPORT NARROWED | 0.3 | +0.0 | 23.2 | 1.4 | 6.2 | -47.1 | 362.0 | 61.1 |
| SUPPORT WORKED OUT | 3.4 | +178.9 | 0.0 | 26.8 | - | - | - | - |
| SUPPORTS | - | - | - | - | 4.3 | +47.1 | 183.2 | 25.5 |
| SURE CHARGE BEATS ADVANCE | - | - | - | - | 0.1 | -2.1 | 10.3 | 0.0 |
| SURE REACH TOGETHER | 0.1 | +1.1 | 0.0 | 0.0 | 0.8 | +8.6 | 1.8 | 16.5 |
| THE DEARER SUM KEEPS ITS PLAN | 2.0 | +0.0 | 0.0 | 22.2 | - | - | - | - |
| THE PROMISE ADDS | 0.4 | -28.3 | 0.0 | 5.7 | - | - | - | - |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE TABLE BINDS | 28.6 | +0.0 | 0.0 | 313.1 | - | - | - | - |
| THROUGH LINE OF FIRE | - | - | - | - | 0.2 | +3.5 | 0.0 | 2.9 |
| TIED UP BY THE SUM | 0.9 | +92.8 | 67.5 | 20.1 | - | - | - | - |
| TIME ON OUR SIDE | 30.1 | +372.5 | 17.4 | 253.4 | - | - | - | - |
| TURN WORTH | - | - | - | - | 0.3 | -21.5 | 32.3 | 17.6 |
| TWO OR MORE ARRIVE | - | - | - | - | 0.8 | +4.4 | 27.3 | 14.1 |
| WAIT AFTER COSTS | - | - | - | - | 8.8 | -434.8 | 219.8 | 209.0 |
| WAITS AGAIN | 1.8 | +0.0 | 0.0 | 9.1 | - | - | - | - |
| WALKS TO THE FIGHT | - | - | - | - | 1.2 | +10.0 | 30.3 | 26.6 |
| WAR ENGINE CHARGES | - | - | - | - | 0.0 | +3.0 | 0.0 | 0.0 |
| WAR ENGINE JOBS | 0.4 | +0.0 | 15.0 | 20.6 | 0.2 | +0.0 | 1.9 | 11.2 |
| WEARS DOWN | - | - | - | - | 1.5 | +66.6 | 136.5 | 47.8 |
| WHAT THE JOINER ADDS | 0.3 | -10.4 | 25.3 | 29.1 | - | - | - | - |
| WHO GETS IN | 0.1 | -5.4 | 16.0 | 0.0 | - | - | - | - |
| WHO HITS BACK | 0.6 | +101.9 | 0.0 | 8.4 | 0.2 | +12.3 | 0.0 | 12.3 |
| WHOLE FIGHT | 0.1 | +1.2 | 12.6 | 14.6 | 0.6 | +55.7 | 95.9 | 30.1 |
| WHOLE FIGHT GAIN | 0.1 | +2.8 | 17.9 | 5.2 | 0.9 | +65.6 | 80.9 | 10.4 |
| WIDER SPREAD | 2.2 | -3.5 | 205.7 | 72.1 | 2.6 | +0.0 | 266.9 | 76.9 |
| WOUNDED STAYS OUT | 0.0 | +0.0 | 13.1 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| WOUNDS ON THE RANKS | 2.7 | +104.6 | 0.0 | 70.3 | - | - | - | - |

### Rule changes: hmw-mine-c1e47a9-p1

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS MOVE AS HE DECIDES | 1311 | 1311 | 850 | 23.61 | +0 | +0.0 |
| OFF BEST | 738 | 738 | 738 | 20.50 | -39977 | -54.2 |
| HIS MOVE WHY | 1315 | 1315 | 726 | 20.17 | +0 | +0.0 |
| ARMY TABLE | 530 | 530 | 400 | 11.11 | +4676 | +11.7 |
| HOLDER ASSIGNMENT | 425 | 425 | 388 | 10.78 | +21457 | +55.3 |
| DEPLOY BY FIGURES | 565 | 565 | 355 | 9.86 | +4583 | +12.9 |
| HIS SHOT LIST | 1201 | 1147 | 226 | 6.28 | +2876 | +12.7 |
| LEGAL CHARGES ONLY | 199 | 199 | 199 | 5.53 | +0 | +0.0 |
| THE TABLE AGAIN | 216 | 216 | 149 | 4.14 | +0 | +0.0 |
| ONE TARGET A SHOOTER | 884 | 843 | 147 | 4.08 | +1167 | +7.9 |
| TIME ON OUR SIDE | 1082 | 966 | 139 | 3.86 | +457 | +3.3 |
| FIVE ACTION | 3169 | 3055 | 136 | 3.78 | +8688 | +63.9 |
| PROMISE BY ITS OWN SUM | 331 | 331 | 136 | 3.78 | -12417 | -91.3 |
| SEARCH SPOT | 138 | 138 | 131 | 3.64 | +5890 | +45.0 |
| HIS ONE MOVE | 619 | 585 | 127 | 3.53 | +0 | +0.0 |
| MOVE TO CHARGE COMPUTED | 281 | 222 | 121 | 3.36 | +5949 | +49.2 |
| PATHS CROSS | 113 | 113 | 113 | 3.14 | +7158 | +63.3 |
| SHOOTS FROM THE BEST SPOT | 140 | 140 | 103 | 2.86 | +1580 | +15.3 |
| MOVE TO CHARGE | 201 | 201 | 96 | 2.67 | +6718 | +70.0 |
| KILLS COUNT NEXT TURN | 274 | 274 | 80 | 2.22 | +2536 | +31.7 |
| SHOTS IN THE MOVE | 949 | 722 | 77 | 2.14 | +1783 | +23.2 |
| SHOT RISK POINTS | 576 | 559 | 75 | 2.08 | +2339 | +31.2 |
| MOVE ORDER | 69 | 69 | 69 | 1.92 | +0 | +0.0 |
| SUPPORTS | 155 | 155 | 66 | 1.83 | +641 | +9.7 |
| FOLLOW UP WEIGHED | 64 | 64 | 64 | 1.78 | +11386 | +177.9 |
| ARTILLERY RE-ROLL WEIGHED | 60 | 60 | 60 | 1.67 | +0 | +0.0 |
| HARD STAY DROPPED | 60 | 60 | 60 | 1.67 | +0 | +0.0 |
| ADVANCE LANE KEPT | 59 | 59 | 59 | 1.64 | +0 | +0.0 |
| FOUR ROUNDS | 135 | 125 | 58 | 1.61 | +2917 | +50.3 |
| LANE BY FIGURES | 57 | 57 | 57 | 1.58 | +2712 | +47.6 |
| COVER ONCE | 407 | 257 | 56 | 1.56 | +1553 | +27.7 |
| QUARTER ODDS | 343 | 332 | 55 | 1.53 | +6002 | +109.1 |
| STAY WORTH | 1363 | 1214 | 53 | 1.47 | +959 | +18.1 |
| CHARGE NOW FIRST | 177 | 177 | 52 | 1.44 | -4034 | -77.6 |
| SET UP TOGETHER | 117 | 99 | 51 | 1.42 | +7253 | +142.2 |
| CHAFF IN THE MOVE | 85 | 75 | 49 | 1.36 | +1386 | +28.3 |
| WAIT AFTER COSTS | 318 | 318 | 49 | 1.36 | +962 | +19.6 |
| RISK ONCE | 197 | 152 | 48 | 1.33 | +1526 | +31.8 |
| CANNON PLANNED TARGET | 247 | 247 | 46 | 1.28 | +101 | +2.2 |
| HOLDS AMBUSHERS | 44 | 44 | 44 | 1.22 | +0 | +0.0 |
| MISSILES IN THE MOVE | 284 | 185 | 44 | 1.22 | +694 | +15.8 |
| RANDOM MOVE BY FIGURES | 90 | 90 | 43 | 1.19 | +1292 | +30.0 |
| SUPPORT WORKED OUT | 124 | 117 | 41 | 1.14 | +1830 | +44.6 |
| RESERVE FALL BACK | 40 | 40 | 40 | 1.11 | +1581 | +39.5 |
| RISK BY ARC | 181 | 172 | 40 | 1.11 | +1269 | +31.7 |
| FALLBACK BY WORTH | 220 | 220 | 39 | 1.08 | +2310 | +59.2 |
| RISK BY HIS FIGURE | 745 | 707 | 39 | 1.08 | +5758 | +147.6 |
| BEST FIRST | 38 | 38 | 38 | 1.06 | +2432 | +64.0 |
| CANNON SIGHT KEPT | 38 | 38 | 38 | 1.06 | +0 | +0.0 |
| REDIRECT COUNTER | 174 | 94 | 38 | 1.06 | +2703 | +71.1 |
| IDLE COST | 800 | 508 | 36 | 1.00 | +300 | +8.3 |
| LONE WIZARD KEPT IN | 35 | 35 | 35 | 0.97 | +2708 | +77.4 |
| MAX FOR POSITIONING | 321 | 209 | 35 | 0.97 | +132 | +3.8 |
| FACES THE THREAT | 32 | 32 | 32 | 0.89 | +1958 | +61.2 |
| CHARGE LOSSES | 366 | 354 | 30 | 0.83 | +3432 | +114.4 |
| WHO HITS BACK | 29 | 29 | 29 | 0.81 | +2941 | +101.4 |
| CAST JOB | 50 | 50 | 27 | 0.75 | +140 | +5.2 |
| ADVANCE WORTH | 174 | 174 | 26 | 0.72 | +376 | +14.5 |
| MARCH CHECK | 38 | 37 | 26 | 0.72 | +734 | +28.2 |
| SAFER THAN THE JOB | 26 | 26 | 26 | 0.72 | +1130 | +43.5 |
| SCOUT WAITS | 26 | 26 | 26 | 0.72 | +0 | +0.0 |
| BEST MOVE FOR SHOOTERS | 25 | 25 | 25 | 0.69 | +1012 | +40.5 |
| CASTER AWAY FROM SCREEN | 25 | 25 | 25 | 0.69 | +0 | +0.0 |
| HOLDER AT DEPLOYMENT | 44 | 44 | 25 | 0.69 | +1020 | +40.8 |
| SET UP BY THE SET | 68 | 65 | 25 | 0.69 | +1952 | +78.1 |
| TIED UP BY THE SUM | 33 | 31 | 25 | 0.69 | +881 | +35.2 |
| ONE FIGHT FORMULA | 467 | 253 | 24 | 0.67 | +107 | +4.4 |
| CHAFF PASSED | 23 | 23 | 23 | 0.64 | -126 | -5.5 |
| COMBAT PIVOT | 23 | 23 | 23 | 0.64 | +0 | +0.0 |
| JOINT CHARGE NOW | 23 | 23 | 23 | 0.64 | -80 | -3.5 |
| SHOOTERS IN TWO RANKS | 23 | 23 | 23 | 0.64 | +53 | +2.3 |
| CHARGE NOT DECLARED | 22 | 22 | 22 | 0.61 | -1522 | -69.2 |
| NEXT CHARGE BY LIST | 242 | 215 | 22 | 0.61 | +427 | +19.4 |
| WOUNDS ON THE RANKS | 96 | 95 | 21 | 0.58 | +492 | +23.4 |
| FIRE IN ORDER | 20 | 20 | 20 | 0.56 | +0 | +0.0 |
| HONEST WORTH | 456 | 445 | 20 | 0.56 | +301 | +15.1 |
| WHOLE FIGHT GAIN | 35 | 33 | 20 | 0.56 | +1304 | +65.2 |
| CHARGE NOW WEIGHED | 19 | 19 | 19 | 0.53 | +670 | +35.3 |
| KILLS COUNT | 61 | 61 | 19 | 0.53 | +664 | +34.9 |
| SHOTS AFTER THE MOVES | 124 | 124 | 19 | 0.53 | +0 | +0.0 |
| WALKS TO THE FIGHT | 45 | 45 | 18 | 0.50 | +123 | +6.8 |
| MAKE SURE TOGETHER | 54 | 35 | 16 | 0.44 | +2162 | +135.1 |
| MOVE AND CAST | 16 | 16 | 16 | 0.44 | +710 | +44.4 |
| FALLS SHORT | 146 | 123 | 15 | 0.42 | +73 | +4.9 |
| CASTS FROM BEHIND | 14 | 14 | 14 | 0.39 | +0 | +0.0 |
| INVITES THE FIGHT | 37 | 37 | 14 | 0.39 | +118 | +8.5 |
| MODEL FACING | 14 | 14 | 14 | 0.39 | +5967 | +426.2 |
| CASTING BLOCK | 29 | 29 | 13 | 0.36 | +344 | +26.5 |
| REDIRECT WEIGHED | 13 | 13 | 13 | 0.36 | +581 | +44.7 |
| SECOND LOOK | 13 | 13 | 13 | 0.36 | +779 | +59.9 |
| OPENS UP | 20 | 19 | 12 | 0.33 | +517 | +43.1 |
| OVERRUNS AWAY | 45 | 43 | 12 | 0.33 | +254 | +21.2 |
| NEARER NOT NEEDED | 241 | 232 | 11 | 0.31 | +392 | +35.6 |
| STOPS SHORT OF THE FLANK | 11 | 11 | 11 | 0.31 | +845 | +76.8 |
| STUCK PIVOT | 11 | 11 | 11 | 0.31 | +0 | +0.0 |
| FRIENDS SHOTS CHECKED | 10 | 10 | 10 | 0.28 | +640 | +64.0 |
| KEEPS ITS TARGET | 81 | 80 | 10 | 0.28 | +171 | +17.1 |
| MARCH ODDS | 10 | 10 | 10 | 0.28 | +63 | +6.3 |
| ONE PROMISE A TARGET | 10 | 10 | 10 | 0.28 | -538 | -53.8 |
| PIVOT GUARDS FLANK | 10 | 10 | 10 | 0.28 | -211 | -21.1 |
| REFUSING RETIRES | 39 | 39 | 10 | 0.28 | -3 | -0.3 |
| SUPPORT NARROWED | 236 | 236 | 10 | 0.28 | -443 | -44.3 |
| BEST OVERALL | 9 | 9 | 9 | 0.25 | +258 | +28.7 |
| BEST PREY | 25 | 25 | 9 | 0.25 | +166 | +18.4 |
| MANOEUVRE | 44 | 44 | 9 | 0.25 | +667 | +74.1 |
| MARCH BY THE SUM | 9 | 9 | 9 | 0.25 | +831 | +92.3 |
| ONE OBJECTIVE FORMULA | 198 | 128 | 8 | 0.22 | +229 | +28.7 |
| RESTRAINS TO SHOOT | 8 | 8 | 8 | 0.22 | +467 | +58.4 |
| SHORT GUN FORWARD | 8 | 8 | 8 | 0.22 | +0 | +0.0 |
| BEST FACING | 7 | 7 | 7 | 0.19 | +115 | +16.5 |
| BLOCKED WHEEL | 7 | 7 | 7 | 0.19 | +120 | +17.2 |
| MARCH OF THE TABLE | 7 | 7 | 7 | 0.19 | -186 | -26.6 |
| MOVES UNITS SPELL | 7 | 7 | 7 | 0.19 | +186 | +26.5 |
| PROMISE READS THE TABLE | 16 | 16 | 7 | 0.19 | -283 | -40.4 |
| WEARS DOWN | 53 | 49 | 7 | 0.19 | +378 | +54.0 |
| WHOLE FIGHT | 25 | 24 | 7 | 0.19 | +1448 | +206.9 |
| BEST PRIZE | 6 | 6 | 6 | 0.17 | -162 | -27.0 |
| BIG CHARACTER SAFETY | 6 | 6 | 6 | 0.17 | -22 | -3.6 |
| HIS CHARGE DENIED | 19 | 18 | 6 | 0.17 | +235 | +39.2 |
| NO DOUBLE ROUNDS | 108 | 101 | 6 | 0.17 | +173 | +28.8 |
| PROMISE KNOWS THE FIGHT | 30 | 19 | 6 | 0.17 | -149 | -24.9 |
| SURE REACH TOGETHER | 32 | 27 | 6 | 0.17 | +264 | +44.1 |
| THROUGH LINE OF FIRE | 6 | 6 | 6 | 0.17 | +128 | +21.3 |
| WIDER SPREAD | 174 | 165 | 6 | 0.17 | +26 | +4.4 |
| AFTERMATH IN POINTS | 5 | 5 | 5 | 0.14 | +500 | +100.0 |
| FEATURE BUFFS | 67 | 67 | 5 | 0.14 | +139 | +27.7 |
| GUN MASK | 38 | 37 | 5 | 0.14 | +241 | +48.2 |
| HIS MOVE AND SHOT | 124 | 116 | 5 | 0.14 | +25 | +5.0 |
| HIS TURN DENIED | 58 | 55 | 5 | 0.14 | +58 | +11.6 |
| HUNT IN PAIRS | 28 | 15 | 5 | 0.14 | +317 | +63.4 |
| SURE CHARGE BEATS ADVANCE | 5 | 5 | 5 | 0.14 | -76 | -15.2 |
| WAR ENGINE JOBS | 23 | 23 | 5 | 0.14 | -226 | -45.2 |
| FIGHT TO THE END | 26 | 22 | 4 | 0.11 | +272 | +68.1 |
| FOCUS FIRE | 4 | 4 | 4 | 0.11 | +228 | +57.0 |
| WHO GETS IN | 4 | 4 | 4 | 0.11 | -194 | -48.6 |
| CATCH ODDS | 3 | 3 | 3 | 0.08 | -29 | -9.7 |
| EDGE GIVE GROUND | 15 | 15 | 3 | 0.08 | +73 | +24.4 |
| HUNT ADVANCE | 8 | 8 | 3 | 0.08 | +84 | +28.1 |
| MISSILES NEXT TURN | 328 | 215 | 3 | 0.08 | +23 | +7.5 |
| PROMISE SHOT AWAY | 3 | 3 | 3 | 0.08 | -99 | -33.1 |
| STANDS TO CAST | 3 | 3 | 3 | 0.08 | +72 | +23.8 |
| AFTERMATH WITH FRIENDS | 2 | 2 | 2 | 0.06 | +102 | +50.8 |
| BACKUP TARGETS | 34 | 19 | 2 | 0.06 | +8 | +4.2 |
| BOMBING RUN | 2 | 2 | 2 | 0.06 | +108 | +53.8 |
| CARRIES OUT SET-UP | 14 | 14 | 2 | 0.06 | -118 | -59.1 |
| CONTINUE AHEAD WEIGHED | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| DEFENSIVE ARMY | 8 | 8 | 2 | 0.06 | -4 | -2.2 |
| FALL BACK GOOD ORDER | 79 | 73 | 2 | 0.06 | +95 | +47.6 |
| JOINT CHARGE PLAN | 13 | 13 | 2 | 0.06 | +529 | +264.7 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| LOST AFTER ESCAPE | 78 | 75 | 2 | 0.06 | +15 | +7.5 |
| NEXT OBJECTIVE NEARER | 14 | 14 | 2 | 0.06 | +125 | +62.4 |
| NO RALLY LEFT | 2 | 2 | 2 | 0.06 | +157 | +78.5 |
| PERIAPT WORTH | 2 | 2 | 2 | 0.06 | +108 | +54.2 |
| PURSUES BIG PREY | 2 | 2 | 2 | 0.06 | -75 | -37.3 |
| REFORMS TO MEET IT | 68 | 58 | 2 | 0.06 | +3 | +1.3 |
| SPELLS IN THE FIGHT | 32 | 29 | 2 | 0.06 | +15 | +7.7 |
| WOUNDED STAYS OUT | 3 | 3 | 2 | 0.06 | -439 | -219.6 |
| BLOWS WHERE AIMED | 25 | 23 | 1 | 0.03 | +13 | +13.2 |
| CHARGE LIST READ AGAIN | 1 | 1 | 1 | 0.03 | +17 | +16.8 |
| CHARGER SLAIN LOST | 36 | 33 | 1 | 0.03 | +10 | +9.7 |
| DEFENSIVE FLOOR | 2 | 2 | 1 | 0.03 | +58 | +58.0 |
| ELIXIR WORTH | 1 | 1 | 1 | 0.03 | +62 | +61.9 |
| FIRE AND FLEE | 1 | 1 | 1 | 0.03 | +7 | +6.6 |
| KEEP FALLS | 1 | 1 | 1 | 0.03 | +33 | +32.8 |
| KEEPS ITS PREY | 6 | 6 | 1 | 0.03 | +2 | +1.9 |
| LONE WIZARD HOLDS BACK | 10 | 10 | 1 | 0.03 | -70 | -70.5 |
| LOST CHARGE | 92 | 92 | 1 | 0.03 | +1 | +1.2 |
| NEEDED THERE | 2 | 2 | 1 | 0.03 | +0 | +0.0 |
| OWN CAST FIRST | 1 | 1 | 1 | 0.03 | -26 | -26.4 |
| STAY WEIGHED | 1 | 1 | 1 | 0.03 | +32 | +31.8 |
| STOPS | 3 | 3 | 1 | 0.03 | +2 | +1.7 |
| ALREADY CARRIED | 3 | not checked | - | - | - | - |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 25 | 25 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 50 | trace | - | - | - | - |
| CATCH FLIERS | 2 | not checked | - | - | - | - |
| CHAMPION KNOWS CHALLENGE | 10 | 10 | 0 | 0.00 | - | - |
| CHARACTER GUNS | 34 | 34 | 0 | 0.00 | - | - |
| CHARIOT NO STATIC JOB | 1 | 1 | 0 | 0.00 | - | - |
| CHARIOT WIZARD CAREFUL | 6 | 6 | 0 | 0.00 | - | - |
| CHEAP HELPER | 6 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 48 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 15 | 15 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 2 | 2 | 0 | 0.00 | - | - |
| FIGHT LIFT | 3 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 348 | not checked | - | - | - | - |
| FRIEND SHOOTS FIRST | 22 | 20 | 0 | 0.00 | - | - |
| GIVES UP | 17 | 16 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 5 | 5 | 0 | 0.00 | - | - |
| GROUND FLIERS | 2 | not checked | - | - | - | - |
| GUN FIGURES | 54 | not checked | - | - | - | - |
| HE SHOOTS OR CHARGES | 81 | 79 | 0 | 0.00 | - | - |
| HELPER ALREADY ASKED | 7 | not checked | - | - | - | - |
| HELPER UNSEEN | 4 | 4 | 0 | 0.00 | - | - |
| HILL BY ITS CHANCE | 13 | 13 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 152 | 147 | 0 | 0.00 | - | - |
| HIS FIGHT TOGETHER | 83 | 82 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 176 | 164 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 79 | 79 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 206 | 190 | 0 | 0.00 | - | - |
| HOLD ODDS | 416 | 415 | 0 | 0.00 | - | - |
| HUNT DROPPED | 5 | trace | - | - | - | - |
| HUNT KEPT | 1 | trace | - | - | - | - |
| HUNT RESULT | 10 | trace | - | - | - | - |
| HUNT THE GUNS | 10 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 10 | 8 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 18 | not checked | - | - | - | - |
| LONG SHOT | 24 | 23 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 20 | 20 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 10 | trace | - | - | - | - |
| MARCH OVER CASTS | 47 | 47 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 8 | 8 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 2 | 1 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 22 | trace | - | - | - | - |
| MOVE SPELL SPOT | 14 | not checked | - | - | - | - |
| NOT NEEDED | 12 | 12 | 0 | 0.00 | - | - |
| NOT TURNED | 229 | 229 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 37 | not checked | - | - | - | - |
| ONE CHARGE A CHARGER | 131 | 129 | 0 | 0.00 | - | - |
| OPENS A LANE | 5 | 2 | 0 | 0.00 | - | - |
| OVERRUN THREAT | 1 | not checked | - | - | - | - |
| PLAN RESULT | 2906 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 7 | 7 | 0 | 0.00 | - | - |
| PROMISE IN STEPS | 7 | 7 | 0 | 0.00 | - | - |
| RAIDS THE BAGGAGE NEXT TURN | 1 | 1 | 0 | 0.00 | - | - |
| RANDOM MOVER NO PROMISE | 7 | 7 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 55 | 55 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 21 | 20 | 0 | 0.00 | - | - |
| RUN DOWN | 91 | 83 | 0 | 0.00 | - | - |
| SAME CHARGE LATER | 1 | 1 | 0 | 0.00 | - | - |
| SCOUT SPOT | 23 | 23 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 22 | 22 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 18 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 8 | not checked | - | - | - | - |
| SET-UP MISSED | 4 | trace | - | - | - | - |
| SHOT OR CHARGE | 17 | 17 | 0 | 0.00 | - | - |
| SPELL CATCH ODDS | 1 | not checked | - | - | - | - |
| SPELL OFF EDGE | 1 | not checked | - | - | - | - |
| SPELL SETS UP CHARGE | 11 | not checked | - | - | - | - |
| SPELL WORTH | 113 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 242 | 223 | 0 | 0.00 | - | - |
| STABLE ROLE | 452 | 451 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 21 | 21 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 18 | 17 | 0 | 0.00 | - | - |
| STANDS STILL | 1455 | 1426 | 0 | 0.00 | - | - |
| STUPIDITY NEXT TURN | 7 | 6 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 71 | not checked | - | - | - | - |
| THE PROMISE ADDS | 14 | 11 | 0 | 0.00 | - | - |
| THE TABLE BINDS | 1030 | not checked | - | - | - | - |
| TURN WORTH | 12 | 12 | 0 | 0.00 | - | - |
| TWO OR MORE ARRIVE | 30 | 28 | 0 | 0.00 | - | - |
| WAITS AGAIN | 63 | 55 | 0 | 0.00 | - | - |
| WAR ENGINE CHARGES | 1 | 1 | 0 | 0.00 | - | - |
| WHAT THE JOINER ADDS | 10 | 8 | 0 | 0.00 | - | - |

### Off best figure: hmw-mine-c1e47a9-p1

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 2.89 | 15.53 | 53.8 |
| PROMISE BY ITS OWN SUM | rule | 3.78 | - | 91.3 |
| ARMY TABLE | rule | 1.89 | - | 47.1 |
| CHARGE NOW FIRST | rule | 0.72 | 0.67 | 80.7 |
| HOLDER ASSIGNMENT | rule | 0.92 | - | 20.0 |
| FALLBACK | gate | - | 0.67 | 55.0 |
| NO REASON | gate | 0.50 | - | 84.2 |
| TURN GATE | gate | - | 0.50 | 65.0 |
| CHARGE NOT DECLARED | rule | 0.06 | 0.42 | 90.1 |
| CHAFF PASSED | rule | 0.33 | 0.08 | 8.3 |
| JOINT CHARGE NOW | rule | 0.31 | - | 64.0 |
| PIVOT GUARDS FLANK | rule | 0.17 | 0.11 | 21.1 |
| SUPPORT NARROWED | rule | 0.08 | 0.19 | 44.3 |
| ONE PROMISE A TARGET | rule | 0.22 | - | 80.5 |
| CANNON PLANNED TARGET | rule | 0.14 | 0.06 | 15.5 |
| PROMISE READS THE TABLE | rule | 0.19 | - | 40.4 |
| BEST PRIZE | rule | 0.08 | 0.08 | 27.0 |
| MARCH OF THE TABLE | rule | 0.17 | - | 31.1 |
| PROMISE KNOWS THE FIGHT | rule | 0.17 | - | 24.9 |
| SURE CHARGE BEATS ADVANCE | rule | - | 0.14 | 15.2 |
| AFTERMATH BAND | gate | 0.08 | 0.03 | 1.7 |
| BIG CHARACTER SAFETY | rule | - | 0.11 | 5.5 |
| CHARGE NOW WEIGHED | rule | - | 0.11 | 42.1 |
| WAR ENGINE JOBS | rule | - | 0.11 | 56.5 |
| CATCH ODDS | rule | - | 0.08 | 9.7 |
| DEPLOY BY FIGURES | rule | 0.03 | 0.06 | 9.2 |
| LONE CHARACTER SAFE SPOT | gate | - | 0.08 | 10.4 |
| PATHS CROSS | rule | 0.03 | 0.06 | 53.7 |
| RULE SWITCHED OFF | gate | - | 0.08 | 11.2 |
| SUPPORT REQUEST | gate | - | 0.08 | 64.4 |
| WHO GETS IN | rule | 0.08 | - | 68.9 |
| CARRIES OUT SET-UP | rule | 0.03 | 0.03 | 59.1 |
| DEFENSIVE ARMY | rule | 0.06 | - | 2.2 |
| MARCH ODDS | rule | 0.06 | - | 16.7 |
| PROMISE SHOT AWAY | rule | 0.06 | - | 49.7 |
| PURSUES BIG PREY | rule | - | 0.06 | 37.3 |
| REFUSING RETIRES | rule | 0.03 | 0.03 | 0.6 |
| SAFER THAN THE JOB | rule | - | 0.06 | 9.9 |
| STANDS TO CAST | rule | - | 0.06 | 8.4 |
| WOUNDED STAYS OUT | rule | - | 0.06 | 219.6 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.03 | - | 5.4 |
| FACES THE THREAT | rule | - | 0.03 | 1.1 |
| FIGHT ORDER BAND | gate | - | 0.03 | 3.8 |
| LONE WIZARD HOLDS BACK | rule | - | 0.03 | 70.5 |
| MOVE AND CAST | rule | - | 0.03 | 31.1 |
| OWN CAST FIRST | rule | 0.03 | - | 26.4 |
| REDIRECT WEIGHED | rule | 0.03 | - | 52.6 |
| SET UP BY THE SET | rule | 0.03 | - | 30.6 |
| STOPS SHORT OF THE FLANK | rule | - | 0.03 | 1.0 |
| THROUGH LINE OF FIRE | rule | - | 0.03 | 234.8 |

### Plans: hmw-mine-c1e47a9-p1

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 3.0 | 58% | 429 | 246 | 57% |
| Mine | join | 0.7 | 92% | 22 | 0 | 0% |
| Mine | move | 28.3 | 95% | 1552 | 0 | 0% |
| Mine | shoot | 9.0 | 62% | 598 | 718 | 120% |
| Mine | support | 0.4 | 86% | 16 | 0 | 0% |
| Opponent | advance | 11.7 | 14% | 141 | 239 | 169% |
| Opponent | charge | 3.9 | 59% | 368 | 385 | 105% |
| Opponent | close in | 7.1 | 27% | 569 | 174 | 31% |
| Opponent | hold | 5.6 | 48% | 415 | 0 | 0% |
| Opponent | join | 0.8 | 100% | 35 | 0 | 0% |
| Opponent | shoot | 4.6 | 63% | 121 | 308 | 254% |
| Opponent | support | 5.8 | 91% | 40 | 0 | 0% |

### Packages: hunt the guns, hmw-mine-c1e47a9-p1

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 46 |
| Opponent | 0.3 | 10 | 0 | 20% | 20% | 10% | 2.0 | 312 | 44 | 20% | 103 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 431 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 51 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 69 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 43 |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 164 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 88 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 77 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 100 |
| Tomb Kings of Khemri | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 303 | 0 | 0% | 12 |
| Vampire Counts | 0.2 | 2 | 0 | 50% | 50% | 50% | 2.0 | 241 | 113 | 50% | 22 |
| Warriors of Chaos | 0.8 | 6 | 0 | 17% | 17% | 0% | 2.0 | 346 | 36 | 17% | 98 |
| Wood Elf Realms | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 261 | 0 | 0% | 60 |

### Battle groups: hmw-mine-c1e47a9-p1

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 1.5 | 24% | 69% | 8% | 0% | 25% | 0% | 0% | 67% | 8% |
| Opponent | REDIRECT COUNTER | 3.3 | 32% | 68% | 16% | 17% | 12% | 0% | 9% | 75% | 3% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: hmw-mine-c1e47a9-p1

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 3 | 0 (3) | 0 | 0 | 37 | 67% | 4.0 | - | 0 (1) | - | - | 0 (1) |
| Mine | Chaff | 37 | 37 (37) | 17 | 20 | 46 | 46% | 2.5 | 34 (12) | 19 (15) | 63 (10) | 45 (28) | 20 (9) |
| Mine | Character | 123 | 53 (123) | 53 | 0 | 35 | 19% | 2.4 | 56 (47) | 57 (42) | 64 (18) | 65 (59) | 49 (48) |
| Mine | Clean-up | 22 | 72 (22) | 23 | 49 | 25 | 41% | 3.6 | 91 (9) | 63 (11) | 40 (2) | 96 (12) | 45 (10) |
| Mine | Fast | 4 | 0 (4) | 0 | 0 | 0 | 25% | 2.0 | 0 (3) | 0 (1) | - | 0 (3) | 0 (1) |
| Mine | Fast Hammer | 42 | 30 (42) | 15 | 15 | 42 | 36% | 3.1 | 30 (23) | 31 (16) | 26 (3) | 30 (27) | 31 (15) |
| Mine | Hammer | 58 | 44 (58) | 23 | 21 | 42 | 16% | 2.6 | 48 (24) | 44 (27) | 25 (7) | 34 (38) | 62 (20) |
| Mine | Holder | 26 | 93 (26) | 15 | 78 | 22 | 50% | 3.0 | 78 (9) | 111 (12) | 45 (5) | 108 (16) | 69 (10) |
| Mine | Shooter | 49 | 85 (49) | 33 | 51 | 38 | 0% | 1.9 | 111 (13) | 85 (26) | 44 (10) | 113 (29) | 48 (20) |
| Mine | Support | 5 | 72 (5) | 0 | 72 | 42 | 20% | 2.8 | 0 (1) | 463 (1) | - | 124 (2) | - |
| Mine | War machine | 56 | 56 (56) | 56 | 0 | 24 | 7% | 1.5 | 39 (25) | 74 (24) | 56 (7) | 8 (7) | 62 (49) |
| Mine | Wizard | 23 | 33 (23) | 33 | 0 | 26 | 4% | 2.5 | 53 (10) | 0 (2) | 22 (5) | 48 (12) | 19 (5) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | 0 (1) | - | - | - | 0 (1) |
| Opponent | Chaff | 67 | 72 (67) | 11 | 61 | 52 | 43% | 3.0 | 45 (21) | 123 (29) | 15 (17) | 85 (45) | 40 (22) |
| Opponent | Character | 113 | 48 (113) | 47 | 1 | 34 | 25% | 2.4 | 39 (40) | 38 (45) | 91 (16) | 43 (62) | 62 (39) |
| Opponent | Clean-up | 14 | 22 (14) | 22 | 0 | 45 | 29% | 2.8 | 20 (4) | 25 (9) | 0 (1) | 36 (8) | 8 (6) |
| Opponent | Early | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Fast Hammer | 59 | 48 (59) | 30 | 17 | 44 | 24% | 2.4 | 43 (24) | 56 (26) | 36 (9) | 49 (40) | 46 (19) |
| Opponent | Fragile | 6 | 23 (6) | 23 | 0 | 66 | 33% | 2.5 | - | 0 (1) | 0 (2) | 0 (3) | - |
| Opponent | Hammer | 65 | 27 (65) | 19 | 7 | 44 | 35% | 2.6 | 30 (22) | 30 (27) | 16 (16) | 35 (42) | 11 (23) |
| Opponent | Holder | 40 | 66 (40) | 0 | 66 | 19 | 55% | 3.8 | 53 (13) | 86 (23) | 13 (4) | 106 (19) | 38 (21) |
| Opponent | Shooter | 34 | 72 (34) | 12 | 60 | 40 | 6% | 1.5 | 67 (11) | 91 (17) | 5 (6) | 71 (17) | 72 (17) |
| Opponent | Support | 2 | 0 (2) | 0 | 0 | 50 | 50% | 6.0 | 0 (1) | - | 0 (1) | 0 (1) | 0 (1) |
| Opponent | War machine | 13 | 113 (13) | 113 | 0 | 29 | 8% | 1.0 | 156 (9) | 0 (2) | 74 (2) | 51 (2) | 123 (11) |
| Opponent | Wizard | 23 | 15 (23) | 15 | 0 | 39 | 9% | 2.4 | 32 (8) | 0 (10) | 0 (2) | 31 (8) | 0 (12) |

### Charged fights: hmw-mine-c1e47a9-p1

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 5 | 336 | 0 | 0.8 | 1.0 | 0 | 47 | -47 | 0 of 4 | 1 of 4 | - | -47 |
| Mine | Chaos Dwarfs | 3 | 78 | 345 | 1.0 | 1.7 | 345 | 40 | +305 | 2 of 3 | 2 of 3 | +188 | +540 |
| Mine | Dwarfen Mountain Holds | 4 | 264 | 43 | 1.0 | 1.2 | 43 | 0 | +43 | 1 of 4 | 3 of 4 | +0 | +57 |
| Mine | Empire of Man | 5 | 390 | 223 | 1.6 | 1.1 | 140 | 24 | +116 | 2 of 8 | 6 of 8 | +0 | +132 |
| Mine | Grand Cathay | 4 | 586 | 339 | 3.0 | 1.2 | 113 | 54 | +58 | 7 of 12 | 8 of 12 | +145 | +51 |
| Mine | High Elf Realms | 4 | 188 | 737 | 4.8 | 1.2 | 155 | 29 | +126 | 7 of 19 | 15 of 19 | +56 | +134 |
| Mine | Kingdom of Bretonnia | 1 | 0 | 409 | 3.0 | 1.0 | 136 | 33 | +103 | 2 of 3 | 1 of 3 | - | +103 |
| Mine | Lizardmen | 1 | 66 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Mine | Ogre Kingdoms | 1 | 0 | 0 | 4.0 | 1.0 | 0 | 167 | -167 | 2 of 4 | 1 of 4 | - | -167 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 597 | 4.0 | 1.0 | 149 | 0 | +149 | 0 of 4 | 4 of 4 | - | +149 |
| Mine | Skaven | 2 | 93 | 189 | 2.5 | 1.0 | 76 | 0 | +76 | 0 of 5 | 4 of 5 | - | +76 |
| Mine | Tomb Kings of Khemri | 2 | 62 | 265 | 3.5 | 1.0 | 76 | 89 | -14 | 2 of 7 | 4 of 7 | - | -14 |
| Mine | Vampire Counts | 2 | 0 | 378 | 6.0 | 1.0 | 63 | 19 | +44 | 3 of 12 | 11 of 12 | - | +44 |
| Mine | Warriors of Chaos | 1 | 0 | 160 | 4.0 | 1.0 | 40 | 0 | +40 | 1 of 4 | 4 of 4 | - | +40 |
| **Mine** | all armies | 36 | 233 | 263 | 2.5 | 1.1 | 106 | 37 | +69 | 29 of 89 | 64 of 89 | +90 | +67 |
| Opponent | Beastmen Brayherds | 1 | 0 | 130 | 2.0 | 3.0 | 65 | 26 | +39 | 0 of 2 | 2 of 2 | +39 | - |
| Opponent | Dwarfen Mountain Holds | 1 | 1294 | 112 | 1.0 | 1.0 | 112 | 0 | +112 | 0 of 1 | 1 of 1 | - | +112 |
| Opponent | Empire of Man | 1 | 372 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Grand Cathay | 1 | 0 | 604 | 4.0 | 1.2 | 151 | 0 | +151 | 4 of 4 | 3 of 4 | +185 | +140 |
| Opponent | High Elf Realms | 2 | 114 | 1176 | 4.5 | 1.4 | 261 | 0 | +261 | 4 of 9 | 8 of 9 | +453 | +108 |
| Opponent | Lizardmen | 1 | 0 | 299 | 3.0 | 1.0 | 100 | 47 | +53 | 2 of 3 | 2 of 3 | - | +53 |
| Opponent | Ogre Kingdoms | 2 | 109 | 112 | 4.0 | 1.4 | 28 | 57 | -28 | 4 of 8 | 4 of 8 | -92 | -7 |
| Opponent | Orc & Goblin Tribes | 2 | 0 | 600 | 3.5 | 1.0 | 172 | 71 | +101 | 5 of 7 | 6 of 7 | - | +101 |
| Opponent | Skaven | 2 | 0 | 0 | 0.5 | 1.0 | 0 | 0 | +0 | 0 of 1 | 1 of 1 | - | +0 |
| Opponent | Tomb Kings of Khemri | 4 | 115 | 968 | 6.0 | 1.3 | 161 | 43 | +118 | 12 of 24 | 19 of 24 | +269 | +68 |
| Opponent | Vampire Counts | 6 | 167 | 168 | 3.5 | 1.2 | 48 | 68 | -20 | 7 of 21 | 12 of 21 | +69 | -48 |
| Opponent | Warriors of Chaos | 7 | 6 | 177 | 1.4 | 1.2 | 124 | 43 | +81 | 6 of 10 | 6 of 10 | -130 | +133 |
| Opponent | Wood Elf Realms | 6 | 53 | 306 | 2.3 | 1.5 | 131 | 23 | +108 | 6 of 14 | 12 of 14 | +165 | +86 |
| **Opponent** | all armies | 36 | 109 | 358 | 2.9 | 1.3 | 124 | 42 | +82 | 50 of 104 | 76 of 104 | +163 | +55 |

### Effective charges: hmw-mine-c1e47a9-p1

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 0 | 0 | 1 (net -52) | 1 (net +0) | 0 | 1 (net -85) | 1 | 33% (1 of 3) |
| Mine | Chaos Dwarfs | 3 | 0 | 0 | 0 | 1 (net +230) | 1 (net +145) | 1 (net +540) | 0 | 0% (0 of 3) |
| Mine | Dwarfen Mountain Holds | 4 | 0 | 0 | 0 | 2 (net +56) | 0 | 2 (net +30) | 0 | 0% (0 of 4) |
| Mine | Empire of Man | 8 | 3 (net +221) | 1 (net +109) | 1 (net +0) | 1 (net +155) | 0 | 2 (net +0) | 0 | 12% (1 of 8) |
| Mine | Grand Cathay | 12 | 1 (net +778) | 2 (net +98) | 1 (net -205) | 3 (net +48) | 1 (net +60) | 3 (net +59) | 1 | 9% (1 of 11) |
| Mine | High Elf Realms | 19 | 2 (net +372) | 0 | 3 (net -38) | 3 (net +101) | 2 (net +15) | 5 (net +232) | 4 | 20% (3 of 15) |
| Mine | Kingdom of Bretonnia | 3 | 0 | 1 (net +156) | 0 | 0 | 1 (net +153) | 1 (net +0) | 0 | 0% (0 of 3) |
| Mine | Ogre Kingdoms | 4 | 1 (net -633) | 0 | 1 (net +0) | 1 (net +0) | 0 | 0 | 1 | 33% (1 of 3) |
| Mine | Orc & Goblin Tribes | 4 | 0 | 0 | 0 | 0 | 2 (net +101) | 0 | 2 | 0% (0 of 2) |
| Mine | Skaven | 5 | 1 (net +0) | 0 | 2 (net +116) | 1 (net +0) | 0 | 1 (net +147) | 0 | 40% (2 of 5) |
| Mine | Tomb Kings of Khemri | 7 | 2 (net -130) | 1 (net +0) | 0 | 0 | 1 (net +125) | 1 (net -195) | 2 | 0% (0 of 5) |
| Mine | Vampire Counts | 12 | 1 (net +0) | 0 | 2 (net +86) | 2 (net +0) | 1 (net +120) | 2 (net +142) | 4 | 25% (2 of 8) |
| Mine | Warriors of Chaos | 4 | 0 | 0 | 0 | 0 | 2 (net +0) | 2 (net +80) | 0 | 0% (0 of 4) |
| Opponent | Beastmen Brayherds | 2 | 0 | 0 | 0 | 0 | 1 (net +65) | 1 (net +13) | 0 | 0% (0 of 2) |
| Opponent | Dwarfen Mountain Holds | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +112) | 0 | 0% (0 of 1) |
| Opponent | Grand Cathay | 4 | 1 (net +185) | 0 | 0 | 2 (net +93) | 0 | 1 (net +233) | 0 | 0% (0 of 4) |
| Opponent | High Elf Realms | 9 | 1 (net +634) | 0 | 0 | 2 (net +434) | 3 (net +207) | 2 (net +114) | 1 | 0% (0 of 8) |
| Opponent | Lizardmen | 3 | 1 (net +0) | 0 | 1 (net +48) | 0 | 0 | 1 (net +110) | 0 | 33% (1 of 3) |
| Opponent | Ogre Kingdoms | 8 | 1 (net +0) | 0 | 3 (net -108) | 1 (net +0) | 0 | 0 | 3 | 60% (3 of 5) |
| Opponent | Orc & Goblin Tribes | 7 | 1 (net +529) | 0 | 0 | 2 (net +115) | 0 | 1 (net -104) | 3 | 0% (0 of 4) |
| Opponent | Skaven | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +0) | 0 | 0% (0 of 1) |
| Opponent | Tomb Kings of Khemri | 24 | 0 | 1 (net +141) | 6 (net +25) | 6 (net +157) | 3 (net +48) | 6 (net +165) | 2 | 27% (6 of 22) |
| Opponent | Vampire Counts | 21 | 6 (net -12) | 0 | 1 (net -50) | 3 (net -261) | 4 (net +5) | 5 (net +79) | 2 | 5% (1 of 19) |
| Opponent | Warriors of Chaos | 10 | 0 | 0 | 3 (net -87) | 1 (net +249) | 0 | 5 (net +112) | 1 | 33% (3 of 9) |
| Opponent | Wood Elf Realms | 14 | 2 (net +0) | 1 (net -107) | 3 (net +178) | 3 (net +82) | 2 (net +192) | 3 (net +152) | 0 | 21% (3 of 14) |

### Charged fights, damage counted: hmw-mine-c1e47a9-p1

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 11 | 314 | 213 | +117 | 268 | 136 | +131 | +41.8 |
| Mine | 50-54% | 5 | 270 | 265 | +92 | 112 | 69 | +43 | +15.8 |
| Mine | Effective (55-75%) | 11 | 169 | 194 | +3 | 55 | 48 | +7 | +4.2 |
| Mine | 76-89% | 15 | 277 | 175 | +63 | 92 | 28 | +64 | +23.2 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 21 | 288 | 192 | +107 | 140 | 22 | +118 | +41.0 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 11 | 487 | 95 | +76 | 125 | 46 | +78 | +16.1 |
| Mine | No odds | 15 | 326 | 183 | +21 | 99 | 53 | +46 | +14.0 |
| Mine | All fights | 89 | 305 | 183 | +69 | 127 | 51 | +75 | +24.8 |
| Opponent | Long shot (under 50%) | 13 | 239 | 264 | +98 | 169 | 83 | +86 | +36.1 |
| Opponent | 50-54% | 2 | 285 | 318 | +17 | 70 | 54 | +17 | +6.0 |
| Opponent | Effective (55-75%) | 17 | 408 | 272 | +6 | 159 | 122 | +36 | +8.9 |
| Opponent | 76-89% | 20 | 303 | 230 | +97 | 187 | 87 | +100 | +32.9 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 27 | 297 | 201 | +111 | 156 | 44 | +112 | +37.7 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 13 | 426 | 93 | +95 | 105 | 18 | +87 | +20.4 |
| Opponent | No odds | 12 | 244 | 202 | +78 | 114 | 38 | +75 | +30.8 |
| Opponent | All fights | 104 | 319 | 215 | +82 | 151 | 66 | +85 | +26.6 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| hmw-mine-c1e47a9-p1 | move | 315 | 78 (25%) | 49 (16%) | 50 (16%) | 187 (59%) |
| hmw-mine-c1e47a9-p1 | objective | 255 | 46 (18%) | 32 (13%) | 30 (12%) | 179 (70%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0102, L0118, L0135, L2531, L2730 |
| Charmed Shield | Opponent | L0524, L1224, L1527, L1625, L2025, L2127, L2934 |
| Clockwork Compass | Mine | L1224 |
| Clockwork Compass | Opponent | L0612 |
| Elixir of Power | Mine | L1114, L1131, L1923 |
| Elixir of Power | Opponent | L0319, L1319 |
| Fistful of Laurels | Mine | L1823 |
| Fistful of Laurels | Opponent | L0118, L0218 |
| Horn of the Wild Hunt | Opponent | L0733 |
| Invocation of Nehek | Mine | L2531, L2730 |
| Invocation of Nehek | Opponent | L0524, L1224, L1527, L1625, L2025, L2127 |
| Opal Amulet | Mine | L1431 |
| Opal Amulet | Opponent | L1114 |
| Periapt of Soul Exchange | Mine | L2025, L2127 |
| Periapt of Soul Exchange | Opponent | L0421, L1021 |
| Ring of Doom | Mine | L0218, L0235, L1114, L1131, L1224, L1527 |
| Ring of Doom | Opponent | L0102, L0612, L0733, L1131, L1431, L2231, L2531 |
| Ring of Jet | Mine | L1021, L1114, L1131, L1224 |
| Ring of Jet | Opponent | L0612 |
| Standard of the Fell Warrior | Mine | L1319, L1335 |
| Standard of the Fell Warrior | Opponent | L0913 |
| Storm Daemon (Renegade 2.0) | Mine | L2127 |
| Storm Daemon (Renegade 2.0) | Opponent | L0421, L1021 |
| Twice-Blessed Armour | Mine | L0717, L0733, L1021 |
| Witch Hunter's Ward | Mine | L0717, L0733, L0823 |
| Witch Hunter's Ward | Opponent | L0508 |

# Doctrine scorecard: hmw-opp-c1e47a9-p1

### Scorecard: hmw-opp-c1e47a9-p1

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0102 | 6 | 1 | Mine | no | 4 | 4 | 1 | 1 | 1 | 0 | 0 | 95 |
| L0102 | 6 | 1 | Opponent | no | 0 | 1 | 3 | 1 | 0 | 0 | 0 | 170 |
| L0118 | 4 | 1 | Mine | no | 1 | - | 0 | 2 | 0 | 0 | 0 | 65 |
| L0118 | 4 | 1 | Opponent | no | 0 | 1 | 1 | 2 | 1 | 0 | 0 | 68 |
| L0135 | 3 | 1 | Mine | no | 2 | - | 0 | 2 | 0 | 0 | 0 | 0 |
| L0135 | 3 | 1 | Opponent | yes | 6 | 1 | 5 | 2 | 0 | 0 | 0 | 0 |
| L0218 | 2 | 1 | Mine | - | - | 3 | 1 | 5 | 0 | 0 | 0 | 281 |
| L0218 | 2 | 1 | Opponent | - | - | 2 | 1 | 1 | 0 | 0 | 0 | 0 |
| L0235 | 1 | 1 | Mine | no | 2 | 4 | 1 | 3 | 0 | 0 | 0 | 170 |
| L0235 | 1 | 1 | Opponent | no | 5 | 3 | 1 | 1 | 0 | 0 | 0 | 0 |
| L0319 | 1 | 1 | Mine | no | 4 | - | 0 | 1 | 0 | 0 | 0 | 760 |
| L0319 | 1 | 1 | Opponent | no | 7 | 2 | 1 | 3 | 0 | 0 | 0 | 0 |
| L0405 | 3 | 1 | Mine | no | 8 | 2 | 5 | 3 | 1 | 0 | 0 | 0 |
| L0405 | 3 | 1 | Opponent | no | 7 | - | 0 | 1 | 0 | 0 | 0 | 1019 |
| L0421 | 1 | 1 | Mine | no | 0 | 1 | 7 | 1 | 0 | 0 | 0 | 0 |
| L0421 | 1 | 1 | Opponent | no | 0 | - | 0 | 4 | 1 | 0 | 0 | 355 |
| L0508 | 4 | 1 | Mine | no | 3 | 5 | 1 | 1 | 0 | 0 | 0 | 686 |
| L0508 | 4 | 1 | Opponent | no | 1 | - | 0 | 2 | 0 | 0 | 0 | 220 |
| L0524 | 2 | 1 | Mine | - | - | 2 | 1 | 1 | 0 | 0 | 0 | 548 |
| L0524 | 2 | 1 | Opponent | - | - | 4 | 2 | 3 | 1 | 0 | 0 | 0 |
| L0612 | 6 | 1 | Mine | no | 0 | - | 0 | 0 | 0 | 0 | 0 | 615 |
| L0612 | 6 | 1 | Opponent | no | 4 | 2 | 2 | 0 | 0 | 0 | 0 | 0 |
| L0628 | 4 | 1 | Mine | no | 0 | 4 | 1 | 3 | 0 | 0 | 0 | 798 |
| L0628 | 4 | 1 | Opponent | no | 6 | - | 0 | 1 | 0 | 0 | 0 | 0 |
| L0717 | 3 | 1 | Mine | yes | 8 | 2 | 4 | 0 | 0 | 0 | 0 | 420 |
| L0717 | 3 | 1 | Opponent | no | 9 | 4 | 7 | 0 | 1 | 0 | 0 | 0 |
| L0733 | 1 | 1 | Mine | no | 2 | 2 | 3 | 0 | 0 | 0 | 0 | 420 |
| L0733 | 1 | 1 | Opponent | no | 1 | 2 | 2 | 2 | 1 | 0 | 0 | 0 |
| L0823 | 1 | 1 | Mine | no | 1 | 6 | 2 | 0 | 0 | 0 | 0 | 515 |
| L0823 | 1 | 1 | Opponent | no | 0 | 2 | 2 | 3 | 0 | 0 | 0 | 0 |
| L0913 | 1 | 1 | Mine | no | 0 | 3 | 2 | 2 | 0 | 0 | 0 | 420 |
| L0913 | 1 | 1 | Opponent | no | 16 | 2 | 3 | 0 | 0 | 0 | 0 | 0 |
| L0930 | 6 | 1 | Mine | no | 1 | 4 | 1 | 2 | 0 | 0 | 0 | 685 |
| L0930 | 6 | 1 | Opponent | no | 6 | 3 | 1 | 1 | 0 | 0 | 0 | 0 |
| L1021 | 1 | 1 | Mine | no | 0 | 1 | 1 | 0 | 0 | 0 | 0 | 501 |
| L1021 | 1 | 1 | Opponent | no | 2 | - | 1 | 7 | 0 | 0 | 0 | 290 |
| L1114 | 4 | 1 | Mine | no | 9 | 2 | 1 | 0 | 0 | 0 | 0 | 330 |
| L1114 | 4 | 1 | Opponent | no | 5 | 2 | 2 | 0 | 0 | 0 | 0 | 0 |
| L1131 | 3 | 1 | Mine | no | 0 | - | 4 | 0 | 0 | 0 | 0 | 330 |
| L1131 | 3 | 1 | Opponent | no | 0 | - | 0 | 3 | 2 | 0 | 0 | 170 |
| L1224 | 6 | 1 | Mine | no | 5 | 3 | 2 | 0 | 0 | 0 | 0 | 330 |
| L1224 | 6 | 1 | Opponent | no | 2 | 2 | 1 | 3 | 0 | 0 | 0 | 0 |
| L1319 | 5 | 1 | Mine | no | - | 2 | 2 | 3 | 0 | 0 | 0 | 302 |
| L1319 | 5 | 1 | Opponent | yes | - | 1 | 3 | 1 | 0 | 0 | 0 | 0 |
| L1335 | 3 | 1 | Mine | no | 9 | 3 | 1 | 0 | 1 | 0 | 0 | 140 |
| L1335 | 3 | 1 | Opponent | no | 2 | 6 | 1 | 2 | 0 | 0 | 0 | 499 |
| L1431 | 3 | 1 | Mine | no | 2 | 2 | 2 | 0 | 0 | 0 | 0 | 0 |
| L1431 | 3 | 1 | Opponent | no | 3 | - | 1 | 1 | 1 | 0 | 0 | 657 |
| L1527 | 3 | 1 | Mine | yes | 5 | 2 | 1 | 0 | 1 | 0 | 0 | 126 |
| L1527 | 3 | 1 | Opponent | no | 2 | 2 | 7 | 2 | 0 | 0 | 0 | 0 |
| L1625 | 5 | 1 | Mine | no | - | 3 | 3 | 0 | 0 | 0 | 0 | 200 |
| L1625 | 5 | 1 | Opponent | yes | - | 3 | 5 | 3 | 0 | 0 | 0 | 0 |
| L1723 | 1 | 1 | Mine | no | 3 | 2 | 4 | 0 | 1 | 0 | 0 | 49 |
| L1723 | 1 | 1 | Opponent | yes | 4 | 2 | 4 | 0 | 2 | 0 | 0 | 0 |
| L1823 | 5 | 1 | Mine | yes | - | - | 4 | 1 | 0 | 0 | 0 | 413 |
| L1823 | 5 | 1 | Opponent | yes | - | 2 | 7 | 0 | 0 | 0 | 0 | 66 |
| L1923 | 3 | 1 | Mine | no | 0 | 3 | 4 | 0 | 1 | 0 | 0 | 161 |
| L1923 | 3 | 1 | Opponent | no | 7 | 1 | 5 | 0 | 0 | 0 | 0 | 0 |
| L2025 | 3 | 1 | Mine | yes | 9 | - | 0 | 0 | 1 | 0 | 0 | 210 |
| L2025 | 3 | 1 | Opponent | no | 6 | 2 | 5 | 2 | 0 | 0 | 0 | 0 |
| L2127 | 3 | 1 | Mine | no | 3 | - | 0 | 4 | 1 | 0 | 0 | 500 |
| L2127 | 3 | 1 | Opponent | no | 0 | 2 | 4 | 3 | 0 | 0 | 0 | 0 |
| L2231 | 5 | 1 | Mine | yes | - | 3 | 8 | 1 | 0 | 0 | 0 | 0 |
| L2231 | 5 | 1 | Opponent | no | - | 2 | 2 | 1 | 1 | 0 | 0 | 340 |
| L2335 | 1 | 1 | Mine | no | 0 | 2 | 3 | 2 | 0 | 0 | 0 | 0 |
| L2335 | 1 | 1 | Opponent | no | 3 | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L2531 | 5 | 1 | Mine | yes | - | 5 | 2 | 1 | 0 | 0 | 0 | 0 |
| L2531 | 5 | 1 | Opponent | yes | - | 1 | 3 | 3 | 0 | 0 | 0 | 340 |
| L2730 | 6 | 1 | Mine | no | 4 | 6 | 7 | 2 | 0 | 0 | 0 | 0 |
| L2730 | 6 | 1 | Opponent | no | 0 | 3 | 2 | 2 | 0 | 0 | 0 | 0 |
| L2934 | 6 | 1 | Mine | no | 6 | 2 | 3 | 2 | 1 | 0 | 0 | 170 |
| L2934 | 6 | 1 | Opponent | no | 4 | 2 | 3 | 2 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 18% | 3.1 | 3.0 | 2.3 | 1.2 | 0.2 | 0.0 | 0.0 | 284.4 |
| **Average** | | | Opponent | 18% | 3.7 | 2.2 | 2.5 | 1.8 | 0.3 | 0.0 | 0.0 | 116.5 |

### KPIs: hmw-opp-c1e47a9-p1

Rules off - Mine only: FIVE ACTION, LIKELY CHARGE, FALLS SHORT, TIME ON OUR SIDE, FEATURE BUFFS, GETS AWAY CHANCE, GUN MASK, RUN DOWN, FOUR ROUNDS, CHARGE LOSSES, CHARACTER GUNS, STAND AND SHOOT, FALL BACK GOOD ORDER, AFTERMATH IN POINTS, NEXT CHARGE BY LIST, NEXT OBJECTIVE NEARER, NO DOUBLE ROUNDS, SCALED CHANCE, LEGAL CHARGES ONLY, SHOT OR CHARGE, MOVE CARRIES THE JOB, MOVE TO CHARGE COMPUTED, RISK BY HIS FIGURE, SHOT RISK POINTS, ONE TARGET A SHOOTER, ONE CHARGE A CHARGER, HIS CHARGE LIST, HIS SHOT LIST, HIS MOVE AND SHOT, HIS LEGAL MOVES, HIS TURN DENIED, THE PROMISE ADDS, HE SHOOTS OR CHARGES, HIS RANDOM MOVE, HIS CHARGE DENIED, SAME CHARGE LATER, FRIEND CHARGES FIRST, FRIEND SHOOTS FIRST, WAITS AGAIN, WOUNDS ON THE RANKS, THE PROMISED MOVE, MARCH BY THE SUM, FIGHT TO THE END, THE DEARER SUM KEEPS ITS PLAN, HIS OWN BEST MOVE, TIED UP BY THE SUM, REFORMS TO MEET IT, STANDS FOR A REASON, HOLDER ASSIGNMENT, ARMY TABLE, MOVE ORDER, CHARGE LIST READ AGAIN, PROMISE READS THE TABLE, SUPPORT WORKED OUT, WHO GETS IN, THE TABLE BINDS, HIS ONE MOVE, PROMISE BY ITS OWN SUM, SECOND LOOK, LOST AFTER ESCAPE, PROMISE KNOWS THE FIGHT, SPOT AS THE GAME MOVES, ONE PROMISE A TARGET, WHAT THE JOINER ADDS, DENIED BY THE FIGHT, HIS MOVE AS HE DECIDES, ROUNDS AFTER TERROR, MARCH OF THE TABLE, PROMISE HOLDS THE SPOT, PROMISE SHOT AWAY, OWN CAST FIRST, PROMISE IN STEPS, STUPIDITY NEXT TURN, PROMISE BELOW ZERO, HIS MOVE WHY, THE TABLE AGAIN, SHOTS AFTER THE MOVES, SET FIGHT, JOINT CHARGE NOW, JOINT ON THE TABLE, JOINT LOOK BACK, AFTERMATH WITH FRIENDS, HIS FIGHT TOGETHER, SET UP BY THE SET, QUARTER ODDS, CHEAPEST HOLDER, NEARER NOT NEEDED, NO FORCED ADVANCE, HARD STAY DROPPED.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 25% (42 of 169) | 3% (5 of 179) | 14% (47 of 348) |
| Winner chose to follow up after the loser gave ground |  | 100% (60 of 60); on the table 100% | 86% (32 of 37); on the table 89% | 95% (92 of 97); on the table 96% |
| Winner chose to pursue after the loser fell back in good order |  | 88% (7 of 8); on the table 100% | 82% (18 of 22); on the table 86% | 83% (25 of 30); on the table 90% |
| Winner chose to pursue after the loser fled |  | 66% (19 of 29); on the table 72% | 72% (26 of 36); on the table 75% | 69% (45 of 65); on the table 74% |
| Winner chose to follow up or pursue (all three) |  | 89% (86 of 97); on the table 92% | 80% (76 of 95); on the table 83% | 84% (162 of 192); on the table 88% |
| Magic missiles tried each own turn | 50%+ | 38% (126 of 330) | 30% (64 of 210) | 35% (190 of 540) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 46% (126 of 272) | 37% (64 of 174) | 43% (190 of 446) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 46% (19 of 41) | 50% (20 of 40) | 48% (39 of 81) |
| Points that never fought | lower | 43% (30762 of 71484) | 45% (32275 of 71889) | 44% (63037 of 143373) |
|   infantry points that never fought | lower | 61% (10300 of 16863) | 61% (8201 of 13348) | 61% (18501 of 30211) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 60% (168 of 279) | 61% (179 of 295) | 60% (347 of 574) |
| Bound items with a magic missile used (at least once a game) |  | 91% (20 of 22); 1.8 uses a game | 80% (16 of 20); 1.4 uses a game | 86% (36 of 42); 1.6 uses a game |
| Bound items with another spell used |  | 56% (9 of 16); 0.6 uses a game | 50% (4 of 8); 0.1 uses a game | 54% (13 of 24); 0.4 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 58% (11 of 19); 0.3 uses a game | 58% (7 of 12); 0.2 uses a game | 58% (18 of 31); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 55% (32586 of 59666) | 54% (34001 of 62699) | 54% (66587 of 122365) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 2.1 (36%) | 1.9 (48%) | 4.0 (41%) |
| MARCHED: its unit marched | 1.4 (25%) | 0.8 (19%) | 2.2 (23%) |
| CHARGED: its unit charged | 0.4 (6%) | 0.0 (1%) | 0.4 (4%) |
| IN COMBAT: engaged in combat | 1.1 (19%) | 0.4 (9%) | 1.4 (15%) |
| REAR RANK: in a rear rank | 0.2 (3%) | 0.1 (2%) | 0.2 (3%) |
| GONE: slain | 0.6 (10%) | 0.4 (9%) | 0.9 (9%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (0%) | 0.3 (7%) | 0.3 (3%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.1 (2%) | 0.1 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (1%) | 0.1 (1%) | 0.1 (1%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.1 (2%) | 0.1 (1%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.6 | 1.4 | 1.2 | 5.3 | 0.5 | 1.8 |
| not cast | 3.4 | 3.0 | 3.5 | 9.7 | 1.8 | 22.2 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) | 0.0 (0%) | 1.3 (6%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.8 (60%) | 0.4 (11%) | 4.0 (41%) | 0.3 (18%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.2 (23%) | 0.4 (23%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.4 (4%) | 0.1 (3%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.2 (5%) | 0.2 (8%) | 0.5 (15%) | 1.4 (15%) | 0.3 (18%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.2 (7%) | 0.3 (11%) | 0.4 (12%) | 0.2 (3%) | 0.0 (0%) | 0.0 (0%) |
| NO CASTS LEFT: every cast used on other spells | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (2%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (1%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (1%) |
| GONE: slain | 0.6 (18%) | 0.3 (9%) | 0.6 (18%) | 0.9 (9%) | 0.2 (11%) | 1.8 (8%) |
| OFF THE TABLE: off the table or not arrived | 0.1 (2%) | 0.1 (3%) | 0.0 (0%) | 0.3 (3%) | 0.0 (0%) | 0.2 (1%) |
| STUPIDITY: Stupidity | 0.1 (2%) | 0.0 (1%) | 0.0 (1%) | 0.1 (1%) | 0.0 (0%) | 0.2 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) | 0.1 (1%) | 0.5 (26%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.2 (65%) | 0.2 (7%) | 1.4 (42%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 18.4 (83%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.9 a game | 0.5 a game | 0.7 a game |
| stood (cast and not dispelled) | 81% (26 of 32) | 71% (12 of 17) | 78% (38 of 49) |
| the unit moved after it | 62% (16 of 26) | 75% (9 of 12) | 66% (25 of 38) |
| it charged on its next turn | 0% (0 of 26) | 0% (0 of 12) | 0% (0 of 38) |
| the enemy charged it first | 31% (8 of 26) | 8% (1 of 12) | 24% (9 of 38) |
| it fought by the end of its next turn | 31% (8 of 26) | 8% (1 of 12) | 24% (9 of 38) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 26) | 8% (1 of 12) | 3% (1 of 38) |
| none of these (no charge, no fight, no charge escaped) | 69% (18 of 26) | 83% (10 of 12) | 74% (28 of 38) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 65% (599 of 925) | 59% (373 of 636) | 62% (972 of 1561) |
|   cavalry | 55% (37 of 67) | 71% (92 of 129) | 66% (129 of 196) |
|   character | 56% (67 of 119) | 33% (41 of 126) | 44% (108 of 245) |
|   chariot | 59% (47 of 79) | 73% (22 of 30) | 63% (69 of 109) |
|   infantry | 63% (205 of 325) | 60% (146 of 243) | 62% (351 of 568) |
|   monster | 63% (31 of 49) | 44% (15 of 34) | 55% (46 of 83) |
|   war machine | 74% (212 of 286) | 77% (57 of 74) | 75% (269 of 360) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.0 (22%) | 1.4 (19%) | 3.4 (21%) |
| CHARGED: it charged | 0.9 (10%) | 1.4 (19%) | 2.4 (14%) |
| FLEEING: it fled or was fleeing | 0.2 (2%) | 0.1 (2%) | 0.3 (2%) |
| IN COMBAT: it fought this turn or the last | 0.4 (4%) | 0.4 (5%) | 0.8 (5%) |
| MOVED: a war machine that moved | 0.0 (0%) | 0.3 (4%) | 0.3 (2%) |
| NO TARGET IN RANGE | 2.4 (27%) | 2.0 (28%) | 4.5 (27%) |
| ONLY IN COMBAT: the only targets were in combat | 0.5 (5%) | 0.6 (8%) | 1.1 (6%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 2.1 (24%) | 0.7 (10%) | 2.9 (17%) |
| SHELTERED: the target was sheltered | 0.2 (3%) | 0.2 (2%) | 0.4 (3%) |
| STUPIDITY | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR | 0.2 (2%) | 0.1 (2%) | 0.4 (2%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 5.1 | 1.3 | 79% | 5.8 pts | 30 pts |
| character | 3.2 | 1.3 | 72% | 10.6 pts | 34 pts |
| chariot | 2.0 | 1.7 | 57% | 15.4 pts | 31 pts |
| infantry | 14.2 | 5.1 | 75% | 8.9 pts | 126 pts |
| monster | 1.5 | 0.6 | 74% | 7.9 pts | 12 pts |
| war machine | 7.5 | 5.6 | 63% | 19.1 pts | 143 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.8 | 5.2 | 4.5 |
| Charges that made contact a game | 2.8 | 3.9 | 3.4 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.90 declared, 0.62 contact (21 units) | 0.44 declared, 0.38 contact (16 units) | 0.70 declared, 0.51 contact (37 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.88 declared, 0.75 contact (8 units) | 1.18 declared, 1.00 contact (11 units) | 1.05 declared, 0.89 contact (19 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.44 declared, 0.32 contact (255 units) | 0.58 declared, 0.42 contact (292 units) | 0.51 declared, 0.38 contact (547 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 49% (34 of 70) | 67% (14 of 21) | 38% (3 of 8) | 52% (51 of 99) |
| Character in a unit | 96% (44 of 46) | 74% (20 of 27) | 50% (2 of 4) | 86% (66 of 77) |
| Character on its own | 83% (34 of 41) | 61% (20 of 33) | 23% (14 of 62) | 50% (68 of 136) |
| Chariot | 75% (12 of 16) | 50% (5 of 10) | - | 65% (17 of 26) |
| Infantry | 52% (46 of 89) | 58% (21 of 36) | 100% (2 of 2) | 54% (69 of 127) |
| Monster | 53% (17 of 32) | 70% (7 of 10) | - | 57% (24 of 42) |
| Monstrous | 91% (10 of 11) | 57% (8 of 14) | - | 72% (18 of 25) |
| War Machines | 80% (33 of 41) | 100% (1 of 1) | - | 81% (34 of 42) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 6 | 83% (20 of 24); on the table 92% | 38% (53 of 138) | 55% | 55% (18 of 33) | 100% (9 of 9); 4.3 uses a game | 67% (2 of 3); 1.3 uses a game | 89% (8 of 9); 1.3 uses a game |
| Chaos Dwarfs | 3 | 100% (8 of 8); on the table 100% | 17% (4 of 24) | 55% | 50% (12 of 24) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 0.3 uses a game |
| Dwarfen Mountain Holds | 5 | 83% (5 of 6); on the table 83% | - | 73% | 71% (29 of 41) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 6 | 75% (9 of 12); on the table 83% | 44% (16 of 36) | 48% | 64% (41 of 64) | 0.0 uses a game | 100% (2 of 2); 1.2 uses a game | 50% (2 of 4); 0.3 uses a game |
| Grand Cathay | 5 | 88% (15 of 17); on the table 88% | 37% (40 of 108) | 44% | 52% (23 of 44) | 100% (12 of 12); 8.0 uses a game | 0% (0 of 1); 0.0 uses a game | 20% (1 of 5); 0.2 uses a game |
| High Elf Realms | 6 | 87% (13 of 15); on the table 87% | 37% (11 of 30) | 24% | 39% (19 of 49) | 80% (4 of 5); 2.5 uses a game | 50% (9 of 18); 2.0 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | 100% (3 of 3); on the table 100% | - | 23% | 83% (5 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Lizardmen | 2 | 100% (9 of 9); on the table 100% | - | 17% | 57% (8 of 14) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 3 | 89% (8 of 9); on the table 89% | 42% (5 of 12) | 42% | 62% (13 of 21) | 67% (2 of 3); 2.3 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 3 | 100% (4 of 4); on the table 100% | 33% (12 of 36) | 28% | 75% (18 of 24) | 0.0 uses a game | 0.0 uses a game | 33% (1 of 3); 0.3 uses a game |
| Skaven | 4 | 100% (6 of 6); on the table 100% | 43% (13 of 30) | 50% | 62% (21 of 34) | 100% (3 of 3); 2.0 uses a game | 0.0 uses a game | 50% (2 of 4); 0.5 uses a game |
| Tomb Kings of Khemri | 6 | 76% (19 of 25); on the table 80% | 17% (2 of 12) | 36% | 43% (13 of 30) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 8 | 70% (23 of 33); on the table 76% | 30% (16 of 54) | 39% | 66% (33 of 50) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 8 | 90% (9 of 10); on the table 90% | 27% (8 of 30) | 53% | 74% (55 of 74) | 100% (4 of 4); 1.2 uses a game | 0.0 uses a game | 50% (1 of 2); 0.1 uses a game |
| Wood Elf Realms | 6 | 100% (11 of 11); on the table 100% | 33% (10 of 30) | 39% | 59% (39 of 66) | 33% (2 of 6); 1.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |

Flank and rear charges a unit could have turned to face (hmw-opp-c1e47a9-p1, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 40% (31) | 57% (30) | 47% (61) |
| ...free all their last turn and able to turn (per game) | 0.47 | 0.53 | 1.00 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.19 | 0.14 | 0.33 |
| ...with the charger already in that arc before they moved (per game) | 0.33 | 0.36 | 0.69 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 1.36 | 0.08 | 1.44 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.53 | 0.03 | 0.56 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 5.61 | 0.33 | 5.94 |

### Quality by phase: hmw-opp-c1e47a9-p1

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.2 | 2.7 |
| Strategy | Charge objectives carried out (made contact) | 50% (63 of 127) | 46% (78 of 170) |
| Strategy | Shoot objectives carried out (shot that target) | 48% (199 of 417) | 44% (65 of 147) |
| Strategy | Close-in objectives charged next turn | 16% (31 of 193) | - |
| Strategy | Support requests answered (helper made contact too) | 53% (10 of 19) | 61% (20 of 33) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (3 of 3) | 50% (1 of 2) |
| Strategy | Hexes on a unit its side charged or shot that turn | 56% (5 of 9) | 50% (7 of 14) |
| Strategy | Joined characters whose unit fought | 23% (14 of 60) | 27% (14 of 52) |
| Strategy | Lone characters that fought | 78% (67 of 86) | 74% (62 of 84) |
| Movement | Charges halted short of contact | 0.1 | 0.1 |
| Movement | Idle units | 1.2 | 1.8 |
| Movement | Points that never moved of their own | 284.4 | 116.5 |
| Movement | Fights charged into per game | 2.4 | 3.2 |
| Movement | Charges with odds: long shots (under 50%) | 5 of 76, net +60 | 24 of 94, net +54 |
| Movement | Charges with odds: sweet spot (55-75%) | 20 of 76, net +137 | 10 of 94, net +47 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 10 of 76, net +62 | 7 of 94, net +96 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 18 of 76, net +66 | 30 of 94, net +181 |
| Shooting | Shots by shooting units (incl. breath weapons) | 11.6 | 9.4 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 45% (189 of 416) | 54% (182 of 340) |
| Shooting | Points destroyed by shooting units | 56.4 | 41.5 |
| Shooting | War machine shots | 5.9 | 1.6 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 46% (97 of 212) | 53% (30 of 57) |
| Shooting | Points destroyed by war machines | 38.2 | 27.7 |
| Magic | Magic missiles cast | 2.4 | 1.2 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 30% (26 of 88) | 50% (21 of 42) |
| Magic | Wounds caused by magic missiles | 6.0 | 1.6 |
| Magic | Wounds caused by other spells | 0.9 | 0.9 |
| Magic | Points destroyed by magic (all spells) | 67.2 | 11.4 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.7 / 0.3 / 0.9 / 0.1 | 1.6 / 0.5 / 0.3 / 0.2 |
| Combat | Points destroyed in combat | 243.6 | 430.4 |
| Combat | Points run down | 28.0 | 99.8 |
| Combat | Net points per charged fight, damage counted | +78 | +115 |
| Combat | Net per 100 charger points, damage counted | +26.3 | +39.4 |
| Combat | First round won (charged fights) | 79% | 76% |
| Combat | Net points per charged fight | +73 | +117 |
| Combat | Net points per supported fight / lone fight | +72 / +73 | +237 / +91 |
| Combat | Charged fights on a top-3 enemy unit | 28 of 87 | 47 of 114 |
| Game | Points lost | 616.2 | 610.9 |
| Game | VP from objectives | 656.1 | 720.0 |
| Game | Lone holders (player turns) | 3.1 | 3.7 |

- Mine won / drew / lost: 12 / 8 / 16 of 36 ended games (of 36); mean margin (Mine - Opponent) -76 VP
- The side that went first won 12 of 28 games with a winner
- Points traded per game (both sides' losses): 1227
- Games not ended: 0; findings 4, warnings 0

### Opponent rules: hmw-opp-c1e47a9-p1

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 5.1 | 1.0 | +0.0 | 0.0 | 0.0 |
| ADVANCE WORTH | 5.6 | -141.9 | 241.5 | 60.2 | - | - | - | - |
| AFTERMATH IN POINTS | - | - | - | - | 0.2 | +21.3 | 0.0 | 0.0 |
| AFTERMATH WITH FRIENDS | - | - | - | - | 0.2 | +28.9 | 0.0 | 0.0 |
| ARMY TABLE | - | - | - | - | 18.3 | +305.5 | 0.0 | 289.1 |
| ARRIVAL HUNT | - | - | - | - | 0.0 | +0.1 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.5 | +0.0 | 0.0 | 23.9 | 0.6 | +0.0 | 0.0 | 2.6 |
| BACKUP TARGETS | 0.6 | +2.5 | 0.0 | 26.2 | 0.1 | +0.1 | 0.0 | 1.4 |
| BEST FACING | 0.3 | +7.5 | 0.0 | 1.4 | 0.0 | +2.5 | 0.0 | 0.0 |
| BEST FIRST | 1.5 | +77.9 | 25.6 | 24.9 | - | - | - | - |
| BEST MOVE FOR SHOOTERS | 1.0 | +78.9 | 0.0 | 2.7 | - | - | - | - |
| BEST OVERALL | 0.2 | +7.4 | 0.0 | 15.0 | - | - | - | - |
| BEST PREY | 0.6 | +47.7 | 15.8 | 8.1 | - | - | - | - |
| BEST PRIZE | 0.1 | -4.4 | 0.0 | 0.0 | 0.1 | -8.0 | 8.4 | 16.6 |
| BIG CHARACTER SAFETY | 0.2 | -0.3 | 0.0 | 15.0 | - | - | - | - |
| BLOCKED CHARGE SKIPPED | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |
| BLOCKED WHEEL | 0.2 | +9.1 | 0.0 | 0.0 | - | - | - | - |
| BLOWS WHERE AIMED | 0.4 | -42.9 | 53.5 | 1.4 | 0.3 | -47.4 | 11.3 | 16.6 |
| BOMBING RUN | 0.0 | +0.9 | 0.0 | 0.0 | - | - | - | - |
| BOUND ASSAILMENT | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CANNON PLAN MISSED | 0.6 | +0.0 | 68.0 | 11.0 | 0.2 | +0.0 | 34.2 | 2.6 |
| CANNON PLANNED TARGET | 5.2 | +139.3 | 239.4 | 61.0 | 1.6 | +49.1 | 76.1 | 9.9 |
| CANNON SIGHT KEPT | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT COUNTER | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CARRIES OUT SET-UP | 0.1 | -1.1 | 0.0 | 0.0 | 0.0 | -1.3 | 2.7 | 0.0 |
| CAST JOB | 0.8 | +19.4 | 40.2 | 19.5 | 0.4 | +1.5 | 25.4 | 0.0 |
| CASTER AWAY FROM SCREEN | 0.3 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.5 | +40.5 | 54.9 | 0.0 | 0.5 | +49.1 | 35.4 | 0.0 |
| CASTS AFTER FRIENDS | 0.7 | +0.0 | 0.0 | 28.0 | 0.3 | +0.0 | 0.0 | 7.6 |
| CASTS FROM BEHIND | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.1 | +0.5 | 0.0 | 0.0 | - | - | - | - |
| CATCH ODDS | 0.0 | +1.6 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | 1.3 | +61.1 | 0.0 | 28.6 | 1.7 | +117.0 | 0.0 | 47.9 |
| CHAFF PASSED | 0.1 | -0.1 | 0.0 | 0.0 | 0.2 | -0.3 | 5.9 | 1.7 |
| CHAMPION KNOWS CHALLENGE | 0.1 | -0.6 | 6.4 | 4.2 | 0.1 | -4.8 | 22.7 | 10.9 |
| CHAMPION TAKES THE CHALLENGE | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |
| CHARACTER GUNS | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| CHARGE LIST READ AGAIN | - | - | - | - | 0.1 | +29.5 | 16.1 | 1.9 |
| CHARGE LOSSES | - | - | - | - | 9.7 | -541.1 | 0.0 | 300.8 |
| CHARGE NOT DECLARED | 0.2 | +0.0 | 9.9 | 1.7 | 0.2 | +0.0 | 5.2 | 2.5 |
| CHARGE NOW FIRST | 2.1 | +0.0 | 168.7 | 43.2 | 2.4 | +0.0 | 227.2 | 74.2 |
| CHARGE NOW WEIGHED | 0.3 | -26.0 | 3.2 | 12.3 | - | - | - | - |
| CHARGER SLAIN LOST | 0.4 | -7.3 | 21.1 | 10.2 | 0.6 | -8.7 | 36.5 | 22.0 |
| CHARIOT WIZARD CAREFUL | 0.1 | +0.0 | 0.0 | 11.0 | - | - | - | - |
| CHEAP HELPER | 0.1 | +0.0 | 0.0 | 3.2 | - | - | - | - |
| COMBAT PIVOT | 0.4 | +0.0 | 15.9 | 21.2 | 0.4 | +0.0 | 36.6 | 12.9 |
| CONTINUE AHEAD WEIGHED | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | 0.8 | +76.6 | 13.9 | 14.8 | 0.2 | +38.9 | 17.3 | 21.1 |
| COVER ONCE | 7.1 | -544.8 | 0.0 | 167.5 | 4.7 | -355.5 | 0.0 | 84.5 |
| DEFENSIVE ARMY | 0.2 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| DENIED BY THE FIGHT | - | - | - | - | 1.4 | -22.9 | 97.7 | 28.3 |
| DEPLOY BY FIGURES | 8.1 | +16.6 | 0.0 | 25.3 | 7.7 | +72.8 | 0.0 | 9.5 |
| EDGE GIVE GROUND | 0.2 | +4.6 | 27.6 | 0.0 | 0.3 | +4.3 | 32.5 | 0.0 |
| ELIXIR WORTH | - | - | - | - | 0.0 | +0.3 | 0.0 | 0.0 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 1.4 | +79.1 | 0.0 | 54.9 | 0.1 | +6.3 | 0.0 | 5.9 |
| FALL BACK GOOD ORDER | - | - | - | - | 3.7 | +8.3 | 316.4 | 95.2 |
| FALLBACK BY WORTH | 4.4 | +36.1 | 0.0 | 51.4 | 0.4 | +0.8 | 0.0 | 3.4 |
| FALLS SHORT | - | - | - | - | 13.6 | +217.0 | 0.0 | 185.0 |
| FEATURE BUFFS | - | - | - | - | 0.3 | +5.4 | 0.0 | 11.2 |
| FIGHT LIFT | 0.0 | +0.1 | 2.5 | 0.0 | - | - | - | - |
| FIGHT TO THE END | - | - | - | - | 1.4 | +18.8 | 105.0 | 38.2 |
| FIRE IN ORDER | 0.2 | +0.0 | 0.0 | 14.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| FIVE ACTION | - | - | - | - | 81.1 | +5042.7 | 911.8 | 1009.9 |
| FLANK NOT WEIGHED | 4.8 | +0.0 | 0.0 | 143.1 | 4.5 | +0.0 | 0.0 | 121.2 |
| FOCUS FIRE | 0.0 | +2.4 | 3.2 | 0.0 | 0.1 | +0.5 | 0.0 | 5.1 |
| FOLLOW UP WEIGHED | 1.0 | +77.5 | 0.0 | 27.6 | 0.7 | +122.1 | 0.0 | 10.9 |
| FOUR ROUNDS | - | - | - | - | 5.0 | +281.0 | 414.0 | 102.1 |
| FRIEND CHARGES FIRST | - | - | - | - | 0.1 | -16.1 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | - | - | - | - | 0.5 | -9.1 | 0.0 | 1.4 |
| FRIENDS SHOTS CHECKED | 0.2 | +6.0 | 0.0 | 1.7 | 0.2 | +19.6 | 0.0 | 1.9 |
| GIVES UP | 0.3 | -3.3 | 24.2 | 13.8 | 0.4 | -11.4 | 38.9 | 3.5 |
| GIVES UP ITS SCREEN | 0.0 | -0.2 | 0.0 | 1.7 | 0.0 | -0.1 | 2.9 | 0.0 |
| GROUND FLIERS | 0.0 | +0.9 | 0.0 | 0.0 | 0.0 | +0.2 | 0.0 | 0.0 |
| GUN FIGURES | 0.9 | +9.7 | 35.7 | 1.8 | 0.5 | +14.0 | 2.9 | 17.2 |
| GUN MASK | - | - | - | - | 0.3 | -2.7 | 0.0 | 9.0 |
| HARD STAY DROPPED | - | - | - | - | 1.3 | +0.0 | 0.0 | 1.8 |
| HE SHOOTS OR CHARGES | - | - | - | - | 2.9 | +0.0 | 0.0 | 137.5 |
| HELPER ALREADY ASKED | 0.1 | +0.0 | 3.3 | 0.0 | - | - | - | - |
| HELPER UNSEEN | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 10.7 | 0.0 |
| HIS CHARGE DENIED | - | - | - | - | 0.8 | +41.4 | 58.3 | 21.2 |
| HIS CHARGE LIST | - | - | - | - | 4.8 | +0.0 | 0.0 | 76.9 |
| HIS FIGHT TOGETHER | - | - | - | - | 1.6 | -71.8 | 0.0 | 75.6 |
| HIS LEGAL MOVES | - | - | - | - | 5.2 | +0.0 | 0.0 | 77.5 |
| HIS MOVE AND SHOT | - | - | - | - | 2.9 | -50.6 | 0.0 | 111.0 |
| HIS MOVE AS HE DECIDES | - | - | - | - | 32.5 | +12.3 | 575.9 | 0.0 |
| HIS MOVE WHY | 32.2 | +0.0 | 0.0 | 507.2 | - | - | - | - |
| HIS ONE MOVE | - | - | - | - | 20.5 | +57.4 | 11.8 | 86.4 |
| HIS OWN BEST MOVE | - | - | - | - | 2.1 | +0.0 | 0.0 | 22.6 |
| HIS RANDOM MOVE | - | - | - | - | 4.9 | +0.0 | 0.0 | 67.9 |
| HIS SHOT LIST | - | - | - | - | 41.4 | +2096.0 | 0.0 | 603.7 |
| HIS TURN DENIED | - | - | - | - | 2.7 | +90.8 | 234.7 | 52.8 |
| HOLD ODDS | - | - | - | - | 13.6 | +0.0 | 0.0 | 148.9 |
| HOLDER ASSIGNMENT | - | - | - | - | 12.6 | +1242.2 | 0.0 | 112.6 |
| HOLDER AT DEPLOYMENT | 1.1 | +192.3 | 0.0 | 0.0 | - | - | - | - |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.8 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 8.3 | -136.3 | 430.9 | 174.5 | 4.1 | -159.4 | 335.7 | 72.6 |
| HORN WORTH | - | - | - | - | 0.0 | +0.2 | 0.0 | 0.0 |
| HUNT ADVANCE | 0.1 | +0.1 | 0.0 | 0.0 | - | - | - | - |
| HUNT DROPPED | 0.0 | +0.0 | 5.9 | 0.0 | - | - | - | - |
| HUNT IN PAIRS | 0.4 | +26.8 | 0.0 | 0.0 | 0.6 | +23.6 | 0.0 | 5.4 |
| HUNT KEPT | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HUNT RESULT | 0.1 | +0.0 | 5.9 | 0.0 | 0.1 | +19.3 | 0.0 | 0.0 |
| HUNT THE GUNS | 0.1 | +21.5 | 0.0 | 3.1 | 0.1 | +21.9 | 8.6 | 0.0 |
| IDLE COST | 15.6 | -261.9 | 0.0 | 220.4 | 9.8 | -138.5 | 0.0 | 113.1 |
| INVITES THE FIGHT | 1.1 | +9.2 | 28.0 | 14.3 | - | - | - | - |
| JOINT CHARGE NOW | - | - | - | - | 1.8 | +56.8 | 166.5 | 19.4 |
| JOINT CHARGE PLAN | 0.1 | +3.1 | 0.0 | 0.0 | - | - | - | - |
| JOINT KNOWS CHALLENGE | 0.1 | -6.6 | 3.8 | 0.0 | 0.1 | -3.5 | 16.5 | 4.3 |
| JOINT ON THE TABLE | - | - | - | - | 0.1 | +16.6 | 6.9 | 0.0 |
| KEEP FALLS | 0.1 | +0.3 | 0.0 | 0.0 | 0.1 | +2.3 | 0.0 | 0.0 |
| KEEPS ITS PREY | 0.1 | +0.2 | 4.4 | 0.0 | - | - | - | - |
| KEEPS ITS TARGET | 2.0 | +59.2 | 121.2 | 49.6 | - | - | - | - |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KILLS COUNT | 1.3 | +56.2 | 82.5 | 39.7 | - | - | - | - |
| KILLS COUNT NEXT TURN | 5.1 | +177.9 | 177.8 | 93.8 | - | - | - | - |
| LANE BY FIGURES | 0.8 | +25.7 | 0.0 | 0.0 | 0.8 | +41.5 | 0.0 | 16.6 |
| LEGAL CHARGES ONLY | - | - | - | - | 5.6 | +0.0 | 348.1 | 176.7 |
| LONE CHARACTER SAFE SPOT | 0.2 | +5.0 | 12.1 | 27.0 | 0.1 | +5.2 | 0.0 | 0.0 |
| LONE WIZARD HOLDS BACK | 0.1 | +0.0 | 0.0 | 5.3 | - | - | - | - |
| LONE WIZARD KEPT IN | 0.7 | +50.8 | 0.0 | 0.0 | 0.2 | +24.5 | 0.0 | 0.0 |
| LONG SHOT | 0.2 | -0.4 | 11.2 | 1.0 | 0.5 | +5.3 | 8.3 | 8.7 |
| LOST AFTER ESCAPE | - | - | - | - | 2.8 | +3.5 | 221.6 | 67.2 |
| LOST CHARGE | 2.1 | -27.2 | 73.2 | 82.2 | - | - | - | - |
| LURE BY WHAT IT DRAWS | 0.3 | -34.9 | 0.0 | 5.9 | 0.2 | -15.3 | 0.0 | 13.7 |
| MAKE SURE TOGETHER | 0.6 | +41.3 | 0.0 | 38.6 | - | - | - | - |
| MANOEUVRE | 0.2 | +4.5 | 0.0 | 1.8 | 0.8 | -0.1 | 0.0 | 2.9 |
| MARCH AT ESCAPER | 0.1 | +0.1 | 0.0 | 0.0 | 0.2 | +0.2 | 0.0 | 0.0 |
| MARCH BY THE SUM | - | - | - | - | 0.2 | +26.0 | 0.0 | 0.0 |
| MARCH CHECK | 0.3 | +21.7 | 0.0 | 0.0 | 0.7 | +42.0 | 0.0 | 0.0 |
| MARCH ODDS | 0.2 | +10.7 | 7.1 | 0.0 | - | - | - | - |
| MARCH OF THE TABLE | - | - | - | - | 0.2 | +5.7 | 0.0 | 4.5 |
| MARCH OVER CASTS | 0.8 | +59.5 | 0.0 | 16.8 | 0.8 | +70.0 | 0.0 | 16.5 |
| MAX FOR POSITIONING | 6.3 | +118.4 | 0.0 | 129.6 | 2.7 | +55.3 | 0.0 | 40.8 |
| MISSILES IN THE MOVE | 4.6 | +141.5 | 0.0 | 77.1 | 3.5 | +74.2 | 0.0 | 70.8 |
| MISSILES NEXT TURN | 5.4 | +115.4 | 0.0 | 90.6 | 4.4 | +41.0 | 0.0 | 78.8 |
| MODEL FACING | 0.2 | +71.3 | 0.0 | 6.7 | - | - | - | - |
| MONSTER WIZARD ROAMS | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE AND CAST | 0.4 | +17.2 | 0.0 | 0.0 | - | - | - | - |
| MOVE ORDER | - | - | - | - | 2.9 | +0.0 | 27.2 | 12.8 |
| MOVE SPELL IN RANGE | 0.1 | +1.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.4 | -26.5 | 0.0 | 9.9 | 0.2 | -5.8 | 0.0 | 15.2 |
| MOVE SPELL SPOT | 0.2 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE | 3.6 | +221.2 | 124.5 | 99.9 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | - | - | - | - | 9.0 | +869.7 | 0.0 | 51.1 |
| MOVES UNITS SPELL | 0.1 | +3.4 | 0.0 | 0.0 | 0.1 | +1.8 | 0.0 | 0.0 |
| NEARER NOT NEEDED | - | - | - | - | 5.7 | +246.3 | 0.0 | 53.2 |
| NEEDED THERE | 0.1 | +24.0 | 5.8 | 0.0 | - | - | - | - |
| NEXT CHARGE BY LIST | - | - | - | - | 8.2 | -341.1 | 42.2 | 89.8 |
| NEXT OBJECTIVE NEARER | - | - | - | - | 0.3 | -25.4 | 0.0 | 9.6 |
| NO DOUBLE ROUNDS | - | - | - | - | 3.9 | -159.7 | 305.0 | 97.9 |
| NOT NEEDED | 0.3 | -8.1 | 17.4 | 1.4 | - | - | - | - |
| NOT TURNED | 5.6 | +104.9 | 0.0 | 132.7 | 0.3 | -5.2 | 0.0 | 6.8 |
| NOT WORTH A CAST | 1.0 | -0.8 | 0.0 | 0.0 | 0.2 | -0.3 | 0.0 | 0.0 |
| OFF BEST | 16.4 | -678.6 | 0.0 | 294.3 | 4.3 | -206.8 | 11.7 | 41.0 |
| ONE CHARGE A CHARGER | - | - | - | - | 4.1 | +0.0 | 0.0 | 112.8 |
| ONE FIGHT FORMULA | 8.4 | -159.4 | 20.6 | 172.2 | 5.8 | -131.7 | 0.0 | 70.6 |
| ONE OBJECTIVE FORMULA | 2.6 | -84.8 | 0.0 | 37.9 | 3.4 | +5.4 | 0.0 | 49.8 |
| ONE PROMISE A TARGET | - | - | - | - | 0.2 | -16.4 | 0.0 | 1.8 |
| ONE TARGET A SHOOTER | - | - | - | - | 31.8 | +886.3 | 0.0 | 395.8 |
| OPENS A LANE | 0.4 | +1.0 | 39.8 | 3.6 | - | - | - | - |
| OPENS UP | 0.2 | +14.9 | 12.4 | 12.3 | 0.4 | +29.4 | 19.9 | 16.6 |
| OVERRUNS AWAY | 0.2 | +5.1 | 22.2 | 1.7 | 0.6 | +25.7 | 62.3 | 2.8 |
| OWN CAST FIRST | - | - | - | - | 0.0 | -0.0 | 0.0 | 0.0 |
| PATHS CROSS | 2.4 | +161.9 | 0.0 | 26.8 | 0.6 | +10.9 | 0.0 | 12.6 |
| PERIAPT WORTH | 0.0 | +3.5 | 0.0 | 0.0 | 0.0 | +3.4 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.1 | -1.1 | 0.0 | 1.5 | 0.1 | -1.8 | 0.0 | 6.5 |
| PLAN RESULT | 38.9 | +1149.2 | 1085.2 | 811.2 | 40.2 | +629.1 | 354.9 | 782.6 |
| PROMISE BELOW ZERO | - | - | - | - | 0.4 | +0.0 | 0.0 | 0.0 |
| PROMISE BY ITS OWN SUM | - | - | - | - | 9.3 | -281.4 | 0.0 | 18.7 |
| PROMISE HOLDS THE SPOT | - | - | - | - | 0.0 | +1.8 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | - | - | - | - | 1.0 | -1.9 | 0.0 | 3.7 |
| PROMISE READS THE TABLE | - | - | - | - | 0.5 | -16.0 | 0.0 | 3.3 |
| PROMISE SHOT AWAY | - | - | - | - | 0.1 | -1.5 | 0.0 | 0.0 |
| PURSUES BIG PREY | 0.1 | -3.9 | 0.0 | 0.0 | 0.1 | -7.1 | 0.0 | 0.0 |
| QUARTER ODDS | - | - | - | - | 7.9 | +1244.0 | 125.9 | 101.9 |
| RAIDS THE BAGGAGE NEXT TURN | 0.0 | +3.3 | 0.0 | 0.0 | - | - | - | - |
| RANDOM MOVE BY FIGURES | 1.1 | +15.9 | 0.0 | 4.0 | 1.1 | +41.3 | 0.0 | 57.9 |
| RANDOM MOVER NO PROMISE | 0.2 | -9.5 | 7.4 | 0.0 | - | - | - | - |
| REDIRECT BY WHAT IT STOPS | 0.6 | -13.4 | 0.0 | 18.8 | 1.3 | -33.8 | 0.0 | 21.5 |
| REDIRECT COUNTER | 2.2 | +149.9 | 0.0 | 35.4 | 3.0 | +205.1 | 0.0 | 51.6 |
| REDIRECT WEIGHED | 0.2 | +2.8 | 4.0 | 0.0 | 0.2 | -3.8 | 5.2 | 8.7 |
| REFORMS TO MEET IT | - | - | - | - | 2.2 | -68.7 | 0.0 | 1.4 |
| REFUSING RETIRES | 0.4 | +0.0 | 0.0 | 23.8 | 0.4 | +0.0 | 0.0 | 9.2 |
| RESERVE FALL BACK | 0.4 | +15.0 | 0.0 | 3.5 | 0.4 | +25.7 | 0.0 | 9.4 |
| RESTRAINS TO SHOOT | 0.0 | +0.2 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | 1.9 | +79.8 | 144.4 | 57.6 | 3.4 | +15.3 | 275.8 | 67.0 |
| RISK BY HIS FIGURE | - | - | - | - | 21.4 | -344.1 | 0.0 | 477.3 |
| RISK ONCE | 2.5 | +55.8 | 27.5 | 127.3 | - | - | - | - |
| ROUNDS AFTER TERROR | - | - | - | - | 1.5 | -40.5 | 160.4 | 34.7 |
| RUN DOWN | - | - | - | - | 3.8 | -42.6 | 312.2 | 77.3 |
| SAFER THAN THE JOB | 0.5 | +26.4 | 0.0 | 17.1 | 0.0 | +0.8 | 0.0 | 0.0 |
| SCOUT SPOT | 0.4 | +0.9 | 0.0 | 1.5 | 0.3 | +0.7 | 0.0 | 1.9 |
| SCOUT WAITS | 0.4 | +0.0 | 0.0 | 1.5 | 0.3 | +0.0 | 0.0 | 1.9 |
| SCREEN BY WHAT IT SAVES | 0.2 | -24.5 | 0.0 | 0.0 | 0.8 | -28.0 | 0.0 | 5.0 |
| SEARCH SPOT | 2.6 | +118.4 | 0.0 | 38.5 | 0.4 | +13.0 | 0.0 | 13.4 |
| SECOND LOOK | - | - | - | - | 0.3 | +19.4 | 16.8 | 17.8 |
| SELF MOVE SPELL | 0.1 | +12.4 | 0.0 | 31.0 | 0.3 | -0.7 | 0.0 | 0.0 |
| SET UP BY THE SET | - | - | - | - | 3.1 | +202.0 | 0.0 | 17.6 |
| SET UP TOGETHER | 0.9 | +50.9 | 0.0 | 38.6 | 0.0 | +2.8 | 0.0 | 0.0 |
| SET-UP ANY TARGET | 0.3 | +40.8 | 2.9 | 5.3 | 0.0 | +0.8 | 0.0 | 0.0 |
| SET-UP MISSED | - | - | - | - | 0.0 | +4.6 | 0.0 | 0.0 |
| SHOOTER COUNTED ONCE | 0.2 | -0.3 | 0.0 | 0.0 | 0.1 | -0.3 | 0.0 | 1.2 |
| SHOOTERS IN TWO RANKS | 0.4 | +0.9 | 0.0 | 0.0 | 0.2 | +0.6 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.8 | +70.2 | 73.3 | 6.1 | 1.2 | +65.2 | 73.0 | 16.1 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| SHOT OR CHARGE | - | - | - | - | 0.3 | -12.7 | 30.0 | 0.0 |
| SHOT RISK POINTS | - | - | - | - | 21.7 | +201.1 | 0.0 | 390.7 |
| SHOTS AFTER THE MOVES | - | - | - | - | 1.8 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 14.8 | +490.7 | 0.0 | 183.2 | 9.9 | +318.0 | 0.0 | 137.1 |
| SPELL SETS UP CHARGE | 0.4 | +88.0 | 2.9 | 5.3 | 0.1 | +15.6 | 0.0 | 0.0 |
| SPELL WORTH | 1.1 | +18.4 | 62.5 | 60.0 | 2.0 | +30.9 | 20.7 | 27.2 |
| SPELLS IN THE FIGHT | 0.5 | -5.1 | 26.1 | 21.4 | 0.7 | -13.5 | 23.7 | 22.4 |
| SPOT AS THE GAME MOVES | - | - | - | - | 10.1 | +0.0 | 0.0 | 134.2 |
| STABLE ROLE | 11.6 | +0.0 | 259.3 | 169.6 | - | - | - | - |
| STAND AND SHOOT | - | - | - | - | 0.9 | -10.2 | 65.5 | 19.5 |
| STANDS FOR A REASON | - | - | - | - | 1.1 | +0.0 | 31.7 | 3.7 |
| STANDS STILL | - | - | - | - | 22.9 | +0.0 | 497.9 | 168.4 |
| STANDS TO CAST | 0.0 | +6.7 | 0.0 | 0.0 | - | - | - | - |
| STAY WEIGHED | 0.2 | +10.4 | 0.0 | 0.0 | - | - | - | - |
| STAY WORTH | 20.0 | +57.3 | 355.9 | 170.1 | 13.8 | +128.2 | 258.0 | 160.7 |
| STOPS | 0.0 | +0.1 | 0.0 | 3.1 | 0.1 | +2.0 | 8.6 | 0.0 |
| STOPS SHORT OF THE FLANK | 0.4 | +17.8 | 0.0 | 0.0 | - | - | - | - |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 8.8 |
| STUPIDITY NEXT TURN | - | - | - | - | 0.6 | +0.0 | 0.0 | 0.0 |
| SUPPORT NARROWED | 5.5 | -63.8 | 248.8 | 116.0 | 0.6 | +0.0 | 73.2 | 5.2 |
| SUPPORT WORKED OUT | - | - | - | - | 4.5 | +158.2 | 0.0 | 34.4 |
| SUPPORTS | 4.1 | +69.5 | 180.0 | 86.7 | - | - | - | - |
| SURE CHARGE BEATS ADVANCE | 0.0 | -1.0 | 0.0 | 0.0 | - | - | - | - |
| SURE REACH TOGETHER | 0.4 | +1.9 | 11.9 | 0.0 | 0.4 | +2.1 | 0.0 | 2.5 |
| THE DEARER SUM KEEPS ITS PLAN | - | - | - | - | 1.4 | +0.0 | 0.0 | 20.8 |
| THE PROMISE ADDS | - | - | - | - | 0.3 | -16.5 | 0.0 | 0.0 |
| THE PROMISED MOVE | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | - | - | - | - | 32.6 | +0.0 | 0.0 | 378.6 |
| THROUGH LINE OF FIRE | 0.3 | +10.3 | 0.0 | 4.9 | - | - | - | - |
| TIED UP BY THE SUM | - | - | - | - | 0.8 | +76.9 | 52.3 | 21.8 |
| TIME ON OUR SIDE | - | - | - | - | 14.3 | +153.3 | 30.6 | 103.2 |
| TURN WORTH | 0.4 | -32.3 | 37.1 | 0.0 | - | - | - | - |
| TWO OR MORE ARRIVE | 0.2 | +0.9 | 0.0 | 27.6 | - | - | - | - |
| WAIT AFTER COSTS | 7.5 | -354.1 | 220.9 | 158.9 | - | - | - | - |
| WAITS AGAIN | - | - | - | - | 1.9 | +0.0 | 0.0 | 13.1 |
| WALKS TO THE FIGHT | 2.0 | +18.3 | 41.7 | 25.2 | - | - | - | - |
| WAR ENGINE CHARGES | 0.0 | +4.7 | 0.0 | 0.0 | - | - | - | - |
| WAR ENGINE JOBS | 0.6 | +0.0 | 11.1 | 13.2 | 0.1 | +0.0 | 0.0 | 0.0 |
| WEARS DOWN | 1.2 | +45.7 | 105.6 | 16.6 | - | - | - | - |
| WHAT THE JOINER ADDS | - | - | - | - | 0.4 | -7.7 | 55.1 | 2.9 |
| WHO GETS IN | - | - | - | - | 0.2 | +6.9 | 30.1 | 5.4 |
| WHO HITS BACK | 0.1 | +1.5 | 0.0 | 0.0 | 0.2 | +38.3 | 0.0 | 4.9 |
| WHOLE FIGHT | 0.2 | +3.9 | 34.2 | 7.4 | 0.2 | +2.9 | 27.6 | 1.4 |
| WHOLE FIGHT GAIN | 0.4 | +41.9 | 23.8 | 4.2 | 0.2 | +18.3 | 29.3 | 5.4 |
| WIDER SPREAD | 2.1 | -7.0 | 143.9 | 61.3 | 3.4 | -7.8 | 269.2 | 51.3 |
| WOUNDED STAYS OUT | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WOUNDS ON THE RANKS | - | - | - | - | 2.4 | +203.1 | 0.0 | 81.8 |

### Rule changes: hmw-opp-c1e47a9-p1

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 744 | 744 | 744 | 20.67 | -31873 | -42.8 |
| HIS MOVE AS HE DECIDES | 1171 | 1171 | 729 | 20.25 | +0 | +0.0 |
| HIS MOVE WHY | 1160 | 1160 | 611 | 16.97 | +0 | +0.0 |
| ARMY TABLE | 659 | 659 | 504 | 14.00 | +8564 | +17.0 |
| HOLDER ASSIGNMENT | 454 | 454 | 427 | 11.86 | +22754 | +53.3 |
| HIS SHOT LIST | 1489 | 1417 | 385 | 10.69 | +8614 | +22.4 |
| DEPLOY BY FIGURES | 569 | 569 | 346 | 9.61 | +4652 | +13.4 |
| ONE TARGET A SHOOTER | 1143 | 1085 | 242 | 6.72 | +3218 | +13.3 |
| LEGAL CHARGES ONLY | 200 | 200 | 200 | 5.56 | +0 | +0.0 |
| FIVE ACTION | 2918 | 2802 | 166 | 4.61 | +11327 | +68.2 |
| THE TABLE AGAIN | 216 | 216 | 158 | 4.39 | +0 | +0.0 |
| HIS ONE MOVE | 738 | 715 | 154 | 4.28 | +0 | +0.0 |
| MOVE TO CHARGE COMPUTED | 325 | 288 | 137 | 3.81 | +6674 | +48.7 |
| SHOT RISK POINTS | 780 | 746 | 135 | 3.75 | +3637 | +26.9 |
| PROMISE BY ITS OWN SUM | 334 | 334 | 112 | 3.11 | -10130 | -90.5 |
| PATHS CROSS | 107 | 107 | 107 | 2.97 | +6222 | +58.1 |
| SEARCH SPOT | 108 | 108 | 105 | 2.92 | +4732 | +45.1 |
| MOVE ORDER | 103 | 103 | 103 | 2.86 | +0 | +0.0 |
| SHOTS IN THE MOVE | 890 | 700 | 92 | 2.56 | +2393 | +26.0 |
| TIME ON OUR SIDE | 514 | 460 | 88 | 2.44 | +257 | +2.9 |
| ARTILLERY RE-ROLL WEIGHED | 76 | 76 | 76 | 2.11 | +0 | +0.0 |
| CHAFF IN THE MOVE | 108 | 103 | 72 | 2.00 | +1362 | +18.9 |
| MOVE TO CHARGE | 131 | 131 | 70 | 1.94 | +2493 | +35.6 |
| SUPPORTS | 149 | 149 | 66 | 1.83 | +1040 | +15.8 |
| FOUR ROUNDS | 181 | 173 | 65 | 1.81 | +3109 | +47.8 |
| JOINT CHARGE NOW | 65 | 65 | 65 | 1.81 | +2045 | +31.5 |
| ADVANCE LANE KEPT | 61 | 61 | 61 | 1.69 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 61 | 61 | 61 | 1.69 | +7187 | +117.8 |
| STAY WORTH | 1216 | 1078 | 61 | 1.69 | +959 | +15.7 |
| KILLS COUNT NEXT TURN | 185 | 185 | 60 | 1.67 | +1586 | +26.4 |
| IDLE COST | 911 | 585 | 58 | 1.61 | +395 | +6.8 |
| SHOOTS FROM THE BEST SPOT | 105 | 105 | 58 | 1.61 | +1285 | +22.2 |
| LANE BY FIGURES | 57 | 57 | 57 | 1.58 | +2421 | +42.5 |
| QUARTER ODDS | 285 | 274 | 56 | 1.56 | +7106 | +126.9 |
| BEST FIRST | 55 | 55 | 55 | 1.53 | +2804 | +51.0 |
| COVER ONCE | 427 | 239 | 53 | 1.47 | +1043 | +19.7 |
| FACES THE THREAT | 52 | 52 | 52 | 1.44 | +3075 | +59.1 |
| WAIT AFTER COSTS | 270 | 270 | 52 | 1.44 | +775 | +14.9 |
| ADVANCE WORTH | 202 | 202 | 49 | 1.36 | +1049 | +21.4 |
| HARD STAY DROPPED | 48 | 48 | 48 | 1.33 | +0 | +0.0 |
| CANNON SIGHT KEPT | 47 | 47 | 47 | 1.31 | +0 | +0.0 |
| MAX FOR POSITIONING | 325 | 227 | 46 | 1.28 | +192 | +4.2 |
| SUPPORT WORKED OUT | 161 | 148 | 46 | 1.28 | +812 | +17.7 |
| HOLDS AMBUSHERS | 44 | 44 | 44 | 1.22 | +0 | +0.0 |
| RISK BY ARC | 192 | 184 | 43 | 1.19 | +1669 | +38.8 |
| CANNON PLANNED TARGET | 245 | 245 | 42 | 1.17 | -1249 | -29.7 |
| CHARGE NOW FIRST | 162 | 162 | 42 | 1.17 | -2960 | -70.5 |
| CHARGE LOSSES | 348 | 332 | 39 | 1.08 | +3627 | +93.0 |
| RANDOM MOVE BY FIGURES | 81 | 81 | 39 | 1.08 | +2056 | +52.7 |
| BEST MOVE FOR SHOOTERS | 37 | 37 | 37 | 1.03 | +2842 | +76.8 |
| RISK BY HIS FIGURE | 769 | 723 | 36 | 1.00 | +3514 | +97.6 |
| LONE WIZARD KEPT IN | 35 | 35 | 35 | 0.97 | +2708 | +77.4 |
| SET UP BY THE SET | 111 | 108 | 35 | 0.97 | +3006 | +85.9 |
| MISSILES IN THE MOVE | 292 | 208 | 34 | 0.94 | +721 | +21.2 |
| REDIRECT COUNTER | 187 | 128 | 31 | 0.86 | +2248 | +72.5 |
| WALKS TO THE FIGHT | 73 | 73 | 31 | 0.86 | +292 | +9.4 |
| FALLS SHORT | 490 | 430 | 30 | 0.83 | +356 | +11.8 |
| COMBAT PIVOT | 29 | 29 | 29 | 0.81 | +0 | +0.0 |
| MARCH CHECK | 35 | 34 | 29 | 0.81 | +986 | +34.0 |
| FALLBACK BY WORTH | 175 | 175 | 27 | 0.75 | +1327 | +49.1 |
| RESERVE FALL BACK | 27 | 27 | 27 | 0.75 | +1463 | +54.2 |
| CAST JOB | 44 | 44 | 26 | 0.72 | +350 | +13.5 |
| SCOUT WAITS | 26 | 26 | 26 | 0.72 | +0 | +0.0 |
| CASTER AWAY FROM SCREEN | 25 | 25 | 25 | 0.69 | +0 | +0.0 |
| ONE FIGHT FORMULA | 513 | 299 | 25 | 0.69 | +54 | +2.2 |
| CASTING BLOCK | 35 | 35 | 23 | 0.64 | +670 | +29.1 |
| SHOOTERS IN TWO RANKS | 23 | 23 | 23 | 0.64 | +53 | +2.3 |
| HIS TURN DENIED | 98 | 94 | 20 | 0.56 | +486 | +24.3 |
| INVITES THE FIGHT | 41 | 41 | 20 | 0.56 | +129 | +6.5 |
| SAFER THAN THE JOB | 20 | 20 | 20 | 0.56 | +979 | +49.0 |
| HOLDER AT DEPLOYMENT | 39 | 39 | 19 | 0.53 | +913 | +48.1 |
| NEXT CHARGE BY LIST | 297 | 282 | 18 | 0.50 | +650 | +36.1 |
| RISK ONCE | 90 | 71 | 18 | 0.50 | +577 | +32.1 |
| HONEST WORTH | 446 | 435 | 17 | 0.47 | +185 | +10.9 |
| KILLS COUNT | 48 | 48 | 16 | 0.44 | +634 | +39.6 |
| STOPS SHORT OF THE FLANK | 16 | 16 | 16 | 0.44 | +642 | +40.1 |
| WOUNDS ON THE RANKS | 86 | 85 | 16 | 0.44 | +1047 | +65.4 |
| REDIRECT WEIGHED | 15 | 15 | 15 | 0.42 | +752 | +50.1 |
| CASTS FROM BEHIND | 14 | 14 | 14 | 0.39 | +0 | +0.0 |
| FIRE IN ORDER | 14 | 14 | 14 | 0.39 | +0 | +0.0 |
| FRIENDS SHOTS CHECKED | 14 | 14 | 14 | 0.39 | +922 | +65.9 |
| MOVE AND CAST | 14 | 14 | 14 | 0.39 | +618 | +44.2 |
| TIED UP BY THE SUM | 28 | 24 | 14 | 0.39 | +488 | +34.8 |
| CHARGE NOT DECLARED | 13 | 13 | 13 | 0.36 | -707 | -54.4 |
| MISSILES NEXT TURN | 353 | 244 | 13 | 0.36 | +116 | +8.9 |
| ONE OBJECTIVE FORMULA | 214 | 142 | 13 | 0.36 | +297 | +22.8 |
| WHO HITS BACK | 13 | 13 | 13 | 0.36 | +827 | +63.6 |
| PROMISE KNOWS THE FIGHT | 37 | 32 | 12 | 0.33 | -68 | -5.7 |
| WAR ENGINE JOBS | 22 | 22 | 12 | 0.33 | -1095 | -91.2 |
| WHOLE FIGHT GAIN | 23 | 23 | 12 | 0.33 | +616 | +51.3 |
| BEST FACING | 11 | 11 | 11 | 0.31 | +357 | +32.5 |
| CHAFF PASSED | 11 | 11 | 11 | 0.31 | -15 | -1.4 |
| CHARGE NOW WEIGHED | 11 | 11 | 11 | 0.31 | +312 | +28.3 |
| SET UP TOGETHER | 32 | 25 | 11 | 0.31 | +683 | +62.1 |
| THROUGH LINE OF FIRE | 11 | 11 | 11 | 0.31 | +372 | +33.9 |
| BEST PREY | 23 | 23 | 10 | 0.28 | +534 | +53.4 |
| HIS CHARGE DENIED | 27 | 27 | 10 | 0.28 | +531 | +53.1 |
| KEEPS ITS TARGET | 71 | 70 | 10 | 0.28 | +193 | +19.3 |
| MANOEUVRE | 36 | 36 | 10 | 0.28 | +341 | +34.1 |
| OPENS UP | 20 | 18 | 10 | 0.28 | +435 | +43.5 |
| SECOND LOOK | 10 | 10 | 10 | 0.28 | +700 | +70.0 |
| AFTERMATH WITH FRIENDS | 9 | 9 | 9 | 0.25 | +1039 | +115.4 |
| FIGHT TO THE END | 49 | 45 | 9 | 0.25 | +297 | +33.0 |
| LOST CHARGE | 74 | 73 | 9 | 0.25 | +142 | +15.8 |
| MARCH ODDS | 9 | 9 | 9 | 0.25 | +67 | +7.4 |
| WHO GETS IN | 9 | 9 | 9 | 0.25 | +247 | +27.5 |
| BLOCKED WHEEL | 8 | 8 | 8 | 0.22 | +327 | +40.8 |
| MODEL FACING | 8 | 8 | 8 | 0.22 | +2565 | +320.6 |
| NEARER NOT NEEDED | 205 | 197 | 8 | 0.22 | +273 | +34.1 |
| ONE PROMISE A TARGET | 8 | 8 | 8 | 0.22 | -591 | -73.8 |
| OVERRUNS AWAY | 31 | 28 | 8 | 0.22 | +195 | +24.4 |
| PIVOT GUARDS FLANK | 8 | 8 | 8 | 0.22 | -103 | -12.9 |
| REFUSING RETIRES | 30 | 30 | 8 | 0.22 | -3 | -0.3 |
| SHORT GUN FORWARD | 8 | 8 | 8 | 0.22 | +0 | +0.0 |
| SUPPORT NARROWED | 221 | 221 | 8 | 0.22 | -533 | -66.6 |
| BEST OVERALL | 7 | 7 | 7 | 0.19 | +268 | +38.2 |
| BEST PRIZE | 7 | 7 | 7 | 0.19 | -508 | -72.5 |
| HUNT IN PAIRS | 33 | 15 | 7 | 0.19 | +387 | +55.3 |
| MARCH BY THE SUM | 7 | 7 | 7 | 0.19 | +935 | +133.6 |
| MARCH OF THE TABLE | 7 | 7 | 7 | 0.19 | -207 | -29.5 |
| MOVES UNITS SPELL | 7 | 7 | 7 | 0.19 | +186 | +26.5 |
| SHOTS AFTER THE MOVES | 65 | 65 | 7 | 0.19 | +0 | +0.0 |
| AFTERMATH IN POINTS | 6 | 6 | 6 | 0.17 | +765 | +127.5 |
| BIG CHARACTER SAFETY | 6 | 6 | 6 | 0.17 | -10 | -1.7 |
| PROMISE READS THE TABLE | 18 | 18 | 6 | 0.17 | +121 | +20.2 |
| PURSUES BIG PREY | 6 | 6 | 6 | 0.17 | -396 | -66.0 |
| STAY WEIGHED | 6 | 6 | 6 | 0.17 | +374 | +62.3 |
| STUCK PIVOT | 6 | 6 | 6 | 0.17 | +0 | +0.0 |
| WEARS DOWN | 43 | 40 | 6 | 0.17 | +278 | +46.3 |
| DEFENSIVE ARMY | 9 | 9 | 5 | 0.14 | -79 | -15.7 |
| HIS MOVE AND SHOT | 105 | 103 | 5 | 0.14 | +28 | +5.6 |
| JOINT ON THE TABLE | 5 | 5 | 5 | 0.14 | +596 | +119.3 |
| MAKE SURE TOGETHER | 23 | 12 | 5 | 0.14 | +503 | +100.6 |
| SURE REACH TOGETHER | 28 | 20 | 5 | 0.14 | +26 | +5.2 |
| CHARGE LIST READ AGAIN | 4 | 4 | 4 | 0.11 | +1062 | +265.6 |
| EDGE GIVE GROUND | 18 | 17 | 4 | 0.11 | +71 | +17.8 |
| KEEP FALLS | 4 | 4 | 4 | 0.11 | +205 | +51.2 |
| WIDER SPREAD | 197 | 190 | 4 | 0.11 | +16 | +4.0 |
| FOCUS FIRE | 3 | 3 | 3 | 0.08 | +102 | +34.2 |
| HIS FIGHT TOGETHER | 56 | 56 | 3 | 0.08 | +26 | +8.8 |
| LONG SHOT | 26 | 25 | 3 | 0.08 | +38 | +12.6 |
| LOST AFTER ESCAPE | 102 | 97 | 3 | 0.08 | +26 | +8.6 |
| PROMISE SHOT AWAY | 3 | 3 | 3 | 0.08 | -52 | -17.4 |
| CARRIES OUT SET-UP | 6 | 6 | 2 | 0.06 | -88 | -44.2 |
| FALL BACK GOOD ORDER | 132 | 125 | 2 | 0.06 | +113 | +56.4 |
| FEATURE BUFFS | 10 | 10 | 2 | 0.06 | +24 | +12.0 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| NEEDED THERE | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| NO DOUBLE ROUNDS | 141 | 134 | 2 | 0.06 | +36 | +17.9 |
| PERIAPT WORTH | 2 | 2 | 2 | 0.06 | +250 | +124.8 |
| SPELLS IN THE FIGHT | 41 | 40 | 2 | 0.06 | +2 | +0.9 |
| WHAT THE JOINER ADDS | 14 | 12 | 2 | 0.06 | +72 | +36.2 |
| BACKUP TARGETS | 24 | 17 | 1 | 0.03 | +0 | +0.0 |
| BLOCKED CHARGE SKIPPED | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| BOMBING RUN | 1 | 1 | 1 | 0.03 | +31 | +30.9 |
| BOUND ASSAILMENT | 1 | 1 | 1 | 0.03 | +0 | +0.2 |
| CATCH ODDS | 1 | 1 | 1 | 0.03 | -11 | -10.9 |
| CONTINUE AHEAD WEIGHED | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| ELIXIR WORTH | 1 | 1 | 1 | 0.03 | +11 | +11.1 |
| GUN MASK | 11 | 10 | 1 | 0.03 | +1 | +1.4 |
| HORN WORTH | 1 | 1 | 1 | 0.03 | +6 | +5.6 |
| OWN CAST FIRST | 1 | 1 | 1 | 0.03 | -1 | -0.8 |
| PROMISE HOLDS THE SPOT | 1 | 1 | 1 | 0.03 | +66 | +66.2 |
| RAIDS THE BAGGAGE NEXT TURN | 1 | 1 | 1 | 0.03 | +74 | +73.8 |
| REFORMS TO MEET IT | 81 | 77 | 1 | 0.03 | +26 | +26.2 |
| RESTRAINS TO SHOOT | 1 | 1 | 1 | 0.03 | +7 | +7.4 |
| STAND AND SHOOT | 32 | 30 | 1 | 0.03 | +4 | +4.0 |
| STANDS TO CAST | 1 | 1 | 1 | 0.03 | +42 | +42.4 |
| STOPS | 3 | 3 | 1 | 0.03 | +39 | +38.6 |
| SURE CHARGE BEATS ADVANCE | 1 | 1 | 1 | 0.03 | -35 | -34.6 |
| THE PROMISE ADDS | 11 | 9 | 1 | 0.03 | +1 | +0.7 |
| WAR ENGINE CHARGES | 1 | 1 | 1 | 0.03 | +113 | +113.2 |
| WHOLE FIGHT | 14 | 13 | 1 | 0.03 | +0 | +0.0 |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| BLOWS WHERE AIMED | 27 | 26 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 28 | 28 | 0 | 0.00 | - | - |
| CARRIES OUT COUNTER | 2 | 2 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 35 | trace | - | - | - | - |
| CATCH FLIERS | 2 | not checked | - | - | - | - |
| CHAMPION KNOWS CHALLENGE | 9 | 9 | 0 | 0.00 | - | - |
| CHAMPION TAKES THE CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| CHARACTER GUNS | 37 | 30 | 0 | 0.00 | - | - |
| CHARGER SLAIN LOST | 34 | 34 | 0 | 0.00 | - | - |
| CHARIOT WIZARD CAREFUL | 2 | 2 | 0 | 0.00 | - | - |
| CHEAP HELPER | 2 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 36 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 49 | 46 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 2 | 2 | 0 | 0.00 | - | - |
| FIGHT LIFT | 1 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 335 | not checked | - | - | - | - |
| FRIEND CHARGES FIRST | 4 | 4 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 19 | 18 | 0 | 0.00 | - | - |
| GIVES UP | 24 | 21 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 2 | 2 | 0 | 0.00 | - | - |
| GROUND FLIERS | 2 | not checked | - | - | - | - |
| GUN FIGURES | 52 | not checked | - | - | - | - |
| HE SHOOTS OR CHARGES | 105 | 103 | 0 | 0.00 | - | - |
| HELPER ALREADY ASKED | 2 | not checked | - | - | - | - |
| HELPER UNSEEN | 6 | 6 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 174 | 161 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 186 | 173 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 77 | 77 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 177 | 166 | 0 | 0.00 | - | - |
| HOLD ODDS | 489 | 488 | 0 | 0.00 | - | - |
| HUNT ADVANCE | 2 | 2 | 0 | 0.00 | - | - |
| HUNT DROPPED | 1 | trace | - | - | - | - |
| HUNT KEPT | 1 | trace | - | - | - | - |
| HUNT RESULT | 4 | trace | - | - | - | - |
| HUNT THE GUNS | 4 | trace | - | - | - | - |
| JOINT CHARGE PLAN | 2 | 2 | 0 | 0.00 | - | - |
| JOINT KNOWS CHALLENGE | 7 | 7 | 0 | 0.00 | - | - |
| KEEPS ITS PREY | 2 | 2 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 11 | not checked | - | - | - | - |
| LONE WIZARD HOLDS BACK | 2 | 2 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 18 | 18 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 9 | trace | - | - | - | - |
| MARCH OVER CASTS | 57 | 57 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 1 | 1 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 2 | 2 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 21 | trace | - | - | - | - |
| MOVE SPELL SPOT | 13 | not checked | - | - | - | - |
| NEXT OBJECTIVE NEARER | 12 | 10 | 0 | 0.00 | - | - |
| NOT NEEDED | 10 | 10 | 0 | 0.00 | - | - |
| NOT TURNED | 214 | 214 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 42 | not checked | - | - | - | - |
| ONE CHARGE A CHARGER | 148 | 145 | 0 | 0.00 | - | - |
| OPENS A LANE | 15 | 7 | 0 | 0.00 | - | - |
| PLAN RESULT | 2847 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 13 | 13 | 0 | 0.00 | - | - |
| RANDOM MOVER NO PROMISE | 7 | 7 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 68 | 68 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 55 | 50 | 0 | 0.00 | - | - |
| RUN DOWN | 137 | 130 | 0 | 0.00 | - | - |
| SCOUT SPOT | 23 | 23 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 35 | 35 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 15 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 13 | not checked | - | - | - | - |
| SET-UP MISSED | 1 | trace | - | - | - | - |
| SHOOTER COUNTED ONCE | 10 | 10 | 0 | 0.00 | - | - |
| SHOT OR CHARGE | 10 | 10 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 18 | not checked | - | - | - | - |
| SPELL WORTH | 112 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 362 | 350 | 0 | 0.00 | - | - |
| STABLE ROLE | 416 | 415 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 40 | 36 | 0 | 0.00 | - | - |
| STANDS STILL | 826 | 792 | 0 | 0.00 | - | - |
| STUPIDITY NEXT TURN | 22 | 21 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 50 | not checked | - | - | - | - |
| THE PROMISED MOVE | 1 | not checked | - | - | - | - |
| THE TABLE BINDS | 1173 | not checked | - | - | - | - |
| TURN WORTH | 15 | 15 | 0 | 0.00 | - | - |
| TWO OR MORE ARRIVE | 9 | 9 | 0 | 0.00 | - | - |
| WAITS AGAIN | 67 | 64 | 0 | 0.00 | - | - |
| WOUNDED STAYS OUT | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: hmw-opp-c1e47a9-p1

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 15.39 | 3.25 | 41.9 |
| PROMISE BY ITS OWN SUM | rule | - | 3.11 | 90.5 |
| ARMY TABLE | rule | - | 1.75 | 40.6 |
| CHARGE NOW FIRST | rule | 0.47 | 0.67 | 72.2 |
| HOLDER ASSIGNMENT | rule | - | 1.08 | 18.6 |
| NO REASON | gate | - | 0.67 | 86.7 |
| JOINT CHARGE NOW | rule | - | 0.64 | 66.7 |
| FALLBACK | gate | 0.44 | 0.06 | 20.6 |
| CANNON PLANNED TARGET | rule | 0.31 | 0.11 | 89.9 |
| CHARGE NOT DECLARED | rule | 0.14 | 0.17 | 64.3 |
| PROMISE KNOWS THE FIGHT | rule | - | 0.31 | 6.2 |
| WAR ENGINE JOBS | rule | 0.31 | - | 99.5 |
| AFTERMATH BAND | gate | 0.11 | 0.14 | 2.3 |
| TURN GATE | gate | 0.19 | 0.06 | 39.2 |
| PIVOT GUARDS FLANK | rule | 0.14 | 0.08 | 12.9 |
| SUPPORT NARROWED | rule | 0.06 | 0.17 | 66.6 |
| BEST PRIZE | rule | 0.06 | 0.14 | 72.5 |
| MARCH OF THE TABLE | rule | - | 0.19 | 29.5 |
| ONE PROMISE A TARGET | rule | - | 0.19 | 85.3 |
| PURSUES BIG PREY | rule | 0.08 | 0.08 | 66.0 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.08 | 0.06 | 91.0 |
| CHAFF PASSED | rule | 0.06 | 0.08 | 2.9 |
| DEFENSIVE ARMY | rule | 0.14 | - | 15.7 |
| PROMISE READS THE TABLE | rule | - | 0.11 | 11.4 |
| CHARGE NOW WEIGHED | rule | 0.08 | - | 60.5 |
| PROMISE SHOT AWAY | rule | - | 0.08 | 17.4 |
| SUPPORT REQUEST | gate | 0.08 | - | 105.4 |
| WHO GETS IN | rule | - | 0.08 | 77.7 |
| BIG CHARACTER SAFETY | rule | 0.06 | - | 6.8 |
| CARRIES OUT SET-UP | rule | 0.03 | 0.03 | 44.2 |
| DEPLOY BY FIGURES | rule | - | 0.06 | 10.4 |
| LONE CHARACTER SAFE SPOT | gate | 0.03 | 0.03 | 36.9 |
| REDIRECT WEIGHED | rule | - | 0.06 | 42.1 |
| REFUSING RETIRES | rule | 0.03 | 0.03 | 0.6 |
| RULE SWITCHED OFF | gate | 0.06 | - | 38.4 |
| SET UP BY THE SET | rule | - | 0.06 | 33.0 |
| BLOCKED WHEEL | rule | 0.03 | - | 3.1 |
| CATCH ODDS | rule | 0.03 | - | 10.9 |
| FACES THE THREAT | rule | 0.03 | - | 11.4 |
| FIGHT ORDER BAND | gate | - | 0.03 | 0.6 |
| FRIENDS SHOTS CHECKED | rule | - | 0.03 | 3.3 |
| MARCH ODDS | rule | 0.03 | - | 13.8 |
| OWN CAST FIRST | rule | - | 0.03 | 0.8 |
| PATHS CROSS | rule | - | 0.03 | 25.2 |
| STOPS SHORT OF THE FLANK | rule | 0.03 | - | 2.3 |
| SURE CHARGE BEATS ADVANCE | rule | 0.03 | - | 34.6 |
| THROUGH LINE OF FIRE | rule | 0.03 | - | 7.6 |

### Plans: hmw-opp-c1e47a9-p1

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 9.8 | 12% | 198 | 200 | 101% |
| Mine | charge | 2.9 | 61% | 262 | 233 | 89% |
| Mine | close in | 5.4 | 27% | 268 | 125 | 47% |
| Mine | hold | 5.9 | 42% | 369 | 0 | 0% |
| Mine | join | 0.4 | 79% | 12 | 0 | 0% |
| Mine | shoot | 9.4 | 70% | 289 | 591 | 205% |
| Mine | support | 5.2 | 87% | 51 | 0 | 0% |
| Opponent | charge | 4.2 | 60% | 578 | 420 | 73% |
| Opponent | join | 1.0 | 95% | 50 | 0 | 0% |
| Opponent | move | 30.8 | 93% | 1668 | 0 | 0% |
| Opponent | shoot | 3.2 | 66% | 193 | 209 | 109% |
| Opponent | support | 1.1 | 82% | 18 | 0 | 0% |

### Packages: hunt the guns, hmw-opp-c1e47a9-p1

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.1 | 2 | 0 | 0% | 0% | 0% | - | 387 | 0 | 0% | 30 |
| Opponent | 0.1 | 2 | 0 | 100% | 100% | 0% | 2.0 | 395 | 347 | 100% | 56 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Chaos Dwarfs | 0.3 | 1 | 0 | 0% | 0% | 0% | - | 549 | 0 | 0% | 215 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 84 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 22 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 33 |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Kingdom of Bretonnia | 1.0 | 1 | 0 | 0% | 0% | 0% | - | 225 | 0 | 0% | 0 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 18 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 48 |
| Tomb Kings of Khemri | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 32 |
| Vampire Counts | 0.1 | 1 | 0 | 100% | 100% | 0% | 2.0 | 569 | 475 | 100% | 59 |
| Warriors of Chaos | 0.1 | 1 | 0 | 100% | 100% | 0% | 2.0 | 221 | 219 | 100% | 14 |
| Wood Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 118 |

### Battle groups: hmw-opp-c1e47a9-p1

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 2.2 | 33% | 69% | 8% | 0% | 12% | 4% | 4% | 67% | 12% |
| Opponent | REDIRECT COUNTER | 3.0 | 21% | 87% | 9% | 0% | 24% | 0% | 0% | 71% | 5% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: hmw-opp-c1e47a9-p1

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 3 | 25 (3) | 25 | 0 | 0 | 33% | 4.5 | 0 (1) | 67 (1) | 0 (1) | 67 (1) | 0 (2) |
| Mine | Chaff | 37 | 39 (37) | 9 | 30 | 54 | 30% | 2.9 | 49 (12) | 31 (17) | 35 (8) | 48 (27) | 20 (10) |
| Mine | Character | 123 | 37 (123) | 37 | 0 | 33 | 20% | 2.3 | 44 (46) | 23 (43) | 47 (20) | 37 (58) | 39 (51) |
| Mine | Clean-up | 25 | 60 (25) | 4 | 55 | 26 | 28% | 3.2 | 51 (12) | 79 (11) | 0 (2) | 71 (16) | 47 (9) |
| Mine | Fast | 4 | 0 (4) | 0 | 0 | 78 | 0% | 1.8 | 0 (3) | 0 (1) | - | 0 (3) | 0 (1) |
| Mine | Fast Hammer | 41 | 37 (41) | 20 | 17 | 53 | 27% | 3.3 | 28 (20) | 33 (16) | 94 (5) | 23 (23) | 53 (18) |
| Mine | Hammer | 58 | 31 (58) | 27 | 4 | 27 | 22% | 2.5 | 36 (22) | 22 (27) | 47 (9) | 31 (32) | 31 (26) |
| Mine | Holder | 24 | 102 (24) | 10 | 92 | 19 | 54% | 3.2 | 75 (9) | 121 (14) | - | 130 (15) | 60 (8) |
| Mine | Shooter | 49 | 101 (49) | 26 | 75 | 39 | 0% | 1.7 | 99 (14) | 110 (27) | 70 (8) | 127 (32) | 58 (17) |
| Mine | Support | 5 | 25 (5) | 25 | 0 | 14 | 20% | 3.2 | 0 (1) | 43 (4) | - | 30 (4) | 0 (1) |
| Mine | War machine | 56 | 31 (56) | 31 | 0 | 29 | 5% | 1.5 | 28 (23) | 35 (25) | 26 (8) | 102 (6) | 23 (50) |
| Mine | Wizard | 23 | 71 (23) | 71 | 0 | 34 | 9% | 3.1 | 120 (11) | 28 (6) | 0 (3) | 118 (11) | 39 (9) |
| Opponent | Blocker | 1 | 94 (1) | 94 | 0 | 100 | 0% | 5.0 | - | 94 (1) | - | 94 (1) | - |
| Opponent | Chaff | 68 | 85 (68) | 12 | 72 | 49 | 44% | 2.6 | 66 (21) | 139 (25) | 37 (22) | 112 (49) | 13 (19) |
| Opponent | Character | 114 | 47 (114) | 47 | 0 | 24 | 30% | 2.5 | 53 (35) | 48 (51) | 52 (19) | 55 (61) | 44 (44) |
| Opponent | Clean-up | 14 | 86 (14) | 72 | 14 | 37 | 36% | 3.1 | 93 (4) | 88 (9) | 0 (1) | 86 (9) | 87 (5) |
| Opponent | Early | 1 | 12 (1) | 12 | 0 | 100 | 0% | 4.0 | 12 (1) | - | - | - | 12 (1) |
| Opponent | Fast Hammer | 58 | 39 (58) | 19 | 20 | 28 | 33% | 2.5 | 38 (18) | 45 (32) | 21 (8) | 46 (35) | 31 (23) |
| Opponent | Fragile | 6 | 0 (6) | 0 | 0 | 81 | 33% | 1.8 | - | 0 (2) | 0 (1) | 0 (1) | 0 (2) |
| Opponent | Hammer | 65 | 42 (65) | 29 | 13 | 42 | 28% | 2.7 | 32 (18) | 44 (30) | 49 (17) | 46 (40) | 35 (25) |
| Opponent | Holder | 40 | 51 (40) | 4 | 47 | 28 | 48% | 2.9 | 69 (11) | 46 (21) | 36 (8) | 68 (23) | 29 (17) |
| Opponent | Shooter | 34 | 53 (34) | 4 | 49 | 51 | 6% | 1.9 | 60 (13) | 63 (13) | 22 (8) | 68 (22) | 27 (12) |
| Opponent | Support | 2 | 0 (2) | 0 | 0 | 0 | 50% | 6.0 | - | 0 (2) | - | - | 0 (2) |
| Opponent | War machine | 13 | 73 (13) | 73 | 0 | 27 | 0% | 1.2 | 95 (9) | 36 (2) | 0 (2) | 32 (2) | 80 (11) |
| Opponent | Wizard | 22 | 2 (22) | 2 | 0 | 27 | 18% | 1.8 | 0 (7) | 4 (8) | 0 (6) | 3 (9) | 0 (12) |

### Charged fights: hmw-opp-c1e47a9-p1

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 5 | 213 | 41 | 1.0 | 1.4 | 41 | 21 | +20 | 2 of 5 | 2 of 5 | -6 | +38 |
| Mine | Chaos Dwarfs | 3 | 100 | 392 | 3.3 | 1.0 | 118 | 0 | +118 | 8 of 10 | 7 of 10 | - | +118 |
| Mine | Dwarfen Mountain Holds | 4 | 229 | 15 | 1.0 | 1.2 | 15 | 15 | +0 | 1 of 4 | 2 of 4 | -60 | +20 |
| Mine | Empire of Man | 5 | 120 | 115 | 2.2 | 1.2 | 52 | 3 | +49 | 1 of 11 | 8 of 11 | +81 | +42 |
| Mine | Grand Cathay | 4 | 382 | 218 | 2.0 | 1.1 | 109 | 53 | +56 | 3 of 8 | 8 of 8 | +483 | -5 |
| Mine | High Elf Realms | 4 | 144 | 593 | 3.2 | 1.4 | 182 | 12 | +171 | 5 of 13 | 9 of 13 | +138 | +192 |
| Mine | Kingdom of Bretonnia | 1 | 0 | 511 | 4.0 | 1.0 | 128 | 20 | +108 | 1 of 4 | 4 of 4 | - | +108 |
| Mine | Lizardmen | 1 | 261 | 726 | 7.0 | 1.3 | 104 | 58 | +45 | 3 of 7 | 6 of 7 | +22 | +55 |
| Mine | Ogre Kingdoms | 1 | 66 | 126 | 4.0 | 1.0 | 32 | 8 | +23 | 0 of 4 | 3 of 4 | - | +23 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 66 | 2.0 | 1.0 | 33 | 0 | +33 | 1 of 2 | 2 of 2 | - | +33 |
| Mine | Skaven | 2 | 128 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Mine | Tomb Kings of Khemri | 2 | 127 | 812 | 5.0 | 1.0 | 162 | 0 | +162 | 1 of 10 | 9 of 10 | - | +162 |
| Mine | Vampire Counts | 2 | 0 | 49 | 4.0 | 1.1 | 12 | 120 | -107 | 1 of 8 | 8 of 8 | -290 | -81 |
| Mine | Warriors of Chaos | 1 | 0 | 160 | 1.0 | 1.0 | 160 | 0 | +160 | 1 of 1 | 1 of 1 | - | +160 |
| **Mine** | all armies | 36 | 162 | 238 | 2.4 | 1.2 | 98 | 26 | +73 | 28 of 87 | 69 of 87 | +72 | +73 |
| Opponent | Beastmen Brayherds | 1 | 55 | 952 | 4.0 | 1.8 | 238 | 68 | +170 | 4 of 4 | 3 of 4 | +165 | +174 |
| Opponent | Dwarfen Mountain Holds | 1 | 784 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Empire of Man | 1 | 415 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Grand Cathay | 1 | 120 | 699 | 4.0 | 1.5 | 175 | 0 | +175 | 3 of 4 | 4 of 4 | +256 | +93 |
| Opponent | High Elf Realms | 2 | 22 | 604 | 4.0 | 1.6 | 151 | 0 | +151 | 2 of 8 | 6 of 8 | +326 | +46 |
| Opponent | Lizardmen | 1 | 0 | 504 | 5.0 | 1.0 | 101 | 0 | +101 | 2 of 5 | 4 of 5 | - | +101 |
| Opponent | Ogre Kingdoms | 2 | 126 | 174 | 3.5 | 1.6 | 50 | 36 | +13 | 3 of 7 | 4 of 7 | +19 | +10 |
| Opponent | Orc & Goblin Tribes | 2 | 0 | 856 | 3.5 | 1.1 | 244 | 8 | +237 | 3 of 7 | 6 of 7 | +347 | +218 |
| Opponent | Skaven | 2 | 56 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 1 of 2 | 1 of 2 | - | +0 |
| Opponent | Tomb Kings of Khemri | 4 | 65 | 837 | 5.2 | 1.3 | 159 | 3 | +156 | 7 of 21 | 19 of 21 | +408 | +97 |
| Opponent | Vampire Counts | 6 | 46 | 600 | 3.7 | 1.1 | 164 | 22 | +141 | 11 of 22 | 16 of 22 | +0 | +156 |
| Opponent | Warriors of Chaos | 7 | 0 | 193 | 2.1 | 1.1 | 90 | 19 | +71 | 4 of 15 | 12 of 15 | +72 | +71 |
| Opponent | Wood Elf Realms | 6 | 98 | 347 | 3.2 | 1.1 | 110 | 56 | +53 | 7 of 19 | 12 of 19 | +406 | +12 |
| **Opponent** | all armies | 36 | 81 | 439 | 3.2 | 1.2 | 139 | 22 | +117 | 47 of 114 | 87 of 114 | +237 | +91 |

### Effective charges: hmw-opp-c1e47a9-p1

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 5 | 1 (net -52) | 0 | 2 (net -26) | 0 | 0 | 1 (net +40) | 1 | 50% (2 of 4) |
| Mine | Chaos Dwarfs | 10 | 2 (net +194) | 1 (net +432) | 1 (net +210) | 3 (net +0) | 0 | 2 (net +72) | 1 | 11% (1 of 9) |
| Mine | Dwarfen Mountain Holds | 4 | 0 | 0 | 1 (net +0) | 2 (net -30) | 0 | 1 (net +60) | 0 | 25% (1 of 4) |
| Mine | Empire of Man | 11 | 2 (net -18) | 0 | 2 (net +206) | 2 (net +0) | 3 (net +54) | 1 (net +0) | 1 | 20% (2 of 10) |
| Mine | Grand Cathay | 8 | 0 | 0 | 2 (net +242) | 3 (net -100) | 0 | 2 (net +62) | 1 | 29% (2 of 7) |
| Mine | High Elf Realms | 13 | 0 | 1 (net +663) | 4 (net +260) | 4 (net -12) | 2 (net +30) | 2 (net +254) | 0 | 31% (4 of 13) |
| Mine | Kingdom of Bretonnia | 4 | 0 | 0 | 1 (net +279) | 2 (net +116) | 0 | 1 (net -80) | 0 | 25% (1 of 4) |
| Mine | Lizardmen | 7 | 0 | 0 | 2 (net +178) | 1 (net +60) | 2 (net +22) | 1 (net +0) | 1 | 33% (2 of 6) |
| Mine | Ogre Kingdoms | 4 | 0 | 0 | 2 (net +63) | 0 | 0 | 0 | 2 | 100% (2 of 2) |
| Mine | Tomb Kings of Khemri | 10 | 0 | 0 | 2 (net +85) | 1 (net +0) | 2 (net +128) | 3 (net +303) | 2 | 25% (2 of 8) |
| Mine | Vampire Counts | 8 | 0 | 0 | 1 (net -290) | 3 (net +0) | 1 (net +98) | 3 (net -222) | 0 | 12% (1 of 8) |
| Mine | Warriors of Chaos | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +160) | 0 | 0% (0 of 1) |
| Opponent | Beastmen Brayherds | 4 | 2 (net -94) | 0 | 0 | 0 | 0 | 1 (net +382) | 1 | 0% (0 of 3) |
| Opponent | Grand Cathay | 4 | 0 | 0 | 0 | 2 (net +257) | 0 | 1 (net +185) | 1 | 0% (0 of 3) |
| Opponent | High Elf Realms | 8 | 1 (net +0) | 0 | 1 (net +150) | 1 (net +0) | 1 (net +125) | 3 (net +311) | 1 | 14% (1 of 7) |
| Opponent | Lizardmen | 5 | 2 (net +119) | 0 | 0 | 2 (net +38) | 0 | 0 | 1 | 0% (0 of 4) |
| Opponent | Ogre Kingdoms | 7 | 2 (net -65) | 0 | 2 (net -20) | 0 | 0 | 1 (net +130) | 2 | 40% (2 of 5) |
| Opponent | Orc & Goblin Tribes | 7 | 0 | 0 | 0 | 1 (net +325) | 1 (net +110) | 1 (net +177) | 4 | 0% (0 of 3) |
| Opponent | Skaven | 2 | 0 | 0 | 1 (net +0) | 1 (net +0) | 0 | 0 | 0 | 50% (1 of 2) |
| Opponent | Tomb Kings of Khemri | 21 | 1 (net +0) | 0 | 2 (net +52) | 7 (net +126) | 1 (net +110) | 5 (net +332) | 5 | 12% (2 of 16) |
| Opponent | Vampire Counts | 22 | 9 (net +175) | 0 | 1 (net +0) | 4 (net +33) | 0 | 7 (net +145) | 1 | 5% (1 of 21) |
| Opponent | Warriors of Chaos | 15 | 1 (net -116) | 0 | 1 (net +254) | 4 (net +90) | 1 (net +72) | 6 (net +82) | 2 | 8% (1 of 13) |
| Opponent | Wood Elf Realms | 19 | 6 (net -14) | 0 | 2 (net +0) | 1 (net +205) | 3 (net +86) | 5 (net +88) | 2 | 12% (2 of 17) |

### Charged fights, damage counted: hmw-opp-c1e47a9-p1

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 5 | 212 | 206 | +60 | 154 | 104 | +51 | +23.9 |
| Mine | 50-54% | 2 | 588 | 301 | +548 | 548 | 0 | +548 | +93.1 |
| Mine | Effective (55-75%) | 20 | 269 | 234 | +137 | 176 | 38 | +138 | +51.1 |
| Mine | 76-89% | 21 | 293 | 153 | -6 | 73 | 65 | +8 | +2.7 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 18 | 240 | 150 | +66 | 121 | 43 | +77 | +32.2 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 10 | 429 | 89 | +62 | 74 | 22 | +51 | +12.0 |
| Mine | No odds | 11 | 306 | 142 | +45 | 88 | 33 | +55 | +17.9 |
| Mine | All fights | 87 | 296 | 169 | +73 | 124 | 46 | +78 | +26.3 |
| Opponent | Long shot (under 50%) | 24 | 212 | 302 | +54 | 121 | 79 | +42 | +19.6 |
| Opponent | Effective (55-75%) | 10 | 273 | 174 | +47 | 88 | 19 | +69 | +25.2 |
| Opponent | 76-89% | 23 | 301 | 150 | +108 | 123 | 15 | +109 | +36.0 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 30 | 334 | 201 | +181 | 226 | 49 | +177 | +53.1 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 7 | 409 | 89 | +96 | 96 | 0 | +96 | +23.6 |
| Opponent | No odds | 20 | 288 | 196 | +148 | 183 | 35 | +148 | +51.6 |
| Opponent | All fights | 114 | 293 | 202 | +117 | 156 | 40 | +115 | +39.4 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| hmw-opp-c1e47a9-p1 | move | 336 | 80 (24%) | 56 (17%) | 48 (14%) | 208 (62%) |
| hmw-opp-c1e47a9-p1 | objective | 193 | 31 (16%) | 23 (12%) | 16 (8%) | 146 (76%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0102, L0118, L0135, L2531, L2730 |
| Charmed Shield | Opponent | L0524, L1224, L1527, L1625, L2025, L2127, L2934 |
| Clockwork Compass | Mine | L1224 |
| Clockwork Compass | Opponent | L0612 |
| Elixir of Power | Mine | L1114, L1131, L1923 |
| Elixir of Power | Opponent | L0319, L1319 |
| Fistful of Laurels | Mine | L1823 |
| Fistful of Laurels | Opponent | L0118, L0218 |
| Horn of the Wild Hunt | Opponent | L0733 |
| Invocation of Nehek | Mine | L2531, L2730 |
| Invocation of Nehek | Opponent | L0524, L1224, L1527, L1625, L2025, L2127 |
| Opal Amulet | Mine | L1431 |
| Opal Amulet | Opponent | L1114 |
| Periapt of Soul Exchange | Mine | L2025, L2127 |
| Periapt of Soul Exchange | Opponent | L0421, L1021 |
| Ring of Doom | Mine | L0218, L0235, L1114, L1131, L1224, L1527 |
| Ring of Doom | Opponent | L0102, L0612, L0733, L1131, L1431, L2231, L2531 |
| Ring of Jet | Mine | L1021, L1114, L1131, L1224 |
| Ring of Jet | Opponent | L0612 |
| Standard of the Fell Warrior | Mine | L1319, L1335 |
| Standard of the Fell Warrior | Opponent | L0913 |
| Storm Daemon (Renegade 2.0) | Mine | L2127 |
| Storm Daemon (Renegade 2.0) | Opponent | L0421, L1021 |
| Twice-Blessed Armour | Mine | L0717, L0733, L1021 |
| Witch Hunter's Ward | Mine | L0717, L0733, L0823 |
| Witch Hunter's Ward | Opponent | L0508 |

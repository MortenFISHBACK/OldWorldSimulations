# Doctrine scorecard: hmw-mine-c1e47a9-p2

### Scorecard: hmw-mine-c1e47a9-p2

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0106 | 4 | 1 | Mine | no | 0 | 2 | 2 | 2 | 0 | 0 | 0 | 0 |
| L0106 | 4 | 1 | Opponent | no | 0 | 2 | 2 | 1 | 0 | 0 | 0 | 743 |
| L0122 | 2 | 1 | Mine | - | - | - | 0 | 1 | 1 | 0 | 0 | 77 |
| L0122 | 2 | 1 | Opponent | - | - | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L0206 | 2 | 1 | Mine | - | - | 2 | 1 | 4 | 0 | 0 | 0 | 0 |
| L0206 | 2 | 1 | Opponent | - | - | 4 | 0 | 2 | 1 | 0 | 0 | 675 |
| L0222 | 6 | 1 | Mine | no | 4 | 2 | 3 | 4 | 0 | 0 | 0 | 0 |
| L0222 | 6 | 1 | Opponent | no | 5 | 1 | 1 | 0 | 0 | 0 | 0 | 72 |
| L0307 | 1 | 1 | Mine | no | 0 | - | 1 | 2 | 0 | 0 | 0 | 340 |
| L0307 | 1 | 1 | Opponent | yes | 4 | 5 | 1 | 2 | 1 | 0 | 0 | 800 |
| L0323 | 5 | 1 | Mine | no | - | 2 | 1 | 1 | 1 | 0 | 0 | 341 |
| L0323 | 5 | 1 | Opponent | yes | - | 2 | 3 | 3 | 1 | 0 | 0 | 0 |
| L0409 | 1 | 1 | Mine | no | 13 | 3 | 4 | 0 | 0 | 0 | 0 | 0 |
| L0409 | 1 | 1 | Opponent | no | 0 | - | 1 | 0 | 0 | 0 | 0 | 560 |
| L0425 | 5 | 1 | Mine | yes | - | 2 | 5 | 4 | 0 | 0 | 0 | 65 |
| L0425 | 5 | 1 | Opponent | no | - | 6 | 2 | 3 | 0 | 0 | 0 | 0 |
| L0512 | 2 | 1 | Mine | - | - | - | 2 | 1 | 0 | 0 | 0 | 956 |
| L0512 | 2 | 1 | Opponent | - | - | 2 | 3 | 2 | 0 | 0 | 0 | 330 |
| L0528 | 6 | 1 | Mine | no | 8 | 3 | 0 | 1 | 0 | 0 | 0 | 350 |
| L0528 | 6 | 1 | Opponent | no | 7 | - | 0 | 2 | 1 | 0 | 0 | 0 |
| L0616 | 4 | 1 | Mine | no | 0 | 3 | 1 | 1 | 0 | 0 | 0 | 992 |
| L0616 | 4 | 1 | Opponent | no | 2 | 2 | 1 | 0 | 0 | 0 | 0 | 307 |
| L0632 | 2 | 1 | Mine | - | - | 1 | 4 | 0 | 0 | 0 | 0 | 358 |
| L0632 | 2 | 1 | Opponent | - | - | 2 | 3 | 3 | 0 | 0 | 0 | 340 |
| L0721 | 1 | 1 | Mine | no | 4 | 2 | 4 | 1 | 0 | 0 | 0 | 170 |
| L0721 | 1 | 1 | Opponent | yes | 0 | - | 0 | 5 | 1 | 0 | 0 | 500 |
| L0810 | 6 | 1 | Mine | no | 1 | - | 0 | 2 | 0 | 0 | 0 | 592 |
| L0810 | 6 | 1 | Opponent | no | 13 | 2 | 2 | 0 | 1 | 0 | 0 | 330 |
| L0827 | 5 | 1 | Mine | no | - | 2 | 1 | 1 | 0 | 0 | 0 | 171 |
| L0827 | 5 | 1 | Opponent | yes | - | 2 | 4 | 5 | 0 | 0 | 0 | 75 |
| L0918 | 6 | 1 | Mine | no | 3 | - | 0 | 1 | 0 | 0 | 0 | 170 |
| L0918 | 6 | 1 | Opponent | no | 0 | 5 | 1 | 0 | 0 | 0 | 0 | 185 |
| L0934 | 4 | 1 | Mine | no | 0 | - | 1 | 1 | 0 | 0 | 0 | 537 |
| L0934 | 4 | 1 | Opponent | no | 2 | 2 | 3 | 4 | 0 | 0 | 0 | 0 |
| L1026 | 6 | 1 | Mine | no | 14 | 2 | 4 | 0 | 0 | 0 | 0 | 0 |
| L1026 | 6 | 1 | Opponent | no | 0 | 4 | 1 | 1 | 0 | 0 | 0 | 120 |
| L1118 | 2 | 1 | Mine | - | - | 3 | 3 | 0 | 0 | 0 | 0 | 0 |
| L1118 | 2 | 1 | Opponent | - | - | - | 2 | 1 | 1 | 0 | 0 | 0 |
| L1135 | 1 | 1 | Mine | yes | 9 | 2 | 2 | 0 | 0 | 0 | 0 | 165 |
| L1135 | 1 | 1 | Opponent | yes | 0 | 2 | 3 | 4 | 0 | 0 | 0 | 0 |
| L1228 | 4 | 1 | Mine | no | 2 | 2 | 1 | 1 | 0 | 0 | 0 | 165 |
| L1228 | 4 | 1 | Opponent | no | 3 | - | 0 | 1 | 0 | 0 | 0 | 111 |
| L1323 | 3 | 1 | Mine | no | 4 | 2 | 0 | 0 | 0 | 0 | 0 | 317 |
| L1323 | 3 | 1 | Opponent | no | 0 | 2 | 7 | 2 | 0 | 0 | 0 | 0 |
| L1418 | 2 | 1 | Mine | - | - | 2 | 8 | 0 | 0 | 0 | 0 | 0 |
| L1418 | 2 | 1 | Opponent | - | - | 1 | 3 | 0 | 0 | 0 | 0 | 0 |
| L1435 | 1 | 1 | Mine | no | 2 | 2 | 2 | 0 | 0 | 0 | 0 | 0 |
| L1435 | 1 | 1 | Opponent | no | 2 | 4 | 4 | 1 | 0 | 0 | 0 | 114 |
| L1531 | 1 | 1 | Mine | no | 0 | 3 | 5 | 1 | 0 | 0 | 0 | 0 |
| L1531 | 1 | 1 | Opponent | no | 1 | - | 1 | 0 | 2 | 0 | 0 | 927 |
| L1629 | 3 | 1 | Mine | no | 2 | 2 | 2 | 1 | 0 | 0 | 0 | 436 |
| L1629 | 3 | 1 | Opponent | no | 1 | 2 | 7 | 1 | 0 | 0 | 0 | 170 |
| L1727 | 5 | 1 | Mine | yes | - | 1 | 1 | 1 | 0 | 0 | 0 | 497 |
| L1727 | 5 | 1 | Opponent | yes | - | 2 | 3 | 5 | 0 | 0 | 0 | 0 |
| L1827 | 3 | 1 | Mine | yes | 8 | - | 1 | 2 | 0 | 0 | 0 | 0 |
| L1827 | 3 | 1 | Opponent | no | 0 | 2 | 7 | 4 | 0 | 0 | 0 | 0 |
| L1927 | 1 | 1 | Mine | no | 1 | 2 | 7 | 1 | 0 | 0 | 0 | 255 |
| L1927 | 1 | 1 | Opponent | no | 3 | 3 | 7 | 0 | 0 | 0 | 0 | 60 |
| L2029 | 1 | 1 | Mine | no | 0 | - | 1 | 2 | 2 | 0 | 0 | 210 |
| L2029 | 1 | 1 | Opponent | no | 4 | 2 | 6 | 1 | 0 | 0 | 0 | 170 |
| L2131 | 1 | 1 | Mine | yes | 2 | - | 0 | 3 | 1 | 0 | 0 | 265 |
| L2131 | 1 | 1 | Opponent | no | 2 | 2 | 1 | 1 | 1 | 0 | 0 | 170 |
| L2235 | 3 | 1 | Mine | no | 8 | 2 | 2 | 0 | 0 | 0 | 0 | 0 |
| L2235 | 3 | 1 | Opponent | no | 1 | 2 | 2 | 2 | 0 | 0 | 0 | 126 |
| L2429 | 5 | 1 | Mine | yes | - | 3 | 2 | 2 | 0 | 0 | 0 | 0 |
| L2429 | 5 | 1 | Opponent | yes | - | 3 | 4 | 3 | 0 | 0 | 0 | 0 |
| L2535 | 3 | 1 | Mine | no | 0 | 2 | 2 | 0 | 0 | 0 | 0 | 0 |
| L2535 | 3 | 1 | Opponent | no | 2 | 2 | 4 | 2 | 0 | 0 | 0 | 0 |
| L2735 | 5 | 1 | Mine | yes | - | 2 | 3 | 3 | 0 | 0 | 0 | 0 |
| L2735 | 5 | 1 | Opponent | yes | - | 2 | 3 | 2 | 0 | 0 | 0 | 0 |
| L3033 | 3 | 1 | Mine | yes | 8 | 2 | 1 | 2 | 0 | 0 | 0 | 0 |
| L3033 | 3 | 1 | Opponent | no | 0 | 3 | 4 | 2 | 0 | 0 | 0 | 144 |
| **Average** | | | Mine | 27% | 3.9 | 2.1 | 2.1 | 1.3 | 0.1 | 0.0 | 0.0 | 206.4 |
| **Average** | | | Opponent | 27% | 2.2 | 2.6 | 2.8 | 1.8 | 0.3 | 0.0 | 0.0 | 195.2 |

### KPIs: hmw-mine-c1e47a9-p2

Rules off - Opponent only: FIVE ACTION, LIKELY CHARGE, FALLS SHORT, TIME ON OUR SIDE, FEATURE BUFFS, GETS AWAY CHANCE, GUN MASK, RUN DOWN, FOUR ROUNDS, CHARGE LOSSES, CHARACTER GUNS, STAND AND SHOOT, FALL BACK GOOD ORDER, AFTERMATH IN POINTS, NEXT CHARGE BY LIST, NEXT OBJECTIVE NEARER, NO DOUBLE ROUNDS, SCALED CHANCE, LEGAL CHARGES ONLY, SHOT OR CHARGE, MOVE CARRIES THE JOB, MOVE TO CHARGE COMPUTED, RISK BY HIS FIGURE, SHOT RISK POINTS, ONE TARGET A SHOOTER, ONE CHARGE A CHARGER, HIS CHARGE LIST, HIS SHOT LIST, HIS MOVE AND SHOT, HIS LEGAL MOVES, HIS TURN DENIED, THE PROMISE ADDS, HE SHOOTS OR CHARGES, HIS RANDOM MOVE, HIS CHARGE DENIED, SAME CHARGE LATER, FRIEND CHARGES FIRST, FRIEND SHOOTS FIRST, WAITS AGAIN, WOUNDS ON THE RANKS, THE PROMISED MOVE, MARCH BY THE SUM, FIGHT TO THE END, THE DEARER SUM KEEPS ITS PLAN, HIS OWN BEST MOVE, TIED UP BY THE SUM, REFORMS TO MEET IT, STANDS FOR A REASON, HOLDER ASSIGNMENT, ARMY TABLE, MOVE ORDER, CHARGE LIST READ AGAIN, PROMISE READS THE TABLE, SUPPORT WORKED OUT, WHO GETS IN, THE TABLE BINDS, HIS ONE MOVE, PROMISE BY ITS OWN SUM, SECOND LOOK, LOST AFTER ESCAPE, PROMISE KNOWS THE FIGHT, SPOT AS THE GAME MOVES, ONE PROMISE A TARGET, WHAT THE JOINER ADDS, DENIED BY THE FIGHT, HIS MOVE AS HE DECIDES, ROUNDS AFTER TERROR, MARCH OF THE TABLE, PROMISE HOLDS THE SPOT, PROMISE SHOT AWAY, OWN CAST FIRST, PROMISE IN STEPS, STUPIDITY NEXT TURN, PROMISE BELOW ZERO, HIS MOVE WHY, THE TABLE AGAIN, SHOTS AFTER THE MOVES, SET FIGHT, JOINT CHARGE NOW, JOINT ON THE TABLE, JOINT LOOK BACK, AFTERMATH WITH FRIENDS, HIS FIGHT TOGETHER, SET UP BY THE SET, QUARTER ODDS, CHEAPEST HOLDER, NEARER NOT NEEDED, NO FORCED ADVANCE, HARD STAY DROPPED.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 26% (45 of 174) | 9% (16 of 169) | 18% (61 of 343) |
| Winner chose to follow up after the loser gave ground |  | 80% (49 of 61); on the table 87% | 98% (47 of 48); on the table 98% | 88% (96 of 109); on the table 92% |
| Winner chose to pursue after the loser fell back in good order |  | 92% (11 of 12); on the table 92% | 73% (8 of 11); on the table 82% | 83% (19 of 23); on the table 87% |
| Winner chose to pursue after the loser fled |  | 57% (16 of 28); on the table 64% | 72% (28 of 39); on the table 79% | 66% (44 of 67); on the table 73% |
| Winner chose to follow up or pursue (all three) |  | 75% (76 of 101); on the table 81% | 85% (83 of 98); on the table 89% | 80% (159 of 199); on the table 85% |
| Magic missiles tried each own turn | 50%+ | 37% (125 of 342) | 35% (54 of 156) | 36% (179 of 498) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 49% (125 of 253) | 46% (54 of 117) | 48% (179 of 370) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 55% (16 of 29) | 47% (20 of 43) | 50% (36 of 72) |
| Points that never fought | lower | 41% (29098 of 71583) | 39% (28399 of 71989) | 40% (57497 of 143572) |
|   infantry points that never fought | lower | 49% (8010 of 16324) | 69% (9655 of 14029) | 58% (17665 of 30353) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 56% (160 of 284) | 62% (183 of 297) | 59% (343 of 581) |
| Bound items with a magic missile used (at least once a game) |  | 90% (18 of 20); 1.6 uses a game | 67% (12 of 18); 1.1 uses a game | 79% (30 of 38); 1.4 uses a game |
| Bound items with another spell used |  | 61% (11 of 18); 0.7 uses a game | 50% (1 of 2); 0.1 uses a game | 60% (12 of 20); 0.4 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 50% (10 of 20); 0.3 uses a game | 14% (1 of 7); 0.0 uses a game | 41% (11 of 27); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 49% (29721 of 60231) | 56% (35413 of 63281) | 53% (65134 of 123512) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.4 (24%) | 1.0 (34%) | 2.4 (27%) |
| MARCHED: its unit marched | 1.8 (30%) | 0.4 (14%) | 2.2 (25%) |
| CHARGED: its unit charged | 0.2 (3%) | 0.1 (2%) | 0.2 (3%) |
| IN COMBAT: engaged in combat | 1.3 (22%) | 0.4 (15%) | 1.8 (20%) |
| REAR RANK: in a rear rank | 0.1 (1%) | 0.1 (3%) | 0.1 (2%) |
| FLEEING: fleeing | 0.2 (4%) | 0.1 (2%) | 0.3 (3%) |
| GONE: slain | 0.7 (12%) | 0.5 (18%) | 1.2 (13%) |
| OFF THE TABLE: off the table or not arrived | 0.2 (3%) | 0.1 (4%) | 0.3 (3%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.2 (9%) | 0.2 (3%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.4 | 1.6 | 1.5 | 5.0 | 0.4 | 1.9 |
| not cast | 3.4 | 3.4 | 3.5 | 8.9 | 1.9 | 19.8 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.1 (3%) | 0.0 (0%) | 0.0 (0%) | 1.4 (7%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.6 (48%) | 0.2 (7%) | 2.4 (27%) | 0.2 (13%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.2 (25%) | 0.4 (20%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (3%) | 0.0 (1%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (1%) | 0.2 (7%) | 0.5 (15%) | 1.8 (20%) | 0.3 (14%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.2 (7%) | 0.3 (10%) | 0.2 (6%) | 0.1 (2%) | 0.0 (0%) | 0.0 (0%) |
| NO CASTS LEFT: every cast used on other spells | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (1%) | 0.1 (2%) | 0.1 (4%) | 0.3 (3%) | 0.1 (3%) | 0.5 (2%) |
| GONE: slain | 0.7 (20%) | 0.5 (16%) | 0.6 (16%) | 1.2 (13%) | 0.4 (23%) | 3.1 (15%) |
| OFF THE TABLE: off the table or not arrived | 0.1 (2%) | 0.0 (1%) | 0.2 (7%) | 0.3 (3%) | 0.2 (9%) | 0.5 (2%) |
| STUPIDITY: Stupidity | 0.1 (2%) | 0.0 (1%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (4%) | 0.4 (13%) | 0.0 (1%) | 0.0 (0%) | 0.3 (16%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (3%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.2 (64%) | 0.1 (4%) | 1.4 (41%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 14.2 (72%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.8 a game | 0.8 a game | 0.8 a game |
| stood (cast and not dispelled) | 57% (16 of 28) | 67% (20 of 30) | 62% (36 of 58) |
| the unit moved after it | 69% (11 of 16) | 55% (11 of 20) | 61% (22 of 36) |
| it charged on its next turn | 0% (0 of 16) | 10% (2 of 20) | 6% (2 of 36) |
| the enemy charged it first | 50% (8 of 16) | 5% (1 of 20) | 25% (9 of 36) |
| it fought by the end of its next turn | 38% (6 of 16) | 0% (0 of 20) | 17% (6 of 36) |
| it moved out of a charge the enemy had planned (not charged first) | 12% (2 of 16) | 5% (1 of 20) | 8% (3 of 36) |
| none of these (no charge, no fight, no charge escaped) | 38% (6 of 16) | 80% (16 of 20) | 61% (22 of 36) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 67% (585 of 868) | 55% (433 of 792) | 61% (1018 of 1660) |
|   cavalry | 67% (42 of 63) | 58% (91 of 158) | 60% (133 of 221) |
|   character | 62% (78 of 126) | 39% (46 of 119) | 51% (124 of 245) |
|   chariot | 65% (70 of 108) | 60% (24 of 40) | 64% (94 of 148) |
|   infantry | 67% (176 of 262) | 52% (164 of 317) | 59% (340 of 579) |
|   monster | 40% (16 of 40) | 71% (27 of 38) | 55% (43 of 78) |
|   war machine | 75% (203 of 269) | 68% (81 of 120) | 73% (284 of 389) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.5 (19%) | 1.9 (19%) | 3.4 (19%) |
| CHARGED: it charged | 0.8 (11%) | 1.5 (15%) | 2.3 (13%) |
| FLEEING: it fled or was fleeing | 0.1 (1%) | 0.2 (2%) | 0.2 (1%) |
| IN COMBAT: it fought this turn or the last | 0.6 (7%) | 0.5 (5%) | 1.1 (6%) |
| MOVED: a war machine that moved | 1.0 (13%) | 0.0 (0%) | 1.0 (6%) |
| NO TARGET IN RANGE | 2.0 (25%) | 2.3 (23%) | 4.2 (24%) |
| ONLY IN COMBAT: the only targets were in combat | 0.5 (6%) | 1.2 (13%) | 1.7 (10%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.2 (15%) | 1.7 (17%) | 2.9 (16%) |
| SHELTERED: the target was sheltered | 0.1 (1%) | 0.1 (1%) | 0.2 (1%) |
| OTHER BAR | 0.2 (2%) | 0.6 (6%) | 0.7 (4%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 5.7 | 1.2 | 85% | 5.2 pts | 30 pts |
| character | 3.8 | 1.1 | 77% | 8.5 pts | 32 pts |
| chariot | 2.6 | 1.6 | 67% | 15.8 pts | 41 pts |
| infantry | 13.3 | 5.3 | 72% | 8.1 pts | 108 pts |
| monster | 1.4 | 0.5 | 76% | 8.7 pts | 12 pts |
| war machine | 7.9 | 6.6 | 60% | 24.3 pts | 192 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.7 | 5.3 | 4.5 |
| Charges that made contact a game | 2.9 | 4.0 | 3.5 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.85 declared, 0.69 contact (26 units) | 0.75 declared, 0.67 contact (12 units) | 0.82 declared, 0.68 contact (38 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.57 declared, 0.43 contact (7 units) | 0.91 declared, 0.82 contact (11 units) | 0.78 declared, 0.67 contact (18 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.43 declared, 0.33 contact (251 units) | 0.60 declared, 0.45 contact (287 units) | 0.52 declared, 0.39 contact (538 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 60% (44 of 73) | 39% (7 of 18) | 50% (6 of 12) | 55% (57 of 103) |
| Character in a unit | 75% (27 of 36) | 59% (10 of 17) | 100% (2 of 2) | 71% (39 of 55) |
| Character on its own | 78% (28 of 36) | 51% (19 of 37) | 28% (18 of 64) | 47% (65 of 137) |
| Chariot | 82% (14 of 17) | 69% (9 of 13) | - | 77% (23 of 30) |
| Infantry | 61% (57 of 94) | 44% (15 of 34) | 0% (0 of 3) | 55% (72 of 131) |
| Monster | 41% (12 of 29) | 56% (5 of 9) | - | 45% (17 of 38) |
| Monstrous | 64% (9 of 14) | 86% (12 of 14) | - | 75% (21 of 28) |
| War Machines | 82% (47 of 57) | 100% (2 of 2) | - | 83% (49 of 59) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 100% (5 of 5); on the table 100% | 42% (43 of 102) | 27% | 41% (9 of 22) | 100% (6 of 6); 5.2 uses a game | 100% (2 of 2); 1.8 uses a game | 83% (5 of 6); 1.2 uses a game |
| Chaos Dwarfs | 4 | 100% (7 of 7); on the table 100% | 39% (14 of 36) | 53% | 56% (18 of 32) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
| Dwarfen Mountain Holds | 6 | 61% (11 of 18); on the table 61% | - | 63% | 70% (38 of 54) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 7 | 57% (8 of 14); on the table 79% | 48% (23 of 48) | 47% | 68% (52 of 76) | 0.0 uses a game | 50% (1 of 2); 0.6 uses a game | 0% (0 of 4); 0.0 uses a game |
| Grand Cathay | 6 | 71% (15 of 21); on the table 76% | 31% (43 of 138) | 40% | 44% (24 of 54) | 79% (11 of 14); 5.2 uses a game | 100% (2 of 2); 1.0 uses a game | 0% (0 of 6); 0.0 uses a game |
| High Elf Realms | 4 | 90% (9 of 10); on the table 90% | 17% (3 of 18) | 29% | 48% (16 of 33) | 100% (3 of 3); 3.2 uses a game | 50% (7 of 14); 2.8 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 2 | 57% (4 of 7); on the table 57% | - | 46% | 50% (6 of 12) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.5 uses a game |
| Lizardmen | 1 | - | - | 57% | 71% (5 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 4 | 91% (10 of 11); on the table 91% | 0% (0 of 18) | 39% | 89% (25 of 28) | 75% (3 of 4); 2.5 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 1 | 100% (7 of 7); on the table 100% | 17% (2 of 12) | 3% | 38% (3 of 8) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Skaven | 3 | 77% (10 of 13); on the table 92% | 67% (12 of 18) | 48% | 64% (16 of 25) | 50% (1 of 2); 0.7 uses a game | 0.0 uses a game | 100% (3 of 3); 1.0 uses a game |
| Tomb Kings of Khemri | 5 | 88% (14 of 16); on the table 94% | - | 39% | 32% (8 of 25) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 9 | 81% (30 of 37); on the table 86% | 32% (21 of 66) | 31% | 50% (27 of 54) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 9 | 86% (12 of 14); on the table 93% | 44% (8 of 18) | 25% | 66% (48 of 73) | 100% (2 of 2); 0.8 uses a game | 0.0 uses a game | 100% (1 of 1); 0.1 uses a game |
| Wood Elf Realms | 7 | 89% (17 of 19); on the table 89% | 42% (10 of 24) | 50% | 62% (48 of 78) | 57% (4 of 7); 2.0 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (hmw-mine-c1e47a9-p2, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 49% (41) | 47% (28) | 49% (69) |
| ...free all their last turn and able to turn (per game) | 0.56 | 0.53 | 1.08 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.36 | 0.14 | 0.50 |
| ...with the charger already in that arc before they moved (per game) | 0.36 | 0.33 | 0.69 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.97 | 0.97 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.47 | 0.47 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.14 | 6.03 | 6.17 |

### Quality by phase: hmw-mine-c1e47a9-p2

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.1 | 2.5 |
| Strategy | Charge objectives carried out (made contact) | 64% (72 of 112) | 50% (99 of 198) |
| Strategy | Shoot objectives carried out (shot that target) | 36% (135 of 374) | 38% (100 of 261) |
| Strategy | Close-in objectives charged next turn | - | 17% (45 of 258) |
| Strategy | Support requests answered (helper made contact too) | 58% (7 of 12) | 39% (12 of 31) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (2 of 2) | 100% (2 of 2) |
| Strategy | Hexes on a unit its side charged or shot that turn | 42% (8 of 19) | 57% (8 of 14) |
| Strategy | Joined characters whose unit fought | 44% (24 of 54) | 34% (12 of 35) |
| Strategy | Lone characters that fought | 71% (65 of 91) | 76% (67 of 88) |
| Movement | Charges halted short of contact | 0.1 | 0.2 |
| Movement | Idle units | 1.3 | 1.8 |
| Movement | Points that never moved of their own | 206.4 | 195.2 |
| Movement | Fights charged into per game | 2.7 | 3.6 |
| Movement | Charges with odds: long shots (under 50%) | 11 of 75, net +96 | 31 of 118, net +35 |
| Movement | Charges with odds: sweet spot (55-75%) | 15 of 75, net +22 | 20 of 118, net +37 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 9 of 75, net +81 | 4 of 118, net +94 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 21 of 75, net +80 | 30 of 118, net +113 |
| Shooting | Shots by shooting units (incl. breath weapons) | 11.7 | 10.6 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 43% (179 of 420) | 48% (184 of 382) |
| Shooting | Points destroyed by shooting units | 101.6 | 24.5 |
| Shooting | War machine shots | 5.6 | 2.2 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 59% (120 of 203) | 52% (42 of 81) |
| Shooting | Points destroyed by war machines | 64.4 | 27.1 |
| Magic | Magic missiles cast | 1.9 | 0.9 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 34% (24 of 70) | 73% (24 of 33) |
| Magic | Wounds caused by magic missiles | 4.1 | 1.3 |
| Magic | Wounds caused by other spells | 2.2 | 0.5 |
| Magic | Points destroyed by magic (all spells) | 56.5 | 37.6 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.1 / 0.7 / 1.0 / 0.1 | 2.1 / 0.4 / 0.3 / 0.1 |
| Combat | Points destroyed in combat | 336.2 | 411.0 |
| Combat | Points run down | 68.7 | 95.9 |
| Combat | Net points per charged fight, damage counted | +76 | +85 |
| Combat | Net per 100 charger points, damage counted | +27.7 | +32.6 |
| Combat | First round won (charged fights) | 80% | 70% |
| Combat | Net points per charged fight | +70 | +81 |
| Combat | Net points per supported fight / lone fight | +198 / +58 | +211 / +62 |
| Combat | Charged fights on a top-3 enemy unit | 27 of 96 | 63 of 128 |
| Game | Points lost | 707.7 | 696.9 |
| Game | VP from objectives | 574.7 | 604.2 |
| Game | Lone holders (player turns) | 3.9 | 2.2 |

- Mine won / drew / lost: 14 / 8 / 14 of 36 ended games (of 36); mean margin (Mine - Opponent) -54 VP
- The side that went first won 13 of 28 games with a winner
- Points traded per game (both sides' losses): 1405
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: hmw-mine-c1e47a9-p2

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.8 | +0.0 | 0.0 | 0.0 | 1.1 | +0.0 | 0.0 | 0.0 |
| ADVANCE WORTH | - | - | - | - | 4.4 | -108.9 | 140.7 | 104.6 |
| AFTERMATH IN POINTS | 0.3 | +37.0 | 0.0 | 16.2 | - | - | - | - |
| AFTERMATH WITH FRIENDS | 0.1 | +11.5 | 0.0 | 0.0 | - | - | - | - |
| ALREADY CARRIED | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | 13.8 | +185.4 | 0.0 | 186.6 | - | - | - | - |
| ARRIVAL HUNT | - | - | - | - | 0.1 | +6.1 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.2 | +0.0 | 0.0 | 25.4 | 0.4 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | 0.2 | +0.9 | 0.0 | 1.5 | 0.4 | +1.5 | 0.0 | 7.0 |
| BEST FACING | - | - | - | - | 0.4 | +16.8 | 0.0 | 41.8 |
| BEST FIRST | - | - | - | - | 1.7 | +103.8 | 18.2 | 30.9 |
| BEST MOVE FOR SHOOTERS | - | - | - | - | 0.6 | +23.5 | 0.0 | 8.2 |
| BEST OVERALL | - | - | - | - | 0.2 | +10.4 | 0.0 | 10.2 |
| BEST PREY | - | - | - | - | 0.9 | +50.7 | 13.9 | 41.4 |
| BEST PRIZE | - | - | - | - | 0.1 | -3.7 | 10.8 | 0.0 |
| BIG CHARACTER SAFETY | - | - | - | - | 0.1 | -0.4 | 0.0 | 0.0 |
| BLOCKED CHARGE SKIPPED | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |
| BLOCKED WHEEL | - | - | - | - | 0.5 | +8.6 | 0.0 | 4.7 |
| BLOWS WHERE AIMED | 0.2 | -22.8 | 36.6 | 0.0 | 0.2 | -37.4 | 18.5 | 33.9 |
| BOMBING RUN | 0.1 | +1.7 | 5.1 | 0.0 | - | - | - | - |
| BOUND ASSAILMENT | 0.1 | +0.0 | 0.0 | 12.6 | - | - | - | - |
| CANNON PLAN MISSED | 0.5 | +0.0 | 161.3 | 3.5 | 0.2 | +0.0 | 31.2 | 0.0 |
| CANNON PLANNED TARGET | 5.6 | +218.2 | 559.9 | 120.3 | 2.0 | +61.3 | 75.7 | 22.4 |
| CANNON SIGHT KEPT | 1.0 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT COUNTER | - | - | - | - | 0.0 | +0.0 | 9.4 | 0.0 |
| CARRIES OUT SET-UP | - | - | - | - | 0.3 | -0.8 | 41.9 | 13.6 |
| CAST JOB | 0.9 | +14.1 | 48.2 | 11.1 | 0.5 | +8.3 | 18.4 | 0.0 |
| CASTER AWAY FROM SCREEN | 0.3 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.3 | +18.7 | 10.3 | 0.0 | 0.3 | +10.8 | 13.5 | 0.0 |
| CASTS AFTER FRIENDS | 0.5 | +0.0 | 0.0 | 12.5 | 0.6 | +0.0 | 0.0 | 7.6 |
| CASTS FROM BEHIND | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | 0.8 | +33.3 | 0.0 | 12.2 | 1.5 | +67.3 | 0.0 | 46.9 |
| CHAFF PASSED | 0.2 | -0.3 | 0.0 | 5.9 | 0.5 | -0.6 | 0.0 | 5.2 |
| CHAMPION KNOWS CHALLENGE | 0.1 | -1.9 | 23.6 | 0.0 | 0.1 | -5.2 | 5.2 | 9.6 |
| CHARACTER GUNS | 1.5 | +0.0 | 0.0 | 10.5 | - | - | - | - |
| CHARGE LIST READ AGAIN | 0.0 | +4.7 | 3.2 | 5.4 | - | - | - | - |
| CHARGE LOSSES | 9.4 | -495.7 | 0.0 | 311.2 | - | - | - | - |
| CHARGE NOT DECLARED | 0.0 | +0.0 | 1.7 | 0.0 | 0.8 | +0.0 | 54.3 | 23.8 |
| CHARGE NOW FIRST | 2.0 | +0.0 | 204.7 | 51.1 | 3.2 | +0.0 | 302.2 | 179.1 |
| CHARGE NOW WEIGHED | - | - | - | - | 0.3 | -31.9 | 3.4 | 23.6 |
| CHARGER SLAIN LOST | 0.3 | -9.6 | 10.6 | 12.3 | 0.6 | -20.1 | 43.5 | 8.8 |
| CHEAP HELPER | - | - | - | - | 0.2 | +0.0 | 30.3 | 3.5 |
| COMBAT PIVOT | 0.2 | +0.0 | 16.6 | 29.2 | 0.7 | +0.0 | 23.1 | 23.7 |
| CONTINUE AHEAD WEIGHED | 0.1 | +0.0 | 0.0 | 7.1 | 0.0 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | 0.6 | +73.1 | 17.6 | 2.6 | 0.7 | +80.8 | 25.3 | 36.7 |
| COVER ONCE | 6.1 | -449.4 | 0.0 | 110.8 | 5.6 | -398.7 | 0.0 | 173.9 |
| DEFENSIVE ARMY | 0.1 | +0.0 | 5.9 | 5.8 | 0.0 | +0.0 | 0.0 | 0.0 |
| DENIED BY THE FIGHT | 0.7 | -5.2 | 76.3 | 29.6 | - | - | - | - |
| DEPLOY BY FIGURES | 8.1 | +16.0 | 0.0 | 9.7 | 8.0 | +56.8 | 0.0 | 27.1 |
| EDGE GIVE GROUND | 0.2 | +1.3 | 26.4 | 5.4 | 0.4 | +7.8 | 44.1 | 3.4 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | - | - | - | - | 1.0 | +57.4 | 0.0 | 44.9 |
| FALL BACK GOOD ORDER | 2.5 | +14.4 | 235.8 | 72.5 | - | - | - | - |
| FALLBACK BY WORTH | 0.2 | +0.0 | 0.0 | 1.5 | 5.1 | +35.6 | 0.0 | 46.5 |
| FALLS SHORT | 5.1 | +95.4 | 0.0 | 82.7 | - | - | - | - |
| FEATURE BUFFS | 1.5 | +34.7 | 0.0 | 39.1 | - | - | - | - |
| FIGHT LIFT | 0.1 | +0.7 | 9.4 | 0.0 | - | - | - | - |
| FIGHT TO THE END | 0.9 | +9.7 | 113.8 | 26.1 | - | - | - | - |
| FIRE AND FLEE | 0.1 | +0.4 | 0.0 | 2.2 | 0.0 | +0.1 | 0.0 | 0.0 |
| FIRE IN ORDER | 0.2 | +0.0 | 13.7 | 7.4 | 0.2 | +0.0 | 4.7 | 1.8 |
| FIVE ACTION | 83.4 | +4491.1 | 2234.7 | 1249.2 | - | - | - | - |
| FLANK NOT WEIGHED | 4.2 | +0.0 | 0.0 | 151.0 | 5.3 | +0.0 | 0.0 | 133.2 |
| FOCUS FIRE | 0.1 | +3.0 | 4.7 | 0.0 | 0.1 | +0.2 | 3.1 | 0.0 |
| FOLLOW UP WEIGHED | 0.8 | +135.1 | 0.0 | 28.5 | 1.2 | +139.5 | 0.0 | 25.1 |
| FOUR ROUNDS | 3.4 | +273.6 | 336.8 | 104.8 | - | - | - | - |
| FRIEND SHOOTS FIRST | 0.6 | -12.3 | 0.0 | 0.0 | - | - | - | - |
| FRIENDS SHOTS CHECKED | 0.2 | +7.7 | 0.0 | 5.8 | 0.1 | +4.5 | 0.0 | 0.0 |
| GATEWAY ESCAPE | - | - | - | - | 0.0 | +1.7 | 0.0 | 0.0 |
| GIVES UP | 0.3 | -4.0 | 25.5 | 0.0 | 0.2 | -2.8 | 13.2 | 2.5 |
| GIVES UP ITS SCREEN | - | - | - | - | 0.0 | -0.0 | 4.2 | 0.0 |
| GUN FIGURES | 1.2 | +15.4 | 40.8 | 1.8 | 0.4 | +7.0 | 6.8 | 15.4 |
| GUN MASK | 0.9 | +7.8 | 0.0 | 19.7 | - | - | - | - |
| HARD STAY DROPPED | 1.9 | +0.0 | 0.0 | 9.5 | - | - | - | - |
| HE SHOOTS OR CHARGES | 3.2 | +0.0 | 0.0 | 127.2 | - | - | - | - |
| HELPER ALREADY ASKED | - | - | - | - | 0.1 | +0.0 | 18.7 | 0.0 |
| HELPER UNSEEN | - | - | - | - | 0.1 | +0.0 | 0.0 | 8.3 |
| HILL BY ITS CHANCE | - | - | - | - | 0.8 | -73.4 | 0.0 | 0.0 |
| HIS CHARGE DENIED | 0.5 | +29.1 | 66.3 | 2.9 | - | - | - | - |
| HIS CHARGE LIST | 4.5 | +0.0 | 0.0 | 58.8 | - | - | - | - |
| HIS FIGHT TOGETHER | 2.2 | -36.8 | 0.0 | 119.8 | - | - | - | - |
| HIS LEGAL MOVES | 4.7 | +0.0 | 0.0 | 96.9 | - | - | - | - |
| HIS MOVE AND SHOT | 2.6 | -47.2 | 0.0 | 120.2 | - | - | - | - |
| HIS MOVE AS HE DECIDES | 37.6 | +13.4 | 781.4 | 0.0 | - | - | - | - |
| HIS MOVE WHY | - | - | - | - | 38.2 | +0.0 | 0.0 | 642.4 |
| HIS ONE MOVE | 16.9 | +55.6 | 0.0 | 133.9 | - | - | - | - |
| HIS OWN BEST MOVE | 1.7 | +0.0 | 0.0 | 26.3 | - | - | - | - |
| HIS RANDOM MOVE | 4.9 | +0.0 | 0.0 | 25.8 | - | - | - | - |
| HIS SHOT LIST | 32.7 | +1180.2 | 0.0 | 522.9 | - | - | - | - |
| HIS TURN DENIED | 1.3 | +29.0 | 126.7 | 49.2 | - | - | - | - |
| HOLD ODDS | 9.8 | +0.0 | 0.0 | 92.1 | - | - | - | - |
| HOLDER ASSIGNMENT | 10.3 | +961.5 | 0.0 | 117.9 | - | - | - | - |
| HOLDER AT DEPLOYMENT | - | - | - | - | 1.0 | +157.1 | 0.0 | 3.2 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 2.9 | -102.0 | 290.3 | 92.4 | 11.6 | -242.9 | 665.9 | 347.3 |
| HORN WORTH | - | - | - | - | 0.0 | +0.2 | 0.0 | 0.0 |
| HUNT ADVANCE | - | - | - | - | 0.1 | +0.4 | 0.0 | 0.0 |
| HUNT DROPPED | - | - | - | - | 0.1 | +0.0 | 11.5 | 0.0 |
| HUNT IN PAIRS | 0.2 | +7.8 | 0.0 | 16.1 | 0.4 | +33.9 | 0.0 | 0.0 |
| HUNT KEPT | - | - | - | - | 0.1 | +0.6 | 9.3 | 0.0 |
| HUNT RESULT | 0.0 | +3.7 | 0.0 | 2.4 | 0.2 | +32.4 | 16.1 | 2.5 |
| HUNT THE GUNS | 0.0 | +3.8 | 3.3 | 0.0 | 0.3 | +102.1 | 12.6 | 2.5 |
| IDLE COST | 3.9 | -47.0 | 0.0 | 41.1 | 19.6 | -315.1 | 0.0 | 267.7 |
| INVITES THE FIGHT | - | - | - | - | 0.7 | +5.4 | 12.3 | 9.3 |
| JOINT CHARGE NOW | 0.7 | +17.0 | 115.6 | 46.0 | - | - | - | - |
| JOINT CHARGE PLAN | - | - | - | - | 0.4 | +13.8 | 7.8 | 6.0 |
| JOINT KNOWS CHALLENGE | 0.0 | -0.2 | 6.3 | 0.0 | 0.1 | -1.8 | 10.5 | 14.6 |
| JOINT ON THE TABLE | 0.0 | +0.5 | 1.7 | 1.4 | - | - | - | - |
| KEEP FALLS | 0.1 | +0.5 | 0.0 | 0.0 | - | - | - | - |
| KEEPS ITS PREY | - | - | - | - | 0.0 | +0.1 | 0.0 | 0.0 |
| KEEPS ITS TARGET | - | - | - | - | 3.0 | +90.8 | 286.2 | 81.8 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| KILLS COUNT | - | - | - | - | 2.2 | +102.9 | 238.4 | 66.1 |
| KILLS COUNT NEXT TURN | - | - | - | - | 7.2 | +256.7 | 201.0 | 166.5 |
| LANE BY FIGURES | 0.7 | +29.8 | 0.0 | 0.0 | 0.9 | +43.7 | 0.0 | 18.2 |
| LEGAL CHARGES ONLY | 5.2 | +0.0 | 175.5 | 292.2 | - | - | - | - |
| LONE CHARACTER SAFE SPOT | 0.1 | +0.7 | 11.7 | 1.2 | 0.4 | +17.1 | 15.2 | 0.0 |
| LONE WIZARD HOLDS BACK | - | - | - | - | 0.1 | +0.0 | 13.7 | 9.8 |
| LONE WIZARD KEPT IN | 0.6 | +39.4 | 0.0 | 0.0 | 0.3 | +24.1 | 0.0 | 0.0 |
| LONG SHOT | 0.2 | -1.9 | 21.3 | 3.1 | 0.3 | +2.0 | 9.9 | 0.0 |
| LOST AFTER ESCAPE | 2.1 | +0.3 | 211.4 | 53.9 | - | - | - | - |
| LOST CHARGE | 0.1 | -0.2 | 22.2 | 0.0 | 1.7 | -20.3 | 54.4 | 100.2 |
| LURE BY WHAT IT DRAWS | 0.0 | -3.0 | 0.0 | 0.0 | 0.1 | -11.1 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 0.1 | +2.3 | 0.0 | 4.7 | 1.4 | +80.3 | 36.0 | 14.4 |
| MANOEUVRE | 0.6 | -0.3 | 0.0 | 0.0 | 0.3 | +11.9 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.2 | +2.2 | 0.0 | 10.2 | 0.0 | +0.1 | 0.0 | 0.0 |
| MARCH BY THE SUM | 0.5 | +40.2 | 0.0 | 10.2 | - | - | - | - |
| MARCH CHECK | 0.6 | +27.6 | 0.0 | 26.4 | 0.4 | +6.3 | 0.0 | 9.8 |
| MARCH ODDS | - | - | - | - | 0.2 | +18.1 | 0.0 | 21.6 |
| MARCH OF THE TABLE | 0.2 | +3.3 | 0.0 | 16.1 | - | - | - | - |
| MARCH OVER CASTS | 1.0 | +79.7 | 0.0 | 46.9 | 0.3 | +15.7 | 0.0 | 9.9 |
| MAX FOR POSITIONING | 2.5 | +42.8 | 0.0 | 72.2 | 7.1 | +96.4 | 0.0 | 150.0 |
| MISSILES IN THE MOVE | 3.8 | +76.8 | 0.0 | 37.8 | 3.3 | +57.5 | 0.0 | 86.5 |
| MISSILES NEXT TURN | 5.1 | +63.8 | 0.0 | 74.4 | 3.8 | +50.2 | 0.0 | 89.4 |
| MODEL FACING | 0.4 | +103.6 | 0.0 | 1.7 | 0.1 | +66.3 | 0.0 | 3.3 |
| MONSTER WIZARD ROAMS | - | - | - | - | 0.2 | +0.0 | 13.3 | 0.0 |
| MOVE AND CAST | - | - | - | - | 0.3 | +16.9 | 0.0 | 4.4 |
| MOVE ORDER | 1.9 | +0.0 | 19.6 | 10.9 | - | - | - | - |
| MOVE SPELL IN RANGE | 0.1 | +5.2 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.3 | -9.4 | 8.1 | 28.6 | 0.4 | -12.4 | 2.8 | 7.6 |
| MOVE SPELL SPOT | 0.2 | +0.0 | 0.0 | 12.3 | 0.1 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE | - | - | - | - | 6.1 | +415.0 | 171.8 | 159.5 |
| MOVE TO CHARGE COMPUTED | 7.1 | +573.7 | 0.0 | 113.7 | - | - | - | - |
| MOVES UNITS SPELL | 0.1 | +3.4 | 0.0 | 0.0 | - | - | - | - |
| NEARER NOT NEEDED | 5.7 | +231.6 | 0.0 | 69.4 | - | - | - | - |
| NEXT CHARGE BY LIST | 6.4 | -218.2 | 33.1 | 62.6 | - | - | - | - |
| NEXT OBJECTIVE NEARER | 0.1 | -1.8 | 0.0 | 0.0 | - | - | - | - |
| NO DOUBLE ROUNDS | 3.0 | -143.7 | 290.4 | 60.1 | - | - | - | - |
| NO RALLY LEFT | 0.0 | +0.6 | 0.0 | 9.6 | - | - | - | - |
| NOT NEEDED | - | - | - | - | 0.6 | -35.9 | 94.2 | 5.2 |
| NOT TURNED | 0.1 | -0.0 | 0.0 | 1.9 | 6.0 | +43.2 | 0.0 | 137.6 |
| NOT WORTH A CAST | 0.6 | -0.4 | 0.0 | 0.0 | 0.6 | -0.5 | 0.0 | 20.7 |
| OFF BEST | 3.0 | -107.6 | 28.6 | 37.6 | 17.6 | -826.9 | 6.9 | 246.5 |
| ONE CHARGE A CHARGER | 4.4 | +0.0 | 0.0 | 137.1 | - | - | - | - |
| ONE FIGHT FORMULA | 5.6 | -104.8 | 0.0 | 126.9 | 8.7 | -198.5 | 12.3 | 273.9 |
| ONE OBJECTIVE FORMULA | 3.5 | +3.3 | 0.0 | 48.2 | 2.7 | -206.2 | 0.0 | 28.4 |
| ONE PROMISE A TARGET | 0.1 | -1.2 | 0.0 | 0.0 | - | - | - | - |
| ONE TARGET A SHOOTER | 25.0 | +530.7 | 0.0 | 365.3 | - | - | - | - |
| OPENS A LANE | 0.1 | +0.5 | 1.7 | 0.0 | 0.0 | +0.1 | 1.5 | 0.0 |
| OPENS UP | 0.2 | +13.8 | 18.2 | 5.4 | 0.2 | +10.4 | 11.1 | 5.4 |
| OVERRUNS AWAY | 0.7 | +37.2 | 63.6 | 49.1 | 0.6 | +14.9 | 66.1 | 4.9 |
| OWN CAST FIRST | 0.1 | -0.6 | 0.0 | 0.0 | - | - | - | - |
| PATHS CROSS | 0.3 | +8.5 | 0.0 | 1.8 | 3.2 | +200.4 | 0.0 | 72.1 |
| PERIAPT WORTH | 0.1 | +5.1 | 0.0 | 0.0 | 0.0 | +1.5 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.0 | -0.3 | 0.0 | 0.0 | 0.1 | -1.2 | 0.0 | 0.0 |
| PLAN RESULT | 39.6 | +1264.0 | 714.7 | 909.7 | 41.3 | +1116.6 | 1357.3 | 936.0 |
| PROMISE BELOW ZERO | 0.2 | +0.0 | 0.0 | 3.2 | - | - | - | - |
| PROMISE BY ITS OWN SUM | 9.0 | -240.3 | 0.0 | 76.1 | - | - | - | - |
| PROMISE HOLDS THE SPOT | 0.0 | +0.3 | 0.0 | 0.0 | - | - | - | - |
| PROMISE IN STEPS | 0.2 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE KNOWS THE FIGHT | 0.9 | -1.3 | 0.0 | 10.3 | - | - | - | - |
| PROMISE READS THE TABLE | 0.3 | -5.7 | 0.0 | 0.0 | - | - | - | - |
| PROMISE SHOT AWAY | 0.1 | -0.4 | 3.2 | 0.0 | - | - | - | - |
| PURSUES BIG PREY | 0.0 | -0.3 | 0.0 | 0.0 | 0.0 | -4.1 | 0.0 | 0.0 |
| QUARTER ODDS | 8.3 | +1250.6 | 192.8 | 213.6 | - | - | - | - |
| RANDOM MOVE BY FIGURES | 0.8 | +18.3 | 0.0 | 30.6 | 1.2 | +17.5 | 0.0 | 42.2 |
| RANDOM MOVER NO PROMISE | - | - | - | - | 0.1 | -2.9 | 0.0 | 4.7 |
| REDIRECT BY WHAT IT STOPS | 0.5 | -15.5 | 0.0 | 9.3 | 1.0 | -33.4 | 0.0 | 33.9 |
| REDIRECT COUNTER | 1.9 | +98.3 | 0.0 | 50.9 | 4.1 | +285.3 | 0.0 | 57.0 |
| REDIRECT WEIGHED | 0.1 | +2.2 | 4.0 | 13.1 | 0.2 | +0.8 | 15.8 | 9.6 |
| REFORMS TO MEET IT | 1.4 | -24.6 | 0.0 | 6.4 | - | - | - | - |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 5.1 | 0.6 | +0.0 | 0.0 | 27.5 |
| RESERVE FALL BACK | 0.4 | +37.0 | 0.0 | 10.2 | 1.0 | +51.6 | 0.0 | 17.3 |
| RESTRAINS TO SHOOT | 0.1 | +2.2 | 0.0 | 0.0 | 0.1 | +2.2 | 0.0 | 1.7 |
| RISK BY ARC | 2.5 | +50.0 | 229.0 | 86.9 | 3.0 | +76.8 | 286.1 | 110.7 |
| RISK BY HIS FIGURE | 21.8 | -405.7 | 0.0 | 588.9 | - | - | - | - |
| RISK ONCE | - | - | - | - | 3.0 | +161.4 | 29.0 | 253.4 |
| ROUNDS AFTER TERROR | 0.6 | -11.9 | 78.8 | 33.8 | - | - | - | - |
| RUN DOWN | 2.2 | -30.2 | 191.6 | 51.8 | - | - | - | - |
| SAFER THAN THE JOB | - | - | - | - | 0.5 | +35.0 | 0.0 | 5.1 |
| SCOUT SPOT | 0.3 | +1.1 | 0.0 | 2.0 | 0.5 | +1.6 | 0.0 | 0.0 |
| SCOUT WAITS | 0.3 | +0.0 | 0.0 | 2.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.5 | -12.6 | 0.0 | 6.8 | 0.7 | -37.3 | 0.0 | 4.6 |
| SEARCH SPOT | 0.5 | +5.7 | 0.0 | 1.5 | 2.2 | +75.1 | 0.0 | 23.9 |
| SECOND HUNTER | - | - | - | - | 0.0 | -0.1 | 0.0 | 0.0 |
| SECOND LOOK | 0.3 | +10.5 | 31.9 | 0.0 | - | - | - | - |
| SELF MOVE SPELL | 0.3 | +5.7 | 0.0 | 0.0 | - | - | - | - |
| SET UP BY THE SET | 1.5 | +31.7 | 3.5 | 24.6 | - | - | - | - |
| SET UP TOGETHER | 0.2 | +2.8 | 0.0 | 4.7 | 2.3 | +163.0 | 62.1 | 31.8 |
| SET-UP ANY TARGET | 0.1 | +5.5 | 0.0 | 0.0 | 0.1 | +7.8 | 1.4 | 11.2 |
| SET-UP MISSED | 0.0 | +1.5 | 1.5 | 0.0 | 0.1 | +11.9 | 0.0 | 11.2 |
| SHOOTER COUNTED ONCE | 0.1 | -0.2 | 0.0 | 3.1 | 0.0 | -0.5 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.4 | +0.8 | 0.0 | 0.0 | 0.3 | +0.6 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 2.3 | +59.3 | 91.8 | 16.1 | 1.1 | +23.0 | 59.3 | 14.6 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| SHOT OR CHARGE | 0.5 | -22.4 | 59.5 | 7.5 | - | - | - | - |
| SHOT RISK POINTS | 14.8 | -80.8 | 0.0 | 295.7 | - | - | - | - |
| SHOTS AFTER THE MOVES | 3.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SHOTS IN THE MOVE | 15.9 | +721.4 | 0.0 | 255.0 | 11.7 | +289.1 | 0.0 | 134.2 |
| SPELL SETS UP CHARGE | 0.1 | +5.5 | 0.0 | 0.0 | 0.2 | +37.6 | 11.6 | 21.5 |
| SPELL WORTH | 1.0 | +18.8 | 28.3 | 26.1 | 1.8 | +21.7 | 58.3 | 70.1 |
| SPELLS IN THE FIGHT | 0.7 | +7.4 | 81.1 | 17.2 | 0.8 | -12.1 | 91.9 | 33.8 |
| SPOT AS THE GAME MOVES | 7.0 | +0.0 | 0.0 | 165.7 | - | - | - | - |
| STABLE ROLE | - | - | - | - | 11.2 | +0.0 | 357.6 | 223.1 |
| STAND AND SHOOT | 0.7 | -6.5 | 76.6 | 8.3 | - | - | - | - |
| STANDS FOR A REASON | 0.4 | +0.0 | 4.0 | 7.8 | - | - | - | - |
| STANDS STILL | 37.7 | +0.0 | 1897.9 | 458.9 | - | - | - | - |
| STAY WEIGHED | - | - | - | - | 0.0 | +0.2 | 0.0 | 0.0 |
| STAY WORTH | 23.5 | -7.2 | 1085.6 | 292.8 | 14.9 | +127.5 | 248.7 | 157.5 |
| STOPS | 0.0 | +0.2 | 3.3 | 0.0 | 0.3 | +15.6 | 21.9 | 2.5 |
| STOPS SHORT OF THE FLANK | - | - | - | - | 0.2 | +9.1 | 0.0 | 0.0 |
| STUCK PIVOT | 0.2 | +0.0 | 0.0 | 9.4 | 0.1 | +0.0 | 0.0 | 0.0 |
| STUPIDITY NEXT TURN | 0.4 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SUPPORT NARROWED | 0.4 | +0.0 | 19.1 | 2.9 | 7.1 | -47.2 | 378.9 | 105.4 |
| SUPPORT WORKED OUT | 2.6 | +107.4 | 0.0 | 22.9 | - | - | - | - |
| SUPPORTS | - | - | - | - | 4.5 | +49.7 | 139.8 | 53.4 |
| SURE CHARGE BEATS ADVANCE | - | - | - | - | 0.1 | -2.2 | 0.0 | 0.0 |
| SURE REACH TOGETHER | 0.2 | +3.7 | 0.0 | 2.1 | 0.9 | -1.2 | 14.4 | 12.1 |
| THE DEARER SUM KEEPS ITS PLAN | 1.2 | +0.0 | 0.0 | 9.6 | - | - | - | - |
| THE PROMISE ADDS | 0.1 | -4.2 | 0.0 | 0.0 | - | - | - | - |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE TABLE BINDS | 27.8 | +0.0 | 0.0 | 380.5 | - | - | - | - |
| THROUGH LINE OF FIRE | - | - | - | - | 0.2 | +5.9 | 0.0 | 3.5 |
| TIED UP BY THE SUM | 0.8 | +76.5 | 59.3 | 24.1 | - | - | - | - |
| TIME ON OUR SIDE | 29.4 | +353.1 | 20.7 | 243.3 | - | - | - | - |
| TURN WORTH | - | - | - | - | 0.3 | -20.3 | 28.3 | 0.0 |
| TWO OR MORE ARRIVE | - | - | - | - | 0.6 | +3.1 | 14.2 | 2.4 |
| WAIT AFTER COSTS | - | - | - | - | 9.3 | -479.4 | 259.9 | 224.1 |
| WAITS AGAIN | 2.1 | +0.0 | 0.0 | 39.5 | - | - | - | - |
| WALKS TO THE FIGHT | - | - | - | - | 1.7 | +11.9 | 52.1 | 32.7 |
| WAR ENGINE CHARGES | 0.0 | +1.2 | 0.0 | 0.0 | 0.1 | +1.9 | 6.8 | 5.1 |
| WAR ENGINE JOBS | 0.4 | +0.0 | 12.2 | 4.2 | 0.3 | +0.0 | 3.5 | 21.5 |
| WEARS DOWN | - | - | - | - | 1.6 | +47.4 | 176.2 | 111.2 |
| WHAT THE JOINER ADDS | 0.3 | +0.1 | 33.4 | 0.0 | - | - | - | - |
| WHO GETS IN | 0.1 | -11.0 | 8.6 | 13.1 | - | - | - | - |
| WHO HITS BACK | 0.4 | +48.9 | 0.0 | 22.7 | 0.2 | +20.6 | 0.0 | 5.4 |
| WHOLE FIGHT | 0.1 | +4.1 | 16.7 | 0.0 | 0.4 | +2.7 | 39.1 | 9.0 |
| WHOLE FIGHT GAIN | 0.1 | +1.6 | 19.0 | 0.0 | 0.7 | +54.0 | 83.3 | 7.7 |
| WIDER SPREAD | 2.3 | -2.6 | 160.0 | 55.8 | 3.8 | -5.6 | 415.2 | 88.7 |
| WOUNDED STAYS OUT | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |
| WOUNDS ON THE RANKS | 2.7 | +153.5 | 0.0 | 51.4 | - | - | - | - |

### Rule changes: hmw-mine-c1e47a9-p2

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS MOVE AS HE DECIDES | 1353 | 1353 | 869 | 24.14 | +0 | +0.0 |
| HIS MOVE WHY | 1375 | 1375 | 745 | 20.69 | +0 | +0.0 |
| OFF BEST | 740 | 740 | 740 | 20.56 | -33643 | -45.5 |
| ARMY TABLE | 497 | 497 | 363 | 10.08 | +4499 | +12.4 |
| DEPLOY BY FIGURES | 578 | 578 | 357 | 9.92 | +4929 | +13.8 |
| HOLDER ASSIGNMENT | 372 | 372 | 347 | 9.64 | +21212 | +61.1 |
| HIS SHOT LIST | 1178 | 1124 | 332 | 9.22 | +4767 | +14.4 |
| ONE TARGET A SHOOTER | 900 | 859 | 224 | 6.22 | +1947 | +8.7 |
| LEGAL CHARGES ONLY | 189 | 189 | 189 | 5.25 | +0 | +0.0 |
| TIME ON OUR SIDE | 1059 | 961 | 160 | 4.44 | +827 | +5.2 |
| FIVE ACTION | 3003 | 2908 | 140 | 3.89 | +5857 | +41.8 |
| HIS ONE MOVE | 609 | 595 | 132 | 3.67 | +0 | +0.0 |
| PROMISE BY ITS OWN SUM | 325 | 325 | 132 | 3.67 | -8652 | -65.5 |
| PATHS CROSS | 127 | 127 | 127 | 3.53 | +7523 | +59.2 |
| THE TABLE AGAIN | 215 | 215 | 123 | 3.42 | +0 | +0.0 |
| MOVE TO CHARGE | 221 | 221 | 122 | 3.39 | +4956 | +40.6 |
| MOVE TO CHARGE COMPUTED | 256 | 227 | 119 | 3.31 | +5749 | +48.3 |
| SHOTS IN THE MOVE | 994 | 806 | 101 | 2.81 | +2805 | +27.8 |
| SEARCH SPOT | 97 | 97 | 88 | 2.44 | +2909 | +33.1 |
| KILLS COUNT NEXT TURN | 258 | 258 | 74 | 2.06 | +2555 | +34.5 |
| FOLLOW UP WEIGHED | 71 | 71 | 71 | 1.97 | +9884 | +139.2 |
| HARD STAY DROPPED | 70 | 70 | 70 | 1.94 | +0 | +0.0 |
| ADVANCE LANE KEPT | 68 | 68 | 68 | 1.89 | +0 | +0.0 |
| MOVE ORDER | 68 | 68 | 68 | 1.89 | +0 | +0.0 |
| SHOT RISK POINTS | 531 | 511 | 68 | 1.89 | +1029 | +15.1 |
| WAIT AFTER COSTS | 335 | 335 | 66 | 1.83 | +1326 | +20.1 |
| BEST FIRST | 62 | 62 | 62 | 1.72 | +3738 | +60.3 |
| FOUR ROUNDS | 124 | 113 | 62 | 1.72 | +2645 | +42.7 |
| SHOOTS FROM THE BEST SPOT | 122 | 122 | 62 | 1.72 | +710 | +11.5 |
| SUPPORTS | 161 | 161 | 62 | 1.72 | +582 | +9.4 |
| COVER ONCE | 420 | 284 | 59 | 1.64 | +1505 | +25.5 |
| CHAFF IN THE MOVE | 83 | 80 | 57 | 1.58 | +666 | +11.7 |
| LANE BY FIGURES | 57 | 57 | 57 | 1.58 | +2647 | +46.4 |
| ARTILLERY RE-ROLL WEIGHED | 55 | 55 | 55 | 1.53 | +0 | +0.0 |
| STAY WORTH | 1381 | 1240 | 55 | 1.53 | +695 | +12.6 |
| QUARTER ODDS | 298 | 286 | 54 | 1.50 | +7382 | +136.7 |
| RESERVE FALL BACK | 53 | 53 | 53 | 1.47 | +3192 | +60.2 |
| IDLE COST | 846 | 526 | 50 | 1.39 | +351 | +7.0 |
| RISK BY ARC | 197 | 186 | 46 | 1.28 | +1503 | +32.7 |
| CANNON SIGHT KEPT | 45 | 45 | 45 | 1.25 | +0 | +0.0 |
| REDIRECT COUNTER | 217 | 126 | 45 | 1.25 | +2461 | +54.7 |
| CANNON PLANNED TARGET | 274 | 274 | 41 | 1.14 | -28 | -0.7 |
| CHARGE NOW FIRST | 188 | 188 | 41 | 1.14 | -2192 | -53.5 |
| HOLDS AMBUSHERS | 40 | 40 | 40 | 1.11 | +0 | +0.0 |
| MAX FOR POSITIONING | 348 | 228 | 38 | 1.06 | +187 | +4.9 |
| SET UP TOGETHER | 90 | 78 | 37 | 1.03 | +2052 | +55.5 |
| RANDOM MOVE BY FIGURES | 72 | 72 | 36 | 1.00 | +1288 | +35.8 |
| FACES THE THREAT | 35 | 35 | 35 | 0.97 | +2068 | +59.1 |
| ADVANCE WORTH | 159 | 159 | 33 | 0.92 | +470 | +14.2 |
| COMBAT PIVOT | 33 | 33 | 33 | 0.92 | +0 | +0.0 |
| LONE WIZARD KEPT IN | 33 | 33 | 33 | 0.92 | +2288 | +69.3 |
| MISSILES IN THE MOVE | 254 | 176 | 33 | 0.92 | +531 | +16.1 |
| SCOUT WAITS | 32 | 32 | 32 | 0.89 | +0 | +0.0 |
| CHARGE NOT DECLARED | 30 | 30 | 30 | 0.83 | -1320 | -44.0 |
| RISK BY HIS FIGURE | 783 | 747 | 30 | 0.83 | +2324 | +77.5 |
| WALKS TO THE FIGHT | 62 | 62 | 30 | 0.83 | +149 | +5.0 |
| FALLBACK BY WORTH | 193 | 193 | 29 | 0.81 | +1280 | +44.1 |
| JOINT CHARGE NOW | 26 | 26 | 26 | 0.72 | +612 | +23.6 |
| ONE FIGHT FORMULA | 513 | 307 | 26 | 0.72 | +102 | +3.9 |
| SHOOTERS IN TWO RANKS | 26 | 26 | 26 | 0.72 | +53 | +2.0 |
| CHAFF PASSED | 25 | 25 | 25 | 0.69 | -31 | -1.3 |
| HONEST WORTH | 522 | 508 | 24 | 0.67 | +251 | +10.5 |
| SUPPORT WORKED OUT | 95 | 89 | 24 | 0.67 | +1350 | +56.3 |
| WOUNDS ON THE RANKS | 98 | 95 | 24 | 0.67 | +952 | +39.6 |
| KILLS COUNT | 78 | 76 | 23 | 0.64 | +1386 | +60.3 |
| SET UP BY THE SET | 54 | 53 | 22 | 0.61 | +1869 | +84.9 |
| WHO HITS BACK | 22 | 22 | 22 | 0.61 | +1460 | +66.4 |
| MARCH CHECK | 34 | 32 | 21 | 0.58 | +698 | +33.2 |
| BEST MOVE FOR SHOOTERS | 20 | 20 | 20 | 0.56 | +845 | +42.2 |
| CAST JOB | 50 | 50 | 20 | 0.56 | +229 | +11.4 |
| TIED UP BY THE SUM | 28 | 25 | 20 | 0.56 | +624 | +31.2 |
| BLOCKED WHEEL | 19 | 19 | 19 | 0.53 | +311 | +16.4 |
| RISK ONCE | 107 | 82 | 19 | 0.53 | +982 | +51.7 |
| CHARGE LOSSES | 337 | 323 | 18 | 0.50 | +1664 | +92.5 |
| HOLDER AT DEPLOYMENT | 35 | 35 | 18 | 0.50 | +958 | +53.2 |
| MARCH BY THE SUM | 18 | 18 | 18 | 0.50 | +1447 | +80.4 |
| MODEL FACING | 18 | 18 | 18 | 0.50 | +6115 | +339.7 |
| CASTING BLOCK | 23 | 23 | 17 | 0.47 | +609 | +35.8 |
| KEEPS ITS TARGET | 109 | 107 | 17 | 0.47 | +353 | +20.7 |
| SAFER THAN THE JOB | 17 | 17 | 17 | 0.47 | +1260 | +74.1 |
| SHOTS AFTER THE MOVES | 111 | 111 | 17 | 0.47 | +0 | +0.0 |
| CASTER AWAY FROM SCREEN | 15 | 15 | 15 | 0.42 | +0 | +0.0 |
| CASTS FROM BEHIND | 15 | 15 | 15 | 0.42 | +0 | +0.0 |
| INVITES THE FIGHT | 26 | 26 | 14 | 0.39 | +79 | +5.6 |
| MISSILES NEXT TURN | 321 | 216 | 14 | 0.39 | +193 | +13.8 |
| NEXT CHARGE BY LIST | 232 | 217 | 14 | 0.39 | +624 | +44.5 |
| SHORT GUN FORWARD | 14 | 14 | 14 | 0.39 | +0 | +0.0 |
| BEST FACING | 13 | 13 | 13 | 0.36 | +606 | +46.6 |
| FIRE IN ORDER | 13 | 13 | 13 | 0.36 | +0 | +0.0 |
| MAKE SURE TOGETHER | 54 | 31 | 13 | 0.36 | +340 | +26.2 |
| WHOLE FIGHT GAIN | 28 | 27 | 13 | 0.36 | +703 | +54.1 |
| CHARGE NOW WEIGHED | 12 | 12 | 12 | 0.33 | +2092 | +174.4 |
| MOVE AND CAST | 12 | 12 | 12 | 0.33 | +610 | +50.8 |
| REFUSING RETIRES | 32 | 32 | 12 | 0.33 | +1 | +0.1 |
| AFTERMATH IN POINTS | 11 | 11 | 11 | 0.31 | +1332 | +121.0 |
| BEST PREY | 33 | 33 | 11 | 0.31 | +222 | +20.2 |
| HIS TURN DENIED | 47 | 43 | 11 | 0.31 | +242 | +22.0 |
| REDIRECT WEIGHED | 11 | 11 | 11 | 0.31 | +1084 | +98.5 |
| SECOND LOOK | 11 | 11 | 11 | 0.31 | +377 | +34.3 |
| MANOEUVRE | 32 | 32 | 10 | 0.28 | +460 | +46.0 |
| FRIENDS SHOTS CHECKED | 9 | 9 | 9 | 0.25 | +440 | +48.9 |
| NEARER NOT NEEDED | 205 | 199 | 9 | 0.25 | +301 | +33.5 |
| STUCK PIVOT | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| SURE REACH TOGETHER | 42 | 35 | 9 | 0.25 | +37 | +4.1 |
| THROUGH LINE OF FIRE | 9 | 9 | 9 | 0.25 | +212 | +23.6 |
| BEST OVERALL | 8 | 8 | 8 | 0.22 | +375 | +46.9 |
| HIS CHARGE DENIED | 19 | 18 | 8 | 0.22 | +236 | +29.5 |
| ONE OBJECTIVE FORMULA | 223 | 149 | 8 | 0.22 | +344 | +43.0 |
| OPENS UP | 16 | 15 | 8 | 0.22 | +265 | +33.1 |
| OVERRUNS AWAY | 48 | 46 | 8 | 0.22 | +269 | +33.6 |
| STOPS SHORT OF THE FLANK | 8 | 8 | 8 | 0.22 | +326 | +40.8 |
| WEARS DOWN | 59 | 56 | 8 | 0.22 | +123 | +15.4 |
| WIDER SPREAD | 218 | 208 | 8 | 0.22 | +65 | +8.1 |
| MARCH ODDS | 7 | 7 | 7 | 0.19 | +59 | +8.4 |
| HIS MOVE AND SHOT | 93 | 92 | 6 | 0.17 | +182 | +30.3 |
| MARCH OF THE TABLE | 6 | 6 | 6 | 0.17 | -118 | -19.7 |
| RESTRAINS TO SHOOT | 6 | 6 | 6 | 0.17 | +160 | +26.6 |
| AFTERMATH WITH FRIENDS | 5 | 5 | 5 | 0.14 | +414 | +82.9 |
| BIG CHARACTER SAFETY | 5 | 5 | 5 | 0.14 | -15 | -3.0 |
| FALLS SHORT | 182 | 164 | 5 | 0.14 | +95 | +18.9 |
| HUNT IN PAIRS | 22 | 11 | 5 | 0.14 | +127 | +25.4 |
| PROMISE KNOWS THE FIGHT | 31 | 23 | 5 | 0.14 | -47 | -9.3 |
| SPELLS IN THE FIGHT | 53 | 49 | 5 | 0.14 | +58 | +11.6 |
| FIGHT TO THE END | 34 | 30 | 4 | 0.11 | +53 | +13.2 |
| FOCUS FIRE | 4 | 4 | 4 | 0.11 | +113 | +28.2 |
| JOINT CHARGE PLAN | 13 | 13 | 4 | 0.11 | +177 | +44.2 |
| KEEPS SCOUTS OR AMBUSH | 4 | 4 | 4 | 0.11 | +0 | +0.0 |
| LONG SHOT | 20 | 20 | 4 | 0.11 | +72 | +18.1 |
| MOVES UNITS SPELL | 4 | 4 | 4 | 0.11 | +122 | +30.4 |
| PIVOT GUARDS FLANK | 4 | 4 | 4 | 0.11 | -57 | -14.2 |
| SUPPORT NARROWED | 267 | 267 | 4 | 0.11 | -35 | -8.8 |
| SURE CHARGE BEATS ADVANCE | 4 | 4 | 4 | 0.11 | -79 | -19.8 |
| BOUND ASSAILMENT | 3 | 3 | 3 | 0.08 | +0 | +0.1 |
| CONTINUE AHEAD WEIGHED | 3 | 3 | 3 | 0.08 | +0 | +0.0 |
| EDGE GIVE GROUND | 22 | 21 | 3 | 0.08 | +75 | +24.9 |
| FIRE AND FLEE | 3 | 3 | 3 | 0.08 | +19 | +6.2 |
| GUN MASK | 34 | 32 | 3 | 0.08 | +10 | +3.4 |
| KEEP FALLS | 3 | 3 | 3 | 0.08 | +35 | +11.6 |
| ONE PROMISE A TARGET | 3 | 3 | 3 | 0.08 | -43 | -14.4 |
| OWN CAST FIRST | 3 | 3 | 3 | 0.08 | -23 | -7.8 |
| PERIAPT WORTH | 3 | 3 | 3 | 0.08 | +237 | +79.0 |
| PROMISE READS THE TABLE | 10 | 10 | 3 | 0.08 | -20 | -6.5 |
| WAR ENGINE JOBS | 24 | 24 | 3 | 0.08 | -211 | -70.3 |
| WHO GETS IN | 3 | 3 | 3 | 0.08 | -396 | -132.1 |
| WHOLE FIGHT | 21 | 20 | 3 | 0.08 | +81 | +27.1 |
| BEST PRIZE | 2 | 2 | 2 | 0.06 | -133 | -66.3 |
| BOMBING RUN | 2 | 2 | 2 | 0.06 | +59 | +29.7 |
| CARRIES OUT SET-UP | 11 | 11 | 2 | 0.06 | -27 | -13.6 |
| FEATURE BUFFS | 55 | 55 | 2 | 0.06 | +21 | +10.6 |
| HIS FIGHT TOGETHER | 79 | 76 | 2 | 0.06 | +29 | +14.6 |
| NO DOUBLE ROUNDS | 108 | 99 | 2 | 0.06 | +49 | +24.3 |
| OPENS A LANE | 4 | 4 | 2 | 0.06 | +14 | +7.1 |
| PROMISE SHOT AWAY | 2 | 2 | 2 | 0.06 | -15 | -7.3 |
| PURSUES BIG PREY | 2 | 2 | 2 | 0.06 | -156 | -78.0 |
| REFORMS TO MEET IT | 50 | 45 | 2 | 0.06 | +22 | +10.8 |
| SCREEN BY WHAT IT SAVES | 41 | 41 | 2 | 0.06 | +124 | +62.0 |
| WHAT THE JOINER ADDS | 10 | 8 | 2 | 0.06 | +49 | +24.5 |
| BACKUP TARGETS | 23 | 15 | 1 | 0.03 | +1 | +0.8 |
| BLOCKED CHARGE SKIPPED | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| BLOWS WHERE AIMED | 16 | 14 | 1 | 0.03 | +4 | +4.1 |
| CHARGE LIST READ AGAIN | 1 | 1 | 1 | 0.03 | +169 | +169.0 |
| DEFENSIVE ARMY | 5 | 5 | 1 | 0.03 | -90 | -90.2 |
| FALL BACK GOOD ORDER | 91 | 81 | 1 | 0.03 | +3 | +3.2 |
| HORN WORTH | 1 | 1 | 1 | 0.03 | +6 | +5.8 |
| JOINT ON THE TABLE | 1 | 1 | 1 | 0.03 | +18 | +18.1 |
| LOST AFTER ESCAPE | 77 | 69 | 1 | 0.03 | +3 | +3.0 |
| LOST CHARGE | 63 | 62 | 1 | 0.03 | +22 | +21.6 |
| NEXT OBJECTIVE NEARER | 4 | 4 | 1 | 0.03 | +8 | +7.5 |
| NO RALLY LEFT | 1 | 1 | 1 | 0.03 | +5 | +4.9 |
| PROMISE HOLDS THE SPOT | 1 | 1 | 1 | 0.03 | +10 | +10.4 |
| STAY WEIGHED | 1 | 1 | 1 | 0.03 | +7 | +7.2 |
| STOPS | 11 | 10 | 1 | 0.03 | +12 | +12.1 |
| WAR ENGINE CHARGES | 3 | 3 | 1 | 0.03 | +24 | +24.5 |
| ALREADY CARRIED | 2 | not checked | - | - | - | - |
| ARRIVAL HUNT | 3 | 3 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 27 | 27 | 0 | 0.00 | - | - |
| CARRIES OUT COUNTER | 1 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 37 | trace | - | - | - | - |
| CHAMPION KNOWS CHALLENGE | 10 | 9 | 0 | 0.00 | - | - |
| CHARACTER GUNS | 55 | 50 | 0 | 0.00 | - | - |
| CHARGER SLAIN LOST | 31 | 30 | 0 | 0.00 | - | - |
| CHEAP HELPER | 8 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 45 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 25 | 20 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT LIFT | 2 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 344 | not checked | - | - | - | - |
| FRIEND SHOOTS FIRST | 21 | 19 | 0 | 0.00 | - | - |
| GATEWAY ESCAPE | 1 | not checked | - | - | - | - |
| GIVES UP | 19 | 17 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 1 | 1 | 0 | 0.00 | - | - |
| GUN FIGURES | 60 | not checked | - | - | - | - |
| HE SHOOTS OR CHARGES | 116 | 113 | 0 | 0.00 | - | - |
| HELPER ALREADY ASKED | 3 | not checked | - | - | - | - |
| HELPER UNSEEN | 5 | 5 | 0 | 0.00 | - | - |
| HILL BY ITS CHANCE | 28 | 28 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 161 | 152 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 169 | 153 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 60 | 60 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 177 | 167 | 0 | 0.00 | - | - |
| HOLD ODDS | 354 | 353 | 0 | 0.00 | - | - |
| HUNT ADVANCE | 3 | 3 | 0 | 0.00 | - | - |
| HUNT DROPPED | 4 | trace | - | - | - | - |
| HUNT KEPT | 3 | trace | - | - | - | - |
| HUNT RESULT | 10 | trace | - | - | - | - |
| HUNT THE GUNS | 11 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 6 | 4 | 0 | 0.00 | - | - |
| KEEPS ITS PREY | 1 | 1 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 17 | not checked | - | - | - | - |
| LONE WIZARD HOLDS BACK | 5 | 5 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 5 | 5 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 8 | trace | - | - | - | - |
| MARCH OVER CASTS | 47 | 47 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 8 | 8 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 5 | 3 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 25 | trace | - | - | - | - |
| MOVE SPELL SPOT | 10 | not checked | - | - | - | - |
| NOT NEEDED | 23 | 23 | 0 | 0.00 | - | - |
| NOT TURNED | 222 | 222 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 42 | not checked | - | - | - | - |
| ONE CHARGE A CHARGER | 160 | 157 | 0 | 0.00 | - | - |
| PLAN RESULT | 2913 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 8 | 8 | 0 | 0.00 | - | - |
| PROMISE IN STEPS | 6 | 6 | 0 | 0.00 | - | - |
| RANDOM MOVER NO PROMISE | 3 | 3 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 53 | 53 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 22 | 21 | 0 | 0.00 | - | - |
| RUN DOWN | 81 | 73 | 0 | 0.00 | - | - |
| SCOUT SPOT | 28 | 28 | 0 | 0.00 | - | - |
| SECOND HUNTER | 1 | 1 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 11 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 8 | not checked | - | - | - | - |
| SET-UP MISSED | 6 | trace | - | - | - | - |
| SHOOTER COUNTED ONCE | 5 | 5 | 0 | 0.00 | - | - |
| SHOT OR CHARGE | 18 | 18 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 11 | not checked | - | - | - | - |
| SPELL WORTH | 100 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 252 | 240 | 0 | 0.00 | - | - |
| STABLE ROLE | 403 | 402 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 24 | 23 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 16 | 16 | 0 | 0.00 | - | - |
| STANDS STILL | 1358 | 1329 | 0 | 0.00 | - | - |
| STUPIDITY NEXT TURN | 16 | 14 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 43 | not checked | - | - | - | - |
| THE PROMISE ADDS | 3 | 2 | 0 | 0.00 | - | - |
| THE TABLE BINDS | 1001 | not checked | - | - | - | - |
| TURN WORTH | 12 | 12 | 0 | 0.00 | - | - |
| TWO OR MORE ARRIVE | 21 | 17 | 0 | 0.00 | - | - |
| WAITS AGAIN | 74 | 67 | 0 | 0.00 | - | - |
| WOUNDED STAYS OUT | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: hmw-mine-c1e47a9-p2

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 2.39 | 15.92 | 47.3 |
| PROMISE BY ITS OWN SUM | rule | 3.67 | - | 65.5 |
| ARMY TABLE | rule | 1.14 | - | 50.9 |
| CHARGE NOW FIRST | rule | 0.47 | 0.64 | 54.8 |
| HOLDER ASSIGNMENT | rule | 0.92 | - | 15.9 |
| FALLBACK | gate | 0.03 | 0.78 | 27.0 |
| CHARGE NOT DECLARED | rule | 0.03 | 0.69 | 56.2 |
| NO REASON | gate | 0.44 | - | 31.7 |
| TURN GATE | gate | 0.03 | 0.39 | 42.0 |
| CANNON PLANNED TARGET | rule | 0.25 | 0.11 | 7.4 |
| CHAFF PASSED | rule | 0.08 | 0.19 | 3.1 |
| JOINT CHARGE NOW | rule | 0.28 | - | 81.3 |
| LONE CHARACTER SAFE SPOT | gate | 0.03 | 0.17 | 19.9 |
| PATHS CROSS | rule | 0.08 | 0.08 | 12.0 |
| FIGHT ORDER BAND | gate | 0.06 | 0.08 | 1.6 |
| MARCH OF THE TABLE | rule | 0.11 | - | 29.6 |
| PIVOT GUARDS FLANK | rule | 0.03 | 0.08 | 14.2 |
| SUPPORT NARROWED | rule | 0.06 | 0.06 | 8.8 |
| SUPPORT REQUEST | gate | - | 0.11 | 80.5 |
| SURE CHARGE BEATS ADVANCE | rule | - | 0.11 | 19.8 |
| AFTERMATH BAND | gate | 0.03 | 0.06 | 2.5 |
| OWN CAST FIRST | rule | 0.08 | - | 7.8 |
| PROMISE KNOWS THE FIGHT | rule | 0.08 | - | 15.3 |
| PROMISE READS THE TABLE | rule | 0.08 | - | 6.5 |
| WAR ENGINE JOBS | rule | - | 0.08 | 70.3 |
| AFTERMATH NEEDS NEXT CHARGE | gate | - | 0.06 | 27.6 |
| BEST PRIZE | rule | - | 0.06 | 66.3 |
| BIG CHARACTER SAFETY | rule | - | 0.06 | 9.8 |
| CARRIES OUT SET-UP | rule | - | 0.06 | 13.6 |
| ONE PROMISE A TARGET | rule | 0.06 | - | 25.1 |
| PROMISE SHOT AWAY | rule | 0.06 | - | 7.3 |
| PURSUES BIG PREY | rule | 0.03 | 0.03 | 78.0 |
| REDIRECT WEIGHED | rule | - | 0.06 | 25.3 |
| STOPS SHORT OF THE FLANK | rule | - | 0.06 | 9.8 |
| WHO GETS IN | rule | 0.06 | - | 200.3 |
| BLOCKED WHEEL | rule | - | 0.03 | 8.0 |
| DEFENSIVE ARMY | rule | - | 0.03 | 90.2 |
| DEPLOY BY FIGURES | rule | 0.03 | - | 9.9 |
| MARCH ODDS | rule | - | 0.03 | 1.8 |
| REFUSING RETIRES | rule | 0.03 | - | 0.6 |

### Plans: hmw-mine-c1e47a9-p2

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 2.9 | 65% | 404 | 293 | 73% |
| Mine | join | 0.6 | 96% | 23 | 0 | 0% |
| Mine | move | 26.7 | 94% | 1304 | 0 | 0% |
| Mine | shoot | 8.8 | 64% | 431 | 971 | 225% |
| Mine | support | 0.5 | 79% | 1 | 0 | 0% |
| Opponent | advance | 11.2 | 15% | 179 | 281 | 157% |
| Opponent | charge | 4.7 | 56% | 402 | 371 | 92% |
| Opponent | close in | 7.1 | 28% | 487 | 171 | 35% |
| Opponent | hold | 5.5 | 39% | 418 | 0 | 0% |
| Opponent | join | 1.1 | 98% | 52 | 0 | 0% |
| Opponent | shoot | 5.6 | 59% | 195 | 297 | 152% |
| Opponent | support | 5.9 | 89% | 45 | 0 | 0% |

### Packages: hunt the guns, hmw-mine-c1e47a9-p2

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.0 | 1 | 0 | 100% | 100% | 0% | 2.0 | 136 | 133 | 100% | 27 |
| Opponent | 0.3 | 10 | 1 | 44% | 44% | 0% | 2.2 | 398 | 130 | 33% | 80 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.2 | 1 | 0 | 100% | 100% | 0% | 2.0 | 136 | 133 | 100% | 0 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 145 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 17 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 96 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 98 |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 90 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Ogre Kingdoms | 1.5 | 6 | 0 | 50% | 50% | 0% | 2.3 | 482 | 153 | 33% | 92 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 70 |
| Tomb Kings of Khemri | 0.6 | 3 | 1 | 0% | 0% | 0% | - | 201 | 0 | 0% | 14 |
| Vampire Counts | 0.1 | 1 | 0 | 100% | 100% | 0% | 2.0 | 290 | 249 | 100% | 0 |
| Warriors of Chaos | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 119 |
| Wood Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |

### Battle groups: hmw-mine-c1e47a9-p2

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 1.9 | 32% | 86% | 0% | - | 18% | 0% | 14% | 68% | 0% |
| Opponent | REDIRECT COUNTER | 4.1 | 18% | 81% | 15% | 0% | 9% | 0% | 18% | 68% | 5% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: hmw-mine-c1e47a9-p2

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 5 | 0 (5) | 0 | 0 | 52 | 40% | 4.0 | - | 0 (4) | - | - | 0 (4) |
| Mine | Chaff | 35 | 60 (35) | 12 | 48 | 63 | 40% | 3.0 | 83 (14) | 43 (12) | 43 (9) | 71 (23) | 40 (12) |
| Mine | Character | 124 | 51 (124) | 51 | 0 | 33 | 17% | 2.5 | 66 (32) | 44 (49) | 53 (23) | 51 (53) | 56 (51) |
| Mine | Clean-up | 19 | 90 (19) | 52 | 38 | 44 | 26% | 2.1 | 198 (3) | 34 (12) | 169 (4) | 119 (14) | 27 (5) |
| Mine | Fast | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | 0 (1) | - | - | 0 (1) | - |
| Mine | Fast Hammer | 47 | 38 (47) | 25 | 14 | 37 | 21% | 2.9 | 36 (18) | 41 (22) | 37 (7) | 46 (29) | 27 (18) |
| Mine | Hammer | 59 | 28 (59) | 15 | 12 | 40 | 20% | 2.6 | 19 (17) | 21 (30) | 56 (12) | 33 (35) | 21 (24) |
| Mine | Holder | 29 | 56 (29) | 15 | 41 | 21 | 59% | 2.9 | 54 (13) | 98 (9) | 7 (7) | 61 (22) | 29 (7) |
| Mine | Shooter | 45 | 97 (45) | 34 | 63 | 40 | 2% | 1.7 | 66 (11) | 120 (23) | 84 (11) | 110 (33) | 64 (12) |
| Mine | Support | 2 | 0 (2) | 0 | 0 | 66 | 0% | 4.0 | - | 0 (2) | - | - | 0 (2) |
| Mine | War machine | 59 | 40 (59) | 40 | 0 | 51 | 5% | 1.3 | 37 (21) | 42 (20) | 41 (18) | 5 (11) | 48 (48) |
| Mine | Wizard | 21 | 28 (21) | 28 | 0 | 43 | 10% | 2.7 | 51 (9) | 0 (4) | 30 (5) | 17 (8) | 50 (10) |
| Opponent | Blocker | 2 | 53 (2) | 53 | 0 | 38 | 0% | 4.0 | - | 53 (2) | - | 84 (1) | 0 (1) |
| Opponent | Chaff | 76 | 72 (76) | 27 | 45 | 49 | 37% | 2.5 | 60 (29) | 77 (29) | 80 (18) | 87 (59) | 28 (17) |
| Opponent | Character | 96 | 50 (96) | 50 | 0 | 35 | 18% | 2.7 | 51 (35) | 53 (42) | 58 (10) | 53 (62) | 51 (25) |
| Opponent | Clean-up | 18 | 38 (18) | 19 | 19 | 39 | 39% | 3.1 | 18 (6) | 60 (10) | 0 (2) | 41 (14) | 26 (4) |
| Opponent | Early | 2 | 0 (2) | 0 | 0 | 50 | 0% | 5.5 | - | 0 (2) | - | - | 0 (2) |
| Opponent | Fast Hammer | 49 | 53 (49) | 47 | 7 | 39 | 16% | 2.7 | 41 (21) | 68 (20) | 43 (8) | 55 (29) | 51 (20) |
| Opponent | Fragile | 3 | 0 (3) | 0 | 0 | 0 | 67% | 1.0 | - | 0 (1) | 0 (2) | 0 (2) | 0 (1) |
| Opponent | Hammer | 70 | 32 (70) | 26 | 7 | 50 | 26% | 2.7 | 34 (19) | 33 (42) | 28 (9) | 44 (41) | 17 (29) |
| Opponent | Holder | 34 | 72 (34) | 0 | 72 | 21 | 56% | 2.6 | 83 (11) | 77 (17) | 62 (5) | 90 (24) | 12 (9) |
| Opponent | Shooter | 36 | 67 (36) | 11 | 56 | 17 | 3% | 1.8 | 51 (11) | 90 (18) | 34 (7) | 87 (22) | 42 (14) |
| Opponent | Support | 3 | 0 (3) | 0 | 0 | 50 | 67% | 3.0 | 0 (1) | 0 (2) | - | - | 0 (3) |
| Opponent | War machine | 24 | 34 (24) | 34 | 0 | 35 | 4% | 1.6 | 65 (11) | 0 (2) | 8 (11) | 0 (3) | 39 (21) |
| Opponent | Wizard | 27 | 11 (27) | 11 | 0 | 34 | 0% | 2.0 | 17 (13) | 11 (10) | 11 (1) | 21 (10) | 6 (14) |

### Charged fights: hmw-mine-c1e47a9-p2

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 107 | 156 | 2.2 | 1.0 | 69 | 6 | +63 | 2 of 9 | 7 of 9 | - | +63 |
| Mine | Chaos Dwarfs | 4 | 244 | 261 | 2.5 | 1.0 | 104 | 31 | +73 | 7 of 10 | 8 of 10 | - | +73 |
| Mine | Dwarfen Mountain Holds | 4 | 690 | 61 | 2.8 | 1.1 | 22 | 52 | -30 | 2 of 11 | 7 of 11 | -60 | -27 |
| Mine | Empire of Man | 5 | 316 | 44 | 1.0 | 1.0 | 44 | 0 | +44 | 2 of 5 | 5 of 5 | - | +44 |
| Mine | Grand Cathay | 4 | 209 | 555 | 3.0 | 1.3 | 185 | 51 | +134 | 3 of 12 | 11 of 12 | +422 | +38 |
| Mine | High Elf Realms | 4 | 159 | 637 | 5.5 | 1.0 | 116 | 12 | +104 | 6 of 22 | 18 of 22 | +195 | +99 |
| Mine | Kingdom of Bretonnia | 1 | 0 | 292 | 4.0 | 1.0 | 73 | 0 | +73 | 1 of 4 | 4 of 4 | - | +73 |
| Mine | Lizardmen | 1 | 45 | 372 | 2.0 | 1.5 | 186 | 0 | +186 | 0 of 2 | 2 of 2 | +186 | +186 |
| Mine | Ogre Kingdoms | 1 | 0 | 0 | 1.0 | 2.0 | 0 | 0 | +0 | 0 of 1 | 1 of 1 | +0 | - |
| Mine | Orc & Goblin Tribes | 1 | 0 | 413 | 6.0 | 1.0 | 69 | 100 | -31 | 1 of 6 | 4 of 6 | - | -31 |
| Mine | Skaven | 2 | 42 | 186 | 0.5 | 1.0 | 373 | 210 | +163 | 1 of 1 | 1 of 1 | - | +163 |
| Mine | Tomb Kings of Khemri | 1 | 644 | 251 | 4.0 | 1.2 | 63 | 0 | +63 | 0 of 4 | 4 of 4 | +0 | +84 |
| Mine | Vampire Counts | 3 | 0 | 243 | 2.7 | 1.0 | 91 | 0 | +91 | 2 of 8 | 5 of 8 | - | +91 |
| Mine | Warriors of Chaos | 1 | 19 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 0 of 1 | 0 of 1 | - | +0 |
| **Mine** | all armies | 36 | 223 | 259 | 2.7 | 1.1 | 97 | 27 | +70 | 27 of 96 | 77 of 96 | +198 | +58 |
| Opponent | Dwarfen Mountain Holds | 2 | 58 | 111 | 2.5 | 1.4 | 44 | 33 | +11 | 2 of 5 | 2 of 5 | +32 | -3 |
| Opponent | Empire of Man | 2 | 290 | 170 | 1.5 | 1.0 | 113 | 0 | +113 | 0 of 3 | 3 of 3 | - | +113 |
| Opponent | Grand Cathay | 2 | 704 | 648 | 4.5 | 1.3 | 144 | 48 | +96 | 9 of 9 | 5 of 9 | +282 | +3 |
| Opponent | Kingdom of Bretonnia | 1 | 100 | 0 | 1.0 | 1.0 | 0 | 471 | -471 | 1 of 1 | 1 of 1 | - | -471 |
| Opponent | Ogre Kingdoms | 3 | 0 | 302 | 4.3 | 1.3 | 70 | 57 | +13 | 5 of 13 | 9 of 13 | +109 | -16 |
| Opponent | Skaven | 1 | 189 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Tomb Kings of Khemri | 4 | 34 | 1276 | 6.0 | 1.1 | 213 | 55 | +158 | 12 of 24 | 17 of 24 | +604 | +117 |
| Opponent | Vampire Counts | 6 | 0 | 686 | 5.2 | 1.1 | 133 | 54 | +79 | 20 of 31 | 21 of 31 | +216 | +59 |
| Opponent | Warriors of Chaos | 8 | 0 | 121 | 2.1 | 1.0 | 57 | 46 | +11 | 8 of 17 | 9 of 17 | - | +11 |
| Opponent | Wood Elf Realms | 7 | 98 | 544 | 3.6 | 1.1 | 152 | 35 | +118 | 6 of 25 | 22 of 25 | +31 | +125 |
| **Opponent** | all armies | 36 | 89 | 466 | 3.6 | 1.1 | 131 | 50 | +81 | 63 of 128 | 89 of 128 | +211 | +62 |

### Effective charges: hmw-mine-c1e47a9-p2

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 9 | 0 | 0 | 3 (net +65) | 2 (net +28) | 0 | 1 (net +72) | 3 | 50% (3 of 6) |
| Mine | Chaos Dwarfs | 10 | 3 (net +150) | 0 | 1 (net -310) | 1 (net +0) | 1 (net +45) | 3 (net +160) | 1 | 11% (1 of 9) |
| Mine | Dwarfen Mountain Holds | 11 | 2 (net -258) | 0 | 3 (net +81) | 1 (net +0) | 0 | 5 (net -12) | 0 | 27% (3 of 11) |
| Mine | Empire of Man | 5 | 0 | 0 | 1 (net +0) | 2 (net +110) | 0 | 0 | 2 | 33% (1 of 3) |
| Mine | Grand Cathay | 12 | 1 (net +990) | 0 | 1 (net +0) | 2 (net -34) | 3 (net +74) | 3 (net +110) | 2 | 10% (1 of 10) |
| Mine | High Elf Realms | 22 | 1 (net +185) | 1 (net +0) | 3 (net -50) | 5 (net +206) | 2 (net +0) | 6 (net +114) | 4 | 17% (3 of 18) |
| Mine | Kingdom of Bretonnia | 4 | 0 | 0 | 0 | 1 (net +0) | 0 | 2 (net +85) | 1 | 0% (0 of 3) |
| Mine | Lizardmen | 2 | 1 (net +186) | 0 | 0 | 0 | 1 (net +186) | 0 | 0 | 0% (0 of 2) |
| Mine | Orc & Goblin Tribes | 6 | 1 (net -235) | 0 | 1 (net +233) | 2 (net -160) | 0 | 0 | 2 | 25% (1 of 4) |
| Mine | Tomb Kings of Khemri | 4 | 0 | 0 | 1 (net +125) | 0 | 1 (net +0) | 1 (net +0) | 1 | 33% (1 of 3) |
| Mine | Vampire Counts | 8 | 2 (net +0) | 0 | 0 | 2 (net +102) | 1 (net +274) | 0 | 3 | 0% (0 of 5) |
| Mine | Warriors of Chaos | 1 | 0 | 0 | 1 (net +0) | 0 | 0 | 0 | 0 | 100% (1 of 1) |
| Opponent | Dwarfen Mountain Holds | 5 | 2 (net -30) | 0 | 1 (net +65) | 1 (net +0) | 0 | 1 (net +52) | 0 | 20% (1 of 5) |
| Opponent | Empire of Man | 3 | 0 | 0 | 0 | 0 | 0 | 3 (net +113) | 0 | 0% (0 of 3) |
| Opponent | Grand Cathay | 9 | 2 (net +0) | 0 | 1 (net +265) | 1 (net +102) | 0 | 4 (net +124) | 1 | 12% (1 of 8) |
| Opponent | Kingdom of Bretonnia | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net -471) | 0 | 0% (0 of 1) |
| Opponent | Ogre Kingdoms | 13 | 5 (net +13) | 0 | 1 (net +150) | 2 (net +150) | 0 | 1 (net +0) | 4 | 11% (1 of 9) |
| Opponent | Tomb Kings of Khemri | 24 | 6 (net +15) | 1 (net +310) | 3 (net +144) | 9 (net +131) | 1 (net +81) | 3 (net +536) | 1 | 13% (3 of 23) |
| Opponent | Vampire Counts | 31 | 10 (net +6) | 1 (net -415) | 6 (net +14) | 8 (net +222) | 1 (net +293) | 4 (net +8) | 1 | 20% (6 of 30) |
| Opponent | Warriors of Chaos | 17 | 2 (net -58) | 0 | 4 (net -144) | 3 (net +99) | 0 | 6 (net +96) | 2 | 27% (4 of 15) |
| Opponent | Wood Elf Realms | 25 | 4 (net +260) | 0 | 4 (net +78) | 7 (net +102) | 2 (net +0) | 7 (net +106) | 1 | 17% (4 of 24) |

### Charged fights, damage counted: hmw-mine-c1e47a9-p2

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 11 | 238 | 280 | +96 | 172 | 94 | +78 | +32.8 |
| Mine | 50-54% | 1 | 143 | 228 | +0 | 0 | 48 | -48 | -33.3 |
| Mine | Effective (55-75%) | 15 | 247 | 155 | +22 | 67 | 56 | +11 | +4.4 |
| Mine | 76-89% | 18 | 200 | 184 | +62 | 137 | 59 | +78 | +39.0 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 21 | 275 | 179 | +80 | 96 | 10 | +87 | +31.6 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 9 | 448 | 104 | +81 | 98 | 6 | +91 | +20.4 |
| Mine | No odds | 21 | 311 | 150 | +85 | 136 | 27 | +109 | +35.1 |
| Mine | All fights | 96 | 275 | 175 | +70 | 116 | 40 | +76 | +27.7 |
| Opponent | Long shot (under 50%) | 31 | 170 | 273 | +35 | 135 | 85 | +50 | +29.7 |
| Opponent | 50-54% | 2 | 333 | 326 | -52 | 233 | 286 | -52 | -15.8 |
| Opponent | Effective (55-75%) | 20 | 281 | 196 | +37 | 128 | 87 | +41 | +14.5 |
| Opponent | 76-89% | 31 | 313 | 179 | +141 | 173 | 37 | +136 | +43.6 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 30 | 265 | 202 | +113 | 162 | 38 | +124 | +46.6 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 4 | 538 | 98 | +94 | 156 | 80 | +76 | +14.1 |
| Opponent | No odds | 10 | 195 | 242 | +47 | 94 | 60 | +33 | +17.1 |
| Opponent | All fights | 128 | 260 | 214 | +81 | 148 | 64 | +85 | +32.6 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| hmw-mine-c1e47a9-p2 | move | 350 | 82 (23%) | 60 (17%) | 52 (15%) | 216 (62%) |
| hmw-mine-c1e47a9-p2 | objective | 258 | 45 (17%) | 34 (13%) | 21 (8%) | 192 (74%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0106, L0122, L2429, L2535, L2735 |
| Charmed Shield | Opponent | L0425, L0827, L0934, L1026, L1727, L1827, L1927 |
| Clockwork Compass | Mine | L1228 |
| Clockwork Compass | Opponent | L0512 |
| Elixir of Power | Mine | L1118, L1135, L1927 |
| Fistful of Laurels | Mine | L1827 |
| Fistful of Laurels | Opponent | L0918, L1118, L1418 |
| Horn of the Wild Hunt | Opponent | L3033 |
| Invocation of Nehek | Mine | L2429, L2535, L2735 |
| Invocation of Nehek | Opponent | L0425, L0827, L1727, L1827, L1927 |
| Opal Amulet | Mine | L1418, L1435 |
| Periapt of Soul Exchange | Mine | L2029, L2131 |
| Periapt of Soul Exchange | Opponent | L0721 |
| Ring of Doom | Mine | L0206, L0222, L1118, L1135, L1228, L1531 |
| Ring of Doom | Opponent | L0512, L1531, L2131, L3033 |
| Ring of Jet | Mine | L1026, L1118, L1135, L1228 |
| Ring of Jet | Opponent | L0512, L0810 |
| Standard of the Fell Warrior | Mine | L1323 |
| Storm Daemon (Renegade 2.0) | Mine | L2131 |
| Storm Daemon (Renegade 2.0) | Opponent | L0721 |
| Twice-Blessed Armour | Mine | L0721, L1026 |
| Twice-Blessed Armour | Opponent | L0307, L0810 |
| Witch Hunter's Ward | Mine | L0721, L0810, L0827 |
| Witch Hunter's Ward | Opponent | L0307 |

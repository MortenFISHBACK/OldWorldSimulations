import json,collections,re,os
d=json.load(open(os.path.expanduser('~/ana/hmw.json'))); R=d['rows']
def job(s):
    if not s: return '(none)'
    s=re.sub(r'#\d+.*','',s); s=re.sub(r'\(.*','',s); return s.strip(' ,;:') or '(none)'
def akind(a):
    k=a.split(' ')[0]; return {'stand':'stand','march':'march','move':'move','charge':'charge'}.get(k,k)
print('--- by assumed action kind')
t=collections.defaultdict(collections.Counter)
for r in R: t[akind(r['assumed'])][r['cat']]+=1
for k,c in t.items(): n=sum(c.values()); print(k,n, {x:f"{100*v/n:.0f}%" for x,v in c.most_common()})
print('--- other job: assumed job -> his row job')
c=collections.Counter((job(r['by']),job(r['real'])) for r in R if r['cat']=='other job')
for k,v in c.most_common(15): print(v,k)
print('--- assumed job overall miss')
c=collections.Counter(job(r['by']) for r in R); m=collections.Counter(job(r['by']) for r in R if r['cat']!='as assumed')
for k,v in c.most_common(12): print(k,v,m[k],f"{100*m[k]/v:.0f}%")
print('--- same job other spot inches')
b=collections.Counter()
for r in R:
  if r['cat']=='same job, other spot' and r['inch'] is not None:
    x=r['inch']; b['1-3' if x<3 else '3-6' if x<6 else '6-12' if x<12 else '12+']+=1
print(b)
print('--- charged not assumed: assumed was')
print(collections.Counter(('assumed charge (other target)' if akind(r['assumed'])=='charge' else 'assumed '+akind(r['assumed'])) for r in R if r['cat']=='charged (not as assumed)'))
# board changed by turn
turns=collections.defaultdict(list)
for r in R: turns[(r['part'],r['game'],r['turn'])].append(r)
fl=collections.Counter(); 
for k,rs in turns.items():
    flag=any(r['board'] for r in rs); miss=any(r['cat']!='as assumed' for r in rs)
    key='changed' if flag else ('not changed' if miss else 'unknown (all as assumed)')
    fl[(key,'rows')]+=len(rs); fl[(key,'miss')]+=sum(r['cat']!='as assumed' for r in rs); fl[(key,'turns')]+=1
print(fl)
print('--- per turn number miss')
c=collections.Counter(r['turn'] for r in R); m=collections.Counter(r['turn'] for r in R if r['cat']!='as assumed')
for k in sorted(c): print(k,c[k],f"{100*m[k]/c[k]:.0f}%")
print('--- newside')
for s in ('Mine','Opponent'):
  rs=[r for r in R if r['newside']==s]; print(s,len(rs),f"{100*sum(r['cat']=='as assumed' for r in rs)/len(rs):.0f}%")

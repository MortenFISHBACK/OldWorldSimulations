import json,collections,re,os
d=json.load(open(os.path.expanduser('~/ana/hmw.json'))); R=d['rows']
def job(s):
    if not s: return '(none)'
    s=re.sub(r'#\d+.*','',s); s=re.sub(r'\(.*','',s); return s.strip(' ,;:') or '(none)'
def tgt(s):
    m=re.search(r'#(\d+)',s or ''); return m.group(1) if m else (re.sub(r'\(.*','',s or '').strip())
g=collections.Counter(); ex=collections.defaultdict(list)
for r in R:
    if r['cat']!='other job': continue
    a,b=job(r['by']),job(r['real'])
    if a==b and tgt(r['by'])!=tgt(r['real']): k=f'same kind ({a}), other target'
    elif a==b: k=f'same kind and target ({a}), wording differs'
    else: k=f'{a} -> {b}'
    g[k]+=1; ex[k].append(r)
for k,v in g.most_common(14): print(v,k)
k='same kind and target (advance on), wording differs'
for r in ex.get(k,[])[:3]: print(r['by'],'||',r['real'])
for r in ex['same kind (advance on), other target'][:3]: print(r['by'],'||',r['real'])

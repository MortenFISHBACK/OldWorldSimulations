"""His move why + promise below zero counts. python3 -I hmw.py <root with <arm>-N/... game-*.log.jsonl>"""
import collections, glob, json, os, re, sys
root = sys.argv[1]
HMW = re.compile(r"HIS MOVE WHY: #(\d+) (.*?): the other side assumed it would (.*?)(?: \[(.*?)\])?; (.*)$")
JOB = re.compile(r"^([a-zA-Z' -]+?)(?: #|$| \(|,)")
def job(s):
    if s is None: return "(our sum, no job)"
    m = JOB.match(s); return (m.group(1).strip() if m else s[:30])
def kind(a):
    return a.split(' ')[0]  # stand / march / move / charge
rows = []; pbz = []
games = 0
for f in sorted(glob.glob(os.path.join(root, '*', '**', 'game-*.log.jsonl'), recursive=True)):
    part = os.path.relpath(f, root).split(os.sep)[0]; g = os.path.basename(f).replace('.log.jsonl', '')
    games += 1
    newside = 'Mine' if part.startswith('mine') else 'Opponent'
    for line in open(f):
        if '"OpponentRule"' not in line and 'BELOW ZERO' not in line: continue
        try: r = json.loads(line)
        except ValueError: continue
        s = r.get('summary') or ''
        if 'HIS MOVE WHY: #' in s:
            s2 = s[s.index('HIS MOVE WHY: #'):].split(' | ')[0]
            m = HMW.match(s2)
            if not m: continue
            uid, name, assumed, by, did = m.groups()
            board = '; their turn changed the board' in did
            did0 = did.split('; their turn changed the board')[0]
            if did0.startswith('it charged as assumed') or did0.startswith('as assumed'): cat = 'as assumed'
            elif did0.startswith('it charged'): cat = 'charged (not as assumed)'
            elif did0.startswith('it did not charge'): cat = 'did not charge'
            elif did0.startswith('other job'): cat = 'other job'
            elif did0.startswith('same job, other spot'): cat = 'same job, other spot'
            elif 'he made no objective row' in did0: cat = 'no row of his'
            elif 'our sum named the action' in did0: cat = 'our sum named it, not his chooser'
            elif 'no move planned' in did0: cat = 'no move planned'
            else: cat = 'other'
            inch = re.search(r'([\d.]+)" from the assumed place', did0)
            real = re.search(r'his row is "(.*?)"', did0)
            rows.append(dict(part=part, game=g, turn=r.get('turn'), side=r.get('side'), newside=newside, uid=uid, name=name, assumed=assumed,
                             akind=kind(assumed), by=by, did=did0, cat=cat, board=board, inch=float(inch.group(1)) if inch else None,
                             real=real.group(1) if real else None))
        elif 'PROMISE BELOW ZERO: #' in s:
            s2 = s[s.index('PROMISE BELOW ZERO: #'):].split(' | ')[0]
            m = re.search(r'~(-?[\d.]+) VP at (\d+)%\); now the charge is worth ~(-?[\d.]+) VP', s2)
            parts = re.search(r'its parts: (.*)$', s2)
            pl = []
            if parts:
                for p in parts.group(1).split(', '):
                    mm = re.match(r'(.*) ([+-][\d.]+)$', p.strip())
                    if mm: pl.append((mm.group(1), float(mm.group(2))))
            gains = re.search(r'\(gains ~([^)]*)\)', s2)
            pbz.append(dict(part=part, game=g, turn=r.get('turn'), text=s2, promise=float(m.group(1)) if m else None, chance=int(m.group(2)) if m else None,
                            worth=float(m.group(3)) if m else None, parts=pl, gains=gains.group(1) if gains else None))
json.dump(dict(games=games, rows=rows, pbz=pbz), open(os.path.expanduser('~/ana/hmw.json'), 'w'))
print(games, 'games;', len(rows), 'HIS MOVE WHY rows;', len(pbz), 'PROMISE BELOW ZERO rows')
c = collections.Counter(r['cat'] for r in rows)
for k, v in c.most_common(): print(f'{k:40s} {v:6d} {100*v/len(rows):5.1f}%  board changed {sum(1 for r in rows if r["cat"]==k and r["board"])}')

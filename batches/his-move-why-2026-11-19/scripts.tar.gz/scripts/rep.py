import json,collections,re,os
d=json.load(open(os.path.expanduser('~/ana/hmw.json'))); R=d['rows']; P=d['pbz']
def job(s):
    if not s: return '(none)'
    s=re.sub(r'#\d+.*','',s); s=re.sub(r'\(.*','',s); return s.strip(' ,;:') or '(none)'
def tgt(s):
    m=re.search(r'#(\d+)',s or ''); return m.group(1) if m else re.sub(r'\(.*','',s or '').strip()
def ak(a): return a.split(' ')[0]
def grp(r):
    c=r['cat']
    if c=='other job':
        a,b=job(r['by']),job(r['real'])
        if a==b and tgt(r['by'])!=tgt(r['real']): return f'other job: same kind ({a}), another target'
        if a==b: return f'other job: same kind ({a}), wording differs'
        return f'other job: {a} -> {b}'
    if c=='same job, other spot':
        x=r['inch'] or 0; return 'same job, other spot: '+('1-3"' if x<3 else '3-6"' if x<6 else '6-12"' if x<12 else '12"+')
    if c=='charged (not as assumed)':
        return 'charged: assumed another target' if ak(r['assumed'])=='charge' else f'charged: assumed it would {ak(r["assumed"])}'
    if c=='did not charge': return 'assumed charge, did not charge'
    return c
N=len(R); miss=[r for r in R if r['cat']!='as assumed']
print(f"N {N} miss {len(miss)}")
g=collections.Counter(grp(r) for r in miss); ex=collections.defaultdict(list)
for r in miss: ex[grp(r)].append(r)
out=[]
for k,v in g.most_common(16):
    seen=[]; byp=collections.defaultdict(list)
    for r in ex[k]: byp[r['part']].append(r)
    for i in range(50):
        for p in sorted(byp):
            if len(byp[p])>i and len(seen)<4 and (byp[p][i]['part'],byp[p][i]['game']) not in [(a,b) for a,b,_,_ in seen]:
                r=byp[p][i]; seen.append((r['part'],r['game'],r['turn'],r['name']))
    bc=sum(1 for r in ex[k] if r['board'])
    out.append((k,v,bc,seen))
    print(f"| {k} | {v} | {100*v/N:.1f}% | {100*bc/v:.0f}% | " + "; ".join(f"{p}/{g2[5:]} t{t} {n}" for p,g2,t,n in seen)+" |")
json.dump(out,open(os.path.expanduser('~/ana/groups.json'),'w'))
# turn classes
turns=collections.defaultdict(list)
for r in R: turns[(r['part'],r['game'],r['turn'],r['side'])].append(r)
fl=collections.Counter()
for rs in turns.values():
    flag=any(r['board'] for r in rs); m=any(r['cat']!='as assumed' for r in rs)
    k='changed' if flag else ('not changed' if m else 'all as assumed (unknown)')
    fl[k,'t']+=1; fl[k,'r']+=len(rs); fl[k,'m']+=sum(r['cat']!='as assumed' for r in rs)
for k in ('changed','not changed','all as assumed (unknown)'): print(k, fl[k,'t'], fl[k,'r'], fl[k,'m'], f"{100*fl[k,'m']/max(fl[k,'r'],1):.0f}%")
# kind table
t=collections.defaultdict(collections.Counter)
for r in R: t[ak(r['assumed'])][r['cat']]+=1
cats=['as assumed','other job','same job, other spot','charged (not as assumed)','did not charge','no row of his','our sum named it, not his chooser']
print('| kind | rows | '+' | '.join(cats)+' |')
for k in ('stand','move','march','charge'):
    c=t[k]; n=sum(c.values()); print(f"| {k} | {n} | "+' | '.join(f"{c[x]} ({100*c[x]/n:.0f}%)" for x in cats)+' |')
print('--- PBZ')
fa=sum(1 for p in P if any(t=='FIVE ACTION' and abs(v-p['worth'])<0.2 for t,v in p['parts']))
print('five action == worth', fa, 'of', len(P))
mg=collections.defaultdict(list)
for p in P:
    parts=[(t,v) for t,v in p['parts'] if t!='FIVE ACTION']
    m=min(parts,key=lambda x:x[1]) if parts else ('(none)',0)
    mg[m[0]].append(p)
for k,v in sorted(mg.items(), key=lambda x:-len(x[1])):
    print(f"| {k} | {len(v)} | " + "; ".join(sorted({f'{p["part"]}/{p["game"][5:]} t{p["turn"]}' for p in v}, key=lambda x:(x[:5]))[::max(1,len(v)//4)][:4]) + ' |')
c=collections.Counter(); s=collections.defaultdict(float); ng=collections.Counter()
for p in P:
    for t,v in p['parts']:
        if t=='FIVE ACTION': continue
        c[t]+=1; s[t]+=v; ng[t]+= v<0
for t,v in sorted(s.items(), key=lambda x:x[1])[:14]: print(f"| {t} | {c[t]} | {ng[t]} | {v/len(P):+.1f} |")
for t,v in sorted(s.items(), key=lambda x:-x[1])[:6]: print(f"+| {t} | {c[t]} | {v/len(P):+.1f} |")
# gains/risk vs promise
import statistics
gs=[];rk=[]
for p in P:
    m=re.search(r'gains ~(-?[\d.]+), minus ~(-?[\d.]+) risk',p['text'])
    if m: gs.append(float(m.group(1))); rk.append(float(m.group(2)))
print('promise mean',statistics.mean(p['promise'] for p in P),'chance mean',statistics.mean(p['chance'] for p in P),'worth mean',statistics.mean(p['worth'] for p in P),'gain mean',statistics.mean(gs),'risk mean',statistics.mean(rk), len(gs))
print('gain<promise', sum(1 for p,g2 in zip(P,gs) if g2<p['promise']))
dup=sum(1 for p in P if len([t for t,_ in p['parts']])!=len({t for t,_ in p['parts']})); print('dup tags',dup)
print('per arm', collections.Counter(p['part'][:3] for p in P), 'games with', len({(p['part'],p['game']) for p in P}))

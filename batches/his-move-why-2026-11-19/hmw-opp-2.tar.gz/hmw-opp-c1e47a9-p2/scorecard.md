# Doctrine scorecard: hmw-opp-c1e47a9-p2

### Scorecard: hmw-opp-c1e47a9-p2

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0106 | 4 | 1 | Mine | no | 11 | - | 0 | 4 | 0 | 0 | 0 | 442 |
| L0106 | 4 | 1 | Opponent | no | 0 | - | 0 | 3 | 0 | 0 | 0 | 635 |
| L0122 | 2 | 1 | Mine | - | - | - | 0 | 1 | 0 | 0 | 0 | 0 |
| L0122 | 2 | 1 | Opponent | - | - | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L0206 | 2 | 1 | Mine | - | - | 3 | 1 | 5 | 1 | 0 | 0 | 0 |
| L0206 | 2 | 1 | Opponent | - | - | - | 0 | 2 | 0 | 0 | 0 | 275 |
| L0222 | 6 | 1 | Mine | no | 0 | 3 | 0 | 5 | 1 | 0 | 0 | 0 |
| L0222 | 6 | 1 | Opponent | no | 0 | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L0307 | 1 | 1 | Mine | yes | 1 | - | 0 | 1 | 0 | 0 | 0 | 1070 |
| L0307 | 1 | 1 | Opponent | yes | 2 | 4 | 2 | 1 | 0 | 0 | 0 | 202 |
| L0323 | 5 | 1 | Mine | no | - | - | 0 | 3 | 0 | 0 | 0 | 675 |
| L0323 | 5 | 1 | Opponent | yes | - | 2 | 2 | 3 | 2 | 0 | 0 | 0 |
| L0409 | 1 | 1 | Mine | no | 6 | 2 | 3 | 2 | 1 | 0 | 0 | 112 |
| L0409 | 1 | 1 | Opponent | no | 5 | - | 0 | 0 | 0 | 0 | 0 | 632 |
| L0425 | 5 | 1 | Mine | yes | - | 2 | 2 | 4 | 0 | 0 | 0 | 0 |
| L0425 | 5 | 1 | Opponent | yes | - | 6 | 2 | 4 | 1 | 0 | 0 | 0 |
| L0512 | 2 | 1 | Mine | - | - | - | 0 | 2 | 0 | 0 | 0 | 1010 |
| L0512 | 2 | 1 | Opponent | - | - | 4 | 1 | 1 | 2 | 0 | 0 | 165 |
| L0528 | 6 | 1 | Mine | no | 7 | 6 | 1 | 2 | 0 | 0 | 0 | 548 |
| L0528 | 6 | 1 | Opponent | no | 2 | - | 0 | 2 | 0 | 0 | 0 | 0 |
| L0616 | 4 | 1 | Mine | no | 0 | - | 1 | 2 | 1 | 0 | 0 | 798 |
| L0616 | 4 | 1 | Opponent | no | 6 | - | 0 | 1 | 1 | 0 | 0 | 100 |
| L0632 | 2 | 1 | Mine | - | - | 2 | 2 | 1 | 0 | 0 | 0 | 798 |
| L0632 | 2 | 1 | Opponent | - | - | 3 | 3 | 2 | 0 | 0 | 0 | 170 |
| L0721 | 1 | 1 | Mine | yes | 2 | 2 | 2 | 0 | 0 | 0 | 0 | 420 |
| L0721 | 1 | 1 | Opponent | yes | 0 | - | 3 | 4 | 1 | 0 | 0 | 355 |
| L0810 | 6 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 605 |
| L0810 | 6 | 1 | Opponent | no | 13 | 2 | 0 | 0 | 1 | 0 | 0 | 0 |
| L0827 | 5 | 1 | Mine | no | - | - | 0 | 2 | 0 | 0 | 0 | 605 |
| L0827 | 5 | 1 | Opponent | yes | - | 2 | 2 | 6 | 0 | 0 | 0 | 75 |
| L0918 | 6 | 1 | Mine | no | 0 | 3 | 3 | 1 | 0 | 0 | 0 | 420 |
| L0918 | 6 | 1 | Opponent | no | 12 | 4 | 1 | 1 | 0 | 0 | 0 | 234 |
| L0934 | 4 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 420 |
| L0934 | 4 | 1 | Opponent | no | 0 | 4 | 1 | 6 | 0 | 0 | 0 | 0 |
| L1026 | 6 | 1 | Mine | no | 9 | 4 | 0 | 0 | 0 | 0 | 0 | 618 |
| L1026 | 6 | 1 | Opponent | no | 11 | 3 | 3 | 2 | 0 | 0 | 0 | 0 |
| L1118 | 2 | 1 | Mine | - | - | 3 | 1 | 0 | 1 | 0 | 0 | 330 |
| L1118 | 2 | 1 | Opponent | - | - | - | 2 | 2 | 0 | 0 | 0 | 185 |
| L1135 | 1 | 1 | Mine | yes | 8 | - | 0 | 0 | 0 | 0 | 0 | 330 |
| L1135 | 1 | 1 | Opponent | yes | 0 | - | 2 | 3 | 1 | 0 | 0 | 0 |
| L1228 | 4 | 1 | Mine | no | 0 | 4 | 1 | 0 | 0 | 0 | 0 | 524 |
| L1228 | 4 | 1 | Opponent | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 0 |
| L1323 | 3 | 1 | Mine | no | 4 | 2 | 3 | 1 | 0 | 0 | 0 | 317 |
| L1323 | 3 | 1 | Opponent | yes | 2 | 2 | 7 | 2 | 1 | 0 | 0 | 0 |
| L1418 | 2 | 1 | Mine | - | - | 2 | 5 | 2 | 1 | 0 | 0 | 123 |
| L1418 | 2 | 1 | Opponent | - | - | - | 0 | 2 | 0 | 0 | 0 | 34 |
| L1435 | 1 | 1 | Mine | no | 3 | 2 | 3 | 2 | 0 | 0 | 0 | 151 |
| L1435 | 1 | 1 | Opponent | no | 0 | 6 | 1 | 1 | 0 | 0 | 0 | 0 |
| L1531 | 1 | 1 | Mine | no | 1 | 3 | 5 | 1 | 1 | 0 | 0 | 0 |
| L1531 | 1 | 1 | Opponent | no | 2 | 2 | 1 | 0 | 0 | 0 | 0 | 340 |
| L1629 | 3 | 1 | Mine | no | 6 | 4 | 1 | 0 | 0 | 0 | 0 | 200 |
| L1629 | 3 | 1 | Opponent | no | 2 | 2 | 1 | 1 | 0 | 0 | 0 | 170 |
| L1727 | 5 | 1 | Mine | yes | - | - | 0 | 1 | 0 | 0 | 0 | 0 |
| L1727 | 5 | 1 | Opponent | yes | - | 2 | 8 | 6 | 0 | 0 | 0 | 0 |
| L1827 | 3 | 1 | Mine | no | 3 | 4 | 3 | 1 | 0 | 0 | 0 | 77 |
| L1827 | 3 | 1 | Opponent | no | 2 | 3 | 2 | 2 | 1 | 0 | 0 | 0 |
| L1927 | 1 | 1 | Mine | yes | 3 | 2 | 5 | 0 | 0 | 0 | 0 | 55 |
| L1927 | 1 | 1 | Opponent | no | 3 | 1 | 7 | 1 | 0 | 0 | 0 | 0 |
| L2029 | 1 | 1 | Mine | no | 0 | 2 | 1 | 0 | 1 | 0 | 0 | 275 |
| L2029 | 1 | 1 | Opponent | no | 8 | 2 | 4 | 1 | 0 | 0 | 0 | 170 |
| L2131 | 1 | 1 | Mine | yes | 2 | - | 0 | 2 | 0 | 0 | 0 | 500 |
| L2131 | 1 | 1 | Opponent | no | 3 | - | 0 | 2 | 1 | 0 | 0 | 340 |
| L2235 | 3 | 1 | Mine | no | 0 | 2 | 1 | 1 | 0 | 0 | 0 | 55 |
| L2235 | 3 | 1 | Opponent | no | 0 | 1 | 2 | 2 | 1 | 0 | 0 | 499 |
| L2429 | 5 | 1 | Mine | yes | - | 4 | 1 | 1 | 0 | 0 | 0 | 0 |
| L2429 | 5 | 1 | Opponent | no | - | 2 | 3 | 5 | 0 | 0 | 0 | 205 |
| L2535 | 3 | 1 | Mine | no | 1 | - | 1 | 0 | 1 | 0 | 0 | 0 |
| L2535 | 3 | 1 | Opponent | no | 0 | 1 | 3 | 4 | 0 | 0 | 0 | 0 |
| L2735 | 5 | 1 | Mine | yes | - | 2 | 3 | 3 | 1 | 0 | 0 | 0 |
| L2735 | 5 | 1 | Opponent | no | - | 3 | 2 | 1 | 0 | 0 | 0 | 0 |
| L3033 | 3 | 1 | Mine | no | 0 | 3 | 3 | 1 | 0 | 0 | 0 | 0 |
| L3033 | 3 | 1 | Opponent | no | 0 | 3 | 5 | 3 | 0 | 0 | 0 | 405 |
| **Average** | | | Mine | 30% | 2.8 | 2.9 | 1.4 | 1.5 | 0.3 | 0.0 | 0.0 | 318.8 |
| **Average** | | | Opponent | 27% | 3.0 | 2.7 | 2.1 | 2.2 | 0.4 | 0.0 | 0.0 | 144.2 |

### KPIs: hmw-opp-c1e47a9-p2

Rules off - Mine only: FIVE ACTION, LIKELY CHARGE, FALLS SHORT, TIME ON OUR SIDE, FEATURE BUFFS, GETS AWAY CHANCE, GUN MASK, RUN DOWN, FOUR ROUNDS, CHARGE LOSSES, CHARACTER GUNS, STAND AND SHOOT, FALL BACK GOOD ORDER, AFTERMATH IN POINTS, NEXT CHARGE BY LIST, NEXT OBJECTIVE NEARER, NO DOUBLE ROUNDS, SCALED CHANCE, LEGAL CHARGES ONLY, SHOT OR CHARGE, MOVE CARRIES THE JOB, MOVE TO CHARGE COMPUTED, RISK BY HIS FIGURE, SHOT RISK POINTS, ONE TARGET A SHOOTER, ONE CHARGE A CHARGER, HIS CHARGE LIST, HIS SHOT LIST, HIS MOVE AND SHOT, HIS LEGAL MOVES, HIS TURN DENIED, THE PROMISE ADDS, HE SHOOTS OR CHARGES, HIS RANDOM MOVE, HIS CHARGE DENIED, SAME CHARGE LATER, FRIEND CHARGES FIRST, FRIEND SHOOTS FIRST, WAITS AGAIN, WOUNDS ON THE RANKS, THE PROMISED MOVE, MARCH BY THE SUM, FIGHT TO THE END, THE DEARER SUM KEEPS ITS PLAN, HIS OWN BEST MOVE, TIED UP BY THE SUM, REFORMS TO MEET IT, STANDS FOR A REASON, HOLDER ASSIGNMENT, ARMY TABLE, MOVE ORDER, CHARGE LIST READ AGAIN, PROMISE READS THE TABLE, SUPPORT WORKED OUT, WHO GETS IN, THE TABLE BINDS, HIS ONE MOVE, PROMISE BY ITS OWN SUM, SECOND LOOK, LOST AFTER ESCAPE, PROMISE KNOWS THE FIGHT, SPOT AS THE GAME MOVES, ONE PROMISE A TARGET, WHAT THE JOINER ADDS, DENIED BY THE FIGHT, HIS MOVE AS HE DECIDES, ROUNDS AFTER TERROR, MARCH OF THE TABLE, PROMISE HOLDS THE SPOT, PROMISE SHOT AWAY, OWN CAST FIRST, PROMISE IN STEPS, STUPIDITY NEXT TURN, PROMISE BELOW ZERO, HIS MOVE WHY, THE TABLE AGAIN, SHOTS AFTER THE MOVES, SET FIGHT, JOINT CHARGE NOW, JOINT ON THE TABLE, JOINT LOOK BACK, AFTERMATH WITH FRIENDS, HIS FIGHT TOGETHER, SET UP BY THE SET, QUARTER ODDS, CHEAPEST HOLDER, NEARER NOT NEEDED, NO FORCED ADVANCE, HARD STAY DROPPED.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 23% (39 of 167) | 11% (20 of 176) | 17% (59 of 343) |
| Winner chose to follow up after the loser gave ground |  | 94% (33 of 35); on the table 94% | 89% (41 of 46); on the table 96% | 91% (74 of 81); on the table 95% |
| Winner chose to pursue after the loser fell back in good order |  | 86% (12 of 14); on the table 93% | 60% (3 of 5); on the table 60% | 79% (15 of 19); on the table 84% |
| Winner chose to pursue after the loser fled |  | 55% (17 of 31); on the table 68% | 79% (19 of 24); on the table 79% | 65% (36 of 55); on the table 73% |
| Winner chose to follow up or pursue (all three) |  | 78% (62 of 80); on the table 84% | 84% (63 of 75); on the table 88% | 81% (125 of 155); on the table 86% |
| Magic missiles tried each own turn | 50%+ | 45% (154 of 342) | 29% (46 of 156) | 40% (200 of 498) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 54% (154 of 283) | 38% (46 of 120) | 50% (200 of 403) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 35% (8 of 23) | 61% (34 of 56) | 53% (42 of 79) |
| Points that never fought | lower | 50% (35946 of 71583) | 54% (39115 of 71989) | 52% (75061 of 143572) |
|   infantry points that never fought | lower | 70% (11388 of 16324) | 72% (10049 of 14029) | 71% (21437 of 30353) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 61% (174 of 284) | 63% (188 of 297) | 62% (362 of 581) |
| Bound items with a magic missile used (at least once a game) |  | 85% (17 of 20); 1.6 uses a game | 78% (14 of 18); 0.9 uses a game | 82% (31 of 38); 1.3 uses a game |
| Bound items with another spell used |  | 56% (10 of 18); 0.6 uses a game | 50% (1 of 2); 0.0 uses a game | 55% (11 of 20); 0.3 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 55% (11 of 20); 0.3 uses a game | 14% (1 of 7); 0.0 uses a game | 44% (12 of 27); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 57% (34342 of 60231) | 60% (37918 of 63281) | 59% (72260 of 123512) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 2.1 (40%) | 0.9 (30%) | 3.0 (37%) |
| MARCHED: its unit marched | 1.0 (20%) | 0.7 (23%) | 1.7 (21%) |
| CHARGED: its unit charged | 0.1 (1%) | 0.1 (2%) | 0.1 (1%) |
| IN COMBAT: engaged in combat | 1.3 (24%) | 0.5 (17%) | 1.8 (22%) |
| REAR RANK: in a rear rank | 0.2 (4%) | 0.1 (5%) | 0.3 (4%) |
| FLEEING: fleeing | 0.1 (2%) | 0.0 (1%) | 0.1 (1%) |
| GONE: slain | 0.3 (5%) | 0.4 (13%) | 0.7 (8%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (0%) | 0.1 (2%) | 0.1 (1%) |
| STUPIDITY: Stupidity | 0.1 (2%) | 0.0 (1%) | 0.1 (2%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.1 (2%) | 0.2 (6%) | 0.3 (3%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.2 | 1.6 | 1.1 | 5.6 | 0.5 | 1.2 |
| not cast | 3.7 | 3.3 | 3.9 | 8.3 | 1.8 | 20.5 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) | 0.0 (0%) | 1.1 (5%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.9 (58%) | 0.2 (4%) | 3.0 (37%) | 0.6 (32%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.7 (21%) | 0.2 (9%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (2%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.2 (6%) | 0.1 (3%) | 0.6 (16%) | 1.8 (22%) | 0.1 (3%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.3 (8%) | 0.3 (10%) | 0.4 (12%) | 0.3 (4%) | 0.0 (0%) | 0.0 (0%) |
| NO CASTS LEFT: every cast used on other spells | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (2%) | 0.0 (0%) |
| FLEEING: fleeing | 0.1 (2%) | 0.0 (0%) | 0.1 (1%) | 0.1 (1%) | 0.0 (0%) | 0.2 (1%) |
| GONE: slain | 0.6 (15%) | 0.4 (13%) | 0.5 (12%) | 0.7 (8%) | 0.0 (2%) | 2.4 (12%) |
| OFF THE TABLE: off the table or not arrived | 0.1 (2%) | 0.0 (0%) | 0.1 (4%) | 0.1 (1%) | 0.1 (5%) | 0.1 (1%) |
| STUPIDITY: Stupidity | 0.1 (4%) | 0.1 (2%) | 0.0 (1%) | 0.1 (2%) | 0.0 (0%) | 0.2 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (3%) | 0.3 (10%) | 0.0 (0%) | 0.0 (0%) | 0.8 (46%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (3%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.2 (61%) | 0.1 (4%) | 1.9 (50%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 16.5 (80%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.6 a game | 0.6 a game | 0.6 a game |
| stood (cast and not dispelled) | 71% (12 of 17) | 61% (14 of 23) | 65% (26 of 40) |
| the unit moved after it | 67% (8 of 12) | 86% (12 of 14) | 77% (20 of 26) |
| it charged on its next turn | 0% (0 of 12) | 14% (2 of 14) | 8% (2 of 26) |
| the enemy charged it first | 0% (0 of 12) | 0% (0 of 14) | 0% (0 of 26) |
| it fought by the end of its next turn | 0% (0 of 12) | 0% (0 of 14) | 0% (0 of 26) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 12) | 14% (2 of 14) | 8% (2 of 26) |
| none of these (no charge, no fight, no charge escaped) | 100% (12 of 12) | 71% (10 of 14) | 85% (22 of 26) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 67% (596 of 884) | 59% (467 of 793) | 63% (1063 of 1677) |
|   cavalry | 53% (39 of 73) | 61% (106 of 174) | 59% (145 of 247) |
|   character | 59% (62 of 105) | 42% (45 of 106) | 51% (107 of 211) |
|   chariot | 69% (65 of 94) | 68% (38 of 56) | 69% (103 of 150) |
|   infantry | 59% (164 of 280) | 55% (164 of 298) | 57% (328 of 578) |
|   monster | 38% (17 of 45) | 74% (28 of 38) | 54% (45 of 83) |
|   war machine | 87% (249 of 287) | 71% (86 of 121) | 82% (335 of 408) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.9 (24%) | 1.6 (18%) | 3.5 (21%) |
| CHARGED: it charged | 0.8 (10%) | 1.0 (11%) | 1.9 (11%) |
| FLEEING: it fled or was fleeing | 0.2 (3%) | 0.2 (2%) | 0.4 (2%) |
| IN COMBAT: it fought this turn or the last | 0.6 (7%) | 0.5 (5%) | 1.1 (6%) |
| MOVED: a war machine that moved | 0.0 (0%) | 0.3 (3%) | 0.3 (2%) |
| NO TARGET IN RANGE | 1.9 (24%) | 2.7 (30%) | 4.6 (27%) |
| ONLY IN COMBAT: the only targets were in combat | 0.4 (5%) | 0.4 (5%) | 0.8 (5%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.6 (20%) | 1.4 (16%) | 3.0 (18%) |
| SHELTERED: the target was sheltered | 0.3 (3%) | 0.4 (5%) | 0.7 (4%) |
| STUPIDITY | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR | 0.2 (3%) | 0.4 (5%) | 0.7 (4%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 6.1 | 1.2 | 83% | 4.6 pts | 28 pts |
| character | 3.1 | 1.3 | 68% | 11.0 pts | 34 pts |
| chariot | 2.9 | 2.1 | 58% | 23.9 pts | 68 pts |
| infantry | 13.0 | 4.4 | 75% | 8.6 pts | 112 pts |
| monster | 1.4 | 0.7 | 71% | 7.5 pts | 11 pts |
| war machine | 9.3 | 9.9 | 56% | 26.8 pts | 250 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.1 | 4.1 | 3.6 |
| Charges that made contact a game | 2.5 | 2.8 | 2.7 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.75 declared, 0.62 contact (24 units) | 0.77 declared, 0.62 contact (13 units) | 0.76 declared, 0.62 contact (37 units) |
|   per unit a game, units carrying another wizard (or one alone) | 1.00 declared, 0.83 contact (6 units) | 1.08 declared, 0.83 contact (12 units) | 1.06 declared, 0.83 contact (18 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.35 declared, 0.29 contact (248 units) | 0.41 declared, 0.27 contact (304 units) | 0.38 declared, 0.28 contact (552 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 59% (43 of 73) | 61% (11 of 18) | 67% (8 of 12) | 60% (62 of 103) |
| Character in a unit | 84% (38 of 45) | 81% (17 of 21) | 80% (4 of 5) | 83% (59 of 71) |
| Character on its own | 81% (22 of 27) | 64% (21 of 33) | 38% (23 of 61) | 55% (66 of 121) |
| Chariot | 65% (11 of 17) | 46% (6 of 13) | - | 57% (17 of 30) |
| Infantry | 60% (56 of 94) | 59% (20 of 34) | 33% (1 of 3) | 59% (77 of 131) |
| Monster | 45% (13 of 29) | 67% (6 of 9) | - | 50% (19 of 38) |
| Monstrous | 71% (10 of 14) | 64% (9 of 14) | - | 68% (19 of 28) |
| War Machines | 72% (41 of 57) | 100% (2 of 2) | - | 73% (43 of 59) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 100% (3 of 3); on the table 100% | 40% (41 of 102) | 77% | 86% (19 of 22) | 83% (5 of 6); 4.0 uses a game | 100% (2 of 2); 1.0 uses a game | 83% (5 of 6); 1.2 uses a game |
| Chaos Dwarfs | 4 | 75% (6 of 8); on the table 75% | 44% (16 of 36) | 42% | 56% (18 of 32) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
| Dwarfen Mountain Holds | 6 | 78% (7 of 9); on the table 78% | - | 75% | 69% (37 of 54) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 7 | 60% (6 of 10); on the table 60% | 56% (27 of 48) | 59% | 67% (51 of 76) | 0.0 uses a game | 100% (2 of 2); 0.6 uses a game | 50% (2 of 4); 0.3 uses a game |
| Grand Cathay | 6 | 75% (3 of 4); on the table 100% | 42% (58 of 138) | 57% | 44% (24 of 54) | 86% (12 of 14); 5.8 uses a game | 50% (1 of 2); 0.2 uses a game | 0% (0 of 6); 0.0 uses a game |
| High Elf Realms | 4 | 79% (11 of 14); on the table 86% | 17% (3 of 18) | 38% | 45% (15 of 33) | 100% (3 of 3); 2.5 uses a game | 43% (6 of 14); 3.8 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 2 | 100% (6 of 6); on the table 100% | - | 63% | 58% (7 of 12) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.5 uses a game |
| Lizardmen | 1 | 100% (2 of 2); on the table 100% | - | 53% | 71% (5 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 4 | 100% (3 of 3); on the table 100% | 0% (0 of 18) | 59% | 68% (19 of 28) | 100% (4 of 4); 2.8 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 1 | 100% (4 of 4); on the table 100% | 58% (7 of 12) | 0% | 12% (1 of 8) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Skaven | 3 | 53% (8 of 15); on the table 80% | 28% (5 of 18) | 42% | 60% (15 of 25) | 50% (1 of 2); 0.3 uses a game | 0.0 uses a game | 67% (2 of 3); 0.7 uses a game |
| Tomb Kings of Khemri | 5 | 80% (8 of 10); on the table 80% | - | 59% | 44% (11 of 25) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 9 | 90% (36 of 40); on the table 90% | 44% (29 of 66) | 37% | 78% (42 of 54) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 9 | 74% (14 of 19); on the table 84% | 28% (5 of 18) | 39% | 55% (40 of 73) | 100% (2 of 2); 0.7 uses a game | 0.0 uses a game | 100% (1 of 1); 0.1 uses a game |
| Wood Elf Realms | 7 | 100% (8 of 8); on the table 100% | 38% (9 of 24) | 59% | 74% (58 of 78) | 57% (4 of 7); 1.7 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (hmw-opp-c1e47a9-p2, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 29% (21) | 50% (23) | 37% (44) |
| ...free all their last turn and able to turn (per game) | 0.33 | 0.53 | 0.86 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.08 | 0.08 | 0.17 |
| ...with the charger already in that arc before they moved (per game) | 0.31 | 0.25 | 0.56 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 1.33 | 0.06 | 1.39 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.67 | 0.03 | 0.69 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 4.58 | 0.44 | 5.03 |

### Quality by phase: hmw-opp-c1e47a9-p2

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.1 | 2.4 |
| Strategy | Charge objectives carried out (made contact) | 70% (64 of 91) | 55% (76 of 137) |
| Strategy | Shoot objectives carried out (shot that target) | 49% (225 of 461) | 44% (100 of 228) |
| Strategy | Close-in objectives charged next turn | 12% (23 of 186) | - |
| Strategy | Support requests answered (helper made contact too) | 73% (8 of 11) | 37% (7 of 19) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (3 of 3) | 100% (3 of 3) |
| Strategy | Hexes on a unit its side charged or shot that turn | 52% (14 of 27) | 50% (5 of 10) |
| Strategy | Joined characters whose unit fought | 27% (18 of 66) | 19% (8 of 43) |
| Strategy | Lone characters that fought | 61% (48 of 79) | 64% (51 of 80) |
| Movement | Charges halted short of contact | 0.0 | 0.3 |
| Movement | Idle units | 1.5 | 2.2 |
| Movement | Points that never moved of their own | 318.8 | 144.2 |
| Movement | Fights charged into per game | 2.1 | 2.6 |
| Movement | Charges with odds: long shots (under 50%) | 11 of 67, net +213 | 28 of 85, net +1 |
| Movement | Charges with odds: sweet spot (55-75%) | 9 of 67, net +76 | 16 of 85, net +68 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 15 of 67, net +90 | 7 of 85, net +121 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 17 of 67, net +148 | 14 of 85, net +102 |
| Shooting | Shots by shooting units (incl. breath weapons) | 10.6 | 11.4 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 41% (156 of 380) | 56% (231 of 412) |
| Shooting | Points destroyed by shooting units | 91.8 | 56.0 |
| Shooting | War machine shots | 6.9 | 2.4 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 55% (137 of 249) | 69% (59 of 86) |
| Shooting | Points destroyed by war machines | 83.4 | 43.1 |
| Magic | Magic missiles cast | 2.4 | 1.0 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 20% (17 of 87) | 33% (12 of 36) |
| Magic | Wounds caused by magic missiles | 4.5 | 1.7 |
| Magic | Wounds caused by other spells | 1.6 | 0.5 |
| Magic | Points destroyed by magic (all spells) | 46.1 | 20.7 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.9 / 0.9 / 0.5 / 0.1 | 1.9 / 0.3 / 0.3 / 0.2 |
| Combat | Points destroyed in combat | 227.0 | 244.4 |
| Combat | Points run down | 70.5 | 32.7 |
| Combat | Net points per charged fight, damage counted | +98 | +65 |
| Combat | Net per 100 charger points, damage counted | +32.1 | +25.5 |
| Combat | First round won (charged fights) | 77% | 67% |
| Combat | Net points per charged fight | +99 | +50 |
| Combat | Net points per supported fight / lone fight | +118 / +94 | +14 / +53 |
| Combat | Charged fights on a top-3 enemy unit | 21 of 74 | 41 of 93 |
| Game | Points lost | 520.7 | 671.7 |
| Game | VP from objectives | 546.4 | 647.8 |
| Game | Lone holders (player turns) | 2.8 | 3.0 |

- Mine won / drew / lost: 13 / 10 / 13 of 36 ended games (of 36); mean margin (Mine - Opponent) +59 VP
- The side that went first won 13 of 26 games with a winner
- Points traded per game (both sides' losses): 1192
- Games not ended: 0; findings 2, warnings 0

### Opponent rules: hmw-opp-c1e47a9-p2

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.9 | +0.0 | 0.0 | 0.0 | 1.2 | +0.0 | 0.0 | 2.1 |
| ADVANCE WORTH | 6.1 | -177.3 | 221.6 | 101.3 | - | - | - | - |
| AFTERMATH IN POINTS | - | - | - | - | 0.1 | +42.0 | 0.0 | 0.0 |
| AFTERMATH WITH FRIENDS | - | - | - | - | 0.1 | +5.2 | 0.0 | 5.2 |
| ALREADY CARRIED | 0.1 | +0.0 | 1.5 | 0.0 | - | - | - | - |
| ARMY TABLE | - | - | - | - | 20.8 | +313.0 | 0.0 | 274.4 |
| ARRIVAL HUNT | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +5.9 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.9 | +0.0 | 0.0 | 35.8 | 0.4 | +0.0 | 0.0 | 3.5 |
| BACKUP TARGETS | 0.8 | +5.1 | 0.0 | 8.6 | 0.2 | +0.8 | 0.0 | 0.0 |
| BEST FACING | 0.4 | +16.4 | 0.0 | 2.9 | - | - | - | - |
| BEST FIRST | 1.7 | +89.2 | 45.6 | 33.9 | - | - | - | - |
| BEST MOVE FOR SHOOTERS | 1.2 | +66.5 | 0.0 | 10.4 | - | - | - | - |
| BEST OVERALL | 0.3 | +8.9 | 0.0 | 1.4 | - | - | - | - |
| BEST PREY | 0.9 | +29.3 | 14.9 | 21.5 | - | - | - | - |
| BEST PRIZE | 0.1 | -17.1 | 0.9 | 13.9 | 0.1 | -3.5 | 4.7 | 0.0 |
| BIG CHARACTER SAFETY | 0.1 | -0.0 | 0.0 | 0.0 | - | - | - | - |
| BLOCKED CHARGE SKIPPED | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| BLOCKED WHEEL | 0.2 | +1.9 | 0.0 | 1.7 | - | - | - | - |
| BLOWS WHERE AIMED | 0.2 | -24.1 | 14.7 | 16.6 | 0.2 | -10.3 | 5.6 | 16.5 |
| BOMBING RUN | 0.1 | +3.8 | 3.5 | 0.0 | - | - | - | - |
| BOUND ASSAILMENT | 0.1 | +0.0 | 0.0 | 7.7 | - | - | - | - |
| CANNON PLAN MISSED | 0.6 | +0.0 | 72.6 | 9.0 | 0.1 | +0.0 | 23.8 | 0.0 |
| CANNON PLANNED TARGET | 6.4 | +190.6 | 429.0 | 117.2 | 2.4 | +82.4 | 188.4 | 30.4 |
| CANNON SIGHT KEPT | 1.1 | +0.0 | 0.0 | 3.8 | 0.4 | +0.0 | 0.0 | 7.7 |
| CARRIES OUT SET-UP | 0.0 | +0.0 | 0.0 | 16.6 | 0.1 | -0.1 | 3.5 | 0.0 |
| CAST JOB | 0.8 | +12.4 | 18.0 | 7.0 | 0.6 | +20.0 | 83.8 | 0.0 |
| CASTER AWAY FROM SCREEN | 0.3 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.5 | +28.7 | 28.5 | 0.0 | 0.3 | +15.1 | 33.2 | 0.0 |
| CASTS AFTER FRIENDS | 0.4 | +0.0 | 0.0 | 13.9 | 0.4 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.0 | +0.9 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | 1.0 | +53.5 | 0.0 | 26.8 | 1.6 | +92.2 | 0.0 | 29.8 |
| CHAFF PASSED | 0.2 | -0.6 | 0.0 | 4.2 | 0.2 | -0.1 | 0.0 | 0.0 |
| CHAMPION KNOWS CHALLENGE | 0.0 | -0.2 | 0.0 | 0.0 | 0.1 | -3.4 | 0.0 | 8.8 |
| CHAMPION TAKES THE CHALLENGE | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHARACTER GUNS | - | - | - | - | 0.7 | +0.0 | 0.0 | 14.4 |
| CHARGE LIST READ AGAIN | - | - | - | - | 0.0 | +0.6 | 0.0 | 0.0 |
| CHARGE LOSSES | - | - | - | - | 10.5 | -632.1 | 0.0 | 407.5 |
| CHARGE NOT DECLARED | 0.1 | +0.0 | 0.0 | 1.7 | 0.1 | +0.0 | 0.0 | 2.9 |
| CHARGE NOW FIRST | 2.1 | +0.0 | 219.2 | 64.2 | 2.0 | +0.0 | 177.5 | 62.9 |
| CHARGE NOW WEIGHED | 0.5 | -31.6 | 23.0 | 10.0 | - | - | - | - |
| CHARGER SLAIN LOST | 0.3 | -7.6 | 12.3 | 23.7 | 0.2 | -15.7 | 4.6 | 15.4 |
| CHARIOT NO STATIC JOB | 0.0 | +0.0 | 0.0 | 2.4 | - | - | - | - |
| CHARIOT WIZARD CAREFUL | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHEAP HELPER | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| COMBAT PIVOT | 0.2 | +0.0 | 6.5 | 8.6 | 0.3 | +0.0 | 9.8 | 10.8 |
| CONTINUE AHEAD WEIGHED | 0.0 | +0.0 | 0.0 | 7.1 | 0.1 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | 0.4 | +71.7 | 16.9 | 13.9 | 0.6 | +56.0 | 12.2 | 16.5 |
| COVER ONCE | 7.7 | -597.3 | 0.0 | 105.1 | 4.8 | -330.3 | 0.0 | 70.4 |
| DEFENSIVE ARMY | 0.1 | +0.0 | 13.1 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| DENIED BY THE FIGHT | - | - | - | - | 0.8 | -10.7 | 25.6 | 36.9 |
| DEPLOY BY FIGURES | 8.0 | +12.1 | 0.0 | 13.6 | 8.1 | +65.4 | 0.0 | 32.6 |
| EDGE GIVE GROUND | 0.1 | +3.4 | 22.5 | 0.0 | 0.4 | +10.4 | 47.3 | 7.3 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 1.3 | +86.9 | 0.0 | 16.8 | 0.1 | +2.4 | 0.0 | 0.0 |
| FALL BACK GOOD ORDER | - | - | - | - | 3.0 | +10.6 | 192.8 | 69.6 |
| FALLBACK BY WORTH | 3.9 | +39.7 | 0.0 | 43.5 | 0.3 | +0.0 | 0.0 | 3.0 |
| FALLS SHORT | - | - | - | - | 15.1 | +213.5 | 0.0 | 255.8 |
| FEATURE BUFFS | - | - | - | - | 0.6 | +8.2 | 0.0 | 7.8 |
| FIGHT TO THE END | - | - | - | - | 1.2 | +25.1 | 52.6 | 36.8 |
| FIRE IN ORDER | 0.4 | +0.0 | 8.9 | 6.4 | 0.2 | +0.0 | 2.8 | 0.0 |
| FIVE ACTION | - | - | - | - | 88.2 | +4890.3 | 1103.9 | 1361.8 |
| FLANK NOT WEIGHED | 4.5 | +0.0 | 0.0 | 88.0 | 4.4 | +0.0 | 0.0 | 156.4 |
| FOCUS FIRE | - | - | - | - | 0.0 | +1.5 | 3.4 | 0.0 |
| FOLLOW UP WEIGHED | 0.5 | +62.3 | 0.0 | 27.5 | 0.6 | +72.2 | 0.0 | 16.6 |
| FOUR ROUNDS | - | - | - | - | 4.0 | +293.8 | 260.4 | 119.6 |
| FRIEND CHARGES FIRST | - | - | - | - | 0.0 | -2.2 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | - | - | - | - | 0.9 | -8.8 | 0.0 | 45.1 |
| FRIENDS SHOTS CHECKED | 0.2 | +11.9 | 0.0 | 0.0 | 0.1 | +10.1 | 0.0 | 0.0 |
| GIVES UP | - | - | - | - | 0.4 | -7.9 | 28.8 | 20.8 |
| GIVES UP ITS SCREEN | - | - | - | - | 0.0 | -0.0 | 3.4 | 0.0 |
| GROUND FLIERS | 0.0 | +1.1 | 0.0 | 0.0 | - | - | - | - |
| GUN FIGURES | 1.2 | +6.6 | 49.7 | 20.3 | 0.6 | +38.7 | 19.6 | 12.5 |
| GUN MASK | - | - | - | - | 0.3 | -0.3 | 0.0 | 0.0 |
| HARD STAY DROPPED | - | - | - | - | 1.6 | +0.0 | 0.0 | 9.8 |
| HE SHOOTS OR CHARGES | - | - | - | - | 3.6 | +0.0 | 0.0 | 163.8 |
| HELPER ALREADY ASKED | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HELPER UNSEEN | - | - | - | - | 0.1 | +0.0 | 0.0 | 0.0 |
| HILL BY ITS CHANCE | 0.4 | -29.5 | 0.0 | 7.0 | - | - | - | - |
| HIS CHARGE DENIED | - | - | - | - | 0.8 | +35.8 | 48.3 | 25.4 |
| HIS CHARGE LIST | - | - | - | - | 6.0 | +0.0 | 0.0 | 84.0 |
| HIS FIGHT TOGETHER | - | - | - | - | 2.0 | -59.7 | 0.0 | 103.5 |
| HIS LEGAL MOVES | - | - | - | - | 5.8 | +0.0 | 0.0 | 179.4 |
| HIS MOVE AND SHOT | - | - | - | - | 3.9 | -68.8 | 0.0 | 216.6 |
| HIS MOVE AS HE DECIDES | - | - | - | - | 32.8 | +12.2 | 495.9 | 0.0 |
| HIS MOVE WHY | 33.2 | +0.0 | 0.0 | 454.3 | - | - | - | - |
| HIS ONE MOVE | - | - | - | - | 18.3 | +41.7 | 3.8 | 222.5 |
| HIS OWN BEST MOVE | - | - | - | - | 2.4 | +0.0 | 0.0 | 80.6 |
| HIS RANDOM MOVE | - | - | - | - | 2.4 | +0.0 | 0.0 | 52.6 |
| HIS SHOT LIST | - | - | - | - | 46.3 | +2132.2 | 0.0 | 878.3 |
| HIS TURN DENIED | - | - | - | - | 1.6 | +56.8 | 123.6 | 67.6 |
| HOLD ODDS | - | - | - | - | 11.1 | +0.0 | 0.0 | 81.2 |
| HOLDER ASSIGNMENT | - | - | - | - | 11.3 | +1118.2 | 0.0 | 56.6 |
| HOLDER AT DEPLOYMENT | 1.0 | +173.9 | 0.0 | 3.9 | - | - | - | - |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 8.2 | -115.7 | 314.0 | 167.8 | 3.5 | -140.1 | 243.6 | 94.1 |
| HUNT ADVANCE | 0.1 | +0.6 | 6.2 | 1.4 | - | - | - | - |
| HUNT DROPPED | 0.1 | +0.0 | 3.3 | 0.0 | - | - | - | - |
| HUNT IN PAIRS | 0.3 | +16.0 | 0.0 | 0.0 | 0.1 | +0.5 | 0.0 | 0.0 |
| HUNT KEPT | 0.0 | +0.8 | 2.9 | 1.4 | - | - | - | - |
| HUNT RESULT | 0.1 | +8.2 | 3.3 | 1.4 | 0.1 | +16.5 | 0.0 | 0.0 |
| HUNT THE GUNS | 0.1 | +22.1 | 9.6 | 1.4 | 0.1 | +20.9 | 8.1 | 0.9 |
| IDLE COST | 16.4 | -291.0 | 0.0 | 158.9 | 11.6 | -167.5 | 0.0 | 212.1 |
| INVITES THE FIGHT | 1.4 | +9.9 | 67.7 | 18.9 | - | - | - | - |
| JOINT CHARGE NOW | - | - | - | - | 1.1 | +32.4 | 45.6 | 30.4 |
| JOINT CHARGE PLAN | 0.1 | +7.3 | 0.0 | 10.2 | - | - | - | - |
| JOINT KNOWS CHALLENGE | 0.1 | -0.3 | 0.0 | 0.0 | 0.0 | -2.1 | 0.0 | 0.0 |
| JOINT ON THE TABLE | - | - | - | - | 0.0 | +3.4 | 0.0 | 0.0 |
| KEEP FALLS | 0.1 | +1.2 | 0.0 | 0.0 | - | - | - | - |
| KEEPS ITS PREY | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KEEPS ITS TARGET | 1.5 | +45.0 | 94.7 | 42.3 | - | - | - | - |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| KILLS COUNT | 0.9 | +57.7 | 107.1 | 11.5 | - | - | - | - |
| KILLS COUNT NEXT TURN | 4.7 | +143.6 | 162.8 | 121.4 | - | - | - | - |
| LANE BY FIGURES | 0.7 | +29.6 | 0.0 | 0.0 | 0.9 | +44.4 | 0.0 | 24.3 |
| LEGAL CHARGES ONLY | - | - | - | - | 5.7 | +0.0 | 220.4 | 249.8 |
| LONE CHARACTER SAFE SPOT | 0.1 | +7.3 | 0.0 | 13.5 | - | - | - | - |
| LONE WIZARD HOLDS BACK | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| LONE WIZARD KEPT IN | 0.6 | +39.4 | 0.0 | 0.0 | 0.3 | +24.1 | 0.0 | 0.0 |
| LONG SHOT | 0.2 | -1.5 | 6.8 | 1.8 | 0.4 | -0.1 | 3.2 | 10.4 |
| LOST AFTER ESCAPE | - | - | - | - | 2.1 | +2.5 | 112.1 | 74.7 |
| LOST CHARGE | 2.2 | -32.6 | 97.9 | 56.8 | 0.0 | -0.0 | 0.0 | 0.0 |
| LURE BY WHAT IT DRAWS | 0.0 | +0.0 | 0.0 | 0.0 | 0.2 | -21.1 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 0.2 | +23.8 | 9.6 | 17.7 | 0.2 | +3.4 | 0.0 | 0.0 |
| MANOEUVRE | 0.2 | +1.8 | 0.0 | 5.4 | 0.7 | -0.1 | 0.0 | 12.8 |
| MARCH AT ESCAPER | 0.1 | +0.4 | 0.0 | 0.0 | 0.1 | +1.3 | 0.0 | 4.4 |
| MARCH BY THE SUM | - | - | - | - | 0.1 | +7.3 | 0.0 | 0.0 |
| MARCH CHECK | 0.3 | +8.7 | 0.0 | 4.5 | 0.7 | +36.9 | 0.0 | 16.4 |
| MARCH ODDS | 0.4 | +15.2 | 14.1 | 0.0 | - | - | - | - |
| MARCH OF THE TABLE | - | - | - | - | 0.1 | +3.0 | 0.0 | 0.0 |
| MARCH OVER CASTS | 0.4 | +16.7 | 0.0 | 10.2 | 0.5 | +77.7 | 0.0 | 43.5 |
| MAX FOR POSITIONING | 5.9 | +89.5 | 0.0 | 123.7 | 2.6 | +63.9 | 0.0 | 15.1 |
| MISSILES IN THE MOVE | 4.8 | +109.1 | 0.0 | 70.6 | 2.7 | +59.2 | 0.0 | 33.7 |
| MISSILES NEXT TURN | 5.4 | +71.7 | 0.0 | 99.3 | 3.7 | +43.2 | 0.0 | 81.6 |
| MODEL FACING | 0.3 | +52.5 | 0.0 | 5.0 | 0.4 | +65.0 | 0.0 | 1.7 |
| MONSTER WIZARD ROAMS | 0.1 | +0.0 | 9.6 | 38.0 | - | - | - | - |
| MOVE AND CAST | 0.3 | +8.4 | 0.0 | 2.2 | - | - | - | - |
| MOVE ORDER | - | - | - | - | 3.4 | +0.0 | 30.0 | 40.1 |
| MOVE SPELL IN RANGE | 0.1 | +2.0 | 0.0 | 16.1 | - | - | - | - |
| MOVE SPELL NOT WORTH | 0.0 | -0.0 | 0.0 | 0.0 | 0.0 | -0.0 | 0.0 | 0.0 |
| MOVE SPELL OUT OF RANGE | 0.3 | -14.3 | 0.0 | 30.0 | 0.3 | -10.6 | 3.5 | 7.6 |
| MOVE SPELL SPOT | 0.2 | +0.0 | 0.0 | 15.4 | 0.1 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE | 3.3 | +231.1 | 83.8 | 92.5 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | - | - | - | - | 7.8 | +672.3 | 0.0 | 189.2 |
| MOVES UNITS SPELL | 0.1 | +3.4 | 0.0 | 0.0 | - | - | - | - |
| NEARER NOT NEEDED | - | - | - | - | 5.8 | +256.4 | 0.0 | 51.5 |
| NEXT CHARGE BY LIST | - | - | - | - | 6.8 | -312.6 | 24.2 | 164.3 |
| NEXT OBJECTIVE NEARER | - | - | - | - | 0.3 | -21.0 | 0.0 | 1.1 |
| NO DOUBLE ROUNDS | - | - | - | - | 3.1 | -121.5 | 220.0 | 96.9 |
| NO RALLY LEFT | - | - | - | - | 0.0 | +1.5 | 0.0 | 0.0 |
| NOT NEEDED | 0.2 | -11.6 | 29.9 | 0.0 | - | - | - | - |
| NOT TURNED | 4.6 | +75.5 | 0.0 | 89.9 | 0.4 | +3.1 | 0.0 | 2.5 |
| NOT WORTH A CAST | 0.8 | -0.6 | 0.0 | 0.0 | 0.5 | -0.6 | 0.0 | 7.6 |
| OFF BEST | 17.5 | -770.2 | 0.0 | 216.0 | 4.2 | -129.5 | 0.0 | 123.3 |
| ONE CHARGE A CHARGER | - | - | - | - | 4.6 | +0.0 | 0.0 | 113.3 |
| ONE FIGHT FORMULA | 9.5 | -158.4 | 67.7 | 160.2 | 5.5 | -103.3 | 0.0 | 147.4 |
| ONE OBJECTIVE FORMULA | 2.5 | -137.9 | 0.0 | 22.6 | 3.2 | +35.3 | 0.0 | 15.5 |
| ONE PROMISE A TARGET | - | - | - | - | 0.2 | -7.1 | 0.0 | 0.0 |
| ONE TARGET A SHOOTER | - | - | - | - | 34.8 | +919.7 | 0.0 | 602.7 |
| OPENS A LANE | 0.2 | +1.5 | 14.1 | 0.0 | 0.1 | +0.9 | 4.2 | 0.0 |
| OPENS UP | 0.1 | +11.8 | 4.3 | 10.2 | 0.2 | +8.5 | 16.4 | 0.0 |
| OVERRUNS AWAY | 0.4 | +19.4 | 46.6 | 30.8 | 0.6 | +16.0 | 54.2 | 13.7 |
| OWN CAST FIRST | - | - | - | - | 0.1 | -0.2 | 0.0 | 0.0 |
| PATHS CROSS | 1.5 | +76.6 | 0.0 | 20.4 | 0.4 | +33.3 | 0.0 | 3.3 |
| PERIAPT WORTH | 0.0 | +3.4 | 0.0 | 0.0 | 0.0 | +2.1 | 0.0 | 15.0 |
| PIVOT GUARDS FLANK | 0.1 | -6.2 | 0.0 | 0.0 | 0.1 | -0.3 | 0.0 | 1.9 |
| PLAN RESULT | 38.9 | +1404.8 | 1202.6 | 775.2 | 42.8 | +602.7 | 419.0 | 1024.5 |
| PROMISE BELOW ZERO | - | - | - | - | 0.3 | +0.0 | 0.0 | 28.4 |
| PROMISE BY ITS OWN SUM | - | - | - | - | 9.0 | -234.0 | 0.0 | 87.1 |
| PROMISE HOLDS THE SPOT | - | - | - | - | 0.0 | +2.9 | 0.0 | 0.0 |
| PROMISE IN STEPS | - | - | - | - | 0.1 | +0.0 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | - | - | - | - | 0.6 | -1.8 | 0.0 | 6.0 |
| PROMISE READS THE TABLE | - | - | - | - | 0.7 | -7.5 | 0.0 | 39.2 |
| PROMISE SHOT AWAY | - | - | - | - | 0.2 | -0.5 | 17.4 | 0.0 |
| PURSUES BIG PREY | 0.0 | -3.9 | 0.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | - | - | - | - | 7.8 | +1140.6 | 96.3 | 143.8 |
| RAIDS THE BAGGAGE NEXT TURN | 0.0 | +2.4 | 0.0 | 0.0 | - | - | - | - |
| RANDOM MOVE BY FIGURES | 0.6 | +5.0 | 0.0 | 28.1 | 1.6 | +41.7 | 0.0 | 23.3 |
| RANDOM MOVER NO PROMISE | 0.1 | -8.6 | 3.4 | 0.0 | - | - | - | - |
| REDIRECT BY WHAT IT STOPS | 0.6 | -14.0 | 0.0 | 23.2 | 1.6 | -18.1 | 0.0 | 26.6 |
| REDIRECT COUNTER | 2.4 | +161.9 | 0.0 | 59.3 | 3.6 | +216.9 | 0.0 | 36.8 |
| REDIRECT WEIGHED | 0.1 | -1.8 | 0.0 | 2.9 | 0.2 | +3.5 | 5.2 | 0.0 |
| REFORMS TO MEET IT | - | - | - | - | 1.6 | -29.9 | 0.0 | 21.8 |
| REFUSING RETIRES | 0.2 | +0.0 | 0.0 | 4.0 | 0.4 | +0.0 | 0.0 | 33.3 |
| RESERVE FALL BACK | 0.4 | +10.9 | 0.0 | 18.3 | 0.9 | +78.4 | 0.0 | 13.7 |
| RESTRAINS TO SHOOT | 0.1 | +3.8 | 0.0 | 4.0 | 0.1 | +0.3 | 0.0 | 0.0 |
| RISK BY ARC | 1.6 | +57.5 | 141.3 | 78.3 | 2.6 | +29.2 | 170.6 | 103.0 |
| RISK BY HIS FIGURE | - | - | - | - | 22.7 | -403.0 | 0.0 | 694.8 |
| RISK ONCE | 4.2 | +113.7 | 53.7 | 180.6 | - | - | - | - |
| ROUNDS AFTER TERROR | - | - | - | - | 1.5 | -35.1 | 115.7 | 26.3 |
| RUN DOWN | - | - | - | - | 2.6 | -23.8 | 173.6 | 41.0 |
| SAFER THAN THE JOB | 0.7 | +16.3 | 0.0 | 0.0 | 0.0 | +2.3 | 0.0 | 0.0 |
| SAME CHARGE LATER | - | - | - | - | 0.0 | -0.5 | 0.0 | 0.0 |
| SCOUT SPOT | 0.3 | +0.9 | 0.0 | 1.5 | 0.5 | +1.8 | 0.0 | 0.0 |
| SCOUT WAITS | 0.3 | +0.0 | 0.0 | 1.5 | 0.6 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.3 | -17.4 | 0.0 | 3.7 | 0.5 | -25.2 | 0.0 | 4.9 |
| SEARCH SPOT | 2.8 | +122.4 | 0.0 | 41.6 | 0.6 | +9.5 | 0.0 | 1.4 |
| SECOND LOOK | - | - | - | - | 0.2 | +16.0 | 19.6 | 5.2 |
| SELF MOVE SPELL | 0.3 | +15.6 | 0.0 | 0.0 | - | - | - | - |
| SET UP BY THE SET | - | - | - | - | 2.9 | +61.6 | 13.9 | 160.3 |
| SET UP TOGETHER | 0.7 | +82.4 | 9.6 | 40.1 | 0.4 | +4.0 | 0.0 | 6.5 |
| SET-UP ANY TARGET | 0.1 | +3.7 | 13.9 | 13.9 | 0.1 | +15.0 | 0.0 | 0.0 |
| SET-UP MISSED | - | - | - | - | 0.0 | +1.0 | 0.0 | 0.0 |
| SHOOTER COUNTED ONCE | 0.1 | -0.1 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | 0.4 | +0.7 | 0.0 | 0.0 | 0.4 | +0.8 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.7 | +49.6 | 95.8 | 9.8 | 1.3 | +36.5 | 52.8 | 10.3 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 6.9 | 0.2 | +0.0 | 0.0 | 0.0 |
| SHOT OR CHARGE | - | - | - | - | 0.4 | -32.4 | 37.5 | 2.9 |
| SHOT RISK POINTS | - | - | - | - | 21.9 | -79.7 | 0.0 | 572.5 |
| SHOTS AFTER THE MOVES | - | - | - | - | 2.4 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 15.4 | +638.6 | 0.0 | 219.9 | 13.9 | +393.0 | 0.0 | 271.6 |
| SPELL OFF EDGE | - | - | - | - | 0.0 | +5.1 | 7.9 | 0.0 |
| SPELL SETS UP CHARGE | 0.2 | +51.3 | 13.9 | 13.9 | 0.2 | +25.6 | 0.0 | 0.0 |
| SPELL WORTH | 0.9 | +14.6 | 38.9 | 33.5 | 1.6 | +19.4 | 61.3 | 61.3 |
| SPELLS IN THE FIGHT | 0.2 | +0.4 | 24.2 | 0.0 | 0.6 | -5.1 | 48.1 | 46.1 |
| SPOT AS THE GAME MOVES | - | - | - | - | 9.0 | +0.0 | 0.0 | 204.7 |
| STABLE ROLE | 12.4 | +0.0 | 275.1 | 185.5 | - | - | - | - |
| STAND AND SHOOT | - | - | - | - | 0.5 | -11.2 | 60.9 | 7.9 |
| STANDS FOR A REASON | - | - | - | - | 1.9 | +0.0 | 17.9 | 52.6 |
| STANDS STILL | - | - | - | - | 28.8 | +0.0 | 843.5 | 280.2 |
| STANDS TO CAST | 0.0 | +1.9 | 5.4 | 0.0 | - | - | - | - |
| STAY WEIGHED | 0.2 | +7.2 | 0.0 | 0.0 | - | - | - | - |
| STAY WORTH | 19.8 | +85.3 | 476.3 | 201.6 | 18.6 | +122.1 | 548.6 | 251.4 |
| STOPS | 0.1 | +0.9 | 6.2 | 1.4 | 0.1 | +7.9 | 8.1 | 0.9 |
| STOPS SHORT OF THE FLANK | 0.3 | +10.4 | 0.0 | 0.0 | - | - | - | - |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 4.7 | 0.2 | +0.0 | 0.0 | 0.0 |
| STUPIDITY NEXT TURN | - | - | - | - | 0.4 | +0.0 | 0.0 | 0.0 |
| SUPPORT NARROWED | 5.5 | -46.0 | 224.0 | 62.3 | 0.4 | +0.0 | 10.5 | 5.2 |
| SUPPORT WORKED OUT | - | - | - | - | 6.2 | +324.7 | 0.0 | 44.4 |
| SUPPORTS | 4.0 | +51.0 | 90.1 | 29.6 | - | - | - | - |
| SURE CHARGE BEATS ADVANCE | 0.0 | -0.8 | 6.6 | 7.9 | - | - | - | - |
| SURE REACH TOGETHER | 0.4 | -3.3 | 9.6 | 15.3 | 0.4 | +2.9 | 0.0 | 4.4 |
| THE DEARER SUM KEEPS ITS PLAN | - | - | - | - | 1.8 | +0.0 | 0.0 | 33.4 |
| THE PROMISE ADDS | - | - | - | - | 0.2 | -7.4 | 0.0 | 0.0 |
| THE TABLE AGAIN | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | - | - | - | - | 34.3 | +0.0 | 0.0 | 543.7 |
| THROUGH LINE OF FIRE | 0.2 | +11.0 | 0.0 | 0.0 | - | - | - | - |
| TIED UP BY THE SUM | - | - | - | - | 0.5 | +56.6 | 38.8 | 8.1 |
| TIME ON OUR SIDE | - | - | - | - | 13.9 | +140.6 | 3.1 | 162.4 |
| TURN WORTH | 0.2 | -12.6 | 22.4 | 12.4 | - | - | - | - |
| TWO OR MORE ARRIVE | 0.2 | +4.1 | 9.6 | 13.9 | - | - | - | - |
| WAIT AFTER COSTS | 7.7 | -331.1 | 221.4 | 141.9 | - | - | - | - |
| WAITS AGAIN | - | - | - | - | 1.2 | +0.0 | 0.0 | 18.6 |
| WALKS TO THE FIGHT | 2.4 | +17.7 | 33.1 | 19.7 | - | - | - | - |
| WAR ENGINE CHARGES | 0.1 | +10.2 | 14.7 | 0.0 | 0.0 | +2.1 | 3.5 | 0.0 |
| WAR ENGINE JOBS | 0.9 | +0.0 | 35.1 | 22.9 | 0.2 | +0.0 | 10.7 | 0.0 |
| WEARS DOWN | 0.9 | +22.2 | 79.9 | 33.6 | - | - | - | - |
| WHAT THE JOINER ADDS | - | - | - | - | 0.3 | -1.2 | 1.9 | 12.8 |
| WHO GETS IN | - | - | - | - | 0.1 | +3.3 | 0.0 | 5.2 |
| WHO HITS BACK | 0.3 | +26.0 | 0.0 | 29.6 | 0.2 | +26.0 | 0.0 | 10.3 |
| WHOLE FIGHT | 0.1 | +2.2 | 5.1 | 4.2 | 0.2 | +1.1 | 0.9 | 6.4 |
| WHOLE FIGHT GAIN | 0.2 | +14.9 | 30.4 | 1.2 | 0.2 | +11.0 | 8.2 | 2.9 |
| WIDER SPREAD | 1.6 | -2.9 | 139.7 | 20.4 | 2.8 | -1.8 | 195.1 | 97.0 |
| WOUNDED STAYS OUT | - | - | - | - | 0.1 | +0.0 | 15.1 | 0.0 |
| WOUNDS ON THE RANKS | - | - | - | - | 2.0 | +119.8 | 0.0 | 10.3 |

### Rule changes: hmw-opp-c1e47a9-p2

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 782 | 782 | 782 | 21.72 | -32386 | -41.4 |
| HIS MOVE AS HE DECIDES | 1180 | 1180 | 742 | 20.61 | +0 | +0.0 |
| HIS MOVE WHY | 1197 | 1197 | 636 | 17.67 | +0 | +0.0 |
| ARMY TABLE | 748 | 748 | 580 | 16.11 | +9712 | +16.7 |
| HIS SHOT LIST | 1666 | 1592 | 499 | 13.86 | +9034 | +18.1 |
| HOLDER ASSIGNMENT | 408 | 408 | 386 | 10.72 | +22323 | +57.8 |
| DEPLOY BY FIGURES | 578 | 578 | 351 | 9.75 | +5088 | +14.5 |
| ONE TARGET A SHOOTER | 1251 | 1198 | 305 | 8.47 | +3040 | +10.0 |
| LEGAL CHARGES ONLY | 206 | 206 | 206 | 5.72 | +0 | +0.0 |
| FIVE ACTION | 3177 | 3065 | 183 | 5.08 | +8958 | +49.0 |
| SHOT RISK POINTS | 790 | 752 | 162 | 4.50 | +3445 | +21.3 |
| THE TABLE AGAIN | 216 | 216 | 159 | 4.42 | +0 | +0.0 |
| MOVE TO CHARGE COMPUTED | 282 | 250 | 141 | 3.92 | +6157 | +43.7 |
| HIS ONE MOVE | 660 | 643 | 137 | 3.81 | +0 | +0.0 |
| MOVE ORDER | 121 | 121 | 121 | 3.36 | +0 | +0.0 |
| PROMISE BY ITS OWN SUM | 323 | 323 | 115 | 3.19 | -8424 | -73.3 |
| SEARCH SPOT | 120 | 120 | 112 | 3.11 | +4761 | +42.5 |
| SHOTS IN THE MOVE | 1057 | 839 | 111 | 3.08 | +4117 | +37.1 |
| SUPPORT WORKED OUT | 222 | 212 | 86 | 2.39 | +1975 | +23.0 |
| ARTILLERY RE-ROLL WEIGHED | 81 | 81 | 81 | 2.25 | +0 | +0.0 |
| ADVANCE LANE KEPT | 75 | 75 | 75 | 2.08 | +0 | +0.0 |
| IDLE COST | 1011 | 652 | 75 | 2.08 | +699 | +9.3 |
| TIME ON OUR SIDE | 502 | 461 | 75 | 2.08 | +142 | +1.9 |
| COVER ONCE | 449 | 291 | 71 | 1.97 | +1573 | +22.2 |
| MOVE TO CHARGE | 120 | 120 | 71 | 1.97 | +3403 | +47.9 |
| PATHS CROSS | 68 | 68 | 68 | 1.89 | +3959 | +58.2 |
| STAY WORTH | 1380 | 1240 | 66 | 1.83 | +463 | +7.0 |
| CHAFF IN THE MOVE | 94 | 92 | 65 | 1.81 | +922 | +14.2 |
| FOUR ROUNDS | 145 | 140 | 64 | 1.78 | +2269 | +35.5 |
| BEST FIRST | 62 | 62 | 62 | 1.72 | +3210 | +51.8 |
| SUPPORTS | 145 | 145 | 61 | 1.69 | +654 | +10.7 |
| WAIT AFTER COSTS | 276 | 276 | 61 | 1.69 | +1117 | +18.3 |
| KILLS COUNT NEXT TURN | 170 | 170 | 57 | 1.58 | +1176 | +20.6 |
| HARD STAY DROPPED | 56 | 56 | 56 | 1.56 | +0 | +0.0 |
| LANE BY FIGURES | 56 | 56 | 56 | 1.56 | +2664 | +47.6 |
| SHOOTS FROM THE BEST SPOT | 108 | 108 | 56 | 1.56 | +662 | +11.8 |
| CANNON SIGHT KEPT | 55 | 55 | 55 | 1.53 | +0 | +0.0 |
| ADVANCE WORTH | 221 | 221 | 53 | 1.47 | +809 | +15.3 |
| FACES THE THREAT | 50 | 50 | 50 | 1.39 | +3213 | +64.3 |
| MAX FOR POSITIONING | 309 | 209 | 49 | 1.36 | +248 | +5.1 |
| REDIRECT COUNTER | 215 | 155 | 49 | 1.36 | +2807 | +57.3 |
| ONE FIGHT FORMULA | 540 | 319 | 47 | 1.31 | +214 | +4.5 |
| RESERVE FALL BACK | 47 | 47 | 47 | 1.31 | +3217 | +68.4 |
| QUARTER ODDS | 279 | 268 | 44 | 1.22 | +5242 | +119.1 |
| BEST MOVE FOR SHOOTERS | 42 | 42 | 42 | 1.17 | +2394 | +57.0 |
| RANDOM MOVE BY FIGURES | 79 | 79 | 42 | 1.17 | +1679 | +40.0 |
| CANNON PLANNED TARGET | 317 | 317 | 40 | 1.11 | +49 | +1.2 |
| HOLDS AMBUSHERS | 40 | 40 | 40 | 1.11 | +0 | +0.0 |
| RISK BY ARC | 151 | 150 | 40 | 1.11 | +996 | +24.9 |
| FOLLOW UP WEIGHED | 39 | 39 | 39 | 1.08 | +4841 | +124.1 |
| JOINT CHARGE NOW | 39 | 39 | 39 | 1.08 | +1167 | +29.9 |
| MISSILES IN THE MOVE | 270 | 178 | 39 | 1.08 | +668 | +17.1 |
| SET UP BY THE SET | 105 | 103 | 38 | 1.06 | +2889 | +76.0 |
| CHARGE NOW FIRST | 147 | 147 | 33 | 0.92 | -1952 | -59.2 |
| FALLS SHORT | 544 | 485 | 33 | 0.92 | +238 | +7.2 |
| LONE WIZARD KEPT IN | 33 | 33 | 33 | 0.92 | +2288 | +69.3 |
| WALKS TO THE FIGHT | 86 | 86 | 33 | 0.92 | +195 | +5.9 |
| SCOUT WAITS | 32 | 32 | 32 | 0.89 | +0 | +0.0 |
| RISK ONCE | 152 | 99 | 30 | 0.83 | +615 | +20.5 |
| MARCH CHECK | 37 | 37 | 29 | 0.81 | +734 | +25.3 |
| CHARGE LOSSES | 377 | 350 | 27 | 0.75 | +2114 | +78.3 |
| SHOOTERS IN TWO RANKS | 26 | 26 | 26 | 0.72 | +54 | +2.1 |
| FALLBACK BY WORTH | 154 | 154 | 25 | 0.69 | +1428 | +57.1 |
| SAFER THAN THE JOB | 25 | 25 | 25 | 0.69 | +670 | +26.8 |
| CAST JOB | 50 | 50 | 23 | 0.64 | +286 | +12.4 |
| FIRE IN ORDER | 23 | 23 | 23 | 0.64 | +0 | +0.0 |
| INVITES THE FIGHT | 49 | 49 | 23 | 0.64 | +116 | +5.1 |
| MODEL FACING | 23 | 23 | 23 | 0.64 | +4230 | +183.9 |
| RISK BY HIS FIGURE | 818 | 782 | 23 | 0.64 | +1802 | +78.4 |
| COMBAT PIVOT | 20 | 20 | 20 | 0.56 | +0 | +0.0 |
| NEXT CHARGE BY LIST | 246 | 229 | 20 | 0.56 | +211 | +10.6 |
| HOLDER AT DEPLOYMENT | 37 | 37 | 19 | 0.53 | +1023 | +53.8 |
| WHO HITS BACK | 19 | 19 | 19 | 0.53 | +1254 | +66.0 |
| CASTING BLOCK | 29 | 29 | 18 | 0.50 | +477 | +26.5 |
| CHARGE NOW WEIGHED | 17 | 17 | 17 | 0.47 | +1171 | +68.9 |
| TIED UP BY THE SUM | 19 | 19 | 17 | 0.47 | +608 | +35.8 |
| SET UP TOGETHER | 38 | 31 | 16 | 0.44 | +1404 | +87.8 |
| BEST FACING | 15 | 15 | 15 | 0.42 | +592 | +39.5 |
| CASTS FROM BEHIND | 15 | 15 | 15 | 0.42 | +0 | +0.0 |
| CHAFF PASSED | 15 | 15 | 15 | 0.42 | -27 | -1.8 |
| HIS TURN DENIED | 58 | 58 | 15 | 0.42 | +490 | +32.6 |
| REFUSING RETIRES | 22 | 22 | 15 | 0.42 | +1 | +0.0 |
| BEST PREY | 33 | 33 | 14 | 0.39 | +329 | +23.5 |
| CASTER AWAY FROM SCREEN | 14 | 14 | 14 | 0.39 | +0 | +0.0 |
| HONEST WORTH | 419 | 414 | 14 | 0.39 | +159 | +11.4 |
| KILLS COUNT | 34 | 34 | 14 | 0.39 | +693 | +49.5 |
| MARCH ODDS | 14 | 14 | 14 | 0.39 | +58 | +4.1 |
| SHORT GUN FORWARD | 14 | 14 | 14 | 0.39 | +0 | +0.0 |
| WAR ENGINE JOBS | 40 | 40 | 12 | 0.33 | -499 | -41.6 |
| FRIENDS SHOTS CHECKED | 11 | 11 | 11 | 0.31 | +795 | +72.3 |
| HIS CHARGE DENIED | 29 | 28 | 11 | 0.31 | +180 | +16.4 |
| MISSILES NEXT TURN | 329 | 219 | 11 | 0.31 | +16 | +1.5 |
| MOVE AND CAST | 11 | 11 | 11 | 0.31 | +303 | +27.6 |
| SHOTS AFTER THE MOVES | 86 | 86 | 11 | 0.31 | +0 | +0.0 |
| STOPS SHORT OF THE FLANK | 11 | 11 | 11 | 0.31 | +373 | +33.9 |
| WHOLE FIGHT GAIN | 18 | 18 | 11 | 0.31 | +313 | +28.5 |
| BEST OVERALL | 10 | 10 | 10 | 0.28 | +322 | +32.2 |
| KEEPS ITS TARGET | 54 | 54 | 10 | 0.28 | +184 | +18.4 |
| NEARER NOT NEEDED | 210 | 207 | 10 | 0.28 | +401 | +40.1 |
| WOUNDS ON THE RANKS | 72 | 69 | 10 | 0.28 | +557 | +55.7 |
| MANOEUVRE | 30 | 30 | 9 | 0.25 | +106 | +11.8 |
| REDIRECT WEIGHED | 9 | 9 | 9 | 0.25 | +545 | +60.5 |
| STUCK PIVOT | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| THROUGH LINE OF FIRE | 9 | 9 | 9 | 0.25 | +397 | +44.2 |
| CHARGE NOT DECLARED | 8 | 8 | 8 | 0.22 | -388 | -48.4 |
| FIGHT TO THE END | 42 | 41 | 8 | 0.22 | +146 | +18.2 |
| ONE PROMISE A TARGET | 8 | 8 | 8 | 0.22 | -257 | -32.1 |
| OVERRUNS AWAY | 36 | 36 | 8 | 0.22 | +340 | +42.5 |
| SURE REACH TOGETHER | 27 | 24 | 8 | 0.22 | +13 | +1.7 |
| BLOCKED WHEEL | 7 | 7 | 7 | 0.19 | +70 | +10.0 |
| PIVOT GUARDS FLANK | 7 | 7 | 7 | 0.19 | -235 | -33.5 |
| PROMISE SHOT AWAY | 7 | 7 | 7 | 0.19 | -19 | -2.7 |
| WEARS DOWN | 31 | 31 | 7 | 0.19 | +175 | +25.0 |
| HIS MOVE AND SHOT | 140 | 134 | 6 | 0.17 | +78 | +13.0 |
| ONE OBJECTIVE FORMULA | 205 | 153 | 6 | 0.17 | +193 | +32.1 |
| OPENS UP | 10 | 9 | 6 | 0.17 | +323 | +53.9 |
| RESTRAINS TO SHOOT | 6 | 6 | 6 | 0.17 | +149 | +24.9 |
| SECOND LOOK | 6 | 6 | 6 | 0.17 | +576 | +95.9 |
| STAY WEIGHED | 6 | 6 | 6 | 0.17 | +261 | +43.5 |
| SUPPORT NARROWED | 210 | 210 | 6 | 0.17 | -102 | -17.0 |
| AFTERMATH IN POINTS | 5 | 5 | 5 | 0.14 | +1511 | +302.2 |
| BOMBING RUN | 5 | 5 | 5 | 0.14 | +139 | +27.7 |
| PROMISE READS THE TABLE | 24 | 24 | 5 | 0.14 | +53 | +10.7 |
| BEST PRIZE | 4 | 4 | 4 | 0.11 | -740 | -184.9 |
| BIG CHARACTER SAFETY | 4 | 4 | 4 | 0.11 | -0 | -0.1 |
| BOUND ASSAILMENT | 4 | 4 | 4 | 0.11 | +1 | +0.2 |
| EDGE GIVE GROUND | 21 | 20 | 4 | 0.11 | +36 | +8.9 |
| HIS FIGHT TOGETHER | 73 | 70 | 4 | 0.11 | +32 | +8.1 |
| HUNT IN PAIRS | 14 | 9 | 4 | 0.11 | +220 | +55.1 |
| KEEP FALLS | 4 | 4 | 4 | 0.11 | +238 | +59.5 |
| KEEPS SCOUTS OR AMBUSH | 4 | 4 | 4 | 0.11 | +0 | +0.0 |
| LOST CHARGE | 79 | 79 | 4 | 0.11 | +32 | +8.0 |
| MAKE SURE TOGETHER | 17 | 7 | 4 | 0.11 | +454 | +113.4 |
| MARCH BY THE SUM | 4 | 4 | 4 | 0.11 | +262 | +65.4 |
| MOVES UNITS SPELL | 4 | 4 | 4 | 0.11 | +122 | +30.4 |
| OPENS A LANE | 10 | 10 | 4 | 0.11 | +6 | +1.5 |
| REDIRECT BY WHAT IT STOPS | 82 | 82 | 4 | 0.11 | +24 | +6.0 |
| WHAT THE JOINER ADDS | 12 | 12 | 4 | 0.11 | +30 | +7.5 |
| BACKUP TARGETS | 36 | 17 | 3 | 0.08 | +1 | +0.5 |
| CONTINUE AHEAD WEIGHED | 3 | 3 | 3 | 0.08 | +0 | +0.0 |
| JOINT CHARGE PLAN | 4 | 4 | 3 | 0.08 | +94 | +31.2 |
| MARCH OF THE TABLE | 3 | 3 | 3 | 0.08 | -109 | -36.2 |
| WHOLE FIGHT | 8 | 8 | 3 | 0.08 | +77 | +25.8 |
| WIDER SPREAD | 155 | 152 | 3 | 0.08 | +11 | +3.6 |
| AFTERMATH WITH FRIENDS | 2 | 2 | 2 | 0.06 | +189 | +94.3 |
| BLOWS WHERE AIMED | 15 | 15 | 2 | 0.06 | +144 | +71.9 |
| DEFENSIVE ARMY | 6 | 6 | 2 | 0.06 | -14 | -7.1 |
| FALL BACK GOOD ORDER | 109 | 105 | 2 | 0.06 | +22 | +10.8 |
| GUN MASK | 11 | 10 | 2 | 0.06 | +9 | +4.7 |
| HILL BY ITS CHANCE | 16 | 16 | 2 | 0.06 | +115 | +57.4 |
| NO DOUBLE ROUNDS | 112 | 107 | 2 | 0.06 | +32 | +16.2 |
| OWN CAST FIRST | 2 | 2 | 2 | 0.06 | -7 | -3.3 |
| PERIAPT WORTH | 2 | 2 | 2 | 0.06 | +198 | +99.2 |
| PROMISE KNOWS THE FIGHT | 21 | 14 | 2 | 0.06 | -66 | -33.2 |
| REFORMS TO MEET IT | 56 | 52 | 2 | 0.06 | +1 | +0.3 |
| SCREEN BY WHAT IT SAVES | 28 | 28 | 2 | 0.06 | +0 | +0.0 |
| TWO OR MORE ARRIVE | 8 | 8 | 2 | 0.06 | +52 | +25.8 |
| WAR ENGINE CHARGES | 3 | 3 | 2 | 0.06 | +191 | +95.6 |
| WHO GETS IN | 2 | 2 | 2 | 0.06 | +120 | +59.8 |
| BLOCKED CHARGE SKIPPED | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| CARRIES OUT SET-UP | 4 | 4 | 1 | 0.03 | -4 | -4.3 |
| CHARGE LIST READ AGAIN | 1 | 1 | 1 | 0.03 | +21 | +20.7 |
| CHARIOT NO STATIC JOB | 1 | 1 | 1 | 0.03 | -52 | -52.5 |
| FOCUS FIRE | 1 | 1 | 1 | 0.03 | +54 | +54.2 |
| FRIEND SHOOTS FIRST | 34 | 33 | 1 | 0.03 | +3 | +3.1 |
| HUNT ADVANCE | 3 | 3 | 1 | 0.03 | +4 | +3.8 |
| JOINT ON THE TABLE | 1 | 1 | 1 | 0.03 | +123 | +122.9 |
| LONE WIZARD HOLDS BACK | 5 | 5 | 1 | 0.03 | +0 | +0.0 |
| MOVE SPELL IN RANGE | 2 | 2 | 1 | 0.03 | +33 | +32.8 |
| NO RALLY LEFT | 1 | 1 | 1 | 0.03 | +53 | +52.9 |
| PROMISE HOLDS THE SPOT | 1 | 1 | 1 | 0.03 | +106 | +106.0 |
| PURSUES BIG PREY | 1 | 1 | 1 | 0.03 | -139 | -139.2 |
| RAIDS THE BAGGAGE NEXT TURN | 1 | 1 | 1 | 0.03 | +73 | +73.1 |
| SPELLS IN THE FIGHT | 31 | 30 | 1 | 0.03 | +1 | +0.9 |
| STANDS TO CAST | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| SURE CHARGE BEATS ADVANCE | 1 | 1 | 1 | 0.03 | -30 | -29.9 |
| ALREADY CARRIED | 3 | not checked | - | - | - | - |
| ARRIVAL HUNT | 5 | 5 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 25 | 25 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 31 | trace | - | - | - | - |
| CATCH FLIERS | 1 | not checked | - | - | - | - |
| CHAMPION KNOWS CHALLENGE | 4 | 4 | 0 | 0.00 | - | - |
| CHAMPION TAKES THE CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| CHARACTER GUNS | 26 | 26 | 0 | 0.00 | - | - |
| CHARGER SLAIN LOST | 19 | 19 | 0 | 0.00 | - | - |
| CHARIOT WIZARD CAREFUL | 1 | 1 | 0 | 0.00 | - | - |
| CHEAP HELPER | 1 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 33 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 27 | 27 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 22 | 22 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 321 | not checked | - | - | - | - |
| FRIEND CHARGES FIRST | 1 | 1 | 0 | 0.00 | - | - |
| GIVES UP | 16 | 14 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 1 | 1 | 0 | 0.00 | - | - |
| GROUND FLIERS | 1 | not checked | - | - | - | - |
| GUN FIGURES | 65 | not checked | - | - | - | - |
| HE SHOOTS OR CHARGES | 129 | 126 | 0 | 0.00 | - | - |
| HELPER ALREADY ASKED | 1 | not checked | - | - | - | - |
| HELPER UNSEEN | 3 | 3 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 216 | 211 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 210 | 199 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 86 | 86 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 88 | 84 | 0 | 0.00 | - | - |
| HOLD ODDS | 401 | 399 | 0 | 0.00 | - | - |
| HUNT DROPPED | 2 | trace | - | - | - | - |
| HUNT KEPT | 1 | trace | - | - | - | - |
| HUNT RESULT | 6 | trace | - | - | - | - |
| HUNT THE GUNS | 6 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 3 | 3 | 0 | 0.00 | - | - |
| KEEPS ITS PREY | 4 | 4 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 5 | not checked | - | - | - | - |
| LONG SHOT | 25 | 25 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 74 | 72 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 9 | 9 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 6 | trace | - | - | - | - |
| MARCH OVER CASTS | 33 | 33 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 5 | 5 | 0 | 0.00 | - | - |
| MOVE SPELL NOT WORTH | 2 | not checked | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 22 | trace | - | - | - | - |
| MOVE SPELL SPOT | 11 | not checked | - | - | - | - |
| NEXT OBJECTIVE NEARER | 11 | 10 | 0 | 0.00 | - | - |
| NOT NEEDED | 6 | 6 | 0 | 0.00 | - | - |
| NOT TURNED | 181 | 181 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 46 | not checked | - | - | - | - |
| ONE CHARGE A CHARGER | 165 | 159 | 0 | 0.00 | - | - |
| PLAN RESULT | 2942 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 11 | 11 | 0 | 0.00 | - | - |
| PROMISE IN STEPS | 2 | 2 | 0 | 0.00 | - | - |
| RANDOM MOVER NO PROMISE | 5 | 5 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 55 | 52 | 0 | 0.00 | - | - |
| RUN DOWN | 95 | 92 | 0 | 0.00 | - | - |
| SAME CHARGE LATER | 1 | 1 | 0 | 0.00 | - | - |
| SCOUT SPOT | 28 | 28 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 12 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 8 | not checked | - | - | - | - |
| SET-UP MISSED | 1 | trace | - | - | - | - |
| SHOOTER COUNTED ONCE | 2 | 2 | 0 | 0.00 | - | - |
| SHOT OR CHARGE | 16 | 16 | 0 | 0.00 | - | - |
| SPELL OFF EDGE | 1 | not checked | - | - | - | - |
| SPELL SETS UP CHARGE | 13 | not checked | - | - | - | - |
| SPELL WORTH | 90 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 323 | 313 | 0 | 0.00 | - | - |
| STABLE ROLE | 447 | 447 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 18 | 18 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 70 | 63 | 0 | 0.00 | - | - |
| STANDS STILL | 1037 | 1006 | 0 | 0.00 | - | - |
| STOPS | 4 | 4 | 0 | 0.00 | - | - |
| STUPIDITY NEXT TURN | 16 | 14 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 63 | not checked | - | - | - | - |
| THE PROMISE ADDS | 7 | 7 | 0 | 0.00 | - | - |
| THE TABLE BINDS | 1236 | not checked | - | - | - | - |
| TURN WORTH | 7 | 7 | 0 | 0.00 | - | - |
| WAITS AGAIN | 45 | 40 | 0 | 0.00 | - | - |
| WOUNDED STAYS OUT | 3 | 3 | 0 | 0.00 | - | - |

### Off best figure: hmw-opp-c1e47a9-p2

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 16.50 | 3.28 | 42.7 |
| PROMISE BY ITS OWN SUM | rule | - | 3.19 | 73.3 |
| ARMY TABLE | rule | - | 1.97 | 42.1 |
| HOLDER ASSIGNMENT | rule | - | 1.19 | 18.5 |
| CHARGE NOW FIRST | rule | 0.44 | 0.47 | 59.2 |
| NO REASON | gate | - | 0.67 | 30.5 |
| FALLBACK | gate | 0.50 | - | 37.8 |
| JOINT CHARGE NOW | rule | - | 0.33 | 38.9 |
| WAR ENGINE JOBS | rule | 0.28 | 0.06 | 41.6 |
| CANNON PLANNED TARGET | rule | 0.25 | - | 9.4 |
| TURN GATE | gate | 0.22 | 0.03 | 10.5 |
| AFTERMATH BAND | gate | 0.08 | 0.14 | 2.7 |
| CHAFF PASSED | rule | 0.14 | 0.08 | 3.3 |
| ONE PROMISE A TARGET | rule | - | 0.22 | 32.1 |
| PIVOT GUARDS FLANK | rule | 0.14 | 0.06 | 33.5 |
| CHARGE NOT DECLARED | rule | 0.08 | 0.08 | 67.7 |
| RULE SWITCHED OFF | gate | 0.17 | - | 23.4 |
| SUPPORT NARROWED | rule | 0.06 | 0.11 | 17.0 |
| BEST PRIZE | rule | 0.06 | 0.06 | 184.9 |
| AFTERMATH NEEDS NEXT CHARGE | gate | - | 0.08 | 103.9 |
| MARCH OF THE TABLE | rule | - | 0.08 | 36.2 |
| PROMISE SHOT AWAY | rule | - | 0.08 | 5.9 |
| BIG CHARACTER SAFETY | rule | 0.06 | - | 2.4 |
| DEFENSIVE ARMY | rule | 0.06 | - | 7.1 |
| DEPLOY BY FIGURES | rule | 0.03 | 0.03 | 5.9 |
| FIGHT ORDER BAND | gate | 0.03 | 0.03 | 2.4 |
| FRIENDS SHOTS CHECKED | rule | 0.03 | 0.03 | 2.9 |
| OWN CAST FIRST | rule | - | 0.06 | 3.3 |
| PROMISE KNOWS THE FIGHT | rule | - | 0.06 | 33.2 |
| REFUSING RETIRES | rule | 0.06 | - | 0.6 |
| SET UP BY THE SET | rule | - | 0.06 | 18.0 |
| CARRIES OUT SET-UP | rule | - | 0.03 | 4.3 |
| CHARIOT NO STATIC JOB | rule | 0.03 | - | 52.5 |
| MARCH ODDS | rule | 0.03 | - | 0.7 |
| PATHS CROSS | rule | - | 0.03 | 109.9 |
| PROMISE READS THE TABLE | rule | - | 0.03 | 0.8 |
| PURSUES BIG PREY | rule | 0.03 | - | 139.2 |
| SAFER THAN THE JOB | rule | 0.03 | - | 0.7 |
| STOPS SHORT OF THE FLANK | rule | 0.03 | - | 4.0 |
| SURE CHARGE BEATS ADVANCE | rule | 0.03 | - | 29.9 |
| WHO GETS IN | rule | - | 0.03 | 17.6 |
| WHO HITS BACK | rule | - | 0.03 | 1.4 |

### Plans: hmw-opp-c1e47a9-p2

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 10.5 | 13% | 194 | 236 | 122% |
| Mine | charge | 2.0 | 68% | 180 | 228 | 126% |
| Mine | close in | 5.2 | 23% | 295 | 135 | 46% |
| Mine | hold | 5.7 | 41% | 371 | 0 | 0% |
| Mine | join | 0.3 | 92% | 14 | 0 | 0% |
| Mine | shoot | 10.4 | 64% | 329 | 805 | 244% |
| Mine | support | 4.8 | 89% | 42 | 0 | 0% |
| Opponent | charge | 3.2 | 59% | 413 | 237 | 57% |
| Opponent | join | 1.1 | 100% | 38 | 0 | 0% |
| Opponent | move | 32.4 | 93% | 1525 | 0 | 0% |
| Opponent | shoot | 5.1 | 70% | 248 | 366 | 148% |
| Opponent | support | 1.1 | 82% | 16 | 0 | 0% |

### Packages: hunt the guns, hmw-opp-c1e47a9-p2

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.1 | 4 | 0 | 50% | 50% | 0% | 2.5 | 199 | 74 | 25% | 33 |
| Opponent | 0.1 | 2 | 0 | 100% | 100% | 0% | 2.0 | 377 | 297 | 50% | 105 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 1.0 | 4 | 0 | 50% | 50% | 0% | 2.5 | 199 | 74 | 25% | 101 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 78 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 37 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 49 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 164 |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 454 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Ogre Kingdoms | 0.2 | 1 | 0 | 100% | 100% | 0% | 2.0 | 505 | 429 | 100% | 184 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Tomb Kings of Khemri | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 39 |
| Vampire Counts | 0.1 | 1 | 0 | 100% | 100% | 0% | 2.0 | 248 | 165 | 0% | 13 |
| Warriors of Chaos | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 20 |
| Wood Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 86 |

### Battle groups: hmw-opp-c1e47a9-p2

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 2.4 | 33% | 54% | 4% | 100% | 4% | 0% | 7% | 89% | 0% |
| Opponent | REDIRECT COUNTER | 3.6 | 20% | 85% | 12% | 33% | 48% | 4% | 4% | 43% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: hmw-opp-c1e47a9-p2

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 5 | 22 (5) | 22 | 0 | 52 | 20% | 2.8 | 0 (1) | 70 (1) | - | 0 (1) | 70 (1) |
| Mine | Chaff | 34 | 65 (34) | 15 | 49 | 49 | 26% | 3.3 | 93 (16) | 52 (13) | 0 (5) | 63 (25) | 68 (9) |
| Mine | Character | 123 | 39 (123) | 39 | 0 | 18 | 28% | 2.3 | 51 (46) | 36 (47) | 15 (21) | 51 (71) | 21 (43) |
| Mine | Clean-up | 19 | 48 (19) | 9 | 38 | 42 | 58% | 1.8 | 103 (4) | 0 (11) | 115 (4) | 87 (12) | 0 (7) |
| Mine | Fast | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | 0 (1) | - | - | 0 (1) | - |
| Mine | Fast Hammer | 49 | 43 (49) | 24 | 19 | 46 | 29% | 2.5 | 54 (22) | 35 (20) | 21 (7) | 46 (30) | 37 (19) |
| Mine | Hammer | 58 | 27 (58) | 20 | 7 | 21 | 29% | 2.5 | 19 (14) | 35 (28) | 22 (16) | 31 (35) | 23 (23) |
| Mine | Holder | 29 | 42 (29) | 5 | 37 | 18 | 55% | 3.5 | 29 (12) | 46 (12) | 59 (5) | 51 (19) | 24 (10) |
| Mine | Shooter | 45 | 93 (45) | 51 | 42 | 19 | 2% | 1.7 | 84 (11) | 118 (25) | 23 (9) | 107 (32) | 60 (13) |
| Mine | Support | 2 | 0 (2) | 0 | 0 | 0 | 0% | 6.0 | - | 0 (2) | - | - | 0 (2) |
| Mine | War machine | 59 | 53 (59) | 53 | 0 | 46 | 3% | 1.2 | 19 (25) | 48 (21) | 118 (13) | 72 (12) | 48 (47) |
| Mine | Wizard | 22 | 5 (22) | 5 | 0 | 29 | 14% | 2.3 | 1 (12) | 0 (5) | 0 (2) | 2 (11) | 0 (8) |
| Opponent | Blocker | 2 | 0 (2) | 0 | 0 | 0 | 50% | 5.0 | - | 0 (2) | - | 0 (1) | 0 (1) |
| Opponent | Chaff | 76 | 78 (76) | 12 | 66 | 49 | 43% | 2.9 | 58 (29) | 105 (20) | 75 (27) | 83 (66) | 51 (10) |
| Opponent | Character | 97 | 38 (97) | 38 | 0 | 38 | 28% | 2.4 | 34 (38) | 41 (46) | 56 (7) | 36 (59) | 44 (32) |
| Opponent | Clean-up | 17 | 22 (17) | 22 | 0 | 43 | 47% | 1.9 | 0 (8) | 55 (9) | - | 25 (14) | 0 (3) |
| Opponent | Early | 2 | 0 (2) | 0 | 0 | 0 | 100% | - | - | 0 (2) | - | - | 0 (2) |
| Opponent | Fast Hammer | 50 | 24 (50) | 13 | 11 | 31 | 26% | 2.4 | 26 (17) | 21 (25) | 30 (8) | 23 (28) | 26 (22) |
| Opponent | Fragile | 3 | 0 (3) | 0 | 0 | 29 | 67% | 1.0 | - | 0 (1) | 0 (2) | - | 0 (3) |
| Opponent | Hammer | 70 | 37 (70) | 25 | 12 | 37 | 39% | 2.7 | 31 (24) | 42 (36) | 29 (10) | 49 (40) | 23 (30) |
| Opponent | Holder | 34 | 61 (34) | 2 | 59 | 20 | 44% | 2.8 | 62 (8) | 69 (18) | 37 (8) | 84 (16) | 37 (18) |
| Opponent | Shooter | 36 | 71 (36) | 12 | 59 | 29 | 0% | 1.7 | 21 (13) | 121 (15) | 63 (8) | 80 (23) | 59 (13) |
| Opponent | Support | 3 | 0 (3) | 0 | 0 | 0 | 100% | - | 0 (2) | 0 (1) | - | - | 0 (3) |
| Opponent | War machine | 24 | 42 (24) | 42 | 0 | 39 | 4% | 1.4 | 73 (11) | 0 (5) | 23 (8) | 0 (3) | 48 (21) |
| Opponent | Wizard | 26 | 6 (26) | 6 | 0 | 43 | 8% | 2.1 | 0 (11) | 12 (9) | 0 (1) | 11 (10) | 0 (11) |

### Charged fights: hmw-opp-c1e47a9-p2

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 41 | 56 | 1.0 | 1.0 | 56 | 21 | +35 | 1 of 4 | 2 of 4 | - | +35 |
| Mine | Chaos Dwarfs | 4 | 140 | 427 | 1.2 | 1.2 | 341 | 0 | +341 | 3 of 5 | 2 of 5 | +265 | +360 |
| Mine | Dwarfen Mountain Holds | 4 | 566 | 42 | 1.2 | 1.4 | 33 | 12 | +21 | 0 of 5 | 4 of 5 | -30 | +56 |
| Mine | Empire of Man | 5 | 311 | 70 | 1.2 | 1.2 | 58 | 47 | +12 | 4 of 6 | 4 of 6 | +0 | +14 |
| Mine | Grand Cathay | 4 | 452 | 97 | 1.5 | 1.5 | 65 | 0 | +65 | 1 of 6 | 5 of 6 | +130 | +0 |
| Mine | High Elf Realms | 4 | 188 | 743 | 4.0 | 1.1 | 186 | 37 | +148 | 6 of 16 | 13 of 16 | +250 | +142 |
| Mine | Kingdom of Bretonnia | 1 | 0 | 205 | 2.0 | 1.0 | 102 | 0 | +102 | 0 of 2 | 1 of 2 | - | +102 |
| Mine | Lizardmen | 1 | 45 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Mine | Ogre Kingdoms | 1 | 311 | 556 | 5.0 | 1.6 | 111 | 7 | +104 | 0 of 5 | 4 of 4 | +108 | +102 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 453 | 7.0 | 1.0 | 65 | 16 | +49 | 2 of 7 | 7 of 7 | - | +49 |
| Mine | Skaven | 2 | 58 | 61 | 2.5 | 1.8 | 24 | 0 | +24 | 0 of 5 | 4 of 5 | +41 | +0 |
| Mine | Tomb Kings of Khemri | 1 | 388 | 511 | 4.0 | 1.0 | 128 | 0 | +128 | 1 of 4 | 4 of 4 | - | +128 |
| Mine | Vampire Counts | 3 | 0 | 211 | 2.3 | 1.3 | 91 | 6 | +84 | 2 of 7 | 5 of 7 | +294 | +0 |
| Mine | Warriors of Chaos | 1 | 0 | 236 | 2.0 | 1.0 | 118 | 0 | +118 | 1 of 2 | 1 of 2 | - | +118 |
| **Mine** | all armies | 36 | 221 | 237 | 2.1 | 1.2 | 115 | 16 | +99 | 21 of 74 | 56 of 73 | +118 | +94 |
| Opponent | Dwarfen Mountain Holds | 2 | 355 | 70 | 1.0 | 1.0 | 70 | 0 | +70 | 0 of 2 | 2 of 2 | - | +70 |
| Opponent | Empire of Man | 2 | 445 | 370 | 2.5 | 1.2 | 148 | 0 | +148 | 2 of 5 | 5 of 5 | +0 | +185 |
| Opponent | Grand Cathay | 2 | 320 | 186 | 2.0 | 1.2 | 93 | 146 | -53 | 2 of 4 | 3 of 4 | -103 | -37 |
| Opponent | Kingdom of Bretonnia | 1 | 105 | 60 | 1.0 | 1.0 | 60 | 0 | +60 | 0 of 1 | 0 of 1 | - | +60 |
| Opponent | Ogre Kingdoms | 3 | 381 | 57 | 1.7 | 1.0 | 34 | 14 | +20 | 2 of 5 | 1 of 5 | - | +20 |
| Opponent | Skaven | 1 | 0 | 0 | 3.0 | 1.0 | 0 | 70 | -70 | 1 of 3 | 0 of 2 | - | -70 |
| Opponent | Tomb Kings of Khemri | 4 | 0 | 524 | 3.5 | 1.0 | 150 | 33 | +117 | 5 of 14 | 12 of 14 | - | +117 |
| Opponent | Vampire Counts | 6 | 0 | 337 | 4.3 | 1.2 | 78 | 24 | +54 | 15 of 26 | 18 of 26 | +34 | +57 |
| Opponent | Warriors of Chaos | 8 | 8 | 166 | 1.6 | 1.2 | 102 | 70 | +33 | 6 of 13 | 10 of 13 | +41 | +31 |
| Opponent | Wood Elf Realms | 7 | 109 | 243 | 2.9 | 1.0 | 85 | 57 | +28 | 8 of 20 | 11 of 20 | - | +28 |
| **Opponent** | all armies | 36 | 120 | 240 | 2.6 | 1.1 | 93 | 43 | +50 | 41 of 93 | 62 of 92 | +14 | +53 |

### Effective charges: hmw-opp-c1e47a9-p2

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 0 | 0 | 1 (net +105) | 3 (net +12) | 0 | 0 | 0 | 25% (1 of 4) |
| Mine | Chaos Dwarfs | 5 | 3 (net +481) | 0 | 0 | 0 | 0 | 2 (net +132) | 0 | 0% (0 of 5) |
| Mine | Dwarfen Mountain Holds | 5 | 0 | 0 | 1 (net +0) | 1 (net -60) | 0 | 3 (net +56) | 0 | 20% (1 of 5) |
| Mine | Empire of Man | 6 | 1 (net +69) | 0 | 3 (net +0) | 1 (net +0) | 1 (net +0) | 0 | 0 | 50% (3 of 6) |
| Mine | Grand Cathay | 6 | 1 (net +0) | 0 | 0 | 0 | 3 (net +20) | 1 (net +329) | 1 | 0% (0 of 5) |
| Mine | High Elf Realms | 16 | 1 (net +599) | 1 (net -597) | 2 (net +185) | 3 (net +313) | 5 (net +128) | 4 (net +106) | 0 | 12% (2 of 16) |
| Mine | Kingdom of Bretonnia | 2 | 0 | 0 | 1 (net +205) | 1 (net +0) | 0 | 0 | 0 | 50% (1 of 2) |
| Mine | Ogre Kingdoms | 5 | 1 (net +0) | 0 | 0 | 0 | 2 (net +168) | 1 (net +186) | 1 | 0% (0 of 4) |
| Mine | Orc & Goblin Tribes | 7 | 1 (net +233) | 0 | 0 | 1 (net +0) | 0 | 0 | 5 | 0% (0 of 2) |
| Mine | Skaven | 5 | 1 (net +0) | 0 | 0 | 3 (net +0) | 1 (net +122) | 0 | 0 | 0% (0 of 5) |
| Mine | Tomb Kings of Khemri | 4 | 0 | 0 | 0 | 0 | 1 (net +102) | 3 (net +136) | 0 | 0% (0 of 4) |
| Mine | Vampire Counts | 7 | 2 (net +0) | 1 (net +0) | 0 | 0 | 2 (net +48) | 2 (net +247) | 0 | 0% (0 of 7) |
| Mine | Warriors of Chaos | 2 | 0 | 0 | 1 (net +0) | 0 | 0 | 1 (net +236) | 0 | 50% (1 of 2) |
| Opponent | Dwarfen Mountain Holds | 2 | 0 | 0 | 0 | 2 (net +70) | 0 | 0 | 0 | 0% (0 of 2) |
| Opponent | Empire of Man | 5 | 1 (net +310) | 0 | 0 | 4 (net +108) | 0 | 0 | 0 | 0% (0 of 5) |
| Opponent | Grand Cathay | 4 | 0 | 0 | 2 (net -102) | 1 (net +95) | 0 | 1 (net -103) | 0 | 50% (2 of 4) |
| Opponent | Kingdom of Bretonnia | 1 | 0 | 1 (net +60) | 0 | 0 | 0 | 0 | 0 | 0% (0 of 1) |
| Opponent | Ogre Kingdoms | 5 | 1 (net +125) | 0 | 1 (net +0) | 1 (net +45) | 0 | 0 | 2 | 33% (1 of 3) |
| Opponent | Skaven | 3 | 1 (net +0) | 2 (net -105) | 0 | 0 | 0 | 0 | 0 | 0% (0 of 3) |
| Opponent | Tomb Kings of Khemri | 14 | 2 (net -195) | 0 | 3 (net +259) | 0 | 2 (net +150) | 3 (net +205) | 4 | 30% (3 of 10) |
| Opponent | Vampire Counts | 26 | 9 (net +27) | 2 (net +0) | 4 (net +107) | 5 (net +149) | 2 (net +82) | 3 (net +0) | 1 | 16% (4 of 25) |
| Opponent | Warriors of Chaos | 13 | 3 (net -38) | 0 | 3 (net +5) | 1 (net -465) | 3 (net +128) | 3 (net +202) | 0 | 23% (3 of 13) |
| Opponent | Wood Elf Realms | 20 | 11 (net -12) | 0 | 3 (net +25) | 1 (net +45) | 0 | 4 (net +78) | 1 | 16% (3 of 19) |

### Charged fights, damage counted: hmw-opp-c1e47a9-p2

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 11 | 249 | 270 | +213 | 251 | 46 | +205 | +82.2 |
| Mine | 50-54% | 2 | 274 | 158 | -298 | 28 | 298 | -270 | -98.7 |
| Mine | Effective (55-75%) | 9 | 262 | 150 | +76 | 95 | 23 | +72 | +27.6 |
| Mine | 76-89% | 13 | 295 | 144 | +70 | 95 | 15 | +80 | +27.1 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 17 | 280 | 197 | +148 | 156 | 14 | +141 | +50.5 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 15 | 447 | 96 | +90 | 111 | 24 | +87 | +19.5 |
| Mine | No odds | 7 | 224 | 121 | +16 | 31 | 16 | +16 | +7.0 |
| Mine | All fights | 74 | 304 | 164 | +99 | 127 | 30 | +98 | +32.1 |
| Opponent | Long shot (under 50%) | 28 | 203 | 279 | +1 | 110 | 88 | +22 | +10.6 |
| Opponent | 50-54% | 5 | 129 | 150 | -30 | 43 | 42 | +1 | +0.4 |
| Opponent | Effective (55-75%) | 16 | 232 | 158 | +68 | 136 | 69 | +67 | +28.8 |
| Opponent | 76-89% | 15 | 283 | 179 | +69 | 154 | 43 | +111 | +39.2 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 14 | 299 | 185 | +102 | 135 | 16 | +120 | +39.9 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 7 | 399 | 89 | +121 | 121 | 39 | +82 | +20.6 |
| Opponent | No odds | 8 | 281 | 237 | +42 | 96 | 44 | +52 | +18.6 |
| Opponent | All fights | 93 | 253 | 203 | +50 | 122 | 57 | +65 | +25.5 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| hmw-opp-c1e47a9-p2 | move | 349 | 64 (18%) | 47 (13%) | 50 (14%) | 235 (67%) |
| hmw-opp-c1e47a9-p2 | objective | 186 | 23 (12%) | 20 (11%) | 25 (13%) | 138 (74%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0106, L0122, L2429, L2535, L2735 |
| Charmed Shield | Opponent | L0425, L0827, L0934, L1026, L1727, L1827, L1927 |
| Clockwork Compass | Mine | L1228 |
| Clockwork Compass | Opponent | L0512 |
| Elixir of Power | Mine | L1118, L1135, L1927 |
| Fistful of Laurels | Mine | L1827 |
| Fistful of Laurels | Opponent | L0918, L1118, L1418 |
| Horn of the Wild Hunt | Opponent | L3033 |
| Invocation of Nehek | Mine | L2429, L2535, L2735 |
| Invocation of Nehek | Opponent | L0425, L0827, L1727, L1827, L1927 |
| Opal Amulet | Mine | L1418, L1435 |
| Periapt of Soul Exchange | Mine | L2029, L2131 |
| Periapt of Soul Exchange | Opponent | L0721 |
| Ring of Doom | Mine | L0206, L0222, L1118, L1135, L1228, L1531 |
| Ring of Doom | Opponent | L0512, L1531, L2131, L3033 |
| Ring of Jet | Mine | L1026, L1118, L1135, L1228 |
| Ring of Jet | Opponent | L0512, L0810 |
| Standard of the Fell Warrior | Mine | L1323 |
| Storm Daemon (Renegade 2.0) | Mine | L2131 |
| Storm Daemon (Renegade 2.0) | Opponent | L0721 |
| Twice-Blessed Armour | Mine | L0721, L1026 |
| Twice-Blessed Armour | Opponent | L0307, L0810 |
| Witch Hunter's Ward | Mine | L0721, L0810, L0827 |
| Witch Hunter's Ward | Opponent | L0307 |

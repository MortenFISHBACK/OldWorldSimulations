# Doctrine scorecard: fw-h2h2-mine-1eea44e-p3

### Scorecard: fw-h2h2-mine-1eea44e-p3

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0110 | 2 | 1 | Mine | - | - | 2 | 1 | 1 | 0 | 0 | 0 | 0 |
| L0110 | 2 | 1 | Opponent | - | - | 2 | 5 | 1 | 1 | 0 | 0 | 330 |
| L0126 | 6 | 1 | Mine | no | 5 | - | 1 | 1 | 0 | 0 | 0 | 387 |
| L0126 | 6 | 1 | Opponent | no | 8 | 2 | 3 | 3 | 0 | 0 | 0 | 0 |
| L0210 | 6 | 1 | Mine | no | 0 | - | 0 | 5 | 0 | 0 | 0 | 30 |
| L0210 | 6 | 1 | Opponent | no | 10 | 2 | 0 | 0 | 1 | 0 | 0 | 330 |
| L0226 | 4 | 1 | Mine | no | 0 | 1 | 2 | 6 | 0 | 0 | 0 | 442 |
| L0226 | 4 | 1 | Opponent | no | 6 | 2 | 1 | 2 | 1 | 0 | 0 | 0 |
| L0311 | 5 | 1 | Mine | no | - | 4 | 1 | 2 | 0 | 0 | 0 | 590 |
| L0311 | 5 | 1 | Opponent | yes | - | - | 3 | 1 | 0 | 0 | 0 | 427 |
| L0327 | 3 | 1 | Mine | no | 0 | 2 | 2 | 0 | 0 | 0 | 0 | 590 |
| L0327 | 3 | 1 | Opponent | no | 8 | - | 0 | 3 | 1 | 0 | 0 | 0 |
| L0413 | 5 | 1 | Mine | yes | - | 2 | 3 | 4 | 1 | 0 | 0 | 0 |
| L0413 | 5 | 1 | Opponent | yes | - | 6 | 1 | 1 | 0 | 0 | 0 | 317 |
| L0429 | 3 | 1 | Mine | yes | 11 | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L0429 | 3 | 1 | Opponent | no | 4 | 2 | 1 | 0 | 0 | 0 | 0 | 375 |
| L0516 | 6 | 1 | Mine | no | 2 | 3 | 1 | 1 | 0 | 0 | 0 | 560 |
| L0516 | 6 | 1 | Opponent | no | 2 | 2 | 1 | 2 | 1 | 0 | 0 | 200 |
| L0533 | 5 | 1 | Mine | yes | - | - | 0 | 1 | 0 | 0 | 0 | 1193 |
| L0533 | 5 | 1 | Opponent | yes | - | 2 | 4 | 6 | 0 | 0 | 0 | 0 |
| L0620 | 2 | 1 | Mine | - | - | 6 | 1 | 1 | 0 | 0 | 0 | 615 |
| L0620 | 2 | 1 | Opponent | - | - | - | 0 | 6 | 0 | 0 | 0 | 0 |
| L0709 | 1 | 1 | Mine | yes | 0 | 2 | 3 | 2 | 0 | 0 | 0 | 420 |
| L0709 | 1 | 1 | Opponent | no | 1 | 6 | 1 | 1 | 0 | 0 | 0 | 706 |
| L0725 | 5 | 1 | Mine | no | - | 5 | 1 | 1 | 0 | 0 | 0 | 613 |
| L0725 | 5 | 1 | Opponent | yes | - | 2 | 2 | 3 | 0 | 0 | 0 | 0 |
| L0815 | 5 | 1 | Mine | no | - | - | 0 | 2 | 0 | 0 | 0 | 515 |
| L0815 | 5 | 1 | Opponent | yes | - | 3 | 3 | 2 | 0 | 0 | 0 | 0 |
| L0831 | 3 | 1 | Mine | yes | 11 | 2 | 1 | 1 | 0 | 0 | 0 | 560 |
| L0831 | 3 | 1 | Opponent | no | 4 | - | 0 | 4 | 2 | 0 | 0 | 170 |
| L0922 | 4 | 1 | Mine | no | 0 | 2 | 2 | 0 | 0 | 0 | 0 | 681 |
| L0922 | 4 | 1 | Opponent | no | 1 | 2 | 2 | 1 | 2 | 0 | 0 | 110 |
| L1013 | 5 | 1 | Mine | yes | - | 3 | 2 | 1 | 1 | 0 | 0 | 330 |
| L1013 | 5 | 1 | Opponent | no | - | 1 | 2 | 2 | 2 | 0 | 0 | 479 |
| L1030 | 4 | 1 | Mine | no | 0 | 3 | 4 | 0 | 0 | 0 | 0 | 330 |
| L1030 | 4 | 1 | Opponent | no | 0 | 2 | 2 | 0 | 2 | 0 | 0 | 0 |
| L1122 | 6 | 1 | Mine | no | 2 | 2 | 3 | 0 | 1 | 0 | 0 | 330 |
| L1122 | 6 | 1 | Opponent | no | 2 | 2 | 2 | 2 | 0 | 0 | 0 | 72 |
| L1216 | 4 | 1 | Mine | no | 2 | 2 | 4 | 0 | 0 | 0 | 0 | 330 |
| L1216 | 4 | 1 | Opponent | no | 3 | 2 | 4 | 1 | 0 | 0 | 0 | 307 |
| **Average** | | | Mine | 33% | 2.8 | 2.7 | 1.8 | 1.5 | 0.1 | 0.0 | 0.0 | 425.8 |
| **Average** | | | Opponent | 28% | 4.1 | 2.5 | 1.9 | 2.0 | 0.7 | 0.0 | 0.0 | 191.2 |

### KPIs: fw-h2h2-mine-1eea44e-p3

Rules off - Opponent only: WAR ENGINE JOBS, STAY WEIGHED, BEST FIRST, RANDOM MOVE BY FIGURES, RANDOM MOVER NO PROMISE, STABLE ROLE, WOUNDED STAYS OUT, BEST FACING, LOST CHARGE, SCREEN BY WHAT IT SAVES, REDIRECT BY WHAT IT STOPS, SHOOTER COUNTED ONCE, LURE BY WHAT IT DRAWS, HILL BY ITS CHANCE, MOVE TO CHARGE, LONG SHOT, DEFENSIVE ARMY, SHOOTS FROM THE BEST SPOT, SUPPORTS, RESERVE FALL BACK, WAIT AFTER COSTS, CHARGE NOW FIRST, SUPPORT NARROWED, WAR ENGINE CHARGES, DEFENSIVE FLOOR.

Morten 2026-11-10; 20 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 48% (46 of 96) | 0% (0 of 96) | 24% (46 of 192) |
| Winner chose to follow up after the loser gave ground |  | 90% (18 of 20); on the table 90% | 100% (21 of 21); on the table 100% | 95% (39 of 41); on the table 95% |
| Winner chose to pursue after the loser fell back in good order |  | 100% (6 of 6); on the table 100% | 100% (4 of 4); on the table 100% | 100% (10 of 10); on the table 100% |
| Winner chose to pursue after the loser fled |  | 75% (9 of 12); on the table 75% | 75% (6 of 8); on the table 75% | 75% (15 of 20); on the table 75% |
| Winner chose to follow up or pursue (all three) |  | 87% (33 of 38); on the table 87% | 94% (31 of 33); on the table 94% | 90% (64 of 71); on the table 90% |
| Magic missiles tried each own turn | 50%+ | 34% (84 of 246) | 38% (61 of 162) | 36% (145 of 408) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 51% (84 of 165) | 52% (61 of 118) | 51% (145 of 283) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 40% (2 of 5) | - | 40% (2 of 5) |
| Points that never fought | lower | 50% (19187 of 38695) | 52% (20727 of 39993) | 51% (39914 of 78688) |
|   infantry points that never fought | lower | 64% (5779 of 8962) | 66% (5771 of 8747) | 65% (11550 of 17709) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 60% (97 of 162) | 63% (94 of 149) | 61% (191 of 311) |
| Bound items with a magic missile used (at least once a game) |  | 93% (14 of 15); 2.5 uses a game | 85% (11 of 13); 1.6 uses a game | 89% (25 of 28); 2.0 uses a game |
| Bound items with another spell used |  | 50% (3 of 6); 0.3 uses a game | 50% (3 of 6); 0.3 uses a game | 50% (6 of 12); 0.3 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 75% (12 of 16); 0.6 uses a game | 62% (5 of 8); 0.2 uses a game | 71% (17 of 24); 0.4 uses a game |
|   their share of the points of units over 100 pts | lower | 55% (17810 of 32385) | 55% (19496 of 35143) | 55% (37306 of 67528) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 2.0 (25%) | 0.9 (18%) | 2.9 (22%) |
| MARCHED: its unit marched | 1.6 (19%) | 1.4 (28%) | 3.0 (22%) |
| CHARGED: its unit charged | 0.2 (3%) | 0.5 (9%) | 0.7 (5%) |
| IN COMBAT: engaged in combat | 1.6 (20%) | 1.4 (28%) | 3.0 (23%) |
| FLEEING: fleeing | 0.2 (3%) | 0.0 (0%) | 0.2 (2%) |
| GONE: slain | 0.9 (12%) | 0.8 (16%) | 1.8 (13%) |
| OFF THE TABLE: off the table or not arrived | 1.2 (15%) | 0.0 (0%) | 1.2 (9%) |
| STUPIDITY: Stupidity | 0.1 (1%) | 0.1 (1%) | 0.1 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (2%) | 0.1 (1%) | 0.2 (2%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.2 | 1.1 | 2.2 | 7.2 | 0.7 | 1.9 |
| not cast | 3.9 | 1.9 | 4.7 | 13.2 | 3.0 | 18.5 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.4 (8%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.9 (47%) | 0.4 (9%) | 2.9 (22%) | 0.2 (8%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 3.0 (22%) | 0.8 (27%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (5%) | 0.1 (2%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.2 (5%) | 0.3 (16%) | 0.7 (14%) | 3.0 (23%) | 1.1 (36%) | 0.0 (0%) |
| FLEEING: fleeing | 0.1 (3%) | 0.1 (3%) | 0.1 (2%) | 0.2 (2%) | 0.1 (2%) | 0.5 (2%) |
| GONE: slain | 0.8 (22%) | 0.2 (13%) | 0.4 (9%) | 1.8 (13%) | 0.4 (14%) | 1.3 (7%) |
| OFF THE TABLE: off the table or not arrived | 0.5 (13%) | 0.2 (13%) | 0.3 (6%) | 1.2 (9%) | 0.1 (2%) | 0.5 (3%) |
| STUPIDITY: Stupidity | 0.1 (3%) | 0.0 (0%) | 0.1 (3%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (4%) | 0.1 (5%) | 0.1 (1%) | 0.2 (2%) | 0.3 (10%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.0 (51%) | 0.1 (3%) | 2.6 (56%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 14.8 (80%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.4 a game | 0.9 a game | 1.1 a game |
| stood (cast and not dispelled) | 52% (14 of 27) | 54% (7 of 13) | 52% (21 of 40) |
| the unit moved after it | 57% (8 of 14) | 86% (6 of 7) | 67% (14 of 21) |
| it charged on its next turn | 0% (0 of 14) | 14% (1 of 7) | 5% (1 of 21) |
| the enemy charged it first | 29% (4 of 14) | 0% (0 of 7) | 19% (4 of 21) |
| it fought by the end of its next turn | 7% (1 of 14) | 0% (0 of 7) | 5% (1 of 21) |
| it moved out of a charge the enemy had planned (not charged first) | 21% (3 of 14) | 29% (2 of 7) | 24% (5 of 21) |
| none of these (no charge, no fight, no charge escaped) | 50% (7 of 14) | 57% (4 of 7) | 52% (11 of 21) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 71% (357 of 503) | 59% (204 of 347) | 66% (561 of 850) |
|   cavalry | 64% (27 of 42) | 31% (11 of 35) | 49% (38 of 77) |
|   character | 91% (30 of 33) | 32% (19 of 59) | 53% (49 of 92) |
|   chariot | 39% (29 of 74) | 64% (16 of 25) | 45% (45 of 99) |
|   infantry | 60% (60 of 100) | 61% (84 of 138) | 61% (144 of 238) |
|   monster | 58% (7 of 12) | 100% (2 of 2) | 64% (9 of 14) |
|   war machine | 84% (204 of 242) | 82% (72 of 88) | 84% (276 of 330) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.0 (28%) | 2.1 (29%) | 4.2 (29%) |
| CHARGED: it charged | 0.6 (8%) | 0.9 (13%) | 1.6 (11%) |
| IN COMBAT: it fought this turn or the last | 0.9 (13%) | 0.1 (2%) | 1.1 (8%) |
| MOVED: a war machine that moved | 0.1 (1%) | 0.1 (1%) | 0.1 (1%) |
| FREE: none of these - no target in range or sight, or held its fire | 0.1 (2%) | 0.0 (0%) | 0.1 (1%) |
| NO TARGET IN RANGE | 0.6 (8%) | 1.3 (18%) | 1.9 (13%) |
| ONLY IN COMBAT: the only targets were in combat | 0.2 (3%) | 0.2 (3%) | 0.5 (3%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.7 (23%) | 1.6 (22%) | 3.2 (22%) |
| SHELTERED: the target was sheltered | 0.3 (5%) | 0.4 (6%) | 0.8 (5%) |
| STUPIDITY | 0.0 (0%) | 0.1 (1%) | 0.1 (0%) |
| OTHER BAR | 0.6 (8%) | 0.3 (5%) | 0.9 (7%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 3.0 | 1.5 | 62% | 12.1 pts | 37 pts |
| character | 3.0 | 1.1 | 76% | 9.0 pts | 26 pts |
| chariot | 2.2 | 0.8 | 80% | 12.8 pts | 29 pts |
| infantry | 10.9 | 3.3 | 78% | 7.7 pts | 83 pts |
| monster | 0.6 | 0.0 | 100% | 0.0 pts | 0 pts |
| war machine | 14.2 | 12.4 | 62% | 25.3 pts | 360 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.0 | 4.3 | 3.7 |
| Charges that made contact a game | 2.4 | 3.0 | 2.7 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.71 declared, 0.57 contact (14 units) | 1.25 declared, 0.81 contact (16 units) | 1.00 declared, 0.70 contact (30 units) |
|   per unit a game, units carrying another wizard (or one alone) | 1.00 declared, 1.00 contact (1 units) | 1.75 declared, 1.25 contact (4 units) | 1.60 declared, 1.20 contact (5 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.41 declared, 0.32 contact (120 units) | 0.45 declared, 0.32 contact (132 units) | 0.43 declared, 0.32 contact (252 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 66% (21 of 32) | 44% (4 of 9) | 25% (1 of 4) | 58% (26 of 45) |
| Character in a unit | 85% (22 of 26) | 89% (8 of 9) | 0% (0 of 1) | 83% (30 of 36) |
| Character on its own | 100% (17 of 17) | 54% (15 of 28) | 31% (10 of 32) | 55% (42 of 77) |
| Chariot | 57% (4 of 7) | 75% (9 of 12) | - | 68% (13 of 19) |
| Infantry | 57% (24 of 42) | 48% (12 of 25) | 25% (1 of 4) | 52% (37 of 71) |
| Monster | 58% (7 of 12) | 67% (2 of 3) | - | 60% (9 of 15) |
| Monstrous | 100% (1 of 1) | 75% (3 of 4) | - | 80% (4 of 5) |
| War Machines | 68% (28 of 41) | 100% (2 of 2) | - | 70% (30 of 43) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 100% (4 of 4); on the table 100% | 39% (37 of 96) | 31% | 55% (12 of 22) | 83% (5 of 6); 5.2 uses a game | 100% (2 of 2); 0.5 uses a game | 100% (6 of 6); 1.5 uses a game |
| Chaos Dwarfs | 4 | 73% (11 of 15); on the table 73% | 47% (17 of 36) | 50% | 66% (21 of 32) | 0.0 uses a game | 0.0 uses a game | 100% (2 of 2); 0.5 uses a game |
| Dwarfen Mountain Holds | 3 | 50% (1 of 2); on the table 50% | - | 74% | 75% (18 of 24) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 6 | 86% (6 of 7); on the table 86% | 57% (17 of 30) | 55% | 69% (41 of 59) | 0.0 uses a game | 50% (1 of 2); 1.0 uses a game | 25% (1 of 4); 0.2 uses a game |
| Grand Cathay | 7 | 100% (14 of 14); on the table 100% | 26% (45 of 174) | 50% | 49% (32 of 65) | 93% (14 of 15); 6.1 uses a game | 25% (1 of 4); 0.3 uses a game | 57% (4 of 7); 0.6 uses a game |
| High Elf Realms | 3 | 100% (3 of 3); on the table 100% | 39% (7 of 18) | 63% | 70% (16 of 23) | 100% (4 of 4); 4.3 uses a game | 50% (2 of 4); 1.0 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 2 | 100% (3 of 3); on the table 100% | - | 41% | 33% (4 of 12) | 0.0 uses a game | 0.0 uses a game | 100% (2 of 2); 1.0 uses a game |
| Skaven | 1 | - | 83% (5 of 6) | 73% | 71% (5 of 7) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Tomb Kings of Khemri | 2 | 80% (4 of 5); on the table 80% | 0% (0 of 6) | 30% | 30% (3 of 10) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 4 | 100% (10 of 10); on the table 100% | 47% (14 of 30) | 54% | 59% (13 of 22) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 3 | 100% (8 of 8); on the table 100% | 50% (3 of 6) | 35% | 72% (18 of 25) | 100% (1 of 1); 1.0 uses a game | 0.0 uses a game | 100% (1 of 1); 0.3 uses a game |
| Wood Elf Realms | 1 | - | 0% (0 of 6) | 75% | 80% (8 of 10) | 50% (1 of 2); 2.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (fw-h2h2-mine-1eea44e-p3, 20 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 60% (24) | 41% (12) | 52% (36) |
| ...free all their last turn and able to turn (per game) | 0.65 | 0.45 | 1.10 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.30 | 0.10 | 0.40 |
| ...with the charger already in that arc before they moved (per game) | 0.35 | 0.35 | 0.70 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 1.45 | 0.95 | 2.40 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 1.05 | 0.85 | 1.90 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 4.90 | 4.95 | 9.85 |

### Quality by phase: fw-h2h2-mine-1eea44e-p3

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.6 | 4.0 |
| Strategy | Charge objectives carried out (made contact) | 55% (32 of 58) | 39% (30 of 77) |
| Strategy | Shoot objectives carried out (shot that target) | 44% (136 of 306) | 53% (66 of 125) |
| Strategy | Close-in objectives charged next turn | 8% (6 of 76) | 14% (16 of 115) |
| Strategy | Support requests answered (helper made contact too) | 83% (5 of 6) | 62% (8 of 13) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (1 of 1) | - |
| Strategy | Hexes on a unit its side charged or shot that turn | 0% (0 of 1) | 100% (6 of 6) |
| Strategy | Joined characters whose unit fought | 41% (15 of 37) | 14% (3 of 21) |
| Strategy | Lone characters that fought | 68% (34 of 50) | 71% (37 of 52) |
| Movement | Charges halted short of contact | 0.1 | 0.1 |
| Movement | Idle units | 1.5 | 2.0 |
| Movement | Points that never moved of their own | 425.8 | 191.2 |
| Movement | Fights charged into per game | 2.1 | 2.4 |
| Movement | Charges with odds: long shots (under 50%) | 6 of 42, net +59 | 6 of 41, net +117 |
| Movement | Charges with odds: sweet spot (55-75%) | 6 of 42, net +113 | 4 of 41, net +218 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 6 of 42, net +52 | 5 of 41, net +86 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 20 of 42, net +46 | 16 of 41, net +102 |
| Shooting | Shots by shooting units (incl. breath weapons) | 8.0 | 7.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 50% (80 of 159) | 42% (62 of 146) |
| Shooting | Points destroyed by shooting units | 67.8 | 62.4 |
| Shooting | War machine shots | 10.2 | 4.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 54% (111 of 204) | 35% (28 of 81) |
| Shooting | Points destroyed by war machines | 178.8 | 27.1 |
| Magic | Magic missiles cast | 3.0 | 1.8 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 32% (19 of 59) | 25% (9 of 36) |
| Magic | Wounds caused by magic missiles | 5.9 | 2.8 |
| Magic | Wounds caused by other spells | 3.0 | 0.4 |
| Magic | Points destroyed by magic (all spells) | 134.7 | 19.1 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.8 / 0.1 / 1.1 / 0.2 | 1.9 / 0.3 / 0.1 / 0.0 |
| Combat | Points destroyed in combat | 205.6 | 327.3 |
| Combat | Points run down | 101.4 | 105.4 |
| Combat | Net points per charged fight, damage counted | +71 | +98 |
| Combat | Net per 100 charger points, damage counted | +27.2 | +27.6 |
| Combat | First round won (charged fights) | 70% | 65% |
| Combat | Net points per charged fight | +59 | +115 |
| Combat | Net points per supported fight / lone fight | +20 / +63 | +120 / +114 |
| Combat | Charged fights on a top-3 enemy unit | 7 of 43 | 30 of 48 |
| Game | Points lost | 644.7 | 705.8 |
| Game | VP from objectives | 544.0 | 561.5 |
| Game | Lone holders (player turns) | 2.8 | 4.1 |

- Mine won / drew / lost: 8 / 5 / 7 of 20 ended games (of 20); mean margin (Mine - Opponent) +38 VP
- The side that went first won 11 of 15 games with a winner
- Points traded per game (both sides' losses): 1350
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: fw-h2h2-mine-1eea44e-p3

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.3 | +0.0 | 0.0 | 0.0 | 0.5 | +0.0 | 0.0 | 0.0 |
| ALREADY CARRIED | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARRIVAL HUNT | - | - | - | - | 0.1 | +0.4 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 3.2 | +0.0 | 0.0 | 43.5 | 0.6 | +0.0 | 0.0 | 6.2 |
| BACKUP TARGETS | 0.7 | +8.1 | 0.0 | 0.0 | 0.7 | +7.4 | 0.0 | 6.8 |
| BEST FACING | 0.6 | +10.4 | 0.0 | 0.0 | - | - | - | - |
| BEST FIRST | 4.0 | +164.6 | 129.6 | 66.3 | - | - | - | - |
| BEST OVERALL | 0.8 | +62.7 | 0.0 | 4.5 | 0.4 | +24.5 | 0.0 | 8.3 |
| BEST PREY | 0.6 | +38.8 | 0.0 | 0.0 | 4.3 | +290.4 | 173.1 | 84.2 |
| BEST PRIZE | 0.1 | -8.4 | 16.9 | 21.7 | - | - | - | - |
| BIG CHARACTER SAFETY | 0.1 | -0.7 | 0.0 | 0.0 | 0.4 | -1.8 | 0.0 | 0.0 |
| BLOCKED CHARGE SKIPPED | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| BLOCKED WHEEL | 0.3 | +3.6 | 0.0 | 0.0 | 0.3 | +2.9 | 0.0 | 6.8 |
| BOMBING RUN | 0.1 | +1.4 | 0.0 | 0.0 | - | - | - | - |
| BOUND ASSAILMENT | - | - | - | - | 0.1 | +0.0 | 0.0 | 7.5 |
| CANNON PLAN MISSED | 1.3 | +0.0 | 112.2 | 9.5 | 0.6 | +0.0 | 14.5 | 20.0 |
| CANNON PLANNED TARGET | 9.3 | +254.6 | 688.8 | 116.0 | 2.1 | +88.7 | 66.9 | 28.5 |
| CANNON SIGHT KEPT | 1.9 | +0.0 | 0.0 | 5.8 | 0.5 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT COUNTER | 0.1 | +0.0 | 9.3 | 0.0 | 0.1 | +0.0 | 18.4 | 0.0 |
| CARRIES OUT SET-UP | 0.1 | -9.8 | 14.2 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CAST JOB | 1.1 | +33.5 | 102.0 | 9.4 | 0.6 | +17.7 | 31.0 | 10.1 |
| CASTER AWAY FROM SCREEN | 0.2 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.4 | +27.0 | 5.5 | 16.1 | - | - | - | - |
| CASTS AFTER FRIENDS | 0.7 | +0.0 | 0.0 | 17.8 | 0.6 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | - | - | - | - | 0.2 | +0.0 | 0.0 | 0.0 |
| CATCH ODDS | - | - | - | - | 0.1 | +1.8 | 0.0 | 10.1 |
| CHAFF PASSED | 0.3 | -0.0 | 9.8 | 0.0 | 0.3 | -1.6 | 6.5 | 3.6 |
| CHARGE NOW FIRST | 2.3 | +0.0 | 251.3 | 55.4 | - | - | - | - |
| CHARGE NOW WEIGHED | 0.5 | -15.2 | 5.5 | 37.4 | 0.4 | -20.6 | 4.2 | 19.2 |
| CHARIOT NO STATIC JOB | - | - | - | - | 0.1 | +0.0 | 0.0 | 3.6 |
| CHARIOT WIZARD CAREFUL | - | - | - | - | 0.3 | -6.1 | 21.7 | 0.0 |
| CHEAP HELPER | - | - | - | - | 0.1 | +0.0 | 0.0 | 0.0 |
| COMBAT PIVOT | 0.6 | +0.0 | 79.2 | 64.0 | 0.1 | +0.0 | 0.0 | 6.8 |
| CONVEYANCE SEARCH | 1.2 | +111.4 | 25.6 | 17.8 | 0.7 | +77.4 | 0.0 | 0.0 |
| COUNTER-CHARGE COVER | 8.8 | +747.1 | 0.0 | 94.7 | 6.2 | +566.0 | 0.0 | 99.2 |
| DEFENSIVE ARMY | 0.1 | +0.0 | 23.6 | 0.0 | - | - | - | - |
| DEFENSIVE FLOOR | 0.1 | +1.0 | 2.2 | 0.0 | - | - | - | - |
| EDGE GIVE GROUND | 0.1 | +1.2 | 0.0 | 0.0 | 0.1 | +0.4 | 9.4 | 0.0 |
| ELIXIR WORTH | 0.1 | +3.0 | 0.0 | 14.8 | - | - | - | - |
| ENGINEER BY LORE | 0.2 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 1.4 | +99.9 | 0.0 | 23.1 | 0.9 | +102.5 | 0.0 | 0.0 |
| FALLBACK BY WORTH | 4.3 | +37.5 | 0.0 | 38.5 | 5.7 | +72.5 | 0.0 | 81.7 |
| FIGHT LIFT | - | - | - | - | 0.1 | +0.8 | 23.6 | 0.0 |
| FIRE AND FLEE | 0.1 | +2.1 | 0.0 | 15.9 | - | - | - | - |
| FLANK NOT WEIGHED | 5.0 | +0.0 | 0.0 | 62.0 | 4.5 | +0.0 | 0.0 | 92.0 |
| FOLLOW UP WEIGHED | 0.8 | +92.7 | 0.0 | 42.1 | 1.0 | +153.6 | 0.0 | 56.3 |
| FRIENDS SHOTS CHECKED | 0.1 | +0.5 | 0.0 | 0.0 | 0.1 | +8.1 | 0.0 | 0.0 |
| GIVES UP | - | - | - | - | 1.5 | -50.2 | 210.3 | 20.6 |
| GIVES UP ITS SCREEN | - | - | - | - | 0.2 | -7.1 | 13.5 | 6.2 |
| GROUND FLIERS | 0.1 | +3.6 | 0.0 | 0.0 | - | - | - | - |
| HELPER ALREADY ASKED | - | - | - | - | 0.1 | +0.0 | 0.0 | 4.0 |
| HELPER UNSEEN | 0.1 | +0.0 | 9.9 | 0.0 | 0.1 | +0.0 | 0.0 | 8.7 |
| HILL BY ITS CHANCE | 0.3 | -19.3 | 0.0 | 3.9 | - | - | - | - |
| HOLDS AMBUSHERS | 0.3 | +0.0 | 0.0 | 0.0 | 0.5 | +0.0 | 0.0 | 0.0 |
| HUNT ADVANCE | 0.3 | +20.5 | 0.0 | 0.0 | 0.4 | +17.9 | 4.8 | 9.3 |
| HUNT DROPPED | 0.1 | +0.0 | 0.0 | 2.6 | 0.1 | +0.0 | 0.0 | 0.0 |
| HUNT IN PAIRS | 0.4 | +24.1 | 0.0 | 18.4 | 1.0 | +91.8 | 0.0 | 21.6 |
| HUNT KEPT | 0.6 | +15.2 | 0.0 | 0.0 | 0.2 | +10.3 | 4.8 | 3.6 |
| HUNT RESULT | 0.1 | +0.0 | 0.0 | 2.6 | 0.2 | +8.1 | 6.5 | 3.6 |
| HUNT THE GUNS | 0.2 | +81.0 | 0.0 | 0.0 | 0.2 | +78.6 | 4.8 | 5.8 |
| INVITES THE FIGHT | 1.2 | +25.7 | 90.4 | 0.0 | - | - | - | - |
| JOINT CHARGE PLAN | 0.1 | +5.9 | 0.0 | 0.0 | 0.3 | +10.6 | 0.0 | 0.0 |
| KEEP FALLS | 0.3 | +3.8 | 0.0 | 0.0 | 0.1 | +0.4 | 0.0 | 0.0 |
| KEEPS ITS PREY | 0.1 | +0.7 | 0.0 | 0.0 | 0.1 | +1.3 | 18.4 | 0.0 |
| KEEPS ITS TARGET | 0.9 | +28.5 | 97.0 | 5.5 | 1.6 | +49.5 | 121.9 | 19.4 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KILLS COUNT | 1.4 | +64.8 | 101.0 | 18.5 | 1.5 | +70.2 | 128.1 | 34.5 |
| KILLS COUNT NEXT TURN | 4.8 | +113.6 | 125.3 | 109.3 | 10.2 | +393.7 | 363.5 | 188.9 |
| LONE CHARACTER SAFE SPOT | 0.7 | +9.2 | 36.6 | 13.9 | 0.5 | +9.2 | 28.2 | 27.9 |
| LONE WIZARD HOLDS BACK | - | - | - | - | 0.1 | +0.0 | 0.0 | 0.0 |
| LONE WIZARD KEPT IN | 0.8 | +57.8 | 0.0 | 0.0 | 0.5 | +41.3 | 0.0 | 0.0 |
| LONG SHOT | 0.2 | +2.9 | 7.2 | 0.0 | - | - | - | - |
| LOST CHARGE | 3.2 | -67.7 | 125.7 | 151.7 | - | - | - | - |
| MAKE SURE TOGETHER | 0.8 | +75.0 | 10.2 | 18.4 | 1.6 | +66.8 | 51.1 | 47.6 |
| MANOEUVRE | 0.2 | +7.8 | 0.0 | 0.0 | 0.1 | +12.3 | 0.0 | 5.5 |
| MARCH AT ESCAPER | 0.1 | +2.3 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| MARCH CHECK | 0.8 | +30.2 | 0.0 | 0.0 | 0.9 | +67.2 | 0.0 | 19.9 |
| MARCH ODDS | - | - | - | - | 1.6 | +87.2 | 34.7 | 49.8 |
| MARCH OVER CASTS | 0.5 | +24.5 | 0.0 | 29.0 | 0.5 | -28.0 | 0.0 | 11.7 |
| MAX FOR POSITIONING | 2.8 | +97.4 | 0.0 | 20.1 | 3.8 | +161.8 | 0.0 | 115.0 |
| MISSILES IN THE MOVE | 4.8 | +219.2 | 0.0 | 52.3 | 4.7 | +82.9 | 0.0 | 94.3 |
| MISSILES NEXT TURN | 5.8 | +147.1 | 0.0 | 90.8 | 5.8 | +61.9 | 0.0 | 113.4 |
| MODEL FACING | 0.2 | +106.2 | 0.0 | 0.0 | - | - | - | - |
| MONSTER WIZARD ROAMS | 0.7 | +0.0 | 24.7 | 18.4 | 0.2 | +0.0 | 0.0 | 0.0 |
| MOVE AND CAST | 0.3 | +27.8 | 0.0 | 0.0 | 0.3 | +6.7 | 0.0 | 20.0 |
| MOVE SPELL IN RANGE | 0.5 | +16.2 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.6 | -30.2 | 0.0 | 75.8 | 0.1 | -0.8 | 0.0 | 11.7 |
| MOVE SPELL SPOT | 0.3 | +0.0 | 0.0 | 4.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE | 3.1 | +114.5 | 86.2 | 67.0 | - | - | - | - |
| MOVES UNITS SPELL | 0.1 | +5.5 | 0.0 | 0.0 | 0.1 | +0.4 | 0.0 | 0.0 |
| NEEDED THERE | - | - | - | - | 0.1 | +1.4 | 0.0 | 0.0 |
| NO RALLY LEFT | - | - | - | - | 0.1 | +6.3 | 0.0 | 0.0 |
| NOT NEEDED | 0.1 | -2.4 | 4.0 | 0.0 | 0.1 | -8.4 | 6.5 | 6.3 |
| NOT TURNED | 4.9 | +48.9 | 0.0 | 108.8 | 5.0 | +47.0 | 0.0 | 91.4 |
| NOT WORTH A CAST | 0.3 | -0.2 | 0.0 | 17.8 | 0.3 | -5.6 | 0.0 | 0.0 |
| OFF BEST | 16.4 | -910.1 | 9.9 | 134.4 | 15.1 | -859.5 | 62.8 | 260.9 |
| OPENS A LANE | 0.2 | +0.3 | 1.9 | 0.0 | - | - | - | - |
| OPENS UP | 0.1 | +14.3 | 7.5 | 21.7 | 0.2 | +21.8 | 17.2 | 0.0 |
| OVERRUNS AWAY | 0.2 | +6.4 | 7.1 | 24.7 | 0.5 | +18.1 | 53.0 | 29.9 |
| PATHS CROSS | 1.8 | +119.5 | 0.0 | 4.2 | 2.2 | +145.3 | 0.0 | 14.0 |
| PERIAPT WORTH | - | - | - | - | 0.1 | +2.7 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.3 | -13.9 | 0.0 | 18.4 | 0.1 | -0.5 | 0.0 | 3.0 |
| PLAN RESULT | 38.1 | +1531.1 | 1622.9 | 837.9 | 34.4 | +1126.4 | 1129.4 | 1078.6 |
| PURSUES BIG PREY | 0.2 | -22.2 | 0.0 | 0.0 | 0.1 | -2.3 | 0.0 | 21.6 |
| RANDOM MOVE BY FIGURES | 0.2 | +2.6 | 0.0 | 17.0 | - | - | - | - |
| RANDOM MOVER NO PROMISE | 0.1 | -3.6 | 0.0 | 0.0 | - | - | - | - |
| REDIRECT BY WHAT IT STOPS | 0.1 | -2.4 | 0.0 | 0.0 | - | - | - | - |
| REDIRECT COUNTER | 1.1 | +124.0 | 0.0 | 22.9 | 1.8 | +105.9 | 0.0 | 57.2 |
| REDIRECT WEIGHED | 0.1 | +6.9 | 0.0 | 10.2 | 0.5 | +15.9 | 0.0 | 2.2 |
| RESERVE FALL BACK | 0.1 | +5.1 | 0.0 | 0.0 | - | - | - | - |
| RESTRAINS TO SHOOT | 0.1 | +2.8 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | 2.2 | +84.2 | 203.2 | 49.5 | 2.3 | +26.9 | 168.1 | 113.3 |
| SAFER THAN THE JOB | 1.1 | +50.2 | 0.0 | 0.0 | 0.8 | +67.2 | 0.0 | 32.5 |
| SCOUT SPOT | 0.4 | +0.7 | 0.0 | 0.0 | 0.3 | +1.4 | 0.0 | 0.0 |
| SCOUT WAITS | 0.4 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.1 | -0.6 | 0.0 | 0.0 | - | - | - | - |
| SEARCH SPOT | 1.8 | +80.0 | 0.0 | 16.5 | 1.1 | +63.6 | 0.0 | 46.7 |
| SECOND HUNTER | 0.1 | -2.2 | 0.0 | 0.0 | - | - | - | - |
| SELF MOVE SPELL | - | - | - | - | 0.3 | +118.3 | 0.0 | 0.0 |
| SET UP TOGETHER | 1.0 | +102.8 | 10.2 | 18.4 | 2.2 | +95.0 | 51.1 | 47.6 |
| SET-UP ANY TARGET | 0.7 | +124.9 | 4.0 | 0.0 | 0.5 | +54.3 | 0.0 | 0.0 |
| SET-UP MISSED | 0.1 | +14.1 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | 0.3 | +0.7 | 0.0 | 0.0 | 0.1 | +0.2 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.4 | +73.7 | 123.4 | 5.2 | - | - | - | - |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SHOT REPLANNED | 1.3 | +0.0 | 174.2 | 9.9 | 0.2 | +0.0 | 93.8 | 0.0 |
| SHOTS IN THE MOVE | 17.5 | +765.2 | 0.0 | 194.1 | 9.6 | +417.9 | 0.0 | 146.9 |
| SPELL CATCH ODDS | 0.2 | -4.0 | 5.5 | 0.0 | - | - | - | - |
| SPELL SETS UP CHARGE | 0.8 | +137.4 | 4.0 | 0.0 | 0.5 | +54.3 | 0.0 | 0.0 |
| SPELL WORTH | 0.6 | +20.8 | 47.6 | 47.6 | 2.7 | +46.7 | 43.5 | 20.0 |
| STABLE ROLE | 12.2 | +0.0 | 402.6 | 71.4 | - | - | - | - |
| STANDS TO CAST | 0.1 | +1.8 | 0.0 | 0.0 | - | - | - | - |
| STOPS | 0.2 | +8.2 | 0.0 | 0.0 | 0.1 | +6.4 | 4.8 | 0.0 |
| STOPS SHORT OF THE FLANK | 0.6 | +35.6 | 0.0 | 15.8 | 0.6 | +16.0 | 0.0 | 0.0 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 8.5 |
| SUPPORT JOB KEPT | - | - | - | - | 0.1 | +0.0 | 0.0 | 3.6 |
| SUPPORT NARROWED | 4.3 | -38.4 | 286.2 | 60.8 | - | - | - | - |
| SUPPORTS | 2.6 | +50.8 | 127.7 | 25.1 | - | - | - | - |
| SURE CHARGE BEATS ADVANCE | - | - | - | - | 0.1 | -4.6 | 20.4 | 0.0 |
| SURE REACH TOGETHER | 0.4 | -0.9 | 0.0 | 18.4 | 0.9 | +1.7 | 0.0 | 7.5 |
| THROUGH LINE OF FIRE | 0.8 | +6.6 | 0.0 | 12.6 | 0.2 | +12.6 | 0.0 | 6.8 |
| TURN WORTH | 0.6 | -46.7 | 62.2 | 18.5 | 0.3 | -28.8 | 24.9 | 6.8 |
| TWO OR MORE ARRIVE | 0.3 | +2.4 | 0.0 | 0.0 | 0.5 | +4.1 | 0.0 | 17.9 |
| WAIT AFTER COSTS | 6.8 | -249.5 | 219.9 | 89.0 | - | - | - | - |
| WALKS TO THE FIGHT | 2.5 | +38.5 | 35.5 | 16.5 | - | - | - | - |
| WAR ENGINE CHARGES | 0.1 | +9.1 | 3.5 | 0.0 | - | - | - | - |
| WAR ENGINE JOBS | 1.1 | +0.0 | 88.5 | 6.5 | - | - | - | - |
| WEARS DOWN | 0.8 | +28.0 | 111.5 | 35.6 | 1.0 | +27.6 | 69.0 | 51.2 |
| WHO HITS BACK | 0.2 | +9.4 | 0.0 | 3.0 | 0.1 | +8.7 | 0.0 | 0.0 |
| WHOLE FIGHT | 0.1 | +0.4 | 19.3 | 10.8 | 0.3 | +31.3 | 40.1 | 0.0 |
| WHOLE FIGHT GAIN | 0.1 | +6.8 | 4.0 | 0.0 | 0.3 | +27.6 | 8.8 | 12.6 |

### Rule changes: fw-h2h2-mine-1eea44e-p3

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 630 | 630 | 630 | 31.50 | -35392 | -56.2 |
| KILLS COUNT NEXT TURN | 299 | 298 | 85 | 4.25 | +2378 | +28.0 |
| BEST FIRST | 81 | 81 | 81 | 4.05 | +3291 | +40.6 |
| PATHS CROSS | 81 | 81 | 81 | 4.05 | +5296 | +65.4 |
| ARTILLERY RE-ROLL WEIGHED | 75 | 75 | 75 | 3.75 | +0 | +0.0 |
| COUNTER-CHARGE COVER | 301 | 155 | 57 | 2.85 | +3704 | +65.0 |
| SEARCH SPOT | 57 | 57 | 56 | 2.80 | +2872 | +51.3 |
| FACES THE THREAT | 48 | 48 | 48 | 2.40 | +4048 | +84.3 |
| CANNON SIGHT KEPT | 47 | 47 | 47 | 2.35 | +0 | +0.0 |
| SHOTS IN THE MOVE | 541 | 384 | 47 | 2.35 | +1808 | +38.5 |
| CANNON PLANNED TARGET | 229 | 229 | 44 | 2.20 | -520 | -11.8 |
| FALLBACK BY WORTH | 200 | 200 | 44 | 2.20 | +2201 | +50.0 |
| BEST PREY | 98 | 97 | 42 | 2.10 | +1822 | +43.4 |
| SAFER THAN THE JOB | 38 | 38 | 38 | 1.90 | +2349 | +61.8 |
| FOLLOW UP WEIGHED | 37 | 37 | 37 | 1.85 | +4927 | +133.2 |
| MOVE TO CHARGE | 62 | 62 | 31 | 1.55 | +544 | +17.6 |
| SHOT REPLANNED | 30 | 30 | 30 | 1.50 | +0 | +0.0 |
| WALKS TO THE FIGHT | 49 | 49 | 29 | 1.45 | +349 | +12.0 |
| MARCH ODDS | 32 | 29 | 28 | 1.40 | +537 | +19.2 |
| MISSILES IN THE MOVE | 190 | 109 | 28 | 1.40 | +585 | +20.9 |
| MARCH CHECK | 35 | 32 | 27 | 1.35 | +2092 | +77.5 |
| SET UP TOGETHER | 65 | 56 | 26 | 1.30 | +836 | +32.2 |
| LONE WIZARD KEPT IN | 25 | 25 | 25 | 1.25 | +1980 | +79.2 |
| BEST OVERALL | 24 | 24 | 24 | 1.20 | +1745 | +72.7 |
| SUPPORTS | 52 | 52 | 23 | 1.15 | +392 | +17.1 |
| STOPS SHORT OF THE FLANK | 22 | 22 | 22 | 1.10 | +1033 | +47.0 |
| THROUGH LINE OF FIRE | 21 | 21 | 21 | 1.05 | +385 | +18.3 |
| WAIT AFTER COSTS | 136 | 136 | 20 | 1.00 | +371 | +18.5 |
| CAST JOB | 33 | 32 | 18 | 0.90 | +478 | +26.5 |
| MAKE SURE TOGETHER | 47 | 35 | 18 | 0.90 | +758 | +42.1 |
| CHARGE NOW WEIGHED | 17 | 17 | 17 | 0.85 | +192 | +11.3 |
| MAX FOR POSITIONING | 132 | 65 | 17 | 0.85 | +183 | +10.8 |
| HOLDS AMBUSHERS | 16 | 16 | 16 | 0.80 | +0 | +0.0 |
| ADVANCE LANE KEPT | 15 | 15 | 15 | 0.75 | +0 | +0.0 |
| RISK BY ARC | 90 | 86 | 15 | 0.75 | +430 | +28.6 |
| COMBAT PIVOT | 14 | 14 | 14 | 0.70 | +0 | +0.0 |
| KILLS COUNT | 59 | 59 | 14 | 0.70 | +679 | +48.5 |
| SCOUT WAITS | 14 | 14 | 14 | 0.70 | +0 | +0.0 |
| BLOCKED WHEEL | 13 | 13 | 13 | 0.65 | +129 | +10.0 |
| REDIRECT WEIGHED | 13 | 13 | 13 | 0.65 | +486 | +37.4 |
| SHOOTS FROM THE BEST SPOT | 28 | 28 | 13 | 0.65 | +639 | +49.2 |
| CHAFF PASSED | 12 | 12 | 12 | 0.60 | -33 | -2.7 |
| MOVE AND CAST | 12 | 12 | 12 | 0.60 | +688 | +57.4 |
| BEST FACING | 11 | 11 | 11 | 0.55 | +209 | +19.0 |
| INVITES THE FIGHT | 24 | 24 | 11 | 0.55 | +143 | +13.0 |
| BIG CHARACTER SAFETY | 10 | 10 | 10 | 0.50 | -50 | -5.0 |
| SHOOTERS IN TWO RANKS | 10 | 10 | 10 | 0.50 | +18 | +1.8 |
| CHARGE NOW FIRST | 46 | 46 | 9 | 0.45 | -521 | -57.9 |
| PIVOT GUARDS FLANK | 9 | 9 | 9 | 0.45 | -287 | -31.9 |
| WAR ENGINE JOBS | 21 | 21 | 9 | 0.45 | -257 | -28.6 |
| KEEPS ITS TARGET | 52 | 50 | 8 | 0.40 | +97 | +12.1 |
| MANOEUVRE | 8 | 8 | 8 | 0.40 | +402 | +50.2 |
| MISSILES NEXT TURN | 234 | 128 | 8 | 0.40 | +65 | +8.1 |
| WHO HITS BACK | 8 | 8 | 8 | 0.40 | +161 | +20.1 |
| CASTER AWAY FROM SCREEN | 7 | 7 | 7 | 0.35 | +0 | +0.0 |
| KEEP FALLS | 7 | 7 | 7 | 0.35 | +241 | +34.4 |
| STUCK PIVOT | 6 | 6 | 6 | 0.30 | +0 | +0.0 |
| WEARS DOWN | 36 | 32 | 6 | 0.30 | +77 | +12.9 |
| CASTING BLOCK | 8 | 8 | 5 | 0.25 | +251 | +50.2 |
| HUNT ADVANCE | 15 | 15 | 5 | 0.25 | +218 | +43.7 |
| MODEL FACING | 5 | 5 | 5 | 0.25 | +2124 | +424.9 |
| OPENS UP | 8 | 7 | 5 | 0.25 | +332 | +66.5 |
| PURSUES BIG PREY | 5 | 5 | 5 | 0.25 | -490 | -98.1 |
| SHORT GUN FORWARD | 5 | 5 | 5 | 0.25 | +0 | +0.0 |
| WHOLE FIGHT GAIN | 9 | 8 | 5 | 0.25 | +264 | +52.7 |
| CASTS FROM BEHIND | 4 | 4 | 4 | 0.20 | +0 | +0.0 |
| REDIRECT COUNTER | 57 | 20 | 4 | 0.20 | +397 | +99.3 |
| CATCH ODDS | 3 | 3 | 3 | 0.15 | -12 | -4.0 |
| HUNT IN PAIRS | 28 | 12 | 3 | 0.15 | +499 | +166.4 |
| LOST CHARGE | 65 | 65 | 3 | 0.15 | +64 | +21.5 |
| MOVES UNITS SPELL | 3 | 3 | 3 | 0.15 | +118 | +39.2 |
| OVERRUNS AWAY | 15 | 15 | 3 | 0.15 | +86 | +28.8 |
| WHOLE FIGHT | 9 | 8 | 3 | 0.15 | +392 | +130.6 |
| BACKUP TARGETS | 27 | 13 | 2 | 0.10 | +2 | +1.1 |
| BEST PRIZE | 2 | 2 | 2 | 0.10 | -168 | -84.2 |
| BLOCKED CHARGE SKIPPED | 2 | 2 | 2 | 0.10 | +0 | +0.0 |
| DEFENSIVE ARMY | 3 | 3 | 2 | 0.10 | -26 | -13.1 |
| FIRE AND FLEE | 2 | 2 | 2 | 0.10 | +41 | +20.7 |
| FRIENDS SHOTS CHECKED | 2 | 2 | 2 | 0.10 | +173 | +86.3 |
| JOINT CHARGE PLAN | 10 | 10 | 2 | 0.10 | +80 | +40.1 |
| RANDOM MOVE BY FIGURES | 5 | 5 | 2 | 0.10 | +51 | +25.6 |
| RESERVE FALL BACK | 2 | 2 | 2 | 0.10 | +102 | +51.0 |
| RESTRAINS TO SHOOT | 2 | 2 | 2 | 0.10 | +55 | +27.7 |
| SURE CHARGE BEATS ADVANCE | 2 | 2 | 2 | 0.10 | -92 | -45.9 |
| SURE REACH TOGETHER | 27 | 20 | 2 | 0.10 | +0 | +0.1 |
| TWO OR MORE ARRIVE | 16 | 14 | 2 | 0.10 | +24 | +11.8 |
| BOMBING RUN | 1 | 1 | 1 | 0.05 | +27 | +27.1 |
| BOUND ASSAILMENT | 1 | 1 | 1 | 0.05 | +0 | +0.1 |
| CARRIES OUT SET-UP | 3 | 3 | 1 | 0.05 | -195 | -195.3 |
| CHARIOT NO STATIC JOB | 2 | 2 | 1 | 0.05 | -4 | -4.5 |
| ELIXIR WORTH | 1 | 1 | 1 | 0.05 | +59 | +59.0 |
| KEEPS SCOUTS OR AMBUSH | 1 | 1 | 1 | 0.05 | +0 | +0.0 |
| LONG SHOT | 5 | 5 | 1 | 0.05 | +12 | +12.4 |
| NEEDED THERE | 2 | 2 | 1 | 0.05 | +0 | +0.0 |
| NO RALLY LEFT | 1 | 1 | 1 | 0.05 | +106 | +106.2 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.05 | +54 | +54.4 |
| STANDS TO CAST | 1 | 1 | 1 | 0.05 | -14 | -14.4 |
| STOPS | 6 | 6 | 1 | 0.05 | +104 | +104.2 |
| SUPPORT JOB KEPT | 1 | 1 | 1 | 0.05 | -27 | -27.0 |
| TURN WORTH | 19 | 18 | 1 | 0.05 | +36 | +35.9 |
| ALREADY CARRIED | 3 | not checked | - | - | - | - |
| ARRIVAL HUNT | 2 | 2 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 37 | 37 | 0 | 0.00 | - | - |
| CARRIES OUT COUNTER | 2 | 2 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 24 | trace | - | - | - | - |
| CHARIOT WIZARD CAREFUL | 7 | 7 | 0 | 0.00 | - | - |
| CHEAP HELPER | 1 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 38 | not checked | - | - | - | - |
| DEFENSIVE FLOOR | 1 | 1 | 0 | 0.00 | - | - |
| EDGE GIVE GROUND | 2 | 1 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT LIFT | 2 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 192 | not checked | - | - | - | - |
| GIVES UP | 30 | 29 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 4 | 4 | 0 | 0.00 | - | - |
| GROUND FLIERS | 1 | not checked | - | - | - | - |
| HELPER ALREADY ASKED | 1 | not checked | - | - | - | - |
| HELPER UNSEEN | 3 | 3 | 0 | 0.00 | - | - |
| HILL BY ITS CHANCE | 6 | 6 | 0 | 0.00 | - | - |
| HUNT DROPPED | 3 | trace | - | - | - | - |
| HUNT KEPT | 16 | trace | - | - | - | - |
| HUNT RESULT | 7 | trace | - | - | - | - |
| HUNT THE GUNS | 9 | trace | - | - | - | - |
| KEEPS ITS PREY | 5 | 5 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 23 | not checked | - | - | - | - |
| LONE WIZARD HOLDS BACK | 1 | 1 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 4 | trace | - | - | - | - |
| MARCH OVER CASTS | 20 | 20 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 19 | 19 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 9 | 6 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 13 | trace | - | - | - | - |
| MOVE SPELL SPOT | 13 | not checked | - | - | - | - |
| NOT NEEDED | 5 | 5 | 0 | 0.00 | - | - |
| NOT TURNED | 197 | 197 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 12 | not checked | - | - | - | - |
| OPENS A LANE | 4 | 2 | 0 | 0.00 | - | - |
| PLAN RESULT | 1450 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 2 | 2 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 2 | 2 | 0 | 0.00 | - | - |
| SCOUT SPOT | 14 | 14 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 1 | 1 | 0 | 0.00 | - | - |
| SECOND HUNTER | 1 | 1 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 6 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 24 | not checked | - | - | - | - |
| SET-UP MISSED | 3 | trace | - | - | - | - |
| SPELL CATCH ODDS | 5 | not checked | - | - | - | - |
| SPELL SETS UP CHARGE | 26 | not checked | - | - | - | - |
| SPELL WORTH | 66 | not checked | - | - | - | - |
| STABLE ROLE | 243 | 243 | 0 | 0.00 | - | - |
| SUPPORT NARROWED | 87 | 87 | 0 | 0.00 | - | - |
| WAR ENGINE CHARGES | 2 | 2 | 0 | 0.00 | - | - |

### Off best figure: fw-h2h2-mine-1eea44e-p3

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 14.60 | 12.80 | 58.3 |
| FALLBACK | gate | 0.50 | 0.95 | 45.5 |
| TURN GATE | gate | 0.50 | 0.30 | 46.9 |
| RULE SWITCHED OFF | gate | - | 0.65 | 4.9 |
| THROUGH LINE OF FIRE | rule | 0.45 | 0.05 | 22.8 |
| CANNON PLANNED TARGET | rule | 0.30 | 0.15 | 80.0 |
| CHARGE NOW FIRST | rule | 0.45 | - | 57.9 |
| PIVOT GUARDS FLANK | rule | 0.35 | 0.10 | 31.9 |
| WAR ENGINE JOBS | rule | 0.45 | - | 28.6 |
| CHARGE NOW WEIGHED | rule | 0.30 | 0.10 | 41.0 |
| LONE CHARACTER SAFE SPOT | gate | 0.25 | 0.10 | 92.9 |
| CHAFF PASSED | rule | - | 0.30 | 5.3 |
| SUPPORT REQUEST | gate | 0.05 | 0.25 | 75.2 |
| PATHS CROSS | rule | 0.05 | 0.20 | 41.8 |
| PURSUES BIG PREY | rule | 0.20 | 0.05 | 98.1 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.15 | 0.05 | 49.8 |
| BIG CHARACTER SAFETY | rule | 0.05 | 0.15 | 14.4 |
| AFTERMATH BAND | gate | 0.15 | - | 3.4 |
| CATCH ODDS | rule | - | 0.15 | 4.0 |
| NO REASON | gate | 0.15 | - | 8.2 |
| BEST PRIZE | rule | 0.10 | - | 84.2 |
| DEFENSIVE ARMY | rule | 0.10 | - | 13.1 |
| SAFER THAN THE JOB | rule | 0.05 | 0.05 | 15.3 |
| SURE CHARGE BEATS ADVANCE | rule | - | 0.10 | 45.9 |
| BLOCKED WHEEL | rule | - | 0.05 | 18.6 |
| CARRIES OUT SET-UP | rule | 0.05 | - | 195.3 |
| CHARIOT NO STATIC JOB | rule | - | 0.05 | 4.5 |
| FACES THE THREAT | rule | - | 0.05 | 23.3 |
| FIGHT ORDER BAND | gate | 0.05 | - | 2.1 |
| FOLLOW UP WEIGHED | rule | 0.05 | - | 3.1 |
| STANDS TO CAST | rule | 0.05 | - | 14.4 |
| STOPS SHORT OF THE FLANK | rule | - | 0.05 | 3.8 |
| SUPPORT JOB KEPT | rule | - | 0.05 | 27.0 |

### Plans: fw-h2h2-mine-1eea44e-p3

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 11.0 | 14% | 318 | 292 | 92% |
| Mine | charge | 2.6 | 55% | 223 | 215 | 96% |
| Mine | close in | 3.8 | 18% | 225 | 103 | 46% |
| Mine | hold | 4.8 | 41% | 284 | 0 | 0% |
| Mine | join | 0.7 | 85% | 12 | 0 | 0% |
| Mine | shoot | 12.7 | 62% | 295 | 921 | 312% |
| Mine | support | 2.6 | 94% | 27 | 0 | 0% |
| Opponent | advance | 12.1 | 15% | 475 | 364 | 77% |
| Opponent | charge | 3.5 | 55% | 405 | 322 | 80% |
| Opponent | close in | 5.8 | 19% | 404 | 102 | 25% |
| Opponent | hold | 3.5 | 33% | 319 | 0 | 0% |
| Opponent | join | 0.4 | 88% | 15 | 0 | 0% |
| Opponent | shoot | 5.5 | 59% | 175 | 337 | 193% |
| Opponent | support | 3.7 | 78% | 162 | 0 | 0% |

### Packages: hunt the guns, fw-h2h2-mine-1eea44e-p3

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.2 | 4 | 2 | 0% | 0% | 0% | - | 362 | 0 | 0% | 27 |
| Opponent | 0.2 | 5 | 0 | 20% | 20% | 0% | 3.0 | 314 | 33 | 20% | 176 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 1.0 | 4 | 2 | 0% | 0% | 0% | - | 362 | 0 | 0% | 42 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 124 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| High Elf Realms | 0.3 | 1 | 0 | 0% | 0% | 0% | - | 581 | 0 | 0% | 324 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 286 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 65 |
| Tomb Kings of Khemri | 0.5 | 1 | 0 | 0% | 0% | 0% | - | 298 | 0 | 0% | 349 |
| Vampire Counts | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 19 |
| Warriors of Chaos | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 295 |
| Wood Elf Realms | 3.0 | 3 | 0 | 33% | 33% | 0% | 3.0 | 231 | 54 | 33% | 253 |

### Battle groups: fw-h2h2-mine-1eea44e-p3

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 8.8 | 17% | 43% | 10% | 67% | 26% | 19% | 4% | 52% | 0% |
| Mine | REDIRECT COUNTER | 1.1 | 24% | 100% | 0% | - | 20% | 0% | 0% | 80% | 0% |
| Opponent | COUNTER-CHARGE COVER | 6.2 | 16% | 90% | 15% | 33% | 41% | 12% | 12% | 35% | 0% |
| Opponent | REDIRECT COUNTER | 1.8 | 39% | 93% | 0% | - | 7% | 0% | 7% | 79% | 7% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: fw-h2h2-mine-1eea44e-p3

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 13 | 16 (13) | 0 | 16 | 25 | 62% | 2.4 | 25 (9) | 0 (2) | 0 (2) | 23 (9) | 0 (4) |
| Mine | Character | 80 | 43 (80) | 43 | 0 | 48 | 28% | 2.4 | 70 (24) | 40 (37) | 28 (7) | 70 (37) | 24 (31) |
| Mine | Clean-up | 8 | 105 (8) | 23 | 81 | 10 | 38% | 3.2 | 146 (3) | 44 (3) | 52 (2) | 130 (5) | 29 (3) |
| Mine | Fast Hammer | 22 | 33 (22) | 25 | 8 | 49 | 32% | 2.5 | 31 (11) | 40 (7) | 28 (4) | 37 (17) | 23 (5) |
| Mine | Hammer | 34 | 28 (34) | 17 | 11 | 33 | 26% | 2.7 | 19 (7) | 31 (24) | 35 (3) | 36 (22) | 17 (12) |
| Mine | Holder | 15 | 70 (15) | 0 | 70 | 19 | 73% | 4.5 | 41 (5) | 87 (7) | 75 (3) | 91 (10) | 32 (5) |
| Mine | Shooter | 22 | 113 (22) | 52 | 61 | 24 | 5% | 1.9 | 57 (4) | 120 (17) | 160 (1) | 90 (14) | 142 (8) |
| Mine | War machine | 46 | 60 (46) | 60 | 0 | 28 | 2% | 1.0 | 42 (13) | 72 (30) | 20 (3) | 21 (13) | 76 (33) |
| Mine | Wizard | 7 | 21 (7) | 21 | 0 | 26 | 14% | 2.2 | 0 (1) | 51 (3) | 0 (2) | 0 (3) | 44 (3) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Chaff | 37 | 29 (37) | 5 | 24 | 67 | 51% | 2.6 | 65 (17) | 0 (5) | 3 (15) | 35 (26) | 15 (11) |
| Opponent | Character | 55 | 48 (55) | 48 | 0 | 32 | 25% | 2.1 | 55 (21) | 53 (25) | 33 (4) | 75 (23) | 35 (27) |
| Opponent | Clean-up | 9 | 39 (9) | 16 | 23 | 35 | 22% | 3.1 | 36 (4) | 14 (4) | 217 (1) | 67 (5) | 15 (4) |
| Opponent | Fast Hammer | 27 | 50 (27) | 34 | 16 | 57 | 37% | 2.2 | 28 (14) | 46 (10) | 168 (3) | 60 (13) | 42 (14) |
| Opponent | Fragile | 3 | 0 (3) | 0 | 0 | 33 | 67% | 2.0 | - | 0 (2) | 0 (1) | 0 (2) | 0 (1) |
| Opponent | Hammer | 16 | 35 (16) | 25 | 10 | 28 | 50% | 2.2 | 0 (3) | 41 (13) | - | 15 (12) | 94 (4) |
| Opponent | Holder | 24 | 48 (24) | 0 | 48 | 30 | 46% | 2.4 | 14 (5) | 64 (17) | 0 (2) | 49 (17) | 46 (7) |
| Opponent | Shooter | 14 | 70 (14) | 57 | 12 | 40 | 7% | 1.2 | 114 (6) | 6 (5) | 82 (3) | 68 (12) | 82 (2) |
| Opponent | Support | 2 | 0 (2) | 0 | 0 | 50 | 50% | 4.0 | - | - | 0 (2) | 0 (1) | 0 (1) |
| Opponent | War machine | 17 | 27 (17) | 27 | 0 | 43 | 6% | 1.3 | 0 (3) | 5 (10) | 86 (4) | 0 (3) | 31 (14) |
| Opponent | Wizard | 18 | 29 (18) | 29 | 0 | 19 | 28% | 2.1 | 0 (6) | 100 (5) | 0 (3) | 11 (8) | 62 (6) |

### Charged fights: fw-h2h2-mine-1eea44e-p3

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 176 | 11 | 0.8 | 1.0 | 15 | 0 | +15 | 0 of 3 | 2 of 3 | - | +15 |
| Mine | Chaos Dwarfs | 4 | 56 | 493 | 3.2 | 1.2 | 152 | 24 | +128 | 4 of 13 | 11 of 13 | +0 | +138 |
| Mine | Dwarfen Mountain Holds | 3 | 368 | 0 | 1.0 | 1.0 | 0 | 42 | -42 | 0 of 3 | 2 of 3 | - | -42 |
| Mine | Empire of Man | 5 | 466 | 118 | 2.0 | 1.1 | 59 | 26 | +32 | 0 of 10 | 7 of 10 | +0 | +36 |
| Mine | Grand Cathay | 4 | 816 | 204 | 3.5 | 1.2 | 58 | 15 | +44 | 3 of 14 | 8 of 14 | +40 | +44 |
| **Mine** | all armies | 20 | 381 | 171 | 2.1 | 1.1 | 80 | 21 | +59 | 7 of 43 | 30 of 43 | +20 | +63 |
| Opponent | Empire of Man | 1 | 299 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Grand Cathay | 3 | 74 | 220 | 4.0 | 1.3 | 55 | 41 | +14 | 4 of 12 | 7 of 12 | -96 | +51 |
| Opponent | High Elf Realms | 3 | 398 | 248 | 1.3 | 1.0 | 186 | 87 | +99 | 4 of 4 | 3 of 4 | - | +99 |
| Opponent | Kingdom of Bretonnia | 2 | 186 | 684 | 3.5 | 1.1 | 196 | 141 | +55 | 5 of 7 | 3 of 7 | -139 | +87 |
| Opponent | Skaven | 1 | 0 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 0 of 1 | 1 of 1 | - | +0 |
| Opponent | Tomb Kings of Khemri | 2 | 0 | 860 | 2.5 | 1.4 | 344 | 83 | +261 | 4 of 5 | 3 of 5 | +323 | +219 |
| Opponent | Vampire Counts | 4 | 21 | 612 | 3.2 | 1.2 | 188 | 4 | +185 | 9 of 13 | 9 of 13 | +274 | +168 |
| Opponent | Warriors of Chaos | 3 | 0 | 420 | 1.3 | 1.2 | 315 | 146 | +168 | 4 of 4 | 3 of 4 | +310 | +121 |
| Opponent | Wood Elf Realms | 1 | 0 | 212 | 2.0 | 1.0 | 106 | 0 | +106 | 0 of 2 | 2 of 2 | - | +106 |
| **Opponent** | all armies | 20 | 109 | 421 | 2.4 | 1.2 | 175 | 60 | +115 | 30 of 48 | 31 of 48 | +120 | +114 |

### Effective charges: fw-h2h2-mine-1eea44e-p3

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 3 | 1 (net +0) | 0 | 1 (net +0) | 0 | 0 | 1 (net +45) | 0 | 33% (1 of 3) |
| Mine | Chaos Dwarfs | 13 | 0 | 0 | 3 (net +315) | 2 (net +76) | 2 (net +15) | 5 (net +72) | 1 | 25% (3 of 12) |
| Mine | Dwarfen Mountain Holds | 3 | 0 | 1 (net -65) | 0 | 0 | 0 | 2 (net -30) | 0 | 0% (0 of 3) |
| Mine | Empire of Man | 10 | 1 (net +217) | 0 | 2 (net -132) | 0 | 2 (net +72) | 5 (net +46) | 0 | 20% (2 of 10) |
| Mine | Grand Cathay | 14 | 4 (net +34) | 0 | 0 | 1 (net +0) | 2 (net +68) | 7 (net +49) | 0 | 0% (0 of 14) |
| Opponent | Grand Cathay | 12 | 2 (net +0) | 0 | 1 (net +140) | 0 | 4 (net +76) | 3 (net -68) | 2 | 10% (1 of 10) |
| Opponent | High Elf Realms | 4 | 1 (net -347) | 0 | 1 (net +0) | 0 | 0 | 2 (net +372) | 0 | 25% (1 of 4) |
| Opponent | Kingdom of Bretonnia | 7 | 0 | 1 (net +190) | 1 (net +185) | 0 | 0 | 5 (net +1) | 0 | 14% (1 of 7) |
| Opponent | Tomb Kings of Khemri | 5 | 0 | 0 | 0 | 2 (net +374) | 0 | 2 (net +278) | 1 | 0% (0 of 4) |
| Opponent | Vampire Counts | 13 | 3 (net +350) | 0 | 1 (net +547) | 4 (net +182) | 1 (net +125) | 3 (net -17) | 1 | 8% (1 of 12) |
| Opponent | Warriors of Chaos | 4 | 0 | 2 (net -138) | 0 | 1 (net +369) | 0 | 1 (net +580) | 0 | 0% (0 of 4) |

### Charged fights, damage counted: fw-h2h2-mine-1eea44e-p3

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 6 | 235 | 216 | +59 | 112 | 85 | +27 | +11.3 |
| Mine | 50-54% | 1 | 65 | 104 | -65 | 0 | 65 | -65 | -100.0 |
| Mine | Effective (55-75%) | 6 | 254 | 270 | +113 | 178 | 62 | +115 | +45.3 |
| Mine | 76-89% | 3 | 318 | 146 | +50 | 124 | 0 | +124 | +39.0 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 20 | 219 | 139 | +46 | 87 | 23 | +64 | +29.2 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 6 | 401 | 86 | +52 | 74 | 1 | +74 | +18.3 |
| Mine | No odds | 1 | 480 | 177 | +177 | 177 | 0 | +177 | +36.9 |
| Mine | All fights | 43 | 261 | 161 | +59 | 104 | 33 | +71 | +27.2 |
| Opponent | Long shot (under 50%) | 6 | 412 | 417 | +117 | 209 | 144 | +65 | +15.9 |
| Opponent | 50-54% | 3 | 339 | 246 | -28 | 167 | 195 | -28 | -8.3 |
| Opponent | Effective (55-75%) | 4 | 496 | 259 | +218 | 218 | 46 | +172 | +34.6 |
| Opponent | 76-89% | 7 | 339 | 247 | +264 | 306 | 75 | +231 | +68.4 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 16 | 371 | 273 | +102 | 217 | 136 | +81 | +21.9 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 5 | 358 | 86 | +86 | 86 | 0 | +86 | +24.1 |
| Opponent | No odds | 7 | 210 | 146 | +19 | 95 | 44 | +51 | +24.4 |
| Opponent | All fights | 48 | 355 | 246 | +115 | 195 | 97 | +98 | +27.6 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| fw-h2h2-mine-1eea44e-p3 | move | 223 | 39 (17%) | 26 (12%) | 26 (12%) | 158 (71%) |
| fw-h2h2-mine-1eea44e-p3 | objective | 191 | 22 (12%) | 15 (8%) | 25 (13%) | 144 (75%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0110, L0126 |
| Charmed Shield | Opponent | L0126, L0226, L0327, L0725 |
| Clockwork Compass | Mine | L1216 |
| Elixir of Power | Mine | L1122 |
| Elixir of Power | Opponent | L0311 |
| Horn of the Wild Hunt | Opponent | L0533 |
| Invocation of Nehek | Opponent | L0327, L0725 |
| Periapt of Soul Exchange | Opponent | L0620 |
| Ring of Doom | Mine | L0210, L0226, L1122, L1216 |
| Ring of Doom | Opponent | L0311, L0533, L0815, L0831 |
| Ring of Jet | Mine | L1013, L1030, L1122, L1216 |
| Ring of Jet | Opponent | L0110, L0210, L0311 |
| Standard of the Fell Warrior | Opponent | L0413, L1013 |
| Twice-Blessed Armour | Mine | L0709, L0725, L1013, L1030 |
| Twice-Blessed Armour | Opponent | L0110, L0210 |
| Witch Hunter's Ward | Mine | L0709, L0725, L0815, L0831 |

# Doctrine scorecard: fw-h2h2-opp-1eea44e-p4

### Scorecard: fw-h2h2-opp-1eea44e-p4

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0114 | 6 | 1 | Mine | no | 5 | - | 1 | 1 | 0 | 0 | 0 | 0 |
| L0114 | 6 | 1 | Opponent | no | 11 | 2 | 3 | 2 | 0 | 0 | 0 | 0 |
| L0130 | 4 | 1 | Mine | yes | 5 | - | 0 | 1 | 0 | 0 | 0 | 0 |
| L0130 | 4 | 1 | Opponent | no | 0 | 1 | 7 | 3 | 1 | 0 | 0 | 0 |
| L0214 | 4 | 1 | Mine | no | 2 | 2 | 3 | 2 | 0 | 0 | 0 | 170 |
| L0214 | 4 | 1 | Opponent | no | 0 | 2 | 4 | 1 | 0 | 0 | 0 | 177 |
| L0230 | 2 | 1 | Mine | - | - | - | 3 | 4 | 0 | 0 | 0 | 170 |
| L0230 | 2 | 1 | Opponent | - | - | 2 | 1 | 0 | 0 | 0 | 0 | 0 |
| L0315 | 3 | 1 | Mine | no | 6 | - | 0 | 1 | 0 | 0 | 0 | 985 |
| L0315 | 3 | 1 | Opponent | yes | 2 | 2 | 3 | 2 | 1 | 0 | 0 | 0 |
| L0332 | 2 | 1 | Mine | - | - | - | 0 | 1 | 0 | 0 | 0 | 590 |
| L0332 | 2 | 1 | Opponent | - | - | 2 | 5 | 2 | 1 | 0 | 0 | 0 |
| L0417 | 3 | 1 | Mine | yes | 2 | 3 | 4 | 1 | 1 | 0 | 0 | 0 |
| L0417 | 3 | 1 | Opponent | yes | 5 | 1 | 4 | 1 | 1 | 0 | 0 | 0 |
| L0434 | 2 | 1 | Mine | - | - | 3 | 2 | 2 | 1 | 0 | 0 | 0 |
| L0434 | 2 | 1 | Opponent | - | - | 1 | 4 | 0 | 0 | 0 | 0 | 0 |
| L0520 | 4 | 1 | Mine | no | 0 | 4 | 1 | 0 | 0 | 0 | 0 | 1193 |
| L0520 | 4 | 1 | Opponent | no | 2 | 4 | 1 | 4 | 0 | 0 | 0 | 210 |
| L0608 | 2 | 1 | Mine | - | - | - | 1 | 3 | 1 | 0 | 0 | 926 |
| L0608 | 2 | 1 | Opponent | - | - | 3 | 1 | 1 | 0 | 0 | 0 | 605 |
| L0624 | 6 | 1 | Mine | no | 2 | 3 | 2 | 1 | 0 | 0 | 0 | 615 |
| L0624 | 6 | 1 | Opponent | no | 5 | 3 | 1 | 0 | 1 | 0 | 0 | 0 |
| L0713 | 5 | 1 | Mine | yes | - | 3 | 2 | 2 | 0 | 0 | 0 | 372 |
| L0713 | 5 | 1 | Opponent | no | - | 2 | 3 | 2 | 1 | 0 | 0 | 479 |
| L0729 | 3 | 1 | Mine | no | 3 | 1 | 3 | 0 | 0 | 0 | 0 | 375 |
| L0729 | 3 | 1 | Opponent | no | 0 | 2 | 4 | 0 | 1 | 0 | 0 | 0 |
| L0819 | 3 | 1 | Mine | no | 0 | 6 | 1 | 1 | 0 | 0 | 0 | 1007 |
| L0819 | 3 | 1 | Opponent | no | 6 | 2 | 1 | 2 | 2 | 0 | 0 | 647 |
| L0835 | 1 | 1 | Mine | no | 0 | - | 1 | 1 | 0 | 0 | 0 | 515 |
| L0835 | 1 | 1 | Opponent | no | 0 | 2 | 5 | 2 | 0 | 0 | 0 | 0 |
| L0926 | 2 | 1 | Mine | - | - | 2 | 2 | 0 | 0 | 0 | 0 | 492 |
| L0926 | 2 | 1 | Opponent | - | - | 2 | 1 | 4 | 1 | 0 | 0 | 0 |
| L1017 | 3 | 1 | Mine | no | 2 | 2 | 2 | 0 | 0 | 0 | 0 | 330 |
| L1017 | 3 | 1 | Opponent | yes | 0 | 2 | 3 | 4 | 1 | 0 | 0 | 175 |
| L1034 | 2 | 1 | Mine | - | - | 1 | 1 | 0 | 0 | 0 | 0 | 330 |
| L1034 | 2 | 1 | Opponent | - | - | 2 | 4 | 2 | 0 | 0 | 0 | 0 |
| L1126 | 4 | 1 | Mine | no | 0 | 2 | 3 | 0 | 0 | 0 | 0 | 330 |
| L1126 | 4 | 1 | Opponent | no | 2 | 2 | 4 | 3 | 1 | 0 | 0 | 0 |
| L1220 | 2 | 1 | Mine | - | - | 3 | 2 | 0 | 0 | 0 | 0 | 330 |
| L1220 | 2 | 1 | Opponent | - | - | - | 2 | 5 | 0 | 0 | 0 | 0 |
| L1314 | 6 | 1 | Mine | no | 2 | 3 | 3 | 0 | 1 | 0 | 0 | 140 |
| L1314 | 6 | 1 | Opponent | no | 2 | 2 | 4 | 1 | 0 | 0 | 0 | 177 |
| L1331 | 5 | 1 | Mine | yes | - | 3 | 2 | 2 | 0 | 0 | 0 | 302 |
| L1331 | 5 | 1 | Opponent | yes | - | 3 | 2 | 2 | 2 | 0 | 0 | 340 |
| L1427 | 5 | 1 | Mine | no | - | 4 | 2 | 2 | 0 | 0 | 0 | 177 |
| L1427 | 5 | 1 | Opponent | yes | - | 2 | 3 | 4 | 0 | 0 | 0 | 0 |
| L1523 | 5 | 1 | Mine | yes | - | 2 | 3 | 2 | 1 | 0 | 0 | 0 |
| L1523 | 5 | 1 | Opponent | no | - | 3 | 4 | 2 | 1 | 0 | 0 | 185 |
| L1621 | 1 | 1 | Mine | no | 4 | 3 | 5 | 1 | 0 | 0 | 0 | 200 |
| L1621 | 1 | 1 | Opponent | no | 0 | - | 3 | 1 | 0 | 0 | 0 | 290 |
| L1719 | 3 | 1 | Mine | yes | 7 | 2 | 4 | 0 | 0 | 0 | 0 | 0 |
| L1719 | 3 | 1 | Opponent | yes | 3 | 2 | 7 | 0 | 0 | 0 | 0 | 0 |
| L1819 | 1 | 1 | Mine | no | 1 | 4 | 6 | 3 | 0 | 0 | 0 | 0 |
| L1819 | 1 | 1 | Opponent | no | 0 | 2 | 4 | 1 | 1 | 0 | 0 | 255 |
| L1835 | 5 | 1 | Mine | yes | - | 3 | 1 | 2 | 1 | 0 | 0 | 0 |
| L1835 | 5 | 1 | Opponent | no | - | 4 | 2 | 4 | 0 | 0 | 0 | 110 |
| L2021 | 5 | 1 | Mine | no | - | 6 | 1 | 3 | 1 | 0 | 0 | 210 |
| L2021 | 5 | 1 | Opponent | yes | - | - | 1 | 6 | 0 | 0 | 0 | 145 |
| L2123 | 5 | 1 | Mine | yes | - | - | 1 | 5 | 1 | 0 | 0 | 1227 |
| L2123 | 5 | 1 | Opponent | yes | - | 2 | 6 | 1 | 0 | 0 | 0 | 0 |
| L2227 | 1 | 1 | Mine | yes | 1 | 1 | 5 | 0 | 0 | 0 | 0 | 170 |
| L2227 | 1 | 1 | Opponent | yes | 5 | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L2331 | 3 | 1 | Mine | no | 1 | 4 | 4 | 0 | 1 | 0 | 0 | 66 |
| L2331 | 3 | 1 | Opponent | no | 3 | 2 | 4 | 2 | 1 | 0 | 0 | 201 |
| L2527 | 1 | 1 | Mine | no | 1 | 4 | 3 | 3 | 0 | 0 | 0 | 0 |
| L2527 | 1 | 1 | Opponent | no | 0 | 3 | 3 | 2 | 0 | 0 | 0 | 0 |
| L2634 | 6 | 1 | Mine | no | 7 | 2 | 1 | 1 | 2 | 0 | 0 | 0 |
| L2634 | 6 | 1 | Opponent | no | 0 | 1 | 6 | 2 | 0 | 0 | 0 | 109 |
| L2930 | 2 | 1 | Mine | - | - | 2 | 4 | 1 | 0 | 0 | 0 | 323 |
| L2930 | 2 | 1 | Opponent | - | - | 2 | 6 | 1 | 0 | 0 | 0 | 80 |
| L3234 | 6 | 1 | Mine | no | 4 | 2 | 3 | 1 | 0 | 0 | 0 | 170 |
| L3234 | 6 | 1 | Opponent | no | 0 | 3 | 4 | 0 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 32% | 2.6 | 2.9 | 2.3 | 1.3 | 0.3 | 0.0 | 0.0 | 325.4 |
| **Average** | | | Opponent | 32% | 2.2 | 2.2 | 3.4 | 1.9 | 0.5 | 0.0 | 0.0 | 116.2 |

### KPIs: fw-h2h2-opp-1eea44e-p4

Rules off - Mine only: WAR ENGINE JOBS, STAY WEIGHED, BEST FIRST, RANDOM MOVE BY FIGURES, RANDOM MOVER NO PROMISE, STABLE ROLE, WOUNDED STAYS OUT, BEST FACING, LOST CHARGE, SCREEN BY WHAT IT SAVES, REDIRECT BY WHAT IT STOPS, SHOOTER COUNTED ONCE, LURE BY WHAT IT DRAWS, HILL BY ITS CHANCE, MOVE TO CHARGE, LONG SHOT, DEFENSIVE ARMY, SHOOTS FROM THE BEST SPOT, SUPPORTS, RESERVE FALL BACK, WAIT AFTER COSTS, CHARGE NOW FIRST, SUPPORT NARROWED, WAR ENGINE CHARGES, DEFENSIVE FLOOR.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 177) | 2% (4 of 185) | 1% (4 of 362) |
| Winner chose to follow up after the loser gave ground |  | 97% (62 of 64); on the table 98% | 100% (62 of 62); on the table 100% | 98% (124 of 126); on the table 99% |
| Winner chose to pursue after the loser fell back in good order |  | 91% (10 of 11); on the table 100% | 69% (11 of 16); on the table 81% | 78% (21 of 27); on the table 89% |
| Winner chose to pursue after the loser fled |  | 86% (19 of 22); on the table 91% | 77% (17 of 22); on the table 86% | 82% (36 of 44); on the table 89% |
| Winner chose to follow up or pursue (all three) |  | 94% (91 of 97); on the table 97% | 90% (90 of 100); on the table 94% | 92% (181 of 197); on the table 95% |
| Magic missiles tried each own turn | 50%+ | 26% (71 of 269) | 39% (68 of 175) | 31% (139 of 444) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 40% (71 of 176) | 50% (68 of 136) | 45% (139 of 312) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 62% (46 of 74) | 62% (46 of 74) |
| Points that never fought | lower | 33% (22562 of 67942) | 36% (26082 of 71984) | 35% (48644 of 139926) |
|   infantry points that never fought | lower | 39% (6046 of 15347) | 56% (7711 of 13804) | 47% (13757 of 29151) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 62% (168 of 270) | 54% (151 of 280) | 58% (319 of 550) |
| Bound items with a magic missile used (at least once a game) |  | 91% (20 of 22); 1.7 uses a game | 89% (8 of 9); 0.7 uses a game | 90% (28 of 31); 1.2 uses a game |
| Bound items with another spell used |  | 56% (9 of 16); 0.4 uses a game | 40% (8 of 20); 0.5 uses a game | 47% (17 of 36); 0.5 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 58% (11 of 19); 0.3 uses a game | 60% (9 of 15); 0.3 uses a game | 59% (20 of 34); 0.3 uses a game |
|   their share of the points of units over 100 pts | lower | 57% (32942 of 57750) | 48% (30666 of 63347) | 53% (63608 of 121097) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.5 (27%) | 1.1 (36%) | 2.6 (30%) |
| MARCHED: its unit marched | 0.9 (17%) | 0.4 (13%) | 1.3 (16%) |
| CHARGED: its unit charged | 0.1 (2%) | 0.1 (3%) | 0.2 (2%) |
| IN COMBAT: engaged in combat | 1.3 (23%) | 0.4 (13%) | 1.7 (20%) |
| REAR RANK: in a rear rank | 0.3 (6%) | 0.3 (11%) | 0.7 (8%) |
| FLEEING: fleeing | 0.0 (1%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | 1.3 (23%) | 0.4 (14%) | 1.7 (20%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (0%) | 0.3 (9%) | 0.3 (3%) |
| STUPIDITY: Stupidity | 0.0 (1%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (1%) | 0.0 (0%) | 0.0 (0%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.0 | 1.4 | 1.9 | 3.9 | 0.3 | 2.3 |
| not cast | 3.2 | 2.4 | 2.9 | 8.5 | 1.7 | 20.7 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.9 (9%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.3 (55%) | 0.1 (4%) | 2.6 (30%) | 0.2 (15%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.3 (16%) | 0.4 (23%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (2%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.2 (5%) | 0.2 (10%) | 0.4 (14%) | 1.7 (20%) | 0.2 (13%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.2 (5%) | 0.2 (7%) | 0.6 (19%) | 0.7 (8%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (1%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (1%) |
| GONE: slain | 0.9 (29%) | 0.4 (17%) | 0.5 (18%) | 1.7 (20%) | 0.4 (21%) | 2.7 (13%) |
| OFF THE TABLE: off the table or not arrived | 0.2 (6%) | 0.0 (1%) | 0.2 (6%) | 0.3 (3%) | 0.0 (0%) | 0.8 (4%) |
| STUPIDITY: Stupidity | 0.1 (4%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (2%) | 0.1 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.2 (9%) | 0.0 (1%) | 0.0 (0%) | 0.4 (26%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.6 (50%) | 0.0 (1%) | 1.1 (39%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 15.0 (73%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.3 a game | 0.6 a game | 1.0 a game |
| stood (cast and not dispelled) | 60% (25 of 42) | 67% (10 of 15) | 61% (35 of 57) |
| the unit moved after it | 84% (21 of 25) | 80% (8 of 10) | 83% (29 of 35) |
| it charged on its next turn | 4% (1 of 25) | 0% (0 of 10) | 3% (1 of 35) |
| the enemy charged it first | 20% (5 of 25) | 10% (1 of 10) | 17% (6 of 35) |
| it fought by the end of its next turn | 12% (3 of 25) | 20% (2 of 10) | 14% (5 of 35) |
| it moved out of a charge the enemy had planned (not charged first) | 12% (3 of 25) | 0% (0 of 10) | 9% (3 of 35) |
| none of these (no charge, no fight, no charge escaped) | 60% (15 of 25) | 80% (8 of 10) | 66% (23 of 35) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 62% (535 of 861) | 52% (283 of 541) | 58% (818 of 1402) |
|   cavalry | 62% (43 of 69) | 72% (86 of 119) | 69% (129 of 188) |
|   character | 40% (42 of 104) | 14% (17 of 125) | 26% (59 of 229) |
|   chariot | 52% (56 of 107) | 48% (10 of 21) | 52% (66 of 128) |
|   infantry | 52% (132 of 254) | 64% (141 of 219) | 58% (273 of 473) |
|   monster | 47% (20 of 43) | 24% (6 of 25) | 38% (26 of 68) |
|   war machine | 85% (242 of 284) | 72% (23 of 32) | 84% (265 of 316) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.6 (29%) | 1.5 (21%) | 4.1 (25%) |
| CHARGED: it charged | 1.4 (16%) | 1.8 (25%) | 3.2 (20%) |
| FLEEING: it fled or was fleeing | 0.2 (2%) | 0.0 (0%) | 0.2 (1%) |
| IN COMBAT: it fought this turn or the last | 0.9 (10%) | 0.4 (6%) | 1.3 (8%) |
| MOVED: a war machine that moved | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| NO TARGET IN RANGE | 1.8 (20%) | 1.2 (16%) | 3.0 (18%) |
| ONLY IN COMBAT: the only targets were in combat | 0.4 (4%) | 0.6 (9%) | 1.0 (6%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.2 (13%) | 1.3 (18%) | 2.5 (15%) |
| SHELTERED: the target was sheltered | 0.2 (3%) | 0.2 (3%) | 0.5 (3%) |
| OTHER BAR | 0.2 (3%) | 0.1 (1%) | 0.3 (2%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 6.0 | 1.9 | 78% | 6.2 pts | 37 pts |
| character | 1.9 | 0.4 | 82% | 4.9 pts | 9 pts |
| chariot | 1.9 | 1.0 | 72% | 14.8 pts | 28 pts |
| infantry | 11.4 | 4.5 | 76% | 8.5 pts | 97 pts |
| monster | 0.8 | 0.4 | 75% | 14.2 pts | 11 pts |
| war machine | 7.4 | 7.7 | 64% | 43.5 pts | 320 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.8 | 6.4 | 5.1 |
| Charges that made contact a game | 3.0 | 4.6 | 3.8 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.88 declared, 0.76 contact (17 units) | 0.33 declared, 0.20 contact (15 units) | 0.62 declared, 0.50 contact (32 units) |
|   per unit a game, units carrying another wizard (or one alone) | 1.00 declared, 0.71 contact (7 units) | 1.77 declared, 1.15 contact (13 units) | 1.50 declared, 1.00 contact (20 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.45 declared, 0.36 contact (251 units) | 0.68 declared, 0.49 contact (300 units) | 0.58 declared, 0.43 contact (551 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 47% (38 of 81) | 44% (7 of 16) | 50% (3 of 6) | 47% (48 of 103) |
| Character in a unit | 86% (24 of 28) | 76% (13 of 17) | 100% (1 of 1) | 83% (38 of 46) |
| Character on its own | 81% (30 of 37) | 52% (13 of 25) | 31% (24 of 77) | 48% (67 of 139) |
| Chariot | 60% (9 of 15) | 58% (7 of 12) | - | 59% (16 of 27) |
| Infantry | 60% (50 of 83) | 52% (13 of 25) | 33% (2 of 6) | 57% (65 of 114) |
| Monster | 62% (21 of 34) | 71% (10 of 14) | - | 65% (31 of 48) |
| Monstrous | 64% (9 of 14) | 64% (9 of 14) | - | 64% (18 of 28) |
| War Machines | 79% (34 of 43) | 100% (2 of 2) | - | 80% (36 of 45) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 100% (10 of 10); on the table 100% | 24% (24 of 102) | 14% | 73% (16 of 22) | 83% (5 of 6); 4.0 uses a game | 100% (2 of 2); 0.8 uses a game | 100% (6 of 6); 1.5 uses a game |
| Chaos Dwarfs | 4 | 100% (10 of 10); on the table 100% | 46% (11 of 24) | 29% | 53% (17 of 32) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
| Dwarfen Mountain Holds | 3 | 100% (6 of 6); on the table 100% | - | 72% | 78% (21 of 27) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 6 | 92% (11 of 12); on the table 92% | 17% (3 of 18) | 49% | 65% (40 of 62) | 0.0 uses a game | 100% (2 of 2); 0.7 uses a game | 80% (4 of 5); 0.7 uses a game |
| Grand Cathay | 4 | 91% (10 of 11); on the table 100% | 33% (28 of 84) | 39% | 62% (23 of 37) | 100% (9 of 9); 6.2 uses a game | 0% (0 of 2); 0.0 uses a game | 0% (0 of 4); 0.0 uses a game |
| High Elf Realms | 9 | 95% (19 of 20); on the table 95% | 14% (5 of 36) | 38% | 54% (38 of 70) | 100% (7 of 7); 2.9 uses a game | 43% (13 of 30); 2.9 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | 100% (6 of 6); on the table 100% | - | 29% | 33% (2 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Lizardmen | 3 | 94% (17 of 18); on the table 94% | 100% (6 of 6) | 33% | 62% (13 of 21) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 2 | 60% (3 of 5); on the table 80% | 17% (1 of 6) | 66% | 71% (10 of 14) | 50% (1 of 2); 0.5 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 3 | 86% (6 of 7); on the table 100% | 33% (14 of 42) | 33% | 67% (16 of 24) | 0.0 uses a game | 0.0 uses a game | 33% (1 of 3); 0.3 uses a game |
| Skaven | 6 | 54% (7 of 13); on the table 85% | 43% (18 of 42) | 43% | 71% (32 of 45) | 100% (3 of 3); 1.0 uses a game | 0.0 uses a game | 50% (3 of 6); 0.7 uses a game |
| Tomb Kings of Khemri | 4 | 93% (14 of 15); on the table 93% | 17% (1 of 6) | 19% | 40% (8 of 20) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 8 | 100% (19 of 19); on the table 100% | 32% (19 of 60) | 26% | 43% (18 of 42) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 9 | 100% (21 of 21); on the table 100% | 50% (6 of 12) | 24% | 49% (35 of 72) | 100% (2 of 2); 0.7 uses a game | 0.0 uses a game | 100% (3 of 3); 0.3 uses a game |
| Wood Elf Realms | 6 | 92% (22 of 24); on the table 92% | 50% (3 of 6) | 33% | 54% (30 of 56) | 50% (1 of 2); 0.8 uses a game | 0.0 uses a game | 25% (1 of 4); 0.2 uses a game |

Flank and rear charges a unit could have turned to face (fw-h2h2-opp-1eea44e-p4, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 48% (49) | 50% (37) | 49% (86) |
| ...free all their last turn and able to turn (per game) | 0.72 | 0.69 | 1.42 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.33 | 0.14 | 0.47 |
| ...with the charger already in that arc before they moved (per game) | 0.53 | 0.44 | 0.97 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 1.25 | 1.08 | 2.33 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.72 | 0.61 | 1.33 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 6.03 | 6.58 | 12.61 |

### Quality by phase: fw-h2h2-opp-1eea44e-p4

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.1 | 3.6 |
| Strategy | Charge objectives carried out (made contact) | 53% (66 of 124) | 42% (85 of 200) |
| Strategy | Shoot objectives carried out (shot that target) | 47% (157 of 331) | 41% (61 of 148) |
| Strategy | Close-in objectives charged next turn | 10% (17 of 176) | 12% (24 of 199) |
| Strategy | Support requests answered (helper made contact too) | 58% (7 of 12) | 36% (8 of 22) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (1 of 1) | - |
| Strategy | Hexes on a unit its side charged or shot that turn | 36% (5 of 14) | 67% (4 of 6) |
| Strategy | Joined characters whose unit fought | 61% (19 of 31) | 25% (8 of 32) |
| Strategy | Lone characters that fought | 74% (68 of 92) | 77% (65 of 84) |
| Movement | Charges halted short of contact | 0.1 | 0.1 |
| Movement | Idle units | 1.3 | 1.9 |
| Movement | Points that never moved of their own | 325.4 | 116.2 |
| Movement | Fights charged into per game | 2.9 | 4.0 |
| Movement | Charges with odds: long shots (under 50%) | 6 of 96, net -47 | 21 of 121, net +15 |
| Movement | Charges with odds: sweet spot (55-75%) | 16 of 96, net -30 | 15 of 121, net +167 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 16 of 96, net +34 | 12 of 121, net +103 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 36 of 96, net +98 | 44 of 121, net +120 |
| Shooting | Shots by shooting units (incl. breath weapons) | 8.9 | 8.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 45% (144 of 320) | 31% (96 of 313) |
| Shooting | Points destroyed by shooting units | 63.1 | 57.0 |
| Shooting | War machine shots | 6.7 | 0.6 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 60% (145 of 242) | 48% (11 of 23) |
| Shooting | Points destroyed by war machines | 109.4 | 3.2 |
| Magic | Magic missiles cast | 1.3 | 1.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 38% (18 of 48) | 24% (11 of 45) |
| Magic | Wounds caused by magic missiles | 4.0 | 0.8 |
| Magic | Wounds caused by other spells | 1.8 | 1.2 |
| Magic | Points destroyed by magic (all spells) | 81.9 | 33.1 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.9 / 0.4 / 1.0 / 0.2 | 1.8 / 0.4 / 0.5 / 0.1 |
| Combat | Points destroyed in combat | 274.8 | 474.0 |
| Combat | Points run down | 74.0 | 88.5 |
| Combat | Net points per charged fight, damage counted | +54 | +84 |
| Combat | Net per 100 charger points, damage counted | +20.1 | +27.8 |
| Combat | First round won (charged fights) | 72% | 62% |
| Combat | Net points per charged fight | +53 | +93 |
| Combat | Net points per supported fight / lone fight | +16 / +57 | +74 / +95 |
| Combat | Charged fights on a top-3 enemy unit | 27 of 105 | 62 of 143 |
| Game | Points lost | 820.2 | 672.2 |
| Game | VP from objectives | 488.3 | 545.0 |
| Game | Lone holders (player turns) | 2.6 | 2.2 |

- Mine won / drew / lost: 13 / 5 / 18 of 36 ended games (of 36); mean margin (Mine - Opponent) -233 VP
- The side that went first won 18 of 31 games with a winner
- Points traded per game (both sides' losses): 1492
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: fw-h2h2-opp-1eea44e-p4

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.6 | +0.0 | 0.0 | 0.0 | 0.8 | +0.0 | 0.0 | 0.0 |
| ALREADY CARRIED | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARTILLERY RE-ROLL WEIGHED | 1.1 | +0.0 | 0.0 | 30.8 | 0.1 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | 1.2 | +7.0 | 0.0 | 51.0 | 1.2 | +14.8 | 0.0 | 20.6 |
| BEST FACING | - | - | - | - | 0.6 | +12.8 | 0.0 | 50.9 |
| BEST FIRST | - | - | - | - | 4.2 | +132.7 | 124.7 | 93.6 |
| BEST OVERALL | 0.2 | +15.4 | 0.0 | 17.8 | 0.6 | +51.3 | 0.0 | 4.2 |
| BEST PREY | 4.9 | +296.7 | 170.6 | 164.6 | 0.8 | +24.5 | 32.4 | 3.2 |
| BEST PRIZE | 0.0 | -5.5 | 3.0 | 0.0 | 0.1 | -12.5 | 7.3 | 12.3 |
| BIG CHARACTER SAFETY | 0.1 | +0.2 | 0.0 | 0.0 | 0.4 | +1.9 | 0.0 | 28.7 |
| BLOCKED CHARGE HANDED OVER | - | - | - | - | 0.0 | +3.8 | 7.8 | 0.0 |
| BLOCKED CHARGE SKIPPED | 0.1 | +0.0 | 11.2 | 0.0 | 0.1 | +0.0 | 13.6 | 0.0 |
| BLOCKED WHEEL | 0.5 | +0.9 | 0.0 | 11.5 | 0.7 | +8.1 | 0.0 | 1.8 |
| BOMBING RUN | 0.0 | +0.2 | 1.7 | 0.0 | - | - | - | - |
| CANNON PLAN MISSED | 0.6 | +0.0 | 106.3 | 8.6 | 0.1 | +0.0 | 10.1 | 0.0 |
| CANNON PLANNED TARGET | 5.4 | +219.0 | 377.4 | 99.0 | 0.4 | +9.1 | 9.3 | 14.7 |
| CANNON SIGHT KEPT | 1.2 | +0.0 | 0.0 | 3.2 | 0.0 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT COUNTER | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT SET-UP | 0.1 | -0.3 | 0.0 | 0.0 | 0.1 | -9.5 | 26.5 | 0.0 |
| CAST JOB | 0.7 | +17.3 | 48.7 | 16.8 | 0.3 | +7.1 | 31.4 | 5.3 |
| CASTER AWAY FROM SCREEN | 0.3 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.4 | +32.3 | 20.6 | 30.9 | - | - | - | - |
| CASTS AFTER FRIENDS | 0.9 | +0.0 | 0.0 | 4.7 | 0.4 | +0.0 | 0.0 | 11.1 |
| CASTS FROM BEHIND | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | - | - | - | - | 0.0 | +1.0 | 0.0 | 0.0 |
| CHAFF PASSED | 0.2 | -0.8 | 0.0 | 5.6 | 0.1 | -0.3 | 3.2 | 4.4 |
| CHARGE NOW FIRST | - | - | - | - | 3.4 | +0.0 | 393.4 | 87.6 |
| CHARGE NOW WEIGHED | 0.5 | -41.4 | 20.6 | 14.4 | 0.4 | -18.1 | 6.0 | 19.3 |
| CHARIOT NO STATIC JOB | 0.4 | +0.0 | 0.0 | 11.1 | - | - | - | - |
| CHARIOT WIZARD CAREFUL | 0.0 | -0.2 | 0.0 | 0.0 | 0.1 | -1.9 | 15.7 | 15.0 |
| CHEAP HELPER | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 12.8 | 1.8 |
| COMBAT PIVOT | 0.6 | +0.0 | 35.3 | 86.4 | 0.8 | +0.0 | 55.3 | 25.0 |
| CONTINUE AHEAD WEIGHED | 0.0 | +0.0 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | 0.8 | +106.6 | 46.5 | 28.9 | 0.3 | +45.8 | 10.1 | 11.1 |
| COUNTER-CHARGE COVER | 7.1 | +458.4 | 0.0 | 264.2 | 7.7 | +688.1 | 0.0 | 128.9 |
| DEFENSIVE FLOOR | - | - | - | - | 0.0 | +1.8 | 3.1 | 0.0 |
| EDGE GIVE GROUND | - | - | - | - | 0.3 | +6.2 | 40.2 | 0.0 |
| ELIXIR WORTH | - | - | - | - | 0.0 | +0.2 | 0.0 | 0.0 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 1.2 | +128.0 | 0.0 | 63.7 | 1.1 | +87.9 | 0.0 | 62.6 |
| FALLBACK BY WORTH | 6.9 | +50.2 | 0.0 | 84.9 | 5.4 | +68.9 | 0.0 | 47.2 |
| FIGHT LIFT | 0.1 | +0.4 | 4.0 | 0.0 | - | - | - | - |
| FIRE AND FLEE | 0.1 | +0.3 | 0.0 | 1.7 | 0.1 | +0.3 | 0.0 | 19.6 |
| FLANK NOT WEIGHED | 6.2 | +0.0 | 0.0 | 225.9 | 5.9 | +0.0 | 0.0 | 107.2 |
| FOCUS FIRE | - | - | - | - | 0.1 | +1.2 | 0.0 | 0.0 |
| FOLLOW UP WEIGHED | 1.2 | +163.5 | 0.0 | 45.4 | 1.1 | +154.2 | 0.0 | 31.9 |
| FRIENDS SHOTS CHECKED | 0.3 | +19.6 | 0.0 | 7.8 | 0.1 | +12.6 | 0.0 | 0.0 |
| GIVES UP | 1.0 | -29.8 | 126.2 | 31.6 | 0.1 | -3.5 | 10.6 | 0.0 |
| GIVES UP ITS SCREEN | 0.5 | -11.5 | 30.6 | 11.6 | 0.1 | -0.4 | 6.0 | 1.2 |
| GROUND FLIERS | 0.0 | +0.6 | 0.0 | 6.1 | - | - | - | - |
| HELPER ALREADY ASKED | - | - | - | - | 0.1 | +0.0 | 9.5 | 0.0 |
| HELPER UNSEEN | 0.2 | +0.0 | 24.1 | 25.1 | 0.4 | +0.0 | 65.4 | 3.2 |
| HILL BY ITS CHANCE | - | - | - | - | 0.6 | -47.7 | 0.0 | 13.1 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| HUNT ADVANCE | 0.1 | +0.1 | 18.3 | 0.0 | 0.1 | +2.0 | 4.6 | 3.2 |
| HUNT DROPPED | - | - | - | - | 0.1 | +0.0 | 0.0 | 0.0 |
| HUNT IN PAIRS | 0.3 | +16.3 | 0.0 | 6.0 | 0.4 | +22.1 | 0.0 | 0.0 |
| HUNT KEPT | 0.0 | +0.0 | 13.1 | 0.0 | 0.0 | +0.0 | 4.6 | 3.1 |
| HUNT RESULT | 0.1 | +18.5 | 0.0 | 0.0 | 0.1 | +24.1 | 0.0 | 7.0 |
| HUNT THE GUNS | 0.1 | +19.0 | 18.3 | 0.0 | 0.1 | +60.4 | 20.7 | 4.0 |
| INVITES THE FIGHT | - | - | - | - | 1.5 | +25.4 | 69.6 | 6.7 |
| JOINT CHARGE PLAN | 0.1 | +0.9 | 0.0 | 0.0 | 0.1 | +0.1 | 0.0 | 0.0 |
| KEEP FALLS | 0.2 | +3.4 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| KEEPS ITS PREY | 0.2 | +1.6 | 11.2 | 3.8 | 0.1 | +0.3 | 1.7 | 0.0 |
| KEEPS ITS TARGET | 1.8 | +53.3 | 135.7 | 57.9 | 2.2 | +65.0 | 226.4 | 38.3 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KILLS COUNT | 1.9 | +104.4 | 174.6 | 88.7 | 2.6 | +131.8 | 228.4 | 65.6 |
| KILLS COUNT NEXT TURN | 9.9 | +332.7 | 395.8 | 209.9 | 6.9 | +253.9 | 321.2 | 191.2 |
| LONE CHARACTER SAFE SPOT | 0.8 | +40.9 | 19.4 | 36.8 | 0.1 | +5.4 | 6.2 | 5.3 |
| LONE WIZARD HOLDS BACK | 0.1 | +0.0 | 0.0 | 10.6 | 0.4 | +0.0 | 19.4 | 10.6 |
| LONE WIZARD KEPT IN | 0.6 | +26.9 | 0.0 | 0.0 | 0.2 | +20.3 | 0.0 | 0.0 |
| LONG SHOT | - | - | - | - | 0.5 | -0.1 | 24.1 | 5.1 |
| LOST CHARGE | - | - | - | - | 2.0 | -26.4 | 54.4 | 43.4 |
| LURE BY WHAT IT DRAWS | - | - | - | - | 0.1 | -15.4 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 0.6 | +26.9 | 11.8 | 13.8 | 0.5 | +89.6 | 44.9 | 0.0 |
| MANOEUVRE | 0.2 | +4.3 | 0.0 | 1.4 | 0.1 | +1.3 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.1 | +0.2 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 5.3 |
| MARCH CHECK | 0.4 | +20.7 | 0.0 | 6.9 | 0.5 | +7.2 | 0.0 | 0.0 |
| MARCH ODDS | 1.0 | +62.8 | 44.5 | 34.8 | 0.2 | +7.6 | 18.0 | 0.0 |
| MARCH OVER CASTS | 0.6 | +28.6 | 0.0 | 4.8 | 0.4 | +13.3 | 0.0 | 5.3 |
| MAX FOR POSITIONING | 4.6 | +160.4 | 0.0 | 122.6 | 5.2 | +176.5 | 0.0 | 139.9 |
| MISSILES IN THE MOVE | 3.5 | +117.1 | 0.0 | 125.5 | 2.6 | +37.6 | 0.0 | 75.1 |
| MISSILES NEXT TURN | 4.8 | +82.4 | 0.0 | 151.1 | 3.1 | +28.6 | 0.0 | 91.5 |
| MODEL FACING | 0.2 | +75.8 | 0.0 | 3.3 | - | - | - | - |
| MONSTER WIZARD ROAMS | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 17.3 | 0.0 |
| MOVE AND CAST | 0.2 | +2.2 | 0.0 | 6.6 | 0.2 | +3.2 | 0.0 | 5.3 |
| MOVE SPELL IN RANGE | 0.2 | +3.7 | 0.0 | 16.1 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.7 | -57.2 | 0.0 | 20.3 | 0.0 | -3.4 | 0.0 | 0.0 |
| MOVE SPELL SPOT | 0.6 | +0.0 | 0.0 | 23.0 | 0.1 | +0.0 | 0.0 | 8.2 |
| MOVE TO CHARGE | - | - | - | - | 4.3 | +290.5 | 270.2 | 92.5 |
| MOVES UNITS SPELL | 0.1 | +3.3 | 0.0 | 0.0 | 0.1 | +0.6 | 0.0 | 0.0 |
| NEEDED THERE | 0.0 | +1.9 | 5.3 | 0.0 | 0.1 | +6.9 | 7.3 | 0.0 |
| NO RALLY LEFT | 0.1 | +7.5 | 0.0 | 5.1 | - | - | - | - |
| NOT NEEDED | 0.2 | -6.6 | 9.1 | 4.9 | 0.4 | -15.7 | 36.6 | 1.2 |
| NOT TURNED | 6.0 | +106.4 | 0.0 | 190.9 | 6.6 | +61.9 | 0.0 | 61.4 |
| NOT WORTH A CAST | 0.6 | -0.4 | 0.0 | 10.6 | 0.4 | -0.2 | 0.0 | 0.0 |
| OFF BEST | 16.5 | -824.9 | 18.7 | 447.4 | 14.1 | -782.2 | 4.8 | 232.8 |
| OPENS A LANE | 0.1 | +0.3 | 41.2 | 0.0 | 0.1 | +1.1 | 6.8 | 0.0 |
| OPENS UP | 0.2 | +11.6 | 16.3 | 4.9 | 0.3 | +41.0 | 21.3 | 0.0 |
| OVERRUN THREAT | 0.0 | +0.3 | 0.0 | 0.0 | - | - | - | - |
| OVERRUNS AWAY | 0.3 | +15.6 | 31.9 | 23.3 | 0.4 | +13.9 | 40.2 | 14.4 |
| PATHS CROSS | 2.1 | +106.9 | 0.0 | 16.1 | 3.2 | +256.8 | 0.0 | 43.2 |
| PERIAPT WORTH | 0.0 | +3.4 | 0.0 | 0.0 | 0.1 | +7.6 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.1 | -3.6 | 0.0 | 13.5 | 0.1 | -2.8 | 0.0 | 0.0 |
| PLAN RESULT | 38.0 | +1583.4 | 1278.4 | 1114.4 | 39.2 | +1414.9 | 1486.9 | 975.7 |
| PURSUES BIG PREY | - | - | - | - | 0.1 | -15.5 | 0.0 | 0.0 |
| PURSUES ON | 0.0 | +0.8 | 0.0 | 2.4 | - | - | - | - |
| RAIDS THE BAGGAGE | - | - | - | - | 0.1 | +6.1 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE NEXT TURN | 0.0 | +3.3 | 0.0 | 0.0 | 0.1 | +9.9 | 0.0 | 3.4 |
| RANDOM MOVE BY FIGURES | - | - | - | - | 2.1 | +20.4 | 0.0 | 47.8 |
| RANDOM MOVER NO PROMISE | - | - | - | - | 0.4 | -19.4 | 8.5 | 0.0 |
| REDIRECT BY WHAT IT STOPS | - | - | - | - | 0.4 | -10.7 | 0.0 | 12.2 |
| REDIRECT COUNTER | 3.3 | +141.8 | 0.0 | 72.4 | 4.6 | +382.3 | 0.0 | 74.6 |
| REDIRECT WEIGHED | 0.2 | +4.3 | 7.5 | 18.1 | 0.4 | +24.7 | 16.2 | 10.7 |
| RESERVE FALL BACK | - | - | - | - | 0.8 | +27.9 | 0.0 | 10.7 |
| RESTRAINS TO SHOOT | 0.1 | +1.7 | 0.0 | 4.0 | 0.1 | +10.8 | 0.0 | 0.0 |
| RISK BY ARC | 2.5 | +96.3 | 187.5 | 104.1 | 3.2 | +25.7 | 327.3 | 95.5 |
| SAFER THAN THE JOB | 0.7 | +46.9 | 0.0 | 50.4 | 0.6 | +43.5 | 0.0 | 11.2 |
| SCOUT SPOT | 0.4 | +0.5 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| SCOUT WAITS | 0.5 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 0.3 | -12.2 | 0.0 | 1.5 |
| SEARCH SPOT | 1.9 | +97.9 | 0.0 | 35.1 | 2.7 | +146.2 | 0.0 | 34.8 |
| SELF MOVE SPELL | 0.2 | +43.5 | 0.0 | 0.0 | 0.4 | +14.8 | 0.0 | 18.1 |
| SET UP TOGETHER | 0.7 | +32.1 | 11.8 | 13.8 | 1.2 | +145.6 | 57.4 | 21.8 |
| SET-UP ANY TARGET | 0.6 | +72.5 | 31.1 | 16.7 | 0.2 | +23.3 | 8.2 | 11.1 |
| SET-UP MISSED | 0.1 | +11.8 | 12.9 | 0.0 | 0.0 | +6.9 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.3 | +0.7 | 0.0 | 0.0 | 0.2 | +0.3 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | - | - | - | - | 0.8 | +26.5 | 53.4 | 9.0 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 3.2 | 0.0 | +0.0 | 0.0 | 0.0 |
| SHOT REPLANNED | 0.6 | +0.0 | 161.8 | 14.2 | 0.2 | +0.0 | 64.3 | 0.0 |
| SHOTS IN THE MOVE | 13.6 | +593.0 | 0.0 | 266.2 | 7.2 | +216.5 | 0.0 | 128.6 |
| SPELL SETS UP CHARGE | 0.6 | +72.5 | 31.1 | 16.7 | 0.2 | +23.3 | 8.2 | 11.1 |
| SPELL WORTH | 1.2 | +12.2 | 37.5 | 61.9 | 2.4 | +46.9 | 101.5 | 99.7 |
| STABLE ROLE | - | - | - | - | 10.6 | +0.0 | 422.0 | 141.7 |
| STANDS TO CAST | 0.0 | +0.9 | 16.4 | 0.0 | 0.0 | +0.3 | 0.0 | 0.0 |
| STAY WEIGHED | - | - | - | - | 0.0 | +0.3 | 0.0 | 0.0 |
| STOPS | - | - | - | - | 0.0 | +0.3 | 16.1 | 0.8 |
| STOPS SHORT OF THE FLANK | 0.4 | +11.5 | 0.0 | 6.5 | 0.6 | +13.1 | 0.0 | 20.4 |
| STUCK PIVOT | 0.2 | +0.0 | 0.0 | 4.7 | 0.4 | +0.0 | 0.0 | 11.7 |
| SUPPORT JOB KEPT | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SUPPORT NARROWED | - | - | - | - | 9.4 | -70.8 | 442.1 | 123.3 |
| SUPPORTS | - | - | - | - | 6.5 | +71.6 | 140.9 | 69.2 |
| SURE CHARGE BEATS ADVANCE | 0.1 | -1.3 | 8.2 | 0.0 | 0.0 | -1.1 | 1.8 | 0.0 |
| SURE REACH TOGETHER | 0.4 | +1.3 | 0.0 | 12.0 | 0.5 | +8.5 | 0.0 | 17.5 |
| THROUGH LINE OF FIRE | 0.3 | +9.2 | 0.0 | 7.7 | 0.1 | +3.6 | 0.0 | 0.0 |
| TURN WORTH | 0.6 | -38.0 | 57.2 | 8.7 | 0.7 | -60.2 | 67.1 | 7.9 |
| TWO OR MORE ARRIVE | 0.3 | +0.8 | 4.7 | 4.2 | 0.2 | +1.3 | 19.0 | 0.0 |
| WAIT AFTER COSTS | - | - | - | - | 7.6 | -331.6 | 393.1 | 125.5 |
| WALKS TO THE FIGHT | - | - | - | - | 0.9 | +18.4 | 28.8 | 1.4 |
| WAR ENGINE CHARGES | - | - | - | - | 0.0 | +0.3 | 0.0 | 0.0 |
| WAR ENGINE JOBS | - | - | - | - | 0.2 | +0.0 | 8.1 | 4.0 |
| WEARS DOWN | 0.8 | +28.7 | 56.2 | 31.9 | 1.1 | +36.0 | 110.4 | 18.7 |
| WHO HITS BACK | 0.4 | +29.2 | 0.0 | 22.9 | 0.2 | +26.6 | 0.0 | 13.1 |
| WHOLE FIGHT | 0.2 | +10.9 | 40.8 | 0.0 | 0.4 | +34.2 | 100.4 | 11.1 |
| WHOLE FIGHT GAIN | 0.2 | +36.0 | 20.4 | 14.2 | 0.6 | +39.6 | 51.9 | 8.1 |

### Rule changes: fw-h2h2-opp-1eea44e-p4

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 1103 | 1103 | 1103 | 30.64 | -57856 | -52.5 |
| PATHS CROSS | 189 | 189 | 189 | 5.25 | +13093 | +69.3 |
| KILLS COUNT NEXT TURN | 606 | 599 | 168 | 4.67 | +5591 | +33.3 |
| SEARCH SPOT | 166 | 166 | 164 | 4.56 | +8863 | +54.0 |
| BEST FIRST | 151 | 151 | 151 | 4.19 | +4777 | +31.6 |
| COUNTER-CHARGE COVER | 532 | 273 | 117 | 3.25 | +6352 | +54.3 |
| BEST PREY | 207 | 201 | 87 | 2.42 | +3220 | +37.0 |
| FACES THE THREAT | 84 | 84 | 84 | 2.33 | +7771 | +92.5 |
| FALLBACK BY WORTH | 444 | 444 | 83 | 2.31 | +4289 | +51.7 |
| FOLLOW UP WEIGHED | 83 | 83 | 83 | 2.31 | +11438 | +137.8 |
| SUPPORTS | 234 | 234 | 81 | 2.25 | +719 | +8.9 |
| MOVE TO CHARGE | 155 | 155 | 79 | 2.19 | +3768 | +47.7 |
| MAX FOR POSITIONING | 353 | 185 | 52 | 1.44 | +550 | +10.6 |
| SHOTS IN THE MOVE | 746 | 526 | 52 | 1.44 | +1454 | +28.0 |
| REDIRECT COUNTER | 287 | 140 | 51 | 1.42 | +4095 | +80.3 |
| ADVANCE LANE KEPT | 49 | 49 | 49 | 1.36 | +0 | +0.0 |
| COMBAT PIVOT | 48 | 48 | 48 | 1.33 | +0 | +0.0 |
| SAFER THAN THE JOB | 48 | 48 | 48 | 1.33 | +3253 | +67.8 |
| RANDOM MOVE BY FIGURES | 74 | 74 | 46 | 1.28 | +734 | +16.0 |
| CANNON SIGHT KEPT | 44 | 44 | 44 | 1.22 | +0 | +0.0 |
| ARTILLERY RE-ROLL WEIGHED | 43 | 43 | 43 | 1.19 | +0 | +0.0 |
| BLOCKED WHEEL | 42 | 42 | 42 | 1.17 | +325 | +7.7 |
| MARCH ODDS | 44 | 44 | 39 | 1.08 | +686 | +17.6 |
| STOPS SHORT OF THE FLANK | 36 | 36 | 36 | 1.00 | +884 | +24.6 |
| CHARGE NOW WEIGHED | 35 | 35 | 35 | 0.97 | +1387 | +39.6 |
| HOLDS AMBUSHERS | 35 | 35 | 35 | 0.97 | +0 | +0.0 |
| KILLS COUNT | 164 | 158 | 34 | 0.94 | +2213 | +65.1 |
| RISK BY ARC | 205 | 196 | 34 | 0.94 | +1049 | +30.8 |
| SET UP TOGETHER | 69 | 59 | 32 | 0.89 | +2927 | +91.5 |
| BEST OVERALL | 31 | 31 | 31 | 0.86 | +2398 | +77.4 |
| CANNON PLANNED TARGET | 209 | 209 | 31 | 0.86 | -490 | -15.8 |
| MARCH CHECK | 35 | 34 | 31 | 0.86 | +928 | +29.9 |
| SHOT REPLANNED | 31 | 31 | 31 | 0.86 | +0 | +0.0 |
| WAIT AFTER COSTS | 273 | 273 | 29 | 0.81 | +472 | +16.3 |
| LONE WIZARD KEPT IN | 28 | 28 | 28 | 0.78 | +1699 | +60.7 |
| MISSILES IN THE MOVE | 220 | 115 | 28 | 0.78 | +686 | +24.5 |
| RESERVE FALL BACK | 27 | 27 | 27 | 0.75 | +1003 | +37.2 |
| WALKS TO THE FIGHT | 34 | 34 | 25 | 0.69 | +358 | +14.3 |
| CHARGE NOW FIRST | 121 | 121 | 23 | 0.64 | -1727 | -75.1 |
| KEEPS ITS TARGET | 142 | 139 | 23 | 0.64 | +439 | +19.1 |
| CAST JOB | 35 | 35 | 22 | 0.61 | +371 | +16.9 |
| WHO HITS BACK | 22 | 22 | 22 | 0.61 | +1589 | +72.2 |
| REDIRECT WEIGHED | 21 | 21 | 21 | 0.58 | +1430 | +68.1 |
| SCOUT WAITS | 21 | 21 | 21 | 0.58 | +0 | +0.0 |
| STUCK PIVOT | 21 | 21 | 21 | 0.58 | +0 | +0.0 |
| BEST FACING | 20 | 20 | 20 | 0.56 | +462 | +23.1 |
| CASTER AWAY FROM SCREEN | 17 | 17 | 17 | 0.47 | +0 | +0.0 |
| FRIENDS SHOTS CHECKED | 17 | 17 | 17 | 0.47 | +1160 | +68.2 |
| MAKE SURE TOGETHER | 38 | 29 | 17 | 0.47 | +2036 | +119.8 |
| SHOOTERS IN TWO RANKS | 17 | 17 | 17 | 0.47 | +36 | +2.1 |
| THROUGH LINE OF FIRE | 17 | 17 | 17 | 0.47 | +461 | +27.1 |
| MOVE AND CAST | 16 | 16 | 16 | 0.44 | +193 | +12.1 |
| BIG CHARACTER SAFETY | 15 | 15 | 15 | 0.42 | +75 | +5.0 |
| WHOLE FIGHT GAIN | 30 | 28 | 15 | 0.42 | +775 | +51.7 |
| CHAFF PASSED | 12 | 12 | 12 | 0.33 | -39 | -3.3 |
| SHOOTS FROM THE BEST SPOT | 30 | 30 | 12 | 0.33 | +413 | +34.4 |
| CASTING BLOCK | 13 | 12 | 11 | 0.31 | +581 | +52.9 |
| CHARIOT NO STATIC JOB | 15 | 15 | 11 | 0.31 | -1715 | -155.9 |
| OPENS UP | 20 | 19 | 11 | 0.31 | +530 | +48.1 |
| INVITES THE FIGHT | 54 | 54 | 10 | 0.28 | +108 | +10.8 |
| MANOEUVRE | 10 | 10 | 10 | 0.28 | +202 | +20.1 |
| WEARS DOWN | 68 | 67 | 10 | 0.28 | +361 | +36.1 |
| CASTS FROM BEHIND | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| MODEL FACING | 9 | 9 | 9 | 0.25 | +2727 | +303.0 |
| RESTRAINS TO SHOOT | 9 | 9 | 9 | 0.25 | +453 | +50.3 |
| SHORT GUN FORWARD | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| PIVOT GUARDS FLANK | 8 | 8 | 8 | 0.22 | -233 | -29.2 |
| BLOCKED CHARGE SKIPPED | 7 | 7 | 7 | 0.19 | +0 | +0.0 |
| KEEP FALLS | 7 | 7 | 7 | 0.19 | +230 | +32.9 |
| MOVES UNITS SPELL | 7 | 7 | 7 | 0.19 | +138 | +19.7 |
| SURE CHARGE BEATS ADVANCE | 6 | 6 | 6 | 0.17 | -86 | -14.3 |
| HUNT IN PAIRS | 26 | 14 | 5 | 0.14 | +187 | +37.3 |
| MISSILES NEXT TURN | 283 | 140 | 5 | 0.14 | +66 | +13.2 |
| PURSUES BIG PREY | 5 | 5 | 5 | 0.14 | -558 | -111.6 |
| RAIDS THE BAGGAGE NEXT TURN | 5 | 5 | 5 | 0.14 | +279 | +55.8 |
| WHOLE FIGHT | 24 | 21 | 5 | 0.14 | +402 | +80.3 |
| BEST PRIZE | 4 | 4 | 4 | 0.11 | -651 | -162.7 |
| FIRE AND FLEE | 4 | 4 | 4 | 0.11 | +21 | +5.3 |
| OVERRUNS AWAY | 27 | 27 | 4 | 0.11 | +262 | +65.6 |
| PERIAPT WORTH | 4 | 4 | 4 | 0.11 | +397 | +99.2 |
| SURE REACH TOGETHER | 33 | 24 | 4 | 0.11 | +4 | +1.1 |
| FOCUS FIRE | 3 | 3 | 3 | 0.08 | +42 | +13.9 |
| LOST CHARGE | 71 | 71 | 3 | 0.08 | +52 | +17.4 |
| NEEDED THERE | 4 | 4 | 3 | 0.08 | +0 | +0.0 |
| CARRIES OUT SET-UP | 6 | 6 | 2 | 0.06 | -352 | -175.9 |
| CONTINUE AHEAD WEIGHED | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| KEEPS ITS PREY | 11 | 10 | 2 | 0.06 | +6 | +2.9 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| LONE WIZARD HOLDS BACK | 18 | 18 | 2 | 0.06 | -178 | -89.0 |
| NO RALLY LEFT | 2 | 2 | 2 | 0.06 | +47 | +23.3 |
| STANDS TO CAST | 2 | 2 | 2 | 0.06 | -2 | -1.0 |
| BACKUP TARGETS | 88 | 36 | 1 | 0.03 | +0 | +0.0 |
| BLOCKED CHARGE HANDED OVER | 1 | 1 | 1 | 0.03 | +136 | +136.5 |
| BOMBING RUN | 1 | 1 | 1 | 0.03 | +6 | +5.5 |
| EDGE GIVE GROUND | 10 | 10 | 1 | 0.03 | +100 | +100.4 |
| ELIXIR WORTH | 1 | 1 | 1 | 0.03 | +6 | +6.5 |
| PURSUES ON | 1 | 1 | 1 | 0.03 | +29 | +29.2 |
| RAIDS THE BAGGAGE | 2 | 2 | 1 | 0.03 | +17 | +17.4 |
| REDIRECT BY WHAT IT STOPS | 16 | 16 | 1 | 0.03 | +10 | +10.3 |
| STAY WEIGHED | 1 | 1 | 1 | 0.03 | +11 | +10.8 |
| SUPPORT JOB KEPT | 1 | 1 | 1 | 0.03 | +17 | +17.0 |
| SUPPORT NARROWED | 339 | 339 | 1 | 0.03 | -7 | -7.5 |
| TURN WORTH | 47 | 47 | 1 | 0.03 | +44 | +44.5 |
| TWO OR MORE ARRIVE | 17 | 17 | 1 | 0.03 | +1 | +1.3 |
| ALREADY CARRIED | 1 | not checked | - | - | - | - |
| CANNON PLAN MISSED | 25 | 25 | 0 | 0.00 | - | - |
| CARRIES OUT COUNTER | 3 | 3 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 47 | trace | - | - | - | - |
| CATCH FLIERS | 1 | not checked | - | - | - | - |
| CHARIOT WIZARD CAREFUL | 6 | 6 | 0 | 0.00 | - | - |
| CHEAP HELPER | 4 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 38 | not checked | - | - | - | - |
| DEFENSIVE FLOOR | 1 | 1 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT LIFT | 3 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 436 | not checked | - | - | - | - |
| GIVES UP | 41 | 38 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 21 | 20 | 0 | 0.00 | - | - |
| GROUND FLIERS | 1 | not checked | - | - | - | - |
| HELPER ALREADY ASKED | 5 | not checked | - | - | - | - |
| HELPER UNSEEN | 23 | 22 | 0 | 0.00 | - | - |
| HILL BY ITS CHANCE | 23 | 23 | 0 | 0.00 | - | - |
| HUNT ADVANCE | 6 | 6 | 0 | 0.00 | - | - |
| HUNT DROPPED | 2 | trace | - | - | - | - |
| HUNT KEPT | 2 | trace | - | - | - | - |
| HUNT RESULT | 7 | trace | - | - | - | - |
| HUNT THE GUNS | 7 | trace | - | - | - | - |
| JOINT CHARGE PLAN | 5 | 5 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 32 | not checked | - | - | - | - |
| LONG SHOT | 17 | 17 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 3 | 3 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 3 | trace | - | - | - | - |
| MARCH OVER CASTS | 33 | 33 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 14 | 14 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 6 | 2 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 25 | trace | - | - | - | - |
| MOVE SPELL SPOT | 25 | not checked | - | - | - | - |
| NOT NEEDED | 19 | 19 | 0 | 0.00 | - | - |
| NOT TURNED | 454 | 454 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 33 | not checked | - | - | - | - |
| OPENS A LANE | 6 | 5 | 0 | 0.00 | - | - |
| OVERRUN THREAT | 1 | not checked | - | - | - | - |
| PLAN RESULT | 2780 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 14 | 14 | 0 | 0.00 | - | - |
| SCOUT SPOT | 19 | 19 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 10 | 10 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 21 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 26 | not checked | - | - | - | - |
| SET-UP MISSED | 4 | trace | - | - | - | - |
| SPELL SETS UP CHARGE | 26 | not checked | - | - | - | - |
| SPELL WORTH | 132 | not checked | - | - | - | - |
| STABLE ROLE | 382 | 381 | 0 | 0.00 | - | - |
| STOPS | 1 | 1 | 0 | 0.00 | - | - |
| WAR ENGINE CHARGES | 1 | 1 | 0 | 0.00 | - | - |
| WAR ENGINE JOBS | 7 | 7 | 0 | 0.00 | - | - |

### Off best figure: fw-h2h2-opp-1eea44e-p4

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 13.64 | 12.33 | 55.9 |
| FALLBACK | gate | 1.11 | 0.61 | 39.4 |
| TURN GATE | gate | 0.36 | 0.78 | 30.0 |
| RULE SWITCHED OFF | gate | 0.72 | - | 15.7 |
| CHARGE NOW FIRST | rule | - | 0.64 | 75.1 |
| CANNON PLANNED TARGET | rule | 0.39 | - | 39.5 |
| AFTERMATH BAND | gate | 0.25 | 0.11 | 2.2 |
| CHARIOT NO STATIC JOB | rule | 0.31 | - | 155.9 |
| PATHS CROSS | rule | 0.14 | 0.17 | 38.6 |
| LONE CHARACTER SAFE SPOT | gate | 0.22 | 0.03 | 98.0 |
| BLOCKED WHEEL | rule | 0.14 | 0.08 | 24.4 |
| PIVOT GUARDS FLANK | rule | 0.11 | 0.11 | 29.2 |
| CHARGE NOW WEIGHED | rule | 0.06 | 0.14 | 81.4 |
| CHAFF PASSED | rule | 0.11 | 0.06 | 6.5 |
| SUPPORT REQUEST | gate | 0.06 | 0.11 | 43.4 |
| SURE CHARGE BEATS ADVANCE | rule | 0.14 | 0.03 | 14.3 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.11 | 0.03 | 45.1 |
| MARCH ODDS | rule | - | 0.14 | 9.6 |
| BEST PRIZE | rule | 0.03 | 0.08 | 162.7 |
| BIG CHARACTER SAFETY | rule | 0.03 | 0.08 | 9.4 |
| FIGHT ORDER BAND | gate | 0.06 | 0.06 | 1.1 |
| PURSUES BIG PREY | rule | - | 0.11 | 164.8 |
| STOPS SHORT OF THE FLANK | rule | 0.03 | 0.06 | 6.9 |
| THROUGH LINE OF FIRE | rule | 0.08 | - | 20.0 |
| CARRIES OUT SET-UP | rule | 0.03 | 0.03 | 175.9 |
| FRIENDS SHOTS CHECKED | rule | 0.06 | - | 1.3 |
| NO REASON | gate | - | 0.06 | 32.5 |
| FACES THE THREAT | rule | - | 0.03 | 17.0 |
| FOLLOW UP WEIGHED | rule | 0.03 | - | 2.7 |
| LONE WIZARD HOLDS BACK | rule | - | 0.03 | 178.0 |
| STANDS TO CAST | rule | - | 0.03 | 7.3 |
| SUPPORT NARROWED | rule | - | 0.03 | 7.5 |
| WHO HITS BACK | rule | 0.03 | - | 4.1 |

### Plans: fw-h2h2-opp-1eea44e-p4

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 12.8 | 22% | 446 | 440 | 99% |
| Mine | charge | 2.9 | 60% | 257 | 279 | 109% |
| Mine | close in | 4.8 | 25% | 295 | 175 | 59% |
| Mine | hold | 4.1 | 38% | 333 | 0 | 0% |
| Mine | join | 0.8 | 93% | 22 | 0 | 0% |
| Mine | shoot | 7.9 | 67% | 324 | 689 | 213% |
| Mine | support | 4.6 | 85% | 245 | 0 | 0% |
| Opponent | advance | 13.4 | 19% | 409 | 361 | 88% |
| Opponent | charge | 4.9 | 68% | 572 | 585 | 102% |
| Opponent | close in | 5.5 | 29% | 414 | 187 | 45% |
| Opponent | hold | 4.6 | 30% | 302 | 0 | 0% |
| Opponent | join | 0.5 | 100% | 25 | 0 | 0% |
| Opponent | shoot | 3.4 | 67% | 87 | 281 | 322% |
| Opponent | support | 7.0 | 88% | 54 | 0 | 0% |

### Packages: hunt the guns, fw-h2h2-opp-1eea44e-p4

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.1 | 2 | 0 | 0% | 100% | 0% | 2.5 | 342 | 333 | 100% | 10 |
| Opponent | 0.1 | 5 | 0 | 20% | 40% | 0% | 2.5 | 435 | 174 | 40% | 117 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Dwarfen Mountain Holds | 0.3 | 1 | 0 | 0% | 100% | 0% | 3.0 | 487 | 470 | 100% | 122 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 94 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 252 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 151 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 90 |
| Tomb Kings of Khemri | 0.5 | 2 | 0 | 0% | 50% | 0% | 2.0 | 325 | 98 | 50% | 0 |
| Vampire Counts | 0.1 | 1 | 0 | 0% | 100% | 0% | 3.0 | 332 | 249 | 100% | 127 |
| Warriors of Chaos | 0.2 | 2 | 0 | 0% | 0% | 0% | - | 374 | 0 | 0% | 68 |
| Wood Elf Realms | 0.2 | 1 | 0 | 100% | 100% | 0% | 2.0 | 640 | 620 | 100% | 0 |

### Battle groups: fw-h2h2-opp-1eea44e-p4

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 7.1 | 29% | 38% | 4% | 100% | 29% | 13% | 10% | 49% | 0% |
| Mine | REDIRECT COUNTER | 3.3 | 33% | 75% | 8% | 0% | 27% | 0% | 5% | 62% | 5% |
| Opponent | COUNTER-CHARGE COVER | 7.7 | 14% | 67% | 28% | 18% | 25% | 11% | 11% | 54% | 0% |
| Opponent | REDIRECT COUNTER | 4.6 | 23% | 71% | 18% | 43% | 23% | 0% | 16% | 55% | 6% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: fw-h2h2-opp-1eea44e-p4

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 4 | 194 (4) | 194 | 0 | 0 | 25% | 2.0 | - | 0 (1) | 313 (3) | - | 194 (4) |
| Mine | Chaff | 40 | 38 (40) | 29 | 9 | 66 | 35% | 2.6 | 58 (15) | 8 (7) | 33 (18) | 54 (25) | 10 (15) |
| Mine | Character | 106 | 42 (106) | 42 | 0 | 43 | 19% | 2.4 | 36 (33) | 58 (48) | 0 (7) | 48 (46) | 46 (42) |
| Mine | Clean-up | 20 | 49 (20) | 19 | 29 | 56 | 25% | 3.3 | 38 (7) | 54 (9) | 54 (4) | 23 (10) | 70 (10) |
| Mine | Early | 1 | 0 (1) | 0 | 0 | 0 | 0% | 5.0 | - | 0 (1) | - | - | 0 (1) |
| Mine | Fast | 2 | 0 (2) | 0 | 0 | 50 | 0% | 1.5 | 0 (2) | - | - | 0 (1) | 0 (1) |
| Mine | Fast Hammer | 39 | 27 (39) | 15 | 12 | 44 | 21% | 2.7 | 11 (24) | 71 (9) | 28 (6) | 24 (26) | 36 (13) |
| Mine | Fragile | 4 | 0 (4) | 0 | 0 | 46 | 50% | 4.0 | 0 (2) | 0 (2) | - | 0 (1) | 0 (3) |
| Mine | Hammer | 64 | 41 (64) | 29 | 11 | 48 | 12% | 2.6 | 55 (12) | 42 (41) | 19 (11) | 42 (39) | 39 (25) |
| Mine | Holder | 31 | 75 (31) | 4 | 71 | 48 | 29% | 2.9 | 17 (6) | 104 (20) | 46 (4) | 100 (19) | 46 (11) |
| Mine | Shooter | 35 | 41 (35) | 16 | 26 | 46 | 0% | 1.7 | 26 (11) | 61 (19) | 0 (5) | 60 (23) | 9 (12) |
| Mine | Support | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Mine | War machine | 56 | 62 (56) | 62 | 0 | 43 | 4% | 1.2 | 48 (20) | 64 (31) | 105 (5) | 81 (9) | 58 (47) |
| Mine | Wizard | 17 | 4 (17) | 4 | 0 | 39 | 6% | 2.1 | 23 (3) | 0 (8) | 0 (1) | 26 (3) | 0 (9) |
| Opponent | Blocker | 1 | 83 (1) | 83 | 0 | 0 | 0% | 6.0 | - | 83 (1) | - | 83 (1) | - |
| Opponent | Chaff | 85 | 44 (85) | 11 | 32 | 54 | 36% | 2.5 | 27 (35) | 58 (21) | 50 (29) | 51 (66) | 12 (19) |
| Opponent | Character | 97 | 60 (97) | 60 | 0 | 31 | 26% | 2.2 | 54 (46) | 60 (40) | 102 (8) | 55 (56) | 69 (38) |
| Opponent | Clean-up | 7 | 84 (7) | 14 | 70 | 10 | 43% | 4.2 | - | 79 (4) | 94 (3) | 34 (2) | 94 (5) |
| Opponent | Fast | 2 | 0 (2) | 0 | 0 | 31 | 100% | - | - | 0 (2) | - | 0 (2) | - |
| Opponent | Fast Hammer | 55 | 62 (55) | 48 | 14 | 36 | 29% | 2.8 | 60 (24) | 48 (22) | 115 (9) | 67 (34) | 55 (21) |
| Opponent | Fragile | 16 | 0 (16) | 0 | 0 | 63 | 31% | 2.4 | 0 (1) | 0 (11) | 0 (3) | 0 (12) | 0 (3) |
| Opponent | Hammer | 64 | 41 (64) | 28 | 13 | 40 | 33% | 3.0 | 60 (20) | 35 (37) | 37 (7) | 58 (43) | 10 (21) |
| Opponent | Holder | 27 | 37 (27) | 18 | 18 | 19 | 44% | 4.1 | 23 (8) | 40 (14) | 49 (5) | 41 (14) | 30 (13) |
| Opponent | Shooter | 34 | 87 (34) | 30 | 58 | 38 | 3% | 1.5 | 74 (11) | 102 (20) | 37 (3) | 73 (20) | 107 (14) |
| Opponent | Support | 6 | 0 (6) | 0 | 0 | 18 | 33% | 4.5 | 0 (5) | - | 0 (1) | 0 (4) | 0 (2) |
| Opponent | War machine | 6 | 56 (6) | 56 | 0 | 40 | 17% | 1.2 | 95 (3) | 0 (3) | - | 95 (3) | 0 (3) |
| Opponent | Wizard | 20 | 10 (20) | 10 | 0 | 43 | 5% | 2.4 | 0 (9) | 30 (4) | 19 (4) | 14 (13) | 0 (4) |

### Charged fights: fw-h2h2-opp-1eea44e-p4

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 106 | 209 | 2.2 | 1.0 | 93 | 18 | +75 | 1 of 9 | 6 of 9 | - | +75 |
| Mine | Chaos Dwarfs | 4 | 187 | 27 | 1.2 | 1.0 | 22 | 38 | -16 | 0 of 5 | 4 of 5 | - | -16 |
| Mine | Dwarfen Mountain Holds | 3 | 398 | 0 | 2.0 | 1.0 | 0 | 0 | +0 | 2 of 6 | 3 of 6 | - | +0 |
| Mine | Empire of Man | 5 | 487 | 198 | 2.6 | 1.2 | 76 | 72 | +4 | 3 of 13 | 10 of 13 | +55 | -5 |
| Mine | Grand Cathay | 4 | 416 | 142 | 3.2 | 1.2 | 44 | 27 | +17 | 3 of 13 | 10 of 13 | +0 | +20 |
| Mine | High Elf Realms | 4 | 210 | 356 | 3.2 | 1.2 | 110 | 22 | +88 | 3 of 13 | 10 of 13 | +88 | +88 |
| Mine | Kingdom of Bretonnia | 1 | 805 | 210 | 5.0 | 1.0 | 42 | 0 | +42 | 2 of 5 | 4 of 5 | - | +42 |
| Mine | Lizardmen | 1 | 0 | 1419 | 4.0 | 1.2 | 355 | 0 | +355 | 3 of 4 | 3 of 4 | +255 | +388 |
| Mine | Ogre Kingdoms | 2 | 175 | 245 | 3.0 | 1.2 | 82 | 6 | +76 | 2 of 6 | 3 of 6 | -34 | +98 |
| Mine | Skaven | 2 | 238 | 33 | 2.0 | 1.0 | 16 | 0 | +16 | 1 of 4 | 2 of 4 | - | +16 |
| Mine | Tomb Kings of Khemri | 2 | 0 | 594 | 4.5 | 1.0 | 132 | 29 | +103 | 5 of 9 | 8 of 9 | - | +103 |
| Mine | Vampire Counts | 2 | 114 | 226 | 4.0 | 1.1 | 57 | 6 | +51 | 1 of 8 | 7 of 8 | +115 | +42 |
| Mine | Warriors of Chaos | 2 | 0 | 407 | 5.0 | 1.1 | 81 | 70 | +12 | 1 of 10 | 6 of 10 | -465 | +65 |
| **Mine** | all armies | 36 | 254 | 238 | 2.9 | 1.1 | 82 | 28 | +53 | 27 of 105 | 76 of 105 | +16 | +57 |
| Opponent | Empire of Man | 1 | 425 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | High Elf Realms | 5 | 79 | 625 | 4.8 | 1.0 | 130 | 25 | +106 | 12 of 24 | 15 of 24 | +140 | +104 |
| Opponent | Lizardmen | 2 | 0 | 460 | 2.0 | 1.0 | 230 | 0 | +230 | 3 of 4 | 3 of 4 | - | +230 |
| Opponent | Orc & Goblin Tribes | 3 | 0 | 268 | 4.0 | 1.1 | 67 | 117 | -50 | 2 of 12 | 6 of 12 | -165 | -39 |
| Opponent | Skaven | 4 | 152 | 215 | 1.8 | 1.1 | 123 | 26 | +96 | 4 of 7 | 4 of 7 | +185 | +82 |
| Opponent | Tomb Kings of Khemri | 2 | 62 | 904 | 4.5 | 1.1 | 201 | 15 | +186 | 3 of 9 | 6 of 9 | +115 | +195 |
| Opponent | Vampire Counts | 6 | 38 | 620 | 4.0 | 1.1 | 155 | 13 | +143 | 11 of 24 | 14 of 24 | +144 | +142 |
| Opponent | Warriors of Chaos | 7 | 22 | 530 | 4.7 | 1.1 | 112 | 24 | +88 | 15 of 33 | 23 of 33 | +155 | +81 |
| Opponent | Wood Elf Realms | 6 | 237 | 522 | 5.0 | 1.1 | 104 | 45 | +59 | 12 of 30 | 18 of 30 | -46 | +71 |
| **Opponent** | all armies | 36 | 93 | 502 | 4.0 | 1.1 | 126 | 33 | +93 | 62 of 143 | 89 of 143 | +74 | +95 |

### Effective charges: fw-h2h2-opp-1eea44e-p4

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 9 | 0 | 0 | 0 | 4 (net +154) | 0 | 5 (net +12) | 0 | 0% (0 of 9) |
| Mine | Chaos Dwarfs | 5 | 0 | 0 | 1 (net -189) | 0 | 0 | 3 (net +36) | 1 | 25% (1 of 4) |
| Mine | Dwarfen Mountain Holds | 6 | 3 (net +0) | 0 | 0 | 1 (net +0) | 1 (net +0) | 1 (net +0) | 0 | 0% (0 of 6) |
| Mine | Empire of Man | 13 | 1 (net -281) | 0 | 3 (net -40) | 3 (net -98) | 2 (net +78) | 4 (net +148) | 0 | 23% (3 of 13) |
| Mine | Grand Cathay | 13 | 0 | 0 | 3 (net -72) | 3 (net -21) | 3 (net +20) | 4 (net +109) | 0 | 23% (3 of 13) |
| Mine | High Elf Realms | 13 | 0 | 0 | 4 (net +108) | 1 (net +0) | 3 (net +7) | 4 (net +173) | 1 | 33% (4 of 12) |
| Mine | Kingdom of Bretonnia | 5 | 0 | 0 | 0 | 1 (net +210) | 1 (net +0) | 2 (net +0) | 1 | 0% (0 of 4) |
| Mine | Lizardmen | 4 | 0 | 0 | 0 | 2 (net +582) | 0 | 2 (net +128) | 0 | 0% (0 of 4) |
| Mine | Ogre Kingdoms | 6 | 1 (net +0) | 0 | 1 (net -34) | 0 | 0 | 3 (net +163) | 1 | 20% (1 of 5) |
| Mine | Skaven | 4 | 0 | 0 | 1 (net +0) | 0 | 0 | 3 (net +22) | 0 | 25% (1 of 4) |
| Mine | Tomb Kings of Khemri | 9 | 1 (net +0) | 1 (net +56) | 1 (net +0) | 3 (net +161) | 1 (net +120) | 2 (net +132) | 0 | 11% (1 of 9) |
| Mine | Vampire Counts | 8 | 0 | 0 | 1 (net +107) | 2 (net +0) | 2 (net +58) | 1 (net +186) | 2 | 17% (1 of 6) |
| Mine | Warriors of Chaos | 10 | 0 | 0 | 1 (net -465) | 1 (net +0) | 3 (net +26) | 2 (net +182) | 3 | 14% (1 of 7) |
| Opponent | High Elf Realms | 24 | 4 (net -104) | 0 | 3 (net +329) | 8 (net +60) | 1 (net +85) | 5 (net +218) | 3 | 14% (3 of 21) |
| Opponent | Lizardmen | 4 | 0 | 0 | 2 (net +290) | 0 | 0 | 1 (net +0) | 1 | 67% (2 of 3) |
| Opponent | Orc & Goblin Tribes | 12 | 1 (net -165) | 0 | 1 (net -350) | 0 | 0 | 2 (net -55) | 8 | 25% (1 of 4) |
| Opponent | Skaven | 7 | 0 | 0 | 1 (net +80) | 1 (net +118) | 1 (net +185) | 4 (net +73) | 0 | 14% (1 of 7) |
| Opponent | Tomb Kings of Khemri | 9 | 0 | 0 | 1 (net +685) | 1 (net +0) | 0 | 6 (net +69) | 1 | 12% (1 of 8) |
| Opponent | Vampire Counts | 24 | 5 (net +178) | 0 | 4 (net +199) | 4 (net +158) | 5 (net +113) | 5 (net +97) | 1 | 17% (4 of 23) |
| Opponent | Warriors of Chaos | 33 | 4 (net +164) | 0 | 1 (net +110) | 5 (net +55) | 4 (net +70) | 13 (net +103) | 6 | 4% (1 of 27) |
| Opponent | Wood Elf Realms | 30 | 7 (net -93) | 2 (net +0) | 2 (net -195) | 8 (net +90) | 1 (net +125) | 8 (net +221) | 2 | 7% (2 of 28) |

### Charged fights, damage counted: fw-h2h2-opp-1eea44e-p4

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 6 | 114 | 305 | -47 | 98 | 50 | +49 | +42.9 |
| Mine | 50-54% | 1 | 195 | 201 | +56 | 251 | 195 | +56 | +28.7 |
| Mine | Effective (55-75%) | 16 | 308 | 219 | -30 | 47 | 121 | -74 | -24.0 |
| Mine | 76-89% | 21 | 285 | 171 | +101 | 146 | 40 | +105 | +37.0 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 36 | 213 | 163 | +98 | 116 | 22 | +95 | +44.4 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 16 | 397 | 89 | +34 | 92 | 55 | +37 | +9.4 |
| Mine | No odds | 9 | 265 | 85 | +15 | 45 | 13 | +32 | +12.1 |
| Mine | All fights | 105 | 269 | 164 | +53 | 102 | 48 | +54 | +20.1 |
| Opponent | Long shot (under 50%) | 21 | 267 | 287 | +15 | 114 | 103 | +11 | +4.0 |
| Opponent | 50-54% | 2 | 301 | 264 | +0 | 2 | 81 | -79 | -26.3 |
| Opponent | Effective (55-75%) | 15 | 314 | 259 | +167 | 254 | 107 | +147 | +46.9 |
| Opponent | 76-89% | 27 | 328 | 152 | +83 | 101 | 22 | +79 | +24.1 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 44 | 252 | 198 | +120 | 155 | 42 | +113 | +44.9 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 12 | 507 | 106 | +103 | 115 | 4 | +111 | +21.8 |
| Opponent | No odds | 22 | 274 | 184 | +80 | 145 | 89 | +56 | +20.4 |
| Opponent | All fights | 143 | 301 | 200 | +93 | 142 | 59 | +84 | +27.8 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| fw-h2h2-opp-1eea44e-p4 | move | 464 | 103 (22%) | 79 (17%) | 63 (14%) | 298 (64%) |
| fw-h2h2-opp-1eea44e-p4 | objective | 375 | 41 (11%) | 30 (8%) | 47 (13%) | 287 (77%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0114, L0130, L2527, L2634 |
| Charmed Shield | Opponent | L0434, L0624, L0926, L1034, L1126, L1427, L2227, L2527, L2634, L3234 |
| Clockwork Compass | Mine | L1220 |
| Elixir of Power | Mine | L1126 |
| Elixir of Power | Opponent | L0819, L1719, L1819 |
| Fistful of Laurels | Mine | L1819, L1835 |
| Invocation of Nehek | Mine | L2527 |
| Invocation of Nehek | Opponent | L0624, L1427, L2227, L2527 |
| Opal Amulet | Mine | L1427 |
| Opal Amulet | Opponent | L0114, L0214, L1314 |
| Periapt of Soul Exchange | Mine | L2021, L2123 |
| Periapt of Soul Exchange | Opponent | L0520, L1220, L1621, L2021 |
| Ring of Doom | Mine | L0214, L0230, L1126, L1220, L1523 |
| Ring of Doom | Opponent | L0315, L1331, L2331 |
| Ring of Jet | Mine | L1017, L1034, L1126, L1220 |
| Standard of the Fell Warrior | Mine | L1314, L1331 |
| Standard of the Fell Warrior | Opponent | L0713 |
| Storm Daemon (Renegade 2.0) | Mine | L2123 |
| Storm Daemon (Renegade 2.0) | Opponent | L1621, L2021 |
| Twice-Blessed Armour | Mine | L0713, L0729, L1017, L1034 |
| Witch Hunter's Ward | Mine | L0713, L0729, L0819, L0835 |
| Witch Hunter's Ward | Opponent | L0608 |

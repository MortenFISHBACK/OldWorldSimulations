# Doctrine scorecard: fw-h2h2-mine-1eea44e-p2

### Scorecard: fw-h2h2-mine-1eea44e-p2

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0106 | 4 | 1 | Mine | no | 3 | 4 | 2 | 1 | 0 | 0 | 0 | 120 |
| L0106 | 4 | 1 | Opponent | no | 0 | 6 | 2 | 1 | 0 | 0 | 0 | 1109 |
| L0122 | 2 | 1 | Mine | - | - | - | 0 | 2 | 1 | 0 | 0 | 317 |
| L0122 | 2 | 1 | Opponent | - | - | 2 | 6 | 0 | 1 | 0 | 0 | 0 |
| L0206 | 2 | 1 | Mine | - | - | 3 | 4 | 3 | 1 | 0 | 0 | 0 |
| L0206 | 2 | 1 | Opponent | - | - | 4 | 1 | 0 | 1 | 0 | 0 | 515 |
| L0222 | 6 | 1 | Mine | no | 2 | 3 | 2 | 3 | 1 | 0 | 0 | 170 |
| L0222 | 6 | 1 | Opponent | no | 1 | 3 | 1 | 0 | 1 | 0 | 0 | 0 |
| L0307 | 1 | 1 | Mine | no | 0 | 5 | 1 | 2 | 0 | 0 | 0 | 760 |
| L0307 | 1 | 1 | Opponent | yes | 0 | 2 | 1 | 1 | 0 | 0 | 0 | 420 |
| L0323 | 5 | 1 | Mine | no | - | - | 0 | 1 | 0 | 0 | 0 | 675 |
| L0323 | 5 | 1 | Opponent | yes | - | 2 | 7 | 3 | 1 | 0 | 0 | 140 |
| L0409 | 1 | 1 | Mine | no | 2 | 2 | 5 | 0 | 0 | 0 | 0 | 0 |
| L0409 | 1 | 1 | Opponent | no | 3 | 2 | 0 | 1 | 0 | 0 | 0 | 945 |
| L0425 | 5 | 1 | Mine | yes | - | 2 | 5 | 5 | 0 | 0 | 0 | 0 |
| L0425 | 5 | 1 | Opponent | no | - | - | 1 | 2 | 1 | 0 | 0 | 416 |
| L0512 | 2 | 1 | Mine | - | - | - | 0 | 2 | 0 | 0 | 0 | 1042 |
| L0512 | 2 | 1 | Opponent | - | - | 2 | 0 | 3 | 1 | 0 | 0 | 330 |
| L0528 | 6 | 1 | Mine | no | 0 | 1 | 1 | 0 | 0 | 0 | 0 | 593 |
| L0528 | 6 | 1 | Opponent | no | 1 | 3 | 1 | 1 | 0 | 0 | 0 | 0 |
| L0616 | 4 | 1 | Mine | no | 0 | 6 | 1 | 1 | 0 | 0 | 0 | 615 |
| L0616 | 4 | 1 | Opponent | yes | 0 | 4 | 3 | 1 | 2 | 0 | 0 | 200 |
| L0632 | 2 | 1 | Mine | - | - | 3 | 1 | 0 | 0 | 0 | 0 | 929 |
| L0632 | 2 | 1 | Opponent | - | - | 2 | 0 | 4 | 1 | 0 | 0 | 0 |
| L0721 | 1 | 1 | Mine | yes | 0 | 1 | 3 | 0 | 0 | 0 | 0 | 375 |
| L0721 | 1 | 1 | Opponent | no | 1 | - | 1 | 3 | 0 | 0 | 0 | 257 |
| L0810 | 6 | 1 | Mine | no | 0 | 2 | 1 | 1 | 0 | 0 | 0 | 769 |
| L0810 | 6 | 1 | Opponent | no | 14 | 2 | 4 | 1 | 1 | 0 | 0 | 330 |
| L0827 | 5 | 1 | Mine | no | - | - | 0 | 1 | 0 | 0 | 0 | 515 |
| L0827 | 5 | 1 | Opponent | yes | - | 3 | 1 | 5 | 0 | 0 | 0 | 0 |
| L0918 | 6 | 1 | Mine | no | 0 | 3 | 4 | 1 | 0 | 0 | 0 | 420 |
| L0918 | 6 | 1 | Opponent | no | 13 | 2 | 4 | 3 | 0 | 0 | 0 | 234 |
| L0934 | 4 | 1 | Mine | no | 0 | 1 | 1 | 1 | 0 | 0 | 0 | 723 |
| L0934 | 4 | 1 | Opponent | yes | 1 | 2 | 7 | 3 | 0 | 0 | 0 | 160 |
| L1026 | 6 | 1 | Mine | no | 4 | 2 | 3 | 0 | 0 | 0 | 0 | 330 |
| L1026 | 6 | 1 | Opponent | no | 4 | 2 | 2 | 1 | 1 | 0 | 0 | 0 |
| L1118 | 2 | 1 | Mine | - | - | 2 | 3 | 0 | 0 | 0 | 0 | 330 |
| L1118 | 2 | 1 | Opponent | - | - | 3 | 2 | 2 | 1 | 0 | 0 | 305 |
| L1135 | 1 | 1 | Mine | no | 0 | 2 | 5 | 0 | 0 | 0 | 0 | 330 |
| L1135 | 1 | 1 | Opponent | yes | 0 | 2 | 4 | 2 | 0 | 0 | 0 | 0 |
| L1228 | 4 | 1 | Mine | no | 2 | 2 | 4 | 1 | 0 | 0 | 0 | 524 |
| L1228 | 4 | 1 | Opponent | no | 0 | 6 | 1 | 1 | 0 | 0 | 0 | 0 |
| L1323 | 3 | 1 | Mine | no | 12 | 2 | 0 | 1 | 1 | 0 | 0 | 317 |
| L1323 | 3 | 1 | Opponent | no | 0 | 2 | 2 | 1 | 1 | 0 | 0 | 66 |
| L1418 | 2 | 1 | Mine | - | - | 2 | 1 | 0 | 0 | 0 | 0 | 0 |
| L1418 | 2 | 1 | Opponent | - | - | 2 | 3 | 2 | 1 | 0 | 0 | 0 |
| L1435 | 1 | 1 | Mine | no | 0 | 3 | 1 | 1 | 0 | 0 | 0 | 0 |
| L1435 | 1 | 1 | Opponent | no | 1 | 1 | 3 | 3 | 0 | 0 | 0 | 140 |
| L1531 | 1 | 1 | Mine | no | 1 | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| L1531 | 1 | 1 | Opponent | no | 3 | 2 | 6 | 0 | 3 | 0 | 0 | 340 |
| L1629 | 3 | 1 | Mine | no | 3 | 1 | 1 | 1 | 0 | 0 | 0 | 200 |
| L1629 | 3 | 1 | Opponent | no | 0 | 2 | 5 | 2 | 0 | 0 | 0 | 170 |
| L1727 | 5 | 1 | Mine | no | - | 3 | 2 | 0 | 0 | 0 | 0 | 0 |
| L1727 | 5 | 1 | Opponent | yes | - | 2 | 7 | 2 | 0 | 0 | 0 | 0 |
| L1827 | 3 | 1 | Mine | no | 0 | - | 2 | 1 | 1 | 0 | 0 | 602 |
| L1827 | 3 | 1 | Opponent | no | 10 | 2 | 7 | 2 | 0 | 0 | 0 | 0 |
| L1927 | 1 | 1 | Mine | no | 0 | 1 | 6 | 1 | 0 | 0 | 0 | 0 |
| L1927 | 1 | 1 | Opponent | no | 1 | 4 | 3 | 2 | 0 | 0 | 0 | 60 |
| L2029 | 1 | 1 | Mine | no | 1 | - | 1 | 1 | 2 | 0 | 0 | 420 |
| L2029 | 1 | 1 | Opponent | no | 2 | 2 | 3 | 2 | 1 | 0 | 0 | 0 |
| L2131 | 1 | 1 | Mine | yes | 4 | - | 1 | 3 | 1 | 0 | 0 | 290 |
| L2131 | 1 | 1 | Opponent | yes | 0 | 2 | 3 | 1 | 1 | 0 | 0 | 0 |
| L2235 | 3 | 1 | Mine | no | 11 | 1 | 6 | 0 | 0 | 0 | 0 | 170 |
| L2235 | 3 | 1 | Opponent | no | 1 | 2 | 8 | 0 | 0 | 0 | 0 | 0 |
| L2429 | 5 | 1 | Mine | yes | - | 4 | 3 | 1 | 0 | 0 | 0 | 0 |
| L2429 | 5 | 1 | Opponent | yes | - | 3 | 3 | 0 | 0 | 0 | 0 | 170 |
| L2535 | 3 | 1 | Mine | no | 15 | 3 | 1 | 2 | 0 | 0 | 0 | 0 |
| L2535 | 3 | 1 | Opponent | no | 0 | 2 | 5 | 0 | 0 | 0 | 0 | 272 |
| L2735 | 5 | 1 | Mine | yes | - | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L2735 | 5 | 1 | Opponent | yes | - | 2 | 3 | 2 | 0 | 0 | 0 | 0 |
| L3033 | 3 | 1 | Mine | yes | 3 | 2 | 4 | 1 | 0 | 0 | 0 | 207 |
| L3033 | 3 | 1 | Opponent | no | 1 | 1 | 6 | 2 | 0 | 0 | 0 | 144 |
| **Average** | | | Mine | 20% | 2.6 | 2.4 | 2.2 | 1.1 | 0.2 | 0.0 | 0.0 | 326.2 |
| **Average** | | | Opponent | 33% | 2.4 | 2.5 | 3.2 | 1.6 | 0.5 | 0.0 | 0.0 | 186.8 |

### KPIs: fw-h2h2-mine-1eea44e-p2

Rules off - Opponent only: WAR ENGINE JOBS, STAY WEIGHED, BEST FIRST, RANDOM MOVE BY FIGURES, RANDOM MOVER NO PROMISE, STABLE ROLE, WOUNDED STAYS OUT, BEST FACING, LOST CHARGE, SCREEN BY WHAT IT SAVES, REDIRECT BY WHAT IT STOPS, SHOOTER COUNTED ONCE, LURE BY WHAT IT DRAWS, HILL BY ITS CHANCE, MOVE TO CHARGE, LONG SHOT, DEFENSIVE ARMY, SHOOTS FROM THE BEST SPOT, SUPPORTS, RESERVE FALL BACK, WAIT AFTER COSTS, CHARGE NOW FIRST, SUPPORT NARROWED, WAR ENGINE CHARGES, DEFENSIVE FLOOR.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 30% (55 of 185) | 0% (0 of 181) | 15% (55 of 366) |
| Winner chose to follow up after the loser gave ground |  | 96% (87 of 91); on the table 98% | 96% (49 of 51); on the table 96% | 96% (136 of 142); on the table 97% |
| Winner chose to pursue after the loser fell back in good order |  | 100% (8 of 8); on the table 100% | 100% (15 of 15); on the table 100% | 100% (23 of 23); on the table 100% |
| Winner chose to pursue after the loser fled |  | 83% (29 of 35); on the table 83% | 85% (22 of 26); on the table 85% | 84% (51 of 61); on the table 84% |
| Winner chose to follow up or pursue (all three) |  | 93% (124 of 134); on the table 94% | 93% (86 of 92); on the table 93% | 93% (210 of 226); on the table 94% |
| Magic missiles tried each own turn | 50%+ | 26% (88 of 342) | 20% (31 of 156) | 24% (119 of 498) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 40% (88 of 221) | 29% (31 of 106) | 36% (119 of 327) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 72% (18 of 25) | - | 72% (18 of 25) |
| Points that never fought | lower | 31% (22454 of 71583) | 37% (26606 of 71989) | 34% (49060 of 143572) |
|   infantry points that never fought | lower | 41% (6628 of 16324) | 61% (8609 of 14029) | 50% (15237 of 30353) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 57% (163 of 284) | 57% (170 of 297) | 57% (333 of 581) |
| Bound items with a magic missile used (at least once a game) |  | 95% (19 of 20); 1.8 uses a game | 61% (11 of 18); 0.9 uses a game | 79% (30 of 38); 1.3 uses a game |
| Bound items with another spell used |  | 56% (10 of 18); 0.6 uses a game | 50% (1 of 2); 0.1 uses a game | 55% (11 of 20); 0.3 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 45% (9 of 20); 0.2 uses a game | 14% (1 of 7); 0.0 uses a game | 37% (10 of 27); 0.1 uses a game |
|   their share of the points of units over 100 pts | lower | 54% (32479 of 60231) | 49% (31139 of 63281) | 52% (63618 of 123512) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 2.2 (31%) | 0.9 (26%) | 3.1 (30%) |
| MARCHED: its unit marched | 1.0 (15%) | 0.6 (16%) | 1.6 (15%) |
| CHARGED: its unit charged | 0.3 (5%) | 0.1 (4%) | 0.5 (4%) |
| IN COMBAT: engaged in combat | 1.9 (27%) | 0.4 (11%) | 2.3 (22%) |
| REAR RANK: in a rear rank | 0.1 (1%) | 0.2 (7%) | 0.3 (3%) |
| FLEEING: fleeing | 0.1 (2%) | 0.0 (1%) | 0.2 (2%) |
| GONE: slain | 0.8 (11%) | 0.6 (16%) | 1.4 (13%) |
| OFF THE TABLE: off the table or not arrived | 0.5 (7%) | 0.4 (12%) | 0.9 (9%) |
| STUPIDITY: Stupidity | 0.1 (1%) | 0.1 (3%) | 0.2 (2%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.1 (3%) | 0.1 (1%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 3.7 | 1.4 | 1.2 | 3.3 | 0.4 | 1.4 |
| not cast | 4.1 | 3.6 | 3.8 | 10.5 | 2.0 | 20.3 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.1 (2%) | 0.0 (0%) | 0.0 (0%) | 1.3 (6%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.1 (1%) | 1.6 (45%) | 0.4 (9%) | 3.1 (30%) | 0.3 (17%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.6 (15%) | 0.3 (15%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.5 (4%) | 0.1 (6%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.1 (1%) | 0.2 (5%) | 0.7 (18%) | 2.3 (22%) | 0.2 (11%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.4 (11%) | 0.4 (12%) | 0.3 (8%) | 0.3 (3%) | 0.0 (0%) | 0.0 (0%) |
| NO CASTS LEFT: every cast used on other spells | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) |
| FLEEING: fleeing | 0.1 (3%) | 0.1 (2%) | 0.1 (4%) | 0.2 (2%) | 0.0 (0%) | 0.6 (3%) |
| GONE: slain | 1.1 (26%) | 0.6 (18%) | 0.6 (15%) | 1.4 (13%) | 0.4 (20%) | 3.8 (19%) |
| OFF THE TABLE: off the table or not arrived | 0.3 (7%) | 0.2 (5%) | 0.5 (12%) | 0.9 (9%) | 0.2 (11%) | 0.9 (5%) |
| STUPIDITY: Stupidity | 0.1 (3%) | 0.1 (4%) | 0.1 (1%) | 0.2 (2%) | 0.0 (0%) | 0.5 (2%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (1%) | 0.3 (8%) | 0.0 (0%) | 0.0 (0%) | 0.4 (18%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.9 (46%) | 0.1 (2%) | 1.2 (31%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 13.2 (65%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.9 a game | 0.5 a game | 0.7 a game |
| stood (cast and not dispelled) | 66% (19 of 29) | 33% (6 of 18) | 53% (25 of 47) |
| the unit moved after it | 53% (10 of 19) | 83% (5 of 6) | 60% (15 of 25) |
| it charged on its next turn | 5% (1 of 19) | 33% (2 of 6) | 12% (3 of 25) |
| the enemy charged it first | 21% (4 of 19) | 17% (1 of 6) | 20% (5 of 25) |
| it fought by the end of its next turn | 16% (3 of 19) | 0% (0 of 6) | 12% (3 of 25) |
| it moved out of a charge the enemy had planned (not charged first) | 11% (2 of 19) | 33% (2 of 6) | 16% (4 of 25) |
| none of these (no charge, no fight, no charge escaped) | 63% (12 of 19) | 50% (3 of 6) | 60% (15 of 25) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 66% (581 of 875) | 52% (414 of 792) | 60% (995 of 1667) |
|   cavalry | 62% (47 of 76) | 57% (93 of 163) | 59% (140 of 239) |
|   character | 62% (67 of 108) | 25% (28 of 112) | 43% (95 of 220) |
|   chariot | 45% (50 of 112) | 52% (23 of 44) | 47% (73 of 156) |
|   infantry | 63% (160 of 255) | 58% (176 of 305) | 60% (336 of 560) |
|   monster | 48% (19 of 40) | 44% (18 of 41) | 46% (37 of 81) |
|   war machine | 84% (238 of 284) | 60% (76 of 127) | 76% (314 of 411) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.1 (25%) | 2.6 (25%) | 4.7 (25%) |
| CHARGED: it charged | 1.2 (15%) | 1.8 (17%) | 3.0 (16%) |
| FLEEING: it fled or was fleeing | 0.1 (1%) | 0.2 (2%) | 0.2 (1%) |
| IN COMBAT: it fought this turn or the last | 1.2 (14%) | 0.7 (6%) | 1.8 (10%) |
| MOVED: a war machine that moved | 0.1 (1%) | 0.0 (0%) | 0.1 (0%) |
| NO TARGET IN RANGE | 1.1 (14%) | 1.9 (18%) | 3.1 (16%) |
| ONLY IN COMBAT: the only targets were in combat | 0.5 (6%) | 0.5 (5%) | 1.0 (6%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.1 (13%) | 1.6 (15%) | 2.7 (14%) |
| SHELTERED: the target was sheltered | 0.6 (7%) | 0.6 (5%) | 1.2 (6%) |
| STUPIDITY | 0.0 (0%) | 0.1 (1%) | 0.1 (0%) |
| OTHER BAR | 0.3 (3%) | 0.6 (5%) | 0.8 (4%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 6.1 | 1.2 | 84% | 3.9 pts | 24 pts |
| character | 2.8 | 0.9 | 76% | 8.8 pts | 24 pts |
| chariot | 2.1 | 0.9 | 74% | 11.5 pts | 24 pts |
| infantry | 13.4 | 4.8 | 73% | 9.3 pts | 125 pts |
| monster | 1.3 | 0.4 | 74% | 10.2 pts | 13 pts |
| war machine | 8.7 | 7.1 | 64% | 27.2 pts | 237 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.9 | 5.7 | 5.3 |
| Charges that made contact a game | 3.5 | 4.2 | 3.9 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.00 declared, 0.72 contact (25 units) | 0.69 declared, 0.46 contact (13 units) | 0.89 declared, 0.63 contact (38 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.57 declared, 0.43 contact (7 units) | 1.00 declared, 0.73 contact (11 units) | 0.83 declared, 0.61 contact (18 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.62 declared, 0.43 contact (242 units) | 0.63 declared, 0.48 contact (292 units) | 0.63 declared, 0.46 contact (534 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 58% (42 of 73) | 67% (12 of 18) | 33% (4 of 12) | 56% (58 of 103) |
| Character in a unit | 72% (21 of 29) | 83% (10 of 12) | 33% (1 of 3) | 73% (32 of 44) |
| Character on its own | 79% (34 of 43) | 52% (22 of 42) | 22% (14 of 63) | 47% (70 of 148) |
| Chariot | 71% (12 of 17) | 77% (10 of 13) | - | 73% (22 of 30) |
| Infantry | 49% (46 of 94) | 59% (20 of 34) | 67% (2 of 3) | 52% (68 of 131) |
| Monster | 59% (17 of 29) | 78% (7 of 9) | - | 63% (24 of 38) |
| Monstrous | 57% (8 of 14) | 57% (8 of 14) | - | 57% (16 of 28) |
| War Machines | 72% (41 of 57) | 100% (2 of 2) | - | 73% (43 of 59) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 100% (20 of 20); on the table 100% | 20% (20 of 102) | 24% | 41% (9 of 22) | 100% (6 of 6); 4.0 uses a game | 100% (2 of 2); 1.8 uses a game | 83% (5 of 6); 1.2 uses a game |
| Chaos Dwarfs | 4 | 100% (18 of 18); on the table 100% | 44% (16 of 36) | 44% | 59% (19 of 32) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |
| Dwarfen Mountain Holds | 6 | 67% (6 of 9); on the table 78% | - | 46% | 78% (42 of 54) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 7 | 80% (12 of 15); on the table 80% | 21% (10 of 48) | 54% | 64% (49 of 76) | 0.0 uses a game | 100% (2 of 2); 0.6 uses a game | 50% (2 of 4); 0.3 uses a game |
| Grand Cathay | 6 | 89% (24 of 27); on the table 93% | 20% (28 of 138) | 38% | 52% (28 of 54) | 79% (11 of 14); 7.5 uses a game | 0% (0 of 2); 0.0 uses a game | 0% (0 of 6); 0.0 uses a game |
| High Elf Realms | 4 | 100% (13 of 13); on the table 100% | 11% (2 of 18) | 28% | 27% (9 of 33) | 100% (3 of 3); 2.5 uses a game | 50% (7 of 14); 3.2 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 2 | 100% (8 of 8); on the table 100% | - | 51% | 50% (6 of 12) | 0.0 uses a game | 0.0 uses a game | 100% (2 of 2); 1.0 uses a game |
| Lizardmen | 1 | 100% (6 of 6); on the table 100% | - | 17% | 57% (4 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 4 | 88% (7 of 8); on the table 88% | 0% (0 of 18) | 41% | 79% (22 of 28) | 75% (3 of 4); 1.2 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 1 | 100% (3 of 3); on the table 100% | 33% (4 of 12) | 6% | 38% (3 of 8) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Skaven | 3 | 86% (6 of 7); on the table 86% | 28% (5 of 18) | 28% | 64% (16 of 25) | 100% (2 of 2); 1.7 uses a game | 0.0 uses a game | 0% (0 of 3); 0.0 uses a game |
| Tomb Kings of Khemri | 5 | 94% (16 of 17); on the table 94% | - | 32% | 36% (9 of 25) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 9 | 100% (33 of 33); on the table 100% | 35% (23 of 66) | 27% | 67% (36 of 54) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 9 | 87% (26 of 30); on the table 87% | 22% (4 of 18) | 21% | 51% (37 of 73) | 100% (2 of 2); 0.7 uses a game | 0.0 uses a game | 100% (1 of 1); 0.1 uses a game |
| Wood Elf Realms | 7 | 100% (12 of 12); on the table 100% | 29% (7 of 24) | 31% | 56% (44 of 78) | 43% (3 of 7); 1.4 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (fw-h2h2-mine-1eea44e-p2, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 52% (45) | 50% (38) | 51% (83) |
| ...free all their last turn and able to turn (per game) | 0.69 | 0.56 | 1.25 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.19 | 0.28 | 0.47 |
| ...with the charger already in that arc before they moved (per game) | 0.42 | 0.36 | 0.78 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 2.06 | 1.03 | 3.08 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 1.56 | 0.72 | 2.28 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 5.33 | 6.17 | 11.50 |

### Quality by phase: fw-h2h2-mine-1eea44e-p2

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.8 | 3.3 |
| Strategy | Charge objectives carried out (made contact) | 49% (79 of 160) | 48% (89 of 187) |
| Strategy | Shoot objectives carried out (shot that target) | 42% (158 of 373) | 52% (99 of 192) |
| Strategy | Close-in objectives charged next turn | 13% (19 of 143) | 19% (40 of 208) |
| Strategy | Support requests answered (helper made contact too) | 44% (11 of 25) | 31% (10 of 32) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 83% (5 of 6) | - |
| Strategy | Hexes on a unit its side charged or shot that turn | 45% (9 of 20) | 62% (5 of 8) |
| Strategy | Joined characters whose unit fought | 70% (30 of 43) | 27% (7 of 26) |
| Strategy | Lone characters that fought | 75% (77 of 102) | 75% (73 of 97) |
| Movement | Charges halted short of contact | 0.1 | 0.3 |
| Movement | Idle units | 1.1 | 1.6 |
| Movement | Points that never moved of their own | 326.2 | 186.8 |
| Movement | Fights charged into per game | 3.0 | 3.7 |
| Movement | Charges with odds: long shots (under 50%) | 13 of 95, net +88 | 23 of 115, net +83 |
| Movement | Charges with odds: sweet spot (55-75%) | 11 of 95, net +22 | 23 of 115, net +91 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 19 of 95, net +57 | 4 of 115, net +104 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 29 of 95, net +127 | 39 of 115, net +64 |
| Shooting | Shots by shooting units (incl. breath weapons) | 10.3 | 10.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 42% (156 of 371) | 44% (164 of 372) |
| Shooting | Points destroyed by shooting units | 52.3 | 60.5 |
| Shooting | War machine shots | 6.6 | 2.1 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 59% (141 of 238) | 51% (39 of 76) |
| Shooting | Points destroyed by war machines | 106.7 | 43.8 |
| Magic | Magic missiles cast | 1.6 | 0.5 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 32% (18 of 57) | 47% (9 of 19) |
| Magic | Wounds caused by magic missiles | 2.9 | 0.6 |
| Magic | Wounds caused by other spells | 1.1 | 0.3 |
| Magic | Points destroyed by magic (all spells) | 62.9 | 6.4 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.9 / 0.7 / 0.6 / 0.1 | 1.9 / 0.2 / 0.2 / 0.1 |
| Combat | Points destroyed in combat | 396.2 | 447.6 |
| Combat | Points run down | 101.7 | 95.1 |
| Combat | Net points per charged fight, damage counted | +77 | +96 |
| Combat | Net per 100 charger points, damage counted | +27.7 | +35.2 |
| Combat | First round won (charged fights) | 66% | 59% |
| Combat | Net points per charged fight | +83 | +97 |
| Combat | Net points per supported fight / lone fight | +198 / +62 | +90 / +98 |
| Combat | Charged fights on a top-3 enemy unit | 32 of 108 | 56 of 134 |
| Game | Points lost | 783.6 | 760.1 |
| Game | VP from objectives | 494.2 | 597.8 |
| Game | Lone holders (player turns) | 2.6 | 2.4 |

- Mine won / drew / lost: 13 / 8 / 15 of 36 ended games (of 36); mean margin (Mine - Opponent) -113 VP
- The side that went first won 13 of 28 games with a winner
- Points traded per game (both sides' losses): 1544
- Games not ended: 0; findings 2, warnings 1

### Opponent rules: fw-h2h2-mine-1eea44e-p2

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| ALREADY CARRIED | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARRIVAL HUNT | - | - | - | - | 0.1 | +0.7 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.6 | +0.0 | 0.0 | 40.4 | 0.3 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | 1.1 | +7.7 | 0.0 | 26.6 | 1.3 | +17.3 | 0.0 | 37.3 |
| BEST FACING | 0.8 | +16.5 | 0.0 | 7.0 | - | - | - | - |
| BEST FIRST | 4.2 | +211.9 | 117.4 | 88.9 | - | - | - | - |
| BEST OVERALL | 1.1 | +61.1 | 0.0 | 37.7 | 0.3 | +29.0 | 0.0 | 20.5 |
| BEST PREY | 0.7 | +38.0 | 18.1 | 14.1 | 5.1 | +391.4 | 283.2 | 97.7 |
| BEST PRIZE | 0.1 | +0.6 | 6.4 | 5.4 | 0.1 | -6.2 | 7.5 | 13.7 |
| BIG CHARACTER SAFETY | 0.1 | +0.7 | 0.0 | 12.1 | 0.1 | -0.5 | 0.0 | 12.1 |
| BLOCKED CHARGE SKIPPED | 0.1 | +0.0 | 0.0 | 0.0 | 0.0 | +0.0 | 7.8 | 0.0 |
| BLOCKED WHEEL | 0.3 | +7.4 | 0.0 | 0.0 | 0.5 | +5.7 | 0.0 | 0.0 |
| BOMBING RUN | - | - | - | - | 0.0 | +0.5 | 2.2 | 0.0 |
| CANNON PLAN MISSED | 1.0 | +0.0 | 137.0 | 17.9 | 0.2 | +0.0 | 32.8 | 0.0 |
| CANNON PLANNED TARGET | 4.8 | +170.1 | 310.4 | 88.6 | 1.5 | +76.8 | 141.0 | 22.4 |
| CANNON SIGHT KEPT | 1.3 | +0.0 | 0.0 | 5.8 | 0.6 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT COUNTER | 0.1 | +0.0 | 0.0 | 7.4 | 0.1 | +0.0 | 24.1 | 0.0 |
| CARRIES OUT SET-UP | 0.0 | +0.0 | 13.1 | 0.0 | 0.2 | -4.0 | 47.4 | 0.0 |
| CAST JOB | 0.7 | +18.7 | 58.1 | 65.6 | 0.2 | +6.3 | 23.5 | 17.2 |
| CASTER AWAY FROM SCREEN | 0.3 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.2 | +20.3 | 26.4 | 8.9 | 0.2 | +14.0 | 19.3 | 0.0 |
| CASTS AFTER FRIENDS | 0.5 | +0.0 | 0.0 | 55.8 | 0.2 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CHAFF PASSED | 0.3 | -0.5 | 15.3 | 22.2 | 0.3 | -0.3 | 0.0 | 4.4 |
| CHARGE NOW FIRST | 2.6 | +0.0 | 259.1 | 74.5 | - | - | - | - |
| CHARGE NOW WEIGHED | 0.5 | -28.3 | 38.6 | 11.4 | 0.4 | -27.0 | 15.0 | 22.5 |
| CHARIOT NO STATIC JOB | 0.0 | +0.0 | 14.2 | 2.4 | 0.1 | +0.0 | 0.0 | 0.0 |
| CHARIOT WIZARD CAREFUL | 0.1 | -0.6 | 0.0 | 0.0 | - | - | - | - |
| CHEAP HELPER | 0.2 | +0.0 | 13.2 | 2.4 | 0.2 | +0.0 | 17.8 | 5.1 |
| COMBAT PIVOT | 0.4 | +0.0 | 9.9 | 44.9 | 0.6 | +0.0 | 10.8 | 47.7 |
| CONTINUE AHEAD WEIGHED | 0.0 | +0.0 | 0.0 | 12.1 | - | - | - | - |
| CONVEYANCE SEARCH | 0.4 | +70.2 | 23.2 | 15.1 | 0.4 | +39.9 | 1.4 | 20.5 |
| COUNTER-CHARGE COVER | 10.7 | +801.7 | 0.0 | 242.1 | 7.1 | +591.5 | 0.0 | 123.0 |
| DEFENSIVE ARMY | 0.4 | +0.0 | 18.1 | 0.0 | - | - | - | - |
| EDGE GIVE GROUND | 0.1 | +4.1 | 13.2 | 3.4 | 0.4 | +17.0 | 65.7 | 0.0 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 2.4 | - | - | - | - |
| FACES THE THREAT | 2.1 | +124.6 | 0.0 | 68.5 | 1.0 | +61.6 | 0.0 | 13.8 |
| FALLBACK BY WORTH | 4.8 | +43.5 | 0.0 | 63.4 | 6.9 | +80.1 | 0.0 | 98.6 |
| FIGHT LIFT | 0.1 | +2.3 | 46.4 | 42.1 | 0.1 | +2.4 | 14.3 | 0.0 |
| FIRE AND FLEE | 0.1 | +0.9 | 0.0 | 2.9 | 0.2 | +2.2 | 3.4 | 6.1 |
| FLANK NOT WEIGHED | 5.5 | +0.0 | 0.0 | 163.1 | 6.0 | +0.0 | 0.0 | 174.0 |
| FOLLOW UP WEIGHED | 1.4 | +170.0 | 0.0 | 46.2 | 1.1 | +177.2 | 0.0 | 18.7 |
| FRIENDS SHOTS CHECKED | 0.3 | +27.1 | 0.0 | 8.8 | 0.2 | +9.9 | 0.0 | 3.4 |
| GIVES UP | - | - | - | - | 1.4 | -55.8 | 197.0 | 69.7 |
| GIVES UP ITS SCREEN | - | - | - | - | 1.2 | -35.1 | 79.4 | 18.7 |
| HELPER ALREADY ASKED | 0.1 | +0.0 | 9.6 | 3.5 | 0.1 | +0.0 | 8.0 | 0.0 |
| HELPER UNSEEN | 0.4 | +0.0 | 32.4 | 24.5 | 0.3 | +0.0 | 13.2 | 16.4 |
| HILL BY ITS CHANCE | 0.4 | -36.5 | 0.0 | 6.5 | - | - | - | - |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HUNT ADVANCE | 0.2 | +2.9 | 14.2 | 2.9 | 0.1 | +2.4 | 11.1 | 0.0 |
| HUNT DROPPED | 0.0 | +0.0 | 0.0 | 0.9 | 0.1 | +0.0 | 11.0 | 0.0 |
| HUNT IN PAIRS | 0.3 | +21.8 | 0.0 | 12.1 | 0.5 | +44.1 | 0.0 | 12.1 |
| HUNT KEPT | 0.1 | +2.7 | 11.2 | 3.8 | 0.2 | +5.4 | 35.8 | 3.1 |
| HUNT RESULT | 0.1 | +21.4 | 0.0 | 3.3 | 0.3 | +58.9 | 32.9 | 6.3 |
| HUNT THE GUNS | 0.1 | +38.8 | 11.2 | 1.4 | 0.3 | +121.5 | 24.9 | 4.3 |
| INVITES THE FIGHT | 1.6 | +33.3 | 45.1 | 8.6 | - | - | - | - |
| JOINT CHARGE PLAN | 0.1 | +4.8 | 9.6 | 10.9 | 0.2 | +13.7 | 8.0 | 6.0 |
| KEEP FALLS | 0.1 | +3.1 | 0.0 | 0.0 | - | - | - | - |
| KEEPS ITS PREY | 0.0 | +0.4 | 0.0 | 0.0 | 0.4 | +3.1 | 22.7 | 21.0 |
| KEEPS ITS TARGET | 1.7 | +50.8 | 186.6 | 54.0 | 2.6 | +76.7 | 268.1 | 50.9 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| KILLS COUNT | 1.7 | +81.8 | 163.6 | 58.6 | 2.0 | +117.9 | 178.6 | 71.9 |
| KILLS COUNT NEXT TURN | 5.0 | +141.8 | 222.9 | 140.1 | 10.2 | +512.1 | 443.8 | 265.1 |
| LONE CHARACTER SAFE SPOT | 0.3 | +5.9 | 5.4 | 11.0 | 0.2 | +1.6 | 10.2 | 16.9 |
| LONE WIZARD HOLDS BACK | 0.2 | +0.0 | 11.1 | 0.0 | 0.1 | +0.0 | 0.0 | 10.8 |
| LONE WIZARD KEPT IN | 0.6 | +39.4 | 0.0 | 0.0 | 0.3 | +23.5 | 0.0 | 0.0 |
| LONG SHOT | 0.5 | -6.3 | 51.4 | 9.8 | - | - | - | - |
| LOST CHARGE | 2.6 | -38.2 | 92.2 | 108.3 | - | - | - | - |
| LURE BY WHAT IT DRAWS | 0.1 | -4.2 | 0.0 | 0.0 | - | - | - | - |
| MAKE SURE TOGETHER | 0.4 | +20.6 | 0.0 | 4.6 | 1.1 | +48.1 | 17.2 | 22.2 |
| MANOEUVRE | 0.1 | +4.4 | 0.0 | 2.6 | 0.2 | +5.5 | 0.0 | 0.0 |
| MARCH AT ESCAPER | - | - | - | - | 0.1 | +2.7 | 0.0 | 9.6 |
| MARCH CHECK | 0.6 | +36.4 | 0.0 | 2.4 | 0.5 | +15.8 | 0.0 | 23.9 |
| MARCH ODDS | 0.2 | +19.3 | 16.3 | 11.1 | 0.3 | +20.5 | 14.0 | 29.9 |
| MARCH OVER CASTS | 0.4 | +36.8 | 0.0 | 25.0 | 0.4 | +14.1 | 0.0 | 24.9 |
| MAX FOR POSITIONING | 4.5 | +151.6 | 0.0 | 130.6 | 5.6 | +261.9 | 0.0 | 94.5 |
| MISSILES IN THE MOVE | 3.8 | +105.5 | 0.0 | 111.1 | 2.3 | +47.7 | 0.0 | 98.9 |
| MISSILES NEXT TURN | 4.6 | +67.9 | 0.0 | 159.2 | 2.9 | +38.0 | 0.0 | 135.6 |
| MODEL FACING | 0.4 | +72.1 | 0.0 | 1.7 | 0.3 | +60.2 | 0.0 | 0.0 |
| MONSTER WIZARD ROAMS | 0.2 | +0.0 | 9.6 | 0.0 | 0.3 | +0.0 | 24.1 | 10.6 |
| MOVE AND CAST | 0.2 | +17.6 | 0.0 | 27.1 | 0.1 | +3.3 | 0.0 | 5.2 |
| MOVE SPELL IN RANGE | 0.1 | +5.0 | 0.0 | 16.1 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.4 | -17.2 | 0.0 | 29.9 | 0.4 | -11.0 | 0.0 | 48.2 |
| MOVE SPELL SPOT | 0.1 | +0.0 | 0.0 | 36.1 | 0.1 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE | 2.4 | +130.9 | 93.0 | 61.0 | - | - | - | - |
| MOVES UNITS SPELL | 0.1 | +3.4 | 0.0 | 0.0 | - | - | - | - |
| NEEDED THERE | 0.1 | +5.8 | 2.6 | 5.2 | 0.1 | +16.3 | 30.7 | 0.0 |
| NO RALLY LEFT | 0.1 | -0.3 | 0.0 | 4.1 | - | - | - | - |
| NOT NEEDED | 0.3 | -21.6 | 23.8 | 6.4 | 0.4 | -19.4 | 37.3 | 6.9 |
| NOT TURNED | 5.3 | +129.0 | 0.0 | 137.5 | 6.2 | +88.1 | 0.0 | 151.5 |
| NOT WORTH A CAST | 0.6 | -0.4 | 0.0 | 42.1 | 0.6 | -0.6 | 0.0 | 1.7 |
| OFF BEST | 15.4 | -701.2 | 24.9 | 309.1 | 18.2 | -1027.9 | 51.7 | 320.9 |
| OPENS A LANE | 0.2 | +3.1 | 11.2 | 0.0 | 0.1 | +0.2 | 21.7 | 0.0 |
| OPENS UP | 0.3 | +22.2 | 15.9 | 17.7 | 0.3 | +26.2 | 8.8 | 0.0 |
| OVERRUNS AWAY | 0.4 | +7.3 | 64.4 | 21.6 | 0.5 | +9.1 | 68.2 | 21.6 |
| PATHS CROSS | 2.2 | +136.3 | 0.0 | 12.3 | 2.7 | +212.8 | 0.0 | 62.6 |
| PIVOT GUARDS FLANK | 0.1 | -1.6 | 0.0 | 0.0 | 0.0 | -0.1 | 0.0 | 0.0 |
| PLAN RESULT | 37.9 | +1529.6 | 1329.8 | 1051.1 | 40.1 | +1357.1 | 1647.8 | 985.0 |
| PURSUES BIG PREY | 0.1 | -7.1 | 0.0 | 0.0 | 0.1 | -4.0 | 0.0 | 0.0 |
| PURSUES ON | 0.0 | -0.1 | 0.0 | 0.0 | - | - | - | - |
| RAIDS THE BAGGAGE NEXT TURN | 0.0 | +1.4 | 0.0 | 0.0 | 0.0 | +2.4 | 0.0 | 0.0 |
| RANDOM MOVE BY FIGURES | 0.7 | +19.1 | 0.0 | 16.4 | - | - | - | - |
| RANDOM MOVER NO PROMISE | 0.2 | -14.7 | 0.0 | 5.8 | - | - | - | - |
| REDIRECT BY WHAT IT STOPS | 0.1 | -3.4 | 0.0 | 0.0 | - | - | - | - |
| REDIRECT COUNTER | 2.0 | +134.7 | 0.0 | 26.2 | 4.5 | +293.9 | 0.0 | 82.0 |
| REDIRECT WEIGHED | 0.2 | +3.2 | 2.9 | 21.5 | 0.4 | +7.6 | 21.7 | 13.7 |
| RESERVE FALL BACK | 0.5 | +11.9 | 0.0 | 14.7 | - | - | - | - |
| RESTRAINS TO SHOOT | 0.2 | +4.5 | 0.0 | 0.0 | 0.1 | +2.3 | 0.0 | 0.0 |
| RISK BY ARC | 2.9 | +59.2 | 285.8 | 138.3 | 3.0 | +59.1 | 290.8 | 119.3 |
| SAFER THAN THE JOB | 1.6 | +97.3 | 0.0 | 44.9 | 0.7 | +53.7 | 0.0 | 27.1 |
| SCOUT SPOT | 0.3 | +0.6 | 0.0 | 1.5 | 0.5 | +2.1 | 0.0 | 0.0 |
| SCOUT WAITS | 0.3 | +0.0 | 0.0 | 1.5 | 0.6 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.0 | -1.4 | 0.0 | 1.2 | - | - | - | - |
| SEARCH SPOT | 2.5 | +124.4 | 0.0 | 52.5 | 1.7 | +98.4 | 0.0 | 24.3 |
| SECOND HUNTER | 0.1 | -0.5 | 5.8 | 2.9 | 0.1 | -0.7 | 9.2 | 0.0 |
| SELF MOVE SPELL | 0.2 | +10.9 | 0.0 | 11.0 | - | - | - | - |
| SET UP TOGETHER | 0.9 | +59.2 | 26.9 | 6.2 | 2.6 | +205.3 | 55.8 | 95.1 |
| SET-UP ANY TARGET | 0.1 | +7.4 | 0.0 | 0.0 | 0.1 | +11.5 | 0.0 | 7.6 |
| SET-UP MISSED | - | - | - | - | 0.1 | +7.5 | 3.5 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.4 | +0.8 | 0.0 | 0.0 | 0.3 | +0.5 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.1 | +38.0 | 76.0 | 5.4 | - | - | - | - |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| SHOT REPLANNED | 0.7 | +0.0 | 211.7 | 6.4 | 0.3 | +0.0 | 55.4 | 6.1 |
| SHOTS IN THE MOVE | 13.7 | +649.4 | 0.0 | 264.6 | 10.8 | +353.7 | 0.0 | 130.8 |
| SPELL CATCH ODDS | 0.0 | -0.4 | 11.1 | 11.1 | - | - | - | - |
| SPELL SETS UP CHARGE | 0.2 | +59.5 | 0.0 | 0.0 | 0.2 | +37.9 | 0.0 | 15.2 |
| SPELL WORTH | 0.8 | +25.2 | 74.5 | 62.5 | 1.6 | +29.2 | 92.8 | 78.5 |
| STABLE ROLE | 11.9 | +0.0 | 376.5 | 164.3 | - | - | - | - |
| STANDS TO CAST | - | - | - | - | 0.0 | +2.6 | 12.1 | 0.0 |
| STOPS | 0.1 | +2.2 | 8.3 | 2.4 | 0.3 | +12.0 | 38.5 | 4.3 |
| STOPS SHORT OF THE FLANK | 0.3 | +14.6 | 0.0 | 12.1 | 0.3 | +16.6 | 0.0 | 18.4 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 4.7 |
| SUPPORT NARROWED | 6.5 | -50.4 | 327.8 | 109.5 | - | - | - | - |
| SUPPORTS | 4.4 | +53.0 | 146.2 | 53.3 | - | - | - | - |
| SURE CHARGE BEATS ADVANCE | 0.0 | -0.3 | 1.1 | 0.0 | 0.1 | -5.8 | 7.2 | 7.0 |
| SURE REACH TOGETHER | 0.3 | -1.1 | 35.9 | 11.1 | 0.9 | +1.0 | 15.9 | 15.8 |
| THROUGH LINE OF FIRE | 0.3 | +10.9 | 0.0 | 0.0 | 0.1 | +6.7 | 0.0 | 0.0 |
| TURN WORTH | 0.4 | -27.9 | 29.0 | 8.8 | 0.2 | -9.8 | 3.5 | 8.3 |
| TWO OR MORE ARRIVE | 0.2 | +0.9 | 9.6 | 1.7 | 0.4 | +2.0 | 8.0 | 17.1 |
| WAIT AFTER COSTS | 6.2 | -252.5 | 245.2 | 91.4 | - | - | - | - |
| WALKS TO THE FIGHT | 1.8 | +35.4 | 59.0 | 16.0 | - | - | - | - |
| WAR ENGINE CHARGES | 0.1 | +21.1 | 9.6 | 0.0 | - | - | - | - |
| WAR ENGINE JOBS | 0.8 | +0.0 | 46.9 | 5.8 | - | - | - | - |
| WEARS DOWN | 1.4 | +58.5 | 146.2 | 36.5 | 1.7 | +62.8 | 216.5 | 71.8 |
| WHO HITS BACK | 0.4 | +36.9 | 0.0 | 48.8 | 0.2 | +38.6 | 0.0 | 25.7 |
| WHOLE FIGHT | 0.4 | +9.0 | 52.0 | 12.8 | 0.3 | -28.4 | 44.8 | 20.7 |
| WHOLE FIGHT GAIN | 0.5 | +48.4 | 78.7 | 11.6 | 0.6 | +61.2 | 46.3 | 15.3 |

### Rule changes: fw-h2h2-mine-1eea44e-p2

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 1207 | 1207 | 1207 | 33.53 | -62245 | -51.6 |
| KILLS COUNT NEXT TURN | 549 | 544 | 183 | 5.08 | +6108 | +33.4 |
| PATHS CROSS | 175 | 175 | 175 | 4.86 | +12566 | +71.8 |
| BEST FIRST | 151 | 151 | 151 | 4.19 | +7629 | +50.5 |
| SEARCH SPOT | 150 | 150 | 145 | 4.03 | +8022 | +55.3 |
| COUNTER-CHARGE COVER | 640 | 333 | 127 | 3.53 | +9385 | +73.9 |
| FACES THE THREAT | 111 | 111 | 111 | 3.08 | +6705 | +60.4 |
| FOLLOW UP WEIGHED | 90 | 90 | 90 | 2.50 | +12499 | +138.9 |
| FALLBACK BY WORTH | 420 | 420 | 88 | 2.44 | +4451 | +50.6 |
| SAFER THAN THE JOB | 82 | 82 | 82 | 2.28 | +5435 | +66.3 |
| BEST PREY | 208 | 200 | 77 | 2.14 | +4262 | +55.3 |
| SHOTS IN THE MOVE | 881 | 563 | 69 | 1.92 | +2550 | +36.9 |
| CANNON SIGHT KEPT | 67 | 67 | 67 | 1.86 | +0 | +0.0 |
| ARTILLERY RE-ROLL WEIGHED | 66 | 66 | 66 | 1.83 | +0 | +0.0 |
| SET UP TOGETHER | 126 | 105 | 54 | 1.50 | +4261 | +78.9 |
| MAX FOR POSITIONING | 364 | 186 | 53 | 1.47 | +392 | +7.4 |
| BEST OVERALL | 50 | 50 | 50 | 1.39 | +3243 | +64.9 |
| SUPPORTS | 157 | 157 | 49 | 1.36 | +558 | +11.4 |
| CANNON PLANNED TARGET | 227 | 227 | 45 | 1.25 | +397 | +8.8 |
| ADVANCE LANE KEPT | 44 | 44 | 44 | 1.22 | +0 | +0.0 |
| REDIRECT COUNTER | 234 | 115 | 44 | 1.22 | +3064 | +69.6 |
| RISK BY ARC | 211 | 197 | 44 | 1.22 | +1229 | +27.9 |
| KILLS COUNT | 132 | 123 | 42 | 1.17 | +1356 | +32.3 |
| WALKS TO THE FIGHT | 66 | 66 | 42 | 1.17 | +625 | +14.9 |
| HOLDS AMBUSHERS | 40 | 40 | 40 | 1.11 | +0 | +0.0 |
| MOVE TO CHARGE | 88 | 88 | 40 | 1.11 | +1456 | +36.4 |
| COMBAT PIVOT | 38 | 38 | 38 | 1.06 | +0 | +0.0 |
| MARCH CHECK | 39 | 38 | 37 | 1.03 | +2394 | +64.7 |
| SHOT REPLANNED | 35 | 35 | 35 | 0.97 | +0 | +0.0 |
| CHARGE NOW WEIGHED | 33 | 33 | 33 | 0.92 | +1890 | +57.3 |
| LONE WIZARD KEPT IN | 33 | 33 | 33 | 0.92 | +2266 | +68.7 |
| SCOUT WAITS | 32 | 32 | 32 | 0.89 | +0 | +0.0 |
| KEEPS ITS TARGET | 153 | 151 | 31 | 0.86 | +402 | +13.0 |
| WAIT AFTER COSTS | 225 | 225 | 31 | 0.86 | +714 | +23.0 |
| BLOCKED WHEEL | 29 | 29 | 29 | 0.81 | +473 | +16.3 |
| BEST FACING | 28 | 28 | 28 | 0.78 | +594 | +21.2 |
| SHOOTERS IN TWO RANKS | 25 | 25 | 25 | 0.69 | +49 | +2.0 |
| MISSILES IN THE MOVE | 220 | 123 | 23 | 0.64 | +829 | +36.0 |
| MODEL FACING | 23 | 23 | 23 | 0.64 | +4765 | +207.2 |
| CHAFF PASSED | 22 | 22 | 22 | 0.61 | -29 | -1.3 |
| STOPS SHORT OF THE FLANK | 22 | 22 | 22 | 0.61 | +1123 | +51.0 |
| MARCH ODDS | 21 | 21 | 21 | 0.58 | +405 | +19.3 |
| REDIRECT WEIGHED | 21 | 21 | 21 | 0.58 | +981 | +46.7 |
| SHOOTS FROM THE BEST SPOT | 38 | 38 | 21 | 0.58 | +667 | +31.8 |
| WHO HITS BACK | 20 | 20 | 20 | 0.56 | +2103 | +105.2 |
| WHOLE FIGHT GAIN | 41 | 33 | 20 | 0.56 | +883 | +44.1 |
| RESERVE FALL BACK | 19 | 19 | 19 | 0.53 | +428 | +22.5 |
| FRIENDS SHOTS CHECKED | 18 | 18 | 18 | 0.50 | +1332 | +74.0 |
| RANDOM MOVE BY FIGURES | 25 | 25 | 18 | 0.50 | +686 | +38.1 |
| CAST JOB | 32 | 32 | 15 | 0.42 | +360 | +24.0 |
| CASTER AWAY FROM SCREEN | 15 | 15 | 15 | 0.42 | +0 | +0.0 |
| CASTS FROM BEHIND | 15 | 15 | 15 | 0.42 | +0 | +0.0 |
| CHARGE NOW FIRST | 93 | 93 | 15 | 0.42 | -598 | -39.8 |
| MAKE SURE TOGETHER | 53 | 35 | 15 | 0.42 | +1093 | +72.9 |
| STUCK PIVOT | 15 | 15 | 15 | 0.42 | +0 | +0.0 |
| THROUGH LINE OF FIRE | 15 | 15 | 15 | 0.42 | +634 | +42.3 |
| SHORT GUN FORWARD | 14 | 14 | 14 | 0.39 | +0 | +0.0 |
| WEARS DOWN | 113 | 106 | 14 | 0.39 | +295 | +21.1 |
| CASTING BLOCK | 18 | 18 | 12 | 0.33 | +577 | +48.1 |
| INVITES THE FIGHT | 58 | 58 | 12 | 0.33 | +175 | +14.6 |
| MANOEUVRE | 12 | 12 | 12 | 0.33 | +355 | +29.6 |
| MOVE AND CAST | 11 | 11 | 11 | 0.31 | +751 | +68.3 |
| OPENS UP | 20 | 19 | 11 | 0.31 | +454 | +41.3 |
| BIG CHARACTER SAFETY | 10 | 10 | 10 | 0.28 | +4 | +0.5 |
| FIRE AND FLEE | 9 | 9 | 9 | 0.25 | +111 | +12.3 |
| RESTRAINS TO SHOOT | 9 | 9 | 9 | 0.25 | +246 | +27.4 |
| BEST PRIZE | 8 | 8 | 8 | 0.22 | -813 | -101.6 |
| OVERRUNS AWAY | 33 | 30 | 8 | 0.22 | +175 | +21.8 |
| LOST CHARGE | 94 | 94 | 7 | 0.19 | +149 | +21.3 |
| NEEDED THERE | 7 | 7 | 7 | 0.19 | +0 | +0.0 |
| HUNT IN PAIRS | 29 | 18 | 6 | 0.17 | +187 | +31.2 |
| PURSUES BIG PREY | 6 | 6 | 6 | 0.17 | -399 | -66.5 |
| WAR ENGINE JOBS | 27 | 27 | 6 | 0.17 | -130 | -21.7 |
| WHOLE FIGHT | 25 | 25 | 6 | 0.17 | +110 | +18.3 |
| KEEP FALLS | 5 | 5 | 5 | 0.14 | +173 | +34.5 |
| SURE CHARGE BEATS ADVANCE | 5 | 5 | 5 | 0.14 | -217 | -43.5 |
| BLOCKED CHARGE SKIPPED | 4 | 4 | 4 | 0.11 | +0 | +0.0 |
| CARRIES OUT SET-UP | 10 | 10 | 4 | 0.11 | -143 | -35.8 |
| KEEPS SCOUTS OR AMBUSH | 4 | 4 | 4 | 0.11 | +0 | +0.0 |
| MOVES UNITS SPELL | 4 | 4 | 4 | 0.11 | +122 | +30.4 |
| PIVOT GUARDS FLANK | 4 | 4 | 4 | 0.11 | -60 | -15.0 |
| SURE REACH TOGETHER | 46 | 34 | 4 | 0.11 | +104 | +26.0 |
| BACKUP TARGETS | 86 | 46 | 3 | 0.08 | +10 | +3.5 |
| MISSILES NEXT TURN | 272 | 144 | 3 | 0.08 | +25 | +8.3 |
| SUPPORT NARROWED | 235 | 235 | 3 | 0.08 | -22 | -7.2 |
| CHARIOT NO STATIC JOB | 5 | 5 | 2 | 0.06 | -26 | -13.1 |
| GIVES UP | 52 | 47 | 2 | 0.06 | +67 | +33.5 |
| MOVE SPELL IN RANGE | 4 | 3 | 2 | 0.06 | +31 | +15.4 |
| NO RALLY LEFT | 2 | 2 | 2 | 0.06 | +40 | +20.0 |
| RAIDS THE BAGGAGE NEXT TURN | 2 | 2 | 2 | 0.06 | +62 | +30.8 |
| STOPS | 12 | 12 | 2 | 0.06 | +83 | +41.7 |
| WAR ENGINE CHARGES | 5 | 5 | 2 | 0.06 | +367 | +183.6 |
| BOMBING RUN | 1 | 1 | 1 | 0.03 | +17 | +17.4 |
| CONTINUE AHEAD WEIGHED | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| DEFENSIVE ARMY | 13 | 13 | 1 | 0.03 | -107 | -106.9 |
| EDGE GIVE GROUND | 19 | 18 | 1 | 0.03 | +10 | +10.1 |
| HUNT ADVANCE | 10 | 10 | 1 | 0.03 | +15 | +15.0 |
| JOINT CHARGE PLAN | 9 | 9 | 1 | 0.03 | +56 | +56.4 |
| LONE WIZARD HOLDS BACK | 11 | 11 | 1 | 0.03 | -37 | -36.7 |
| LONG SHOT | 18 | 18 | 1 | 0.03 | +10 | +9.5 |
| OPENS A LANE | 10 | 9 | 1 | 0.03 | +10 | +10.4 |
| PURSUES ON | 1 | 1 | 1 | 0.03 | -2 | -1.9 |
| STANDS TO CAST | 1 | 1 | 1 | 0.03 | +20 | +19.9 |
| ALREADY CARRIED | 3 | not checked | - | - | - | - |
| ARRIVAL HUNT | 3 | 3 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 44 | 44 | 0 | 0.00 | - | - |
| CARRIES OUT COUNTER | 4 | 4 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 25 | trace | - | - | - | - |
| CHARIOT WIZARD CAREFUL | 3 | 3 | 0 | 0.00 | - | - |
| CHEAP HELPER | 13 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 29 | not checked | - | - | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT LIFT | 7 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 414 | not checked | - | - | - | - |
| GIVES UP ITS SCREEN | 45 | 44 | 0 | 0.00 | - | - |
| HELPER ALREADY ASKED | 6 | not checked | - | - | - | - |
| HELPER UNSEEN | 27 | 25 | 0 | 0.00 | - | - |
| HILL BY ITS CHANCE | 13 | 13 | 0 | 0.00 | - | - |
| HUNT DROPPED | 3 | trace | - | - | - | - |
| HUNT KEPT | 11 | trace | - | - | - | - |
| HUNT RESULT | 15 | trace | - | - | - | - |
| HUNT THE GUNS | 15 | trace | - | - | - | - |
| KEEPS ITS PREY | 17 | 16 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 19 | not checked | - | - | - | - |
| LURE BY WHAT IT DRAWS | 2 | 2 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 3 | trace | - | - | - | - |
| MARCH OVER CASTS | 31 | 31 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 17 | 17 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 28 | trace | - | - | - | - |
| MOVE SPELL SPOT | 7 | not checked | - | - | - | - |
| NOT NEEDED | 25 | 24 | 0 | 0.00 | - | - |
| NOT TURNED | 414 | 414 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 41 | not checked | - | - | - | - |
| PLAN RESULT | 2808 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 6 | 6 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 3 | 3 | 0 | 0.00 | - | - |
| SCOUT SPOT | 28 | 28 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 1 | 1 | 0 | 0.00 | - | - |
| SECOND HUNTER | 6 | 6 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 9 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 8 | not checked | - | - | - | - |
| SET-UP MISSED | 2 | trace | - | - | - | - |
| SPELL CATCH ODDS | 1 | not checked | - | - | - | - |
| SPELL SETS UP CHARGE | 14 | not checked | - | - | - | - |
| SPELL WORTH | 88 | not checked | - | - | - | - |
| STABLE ROLE | 427 | 427 | 0 | 0.00 | - | - |
| TURN WORTH | 23 | 22 | 0 | 0.00 | - | - |
| TWO OR MORE ARRIVE | 25 | 20 | 0 | 0.00 | - | - |

### Off best figure: fw-h2h2-mine-1eea44e-p2

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 13.58 | 15.42 | 53.6 |
| FALLBACK | gate | 0.81 | 1.11 | 52.6 |
| TURN GATE | gate | 0.44 | 0.44 | 34.1 |
| RULE SWITCHED OFF | gate | - | 0.75 | 20.4 |
| CHARGE NOW FIRST | rule | 0.42 | - | 39.8 |
| PATHS CROSS | rule | 0.06 | 0.28 | 56.2 |
| CANNON PLANNED TARGET | rule | 0.28 | - | 9.1 |
| SUPPORT REQUEST | gate | 0.11 | 0.14 | 48.5 |
| BEST PRIZE | rule | 0.14 | 0.08 | 101.6 |
| CHAFF PASSED | rule | 0.14 | 0.08 | 3.6 |
| CHARGE NOW WEIGHED | rule | 0.11 | 0.11 | 16.3 |
| LONE CHARACTER SAFE SPOT | gate | 0.08 | 0.14 | 34.6 |
| AFTERMATH BAND | gate | 0.17 | 0.03 | 2.6 |
| FIGHT ORDER BAND | gate | 0.11 | 0.08 | 1.8 |
| PURSUES BIG PREY | rule | 0.11 | 0.06 | 66.5 |
| WAR ENGINE JOBS | rule | 0.17 | - | 21.7 |
| BIG CHARACTER SAFETY | rule | 0.06 | 0.08 | 6.7 |
| SURE CHARGE BEATS ADVANCE | rule | 0.03 | 0.11 | 43.5 |
| CARRIES OUT SET-UP | rule | - | 0.11 | 35.8 |
| PIVOT GUARDS FLANK | rule | 0.08 | 0.03 | 15.0 |
| BLOCKED WHEEL | rule | - | 0.08 | 14.1 |
| SUPPORT NARROWED | rule | 0.08 | - | 7.2 |
| AFTERMATH NEEDS NEXT CHARGE | gate | - | 0.06 | 101.4 |
| CHARIOT NO STATIC JOB | rule | - | 0.06 | 13.1 |
| NO REASON | gate | 0.06 | - | 10.6 |
| SAFER THAN THE JOB | rule | - | 0.06 | 7.5 |
| STOPS SHORT OF THE FLANK | rule | 0.03 | 0.03 | 4.0 |
| DEFENSIVE ARMY | rule | 0.03 | - | 106.9 |
| FACES THE THREAT | rule | 0.03 | - | 10.5 |
| FOLLOW UP WEIGHED | rule | 0.03 | - | 3.2 |
| LONE WIZARD HOLDS BACK | rule | - | 0.03 | 36.7 |
| MARCH ODDS | rule | 0.03 | - | 5.0 |
| PURSUES ON | rule | 0.03 | - | 1.9 |
| REDIRECT WEIGHED | rule | - | 0.03 | 7.7 |
| THROUGH LINE OF FIRE | rule | 0.03 | - | 38.2 |

### Plans: fw-h2h2-mine-1eea44e-p2

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 11.8 | 20% | 457 | 318 | 69% |
| Mine | charge | 3.7 | 63% | 374 | 384 | 103% |
| Mine | close in | 4.0 | 25% | 207 | 133 | 64% |
| Mine | hold | 4.5 | 27% | 255 | 0 | 0% |
| Mine | join | 1.0 | 100% | 37 | 0 | 0% |
| Mine | shoot | 8.5 | 64% | 266 | 694 | 261% |
| Mine | support | 4.4 | 89% | 36 | 0 | 0% |
| Opponent | advance | 14.3 | 15% | 661 | 443 | 67% |
| Opponent | charge | 4.4 | 48% | 518 | 410 | 79% |
| Opponent | close in | 5.7 | 26% | 492 | 163 | 33% |
| Opponent | hold | 4.0 | 38% | 342 | 0 | 0% |
| Opponent | join | 0.6 | 91% | 21 | 0 | 0% |
| Opponent | shoot | 4.6 | 62% | 154 | 341 | 221% |
| Opponent | support | 6.6 | 90% | 304 | 0 | 0% |

### Packages: hunt the guns, fw-h2h2-mine-1eea44e-p2

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.1 | 5 | 0 | 40% | 60% | 0% | 3.0 | 280 | 154 | 60% | 48 |
| Opponent | 0.3 | 10 | 0 | 50% | 50% | 0% | 3.0 | 437 | 212 | 50% | 110 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.5 | 2 | 0 | 50% | 100% | 0% | 3.0 | 388 | 275 | 100% | 122 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 224 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 39 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 72 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 156 |
| High Elf Realms | 0.2 | 1 | 0 | 100% | 100% | 0% | 3.0 | 233 | 221 | 100% | 0 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Ogre Kingdoms | 1.0 | 4 | 0 | 50% | 50% | 0% | 3.0 | 430 | 250 | 50% | 151 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 217 |
| Tomb Kings of Khemri | 0.2 | 1 | 0 | 0% | 100% | 0% | 3.0 | 431 | 420 | 100% | 28 |
| Vampire Counts | 0.4 | 4 | 0 | 50% | 25% | 0% | 3.0 | 284 | 62 | 25% | 8 |
| Warriors of Chaos | 0.3 | 3 | 0 | 33% | 33% | 0% | 3.0 | 490 | 151 | 33% | 120 |
| Wood Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 16 |

### Battle groups: fw-h2h2-mine-1eea44e-p2

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 10.7 | 25% | 49% | 11% | 45% | 24% | 14% | 8% | 54% | 0% |
| Mine | REDIRECT COUNTER | 2.0 | 26% | 47% | 5% | 100% | 17% | 0% | 22% | 61% | 0% |
| Opponent | COUNTER-CHARGE COVER | 7.1 | 19% | 67% | 12% | 50% | 40% | 16% | 12% | 33% | 0% |
| Opponent | REDIRECT COUNTER | 4.5 | 27% | 63% | 19% | 38% | 23% | 0% | 20% | 54% | 3% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: fw-h2h2-mine-1eea44e-p2

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 5 | 0 (5) | 0 | 0 | 0 | 20% | 3.0 | 0 (1) | 0 (4) | - | 0 (1) | 0 (4) |
| Mine | Chaff | 41 | 64 (41) | 31 | 33 | 65 | 32% | 2.9 | 65 (21) | 87 (9) | 45 (11) | 86 (29) | 4 (12) |
| Mine | Character | 124 | 50 (124) | 50 | 0 | 41 | 12% | 2.6 | 67 (35) | 49 (57) | 37 (12) | 63 (54) | 46 (50) |
| Mine | Clean-up | 15 | 54 (15) | 16 | 38 | 36 | 67% | 3.2 | 37 (6) | 33 (7) | 194 (2) | 111 (8) | 11 (7) |
| Mine | Fast | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Mine | Fast Hammer | 44 | 55 (44) | 44 | 11 | 55 | 16% | 3.1 | 51 (24) | 52 (14) | 94 (6) | 76 (27) | 25 (17) |
| Mine | Fragile | 5 | 63 (5) | 63 | 0 | 40 | 0% | 1.8 | - | 105 (3) | 0 (2) | 63 (5) | - |
| Mine | Hammer | 57 | 40 (57) | 33 | 7 | 40 | 18% | 2.5 | 25 (16) | 35 (32) | 88 (9) | 44 (37) | 34 (20) |
| Mine | Holder | 28 | 54 (28) | 19 | 35 | 35 | 43% | 3.1 | 52 (9) | 36 (11) | 95 (7) | 69 (18) | 29 (9) |
| Mine | Shooter | 44 | 71 (44) | 26 | 46 | 45 | 0% | 1.8 | 39 (7) | 92 (30) | 13 (7) | 109 (26) | 19 (18) |
| Mine | Support | 2 | 0 (2) | 0 | 0 | 0 | 50% | 3.0 | - | 0 (2) | - | - | 0 (2) |
| Mine | War machine | 59 | 55 (59) | 55 | 0 | 47 | 2% | 1.2 | 53 (10) | 54 (37) | 61 (12) | 58 (11) | 55 (48) |
| Mine | Wizard | 21 | 22 (21) | 22 | 0 | 33 | 19% | 2.4 | 5 (7) | 53 (6) | 46 (4) | 58 (7) | 0 (10) |
| Opponent | Blocker | 2 | 0 (2) | 0 | 0 | 0 | 100% | - | 0 (1) | 0 (1) | - | 0 (1) | 0 (1) |
| Opponent | Chaff | 77 | 38 (77) | 15 | 23 | 50 | 39% | 2.8 | 46 (30) | 31 (18) | 35 (29) | 54 (53) | 5 (24) |
| Opponent | Character | 94 | 56 (94) | 56 | 0 | 42 | 20% | 2.4 | 66 (42) | 65 (33) | 6 (6) | 62 (54) | 61 (27) |
| Opponent | Clean-up | 21 | 23 (21) | 7 | 15 | 58 | 48% | 2.5 | 31 (14) | 8 (6) | 0 (1) | 27 (15) | 13 (6) |
| Opponent | Early | 2 | 0 (2) | 0 | 0 | 0 | 100% | - | - | 0 (1) | 0 (1) | 0 (2) | - |
| Opponent | Fast Hammer | 46 | 48 (46) | 34 | 14 | 50 | 22% | 2.9 | 55 (25) | 34 (11) | 48 (10) | 38 (29) | 67 (17) |
| Opponent | Fragile | 5 | 0 (5) | 0 | 0 | 61 | 40% | 2.0 | - | 0 (3) | 0 (2) | 0 (3) | 0 (2) |
| Opponent | Hammer | 68 | 41 (68) | 35 | 6 | 42 | 21% | 2.9 | 56 (21) | 33 (36) | 46 (11) | 43 (40) | 37 (28) |
| Opponent | Holder | 35 | 112 (35) | 25 | 87 | 20 | 31% | 3.0 | 36 (6) | 152 (22) | 38 (6) | 149 (17) | 78 (17) |
| Opponent | Shooter | 34 | 63 (34) | 24 | 39 | 18 | 0% | 1.7 | 43 (11) | 74 (16) | 68 (7) | 86 (22) | 30 (12) |
| Opponent | Support | 3 | 0 (3) | 0 | 0 | 0 | 100% | - | 0 (1) | 0 (2) | - | 0 (1) | 0 (2) |
| Opponent | War machine | 24 | 61 (24) | 61 | 0 | 22 | 8% | 1.8 | 77 (6) | 64 (15) | 27 (3) | 0 (2) | 67 (22) |
| Opponent | Wizard | 29 | 6 (29) | 6 | 0 | 50 | 7% | 1.7 | 0 (12) | 23 (5) | 0 (6) | 15 (12) | 0 (11) |

### Charged fights: fw-h2h2-mine-1eea44e-p2

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 116 | 304 | 2.5 | 1.2 | 122 | 0 | +122 | 4 of 10 | 10 of 10 | +100 | +127 |
| Mine | Chaos Dwarfs | 4 | 212 | 342 | 2.0 | 1.2 | 171 | 0 | +171 | 4 of 8 | 8 of 8 | +186 | +166 |
| Mine | Dwarfen Mountain Holds | 4 | 632 | 118 | 1.5 | 1.3 | 78 | 53 | +25 | 2 of 6 | 2 of 6 | +206 | -65 |
| Mine | Empire of Man | 5 | 413 | 165 | 2.0 | 1.1 | 82 | 45 | +37 | 4 of 10 | 5 of 10 | +362 | +1 |
| Mine | Grand Cathay | 4 | 174 | 435 | 4.0 | 1.1 | 109 | 9 | +99 | 8 of 16 | 11 of 16 | +490 | +44 |
| Mine | High Elf Realms | 4 | 190 | 501 | 2.8 | 1.4 | 182 | 14 | +169 | 2 of 11 | 11 of 11 | +365 | +95 |
| Mine | Kingdom of Bretonnia | 1 | 0 | 375 | 3.0 | 1.3 | 125 | 0 | +125 | 0 of 3 | 3 of 3 | +0 | +188 |
| Mine | Lizardmen | 1 | 0 | 507 | 5.0 | 1.2 | 101 | 100 | +2 | 1 of 5 | 2 of 5 | -499 | +127 |
| Mine | Ogre Kingdoms | 1 | 0 | 45 | 5.0 | 1.0 | 9 | 76 | -67 | 0 of 5 | 0 of 5 | - | -67 |
| Mine | Orc & Goblin Tribes | 1 | 50 | 840 | 7.0 | 1.0 | 120 | 0 | +120 | 1 of 7 | 2 of 7 | - | +120 |
| Mine | Skaven | 2 | 58 | 708 | 2.5 | 1.2 | 283 | 161 | +122 | 3 of 5 | 2 of 5 | +205 | +101 |
| Mine | Tomb Kings of Khemri | 1 | 0 | 823 | 6.0 | 1.2 | 137 | 20 | +117 | 1 of 6 | 3 of 6 | +432 | +54 |
| Mine | Vampire Counts | 3 | 155 | 38 | 3.7 | 1.0 | 10 | 44 | -34 | 2 of 11 | 8 of 11 | - | -34 |
| Mine | Warriors of Chaos | 1 | 0 | 825 | 5.0 | 1.2 | 165 | 40 | +125 | 0 of 5 | 4 of 5 | -198 | +206 |
| **Mine** | all armies | 36 | 222 | 349 | 3.0 | 1.2 | 116 | 33 | +83 | 32 of 108 | 71 of 108 | +198 | +62 |
| Opponent | Dwarfen Mountain Holds | 2 | 497 | 75 | 2.5 | 1.2 | 30 | 81 | -51 | 1 of 5 | 2 of 5 | -300 | +11 |
| Opponent | Empire of Man | 2 | 448 | 280 | 2.5 | 1.0 | 112 | 0 | +112 | 2 of 5 | 3 of 5 | - | +112 |
| Opponent | Grand Cathay | 2 | 236 | 458 | 2.0 | 1.8 | 229 | 54 | +175 | 3 of 4 | 2 of 4 | +210 | +163 |
| Opponent | Kingdom of Bretonnia | 1 | 115 | 366 | 4.0 | 1.0 | 92 | 0 | +92 | 1 of 4 | 4 of 4 | - | +92 |
| Opponent | Ogre Kingdoms | 3 | 41 | 458 | 3.7 | 1.1 | 125 | 10 | +115 | 1 of 11 | 5 of 11 | +316 | +95 |
| Opponent | Skaven | 1 | 0 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 0 of 1 | 1 of 1 | - | +0 |
| Opponent | Tomb Kings of Khemri | 4 | 108 | 1112 | 4.5 | 1.2 | 247 | 91 | +156 | 11 of 18 | 11 of 18 | +283 | +131 |
| Opponent | Vampire Counts | 6 | 0 | 493 | 4.5 | 1.1 | 110 | 44 | +65 | 12 of 27 | 16 of 27 | -166 | +94 |
| Opponent | Warriors of Chaos | 8 | 76 | 278 | 3.2 | 1.1 | 86 | 34 | +52 | 13 of 26 | 16 of 26 | +100 | +46 |
| Opponent | Wood Elf Realms | 7 | 50 | 747 | 4.7 | 1.1 | 158 | 25 | +133 | 12 of 33 | 19 of 33 | +140 | +132 |
| **Opponent** | all armies | 36 | 111 | 506 | 3.7 | 1.1 | 136 | 39 | +97 | 56 of 134 | 79 of 134 | +90 | +98 |

### Effective charges: fw-h2h2-mine-1eea44e-p2

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 10 | 1 (net +511) | 0 | 0 | 2 (net +52) | 1 (net +95) | 5 (net +77) | 1 | 0% (0 of 9) |
| Mine | Chaos Dwarfs | 8 | 1 (net +268) | 0 | 0 | 4 (net +192) | 2 (net +52) | 1 (net +227) | 0 | 0% (0 of 8) |
| Mine | Dwarfen Mountain Holds | 6 | 1 (net +0) | 0 | 2 (net +123) | 2 (net +0) | 0 | 1 (net -95) | 0 | 33% (2 of 6) |
| Mine | Empire of Man | 10 | 0 | 0 | 1 (net -265) | 2 (net -22) | 1 (net +112) | 5 (net +113) | 1 | 11% (1 of 9) |
| Mine | Grand Cathay | 16 | 4 (net +0) | 1 (net +102) | 2 (net +114) | 2 (net +142) | 3 (net +34) | 3 (net +292) | 1 | 13% (2 of 15) |
| Mine | High Elf Realms | 11 | 0 | 0 | 1 (net +0) | 3 (net +145) | 2 (net +203) | 5 (net +202) | 0 | 9% (1 of 11) |
| Mine | Kingdom of Bretonnia | 3 | 0 | 0 | 1 (net +205) | 1 (net +170) | 1 (net +0) | 0 | 0 | 33% (1 of 3) |
| Mine | Lizardmen | 5 | 1 (net +60) | 0 | 2 (net -64) | 0 | 1 (net +0) | 0 | 1 | 50% (2 of 4) |
| Mine | Ogre Kingdoms | 5 | 1 (net -34) | 0 | 0 | 0 | 0 | 1 (net +45) | 3 | 0% (0 of 2) |
| Mine | Orc & Goblin Tribes | 7 | 2 (net +95) | 0 | 0 | 0 | 1 (net +45) | 1 (net +0) | 3 | 0% (0 of 4) |
| Mine | Skaven | 5 | 1 (net +196) | 2 (net +104) | 0 | 0 | 0 | 2 (net +102) | 0 | 0% (0 of 5) |
| Mine | Tomb Kings of Khemri | 6 | 0 | 0 | 0 | 0 | 4 (net +174) | 0 | 2 | 0% (0 of 4) |
| Mine | Vampire Counts | 11 | 1 (net -45) | 0 | 2 (net -25) | 3 (net +0) | 2 (net -140) | 3 (net +0) | 0 | 18% (2 of 11) |
| Mine | Warriors of Chaos | 5 | 0 | 0 | 0 | 1 (net +19) | 1 (net -198) | 2 (net +232) | 1 | 0% (0 of 4) |
| Opponent | Dwarfen Mountain Holds | 5 | 2 (net -118) | 0 | 1 (net -105) | 1 (net +30) | 0 | 1 (net +55) | 0 | 20% (1 of 5) |
| Opponent | Empire of Man | 5 | 2 (net +155) | 0 | 2 (net +125) | 0 | 0 | 1 (net +0) | 0 | 40% (2 of 5) |
| Opponent | Grand Cathay | 4 | 1 (net +0) | 0 | 1 (net +210) | 2 (net +244) | 0 | 0 | 0 | 25% (1 of 4) |
| Opponent | Kingdom of Bretonnia | 4 | 1 (net +0) | 0 | 0 | 1 (net +0) | 0 | 0 | 2 | 0% (0 of 2) |
| Opponent | Ogre Kingdoms | 11 | 2 (net +323) | 0 | 1 (net -34) | 1 (net +125) | 0 | 2 (net +68) | 5 | 17% (1 of 6) |
| Opponent | Skaven | 1 | 0 | 0 | 1 (net +0) | 0 | 0 | 0 | 0 | 100% (1 of 1) |
| Opponent | Tomb Kings of Khemri | 18 | 4 (net +176) | 0 | 1 (net +0) | 3 (net +245) | 1 (net +0) | 7 (net +99) | 2 | 6% (1 of 16) |
| Opponent | Vampire Counts | 27 | 5 (net +46) | 1 (net +251) | 8 (net +109) | 5 (net +106) | 0 | 6 (net -81) | 2 | 32% (8 of 25) |
| Opponent | Warriors of Chaos | 26 | 1 (net +0) | 1 (net -116) | 4 (net +9) | 3 (net -48) | 0 | 11 (net +88) | 6 | 20% (4 of 20) |
| Opponent | Wood Elf Realms | 33 | 5 (net +52) | 0 | 4 (net +214) | 8 (net +206) | 3 (net +138) | 11 (net +104) | 2 | 13% (4 of 31) |

### Charged fights, damage counted: fw-h2h2-mine-1eea44e-p2

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 13 | 212 | 271 | +88 | 111 | 52 | +59 | +27.6 |
| Mine | 50-54% | 3 | 207 | 320 | +104 | 354 | 250 | +104 | +50.0 |
| Mine | Effective (55-75%) | 11 | 266 | 244 | +22 | 127 | 101 | +27 | +10.1 |
| Mine | 76-89% | 20 | 217 | 153 | +87 | 108 | 21 | +88 | +40.4 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 29 | 274 | 165 | +127 | 143 | 27 | +116 | +42.4 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 19 | 457 | 116 | +57 | 104 | 50 | +55 | +12.0 |
| Mine | No odds | 13 | 212 | 162 | +61 | 115 | 54 | +60 | +28.4 |
| Mine | All fights | 108 | 278 | 179 | +83 | 127 | 50 | +77 | +27.7 |
| Opponent | Long shot (under 50%) | 23 | 225 | 265 | +83 | 201 | 127 | +74 | +32.9 |
| Opponent | 50-54% | 2 | 151 | 186 | +68 | 140 | 58 | +82 | +54.3 |
| Opponent | Effective (55-75%) | 23 | 265 | 220 | +91 | 141 | 54 | +87 | +32.7 |
| Opponent | 76-89% | 24 | 280 | 156 | +142 | 158 | 24 | +134 | +47.8 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 39 | 298 | 205 | +64 | 133 | 64 | +70 | +23.4 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 4 | 658 | 112 | +104 | 117 | 0 | +117 | +17.7 |
| Opponent | No odds | 19 | 218 | 145 | +131 | 153 | 14 | +139 | +63.8 |
| Opponent | All fights | 134 | 274 | 197 | +97 | 153 | 57 | +96 | +35.2 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| fw-h2h2-mine-1eea44e-p2 | move | 455 | 119 (26%) | 86 (19%) | 50 (11%) | 286 (63%) |
| fw-h2h2-mine-1eea44e-p2 | objective | 351 | 59 (17%) | 43 (12%) | 46 (13%) | 246 (70%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0106, L0122, L2429, L2535, L2735 |
| Charmed Shield | Opponent | L0425, L0827, L0934, L1026, L1727, L1827, L1927 |
| Clockwork Compass | Mine | L1228 |
| Clockwork Compass | Opponent | L0512 |
| Elixir of Power | Mine | L1118, L1135, L1927 |
| Fistful of Laurels | Mine | L1827 |
| Fistful of Laurels | Opponent | L0918, L1118, L1418 |
| Horn of the Wild Hunt | Opponent | L3033 |
| Invocation of Nehek | Mine | L2429, L2535, L2735 |
| Invocation of Nehek | Opponent | L0425, L0827, L1727, L1827, L1927 |
| Opal Amulet | Mine | L1418, L1435 |
| Periapt of Soul Exchange | Mine | L2029, L2131 |
| Periapt of Soul Exchange | Opponent | L0721 |
| Ring of Doom | Mine | L0206, L0222, L1118, L1135, L1228, L1531 |
| Ring of Doom | Opponent | L0512, L1531, L2131, L3033 |
| Ring of Jet | Mine | L1026, L1118, L1135, L1228 |
| Ring of Jet | Opponent | L0512, L0810 |
| Standard of the Fell Warrior | Mine | L1323 |
| Storm Daemon (Renegade 2.0) | Mine | L2131 |
| Storm Daemon (Renegade 2.0) | Opponent | L0721 |
| Twice-Blessed Armour | Mine | L0721, L1026 |
| Twice-Blessed Armour | Opponent | L0307, L0810 |
| Witch Hunter's Ward | Mine | L0721, L0810, L0827 |
| Witch Hunter's Ward | Opponent | L0307 |

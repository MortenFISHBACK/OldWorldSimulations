# Doctrine scorecard: fw-h2h2-mine-1eea44e-p1

### Scorecard: fw-h2h2-mine-1eea44e-p1

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0102 | 6 | 1 | Mine | no | 4 | 6 | 1 | 1 | 0 | 0 | 0 | 0 |
| L0102 | 6 | 1 | Opponent | no | 4 | 1 | 3 | 3 | 0 | 0 | 0 | 0 |
| L0118 | 4 | 1 | Mine | no | 0 | 6 | 1 | 1 | 1 | 0 | 0 | 322 |
| L0118 | 4 | 1 | Opponent | no | 0 | 5 | 4 | 2 | 0 | 0 | 0 | 0 |
| L0135 | 3 | 1 | Mine | no | 7 | - | 1 | 2 | 0 | 0 | 0 | 0 |
| L0135 | 3 | 1 | Opponent | no | 4 | 2 | 3 | 3 | 0 | 0 | 0 | 0 |
| L0218 | 2 | 1 | Mine | - | - | 2 | 0 | 3 | 0 | 0 | 0 | 0 |
| L0218 | 2 | 1 | Opponent | - | - | 2 | 1 | 1 | 0 | 0 | 0 | 0 |
| L0235 | 1 | 1 | Mine | no | 4 | 2 | 3 | 3 | 0 | 0 | 0 | 0 |
| L0235 | 1 | 1 | Opponent | no | 0 | 3 | 3 | 1 | 0 | 0 | 0 | 0 |
| L0319 | 1 | 1 | Mine | no | 5 | 2 | 1 | 0 | 0 | 0 | 0 | 900 |
| L0319 | 1 | 1 | Opponent | no | 2 | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L0405 | 3 | 1 | Mine | yes | 3 | 2 | 3 | 2 | 0 | 0 | 0 | 0 |
| L0405 | 3 | 1 | Opponent | no | 1 | - | 0 | 1 | 0 | 0 | 0 | 1258 |
| L0421 | 1 | 1 | Mine | no | 5 | 2 | 8 | 2 | 0 | 0 | 0 | 0 |
| L0421 | 1 | 1 | Opponent | no | 1 | - | 0 | 2 | 1 | 0 | 0 | 355 |
| L0508 | 4 | 1 | Mine | no | 0 | 6 | 1 | 1 | 0 | 0 | 0 | 548 |
| L0508 | 4 | 1 | Opponent | no | 2 | 3 | 1 | 4 | 0 | 0 | 0 | 515 |
| L0524 | 2 | 1 | Mine | - | - | 2 | 2 | 0 | 0 | 0 | 0 | 475 |
| L0524 | 2 | 1 | Opponent | - | - | 4 | 3 | 1 | 1 | 0 | 0 | 0 |
| L0612 | 6 | 1 | Mine | no | 0 | - | 1 | 2 | 0 | 0 | 0 | 883 |
| L0612 | 6 | 1 | Opponent | no | 3 | 3 | 2 | 1 | 1 | 0 | 0 | 330 |
| L0628 | 4 | 1 | Mine | no | 0 | 4 | 3 | 2 | 0 | 0 | 0 | 801 |
| L0628 | 4 | 1 | Opponent | no | 0 | - | 1 | 1 | 0 | 0 | 0 | 0 |
| L0717 | 3 | 1 | Mine | yes | 1 | 2 | 6 | 0 | 0 | 0 | 0 | 375 |
| L0717 | 3 | 1 | Opponent | yes | 4 | 2 | 3 | 1 | 3 | 0 | 0 | 322 |
| L0733 | 1 | 1 | Mine | no | 7 | 2 | 4 | 0 | 1 | 0 | 0 | 250 |
| L0733 | 1 | 1 | Opponent | no | 5 | 1 | 5 | 1 | 0 | 0 | 0 | 236 |
| L0823 | 1 | 1 | Mine | no | 2 | - | 0 | 1 | 0 | 0 | 0 | 679 |
| L0823 | 1 | 1 | Opponent | no | 0 | 2 | 3 | 4 | 1 | 0 | 0 | 0 |
| L0913 | 1 | 1 | Mine | no | 1 | 3 | 1 | 0 | 0 | 0 | 0 | 537 |
| L0913 | 1 | 1 | Opponent | no | 7 | 3 | 1 | 0 | 0 | 0 | 0 | 140 |
| L0930 | 6 | 1 | Mine | no | 0 | 4 | 3 | 1 | 0 | 0 | 0 | 584 |
| L0930 | 6 | 1 | Opponent | no | 9 | 2 | 4 | 2 | 2 | 0 | 0 | 0 |
| L1021 | 1 | 1 | Mine | no | 0 | 2 | 3 | 0 | 0 | 0 | 0 | 330 |
| L1021 | 1 | 1 | Opponent | no | 0 | - | 1 | 5 | 1 | 0 | 0 | 145 |
| L1114 | 4 | 1 | Mine | no | 5 | 2 | 3 | 1 | 0 | 0 | 0 | 330 |
| L1114 | 4 | 1 | Opponent | no | 1 | 2 | 3 | 1 | 1 | 0 | 0 | 328 |
| L1131 | 3 | 1 | Mine | no | 0 | - | 2 | 0 | 0 | 0 | 0 | 330 |
| L1131 | 3 | 1 | Opponent | no | 0 | 4 | 2 | 3 | 2 | 0 | 0 | 365 |
| L1224 | 6 | 1 | Mine | no | 9 | 2 | 3 | 0 | 0 | 0 | 0 | 330 |
| L1224 | 6 | 1 | Opponent | no | 9 | 2 | 2 | 2 | 0 | 0 | 0 | 0 |
| L1319 | 5 | 1 | Mine | yes | - | 3 | 4 | 3 | 0 | 0 | 0 | 479 |
| L1319 | 5 | 1 | Opponent | yes | - | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L1335 | 3 | 1 | Mine | no | 9 | 3 | 3 | 0 | 0 | 0 | 0 | 140 |
| L1335 | 3 | 1 | Opponent | no | 0 | 2 | 6 | 5 | 0 | 0 | 0 | 250 |
| L1431 | 3 | 1 | Mine | yes | 6 | 2 | 5 | 0 | 0 | 0 | 0 | 0 |
| L1431 | 3 | 1 | Opponent | no | 0 | - | 1 | 1 | 1 | 0 | 0 | 170 |
| L1527 | 3 | 1 | Mine | no | 4 | 2 | 2 | 0 | 0 | 0 | 0 | 0 |
| L1527 | 3 | 1 | Opponent | no | 2 | 2 | 4 | 2 | 0 | 0 | 0 | 0 |
| L1625 | 5 | 1 | Mine | yes | - | 2 | 6 | 2 | 0 | 0 | 0 | 200 |
| L1625 | 5 | 1 | Opponent | yes | - | - | 2 | 2 | 0 | 0 | 0 | 0 |
| L1723 | 1 | 1 | Mine | no | 0 | 4 | 4 | 1 | 0 | 0 | 0 | 181 |
| L1723 | 1 | 1 | Opponent | no | 0 | 2 | 6 | 1 | 2 | 0 | 0 | 0 |
| L1823 | 5 | 1 | Mine | yes | - | - | 1 | 1 | 1 | 0 | 0 | 0 |
| L1823 | 5 | 1 | Opponent | yes | - | 2 | 6 | 0 | 0 | 0 | 0 | 0 |
| L1923 | 3 | 1 | Mine | yes | 1 | 2 | 7 | 0 | 0 | 0 | 0 | 104 |
| L1923 | 3 | 1 | Opponent | no | 3 | 1 | 2 | 0 | 0 | 0 | 0 | 245 |
| L2025 | 3 | 1 | Mine | yes | 2 | - | 0 | 0 | 0 | 0 | 0 | 210 |
| L2025 | 3 | 1 | Opponent | no | 0 | 2 | 5 | 2 | 0 | 0 | 0 | 0 |
| L2127 | 3 | 1 | Mine | no | 2 | - | 0 | 5 | 0 | 0 | 0 | 722 |
| L2127 | 3 | 1 | Opponent | no | 5 | 2 | 2 | 2 | 1 | 0 | 0 | 0 |
| L2231 | 5 | 1 | Mine | yes | - | 2 | 2 | 0 | 1 | 0 | 0 | 0 |
| L2231 | 5 | 1 | Opponent | yes | - | 3 | 3 | 3 | 2 | 0 | 0 | 958 |
| L2335 | 1 | 1 | Mine | no | 0 | 1 | 6 | 1 | 1 | 0 | 0 | 0 |
| L2335 | 1 | 1 | Opponent | no | 1 | 4 | 1 | 1 | 1 | 0 | 0 | 412 |
| L2531 | 5 | 1 | Mine | yes | - | 3 | 5 | 0 | 1 | 0 | 0 | 0 |
| L2531 | 5 | 1 | Opponent | yes | - | 4 | 2 | 0 | 0 | 0 | 0 | 0 |
| L2730 | 6 | 1 | Mine | no | 0 | 1 | 7 | 4 | 0 | 0 | 0 | 0 |
| L2730 | 6 | 1 | Opponent | no | 1 | 2 | 2 | 0 | 0 | 0 | 0 | 0 |
| L2934 | 6 | 1 | Mine | no | 1 | 2 | 2 | 0 | 0 | 0 | 0 | 0 |
| L2934 | 6 | 1 | Opponent | no | 0 | 4 | 1 | 1 | 0 | 0 | 0 | 107 |
| **Average** | | | Mine | 29% | 2.7 | 2.7 | 2.9 | 1.1 | 0.2 | 0.0 | 0.0 | 269.7 |
| **Average** | | | Opponent | 18% | 2.2 | 2.5 | 2.6 | 1.7 | 0.6 | 0.0 | 0.0 | 170.4 |

### KPIs: fw-h2h2-mine-1eea44e-p1

Rules off - Opponent only: WAR ENGINE JOBS, STAY WEIGHED, BEST FIRST, RANDOM MOVE BY FIGURES, RANDOM MOVER NO PROMISE, STABLE ROLE, WOUNDED STAYS OUT, BEST FACING, LOST CHARGE, SCREEN BY WHAT IT SAVES, REDIRECT BY WHAT IT STOPS, SHOOTER COUNTED ONCE, LURE BY WHAT IT DRAWS, HILL BY ITS CHANCE, MOVE TO CHARGE, LONG SHOT, DEFENSIVE ARMY, SHOOTS FROM THE BEST SPOT, SUPPORTS, RESERVE FALL BACK, WAIT AFTER COSTS, CHARGE NOW FIRST, SUPPORT NARROWED, WAR ENGINE CHARGES, DEFENSIVE FLOOR.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 33% (58 of 177) | 0% (0 of 184) | 16% (58 of 361) |
| Winner chose to follow up after the loser gave ground |  | 98% (45 of 46); on the table 100% | 99% (77 of 78); on the table 100% | 98% (122 of 124); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | 100% (12 of 12); on the table 100% | 100% (11 of 11); on the table 100% | 100% (23 of 23); on the table 100% |
| Winner chose to pursue after the loser fled |  | 64% (16 of 25); on the table 72% | 78% (35 of 45); on the table 82% | 73% (51 of 70); on the table 79% |
| Winner chose to follow up or pursue (all three) |  | 88% (73 of 83); on the table 92% | 92% (123 of 134); on the table 94% | 90% (196 of 217); on the table 93% |
| Magic missiles tried each own turn | 50%+ | 32% (107 of 330) | 26% (54 of 210) | 30% (161 of 540) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 46% (107 of 234) | 39% (54 of 139) | 43% (161 of 373) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 59% (22 of 37) | - | 59% (22 of 37) |
| Points that never fought | lower | 38% (27235 of 71484) | 35% (25427 of 71889) | 37% (52662 of 143373) |
|   infantry points that never fought | lower | 49% (8307 of 16863) | 49% (6602 of 13348) | 49% (14909 of 30211) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 47% (132 of 279) | 64% (188 of 295) | 56% (320 of 574) |
| Bound items with a magic missile used (at least once a game) |  | 95% (21 of 22); 2.3 uses a game | 75% (15 of 20); 1.5 uses a game | 86% (36 of 42); 1.9 uses a game |
| Bound items with another spell used |  | 56% (9 of 16); 0.6 uses a game | 38% (3 of 8); 0.1 uses a game | 50% (12 of 24); 0.4 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 53% (10 of 19); 0.3 uses a game | 67% (8 of 12); 0.2 uses a game | 58% (18 of 31); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 41% (24681 of 59666) | 60% (37518 of 62699) | 51% (62199 of 122365) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.8 (30%) | 1.5 (35%) | 3.3 (32%) |
| MARCHED: its unit marched | 1.2 (20%) | 0.5 (11%) | 1.7 (16%) |
| CHARGED: its unit charged | 0.2 (4%) | 0.1 (1%) | 0.3 (3%) |
| IN COMBAT: engaged in combat | 1.5 (25%) | 0.7 (17%) | 2.2 (21%) |
| REAR RANK: in a rear rank | 0.1 (2%) | 0.2 (4%) | 0.3 (3%) |
| FLEEING: fleeing | 0.0 (0%) | 0.1 (3%) | 0.1 (1%) |
| GONE: slain | 1.1 (18%) | 1.0 (23%) | 2.1 (20%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (0%) | 0.1 (3%) | 0.1 (1%) |
| STUPIDITY: Stupidity | 0.1 (2%) | 0.0 (0%) | 0.1 (1%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.1 (3%) | 0.1 (1%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.1 | 1.6 | 1.5 | 4.5 | 0.4 | 1.6 |
| not cast | 3.9 | 2.7 | 3.1 | 10.5 | 1.9 | 22.4 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) | 0.0 (0%) | 1.9 (8%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.1 (41%) | 0.2 (7%) | 3.3 (32%) | 0.4 (20%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.7 (16%) | 0.3 (14%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (3%) | 0.1 (4%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.1 (3%) | 0.2 (6%) | 0.4 (12%) | 2.2 (21%) | 0.3 (17%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.3 (9%) | 0.3 (12%) | 0.4 (14%) | 0.3 (3%) | 0.0 (0%) | 0.0 (0%) |
| NO CASTS LEFT: every cast used on other spells | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (1%) | 0.0 (0%) | 0.0 (1%) | 0.1 (1%) | 0.0 (0%) | 0.3 (1%) |
| GONE: slain | 1.3 (33%) | 0.4 (15%) | 0.5 (15%) | 2.1 (20%) | 0.4 (23%) | 3.9 (17%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (1%) | 0.1 (5%) | 0.1 (3%) | 0.1 (1%) | 0.0 (0%) | 0.4 (2%) |
| STUPIDITY: Stupidity | 0.1 (2%) | 0.1 (3%) | 0.0 (0%) | 0.1 (1%) | 0.0 (1%) | 0.1 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (1%) | 0.1 (4%) | 0.0 (0%) | 0.0 (0%) | 0.4 (19%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.0 (50%) | 0.4 (13%) | 1.5 (47%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 15.8 (71%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.3 a game | 0.5 a game | 0.9 a game |
| stood (cast and not dispelled) | 64% (27 of 42) | 69% (11 of 16) | 66% (38 of 58) |
| the unit moved after it | 74% (20 of 27) | 45% (5 of 11) | 66% (25 of 38) |
| it charged on its next turn | 0% (0 of 27) | 9% (1 of 11) | 3% (1 of 38) |
| the enemy charged it first | 19% (5 of 27) | 9% (1 of 11) | 16% (6 of 38) |
| it fought by the end of its next turn | 4% (1 of 27) | 0% (0 of 11) | 3% (1 of 38) |
| it moved out of a charge the enemy had planned (not charged first) | 15% (4 of 27) | 9% (1 of 11) | 13% (5 of 38) |
| none of these (no charge, no fight, no charge escaped) | 67% (18 of 27) | 73% (8 of 11) | 68% (26 of 38) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 63% (607 of 964) | 58% (336 of 575) | 61% (943 of 1539) |
|   cavalry | 59% (58 of 99) | 65% (77 of 119) | 62% (135 of 218) |
|   character | 45% (52 of 116) | 26% (31 of 117) | 36% (83 of 233) |
|   chariot | 62% (53 of 86) | 81% (25 of 31) | 67% (78 of 117) |
|   infantry | 54% (174 of 320) | 59% (136 of 231) | 56% (310 of 551) |
|   monster | 58% (23 of 40) | 62% (13 of 21) | 59% (36 of 61) |
|   war machine | 82% (247 of 303) | 96% (54 of 56) | 84% (301 of 359) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.7 (27%) | 2.0 (31%) | 4.8 (29%) |
| CHARGED: it charged | 1.2 (12%) | 1.1 (17%) | 2.3 (14%) |
| FLEEING: it fled or was fleeing | 0.3 (3%) | 0.1 (1%) | 0.4 (3%) |
| IN COMBAT: it fought this turn or the last | 0.7 (7%) | 0.7 (10%) | 1.3 (8%) |
| MOVED: a war machine that moved | 0.1 (1%) | 0.0 (0%) | 0.1 (0%) |
| FREE: none of these - no target in range or sight, or held its fire | 0.3 (3%) | 0.0 (0%) | 0.3 (2%) |
| NO TARGET IN RANGE | 1.5 (15%) | 1.1 (17%) | 2.7 (16%) |
| ONLY IN COMBAT: the only targets were in combat | 0.6 (6%) | 0.4 (5%) | 0.9 (6%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.9 (19%) | 1.1 (16%) | 2.9 (18%) |
| SHELTERED: the target was sheltered | 0.4 (4%) | 0.1 (1%) | 0.4 (3%) |
| STUPIDITY | 0.0 (0%) | 0.1 (1%) | 0.1 (0%) |
| OTHER BAR | 0.3 (3%) | 0.1 (1%) | 0.4 (2%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 5.7 | 1.1 | 83% | 4.7 pts | 27 pts |
| character | 2.6 | 0.8 | 82% | 7.8 pts | 20 pts |
| chariot | 2.2 | 1.0 | 70% | 11.3 pts | 25 pts |
| infantry | 12.4 | 4.4 | 74% | 9.1 pts | 112 pts |
| monster | 1.1 | 0.3 | 76% | 8.5 pts | 10 pts |
| war machine | 8.4 | 7.3 | 64% | 28.2 pts | 235 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 5.0 | 5.2 | 5.1 |
| Charges that made contact a game | 3.6 | 3.4 | 3.5 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.09 declared, 0.91 contact (22 units) | 0.43 declared, 0.29 contact (14 units) | 0.83 declared, 0.67 contact (36 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.80 declared, 0.60 contact (5 units) | 1.38 declared, 1.00 contact (8 units) | 1.15 declared, 0.85 contact (13 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.60 declared, 0.42 contact (252 units) | 0.61 declared, 0.39 contact (280 units) | 0.60 declared, 0.41 contact (532 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 46% (32 of 70) | 57% (12 of 21) | 50% (4 of 8) | 48% (48 of 99) |
| Character in a unit | 68% (25 of 37) | 67% (16 of 24) | 25% (1 of 4) | 65% (42 of 65) |
| Character on its own | 78% (39 of 50) | 47% (17 of 36) | 31% (19 of 62) | 51% (75 of 148) |
| Chariot | 75% (12 of 16) | 60% (6 of 10) | - | 69% (18 of 26) |
| Infantry | 51% (45 of 89) | 39% (14 of 36) | 50% (1 of 2) | 47% (60 of 127) |
| Monster | 62% (20 of 32) | 80% (8 of 10) | - | 67% (28 of 42) |
| Monstrous | 82% (9 of 11) | 64% (9 of 14) | - | 72% (18 of 25) |
| War Machines | 73% (30 of 41) | 100% (1 of 1) | - | 74% (31 of 42) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 6 | 83% (10 of 12); on the table 92% | 43% (60 of 138) | 27% | 39% (13 of 33) | 100% (9 of 9); 6.5 uses a game | 100% (3 of 3); 1.7 uses a game | 89% (8 of 9); 1.3 uses a game |
| Chaos Dwarfs | 3 | 86% (6 of 7); on the table 86% | 12% (3 of 24) | 38% | 33% (8 of 24) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 0.3 uses a game |
| Dwarfen Mountain Holds | 5 | 100% (5 of 5); on the table 100% | - | 60% | 61% (25 of 41) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 6 | 75% (6 of 8); on the table 88% | 47% (17 of 36) | 61% | 55% (35 of 64) | 0.0 uses a game | 100% (2 of 2); 1.5 uses a game | 25% (1 of 4); 0.2 uses a game |
| Grand Cathay | 5 | 100% (5 of 5); on the table 100% | 25% (27 of 108) | 56% | 52% (23 of 44) | 92% (11 of 12); 9.2 uses a game | 0% (0 of 1); 0.0 uses a game | 40% (2 of 5); 0.4 uses a game |
| High Elf Realms | 6 | 86% (12 of 14); on the table 86% | 17% (5 of 30) | 34% | 41% (20 of 49) | 100% (5 of 5); 3.0 uses a game | 39% (7 of 18); 1.3 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | 100% (2 of 2); on the table 100% | - | 54% | 50% (3 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Lizardmen | 2 | 100% (5 of 5); on the table 100% | - | 25% | 64% (9 of 14) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 3 | 89% (8 of 9); on the table 89% | 0% (0 of 12) | 40% | 71% (15 of 21) | 67% (2 of 3); 2.7 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 3 | 100% (11 of 11); on the table 100% | 14% (5 of 36) | 11% | 62% (15 of 24) | 0.0 uses a game | 0.0 uses a game | 67% (2 of 3); 0.7 uses a game |
| Skaven | 4 | 96% (22 of 23); on the table 100% | 20% (6 of 30) | 23% | 68% (23 of 34) | 100% (3 of 3); 2.8 uses a game | 0.0 uses a game | 50% (2 of 4); 0.5 uses a game |
| Tomb Kings of Khemri | 6 | 74% (23 of 31); on the table 77% | 0% (0 of 12) | 27% | 40% (12 of 30) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 8 | 93% (40 of 43); on the table 98% | 46% (25 of 54) | 31% | 62% (31 of 50) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 8 | 96% (25 of 26); on the table 96% | 13% (4 of 30) | 29% | 59% (44 of 74) | 100% (4 of 4); 1.1 uses a game | 0.0 uses a game | 50% (1 of 2); 0.1 uses a game |
| Wood Elf Realms | 6 | 100% (16 of 16); on the table 100% | 30% (9 of 30) | 39% | 67% (44 of 66) | 33% (2 of 6); 1.0 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (fw-h2h2-mine-1eea44e-p1, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 50% (35) | 49% (39) | 49% (74) |
| ...free all their last turn and able to turn (per game) | 0.53 | 0.53 | 1.06 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.17 | 0.22 | 0.39 |
| ...with the charger already in that arc before they moved (per game) | 0.22 | 0.39 | 0.61 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 1.56 | 0.69 | 2.25 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.92 | 0.94 | 1.86 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 5.61 | 6.25 | 11.86 |

### Quality by phase: fw-h2h2-mine-1eea44e-p1

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.1 | 3.4 |
| Strategy | Charge objectives carried out (made contact) | 52% (83 of 161) | 41% (66 of 162) |
| Strategy | Shoot objectives carried out (shot that target) | 52% (210 of 401) | 61% (99 of 162) |
| Strategy | Close-in objectives charged next turn | 17% (26 of 151) | 14% (32 of 233) |
| Strategy | Support requests answered (helper made contact too) | 39% (7 of 18) | 52% (12 of 23) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (3 of 3) | 67% (2 of 3) |
| Strategy | Hexes on a unit its side charged or shot that turn | 64% (9 of 14) | 60% (6 of 10) |
| Strategy | Joined characters whose unit fought | 48% (31 of 64) | 64% (23 of 36) |
| Strategy | Lone characters that fought | 83% (68 of 82) | 77% (77 of 100) |
| Movement | Charges halted short of contact | 0.4 | 0.2 |
| Movement | Idle units | 1.1 | 1.7 |
| Movement | Points that never moved of their own | 269.7 | 170.4 |
| Movement | Fights charged into per game | 3.2 | 2.9 |
| Movement | Charges with odds: long shots (under 50%) | 14 of 101, net +128 | 14 of 85, net +32 |
| Movement | Charges with odds: sweet spot (55-75%) | 18 of 101, net -18 | 13 of 85, net +140 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 15 of 101, net +120 | 3 of 85, net +37 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 32 of 101, net +153 | 33 of 85, net +171 |
| Shooting | Shots by shooting units (incl. breath weapons) | 10.8 | 8.9 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 44% (171 of 389) | 43% (138 of 320) |
| Shooting | Points destroyed by shooting units | 120.4 | 24.5 |
| Shooting | War machine shots | 6.9 | 1.5 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 42% (104 of 247) | 41% (22 of 54) |
| Shooting | Points destroyed by war machines | 76.4 | 25.6 |
| Magic | Magic missiles cast | 1.9 | 1.0 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 32% (22 of 68) | 47% (17 of 36) |
| Magic | Wounds caused by magic missiles | 5.1 | 1.9 |
| Magic | Wounds caused by other spells | 1.3 | 0.2 |
| Magic | Points destroyed by magic (all spells) | 114.8 | 21.5 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.4 / 0.5 / 0.9 / 0.2 | 1.6 / 0.3 / 0.2 / 0.1 |
| Combat | Points destroyed in combat | 395.1 | 352.4 |
| Combat | Points run down | 61.9 | 98.1 |
| Combat | Net points per charged fight, damage counted | +104 | +96 |
| Combat | Net per 100 charger points, damage counted | +36.3 | +41.5 |
| Combat | First round won (charged fights) | 56% | 60% |
| Combat | Net points per charged fight | +91 | +83 |
| Combat | Net points per supported fight / lone fight | +240 / +70 | +177 / +71 |
| Combat | Charged fights on a top-3 enemy unit | 41 of 115 | 49 of 105 |
| Game | Points lost | 606.8 | 859.3 |
| Game | VP from objectives | 656.9 | 580.6 |
| Game | Lone holders (player turns) | 2.7 | 2.2 |

- Mine won / drew / lost: 22 / 3 / 11 of 36 ended games (of 36); mean margin (Mine - Opponent) +349 VP
- The side that went first won 17 of 33 games with a winner
- Points traded per game (both sides' losses): 1466
- Games not ended: 0; findings 1, warnings 0

### Opponent rules: fw-h2h2-mine-1eea44e-p1

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.5 | +0.0 | 0.0 | 1.8 | 0.7 | +0.0 | 0.0 | 0.0 |
| ALREADY CARRIED | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARRIVAL HUNT | - | - | - | - | 0.0 | +0.2 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.8 | +0.0 | 0.0 | 8.1 | 0.3 | +0.0 | 0.0 | 3.6 |
| BACKUP TARGETS | 1.1 | +13.0 | 0.0 | 32.8 | 1.2 | +10.8 | 0.0 | 23.2 |
| BEST FACING | 0.8 | +34.3 | 0.0 | 44.9 | - | - | - | - |
| BEST FIRST | 4.2 | +170.9 | 197.3 | 60.2 | - | - | - | - |
| BEST OVERALL | 0.6 | +20.3 | 0.0 | 19.4 | 0.2 | +13.2 | 0.0 | 8.0 |
| BEST PREY | 0.6 | +21.9 | 4.8 | 9.3 | 4.3 | +309.5 | 165.9 | 146.2 |
| BEST PRIZE | 0.1 | -2.6 | 7.9 | 5.4 | - | - | - | - |
| BIG CHARACTER SAFETY | 0.1 | -0.6 | 0.0 | 21.4 | 0.2 | -0.7 | 0.0 | 27.1 |
| BLOCKED CHARGE SKIPPED | 0.1 | +0.0 | 4.0 | 0.0 | 0.0 | +0.0 | 0.0 | 1.8 |
| BLOCKED WHEEL | 0.3 | +3.4 | 0.0 | 0.0 | 0.4 | +3.0 | 0.0 | 4.7 |
| BOMBING RUN | 0.2 | +4.8 | 11.2 | 0.0 | - | - | - | - |
| CANNON PLAN MISSED | 0.8 | +0.0 | 121.6 | 8.9 | 0.1 | +0.0 | 15.4 | 0.0 |
| CANNON PLANNED TARGET | 5.6 | +165.4 | 467.5 | 44.6 | 1.4 | +34.9 | 49.9 | 16.2 |
| CANNON SIGHT KEPT | 1.0 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 7.2 |
| CARRIES OUT COUNTER | 0.1 | +0.0 | 0.0 | 17.4 | - | - | - | - |
| CARRIES OUT SET-UP | 0.1 | +0.0 | 0.0 | 11.7 | 0.1 | -1.3 | 0.0 | 0.0 |
| CAST JOB | 0.6 | +28.4 | 32.9 | 8.5 | 0.4 | +10.0 | 7.8 | 15.6 |
| CASTER AWAY FROM SCREEN | 0.4 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.5 | +59.3 | 28.6 | 19.3 | 0.2 | +7.1 | 1.5 | 4.4 |
| CASTS AFTER FRIENDS | 0.8 | +0.0 | 0.0 | 22.4 | 0.3 | +0.0 | 0.0 | 29.1 |
| CASTS FROM BEHIND | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.1 | +2.4 | 0.0 | 0.0 | 0.0 | +0.1 | 0.0 | 0.0 |
| CHAFF PASSED | 0.2 | -1.2 | 16.2 | 0.0 | 0.1 | -0.1 | 0.0 | 7.0 |
| CHARGE NOW FIRST | 3.1 | +0.0 | 287.4 | 98.8 | - | - | - | - |
| CHARGE NOW WEIGHED | 0.5 | -54.1 | 28.8 | 33.0 | 0.5 | -33.6 | 2.9 | 22.6 |
| CHARIOT NO STATIC JOB | 0.1 | +0.0 | 0.0 | 2.4 | 0.1 | +0.0 | 0.0 | 0.0 |
| CHARIOT WIZARD CAREFUL | 0.1 | -2.3 | 10.9 | 11.1 | 0.1 | -1.4 | 0.0 | 0.0 |
| CHEAP HELPER | 0.1 | +0.0 | 3.2 | 2.9 | 0.1 | +0.0 | 6.2 | 6.6 |
| COMBAT PIVOT | 0.5 | +0.0 | 21.3 | 12.6 | 0.4 | +0.0 | 10.0 | 50.4 |
| CONTINUE AHEAD WEIGHED | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CONVEYANCE SEARCH | 0.8 | +99.9 | 8.4 | 22.5 | 0.4 | +92.6 | 0.0 | 15.2 |
| COUNTER-CHARGE COVER | 10.0 | +974.7 | 0.0 | 205.2 | 7.1 | +588.3 | 0.0 | 157.1 |
| DEFENSIVE ARMY | 0.5 | +0.0 | 39.9 | 12.5 | - | - | - | - |
| DEFENSIVE FLOOR | 0.1 | +5.1 | 0.0 | 7.8 | - | - | - | - |
| EDGE GIVE GROUND | 0.1 | +16.2 | 14.7 | 0.0 | 0.2 | +9.7 | 29.4 | 16.6 |
| ELIXIR WORTH | - | - | - | - | 0.1 | +2.3 | 0.0 | 0.0 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 1.6 | +94.9 | 0.0 | 47.5 | 0.7 | +58.7 | 0.0 | 11.8 |
| FALLBACK BY WORTH | 4.8 | +101.1 | 0.0 | 60.4 | 7.4 | +85.0 | 0.0 | 112.4 |
| FIGHT LIFT | 0.0 | +0.1 | 0.0 | 0.0 | - | - | - | - |
| FIRE AND FLEE | - | - | - | - | 0.1 | +0.3 | 0.0 | 7.0 |
| FLANK NOT WEIGHED | 5.6 | +0.0 | 0.0 | 156.7 | 6.2 | +0.0 | 0.0 | 151.8 |
| FOCUS FIRE | - | - | - | - | 0.0 | +0.5 | 1.5 | 0.0 |
| FOLLOW UP WEIGHED | 0.9 | +128.3 | 0.0 | 26.0 | 1.3 | +193.4 | 0.0 | 9.2 |
| FRIENDS SHOTS CHECKED | 0.2 | +11.0 | 0.0 | 13.8 | 0.1 | +9.3 | 0.0 | 8.0 |
| GIVES UP | 0.1 | -0.8 | 19.8 | 1.4 | 1.4 | -44.9 | 224.9 | 49.0 |
| GIVES UP ITS SCREEN | - | - | - | - | 0.9 | -17.0 | 59.9 | 19.6 |
| GROUND FLIERS | 0.0 | +0.5 | 0.0 | 0.0 | - | - | - | - |
| HELPER ALREADY ASKED | 0.1 | +0.0 | 7.0 | 0.0 | 0.1 | +0.0 | 9.1 | 0.0 |
| HELPER UNSEEN | 0.3 | +0.0 | 11.0 | 14.8 | 0.2 | +0.0 | 16.8 | 6.0 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.8 | +0.0 | 0.0 | 0.0 |
| HUNT ADVANCE | 0.0 | +0.0 | 5.9 | 0.0 | 0.4 | +10.4 | 22.0 | 8.1 |
| HUNT DROPPED | - | - | - | - | 0.1 | +0.0 | 5.9 | 0.0 |
| HUNT IN PAIRS | 0.4 | +33.5 | 0.0 | 5.7 | 0.3 | +15.7 | 0.0 | 0.0 |
| HUNT KEPT | - | - | - | - | 0.2 | +4.7 | 17.6 | 6.4 |
| HUNT RESULT | 0.0 | +6.2 | 0.0 | 0.0 | 0.2 | +10.2 | 5.9 | 4.8 |
| HUNT THE GUNS | 0.0 | +6.2 | 5.9 | 0.0 | 0.2 | +76.5 | 10.2 | 4.8 |
| INVITES THE FIGHT | 1.7 | +41.8 | 79.4 | 26.0 | - | - | - | - |
| JOINT CHARGE PLAN | 0.1 | +1.1 | 0.0 | 0.0 | 0.2 | +18.8 | 0.0 | 3.4 |
| KEEP FALLS | 0.0 | +0.1 | 0.0 | 0.0 | 0.0 | +0.1 | 0.0 | 0.0 |
| KEEPS ITS PREY | 0.0 | +0.1 | 0.0 | 0.0 | 0.3 | +2.6 | 1.5 | 18.0 |
| KEEPS ITS TARGET | 1.8 | +54.2 | 145.4 | 50.5 | 2.3 | +68.3 | 188.0 | 124.9 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KILLS COUNT | 1.8 | +67.8 | 114.8 | 37.6 | 1.8 | +86.0 | 138.8 | 75.5 |
| KILLS COUNT NEXT TURN | 4.9 | +185.3 | 144.7 | 134.2 | 10.1 | +380.1 | 361.1 | 290.3 |
| LONE CHARACTER SAFE SPOT | 0.5 | +15.3 | 15.9 | 37.8 | 0.8 | +20.4 | 29.5 | 10.0 |
| LONE WIZARD HOLDS BACK | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 11.9 |
| LONE WIZARD KEPT IN | 0.7 | +49.1 | 0.0 | 0.0 | 0.2 | +24.5 | 0.0 | 0.0 |
| LONG SHOT | 0.8 | -2.8 | 34.4 | 20.2 | - | - | - | - |
| LOST CHARGE | 3.0 | -46.8 | 134.9 | 119.0 | - | - | - | - |
| LURE BY WHAT IT DRAWS | 0.1 | -4.6 | 0.0 | 0.0 | - | - | - | - |
| MAKE SURE TOGETHER | 0.6 | +36.5 | 7.0 | 34.8 | 0.8 | +77.2 | 10.9 | 8.7 |
| MANOEUVRE | 0.3 | +12.5 | 0.0 | 2.1 | 0.2 | +1.7 | 0.0 | 1.8 |
| MARCH AT ESCAPER | 0.1 | +1.1 | 0.0 | 30.0 | 0.1 | +0.1 | 0.0 | 13.9 |
| MARCH CHECK | 0.5 | +15.4 | 0.0 | 20.9 | 0.6 | +32.0 | 0.0 | 0.0 |
| MARCH ODDS | 0.2 | +20.5 | 12.9 | 10.6 | 0.4 | +21.3 | 4.9 | 28.5 |
| MARCH OVER CASTS | 0.7 | +42.9 | 0.0 | 11.1 | 0.2 | +17.6 | 0.0 | 5.6 |
| MAX FOR POSITIONING | 4.9 | +219.2 | 0.0 | 110.6 | 5.1 | +179.1 | 0.0 | 103.7 |
| MISSILES IN THE MOVE | 4.6 | +218.9 | 0.0 | 136.4 | 3.4 | +60.1 | 0.0 | 91.1 |
| MISSILES NEXT TURN | 5.2 | +132.9 | 0.0 | 180.9 | 4.1 | +41.6 | 0.0 | 124.1 |
| MODEL FACING | 0.3 | +80.0 | 0.0 | 1.7 | - | - | - | - |
| MONSTER WIZARD ROAMS | 0.1 | +0.0 | 0.0 | 10.5 | 0.2 | +0.0 | 0.0 | 12.1 |
| MOVE AND CAST | 0.3 | +26.1 | 0.0 | 2.4 | 0.2 | +8.5 | 0.0 | 15.6 |
| MOVE SPELL IN RANGE | 0.1 | +4.2 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.4 | -77.3 | 0.0 | 0.0 | 0.1 | -0.6 | 0.0 | 0.0 |
| MOVE SPELL SPOT | 0.3 | +0.0 | 0.0 | 11.1 | 0.1 | +0.0 | 0.0 | 13.9 |
| MOVE TO CHARGE | 2.9 | +206.0 | 83.7 | 116.5 | - | - | - | - |
| MOVES UNITS SPELL | 0.1 | +3.4 | 0.0 | 0.0 | 0.1 | +1.8 | 0.0 | 0.0 |
| NEEDED THERE | 0.1 | +7.1 | 6.2 | 0.0 | 0.0 | +10.5 | 1.7 | 16.6 |
| NO RALLY LEFT | 0.1 | +0.8 | 0.0 | 0.0 | 0.0 | +0.9 | 0.0 | 5.1 |
| NOT NEEDED | 0.3 | -16.6 | 29.3 | 1.5 | 0.3 | -15.9 | 37.8 | 23.6 |
| NOT TURNED | 5.6 | +108.9 | 0.0 | 95.9 | 6.2 | +145.1 | 0.0 | 151.6 |
| NOT WORTH A CAST | 1.0 | -1.1 | 0.0 | 62.4 | 0.2 | -0.2 | 0.0 | 0.0 |
| OFF BEST | 16.0 | -831.4 | 0.0 | 221.0 | 18.1 | -1009.1 | 43.6 | 306.1 |
| OPENS A LANE | 0.4 | +2.3 | 67.9 | 0.0 | 0.1 | +0.2 | 19.5 | 0.0 |
| OPENS UP | 0.3 | +22.3 | 17.8 | 10.6 | 0.2 | +26.2 | 10.3 | 7.9 |
| OVERRUN THREAT | - | - | - | - | 0.0 | +1.6 | 0.0 | 0.0 |
| OVERRUNS AWAY | 0.6 | +28.1 | 76.0 | 33.8 | 0.7 | +22.6 | 74.9 | 38.2 |
| PATHS CROSS | 1.8 | +131.9 | 0.0 | 66.7 | 2.9 | +168.3 | 0.0 | 60.2 |
| PERIAPT WORTH | - | - | - | - | 0.1 | +6.1 | 0.0 | 15.0 |
| PIVOT GUARDS FLANK | 0.1 | -1.1 | 0.0 | 0.0 | 0.1 | -0.3 | 0.0 | 5.1 |
| PLAN RESULT | 39.1 | +1587.0 | 1537.7 | 849.5 | 38.2 | +1003.4 | 1086.8 | 1160.6 |
| PURSUES BIG PREY | 0.0 | -0.6 | 0.0 | 0.0 | 0.2 | -11.0 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE | - | - | - | - | 0.0 | +4.9 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE NEXT TURN | - | - | - | - | 0.1 | +6.6 | 0.0 | 0.0 |
| RANDOM MOVE BY FIGURES | 1.0 | +13.9 | 0.0 | 0.0 | - | - | - | - |
| RANDOM MOVER NO PROMISE | 0.1 | -9.1 | 3.0 | 0.0 | - | - | - | - |
| REDIRECT BY WHAT IT STOPS | 0.1 | -1.8 | 0.0 | 1.0 | - | - | - | - |
| REDIRECT COUNTER | 2.1 | +131.9 | 0.0 | 17.2 | 4.7 | +343.8 | 0.0 | 94.5 |
| REDIRECT WEIGHED | 0.2 | +2.5 | 0.0 | 5.7 | 0.3 | +8.1 | 0.0 | 2.4 |
| RESERVE FALL BACK | 0.7 | +10.5 | 0.0 | 3.4 | - | - | - | - |
| RESTRAINS TO SHOOT | 0.1 | +1.2 | 0.0 | 7.4 | 0.1 | +4.5 | 0.0 | 3.2 |
| RISK BY ARC | 3.2 | +125.1 | 293.3 | 108.2 | 3.0 | +63.8 | 309.8 | 120.4 |
| SAFER THAN THE JOB | 0.9 | +60.2 | 0.0 | 10.9 | 0.9 | +40.5 | 0.0 | 44.1 |
| SCOUT SPOT | 0.4 | +0.6 | 0.0 | 0.0 | 0.3 | +0.5 | 0.0 | 0.0 |
| SCOUT WAITS | 0.4 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.1 | -1.7 | 0.0 | 0.9 | - | - | - | - |
| SEARCH SPOT | 2.3 | +115.0 | 0.0 | 50.1 | 1.8 | +128.1 | 0.0 | 31.1 |
| SECOND HUNTER | - | - | - | - | 0.1 | -0.1 | 5.9 | 0.0 |
| SELF MOVE SPELL | 0.2 | +6.3 | 0.0 | 18.1 | 0.2 | +1.9 | 0.0 | 18.1 |
| SET UP TOGETHER | 0.8 | +70.0 | 7.0 | 34.8 | 1.6 | +143.2 | 10.9 | 45.0 |
| SET-UP ANY TARGET | 0.4 | +40.5 | 8.4 | 11.2 | 0.2 | +10.9 | 0.0 | 7.6 |
| SET-UP MISSED | 0.1 | +16.7 | 0.0 | 0.0 | 0.1 | +12.1 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.4 | +0.9 | 0.0 | 0.0 | 0.2 | +0.6 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.2 | +58.8 | 106.2 | 2.4 | - | - | - | - |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 3.2 | 0.0 | +0.0 | 0.0 | 3.8 |
| SHOT REPLANNED | 0.7 | +0.0 | 158.6 | 6.9 | 0.2 | +0.0 | 23.2 | 0.0 |
| SHOTS IN THE MOVE | 15.4 | +593.2 | 0.0 | 163.8 | 8.0 | +174.0 | 0.0 | 157.1 |
| SPELL SETS UP CHARGE | 0.5 | +90.5 | 8.4 | 11.2 | 0.2 | +58.4 | 0.0 | 7.6 |
| SPELL WORTH | 1.1 | +13.0 | 78.2 | 73.3 | 1.7 | +45.3 | 91.8 | 91.8 |
| STABLE ROLE | 11.4 | +0.0 | 442.2 | 139.8 | - | - | - | - |
| STANDS TO CAST | 0.0 | +1.4 | 0.0 | 0.0 | 0.1 | +1.7 | 0.0 | 5.9 |
| STAY WEIGHED | 0.0 | +1.8 | 0.0 | 0.0 | - | - | - | - |
| STOPS | - | - | - | - | 0.1 | +2.7 | 5.9 | 3.2 |
| STOPS SHORT OF THE FLANK | 0.3 | +16.1 | 0.0 | 15.4 | 0.5 | +27.8 | 0.0 | 5.1 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 17.5 |
| SUPPORT NARROWED | 6.3 | -58.6 | 386.7 | 140.8 | - | - | - | - |
| SUPPORTS | 3.9 | +58.6 | 155.9 | 50.6 | - | - | - | - |
| SURE CHARGE BEATS ADVANCE | 0.2 | -11.6 | 15.9 | 17.4 | 0.1 | -3.3 | 0.0 | 0.0 |
| SURE REACH TOGETHER | 0.6 | -3.6 | 0.0 | 23.0 | 0.5 | +1.5 | 0.0 | 20.5 |
| THROUGH LINE OF FIRE | 0.6 | +24.1 | 0.0 | 4.2 | 0.2 | +2.6 | 0.0 | 0.0 |
| TURN WORTH | 0.5 | -41.1 | 45.1 | 18.6 | 0.4 | -14.3 | 28.3 | 4.5 |
| TWO OR MORE ARRIVE | 0.3 | +3.6 | 7.0 | 12.0 | 0.5 | +2.4 | 0.0 | 14.7 |
| WAIT AFTER COSTS | 7.0 | -318.7 | 228.1 | 174.8 | - | - | - | - |
| WALKS TO THE FIGHT | 1.9 | +45.1 | 59.3 | 12.5 | - | - | - | - |
| WAR ENGINE CHARGES | 0.0 | +4.8 | 0.0 | 8.6 | - | - | - | - |
| WAR ENGINE JOBS | 0.7 | +0.0 | 53.8 | 5.7 | - | - | - | - |
| WEARS DOWN | 1.5 | +95.2 | 215.4 | 56.4 | 1.1 | +36.5 | 143.1 | 53.0 |
| WHO HITS BACK | 0.3 | +18.7 | 0.0 | 21.1 | 0.2 | +16.7 | 0.0 | 8.0 |
| WHOLE FIGHT | 0.5 | +53.4 | 71.8 | 11.1 | 0.5 | +34.9 | 93.6 | 1.2 |
| WHOLE FIGHT GAIN | 0.4 | +77.9 | 57.7 | 9.8 | 0.6 | +44.7 | 47.5 | 23.0 |

### Rule changes: fw-h2h2-mine-1eea44e-p1

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 1228 | 1228 | 1228 | 34.11 | -66257 | -54.0 |
| COUNTER-CHARGE COVER | 614 | 333 | 171 | 4.75 | +11059 | +64.7 |
| PATHS CROSS | 170 | 170 | 170 | 4.72 | +10808 | +63.6 |
| KILLS COUNT NEXT TURN | 541 | 536 | 157 | 4.36 | +5301 | +33.8 |
| BEST FIRST | 152 | 152 | 152 | 4.22 | +6152 | +40.5 |
| SEARCH SPOT | 149 | 149 | 147 | 4.08 | +8753 | +59.5 |
| FALLBACK BY WORTH | 439 | 439 | 105 | 2.92 | +6700 | +63.8 |
| FACES THE THREAT | 81 | 81 | 81 | 2.25 | +5530 | +68.3 |
| FOLLOW UP WEIGHED | 80 | 80 | 80 | 2.22 | +11578 | +144.7 |
| ARTILLERY RE-ROLL WEIGHED | 75 | 75 | 75 | 2.08 | +0 | +0.0 |
| BEST PREY | 175 | 175 | 70 | 1.94 | +3077 | +44.0 |
| SAFER THAN THE JOB | 67 | 67 | 67 | 1.86 | +3624 | +54.1 |
| MOVE TO CHARGE | 105 | 105 | 64 | 1.78 | +3164 | +49.4 |
| CANNON PLANNED TARGET | 252 | 252 | 63 | 1.75 | -68 | -1.1 |
| SUPPORTS | 142 | 142 | 62 | 1.72 | +874 | +14.1 |
| CANNON SIGHT KEPT | 52 | 52 | 52 | 1.44 | +0 | +0.0 |
| RISK BY ARC | 223 | 213 | 52 | 1.44 | +1777 | +34.2 |
| SHOTS IN THE MOVE | 843 | 531 | 52 | 1.44 | +1469 | +28.2 |
| MAX FOR POSITIONING | 359 | 191 | 51 | 1.42 | +575 | +11.3 |
| ADVANCE LANE KEPT | 45 | 45 | 45 | 1.25 | +0 | +0.0 |
| HOLDS AMBUSHERS | 44 | 44 | 44 | 1.22 | +0 | +0.0 |
| SET UP TOGETHER | 86 | 73 | 43 | 1.19 | +3283 | +76.3 |
| WALKS TO THE FIGHT | 67 | 67 | 41 | 1.14 | +670 | +16.4 |
| MARCH CHECK | 40 | 40 | 40 | 1.11 | +1799 | +45.0 |
| MISSILES IN THE MOVE | 285 | 157 | 38 | 1.06 | +1235 | +32.5 |
| CHARGE NOW WEIGHED | 37 | 37 | 37 | 1.03 | +1502 | +40.6 |
| KEEPS ITS TARGET | 147 | 144 | 37 | 1.03 | +600 | +16.2 |
| LONE WIZARD KEPT IN | 34 | 34 | 34 | 0.94 | +2648 | +77.9 |
| COMBAT PIVOT | 33 | 33 | 33 | 0.92 | +0 | +0.0 |
| SHOT REPLANNED | 33 | 33 | 33 | 0.92 | +0 | +0.0 |
| WAIT AFTER COSTS | 253 | 253 | 33 | 0.92 | +614 | +18.6 |
| KILLS COUNT | 128 | 123 | 32 | 0.89 | +1477 | +46.2 |
| STOPS SHORT OF THE FLANK | 31 | 31 | 31 | 0.86 | +1579 | +50.9 |
| BEST OVERALL | 29 | 29 | 29 | 0.81 | +1207 | +41.6 |
| REDIRECT COUNTER | 246 | 104 | 29 | 0.81 | +2452 | +84.5 |
| THROUGH LINE OF FIRE | 29 | 29 | 29 | 0.81 | +961 | +33.1 |
| BEST FACING | 27 | 27 | 27 | 0.75 | +1234 | +45.7 |
| SCOUT WAITS | 26 | 26 | 26 | 0.72 | +0 | +0.0 |
| BLOCKED WHEEL | 25 | 25 | 25 | 0.69 | +230 | +9.2 |
| CAST JOB | 35 | 33 | 25 | 0.69 | +728 | +29.1 |
| RESERVE FALL BACK | 24 | 24 | 24 | 0.67 | +377 | +15.7 |
| SHOOTS FROM THE BEST SPOT | 42 | 42 | 24 | 0.67 | +1262 | +52.6 |
| SHOOTERS IN TWO RANKS | 23 | 23 | 23 | 0.64 | +53 | +2.3 |
| CASTER AWAY FROM SCREEN | 22 | 22 | 22 | 0.61 | +0 | +0.0 |
| MAKE SURE TOGETHER | 48 | 35 | 22 | 0.61 | +1572 | +71.5 |
| RANDOM MOVE BY FIGURES | 37 | 37 | 22 | 0.61 | +499 | +22.7 |
| MARCH ODDS | 23 | 21 | 21 | 0.58 | +641 | +30.5 |
| REDIRECT WEIGHED | 21 | 21 | 21 | 0.58 | +405 | +19.3 |
| WHOLE FIGHT GAIN | 36 | 34 | 20 | 0.56 | +811 | +40.5 |
| CHARGE NOW FIRST | 111 | 111 | 19 | 0.53 | -1313 | -69.1 |
| MOVE AND CAST | 18 | 18 | 18 | 0.50 | +1245 | +69.2 |
| WHO HITS BACK | 18 | 18 | 18 | 0.50 | +805 | +44.7 |
| CASTING BLOCK | 26 | 25 | 17 | 0.47 | +1305 | +76.8 |
| STUCK PIVOT | 17 | 17 | 17 | 0.47 | +0 | +0.0 |
| INVITES THE FIGHT | 61 | 61 | 15 | 0.42 | +193 | +12.9 |
| MANOEUVRE | 16 | 16 | 15 | 0.42 | +513 | +34.2 |
| CASTS FROM BEHIND | 14 | 14 | 14 | 0.39 | +0 | +0.0 |
| BIG CHARACTER SAFETY | 13 | 13 | 13 | 0.36 | -47 | -3.6 |
| BACKUP TARGETS | 80 | 40 | 11 | 0.31 | +81 | +7.4 |
| CHAFF PASSED | 11 | 11 | 11 | 0.31 | -46 | -4.2 |
| FRIENDS SHOTS CHECKED | 11 | 11 | 11 | 0.31 | +731 | +66.5 |
| MODEL FACING | 11 | 11 | 11 | 0.31 | +2879 | +261.7 |
| OVERRUNS AWAY | 45 | 44 | 11 | 0.31 | +506 | +46.0 |
| WAR ENGINE JOBS | 26 | 26 | 10 | 0.28 | -534 | -53.4 |
| WEARS DOWN | 96 | 92 | 10 | 0.28 | +292 | +29.2 |
| WHOLE FIGHT | 35 | 33 | 10 | 0.28 | +1039 | +103.9 |
| LOST CHARGE | 109 | 109 | 9 | 0.25 | +98 | +10.9 |
| MISSILES NEXT TURN | 336 | 188 | 9 | 0.25 | +45 | +5.0 |
| OPENS UP | 20 | 19 | 9 | 0.25 | +433 | +48.1 |
| SURE CHARGE BEATS ADVANCE | 9 | 9 | 9 | 0.25 | -539 | -59.9 |
| PIVOT GUARDS FLANK | 8 | 8 | 8 | 0.22 | -51 | -6.4 |
| SHORT GUN FORWARD | 8 | 8 | 8 | 0.22 | +0 | +0.0 |
| HUNT IN PAIRS | 28 | 17 | 7 | 0.19 | +562 | +80.3 |
| MOVES UNITS SPELL | 7 | 7 | 7 | 0.19 | +186 | +26.5 |
| PURSUES BIG PREY | 7 | 7 | 7 | 0.19 | -418 | -59.6 |
| BOMBING RUN | 6 | 6 | 6 | 0.17 | +174 | +29.1 |
| HUNT ADVANCE | 14 | 14 | 6 | 0.17 | +162 | +27.0 |
| BLOCKED CHARGE SKIPPED | 5 | 5 | 5 | 0.14 | +0 | +0.0 |
| SURE REACH TOGETHER | 41 | 28 | 5 | 0.14 | +7 | +1.5 |
| JOINT CHARGE PLAN | 11 | 11 | 4 | 0.11 | +111 | +27.8 |
| RESTRAINS TO SHOOT | 4 | 4 | 4 | 0.11 | +205 | +51.2 |
| NEEDED THERE | 4 | 4 | 3 | 0.08 | +0 | +0.0 |
| NO RALLY LEFT | 3 | 3 | 3 | 0.08 | +28 | +9.3 |
| RAIDS THE BAGGAGE NEXT TURN | 3 | 3 | 3 | 0.08 | +110 | +36.8 |
| BEST PRIZE | 2 | 2 | 2 | 0.06 | -94 | -47.0 |
| CHARIOT NO STATIC JOB | 6 | 6 | 2 | 0.06 | -46 | -23.2 |
| DEFENSIVE ARMY | 18 | 18 | 2 | 0.06 | -11 | -5.7 |
| DEFENSIVE FLOOR | 2 | 2 | 2 | 0.06 | +142 | +70.8 |
| EDGE GIVE GROUND | 9 | 9 | 2 | 0.06 | +123 | +61.7 |
| ELIXIR WORTH | 2 | 2 | 2 | 0.06 | +84 | +42.2 |
| FIRE AND FLEE | 2 | 2 | 2 | 0.06 | +10 | +5.0 |
| KEEP FALLS | 2 | 2 | 2 | 0.06 | +19 | +9.7 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| PERIAPT WORTH | 2 | 2 | 2 | 0.06 | +220 | +110.2 |
| STANDS TO CAST | 3 | 2 | 2 | 0.06 | +21 | +10.5 |
| SUPPORT NARROWED | 228 | 228 | 2 | 0.06 | -24 | -12.1 |
| CARRIES OUT SET-UP | 9 | 9 | 1 | 0.03 | -47 | -47.2 |
| CONTINUE AHEAD WEIGHED | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| FOCUS FIRE | 1 | 1 | 1 | 0.03 | +17 | +16.7 |
| KEEPS ITS PREY | 11 | 10 | 1 | 0.03 | +8 | +7.6 |
| MOVE SPELL IN RANGE | 5 | 3 | 1 | 0.03 | +55 | +55.4 |
| RAIDS THE BAGGAGE | 1 | 1 | 1 | 0.03 | +124 | +124.0 |
| STAY WEIGHED | 1 | 1 | 1 | 0.03 | +64 | +63.8 |
| TWO OR MORE ARRIVE | 30 | 28 | 1 | 0.03 | +16 | +16.0 |
| WAR ENGINE CHARGES | 1 | 1 | 1 | 0.03 | +165 | +165.1 |
| ALREADY CARRIED | 2 | not checked | - | - | - | - |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 32 | 32 | 0 | 0.00 | - | - |
| CARRIES OUT COUNTER | 2 | 2 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 41 | trace | - | - | - | - |
| CATCH FLIERS | 3 | not checked | - | - | - | - |
| CHARIOT WIZARD CAREFUL | 6 | 6 | 0 | 0.00 | - | - |
| CHEAP HELPER | 9 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 41 | not checked | - | - | - | - |
| ENGINEER BY LORE | 2 | 2 | 0 | 0.00 | - | - |
| FIGHT LIFT | 1 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 426 | not checked | - | - | - | - |
| GIVES UP | 54 | 53 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 33 | 32 | 0 | 0.00 | - | - |
| GROUND FLIERS | 1 | not checked | - | - | - | - |
| HELPER ALREADY ASKED | 4 | not checked | - | - | - | - |
| HELPER UNSEEN | 16 | 15 | 0 | 0.00 | - | - |
| HUNT DROPPED | 3 | trace | - | - | - | - |
| HUNT KEPT | 7 | trace | - | - | - | - |
| HUNT RESULT | 8 | trace | - | - | - | - |
| HUNT THE GUNS | 9 | trace | - | - | - | - |
| LONE CHARACTER SAFE SPOT | 47 | not checked | - | - | - | - |
| LONE WIZARD HOLDS BACK | 9 | 9 | 0 | 0.00 | - | - |
| LONG SHOT | 27 | 26 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 2 | 2 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 7 | trace | - | - | - | - |
| MARCH OVER CASTS | 33 | 33 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 11 | 11 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 16 | trace | - | - | - | - |
| MOVE SPELL SPOT | 15 | not checked | - | - | - | - |
| NOT NEEDED | 22 | 22 | 0 | 0.00 | - | - |
| NOT TURNED | 427 | 427 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 46 | not checked | - | - | - | - |
| OPENS A LANE | 16 | 10 | 0 | 0.00 | - | - |
| OVERRUN THREAT | 1 | not checked | - | - | - | - |
| PLAN RESULT | 2781 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 5 | 5 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 4 | 4 | 0 | 0.00 | - | - |
| SCOUT SPOT | 23 | 23 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 2 | 2 | 0 | 0.00 | - | - |
| SECOND HUNTER | 2 | 2 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 17 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 21 | not checked | - | - | - | - |
| SET-UP MISSED | 6 | trace | - | - | - | - |
| SPELL SETS UP CHARGE | 26 | not checked | - | - | - | - |
| SPELL WORTH | 100 | not checked | - | - | - | - |
| STABLE ROLE | 411 | 411 | 0 | 0.00 | - | - |
| STOPS | 2 | 2 | 0 | 0.00 | - | - |
| TURN WORTH | 33 | 32 | 0 | 0.00 | - | - |

### Off best figure: fw-h2h2-mine-1eea44e-p1

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 14.33 | 14.86 | 56.0 |
| FALLBACK | gate | 0.53 | 1.36 | 47.8 |
| TURN GATE | gate | 0.75 | 0.50 | 39.5 |
| RULE SWITCHED OFF | gate | - | 0.64 | 14.7 |
| LONE CHARACTER SAFE SPOT | gate | 0.19 | 0.36 | 64.8 |
| CHARGE NOW FIRST | rule | 0.50 | - | 72.9 |
| PATHS CROSS | rule | 0.14 | 0.17 | 65.3 |
| CANNON PLANNED TARGET | rule | 0.28 | - | 39.2 |
| SUPPORT REQUEST | gate | 0.08 | 0.19 | 50.7 |
| CHARGE NOW WEIGHED | rule | 0.11 | 0.14 | 74.3 |
| SURE CHARGE BEATS ADVANCE | rule | 0.19 | 0.06 | 59.9 |
| WAR ENGINE JOBS | rule | 0.25 | - | 59.3 |
| BIG CHARACTER SAFETY | rule | 0.11 | 0.11 | 8.6 |
| PIVOT GUARDS FLANK | rule | 0.14 | 0.08 | 6.4 |
| AFTERMATH BAND | gate | 0.06 | 0.14 | 1.7 |
| PURSUES BIG PREY | rule | 0.03 | 0.17 | 59.6 |
| CHAFF PASSED | rule | 0.11 | 0.06 | 7.6 |
| STOPS SHORT OF THE FLANK | rule | 0.08 | 0.06 | 5.8 |
| BLOCKED WHEEL | rule | 0.06 | 0.03 | 6.6 |
| BEST PRIZE | rule | 0.06 | - | 47.0 |
| CHARIOT NO STATIC JOB | rule | 0.03 | 0.03 | 23.2 |
| DEFENSIVE ARMY | rule | 0.06 | - | 5.7 |
| FACES THE THREAT | rule | 0.03 | 0.03 | 11.2 |
| FIGHT ORDER BAND | gate | 0.03 | 0.03 | 2.8 |
| SUPPORT NARROWED | rule | 0.06 | - | 12.1 |
| THROUGH LINE OF FIRE | rule | 0.06 | - | 10.8 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.03 | - | 35.7 |
| CARRIES OUT SET-UP | rule | - | 0.03 | 47.2 |
| FALLBACK BY WORTH | rule | 0.03 | - | 94.6 |
| FOLLOW UP WEIGHED | rule | 0.03 | - | 1.6 |
| MARCH ODDS | rule | - | 0.03 | 0.6 |
| NO REASON | gate | 0.03 | - | 125.2 |
| SAFER THAN THE JOB | rule | - | 0.03 | 17.6 |

### Plans: fw-h2h2-mine-1eea44e-p1

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 11.9 | 17% | 464 | 333 | 72% |
| Mine | charge | 3.6 | 55% | 552 | 304 | 55% |
| Mine | close in | 4.2 | 27% | 289 | 102 | 35% |
| Mine | hold | 5.1 | 37% | 314 | 0 | 0% |
| Mine | join | 0.7 | 100% | 28 | 0 | 0% |
| Mine | shoot | 9.5 | 64% | 351 | 847 | 241% |
| Mine | support | 4.1 | 87% | 37 | 0 | 0% |
| Opponent | advance | 12.3 | 13% | 506 | 235 | 46% |
| Opponent | charge | 3.9 | 64% | 408 | 416 | 102% |
| Opponent | close in | 6.3 | 21% | 495 | 147 | 30% |
| Opponent | hold | 3.5 | 40% | 239 | 0 | 0% |
| Opponent | join | 1.2 | 95% | 49 | 0 | 0% |
| Opponent | shoot | 4.1 | 58% | 84 | 208 | 248% |
| Opponent | support | 6.8 | 88% | 354 | 0 | 0% |

### Packages: hunt the guns, fw-h2h2-mine-1eea44e-p1

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.0 | 1 | 0 | 0% | 100% | 0% | 2.0 | 225 | 222 | 100% | 24 |
| Opponent | 0.2 | 8 | 1 | 0% | 14% | 0% | 2.0 | 362 | 53 | 14% | 86 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 103 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 112 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 65 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 61 |
| Kingdom of Bretonnia | 1.0 | 1 | 0 | 0% | 100% | 0% | 2.0 | 225 | 222 | 100% | 0 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 250 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 171 |
| Tomb Kings of Khemri | 0.3 | 2 | 0 | 0% | 0% | 0% | - | 264 | 0 | 0% | 65 |
| Vampire Counts | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 9 |
| Warriors of Chaos | 0.6 | 5 | 1 | 0% | 25% | 0% | 2.0 | 420 | 92 | 25% | 30 |
| Wood Elf Realms | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 329 | 0 | 0% | 78 |

### Battle groups: fw-h2h2-mine-1eea44e-p1

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 10.0 | 24% | 49% | 14% | 42% | 41% | 7% | 3% | 50% | 0% |
| Mine | REDIRECT COUNTER | 2.1 | 24% | 50% | 22% | 25% | 29% | 0% | 7% | 64% | 0% |
| Opponent | COUNTER-CHARGE COVER | 7.1 | 20% | 63% | 18% | 11% | 43% | 10% | 12% | 36% | 0% |
| Opponent | REDIRECT COUNTER | 4.7 | 22% | 89% | 16% | 0% | 25% | 3% | 6% | 66% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: fw-h2h2-mine-1eea44e-p1

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 3 | 0 (3) | 0 | 0 | 0 | 67% | 6.0 | 0 (1) | 0 (2) | - | 0 (1) | 0 (2) |
| Mine | Chaff | 39 | 38 (39) | 14 | 24 | 49 | 33% | 2.7 | 60 (12) | 14 (12) | 39 (15) | 41 (25) | 32 (14) |
| Mine | Character | 123 | 68 (123) | 67 | 1 | 26 | 16% | 2.6 | 83 (33) | 69 (68) | 23 (9) | 78 (65) | 63 (45) |
| Mine | Clean-up | 23 | 92 (23) | 44 | 48 | 37 | 39% | 3.4 | 59 (10) | 159 (9) | 8 (4) | 120 (11) | 68 (12) |
| Mine | Fast | 4 | 35 (4) | 35 | 0 | 34 | 0% | 1.8 | 67 (1) | 0 (2) | 0 (1) | 35 (4) | - |
| Mine | Fast Hammer | 40 | 43 (40) | 28 | 15 | 49 | 28% | 2.2 | 22 (19) | 63 (10) | 65 (11) | 50 (28) | 29 (12) |
| Mine | Fragile | 5 | 67 (5) | 67 | 0 | 40 | 20% | 2.2 | - | 84 (4) | 0 (1) | 0 (1) | 84 (4) |
| Mine | Hammer | 56 | 41 (56) | 21 | 20 | 33 | 14% | 2.7 | 45 (9) | 39 (38) | 47 (9) | 51 (36) | 26 (20) |
| Mine | Holder | 26 | 69 (26) | 7 | 62 | 35 | 46% | 3.1 | 66 (10) | 64 (12) | 93 (4) | 110 (14) | 23 (12) |
| Mine | Shooter | 45 | 104 (45) | 47 | 58 | 39 | 4% | 1.7 | 8 (4) | 108 (34) | 168 (7) | 94 (24) | 115 (21) |
| Mine | Support | 5 | 0 (5) | 0 | 0 | 70 | 20% | 2.8 | 0 (1) | 0 (4) | - | 0 (3) | 0 (2) |
| Mine | War machine | 56 | 47 (56) | 47 | 0 | 21 | 7% | 1.2 | 71 (13) | 41 (37) | 38 (6) | 138 (11) | 23 (45) |
| Mine | Wizard | 23 | 33 (23) | 33 | 0 | 56 | 13% | 2.4 | 91 (6) | 11 (11) | 0 (3) | 50 (4) | 35 (16) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | - | 0 (1) | 0 (1) | - |
| Opponent | Chaff | 70 | 62 (70) | 12 | 51 | 62 | 44% | 2.9 | 79 (28) | 37 (18) | 65 (24) | 78 (51) | 16 (19) |
| Opponent | Character | 113 | 49 (113) | 49 | 0 | 45 | 18% | 2.5 | 66 (45) | 41 (48) | 27 (5) | 50 (66) | 60 (32) |
| Opponent | Clean-up | 18 | 33 (18) | 29 | 4 | 33 | 17% | 3.1 | 30 (8) | 22 (7) | 89 (3) | 32 (13) | 37 (5) |
| Opponent | Early | 1 | 72 (1) | 72 | 0 | 100 | 0% | 4.0 | - | 72 (1) | - | 72 (1) | - |
| Opponent | Fast Hammer | 53 | 36 (53) | 21 | 15 | 45 | 28% | 2.9 | 20 (23) | 62 (15) | 34 (15) | 25 (36) | 55 (17) |
| Opponent | Fragile | 10 | 34 (10) | 34 | 0 | 63 | 10% | 2.3 | - | 68 (5) | 0 (5) | 23 (7) | 68 (3) |
| Opponent | Hammer | 63 | 21 (63) | 12 | 8 | 56 | 29% | 2.7 | 3 (21) | 29 (38) | 0 (4) | 17 (37) | 26 (26) |
| Opponent | Holder | 39 | 74 (39) | 5 | 70 | 20 | 38% | 3.4 | 33 (7) | 106 (24) | 29 (8) | 112 (18) | 40 (21) |
| Opponent | Shooter | 31 | 44 (31) | 12 | 32 | 59 | 6% | 1.2 | 3 (7) | 60 (19) | 35 (5) | 44 (17) | 43 (14) |
| Opponent | Support | 2 | 0 (2) | 0 | 0 | 0 | 100% | - | 0 (2) | - | - | - | 0 (2) |
| Opponent | War machine | 13 | 60 (13) | 60 | 0 | 47 | 15% | 1.0 | 29 (5) | 88 (5) | 57 (3) | 0 (3) | 77 (10) |
| Opponent | Wizard | 24 | 1 (24) | 1 | 0 | 45 | 8% | 3.0 | 0 (8) | 2 (7) | 0 (4) | 0 (10) | 2 (9) |

### Charged fights: fw-h2h2-mine-1eea44e-p1

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 5 | 376 | 52 | 1.8 | 1.2 | 29 | 21 | +7 | 1 of 9 | 4 of 9 | -6 | +11 |
| Mine | Chaos Dwarfs | 3 | 92 | 1007 | 4.0 | 1.2 | 252 | 36 | +216 | 9 of 12 | 5 of 12 | +440 | +171 |
| Mine | Dwarfen Mountain Holds | 4 | 498 | 43 | 1.2 | 1.0 | 34 | 0 | +34 | 1 of 5 | 4 of 5 | - | +34 |
| Mine | Empire of Man | 5 | 628 | 100 | 2.4 | 1.1 | 42 | 24 | +17 | 2 of 12 | 10 of 12 | +0 | +19 |
| Mine | Grand Cathay | 4 | 540 | 208 | 3.0 | 1.2 | 69 | 19 | +50 | 6 of 12 | 5 of 12 | +62 | +48 |
| Mine | High Elf Realms | 4 | 163 | 791 | 3.8 | 1.1 | 211 | 10 | +201 | 8 of 15 | 8 of 15 | +888 | +152 |
| Mine | Kingdom of Bretonnia | 1 | 120 | 1431 | 7.0 | 1.0 | 204 | 0 | +204 | 3 of 7 | 5 of 7 | - | +204 |
| Mine | Lizardmen | 1 | 0 | 455 | 3.0 | 1.0 | 152 | 0 | +152 | 0 of 3 | 3 of 3 | - | +152 |
| Mine | Ogre Kingdoms | 1 | 0 | 0 | 2.0 | 1.0 | 0 | 0 | +0 | 0 of 2 | 1 of 2 | - | +0 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 331 | 4.0 | 1.0 | 83 | 14 | +69 | 1 of 4 | 4 of 4 | - | +69 |
| Mine | Skaven | 2 | 202 | 0 | 0.5 | 1.0 | 0 | 0 | +0 | 1 of 1 | 0 of 1 | - | +0 |
| Mine | Tomb Kings of Khemri | 2 | 300 | 1085 | 8.0 | 1.2 | 136 | 35 | +101 | 5 of 16 | 9 of 16 | +397 | +32 |
| Mine | Vampire Counts | 2 | 0 | 828 | 6.5 | 1.2 | 127 | 109 | +18 | 3 of 13 | 4 of 13 | +97 | -5 |
| Mine | Warriors of Chaos | 1 | 0 | 0 | 4.0 | 1.0 | 0 | 51 | -51 | 1 of 4 | 2 of 4 | - | -51 |
| **Mine** | all armies | 36 | 312 | 389 | 3.2 | 1.1 | 122 | 31 | +91 | 41 of 115 | 64 of 115 | +240 | +70 |
| Opponent | Beastmen Brayherds | 1 | 0 | 0 | 3.0 | 1.0 | 0 | 28 | -28 | 0 of 3 | 1 of 3 | - | -28 |
| Opponent | Dwarfen Mountain Holds | 1 | 310 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Empire of Man | 1 | 160 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Grand Cathay | 1 | 400 | 486 | 3.0 | 1.0 | 162 | 72 | +90 | 2 of 3 | 1 of 3 | - | +90 |
| Opponent | High Elf Realms | 2 | 62 | 296 | 2.0 | 1.0 | 148 | 0 | +148 | 2 of 4 | 1 of 4 | - | +148 |
| Opponent | Lizardmen | 1 | 0 | 505 | 2.0 | 1.0 | 252 | 42 | +211 | 1 of 2 | 1 of 2 | - | +211 |
| Opponent | Ogre Kingdoms | 2 | 80 | 258 | 3.0 | 1.3 | 86 | 120 | -34 | 3 of 6 | 3 of 6 | +132 | -118 |
| Opponent | Orc & Goblin Tribes | 2 | 0 | 216 | 4.0 | 1.0 | 54 | 87 | -33 | 4 of 8 | 3 of 8 | - | -33 |
| Opponent | Skaven | 2 | 155 | 32 | 2.0 | 1.2 | 16 | 0 | +16 | 2 of 4 | 1 of 4 | +0 | +22 |
| Opponent | Tomb Kings of Khemri | 4 | 142 | 838 | 4.0 | 1.2 | 209 | 46 | +163 | 9 of 16 | 9 of 16 | +244 | +152 |
| Opponent | Vampire Counts | 6 | 63 | 485 | 3.7 | 1.4 | 132 | 9 | +124 | 11 of 22 | 17 of 22 | +204 | +93 |
| Opponent | Warriors of Chaos | 7 | 0 | 415 | 2.6 | 1.1 | 161 | 19 | +142 | 7 of 18 | 14 of 18 | +151 | +141 |
| Opponent | Wood Elf Realms | 6 | 28 | 217 | 3.2 | 1.0 | 68 | 68 | +0 | 8 of 19 | 12 of 19 | - | +0 |
| **Opponent** | all armies | 36 | 72 | 363 | 2.9 | 1.2 | 124 | 42 | +83 | 49 of 105 | 63 of 105 | +177 | +71 |

### Effective charges: fw-h2h2-mine-1eea44e-p1

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 9 | 0 | 0 | 2 (net -70) | 2 (net +66) | 1 (net +40) | 1 (net +34) | 3 | 33% (2 of 6) |
| Mine | Chaos Dwarfs | 12 | 2 (net +322) | 0 | 1 (net -79) | 4 (net +134) | 0 | 3 (net +459) | 2 | 10% (1 of 10) |
| Mine | Dwarfen Mountain Holds | 5 | 1 (net +0) | 0 | 2 (net +56) | 0 | 0 | 2 (net +30) | 0 | 40% (2 of 5) |
| Mine | Empire of Man | 12 | 1 (net +0) | 0 | 2 (net -85) | 3 (net +58) | 1 (net +0) | 3 (net +103) | 2 | 20% (2 of 10) |
| Mine | Grand Cathay | 12 | 1 (net +0) | 0 | 3 (net +70) | 3 (net -30) | 2 (net +92) | 3 (net +99) | 0 | 25% (3 of 12) |
| Mine | High Elf Realms | 15 | 3 (net +221) | 0 | 2 (net -72) | 2 (net +532) | 3 (net +351) | 5 (net +77) | 0 | 13% (2 of 15) |
| Mine | Kingdom of Bretonnia | 7 | 2 (net +176) | 0 | 0 | 0 | 1 (net +68) | 4 (net +252) | 0 | 0% (0 of 7) |
| Mine | Lizardmen | 3 | 0 | 0 | 0 | 2 (net +30) | 0 | 1 (net +395) | 0 | 0% (0 of 3) |
| Mine | Ogre Kingdoms | 2 | 0 | 0 | 1 (net +0) | 0 | 0 | 0 | 1 | 100% (1 of 1) |
| Mine | Orc & Goblin Tribes | 4 | 0 | 0 | 0 | 0 | 1 (net +66) | 0 | 3 | 0% (0 of 1) |
| Mine | Skaven | 1 | 1 (net +0) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 1) |
| Mine | Tomb Kings of Khemri | 16 | 2 (net -246) | 0 | 2 (net -33) | 2 (net +604) | 2 (net +62) | 6 (net +111) | 2 | 14% (2 of 14) |
| Mine | Vampire Counts | 13 | 1 (net +619) | 0 | 1 (net -45) | 4 (net -242) | 3 (net +89) | 4 (net +90) | 0 | 8% (1 of 13) |
| Mine | Warriors of Chaos | 4 | 0 | 0 | 2 (net +0) | 0 | 1 (net +0) | 0 | 1 | 67% (2 of 3) |
| Opponent | Beastmen Brayherds | 3 | 0 | 0 | 1 (net +0) | 1 (net +0) | 0 | 0 | 1 | 50% (1 of 2) |
| Opponent | Grand Cathay | 3 | 1 (net -32) | 0 | 0 | 2 (net +150) | 0 | 0 | 0 | 0% (0 of 3) |
| Opponent | High Elf Realms | 4 | 1 (net +217) | 0 | 1 (net +0) | 1 (net +147) | 0 | 1 (net +227) | 0 | 25% (1 of 4) |
| Opponent | Lizardmen | 2 | 0 | 0 | 0 | 0 | 0 | 1 (net +297) | 1 | 0% (0 of 1) |
| Opponent | Ogre Kingdoms | 6 | 0 | 1 (net -185) | 0 | 0 | 0 | 4 (net +3) | 1 | 0% (0 of 5) |
| Opponent | Orc & Goblin Tribes | 8 | 0 | 0 | 0 | 2 (net +80) | 0 | 0 | 6 | 0% (0 of 2) |
| Opponent | Skaven | 4 | 1 (net +0) | 0 | 0 | 1 (net +0) | 0 | 2 (net +32) | 0 | 0% (0 of 4) |
| Opponent | Tomb Kings of Khemri | 16 | 2 (net -35) | 2 (net -152) | 3 (net +361) | 3 (net +184) | 1 (net +110) | 4 (net +326) | 1 | 20% (3 of 15) |
| Opponent | Vampire Counts | 22 | 3 (net -33) | 1 (net +300) | 5 (net +168) | 2 (net +0) | 1 (net +0) | 10 (net +168) | 0 | 23% (5 of 22) |
| Opponent | Warriors of Chaos | 18 | 1 (net +499) | 0 | 2 (net +246) | 2 (net +93) | 0 | 6 (net +179) | 7 | 18% (2 of 11) |
| Opponent | Wood Elf Realms | 19 | 5 (net -12) | 0 | 1 (net -599) | 4 (net -75) | 1 (net +0) | 5 (net +199) | 3 | 6% (1 of 16) |

### Charged fights, damage counted: fw-h2h2-mine-1eea44e-p1

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 14 | 351 | 299 | +128 | 217 | 39 | +177 | +50.6 |
| Mine | Effective (55-75%) | 18 | 174 | 144 | -18 | 38 | 52 | -14 | -7.8 |
| Mine | 76-89% | 22 | 262 | 227 | +96 | 178 | 86 | +92 | +35.3 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 32 | 250 | 184 | +153 | 191 | 18 | +173 | +69.4 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 15 | 471 | 104 | +120 | 120 | 17 | +104 | +22.0 |
| Mine | No odds | 14 | 297 | 151 | +13 | 72 | 29 | +43 | +14.4 |
| Mine | All fights | 115 | 287 | 186 | +91 | 144 | 40 | +104 | +36.3 |
| Opponent | Long shot (under 50%) | 14 | 157 | 308 | +32 | 117 | 86 | +31 | +19.5 |
| Opponent | 50-54% | 4 | 334 | 262 | -48 | 172 | 218 | -46 | -13.9 |
| Opponent | Effective (55-75%) | 13 | 283 | 228 | +140 | 219 | 49 | +170 | +60.2 |
| Opponent | 76-89% | 18 | 225 | 150 | +58 | 110 | 26 | +84 | +37.3 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 33 | 280 | 224 | +171 | 213 | 35 | +178 | +63.5 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 3 | 273 | 72 | +37 | 76 | 11 | +65 | +23.7 |
| Opponent | No odds | 20 | 145 | 229 | -10 | 79 | 79 | +1 | +0.5 |
| Opponent | All fights | 105 | 231 | 221 | +83 | 152 | 57 | +96 | +41.5 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| fw-h2h2-mine-1eea44e-p1 | move | 473 | 107 (23%) | 73 (15%) | 58 (12%) | 308 (65%) |
| fw-h2h2-mine-1eea44e-p1 | objective | 384 | 58 (15%) | 40 (10%) | 51 (13%) | 275 (72%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0102, L0118, L0135, L2531, L2730 |
| Charmed Shield | Opponent | L0524, L1224, L1527, L1625, L2025, L2127, L2934 |
| Clockwork Compass | Mine | L1224 |
| Clockwork Compass | Opponent | L0612 |
| Elixir of Power | Mine | L1114, L1131, L1923 |
| Elixir of Power | Opponent | L0319, L1319 |
| Fistful of Laurels | Mine | L1823 |
| Fistful of Laurels | Opponent | L0118, L0218 |
| Horn of the Wild Hunt | Opponent | L0733 |
| Invocation of Nehek | Mine | L2531, L2730 |
| Invocation of Nehek | Opponent | L0524, L1224, L1527, L1625, L2025, L2127 |
| Opal Amulet | Mine | L1431 |
| Opal Amulet | Opponent | L1114 |
| Periapt of Soul Exchange | Mine | L2025, L2127 |
| Periapt of Soul Exchange | Opponent | L0421, L1021 |
| Ring of Doom | Mine | L0218, L0235, L1114, L1131, L1224, L1527 |
| Ring of Doom | Opponent | L0102, L0612, L0733, L1131, L1431, L2231, L2531 |
| Ring of Jet | Mine | L1021, L1114, L1131, L1224 |
| Ring of Jet | Opponent | L0612 |
| Standard of the Fell Warrior | Mine | L1319, L1335 |
| Standard of the Fell Warrior | Opponent | L0913 |
| Storm Daemon (Renegade 2.0) | Mine | L2127 |
| Storm Daemon (Renegade 2.0) | Opponent | L0421, L1021 |
| Twice-Blessed Armour | Mine | L0717, L0733, L1021 |
| Witch Hunter's Ward | Mine | L0717, L0733, L0823 |
| Witch Hunter's Ward | Opponent | L0508 |

# Doctrine scorecard: fw-h2h2-opp-1eea44e-p2

### Scorecard: fw-h2h2-opp-1eea44e-p2

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0106 | 4 | 1 | Mine | no | 1 | 4 | 0 | 2 | 0 | 0 | 0 | 65 |
| L0106 | 4 | 1 | Opponent | yes | 0 | 2 | 0 | 0 | 0 | 0 | 0 | 743 |
| L0122 | 2 | 1 | Mine | - | - | - | 0 | 1 | 1 | 0 | 0 | 639 |
| L0122 | 2 | 1 | Opponent | - | - | 2 | 5 | 1 | 1 | 0 | 0 | 0 |
| L0206 | 2 | 1 | Mine | - | - | 2 | 2 | 4 | 1 | 0 | 0 | 0 |
| L0206 | 2 | 1 | Opponent | - | - | 2 | 2 | 1 | 0 | 0 | 0 | 798 |
| L0222 | 6 | 1 | Mine | no | 4 | - | 0 | 3 | 1 | 0 | 0 | 0 |
| L0222 | 6 | 1 | Opponent | no | 0 | 2 | 4 | 0 | 0 | 0 | 0 | 0 |
| L0307 | 1 | 1 | Mine | yes | 1 | 2 | 2 | 0 | 0 | 0 | 0 | 620 |
| L0307 | 1 | 1 | Opponent | yes | 4 | - | 0 | 2 | 1 | 0 | 0 | 420 |
| L0323 | 5 | 1 | Mine | no | - | 4 | 2 | 3 | 0 | 0 | 0 | 675 |
| L0323 | 5 | 1 | Opponent | yes | - | 2 | 2 | 2 | 0 | 0 | 0 | 0 |
| L0409 | 1 | 1 | Mine | no | 4 | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L0409 | 1 | 1 | Opponent | no | 7 | 3 | 0 | 0 | 0 | 0 | 0 | 913 |
| L0425 | 5 | 1 | Mine | yes | - | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| L0425 | 5 | 1 | Opponent | yes | - | 2 | 3 | 3 | 1 | 0 | 0 | 0 |
| L0512 | 2 | 1 | Mine | - | - | - | 1 | 1 | 0 | 0 | 0 | 666 |
| L0512 | 2 | 1 | Opponent | - | - | 2 | 7 | 4 | 0 | 0 | 0 | 330 |
| L0528 | 6 | 1 | Mine | no | 1 | - | 0 | 2 | 0 | 0 | 0 | 1050 |
| L0528 | 6 | 1 | Opponent | no | 6 | 2 | 2 | 0 | 0 | 0 | 0 | 0 |
| L0616 | 4 | 1 | Mine | no | 0 | 3 | 1 | 0 | 1 | 0 | 0 | 828 |
| L0616 | 4 | 1 | Opponent | no | 1 | 2 | 6 | 1 | 2 | 0 | 0 | 200 |
| L0632 | 2 | 1 | Mine | - | - | 2 | 2 | 0 | 0 | 0 | 0 | 615 |
| L0632 | 2 | 1 | Opponent | - | - | 2 | 6 | 3 | 1 | 0 | 0 | 170 |
| L0721 | 1 | 1 | Mine | yes | 2 | 3 | 5 | 1 | 0 | 0 | 0 | 420 |
| L0721 | 1 | 1 | Opponent | no | 0 | - | 1 | 5 | 1 | 0 | 0 | 355 |
| L0810 | 6 | 1 | Mine | no | 3 | 2 | 1 | 2 | 0 | 0 | 0 | 769 |
| L0810 | 6 | 1 | Opponent | no | 14 | 2 | 1 | 0 | 0 | 0 | 0 | 330 |
| L0827 | 5 | 1 | Mine | no | - | 4 | 2 | 1 | 0 | 0 | 0 | 515 |
| L0827 | 5 | 1 | Opponent | yes | - | 2 | 1 | 3 | 0 | 0 | 0 | 0 |
| L0918 | 6 | 1 | Mine | no | 0 | 2 | 3 | 0 | 1 | 0 | 0 | 420 |
| L0918 | 6 | 1 | Opponent | no | 15 | 2 | 4 | 2 | 0 | 0 | 0 | 419 |
| L0934 | 4 | 1 | Mine | no | 4 | 1 | 3 | 0 | 0 | 0 | 0 | 515 |
| L0934 | 4 | 1 | Opponent | yes | 1 | 2 | 4 | 2 | 0 | 0 | 0 | 160 |
| L1026 | 6 | 1 | Mine | no | 0 | 2 | 4 | 1 | 0 | 0 | 0 | 456 |
| L1026 | 6 | 1 | Opponent | no | 5 | 2 | 2 | 2 | 1 | 0 | 0 | 439 |
| L1118 | 2 | 1 | Mine | - | - | 3 | 2 | 1 | 0 | 0 | 0 | 330 |
| L1118 | 2 | 1 | Opponent | - | - | 2 | 5 | 3 | 0 | 0 | 0 | 0 |
| L1135 | 1 | 1 | Mine | yes | 0 | 2 | 1 | 0 | 0 | 0 | 0 | 330 |
| L1135 | 1 | 1 | Opponent | yes | 0 | 3 | 5 | 1 | 0 | 0 | 0 | 0 |
| L1228 | 4 | 1 | Mine | no | 4 | 2 | 1 | 1 | 0 | 0 | 0 | 524 |
| L1228 | 4 | 1 | Opponent | no | 0 | 3 | 2 | 2 | 0 | 0 | 0 | 0 |
| L1323 | 3 | 1 | Mine | yes | 4 | 6 | 1 | 0 | 1 | 0 | 0 | 317 |
| L1323 | 3 | 1 | Opponent | no | 2 | 2 | 5 | 2 | 0 | 0 | 0 | 66 |
| L1418 | 2 | 1 | Mine | - | - | 1 | 7 | 0 | 0 | 0 | 0 | 0 |
| L1418 | 2 | 1 | Opponent | - | - | 5 | 3 | 1 | 0 | 0 | 0 | 305 |
| L1435 | 1 | 1 | Mine | no | 0 | 3 | 2 | 2 | 0 | 0 | 0 | 0 |
| L1435 | 1 | 1 | Opponent | no | 0 | 5 | 3 | 1 | 0 | 0 | 0 | 0 |
| L1531 | 1 | 1 | Mine | no | 6 | 2 | 1 | 1 | 0 | 0 | 0 | 176 |
| L1531 | 1 | 1 | Opponent | no | 0 | 3 | 2 | 2 | 0 | 0 | 0 | 340 |
| L1629 | 3 | 1 | Mine | no | 3 | 3 | 4 | 0 | 1 | 0 | 0 | 200 |
| L1629 | 3 | 1 | Opponent | no | 0 | 2 | 5 | 0 | 1 | 0 | 0 | 170 |
| L1727 | 5 | 1 | Mine | yes | - | 3 | 5 | 0 | 0 | 0 | 0 | 147 |
| L1727 | 5 | 1 | Opponent | yes | - | 2 | 8 | 1 | 0 | 0 | 0 | 0 |
| L1827 | 3 | 1 | Mine | no | 0 | 2 | 3 | 0 | 0 | 0 | 0 | 297 |
| L1827 | 3 | 1 | Opponent | no | 2 | 2 | 5 | 2 | 0 | 0 | 0 | 0 |
| L1927 | 1 | 1 | Mine | no | 0 | 1 | 4 | 0 | 0 | 0 | 0 | 0 |
| L1927 | 1 | 1 | Opponent | no | 8 | 2 | 2 | 0 | 0 | 0 | 0 | 0 |
| L2029 | 1 | 1 | Mine | no | 2 | - | 2 | 3 | 2 | 0 | 0 | 650 |
| L2029 | 1 | 1 | Opponent | no | 0 | 2 | 1 | 1 | 1 | 0 | 0 | 170 |
| L2131 | 1 | 1 | Mine | yes | 3 | - | 2 | 3 | 0 | 0 | 0 | 555 |
| L2131 | 1 | 1 | Opponent | no | 2 | 2 | 2 | 1 | 2 | 0 | 0 | 0 |
| L2235 | 3 | 1 | Mine | no | 1 | 3 | 2 | 0 | 0 | 0 | 0 | 0 |
| L2235 | 3 | 1 | Opponent | no | 0 | 4 | 3 | 1 | 0 | 0 | 0 | 0 |
| L2429 | 5 | 1 | Mine | yes | - | 2 | 4 | 3 | 0 | 0 | 0 | 0 |
| L2429 | 5 | 1 | Opponent | yes | - | 3 | 3 | 2 | 0 | 0 | 0 | 170 |
| L2535 | 3 | 1 | Mine | no | 5 | 3 | 2 | 0 | 0 | 0 | 0 | 0 |
| L2535 | 3 | 1 | Opponent | no | 0 | 1 | 7 | 2 | 0 | 0 | 0 | 0 |
| L2735 | 5 | 1 | Mine | no | - | 2 | 2 | 2 | 0 | 0 | 0 | 0 |
| L2735 | 5 | 1 | Opponent | yes | - | 2 | 4 | 3 | 0 | 0 | 0 | 0 |
| L3033 | 3 | 1 | Mine | yes | 5 | 2 | 6 | 1 | 0 | 0 | 0 | 0 |
| L3033 | 3 | 1 | Opponent | no | 0 | 2 | 3 | 2 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 30% | 2.2 | 2.5 | 2.4 | 1.1 | 0.2 | 0.0 | 0.0 | 327.2 |
| **Average** | | | Opponent | 33% | 2.8 | 2.4 | 3.3 | 1.6 | 0.3 | 0.0 | 0.0 | 180.5 |

### KPIs: fw-h2h2-opp-1eea44e-p2

Rules off - Mine only: WAR ENGINE JOBS, STAY WEIGHED, BEST FIRST, RANDOM MOVE BY FIGURES, RANDOM MOVER NO PROMISE, STABLE ROLE, WOUNDED STAYS OUT, BEST FACING, LOST CHARGE, SCREEN BY WHAT IT SAVES, REDIRECT BY WHAT IT STOPS, SHOOTER COUNTED ONCE, LURE BY WHAT IT DRAWS, HILL BY ITS CHANCE, MOVE TO CHARGE, LONG SHOT, DEFENSIVE ARMY, SHOOTS FROM THE BEST SPOT, SUPPORTS, RESERVE FALL BACK, WAIT AFTER COSTS, CHARGE NOW FIRST, SUPPORT NARROWED, WAR ENGINE CHARGES, DEFENSIVE FLOOR.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 175) | 14% (25 of 183) | 7% (25 of 358) |
| Winner chose to follow up after the loser gave ground |  | 96% (67 of 70); on the table 97% | 97% (60 of 62); on the table 97% | 96% (127 of 132); on the table 97% |
| Winner chose to pursue after the loser fell back in good order |  | 92% (12 of 13); on the table 100% | 88% (23 of 26); on the table 88% | 90% (35 of 39); on the table 92% |
| Winner chose to pursue after the loser fled |  | 65% (17 of 26); on the table 77% | 81% (22 of 27); on the table 89% | 74% (39 of 53); on the table 83% |
| Winner chose to follow up or pursue (all three) |  | 88% (96 of 109); on the table 93% | 91% (105 of 115); on the table 93% | 90% (201 of 224); on the table 93% |
| Magic missiles tried each own turn | 50%+ | 27% (91 of 342) | 31% (48 of 156) | 28% (139 of 498) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 43% (91 of 214) | 39% (42 of 108) | 41% (133 of 322) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 60% (28 of 47) | 60% (28 of 47) |
| Points that never fought | lower | 31% (22292 of 71583) | 38% (27284 of 71989) | 35% (49576 of 143572) |
|   infantry points that never fought | lower | 39% (6425 of 16324) | 56% (7925 of 14029) | 47% (14350 of 30353) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 60% (170 of 284) | 58% (171 of 297) | 59% (341 of 581) |
| Bound items with a magic missile used (at least once a game) |  | 80% (16 of 20); 1.1 uses a game | 72% (13 of 18); 1.0 uses a game | 76% (29 of 38); 1.1 uses a game |
| Bound items with another spell used |  | 67% (12 of 18); 0.8 uses a game | 50% (1 of 2); 0.1 uses a game | 65% (13 of 20); 0.5 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 55% (11 of 20); 0.3 uses a game | 29% (2 of 7); 0.1 uses a game | 48% (13 of 27); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 55% (33020 of 60231) | 51% (32244 of 63281) | 53% (65264 of 123512) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.7 (25%) | 0.9 (29%) | 2.6 (26%) |
| MARCHED: its unit marched | 1.4 (20%) | 0.4 (14%) | 1.8 (18%) |
| CHARGED: its unit charged | 0.2 (3%) | 0.2 (6%) | 0.4 (4%) |
| IN COMBAT: engaged in combat | 1.9 (27%) | 0.4 (14%) | 2.3 (23%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.1 (4%) | 0.1 (1%) |
| FLEEING: fleeing | 0.2 (2%) | 0.0 (0%) | 0.2 (2%) |
| GONE: slain | 1.1 (16%) | 0.6 (19%) | 1.6 (16%) |
| OFF THE TABLE: off the table or not arrived | 0.4 (6%) | 0.2 (6%) | 0.6 (6%) |
| STUPIDITY: Stupidity | 0.1 (1%) | 0.1 (3%) | 0.1 (1%) |
| NOT OFFERED: not in the cast list | 0.1 (1%) | 0.2 (6%) | 0.2 (3%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.4 | 1.7 | 1.1 | 3.9 | 0.5 | 2.2 |
| not cast | 3.5 | 3.2 | 3.9 | 10.0 | 1.9 | 19.5 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) | 1.6 (8%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.2 (38%) | 0.2 (6%) | 2.6 (26%) | 0.3 (18%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.8 (18%) | 0.3 (18%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.4 (4%) | 0.1 (6%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (1%) | 0.2 (5%) | 0.6 (17%) | 2.3 (23%) | 0.1 (4%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.2 (6%) | 0.3 (9%) | 0.2 (6%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (1%) | 0.2 (6%) | 0.0 (1%) | 0.2 (2%) | 0.1 (4%) | 0.2 (1%) |
| GONE: slain | 0.7 (20%) | 0.8 (25%) | 0.8 (20%) | 1.6 (16%) | 0.2 (13%) | 2.8 (14%) |
| OFF THE TABLE: off the table or not arrived | 0.4 (13%) | 0.0 (0%) | 0.3 (8%) | 0.6 (6%) | 0.2 (10%) | 1.0 (5%) |
| STUPIDITY: Stupidity | 0.1 (2%) | 0.1 (3%) | 0.0 (1%) | 0.1 (1%) | 0.0 (0%) | 0.4 (2%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (3%) | 0.2 (8%) | 0.0 (0%) | 0.0 (0%) | 0.5 (25%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (3%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.9 (55%) | 0.2 (6%) | 1.6 (40%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 13.5 (69%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.5 a game | 0.7 a game | 0.6 a game |
| stood (cast and not dispelled) | 80% (12 of 15) | 64% (16 of 25) | 70% (28 of 40) |
| the unit moved after it | 83% (10 of 12) | 38% (6 of 16) | 57% (16 of 28) |
| it charged on its next turn | 17% (2 of 12) | 12% (2 of 16) | 14% (4 of 28) |
| the enemy charged it first | 0% (0 of 12) | 6% (1 of 16) | 4% (1 of 28) |
| it fought by the end of its next turn | 0% (0 of 12) | 6% (1 of 16) | 4% (1 of 28) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 12) | 6% (1 of 16) | 4% (1 of 28) |
| none of these (no charge, no fight, no charge escaped) | 83% (10 of 12) | 81% (13 of 16) | 82% (23 of 28) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 62% (509 of 817) | 52% (427 of 827) | 57% (936 of 1644) |
|   cavalry | 52% (32 of 61) | 60% (113 of 189) | 58% (145 of 250) |
|   character | 46% (40 of 87) | 27% (32 of 118) | 35% (72 of 205) |
|   chariot | 39% (37 of 94) | 61% (30 of 49) | 47% (67 of 143) |
|   infantry | 55% (142 of 257) | 53% (158 of 298) | 54% (300 of 555) |
|   monster | 39% (18 of 46) | 46% (21 of 46) | 42% (39 of 92) |
|   war machine | 88% (240 of 272) | 57% (73 of 127) | 78% (313 of 399) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.4 (28%) | 2.6 (24%) | 5.0 (26%) |
| CHARGED: it charged | 1.4 (16%) | 2.3 (21%) | 3.7 (19%) |
| FLEEING: it fled or was fleeing | 0.2 (2%) | 0.1 (1%) | 0.3 (1%) |
| IN COMBAT: it fought this turn or the last | 1.2 (15%) | 0.7 (6%) | 1.9 (10%) |
| MOVED: a war machine that moved | 0.1 (1%) | 0.0 (0%) | 0.1 (0%) |
| NO TARGET IN RANGE | 0.9 (11%) | 1.8 (16%) | 2.8 (14%) |
| ONLY IN COMBAT: the only targets were in combat | 0.6 (7%) | 0.7 (6%) | 1.3 (6%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.3 (16%) | 2.3 (20%) | 3.6 (18%) |
| SHELTERED: the target was sheltered | 0.2 (2%) | 0.2 (2%) | 0.4 (2%) |
| OTHER BAR | 0.2 (2%) | 0.4 (4%) | 0.6 (3%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 6.0 | 1.1 | 84% | 4.8 pts | 29 pts |
| character | 2.2 | 0.5 | 83% | 6.6 pts | 15 pts |
| chariot | 1.9 | 1.5 | 65% | 14.9 pts | 28 pts |
| infantry | 11.4 | 4.3 | 75% | 8.2 pts | 93 pts |
| monster | 1.2 | 0.4 | 78% | 8.5 pts | 11 pts |
| war machine | 8.7 | 7.3 | 59% | 23.9 pts | 208 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.4 | 7.3 | 5.8 |
| Charges that made contact a game | 3.4 | 4.9 | 4.1 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.92 declared, 0.76 contact (25 units) | 0.46 declared, 0.23 contact (13 units) | 0.76 declared, 0.58 contact (38 units) |
|   per unit a game, units carrying another wizard (or one alone) | 1.00 declared, 0.62 contact (8 units) | 1.45 declared, 0.91 contact (11 units) | 1.26 declared, 0.79 contact (19 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.50 declared, 0.39 contact (250 units) | 0.83 declared, 0.56 contact (291 units) | 0.68 declared, 0.48 contact (541 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 58% (42 of 73) | 56% (10 of 18) | 58% (7 of 12) | 57% (59 of 103) |
| Character in a unit | 81% (22 of 27) | 69% (11 of 16) | 75% (3 of 4) | 77% (36 of 47) |
| Character on its own | 82% (37 of 45) | 47% (18 of 38) | 26% (16 of 62) | 49% (71 of 145) |
| Chariot | 76% (13 of 17) | 62% (8 of 13) | - | 70% (21 of 30) |
| Infantry | 55% (52 of 94) | 59% (20 of 34) | 33% (1 of 3) | 56% (73 of 131) |
| Monster | 52% (15 of 29) | 67% (6 of 9) | - | 55% (21 of 38) |
| Monstrous | 64% (9 of 14) | 57% (8 of 14) | - | 61% (17 of 28) |
| War Machines | 72% (41 of 57) | 100% (2 of 2) | - | 73% (43 of 59) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 100% (11 of 11); on the table 100% | 16% (16 of 102) | 24% | 45% (10 of 22) | 83% (5 of 6); 2.2 uses a game | 50% (1 of 2); 0.2 uses a game | 83% (5 of 6); 1.2 uses a game |
| Chaos Dwarfs | 4 | 82% (9 of 11); on the table 91% | 44% (16 of 36) | 39% | 62% (20 of 32) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
| Dwarfen Mountain Holds | 6 | 91% (10 of 11); on the table 91% | - | 53% | 69% (37 of 54) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 7 | 94% (15 of 16); on the table 94% | 21% (10 of 48) | 49% | 63% (48 of 76) | 0.0 uses a game | 100% (2 of 2); 1.0 uses a game | 50% (2 of 4); 0.3 uses a game |
| Grand Cathay | 6 | 100% (22 of 22); on the table 100% | 33% (45 of 138) | 45% | 50% (27 of 54) | 64% (9 of 14); 4.3 uses a game | 50% (1 of 2); 0.2 uses a game | 17% (1 of 6); 0.2 uses a game |
| High Elf Realms | 4 | 81% (17 of 21); on the table 81% | 28% (5 of 18) | 24% | 61% (20 of 33) | 100% (3 of 3); 2.0 uses a game | 64% (9 of 14); 6.5 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 2 | 57% (4 of 7); on the table 57% | - | 36% | 25% (3 of 12) | 0.0 uses a game | 0.0 uses a game | 100% (2 of 2); 1.0 uses a game |
| Lizardmen | 1 | 100% (4 of 4); on the table 100% | - | 8% | 57% (4 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 4 | 75% (6 of 8); on the table 88% | 6% (1 of 18) | 35% | 57% (16 of 28) | 100% (4 of 4); 3.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 1 | 100% (1 of 1); on the table 100% | 17% (2 of 12) | 0% | 25% (2 of 8) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Skaven | 3 | 67% (4 of 6); on the table 100% | 17% (3 of 18) | 38% | 64% (16 of 25) | 100% (2 of 2); 1.3 uses a game | 0.0 uses a game | 33% (1 of 3); 0.3 uses a game |
| Tomb Kings of Khemri | 5 | 100% (8 of 8); on the table 100% | - | 32% | 24% (6 of 25) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 9 | 90% (38 of 42); on the table 98% | 38% (25 of 66) | 26% | 69% (37 of 54) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 9 | 89% (25 of 28); on the table 89% | 44% (8 of 18) | 25% | 59% (43 of 73) | 100% (2 of 2); 0.8 uses a game | 0.0 uses a game | 100% (1 of 1); 0.1 uses a game |
| Wood Elf Realms | 7 | 96% (27 of 28); on the table 96% | 33% (8 of 24) | 37% | 67% (52 of 78) | 57% (4 of 7); 1.6 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (fw-h2h2-opp-1eea44e-p2, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 52% (56) | 51% (36) | 52% (92) |
| ...free all their last turn and able to turn (per game) | 0.86 | 0.61 | 1.47 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.31 | 0.22 | 0.53 |
| ...with the charger already in that arc before they moved (per game) | 0.61 | 0.28 | 0.89 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 1.19 | 1.56 | 2.75 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.56 | 0.97 | 1.53 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 7.47 | 5.92 | 13.39 |

### Quality by phase: fw-h2h2-opp-1eea44e-p2

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.8 | 3.3 |
| Strategy | Charge objectives carried out (made contact) | 53% (72 of 135) | 45% (111 of 245) |
| Strategy | Shoot objectives carried out (shot that target) | 48% (147 of 306) | 50% (109 of 218) |
| Strategy | Close-in objectives charged next turn | 10% (16 of 157) | 20% (46 of 232) |
| Strategy | Support requests answered (helper made contact too) | 76% (13 of 17) | 40% (14 of 35) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (2 of 2) | - |
| Strategy | Hexes on a unit its side charged or shot that turn | 36% (8 of 22) | 54% (7 of 13) |
| Strategy | Joined characters whose unit fought | 59% (24 of 41) | 31% (11 of 35) |
| Strategy | Lone characters that fought | 79% (82 of 104) | 76% (67 of 88) |
| Movement | Charges halted short of contact | 0.2 | 0.5 |
| Movement | Idle units | 1.1 | 1.6 |
| Movement | Points that never moved of their own | 327.2 | 180.5 |
| Movement | Fights charged into per game | 3.0 | 4.2 |
| Movement | Charges with odds: long shots (under 50%) | 9 of 97, net +84 | 26 of 136, net +18 |
| Movement | Charges with odds: sweet spot (55-75%) | 16 of 97, net -32 | 24 of 136, net +83 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 19 of 97, net +110 | 7 of 136, net +72 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 32 of 97, net +106 | 48 of 136, net +144 |
| Shooting | Shots by shooting units (incl. breath weapons) | 8.5 | 10.9 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 41% (125 of 306) | 48% (187 of 391) |
| Shooting | Points destroyed by shooting units | 62.7 | 31.2 |
| Shooting | War machine shots | 6.7 | 2.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 52% (124 of 240) | 51% (37 of 73) |
| Shooting | Points destroyed by war machines | 68.5 | 31.8 |
| Magic | Magic missiles cast | 1.5 | 0.8 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 36% (20 of 55) | 53% (16 of 30) |
| Magic | Wounds caused by magic missiles | 2.6 | 1.3 |
| Magic | Wounds caused by other spells | 1.4 | 0.8 |
| Magic | Points destroyed by magic (all spells) | 48.9 | 37.3 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.9 / 0.7 / 0.8 / 0.1 | 2.1 / 0.4 / 0.6 / 0.2 |
| Combat | Points destroyed in combat | 333.6 | 456.5 |
| Combat | Points run down | 95.2 | 128.2 |
| Combat | Net points per charged fight, damage counted | +74 | +91 |
| Combat | Net per 100 charger points, damage counted | +26.6 | +33.0 |
| Combat | First round won (charged fights) | 63% | 67% |
| Combat | Net points per charged fight | +70 | +93 |
| Combat | Net points per supported fight / lone fight | +163 / +56 | +220 / +72 |
| Combat | Charged fights on a top-3 enemy unit | 40 of 107 | 65 of 150 |
| Game | Points lost | 872.1 | 695.8 |
| Game | VP from objectives | 499.7 | 627.8 |
| Game | Lone holders (player turns) | 2.2 | 2.8 |

- Mine won / drew / lost: 11 / 6 / 19 of 36 ended games (of 36); mean margin (Mine - Opponent) -301 VP
- The side that went first won 19 of 30 games with a winner
- Points traded per game (both sides' losses): 1568
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: fw-h2h2-opp-1eea44e-p2

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.6 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| ALREADY CARRIED | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARRIVAL HUNT | - | - | - | - | 0.1 | +4.3 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.5 | +0.0 | 0.0 | 38.2 | 0.2 | +0.0 | 0.0 | 3.5 |
| BACKUP TARGETS | 0.9 | +5.7 | 0.0 | 1.8 | 1.1 | +13.3 | 0.0 | 30.3 |
| BEST FACING | - | - | - | - | 0.7 | +37.0 | 0.0 | 40.8 |
| BEST FIRST | - | - | - | - | 4.4 | +210.0 | 145.2 | 99.6 |
| BEST OVERALL | 0.2 | +10.3 | 0.0 | 7.4 | 0.7 | +48.4 | 0.0 | 51.7 |
| BEST PREY | 4.2 | +294.3 | 146.2 | 114.8 | 1.0 | +46.8 | 51.4 | 19.0 |
| BEST PRIZE | - | - | - | - | 0.2 | +2.6 | 6.7 | 5.4 |
| BIG CHARACTER SAFETY | 0.2 | -0.2 | 0.0 | 12.3 | 0.0 | -0.3 | 0.0 | 0.0 |
| BLOCKED CHARGE SKIPPED | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 3.8 | 0.0 |
| BLOCKED WHEEL | 0.5 | +5.1 | 0.0 | 11.0 | 0.5 | +3.3 | 0.0 | 0.0 |
| BOMBING RUN | 0.0 | +0.4 | 0.0 | 1.7 | - | - | - | - |
| BOUND ASSAILMENT | 0.1 | +0.0 | 0.0 | 6.9 | - | - | - | - |
| CANNON PLAN MISSED | 0.6 | +0.0 | 52.2 | 11.1 | 0.2 | +0.0 | 11.8 | 0.0 |
| CANNON PLANNED TARGET | 5.2 | +184.2 | 388.9 | 120.3 | 1.6 | +58.7 | 68.6 | 29.6 |
| CANNON SIGHT KEPT | 1.3 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT COUNTER | 0.1 | -0.7 | 5.2 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT SET-UP | 0.1 | +0.0 | 8.6 | 0.0 | 0.3 | -0.8 | 56.2 | 0.0 |
| CAST JOB | 0.7 | +8.7 | 20.9 | 32.4 | 0.2 | +5.5 | 11.0 | 0.0 |
| CASTER AWAY FROM SCREEN | 0.3 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.3 | +17.1 | 10.0 | 8.2 | 0.2 | +8.1 | 7.1 | 0.0 |
| CASTS AFTER FRIENDS | 0.4 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 47.6 |
| CASTS FROM BEHIND | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.0 | +1.0 | 0.0 | 0.0 | - | - | - | - |
| CHAFF PASSED | 0.3 | -0.0 | 0.0 | 10.1 | 0.2 | -0.2 | 3.1 | 3.1 |
| CHAMPION TAKES THE CHALLENGE | 0.0 | +0.1 | 2.1 | 0.0 | - | - | - | - |
| CHARGE NOW FIRST | - | - | - | - | 3.5 | +0.0 | 373.2 | 81.8 |
| CHARGE NOW WEIGHED | 0.7 | -31.6 | 19.6 | 24.0 | 0.5 | -62.8 | 21.3 | 26.1 |
| CHARIOT NO STATIC JOB | 0.5 | +0.0 | 10.4 | 14.2 | - | - | - | - |
| CHARIOT WIZARD CAREFUL | - | - | - | - | 0.0 | -0.1 | 0.0 | 0.0 |
| CHEAP HELPER | 0.1 | +0.0 | 0.0 | 1.4 | 0.3 | +0.0 | 35.9 | 0.0 |
| COMBAT PIVOT | 0.6 | +0.0 | 43.6 | 68.9 | 0.6 | +0.0 | 58.1 | 73.1 |
| CONVEYANCE SEARCH | 0.3 | +41.5 | 0.0 | 0.0 | 0.6 | +93.0 | 17.8 | 52.8 |
| COUNTER-CHARGE COVER | 9.1 | +736.8 | 0.0 | 198.9 | 8.0 | +740.7 | 0.0 | 195.1 |
| DEFENSIVE ARMY | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |
| DEFENSIVE FLOOR | - | - | - | - | 0.0 | +0.2 | 0.0 | 3.5 |
| EDGE GIVE GROUND | 0.1 | +5.8 | 3.2 | 9.1 | 0.4 | +22.8 | 51.1 | 0.0 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 1.2 | +105.8 | 0.0 | 10.5 | 1.6 | +144.5 | 0.0 | 54.8 |
| FALLBACK BY WORTH | 6.5 | +75.3 | 0.0 | 94.4 | 6.6 | +74.0 | 0.0 | 60.9 |
| FIGHT LIFT | 0.1 | +1.5 | 0.0 | 0.0 | 0.1 | +2.1 | 0.0 | 0.0 |
| FIRE AND FLEE | 0.1 | +2.3 | 0.0 | 0.0 | 0.1 | +0.4 | 0.0 | 0.0 |
| FLANK NOT WEIGHED | 7.2 | +0.0 | 0.0 | 238.2 | 5.4 | +0.0 | 0.0 | 140.1 |
| FOLLOW UP WEIGHED | 1.1 | +168.3 | 0.0 | 58.5 | 1.4 | +179.7 | 0.0 | 22.9 |
| FRIENDS SHOTS CHECKED | 0.3 | +20.0 | 0.0 | 8.6 | 0.2 | +14.0 | 0.0 | 8.3 |
| GIVES UP | 0.9 | -32.4 | 106.0 | 24.0 | 0.2 | -4.4 | 24.5 | 5.4 |
| GIVES UP ITS SCREEN | 0.6 | -13.5 | 38.7 | 12.1 | 0.1 | -0.4 | 0.0 | 0.8 |
| GROUND FLIERS | 0.1 | +0.6 | 0.0 | 0.0 | - | - | - | - |
| HELPER ALREADY ASKED | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 19.4 | 0.0 |
| HELPER UNSEEN | 0.2 | +0.0 | 20.2 | 0.0 | 0.3 | +0.0 | 17.0 | 1.4 |
| HILL BY ITS CHANCE | - | - | - | - | 0.6 | -48.1 | 0.0 | 2.1 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HORN WORTH | - | - | - | - | 0.0 | +0.7 | 0.0 | 0.0 |
| HUNT ADVANCE | 0.1 | +2.1 | 0.0 | 3.8 | 0.3 | +2.0 | 11.1 | 6.2 |
| HUNT DROPPED | 0.1 | +0.0 | 0.0 | 2.4 | 0.2 | +0.0 | 24.2 | 2.4 |
| HUNT IN PAIRS | 0.6 | +52.1 | 0.0 | 9.4 | 0.6 | +23.2 | 0.0 | 17.4 |
| HUNT KEPT | - | - | - | - | 0.2 | +3.5 | 9.2 | 1.9 |
| HUNT RESULT | 0.1 | +5.4 | 0.0 | 2.4 | 0.4 | +56.4 | 24.2 | 3.3 |
| HUNT THE GUNS | 0.1 | +36.0 | 5.3 | 3.8 | 0.4 | +142.5 | 44.0 | 4.3 |
| INVITES THE FIGHT | - | - | - | - | 0.9 | +19.1 | 66.6 | 25.5 |
| JOINT CHARGE PLAN | 0.0 | +0.5 | 5.2 | 0.0 | 0.2 | +18.1 | 27.1 | 13.7 |
| KEEP FALLS | 0.1 | +0.6 | 0.0 | 0.0 | - | - | - | - |
| KEEPS ITS PREY | 0.3 | +1.9 | 5.5 | 7.1 | 0.1 | +0.4 | 0.0 | 11.6 |
| KEEPS ITS TARGET | 1.7 | +50.0 | 130.0 | 49.2 | 2.6 | +77.5 | 236.2 | 33.4 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| KILLS COUNT | 1.8 | +92.6 | 144.6 | 32.9 | 2.8 | +132.3 | 232.0 | 36.9 |
| KILLS COUNT NEXT TURN | 7.5 | +257.2 | 323.1 | 195.3 | 7.7 | +306.1 | 363.8 | 177.7 |
| LONE CHARACTER SAFE SPOT | 0.4 | +19.5 | 23.1 | 3.1 | 0.2 | +1.8 | 13.2 | 7.9 |
| LONE WIZARD HOLDS BACK | 0.1 | +0.0 | 11.4 | 0.0 | 0.5 | +0.0 | 1.7 | 10.6 |
| LONE WIZARD KEPT IN | 0.6 | +39.4 | 0.0 | 0.0 | 0.3 | +23.5 | 0.0 | 0.0 |
| LONG SHOT | - | - | - | - | 0.6 | +0.3 | 27.6 | 1.5 |
| LOST CHARGE | - | - | - | - | 2.1 | -44.8 | 77.8 | 52.2 |
| LURE BY WHAT IT DRAWS | - | - | - | - | 0.1 | -7.0 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 0.4 | +17.7 | 10.5 | 4.6 | 0.9 | +128.8 | 43.3 | 28.7 |
| MANOEUVRE | 0.1 | +0.9 | 0.0 | 2.1 | 0.2 | +5.9 | 0.0 | 5.7 |
| MARCH AT ESCAPER | - | - | - | - | 0.0 | +0.1 | 0.0 | 0.0 |
| MARCH CHECK | 0.6 | +30.4 | 0.0 | 0.0 | 0.3 | +7.0 | 0.0 | 0.0 |
| MARCH ODDS | 0.8 | +63.1 | 48.6 | 10.2 | 0.1 | +10.4 | 0.0 | 10.5 |
| MARCH OVER CASTS | 0.6 | +46.4 | 0.0 | 18.3 | 0.2 | +38.6 | 0.0 | 4.4 |
| MAX FOR POSITIONING | 5.0 | +184.5 | 0.0 | 134.1 | 5.2 | +184.8 | 0.0 | 146.4 |
| MISSILES IN THE MOVE | 3.2 | +79.5 | 0.0 | 88.9 | 2.8 | +50.4 | 0.0 | 63.1 |
| MISSILES NEXT TURN | 4.2 | +63.9 | 0.0 | 118.3 | 3.3 | +41.3 | 0.0 | 67.5 |
| MODEL FACING | 0.2 | +67.5 | 0.0 | 1.7 | 0.4 | +86.5 | 0.0 | 5.0 |
| MONSTER WIZARD ROAMS | 0.3 | +0.0 | 22.6 | 0.0 | 0.2 | +0.0 | 43.1 | 0.0 |
| MOVE AND CAST | 0.2 | +9.2 | 0.0 | 15.0 | 0.2 | +4.2 | 0.0 | 0.0 |
| MOVE SPELL IN RANGE | 0.2 | +7.3 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL NOT WORTH | - | - | - | - | 0.0 | -0.0 | 0.0 | 0.0 |
| MOVE SPELL OUT OF RANGE | 0.4 | -15.3 | 0.0 | 0.0 | 0.1 | -7.6 | 1.1 | 0.0 |
| MOVE SPELL SPOT | 0.2 | +0.0 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE | - | - | - | - | 5.1 | +336.6 | 243.0 | 136.7 |
| MOVES UNITS SPELL | 0.1 | +3.4 | 0.0 | 0.0 | - | - | - | - |
| NEEDED THERE | 0.1 | +4.8 | 3.5 | 0.0 | 0.3 | +25.9 | 23.6 | 0.0 |
| NO RALLY LEFT | 0.1 | +5.5 | 0.0 | 0.0 | 0.1 | +1.8 | 0.0 | 0.0 |
| NOT NEEDED | 0.2 | -17.8 | 20.6 | 0.0 | 0.6 | -30.6 | 74.4 | 5.3 |
| NOT TURNED | 7.5 | +130.1 | 0.0 | 192.8 | 5.9 | +107.5 | 0.0 | 116.4 |
| NOT WORTH A CAST | 0.5 | -0.3 | 0.0 | 0.0 | 0.5 | -0.4 | 0.0 | 0.0 |
| OFF BEST | 18.1 | -929.6 | 22.2 | 398.4 | 15.9 | -849.2 | 42.9 | 280.3 |
| OPENS A LANE | 0.1 | +0.2 | 0.0 | 0.0 | 0.1 | +1.2 | 6.4 | 3.5 |
| OPENS UP | 0.0 | +1.9 | 2.1 | 0.0 | 0.2 | +23.8 | 6.1 | 21.1 |
| OVERRUN THREAT | 0.0 | +1.0 | 0.0 | 0.0 | - | - | - | - |
| OVERRUNS AWAY | 0.5 | +6.5 | 44.0 | 9.4 | 0.8 | +15.5 | 64.2 | 14.6 |
| PATHS CROSS | 1.8 | +118.0 | 0.0 | 38.4 | 2.5 | +215.0 | 0.0 | 48.6 |
| PERIAPT WORTH | - | - | - | - | 0.0 | +1.6 | 0.0 | 15.0 |
| PIVOT GUARDS FLANK | 0.1 | -0.7 | 0.0 | 0.0 | 0.2 | -1.3 | 0.0 | 7.1 |
| PLAN RESULT | 35.7 | +1196.5 | 1339.0 | 1147.5 | 42.2 | +1443.1 | 1494.0 | 944.4 |
| PURSUES BIG PREY | 0.1 | -4.6 | 0.0 | 10.2 | 0.1 | -6.2 | 0.0 | 0.0 |
| PURSUES ON | 0.0 | +0.5 | 0.0 | 0.0 | - | - | - | - |
| RAIDS THE BAGGAGE NEXT TURN | 0.1 | +7.4 | 0.0 | 0.0 | 0.1 | +9.0 | 0.0 | 0.0 |
| RANDOM MOVE BY FIGURES | - | - | - | - | 1.3 | +15.2 | 0.0 | 36.1 |
| RANDOM MOVER NO PROMISE | - | - | - | - | 0.2 | -21.3 | 12.8 | 4.7 |
| REDIRECT BY WHAT IT STOPS | - | - | - | - | 0.2 | -7.4 | 0.0 | 0.0 |
| REDIRECT COUNTER | 3.2 | +208.2 | 0.0 | 59.6 | 3.8 | +287.0 | 0.0 | 33.4 |
| REDIRECT WEIGHED | 0.1 | +0.0 | 0.0 | 0.0 | 0.5 | +25.9 | 14.6 | 10.6 |
| RESERVE FALL BACK | - | - | - | - | 1.1 | +30.8 | 0.0 | 20.4 |
| RESTRAINS TO SHOOT | 0.1 | +4.8 | 0.0 | 0.0 | 0.1 | +3.1 | 0.0 | 0.0 |
| RISK BY ARC | 2.2 | +69.0 | 178.2 | 65.6 | 4.1 | +80.9 | 407.8 | 69.4 |
| SAFE SURE CHARGE | 0.0 | -1.4 | 0.0 | 0.0 | - | - | - | - |
| SAFER THAN THE JOB | 0.6 | +24.8 | 0.0 | 22.5 | 1.0 | +65.8 | 0.0 | 72.9 |
| SCOUT SPOT | 0.3 | +0.9 | 0.0 | 0.0 | 0.5 | +2.1 | 0.0 | 1.8 |
| SCOUT WAITS | 0.3 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 1.8 |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 0.3 | -16.2 | 0.0 | 0.8 |
| SEARCH SPOT | 2.0 | +115.6 | 0.0 | 27.3 | 3.2 | +176.6 | 0.0 | 31.5 |
| SECOND HUNTER | 0.0 | -0.0 | 0.0 | 0.9 | 0.1 | -0.8 | 13.8 | 0.0 |
| SELF MOVE SPELL | 0.3 | +2.7 | 0.0 | 9.1 | - | - | - | - |
| SET UP TOGETHER | 0.7 | +23.6 | 28.3 | 6.9 | 1.8 | +192.7 | 75.4 | 57.1 |
| SET-UP ANY TARGET | 0.2 | +27.2 | 0.0 | 0.0 | 0.2 | +17.6 | 6.6 | 26.5 |
| SET-UP MISSED | - | - | - | - | 0.0 | +15.3 | 0.0 | 7.6 |
| SHOOTER COUNTED ONCE | - | - | - | - | 0.0 | -0.1 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.4 | +0.8 | 0.0 | 0.0 | 0.3 | +0.6 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | - | - | - | - | 0.7 | +29.9 | 28.9 | 7.5 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| SHOT REPLANNED | 0.4 | +0.0 | 82.2 | 11.1 | 0.6 | +0.0 | 67.2 | 1.7 |
| SHOTS IN THE MOVE | 13.1 | +636.6 | 0.0 | 247.0 | 11.0 | +330.9 | 0.0 | 183.9 |
| SPELL CATCH ODDS | 0.1 | -2.1 | 0.0 | 0.0 | - | - | - | - |
| SPELL SETS UP CHARGE | 0.2 | +41.2 | 0.0 | 0.0 | 0.3 | +47.5 | 6.6 | 34.1 |
| SPELL WORTH | 0.7 | +16.7 | 55.6 | 55.6 | 2.0 | +40.0 | 88.1 | 85.9 |
| STABLE ROLE | - | - | - | - | 12.2 | +0.0 | 474.9 | 120.9 |
| STANDS TO CAST | 0.0 | +0.9 | 0.0 | 0.0 | 0.0 | +2.9 | 0.0 | 0.0 |
| STAY WEIGHED | - | - | - | - | 0.0 | +2.2 | 0.0 | 0.0 |
| STOPS | 0.0 | +0.0 | 5.3 | 0.0 | 0.2 | +13.5 | 42.1 | 0.0 |
| STOPS SHORT OF THE FLANK | 0.5 | +24.8 | 0.0 | 37.0 | 0.2 | +7.9 | 0.0 | 13.9 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 4.7 | 0.1 | +0.0 | 0.0 | 4.0 |
| SUPPORT JOB KEPT | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |
| SUPPORT NARROWED | - | - | - | - | 7.9 | -54.6 | 443.3 | 78.0 |
| SUPPORTS | - | - | - | - | 4.5 | +55.9 | 143.8 | 36.5 |
| SURE CHARGE BEATS ADVANCE | 0.2 | -13.7 | 19.0 | 7.2 | 0.1 | -7.5 | 10.3 | 0.0 |
| SURE REACH TOGETHER | 0.5 | +0.3 | 17.0 | 12.6 | 0.7 | -9.6 | 0.0 | 6.3 |
| THROUGH LINE OF FIRE | 0.4 | +20.0 | 0.0 | 10.9 | 0.2 | +15.7 | 0.0 | 3.5 |
| TURN WORTH | 0.2 | -19.0 | 28.6 | 0.0 | 0.2 | -25.5 | 28.0 | 0.0 |
| TWO OR MORE ARRIVE | 0.1 | +0.2 | 6.5 | 2.4 | 0.3 | +1.6 | 60.4 | 0.8 |
| WAIT AFTER COSTS | - | - | - | - | 8.4 | -414.1 | 396.3 | 183.5 |
| WALKS TO THE FIGHT | - | - | - | - | 1.6 | +29.2 | 31.4 | 27.8 |
| WAR ENGINE CHARGES | - | - | - | - | 0.1 | +17.0 | 4.0 | 0.0 |
| WAR ENGINE JOBS | - | - | - | - | 0.3 | +0.0 | 3.4 | 15.4 |
| WEARS DOWN | 0.9 | +44.5 | 94.9 | 51.8 | 2.1 | +57.2 | 241.8 | 53.3 |
| WHO HITS BACK | 0.2 | +40.7 | 0.0 | 2.7 | 0.2 | +5.0 | 0.0 | 15.0 |
| WHOLE FIGHT | 0.5 | +17.4 | 50.2 | 14.9 | 0.5 | +0.1 | 89.2 | 1.4 |
| WHOLE FIGHT GAIN | 0.3 | +30.1 | 41.8 | 9.1 | 0.8 | +69.2 | 82.5 | 7.5 |
| WOUNDED STAYS OUT | - | - | - | - | 0.1 | +0.0 | 2.1 | 13.7 |

### Rule changes: fw-h2h2-opp-1eea44e-p2

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 1224 | 1224 | 1224 | 34.00 | -64037 | -52.3 |
| SEARCH SPOT | 187 | 187 | 186 | 5.17 | +10519 | +56.6 |
| BEST FIRST | 158 | 158 | 158 | 4.39 | +7562 | +47.9 |
| PATHS CROSS | 156 | 156 | 156 | 4.33 | +11989 | +76.9 |
| KILLS COUNT NEXT TURN | 547 | 542 | 153 | 4.25 | +4495 | +29.4 |
| COUNTER-CHARGE COVER | 616 | 313 | 128 | 3.56 | +8486 | +66.3 |
| FALLBACK BY WORTH | 471 | 471 | 108 | 3.00 | +5375 | +49.8 |
| FACES THE THREAT | 99 | 99 | 99 | 2.75 | +9009 | +91.0 |
| BEST PREY | 188 | 182 | 98 | 2.72 | +3302 | +33.7 |
| FOLLOW UP WEIGHED | 91 | 91 | 91 | 2.53 | +12528 | +137.7 |
| MOVE TO CHARGE | 182 | 182 | 83 | 2.31 | +3711 | +44.7 |
| SHOTS IN THE MOVE | 867 | 557 | 79 | 2.19 | +2082 | +26.3 |
| CANNON SIGHT KEPT | 70 | 70 | 70 | 1.94 | +0 | +0.0 |
| ARTILLERY RE-ROLL WEIGHED | 62 | 62 | 62 | 1.72 | +0 | +0.0 |
| SUPPORTS | 163 | 163 | 60 | 1.67 | +550 | +9.2 |
| SAFER THAN THE JOB | 55 | 55 | 55 | 1.53 | +3259 | +59.3 |
| WAIT AFTER COSTS | 304 | 304 | 49 | 1.36 | +1092 | +22.3 |
| COMBAT PIVOT | 44 | 44 | 44 | 1.22 | +0 | +0.0 |
| RISK BY ARC | 227 | 215 | 44 | 1.22 | +1951 | +44.3 |
| ADVANCE LANE KEPT | 43 | 43 | 43 | 1.19 | +0 | +0.0 |
| CANNON PLANNED TARGET | 243 | 243 | 42 | 1.17 | -337 | -8.0 |
| CHARGE NOW WEIGHED | 42 | 42 | 42 | 1.17 | +2380 | +56.7 |
| REDIRECT COUNTER | 254 | 117 | 42 | 1.17 | +3123 | +74.4 |
| RESERVE FALL BACK | 41 | 41 | 41 | 1.14 | +1107 | +27.0 |
| HOLDS AMBUSHERS | 40 | 40 | 40 | 1.11 | +0 | +0.0 |
| BLOCKED WHEEL | 37 | 37 | 37 | 1.03 | +304 | +8.2 |
| MAX FOR POSITIONING | 365 | 181 | 37 | 1.03 | +384 | +10.4 |
| SHOT REPLANNED | 36 | 36 | 36 | 1.00 | +0 | +0.0 |
| BEST OVERALL | 33 | 33 | 33 | 0.92 | +2114 | +64.1 |
| LONE WIZARD KEPT IN | 33 | 33 | 33 | 0.92 | +2266 | +68.7 |
| SET UP TOGETHER | 89 | 64 | 33 | 0.92 | +2181 | +66.1 |
| KILLS COUNT | 163 | 155 | 32 | 0.89 | +817 | +25.5 |
| SCOUT WAITS | 32 | 32 | 32 | 0.89 | +0 | +0.0 |
| KEEPS ITS TARGET | 153 | 151 | 31 | 0.86 | +552 | +17.8 |
| WALKS TO THE FIGHT | 57 | 57 | 31 | 0.86 | +293 | +9.5 |
| MARCH ODDS | 32 | 32 | 30 | 0.83 | +688 | +22.9 |
| MARCH CHECK | 30 | 30 | 29 | 0.81 | +2131 | +73.5 |
| RANDOM MOVE BY FIGURES | 47 | 47 | 28 | 0.78 | +546 | +19.5 |
| BEST FACING | 25 | 25 | 25 | 0.69 | +1332 | +53.3 |
| CHARGE NOW FIRST | 125 | 125 | 25 | 0.69 | -1436 | -57.4 |
| SHOOTERS IN TWO RANKS | 25 | 25 | 25 | 0.69 | +50 | +2.0 |
| STOPS SHORT OF THE FLANK | 25 | 25 | 25 | 0.69 | +1177 | +47.1 |
| MODEL FACING | 22 | 22 | 22 | 0.61 | +5546 | +252.1 |
| REDIRECT WEIGHED | 22 | 22 | 22 | 0.61 | +1263 | +57.4 |
| THROUGH LINE OF FIRE | 21 | 21 | 21 | 0.58 | +1287 | +61.3 |
| WHOLE FIGHT GAIN | 41 | 35 | 21 | 0.58 | +990 | +47.2 |
| CHAFF PASSED | 19 | 19 | 19 | 0.53 | -9 | -0.5 |
| FRIENDS SHOTS CHECKED | 19 | 19 | 19 | 0.53 | +1223 | +64.3 |
| MISSILES IN THE MOVE | 214 | 135 | 18 | 0.50 | +411 | +22.8 |
| WEARS DOWN | 107 | 103 | 17 | 0.47 | +598 | +35.2 |
| CASTER AWAY FROM SCREEN | 15 | 15 | 15 | 0.42 | +0 | +0.0 |
| CASTS FROM BEHIND | 15 | 15 | 15 | 0.42 | +0 | +0.0 |
| MAKE SURE TOGETHER | 46 | 30 | 14 | 0.39 | +872 | +62.3 |
| SHORT GUN FORWARD | 14 | 14 | 14 | 0.39 | +0 | +0.0 |
| WHO HITS BACK | 14 | 14 | 14 | 0.39 | +1366 | +97.6 |
| CASTING BLOCK | 17 | 17 | 13 | 0.36 | +402 | +31.0 |
| HUNT IN PAIRS | 42 | 30 | 13 | 0.36 | +912 | +70.1 |
| MOVE AND CAST | 13 | 13 | 13 | 0.36 | +484 | +37.2 |
| CHARIOT NO STATIC JOB | 18 | 18 | 12 | 0.33 | -1558 | -129.9 |
| SURE CHARGE BEATS ADVANCE | 12 | 12 | 12 | 0.33 | -764 | -63.6 |
| CAST JOB | 33 | 32 | 11 | 0.31 | +110 | +10.0 |
| NEEDED THERE | 13 | 13 | 11 | 0.31 | +0 | +0.0 |
| PURSUES BIG PREY | 9 | 9 | 9 | 0.25 | -388 | -43.1 |
| STUCK PIVOT | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| OVERRUNS AWAY | 48 | 44 | 8 | 0.22 | +109 | +13.6 |
| PIVOT GUARDS FLANK | 8 | 8 | 8 | 0.22 | -75 | -9.4 |
| SHOOTS FROM THE BEST SPOT | 24 | 24 | 8 | 0.22 | +281 | +35.2 |
| BIG CHARACTER SAFETY | 7 | 7 | 7 | 0.19 | -18 | -2.5 |
| INVITES THE FIGHT | 34 | 34 | 7 | 0.19 | +79 | +11.3 |
| RAIDS THE BAGGAGE NEXT TURN | 7 | 7 | 7 | 0.19 | +219 | +31.3 |
| BEST PRIZE | 6 | 6 | 6 | 0.17 | -263 | -43.9 |
| MANOEUVRE | 8 | 8 | 6 | 0.17 | +245 | +40.9 |
| OPENS UP | 9 | 9 | 6 | 0.17 | +279 | +46.6 |
| RESTRAINS TO SHOOT | 6 | 6 | 6 | 0.17 | +281 | +46.9 |
| WHOLE FIGHT | 35 | 33 | 6 | 0.17 | +250 | +41.7 |
| LOST CHARGE | 75 | 75 | 5 | 0.14 | +71 | +14.2 |
| WAR ENGINE JOBS | 10 | 10 | 5 | 0.14 | -101 | -20.3 |
| BLOCKED CHARGE SKIPPED | 4 | 4 | 4 | 0.11 | +0 | +0.0 |
| FIRE AND FLEE | 4 | 4 | 4 | 0.11 | +96 | +24.1 |
| KEEPS SCOUTS OR AMBUSH | 4 | 4 | 4 | 0.11 | +0 | +0.0 |
| LONE WIZARD HOLDS BACK | 22 | 22 | 4 | 0.11 | -20 | -5.0 |
| MOVES UNITS SPELL | 4 | 4 | 4 | 0.11 | +122 | +30.4 |
| NO RALLY LEFT | 4 | 4 | 4 | 0.11 | +121 | +30.3 |
| WAR ENGINE CHARGES | 5 | 5 | 4 | 0.11 | +127 | +31.8 |
| BOUND ASSAILMENT | 3 | 3 | 3 | 0.08 | +0 | +0.2 |
| CARRIES OUT SET-UP | 12 | 12 | 3 | 0.08 | -30 | -9.9 |
| EDGE GIVE GROUND | 19 | 19 | 3 | 0.08 | +70 | +23.4 |
| HUNT ADVANCE | 15 | 15 | 3 | 0.08 | +70 | +23.2 |
| BACKUP TARGETS | 70 | 28 | 2 | 0.06 | +7 | +3.5 |
| KEEP FALLS | 2 | 2 | 2 | 0.06 | +42 | +21.2 |
| MOVE SPELL IN RANGE | 6 | 5 | 2 | 0.06 | +26 | +12.8 |
| STANDS TO CAST | 2 | 2 | 2 | 0.06 | -23 | -11.4 |
| SUPPORT NARROWED | 285 | 285 | 2 | 0.06 | -2 | -0.9 |
| SURE REACH TOGETHER | 41 | 28 | 2 | 0.06 | +21 | +10.7 |
| BOMBING RUN | 1 | 1 | 1 | 0.03 | +13 | +13.1 |
| CARRIES OUT COUNTER | 3 | 3 | 1 | 0.03 | -25 | -24.8 |
| DEFENSIVE ARMY | 1 | 1 | 1 | 0.03 | -118 | -117.5 |
| HORN WORTH | 1 | 1 | 1 | 0.03 | +25 | +25.4 |
| JOINT CHARGE PLAN | 9 | 9 | 1 | 0.03 | +62 | +62.3 |
| MISSILES NEXT TURN | 271 | 157 | 1 | 0.03 | +0 | +0.0 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.03 | +56 | +56.3 |
| PURSUES ON | 1 | 1 | 1 | 0.03 | +18 | +18.0 |
| SAFE SURE CHARGE | 1 | 1 | 1 | 0.03 | -67 | -67.1 |
| SCREEN BY WHAT IT SAVES | 11 | 11 | 1 | 0.03 | +15 | +15.1 |
| STAY WEIGHED | 1 | 1 | 1 | 0.03 | +81 | +80.6 |
| STOPS | 9 | 9 | 1 | 0.03 | +38 | +38.2 |
| SUPPORT JOB KEPT | 1 | 1 | 1 | 0.03 | +46 | +45.8 |
| TURN WORTH | 17 | 16 | 1 | 0.03 | +2 | +2.1 |
| ALREADY CARRIED | 1 | not checked | - | - | - | - |
| ARRIVAL HUNT | 2 | 2 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 27 | 27 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 29 | trace | - | - | - | - |
| CATCH FLIERS | 1 | not checked | - | - | - | - |
| CHAMPION TAKES THE CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| CHARIOT WIZARD CAREFUL | 1 | 1 | 0 | 0.00 | - | - |
| CHEAP HELPER | 12 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 31 | not checked | - | - | - | - |
| DEFENSIVE FLOOR | 1 | 1 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT LIFT | 7 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 454 | not checked | - | - | - | - |
| GIVES UP | 38 | 35 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 25 | 24 | 0 | 0.00 | - | - |
| GROUND FLIERS | 2 | not checked | - | - | - | - |
| HELPER ALREADY ASKED | 6 | not checked | - | - | - | - |
| HELPER UNSEEN | 17 | 16 | 0 | 0.00 | - | - |
| HILL BY ITS CHANCE | 22 | 22 | 0 | 0.00 | - | - |
| HUNT DROPPED | 10 | trace | - | - | - | - |
| HUNT KEPT | 6 | trace | - | - | - | - |
| HUNT RESULT | 18 | trace | - | - | - | - |
| HUNT THE GUNS | 20 | trace | - | - | - | - |
| KEEPS ITS PREY | 14 | 13 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 23 | not checked | - | - | - | - |
| LONG SHOT | 20 | 20 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 3 | 3 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 30 | 30 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 19 | 19 | 0 | 0.00 | - | - |
| MOVE SPELL NOT WORTH | 1 | not checked | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 20 | trace | - | - | - | - |
| MOVE SPELL SPOT | 10 | not checked | - | - | - | - |
| NOT NEEDED | 27 | 26 | 0 | 0.00 | - | - |
| NOT TURNED | 482 | 482 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 36 | not checked | - | - | - | - |
| OPENS A LANE | 6 | 6 | 0 | 0.00 | - | - |
| OVERRUN THREAT | 1 | not checked | - | - | - | - |
| PLAN RESULT | 2803 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 8 | 8 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 8 | 8 | 0 | 0.00 | - | - |
| SCOUT SPOT | 28 | 28 | 0 | 0.00 | - | - |
| SECOND HUNTER | 6 | 6 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 10 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 13 | not checked | - | - | - | - |
| SET-UP MISSED | 1 | trace | - | - | - | - |
| SHOOTER COUNTED ONCE | 1 | 1 | 0 | 0.00 | - | - |
| SPELL CATCH ODDS | 2 | not checked | - | - | - | - |
| SPELL SETS UP CHARGE | 18 | not checked | - | - | - | - |
| SPELL WORTH | 96 | not checked | - | - | - | - |
| STABLE ROLE | 438 | 435 | 0 | 0.00 | - | - |
| TWO OR MORE ARRIVE | 14 | 13 | 0 | 0.00 | - | - |
| WOUNDED STAYS OUT | 3 | 3 | 0 | 0.00 | - | - |

### Off best figure: fw-h2h2-opp-1eea44e-p2

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 15.53 | 13.67 | 53.9 |
| FALLBACK | gate | 1.03 | 1.17 | 46.0 |
| RULE SWITCHED OFF | gate | 0.92 | - | 14.0 |
| TURN GATE | gate | 0.25 | 0.56 | 43.2 |
| CHARGE NOW FIRST | rule | - | 0.67 | 59.8 |
| CHARGE NOW WEIGHED | rule | 0.25 | 0.14 | 61.9 |
| CANNON PLANNED TARGET | rule | 0.28 | 0.08 | 29.9 |
| CHARIOT NO STATIC JOB | rule | 0.33 | - | 129.9 |
| SUPPORT REQUEST | gate | 0.11 | 0.22 | 122.5 |
| SURE CHARGE BEATS ADVANCE | rule | 0.22 | 0.11 | 63.6 |
| PATHS CROSS | rule | 0.25 | - | 41.6 |
| PURSUES BIG PREY | rule | 0.11 | 0.14 | 43.1 |
| BLOCKED WHEEL | rule | 0.17 | 0.06 | 67.9 |
| PIVOT GUARDS FLANK | rule | 0.06 | 0.17 | 9.4 |
| BEST PRIZE | rule | - | 0.17 | 43.9 |
| FIGHT ORDER BAND | gate | 0.06 | 0.11 | 2.3 |
| LONE CHARACTER SAFE SPOT | gate | 0.08 | 0.08 | 72.6 |
| AFTERMATH BAND | gate | 0.06 | 0.06 | 0.9 |
| WAR ENGINE JOBS | rule | - | 0.11 | 25.2 |
| BIG CHARACTER SAFETY | rule | 0.06 | 0.03 | 12.8 |
| CARRIES OUT SET-UP | rule | - | 0.08 | 9.9 |
| CHAFF PASSED | rule | 0.03 | 0.06 | 3.0 |
| LONE WIZARD HOLDS BACK | rule | 0.03 | 0.06 | 6.6 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.03 | 0.03 | 29.9 |
| FALLBACK BY WORTH | rule | - | 0.06 | 40.2 |
| NO REASON | gate | - | 0.06 | 11.5 |
| REDIRECT WEIGHED | rule | - | 0.06 | 50.7 |
| THROUGH LINE OF FIRE | rule | 0.06 | - | 10.8 |
| CARRIES OUT COUNTER | rule | 0.03 | - | 24.8 |
| DEFENSIVE ARMY | rule | - | 0.03 | 117.5 |
| FACES THE THREAT | rule | 0.03 | - | 18.4 |
| SAFE SURE CHARGE | rule | 0.03 | - | 67.1 |
| SAFER THAN THE JOB | rule | - | 0.03 | 11.2 |
| STANDS TO CAST | rule | - | 0.03 | 33.0 |
| STOPS SHORT OF THE FLANK | rule | 0.03 | - | 8.9 |
| SUPPORT NARROWED | rule | - | 0.03 | 1.3 |

### Plans: fw-h2h2-opp-1eea44e-p2

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 11.7 | 18% | 527 | 272 | 52% |
| Mine | charge | 2.9 | 53% | 339 | 228 | 67% |
| Mine | close in | 4.2 | 21% | 249 | 153 | 61% |
| Mine | hold | 4.1 | 41% | 299 | 0 | 0% |
| Mine | join | 0.7 | 92% | 16 | 0 | 0% |
| Mine | shoot | 7.4 | 59% | 254 | 544 | 214% |
| Mine | support | 4.6 | 87% | 277 | 0 | 0% |
| Opponent | advance | 14.2 | 17% | 441 | 375 | 85% |
| Opponent | charge | 5.9 | 58% | 687 | 580 | 84% |
| Opponent | close in | 6.4 | 32% | 536 | 189 | 35% |
| Opponent | hold | 4.5 | 47% | 320 | 0 | 0% |
| Opponent | join | 1.2 | 96% | 49 | 0 | 0% |
| Opponent | shoot | 5.0 | 58% | 185 | 300 | 162% |
| Opponent | support | 4.9 | 95% | 39 | 0 | 0% |

### Packages: hunt the guns, fw-h2h2-opp-1eea44e-p2

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.1 | 5 | 0 | 20% | 20% | 0% | 2.0 | 259 | 39 | 20% | 27 |
| Opponent | 0.4 | 15 | 2 | 38% | 38% | 0% | 2.4 | 380 | 156 | 38% | 96 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.5 | 2 | 0 | 0% | 0% | 0% | - | 355 | 0 | 0% | 34 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 105 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 28 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 36 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 63 |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 414 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Ogre Kingdoms | 1.8 | 7 | 0 | 71% | 71% | 0% | 2.4 | 423 | 290 | 71% | 151 |
| Orc & Goblin Tribes | 1.0 | 1 | 0 | 100% | 100% | 0% | 2.0 | 196 | 195 | 100% | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 63 |
| Tomb Kings of Khemri | 1.4 | 7 | 2 | 0% | 0% | 0% | - | 256 | 0 | 0% | 0 |
| Vampire Counts | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 5 |
| Warriors of Chaos | 0.2 | 2 | 0 | 0% | 0% | 0% | - | 339 | 0 | 0% | 139 |
| Wood Elf Realms | 0.1 | 1 | 0 | 0% | 0% | 0% | - | 410 | 0 | 0% | 20 |

### Battle groups: fw-h2h2-opp-1eea44e-p2

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 9.1 | 24% | 51% | 10% | 25% | 32% | 11% | 15% | 42% | 0% |
| Mine | REDIRECT COUNTER | 3.2 | 30% | 54% | 14% | 20% | 10% | 0% | 13% | 73% | 3% |
| Opponent | COUNTER-CHARGE COVER | 8.0 | 18% | 56% | 15% | 38% | 30% | 14% | 9% | 48% | 0% |
| Opponent | REDIRECT COUNTER | 3.8 | 23% | 66% | 16% | 20% | 26% | 0% | 15% | 59% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: fw-h2h2-opp-1eea44e-p2

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 5 | 0 (5) | 0 | 0 | 49 | 20% | 2.2 | 0 (4) | - | - | 0 (4) | - |
| Mine | Chaff | 38 | 34 (38) | 11 | 24 | 82 | 50% | 1.8 | 56 (20) | 0 (6) | 13 (12) | 45 (25) | 12 (13) |
| Mine | Character | 124 | 49 (124) | 49 | 0 | 42 | 17% | 2.5 | 43 (38) | 63 (55) | 27 (6) | 60 (52) | 44 (47) |
| Mine | Clean-up | 17 | 41 (17) | 4 | 36 | 43 | 35% | 2.9 | 9 (5) | 28 (7) | 111 (5) | 51 (11) | 26 (6) |
| Mine | Fast Hammer | 45 | 44 (45) | 28 | 16 | 52 | 20% | 3.2 | 34 (24) | 63 (9) | 52 (12) | 44 (31) | 43 (14) |
| Mine | Fragile | 5 | 45 (5) | 45 | 0 | 40 | 0% | 1.8 | - | 75 (3) | 0 (2) | 45 (5) | - |
| Mine | Hammer | 58 | 25 (58) | 17 | 8 | 51 | 16% | 2.6 | 18 (16) | 33 (32) | 6 (10) | 18 (38) | 37 (20) |
| Mine | Holder | 29 | 69 (29) | 34 | 35 | 35 | 38% | 3.4 | 65 (8) | 72 (13) | 65 (8) | 74 (17) | 61 (12) |
| Mine | Shooter | 43 | 77 (43) | 27 | 50 | 49 | 2% | 1.5 | 91 (7) | 87 (26) | 39 (10) | 85 (27) | 61 (16) |
| Mine | Support | 2 | 0 (2) | 0 | 0 | 0 | 50% | 5.0 | 0 (1) | 0 (1) | - | - | 0 (2) |
| Mine | War machine | 59 | 48 (59) | 48 | 0 | 55 | 3% | 1.2 | 49 (13) | 35 (36) | 100 (10) | 0 (9) | 56 (50) |
| Mine | Wizard | 21 | 14 (21) | 14 | 0 | 40 | 14% | 2.8 | 7 (7) | 39 (8) | 0 (2) | 0 (5) | 25 (12) |
| Opponent | Blocker | 2 | 0 (2) | 0 | 0 | 100 | 0% | 3.5 | - | 0 (2) | - | 0 (1) | 0 (1) |
| Opponent | Chaff | 86 | 94 (86) | 32 | 62 | 42 | 41% | 2.5 | 105 (34) | 100 (25) | 73 (27) | 93 (61) | 98 (25) |
| Opponent | Character | 94 | 63 (94) | 63 | 0 | 36 | 18% | 2.4 | 73 (42) | 66 (36) | 26 (5) | 68 (57) | 68 (26) |
| Opponent | Clean-up | 12 | 17 (12) | 14 | 3 | 33 | 50% | 2.0 | 17 (7) | 16 (5) | - | 21 (9) | 0 (3) |
| Opponent | Early | 2 | 0 (2) | 0 | 0 | 0 | 50% | 5.0 | - | 0 (2) | - | 0 (1) | 0 (1) |
| Opponent | Fast Hammer | 47 | 42 (47) | 34 | 8 | 42 | 17% | 2.8 | 26 (25) | 51 (12) | 70 (10) | 44 (27) | 39 (20) |
| Opponent | Fragile | 5 | 88 (5) | 88 | 0 | 39 | 20% | 3.8 | 0 (1) | 144 (3) | 0 (1) | 0 (3) | 255 (2) |
| Opponent | Hammer | 69 | 38 (69) | 33 | 5 | 38 | 26% | 2.8 | 15 (15) | 42 (42) | 48 (12) | 54 (42) | 14 (27) |
| Opponent | Holder | 33 | 83 (33) | 21 | 61 | 14 | 30% | 3.7 | 22 (6) | 121 (21) | 0 (4) | 122 (18) | 37 (13) |
| Opponent | Shooter | 34 | 68 (34) | 9 | 58 | 43 | 3% | 1.7 | 53 (8) | 71 (20) | 74 (6) | 92 (23) | 27 (11) |
| Opponent | Support | 3 | 0 (3) | 0 | 0 | 25 | 67% | 3.0 | 0 (1) | 0 (1) | 0 (1) | 0 (1) | 0 (2) |
| Opponent | War machine | 24 | 34 (24) | 34 | 0 | 25 | 12% | 1.6 | 22 (6) | 43 (14) | 23 (4) | 85 (3) | 27 (21) |
| Opponent | Wizard | 29 | 36 (29) | 36 | 0 | 45 | 10% | 1.5 | 5 (10) | 117 (7) | 9 (7) | 86 (9) | 6 (15) |

### Charged fights: fw-h2h2-opp-1eea44e-p2

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 67 | 160 | 0.5 | 1.0 | 320 | 0 | +320 | 2 of 2 | 2 of 2 | - | +320 |
| Mine | Chaos Dwarfs | 4 | 287 | 453 | 3.2 | 1.2 | 139 | 21 | +118 | 8 of 13 | 7 of 13 | +52 | +130 |
| Mine | Dwarfen Mountain Holds | 4 | 652 | 0 | 1.2 | 1.4 | 0 | 63 | -63 | 3 of 5 | 2 of 5 | +0 | -104 |
| Mine | Empire of Man | 5 | 151 | 219 | 2.4 | 1.0 | 91 | 141 | -50 | 9 of 12 | 3 of 12 | - | -50 |
| Mine | Grand Cathay | 4 | 131 | 426 | 2.8 | 1.3 | 155 | 14 | +141 | 4 of 11 | 9 of 11 | +379 | +88 |
| Mine | High Elf Realms | 4 | 82 | 551 | 3.8 | 1.1 | 147 | 8 | +139 | 4 of 15 | 14 of 15 | +185 | +136 |
| Mine | Kingdom of Bretonnia | 1 | 0 | 1371 | 5.0 | 1.2 | 274 | 94 | +180 | 2 of 5 | 4 of 5 | +205 | +174 |
| Mine | Lizardmen | 1 | 0 | 75 | 4.0 | 1.0 | 19 | 46 | -28 | 0 of 4 | 3 of 4 | - | -28 |
| Mine | Ogre Kingdoms | 1 | 236 | 45 | 3.0 | 1.0 | 15 | 11 | +4 | 0 of 3 | 1 of 2 | - | +4 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 399 | 6.0 | 1.2 | 66 | 133 | -66 | 1 of 6 | 4 of 6 | +45 | -89 |
| Mine | Skaven | 2 | 73 | 0 | 2.0 | 1.0 | 0 | 0 | +0 | 1 of 4 | 2 of 4 | - | +0 |
| Mine | Tomb Kings of Khemri | 1 | 125 | 792 | 7.0 | 1.3 | 113 | 10 | +103 | 1 of 7 | 5 of 7 | +278 | +33 |
| Mine | Vampire Counts | 3 | 115 | 260 | 5.0 | 1.2 | 52 | 10 | +42 | 3 of 15 | 8 of 15 | +143 | +17 |
| Mine | Warriors of Chaos | 1 | 0 | 844 | 5.0 | 1.0 | 169 | 0 | +169 | 2 of 5 | 3 of 5 | - | +169 |
| **Mine** | all armies | 36 | 180 | 327 | 3.0 | 1.1 | 110 | 40 | +70 | 40 of 107 | 67 of 106 | +163 | +56 |
| Opponent | Dwarfen Mountain Holds | 2 | 137 | 268 | 3.5 | 1.1 | 77 | 9 | +68 | 1 of 7 | 3 of 7 | +81 | +66 |
| Opponent | Empire of Man | 2 | 280 | 325 | 2.0 | 1.0 | 162 | 0 | +162 | 1 of 4 | 3 of 4 | - | +162 |
| Opponent | Grand Cathay | 2 | 447 | 568 | 5.5 | 1.1 | 103 | 15 | +89 | 4 of 11 | 11 of 11 | -162 | +114 |
| Opponent | Kingdom of Bretonnia | 1 | 165 | 215 | 4.0 | 1.0 | 54 | 0 | +54 | 3 of 4 | 1 of 4 | - | +54 |
| Opponent | Ogre Kingdoms | 3 | 145 | 422 | 5.3 | 1.1 | 79 | 2 | +77 | 7 of 16 | 11 of 16 | +267 | +49 |
| Opponent | Skaven | 1 | 380 | 189 | 2.0 | 1.0 | 94 | 0 | +94 | 2 of 2 | 2 of 2 | - | +94 |
| Opponent | Tomb Kings of Khemri | 4 | 164 | 910 | 5.8 | 1.2 | 158 | 87 | +71 | 13 of 23 | 14 of 23 | +376 | +42 |
| Opponent | Vampire Counts | 6 | 0 | 560 | 4.0 | 1.1 | 140 | 60 | +80 | 12 of 24 | 14 of 24 | +287 | +61 |
| Opponent | Warriors of Chaos | 8 | 16 | 516 | 3.5 | 1.4 | 148 | 8 | +139 | 15 of 28 | 20 of 28 | +264 | +90 |
| Opponent | Wood Elf Realms | 7 | 18 | 503 | 4.4 | 1.2 | 114 | 25 | +88 | 7 of 31 | 21 of 31 | +146 | +77 |
| **Opponent** | all armies | 36 | 100 | 518 | 4.2 | 1.2 | 124 | 31 | +93 | 65 of 150 | 100 of 150 | +220 | +72 |

### Effective charges: fw-h2h2-opp-1eea44e-p2

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 2 | 0 | 0 | 0 | 0 | 0 | 1 (net +511) | 1 | 0% (0 of 1) |
| Mine | Chaos Dwarfs | 13 | 3 (net +347) | 1 (net +0) | 3 (net -91) | 0 | 2 (net +74) | 4 (net +156) | 0 | 23% (3 of 13) |
| Mine | Dwarfen Mountain Holds | 5 | 1 (net +0) | 1 (net +0) | 2 (net -156) | 0 | 0 | 1 (net +0) | 0 | 40% (2 of 5) |
| Mine | Empire of Man | 12 | 0 | 1 (net +0) | 2 (net -464) | 4 (net -2) | 0 | 5 (net +67) | 0 | 17% (2 of 12) |
| Mine | Grand Cathay | 11 | 1 (net +0) | 0 | 4 (net +152) | 0 | 1 (net +60) | 5 (net +177) | 0 | 36% (4 of 11) |
| Mine | High Elf Realms | 15 | 0 | 0 | 2 (net +0) | 1 (net +752) | 7 (net +136) | 3 (net +87) | 2 | 15% (2 of 13) |
| Mine | Kingdom of Bretonnia | 5 | 0 | 1 (net +0) | 0 | 2 (net +350) | 1 (net +207) | 1 (net -6) | 0 | 0% (0 of 5) |
| Mine | Lizardmen | 4 | 1 (net -185) | 0 | 0 | 1 (net +75) | 1 (net +0) | 1 (net +0) | 0 | 0% (0 of 4) |
| Mine | Ogre Kingdoms | 3 | 0 | 0 | 0 | 2 (net -17) | 1 (net +45) | 0 | 0 | 0% (0 of 3) |
| Mine | Orc & Goblin Tribes | 6 | 0 | 0 | 1 (net +190) | 0 | 0 | 0 | 5 | 100% (1 of 1) |
| Mine | Skaven | 4 | 1 (net +0) | 0 | 0 | 0 | 0 | 3 (net +0) | 0 | 0% (0 of 4) |
| Mine | Tomb Kings of Khemri | 7 | 0 | 1 (net +0) | 0 | 0 | 3 (net +227) | 2 (net +55) | 1 | 0% (0 of 6) |
| Mine | Vampire Counts | 15 | 2 (net -50) | 0 | 1 (net +205) | 5 (net +93) | 3 (net +0) | 3 (net +22) | 1 | 7% (1 of 14) |
| Mine | Warriors of Chaos | 5 | 0 | 0 | 1 (net +0) | 1 (net +236) | 0 | 3 (net +203) | 0 | 20% (1 of 5) |
| Opponent | Dwarfen Mountain Holds | 7 | 2 (net +2) | 0 | 0 | 2 (net +128) | 0 | 2 (net +82) | 1 | 0% (0 of 6) |
| Opponent | Empire of Man | 4 | 1 (net +310) | 0 | 2 (net +115) | 1 (net +110) | 0 | 0 | 0 | 50% (2 of 4) |
| Opponent | Grand Cathay | 11 | 1 (net +0) | 0 | 3 (net +9) | 5 (net +166) | 0 | 1 (net +117) | 1 | 30% (3 of 10) |
| Opponent | Kingdom of Bretonnia | 4 | 1 (net +95) | 0 | 3 (net +40) | 0 | 0 | 0 | 0 | 75% (3 of 4) |
| Opponent | Ogre Kingdoms | 16 | 3 (net +152) | 0 | 1 (net +0) | 1 (net +0) | 0 | 10 (net +77) | 1 | 7% (1 of 15) |
| Opponent | Skaven | 2 | 0 | 1 (net +0) | 0 | 0 | 0 | 1 (net +189) | 0 | 0% (0 of 2) |
| Opponent | Tomb Kings of Khemri | 23 | 8 (net -79) | 0 | 1 (net +442) | 3 (net +17) | 1 (net +151) | 8 (net +205) | 2 | 5% (1 of 21) |
| Opponent | Vampire Counts | 24 | 6 (net +16) | 2 (net +376) | 6 (net +202) | 4 (net -176) | 0 | 5 (net +112) | 1 | 26% (6 of 23) |
| Opponent | Warriors of Chaos | 28 | 1 (net +0) | 1 (net +0) | 3 (net +0) | 5 (net +300) | 1 (net +80) | 10 (net +159) | 7 | 14% (3 of 21) |
| Opponent | Wood Elf Realms | 31 | 3 (net +48) | 1 (net -557) | 5 (net -10) | 5 (net +187) | 5 (net +55) | 11 (net +170) | 1 | 17% (5 of 30) |

### Charged fights, damage counted: fw-h2h2-opp-1eea44e-p2

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 9 | 285 | 323 | +84 | 135 | 76 | +59 | +20.8 |
| Mine | 50-54% | 5 | 243 | 299 | +0 | 22 | 0 | +22 | +8.9 |
| Mine | Effective (55-75%) | 16 | 244 | 248 | -32 | 111 | 125 | -14 | -5.5 |
| Mine | 76-89% | 16 | 217 | 230 | +137 | 189 | 52 | +137 | +63.0 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 32 | 233 | 175 | +106 | 149 | 40 | +109 | +46.8 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 19 | 407 | 103 | +110 | 117 | 6 | +111 | +27.2 |
| Mine | No odds | 10 | 323 | 116 | -41 | 84 | 116 | -33 | -10.1 |
| Mine | All fights | 107 | 276 | 194 | +70 | 130 | 57 | +74 | +26.6 |
| Opponent | Long shot (under 50%) | 26 | 209 | 258 | +18 | 113 | 88 | +24 | +11.7 |
| Opponent | 50-54% | 5 | 218 | 264 | +39 | 160 | 125 | +35 | +16.0 |
| Opponent | Effective (55-75%) | 24 | 257 | 214 | +83 | 117 | 28 | +89 | +34.8 |
| Opponent | 76-89% | 26 | 303 | 168 | +115 | 174 | 61 | +114 | +37.6 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 48 | 299 | 204 | +144 | 168 | 27 | +141 | +47.2 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 7 | 584 | 119 | +72 | 84 | 27 | +58 | +9.9 |
| Opponent | No odds | 14 | 175 | 136 | +64 | 73 | 30 | +43 | +24.4 |
| Opponent | All fights | 150 | 276 | 201 | +93 | 138 | 47 | +91 | +33.0 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| fw-h2h2-opp-1eea44e-p2 | move | 506 | 100 (20%) | 64 (13%) | 74 (15%) | 332 (66%) |
| fw-h2h2-opp-1eea44e-p2 | objective | 389 | 62 (16%) | 42 (11%) | 46 (12%) | 281 (72%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0106, L0122, L2429, L2535, L2735 |
| Charmed Shield | Opponent | L0425, L0827, L0934, L1026, L1727, L1827, L1927 |
| Clockwork Compass | Mine | L1228 |
| Clockwork Compass | Opponent | L0512 |
| Elixir of Power | Mine | L1118, L1135, L1927 |
| Fistful of Laurels | Mine | L1827 |
| Fistful of Laurels | Opponent | L0918, L1118, L1418 |
| Horn of the Wild Hunt | Opponent | L3033 |
| Invocation of Nehek | Mine | L2429, L2535, L2735 |
| Invocation of Nehek | Opponent | L0425, L0827, L1727, L1827, L1927 |
| Opal Amulet | Mine | L1418, L1435 |
| Periapt of Soul Exchange | Mine | L2029, L2131 |
| Periapt of Soul Exchange | Opponent | L0721 |
| Ring of Doom | Mine | L0206, L0222, L1118, L1135, L1228, L1531 |
| Ring of Doom | Opponent | L0512, L1531, L2131, L3033 |
| Ring of Jet | Mine | L1026, L1118, L1135, L1228 |
| Ring of Jet | Opponent | L0512, L0810 |
| Standard of the Fell Warrior | Mine | L1323 |
| Storm Daemon (Renegade 2.0) | Mine | L2131 |
| Storm Daemon (Renegade 2.0) | Opponent | L0721 |
| Twice-Blessed Armour | Mine | L0721, L1026 |
| Twice-Blessed Armour | Opponent | L0307, L0810 |
| Witch Hunter's Ward | Mine | L0721, L0810, L0827 |
| Witch Hunter's Ward | Opponent | L0307 |

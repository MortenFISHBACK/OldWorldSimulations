# Doctrine scorecard: fw-h2h2-mine-1eea44e-p3c

### Scorecard: fw-h2h2-mine-1eea44e-p3c

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L1122 | 6 | 1 | Mine | no | 2 | 2 | 3 | 0 | 1 | 0 | 0 | 330 |
| L1122 | 6 | 1 | Opponent | no | 2 | 2 | 2 | 2 | 0 | 0 | 0 | 72 |
| L1216 | 4 | 1 | Mine | no | 2 | 2 | 4 | 0 | 0 | 0 | 0 | 330 |
| L1216 | 4 | 1 | Opponent | no | 3 | 2 | 4 | 1 | 0 | 0 | 0 | 307 |
| L1232 | 2 | 1 | Mine | - | - | 3 | 2 | 0 | 0 | 0 | 0 | 330 |
| L1232 | 2 | 1 | Opponent | - | - | 2 | 1 | 4 | 0 | 0 | 0 | 0 |
| L1327 | 1 | 1 | Mine | no | 3 | 2 | 5 | 0 | 0 | 0 | 0 | 140 |
| L1327 | 1 | 1 | Opponent | no | 1 | 3 | 2 | 2 | 0 | 0 | 0 | 50 |
| L1422 | 6 | 1 | Mine | no | 0 | 2 | 4 | 0 | 0 | 0 | 0 | 123 |
| L1422 | 6 | 1 | Opponent | no | 0 | 2 | 4 | 1 | 0 | 0 | 0 | 170 |
| L1519 | 1 | 1 | Mine | no | 1 | 2 | 7 | 0 | 0 | 0 | 0 | 0 |
| L1519 | 1 | 1 | Opponent | no | 0 | 2 | 4 | 2 | 1 | 0 | 0 | 0 |
| **Average** | | | Mine | 0% | 1.6 | 2.2 | 4.2 | 0.0 | 0.2 | 0.0 | 0.0 | 208.8 |
| **Average** | | | Opponent | 0% | 1.2 | 2.2 | 2.8 | 2.0 | 0.2 | 0.0 | 0.0 | 99.8 |

### KPIs: fw-h2h2-mine-1eea44e-p3c

Rules off - Opponent only: WAR ENGINE JOBS, STAY WEIGHED, BEST FIRST, RANDOM MOVE BY FIGURES, RANDOM MOVER NO PROMISE, STABLE ROLE, WOUNDED STAYS OUT, BEST FACING, LOST CHARGE, SCREEN BY WHAT IT SAVES, REDIRECT BY WHAT IT STOPS, SHOOTER COUNTED ONCE, LURE BY WHAT IT DRAWS, HILL BY ITS CHANCE, MOVE TO CHARGE, LONG SHOT, DEFENSIVE ARMY, SHOOTS FROM THE BEST SPOT, SUPPORTS, RESERVE FALL BACK, WAIT AFTER COSTS, CHARGE NOW FIRST, SUPPORT NARROWED, WAR ENGINE CHARGES, DEFENSIVE FLOOR.

Morten 2026-11-10; 6 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 16% (5 of 31) | 0% (0 of 30) | 8% (5 of 61) |
| Winner chose to follow up after the loser gave ground |  | 100% (9 of 9); on the table 100% | 90% (9 of 10); on the table 90% | 95% (18 of 19); on the table 95% |
| Winner chose to pursue after the loser fell back in good order |  | 100% (3 of 3); on the table 100% | 0% (0 of 1); on the table 0% | 75% (3 of 4); on the table 75% |
| Winner chose to pursue after the loser fled |  | 71% (5 of 7); on the table 71% | 60% (3 of 5); on the table 60% | 67% (8 of 12); on the table 67% |
| Winner chose to follow up or pursue (all three) |  | 89% (17 of 19); on the table 89% | 75% (12 of 16); on the table 75% | 83% (29 of 35); on the table 83% |
| Magic missiles tried each own turn | 50%+ | 29% (23 of 78) | 6% (1 of 18) | 25% (24 of 96) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 41% (23 of 56) | 20% (1 of 5) | 39% (24 of 61) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | - | - |
| Points that never fought | lower | 35% (4150 of 11999) | 31% (3687 of 11999) | 33% (7837 of 23998) |
|   infantry points that never fought | lower | 47% (801 of 1704) | 30% (530 of 1768) | 38% (1331 of 3472) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 30% (15 of 50) | 63% (24 of 38) | 44% (39 of 88) |
| Bound items with a magic missile used (at least once a game) |  | 100% (11 of 11); 5.2 uses a game | 0.0 uses a game | 100% (11 of 11); 2.6 uses a game |
| Bound items with another spell used |  | 50% (4 of 8); 1.0 uses a game | 0.0 uses a game | 50% (4 of 8); 0.5 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 67% (2 of 3); 0.3 uses a game | 50% (1 of 2); 0.2 uses a game | 60% (3 of 5); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 23% (2687 of 11607) | 57% (5535 of 9636) | 39% (8222 of 21243) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.0 (11%) | 0.2 (6%) | 1.2 (10%) |
| MARCHED: its unit marched | 3.5 (38%) | 0.0 (0%) | 3.5 (29%) |
| CHARGED: its unit charged | 0.7 (7%) | 0.0 (0%) | 0.7 (6%) |
| IN COMBAT: engaged in combat | 3.0 (33%) | 0.2 (6%) | 3.2 (26%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.5 (18%) | 0.5 (4%) |
| FLEEING: fleeing | 0.3 (4%) | 0.0 (0%) | 0.3 (3%) |
| GONE: slain | 0.3 (4%) | 1.2 (41%) | 1.5 (12%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (0%) | 0.8 (29%) | 0.8 (7%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.3 (4%) | 0.0 (0%) | 0.3 (3%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.0 | 0.8 | 1.5 | 4.0 | 0.5 | 3.2 |
| not cast | 4.0 | 1.2 | 5.5 | 12.0 | 5.5 | 28.8 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 3.0 (10%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.7 (57%) | 0.3 (6%) | 1.2 (10%) | 0.5 (9%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 3.5 (29%) | 1.3 (24%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (6%) | 0.2 (3%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.2 (4%) | 0.0 (0%) | 1.0 (18%) | 3.2 (26%) | 1.2 (21%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.0 (0%) | 0.5 (9%) | 0.5 (4%) | 0.3 (6%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (0%) | 0.2 (14%) | 0.0 (0%) | 0.3 (3%) | 0.2 (3%) | 1.0 (3%) |
| GONE: slain | 1.7 (42%) | 0.0 (0%) | 0.5 (9%) | 1.5 (12%) | 0.5 (9%) | 6.5 (23%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (0%) | 0.0 (0%) | 0.8 (15%) | 0.8 (7%) | 0.8 (15%) | 1.8 (6%) |
| STUPIDITY: Stupidity | 0.2 (4%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.3 (29%) | 0.0 (0%) | 0.3 (3%) | 0.5 (9%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.0 (50%) | 0.0 (0%) | 2.3 (42%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 16.5 (57%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.5 a game | 0.0 a game | 0.8 a game |
| stood (cast and not dispelled) | 71% (5 of 7) | - | 71% (5 of 7) |
| the unit moved after it | 100% (5 of 5) | - | 100% (5 of 5) |
| it charged on its next turn | 20% (1 of 5) | - | 20% (1 of 5) |
| the enemy charged it first | 40% (2 of 5) | - | 40% (2 of 5) |
| it fought by the end of its next turn | 60% (3 of 5) | - | 60% (3 of 5) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 5) | - | 0% (0 of 5) |
| none of these (no charge, no fight, no charge escaped) | 40% (2 of 5) | - | 40% (2 of 5) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 65% (83 of 127) | 56% (53 of 95) | 61% (136 of 222) |
|   cavalry | 67% (4 of 6) | 57% (13 of 23) | 59% (17 of 29) |
|   character | 26% (8 of 31) | 0% (0 of 24) | 15% (8 of 55) |
|   chariot | 73% (8 of 11) | 86% (6 of 7) | 78% (14 of 18) |
|   infantry | 73% (27 of 37) | 84% (31 of 37) | 78% (58 of 74) |
|   war machine | 86% (36 of 42) | 75% (3 of 4) | 85% (39 of 46) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.7 (36%) | 0.3 (5%) | 3.0 (21%) |
| CHARGED: it charged | 2.2 (30%) | 1.8 (26%) | 4.0 (28%) |
| FLEEING: it fled or was fleeing | 0.2 (2%) | 0.0 (0%) | 0.2 (1%) |
| IN COMBAT: it fought this turn or the last | 0.2 (2%) | 0.5 (7%) | 0.7 (5%) |
| NO TARGET IN RANGE | 0.3 (5%) | 1.7 (24%) | 2.0 (14%) |
| ONLY IN COMBAT: the only targets were in combat | 0.0 (0%) | 0.7 (10%) | 0.7 (5%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.3 (18%) | 1.8 (26%) | 3.2 (22%) |
| SHELTERED: the target was sheltered | 0.3 (5%) | 0.2 (2%) | 0.5 (3%) |
| OTHER BAR | 0.2 (2%) | 0.0 (0%) | 0.2 (1%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 4.8 | 0.7 | 90% | 3.3 pts | 16 pts |
| character | 2.2 | 0.2 | 92% | 1.4 pts | 3 pts |
| chariot | 2.3 | 0.5 | 79% | 6.4 pts | 15 pts |
| infantry | 15.7 | 5.3 | 69% | 11.1 pts | 174 pts |
| war machine | 6.5 | 5.8 | 59% | 32.8 pts | 214 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 6.5 | 5.5 | 6.0 |
| Charges that made contact a game | 5.0 | 3.0 | 4.0 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.38 declared, 1.00 contact (8 units) | 0.00 declared, 0.00 contact (1 units) | 1.22 declared, 0.89 contact (9 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 2.00 declared, 1.00 contact (2 units) | 2.00 declared, 1.00 contact (2 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.97 declared, 0.76 contact (29 units) | 0.59 declared, 0.33 contact (49 units) | 0.73 declared, 0.49 contact (78 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 39% (7 of 18) | 100% (1 of 1) | 0% (0 of 3) | 36% (8 of 22) |
| Character on its own | 100% (6 of 6) | 42% (5 of 12) | 24% (4 of 17) | 43% (15 of 35) |
| Chariot | 50% (1 of 2) | - | - | 50% (1 of 2) |
| Infantry | 36% (4 of 11) | 0% (0 of 3) | - | 29% (4 of 14) |
| Monster | 67% (4 of 6) | - | - | 67% (4 of 6) |
| Monstrous | 100% (1 of 1) | 100% (2 of 2) | - | 100% (3 of 3) |
| War Machines | 67% (4 of 6) | - | - | 67% (4 of 6) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Grand Cathay | 3 | 88% (7 of 8); on the table 88% | 30% (18 of 60) | 45% | 38% (10 of 26) | 100% (8 of 8); 7.7 uses a game | 0.0 uses a game | 67% (2 of 3); 0.7 uses a game |
| High Elf Realms | 3 | 91% (10 of 11); on the table 91% | 28% (5 of 18) | 24% | 21% (5 of 24) | 100% (3 of 3); 2.7 uses a game | 50% (4 of 8); 2.0 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | 100% (3 of 3); on the table 100% | - | 28% | 50% (3 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Orc & Goblin Tribes | 1 | 100% (2 of 2); on the table 100% | 0% (0 of 6) | 6% | 88% (7 of 8) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Tomb Kings of Khemri | 2 | 67% (6 of 9); on the table 67% | 0% (0 of 6) | 37% | 60% (6 of 10) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 1 | 50% (1 of 2); on the table 50% | 17% (1 of 6) | 29% | 33% (2 of 6) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 1 | - | - | 48% | 75% (6 of 8) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (fw-h2h2-mine-1eea44e-p3c, 6 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 69% (9) | 56% (10) | 61% (19) |
| ...free all their last turn and able to turn (per game) | 0.83 | 1.17 | 2.00 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.33 | 0.33 | 0.67 |
| ...with the charger already in that arc before they moved (per game) | 0.67 | 0.67 | 1.33 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 2.00 | 0.17 | 2.17 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 1.00 | 0.33 | 1.33 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 3.83 | 6.33 | 10.17 |

### Quality by phase: fw-h2h2-mine-1eea44e-p3c

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 5.7 | 4.0 |
| Strategy | Charge objectives carried out (made contact) | 83% (24 of 29) | 33% (9 of 27) |
| Strategy | Shoot objectives carried out (shot that target) | 43% (29 of 67) | 75% (15 of 20) |
| Strategy | Close-in objectives charged next turn | 22% (11 of 50) | 4% (1 of 24) |
| Strategy | Support requests answered (helper made contact too) | 50% (1 of 2) | 60% (3 of 5) |
| Strategy | Hexes on a unit its side charged or shot that turn | 33% (1 of 3) | - |
| Strategy | Joined characters whose unit fought | 0% (0 of 1) | 0% (0 of 1) |
| Strategy | Lone characters that fought | 89% (16 of 18) | 79% (19 of 24) |
| Movement | Charges halted short of contact | 0.3 | 0.5 |
| Movement | Idle units | 0.0 | 2.0 |
| Movement | Points that never moved of their own | 208.8 | 99.8 |
| Movement | Fights charged into per game | 4.5 | 2.8 |
| Movement | Charges with odds: long shots (under 50%) | 4 of 26, net +117 | 0 of 13 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 26 | 0 of 13 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 5 of 26, net +69 | 0 of 13 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 13 of 26, net +186 | 9 of 13, net +96 |
| Shooting | Shots by shooting units (incl. breath weapons) | 8.8 | 10.5 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 51% (27 of 53) | 60% (38 of 63) |
| Shooting | Points destroyed by shooting units | 99.3 | 20.5 |
| Shooting | War machine shots | 6.0 | 0.5 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 56% (20 of 36) | 67% (2 of 3) |
| Shooting | Points destroyed by war machines | 28.7 | 0.0 |
| Magic | Magic missiles cast | 3.0 | 0.2 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 28% (5 of 18) | 0% (0 of 1) |
| Magic | Wounds caused by magic missiles | 5.3 | - |
| Magic | Wounds caused by other spells | 7.7 | - |
| Magic | Points destroyed by magic (all spells) | 278.3 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.5 / 0.5 / 2.2 / 0.3 | 1.8 / 0.0 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 611.8 | 389.8 |
| Combat | Points run down | 136.3 | 141.3 |
| Combat | Net points per charged fight, damage counted | +137 | +114 |
| Combat | Net per 100 charger points, damage counted | +37.4 | +34.8 |
| Combat | First round won (charged fights) | 52% | 59% |
| Combat | Net points per charged fight | +134 | +117 |
| Combat | Net points per supported fight / lone fight | +78 / +141 | +244 / +109 |
| Combat | Charged fights on a top-3 enemy unit | 9 of 27 | 8 of 17 |
| Game | Points lost | 627.2 | 1203.3 |
| Game | VP from objectives | 653.3 | 338.3 |
| Game | Lone holders (player turns) | 1.6 | 1.2 |

- Mine won / drew / lost: 4 / 1 / 1 of 6 ended games (of 6); mean margin (Mine - Opponent) +1044 VP
- The side that went first won 3 of 5 games with a winner
- Points traded per game (both sides' losses): 1830
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: fw-h2h2-mine-1eea44e-p3c

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.8 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| ARRIVAL HUNT | - | - | - | - | 0.2 | +0.5 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.2 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| BACKUP TARGETS | 1.7 | +7.3 | 0.0 | 20.5 | 1.5 | +23.0 | 0.0 | 0.0 |
| BEST FACING | 0.5 | +30.8 | 0.0 | 25.2 | - | - | - | - |
| BEST FIRST | 2.5 | +125.5 | 189.2 | 0.0 | - | - | - | - |
| BEST OVERALL | 0.5 | +21.2 | 0.0 | 0.0 | - | - | - | - |
| BEST PREY | 0.7 | +39.1 | 77.7 | 0.0 | 5.2 | +308.0 | 58.3 | 184.2 |
| BEST PRIZE | 0.3 | -69.6 | 0.0 | 0.0 | 0.2 | +24.0 | 0.0 | 0.0 |
| BIG CHARACTER SAFETY | 0.5 | -1.9 | 0.0 | 0.0 | - | - | - | - |
| BLOCKED CHARGE SKIPPED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| BLOCKED WHEEL | 0.7 | +13.1 | 0.0 | 0.0 | 0.5 | +29.2 | 0.0 | 8.3 |
| BOMBING RUN | 0.2 | +4.5 | 0.0 | 0.0 | - | - | - | - |
| BOUND ASSAILMENT | 0.2 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CANNON PLAN MISSED | 0.5 | +0.0 | 7.5 | 11.7 | - | - | - | - |
| CANNON PLANNED TARGET | 4.7 | +110.0 | 303.5 | 133.3 | 0.5 | +0.0 | 0.0 | 0.0 |
| CANNON SIGHT KEPT | 2.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT COUNTER | - | - | - | - | 0.2 | +0.0 | 61.5 | 0.0 |
| CARRIES OUT SET-UP | 0.3 | -32.6 | 36.2 | 0.0 | - | - | - | - |
| CAST JOB | 0.8 | +19.7 | 87.8 | 0.0 | - | - | - | - |
| CASTING BLOCK | 0.2 | +8.5 | 0.0 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | 0.8 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CASTS FROM BEHIND | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CHAFF PASSED | 0.3 | -1.4 | 32.5 | 0.0 | - | - | - | - |
| CHARGE NOW FIRST | 3.8 | +0.0 | 620.3 | 36.2 | - | - | - | - |
| CHARGE NOW WEIGHED | 0.8 | -113.8 | 40.0 | 33.2 | 0.5 | -64.2 | 0.0 | 35.2 |
| CHARIOT NO STATIC JOB | - | - | - | - | 0.8 | +0.0 | 0.0 | 12.0 |
| COMBAT PIVOT | 1.0 | +0.0 | 256.3 | 72.3 | 0.2 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | 0.8 | +67.2 | 0.0 | 0.0 | - | - | - | - |
| COUNTER-CHARGE COVER | 6.7 | +375.3 | 0.0 | 168.5 | 8.0 | +1087.3 | 0.0 | 185.5 |
| DEFENSIVE ARMY | 0.2 | +0.0 | 0.0 | 29.5 | - | - | - | - |
| EDGE GIVE GROUND | 0.7 | +49.5 | 69.8 | 0.0 | 0.3 | +3.8 | 29.5 | 32.5 |
| ELIXIR WORTH | 0.2 | +9.8 | 0.0 | 49.3 | - | - | - | - |
| FACES THE THREAT | 2.0 | +223.3 | 0.0 | 79.8 | 0.2 | +12.6 | 0.0 | 0.0 |
| FALLBACK BY WORTH | 3.3 | +66.9 | 0.0 | 0.0 | 8.0 | +277.6 | 0.0 | 141.3 |
| FIGHT LIFT | - | - | - | - | 0.2 | +1.7 | 0.0 | 0.0 |
| FLANK NOT WEIGHED | 3.0 | +0.0 | 0.0 | 65.8 | 5.5 | +0.0 | 0.0 | 146.2 |
| FOLLOW UP WEIGHED | 1.7 | +370.3 | 0.0 | 178.7 | 0.8 | +169.2 | 0.0 | 168.5 |
| FRIENDS SHOTS CHECKED | 0.2 | +0.3 | 0.0 | 0.0 | - | - | - | - |
| GIVES UP | - | - | - | - | 1.8 | -96.4 | 183.8 | 32.5 |
| GIVES UP ITS SCREEN | - | - | - | - | 0.8 | -26.7 | 65.8 | 20.0 |
| HELPER UNSEEN | 0.3 | +0.0 | 71.7 | 19.2 | - | - | - | - |
| HILL BY ITS CHANCE | 0.5 | -41.1 | 0.0 | 40.7 | - | - | - | - |
| HOLDS AMBUSHERS | 0.7 | +0.0 | 0.0 | 0.0 | 0.8 | +0.0 | 0.0 | 0.0 |
| HUNT ADVANCE | - | - | - | - | 0.3 | +0.8 | 0.0 | 0.0 |
| HUNT DROPPED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| HUNT IN PAIRS | 0.8 | +60.7 | 0.0 | 0.0 | 1.5 | +35.8 | 0.0 | 0.0 |
| HUNT RESULT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| HUNT THE GUNS | - | - | - | - | 0.3 | +182.7 | 0.0 | 0.0 |
| INVITES THE FIGHT | 1.0 | +9.6 | 7.5 | 58.3 | - | - | - | - |
| JOINT CHARGE PLAN | 0.3 | +145.6 | 65.5 | 0.0 | 0.2 | +4.7 | 0.0 | 0.0 |
| KEEP FALLS | 0.2 | +4.6 | 0.0 | 0.0 | - | - | - | - |
| KEEPS ITS PREY | - | - | - | - | 0.3 | +7.2 | 0.0 | 35.2 |
| KEEPS ITS TARGET | 3.0 | +90.0 | 554.3 | 0.0 | 1.3 | +40.0 | 29.5 | 0.0 |
| KILLS COUNT | 2.0 | +104.6 | 334.0 | 0.0 | 2.0 | +88.6 | 83.5 | 0.0 |
| KILLS COUNT NEXT TURN | 9.3 | +441.9 | 601.0 | 123.0 | 9.2 | +337.5 | 192.2 | 242.3 |
| LONE CHARACTER SAFE SPOT | 0.8 | +116.5 | 10.5 | 0.0 | 0.5 | +5.1 | 0.0 | 93.5 |
| LONE WIZARD HOLDS BACK | - | - | - | - | 0.2 | +0.0 | 10.0 | 31.7 |
| LONE WIZARD KEPT IN | 0.2 | +8.0 | 0.0 | 0.0 | 0.8 | +53.8 | 0.0 | 0.0 |
| LONG SHOT | 0.2 | +17.3 | 0.0 | 0.0 | - | - | - | - |
| LOST CHARGE | 3.7 | -71.8 | 264.8 | 179.2 | - | - | - | - |
| MAKE SURE TOGETHER | 1.3 | +221.1 | 65.5 | 0.0 | 1.3 | +89.8 | 0.0 | 12.0 |
| MARCH CHECK | 1.3 | +18.1 | 0.0 | 0.0 | 0.2 | +20.3 | 0.0 | 0.0 |
| MARCH ODDS | 0.8 | +49.4 | 33.3 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 2.2 | +289.9 | 0.0 | 0.0 | - | - | - | - |
| MAX FOR POSITIONING | 4.0 | +118.6 | 0.0 | 66.2 | 4.3 | +284.2 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 7.3 | +167.0 | 0.0 | 73.8 | 0.5 | +2.4 | 0.0 | 65.5 |
| MISSILES NEXT TURN | 10.7 | +121.9 | 0.0 | 73.8 | 0.7 | +2.2 | 0.0 | 97.2 |
| MONSTER WIZARD ROAMS | 0.5 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE AND CAST | 1.2 | +56.6 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL SPOT | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE TO CHARGE | 6.5 | +841.0 | 593.0 | 95.7 | - | - | - | - |
| MOVES UNITS SPELL | 0.2 | +1.2 | 0.0 | 0.0 | 0.2 | +0.7 | 0.0 | 0.0 |
| NEEDED THERE | 0.2 | +22.5 | 39.2 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| NOT NEEDED | 0.2 | -32.4 | 12.0 | 0.0 | 0.2 | -32.6 | 0.0 | 0.0 |
| NOT TURNED | 3.8 | +105.5 | 0.0 | 104.2 | 6.3 | +29.4 | 0.0 | 158.7 |
| NOT WORTH A CAST | 1.2 | -0.5 | 0.0 | 0.0 | 0.2 | -0.0 | 0.0 | 0.0 |
| OFF BEST | 16.0 | -944.8 | 0.0 | 185.8 | 14.5 | -1233.9 | 0.0 | 210.2 |
| OPENS UP | 0.7 | +51.2 | 46.5 | 0.0 | 0.3 | +27.3 | 11.7 | 0.0 |
| OVERRUNS AWAY | 0.8 | +30.3 | 46.5 | 0.0 | 0.3 | +17.2 | 72.3 | 0.0 |
| PATHS CROSS | 2.7 | +306.4 | 0.0 | 0.0 | 1.8 | +208.5 | 0.0 | 12.0 |
| PIVOT GUARDS FLANK | 0.2 | -1.1 | 0.0 | 0.0 | 0.2 | -3.1 | 0.0 | 0.0 |
| PLAN RESULT | 35.7 | +1642.7 | 2170.5 | 1004.2 | 33.2 | +1399.0 | 1372.3 | 1685.7 |
| PURSUES BIG PREY | 0.3 | -30.2 | 0.0 | 0.0 | - | - | - | - |
| RAIDS THE BAGGAGE NEXT TURN | - | - | - | - | 0.2 | +14.6 | 0.0 | 0.0 |
| REDIRECT COUNTER | 1.0 | +20.8 | 0.0 | 41.0 | 5.5 | +974.1 | 0.0 | 94.8 |
| REDIRECT WEIGHED | 0.5 | -23.6 | 39.2 | 19.2 | 1.0 | +44.3 | 20.5 | 7.5 |
| RESERVE FALL BACK | 0.3 | +17.0 | 0.0 | 0.0 | - | - | - | - |
| RESTRAINS TO SHOOT | - | - | - | - | 0.2 | +30.2 | 0.0 | 0.0 |
| RISK BY ARC | 4.2 | +248.5 | 648.8 | 57.5 | 2.2 | +41.0 | 221.7 | 52.5 |
| SAFER THAN THE JOB | 1.0 | +11.9 | 0.0 | 0.0 | 0.3 | +12.2 | 0.0 | 46.2 |
| SCOUT SPOT | - | - | - | - | 0.7 | +1.8 | 0.0 | 0.0 |
| SCOUT WAITS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| SEARCH SPOT | 1.5 | +114.9 | 0.0 | 38.3 | 2.3 | +189.1 | 0.0 | 46.7 |
| SECOND HUNTER | - | - | - | - | 0.2 | -0.1 | 0.0 | 0.0 |
| SELF MOVE SPELL | 1.0 | +87.5 | 0.0 | 0.0 | - | - | - | - |
| SET UP TOGETHER | 1.7 | +278.6 | 65.5 | 0.0 | 1.5 | +93.0 | 0.0 | 12.0 |
| SET-UP ANY TARGET | 0.7 | +126.0 | 0.0 | 0.0 | - | - | - | - |
| SET-UP MISSED | 0.2 | +35.9 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | 0.3 | +0.3 | 0.0 | 0.0 | - | - | - | - |
| SHOOTS FROM THE BEST SPOT | 2.0 | +62.5 | 144.5 | 50.0 | - | - | - | - |
| SHOT REPLANNED | 0.3 | +0.0 | 7.5 | 11.7 | - | - | - | - |
| SHOTS IN THE MOVE | 14.0 | +539.3 | 0.0 | 227.2 | 8.2 | +430.6 | 0.0 | 131.8 |
| SPELL SETS UP CHARGE | 0.7 | +126.0 | 0.0 | 0.0 | - | - | - | - |
| SPELL WORTH | 1.8 | +62.3 | 144.7 | 144.7 | 2.0 | +14.2 | 0.0 | 0.0 |
| STABLE ROLE | 7.7 | +0.0 | 301.5 | 146.8 | - | - | - | - |
| STANDS TO CAST | 0.2 | +6.0 | 0.0 | 0.0 | - | - | - | - |
| STOPS SHORT OF THE FLANK | 1.0 | +29.8 | 0.0 | 67.3 | - | - | - | - |
| STUCK PIVOT | - | - | - | - | 0.5 | +0.0 | 0.0 | 0.0 |
| SUPPORT JOB KEPT | - | - | - | - | 0.2 | +0.0 | 0.0 | 12.0 |
| SUPPORT NARROWED | 5.0 | -29.2 | 397.3 | 177.7 | - | - | - | - |
| SUPPORTS | 2.2 | +60.1 | 0.0 | 84.0 | - | - | - | - |
| SURE CHARGE BEATS ADVANCE | 0.7 | -66.9 | 108.0 | 0.0 | 0.2 | -13.4 | 68.0 | 0.0 |
| SURE REACH TOGETHER | 0.8 | +4.5 | 0.0 | 33.2 | - | - | - | - |
| THROUGH LINE OF FIRE | 0.2 | +32.1 | 0.0 | 0.0 | 0.3 | +8.4 | 0.0 | 0.0 |
| TURN WORTH | 0.8 | -66.0 | 98.8 | 0.0 | 0.7 | -40.5 | 25.2 | 32.5 |
| TWO OR MORE ARRIVE | 0.5 | +4.5 | 65.5 | 0.0 | 0.7 | +3.9 | 0.0 | 12.0 |
| WAIT AFTER COSTS | 10.5 | -443.2 | 666.7 | 154.0 | - | - | - | - |
| WALKS TO THE FIGHT | 1.7 | +14.4 | 55.7 | 0.0 | - | - | - | - |
| WAR ENGINE JOBS | 0.8 | +0.0 | 33.2 | 0.0 | - | - | - | - |
| WEARS DOWN | 1.3 | +33.1 | 343.7 | 55.3 | 0.8 | +37.9 | 0.0 | 12.5 |
| WHOLE FIGHT | 0.2 | +1.4 | 64.3 | 36.2 | 0.7 | +106.3 | 172.2 | 0.0 |
| WHOLE FIGHT GAIN | 0.2 | +21.0 | 39.2 | 0.0 | 0.7 | +93.1 | 65.8 | 7.5 |

### Rule changes: fw-h2h2-mine-1eea44e-p3c

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 183 | 183 | 183 | 30.50 | -13071 | -71.4 |
| PATHS CROSS | 27 | 27 | 27 | 4.50 | +3089 | +114.4 |
| FALLBACK BY WORTH | 68 | 68 | 25 | 4.17 | +2067 | +82.7 |
| SEARCH SPOT | 23 | 23 | 23 | 3.83 | +1824 | +79.3 |
| KILLS COUNT NEXT TURN | 111 | 111 | 22 | 3.67 | +514 | +23.4 |
| COUNTER-CHARGE COVER | 88 | 48 | 20 | 3.33 | +1669 | +83.4 |
| CANNON SIGHT KEPT | 18 | 18 | 18 | 3.00 | +0 | +0.0 |
| MOVE TO CHARGE | 39 | 39 | 18 | 3.00 | +1560 | +86.7 |
| BEST FIRST | 15 | 15 | 15 | 2.50 | +753 | +50.2 |
| FOLLOW UP WEIGHED | 15 | 15 | 15 | 2.50 | +3237 | +215.8 |
| FACES THE THREAT | 13 | 13 | 13 | 2.17 | +1415 | +108.9 |
| RISK BY ARC | 38 | 37 | 11 | 1.83 | +333 | +30.2 |
| BEST PREY | 35 | 34 | 9 | 1.50 | +530 | +58.9 |
| HOLDS AMBUSHERS | 9 | 9 | 9 | 1.50 | +0 | +0.0 |
| REDIRECT WEIGHED | 9 | 9 | 9 | 1.50 | +309 | +34.3 |
| CANNON PLANNED TARGET | 31 | 31 | 8 | 1.33 | -28 | -3.5 |
| CHARGE NOW WEIGHED | 8 | 8 | 8 | 1.33 | +852 | +106.6 |
| SAFER THAN THE JOB | 8 | 8 | 8 | 1.33 | +145 | +18.1 |
| SHOOTS FROM THE BEST SPOT | 12 | 12 | 8 | 1.33 | +109 | +13.6 |
| SHOTS IN THE MOVE | 133 | 87 | 8 | 1.33 | +308 | +38.4 |
| ARTILLERY RE-ROLL WEIGHED | 7 | 7 | 7 | 1.17 | +0 | +0.0 |
| BLOCKED WHEEL | 7 | 7 | 7 | 1.17 | +254 | +36.3 |
| CHARGE NOW FIRST | 23 | 23 | 7 | 1.17 | -469 | -67.0 |
| COMBAT PIVOT | 7 | 7 | 7 | 1.17 | +0 | +0.0 |
| MOVE AND CAST | 7 | 7 | 7 | 1.17 | +340 | +48.5 |
| REDIRECT COUNTER | 39 | 19 | 7 | 1.17 | +1605 | +229.3 |
| ADVANCE LANE KEPT | 6 | 6 | 6 | 1.00 | +0 | +0.0 |
| LONE WIZARD KEPT IN | 6 | 6 | 6 | 1.00 | +371 | +61.8 |
| MISSILES IN THE MOVE | 47 | 25 | 6 | 1.00 | +82 | +13.7 |
| STOPS SHORT OF THE FLANK | 6 | 6 | 6 | 1.00 | +179 | +29.8 |
| SUPPORTS | 13 | 13 | 6 | 1.00 | +152 | +25.4 |
| WALKS TO THE FIGHT | 10 | 10 | 6 | 1.00 | +46 | +7.6 |
| KEEPS ITS TARGET | 26 | 26 | 5 | 0.83 | +50 | +9.9 |
| KILLS COUNT | 24 | 23 | 5 | 0.83 | +112 | +22.4 |
| MAKE SURE TOGETHER | 16 | 13 | 5 | 0.83 | +233 | +46.5 |
| MARCH ODDS | 5 | 5 | 5 | 0.83 | +11 | +2.2 |
| SET UP TOGETHER | 19 | 16 | 5 | 0.83 | +233 | +46.5 |
| SURE CHARGE BEATS ADVANCE | 5 | 5 | 5 | 0.83 | -482 | -96.3 |
| OPENS UP | 6 | 5 | 4 | 0.67 | +184 | +46.0 |
| SCOUT WAITS | 4 | 4 | 4 | 0.67 | +0 | +0.0 |
| BEST FACING | 3 | 3 | 3 | 0.50 | +185 | +61.6 |
| BEST OVERALL | 3 | 3 | 3 | 0.50 | +127 | +42.4 |
| BEST PRIZE | 3 | 3 | 3 | 0.50 | -436 | -145.4 |
| BIG CHARACTER SAFETY | 3 | 3 | 3 | 0.50 | -12 | -3.9 |
| MARCH CHECK | 9 | 7 | 3 | 0.50 | +159 | +53.1 |
| MAX FOR POSITIONING | 50 | 22 | 3 | 0.50 | +32 | +10.7 |
| STUCK PIVOT | 3 | 3 | 3 | 0.50 | +0 | +0.0 |
| THROUGH LINE OF FIRE | 3 | 3 | 3 | 0.50 | +243 | +81.0 |
| WAIT AFTER COSTS | 63 | 63 | 3 | 0.50 | +18 | +6.2 |
| WHOLE FIGHT | 5 | 5 | 3 | 0.50 | +392 | +130.6 |
| WHOLE FIGHT GAIN | 5 | 4 | 3 | 0.50 | +107 | +35.8 |
| BLOCKED CHARGE SKIPPED | 2 | 2 | 2 | 0.33 | +0 | +0.0 |
| CAST JOB | 5 | 5 | 2 | 0.33 | +20 | +9.8 |
| CASTS FROM BEHIND | 2 | 2 | 2 | 0.33 | +0 | +0.0 |
| CHAFF PASSED | 2 | 2 | 2 | 0.33 | -9 | -4.3 |
| EDGE GIVE GROUND | 6 | 6 | 2 | 0.33 | +186 | +93.2 |
| MOVES UNITS SPELL | 2 | 2 | 2 | 0.33 | +12 | +5.8 |
| PIVOT GUARDS FLANK | 2 | 2 | 2 | 0.33 | -25 | -12.7 |
| PURSUES BIG PREY | 2 | 2 | 2 | 0.33 | -181 | -90.5 |
| RESERVE FALL BACK | 2 | 2 | 2 | 0.33 | +102 | +51.0 |
| SHOOTERS IN TWO RANKS | 2 | 2 | 2 | 0.33 | +2 | +1.0 |
| SHOT REPLANNED | 2 | 2 | 2 | 0.33 | +0 | +0.0 |
| WAR ENGINE JOBS | 5 | 5 | 2 | 0.33 | -37 | -18.5 |
| BACKUP TARGETS | 19 | 9 | 1 | 0.17 | +0 | +0.3 |
| BOMBING RUN | 1 | 1 | 1 | 0.17 | +27 | +27.1 |
| BOUND ASSAILMENT | 1 | 1 | 1 | 0.17 | +0 | +0.1 |
| CARRIES OUT SET-UP | 2 | 2 | 1 | 0.17 | -195 | -195.3 |
| CASTING BLOCK | 1 | 1 | 1 | 0.17 | +51 | +51.1 |
| ELIXIR WORTH | 1 | 1 | 1 | 0.17 | +59 | +59.0 |
| FRIENDS SHOTS CHECKED | 1 | 1 | 1 | 0.17 | +2 | +1.8 |
| HUNT IN PAIRS | 14 | 6 | 1 | 0.17 | +104 | +103.6 |
| KEEP FALLS | 1 | 1 | 1 | 0.17 | +36 | +36.2 |
| LONG SHOT | 1 | 1 | 1 | 0.17 | +12 | +12.4 |
| LOST CHARGE | 22 | 22 | 1 | 0.17 | +6 | +6.1 |
| NEEDED THERE | 2 | 2 | 1 | 0.17 | +0 | +0.0 |
| OVERRUNS AWAY | 7 | 7 | 1 | 0.17 | +50 | +49.8 |
| RAIDS THE BAGGAGE NEXT TURN | 1 | 1 | 1 | 0.17 | +87 | +86.6 |
| RESTRAINS TO SHOOT | 1 | 1 | 1 | 0.17 | +181 | +181.2 |
| STANDS TO CAST | 1 | 1 | 1 | 0.17 | -14 | -14.4 |
| SUPPORT JOB KEPT | 1 | 1 | 1 | 0.17 | -27 | -27.0 |
| WEARS DOWN | 13 | 13 | 1 | 0.17 | +30 | +30.1 |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 3 | 3 | 0 | 0.00 | - | - |
| CARRIES OUT COUNTER | 1 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 5 | trace | - | - | - | - |
| CHARIOT NO STATIC JOB | 5 | 5 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 5 | not checked | - | - | - | - |
| DEFENSIVE ARMY | 1 | 1 | 0 | 0.00 | - | - |
| FIGHT LIFT | 1 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 51 | not checked | - | - | - | - |
| GIVES UP | 11 | 11 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 5 | 4 | 0 | 0.00 | - | - |
| HELPER UNSEEN | 2 | 2 | 0 | 0.00 | - | - |
| HILL BY ITS CHANCE | 3 | 3 | 0 | 0.00 | - | - |
| HUNT ADVANCE | 2 | 2 | 0 | 0.00 | - | - |
| HUNT DROPPED | 2 | trace | - | - | - | - |
| HUNT RESULT | 2 | trace | - | - | - | - |
| HUNT THE GUNS | 2 | trace | - | - | - | - |
| INVITES THE FIGHT | 6 | 6 | 0 | 0.00 | - | - |
| JOINT CHARGE PLAN | 3 | 3 | 0 | 0.00 | - | - |
| KEEPS ITS PREY | 2 | 2 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 8 | not checked | - | - | - | - |
| LONE WIZARD HOLDS BACK | 1 | 1 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 13 | 13 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 68 | 30 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 3 | 3 | 0 | 0.00 | - | - |
| MOVE SPELL SPOT | 4 | not checked | - | - | - | - |
| NOT NEEDED | 2 | 2 | 0 | 0.00 | - | - |
| NOT TURNED | 61 | 61 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 8 | not checked | - | - | - | - |
| PLAN RESULT | 413 | trace | - | - | - | - |
| SCOUT SPOT | 4 | 4 | 0 | 0.00 | - | - |
| SECOND HUNTER | 1 | 1 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 6 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 4 | not checked | - | - | - | - |
| SET-UP MISSED | 1 | trace | - | - | - | - |
| SPELL SETS UP CHARGE | 4 | not checked | - | - | - | - |
| SPELL WORTH | 23 | not checked | - | - | - | - |
| STABLE ROLE | 46 | 46 | 0 | 0.00 | - | - |
| SUPPORT NARROWED | 30 | 30 | 0 | 0.00 | - | - |
| SURE REACH TOGETHER | 5 | 2 | 0 | 0.00 | - | - |
| TURN WORTH | 9 | 8 | 0 | 0.00 | - | - |
| TWO OR MORE ARRIVE | 7 | 7 | 0 | 0.00 | - | - |

### Off best figure: fw-h2h2-mine-1eea44e-p3c

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 15.00 | 11.83 | 72.0 |
| FALLBACK | gate | 0.33 | 1.33 | 113.1 |
| CHARGE NOW FIRST | rule | 1.17 | - | 67.0 |
| SURE CHARGE BEATS ADVANCE | rule | 0.67 | 0.17 | 96.3 |
| RULE SWITCHED OFF | gate | - | 0.67 | 6.1 |
| BEST PRIZE | rule | 0.33 | 0.17 | 145.4 |
| AFTERMATH NEEDS NEXT CHARGE | gate | - | 0.33 | 45.5 |
| LONE CHARACTER SAFE SPOT | gate | 0.33 | - | 91.5 |
| PIVOT GUARDS FLANK | rule | 0.17 | 0.17 | 12.7 |
| PURSUES BIG PREY | rule | 0.33 | - | 90.5 |
| REDIRECT WEIGHED | rule | 0.17 | 0.17 | 128.8 |
| WAR ENGINE JOBS | rule | 0.33 | - | 18.5 |
| AFTERMATH BAND | gate | 0.17 | - | 3.8 |
| BIG CHARACTER SAFETY | rule | 0.17 | - | 13.8 |
| CANNON PLANNED TARGET | rule | 0.17 | - | 28.1 |
| CARRIES OUT SET-UP | rule | 0.17 | - | 195.3 |
| CHAFF PASSED | rule | 0.17 | - | 8.1 |
| CHARGE NOW WEIGHED | rule | 0.17 | - | 43.5 |
| FIGHT ORDER BAND | gate | 0.17 | - | 2.1 |
| MARCH ODDS | rule | 0.17 | - | 25.6 |
| PATHS CROSS | rule | 0.17 | - | 73.5 |
| SAFER THAN THE JOB | rule | 0.17 | - | 13.8 |
| STANDS TO CAST | rule | 0.17 | - | 14.4 |
| SUPPORT JOB KEPT | rule | - | 0.17 | 27.0 |
| SUPPORT REQUEST | gate | - | 0.17 | 5.2 |
| TURN GATE | gate | - | 0.17 | 37.1 |

### Plans: fw-h2h2-mine-1eea44e-p3c

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 7.3 | 23% | 201 | 210 | 104% |
| Mine | charge | 4.2 | 64% | 726 | 454 | 63% |
| Mine | close in | 8.3 | 36% | 1190 | 342 | 29% |
| Mine | hold | 4.5 | 48% | 222 | 0 | 0% |
| Mine | shoot | 9.2 | 64% | 198 | 637 | 321% |
| Mine | support | 2.2 | 92% | 51 | 0 | 0% |
| Opponent | advance | 13.0 | 17% | 815 | 349 | 43% |
| Opponent | charge | 4.2 | 64% | 481 | 530 | 110% |
| Opponent | close in | 3.8 | 22% | 321 | 296 | 92% |
| Opponent | hold | 3.5 | 38% | 203 | 0 | 0% |
| Opponent | join | 0.3 | 50% | 12 | 0 | 0% |
| Opponent | shoot | 3.2 | 58% | 123 | 224 | 183% |
| Opponent | support | 5.2 | 74% | 142 | 0 | 0% |

### Packages: hunt the guns, fw-h2h2-mine-1eea44e-p3c

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Opponent | 0.3 | 2 | 0 | 0% | 0% | 0% | - | 548 | 0 | 0% | 29 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 100 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Tomb Kings of Khemri | 1.0 | 2 | 0 | 0% | 0% | 0% | - | 548 | 0 | 0% | 36 |
| Vampire Counts | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Warriors of Chaos | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |

### Battle groups: fw-h2h2-mine-1eea44e-p3c

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 6.7 | 38% | 27% | 20% | 67% | 0% | 0% | 33% | 67% | 0% |
| Mine | REDIRECT COUNTER | 1.0 | 67% | 50% | 0% | - | 0% | 0% | 25% | 75% | 0% |
| Opponent | COUNTER-CHARGE COVER | 8.0 | 25% | 83% | 33% | 25% | 75% | 25% | 0% | 0% | 0% |
| Opponent | REDIRECT COUNTER | 5.5 | 27% | 67% | 0% | - | 0% | 0% | 33% | 67% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: fw-h2h2-mine-1eea44e-p3c

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Mine | Character | 19 | 81 (19) | 81 | 0 | 25 | 0% | 2.4 | 132 (4) | 66 (14) | - | 68 (13) | 116 (5) |
| Mine | Clean-up | 2 | 37 (2) | 0 | 37 | 57 | 0% | 3.0 | - | 37 (2) | - | 70 (1) | 13 (1) |
| Mine | Fast Hammer | 13 | 65 (13) | 40 | 25 | 59 | 23% | 2.3 | 93 (4) | 64 (7) | 0 (2) | 70 (11) | 49 (2) |
| Mine | Holder | 3 | 65 (3) | 0 | 65 | 44 | 0% | 3.3 | - | 65 (3) | - | 65 (3) | - |
| Mine | Shooter | 9 | 126 (9) | 90 | 36 | 12 | 0% | 2.4 | - | 141 (7) | 80 (2) | 97 (7) | 219 (2) |
| Mine | War machine | 8 | 15 (8) | 15 | 0 | 42 | 0% | 1.1 | - | 11 (6) | 31 (2) | - | 15 (8) |
| Opponent | Chaff | 18 | 61 (18) | 10 | 52 | 75 | 44% | 1.9 | 7 (7) | 205 (4) | 6 (7) | 76 (14) | 11 (4) |
| Opponent | Character | 16 | 42 (16) | 42 | 0 | 36 | 19% | 2.2 | 45 (5) | 43 (9) | - | 32 (7) | 51 (7) |
| Opponent | Clean-up | 1 | 9 (1) | 0 | 9 | 115 | 0% | 3.0 | - | 9 (1) | - | - | 9 (1) |
| Opponent | Fast Hammer | 9 | 69 (9) | 63 | 6 | 86 | 44% | 3.0 | 11 (4) | 30 (3) | 265 (2) | 82 (7) | 0 (2) |
| Opponent | Hammer | 6 | 12 (6) | 12 | 0 | 61 | 17% | 4.4 | 32 (3) | 0 (3) | - | 19 (4) | 0 (2) |
| Opponent | Holder | 10 | 69 (10) | 0 | 69 | 91 | 0% | 2.2 | 0 (2) | 113 (6) | 0 (2) | 83 (8) | 0 (2) |
| Opponent | Shooter | 2 | 44 (2) | 0 | 44 | 129 | 0% | 1.0 | 88 (1) | 0 (1) | - | 88 (1) | 0 (1) |
| Opponent | Support | 2 | 0 (2) | 0 | 0 | 66 | 50% | 4.0 | 0 (1) | - | 0 (1) | 0 (1) | 0 (1) |
| Opponent | War machine | 2 | 0 (2) | 0 | 0 | 100 | 50% | 1.0 | - | 0 (2) | - | - | 0 (2) |
| Opponent | Wizard | 9 | 0 (9) | 0 | 0 | 104 | 0% | 1.8 | 0 (1) | - | 0 (1) | 0 (1) | 0 (1) |

### Charged fights: fw-h2h2-mine-1eea44e-p3c

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Grand Cathay | 3 | 583 | 185 | 3.7 | 1.1 | 50 | 0 | +50 | 2 of 11 | 6 of 11 | +0 | +55 |
| Mine | High Elf Realms | 3 | 230 | 1021 | 5.3 | 1.1 | 191 | 0 | +191 | 7 of 16 | 8 of 16 | +118 | +202 |
| **Mine** | all armies | 6 | 406 | 603 | 4.5 | 1.1 | 134 | 0 | +134 | 9 of 27 | 14 of 27 | +78 | +141 |
| Opponent | Kingdom of Bretonnia | 1 | 0 | 856 | 4.0 | 1.0 | 214 | 178 | +36 | 3 of 4 | 2 of 4 | - | +36 |
| Opponent | Orc & Goblin Tribes | 1 | 0 | 314 | 4.0 | 1.0 | 78 | 0 | +78 | 1 of 4 | 3 of 4 | - | +78 |
| Opponent | Tomb Kings of Khemri | 2 | 62 | 700 | 3.0 | 1.0 | 234 | 69 | +164 | 4 of 6 | 4 of 6 | - | +164 |
| Opponent | Vampire Counts | 1 | 0 | 300 | 2.0 | 1.0 | 150 | 0 | +150 | 0 of 2 | 0 of 2 | - | +150 |
| Opponent | Warriors of Chaos | 1 | 0 | 244 | 1.0 | 2.0 | 244 | 0 | +244 | 0 of 1 | 1 of 1 | +244 | - |
| **Opponent** | all armies | 6 | 20 | 519 | 2.8 | 1.1 | 183 | 66 | +117 | 8 of 17 | 10 of 17 | +244 | +109 |

### Effective charges: fw-h2h2-mine-1eea44e-p3c

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Grand Cathay | 11 | 2 (net +72) | 0 | 0 | 1 (net +0) | 2 (net +28) | 6 (net +59) | 0 | 0% (0 of 11) |
| Mine | High Elf Realms | 16 | 2 (net +162) | 1 (net +0) | 0 | 2 (net +190) | 3 (net +97) | 7 (net +296) | 1 | 0% (0 of 15) |
| Opponent | Kingdom of Bretonnia | 4 | 0 | 0 | 0 | 0 | 0 | 4 (net +36) | 0 | 0% (0 of 4) |
| Opponent | Orc & Goblin Tribes | 4 | 0 | 0 | 0 | 1 (net +199) | 0 | 0 | 3 | 0% (0 of 1) |
| Opponent | Tomb Kings of Khemri | 6 | 0 | 0 | 0 | 1 (net +509) | 0 | 4 (net +119) | 1 | 0% (0 of 5) |
| Opponent | Vampire Counts | 2 | 0 | 0 | 0 | 2 (net +150) | 0 | 0 | 0 | 0% (0 of 2) |
| Opponent | Warriors of Chaos | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +244) | 0 | 0% (0 of 1) |

### Charged fights, damage counted: fw-h2h2-mine-1eea44e-p3c

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 4 | 320 | 264 | +117 | 117 | 29 | +88 | +27.5 |
| Mine | 50-54% | 1 | 247 | 380 | +0 | 0 | 0 | +0 | +0.0 |
| Mine | 76-89% | 3 | 401 | 216 | +126 | 153 | 0 | +153 | +38.2 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 13 | 304 | 208 | +186 | 196 | 0 | +196 | +64.5 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 5 | 624 | 96 | +69 | 69 | 0 | +69 | +11.1 |
| Mine | No odds | 1 | 115 | 235 | +0 | 0 | 0 | +0 | +0.0 |
| Mine | All fights | 27 | 367 | 204 | +134 | 142 | 4 | +137 | +37.4 |
| Opponent | 76-89% | 4 | 372 | 214 | +252 | 344 | 56 | +287 | +77.2 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 9 | 352 | 276 | +96 | 206 | 150 | +56 | +15.8 |
| Opponent | No odds | 4 | 225 | 215 | +29 | 71 | 0 | +71 | +31.7 |
| Opponent | All fights | 17 | 327 | 247 | +117 | 207 | 93 | +114 | +34.8 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| fw-h2h2-mine-1eea44e-p3c | move | 82 | 22 (27%) | 18 (22%) | 11 (13%) | 49 (60%) |
| fw-h2h2-mine-1eea44e-p3c | objective | 74 | 12 (16%) | 10 (14%) | 11 (15%) | 51 (69%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L1327 |
| Clockwork Compass | Mine | L1216, L1232 |
| Elixir of Power | Mine | L1122 |
| Elixir of Power | Opponent | L1519 |
| Invocation of Nehek | Opponent | L1327 |
| Opal Amulet | Mine | L1422 |
| Ring of Doom | Mine | L1122, L1216, L1232, L1519 |
| Ring of Jet | Mine | L1122, L1216, L1232 |
| Standard of the Fell Warrior | Mine | L1327 |

### Framework side, per turn by its stance that turn

| Stance | Turns | VP won by shooting + magic a turn | VP won in fights a turn | VP lost to shooting + magic a turn | VP lost in fights a turn | Net kills a turn |
| --- | --- | --- | --- | --- | --- | --- |
| defensive | 252 | 60 | 46 | 15 | 148 | -58 |
| offensive | 1174 | 23 | 143 | 33 | 100 | +33 |

### By army type (an army is defensive when it played defensive in half or more of its turns with the framework; the same label is used for it when it played without)

| Framework army | Other army | Games | Framework VP margin a game | Framework won / drew / lost | Framework VP by shooting + magic | Framework VP in fights | Framework VP from objectives | Other VP by shooting + magic | Other VP in fights | Other VP from objectives |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| defensive | offensive | 49 | -441 (±372) | 21 / 0 / 28 | 372 | 250 | 491 | 79 | 782 | 710 |
| defensive | all | 49 | -441 (±372) | 21 / 0 / 28 | 372 | 250 | 491 | 79 | 782 | 710 |
| offensive | defensive | 49 | +773 (±307) | 38 / 0 / 11 | 118 | 949 | 746 | 384 | 237 | 452 |
| offensive | offensive | 188 | +4 (±190) | 101 / 0 / 87 | 143 | 680 | 521 | 134 | 661 | 539 |
| offensive | all | 238 | +166 (±168) | 140 / 0 / 98 | 137 | 738 | 568 | 185 | 573 | 521 |
| all | defensive | 49 | +773 (±307) | 38 / 0 / 11 | 118 | 949 | 746 | 384 | 237 | 452 |
| all | offensive | 237 | -88 (±171) | 122 / 0 / 115 | 190 | 591 | 515 | 122 | 686 | 574 |
| all | all | 287 | +63 (±155) | 161 / 0 / 126 | 177 | 655 | 555 | 167 | 609 | 554 |

288 games read.

Different jobs a side used in a game: framework 5.2, no framework 6.4.

Different jobs used over the batch: framework 9 (advance, charge, close-in, hold, join, lure, redirect, screen, shoot); no framework 9 (advance, charge, close-in, hold, join, lure, redirect, screen, shoot).

| Job | Side | Picks a game | Share of picks | Claimed (mean VP) | Claimed VP a game | Happened |
| --- | --- | --- | --- | --- | --- | --- |
| Charge | framework | 5.2 | 12% | 121.8 | 556 | net 55 VP in 2 turns; declared 75% |
| Charge | no framework | 4.2 | 10% | 115.6 | 453 | net 56 VP in 2 turns; declared 76% |
| Shoot | framework | 7.7 | 18% | 17.5 | 113 | 5.0 VP of wounds that turn |
| Shoot | no framework | 7.0 | 16% | 20.1 | 116 | 4.7 VP of wounds that turn |
| Hold a marker, the hill, a feature | framework | 5.1 | 12% | 72.7 | 355 | 23.4 VP scored this turn and the enemy's next |
| Hold a marker, the hill, a feature | no framework | 4.5 | 11% | 78.4 | 337 | 25.2 VP scored this turn and the enemy's next |
| Close in to charge next turn | framework | 5.1 | 12% | 59.5 | 296 | charged that target next turn 13% |
| Close in to charge next turn | no framework | 5.3 | 12% | 62.9 | 323 | charged that target next turn 11% |
| Advance on an enemy | framework | 19.6 | 44% | 24.8 | 340 | charged that target next turn 4% |
| Advance on an enemy | no framework | 14.7 | 34% | 35.2 | 333 | charged that target next turn 6% |
| Screen | framework | 0.2 | 0% | 2.6 | 0 | guarded unit lost 0.05 wounds (line said 2.38 a turn) |
| Screen | no framework | 2.9 | 7% | 49.8 | 129 | guarded unit lost 0.30 wounds (line said 5.46 a turn) |
| Redirect | framework | 0.3 | 1% | 0.7 | 0 | enemy charged the guarded friend 0%, the chaff 16% |
| Redirect | no framework | 2.6 | 6% | 23.3 | 41 | enemy charged the guarded friend 1%, the chaff 4% |
| Lure | framework | 0.1 | 0% | -14.0 | -1 | enemy charged the guarded friend 11%, the chaff 22% |
| Lure | no framework | 0.7 | 2% | 114.4 | 77 | enemy charged the guarded friend 19%, the chaff 7% |
| Join a unit | framework | 0.9 | 2% | 48.2 | 24 | - |
| Join a unit | no framework | 0.8 | 2% | 41.7 | 17 | - |

# Doctrine scorecard: fw-h2h2-opp-1eea44e-p3

### Scorecard: fw-h2h2-opp-1eea44e-p3

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0110 | 2 | 1 | Mine | - | - | - | 0 | 3 | 0 | 0 | 0 | 322 |
| L0110 | 2 | 1 | Opponent | - | - | 2 | 2 | 1 | 0 | 0 | 0 | 330 |
| L0126 | 6 | 1 | Mine | no | 4 | - | 0 | 2 | 0 | 0 | 0 | 322 |
| L0126 | 6 | 1 | Opponent | no | 13 | 2 | 2 | 3 | 0 | 0 | 0 | 0 |
| L0210 | 6 | 1 | Mine | no | 4 | 2 | 0 | 3 | 0 | 0 | 0 | 0 |
| L0210 | 6 | 1 | Opponent | no | 6 | 2 | 1 | 1 | 0 | 0 | 0 | 330 |
| L0226 | 4 | 1 | Mine | no | 4 | 3 | 2 | 3 | 0 | 0 | 0 | 442 |
| L0226 | 4 | 1 | Opponent | no | 8 | 2 | 1 | 2 | 1 | 0 | 0 | 0 |
| L0311 | 5 | 1 | Mine | no | - | 3 | 3 | 0 | 0 | 0 | 0 | 590 |
| L0311 | 5 | 1 | Opponent | no | - | - | 2 | 1 | 0 | 0 | 0 | 330 |
| L0327 | 3 | 1 | Mine | no | 4 | 3 | 1 | 0 | 0 | 0 | 0 | 590 |
| L0327 | 3 | 1 | Opponent | yes | 2 | 2 | 2 | 3 | 1 | 0 | 0 | 0 |
| L0413 | 5 | 1 | Mine | yes | - | 2 | 6 | 2 | 0 | 0 | 0 | 0 |
| L0413 | 5 | 1 | Opponent | no | - | 2 | 3 | 1 | 0 | 0 | 0 | 317 |
| L0429 | 3 | 1 | Mine | no | 2 | 3 | 5 | 0 | 0 | 0 | 0 | 0 |
| L0429 | 3 | 1 | Opponent | no | 0 | 2 | 4 | 0 | 0 | 0 | 0 | 170 |
| L0516 | 6 | 1 | Mine | no | 1 | 3 | 2 | 1 | 0 | 0 | 0 | 763 |
| L0516 | 6 | 1 | Opponent | no | 3 | 3 | 2 | 2 | 2 | 0 | 0 | 280 |
| L0533 | 5 | 1 | Mine | no | - | - | 1 | 1 | 0 | 0 | 0 | 548 |
| L0533 | 5 | 1 | Opponent | yes | - | 3 | 2 | 4 | 0 | 0 | 0 | 0 |
| L0620 | 2 | 1 | Mine | - | - | 2 | 4 | 1 | 1 | 0 | 0 | 743 |
| L0620 | 2 | 1 | Opponent | - | - | 5 | 2 | 3 | 0 | 0 | 0 | 305 |
| L0709 | 1 | 1 | Mine | yes | 1 | 2 | 2 | 2 | 0 | 0 | 0 | 420 |
| L0709 | 1 | 1 | Opponent | yes | 1 | 3 | 3 | 0 | 0 | 0 | 0 | 976 |
| L0725 | 5 | 1 | Mine | yes | - | 2 | 2 | 1 | 0 | 0 | 0 | 375 |
| L0725 | 5 | 1 | Opponent | no | - | 3 | 3 | 1 | 0 | 0 | 0 | 0 |
| L0815 | 5 | 1 | Mine | no | - | - | 0 | 1 | 0 | 0 | 0 | 515 |
| L0815 | 5 | 1 | Opponent | yes | - | 2 | 2 | 3 | 1 | 0 | 0 | 115 |
| L0831 | 3 | 1 | Mine | no | 0 | 3 | 1 | 1 | 0 | 0 | 0 | 807 |
| L0831 | 3 | 1 | Opponent | no | 0 | 5 | 1 | 3 | 2 | 0 | 0 | 170 |
| L0922 | 4 | 1 | Mine | no | 1 | 3 | 1 | 0 | 0 | 0 | 0 | 632 |
| L0922 | 4 | 1 | Opponent | no | 0 | 2 | 4 | 1 | 0 | 0 | 0 | 55 |
| L1013 | 5 | 1 | Mine | yes | - | 2 | 3 | 2 | 0 | 0 | 0 | 330 |
| L1013 | 5 | 1 | Opponent | no | - | 1 | 3 | 0 | 2 | 0 | 0 | 317 |
| L1030 | 4 | 1 | Mine | no | 2 | 2 | 2 | 0 | 1 | 0 | 0 | 492 |
| L1030 | 4 | 1 | Opponent | no | 0 | 2 | 2 | 2 | 1 | 0 | 0 | 0 |
| L1122 | 6 | 1 | Mine | no | 4 | 3 | 2 | 0 | 0 | 0 | 0 | 330 |
| L1122 | 6 | 1 | Opponent | no | 0 | 2 | 5 | 1 | 1 | 0 | 0 | 144 |
| L1216 | 4 | 1 | Mine | no | 0 | 2 | 4 | 0 | 0 | 0 | 0 | 330 |
| L1216 | 4 | 1 | Opponent | no | 0 | 2 | 2 | 2 | 1 | 0 | 0 | 536 |
| L1232 | 2 | 1 | Mine | - | - | 3 | 2 | 0 | 0 | 0 | 0 | 547 |
| L1232 | 2 | 1 | Opponent | - | - | 3 | 5 | 3 | 1 | 0 | 0 | 340 |
| L1327 | 1 | 1 | Mine | no | 2 | 3 | 1 | 0 | 0 | 0 | 0 | 479 |
| L1327 | 1 | 1 | Opponent | no | 0 | 1 | 6 | 1 | 0 | 0 | 0 | 0 |
| L1422 | 6 | 1 | Mine | no | 1 | 2 | 4 | 0 | 0 | 0 | 0 | 0 |
| L1422 | 6 | 1 | Opponent | no | 5 | 1 | 6 | 0 | 1 | 0 | 0 | 170 |
| L1519 | 1 | 1 | Mine | no | 6 | 2 | 1 | 0 | 0 | 0 | 0 | 126 |
| L1519 | 1 | 1 | Opponent | no | 0 | 2 | 6 | 0 | 1 | 0 | 0 | 543 |
| L1535 | 5 | 1 | Mine | yes | - | 2 | 1 | 1 | 1 | 0 | 0 | 0 |
| L1535 | 5 | 1 | Opponent | yes | - | 2 | 3 | 4 | 1 | 0 | 0 | 382 |
| L1633 | 1 | 1 | Mine | yes | 13 | 2 | 6 | 1 | 0 | 0 | 0 | 260 |
| L1633 | 1 | 1 | Opponent | no | 0 | 1 | 4 | 2 | 0 | 0 | 0 | 144 |
| L1731 | 3 | 1 | Mine | - | - | - | - | - | - | - | - | - |
| L1731 | 3 | 1 | Opponent | - | - | - | - | - | - | - | - | - |
| L1831 | 1 | 1 | Mine | no | 3 | 3 | 2 | 0 | 0 | 0 | 0 | 0 |
| L1831 | 1 | 1 | Opponent | no | 5 | 3 | 5 | 1 | 3 | 0 | 0 | 170 |
| L1932 | 6 | 1 | Mine | no | 2 | 2 | 4 | 0 | 1 | 0 | 0 | 0 |
| L1932 | 6 | 1 | Opponent | no | 1 | 2 | 1 | 2 | 1 | 0 | 0 | 340 |
| L2033 | 5 | 1 | Mine | yes | - | - | 2 | 3 | 1 | 0 | 0 | 210 |
| L2033 | 5 | 1 | Opponent | yes | - | 3 | 1 | 5 | 0 | 0 | 0 | 0 |
| L2223 | 3 | 1 | Mine | no | 0 | 2 | 3 | 1 | 2 | 0 | 0 | 369 |
| L2223 | 3 | 1 | Opponent | no | 6 | 1 | 8 | 0 | 1 | 0 | 0 | 0 |
| L2327 | 5 | 1 | Mine | yes | - | 2 | 3 | 0 | 0 | 0 | 0 | 311 |
| L2327 | 5 | 1 | Opponent | yes | - | 2 | 6 | 1 | 0 | 0 | 0 | 0 |
| L2433 | 3 | 1 | Mine | no | 4 | 3 | 5 | 2 | 0 | 0 | 0 | 0 |
| L2433 | 3 | 1 | Opponent | no | 0 | 1 | 4 | 2 | 0 | 0 | 0 | 0 |
| L2630 | 2 | 1 | Mine | - | - | 2 | 4 | 0 | 0 | 0 | 0 | 0 |
| L2630 | 2 | 1 | Opponent | - | - | 2 | 2 | 0 | 0 | 0 | 0 | 0 |
| L2832 | 6 | 1 | Mine | no | 1 | - | 0 | 0 | 3 | 0 | 0 | 0 |
| L2832 | 6 | 1 | Opponent | no | 2 | 2 | 3 | 3 | 1 | 0 | 0 | 170 |
| L3133 | 1 | 1 | Mine | no | 1 | 4 | 2 | 2 | 3 | 0 | 0 | 0 |
| L3133 | 1 | 1 | Opponent | no | 4 | 4 | 2 | 3 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 26% | 2.7 | 2.5 | 2.3 | 0.9 | 0.4 | 0.0 | 0.0 | 310.1 |
| **Average** | | | Opponent | 23% | 2.5 | 2.3 | 3.1 | 1.7 | 0.6 | 0.0 | 0.0 | 189.5 |

### KPIs: fw-h2h2-opp-1eea44e-p3

Rules off - Mine only: WAR ENGINE JOBS, STAY WEIGHED, BEST FIRST, RANDOM MOVE BY FIGURES, RANDOM MOVER NO PROMISE, STABLE ROLE, WOUNDED STAYS OUT, BEST FACING, LOST CHARGE, SCREEN BY WHAT IT SAVES, REDIRECT BY WHAT IT STOPS, SHOOTER COUNTED ONCE, LURE BY WHAT IT DRAWS, HILL BY ITS CHANCE, MOVE TO CHARGE, LONG SHOT, DEFENSIVE ARMY, SHOOTS FROM THE BEST SPOT, SUPPORTS, RESERVE FALL BACK, WAIT AFTER COSTS, CHARGE NOW FIRST, SUPPORT NARROWED, WAR ENGINE CHARGES, DEFENSIVE FLOOR.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 174) | 12% (20 of 171) | 6% (20 of 345) |
| Winner chose to follow up after the loser gave ground |  | 99% (66 of 67); on the table 99% | 100% (64 of 64); on the table 100% | 99% (130 of 131); on the table 99% |
| Winner chose to pursue after the loser fell back in good order |  | 86% (6 of 7); on the table 100% | 92% (12 of 13); on the table 92% | 90% (18 of 20); on the table 95% |
| Winner chose to pursue after the loser fled |  | 71% (17 of 24); on the table 71% | 65% (22 of 34); on the table 71% | 67% (39 of 58); on the table 71% |
| Winner chose to follow up or pursue (all three) |  | 91% (89 of 98); on the table 92% | 88% (98 of 111); on the table 90% | 89% (187 of 209); on the table 91% |
| Magic missiles tried each own turn | 50%+ | 27% (91 of 337) | 22% (42 of 187) | 25% (133 of 524) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 43% (91 of 210) | 34% (42 of 125) | 40% (133 of 335) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 42% (22 of 52) | 42% (22 of 52) |
| Points that never fought | lower | 38% (25147 of 66801) | 34% (23704 of 69990) | 36% (48851 of 136791) |
|   infantry points that never fought | lower | 37% (5068 of 13801) | 52% (7304 of 13984) | 45% (12372 of 27785) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 53% (141 of 265) | 61% (167 of 273) | 57% (308 of 538) |
| Bound items with a magic missile used (at least once a game) |  | 92% (23 of 25); 1.8 uses a game | 88% (21 of 24); 1.9 uses a game | 90% (44 of 49); 1.8 uses a game |
| Bound items with another spell used |  | 43% (6 of 14); 0.3 uses a game | 50% (3 of 6); 0.1 uses a game | 45% (9 of 20); 0.2 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 55% (11 of 20); 0.3 uses a game | 43% (6 of 14); 0.2 uses a game | 50% (17 of 34); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 48% (27547 of 57776) | 53% (32726 of 62043) | 50% (60273 of 119819) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.1 (16%) | 1.1 (27%) | 2.2 (20%) |
| MARCHED: its unit marched | 1.6 (24%) | 0.9 (23%) | 2.6 (24%) |
| CHARGED: its unit charged | 0.2 (4%) | 0.2 (6%) | 0.5 (4%) |
| IN COMBAT: engaged in combat | 1.6 (24%) | 0.8 (20%) | 2.4 (23%) |
| REAR RANK: in a rear rank | 0.1 (1%) | 0.0 (1%) | 0.1 (1%) |
| FLEEING: fleeing | 0.1 (2%) | 0.0 (0%) | 0.1 (1%) |
| GONE: slain | 1.4 (21%) | 0.6 (14%) | 2.0 (19%) |
| OFF THE TABLE: off the table or not arrived | 0.3 (4%) | 0.3 (8%) | 0.6 (6%) |
| STUPIDITY: Stupidity | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (1%) | 0.0 (1%) | 0.1 (1%) |
| NOT OFFERED: not in the cast list | 0.1 (2%) | 0.0 (0%) | 0.1 (1%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.5 | 0.9 | 1.9 | 3.7 | 0.8 | 2.4 |
| not cast | 4.3 | 1.7 | 4.3 | 10.9 | 2.5 | 18.3 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.2 (7%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (1%) | 0.5 (28%) | 0.3 (6%) | 2.2 (20%) | 0.2 (8%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.6 (24%) | 0.6 (23%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.5 (4%) | 0.1 (2%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.3 (8%) | 0.2 (13%) | 0.8 (19%) | 2.4 (23%) | 0.4 (17%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.2 (4%) | 0.0 (2%) | 0.2 (5%) | 0.1 (1%) | 0.0 (1%) | 0.0 (0%) |
| FLEEING: fleeing | 0.1 (3%) | 0.0 (0%) | 0.0 (1%) | 0.1 (1%) | 0.1 (4%) | 0.6 (3%) |
| GONE: slain | 0.9 (21%) | 0.3 (18%) | 1.1 (25%) | 2.0 (19%) | 0.5 (20%) | 2.4 (13%) |
| OFF THE TABLE: off the table or not arrived | 0.4 (10%) | 0.3 (18%) | 0.5 (11%) | 0.6 (6%) | 0.2 (10%) | 1.2 (7%) |
| STUPIDITY: Stupidity | 0.2 (4%) | 0.0 (2%) | 0.1 (3%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (1%) | 0.1 (7%) | 0.0 (1%) | 0.1 (1%) | 0.4 (14%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.1 (48%) | 0.2 (12%) | 1.2 (29%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 12.8 (70%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.3 a game | 0.6 a game | 0.9 a game |
| stood (cast and not dispelled) | 76% (28 of 37) | 65% (11 of 17) | 72% (39 of 54) |
| the unit moved after it | 82% (23 of 28) | 100% (11 of 11) | 87% (34 of 39) |
| it charged on its next turn | 7% (2 of 28) | 0% (0 of 11) | 5% (2 of 39) |
| the enemy charged it first | 21% (6 of 28) | 18% (2 of 11) | 21% (8 of 39) |
| it fought by the end of its next turn | 7% (2 of 28) | 9% (1 of 11) | 8% (3 of 39) |
| it moved out of a charge the enemy had planned (not charged first) | 4% (1 of 28) | 9% (1 of 11) | 5% (2 of 39) |
| none of these (no charge, no fight, no charge escaped) | 68% (19 of 28) | 73% (8 of 11) | 69% (27 of 39) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 65% (458 of 710) | 59% (341 of 575) | 62% (799 of 1285) |
|   cavalry | 70% (39 of 56) | 52% (54 of 103) | 58% (93 of 159) |
|   character | 47% (47 of 101) | 23% (25 of 109) | 34% (72 of 210) |
|   chariot | 45% (42 of 94) | 76% (22 of 29) | 52% (64 of 123) |
|   infantry | 55% (99 of 180) | 67% (171 of 254) | 62% (270 of 434) |
|   monster | 48% (10 of 21) | 100% (3 of 3) | 54% (13 of 24) |
|   war machine | 86% (221 of 258) | 86% (66 of 77) | 86% (287 of 335) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.8 (40%) | 1.6 (25%) | 4.4 (33%) |
| CHARGED: it charged | 1.0 (14%) | 1.7 (26%) | 2.7 (20%) |
| FLEEING: it fled or was fleeing | 0.0 (0%) | 0.0 (0%) | 0.1 (0%) |
| IN COMBAT: it fought this turn or the last | 0.8 (11%) | 0.6 (9%) | 1.4 (10%) |
| MOVED: a war machine that moved | 0.0 (0%) | 0.0 (0%) | 0.1 (0%) |
| NO TARGET IN RANGE | 0.6 (9%) | 1.0 (15%) | 1.6 (12%) |
| ONLY IN COMBAT: the only targets were in combat | 0.2 (4%) | 0.2 (4%) | 0.5 (4%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.1 (15%) | 0.8 (13%) | 1.9 (14%) |
| SHELTERED: the target was sheltered | 0.2 (2%) | 0.2 (3%) | 0.4 (3%) |
| STUPIDITY | 0.0 (0%) | 0.1 (1%) | 0.1 (0%) |
| OTHER BAR | 0.3 (4%) | 0.2 (3%) | 0.5 (3%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 4.1 | 1.1 | 81% | 7.9 pts | 32 pts |
| character | 2.4 | 0.8 | 80% | 7.6 pts | 18 pts |
| chariot | 1.8 | 1.3 | 56% | 19.2 pts | 34 pts |
| infantry | 11.2 | 4.3 | 73% | 10.1 pts | 114 pts |
| monster | 0.4 | 0.2 | 75% | 20.1 pts | 9 pts |
| war machine | 8.3 | 6.7 | 67% | 23.2 pts | 193 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.3 | 5.9 | 5.1 |
| Charges that made contact a game | 2.9 | 4.2 | 3.5 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.70 declared, 0.57 contact (23 units) | 0.81 declared, 0.56 contact (16 units) | 0.74 declared, 0.56 contact (39 units) |
|   per unit a game, units carrying another wizard (or one alone) | 1.25 declared, 1.00 contact (4 units) | 1.45 declared, 1.00 contact (11 units) | 1.40 declared, 1.00 contact (15 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.60 declared, 0.39 contact (222 units) | 0.69 declared, 0.49 contact (268 units) | 0.65 declared, 0.44 contact (490 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 60% (45 of 75) | 57% (8 of 14) | 60% (6 of 10) | 60% (59 of 99) |
| Character in a unit | 90% (27 of 30) | 64% (7 of 11) | 25% (1 of 4) | 78% (35 of 45) |
| Character on its own | 83% (35 of 42) | 56% (25 of 45) | 24% (16 of 68) | 49% (76 of 155) |
| Chariot | 73% (8 of 11) | 50% (6 of 12) | - | 61% (14 of 23) |
| Infantry | 54% (36 of 67) | 40% (17 of 42) | 40% (2 of 5) | 48% (55 of 114) |
| Monster | 69% (20 of 29) | 43% (3 of 7) | - | 64% (23 of 36) |
| Monstrous | 70% (7 of 10) | 55% (6 of 11) | - | 62% (13 of 21) |
| War Machines | 74% (32 of 43) | 50% (1 of 2) | - | 73% (33 of 45) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 100% (6 of 6); on the table 100% | 20% (19 of 96) | 37% | 50% (11 of 22) | 67% (4 of 6); 2.8 uses a game | 0% (0 of 2); 0.0 uses a game | 83% (5 of 6); 1.2 uses a game |
| Chaos Dwarfs | 4 | 95% (20 of 21); on the table 95% | 56% (20 of 36) | 41% | 53% (17 of 32) | 0.0 uses a game | 0.0 uses a game | 100% (2 of 2); 0.5 uses a game |
| Dwarfen Mountain Holds | 3 | 60% (3 of 5); on the table 60% | - | 50% | 58% (14 of 24) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 6 | 78% (7 of 9); on the table 78% | 33% (10 of 30) | 46% | 64% (38 of 59) | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game | 0% (0 of 4); 0.0 uses a game |
| Grand Cathay | 8 | 100% (18 of 18); on the table 100% | 24% (47 of 192) | 50% | 57% (42 of 74) | 94% (17 of 18); 5.9 uses a game | 25% (1 of 4); 0.1 uses a game | 38% (3 of 8); 0.4 uses a game |
| High Elf Realms | 7 | 95% (20 of 21); on the table 95% | 24% (10 of 42) | 28% | 56% (30 of 54) | 100% (9 of 9); 4.0 uses a game | 67% (8 of 12); 1.9 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 3 | 100% (9 of 9); on the table 100% | - | 45% | 33% (6 of 18) | 0.0 uses a game | 0.0 uses a game | 67% (2 of 3); 0.7 uses a game |
| Ogre Kingdoms | 1 | 100% (1 of 1); on the table 100% | 0% (0 of 6) | 58% | 14% (1 of 7) | 100% (1 of 1); 4.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 2 | 100% (2 of 2); on the table 100% | 17% (2 of 12) | 1% | 69% (11 of 16) | 0.0 uses a game | 0.0 uses a game | 100% (2 of 2); 1.0 uses a game |
| Skaven | 2 | 67% (4 of 6); on the table 83% | 25% (3 of 12) | 41% | 50% (7 of 14) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.5 uses a game |
| Tomb Kings of Khemri | 6 | 93% (13 of 14); on the table 93% | 0% (0 of 6) | 24% | 42% (11 of 26) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 8 | 92% (37 of 40); on the table 92% | 22% (12 of 54) | 24% | 52% (24 of 46) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 10 | 76% (32 of 42); on the table 81% | 29% (7 of 24) | 31% | 64% (54 of 84) | 100% (3 of 3); 1.1 uses a game | 0.0 uses a game | 100% (2 of 2); 0.2 uses a game |
| Wood Elf Realms | 6 | 100% (15 of 15); on the table 100% | 17% (2 of 12) | 39% | 68% (42 of 62) | 82% (9 of 11); 5.0 uses a game | 0.0 uses a game | 0% (0 of 5); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (fw-h2h2-opp-1eea44e-p3, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 35% (28) | 40% (28) | 37% (56) |
| ...free all their last turn and able to turn (per game) | 0.39 | 0.39 | 0.78 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.08 | 0.19 | 0.28 |
| ...with the charger already in that arc before they moved (per game) | 0.22 | 0.19 | 0.42 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 1.06 | 1.28 | 2.33 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.83 | 0.56 | 1.39 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 5.97 | 5.86 | 11.83 |

### Quality by phase: fw-h2h2-opp-1eea44e-p3

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.2 | 3.6 |
| Strategy | Charge objectives carried out (made contact) | 50% (63 of 127) | 46% (93 of 202) |
| Strategy | Shoot objectives carried out (shot that target) | 49% (165 of 335) | 55% (98 of 178) |
| Strategy | Close-in objectives charged next turn | 16% (24 of 153) | 17% (39 of 225) |
| Strategy | Support requests answered (helper made contact too) | 58% (11 of 19) | 52% (14 of 27) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (4 of 4) | 100% (1 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | 20% (2 of 10) | 50% (2 of 4) |
| Strategy | Joined characters whose unit fought | 49% (17 of 35) | 27% (9 of 33) |
| Strategy | Lone characters that fought | 71% (69 of 97) | 86% (83 of 96) |
| Movement | Charges halted short of contact | 0.3 | 0.4 |
| Movement | Idle units | 0.9 | 1.7 |
| Movement | Points that never moved of their own | 310.1 | 189.5 |
| Movement | Fights charged into per game | 2.6 | 3.6 |
| Movement | Charges with odds: long shots (under 50%) | 14 of 82, net +115 | 19 of 110, net +11 |
| Movement | Charges with odds: sweet spot (55-75%) | 7 of 82, net +69 | 17 of 110, net +75 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 10 of 82, net +79 | 13 of 110, net +79 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 27 of 82, net +116 | 35 of 110, net +147 |
| Shooting | Shots by shooting units (incl. breath weapons) | 7.2 | 9.4 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 43% (110 of 258) | 36% (122 of 338) |
| Shooting | Points destroyed by shooting units | 68.8 | 36.4 |
| Shooting | War machine shots | 6.1 | 2.2 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 50% (110 of 221) | 29% (23 of 79) |
| Shooting | Points destroyed by war machines | 66.8 | 25.5 |
| Magic | Magic missiles cast | 1.8 | 0.7 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 38% (25 of 65) | 12% (3 of 24) |
| Magic | Wounds caused by magic missiles | 3.5 | 1.5 |
| Magic | Wounds caused by other spells | 1.7 | 0.8 |
| Magic | Points destroyed by magic (all spells) | 94.4 | 36.8 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.1 / 0.3 / 0.8 / 0.2 | 2.1 / 0.2 / 0.4 / 0.4 |
| Combat | Points destroyed in combat | 330.7 | 388.2 |
| Combat | Points run down | 128.8 | 134.8 |
| Combat | Net points per charged fight, damage counted | +107 | +81 |
| Combat | Net per 100 charger points, damage counted | +36.2 | +27.7 |
| Combat | First round won (charged fights) | 66% | 59% |
| Combat | Net points per charged fight | +112 | +78 |
| Combat | Net points per supported fight / lone fight | +139 / +107 | +125 / +68 |
| Combat | Charged fights on a top-3 enemy unit | 29 of 90 | 64 of 126 |
| Game | Points lost | 781.0 | 791.3 |
| Game | VP from objectives | 526.9 | 509.7 |
| Game | Lone holders (player turns) | 2.7 | 2.5 |

- Mine won / drew / lost: 16 / 2 / 17 of 35 ended games (of 36); mean margin (Mine - Opponent) -38 VP
- The side that went first won 16 of 33 games with a winner
- Points traded per game (both sides' losses): 1572
- Games not ended: 1 (L1731-1); findings 1, warnings 0

### Opponent rules: fw-h2h2-opp-1eea44e-p3

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.6 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| ALREADY CARRIED | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARRIVAL HUNT | 0.0 | +0.1 | 0.0 | 0.0 | 0.1 | +0.4 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.8 | +0.0 | 0.0 | 41.0 | 0.2 | +0.0 | 0.0 | 8.1 |
| BACKUP TARGETS | 1.1 | +8.5 | 0.0 | 9.6 | 1.0 | +10.9 | 0.0 | 7.9 |
| BEST FACING | - | - | - | - | 0.8 | +36.9 | 0.0 | 30.4 |
| BEST FIRST | - | - | - | - | 3.2 | +148.5 | 76.1 | 55.9 |
| BEST OVERALL | 0.4 | +13.8 | 0.0 | 5.2 | 0.5 | +25.2 | 0.0 | 25.1 |
| BEST PREY | 4.2 | +288.9 | 200.9 | 134.0 | 0.5 | +22.7 | 14.4 | 9.4 |
| BEST PRIZE | - | - | - | - | 0.0 | -1.1 | 8.4 | 0.0 |
| BIG CHARACTER SAFETY | 0.1 | -1.3 | 0.0 | 0.0 | 0.2 | -0.0 | 0.0 | 25.4 |
| BLOCKED CHARGE SKIPPED | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 3.5 | 6.2 |
| BLOCKED WHEEL | 0.4 | +6.2 | 0.0 | 0.0 | 0.4 | +6.2 | 0.0 | 9.2 |
| BOMBING RUN | 0.0 | +0.8 | 0.0 | 0.0 | - | - | - | - |
| CANNON PLAN MISSED | 0.7 | +0.0 | 100.2 | 12.8 | 0.2 | +0.0 | 45.7 | 9.2 |
| CANNON PLANNED TARGET | 5.0 | +161.2 | 351.1 | 118.5 | 1.2 | +76.9 | 80.9 | 32.9 |
| CANNON SIGHT KEPT | 1.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT COUNTER | 0.0 | +0.0 | 10.2 | 2.5 | - | - | - | - |
| CARRIES OUT SET-UP | 0.2 | -7.5 | 13.1 | 10.2 | 0.2 | -4.2 | 20.1 | 4.5 |
| CAST JOB | 1.1 | +35.1 | 91.4 | 0.0 | 0.4 | +16.4 | 43.6 | 21.9 |
| CASTER AWAY FROM SCREEN | 0.2 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.4 | +41.5 | 25.3 | 6.1 | 0.1 | +0.4 | 0.0 | 2.9 |
| CASTS AFTER FRIENDS | 0.8 | +0.0 | 0.0 | 12.5 | 0.4 | +0.0 | 0.0 | 17.6 |
| CASTS FROM BEHIND | 0.0 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.1 | +1.8 | 0.0 | 6.1 | - | - | - | - |
| CHAFF PASSED | 0.2 | -0.3 | 0.0 | 9.8 | 0.3 | -1.6 | 22.5 | 6.6 |
| CHARGE NOW FIRST | - | - | - | - | 3.4 | +0.0 | 320.3 | 92.6 |
| CHARGE NOW WEIGHED | 0.8 | -43.9 | 24.7 | 18.1 | 0.4 | -24.8 | 8.3 | 0.8 |
| CHARIOT NO STATIC JOB | 0.4 | +0.0 | 0.0 | 13.1 | - | - | - | - |
| CHARIOT WIZARD CAREFUL | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | -1.3 | 8.3 | 11.1 |
| CHEAP HELPER | 0.1 | +0.0 | 0.0 | 2.4 | 0.1 | +0.0 | 1.9 | 3.1 |
| COMBAT PIVOT | 0.6 | +0.0 | 49.3 | 50.2 | 0.3 | +0.0 | 5.4 | 22.6 |
| CONVEYANCE SEARCH | 0.6 | +49.9 | 5.7 | 12.5 | 0.4 | +33.0 | 16.8 | 29.4 |
| COUNTER-CHARGE COVER | 7.9 | +572.3 | 0.0 | 193.6 | 7.2 | +655.2 | 0.0 | 150.9 |
| DEFENSIVE ARMY | - | - | - | - | 0.2 | +0.0 | 12.4 | 13.1 |
| EDGE GIVE GROUND | 0.2 | +5.9 | 28.1 | 3.4 | 0.3 | +4.7 | 37.6 | 1.2 |
| ELIXIR WORTH | 0.0 | +0.6 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 1.1 | +81.7 | 0.0 | 29.6 | 1.3 | +95.3 | 0.0 | 56.6 |
| FALLBACK BY WORTH | 5.6 | +96.4 | 0.0 | 119.2 | 5.4 | +67.7 | 0.0 | 33.7 |
| FIGHT LIFT | 0.0 | +0.5 | 3.2 | 0.0 | - | - | - | - |
| FIRE AND FLEE | 0.1 | +0.3 | 0.0 | 3.1 | 0.0 | +0.1 | 1.8 | 0.0 |
| FLANK NOT WEIGHED | 5.6 | +0.0 | 0.0 | 158.8 | 6.0 | +0.0 | 0.0 | 124.8 |
| FOCUS FIRE | - | - | - | - | 0.0 | +0.3 | 0.0 | 0.0 |
| FOLLOW UP WEIGHED | 1.1 | +152.5 | 0.0 | 50.7 | 1.2 | +204.2 | 0.0 | 39.8 |
| FRIENDS SHOTS CHECKED | 0.5 | +25.2 | 0.0 | 29.0 | 0.2 | +13.3 | 0.0 | 7.2 |
| GIVES UP | 1.0 | -27.6 | 128.9 | 33.0 | 0.1 | -1.5 | 21.2 | 0.0 |
| GIVES UP ITS SCREEN | 0.6 | -22.5 | 45.5 | 15.3 | 0.1 | -0.7 | 7.9 | 1.5 |
| GROUND FLIERS | 0.1 | +3.1 | 0.0 | 0.0 | 0.0 | +0.7 | 0.0 | 0.0 |
| HELPER ALREADY ASKED | 0.0 | +0.0 | 9.3 | 0.0 | 0.1 | +0.0 | 13.4 | 0.0 |
| HELPER UNSEEN | 0.2 | +0.0 | 55.3 | 1.2 | 0.5 | +0.0 | 41.3 | 1.8 |
| HILL BY ITS CHANCE | - | - | - | - | 0.4 | -53.3 | 0.0 | 4.5 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HORN WORTH | - | - | - | - | 0.1 | +1.8 | 0.0 | 0.0 |
| HUNT ADVANCE | 0.2 | +14.8 | 13.8 | 7.6 | 0.1 | +2.3 | 8.9 | 0.0 |
| HUNT DROPPED | 0.0 | +0.0 | 0.0 | 1.4 | 0.1 | +0.0 | 5.4 | 2.0 |
| HUNT IN PAIRS | 0.4 | +14.4 | 0.0 | 12.1 | 0.7 | +40.3 | 0.0 | 13.9 |
| HUNT KEPT | 0.2 | +7.0 | 18.3 | 3.1 | 0.0 | +1.0 | 3.5 | 0.0 |
| HUNT RESULT | 0.1 | +21.6 | 0.0 | 1.4 | 0.2 | +20.3 | 8.9 | 2.0 |
| HUNT THE GUNS | 0.1 | +61.7 | 9.2 | 4.5 | 0.2 | +44.3 | 15.4 | 0.0 |
| INVITES THE FIGHT | - | - | - | - | 1.2 | +22.6 | 48.9 | 12.3 |
| JOINT CHARGE PLAN | 0.1 | +0.4 | 9.3 | 12.1 | 0.2 | +3.1 | 17.5 | 3.2 |
| KEEP FALLS | 0.1 | +0.9 | 0.0 | 0.0 | - | - | - | - |
| KEEPS ITS PREY | 0.3 | +1.8 | 18.0 | 13.6 | 0.1 | +0.8 | 2.9 | 4.7 |
| KEEPS ITS TARGET | 1.4 | +41.7 | 163.1 | 37.3 | 2.2 | +67.5 | 171.0 | 55.9 |
| KEEPS SCOUTS OR AMBUSH | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KILLS COUNT | 1.7 | +82.7 | 157.8 | 48.5 | 2.4 | +101.3 | 167.6 | 48.6 |
| KILLS COUNT NEXT TURN | 8.4 | +289.5 | 484.1 | 226.2 | 6.8 | +241.5 | 233.0 | 149.8 |
| LONE CHARACTER SAFE SPOT | 0.6 | +18.1 | 12.4 | 4.5 | 0.4 | +15.9 | 32.4 | 1.4 |
| LONE WIZARD HOLDS BACK | 0.1 | +0.0 | 0.0 | 5.4 | 0.6 | +0.0 | 15.0 | 16.0 |
| LONE WIZARD KEPT IN | 0.6 | +37.3 | 0.0 | 0.0 | 0.3 | +22.1 | 0.0 | 0.0 |
| LONG SHOT | - | - | - | - | 0.4 | -2.1 | 8.7 | 7.8 |
| LOST CHARGE | - | - | - | - | 2.6 | -35.6 | 104.2 | 78.2 |
| LURE BY WHAT IT DRAWS | - | - | - | - | 0.1 | -4.3 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 1.1 | +96.6 | 59.2 | 20.6 | 0.8 | +67.8 | 40.1 | 16.2 |
| MANOEUVRE | 0.2 | +9.0 | 0.0 | 0.0 | 0.1 | +3.1 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.1 | +0.4 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| MARCH CHECK | 0.8 | +38.5 | 0.0 | 19.2 | 0.5 | +20.5 | 0.0 | 9.8 |
| MARCH ODDS | 0.9 | +57.7 | 36.0 | 0.0 | 0.3 | +17.2 | 9.0 | 6.5 |
| MARCH OVER CASTS | 0.6 | +27.1 | 0.0 | 29.5 | 0.5 | +19.2 | 0.0 | 6.5 |
| MAX FOR POSITIONING | 4.4 | +177.7 | 0.0 | 95.3 | 4.8 | +220.7 | 0.0 | 76.1 |
| MISSILES IN THE MOVE | 4.0 | +144.0 | 0.0 | 68.9 | 3.4 | +66.3 | 0.0 | 115.4 |
| MISSILES NEXT TURN | 4.9 | +92.8 | 0.0 | 114.9 | 4.2 | +46.5 | 0.0 | 103.0 |
| MODEL FACING | 0.0 | +2.9 | 0.0 | 0.0 | - | - | - | - |
| MONSTER WIZARD ROAMS | 0.2 | +0.0 | 40.3 | 12.1 | 0.1 | +0.0 | 0.0 | 0.0 |
| MOVE AND CAST | 0.3 | +17.2 | 0.0 | 0.0 | 0.3 | +14.3 | 0.0 | 0.0 |
| MOVE SPELL IN RANGE | 0.2 | +8.2 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.6 | -11.4 | 0.0 | 50.7 | 0.1 | -0.9 | 0.0 | 13.0 |
| MOVE SPELL SPOT | 0.6 | +0.0 | 0.0 | 17.8 | 0.1 | +0.0 | 0.0 | 11.1 |
| MOVE TO CHARGE | - | - | - | - | 4.7 | +491.6 | 168.3 | 98.4 |
| MOVES UNITS SPELL | 0.1 | +3.6 | 0.0 | 0.0 | 0.1 | +0.3 | 0.0 | 0.0 |
| NEEDED THERE | 0.1 | +6.3 | 5.4 | 0.0 | 0.0 | +6.3 | 4.5 | 0.0 |
| NO RALLY LEFT | 0.1 | +0.7 | 0.0 | 0.0 | 0.0 | +1.2 | 0.0 | 0.0 |
| NOT NEEDED | 0.1 | -5.6 | 7.1 | 1.7 | 0.4 | -23.3 | 25.6 | 9.1 |
| NOT TURNED | 6.0 | +86.4 | 0.0 | 164.4 | 5.9 | +72.5 | 0.0 | 61.3 |
| NOT WORTH A CAST | 0.6 | -0.4 | 0.0 | 31.0 | 0.7 | -0.8 | 0.0 | 0.0 |
| OFF BEST | 16.4 | -939.5 | 41.6 | 363.1 | 14.7 | -857.9 | 14.8 | 216.1 |
| OPENS A LANE | 0.1 | +0.1 | 6.7 | 0.0 | 0.2 | +0.6 | 5.3 | 4.6 |
| OPENS UP | 0.4 | +31.0 | 17.5 | 0.0 | 0.2 | +24.6 | 10.5 | 10.2 |
| OVERRUNS AWAY | 0.5 | +21.3 | 42.4 | 9.0 | 0.6 | +13.0 | 60.3 | 17.4 |
| PATHS CROSS | 2.1 | +109.8 | 0.0 | 16.3 | 2.4 | +235.9 | 0.0 | 35.2 |
| PERIAPT WORTH | - | - | - | - | 0.0 | +1.6 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.1 | -0.8 | 0.0 | 0.0 | 0.1 | -0.4 | 0.0 | 0.0 |
| PLAN RESULT | 34.9 | +1417.9 | 1484.5 | 967.1 | 36.2 | +1303.9 | 1521.3 | 1082.3 |
| PURSUES BIG PREY | 0.1 | -6.0 | 0.0 | 0.0 | 0.1 | -4.4 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE | - | - | - | - | 0.1 | +11.5 | 0.0 | 1.5 |
| RAIDS THE BAGGAGE NEXT TURN | 0.1 | +9.6 | 0.0 | 1.5 | 0.1 | +2.6 | 0.0 | 1.5 |
| RANDOM MOVE BY FIGURES | - | - | - | - | 1.4 | +20.5 | 0.0 | 51.9 |
| RANDOM MOVER NO PROMISE | - | - | - | - | 0.5 | -21.4 | 31.1 | 14.2 |
| REDIRECT BY WHAT IT STOPS | - | - | - | - | 0.5 | -9.5 | 0.0 | 4.5 |
| REDIRECT COUNTER | 2.5 | +157.4 | 0.0 | 51.0 | 3.6 | +287.8 | 0.0 | 43.6 |
| REDIRECT WEIGHED | 0.4 | +20.6 | 21.0 | 7.3 | 0.3 | +10.1 | 10.8 | 10.2 |
| RESERVE FALL BACK | - | - | - | - | 0.8 | +26.7 | 0.0 | 11.7 |
| RESTRAINS TO SHOOT | 0.1 | +5.5 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | 2.6 | +104.5 | 293.3 | 85.9 | 3.3 | +63.1 | 275.9 | 115.6 |
| SAFER THAN THE JOB | 0.8 | +39.0 | 0.0 | 22.5 | 0.6 | +33.5 | 0.0 | 21.1 |
| SCOUT SPOT | 0.4 | +0.3 | 0.0 | 0.0 | 0.3 | +0.8 | 0.0 | 0.0 |
| SCOUT WAITS | 0.4 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 0.4 | -27.1 | 0.0 | 2.4 |
| SEARCH SPOT | 1.6 | +92.1 | 0.0 | 52.4 | 2.2 | +144.2 | 0.0 | 15.9 |
| SECOND HUNTER | 0.1 | -1.3 | 4.6 | 1.4 | - | - | - | - |
| SELF MOVE SPELL | 0.4 | +61.4 | 0.0 | 9.1 | 0.2 | +44.9 | 0.0 | 20.0 |
| SET UP TOGETHER | 1.4 | +135.1 | 87.2 | 35.8 | 1.7 | +208.7 | 70.2 | 23.1 |
| SET-UP ANY TARGET | 0.4 | +52.2 | 0.0 | 2.6 | 0.2 | +27.1 | 12.5 | 22.9 |
| SET-UP MISSED | 0.0 | +6.0 | 0.0 | 0.0 | - | - | - | - |
| SHOOTER COUNTED ONCE | - | - | - | - | 0.0 | -0.0 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.3 | +0.6 | 0.0 | 0.0 | 0.1 | +0.3 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | - | - | - | - | 0.7 | +20.5 | 18.4 | 28.8 |
| SHORT GUN FORWARD | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SHOT REPLANNED | 0.4 | +0.0 | 67.5 | 8.2 | 0.2 | +0.0 | 42.2 | 1.5 |
| SHOTS IN THE MOVE | 11.8 | +517.8 | 0.0 | 219.2 | 9.2 | +338.9 | 0.0 | 171.2 |
| SPELL CATCH ODDS | 0.1 | -1.9 | 0.0 | 0.0 | 0.0 | -0.0 | 0.0 | 0.0 |
| SPELL SETS UP CHARGE | 0.4 | +53.0 | 0.0 | 2.6 | 0.2 | +27.1 | 12.5 | 22.9 |
| SPELL WORTH | 1.3 | +17.0 | 30.9 | 37.6 | 2.2 | +25.9 | 67.5 | 49.4 |
| STABLE ROLE | - | - | - | - | 8.7 | +0.0 | 325.4 | 140.7 |
| STANDS TO CAST | 0.0 | +1.8 | 1.5 | 0.0 | 0.0 | +2.0 | 0.0 | 3.0 |
| STAY WEIGHED | - | - | - | - | 0.1 | +5.3 | 0.0 | 2.9 |
| STOPS | 0.0 | +2.3 | 4.6 | 0.0 | 0.1 | +3.0 | 10.0 | 0.0 |
| STOPS SHORT OF THE FLANK | 0.4 | +18.9 | 0.0 | 0.0 | 0.6 | +41.3 | 0.0 | 34.9 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 4.7 | 0.2 | +0.0 | 0.0 | 9.4 |
| SUPPORT NARROWED | - | - | - | - | 7.1 | -42.6 | 535.1 | 134.1 |
| SUPPORTS | - | - | - | - | 4.0 | +52.3 | 295.4 | 55.4 |
| SURE CHARGE BEATS ADVANCE | 0.1 | -2.7 | 3.8 | 0.0 | 0.0 | -1.8 | 0.0 | 0.0 |
| SURE REACH TOGETHER | 0.3 | +6.7 | 0.0 | 12.1 | 0.6 | +1.3 | 0.0 | 16.1 |
| THROUGH LINE OF FIRE | 0.3 | +9.1 | 0.0 | 7.4 | 0.1 | +12.6 | 0.0 | 0.0 |
| TURN WORTH | 0.5 | -44.1 | 36.8 | 9.7 | 0.6 | -48.2 | 46.6 | 4.6 |
| TWO OR MORE ARRIVE | 0.5 | +4.7 | 13.6 | 4.5 | 0.5 | +8.7 | 20.6 | 13.3 |
| WAIT AFTER COSTS | - | - | - | - | 7.3 | -440.4 | 257.6 | 128.9 |
| WALKS TO THE FIGHT | - | - | - | - | 1.0 | +16.4 | 34.8 | 8.7 |
| WAR ENGINE JOBS | - | - | - | - | 0.1 | +0.0 | 11.9 | 3.8 |
| WEARS DOWN | 1.0 | +49.7 | 151.2 | 30.7 | 1.5 | +62.5 | 161.8 | 43.8 |
| WHO HITS BACK | 0.2 | +24.3 | 0.0 | 13.9 | 0.2 | +18.4 | 0.0 | 0.0 |
| WHOLE FIGHT | 0.2 | +5.7 | 57.4 | 5.7 | 0.7 | +14.5 | 89.0 | 7.8 |
| WHOLE FIGHT GAIN | 0.3 | +18.6 | 28.6 | 8.9 | 0.6 | +47.5 | 50.4 | 8.3 |
| WOUNDED STAYS OUT | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |

### Rule changes: fw-h2h2-opp-1eea44e-p3

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 1121 | 1121 | 1121 | 31.14 | -64709 | -57.7 |
| PATHS CROSS | 163 | 163 | 163 | 4.53 | +12445 | +76.4 |
| KILLS COUNT NEXT TURN | 547 | 546 | 153 | 4.25 | +3484 | +22.8 |
| SEARCH SPOT | 137 | 137 | 134 | 3.72 | +8506 | +63.5 |
| COUNTER-CHARGE COVER | 541 | 264 | 118 | 3.28 | +7272 | +61.6 |
| BEST FIRST | 115 | 115 | 115 | 3.19 | +5344 | +46.5 |
| MOVE TO CHARGE | 169 | 169 | 102 | 2.83 | +8330 | +81.7 |
| FALLBACK BY WORTH | 397 | 397 | 95 | 2.64 | +5910 | +62.2 |
| FACES THE THREAT | 84 | 84 | 84 | 2.33 | +6372 | +75.9 |
| FOLLOW UP WEIGHED | 84 | 84 | 84 | 2.33 | +12842 | +152.9 |
| BEST PREY | 171 | 169 | 79 | 2.19 | +2984 | +37.8 |
| ARTILLERY RE-ROLL WEIGHED | 72 | 72 | 72 | 2.00 | +0 | +0.0 |
| SHOTS IN THE MOVE | 754 | 481 | 63 | 1.75 | +1548 | +24.6 |
| SET UP TOGETHER | 113 | 90 | 57 | 1.58 | +5199 | +91.2 |
| CANNON SIGHT KEPT | 56 | 56 | 56 | 1.56 | +0 | +0.0 |
| RISK BY ARC | 212 | 196 | 53 | 1.47 | +1789 | +33.8 |
| SAFER THAN THE JOB | 50 | 50 | 50 | 1.39 | +2610 | +52.2 |
| MAX FOR POSITIONING | 328 | 153 | 48 | 1.33 | +495 | +10.3 |
| CANNON PLANNED TARGET | 222 | 222 | 44 | 1.22 | -437 | -9.9 |
| REDIRECT COUNTER | 220 | 105 | 44 | 1.22 | +3527 | +80.2 |
| SUPPORTS | 143 | 143 | 43 | 1.19 | +542 | +12.6 |
| CHARGE NOW WEIGHED | 42 | 42 | 42 | 1.17 | +1474 | +35.1 |
| MARCH ODDS | 42 | 42 | 41 | 1.14 | +718 | +17.5 |
| HOLDS AMBUSHERS | 39 | 39 | 39 | 1.08 | +0 | +0.0 |
| MARCH CHECK | 47 | 44 | 34 | 0.94 | +2385 | +70.1 |
| STOPS SHORT OF THE FLANK | 34 | 34 | 34 | 0.94 | +2166 | +63.7 |
| BEST OVERALL | 33 | 33 | 33 | 0.92 | +1403 | +42.5 |
| COMBAT PIVOT | 33 | 33 | 33 | 0.92 | +0 | +0.0 |
| ADVANCE LANE KEPT | 32 | 32 | 32 | 0.89 | +0 | +0.0 |
| LONE WIZARD KEPT IN | 32 | 32 | 32 | 0.89 | +2140 | +66.9 |
| MISSILES IN THE MOVE | 266 | 144 | 31 | 0.86 | +738 | +23.8 |
| BLOCKED WHEEL | 30 | 30 | 30 | 0.83 | +445 | +14.8 |
| WAIT AFTER COSTS | 262 | 262 | 30 | 0.83 | +441 | +14.7 |
| KILLS COUNT | 149 | 143 | 28 | 0.78 | +1165 | +41.6 |
| BEST FACING | 27 | 27 | 27 | 0.75 | +1329 | +49.2 |
| RESERVE FALL BACK | 27 | 27 | 27 | 0.75 | +960 | +35.6 |
| CAST JOB | 56 | 56 | 26 | 0.72 | +805 | +31.0 |
| KEEPS ITS TARGET | 131 | 131 | 26 | 0.72 | +401 | +15.4 |
| SCOUT WAITS | 25 | 25 | 25 | 0.69 | +0 | +0.0 |
| FRIENDS SHOTS CHECKED | 23 | 23 | 23 | 0.64 | +1387 | +60.3 |
| REDIRECT WEIGHED | 23 | 23 | 23 | 0.64 | +1570 | +68.3 |
| MAKE SURE TOGETHER | 68 | 43 | 22 | 0.61 | +1296 | +58.9 |
| RANDOM MOVE BY FIGURES | 52 | 52 | 22 | 0.61 | +736 | +33.5 |
| SHOT REPLANNED | 22 | 22 | 22 | 0.61 | +0 | +0.0 |
| CHAFF PASSED | 21 | 21 | 21 | 0.58 | -70 | -3.3 |
| MOVE AND CAST | 21 | 21 | 21 | 0.58 | +1132 | +53.9 |
| CHARGE NOW FIRST | 121 | 121 | 19 | 0.53 | -1151 | -60.6 |
| WEARS DOWN | 90 | 83 | 19 | 0.53 | +816 | +43.0 |
| SHOOTERS IN TWO RANKS | 17 | 17 | 17 | 0.47 | +32 | +1.9 |
| WHOLE FIGHT GAIN | 33 | 30 | 17 | 0.47 | +823 | +48.4 |
| WALKS TO THE FIGHT | 37 | 37 | 16 | 0.44 | +223 | +14.0 |
| WHO HITS BACK | 16 | 16 | 16 | 0.44 | +1191 | +74.4 |
| SHOOTS FROM THE BEST SPOT | 25 | 25 | 15 | 0.42 | +360 | +24.0 |
| THROUGH LINE OF FIRE | 15 | 15 | 15 | 0.42 | +781 | +52.0 |
| CASTING BLOCK | 17 | 17 | 14 | 0.39 | +823 | +58.8 |
| BIG CHARACTER SAFETY | 12 | 12 | 12 | 0.33 | -48 | -4.0 |
| INVITES THE FIGHT | 42 | 42 | 12 | 0.33 | +144 | +12.0 |
| LONE WIZARD HOLDS BACK | 23 | 23 | 12 | 0.33 | -370 | -30.8 |
| CASTER AWAY FROM SCREEN | 10 | 10 | 10 | 0.28 | +0 | +0.0 |
| CHARIOT NO STATIC JOB | 14 | 14 | 10 | 0.28 | -1310 | -131.0 |
| STUCK PIVOT | 10 | 10 | 10 | 0.28 | +0 | +0.0 |
| CASTS FROM BEHIND | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| MANOEUVRE | 10 | 10 | 9 | 0.25 | +435 | +48.4 |
| OPENS UP | 23 | 20 | 9 | 0.25 | +405 | +45.0 |
| BACKUP TARGETS | 73 | 29 | 8 | 0.22 | +40 | +5.0 |
| HUNT IN PAIRS | 40 | 25 | 8 | 0.22 | +320 | +40.0 |
| WHOLE FIGHT | 33 | 30 | 8 | 0.22 | +306 | +38.3 |
| MOVES UNITS SPELL | 7 | 7 | 7 | 0.19 | +141 | +20.1 |
| OVERRUNS AWAY | 38 | 34 | 7 | 0.19 | +232 | +33.2 |
| PIVOT GUARDS FLANK | 7 | 7 | 7 | 0.19 | -44 | -6.3 |
| LOST CHARGE | 92 | 91 | 6 | 0.17 | +113 | +18.9 |
| MISSILES NEXT TURN | 329 | 180 | 6 | 0.17 | +37 | +6.1 |
| PURSUES BIG PREY | 6 | 6 | 6 | 0.17 | -377 | -62.9 |
| DEFENSIVE ARMY | 7 | 7 | 5 | 0.14 | -374 | -74.8 |
| HUNT ADVANCE | 11 | 11 | 5 | 0.14 | +237 | +47.5 |
| RAIDS THE BAGGAGE NEXT TURN | 6 | 6 | 5 | 0.14 | +101 | +20.2 |
| SHORT GUN FORWARD | 5 | 5 | 5 | 0.14 | +0 | +0.0 |
| BLOCKED CHARGE SKIPPED | 4 | 4 | 4 | 0.11 | +0 | +0.0 |
| CARRIES OUT SET-UP | 13 | 13 | 4 | 0.11 | -422 | -105.5 |
| SUPPORT NARROWED | 256 | 256 | 4 | 0.11 | -26 | -6.5 |
| SURE CHARGE BEATS ADVANCE | 4 | 4 | 4 | 0.11 | -163 | -40.8 |
| FIRE AND FLEE | 3 | 3 | 3 | 0.08 | +16 | +5.2 |
| HORN WORTH | 3 | 3 | 3 | 0.08 | +64 | +21.2 |
| NEEDED THERE | 3 | 3 | 3 | 0.08 | +0 | +0.0 |
| NO RALLY LEFT | 3 | 3 | 3 | 0.08 | +8 | +2.6 |
| RESTRAINS TO SHOOT | 3 | 3 | 3 | 0.08 | +197 | +65.7 |
| SURE REACH TOGETHER | 31 | 21 | 3 | 0.08 | +45 | +15.1 |
| ELIXIR WORTH | 2 | 2 | 2 | 0.06 | +22 | +10.8 |
| KEEP FALLS | 2 | 2 | 2 | 0.06 | +101 | +50.6 |
| RAIDS THE BAGGAGE | 2 | 2 | 2 | 0.06 | +302 | +151.1 |
| STANDS TO CAST | 2 | 2 | 2 | 0.06 | +4 | +2.0 |
| STAY WEIGHED | 2 | 2 | 2 | 0.06 | +189 | +94.6 |
| STOPS | 5 | 5 | 2 | 0.06 | +45 | +22.3 |
| WAR ENGINE JOBS | 4 | 4 | 2 | 0.06 | -29 | -14.5 |
| BEST PRIZE | 1 | 1 | 1 | 0.03 | -41 | -41.2 |
| BOMBING RUN | 1 | 1 | 1 | 0.03 | +27 | +27.1 |
| EDGE GIVE GROUND | 16 | 16 | 1 | 0.03 | +17 | +16.6 |
| FOCUS FIRE | 1 | 1 | 1 | 0.03 | +12 | +11.8 |
| GIVES UP | 41 | 36 | 1 | 0.03 | +6 | +5.8 |
| JOINT CHARGE PLAN | 9 | 9 | 1 | 0.03 | +1 | +0.9 |
| KEEPS SCOUTS OR AMBUSH | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| MODEL FACING | 1 | 1 | 1 | 0.03 | +105 | +105.0 |
| MOVE SPELL IN RANGE | 8 | 5 | 1 | 0.03 | +7 | +7.1 |
| OPENS A LANE | 9 | 1 | 1 | 0.03 | +4 | +4.5 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.03 | +56 | +56.5 |
| TWO OR MORE ARRIVE | 35 | 29 | 1 | 0.03 | +23 | +22.8 |
| WOUNDED STAYS OUT | 1 | 1 | 1 | 0.03 | -84 | -84.0 |
| ALREADY CARRIED | 1 | not checked | - | - | - | - |
| ARRIVAL HUNT | 3 | 3 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 34 | 34 | 0 | 0.00 | - | - |
| CARRIES OUT COUNTER | 1 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 44 | trace | - | - | - | - |
| CATCH FLIERS | 2 | not checked | - | - | - | - |
| CHARIOT WIZARD CAREFUL | 6 | 6 | 0 | 0.00 | - | - |
| CHEAP HELPER | 5 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 36 | not checked | - | - | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT LIFT | 1 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 418 | not checked | - | - | - | - |
| GIVES UP ITS SCREEN | 24 | 22 | 0 | 0.00 | - | - |
| GROUND FLIERS | 3 | not checked | - | - | - | - |
| HELPER ALREADY ASKED | 4 | not checked | - | - | - | - |
| HELPER UNSEEN | 25 | 24 | 0 | 0.00 | - | - |
| HILL BY ITS CHANCE | 13 | 13 | 0 | 0.00 | - | - |
| HUNT DROPPED | 4 | trace | - | - | - | - |
| HUNT KEPT | 7 | trace | - | - | - | - |
| HUNT RESULT | 11 | trace | - | - | - | - |
| HUNT THE GUNS | 11 | trace | - | - | - | - |
| KEEPS ITS PREY | 12 | 10 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 38 | not checked | - | - | - | - |
| LONG SHOT | 13 | 13 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 3 | 3 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 6 | trace | - | - | - | - |
| MARCH OVER CASTS | 38 | 38 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 13 | 13 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 22 | trace | - | - | - | - |
| MOVE SPELL SPOT | 26 | not checked | - | - | - | - |
| NOT NEEDED | 19 | 17 | 0 | 0.00 | - | - |
| NOT TURNED | 426 | 426 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 46 | not checked | - | - | - | - |
| PLAN RESULT | 2561 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 17 | 17 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 17 | 17 | 0 | 0.00 | - | - |
| SCOUT SPOT | 24 | 24 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 13 | 13 | 0 | 0.00 | - | - |
| SECOND HUNTER | 2 | 2 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 21 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 20 | not checked | - | - | - | - |
| SET-UP MISSED | 1 | trace | - | - | - | - |
| SHOOTER COUNTED ONCE | 1 | 1 | 0 | 0.00 | - | - |
| SPELL CATCH ODDS | 3 | not checked | - | - | - | - |
| SPELL SETS UP CHARGE | 21 | not checked | - | - | - | - |
| SPELL WORTH | 127 | not checked | - | - | - | - |
| STABLE ROLE | 314 | 312 | 0 | 0.00 | - | - |
| TURN WORTH | 42 | 40 | 0 | 0.00 | - | - |

### Off best figure: fw-h2h2-opp-1eea44e-p3

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 14.00 | 12.86 | 59.7 |
| FALLBACK | gate | 0.89 | 0.47 | 50.1 |
| TURN GATE | gate | 0.36 | 0.67 | 36.9 |
| RULE SWITCHED OFF | gate | 0.69 | - | 20.2 |
| CHARGE NOW FIRST | rule | - | 0.53 | 60.6 |
| LONE CHARACTER SAFE SPOT | gate | 0.14 | 0.28 | 117.8 |
| CHAFF PASSED | rule | 0.11 | 0.25 | 5.4 |
| AFTERMATH BAND | gate | 0.14 | 0.19 | 2.7 |
| CHARGE NOW WEIGHED | rule | 0.22 | 0.08 | 32.2 |
| CANNON PLANNED TARGET | rule | 0.22 | 0.06 | 77.9 |
| CHARIOT NO STATIC JOB | rule | 0.28 | - | 131.0 |
| SUPPORT REQUEST | gate | 0.14 | 0.11 | 75.9 |
| PIVOT GUARDS FLANK | rule | 0.11 | 0.08 | 6.3 |
| BIG CHARACTER SAFETY | rule | 0.08 | 0.08 | 13.8 |
| PURSUES BIG PREY | rule | 0.06 | 0.11 | 62.9 |
| DEFENSIVE ARMY | rule | - | 0.14 | 74.8 |
| FIGHT ORDER BAND | gate | 0.06 | 0.08 | 1.2 |
| LONE WIZARD HOLDS BACK | rule | 0.03 | 0.11 | 73.9 |
| PATHS CROSS | rule | 0.08 | 0.06 | 29.2 |
| BLOCKED WHEEL | rule | 0.03 | 0.08 | 11.8 |
| CARRIES OUT SET-UP | rule | 0.06 | 0.06 | 105.5 |
| STOPS SHORT OF THE FLANK | rule | 0.06 | 0.06 | 13.6 |
| SUPPORT NARROWED | rule | - | 0.11 | 6.5 |
| SURE CHARGE BEATS ADVANCE | rule | 0.08 | 0.03 | 40.8 |
| MARCH ODDS | rule | - | 0.06 | 32.2 |
| SAFER THAN THE JOB | rule | 0.03 | 0.03 | 14.2 |
| WAR ENGINE JOBS | rule | - | 0.06 | 14.5 |
| AFTERMATH NEEDS NEXT CHARGE | gate | - | 0.03 | 142.2 |
| BEST PRIZE | rule | - | 0.03 | 41.2 |
| NO REASON | gate | - | 0.03 | 14.8 |
| STANDS TO CAST | rule | - | 0.03 | 53.4 |
| WHO HITS BACK | rule | - | 0.03 | 4.8 |
| WOUNDED STAYS OUT | rule | - | 0.03 | 84.0 |

### Plans: fw-h2h2-opp-1eea44e-p3

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 11.7 | 20% | 419 | 387 | 92% |
| Mine | charge | 3.1 | 50% | 258 | 296 | 115% |
| Mine | close in | 4.2 | 27% | 307 | 161 | 52% |
| Mine | hold | 3.4 | 32% | 210 | 0 | 0% |
| Mine | join | 0.6 | 100% | 14 | 0 | 0% |
| Mine | shoot | 8.3 | 59% | 235 | 575 | 244% |
| Mine | support | 3.8 | 88% | 243 | 0 | 0% |
| Opponent | advance | 11.6 | 17% | 371 | 355 | 96% |
| Opponent | charge | 5.0 | 54% | 622 | 470 | 76% |
| Opponent | close in | 6.2 | 29% | 495 | 184 | 37% |
| Opponent | hold | 3.8 | 35% | 256 | 0 | 0% |
| Opponent | join | 0.8 | 93% | 28 | 0 | 0% |
| Opponent | shoot | 4.2 | 64% | 127 | 295 | 233% |
| Opponent | support | 4.6 | 90% | 35 | 0 | 0% |

### Packages: hunt the guns, fw-h2h2-opp-1eea44e-p3

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.1 | 5 | 0 | 20% | 60% | 0% | 3.7 | 444 | 156 | 20% | 19 |
| Opponent | 0.2 | 6 | 0 | 33% | 50% | 0% | 2.3 | 266 | 122 | 50% | 62 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 1.0 | 4 | 0 | 25% | 75% | 0% | 3.7 | 420 | 195 | 25% | 0 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 35 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 78 |
| Empire of Man | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 542 | 0 | 0% | 21 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 89 |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 16 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 33 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 80 |
| Tomb Kings of Khemri | 0.3 | 2 | 0 | 0% | 50% | 0% | 3.0 | 363 | 128 | 50% | 21 |
| Vampire Counts | 0.1 | 1 | 0 | 0% | 0% | 0% | - | 108 | 0 | 0% | 9 |
| Warriors of Chaos | 0.1 | 1 | 0 | 100% | 100% | 0% | 2.0 | 282 | 252 | 100% | 60 |
| Wood Elf Realms | 0.3 | 2 | 0 | 50% | 50% | 0% | 2.0 | 238 | 112 | 50% | 77 |

### Battle groups: fw-h2h2-opp-1eea44e-p3

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 7.9 | 25% | 46% | 12% | 44% | 35% | 11% | 6% | 48% | 0% |
| Mine | REDIRECT COUNTER | 2.5 | 29% | 58% | 8% | 0% | 21% | 0% | 12% | 58% | 8% |
| Opponent | COUNTER-CHARGE COVER | 7.2 | 19% | 59% | 16% | 62% | 22% | 10% | 12% | 56% | 0% |
| Opponent | REDIRECT COUNTER | 3.6 | 24% | 78% | 22% | 14% | 12% | 0% | 12% | 68% | 8% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: fw-h2h2-opp-1eea44e-p3

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Mine | Chaff | 36 | 83 (36) | 40 | 43 | 69 | 44% | 2.7 | 53 (18) | 4 (7) | 183 (11) | 113 (28) | 0 (8) |
| Mine | Character | 117 | 64 (117) | 64 | 0 | 40 | 21% | 2.4 | 89 (36) | 59 (51) | 79 (9) | 82 (54) | 58 (42) |
| Mine | Clean-up | 17 | 65 (17) | 27 | 39 | 45 | 12% | 3.2 | 56 (7) | 32 (6) | 196 (4) | 52 (11) | 88 (6) |
| Mine | Fast Hammer | 43 | 28 (43) | 17 | 11 | 44 | 26% | 2.8 | 28 (26) | 33 (12) | 14 (5) | 27 (34) | 31 (9) |
| Mine | Fragile | 3 | 0 (3) | 0 | 0 | 67 | 0% | 3.7 | 0 (3) | - | - | 0 (1) | 0 (2) |
| Mine | Hammer | 50 | 41 (50) | 30 | 11 | 38 | 16% | 2.5 | 27 (13) | 46 (32) | 34 (5) | 38 (34) | 46 (16) |
| Mine | Holder | 25 | 58 (25) | 29 | 29 | 30 | 36% | 2.8 | 46 (6) | 79 (12) | 15 (7) | 52 (15) | 66 (10) |
| Mine | Shooter | 33 | 56 (33) | 27 | 28 | 46 | 6% | 1.7 | 58 (9) | 59 (22) | 0 (1) | 52 (20) | 62 (12) |
| Mine | Support | 1 | 0 (1) | 0 | 0 | 0 | 0% | 5.0 | - | 0 (1) | - | 0 (1) | - |
| Mine | War machine | 52 | 34 (52) | 34 | 0 | 46 | 2% | 1.1 | 19 (14) | 43 (34) | 0 (4) | 30 (14) | 35 (38) |
| Mine | Wizard | 15 | 0 (15) | 0 | 0 | 66 | 7% | 2.4 | 0 (3) | 0 (5) | 0 (2) | 0 (6) | 0 (4) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Chaff | 70 | 55 (70) | 15 | 41 | 48 | 47% | 2.5 | 46 (30) | 89 (13) | 45 (27) | 64 (49) | 36 (21) |
| Opponent | Character | 96 | 59 (96) | 59 | 0 | 34 | 17% | 2.3 | 57 (32) | 70 (47) | 30 (7) | 48 (44) | 77 (42) |
| Opponent | Clean-up | 10 | 36 (10) | 10 | 26 | 40 | 40% | 3.5 | 15 (3) | 25 (5) | 118 (2) | 42 (6) | 29 (4) |
| Opponent | Fast Hammer | 59 | 31 (59) | 18 | 13 | 58 | 20% | 2.6 | 26 (26) | 30 (21) | 49 (12) | 33 (25) | 30 (34) |
| Opponent | Fragile | 3 | 92 (3) | 92 | 0 | 67 | 33% | 2.0 | - | 46 (2) | 185 (1) | 92 (2) | 92 (1) |
| Opponent | Hammer | 44 | 54 (44) | 39 | 15 | 42 | 32% | 3.0 | 46 (15) | 60 (25) | 27 (4) | 82 (25) | 15 (19) |
| Opponent | Holder | 39 | 84 (39) | 24 | 60 | 25 | 38% | 2.5 | 46 (11) | 108 (17) | 85 (11) | 98 (29) | 49 (10) |
| Opponent | Shooter | 28 | 46 (28) | 27 | 18 | 53 | 7% | 1.1 | 36 (8) | 50 (20) | - | 49 (16) | 42 (12) |
| Opponent | Support | 4 | 0 (4) | 0 | 0 | 34 | 25% | 5.0 | 0 (1) | 0 (2) | 0 (1) | 0 (2) | 0 (2) |
| Opponent | War machine | 17 | 32 (17) | 32 | 0 | 62 | 6% | 1.4 | 46 (3) | 30 (10) | 30 (4) | 0 (3) | 38 (14) |
| Opponent | Wizard | 33 | 3 (33) | 3 | 0 | 48 | 15% | 1.8 | 0 (21) | 11 (5) | 0 (2) | 5 (13) | 0 (15) |

### Charged fights: fw-h2h2-opp-1eea44e-p3

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 93 | 75 | 1.0 | 1.2 | 75 | 0 | +75 | 0 of 4 | 3 of 4 | +0 | +100 |
| Mine | Chaos Dwarfs | 4 | 202 | 488 | 2.5 | 1.2 | 195 | 0 | +195 | 5 of 10 | 9 of 10 | +140 | +209 |
| Mine | Dwarfen Mountain Holds | 3 | 370 | 22 | 1.7 | 1.0 | 13 | 49 | -36 | 1 of 5 | 2 of 5 | - | -36 |
| Mine | Empire of Man | 5 | 383 | 330 | 1.8 | 1.0 | 183 | 0 | +183 | 2 of 9 | 6 of 9 | - | +183 |
| Mine | Grand Cathay | 5 | 454 | 190 | 3.0 | 1.1 | 63 | 14 | +50 | 4 of 15 | 11 of 15 | +173 | +41 |
| Mine | High Elf Realms | 4 | 124 | 770 | 3.5 | 1.5 | 220 | 16 | +204 | 5 of 14 | 10 of 14 | +208 | +201 |
| Mine | Kingdom of Bretonnia | 1 | 479 | 740 | 5.0 | 1.0 | 148 | 55 | +93 | 1 of 5 | 2 of 5 | - | +93 |
| Mine | Ogre Kingdoms | 1 | 481 | 251 | 3.0 | 1.0 | 84 | 0 | +84 | 2 of 3 | 2 of 3 | - | +84 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 477 | 4.0 | 1.0 | 119 | 14 | +106 | 1 of 4 | 2 of 4 | - | +106 |
| Mine | Skaven | 1 | 0 | 0 | 2.0 | 1.0 | 0 | 0 | +0 | 0 of 2 | 1 of 2 | - | +0 |
| Mine | Tomb Kings of Khemri | 2 | 0 | 278 | 4.0 | 1.1 | 70 | 24 | +45 | 4 of 8 | 3 of 8 | -195 | +80 |
| Mine | Vampire Counts | 2 | 164 | 859 | 5.0 | 1.3 | 172 | 37 | +134 | 4 of 10 | 7 of 10 | +172 | +118 |
| Mine | Warriors of Chaos | 2 | 10 | 0 | 0.5 | 1.0 | 0 | 116 | -116 | 0 of 1 | 1 of 1 | - | -116 |
| **Mine** | all armies | 35 | 236 | 335 | 2.6 | 1.2 | 130 | 19 | +112 | 29 of 90 | 59 of 90 | +139 | +107 |
| Opponent | Empire of Man | 1 | 380 | 0 | 1.0 | 1.0 | 0 | 104 | -104 | 0 of 1 | 1 of 1 | - | -104 |
| Opponent | Grand Cathay | 3 | 170 | 355 | 3.0 | 1.2 | 118 | 59 | +59 | 3 of 9 | 6 of 9 | +162 | +30 |
| Opponent | High Elf Realms | 3 | 269 | 220 | 2.3 | 1.0 | 94 | 107 | -13 | 5 of 7 | 4 of 7 | - | -13 |
| Opponent | Kingdom of Bretonnia | 2 | 199 | 673 | 3.0 | 1.0 | 224 | 0 | +224 | 4 of 6 | 1 of 6 | - | +224 |
| Opponent | Orc & Goblin Tribes | 1 | 0 | 0 | 4.0 | 1.0 | 0 | 54 | -54 | 4 of 4 | 0 of 4 | - | -54 |
| Opponent | Skaven | 1 | 180 | 1066 | 4.0 | 1.0 | 266 | 0 | +266 | 2 of 4 | 4 of 4 | - | +266 |
| Opponent | Tomb Kings of Khemri | 4 | 119 | 799 | 4.8 | 1.2 | 168 | 24 | +144 | 10 of 19 | 13 of 19 | +28 | +175 |
| Opponent | Vampire Counts | 6 | 33 | 554 | 5.2 | 1.3 | 107 | 48 | +59 | 12 of 31 | 18 of 31 | +134 | +29 |
| Opponent | Warriors of Chaos | 8 | 0 | 449 | 3.9 | 1.2 | 116 | 15 | +101 | 16 of 31 | 21 of 31 | +141 | +92 |
| Opponent | Wood Elf Realms | 6 | 100 | 231 | 2.3 | 1.1 | 99 | 127 | -28 | 8 of 14 | 6 of 14 | +264 | -51 |
| **Opponent** | all armies | 35 | 102 | 447 | 3.6 | 1.2 | 124 | 46 | +78 | 64 of 126 | 74 of 126 | +125 | +68 |

### Effective charges: fw-h2h2-opp-1eea44e-p3

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 1 (net +0) | 1 (net +0) | 0 | 1 (net +165) | 0 | 1 (net +135) | 0 | 0% (0 of 4) |
| Mine | Chaos Dwarfs | 10 | 0 | 1 (net +0) | 0 | 4 (net +227) | 1 (net +280) | 3 (net +256) | 1 | 0% (0 of 9) |
| Mine | Dwarfen Mountain Holds | 5 | 1 (net -186) | 0 | 1 (net +0) | 1 (net -60) | 0 | 1 (net +0) | 1 | 25% (1 of 4) |
| Mine | Empire of Man | 9 | 3 (net +192) | 1 (net +559) | 0 | 0 | 1 (net +72) | 2 (net +110) | 2 | 0% (0 of 7) |
| Mine | Grand Cathay | 15 | 1 (net +0) | 0 | 1 (net +0) | 5 (net -27) | 2 (net +86) | 5 (net +88) | 1 | 7% (1 of 14) |
| Mine | High Elf Realms | 14 | 1 (net +663) | 0 | 0 | 5 (net +296) | 3 (net +37) | 5 (net +119) | 0 | 0% (0 of 14) |
| Mine | Kingdom of Bretonnia | 5 | 2 (net +95) | 0 | 0 | 0 | 0 | 3 (net +91) | 0 | 0% (0 of 5) |
| Mine | Ogre Kingdoms | 3 | 1 (net +251) | 0 | 0 | 0 | 0 | 1 (net +0) | 1 | 0% (0 of 2) |
| Mine | Orc & Goblin Tribes | 4 | 0 | 0 | 0 | 0 | 0 | 2 (net +238) | 2 | 0% (0 of 2) |
| Mine | Skaven | 2 | 1 (net +0) | 0 | 0 | 0 | 0 | 1 (net +0) | 0 | 0% (0 of 2) |
| Mine | Tomb Kings of Khemri | 8 | 1 (net +233) | 0 | 3 (net -40) | 2 (net +98) | 2 (net +27) | 0 | 0 | 38% (3 of 8) |
| Mine | Vampire Counts | 10 | 1 (net +0) | 0 | 2 (net +302) | 3 (net +145) | 1 (net +98) | 3 (net +69) | 0 | 20% (2 of 10) |
| Mine | Warriors of Chaos | 1 | 1 (net -116) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 1) |
| Opponent | Empire of Man | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net -104) | 0 | 0% (0 of 1) |
| Opponent | Grand Cathay | 9 | 1 (net +371) | 0 | 0 | 1 (net -278) | 3 (net +0) | 3 (net +129) | 1 | 0% (0 of 8) |
| Opponent | High Elf Realms | 7 | 0 | 1 (net +0) | 1 (net -347) | 3 (net -2) | 1 (net +0) | 0 | 1 | 17% (1 of 6) |
| Opponent | Kingdom of Bretonnia | 6 | 3 (net +274) | 2 (net +154) | 1 (net +217) | 0 | 0 | 0 | 0 | 17% (1 of 6) |
| Opponent | Skaven | 4 | 1 (net +105) | 0 | 0 | 0 | 0 | 3 (net +320) | 0 | 0% (0 of 4) |
| Opponent | Tomb Kings of Khemri | 19 | 0 | 0 | 2 (net +256) | 3 (net +91) | 3 (net +30) | 9 (net +159) | 2 | 12% (2 of 17) |
| Opponent | Vampire Counts | 31 | 8 (net -51) | 0 | 7 (net +61) | 6 (net +5) | 6 (net +157) | 4 (net +213) | 0 | 23% (7 of 31) |
| Opponent | Warriors of Chaos | 31 | 3 (net -12) | 4 (net +108) | 5 (net +132) | 4 (net +54) | 0 | 11 (net +116) | 4 | 19% (5 of 27) |
| Opponent | Wood Elf Realms | 14 | 3 (net -216) | 0 | 1 (net -190) | 2 (net -12) | 0 | 4 (net +83) | 4 | 10% (1 of 10) |

### Charged fights, damage counted: fw-h2h2-opp-1eea44e-p3

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 14 | 239 | 228 | +115 | 173 | 52 | +122 | +50.8 |
| Mine | 50-54% | 3 | 278 | 279 | +186 | 186 | 76 | +110 | +39.6 |
| Mine | Effective (55-75%) | 7 | 345 | 294 | +69 | 124 | 122 | +1 | +0.4 |
| Mine | 76-89% | 21 | 326 | 217 | +142 | 188 | 44 | +145 | +44.3 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 27 | 262 | 166 | +116 | 146 | 25 | +122 | +46.4 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 10 | 438 | 98 | +79 | 80 | 10 | +71 | +16.1 |
| Mine | No odds | 8 | 218 | 188 | +62 | 85 | 12 | +73 | +33.5 |
| Mine | All fights | 90 | 296 | 196 | +112 | 147 | 40 | +107 | +36.2 |
| Opponent | Long shot (under 50%) | 19 | 198 | 242 | +11 | 123 | 97 | +25 | +12.8 |
| Opponent | 50-54% | 7 | 368 | 265 | +106 | 113 | 13 | +100 | +27.2 |
| Opponent | Effective (55-75%) | 17 | 350 | 274 | +75 | 150 | 51 | +99 | +28.2 |
| Opponent | 76-89% | 19 | 286 | 234 | +11 | 111 | 107 | +4 | +1.3 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 35 | 307 | 196 | +147 | 214 | 56 | +158 | +51.6 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 13 | 397 | 93 | +79 | 99 | 36 | +63 | +15.7 |
| Opponent | No odds | 16 | 212 | 288 | +78 | 132 | 73 | +59 | +28.1 |
| Opponent | All fights | 126 | 294 | 224 | +78 | 148 | 67 | +81 | +27.7 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| fw-h2h2-opp-1eea44e-p3 | move | 429 | 96 (22%) | 64 (15%) | 64 (15%) | 269 (63%) |
| fw-h2h2-opp-1eea44e-p3 | objective | 378 | 62 (16%) | 44 (12%) | 55 (15%) | 261 (69%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0110, L0126, L2433, L2630 |
| Charmed Shield | Opponent | L0126, L0226, L0327, L0725, L1327, L2327 |
| Clockwork Compass | Mine | L1216, L1232 |
| Elixir of Power | Mine | L1122, L1932 |
| Elixir of Power | Opponent | L0311, L1519 |
| Fistful of Laurels | Mine | L1831 |
| Horn of the Wild Hunt | Opponent | L0533, L1633, L2033, L2433, L3133 |
| Invocation of Nehek | Mine | L2433 |
| Invocation of Nehek | Opponent | L0327, L0725, L1327, L2327 |
| Opal Amulet | Mine | L1422 |
| Periapt of Soul Exchange | Mine | L2033 |
| Periapt of Soul Exchange | Opponent | L0620 |
| Ring of Doom | Mine | L0210, L0226, L1122, L1216, L1232, L1519, L1535, L3133 |
| Ring of Doom | Opponent | L0311, L0533, L0815, L0831, L1633, L1731, L1831, L2033, L2433, L3133 |
| Ring of Jet | Mine | L1013, L1030, L1122, L1216, L1232 |
| Ring of Jet | Opponent | L0110, L0210, L0311 |
| Standard of the Fell Warrior | Mine | L1327 |
| Standard of the Fell Warrior | Opponent | L0413, L1013 |
| Twice-Blessed Armour | Mine | L0709, L0725, L1013, L1030 |
| Twice-Blessed Armour | Opponent | L0110, L0210 |
| Witch Hunter's Ward | Mine | L0709, L0725, L0815, L0831 |

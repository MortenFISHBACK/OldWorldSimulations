# Doctrine scorecard: fw-h2h2-mine-1eea44e-p4

### Scorecard: fw-h2h2-mine-1eea44e-p4

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0114 | 6 | 1 | Mine | no | 6 | - | 0 | 2 | 0 | 0 | 0 | 0 |
| L0114 | 6 | 1 | Opponent | no | 8 | 2 | 6 | 0 | 0 | 0 | 0 | 123 |
| L0130 | 4 | 1 | Mine | yes | 1 | - | 0 | 2 | 0 | 0 | 0 | 65 |
| L0130 | 4 | 1 | Opponent | no | 1 | 1 | 5 | 4 | 0 | 0 | 0 | 0 |
| L0214 | 4 | 1 | Mine | no | 0 | 2 | 2 | 4 | 2 | 0 | 0 | 0 |
| L0214 | 4 | 1 | Opponent | no | 1 | 2 | 0 | 2 | 0 | 0 | 0 | 0 |
| L0230 | 2 | 1 | Mine | - | - | 1 | 8 | 2 | 0 | 0 | 0 | 540 |
| L0230 | 2 | 1 | Opponent | - | - | 3 | 2 | 3 | 0 | 0 | 0 | 0 |
| L0315 | 3 | 1 | Mine | yes | 5 | - | 1 | 0 | 0 | 0 | 0 | 675 |
| L0315 | 3 | 1 | Opponent | yes | 6 | 2 | 3 | 0 | 2 | 0 | 0 | 0 |
| L0332 | 2 | 1 | Mine | - | - | - | 0 | 1 | 1 | 0 | 0 | 794 |
| L0332 | 2 | 1 | Opponent | - | - | 2 | 4 | 6 | 0 | 0 | 0 | 0 |
| L0417 | 3 | 1 | Mine | no | 4 | 2 | 6 | 1 | 0 | 0 | 0 | 0 |
| L0417 | 3 | 1 | Opponent | no | 1 | 1 | 5 | 0 | 1 | 0 | 0 | 0 |
| L0434 | 2 | 1 | Mine | - | - | 3 | 2 | 1 | 1 | 0 | 0 | 0 |
| L0434 | 2 | 1 | Opponent | - | - | 1 | 4 | 3 | 0 | 0 | 0 | 56 |
| L0520 | 4 | 1 | Mine | no | 0 | 2 | 1 | 0 | 0 | 0 | 0 | 1193 |
| L0520 | 4 | 1 | Opponent | no | 0 | - | 0 | 4 | 1 | 0 | 0 | 210 |
| L0608 | 2 | 1 | Mine | - | - | 3 | 2 | 1 | 1 | 0 | 0 | 801 |
| L0608 | 2 | 1 | Opponent | - | - | 3 | 2 | 2 | 0 | 0 | 0 | 605 |
| L0624 | 6 | 1 | Mine | no | 0 | 3 | 2 | 0 | 0 | 0 | 0 | 798 |
| L0624 | 6 | 1 | Opponent | no | 5 | 3 | 2 | 3 | 0 | 0 | 0 | 0 |
| L0713 | 5 | 1 | Mine | yes | - | 2 | 3 | 1 | 2 | 0 | 0 | 375 |
| L0713 | 5 | 1 | Opponent | yes | - | 2 | 2 | 2 | 1 | 0 | 0 | 317 |
| L0729 | 3 | 1 | Mine | no | 0 | 2 | 2 | 0 | 0 | 0 | 0 | 513 |
| L0729 | 3 | 1 | Opponent | no | 4 | 2 | 3 | 0 | 0 | 0 | 0 | 170 |
| L0819 | 3 | 1 | Mine | no | 0 | 3 | 1 | 0 | 1 | 0 | 0 | 475 |
| L0819 | 3 | 1 | Opponent | no | 4 | 2 | 1 | 2 | 1 | 0 | 0 | 0 |
| L0835 | 1 | 1 | Mine | no | 0 | 4 | 2 | 1 | 0 | 0 | 0 | 515 |
| L0835 | 1 | 1 | Opponent | no | 0 | 2 | 3 | 4 | 0 | 0 | 0 | 0 |
| L0926 | 2 | 1 | Mine | - | - | 2 | 2 | 0 | 0 | 0 | 0 | 515 |
| L0926 | 2 | 1 | Opponent | - | - | 2 | 3 | 2 | 0 | 0 | 0 | 0 |
| L1017 | 3 | 1 | Mine | no | 0 | 2 | 2 | 0 | 1 | 0 | 0 | 456 |
| L1017 | 3 | 1 | Opponent | yes | 9 | 2 | 9 | 2 | 2 | 0 | 0 | 49 |
| L1034 | 2 | 1 | Mine | - | - | 1 | 1 | 1 | 0 | 0 | 0 | 330 |
| L1034 | 2 | 1 | Opponent | - | - | 2 | 2 | 3 | 0 | 0 | 0 | 56 |
| L1126 | 4 | 1 | Mine | no | 0 | 2 | 3 | 0 | 0 | 0 | 0 | 330 |
| L1126 | 4 | 1 | Opponent | no | 0 | 2 | 3 | 2 | 1 | 0 | 0 | 0 |
| L1220 | 2 | 1 | Mine | - | - | 2 | 2 | 1 | 1 | 0 | 0 | 330 |
| L1220 | 2 | 1 | Opponent | - | - | 4 | 2 | 2 | 0 | 0 | 0 | 420 |
| L1314 | 6 | 1 | Mine | no | 1 | 2 | 3 | 0 | 0 | 0 | 0 | 479 |
| L1314 | 6 | 1 | Opponent | no | 6 | 2 | 4 | 1 | 1 | 0 | 0 | 177 |
| L1331 | 5 | 1 | Mine | yes | - | 4 | 1 | 3 | 0 | 0 | 0 | 302 |
| L1331 | 5 | 1 | Opponent | no | - | 2 | 1 | 4 | 3 | 0 | 0 | 170 |
| L1427 | 5 | 1 | Mine | yes | - | 2 | 3 | 0 | 0 | 0 | 0 | 0 |
| L1427 | 5 | 1 | Opponent | yes | - | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L1523 | 5 | 1 | Mine | no | - | 2 | 3 | 2 | 1 | 0 | 0 | 0 |
| L1523 | 5 | 1 | Opponent | yes | - | 3 | 5 | 2 | 1 | 0 | 0 | 0 |
| L1621 | 1 | 1 | Mine | no | 4 | 2 | 1 | 1 | 0 | 0 | 0 | 475 |
| L1621 | 1 | 1 | Opponent | no | 1 | 3 | 1 | 4 | 0 | 0 | 0 | 290 |
| L1719 | 3 | 1 | Mine | no | 0 | 2 | 5 | 0 | 0 | 0 | 0 | 147 |
| L1719 | 3 | 1 | Opponent | no | 1 | 2 | 2 | 1 | 1 | 0 | 0 | 0 |
| L1819 | 1 | 1 | Mine | no | 1 | 3 | 6 | 1 | 1 | 0 | 0 | 0 |
| L1819 | 1 | 1 | Opponent | no | 1 | 2 | 5 | 1 | 0 | 0 | 0 | 0 |
| L1835 | 5 | 1 | Mine | yes | - | 2 | 1 | 2 | 1 | 0 | 0 | 0 |
| L1835 | 5 | 1 | Opponent | yes | - | 2 | 3 | 3 | 0 | 0 | 0 | 250 |
| L2021 | 5 | 1 | Mine | no | - | 2 | 1 | 6 | 1 | 0 | 0 | 420 |
| L2021 | 5 | 1 | Opponent | no | - | 4 | 4 | 4 | 0 | 0 | 0 | 355 |
| L2123 | 5 | 1 | Mine | yes | - | - | 1 | 5 | 0 | 0 | 0 | 730 |
| L2123 | 5 | 1 | Opponent | yes | - | 2 | 3 | 3 | 0 | 0 | 0 | 0 |
| L2227 | 1 | 1 | Mine | yes | 4 | 1 | 3 | 1 | 0 | 0 | 0 | 0 |
| L2227 | 1 | 1 | Opponent | no | 2 | 4 | 8 | 3 | 1 | 0 | 0 | 0 |
| L2331 | 3 | 1 | Mine | yes | 0 | 2 | 4 | 0 | 0 | 0 | 0 | 0 |
| L2331 | 3 | 1 | Opponent | yes | 2 | 3 | 1 | 2 | 2 | 0 | 0 | 0 |
| L2527 | 1 | 1 | Mine | no | 0 | 3 | 2 | 2 | 1 | 0 | 0 | 0 |
| L2527 | 1 | 1 | Opponent | no | 4 | 1 | 2 | 2 | 0 | 0 | 0 | 0 |
| L2634 | 6 | 1 | Mine | no | 1 | 2 | 4 | 0 | 0 | 0 | 0 | 357 |
| L2634 | 6 | 1 | Opponent | no | 4 | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L2930 | 2 | 1 | Mine | - | - | 2 | 8 | 1 | 0 | 0 | 0 | 0 |
| L2930 | 2 | 1 | Opponent | - | - | 3 | 4 | 2 | 0 | 0 | 0 | 0 |
| L3234 | 6 | 1 | Mine | no | 1 | 2 | 2 | 1 | 2 | 0 | 0 | 307 |
| L3234 | 6 | 1 | Opponent | no | 0 | 1 | 5 | 2 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 32% | 1.3 | 2.2 | 2.5 | 1.2 | 0.5 | 0.0 | 0.0 | 331.2 |
| **Average** | | | Opponent | 29% | 2.9 | 2.2 | 3.2 | 2.3 | 0.5 | 0.0 | 0.0 | 90.2 |

### KPIs: fw-h2h2-mine-1eea44e-p4

Rules off - Opponent only: WAR ENGINE JOBS, STAY WEIGHED, BEST FIRST, RANDOM MOVE BY FIGURES, RANDOM MOVER NO PROMISE, STABLE ROLE, WOUNDED STAYS OUT, BEST FACING, LOST CHARGE, SCREEN BY WHAT IT SAVES, REDIRECT BY WHAT IT STOPS, SHOOTER COUNTED ONCE, LURE BY WHAT IT DRAWS, HILL BY ITS CHANCE, MOVE TO CHARGE, LONG SHOT, DEFENSIVE ARMY, SHOOTS FROM THE BEST SPOT, SUPPORTS, RESERVE FALL BACK, WAIT AFTER COSTS, CHARGE NOW FIRST, SUPPORT NARROWED, WAR ENGINE CHARGES, DEFENSIVE FLOOR.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 22% (38 of 172) | 0% (0 of 175) | 11% (38 of 347) |
| Winner chose to follow up after the loser gave ground |  | 95% (63 of 66); on the table 97% | 95% (63 of 66); on the table 95% | 95% (126 of 132); on the table 96% |
| Winner chose to pursue after the loser fell back in good order |  | 100% (11 of 11); on the table 100% | 89% (17 of 19); on the table 89% | 93% (28 of 30); on the table 93% |
| Winner chose to pursue after the loser fled |  | 80% (16 of 20); on the table 85% | 82% (32 of 39); on the table 87% | 81% (48 of 59); on the table 86% |
| Winner chose to follow up or pursue (all three) |  | 93% (90 of 97); on the table 95% | 90% (112 of 124); on the table 92% | 91% (202 of 221); on the table 93% |
| Magic missiles tried each own turn | 50%+ | 32% (85 of 268) | 35% (60 of 172) | 33% (145 of 440) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 52% (85 of 163) | 45% (60 of 132) | 49% (145 of 295) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 65% (26 of 40) | - | 65% (26 of 40) |
| Points that never fought | lower | 33% (22751 of 67942) | 33% (23775 of 71984) | 33% (46526 of 139926) |
|   infantry points that never fought | lower | 41% (6338 of 15347) | 61% (8373 of 13804) | 50% (14711 of 29151) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 62% (168 of 270) | 49% (137 of 280) | 55% (305 of 550) |
| Bound items with a magic missile used (at least once a game) |  | 91% (20 of 22); 1.6 uses a game | 78% (7 of 9); 0.7 uses a game | 87% (27 of 31); 1.1 uses a game |
| Bound items with another spell used |  | 69% (11 of 16); 0.6 uses a game | 25% (5 of 20); 0.2 uses a game | 44% (16 of 36); 0.4 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 53% (10 of 19); 0.3 uses a game | 80% (12 of 15); 0.4 uses a game | 65% (22 of 34); 0.3 uses a game |
|   their share of the points of units over 100 pts | lower | 56% (32476 of 57750) | 39% (25021 of 63347) | 47% (57497 of 121097) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.2 (23%) | 0.8 (26%) | 2.0 (24%) |
| MARCHED: its unit marched | 0.8 (16%) | 0.6 (18%) | 1.4 (17%) |
| CHARGED: its unit charged | 0.1 (1%) | 0.3 (9%) | 0.3 (4%) |
| IN COMBAT: engaged in combat | 1.2 (23%) | 0.7 (21%) | 1.9 (23%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.2 (8%) | 0.2 (3%) |
| FLEEING: fleeing | 0.1 (2%) | 0.1 (4%) | 0.2 (2%) |
| GONE: slain | 1.4 (28%) | 0.3 (11%) | 1.8 (22%) |
| OFF THE TABLE: off the table or not arrived | 0.2 (4%) | 0.0 (0%) | 0.2 (2%) |
| STUPIDITY: Stupidity | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (1%) | 0.1 (4%) | 0.1 (2%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.5 | 1.5 | 1.5 | 4.0 | 0.3 | 1.9 |
| not cast | 2.7 | 2.4 | 3.3 | 8.2 | 1.7 | 21.0 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.8 (9%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.2 (51%) | 0.1 (3%) | 2.0 (24%) | 0.5 (31%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.4 (17%) | 0.3 (18%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (4%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.1 (5%) | 0.1 (2%) | 0.5 (14%) | 1.9 (23%) | 0.3 (18%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.2 (6%) | 0.2 (7%) | 0.3 (10%) | 0.2 (3%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.2 (6%) | 0.0 (0%) | 0.0 (1%) | 0.2 (2%) | 0.0 (0%) | 0.4 (2%) |
| GONE: slain | 0.8 (30%) | 0.5 (20%) | 0.7 (20%) | 1.8 (22%) | 0.5 (31%) | 3.7 (18%) |
| OFF THE TABLE: off the table or not arrived | 0.1 (4%) | 0.0 (0%) | 0.3 (9%) | 0.2 (2%) | 0.0 (0%) | 0.5 (3%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.0 (0%) | 0.0 (1%) | 0.1 (1%) | 0.0 (0%) | 0.1 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.3 (12%) | 0.0 (1%) | 0.1 (2%) | 0.1 (3%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.3 (48%) | 0.2 (7%) | 1.3 (40%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 14.4 (69%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.1 a game | 0.5 a game | 0.8 a game |
| stood (cast and not dispelled) | 64% (23 of 36) | 55% (6 of 11) | 62% (29 of 47) |
| the unit moved after it | 74% (17 of 23) | 67% (4 of 6) | 72% (21 of 29) |
| it charged on its next turn | 4% (1 of 23) | 0% (0 of 6) | 3% (1 of 29) |
| the enemy charged it first | 17% (4 of 23) | 0% (0 of 6) | 14% (4 of 29) |
| it fought by the end of its next turn | 9% (2 of 23) | 17% (1 of 6) | 10% (3 of 29) |
| it moved out of a charge the enemy had planned (not charged first) | 17% (4 of 23) | 0% (0 of 6) | 14% (4 of 29) |
| none of these (no charge, no fight, no charge escaped) | 57% (13 of 23) | 83% (5 of 6) | 62% (18 of 29) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 62% (533 of 863) | 54% (296 of 544) | 59% (829 of 1407) |
|   cavalry | 70% (64 of 91) | 72% (80 of 111) | 71% (144 of 202) |
|   character | 34% (33 of 96) | 17% (24 of 141) | 24% (57 of 237) |
|   chariot | 55% (53 of 96) | 63% (12 of 19) | 57% (65 of 115) |
|   infantry | 55% (150 of 273) | 68% (159 of 234) | 61% (309 of 507) |
|   monster | 39% (18 of 46) | 19% (4 of 21) | 33% (22 of 67) |
|   war machine | 82% (215 of 261) | 94% (17 of 18) | 83% (232 of 279) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.2 (25%) | 1.5 (22%) | 3.8 (24%) |
| CHARGED: it charged | 1.2 (13%) | 1.9 (28%) | 3.1 (20%) |
| FLEEING: it fled or was fleeing | 0.2 (2%) | 0.1 (1%) | 0.2 (2%) |
| IN COMBAT: it fought this turn or the last | 1.0 (11%) | 0.3 (4%) | 1.3 (8%) |
| MOVED: a war machine that moved | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| NO TARGET IN RANGE | 1.7 (18%) | 1.4 (20%) | 3.1 (19%) |
| ONLY IN COMBAT: the only targets were in combat | 0.8 (9%) | 0.6 (8%) | 1.4 (8%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.5 (17%) | 1.1 (16%) | 2.6 (16%) |
| SHELTERED: the target was sheltered | 0.2 (2%) | 0.0 (0%) | 0.2 (1%) |
| STUPIDITY | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR | 0.2 (3%) | 0.0 (0%) | 0.2 (2%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 6.5 | 1.7 | 80% | 6.2 pts | 40 pts |
| character | 2.1 | 0.5 | 83% | 7.2 pts | 15 pts |
| chariot | 1.8 | 1.1 | 62% | 20.7 pts | 37 pts |
| infantry | 12.4 | 4.9 | 73% | 11.1 pts | 139 pts |
| monster | 0.7 | 0.2 | 83% | 5.8 pts | 4 pts |
| war machine | 6.4 | 5.3 | 65% | 29.1 pts | 187 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.3 | 6.2 | 5.2 |
| Charges that made contact a game | 3.1 | 4.2 | 3.7 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.59 declared, 0.53 contact (17 units) | 0.80 declared, 0.60 contact (15 units) | 0.69 declared, 0.56 contact (32 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.90 declared, 0.90 contact (10 units) | 1.00 declared, 0.50 contact (10 units) | 0.95 declared, 0.70 contact (20 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.54 declared, 0.37 contact (250 units) | 0.66 declared, 0.46 contact (304 units) | 0.61 declared, 0.42 contact (554 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 49% (40 of 81) | 44% (7 of 16) | 33% (2 of 6) | 48% (49 of 103) |
| Character in a unit | 64% (14 of 22) | 64% (9 of 14) | 100% (1 of 1) | 65% (24 of 37) |
| Character on its own | 67% (29 of 43) | 57% (16 of 28) | 22% (17 of 77) | 42% (62 of 148) |
| Chariot | 73% (11 of 15) | 50% (6 of 12) | - | 63% (17 of 27) |
| Infantry | 54% (45 of 83) | 48% (12 of 25) | 33% (2 of 6) | 52% (59 of 114) |
| Monster | 79% (27 of 34) | 71% (10 of 14) | - | 77% (37 of 48) |
| Monstrous | 71% (10 of 14) | 57% (8 of 14) | - | 64% (18 of 28) |
| War Machines | 86% (37 of 43) | 100% (2 of 2) | - | 87% (39 of 45) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 89% (8 of 9); on the table 100% | 36% (37 of 102) | 26% | 73% (16 of 22) | 100% (6 of 6); 4.5 uses a game | 100% (2 of 2); 1.2 uses a game | 83% (5 of 6); 1.2 uses a game |
| Chaos Dwarfs | 4 | 91% (10 of 11); on the table 91% | 25% (6 of 24) | 20% | 56% (18 of 32) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
| Dwarfen Mountain Holds | 3 | 82% (9 of 11); on the table 82% | - | 69% | 78% (21 of 27) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 6 | 83% (15 of 18); on the table 89% | 50% (9 of 18) | 41% | 63% (39 of 62) | 0.0 uses a game | 100% (2 of 2); 0.7 uses a game | 80% (4 of 5); 0.7 uses a game |
| Grand Cathay | 4 | 100% (7 of 7); on the table 100% | 29% (24 of 84) | 34% | 49% (18 of 37) | 89% (8 of 9); 4.5 uses a game | 100% (2 of 2); 0.8 uses a game | 0% (0 of 4); 0.0 uses a game |
| High Elf Realms | 9 | 90% (26 of 29); on the table 90% | 26% (9 of 34) | 32% | 43% (30 of 70) | 100% (7 of 7); 3.2 uses a game | 33% (10 of 30); 1.9 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | - | - | 43% | 33% (2 of 6) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Lizardmen | 3 | 100% (9 of 9); on the table 100% | 83% (5 of 6) | 22% | 52% (11 of 21) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 2 | 100% (5 of 5); on the table 100% | 17% (1 of 6) | 44% | 86% (12 of 14) | 50% (1 of 2); 1.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 3 | 100% (10 of 10); on the table 100% | 14% (6 of 42) | 7% | 12% (3 of 24) | 0.0 uses a game | 0.0 uses a game | 67% (2 of 3); 0.7 uses a game |
| Skaven | 6 | 57% (4 of 7); on the table 86% | 38% (15 of 40) | 46% | 67% (30 of 45) | 67% (2 of 3); 0.8 uses a game | 0.0 uses a game | 67% (4 of 6); 0.8 uses a game |
| Tomb Kings of Khemri | 4 | 86% (12 of 14); on the table 86% | 33% (2 of 6) | 35% | 50% (10 of 20) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 8 | 94% (34 of 36); on the table 94% | 38% (23 of 60) | 24% | 48% (20 of 42) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 9 | 97% (30 of 31); on the table 97% | 25% (3 of 12) | 35% | 62% (45 of 72) | 100% (2 of 2); 0.6 uses a game | 0.0 uses a game | 100% (3 of 3); 0.3 uses a game |
| Wood Elf Realms | 6 | 96% (23 of 24); on the table 96% | 83% (5 of 6) | 33% | 54% (30 of 56) | 50% (1 of 2); 0.7 uses a game | 0.0 uses a game | 75% (3 of 4); 0.5 uses a game |

Flank and rear charges a unit could have turned to face (fw-h2h2-mine-1eea44e-p4, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 48% (43) | 47% (36) | 48% (79) |
| ...free all their last turn and able to turn (per game) | 0.64 | 0.50 | 1.14 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.28 | 0.28 | 0.56 |
| ...with the charger already in that arc before they moved (per game) | 0.42 | 0.31 | 0.72 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 1.81 | 0.94 | 2.75 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 1.19 | 0.56 | 1.75 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 5.86 | 7.19 | 13.06 |

### Quality by phase: fw-h2h2-mine-1eea44e-p4

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.1 | 3.6 |
| Strategy | Charge objectives carried out (made contact) | 43% (73 of 171) | 43% (77 of 180) |
| Strategy | Shoot objectives carried out (shot that target) | 44% (154 of 351) | 57% (82 of 144) |
| Strategy | Close-in objectives charged next turn | 18% (25 of 140) | 16% (35 of 215) |
| Strategy | Support requests answered (helper made contact too) | 36% (5 of 14) | 35% (8 of 23) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (2 of 2) | 100% (3 of 3) |
| Strategy | Hexes on a unit its side charged or shot that turn | 36% (5 of 14) | 25% (2 of 8) |
| Strategy | Joined characters whose unit fought | 28% (7 of 25) | 55% (18 of 33) |
| Strategy | Lone characters that fought | 82% (80 of 98) | 83% (69 of 83) |
| Movement | Charges halted short of contact | 0.2 | 0.2 |
| Movement | Idle units | 1.2 | 2.3 |
| Movement | Points that never moved of their own | 331.2 | 90.2 |
| Movement | Fights charged into per game | 2.9 | 3.6 |
| Movement | Charges with odds: long shots (under 50%) | 11 of 94, net +75 | 18 of 114, net +55 |
| Movement | Charges with odds: sweet spot (55-75%) | 17 of 94, net +43 | 22 of 114, net +56 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 12 of 94, net +34 | 14 of 114, net +60 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 36 of 94, net +56 | 35 of 114, net +246 |
| Shooting | Shots by shooting units (incl. breath weapons) | 9.7 | 9.2 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 46% (161 of 350) | 41% (136 of 330) |
| Shooting | Points destroyed by shooting units | 102.1 | 67.4 |
| Shooting | War machine shots | 6.0 | 0.5 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 58% (125 of 215) | 0% (0 of 17) |
| Shooting | Points destroyed by war machines | 54.4 | 12.5 |
| Magic | Magic missiles cast | 1.6 | 1.2 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 29% (17 of 58) | 30% (13 of 43) |
| Magic | Wounds caused by magic missiles | 3.7 | 1.9 |
| Magic | Wounds caused by other spells | 1.6 | 1.8 |
| Magic | Points destroyed by magic (all spells) | 60.2 | 31.9 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.2 / 0.4 / 0.5 / 0.1 | 2.3 / 0.4 / 0.7 / 0.0 |
| Combat | Points destroyed in combat | 301.7 | 566.2 |
| Combat | Points run down | 73.9 | 133.2 |
| Combat | Net points per charged fight, damage counted | +39 | +128 |
| Combat | Net per 100 charger points, damage counted | +14.9 | +40.9 |
| Combat | First round won (charged fights) | 66% | 56% |
| Combat | Net points per charged fight | +48 | +124 |
| Combat | Net points per supported fight / lone fight | +154 / +32 | +279 / +110 |
| Combat | Charged fights on a top-3 enemy unit | 38 of 105 | 67 of 131 |
| Game | Points lost | 936.6 | 651.9 |
| Game | VP from objectives | 425.3 | 637.5 |
| Game | Lone holders (player turns) | 1.3 | 2.9 |

- Mine won / drew / lost: 11 / 3 / 22 of 36 ended games (of 36); mean margin (Mine - Opponent) -551 VP
- The side that went first won 15 of 33 games with a winner
- Points traded per game (both sides' losses): 1588
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: fw-h2h2-mine-1eea44e-p4

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.6 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| ALREADY CARRIED | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARRIVAL HUNT | - | - | - | - | 0.0 | +0.4 | 0.0 | 2.4 |
| ARTILLERY RE-ROLL WEIGHED | 1.0 | +0.0 | 0.0 | 27.6 | 0.3 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | 0.9 | +5.9 | 0.0 | 35.6 | 1.5 | +16.9 | 0.0 | 15.8 |
| BEST FACING | 0.5 | +13.9 | 0.0 | 17.0 | - | - | - | - |
| BEST FIRST | 4.1 | +180.2 | 152.9 | 98.9 | - | - | - | - |
| BEST OVERALL | 0.6 | +37.3 | 0.0 | 16.8 | 0.3 | +29.1 | 0.0 | 19.8 |
| BEST PREY | 0.6 | +20.3 | 25.0 | 6.3 | 4.8 | +342.0 | 257.6 | 98.9 |
| BEST PRIZE | 0.1 | -0.2 | 0.0 | 13.6 | 0.1 | +7.7 | 16.6 | 0.0 |
| BIG CHARACTER SAFETY | 0.2 | -1.3 | 0.0 | 15.0 | 0.3 | -1.9 | 0.0 | 11.0 |
| BLOCKED CHARGE SKIPPED | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 16.1 | 0.0 |
| BLOCKED WHEEL | 0.6 | +16.9 | 0.0 | 15.4 | 0.6 | -3.1 | 0.0 | 2.6 |
| BOMBING RUN | 0.1 | +0.6 | 1.2 | 1.7 | - | - | - | - |
| BOUND ASSAILMENT | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CANNON PLAN MISSED | 0.7 | +0.0 | 110.9 | 11.0 | 0.1 | +0.0 | 5.8 | 3.5 |
| CANNON PLANNED TARGET | 4.7 | +117.0 | 298.6 | 146.9 | 0.4 | +18.9 | 19.4 | 3.9 |
| CANNON SIGHT KEPT | 1.1 | +0.0 | 0.0 | 7.7 | 0.1 | +0.0 | 0.0 | 1.9 |
| CARRIES OUT COUNTER | 0.1 | +0.0 | 6.5 | 8.9 | - | - | - | - |
| CARRIES OUT SET-UP | 0.1 | +0.0 | 11.9 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CAST JOB | 0.8 | +25.1 | 41.8 | 2.4 | 0.4 | +5.5 | 36.9 | 5.4 |
| CASTER AWAY FROM SCREEN | 0.3 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.2 | +31.7 | 19.2 | 17.9 | - | - | - | - |
| CASTS AFTER FRIENDS | 0.7 | +0.0 | 0.0 | 36.7 | 0.2 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.0 | +2.1 | 0.0 | 0.0 | - | - | - | - |
| CATCH ODDS | 0.1 | +1.3 | 0.0 | 0.0 | - | - | - | - |
| CHAFF PASSED | 0.5 | -1.2 | 3.8 | 8.7 | 0.3 | -1.1 | 2.9 | 10.0 |
| CHAMPION TAKES THE CHALLENGE | - | - | - | - | 0.0 | +1.2 | 8.0 | 0.0 |
| CHARGE NOW FIRST | 3.3 | +0.0 | 212.0 | 107.5 | - | - | - | - |
| CHARGE NOW WEIGHED | 0.5 | -49.0 | 4.4 | 32.2 | 0.8 | -48.1 | 47.6 | 21.8 |
| CHARIOT NO STATIC JOB | 0.1 | +0.0 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 3.2 |
| CHARIOT WIZARD CAREFUL | 0.1 | -0.2 | 0.0 | 0.0 | 0.2 | -1.4 | 0.0 | 0.0 |
| CHEAP HELPER | 0.1 | +0.0 | 7.2 | 2.9 | 0.1 | +0.0 | 5.2 | 1.2 |
| COMBAT PIVOT | 0.7 | +0.0 | 33.5 | 49.2 | 0.8 | +0.0 | 99.4 | 14.7 |
| CONTINUE AHEAD WEIGHED | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CONVEYANCE SEARCH | 0.7 | +160.6 | 22.1 | 24.6 | 0.2 | +53.9 | 13.9 | 13.9 |
| COUNTER-CHARGE COVER | 8.8 | +725.4 | 0.0 | 281.8 | 7.4 | +602.6 | 0.0 | 98.5 |
| DEFENSIVE ARMY | 0.2 | +0.0 | 0.0 | 1.0 | - | - | - | - |
| DEFENSIVE FLOOR | 0.1 | +3.1 | 10.1 | 0.0 | - | - | - | - |
| EDGE GIVE GROUND | 0.2 | +2.3 | 12.2 | 0.0 | 0.1 | +7.4 | 23.5 | 0.0 |
| ELIXIR WORTH | - | - | - | - | 0.1 | +0.6 | 0.0 | 0.0 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 1.8 | +133.6 | 0.0 | 61.6 | 0.9 | +73.6 | 0.0 | 30.7 |
| FALLBACK BY WORTH | 5.1 | +55.5 | 0.0 | 71.4 | 7.3 | +69.9 | 0.0 | 104.9 |
| FIGHT LIFT | 0.1 | +0.8 | 5.6 | 0.0 | 0.0 | +0.2 | 0.0 | 11.0 |
| FIRE AND FLEE | 0.0 | +0.6 | 0.0 | 0.0 | 0.1 | +0.3 | 13.6 | 3.0 |
| FLANK NOT WEIGHED | 5.7 | +0.0 | 0.0 | 201.0 | 6.4 | +0.0 | 0.0 | 115.9 |
| FOCUS FIRE | 0.0 | +1.9 | 0.0 | 0.0 | 0.0 | +0.6 | 0.0 | 0.0 |
| FOLLOW UP WEIGHED | 1.3 | +148.8 | 0.0 | 70.7 | 1.5 | +205.1 | 0.0 | 39.2 |
| FRIENDS SHOTS CHECKED | 0.3 | +11.7 | 0.0 | 7.4 | 0.1 | +5.7 | 0.0 | 0.8 |
| GIVES UP | 0.0 | -0.6 | 7.0 | 0.0 | 1.7 | -64.1 | 229.5 | 11.9 |
| GIVES UP ITS SCREEN | 0.1 | -0.2 | 0.8 | 2.4 | 1.1 | -27.6 | 76.6 | 11.6 |
| GROUND FLIERS | 0.0 | +0.2 | 0.0 | 0.0 | 0.1 | +1.9 | 0.0 | 0.0 |
| HELPER ALREADY ASKED | - | - | - | - | 0.1 | +0.0 | 3.4 | 0.0 |
| HELPER UNSEEN | 0.5 | +0.0 | 39.7 | 4.9 | 0.5 | +0.0 | 54.1 | 15.9 |
| HILL BY ITS CHANCE | 0.5 | -77.0 | 0.0 | 17.4 | - | - | - | - |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| HUNT ADVANCE | 0.1 | +0.1 | 5.3 | 0.0 | 0.1 | +3.2 | 3.5 | 0.0 |
| HUNT DROPPED | 0.0 | +0.0 | 0.0 | 3.1 | 0.1 | +0.0 | 0.0 | 3.1 |
| HUNT IN PAIRS | 0.3 | +11.3 | 0.0 | 6.5 | 0.4 | +11.4 | 0.0 | 13.3 |
| HUNT RESULT | 0.1 | +5.4 | 0.0 | 3.1 | 0.2 | +36.3 | 19.6 | 8.5 |
| HUNT THE GUNS | 0.1 | +21.1 | 5.3 | 0.0 | 0.2 | +60.5 | 26.5 | 3.8 |
| INVITES THE FIGHT | 1.9 | +36.5 | 44.5 | 39.6 | - | - | - | - |
| JOINT CHARGE PLAN | 0.1 | +3.2 | 0.0 | 0.0 | 0.2 | +25.1 | 15.1 | 6.7 |
| KEEP FALLS | 0.1 | +1.7 | 0.0 | 6.1 | 0.1 | +2.9 | 0.0 | 0.0 |
| KEEPS ITS PREY | 0.1 | +0.2 | 0.0 | 0.0 | 0.2 | +2.4 | 16.9 | 9.6 |
| KEEPS ITS TARGET | 1.9 | +55.8 | 109.8 | 47.4 | 2.2 | +66.7 | 266.8 | 39.1 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KILLS COUNT | 2.0 | +75.8 | 151.1 | 34.0 | 2.2 | +108.1 | 196.6 | 21.0 |
| KILLS COUNT NEXT TURN | 5.1 | +156.5 | 179.5 | 164.4 | 10.7 | +598.6 | 585.2 | 242.3 |
| LONE CHARACTER SAFE SPOT | 0.6 | +38.8 | 9.5 | 31.2 | 0.2 | +26.7 | 11.8 | 14.9 |
| LONE WIZARD HOLDS BACK | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 3.5 | 16.1 |
| LONE WIZARD KEPT IN | 0.6 | +26.9 | 0.0 | 0.0 | 0.2 | +20.3 | 0.0 | 0.0 |
| LONG SHOT | 0.7 | -3.1 | 49.2 | 2.4 | - | - | - | - |
| LOST CHARGE | 2.5 | -40.5 | 70.5 | 123.7 | - | - | - | - |
| LURE BY WHAT IT DRAWS | 0.1 | -14.1 | 0.0 | 1.2 | - | - | - | - |
| MAKE SURE TOGETHER | 0.5 | +34.9 | 0.0 | 11.1 | 0.7 | +73.3 | 17.7 | 10.7 |
| MANOEUVRE | 0.2 | +2.0 | 0.0 | 0.0 | 0.2 | +4.2 | 0.0 | 6.5 |
| MARCH AT ESCAPER | 0.0 | +0.0 | 0.0 | 0.0 | 0.0 | +0.2 | 0.0 | 0.0 |
| MARCH CHECK | 0.6 | +20.8 | 0.0 | 18.6 | 0.4 | +26.4 | 0.0 | 24.7 |
| MARCH ODDS | 0.4 | +27.1 | 21.9 | 4.6 | 0.7 | +56.9 | 31.7 | 0.0 |
| MARCH OVER CASTS | 0.4 | +31.2 | 0.0 | 16.7 | 0.6 | +60.2 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 4.6 | +133.9 | 0.0 | 160.9 | 5.5 | +197.3 | 0.0 | 87.2 |
| MISSILES IN THE MOVE | 4.0 | +146.9 | 0.0 | 118.5 | 2.4 | +38.0 | 0.0 | 84.4 |
| MISSILES NEXT TURN | 4.5 | +88.7 | 0.0 | 146.0 | 3.1 | +30.3 | 0.0 | 84.3 |
| MODEL FACING | 0.3 | +63.8 | 0.0 | 6.7 | - | - | - | - |
| MONSTER WIZARD ROAMS | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| MOVE AND CAST | 0.4 | +13.9 | 0.0 | 11.0 | 0.1 | +6.4 | 0.0 | 0.0 |
| MOVE SPELL IN RANGE | 0.2 | +3.5 | 0.0 | 15.3 | - | - | - | - |
| MOVE SPELL NOT WORTH | - | - | - | - | 0.0 | -0.0 | 0.0 | 0.0 |
| MOVE SPELL OUT OF RANGE | 0.4 | -21.0 | 21.3 | 21.1 | - | - | - | - |
| MOVE SPELL SPOT | 0.5 | +0.0 | 0.0 | 23.5 | 0.1 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE | 2.6 | +126.5 | 65.5 | 96.4 | - | - | - | - |
| MOVES UNITS SPELL | 0.1 | +3.3 | 0.0 | 0.0 | 0.1 | +0.6 | 0.0 | 0.0 |
| NEEDED THERE | - | - | - | - | 0.1 | +10.0 | 9.1 | 0.0 |
| NO RALLY LEFT | 0.1 | +22.2 | 0.0 | 0.0 | 0.0 | +1.6 | 0.0 | 5.4 |
| NOT NEEDED | 0.4 | -21.3 | 45.3 | 0.0 | 0.2 | -15.8 | 18.2 | 6.5 |
| NOT TURNED | 5.9 | +124.7 | 0.0 | 159.4 | 7.2 | +155.9 | 0.0 | 96.9 |
| NOT WORTH A CAST | 0.7 | -0.5 | 0.0 | 56.8 | 0.2 | -0.1 | 0.0 | 0.0 |
| OFF BEST | 14.2 | -618.9 | 0.0 | 365.2 | 16.1 | -958.7 | 36.4 | 258.2 |
| OPENS A LANE | 0.3 | +1.7 | 17.3 | 2.6 | - | - | - | - |
| OPENS UP | 0.2 | +20.0 | 15.0 | 6.0 | 0.1 | +8.6 | 6.6 | 0.0 |
| OVERRUN THREAT | 0.0 | +0.2 | 0.0 | 4.9 | 0.0 | +0.1 | 0.0 | 0.0 |
| OVERRUNS AWAY | 0.6 | +13.6 | 36.6 | 13.9 | 0.7 | +9.2 | 68.2 | 13.4 |
| PATHS CROSS | 2.5 | +183.4 | 0.0 | 57.7 | 3.1 | +219.1 | 0.0 | 35.7 |
| PERIAPT WORTH | 0.1 | +6.3 | 0.0 | 0.0 | 0.1 | +4.8 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.1 | -2.1 | 0.0 | 1.7 | 0.1 | -1.3 | 0.0 | 0.0 |
| PLAN RESULT | 37.9 | +1456.2 | 1461.6 | 1261.3 | 39.4 | +1550.7 | 1814.3 | 926.2 |
| PURSUES BIG PREY | 0.0 | -0.7 | 0.0 | 0.0 | 0.1 | -4.8 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE | 0.0 | +4.9 | 0.0 | 0.0 | 0.1 | +13.2 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE NEXT TURN | 0.1 | +7.2 | 0.0 | 0.0 | 0.1 | +5.7 | 0.0 | 0.0 |
| RANDOM MOVE BY FIGURES | 1.1 | +19.9 | 0.0 | 29.2 | - | - | - | - |
| RANDOM MOVER NO PROMISE | 0.3 | -15.2 | 2.7 | 9.4 | - | - | - | - |
| REDIRECT BY WHAT IT STOPS | 0.3 | -6.6 | 0.0 | 3.8 | - | - | - | - |
| REDIRECT COUNTER | 2.6 | +165.7 | 0.0 | 40.6 | 4.8 | +329.5 | 0.0 | 86.6 |
| REDIRECT WEIGHED | 0.3 | +4.3 | 12.1 | 15.8 | 0.3 | +8.9 | 3.8 | 7.1 |
| RESERVE FALL BACK | 0.6 | +20.7 | 0.0 | 5.7 | - | - | - | - |
| RESTRAINS TO SHOOT | 0.1 | +5.1 | 0.0 | 6.5 | 0.1 | +3.4 | 0.0 | 0.0 |
| RISK BY ARC | 3.3 | +127.6 | 233.7 | 94.6 | 2.6 | +51.9 | 250.6 | 55.2 |
| SAFER THAN THE JOB | 1.2 | +59.9 | 0.0 | 35.3 | 0.6 | +25.5 | 0.0 | 22.3 |
| SCOUT SPOT | 0.4 | +0.5 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| SCOUT WAITS | 0.5 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.1 | -2.7 | 0.0 | 0.0 | - | - | - | - |
| SEARCH SPOT | 2.5 | +128.4 | 0.0 | 46.4 | 2.0 | +129.4 | 0.0 | 20.4 |
| SELF MOVE SPELL | 0.2 | +9.1 | 0.0 | 0.0 | 0.4 | +17.8 | 0.0 | 21.9 |
| SET UP TOGETHER | 0.7 | +44.4 | 0.0 | 27.4 | 1.3 | +106.2 | 44.6 | 32.1 |
| SET-UP ANY TARGET | 0.5 | +109.1 | 22.1 | 22.2 | 0.1 | +23.8 | 13.9 | 13.9 |
| SET-UP MISSED | 0.1 | +8.1 | 2.5 | 2.4 | 0.1 | +14.1 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.3 | +0.8 | 0.0 | 0.0 | 0.2 | +0.3 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 0.7 | +27.3 | 19.1 | 21.4 | - | - | - | - |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 3.8 |
| SHOT REPLANNED | 0.4 | +0.0 | 70.6 | 15.1 | 0.3 | +0.0 | 30.9 | 16.9 |
| SHOTS IN THE MOVE | 13.8 | +506.9 | 0.0 | 321.9 | 7.3 | +211.8 | 0.0 | 118.1 |
| SPELL CATCH ODDS | 0.0 | -0.1 | 0.0 | 0.0 | - | - | - | - |
| SPELL SETS UP CHARGE | 0.6 | +128.9 | 22.1 | 22.2 | 0.1 | +28.1 | 13.9 | 13.9 |
| SPELL WORTH | 1.4 | +26.6 | 95.3 | 99.6 | 2.5 | +44.1 | 35.3 | 43.6 |
| STABLE ROLE | 11.2 | +0.0 | 369.6 | 190.1 | - | - | - | - |
| STANDS TO CAST | 0.1 | +2.6 | 0.0 | 0.0 | 0.0 | +0.9 | 0.0 | 0.0 |
| STAY WEIGHED | 0.0 | +1.7 | 0.0 | 2.0 | - | - | - | - |
| STOPS | - | - | - | - | 0.1 | +4.1 | 23.1 | 3.8 |
| STOPS SHORT OF THE FLANK | 0.6 | +26.8 | 0.0 | 17.4 | 0.2 | +3.9 | 0.0 | 0.0 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 5.8 | 0.4 | +0.0 | 0.0 | 8.1 |
| SUPPORT NARROWED | 6.9 | -46.3 | 360.1 | 102.8 | - | - | - | - |
| SUPPORTS | 4.0 | +46.3 | 192.1 | 60.9 | - | - | - | - |
| SURE CHARGE BEATS ADVANCE | 0.1 | -1.7 | 0.0 | 0.0 | 0.1 | -4.8 | 2.8 | 0.0 |
| SURE REACH TOGETHER | 0.6 | -8.1 | 13.9 | 23.0 | 0.7 | -10.6 | 24.2 | 7.9 |
| THROUGH LINE OF FIRE | 0.3 | +11.0 | 0.0 | 7.0 | 0.4 | +26.1 | 0.0 | 5.4 |
| TURN WORTH | 0.9 | -69.2 | 80.6 | 19.9 | 0.4 | -35.7 | 22.9 | 5.4 |
| TWO OR MORE ARRIVE | 0.3 | +1.6 | 0.0 | 10.6 | 0.2 | +0.7 | 15.9 | 0.0 |
| WAIT AFTER COSTS | 6.7 | -258.9 | 183.6 | 145.5 | - | - | - | - |
| WALKS TO THE FIGHT | 2.0 | +37.3 | 51.1 | 11.1 | - | - | - | - |
| WAR ENGINE CHARGES | 0.1 | +4.5 | 7.8 | 5.1 | - | - | - | - |
| WAR ENGINE JOBS | 0.6 | +0.0 | 16.2 | 19.3 | - | - | - | - |
| WEARS DOWN | 1.6 | +48.8 | 122.8 | 60.9 | 1.3 | +36.6 | 143.8 | 27.8 |
| WHO HITS BACK | 0.2 | +7.7 | 0.0 | 2.4 | 0.2 | +23.2 | 0.0 | 21.4 |
| WHOLE FIGHT | 0.4 | +40.0 | 44.0 | 3.8 | 0.4 | +45.0 | 70.6 | 7.3 |
| WHOLE FIGHT GAIN | 0.2 | +19.4 | 28.1 | 1.7 | 0.6 | +47.8 | 27.3 | 12.1 |

### Rule changes: fw-h2h2-mine-1eea44e-p4

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 1091 | 1091 | 1091 | 30.31 | -56794 | -52.1 |
| PATHS CROSS | 203 | 203 | 203 | 5.64 | +14491 | +71.4 |
| SEARCH SPOT | 162 | 162 | 158 | 4.39 | +9293 | +58.8 |
| KILLS COUNT NEXT TURN | 568 | 564 | 155 | 4.31 | +6353 | +41.0 |
| BEST FIRST | 149 | 149 | 149 | 4.14 | +6487 | +43.5 |
| COUNTER-CHARGE COVER | 586 | 293 | 128 | 3.56 | +7978 | +62.3 |
| FOLLOW UP WEIGHED | 101 | 101 | 101 | 2.81 | +12740 | +126.1 |
| FACES THE THREAT | 99 | 99 | 99 | 2.75 | +7460 | +75.4 |
| FALLBACK BY WORTH | 444 | 444 | 82 | 2.28 | +4512 | +55.0 |
| BEST PREY | 193 | 191 | 63 | 1.75 | +2310 | +36.7 |
| SAFER THAN THE JOB | 63 | 63 | 63 | 1.75 | +3074 | +48.8 |
| SUPPORTS | 143 | 143 | 57 | 1.58 | +433 | +7.6 |
| COMBAT PIVOT | 52 | 52 | 52 | 1.44 | +0 | +0.0 |
| MOVE TO CHARGE | 93 | 93 | 52 | 1.44 | +1671 | +32.1 |
| MAX FOR POSITIONING | 363 | 193 | 48 | 1.33 | +398 | +8.3 |
| ADVANCE LANE KEPT | 46 | 46 | 46 | 1.28 | +0 | +0.0 |
| BLOCKED WHEEL | 46 | 46 | 46 | 1.28 | +500 | +10.9 |
| SHOTS IN THE MOVE | 761 | 506 | 46 | 1.28 | +1039 | +22.6 |
| ARTILLERY RE-ROLL WEIGHED | 45 | 45 | 45 | 1.25 | +0 | +0.0 |
| CHARGE NOW WEIGHED | 45 | 45 | 45 | 1.25 | +3384 | +75.2 |
| CANNON SIGHT KEPT | 43 | 43 | 43 | 1.19 | +0 | +0.0 |
| RISK BY ARC | 212 | 204 | 42 | 1.17 | +1709 | +40.7 |
| WALKS TO THE FIGHT | 71 | 71 | 38 | 1.06 | +509 | +13.4 |
| REDIRECT COUNTER | 267 | 131 | 37 | 1.03 | +3590 | +97.0 |
| MISSILES IN THE MOVE | 231 | 142 | 36 | 1.00 | +495 | +13.8 |
| HOLDS AMBUSHERS | 35 | 35 | 35 | 0.97 | +0 | +0.0 |
| MARCH ODDS | 38 | 36 | 34 | 0.94 | +911 | +26.8 |
| KILLS COUNT | 152 | 141 | 33 | 0.92 | +1460 | +44.2 |
| MARCH CHECK | 38 | 36 | 33 | 0.92 | +2187 | +66.3 |
| BEST OVERALL | 32 | 32 | 32 | 0.89 | +2390 | +74.7 |
| SET UP TOGETHER | 72 | 63 | 31 | 0.86 | +2005 | +64.7 |
| STOPS SHORT OF THE FLANK | 30 | 30 | 30 | 0.83 | +1105 | +36.8 |
| CHAFF PASSED | 28 | 28 | 28 | 0.78 | -81 | -2.9 |
| LONE WIZARD KEPT IN | 28 | 28 | 28 | 0.78 | +1699 | +60.7 |
| WAIT AFTER COSTS | 241 | 241 | 28 | 0.78 | +409 | +14.6 |
| THROUGH LINE OF FIRE | 27 | 27 | 27 | 0.75 | +1334 | +49.4 |
| KEEPS ITS TARGET | 147 | 144 | 26 | 0.72 | +427 | +16.4 |
| RANDOM MOVE BY FIGURES | 40 | 40 | 26 | 0.72 | +716 | +27.5 |
| SHOT REPLANNED | 26 | 26 | 26 | 0.72 | +0 | +0.0 |
| CAST JOB | 43 | 41 | 25 | 0.69 | +387 | +15.5 |
| CANNON PLANNED TARGET | 182 | 182 | 24 | 0.67 | -28 | -1.1 |
| CHARGE NOW FIRST | 119 | 119 | 23 | 0.64 | -869 | -37.8 |
| RESERVE FALL BACK | 23 | 23 | 23 | 0.64 | +745 | +32.4 |
| INVITES THE FIGHT | 67 | 67 | 22 | 0.61 | +313 | +14.2 |
| REDIRECT WEIGHED | 22 | 22 | 22 | 0.61 | +1107 | +50.3 |
| SCOUT WAITS | 21 | 21 | 21 | 0.58 | +0 | +0.0 |
| BIG CHARACTER SAFETY | 19 | 19 | 19 | 0.53 | -116 | -6.1 |
| STUCK PIVOT | 19 | 19 | 19 | 0.53 | +0 | +0.0 |
| MAKE SURE TOGETHER | 42 | 35 | 18 | 0.50 | +1210 | +67.2 |
| SHOOTERS IN TWO RANKS | 18 | 18 | 18 | 0.50 | +41 | +2.3 |
| BEST FACING | 17 | 17 | 17 | 0.47 | +500 | +29.4 |
| MOVE AND CAST | 17 | 17 | 17 | 0.47 | +728 | +42.8 |
| CASTER AWAY FROM SCREEN | 16 | 16 | 16 | 0.44 | +0 | +0.0 |
| FRIENDS SHOTS CHECKED | 15 | 15 | 15 | 0.42 | +627 | +41.8 |
| SHOOTS FROM THE BEST SPOT | 26 | 26 | 15 | 0.42 | +291 | +19.4 |
| WHO HITS BACK | 15 | 15 | 15 | 0.42 | +605 | +40.3 |
| WEARS DOWN | 106 | 101 | 13 | 0.36 | +344 | +26.5 |
| WHOLE FIGHT | 28 | 28 | 13 | 0.36 | +1210 | +93.1 |
| WHOLE FIGHT GAIN | 32 | 25 | 13 | 0.36 | +594 | +45.7 |
| MANOEUVRE | 15 | 15 | 12 | 0.33 | +222 | +18.5 |
| MODEL FACING | 11 | 11 | 11 | 0.31 | +2296 | +208.7 |
| CASTS FROM BEHIND | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| SHORT GUN FORWARD | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| WAR ENGINE JOBS | 20 | 20 | 9 | 0.25 | -277 | -30.7 |
| LOST CHARGE | 91 | 91 | 8 | 0.22 | +123 | +15.4 |
| PIVOT GUARDS FLANK | 8 | 8 | 8 | 0.22 | -124 | -15.6 |
| SURE CHARGE BEATS ADVANCE | 8 | 8 | 8 | 0.22 | -235 | -29.4 |
| MOVES UNITS SPELL | 7 | 7 | 7 | 0.19 | +138 | +19.7 |
| OVERRUNS AWAY | 46 | 43 | 7 | 0.19 | +136 | +19.4 |
| BEST PRIZE | 6 | 6 | 6 | 0.17 | -310 | -51.7 |
| CASTING BLOCK | 8 | 8 | 6 | 0.17 | +701 | +116.8 |
| KEEP FALLS | 6 | 6 | 6 | 0.17 | +255 | +42.4 |
| OPENS UP | 12 | 12 | 6 | 0.17 | +397 | +66.2 |
| PURSUES BIG PREY | 6 | 6 | 6 | 0.17 | -196 | -32.6 |
| RESTRAINS TO SHOOT | 6 | 6 | 6 | 0.17 | +306 | +51.0 |
| PERIAPT WORTH | 5 | 5 | 5 | 0.14 | +400 | +80.0 |
| SURE REACH TOGETHER | 46 | 40 | 5 | 0.14 | +71 | +14.2 |
| BACKUP TARGETS | 87 | 38 | 4 | 0.11 | +28 | +7.0 |
| BLOCKED CHARGE SKIPPED | 4 | 4 | 4 | 0.11 | +0 | +0.0 |
| FIRE AND FLEE | 4 | 4 | 4 | 0.11 | +32 | +8.1 |
| JOINT CHARGE PLAN | 9 | 9 | 4 | 0.11 | +446 | +111.4 |
| MISSILES NEXT TURN | 274 | 156 | 4 | 0.11 | +12 | +3.0 |
| NO RALLY LEFT | 4 | 4 | 4 | 0.11 | +749 | +187.2 |
| RAIDS THE BAGGAGE NEXT TURN | 5 | 5 | 4 | 0.11 | +323 | +80.7 |
| STANDS TO CAST | 4 | 4 | 4 | 0.11 | +14 | +3.5 |
| SUPPORT NARROWED | 248 | 248 | 4 | 0.11 | -19 | -4.8 |
| DEFENSIVE FLOOR | 4 | 4 | 3 | 0.08 | +29 | +9.7 |
| BOMBING RUN | 2 | 2 | 2 | 0.06 | +21 | +10.6 |
| CATCH ODDS | 2 | 2 | 2 | 0.06 | -8 | -3.9 |
| DEFENSIVE ARMY | 6 | 6 | 2 | 0.06 | -53 | -26.4 |
| EDGE GIVE GROUND | 11 | 11 | 2 | 0.06 | +81 | +40.6 |
| ELIXIR WORTH | 2 | 2 | 2 | 0.06 | +23 | +11.3 |
| FOCUS FIRE | 2 | 2 | 2 | 0.06 | +91 | +45.7 |
| HUNT ADVANCE | 5 | 5 | 2 | 0.06 | +90 | +44.9 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| NEEDED THERE | 3 | 3 | 2 | 0.06 | +0 | +0.0 |
| RAIDS THE BAGGAGE | 3 | 3 | 2 | 0.06 | +273 | +136.3 |
| BOUND ASSAILMENT | 1 | 1 | 1 | 0.03 | +0 | +0.2 |
| CHARIOT NO STATIC JOB | 3 | 3 | 1 | 0.03 | -5 | -5.4 |
| CONTINUE AHEAD WEIGHED | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| GIVES UP ITS SCREEN | 40 | 37 | 1 | 0.03 | +3 | +2.7 |
| STAY WEIGHED | 1 | 1 | 1 | 0.03 | +60 | +60.0 |
| TURN WORTH | 45 | 43 | 1 | 0.03 | +3 | +3.3 |
| TWO OR MORE ARRIVE | 17 | 16 | 1 | 0.03 | +16 | +16.0 |
| ALREADY CARRIED | 3 | not checked | - | - | - | - |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 28 | 28 | 0 | 0.00 | - | - |
| CARRIES OUT COUNTER | 3 | 3 | 0 | 0.00 | - | - |
| CARRIES OUT SET-UP | 7 | 7 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 33 | trace | - | - | - | - |
| CATCH FLIERS | 1 | not checked | - | - | - | - |
| CHAMPION TAKES THE CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| CHARIOT WIZARD CAREFUL | 9 | 9 | 0 | 0.00 | - | - |
| CHEAP HELPER | 7 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 34 | not checked | - | - | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT LIFT | 4 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 437 | not checked | - | - | - | - |
| GIVES UP | 61 | 56 | 0 | 0.00 | - | - |
| GROUND FLIERS | 3 | not checked | - | - | - | - |
| HELPER ALREADY ASKED | 2 | not checked | - | - | - | - |
| HELPER UNSEEN | 36 | 35 | 0 | 0.00 | - | - |
| HILL BY ITS CHANCE | 19 | 19 | 0 | 0.00 | - | - |
| HUNT DROPPED | 3 | trace | - | - | - | - |
| HUNT IN PAIRS | 24 | 11 | 0 | 0.00 | - | - |
| HUNT RESULT | 8 | trace | - | - | - | - |
| HUNT THE GUNS | 8 | trace | - | - | - | - |
| KEEPS ITS PREY | 10 | 10 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 28 | not checked | - | - | - | - |
| LONE WIZARD HOLDS BACK | 12 | 12 | 0 | 0.00 | - | - |
| LONG SHOT | 25 | 25 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 4 | 4 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 2 | trace | - | - | - | - |
| MARCH OVER CASTS | 34 | 34 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 7 | 7 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 6 | 2 | 0 | 0.00 | - | - |
| MOVE SPELL NOT WORTH | 1 | not checked | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 15 | trace | - | - | - | - |
| MOVE SPELL SPOT | 19 | not checked | - | - | - | - |
| NOT NEEDED | 20 | 20 | 0 | 0.00 | - | - |
| NOT TURNED | 470 | 470 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 33 | not checked | - | - | - | - |
| OPENS A LANE | 12 | 8 | 0 | 0.00 | - | - |
| OVERRUN THREAT | 2 | not checked | - | - | - | - |
| PLAN RESULT | 2782 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 10 | 10 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 11 | 11 | 0 | 0.00 | - | - |
| SCOUT SPOT | 19 | 19 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 3 | 3 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 22 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 23 | not checked | - | - | - | - |
| SET-UP MISSED | 4 | trace | - | - | - | - |
| SPELL CATCH ODDS | 1 | not checked | - | - | - | - |
| SPELL SETS UP CHARGE | 26 | not checked | - | - | - | - |
| SPELL WORTH | 138 | not checked | - | - | - | - |
| STABLE ROLE | 405 | 405 | 0 | 0.00 | - | - |
| STOPS | 3 | 3 | 0 | 0.00 | - | - |
| WAR ENGINE CHARGES | 3 | 3 | 0 | 0.00 | - | - |

### Off best figure: fw-h2h2-mine-1eea44e-p4

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 12.06 | 13.31 | 53.6 |
| FALLBACK | gate | 0.58 | 1.17 | 58.6 |
| TURN GATE | gate | 0.97 | 0.42 | 29.0 |
| RULE SWITCHED OFF | gate | - | 0.81 | 41.3 |
| CHARGE NOW FIRST | rule | 0.64 | - | 37.8 |
| PATHS CROSS | rule | 0.22 | 0.22 | 29.8 |
| BIG CHARACTER SAFETY | rule | 0.17 | 0.19 | 10.1 |
| AFTERMATH BAND | gate | 0.19 | 0.11 | 2.5 |
| CHAFF PASSED | rule | 0.14 | 0.11 | 8.9 |
| WAR ENGINE JOBS | rule | 0.25 | - | 30.7 |
| LONE CHARACTER SAFE SPOT | gate | 0.19 | 0.03 | 29.1 |
| PIVOT GUARDS FLANK | rule | 0.11 | 0.11 | 15.6 |
| SUPPORT REQUEST | gate | 0.03 | 0.19 | 93.0 |
| SURE CHARGE BEATS ADVANCE | rule | 0.11 | 0.11 | 29.4 |
| BLOCKED WHEEL | rule | 0.08 | 0.11 | 62.6 |
| CHARGE NOW WEIGHED | rule | 0.03 | 0.17 | 22.5 |
| BEST PRIZE | rule | 0.11 | 0.06 | 51.7 |
| CANNON PLANNED TARGET | rule | 0.11 | 0.06 | 54.2 |
| FIGHT ORDER BAND | gate | 0.14 | 0.03 | 2.2 |
| PURSUES BIG PREY | rule | 0.03 | 0.14 | 32.6 |
| STOPS SHORT OF THE FLANK | rule | 0.08 | 0.08 | 10.3 |
| SAFER THAN THE JOB | rule | 0.08 | 0.06 | 11.1 |
| MARCH ODDS | rule | 0.06 | 0.06 | 9.2 |
| SUPPORT NARROWED | rule | 0.11 | - | 4.8 |
| FOLLOW UP WEIGHED | rule | 0.06 | 0.03 | 1.8 |
| AFTERMATH NEEDS NEXT CHARGE | gate | - | 0.06 | 205.5 |
| CATCH ODDS | rule | 0.06 | - | 3.9 |
| DEFENSIVE ARMY | rule | 0.06 | - | 26.4 |
| FACES THE THREAT | rule | - | 0.06 | 6.8 |
| CHARIOT NO STATIC JOB | rule | - | 0.03 | 5.4 |
| NO REASON | gate | 0.03 | - | 100.7 |
| STANDS TO CAST | rule | 0.03 | - | 21.2 |
| WHO HITS BACK | rule | 0.03 | - | 5.0 |

### Plans: fw-h2h2-mine-1eea44e-p4

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 12.2 | 15% | 378 | 325 | 86% |
| Mine | charge | 4.1 | 59% | 365 | 328 | 90% |
| Mine | close in | 3.9 | 30% | 229 | 103 | 45% |
| Mine | hold | 4.3 | 24% | 291 | 0 | 0% |
| Mine | join | 0.5 | 89% | 8 | 0 | 0% |
| Mine | shoot | 8.6 | 60% | 280 | 701 | 250% |
| Mine | support | 4.2 | 91% | 29 | 0 | 0% |
| Opponent | advance | 14.0 | 19% | 708 | 487 | 69% |
| Opponent | charge | 4.3 | 58% | 547 | 435 | 80% |
| Opponent | close in | 5.9 | 31% | 522 | 290 | 56% |
| Opponent | hold | 4.3 | 35% | 371 | 0 | 0% |
| Opponent | join | 0.4 | 87% | 17 | 0 | 0% |
| Opponent | shoot | 3.4 | 69% | 107 | 342 | 320% |
| Opponent | support | 6.9 | 92% | 245 | 0 | 0% |

### Packages: hunt the guns, fw-h2h2-mine-1eea44e-p4

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.1 | 2 | 0 | 0% | 50% | 0% | 2.0 | 379 | 97 | 50% | 12 |
| Opponent | 0.2 | 6 | 0 | 50% | 67% | 0% | 2.0 | 363 | 218 | 67% | 86 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 150 |
| Empire of Man | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 564 | 0 | 0% | 8 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| High Elf Realms | 0.1 | 1 | 0 | 100% | 100% | 0% | 2.0 | 104 | 98 | 100% | 137 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 164 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 164 |
| Tomb Kings of Khemri | 0.5 | 2 | 0 | 0% | 50% | 0% | 2.0 | 308 | 97 | 50% | 0 |
| Vampire Counts | 0.4 | 3 | 0 | 33% | 67% | 0% | 2.0 | 319 | 180 | 67% | 43 |
| Warriors of Chaos | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Wood Elf Realms | 0.2 | 1 | 0 | 100% | 100% | 0% | 2.0 | 697 | 668 | 100% | 0 |

### Battle groups: fw-h2h2-mine-1eea44e-p4

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 8.8 | 24% | 36% | 9% | 43% | 29% | 7% | 14% | 50% | 0% |
| Mine | REDIRECT COUNTER | 2.6 | 34% | 53% | 6% | 50% | 30% | 0% | 10% | 53% | 7% |
| Opponent | COUNTER-CHARGE COVER | 7.4 | 18% | 70% | 11% | 40% | 43% | 10% | 5% | 43% | 0% |
| Opponent | REDIRECT COUNTER | 4.8 | 25% | 79% | 14% | 17% | 35% | 0% | 19% | 43% | 3% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: fw-h2h2-mine-1eea44e-p4

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 4 | 154 (4) | 154 | 0 | 100 | 0% | 3.5 | - | 154 (4) | - | 0 (1) | 248 (3) |
| Mine | Chaff | 43 | 39 (43) | 23 | 16 | 54 | 30% | 2.4 | 29 (15) | 39 (16) | 53 (12) | 53 (27) | 18 (16) |
| Mine | Character | 106 | 36 (106) | 36 | 0 | 51 | 12% | 2.3 | 42 (32) | 41 (42) | 41 (9) | 37 (45) | 46 (38) |
| Mine | Clean-up | 17 | 92 (17) | 57 | 36 | 49 | 29% | 3.4 | 75 (4) | 95 (10) | 100 (3) | 157 (9) | 41 (8) |
| Mine | Early | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Mine | Fast | 2 | 178 (2) | 178 | 0 | 100 | 0% | 1.5 | 0 (1) | 357 (1) | - | 178 (2) | - |
| Mine | Fast Hammer | 40 | 41 (40) | 30 | 11 | 47 | 10% | 2.9 | 42 (25) | 43 (9) | 37 (6) | 42 (26) | 39 (14) |
| Mine | Fragile | 4 | 29 (4) | 29 | 0 | 73 | 0% | 2.8 | 0 (3) | 108 (1) | - | 108 (1) | 0 (3) |
| Mine | Hammer | 64 | 32 (64) | 19 | 13 | 59 | 22% | 2.6 | 36 (11) | 34 (45) | 12 (8) | 27 (39) | 38 (25) |
| Mine | Holder | 30 | 69 (30) | 25 | 44 | 21 | 43% | 2.6 | 21 (6) | 95 (17) | 42 (7) | 79 (18) | 54 (12) |
| Mine | Shooter | 35 | 55 (35) | 29 | 27 | 47 | 0% | 1.9 | 14 (8) | 77 (22) | 39 (5) | 68 (27) | 9 (8) |
| Mine | Support | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | - | 0 (1) | 0 (1) | - |
| Mine | War machine | 56 | 45 (56) | 45 | 0 | 70 | 4% | 1.1 | 14 (16) | 54 (30) | 81 (10) | 17 (7) | 49 (49) |
| Mine | Wizard | 17 | 12 (17) | 12 | 0 | 38 | 0% | 2.4 | 12 (6) | 0 (5) | 0 (1) | 0 (6) | 9 (6) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Chaff | 76 | 54 (76) | 24 | 30 | 44 | 45% | 2.8 | 47 (26) | 28 (21) | 82 (29) | 64 (57) | 16 (19) |
| Opponent | Character | 97 | 74 (97) | 74 | 0 | 30 | 19% | 2.2 | 80 (39) | 73 (42) | 92 (7) | 78 (44) | 78 (44) |
| Opponent | Clean-up | 13 | 60 (13) | 18 | 42 | 30 | 38% | 3.8 | 0 (7) | 92 (3) | 88 (3) | 37 (8) | 87 (5) |
| Opponent | Fast Hammer | 55 | 48 (55) | 28 | 20 | 32 | 35% | 2.8 | 39 (26) | 53 (19) | 69 (10) | 49 (33) | 45 (22) |
| Opponent | Fragile | 17 | 59 (17) | 59 | 0 | 60 | 18% | 1.5 | 0 (2) | 0 (8) | 75 (6) | 36 (12) | 0 (4) |
| Opponent | Hammer | 65 | 52 (65) | 38 | 14 | 46 | 31% | 3.3 | 46 (20) | 57 (39) | 10 (6) | 45 (40) | 62 (25) |
| Opponent | Holder | 30 | 30 (30) | 0 | 30 | 28 | 57% | 3.7 | 0 (11) | 53 (14) | 0 (5) | 50 (13) | 13 (17) |
| Opponent | Shooter | 34 | 96 (34) | 37 | 59 | 32 | 0% | 1.4 | 132 (8) | 87 (24) | 71 (2) | 91 (19) | 102 (15) |
| Opponent | Support | 6 | 0 (6) | 0 | 0 | 82 | 33% | 3.0 | - | 0 (2) | 0 (1) | - | 0 (3) |
| Opponent | War machine | 6 | 69 (6) | 69 | 0 | 61 | 17% | 1.0 | 117 (3) | 0 (3) | - | 117 (3) | 0 (3) |
| Opponent | Wizard | 20 | 17 (20) | 17 | 0 | 27 | 10% | 2.5 | 19 (13) | 30 (3) | 0 (2) | 10 (10) | 33 (8) |

### Charged fights: fw-h2h2-mine-1eea44e-p4

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 157 | 124 | 2.2 | 1.1 | 55 | 21 | +34 | 2 of 9 | 5 of 9 | +177 | +16 |
| Mine | Chaos Dwarfs | 4 | 174 | 264 | 2.0 | 1.1 | 132 | 0 | +132 | 1 of 8 | 6 of 8 | +175 | +126 |
| Mine | Dwarfen Mountain Holds | 3 | 602 | 0 | 2.3 | 1.1 | 0 | 90 | -90 | 3 of 7 | 6 of 7 | +0 | -105 |
| Mine | Empire of Man | 5 | 137 | 218 | 2.2 | 1.1 | 99 | 26 | +73 | 4 of 11 | 7 of 11 | +347 | +46 |
| Mine | Grand Cathay | 4 | 346 | 236 | 3.0 | 1.2 | 79 | 141 | -62 | 4 of 12 | 10 of 12 | +96 | -94 |
| Mine | High Elf Realms | 4 | 468 | 245 | 2.5 | 1.1 | 98 | 0 | +98 | 4 of 10 | 6 of 10 | +177 | +89 |
| Mine | Kingdom of Bretonnia | 1 | 65 | 717 | 4.0 | 1.2 | 179 | 0 | +179 | 1 of 4 | 3 of 4 | +572 | +48 |
| Mine | Lizardmen | 1 | 0 | 1011 | 4.0 | 1.5 | 253 | 188 | +64 | 4 of 4 | 2 of 4 | +200 | -71 |
| Mine | Ogre Kingdoms | 2 | 0 | 145 | 4.0 | 1.1 | 36 | 110 | -74 | 5 of 8 | 2 of 8 | +0 | -84 |
| Mine | Skaven | 2 | 318 | 33 | 1.5 | 1.3 | 22 | 0 | +22 | 0 of 3 | 2 of 3 | +0 | +33 |
| Mine | Tomb Kings of Khemri | 2 | 0 | 790 | 5.0 | 1.2 | 158 | 0 | +158 | 6 of 10 | 6 of 10 | +58 | +183 |
| Mine | Vampire Counts | 2 | 14 | 416 | 5.5 | 1.0 | 76 | 0 | +76 | 2 of 11 | 6 of 11 | - | +76 |
| Mine | Warriors of Chaos | 2 | 0 | 230 | 4.0 | 1.0 | 58 | 0 | +58 | 2 of 8 | 8 of 8 | - | +58 |
| **Mine** | all armies | 36 | 217 | 265 | 2.9 | 1.1 | 91 | 42 | +48 | 38 of 105 | 69 of 105 | +154 | +32 |
| Opponent | Empire of Man | 1 | 570 | 185 | 1.0 | 1.0 | 185 | 214 | -29 | 1 of 1 | 0 of 1 | - | -29 |
| Opponent | High Elf Realms | 5 | 224 | 1006 | 4.8 | 1.1 | 210 | 11 | +199 | 13 of 24 | 15 of 24 | +590 | +163 |
| Opponent | Lizardmen | 2 | 0 | 646 | 4.5 | 1.2 | 144 | 50 | +93 | 5 of 9 | 5 of 9 | +0 | +105 |
| Opponent | Orc & Goblin Tribes | 3 | 0 | 537 | 2.3 | 1.0 | 230 | 103 | +127 | 2 of 7 | 5 of 7 | - | +127 |
| Opponent | Skaven | 4 | 95 | 0 | 1.0 | 1.0 | 0 | 321 | -321 | 2 of 4 | 1 of 4 | - | -321 |
| Opponent | Tomb Kings of Khemri | 2 | 258 | 739 | 3.5 | 1.0 | 211 | 0 | +211 | 3 of 7 | 4 of 7 | - | +211 |
| Opponent | Vampire Counts | 6 | 40 | 483 | 5.2 | 1.2 | 93 | 26 | +68 | 18 of 31 | 14 of 31 | +208 | +47 |
| Opponent | Warriors of Chaos | 7 | 0 | 633 | 2.9 | 1.1 | 222 | 29 | +193 | 14 of 20 | 10 of 20 | +335 | +185 |
| Opponent | Wood Elf Realms | 6 | 200 | 664 | 4.7 | 1.1 | 142 | 13 | +130 | 9 of 28 | 20 of 28 | +240 | +117 |
| **Opponent** | all armies | 36 | 112 | 581 | 3.6 | 1.1 | 160 | 36 | +124 | 67 of 131 | 74 of 131 | +279 | +110 |

### Effective charges: fw-h2h2-mine-1eea44e-p4

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 9 | 0 | 0 | 3 (net -17) | 2 (net +6) | 0 | 3 (net +133) | 1 | 38% (3 of 8) |
| Mine | Chaos Dwarfs | 8 | 2 (net +348) | 0 | 1 (net +0) | 0 | 0 | 5 (net +72) | 0 | 12% (1 of 8) |
| Mine | Dwarfen Mountain Holds | 7 | 1 (net -428) | 0 | 2 (net +0) | 1 (net +0) | 0 | 3 (net -67) | 0 | 29% (2 of 7) |
| Mine | Empire of Man | 11 | 2 (net +76) | 0 | 2 (net +234) | 1 (net +235) | 1 (net +30) | 5 (net -17) | 0 | 18% (2 of 11) |
| Mine | Grand Cathay | 12 | 0 | 0 | 1 (net +329) | 4 (net +81) | 2 (net -302) | 4 (net -94) | 1 | 9% (1 of 11) |
| Mine | High Elf Realms | 10 | 2 (net +0) | 0 | 1 (net +0) | 4 (net +157) | 2 (net +150) | 1 (net +54) | 0 | 10% (1 of 10) |
| Mine | Kingdom of Bretonnia | 4 | 0 | 0 | 0 | 1 (net +572) | 0 | 1 (net +145) | 2 | 0% (0 of 2) |
| Mine | Lizardmen | 4 | 2 (net -46) | 0 | 0 | 1 (net -142) | 0 | 1 (net +490) | 0 | 0% (0 of 4) |
| Mine | Ogre Kingdoms | 8 | 0 | 0 | 3 (net -43) | 2 (net -150) | 0 | 0 | 3 | 60% (3 of 5) |
| Mine | Skaven | 3 | 0 | 0 | 0 | 0 | 1 (net +0) | 1 (net +66) | 1 | 0% (0 of 2) |
| Mine | Tomb Kings of Khemri | 10 | 2 (net +246) | 0 | 2 (net +58) | 1 (net +195) | 1 (net +144) | 4 (net +158) | 0 | 20% (2 of 10) |
| Mine | Vampire Counts | 11 | 0 | 0 | 1 (net +0) | 1 (net +27) | 4 (net +109) | 4 (net +69) | 1 | 10% (1 of 10) |
| Mine | Warriors of Chaos | 8 | 0 | 0 | 1 (net +0) | 0 | 1 (net +98) | 4 (net +63) | 2 | 17% (1 of 6) |
| Opponent | Empire of Man | 1 | 0 | 0 | 0 | 1 (net -29) | 0 | 0 | 0 | 0% (0 of 1) |
| Opponent | High Elf Realms | 24 | 1 (net +0) | 0 | 4 (net +112) | 5 (net +101) | 3 (net +67) | 8 (net +402) | 3 | 19% (4 of 21) |
| Opponent | Lizardmen | 9 | 1 (net +434) | 1 (net +0) | 1 (net +0) | 2 (net +144) | 0 | 1 (net +167) | 3 | 17% (1 of 6) |
| Opponent | Orc & Goblin Tribes | 7 | 1 (net +265) | 0 | 0 | 0 | 0 | 1 (net -377) | 5 | 0% (0 of 2) |
| Opponent | Skaven | 4 | 1 (net -540) | 0 | 1 (net -540) | 0 | 0 | 1 (net -140) | 1 | 33% (1 of 3) |
| Opponent | Tomb Kings of Khemri | 7 | 1 (net +176) | 0 | 1 (net +0) | 1 (net +45) | 1 (net +0) | 3 (net +419) | 0 | 14% (1 of 7) |
| Opponent | Vampire Counts | 31 | 8 (net +75) | 1 (net +72) | 5 (net -37) | 5 (net +95) | 6 (net +70) | 6 (net +119) | 0 | 16% (5 of 31) |
| Opponent | Warriors of Chaos | 20 | 3 (net +67) | 2 (net +62) | 5 (net +113) | 2 (net +450) | 1 (net +77) | 5 (net +372) | 2 | 28% (5 of 18) |
| Opponent | Wood Elf Realms | 28 | 2 (net -76) | 0 | 5 (net +187) | 5 (net +67) | 3 (net +46) | 10 (net +192) | 3 | 20% (5 of 25) |

### Charged fights, damage counted: fw-h2h2-mine-1eea44e-p4

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 11 | 331 | 348 | +75 | 139 | 72 | +67 | +20.3 |
| Mine | Effective (55-75%) | 17 | 214 | 267 | +43 | 99 | 78 | +21 | +9.8 |
| Mine | 76-89% | 18 | 245 | 189 | +86 | 155 | 87 | +68 | +27.7 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 36 | 221 | 156 | +56 | 92 | 37 | +55 | +24.9 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 12 | 447 | 104 | +34 | 92 | 65 | +28 | +6.2 |
| Mine | No odds | 11 | 229 | 159 | -39 | 19 | 67 | -48 | -21.2 |
| Mine | All fights | 105 | 262 | 194 | +48 | 101 | 62 | +39 | +14.9 |
| Opponent | Long shot (under 50%) | 18 | 242 | 229 | +55 | 139 | 72 | +66 | +27.4 |
| Opponent | 50-54% | 4 | 105 | 154 | +49 | 49 | 2 | +48 | +45.5 |
| Opponent | Effective (55-75%) | 22 | 273 | 264 | +56 | 131 | 65 | +67 | +24.5 |
| Opponent | 76-89% | 21 | 282 | 224 | +120 | 155 | 50 | +105 | +37.4 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 35 | 364 | 238 | +246 | 294 | 44 | +249 | +68.4 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 14 | 466 | 98 | +60 | 79 | 11 | +68 | +14.7 |
| Opponent | No odds | 17 | 288 | 193 | +111 | 176 | 61 | +116 | +40.2 |
| Opponent | All fights | 131 | 312 | 216 | +124 | 177 | 50 | +128 | +40.9 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| fw-h2h2-mine-1eea44e-p4 | move | 422 | 100 (24%) | 67 (16%) | 61 (14%) | 261 (62%) |
| fw-h2h2-mine-1eea44e-p4 | objective | 355 | 60 (17%) | 44 (12%) | 48 (14%) | 247 (70%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0114, L0130, L2527, L2634 |
| Charmed Shield | Opponent | L0434, L0624, L0926, L1034, L1126, L1427, L2227, L2527, L2634, L3234 |
| Clockwork Compass | Mine | L1220 |
| Elixir of Power | Mine | L1126 |
| Elixir of Power | Opponent | L0819, L1719, L1819 |
| Fistful of Laurels | Mine | L1819, L1835 |
| Invocation of Nehek | Mine | L2527 |
| Invocation of Nehek | Opponent | L0624, L1427, L2227, L2527 |
| Opal Amulet | Mine | L1427 |
| Opal Amulet | Opponent | L0114, L0214, L1314 |
| Periapt of Soul Exchange | Mine | L2021, L2123 |
| Periapt of Soul Exchange | Opponent | L0520, L1220, L1621, L2021 |
| Ring of Doom | Mine | L0214, L0230, L1126, L1220, L1523 |
| Ring of Doom | Opponent | L0315, L1331, L2331 |
| Ring of Jet | Mine | L1017, L1034, L1126, L1220 |
| Standard of the Fell Warrior | Mine | L1314, L1331 |
| Standard of the Fell Warrior | Opponent | L0713 |
| Storm Daemon (Renegade 2.0) | Mine | L2123 |
| Storm Daemon (Renegade 2.0) | Opponent | L1621, L2021 |
| Twice-Blessed Armour | Mine | L0713, L0729, L1017, L1034 |
| Witch Hunter's Ward | Mine | L0713, L0729, L0819, L0835 |
| Witch Hunter's Ward | Opponent | L0608 |

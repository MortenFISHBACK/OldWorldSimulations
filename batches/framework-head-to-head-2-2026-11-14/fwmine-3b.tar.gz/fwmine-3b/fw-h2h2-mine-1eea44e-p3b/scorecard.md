# Doctrine scorecard: fw-h2h2-mine-1eea44e-p3b

### Scorecard: fw-h2h2-mine-1eea44e-p3b

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L1535 | 5 | 1 | Mine | yes | - | 3 | 3 | 0 | 0 | 0 | 0 | 0 |
| L1535 | 5 | 1 | Opponent | yes | - | 3 | 1 | 3 | 0 | 0 | 0 | 298 |
| L1633 | 1 | 1 | Mine | no | 3 | 2 | 4 | 0 | 1 | 0 | 0 | 200 |
| L1633 | 1 | 1 | Opponent | no | 0 | 1 | 7 | 3 | 0 | 0 | 0 | 0 |
| L1731 | 3 | 1 | Mine | no | 5 | 4 | 5 | 0 | 0 | 0 | 0 | 0 |
| L1731 | 3 | 1 | Opponent | no | 0 | 3 | 4 | 0 | 2 | 0 | 0 | 170 |
| L1831 | 1 | 1 | Mine | no | 3 | - | 4 | 1 | 1 | 0 | 0 | 0 |
| L1831 | 1 | 1 | Opponent | no | 1 | 6 | 1 | 1 | 3 | 0 | 0 | 170 |
| L1932 | 6 | 1 | Mine | no | 3 | 2 | 3 | 0 | 1 | 0 | 0 | 416 |
| L1932 | 6 | 1 | Opponent | no | 0 | 2 | 5 | 2 | 0 | 0 | 0 | 340 |
| L2033 | 5 | 1 | Mine | yes | - | - | 0 | 4 | 0 | 0 | 0 | 420 |
| L2033 | 5 | 1 | Opponent | yes | - | 4 | 1 | 2 | 0 | 0 | 0 | 639 |
| L2223 | 3 | 1 | Mine | no | 7 | 2 | 4 | 0 | 1 | 0 | 0 | 55 |
| L2223 | 3 | 1 | Opponent | no | 2 | 2 | 4 | 0 | 2 | 0 | 0 | 185 |
| L2327 | 5 | 1 | Mine | yes | - | 2 | 3 | 0 | 0 | 0 | 0 | 185 |
| L2327 | 5 | 1 | Opponent | yes | - | 2 | 4 | 0 | 1 | 0 | 0 | 0 |
| L2433 | 3 | 1 | Mine | no | 0 | 5 | 3 | 1 | 0 | 0 | 0 | 0 |
| L2433 | 3 | 1 | Opponent | no | 1 | 1 | 4 | 1 | 0 | 0 | 0 | 236 |
| L2630 | 2 | 1 | Mine | - | - | 2 | 3 | 2 | 1 | 0 | 0 | 0 |
| L2630 | 2 | 1 | Opponent | - | - | 2 | 4 | 1 | 1 | 0 | 0 | 0 |
| L2832 | 6 | 1 | Mine | no | 0 | 2 | 1 | 0 | 0 | 0 | 0 | 0 |
| L2832 | 6 | 1 | Opponent | no | 0 | 2 | 2 | 4 | 0 | 0 | 0 | 170 |
| L3133 | 1 | 1 | Mine | no | 4 | 2 | 1 | 0 | 1 | 0 | 0 | 170 |
| L3133 | 1 | 1 | Opponent | no | 0 | 2 | 3 | 2 | 0 | 0 | 0 | 334 |
| **Average** | | | Mine | 27% | 3.1 | 2.6 | 2.8 | 0.7 | 0.5 | 0.0 | 0.0 | 120.5 |
| **Average** | | | Opponent | 27% | 0.5 | 2.5 | 3.3 | 1.6 | 0.8 | 0.0 | 0.0 | 211.8 |

### KPIs: fw-h2h2-mine-1eea44e-p3b

Rules off - Opponent only: WAR ENGINE JOBS, STAY WEIGHED, BEST FIRST, RANDOM MOVE BY FIGURES, RANDOM MOVER NO PROMISE, STABLE ROLE, WOUNDED STAYS OUT, BEST FACING, LOST CHARGE, SCREEN BY WHAT IT SAVES, REDIRECT BY WHAT IT STOPS, SHOOTER COUNTED ONCE, LURE BY WHAT IT DRAWS, HILL BY ITS CHANCE, MOVE TO CHARGE, LONG SHOT, DEFENSIVE ARMY, SHOOTS FROM THE BEST SPOT, SUPPORTS, RESERVE FALL BACK, WAIT AFTER COSTS, CHARGE NOW FIRST, SUPPORT NARROWED, WAR ENGINE CHARGES, DEFENSIVE FLOOR.

Morten 2026-11-10; 12 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 59) | 0% (0 of 59) | 0% (0 of 118) |
| Winner chose to follow up after the loser gave ground |  | 97% (32 of 33); on the table 97% | 92% (11 of 12); on the table 92% | 96% (43 of 45); on the table 96% |
| Winner chose to pursue after the loser fell back in good order |  | 86% (6 of 7); on the table 86% | 88% (7 of 8); on the table 88% | 87% (13 of 15); on the table 87% |
| Winner chose to pursue after the loser fled |  | 64% (9 of 14); on the table 71% | 44% (4 of 9); on the table 56% | 57% (13 of 23); on the table 65% |
| Winner chose to follow up or pursue (all three) |  | 87% (47 of 54); on the table 89% | 76% (22 of 29); on the table 79% | 83% (69 of 83); on the table 86% |
| Magic missiles tried each own turn | 50%+ | 13% (8 of 60) | 44% (8 of 18) | 21% (16 of 78) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 21% (8 of 38) | 73% (8 of 11) | 33% (16 of 49) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 31% (5 of 16) | - | 31% (5 of 16) |
| Points that never fought | lower | 22% (4970 of 22106) | 21% (5125 of 23998) | 22% (10095 of 46104) |
|   infantry points that never fought | lower | 40% (1571 of 3970) | 40% (1911 of 4769) | 40% (3482 of 8739) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 43% (33 of 77) | 59% (64 of 109) | 52% (97 of 186) |
| Bound items with a magic missile used (at least once a game) |  | 100% (4 of 4); 1.2 uses a game | 91% (10 of 11); 3.3 uses a game | 93% (14 of 15); 2.3 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 100% (3 of 3); 0.2 uses a game | 20% (1 of 5); 0.1 uses a game | 50% (4 of 8); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 41% (7856 of 19206) | 50% (11194 of 22246) | 46% (19050 of 41452) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.0 (23%) | 0.2 (20%) | 1.2 (23%) |
| MARCHED: its unit marched | 0.8 (19%) | 0.1 (10%) | 0.9 (18%) |
| CHARGED: its unit charged | 0.2 (4%) | 0.0 (0%) | 0.2 (3%) |
| IN COMBAT: engaged in combat | 1.0 (23%) | 0.2 (30%) | 1.2 (24%) |
| REAR RANK: in a rear rank | 0.2 (4%) | 0.0 (0%) | 0.2 (3%) |
| GONE: slain | 0.5 (12%) | 0.3 (40%) | 0.8 (16%) |
| OFF THE TABLE: off the table or not arrived | 0.3 (8%) | 0.0 (0%) | 0.3 (6%) |
| NOT OFFERED: not in the cast list | 0.3 (8%) | 0.0 (0%) | 0.3 (6%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.8 | 0.3 | 0.9 | 1.3 | 0.8 | 0.7 |
| not cast | 5.8 | 1.7 | 3.1 | 5.2 | 1.7 | 15.3 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.8 (5%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.1 (1%) | 0.5 (30%) | 0.2 (5%) | 1.2 (23%) | 0.0 (0%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.9 (18%) | 0.2 (10%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (3%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.2 (4%) | 0.1 (5%) | 0.2 (5%) | 1.2 (24%) | 0.2 (10%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.6 (10%) | 0.0 (0%) | 0.5 (16%) | 0.2 (3%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (0%) | 0.1 (5%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.6 (4%) |
| GONE: slain | 2.0 (35%) | 0.3 (20%) | 1.2 (41%) | 0.8 (16%) | 0.8 (50%) | 4.9 (32%) |
| OFF THE TABLE: off the table or not arrived | 0.3 (6%) | 0.3 (20%) | 0.3 (11%) | 0.3 (6%) | 0.0 (0%) | 0.0 (0%) |
| STUPIDITY: Stupidity | 0.2 (3%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (1%) | 0.1 (5%) | 0.0 (0%) | 0.0 (0%) | 0.5 (30%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (6%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.2 (39%) | 0.2 (15%) | 0.7 (22%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 9.1 (59%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.7 a game | 0.2 a game | 0.5 a game |
| stood (cast and not dispelled) | 67% (2 of 3) | 67% (2 of 3) | 67% (4 of 6) |
| the unit moved after it | 100% (2 of 2) | 50% (1 of 2) | 75% (3 of 4) |
| it charged on its next turn | 0% (0 of 2) | 0% (0 of 2) | 0% (0 of 4) |
| the enemy charged it first | 50% (1 of 2) | 50% (1 of 2) | 50% (2 of 4) |
| it fought by the end of its next turn | 50% (1 of 2) | 0% (0 of 2) | 25% (1 of 4) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 2) | 0% (0 of 2) | 0% (0 of 4) |
| none of these (no charge, no fight, no charge escaped) | 50% (1 of 2) | 50% (1 of 2) | 50% (2 of 4) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 53% (103 of 194) | 56% (110 of 195) | 55% (213 of 389) |
|   cavalry | 71% (15 of 21) | 48% (31 of 64) | 54% (46 of 85) |
|   character | 41% (9 of 22) | 33% (16 of 49) | 35% (25 of 71) |
|   chariot | 53% (10 of 19) | - | 53% (10 of 19) |
|   infantry | 53% (50 of 94) | 77% (63 of 82) | 64% (113 of 176) |
|   monster | 30% (8 of 27) | - | 30% (8 of 27) |
|   war machine | 100% (11 of 11) | - | 100% (11 of 11) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.1 (27%) | 1.6 (22%) | 3.7 (25%) |
| CHARGED: it charged | 1.0 (13%) | 1.9 (27%) | 2.9 (20%) |
| FLEEING: it fled or was fleeing | 0.1 (1%) | 0.1 (1%) | 0.2 (1%) |
| IN COMBAT: it fought this turn or the last | 0.8 (10%) | 1.2 (16%) | 1.9 (13%) |
| NO TARGET IN RANGE | 2.0 (26%) | 1.0 (14%) | 3.0 (20%) |
| ONLY IN COMBAT: the only targets were in combat | 0.4 (5%) | 0.7 (9%) | 1.1 (7%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.0 (13%) | 0.7 (9%) | 1.7 (11%) |
| SHELTERED: the target was sheltered | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| OTHER BAR | 0.2 (2%) | 0.0 (0%) | 0.2 (1%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 5.4 | 1.6 | 77% | 7.7 pts | 42 pts |
| character | 2.2 | 0.2 | 92% | 6.1 pts | 13 pts |
| chariot | 0.8 | 0.0 | 100% | 0.0 pts | 0 pts |
| infantry | 15.4 | 4.8 | 78% | 9.5 pts | 147 pts |
| monster | 0.7 | 0.3 | 62% | 20.4 pts | 14 pts |
| war machine | 0.9 | 0.8 | 55% | 14.4 pts | 13 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 5.7 | 5.0 | 5.3 |
| Charges that made contact a game | 4.4 | 3.9 | 4.2 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.00 declared, 0.60 contact (5 units) | 0.50 declared, 0.50 contact (2 units) | 0.86 declared, 0.57 contact (7 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.50 declared, 0.50 contact (2 units) | 0.67 declared, 0.67 contact (3 units) | 0.60 declared, 0.60 contact (5 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.75 declared, 0.59 contact (83 units) | 0.59 declared, 0.45 contact (97 units) | 0.66 declared, 0.52 contact (180 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 48% (14 of 29) | 80% (4 of 5) | 50% (2 of 4) | 53% (20 of 38) |
| Character in a unit | 62% (5 of 8) | 50% (1 of 2) | 50% (2 of 4) | 57% (8 of 14) |
| Character on its own | 57% (12 of 21) | 64% (7 of 11) | 19% (5 of 26) | 41% (24 of 58) |
| Chariot | 67% (2 of 3) | - | - | 67% (2 of 3) |
| Infantry | 76% (16 of 21) | 62% (10 of 16) | 0% (0 of 1) | 68% (26 of 38) |
| Monster | 39% (7 of 18) | 50% (2 of 4) | - | 41% (9 of 22) |
| Monstrous | 75% (6 of 8) | 40% (2 of 5) | - | 62% (8 of 13) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| High Elf Realms | 1 | 100% (3 of 3); on the table 100% | 17% (1 of 6) | 10% | 29% (2 of 7) | 100% (2 of 2); 5.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | 50% (1 of 2); on the table 50% | - | 37% | 33% (2 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Lizardmen | 1 | 33% (1 of 3); on the table 33% | 17% (1 of 6) | 9% | 29% (2 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 1 | 100% (6 of 6); on the table 100% | 0% (0 of 6) | 24% | 43% (3 of 7) | 100% (1 of 1); 4.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 1 | 100% (5 of 5); on the table 100% | 0% (0 of 6) | 14% | 75% (6 of 8) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Skaven | 1 | 33% (1 of 3); on the table 67% | 0% (0 of 6) | 65% | 86% (6 of 7) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Tomb Kings of Khemri | 3 | 100% (12 of 12); on the table 100% | - | 12% | 18% (2 of 11) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 3 | 91% (10 of 11); on the table 91% | 6% (1 of 18) | 26% | 44% (8 of 18) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 7 | 78% (29 of 37); on the table 81% | 42% (10 of 24) | 19% | 43% (27 of 63) | 100% (3 of 3); 1.9 uses a game | 0.0 uses a game | 100% (1 of 1); 0.1 uses a game |
| Wood Elf Realms | 5 | 100% (1 of 1); on the table 100% | 50% (3 of 6) | 22% | 75% (39 of 52) | 89% (8 of 9); 6.6 uses a game | 0.0 uses a game | 0% (0 of 4); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (fw-h2h2-mine-1eea44e-p3b, 12 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 62% (15) | 47% (17) | 53% (32) |
| ...free all their last turn and able to turn (per game) | 0.92 | 1.00 | 1.92 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.08 | 0.17 | 0.25 |
| ...with the charger already in that arc before they moved (per game) | 0.67 | 0.58 | 1.25 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 2.17 | 1.33 | 3.50 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.50 | 0.83 | 1.33 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 8.33 | 7.50 | 15.83 |

### Quality by phase: fw-h2h2-mine-1eea44e-p3b

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.4 | 2.8 |
| Strategy | Charge objectives carried out (made contact) | 56% (36 of 64) | 52% (24 of 46) |
| Strategy | Shoot objectives carried out (shot that target) | 47% (26 of 55) | 49% (21 of 43) |
| Strategy | Close-in objectives charged next turn | 16% (12 of 73) | 15% (11 of 72) |
| Strategy | Support requests answered (helper made contact too) | 50% (2 of 4) | 0% (0 of 4) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (1 of 1) | - |
| Strategy | Hexes on a unit its side charged or shot that turn | 0% (0 of 2) | 0% (0 of 1) |
| Strategy | Joined characters whose unit fought | 86% (6 of 7) | 67% (6 of 9) |
| Strategy | Lone characters that fought | 83% (25 of 30) | 91% (32 of 35) |
| Movement | Charges halted short of contact | 0.1 | 0.3 |
| Movement | Idle units | 0.7 | 1.6 |
| Movement | Points that never moved of their own | 120.5 | 211.8 |
| Movement | Fights charged into per game | 3.8 | 3.4 |
| Movement | Charges with odds: long shots (under 50%) | 2 of 42, net +0 | 6 of 32, net +42 |
| Movement | Charges with odds: sweet spot (55-75%) | 11 of 42, net +26 | 3 of 32, net +29 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 8 of 42, net +138 | 3 of 32, net +190 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 12 of 42, net +154 | 16 of 32, net +128 |
| Shooting | Shots by shooting units (incl. breath weapons) | 8.8 | 11.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 34% (36 of 105) | 39% (53 of 136) |
| Shooting | Points destroyed by shooting units | 34.6 | 5.4 |
| Shooting | War machine shots | 0.9 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 9% (1 of 11) | - |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | 0.4 | 0.5 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 0% (0 of 5) | 0% (0 of 6) |
| Magic | Wounds caused by magic missiles | 1.1 | 1.8 |
| Magic | Wounds caused by other spells | 0.8 | - |
| Magic | Points destroyed by magic (all spells) | 43.4 | 27.6 |
| Magic | Augments / hexes / assailments / vortexes cast | 2.0 / 0.2 / 0.2 / 0.0 | 1.4 / 0.1 / 0.1 / 0.6 |
| Combat | Points destroyed in combat | 588.8 | 407.1 |
| Combat | Points run down | 57.3 | 28.7 |
| Combat | Net points per charged fight, damage counted | +108 | +89 |
| Combat | Net per 100 charger points, damage counted | +37.9 | +42.4 |
| Combat | First round won (charged fights) | 67% | 61% |
| Combat | Net points per charged fight | +121 | +82 |
| Combat | Net points per supported fight / lone fight | +261 / +96 | +14 / +89 |
| Combat | Charged fights on a top-3 enemy unit | 11 of 46 | 16 of 41 |
| Game | Points lost | 724.2 | 863.7 |
| Game | VP from objectives | 608.3 | 472.5 |
| Game | Lone holders (player turns) | 3.1 | 0.5 |

- Mine won / drew / lost: 8 / 1 / 3 of 12 ended games (of 12); mean margin (Mine - Opponent) +225 VP
- The side that went first won 4 of 11 games with a winner
- Points traded per game (both sides' losses): 1588
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: fw-h2h2-mine-1eea44e-p3b

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.8 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | 1.3 | +9.4 | 0.0 | 0.0 | 0.9 | +11.5 | 0.0 | 9.0 |
| BEST FACING | 0.9 | +37.9 | 0.0 | 0.0 | - | - | - | - |
| BEST FIRST | 4.7 | +179.7 | 121.5 | 93.2 | - | - | - | - |
| BEST OVERALL | 0.2 | +4.7 | 0.0 | 0.0 | 0.2 | +9.4 | 0.0 | 0.0 |
| BEST PREY | 1.1 | +53.1 | 20.8 | 8.9 | 6.2 | +507.8 | 214.3 | 209.6 |
| BIG CHARACTER SAFETY | - | - | - | - | 0.2 | -1.8 | 0.0 | 0.0 |
| BLOCKED CHARGE SKIPPED | 0.3 | +0.0 | 16.5 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| BLOCKED WHEEL | 0.6 | +15.0 | 0.0 | 0.0 | 0.2 | +1.9 | 0.0 | 5.8 |
| CANNON PLAN MISSED | 0.1 | +0.0 | 8.7 | 8.3 | - | - | - | - |
| CANNON PLANNED TARGET | 0.8 | +18.6 | 18.9 | 16.7 | - | - | - | - |
| CANNON SIGHT KEPT | 0.2 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CARRIES OUT SET-UP | 0.1 | +0.0 | 9.0 | 0.0 | - | - | - | - |
| CAST JOB | 0.2 | +5.4 | 0.0 | 0.0 | 0.4 | +13.2 | 2.8 | 16.2 |
| CASTER AWAY FROM SCREEN | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CASTING BLOCK | 0.1 | +3.8 | 0.0 | 0.0 | 0.1 | +6.5 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 0.3 | +0.0 | 0.0 | 32.9 | 0.2 | +0.0 | 0.0 | 15.8 |
| CASTS FROM BEHIND | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CHAFF PASSED | 0.1 | -0.0 | 0.0 | 0.0 | 0.2 | -0.2 | 0.0 | 0.0 |
| CHARGE NOW FIRST | 2.9 | +0.0 | 323.3 | 99.1 | - | - | - | - |
| CHARGE NOW WEIGHED | 0.6 | -51.6 | 32.7 | 56.0 | 1.1 | -100.8 | 5.5 | 42.0 |
| CHARIOT WIZARD CAREFUL | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHEAP HELPER | 0.1 | +0.0 | 16.5 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| COMBAT PIVOT | 0.4 | +0.0 | 14.4 | 0.0 | 0.7 | +0.0 | 0.0 | 48.3 |
| CONTINUE AHEAD WEIGHED | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CONVEYANCE SEARCH | 0.2 | +22.1 | 0.0 | 0.0 | 0.2 | +8.1 | 0.0 | 19.5 |
| COUNTER-CHARGE COVER | 9.6 | +787.5 | 0.0 | 183.8 | 8.4 | +598.2 | 0.0 | 177.9 |
| DEFENSIVE FLOOR | 0.2 | +9.5 | 9.7 | 0.0 | - | - | - | - |
| EDGE GIVE GROUND | 0.2 | +12.4 | 59.0 | 0.0 | - | - | - | - |
| ELIXIR WORTH | 0.1 | +0.4 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 2.2 | +212.9 | 0.0 | 29.8 | 1.3 | +74.4 | 0.0 | 75.8 |
| FALLBACK BY WORTH | 4.7 | +61.1 | 0.0 | 52.1 | 8.8 | +223.4 | 0.0 | 88.6 |
| FIGHT LIFT | 0.1 | +0.1 | 0.0 | 32.9 | - | - | - | - |
| FIRE AND FLEE | 0.1 | +1.2 | 0.0 | 6.7 | - | - | - | - |
| FLANK NOT WEIGHED | 7.4 | +0.0 | 0.0 | 140.1 | 6.8 | +0.0 | 0.0 | 172.9 |
| FOLLOW UP WEIGHED | 1.7 | +288.1 | 0.0 | 90.6 | 1.2 | +217.5 | 0.0 | 26.4 |
| FRIENDS SHOTS CHECKED | 0.5 | +7.9 | 0.0 | 0.0 | - | - | - | - |
| GIVES UP | 0.1 | -1.1 | 14.4 | 0.0 | 0.7 | -24.9 | 122.8 | 0.0 |
| GIVES UP ITS SCREEN | - | - | - | - | 0.9 | -15.6 | 26.2 | 19.3 |
| HELPER ALREADY ASKED | 0.1 | +0.0 | 16.5 | 0.0 | - | - | - | - |
| HELPER UNSEEN | 0.5 | +0.0 | 60.0 | 9.7 | 0.4 | +0.0 | 0.0 | 13.8 |
| HOLDS AMBUSHERS | 0.6 | +0.0 | 0.0 | 0.0 | 0.9 | +0.0 | 0.0 | 0.0 |
| HORN WORTH | - | - | - | - | 0.2 | +6.1 | 0.0 | 0.0 |
| HUNT ADVANCE | - | - | - | - | 0.2 | +1.5 | 0.0 | 0.0 |
| HUNT IN PAIRS | 0.5 | +19.7 | 0.0 | 0.0 | 0.5 | +18.5 | 0.0 | 0.0 |
| HUNT KEPT | - | - | - | - | 0.1 | +3.4 | 0.0 | 8.7 |
| HUNT RESULT | - | - | - | - | 0.2 | +0.0 | 0.0 | 8.7 |
| HUNT THE GUNS | - | - | - | - | 0.2 | +39.5 | 0.0 | 0.0 |
| INVITES THE FIGHT | 1.9 | +57.1 | 72.8 | 32.8 | - | - | - | - |
| JOINT CHARGE PLAN | 0.2 | +13.8 | 0.0 | 0.0 | 0.8 | +17.3 | 0.0 | 12.0 |
| KEEPS ITS PREY | 0.1 | +1.4 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| KEEPS ITS TARGET | 2.5 | +75.0 | 288.8 | 28.2 | 2.2 | +67.5 | 166.0 | 32.6 |
| KILLS COUNT | 2.5 | +85.7 | 158.3 | 40.8 | 1.9 | +69.2 | 116.8 | 37.6 |
| KILLS COUNT NEXT TURN | 7.4 | +290.1 | 219.6 | 98.2 | 13.2 | +501.8 | 326.4 | 208.4 |
| LONE CHARACTER SAFE SPOT | 0.2 | +21.1 | 0.0 | 0.0 | 0.8 | +9.6 | 0.0 | 0.0 |
| LONE WIZARD HOLDS BACK | 0.2 | +0.0 | 15.8 | 0.0 | 0.8 | +0.0 | 9.8 | 32.1 |
| LONE WIZARD KEPT IN | 0.4 | +15.8 | 0.0 | 0.0 | 0.1 | +1.9 | 0.0 | 0.0 |
| LONG SHOT | 0.3 | -3.4 | 9.7 | 0.0 | - | - | - | - |
| LOST CHARGE | 2.1 | -42.1 | 58.1 | 29.2 | - | - | - | - |
| LURE BY WHAT IT DRAWS | 0.1 | -3.3 | 0.0 | 0.0 | - | - | - | - |
| MAKE SURE TOGETHER | 1.2 | +131.6 | 0.0 | 0.0 | 0.7 | +25.7 | 0.0 | 9.0 |
| MANOEUVRE | 0.2 | +2.1 | 0.0 | 0.0 | 0.1 | +0.3 | 0.0 | 12.0 |
| MARCH AT ESCAPER | - | - | - | - | 0.1 | +2.0 | 0.0 | 0.0 |
| MARCH CHECK | 0.2 | +9.1 | 0.0 | 0.0 | 0.7 | +10.9 | 0.0 | 0.0 |
| MARCH ODDS | 0.2 | +11.2 | 16.5 | 0.0 | 0.3 | +11.8 | 0.0 | 16.2 |
| MARCH OVER CASTS | 0.4 | +29.3 | 0.0 | 65.7 | 0.2 | -3.0 | 0.0 | 9.7 |
| MAX FOR POSITIONING | 7.6 | +332.2 | 0.0 | 157.5 | 6.8 | +249.3 | 0.0 | 126.9 |
| MISSILES IN THE MOVE | 2.0 | +35.1 | 0.0 | 62.7 | 3.8 | +66.0 | 0.0 | 55.8 |
| MISSILES NEXT TURN | 3.1 | +28.7 | 0.0 | 158.1 | 3.9 | +53.5 | 0.0 | 65.4 |
| MONSTER WIZARD ROAMS | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE AND CAST | 0.1 | +3.6 | 0.0 | 0.0 | 0.5 | +29.5 | 0.0 | 16.2 |
| MOVE SPELL OUT OF RANGE | - | - | - | - | 0.1 | -0.8 | 0.0 | 22.8 |
| MOVE SPELL SPOT | 0.2 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE TO CHARGE | 4.2 | +330.7 | 226.9 | 50.8 | - | - | - | - |
| MOVES UNITS SPELL | 0.2 | +1.0 | 0.0 | 0.0 | - | - | - | - |
| NEEDED THERE | 0.1 | +6.3 | 14.4 | 0.0 | 0.1 | +10.2 | 0.0 | 0.0 |
| NOT NEEDED | 0.5 | -30.6 | 57.7 | 0.0 | 0.2 | -9.0 | 14.2 | 0.0 |
| NOT TURNED | 8.3 | +167.4 | 0.0 | 163.2 | 7.5 | +179.7 | 0.0 | 155.0 |
| NOT WORTH A CAST | 0.8 | -0.6 | 0.0 | 0.0 | 1.2 | -1.8 | 0.0 | 39.0 |
| OFF BEST | 15.7 | -732.9 | 16.5 | 243.8 | 17.8 | -1210.8 | 0.0 | 341.2 |
| OPENS A LANE | - | - | - | - | 0.2 | +0.3 | 23.1 | 0.0 |
| OPENS UP | 0.2 | +20.0 | 18.8 | 0.0 | 0.2 | +11.0 | 5.0 | 0.0 |
| OVERRUNS AWAY | 0.8 | +25.9 | 43.8 | 15.4 | 0.7 | +11.2 | 0.0 | 27.5 |
| PATHS CROSS | 2.8 | +165.9 | 0.0 | 10.8 | 3.3 | +349.0 | 0.0 | 38.8 |
| PERIAPT WORTH | 0.1 | +8.3 | 0.0 | 0.0 | - | - | - | - |
| PIVOT GUARDS FLANK | 0.2 | -0.9 | 0.0 | 15.4 | 0.1 | -0.1 | 0.0 | 11.4 |
| PLAN RESULT | 37.0 | +944.1 | 1452.5 | 781.6 | 38.6 | +1010.7 | 977.4 | 1042.8 |
| PURSUES BIG PREY | - | - | - | - | 0.1 | -37.1 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE NEXT TURN | 0.2 | +14.6 | 0.0 | 4.6 | 0.1 | +9.9 | 0.0 | 0.0 |
| RANDOM MOVE BY FIGURES | 1.3 | +27.6 | 0.0 | 45.8 | - | - | - | - |
| RANDOM MOVER NO PROMISE | 0.6 | -56.8 | 0.0 | 28.3 | - | - | - | - |
| REDIRECT BY WHAT IT STOPS | 0.2 | -0.3 | 0.0 | 0.0 | - | - | - | - |
| REDIRECT COUNTER | 3.3 | +183.8 | 0.0 | 28.8 | 6.7 | +466.5 | 0.0 | 127.9 |
| REDIRECT WEIGHED | 0.3 | +1.3 | 1.6 | 0.0 | 0.2 | +14.9 | 4.6 | 11.2 |
| RESERVE FALL BACK | 1.2 | +39.2 | 0.0 | 38.9 | - | - | - | - |
| RESTRAINS TO SHOOT | 0.1 | +0.6 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | 3.8 | +76.6 | 346.9 | 78.8 | 2.2 | +40.6 | 160.1 | 46.8 |
| SAFER THAN THE JOB | 0.5 | +43.8 | 0.0 | 29.8 | 0.8 | +59.5 | 0.0 | 12.0 |
| SCOUT SPOT | 0.5 | +0.4 | 0.0 | 2.8 | 0.2 | +0.0 | 0.0 | 0.0 |
| SCOUT WAITS | 0.6 | +0.0 | 0.0 | 2.8 | 0.2 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.2 | +4.0 | 0.0 | 0.0 | - | - | - | - |
| SEARCH SPOT | 2.8 | +147.0 | 0.0 | 79.6 | 2.5 | +131.5 | 0.0 | 22.1 |
| SELF MOVE SPELL | 0.8 | +111.2 | 0.0 | 120.2 | - | - | - | - |
| SET UP TOGETHER | 1.8 | +190.0 | 22.8 | 19.3 | 1.6 | +173.5 | 42.6 | 21.0 |
| SET-UP ANY TARGET | - | - | - | - | 0.1 | +7.8 | 0.0 | 19.5 |
| SHOOTERS IN TWO RANKS | 0.3 | +0.8 | 0.0 | 0.0 | 0.1 | +0.1 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.0 | +29.0 | 60.3 | 6.9 | - | - | - | - |
| SHOT REPLANNED | 0.2 | +0.0 | 19.2 | 8.3 | 0.1 | +0.0 | 9.7 | 0.0 |
| SHOTS IN THE MOVE | 9.0 | +223.6 | 0.0 | 115.1 | 7.8 | +307.7 | 0.0 | 97.0 |
| SPELL SETS UP CHARGE | 0.2 | +62.1 | 0.0 | 0.0 | 0.1 | +7.8 | 0.0 | 19.5 |
| SPELL WORTH | 2.1 | +39.2 | 2.5 | 62.2 | 2.0 | +20.6 | 32.8 | 71.8 |
| STABLE ROLE | 10.2 | +0.0 | 409.5 | 173.9 | - | - | - | - |
| STOPS | - | - | - | - | 0.1 | +3.4 | 0.0 | 8.7 |
| STOPS SHORT OF THE FLANK | 0.3 | +33.9 | 0.0 | 0.0 | 0.2 | +4.9 | 0.0 | 0.0 |
| STUCK PIVOT | 0.2 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 14.2 |
| SUPPORT NARROWED | 8.6 | -92.6 | 508.0 | 201.3 | - | - | - | - |
| SUPPORTS | 5.0 | +92.6 | 155.7 | 134.4 | - | - | - | - |
| SURE CHARGE BEATS ADVANCE | - | - | - | - | 0.3 | -21.1 | 44.2 | 0.0 |
| SURE REACH TOGETHER | 0.8 | +21.2 | 0.0 | 23.1 | 0.2 | -2.2 | 29.8 | 0.0 |
| THROUGH LINE OF FIRE | 0.3 | +14.2 | 0.0 | 0.0 | 0.1 | +31.4 | 0.0 | 22.8 |
| TURN WORTH | 0.4 | -23.5 | 74.4 | 19.1 | 0.4 | -21.7 | 24.5 | 22.7 |
| TWO OR MORE ARRIVE | 0.7 | +10.5 | 22.8 | 9.7 | 0.9 | +17.0 | 0.0 | 0.0 |
| WAIT AFTER COSTS | 8.0 | -445.3 | 348.9 | 83.6 | - | - | - | - |
| WALKS TO THE FIGHT | 1.7 | +70.9 | 36.7 | 0.0 | - | - | - | - |
| WAR ENGINE JOBS | 0.2 | +0.0 | 19.5 | 0.0 | - | - | - | - |
| WEARS DOWN | 1.9 | +70.9 | 254.1 | 42.6 | 1.1 | +43.8 | 131.5 | 30.3 |
| WHO HITS BACK | 0.2 | +6.7 | 0.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT | 0.6 | +20.8 | 86.7 | 0.0 | 0.6 | +60.2 | 134.9 | 1.6 |
| WHOLE FIGHT GAIN | 0.3 | +27.7 | 49.0 | 4.6 | 0.2 | +4.6 | 0.0 | 0.0 |

### Rule changes: fw-h2h2-mine-1eea44e-p3b

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 401 | 401 | 401 | 33.42 | -23324 | -58.2 |
| PATHS CROSS | 74 | 74 | 74 | 6.17 | +6178 | +83.5 |
| SEARCH SPOT | 63 | 63 | 63 | 5.25 | +3341 | +53.0 |
| KILLS COUNT NEXT TURN | 247 | 246 | 60 | 5.00 | +2094 | +34.9 |
| BEST FIRST | 56 | 56 | 56 | 4.67 | +2157 | +38.5 |
| COUNTER-CHARGE COVER | 216 | 104 | 47 | 3.92 | +2242 | +47.7 |
| FACES THE THREAT | 42 | 42 | 42 | 3.50 | +3448 | +82.1 |
| FALLBACK BY WORTH | 161 | 161 | 42 | 3.50 | +3414 | +81.3 |
| FOLLOW UP WEIGHED | 35 | 35 | 35 | 2.92 | +6068 | +173.4 |
| BEST PREY | 88 | 86 | 34 | 2.83 | +1597 | +47.0 |
| MAX FOR POSITIONING | 172 | 79 | 27 | 2.25 | +392 | +14.5 |
| MOVE TO CHARGE | 50 | 50 | 25 | 2.08 | +1284 | +51.4 |
| SUPPORTS | 60 | 60 | 25 | 2.08 | +370 | +14.8 |
| SHOTS IN THE MOVE | 201 | 117 | 23 | 1.92 | +535 | +23.3 |
| CHARGE NOW WEIGHED | 20 | 20 | 20 | 1.67 | +1039 | +51.9 |
| SET UP TOGETHER | 40 | 35 | 19 | 1.58 | +1606 | +84.5 |
| HOLDS AMBUSHERS | 18 | 18 | 18 | 1.50 | +0 | +0.0 |
| RISK BY ARC | 71 | 68 | 18 | 1.50 | +324 | +18.0 |
| SAFER THAN THE JOB | 16 | 16 | 16 | 1.33 | +1239 | +77.4 |
| RESERVE FALL BACK | 15 | 15 | 15 | 1.25 | +470 | +31.3 |
| KILLS COUNT | 53 | 50 | 14 | 1.17 | +303 | +21.7 |
| ADVANCE LANE KEPT | 13 | 13 | 13 | 1.08 | +0 | +0.0 |
| COMBAT PIVOT | 13 | 13 | 13 | 1.08 | +0 | +0.0 |
| KEEPS ITS TARGET | 57 | 57 | 13 | 1.08 | +241 | +18.5 |
| WALKS TO THE FIGHT | 20 | 20 | 13 | 1.08 | +428 | +32.9 |
| BEST FACING | 11 | 11 | 11 | 0.92 | +455 | +41.4 |
| REDIRECT COUNTER | 120 | 55 | 11 | 0.92 | +1249 | +113.6 |
| BLOCKED WHEEL | 10 | 10 | 10 | 0.83 | +203 | +20.3 |
| CHARGE NOW FIRST | 35 | 35 | 10 | 0.83 | -575 | -57.5 |
| MARCH CHECK | 11 | 10 | 10 | 0.83 | +318 | +31.8 |
| SCOUT WAITS | 9 | 9 | 9 | 0.75 | +0 | +0.0 |
| MISSILES IN THE MOVE | 70 | 42 | 8 | 0.67 | +57 | +7.1 |
| MOVE AND CAST | 7 | 7 | 7 | 0.58 | +397 | +56.7 |
| STUCK PIVOT | 7 | 7 | 7 | 0.58 | +0 | +0.0 |
| BLOCKED CHARGE SKIPPED | 6 | 6 | 6 | 0.50 | +0 | +0.0 |
| CAST JOB | 8 | 8 | 6 | 0.50 | +120 | +20.1 |
| FRIENDS SHOTS CHECKED | 6 | 6 | 6 | 0.50 | +95 | +15.8 |
| INVITES THE FIGHT | 23 | 23 | 6 | 0.50 | +109 | +18.2 |
| LONE WIZARD KEPT IN | 6 | 6 | 6 | 0.50 | +212 | +35.4 |
| REDIRECT WEIGHED | 6 | 6 | 6 | 0.50 | +569 | +94.8 |
| SHOOTS FROM THE BEST SPOT | 12 | 12 | 6 | 0.50 | +199 | +33.2 |
| STOPS SHORT OF THE FLANK | 6 | 6 | 6 | 0.50 | +465 | +77.6 |
| WAIT AFTER COSTS | 96 | 96 | 6 | 0.50 | +71 | +11.8 |
| WEARS DOWN | 36 | 35 | 6 | 0.50 | +236 | +39.3 |
| BEST OVERALL | 5 | 5 | 5 | 0.42 | +169 | +33.9 |
| MAKE SURE TOGETHER | 23 | 17 | 5 | 0.42 | +370 | +74.1 |
| MARCH ODDS | 7 | 7 | 5 | 0.42 | +87 | +17.4 |
| RANDOM MOVE BY FIGURES | 16 | 16 | 5 | 0.42 | +331 | +66.3 |
| SHOOTERS IN TWO RANKS | 5 | 5 | 5 | 0.42 | +11 | +2.2 |
| THROUGH LINE OF FIRE | 5 | 5 | 5 | 0.42 | +547 | +109.5 |
| WHOLE FIGHT GAIN | 7 | 7 | 5 | 0.42 | +206 | +41.1 |
| BACKUP TARGETS | 27 | 10 | 4 | 0.33 | +30 | +7.5 |
| OPENS UP | 5 | 5 | 4 | 0.33 | +255 | +63.7 |
| SURE CHARGE BEATS ADVANCE | 4 | 4 | 4 | 0.33 | -254 | -63.4 |
| WHOLE FIGHT | 14 | 14 | 4 | 0.33 | +62 | +15.6 |
| CASTS FROM BEHIND | 3 | 3 | 3 | 0.25 | +0 | +0.0 |
| CHAFF PASSED | 3 | 3 | 3 | 0.25 | -3 | -0.9 |
| HORN WORTH | 3 | 3 | 3 | 0.25 | +73 | +24.2 |
| MANOEUVRE | 3 | 3 | 3 | 0.25 | +30 | +10.0 |
| OVERRUNS AWAY | 18 | 17 | 3 | 0.25 | +50 | +16.6 |
| PIVOT GUARDS FLANK | 3 | 3 | 3 | 0.25 | -12 | -4.0 |
| RAIDS THE BAGGAGE NEXT TURN | 3 | 3 | 3 | 0.25 | +12 | +4.1 |
| SHOT REPLANNED | 3 | 3 | 3 | 0.25 | +0 | +0.0 |
| BIG CHARACTER SAFETY | 2 | 2 | 2 | 0.17 | -22 | -10.8 |
| CANNON SIGHT KEPT | 2 | 2 | 2 | 0.17 | +0 | +0.0 |
| HUNT IN PAIRS | 12 | 5 | 2 | 0.17 | +4 | +2.1 |
| LONE WIZARD HOLDS BACK | 12 | 12 | 2 | 0.17 | -201 | -100.7 |
| MOVES UNITS SPELL | 2 | 2 | 2 | 0.17 | +12 | +5.8 |
| NEEDED THERE | 2 | 2 | 2 | 0.17 | +0 | +0.0 |
| SUPPORT NARROWED | 103 | 103 | 2 | 0.17 | -5 | -2.3 |
| WHO HITS BACK | 2 | 2 | 2 | 0.17 | +80 | +40.2 |
| CANNON PLANNED TARGET | 10 | 10 | 1 | 0.08 | +23 | +23.1 |
| CASTER AWAY FROM SCREEN | 1 | 1 | 1 | 0.08 | +0 | +0.0 |
| CONTINUE AHEAD WEIGHED | 1 | 1 | 1 | 0.08 | +0 | +0.0 |
| EDGE GIVE GROUND | 3 | 3 | 1 | 0.08 | +43 | +43.0 |
| ELIXIR WORTH | 1 | 1 | 1 | 0.08 | +5 | +4.6 |
| FIRE AND FLEE | 1 | 1 | 1 | 0.08 | +15 | +15.1 |
| LOST CHARGE | 25 | 25 | 1 | 0.08 | +0 | +0.0 |
| MISSILES NEXT TURN | 84 | 48 | 1 | 0.08 | +8 | +7.6 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.08 | +99 | +99.4 |
| PURSUES BIG PREY | 1 | 1 | 1 | 0.08 | -445 | -445.0 |
| RESTRAINS TO SHOOT | 1 | 1 | 1 | 0.08 | +7 | +6.8 |
| SCREEN BY WHAT IT SAVES | 2 | 2 | 1 | 0.08 | +20 | +20.3 |
| TWO OR MORE ARRIVE | 19 | 19 | 1 | 0.08 | +7 | +7.3 |
| WAR ENGINE JOBS | 2 | 2 | 1 | 0.08 | -8 | -8.4 |
| CANNON PLAN MISSED | 1 | 1 | 0 | 0.00 | - | - |
| CARRIES OUT SET-UP | 1 | 1 | 0 | 0.00 | - | - |
| CASTING BLOCK | 2 | 2 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 6 | trace | - | - | - | - |
| CHARIOT WIZARD CAREFUL | 1 | 1 | 0 | 0.00 | - | - |
| CHEAP HELPER | 4 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 4 | not checked | - | - | - | - |
| DEFENSIVE FLOOR | 2 | 2 | 0 | 0.00 | - | - |
| FIGHT LIFT | 1 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 170 | not checked | - | - | - | - |
| GIVES UP | 9 | 8 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 11 | 11 | 0 | 0.00 | - | - |
| HELPER ALREADY ASKED | 1 | not checked | - | - | - | - |
| HELPER UNSEEN | 11 | 11 | 0 | 0.00 | - | - |
| HUNT ADVANCE | 2 | 2 | 0 | 0.00 | - | - |
| HUNT KEPT | 1 | trace | - | - | - | - |
| HUNT RESULT | 2 | trace | - | - | - | - |
| HUNT THE GUNS | 2 | trace | - | - | - | - |
| JOINT CHARGE PLAN | 11 | 11 | 0 | 0.00 | - | - |
| KEEPS ITS PREY | 2 | 2 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 12 | not checked | - | - | - | - |
| LONG SHOT | 4 | 4 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 1 | 1 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 8 | 8 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 1 | 1 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 1 | trace | - | - | - | - |
| MOVE SPELL SPOT | 2 | not checked | - | - | - | - |
| NOT NEEDED | 9 | 9 | 0 | 0.00 | - | - |
| NOT TURNED | 190 | 190 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 24 | not checked | - | - | - | - |
| OPENS A LANE | 2 | not checked | - | - | - | - |
| PLAN RESULT | 907 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 7 | 7 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 2 | 2 | 0 | 0.00 | - | - |
| SCOUT SPOT | 8 | 8 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 9 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 1 | not checked | - | - | - | - |
| SPELL SETS UP CHARGE | 3 | not checked | - | - | - | - |
| SPELL WORTH | 49 | not checked | - | - | - | - |
| STABLE ROLE | 122 | 122 | 0 | 0.00 | - | - |
| STOPS | 1 | 1 | 0 | 0.00 | - | - |
| SURE REACH TOGETHER | 11 | 8 | 0 | 0.00 | - | - |
| TURN WORTH | 10 | 9 | 0 | 0.00 | - | - |

### Off best figure: fw-h2h2-mine-1eea44e-p3b

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 13.92 | 14.92 | 60.3 |
| FALLBACK | gate | 0.58 | 1.33 | 52.7 |
| TURN GATE | gate | 0.75 | 0.42 | 49.8 |
| CHARGE NOW FIRST | rule | 0.83 | - | 57.5 |
| CHARGE NOW WEIGHED | rule | 0.42 | 0.08 | 42.9 |
| RULE SWITCHED OFF | gate | - | 0.42 | 3.4 |
| PATHS CROSS | rule | 0.17 | 0.17 | 25.4 |
| SURE CHARGE BEATS ADVANCE | rule | - | 0.33 | 63.4 |
| FIGHT ORDER BAND | gate | 0.08 | 0.17 | 3.4 |
| LONE CHARACTER SAFE SPOT | gate | - | 0.25 | 67.4 |
| PIVOT GUARDS FLANK | rule | 0.17 | 0.08 | 4.0 |
| SUPPORT REQUEST | gate | 0.08 | 0.17 | 43.9 |
| AFTERMATH BAND | gate | 0.17 | - | 3.2 |
| LONE WIZARD HOLDS BACK | rule | - | 0.17 | 100.7 |
| SUPPORT NARROWED | rule | 0.17 | - | 2.3 |
| AFTERMATH NEEDS NEXT CHARGE | gate | - | 0.08 | 87.8 |
| BIG CHARACTER SAFETY | rule | - | 0.08 | 21.3 |
| CHAFF PASSED | rule | - | 0.08 | 1.9 |
| MARCH ODDS | rule | 0.08 | - | 1.5 |
| NO REASON | gate | 0.08 | - | 78.5 |
| PURSUES BIG PREY | rule | - | 0.08 | 445.0 |
| SAFER THAN THE JOB | rule | - | 0.08 | 21.3 |
| WAR ENGINE JOBS | rule | 0.08 | - | 8.4 |

### Plans: fw-h2h2-mine-1eea44e-p3b

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 13.2 | 19% | 473 | 238 | 50% |
| Mine | charge | 4.6 | 69% | 455 | 379 | 83% |
| Mine | close in | 6.1 | 33% | 411 | 178 | 43% |
| Mine | hold | 3.4 | 49% | 183 | 0 | 0% |
| Mine | join | 0.2 | 100% | 6 | 0 | 0% |
| Mine | shoot | 4.2 | 37% | 58 | 149 | 258% |
| Mine | support | 5.3 | 89% | 65 | 0 | 0% |
| Opponent | advance | 14.1 | 16% | 732 | 425 | 58% |
| Opponent | charge | 3.2 | 45% | 277 | 233 | 84% |
| Opponent | close in | 5.9 | 21% | 494 | 211 | 43% |
| Opponent | hold | 3.2 | 26% | 193 | 0 | 0% |
| Opponent | join | 1.4 | 88% | 80 | 0 | 0% |
| Opponent | shoot | 3.2 | 61% | 80 | 142 | 178% |
| Opponent | support | 7.7 | 90% | 299 | 0 | 0% |

### Packages: hunt the guns, fw-h2h2-mine-1eea44e-p3b

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Opponent | 0.2 | 2 | 0 | 0% | 0% | 0% | - | 237 | 0 | 0% | 0 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Tomb Kings of Khemri | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Vampire Counts | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Warriors of Chaos | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Wood Elf Realms | 0.4 | 2 | 0 | 0% | 0% | 0% | - | 237 | 0 | 0% | 0 |

### Battle groups: fw-h2h2-mine-1eea44e-p3b

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 9.6 | 16% | 33% | 17% | 33% | 40% | 13% | 7% | 40% | 0% |
| Mine | REDIRECT COUNTER | 3.3 | 28% | 55% | 9% | 0% | 30% | 0% | 10% | 60% | 0% |
| Opponent | COUNTER-CHARGE COVER | 8.4 | 16% | 50% | 6% | 0% | 40% | 0% | 20% | 40% | 0% |
| Opponent | REDIRECT COUNTER | 6.7 | 31% | 64% | 12% | 0% | 14% | 0% | 23% | 64% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: fw-h2h2-mine-1eea44e-p3b

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 0% | 4.0 | - | 0 (1) | - | - | 0 (1) |
| Mine | Chaff | 24 | 64 (24) | 36 | 28 | 43 | 25% | 2.7 | 75 (13) | 29 (5) | 70 (6) | 82 (19) | 0 (5) |
| Mine | Character | 28 | 70 (28) | 70 | 0 | 34 | 11% | 2.5 | 58 (13) | 97 (12) | - | 81 (14) | 64 (11) |
| Mine | Clean-up | 7 | 28 (7) | 15 | 13 | 19 | 14% | 2.2 | 0 (2) | 39 (5) | - | 29 (3) | 27 (4) |
| Mine | Fast | 1 | 0 (1) | 0 | 0 | 0 | 0% | 2.0 | - | 0 (1) | - | 0 (1) | - |
| Mine | Fast Hammer | 11 | 26 (11) | 26 | 0 | 25 | 18% | 2.3 | 44 (7) | 5 (2) | 4 (2) | 18 (7) | 49 (4) |
| Mine | Fragile | 3 | 0 (3) | 0 | 0 | 67 | 0% | 3.3 | 0 (3) | - | - | 0 (1) | 0 (2) |
| Mine | Hammer | 16 | 39 (16) | 25 | 14 | 31 | 12% | 3.1 | 5 (4) | 48 (11) | 0 (1) | 32 (12) | 62 (4) |
| Mine | Holder | 8 | 51 (8) | 23 | 28 | 18 | 25% | 2.7 | 0 (1) | 75 (4) | 0 (3) | 88 (4) | 18 (4) |
| Mine | Shooter | 9 | 50 (9) | 11 | 39 | 67 | 0% | 1.8 | 30 (2) | 63 (6) | 0 (1) | 46 (3) | 53 (6) |
| Mine | Support | 4 | 87 (4) | 87 | 0 | 42 | 0% | 4.8 | 97 (1) | 79 (3) | - | 97 (1) | 79 (3) |
| Mine | War machine | 2 | 0 (2) | 0 | 0 | 50 | 0% | 1.0 | - | 0 (2) | - | - | 0 (2) |
| Mine | Wizard | 9 | 7 (9) | 7 | 0 | 65 | 0% | 1.8 | 0 (2) | 0 (1) | 53 (1) | 53 (1) | 0 (3) |
| Opponent | Chaff | 22 | 24 (22) | 8 | 16 | 52 | 45% | 2.9 | 0 (8) | 21 (4) | 36 (10) | 18 (16) | 39 (6) |
| Opponent | Character | 35 | 49 (35) | 49 | 0 | 35 | 9% | 2.5 | 39 (11) | 78 (13) | 38 (2) | 52 (16) | 69 (10) |
| Opponent | Fast Hammer | 25 | 41 (25) | 22 | 19 | 68 | 8% | 2.7 | 42 (15) | 9 (4) | 70 (6) | 52 (13) | 31 (12) |
| Opponent | Hammer | 25 | 35 (25) | 35 | 0 | 43 | 28% | 3.7 | 2 (11) | 64 (11) | 0 (3) | 30 (13) | 40 (12) |
| Opponent | Holder | 11 | 43 (11) | 3 | 40 | 27 | 45% | 3.2 | 50 (4) | 45 (4) | 48 (2) | 43 (7) | 58 (3) |
| Opponent | Shooter | 15 | 45 (15) | 17 | 28 | 53 | 7% | 1.1 | 105 (1) | 40 (14) | - | 82 (6) | 23 (9) |
| Opponent | Support | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | - | 0 (1) | - | 0 (1) |
| Opponent | Wizard | 9 | 22 (9) | 22 | 0 | 63 | 11% | 2.6 | 0 (2) | 39 (5) | 0 (1) | 11 (5) | 52 (3) |

### Charged fights: fw-h2h2-mine-1eea44e-p3b

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | High Elf Realms | 1 | 0 | 542 | 4.0 | 1.5 | 136 | 0 | +136 | 1 of 4 | 4 of 4 | +432 | +37 |
| Mine | Kingdom of Bretonnia | 1 | 104 | 470 | 2.0 | 1.0 | 235 | 0 | +235 | 1 of 2 | 2 of 2 | - | +235 |
| Mine | Lizardmen | 1 | 0 | 922 | 5.0 | 1.0 | 184 | 0 | +184 | 2 of 5 | 2 of 5 | - | +184 |
| Mine | Ogre Kingdoms | 1 | 427 | 260 | 4.0 | 1.0 | 65 | 0 | +65 | 0 of 4 | 4 of 4 | - | +65 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 200 | 4.0 | 1.2 | 50 | 0 | +50 | 2 of 4 | 3 of 4 | +0 | +67 |
| Mine | Skaven | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Mine | Tomb Kings of Khemri | 2 | 0 | 706 | 4.5 | 1.2 | 157 | 10 | +147 | 2 of 9 | 4 of 9 | +392 | +77 |
| Mine | Vampire Counts | 2 | 202 | 562 | 6.5 | 1.2 | 87 | 18 | +69 | 2 of 13 | 6 of 12 | +86 | +66 |
| Mine | Warriors of Chaos | 2 | 0 | 560 | 2.5 | 1.2 | 224 | 34 | +190 | 1 of 5 | 5 of 5 | +438 | +128 |
| **Mine** | all armies | 12 | 78 | 504 | 3.8 | 1.2 | 132 | 11 | +121 | 11 of 46 | 30 of 45 | +261 | +96 |
| Opponent | Tomb Kings of Khemri | 1 | 0 | 511 | 5.0 | 1.0 | 102 | 0 | +102 | 3 of 5 | 4 of 5 | - | +102 |
| Opponent | Vampire Counts | 1 | 0 | 385 | 5.0 | 1.2 | 77 | 0 | +77 | 1 of 5 | 2 of 5 | +60 | +81 |
| Opponent | Warriors of Chaos | 5 | 7 | 570 | 3.4 | 1.2 | 168 | 59 | +109 | 7 of 17 | 10 of 17 | -2 | +133 |
| Opponent | Wood Elf Realms | 5 | 72 | 144 | 2.8 | 1.0 | 51 | 7 | +44 | 5 of 14 | 9 of 14 | - | +44 |
| **Opponent** | all armies | 12 | 33 | 372 | 3.4 | 1.1 | 109 | 27 | +82 | 16 of 41 | 25 of 41 | +14 | +89 |

### Effective charges: fw-h2h2-mine-1eea44e-p3b

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | High Elf Realms | 4 | 0 | 0 | 0 | 0 | 3 (net +181) | 1 (net +0) | 0 | 0% (0 of 4) |
| Mine | Kingdom of Bretonnia | 2 | 0 | 0 | 0 | 0 | 0 | 2 (net +235) | 0 | 0% (0 of 2) |
| Mine | Lizardmen | 5 | 0 | 0 | 1 (net +116) | 2 (net +331) | 0 | 1 (net +0) | 1 | 25% (1 of 4) |
| Mine | Ogre Kingdoms | 4 | 0 | 0 | 2 (net +58) | 2 (net +72) | 0 | 0 | 0 | 50% (2 of 4) |
| Mine | Orc & Goblin Tribes | 4 | 0 | 0 | 0 | 0 | 0 | 2 (net +15) | 2 | 0% (0 of 2) |
| Mine | Tomb Kings of Khemri | 9 | 1 (net +0) | 0 | 4 (net +54) | 1 (net +663) | 2 (net +185) | 1 (net +75) | 0 | 44% (4 of 9) |
| Mine | Vampire Counts | 13 | 1 (net +0) | 0 | 3 (net -53) | 2 (net +0) | 3 (net +64) | 3 (net +288) | 1 | 25% (3 of 12) |
| Mine | Warriors of Chaos | 5 | 0 | 0 | 1 (net +0) | 2 (net +274) | 0 | 2 (net +202) | 0 | 20% (1 of 5) |
| Opponent | Tomb Kings of Khemri | 5 | 0 | 0 | 2 (net +0) | 0 | 2 (net +256) | 1 (net +0) | 0 | 40% (2 of 5) |
| Opponent | Vampire Counts | 5 | 2 (net +0) | 0 | 0 | 1 (net +0) | 1 (net +60) | 1 (net +325) | 0 | 0% (0 of 5) |
| Opponent | Warriors of Chaos | 17 | 1 (net +357) | 1 (net +90) | 1 (net +88) | 2 (net +134) | 0 | 11 (net +121) | 1 | 6% (1 of 16) |
| Opponent | Wood Elf Realms | 14 | 3 (net -35) | 0 | 0 | 0 | 0 | 3 (net +132) | 8 | 0% (0 of 6) |

### Charged fights, damage counted: fw-h2h2-mine-1eea44e-p3b

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 2 | 456 | 314 | +0 | 0 | 0 | +0 | +0.0 |
| Mine | Effective (55-75%) | 11 | 196 | 127 | +26 | 80 | 47 | +33 | +16.9 |
| Mine | 76-89% | 9 | 262 | 180 | +224 | 244 | 63 | +182 | +69.3 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 12 | 234 | 151 | +154 | 171 | 26 | +145 | +61.9 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 8 | 442 | 102 | +138 | 146 | 20 | +126 | +28.5 |
| Mine | No odds | 4 | 326 | 230 | +78 | 78 | 25 | +54 | +16.4 |
| Mine | All fights | 46 | 284 | 156 | +121 | 144 | 36 | +108 | +37.9 |
| Opponent | Long shot (under 50%) | 6 | 173 | 278 | +42 | 63 | 43 | +20 | +11.8 |
| Opponent | 50-54% | 1 | 499 | 494 | +90 | 474 | 137 | +337 | +67.5 |
| Opponent | Effective (55-75%) | 3 | 330 | 254 | +29 | 167 | 137 | +29 | +8.9 |
| Opponent | 76-89% | 3 | 166 | 151 | +89 | 89 | 22 | +68 | +40.8 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 16 | 247 | 179 | +128 | 151 | 26 | +125 | +50.4 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 3 | 428 | 64 | +190 | 190 | 10 | +180 | +42.2 |
| Opponent | No odds | 9 | 38 | 177 | +5 | 92 | 52 | +40 | +104.8 |
| Opponent | All fights | 41 | 210 | 196 | +82 | 132 | 43 | +89 | +42.4 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| fw-h2h2-mine-1eea44e-p3b | move | 202 | 43 (21%) | 38 (19%) | 22 (11%) | 137 (68%) |
| fw-h2h2-mine-1eea44e-p3b | objective | 145 | 23 (16%) | 18 (12%) | 21 (14%) | 101 (70%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L2433, L2630 |
| Charmed Shield | Opponent | L2327 |
| Elixir of Power | Mine | L1932 |
| Fistful of Laurels | Mine | L1831 |
| Horn of the Wild Hunt | Opponent | L1633, L2033, L2433, L3133 |
| Invocation of Nehek | Mine | L2433 |
| Invocation of Nehek | Opponent | L2327 |
| Periapt of Soul Exchange | Mine | L2033 |
| Ring of Doom | Mine | L1535, L3133 |
| Ring of Doom | Opponent | L1633, L1731, L1831, L2033, L2433, L3133 |

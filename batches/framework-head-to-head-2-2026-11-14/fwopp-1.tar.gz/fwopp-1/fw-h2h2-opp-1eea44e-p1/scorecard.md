# Doctrine scorecard: fw-h2h2-opp-1eea44e-p1

### Scorecard: fw-h2h2-opp-1eea44e-p1

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0102 | 6 | 1 | Mine | no | 7 | - | 0 | 1 | 0 | 0 | 0 | 322 |
| L0102 | 6 | 1 | Opponent | no | 4 | 1 | 2 | 1 | 1 | 0 | 0 | 222 |
| L0118 | 4 | 1 | Mine | no | 3 | - | 0 | 2 | 0 | 0 | 0 | 317 |
| L0118 | 4 | 1 | Opponent | no | 0 | 1 | 5 | 5 | 0 | 0 | 0 | 331 |
| L0135 | 3 | 1 | Mine | no | 1 | - | 0 | 2 | 0 | 0 | 0 | 639 |
| L0135 | 3 | 1 | Opponent | no | 0 | 2 | 2 | 3 | 0 | 0 | 0 | 0 |
| L0218 | 2 | 1 | Mine | - | - | 1 | 1 | 2 | 0 | 0 | 0 | 0 |
| L0218 | 2 | 1 | Opponent | - | - | 2 | 1 | 2 | 0 | 0 | 0 | 0 |
| L0235 | 1 | 1 | Mine | no | 3 | 2 | 3 | 3 | 0 | 0 | 0 | 0 |
| L0235 | 1 | 1 | Opponent | no | 3 | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L0319 | 1 | 1 | Mine | no | 3 | 2 | 1 | 1 | 1 | 0 | 0 | 760 |
| L0319 | 1 | 1 | Opponent | no | 2 | 2 | 3 | 1 | 1 | 0 | 0 | 0 |
| L0405 | 3 | 1 | Mine | yes | 11 | 2 | 3 | 2 | 0 | 0 | 0 | 0 |
| L0405 | 3 | 1 | Opponent | yes | 2 | 2 | 0 | 0 | 0 | 0 | 0 | 1343 |
| L0421 | 1 | 1 | Mine | no | 3 | 2 | 5 | 0 | 0 | 0 | 0 | 0 |
| L0421 | 1 | 1 | Opponent | no | 3 | - | 3 | 4 | 0 | 0 | 0 | 210 |
| L0508 | 4 | 1 | Mine | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 633 |
| L0508 | 4 | 1 | Opponent | no | 0 | 4 | 1 | 5 | 0 | 0 | 0 | 807 |
| L0524 | 2 | 1 | Mine | - | - | 5 | 1 | 2 | 0 | 0 | 0 | 698 |
| L0524 | 2 | 1 | Opponent | - | - | 3 | 3 | 3 | 0 | 0 | 0 | 0 |
| L0612 | 6 | 1 | Mine | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 743 |
| L0612 | 6 | 1 | Opponent | no | 4 | 2 | 5 | 0 | 0 | 0 | 0 | 330 |
| L0628 | 4 | 1 | Mine | no | 0 | 2 | 3 | 1 | 0 | 0 | 0 | 1261 |
| L0628 | 4 | 1 | Opponent | yes | 3 | 2 | 3 | 0 | 0 | 0 | 0 | 0 |
| L0717 | 3 | 1 | Mine | no | 2 | 2 | 2 | 0 | 1 | 0 | 0 | 420 |
| L0717 | 3 | 1 | Opponent | yes | 7 | 2 | 4 | 0 | 1 | 0 | 0 | 175 |
| L0733 | 1 | 1 | Mine | no | 3 | 3 | 2 | 1 | 0 | 0 | 0 | 375 |
| L0733 | 1 | 1 | Opponent | no | 1 | 2 | 2 | 4 | 0 | 0 | 0 | 352 |
| L0823 | 1 | 1 | Mine | no | 1 | - | 0 | 1 | 0 | 0 | 0 | 515 |
| L0823 | 1 | 1 | Opponent | no | 3 | 2 | 5 | 3 | 1 | 0 | 0 | 0 |
| L0913 | 1 | 1 | Mine | no | 0 | 2 | 3 | 0 | 0 | 0 | 0 | 1029 |
| L0913 | 1 | 1 | Opponent | no | 3 | 2 | 5 | 0 | 1 | 0 | 0 | 140 |
| L0930 | 6 | 1 | Mine | no | 0 | 4 | 3 | 0 | 0 | 0 | 0 | 629 |
| L0930 | 6 | 1 | Opponent | no | 3 | 2 | 6 | 1 | 0 | 0 | 0 | 0 |
| L1021 | 1 | 1 | Mine | no | 2 | 2 | 2 | 0 | 0 | 0 | 0 | 330 |
| L1021 | 1 | 1 | Opponent | no | 2 | 2 | 2 | 3 | 0 | 0 | 0 | 355 |
| L1114 | 4 | 1 | Mine | no | 0 | 2 | 1 | 0 | 0 | 0 | 0 | 330 |
| L1114 | 4 | 1 | Opponent | no | 0 | 2 | 3 | 3 | 0 | 0 | 0 | 500 |
| L1131 | 3 | 1 | Mine | no | 0 | - | 2 | 0 | 2 | 0 | 0 | 501 |
| L1131 | 3 | 1 | Opponent | no | 0 | 4 | 2 | 2 | 2 | 0 | 0 | 170 |
| L1224 | 6 | 1 | Mine | no | 4 | 2 | 3 | 0 | 0 | 0 | 0 | 330 |
| L1224 | 6 | 1 | Opponent | no | 6 | 2 | 2 | 2 | 0 | 0 | 0 | 0 |
| L1319 | 5 | 1 | Mine | no | - | 2 | 4 | 0 | 0 | 0 | 0 | 302 |
| L1319 | 5 | 1 | Opponent | yes | - | 2 | 7 | 1 | 1 | 0 | 0 | 0 |
| L1335 | 3 | 1 | Mine | no | 6 | 2 | 1 | 0 | 0 | 0 | 0 | 302 |
| L1335 | 3 | 1 | Opponent | no | 0 | 2 | 2 | 2 | 0 | 0 | 0 | 266 |
| L1431 | 3 | 1 | Mine | yes | 3 | 2 | 3 | 0 | 0 | 0 | 0 | 0 |
| L1431 | 3 | 1 | Opponent | yes | 1 | - | 3 | 2 | 2 | 0 | 0 | 456 |
| L1527 | 3 | 1 | Mine | no | 8 | 2 | 6 | 1 | 1 | 0 | 0 | 0 |
| L1527 | 3 | 1 | Opponent | no | 0 | 2 | 5 | 2 | 0 | 0 | 0 | 0 |
| L1625 | 5 | 1 | Mine | yes | - | 3 | 4 | 2 | 0 | 0 | 0 | 200 |
| L1625 | 5 | 1 | Opponent | no | - | 1 | 3 | 2 | 0 | 0 | 0 | 0 |
| L1723 | 1 | 1 | Mine | no | 1 | 2 | 5 | 0 | 0 | 0 | 0 | 175 |
| L1723 | 1 | 1 | Opponent | yes | 1 | 2 | 7 | 0 | 1 | 0 | 0 | 0 |
| L1823 | 5 | 1 | Mine | yes | - | - | 3 | 1 | 0 | 0 | 0 | 234 |
| L1823 | 5 | 1 | Opponent | yes | - | 2 | 4 | 2 | 1 | 0 | 0 | 70 |
| L1923 | 3 | 1 | Mine | no | 1 | 2 | 5 | 0 | 1 | 0 | 0 | 0 |
| L1923 | 3 | 1 | Opponent | no | 2 | 2 | 5 | 0 | 0 | 0 | 0 | 0 |
| L2025 | 3 | 1 | Mine | yes | 4 | - | 1 | 0 | 0 | 0 | 0 | 402 |
| L2025 | 3 | 1 | Opponent | no | 3 | 3 | 8 | 1 | 0 | 0 | 0 | 0 |
| L2127 | 3 | 1 | Mine | no | 4 | - | 1 | 3 | 1 | 0 | 0 | 730 |
| L2127 | 3 | 1 | Opponent | no | 5 | 1 | 5 | 2 | 0 | 0 | 0 | 0 |
| L2231 | 5 | 1 | Mine | yes | - | 2 | 3 | 1 | 0 | 0 | 0 | 72 |
| L2231 | 5 | 1 | Opponent | no | - | 4 | 4 | 1 | 2 | 0 | 0 | 541 |
| L2335 | 1 | 1 | Mine | no | 5 | 1 | 2 | 0 | 2 | 0 | 0 | 60 |
| L2335 | 1 | 1 | Opponent | no | 0 | 2 | 5 | 0 | 1 | 0 | 0 | 0 |
| L2531 | 5 | 1 | Mine | yes | - | 3 | 4 | 0 | 0 | 0 | 0 | 0 |
| L2531 | 5 | 1 | Opponent | yes | - | 3 | 2 | 3 | 0 | 0 | 0 | 0 |
| L2730 | 6 | 1 | Mine | no | 1 | 3 | 10 | 4 | 1 | 0 | 0 | 0 |
| L2730 | 6 | 1 | Opponent | no | 3 | 2 | 3 | 0 | 0 | 0 | 0 | 0 |
| L2934 | 6 | 1 | Mine | no | 5 | 2 | 2 | 0 | 0 | 0 | 0 | 170 |
| L2934 | 6 | 1 | Opponent | no | 0 | 2 | 1 | 0 | 0 | 0 | 0 | 267 |
| **Average** | | | Mine | 21% | 2.8 | 2.3 | 2.5 | 0.9 | 0.3 | 0.0 | 0.0 | 346.6 |
| **Average** | | | Opponent | 24% | 2.1 | 2.1 | 3.5 | 1.7 | 0.4 | 0.0 | 0.0 | 181.5 |

### KPIs: fw-h2h2-opp-1eea44e-p1

Rules off - Mine only: WAR ENGINE JOBS, STAY WEIGHED, BEST FIRST, RANDOM MOVE BY FIGURES, RANDOM MOVER NO PROMISE, STABLE ROLE, WOUNDED STAYS OUT, BEST FACING, LOST CHARGE, SCREEN BY WHAT IT SAVES, REDIRECT BY WHAT IT STOPS, SHOOTER COUNTED ONCE, LURE BY WHAT IT DRAWS, HILL BY ITS CHANCE, MOVE TO CHARGE, LONG SHOT, DEFENSIVE ARMY, SHOOTS FROM THE BEST SPOT, SUPPORTS, RESERVE FALL BACK, WAIT AFTER COSTS, CHARGE NOW FIRST, SUPPORT NARROWED, WAR ENGINE CHARGES, DEFENSIVE FLOOR.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 176) | 3% (5 of 177) | 1% (5 of 353) |
| Winner chose to follow up after the loser gave ground |  | 95% (69 of 73); on the table 96% | 98% (54 of 55); on the table 98% | 96% (123 of 128); on the table 97% |
| Winner chose to pursue after the loser fell back in good order |  | 93% (14 of 15); on the table 93% | 81% (17 of 21); on the table 81% | 86% (31 of 36); on the table 86% |
| Winner chose to pursue after the loser fled |  | 70% (21 of 30); on the table 77% | 79% (41 of 52); on the table 92% | 76% (62 of 82); on the table 87% |
| Winner chose to follow up or pursue (all three) |  | 88% (104 of 118); on the table 91% | 88% (112 of 128); on the table 93% | 88% (216 of 246); on the table 92% |
| Magic missiles tried each own turn | 50%+ | 35% (117 of 330) | 29% (60 of 210) | 33% (177 of 540) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 51% (117 of 229) | 45% (60 of 134) | 49% (177 of 363) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 53% (30 of 57) | 53% (30 of 57) |
| Points that never fought | lower | 28% (20099 of 71484) | 32% (23024 of 71889) | 30% (43123 of 143373) |
|   infantry points that never fought | lower | 32% (5395 of 16863) | 52% (6948 of 13348) | 41% (12343 of 30211) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 52% (144 of 279) | 58% (171 of 295) | 55% (315 of 574) |
| Bound items with a magic missile used (at least once a game) |  | 86% (19 of 22); 1.7 uses a game | 70% (14 of 20); 1.2 uses a game | 79% (33 of 42); 1.5 uses a game |
| Bound items with another spell used |  | 75% (12 of 16); 0.6 uses a game | 38% (3 of 8); 0.1 uses a game | 62% (15 of 24); 0.4 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 58% (11 of 19); 0.3 uses a game | 58% (7 of 12); 0.2 uses a game | 58% (18 of 31); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 46% (27735 of 59666) | 51% (32051 of 62699) | 49% (59786 of 122365) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.8 (30%) | 1.2 (29%) | 3.0 (29%) |
| MARCHED: its unit marched | 1.1 (18%) | 0.5 (11%) | 1.6 (15%) |
| CHARGED: its unit charged | 0.2 (3%) | 0.1 (2%) | 0.2 (2%) |
| IN COMBAT: engaged in combat | 1.5 (26%) | 1.1 (25%) | 2.6 (26%) |
| REAR RANK: in a rear rank | 0.1 (1%) | 0.2 (5%) | 0.3 (3%) |
| FLEEING: fleeing | 0.2 (4%) | 0.0 (0%) | 0.2 (2%) |
| GONE: slain | 0.8 (13%) | 0.9 (21%) | 1.7 (17%) |
| OFF THE TABLE: off the table or not arrived | 0.2 (4%) | 0.2 (4%) | 0.4 (4%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.1 (1%) | 0.1 (1%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 3.7 | 1.7 | 1.3 | 4.9 | 0.5 | 2.2 |
| not cast | 4.3 | 2.6 | 3.4 | 10.1 | 1.9 | 21.8 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) | 0.0 (0%) | 1.9 (9%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.1 (1%) | 1.1 (44%) | 0.4 (12%) | 3.0 (29%) | 0.3 (16%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.6 (15%) | 0.4 (21%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (2%) | 0.1 (4%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.1 (3%) | 0.3 (13%) | 0.6 (18%) | 2.6 (26%) | 0.5 (25%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.1 (1%) | 0.2 (6%) | 0.2 (7%) | 0.3 (3%) | 0.0 (0%) | 0.0 (0%) |
| NO CASTS LEFT: every cast used on other spells | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) |
| FLEEING: fleeing | 0.2 (6%) | 0.0 (0%) | 0.0 (1%) | 0.2 (2%) | 0.0 (0%) | 0.7 (3%) |
| GONE: slain | 1.1 (26%) | 0.3 (12%) | 0.4 (12%) | 1.7 (17%) | 0.1 (3%) | 3.5 (16%) |
| OFF THE TABLE: off the table or not arrived | 0.3 (8%) | 0.2 (9%) | 0.2 (6%) | 0.4 (4%) | 0.1 (3%) | 0.9 (4%) |
| STUPIDITY: Stupidity | 0.1 (2%) | 0.0 (1%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (1%) | 0.3 (11%) | 0.0 (0%) | 0.1 (1%) | 0.4 (24%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.3 (53%) | 0.1 (5%) | 1.5 (44%) | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 14.6 (67%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.1 a game | 0.4 a game | 0.8 a game |
| stood (cast and not dispelled) | 62% (21 of 34) | 55% (6 of 11) | 60% (27 of 45) |
| the unit moved after it | 71% (15 of 21) | 100% (6 of 6) | 78% (21 of 27) |
| it charged on its next turn | 5% (1 of 21) | 17% (1 of 6) | 7% (2 of 27) |
| the enemy charged it first | 38% (8 of 21) | 17% (1 of 6) | 33% (9 of 27) |
| it fought by the end of its next turn | 19% (4 of 21) | 17% (1 of 6) | 19% (5 of 27) |
| it moved out of a charge the enemy had planned (not charged first) | 19% (4 of 21) | 17% (1 of 6) | 19% (5 of 27) |
| none of these (no charge, no fight, no charge escaped) | 38% (8 of 21) | 50% (3 of 6) | 41% (11 of 27) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 60% (541 of 904) | 53% (315 of 599) | 57% (856 of 1503) |
|   cavalry | 47% (35 of 75) | 59% (67 of 114) | 54% (102 of 189) |
|   character | 50% (57 of 114) | 31% (38 of 122) | 40% (95 of 236) |
|   chariot | 37% (34 of 93) | 63% (24 of 38) | 44% (58 of 131) |
|   infantry | 52% (154 of 295) | 55% (127 of 229) | 54% (281 of 524) |
|   monster | 56% (23 of 41) | 33% (9 of 27) | 47% (32 of 68) |
|   war machine | 83% (238 of 286) | 72% (50 of 69) | 81% (288 of 355) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.5 (25%) | 1.4 (17%) | 3.9 (21%) |
| CHARGED: it charged | 1.4 (14%) | 1.9 (25%) | 3.4 (19%) |
| FLEEING: it fled or was fleeing | 0.2 (2%) | 0.2 (2%) | 0.4 (2%) |
| IN COMBAT: it fought this turn or the last | 0.9 (9%) | 0.6 (7%) | 1.4 (8%) |
| MOVED: a war machine that moved | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NO TARGET IN RANGE | 1.8 (18%) | 1.4 (18%) | 3.2 (18%) |
| ONLY IN COMBAT: the only targets were in combat | 0.6 (6%) | 0.6 (8%) | 1.3 (7%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.8 (18%) | 1.1 (14%) | 2.9 (16%) |
| SHELTERED: the target was sheltered | 0.3 (3%) | 0.4 (5%) | 0.7 (4%) |
| STUPIDITY | 0.0 (0%) | 0.1 (1%) | 0.1 (0%) |
| OTHER BAR | 0.4 (4%) | 0.2 (2%) | 0.6 (3%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 4.1 | 1.4 | 73% | 9.2 pts | 38 pts |
| character | 3.1 | 1.4 | 69% | 9.3 pts | 29 pts |
| chariot | 1.7 | 0.5 | 85% | 6.7 pts | 11 pts |
| infantry | 11.3 | 4.3 | 72% | 8.7 pts | 99 pts |
| monster | 1.1 | 0.1 | 89% | 3.0 pts | 3 pts |
| war machine | 8.0 | 6.6 | 61% | 24.0 pts | 192 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.8 | 6.7 | 5.7 |
| Charges that made contact a game | 3.6 | 4.9 | 4.2 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.05 declared, 0.82 contact (22 units) | 0.75 declared, 0.62 contact (16 units) | 0.92 declared, 0.74 contact (38 units) |
|   per unit a game, units carrying another wizard (or one alone) | 1.00 declared, 0.67 contact (6 units) | 0.78 declared, 0.67 contact (9 units) | 0.87 declared, 0.67 contact (15 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.56 declared, 0.42 contact (254 units) | 0.79 declared, 0.57 contact (279 units) | 0.68 declared, 0.50 contact (533 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 56% (39 of 70) | 67% (14 of 21) | 25% (2 of 8) | 56% (55 of 99) |
| Character in a unit | 66% (19 of 29) | 61% (11 of 18) | 100% (1 of 1) | 65% (31 of 48) |
| Character on its own | 78% (45 of 58) | 45% (19 of 42) | 23% (15 of 65) | 48% (79 of 165) |
| Chariot | 50% (8 of 16) | 80% (8 of 10) | - | 62% (16 of 26) |
| Infantry | 55% (49 of 89) | 36% (13 of 36) | 0% (0 of 2) | 49% (62 of 127) |
| Monster | 56% (18 of 32) | 80% (8 of 10) | - | 62% (26 of 42) |
| Monstrous | 82% (9 of 11) | 64% (9 of 14) | - | 72% (18 of 25) |
| War Machines | 68% (28 of 41) | 0% (0 of 1) | - | 67% (28 of 42) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 6 | 79% (15 of 19); on the table 84% | 49% (68 of 138) | 26% | 48% (16 of 33) | 89% (8 of 9); 5.5 uses a game | 100% (3 of 3); 1.5 uses a game | 67% (6 of 9); 1.0 uses a game |
| Chaos Dwarfs | 3 | 100% (7 of 7); on the table 100% | 42% (10 of 24) | 32% | 42% (10 of 24) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Dwarfen Mountain Holds | 5 | 79% (11 of 14); on the table 79% | - | 51% | 71% (29 of 41) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 6 | 85% (11 of 13); on the table 92% | 44% (16 of 36) | 42% | 67% (43 of 64) | 0.0 uses a game | 50% (1 of 2); 0.3 uses a game | 25% (1 of 4); 0.2 uses a game |
| Grand Cathay | 5 | 100% (16 of 16); on the table 100% | 19% (20 of 108) | 36% | 41% (18 of 44) | 92% (11 of 12); 6.4 uses a game | 100% (1 of 1); 0.2 uses a game | 60% (3 of 5); 0.6 uses a game |
| High Elf Realms | 6 | 94% (15 of 16); on the table 94% | 30% (9 of 30) | 22% | 39% (19 of 49) | 100% (5 of 5); 2.7 uses a game | 56% (10 of 18); 2.3 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | 50% (1 of 2); on the table 50% | - | 23% | 33% (2 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Lizardmen | 2 | 80% (8 of 10); on the table 100% | - | 27% | 50% (7 of 14) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 3 | 86% (6 of 7); on the table 100% | 8% (1 of 12) | 42% | 67% (14 of 21) | 33% (1 of 3); 0.3 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 3 | 100% (19 of 19); on the table 100% | 11% (4 of 36) | 8% | 67% (16 of 24) | 0.0 uses a game | 0.0 uses a game | 100% (3 of 3); 1.0 uses a game |
| Skaven | 4 | 92% (12 of 13); on the table 92% | 23% (7 of 30) | 30% | 65% (22 of 34) | 67% (2 of 3); 0.8 uses a game | 0.0 uses a game | 50% (2 of 4); 0.5 uses a game |
| Tomb Kings of Khemri | 6 | 78% (18 of 23); on the table 83% | 17% (2 of 12) | 33% | 23% (7 of 30) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 8 | 85% (33 of 39); on the table 95% | 41% (22 of 54) | 24% | 62% (31 of 50) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 8 | 92% (22 of 24); on the table 92% | 23% (7 of 30) | 21% | 62% (46 of 74) | 100% (4 of 4); 2.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.1 uses a game |
| Wood Elf Realms | 6 | 92% (22 of 24); on the table 92% | 37% (11 of 30) | 32% | 53% (35 of 66) | 33% (2 of 6); 0.8 uses a game | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |

Flank and rear charges a unit could have turned to face (fw-h2h2-opp-1eea44e-p1, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 48% (42) | 39% (29) | 44% (71) |
| ...free all their last turn and able to turn (per game) | 0.75 | 0.44 | 1.19 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.17 | 0.22 | 0.39 |
| ...with the charger already in that arc before they moved (per game) | 0.64 | 0.39 | 1.03 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 1.36 | 1.14 | 2.50 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.67 | 0.58 | 1.25 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 5.78 | 5.19 | 10.97 |

### Quality by phase: fw-h2h2-opp-1eea44e-p1

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.1 | 3.4 |
| Strategy | Charge objectives carried out (made contact) | 57% (82 of 143) | 51% (105 of 207) |
| Strategy | Shoot objectives carried out (shot that target) | 52% (188 of 361) | 58% (94 of 163) |
| Strategy | Close-in objectives charged next turn | 14% (24 of 175) | 14% (27 of 197) |
| Strategy | Support requests answered (helper made contact too) | 64% (14 of 22) | 57% (16 of 28) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 75% (3 of 4) | 80% (4 of 5) |
| Strategy | Hexes on a unit its side charged or shot that turn | 48% (10 of 21) | 64% (7 of 11) |
| Strategy | Joined characters whose unit fought | 62% (24 of 39) | 61% (19 of 31) |
| Strategy | Lone characters that fought | 84% (90 of 107) | 77% (81 of 105) |
| Movement | Charges halted short of contact | 0.2 | 0.3 |
| Movement | Idle units | 0.9 | 1.7 |
| Movement | Points that never moved of their own | 346.6 | 181.5 |
| Movement | Fights charged into per game | 3.0 | 4.2 |
| Movement | Charges with odds: long shots (under 50%) | 17 of 96, net +50 | 21 of 125, net +118 |
| Movement | Charges with odds: sweet spot (55-75%) | 14 of 96, net -7 | 13 of 125, net +155 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 16 of 96, net +83 | 11 of 125, net +26 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 30 of 96, net +84 | 45 of 125, net +71 |
| Shooting | Shots by shooting units (incl. breath weapons) | 9.3 | 8.4 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 41% (137 of 336) | 45% (136 of 301) |
| Shooting | Points destroyed by shooting units | 101.4 | 37.7 |
| Shooting | War machine shots | 6.6 | 1.4 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 53% (125 of 238) | 36% (18 of 50) |
| Shooting | Points destroyed by war machines | 80.6 | 12.1 |
| Magic | Magic missiles cast | 1.9 | 1.0 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 29% (20 of 70) | 35% (13 of 37) |
| Magic | Wounds caused by magic missiles | 5.6 | 2.0 |
| Magic | Wounds caused by other spells | 1.7 | 1.2 |
| Magic | Points destroyed by magic (all spells) | 112.5 | 55.4 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.4 / 0.6 / 0.7 / 0.1 | 1.5 / 0.4 / 0.6 / 0.2 |
| Combat | Points destroyed in combat | 390.7 | 437.8 |
| Combat | Points run down | 103.9 | 198.0 |
| Combat | Net points per charged fight, damage counted | +69 | +94 |
| Combat | Net per 100 charger points, damage counted | +23.9 | +35.8 |
| Combat | First round won (charged fights) | 58% | 56% |
| Combat | Net points per charged fight | +65 | +90 |
| Combat | Net points per supported fight / lone fight | +107 / +56 | +83 / +91 |
| Combat | Charged fights on a top-3 enemy unit | 46 of 108 | 60 of 150 |
| Game | Points lost | 859.9 | 862.3 |
| Game | VP from objectives | 593.3 | 613.6 |
| Game | Lone holders (player turns) | 2.8 | 2.1 |

- Mine won / drew / lost: 14 / 9 / 13 of 36 ended games (of 36); mean margin (Mine - Opponent) -44 VP
- The side that went first won 12 of 27 games with a winner
- Points traded per game (both sides' losses): 1722
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: fw-h2h2-opp-1eea44e-p1

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.6 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 4.5 |
| ALREADY CARRIED | 0.0 | +0.0 | 8.9 | 0.0 | - | - | - | - |
| ARRIVAL HUNT | - | - | - | - | 0.0 | +0.2 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.3 | +0.0 | 0.0 | 3.9 | 0.2 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | 0.7 | +6.3 | 0.0 | 30.5 | 1.0 | +10.4 | 0.0 | 42.8 |
| BEST FACING | - | - | - | - | 0.4 | +19.3 | 0.0 | 30.2 |
| BEST FIRST | - | - | - | - | 3.4 | +181.2 | 95.3 | 58.7 |
| BEST OVERALL | 0.3 | +15.5 | 0.0 | 21.7 | 0.4 | +18.5 | 0.0 | 26.1 |
| BEST PREY | 4.1 | +261.1 | 142.9 | 177.9 | 0.9 | +48.8 | 9.5 | 22.9 |
| BEST PRIZE | - | - | - | - | 0.1 | -5.1 | 5.2 | 0.0 |
| BIG CHARACTER SAFETY | 0.2 | +0.2 | 0.0 | 12.9 | 0.1 | -0.1 | 0.0 | 15.0 |
| BLOCKED CHARGE SKIPPED | 0.1 | +0.0 | 33.1 | 5.7 | 0.1 | +0.0 | 2.2 | 0.0 |
| BLOCKED WHEEL | 0.3 | +8.7 | 0.0 | 0.0 | 0.4 | -1.8 | 0.0 | 8.4 |
| BOMBING RUN | 0.0 | +1.3 | 3.4 | 0.0 | - | - | - | - |
| BOUND ASSAILMENT | 0.0 | +0.0 | 0.0 | 4.2 | - | - | - | - |
| CANNON PLAN MISSED | 1.0 | +0.0 | 110.4 | 3.9 | 0.1 | +0.0 | 3.5 | 0.0 |
| CANNON PLANNED TARGET | 5.2 | +169.6 | 436.1 | 72.4 | 1.1 | +18.4 | 79.9 | 9.9 |
| CANNON SIGHT KEPT | 1.0 | +0.0 | 0.0 | 3.5 | 0.3 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT COUNTER | 0.0 | +0.0 | 0.0 | 0.0 | 0.0 | -2.4 | 7.8 | 0.0 |
| CARRIES OUT SET-UP | 0.1 | +0.0 | 0.0 | 10.6 | 0.0 | -2.5 | 0.0 | 0.0 |
| CAST JOB | 0.9 | +29.7 | 59.6 | 17.2 | 0.3 | +6.0 | 17.2 | 9.4 |
| CASTER AWAY FROM SCREEN | 0.4 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.8 | +103.7 | 39.9 | 19.3 | 0.1 | +2.8 | 2.4 | 0.0 |
| CASTS AFTER FRIENDS | 0.6 | +0.0 | 0.0 | 17.2 | 0.3 | +0.0 | 0.0 | 9.1 |
| CASTS FROM BEHIND | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.1 | +0.6 | 0.0 | 6.1 | 0.0 | +0.3 | 0.0 | 0.0 |
| CHAFF PASSED | 0.2 | -0.6 | 5.4 | 7.9 | 0.1 | -0.0 | 0.0 | 0.0 |
| CHAMPION TAKES THE CHALLENGE | - | - | - | - | 0.0 | +0.0 | 7.8 | 0.0 |
| CHARGE NOW FIRST | - | - | - | - | 3.3 | +0.0 | 264.4 | 133.6 |
| CHARGE NOW WEIGHED | 0.3 | -18.2 | 9.9 | 21.6 | 0.3 | -16.2 | 2.0 | 2.9 |
| CHARIOT NO STATIC JOB | 0.5 | +0.0 | 29.6 | 7.1 | - | - | - | - |
| CHARIOT WIZARD CAREFUL | 0.1 | -0.3 | 6.5 | 26.1 | 0.0 | -1.0 | 5.2 | 0.0 |
| CHEAP HELPER | 0.1 | +0.0 | 6.2 | 6.9 | 0.1 | +0.0 | 12.0 | 2.7 |
| COMBAT PIVOT | 0.3 | +0.0 | 11.0 | 13.8 | 0.6 | +0.0 | 22.6 | 57.4 |
| CONTINUE AHEAD WEIGHED | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | 0.7 | +152.5 | 26.8 | 6.1 | 0.2 | +56.8 | 3.2 | 0.0 |
| COUNTER-CHARGE COVER | 8.7 | +713.3 | 0.0 | 318.0 | 6.6 | +600.1 | 0.0 | 238.6 |
| DEFENSIVE ARMY | - | - | - | - | 0.1 | +0.0 | 0.0 | 6.3 |
| DEFENSIVE FLOOR | - | - | - | - | 0.1 | +1.3 | 10.4 | 0.0 |
| EDGE GIVE GROUND | 0.1 | +16.8 | 29.5 | 0.0 | 0.2 | +6.3 | 26.9 | 18.6 |
| ELIXIR WORTH | 0.1 | +1.1 | 0.0 | 8.2 | 0.1 | +0.6 | 0.0 | 0.0 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 1.4 | +108.4 | 0.0 | 123.5 | 1.1 | +98.5 | 0.0 | 90.8 |
| FALLBACK BY WORTH | 5.2 | +81.8 | 0.0 | 123.3 | 4.8 | +40.9 | 0.0 | 42.2 |
| FIGHT LIFT | 0.2 | +1.6 | 2.8 | 0.0 | - | - | - | - |
| FIRE AND FLEE | 0.1 | +1.0 | 0.0 | 0.0 | - | - | - | - |
| FLANK NOT WEIGHED | 5.9 | +0.0 | 0.0 | 251.4 | 4.6 | +0.0 | 0.0 | 199.5 |
| FOCUS FIRE | - | - | - | - | 0.1 | +1.2 | 2.5 | 0.0 |
| FOLLOW UP WEIGHED | 1.1 | +146.5 | 0.0 | 59.2 | 1.2 | +150.8 | 0.0 | 20.2 |
| FRIENDS SHOTS CHECKED | 0.2 | +12.3 | 0.0 | 25.4 | 0.1 | +8.3 | 0.0 | 0.0 |
| GIVES UP | 1.3 | -38.7 | 135.1 | 53.3 | 0.1 | -0.8 | 0.0 | 9.4 |
| GIVES UP ITS SCREEN | 0.6 | -27.8 | 55.8 | 17.4 | - | - | - | - |
| GROUND FLIERS | 0.0 | +0.8 | 0.0 | 0.0 | - | - | - | - |
| HELPER ALREADY ASKED | 0.0 | +0.0 | 1.9 | 0.0 | 0.0 | +0.0 | 0.0 | 0.8 |
| HELPER UNSEEN | 0.1 | +0.0 | 7.0 | 1.4 | 0.4 | +0.0 | 65.9 | 0.0 |
| HILL BY ITS CHANCE | - | - | - | - | 0.1 | -12.2 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.8 | +0.0 | 0.0 | 0.0 |
| HORN WORTH | - | - | - | - | 0.0 | +0.1 | 0.0 | 0.0 |
| HUNT ADVANCE | 0.1 | +0.7 | 5.3 | 1.4 | 0.2 | +12.0 | 0.0 | 16.0 |
| HUNT DROPPED | - | - | - | - | 0.1 | +0.0 | 3.6 | 6.4 |
| HUNT IN PAIRS | 0.3 | +34.7 | 0.0 | 5.7 | 0.3 | +11.6 | 0.0 | 5.4 |
| HUNT KEPT | 0.1 | +0.6 | 10.6 | 0.0 | 0.1 | +2.6 | 0.0 | 1.9 |
| HUNT RESULT | 0.1 | +5.5 | 0.0 | 1.4 | 0.3 | +11.5 | 3.6 | 16.3 |
| HUNT THE GUNS | 0.1 | +28.2 | 9.2 | 1.4 | 0.4 | +108.2 | 10.4 | 21.2 |
| INVITES THE FIGHT | - | - | - | - | 1.7 | +35.4 | 34.4 | 14.1 |
| JOINT CHARGE PLAN | - | - | - | - | 0.2 | +9.7 | 5.2 | 8.2 |
| KEEP FALLS | 0.0 | +0.2 | 0.0 | 0.0 | 0.1 | +0.8 | 0.0 | 0.0 |
| KEEPS ITS PREY | 0.1 | +1.4 | 0.0 | 0.0 | 0.1 | +0.3 | 1.2 | 0.0 |
| KEEPS ITS TARGET | 1.8 | +53.3 | 177.4 | 38.6 | 1.8 | +54.2 | 179.7 | 69.4 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KILLS COUNT | 1.6 | +68.4 | 125.8 | 52.0 | 2.3 | +89.6 | 184.0 | 78.2 |
| KILLS COUNT NEXT TURN | 7.6 | +260.8 | 425.3 | 206.9 | 6.7 | +253.9 | 383.0 | 187.5 |
| LONE CHARACTER SAFE SPOT | 0.4 | +12.8 | 0.0 | 1.4 | 0.6 | +14.2 | 38.4 | 0.0 |
| LONE WIZARD HOLDS BACK | - | - | - | - | 0.3 | +0.0 | 9.5 | 10.6 |
| LONE WIZARD KEPT IN | 0.7 | +49.1 | 0.0 | 0.0 | 0.2 | +24.5 | 0.0 | 0.0 |
| LONG SHOT | - | - | - | - | 0.7 | -1.4 | 34.0 | 19.4 |
| LOST CHARGE | - | - | - | - | 2.4 | -35.4 | 80.6 | 151.6 |
| MAKE SURE TOGETHER | 0.4 | +24.5 | 13.1 | 10.6 | 0.6 | +53.9 | 5.2 | 33.4 |
| MANOEUVRE | 0.1 | +2.7 | 0.0 | 2.9 | 0.2 | +4.9 | 0.0 | 8.8 |
| MARCH CHECK | 0.5 | +25.9 | 0.0 | 22.3 | 0.6 | +46.2 | 0.0 | 24.6 |
| MARCH ODDS | 0.6 | +53.5 | 29.2 | 24.4 | 0.2 | +20.1 | 0.0 | 0.0 |
| MARCH OVER CASTS | 0.6 | +13.9 | 0.0 | 25.2 | 0.2 | +15.9 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 5.0 | +219.5 | 0.0 | 153.8 | 4.5 | +156.2 | 0.0 | 167.7 |
| MISSILES IN THE MOVE | 3.9 | +180.5 | 0.0 | 96.8 | 3.0 | +57.6 | 0.0 | 123.7 |
| MISSILES NEXT TURN | 4.7 | +111.2 | 0.0 | 138.4 | 3.6 | +33.6 | 0.0 | 150.1 |
| MODEL FACING | 0.2 | +54.1 | 0.0 | 0.0 | - | - | - | - |
| MONSTER WIZARD ROAMS | 0.2 | +0.0 | 6.2 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| MOVE AND CAST | 0.2 | +7.1 | 0.0 | 2.2 | 0.3 | +17.6 | 0.0 | 9.2 |
| MOVE SPELL IN RANGE | 0.1 | +4.2 | 0.0 | 0.0 | 0.1 | +0.4 | 0.0 | 0.0 |
| MOVE SPELL OUT OF RANGE | 0.5 | -95.3 | 0.0 | 0.0 | 0.1 | -7.8 | 0.0 | 7.6 |
| MOVE SPELL SPOT | 0.3 | +0.0 | 0.0 | 20.1 | 0.2 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE | - | - | - | - | 4.5 | +300.7 | 217.3 | 193.1 |
| MOVES UNITS SPELL | 0.1 | +3.4 | 0.0 | 0.0 | 0.1 | +1.8 | 0.0 | 0.0 |
| NEEDED THERE | 0.0 | +1.8 | 0.0 | 0.0 | 0.2 | +6.4 | 17.6 | 0.0 |
| NO RALLY LEFT | 0.0 | +0.2 | 0.0 | 2.3 | 0.0 | +0.4 | 0.0 | 0.0 |
| NOT NEEDED | 0.2 | -20.3 | 26.6 | 1.2 | 0.4 | -13.8 | 39.4 | 2.3 |
| NOT TURNED | 5.8 | +88.1 | 0.0 | 177.5 | 5.2 | +81.6 | 0.0 | 181.9 |
| NOT WORTH A CAST | 0.9 | -0.7 | 0.0 | 50.0 | 0.4 | -0.4 | 0.0 | 0.0 |
| OFF BEST | 18.0 | -1047.9 | 24.2 | 401.7 | 14.8 | -783.7 | 10.6 | 353.2 |
| OPENS A LANE | 0.5 | +1.3 | 41.4 | 0.0 | 0.0 | +0.2 | 5.2 | 6.5 |
| OPENS UP | 0.1 | +6.4 | 7.9 | 0.0 | 0.4 | +48.5 | 6.8 | 22.9 |
| OVERRUNS AWAY | 0.5 | +10.5 | 27.8 | 40.2 | 0.5 | +19.5 | 17.4 | 24.2 |
| PATHS CROSS | 1.7 | +151.0 | 0.0 | 23.9 | 2.6 | +195.2 | 0.0 | 43.1 |
| PERIAPT WORTH | 0.0 | +3.4 | 0.0 | 0.0 | 0.0 | +3.4 | 0.0 | 15.0 |
| PIVOT GUARDS FLANK | 0.1 | -0.6 | 0.0 | 0.0 | 0.2 | -4.3 | 0.0 | 24.6 |
| PLAN RESULT | 36.5 | +1514.2 | 1336.9 | 1079.9 | 37.9 | +1319.2 | 1473.2 | 1045.0 |
| PURSUES BIG PREY | 0.0 | -0.3 | 0.0 | 0.0 | 0.2 | -18.6 | 0.0 | 13.7 |
| RAIDS THE BAGGAGE | - | - | - | - | 0.0 | +6.6 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE NEXT TURN | - | - | - | - | 0.1 | +5.7 | 0.0 | 0.0 |
| RANDOM MOVE BY FIGURES | - | - | - | - | 1.6 | +16.5 | 0.0 | 56.1 |
| RANDOM MOVER NO PROMISE | - | - | - | - | 0.4 | -13.1 | 10.5 | 15.3 |
| REDIRECT BY WHAT IT STOPS | - | - | - | - | 0.5 | -1.9 | 0.0 | 8.7 |
| REDIRECT COUNTER | 3.6 | +183.4 | 0.0 | 48.3 | 4.1 | +336.6 | 0.0 | 72.4 |
| REDIRECT WEIGHED | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +8.3 | 12.2 | 3.1 |
| RESERVE FALL BACK | - | - | - | - | 0.6 | +14.2 | 0.0 | 14.5 |
| RESTRAINS TO SHOOT | 0.1 | +4.3 | 0.0 | 15.1 | 0.1 | +7.8 | 0.0 | 12.1 |
| RISK BY ARC | 2.5 | +69.4 | 187.8 | 133.4 | 3.5 | +106.5 | 256.3 | 106.3 |
| SAFE SURE CHARGE | 0.0 | -0.1 | 1.4 | 0.0 | - | - | - | - |
| SAFER THAN THE JOB | 0.7 | +34.5 | 0.0 | 46.6 | 0.6 | +28.4 | 0.0 | 49.2 |
| SCOUT SPOT | 0.4 | +0.6 | 0.0 | 0.0 | 0.3 | +0.3 | 0.0 | 2.8 |
| SCOUT WAITS | 0.4 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 2.8 |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 0.1 | +1.7 | 0.0 | 0.0 |
| SEARCH SPOT | 1.5 | +73.1 | 0.0 | 42.4 | 2.6 | +121.3 | 0.0 | 44.6 |
| SECOND HUNTER | 0.0 | -0.2 | 4.6 | 0.0 | 0.0 | -0.0 | 0.0 | 0.0 |
| SELF MOVE SPELL | 0.2 | +11.8 | 0.0 | 0.0 | 0.3 | +2.5 | 0.0 | 36.2 |
| SET UP TOGETHER | 0.9 | +75.1 | 36.1 | 22.1 | 1.1 | +82.4 | 15.8 | 53.2 |
| SET-UP ANY TARGET | 0.3 | +27.1 | 0.0 | 0.0 | 0.1 | +6.8 | 0.0 | 0.0 |
| SET-UP MISSED | 0.0 | +1.9 | 0.0 | 0.0 | 0.0 | +1.1 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.4 | +0.9 | 0.0 | 0.0 | 0.3 | +0.8 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | - | - | - | - | 0.6 | +24.3 | 21.1 | 0.0 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 3.3 | 0.0 | +0.0 | 0.0 | 3.8 |
| SHOT REPLANNED | 0.8 | +0.0 | 193.5 | 9.6 | 0.0 | +0.0 | 0.9 | 0.0 |
| SHOTS IN THE MOVE | 13.7 | +558.0 | 0.0 | 257.1 | 7.6 | +171.8 | 0.0 | 118.1 |
| SPELL CATCH ODDS | 0.1 | -2.9 | 0.0 | 0.0 | - | - | - | - |
| SPELL SETS UP CHARGE | 0.4 | +127.7 | 8.9 | 6.1 | 0.1 | +68.0 | 0.0 | 0.0 |
| SPELL WORTH | 1.1 | +19.9 | 127.4 | 98.6 | 1.5 | +34.6 | 124.1 | 131.1 |
| STABLE ROLE | - | - | - | - | 11.0 | +0.0 | 366.3 | 213.8 |
| STANDS TO CAST | 0.1 | +3.9 | 10.1 | 9.6 | 0.0 | +0.7 | 0.0 | 7.0 |
| STAY WEIGHED | - | - | - | - | 0.0 | +1.3 | 0.0 | 0.0 |
| STOPS | 0.1 | +1.8 | 14.4 | 0.0 | 0.2 | +1.8 | 10.4 | 7.2 |
| STOPS SHORT OF THE FLANK | 0.6 | +35.7 | 0.0 | 7.8 | 0.3 | +15.0 | 0.0 | 5.4 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| SUPPORT JOB KEPT | 0.0 | +0.0 | 4.0 | 0.0 | - | - | - | - |
| SUPPORT NARROWED | - | - | - | - | 8.5 | -67.6 | 507.8 | 140.8 |
| SUPPORTS | - | - | - | - | 5.4 | +68.0 | 268.5 | 75.1 |
| SURE CHARGE BEATS ADVANCE | 0.2 | -13.5 | 29.8 | 5.4 | 0.1 | -2.5 | 6.9 | 0.0 |
| SURE REACH TOGETHER | 0.6 | -10.4 | 51.2 | 13.5 | 0.2 | -0.0 | 0.0 | 0.5 |
| THROUGH LINE OF FIRE | 0.4 | +8.1 | 0.0 | 18.2 | 0.1 | +2.3 | 0.0 | 0.0 |
| TURN WORTH | 0.3 | -18.9 | 34.7 | 4.7 | 0.6 | -51.2 | 54.9 | 15.0 |
| TWO OR MORE ARRIVE | 0.3 | +3.4 | 13.1 | 7.8 | 0.2 | +1.6 | 0.0 | 11.0 |
| WAIT AFTER COSTS | - | - | - | - | 8.0 | -403.3 | 330.9 | 257.7 |
| WALKS TO THE FIGHT | - | - | - | - | 1.1 | +22.5 | 12.7 | 29.9 |
| WAR ENGINE CHARGES | - | - | - | - | 0.0 | +2.3 | 4.0 | 0.0 |
| WAR ENGINE JOBS | - | - | - | - | 0.4 | +0.0 | 11.7 | 14.3 |
| WEARS DOWN | 1.3 | +67.3 | 129.2 | 56.2 | 1.6 | +49.2 | 151.1 | 33.5 |
| WHO HITS BACK | 0.3 | +19.1 | 0.0 | 9.6 | 0.3 | +33.3 | 0.0 | 5.4 |
| WHOLE FIGHT | 0.2 | -9.3 | 16.9 | 1.8 | 0.6 | +14.1 | 54.8 | 18.8 |
| WHOLE FIGHT GAIN | 0.4 | +50.3 | 37.5 | 12.2 | 0.8 | +70.5 | 69.9 | 20.6 |

### Rule changes: fw-h2h2-opp-1eea44e-p1

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 1181 | 1181 | 1181 | 32.81 | -65942 | -55.8 |
| PATHS CROSS | 155 | 155 | 155 | 4.31 | +12460 | +80.4 |
| KILLS COUNT NEXT TURN | 517 | 512 | 153 | 4.25 | +5063 | +33.1 |
| SEARCH SPOT | 147 | 147 | 145 | 4.03 | +6999 | +48.3 |
| COUNTER-CHARGE COVER | 550 | 298 | 144 | 4.00 | +8175 | +56.8 |
| BEST FIRST | 124 | 124 | 124 | 3.44 | +6524 | +52.6 |
| FALLBACK BY WORTH | 361 | 361 | 97 | 2.69 | +4417 | +45.5 |
| FACES THE THREAT | 90 | 90 | 90 | 2.50 | +7447 | +82.7 |
| FOLLOW UP WEIGHED | 85 | 85 | 85 | 2.36 | +10702 | +125.9 |
| MOVE TO CHARGE | 162 | 162 | 77 | 2.14 | +3528 | +45.8 |
| BEST PREY | 179 | 174 | 71 | 1.97 | +3617 | +50.9 |
| SUPPORTS | 195 | 195 | 69 | 1.92 | +688 | +10.0 |
| ARTILLERY RE-ROLL WEIGHED | 57 | 57 | 57 | 1.58 | +0 | +0.0 |
| CANNON PLANNED TARGET | 226 | 226 | 50 | 1.39 | +193 | +3.9 |
| MAX FOR POSITIONING | 341 | 181 | 48 | 1.33 | +520 | +10.8 |
| CANNON SIGHT KEPT | 47 | 47 | 47 | 1.31 | +0 | +0.0 |
| REDIRECT COUNTER | 276 | 123 | 46 | 1.28 | +3346 | +72.7 |
| ADVANCE LANE KEPT | 45 | 45 | 45 | 1.25 | +0 | +0.0 |
| SAFER THAN THE JOB | 45 | 45 | 45 | 1.25 | +2264 | +50.3 |
| SHOTS IN THE MOVE | 766 | 484 | 45 | 1.25 | +1195 | +26.6 |
| HOLDS AMBUSHERS | 44 | 44 | 44 | 1.22 | +0 | +0.0 |
| RISK BY ARC | 215 | 200 | 41 | 1.14 | +1493 | +36.4 |
| MARCH CHECK | 41 | 39 | 38 | 1.06 | +2974 | +78.3 |
| WAIT AFTER COSTS | 289 | 289 | 36 | 1.00 | +618 | +17.2 |
| LONE WIZARD KEPT IN | 34 | 34 | 34 | 0.94 | +2648 | +77.9 |
| SET UP TOGETHER | 69 | 56 | 34 | 0.94 | +2160 | +63.5 |
| COMBAT PIVOT | 33 | 33 | 33 | 0.92 | +0 | +0.0 |
| STOPS SHORT OF THE FLANK | 32 | 32 | 32 | 0.89 | +1826 | +57.1 |
| MISSILES IN THE MOVE | 248 | 138 | 30 | 0.83 | +835 | +27.8 |
| RANDOM MOVE BY FIGURES | 57 | 57 | 30 | 0.83 | +593 | +19.8 |
| SHOT REPLANNED | 30 | 30 | 30 | 0.83 | +0 | +0.0 |
| KILLS COUNT | 138 | 134 | 29 | 0.81 | +1142 | +39.4 |
| BLOCKED WHEEL | 27 | 27 | 27 | 0.75 | +247 | +9.1 |
| WALKS TO THE FIGHT | 39 | 39 | 27 | 0.75 | +335 | +12.4 |
| BEST OVERALL | 26 | 26 | 26 | 0.72 | +1223 | +47.0 |
| CHARGE NOW FIRST | 118 | 118 | 26 | 0.72 | -1503 | -57.8 |
| MARCH ODDS | 28 | 27 | 26 | 0.72 | +486 | +18.7 |
| SCOUT WAITS | 26 | 26 | 26 | 0.72 | +0 | +0.0 |
| CASTING BLOCK | 30 | 29 | 25 | 0.69 | +2444 | +97.8 |
| CHARGE NOW WEIGHED | 24 | 24 | 24 | 0.67 | +1346 | +56.1 |
| SHOOTERS IN TWO RANKS | 24 | 24 | 24 | 0.67 | +58 | +2.4 |
| KEEPS ITS TARGET | 129 | 129 | 23 | 0.64 | +408 | +17.7 |
| CASTER AWAY FROM SCREEN | 22 | 22 | 22 | 0.61 | +0 | +0.0 |
| WHO HITS BACK | 22 | 22 | 22 | 0.61 | +1448 | +65.8 |
| WEARS DOWN | 102 | 94 | 21 | 0.58 | +550 | +26.2 |
| RESERVE FALL BACK | 20 | 20 | 20 | 0.56 | +512 | +25.6 |
| CAST JOB | 43 | 42 | 19 | 0.53 | +422 | +22.2 |
| MOVE AND CAST | 18 | 18 | 18 | 0.50 | +891 | +49.5 |
| THROUGH LINE OF FIRE | 18 | 18 | 18 | 0.50 | +376 | +20.9 |
| REDIRECT WEIGHED | 17 | 17 | 17 | 0.47 | +450 | +26.5 |
| WHOLE FIGHT GAIN | 41 | 30 | 16 | 0.44 | +1459 | +91.2 |
| CHARIOT NO STATIC JOB | 18 | 18 | 15 | 0.42 | -2242 | -149.5 |
| STUCK PIVOT | 15 | 15 | 15 | 0.42 | +0 | +0.0 |
| BEST FACING | 14 | 14 | 14 | 0.39 | +695 | +49.6 |
| CASTS FROM BEHIND | 14 | 14 | 14 | 0.39 | +0 | +0.0 |
| SHOOTS FROM THE BEST SPOT | 20 | 20 | 13 | 0.36 | +513 | +39.4 |
| FRIENDS SHOTS CHECKED | 12 | 12 | 12 | 0.33 | +743 | +61.9 |
| INVITES THE FIGHT | 61 | 61 | 12 | 0.33 | +316 | +26.4 |
| MAKE SURE TOGETHER | 38 | 24 | 12 | 0.33 | +883 | +73.6 |
| MANOEUVRE | 12 | 12 | 12 | 0.33 | +273 | +22.8 |
| OPENS UP | 17 | 17 | 12 | 0.33 | +728 | +60.7 |
| PIVOT GUARDS FLANK | 12 | 12 | 12 | 0.33 | -178 | -14.8 |
| BIG CHARACTER SAFETY | 11 | 11 | 11 | 0.31 | +2 | +0.2 |
| SURE CHARGE BEATS ADVANCE | 11 | 11 | 11 | 0.31 | -575 | -52.3 |
| CHAFF PASSED | 10 | 10 | 10 | 0.28 | -22 | -2.2 |
| RESTRAINS TO SHOOT | 10 | 10 | 10 | 0.28 | +436 | +43.6 |
| MODEL FACING | 9 | 9 | 9 | 0.25 | +1948 | +216.4 |
| SHORT GUN FORWARD | 8 | 8 | 8 | 0.22 | +0 | +0.0 |
| WAR ENGINE JOBS | 14 | 14 | 8 | 0.22 | -410 | -51.2 |
| BLOCKED CHARGE SKIPPED | 7 | 7 | 7 | 0.19 | +0 | +0.0 |
| HUNT IN PAIRS | 22 | 14 | 7 | 0.19 | +417 | +59.6 |
| MOVES UNITS SPELL | 7 | 7 | 7 | 0.19 | +186 | +26.5 |
| PURSUES BIG PREY | 7 | 7 | 7 | 0.19 | -678 | -96.8 |
| HUNT ADVANCE | 12 | 12 | 6 | 0.17 | +199 | +33.2 |
| MISSILES NEXT TURN | 297 | 157 | 6 | 0.17 | +4 | +0.6 |
| NEEDED THERE | 8 | 8 | 6 | 0.17 | +0 | +0.0 |
| OVERRUNS AWAY | 36 | 35 | 6 | 0.17 | +148 | +24.8 |
| BACKUP TARGETS | 60 | 22 | 5 | 0.14 | +48 | +9.5 |
| LOST CHARGE | 87 | 86 | 5 | 0.14 | +53 | +10.7 |
| SUPPORT NARROWED | 305 | 305 | 5 | 0.14 | -46 | -9.2 |
| ELIXIR WORTH | 4 | 4 | 4 | 0.11 | +62 | +15.5 |
| STANDS TO CAST | 4 | 4 | 4 | 0.11 | +11 | +2.9 |
| EDGE GIVE GROUND | 12 | 12 | 3 | 0.08 | +452 | +150.8 |
| KEEP FALLS | 3 | 3 | 3 | 0.08 | +86 | +28.6 |
| SURE REACH TOGETHER | 28 | 25 | 3 | 0.08 | +2 | +0.8 |
| WHOLE FIGHT | 28 | 27 | 3 | 0.08 | +0 | +0.0 |
| BEST PRIZE | 2 | 2 | 2 | 0.06 | -182 | -91.0 |
| FIRE AND FLEE | 2 | 2 | 2 | 0.06 | +35 | +17.3 |
| FOCUS FIRE | 2 | 2 | 2 | 0.06 | +45 | +22.4 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| LONG SHOT | 26 | 26 | 2 | 0.06 | +9 | +4.6 |
| NO RALLY LEFT | 2 | 2 | 2 | 0.06 | +10 | +5.1 |
| PERIAPT WORTH | 2 | 2 | 2 | 0.06 | +248 | +123.9 |
| REDIRECT BY WHAT IT STOPS | 17 | 17 | 2 | 0.06 | +92 | +46.2 |
| BOMBING RUN | 1 | 1 | 1 | 0.03 | +45 | +45.1 |
| BOUND ASSAILMENT | 1 | 1 | 1 | 0.03 | +0 | +0.1 |
| CARRIES OUT COUNTER | 2 | 2 | 1 | 0.03 | -85 | -85.2 |
| CARRIES OUT SET-UP | 4 | 4 | 1 | 0.03 | -90 | -90.3 |
| CONTINUE AHEAD WEIGHED | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| GIVES UP | 49 | 47 | 1 | 0.03 | +23 | +23.3 |
| HORN WORTH | 1 | 1 | 1 | 0.03 | +5 | +5.0 |
| JOINT CHARGE PLAN | 7 | 7 | 1 | 0.03 | +17 | +16.6 |
| KEEPS ITS PREY | 6 | 6 | 1 | 0.03 | +32 | +32.3 |
| MOVE SPELL IN RANGE | 5 | 5 | 1 | 0.03 | +0 | +0.0 |
| OPENS A LANE | 18 | 2 | 1 | 0.03 | +1 | +1.2 |
| RAIDS THE BAGGAGE | 1 | 1 | 1 | 0.03 | +202 | +202.1 |
| RAIDS THE BAGGAGE NEXT TURN | 2 | 2 | 1 | 0.03 | +31 | +30.9 |
| SAFE SURE CHARGE | 1 | 1 | 1 | 0.03 | -3 | -3.2 |
| STAY WEIGHED | 1 | 1 | 1 | 0.03 | +48 | +48.5 |
| SUPPORT JOB KEPT | 1 | 1 | 1 | 0.03 | +145 | +145.4 |
| TURN WORTH | 34 | 34 | 1 | 0.03 | +1 | +1.1 |
| ALREADY CARRIED | 1 | not checked | - | - | - | - |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 38 | 38 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 32 | trace | - | - | - | - |
| CATCH FLIERS | 3 | not checked | - | - | - | - |
| CHAMPION TAKES THE CHALLENGE | 1 | not checked | - | - | - | - |
| CHARIOT WIZARD CAREFUL | 5 | 5 | 0 | 0.00 | - | - |
| CHEAP HELPER | 9 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 32 | not checked | - | - | - | - |
| DEFENSIVE ARMY | 2 | 2 | 0 | 0.00 | - | - |
| DEFENSIVE FLOOR | 2 | 2 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 2 | 2 | 0 | 0.00 | - | - |
| FIGHT LIFT | 6 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 379 | not checked | - | - | - | - |
| GIVES UP ITS SCREEN | 23 | 22 | 0 | 0.00 | - | - |
| GROUND FLIERS | 1 | not checked | - | - | - | - |
| HELPER ALREADY ASKED | 2 | not checked | - | - | - | - |
| HELPER UNSEEN | 20 | 18 | 0 | 0.00 | - | - |
| HILL BY ITS CHANCE | 4 | 4 | 0 | 0.00 | - | - |
| HUNT DROPPED | 4 | trace | - | - | - | - |
| HUNT KEPT | 5 | trace | - | - | - | - |
| HUNT RESULT | 14 | trace | - | - | - | - |
| HUNT THE GUNS | 17 | trace | - | - | - | - |
| LONE CHARACTER SAFE SPOT | 36 | not checked | - | - | - | - |
| LONE WIZARD HOLDS BACK | 11 | 11 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 26 | 26 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 8 | 8 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 22 | trace | - | - | - | - |
| MOVE SPELL SPOT | 16 | not checked | - | - | - | - |
| NOT NEEDED | 21 | 21 | 0 | 0.00 | - | - |
| NOT TURNED | 395 | 395 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 46 | not checked | - | - | - | - |
| PLAN RESULT | 2678 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 14 | 14 | 0 | 0.00 | - | - |
| SCOUT SPOT | 23 | 23 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 4 | 4 | 0 | 0.00 | - | - |
| SECOND HUNTER | 2 | 2 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 20 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 14 | not checked | - | - | - | - |
| SET-UP MISSED | 2 | trace | - | - | - | - |
| SPELL CATCH ODDS | 3 | not checked | - | - | - | - |
| SPELL SETS UP CHARGE | 21 | not checked | - | - | - | - |
| SPELL WORTH | 95 | not checked | - | - | - | - |
| STABLE ROLE | 396 | 393 | 0 | 0.00 | - | - |
| STOPS | 10 | 10 | 0 | 0.00 | - | - |
| TWO OR MORE ARRIVE | 17 | 17 | 0 | 0.00 | - | - |
| WAR ENGINE CHARGES | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: fw-h2h2-opp-1eea44e-p1

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 15.14 | 12.58 | 56.1 |
| FALLBACK | gate | 0.94 | 0.89 | 53.8 |
| TURN GATE | gate | 0.56 | 0.47 | 73.6 |
| RULE SWITCHED OFF | gate | 0.78 | - | 11.5 |
| CHARGE NOW FIRST | rule | - | 0.72 | 57.8 |
| LONE CHARACTER SAFE SPOT | gate | 0.19 | 0.28 | 52.0 |
| CHARIOT NO STATIC JOB | rule | 0.42 | - | 149.5 |
| SUPPORT REQUEST | gate | 0.14 | 0.25 | 141.7 |
| PIVOT GUARDS FLANK | rule | 0.08 | 0.25 | 14.8 |
| SURE CHARGE BEATS ADVANCE | rule | 0.17 | 0.14 | 52.3 |
| PATHS CROSS | rule | 0.11 | 0.11 | 77.7 |
| WAR ENGINE JOBS | rule | - | 0.22 | 51.2 |
| AFTERMATH BAND | gate | 0.06 | 0.14 | 2.3 |
| FIGHT ORDER BAND | gate | 0.11 | 0.08 | 1.7 |
| PURSUES BIG PREY | rule | 0.03 | 0.17 | 96.8 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.06 | 0.08 | 60.6 |
| CANNON PLANNED TARGET | rule | 0.14 | - | 42.9 |
| SUPPORT NARROWED | rule | - | 0.14 | 9.2 |
| BLOCKED WHEEL | rule | - | 0.11 | 21.9 |
| CHAFF PASSED | rule | 0.11 | - | 5.4 |
| CHARGE NOW WEIGHED | rule | 0.06 | 0.06 | 35.9 |
| BIG CHARACTER SAFETY | rule | 0.06 | 0.03 | 5.5 |
| BEST PRIZE | rule | - | 0.06 | 91.0 |
| NO REASON | gate | - | 0.06 | 91.0 |
| SAFER THAN THE JOB | rule | 0.03 | 0.03 | 3.6 |
| CARRIES OUT COUNTER | rule | - | 0.03 | 85.2 |
| CARRIES OUT SET-UP | rule | - | 0.03 | 90.3 |
| MARCH ODDS | rule | - | 0.03 | 29.9 |
| SAFE SURE CHARGE | rule | 0.03 | - | 3.2 |
| STANDS TO CAST | rule | - | 0.03 | 7.3 |
| STOPS SHORT OF THE FLANK | rule | 0.03 | - | 9.2 |
| THROUGH LINE OF FIRE | rule | 0.03 | - | 18.2 |
| WHO HITS BACK | rule | - | 0.03 | 2.3 |

### Plans: fw-h2h2-opp-1eea44e-p1

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 10.5 | 22% | 435 | 359 | 83% |
| Mine | charge | 3.1 | 50% | 390 | 256 | 66% |
| Mine | close in | 4.7 | 27% | 345 | 180 | 52% |
| Mine | hold | 3.9 | 45% | 242 | 0 | 0% |
| Mine | join | 0.6 | 96% | 13 | 0 | 0% |
| Mine | shoot | 8.8 | 70% | 361 | 722 | 200% |
| Mine | support | 4.8 | 88% | 228 | 0 | 0% |
| Opponent | advance | 12.7 | 18% | 429 | 370 | 86% |
| Opponent | charge | 5.2 | 57% | 628 | 470 | 75% |
| Opponent | close in | 5.5 | 28% | 378 | 187 | 49% |
| Opponent | hold | 3.7 | 38% | 264 | 0 | 0% |
| Opponent | join | 1.2 | 93% | 72 | 0 | 0% |
| Opponent | shoot | 3.8 | 69% | 91 | 293 | 320% |
| Opponent | support | 5.9 | 91% | 56 | 0 | 0% |

### Packages: hunt the guns, fw-h2h2-opp-1eea44e-p1

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.1 | 4 | 2 | 50% | 50% | 0% | 4.0 | 266 | 100 | 50% | 12 |
| Opponent | 0.4 | 13 | 1 | 17% | 17% | 0% | 2.0 | 290 | 34 | 17% | 132 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 318 | 0 | 0% | 0 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 46 |
| Dwarfen Mountain Holds | 0.4 | 2 | 2 | - | - | - | - | - | - | - | 59 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 88 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 87 |
| High Elf Realms | 0.2 | 1 | 0 | 100% | 100% | 0% | 4.0 | 214 | 200 | 100% | 104 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 290 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Orc & Goblin Tribes | 0.7 | 2 | 0 | 50% | 50% | 0% | 2.0 | 146 | 90 | 50% | 18 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 72 |
| Tomb Kings of Khemri | 0.5 | 3 | 0 | 0% | 0% | 0% | - | 275 | 0 | 0% | 88 |
| Vampire Counts | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Warriors of Chaos | 0.5 | 4 | 0 | 25% | 25% | 0% | 2.0 | 371 | 58 | 25% | 168 |
| Wood Elf Realms | 0.7 | 4 | 1 | 0% | 0% | 0% | - | 295 | 0 | 0% | 64 |

### Battle groups: fw-h2h2-opp-1eea44e-p1

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 8.7 | 28% | 52% | 10% | 56% | 42% | 12% | 13% | 34% | 0% |
| Mine | REDIRECT COUNTER | 3.6 | 39% | 64% | 4% | 0% | 23% | 2% | 8% | 60% | 6% |
| Opponent | COUNTER-CHARGE COVER | 6.6 | 22% | 63% | 15% | 38% | 48% | 9% | 11% | 32% | 0% |
| Opponent | REDIRECT COUNTER | 4.1 | 20% | 67% | 13% | 25% | 23% | 0% | 8% | 62% | 8% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: fw-h2h2-opp-1eea44e-p1

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 3 | 0 (3) | 0 | 0 | 19 | 100% | - | 0 (1) | 0 (1) | - | - | 0 (2) |
| Mine | Chaff | 41 | 43 (41) | 22 | 21 | 50 | 37% | 2.6 | 53 (17) | 48 (8) | 31 (16) | 54 (27) | 25 (14) |
| Mine | Character | 124 | 66 (124) | 66 | 0 | 43 | 10% | 2.4 | 86 (30) | 73 (55) | 50 (11) | 66 (56) | 85 (40) |
| Mine | Clean-up | 24 | 51 (24) | 21 | 30 | 57 | 12% | 3.4 | 48 (11) | 61 (8) | 29 (5) | 63 (13) | 36 (11) |
| Mine | Fast | 1 | 0 (1) | 0 | 0 | 100 | 0% | 3.0 | - | 0 (1) | - | - | 0 (1) |
| Mine | Fast Hammer | 40 | 37 (40) | 22 | 15 | 54 | 15% | 3.1 | 43 (19) | 29 (6) | 32 (15) | 45 (29) | 20 (11) |
| Mine | Fragile | 5 | 0 (5) | 0 | 0 | 60 | 20% | 1.8 | - | 0 (5) | - | 0 (1) | 0 (4) |
| Mine | Hammer | 56 | 36 (56) | 22 | 13 | 52 | 14% | 2.5 | 34 (12) | 35 (35) | 40 (9) | 43 (35) | 26 (21) |
| Mine | Holder | 26 | 77 (26) | 1 | 76 | 53 | 46% | 2.9 | 98 (6) | 80 (12) | 69 (6) | 105 (11) | 63 (13) |
| Mine | Shooter | 45 | 74 (45) | 24 | 50 | 54 | 2% | 1.7 | 34 (8) | 93 (30) | 53 (7) | 91 (26) | 51 (19) |
| Mine | Support | 5 | 0 (5) | 0 | 0 | 84 | 20% | 2.8 | - | 0 (2) | - | - | 0 (2) |
| Mine | War machine | 56 | 72 (56) | 72 | 0 | 31 | 4% | 1.3 | 102 (14) | 69 (38) | 0 (4) | 72 (10) | 72 (46) |
| Mine | Wizard | 22 | 52 (22) | 52 | 0 | 56 | 9% | 2.7 | 119 (7) | 45 (5) | 0 (2) | 178 (3) | 35 (11) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 0% | 5.0 | - | 0 (1) | - | 0 (1) | - |
| Opponent | Chaff | 78 | 68 (78) | 44 | 24 | 49 | 36% | 3.0 | 53 (31) | 9 (22) | 143 (25) | 96 (53) | 7 (25) |
| Opponent | Character | 113 | 63 (113) | 63 | 0 | 44 | 19% | 2.4 | 108 (31) | 50 (54) | 46 (9) | 69 (63) | 79 (31) |
| Opponent | Clean-up | 11 | 14 (11) | 5 | 9 | 72 | 55% | 3.0 | 0 (3) | 16 (6) | 30 (2) | 21 (7) | 0 (4) |
| Opponent | Early | 1 | 0 (1) | 0 | 0 | 0 | 0% | 5.0 | - | 0 (1) | - | 0 (1) | - |
| Opponent | Fast Hammer | 54 | 70 (54) | 48 | 22 | 51 | 20% | 2.6 | 69 (19) | 38 (21) | 123 (14) | 62 (40) | 98 (14) |
| Opponent | Fragile | 9 | 27 (9) | 27 | 0 | 57 | 44% | 1.8 | 0 (3) | 0 (4) | 104 (2) | 33 (7) | 0 (2) |
| Opponent | Hammer | 63 | 42 (63) | 34 | 8 | 53 | 17% | 2.7 | 30 (15) | 46 (40) | 39 (8) | 29 (38) | 65 (25) |
| Opponent | Holder | 37 | 71 (37) | 15 | 57 | 24 | 43% | 3.5 | 53 (10) | 111 (14) | 34 (13) | 91 (22) | 42 (15) |
| Opponent | Shooter | 32 | 48 (32) | 6 | 42 | 52 | 3% | 1.4 | 70 (9) | 47 (17) | 20 (6) | 58 (16) | 37 (16) |
| Opponent | Support | 2 | 0 (2) | 0 | 0 | 0 | 50% | 6.0 | 0 (1) | 0 (1) | - | - | 0 (2) |
| Opponent | War machine | 13 | 30 (13) | 30 | 0 | 36 | 23% | 1.2 | 49 (3) | 34 (7) | 0 (3) | 0 (2) | 35 (11) |
| Opponent | Wizard | 24 | 23 (24) | 23 | 0 | 43 | 4% | 2.2 | 30 (7) | 53 (5) | 0 (4) | 45 (8) | 11 (8) |

### Charged fights: fw-h2h2-opp-1eea44e-p1

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 5 | 264 | 70 | 1.4 | 1.3 | 50 | 44 | +6 | 1 of 7 | 2 of 7 | -68 | +36 |
| Mine | Chaos Dwarfs | 3 | 85 | 414 | 4.0 | 1.3 | 103 | 52 | +52 | 6 of 12 | 6 of 12 | +136 | +24 |
| Mine | Dwarfen Mountain Holds | 4 | 668 | 182 | 1.5 | 1.2 | 121 | 10 | +111 | 1 of 6 | 4 of 6 | +165 | +100 |
| Mine | Empire of Man | 5 | 461 | 107 | 1.6 | 1.1 | 67 | 88 | -21 | 2 of 8 | 4 of 8 | +0 | -24 |
| Mine | Grand Cathay | 4 | 762 | 286 | 3.2 | 1.2 | 88 | 0 | +88 | 7 of 13 | 9 of 13 | +72 | +91 |
| Mine | High Elf Realms | 4 | 113 | 486 | 4.5 | 1.3 | 108 | 42 | +66 | 10 of 18 | 9 of 18 | +181 | +23 |
| Mine | Kingdom of Bretonnia | 1 | 0 | 1107 | 6.0 | 1.3 | 184 | 0 | +184 | 4 of 6 | 4 of 5 | +204 | +175 |
| Mine | Lizardmen | 1 | 195 | 475 | 5.0 | 1.0 | 95 | 43 | +52 | 2 of 5 | 2 of 5 | - | +52 |
| Mine | Ogre Kingdoms | 1 | 70 | 0 | 2.0 | 1.0 | 0 | 17 | -17 | 0 of 2 | 2 of 2 | - | -17 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 345 | 5.0 | 1.0 | 69 | 22 | +47 | 2 of 5 | 4 of 5 | - | +47 |
| Mine | Skaven | 2 | 22 | 0 | 0.5 | 2.0 | 0 | 65 | -65 | 1 of 1 | 1 of 1 | -65 | - |
| Mine | Tomb Kings of Khemri | 2 | 121 | 1022 | 4.5 | 1.0 | 227 | 43 | +184 | 4 of 9 | 5 of 9 | - | +184 |
| Mine | Vampire Counts | 2 | 0 | 278 | 6.0 | 1.1 | 46 | 45 | +1 | 6 of 12 | 6 of 12 | +99 | -7 |
| Mine | Warriors of Chaos | 1 | 0 | 305 | 4.0 | 1.0 | 76 | 0 | +76 | 0 of 4 | 4 of 4 | - | +76 |
| **Mine** | all armies | 36 | 294 | 299 | 3.0 | 1.2 | 100 | 35 | +65 | 46 of 108 | 62 of 107 | +107 | +56 |
| Opponent | Beastmen Brayherds | 1 | 322 | 0 | 4.0 | 1.5 | 0 | 64 | -64 | 3 of 4 | 1 of 4 | +0 | -128 |
| Opponent | Dwarfen Mountain Holds | 1 | 139 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Empire of Man | 1 | 250 | 289 | 1.0 | 1.0 | 289 | 0 | +289 | 1 of 1 | 1 of 1 | - | +289 |
| Opponent | Grand Cathay | 1 | 395 | 894 | 5.0 | 1.2 | 179 | 0 | +179 | 4 of 5 | 4 of 5 | +0 | +224 |
| Opponent | High Elf Realms | 2 | 62 | 954 | 4.0 | 1.0 | 239 | 22 | +216 | 2 of 8 | 4 of 8 | - | +216 |
| Opponent | Lizardmen | 1 | 281 | 646 | 4.0 | 1.0 | 162 | 0 | +162 | 2 of 4 | 2 of 4 | - | +162 |
| Opponent | Ogre Kingdoms | 2 | 42 | 86 | 4.5 | 1.3 | 19 | 33 | -14 | 3 of 9 | 5 of 9 | +32 | -28 |
| Opponent | Orc & Goblin Tribes | 2 | 0 | 1030 | 5.5 | 1.1 | 187 | 78 | +109 | 6 of 11 | 5 of 11 | +376 | +82 |
| Opponent | Skaven | 2 | 68 | 119 | 3.0 | 1.0 | 40 | 118 | -78 | 2 of 6 | 2 of 6 | - | -78 |
| Opponent | Tomb Kings of Khemri | 4 | 8 | 819 | 5.5 | 1.2 | 149 | 60 | +89 | 7 of 22 | 13 of 22 | +306 | +41 |
| Opponent | Vampire Counts | 6 | 192 | 378 | 4.5 | 1.1 | 84 | 2 | +82 | 11 of 27 | 16 of 27 | +70 | +84 |
| Opponent | Warriors of Chaos | 7 | 0 | 676 | 3.9 | 1.1 | 175 | 53 | +123 | 12 of 27 | 18 of 27 | -104 | +162 |
| Opponent | Wood Elf Realms | 6 | 145 | 425 | 4.3 | 1.2 | 98 | 17 | +81 | 7 of 26 | 13 of 26 | +72 | +83 |
| **Opponent** | all armies | 36 | 105 | 529 | 4.2 | 1.2 | 127 | 37 | +90 | 60 of 150 | 84 of 150 | +83 | +91 |

### Effective charges: fw-h2h2-opp-1eea44e-p1

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 7 | 1 (net -85) | 1 (net +0) | 0 | 1 (net -52) | 0 | 4 (net +44) | 0 | 0% (0 of 7) |
| Mine | Chaos Dwarfs | 12 | 2 (net +312) | 0 | 2 (net +0) | 2 (net +134) | 1 (net +0) | 4 (net -67) | 1 | 18% (2 of 11) |
| Mine | Dwarfen Mountain Holds | 6 | 0 | 0 | 2 (net +52) | 1 (net +41) | 1 (net +50) | 2 (net +235) | 0 | 33% (2 of 6) |
| Mine | Empire of Man | 8 | 2 (net +10) | 0 | 1 (net -227) | 0 | 2 (net +12) | 2 (net +128) | 1 | 14% (1 of 7) |
| Mine | Grand Cathay | 13 | 2 (net +0) | 0 | 1 (net +0) | 4 (net +134) | 4 (net +61) | 2 (net +181) | 0 | 8% (1 of 13) |
| Mine | High Elf Realms | 18 | 3 (net +52) | 0 | 3 (net -249) | 4 (net +208) | 3 (net +175) | 3 (net +110) | 2 | 19% (3 of 16) |
| Mine | Kingdom of Bretonnia | 6 | 1 (net +0) | 0 | 0 | 1 (net +580) | 2 (net +136) | 2 (net +127) | 0 | 0% (0 of 6) |
| Mine | Lizardmen | 5 | 0 | 0 | 1 (net +90) | 0 | 0 | 0 | 4 | 100% (1 of 1) |
| Mine | Ogre Kingdoms | 2 | 0 | 0 | 0 | 0 | 0 | 1 (net +0) | 1 | 0% (0 of 1) |
| Mine | Orc & Goblin Tribes | 5 | 0 | 0 | 0 | 0 | 1 (net +0) | 1 (net +275) | 3 | 0% (0 of 2) |
| Mine | Skaven | 1 | 0 | 0 | 1 (net -65) | 0 | 0 | 0 | 0 | 100% (1 of 1) |
| Mine | Tomb Kings of Khemri | 9 | 1 (net +0) | 0 | 2 (net +376) | 1 (net +125) | 0 | 5 (net +155) | 0 | 22% (2 of 9) |
| Mine | Vampire Counts | 12 | 5 (net +26) | 1 (net +0) | 1 (net +0) | 1 (net +0) | 1 (net +99) | 3 (net -70) | 0 | 8% (1 of 12) |
| Mine | Warriors of Chaos | 4 | 0 | 0 | 0 | 2 (net +46) | 1 (net +107) | 1 (net +107) | 0 | 0% (0 of 4) |
| Opponent | Beastmen Brayherds | 4 | 1 (net +0) | 0 | 1 (net +0) | 0 | 0 | 2 (net -128) | 0 | 25% (1 of 4) |
| Opponent | Empire of Man | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +289) | 0 | 0% (0 of 1) |
| Opponent | Grand Cathay | 5 | 3 (net +236) | 0 | 0 | 1 (net +186) | 0 | 1 (net +0) | 0 | 0% (0 of 5) |
| Opponent | High Elf Realms | 8 | 2 (net +466) | 0 | 1 (net +0) | 1 (net +0) | 1 (net +150) | 1 (net +125) | 2 | 17% (1 of 6) |
| Opponent | Lizardmen | 4 | 1 (net +380) | 0 | 0 | 1 (net +189) | 0 | 0 | 2 | 0% (0 of 2) |
| Opponent | Ogre Kingdoms | 9 | 0 | 0 | 1 (net +52) | 1 (net -301) | 1 (net +65) | 4 (net +14) | 2 | 14% (1 of 7) |
| Opponent | Orc & Goblin Tribes | 11 | 0 | 0 | 0 | 1 (net +376) | 0 | 2 (net +37) | 8 | 0% (0 of 3) |
| Opponent | Skaven | 6 | 2 (net -214) | 1 (net -55) | 0 | 2 (net +63) | 0 | 1 (net -112) | 0 | 0% (0 of 6) |
| Opponent | Tomb Kings of Khemri | 22 | 2 (net -284) | 1 (net +0) | 4 (net +252) | 5 (net +144) | 1 (net -540) | 8 (net +163) | 1 | 19% (4 of 21) |
| Opponent | Vampire Counts | 27 | 5 (net +127) | 0 | 5 (net +99) | 5 (net +49) | 3 (net +44) | 8 (net +22) | 1 | 19% (5 of 26) |
| Opponent | Warriors of Chaos | 27 | 2 (net +244) | 1 (net +125) | 0 | 8 (net +210) | 0 | 10 (net +92) | 6 | 0% (0 of 21) |
| Opponent | Wood Elf Realms | 26 | 3 (net +112) | 1 (net +70) | 1 (net +465) | 6 (net +40) | 5 (net +96) | 7 (net +88) | 3 | 4% (1 of 23) |

### Charged fights, damage counted: fw-h2h2-opp-1eea44e-p1

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 17 | 294 | 305 | +50 | 114 | 72 | +42 | +14.2 |
| Mine | 50-54% | 2 | 136 | 212 | +0 | 0 | 0 | +0 | +0.0 |
| Mine | Effective (55-75%) | 14 | 275 | 240 | -7 | 100 | 111 | -11 | -4.0 |
| Mine | 76-89% | 17 | 290 | 227 | +142 | 182 | 31 | +150 | +51.9 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 30 | 210 | 175 | +84 | 131 | 37 | +94 | +45.0 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 16 | 457 | 100 | +83 | 99 | 16 | +83 | +18.3 |
| Mine | No odds | 12 | 275 | 215 | -3 | 61 | 50 | +11 | +4.0 |
| Mine | All fights | 108 | 287 | 206 | +65 | 117 | 49 | +69 | +23.9 |
| Opponent | Long shot (under 50%) | 21 | 284 | 298 | +118 | 205 | 107 | +98 | +34.7 |
| Opponent | 50-54% | 4 | 261 | 227 | +35 | 49 | 14 | +35 | +13.4 |
| Opponent | Effective (55-75%) | 13 | 274 | 190 | +155 | 168 | 32 | +135 | +49.4 |
| Opponent | 76-89% | 31 | 230 | 169 | +112 | 160 | 45 | +114 | +49.8 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 45 | 252 | 190 | +71 | 134 | 50 | +85 | +33.7 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 11 | 411 | 84 | +26 | 94 | 52 | +42 | +10.3 |
| Opponent | No odds | 25 | 232 | 193 | +77 | 127 | 35 | +92 | +39.7 |
| Opponent | All fights | 150 | 262 | 195 | +90 | 146 | 52 | +94 | +35.8 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| fw-h2h2-opp-1eea44e-p1 | move | 446 | 102 (23%) | 77 (17%) | 61 (14%) | 283 (63%) |
| fw-h2h2-opp-1eea44e-p1 | objective | 372 | 51 (14%) | 38 (10%) | 58 (16%) | 263 (71%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0102, L0118, L0135, L2531, L2730 |
| Charmed Shield | Opponent | L0524, L1224, L1527, L1625, L2025, L2127, L2934 |
| Clockwork Compass | Mine | L1224 |
| Clockwork Compass | Opponent | L0612 |
| Elixir of Power | Mine | L1114, L1131, L1923 |
| Elixir of Power | Opponent | L0319, L1319 |
| Fistful of Laurels | Mine | L1823 |
| Fistful of Laurels | Opponent | L0118, L0218 |
| Horn of the Wild Hunt | Opponent | L0733 |
| Invocation of Nehek | Mine | L2531, L2730 |
| Invocation of Nehek | Opponent | L0524, L1224, L1527, L1625, L2025, L2127 |
| Opal Amulet | Mine | L1431 |
| Opal Amulet | Opponent | L1114 |
| Periapt of Soul Exchange | Mine | L2025, L2127 |
| Periapt of Soul Exchange | Opponent | L0421, L1021 |
| Ring of Doom | Mine | L0218, L0235, L1114, L1131, L1224, L1527 |
| Ring of Doom | Opponent | L0102, L0612, L0733, L1131, L1431, L2231, L2531 |
| Ring of Jet | Mine | L1021, L1114, L1131, L1224 |
| Ring of Jet | Opponent | L0612 |
| Standard of the Fell Warrior | Mine | L1319, L1335 |
| Standard of the Fell Warrior | Opponent | L0913 |
| Storm Daemon (Renegade 2.0) | Mine | L2127 |
| Storm Daemon (Renegade 2.0) | Opponent | L0421, L1021 |
| Twice-Blessed Armour | Mine | L0717, L0733, L1021 |
| Witch Hunter's Ward | Mine | L0717, L0733, L0823 |
| Witch Hunter's Ward | Opponent | L0508 |

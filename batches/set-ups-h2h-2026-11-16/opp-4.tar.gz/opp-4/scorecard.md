# Doctrine scorecard: su-h2h-opp-e45904b-p4

### Scorecard: su-h2h-opp-e45904b-p4

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0114 | 6 | 1 | Mine | no | 12 | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| L0114 | 6 | 1 | Opponent | no | 0 | 1 | 6 | 1 | 0 | 0 | 0 | 0 |
| L0130 | 4 | 1 | Mine | yes | 2 | - | 0 | 2 | 1 | 0 | 0 | 0 |
| L0130 | 4 | 1 | Opponent | no | 0 | 1 | 4 | 3 | 1 | 0 | 0 | 0 |
| L0214 | 4 | 1 | Mine | no | 0 | 3 | 2 | 2 | 0 | 0 | 0 | 170 |
| L0214 | 4 | 1 | Opponent | no | 0 | 1 | 1 | 0 | 1 | 0 | 0 | 0 |
| L0230 | 2 | 1 | Mine | - | - | 1 | 3 | 4 | 1 | 0 | 0 | 170 |
| L0230 | 2 | 1 | Opponent | - | - | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| L0315 | 3 | 1 | Mine | no | 0 | - | 1 | 0 | 0 | 0 | 0 | 590 |
| L0315 | 3 | 1 | Opponent | yes | 4 | 2 | 0 | 0 | 2 | 0 | 0 | 0 |
| L0332 | 2 | 1 | Mine | - | - | 3 | 3 | 1 | 1 | 0 | 0 | 360 |
| L0332 | 2 | 1 | Opponent | - | - | 2 | 3 | 2 | 1 | 0 | 0 | 0 |
| L0417 | 3 | 1 | Mine | yes | 6 | 2 | 5 | 1 | 0 | 0 | 0 | 0 |
| L0417 | 3 | 1 | Opponent | yes | 6 | 2 | 6 | 0 | 1 | 0 | 0 | 98 |
| L0434 | 2 | 1 | Mine | - | - | 3 | 2 | 1 | 1 | 0 | 0 | 0 |
| L0434 | 2 | 1 | Opponent | - | - | 1 | 2 | 0 | 0 | 0 | 0 | 0 |
| L0520 | 4 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 1416 |
| L0520 | 4 | 1 | Opponent | no | 0 | - | 1 | 4 | 1 | 0 | 0 | 210 |
| L0608 | 2 | 1 | Mine | - | - | - | 0 | 3 | 1 | 0 | 0 | 801 |
| L0608 | 2 | 1 | Opponent | - | - | - | 0 | 2 | 0 | 0 | 0 | 605 |
| L0624 | 6 | 1 | Mine | no | 0 | 2 | 4 | 0 | 0 | 0 | 0 | 801 |
| L0624 | 6 | 1 | Opponent | no | 6 | 2 | 3 | 0 | 0 | 0 | 0 | 0 |
| L0713 | 5 | 1 | Mine | yes | - | 1 | 3 | 2 | 0 | 0 | 0 | 420 |
| L0713 | 5 | 1 | Opponent | yes | - | 4 | 0 | 0 | 1 | 0 | 0 | 317 |
| L0729 | 3 | 1 | Mine | no | 2 | 3 | 0 | 0 | 0 | 0 | 0 | 375 |
| L0729 | 3 | 1 | Opponent | no | 1 | 2 | 4 | 1 | 1 | 0 | 0 | 170 |
| L0819 | 3 | 1 | Mine | no | 0 | 4 | 1 | 0 | 0 | 0 | 0 | 1064 |
| L0819 | 3 | 1 | Opponent | no | 0 | 2 | 3 | 3 | 1 | 0 | 0 | 0 |
| L0835 | 1 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 515 |
| L0835 | 1 | 1 | Opponent | no | 0 | 2 | 3 | 3 | 0 | 0 | 0 | 388 |
| L0926 | 2 | 1 | Mine | - | - | 2 | 1 | 2 | 0 | 0 | 0 | 597 |
| L0926 | 2 | 1 | Opponent | - | - | 2 | 7 | 4 | 0 | 0 | 0 | 0 |
| L1017 | 3 | 1 | Mine | no | 0 | 2 | 3 | 0 | 0 | 0 | 0 | 330 |
| L1017 | 3 | 1 | Opponent | yes | 5 | 5 | 1 | 0 | 2 | 0 | 0 | 175 |
| L1034 | 2 | 1 | Mine | - | - | 2 | 1 | 1 | 1 | 0 | 0 | 330 |
| L1034 | 2 | 1 | Opponent | - | - | 3 | 3 | 7 | 1 | 0 | 0 | 527 |
| **Average** | | | Mine | 25% | 2.0 | 2.3 | 1.7 | 1.2 | 0.3 | 0.0 | 0.0 | 441.1 |
| **Average** | | | Opponent | 33% | 2.0 | 2.1 | 2.7 | 1.7 | 0.7 | 0.0 | 0.0 | 138.3 |

### KPIs: su-h2h-opp-e45904b-p4

Rules off - Mine only: SET-UP SPOT, CARRIES OUT CLOSE-IN, JOINT AS ONE.

Morten 2026-11-10; 18 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 49% (37 of 75) | 0% (0 of 88) | 23% (37 of 163) |
| Winner chose to follow up after the loser gave ground |  | 97% (31 of 32); on the table 97% | 100% (30 of 30); on the table 100% | 98% (61 of 62); on the table 98% |
| Winner chose to pursue after the loser fell back in good order |  | 75% (9 of 12); on the table 75% | 100% (7 of 7); on the table 100% | 84% (16 of 19); on the table 84% |
| Winner chose to pursue after the loser fled |  | 79% (11 of 14); on the table 79% | 67% (10 of 15); on the table 73% | 72% (21 of 29); on the table 76% |
| Winner chose to follow up or pursue (all three) |  | 88% (51 of 58); on the table 88% | 90% (47 of 52); on the table 92% | 89% (98 of 110); on the table 90% |
| Magic missiles tried each own turn | 50%+ | 43% (83 of 192) | 17% (9 of 54) | 37% (92 of 246) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 56% (77 of 137) | 28% (9 of 32) | 51% (86 of 169) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 57% (4 of 7) | 54% (13 of 24) | 55% (17 of 31) |
| Points that never fought | lower | 36% (12864 of 35589) | 38% (13525 of 35991) | 37% (26389 of 71580) |
|   infantry points that never fought | lower | 37% (3356 of 8978) | 57% (4017 of 6996) | 46% (7373 of 15974) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 54% (83 of 153) | 54% (75 of 139) | 54% (158 of 292) |
| Bound items with a magic missile used (at least once a game) |  | 90% (9 of 10); 1.7 uses a game | 100% (4 of 4); 0.9 uses a game | 93% (13 of 14); 1.3 uses a game |
| Bound items with another spell used |  | 67% (4 of 6); 0.6 uses a game | 71% (10 of 14); 0.9 uses a game | 70% (14 of 20); 0.8 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 64% (9 of 14); 0.5 uses a game | 86% (6 of 7); 0.3 uses a game | 71% (15 of 21); 0.4 uses a game |
|   their share of the points of units over 100 pts | lower | 50% (14862 of 29510) | 47% (15063 of 32388) | 48% (29925 of 61898) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.7 (28%) | 0.2 (9%) | 1.9 (22%) |
| MARCHED: its unit marched | 1.1 (18%) | 0.4 (16%) | 1.5 (18%) |
| CHARGED: its unit charged | 0.6 (9%) | 0.0 (0%) | 0.6 (6%) |
| IN COMBAT: engaged in combat | 1.6 (27%) | 0.5 (20%) | 2.1 (25%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.7 (27%) | 0.7 (8%) |
| FLEEING: fleeing | 0.1 (2%) | 0.1 (2%) | 0.2 (2%) |
| GONE: slain | 0.8 (13%) | 0.5 (20%) | 1.3 (15%) |
| OFF THE TABLE: off the table or not arrived | 0.2 (4%) | 0.2 (7%) | 0.4 (5%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 3.0 | 1.3 | 2.2 | 5.1 | 0.7 | 2.4 |
| not cast | 2.0 | 3.2 | 3.8 | 8.6 | 2.3 | 16.3 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.6 (10%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.6 (51%) | 0.5 (13%) | 1.9 (22%) | 0.4 (17%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.5 (18%) | 0.4 (17%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.6 (6%) | 0.1 (5%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.2 (8%) | 0.2 (7%) | 0.9 (24%) | 2.1 (25%) | 0.7 (29%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.0 (0%) | 0.3 (9%) | 0.7 (8%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (0%) | 0.2 (7%) | 0.0 (0%) | 0.2 (2%) | 0.0 (0%) | 0.6 (4%) |
| GONE: slain | 0.9 (47%) | 0.8 (26%) | 0.7 (19%) | 1.3 (15%) | 0.1 (5%) | 3.1 (19%) |
| OFF THE TABLE: off the table or not arrived | 0.2 (8%) | 0.1 (4%) | 0.1 (3%) | 0.4 (5%) | 0.0 (0%) | 0.6 (4%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.1 (4%) | 0.0 (0%) | 0.0 (0%) | 0.6 (27%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 0.7 (36%) | 0.1 (2%) | 1.2 (32%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 10.4 (64%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.8 a game | 0.5 a game | 1.2 a game |
| stood (cast and not dispelled) | 58% (19 of 33) | 57% (4 of 7) | 58% (23 of 40) |
| the unit moved after it | 89% (17 of 19) | 75% (3 of 4) | 87% (20 of 23) |
| it charged on its next turn | 16% (3 of 19) | 0% (0 of 4) | 13% (3 of 23) |
| the enemy charged it first | 32% (6 of 19) | 50% (2 of 4) | 35% (8 of 23) |
| it fought by the end of its next turn | 21% (4 of 19) | 50% (2 of 4) | 26% (6 of 23) |
| it moved out of a charge the enemy had planned (not charged first) | 11% (2 of 19) | 25% (1 of 4) | 13% (3 of 23) |
| none of these (no charge, no fight, no charge escaped) | 47% (9 of 19) | 25% (1 of 4) | 43% (10 of 23) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 68% (343 of 508) | 54% (146 of 272) | 63% (489 of 780) |
|   cavalry | 65% (24 of 37) | 75% (41 of 55) | 71% (65 of 92) |
|   character | 89% (33 of 37) | 15% (9 of 62) | 42% (42 of 99) |
|   chariot | 36% (24 of 67) | 88% (7 of 8) | 41% (31 of 75) |
|   infantry | 47% (47 of 101) | 63% (66 of 105) | 55% (113 of 206) |
|   monster | 46% (6 of 13) | 20% (4 of 20) | 30% (10 of 33) |
|   war machine | 83% (209 of 253) | 86% (19 of 22) | 83% (228 of 275) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.1 (22%) | 1.6 (23%) | 3.7 (23%) |
| CHARGED: it charged | 0.7 (7%) | 1.6 (23%) | 2.3 (14%) |
| FLEEING: it fled or was fleeing | 0.2 (2%) | 0.2 (2%) | 0.3 (2%) |
| IN COMBAT: it fought this turn or the last | 1.4 (15%) | 0.6 (9%) | 2.0 (12%) |
| MOVED: a war machine that moved | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| NO TARGET IN RANGE | 2.1 (22%) | 1.3 (19%) | 3.4 (21%) |
| ONLY IN COMBAT: the only targets were in combat | 0.1 (1%) | 0.7 (10%) | 0.8 (5%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.6 (17%) | 0.8 (12%) | 2.4 (15%) |
| SHELTERED: the target was sheltered | 0.5 (5%) | 0.1 (1%) | 0.6 (3%) |
| STUPIDITY | 0.1 (1%) | 0.0 (0%) | 0.1 (0%) |
| OTHER BAR | 0.5 (5%) | 0.1 (2%) | 0.6 (4%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 6.3 | 1.8 | 80% | 6.4 pts | 41 pts |
| character | 2.6 | 0.7 | 80% | 6.6 pts | 17 pts |
| chariot | 1.7 | 1.0 | 65% | 15.3 pts | 26 pts |
| infantry | 9.7 | 2.7 | 79% | 8.7 pts | 85 pts |
| monster | 0.7 | 0.3 | 77% | 10.9 pts | 8 pts |
| war machine | 12.7 | 12.1 | 62% | 34.1 pts | 432 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.1 | 5.7 | 4.9 |
| Charges that made contact a game | 2.8 | 4.1 | 3.4 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.73 declared, 0.45 contact (11 units) | 1.00 declared, 0.86 contact (7 units) | 0.83 declared, 0.61 contact (18 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.67 declared, 0.67 contact (3 units) | 0.71 declared, 0.71 contact (7 units) | 0.70 declared, 0.70 contact (10 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.56 declared, 0.38 contact (113 units) | 0.63 declared, 0.44 contact (142 units) | 0.60 declared, 0.41 contact (255 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 60% (26 of 43) | 0% (0 of 9) | 100% (1 of 1) | 51% (27 of 53) |
| Character in a unit | 68% (13 of 19) | 70% (7 of 10) | - | 69% (20 of 29) |
| Character on its own | 81% (13 of 16) | 29% (4 of 14) | 27% (9 of 33) | 41% (26 of 63) |
| Chariot | 33% (1 of 3) | 67% (8 of 12) | - | 60% (9 of 15) |
| Infantry | 56% (23 of 41) | 29% (5 of 17) | 75% (3 of 4) | 50% (31 of 62) |
| Monster | 64% (9 of 14) | 50% (2 of 4) | - | 61% (11 of 18) |
| Monstrous | 100% (7 of 7) | 75% (3 of 4) | - | 91% (10 of 11) |
| War Machines | 56% (22 of 39) | 100% (2 of 2) | - | 59% (24 of 41) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 85% (22 of 26); on the table 85% | 37% (38 of 102) | 11% | 50% (11 of 22) | 83% (5 of 6); 4.0 uses a game | 100% (2 of 2); 0.5 uses a game | 67% (4 of 6); 1.0 uses a game |
| Chaos Dwarfs | 4 | 93% (13 of 14); on the table 93% | 62% (15 of 24) | 23% | 44% (14 of 32) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
| Dwarfen Mountain Holds | 3 | 100% (5 of 5); on the table 100% | - | 50% | 63% (17 of 27) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 6 | 67% (4 of 6); on the table 67% | 56% (10 of 18) | 58% | 68% (42 of 62) | 0.0 uses a game | 100% (2 of 2); 1.5 uses a game | 80% (4 of 5); 0.7 uses a game |
| Grand Cathay | 2 | 100% (7 of 7); on the table 100% | 42% (20 of 48) | 56% | 30% (6 of 20) | 100% (4 of 4); 7.0 uses a game | 0% (0 of 2); 0.0 uses a game | 50% (1 of 2); 0.5 uses a game |
| High Elf Realms | 4 | 100% (13 of 13); on the table 100% | 17% (3 of 18) | 24% | 52% (17 of 33) | 100% (3 of 3); 2.8 uses a game | 71% (10 of 14); 4.0 uses a game | 0.0 uses a game |
| Lizardmen | 2 | 100% (8 of 8); on the table 100% | 83% (5 of 6) | 38% | 64% (9 of 14) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 1 | 100% (1 of 1); on the table 100% | 0% (0 of 12) | 21% | 12% (1 of 8) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Skaven | 1 | 100% (5 of 5); on the table 100% | 17% (1 of 6) | 63% | 43% (3 of 7) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Vampire Counts | 2 | 33% (1 of 3); on the table 67% | 0% (0 of 12) | 30% | 25% (3 of 12) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 4 | 80% (12 of 15); on the table 80% | - | 24% | 52% (14 of 27) | 0.0 uses a game | 0.0 uses a game | 100% (2 of 2); 0.5 uses a game |
| Wood Elf Realms | 3 | 100% (7 of 7); on the table 100% | - | 55% | 75% (21 of 28) | 100% (1 of 1); 1.7 uses a game | 0.0 uses a game | 100% (2 of 2); 0.7 uses a game |

Flank and rear charges a unit could have turned to face (su-h2h-opp-e45904b-p4, 18 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 50% (25) | 48% (11) | 49% (36) |
| ...free all their last turn and able to turn (per game) | 0.89 | 0.28 | 1.17 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.33 | 0.17 | 0.50 |
| ...with the charger already in that arc before they moved (per game) | 0.44 | 0.11 | 0.56 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 1.83 | 1.22 | 3.06 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 1.33 | 0.83 | 2.17 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 3.78 | 4.72 | 8.50 |

### Quality by phase: su-h2h-opp-e45904b-p4

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.0 | 3.5 |
| Strategy | Charge objectives carried out (made contact) | 50% (32 of 64) | 47% (41 of 87) |
| Strategy | Shoot objectives carried out (shot that target) | 54% (148 of 276) | 52% (45 of 87) |
| Strategy | Close-in objectives charged next turn | 14% (8 of 57) | 17% (16 of 92) |
| Strategy | Support requests answered (helper made contact too) | 73% (8 of 11) | 31% (5 of 16) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (2 of 2) | - |
| Strategy | Hexes on a unit its side charged or shot that turn | 60% (3 of 5) | 75% (3 of 4) |
| Strategy | Joined characters whose unit fought | 72% (21 of 29) | 58% (7 of 12) |
| Strategy | Lone characters that fought | 76% (37 of 49) | 71% (27 of 38) |
| Movement | Charges halted short of contact | 0.3 | 0.2 |
| Movement | Idle units | 1.2 | 1.7 |
| Movement | Points that never moved of their own | 441.1 | 138.3 |
| Movement | Fights charged into per game | 2.1 | 3.6 |
| Movement | Charges with odds: long shots (under 50%) | 5 of 37, net -72 | 12 of 60, net -53 |
| Movement | Charges with odds: sweet spot (55-75%) | 10 of 37, net +12 | 15 of 60, net +163 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 2 of 37, net +28 | 6 of 60, net +77 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 12 of 37, net +72 | 17 of 60, net +177 |
| Shooting | Shots by shooting units (incl. breath weapons) | 7.9 | 8.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 50% (71 of 143) | 39% (62 of 157) |
| Shooting | Points destroyed by shooting units | 50.7 | 13.6 |
| Shooting | War machine shots | 11.6 | 1.1 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 63% (131 of 209) | 11% (2 of 19) |
| Shooting | Points destroyed by war machines | 262.6 | 12.2 |
| Magic | Magic missiles cast | 2.8 | 0.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 45% (23 of 51) | 17% (1 of 6) |
| Magic | Wounds caused by magic missiles | 5.6 | 0.7 |
| Magic | Wounds caused by other spells | 1.3 | 1.6 |
| Magic | Points destroyed by magic (all spells) | 133.7 | 15.1 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.7 / 0.3 / 0.9 / 0.3 | 1.2 / 0.4 / 0.7 / 0.1 |
| Combat | Points destroyed in combat | 240.1 | 457.3 |
| Combat | Points run down | 48.3 | 100.9 |
| Combat | Net points per charged fight, damage counted | +39 | +87 |
| Combat | Net per 100 charger points, damage counted | +16.9 | +24.2 |
| Combat | First round won (charged fights) | 74% | 61% |
| Combat | Net points per charged fight | +30 | +102 |
| Combat | Net points per supported fight / lone fight | +80 / +13 | +67 / +107 |
| Combat | Charged fights on a top-3 enemy unit | 11 of 38 | 41 of 64 |
| Game | Points lost | 678.0 | 840.0 |
| Game | VP from objectives | 516.1 | 542.8 |
| Game | Lone holders (player turns) | 2.0 | 2.0 |

- Mine won / drew / lost: 8 / 2 / 8 of 18 ended games (of 18); mean margin (Mine - Opponent) +78 VP
- The side that went first won 9 of 16 games with a winner
- Points traded per game (both sides' losses): 1518
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: su-h2h-opp-e45904b-p4

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.6 | +0.0 | 0.0 | 0.0 | 1.1 | +0.0 | 0.0 | 0.0 |
| ALREADY CARRIED | 0.1 | +0.0 | 17.9 | 5.3 | - | - | - | - |
| ARRIVAL HUNT | - | - | - | - | 0.1 | +0.7 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 2.1 | +0.0 | 0.0 | 14.7 | 0.2 | +0.0 | 0.0 | 7.2 |
| BACKUP TARGETS | 0.7 | +6.3 | 0.0 | 0.0 | 0.6 | +9.2 | 0.0 | 0.0 |
| BEST FACING | 0.8 | +69.3 | 0.0 | 17.2 | 0.6 | +21.0 | 0.0 | 49.9 |
| BEST FIRST | 4.2 | +186.8 | 187.7 | 81.5 | 3.2 | +113.2 | 48.7 | 53.9 |
| BEST OVERALL | 0.9 | +86.5 | 0.0 | 26.4 | 0.5 | +33.5 | 0.0 | 45.3 |
| BEST PREY | 0.3 | +25.6 | 22.5 | 0.0 | 0.9 | +45.7 | 10.6 | 10.3 |
| BIG CHARACTER SAFETY | 0.1 | -0.7 | 0.0 | 0.0 | 0.3 | -1.1 | 0.0 | 0.0 |
| BLOCKED CHARGE SKIPPED | - | - | - | - | 0.1 | +0.0 | 0.0 | 0.0 |
| BLOCKED WHEEL | 0.4 | -13.3 | 0.0 | 0.0 | 0.5 | +15.1 | 0.0 | 16.5 |
| BLOWS WHERE AIMED | 0.1 | +0.5 | 22.2 | 0.0 | 0.2 | -33.0 | 47.0 | 33.3 |
| CANNON PLAN MISSED | 0.9 | +0.0 | 148.2 | 20.8 | 0.1 | +0.0 | 3.3 | 0.0 |
| CANNON PLANNED TARGET | 9.1 | +449.2 | 948.1 | 35.0 | 1.0 | +67.7 | 31.1 | 22.2 |
| CANNON SIGHT KEPT | 1.7 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 3.9 |
| CARRIES OUT CLOSE-IN | - | - | - | - | 0.7 | -8.1 | 105.7 | 49.1 |
| CARRIES OUT COUNTER | 0.1 | +0.0 | 21.4 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT SET-UP | 0.2 | +0.0 | 3.9 | 0.0 | 0.1 | +0.0 | 0.0 | 27.8 |
| CAST JOB | 1.1 | +74.7 | 167.3 | 0.0 | 0.1 | +1.5 | 0.0 | 30.0 |
| CASTER AWAY FROM SCREEN | 0.6 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CASTING BLOCK | 0.4 | +88.4 | 50.4 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | 1.0 | +0.0 | 0.0 | 29.2 | 0.2 | +0.0 | 0.0 | 22.2 |
| CASTS FROM BEHIND | - | - | - | - | 0.1 | +0.0 | 0.0 | 0.0 |
| CHAFF PASSED | 0.3 | -0.4 | 0.0 | 0.0 | 0.3 | -0.5 | 0.0 | 7.5 |
| CHARGE BAND | 0.3 | +0.0 | 20.1 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CHARGE NOW FIRST | 2.2 | +0.0 | 246.7 | 48.6 | 2.9 | +0.0 | 249.2 | 156.6 |
| CHARGE NOW WEIGHED | 0.6 | -17.8 | 13.7 | 8.7 | 0.3 | -48.7 | 9.0 | 55.8 |
| CHARGER SLAIN LOST | 0.8 | -25.4 | 47.3 | 10.9 | 0.4 | -18.2 | 11.2 | 38.3 |
| CHARIOT NO STATIC JOB | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHARIOT WIZARD CAREFUL | - | - | - | - | 0.2 | -1.0 | 0.0 | 0.0 |
| CHEAP HELPER | - | - | - | - | 0.1 | +0.0 | 0.0 | 0.0 |
| COMBAT PIVOT | 0.6 | +0.0 | 15.8 | 94.7 | 0.6 | +0.0 | 0.0 | 90.5 |
| CONTINUE AHEAD WEIGHED | - | - | - | - | 0.2 | +0.0 | 7.8 | 7.7 |
| CONVEYANCE SEARCH | 1.3 | +151.9 | 40.5 | 34.4 | 0.4 | +40.9 | 31.0 | 22.2 |
| COUNTER-CHARGE COVER | 8.7 | +709.9 | 0.0 | 106.8 | 7.3 | +523.2 | 0.0 | 199.2 |
| DEFENSIVE ARMY | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| DEFENSIVE FLOOR | 0.1 | +2.0 | 0.0 | 0.0 | - | - | - | - |
| EDGE GIVE GROUND | - | - | - | - | 0.2 | +0.7 | 13.9 | 0.0 |
| ENGINEER BY LORE | 0.2 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 1.8 | +174.5 | 0.0 | 82.4 | 1.2 | +89.2 | 0.0 | 78.1 |
| FALLBACK BY WORTH | 3.4 | +33.5 | 0.0 | 23.2 | 5.1 | +58.5 | 0.0 | 51.7 |
| FIGHT LIFT | 0.1 | +0.2 | 0.0 | 0.0 | - | - | - | - |
| FIRE AND FLEE | 0.1 | +2.1 | 0.0 | 0.0 | 0.1 | +0.7 | 0.0 | 5.9 |
| FLANK NOT WEIGHED | 4.2 | +0.0 | 0.0 | 92.2 | 4.1 | +0.0 | 0.0 | 127.5 |
| FOLLOW UP WEIGHED | 1.0 | +174.9 | 0.0 | 38.0 | 1.2 | +223.0 | 0.0 | 53.6 |
| FRIENDS SHOTS CHECKED | 0.2 | +18.8 | 0.0 | 0.0 | 0.3 | +31.1 | 0.0 | 33.3 |
| GIVES UP | - | - | - | - | 0.2 | -3.6 | 41.6 | 0.0 |
| GROUND FLIERS | 0.2 | +3.3 | 0.0 | 0.0 | 0.1 | +3.5 | 0.0 | 0.0 |
| HELPER ALREADY ASKED | - | - | - | - | 0.1 | +0.0 | 0.0 | 2.7 |
| HELPER UNSEEN | 0.2 | +0.0 | 16.8 | 17.2 | 0.4 | +0.0 | 0.0 | 15.6 |
| HILL BY ITS CHANCE | 0.9 | -53.3 | 0.0 | 10.5 | 0.4 | -35.3 | 0.0 | 3.9 |
| HOLDS AMBUSHERS | 0.2 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 6.6 | -92.8 | 284.3 | 97.3 | 8.3 | -210.8 | 471.4 | 214.3 |
| HUNT ADVANCE | - | - | - | - | 0.1 | +2.9 | 0.0 | 0.0 |
| HUNT IN PAIRS | 0.4 | +6.8 | 0.0 | 0.0 | 0.7 | +27.5 | 0.0 | 37.2 |
| HUNT KEPT | - | - | - | - | 0.1 | +3.9 | 13.9 | 0.0 |
| HUNT RESULT | - | - | - | - | 0.1 | +6.9 | 0.0 | 0.0 |
| HUNT THE GUNS | - | - | - | - | 0.1 | +28.0 | 0.0 | 3.3 |
| INVITES THE FIGHT | 2.4 | +37.7 | 92.3 | 30.6 | 0.9 | +18.0 | 45.6 | 41.9 |
| JOINT AS ONE | - | - | - | - | 2.3 | -21.9 | 115.9 | 44.4 |
| JOINT CHARGE PLAN | 0.2 | +10.2 | 0.0 | 10.5 | 0.1 | +0.6 | 0.0 | 0.0 |
| JOINT KNOWS CHALLENGE | 0.2 | -4.6 | 12.1 | 0.0 | 0.4 | -46.0 | 21.1 | 19.6 |
| KEEP FALLS | 0.1 | +0.3 | 0.0 | 0.0 | 0.1 | +7.5 | 0.0 | 0.0 |
| KEEPS ITS PREY | - | - | - | - | 0.1 | +0.2 | 0.0 | 0.0 |
| KEEPS ITS TARGET | 0.9 | +28.3 | 98.1 | 28.8 | 2.1 | +63.3 | 219.1 | 92.4 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KILLS COUNT | 1.2 | +24.4 | 87.7 | 6.7 | 2.2 | +169.4 | 197.8 | 113.6 |
| KILLS COUNT NEXT TURN | 3.2 | +54.1 | 100.8 | 10.5 | 5.3 | +227.8 | 179.8 | 83.3 |
| LONE CHARACTER SAFE SPOT | 0.4 | +6.2 | 4.3 | 2.5 | 0.1 | +5.1 | 0.0 | 0.0 |
| LONE WIZARD HOLDS BACK | - | - | - | - | 0.1 | +0.0 | 0.0 | 15.2 |
| LONE WIZARD KEPT IN | 0.8 | +30.7 | 0.0 | 0.0 | 0.1 | +11.2 | 0.0 | 0.0 |
| LONG SHOT | 0.3 | +9.1 | 27.8 | 0.0 | 0.4 | -0.2 | 34.1 | 0.0 |
| LOST CHARGE | 2.6 | -49.7 | 82.3 | 44.1 | 1.7 | -26.6 | 32.7 | 22.2 |
| MAKE SURE TOGETHER | 0.8 | +49.1 | 9.8 | 0.0 | 0.3 | +8.2 | 0.0 | 0.0 |
| MANOEUVRE | 0.1 | +16.9 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | 0.5 | +26.1 | 0.0 | 24.1 | 0.2 | +4.7 | 0.0 | 0.0 |
| MARCH ODDS | 0.8 | +44.6 | 70.4 | 0.0 | 0.2 | +14.6 | 11.2 | 22.2 |
| MARCH OVER CASTS | 0.3 | +13.8 | 0.0 | 9.0 | 0.2 | +34.1 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 4.0 | +136.2 | 0.0 | 24.2 | 4.9 | +203.1 | 0.0 | 97.8 |
| MISSILES IN THE MOVE | 4.9 | +304.9 | 0.0 | 51.0 | 1.5 | +30.1 | 0.0 | 120.1 |
| MISSILES NEXT TURN | 5.2 | +153.6 | 0.0 | 60.0 | 1.9 | +16.8 | 0.0 | 120.1 |
| MODEL FACING | 0.3 | +18.2 | 0.0 | 3.3 | - | - | - | - |
| MONSTER WIZARD ROAMS | 0.6 | +0.0 | 55.5 | 0.0 | - | - | - | - |
| MOVE AND CAST | 0.7 | +36.9 | 0.0 | 0.0 | 0.1 | +2.9 | 0.0 | 43.9 |
| MOVE SPELL IN RANGE | 0.6 | +15.9 | 0.0 | 9.4 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 1.4 | -92.5 | 0.0 | 69.2 | 0.2 | -14.8 | 0.0 | 15.2 |
| MOVE SPELL SPOT | 0.9 | +0.0 | 0.0 | 33.9 | 0.2 | +0.0 | 0.0 | 22.2 |
| MOVE TO CHARGE | 2.4 | +115.9 | 46.4 | 56.1 | 3.8 | +195.0 | 91.1 | 29.3 |
| MOVES UNITS SPELL | 0.1 | +6.1 | 0.0 | 0.0 | 0.1 | +0.6 | 0.0 | 0.0 |
| NEEDED THERE | 0.2 | +17.6 | 15.8 | 0.0 | 0.1 | +3.1 | 10.5 | 0.0 |
| NO CHARGE WHY | 2.2 | +0.0 | 84.9 | 79.4 | 3.5 | +0.0 | 128.7 | 49.6 |
| NO RALLY LEFT | - | - | - | - | 0.1 | +0.4 | 0.0 | 0.0 |
| NOT NEEDED | 0.2 | -1.8 | 15.9 | 0.0 | 0.2 | -18.7 | 28.9 | 0.0 |
| NOT TURNED | 3.8 | +93.5 | 0.0 | 59.6 | 4.7 | +144.9 | 0.0 | 159.9 |
| NOT WORTH A CAST | 0.4 | -0.3 | 0.0 | 0.0 | 0.1 | -0.0 | 0.0 | 15.2 |
| OFF BEST | 13.9 | -759.0 | 0.0 | 217.1 | 13.8 | -700.5 | 0.0 | 267.9 |
| OPENS A LANE | 0.2 | +1.2 | 23.3 | 0.0 | - | - | - | - |
| OPENS UP | 0.2 | +7.2 | 15.0 | 0.0 | 0.1 | +8.7 | 6.1 | 0.0 |
| OVERRUNS AWAY | 0.4 | +4.0 | 41.8 | 6.7 | 0.6 | +1.6 | 51.0 | 58.1 |
| PATHS CROSS | 1.8 | +159.5 | 0.0 | 6.7 | 2.9 | +304.4 | 0.0 | 59.3 |
| PERIAPT WORTH | - | - | - | - | 0.1 | +3.5 | 0.0 | 30.0 |
| PIVOT GUARDS FLANK | 0.2 | -8.0 | 0.0 | 2.9 | 0.1 | -2.9 | 0.0 | 0.0 |
| PLAN RESULT | 37.7 | +2129.4 | 2234.6 | 749.4 | 36.6 | +910.9 | 1516.6 | 1356.8 |
| PURSUES BIG PREY | 0.1 | -6.7 | 0.0 | 0.0 | - | - | - | - |
| RAIDS THE BAGGAGE NEXT TURN | 0.1 | +2.8 | 0.0 | 5.8 | 0.1 | +11.5 | 0.0 | 5.9 |
| RANDOM MOVE BY FIGURES | 0.4 | +23.6 | 0.0 | 0.0 | 1.3 | +4.3 | 0.0 | 18.9 |
| RANDOM MOVER NO PROMISE | 0.1 | -2.5 | 18.2 | 0.0 | 0.3 | -14.3 | 10.6 | 0.0 |
| REDIRECT BY WHAT IT STOPS | 0.2 | +0.4 | 0.0 | 0.0 | 0.3 | -1.6 | 0.0 | 0.0 |
| REDIRECT COUNTER | 1.6 | +150.7 | 0.0 | 9.9 | 3.6 | +233.6 | 0.0 | 79.1 |
| REDIRECT WEIGHED | 0.1 | +0.0 | 0.0 | 0.0 | 0.4 | +7.5 | 0.0 | 3.3 |
| REFUSING RETIRES | 0.5 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | 0.4 | +20.9 | 0.0 | 17.9 | 0.4 | +10.4 | 0.0 | 5.9 |
| RESTRAINS TO SHOOT | 0.2 | +2.1 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | 2.6 | +90.9 | 246.2 | 49.1 | 2.7 | +42.2 | 253.1 | 148.1 |
| SAFER THAN THE JOB | 1.3 | +86.8 | 0.0 | 43.5 | 0.8 | +47.7 | 0.0 | 17.8 |
| SCOUT SPOT | 0.4 | +0.2 | 0.0 | 0.0 | - | - | - | - |
| SCOUT WAITS | 0.4 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SCREEN BY WHAT IT SAVES | 0.1 | -6.7 | 0.0 | 0.0 | 0.5 | -27.6 | 0.0 | 1.5 |
| SEARCH SPOT | 1.9 | +88.4 | 0.0 | 11.2 | 2.3 | +120.5 | 0.0 | 43.4 |
| SELF MOVE SPELL | - | - | - | - | 0.1 | +8.7 | 0.0 | 43.9 |
| SET UP TOGETHER | 1.1 | +90.3 | 9.8 | 10.5 | 1.3 | +28.7 | 0.0 | 0.0 |
| SET-UP ANY TARGET | 0.9 | +127.6 | 40.5 | 29.7 | 0.2 | +19.5 | 0.0 | 0.0 |
| SET-UP MISSED | 0.1 | +23.6 | 0.0 | 0.0 | - | - | - | - |
| SET-UP SPOT | - | - | - | - | 5.8 | +86.5 | 39.3 | 54.4 |
| SHOOTERS IN TWO RANKS | 0.4 | +0.8 | 0.0 | 0.0 | 0.3 | +0.6 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.3 | +74.0 | 160.2 | 14.8 | 0.7 | +18.3 | 18.0 | 43.6 |
| SHORT GUN FORWARD | 0.4 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| SHOT REPLANNED | 0.7 | +0.0 | 194.4 | 0.0 | 0.3 | +0.0 | 25.0 | 23.8 |
| SHOTS IN THE MOVE | 18.1 | +1068.1 | 0.0 | 190.9 | 8.3 | +292.5 | 0.0 | 245.7 |
| SPELL CATCH ODDS | 0.1 | -0.1 | 17.9 | 19.7 | - | - | - | - |
| SPELL SETS UP CHARGE | 0.9 | +138.6 | 40.5 | 29.7 | 0.2 | +42.7 | 0.0 | 0.0 |
| SPELL WORTH | 0.7 | +5.8 | 32.5 | 43.1 | 2.1 | +43.7 | 117.2 | 117.2 |
| SPELLS IN THE FIGHT | 0.8 | -16.0 | 103.7 | 6.2 | 0.8 | -2.0 | 80.4 | 30.8 |
| STABLE ROLE | 11.7 | +0.0 | 412.1 | 192.3 | 10.0 | +0.0 | 282.5 | 113.6 |
| STAY WEIGHED | 0.2 | +18.8 | 0.0 | 0.0 | - | - | - | - |
| STOPS | - | - | - | - | 0.1 | +4.0 | 6.9 | 3.3 |
| STOPS SHORT OF THE FLANK | 0.6 | +22.6 | 0.0 | 10.5 | 0.4 | +31.5 | 0.0 | 27.4 |
| STUCK PIVOT | - | - | - | - | 0.2 | +0.0 | 0.0 | 9.4 |
| SUPPORT NARROWED | 4.8 | -44.6 | 201.1 | 60.7 | 7.6 | -56.2 | 575.3 | 212.8 |
| SUPPORTS | 2.7 | +48.8 | 43.8 | 2.0 | 5.2 | +66.9 | 372.3 | 118.8 |
| SURE CHARGE BEATS ADVANCE | 0.2 | -1.8 | 0.0 | 0.0 | 0.1 | -0.2 | 10.2 | 0.0 |
| SURE REACH TOGETHER | 0.5 | +10.9 | 0.0 | 0.0 | 1.0 | +6.6 | 0.0 | 24.0 |
| THROUGH LINE OF FIRE | 0.3 | -4.6 | 0.0 | 12.6 | 0.2 | +11.4 | 0.0 | 0.0 |
| TURN WORTH | 0.2 | -13.1 | 18.8 | 0.0 | 0.3 | -27.0 | 26.9 | 0.0 |
| TWO OR MORE ARRIVE | 0.7 | +2.6 | 0.0 | 10.5 | 0.4 | +2.7 | 0.0 | 0.0 |
| WAIT AFTER COSTS | 6.4 | -247.8 | 175.6 | 95.1 | 5.9 | -315.3 | 226.5 | 102.5 |
| WALKS TO THE FIGHT | 1.3 | +12.1 | 36.9 | 8.4 | 0.4 | +5.2 | 14.0 | 9.7 |
| WAR ENGINE CHARGES | 0.1 | +8.9 | 6.1 | 17.2 | - | - | - | - |
| WAR ENGINE JOBS | 0.7 | +0.0 | 76.1 | 17.2 | - | - | - | - |
| WEARS DOWN | 1.2 | +47.4 | 88.2 | 46.2 | 1.7 | +66.5 | 92.7 | 58.5 |
| WHO HITS BACK | 0.2 | +21.2 | 0.0 | 0.0 | 0.3 | +17.0 | 0.0 | 3.3 |
| WHOLE FIGHT | 0.5 | +21.9 | 44.1 | 13.8 | 0.3 | +11.2 | 47.3 | 0.0 |
| WHOLE FIGHT GAIN | 0.5 | +24.3 | 21.7 | 3.3 | 0.7 | +46.3 | 19.8 | 14.4 |
| WIDER SPREAD | 2.5 | -4.5 | 221.6 | 66.7 | 3.1 | -9.1 | 275.7 | 75.6 |

### Rule changes: su-h2h-opp-e45904b-p4

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 498 | 498 | 498 | 27.67 | -26270 | -52.8 |
| BEST FIRST | 133 | 133 | 133 | 7.39 | +5399 | +40.6 |
| PATHS CROSS | 85 | 85 | 85 | 4.72 | +8351 | +98.2 |
| SEARCH SPOT | 76 | 76 | 75 | 4.17 | +3762 | +50.2 |
| COUNTER-CHARGE COVER | 288 | 144 | 66 | 3.67 | +4490 | +68.0 |
| SUPPORTS | 142 | 142 | 60 | 3.33 | +708 | +11.8 |
| FACES THE THREAT | 55 | 55 | 55 | 3.06 | +4745 | +86.3 |
| SET-UP SPOT | 105 | 105 | 54 | 3.00 | +1907 | +35.3 |
| MOVE TO CHARGE | 112 | 112 | 52 | 2.89 | +1592 | +30.6 |
| SHOTS IN THE MOVE | 474 | 345 | 43 | 2.39 | +1692 | +39.3 |
| ARTILLERY RE-ROLL WEIGHED | 41 | 41 | 41 | 2.28 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 40 | 40 | 40 | 2.22 | +7161 | +179.0 |
| KILLS COUNT NEXT TURN | 154 | 154 | 39 | 2.17 | +1469 | +37.7 |
| SAFER THAN THE JOB | 39 | 39 | 39 | 2.17 | +2421 | +62.1 |
| CANNON SIGHT KEPT | 33 | 33 | 33 | 1.83 | +0 | +0.0 |
| ADVANCE LANE KEPT | 30 | 30 | 30 | 1.67 | +0 | +0.0 |
| REDIRECT COUNTER | 94 | 62 | 30 | 1.67 | +2370 | +79.0 |
| FALLBACK BY WORTH | 152 | 152 | 29 | 1.61 | +1656 | +57.1 |
| CANNON PLANNED TARGET | 181 | 181 | 28 | 1.56 | -46 | -1.6 |
| BEST FACING | 25 | 25 | 25 | 1.39 | +1626 | +65.1 |
| BEST OVERALL | 25 | 25 | 25 | 1.39 | +2160 | +86.4 |
| MAX FOR POSITIONING | 161 | 87 | 23 | 1.28 | +264 | +11.5 |
| SHOOTS FROM THE BEST SPOT | 36 | 36 | 23 | 1.28 | +506 | +22.0 |
| COMBAT PIVOT | 22 | 22 | 22 | 1.22 | +0 | +0.0 |
| WAIT AFTER COSTS | 221 | 221 | 22 | 1.22 | +397 | +18.1 |
| MARCH ODDS | 18 | 18 | 18 | 1.00 | +115 | +6.4 |
| SHOT REPLANNED | 18 | 18 | 18 | 1.00 | +0 | +0.0 |
| STOPS SHORT OF THE FLANK | 18 | 18 | 18 | 1.00 | +974 | +54.1 |
| BLOCKED WHEEL | 17 | 17 | 17 | 0.94 | +32 | +1.9 |
| RANDOM MOVE BY FIGURES | 31 | 31 | 17 | 0.94 | +503 | +29.6 |
| WALKS TO THE FIGHT | 30 | 30 | 17 | 0.94 | +87 | +5.1 |
| CHARGE NOW WEIGHED | 16 | 16 | 16 | 0.89 | +358 | +22.4 |
| LONE WIZARD KEPT IN | 16 | 16 | 16 | 0.89 | +754 | +47.1 |
| KILLS COUNT | 61 | 59 | 15 | 0.83 | +856 | +57.1 |
| SET UP TOGETHER | 43 | 38 | 15 | 0.83 | +475 | +31.6 |
| MISSILES IN THE MOVE | 116 | 65 | 14 | 0.78 | +233 | +16.6 |
| MOVE AND CAST | 14 | 14 | 14 | 0.78 | +716 | +51.2 |
| RESERVE FALL BACK | 14 | 14 | 14 | 0.78 | +563 | +40.2 |
| RISK BY ARC | 94 | 91 | 14 | 0.78 | +277 | +19.8 |
| CHARGE NOW FIRST | 92 | 92 | 13 | 0.72 | -761 | -58.6 |
| SHOOTERS IN TWO RANKS | 12 | 12 | 12 | 0.67 | +25 | +2.1 |
| CASTER AWAY FROM SCREEN | 11 | 11 | 11 | 0.61 | +0 | +0.0 |
| CHAFF PASSED | 11 | 11 | 11 | 0.61 | -17 | -1.5 |
| CAST JOB | 22 | 22 | 10 | 0.56 | +554 | +55.4 |
| HONEST WORTH | 268 | 264 | 10 | 0.56 | +112 | +11.2 |
| FRIENDS SHOTS CHECKED | 9 | 9 | 9 | 0.50 | +898 | +99.7 |
| MARCH CHECK | 12 | 12 | 9 | 0.50 | +567 | +63.0 |
| REDIRECT WEIGHED | 9 | 9 | 9 | 0.50 | +249 | +27.6 |
| SHORT GUN FORWARD | 9 | 9 | 9 | 0.50 | +0 | +0.0 |
| THROUGH LINE OF FIRE | 9 | 9 | 9 | 0.50 | +121 | +13.4 |
| WHOLE FIGHT GAIN | 21 | 19 | 9 | 0.50 | +242 | +26.9 |
| CASTING BLOCK | 8 | 8 | 8 | 0.44 | +906 | +113.2 |
| HOLDS AMBUSHERS | 8 | 8 | 8 | 0.44 | +0 | +0.0 |
| WHO HITS BACK | 8 | 8 | 8 | 0.44 | +565 | +70.6 |
| BIG CHARACTER SAFETY | 7 | 7 | 7 | 0.39 | -32 | -4.5 |
| CHARGE BAND | 7 | 7 | 7 | 0.39 | +0 | +0.0 |
| MISSILES NEXT TURN | 128 | 70 | 7 | 0.39 | +11 | +1.5 |
| REFUSING RETIRES | 14 | 14 | 7 | 0.39 | -1 | -0.2 |
| SCOUT WAITS | 7 | 7 | 7 | 0.39 | +0 | +0.0 |
| BEST PREY | 23 | 23 | 6 | 0.33 | +200 | +33.3 |
| KEEPS ITS TARGET | 55 | 53 | 6 | 0.33 | +144 | +24.0 |
| PIVOT GUARDS FLANK | 6 | 6 | 6 | 0.33 | -197 | -32.9 |
| HUNT IN PAIRS | 19 | 8 | 5 | 0.28 | +163 | +32.6 |
| INVITES THE FIGHT | 60 | 60 | 5 | 0.28 | +72 | +14.5 |
| MAKE SURE TOGETHER | 21 | 16 | 5 | 0.28 | +207 | +41.4 |
| MODEL FACING | 5 | 5 | 5 | 0.28 | +328 | +65.5 |
| SUPPORT NARROWED | 224 | 224 | 5 | 0.28 | -22 | -4.3 |
| SURE REACH TOGETHER | 27 | 19 | 5 | 0.28 | +52 | +10.4 |
| WEARS DOWN | 51 | 48 | 5 | 0.28 | +165 | +33.1 |
| WHOLE FIGHT | 14 | 14 | 5 | 0.28 | +306 | +61.3 |
| FIRE AND FLEE | 4 | 4 | 4 | 0.22 | +51 | +12.8 |
| MOVES UNITS SPELL | 4 | 4 | 4 | 0.22 | +122 | +30.4 |
| NEEDED THERE | 4 | 4 | 4 | 0.22 | +0 | +0.0 |
| STAY WEIGHED | 4 | 4 | 4 | 0.22 | +339 | +84.7 |
| STUCK PIVOT | 4 | 4 | 4 | 0.22 | +0 | +0.0 |
| SURE CHARGE BEATS ADVANCE | 4 | 4 | 4 | 0.22 | -36 | -9.0 |
| CONTINUE AHEAD WEIGHED | 3 | 3 | 3 | 0.17 | +0 | +0.0 |
| JOINT AS ONE | 42 | 42 | 3 | 0.17 | -30 | -10.1 |
| KEEP FALLS | 3 | 3 | 3 | 0.17 | +346 | +115.2 |
| LOST CHARGE | 77 | 77 | 3 | 0.17 | +25 | +8.4 |
| MANOEUVRE | 6 | 6 | 3 | 0.17 | +304 | +101.5 |
| RESTRAINS TO SHOOT | 3 | 3 | 3 | 0.17 | +38 | +12.7 |
| BLOCKED CHARGE SKIPPED | 2 | 2 | 2 | 0.11 | +0 | +0.0 |
| CARRIES OUT CLOSE-IN | 13 | 13 | 2 | 0.11 | -146 | -72.8 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.11 | +0 | +0.0 |
| LONE WIZARD HOLDS BACK | 2 | 2 | 2 | 0.11 | -10 | -5.2 |
| LONG SHOT | 13 | 13 | 2 | 0.11 | +117 | +58.4 |
| OPENS A LANE | 3 | 2 | 2 | 0.11 | +8 | +3.9 |
| OPENS UP | 5 | 5 | 2 | 0.11 | +76 | +38.1 |
| OVERRUNS AWAY | 18 | 17 | 2 | 0.11 | +23 | +11.3 |
| RAIDS THE BAGGAGE NEXT TURN | 3 | 3 | 2 | 0.11 | +59 | +29.3 |
| SPELLS IN THE FIGHT | 30 | 28 | 2 | 0.11 | +8 | +3.8 |
| WAR ENGINE CHARGES | 2 | 2 | 2 | 0.11 | +121 | +60.5 |
| BACKUP TARGETS | 24 | 11 | 1 | 0.06 | +2 | +2.3 |
| CASTS FROM BEHIND | 1 | 1 | 1 | 0.06 | +0 | +0.0 |
| HUNT ADVANCE | 1 | 1 | 1 | 0.06 | +9 | +8.8 |
| JOINT CHARGE PLAN | 6 | 6 | 1 | 0.06 | +3 | +3.1 |
| NO RALLY LEFT | 1 | 1 | 1 | 0.06 | +3 | +2.9 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.06 | +63 | +63.4 |
| PURSUES BIG PREY | 1 | 1 | 1 | 0.06 | -121 | -120.7 |
| REDIRECT BY WHAT IT STOPS | 10 | 10 | 1 | 0.06 | +22 | +21.8 |
| WAR ENGINE JOBS | 13 | 13 | 1 | 0.06 | -13 | -13.0 |
| WIDER SPREAD | 100 | 92 | 1 | 0.06 | +0 | +0.0 |
| ALREADY CARRIED | 2 | not checked | - | - | - | - |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| BLOWS WHERE AIMED | 5 | 5 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 17 | 17 | 0 | 0.00 | - | - |
| CARRIES OUT COUNTER | 2 | 2 | 0 | 0.00 | - | - |
| CARRIES OUT SET-UP | 4 | 4 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 22 | trace | - | - | - | - |
| CHARGER SLAIN LOST | 23 | 20 | 0 | 0.00 | - | - |
| CHARIOT NO STATIC JOB | 1 | 1 | 0 | 0.00 | - | - |
| CHARIOT WIZARD CAREFUL | 3 | 3 | 0 | 0.00 | - | - |
| CHEAP HELPER | 1 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 30 | not checked | - | - | - | - |
| DEFENSIVE ARMY | 2 | 2 | 0 | 0.00 | - | - |
| DEFENSIVE FLOOR | 2 | 2 | 0 | 0.00 | - | - |
| EDGE GIVE GROUND | 3 | 3 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT LIFT | 1 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 148 | not checked | - | - | - | - |
| GIVES UP | 3 | 2 | 0 | 0.00 | - | - |
| GROUND FLIERS | 5 | not checked | - | - | - | - |
| HELPER ALREADY ASKED | 1 | not checked | - | - | - | - |
| HELPER UNSEEN | 11 | 11 | 0 | 0.00 | - | - |
| HILL BY ITS CHANCE | 24 | 24 | 0 | 0.00 | - | - |
| HUNT KEPT | 2 | trace | - | - | - | - |
| HUNT RESULT | 2 | trace | - | - | - | - |
| HUNT THE GUNS | 2 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 11 | 8 | 0 | 0.00 | - | - |
| KEEPS ITS PREY | 1 | 1 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 8 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 9 | 9 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 11 | 11 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 11 | 6 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 29 | trace | - | - | - | - |
| MOVE SPELL SPOT | 19 | not checked | - | - | - | - |
| NO CHARGE WHY | 103 | not checked | - | - | - | - |
| NOT NEEDED | 7 | 7 | 0 | 0.00 | - | - |
| NOT TURNED | 153 | 153 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 9 | not checked | - | - | - | - |
| PLAN RESULT | 1337 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 7 | 7 | 0 | 0.00 | - | - |
| SCOUT SPOT | 7 | 7 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 11 | 11 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 2 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 19 | not checked | - | - | - | - |
| SET-UP MISSED | 2 | trace | - | - | - | - |
| SPELL CATCH ODDS | 1 | not checked | - | - | - | - |
| SPELL SETS UP CHARGE | 21 | not checked | - | - | - | - |
| SPELL WORTH | 50 | not checked | - | - | - | - |
| STABLE ROLE | 390 | 388 | 0 | 0.00 | - | - |
| STOPS | 2 | 2 | 0 | 0.00 | - | - |
| TURN WORTH | 9 | 9 | 0 | 0.00 | - | - |
| TWO OR MORE ARRIVE | 19 | 16 | 0 | 0.00 | - | - |

### Off best figure: su-h2h-opp-e45904b-p4

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 12.67 | 11.67 | 54.4 |
| FALLBACK | gate | 0.22 | 0.89 | 56.5 |
| CHARGE NOW FIRST | rule | 0.33 | 0.39 | 58.6 |
| NO REASON | gate | - | 0.67 | 26.9 |
| TURN GATE | gate | 0.39 | 0.28 | 19.5 |
| SUPPORT REQUEST | gate | 0.22 | 0.17 | 79.4 |
| PIVOT GUARDS FLANK | rule | 0.22 | 0.11 | 32.9 |
| BIG CHARACTER SAFETY | rule | 0.11 | 0.17 | 7.2 |
| BLOCKED WHEEL | rule | 0.17 | 0.06 | 72.2 |
| CANNON PLANNED TARGET | rule | 0.22 | - | 12.8 |
| SURE CHARGE BEATS ADVANCE | rule | 0.17 | 0.06 | 9.0 |
| CHAFF PASSED | rule | 0.06 | 0.11 | 5.6 |
| CHARGE NOW WEIGHED | rule | 0.11 | 0.06 | 55.0 |
| FIGHT ORDER BAND | gate | 0.06 | 0.11 | 1.8 |
| JOINT AS ONE | rule | - | 0.17 | 10.1 |
| MARCH ODDS | rule | 0.11 | 0.06 | 61.7 |
| RULE SWITCHED OFF | gate | 0.17 | - | 24.9 |
| SUPPORT NARROWED | rule | 0.11 | 0.06 | 7.1 |
| CARRIES OUT CLOSE-IN | rule | - | 0.11 | 72.8 |
| LONE WIZARD HOLDS BACK | rule | - | 0.11 | 5.2 |
| SAFER THAN THE JOB | rule | 0.06 | 0.06 | 8.4 |
| STOPS SHORT OF THE FLANK | rule | 0.06 | 0.06 | 7.3 |
| AFTERMATH BAND | gate | 0.06 | - | 4.9 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.06 | - | 93.2 |
| FACES THE THREAT | rule | - | 0.06 | 4.7 |
| FALLBACK BY WORTH | rule | 0.06 | - | 20.4 |
| LONE CHARACTER SAFE SPOT | gate | 0.06 | - | 8.4 |
| PATHS CROSS | rule | - | 0.06 | 2.5 |
| PURSUES BIG PREY | rule | 0.06 | - | 120.7 |
| SET-UP SPOT | rule | - | 0.06 | 150.6 |
| THROUGH LINE OF FIRE | rule | 0.06 | - | 212.7 |
| WAR ENGINE JOBS | rule | 0.06 | - | 13.0 |

### Plans: su-h2h-opp-e45904b-p4

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 10.3 | 18% | 410 | 391 | 95% |
| Mine | charge | 3.2 | 55% | 181 | 258 | 143% |
| Mine | close in | 3.1 | 29% | 147 | 85 | 58% |
| Mine | hold | 4.7 | 38% | 348 | 0 | 0% |
| Mine | join | 0.6 | 91% | 12 | 0 | 0% |
| Mine | shoot | 13.0 | 69% | 660 | 1395 | 211% |
| Mine | support | 2.8 | 94% | 23 | 0 | 0% |
| Opponent | advance | 12.4 | 18% | 263 | 331 | 126% |
| Opponent | charge | 4.6 | 45% | 544 | 339 | 62% |
| Opponent | close in | 5.1 | 24% | 285 | 99 | 35% |
| Opponent | hold | 4.3 | 35% | 247 | 0 | 0% |
| Opponent | join | 0.1 | 100% | 2 | 0 | 0% |
| Opponent | shoot | 4.1 | 55% | 98 | 154 | 157% |
| Opponent | support | 5.8 | 82% | 47 | 0 | 0% |

### Packages: hunt the guns, su-h2h-opp-e45904b-p4

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 12 |
| Opponent | 0.1 | 2 | 0 | 50% | 50% | 0% | 4.0 | 252 | 62 | 0% | 249 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 73 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 67 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| High Elf Realms | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 213 | 0 | 0% | 274 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 88 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 640 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 640 |
| Vampire Counts | 0.5 | 1 | 0 | 100% | 100% | 0% | 4.0 | 292 | 125 | 0% | 0 |
| Warriors of Chaos | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 166 |
| Wood Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 286 |

### Battle groups: su-h2h-opp-e45904b-p4

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 8.7 | 25% | 49% | 26% | 30% | 48% | 3% | 17% | 31% | 0% |
| Mine | REDIRECT COUNTER | 1.6 | 28% | 75% | 0% | - | 12% | 0% | 0% | 88% | 0% |
| Opponent | COUNTER-CHARGE COVER | 7.3 | 13% | 76% | 24% | 0% | 31% | 0% | 15% | 54% | 0% |
| Opponent | REDIRECT COUNTER | 3.6 | 25% | 88% | 19% | 33% | 46% | 0% | 31% | 23% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: su-h2h-opp-e45904b-p4

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 7 | 0 (7) | 0 | 0 | 51 | 57% | 2.0 | 0 (3) | 0 (2) | 0 (2) | 0 (3) | 0 (4) |
| Mine | Character | 67 | 38 (67) | 38 | 0 | 41 | 15% | 2.4 | 50 (14) | 38 (35) | 0 (6) | 29 (21) | 41 (34) |
| Mine | Clean-up | 14 | 77 (14) | 37 | 39 | 37 | 21% | 3.2 | - | 81 (12) | 49 (2) | 31 (7) | 103 (7) |
| Mine | Fast | 2 | 0 (2) | 0 | 0 | 100 | 0% | 1.5 | 0 (1) | 0 (1) | - | 0 (2) | - |
| Mine | Fast Hammer | 21 | 81 (21) | 46 | 35 | 40 | 19% | 2.1 | 74 (15) | 142 (4) | 0 (2) | 110 (12) | 49 (9) |
| Mine | Hammer | 37 | 46 (37) | 33 | 14 | 39 | 16% | 2.5 | 24 (4) | 57 (27) | 10 (6) | 51 (23) | 41 (14) |
| Mine | Holder | 13 | 37 (13) | 0 | 37 | 45 | 54% | 3.8 | 0 (2) | 63 (7) | 0 (4) | 70 (7) | 4 (6) |
| Mine | Shooter | 19 | 55 (19) | 17 | 38 | 52 | 5% | 1.8 | 0 (3) | 85 (12) | 0 (4) | 54 (14) | 57 (5) |
| Mine | War machine | 46 | 79 (46) | 79 | 0 | 21 | 4% | 1.4 | 61 (16) | 78 (22) | 128 (8) | 118 (8) | 71 (38) |
| Mine | Wizard | 11 | 9 (11) | 9 | 0 | 35 | 0% | 1.5 | 0 (2) | 16 (6) | 0 (1) | 16 (4) | 8 (5) |
| Opponent | Chaff | 38 | 34 (38) | 7 | 27 | 56 | 53% | 2.5 | 25 (15) | 54 (7) | 29 (16) | 37 (28) | 22 (10) |
| Opponent | Character | 45 | 50 (45) | 50 | 0 | 41 | 27% | 2.0 | 60 (20) | 46 (20) | 31 (4) | 54 (19) | 49 (25) |
| Opponent | Clean-up | 6 | 38 (6) | 25 | 13 | 14 | 17% | 2.8 | 0 (1) | 44 (3) | 42 (2) | 67 (3) | 21 (3) |
| Opponent | Fast | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Fast Hammer | 26 | 55 (26) | 46 | 9 | 58 | 15% | 3.0 | 58 (10) | 40 (11) | 89 (5) | 38 (17) | 80 (9) |
| Opponent | Fragile | 8 | 0 (8) | 0 | 0 | 41 | 25% | 2.0 | 0 (3) | 0 (4) | 0 (1) | 0 (6) | 0 (2) |
| Opponent | Hammer | 27 | 41 (27) | 21 | 20 | 36 | 44% | 3.3 | 14 (7) | 51 (18) | 0 (2) | 17 (15) | 60 (12) |
| Opponent | Holder | 11 | 61 (11) | 20 | 42 | 32 | 55% | 3.8 | 0 (5) | 105 (5) | 0 (1) | 24 (8) | 145 (3) |
| Opponent | Shooter | 21 | 58 (21) | 4 | 53 | 47 | 0% | 1.6 | 29 (6) | 62 (13) | 145 (2) | 32 (10) | 86 (11) |
| Opponent | Support | 3 | 0 (3) | 0 | 0 | 100 | 0% | 2.0 | 0 (1) | 0 (2) | - | 0 (3) | - |
| Opponent | War machine | 6 | 34 (6) | 34 | 0 | 62 | 0% | 1.2 | 30 (3) | 39 (3) | - | 30 (3) | 39 (3) |
| Opponent | Wizard | 5 | 28 (5) | 28 | 0 | 44 | 0% | 2.0 | 11 (3) | - | 16 (1) | 16 (1) | 11 (3) |

### Charged fights: su-h2h-opp-e45904b-p4

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 156 | 199 | 2.2 | 1.6 | 88 | 9 | +79 | 1 of 9 | 7 of 9 | +93 | +61 |
| Mine | Chaos Dwarfs | 4 | 216 | 171 | 3.0 | 1.2 | 57 | 42 | +15 | 3 of 12 | 8 of 12 | +54 | +8 |
| Mine | Dwarfen Mountain Holds | 3 | 416 | 202 | 1.7 | 1.4 | 121 | 70 | +51 | 2 of 5 | 5 of 5 | +110 | +12 |
| Mine | Empire of Man | 5 | 671 | 0 | 1.4 | 1.3 | 0 | 65 | -65 | 5 of 7 | 3 of 7 | +0 | -76 |
| Mine | Grand Cathay | 2 | 978 | 230 | 2.5 | 1.0 | 92 | 0 | +92 | 0 of 5 | 5 of 5 | - | +92 |
| **Mine** | all armies | 18 | 447 | 141 | 2.1 | 1.3 | 67 | 37 | +30 | 11 of 38 | 28 of 38 | +80 | +13 |
| Opponent | Empire of Man | 1 | 340 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | High Elf Realms | 4 | 31 | 374 | 3.8 | 1.3 | 100 | 135 | -35 | 11 of 15 | 7 of 15 | -38 | -35 |
| Opponent | Lizardmen | 2 | 0 | 370 | 4.0 | 1.2 | 92 | 44 | +48 | 5 of 8 | 5 of 8 | +155 | +12 |
| Opponent | Orc & Goblin Tribes | 1 | 0 | 1425 | 4.0 | 1.0 | 356 | 0 | +356 | 2 of 4 | 4 of 4 | - | +356 |
| Opponent | Skaven | 1 | 0 | 772 | 2.0 | 1.0 | 386 | 48 | +338 | 1 of 2 | 1 of 2 | - | +338 |
| Opponent | Vampire Counts | 2 | 114 | 478 | 4.0 | 1.1 | 119 | 0 | +119 | 4 of 8 | 5 of 8 | +120 | +119 |
| Opponent | Warriors of Chaos | 4 | 0 | 782 | 5.0 | 1.1 | 156 | 33 | +123 | 13 of 20 | 12 of 20 | +219 | +118 |
| Opponent | Wood Elf Realms | 3 | 15 | 388 | 2.3 | 1.1 | 166 | 0 | +166 | 5 of 7 | 5 of 7 | +0 | +194 |
| **Opponent** | all armies | 18 | 41 | 538 | 3.6 | 1.1 | 151 | 49 | +102 | 41 of 64 | 39 of 64 | +67 | +107 |

### Effective charges: su-h2h-opp-e45904b-p4

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 9 | 2 (net +46) | 0 | 4 (net +106) | 1 (net +123) | 0 | 2 (net +35) | 0 | 44% (4 of 9) |
| Mine | Chaos Dwarfs | 12 | 1 (net +0) | 0 | 3 (net -103) | 2 (net -7) | 1 (net +0) | 4 (net +98) | 1 | 27% (3 of 11) |
| Mine | Dwarfen Mountain Holds | 5 | 0 | 0 | 0 | 1 (net -60) | 0 | 4 (net +79) | 0 | 0% (0 of 5) |
| Mine | Empire of Man | 7 | 2 (net -227) | 1 (net +0) | 2 (net +0) | 1 (net +0) | 0 | 1 (net +0) | 0 | 29% (2 of 7) |
| Mine | Grand Cathay | 5 | 0 | 0 | 1 (net +0) | 2 (net +161) | 1 (net +56) | 1 (net +83) | 0 | 20% (1 of 5) |
| Opponent | High Elf Realms | 15 | 4 (net -313) | 0 | 4 (net +118) | 4 (net -6) | 1 (net +77) | 2 (net +98) | 0 | 27% (4 of 15) |
| Opponent | Lizardmen | 8 | 2 (net -24) | 0 | 3 (net +103) | 0 | 1 (net -186) | 2 (net +155) | 0 | 38% (3 of 8) |
| Opponent | Orc & Goblin Tribes | 4 | 0 | 0 | 0 | 0 | 0 | 1 (net +354) | 3 | 0% (0 of 1) |
| Opponent | Skaven | 2 | 1 (net +474) | 0 | 0 | 0 | 0 | 1 (net +203) | 0 | 0% (0 of 2) |
| Opponent | Vampire Counts | 8 | 1 (net +239) | 0 | 1 (net +0) | 2 (net +0) | 2 (net +60) | 2 (net +298) | 0 | 12% (1 of 8) |
| Opponent | Warriors of Chaos | 20 | 4 (net -12) | 1 (net +0) | 5 (net +209) | 0 | 1 (net +110) | 8 (net +169) | 1 | 26% (5 of 19) |
| Opponent | Wood Elf Realms | 7 | 0 | 1 (net +0) | 2 (net +312) | 2 (net +101) | 1 (net +339) | 1 (net +0) | 0 | 29% (2 of 7) |

### Charged fights, damage counted: su-h2h-opp-e45904b-p4

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 5 | 221 | 265 | -72 | 38 | 108 | -70 | -31.7 |
| Mine | 50-54% | 1 | 380 | 170 | +0 | 113 | 0 | +113 | +29.8 |
| Mine | Effective (55-75%) | 10 | 245 | 245 | +12 | 49 | 41 | +8 | +3.1 |
| Mine | 76-89% | 7 | 156 | 178 | +53 | 119 | 54 | +65 | +41.8 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 12 | 190 | 184 | +72 | 136 | 52 | +85 | +44.6 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 2 | 572 | 96 | +28 | 28 | 0 | +28 | +4.9 |
| Mine | No odds | 1 | 339 | 115 | +115 | 115 | 0 | +115 | +33.9 |
| Mine | All fights | 38 | 231 | 203 | +30 | 90 | 51 | +39 | +16.9 |
| Opponent | Long shot (under 50%) | 12 | 330 | 311 | -53 | 114 | 196 | -82 | -24.9 |
| Opponent | 50-54% | 2 | 70 | 227 | +0 | 0 | 8 | -8 | -10.8 |
| Opponent | Effective (55-75%) | 15 | 403 | 304 | +163 | 239 | 134 | +106 | +26.2 |
| Opponent | 76-89% | 8 | 384 | 201 | +22 | 54 | 26 | +29 | +7.5 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 17 | 295 | 203 | +177 | 215 | 10 | +205 | +69.4 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 6 | 544 | 112 | +77 | 144 | 106 | +38 | +6.9 |
| Opponent | No odds | 4 | 381 | 190 | +268 | 268 | 7 | +261 | +68.5 |
| Opponent | All fights | 64 | 360 | 238 | +102 | 172 | 85 | +87 | +24.2 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| su-h2h-opp-e45904b-p4 | move | 188 | 43 (23%) | 28 (15%) | 25 (13%) | 120 (64%) |
| su-h2h-opp-e45904b-p4 | objective | 149 | 24 (16%) | 18 (12%) | 21 (14%) | 104 (70%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0114, L0130 |
| Charmed Shield | Opponent | L0434, L0624, L0926, L1034 |
| Elixir of Power | Opponent | L0819 |
| Invocation of Nehek | Opponent | L0624 |
| Opal Amulet | Opponent | L0114, L0214 |
| Periapt of Soul Exchange | Opponent | L0520 |
| Ring of Doom | Mine | L0214, L0230 |
| Ring of Doom | Opponent | L0315 |
| Ring of Jet | Mine | L1017, L1034 |
| Standard of the Fell Warrior | Opponent | L0713 |
| Twice-Blessed Armour | Mine | L0713, L0729, L1017, L1034 |
| Witch Hunter's Ward | Mine | L0713, L0729, L0819, L0835 |
| Witch Hunter's Ward | Opponent | L0608 |

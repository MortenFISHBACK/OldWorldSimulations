import json,collections,statistics
from cls import cls,R
RNG=json.load(open('rng.json'))
def rng(r,who='uid'):
    k=f"{r['arm']}-{0}"
    return None
# need part folder key: reconstruct from file name -> find
import glob,os
key={}
for f in glob.glob('/root/data/charge-band-h2h-2026-11-15/*/game-*.log.jsonl'):
    key[(os.path.basename(os.path.dirname(f)).split('-')[0],os.path.basename(f)[5:-10])]=os.path.basename(os.path.dirname(f))+'/'+os.path.basename(f)
def reach(r,idf):
    v=RNG.get(f"{key[(r['arm'],r['g'])]}|{r[idf]}")
    if not v: return None
    if v['txt']: return v['txt']
    if v['m'] is None or v['mt']: return None
    return v['m']+6
def sub(r):
    c=cls(r)
    if not c.startswith('no charge offered'): return c
    g1,g2=r['gap1'],r['gap2']
    if g1 is None or g2 is None: return 'NO: ?'
    ur=reach(r,'uid')
    moved_away=g2-g1>1.0
    tm=(r['tmove'] or 0)>0.5; um=(r['uenemyturn'] or 0)>0.5
    if r['preach'] is None:
        # the move did not promise a reach
        if ur is not None and g1>ur: return 'NO: own move ended out of charge range (no reach promised)'
        if ur is not None and g2>ur: return 'NO: no reach promised; target then stepped out of range'
        return 'NO: no reach promised (fallback/other move), '+('in range' if ur is not None else 'range unknown')
    if um and not tm: return 'NO: unit itself was moved in the enemy turn'
    if ur is not None and g2>ur: return 'NO: promised, target moved out of range' if tm else 'NO: promised, but out of range without target moving'
    if tm: return 'NO: promised, target moved (still within max range or range unknown)'
    return 'NO: promised, target did not move, still no charge (arc, sight, blocked, reach under the floor)'
if __name__=='__main__':
    for kind in('close in to charge','advance on'):
        rows=[r for r in R if r['kind']==kind]
        C=collections.Counter(sub(r) for r in rows); n=len(rows)
        print('##',kind,n)
        for k,v in C.most_common(): print(f'  {v:5d} {100*v/n:5.1f}%  {k}')
    ci=[r for r in R if r['kind']=='close in to charge']
    print('preach stated',sum(r['preach'] is not None for r in ci),'fallback',sum(r['fallback'] for r in ci),'short>1',sum(r['short']>1 for r in ci),'left',sum(r['left'] for r in ci),'nomv',sum(r['mv']=='' for r in ci))
    import collections as c2
    b=c2.Counter()
    for r in ci:
        p=r['preach']; k='none' if p is None else '<50' if p<50 else '50-74' if p<75 else '75-94' if p<95 else '95+'
        b[(k,cls(r).startswith('CHARGED TARGET'))]+=1
    for k in('none','<50','50-74','75-94','95+'): print(k,b[(k,True)],b[(k,False)],round(100*b[(k,True)]/max(1,b[(k,True)]+b[(k,False)])))

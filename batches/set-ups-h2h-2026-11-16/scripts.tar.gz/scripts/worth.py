import json,glob,os,re,collections
D='/mnt/project-files/set-ups-h2h-2026-11-16'
R=re.compile(r"^(HONEST WORTH|CHARGE BAND): (-?[\d.]+) VP: ([a-z ]+?) #\d+ .*?\| (SAME|CHANGED)")
C=collections.Counter(); V=collections.defaultdict(float); leak=collections.Counter(); games=collections.Counter()
for f in sorted(glob.glob(D+'/*/game-*.log.jsonl')):
  arm=os.path.basename(os.path.dirname(f)).split('-')[0]; fx='Mine' if arm=='mine' else 'Opponent'; games[arm]+=1
  for l in open(f):
    if '"OpponentRule"' not in l or ('HONEST WORTH' not in l and 'CHARGE BAND' not in l): continue
    d=json.loads(l); s=d['summary']; tag='HONEST WORTH' if s.startswith('HONEST WORTH') else ('CHARGE BAND' if s.startswith('CHARGE BAND') else None)
    if not tag: continue
    if d['side']!=fx: leak[tag]+=1; continue
    m=R.match(s)
    k=(tag,m.group(3) if m else '?',m.group(4) if m else '?'); C[k]+=1; V[k]+=float(m.group(2)) if m else 0
print('games',dict(games),'leak (rows on the switched-off side)',dict(leak))
for k in sorted(C): print(k,C[k],'avg VP %.1f'%(V[k]/C[k]))

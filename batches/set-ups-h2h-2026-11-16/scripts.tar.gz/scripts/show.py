import load,sys,glob
def show(arm,g,turn,side,name,phases=('Strategy','Movement'),width=1400,turns=None):
    f=glob.glob(f'/root/data/charge-band-h2h-2026-11-15/{arm}-*/game-{g}.log.jsonl')[0]
    G=load.load(f)
    for a in G['acts']:
        s=a.get('summary') or ''
        if a['turn'] in (turns or [turn]) and a['side']==side and a['phase'] in phases and (name in s[:len(name)+25] or a.get('actor')==name):
            print(f"[{a['id']} t{a['turn']} {a['phase']} {a['type']}] {s[:width]}")
if __name__=='__main__':
    show(sys.argv[1],sys.argv[2],int(sys.argv[3]),sys.argv[4],sys.argv[5],turns=[int(x) for x in sys.argv[6].split(',')] if len(sys.argv)>6 else None)

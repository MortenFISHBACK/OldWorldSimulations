import load,re,json,collections,os,sys
OBJ=re.compile(r'^Objective for (.+?): (close in to charge|advance on|charge|shoot|hold or contest|support|join)\b(.*)$')
TID=re.compile(r'#(\d+)')
WORTH=re.compile(r'worth ~(-?[\d.]+) VP')
out=[]
for f in load.files():
    g=load.load(f); acts=g['acts']; frames=g['frames']; board=g['board']
    arm=os.path.basename(os.path.dirname(f)).split('-')[0]; fixside='Mine' if arm=='mine' else 'Opponent'
    U={u['id']:u for u in board['units']}; byname={}
    for u in board['units']: byname[(u['s'],u['n'])]=u
    names={s:sorted([n for (ss,n) in byname if ss==s],key=len,reverse=True) for s in ('Mine','Opponent')}
    def unit_of(side,text):
        for n in names[side]:
            if text.startswith(n+' ') or text.startswith(n+': '): return byname[(side,n)]
        return None
    # game-side turns in order
    gst=[];idx={}
    pos={};fi=0
    snap={}  # (turn,side)-> positions at first action
    per=collections.defaultdict(list)
    for a in acts:
        while fi<len(frames) and frames[fi]['after']<a['id']:
            for u in frames[fi]['units']: pos[u['id']]=u
            fi+=1
        if a['turn']<1: continue
        k=(a['turn'],a['side'])
        if k not in idx:
            idx[k]=len(gst); gst.append(k); snap[k]=dict(pos)
        per[k].append(a)
    while fi<len(frames):
        for u in frames[fi]['units']: pos[u['id']]=u
        fi+=1
    endpos=dict(pos)
    def after(k):  # snapshot at start of following game-side turn
        i=idx[k]+1
        return snap[gst[i]] if i<len(gst) else endpos
    for k in gst:
        turn,side=k; A=per[k]
        nk=(turn+1,side)
        if nk not in idx: continue
        i=idx[k]
        enemyk=gst[i+1] if i+1<len(gst) and gst[i+1][1]!=side else None
        B=per[nk]; E=per[enemyk] if enemyk and enemyk!=nk else []
        # objectives this turn and next
        def objs(X,sd):
            d={}
            for a in X:
                if a['type']=='Computer' and a['phase']=='Strategy':
                    s=a.get('summary') or ''
                    if s.startswith('Objective for '):
                        u=unit_of(sd,s[len('Objective for '):])
                        if not u: continue
                        rest=s[len('Objective for ')+len(u['n'])+2:]
                        m=re.match(r'(close in to charge|advance on|charge|shoot|hold or contest|support|join)',rest)
                        kind=m.group(1) if m else rest[:20]
                        t=TID.search(rest); w=WORTH.search(rest)
                        d[u['id']]=dict(kind=kind,tid=int(t.group(1)) if t and kind in('close in to charge','advance on','charge','shoot','join') else None,worth=float(w.group(1)) if w else None,text=rest,only='its only option' in rest)
            return d
        O=objs(A,side); N=objs(B,side)
        # declared charges next turn by own side
        decl=collections.defaultdict(list); contact=set()
        for a in B:
            if a['type']=='Charge':
                s=a.get('summary') or ''
                if 'declares a charge against' in s: decl[a['actor_id']].append(a['target_id'])
        edecl=collections.defaultdict(list)
        for a in E:
            if a['type']=='Charge' and 'declares a charge against' in (a.get('summary') or ''): edecl[a['target_id']].append(a['actor_id'])
        # own charges THIS turn on each target (who charged T this turn)
        for uid,o in O.items():
            if o['kind'] not in('close in to charge','advance on') or o['tid'] is None: continue
            u=U[uid]; tid=o['tid']; n=u['n']
            r=dict(g=os.path.basename(f)[5:-10],arm=arm,turn=turn,side=side,fix=side==fixside,uid=uid,unit=n,tid=tid,target=U[tid]['n'] if tid in U else '?',
                   kind=o['kind'],worth=o['worth'],only=o['only'],utt=u['lk'].get('tt'),urt=u['lk'].get('rt'),ttt=U[tid]['lk'].get('tt') if tid in U else None)
            # rule tags this turn (strategy) for the unit
            tags=[];mtags=[]
            for a in A:
                if a['type']=='OpponentRule' and a.get('actor_id')==uid:
                    m=re.match(r"^([A-Z][A-Z0-9 +'’-]+): ([+-][\d.]+) VP",a.get('summary') or '')
                    if m: (tags if a['phase']=='Strategy' else mtags).append((m.group(1),float(m.group(2))))
            r['tags']=tags; r['mtags']=mtags
            mv=''
            for a in A:
                s=a.get('summary') or ''
                if a['type']=='Computer' and a['phase']=='Movement' and s.startswith(n+' ') and '(its objective: ' in s: mv=s
            r['mv']=mv
            m=re.search(r'next turn its charge reach (\d+)%, win first round (\d+)%',mv)
            r['preach']=int(m.group(1)) if m else None; r['pwin']=int(m.group(2)) if m else None
            r['fallback']='fallback' in mv or 'no move for the job gets it nearer' in mv
            m=re.search(r'ends ([\d.]+)" short of that spot',mv); r['short']=float(m.group(1)) if m else 0
            r['left']='leaves its objective' in mv
            m=re.search(r"sets up next turn's charge on #(\d+)",mv); r['setsup']=int(m.group(1)) if m else None
            r['together']=any(t[0] in('SET UP TOGETHER','JOINT CHARGE PLAN') for t in tags) or 'closes in together' in mv
            p0=snap[k]; p1=after(k); p2=snap[nk]
            r['arc1']=load.inarc(p1.get(uid),p1.get(tid)); r['arc2']=load.inarc(p2.get(uid),p2.get(tid)); r['gap0']=load.gap(p0.get(uid),p0.get(tid)); r['gap1']=load.gap(p1.get(uid),p1.get(tid)); r['gap2']=load.gap(p2.get(uid),p2.get(tid))
            def moved(a,b,i):
                if not a.get(i) or not b.get(i): return None
                return ((a[i]['x']-b[i]['x'])**2+(a[i]['y']-b[i]['y'])**2)**.5
            r['umove']=moved(p0,p1,uid); r['tmove']=moved(p1,p2,tid); r['uenemyturn']=moved(p1,p2,uid)
            r['t_on2']=p2.get(tid,{}).get('on'); r['t_fl2']=p2.get(tid,{}).get('fl'); r['u_on2']=p2.get(uid,{}).get('on'); r['u_fl2']=p2.get(uid,{}).get('fl')
            r['u_charged']=edecl.get(uid,[]); 
            # next turn
            no=N.get(uid); r['next']=no and dict(kind=no['kind'],tid=no['tid'],worth=no['worth'])
            offered={}
            carry=None;nmv='';plan=None;cnow=None
            for a in B:
                s=a.get('summary') or ''
                if a['type']=='Computer' and a['phase']=='Strategy' and s.startswith(n+' does not charge #'):
                    for m in re.finditer(r'#(\d+) .*?\(worth ~(-?[\d.]+) VP\)',s): offered[int(m.group(1))]=float(m.group(2))
                if a['type']=='Computer' and a['phase']=='Strategy' and s.startswith(n+' does not carry out'): carry=s
                if a['type']=='OpponentRule' and a.get('actor_id')==uid and (a.get('summary') or '').startswith('PLAN RESULT'): plan=s
                if a['type']=='OpponentRule' and a.get('actor_id')==uid and (a.get('summary') or '').startswith('CARRIES OUT SET-UP'): carry='CARRIED: '+s
                if a['type']=='Computer' and a['phase']=='Movement' and s.startswith(n+' does not charge: '):
                    cnow=s
                if a['type']=='Computer' and a['phase']=='Movement' and re.match(re.escape(n)+r' charges ',s): cnow=s
            r['offered']=offered; r['carry']=carry; r['plan']=plan; r['cnow']=cnow
            r['decl']=decl.get(uid,[])
            r['joint']=[x for x,ts in decl.items() if x!=uid and tid in ts]
            r['others_on_t']=r['joint']
            if no and no['kind']=='charge' and no['tid'] is not None:
                m=re.search(r'win first round (\d+)%',no['text']); r['nwin']=int(m.group(1)) if m else None
                r['njoint']=[x for x,ts in decl.items() if x!=uid and no['tid'] in ts]
            out.append(r)
json.dump(out,open('trace.json','w'))
print(len(out))

import json,collections,load
RNG=json.load(open('rng.json'))
from why import key
RT={}
for f in load.files():
    g=load.load(f); k=f.split('/')[-2]+'/'+f.split('/')[-1]
    for u in g['board']['units']: RT[f"{k}|{u['id']}"]=(u['lk'].get('rt'),u['lk'].get('tt'))
def maxrange(r,idf='uid'):
    k=f"{key[(r['arm'],r['g'])]}|{r[idf]}"; v=RNG.get(k)
    if not v: return None
    if v['txt']: return v['txt']
    if v['m'] is None or v['mt']: return None
    rt,tt=RT[k]
    if tt=='Infantry' and rt in('Regular Infantry','Heavy Infantry'): return v['m']+6
    if tt=='Cavalry' and rt in('Heavy Cavalry','Light Cavalry'): return v['m']+9
    return None
def band(slack):
    if slack is None: return None
    if slack>=5: return 'a sure'
    if slack>=2: return 'b 75%+'
    if slack>=0: return 'c long shot'
    return 'd out of range'

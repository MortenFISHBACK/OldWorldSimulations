import json,glob,re,os,sqlite3,collections
D='/mnt/project-files/set-ups-h2h-2026-11-16'
c=sqlite3.connect('/home/user/WarhammerOldWorldSimulator/deploy/seed/oldworldwartable.db')
MV={}
for n,m in c.execute('select Name,Movement from Units'): MV.setdefault(n,m)
out={}; src=collections.Counter()
P1=re.compile(r'it charges up to ([\d.]+)"'); P2=re.compile(r'#(\d+) [^#]*?, staying out of its charge reach \(([\d.]+)"\)')
for f in sorted(glob.glob(D+'/*/game-*.log.jsonl')):
  if '/parts/' in f: continue
  arm=f.split('/')[-2].split('-')[0]; g=os.path.basename(f)[5:-10]
  txt={}; units={}
  for l in open(f):
    if '"kind":"board"' in l:
      for u in json.loads(l)['units']: units[u['id']]=u
      continue
    if '"kind":"action"' not in l: continue
    a=json.loads(l); s=a.get('summary') or ''
    m=P1.search(s)
    if m and a.get('actor_id') and s.startswith('NO CHARGE WHY'): txt[a['actor_id']]=max(txt.get(a['actor_id'],0),float(m.group(1)))
    for m in P2.finditer(s): txt[int(m.group(1))]=max(txt.get(int(m.group(1)),0),float(m.group(2)))
  for uid,u in units.items():
    lk=u['lk']; v=None
    if uid in txt: v=txt[uid]; src['text']+=1
    elif lk.get('mt') is None and lk.get('cn') in MV and MV[lk['cn']]:
      tt,rt=lk.get('tt'),lk.get('rt')
      if tt=='Infantry' and rt in('Regular Infantry','Heavy Infantry'): v=MV[lk['cn']]+6; src['infantry M+6']+=1
      elif tt=='Cavalry' and rt in('Heavy Cavalry','Light Cavalry'): v=MV[lk['cn']]+9; src['cavalry M+9']+=1
    if v is None: src['unknown']+=1
    else: out[f'{arm}|{g}|{uid}']=v
json.dump(out,open('rng3.json','w')); print(src)

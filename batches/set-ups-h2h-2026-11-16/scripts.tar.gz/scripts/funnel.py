import json,collections,re
from cls import cls,R
from why import reach
def movecls(r):
    s=r['mv']
    if not s: return '0 no move at all (no move line)'
    if 'it stays (SAFER THAN THE JOB' in s: return '1 stays: SAFER THAN THE JOB'
    if ': it stays (its objective' in s or 'the first move that serves its objective: it stays' in s: return '1 stays: no reason given'
    if 'FACES THE THREAT' in s or 'way out:' in s or 'STOPS SHORT OF THE FLANK' in s or 'SAFER THAN THE JOB' in s or 'BEST OVERALL' in s: return '2 safety move instead (faces the threat, way out, stops short)'
    if 'fallback' in s or 'no move for the job gets it nearer' in s: return '3 fallback: no move for the job'
    m=re.search(r'the first move that serves its objective: (.*?)\(its objective',s)
    lab=m.group(1) if m else s
    if f"#{r['tid']} " in lab:
        if 'leaves its objective' in s: return '4 turns/reforms to face target only'
        return '5 job move toward target'
    return '6 other move (names another unit or spot)'
def endsets(r):
    s=r['mv']
    ms=re.findall(r"sets up next turn's charge on #(\d+)[^(]*(?:\(if it steps back first: [^(]*)?\(reach (\d+)%\)",s)
    for t,p in ms:
        if int(t)==r['tid']: return 'T',int(p)
    if ms: return 'other',int(ms[0][1])
    m=re.search(r"to face #(\d+) [^(]*for next turn's charge \(reach (\d+)%\)",s)
    if m: return ('T' if int(m.group(1))==r['tid'] else 'other'),int(m.group(2))
    return None,None
if __name__=='__main__':
    ci=[r for r in R if r['kind']=='close in to charge']
    C=collections.defaultdict(collections.Counter)
    for r in ci:
        C[movecls(r)][cls(r)]+=1
    n=len(ci)
    for k in sorted(C):
        t=sum(C[k].values()); ch=sum(v for kk,v in C[k].items() if kk.startswith('CHARGED TARGET')); oth=C[k]['charged another enemy']
        print(f"{k}: {t} ({100*t/n:.0f}%), charged target {ch} ({100*ch/t:.0f}%), charged another {oth} ({100*oth/t:.0f}%)")
        print('     ',C[k].most_common(5))
    # end spot really sets up
    E=collections.defaultdict(collections.Counter)
    for r in ci:
        w,p=endsets(r)
        k='end spot sets up: nothing said' if w is None else ('end spot sets up the TARGET, reach '+('75%+' if p>=75 else '<75%')) if w=='T' else 'end spot sets up ANOTHER enemy'
        E[k][cls(r)]+=1
    for k in sorted(E):
        t=sum(E[k].values()); ch=sum(v for kk,v in E[k].items() if kk.startswith('CHARGED TARGET')); oth=E[k]['charged another enemy']
        print(f"{k}: {t} ({100*t/n:.0f}%), charged target {ch} ({100*ch/t:.0f}%), charged another {oth} ({100*oth/t:.0f}%)")
        print('     ',E[k].most_common(6))

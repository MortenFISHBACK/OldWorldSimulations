import json,glob,os,re,collections
D='/mnt/project-files/set-ups-h2h-2026-11-16'
P=re.compile(r"^PLAN RESULT: [+-][\d.]+ VP: happened=(yes|no) won=([\d.]+) planned=(-?[\d.]+) kind=([a-z ]+?): ")
S=collections.defaultdict(lambda:[0,0,0.0,0.0])
for f in glob.glob(D+'/*/game-*.log.jsonl'):
  arm=os.path.basename(os.path.dirname(f)).split('-')[0]; fx='Mine' if arm=='mine' else 'Opponent'
  for l in open(f):
    if 'PLAN RESULT' not in l: continue
    d=json.loads(l); m=P.match(d.get('summary') or '')
    if not m: continue
    k=('on' if d['side']==fx else 'off',m.group(4)); s=S[k]
    s[0]+=1; s[1]+=m.group(1)=='yes'; s[2]+=float(m.group(3)); s[3]+=float(m.group(2))
print('| Job | Changes on: jobs, happened, planned v won VP a job | Changes off |\n| --- | --- | --- |')
for kind in sorted({k for _,k in S}):
  c=[]
  for b in ('on','off'):
    n,h,pl,w=S[(b,kind)]; c.append(f"{n}, {100*h/n:.0f}%, {pl/n:.0f} v {w/n:.0f}" if n else '-')
  print(f"| {kind} | {c[0]} | {c[1]} |")

import json,collections,os
from cls import cls,R
RN=json.load(open('rng3.json'))
rng=RN
def where(r):
  m=rng.get(f"{r['arm']}|{r['g']}|{r['uid']}")
  if m is None or r['gap1'] is None: return None
  if r['gap1']>m: return 'a outside max charge range'
  if not r['arc1']: return 'b in range, not facing'
  return 'c in range and facing'
ci=[r for r in R if r['kind']=='close in to charge']
for lab,rows in (('ON',[r for r in ci if r['fix']]),('OFF',[r for r in ci if not r['fix']])):
  n=len(rows); c=collections.Counter(cls(r) for r in rows)
  alone=c['CHARGED TARGET alone']; joint=c['CHARGED TARGET joint']
  W=collections.Counter(where(r) for r in rows); kn=n-W[None]
  tog=[r for r in rows if r['together']]
  print(f"{lab}: close-in jobs {n}; charged target next turn {(alone+joint)/n:.1%} (alone {alone/n:.1%}, with a friend {joint/n:.1%}); charged another {c['charged another enemy']/n:.1%}; target gone {c['target gone']/n:.1%}; charged first {c['charged first by the enemy']/n:.1%}")
  print(f"   after own move (known range {kn}): "+', '.join(f"{k[2:]} {W[k]/max(1,kn):.0%}" for k in sorted(k for k in W if k)))
  # ready vs charged
  rd=[r for r in rows if where(r)=='c in range and facing']; cc=collections.Counter(cls(r) for r in rd)
  print(f"   in range+facing: {len(rd)}, charged target {(cc['CHARGED TARGET alone']+cc['CHARGED TARGET joint'])/max(1,len(rd)):.0%}, another {cc['charged another enemy']/max(1,len(rd)):.0%}")
  # pairs on the same enemy in the same turn both ready
  grp=collections.defaultdict(list)
  for r in rows: grp[(r['arm'],r['g'],r['turn'],r['side'],r['tid'])].append(r)
  pairs=[v for v in grp.values() if len(v)>=2]
  both=sum(1 for v in pairs if sum(where(r)=='c in range and facing' for r in v)>=2)
  bothch=sum(1 for v in pairs if sum(r['tid'] in r['decl'] for r in v)>=2)
  print(f"   2+ close-ins on one enemy: {len(pairs)} groups; 2+ ready {both} ({both/max(1,len(pairs)):.0%}); 2+ charged it {bothch} ({bothch/max(1,len(pairs)):.0%}); together-flagged jobs {len(tog)}")

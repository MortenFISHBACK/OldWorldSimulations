import json,collections
R=json.load(open('trace.json'))
def cls(r):
    tid=r['tid']
    if r['u_on2']==0 or r['u_on2'] is None: return 'unit gone'
    if r['next'] is None:
        if r['u_charged']: return 'charged first by the enemy'
        if r['u_fl2']: return 'unit fleeing'
        return 'unit fighting/fleeing/no job'
    if tid in r['decl']: return 'CHARGED TARGET joint' if r['joint'] else 'CHARGED TARGET alone'
    if r['t_on2']==0: return 'target gone'
    if r['decl']: return 'charged another enemy'
    n=r['next']
    if tid in r['offered']:
        return 'charge on target offered, worth below zero'
    if r['cnow'] and 'it can charge now '+r['target'] in r['cnow']:
        return 'charge on target offered, less than its job' if 'less than its objective' in r['cnow'] else 'charge on target offered, worth below zero'
    # no charge on T offered
    same=n['tid']==tid
    if n['kind'] in('close in to charge','advance on'):
        return 'no charge offered: same target again' if same else 'no charge offered: now goes for another enemy'
    return 'no charge offered: other job ('+n['kind']+')'
def table(rows,title):
    C=collections.Counter(cls(r) for r in rows); n=len(rows)
    print(f'## {title}: {n}')
    for k,v in C.most_common(): print(f'  {v:5d} {100*v/n:5.1f}%  {k}')
if __name__=='__main__':
    ci=[r for r in R if r['kind']=='close in to charge']; ad=[r for r in R if r['kind']=='advance on']
    table(ci,'close in'); table(ad,'advance on')
    table([r for r in ci if r['together']],'close in, together')
    table([r for r in ci if r['worth'] is not None and r['worth']>0],'close in worth>0')
    table([r for r in ci if r['worth'] is not None and r['worth']<=0],'close in worth<=0')
    table([r for r in ci if r['fix']],'close in fix side'); table([r for r in ci if not r['fix']],'close in main side')
    import statistics
    print('worth<=0 share', sum(1 for r in ci if r['worth'] is not None and r['worth']<=0)/len(ci), 'only', sum(r['only'] for r in ci)/len(ci))
    print('advance worth<=0', sum(1 for r in ad if r['worth'] is not None and r['worth']<=0)/len(ad), 'only', sum(r['only'] for r in ad)/len(ad))

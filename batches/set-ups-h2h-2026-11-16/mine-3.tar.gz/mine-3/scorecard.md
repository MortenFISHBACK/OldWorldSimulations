# Doctrine scorecard: su-h2h-mine-e45904b-p3

### Scorecard: su-h2h-mine-e45904b-p3

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0110 | 2 | 1 | Mine | - | - | 3 | 1 | 2 | 0 | 0 | 0 | 0 |
| L0110 | 2 | 1 | Opponent | - | - | 2 | 2 | 1 | 0 | 0 | 0 | 330 |
| L0126 | 6 | 1 | Mine | no | 4 | 3 | 3 | 2 | 0 | 0 | 0 | 65 |
| L0126 | 6 | 1 | Opponent | no | 12 | 3 | 3 | 2 | 0 | 0 | 0 | 0 |
| L0210 | 6 | 1 | Mine | no | 0 | 2 | 0 | 4 | 0 | 0 | 0 | 0 |
| L0210 | 6 | 1 | Opponent | no | 11 | 3 | 1 | 0 | 0 | 0 | 0 | 330 |
| L0226 | 4 | 1 | Mine | no | 0 | 2 | 1 | 4 | 0 | 0 | 0 | 170 |
| L0226 | 4 | 1 | Opponent | no | 6 | 2 | 1 | 3 | 1 | 0 | 0 | 0 |
| L0311 | 5 | 1 | Mine | no | - | 5 | 2 | 1 | 0 | 0 | 0 | 590 |
| L0311 | 5 | 1 | Opponent | yes | - | 3 | 1 | 0 | 0 | 0 | 0 | 427 |
| L0327 | 3 | 1 | Mine | yes | 4 | 3 | 1 | 0 | 0 | 0 | 0 | 590 |
| L0327 | 3 | 1 | Opponent | no | 4 | 4 | 2 | 2 | 2 | 0 | 0 | 0 |
| L0413 | 5 | 1 | Mine | yes | - | 2 | 5 | 2 | 0 | 0 | 0 | 0 |
| L0413 | 5 | 1 | Opponent | no | - | 2 | 3 | 0 | 2 | 0 | 0 | 317 |
| L0429 | 3 | 1 | Mine | yes | 2 | 2 | 2 | 2 | 0 | 0 | 0 | 0 |
| L0429 | 3 | 1 | Opponent | no | 0 | 3 | 3 | 1 | 1 | 0 | 0 | 170 |
| L0516 | 6 | 1 | Mine | no | 0 | 4 | 1 | 0 | 0 | 0 | 0 | 666 |
| L0516 | 6 | 1 | Opponent | no | 2 | 2 | 3 | 1 | 0 | 0 | 0 | 200 |
| L0533 | 5 | 1 | Mine | no | - | 5 | 0 | 0 | 0 | 0 | 0 | 548 |
| L0533 | 5 | 1 | Opponent | yes | - | 2 | 2 | 5 | 0 | 0 | 0 | 0 |
| L0620 | 2 | 1 | Mine | - | - | 3 | 3 | 1 | 0 | 0 | 0 | 801 |
| L0620 | 2 | 1 | Opponent | - | - | 4 | 1 | 5 | 1 | 0 | 0 | 210 |
| L0709 | 1 | 1 | Mine | yes | 10 | 4 | 1 | 1 | 1 | 0 | 0 | 375 |
| L0709 | 1 | 1 | Opponent | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 420 |
| L0725 | 5 | 1 | Mine | yes | - | 3 | 2 | 0 | 0 | 0 | 0 | 250 |
| L0725 | 5 | 1 | Opponent | yes | - | 2 | 4 | 0 | 0 | 0 | 0 | 0 |
| L0815 | 5 | 1 | Mine | no | - | 5 | 2 | 0 | 0 | 0 | 0 | 515 |
| L0815 | 5 | 1 | Opponent | yes | - | 2 | 2 | 1 | 0 | 0 | 0 | 115 |
| L0831 | 3 | 1 | Mine | no | 0 | 6 | 1 | 1 | 0 | 0 | 0 | 605 |
| L0831 | 3 | 1 | Opponent | no | 0 | - | 0 | 3 | 1 | 0 | 0 | 170 |
| L0922 | 4 | 1 | Mine | no | 1 | 3 | 1 | 0 | 0 | 0 | 0 | 596 |
| L0922 | 4 | 1 | Opponent | no | 0 | 2 | 2 | 2 | 2 | 0 | 0 | 55 |
| L1013 | 5 | 1 | Mine | yes | - | 2 | 2 | 1 | 2 | 0 | 0 | 330 |
| L1013 | 5 | 1 | Opponent | no | - | 1 | 1 | 3 | 0 | 0 | 0 | 302 |
| L1030 | 4 | 1 | Mine | no | 4 | 2 | 3 | 0 | 0 | 0 | 0 | 501 |
| L1030 | 4 | 1 | Opponent | no | 0 | 2 | 2 | 3 | 1 | 0 | 0 | 0 |
| L1122 | 6 | 1 | Mine | no | 0 | 3 | 2 | 1 | 0 | 0 | 0 | 330 |
| L1122 | 6 | 1 | Opponent | no | 0 | 2 | 3 | 2 | 0 | 0 | 0 | 144 |
| L1216 | 4 | 1 | Mine | no | 2 | 2 | 2 | 0 | 1 | 0 | 0 | 330 |
| L1216 | 4 | 1 | Opponent | no | 1 | 2 | 0 | 2 | 0 | 0 | 0 | 200 |
| L1232 | 2 | 1 | Mine | - | - | 4 | 1 | 0 | 1 | 0 | 0 | 330 |
| L1232 | 2 | 1 | Opponent | - | - | 2 | 2 | 3 | 1 | 0 | 0 | 170 |
| L1327 | 1 | 1 | Mine | no | 11 | 4 | 1 | 0 | 1 | 0 | 0 | 140 |
| L1327 | 1 | 1 | Opponent | no | 4 | 1 | 6 | 2 | 0 | 0 | 0 | 0 |
| L1422 | 6 | 1 | Mine | no | 8 | 3 | 2 | 1 | 0 | 0 | 0 | 177 |
| L1422 | 6 | 1 | Opponent | no | 0 | 2 | 4 | 0 | 1 | 0 | 0 | 0 |
| L1519 | 1 | 1 | Mine | no | 0 | 2 | 5 | 0 | 1 | 0 | 0 | 0 |
| L1519 | 1 | 1 | Opponent | no | 0 | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L1535 | 5 | 1 | Mine | yes | - | 2 | 1 | 0 | 1 | 0 | 0 | 0 |
| L1535 | 5 | 1 | Opponent | yes | - | 3 | 1 | 1 | 1 | 0 | 0 | 388 |
| L1633 | 1 | 1 | Mine | no | 1 | 2 | 2 | 1 | 0 | 0 | 0 | 200 |
| L1633 | 1 | 1 | Opponent | no | 0 | 1 | 3 | 3 | 0 | 0 | 0 | 144 |
| L1731 | 3 | 1 | Mine | yes | 1 | - | 3 | 0 | 1 | 0 | 0 | 49 |
| L1731 | 3 | 1 | Opponent | no | 2 | 2 | 1 | 1 | 4 | 0 | 0 | 340 |
| L1831 | 1 | 1 | Mine | no | 4 | 3 | 3 | 0 | 1 | 0 | 0 | 0 |
| L1831 | 1 | 1 | Opponent | no | 2 | 6 | 2 | 1 | 0 | 0 | 0 | 0 |
| L1932 | 6 | 1 | Mine | no | 2 | 2 | 2 | 1 | 0 | 0 | 0 | 491 |
| L1932 | 6 | 1 | Opponent | no | 0 | 2 | 4 | 3 | 1 | 0 | 0 | 340 |
| L2033 | 5 | 1 | Mine | yes | - | 4 | 1 | 6 | 0 | 0 | 0 | 210 |
| L2033 | 5 | 1 | Opponent | yes | - | 6 | 0 | 3 | 0 | 0 | 0 | 0 |
| L2223 | 3 | 1 | Mine | no | 3 | 1 | 4 | 1 | 1 | 0 | 0 | 170 |
| L2223 | 3 | 1 | Opponent | no | 4 | 2 | 6 | 0 | 0 | 0 | 0 | 0 |
| L2327 | 5 | 1 | Mine | yes | - | 2 | 3 | 0 | 0 | 0 | 0 | 185 |
| L2327 | 5 | 1 | Opponent | yes | - | 3 | 5 | 3 | 0 | 0 | 0 | 0 |
| L2433 | 3 | 1 | Mine | no | 3 | 3 | 3 | 1 | 0 | 0 | 0 | 0 |
| L2433 | 3 | 1 | Opponent | no | 0 | 2 | 6 | 2 | 0 | 0 | 0 | 0 |
| L2630 | 2 | 1 | Mine | - | - | 3 | 3 | 3 | 0 | 0 | 0 | 0 |
| L2630 | 2 | 1 | Opponent | - | - | 2 | 3 | 4 | 0 | 0 | 0 | 0 |
| L2832 | 6 | 1 | Mine | no | 1 | - | 0 | 1 | 1 | 0 | 0 | 0 |
| L2832 | 6 | 1 | Opponent | yes | 9 | 2 | 2 | 4 | 1 | 0 | 0 | 0 |
| L3133 | 1 | 1 | Mine | no | 0 | 2 | 2 | 2 | 1 | 0 | 0 | 170 |
| L3133 | 1 | 1 | Opponent | no | 8 | 3 | 1 | 3 | 0 | 0 | 0 | 405 |
| **Average** | | | Mine | 31% | 2.7 | 3.0 | 2.0 | 1.1 | 0.4 | 0.0 | 0.0 | 260.7 |
| **Average** | | | Opponent | 25% | 2.8 | 2.5 | 2.4 | 2.0 | 0.6 | 0.0 | 0.0 | 143.8 |

### KPIs: su-h2h-mine-e45904b-p3

Rules off - Opponent only: SET-UP SPOT, CARRIES OUT CLOSE-IN, JOINT AS ONE.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 24% (41 of 174) | 12% (21 of 173) | 18% (62 of 347) |
| Winner chose to follow up after the loser gave ground |  | 95% (55 of 58); on the table 98% | 100% (47 of 47); on the table 100% | 97% (102 of 105); on the table 99% |
| Winner chose to pursue after the loser fell back in good order |  | 100% (7 of 7); on the table 100% | 92% (11 of 12); on the table 92% | 95% (18 of 19); on the table 95% |
| Winner chose to pursue after the loser fled |  | 56% (9 of 16); on the table 81% | 77% (20 of 26); on the table 81% | 69% (29 of 42); on the table 81% |
| Winner chose to follow up or pursue (all three) |  | 88% (71 of 81); on the table 95% | 92% (78 of 85); on the table 93% | 90% (149 of 166); on the table 94% |
| Magic missiles tried each own turn | 50%+ | 34% (115 of 342) | 48% (92 of 192) | 39% (207 of 534) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 48% (115 of 242) | 56% (92 of 163) | 51% (207 of 405) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 47% (9 of 19) | 60% (40 of 67) | 57% (49 of 86) |
| Points that never fought | lower | 41% (28377 of 68801) | 40% (28832 of 71990) | 41% (57209 of 140791) |
|   infantry points that never fought | lower | 53% (7480 of 14174) | 56% (8030 of 14220) | 55% (15510 of 28394) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 56% (153 of 272) | 59% (167 of 285) | 57% (320 of 557) |
| Bound items with a magic missile used (at least once a game) |  | 100% (25 of 25); 2.2 uses a game | 88% (21 of 24); 2.2 uses a game | 94% (46 of 49); 2.2 uses a game |
| Bound items with another spell used |  | 29% (4 of 14); 0.3 uses a game | 50% (3 of 6); 0.2 uses a game | 35% (7 of 20); 0.2 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 50% (10 of 20); 0.3 uses a game | 43% (6 of 14); 0.2 uses a game | 47% (16 of 34); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 52% (30800 of 59391) | 54% (34572 of 64043) | 53% (65372 of 123434) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.6 (25%) | 0.8 (30%) | 2.4 (26%) |
| MARCHED: its unit marched | 1.4 (22%) | 0.6 (23%) | 2.0 (22%) |
| CHARGED: its unit charged | 0.3 (5%) | 0.2 (9%) | 0.6 (6%) |
| IN COMBAT: engaged in combat | 1.2 (19%) | 0.4 (13%) | 1.5 (17%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.2 (8%) | 0.2 (3%) |
| FLEEING: fleeing | 0.2 (3%) | 0.0 (0%) | 0.2 (2%) |
| GONE: slain | 1.3 (20%) | 0.4 (13%) | 1.6 (18%) |
| OFF THE TABLE: off the table or not arrived | 0.2 (3%) | 0.1 (3%) | 0.2 (3%) |
| STUPIDITY: Stupidity | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (1%) | 0.0 (1%) | 0.1 (1%) |
| NOT OFFERED: not in the cast list | 0.1 (2%) | 0.0 (0%) | 0.1 (2%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.7 | 1.2 | 1.9 | 5.8 | 0.9 | 1.5 |
| not cast | 4.1 | 1.4 | 4.2 | 9.1 | 2.3 | 19.2 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) | 0.0 (0%) | 0.8 (4%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.1 (1%) | 0.6 (41%) | 0.3 (7%) | 2.4 (26%) | 0.3 (13%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.0 (22%) | 0.4 (18%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.6 (6%) | 0.1 (2%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.2 (4%) | 0.2 (12%) | 0.5 (12%) | 1.5 (17%) | 0.3 (13%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.2 (4%) | 0.0 (0%) | 0.2 (6%) | 0.2 (3%) | 0.1 (4%) | 0.0 (0%) |
| FLEEING: fleeing | 0.2 (5%) | 0.0 (0%) | 0.2 (4%) | 0.2 (2%) | 0.1 (2%) | 0.4 (2%) |
| GONE: slain | 1.2 (30%) | 0.4 (27%) | 1.2 (29%) | 1.6 (18%) | 0.6 (25%) | 3.9 (20%) |
| OFF THE TABLE: off the table or not arrived | 0.1 (3%) | 0.0 (0%) | 0.1 (3%) | 0.2 (3%) | 0.1 (4%) | 0.2 (1%) |
| STUPIDITY: Stupidity | 0.0 (1%) | 0.0 (0%) | 0.1 (1%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.2 (5%) | 0.0 (0%) | 0.0 (1%) | 0.1 (1%) | 0.4 (19%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (2%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.9 (47%) | 0.3 (20%) | 1.5 (35%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 13.8 (72%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.3 a game | 0.7 a game | 1.0 a game |
| stood (cast and not dispelled) | 51% (20 of 39) | 33% (6 of 18) | 46% (26 of 57) |
| the unit moved after it | 75% (15 of 20) | 83% (5 of 6) | 77% (20 of 26) |
| it charged on its next turn | 5% (1 of 20) | 17% (1 of 6) | 8% (2 of 26) |
| the enemy charged it first | 15% (3 of 20) | 33% (2 of 6) | 19% (5 of 26) |
| it fought by the end of its next turn | 10% (2 of 20) | 17% (1 of 6) | 12% (3 of 26) |
| it moved out of a charge the enemy had planned (not charged first) | 40% (8 of 20) | 17% (1 of 6) | 35% (9 of 26) |
| none of these (no charge, no fight, no charge escaped) | 40% (8 of 20) | 33% (2 of 6) | 38% (10 of 26) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 67% (515 of 764) | 56% (354 of 627) | 62% (869 of 1391) |
|   cavalry | 65% (40 of 62) | 59% (67 of 114) | 61% (107 of 176) |
|   character | 64% (57 of 89) | 21% (23 of 111) | 40% (80 of 200) |
|   chariot | 48% (48 of 99) | 52% (14 of 27) | 49% (62 of 126) |
|   infantry | 58% (124 of 213) | 63% (174 of 278) | 61% (298 of 491) |
|   monster | 42% (17 of 40) | 33% (1 of 3) | 42% (18 of 43) |
|   war machine | 88% (229 of 261) | 80% (75 of 94) | 86% (304 of 355) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.2 (33%) | 1.9 (25%) | 4.1 (28%) |
| CHARGED: it charged | 0.7 (10%) | 1.5 (20%) | 2.2 (15%) |
| FLEEING: it fled or was fleeing | 0.0 (0%) | 0.0 (0%) | 0.1 (0%) |
| IN COMBAT: it fought this turn or the last | 0.7 (10%) | 0.6 (8%) | 1.3 (9%) |
| MOVED: a war machine that moved | 0.1 (1%) | 0.0 (0%) | 0.1 (0%) |
| NO TARGET IN RANGE | 0.9 (14%) | 1.2 (16%) | 2.1 (15%) |
| ONLY IN COMBAT: the only targets were in combat | 0.5 (7%) | 0.4 (5%) | 0.9 (6%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.4 (21%) | 1.4 (19%) | 2.9 (20%) |
| SHELTERED: the target was sheltered | 0.1 (2%) | 0.2 (3%) | 0.3 (2%) |
| STUPIDITY | 0.0 (0%) | 0.1 (1%) | 0.1 (1%) |
| OTHER BAR | 0.2 (4%) | 0.3 (4%) | 0.5 (4%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 4.6 | 0.9 | 84% | 4.7 pts | 22 pts |
| character | 2.7 | 1.3 | 73% | 7.9 pts | 21 pts |
| chariot | 1.7 | 0.9 | 69% | 16.6 pts | 29 pts |
| infantry | 12.8 | 4.3 | 75% | 9.9 pts | 127 pts |
| monster | 0.6 | 0.4 | 76% | 16.3 pts | 10 pts |
| war machine | 8.8 | 7.9 | 59% | 24.6 pts | 216 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.2 | 5.1 | 4.2 |
| Charges that made contact a game | 2.4 | 3.4 | 2.9 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.46 declared, 0.42 contact (24 units) | 0.62 declared, 0.25 contact (16 units) | 0.53 declared, 0.35 contact (40 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.25 declared, 0.00 contact (4 units) | 0.78 declared, 0.44 contact (9 units) | 0.62 declared, 0.31 contact (13 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.45 declared, 0.34 contact (229 units) | 0.63 declared, 0.44 contact (264 units) | 0.55 declared, 0.39 contact (493 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 51% (39 of 77) | 53% (8 of 15) | 30% (3 of 10) | 49% (50 of 102) |
| Character in a unit | 82% (27 of 33) | 67% (12 of 18) | 57% (4 of 7) | 74% (43 of 58) |
| Character on its own | 75% (33 of 44) | 50% (19 of 38) | 40% (27 of 68) | 53% (79 of 150) |
| Chariot | 82% (9 of 11) | 67% (8 of 12) | - | 74% (17 of 23) |
| Infantry | 56% (39 of 70) | 55% (23 of 42) | 40% (2 of 5) | 55% (64 of 117) |
| Monster | 62% (21 of 34) | 57% (4 of 7) | - | 61% (25 of 41) |
| Monstrous | 70% (7 of 10) | 55% (6 of 11) | - | 62% (13 of 21) |
| War Machines | 63% (27 of 43) | 100% (2 of 2) | - | 64% (29 of 45) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 100% (10 of 10); on the table 100% | 45% (43 of 96) | 56% | 68% (15 of 22) | 100% (6 of 6); 6.2 uses a game | 50% (1 of 2); 0.8 uses a game | 67% (4 of 6); 1.0 uses a game |
| Chaos Dwarfs | 4 | 58% (7 of 12); on the table 92% | 36% (13 of 36) | 45% | 53% (17 of 32) | 0.0 uses a game | 0.0 uses a game | 100% (2 of 2); 0.5 uses a game |
| Dwarfen Mountain Holds | 3 | 100% (5 of 5); on the table 100% | - | 67% | 75% (18 of 24) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 6 | 89% (8 of 9); on the table 89% | 27% (8 of 30) | 54% | 64% (38 of 59) | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game | 25% (1 of 4); 0.2 uses a game |
| Grand Cathay | 8 | 91% (10 of 11); on the table 100% | 44% (85 of 192) | 54% | 54% (40 of 74) | 94% (17 of 18); 6.8 uses a game | 25% (1 of 4); 0.1 uses a game | 25% (2 of 8); 0.2 uses a game |
| High Elf Realms | 7 | 78% (18 of 23); on the table 83% | 26% (11 of 42) | 31% | 48% (26 of 54) | 100% (9 of 9); 4.0 uses a game | 42% (5 of 12); 2.0 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 3 | 100% (3 of 3); on the table 100% | - | 42% | 28% (5 of 18) | 0.0 uses a game | 0.0 uses a game | 100% (3 of 3); 1.0 uses a game |
| Lizardmen | 1 | 100% (1 of 1); on the table 100% | 33% (2 of 6) | 33% | 57% (4 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 1 | - | 0% (0 of 6) | 15% | 71% (5 of 7) | 100% (1 of 1); 5.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 2 | 75% (3 of 4); on the table 100% | 25% (3 of 12) | 3% | 69% (11 of 16) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |
| Skaven | 2 | 100% (2 of 2); on the table 100% | 8% (1 of 12) | 74% | 57% (8 of 14) | 0.0 uses a game | 0.0 uses a game | 100% (2 of 2); 1.0 uses a game |
| Tomb Kings of Khemri | 6 | 100% (13 of 13); on the table 100% | 0% (0 of 6) | 35% | 46% (12 of 26) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 8 | 91% (21 of 23); on the table 91% | 44% (24 of 54) | 30% | 54% (25 of 46) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 11 | 95% (36 of 38); on the table 95% | 50% (15 of 30) | 37% | 60% (58 of 96) | 100% (4 of 4); 1.1 uses a game | 0.0 uses a game | 100% (2 of 2); 0.2 uses a game |
| Wood Elf Realms | 6 | 100% (12 of 12); on the table 100% | 17% (2 of 12) | 28% | 61% (38 of 62) | 82% (9 of 11); 5.8 uses a game | 0.0 uses a game | 0% (0 of 5); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (su-h2h-mine-e45904b-p3, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 54% (43) | 52% (32) | 53% (75) |
| ...free all their last turn and able to turn (per game) | 0.83 | 0.56 | 1.39 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.17 | 0.17 | 0.33 |
| ...with the charger already in that arc before they moved (per game) | 0.53 | 0.39 | 0.92 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 2.47 | 1.31 | 3.78 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 1.00 | 0.58 | 1.58 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 6.06 | 5.50 | 11.56 |

### Quality by phase: su-h2h-mine-e45904b-p3

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.2 | 3.6 |
| Strategy | Charge objectives carried out (made contact) | 59% (63 of 106) | 45% (68 of 151) |
| Strategy | Shoot objectives carried out (shot that target) | 47% (193 of 408) | 52% (124 of 240) |
| Strategy | Close-in objectives charged next turn | 17% (21 of 122) | 13% (27 of 210) |
| Strategy | Support requests answered (helper made contact too) | 55% (6 of 11) | 45% (13 of 29) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (4 of 4) | 67% (2 of 3) |
| Strategy | Hexes on a unit its side charged or shot that turn | 25% (2 of 8) | 62% (5 of 8) |
| Strategy | Joined characters whose unit fought | 37% (15 of 41) | 32% (14 of 44) |
| Strategy | Lone characters that fought | 69% (65 of 94) | 78% (70 of 90) |
| Movement | Charges halted short of contact | 0.1 | 0.3 |
| Movement | Idle units | 1.1 | 2.0 |
| Movement | Points that never moved of their own | 260.7 | 143.8 |
| Movement | Fights charged into per game | 2.2 | 2.9 |
| Movement | Charges with odds: long shots (under 50%) | 7 of 73, net +30 | 19 of 87, net +116 |
| Movement | Charges with odds: sweet spot (55-75%) | 14 of 73, net +189 | 15 of 87, net +115 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 9 of 73, net +142 | 4 of 87, net +42 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 20 of 73, net +115 | 23 of 87, net +105 |
| Shooting | Shots by shooting units (incl. breath weapons) | 8.7 | 9.5 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 40% (126 of 312) | 52% (178 of 341) |
| Shooting | Points destroyed by shooting units | 64.9 | 72.4 |
| Shooting | War machine shots | 6.4 | 2.4 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 51% (117 of 229) | 41% (35 of 86) |
| Shooting | Points destroyed by war machines | 86.7 | 20.8 |
| Magic | Magic missiles cast | 2.1 | 1.8 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 40% (31 of 77) | 39% (25 of 64) |
| Magic | Wounds caused by magic missiles | 3.9 | 2.3 |
| Magic | Wounds caused by other spells | 1.4 | 0.7 |
| Magic | Points destroyed by magic (all spells) | 87.9 | 45.3 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.2 / 0.2 / 0.6 / 0.1 | 2.1 / 0.3 / 0.3 / 0.4 |
| Combat | Points destroyed in combat | 302.8 | 292.4 |
| Combat | Points run down | 67.9 | 106.4 |
| Combat | Net points per charged fight, damage counted | +102 | +78 |
| Combat | Net per 100 charger points, damage counted | +36.3 | +26.6 |
| Combat | First round won (charged fights) | 82% | 75% |
| Combat | Net points per charged fight | +102 | +78 |
| Combat | Net points per supported fight / lone fight | +92 / +103 | +256 / +46 |
| Combat | Charged fights on a top-3 enemy unit | 27 of 80 | 52 of 104 |
| Game | Points lost | 705.9 | 667.0 |
| Game | VP from objectives | 566.1 | 624.7 |
| Game | Lone holders (player turns) | 2.7 | 2.8 |

- Mine won / drew / lost: 10 / 13 / 13 of 36 ended games (of 36); mean margin (Mine - Opponent) -99 VP
- The side that went first won 9 of 23 games with a winner
- Points traded per game (both sides' losses): 1373
- Games not ended: 0; findings 0, warnings 1

### Opponent rules: su-h2h-mine-e45904b-p3

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.6 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 0.0 |
| ALREADY CARRIED | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARRIVAL HUNT | 0.0 | +0.0 | 0.0 | 2.5 | 0.1 | +0.5 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.5 | +0.0 | 0.0 | 47.8 | 0.2 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | 1.1 | +8.1 | 0.0 | 0.0 | 0.9 | +9.1 | 0.0 | 40.7 |
| BEST FACING | 1.1 | +65.3 | 0.0 | 47.8 | 0.8 | +54.2 | 0.0 | 24.8 |
| BEST FIRST | 4.9 | +210.4 | 182.3 | 122.5 | 4.0 | +154.5 | 174.4 | 86.6 |
| BEST OVERALL | 0.7 | +40.1 | 0.0 | 13.7 | 0.7 | +60.7 | 0.0 | 1.8 |
| BEST PREY | 0.7 | +46.6 | 36.6 | 25.6 | 0.6 | +22.5 | 17.4 | 0.0 |
| BEST PRIZE | - | - | - | - | 0.1 | +2.2 | 6.9 | 0.0 |
| BIG CHARACTER SAFETY | 0.3 | -1.2 | 0.0 | 11.1 | 0.1 | -0.2 | 0.0 | 0.0 |
| BLOCKED CHARGE SKIPPED | 0.1 | +0.0 | 19.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| BLOCKED WHEEL | 0.3 | +1.8 | 0.0 | 0.0 | 0.3 | +3.9 | 0.0 | 0.0 |
| BLOWS WHERE AIMED | 0.2 | -17.5 | 20.0 | 3.2 | 0.2 | -22.7 | 50.5 | 5.4 |
| BOMBING RUN | 0.1 | +1.5 | 0.0 | 0.0 | - | - | - | - |
| CANNON PLAN MISSED | 0.4 | +0.0 | 36.8 | 10.0 | 0.3 | +0.0 | 47.8 | 0.0 |
| CANNON PLANNED TARGET | 5.6 | +167.2 | 329.8 | 97.6 | 1.6 | +64.8 | 118.7 | 18.9 |
| CANNON SIGHT KEPT | 1.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT CLOSE-IN | 0.3 | -0.3 | 28.6 | 0.0 | - | - | - | - |
| CARRIES OUT COUNTER | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | -0.6 | 3.2 | 0.0 |
| CARRIES OUT SET-UP | 0.2 | -11.0 | 11.9 | 22.3 | 0.1 | +0.0 | 5.1 | 3.2 |
| CAST JOB | 1.2 | +36.8 | 70.4 | 15.8 | 0.6 | +14.4 | 22.4 | 28.8 |
| CASTER AWAY FROM SCREEN | 0.2 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.5 | +39.4 | 17.1 | 0.0 | 0.1 | +2.9 | 7.9 | 0.0 |
| CASTS AFTER FRIENDS | 0.7 | +0.0 | 0.0 | 67.5 | 0.2 | +0.0 | 0.0 | 16.4 |
| CASTS FROM BEHIND | 0.0 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CATCH ODDS | 0.0 | +0.4 | 0.0 | 0.0 | - | - | - | - |
| CHAFF PASSED | 0.2 | -0.7 | 0.0 | 3.8 | 0.2 | -0.5 | 0.0 | 0.0 |
| CHARGE BAND | 0.1 | +0.0 | 7.9 | 10.5 | 0.2 | +0.0 | 36.0 | 0.0 |
| CHARGE NOW FIRST | 1.7 | +0.0 | 141.4 | 70.0 | 2.0 | +0.0 | 179.4 | 105.3 |
| CHARGE NOW WEIGHED | 0.8 | -57.0 | 30.2 | 25.1 | 0.6 | -60.7 | 17.8 | 16.3 |
| CHARGER SLAIN LOST | 0.4 | -6.3 | 23.2 | 6.1 | 0.9 | -17.1 | 81.2 | 16.6 |
| CHARIOT NO STATIC JOB | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHARIOT WIZARD CAREFUL | 0.1 | -1.8 | 0.0 | 0.0 | 0.2 | -2.6 | 0.0 | 22.2 |
| CHEAP HELPER | 0.1 | +0.0 | 0.0 | 1.8 | 0.1 | +0.0 | 4.2 | 2.0 |
| COMBAT PIVOT | 0.5 | +0.0 | 12.4 | 64.6 | 0.4 | +0.0 | 38.5 | 26.8 |
| CONTINUE AHEAD WEIGHED | 0.0 | +0.0 | 0.0 | 0.0 | 0.0 | +0.0 | 1.2 | 0.0 |
| CONVEYANCE SEARCH | 0.8 | +99.1 | 30.0 | 33.6 | 0.4 | +41.7 | 11.1 | 30.5 |
| COUNTER-CHARGE COVER | 10.1 | +919.6 | 0.0 | 236.2 | 7.5 | +704.8 | 0.0 | 152.1 |
| DEFENSIVE ARMY | 0.1 | +0.0 | 31.7 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| EDGE GIVE GROUND | 0.1 | +9.0 | 12.8 | 0.0 | 0.1 | +1.4 | 0.0 | 1.2 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 2.5 | +218.2 | 0.0 | 79.9 | 1.3 | +115.6 | 0.0 | 46.8 |
| FALLBACK BY WORTH | 4.3 | +51.9 | 0.0 | 57.7 | 5.6 | +86.1 | 0.0 | 20.6 |
| FIGHT LIFT | 0.1 | +0.3 | 1.7 | 11.0 | 0.1 | +1.5 | 0.0 | 0.0 |
| FIRE AND FLEE | 0.0 | +0.4 | 0.0 | 2.2 | - | - | - | - |
| FLANK NOT WEIGHED | 6.8 | +0.0 | 0.0 | 175.1 | 5.4 | +0.0 | 0.0 | 135.1 |
| FOCUS FIRE | - | - | - | - | 0.1 | +1.3 | 0.0 | 0.0 |
| FOLLOW UP WEIGHED | 1.0 | +140.8 | 0.0 | 31.1 | 1.0 | +157.2 | 0.0 | 0.0 |
| FRIENDS SHOTS CHECKED | 0.2 | +13.2 | 0.0 | 29.0 | 0.1 | +7.5 | 0.0 | 0.0 |
| GIVES UP | 0.1 | -1.8 | 10.9 | 0.0 | 0.1 | -1.5 | 11.9 | 0.0 |
| GIVES UP ITS SCREEN | - | - | - | - | 0.0 | -0.0 | 9.4 | 0.0 |
| GROUND FLIERS | 0.1 | +4.4 | 0.0 | 0.0 | - | - | - | - |
| HELPER ALREADY ASKED | - | - | - | - | 0.0 | +0.0 | 8.9 | 0.0 |
| HELPER UNSEEN | 0.2 | +0.0 | 11.0 | 19.7 | 0.4 | +0.0 | 68.5 | 0.0 |
| HILL BY ITS CHANCE | 0.2 | -48.3 | 0.0 | 0.0 | 0.5 | -70.8 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 6.6 | -106.1 | 276.5 | 203.5 | 7.8 | -185.9 | 366.2 | 196.5 |
| HORN WORTH | - | - | - | - | 0.0 | +0.4 | 0.0 | 0.0 |
| HUNT ADVANCE | 0.1 | +10.0 | 9.2 | 6.2 | 0.1 | +3.1 | 3.5 | 0.0 |
| HUNT DROPPED | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 2.0 |
| HUNT IN PAIRS | 0.4 | +27.7 | 0.0 | 5.7 | 1.0 | +83.9 | 0.0 | 59.8 |
| HUNT KEPT | 0.1 | +5.7 | 4.6 | 3.9 | 0.0 | +1.1 | 0.0 | 0.0 |
| HUNT RESULT | 0.1 | +9.3 | 0.0 | 3.9 | 0.3 | +43.8 | 3.5 | 3.2 |
| HUNT THE GUNS | 0.1 | +54.3 | 4.6 | 3.8 | 0.3 | +101.2 | 17.5 | 0.0 |
| INVITES THE FIGHT | 1.8 | +36.8 | 15.1 | 48.9 | 1.1 | +21.2 | 39.3 | 21.1 |
| JOINT AS ONE | 2.6 | -31.3 | 75.4 | 97.9 | - | - | - | - |
| JOINT CHARGE PLAN | 0.1 | +6.1 | 4.8 | 3.2 | 0.3 | +9.9 | 0.0 | 3.2 |
| JOINT KNOWS CHALLENGE | - | - | - | - | 0.1 | -11.8 | 16.8 | 3.2 |
| KEEP FALLS | 0.1 | +4.2 | 0.0 | 14.3 | 0.0 | +0.1 | 0.0 | 0.0 |
| KEEPS ITS PREY | 0.0 | +0.2 | 0.0 | 0.0 | 0.1 | +0.3 | 0.0 | 0.0 |
| KEEPS ITS TARGET | 1.3 | +40.0 | 99.4 | 65.6 | 2.0 | +59.2 | 159.6 | 24.2 |
| KEEPS SCOUTS OR AMBUSH | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KILLS COUNT | 1.4 | +58.4 | 81.7 | 43.6 | 1.6 | +73.4 | 119.8 | 63.6 |
| KILLS COUNT NEXT TURN | 3.8 | +124.4 | 136.5 | 87.1 | 6.9 | +250.2 | 234.7 | 118.2 |
| LONE CHARACTER SAFE SPOT | 0.3 | +6.2 | 0.0 | 7.0 | 0.4 | +6.7 | 21.4 | 29.3 |
| LONE WIZARD HOLDS BACK | 0.0 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 7.2 | 12.9 |
| LONE WIZARD KEPT IN | 0.6 | +37.3 | 0.0 | 0.0 | 0.4 | +25.4 | 0.0 | 0.0 |
| LONG SHOT | 0.4 | +3.5 | 8.0 | 18.5 | 0.3 | -1.3 | 17.6 | 4.3 |
| LOST CHARGE | 3.1 | -61.5 | 111.3 | 126.3 | 2.4 | -39.5 | 120.0 | 61.4 |
| LURE BY WHAT IT DRAWS | - | - | - | - | 0.1 | -5.8 | 0.0 | 1.5 |
| MAKE SURE TOGETHER | 0.8 | +80.6 | 14.4 | 35.7 | 0.6 | +59.7 | 0.0 | 6.4 |
| MANOEUVRE | 0.2 | +4.0 | 0.0 | 12.8 | 0.1 | +3.1 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.2 | +1.5 | 0.0 | 7.2 | - | - | - | - |
| MARCH CHECK | 0.8 | +43.1 | 0.0 | 21.8 | 0.6 | +24.6 | 0.0 | 11.1 |
| MARCH ODDS | 0.4 | +22.1 | 10.3 | 11.1 | 0.3 | +15.1 | 7.1 | 0.0 |
| MARCH OVER CASTS | 0.6 | +63.2 | 0.0 | 30.4 | 0.3 | +31.8 | 0.0 | 22.2 |
| MAX FOR POSITIONING | 5.0 | +199.2 | 0.0 | 150.5 | 4.5 | +189.4 | 0.0 | 147.3 |
| MISSILES IN THE MOVE | 4.4 | +145.3 | 0.0 | 106.4 | 4.6 | +81.3 | 0.0 | 94.9 |
| MISSILES NEXT TURN | 5.4 | +96.0 | 0.0 | 147.3 | 5.3 | +58.8 | 0.0 | 109.0 |
| MODEL FACING | 0.1 | +33.0 | 0.0 | 1.7 | - | - | - | - |
| MONSTER WIZARD ROAMS | 0.2 | +0.0 | 15.9 | 17.8 | 0.1 | +0.0 | 0.0 | 0.0 |
| MOVE AND CAST | 0.5 | +29.9 | 0.0 | 0.0 | 0.5 | +30.4 | 0.0 | 10.2 |
| MOVE SPELL IN RANGE | 0.2 | +4.0 | 0.0 | 10.6 | 0.0 | +0.7 | 0.0 | 7.6 |
| MOVE SPELL OUT OF RANGE | 0.5 | -12.2 | 0.0 | 55.3 | 0.1 | -0.8 | 0.0 | 13.0 |
| MOVE SPELL SPOT | 0.3 | +0.0 | 0.0 | 46.6 | 0.1 | +0.0 | 0.0 | 11.1 |
| MOVE TO CHARGE | 2.3 | +176.2 | 87.4 | 89.8 | 4.4 | +450.2 | 99.6 | 63.7 |
| MOVES UNITS SPELL | 0.1 | +3.6 | 0.0 | 0.0 | 0.1 | +0.3 | 0.0 | 0.0 |
| NEEDED THERE | 0.1 | +17.9 | 3.5 | 0.0 | 0.1 | +11.1 | 12.2 | 0.0 |
| NO CHARGE WHY | 2.1 | +0.0 | 105.2 | 56.8 | 3.9 | +0.0 | 174.7 | 98.6 |
| NO RALLY LEFT | - | - | - | - | 0.0 | +5.9 | 0.0 | 0.0 |
| NOT NEEDED | 0.1 | -9.4 | 12.0 | 13.4 | 0.2 | -13.2 | 42.6 | 5.2 |
| NOT TURNED | 6.1 | +102.2 | 0.0 | 142.2 | 5.5 | -6.5 | 0.0 | 89.7 |
| NOT WORTH A CAST | 0.6 | -0.4 | 0.0 | 24.2 | 0.8 | -1.2 | 0.0 | 7.6 |
| OFF BEST | 16.6 | -900.5 | 0.0 | 268.4 | 14.3 | -846.1 | 5.2 | 285.8 |
| OPENS A LANE | 0.2 | +0.4 | 23.3 | 0.0 | 0.2 | +1.6 | 69.4 | 20.5 |
| OPENS UP | 0.1 | +2.6 | 4.7 | 0.0 | 0.1 | +8.6 | 7.9 | 5.4 |
| OVERRUNS AWAY | 0.4 | +6.7 | 30.2 | 33.4 | 0.4 | +8.2 | 40.7 | 21.4 |
| PATHS CROSS | 1.9 | +171.2 | 0.0 | 34.1 | 2.4 | +192.9 | 0.0 | 47.4 |
| PERIAPT WORTH | 0.0 | +2.8 | 0.0 | 0.0 | 0.0 | +1.5 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.1 | -1.7 | 0.0 | 16.1 | 0.1 | -0.7 | 0.0 | 2.4 |
| PLAN RESULT | 36.6 | +1081.7 | 1337.0 | 955.0 | 38.4 | +1418.3 | 1374.6 | 882.9 |
| PURSUES BIG PREY | 0.0 | -0.9 | 0.0 | 0.0 | 0.1 | -19.0 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE | - | - | - | - | 0.0 | +4.9 | 0.0 | 1.5 |
| RAIDS THE BAGGAGE NEXT TURN | 0.1 | +4.9 | 0.0 | 0.0 | 0.1 | +3.5 | 0.0 | 1.5 |
| RANDOM MOVE BY FIGURES | 0.5 | +5.2 | 0.0 | 18.9 | 1.9 | +43.4 | 0.0 | 51.9 |
| RANDOM MOVER NO PROMISE | 0.1 | -5.0 | 0.0 | 0.0 | 0.5 | -33.5 | 30.3 | 4.7 |
| REDIRECT BY WHAT IT STOPS | 0.5 | -14.4 | 0.0 | 2.7 | 0.8 | -18.1 | 0.0 | 2.1 |
| REDIRECT COUNTER | 1.7 | +130.1 | 0.0 | 31.7 | 3.8 | +293.1 | 0.0 | 47.5 |
| REDIRECT WEIGHED | 0.2 | +3.0 | 5.7 | 16.8 | 0.4 | +8.8 | 6.9 | 1.2 |
| REFUSING RETIRES | 0.2 | +0.0 | 0.0 | 3.2 | 0.3 | +0.0 | 0.0 | 3.2 |
| RESERVE FALL BACK | 0.5 | +9.4 | 0.0 | 0.0 | 0.9 | +37.4 | 0.0 | 18.8 |
| RESTRAINS TO SHOOT | 0.1 | +1.3 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | 2.0 | +85.6 | 129.3 | 67.5 | 2.5 | +85.7 | 206.3 | 92.1 |
| SAFER THAN THE JOB | 1.0 | +67.7 | 0.0 | 30.7 | 0.6 | +37.1 | 0.0 | 0.0 |
| SCOUT SPOT | 0.4 | +0.6 | 0.0 | 0.9 | 0.3 | +1.0 | 0.0 | 0.0 |
| SCOUT WAITS | 0.4 | +0.0 | 0.0 | 0.9 | 0.3 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.0 | -1.3 | 0.0 | 0.9 | 0.4 | -26.9 | 0.0 | 2.8 |
| SEARCH SPOT | 2.3 | +120.0 | 0.0 | 50.7 | 2.6 | +117.9 | 0.0 | 33.6 |
| SECOND HUNTER | 0.0 | -1.2 | 0.0 | 0.0 | - | - | - | - |
| SELF MOVE SPELL | 0.4 | +57.7 | 0.0 | 21.9 | 0.2 | +54.3 | 0.0 | 0.0 |
| SET UP TOGETHER | 1.1 | +110.0 | 18.8 | 54.0 | 1.5 | +152.1 | 0.0 | 31.6 |
| SET-UP ANY TARGET | 0.5 | +79.4 | 30.0 | 23.7 | 0.2 | +28.2 | 0.0 | 6.5 |
| SET-UP MISSED | 0.1 | +6.2 | 0.0 | 0.0 | - | - | - | - |
| SET-UP SPOT | 3.9 | +109.2 | 50.7 | 97.2 | - | - | - | - |
| SHOOTER COUNTED ONCE | - | - | - | - | 0.1 | -0.2 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.4 | +0.7 | 0.0 | 0.0 | 0.1 | +0.3 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.2 | +34.7 | 44.7 | 3.0 | 0.9 | +36.8 | 27.8 | 8.8 |
| SHORT GUN FORWARD | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SHOT REPLANNED | 0.6 | +0.0 | 138.2 | 8.2 | 0.1 | +0.0 | 33.2 | 0.0 |
| SHOTS IN THE MOVE | 14.6 | +558.0 | 0.0 | 268.5 | 9.8 | +426.2 | 0.0 | 85.5 |
| SPELL OFF EDGE | 0.0 | +8.7 | 13.9 | 0.0 | - | - | - | - |
| SPELL SETS UP CHARGE | 0.6 | +87.9 | 30.0 | 23.7 | 0.2 | +32.3 | 11.1 | 17.6 |
| SPELL WORTH | 1.3 | +21.5 | 70.8 | 99.8 | 2.5 | +38.3 | 117.9 | 117.9 |
| SPELLS IN THE FIGHT | 0.2 | -2.1 | 18.2 | 0.0 | 0.6 | -9.6 | 83.2 | 53.2 |
| STABLE ROLE | 10.8 | +0.0 | 359.5 | 173.8 | 9.0 | +0.0 | 293.1 | 124.9 |
| STANDS TO CAST | 0.0 | +0.4 | 0.0 | 0.0 | - | - | - | - |
| STOPS | 0.1 | +4.2 | 0.0 | 1.5 | 0.2 | +4.5 | 14.0 | 0.0 |
| STOPS SHORT OF THE FLANK | 0.5 | +22.0 | 0.0 | 38.1 | 0.4 | +27.9 | 0.0 | 0.0 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 4.7 |
| SUPPORT NARROWED | 4.8 | -45.8 | 266.9 | 105.5 | 6.7 | -70.4 | 340.6 | 114.0 |
| SUPPORTS | 3.3 | +54.7 | 181.1 | 62.4 | 4.7 | +72.3 | 160.7 | 31.8 |
| SURE CHARGE BEATS ADVANCE | 0.1 | -1.7 | 5.6 | 0.0 | 0.1 | -3.4 | 12.7 | 13.9 |
| SURE REACH TOGETHER | 0.3 | -0.3 | 14.4 | 4.2 | 0.4 | -13.1 | 0.0 | 0.0 |
| THROUGH LINE OF FIRE | 0.4 | +11.9 | 0.0 | 11.9 | 0.2 | +21.7 | 0.0 | 2.0 |
| TURN WORTH | 0.1 | -5.4 | 8.3 | 0.0 | 0.3 | -21.0 | 24.4 | 8.4 |
| TWO OR MORE ARRIVE | 0.3 | +1.7 | 0.0 | 34.5 | 0.4 | +7.3 | 0.0 | 8.5 |
| WAIT AFTER COSTS | 6.1 | -306.2 | 147.1 | 168.3 | 6.7 | -390.0 | 169.4 | 112.2 |
| WALKS TO THE FIGHT | 1.6 | +33.1 | 24.6 | 19.0 | 0.6 | +7.0 | 4.9 | 11.1 |
| WAR ENGINE CHARGES | 0.1 | +5.8 | 4.7 | 8.6 | - | - | - | - |
| WAR ENGINE JOBS | 0.8 | +0.0 | 52.4 | 26.4 | 0.1 | +0.0 | 0.0 | 3.8 |
| WEARS DOWN | 0.9 | +37.8 | 51.6 | 23.6 | 1.0 | +40.7 | 157.4 | 26.7 |
| WHO HITS BACK | 0.4 | +29.7 | 0.0 | 29.6 | 0.3 | +24.5 | 0.0 | 4.2 |
| WHOLE FIGHT | 0.3 | +13.2 | 46.8 | 8.6 | 0.4 | +16.5 | 50.8 | 0.5 |
| WHOLE FIGHT GAIN | 0.2 | +15.2 | 18.1 | 0.0 | 0.7 | +40.3 | 65.8 | 20.8 |
| WIDER SPREAD | 1.7 | -5.3 | 125.7 | 38.1 | 3.0 | -5.3 | 267.4 | 62.1 |
| WOUNDED STAYS OUT | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |

### Rule changes: su-h2h-mine-e45904b-p3

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 1112 | 1112 | 1112 | 30.89 | -62881 | -56.5 |
| BEST FIRST | 318 | 318 | 318 | 8.83 | +13137 | +41.3 |
| SEARCH SPOT | 178 | 178 | 176 | 4.89 | +8585 | +48.8 |
| COUNTER-CHARGE COVER | 633 | 346 | 157 | 4.36 | +10961 | +69.8 |
| PATHS CROSS | 155 | 155 | 155 | 4.31 | +13106 | +84.6 |
| FACES THE THREAT | 136 | 136 | 136 | 3.78 | +12015 | +88.3 |
| MOVE TO CHARGE | 243 | 243 | 135 | 3.75 | +9184 | +68.0 |
| KILLS COUNT NEXT TURN | 386 | 386 | 110 | 3.06 | +2763 | +25.1 |
| SUPPORTS | 288 | 288 | 104 | 2.89 | +1375 | +13.2 |
| FALLBACK BY WORTH | 355 | 355 | 82 | 2.28 | +4970 | +60.6 |
| SET-UP SPOT | 139 | 139 | 81 | 2.25 | +3806 | +47.0 |
| FOLLOW UP WEIGHED | 71 | 71 | 71 | 1.97 | +10730 | +151.1 |
| BEST FACING | 65 | 65 | 65 | 1.81 | +4305 | +66.2 |
| SHOTS IN THE MOVE | 879 | 593 | 63 | 1.75 | +2046 | +32.5 |
| ARTILLERY RE-ROLL WEIGHED | 61 | 61 | 61 | 1.69 | +0 | +0.0 |
| WAIT AFTER COSTS | 460 | 460 | 61 | 1.69 | +1050 | +17.2 |
| SAFER THAN THE JOB | 57 | 57 | 57 | 1.58 | +3773 | +66.2 |
| CANNON SIGHT KEPT | 56 | 56 | 56 | 1.56 | +0 | +0.0 |
| CHARGE NOW WEIGHED | 53 | 53 | 53 | 1.47 | +3349 | +63.2 |
| BEST OVERALL | 52 | 52 | 52 | 1.44 | +3629 | +69.8 |
| CANNON PLANNED TARGET | 257 | 257 | 49 | 1.36 | -1292 | -26.4 |
| MAX FOR POSITIONING | 340 | 180 | 49 | 1.36 | +467 | +9.5 |
| RANDOM MOVE BY FIGURES | 86 | 86 | 49 | 1.36 | +1750 | +35.7 |
| RESERVE FALL BACK | 49 | 49 | 49 | 1.36 | +1683 | +34.3 |
| REDIRECT COUNTER | 198 | 105 | 46 | 1.28 | +3676 | +79.9 |
| WALKS TO THE FIGHT | 80 | 80 | 44 | 1.22 | +679 | +15.4 |
| MARCH CHECK | 49 | 47 | 43 | 1.19 | +2563 | +59.6 |
| SET UP TOGETHER | 91 | 79 | 42 | 1.17 | +2760 | +65.7 |
| RISK BY ARC | 163 | 157 | 40 | 1.11 | +1446 | +36.1 |
| HOLDS AMBUSHERS | 39 | 39 | 39 | 1.08 | +0 | +0.0 |
| MISSILES IN THE MOVE | 324 | 174 | 39 | 1.08 | +596 | +15.3 |
| CAST JOB | 64 | 64 | 38 | 1.06 | +886 | +23.3 |
| MOVE AND CAST | 36 | 36 | 36 | 1.00 | +2172 | +60.3 |
| ADVANCE LANE KEPT | 35 | 35 | 35 | 0.97 | +0 | +0.0 |
| CHARGE NOW FIRST | 133 | 133 | 34 | 0.94 | -1957 | -57.6 |
| SHOOTS FROM THE BEST SPOT | 75 | 75 | 34 | 0.94 | +1313 | +38.6 |
| LONE WIZARD KEPT IN | 33 | 33 | 33 | 0.92 | +2259 | +68.5 |
| STOPS SHORT OF THE FLANK | 32 | 32 | 32 | 0.89 | +1795 | +56.1 |
| COMBAT PIVOT | 31 | 31 | 31 | 0.86 | +0 | +0.0 |
| HONEST WORTH | 521 | 515 | 27 | 0.75 | +205 | +7.6 |
| INVITES THE FIGHT | 103 | 103 | 26 | 0.72 | +384 | +14.8 |
| KEEPS ITS TARGET | 119 | 117 | 26 | 0.72 | +494 | +19.0 |
| MARCH ODDS | 28 | 28 | 26 | 0.72 | +90 | +3.5 |
| SHOT REPLANNED | 26 | 26 | 26 | 0.72 | +0 | +0.0 |
| WHO HITS BACK | 26 | 26 | 26 | 0.72 | +1502 | +57.8 |
| KILLS COUNT | 110 | 105 | 25 | 0.69 | +1431 | +57.2 |
| SCOUT WAITS | 25 | 25 | 25 | 0.69 | +0 | +0.0 |
| THROUGH LINE OF FIRE | 24 | 24 | 24 | 0.67 | +1208 | +50.3 |
| BLOCKED WHEEL | 21 | 21 | 21 | 0.58 | +205 | +9.8 |
| REDIRECT WEIGHED | 21 | 21 | 21 | 0.58 | +894 | +42.5 |
| CASTING BLOCK | 22 | 22 | 20 | 0.56 | +975 | +48.7 |
| SHOOTERS IN TWO RANKS | 18 | 18 | 18 | 0.50 | +36 | +2.0 |
| BEST PREY | 45 | 45 | 17 | 0.47 | +448 | +26.4 |
| BIG CHARACTER SAFETY | 15 | 15 | 15 | 0.42 | -50 | -3.4 |
| WEARS DOWN | 68 | 67 | 14 | 0.39 | +589 | +42.1 |
| CHAFF PASSED | 13 | 13 | 13 | 0.36 | -43 | -3.3 |
| HUNT IN PAIRS | 52 | 29 | 13 | 0.36 | +471 | +36.2 |
| FRIENDS SHOTS CHECKED | 12 | 12 | 12 | 0.33 | +746 | +62.2 |
| REFUSING RETIRES | 20 | 20 | 12 | 0.33 | -2 | -0.2 |
| WHOLE FIGHT GAIN | 33 | 32 | 12 | 0.33 | +508 | +42.4 |
| MISSILES NEXT TURN | 387 | 213 | 11 | 0.31 | +31 | +2.8 |
| STUCK PIVOT | 11 | 11 | 11 | 0.31 | +0 | +0.0 |
| MAKE SURE TOGETHER | 50 | 33 | 10 | 0.28 | +849 | +84.9 |
| MANOEUVRE | 13 | 13 | 10 | 0.28 | +260 | +26.1 |
| WAR ENGINE JOBS | 31 | 31 | 10 | 0.28 | -224 | -22.4 |
| CASTER AWAY FROM SCREEN | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| CASTS FROM BEHIND | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| LOST CHARGE | 197 | 197 | 9 | 0.25 | +296 | +32.9 |
| CHARGE BAND | 8 | 8 | 8 | 0.22 | +0 | +0.0 |
| PIVOT GUARDS FLANK | 8 | 8 | 8 | 0.22 | -86 | -10.8 |
| BLOCKED CHARGE SKIPPED | 7 | 7 | 7 | 0.19 | +0 | +0.0 |
| JOINT AS ONE | 94 | 94 | 7 | 0.19 | -144 | -20.6 |
| MOVES UNITS SPELL | 7 | 7 | 7 | 0.19 | +141 | +20.1 |
| SURE CHARGE BEATS ADVANCE | 7 | 7 | 7 | 0.19 | -181 | -25.8 |
| KEEP FALLS | 6 | 6 | 6 | 0.17 | +259 | +43.2 |
| LONE WIZARD HOLDS BACK | 15 | 15 | 6 | 0.17 | -395 | -65.8 |
| OVERRUNS AWAY | 29 | 28 | 6 | 0.17 | +31 | +5.2 |
| WIDER SPREAD | 168 | 161 | 6 | 0.17 | +21 | +3.5 |
| OPENS UP | 7 | 6 | 5 | 0.14 | +108 | +21.6 |
| SHORT GUN FORWARD | 5 | 5 | 5 | 0.14 | +0 | +0.0 |
| SUPPORT NARROWED | 412 | 412 | 5 | 0.14 | -209 | -41.7 |
| CHARIOT NO STATIC JOB | 4 | 4 | 4 | 0.11 | -347 | -86.8 |
| MODEL FACING | 4 | 4 | 4 | 0.11 | +1186 | +296.6 |
| NEEDED THERE | 4 | 4 | 4 | 0.11 | +0 | +0.0 |
| PURSUES BIG PREY | 4 | 4 | 4 | 0.11 | -717 | -179.3 |
| RAIDS THE BAGGAGE NEXT TURN | 4 | 4 | 4 | 0.11 | +98 | +24.5 |
| WHOLE FIGHT | 24 | 24 | 4 | 0.11 | +177 | +44.2 |
| BACKUP TARGETS | 72 | 34 | 3 | 0.08 | +20 | +6.8 |
| BEST PRIZE | 3 | 3 | 3 | 0.08 | -14 | -4.7 |
| BOMBING RUN | 3 | 3 | 3 | 0.08 | +53 | +17.8 |
| LONG SHOT | 27 | 26 | 3 | 0.08 | +68 | +22.6 |
| SURE REACH TOGETHER | 28 | 22 | 3 | 0.08 | +43 | +14.3 |
| CARRIES OUT SET-UP | 8 | 8 | 2 | 0.06 | -394 | -197.1 |
| CONTINUE AHEAD WEIGHED | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| EDGE GIVE GROUND | 10 | 10 | 2 | 0.06 | +236 | +118.0 |
| FOCUS FIRE | 2 | 2 | 2 | 0.06 | +47 | +23.6 |
| PERIAPT WORTH | 2 | 2 | 2 | 0.06 | +154 | +76.9 |
| REDIRECT BY WHAT IT STOPS | 45 | 45 | 2 | 0.06 | +121 | +60.3 |
| RESTRAINS TO SHOOT | 2 | 2 | 2 | 0.06 | +47 | +23.6 |
| CARRIES OUT CLOSE-IN | 10 | 10 | 1 | 0.03 | -10 | -9.9 |
| CARRIES OUT COUNTER | 3 | 3 | 1 | 0.03 | -23 | -22.8 |
| CATCH ODDS | 1 | 1 | 1 | 0.03 | -2 | -1.8 |
| FIRE AND FLEE | 1 | 1 | 1 | 0.03 | +15 | +15.1 |
| HILL BY ITS CHANCE | 28 | 28 | 1 | 0.03 | +3 | +3.2 |
| HORN WORTH | 1 | 1 | 1 | 0.03 | +14 | +13.5 |
| HUNT ADVANCE | 9 | 9 | 1 | 0.03 | +48 | +48.1 |
| JOINT CHARGE PLAN | 15 | 15 | 1 | 0.03 | +3 | +3.0 |
| KEEPS SCOUTS OR AMBUSH | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| NO RALLY LEFT | 1 | 1 | 1 | 0.03 | +137 | +136.6 |
| RAIDS THE BAGGAGE | 1 | 1 | 1 | 0.03 | +146 | +145.6 |
| STANDS TO CAST | 1 | 1 | 1 | 0.03 | -12 | -12.1 |
| STOPS | 12 | 12 | 1 | 0.03 | +28 | +28.3 |
| ALREADY CARRIED | 1 | not checked | - | - | - | - |
| ARRIVAL HUNT | 3 | 3 | 0 | 0.00 | - | - |
| BLOWS WHERE AIMED | 16 | 15 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 25 | 25 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 33 | trace | - | - | - | - |
| CHARGER SLAIN LOST | 46 | 46 | 0 | 0.00 | - | - |
| CHARIOT WIZARD CAREFUL | 8 | 8 | 0 | 0.00 | - | - |
| CHEAP HELPER | 6 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 41 | not checked | - | - | - | - |
| DEFENSIVE ARMY | 7 | 7 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT LIFT | 4 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 439 | not checked | - | - | - | - |
| GIVES UP | 4 | 4 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 1 | 1 | 0 | 0.00 | - | - |
| GROUND FLIERS | 2 | not checked | - | - | - | - |
| HELPER ALREADY ASKED | 1 | not checked | - | - | - | - |
| HELPER UNSEEN | 22 | 22 | 0 | 0.00 | - | - |
| HUNT DROPPED | 6 | trace | - | - | - | - |
| HUNT KEPT | 6 | trace | - | - | - | - |
| HUNT RESULT | 15 | trace | - | - | - | - |
| HUNT THE GUNS | 15 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 5 | 3 | 0 | 0.00 | - | - |
| KEEPS ITS PREY | 3 | 3 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 25 | not checked | - | - | - | - |
| LURE BY WHAT IT DRAWS | 3 | 3 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 6 | trace | - | - | - | - |
| MARCH OVER CASTS | 33 | 33 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 12 | 12 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 8 | 3 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 20 | trace | - | - | - | - |
| MOVE SPELL SPOT | 17 | not checked | - | - | - | - |
| NO CHARGE WHY | 217 | not checked | - | - | - | - |
| NOT NEEDED | 13 | 13 | 0 | 0.00 | - | - |
| NOT TURNED | 416 | 416 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 51 | not checked | - | - | - | - |
| OPENS A LANE | 15 | 7 | 0 | 0.00 | - | - |
| PLAN RESULT | 2702 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 21 | 21 | 0 | 0.00 | - | - |
| SCOUT SPOT | 24 | 24 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 14 | 14 | 0 | 0.00 | - | - |
| SECOND HUNTER | 1 | 1 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 21 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 26 | not checked | - | - | - | - |
| SET-UP MISSED | 2 | trace | - | - | - | - |
| SHOOTER COUNTED ONCE | 2 | 2 | 0 | 0.00 | - | - |
| SPELL OFF EDGE | 1 | not checked | - | - | - | - |
| SPELL SETS UP CHARGE | 29 | not checked | - | - | - | - |
| SPELL WORTH | 136 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 28 | 28 | 0 | 0.00 | - | - |
| STABLE ROLE | 710 | 709 | 0 | 0.00 | - | - |
| TURN WORTH | 13 | 13 | 0 | 0.00 | - | - |
| TWO OR MORE ARRIVE | 27 | 23 | 0 | 0.00 | - | - |
| WAR ENGINE CHARGES | 2 | 2 | 0 | 0.00 | - | - |
| WOUNDED STAYS OUT | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: su-h2h-mine-e45904b-p3

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 14.53 | 12.31 | 57.6 |
| FALLBACK | gate | 0.78 | 0.75 | 53.2 |
| TURN GATE | gate | 0.69 | 0.69 | 43.6 |
| CHARGE NOW FIRST | rule | 0.47 | 0.47 | 57.6 |
| CANNON PLANNED TARGET | rule | 0.42 | 0.22 | 64.1 |
| LONE CHARACTER SAFE SPOT | gate | 0.08 | 0.28 | 106.0 |
| NO REASON | gate | 0.33 | - | 12.1 |
| WAR ENGINE JOBS | rule | 0.25 | 0.03 | 22.4 |
| CHAFF PASSED | rule | 0.06 | 0.17 | 5.3 |
| PIVOT GUARDS FLANK | rule | 0.14 | 0.08 | 10.8 |
| CHARGE NOW WEIGHED | rule | 0.14 | 0.06 | 43.0 |
| JOINT AS ONE | rule | 0.19 | - | 20.6 |
| PATHS CROSS | rule | 0.08 | 0.11 | 12.2 |
| SURE CHARGE BEATS ADVANCE | rule | 0.11 | 0.08 | 25.8 |
| BIG CHARACTER SAFETY | rule | 0.14 | 0.03 | 14.8 |
| MARCH ODDS | rule | 0.11 | 0.06 | 12.7 |
| SUPPORT REQUEST | gate | 0.06 | 0.11 | 86.2 |
| AFTERMATH BAND | gate | 0.03 | 0.11 | 1.7 |
| LONE WIZARD HOLDS BACK | rule | 0.03 | 0.11 | 79.0 |
| SET-UP SPOT | rule | 0.14 | - | 18.5 |
| SUPPORT NARROWED | rule | 0.08 | 0.06 | 41.7 |
| CHARIOT NO STATIC JOB | rule | 0.11 | - | 86.8 |
| FIGHT ORDER BAND | gate | 0.06 | 0.06 | 1.7 |
| PURSUES BIG PREY | rule | 0.03 | 0.08 | 179.3 |
| STOPS SHORT OF THE FLANK | rule | 0.08 | 0.03 | 15.1 |
| BEST PRIZE | rule | - | 0.08 | 4.7 |
| BLOCKED WHEEL | rule | 0.06 | - | 25.1 |
| CARRIES OUT SET-UP | rule | 0.06 | - | 197.1 |
| FALLBACK BY WORTH | rule | - | 0.06 | 8.6 |
| REDIRECT WEIGHED | rule | - | 0.06 | 4.0 |
| THROUGH LINE OF FIRE | rule | 0.06 | - | 2.4 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.03 | - | 69.4 |
| CARRIES OUT CLOSE-IN | rule | 0.03 | - | 9.9 |
| CARRIES OUT COUNTER | rule | - | 0.03 | 22.8 |
| CATCH ODDS | rule | 0.03 | - | 1.8 |
| FACES THE THREAT | rule | 0.03 | - | 10.2 |
| LONG SHOT | rule | - | 0.03 | 38.8 |
| REFUSING RETIRES | rule | 0.03 | - | 0.7 |
| SAFER THAN THE JOB | rule | 0.03 | - | 18.1 |
| STANDS TO CAST | rule | 0.03 | - | 12.1 |

### Plans: su-h2h-mine-e45904b-p3

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 12.6 | 14% | 435 | 260 | 60% |
| Mine | charge | 2.3 | 60% | 210 | 203 | 97% |
| Mine | close in | 3.4 | 25% | 180 | 99 | 55% |
| Mine | hold | 4.6 | 43% | 286 | 0 | 0% |
| Mine | join | 0.4 | 71% | 7 | 0 | 0% |
| Mine | shoot | 9.6 | 56% | 223 | 521 | 233% |
| Mine | support | 3.8 | 92% | 33 | 0 | 0% |
| Opponent | advance | 13.1 | 20% | 344 | 434 | 126% |
| Opponent | charge | 3.7 | 56% | 229 | 335 | 146% |
| Opponent | close in | 5.8 | 16% | 404 | 161 | 40% |
| Opponent | hold | 4.0 | 31% | 296 | 0 | 0% |
| Opponent | join | 0.9 | 94% | 33 | 0 | 0% |
| Opponent | shoot | 5.5 | 58% | 207 | 488 | 235% |
| Opponent | support | 5.6 | 92% | 51 | 0 | 0% |

### Packages: hunt the guns, su-h2h-mine-e45904b-p3

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.1 | 5 | 0 | 0% | 20% | 0% | 3.0 | 391 | 67 | 20% | 49 |
| Opponent | 0.3 | 10 | 0 | 40% | 50% | 0% | 2.0 | 364 | 158 | 50% | 95 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 1.2 | 5 | 0 | 0% | 20% | 0% | 3.0 | 391 | 67 | 20% | 68 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 145 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 32 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 63 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 54 |
| High Elf Realms | 0.3 | 2 | 0 | 100% | 100% | 0% | 2.0 | 566 | 466 | 100% | 16 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 33 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Orc & Goblin Tribes | 0.5 | 1 | 0 | 0% | 0% | 0% | - | 446 | 0 | 0% | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 302 |
| Tomb Kings of Khemri | 0.3 | 2 | 0 | 0% | 50% | 0% | 2.0 | 320 | 106 | 50% | 110 |
| Vampire Counts | 0.2 | 2 | 0 | 100% | 100% | 0% | 2.0 | 253 | 216 | 100% | 45 |
| Warriors of Chaos | 0.1 | 1 | 0 | 0% | 0% | 0% | - | 415 | 0 | 0% | 94 |
| Wood Elf Realms | 0.3 | 2 | 0 | 0% | 0% | 0% | - | 251 | 0 | 0% | 95 |

### Battle groups: su-h2h-mine-e45904b-p3

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 10.1 | 20% | 58% | 9% | 14% | 22% | 19% | 9% | 49% | 0% |
| Mine | REDIRECT COUNTER | 1.7 | 27% | 59% | 12% | 50% | 27% | 7% | 13% | 53% | 0% |
| Opponent | COUNTER-CHARGE COVER | 7.5 | 13% | 61% | 19% | 57% | 41% | 3% | 7% | 48% | 0% |
| Opponent | REDIRECT COUNTER | 3.8 | 23% | 65% | 3% | 100% | 13% | 0% | 3% | 80% | 3% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: su-h2h-mine-e45904b-p3

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 1 | 0 (1) | 0 | 0 | 100 | 0% | 4.0 | - | 0 (1) | - | 0 (1) | - |
| Mine | Chaff | 34 | 43 (34) | 6 | 37 | 51 | 38% | 2.8 | 49 (21) | 0 (4) | 42 (9) | 64 (24) | 0 (10) |
| Mine | Character | 118 | 38 (118) | 38 | 0 | 39 | 21% | 2.5 | 55 (36) | 34 (64) | 11 (5) | 38 (62) | 45 (43) |
| Mine | Clean-up | 18 | 75 (18) | 34 | 40 | 67 | 33% | 2.5 | 92 (3) | 64 (13) | 164 (2) | 93 (12) | 46 (6) |
| Mine | Fast | 1 | 58 (1) | 58 | 0 | 0 | 0% | 2.0 | - | 58 (1) | - | 58 (1) | - |
| Mine | Fast Hammer | 44 | 41 (44) | 24 | 17 | 37 | 23% | 2.9 | 33 (22) | 30 (14) | 84 (8) | 48 (30) | 29 (14) |
| Mine | Fragile | 3 | 19 (3) | 19 | 0 | 100 | 33% | 3.0 | 19 (3) | - | - | 29 (1) | 15 (2) |
| Mine | Hammer | 52 | 37 (52) | 21 | 16 | 28 | 27% | 3.0 | 17 (14) | 45 (35) | 33 (3) | 43 (36) | 25 (16) |
| Mine | Holder | 25 | 40 (25) | 5 | 35 | 20 | 52% | 2.9 | 50 (8) | 32 (11) | 63 (5) | 74 (12) | 8 (12) |
| Mine | Shooter | 37 | 84 (37) | 44 | 40 | 42 | 0% | 2.0 | 77 (6) | 93 (28) | 19 (3) | 86 (23) | 81 (14) |
| Mine | Support | 4 | 33 (4) | 33 | 0 | 81 | 0% | 2.2 | 0 (1) | 0 (2) | - | 0 (1) | 0 (2) |
| Mine | War machine | 52 | 53 (52) | 53 | 0 | 37 | 2% | 1.1 | 29 (13) | 62 (36) | 55 (3) | 24 (13) | 63 (39) |
| Mine | Wizard | 17 | 32 (17) | 32 | 0 | 36 | 6% | 2.8 | 17 (3) | 56 (7) | 125 (1) | 75 (6) | 16 (5) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 0% | 5.0 | - | 0 (1) | - | - | 0 (1) |
| Opponent | Chaff | 68 | 69 (68) | 11 | 58 | 53 | 46% | 2.8 | 26 (29) | 209 (11) | 33 (28) | 83 (48) | 37 (20) |
| Opponent | Character | 102 | 47 (102) | 47 | 0 | 35 | 19% | 2.3 | 54 (38) | 49 (50) | 19 (6) | 47 (54) | 53 (40) |
| Opponent | Clean-up | 11 | 40 (11) | 0 | 40 | 32 | 27% | 4.2 | 0 (4) | 40 (6) | 204 (1) | 36 (6) | 43 (5) |
| Opponent | Fast | 1 | 60 (1) | 60 | 0 | 0 | 0% | 6.0 | - | 60 (1) | - | 60 (1) | - |
| Opponent | Fast Hammer | 60 | 41 (60) | 25 | 16 | 42 | 32% | 3.0 | 37 (30) | 26 (20) | 89 (10) | 55 (28) | 28 (32) |
| Opponent | Fragile | 3 | 0 (3) | 0 | 0 | 100 | 33% | 2.5 | - | 0 (2) | 0 (1) | 0 (2) | 0 (1) |
| Opponent | Hammer | 50 | 51 (50) | 24 | 27 | 32 | 30% | 2.9 | 31 (17) | 61 (30) | 0 (3) | 43 (30) | 62 (20) |
| Opponent | Holder | 40 | 57 (40) | 15 | 41 | 20 | 48% | 2.5 | 11 (10) | 68 (21) | 90 (9) | 52 (28) | 66 (12) |
| Opponent | Shooter | 27 | 46 (27) | 18 | 28 | 39 | 4% | 1.1 | 58 (6) | 27 (19) | 279 (2) | 45 (16) | 47 (11) |
| Opponent | Support | 4 | 0 (4) | 0 | 0 | 0 | 100% | - | 0 (2) | 0 (1) | 0 (1) | 0 (3) | 0 (1) |
| Opponent | War machine | 17 | 86 (17) | 86 | 0 | 24 | 6% | 1.4 | 142 (3) | 100 (10) | 26 (4) | 190 (3) | 68 (14) |
| Opponent | Wizard | 32 | 32 (32) | 32 | 0 | 30 | 19% | 2.3 | 13 (16) | 55 (7) | 0 (3) | 29 (14) | 0 (12) |

### Charged fights: su-h2h-mine-e45904b-p3

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 65 | 74 | 1.8 | 1.3 | 42 | 48 | -6 | 3 of 7 | 5 of 7 | +68 | -35 |
| Mine | Chaos Dwarfs | 4 | 204 | 589 | 2.5 | 1.0 | 236 | 0 | +236 | 7 of 10 | 9 of 10 | - | +236 |
| Mine | Dwarfen Mountain Holds | 3 | 385 | 34 | 1.3 | 1.0 | 26 | 16 | +10 | 0 of 4 | 4 of 4 | - | +10 |
| Mine | Empire of Man | 5 | 304 | 79 | 1.2 | 1.0 | 66 | 6 | +60 | 2 of 6 | 5 of 6 | - | +60 |
| Mine | Grand Cathay | 5 | 544 | 134 | 2.0 | 1.1 | 67 | 67 | +0 | 2 of 10 | 7 of 10 | +98 | -10 |
| Mine | High Elf Realms | 4 | 351 | 788 | 3.5 | 1.3 | 225 | 8 | +217 | 6 of 14 | 14 of 14 | +100 | +264 |
| Mine | Kingdom of Bretonnia | 1 | 123 | 722 | 3.0 | 1.3 | 241 | 0 | +241 | 1 of 3 | 2 of 3 | +342 | +190 |
| Mine | Lizardmen | 1 | 232 | 116 | 2.0 | 1.0 | 58 | 42 | +16 | 0 of 2 | 2 of 2 | - | +16 |
| Mine | Ogre Kingdoms | 1 | 116 | 120 | 2.0 | 1.0 | 60 | 45 | +15 | 0 of 2 | 2 of 2 | - | +15 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 583 | 4.0 | 1.0 | 146 | 14 | +132 | 0 of 4 | 3 of 4 | - | +132 |
| Mine | Skaven | 1 | 38 | 258 | 1.0 | 1.0 | 258 | 0 | +258 | 0 of 1 | 1 of 1 | - | +258 |
| Mine | Tomb Kings of Khemri | 2 | 0 | 473 | 3.5 | 1.0 | 135 | 9 | +126 | 2 of 7 | 7 of 7 | - | +126 |
| Mine | Vampire Counts | 2 | 0 | 342 | 3.5 | 1.0 | 98 | 82 | +15 | 3 of 7 | 3 of 7 | - | +15 |
| Mine | Warriors of Chaos | 2 | 122 | 72 | 1.5 | 1.3 | 48 | 95 | -47 | 1 of 3 | 2 of 3 | -142 | +0 |
| **Mine** | all armies | 36 | 240 | 293 | 2.2 | 1.1 | 132 | 30 | +102 | 27 of 80 | 66 of 80 | +92 | +103 |
| Opponent | Empire of Man | 1 | 380 | 0 | 1.0 | 1.0 | 0 | 444 | -444 | 1 of 1 | 1 of 1 | - | -444 |
| Opponent | Grand Cathay | 3 | 320 | 211 | 1.7 | 1.6 | 126 | 0 | +126 | 3 of 5 | 4 of 5 | +274 | +28 |
| Opponent | High Elf Realms | 3 | 510 | 169 | 2.7 | 1.0 | 64 | 62 | +1 | 4 of 8 | 6 of 8 | - | +1 |
| Opponent | Kingdom of Bretonnia | 2 | 48 | 514 | 3.0 | 1.5 | 171 | 0 | +171 | 3 of 6 | 4 of 6 | +292 | +111 |
| Opponent | Orc & Goblin Tribes | 1 | 0 | 60 | 5.0 | 1.2 | 12 | 85 | -73 | 3 of 5 | 3 of 5 | +0 | -92 |
| Opponent | Skaven | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Tomb Kings of Khemri | 4 | 136 | 406 | 3.8 | 1.1 | 108 | 5 | +104 | 11 of 15 | 10 of 15 | +369 | +85 |
| Opponent | Vampire Counts | 6 | 14 | 482 | 4.3 | 1.1 | 111 | 6 | +105 | 11 of 26 | 20 of 26 | +140 | +102 |
| Opponent | Warriors of Chaos | 9 | 45 | 381 | 2.6 | 1.2 | 149 | 29 | +120 | 13 of 23 | 19 of 23 | +297 | +71 |
| Opponent | Wood Elf Realms | 6 | 164 | 231 | 2.5 | 1.2 | 92 | 77 | +16 | 3 of 15 | 10 of 14 | +277 | -50 |
| **Opponent** | all armies | 36 | 138 | 321 | 2.9 | 1.2 | 111 | 33 | +78 | 52 of 104 | 77 of 103 | +256 | +46 |

### Effective charges: su-h2h-mine-e45904b-p3

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 7 | 1 (net +0) | 0 | 0 | 2 (net +50) | 0 | 1 (net +135) | 3 | 0% (0 of 4) |
| Mine | Chaos Dwarfs | 10 | 0 | 0 | 2 (net +221) | 5 (net +298) | 0 | 2 (net +111) | 1 | 22% (2 of 9) |
| Mine | Dwarfen Mountain Holds | 4 | 0 | 1 (net -65) | 1 (net +38) | 1 (net +0) | 0 | 1 (net +65) | 0 | 25% (1 of 4) |
| Mine | Empire of Man | 6 | 0 | 1 (net -36) | 0 | 2 (net +161) | 1 (net +72) | 2 (net +0) | 0 | 0% (0 of 6) |
| Mine | Grand Cathay | 10 | 1 (net +0) | 1 (net -205) | 2 (net -22) | 2 (net +96) | 2 (net +85) | 2 (net -54) | 0 | 20% (2 of 10) |
| Mine | High Elf Realms | 14 | 1 (net -115) | 0 | 3 (net +545) | 1 (net +0) | 5 (net +139) | 4 (net +206) | 0 | 21% (3 of 14) |
| Mine | Kingdom of Bretonnia | 3 | 1 (net +144) | 0 | 1 (net +236) | 0 | 1 (net +342) | 0 | 0 | 33% (1 of 3) |
| Mine | Lizardmen | 2 | 1 (net +33) | 0 | 0 | 0 | 0 | 1 (net +0) | 0 | 0% (0 of 2) |
| Mine | Ogre Kingdoms | 2 | 0 | 0 | 0 | 0 | 0 | 1 (net +120) | 1 | 0% (0 of 1) |
| Mine | Orc & Goblin Tribes | 4 | 0 | 0 | 0 | 0 | 0 | 2 (net +292) | 2 | 0% (0 of 2) |
| Mine | Skaven | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +258) | 0 | 0% (0 of 1) |
| Mine | Tomb Kings of Khemri | 7 | 1 (net +195) | 0 | 1 (net +195) | 4 (net +122) | 0 | 1 (net +0) | 0 | 14% (1 of 7) |
| Mine | Vampire Counts | 7 | 1 (net -45) | 1 (net -60) | 2 (net +142) | 2 (net -140) | 0 | 1 (net +208) | 0 | 29% (2 of 7) |
| Mine | Warriors of Chaos | 3 | 0 | 0 | 2 (net -71) | 0 | 0 | 1 (net +0) | 0 | 67% (2 of 3) |
| Opponent | Empire of Man | 1 | 0 | 0 | 0 | 1 (net -444) | 0 | 0 | 0 | 0% (0 of 1) |
| Opponent | Grand Cathay | 5 | 0 | 1 (net +0) | 1 (net +0) | 1 (net +85) | 1 (net +0) | 1 (net +547) | 0 | 20% (1 of 5) |
| Opponent | High Elf Realms | 8 | 1 (net -347) | 0 | 2 (net +0) | 2 (net +116) | 0 | 3 (net +42) | 0 | 25% (2 of 8) |
| Opponent | Kingdom of Bretonnia | 6 | 2 (net +116) | 0 | 0 | 2 (net +102) | 0 | 2 (net +296) | 0 | 0% (0 of 6) |
| Opponent | Orc & Goblin Tribes | 5 | 0 | 0 | 0 | 1 (net +0) | 0 | 0 | 4 | 0% (0 of 1) |
| Opponent | Tomb Kings of Khemri | 15 | 1 (net +240) | 0 | 4 (net +82) | 4 (net +238) | 1 (net +104) | 3 (net +0) | 2 | 31% (4 of 13) |
| Opponent | Vampire Counts | 26 | 9 (net +86) | 0 | 3 (net +108) | 7 (net +124) | 1 (net +65) | 6 (net +115) | 0 | 12% (3 of 26) |
| Opponent | Warriors of Chaos | 23 | 4 (net +321) | 1 (net +0) | 4 (net +148) | 4 (net +115) | 1 (net +0) | 7 (net +28) | 2 | 19% (4 of 21) |
| Opponent | Wood Elf Realms | 15 | 2 (net +9) | 0 | 1 (net +482) | 2 (net -22) | 0 | 1 (net +255) | 9 | 17% (1 of 6) |

### Charged fights, damage counted: su-h2h-mine-e45904b-p3

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 7 | 139 | 234 | +30 | 95 | 95 | +1 | +0.5 |
| Mine | 50-54% | 4 | 92 | 154 | -92 | 98 | 92 | +7 | +7.4 |
| Mine | Effective (55-75%) | 14 | 320 | 254 | +189 | 264 | 100 | +165 | +51.5 |
| Mine | 76-89% | 19 | 274 | 197 | +122 | 165 | 53 | +112 | +40.9 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 20 | 227 | 179 | +115 | 142 | 19 | +123 | +54.1 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 9 | 478 | 94 | +142 | 142 | 13 | +129 | +27.0 |
| Mine | No odds | 7 | 375 | 192 | -31 | 82 | 70 | +12 | +3.3 |
| Mine | All fights | 80 | 281 | 191 | +102 | 157 | 55 | +102 | +36.3 |
| Opponent | Long shot (under 50%) | 19 | 185 | 214 | +116 | 181 | 97 | +85 | +45.7 |
| Opponent | 50-54% | 2 | 434 | 340 | +0 | 0 | 0 | +0 | +0.0 |
| Opponent | Effective (55-75%) | 15 | 416 | 304 | +115 | 140 | 31 | +109 | +26.3 |
| Opponent | 76-89% | 24 | 368 | 234 | +97 | 164 | 71 | +93 | +25.3 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 23 | 332 | 207 | +105 | 139 | 14 | +125 | +37.8 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 4 | 310 | 68 | +42 | 56 | 0 | +56 | +18.2 |
| Opponent | No odds | 17 | 131 | 194 | -40 | 54 | 82 | -28 | -21.3 |
| Opponent | All fights | 104 | 294 | 224 | +78 | 133 | 55 | +78 | +26.6 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| su-h2h-mine-e45904b-p3 | move | 467 | 76 (16%) | 55 (12%) | 55 (12%) | 336 (72%) |
| su-h2h-mine-e45904b-p3 | objective | 332 | 48 (14%) | 32 (10%) | 43 (13%) | 241 (73%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0110, L0126, L2433, L2630 |
| Charmed Shield | Opponent | L0126, L0226, L0327, L0725, L1327, L2327 |
| Clockwork Compass | Mine | L1216, L1232 |
| Elixir of Power | Mine | L1122, L1932 |
| Elixir of Power | Opponent | L0311, L1519 |
| Fistful of Laurels | Mine | L1831 |
| Horn of the Wild Hunt | Opponent | L0533, L1633, L2033, L2433, L3133 |
| Invocation of Nehek | Mine | L2433 |
| Invocation of Nehek | Opponent | L0327, L0725, L1327, L2327 |
| Opal Amulet | Mine | L1422 |
| Periapt of Soul Exchange | Mine | L2033 |
| Periapt of Soul Exchange | Opponent | L0620 |
| Ring of Doom | Mine | L0210, L0226, L1122, L1216, L1232, L1519, L1535, L3133 |
| Ring of Doom | Opponent | L0311, L0533, L0815, L0831, L1633, L1731, L1831, L2033, L2433, L3133 |
| Ring of Jet | Mine | L1013, L1030, L1122, L1216, L1232 |
| Ring of Jet | Opponent | L0110, L0210, L0311 |
| Standard of the Fell Warrior | Mine | L1327 |
| Standard of the Fell Warrior | Opponent | L0413, L1013 |
| Twice-Blessed Armour | Mine | L0709, L0725, L1013, L1030 |
| Twice-Blessed Armour | Opponent | L0110, L0210 |
| Witch Hunter's Ward | Mine | L0709, L0725, L0815, L0831 |

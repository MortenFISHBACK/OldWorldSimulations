# Doctrine scorecard: su-h2h-mine-e45904b-p4

### Scorecard: su-h2h-mine-e45904b-p4

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0114 | 6 | 1 | Mine | no | 5 | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| L0114 | 6 | 1 | Opponent | no | 6 | 1 | 1 | 1 | 0 | 0 | 0 | 0 |
| L0130 | 4 | 1 | Mine | yes | 6 | - | 0 | 2 | 1 | 0 | 0 | 0 |
| L0130 | 4 | 1 | Opponent | no | 0 | 1 | 4 | 1 | 0 | 0 | 0 | 0 |
| L0214 | 4 | 1 | Mine | no | 2 | 2 | 1 | 1 | 0 | 0 | 0 | 170 |
| L0214 | 4 | 1 | Opponent | no | 2 | 1 | 0 | 2 | 0 | 0 | 0 | 0 |
| L0230 | 2 | 1 | Mine | - | - | 1 | 6 | 3 | 1 | 0 | 0 | 170 |
| L0230 | 2 | 1 | Opponent | - | - | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| L0315 | 3 | 1 | Mine | no | 0 | 2 | 0 | 2 | 0 | 0 | 0 | 675 |
| L0315 | 3 | 1 | Opponent | yes | 18 | 2 | 3 | 0 | 0 | 0 | 0 | 0 |
| L0332 | 2 | 1 | Mine | - | - | - | 1 | 0 | 1 | 0 | 0 | 360 |
| L0332 | 2 | 1 | Opponent | - | - | 2 | 1 | 5 | 1 | 0 | 0 | 0 |
| L0417 | 3 | 1 | Mine | yes | 4 | 2 | 4 | 0 | 1 | 0 | 0 | 0 |
| L0417 | 3 | 1 | Opponent | yes | 10 | 4 | 3 | 0 | 1 | 0 | 0 | 175 |
| L0434 | 2 | 1 | Mine | - | - | 2 | 2 | 0 | 0 | 0 | 0 | 0 |
| L0434 | 2 | 1 | Opponent | - | - | 1 | 3 | 1 | 0 | 0 | 0 | 0 |
| L0520 | 4 | 1 | Mine | no | 0 | 6 | 1 | 1 | 0 | 0 | 0 | 1120 |
| L0520 | 4 | 1 | Opponent | no | 1 | - | 1 | 3 | 1 | 0 | 0 | 210 |
| L0608 | 2 | 1 | Mine | - | - | 3 | 2 | 2 | 0 | 0 | 0 | 886 |
| L0608 | 2 | 1 | Opponent | - | - | 4 | 1 | 1 | 0 | 0 | 0 | 605 |
| L0624 | 6 | 1 | Mine | no | 0 | 3 | 1 | 0 | 0 | 0 | 0 | 615 |
| L0624 | 6 | 1 | Opponent | no | 2 | 3 | 2 | 2 | 1 | 0 | 0 | 0 |
| L0713 | 5 | 1 | Mine | yes | - | 1 | 4 | 1 | 1 | 0 | 0 | 497 |
| L0713 | 5 | 1 | Opponent | no | - | 4 | 3 | 0 | 1 | 0 | 0 | 140 |
| L0729 | 3 | 1 | Mine | no | 7 | 2 | 2 | 0 | 0 | 0 | 0 | 375 |
| L0729 | 3 | 1 | Opponent | no | 2 | 2 | 3 | 0 | 1 | 0 | 0 | 0 |
| L0819 | 3 | 1 | Mine | no | 0 | 3 | 1 | 0 | 0 | 0 | 0 | 715 |
| L0819 | 3 | 1 | Opponent | no | 0 | 2 | 2 | 2 | 2 | 0 | 0 | 543 |
| L0835 | 1 | 1 | Mine | no | 0 | 4 | 0 | 1 | 0 | 0 | 0 | 717 |
| L0835 | 1 | 1 | Opponent | no | 2 | - | 1 | 2 | 1 | 0 | 0 | 0 |
| L0926 | 2 | 1 | Mine | - | - | 4 | 1 | 2 | 0 | 0 | 0 | 537 |
| L0926 | 2 | 1 | Opponent | - | - | 2 | 1 | 6 | 0 | 0 | 0 | 0 |
| L1017 | 3 | 1 | Mine | no | 0 | 4 | 3 | 0 | 1 | 0 | 0 | 330 |
| L1017 | 3 | 1 | Opponent | yes | 0 | 2 | 5 | 1 | 0 | 0 | 0 | 175 |
| L1034 | 2 | 1 | Mine | - | - | 2 | 1 | 1 | 0 | 0 | 0 | 330 |
| L1034 | 2 | 1 | Opponent | - | - | 3 | 5 | 6 | 0 | 0 | 0 | 527 |
| L1126 | 4 | 1 | Mine | no | 0 | 4 | 2 | 0 | 0 | 0 | 0 | 330 |
| L1126 | 4 | 1 | Opponent | no | 0 | 2 | 2 | 3 | 1 | 0 | 0 | 0 |
| L1220 | 2 | 1 | Mine | - | - | 2 | 3 | 0 | 0 | 0 | 0 | 330 |
| L1220 | 2 | 1 | Opponent | - | - | - | 5 | 5 | 2 | 0 | 0 | 650 |
| L1314 | 6 | 1 | Mine | no | 2 | 3 | 2 | 0 | 0 | 0 | 0 | 302 |
| L1314 | 6 | 1 | Opponent | no | 5 | 2 | 4 | 0 | 1 | 0 | 0 | 123 |
| L1331 | 5 | 1 | Mine | yes | - | 2 | 0 | 1 | 1 | 0 | 0 | 140 |
| L1331 | 5 | 1 | Opponent | yes | - | 4 | 1 | 2 | 1 | 0 | 0 | 456 |
| L1427 | 5 | 1 | Mine | yes | - | 2 | 3 | 2 | 0 | 0 | 0 | 0 |
| L1427 | 5 | 1 | Opponent | no | - | 2 | 5 | 2 | 1 | 0 | 0 | 0 |
| L1523 | 5 | 1 | Mine | no | - | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| L1523 | 5 | 1 | Opponent | yes | - | 2 | 5 | 2 | 1 | 0 | 0 | 66 |
| L1621 | 1 | 1 | Mine | no | 0 | 2 | 6 | 1 | 0 | 0 | 0 | 200 |
| L1621 | 1 | 1 | Opponent | no | 6 | 2 | 5 | 3 | 0 | 0 | 0 | 565 |
| L1719 | 3 | 1 | Mine | no | 3 | 2 | 7 | 0 | 1 | 0 | 0 | 49 |
| L1719 | 3 | 1 | Opponent | yes | 4 | 2 | 4 | 0 | 0 | 0 | 0 | 0 |
| L1819 | 1 | 1 | Mine | no | 2 | 4 | 3 | 0 | 1 | 0 | 0 | 185 |
| L1819 | 1 | 1 | Opponent | no | 4 | 2 | 5 | 0 | 0 | 0 | 0 | 0 |
| L1835 | 5 | 1 | Mine | no | - | - | 1 | 2 | 1 | 0 | 0 | 0 |
| L1835 | 5 | 1 | Opponent | yes | - | 2 | 2 | 3 | 0 | 0 | 0 | 0 |
| L2021 | 5 | 1 | Mine | no | - | - | 0 | 3 | 1 | 0 | 0 | 210 |
| L2021 | 5 | 1 | Opponent | yes | - | 4 | 1 | 6 | 0 | 0 | 0 | 355 |
| L2123 | 5 | 1 | Mine | yes | - | - | 3 | 4 | 0 | 0 | 0 | 355 |
| L2123 | 5 | 1 | Opponent | yes | - | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L2227 | 1 | 1 | Mine | no | 0 | 2 | 1 | 0 | 0 | 0 | 0 | 0 |
| L2227 | 1 | 1 | Opponent | yes | 0 | 1 | 4 | 1 | 0 | 0 | 0 | 0 |
| L2331 | 3 | 1 | Mine | no | 1 | 2 | 2 | 0 | 0 | 0 | 0 | 66 |
| L2331 | 3 | 1 | Opponent | yes | 4 | 3 | 3 | 0 | 0 | 0 | 0 | 170 |
| L2527 | 1 | 1 | Mine | no | 0 | 3 | 6 | 1 | 0 | 0 | 0 | 0 |
| L2527 | 1 | 1 | Opponent | no | 0 | 1 | 2 | 2 | 1 | 0 | 0 | 190 |
| L2634 | 6 | 1 | Mine | no | 4 | 2 | 3 | 0 | 1 | 0 | 0 | 0 |
| L2634 | 6 | 1 | Opponent | no | 3 | 2 | 3 | 1 | 0 | 0 | 0 | 56 |
| L2930 | 2 | 1 | Mine | - | - | 2 | 7 | 0 | 0 | 0 | 0 | 0 |
| L2930 | 2 | 1 | Opponent | - | - | 3 | 0 | 0 | 0 | 0 | 0 | 0 |
| L3234 | 6 | 1 | Mine | no | 1 | 2 | 4 | 2 | 0 | 0 | 0 | 170 |
| L3234 | 6 | 1 | Opponent | no | 1 | 2 | 4 | 2 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 21% | 1.8 | 2.5 | 2.4 | 0.9 | 0.3 | 0.0 | 0.0 | 273.2 |
| **Average** | | | Opponent | 39% | 3.3 | 2.2 | 2.8 | 1.9 | 0.5 | 0.0 | 0.0 | 139.1 |

### KPIs: su-h2h-mine-e45904b-p4

Rules off - Opponent only: SET-UP SPOT, CARRIES OUT CLOSE-IN, JOINT AS ONE.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 25% (43 of 171) | 1% (2 of 188) | 13% (45 of 359) |
| Winner chose to follow up after the loser gave ground |  | 96% (53 of 55); on the table 96% | 98% (57 of 58); on the table 98% | 97% (110 of 113); on the table 97% |
| Winner chose to pursue after the loser fell back in good order |  | 89% (8 of 9); on the table 89% | 91% (21 of 23); on the table 91% | 91% (29 of 32); on the table 91% |
| Winner chose to pursue after the loser fled |  | 81% (29 of 36); on the table 81% | 71% (20 of 28); on the table 79% | 77% (49 of 64); on the table 80% |
| Winner chose to follow up or pursue (all three) |  | 90% (90 of 100); on the table 90% | 90% (98 of 109); on the table 92% | 90% (188 of 209); on the table 91% |
| Magic missiles tried each own turn | 50%+ | 27% (71 of 263) | 35% (62 of 178) | 30% (133 of 441) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 40% (65 of 164) | 46% (56 of 122) | 42% (121 of 286) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 60% (24 of 40) | 60% (36 of 60) | 60% (60 of 100) |
| Points that never fought | lower | 38% (26025 of 67942) | 32% (23366 of 71984) | 35% (49391 of 139926) |
|   infantry points that never fought | lower | 50% (7736 of 15347) | 57% (7875 of 13804) | 54% (15611 of 29151) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 54% (145 of 270) | 49% (138 of 280) | 51% (283 of 550) |
| Bound items with a magic missile used (at least once a game) |  | 86% (19 of 22); 1.3 uses a game | 89% (8 of 9); 0.7 uses a game | 87% (27 of 31); 1.0 uses a game |
| Bound items with another spell used |  | 38% (6 of 16); 0.5 uses a game | 35% (7 of 20); 0.3 uses a game | 36% (13 of 36); 0.4 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 53% (10 of 19); 0.3 uses a game | 80% (12 of 15); 0.4 uses a game | 65% (22 of 34); 0.3 uses a game |
|   their share of the points of units over 100 pts | lower | 49% (28223 of 57750) | 43% (26946 of 63347) | 46% (55169 of 121097) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.1 (20%) | 1.0 (30%) | 2.1 (24%) |
| MARCHED: its unit marched | 1.4 (27%) | 0.5 (15%) | 1.9 (22%) |
| CHARGED: its unit charged | 0.2 (4%) | 0.1 (2%) | 0.2 (3%) |
| IN COMBAT: engaged in combat | 1.4 (27%) | 0.4 (13%) | 1.9 (22%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.3 (10%) | 0.3 (4%) |
| FLEEING: fleeing | 0.0 (0%) | 0.1 (3%) | 0.1 (1%) |
| GONE: slain | 0.8 (15%) | 0.8 (25%) | 1.6 (19%) |
| OFF THE TABLE: off the table or not arrived | 0.4 (7%) | 0.1 (2%) | 0.4 (5%) |
| STUPIDITY: Stupidity | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.1 | 1.3 | 2.1 | 3.7 | 0.5 | 2.7 |
| not cast | 3.1 | 2.4 | 2.8 | 8.6 | 1.5 | 20.3 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.8 (9%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.2 (48%) | 0.3 (12%) | 2.1 (24%) | 0.4 (24%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.9 (22%) | 0.4 (24%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (3%) | 0.1 (4%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.2 (6%) | 0.2 (7%) | 0.7 (25%) | 1.9 (22%) | 0.2 (16%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.2 (6%) | 0.1 (5%) | 0.3 (10%) | 0.3 (4%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.2 (6%) | 0.0 (0%) | 0.0 (1%) | 0.1 (1%) | 0.0 (0%) | 0.5 (2%) |
| GONE: slain | 0.5 (17%) | 0.5 (19%) | 0.4 (14%) | 1.6 (19%) | 0.3 (20%) | 3.1 (15%) |
| OFF THE TABLE: off the table or not arrived | 0.3 (10%) | 0.1 (6%) | 0.2 (7%) | 0.4 (5%) | 0.0 (2%) | 1.1 (5%) |
| STUPIDITY: Stupidity | 0.1 (4%) | 0.0 (0%) | 0.0 (1%) | 0.1 (1%) | 0.0 (0%) | 0.2 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.3 (11%) | 0.0 (0%) | 0.0 (0%) | 0.2 (11%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.5 (50%) | 0.1 (5%) | 0.8 (30%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 13.6 (67%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.6 a game | 0.6 a game | 1.1 a game |
| stood (cast and not dispelled) | 64% (32 of 50) | 67% (8 of 12) | 65% (40 of 62) |
| the unit moved after it | 78% (25 of 32) | 62% (5 of 8) | 75% (30 of 40) |
| it charged on its next turn | 6% (2 of 32) | 0% (0 of 8) | 5% (2 of 40) |
| the enemy charged it first | 19% (6 of 32) | 25% (2 of 8) | 20% (8 of 40) |
| it fought by the end of its next turn | 9% (3 of 32) | 25% (2 of 8) | 12% (5 of 40) |
| it moved out of a charge the enemy had planned (not charged first) | 12% (4 of 32) | 0% (0 of 8) | 10% (4 of 40) |
| none of these (no charge, no fight, no charge escaped) | 66% (21 of 32) | 75% (6 of 8) | 68% (27 of 40) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 65% (584 of 901) | 52% (278 of 537) | 60% (862 of 1438) |
|   cavalry | 66% (52 of 79) | 63% (72 of 115) | 64% (124 of 194) |
|   character | 39% (42 of 107) | 16% (19 of 122) | 27% (61 of 229) |
|   chariot | 55% (53 of 97) | 43% (9 of 21) | 53% (62 of 118) |
|   infantry | 59% (163 of 277) | 68% (161 of 237) | 63% (324 of 514) |
|   monster | 48% (23 of 48) | 12% (3 of 24) | 36% (26 of 72) |
|   war machine | 86% (251 of 293) | 78% (14 of 18) | 85% (265 of 311) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.3 (26%) | 1.3 (19%) | 3.6 (23%) |
| CHARGED: it charged | 1.1 (13%) | 1.9 (26%) | 3.0 (19%) |
| FLEEING: it fled or was fleeing | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: it fought this turn or the last | 0.8 (9%) | 0.5 (7%) | 1.4 (9%) |
| MOVED: a war machine that moved | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| HELD FIRE: a target, but it held its fire | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NO TARGET IN RANGE | 1.8 (21%) | 1.2 (17%) | 3.0 (19%) |
| ONLY IN COMBAT: the only targets were in combat | 0.6 (6%) | 0.8 (11%) | 1.3 (8%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.6 (19%) | 1.3 (18%) | 2.9 (18%) |
| SHELTERED: the target was sheltered | 0.2 (2%) | 0.1 (2%) | 0.3 (2%) |
| STUPIDITY | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR | 0.2 (2%) | 0.1 (1%) | 0.3 (2%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 5.9 | 1.7 | 77% | 6.6 pts | 39 pts |
| character | 2.0 | 0.6 | 82% | 8.4 pts | 17 pts |
| chariot | 1.7 | 0.8 | 69% | 12.8 pts | 22 pts |
| infantry | 13.2 | 4.8 | 74% | 9.1 pts | 120 pts |
| monster | 0.7 | 0.1 | 92% | 1.5 pts | 1 pts |
| war machine | 7.4 | 6.6 | 65% | 32.9 pts | 242 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.7 | 6.7 | 5.7 |
| Charges that made contact a game | 3.2 | 4.7 | 4.0 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.71 declared, 0.53 contact (17 units) | 0.72 declared, 0.67 contact (18 units) | 0.71 declared, 0.60 contact (35 units) |
|   per unit a game, units carrying another wizard (or one alone) | 1.00 declared, 0.89 contact (9 units) | 1.08 declared, 0.77 contact (13 units) | 1.05 declared, 0.82 contact (22 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.59 declared, 0.40 contact (248 units) | 0.75 declared, 0.52 contact (284 units) | 0.68 declared, 0.46 contact (532 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 58% (47 of 81) | 44% (7 of 16) | 50% (3 of 6) | 55% (57 of 103) |
| Character in a unit | 74% (25 of 34) | 40% (6 of 15) | 100% (1 of 1) | 64% (32 of 50) |
| Character on its own | 61% (19 of 31) | 37% (10 of 27) | 29% (22 of 77) | 38% (51 of 135) |
| Chariot | 73% (11 of 15) | 67% (8 of 12) | - | 70% (19 of 27) |
| Infantry | 49% (41 of 83) | 32% (8 of 25) | 17% (1 of 6) | 44% (50 of 114) |
| Monster | 68% (23 of 34) | 79% (11 of 14) | - | 71% (34 of 48) |
| Monstrous | 71% (10 of 14) | 50% (7 of 14) | - | 61% (17 of 28) |
| War Machines | 49% (21 of 43) | 100% (2 of 2) | - | 51% (23 of 45) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 90% (18 of 20); on the table 90% | 23% (23 of 102) | 19% | 27% (6 of 22) | 83% (5 of 6); 2.0 uses a game | 50% (1 of 2); 1.0 uses a game | 67% (4 of 6); 1.0 uses a game |
| Chaos Dwarfs | 4 | 100% (8 of 8); on the table 100% | 71% (17 of 24) | 38% | 59% (19 of 32) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
| Dwarfen Mountain Holds | 3 | 100% (2 of 2); on the table 100% | - | 77% | 56% (15 of 27) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 6 | 90% (9 of 10); on the table 90% | 44% (8 of 18) | 51% | 55% (34 of 62) | 0.0 uses a game | 100% (2 of 2); 1.0 uses a game | 80% (4 of 5); 0.7 uses a game |
| Grand Cathay | 4 | 94% (15 of 16); on the table 94% | 24% (20 of 84) | 43% | 49% (18 of 37) | 89% (8 of 9); 5.8 uses a game | 0% (0 of 2); 0.0 uses a game | 0% (0 of 4); 0.0 uses a game |
| High Elf Realms | 9 | 89% (25 of 28); on the table 89% | 25% (9 of 36) | 25% | 40% (28 of 70) | 100% (7 of 7); 2.8 uses a game | 33% (10 of 30); 2.1 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | 67% (2 of 3); on the table 67% | - | 19% | 33% (2 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Lizardmen | 3 | 88% (14 of 16); on the table 88% | 100% (6 of 6) | 35% | 62% (13 of 21) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 2 | 100% (2 of 2); on the table 100% | 0% (0 of 6) | 56% | 79% (11 of 14) | 50% (1 of 2); 0.5 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 3 | 100% (10 of 10); on the table 100% | 24% (10 of 42) | 16% | 21% (5 of 24) | 0.0 uses a game | 0.0 uses a game | 67% (2 of 3); 0.7 uses a game |
| Skaven | 6 | 100% (5 of 5); on the table 100% | 25% (10 of 40) | 46% | 67% (30 of 45) | 100% (3 of 3); 1.0 uses a game | 0.0 uses a game | 67% (4 of 6); 0.8 uses a game |
| Tomb Kings of Khemri | 4 | 88% (15 of 17); on the table 94% | 0% (0 of 6) | 29% | 30% (6 of 20) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 8 | 93% (13 of 14); on the table 93% | 37% (22 of 59) | 33% | 55% (23 of 42) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 9 | 89% (31 of 35); on the table 89% | 50% (6 of 12) | 22% | 57% (41 of 72) | 100% (2 of 2); 0.6 uses a game | 0.0 uses a game | 100% (3 of 3); 0.3 uses a game |
| Wood Elf Realms | 6 | 83% (19 of 23); on the table 87% | 33% (2 of 6) | 39% | 57% (32 of 56) | 50% (1 of 2); 0.8 uses a game | 0.0 uses a game | 75% (3 of 4); 0.5 uses a game |

Flank and rear charges a unit could have turned to face (su-h2h-mine-e45904b-p4, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 50% (50) | 49% (35) | 50% (85) |
| ...free all their last turn and able to turn (per game) | 0.75 | 0.58 | 1.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.31 | 0.19 | 0.50 |
| ...with the charger already in that arc before they moved (per game) | 0.44 | 0.36 | 0.81 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 1.81 | 1.44 | 3.25 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.86 | 0.56 | 1.42 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 5.83 | 5.86 | 11.69 |

### Quality by phase: su-h2h-mine-e45904b-p4

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.1 | 3.6 |
| Strategy | Charge objectives carried out (made contact) | 45% (68 of 151) | 39% (78 of 198) |
| Strategy | Shoot objectives carried out (shot that target) | 42% (172 of 407) | 37% (56 of 152) |
| Strategy | Close-in objectives charged next turn | 19% (25 of 129) | 13% (30 of 228) |
| Strategy | Support requests answered (helper made contact too) | 62% (13 of 21) | 49% (18 of 37) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (1 of 1) | - |
| Strategy | Hexes on a unit its side charged or shot that turn | 40% (4 of 10) | 18% (2 of 11) |
| Strategy | Joined characters whose unit fought | 40% (17 of 42) | 67% (20 of 30) |
| Strategy | Lone characters that fought | 77% (62 of 81) | 79% (68 of 86) |
| Movement | Charges halted short of contact | 0.3 | 0.4 |
| Movement | Idle units | 0.9 | 1.9 |
| Movement | Points that never moved of their own | 273.2 | 139.1 |
| Movement | Fights charged into per game | 2.9 | 3.7 |
| Movement | Charges with odds: long shots (under 50%) | 14 of 95, net +104 | 20 of 117, net +70 |
| Movement | Charges with odds: sweet spot (55-75%) | 18 of 95, net +9 | 30 of 117, net +132 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 9 of 95, net +48 | 11 of 117, net +82 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 21 of 95, net +61 | 29 of 117, net +43 |
| Shooting | Shots by shooting units (incl. breath weapons) | 10.0 | 8.8 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 51% (183 of 360) | 43% (137 of 317) |
| Shooting | Points destroyed by shooting units | 107.6 | 15.1 |
| Shooting | War machine shots | 7.0 | 0.4 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 58% (145 of 251) | 0% (0 of 14) |
| Shooting | Points destroyed by war machines | 82.4 | 9.7 |
| Magic | Magic missiles cast | 1.3 | 1.2 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 32% (15 of 47) | 24% (10 of 42) |
| Magic | Wounds caused by magic missiles | 3.0 | 1.0 |
| Magic | Wounds caused by other spells | 2.2 | 1.1 |
| Magic | Points destroyed by magic (all spells) | 76.1 | 40.6 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.0 / 0.3 / 1.3 / 0.3 | 1.9 / 0.5 / 0.6 / 0.0 |
| Combat | Points destroyed in combat | 286.7 | 402.9 |
| Combat | Points run down | 58.2 | 78.8 |
| Combat | Net points per charged fight, damage counted | +61 | +78 |
| Combat | Net per 100 charger points, damage counted | +20.9 | +26.4 |
| Combat | First round won (charged fights) | 77% | 71% |
| Combat | Net points per charged fight | +53 | +80 |
| Combat | Net points per supported fight / lone fight | +48 / +54 | +114 / +73 |
| Combat | Charged fights on a top-3 enemy unit | 39 of 103 | 57 of 133 |
| Game | Points lost | 706.9 | 717.6 |
| Game | VP from objectives | 500.3 | 554.7 |
| Game | Lone holders (player turns) | 1.8 | 3.3 |

- Mine won / drew / lost: 16 / 7 / 13 of 36 ended games (of 36); mean margin (Mine - Opponent) -32 VP
- The side that went first won 15 of 29 games with a winner
- Points traded per game (both sides' losses): 1425
- Games not ended: 0; findings 0, warnings 1

### Opponent rules: su-h2h-mine-e45904b-p4

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 0.8 | +0.0 | 0.0 | 0.0 |
| ALREADY CARRIED | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARRIVAL HUNT | - | - | - | - | 0.0 | +0.3 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.3 | +0.0 | 0.0 | 10.8 | 0.1 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | 0.9 | +8.6 | 0.0 | 19.6 | 1.0 | +12.0 | 0.0 | 13.1 |
| BEST FACING | 0.7 | +21.9 | 0.0 | 27.8 | 0.6 | +23.2 | 0.0 | 23.2 |
| BEST FIRST | 3.9 | +192.0 | 181.2 | 107.5 | 4.2 | +136.4 | 129.7 | 85.1 |
| BEST OVERALL | 0.5 | +28.3 | 0.0 | 12.1 | 0.5 | +39.7 | 0.0 | 13.4 |
| BEST PREY | 0.9 | +50.4 | 17.3 | 0.0 | 1.0 | +42.3 | 16.2 | 16.4 |
| BEST PRIZE | 0.1 | -1.3 | 0.0 | 0.0 | 0.1 | -1.3 | 4.9 | 0.0 |
| BIG CHARACTER SAFETY | 0.2 | -0.1 | 0.0 | 10.2 | 0.4 | +0.1 | 0.0 | 30.0 |
| BLOCKED CHARGE SKIPPED | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 22.3 | 0.0 |
| BLOCKED WHEEL | 0.5 | +0.3 | 0.0 | 5.1 | 0.6 | +16.8 | 0.0 | 1.9 |
| BLOWS WHERE AIMED | 0.4 | -41.8 | 42.0 | 19.3 | 0.2 | -56.8 | 19.2 | 3.3 |
| BOMBING RUN | 0.0 | +0.9 | 3.1 | 0.0 | - | - | - | - |
| BOUND ASSAILMENT | - | - | - | - | 0.1 | +0.0 | 0.0 | 7.4 |
| CANNON PLAN MISSED | 0.9 | +0.0 | 179.6 | 8.1 | 0.0 | +0.0 | 3.2 | 0.0 |
| CANNON PLANNED TARGET | 5.3 | +256.8 | 466.3 | 45.7 | 0.4 | +18.5 | 24.4 | 7.4 |
| CANNON SIGHT KEPT | 1.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 1.9 |
| CARRIES OUT CLOSE-IN | 0.4 | -1.0 | 72.0 | 19.8 | - | - | - | - |
| CARRIES OUT COUNTER | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | -1.1 | 0.0 | 0.0 |
| CARRIES OUT SET-UP | 0.2 | -1.4 | 38.6 | 0.0 | 0.2 | -1.9 | 23.4 | 0.0 |
| CAST JOB | 0.6 | +17.0 | 20.8 | 15.0 | 0.6 | +15.4 | 53.1 | 27.6 |
| CASTER AWAY FROM SCREEN | 0.3 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.2 | +19.5 | 19.7 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | 1.0 | +0.0 | 0.0 | 45.6 | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.0 | +0.3 | 0.0 | 0.0 | - | - | - | - |
| CATCH ODDS | 0.0 | +0.8 | 0.0 | 6.2 | - | - | - | - |
| CHAFF PASSED | 0.1 | -0.2 | 0.0 | 0.0 | 0.1 | -0.3 | 6.5 | 5.6 |
| CHAMPION TAKES THE CHALLENGE | - | - | - | - | 0.0 | +0.1 | 0.0 | 0.0 |
| CHARGE BAND | 0.2 | +0.0 | 18.3 | 6.9 | 0.2 | +0.0 | 16.8 | 0.0 |
| CHARGE NOW FIRST | 2.5 | +0.0 | 284.3 | 97.8 | 2.8 | +0.0 | 217.5 | 36.8 |
| CHARGE NOW WEIGHED | 0.4 | -33.1 | 11.0 | 10.0 | 0.5 | -35.4 | 21.7 | 33.2 |
| CHARGER SLAIN LOST | 0.7 | -13.2 | 61.7 | 17.8 | 0.6 | -20.7 | 76.2 | 28.6 |
| CHARIOT NO STATIC JOB | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHARIOT WIZARD CAREFUL | 0.2 | -0.7 | 5.4 | 26.1 | 0.2 | -0.5 | 0.0 | 30.0 |
| CHEAP HELPER | 0.1 | +0.0 | 1.9 | 5.6 | - | - | - | - |
| COMBAT PIVOT | 0.4 | +0.0 | 0.0 | 35.4 | 0.4 | +0.0 | 30.7 | 42.8 |
| CONTINUE AHEAD WEIGHED | 0.0 | +0.0 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | 1.0 | +148.1 | 8.9 | 14.0 | 0.2 | +47.7 | 0.0 | 0.0 |
| COUNTER-CHARGE COVER | 9.4 | +770.6 | 0.0 | 224.8 | 7.1 | +646.3 | 0.0 | 177.6 |
| DEFENSIVE ARMY | 0.2 | +0.0 | 13.1 | 1.0 | - | - | - | - |
| DEFENSIVE FLOOR | 0.1 | +0.7 | 2.9 | 0.0 | 0.0 | +1.2 | 9.4 | 0.0 |
| EDGE GIVE GROUND | 0.1 | +8.9 | 16.4 | 7.9 | 0.1 | +4.0 | 3.5 | 1.2 |
| ELIXIR WORTH | - | - | - | - | 0.1 | +5.4 | 0.0 | 0.0 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 1.8 | +149.0 | 0.0 | 95.1 | 1.4 | +100.7 | 0.0 | 62.1 |
| FALLBACK BY WORTH | 4.8 | +38.8 | 0.0 | 39.8 | 6.5 | +73.7 | 0.0 | 59.1 |
| FIGHT LIFT | 0.1 | +1.9 | 29.8 | 9.3 | - | - | - | - |
| FIRE AND FLEE | - | - | - | - | 0.1 | +3.6 | 0.0 | 11.9 |
| FLANK NOT WEIGHED | 5.8 | +0.0 | 0.0 | 161.3 | 5.9 | +0.0 | 0.0 | 134.3 |
| FLEE LOSES BLESSING | 0.1 | +3.0 | 0.0 | 0.0 | - | - | - | - |
| FOCUS FIRE | 0.0 | +0.4 | 1.5 | 0.0 | - | - | - | - |
| FOLLOW UP WEIGHED | 0.9 | +120.2 | 0.0 | 45.8 | 1.0 | +112.2 | 0.0 | 5.3 |
| FRIENDS SHOTS CHECKED | 0.3 | +21.6 | 0.0 | 5.9 | 0.2 | +18.8 | 0.0 | 0.0 |
| GIVES UP | 0.1 | -1.7 | 12.8 | 0.0 | 0.0 | -1.0 | 0.0 | 0.0 |
| GIVES UP ITS SCREEN | - | - | - | - | 0.1 | -0.2 | 3.8 | 1.2 |
| GROUND FLIERS | 0.1 | +1.0 | 0.0 | 0.0 | 0.1 | +1.9 | 0.0 | 3.2 |
| HELPER ALREADY ASKED | - | - | - | - | 0.1 | +0.0 | 8.2 | 0.0 |
| HELPER UNSEEN | 0.4 | +0.0 | 28.7 | 1.4 | 0.6 | +0.0 | 50.1 | 25.2 |
| HILL BY ITS CHANCE | 0.5 | -44.8 | 0.0 | 0.0 | 0.4 | -38.8 | 0.0 | 4.9 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 7.0 | -127.6 | 488.4 | 252.6 | 8.9 | -221.4 | 512.1 | 110.4 |
| HUNT ADVANCE | - | - | - | - | 0.1 | +2.0 | 11.1 | 0.0 |
| HUNT DROPPED | - | - | - | - | 0.1 | +0.0 | 0.0 | 4.3 |
| HUNT IN PAIRS | 0.3 | +9.5 | 0.0 | 10.2 | 0.5 | +29.5 | 0.0 | 1.9 |
| HUNT KEPT | - | - | - | - | 0.1 | +0.2 | 4.7 | 1.2 |
| HUNT RESULT | - | - | - | - | 0.2 | +31.6 | 14.6 | 5.6 |
| HUNT THE GUNS | - | - | - | - | 0.2 | +82.4 | 27.8 | 3.2 |
| INVITES THE FIGHT | 1.7 | +32.5 | 51.9 | 39.7 | 1.2 | +19.0 | 25.0 | 4.8 |
| JOINT AS ONE | 2.3 | -1.7 | 131.4 | 81.2 | - | - | - | - |
| JOINT CHARGE PLAN | 0.1 | +1.2 | 30.0 | 0.0 | 0.2 | +16.6 | 13.4 | 7.6 |
| JOINT KNOWS CHALLENGE | 0.1 | -2.5 | 6.1 | 0.0 | 0.2 | -20.4 | 17.6 | 7.4 |
| KEEP FALLS | 0.1 | +0.2 | 0.0 | 0.0 | 0.1 | +1.1 | 0.0 | 0.0 |
| KEEPS ITS PREY | - | - | - | - | 0.0 | +0.0 | 0.0 | 9.5 |
| KEEPS ITS TARGET | 1.5 | +45.8 | 202.2 | 22.0 | 2.2 | +66.7 | 176.0 | 53.4 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KILLS COUNT | 1.7 | +54.1 | 142.6 | 54.4 | 2.3 | +131.5 | 164.6 | 25.3 |
| KILLS COUNT NEXT TURN | 5.0 | +120.4 | 289.7 | 114.8 | 7.0 | +254.4 | 303.6 | 144.2 |
| LONE CHARACTER SAFE SPOT | 0.3 | +13.0 | 16.1 | 2.4 | 0.2 | +2.7 | 9.5 | 0.0 |
| LONE WIZARD HOLDS BACK | 0.0 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 3.5 | 5.3 |
| LONE WIZARD KEPT IN | 0.6 | +26.9 | 0.0 | 0.0 | 0.2 | +20.3 | 0.0 | 0.0 |
| LONG SHOT | 0.4 | -0.4 | 41.3 | 0.0 | 0.7 | +1.0 | 39.4 | 5.0 |
| LOST CHARGE | 3.1 | -41.2 | 167.9 | 109.4 | 1.8 | -21.2 | 40.2 | 50.7 |
| LURE BY WHAT IT DRAWS | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MAKE SURE TOGETHER | 0.6 | +53.1 | 95.8 | 2.2 | 0.9 | +82.6 | 30.3 | 24.8 |
| MANOEUVRE | 0.4 | +10.8 | 0.0 | 11.6 | 0.1 | +7.3 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.1 | +0.0 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| MARCH CHECK | 0.5 | +21.3 | 0.0 | 21.5 | 0.3 | +10.3 | 0.0 | 3.2 |
| MARCH ODDS | 0.4 | +18.7 | 9.9 | 19.6 | 0.2 | +16.5 | 6.8 | 26.1 |
| MARCH OVER CASTS | 0.5 | +42.1 | 0.0 | 15.6 | 0.3 | +29.7 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 4.3 | +177.5 | 0.0 | 84.2 | 4.3 | +170.0 | 0.0 | 94.7 |
| MISSILES IN THE MOVE | 3.7 | +144.8 | 0.0 | 121.8 | 2.5 | +43.4 | 0.0 | 102.7 |
| MISSILES NEXT TURN | 4.6 | +87.1 | 0.0 | 164.9 | 3.0 | +26.1 | 0.0 | 102.7 |
| MODEL FACING | 0.2 | +57.3 | 0.0 | 3.3 | - | - | - | - |
| MONSTER WIZARD ROAMS | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 23.9 | 13.9 |
| MOVE AND CAST | 0.4 | +22.5 | 0.0 | 5.5 | 0.3 | +15.5 | 0.0 | 3.2 |
| MOVE SPELL IN RANGE | 0.4 | +12.6 | 0.0 | 2.4 | 0.1 | +2.1 | 0.0 | 0.0 |
| MOVE SPELL OUT OF RANGE | 0.7 | -51.6 | 0.0 | 14.9 | 0.2 | -14.3 | 0.0 | 0.0 |
| MOVE SPELL SPOT | 0.7 | +0.0 | 0.0 | 35.8 | 0.1 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE | 2.2 | +106.3 | 190.6 | 75.2 | 4.1 | +408.0 | 204.4 | 46.8 |
| MOVES UNITS SPELL | 0.1 | +3.3 | 0.0 | 0.0 | 0.1 | +0.6 | 0.0 | 0.0 |
| NEEDED THERE | 0.1 | +9.7 | 1.9 | 13.4 | 0.0 | +5.5 | 1.8 | 0.0 |
| NO CHARGE WHY | 2.4 | +0.0 | 154.2 | 71.9 | 4.6 | +0.0 | 252.5 | 103.6 |
| NO RALLY LEFT | 0.1 | +5.0 | 0.0 | 4.9 | - | - | - | - |
| NOT NEEDED | 0.3 | -11.4 | 38.7 | 5.6 | 0.3 | -9.5 | 42.7 | 0.0 |
| NOT TURNED | 5.8 | +54.0 | 0.0 | 133.1 | 5.9 | +93.2 | 0.0 | 120.6 |
| NOT WORTH A CAST | 0.5 | -0.4 | 0.0 | 0.0 | 0.3 | -0.2 | 0.0 | 0.0 |
| OFF BEST | 14.3 | -712.0 | 3.6 | 224.1 | 13.7 | -783.5 | 5.2 | 296.6 |
| OPENS A LANE | - | - | - | - | 0.1 | +0.1 | 10.2 | 0.0 |
| OPENS UP | 0.3 | +18.5 | 32.1 | 0.0 | 0.2 | +25.7 | 9.7 | 0.0 |
| OVERRUN THREAT | - | - | - | - | 0.0 | +0.3 | 0.0 | 0.0 |
| OVERRUNS AWAY | 0.5 | +16.9 | 32.1 | 0.0 | 0.6 | +12.1 | 40.9 | 18.2 |
| PATHS CROSS | 2.3 | +162.5 | 0.0 | 14.8 | 3.1 | +219.2 | 0.0 | 42.4 |
| PERIAPT WORTH | 0.1 | +6.8 | 0.0 | 15.0 | 0.1 | +6.1 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.2 | -4.8 | 0.0 | 0.0 | 0.1 | -0.6 | 0.0 | 3.1 |
| PLAN RESULT | 39.1 | +1805.5 | 1744.5 | 1020.2 | 38.5 | +1209.5 | 1440.6 | 1028.1 |
| PURSUES BIG PREY | 0.2 | -24.3 | 0.0 | 4.9 | 0.1 | -10.3 | 0.0 | 0.0 |
| PURSUES ON | - | - | - | - | 0.1 | +1.3 | 0.0 | 6.2 |
| RAIDS THE BAGGAGE NEXT TURN | 0.1 | +9.6 | 0.0 | 0.0 | 0.2 | +15.3 | 0.0 | 7.2 |
| RANDOM MOVE BY FIGURES | 1.1 | +24.8 | 0.0 | 42.6 | 1.7 | +21.1 | 0.0 | 88.2 |
| RANDOM MOVER NO PROMISE | 0.4 | -16.3 | 22.0 | 9.4 | 0.2 | -8.1 | 1.7 | 13.5 |
| REDIRECT BY WHAT IT STOPS | 0.2 | -2.4 | 0.0 | 5.1 | 0.8 | -13.9 | 0.0 | 4.7 |
| REDIRECT COUNTER | 2.4 | +165.6 | 0.0 | 36.3 | 3.9 | +291.9 | 0.0 | 59.0 |
| REDIRECT WEIGHED | 0.2 | +3.5 | 4.9 | 0.0 | 0.4 | +14.7 | 35.6 | 1.5 |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 22.9 |
| RESERVE FALL BACK | 0.5 | +18.4 | 0.0 | 6.4 | 0.8 | +37.1 | 0.0 | 9.2 |
| RESTRAINS TO SHOOT | 0.1 | +8.8 | 0.0 | 13.9 | 0.1 | +1.5 | 0.0 | 3.4 |
| RISK BY ARC | 2.7 | +110.9 | 240.9 | 118.6 | 3.4 | +70.2 | 272.6 | 69.0 |
| SAFER THAN THE JOB | 0.9 | +71.1 | 0.0 | 14.4 | 0.6 | +23.0 | 0.0 | 25.4 |
| SCOUT SPOT | 0.4 | +0.5 | 0.0 | 0.9 | 0.1 | +0.0 | 0.0 | 1.8 |
| SCOUT WAITS | 0.5 | +0.0 | 0.0 | 0.9 | 0.1 | +0.0 | 0.0 | 1.8 |
| SCREEN BY WHAT IT SAVES | 0.2 | -14.1 | 0.0 | 0.0 | 0.2 | -18.3 | 0.0 | 1.5 |
| SEARCH SPOT | 2.4 | +107.9 | 0.0 | 35.1 | 2.5 | +129.9 | 0.0 | 28.2 |
| SELF MOVE SPELL | 0.2 | +38.3 | 0.0 | 0.0 | 0.4 | +17.6 | 0.0 | 18.1 |
| SET UP TOGETHER | 0.6 | +53.1 | 95.8 | 2.2 | 1.6 | +121.7 | 67.6 | 38.6 |
| SET-UP ANY TARGET | 0.5 | +111.8 | 2.4 | 11.7 | 0.1 | +8.6 | 0.0 | 0.0 |
| SET-UP MISSED | 0.2 | +25.9 | 12.6 | 12.6 | 0.0 | +2.3 | 0.0 | 0.0 |
| SET-UP SPOT | 4.0 | +70.0 | 130.9 | 67.6 | - | - | - | - |
| SHOOTER COUNTED ONCE | - | - | - | - | 0.0 | -0.7 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.3 | +0.8 | 0.0 | 0.0 | 0.2 | +0.3 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.1 | +48.7 | 40.1 | 14.0 | 0.6 | +14.8 | 9.1 | 0.0 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 3.3 | 0.0 | +0.0 | 0.0 | 0.0 |
| SHOT REPLANNED | 0.7 | +0.0 | 182.5 | 19.8 | 0.1 | +0.0 | 4.9 | 0.0 |
| SHOTS IN THE MOVE | 15.2 | +749.7 | 0.0 | 228.8 | 7.1 | +159.4 | 0.0 | 95.5 |
| SPELL CATCH ODDS | 0.1 | -0.9 | 0.0 | 2.4 | 0.1 | -0.8 | 0.0 | 0.0 |
| SPELL SETS UP CHARGE | 0.6 | +132.7 | 2.4 | 11.7 | 0.1 | +29.7 | 0.0 | 0.0 |
| SPELL WORTH | 1.2 | +21.4 | 110.2 | 91.5 | 2.2 | +44.7 | 102.6 | 97.2 |
| SPELLS IN THE FIGHT | 0.9 | -3.1 | 123.4 | 12.3 | 1.0 | -20.7 | 100.8 | 39.4 |
| STABLE ROLE | 10.8 | +0.0 | 441.3 | 263.9 | 10.5 | +0.0 | 319.2 | 168.3 |
| STAY WEIGHED | 0.1 | +11.2 | 0.0 | 0.0 | - | - | - | - |
| STOPS | - | - | - | - | 0.2 | +6.2 | 19.0 | 3.2 |
| STOPS SHORT OF THE FLANK | 0.3 | +4.3 | 0.0 | 26.7 | 0.5 | +24.9 | 0.0 | 5.9 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 9.9 |
| SUPPORT NARROWED | 6.1 | -50.8 | 343.2 | 153.4 | 7.7 | -51.6 | 364.2 | 117.1 |
| SUPPORTS | 4.2 | +58.4 | 210.8 | 99.0 | 5.0 | +55.9 | 187.3 | 72.0 |
| SURE CHARGE BEATS ADVANCE | 0.2 | -5.6 | 16.4 | 27.0 | 0.1 | -4.5 | 1.4 | 5.2 |
| SURE REACH TOGETHER | 0.2 | +1.3 | 0.0 | 5.8 | 0.7 | -2.8 | 32.0 | 33.8 |
| THROUGH LINE OF FIRE | 0.5 | +10.6 | 0.0 | 18.4 | 0.3 | +15.8 | 0.0 | 3.2 |
| TURN WORTH | 0.4 | -26.9 | 39.2 | 0.0 | 0.1 | -9.5 | 3.1 | 5.2 |
| TWO OR MORE ARRIVE | 0.2 | +2.8 | 60.0 | 2.2 | 0.6 | +4.4 | 36.3 | 10.6 |
| WAIT AFTER COSTS | 5.8 | -264.1 | 322.7 | 127.9 | 6.9 | -401.0 | 317.6 | 92.7 |
| WALKS TO THE FIGHT | 1.5 | +18.6 | 33.0 | 35.1 | 0.6 | +12.5 | 12.1 | 4.0 |
| WAR ENGINE CHARGES | 0.1 | +3.2 | 6.2 | 8.6 | - | - | - | - |
| WAR ENGINE JOBS | 0.4 | +0.0 | 30.2 | 30.4 | 0.1 | +0.0 | 5.8 | 12.1 |
| WEARS DOWN | 1.6 | +66.0 | 146.4 | 82.9 | 1.5 | +49.9 | 105.0 | 25.5 |
| WHO HITS BACK | 0.2 | +36.9 | 0.0 | 0.0 | 0.2 | +11.5 | 0.0 | 14.5 |
| WHOLE FIGHT | 0.4 | +12.0 | 26.1 | 4.9 | 0.5 | +26.4 | 68.8 | 5.7 |
| WHOLE FIGHT GAIN | 0.4 | +23.2 | 26.8 | 17.4 | 0.8 | +52.6 | 52.8 | 2.8 |
| WIDER SPREAD | 3.1 | -9.9 | 265.5 | 80.8 | 3.9 | -8.0 | 288.8 | 66.0 |

### Rule changes: su-h2h-mine-e45904b-p4

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 1007 | 1007 | 1007 | 27.97 | -53835 | -53.5 |
| BEST FIRST | 291 | 291 | 291 | 8.08 | +11825 | +40.6 |
| PATHS CROSS | 194 | 194 | 194 | 5.39 | +13740 | +70.8 |
| SEARCH SPOT | 177 | 177 | 175 | 4.86 | +8563 | +48.9 |
| COUNTER-CHARGE COVER | 594 | 326 | 160 | 4.44 | +11464 | +71.7 |
| MOVE TO CHARGE | 229 | 229 | 129 | 3.58 | +7897 | +61.2 |
| FACES THE THREAT | 117 | 117 | 117 | 3.25 | +8990 | +76.8 |
| SUPPORTS | 330 | 330 | 116 | 3.22 | +1283 | +11.1 |
| KILLS COUNT NEXT TURN | 432 | 432 | 108 | 3.00 | +2586 | +23.9 |
| FALLBACK BY WORTH | 408 | 408 | 77 | 2.14 | +4050 | +52.6 |
| FOLLOW UP WEIGHED | 68 | 68 | 68 | 1.89 | +8366 | +123.0 |
| SHOTS IN THE MOVE | 806 | 562 | 68 | 1.89 | +2029 | +29.8 |
| SET-UP SPOT | 143 | 143 | 62 | 1.72 | +2133 | +34.4 |
| WAIT AFTER COSTS | 459 | 459 | 62 | 1.72 | +1240 | +20.0 |
| RANDOM MOVE BY FIGURES | 100 | 100 | 60 | 1.67 | +1653 | +27.6 |
| ADVANCE LANE KEPT | 55 | 55 | 55 | 1.53 | +0 | +0.0 |
| ARTILLERY RE-ROLL WEIGHED | 51 | 51 | 51 | 1.42 | +0 | +0.0 |
| CHARGE NOW FIRST | 191 | 191 | 51 | 1.42 | -2757 | -54.0 |
| SAFER THAN THE JOB | 51 | 51 | 51 | 1.42 | +3385 | +66.4 |
| MAX FOR POSITIONING | 311 | 171 | 47 | 1.31 | +698 | +14.8 |
| WALKS TO THE FIGHT | 76 | 76 | 47 | 1.31 | +399 | +8.5 |
| BEST FACING | 44 | 44 | 44 | 1.22 | +1624 | +36.9 |
| REDIRECT COUNTER | 228 | 126 | 44 | 1.22 | +3018 | +68.6 |
| RESERVE FALL BACK | 44 | 44 | 44 | 1.22 | +1998 | +45.4 |
| RISK BY ARC | 219 | 212 | 43 | 1.19 | +1129 | +26.3 |
| CANNON SIGHT KEPT | 42 | 42 | 42 | 1.17 | +0 | +0.0 |
| BLOCKED WHEEL | 39 | 39 | 39 | 1.08 | +617 | +15.8 |
| KILLS COUNT | 142 | 140 | 36 | 1.00 | +2228 | +61.9 |
| BEST OVERALL | 35 | 35 | 35 | 0.97 | +2447 | +69.9 |
| CHARGE NOW WEIGHED | 35 | 35 | 35 | 0.97 | +2008 | +57.4 |
| HOLDS AMBUSHERS | 35 | 35 | 35 | 0.97 | +0 | +0.0 |
| MISSILES IN THE MOVE | 223 | 139 | 32 | 0.89 | +1145 | +35.8 |
| COMBAT PIVOT | 30 | 30 | 30 | 0.83 | +0 | +0.0 |
| LONE WIZARD KEPT IN | 28 | 28 | 28 | 0.78 | +1699 | +60.7 |
| STOPS SHORT OF THE FLANK | 28 | 28 | 28 | 0.78 | +1051 | +37.5 |
| THROUGH LINE OF FIRE | 28 | 28 | 28 | 0.78 | +949 | +33.9 |
| SET UP TOGETHER | 79 | 69 | 27 | 0.75 | +2142 | +79.3 |
| SHOT REPLANNED | 27 | 27 | 27 | 0.75 | +0 | +0.0 |
| SHOOTS FROM THE BEST SPOT | 63 | 63 | 26 | 0.72 | +809 | +31.1 |
| KEEPS ITS TARGET | 135 | 132 | 25 | 0.69 | +478 | +19.1 |
| MARCH CHECK | 28 | 28 | 25 | 0.69 | +1122 | +44.9 |
| MOVE AND CAST | 24 | 24 | 24 | 0.67 | +1367 | +57.0 |
| MARCH ODDS | 22 | 22 | 22 | 0.61 | +58 | +2.7 |
| BEST PREY | 67 | 67 | 21 | 0.58 | +679 | +32.3 |
| BIG CHARACTER SAFETY | 21 | 21 | 21 | 0.58 | +0 | +0.0 |
| CANNON PLANNED TARGET | 204 | 204 | 21 | 0.58 | -270 | -12.8 |
| CAST JOB | 43 | 43 | 21 | 0.58 | +323 | +15.4 |
| REDIRECT WEIGHED | 21 | 21 | 21 | 0.58 | +584 | +27.8 |
| SCOUT WAITS | 21 | 21 | 21 | 0.58 | +0 | +0.0 |
| WHOLE FIGHT GAIN | 41 | 40 | 19 | 0.53 | +931 | +49.0 |
| FRIENDS SHOTS CHECKED | 18 | 18 | 18 | 0.50 | +1451 | +80.6 |
| HONEST WORTH | 570 | 563 | 18 | 0.50 | +190 | +10.6 |
| SHOOTERS IN TWO RANKS | 18 | 18 | 18 | 0.50 | +41 | +2.3 |
| CASTER AWAY FROM SCREEN | 17 | 17 | 17 | 0.47 | +0 | +0.0 |
| MANOEUVRE | 20 | 20 | 17 | 0.47 | +651 | +38.3 |
| CHARGE BAND | 16 | 16 | 16 | 0.44 | +0 | +0.0 |
| WHO HITS BACK | 15 | 15 | 15 | 0.42 | +1226 | +81.7 |
| WEARS DOWN | 110 | 104 | 14 | 0.39 | +342 | +24.4 |
| INVITES THE FIGHT | 106 | 106 | 13 | 0.36 | +141 | +10.9 |
| MAKE SURE TOGETHER | 52 | 37 | 13 | 0.36 | +1162 | +89.4 |
| JOINT AS ONE | 84 | 84 | 12 | 0.33 | -398 | -33.1 |
| STUCK PIVOT | 12 | 12 | 12 | 0.33 | +0 | +0.0 |
| OPENS UP | 20 | 19 | 11 | 0.31 | +472 | +42.9 |
| SUPPORT NARROWED | 498 | 498 | 10 | 0.28 | -116 | -11.6 |
| CASTS FROM BEHIND | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| CHAFF PASSED | 9 | 9 | 9 | 0.25 | -16 | -1.8 |
| OVERRUNS AWAY | 40 | 38 | 9 | 0.25 | +258 | +28.6 |
| PIVOT GUARDS FLANK | 9 | 9 | 9 | 0.25 | -194 | -21.6 |
| SHORT GUN FORWARD | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| SURE CHARGE BEATS ADVANCE | 9 | 9 | 9 | 0.25 | -363 | -40.3 |
| PURSUES BIG PREY | 8 | 8 | 8 | 0.22 | -1243 | -155.4 |
| RAIDS THE BAGGAGE NEXT TURN | 10 | 10 | 8 | 0.22 | +335 | +41.9 |
| BLOCKED CHARGE SKIPPED | 7 | 7 | 7 | 0.19 | +0 | +0.0 |
| LOST CHARGE | 175 | 175 | 7 | 0.19 | +173 | +24.7 |
| MISSILES NEXT TURN | 272 | 165 | 7 | 0.19 | +62 | +8.9 |
| MODEL FACING | 7 | 7 | 7 | 0.19 | +2064 | +294.9 |
| MOVES UNITS SPELL | 7 | 7 | 7 | 0.19 | +138 | +19.7 |
| RESTRAINS TO SHOOT | 7 | 7 | 7 | 0.19 | +373 | +53.3 |
| BACKUP TARGETS | 71 | 39 | 6 | 0.17 | +18 | +3.0 |
| REFUSING RETIRES | 22 | 22 | 6 | 0.17 | -3 | -0.5 |
| KEEP FALLS | 5 | 5 | 5 | 0.14 | +150 | +30.0 |
| PERIAPT WORTH | 5 | 5 | 5 | 0.14 | +464 | +92.8 |
| SURE REACH TOGETHER | 30 | 24 | 5 | 0.14 | +31 | +6.2 |
| WAR ENGINE JOBS | 21 | 21 | 5 | 0.14 | -151 | -30.2 |
| BEST PRIZE | 4 | 4 | 4 | 0.11 | -203 | -50.7 |
| CASTING BLOCK | 7 | 7 | 4 | 0.11 | +161 | +40.2 |
| NEEDED THERE | 4 | 4 | 4 | 0.11 | +0 | +0.0 |
| STAY WEIGHED | 4 | 4 | 4 | 0.11 | +404 | +101.0 |
| WHOLE FIGHT | 32 | 29 | 4 | 0.11 | +246 | +61.5 |
| WIDER SPREAD | 249 | 242 | 4 | 0.11 | +9 | +2.2 |
| FIRE AND FLEE | 3 | 3 | 3 | 0.08 | +130 | +43.5 |
| HUNT IN PAIRS | 29 | 14 | 3 | 0.08 | +224 | +74.7 |
| LONE WIZARD HOLDS BACK | 10 | 10 | 3 | 0.08 | -187 | -62.3 |
| SPELLS IN THE FIGHT | 67 | 62 | 3 | 0.08 | +61 | +20.2 |
| BLOWS WHERE AIMED | 21 | 19 | 2 | 0.06 | +124 | +62.1 |
| BOUND ASSAILMENT | 2 | 2 | 2 | 0.06 | +0 | +0.2 |
| CARRIES OUT SET-UP | 12 | 12 | 2 | 0.06 | -119 | -59.4 |
| CONTINUE AHEAD WEIGHED | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| EDGE GIVE GROUND | 8 | 8 | 2 | 0.06 | +132 | +65.8 |
| ELIXIR WORTH | 2 | 2 | 2 | 0.06 | +195 | +97.5 |
| FLEE LOSES BLESSING | 2 | 2 | 2 | 0.06 | +62 | +31.2 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| LONG SHOT | 40 | 40 | 2 | 0.06 | +19 | +9.6 |
| NO RALLY LEFT | 2 | 2 | 2 | 0.06 | +139 | +69.4 |
| PURSUES ON | 2 | 2 | 2 | 0.06 | +47 | +23.3 |
| REDIRECT BY WHAT IT STOPS | 39 | 39 | 2 | 0.06 | +50 | +25.1 |
| BOMBING RUN | 1 | 1 | 1 | 0.03 | +32 | +32.1 |
| CARRIES OUT CLOSE-IN | 13 | 13 | 1 | 0.03 | -35 | -35.4 |
| CARRIES OUT COUNTER | 3 | 3 | 1 | 0.03 | -39 | -39.0 |
| CATCH ODDS | 1 | 1 | 1 | 0.03 | -6 | -6.2 |
| CHARGER SLAIN LOST | 44 | 41 | 1 | 0.03 | +53 | +53.2 |
| DEFENSIVE ARMY | 7 | 7 | 1 | 0.03 | -3 | -2.8 |
| DEFENSIVE FLOOR | 3 | 3 | 1 | 0.03 | +24 | +24.4 |
| FOCUS FIRE | 1 | 1 | 1 | 0.03 | +15 | +14.8 |
| JOINT CHARGE PLAN | 9 | 9 | 1 | 0.03 | +263 | +262.7 |
| MOVE SPELL IN RANGE | 17 | 7 | 1 | 0.03 | +67 | +66.9 |
| STOPS | 6 | 6 | 1 | 0.03 | +75 | +74.9 |
| WAR ENGINE CHARGES | 2 | 2 | 1 | 0.03 | +28 | +27.7 |
| ALREADY CARRIED | 1 | not checked | - | - | - | - |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 34 | 34 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 48 | trace | - | - | - | - |
| CATCH FLIERS | 1 | not checked | - | - | - | - |
| CHAMPION TAKES THE CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| CHARIOT NO STATIC JOB | 2 | 2 | 0 | 0.00 | - | - |
| CHARIOT WIZARD CAREFUL | 12 | 12 | 0 | 0.00 | - | - |
| CHEAP HELPER | 4 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 45 | not checked | - | - | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT LIFT | 4 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 423 | not checked | - | - | - | - |
| GIVES UP | 5 | 4 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 2 | 2 | 0 | 0.00 | - | - |
| GROUND FLIERS | 4 | not checked | - | - | - | - |
| HELPER ALREADY ASKED | 4 | not checked | - | - | - | - |
| HELPER UNSEEN | 34 | 31 | 0 | 0.00 | - | - |
| HILL BY ITS CHANCE | 30 | 30 | 0 | 0.00 | - | - |
| HUNT ADVANCE | 3 | 3 | 0 | 0.00 | - | - |
| HUNT DROPPED | 3 | trace | - | - | - | - |
| HUNT KEPT | 3 | trace | - | - | - | - |
| HUNT RESULT | 8 | trace | - | - | - | - |
| HUNT THE GUNS | 8 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 13 | 9 | 0 | 0.00 | - | - |
| KEEPS ITS PREY | 1 | 1 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 18 | not checked | - | - | - | - |
| LURE BY WHAT IT DRAWS | 1 | 1 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 3 | trace | - | - | - | - |
| MARCH OVER CASTS | 30 | 30 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 12 | 12 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 31 | trace | - | - | - | - |
| MOVE SPELL SPOT | 28 | not checked | - | - | - | - |
| NO CHARGE WHY | 251 | not checked | - | - | - | - |
| NOT NEEDED | 23 | 23 | 0 | 0.00 | - | - |
| NOT TURNED | 421 | 421 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 31 | not checked | - | - | - | - |
| OPENS A LANE | 2 | 1 | 0 | 0.00 | - | - |
| OVERRUN THREAT | 1 | not checked | - | - | - | - |
| PLAN RESULT | 2796 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 21 | 21 | 0 | 0.00 | - | - |
| SCOUT SPOT | 19 | 19 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 15 | 15 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 21 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 22 | not checked | - | - | - | - |
| SET-UP MISSED | 7 | trace | - | - | - | - |
| SHOOTER COUNTED ONCE | 1 | 1 | 0 | 0.00 | - | - |
| SPELL CATCH ODDS | 4 | not checked | - | - | - | - |
| SPELL SETS UP CHARGE | 25 | not checked | - | - | - | - |
| SPELL WORTH | 124 | not checked | - | - | - | - |
| STABLE ROLE | 765 | 762 | 0 | 0.00 | - | - |
| TURN WORTH | 16 | 15 | 0 | 0.00 | - | - |
| TWO OR MORE ARRIVE | 27 | 22 | 0 | 0.00 | - | - |

### Off best figure: su-h2h-mine-e45904b-p4

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 12.17 | 11.89 | 55.6 |
| FALLBACK | gate | 0.61 | 0.89 | 54.4 |
| CHARGE NOW FIRST | rule | 0.64 | 0.78 | 54.0 |
| TURN GATE | gate | 0.75 | 0.50 | 35.4 |
| NO REASON | gate | 0.33 | - | 17.6 |
| JOINT AS ONE | rule | 0.31 | - | 36.1 |
| AFTERMATH BAND | gate | 0.14 | 0.14 | 2.9 |
| SUPPORT NARROWED | rule | 0.14 | 0.14 | 11.6 |
| PATHS CROSS | rule | 0.11 | 0.14 | 13.0 |
| PIVOT GUARDS FLANK | rule | 0.19 | 0.06 | 21.6 |
| BIG CHARACTER SAFETY | rule | 0.06 | 0.17 | 9.6 |
| LONE CHARACTER SAFE SPOT | gate | 0.14 | 0.08 | 37.0 |
| PURSUES BIG PREY | rule | 0.17 | 0.06 | 155.4 |
| SUPPORT REQUEST | gate | 0.11 | 0.11 | 72.6 |
| SURE CHARGE BEATS ADVANCE | rule | 0.14 | 0.08 | 45.3 |
| CANNON PLANNED TARGET | rule | 0.17 | - | 73.3 |
| CHARGE NOW WEIGHED | rule | 0.08 | 0.08 | 79.1 |
| STOPS SHORT OF THE FLANK | rule | 0.06 | 0.08 | 10.5 |
| WAR ENGINE JOBS | rule | 0.14 | - | 30.2 |
| BEST PRIZE | rule | 0.06 | 0.06 | 50.7 |
| CHAFF PASSED | rule | 0.06 | 0.06 | 4.0 |
| BLOCKED WHEEL | rule | 0.03 | 0.06 | 129.6 |
| FIGHT ORDER BAND | gate | 0.03 | 0.06 | 1.9 |
| LONE WIZARD HOLDS BACK | rule | - | 0.08 | 62.3 |
| MARCH ODDS | rule | 0.03 | 0.06 | 59.1 |
| CARRIES OUT SET-UP | rule | 0.03 | 0.03 | 59.4 |
| FOLLOW UP WEIGHED | rule | 0.03 | 0.03 | 2.6 |
| REFUSING RETIRES | rule | 0.06 | - | 0.8 |
| SAFER THAN THE JOB | rule | - | 0.06 | 10.0 |
| THROUGH LINE OF FIRE | rule | 0.06 | - | 10.7 |
| CARRIES OUT CLOSE-IN | rule | 0.03 | - | 35.4 |
| CARRIES OUT COUNTER | rule | - | 0.03 | 39.0 |
| CATCH ODDS | rule | 0.03 | - | 6.2 |
| DEFENSIVE ARMY | rule | 0.03 | - | 2.8 |
| FACES THE THREAT | rule | - | 0.03 | 4.2 |
| FRIENDS SHOTS CHECKED | rule | 0.03 | - | 2.4 |
| REDIRECT WEIGHED | rule | - | 0.03 | 37.0 |
| RULE SWITCHED OFF | gate | - | 0.03 | 14.1 |
| WHO HITS BACK | rule | - | 0.03 | 3.3 |

### Plans: su-h2h-mine-e45904b-p4

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 12.4 | 19% | 388 | 403 | 104% |
| Mine | charge | 3.7 | 55% | 257 | 344 | 134% |
| Mine | close in | 3.6 | 32% | 164 | 124 | 75% |
| Mine | hold | 4.4 | 31% | 283 | 0 | 0% |
| Mine | join | 0.6 | 95% | 11 | 0 | 0% |
| Mine | shoot | 9.9 | 61% | 448 | 935 | 209% |
| Mine | support | 4.5 | 93% | 50 | 0 | 0% |
| Opponent | advance | 13.0 | 12% | 364 | 322 | 89% |
| Opponent | charge | 5.1 | 54% | 431 | 481 | 112% |
| Opponent | close in | 6.2 | 23% | 457 | 213 | 47% |
| Opponent | hold | 4.0 | 34% | 259 | 0 | 0% |
| Opponent | join | 0.6 | 91% | 39 | 0 | 0% |
| Opponent | shoot | 3.6 | 62% | 54 | 198 | 365% |
| Opponent | support | 5.8 | 90% | 36 | 0 | 0% |

### Packages: hunt the guns, su-h2h-mine-e45904b-p4

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 11 |
| Opponent | 0.2 | 8 | 0 | 25% | 38% | 0% | 2.7 | 371 | 142 | 38% | 122 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 137 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 22 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| High Elf Realms | 0.1 | 1 | 0 | 0% | 100% | 0% | 4.0 | 109 | 91 | 100% | 61 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 58 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 225 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 136 |
| Tomb Kings of Khemri | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Vampire Counts | 0.5 | 4 | 0 | 25% | 0% | 0% | - | 323 | 0 | 0% | 149 |
| Warriors of Chaos | 0.1 | 1 | 0 | 0% | 100% | 0% | 2.0 | 457 | 438 | 100% | 55 |
| Wood Elf Realms | 0.3 | 2 | 0 | 50% | 50% | 0% | 2.0 | 555 | 305 | 50% | 60 |

### Battle groups: su-h2h-mine-e45904b-p4

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 9.4 | 25% | 50% | 16% | 64% | 22% | 18% | 6% | 54% | 0% |
| Mine | REDIRECT COUNTER | 2.4 | 32% | 54% | 11% | 33% | 12% | 0% | 8% | 76% | 4% |
| Opponent | COUNTER-CHARGE COVER | 7.1 | 18% | 72% | 26% | 17% | 34% | 14% | 20% | 31% | 0% |
| Opponent | REDIRECT COUNTER | 3.9 | 24% | 71% | 15% | 0% | 21% | 0% | 17% | 55% | 7% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: su-h2h-mine-e45904b-p4

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 4 | 154 (4) | 154 | 0 | 38 | 0% | 2.5 | - | 154 (4) | - | 371 (1) | 97 (3) |
| Mine | Chaff | 34 | 13 (34) | 2 | 11 | 72 | 24% | 2.7 | 19 (14) | 0 (7) | 13 (13) | 3 (22) | 31 (12) |
| Mine | Character | 106 | 40 (106) | 40 | 0 | 38 | 18% | 2.2 | 37 (31) | 44 (58) | 39 (7) | 38 (47) | 44 (49) |
| Mine | Clean-up | 22 | 33 (22) | 16 | 17 | 37 | 23% | 3.2 | 0 (2) | 34 (16) | 46 (4) | 6 (10) | 48 (12) |
| Mine | Early | 1 | 0 (1) | 0 | 0 | 100 | 0% | 4.0 | - | 0 (1) | - | - | 0 (1) |
| Mine | Fast | 4 | 89 (4) | 89 | 0 | 73 | 25% | 4.0 | 131 (2) | 48 (2) | - | 89 (3) | 89 (1) |
| Mine | Fast Hammer | 41 | 67 (41) | 36 | 30 | 38 | 15% | 2.8 | 40 (27) | 179 (9) | 0 (5) | 90 (25) | 32 (16) |
| Mine | Fragile | 4 | 0 (4) | 0 | 0 | 73 | 25% | 2.7 | 0 (1) | 0 (2) | - | 0 (1) | 0 (2) |
| Mine | Hammer | 65 | 36 (65) | 26 | 10 | 44 | 20% | 2.3 | 52 (13) | 36 (45) | 6 (7) | 48 (40) | 22 (25) |
| Mine | Holder | 31 | 95 (31) | 18 | 77 | 21 | 35% | 2.8 | 69 (7) | 161 (15) | 8 (8) | 152 (19) | 28 (11) |
| Mine | Shooter | 34 | 65 (34) | 38 | 27 | 37 | 3% | 1.6 | 30 (8) | 87 (21) | 30 (5) | 72 (25) | 42 (9) |
| Mine | Support | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Mine | War machine | 56 | 64 (56) | 64 | 0 | 32 | 2% | 1.3 | 44 (16) | 89 (30) | 30 (10) | 57 (9) | 66 (47) |
| Mine | Wizard | 17 | 15 (17) | 15 | 0 | 67 | 6% | 2.2 | 0 (5) | 46 (5) | 0 (1) | 0 (6) | 43 (5) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Chaff | 75 | 31 (75) | 6 | 25 | 53 | 44% | 2.5 | 29 (31) | 38 (17) | 29 (27) | 34 (56) | 22 (19) |
| Opponent | Character | 97 | 54 (97) | 54 | 0 | 30 | 18% | 2.5 | 69 (44) | 43 (40) | 18 (8) | 57 (53) | 48 (39) |
| Opponent | Clean-up | 11 | 79 (11) | 9 | 70 | 29 | 45% | 2.0 | 0 (3) | 79 (6) | 131 (2) | 14 (6) | 116 (5) |
| Opponent | Fast | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Fast Hammer | 60 | 55 (60) | 38 | 17 | 49 | 25% | 2.8 | 54 (26) | 58 (25) | 50 (9) | 52 (39) | 59 (21) |
| Opponent | Fragile | 17 | 0 (17) | 0 | 0 | 25 | 18% | 2.6 | 0 (5) | 0 (8) | 0 (4) | 0 (13) | 0 (4) |
| Opponent | Hammer | 65 | 31 (65) | 17 | 14 | 45 | 26% | 3.1 | 22 (20) | 34 (38) | 34 (7) | 31 (41) | 32 (24) |
| Opponent | Holder | 29 | 34 (29) | 8 | 27 | 22 | 55% | 4.2 | 23 (11) | 45 (13) | 29 (4) | 41 (18) | 27 (10) |
| Opponent | Shooter | 33 | 68 (33) | 16 | 53 | 33 | 3% | 1.5 | 51 (9) | 82 (21) | 18 (3) | 49 (18) | 89 (15) |
| Opponent | Support | 6 | 91 (6) | 91 | 0 | 0 | 50% | 3.0 | 135 (4) | 0 (2) | - | 135 (4) | 0 (2) |
| Opponent | War machine | 6 | 63 (6) | 63 | 0 | 61 | 0% | 1.0 | 91 (3) | 22 (3) | - | 91 (3) | 22 (3) |
| Opponent | Wizard | 19 | 12 (19) | 12 | 0 | 56 | 5% | 2.2 | 5 (9) | 15 (3) | 27 (4) | 18 (11) | 0 (5) |

### Charged fights: su-h2h-mine-e45904b-p4

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 246 | 290 | 2.5 | 1.5 | 116 | 69 | +46 | 3 of 10 | 8 of 10 | +11 | +82 |
| Mine | Chaos Dwarfs | 4 | 64 | 258 | 2.5 | 1.2 | 103 | 40 | +63 | 3 of 10 | 7 of 10 | -116 | +108 |
| Mine | Dwarfen Mountain Holds | 3 | 682 | 0 | 0.3 | 1.0 | 0 | 0 | +0 | 1 of 1 | 1 of 1 | - | +0 |
| Mine | Empire of Man | 5 | 547 | 281 | 1.8 | 1.2 | 156 | 106 | +51 | 5 of 9 | 7 of 9 | +102 | +36 |
| Mine | Grand Cathay | 4 | 319 | 244 | 2.5 | 1.1 | 98 | 0 | +98 | 4 of 10 | 9 of 10 | +0 | +109 |
| Mine | High Elf Realms | 4 | 456 | 191 | 3.8 | 1.3 | 51 | 8 | +43 | 6 of 15 | 10 of 15 | +107 | +27 |
| Mine | Kingdom of Bretonnia | 1 | 65 | 577 | 6.0 | 1.0 | 96 | 0 | +96 | 3 of 6 | 5 of 6 | - | +96 |
| Mine | Lizardmen | 1 | 55 | 847 | 8.0 | 1.4 | 106 | 135 | -29 | 5 of 8 | 5 of 8 | -104 | +15 |
| Mine | Ogre Kingdoms | 2 | 55 | 128 | 2.5 | 1.2 | 51 | 70 | -19 | 2 of 5 | 2 of 5 | +0 | -24 |
| Mine | Skaven | 2 | 0 | 33 | 1.5 | 1.0 | 22 | 0 | +22 | 0 of 3 | 2 of 3 | - | +22 |
| Mine | Tomb Kings of Khemri | 2 | 100 | 352 | 3.0 | 1.5 | 118 | 0 | +118 | 2 of 6 | 6 of 6 | +170 | +65 |
| Mine | Vampire Counts | 2 | 14 | 356 | 4.5 | 1.0 | 79 | 10 | +69 | 1 of 9 | 8 of 9 | - | +69 |
| Mine | Warriors of Chaos | 2 | 0 | 742 | 5.5 | 1.1 | 135 | 76 | +59 | 4 of 11 | 9 of 11 | +458 | +19 |
| **Mine** | all armies | 36 | 266 | 277 | 2.9 | 1.2 | 97 | 44 | +53 | 39 of 103 | 79 of 103 | +48 | +54 |
| Opponent | Empire of Man | 1 | 575 | 185 | 2.0 | 1.5 | 92 | 132 | -40 | 2 of 2 | 2 of 2 | +185 | -265 |
| Opponent | High Elf Realms | 5 | 85 | 507 | 3.6 | 1.2 | 141 | 40 | +101 | 9 of 18 | 12 of 18 | +77 | +107 |
| Opponent | Lizardmen | 2 | 102 | 512 | 2.0 | 1.0 | 256 | 0 | +256 | 2 of 4 | 3 of 4 | - | +256 |
| Opponent | Orc & Goblin Tribes | 3 | 0 | 357 | 3.7 | 1.3 | 97 | 0 | +97 | 3 of 11 | 9 of 11 | +134 | +89 |
| Opponent | Skaven | 4 | 138 | 69 | 3.0 | 1.0 | 23 | 117 | -94 | 7 of 12 | 5 of 12 | - | -94 |
| Opponent | Tomb Kings of Khemri | 2 | 80 | 647 | 4.5 | 1.2 | 144 | 8 | +136 | 3 of 9 | 8 of 9 | +358 | +72 |
| Opponent | Vampire Counts | 6 | 0 | 338 | 3.8 | 1.2 | 88 | 17 | +71 | 12 of 23 | 15 of 23 | -7 | +88 |
| Opponent | Warriors of Chaos | 7 | 9 | 395 | 3.6 | 1.2 | 111 | 15 | +95 | 12 of 25 | 17 of 25 | +142 | +86 |
| Opponent | Wood Elf Realms | 6 | 62 | 481 | 4.8 | 1.3 | 100 | 5 | +94 | 7 of 29 | 24 of 29 | +103 | +92 |
| **Opponent** | all armies | 36 | 65 | 391 | 3.7 | 1.2 | 106 | 25 | +80 | 57 of 133 | 95 of 133 | +114 | +73 |

### Effective charges: su-h2h-mine-e45904b-p4

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 10 | 2 (net -118) | 0 | 2 (net +0) | 2 (net +96) | 0 | 4 (net +127) | 0 | 20% (2 of 10) |
| Mine | Chaos Dwarfs | 10 | 2 (net +308) | 0 | 2 (net -32) | 2 (net +156) | 2 (net -116) | 0 | 2 | 25% (2 of 8) |
| Mine | Dwarfen Mountain Holds | 1 | 0 | 0 | 0 | 1 (net +0) | 0 | 0 | 0 | 0% (0 of 1) |
| Mine | Empire of Man | 9 | 3 (net +140) | 0 | 2 (net +102) | 1 (net -345) | 0 | 2 (net +0) | 1 | 25% (2 of 8) |
| Mine | Grand Cathay | 10 | 0 | 0 | 1 (net +0) | 4 (net +244) | 1 (net +0) | 4 (net +0) | 0 | 10% (1 of 10) |
| Mine | High Elf Realms | 15 | 2 (net +0) | 0 | 2 (net +0) | 5 (net +37) | 1 (net +136) | 3 (net +108) | 2 | 15% (2 of 13) |
| Mine | Kingdom of Bretonnia | 6 | 1 (net +210) | 0 | 0 | 3 (net +122) | 0 | 2 (net +0) | 0 | 0% (0 of 6) |
| Mine | Lizardmen | 8 | 2 (net +241) | 2 (net -112) | 1 (net -316) | 2 (net -88) | 0 | 0 | 1 | 14% (1 of 7) |
| Mine | Ogre Kingdoms | 5 | 0 | 1 (net +0) | 1 (net +0) | 2 (net -32) | 0 | 0 | 1 | 25% (1 of 4) |
| Mine | Skaven | 3 | 1 (net +0) | 0 | 0 | 0 | 0 | 2 (net +33) | 0 | 0% (0 of 3) |
| Mine | Tomb Kings of Khemri | 6 | 0 | 0 | 3 (net +122) | 1 (net +75) | 1 (net +120) | 1 (net +144) | 0 | 50% (3 of 6) |
| Mine | Vampire Counts | 9 | 1 (net -40) | 0 | 2 (net +5) | 3 (net +116) | 1 (net +75) | 2 (net +116) | 0 | 22% (2 of 9) |
| Mine | Warriors of Chaos | 11 | 0 | 1 (net +0) | 2 (net -15) | 3 (net +84) | 3 (net +112) | 1 (net +0) | 1 | 20% (2 of 10) |
| Opponent | Empire of Man | 2 | 0 | 0 | 1 (net +185) | 1 (net -265) | 0 | 0 | 0 | 50% (1 of 2) |
| Opponent | High Elf Realms | 18 | 4 (net -1) | 0 | 3 (net +187) | 3 (net -50) | 0 | 6 (net +139) | 2 | 19% (3 of 16) |
| Opponent | Lizardmen | 4 | 0 | 0 | 0 | 2 (net +155) | 0 | 1 (net +124) | 1 | 0% (0 of 3) |
| Opponent | Orc & Goblin Tribes | 11 | 1 (net +297) | 0 | 1 (net +185) | 1 (net +0) | 1 (net +83) | 1 (net +0) | 6 | 20% (1 of 5) |
| Opponent | Skaven | 12 | 1 (net -210) | 1 (net +0) | 3 (net +70) | 1 (net +0) | 0 | 5 (net -187) | 1 | 27% (3 of 11) |
| Opponent | Tomb Kings of Khemri | 9 | 0 | 0 | 4 (net +126) | 2 (net +138) | 1 (net +145) | 2 (net +151) | 0 | 44% (4 of 9) |
| Opponent | Vampire Counts | 23 | 5 (net -21) | 0 | 7 (net +133) | 4 (net +74) | 2 (net +14) | 3 (net +109) | 2 | 33% (7 of 21) |
| Opponent | Warriors of Chaos | 25 | 7 (net +211) | 0 | 3 (net +0) | 6 (net +75) | 3 (net +123) | 4 (net +6) | 2 | 13% (3 of 23) |
| Opponent | Wood Elf Realms | 29 | 2 (net -28) | 1 (net +0) | 8 (net +173) | 5 (net +57) | 4 (net +70) | 7 (net +83) | 2 | 30% (8 of 27) |

### Charged fights, damage counted: su-h2h-mine-e45904b-p4

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 14 | 212 | 283 | +104 | 205 | 120 | +84 | +39.8 |
| Mine | 50-54% | 4 | 259 | 325 | -56 | 261 | 297 | -36 | -14.1 |
| Mine | Effective (55-75%) | 18 | 291 | 248 | +9 | 83 | 35 | +48 | +16.4 |
| Mine | 76-89% | 29 | 287 | 220 | +73 | 136 | 57 | +79 | +27.4 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 21 | 262 | 164 | +61 | 110 | 35 | +75 | +28.6 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 9 | 557 | 100 | +48 | 93 | 50 | +42 | +7.6 |
| Mine | No odds | 8 | 245 | 145 | +29 | 59 | 40 | +19 | +7.8 |
| Mine | All fights | 103 | 292 | 210 | +53 | 126 | 65 | +61 | +20.9 |
| Opponent | Long shot (under 50%) | 20 | 253 | 283 | +70 | 117 | 44 | +73 | +29.1 |
| Opponent | 50-54% | 2 | 75 | 224 | +0 | 8 | 11 | -3 | -4.1 |
| Opponent | Effective (55-75%) | 30 | 327 | 244 | +132 | 170 | 27 | +143 | +43.7 |
| Opponent | 76-89% | 25 | 240 | 146 | +48 | 85 | 48 | +37 | +15.4 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 29 | 287 | 187 | +43 | 111 | 73 | +38 | +13.2 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 11 | 434 | 86 | +82 | 95 | 28 | +67 | +15.5 |
| Opponent | No odds | 16 | 335 | 168 | +124 | 142 | 24 | +119 | +35.3 |
| Opponent | All fights | 133 | 297 | 197 | +80 | 121 | 43 | +78 | +26.4 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| su-h2h-mine-e45904b-p4 | move | 393 | 99 (25%) | 64 (16%) | 58 (15%) | 236 (60%) |
| su-h2h-mine-e45904b-p4 | objective | 357 | 55 (15%) | 35 (10%) | 45 (13%) | 257 (72%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0114, L0130, L2527, L2634 |
| Charmed Shield | Opponent | L0434, L0624, L0926, L1034, L1126, L1427, L2227, L2527, L2634, L3234 |
| Clockwork Compass | Mine | L1220 |
| Elixir of Power | Mine | L1126 |
| Elixir of Power | Opponent | L0819, L1719, L1819 |
| Fistful of Laurels | Mine | L1819, L1835 |
| Invocation of Nehek | Mine | L2527 |
| Invocation of Nehek | Opponent | L0624, L1427, L2227, L2527 |
| Opal Amulet | Mine | L1427 |
| Opal Amulet | Opponent | L0114, L0214, L1314 |
| Periapt of Soul Exchange | Mine | L2021, L2123 |
| Periapt of Soul Exchange | Opponent | L0520, L1220, L1621, L2021 |
| Ring of Doom | Mine | L0214, L0230, L1126, L1220, L1523 |
| Ring of Doom | Opponent | L0315, L1331, L2331 |
| Ring of Jet | Mine | L1017, L1034, L1126, L1220 |
| Standard of the Fell Warrior | Mine | L1314, L1331 |
| Standard of the Fell Warrior | Opponent | L0713 |
| Storm Daemon (Renegade 2.0) | Mine | L2123 |
| Storm Daemon (Renegade 2.0) | Opponent | L1621, L2021 |
| Twice-Blessed Armour | Mine | L0713, L0729, L1017, L1034 |
| Witch Hunter's Ward | Mine | L0713, L0729, L0819, L0835 |
| Witch Hunter's Ward | Opponent | L0608 |

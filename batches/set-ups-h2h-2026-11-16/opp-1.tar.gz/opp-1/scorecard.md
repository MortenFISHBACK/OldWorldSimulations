# Doctrine scorecard: su-h2h-opp-e45904b-p1

### Scorecard: su-h2h-opp-e45904b-p1

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0102 | 6 | 1 | Mine | no | 9 | - | 0 | 1 | 1 | 0 | 0 | 142 |
| L0102 | 6 | 1 | Opponent | no | 1 | 2 | 5 | 4 | 1 | 0 | 0 | 222 |
| L0118 | 4 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 0 |
| L0118 | 4 | 1 | Opponent | no | 0 | 2 | 2 | 4 | 0 | 0 | 0 | 268 |
| L0135 | 3 | 1 | Mine | yes | 6 | 4 | 0 | 2 | 0 | 0 | 0 | 0 |
| L0135 | 3 | 1 | Opponent | no | 1 | 3 | 1 | 2 | 0 | 0 | 0 | 0 |
| L0218 | 2 | 1 | Mine | - | - | 2 | 4 | 2 | 1 | 0 | 0 | 170 |
| L0218 | 2 | 1 | Opponent | - | - | 2 | 1 | 1 | 0 | 0 | 0 | 0 |
| L0235 | 1 | 1 | Mine | no | 3 | 2 | 2 | 2 | 0 | 0 | 0 | 170 |
| L0235 | 1 | 1 | Opponent | no | 0 | 2 | 3 | 2 | 0 | 0 | 0 | 110 |
| L0319 | 1 | 1 | Mine | no | 10 | 3 | 3 | 0 | 0 | 0 | 0 | 590 |
| L0319 | 1 | 1 | Opponent | no | 1 | 2 | 2 | 0 | 0 | 0 | 0 | 0 |
| L0405 | 3 | 1 | Mine | yes | 5 | 2 | 2 | 0 | 0 | 0 | 0 | 0 |
| L0405 | 3 | 1 | Opponent | yes | 0 | 4 | 1 | 0 | 0 | 0 | 0 | 1193 |
| L0421 | 1 | 1 | Mine | no | 0 | 2 | 5 | 1 | 0 | 0 | 0 | 0 |
| L0421 | 1 | 1 | Opponent | no | 0 | - | 0 | 3 | 1 | 0 | 0 | 355 |
| L0508 | 4 | 1 | Mine | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 1416 |
| L0508 | 4 | 1 | Opponent | no | 0 | 5 | 0 | 1 | 0 | 0 | 0 | 769 |
| L0524 | 2 | 1 | Mine | - | - | 3 | 1 | 1 | 0 | 0 | 0 | 698 |
| L0524 | 2 | 1 | Opponent | - | - | 3 | 1 | 3 | 1 | 0 | 0 | 0 |
| L0612 | 6 | 1 | Mine | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 798 |
| L0612 | 6 | 1 | Opponent | no | 3 | - | 0 | 0 | 1 | 0 | 0 | 330 |
| L0628 | 4 | 1 | Mine | no | 0 | 6 | 1 | 1 | 0 | 0 | 0 | 1197 |
| L0628 | 4 | 1 | Opponent | no | 8 | 2 | 3 | 0 | 0 | 0 | 0 | 111 |
| L0717 | 3 | 1 | Mine | no | 0 | 2 | 4 | 1 | 0 | 0 | 0 | 420 |
| L0717 | 3 | 1 | Opponent | yes | 6 | 3 | 3 | 1 | 1 | 0 | 0 | 175 |
| L0733 | 1 | 1 | Mine | no | 5 | 1 | 1 | 2 | 1 | 0 | 0 | 558 |
| L0733 | 1 | 1 | Opponent | no | 3 | 3 | 0 | 4 | 0 | 0 | 0 | 0 |
| L0823 | 1 | 1 | Mine | no | 4 | 2 | 1 | 0 | 1 | 0 | 0 | 560 |
| L0823 | 1 | 1 | Opponent | no | 0 | 3 | 3 | 2 | 3 | 0 | 0 | 70 |
| L0913 | 1 | 1 | Mine | no | 0 | 4 | 1 | 1 | 0 | 0 | 0 | 560 |
| L0913 | 1 | 1 | Opponent | no | 1 | 4 | 2 | 1 | 0 | 0 | 0 | 140 |
| L0930 | 6 | 1 | Mine | no | 0 | 6 | 2 | 0 | 0 | 0 | 0 | 537 |
| L0930 | 6 | 1 | Opponent | no | 5 | 2 | 4 | 2 | 1 | 0 | 0 | 0 |
| L1021 | 1 | 1 | Mine | no | 0 | 2 | 3 | 0 | 1 | 0 | 0 | 330 |
| L1021 | 1 | 1 | Opponent | no | 0 | 4 | 1 | 4 | 0 | 0 | 0 | 355 |
| L1114 | 4 | 1 | Mine | no | 0 | 2 | 4 | 1 | 0 | 0 | 0 | 427 |
| L1114 | 4 | 1 | Opponent | no | 1 | 3 | 2 | 3 | 0 | 0 | 0 | 677 |
| L1131 | 3 | 1 | Mine | no | 5 | - | 0 | 0 | 0 | 0 | 0 | 526 |
| L1131 | 3 | 1 | Opponent | no | 1 | 4 | 2 | 3 | 1 | 0 | 0 | 170 |
| L1224 | 6 | 1 | Mine | no | 10 | 2 | 1 | 0 | 0 | 0 | 0 | 330 |
| L1224 | 6 | 1 | Opponent | no | 6 | 2 | 0 | 1 | 1 | 0 | 0 | 0 |
| L1319 | 5 | 1 | Mine | yes | - | 4 | 2 | 0 | 0 | 0 | 0 | 302 |
| L1319 | 5 | 1 | Opponent | yes | - | 2 | 2 | 1 | 0 | 0 | 0 | 255 |
| L1335 | 3 | 1 | Mine | no | 1 | 2 | 3 | 1 | 0 | 0 | 0 | 140 |
| L1335 | 3 | 1 | Opponent | no | 0 | 4 | 1 | 3 | 0 | 0 | 0 | 126 |
| L1431 | 3 | 1 | Mine | no | 6 | 2 | 2 | 0 | 0 | 0 | 0 | 0 |
| L1431 | 3 | 1 | Opponent | no | 2 | - | 1 | 1 | 1 | 0 | 0 | 340 |
| L1527 | 3 | 1 | Mine | no | 1 | 3 | 3 | 0 | 1 | 0 | 0 | 0 |
| L1527 | 3 | 1 | Opponent | no | 0 | 2 | 8 | 2 | 0 | 0 | 0 | 0 |
| L1625 | 5 | 1 | Mine | yes | - | 2 | 1 | 0 | 0 | 0 | 0 | 200 |
| L1625 | 5 | 1 | Opponent | yes | - | 5 | 1 | 2 | 0 | 0 | 0 | 348 |
| L1723 | 1 | 1 | Mine | - | - | - | - | - | - | - | - | - |
| L1723 | 1 | 1 | Opponent | - | - | - | - | - | - | - | - | - |
| L1823 | 5 | 1 | Mine | no | - | 4 | 4 | 0 | 1 | 0 | 0 | 234 |
| L1823 | 5 | 1 | Opponent | yes | - | 1 | 1 | 1 | 2 | 0 | 0 | 0 |
| L1923 | 3 | 1 | Mine | no | 0 | 2 | 3 | 0 | 0 | 0 | 0 | 0 |
| L1923 | 3 | 1 | Opponent | no | 2 | 2 | 3 | 0 | 1 | 0 | 0 | 0 |
| L2025 | 3 | 1 | Mine | no | 9 | - | 0 | 3 | 0 | 0 | 0 | 485 |
| L2025 | 3 | 1 | Opponent | no | 3 | 4 | 1 | 3 | 0 | 0 | 0 | 0 |
| L2127 | 3 | 1 | Mine | no | 6 | - | 0 | 3 | 0 | 0 | 0 | 577 |
| L2127 | 3 | 1 | Opponent | no | 3 | 2 | 4 | 1 | 1 | 0 | 0 | 0 |
| L2231 | 5 | 1 | Mine | yes | - | 2 | 5 | 0 | 2 | 0 | 0 | 0 |
| L2231 | 5 | 1 | Opponent | yes | - | 4 | 3 | 3 | 5 | 0 | 0 | 340 |
| L2335 | 1 | 1 | Mine | no | 1 | 2 | 3 | 0 | 1 | 0 | 0 | 72 |
| L2335 | 1 | 1 | Opponent | no | 0 | 2 | 3 | 0 | 0 | 0 | 0 | 0 |
| L2531 | 5 | 1 | Mine | yes | - | 4 | 3 | 3 | 0 | 0 | 0 | 0 |
| L2531 | 5 | 1 | Opponent | yes | - | 3 | 1 | 3 | 1 | 0 | 0 | 0 |
| L2730 | 6 | 1 | Mine | no | 0 | 1 | 9 | 3 | 0 | 0 | 0 | 0 |
| L2730 | 6 | 1 | Opponent | no | 3 | 3 | 0 | 1 | 0 | 0 | 0 | 0 |
| L2934 | 6 | 1 | Mine | no | 3 | 2 | 4 | 0 | 0 | 0 | 0 | 0 |
| L2934 | 6 | 1 | Opponent | no | 0 | 2 | 4 | 3 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 18% | 3.0 | 2.7 | 2.2 | 0.9 | 0.3 | 0.0 | 0.0 | 326.8 |
| **Average** | | | Opponent | 21% | 1.8 | 2.8 | 2.0 | 1.9 | 0.6 | 0.0 | 0.0 | 181.5 |

### KPIs: su-h2h-opp-e45904b-p1

Rules off - Mine only: SET-UP SPOT, CARRIES OUT CLOSE-IN, JOINT AS ONE.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 27% (48 of 177) | 4% (8 of 181) | 16% (56 of 358) |
| Winner chose to follow up after the loser gave ground |  | 100% (59 of 59); on the table 100% | 98% (50 of 51); on the table 98% | 99% (109 of 110); on the table 99% |
| Winner chose to pursue after the loser fell back in good order |  | 100% (12 of 12); on the table 100% | 67% (12 of 18); on the table 83% | 80% (24 of 30); on the table 90% |
| Winner chose to pursue after the loser fled |  | 87% (20 of 23); on the table 91% | 89% (33 of 37); on the table 89% | 88% (53 of 60); on the table 90% |
| Winner chose to follow up or pursue (all three) |  | 97% (91 of 94); on the table 98% | 90% (95 of 106); on the table 92% | 93% (186 of 200); on the table 95% |
| Magic missiles tried each own turn | 50%+ | 38% (129 of 336) | 31% (66 of 210) | 36% (195 of 546) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 51% (129 of 251) | 44% (66 of 151) | 49% (195 of 402) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 59% (17 of 29) | 60% (26 of 43) | 60% (43 of 72) |
| Points that never fought | lower | 40% (27946 of 69484) | 38% (26753 of 69889) | 39% (54699 of 139373) |
|   infantry points that never fought | lower | 54% (8886 of 16490) | 55% (7075 of 12971) | 54% (15961 of 29461) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 49% (132 of 272) | 56% (163 of 290) | 52% (295 of 562) |
| Bound items with a magic missile used (at least once a game) |  | 91% (20 of 22); 1.8 uses a game | 80% (16 of 20); 1.5 uses a game | 86% (36 of 42); 1.6 uses a game |
| Bound items with another spell used |  | 75% (12 of 16); 0.8 uses a game | 12% (1 of 8); 0.0 uses a game | 54% (13 of 24); 0.4 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 58% (11 of 19); 0.3 uses a game | 42% (5 of 12); 0.1 uses a game | 52% (16 of 31); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 44% (25324 of 58051) | 51% (31275 of 61253) | 47% (56599 of 119304) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 2.1 (37%) | 1.2 (31%) | 3.3 (34%) |
| MARCHED: its unit marched | 0.9 (17%) | 0.5 (12%) | 1.4 (15%) |
| CHARGED: its unit charged | 0.2 (4%) | 0.1 (1%) | 0.3 (3%) |
| IN COMBAT: engaged in combat | 1.4 (25%) | 0.6 (15%) | 2.0 (21%) |
| REAR RANK: in a rear rank | 0.1 (2%) | 0.5 (13%) | 0.6 (7%) |
| FLEEING: fleeing | 0.2 (3%) | 0.0 (0%) | 0.2 (2%) |
| GONE: slain | 0.6 (10%) | 1.0 (26%) | 1.6 (17%) |
| OFF THE TABLE: off the table or not arrived | 0.1 (1%) | 0.0 (1%) | 0.1 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.1 (1%) | 0.1 (1%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.0 | 1.5 | 1.1 | 5.4 | 0.5 | 1.5 |
| not cast | 4.0 | 2.9 | 3.6 | 9.6 | 1.8 | 22.4 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) | 0.0 (0%) | 1.5 (7%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (1%) | 1.2 (41%) | 0.3 (9%) | 3.3 (34%) | 0.4 (20%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.4 (15%) | 0.3 (17%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (3%) | 0.1 (3%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.2 (5%) | 0.2 (7%) | 0.6 (17%) | 2.0 (21%) | 0.5 (26%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.2 (6%) | 0.3 (12%) | 0.7 (19%) | 0.6 (7%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.2 (5%) | 0.0 (1%) | 0.0 (0%) | 0.2 (2%) | 0.0 (0%) | 0.4 (2%) |
| GONE: slain | 0.8 (19%) | 0.7 (24%) | 0.4 (12%) | 1.6 (17%) | 0.4 (20%) | 3.5 (16%) |
| OFF THE TABLE: off the table or not arrived | 0.1 (2%) | 0.0 (1%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.5 (2%) |
| STUPIDITY: Stupidity | 0.1 (2%) | 0.0 (1%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (1%) | 0.1 (5%) | 0.0 (0%) | 0.0 (0%) | 0.3 (15%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.4 (60%) | 0.2 (9%) | 1.5 (42%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 16.4 (73%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.1 a game | 0.3 a game | 0.7 a game |
| stood (cast and not dispelled) | 63% (22 of 35) | 70% (7 of 10) | 64% (29 of 45) |
| the unit moved after it | 64% (14 of 22) | 43% (3 of 7) | 59% (17 of 29) |
| it charged on its next turn | 0% (0 of 22) | 0% (0 of 7) | 0% (0 of 29) |
| the enemy charged it first | 5% (1 of 22) | 14% (1 of 7) | 7% (2 of 29) |
| it fought by the end of its next turn | 5% (1 of 22) | 0% (0 of 7) | 3% (1 of 29) |
| it moved out of a charge the enemy had planned (not charged first) | 18% (4 of 22) | 14% (1 of 7) | 17% (5 of 29) |
| none of these (no charge, no fight, no charge escaped) | 77% (17 of 22) | 71% (5 of 7) | 76% (22 of 29) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 63% (572 of 901) | 59% (328 of 558) | 62% (900 of 1459) |
|   cavalry | 52% (47 of 91) | 64% (75 of 117) | 59% (122 of 208) |
|   character | 49% (60 of 122) | 33% (35 of 105) | 42% (95 of 227) |
|   chariot | 48% (46 of 96) | 68% (30 of 44) | 54% (76 of 140) |
|   infantry | 61% (178 of 292) | 61% (132 of 215) | 61% (310 of 507) |
|   monster | 67% (18 of 27) | 25% (4 of 16) | 51% (22 of 43) |
|   war machine | 82% (223 of 273) | 85% (52 of 61) | 82% (275 of 334) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.6 (29%) | 1.3 (20%) | 3.9 (25%) |
| CHARGED: it charged | 1.4 (15%) | 1.2 (19%) | 2.6 (17%) |
| FLEEING: it fled or was fleeing | 0.1 (1%) | 0.1 (2%) | 0.2 (1%) |
| IN COMBAT: it fought this turn or the last | 0.7 (7%) | 0.6 (10%) | 1.3 (8%) |
| FREE: none of these - no target in range or sight, or held its fire | 0.4 (4%) | 0.0 (0%) | 0.4 (2%) |
| NO TARGET IN RANGE | 1.6 (17%) | 1.4 (22%) | 3.0 (19%) |
| ONLY IN COMBAT: the only targets were in combat | 0.3 (4%) | 0.4 (7%) | 0.8 (5%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.6 (18%) | 0.9 (14%) | 2.5 (16%) |
| SHELTERED: the target was sheltered | 0.2 (2%) | 0.2 (4%) | 0.4 (3%) |
| STUPIDITY | 0.0 (0%) | 0.0 (0%) | 0.1 (0%) |
| OTHER BAR | 0.3 (3%) | 0.1 (2%) | 0.4 (3%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 4.9 | 1.2 | 80% | 5.4 pts | 27 pts |
| character | 3.1 | 0.8 | 79% | 4.9 pts | 15 pts |
| chariot | 2.1 | 1.6 | 71% | 9.1 pts | 19 pts |
| infantry | 12.4 | 5.0 | 75% | 9.0 pts | 112 pts |
| monster | 0.8 | 0.1 | 89% | 4.4 pts | 3 pts |
| war machine | 7.6 | 5.8 | 63% | 24.7 pts | 189 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.7 | 5.2 | 5.0 |
| Charges that made contact a game | 3.6 | 3.7 | 3.6 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.89 declared, 0.74 contact (19 units) | 0.20 declared, 0.20 contact (15 units) | 0.59 declared, 0.50 contact (34 units) |
|   per unit a game, units carrying another wizard (or one alone) | 1.20 declared, 0.60 contact (5 units) | 1.22 declared, 0.89 contact (9 units) | 1.21 declared, 0.79 contact (14 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.61 declared, 0.46 contact (240 units) | 0.61 declared, 0.43 contact (284 units) | 0.61 declared, 0.44 contact (524 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 49% (34 of 70) | 38% (8 of 21) | 25% (2 of 8) | 44% (44 of 99) |
| Character in a unit | 79% (23 of 29) | 58% (15 of 26) | 67% (2 of 3) | 69% (40 of 58) |
| Character on its own | 70% (40 of 57) | 44% (15 of 34) | 31% (18 of 59) | 49% (73 of 150) |
| Chariot | 50% (8 of 16) | 50% (5 of 10) | - | 50% (13 of 26) |
| Infantry | 48% (42 of 87) | 47% (17 of 36) | 50% (1 of 2) | 48% (60 of 125) |
| Monster | 59% (16 of 27) | 70% (7 of 10) | - | 62% (23 of 37) |
| Monstrous | 64% (7 of 11) | 57% (8 of 14) | - | 60% (15 of 25) |
| War Machines | 66% (27 of 41) | 0% (0 of 1) | - | 64% (27 of 42) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 6 | 94% (17 of 18); on the table 94% | 49% (68 of 138) | 44% | 48% (16 of 33) | 100% (9 of 9); 5.0 uses a game | 100% (3 of 3); 1.5 uses a game | 89% (8 of 9); 1.3 uses a game |
| Chaos Dwarfs | 3 | 92% (12 of 13); on the table 92% | 42% (10 of 24) | 25% | 33% (8 of 24) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 0.3 uses a game |
| Dwarfen Mountain Holds | 5 | 100% (11 of 11); on the table 100% | - | 59% | 73% (30 of 41) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 6 | 100% (10 of 10); on the table 100% | 39% (14 of 36) | 50% | 56% (36 of 64) | 0.0 uses a game | 100% (2 of 2); 1.2 uses a game | 50% (2 of 4); 0.3 uses a game |
| Grand Cathay | 5 | 92% (11 of 12); on the table 92% | 38% (41 of 108) | 53% | 43% (19 of 44) | 92% (11 of 12); 6.8 uses a game | 100% (1 of 1); 0.6 uses a game | 0% (0 of 5); 0.0 uses a game |
| High Elf Realms | 6 | 93% (13 of 14); on the table 93% | 13% (4 of 30) | 33% | 41% (20 of 49) | 100% (5 of 5); 3.0 uses a game | 39% (7 of 18); 1.7 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | 100% (8 of 8); on the table 100% | - | 34% | 67% (4 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Lizardmen | 1 | 100% (2 of 2); on the table 100% | - | 41% | 43% (3 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 3 | 100% (10 of 10); on the table 100% | 0% (0 of 12) | 49% | 71% (15 of 21) | 67% (2 of 3); 2.3 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 3 | 100% (4 of 4); on the table 100% | 14% (5 of 36) | 4% | 42% (10 of 24) | 0.0 uses a game | 0.0 uses a game | 33% (1 of 3); 0.3 uses a game |
| Skaven | 4 | 100% (9 of 9); on the table 100% | 33% (10 of 30) | 40% | 53% (18 of 34) | 100% (3 of 3); 1.0 uses a game | 0.0 uses a game | 50% (2 of 4); 0.5 uses a game |
| Tomb Kings of Khemri | 5 | 87% (20 of 23); on the table 96% | 17% (2 of 12) | 30% | 28% (7 of 25) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 8 | 94% (34 of 36); on the table 94% | 33% (18 of 54) | 35% | 62% (31 of 50) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 8 | 76% (16 of 21); on the table 86% | 30% (9 of 30) | 34% | 61% (45 of 74) | 100% (4 of 4); 2.2 uses a game | 0.0 uses a game | 50% (1 of 2); 0.1 uses a game |
| Wood Elf Realms | 6 | 100% (9 of 9); on the table 100% | 47% (14 of 30) | 44% | 50% (33 of 66) | 33% (2 of 6); 1.2 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (su-h2h-opp-e45904b-p1, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 45% (31) | 56% (41) | 51% (72) |
| ...free all their last turn and able to turn (per game) | 0.53 | 0.72 | 1.25 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.25 | 0.17 | 0.42 |
| ...with the charger already in that arc before they moved (per game) | 0.39 | 0.42 | 0.81 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 2.08 | 1.14 | 3.22 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.81 | 0.42 | 1.22 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 5.19 | 6.72 | 11.92 |

### Quality by phase: su-h2h-opp-e45904b-p1

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.1 | 3.4 |
| Strategy | Charge objectives carried out (made contact) | 53% (74 of 140) | 50% (77 of 154) |
| Strategy | Shoot objectives carried out (shot that target) | 46% (189 of 414) | 62% (130 of 209) |
| Strategy | Close-in objectives charged next turn | 18% (26 of 148) | 22% (43 of 199) |
| Strategy | Support requests answered (helper made contact too) | 62% (15 of 24) | 56% (19 of 34) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (1 of 1) | 75% (3 of 4) |
| Strategy | Hexes on a unit its side charged or shot that turn | 46% (6 of 13) | 86% (12 of 14) |
| Strategy | Joined characters whose unit fought | 22% (11 of 49) | 60% (24 of 40) |
| Strategy | Lone characters that fought | 79% (74 of 94) | 72% (67 of 93) |
| Movement | Charges halted short of contact | 0.2 | 0.1 |
| Movement | Idle units | 0.9 | 1.9 |
| Movement | Points that never moved of their own | 326.8 | 181.5 |
| Movement | Fights charged into per game | 2.8 | 2.9 |
| Movement | Charges with odds: long shots (under 50%) | 9 of 87, net +254 | 10 of 88, net +18 |
| Movement | Charges with odds: sweet spot (55-75%) | 13 of 87, net +116 | 19 of 88, net +79 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 9 of 87, net +66 | 2 of 88, net +32 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 33 of 87, net +125 | 30 of 88, net +160 |
| Shooting | Shots by shooting units (incl. breath weapons) | 10.5 | 8.6 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 48% (181 of 377) | 39% (121 of 311) |
| Shooting | Points destroyed by shooting units | 84.2 | 55.9 |
| Shooting | War machine shots | 6.2 | 1.4 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 49% (110 of 223) | 35% (18 of 52) |
| Shooting | Points destroyed by war machines | 92.9 | 11.2 |
| Magic | Magic missiles cast | 2.3 | 1.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 29% (24 of 82) | 50% (23 of 46) |
| Magic | Wounds caused by magic missiles | 5.1 | 1.5 |
| Magic | Wounds caused by other spells | 1.7 | 0.4 |
| Magic | Points destroyed by magic (all spells) | 80.8 | 23.3 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.5 / 0.4 / 0.8 / 0.1 | 1.6 / 0.5 / 0.3 / 0.1 |
| Combat | Points destroyed in combat | 436.7 | 324.6 |
| Combat | Points run down | 80.3 | 116.2 |
| Combat | Net points per charged fight, damage counted | +96 | +103 |
| Combat | Net per 100 charger points, damage counted | +30.2 | +37.7 |
| Combat | First round won (charged fights) | 75% | 85% |
| Combat | Net points per charged fight | +105 | +88 |
| Combat | Net points per supported fight / lone fight | +205 / +69 | +151 / +67 |
| Combat | Charged fights on a top-3 enemy unit | 36 of 97 | 43 of 100 |
| Game | Points lost | 656.5 | 847.3 |
| Game | VP from objectives | 640.0 | 632.9 |
| Game | Lone holders (player turns) | 3.0 | 1.8 |

- Mine won / drew / lost: 16 / 7 / 12 of 35 ended games (of 36); mean margin (Mine - Opponent) +170 VP
- The side that went first won 10 of 28 games with a winner
- Points traded per game (both sides' losses): 1504
- Games not ended: 1 (L1723-1); findings 2, warnings 1

### Opponent rules: su-h2h-opp-e45904b-p1

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.6 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| ARRIVAL HUNT | - | - | - | - | 0.0 | +0.3 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.4 | +0.0 | 0.0 | 27.1 | 0.3 | +0.0 | 0.0 | 2.6 |
| BACKUP TARGETS | 0.9 | +8.2 | 0.0 | 7.9 | 1.1 | +11.6 | 0.0 | 40.9 |
| BEST FACING | 0.7 | +30.8 | 0.0 | 40.6 | 0.6 | +25.5 | 0.0 | 15.4 |
| BEST FIRST | 4.5 | +196.0 | 145.6 | 106.9 | 3.9 | +151.1 | 113.8 | 55.7 |
| BEST OVERALL | 0.5 | +22.5 | 0.0 | 21.6 | 0.5 | +31.8 | 0.0 | 1.9 |
| BEST PREY | 0.6 | +34.7 | 18.3 | 24.2 | 1.2 | +45.2 | 32.8 | 28.3 |
| BEST PRIZE | 0.0 | -0.6 | 0.0 | 0.0 | 0.1 | -4.9 | 5.6 | 6.5 |
| BIG CHARACTER SAFETY | 0.1 | -0.7 | 0.0 | 0.0 | 0.1 | -0.1 | 0.0 | 0.0 |
| BLOCKED CHARGE SKIPPED | 0.1 | +0.0 | 2.9 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| BLOCKED WHEEL | 0.2 | +0.2 | 0.0 | 0.0 | 0.3 | +1.6 | 0.0 | 7.9 |
| BLOWS WHERE AIMED | 0.2 | -20.3 | 35.7 | 0.0 | 0.4 | -28.5 | 72.6 | 10.8 |
| BOMBING RUN | 0.0 | +1.3 | 0.0 | 0.0 | - | - | - | - |
| CANNON PLAN MISSED | 1.0 | +0.0 | 155.1 | 9.6 | 0.1 | +0.0 | 9.5 | 0.0 |
| CANNON PLANNED TARGET | 4.8 | +177.0 | 381.7 | 81.9 | 1.3 | +29.0 | 33.5 | 9.9 |
| CANNON SIGHT KEPT | 1.0 | +0.0 | 0.0 | 3.5 | 0.4 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT CLOSE-IN | - | - | - | - | 0.6 | -0.5 | 69.3 | 0.0 |
| CARRIES OUT COUNTER | 0.0 | -1.1 | 5.1 | 0.0 | 0.0 | +0.0 | 1.9 | 3.5 |
| CARRIES OUT SET-UP | 0.3 | -0.3 | 44.9 | 18.9 | 0.1 | +0.0 | 18.0 | 2.4 |
| CAST JOB | 0.8 | +21.1 | 49.9 | 2.4 | 0.4 | +7.9 | 5.4 | 1.7 |
| CASTER AWAY FROM SCREEN | 0.4 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.4 | +29.4 | 26.9 | 10.9 | 0.2 | +6.1 | 8.5 | 0.0 |
| CASTS AFTER FRIENDS | 0.6 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 20.7 |
| CASTS FROM BEHIND | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.1 | +1.1 | 0.0 | 0.0 | 0.0 | +0.3 | 0.0 | 0.0 |
| CATCH ODDS | 0.0 | +0.3 | 0.0 | 0.0 | - | - | - | - |
| CHAFF PASSED | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 3.8 |
| CHARGE BAND | 0.2 | +0.0 | 34.6 | 12.1 | 0.2 | +0.0 | 17.2 | 13.1 |
| CHARGE NOW FIRST | 2.8 | +0.0 | 313.4 | 92.9 | 2.1 | +0.0 | 179.8 | 33.8 |
| CHARGE NOW WEIGHED | 0.4 | -37.3 | 0.0 | 9.2 | 0.6 | -36.7 | 0.0 | 22.7 |
| CHARGER SLAIN LOST | 0.5 | -31.7 | 75.1 | 9.1 | 0.7 | -27.6 | 76.8 | 19.2 |
| CHARIOT WIZARD CAREFUL | 0.1 | -0.0 | 11.9 | 0.0 | 0.1 | -0.0 | 8.0 | 13.1 |
| CHEAP HELPER | 0.1 | +0.0 | 8.3 | 2.1 | 0.1 | +0.0 | 0.9 | 1.2 |
| COMBAT PIVOT | 0.6 | +0.0 | 67.9 | 22.5 | 0.6 | +0.0 | 24.9 | 64.6 |
| CONTINUE AHEAD WEIGHED | 0.1 | +0.0 | 1.1 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | 0.6 | +90.2 | 0.0 | 0.0 | 0.2 | +62.3 | 4.4 | 15.2 |
| COUNTER-CHARGE COVER | 9.0 | +866.4 | 0.0 | 157.8 | 7.8 | +694.2 | 0.0 | 203.8 |
| DEFENSIVE ARMY | 0.1 | +0.0 | 0.0 | 3.6 | 0.1 | +0.0 | 0.0 | 0.0 |
| EDGE GIVE GROUND | 0.1 | +15.0 | 18.4 | 0.0 | 0.1 | +1.0 | 6.7 | 0.0 |
| ELIXIR WORTH | - | - | - | - | 0.0 | +0.1 | 0.0 | 0.0 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 2.1 | +171.5 | 0.0 | 79.9 | 1.1 | +74.3 | 0.0 | 36.6 |
| FALLBACK BY WORTH | 4.6 | +84.5 | 0.0 | 54.8 | 5.6 | +55.2 | 0.0 | 60.2 |
| FLANK NOT WEIGHED | 5.1 | +0.0 | 0.0 | 83.6 | 6.5 | +0.0 | 0.0 | 148.0 |
| FOCUS FIRE | - | - | - | - | 0.0 | +0.5 | 0.8 | 0.0 |
| FOLLOW UP WEIGHED | 0.8 | +91.6 | 0.0 | 7.8 | 1.1 | +167.7 | 0.0 | 55.4 |
| FRIENDS SHOTS CHECKED | 0.4 | +31.0 | 0.0 | 13.3 | 0.2 | +13.0 | 0.0 | 0.0 |
| GIVES UP | 0.1 | -0.6 | 4.7 | 5.4 | 0.0 | -0.0 | 1.2 | 0.0 |
| GIVES UP ITS SCREEN | - | - | - | - | 0.1 | -1.4 | 0.0 | 1.7 |
| HELPER ALREADY ASKED | - | - | - | - | 0.1 | +0.0 | 12.8 | 0.0 |
| HELPER UNSEEN | 0.4 | +0.0 | 31.6 | 14.7 | 0.4 | +0.0 | 40.7 | 1.2 |
| HILL BY ITS CHANCE | - | - | - | - | 0.1 | -9.4 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.8 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 7.4 | -153.7 | 564.3 | 206.2 | 8.3 | -158.1 | 401.7 | 152.7 |
| HUNT ADVANCE | 0.1 | +0.8 | 5.9 | 0.0 | 0.1 | +10.2 | 0.0 | 8.1 |
| HUNT DROPPED | - | - | - | - | 0.1 | +0.0 | 0.0 | 3.6 |
| HUNT IN PAIRS | 0.5 | +22.4 | 0.0 | 17.5 | 0.4 | +48.1 | 0.0 | 22.1 |
| HUNT KEPT | - | - | - | - | 0.1 | +4.5 | 0.0 | 4.9 |
| HUNT RESULT | 0.1 | +6.1 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 6.8 |
| HUNT THE GUNS | 0.1 | +16.8 | 5.9 | 0.0 | 0.2 | +62.2 | 0.0 | 4.8 |
| INVITES THE FIGHT | 1.6 | +31.5 | 59.8 | 39.6 | 1.6 | +27.7 | 32.9 | 42.5 |
| JOINT AS ONE | - | - | - | - | 2.8 | -7.6 | 104.4 | 56.4 |
| JOINT CHARGE PLAN | 0.2 | +9.0 | 19.0 | 0.0 | 0.1 | +0.9 | 0.0 | 0.0 |
| JOINT KNOWS CHALLENGE | 0.1 | -3.4 | 13.9 | 7.8 | 0.1 | -3.7 | 0.0 | 0.0 |
| KEEP FALLS | 0.1 | +1.1 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| KEEPS ITS PREY | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KEEPS ITS TARGET | 1.6 | +48.3 | 129.4 | 44.2 | 2.2 | +66.7 | 169.8 | 39.5 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KILLS COUNT | 1.6 | +77.0 | 112.2 | 31.1 | 1.8 | +105.0 | 148.3 | 15.2 |
| KILLS COUNT NEXT TURN | 4.3 | +148.2 | 215.2 | 101.0 | 6.8 | +229.3 | 246.6 | 213.9 |
| LONE CHARACTER SAFE SPOT | 0.2 | +11.5 | 8.8 | 0.0 | 0.4 | +4.9 | 7.0 | 20.2 |
| LONE WIZARD HOLDS BACK | 0.1 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 13.9 | 27.2 |
| LONE WIZARD KEPT IN | 0.7 | +49.1 | 0.0 | 0.0 | 0.2 | +24.5 | 0.0 | 0.0 |
| LONG SHOT | 0.5 | -0.6 | 19.8 | 3.1 | 0.5 | +2.9 | 30.7 | 11.5 |
| LOST CHARGE | 3.1 | -58.8 | 185.3 | 96.4 | 2.5 | -35.5 | 72.2 | 63.2 |
| LURE BY WHAT IT DRAWS | 0.0 | +0.0 | 0.0 | 1.7 | 0.1 | -4.8 | 0.0 | 1.1 |
| MAKE SURE TOGETHER | 0.7 | +59.4 | 57.1 | 22.4 | 0.6 | +35.5 | 10.9 | 17.4 |
| MANOEUVRE | 0.3 | +7.2 | 0.0 | 3.0 | 0.2 | +8.7 | 0.0 | 7.7 |
| MARCH AT ESCAPER | 0.0 | +0.3 | 0.0 | 10.9 | - | - | - | - |
| MARCH CHECK | 0.6 | +37.3 | 0.0 | 15.0 | 0.4 | +13.5 | 0.0 | 7.0 |
| MARCH ODDS | 0.4 | +28.3 | 10.0 | 10.6 | 0.2 | +7.1 | 0.0 | 0.0 |
| MARCH OVER CASTS | 0.5 | +48.8 | 0.0 | 10.9 | 0.3 | +16.7 | 0.0 | 22.9 |
| MAX FOR POSITIONING | 4.6 | +155.0 | 0.0 | 70.9 | 5.9 | +245.8 | 0.0 | 167.5 |
| MISSILES IN THE MOVE | 4.4 | +160.2 | 0.0 | 31.4 | 3.7 | +59.7 | 0.0 | 63.4 |
| MISSILES NEXT TURN | 4.9 | +113.5 | 0.0 | 67.0 | 4.1 | +41.0 | 0.0 | 104.4 |
| MODEL FACING | 0.1 | +37.6 | 0.0 | 1.7 | - | - | - | - |
| MONSTER WIZARD ROAMS | 0.1 | +0.0 | 8.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| MOVE AND CAST | 0.3 | +15.1 | 0.0 | 2.4 | 0.6 | +18.7 | 0.0 | 22.9 |
| MOVE SPELL IN RANGE | 0.2 | +5.6 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.4 | -81.8 | 0.0 | 26.9 | 0.1 | -12.7 | 0.0 | 0.0 |
| MOVE SPELL SPOT | 0.2 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 13.1 |
| MOVE TO CHARGE | 2.9 | +247.2 | 144.5 | 79.5 | 4.3 | +361.7 | 151.1 | 131.5 |
| MOVES UNITS SPELL | 0.1 | +3.4 | 0.0 | 0.0 | 0.1 | +1.8 | 0.0 | 0.0 |
| NO CHARGE WHY | 2.6 | +0.0 | 137.4 | 135.4 | 3.6 | +0.0 | 96.0 | 113.3 |
| NO RALLY LEFT | 0.1 | +2.7 | 0.0 | 0.0 | 0.0 | +0.1 | 0.0 | 0.9 |
| NOT NEEDED | 0.2 | -10.3 | 19.4 | 0.0 | 0.5 | -25.6 | 65.7 | 1.4 |
| NOT TURNED | 5.2 | +122.5 | 0.0 | 63.9 | 6.7 | +111.1 | 0.0 | 185.1 |
| NOT WORTH A CAST | 1.1 | -0.8 | 0.0 | 15.0 | 0.3 | -0.3 | 0.0 | 0.0 |
| OFF BEST | 15.9 | -802.7 | 17.4 | 241.0 | 16.0 | -846.3 | 8.0 | 302.8 |
| OPENS A LANE | 0.3 | +2.5 | 12.6 | 0.0 | 0.2 | +0.9 | 12.9 | 0.0 |
| OPENS UP | 0.2 | +10.0 | 6.1 | 35.1 | 0.1 | +3.6 | 1.2 | 0.0 |
| OVERRUN THREAT | 0.0 | +0.5 | 0.0 | 0.0 | - | - | - | - |
| OVERRUNS AWAY | 0.6 | +18.9 | 69.5 | 8.9 | 0.6 | +12.2 | 42.6 | 20.7 |
| PATHS CROSS | 2.0 | +133.0 | 0.0 | 17.8 | 2.7 | +209.0 | 0.0 | 47.8 |
| PERIAPT WORTH | 0.0 | +3.4 | 0.0 | 0.0 | 0.0 | +3.0 | 0.0 | 15.0 |
| PIVOT GUARDS FLANK | 0.1 | -0.3 | 0.0 | 0.0 | 0.2 | -4.3 | 0.0 | 9.1 |
| PLAN RESULT | 37.4 | +1544.9 | 1352.7 | 883.5 | 38.0 | +1097.1 | 1271.9 | 1084.1 |
| PURSUES BIG PREY | 0.1 | -9.7 | 0.0 | 0.0 | 0.2 | -7.4 | 0.0 | 5.2 |
| RAIDS THE BAGGAGE NEXT TURN | 0.0 | +2.0 | 0.0 | 0.0 | 0.1 | +12.9 | 0.0 | 0.0 |
| RANDOM MOVE BY FIGURES | 0.8 | +13.6 | 0.0 | 43.3 | 1.2 | +8.7 | 0.0 | 66.7 |
| RANDOM MOVER NO PROMISE | 0.1 | -2.9 | 4.4 | 9.4 | 0.2 | -5.1 | 1.5 | 15.3 |
| REDIRECT BY WHAT IT STOPS | 0.1 | -1.2 | 0.0 | 3.2 | 0.6 | -8.1 | 0.0 | 6.5 |
| REDIRECT COUNTER | 1.8 | +95.0 | 0.0 | 28.9 | 4.5 | +394.8 | 0.0 | 59.5 |
| REDIRECT WEIGHED | 0.2 | +0.0 | 0.0 | 4.9 | 0.3 | -3.6 | 2.1 | 14.9 |
| REFUSING RETIRES | 0.4 | +0.0 | 0.0 | 22.3 | 0.3 | +0.0 | 0.0 | 6.2 |
| RESERVE FALL BACK | 0.6 | +17.5 | 0.0 | 6.0 | 0.8 | +25.1 | 0.0 | 10.7 |
| RESTRAINS TO SHOOT | 0.1 | +2.2 | 0.0 | 0.0 | 0.0 | +0.3 | 0.0 | 4.0 |
| RISK BY ARC | 2.6 | +115.4 | 237.7 | 80.3 | 2.6 | +43.2 | 194.8 | 60.9 |
| SAFER THAN THE JOB | 0.8 | +48.5 | 0.0 | 42.6 | 0.4 | +12.9 | 0.0 | 0.0 |
| SCOUT SPOT | 0.4 | +0.7 | 0.0 | 0.0 | 0.3 | +0.6 | 0.0 | 0.9 |
| SCOUT WAITS | 0.4 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.9 |
| SCREEN BY WHAT IT SAVES | 0.1 | -5.7 | 0.0 | 2.2 | 0.3 | -1.2 | 0.0 | 1.2 |
| SEARCH SPOT | 2.3 | +107.4 | 0.0 | 28.7 | 2.3 | +133.3 | 0.0 | 37.3 |
| SECOND HUNTER | - | - | - | - | 0.0 | -0.0 | 0.0 | 0.0 |
| SELF MOVE SPELL | 0.3 | +13.7 | 0.0 | 18.1 | 0.1 | -0.2 | 0.0 | 0.0 |
| SET UP TOGETHER | 1.3 | +129.3 | 96.6 | 35.0 | 1.7 | +92.5 | 10.9 | 74.7 |
| SET-UP ANY TARGET | 0.2 | +15.1 | 0.0 | 0.0 | 0.1 | +8.4 | 0.0 | 7.6 |
| SET-UP MISSED | 0.0 | +4.7 | 0.0 | 0.0 | 0.1 | +9.4 | 0.0 | 7.6 |
| SET-UP SPOT | - | - | - | - | 7.0 | +228.0 | 125.8 | 271.9 |
| SHOOTERS IN TWO RANKS | 0.4 | +0.9 | 0.0 | 0.0 | 0.3 | +0.8 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.5 | +61.2 | 88.8 | 19.9 | 0.9 | +13.8 | 23.0 | 26.2 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| SHOT REPLANNED | 1.0 | +0.0 | 202.5 | 9.6 | 0.2 | +0.0 | 17.1 | 0.0 |
| SHOTS IN THE MOVE | 14.9 | +616.3 | 0.0 | 223.0 | 8.7 | +211.6 | 0.0 | 117.1 |
| SPELL SETS UP CHARGE | 0.2 | +44.5 | 0.0 | 0.0 | 0.1 | +34.4 | 0.0 | 7.6 |
| SPELL WORTH | 1.0 | +18.7 | 37.9 | 30.3 | 1.6 | +38.2 | 114.1 | 117.6 |
| SPELLS IN THE FIGHT | 0.6 | +5.7 | 78.8 | 23.9 | 0.3 | -5.9 | 14.5 | 14.9 |
| STABLE ROLE | 11.7 | +0.0 | 408.8 | 164.1 | 11.3 | +0.0 | 344.7 | 205.4 |
| STANDS TO CAST | 0.1 | +1.4 | 0.0 | 0.0 | 0.0 | +0.6 | 0.0 | 0.0 |
| STAY WEIGHED | 0.0 | +0.2 | 0.0 | 0.0 | - | - | - | - |
| STOPS | - | - | - | - | 0.1 | +2.0 | 0.0 | 1.7 |
| STOPS SHORT OF THE FLANK | 0.3 | +8.5 | 0.0 | 5.2 | 0.3 | +18.3 | 0.0 | 5.9 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 4.7 | 0.2 | +0.0 | 0.0 | 0.0 |
| SUPPORT NARROWED | 5.2 | -40.5 | 239.0 | 106.1 | 6.7 | -50.0 | 363.8 | 135.0 |
| SUPPORTS | 3.2 | +47.4 | 87.8 | 35.3 | 4.4 | +50.0 | 203.6 | 83.6 |
| SURE CHARGE BEATS ADVANCE | 0.1 | -3.5 | 10.5 | 0.0 | 0.1 | -4.4 | 11.4 | 3.2 |
| SURE REACH TOGETHER | 0.6 | -16.0 | 63.1 | 0.0 | 0.9 | +17.3 | 0.0 | 39.6 |
| THROUGH LINE OF FIRE | 0.6 | -0.2 | 0.0 | 5.2 | 0.1 | +2.3 | 0.0 | 1.9 |
| TURN WORTH | 0.2 | -17.0 | 20.3 | 22.4 | 0.2 | -7.0 | 7.2 | 0.0 |
| TWO OR MORE ARRIVE | 0.2 | +1.5 | 15.4 | 1.4 | 0.3 | +2.5 | 0.0 | 9.4 |
| WAIT AFTER COSTS | 6.5 | -305.1 | 291.1 | 151.7 | 7.5 | -436.0 | 246.6 | 208.5 |
| WALKS TO THE FIGHT | 1.6 | +31.2 | 37.2 | 38.6 | 0.8 | +17.5 | 22.1 | 0.0 |
| WAR ENGINE CHARGES | 0.2 | +18.4 | 16.5 | 0.0 | 0.1 | +0.7 | 0.0 | 0.0 |
| WAR ENGINE JOBS | 0.4 | +0.0 | 42.6 | 20.1 | 0.3 | +0.0 | 2.1 | 7.2 |
| WEARS DOWN | 1.1 | +59.4 | 141.2 | 21.5 | 1.0 | +40.7 | 160.6 | 23.6 |
| WHO HITS BACK | 0.3 | +15.2 | 0.0 | 0.0 | 0.2 | +14.6 | 0.0 | 19.7 |
| WHOLE FIGHT | 0.5 | +21.5 | 143.2 | 9.9 | 0.3 | +27.5 | 30.4 | 3.2 |
| WHOLE FIGHT GAIN | 0.5 | +42.5 | 43.5 | 17.4 | 0.8 | +60.0 | 103.9 | 0.0 |
| WIDER SPREAD | 2.6 | -9.1 | 297.1 | 80.9 | 3.0 | -6.2 | 302.8 | 56.7 |

### Rule changes: su-h2h-opp-e45904b-p1

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 1150 | 1150 | 1150 | 31.94 | -59361 | -51.6 |
| BEST FIRST | 304 | 304 | 304 | 8.44 | +12494 | +41.1 |
| PATHS CROSS | 169 | 169 | 169 | 4.69 | +12313 | +72.9 |
| SEARCH SPOT | 166 | 166 | 163 | 4.53 | +8668 | +53.2 |
| MOVE TO CHARGE | 259 | 259 | 151 | 4.19 | +8560 | +56.7 |
| COUNTER-CHARGE COVER | 602 | 328 | 145 | 4.03 | +10201 | +70.4 |
| SET-UP SPOT | 251 | 251 | 134 | 3.72 | +6990 | +52.2 |
| KILLS COUNT NEXT TURN | 401 | 401 | 129 | 3.58 | +4626 | +35.9 |
| FACES THE THREAT | 116 | 116 | 116 | 3.22 | +8850 | +76.3 |
| SUPPORTS | 276 | 276 | 109 | 3.03 | +1089 | +10.0 |
| FALLBACK BY WORTH | 366 | 366 | 89 | 2.47 | +5030 | +56.5 |
| SHOTS IN THE MOVE | 851 | 568 | 78 | 2.17 | +2171 | +27.8 |
| FOLLOW UP WEIGHED | 69 | 69 | 69 | 1.92 | +9332 | +135.2 |
| WAIT AFTER COSTS | 503 | 503 | 66 | 1.83 | +1360 | +20.6 |
| ARTILLERY RE-ROLL WEIGHED | 64 | 64 | 64 | 1.78 | +0 | +0.0 |
| REDIRECT COUNTER | 225 | 118 | 52 | 1.44 | +4469 | +85.9 |
| CANNON SIGHT KEPT | 51 | 51 | 51 | 1.42 | +0 | +0.0 |
| WALKS TO THE FIGHT | 84 | 84 | 51 | 1.42 | +813 | +15.9 |
| MAX FOR POSITIONING | 379 | 214 | 50 | 1.39 | +540 | +10.8 |
| RESERVE FALL BACK | 50 | 50 | 50 | 1.39 | +1534 | +30.7 |
| BEST FACING | 47 | 47 | 47 | 1.31 | +2024 | +43.1 |
| SET UP TOGETHER | 107 | 83 | 47 | 1.31 | +3314 | +70.5 |
| ADVANCE LANE KEPT | 46 | 46 | 46 | 1.28 | +0 | +0.0 |
| HOLDS AMBUSHERS | 44 | 44 | 44 | 1.22 | +0 | +0.0 |
| SAFER THAN THE JOB | 44 | 44 | 44 | 1.22 | +2210 | +50.2 |
| CANNON PLANNED TARGET | 220 | 220 | 43 | 1.19 | -310 | -7.2 |
| RANDOM MOVE BY FIGURES | 72 | 72 | 43 | 1.19 | +803 | +18.7 |
| RISK BY ARC | 185 | 178 | 43 | 1.19 | +1640 | +38.1 |
| COMBAT PIVOT | 42 | 42 | 42 | 1.17 | +0 | +0.0 |
| SHOT REPLANNED | 41 | 41 | 41 | 1.14 | +0 | +0.0 |
| BEST OVERALL | 36 | 36 | 36 | 1.00 | +1957 | +54.4 |
| CHARGE NOW FIRST | 173 | 173 | 36 | 1.00 | -1823 | -50.6 |
| MISSILES IN THE MOVE | 289 | 171 | 36 | 1.00 | +865 | +24.0 |
| CHARGE NOW WEIGHED | 35 | 35 | 35 | 0.97 | +2639 | +75.4 |
| SHOOTS FROM THE BEST SPOT | 87 | 87 | 35 | 0.97 | +957 | +27.3 |
| LONE WIZARD KEPT IN | 34 | 34 | 34 | 0.94 | +2648 | +77.9 |
| KILLS COUNT | 122 | 117 | 33 | 0.92 | +1177 | +35.7 |
| MARCH CHECK | 34 | 34 | 32 | 0.89 | +1979 | +61.8 |
| MOVE AND CAST | 30 | 30 | 30 | 0.83 | +1218 | +40.6 |
| CAST JOB | 44 | 44 | 28 | 0.78 | +391 | +14.0 |
| CASTER AWAY FROM SCREEN | 26 | 26 | 26 | 0.72 | +0 | +0.0 |
| SCOUT WAITS | 26 | 26 | 26 | 0.72 | +0 | +0.0 |
| SHOOTERS IN TWO RANKS | 24 | 24 | 24 | 0.67 | +58 | +2.4 |
| STOPS SHORT OF THE FLANK | 24 | 24 | 24 | 0.67 | +964 | +40.2 |
| THROUGH LINE OF FIRE | 24 | 24 | 24 | 0.67 | +75 | +3.1 |
| KEEPS ITS TARGET | 138 | 136 | 22 | 0.61 | +335 | +15.2 |
| INVITES THE FIGHT | 116 | 116 | 21 | 0.58 | +397 | +18.9 |
| WHOLE FIGHT GAIN | 44 | 42 | 21 | 0.58 | +1222 | +58.2 |
| HONEST WORTH | 568 | 562 | 20 | 0.56 | +222 | +11.1 |
| MARCH ODDS | 20 | 20 | 20 | 0.56 | +237 | +11.8 |
| FRIENDS SHOTS CHECKED | 19 | 19 | 19 | 0.53 | +1582 | +83.3 |
| BEST PREY | 65 | 65 | 18 | 0.50 | +571 | +31.7 |
| REDIRECT WEIGHED | 17 | 17 | 17 | 0.47 | +729 | +42.9 |
| BLOCKED WHEEL | 16 | 16 | 16 | 0.44 | +65 | +4.1 |
| CASTING BLOCK | 23 | 23 | 16 | 0.44 | +614 | +38.4 |
| CHARGE BAND | 16 | 16 | 16 | 0.44 | +0 | +0.0 |
| WHO HITS BACK | 16 | 16 | 16 | 0.44 | +728 | +45.5 |
| MANOEUVRE | 17 | 17 | 15 | 0.42 | +573 | +38.2 |
| CASTS FROM BEHIND | 14 | 14 | 14 | 0.39 | +0 | +0.0 |
| REFUSING RETIRES | 25 | 25 | 11 | 0.31 | -3 | -0.2 |
| HUNT IN PAIRS | 33 | 21 | 10 | 0.28 | +513 | +51.3 |
| JOINT AS ONE | 101 | 101 | 9 | 0.25 | +110 | +12.3 |
| PIVOT GUARDS FLANK | 9 | 9 | 9 | 0.25 | -164 | -18.2 |
| PURSUES BIG PREY | 9 | 9 | 9 | 0.25 | -616 | -68.4 |
| WEARS DOWN | 75 | 71 | 9 | 0.25 | +289 | +32.1 |
| CHAFF PASSED | 8 | 8 | 8 | 0.22 | +0 | +0.0 |
| LOST CHARGE | 203 | 200 | 8 | 0.22 | +212 | +26.5 |
| MAKE SURE TOGETHER | 44 | 32 | 8 | 0.22 | +1040 | +130.0 |
| SHORT GUN FORWARD | 8 | 8 | 8 | 0.22 | +0 | +0.0 |
| STUCK PIVOT | 8 | 8 | 8 | 0.22 | +0 | +0.0 |
| SURE CHARGE BEATS ADVANCE | 8 | 8 | 8 | 0.22 | -285 | -35.6 |
| BIG CHARACTER SAFETY | 7 | 7 | 7 | 0.19 | -26 | -3.7 |
| MISSILES NEXT TURN | 325 | 183 | 7 | 0.19 | +53 | +7.6 |
| MOVES UNITS SPELL | 7 | 7 | 7 | 0.19 | +186 | +26.5 |
| OVERRUNS AWAY | 43 | 42 | 7 | 0.19 | +363 | +51.8 |
| WHOLE FIGHT | 30 | 30 | 7 | 0.19 | +739 | +105.6 |
| BEST PRIZE | 6 | 6 | 6 | 0.17 | -248 | -41.2 |
| SUPPORT NARROWED | 429 | 429 | 6 | 0.17 | -107 | -17.8 |
| BACKUP TARGETS | 69 | 35 | 5 | 0.14 | +21 | +4.1 |
| BLOCKED CHARGE SKIPPED | 5 | 5 | 5 | 0.14 | +0 | +0.0 |
| MODEL FACING | 5 | 5 | 5 | 0.14 | +1353 | +270.7 |
| SURE REACH TOGETHER | 56 | 44 | 5 | 0.14 | +120 | +24.0 |
| CONTINUE AHEAD WEIGHED | 4 | 4 | 4 | 0.11 | +0 | +0.0 |
| KEEP FALLS | 4 | 4 | 4 | 0.11 | +166 | +41.5 |
| OPENS UP | 8 | 8 | 4 | 0.11 | +104 | +26.0 |
| RAIDS THE BAGGAGE NEXT TURN | 6 | 6 | 4 | 0.11 | +198 | +49.5 |
| RESTRAINS TO SHOOT | 4 | 4 | 4 | 0.11 | +88 | +22.0 |
| WAR ENGINE JOBS | 26 | 26 | 4 | 0.11 | -347 | -86.6 |
| HUNT ADVANCE | 6 | 6 | 3 | 0.08 | +106 | +35.2 |
| LONE WIZARD HOLDS BACK | 18 | 18 | 3 | 0.08 | -208 | -69.4 |
| NO RALLY LEFT | 3 | 3 | 3 | 0.08 | +75 | +25.0 |
| OPENS A LANE | 18 | 5 | 3 | 0.08 | +32 | +10.6 |
| SPELLS IN THE FIGHT | 32 | 31 | 3 | 0.08 | +23 | +7.7 |
| STANDS TO CAST | 3 | 3 | 3 | 0.08 | -5 | -1.6 |
| WAR ENGINE CHARGES | 9 | 9 | 3 | 0.08 | +245 | +81.8 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| PERIAPT WORTH | 2 | 2 | 2 | 0.06 | +230 | +115.1 |
| REDIRECT BY WHAT IT STOPS | 25 | 25 | 2 | 0.06 | +38 | +18.8 |
| SCREEN BY WHAT IT SAVES | 15 | 15 | 2 | 0.06 | +44 | +21.8 |
| WIDER SPREAD | 202 | 192 | 2 | 0.06 | +30 | +14.8 |
| BLOWS WHERE AIMED | 22 | 21 | 1 | 0.03 | +14 | +13.9 |
| BOMBING RUN | 1 | 1 | 1 | 0.03 | +47 | +47.3 |
| CARRIES OUT CLOSE-IN | 22 | 22 | 1 | 0.03 | -17 | -16.7 |
| CARRIES OUT COUNTER | 2 | 2 | 1 | 0.03 | -39 | -39.1 |
| CARRIES OUT SET-UP | 15 | 15 | 1 | 0.03 | -12 | -12.0 |
| CATCH ODDS | 1 | 1 | 1 | 0.03 | -4 | -4.5 |
| DEFENSIVE ARMY | 7 | 7 | 1 | 0.03 | -27 | -26.6 |
| ELIXIR WORTH | 1 | 1 | 1 | 0.03 | +3 | +2.8 |
| FOCUS FIRE | 1 | 1 | 1 | 0.03 | +19 | +19.4 |
| JOINT CHARGE PLAN | 11 | 11 | 1 | 0.03 | +15 | +14.6 |
| LONG SHOT | 35 | 35 | 1 | 0.03 | +0 | +0.3 |
| STAY WEIGHED | 1 | 1 | 1 | 0.03 | +8 | +7.7 |
| STOPS | 4 | 4 | 1 | 0.03 | +13 | +12.6 |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 38 | 38 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 28 | trace | - | - | - | - |
| CATCH FLIERS | 3 | not checked | - | - | - | - |
| CHARGER SLAIN LOST | 43 | 41 | 0 | 0.00 | - | - |
| CHARIOT WIZARD CAREFUL | 6 | 6 | 0 | 0.00 | - | - |
| CHEAP HELPER | 5 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 30 | not checked | - | - | - | - |
| EDGE GIVE GROUND | 6 | 6 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 2 | 2 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 417 | not checked | - | - | - | - |
| GIVES UP | 3 | 3 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 2 | 2 | 0 | 0.00 | - | - |
| HELPER ALREADY ASKED | 3 | not checked | - | - | - | - |
| HELPER UNSEEN | 28 | 26 | 0 | 0.00 | - | - |
| HILL BY ITS CHANCE | 2 | 2 | 0 | 0.00 | - | - |
| HUNT DROPPED | 4 | trace | - | - | - | - |
| HUNT KEPT | 4 | trace | - | - | - | - |
| HUNT RESULT | 8 | trace | - | - | - | - |
| HUNT THE GUNS | 8 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 7 | 6 | 0 | 0.00 | - | - |
| KEEPS ITS PREY | 1 | 1 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 23 | not checked | - | - | - | - |
| LURE BY WHAT IT DRAWS | 3 | 3 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 28 | 28 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 7 | 7 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 7 | 4 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 19 | trace | - | - | - | - |
| MOVE SPELL SPOT | 9 | not checked | - | - | - | - |
| NO CHARGE WHY | 221 | not checked | - | - | - | - |
| NOT NEEDED | 23 | 23 | 0 | 0.00 | - | - |
| NOT TURNED | 429 | 429 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 50 | not checked | - | - | - | - |
| OVERRUN THREAT | 1 | not checked | - | - | - | - |
| PLAN RESULT | 2712 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 8 | 8 | 0 | 0.00 | - | - |
| SCOUT SPOT | 23 | 23 | 0 | 0.00 | - | - |
| SECOND HUNTER | 1 | 1 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 14 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 10 | not checked | - | - | - | - |
| SET-UP MISSED | 3 | trace | - | - | - | - |
| SPELL SETS UP CHARGE | 13 | not checked | - | - | - | - |
| SPELL WORTH | 92 | not checked | - | - | - | - |
| STABLE ROLE | 829 | 829 | 0 | 0.00 | - | - |
| TURN WORTH | 14 | 14 | 0 | 0.00 | - | - |
| TWO OR MORE ARRIVE | 20 | 17 | 0 | 0.00 | - | - |

### Off best figure: su-h2h-opp-e45904b-p1

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 13.97 | 13.22 | 54.2 |
| FALLBACK | gate | 0.67 | 1.11 | 38.6 |
| TURN GATE | gate | 0.72 | 0.69 | 29.3 |
| CHARGE NOW FIRST | rule | 0.69 | 0.31 | 50.6 |
| NO REASON | gate | - | 0.53 | 41.7 |
| LONE CHARACTER SAFE SPOT | gate | 0.14 | 0.19 | 60.8 |
| PIVOT GUARDS FLANK | rule | 0.06 | 0.19 | 18.2 |
| PURSUES BIG PREY | rule | 0.08 | 0.17 | 68.4 |
| SUPPORT REQUEST | gate | 0.08 | 0.14 | 71.0 |
| SURE CHARGE BEATS ADVANCE | rule | 0.08 | 0.14 | 35.6 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.14 | 0.06 | 32.3 |
| CANNON PLANNED TARGET | rule | 0.14 | 0.06 | 57.2 |
| FIGHT ORDER BAND | gate | 0.14 | 0.03 | 1.6 |
| JOINT AS ONE | rule | - | 0.17 | 17.6 |
| PATHS CROSS | rule | 0.06 | 0.11 | 21.7 |
| THROUGH LINE OF FIRE | rule | 0.14 | 0.03 | 42.8 |
| BEST PRIZE | rule | 0.03 | 0.11 | 49.5 |
| CHARGE NOW WEIGHED | rule | 0.03 | 0.11 | 37.6 |
| SUPPORT NARROWED | rule | 0.08 | 0.06 | 21.4 |
| AFTERMATH BAND | gate | 0.08 | 0.03 | 2.6 |
| BIG CHARACTER SAFETY | rule | 0.06 | 0.06 | 8.7 |
| MARCH ODDS | rule | 0.06 | 0.06 | 12.2 |
| WAR ENGINE JOBS | rule | 0.06 | 0.06 | 86.6 |
| BLOCKED WHEEL | rule | - | 0.08 | 75.6 |
| LONE WIZARD HOLDS BACK | rule | - | 0.08 | 69.4 |
| MOVE AND CAST | rule | 0.03 | 0.06 | 15.7 |
| REDIRECT WEIGHED | rule | - | 0.06 | 74.8 |
| SAFER THAN THE JOB | rule | - | 0.06 | 2.6 |
| STANDS TO CAST | rule | 0.03 | 0.03 | 2.8 |
| CARRIES OUT CLOSE-IN | rule | - | 0.03 | 16.7 |
| CARRIES OUT COUNTER | rule | 0.03 | - | 39.1 |
| CARRIES OUT SET-UP | rule | 0.03 | - | 12.0 |
| CATCH ODDS | rule | 0.03 | - | 4.5 |
| DEFENSIVE ARMY | rule | 0.03 | - | 26.6 |
| FACES THE THREAT | rule | 0.03 | - | 13.4 |
| SET-UP SPOT | rule | - | 0.03 | 2.7 |
| STOPS SHORT OF THE FLANK | rule | 0.03 | - | 15.9 |

### Plans: su-h2h-opp-e45904b-p1

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 10.8 | 16% | 404 | 289 | 72% |
| Mine | charge | 3.4 | 67% | 301 | 349 | 116% |
| Mine | close in | 4.1 | 29% | 263 | 103 | 39% |
| Mine | hold | 5.6 | 37% | 334 | 0 | 0% |
| Mine | join | 0.5 | 100% | 20 | 0 | 0% |
| Mine | shoot | 9.6 | 62% | 394 | 804 | 204% |
| Mine | support | 3.4 | 87% | 32 | 0 | 0% |
| Opponent | advance | 12.9 | 15% | 381 | 285 | 75% |
| Opponent | charge | 3.7 | 67% | 310 | 407 | 131% |
| Opponent | close in | 5.5 | 29% | 338 | 151 | 45% |
| Opponent | hold | 4.4 | 39% | 301 | 0 | 0% |
| Opponent | join | 1.2 | 98% | 61 | 0 | 0% |
| Opponent | shoot | 5.1 | 56% | 114 | 257 | 226% |
| Opponent | support | 5.2 | 89% | 44 | 0 | 0% |

### Packages: hunt the guns, su-h2h-opp-e45904b-p1

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.1 | 2 | 0 | 0% | 50% | 0% | 2.0 | 303 | 109 | 50% | 16 |
| Opponent | 0.2 | 6 | 0 | 33% | 0% | 0% | - | 373 | 0 | 0% | 124 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Dwarfen Mountain Holds | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 385 | 0 | 0% | 81 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 58 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 95 |
| Kingdom of Bretonnia | 1.0 | 1 | 0 | 0% | 100% | 0% | 2.0 | 222 | 218 | 100% | 0 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 755 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 18 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 83 |
| Tomb Kings of Khemri | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 342 | 0 | 0% | 53 |
| Vampire Counts | 0.1 | 1 | 0 | 0% | 0% | 0% | - | 374 | 0 | 0% | 116 |
| Warriors of Chaos | 0.4 | 3 | 0 | 67% | 0% | 0% | - | 398 | 0 | 0% | 125 |
| Wood Elf Realms | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 329 | 0 | 0% | 46 |

### Battle groups: su-h2h-opp-e45904b-p1

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 9.0 | 21% | 45% | 12% | 50% | 24% | 8% | 10% | 58% | 0% |
| Mine | REDIRECT COUNTER | 1.8 | 27% | 71% | 12% | 0% | 33% | 0% | 13% | 47% | 7% |
| Opponent | COUNTER-CHARGE COVER | 7.8 | 19% | 59% | 13% | 29% | 34% | 2% | 11% | 53% | 0% |
| Opponent | REDIRECT COUNTER | 4.5 | 23% | 57% | 16% | 17% | 26% | 0% | 6% | 68% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: su-h2h-opp-e45904b-p1

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 3 | 0 (3) | 0 | 0 | 19 | 0% | 4.0 | 0 (2) | 0 (1) | - | 0 (1) | 0 (2) |
| Mine | Chaff | 37 | 58 (37) | 56 | 3 | 44 | 41% | 2.1 | 13 (16) | 25 (9) | 135 (12) | 13 (24) | 128 (13) |
| Mine | Character | 120 | 51 (120) | 51 | 0 | 31 | 18% | 2.3 | 75 (33) | 46 (60) | 17 (11) | 65 (55) | 43 (49) |
| Mine | Clean-up | 24 | 56 (24) | 17 | 39 | 48 | 42% | 2.9 | 51 (9) | 49 (11) | 115 (4) | 75 (14) | 34 (10) |
| Mine | Fast | 4 | 35 (4) | 35 | 0 | 13 | 25% | 1.3 | 67 (1) | 0 (2) | 0 (1) | 35 (4) | - |
| Mine | Fast Hammer | 40 | 48 (40) | 39 | 9 | 55 | 18% | 3.0 | 69 (17) | 38 (12) | 23 (11) | 39 (27) | 65 (13) |
| Mine | Fragile | 5 | 0 (5) | 0 | 0 | 60 | 20% | 2.0 | - | 0 (4) | 0 (1) | 0 (1) | 0 (4) |
| Mine | Hammer | 55 | 49 (55) | 32 | 17 | 45 | 13% | 2.6 | 53 (10) | 47 (35) | 52 (10) | 56 (33) | 41 (22) |
| Mine | Holder | 25 | 73 (25) | 5 | 67 | 26 | 28% | 3.5 | 68 (9) | 80 (11) | 61 (5) | 101 (10) | 53 (15) |
| Mine | Shooter | 41 | 122 (41) | 43 | 79 | 16 | 5% | 1.8 | 66 (5) | 158 (28) | 50 (8) | 139 (22) | 103 (19) |
| Mine | Support | 2 | 0 (2) | 0 | 0 | 0 | 0% | 3.5 | 0 (1) | 0 (1) | - | 0 (2) | - |
| Mine | War machine | 56 | 66 (56) | 66 | 0 | 37 | 4% | 1.3 | 84 (13) | 58 (37) | 79 (6) | 49 (11) | 71 (45) |
| Mine | Wizard | 23 | 29 (23) | 29 | 0 | 32 | 17% | 2.3 | 53 (5) | 35 (10) | 0 (3) | 103 (4) | 13 (14) |
| Opponent | Blocker | 1 | 58 (1) | 58 | 0 | 0 | 100% | - | - | 58 (1) | - | - | 58 (1) |
| Opponent | Chaff | 64 | 56 (64) | 20 | 36 | 44 | 41% | 3.3 | 73 (27) | 64 (16) | 27 (21) | 73 (46) | 11 (18) |
| Opponent | Character | 112 | 39 (112) | 39 | 0 | 40 | 22% | 2.6 | 60 (39) | 31 (54) | 12 (6) | 45 (68) | 36 (31) |
| Opponent | Clean-up | 16 | 17 (16) | 17 | 0 | 58 | 25% | 3.2 | 0 (5) | 3 (8) | 70 (3) | 36 (8) | 2 (8) |
| Opponent | Early | 1 | 34 (1) | 34 | 0 | 0 | 0% | 4.0 | - | 34 (1) | - | 34 (1) | - |
| Opponent | Fast Hammer | 54 | 50 (54) | 27 | 23 | 65 | 31% | 2.3 | 46 (24) | 35 (17) | 78 (13) | 54 (38) | 40 (16) |
| Opponent | Fragile | 10 | 0 (10) | 0 | 0 | 52 | 30% | 1.6 | 0 (3) | 0 (3) | 0 (3) | 0 (9) | - |
| Opponent | Hammer | 65 | 51 (65) | 39 | 11 | 56 | 20% | 2.6 | 44 (16) | 49 (42) | 86 (7) | 47 (40) | 58 (25) |
| Opponent | Holder | 37 | 63 (37) | 5 | 58 | 16 | 62% | 3.3 | 41 (9) | 89 (17) | 30 (11) | 66 (19) | 60 (18) |
| Opponent | Shooter | 29 | 59 (29) | 16 | 44 | 37 | 7% | 1.2 | 72 (7) | 55 (17) | 57 (5) | 69 (16) | 45 (13) |
| Opponent | Support | 2 | 134 (2) | 134 | 0 | 0 | 50% | 6.0 | 0 (1) | 269 (1) | - | 269 (1) | 0 (1) |
| Opponent | War machine | 13 | 39 (13) | 39 | 0 | 36 | 0% | 1.2 | 0 (5) | 47 (5) | 95 (3) | 86 (3) | 26 (10) |
| Opponent | Wizard | 21 | 22 (21) | 22 | 0 | 38 | 5% | 1.9 | 18 (12) | 86 (3) | 0 (3) | 21 (10) | 26 (8) |

### Charged fights: su-h2h-opp-e45904b-p1

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 5 | 234 | 69 | 1.6 | 1.1 | 43 | 13 | +30 | 0 of 8 | 5 of 8 | -52 | +42 |
| Mine | Chaos Dwarfs | 3 | 106 | 972 | 5.0 | 1.1 | 194 | 4 | +190 | 8 of 15 | 11 of 15 | +402 | +157 |
| Mine | Dwarfen Mountain Holds | 4 | 524 | 64 | 1.2 | 1.4 | 52 | 12 | +40 | 1 of 5 | 3 of 5 | +108 | -6 |
| Mine | Empire of Man | 5 | 372 | 255 | 2.0 | 1.1 | 128 | 79 | +49 | 4 of 10 | 8 of 10 | -569 | +118 |
| Mine | Grand Cathay | 4 | 708 | 382 | 2.5 | 1.4 | 153 | 43 | +109 | 7 of 10 | 8 of 10 | +314 | -27 |
| Mine | High Elf Realms | 4 | 222 | 580 | 3.8 | 1.5 | 155 | 18 | +136 | 3 of 15 | 12 of 15 | +152 | +126 |
| Mine | Kingdom of Bretonnia | 1 | 75 | 1010 | 4.0 | 1.5 | 252 | 0 | +252 | 2 of 4 | 4 of 4 | +304 | +200 |
| Mine | Ogre Kingdoms | 1 | 0 | 70 | 5.0 | 1.2 | 14 | 46 | -32 | 2 of 5 | 3 of 5 | +70 | -57 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 265 | 2.0 | 1.5 | 132 | 215 | -82 | 2 of 2 | 1 of 2 | -165 | +0 |
| Mine | Skaven | 2 | 25 | 162 | 1.0 | 1.0 | 162 | 76 | +86 | 0 of 2 | 1 of 2 | - | +86 |
| Mine | Tomb Kings of Khemri | 2 | 0 | 1398 | 5.0 | 1.5 | 280 | 39 | +240 | 5 of 10 | 8 of 10 | +413 | +68 |
| Mine | Vampire Counts | 2 | 0 | 312 | 3.5 | 1.1 | 89 | 101 | -12 | 1 of 7 | 6 of 7 | +170 | -42 |
| Mine | Warriors of Chaos | 1 | 0 | 160 | 4.0 | 1.0 | 40 | 8 | +32 | 1 of 4 | 3 of 4 | - | +32 |
| **Mine** | all armies | 35 | 265 | 397 | 2.8 | 1.3 | 143 | 38 | +105 | 36 of 97 | 73 of 97 | +205 | +69 |
| Opponent | Beastmen Brayherds | 1 | 65 | 1094 | 5.0 | 1.2 | 219 | 124 | +95 | 2 of 5 | 3 of 5 | +572 | -24 |
| Opponent | Dwarfen Mountain Holds | 1 | 0 | 0 | 2.0 | 1.0 | 0 | 0 | +0 | 1 of 2 | 2 of 2 | - | +0 |
| Opponent | Empire of Man | 1 | 350 | 474 | 1.0 | 2.0 | 474 | 0 | +474 | 1 of 1 | 1 of 1 | +474 | - |
| Opponent | Grand Cathay | 1 | 120 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | High Elf Realms | 2 | 318 | 0 | 1.5 | 1.3 | 0 | 48 | -48 | 3 of 3 | 3 of 3 | +0 | -72 |
| Opponent | Lizardmen | 1 | 189 | 526 | 1.0 | 2.0 | 526 | 0 | +526 | 1 of 1 | 1 of 1 | +526 | - |
| Opponent | Ogre Kingdoms | 2 | 0 | 146 | 3.5 | 1.1 | 42 | 48 | -6 | 2 of 7 | 5 of 6 | +77 | -20 |
| Opponent | Orc & Goblin Tribes | 2 | 35 | 342 | 4.0 | 1.1 | 86 | 33 | +52 | 1 of 8 | 6 of 8 | +0 | +60 |
| Opponent | Skaven | 2 | 314 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 1 of 2 | 2 of 2 | - | +0 |
| Opponent | Tomb Kings of Khemri | 3 | 71 | 1005 | 4.3 | 1.3 | 232 | 35 | +197 | 8 of 13 | 13 of 13 | +334 | +136 |
| Opponent | Vampire Counts | 6 | 9 | 370 | 3.8 | 1.4 | 96 | 50 | +47 | 9 of 23 | 19 of 23 | +21 | +61 |
| Opponent | Warriors of Chaos | 7 | 22 | 316 | 2.4 | 1.2 | 130 | 25 | +105 | 9 of 17 | 14 of 17 | -60 | +140 |
| Opponent | Wood Elf Realms | 6 | 130 | 369 | 3.0 | 1.3 | 123 | 27 | +96 | 5 of 18 | 15 of 18 | +189 | +60 |
| **Opponent** | all armies | 35 | 93 | 364 | 2.9 | 1.3 | 127 | 39 | +88 | 43 of 100 | 84 of 99 | +151 | +67 |

### Effective charges: su-h2h-opp-e45904b-p1

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 8 | 1 (net +0) | 1 (net +185) | 1 (net +0) | 1 (net -52) | 0 | 2 (net +17) | 2 | 17% (1 of 6) |
| Mine | Chaos Dwarfs | 15 | 1 (net +388) | 1 (net +0) | 1 (net +572) | 3 (net +295) | 1 (net +0) | 8 (net +126) | 0 | 7% (1 of 15) |
| Mine | Dwarfen Mountain Holds | 5 | 1 (net +217) | 0 | 0 | 2 (net -10) | 0 | 2 (net +0) | 0 | 0% (0 of 5) |
| Mine | Empire of Man | 10 | 1 (net +0) | 0 | 2 (net +134) | 2 (net -284) | 1 (net +0) | 4 (net +198) | 0 | 20% (2 of 10) |
| Mine | Grand Cathay | 10 | 0 | 0 | 2 (net +126) | 3 (net +288) | 0 | 3 (net +97) | 2 | 25% (2 of 8) |
| Mine | High Elf Realms | 15 | 0 | 1 (net +0) | 0 | 4 (net +198) | 5 (net +62) | 2 (net +332) | 3 | 0% (0 of 12) |
| Mine | Kingdom of Bretonnia | 4 | 0 | 0 | 1 (net +398) | 0 | 0 | 3 (net +204) | 0 | 25% (1 of 4) |
| Mine | Ogre Kingdoms | 5 | 0 | 0 | 1 (net +70) | 2 (net -114) | 0 | 1 (net +0) | 1 | 25% (1 of 4) |
| Mine | Skaven | 2 | 0 | 0 | 0 | 0 | 0 | 2 (net +86) | 0 | 0% (0 of 2) |
| Mine | Tomb Kings of Khemri | 10 | 3 (net +569) | 0 | 3 (net -73) | 0 | 1 (net +125) | 3 (net +264) | 0 | 30% (3 of 10) |
| Mine | Vampire Counts | 7 | 1 (net +0) | 0 | 2 (net +85) | 3 (net -7) | 0 | 1 (net -233) | 0 | 29% (2 of 7) |
| Mine | Warriors of Chaos | 4 | 1 (net -30) | 0 | 0 | 0 | 1 (net +160) | 2 (net +0) | 0 | 0% (0 of 4) |
| Opponent | Beastmen Brayherds | 5 | 1 (net +77) | 0 | 2 (net -88) | 0 | 0 | 1 (net +572) | 1 | 50% (2 of 4) |
| Opponent | Dwarfen Mountain Holds | 2 | 0 | 0 | 0 | 0 | 0 | 2 (net +0) | 0 | 0% (0 of 2) |
| Opponent | Empire of Man | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +474) | 0 | 0% (0 of 1) |
| Opponent | High Elf Realms | 3 | 1 (net -143) | 0 | 0 | 0 | 0 | 2 (net +0) | 0 | 0% (0 of 3) |
| Opponent | Lizardmen | 1 | 0 | 1 (net +526) | 0 | 0 | 0 | 0 | 0 | 0% (0 of 1) |
| Opponent | Ogre Kingdoms | 7 | 1 (net +0) | 0 | 1 (net -34) | 3 (net +69) | 0 | 1 (net +85) | 1 | 17% (1 of 6) |
| Opponent | Orc & Goblin Tribes | 8 | 0 | 0 | 0 | 0 | 0 | 1 (net +230) | 7 | 0% (0 of 1) |
| Opponent | Skaven | 2 | 0 | 0 | 0 | 1 (net +0) | 0 | 0 | 1 | 0% (0 of 1) |
| Opponent | Tomb Kings of Khemri | 13 | 1 (net -195) | 0 | 6 (net +206) | 2 (net +225) | 0 | 3 (net +314) | 1 | 50% (6 of 12) |
| Opponent | Vampire Counts | 23 | 2 (net -172) | 0 | 4 (net +41) | 7 (net +21) | 1 (net +0) | 9 (net +123) | 0 | 17% (4 of 23) |
| Opponent | Warriors of Chaos | 17 | 3 (net +221) | 0 | 2 (net +76) | 6 (net +96) | 0 | 5 (net +101) | 1 | 12% (2 of 16) |
| Opponent | Wood Elf Realms | 18 | 1 (net +122) | 1 (net +0) | 4 (net +40) | 6 (net +80) | 1 (net +65) | 5 (net +179) | 0 | 22% (4 of 18) |

### Charged fights, damage counted: su-h2h-opp-e45904b-p1

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 9 | 314 | 190 | +254 | 258 | 71 | +186 | +59.3 |
| Mine | 50-54% | 3 | 141 | 203 | +62 | 62 | 6 | +56 | +39.7 |
| Mine | Effective (55-75%) | 13 | 293 | 205 | +116 | 164 | 38 | +126 | +42.9 |
| Mine | 76-89% | 20 | 342 | 174 | +83 | 174 | 92 | +82 | +23.8 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 33 | 253 | 180 | +125 | 157 | 30 | +127 | +50.2 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 9 | 565 | 106 | +66 | 95 | 71 | +24 | +4.2 |
| Mine | No odds | 10 | 336 | 182 | -12 | 93 | 116 | -23 | -6.8 |
| Mine | All fights | 97 | 317 | 177 | +105 | 156 | 60 | +96 | +30.2 |
| Opponent | Long shot (under 50%) | 10 | 141 | 176 | +18 | 105 | 70 | +35 | +24.9 |
| Opponent | 50-54% | 2 | 520 | 280 | +263 | 271 | 0 | +271 | +52.2 |
| Opponent | Effective (55-75%) | 19 | 218 | 204 | +79 | 150 | 60 | +90 | +41.4 |
| Opponent | 76-89% | 25 | 291 | 182 | +75 | 146 | 58 | +88 | +30.1 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 30 | 332 | 201 | +160 | 207 | 40 | +167 | +50.4 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 2 | 349 | 96 | +32 | 73 | 0 | +73 | +20.9 |
| Opponent | No odds | 12 | 243 | 234 | -9 | 97 | 65 | +32 | +13.1 |
| Opponent | All fights | 100 | 274 | 198 | +88 | 156 | 53 | +103 | +37.7 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| su-h2h-opp-e45904b-p1 | move | 482 | 106 (22%) | 84 (17%) | 67 (14%) | 309 (64%) |
| su-h2h-opp-e45904b-p1 | objective | 347 | 69 (20%) | 53 (15%) | 44 (13%) | 234 (67%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0102, L0118, L0135, L2531, L2730 |
| Charmed Shield | Opponent | L0524, L1224, L1527, L1625, L2025, L2127, L2934 |
| Clockwork Compass | Mine | L1224 |
| Clockwork Compass | Opponent | L0612 |
| Elixir of Power | Mine | L1114, L1131, L1923 |
| Elixir of Power | Opponent | L0319, L1319 |
| Fistful of Laurels | Mine | L1823 |
| Fistful of Laurels | Opponent | L0118, L0218 |
| Horn of the Wild Hunt | Opponent | L0733 |
| Invocation of Nehek | Mine | L2531, L2730 |
| Invocation of Nehek | Opponent | L0524, L1224, L1527, L1625, L2025, L2127 |
| Opal Amulet | Mine | L1431 |
| Opal Amulet | Opponent | L1114 |
| Periapt of Soul Exchange | Mine | L2025, L2127 |
| Periapt of Soul Exchange | Opponent | L0421, L1021 |
| Ring of Doom | Mine | L0218, L0235, L1114, L1131, L1224, L1527 |
| Ring of Doom | Opponent | L0102, L0612, L0733, L1131, L1431, L2231, L2531 |
| Ring of Jet | Mine | L1021, L1114, L1131, L1224 |
| Ring of Jet | Opponent | L0612 |
| Standard of the Fell Warrior | Mine | L1319, L1335 |
| Standard of the Fell Warrior | Opponent | L0913 |
| Storm Daemon (Renegade 2.0) | Mine | L2127 |
| Storm Daemon (Renegade 2.0) | Opponent | L0421, L1021 |
| Twice-Blessed Armour | Mine | L0717, L0733, L1021 |
| Witch Hunter's Ward | Mine | L0717, L0733, L0823 |
| Witch Hunter's Ward | Opponent | L0508 |

# Doctrine scorecard: su-h2h-opp-e45904b-p4b

### Scorecard: su-h2h-opp-e45904b-p4b

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L1126 | 4 | 1 | Mine | no | 0 | 4 | 2 | 0 | 0 | 0 | 0 | 427 |
| L1126 | 4 | 1 | Opponent | no | 7 | 3 | 4 | 1 | 0 | 0 | 0 | 0 |
| L1220 | 2 | 1 | Mine | - | - | 2 | 4 | 0 | 0 | 0 | 0 | 330 |
| L1220 | 2 | 1 | Opponent | - | - | - | 2 | 2 | 0 | 0 | 0 | 440 |
| L1314 | 6 | 1 | Mine | no | 2 | 3 | 2 | 0 | 0 | 0 | 0 | 302 |
| L1314 | 6 | 1 | Opponent | no | 3 | 2 | 3 | 0 | 0 | 0 | 0 | 123 |
| L1331 | 5 | 1 | Mine | yes | - | 4 | 2 | 3 | 0 | 0 | 0 | 302 |
| L1331 | 5 | 1 | Opponent | no | - | - | 0 | 3 | 2 | 0 | 0 | 314 |
| L1427 | 5 | 1 | Mine | no | - | 3 | 2 | 2 | 1 | 0 | 0 | 0 |
| L1427 | 5 | 1 | Opponent | yes | - | 2 | 5 | 3 | 0 | 0 | 0 | 0 |
| L1523 | 5 | 1 | Mine | yes | - | 2 | 2 | 0 | 1 | 0 | 0 | 0 |
| L1523 | 5 | 1 | Opponent | yes | - | 2 | 3 | 3 | 0 | 0 | 0 | 311 |
| L1621 | 1 | 1 | Mine | no | 0 | 2 | 4 | 0 | 0 | 0 | 0 | 200 |
| L1621 | 1 | 1 | Opponent | no | 1 | 3 | 1 | 3 | 1 | 0 | 0 | 565 |
| L1719 | 3 | 1 | Mine | no | 1 | 2 | 5 | 0 | 0 | 0 | 0 | 98 |
| L1719 | 3 | 1 | Opponent | yes | 7 | 2 | 8 | 0 | 1 | 0 | 0 | 0 |
| L1819 | 1 | 1 | Mine | no | 0 | 3 | 5 | 0 | 0 | 0 | 0 | 0 |
| L1819 | 1 | 1 | Opponent | no | 1 | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| L1835 | 5 | 1 | Mine | yes | - | 4 | 4 | 1 | 0 | 0 | 0 | 185 |
| L1835 | 5 | 1 | Opponent | yes | - | 2 | 7 | 0 | 0 | 0 | 0 | 0 |
| L2021 | 5 | 1 | Mine | no | - | 6 | 2 | 3 | 1 | 0 | 0 | 420 |
| L2021 | 5 | 1 | Opponent | no | - | 6 | 1 | 4 | 0 | 0 | 0 | 355 |
| L2123 | 5 | 1 | Mine | yes | - | - | 0 | 4 | 0 | 0 | 0 | 210 |
| L2123 | 5 | 1 | Opponent | yes | - | 2 | 4 | 1 | 1 | 0 | 0 | 0 |
| L2227 | 1 | 1 | Mine | yes | 3 | 2 | 1 | 0 | 1 | 0 | 0 | 0 |
| L2227 | 1 | 1 | Opponent | yes | 0 | 1 | 3 | 2 | 0 | 0 | 0 | 0 |
| L2331 | 3 | 1 | Mine | no | 0 | 2 | 1 | 2 | 0 | 0 | 0 | 0 |
| L2331 | 3 | 1 | Opponent | yes | 1 | - | 1 | 1 | 3 | 0 | 0 | 170 |
| L2527 | 1 | 1 | Mine | no | 0 | 3 | 3 | 1 | 0 | 0 | 0 | 0 |
| L2527 | 1 | 1 | Opponent | no | 0 | 1 | 0 | 3 | 0 | 0 | 0 | 190 |
| L2634 | 6 | 1 | Mine | no | 11 | 3 | 3 | 1 | 2 | 0 | 0 | 0 |
| L2634 | 6 | 1 | Opponent | no | 8 | 2 | 5 | 2 | 0 | 0 | 0 | 0 |
| L2930 | 2 | 1 | Mine | - | - | 3 | 3 | 1 | 0 | 0 | 0 | 0 |
| L2930 | 2 | 1 | Opponent | - | - | 4 | 3 | 2 | 0 | 0 | 0 | 0 |
| L3234 | 6 | 1 | Mine | no | 3 | 2 | 4 | 2 | 0 | 0 | 0 | 170 |
| L3234 | 6 | 1 | Opponent | no | 4 | 2 | 3 | 0 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 31% | 2.0 | 2.9 | 2.7 | 1.1 | 0.3 | 0.0 | 0.0 | 146.9 |
| **Average** | | | Opponent | 44% | 3.2 | 2.4 | 3.1 | 1.7 | 0.4 | 0.0 | 0.0 | 137.1 |

### KPIs: su-h2h-opp-e45904b-p4b

Rules off - Mine only: SET-UP SPOT, CARRIES OUT CLOSE-IN, JOINT AS ONE.

Morten 2026-11-10; 18 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 6% (6 of 95) | 2% (2 of 88) | 4% (8 of 183) |
| Winner chose to follow up after the loser gave ground |  | 100% (33 of 33); on the table 100% | 100% (14 of 14); on the table 100% | 100% (47 of 47); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | 100% (7 of 7); on the table 100% | 100% (3 of 3); on the table 100% | 100% (10 of 10); on the table 100% |
| Winner chose to pursue after the loser fled |  | 93% (13 of 14); on the table 93% | 71% (15 of 21); on the table 81% | 80% (28 of 35); on the table 86% |
| Winner chose to follow up or pursue (all three) |  | 98% (53 of 54); on the table 98% | 84% (32 of 38); on the table 89% | 92% (85 of 92); on the table 95% |
| Magic missiles tried each own turn | 50%+ | 13% (10 of 78) | 33% (39 of 118) | 25% (49 of 196) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 18% (10 of 55) | 53% (39 of 74) | 38% (49 of 129) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 62% (21 of 34) | 52% (22 of 42) | 57% (43 of 76) |
| Points that never fought | lower | 22% (7105 of 32353) | 36% (12963 of 35993) | 29% (20068 of 68346) |
|   infantry points that never fought | lower | 46% (2916 of 6369) | 52% (3520 of 6808) | 49% (6436 of 13177) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 51% (60 of 117) | 63% (89 of 141) | 58% (149 of 258) |
| Bound items with a magic missile used (at least once a game) |  | 92% (11 of 12); 2.2 uses a game | 80% (4 of 5); 0.4 uses a game | 88% (15 of 17); 1.3 uses a game |
| Bound items with another spell used |  | 30% (3 of 10); 0.3 uses a game | 17% (1 of 6); 0.1 uses a game | 25% (4 of 16); 0.2 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 40% (2 of 5); 0.1 uses a game | 62% (5 of 8); 0.3 uses a game | 54% (7 of 13); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 47% (13183 of 28240) | 55% (16974 of 30959) | 51% (30157 of 59199) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.1 (28%) | 1.3 (30%) | 2.4 (29%) |
| MARCHED: its unit marched | 1.3 (34%) | 0.5 (11%) | 1.8 (22%) |
| CHARGED: its unit charged | 0.2 (4%) | 0.1 (3%) | 0.3 (3%) |
| IN COMBAT: engaged in combat | 0.8 (21%) | 0.5 (11%) | 1.3 (16%) |
| FLEEING: fleeing | 0.0 (0%) | 0.2 (4%) | 0.2 (2%) |
| GONE: slain | 0.3 (9%) | 1.8 (41%) | 2.1 (26%) |
| OFF THE TABLE: off the table or not arrived | 0.2 (4%) | 0.0 (0%) | 0.2 (2%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 5.3 | 1.2 | 1.6 | 2.7 | 0.2 | 2.0 |
| not cast | 4.1 | 1.9 | 2.1 | 8.2 | 0.8 | 25.3 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.8 (7%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.9 (47%) | 0.1 (3%) | 2.4 (29%) | 0.3 (33%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.8 (22%) | 0.3 (33%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (3%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.1 (1%) | 0.1 (3%) | 0.4 (18%) | 1.3 (16%) | 0.1 (13%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.3 (8%) | 0.3 (18%) | 0.3 (16%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.2 (5%) | 0.0 (0%) | 0.1 (3%) | 0.2 (2%) | 0.0 (0%) | 0.4 (2%) |
| GONE: slain | 1.1 (26%) | 0.2 (9%) | 0.6 (29%) | 2.1 (26%) | 0.2 (20%) | 5.4 (21%) |
| OFF THE TABLE: off the table or not arrived | 0.2 (4%) | 0.0 (0%) | 0.0 (0%) | 0.2 (2%) | 0.0 (0%) | 0.7 (3%) |
| STUPIDITY: Stupidity | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.4 (2%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (3%) | 0.3 (18%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.1 (51%) | 0.1 (6%) | 0.7 (32%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 16.6 (66%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.1 a game | 0.4 a game | 0.8 a game |
| stood (cast and not dispelled) | 71% (10 of 14) | 60% (3 of 5) | 68% (13 of 19) |
| the unit moved after it | 80% (8 of 10) | 100% (3 of 3) | 85% (11 of 13) |
| it charged on its next turn | 30% (3 of 10) | 0% (0 of 3) | 23% (3 of 13) |
| the enemy charged it first | 10% (1 of 10) | 0% (0 of 3) | 8% (1 of 13) |
| it fought by the end of its next turn | 30% (3 of 10) | 0% (0 of 3) | 23% (3 of 13) |
| it moved out of a charge the enemy had planned (not charged first) | 20% (2 of 10) | 33% (1 of 3) | 23% (3 of 13) |
| none of these (no charge, no fight, no charge escaped) | 30% (3 of 10) | 67% (2 of 3) | 38% (5 of 13) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 51% (212 of 414) | 57% (141 of 249) | 53% (353 of 663) |
|   cavalry | 44% (22 of 50) | 78% (49 of 63) | 63% (71 of 113) |
|   character | 16% (11 of 69) | 15% (9 of 60) | 16% (20 of 129) |
|   chariot | 58% (26 of 45) | 50% (6 of 12) | 56% (32 of 57) |
|   infantry | 56% (88 of 157) | 68% (77 of 114) | 61% (165 of 271) |
|   monster | 38% (15 of 39) | - | 38% (15 of 39) |
|   war machine | 93% (50 of 54) | - | 93% (50 of 54) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.2 (20%) | 1.1 (18%) | 3.3 (19%) |
| CHARGED: it charged | 1.8 (16%) | 1.6 (27%) | 3.4 (20%) |
| FLEEING: it fled or was fleeing | 0.7 (6%) | 0.1 (2%) | 0.8 (5%) |
| IN COMBAT: it fought this turn or the last | 0.8 (7%) | 0.5 (8%) | 1.3 (7%) |
| NO TARGET IN RANGE | 2.7 (24%) | 0.8 (14%) | 3.6 (21%) |
| ONLY IN COMBAT: the only targets were in combat | 1.3 (12%) | 0.3 (6%) | 1.7 (10%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.2 (10%) | 1.5 (25%) | 2.7 (15%) |
| SHELTERED: the target was sheltered | 0.3 (2%) | 0.0 (0%) | 0.3 (2%) |
| OTHER BAR | 0.2 (1%) | 0.1 (1%) | 0.2 (1%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 6.0 | 1.2 | 84% | 5.2 pts | 31 pts |
| character | 1.4 | 0.2 | 92% | 3.9 pts | 5 pts |
| chariot | 1.8 | 0.2 | 91% | 1.3 pts | 2 pts |
| infantry | 12.9 | 4.1 | 75% | 9.2 pts | 118 pts |
| monster | 0.9 | 0.0 | 100% | 0.0 pts | 0 pts |
| war machine | 2.8 | 1.8 | 62% | 17.9 pts | 50 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 5.4 | 7.3 | 6.4 |
| Charges that made contact a game | 4.2 | 4.8 | 4.5 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.67 declared, 0.67 contact (6 units) | 0.73 declared, 0.36 contact (11 units) | 0.71 declared, 0.47 contact (17 units) |
|   per unit a game, units carrying another wizard (or one alone) | 1.50 declared, 1.25 contact (4 units) | 1.00 declared, 0.60 contact (5 units) | 1.22 declared, 0.89 contact (9 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.67 declared, 0.51 contact (129 units) | 0.78 declared, 0.53 contact (152 units) | 0.73 declared, 0.52 contact (281 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 58% (22 of 38) | 29% (2 of 7) | 60% (3 of 5) | 54% (27 of 50) |
| Character in a unit | 82% (9 of 11) | 75% (3 of 4) | 100% (1 of 1) | 81% (13 of 16) |
| Character on its own | 95% (18 of 19) | 71% (10 of 14) | 30% (13 of 44) | 53% (41 of 77) |
| Chariot | 67% (8 of 12) | - | - | 67% (8 of 12) |
| Infantry | 64% (27 of 42) | 50% (4 of 8) | 0% (0 of 2) | 60% (31 of 52) |
| Monster | 65% (13 of 20) | 60% (6 of 10) | - | 63% (19 of 30) |
| Monstrous | 57% (4 of 7) | 30% (3 of 10) | - | 41% (7 of 17) |
| War Machines | 75% (3 of 4) | - | - | 75% (3 of 4) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Grand Cathay | 2 | 100% (6 of 6); on the table 100% | 17% (6 of 36) | 23% | 59% (10 of 17) | 100% (5 of 5); 10.0 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |
| High Elf Realms | 5 | 89% (8 of 9); on the table 89% | 22% (4 of 18) | 33% | 57% (21 of 37) | 100% (4 of 4); 3.0 uses a game | 25% (4 of 16); 1.2 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | 100% (3 of 3); on the table 100% | - | 19% | 0% (0 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Lizardmen | 1 | 100% (4 of 4); on the table 100% | - | 12% | 43% (3 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 2 | 100% (2 of 2); on the table 100% | 0% (0 of 6) | 14% | 64% (9 of 14) | 50% (1 of 2); 1.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 2 | 100% (9 of 9); on the table 100% | 13% (4 of 30) | 8% | 38% (6 of 16) | 0.0 uses a game | 0.0 uses a game | 100% (2 of 2); 1.0 uses a game |
| Skaven | 5 | 100% (3 of 3); on the table 100% | 26% (9 of 35) | 37% | 74% (28 of 38) | 100% (3 of 3); 1.0 uses a game | 0.0 uses a game | 60% (3 of 5); 0.6 uses a game |
| Tomb Kings of Khemri | 4 | 92% (12 of 13); on the table 92% | 0% (0 of 6) | 37% | 50% (10 of 20) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 6 | 95% (18 of 19); on the table 95% | 36% (17 of 47) | 32% | 53% (16 of 30) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 5 | 85% (11 of 13); on the table 92% | 33% (4 of 12) | 35% | 76% (34 of 45) | 100% (2 of 2); 1.0 uses a game | 0.0 uses a game | 100% (1 of 1); 0.2 uses a game |
| Wood Elf Realms | 3 | 82% (9 of 11); on the table 91% | 83% (5 of 6) | 26% | 43% (12 of 28) | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (su-h2h-opp-e45904b-p4b, 18 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 50% (21) | 45% (24) | 47% (45) |
| ...free all their last turn and able to turn (per game) | 0.83 | 0.89 | 1.72 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.11 | 0.28 | 0.39 |
| ...with the charger already in that arc before they moved (per game) | 0.44 | 0.33 | 0.78 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 1.94 | 1.28 | 3.22 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.89 | 0.61 | 1.50 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 5.89 | 7.61 | 13.50 |

### Quality by phase: su-h2h-opp-e45904b-p4b

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 4.1 | 3.8 |
| Strategy | Charge objectives carried out (made contact) | 49% (45 of 91) | 37% (37 of 101) |
| Strategy | Shoot objectives carried out (shot that target) | 47% (60 of 127) | 23% (17 of 75) |
| Strategy | Close-in objectives charged next turn | 18% (21 of 116) | 13% (11 of 82) |
| Strategy | Support requests answered (helper made contact too) | 82% (9 of 11) | 50% (11 of 22) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (1 of 1) | - |
| Strategy | Hexes on a unit its side charged or shot that turn | 40% (2 of 5) | 67% (2 of 3) |
| Strategy | Joined characters whose unit fought | 50% (3 of 6) | 21% (4 of 19) |
| Strategy | Lone characters that fought | 97% (38 of 39) | 74% (35 of 47) |
| Movement | Charges halted short of contact | 0.2 | 0.7 |
| Movement | Idle units | 1.1 | 1.7 |
| Movement | Points that never moved of their own | 146.9 | 137.1 |
| Movement | Fights charged into per game | 3.8 | 3.9 |
| Movement | Charges with odds: long shots (under 50%) | 3 of 65, net -22 | 14 of 60, net +41 |
| Movement | Charges with odds: sweet spot (55-75%) | 15 of 65, net +8 | 14 of 60, net +74 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 9 of 65, net +92 | 4 of 60, net +98 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 19 of 65, net +75 | 12 of 60, net +158 |
| Shooting | Shots by shooting units (incl. breath weapons) | 10.3 | 9.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 40% (74 of 186) | 33% (53 of 162) |
| Shooting | Points destroyed by shooting units | 66.0 | 21.7 |
| Shooting | War machine shots | 2.8 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 36% (18 of 50) | - |
| Shooting | Points destroyed by war machines | 7.2 | 0.0 |
| Magic | Magic missiles cast | 0.4 | 1.7 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 14% (1 of 7) | 27% (8 of 30) |
| Magic | Wounds caused by magic missiles | 1.0 | 1.8 |
| Magic | Wounds caused by other spells | 3.0 | 0.4 |
| Magic | Points destroyed by magic (all spells) | 99.8 | 1.9 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.8 / 0.3 / 0.9 / 0.1 | 2.1 / 0.3 / 0.3 / 0.1 |
| Combat | Points destroyed in combat | 352.1 | 387.2 |
| Combat | Points run down | 146.9 | 116.8 |
| Combat | Net points per charged fight, damage counted | +80 | +77 |
| Combat | Net per 100 charger points, damage counted | +24.3 | +32.2 |
| Combat | First round won (charged fights) | 87% | 63% |
| Combat | Net points per charged fight | +80 | +76 |
| Combat | Net points per supported fight / lone fight | +178 / +55 | +243 / +55 |
| Combat | Charged fights on a top-3 enemy unit | 23 of 68 | 27 of 70 |
| Game | Points lost | 628.8 | 747.9 |
| Game | VP from objectives | 572.2 | 546.7 |
| Game | Lone holders (player turns) | 2.0 | 3.2 |

- Mine won / drew / lost: 7 / 5 / 6 of 18 ended games (of 18); mean margin (Mine - Opponent) +118 VP
- The side that went first won 7 of 13 games with a winner
- Points traded per game (both sides' losses): 1377
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: su-h2h-opp-e45904b-p4b

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.8 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 0.1 | +0.0 | 0.0 | 9.2 | - | - | - | - |
| BACKUP TARGETS | 1.0 | +4.2 | 0.0 | 0.0 | 1.2 | +14.8 | 0.0 | 14.7 |
| BEST FACING | 0.7 | +27.5 | 0.0 | 30.4 | 0.5 | +53.2 | 0.0 | 0.0 |
| BEST FIRST | 4.7 | +134.4 | 213.0 | 119.4 | 5.7 | +216.0 | 151.5 | 115.1 |
| BEST OVERALL | 0.4 | +17.4 | 0.0 | 19.0 | 0.8 | +59.3 | 0.0 | 20.7 |
| BEST PREY | 0.7 | +43.1 | 33.4 | 12.3 | 1.2 | +43.8 | 12.7 | 11.3 |
| BEST PRIZE | 0.1 | -0.5 | 0.0 | 7.8 | 0.1 | -0.9 | 7.8 | 0.0 |
| BIG CHARACTER SAFETY | 0.5 | +0.1 | 0.0 | 30.0 | 0.2 | -1.0 | 0.0 | 30.0 |
| BLOCKED CHARGE SKIPPED | 0.2 | +0.0 | 50.3 | 0.0 | 0.1 | +0.0 | 6.1 | 0.0 |
| BLOCKED WHEEL | 0.4 | -0.5 | 0.0 | 0.0 | 0.7 | +10.6 | 0.0 | 0.0 |
| BLOWS WHERE AIMED | 0.4 | -13.7 | 62.4 | 35.7 | 0.2 | +4.7 | 39.7 | 0.0 |
| BOMBING RUN | 0.1 | +1.6 | 0.0 | 0.0 | - | - | - | - |
| CANNON PLAN MISSED | 0.5 | +0.0 | 72.1 | 0.0 | - | - | - | - |
| CANNON PLANNED TARGET | 2.2 | +37.0 | 174.7 | 36.7 | - | - | - | - |
| CANNON SIGHT KEPT | 0.5 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CARRIES OUT CLOSE-IN | - | - | - | - | 0.5 | -0.6 | 55.6 | 0.0 |
| CARRIES OUT COUNTER | 0.1 | +0.0 | 33.9 | 0.0 | 0.1 | -9.2 | 41.4 | 0.0 |
| CARRIES OUT SET-UP | 0.3 | -2.6 | 55.0 | 0.0 | - | - | - | - |
| CAST JOB | 0.4 | +8.0 | 32.0 | 0.0 | 0.4 | +4.2 | 35.0 | 0.0 |
| CASTER AWAY FROM SCREEN | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.1 | +0.7 | 0.0 | 0.0 | 0.1 | +2.5 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 0.8 | +0.0 | 0.0 | 45.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CHAFF PASSED | 0.2 | -0.1 | 0.0 | 8.1 | 0.2 | -0.3 | 0.0 | 3.7 |
| CHARGE BAND | 0.2 | +0.0 | 24.3 | 0.0 | 0.1 | +0.0 | 33.6 | 0.0 |
| CHARGE NOW FIRST | 2.7 | +0.0 | 275.0 | 120.3 | 2.3 | +0.0 | 304.1 | 115.4 |
| CHARGE NOW WEIGHED | 0.7 | -47.9 | 40.9 | 4.2 | 0.4 | -33.9 | 13.9 | 0.0 |
| CHARGER SLAIN LOST | 0.3 | -11.7 | 57.3 | 15.2 | 0.8 | -17.0 | 52.5 | 27.9 |
| CHARIOT WIZARD CAREFUL | 0.2 | -1.8 | 0.0 | 30.0 | 0.2 | -0.1 | 0.0 | 30.0 |
| CHEAP HELPER | - | - | - | - | 0.1 | +0.0 | 6.1 | 0.0 |
| COMBAT PIVOT | 0.4 | +0.0 | 18.8 | 44.7 | 0.5 | +0.0 | 19.3 | 10.8 |
| CONVEYANCE SEARCH | 0.5 | +79.7 | 0.0 | 45.0 | - | - | - | - |
| COUNTER-CHARGE COVER | 7.9 | +526.2 | 0.0 | 197.4 | 8.3 | +907.9 | 0.0 | 210.6 |
| DEFENSIVE ARMY | 0.1 | +0.0 | 6.4 | 0.0 | - | - | - | - |
| DEFENSIVE FLOOR | - | - | - | - | 0.1 | +4.5 | 19.4 | 0.0 |
| EDGE GIVE GROUND | 0.1 | +1.2 | 8.0 | 0.0 | 0.1 | +1.0 | 18.3 | 0.0 |
| ELIXIR WORTH | - | - | - | - | 0.1 | +2.6 | 0.0 | 0.0 |
| FACES THE THREAT | 1.9 | +138.2 | 0.0 | 83.1 | 1.3 | +98.2 | 0.0 | 15.8 |
| FALLBACK BY WORTH | 6.4 | +61.7 | 0.0 | 80.6 | 6.6 | +77.8 | 0.0 | 35.2 |
| FIGHT LIFT | 0.3 | +2.3 | 11.7 | 0.0 | - | - | - | - |
| FIRE AND FLEE | - | - | - | - | 0.1 | +2.2 | 13.9 | 0.0 |
| FLANK NOT WEIGHED | 5.6 | +0.0 | 0.0 | 136.1 | 7.3 | +0.0 | 0.0 | 126.0 |
| FOLLOW UP WEIGHED | 1.0 | +143.7 | 0.0 | 73.8 | 0.7 | +103.3 | 0.0 | 0.0 |
| FRIENDS SHOTS CHECKED | 0.2 | +10.9 | 0.0 | 27.8 | 0.2 | +18.4 | 0.0 | 1.5 |
| GIVES UP ITS SCREEN | - | - | - | - | 0.1 | -0.4 | 0.0 | 0.0 |
| HELPER ALREADY ASKED | - | - | - | - | 0.1 | +0.0 | 5.4 | 0.0 |
| HELPER UNSEEN | 0.4 | +0.0 | 10.3 | 1.7 | 0.7 | +0.0 | 101.9 | 38.1 |
| HILL BY ITS CHANCE | 0.5 | -90.5 | 0.0 | 6.8 | 0.4 | -32.5 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 0.6 | +0.0 | 0.0 | 0.0 | 0.9 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 10.9 | -201.1 | 861.3 | 134.5 | 7.6 | -144.3 | 440.6 | 165.2 |
| HUNT ADVANCE | - | - | - | - | 0.1 | +0.0 | 0.0 | 0.0 |
| HUNT DROPPED | - | - | - | - | 0.1 | +0.0 | 9.2 | 2.5 |
| HUNT IN PAIRS | 0.5 | +29.8 | 0.0 | 12.9 | 0.8 | +50.9 | 0.0 | 0.0 |
| HUNT RESULT | - | - | - | - | 0.2 | +13.8 | 9.2 | 2.5 |
| HUNT THE GUNS | - | - | - | - | 0.2 | +58.4 | 18.3 | 0.0 |
| INVITES THE FIGHT | 2.1 | +24.9 | 25.3 | 36.9 | 1.2 | +19.9 | 45.0 | 35.8 |
| JOINT AS ONE | - | - | - | - | 1.9 | -24.8 | 53.1 | 64.8 |
| JOINT CHARGE PLAN | 0.2 | +1.0 | 65.2 | 0.0 | - | - | - | - |
| JOINT KNOWS CHALLENGE | 0.1 | -0.4 | 12.3 | 0.0 | 0.1 | -1.1 | 30.3 | 0.0 |
| KEEPS ITS PREY | - | - | - | - | 0.2 | +0.5 | 0.0 | 9.4 |
| KEEPS ITS TARGET | 2.7 | +81.7 | 322.9 | 34.9 | 1.3 | +40.0 | 88.6 | 14.9 |
| KILLS COUNT | 2.3 | +112.7 | 193.6 | 101.0 | 2.5 | +112.7 | 211.0 | 122.8 |
| KILLS COUNT NEXT TURN | 7.4 | +222.5 | 458.4 | 144.9 | 6.1 | +117.9 | 102.3 | 124.2 |
| LONE CHARACTER SAFE SPOT | 0.1 | +0.5 | 8.1 | 0.0 | 0.2 | +7.8 | 9.8 | 6.4 |
| LONE WIZARD HOLDS BACK | 0.2 | +0.0 | 10.3 | 0.0 | 0.2 | +0.0 | 0.0 | 32.2 |
| LONE WIZARD KEPT IN | 0.4 | +23.1 | 0.0 | 0.0 | 0.3 | +29.4 | 0.0 | 0.0 |
| LONG SHOT | 0.6 | +2.8 | 40.9 | 39.6 | 0.8 | +6.9 | 33.7 | 10.8 |
| LOST CHARGE | 2.8 | -39.3 | 175.2 | 87.2 | 1.8 | -33.2 | 30.1 | 51.3 |
| LURE BY WHAT IT DRAWS | 0.1 | -20.2 | 0.0 | 0.0 | 0.1 | -7.9 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 1.3 | +106.2 | 153.3 | 19.3 | - | - | - | - |
| MANOEUVRE | 0.4 | +8.5 | 0.0 | 27.6 | 0.1 | +0.0 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.2 | +0.1 | 0.0 | 24.0 | - | - | - | - |
| MARCH CHECK | 0.8 | +28.8 | 0.0 | 24.0 | 0.4 | +5.9 | 0.0 | 0.0 |
| MARCH ODDS | 0.1 | +5.7 | 0.0 | 0.0 | 0.1 | +0.7 | 0.0 | 0.0 |
| MARCH OVER CASTS | 0.9 | +58.1 | 0.0 | 24.0 | 0.3 | +33.9 | 0.0 | 10.8 |
| MAX FOR POSITIONING | 5.2 | +175.4 | 0.0 | 132.8 | 4.6 | +238.0 | 0.0 | 97.3 |
| MISSILES IN THE MOVE | 3.6 | +57.5 | 0.0 | 66.3 | 2.7 | +46.3 | 0.0 | 98.4 |
| MISSILES NEXT TURN | 4.8 | +41.5 | 0.0 | 66.9 | 3.5 | +29.0 | 0.0 | 109.2 |
| MONSTER WIZARD ROAMS | 0.2 | +0.0 | 27.8 | 0.0 | 0.2 | +0.0 | 12.3 | 0.0 |
| MOVE AND CAST | 0.1 | +0.4 | 0.0 | 0.0 | 0.3 | +15.5 | 0.0 | 0.0 |
| MOVE SPELL OUT OF RANGE | - | - | - | - | 0.1 | -0.3 | 13.4 | 0.0 |
| MOVE SPELL SPOT | 0.4 | +0.0 | 0.0 | 19.3 | 0.1 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE | 4.6 | +263.6 | 326.2 | 60.2 | 2.4 | +162.1 | 29.2 | 26.8 |
| MOVES UNITS SPELL | 0.1 | +0.4 | 0.0 | 0.0 | 0.1 | +0.5 | 0.0 | 0.0 |
| NEEDED THERE | - | - | - | - | 0.2 | +13.9 | 23.9 | 0.0 |
| NO CHARGE WHY | 4.6 | +0.0 | 308.4 | 95.7 | 3.1 | +0.0 | 122.4 | 124.6 |
| NOT NEEDED | 0.7 | -32.2 | 103.6 | 11.4 | 0.6 | -21.4 | 85.1 | 0.0 |
| NOT TURNED | 5.9 | +42.0 | 0.0 | 133.0 | 7.6 | +88.4 | 0.0 | 152.0 |
| NOT WORTH A CAST | 0.7 | -0.4 | 0.0 | 0.0 | 0.5 | -0.2 | 0.0 | 0.0 |
| OFF BEST | 15.4 | -613.7 | 0.0 | 322.6 | 14.1 | -784.6 | 9.7 | 135.6 |
| OPENS A LANE | 0.1 | +0.2 | 1.9 | 0.0 | - | - | - | - |
| OPENS UP | 0.3 | +22.1 | 30.7 | 0.0 | 0.1 | +3.3 | 5.4 | 0.0 |
| OVERRUNS AWAY | 0.4 | +5.3 | 31.7 | 5.1 | 0.3 | +1.5 | 32.6 | 3.1 |
| PATHS CROSS | 2.8 | +199.8 | 0.0 | 24.1 | 3.3 | +212.1 | 0.0 | 20.4 |
| PERIAPT WORTH | 0.1 | +13.5 | 0.0 | 0.0 | 0.1 | +6.8 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.1 | -1.0 | 0.0 | 0.0 | 0.2 | -0.8 | 0.0 | 11.2 |
| PLAN RESULT | 40.4 | +1487.8 | 1748.9 | 996.4 | 40.8 | +1217.1 | 1761.1 | 1129.3 |
| PURSUES BIG PREY | 0.2 | -7.9 | 0.0 | 0.0 | 0.1 | -1.0 | 0.0 | 0.0 |
| PURSUES ON | - | - | - | - | 0.1 | +2.3 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE | - | - | - | - | 0.1 | +26.4 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE NEXT TURN | 0.1 | +7.8 | 0.0 | 0.0 | 0.3 | +22.2 | 0.0 | 0.0 |
| RANDOM MOVE BY FIGURES | 1.9 | +29.9 | 0.0 | 39.4 | 2.3 | +29.0 | 0.0 | 123.3 |
| RANDOM MOVER NO PROMISE | 0.8 | -37.7 | 11.9 | 0.0 | 0.2 | -3.9 | 0.0 | 17.5 |
| REDIRECT BY WHAT IT STOPS | 0.2 | +6.3 | 0.0 | 0.0 | 1.0 | -12.4 | 0.0 | 2.5 |
| REDIRECT COUNTER | 3.4 | +155.7 | 0.0 | 72.6 | 4.7 | +460.2 | 0.0 | 71.0 |
| REDIRECT WEIGHED | 0.4 | +1.4 | 3.6 | 3.5 | 0.3 | +8.5 | 7.4 | 21.8 |
| REFUSING RETIRES | 0.4 | +0.0 | 0.0 | 12.3 | 0.3 | +0.0 | 0.0 | 21.8 |
| RESERVE FALL BACK | 0.7 | +31.0 | 0.0 | 4.0 | 0.8 | +20.9 | 0.0 | 3.7 |
| RESTRAINS TO SHOOT | 0.1 | +3.9 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | 3.0 | +172.6 | 335.0 | 121.4 | 2.8 | +68.2 | 343.3 | 124.9 |
| SAFER THAN THE JOB | 0.9 | +65.7 | 0.0 | 10.3 | 0.6 | +40.0 | 0.0 | 47.8 |
| SCOUT SPOT | 0.4 | +0.7 | 0.0 | 1.9 | 0.2 | +0.0 | 0.0 | 0.0 |
| SCOUT WAITS | 0.6 | +0.0 | 0.0 | 1.9 | 0.2 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.3 | -11.1 | 0.0 | 1.9 | 0.4 | -27.5 | 0.0 | 3.1 |
| SEARCH SPOT | 2.9 | +104.1 | 0.0 | 35.4 | 2.9 | +142.3 | 0.0 | 50.1 |
| SECOND HUNTER | - | - | - | - | 0.1 | -1.7 | 9.2 | 0.0 |
| SELF MOVE SPELL | 0.3 | +112.3 | 0.0 | 0.0 | 0.3 | +16.7 | 0.0 | 72.4 |
| SET UP TOGETHER | 1.6 | +122.1 | 187.5 | 31.9 | 0.4 | +34.6 | 0.0 | 0.0 |
| SET-UP ANY TARGET | 0.3 | +69.1 | 0.0 | 22.5 | - | - | - | - |
| SET-UP SPOT | - | - | - | - | 5.1 | +118.1 | 14.9 | 107.1 |
| SHOOTER COUNTED ONCE | - | - | - | - | 0.1 | -0.0 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.3 | +0.8 | 0.0 | 0.0 | 0.1 | +0.1 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.1 | +22.5 | 8.1 | 3.6 | 1.1 | +40.3 | 86.1 | 17.1 |
| SHOT REPLANNED | 0.2 | +0.0 | 25.9 | 0.0 | 0.1 | +0.0 | 15.3 | 0.0 |
| SHOTS IN THE MOVE | 11.1 | +260.7 | 0.0 | 172.6 | 6.9 | +121.8 | 0.0 | 47.7 |
| SPELL SETS UP CHARGE | 0.3 | +69.1 | 0.0 | 22.5 | - | - | - | - |
| SPELL WORTH | 1.9 | +38.0 | 175.5 | 163.8 | 2.3 | +24.3 | 60.0 | 60.0 |
| SPELLS IN THE FIGHT | 0.8 | -6.6 | 174.9 | 52.2 | 0.7 | -18.4 | 103.3 | 77.2 |
| STABLE ROLE | 9.9 | +0.0 | 502.0 | 146.4 | 11.6 | +0.0 | 449.7 | 217.2 |
| STANDS TO CAST | 0.1 | +1.1 | 0.0 | 0.0 | - | - | - | - |
| STOPS | - | - | - | - | 0.1 | +8.4 | 18.3 | 0.0 |
| STOPS SHORT OF THE FLANK | 0.6 | +14.3 | 0.0 | 5.1 | 0.4 | +12.6 | 0.0 | 23.9 |
| STUCK PIVOT | 0.3 | +0.0 | 0.0 | 8.1 | 0.4 | +0.0 | 0.0 | 19.7 |
| SUPPORT NARROWED | 6.2 | -51.4 | 487.5 | 67.7 | 8.2 | -74.2 | 528.2 | 127.0 |
| SUPPORTS | 3.9 | +51.4 | 220.4 | 39.4 | 6.2 | +74.2 | 310.7 | 88.5 |
| SURE CHARGE BEATS ADVANCE | 0.1 | -1.4 | 10.6 | 0.0 | 0.1 | -4.9 | 6.8 | 0.0 |
| SURE REACH TOGETHER | 0.3 | +2.1 | 0.0 | 19.3 | 0.2 | -3.6 | 0.0 | 6.9 |
| THROUGH LINE OF FIRE | 0.2 | +1.0 | 0.0 | 0.0 | 0.3 | +8.6 | 0.0 | 6.9 |
| TURN WORTH | 0.3 | -23.7 | 21.8 | 7.8 | 0.2 | -12.4 | 0.0 | 10.8 |
| TWO OR MORE ARRIVE | 0.7 | +2.1 | 159.0 | 0.0 | - | - | - | - |
| WAIT AFTER COSTS | 9.0 | -355.2 | 517.4 | 131.7 | 5.2 | -232.8 | 85.0 | 88.4 |
| WALKS TO THE FIGHT | 1.7 | +27.4 | 51.2 | 5.0 | 1.1 | +17.6 | 0.0 | 14.9 |
| WAR ENGINE JOBS | 0.6 | +0.0 | 0.0 | 8.1 | 0.3 | +0.0 | 11.7 | 24.2 |
| WEARS DOWN | 1.1 | +44.1 | 127.5 | 27.9 | 1.2 | +37.1 | 162.5 | 7.9 |
| WHO HITS BACK | 0.6 | +23.2 | 0.0 | 2.5 | 0.2 | +13.2 | 0.0 | 0.0 |
| WHOLE FIGHT | 0.5 | +15.1 | 126.7 | 4.6 | 0.4 | +33.6 | 137.8 | 0.0 |
| WHOLE FIGHT GAIN | 0.5 | +44.1 | 37.2 | 2.2 | 1.2 | +66.2 | 139.2 | 6.6 |
| WIDER SPREAD | 3.4 | -9.5 | 382.2 | 88.9 | 4.0 | -1.5 | 468.5 | 108.4 |

### Rule changes: su-h2h-opp-e45904b-p4b

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 532 | 532 | 532 | 29.56 | -25168 | -47.3 |
| BEST FIRST | 186 | 186 | 186 | 10.33 | +6308 | +33.9 |
| PATHS CROSS | 110 | 110 | 110 | 6.11 | +7415 | +67.4 |
| SEARCH SPOT | 105 | 105 | 104 | 5.78 | +4467 | +42.9 |
| COUNTER-CHARGE COVER | 291 | 173 | 88 | 4.89 | +6215 | +70.6 |
| MOVE TO CHARGE | 125 | 125 | 79 | 4.39 | +2474 | +31.3 |
| SUPPORTS | 182 | 182 | 71 | 3.94 | +735 | +10.4 |
| KILLS COUNT NEXT TURN | 243 | 243 | 70 | 3.89 | +1192 | +17.0 |
| FACES THE THREAT | 58 | 58 | 58 | 3.22 | +4254 | +73.4 |
| FALLBACK BY WORTH | 234 | 234 | 51 | 2.83 | +2512 | +49.2 |
| SET-UP SPOT | 92 | 92 | 49 | 2.72 | +2085 | +42.5 |
| RANDOM MOVE BY FIGURES | 76 | 76 | 43 | 2.39 | +1060 | +24.7 |
| SHOTS IN THE MOVE | 325 | 210 | 31 | 1.72 | +617 | +19.9 |
| WAIT AFTER COSTS | 255 | 255 | 31 | 1.72 | +489 | +15.8 |
| WALKS TO THE FIGHT | 50 | 50 | 31 | 1.72 | +302 | +9.8 |
| FOLLOW UP WEIGHED | 30 | 30 | 30 | 1.67 | +4445 | +148.2 |
| MAX FOR POSITIONING | 177 | 114 | 28 | 1.56 | +334 | +11.9 |
| HOLDS AMBUSHERS | 27 | 27 | 27 | 1.50 | +0 | +0.0 |
| SAFER THAN THE JOB | 27 | 27 | 27 | 1.50 | +1903 | +70.5 |
| REDIRECT COUNTER | 146 | 87 | 26 | 1.44 | +1681 | +64.6 |
| RESERVE FALL BACK | 26 | 26 | 26 | 1.44 | +933 | +35.9 |
| ADVANCE LANE KEPT | 25 | 25 | 25 | 1.39 | +0 | +0.0 |
| RISK BY ARC | 104 | 100 | 23 | 1.28 | +1113 | +48.4 |
| BEST OVERALL | 22 | 22 | 22 | 1.22 | +1379 | +62.7 |
| BEST FACING | 21 | 21 | 21 | 1.17 | +1454 | +69.2 |
| SET UP TOGETHER | 37 | 32 | 21 | 1.17 | +752 | +35.8 |
| BLOCKED WHEEL | 20 | 20 | 20 | 1.11 | +180 | +9.0 |
| CHARGE NOW WEIGHED | 20 | 20 | 20 | 1.11 | +1533 | +76.6 |
| KILLS COUNT | 86 | 85 | 19 | 1.06 | +883 | +46.5 |
| MARCH CHECK | 21 | 21 | 19 | 1.06 | +1025 | +53.9 |
| CHARGE NOW FIRST | 91 | 91 | 18 | 1.00 | -675 | -37.5 |
| STOPS SHORT OF THE FLANK | 18 | 18 | 18 | 1.00 | +485 | +26.9 |
| KEEPS ITS TARGET | 73 | 71 | 17 | 0.94 | +346 | +20.4 |
| COMBAT PIVOT | 16 | 16 | 16 | 0.89 | +0 | +0.0 |
| WHOLE FIGHT GAIN | 31 | 28 | 16 | 0.89 | +721 | +45.1 |
| SCOUT WAITS | 14 | 14 | 14 | 0.78 | +0 | +0.0 |
| SHOOTS FROM THE BEST SPOT | 39 | 39 | 14 | 0.78 | +492 | +35.1 |
| WHO HITS BACK | 14 | 14 | 14 | 0.78 | +489 | +34.9 |
| HONEST WORTH | 332 | 329 | 13 | 0.72 | +115 | +8.9 |
| REDIRECT WEIGHED | 13 | 13 | 13 | 0.72 | +566 | +43.5 |
| BEST PREY | 35 | 35 | 12 | 0.67 | +229 | +19.1 |
| BIG CHARACTER SAFETY | 12 | 12 | 12 | 0.67 | -16 | -1.3 |
| INVITES THE FIGHT | 59 | 59 | 12 | 0.67 | +75 | +6.3 |
| LONE WIZARD KEPT IN | 12 | 12 | 12 | 0.67 | +944 | +78.7 |
| STUCK PIVOT | 12 | 12 | 12 | 0.67 | +0 | +0.0 |
| MAKE SURE TOGETHER | 23 | 18 | 11 | 0.61 | +278 | +25.3 |
| MISSILES IN THE MOVE | 114 | 75 | 11 | 0.61 | +275 | +25.0 |
| SUPPORT NARROWED | 259 | 259 | 10 | 0.56 | -99 | -9.9 |
| CANNON SIGHT KEPT | 9 | 9 | 9 | 0.50 | +0 | +0.0 |
| THROUGH LINE OF FIRE | 9 | 9 | 9 | 0.50 | +173 | +19.2 |
| CAST JOB | 15 | 15 | 8 | 0.44 | +128 | +15.9 |
| CASTS FROM BEHIND | 8 | 8 | 8 | 0.44 | +0 | +0.0 |
| FRIENDS SHOTS CHECKED | 8 | 8 | 8 | 0.44 | +528 | +65.9 |
| JOINT AS ONE | 34 | 34 | 8 | 0.44 | -110 | -13.7 |
| MANOEUVRE | 8 | 8 | 8 | 0.44 | +153 | +19.2 |
| CHAFF PASSED | 7 | 7 | 7 | 0.39 | -7 | -1.0 |
| MOVE AND CAST | 7 | 7 | 7 | 0.39 | +287 | +41.1 |
| WAR ENGINE JOBS | 16 | 16 | 7 | 0.39 | -312 | -44.6 |
| CASTER AWAY FROM SCREEN | 6 | 6 | 6 | 0.33 | +0 | +0.0 |
| CHARGE BAND | 6 | 6 | 6 | 0.33 | +0 | +0.0 |
| PIVOT GUARDS FLANK | 6 | 6 | 6 | 0.33 | -32 | -5.3 |
| RAIDS THE BAGGAGE NEXT TURN | 7 | 7 | 6 | 0.33 | +78 | +12.9 |
| SHOOTERS IN TWO RANKS | 6 | 6 | 6 | 0.33 | +16 | +2.7 |
| SHOT REPLANNED | 6 | 6 | 6 | 0.33 | +0 | +0.0 |
| WEARS DOWN | 41 | 39 | 6 | 0.33 | +195 | +32.5 |
| WIDER SPREAD | 133 | 127 | 6 | 0.33 | +24 | +4.0 |
| BACKUP TARGETS | 40 | 25 | 5 | 0.28 | +25 | +5.0 |
| BLOCKED CHARGE SKIPPED | 5 | 5 | 5 | 0.28 | +0 | +0.0 |
| HUNT IN PAIRS | 23 | 14 | 5 | 0.28 | +227 | +45.3 |
| OPENS UP | 7 | 7 | 5 | 0.28 | +136 | +27.2 |
| LONG SHOT | 25 | 25 | 4 | 0.22 | +67 | +16.7 |
| PURSUES BIG PREY | 4 | 4 | 4 | 0.22 | -160 | -40.1 |
| MOVES UNITS SPELL | 3 | 3 | 3 | 0.17 | +16 | +5.3 |
| NEEDED THERE | 3 | 3 | 3 | 0.17 | +0 | +0.0 |
| PERIAPT WORTH | 3 | 3 | 3 | 0.17 | +365 | +121.6 |
| REFUSING RETIRES | 12 | 12 | 3 | 0.17 | -1 | -0.3 |
| SURE CHARGE BEATS ADVANCE | 3 | 3 | 3 | 0.17 | -112 | -37.3 |
| SURE REACH TOGETHER | 10 | 10 | 3 | 0.17 | +6 | +2.0 |
| ARTILLERY RE-ROLL WEIGHED | 2 | 2 | 2 | 0.11 | +0 | +0.0 |
| BEST PRIZE | 2 | 2 | 2 | 0.11 | -30 | -14.8 |
| CANNON PLANNED TARGET | 39 | 39 | 2 | 0.11 | -56 | -28.1 |
| ELIXIR WORTH | 2 | 2 | 2 | 0.11 | +46 | +23.2 |
| FIRE AND FLEE | 2 | 2 | 2 | 0.11 | +40 | +20.1 |
| MARCH ODDS | 2 | 2 | 2 | 0.11 | +8 | +4.0 |
| RAIDS THE BAGGAGE | 2 | 2 | 2 | 0.11 | +364 | +182.0 |
| REDIRECT BY WHAT IT STOPS | 22 | 22 | 2 | 0.11 | +72 | +36.1 |
| RESTRAINS TO SHOOT | 2 | 2 | 2 | 0.11 | +71 | +35.4 |
| WHOLE FIGHT | 17 | 16 | 2 | 0.11 | +75 | +37.4 |
| BOMBING RUN | 1 | 1 | 1 | 0.06 | +29 | +28.9 |
| CARRIES OUT CLOSE-IN | 9 | 9 | 1 | 0.06 | -12 | -11.5 |
| CARRIES OUT COUNTER | 4 | 4 | 1 | 0.06 | -165 | -165.2 |
| CARRIES OUT SET-UP | 5 | 5 | 1 | 0.06 | -46 | -46.1 |
| CASTING BLOCK | 3 | 3 | 1 | 0.06 | +20 | +19.7 |
| CHARGER SLAIN LOST | 21 | 21 | 1 | 0.06 | +3 | +3.4 |
| DEFENSIVE FLOOR | 2 | 2 | 1 | 0.06 | +36 | +36.2 |
| HILL BY ITS CHANCE | 16 | 16 | 1 | 0.06 | +9 | +9.4 |
| LONE WIZARD HOLDS BACK | 7 | 7 | 1 | 0.06 | -121 | -121.2 |
| LOST CHARGE | 83 | 83 | 1 | 0.06 | +67 | +67.2 |
| MISSILES NEXT TURN | 149 | 95 | 1 | 0.06 | +8 | +7.6 |
| OVERRUNS AWAY | 13 | 13 | 1 | 0.06 | +16 | +15.6 |
| PURSUES ON | 1 | 1 | 1 | 0.06 | +42 | +41.7 |
| STANDS TO CAST | 1 | 1 | 1 | 0.06 | -2 | -2.4 |
| BLOWS WHERE AIMED | 10 | 9 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 9 | 9 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 18 | trace | - | - | - | - |
| CHARIOT WIZARD CAREFUL | 7 | 7 | 0 | 0.00 | - | - |
| CHEAP HELPER | 1 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 9 | not checked | - | - | - | - |
| DEFENSIVE ARMY | 1 | 1 | 0 | 0.00 | - | - |
| EDGE GIVE GROUND | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT LIFT | 6 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 233 | not checked | - | - | - | - |
| GIVES UP ITS SCREEN | 1 | 1 | 0 | 0.00 | - | - |
| HELPER ALREADY ASKED | 1 | not checked | - | - | - | - |
| HELPER UNSEEN | 20 | 18 | 0 | 0.00 | - | - |
| HUNT ADVANCE | 1 | 1 | 0 | 0.00 | - | - |
| HUNT DROPPED | 2 | trace | - | - | - | - |
| HUNT RESULT | 3 | trace | - | - | - | - |
| HUNT THE GUNS | 3 | trace | - | - | - | - |
| JOINT CHARGE PLAN | 4 | 4 | 0 | 0.00 | - | - |
| JOINT KNOWS CHALLENGE | 3 | 3 | 0 | 0.00 | - | - |
| KEEPS ITS PREY | 3 | 3 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 6 | not checked | - | - | - | - |
| LURE BY WHAT IT DRAWS | 3 | 3 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 3 | trace | - | - | - | - |
| MARCH OVER CASTS | 21 | 21 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 6 | 6 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 2 | trace | - | - | - | - |
| MOVE SPELL SPOT | 9 | not checked | - | - | - | - |
| NO CHARGE WHY | 138 | not checked | - | - | - | - |
| NOT NEEDED | 23 | 23 | 0 | 0.00 | - | - |
| NOT TURNED | 243 | 243 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 21 | not checked | - | - | - | - |
| OPENS A LANE | 1 | not checked | - | - | - | - |
| PLAN RESULT | 1463 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 18 | 18 | 0 | 0.00 | - | - |
| SCOUT SPOT | 12 | 12 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 13 | 13 | 0 | 0.00 | - | - |
| SECOND HUNTER | 1 | 1 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 12 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 6 | not checked | - | - | - | - |
| SHOOTER COUNTED ONCE | 1 | 1 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 6 | not checked | - | - | - | - |
| SPELL WORTH | 76 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 26 | 26 | 0 | 0.00 | - | - |
| STABLE ROLE | 387 | 387 | 0 | 0.00 | - | - |
| STOPS | 2 | 2 | 0 | 0.00 | - | - |
| TURN WORTH | 9 | 8 | 0 | 0.00 | - | - |
| TWO OR MORE ARRIVE | 12 | 12 | 0 | 0.00 | - | - |

### Off best figure: su-h2h-opp-e45904b-p4b

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 13.44 | 11.39 | 49.1 |
| FALLBACK | gate | 1.00 | 0.94 | 38.7 |
| TURN GATE | gate | 0.44 | 0.83 | 38.5 |
| CHARGE NOW FIRST | rule | 0.50 | 0.50 | 37.5 |
| SUPPORT NARROWED | rule | 0.28 | 0.28 | 9.9 |
| AFTERMATH BAND | gate | 0.28 | 0.22 | 2.3 |
| JOINT AS ONE | rule | - | 0.44 | 13.7 |
| NO REASON | gate | - | 0.39 | 24.6 |
| PATHS CROSS | rule | 0.28 | 0.11 | 11.9 |
| WAR ENGINE JOBS | rule | 0.33 | 0.06 | 44.6 |
| BIG CHARACTER SAFETY | rule | 0.22 | 0.11 | 7.1 |
| PIVOT GUARDS FLANK | rule | 0.11 | 0.22 | 5.3 |
| BLOCKED WHEEL | rule | 0.06 | 0.17 | 6.1 |
| LONE CHARACTER SAFE SPOT | gate | 0.06 | 0.17 | 84.0 |
| PURSUES BIG PREY | rule | 0.17 | 0.06 | 40.1 |
| CHAFF PASSED | rule | 0.06 | 0.11 | 2.3 |
| FIGHT ORDER BAND | gate | 0.11 | 0.06 | 3.5 |
| STOPS SHORT OF THE FLANK | rule | 0.17 | - | 3.4 |
| SUPPORT REQUEST | gate | 0.06 | 0.11 | 149.1 |
| SURE CHARGE BEATS ADVANCE | rule | 0.06 | 0.11 | 37.3 |
| BEST PRIZE | rule | 0.06 | 0.06 | 14.8 |
| SAFER THAN THE JOB | rule | 0.06 | 0.06 | 4.7 |
| SET-UP SPOT | rule | - | 0.11 | 21.7 |
| CANNON PLANNED TARGET | rule | 0.06 | - | 56.1 |
| CARRIES OUT CLOSE-IN | rule | - | 0.06 | 11.5 |
| CARRIES OUT COUNTER | rule | - | 0.06 | 165.2 |
| CARRIES OUT SET-UP | rule | 0.06 | - | 46.1 |
| FACES THE THREAT | rule | - | 0.06 | 23.0 |
| FOLLOW UP WEIGHED | rule | - | 0.06 | 2.0 |
| LONE WIZARD HOLDS BACK | rule | - | 0.06 | 121.2 |
| RULE SWITCHED OFF | gate | 0.06 | - | 1.2 |
| STANDS TO CAST | rule | 0.06 | - | 2.4 |

### Plans: su-h2h-opp-e45904b-p4b

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 14.4 | 12% | 327 | 395 | 121% |
| Mine | charge | 4.1 | 68% | 287 | 432 | 150% |
| Mine | close in | 6.4 | 37% | 342 | 284 | 83% |
| Mine | hold | 5.0 | 37% | 288 | 0 | 0% |
| Mine | join | 0.2 | 100% | 8 | 0 | 0% |
| Mine | shoot | 5.9 | 42% | 110 | 377 | 345% |
| Mine | support | 4.4 | 92% | 53 | 0 | 0% |
| Opponent | advance | 15.2 | 16% | 419 | 416 | 99% |
| Opponent | charge | 4.7 | 60% | 295 | 517 | 175% |
| Opponent | close in | 4.4 | 24% | 148 | 101 | 69% |
| Opponent | hold | 4.5 | 28% | 333 | 0 | 0% |
| Opponent | join | 1.1 | 90% | 44 | 0 | 0% |
| Opponent | shoot | 3.6 | 58% | 62 | 183 | 296% |
| Opponent | support | 7.3 | 90% | 67 | 0 | 0% |

### Packages: hunt the guns, su-h2h-opp-e45904b-p4b

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Opponent | 0.2 | 3 | 0 | 33% | 33% | 0% | 2.0 | 350 | 83 | 33% | 44 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 100 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 26 |
| Tomb Kings of Khemri | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Vampire Counts | 0.3 | 2 | 0 | 50% | 50% | 0% | 2.0 | 311 | 124 | 50% | 0 |
| Warriors of Chaos | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 429 | 0 | 0% | 34 |
| Wood Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |

### Battle groups: su-h2h-opp-e45904b-p4b

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 7.9 | 27% | 53% | 21% | 38% | 40% | 7% | 10% | 43% | 0% |
| Mine | REDIRECT COUNTER | 3.4 | 39% | 54% | 4% | 100% | 17% | 0% | 4% | 70% | 9% |
| Opponent | COUNTER-CHARGE COVER | 8.3 | 19% | 69% | 17% | 60% | 29% | 21% | 12% | 38% | 0% |
| Opponent | REDIRECT COUNTER | 4.7 | 21% | 67% | 28% | 0% | 23% | 0% | 8% | 69% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: su-h2h-opp-e45904b-p4b

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 4 | 41 (4) | 41 | 0 | 62 | 0% | 2.8 | - | 40 (3) | - | - | 40 (3) |
| Mine | Chaff | 27 | 13 (27) | 8 | 4 | 48 | 19% | 2.6 | 16 (11) | 0 (5) | 15 (11) | 15 (19) | 7 (8) |
| Mine | Character | 39 | 62 (39) | 62 | 0 | 41 | 0% | 2.3 | 33 (14) | 82 (20) | 255 (1) | 49 (19) | 82 (16) |
| Mine | Clean-up | 8 | 60 (8) | 37 | 23 | 4 | 25% | 2.7 | 0 (2) | 77 (4) | 67 (2) | 62 (3) | 59 (5) |
| Mine | Early | 1 | 0 (1) | 0 | 0 | 100 | 0% | 3.0 | - | 0 (1) | - | - | 0 (1) |
| Mine | Fast | 2 | 0 (2) | 0 | 0 | 0 | 50% | 4.0 | 0 (1) | 0 (1) | - | 0 (1) | 0 (1) |
| Mine | Fast Hammer | 20 | 27 (20) | 17 | 10 | 42 | 15% | 3.0 | 18 (12) | 59 (5) | 13 (3) | 31 (13) | 17 (7) |
| Mine | Fragile | 4 | 29 (4) | 29 | 0 | 27 | 25% | 3.7 | 0 (2) | 54 (2) | - | 108 (1) | 0 (3) |
| Mine | Hammer | 28 | 39 (28) | 29 | 10 | 43 | 11% | 2.8 | 7 (9) | 47 (18) | 176 (1) | 61 (17) | 11 (11) |
| Mine | Holder | 18 | 149 (18) | 14 | 135 | 10 | 39% | 2.7 | 53 (7) | 267 (10) | 0 (1) | 187 (11) | 104 (7) |
| Mine | Shooter | 15 | 33 (15) | 14 | 19 | 43 | 0% | 1.5 | 0 (5) | 56 (9) | 0 (1) | 31 (11) | 38 (4) |
| Mine | Support | 1 | 61 (1) | 61 | 0 | 0 | 0% | 6.0 | - | 61 (1) | - | - | 61 (1) |
| Mine | War machine | 10 | 70 (10) | 70 | 0 | 29 | 0% | 1.1 | - | 91 (8) | 20 (2) | 243 (1) | 59 (9) |
| Mine | Wizard | 6 | 0 (6) | 0 | 0 | 14 | 0% | 2.7 | 0 (3) | 0 (2) | - | 0 (3) | 0 (2) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Chaff | 37 | 21 (37) | 18 | 3 | 54 | 22% | 3.1 | 20 (16) | 19 (10) | 24 (11) | 18 (28) | 31 (9) |
| Opponent | Character | 52 | 53 (52) | 53 | 0 | 28 | 35% | 2.0 | 70 (24) | 38 (18) | 60 (2) | 64 (29) | 45 (15) |
| Opponent | Clean-up | 5 | 130 (5) | 74 | 56 | 17 | 40% | 2.7 | 0 (2) | 157 (3) | - | 218 (3) | 84 (2) |
| Opponent | Fast Hammer | 34 | 40 (34) | 17 | 23 | 43 | 26% | 2.9 | 25 (16) | 64 (14) | 34 (4) | 32 (22) | 55 (12) |
| Opponent | Fragile | 9 | 49 (9) | 49 | 0 | 58 | 11% | 1.6 | 191 (2) | 0 (4) | 34 (3) | 13 (8) | 323 (1) |
| Opponent | Hammer | 38 | 35 (38) | 25 | 10 | 54 | 21% | 3.2 | 12 (13) | 48 (20) | 8 (5) | 40 (26) | 24 (12) |
| Opponent | Holder | 18 | 26 (18) | 5 | 20 | 40 | 44% | 3.9 | 15 (7) | 31 (8) | 33 (3) | 50 (9) | 3 (9) |
| Opponent | Shooter | 12 | 36 (12) | 5 | 32 | 38 | 0% | 1.4 | 0 (3) | 42 (8) | 94 (1) | 9 (8) | 65 (4) |
| Opponent | Support | 3 | 0 (3) | 0 | 0 | 0 | 100% | - | 0 (1) | 0 (2) | - | - | 0 (3) |
| Opponent | Wizard | 14 | 7 (14) | 7 | 0 | 71 | 14% | 2.3 | 9 (7) | 0 (1) | 0 (2) | 7 (7) | 0 (3) |

### Charged fights: su-h2h-opp-e45904b-p4b

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Grand Cathay | 2 | 440 | 174 | 4.0 | 1.1 | 43 | 63 | -19 | 4 of 8 | 8 of 8 | +242 | -57 |
| Mine | High Elf Realms | 4 | 376 | 266 | 3.8 | 1.2 | 71 | 43 | +28 | 3 of 15 | 15 of 15 | +150 | -3 |
| Mine | Kingdom of Bretonnia | 1 | 130 | 1052 | 5.0 | 1.2 | 210 | 0 | +210 | 3 of 5 | 5 of 5 | +145 | +227 |
| Mine | Lizardmen | 1 | 55 | 1895 | 4.0 | 1.2 | 474 | 35 | +438 | 2 of 4 | 3 of 4 | +165 | +530 |
| Mine | Ogre Kingdoms | 2 | 0 | 180 | 5.0 | 1.2 | 36 | 23 | +13 | 4 of 10 | 4 of 10 | +28 | +10 |
| Mine | Skaven | 2 | 68 | 0 | 0.5 | 1.0 | 0 | 0 | +0 | 0 of 1 | 1 of 1 | - | +0 |
| Mine | Tomb Kings of Khemri | 2 | 98 | 697 | 3.0 | 1.7 | 232 | 0 | +232 | 1 of 6 | 6 of 6 | +301 | +96 |
| Mine | Vampire Counts | 2 | 108 | 504 | 4.5 | 1.2 | 112 | 4 | +108 | 2 of 9 | 9 of 9 | +118 | +104 |
| Mine | Warriors of Chaos | 2 | 0 | 210 | 5.0 | 1.0 | 42 | 52 | -10 | 4 of 10 | 8 of 10 | - | -10 |
| **Mine** | all armies | 18 | 173 | 419 | 3.8 | 1.2 | 111 | 31 | +80 | 23 of 68 | 59 of 68 | +178 | +55 |
| Opponent | High Elf Realms | 1 | 0 | 0 | 2.0 | 1.0 | 0 | 147 | -147 | 1 of 2 | 0 of 2 | - | -147 |
| Opponent | Orc & Goblin Tribes | 2 | 0 | 563 | 5.0 | 1.0 | 113 | 69 | +44 | 2 of 10 | 8 of 10 | - | +44 |
| Opponent | Skaven | 3 | 70 | 0 | 2.0 | 1.0 | 0 | 99 | -99 | 2 of 6 | 1 of 6 | - | -99 |
| Opponent | Tomb Kings of Khemri | 2 | 90 | 784 | 4.5 | 1.2 | 174 | 22 | +153 | 3 of 9 | 7 of 9 | +375 | +89 |
| Opponent | Vampire Counts | 4 | 0 | 458 | 4.5 | 1.3 | 102 | 3 | +98 | 11 of 18 | 10 of 18 | +194 | +79 |
| Opponent | Warriors of Chaos | 3 | 0 | 109 | 1.7 | 1.0 | 65 | 48 | +17 | 1 of 5 | 2 of 5 | - | +17 |
| Opponent | Wood Elf Realms | 3 | 11 | 906 | 6.7 | 1.1 | 136 | 8 | +127 | 7 of 20 | 16 of 20 | +203 | +114 |
| **Opponent** | all armies | 18 | 24 | 421 | 3.9 | 1.1 | 108 | 32 | +76 | 27 of 70 | 44 of 70 | +243 | +55 |

### Effective charges: su-h2h-opp-e45904b-p4b

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Grand Cathay | 8 | 0 | 0 | 2 (net -102) | 2 (net +0) | 2 (net +52) | 2 (net -27) | 0 | 25% (2 of 8) |
| Mine | High Elf Realms | 15 | 0 | 0 | 1 (net -589) | 6 (net +56) | 3 (net +108) | 5 (net +69) | 0 | 7% (1 of 15) |
| Mine | Kingdom of Bretonnia | 5 | 0 | 0 | 0 | 2 (net +184) | 1 (net +145) | 2 (net +270) | 0 | 0% (0 of 5) |
| Mine | Lizardmen | 4 | 1 (net -37) | 0 | 0 | 2 (net +210) | 0 | 0 | 1 | 0% (0 of 3) |
| Mine | Ogre Kingdoms | 10 | 1 (net +0) | 0 | 2 (net -114) | 2 (net +0) | 0 | 4 (net +90) | 1 | 22% (2 of 9) |
| Mine | Skaven | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +0) | 0 | 0% (0 of 1) |
| Mine | Tomb Kings of Khemri | 6 | 0 | 0 | 2 (net +530) | 3 (net +64) | 1 (net +144) | 0 | 0 | 33% (2 of 6) |
| Mine | Vampire Counts | 9 | 0 | 0 | 4 (net +138) | 1 (net +0) | 0 | 3 (net +77) | 1 | 50% (4 of 8) |
| Mine | Warriors of Chaos | 10 | 1 (net -30) | 0 | 4 (net -117) | 1 (net +285) | 2 (net +54) | 2 (net +0) | 0 | 40% (4 of 10) |
| Opponent | High Elf Realms | 2 | 1 (net -143) | 0 | 0 | 1 (net -151) | 0 | 0 | 0 | 0% (0 of 2) |
| Opponent | Orc & Goblin Tribes | 10 | 1 (net +0) | 0 | 0 | 2 (net +180) | 0 | 2 (net +208) | 5 | 0% (0 of 5) |
| Opponent | Skaven | 6 | 1 (net -35) | 1 (net +0) | 3 (net +0) | 1 (net -560) | 0 | 0 | 0 | 50% (3 of 6) |
| Opponent | Tomb Kings of Khemri | 9 | 1 (net +577) | 0 | 1 (net +55) | 2 (net +72) | 0 | 3 (net +185) | 2 | 14% (1 of 7) |
| Opponent | Vampire Counts | 18 | 5 (net +23) | 1 (net +0) | 6 (net +111) | 4 (net +248) | 1 (net +0) | 1 (net +0) | 0 | 33% (6 of 18) |
| Opponent | Warriors of Chaos | 5 | 0 | 1 (net +205) | 1 (net -70) | 0 | 1 (net +122) | 0 | 2 | 33% (1 of 3) |
| Opponent | Wood Elf Realms | 20 | 5 (net +11) | 0 | 3 (net +128) | 3 (net +291) | 2 (net +136) | 6 (net +154) | 1 | 16% (3 of 19) |

### Charged fights, damage counted: su-h2h-opp-e45904b-p4b

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 3 | 150 | 264 | -22 | 42 | 57 | -15 | -10.2 |
| Mine | Effective (55-75%) | 15 | 317 | 229 | +8 | 144 | 143 | +1 | +0.4 |
| Mine | 76-89% | 19 | 366 | 189 | +84 | 89 | 10 | +79 | +21.5 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 19 | 254 | 174 | +75 | 126 | 29 | +97 | +38.0 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 9 | 522 | 101 | +92 | 98 | 7 | +92 | +17.6 |
| Mine | No odds | 3 | 250 | 307 | +519 | 519 | 77 | +442 | +177.0 |
| Mine | All fights | 68 | 330 | 190 | +80 | 130 | 49 | +80 | +24.3 |
| Opponent | Long shot (under 50%) | 14 | 126 | 282 | +41 | 62 | 21 | +42 | +33.0 |
| Opponent | 50-54% | 3 | 88 | 119 | +68 | 74 | 7 | +66 | +75.3 |
| Opponent | Effective (55-75%) | 14 | 227 | 212 | +74 | 111 | 30 | +81 | +35.6 |
| Opponent | 76-89% | 13 | 342 | 239 | +128 | 210 | 79 | +131 | +38.4 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 12 | 307 | 167 | +158 | 174 | 25 | +149 | +48.6 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 4 | 428 | 86 | +98 | 132 | 24 | +108 | +25.2 |
| Opponent | No odds | 10 | 176 | 143 | -44 | 57 | 101 | -44 | -25.0 |
| Opponent | All fights | 70 | 240 | 202 | +76 | 122 | 45 | +77 | +32.2 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| su-h2h-opp-e45904b-p4b | move | 222 | 56 (25%) | 35 (16%) | 39 (18%) | 127 (57%) |
| su-h2h-opp-e45904b-p4b | objective | 198 | 32 (16%) | 21 (11%) | 40 (20%) | 126 (64%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L2527, L2634 |
| Charmed Shield | Opponent | L1126, L1427, L2227, L2527, L2634, L3234 |
| Clockwork Compass | Mine | L1220 |
| Elixir of Power | Mine | L1126 |
| Elixir of Power | Opponent | L1719, L1819 |
| Fistful of Laurels | Mine | L1819, L1835 |
| Invocation of Nehek | Mine | L2527 |
| Invocation of Nehek | Opponent | L1427, L2227, L2527 |
| Opal Amulet | Mine | L1427 |
| Opal Amulet | Opponent | L1314 |
| Periapt of Soul Exchange | Mine | L2021, L2123 |
| Periapt of Soul Exchange | Opponent | L1220, L1621, L2021 |
| Ring of Doom | Mine | L1126, L1220, L1523 |
| Ring of Doom | Opponent | L1331, L2331 |
| Ring of Jet | Mine | L1126, L1220 |
| Standard of the Fell Warrior | Mine | L1314, L1331 |
| Storm Daemon (Renegade 2.0) | Mine | L2123 |
| Storm Daemon (Renegade 2.0) | Opponent | L1621, L2021 |

# Doctrine scorecard: su-h2h-opp-e45904b-p3

### Scorecard: su-h2h-opp-e45904b-p3

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0110 | 2 | 1 | Mine | - | - | 4 | 0 | 2 | 0 | 0 | 0 | 0 |
| L0110 | 2 | 1 | Opponent | - | - | 2 | 3 | 1 | 0 | 0 | 0 | 330 |
| L0126 | 6 | 1 | Mine | no | 5 | 3 | 1 | 0 | 0 | 0 | 0 | 322 |
| L0126 | 6 | 1 | Opponent | no | 16 | 3 | 3 | 2 | 0 | 0 | 0 | 0 |
| L0210 | 6 | 1 | Mine | no | 3 | 3 | 1 | 3 | 0 | 0 | 0 | 0 |
| L0210 | 6 | 1 | Opponent | no | 10 | 4 | 1 | 0 | 0 | 0 | 0 | 330 |
| L0226 | 4 | 1 | Mine | no | 0 | 3 | 3 | 3 | 0 | 0 | 0 | 170 |
| L0226 | 4 | 1 | Opponent | no | 4 | 2 | 1 | 2 | 0 | 0 | 0 | 0 |
| L0311 | 5 | 1 | Mine | no | - | 3 | 0 | 1 | 0 | 0 | 0 | 675 |
| L0311 | 5 | 1 | Opponent | yes | - | 2 | 1 | 0 | 0 | 0 | 0 | 427 |
| L0327 | 3 | 1 | Mine | no | 0 | 3 | 2 | 0 | 0 | 0 | 0 | 590 |
| L0327 | 3 | 1 | Opponent | no | 2 | 2 | 0 | 4 | 0 | 0 | 0 | 0 |
| L0413 | 5 | 1 | Mine | yes | - | 2 | 1 | 3 | 0 | 0 | 0 | 0 |
| L0413 | 5 | 1 | Opponent | yes | - | 4 | 1 | 2 | 0 | 0 | 0 | 479 |
| L0429 | 3 | 1 | Mine | yes | 4 | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L0429 | 3 | 1 | Opponent | no | 2 | 2 | 2 | 2 | 0 | 0 | 0 | 170 |
| L0516 | 6 | 1 | Mine | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 548 |
| L0516 | 6 | 1 | Opponent | no | 10 | 2 | 2 | 1 | 1 | 0 | 0 | 200 |
| L0533 | 5 | 1 | Mine | no | - | - | 0 | 1 | 0 | 0 | 0 | 548 |
| L0533 | 5 | 1 | Opponent | yes | - | 2 | 3 | 3 | 0 | 0 | 0 | 0 |
| L0620 | 2 | 1 | Mine | - | - | 2 | 3 | 1 | 0 | 0 | 0 | 801 |
| L0620 | 2 | 1 | Opponent | - | - | - | 0 | 5 | 0 | 0 | 0 | 210 |
| L0709 | 1 | 1 | Mine | yes | 3 | 4 | 2 | 0 | 1 | 0 | 0 | 420 |
| L0709 | 1 | 1 | Opponent | no | 0 | 2 | 3 | 1 | 0 | 0 | 0 | 420 |
| L0725 | 5 | 1 | Mine | yes | - | 3 | 3 | 1 | 0 | 0 | 0 | 613 |
| L0725 | 5 | 1 | Opponent | yes | - | 2 | 5 | 0 | 0 | 0 | 0 | 0 |
| L0815 | 5 | 1 | Mine | no | - | - | 0 | 1 | 0 | 0 | 0 | 617 |
| L0815 | 5 | 1 | Opponent | yes | - | 2 | 5 | 2 | 1 | 0 | 0 | 115 |
| L0831 | 3 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 807 |
| L0831 | 3 | 1 | Opponent | no | 0 | - | 0 | 4 | 1 | 0 | 0 | 170 |
| L0922 | 4 | 1 | Mine | no | 0 | - | 0 | 0 | 0 | 0 | 0 | 700 |
| L0922 | 4 | 1 | Opponent | no | 0 | 2 | 5 | 2 | 1 | 0 | 0 | 55 |
| L1013 | 5 | 1 | Mine | yes | - | 2 | 2 | 1 | 2 | 0 | 0 | 330 |
| L1013 | 5 | 1 | Opponent | no | - | 1 | 1 | 3 | 0 | 0 | 0 | 302 |
| L1030 | 4 | 1 | Mine | no | 5 | 2 | 5 | 0 | 0 | 0 | 0 | 501 |
| L1030 | 4 | 1 | Opponent | no | 0 | 2 | 4 | 3 | 1 | 0 | 0 | 0 |
| L1122 | 6 | 1 | Mine | no | 0 | 2 | 3 | 1 | 0 | 0 | 0 | 330 |
| L1122 | 6 | 1 | Opponent | no | 0 | 2 | 4 | 1 | 0 | 0 | 0 | 127 |
| L1216 | 4 | 1 | Mine | no | 0 | 2 | 4 | 0 | 1 | 0 | 0 | 330 |
| L1216 | 4 | 1 | Opponent | no | 0 | 2 | 3 | 1 | 0 | 0 | 0 | 200 |
| L1232 | 2 | 1 | Mine | - | - | 3 | 2 | 0 | 2 | 0 | 0 | 330 |
| L1232 | 2 | 1 | Opponent | - | - | 3 | 3 | 0 | 0 | 0 | 0 | 0 |
| L1327 | 1 | 1 | Mine | no | 3 | 4 | 4 | 0 | 0 | 0 | 0 | 140 |
| L1327 | 1 | 1 | Opponent | no | 3 | 1 | 4 | 3 | 0 | 0 | 0 | 0 |
| L1422 | 6 | 1 | Mine | no | 10 | 2 | 3 | 0 | 1 | 0 | 0 | 0 |
| L1422 | 6 | 1 | Opponent | no | 0 | 2 | 2 | 0 | 1 | 0 | 0 | 127 |
| L1519 | 1 | 1 | Mine | no | 1 | 2 | 4 | 0 | 0 | 0 | 0 | 0 |
| L1519 | 1 | 1 | Opponent | no | 0 | 2 | 5 | 2 | 0 | 0 | 0 | 0 |
| L1535 | 5 | 1 | Mine | yes | - | 3 | 3 | 2 | 0 | 0 | 0 | 0 |
| L1535 | 5 | 1 | Opponent | yes | - | 2 | 1 | 1 | 0 | 0 | 0 | 0 |
| L1633 | 1 | 1 | Mine | no | 6 | 2 | 2 | 0 | 1 | 0 | 0 | 200 |
| L1633 | 1 | 1 | Opponent | no | 1 | 1 | 3 | 3 | 0 | 0 | 0 | 549 |
| L1731 | 3 | 1 | Mine | no | 2 | 2 | 4 | 0 | 0 | 0 | 0 | 0 |
| L1731 | 3 | 1 | Opponent | no | 2 | 2 | 1 | 2 | 1 | 0 | 0 | 340 |
| L1831 | 1 | 1 | Mine | no | 6 | - | 2 | 1 | 0 | 0 | 0 | 0 |
| L1831 | 1 | 1 | Opponent | no | 1 | 6 | 0 | 0 | 3 | 0 | 0 | 0 |
| L1932 | 6 | 1 | Mine | no | 4 | 2 | 2 | 0 | 0 | 0 | 0 | 0 |
| L1932 | 6 | 1 | Opponent | no | 2 | 2 | 6 | 1 | 0 | 0 | 0 | 170 |
| L2033 | 5 | 1 | Mine | yes | - | 6 | 0 | 5 | 1 | 0 | 0 | 210 |
| L2033 | 5 | 1 | Opponent | no | - | - | 0 | 4 | 1 | 0 | 0 | 234 |
| L2223 | 3 | 1 | Mine | yes | 8 | 1 | 5 | 0 | 0 | 0 | 0 | 72 |
| L2223 | 3 | 1 | Opponent | no | 0 | 2 | 5 | 1 | 2 | 0 | 0 | 0 |
| L2327 | 5 | 1 | Mine | yes | - | 2 | 1 | 2 | 0 | 0 | 0 | 257 |
| L2327 | 5 | 1 | Opponent | yes | - | 2 | 6 | 4 | 1 | 0 | 0 | 50 |
| L2433 | 3 | 1 | Mine | no | 0 | 5 | 2 | 1 | 0 | 0 | 0 | 0 |
| L2433 | 3 | 1 | Opponent | no | 0 | 2 | 7 | 1 | 1 | 0 | 0 | 0 |
| L2630 | 2 | 1 | Mine | - | - | 2 | 6 | 1 | 0 | 0 | 0 | 0 |
| L2630 | 2 | 1 | Opponent | - | - | 2 | 6 | 1 | 1 | 0 | 0 | 0 |
| L2832 | 6 | 1 | Mine | no | 0 | - | 0 | 0 | 2 | 0 | 0 | 414 |
| L2832 | 6 | 1 | Opponent | no | 4 | 2 | 5 | 0 | 0 | 0 | 0 | 0 |
| L3133 | 1 | 1 | Mine | no | 5 | 2 | 4 | 1 | 2 | 0 | 0 | 340 |
| L3133 | 1 | 1 | Opponent | no | 8 | 3 | 4 | 3 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 28% | 2.8 | 2.7 | 2.2 | 1.0 | 0.4 | 0.0 | 0.0 | 285.1 |
| **Average** | | | Opponent | 22% | 2.8 | 2.2 | 2.9 | 1.8 | 0.4 | 0.0 | 0.0 | 139.0 |

### KPIs: su-h2h-opp-e45904b-p3

Rules off - Mine only: SET-UP SPOT, CARRIES OUT CLOSE-IN, JOINT AS ONE.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 22% (40 of 181) | 8% (13 of 173) | 15% (53 of 354) |
| Winner chose to follow up after the loser gave ground |  | 95% (39 of 41); on the table 95% | 100% (42 of 42); on the table 100% | 98% (81 of 83); on the table 98% |
| Winner chose to pursue after the loser fell back in good order |  | 86% (6 of 7); on the table 100% | 95% (18 of 19); on the table 100% | 92% (24 of 26); on the table 100% |
| Winner chose to pursue after the loser fled |  | 59% (10 of 17); on the table 59% | 78% (31 of 40); on the table 80% | 72% (41 of 57); on the table 74% |
| Winner chose to follow up or pursue (all three) |  | 85% (55 of 65); on the table 86% | 90% (91 of 101); on the table 92% | 88% (146 of 166); on the table 90% |
| Magic missiles tried each own turn | 50%+ | 33% (113 of 342) | 43% (83 of 192) | 37% (196 of 534) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 49% (113 of 232) | 53% (83 of 157) | 50% (196 of 389) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 61% (11 of 18) | 46% (31 of 67) | 49% (42 of 85) |
| Points that never fought | lower | 40% (27780 of 68801) | 43% (31068 of 71990) | 42% (58848 of 140791) |
|   infantry points that never fought | lower | 49% (6945 of 14174) | 63% (9027 of 14220) | 56% (15972 of 28394) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 58% (157 of 272) | 58% (166 of 285) | 58% (323 of 557) |
| Bound items with a magic missile used (at least once a game) |  | 92% (23 of 25); 1.6 uses a game | 96% (23 of 24); 2.3 uses a game | 94% (46 of 49); 1.9 uses a game |
| Bound items with another spell used |  | 50% (7 of 14); 0.3 uses a game | 17% (1 of 6); 0.0 uses a game | 40% (8 of 20); 0.2 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 50% (10 of 20); 0.3 uses a game | 43% (6 of 14); 0.2 uses a game | 47% (16 of 34); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 55% (32837 of 59391) | 51% (32439 of 64043) | 53% (65276 of 123434) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.1 (17%) | 0.8 (27%) | 1.9 (20%) |
| MARCHED: its unit marched | 1.6 (25%) | 0.9 (29%) | 2.5 (27%) |
| CHARGED: its unit charged | 0.3 (5%) | 0.2 (6%) | 0.5 (5%) |
| IN COMBAT: engaged in combat | 1.2 (19%) | 0.5 (17%) | 1.7 (18%) |
| REAR RANK: in a rear rank | 0.1 (1%) | 0.2 (6%) | 0.2 (2%) |
| FLEEING: fleeing | 0.2 (3%) | 0.0 (0%) | 0.2 (2%) |
| GONE: slain | 1.6 (24%) | 0.4 (12%) | 1.9 (20%) |
| OFF THE TABLE: off the table or not arrived | 0.1 (2%) | 0.1 (3%) | 0.2 (2%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (2%) | 0.0 (1%) | 0.1 (1%) |
| NOT OFFERED: not in the cast list | 0.1 (2%) | 0.0 (0%) | 0.1 (1%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.7 | 1.2 | 1.6 | 5.4 | 0.5 | 1.2 |
| not cast | 4.1 | 1.4 | 4.6 | 9.4 | 2.8 | 19.5 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) | 1.4 (7%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.1 (1%) | 0.6 (45%) | 0.4 (8%) | 1.9 (20%) | 0.5 (17%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.5 (27%) | 0.5 (18%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.5 (5%) | 0.1 (3%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.1 (3%) | 0.2 (14%) | 0.6 (13%) | 1.7 (18%) | 0.5 (17%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.2 (4%) | 0.0 (0%) | 0.3 (7%) | 0.2 (2%) | 0.2 (6%) | 0.0 (0%) |
| FLEEING: fleeing | 0.2 (5%) | 0.0 (2%) | 0.2 (4%) | 0.2 (2%) | 0.0 (0%) | 0.7 (3%) |
| GONE: slain | 1.4 (33%) | 0.3 (24%) | 1.1 (23%) | 1.9 (20%) | 0.6 (23%) | 2.8 (14%) |
| OFF THE TABLE: off the table or not arrived | 0.1 (2%) | 0.0 (0%) | 0.1 (2%) | 0.2 (2%) | 0.2 (6%) | 0.5 (3%) |
| STUPIDITY: Stupidity | 0.0 (1%) | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (3%) | 0.1 (4%) | 0.0 (0%) | 0.1 (1%) | 0.3 (12%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.0 (48%) | 0.2 (12%) | 1.9 (41%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 14.2 (73%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.2 a game | 0.5 a game | 0.8 a game |
| stood (cast and not dispelled) | 63% (24 of 38) | 50% (7 of 14) | 60% (31 of 52) |
| the unit moved after it | 71% (17 of 24) | 86% (6 of 7) | 74% (23 of 31) |
| it charged on its next turn | 4% (1 of 24) | 14% (1 of 7) | 6% (2 of 31) |
| the enemy charged it first | 21% (5 of 24) | 14% (1 of 7) | 19% (6 of 31) |
| it fought by the end of its next turn | 17% (4 of 24) | 0% (0 of 7) | 13% (4 of 31) |
| it moved out of a charge the enemy had planned (not charged first) | 25% (6 of 24) | 14% (1 of 7) | 23% (7 of 31) |
| none of these (no charge, no fight, no charge escaped) | 50% (12 of 24) | 57% (4 of 7) | 52% (16 of 31) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 66% (503 of 759) | 58% (372 of 636) | 63% (875 of 1395) |
|   cavalry | 68% (40 of 59) | 58% (69 of 119) | 61% (109 of 178) |
|   character | 60% (55 of 92) | 22% (27 of 125) | 38% (82 of 217) |
|   chariot | 56% (57 of 101) | 62% (15 of 24) | 58% (72 of 125) |
|   infantry | 53% (111 of 211) | 69% (185 of 267) | 62% (296 of 478) |
|   monster | 41% (12 of 29) | 33% (2 of 6) | 40% (14 of 35) |
|   war machine | 85% (228 of 267) | 78% (74 of 95) | 83% (302 of 362) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.4 (33%) | 1.7 (23%) | 4.0 (28%) |
| CHARGED: it charged | 0.7 (10%) | 1.8 (25%) | 2.6 (18%) |
| FLEEING: it fled or was fleeing | 0.2 (3%) | 0.1 (2%) | 0.3 (2%) |
| IN COMBAT: it fought this turn or the last | 0.4 (6%) | 0.4 (6%) | 0.8 (6%) |
| MOVED: a war machine that moved | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| NO TARGET IN RANGE | 1.1 (16%) | 1.1 (15%) | 2.2 (15%) |
| ONLY IN COMBAT: the only targets were in combat | 0.2 (3%) | 0.5 (6%) | 0.7 (5%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.4 (20%) | 1.2 (17%) | 2.6 (18%) |
| SHELTERED: the target was sheltered | 0.2 (3%) | 0.2 (3%) | 0.5 (3%) |
| STUPIDITY | 0.0 (0%) | 0.1 (1%) | 0.1 (0%) |
| OTHER BAR | 0.4 (5%) | 0.2 (2%) | 0.5 (4%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 4.6 | 0.8 | 84% | 4.9 pts | 23 pts |
| character | 2.7 | 0.6 | 82% | 4.3 pts | 12 pts |
| chariot | 2.0 | 1.4 | 58% | 19.3 pts | 39 pts |
| infantry | 12.5 | 4.3 | 76% | 9.5 pts | 119 pts |
| monster | 0.4 | 0.2 | 69% | 14.8 pts | 7 pts |
| war machine | 8.8 | 8.3 | 59% | 27.6 pts | 241 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.2 | 5.5 | 4.4 |
| Charges that made contact a game | 2.3 | 3.8 | 3.1 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.78 declared, 0.65 contact (23 units) | 0.61 declared, 0.39 contact (18 units) | 0.71 declared, 0.54 contact (41 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.67 declared, 0.33 contact (3 units) | 1.00 declared, 0.67 contact (9 units) | 0.92 declared, 0.58 contact (12 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.43 declared, 0.30 contact (223 units) | 0.67 declared, 0.47 contact (267 units) | 0.56 declared, 0.39 contact (490 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 58% (45 of 77) | 60% (9 of 15) | 50% (5 of 10) | 58% (59 of 102) |
| Character in a unit | 78% (28 of 36) | 76% (13 of 17) | 40% (2 of 5) | 74% (43 of 58) |
| Character on its own | 80% (33 of 41) | 62% (24 of 39) | 36% (25 of 70) | 55% (82 of 150) |
| Chariot | 64% (7 of 11) | 67% (8 of 12) | - | 65% (15 of 23) |
| Infantry | 56% (39 of 70) | 45% (19 of 42) | 20% (1 of 5) | 50% (59 of 117) |
| Monster | 53% (18 of 34) | 29% (2 of 7) | - | 49% (20 of 41) |
| Monstrous | 100% (10 of 10) | 64% (7 of 11) | - | 81% (17 of 21) |
| War Machines | 63% (27 of 43) | 50% (1 of 2) | - | 62% (28 of 45) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 100% (4 of 4); on the table 100% | 39% (37 of 96) | 39% | 55% (12 of 22) | 100% (6 of 6); 4.5 uses a game | 100% (2 of 2); 0.8 uses a game | 83% (5 of 6); 1.2 uses a game |
| Chaos Dwarfs | 4 | 71% (5 of 7); on the table 71% | 50% (18 of 36) | 62% | 53% (17 of 32) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
| Dwarfen Mountain Holds | 3 | 100% (1 of 1); on the table 100% | - | 65% | 71% (17 of 24) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 6 | 100% (5 of 5); on the table 100% | 60% (18 of 30) | 55% | 66% (39 of 59) | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game | 25% (1 of 4); 0.2 uses a game |
| Grand Cathay | 8 | 93% (13 of 14); on the table 100% | 33% (64 of 192) | 47% | 55% (41 of 74) | 94% (17 of 18); 6.2 uses a game | 25% (1 of 4); 0.2 uses a game | 25% (2 of 8); 0.2 uses a game |
| High Elf Realms | 7 | 94% (17 of 18); on the table 94% | 21% (9 of 42) | 41% | 52% (28 of 54) | 89% (8 of 9); 3.4 uses a game | 42% (5 of 12); 1.1 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 3 | 100% (9 of 9); on the table 100% | - | 46% | 44% (8 of 18) | 0.0 uses a game | 0.0 uses a game | 100% (3 of 3); 1.0 uses a game |
| Lizardmen | 1 | - | 50% (3 of 6) | 30% | 43% (3 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 1 | 100% (1 of 1); on the table 100% | 0% (0 of 6) | 30% | 57% (4 of 7) | 100% (1 of 1); 4.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 2 | 100% (6 of 6); on the table 100% | 17% (2 of 12) | 7% | 75% (12 of 16) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |
| Skaven | 2 | 50% (3 of 6); on the table 50% | 17% (2 of 12) | 73% | 50% (7 of 14) | 0.0 uses a game | 0.0 uses a game | 100% (2 of 2); 1.0 uses a game |
| Tomb Kings of Khemri | 6 | 94% (15 of 16); on the table 100% | 50% (3 of 6) | 36% | 38% (10 of 26) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 8 | 80% (16 of 20); on the table 80% | 44% (24 of 54) | 32% | 52% (24 of 46) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 11 | 85% (44 of 52); on the table 87% | 50% (15 of 30) | 35% | 64% (61 of 96) | 100% (4 of 4); 1.5 uses a game | 0.0 uses a game | 100% (2 of 2); 0.2 uses a game |
| Wood Elf Realms | 6 | 100% (7 of 7); on the table 100% | 8% (1 of 12) | 33% | 65% (40 of 62) | 91% (10 of 11); 4.5 uses a game | 0.0 uses a game | 0% (0 of 5); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (su-h2h-opp-e45904b-p3, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 52% (43) | 56% (33) | 54% (76) |
| ...free all their last turn and able to turn (per game) | 0.81 | 0.36 | 1.17 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.17 | 0.31 | 0.47 |
| ...with the charger already in that arc before they moved (per game) | 0.56 | 0.31 | 0.86 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 2.08 | 1.11 | 3.19 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 1.08 | 0.58 | 1.67 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 6.50 | 5.67 | 12.17 |

### Quality by phase: su-h2h-opp-e45904b-p3

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.2 | 3.6 |
| Strategy | Charge objectives carried out (made contact) | 52% (57 of 110) | 45% (79 of 176) |
| Strategy | Shoot objectives carried out (shot that target) | 50% (195 of 388) | 44% (97 of 218) |
| Strategy | Close-in objectives charged next turn | 12% (18 of 156) | 21% (38 of 182) |
| Strategy | Support requests answered (helper made contact too) | 27% (3 of 11) | 47% (17 of 36) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (1 of 1) | 100% (1 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | 40% (6 of 15) | 83% (5 of 6) |
| Strategy | Joined characters whose unit fought | 40% (17 of 42) | 34% (16 of 47) |
| Strategy | Lone characters that fought | 74% (69 of 93) | 71% (62 of 87) |
| Movement | Charges halted short of contact | 0.0 | 0.4 |
| Movement | Idle units | 1.0 | 1.8 |
| Movement | Points that never moved of their own | 285.1 | 139.0 |
| Movement | Fights charged into per game | 2.2 | 3.2 |
| Movement | Charges with odds: long shots (under 50%) | 8 of 69, net -46 | 18 of 99, net +54 |
| Movement | Charges with odds: sweet spot (55-75%) | 13 of 69, net -3 | 15 of 99, net +167 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 9 of 69, net +80 | 9 of 99, net +54 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 17 of 69, net +64 | 21 of 99, net +145 |
| Shooting | Shots by shooting units (incl. breath weapons) | 8.3 | 9.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 42% (127 of 300) | 48% (168 of 348) |
| Shooting | Points destroyed by shooting units | 42.7 | 68.0 |
| Shooting | War machine shots | 6.3 | 2.4 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 50% (113 of 228) | 47% (41 of 87) |
| Shooting | Points destroyed by war machines | 93.6 | 25.3 |
| Magic | Magic missiles cast | 2.2 | 1.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 38% (30 of 80) | 33% (16 of 48) |
| Magic | Wounds caused by magic missiles | 4.0 | 1.9 |
| Magic | Wounds caused by other spells | 1.2 | 0.8 |
| Magic | Points destroyed by magic (all spells) | 56.3 | 40.1 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.4 / 0.4 / 0.4 / 0.1 | 2.1 / 0.2 / 0.2 / 0.2 |
| Combat | Points destroyed in combat | 329.3 | 443.0 |
| Combat | Points run down | 25.9 | 124.1 |
| Combat | Net points per charged fight, damage counted | +62 | +102 |
| Combat | Net per 100 charger points, damage counted | +20.7 | +35.3 |
| Combat | First round won (charged fights) | 67% | 76% |
| Combat | Net points per charged fight | +64 | +97 |
| Combat | Net points per supported fight / lone fight | -85 / +78 | +258 / +75 |
| Combat | Charged fights on a top-3 enemy unit | 33 of 79 | 49 of 117 |
| Game | Points lost | 821.7 | 589.6 |
| Game | VP from objectives | 519.4 | 647.5 |
| Game | Lone holders (player turns) | 2.8 | 2.8 |

- Mine won / drew / lost: 9 / 8 / 19 of 36 ended games (of 36); mean margin (Mine - Opponent) -378 VP
- The side that went first won 15 of 28 games with a winner
- Points traded per game (both sides' losses): 1411
- Games not ended: 0; findings 0, warnings 1

### Opponent rules: su-h2h-opp-e45904b-p3

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.6 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 0.0 |
| ALREADY CARRIED | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARRIVAL HUNT | 0.0 | +0.1 | 0.0 | 0.0 | 0.1 | +0.5 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.7 | +0.0 | 0.0 | 24.2 | 0.4 | +0.0 | 0.0 | 4.6 |
| BACKUP TARGETS | 1.0 | +8.3 | 0.0 | 61.4 | 0.8 | +10.2 | 0.0 | 18.5 |
| BEST FACING | 1.1 | +37.8 | 0.0 | 26.1 | 0.4 | +22.6 | 0.0 | 0.0 |
| BEST FIRST | 5.0 | +209.6 | 142.5 | 165.7 | 3.6 | +163.1 | 117.4 | 15.1 |
| BEST OVERALL | 1.0 | +63.6 | 0.0 | 11.5 | 0.3 | +23.5 | 0.0 | 5.3 |
| BEST PREY | 0.7 | +33.2 | 22.4 | 15.3 | 0.6 | +23.2 | 14.4 | 15.8 |
| BEST PRIZE | 0.1 | +0.2 | 7.1 | 9.7 | 0.1 | +3.4 | 0.0 | 0.0 |
| BIG CHARACTER SAFETY | 0.2 | -0.5 | 0.0 | 21.5 | 0.2 | -0.5 | 0.0 | 0.0 |
| BLOCKED CHARGE SKIPPED | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| BLOCKED WHEEL | 0.3 | +0.4 | 0.0 | 0.0 | 0.3 | +8.6 | 0.0 | 0.8 |
| BLOWS WHERE AIMED | 0.4 | -49.2 | 37.4 | 15.8 | 0.4 | -47.3 | 93.7 | 21.3 |
| BOMBING RUN | 0.0 | +0.8 | 0.0 | 0.0 | - | - | - | - |
| CANNON PLAN MISSED | 0.7 | +0.0 | 85.7 | 9.6 | 0.2 | +0.0 | 27.3 | 4.6 |
| CANNON PLANNED TARGET | 5.8 | +150.8 | 360.4 | 119.0 | 1.2 | +49.1 | 119.8 | 4.6 |
| CANNON SIGHT KEPT | 1.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT CLOSE-IN | - | - | - | - | 0.5 | -6.3 | 50.2 | 46.1 |
| CARRIES OUT COUNTER | 0.2 | -3.2 | 24.2 | 0.0 | - | - | - | - |
| CARRIES OUT SET-UP | 0.2 | -9.0 | 10.4 | 9.2 | 0.1 | -0.6 | 26.2 | 3.2 |
| CAST JOB | 0.8 | +18.5 | 55.0 | 7.9 | 0.6 | +12.5 | 17.8 | 5.4 |
| CASTER AWAY FROM SCREEN | 0.2 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.5 | +47.2 | 41.1 | 8.9 | 0.1 | +0.7 | 7.0 | 0.0 |
| CASTS AFTER FRIENDS | 0.6 | +0.0 | 0.0 | 41.9 | 0.2 | +0.0 | 0.0 | 11.1 |
| CASTS FROM BEHIND | 0.0 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.1 | +1.3 | 0.0 | 0.0 | - | - | - | - |
| CATCH ODDS | 0.0 | +0.4 | 0.0 | 0.0 | - | - | - | - |
| CHAFF PASSED | 0.1 | -0.0 | 0.0 | 3.8 | 0.2 | -0.6 | 3.5 | 3.7 |
| CHARGE BAND | 0.1 | +0.0 | 1.7 | 5.4 | 0.1 | +0.0 | 19.9 | 3.2 |
| CHARGE NOW FIRST | 2.2 | +0.0 | 186.7 | 66.1 | 2.4 | +0.0 | 299.3 | 97.9 |
| CHARGE NOW WEIGHED | 0.8 | -100.9 | 44.2 | 57.8 | 0.6 | -38.1 | 19.7 | 9.6 |
| CHARGER SLAIN LOST | 0.3 | -11.9 | 22.5 | 21.3 | 0.9 | -16.0 | 63.6 | 18.6 |
| CHARIOT NO STATIC JOB | 0.1 | +0.0 | 2.4 | 0.0 | - | - | - | - |
| CHARIOT WIZARD CAREFUL | - | - | - | - | 0.2 | -1.7 | 7.0 | 11.0 |
| CHEAP HELPER | - | - | - | - | 0.1 | +0.0 | 4.0 | 0.5 |
| COMBAT PIVOT | 0.3 | +0.0 | 18.3 | 28.0 | 0.4 | +0.0 | 40.4 | 19.3 |
| CONTINUE AHEAD WEIGHED | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CONVEYANCE SEARCH | 0.6 | +110.9 | 31.6 | 31.6 | 0.4 | +33.4 | 11.1 | 17.6 |
| COUNTER-CHARGE COVER | 10.8 | +1037.3 | 0.0 | 250.2 | 7.5 | +668.8 | 0.0 | 103.5 |
| DEFENSIVE ARMY | 0.1 | +0.0 | 0.0 | 6.1 | 0.1 | +0.0 | 10.6 | 0.0 |
| DEFENSIVE FLOOR | 0.1 | +2.4 | 0.0 | 0.0 | - | - | - | - |
| EDGE GIVE GROUND | 0.2 | +9.4 | 17.9 | 0.0 | 0.2 | +2.3 | 3.2 | 2.1 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 2.1 | +176.7 | 0.0 | 72.8 | 1.1 | +106.5 | 0.0 | 13.4 |
| FALLBACK BY WORTH | 5.0 | +101.7 | 0.0 | 110.8 | 5.1 | +53.0 | 0.0 | 22.2 |
| FIGHT LIFT | 0.0 | +0.1 | 0.0 | 0.0 | 0.0 | +1.1 | 0.0 | 0.0 |
| FIRE AND FLEE | 0.0 | +0.4 | 2.9 | 2.2 | - | - | - | - |
| FLANK NOT WEIGHED | 7.0 | +0.0 | 0.0 | 194.3 | 5.1 | +0.0 | 0.0 | 103.1 |
| FOCUS FIRE | - | - | - | - | 0.1 | +1.5 | 0.0 | 0.0 |
| FOLLOW UP WEIGHED | 0.7 | +75.7 | 0.0 | 15.1 | 0.8 | +92.0 | 0.0 | 15.2 |
| FRIENDS SHOTS CHECKED | 0.2 | +17.8 | 0.0 | 0.0 | 0.1 | +11.7 | 0.0 | 0.0 |
| GIVES UP | 0.0 | -0.8 | 7.9 | 0.0 | 0.1 | -0.5 | 6.9 | 0.0 |
| GIVES UP ITS SCREEN | 0.1 | -0.8 | 0.0 | 1.7 | - | - | - | - |
| GROUND FLIERS | 0.0 | +3.2 | 0.0 | 0.0 | - | - | - | - |
| HELPER ALREADY ASKED | 0.0 | +0.0 | 0.0 | 3.2 | 0.1 | +0.0 | 18.2 | 6.4 |
| HELPER UNSEEN | 0.2 | +0.0 | 17.8 | 12.8 | 0.5 | +0.0 | 46.7 | 5.4 |
| HILL BY ITS CHANCE | 0.2 | -20.9 | 0.0 | 0.0 | 0.4 | -50.5 | 0.0 | 3.8 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 6.9 | -123.1 | 298.6 | 170.0 | 7.7 | -189.1 | 569.2 | 187.8 |
| HORN WORTH | - | - | - | - | 0.1 | +0.7 | 0.0 | 0.0 |
| HUNT ADVANCE | 0.2 | +13.9 | 0.0 | 5.2 | 0.2 | +2.8 | 0.0 | 5.8 |
| HUNT DROPPED | 0.1 | +0.0 | 0.0 | 1.4 | 0.1 | +0.0 | 3.5 | 0.0 |
| HUNT IN PAIRS | 0.4 | +12.9 | 0.0 | 5.4 | 0.6 | +36.8 | 0.0 | 8.5 |
| HUNT KEPT | 0.2 | +8.1 | 0.0 | 4.7 | 0.1 | +1.4 | 0.0 | 4.1 |
| HUNT RESULT | 0.2 | +5.9 | 0.0 | 1.4 | 0.2 | +11.4 | 17.4 | 1.2 |
| HUNT THE GUNS | 0.2 | +80.4 | 5.4 | 2.9 | 0.3 | +72.3 | 10.4 | 2.9 |
| INVITES THE FIGHT | 1.3 | +26.7 | 57.8 | 0.0 | 0.9 | +15.1 | 52.3 | 9.1 |
| JOINT AS ONE | - | - | - | - | 2.3 | -9.6 | 138.0 | 52.3 |
| JOINT CHARGE PLAN | 0.2 | +6.3 | 1.7 | 3.2 | 0.2 | +9.5 | 24.4 | 6.4 |
| JOINT KNOWS CHALLENGE | - | - | - | - | 0.1 | -0.8 | 5.1 | 6.3 |
| KEEP FALLS | 0.0 | +0.5 | 0.0 | 7.5 | 0.0 | +0.1 | 0.0 | 0.0 |
| KEEPS ITS PREY | 0.1 | +0.3 | 0.0 | 0.0 | - | - | - | - |
| KEEPS ITS TARGET | 1.3 | +38.3 | 58.9 | 53.3 | 1.8 | +53.3 | 192.5 | 77.9 |
| KEEPS SCOUTS OR AMBUSH | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KILLS COUNT | 1.5 | +86.3 | 112.6 | 30.2 | 1.9 | +80.0 | 146.5 | 42.3 |
| KILLS COUNT NEXT TURN | 5.0 | +149.8 | 111.4 | 199.7 | 6.3 | +205.3 | 261.9 | 122.8 |
| LONE CHARACTER SAFE SPOT | 0.3 | +8.2 | 23.4 | 2.5 | 0.4 | +9.1 | 0.0 | 25.8 |
| LONE WIZARD HOLDS BACK | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 5.4 |
| LONE WIZARD KEPT IN | 0.6 | +37.3 | 0.0 | 0.0 | 0.4 | +25.4 | 0.0 | 0.0 |
| LONG SHOT | 0.2 | +0.1 | 14.3 | 0.0 | 0.2 | -3.4 | 12.9 | 0.0 |
| LOST CHARGE | 2.8 | -57.1 | 116.3 | 184.6 | 2.4 | -37.9 | 85.1 | 79.4 |
| LURE BY WHAT IT DRAWS | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MAKE SURE TOGETHER | 1.1 | +131.8 | 1.7 | 39.9 | 0.5 | +24.2 | 38.4 | 22.8 |
| MANOEUVRE | 0.2 | +11.1 | 0.0 | 0.0 | 0.3 | +6.8 | 0.0 | 6.8 |
| MARCH AT ESCAPER | 0.2 | +1.9 | 0.0 | 4.8 | - | - | - | - |
| MARCH CHECK | 0.5 | +34.0 | 0.0 | 21.2 | 0.7 | +44.2 | 0.0 | 3.0 |
| MARCH ODDS | 0.2 | +9.8 | 19.4 | 13.9 | 0.2 | +14.7 | 10.3 | 0.0 |
| MARCH OVER CASTS | 0.8 | +48.3 | 0.0 | 64.8 | 0.5 | +50.9 | 0.0 | 11.1 |
| MAX FOR POSITIONING | 4.9 | +179.6 | 0.0 | 133.7 | 4.7 | +194.5 | 0.0 | 89.3 |
| MISSILES IN THE MOVE | 3.9 | +140.9 | 0.0 | 106.9 | 4.4 | +60.3 | 0.0 | 46.1 |
| MISSILES NEXT TURN | 5.2 | +89.7 | 0.0 | 195.7 | 5.1 | +51.2 | 0.0 | 60.2 |
| MODEL FACING | 0.1 | +36.9 | 0.0 | 1.7 | - | - | - | - |
| MONSTER WIZARD ROAMS | 0.3 | +0.0 | 19.0 | 41.9 | 0.3 | +0.0 | 28.2 | 0.0 |
| MOVE AND CAST | 0.5 | +34.9 | 0.0 | 7.1 | 0.5 | +21.1 | 0.0 | 17.2 |
| MOVE SPELL IN RANGE | 0.2 | +5.2 | 0.0 | 21.1 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.4 | -13.8 | 6.6 | 43.5 | 0.1 | -2.2 | 2.9 | 13.0 |
| MOVE SPELL SPOT | 0.4 | +0.0 | 0.0 | 10.5 | 0.1 | +0.0 | 0.0 | 11.1 |
| MOVE TO CHARGE | 2.9 | +291.1 | 47.4 | 128.4 | 3.3 | +281.1 | 135.2 | 79.5 |
| MOVES UNITS SPELL | 0.1 | +3.6 | 0.0 | 0.0 | 0.1 | +0.3 | 0.0 | 0.0 |
| NO CHARGE WHY | 2.9 | +0.0 | 93.9 | 107.8 | 3.3 | +0.0 | 161.8 | 66.6 |
| NO RALLY LEFT | - | - | - | - | 0.1 | +1.0 | 0.0 | 2.2 |
| NOT NEEDED | 0.2 | -13.3 | 4.0 | 3.2 | 0.2 | -6.0 | 13.0 | 0.0 |
| NOT TURNED | 6.5 | +93.1 | 0.0 | 174.4 | 5.7 | +94.1 | 0.0 | 92.8 |
| NOT WORTH A CAST | 0.5 | -0.4 | 0.0 | 21.1 | 0.7 | -0.8 | 0.0 | 13.0 |
| OFF BEST | 16.6 | -840.0 | 7.6 | 344.9 | 14.5 | -829.7 | 15.7 | 190.0 |
| OPENS A LANE | 0.2 | +0.7 | 12.3 | 0.0 | 0.1 | +0.6 | 5.5 | 0.0 |
| OPENS UP | 0.1 | +8.4 | 7.8 | 0.0 | 0.2 | +14.7 | 9.5 | 0.0 |
| OVERRUNS AWAY | 0.4 | +6.4 | 38.8 | 17.0 | 0.4 | +11.2 | 39.2 | 31.6 |
| PATHS CROSS | 2.1 | +153.3 | 0.0 | 41.3 | 2.9 | +248.0 | 0.0 | 70.5 |
| PERIAPT WORTH | 0.0 | +2.8 | 0.0 | 0.0 | 0.0 | +1.5 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.2 | -5.1 | 0.0 | 5.9 | 0.1 | -3.4 | 0.0 | 1.9 |
| PLAN RESULT | 36.4 | +1177.5 | 1199.2 | 1096.2 | 37.7 | +1538.9 | 1667.6 | 801.3 |
| PURSUES BIG PREY | - | - | - | - | 0.1 | -13.4 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE | - | - | - | - | 0.1 | +11.5 | 0.0 | 1.5 |
| RAIDS THE BAGGAGE NEXT TURN | 0.1 | +7.3 | 0.0 | 4.8 | 0.1 | +5.9 | 0.0 | 5.3 |
| RANDOM MOVE BY FIGURES | 0.5 | +15.1 | 0.0 | 40.0 | 1.9 | +21.9 | 0.0 | 47.2 |
| RANDOM MOVER NO PROMISE | 0.1 | -6.3 | 0.0 | 9.4 | 0.6 | -42.7 | 28.1 | 4.7 |
| REDIRECT BY WHAT IT STOPS | 0.2 | -3.1 | 0.0 | 0.0 | 0.8 | -19.6 | 0.0 | 6.9 |
| REDIRECT COUNTER | 2.1 | +166.2 | 0.0 | 41.1 | 3.8 | +324.4 | 0.0 | 47.3 |
| REDIRECT WEIGHED | 0.3 | +3.8 | 9.6 | 12.1 | 0.5 | +15.9 | 13.7 | 13.1 |
| REFUSING RETIRES | 0.2 | +0.0 | 0.0 | 12.1 | 0.2 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | 0.3 | +11.9 | 0.0 | 0.0 | 0.9 | +33.5 | 0.0 | 15.8 |
| RESTRAINS TO SHOOT | 0.1 | +1.8 | 0.0 | 0.0 | 0.0 | +5.2 | 0.0 | 0.0 |
| RISK BY ARC | 2.2 | +85.7 | 170.4 | 65.9 | 3.0 | +52.4 | 287.8 | 101.6 |
| SAFE SURE CHARGE | - | - | - | - | 0.0 | -1.0 | 7.1 | 0.0 |
| SAFER THAN THE JOB | 1.1 | +67.9 | 0.0 | 24.2 | 0.6 | +31.8 | 0.0 | 4.2 |
| SCOUT SPOT | 0.4 | +0.6 | 0.0 | 0.9 | 0.3 | +1.0 | 0.0 | 0.0 |
| SCOUT WAITS | 0.4 | +0.0 | 0.0 | 0.9 | 0.3 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.1 | -1.2 | 0.0 | 0.0 | 0.2 | -9.5 | 0.0 | 1.1 |
| SEARCH SPOT | 2.6 | +154.2 | 0.0 | 39.2 | 3.4 | +164.9 | 0.0 | 42.4 |
| SECOND HUNTER | 0.0 | -0.4 | 0.0 | 1.4 | - | - | - | - |
| SELF MOVE SPELL | 0.2 | +33.5 | 0.0 | 32.9 | 0.1 | +43.7 | 0.0 | 11.0 |
| SET UP TOGETHER | 1.4 | +149.7 | 9.3 | 60.5 | 1.5 | +75.3 | 58.3 | 42.1 |
| SET-UP ANY TARGET | 0.2 | +36.0 | 31.6 | 31.6 | 0.2 | +24.6 | 0.0 | 6.5 |
| SET-UP MISSED | 0.0 | +5.8 | 8.9 | 0.0 | - | - | - | - |
| SET-UP SPOT | - | - | - | - | 5.6 | +146.6 | 111.0 | 90.9 |
| SHOOTERS IN TWO RANKS | 0.4 | +0.7 | 0.0 | 0.0 | 0.1 | +0.3 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.0 | +52.2 | 23.0 | 8.6 | 0.9 | +28.8 | 47.9 | 6.0 |
| SHORT GUN FORWARD | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SHOT REPLANNED | 0.6 | +0.0 | 120.5 | 6.1 | 0.5 | +0.0 | 111.9 | 8.8 |
| SHOTS IN THE MOVE | 14.2 | +565.6 | 0.0 | 279.3 | 10.1 | +302.7 | 0.0 | 100.9 |
| SPELL SETS UP CHARGE | 0.5 | +111.6 | 31.6 | 31.6 | 0.2 | +28.7 | 11.1 | 17.6 |
| SPELL WORTH | 1.2 | +18.5 | 28.8 | 68.1 | 2.3 | +39.5 | 42.8 | 55.8 |
| SPELLS IN THE FIGHT | 0.2 | +0.2 | 19.2 | 0.0 | 0.8 | -13.7 | 86.8 | 40.0 |
| STABLE ROLE | 10.6 | +0.0 | 346.7 | 181.6 | 8.6 | +0.0 | 297.4 | 158.6 |
| STANDS TO CAST | 0.0 | +2.2 | 0.0 | 0.0 | - | - | - | - |
| STAY WEIGHED | 0.1 | +3.3 | 0.0 | 0.0 | - | - | - | - |
| STOPS | 0.2 | +4.6 | 5.4 | 0.0 | 0.2 | +6.6 | 10.4 | 0.0 |
| STOPS SHORT OF THE FLANK | 0.5 | +20.2 | 0.0 | 38.5 | 0.3 | +3.2 | 0.0 | 3.4 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 15.3 | 0.3 | +0.0 | 0.0 | 4.7 |
| SUPPORT NARROWED | 5.7 | -59.7 | 311.4 | 121.7 | 7.6 | -61.4 | 400.6 | 136.9 |
| SUPPORTS | 4.1 | +65.1 | 206.7 | 69.2 | 5.4 | +72.8 | 190.4 | 63.9 |
| SURE CHARGE BEATS ADVANCE | 0.1 | -1.4 | 2.0 | 5.2 | 0.1 | -5.6 | 6.3 | 0.0 |
| SURE REACH TOGETHER | 0.4 | +2.7 | 0.0 | 5.4 | 0.7 | +4.3 | 0.0 | 11.4 |
| THROUGH LINE OF FIRE | 0.5 | +31.3 | 0.0 | 4.6 | 0.4 | +28.0 | 0.0 | 0.0 |
| TURN WORTH | 0.2 | -20.8 | 23.2 | 4.0 | 0.2 | -14.6 | 12.5 | 0.0 |
| TWO OR MORE ARRIVE | 0.4 | +2.7 | 0.0 | 10.2 | 0.4 | +2.1 | 0.0 | 11.9 |
| WAIT AFTER COSTS | 6.1 | -308.1 | 143.6 | 149.9 | 5.8 | -296.4 | 249.8 | 109.2 |
| WALKS TO THE FIGHT | 1.4 | +28.2 | 23.7 | 11.0 | 0.8 | +11.7 | 18.5 | 11.1 |
| WAR ENGINE CHARGES | 0.1 | +4.0 | 18.6 | 0.0 | - | - | - | - |
| WAR ENGINE JOBS | 0.7 | +0.0 | 49.8 | 16.1 | 0.2 | +0.0 | 0.0 | 0.0 |
| WEARS DOWN | 1.1 | +45.2 | 57.5 | 40.6 | 1.2 | +51.1 | 191.3 | 40.2 |
| WHO HITS BACK | 0.4 | +19.2 | 0.0 | 7.7 | 0.1 | +14.8 | 0.0 | 19.3 |
| WHOLE FIGHT | 0.2 | +2.2 | 30.6 | 12.0 | 0.5 | +33.1 | 76.0 | 6.0 |
| WHOLE FIGHT GAIN | 0.2 | +19.4 | 11.3 | 5.7 | 0.7 | +78.2 | 52.7 | 19.8 |
| WIDER SPREAD | 2.1 | -6.0 | 149.2 | 68.9 | 3.2 | -5.0 | 315.6 | 73.4 |
| WOUNDED STAYS OUT | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |

### Rule changes: su-h2h-opp-e45904b-p3

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 1120 | 1120 | 1120 | 31.11 | -60109 | -53.7 |
| BEST FIRST | 312 | 312 | 312 | 8.67 | +13416 | +43.0 |
| SEARCH SPOT | 214 | 214 | 213 | 5.92 | +11488 | +53.9 |
| COUNTER-CHARGE COVER | 661 | 366 | 178 | 4.94 | +11738 | +65.9 |
| PATHS CROSS | 178 | 178 | 178 | 4.94 | +14447 | +81.2 |
| SUPPORTS | 343 | 343 | 143 | 3.97 | +1726 | +12.1 |
| MOVE TO CHARGE | 223 | 223 | 124 | 3.44 | +9035 | +72.9 |
| FACES THE THREAT | 115 | 115 | 115 | 3.19 | +10195 | +88.7 |
| KILLS COUNT NEXT TURN | 406 | 406 | 109 | 3.03 | +2938 | +26.9 |
| SET-UP SPOT | 203 | 203 | 106 | 2.94 | +4822 | +45.5 |
| FALLBACK BY WORTH | 362 | 362 | 81 | 2.25 | +5568 | +68.7 |
| SHOTS IN THE MOVE | 875 | 571 | 77 | 2.14 | +1902 | +24.7 |
| ARTILLERY RE-ROLL WEIGHED | 75 | 75 | 75 | 2.08 | +0 | +0.0 |
| SAFER THAN THE JOB | 60 | 60 | 60 | 1.67 | +3590 | +59.8 |
| CANNON SIGHT KEPT | 56 | 56 | 56 | 1.56 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 55 | 55 | 55 | 1.53 | +6036 | +109.8 |
| BEST FACING | 53 | 53 | 53 | 1.47 | +2173 | +41.0 |
| WAIT AFTER COSTS | 427 | 427 | 53 | 1.47 | +790 | +14.9 |
| CHARGE NOW WEIGHED | 51 | 51 | 51 | 1.42 | +4047 | +79.4 |
| BEST OVERALL | 45 | 45 | 45 | 1.25 | +3136 | +69.7 |
| RESERVE FALL BACK | 44 | 44 | 44 | 1.22 | +1635 | +37.2 |
| MAX FOR POSITIONING | 344 | 183 | 43 | 1.19 | +652 | +15.2 |
| RANDOM MOVE BY FIGURES | 85 | 85 | 42 | 1.17 | +1329 | +31.6 |
| SHOOTS FROM THE BEST SPOT | 70 | 70 | 42 | 1.17 | +1464 | +34.9 |
| CANNON PLANNED TARGET | 252 | 252 | 41 | 1.14 | -640 | -15.6 |
| SHOT REPLANNED | 40 | 40 | 40 | 1.11 | +0 | +0.0 |
| HOLDS AMBUSHERS | 39 | 39 | 39 | 1.08 | +0 | +0.0 |
| REDIRECT COUNTER | 213 | 114 | 39 | 1.08 | +3278 | +84.1 |
| WALKS TO THE FIGHT | 80 | 80 | 39 | 1.08 | +630 | +16.2 |
| MISSILES IN THE MOVE | 299 | 171 | 38 | 1.06 | +1014 | +26.7 |
| CHARGE NOW FIRST | 169 | 169 | 37 | 1.03 | -2285 | -61.8 |
| SET UP TOGETHER | 104 | 80 | 37 | 1.03 | +2354 | +63.6 |
| ADVANCE LANE KEPT | 35 | 35 | 35 | 0.97 | +0 | +0.0 |
| MOVE AND CAST | 35 | 35 | 35 | 0.97 | +2018 | +57.7 |
| LONE WIZARD KEPT IN | 33 | 33 | 33 | 0.92 | +2259 | +68.5 |
| MARCH CHECK | 41 | 39 | 33 | 0.92 | +2422 | +73.4 |
| RISK BY ARC | 187 | 177 | 31 | 0.86 | +935 | +30.2 |
| THROUGH LINE OF FIRE | 31 | 31 | 31 | 0.86 | +2136 | +68.9 |
| STOPS SHORT OF THE FLANK | 29 | 29 | 29 | 0.81 | +843 | +29.1 |
| REDIRECT WEIGHED | 28 | 28 | 28 | 0.78 | +1427 | +51.0 |
| HONEST WORTH | 527 | 518 | 27 | 0.75 | +218 | +8.1 |
| COMBAT PIVOT | 26 | 26 | 26 | 0.72 | +0 | +0.0 |
| KILLS COUNT | 120 | 115 | 26 | 0.72 | +1239 | +47.7 |
| SCOUT WAITS | 25 | 25 | 25 | 0.69 | +0 | +0.0 |
| BLOCKED WHEEL | 21 | 21 | 21 | 0.58 | +325 | +15.5 |
| WEARS DOWN | 83 | 78 | 19 | 0.53 | +678 | +35.7 |
| SHOOTERS IN TWO RANKS | 18 | 18 | 18 | 0.50 | +36 | +2.0 |
| WHO HITS BACK | 18 | 18 | 18 | 0.50 | +852 | +47.4 |
| WHOLE FIGHT GAIN | 31 | 31 | 18 | 0.50 | +1544 | +85.8 |
| CAST JOB | 51 | 51 | 17 | 0.47 | +409 | +24.1 |
| CASTING BLOCK | 21 | 21 | 17 | 0.47 | +984 | +57.9 |
| KEEPS ITS TARGET | 110 | 106 | 17 | 0.47 | +272 | +16.0 |
| MARCH ODDS | 17 | 17 | 17 | 0.47 | +103 | +6.1 |
| MAKE SURE TOGETHER | 59 | 42 | 16 | 0.44 | +1470 | +91.8 |
| BIG CHARACTER SAFETY | 15 | 15 | 15 | 0.42 | -35 | -2.3 |
| MANOEUVRE | 19 | 19 | 15 | 0.42 | +646 | +43.1 |
| BEST PREY | 47 | 47 | 14 | 0.39 | +545 | +38.9 |
| INVITES THE FIGHT | 81 | 81 | 14 | 0.39 | +259 | +18.5 |
| STUCK PIVOT | 14 | 14 | 14 | 0.39 | +0 | +0.0 |
| FRIENDS SHOTS CHECKED | 13 | 13 | 13 | 0.36 | +1059 | +81.5 |
| WAR ENGINE JOBS | 32 | 32 | 13 | 0.36 | -350 | -26.9 |
| LOST CHARGE | 187 | 186 | 12 | 0.33 | +266 | +22.2 |
| CHAFF PASSED | 11 | 11 | 11 | 0.31 | -22 | -2.0 |
| PIVOT GUARDS FLANK | 11 | 11 | 11 | 0.31 | -308 | -28.0 |
| WHOLE FIGHT | 27 | 27 | 11 | 0.31 | +803 | +73.0 |
| JOINT AS ONE | 84 | 84 | 10 | 0.28 | -163 | -16.3 |
| CASTER AWAY FROM SCREEN | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| CASTS FROM BEHIND | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| CHARGE BAND | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| WIDER SPREAD | 192 | 180 | 8 | 0.22 | +42 | +5.2 |
| MOVES UNITS SPELL | 7 | 7 | 7 | 0.19 | +141 | +20.1 |
| REFUSING RETIRES | 17 | 17 | 7 | 0.19 | -1 | -0.2 |
| SURE CHARGE BEATS ADVANCE | 7 | 7 | 7 | 0.19 | -254 | -36.2 |
| BEST PRIZE | 6 | 6 | 6 | 0.17 | -103 | -17.1 |
| HUNT IN PAIRS | 34 | 16 | 6 | 0.17 | +261 | +43.6 |
| MISSILES NEXT TURN | 371 | 212 | 6 | 0.17 | +1 | +0.1 |
| OPENS UP | 11 | 10 | 6 | 0.17 | +330 | +55.0 |
| RAIDS THE BAGGAGE NEXT TURN | 6 | 6 | 6 | 0.17 | +166 | +27.8 |
| LONE WIZARD HOLDS BACK | 15 | 15 | 5 | 0.14 | -307 | -61.4 |
| SHORT GUN FORWARD | 5 | 5 | 5 | 0.14 | +0 | +0.0 |
| SUPPORT NARROWED | 481 | 481 | 5 | 0.14 | -72 | -14.3 |
| BACKUP TARGETS | 64 | 34 | 4 | 0.11 | +9 | +2.3 |
| PURSUES BIG PREY | 4 | 4 | 4 | 0.11 | -481 | -120.3 |
| BLOCKED CHARGE SKIPPED | 3 | 3 | 3 | 0.08 | +0 | +0.0 |
| CARRIES OUT SET-UP | 10 | 10 | 3 | 0.08 | -345 | -115.1 |
| CHARIOT NO STATIC JOB | 3 | 3 | 3 | 0.08 | -294 | -97.9 |
| MODEL FACING | 3 | 3 | 3 | 0.08 | +1328 | +442.7 |
| RESTRAINS TO SHOOT | 3 | 3 | 3 | 0.08 | +252 | +83.9 |
| STOPS | 12 | 12 | 3 | 0.08 | +89 | +29.5 |
| CARRIES OUT CLOSE-IN | 18 | 18 | 2 | 0.06 | -226 | -113.0 |
| CARRIES OUT COUNTER | 6 | 6 | 2 | 0.06 | -116 | -58.0 |
| EDGE GIVE GROUND | 13 | 12 | 2 | 0.06 | +263 | +131.6 |
| FOCUS FIRE | 2 | 2 | 2 | 0.06 | +55 | +27.6 |
| HORN WORTH | 2 | 2 | 2 | 0.06 | +24 | +12.2 |
| JOINT CHARGE PLAN | 13 | 13 | 2 | 0.06 | +178 | +88.9 |
| KEEP FALLS | 2 | 2 | 2 | 0.06 | +47 | +23.6 |
| NO RALLY LEFT | 2 | 2 | 2 | 0.06 | +21 | +10.4 |
| OVERRUNS AWAY | 30 | 29 | 2 | 0.06 | +13 | +6.6 |
| PERIAPT WORTH | 2 | 2 | 2 | 0.06 | +154 | +76.9 |
| RAIDS THE BAGGAGE | 2 | 2 | 2 | 0.06 | +338 | +168.8 |
| SPELLS IN THE FIGHT | 37 | 36 | 2 | 0.06 | +15 | +7.6 |
| STAY WEIGHED | 2 | 2 | 2 | 0.06 | +118 | +59.2 |
| BLOWS WHERE AIMED | 29 | 27 | 1 | 0.03 | +57 | +56.7 |
| BOMBING RUN | 1 | 1 | 1 | 0.03 | +27 | +27.1 |
| CATCH ODDS | 1 | 1 | 1 | 0.03 | -2 | -1.8 |
| CONTINUE AHEAD WEIGHED | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| DEFENSIVE ARMY | 6 | 6 | 1 | 0.03 | -22 | -22.0 |
| FIRE AND FLEE | 1 | 1 | 1 | 0.03 | +15 | +15.1 |
| HUNT ADVANCE | 15 | 15 | 1 | 0.03 | +59 | +58.9 |
| KEEPS SCOUTS OR AMBUSH | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| REDIRECT BY WHAT IT STOPS | 39 | 39 | 1 | 0.03 | +2 | +2.0 |
| SAFE SURE CHARGE | 1 | 1 | 1 | 0.03 | -115 | -115.1 |
| STANDS TO CAST | 1 | 1 | 1 | 0.03 | +64 | +63.7 |
| ALREADY CARRIED | 2 | not checked | - | - | - | - |
| ARRIVAL HUNT | 3 | 3 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 33 | 33 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 32 | trace | - | - | - | - |
| CATCH FLIERS | 2 | not checked | - | - | - | - |
| CHARGER SLAIN LOST | 46 | 43 | 0 | 0.00 | - | - |
| CHARIOT WIZARD CAREFUL | 7 | 7 | 0 | 0.00 | - | - |
| CHEAP HELPER | 5 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 36 | not checked | - | - | - | - |
| DEFENSIVE FLOOR | 2 | 2 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT LIFT | 2 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 435 | not checked | - | - | - | - |
| GIVES UP | 5 | 5 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 2 | 2 | 0 | 0.00 | - | - |
| GROUND FLIERS | 1 | not checked | - | - | - | - |
| HELPER ALREADY ASKED | 6 | not checked | - | - | - | - |
| HELPER UNSEEN | 26 | 24 | 0 | 0.00 | - | - |
| HILL BY ITS CHANCE | 21 | 21 | 0 | 0.00 | - | - |
| HUNT DROPPED | 5 | trace | - | - | - | - |
| HUNT KEPT | 14 | trace | - | - | - | - |
| HUNT RESULT | 14 | trace | - | - | - | - |
| HUNT THE GUNS | 18 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 3 | 2 | 0 | 0.00 | - | - |
| KEEPS ITS PREY | 2 | 2 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 24 | not checked | - | - | - | - |
| LONG SHOT | 16 | 15 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 1 | 1 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 7 | trace | - | - | - | - |
| MARCH OVER CASTS | 48 | 48 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 22 | 22 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 8 | 5 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 20 | trace | - | - | - | - |
| MOVE SPELL SPOT | 19 | not checked | - | - | - | - |
| NO CHARGE WHY | 223 | not checked | - | - | - | - |
| NOT NEEDED | 13 | 13 | 0 | 0.00 | - | - |
| NOT TURNED | 438 | 438 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 45 | not checked | - | - | - | - |
| OPENS A LANE | 13 | 7 | 0 | 0.00 | - | - |
| PLAN RESULT | 2670 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 27 | 27 | 0 | 0.00 | - | - |
| SCOUT SPOT | 24 | 24 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 9 | 9 | 0 | 0.00 | - | - |
| SECOND HUNTER | 1 | 1 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 13 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 17 | not checked | - | - | - | - |
| SET-UP MISSED | 1 | trace | - | - | - | - |
| SPELL SETS UP CHARGE | 28 | not checked | - | - | - | - |
| SPELL WORTH | 128 | not checked | - | - | - | - |
| STABLE ROLE | 689 | 686 | 0 | 0.00 | - | - |
| SURE REACH TOGETHER | 41 | 32 | 0 | 0.00 | - | - |
| TURN WORTH | 16 | 16 | 0 | 0.00 | - | - |
| TWO OR MORE ARRIVE | 26 | 20 | 0 | 0.00 | - | - |
| WAR ENGINE CHARGES | 2 | 2 | 0 | 0.00 | - | - |
| WOUNDED STAYS OUT | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: su-h2h-opp-e45904b-p3

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 14.78 | 11.67 | 55.0 |
| TURN GATE | gate | 0.86 | 0.75 | 31.6 |
| FALLBACK | gate | 0.72 | 0.81 | 52.3 |
| CHARGE NOW FIRST | rule | 0.50 | 0.44 | 67.2 |
| NO REASON | gate | - | 0.69 | 29.3 |
| CANNON PLANNED TARGET | rule | 0.28 | 0.06 | 53.5 |
| WAR ENGINE JOBS | rule | 0.31 | 0.03 | 29.1 |
| LONE CHARACTER SAFE SPOT | gate | 0.08 | 0.22 | 103.9 |
| PIVOT GUARDS FLANK | rule | 0.17 | 0.14 | 28.0 |
| JOINT AS ONE | rule | - | 0.25 | 18.1 |
| SUPPORT REQUEST | gate | 0.08 | 0.17 | 63.5 |
| PATHS CROSS | rule | 0.06 | 0.17 | 16.8 |
| BIG CHARACTER SAFETY | rule | 0.11 | 0.08 | 10.8 |
| CHAFF PASSED | rule | 0.03 | 0.17 | 3.1 |
| BEST PRIZE | rule | 0.11 | 0.06 | 17.1 |
| SURE CHARGE BEATS ADVANCE | rule | 0.03 | 0.14 | 42.2 |
| CHARGE NOW WEIGHED | rule | 0.06 | 0.08 | 35.9 |
| LONE WIZARD HOLDS BACK | rule | 0.08 | 0.06 | 61.4 |
| SUPPORT NARROWED | rule | 0.08 | 0.06 | 14.3 |
| AFTERMATH BAND | gate | - | 0.11 | 1.6 |
| AFTERMATH NEEDS NEXT CHARGE | gate | - | 0.11 | 146.7 |
| MARCH ODDS | rule | 0.08 | 0.03 | 11.3 |
| PURSUES BIG PREY | rule | - | 0.11 | 120.3 |
| CARRIES OUT SET-UP | rule | 0.03 | 0.06 | 115.1 |
| CHARIOT NO STATIC JOB | rule | 0.08 | - | 97.9 |
| STOPS SHORT OF THE FLANK | rule | 0.06 | 0.03 | 2.8 |
| BLOCKED WHEEL | rule | 0.03 | 0.03 | 5.4 |
| CARRIES OUT CLOSE-IN | rule | - | 0.06 | 113.0 |
| CARRIES OUT COUNTER | rule | 0.06 | - | 58.0 |
| FACES THE THREAT | rule | 0.03 | 0.03 | 16.6 |
| SAFER THAN THE JOB | rule | 0.03 | 0.03 | 17.0 |
| SET-UP SPOT | rule | - | 0.06 | 14.3 |
| CATCH ODDS | rule | 0.03 | - | 1.8 |
| DEFENSIVE ARMY | rule | 0.03 | - | 22.0 |
| FIGHT ORDER BAND | gate | 0.03 | - | 2.8 |
| RULE SWITCHED OFF | gate | 0.03 | - | 32.3 |
| SAFE SURE CHARGE | rule | - | 0.03 | 115.1 |
| THROUGH LINE OF FIRE | rule | 0.03 | - | 4.2 |
| WHO HITS BACK | rule | 0.03 | - | 0.6 |

### Plans: su-h2h-opp-e45904b-p3

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 11.5 | 13% | 423 | 228 | 54% |
| Mine | charge | 2.6 | 58% | 211 | 216 | 102% |
| Mine | close in | 4.3 | 25% | 285 | 95 | 33% |
| Mine | hold | 4.3 | 40% | 263 | 0 | 0% |
| Mine | join | 0.4 | 88% | 8 | 0 | 0% |
| Mine | shoot | 9.1 | 63% | 195 | 639 | 328% |
| Mine | support | 4.3 | 92% | 40 | 0 | 0% |
| Opponent | advance | 12.4 | 19% | 333 | 403 | 121% |
| Opponent | charge | 4.3 | 58% | 387 | 504 | 130% |
| Opponent | close in | 5.0 | 31% | 258 | 187 | 73% |
| Opponent | hold | 3.8 | 31% | 268 | 0 | 0% |
| Opponent | join | 0.9 | 94% | 34 | 0 | 0% |
| Opponent | shoot | 5.1 | 54% | 189 | 448 | 236% |
| Opponent | support | 6.2 | 91% | 60 | 0 | 0% |

### Packages: hunt the guns, su-h2h-opp-e45904b-p3

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.2 | 8 | 2 | 17% | 17% | 0% | 2.0 | 362 | 35 | 17% | 43 |
| Opponent | 0.3 | 10 | 2 | 25% | 25% | 12% | 2.0 | 297 | 51 | 25% | 86 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 1.2 | 5 | 2 | 0% | 0% | 0% | - | 373 | 0 | 0% | 26 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 63 |
| Empire of Man | 0.3 | 2 | 0 | 0% | 0% | 0% | - | 417 | 0 | 0% | 134 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 75 |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 73 |
| Kingdom of Bretonnia | 0.3 | 1 | 0 | 0% | 0% | 0% | - | 325 | 0 | 0% | 309 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Ogre Kingdoms | 1.0 | 1 | 0 | 100% | 100% | 0% | 2.0 | 220 | 212 | 100% | 0 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 52 |
| Tomb Kings of Khemri | 0.5 | 3 | 1 | 0% | 0% | 50% | - | 469 | 7 | 0% | 24 |
| Vampire Counts | 0.5 | 4 | 1 | 67% | 67% | 0% | 2.0 | 204 | 132 | 67% | 45 |
| Warriors of Chaos | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 42 |
| Wood Elf Realms | 0.3 | 2 | 0 | 0% | 0% | 0% | - | 251 | 0 | 0% | 74 |

### Battle groups: su-h2h-opp-e45904b-p3

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 10.8 | 23% | 64% | 19% | 41% | 34% | 18% | 8% | 40% | 0% |
| Mine | REDIRECT COUNTER | 2.1 | 25% | 63% | 16% | 0% | 31% | 6% | 0% | 62% | 0% |
| Opponent | COUNTER-CHARGE COVER | 7.5 | 18% | 64% | 18% | 22% | 51% | 0% | 12% | 37% | 0% |
| Opponent | REDIRECT COUNTER | 3.8 | 19% | 73% | 27% | 14% | 11% | 0% | 11% | 79% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: su-h2h-opp-e45904b-p3

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 1 | 346 (1) | 346 | 0 | 0 | 0% | 4.0 | 346 (1) | - | - | 346 (1) | - |
| Mine | Chaff | 34 | 43 (34) | 7 | 35 | 36 | 32% | 2.4 | 60 (21) | 0 (4) | 12 (9) | 63 (24) | 0 (10) |
| Mine | Character | 118 | 35 (118) | 35 | 0 | 38 | 22% | 2.3 | 39 (37) | 40 (58) | 24 (7) | 38 (56) | 40 (46) |
| Mine | Clean-up | 18 | 68 (18) | 28 | 40 | 48 | 56% | 2.5 | 101 (3) | 66 (13) | 21 (2) | 97 (12) | 25 (6) |
| Mine | Fast | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Mine | Fast Hammer | 44 | 23 (44) | 12 | 11 | 61 | 27% | 3.0 | 20 (22) | 19 (14) | 37 (8) | 29 (30) | 12 (14) |
| Mine | Fragile | 3 | 10 (3) | 10 | 0 | 33 | 67% | 4.0 | 10 (3) | - | - | 0 (1) | 15 (2) |
| Mine | Hammer | 52 | 42 (52) | 27 | 15 | 43 | 19% | 2.5 | 13 (14) | 54 (35) | 36 (3) | 36 (36) | 55 (16) |
| Mine | Holder | 25 | 65 (25) | 9 | 56 | 42 | 40% | 3.3 | 31 (7) | 79 (13) | 89 (4) | 89 (14) | 38 (10) |
| Mine | Shooter | 37 | 56 (37) | 30 | 26 | 55 | 3% | 1.8 | 105 (6) | 52 (28) | 0 (3) | 52 (22) | 61 (15) |
| Mine | Support | 4 | 0 (4) | 0 | 0 | 58 | 0% | 3.0 | 0 (1) | - | - | 0 (1) | - |
| Mine | War machine | 52 | 48 (52) | 48 | 0 | 47 | 0% | 1.1 | 45 (13) | 53 (36) | 0 (3) | 37 (13) | 52 (39) |
| Mine | Wizard | 17 | 8 (17) | 8 | 0 | 49 | 12% | 1.8 | 0 (4) | 6 (8) | 63 (1) | 13 (7) | 8 (6) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Chaff | 68 | 56 (68) | 34 | 22 | 46 | 46% | 2.9 | 95 (29) | 20 (11) | 43 (28) | 43 (48) | 86 (20) |
| Opponent | Character | 102 | 54 (102) | 54 | 0 | 27 | 25% | 2.0 | 48 (37) | 65 (50) | 16 (6) | 58 (54) | 54 (39) |
| Opponent | Clean-up | 11 | 76 (11) | 4 | 72 | 36 | 27% | 4.0 | 0 (4) | 105 (6) | 185 (1) | 42 (6) | 109 (5) |
| Opponent | Fast | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Fast Hammer | 60 | 43 (60) | 22 | 21 | 38 | 35% | 2.4 | 28 (30) | 48 (20) | 80 (10) | 51 (28) | 35 (32) |
| Opponent | Fragile | 3 | 54 (3) | 54 | 0 | 67 | 33% | 2.0 | - | 81 (2) | 0 (1) | 0 (2) | 162 (1) |
| Opponent | Hammer | 50 | 55 (50) | 40 | 15 | 33 | 24% | 3.2 | 8 (17) | 74 (30) | 25 (3) | 57 (30) | 53 (20) |
| Opponent | Holder | 40 | 73 (40) | 22 | 51 | 22 | 45% | 2.6 | 50 (10) | 77 (20) | 108 (9) | 86 (27) | 54 (12) |
| Opponent | Shooter | 27 | 66 (27) | 35 | 31 | 24 | 0% | 1.3 | 70 (6) | 49 (19) | 308 (2) | 69 (16) | 63 (11) |
| Opponent | Support | 4 | 0 (4) | 0 | 0 | 0 | 100% | - | 0 (3) | - | 0 (1) | 0 (1) | 0 (3) |
| Opponent | War machine | 17 | 75 (17) | 75 | 0 | 18 | 0% | 1.4 | 142 (3) | 32 (10) | 130 (4) | 0 (3) | 88 (14) |
| Opponent | Wizard | 32 | 28 (32) | 28 | 0 | 35 | 16% | 2.3 | 23 (15) | 38 (12) | 0 (2) | 26 (15) | 27 (14) |

### Charged fights: su-h2h-opp-e45904b-p3

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 70 | 208 | 1.2 | 1.0 | 167 | 60 | +106 | 1 of 5 | 4 of 5 | - | +106 |
| Mine | Chaos Dwarfs | 4 | 234 | 402 | 1.5 | 1.0 | 268 | 0 | +268 | 3 of 6 | 6 of 6 | - | +268 |
| Mine | Dwarfen Mountain Holds | 3 | 508 | 0 | 1.0 | 1.0 | 0 | 62 | -62 | 0 of 3 | 1 of 3 | - | -62 |
| Mine | Empire of Man | 5 | 340 | 95 | 0.6 | 1.0 | 158 | 0 | +158 | 2 of 3 | 3 of 3 | - | +158 |
| Mine | Grand Cathay | 5 | 191 | 159 | 3.4 | 1.1 | 47 | 87 | -41 | 8 of 17 | 11 of 17 | -320 | -3 |
| Mine | High Elf Realms | 4 | 120 | 288 | 3.2 | 1.1 | 88 | 13 | +75 | 7 of 13 | 8 of 13 | -115 | +91 |
| Mine | Kingdom of Bretonnia | 1 | 0 | 1691 | 4.0 | 1.5 | 423 | 69 | +354 | 1 of 4 | 3 of 4 | +331 | +361 |
| Mine | Lizardmen | 1 | 317 | 402 | 3.0 | 1.3 | 134 | 304 | -170 | 1 of 3 | 2 of 3 | -175 | -168 |
| Mine | Ogre Kingdoms | 1 | 116 | 311 | 3.0 | 1.0 | 104 | 0 | +104 | 1 of 3 | 0 of 3 | - | +104 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 135 | 1.0 | 1.0 | 135 | 0 | +135 | 0 of 1 | 1 of 1 | - | +135 |
| Mine | Skaven | 1 | 19 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Mine | Tomb Kings of Khemri | 2 | 132 | 346 | 3.5 | 1.1 | 99 | 0 | +99 | 4 of 7 | 5 of 7 | +0 | +115 |
| Mine | Vampire Counts | 2 | 106 | 421 | 4.5 | 1.1 | 94 | 57 | +36 | 4 of 9 | 7 of 9 | +0 | +41 |
| Mine | Warriors of Chaos | 2 | 62 | 186 | 2.5 | 1.0 | 74 | 81 | -7 | 1 of 5 | 2 of 5 | - | -7 |
| **Mine** | all armies | 36 | 193 | 258 | 2.2 | 1.1 | 118 | 54 | +64 | 33 of 79 | 53 of 79 | -85 | +78 |
| Opponent | Empire of Man | 1 | 807 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Grand Cathay | 3 | 352 | 346 | 2.0 | 1.2 | 173 | 0 | +173 | 2 of 6 | 6 of 6 | +485 | +110 |
| Opponent | High Elf Realms | 3 | 386 | 302 | 2.3 | 1.0 | 129 | 71 | +58 | 4 of 7 | 5 of 7 | - | +58 |
| Opponent | Kingdom of Bretonnia | 2 | 95 | 0 | 1.5 | 1.0 | 0 | 157 | -157 | 2 of 3 | 1 of 3 | - | -157 |
| Opponent | Orc & Goblin Tribes | 1 | 0 | 199 | 4.0 | 1.2 | 50 | 14 | +36 | 1 of 4 | 3 of 4 | +199 | -18 |
| Opponent | Skaven | 1 | 105 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Tomb Kings of Khemri | 4 | 214 | 651 | 4.8 | 1.2 | 137 | 0 | +137 | 6 of 19 | 16 of 19 | +269 | +102 |
| Opponent | Vampire Counts | 6 | 0 | 528 | 4.2 | 1.1 | 127 | 31 | +95 | 10 of 25 | 21 of 25 | +560 | +55 |
| Opponent | Warriors of Chaos | 9 | 0 | 572 | 4.0 | 1.2 | 143 | 18 | +125 | 18 of 36 | 26 of 36 | +216 | +113 |
| Opponent | Wood Elf Realms | 6 | 104 | 222 | 2.8 | 1.1 | 78 | 36 | +42 | 6 of 17 | 11 of 17 | -62 | +56 |
| **Opponent** | all armies | 36 | 133 | 400 | 3.2 | 1.1 | 123 | 26 | +97 | 49 of 117 | 89 of 117 | +258 | +75 |

### Effective charges: su-h2h-opp-e45904b-p3

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 5 | 1 (net +0) | 1 (net +50) | 0 | 0 | 0 | 1 (net +277) | 2 | 0% (0 of 3) |
| Mine | Chaos Dwarfs | 6 | 1 (net +0) | 1 (net +757) | 0 | 3 (net +224) | 0 | 0 | 1 | 0% (0 of 5) |
| Mine | Dwarfen Mountain Holds | 3 | 0 | 1 (net -65) | 0 | 1 (net -60) | 0 | 0 | 1 | 0% (0 of 2) |
| Mine | Empire of Man | 3 | 0 | 0 | 1 (net +0) | 2 (net +238) | 0 | 0 | 0 | 33% (1 of 3) |
| Mine | Grand Cathay | 17 | 1 (net -205) | 2 (net +40) | 4 (net -160) | 1 (net +0) | 4 (net +59) | 5 (net -32) | 0 | 24% (4 of 17) |
| Mine | High Elf Realms | 13 | 1 (net +104) | 1 (net -115) | 1 (net +431) | 2 (net -30) | 2 (net +180) | 6 (net +42) | 0 | 8% (1 of 13) |
| Mine | Kingdom of Bretonnia | 4 | 0 | 0 | 1 (net +331) | 1 (net +505) | 1 (net +342) | 1 (net +236) | 0 | 25% (1 of 4) |
| Mine | Lizardmen | 3 | 1 (net -175) | 0 | 0 | 0 | 1 (net -216) | 0 | 1 | 0% (0 of 2) |
| Mine | Ogre Kingdoms | 3 | 2 (net +98) | 0 | 0 | 0 | 0 | 0 | 1 | 0% (0 of 2) |
| Mine | Tomb Kings of Khemri | 7 | 0 | 0 | 2 (net +0) | 3 (net +209) | 1 (net +0) | 1 (net +66) | 0 | 29% (2 of 7) |
| Mine | Vampire Counts | 9 | 0 | 1 (net +0) | 4 (net -40) | 0 | 0 | 3 (net +136) | 1 | 50% (4 of 8) |
| Mine | Warriors of Chaos | 5 | 1 (net -286) | 1 (net +30) | 0 | 1 (net +0) | 0 | 0 | 2 | 0% (0 of 3) |
| Opponent | Grand Cathay | 6 | 0 | 0 | 1 (net +0) | 1 (net +85) | 1 (net +0) | 3 (net +317) | 0 | 17% (1 of 6) |
| Opponent | High Elf Realms | 7 | 1 (net -347) | 2 (net +178) | 0 | 1 (net +354) | 0 | 1 (net +0) | 2 | 0% (0 of 5) |
| Opponent | Kingdom of Bretonnia | 3 | 0 | 0 | 0 | 0 | 0 | 2 (net -236) | 1 | 0% (0 of 2) |
| Opponent | Orc & Goblin Tribes | 4 | 0 | 0 | 1 (net +199) | 0 | 0 | 0 | 3 | 100% (1 of 1) |
| Opponent | Tomb Kings of Khemri | 19 | 4 (net +212) | 0 | 1 (net +0) | 4 (net +190) | 5 (net +70) | 5 (net +129) | 0 | 5% (1 of 19) |
| Opponent | Vampire Counts | 25 | 7 (net +77) | 2 (net -204) | 4 (net +344) | 9 (net +103) | 2 (net +68) | 0 | 1 | 17% (4 of 24) |
| Opponent | Warriors of Chaos | 36 | 4 (net -15) | 2 (net -232) | 6 (net +128) | 13 (net +188) | 1 (net +0) | 7 (net +227) | 3 | 18% (6 of 33) |
| Opponent | Wood Elf Realms | 17 | 2 (net +0) | 0 | 2 (net +80) | 2 (net -95) | 0 | 3 (net +112) | 8 | 22% (2 of 9) |

### Charged fights, damage counted: su-h2h-opp-e45904b-p3

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 8 | 191 | 287 | -46 | 42 | 111 | -69 | -35.9 |
| Mine | 50-54% | 8 | 214 | 227 | +92 | 189 | 81 | +108 | +50.5 |
| Mine | Effective (55-75%) | 13 | 348 | 308 | -3 | 135 | 136 | -2 | -0.5 |
| Mine | 76-89% | 14 | 325 | 194 | +154 | 171 | 16 | +155 | +47.9 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 17 | 296 | 198 | +64 | 104 | 45 | +59 | +19.9 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 9 | 383 | 77 | +80 | 117 | 37 | +80 | +20.9 |
| Mine | No odds | 10 | 304 | 204 | +76 | 150 | 77 | +74 | +24.3 |
| Mine | All fights | 79 | 302 | 214 | +64 | 131 | 68 | +62 | +20.7 |
| Opponent | Long shot (under 50%) | 18 | 220 | 231 | +54 | 136 | 40 | +96 | +43.6 |
| Opponent | 50-54% | 6 | 290 | 278 | -86 | 127 | 183 | -56 | -19.2 |
| Opponent | Effective (55-75%) | 15 | 397 | 260 | +167 | 176 | 27 | +149 | +37.5 |
| Opponent | 76-89% | 30 | 261 | 202 | +146 | 166 | 26 | +140 | +53.6 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 21 | 327 | 241 | +145 | 220 | 66 | +153 | +46.8 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 9 | 439 | 87 | +54 | 54 | 0 | +54 | +12.3 |
| Opponent | No odds | 18 | 201 | 189 | +24 | 58 | 32 | +26 | +12.8 |
| Opponent | All fights | 117 | 290 | 214 | +97 | 145 | 43 | +102 | +35.3 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| su-h2h-opp-e45904b-p3 | move | 435 | 80 (18%) | 58 (13%) | 56 (13%) | 299 (69%) |
| su-h2h-opp-e45904b-p3 | objective | 338 | 56 (17%) | 40 (12%) | 50 (15%) | 232 (69%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0110, L0126, L2433, L2630 |
| Charmed Shield | Opponent | L0126, L0226, L0327, L0725, L1327, L2327 |
| Clockwork Compass | Mine | L1216, L1232 |
| Elixir of Power | Mine | L1122, L1932 |
| Elixir of Power | Opponent | L0311, L1519 |
| Fistful of Laurels | Mine | L1831 |
| Horn of the Wild Hunt | Opponent | L0533, L1633, L2033, L2433, L3133 |
| Invocation of Nehek | Mine | L2433 |
| Invocation of Nehek | Opponent | L0327, L0725, L1327, L2327 |
| Opal Amulet | Mine | L1422 |
| Periapt of Soul Exchange | Mine | L2033 |
| Periapt of Soul Exchange | Opponent | L0620 |
| Ring of Doom | Mine | L0210, L0226, L1122, L1216, L1232, L1519, L1535, L3133 |
| Ring of Doom | Opponent | L0311, L0533, L0815, L0831, L1633, L1731, L1831, L2033, L2433, L3133 |
| Ring of Jet | Mine | L1013, L1030, L1122, L1216, L1232 |
| Ring of Jet | Opponent | L0110, L0210, L0311 |
| Standard of the Fell Warrior | Mine | L1327 |
| Standard of the Fell Warrior | Opponent | L0413, L1013 |
| Twice-Blessed Armour | Mine | L0709, L0725, L1013, L1030 |
| Twice-Blessed Armour | Opponent | L0110, L0210 |
| Witch Hunter's Ward | Mine | L0709, L0725, L0815, L0831 |

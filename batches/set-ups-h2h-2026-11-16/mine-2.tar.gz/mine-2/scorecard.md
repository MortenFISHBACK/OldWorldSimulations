# Doctrine scorecard: su-h2h-mine-e45904b-p2

### Scorecard: su-h2h-mine-e45904b-p2

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0106 | 4 | 1 | Mine | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 387 |
| L0106 | 4 | 1 | Opponent | no | 0 | 4 | 2 | 1 | 1 | 0 | 0 | 981 |
| L0122 | 2 | 1 | Mine | - | - | 6 | 1 | 2 | 0 | 0 | 0 | 322 |
| L0122 | 2 | 1 | Opponent | - | - | 2 | 3 | 0 | 1 | 0 | 0 | 0 |
| L0206 | 2 | 1 | Mine | - | - | 2 | 1 | 3 | 0 | 0 | 0 | 0 |
| L0206 | 2 | 1 | Opponent | - | - | 4 | 0 | 0 | 0 | 0 | 0 | 615 |
| L0222 | 6 | 1 | Mine | no | 0 | 2 | 3 | 3 | 1 | 0 | 0 | 170 |
| L0222 | 6 | 1 | Opponent | no | 6 | 2 | 1 | 0 | 0 | 0 | 0 | 55 |
| L0307 | 1 | 1 | Mine | no | 0 | 3 | 0 | 2 | 0 | 0 | 0 | 675 |
| L0307 | 1 | 1 | Opponent | yes | 5 | 2 | 1 | 1 | 1 | 0 | 0 | 420 |
| L0323 | 5 | 1 | Mine | no | - | 2 | 1 | 3 | 0 | 0 | 0 | 590 |
| L0323 | 5 | 1 | Opponent | yes | - | 2 | 0 | 2 | 0 | 0 | 0 | 0 |
| L0409 | 1 | 1 | Mine | no | 4 | 2 | 2 | 0 | 0 | 0 | 0 | 0 |
| L0409 | 1 | 1 | Opponent | no | 6 | - | 0 | 1 | 0 | 0 | 0 | 886 |
| L0425 | 5 | 1 | Mine | yes | - | 2 | 3 | 2 | 1 | 0 | 0 | 0 |
| L0425 | 5 | 1 | Opponent | yes | - | - | 5 | 4 | 1 | 0 | 0 | 0 |
| L0512 | 2 | 1 | Mine | - | - | - | 1 | 1 | 0 | 0 | 0 | 1448 |
| L0512 | 2 | 1 | Opponent | - | - | 2 | 2 | 3 | 1 | 0 | 0 | 330 |
| L0528 | 6 | 1 | Mine | no | 0 | 4 | 1 | 1 | 0 | 0 | 0 | 475 |
| L0528 | 6 | 1 | Opponent | no | 8 | - | 0 | 2 | 0 | 0 | 0 | 0 |
| L0616 | 4 | 1 | Mine | no | 0 | 4 | 1 | 1 | 0 | 0 | 0 | 615 |
| L0616 | 4 | 1 | Opponent | no | 8 | 2 | 1 | 0 | 1 | 0 | 0 | 200 |
| L0632 | 2 | 1 | Mine | - | - | 2 | 3 | 0 | 0 | 0 | 0 | 1176 |
| L0632 | 2 | 1 | Opponent | - | - | 2 | 2 | 3 | 2 | 0 | 0 | 170 |
| L0721 | 1 | 1 | Mine | yes | 3 | 2 | 4 | 0 | 0 | 0 | 0 | 295 |
| L0721 | 1 | 1 | Opponent | no | 0 | - | 0 | 5 | 1 | 0 | 0 | 355 |
| L0810 | 6 | 1 | Mine | no | 0 | 6 | 1 | 2 | 0 | 0 | 0 | 605 |
| L0810 | 6 | 1 | Opponent | no | 10 | 2 | 2 | 0 | 0 | 0 | 0 | 330 |
| L0827 | 5 | 1 | Mine | no | - | 3 | 1 | 1 | 0 | 0 | 0 | 807 |
| L0827 | 5 | 1 | Opponent | yes | - | 2 | 2 | 5 | 0 | 0 | 0 | 0 |
| L0918 | 6 | 1 | Mine | no | 0 | 3 | 2 | 0 | 0 | 0 | 0 | 420 |
| L0918 | 6 | 1 | Opponent | no | 9 | 2 | 3 | 1 | 0 | 0 | 0 | 419 |
| L0934 | 4 | 1 | Mine | no | 0 | - | 0 | 0 | 0 | 0 | 0 | 808 |
| L0934 | 4 | 1 | Opponent | yes | 4 | 2 | 6 | 2 | 0 | 0 | 0 | 160 |
| L1026 | 6 | 1 | Mine | no | 1 | 2 | 3 | 1 | 2 | 0 | 0 | 330 |
| L1026 | 6 | 1 | Opponent | no | 9 | 2 | 4 | 4 | 1 | 0 | 0 | 0 |
| L1118 | 2 | 1 | Mine | - | - | 2 | 5 | 0 | 0 | 0 | 0 | 330 |
| L1118 | 2 | 1 | Opponent | - | - | 5 | 1 | 0 | 0 | 0 | 0 | 370 |
| L1135 | 1 | 1 | Mine | yes | 4 | 3 | 4 | 0 | 0 | 0 | 0 | 330 |
| L1135 | 1 | 1 | Opponent | no | 0 | 3 | 3 | 3 | 1 | 0 | 0 | 0 |
| L1228 | 4 | 1 | Mine | no | 2 | 3 | 3 | 0 | 0 | 0 | 0 | 524 |
| L1228 | 4 | 1 | Opponent | no | 5 | 4 | 1 | 2 | 0 | 0 | 0 | 111 |
| L1323 | 3 | 1 | Mine | yes | 1 | - | 1 | 0 | 0 | 0 | 0 | 140 |
| L1323 | 3 | 1 | Opponent | no | 0 | 1 | 3 | 0 | 0 | 0 | 0 | 0 |
| L1418 | 2 | 1 | Mine | - | - | 2 | 5 | 1 | 0 | 0 | 0 | 0 |
| L1418 | 2 | 1 | Opponent | - | - | 2 | 2 | 2 | 0 | 0 | 0 | 0 |
| L1435 | 1 | 1 | Mine | no | 0 | 2 | 3 | 2 | 0 | 0 | 0 | 0 |
| L1435 | 1 | 1 | Opponent | no | 0 | 3 | 1 | 2 | 0 | 0 | 0 | 0 |
| L1531 | 1 | 1 | Mine | no | 0 | 3 | 2 | 1 | 0 | 0 | 0 | 0 |
| L1531 | 1 | 1 | Opponent | yes | 0 | 2 | 3 | 0 | 0 | 0 | 0 | 340 |
| L1629 | 3 | 1 | Mine | no | 4 | 1 | 1 | 1 | 0 | 0 | 0 | 200 |
| L1629 | 3 | 1 | Opponent | no | 0 | 2 | 0 | 1 | 1 | 0 | 0 | 170 |
| L1727 | 5 | 1 | Mine | no | - | 3 | 2 | 0 | 0 | 0 | 0 | 0 |
| L1727 | 5 | 1 | Opponent | yes | - | 2 | 2 | 4 | 0 | 0 | 0 | 0 |
| L1827 | 3 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 297 |
| L1827 | 3 | 1 | Opponent | no | 8 | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| L1927 | 1 | 1 | Mine | no | 1 | 1 | 2 | 0 | 0 | 0 | 0 | 0 |
| L1927 | 1 | 1 | Opponent | no | 0 | 2 | 5 | 3 | 0 | 0 | 0 | 0 |
| L2029 | 1 | 1 | Mine | no | 0 | - | 2 | 1 | 0 | 0 | 0 | 860 |
| L2029 | 1 | 1 | Opponent | no | 0 | 3 | 3 | 1 | 0 | 0 | 0 | 170 |
| L2131 | 1 | 1 | Mine | yes | 8 | 6 | 2 | 3 | 1 | 0 | 0 | 145 |
| L2131 | 1 | 1 | Opponent | no | 4 | 4 | 1 | 1 | 1 | 0 | 0 | 170 |
| L2235 | 3 | 1 | Mine | no | 3 | 2 | 3 | 0 | 0 | 0 | 0 | 0 |
| L2235 | 3 | 1 | Opponent | no | 0 | 4 | 3 | 0 | 1 | 0 | 0 | 126 |
| L2429 | 5 | 1 | Mine | yes | - | 2 | 1 | 1 | 0 | 0 | 0 | 0 |
| L2429 | 5 | 1 | Opponent | yes | - | 3 | 4 | 4 | 0 | 0 | 0 | 0 |
| L2535 | 3 | 1 | Mine | no | 4 | 5 | 1 | 2 | 1 | 0 | 0 | 0 |
| L2535 | 3 | 1 | Opponent | no | 2 | 1 | 8 | 1 | 0 | 0 | 0 | 140 |
| L2735 | 5 | 1 | Mine | yes | - | 2 | 1 | 2 | 0 | 0 | 0 | 0 |
| L2735 | 5 | 1 | Opponent | yes | - | 2 | 5 | 2 | 0 | 0 | 0 | 0 |
| L3033 | 3 | 1 | Mine | yes | 2 | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L3033 | 3 | 1 | Opponent | no | 3 | 1 | 6 | 2 | 0 | 0 | 0 | 549 |
| **Average** | | | Mine | 27% | 1.5 | 2.8 | 1.9 | 1.1 | 0.2 | 0.0 | 0.0 | 331.9 |
| **Average** | | | Opponent | 30% | 3.6 | 2.4 | 2.4 | 1.8 | 0.4 | 0.0 | 0.0 | 196.3 |

### KPIs: su-h2h-mine-e45904b-p2

Rules off - Opponent only: SET-UP SPOT, CARRIES OUT CLOSE-IN, JOINT AS ONE.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 32% (57 of 180) | 14% (25 of 175) | 23% (82 of 355) |
| Winner chose to follow up after the loser gave ground |  | 97% (69 of 71); on the table 97% | 95% (41 of 43); on the table 98% | 96% (110 of 114); on the table 97% |
| Winner chose to pursue after the loser fell back in good order |  | 100% (10 of 10); on the table 100% | 94% (15 of 16); on the table 100% | 96% (25 of 26); on the table 100% |
| Winner chose to pursue after the loser fled |  | 77% (20 of 26); on the table 77% | 74% (25 of 34); on the table 76% | 75% (45 of 60); on the table 77% |
| Winner chose to follow up or pursue (all three) |  | 93% (99 of 107); on the table 93% | 87% (81 of 93); on the table 90% | 90% (180 of 200); on the table 92% |
| Magic missiles tried each own turn | 50%+ | 32% (108 of 342) | 38% (60 of 156) | 34% (168 of 498) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 47% (108 of 229) | 48% (60 of 125) | 47% (168 of 354) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 39% (9 of 23) | 55% (29 of 53) | 50% (38 of 76) |
| Points that never fought | lower | 36% (26015 of 71583) | 41% (29413 of 71989) | 39% (55428 of 143572) |
|   infantry points that never fought | lower | 44% (7128 of 16324) | 69% (9645 of 14029) | 55% (16773 of 30353) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 65% (184 of 284) | 58% (171 of 297) | 61% (355 of 581) |
| Bound items with a magic missile used (at least once a game) |  | 95% (19 of 20); 1.8 uses a game | 72% (13 of 18); 1.1 uses a game | 84% (32 of 38); 1.5 uses a game |
| Bound items with another spell used |  | 50% (9 of 18); 0.5 uses a game | 50% (1 of 2); 0.0 uses a game | 50% (10 of 20); 0.3 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 55% (11 of 20); 0.3 uses a game | 29% (2 of 7); 0.1 uses a game | 48% (13 of 27); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 62% (37044 of 60231) | 51% (32436 of 63281) | 56% (69480 of 123512) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.8 (27%) | 0.8 (31%) | 2.6 (28%) |
| MARCHED: its unit marched | 1.1 (16%) | 0.6 (21%) | 1.6 (18%) |
| CHARGED: its unit charged | 0.3 (5%) | 0.0 (1%) | 0.3 (4%) |
| IN COMBAT: engaged in combat | 1.4 (22%) | 0.4 (17%) | 1.9 (20%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.2 (7%) | 0.2 (2%) |
| FLEEING: fleeing | 0.0 (0%) | 0.1 (3%) | 0.1 (1%) |
| GONE: slain | 1.6 (24%) | 0.2 (6%) | 1.8 (19%) |
| OFF THE TABLE: off the table or not arrived | 0.1 (2%) | 0.2 (6%) | 0.3 (3%) |
| STUPIDITY: Stupidity | 0.2 (3%) | 0.0 (1%) | 0.2 (2%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.1 (1%) | 0.1 (5%) | 0.2 (2%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.0 | 1.6 | 1.1 | 4.7 | 0.6 | 1.9 |
| not cast | 3.9 | 3.4 | 3.9 | 9.2 | 1.8 | 19.7 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) | 1.6 (8%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.6 (48%) | 0.2 (4%) | 2.6 (28%) | 0.4 (22%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.6 (18%) | 0.3 (17%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (4%) | 0.1 (6%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.1 (2%) | 0.2 (6%) | 0.6 (15%) | 1.9 (20%) | 0.4 (20%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.4 (10%) | 0.3 (10%) | 0.4 (10%) | 0.2 (2%) | 0.0 (0%) | 0.0 (0%) |
| NO CASTS LEFT: every cast used on other spells | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (5%) | 0.0 (0%) |
| FLEEING: fleeing | 0.1 (2%) | 0.0 (0%) | 0.0 (1%) | 0.1 (1%) | 0.0 (2%) | 0.4 (2%) |
| GONE: slain | 1.0 (26%) | 0.9 (25%) | 0.9 (22%) | 1.8 (19%) | 0.2 (14%) | 3.4 (17%) |
| OFF THE TABLE: off the table or not arrived | 0.1 (2%) | 0.0 (1%) | 0.1 (3%) | 0.3 (3%) | 0.0 (2%) | 0.5 (3%) |
| STUPIDITY: Stupidity | 0.1 (2%) | 0.0 (0%) | 0.1 (1%) | 0.2 (2%) | 0.0 (0%) | 0.3 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (1%) | 0.2 (7%) | 0.0 (0%) | 0.0 (0%) | 0.2 (12%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (2%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.1 (55%) | 0.1 (3%) | 1.6 (42%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 13.5 (68%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.6 a game | 0.7 a game | 0.6 a game |
| stood (cast and not dispelled) | 79% (15 of 19) | 62% (15 of 24) | 70% (30 of 43) |
| the unit moved after it | 67% (10 of 15) | 33% (5 of 15) | 50% (15 of 30) |
| it charged on its next turn | 0% (0 of 15) | 20% (3 of 15) | 10% (3 of 30) |
| the enemy charged it first | 0% (0 of 15) | 7% (1 of 15) | 3% (1 of 30) |
| it fought by the end of its next turn | 0% (0 of 15) | 7% (1 of 15) | 3% (1 of 30) |
| it moved out of a charge the enemy had planned (not charged first) | 7% (1 of 15) | 33% (5 of 15) | 20% (6 of 30) |
| none of these (no charge, no fight, no charge escaped) | 93% (14 of 15) | 47% (7 of 15) | 70% (21 of 30) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 66% (560 of 854) | 56% (455 of 808) | 61% (1015 of 1662) |
|   cavalry | 67% (56 of 83) | 59% (97 of 164) | 62% (153 of 247) |
|   character | 46% (48 of 105) | 30% (33 of 110) | 38% (81 of 215) |
|   chariot | 55% (62 of 112) | 73% (32 of 44) | 60% (94 of 156) |
|   infantry | 59% (143 of 243) | 57% (181 of 319) | 58% (324 of 562) |
|   monster | 64% (25 of 39) | 51% (19 of 37) | 58% (44 of 76) |
|   war machine | 83% (226 of 272) | 69% (93 of 134) | 79% (319 of 406) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.4 (29%) | 2.5 (25%) | 4.9 (27%) |
| CHARGED: it charged | 1.0 (13%) | 1.7 (17%) | 2.7 (15%) |
| FLEEING: it fled or was fleeing | 0.0 (0%) | 0.1 (1%) | 0.1 (0%) |
| IN COMBAT: it fought this turn or the last | 0.8 (10%) | 0.5 (5%) | 1.3 (7%) |
| MOVED: a war machine that moved | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| NO TARGET IN RANGE | 1.1 (13%) | 2.2 (23%) | 3.3 (18%) |
| ONLY IN COMBAT: the only targets were in combat | 0.6 (7%) | 0.3 (3%) | 0.9 (5%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.6 (20%) | 1.7 (17%) | 3.3 (18%) |
| SHELTERED: the target was sheltered | 0.2 (3%) | 0.4 (4%) | 0.6 (4%) |
| STUPIDITY | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR | 0.3 (4%) | 0.4 (5%) | 0.8 (4%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 6.5 | 1.1 | 87% | 3.4 pts | 22 pts |
| character | 2.4 | 0.9 | 71% | 10.7 pts | 26 pts |
| chariot | 2.6 | 1.4 | 73% | 13.1 pts | 35 pts |
| infantry | 12.3 | 6.0 | 68% | 10.5 pts | 129 pts |
| monster | 1.5 | 0.2 | 87% | 3.9 pts | 6 pts |
| war machine | 8.9 | 7.2 | 58% | 26.6 pts | 236 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.0 | 5.8 | 4.9 |
| Charges that made contact a game | 2.9 | 4.1 | 3.5 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.71 declared, 0.38 contact (24 units) | 0.77 declared, 0.54 contact (13 units) | 0.73 declared, 0.43 contact (37 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.25 declared, 0.25 contact (8 units) | 0.85 declared, 0.69 contact (13 units) | 0.62 declared, 0.52 contact (21 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.51 declared, 0.39 contact (245 units) | 0.65 declared, 0.46 contact (286 units) | 0.59 declared, 0.43 contact (531 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 66% (48 of 73) | 67% (12 of 18) | 58% (7 of 12) | 65% (67 of 103) |
| Character in a unit | 84% (26 of 31) | 65% (13 of 20) | 67% (2 of 3) | 76% (41 of 54) |
| Character on its own | 78% (32 of 41) | 65% (22 of 34) | 32% (20 of 63) | 54% (74 of 138) |
| Chariot | 59% (10 of 17) | 62% (8 of 13) | - | 60% (18 of 30) |
| Infantry | 53% (50 of 94) | 68% (23 of 34) | 33% (1 of 3) | 56% (74 of 131) |
| Monster | 45% (13 of 29) | 67% (6 of 9) | - | 50% (19 of 38) |
| Monstrous | 64% (9 of 14) | 64% (9 of 14) | - | 64% (18 of 28) |
| War Machines | 74% (42 of 57) | 100% (2 of 2) | - | 75% (44 of 59) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 100% (15 of 15); on the table 100% | 33% (34 of 102) | 39% | 64% (14 of 22) | 83% (5 of 6); 4.0 uses a game | 50% (1 of 2); 1.0 uses a game | 83% (5 of 6); 1.2 uses a game |
| Chaos Dwarfs | 4 | 100% (10 of 10); on the table 100% | 42% (15 of 36) | 57% | 69% (22 of 32) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
| Dwarfen Mountain Holds | 6 | 93% (14 of 15); on the table 93% | - | 53% | 70% (38 of 54) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 7 | 86% (12 of 14); on the table 86% | 27% (13 of 48) | 47% | 70% (53 of 76) | 0.0 uses a game | 100% (2 of 2); 0.7 uses a game | 25% (1 of 4); 0.1 uses a game |
| Grand Cathay | 6 | 95% (20 of 21); on the table 95% | 36% (49 of 138) | 46% | 52% (28 of 54) | 86% (12 of 14); 8.3 uses a game | 50% (1 of 2); 0.2 uses a game | 17% (1 of 6); 0.2 uses a game |
| High Elf Realms | 4 | 70% (7 of 10); on the table 70% | 6% (1 of 18) | 16% | 58% (19 of 33) | 100% (3 of 3); 2.0 uses a game | 43% (6 of 14); 2.2 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 2 | 100% (4 of 4); on the table 100% | - | 55% | 33% (4 of 12) | 0.0 uses a game | 0.0 uses a game | 100% (2 of 2); 1.0 uses a game |
| Lizardmen | 1 | 100% (2 of 2); on the table 100% | - | 51% | 86% (6 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 4 | 100% (8 of 8); on the table 100% | 0% (0 of 18) | 40% | 75% (21 of 28) | 100% (4 of 4); 2.2 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 1 | 100% (6 of 6); on the table 100% | 8% (1 of 12) | 0% | 25% (2 of 8) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Skaven | 3 | 93% (14 of 15); on the table 100% | 33% (6 of 18) | 28% | 60% (15 of 25) | 100% (2 of 2); 1.3 uses a game | 0.0 uses a game | 67% (2 of 3); 0.7 uses a game |
| Tomb Kings of Khemri | 5 | 75% (6 of 8); on the table 88% | - | 38% | 12% (3 of 25) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 9 | 90% (28 of 31); on the table 90% | 47% (31 of 66) | 38% | 72% (39 of 54) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 9 | 70% (16 of 23); on the table 74% | 44% (8 of 18) | 25% | 51% (37 of 73) | 100% (2 of 2); 0.7 uses a game | 0.0 uses a game | 100% (1 of 1); 0.1 uses a game |
| Wood Elf Realms | 7 | 100% (18 of 18); on the table 100% | 42% (10 of 24) | 36% | 69% (54 of 78) | 57% (4 of 7); 1.7 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (su-h2h-mine-e45904b-p2, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 68% (54) | 55% (35) | 62% (89) |
| ...free all their last turn and able to turn (per game) | 0.69 | 0.67 | 1.36 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.42 | 0.14 | 0.56 |
| ...with the charger already in that arc before they moved (per game) | 0.47 | 0.39 | 0.86 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 1.78 | 1.33 | 3.11 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 1.25 | 1.17 | 2.42 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 6.28 | 5.39 | 11.67 |

### Quality by phase: su-h2h-mine-e45904b-p2

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.8 | 3.3 |
| Strategy | Charge objectives carried out (made contact) | 50% (61 of 123) | 45% (90 of 198) |
| Strategy | Shoot objectives carried out (shot that target) | 40% (135 of 336) | 50% (133 of 267) |
| Strategy | Close-in objectives charged next turn | 15% (18 of 119) | 16% (38 of 234) |
| Strategy | Support requests answered (helper made contact too) | 56% (10 of 18) | 47% (18 of 38) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (5 of 5) | 100% (1 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | 62% (10 of 16) | 42% (5 of 12) |
| Strategy | Joined characters whose unit fought | 43% (21 of 49) | 36% (15 of 42) |
| Strategy | Lone characters that fought | 79% (76 of 96) | 74% (60 of 81) |
| Movement | Charges halted short of contact | 0.1 | 0.2 |
| Movement | Idle units | 1.1 | 1.8 |
| Movement | Points that never moved of their own | 331.9 | 196.3 |
| Movement | Fights charged into per game | 2.5 | 3.4 |
| Movement | Charges with odds: long shots (under 50%) | 7 of 78, net +137 | 18 of 111, net +278 |
| Movement | Charges with odds: sweet spot (55-75%) | 18 of 78, net +34 | 21 of 111, net +134 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 11 of 78, net +115 | 5 of 111, net +72 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 20 of 78, net +106 | 38 of 111, net +134 |
| Shooting | Shots by shooting units (incl. breath weapons) | 10.3 | 11.2 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 36% (133 of 370) | 44% (175 of 402) |
| Shooting | Points destroyed by shooting units | 100.7 | 48.2 |
| Shooting | War machine shots | 6.3 | 2.6 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 49% (111 of 226) | 48% (45 of 93) |
| Shooting | Points destroyed by war machines | 75.5 | 55.1 |
| Magic | Magic missiles cast | 1.8 | 1.0 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 35% (23 of 65) | 43% (16 of 37) |
| Magic | Wounds caused by magic missiles | 2.8 | 1.2 |
| Magic | Wounds caused by other spells | 1.3 | 0.4 |
| Magic | Points destroyed by magic (all spells) | 52.8 | 16.9 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.0 / 0.6 / 0.6 / 0.1 | 1.9 / 0.3 / 0.6 / 0.2 |
| Combat | Points destroyed in combat | 265.5 | 468.4 |
| Combat | Points run down | 52.8 | 140.8 |
| Combat | Net points per charged fight, damage counted | +81 | +162 |
| Combat | Net per 100 charger points, damage counted | +28.0 | +58.1 |
| Combat | First round won (charged fights) | 76% | 79% |
| Combat | Net points per charged fight | +72 | +157 |
| Combat | Net points per supported fight / lone fight | +39 / +78 | +221 / +142 |
| Combat | Charged fights on a top-3 enemy unit | 40 of 91 | 47 of 121 |
| Game | Points lost | 825.6 | 596.2 |
| Game | VP from objectives | 506.4 | 686.1 |
| Game | Lone holders (player turns) | 1.5 | 3.6 |

- Mine won / drew / lost: 13 / 5 / 18 of 36 ended games (of 36); mean margin (Mine - Opponent) -419 VP
- The side that went first won 14 of 31 games with a winner
- Points traded per game (both sides' losses): 1422
- Games not ended: 0; findings 0, warnings 1

### Opponent rules: su-h2h-mine-e45904b-p2

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 0.5 | +0.0 | 0.0 | 0.0 |
| ARRIVAL HUNT | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +4.3 | 0.0 | 2.5 |
| ARTILLERY RE-ROLL WEIGHED | 1.4 | +0.0 | 0.0 | 29.6 | 0.2 | +0.0 | 0.0 | 6.9 |
| BACKUP TARGETS | 1.7 | +14.8 | 0.0 | 58.8 | 0.8 | +7.2 | 0.0 | 39.4 |
| BEST FACING | 0.8 | +30.9 | 0.0 | 8.0 | 0.6 | +18.7 | 0.0 | 11.5 |
| BEST FIRST | 5.0 | +210.9 | 114.0 | 55.3 | 4.2 | +153.1 | 140.4 | 70.9 |
| BEST OVERALL | 0.9 | +55.7 | 0.0 | 7.0 | 0.7 | +54.1 | 0.0 | 29.1 |
| BEST PREY | 0.9 | +49.7 | 31.4 | 24.3 | 1.0 | +39.8 | 64.9 | 10.6 |
| BEST PRIZE | 0.1 | -5.1 | 0.0 | 3.8 | 0.1 | -8.7 | 7.6 | 13.1 |
| BIG CHARACTER SAFETY | 0.2 | -0.3 | 0.0 | 0.0 | 0.2 | +0.2 | 0.0 | 0.0 |
| BLOCKED CHARGE SKIPPED | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| BLOCKED WHEEL | 0.3 | +7.2 | 0.0 | 3.5 | 0.6 | -10.3 | 0.0 | 3.3 |
| BLOWS WHERE AIMED | 0.3 | -7.0 | 18.6 | 17.6 | 0.4 | -37.1 | 80.7 | 5.4 |
| BOMBING RUN | 0.1 | +1.7 | 6.5 | 0.0 | - | - | - | - |
| BOUND ASSAILMENT | 0.1 | +0.0 | 0.0 | 6.8 | - | - | - | - |
| CANNON PLAN MISSED | 1.1 | +0.0 | 157.6 | 22.8 | 0.3 | +0.0 | 22.4 | 0.0 |
| CANNON PLANNED TARGET | 4.6 | +162.8 | 352.1 | 81.8 | 1.9 | +110.7 | 108.5 | 19.4 |
| CANNON SIGHT KEPT | 1.3 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 13.1 |
| CARRIES OUT CLOSE-IN | 0.3 | -19.3 | 27.4 | 5.2 | - | - | - | - |
| CARRIES OUT COUNTER | - | - | - | - | 0.2 | -0.3 | 19.5 | 2.8 |
| CARRIES OUT SET-UP | 0.1 | +0.0 | 20.7 | 0.0 | 0.4 | -4.3 | 83.5 | 0.0 |
| CAST JOB | 0.7 | +15.6 | 53.5 | 27.6 | 0.4 | +15.6 | 61.3 | 10.6 |
| CASTER AWAY FROM SCREEN | 0.3 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.4 | +19.9 | 10.8 | 8.2 | 0.4 | +19.1 | 30.2 | 0.0 |
| CASTS AFTER FRIENDS | 0.4 | +0.0 | 0.0 | 9.9 | 0.4 | +0.0 | 0.0 | 18.9 |
| CASTS FROM BEHIND | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.1 | +3.8 | 0.0 | 0.0 | - | - | - | - |
| CATCH ODDS | - | - | - | - | 0.1 | +4.9 | 0.0 | 0.0 |
| CHAFF PASSED | 0.2 | -0.6 | 0.0 | 6.5 | 0.1 | +0.0 | 0.0 | 0.0 |
| CHAMPION TAKES THE CHALLENGE | - | - | - | - | 0.1 | +0.1 | 10.7 | 0.0 |
| CHARGE BAND | 0.1 | +0.0 | 8.9 | 2.4 | 0.2 | +0.0 | 15.2 | 0.0 |
| CHARGE NOW FIRST | 2.0 | +0.0 | 150.8 | 59.3 | 2.5 | +0.0 | 273.8 | 50.1 |
| CHARGE NOW WEIGHED | 0.6 | -38.3 | 17.8 | 38.9 | 0.5 | -55.8 | 27.3 | 33.9 |
| CHARGER SLAIN LOST | 0.6 | -18.8 | 68.6 | 24.3 | 0.6 | -10.6 | 64.2 | 18.2 |
| CHARIOT NO STATIC JOB | 0.0 | +0.0 | 0.0 | 2.4 | - | - | - | - |
| CHEAP HELPER | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 5.8 | 2.5 |
| COMBAT PIVOT | 0.4 | +0.0 | 19.9 | 66.1 | 0.8 | +0.0 | 85.4 | 46.0 |
| CONTINUE AHEAD WEIGHED | 0.0 | +0.0 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 5.1 |
| CONVEYANCE SEARCH | 0.4 | +102.0 | 0.0 | 9.9 | 0.5 | +55.2 | 4.4 | 30.1 |
| COUNTER-CHARGE COVER | 11.6 | +1055.6 | 0.0 | 259.7 | 7.7 | +745.9 | 0.0 | 145.4 |
| DEFENSIVE ARMY | 0.4 | +0.0 | 43.8 | 3.6 | 0.1 | +0.0 | 16.1 | 0.0 |
| EDGE GIVE GROUND | 0.1 | +2.0 | 0.0 | 1.5 | 0.4 | +5.0 | 23.6 | 12.9 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 1.8 | +139.4 | 0.0 | 33.8 | 1.3 | +114.9 | 0.0 | 30.6 |
| FALLBACK BY WORTH | 4.4 | +64.3 | 0.0 | 77.6 | 5.7 | +54.7 | 0.0 | 57.7 |
| FIGHT LIFT | 0.0 | +0.0 | 9.4 | 0.0 | 0.1 | +1.9 | 0.0 | 0.0 |
| FIRE AND FLEE | 0.1 | +0.9 | 7.7 | 0.0 | 0.1 | +0.4 | 0.0 | 3.2 |
| FLANK NOT WEIGHED | 6.3 | +0.0 | 0.0 | 146.5 | 5.4 | +0.0 | 0.0 | 154.7 |
| FOCUS FIRE | - | - | - | - | 0.0 | +0.6 | 1.8 | 0.0 |
| FOLLOW UP WEIGHED | 1.0 | +101.1 | 0.0 | 36.3 | 0.9 | +117.5 | 0.0 | 42.4 |
| FRIENDS SHOTS CHECKED | 0.2 | +10.7 | 0.0 | 7.2 | 0.1 | +5.2 | 0.0 | 0.0 |
| GIVES UP | - | - | - | - | 0.1 | -1.8 | 26.3 | 0.0 |
| GIVES UP ITS SCREEN | - | - | - | - | 0.1 | -1.0 | 10.1 | 0.0 |
| GROUND FLIERS | 0.1 | +1.6 | 0.0 | 0.0 | - | - | - | - |
| HELPER ALREADY ASKED | 0.0 | +0.0 | 5.7 | 0.0 | 0.1 | +0.0 | 14.9 | 3.1 |
| HELPER UNSEEN | 0.4 | +0.0 | 42.6 | 16.2 | 0.4 | +0.0 | 43.8 | 14.9 |
| HILL BY ITS CHANCE | 0.4 | -33.6 | 0.0 | 6.5 | 0.6 | -56.4 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 6.7 | -99.0 | 265.9 | 158.5 | 10.3 | -199.2 | 676.0 | 174.9 |
| HORN WORTH | - | - | - | - | 0.0 | +1.0 | 0.0 | 0.0 |
| HUNT ADVANCE | 0.1 | +0.2 | 5.4 | 0.9 | 0.2 | +4.0 | 15.6 | 0.0 |
| HUNT DROPPED | - | - | - | - | 0.2 | +0.0 | 3.9 | 0.0 |
| HUNT IN PAIRS | 0.4 | +20.3 | 0.0 | 22.6 | 0.4 | +39.3 | 0.0 | 11.4 |
| HUNT KEPT | 0.0 | +0.5 | 5.4 | 0.0 | 0.1 | +5.5 | 11.9 | 0.9 |
| HUNT RESULT | 0.1 | +22.1 | 0.0 | 5.6 | 0.4 | +43.4 | 8.5 | 0.9 |
| HUNT THE GUNS | 0.1 | +28.2 | 20.8 | 0.9 | 0.4 | +127.2 | 24.7 | 3.0 |
| INVITES THE FIGHT | 2.1 | +42.3 | 79.4 | 16.3 | 0.9 | +16.6 | 52.4 | 0.0 |
| JOINT AS ONE | 2.5 | -4.2 | 94.9 | 30.6 | - | - | - | - |
| JOINT CHARGE PLAN | 0.1 | +1.5 | 0.0 | 0.0 | 0.1 | +6.1 | 0.0 | 0.0 |
| JOINT KNOWS CHALLENGE | 0.1 | -0.4 | 13.3 | 0.0 | 0.1 | -0.7 | 9.0 | 0.0 |
| KEEP FALLS | 0.0 | +0.6 | 0.0 | 0.0 | - | - | - | - |
| KEEPS ITS PREY | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |
| KEEPS ITS TARGET | 0.9 | +28.3 | 83.6 | 40.9 | 2.1 | +64.2 | 234.1 | 61.8 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| KILLS COUNT | 1.8 | +81.4 | 107.8 | 50.6 | 2.0 | +88.8 | 171.0 | 19.1 |
| KILLS COUNT NEXT TURN | 3.8 | +126.9 | 121.5 | 112.8 | 7.3 | +255.5 | 360.9 | 154.4 |
| LONE CHARACTER SAFE SPOT | 0.1 | +15.6 | 0.0 | 0.0 | 0.2 | +3.9 | 10.2 | 4.9 |
| LONE WIZARD HOLDS BACK | 0.1 | +0.0 | 0.0 | 3.9 | 0.3 | +0.0 | 12.6 | 16.1 |
| LONE WIZARD KEPT IN | 0.6 | +39.4 | 0.0 | 0.0 | 0.3 | +23.5 | 0.0 | 0.0 |
| LONG SHOT | 0.4 | -3.7 | 10.3 | 11.1 | 0.7 | +5.5 | 55.4 | 0.0 |
| LOST CHARGE | 3.0 | -50.0 | 82.1 | 89.8 | 2.9 | -56.0 | 92.3 | 44.5 |
| LURE BY WHAT IT DRAWS | - | - | - | - | 0.0 | -5.6 | 0.0 | 0.9 |
| MAKE SURE TOGETHER | 0.5 | +27.5 | 20.7 | 4.6 | 0.7 | +24.4 | 0.0 | 10.9 |
| MANOEUVRE | 0.3 | +9.8 | 0.0 | 7.6 | 0.2 | +4.7 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | 0.4 | +13.2 | 0.0 | 14.1 | 0.4 | +34.1 | 0.0 | 3.2 |
| MARCH ODDS | 0.3 | +23.6 | 14.6 | 0.0 | 0.3 | +22.9 | 22.4 | 0.0 |
| MARCH OVER CASTS | 0.4 | +32.0 | 0.0 | 11.1 | 0.2 | +25.5 | 0.0 | 4.4 |
| MAX FOR POSITIONING | 5.8 | +192.3 | 0.0 | 169.8 | 4.4 | +186.0 | 0.0 | 111.7 |
| MISSILES IN THE MOVE | 3.9 | +94.4 | 0.0 | 114.1 | 3.2 | +71.4 | 0.0 | 50.4 |
| MISSILES NEXT TURN | 4.5 | +66.0 | 0.0 | 141.3 | 3.5 | +48.5 | 0.0 | 55.7 |
| MODEL FACING | 0.3 | +61.9 | 0.0 | 1.7 | 0.3 | +111.7 | 0.0 | 3.3 |
| MONSTER WIZARD ROAMS | 0.1 | +0.0 | 25.0 | 0.0 | 0.2 | +0.0 | 24.1 | 0.0 |
| MOVE AND CAST | 0.3 | +17.0 | 0.0 | 17.4 | 0.3 | +8.9 | 0.0 | 0.0 |
| MOVE SPELL IN RANGE | 0.1 | +3.8 | 0.0 | 32.2 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.2 | -10.6 | 0.0 | 0.0 | 0.2 | -6.3 | 0.0 | 7.6 |
| MOVE SPELL SPOT | 0.3 | +0.0 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE | 2.5 | +142.8 | 62.7 | 107.5 | 5.1 | +282.8 | 239.8 | 122.5 |
| MOVES UNITS SPELL | 0.1 | +3.4 | 0.0 | 0.0 | - | - | - | - |
| NEEDED THERE | - | - | - | - | 0.1 | +5.4 | 4.4 | 0.0 |
| NO CHARGE WHY | 2.2 | +0.0 | 50.9 | 77.9 | 4.4 | +0.0 | 238.1 | 122.9 |
| NO RALLY LEFT | - | - | - | - | 0.0 | +1.8 | 0.0 | 0.0 |
| NOT NEEDED | 0.2 | -5.0 | 14.6 | 0.0 | 0.5 | -19.8 | 64.8 | 0.0 |
| NOT TURNED | 6.3 | +93.7 | 0.0 | 138.0 | 5.4 | +83.3 | 0.0 | 144.0 |
| NOT WORTH A CAST | 0.4 | -0.3 | 0.0 | 0.0 | 0.7 | -0.7 | 0.0 | 7.6 |
| OFF BEST | 15.1 | -718.1 | 6.6 | 188.4 | 15.6 | -923.2 | 11.7 | 285.1 |
| OPENS A LANE | 0.4 | +3.0 | 15.9 | 0.0 | 0.1 | +0.1 | 0.0 | 0.0 |
| OPENS UP | 0.1 | +2.6 | 4.4 | 10.2 | 0.2 | +21.9 | 9.4 | 0.0 |
| OVERRUNS AWAY | 0.5 | +7.0 | 55.2 | 20.0 | 0.7 | +18.9 | 72.7 | 33.0 |
| PATHS CROSS | 2.3 | +128.8 | 0.0 | 57.5 | 2.8 | +196.5 | 0.0 | 63.0 |
| PERIAPT WORTH | 0.0 | +1.5 | 0.0 | 0.0 | 0.0 | +1.4 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.1 | -1.7 | 0.0 | 16.1 | 0.1 | -1.0 | 0.0 | 0.0 |
| PLAN RESULT | 36.5 | +1310.7 | 1360.7 | 1015.2 | 41.9 | +1418.1 | 1724.4 | 754.9 |
| PURSUES BIG PREY | 0.1 | -13.8 | 0.0 | 8.6 | 0.1 | -17.3 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE NEXT TURN | 0.0 | +1.7 | 0.0 | 3.4 | 0.0 | +2.4 | 0.0 | 0.0 |
| RANDOM MOVE BY FIGURES | 0.6 | +14.2 | 0.0 | 10.6 | 1.5 | +25.9 | 0.0 | 56.1 |
| RANDOM MOVER NO PROMISE | 0.1 | -8.0 | 4.0 | 4.7 | 0.1 | -5.3 | 10.0 | 0.0 |
| REDIRECT BY WHAT IT STOPS | 0.2 | -0.3 | 0.0 | 10.6 | 0.4 | -3.0 | 0.0 | 1.8 |
| REDIRECT COUNTER | 2.4 | +170.0 | 0.0 | 53.1 | 3.8 | +276.4 | 0.0 | 52.0 |
| REDIRECT WEIGHED | 0.3 | +3.2 | 2.6 | 1.2 | 0.3 | -8.7 | 7.6 | 26.8 |
| REFUSING RETIRES | 0.4 | +0.0 | 0.0 | 9.4 | 0.4 | +0.0 | 0.0 | 24.1 |
| RESERVE FALL BACK | 0.4 | +11.9 | 0.0 | 2.0 | 1.1 | +34.7 | 0.0 | 25.0 |
| RESTRAINS TO SHOOT | 0.1 | +5.5 | 0.0 | 8.6 | 0.1 | +0.9 | 0.0 | 0.0 |
| RISK BY ARC | 2.4 | +102.7 | 191.4 | 95.4 | 3.4 | +92.3 | 367.4 | 61.8 |
| SAFE SURE CHARGE | 0.0 | -1.7 | 1.1 | 0.0 | 0.0 | -0.8 | 0.8 | 0.0 |
| SAFER THAN THE JOB | 1.2 | +59.2 | 0.0 | 7.3 | 1.2 | +80.2 | 0.0 | 37.8 |
| SCOUT SPOT | 0.3 | +0.9 | 0.0 | 0.0 | 0.5 | +2.4 | 0.0 | 0.0 |
| SCOUT WAITS | 0.3 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.1 | -1.5 | 0.0 | 1.2 | 0.6 | -39.2 | 0.0 | 3.8 |
| SEARCH SPOT | 2.9 | +127.4 | 0.0 | 57.6 | 2.9 | +147.7 | 0.0 | 42.1 |
| SECOND HUNTER | - | - | - | - | 0.1 | -1.5 | 5.8 | 0.0 |
| SELF MOVE SPELL | 0.2 | +7.3 | 0.0 | 9.1 | - | - | - | - |
| SET UP TOGETHER | 0.7 | +28.9 | 20.7 | 8.6 | 2.0 | +129.7 | 87.9 | 30.0 |
| SET-UP ANY TARGET | 0.1 | +11.1 | 0.0 | 0.0 | 0.1 | +25.2 | 0.0 | 11.2 |
| SET-UP MISSED | - | - | - | - | 0.1 | +3.5 | 0.0 | 0.0 |
| SET-UP SPOT | 4.1 | +48.5 | 48.6 | 172.8 | - | - | - | - |
| SHOOTER COUNTED ONCE | - | - | - | - | 0.1 | -0.0 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.4 | +0.8 | 0.0 | 0.0 | 0.3 | +0.6 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 0.8 | +19.9 | 35.0 | 14.2 | 0.7 | +10.9 | 28.9 | 19.9 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| SHOT REPLANNED | 0.9 | +0.0 | 204.9 | 15.4 | 0.4 | +0.0 | 60.0 | 0.0 |
| SHOTS IN THE MOVE | 14.0 | +568.9 | 0.0 | 247.0 | 11.9 | +387.7 | 0.0 | 149.8 |
| SPELL CATCH ODDS | 0.0 | -0.0 | 0.0 | 9.9 | - | - | - | - |
| SPELL SETS UP CHARGE | 0.2 | +72.1 | 0.0 | 0.0 | 0.1 | +25.2 | 0.0 | 11.2 |
| SPELL WORTH | 0.9 | +13.0 | 89.9 | 94.3 | 1.6 | +28.9 | 72.8 | 67.1 |
| SPELLS IN THE FIGHT | 0.6 | -0.7 | 76.3 | 34.6 | 0.9 | -10.9 | 94.3 | 5.4 |
| STABLE ROLE | 11.5 | +0.0 | 369.6 | 145.2 | 12.7 | +0.0 | 469.9 | 146.2 |
| STAY WEIGHED | 0.1 | +1.9 | 0.0 | 0.8 | 0.1 | +2.1 | 0.0 | 0.0 |
| STOPS | 0.1 | +0.8 | 20.8 | 0.0 | 0.3 | +14.6 | 16.5 | 3.9 |
| STOPS SHORT OF THE FLANK | 0.5 | +27.5 | 0.0 | 28.9 | 0.4 | +18.7 | 0.0 | 15.9 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 4.0 |
| SUPPORT NARROWED | 6.5 | -56.6 | 339.8 | 98.3 | 7.1 | -52.9 | 395.5 | 65.6 |
| SUPPORTS | 4.4 | +58.6 | 226.8 | 40.8 | 4.6 | +55.0 | 185.5 | 53.9 |
| SURE CHARGE BEATS ADVANCE | 0.1 | -2.8 | 6.5 | 5.2 | 0.1 | -2.4 | 10.1 | 5.6 |
| SURE REACH TOGETHER | 0.6 | +2.8 | 8.4 | 12.0 | 0.8 | +2.8 | 18.9 | 17.0 |
| THROUGH LINE OF FIRE | 0.2 | +21.9 | 0.0 | 0.0 | 0.3 | +8.9 | 0.0 | 0.0 |
| TURN WORTH | 0.1 | -10.4 | 11.5 | 12.3 | 0.1 | -4.8 | 9.8 | 2.9 |
| TWO OR MORE ARRIVE | 0.2 | +2.5 | 0.0 | 0.0 | 0.4 | +3.6 | 12.6 | 11.7 |
| WAIT AFTER COSTS | 6.0 | -300.6 | 182.8 | 137.7 | 8.1 | -369.0 | 353.7 | 147.9 |
| WALKS TO THE FIGHT | 1.4 | +29.3 | 37.4 | 4.0 | 1.1 | +14.0 | 34.7 | 16.4 |
| WAR ENGINE CHARGES | 0.1 | +8.3 | 0.0 | 0.0 | 0.0 | +0.2 | 0.9 | 0.0 |
| WAR ENGINE JOBS | 0.7 | +0.0 | 69.4 | 3.9 | 0.2 | +0.0 | 28.8 | 19.4 |
| WEARS DOWN | 1.0 | +50.6 | 82.9 | 48.0 | 1.6 | +43.1 | 178.9 | 37.4 |
| WHO HITS BACK | 0.3 | +20.8 | 0.0 | 18.9 | 0.2 | +31.5 | 0.0 | 5.6 |
| WHOLE FIGHT | 0.2 | +17.5 | 26.0 | 6.9 | 0.4 | +32.8 | 89.8 | 2.8 |
| WHOLE FIGHT GAIN | 0.4 | +25.4 | 35.4 | 21.1 | 1.1 | +81.7 | 115.9 | 24.9 |
| WIDER SPREAD | 2.5 | -5.5 | 178.6 | 76.1 | 3.8 | -5.8 | 371.9 | 39.2 |
| WOUNDED STAYS OUT | - | - | - | - | 0.1 | +0.0 | 1.9 | 0.0 |

### Rule changes: su-h2h-mine-e45904b-p2

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 1107 | 1107 | 1107 | 30.75 | -59085 | -53.4 |
| BEST FIRST | 333 | 333 | 333 | 9.25 | +13106 | +39.4 |
| SEARCH SPOT | 209 | 209 | 208 | 5.78 | +9915 | +47.7 |
| COUNTER-CHARGE COVER | 693 | 408 | 203 | 5.64 | +12638 | +62.3 |
| PATHS CROSS | 184 | 184 | 184 | 5.11 | +11713 | +63.7 |
| MOVE TO CHARGE | 272 | 272 | 140 | 3.89 | +5794 | +41.4 |
| KILLS COUNT NEXT TURN | 401 | 401 | 132 | 3.67 | +3957 | +30.0 |
| SUPPORTS | 326 | 326 | 126 | 3.50 | +1213 | +9.6 |
| FACES THE THREAT | 112 | 112 | 112 | 3.11 | +9154 | +81.7 |
| SAFER THAN THE JOB | 87 | 87 | 87 | 2.42 | +5018 | +57.7 |
| FALLBACK BY WORTH | 365 | 365 | 85 | 2.36 | +4285 | +50.4 |
| SHOTS IN THE MOVE | 932 | 621 | 72 | 2.00 | +1846 | +25.6 |
| CANNON SIGHT KEPT | 70 | 70 | 70 | 1.94 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 68 | 68 | 68 | 1.89 | +7871 | +115.7 |
| SET-UP SPOT | 148 | 148 | 66 | 1.83 | +2059 | +31.2 |
| WAIT AFTER COSTS | 506 | 506 | 63 | 1.75 | +1395 | +22.1 |
| ARTILLERY RE-ROLL WEIGHED | 58 | 58 | 58 | 1.61 | +0 | +0.0 |
| BEST OVERALL | 58 | 58 | 58 | 1.61 | +3954 | +68.2 |
| RESERVE FALL BACK | 53 | 53 | 53 | 1.47 | +1677 | +31.6 |
| WALKS TO THE FIGHT | 88 | 88 | 50 | 1.39 | +663 | +13.3 |
| BEST FACING | 49 | 49 | 49 | 1.36 | +1783 | +36.4 |
| SHOT REPLANNED | 48 | 48 | 48 | 1.33 | +0 | +0.0 |
| REDIRECT COUNTER | 221 | 125 | 47 | 1.31 | +2280 | +48.5 |
| RISK BY ARC | 212 | 201 | 46 | 1.28 | +1455 | +31.6 |
| MAX FOR POSITIONING | 367 | 207 | 44 | 1.22 | +341 | +7.7 |
| COMBAT PIVOT | 43 | 43 | 43 | 1.19 | +0 | +0.0 |
| ADVANCE LANE KEPT | 42 | 42 | 42 | 1.17 | +0 | +0.0 |
| HOLDS AMBUSHERS | 40 | 40 | 40 | 1.11 | +0 | +0.0 |
| CHARGE NOW WEIGHED | 39 | 39 | 39 | 1.08 | +3773 | +96.7 |
| MISSILES IN THE MOVE | 257 | 147 | 38 | 1.06 | +951 | +25.0 |
| RANDOM MOVE BY FIGURES | 76 | 76 | 38 | 1.06 | +1444 | +38.0 |
| CHARGE NOW FIRST | 161 | 161 | 37 | 1.03 | -2261 | -61.1 |
| KILLS COUNT | 135 | 132 | 37 | 1.03 | +1378 | +37.2 |
| SET UP TOGETHER | 98 | 80 | 36 | 1.00 | +2308 | +64.1 |
| BLOCKED WHEEL | 34 | 34 | 34 | 0.94 | -113 | -3.3 |
| STOPS SHORT OF THE FLANK | 34 | 34 | 34 | 0.94 | +1666 | +49.0 |
| LONE WIZARD KEPT IN | 33 | 33 | 33 | 0.92 | +2266 | +68.7 |
| CANNON PLANNED TARGET | 232 | 232 | 32 | 0.89 | -269 | -8.4 |
| HONEST WORTH | 612 | 603 | 32 | 0.89 | +239 | +7.5 |
| SCOUT WAITS | 32 | 32 | 32 | 0.89 | +0 | +0.0 |
| MARCH CHECK | 31 | 30 | 27 | 0.75 | +1575 | +58.3 |
| WHOLE FIGHT GAIN | 53 | 49 | 27 | 0.75 | +1141 | +42.2 |
| SHOOTERS IN TWO RANKS | 25 | 25 | 25 | 0.69 | +50 | +2.0 |
| SHOOTS FROM THE BEST SPOT | 56 | 56 | 24 | 0.67 | +320 | +13.3 |
| MODEL FACING | 23 | 23 | 23 | 0.64 | +6248 | +271.7 |
| CASTING BLOCK | 27 | 27 | 21 | 0.58 | +741 | +35.3 |
| INVITES THE FIGHT | 108 | 108 | 21 | 0.58 | +417 | +19.9 |
| MARCH ODDS | 21 | 21 | 21 | 0.58 | +476 | +22.6 |
| MOVE AND CAST | 21 | 21 | 21 | 0.58 | +934 | +44.5 |
| REDIRECT WEIGHED | 21 | 21 | 21 | 0.58 | +788 | +37.5 |
| BEST PREY | 68 | 68 | 20 | 0.56 | +792 | +39.6 |
| CAST JOB | 40 | 40 | 19 | 0.53 | +277 | +14.6 |
| THROUGH LINE OF FIRE | 19 | 19 | 19 | 0.53 | +1106 | +58.2 |
| KEEPS ITS TARGET | 111 | 106 | 17 | 0.47 | +287 | +16.9 |
| MANOEUVRE | 18 | 18 | 17 | 0.47 | +521 | +30.7 |
| WHO HITS BACK | 17 | 17 | 17 | 0.47 | +1342 | +78.9 |
| CASTER AWAY FROM SCREEN | 16 | 16 | 16 | 0.44 | +0 | +0.0 |
| BIG CHARACTER SAFETY | 15 | 15 | 15 | 0.42 | -4 | -0.3 |
| CASTS FROM BEHIND | 15 | 15 | 15 | 0.42 | +0 | +0.0 |
| REFUSING RETIRES | 30 | 30 | 15 | 0.42 | -3 | -0.2 |
| LOST CHARGE | 214 | 214 | 14 | 0.39 | +236 | +16.8 |
| SHORT GUN FORWARD | 14 | 14 | 14 | 0.39 | +0 | +0.0 |
| WEARS DOWN | 96 | 92 | 14 | 0.39 | +579 | +41.4 |
| HUNT IN PAIRS | 31 | 20 | 13 | 0.36 | +817 | +62.9 |
| CHARGE BAND | 12 | 12 | 12 | 0.33 | +0 | +0.0 |
| MISSILES NEXT TURN | 287 | 160 | 12 | 0.33 | +10 | +0.8 |
| CHAFF PASSED | 10 | 10 | 10 | 0.28 | -20 | -2.0 |
| FRIENDS SHOTS CHECKED | 10 | 10 | 10 | 0.28 | +574 | +57.4 |
| STUCK PIVOT | 10 | 10 | 10 | 0.28 | +0 | +0.0 |
| OVERRUNS AWAY | 43 | 41 | 9 | 0.25 | +160 | +17.8 |
| PURSUES BIG PREY | 9 | 9 | 9 | 0.25 | -1121 | -124.5 |
| SUPPORT NARROWED | 490 | 490 | 9 | 0.25 | -92 | -10.2 |
| WAR ENGINE JOBS | 34 | 34 | 9 | 0.25 | -280 | -31.1 |
| JOINT AS ONE | 90 | 90 | 8 | 0.22 | -309 | -38.6 |
| MAKE SURE TOGETHER | 41 | 20 | 8 | 0.22 | +500 | +62.5 |
| OPENS UP | 10 | 10 | 8 | 0.22 | +534 | +66.8 |
| SURE CHARGE BEATS ADVANCE | 8 | 8 | 8 | 0.22 | -189 | -23.6 |
| BACKUP TARGETS | 91 | 45 | 7 | 0.19 | +71 | +10.1 |
| BEST PRIZE | 7 | 7 | 7 | 0.19 | -498 | -71.2 |
| SURE REACH TOGETHER | 48 | 37 | 7 | 0.19 | +129 | +18.4 |
| WHOLE FIGHT | 25 | 23 | 7 | 0.19 | +698 | +99.7 |
| WIDER SPREAD | 226 | 212 | 7 | 0.19 | +37 | +5.3 |
| PIVOT GUARDS FLANK | 6 | 6 | 6 | 0.17 | -98 | -16.4 |
| RESTRAINS TO SHOOT | 5 | 5 | 5 | 0.14 | +232 | +46.4 |
| STAY WEIGHED | 5 | 5 | 5 | 0.14 | +143 | +28.6 |
| BLOCKED CHARGE SKIPPED | 4 | 4 | 4 | 0.11 | +0 | +0.0 |
| FIRE AND FLEE | 4 | 4 | 4 | 0.11 | +47 | +11.8 |
| KEEPS SCOUTS OR AMBUSH | 4 | 4 | 4 | 0.11 | +0 | +0.0 |
| MOVES UNITS SPELL | 4 | 4 | 4 | 0.11 | +122 | +30.4 |
| BLOWS WHERE AIMED | 25 | 22 | 3 | 0.08 | +204 | +67.9 |
| BOMBING RUN | 3 | 3 | 3 | 0.08 | +60 | +19.9 |
| BOUND ASSAILMENT | 3 | 3 | 3 | 0.08 | +0 | +0.2 |
| CARRIES OUT CLOSE-IN | 10 | 10 | 3 | 0.08 | -695 | -231.7 |
| CARRIES OUT SET-UP | 17 | 17 | 3 | 0.08 | -155 | -51.7 |
| SPELLS IN THE FIGHT | 54 | 48 | 3 | 0.08 | +32 | +10.6 |
| CATCH ODDS | 2 | 2 | 2 | 0.06 | -49 | -24.4 |
| CONTINUE AHEAD WEIGHED | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| DEFENSIVE ARMY | 18 | 18 | 2 | 0.06 | -76 | -38.0 |
| HUNT ADVANCE | 11 | 11 | 2 | 0.06 | +16 | +8.2 |
| LONG SHOT | 40 | 40 | 2 | 0.06 | +64 | +32.0 |
| NEEDED THERE | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| OPENS A LANE | 15 | 7 | 2 | 0.06 | +33 | +16.7 |
| PERIAPT WORTH | 2 | 2 | 2 | 0.06 | +106 | +53.0 |
| RAIDS THE BAGGAGE NEXT TURN | 2 | 2 | 2 | 0.06 | +101 | +50.5 |
| SAFE SURE CHARGE | 2 | 2 | 2 | 0.06 | -194 | -96.8 |
| STOPS | 13 | 13 | 2 | 0.06 | +42 | +20.9 |
| CARRIES OUT COUNTER | 6 | 6 | 1 | 0.03 | -11 | -11.3 |
| CHARIOT NO STATIC JOB | 1 | 1 | 1 | 0.03 | -75 | -75.0 |
| EDGE GIVE GROUND | 16 | 15 | 1 | 0.03 | +58 | +57.7 |
| FOCUS FIRE | 1 | 1 | 1 | 0.03 | +23 | +23.2 |
| HILL BY ITS CHANCE | 36 | 36 | 1 | 0.03 | +55 | +55.0 |
| HORN WORTH | 1 | 1 | 1 | 0.03 | +37 | +36.6 |
| JOINT CHARGE PLAN | 8 | 8 | 1 | 0.03 | +62 | +61.6 |
| KEEP FALLS | 1 | 1 | 1 | 0.03 | +22 | +22.0 |
| LONE WIZARD HOLDS BACK | 14 | 14 | 1 | 0.03 | +0 | +0.0 |
| NO RALLY LEFT | 1 | 1 | 1 | 0.03 | +15 | +15.3 |
| REDIRECT BY WHAT IT STOPS | 24 | 24 | 1 | 0.03 | +42 | +41.8 |
| TWO OR MORE ARRIVE | 20 | 18 | 1 | 0.03 | +10 | +10.5 |
| WAR ENGINE CHARGES | 3 | 3 | 1 | 0.03 | +196 | +195.9 |
| WOUNDED STAYS OUT | 2 | 2 | 1 | 0.03 | -2 | -1.9 |
| ARRIVAL HUNT | 6 | 6 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 51 | 51 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 31 | trace | - | - | - | - |
| CATCH FLIERS | 2 | not checked | - | - | - | - |
| CHAMPION TAKES THE CHALLENGE | 2 | 2 | 0 | 0.00 | - | - |
| CHARGER SLAIN LOST | 41 | 37 | 0 | 0.00 | - | - |
| CHEAP HELPER | 9 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 32 | not checked | - | - | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT LIFT | 4 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 422 | not checked | - | - | - | - |
| GIVES UP | 5 | 4 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 4 | 2 | 0 | 0.00 | - | - |
| GROUND FLIERS | 2 | not checked | - | - | - | - |
| HELPER ALREADY ASKED | 5 | not checked | - | - | - | - |
| HELPER UNSEEN | 26 | 25 | 0 | 0.00 | - | - |
| HUNT DROPPED | 6 | trace | - | - | - | - |
| HUNT KEPT | 6 | trace | - | - | - | - |
| HUNT RESULT | 19 | trace | - | - | - | - |
| HUNT THE GUNS | 19 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 6 | 5 | 0 | 0.00 | - | - |
| KEEPS ITS PREY | 1 | 1 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 11 | not checked | - | - | - | - |
| LURE BY WHAT IT DRAWS | 1 | 1 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 25 | 25 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 12 | 12 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 3 | 1 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 15 | trace | - | - | - | - |
| MOVE SPELL SPOT | 11 | not checked | - | - | - | - |
| NO CHARGE WHY | 236 | not checked | - | - | - | - |
| NOT NEEDED | 26 | 25 | 0 | 0.00 | - | - |
| NOT TURNED | 420 | 420 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 40 | not checked | - | - | - | - |
| PLAN RESULT | 2822 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 7 | 7 | 0 | 0.00 | - | - |
| SCOUT SPOT | 28 | 28 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 22 | 22 | 0 | 0.00 | - | - |
| SECOND HUNTER | 4 | 4 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 8 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 7 | not checked | - | - | - | - |
| SET-UP MISSED | 2 | trace | - | - | - | - |
| SHOOTER COUNTED ONCE | 2 | 2 | 0 | 0.00 | - | - |
| SPELL CATCH ODDS | 1 | not checked | - | - | - | - |
| SPELL SETS UP CHARGE | 12 | not checked | - | - | - | - |
| SPELL WORTH | 91 | not checked | - | - | - | - |
| STABLE ROLE | 870 | 868 | 0 | 0.00 | - | - |
| TURN WORTH | 9 | 8 | 0 | 0.00 | - | - |

### Off best figure: su-h2h-mine-e45904b-p2

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 13.08 | 14.14 | 56.0 |
| TURN GATE | gate | 0.75 | 0.56 | 27.9 |
| FALLBACK | gate | 0.64 | 0.53 | 39.1 |
| CHARGE NOW FIRST | rule | 0.47 | 0.56 | 61.1 |
| AFTERMATH BAND | gate | 0.11 | 0.14 | 2.1 |
| PURSUES BIG PREY | rule | 0.11 | 0.14 | 124.5 |
| SUPPORT NARROWED | rule | 0.14 | 0.11 | 10.2 |
| WAR ENGINE JOBS | rule | 0.25 | - | 31.1 |
| CHARGE NOW WEIGHED | rule | 0.17 | 0.06 | 31.6 |
| JOINT AS ONE | rule | 0.22 | - | 38.6 |
| NO REASON | gate | 0.22 | - | 31.5 |
| SURE CHARGE BEATS ADVANCE | rule | 0.11 | 0.11 | 23.6 |
| BEST PRIZE | rule | 0.11 | 0.08 | 71.2 |
| CANNON PLANNED TARGET | rule | 0.17 | 0.03 | 40.8 |
| PATHS CROSS | rule | 0.11 | 0.08 | 34.8 |
| SUPPORT REQUEST | gate | 0.06 | 0.14 | 50.2 |
| BIG CHARACTER SAFETY | rule | 0.14 | 0.03 | 10.0 |
| BLOCKED WHEEL | rule | 0.08 | 0.08 | 107.6 |
| LONE CHARACTER SAFE SPOT | gate | 0.11 | 0.06 | 46.0 |
| PIVOT GUARDS FLANK | rule | 0.11 | 0.06 | 16.4 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.08 | 0.03 | 58.6 |
| CARRIES OUT CLOSE-IN | rule | 0.08 | - | 231.7 |
| CARRIES OUT SET-UP | rule | - | 0.08 | 51.7 |
| CHAFF PASSED | rule | 0.08 | - | 6.6 |
| FIGHT ORDER BAND | gate | 0.06 | 0.03 | 2.0 |
| SAFER THAN THE JOB | rule | 0.08 | - | 9.4 |
| CATCH ODDS | rule | - | 0.06 | 24.4 |
| DEFENSIVE ARMY | rule | - | 0.06 | 38.0 |
| MARCH ODDS | rule | 0.03 | 0.03 | 19.0 |
| REDIRECT WEIGHED | rule | 0.03 | 0.03 | 22.4 |
| REFUSING RETIRES | rule | 0.06 | - | 0.7 |
| SAFE SURE CHARGE | rule | 0.03 | 0.03 | 96.8 |
| STOPS SHORT OF THE FLANK | rule | 0.03 | 0.03 | 4.6 |
| CARRIES OUT COUNTER | rule | - | 0.03 | 11.3 |
| CHARIOT NO STATIC JOB | rule | 0.03 | - | 75.0 |
| FACES THE THREAT | rule | 0.03 | - | 22.5 |
| MOVE AND CAST | rule | - | 0.03 | 14.6 |
| RULE SWITCHED OFF | gate | - | 0.03 | 111.6 |
| SET-UP SPOT | rule | 0.03 | - | 27.5 |
| WOUNDED STAYS OUT | rule | - | 0.03 | 1.9 |

### Plans: su-h2h-mine-e45904b-p2

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 12.4 | 17% | 497 | 332 | 67% |
| Mine | charge | 2.8 | 55% | 219 | 231 | 105% |
| Mine | close in | 3.2 | 26% | 154 | 85 | 55% |
| Mine | hold | 4.9 | 29% | 309 | 0 | 0% |
| Mine | join | 0.6 | 95% | 22 | 0 | 0% |
| Mine | shoot | 7.8 | 65% | 240 | 663 | 276% |
| Mine | support | 4.7 | 89% | 38 | 0 | 0% |
| Opponent | advance | 14.2 | 17% | 338 | 376 | 111% |
| Opponent | charge | 4.8 | 56% | 362 | 455 | 126% |
| Opponent | close in | 6.5 | 29% | 369 | 162 | 44% |
| Opponent | hold | 4.2 | 39% | 331 | 0 | 0% |
| Opponent | join | 0.8 | 96% | 36 | 0 | 0% |
| Opponent | shoot | 6.1 | 67% | 175 | 425 | 243% |
| Opponent | support | 5.4 | 94% | 50 | 0 | 0% |

### Packages: hunt the guns, su-h2h-mine-e45904b-p2

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.1 | 4 | 0 | 75% | 75% | 0% | 2.3 | 254 | 199 | 75% | 52 |
| Opponent | 0.4 | 15 | 0 | 33% | 53% | 0% | 2.2 | 305 | 104 | 47% | 106 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.2 | 1 | 0 | 100% | 100% | 0% | 2.0 | 123 | 122 | 100% | 0 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 300 |
| Dwarfen Mountain Holds | 0.2 | 1 | 0 | 100% | 100% | 0% | 2.0 | 460 | 453 | 100% | 67 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 36 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 22 |
| High Elf Realms | 0.2 | 1 | 0 | 100% | 100% | 0% | 3.0 | 233 | 221 | 100% | 0 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 414 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Ogre Kingdoms | 1.5 | 6 | 0 | 33% | 33% | 0% | 2.5 | 436 | 94 | 17% | 206 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 140 |
| Tomb Kings of Khemri | 1.4 | 7 | 0 | 29% | 57% | 0% | 2.0 | 116 | 49 | 57% | 0 |
| Vampire Counts | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Warriors of Chaos | 0.1 | 1 | 0 | 0% | 0% | 0% | - | 490 | 0 | 0% | 179 |
| Wood Elf Realms | 0.3 | 2 | 0 | 50% | 100% | 0% | 2.5 | 428 | 328 | 100% | 0 |

### Battle groups: su-h2h-mine-e45904b-p2

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 11.6 | 20% | 51% | 16% | 31% | 32% | 16% | 9% | 43% | 0% |
| Mine | REDIRECT COUNTER | 2.4 | 30% | 77% | 0% | - | 15% | 0% | 27% | 58% | 0% |
| Opponent | COUNTER-CHARGE COVER | 7.7 | 22% | 63% | 20% | 33% | 35% | 17% | 8% | 40% | 0% |
| Opponent | REDIRECT COUNTER | 3.8 | 17% | 57% | 13% | 33% | 10% | 5% | 15% | 65% | 5% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: su-h2h-mine-e45904b-p2

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 5 | 99 (5) | 99 | 0 | 0 | 80% | 5.0 | 0 (1) | 117 (4) | - | 206 (2) | 0 (3) |
| Mine | Chaff | 34 | 64 (34) | 17 | 47 | 73 | 32% | 2.9 | 71 (19) | 113 (7) | 11 (8) | 88 (23) | 9 (11) |
| Mine | Character | 123 | 40 (123) | 40 | 0 | 46 | 20% | 2.5 | 54 (38) | 37 (53) | 3 (12) | 43 (54) | 41 (49) |
| Mine | Clean-up | 21 | 49 (21) | 19 | 30 | 34 | 43% | 3.1 | 15 (5) | 60 (13) | 95 (3) | 94 (13) | 4 (8) |
| Mine | Fast | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Mine | Fast Hammer | 48 | 43 (48) | 19 | 23 | 50 | 25% | 2.7 | 24 (23) | 96 (16) | 10 (9) | 48 (29) | 34 (19) |
| Mine | Fragile | 5 | 26 (5) | 26 | 0 | 60 | 0% | 1.6 | - | 44 (3) | 0 (2) | 26 (5) | - |
| Mine | Hammer | 57 | 23 (57) | 16 | 7 | 41 | 12% | 2.8 | 16 (18) | 28 (29) | 25 (10) | 27 (38) | 17 (19) |
| Mine | Holder | 28 | 40 (28) | 9 | 31 | 22 | 36% | 3.2 | 33 (9) | 60 (11) | 17 (8) | 50 (19) | 20 (9) |
| Mine | Shooter | 41 | 72 (41) | 19 | 53 | 55 | 0% | 1.7 | 153 (5) | 73 (30) | 17 (6) | 102 (25) | 24 (16) |
| Mine | Support | 2 | 0 (2) | 0 | 0 | 0 | 100% | - | 0 (1) | 0 (1) | - | - | 0 (2) |
| Mine | War machine | 59 | 53 (59) | 53 | 0 | 45 | 2% | 1.1 | 123 (10) | 45 (37) | 26 (12) | 64 (10) | 51 (49) |
| Mine | Wizard | 22 | 12 (22) | 12 | 0 | 45 | 18% | 2.5 | 0 (7) | 6 (7) | 44 (5) | 0 (5) | 19 (14) |
| Opponent | Blocker | 2 | 0 (2) | 0 | 0 | 0 | 50% | 5.0 | 0 (2) | - | - | 0 (1) | 0 (1) |
| Opponent | Chaff | 76 | 64 (76) | 18 | 46 | 46 | 51% | 2.3 | 93 (32) | 39 (19) | 49 (25) | 84 (54) | 17 (22) |
| Opponent | Character | 97 | 65 (97) | 65 | 0 | 32 | 21% | 2.5 | 85 (42) | 59 (40) | 2 (8) | 65 (63) | 75 (27) |
| Opponent | Clean-up | 19 | 50 (19) | 29 | 20 | 19 | 37% | 2.4 | 52 (9) | 46 (10) | - | 65 (14) | 5 (5) |
| Opponent | Early | 2 | 0 (2) | 0 | 0 | 50 | 50% | 5.0 | - | 0 (1) | - | 0 (1) | - |
| Opponent | Fast Hammer | 48 | 41 (48) | 30 | 11 | 30 | 12% | 3.0 | 56 (22) | 24 (16) | 35 (10) | 36 (28) | 49 (20) |
| Opponent | Fragile | 5 | 44 (5) | 44 | 0 | 46 | 20% | 3.0 | - | 71 (3) | 0 (2) | 54 (4) | 0 (1) |
| Opponent | Hammer | 70 | 34 (70) | 31 | 4 | 42 | 29% | 3.0 | 49 (17) | 35 (42) | 9 (11) | 40 (43) | 26 (27) |
| Opponent | Holder | 35 | 99 (35) | 17 | 81 | 20 | 37% | 2.7 | 67 (5) | 114 (24) | 59 (5) | 117 (23) | 62 (11) |
| Opponent | Shooter | 33 | 75 (33) | 12 | 63 | 20 | 0% | 1.8 | 31 (8) | 99 (19) | 49 (6) | 114 (22) | 15 (11) |
| Opponent | Support | 3 | 0 (3) | 0 | 0 | 0 | 67% | 6.0 | 0 (1) | 0 (1) | 0 (1) | 0 (1) | 0 (2) |
| Opponent | War machine | 24 | 65 (24) | 65 | 0 | 17 | 8% | 1.5 | 0 (6) | 93 (14) | 56 (4) | 0 (3) | 75 (21) |
| Opponent | Wizard | 26 | 32 (26) | 32 | 0 | 33 | 12% | 1.4 | 0 (10) | 119 (6) | 11 (6) | 80 (8) | 3 (14) |

### Charged fights: su-h2h-mine-e45904b-p2

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 98 | 77 | 1.8 | 1.0 | 44 | 66 | -22 | 2 of 7 | 5 of 7 | - | -22 |
| Mine | Chaos Dwarfs | 4 | 48 | 260 | 2.2 | 1.3 | 116 | 0 | +116 | 7 of 9 | 6 of 9 | +258 | +75 |
| Mine | Dwarfen Mountain Holds | 4 | 701 | 136 | 2.2 | 1.3 | 61 | 11 | +50 | 4 of 9 | 9 of 9 | -32 | +91 |
| Mine | Empire of Man | 5 | 390 | 18 | 1.6 | 1.0 | 12 | 57 | -45 | 4 of 8 | 6 of 8 | - | -45 |
| Mine | Grand Cathay | 4 | 242 | 85 | 2.8 | 1.0 | 31 | 19 | +12 | 7 of 11 | 6 of 11 | - | +12 |
| Mine | High Elf Realms | 4 | 125 | 647 | 2.8 | 1.2 | 235 | 26 | +209 | 7 of 11 | 10 of 11 | +51 | +244 |
| Mine | Kingdom of Bretonnia | 1 | 465 | 904 | 6.0 | 1.5 | 151 | 46 | +104 | 2 of 6 | 6 of 6 | -24 | +233 |
| Mine | Lizardmen | 1 | 45 | 713 | 3.0 | 1.3 | 238 | 0 | +238 | 2 of 3 | 1 of 3 | +50 | +332 |
| Mine | Ogre Kingdoms | 1 | 0 | 278 | 2.0 | 1.0 | 139 | 17 | +122 | 0 of 2 | 1 of 2 | - | +122 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 295 | 4.0 | 1.2 | 74 | 0 | +74 | 1 of 4 | 4 of 4 | +45 | +83 |
| Mine | Skaven | 2 | 270 | 58 | 2.5 | 1.0 | 23 | 141 | -118 | 1 of 5 | 3 of 5 | - | -118 |
| Mine | Tomb Kings of Khemri | 1 | 364 | 1281 | 7.0 | 1.3 | 183 | 17 | +166 | 2 of 7 | 5 of 7 | +2 | +231 |
| Mine | Vampire Counts | 3 | 0 | 0 | 2.3 | 1.0 | 0 | 0 | +0 | 0 of 7 | 6 of 7 | - | +0 |
| Mine | Warriors of Chaos | 1 | 19 | 700 | 2.0 | 1.0 | 350 | 0 | +350 | 1 of 2 | 1 of 2 | - | +350 |
| **Mine** | all armies | 36 | 229 | 256 | 2.5 | 1.2 | 101 | 29 | +72 | 40 of 91 | 69 of 91 | +39 | +78 |
| Opponent | Dwarfen Mountain Holds | 2 | 136 | 110 | 2.5 | 1.4 | 44 | 33 | +11 | 1 of 5 | 3 of 5 | +53 | -17 |
| Opponent | Empire of Man | 2 | 600 | 0 | 1.5 | 1.3 | 0 | 127 | -127 | 1 of 3 | 3 of 3 | +0 | -190 |
| Opponent | Grand Cathay | 2 | 300 | 934 | 2.5 | 1.8 | 374 | 0 | +374 | 3 of 5 | 4 of 5 | +351 | +408 |
| Opponent | Kingdom of Bretonnia | 1 | 220 | 225 | 2.0 | 1.0 | 112 | 0 | +112 | 1 of 2 | 2 of 2 | - | +112 |
| Opponent | Ogre Kingdoms | 3 | 42 | 337 | 4.0 | 1.2 | 84 | 0 | +84 | 3 of 12 | 8 of 12 | +76 | +87 |
| Opponent | Skaven | 1 | 380 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Tomb Kings of Khemri | 4 | 182 | 999 | 4.0 | 1.4 | 250 | 54 | +196 | 5 of 16 | 14 of 16 | +427 | +91 |
| Opponent | Vampire Counts | 6 | 44 | 887 | 4.2 | 1.2 | 213 | 2 | +211 | 13 of 25 | 20 of 25 | +154 | +222 |
| Opponent | Warriors of Chaos | 8 | 16 | 436 | 2.5 | 1.1 | 174 | 10 | +164 | 8 of 20 | 19 of 20 | +218 | +155 |
| Opponent | Wood Elf Realms | 7 | 59 | 738 | 4.7 | 1.1 | 157 | 18 | +138 | 12 of 33 | 23 of 33 | +170 | +135 |
| **Opponent** | all armies | 36 | 120 | 592 | 3.4 | 1.2 | 176 | 19 | +157 | 47 of 121 | 96 of 121 | +221 | +142 |

### Effective charges: su-h2h-mine-e45904b-p2

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 7 | 0 | 0 | 0 | 2 (net +88) | 0 | 1 (net +72) | 4 | 0% (0 of 3) |
| Mine | Chaos Dwarfs | 9 | 0 | 0 | 1 (net +0) | 2 (net +0) | 1 (net +516) | 4 (net +132) | 1 | 12% (1 of 8) |
| Mine | Dwarfen Mountain Holds | 9 | 2 (net -48) | 0 | 2 (net +0) | 2 (net +0) | 0 | 3 (net +182) | 0 | 22% (2 of 9) |
| Mine | Empire of Man | 8 | 0 | 0 | 3 (net -88) | 1 (net -189) | 1 (net +0) | 1 (net +0) | 2 | 50% (3 of 6) |
| Mine | Grand Cathay | 11 | 3 (net -68) | 1 (net +0) | 3 (net +100) | 3 (net +0) | 1 (net +40) | 0 | 0 | 27% (3 of 11) |
| Mine | High Elf Realms | 11 | 0 | 0 | 2 (net +228) | 2 (net +79) | 3 (net +177) | 2 (net +324) | 2 | 22% (2 of 9) |
| Mine | Kingdom of Bretonnia | 6 | 0 | 0 | 1 (net +205) | 2 (net +247) | 1 (net +0) | 2 (net -36) | 0 | 17% (1 of 6) |
| Mine | Lizardmen | 3 | 1 (net +663) | 0 | 1 (net +0) | 0 | 1 (net +50) | 0 | 0 | 33% (1 of 3) |
| Mine | Ogre Kingdoms | 2 | 0 | 0 | 0 | 1 (net +278) | 0 | 0 | 1 | 0% (0 of 1) |
| Mine | Orc & Goblin Tribes | 4 | 0 | 0 | 1 (net +45) | 1 (net +190) | 0 | 0 | 2 | 50% (1 of 2) |
| Mine | Skaven | 5 | 0 | 0 | 1 (net -602) | 2 (net +26) | 1 (net +0) | 1 (net -38) | 0 | 20% (1 of 5) |
| Mine | Tomb Kings of Khemri | 7 | 1 (net +599) | 0 | 1 (net +0) | 0 | 2 (net +62) | 3 (net +145) | 0 | 14% (1 of 7) |
| Mine | Vampire Counts | 7 | 0 | 0 | 1 (net +0) | 3 (net +0) | 0 | 3 (net +0) | 0 | 14% (1 of 7) |
| Mine | Warriors of Chaos | 2 | 0 | 0 | 1 (net +464) | 0 | 0 | 0 | 1 | 100% (1 of 1) |
| Opponent | Dwarfen Mountain Holds | 5 | 1 (net -60) | 0 | 1 (net -105) | 2 (net +28) | 0 | 1 (net +166) | 0 | 20% (1 of 5) |
| Opponent | Empire of Man | 3 | 1 (net -380) | 0 | 0 | 0 | 1 (net +0) | 1 (net +0) | 0 | 0% (0 of 3) |
| Opponent | Grand Cathay | 5 | 2 (net +691) | 0 | 2 (net +92) | 0 | 0 | 1 (net +304) | 0 | 40% (2 of 5) |
| Opponent | Kingdom of Bretonnia | 2 | 0 | 0 | 1 (net +0) | 0 | 0 | 0 | 1 | 100% (1 of 1) |
| Opponent | Ogre Kingdoms | 12 | 3 (net +110) | 0 | 0 | 2 (net +22) | 0 | 5 (net +127) | 2 | 0% (0 of 10) |
| Opponent | Tomb Kings of Khemri | 16 | 2 (net +428) | 2 (net +146) | 2 (net +81) | 4 (net +122) | 1 (net +85) | 3 (net +225) | 2 | 14% (2 of 14) |
| Opponent | Vampire Counts | 25 | 6 (net +308) | 1 (net +297) | 9 (net +229) | 6 (net +178) | 0 | 3 (net +0) | 0 | 36% (9 of 25) |
| Opponent | Warriors of Chaos | 20 | 0 | 2 (net +282) | 3 (net +197) | 2 (net +84) | 1 (net +60) | 11 (net +163) | 1 | 16% (3 of 19) |
| Opponent | Wood Elf Realms | 33 | 3 (net +342) | 2 (net +532) | 3 (net -27) | 6 (net +77) | 2 (net +107) | 13 (net +117) | 4 | 10% (3 of 29) |

### Charged fights, damage counted: su-h2h-mine-e45904b-p2

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 7 | 257 | 392 | +137 | 183 | 99 | +84 | +32.8 |
| Mine | 50-54% | 1 | 369 | 297 | +0 | 148 | 53 | +96 | +26.0 |
| Mine | Effective (55-75%) | 18 | 267 | 265 | +34 | 105 | 67 | +38 | +14.2 |
| Mine | 76-89% | 21 | 257 | 197 | +55 | 70 | 20 | +50 | +19.5 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 20 | 250 | 187 | +106 | 170 | 31 | +139 | +55.7 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 11 | 555 | 113 | +115 | 166 | 26 | +140 | +25.2 |
| Mine | No odds | 13 | 231 | 159 | +35 | 92 | 41 | +51 | +22.0 |
| Mine | All fights | 91 | 291 | 209 | +72 | 123 | 42 | +81 | +28.0 |
| Opponent | Long shot (under 50%) | 18 | 287 | 304 | +278 | 351 | 75 | +277 | +96.4 |
| Opponent | 50-54% | 7 | 331 | 231 | +316 | 349 | 0 | +349 | +105.3 |
| Opponent | Effective (55-75%) | 21 | 327 | 205 | +134 | 169 | 34 | +135 | +41.2 |
| Opponent | 76-89% | 22 | 212 | 138 | +104 | 111 | 14 | +97 | +45.7 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 38 | 273 | 186 | +134 | 184 | 35 | +148 | +54.3 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 5 | 453 | 78 | +72 | 72 | 18 | +54 | +11.9 |
| Opponent | No odds | 10 | 200 | 229 | +127 | 168 | 40 | +127 | +63.8 |
| Opponent | All fights | 121 | 278 | 200 | +157 | 196 | 35 | +162 | +58.1 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| su-h2h-mine-e45904b-p2 | move | 457 | 89 (19%) | 65 (14%) | 60 (13%) | 308 (67%) |
| su-h2h-mine-e45904b-p2 | objective | 353 | 56 (16%) | 37 (10%) | 39 (11%) | 258 (73%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0106, L0122, L2429, L2535, L2735 |
| Charmed Shield | Opponent | L0425, L0827, L0934, L1026, L1727, L1827, L1927 |
| Clockwork Compass | Mine | L1228 |
| Clockwork Compass | Opponent | L0512 |
| Elixir of Power | Mine | L1118, L1135, L1927 |
| Fistful of Laurels | Mine | L1827 |
| Fistful of Laurels | Opponent | L0918, L1118, L1418 |
| Horn of the Wild Hunt | Opponent | L3033 |
| Invocation of Nehek | Mine | L2429, L2535, L2735 |
| Invocation of Nehek | Opponent | L0425, L0827, L1727, L1827, L1927 |
| Opal Amulet | Mine | L1418, L1435 |
| Periapt of Soul Exchange | Mine | L2029, L2131 |
| Periapt of Soul Exchange | Opponent | L0721 |
| Ring of Doom | Mine | L0206, L0222, L1118, L1135, L1228, L1531 |
| Ring of Doom | Opponent | L0512, L1531, L2131, L3033 |
| Ring of Jet | Mine | L1026, L1118, L1135, L1228 |
| Ring of Jet | Opponent | L0512, L0810 |
| Standard of the Fell Warrior | Mine | L1323 |
| Storm Daemon (Renegade 2.0) | Mine | L2131 |
| Storm Daemon (Renegade 2.0) | Opponent | L0721 |
| Twice-Blessed Armour | Mine | L0721, L1026 |
| Twice-Blessed Armour | Opponent | L0307, L0810 |
| Witch Hunter's Ward | Mine | L0721, L0810, L0827 |
| Witch Hunter's Ward | Opponent | L0307 |

# Doctrine scorecard: su-h2h-mine-e45904b-p1

### Scorecard: su-h2h-mine-e45904b-p1

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0102 | 6 | 1 | Mine | no | 5 | 3 | 1 | 0 | 1 | 0 | 0 | 142 |
| L0102 | 6 | 1 | Opponent | no | 2 | 2 | 5 | 3 | 1 | 0 | 0 | 222 |
| L0118 | 4 | 1 | Mine | no | 0 | 5 | 1 | 1 | 0 | 0 | 0 | 0 |
| L0118 | 4 | 1 | Opponent | no | 2 | 2 | 3 | 3 | 0 | 0 | 0 | 302 |
| L0135 | 3 | 1 | Mine | no | 4 | 2 | 0 | 1 | 0 | 0 | 0 | 132 |
| L0135 | 3 | 1 | Opponent | no | 8 | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L0218 | 2 | 1 | Mine | - | - | 2 | 2 | 3 | 0 | 0 | 0 | 170 |
| L0218 | 2 | 1 | Opponent | - | - | 3 | 1 | 2 | 0 | 0 | 0 | 0 |
| L0235 | 1 | 1 | Mine | no | 0 | 2 | 3 | 2 | 1 | 0 | 0 | 84 |
| L0235 | 1 | 1 | Opponent | no | 2 | 2 | 2 | 2 | 0 | 0 | 0 | 0 |
| L0319 | 1 | 1 | Mine | no | 7 | 3 | 3 | 0 | 0 | 0 | 0 | 675 |
| L0319 | 1 | 1 | Opponent | no | 1 | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| L0405 | 3 | 1 | Mine | yes | 3 | 2 | 1 | 2 | 0 | 0 | 0 | 124 |
| L0405 | 3 | 1 | Opponent | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 771 |
| L0421 | 1 | 1 | Mine | no | 0 | 2 | 7 | 1 | 0 | 0 | 0 | 0 |
| L0421 | 1 | 1 | Opponent | no | 0 | - | 0 | 3 | 0 | 0 | 0 | 145 |
| L0508 | 4 | 1 | Mine | no | 3 | - | 0 | 2 | 0 | 0 | 0 | 771 |
| L0508 | 4 | 1 | Opponent | no | 0 | 4 | 2 | 1 | 0 | 0 | 0 | 971 |
| L0524 | 2 | 1 | Mine | - | - | 2 | 2 | 1 | 0 | 0 | 0 | 475 |
| L0524 | 2 | 1 | Opponent | - | - | 6 | 3 | 4 | 0 | 0 | 0 | 0 |
| L0612 | 6 | 1 | Mine | no | 2 | - | 1 | 3 | 0 | 0 | 0 | 615 |
| L0612 | 6 | 1 | Opponent | no | 5 | 3 | 2 | 0 | 0 | 0 | 0 | 330 |
| L0628 | 4 | 1 | Mine | no | 0 | 5 | 1 | 1 | 0 | 0 | 0 | 1167 |
| L0628 | 4 | 1 | Opponent | no | 1 | 3 | 2 | 2 | 0 | 0 | 0 | 0 |
| L0717 | 3 | 1 | Mine | yes | 5 | 2 | 6 | 0 | 0 | 0 | 0 | 375 |
| L0717 | 3 | 1 | Opponent | yes | 7 | 2 | 2 | 0 | 2 | 0 | 0 | 175 |
| L0733 | 1 | 1 | Mine | no | 7 | 1 | 4 | 2 | 0 | 0 | 0 | 375 |
| L0733 | 1 | 1 | Opponent | no | 1 | 3 | 2 | 3 | 0 | 0 | 0 | 0 |
| L0823 | 1 | 1 | Mine | no | 0 | 2 | 1 | 1 | 1 | 0 | 0 | 560 |
| L0823 | 1 | 1 | Opponent | no | 0 | 2 | 4 | 1 | 2 | 0 | 0 | 70 |
| L0913 | 1 | 1 | Mine | no | 2 | 1 | 2 | 1 | 0 | 0 | 0 | 609 |
| L0913 | 1 | 1 | Opponent | no | 2 | 2 | 4 | 0 | 0 | 0 | 0 | 140 |
| L0930 | 6 | 1 | Mine | no | 0 | 6 | 0 | 0 | 0 | 0 | 0 | 629 |
| L0930 | 6 | 1 | Opponent | no | 7 | 2 | 4 | 2 | 0 | 0 | 0 | 98 |
| L1021 | 1 | 1 | Mine | no | 0 | 2 | 1 | 0 | 0 | 0 | 0 | 330 |
| L1021 | 1 | 1 | Opponent | no | 1 | - | 4 | 3 | 1 | 0 | 0 | 355 |
| L1114 | 4 | 1 | Mine | no | 0 | 2 | 2 | 1 | 0 | 0 | 0 | 427 |
| L1114 | 4 | 1 | Opponent | no | 0 | 5 | 1 | 5 | 0 | 0 | 0 | 677 |
| L1131 | 3 | 1 | Mine | no | 1 | - | 3 | 0 | 1 | 0 | 0 | 330 |
| L1131 | 3 | 1 | Opponent | no | 3 | 4 | 2 | 1 | 2 | 0 | 0 | 562 |
| L1224 | 6 | 1 | Mine | no | 10 | 3 | 1 | 0 | 0 | 0 | 0 | 330 |
| L1224 | 6 | 1 | Opponent | no | 1 | 2 | 1 | 2 | 0 | 0 | 0 | 0 |
| L1319 | 5 | 1 | Mine | no | - | 3 | 5 | 0 | 0 | 0 | 0 | 302 |
| L1319 | 5 | 1 | Opponent | yes | - | 2 | 4 | 2 | 0 | 0 | 0 | 0 |
| L1335 | 3 | 1 | Mine | no | 9 | 2 | 3 | 0 | 0 | 0 | 0 | 140 |
| L1335 | 3 | 1 | Opponent | no | 0 | 5 | 0 | 3 | 0 | 0 | 0 | 126 |
| L1431 | 3 | 1 | Mine | no | 9 | 2 | 6 | 0 | 0 | 0 | 0 | 0 |
| L1431 | 3 | 1 | Opponent | no | 1 | - | 1 | 3 | 1 | 0 | 0 | 340 |
| L1527 | 3 | 1 | Mine | no | 3 | 4 | 4 | 1 | 0 | 0 | 0 | 0 |
| L1527 | 3 | 1 | Opponent | no | 0 | 2 | 7 | 1 | 0 | 0 | 0 | 0 |
| L1625 | 5 | 1 | Mine | yes | - | 2 | 3 | 0 | 0 | 0 | 0 | 260 |
| L1625 | 5 | 1 | Opponent | yes | - | 3 | 2 | 1 | 0 | 0 | 0 | 398 |
| L1723 | 1 | 1 | Mine | no | 4 | 1 | 1 | 0 | 2 | 0 | 0 | 305 |
| L1723 | 1 | 1 | Opponent | yes | 8 | 2 | 5 | 1 | 1 | 0 | 0 | 0 |
| L1823 | 5 | 1 | Mine | no | - | - | 2 | 1 | 0 | 0 | 0 | 234 |
| L1823 | 5 | 1 | Opponent | yes | - | 1 | 2 | 1 | 1 | 0 | 0 | 0 |
| L1923 | 3 | 1 | Mine | no | 0 | 2 | 8 | 0 | 1 | 0 | 0 | 0 |
| L1923 | 3 | 1 | Opponent | no | 2 | 2 | 3 | 0 | 0 | 0 | 0 | 0 |
| L2025 | 3 | 1 | Mine | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 650 |
| L2025 | 3 | 1 | Opponent | no | 13 | 2 | 6 | 1 | 0 | 0 | 0 | 0 |
| L2127 | 3 | 1 | Mine | no | 0 | - | 1 | 2 | 0 | 0 | 0 | 257 |
| L2127 | 3 | 1 | Opponent | no | 5 | 2 | 2 | 3 | 0 | 0 | 0 | 0 |
| L2231 | 5 | 1 | Mine | yes | - | 2 | 3 | 0 | 1 | 0 | 0 | 0 |
| L2231 | 5 | 1 | Opponent | no | - | 2 | 3 | 2 | 3 | 0 | 0 | 371 |
| L2335 | 1 | 1 | Mine | no | 0 | 2 | 4 | 0 | 1 | 0 | 0 | 0 |
| L2335 | 1 | 1 | Opponent | no | 2 | 2 | 4 | 3 | 0 | 0 | 0 | 0 |
| L2531 | 5 | 1 | Mine | yes | - | 6 | 3 | 3 | 1 | 0 | 0 | 0 |
| L2531 | 5 | 1 | Opponent | yes | - | 4 | 0 | 2 | 1 | 0 | 0 | 0 |
| L2730 | 6 | 1 | Mine | no | 0 | 1 | 5 | 3 | 0 | 0 | 0 | 0 |
| L2730 | 6 | 1 | Opponent | no | 4 | 3 | 1 | 2 | 0 | 0 | 0 | 0 |
| L2934 | 6 | 1 | Mine | no | 2 | 2 | 2 | 1 | 0 | 0 | 0 | 170 |
| L2934 | 6 | 1 | Opponent | no | 9 | 2 | 4 | 1 | 0 | 0 | 0 | 160 |
| **Average** | | | Mine | 15% | 2.6 | 2.5 | 2.6 | 1.0 | 0.3 | 0.0 | 0.0 | 295.5 |
| **Average** | | | Opponent | 18% | 3.0 | 2.7 | 2.6 | 1.8 | 0.4 | 0.0 | 0.0 | 172.6 |

### KPIs: su-h2h-mine-e45904b-p1

Rules off - Opponent only: SET-UP SPOT, CARRIES OUT CLOSE-IN, JOINT AS ONE.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 30% (53 of 174) | 3% (6 of 179) | 17% (59 of 353) |
| Winner chose to follow up after the loser gave ground |  | 96% (53 of 55); on the table 96% | 100% (64 of 64); on the table 100% | 98% (117 of 119); on the table 98% |
| Winner chose to pursue after the loser fell back in good order |  | 89% (8 of 9); on the table 89% | 100% (16 of 16); on the table 100% | 96% (24 of 25); on the table 96% |
| Winner chose to pursue after the loser fled |  | 71% (22 of 31); on the table 71% | 94% (47 of 50); on the table 94% | 85% (69 of 81); on the table 85% |
| Winner chose to follow up or pursue (all three) |  | 87% (83 of 95); on the table 87% | 98% (127 of 130); on the table 98% | 93% (210 of 225); on the table 93% |
| Magic missiles tried each own turn | 50%+ | 35% (117 of 330) | 24% (50 of 210) | 31% (167 of 540) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 54% (117 of 216) | 33% (44 of 134) | 46% (161 of 350) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 54% (19 of 35) | 62% (32 of 52) | 59% (51 of 87) |
| Points that never fought | lower | 36% (25421 of 71484) | 37% (26407 of 71889) | 36% (51828 of 143373) |
|   infantry points that never fought | lower | 42% (7009 of 16863) | 57% (7570 of 13348) | 48% (14579 of 30211) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 56% (157 of 279) | 58% (170 of 295) | 57% (327 of 574) |
| Bound items with a magic missile used (at least once a game) |  | 95% (21 of 22); 2.0 uses a game | 80% (16 of 20); 1.1 uses a game | 88% (37 of 42); 1.6 uses a game |
| Bound items with another spell used |  | 69% (11 of 16); 0.5 uses a game | 0% (0 of 8); 0.0 uses a game | 46% (11 of 24); 0.2 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 47% (9 of 19); 0.2 uses a game | 58% (7 of 12); 0.2 uses a game | 52% (16 of 31); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 50% (29570 of 59666) | 54% (33886 of 62699) | 52% (63456 of 122365) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.6 (27%) | 1.4 (32%) | 3.0 (29%) |
| MARCHED: its unit marched | 0.8 (13%) | 0.5 (12%) | 1.3 (12%) |
| CHARGED: its unit charged | 0.2 (4%) | 0.1 (1%) | 0.3 (3%) |
| IN COMBAT: engaged in combat | 1.8 (30%) | 0.6 (14%) | 2.4 (23%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.4 (10%) | 0.4 (4%) |
| FLEEING: fleeing | 0.1 (1%) | 0.1 (2%) | 0.2 (2%) |
| GONE: slain | 0.7 (12%) | 1.1 (25%) | 1.8 (18%) |
| OFF THE TABLE: off the table or not arrived | 0.6 (10%) | 0.1 (2%) | 0.7 (7%) |
| STUPIDITY: Stupidity | 0.1 (2%) | 0.0 (0%) | 0.1 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.1 (1%) | 0.1 (1%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 3.8 | 1.4 | 1.2 | 4.6 | 0.6 | 1.9 |
| not cast | 4.2 | 2.9 | 3.5 | 10.4 | 1.8 | 22.1 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) | 0.0 (0%) | 1.3 (6%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.9 (32%) | 0.4 (10%) | 3.0 (29%) | 0.4 (22%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.3 (12%) | 0.3 (17%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (3%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.2 (5%) | 0.3 (11%) | 0.6 (16%) | 2.4 (23%) | 0.4 (22%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.2 (4%) | 0.3 (11%) | 0.5 (14%) | 0.4 (4%) | 0.0 (0%) | 0.0 (0%) |
| NO CASTS LEFT: every cast used on other spells | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (2%) | 0.0 (0%) |
| FLEEING: fleeing | 0.1 (3%) | 0.0 (0%) | 0.0 (0%) | 0.2 (2%) | 0.0 (0%) | 0.6 (3%) |
| GONE: slain | 1.4 (32%) | 0.4 (14%) | 0.6 (18%) | 1.8 (18%) | 0.2 (13%) | 3.2 (14%) |
| OFF THE TABLE: off the table or not arrived | 0.1 (3%) | 0.3 (10%) | 0.1 (2%) | 0.7 (7%) | 0.0 (0%) | 0.9 (4%) |
| STUPIDITY: Stupidity | 0.2 (4%) | 0.0 (1%) | 0.0 (1%) | 0.1 (1%) | 0.0 (0%) | 0.2 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.4 (15%) | 0.0 (0%) | 0.0 (0%) | 0.4 (24%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.0 (48%) | 0.1 (5%) | 1.3 (37%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 15.9 (72%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.0 a game | 0.4 a game | 0.7 a game |
| stood (cast and not dispelled) | 77% (24 of 31) | 62% (8 of 13) | 73% (32 of 44) |
| the unit moved after it | 71% (17 of 24) | 62% (5 of 8) | 69% (22 of 32) |
| it charged on its next turn | 4% (1 of 24) | 0% (0 of 8) | 3% (1 of 32) |
| the enemy charged it first | 17% (4 of 24) | 38% (3 of 8) | 22% (7 of 32) |
| it fought by the end of its next turn | 21% (5 of 24) | 12% (1 of 8) | 19% (6 of 32) |
| it moved out of a charge the enemy had planned (not charged first) | 4% (1 of 24) | 0% (0 of 8) | 3% (1 of 32) |
| none of these (no charge, no fight, no charge escaped) | 71% (17 of 24) | 62% (5 of 8) | 69% (22 of 32) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 64% (549 of 861) | 65% (402 of 619) | 64% (951 of 1480) |
|   cavalry | 58% (45 of 77) | 74% (97 of 131) | 68% (142 of 208) |
|   character | 50% (53 of 106) | 38% (47 of 124) | 43% (100 of 230) |
|   chariot | 43% (38 of 89) | 70% (28 of 40) | 51% (66 of 129) |
|   infantry | 58% (166 of 284) | 67% (153 of 230) | 62% (319 of 514) |
|   monster | 58% (19 of 33) | 54% (14 of 26) | 56% (33 of 59) |
|   war machine | 84% (228 of 272) | 93% (63 of 68) | 86% (291 of 340) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.4 (28%) | 1.6 (26%) | 4.0 (27%) |
| CHARGED: it charged | 1.2 (14%) | 1.1 (19%) | 2.4 (16%) |
| FLEEING: it fled or was fleeing | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: it fought this turn or the last | 0.7 (8%) | 0.4 (6%) | 1.1 (7%) |
| MOVED: a war machine that moved | 0.1 (1%) | 0.0 (0%) | 0.1 (0%) |
| NO TARGET IN RANGE | 1.6 (18%) | 1.3 (22%) | 2.9 (20%) |
| ONLY IN COMBAT: the only targets were in combat | 0.7 (8%) | 0.4 (6%) | 1.1 (7%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.5 (17%) | 0.9 (16%) | 2.4 (16%) |
| SHELTERED: the target was sheltered | 0.1 (2%) | 0.2 (4%) | 0.4 (2%) |
| OTHER BAR | 0.4 (4%) | 0.1 (1%) | 0.4 (3%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 6.1 | 1.3 | 82% | 3.7 pts | 22 pts |
| character | 3.3 | 0.6 | 83% | 4.4 pts | 15 pts |
| chariot | 1.9 | 1.0 | 74% | 8.0 pts | 15 pts |
| infantry | 12.8 | 4.5 | 77% | 8.7 pts | 112 pts |
| monster | 1.0 | 0.2 | 83% | 4.3 pts | 4 pts |
| war machine | 8.1 | 5.8 | 62% | 22.0 pts | 177 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.4 | 5.3 | 4.9 |
| Charges that made contact a game | 3.2 | 3.7 | 3.5 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.91 declared, 0.82 contact (22 units) | 0.21 declared, 0.14 contact (14 units) | 0.64 declared, 0.56 contact (36 units) |
|   per unit a game, units carrying another wizard (or one alone) | 1.00 declared, 0.75 contact (4 units) | 0.64 declared, 0.45 contact (11 units) | 0.73 declared, 0.53 contact (15 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.54 declared, 0.38 contact (251 units) | 0.65 declared, 0.45 contact (280 units) | 0.60 declared, 0.42 contact (531 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 57% (40 of 70) | 52% (11 of 21) | 50% (4 of 8) | 56% (55 of 99) |
| Character in a unit | 79% (31 of 39) | 83% (20 of 24) | 67% (2 of 3) | 80% (53 of 66) |
| Character on its own | 69% (33 of 48) | 42% (15 of 36) | 30% (19 of 63) | 46% (67 of 147) |
| Chariot | 88% (14 of 16) | 60% (6 of 10) | - | 77% (20 of 26) |
| Infantry | 53% (47 of 89) | 42% (15 of 36) | 50% (1 of 2) | 50% (63 of 127) |
| Monster | 62% (20 of 32) | 60% (6 of 10) | - | 62% (26 of 42) |
| Monstrous | 45% (5 of 11) | 50% (7 of 14) | - | 48% (12 of 25) |
| War Machines | 73% (30 of 41) | 100% (1 of 1) | - | 74% (31 of 42) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 6 | 74% (14 of 19); on the table 74% | 33% (45 of 138) | 20% | 55% (18 of 33) | 100% (9 of 9); 4.3 uses a game | 100% (3 of 3); 0.8 uses a game | 89% (8 of 9); 1.3 uses a game |
| Chaos Dwarfs | 3 | 100% (7 of 7); on the table 100% | 29% (7 of 24) | 40% | 50% (12 of 24) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Dwarfen Mountain Holds | 5 | 67% (4 of 6); on the table 67% | - | 60% | 71% (29 of 41) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 6 | 89% (17 of 19); on the table 89% | 17% (6 of 36) | 43% | 59% (38 of 64) | 0.0 uses a game | 100% (2 of 2); 1.0 uses a game | 25% (1 of 4); 0.2 uses a game |
| Grand Cathay | 5 | 100% (15 of 15); on the table 100% | 39% (42 of 108) | 49% | 48% (21 of 44) | 100% (12 of 12); 8.2 uses a game | 100% (1 of 1); 0.2 uses a game | 20% (1 of 5); 0.2 uses a game |
| High Elf Realms | 6 | 80% (12 of 15); on the table 80% | 37% (11 of 30) | 29% | 51% (25 of 49) | 100% (5 of 5); 2.2 uses a game | 28% (5 of 18); 0.8 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | 100% (3 of 3); on the table 100% | - | 32% | 50% (3 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Lizardmen | 2 | 88% (7 of 8); on the table 88% | - | 16% | 57% (8 of 14) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 3 | 100% (5 of 5); on the table 100% | 25% (3 of 12) | 53% | 67% (14 of 21) | 67% (2 of 3); 1.7 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 3 | 100% (8 of 8); on the table 100% | 3% (1 of 36) | 4% | 54% (13 of 24) | 0.0 uses a game | 0.0 uses a game | 67% (2 of 3); 0.7 uses a game |
| Skaven | 4 | 100% (8 of 8); on the table 100% | 37% (11 of 30) | 34% | 62% (21 of 34) | 100% (3 of 3); 2.0 uses a game | 0.0 uses a game | 25% (1 of 4); 0.2 uses a game |
| Tomb Kings of Khemri | 6 | 97% (28 of 29); on the table 97% | 0% (0 of 12) | 34% | 37% (11 of 30) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 8 | 100% (32 of 32); on the table 100% | 37% (20 of 54) | 40% | 62% (31 of 50) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 8 | 96% (25 of 26); on the table 96% | 37% (11 of 30) | 39% | 65% (48 of 74) | 100% (4 of 4); 1.8 uses a game | 0.0 uses a game | 50% (1 of 2); 0.1 uses a game |
| Wood Elf Realms | 6 | 100% (25 of 25); on the table 100% | 33% (10 of 30) | 28% | 53% (35 of 66) | 33% (2 of 6); 0.8 uses a game | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |

Flank and rear charges a unit could have turned to face (su-h2h-mine-e45904b-p1, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 50% (37) | 43% (28) | 47% (65) |
| ...free all their last turn and able to turn (per game) | 0.61 | 0.47 | 1.08 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.22 | 0.14 | 0.36 |
| ...with the charger already in that arc before they moved (per game) | 0.44 | 0.36 | 0.81 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 1.75 | 1.25 | 3.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 1.03 | 0.67 | 1.69 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 5.94 | 5.36 | 11.31 |

### Quality by phase: su-h2h-mine-e45904b-p1

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.1 | 3.4 |
| Strategy | Charge objectives carried out (made contact) | 56% (70 of 125) | 42% (69 of 165) |
| Strategy | Shoot objectives carried out (shot that target) | 48% (189 of 391) | 60% (126 of 210) |
| Strategy | Close-in objectives charged next turn | 19% (24 of 126) | 20% (39 of 199) |
| Strategy | Support requests answered (helper made contact too) | 29% (7 of 24) | 39% (12 of 31) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 33% (1 of 3) | 100% (3 of 3) |
| Strategy | Hexes on a unit its side charged or shot that turn | 47% (7 of 15) | 38% (5 of 13) |
| Strategy | Joined characters whose unit fought | 45% (23 of 51) | 57% (25 of 44) |
| Strategy | Lone characters that fought | 75% (71 of 95) | 77% (71 of 92) |
| Movement | Charges halted short of contact | 0.2 | 0.1 |
| Movement | Idle units | 1.0 | 1.8 |
| Movement | Points that never moved of their own | 295.5 | 172.6 |
| Movement | Fights charged into per game | 2.8 | 3.3 |
| Movement | Charges with odds: long shots (under 50%) | 13 of 84, net -38 | 14 of 102, net +76 |
| Movement | Charges with odds: sweet spot (55-75%) | 16 of 84, net +121 | 29 of 102, net +70 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 6 of 84, net +90 | 2 of 102, net +329 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 27 of 84, net +88 | 25 of 102, net +150 |
| Shooting | Shots by shooting units (incl. breath weapons) | 9.7 | 10.5 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 41% (144 of 350) | 46% (174 of 379) |
| Shooting | Points destroyed by shooting units | 59.8 | 23.1 |
| Shooting | War machine shots | 6.3 | 1.8 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 49% (112 of 228) | 43% (27 of 63) |
| Shooting | Points destroyed by war machines | 81.1 | 32.5 |
| Magic | Magic missiles cast | 2.2 | 0.9 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 30% (24 of 80) | 45% (15 of 33) |
| Magic | Wounds caused by magic missiles | 5.6 | 1.1 |
| Magic | Wounds caused by other spells | 1.5 | 0.7 |
| Magic | Points destroyed by magic (all spells) | 89.4 | 10.2 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.5 / 0.4 / 1.0 / 0.2 | 1.4 / 0.4 / 0.4 / 0.2 |
| Combat | Points destroyed in combat | 307.8 | 311.4 |
| Combat | Points run down | 52.7 | 209.0 |
| Combat | Net points per charged fight, damage counted | +76 | +103 |
| Combat | Net per 100 charger points, damage counted | +26.2 | +41.0 |
| Combat | First round won (charged fights) | 63% | 77% |
| Combat | Net points per charged fight | +73 | +104 |
| Combat | Net points per supported fight / lone fight | +180 / +58 | +191 / +93 |
| Combat | Charged fights on a top-3 enemy unit | 43 of 101 | 55 of 120 |
| Game | Points lost | 708.5 | 703.1 |
| Game | VP from objectives | 595.6 | 682.8 |
| Game | Lone holders (player turns) | 2.6 | 3.0 |

- Mine won / drew / lost: 10 / 7 / 19 of 36 ended games (of 36); mean margin (Mine - Opponent) -106 VP
- The side that went first won 12 of 29 games with a winner
- Points traded per game (both sides' losses): 1412
- Games not ended: 0; findings 1, warnings 0

### Opponent rules: su-h2h-mine-e45904b-p1

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.6 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 4.5 |
| ALREADY CARRIED | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARRIVAL HUNT | - | - | - | - | 0.0 | +0.2 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.2 | +0.0 | 0.0 | 15.4 | 0.3 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | 0.8 | +8.8 | 0.0 | 30.6 | 1.2 | +9.2 | 0.0 | 16.4 |
| BEST FACING | 0.8 | +28.8 | 0.0 | 16.4 | 0.6 | +21.2 | 0.0 | 31.0 |
| BEST FIRST | 4.4 | +188.0 | 179.5 | 82.3 | 3.5 | +147.3 | 68.0 | 56.7 |
| BEST OVERALL | 0.7 | +41.6 | 0.0 | 23.6 | 0.3 | +24.6 | 0.0 | 21.1 |
| BEST PREY | 0.8 | +45.6 | 24.9 | 8.9 | 1.3 | +59.1 | 31.5 | 31.5 |
| BEST PRIZE | 0.1 | -0.8 | 0.0 | 0.0 | 0.1 | -0.5 | 6.2 | 0.0 |
| BIG CHARACTER SAFETY | 0.2 | -1.1 | 0.0 | 0.0 | 0.2 | +0.2 | 0.0 | 15.0 |
| BLOCKED CHARGE SKIPPED | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| BLOCKED WHEEL | 0.2 | +1.1 | 0.0 | 6.5 | 0.2 | +7.1 | 0.0 | 0.0 |
| BLOWS WHERE AIMED | 0.3 | -25.7 | 28.4 | 15.5 | 0.2 | -18.1 | 13.4 | 6.7 |
| CANNON PLAN MISSED | 0.8 | +0.0 | 103.3 | 3.5 | 0.2 | +0.0 | 29.3 | 0.0 |
| CANNON PLANNED TARGET | 5.2 | +162.8 | 333.2 | 41.9 | 1.4 | +39.0 | 82.9 | 0.0 |
| CANNON SIGHT KEPT | 1.0 | +0.0 | 0.0 | 3.5 | 0.4 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT CLOSE-IN | 0.4 | -9.9 | 62.3 | 0.0 | - | - | - | - |
| CARRIES OUT COUNTER | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | -0.1 | 0.0 | 10.2 |
| CARRIES OUT SET-UP | 0.1 | -1.4 | 1.1 | 0.0 | 0.1 | +0.0 | 4.4 | 0.0 |
| CAST JOB | 0.4 | +12.3 | 24.8 | 17.4 | 0.3 | +7.3 | 3.3 | 0.0 |
| CASTER AWAY FROM SCREEN | 0.4 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.5 | +47.1 | 16.6 | 0.0 | 0.1 | +4.0 | 3.8 | 4.4 |
| CASTS AFTER FRIENDS | 0.6 | +0.0 | 0.0 | 22.5 | 0.2 | +0.0 | 0.0 | 28.3 |
| CASTS FROM BEHIND | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.0 | +0.3 | 0.0 | 0.0 | - | - | - | - |
| CATCH ODDS | - | - | - | - | 0.1 | +3.6 | 0.0 | 0.0 |
| CHAFF PASSED | 0.2 | -0.1 | 0.0 | 12.1 | 0.2 | -0.5 | 7.8 | 3.8 |
| CHARGE BAND | 0.1 | +0.0 | 20.8 | 0.0 | 0.2 | +0.0 | 31.1 | 0.0 |
| CHARGE NOW FIRST | 2.1 | +0.0 | 233.9 | 87.5 | 2.3 | +0.0 | 193.5 | 43.0 |
| CHARGE NOW WEIGHED | 0.4 | -22.0 | 23.9 | 11.1 | 0.6 | -39.3 | 20.1 | 10.0 |
| CHARGER SLAIN LOST | 0.5 | -16.9 | 23.6 | 11.5 | 0.8 | -17.8 | 70.5 | 32.6 |
| CHARIOT NO STATIC JOB | 0.0 | +0.0 | 0.0 | 2.4 | - | - | - | - |
| CHARIOT WIZARD CAREFUL | 0.1 | -0.5 | 4.4 | 0.0 | 0.1 | -0.0 | 0.0 | 15.0 |
| CHEAP HELPER | 0.1 | +0.0 | 0.0 | 1.8 | 0.1 | +0.0 | 3.3 | 0.0 |
| COMBAT PIVOT | 0.7 | +0.0 | 23.3 | 15.1 | 0.4 | +0.0 | 7.9 | 14.9 |
| CONTINUE AHEAD WEIGHED | - | - | - | - | 0.1 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | 0.6 | +129.9 | 0.0 | 3.6 | 0.2 | +39.9 | 8.8 | 15.2 |
| COUNTER-CHARGE COVER | 8.9 | +829.0 | 0.0 | 167.5 | 6.7 | +674.3 | 0.0 | 173.6 |
| DEFENSIVE ARMY | 0.0 | +0.0 | 0.0 | 1.8 | 0.2 | +0.0 | 4.4 | 0.0 |
| DEFENSIVE FLOOR | 0.0 | -0.5 | 0.0 | 0.0 | - | - | - | - |
| EDGE GIVE GROUND | 0.1 | +2.0 | 7.6 | 0.0 | 0.3 | +6.7 | 25.6 | 14.7 |
| ELIXIR WORTH | - | - | - | - | 0.1 | +2.1 | 0.0 | 0.0 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 1.8 | +97.6 | 0.0 | 44.3 | 1.2 | +90.1 | 0.0 | 72.2 |
| FALLBACK BY WORTH | 4.2 | +40.6 | 0.0 | 32.9 | 5.5 | +85.5 | 0.0 | 73.8 |
| FLANK NOT WEIGHED | 5.4 | +0.0 | 0.0 | 113.7 | 5.1 | +0.0 | 0.0 | 145.3 |
| FOCUS FIRE | 0.1 | +4.0 | 3.5 | 0.0 | 0.0 | +0.3 | 0.0 | 0.0 |
| FOLLOW UP WEIGHED | 0.8 | +150.4 | 0.0 | 20.4 | 1.2 | +193.6 | 0.0 | 50.8 |
| FRIENDS SHOTS CHECKED | 0.2 | +10.2 | 0.0 | 11.7 | 0.2 | +7.7 | 0.0 | 3.5 |
| GIVES UP | - | - | - | - | 0.1 | -0.3 | 0.0 | 11.0 |
| GIVES UP ITS SCREEN | 0.0 | -0.6 | 0.0 | 1.7 | - | - | - | - |
| GROUND FLIERS | 0.0 | +0.6 | 0.0 | 0.0 | 0.0 | +0.5 | 0.0 | 0.0 |
| HELPER ALREADY ASKED | 0.1 | +0.0 | 13.1 | 0.0 | - | - | - | - |
| HELPER UNSEEN | 0.3 | +0.0 | 31.8 | 0.0 | 0.3 | +0.0 | 10.8 | 17.7 |
| HILL BY ITS CHANCE | 0.0 | -1.6 | 0.0 | 2.3 | 0.1 | -9.5 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.8 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 6.7 | -133.2 | 431.4 | 124.7 | 8.8 | -167.6 | 468.1 | 231.1 |
| HUNT ADVANCE | 0.1 | +1.8 | 0.0 | 3.2 | 0.1 | +7.2 | 0.0 | 6.1 |
| HUNT DROPPED | 0.0 | +0.0 | 0.0 | 3.2 | 0.1 | +0.0 | 0.0 | 0.0 |
| HUNT IN PAIRS | 0.5 | +16.6 | 0.0 | 15.4 | 0.4 | +19.8 | 0.0 | 16.9 |
| HUNT KEPT | 0.1 | +0.9 | 0.0 | 3.2 | 0.0 | +0.0 | 0.0 | 0.0 |
| HUNT RESULT | 0.1 | +0.0 | 0.0 | 3.2 | 0.1 | +0.0 | 0.0 | 3.2 |
| HUNT THE GUNS | 0.1 | +16.6 | 0.0 | 0.0 | 0.1 | +52.1 | 0.0 | 6.1 |
| INVITES THE FIGHT | 1.8 | +35.5 | 64.4 | 15.1 | 1.5 | +22.9 | 33.7 | 45.2 |
| JOINT AS ONE | 2.4 | -38.6 | 100.2 | 98.2 | - | - | - | - |
| JOINT CHARGE PLAN | 0.1 | +0.4 | 0.0 | 5.2 | 0.2 | +5.9 | 0.0 | 4.0 |
| JOINT KNOWS CHALLENGE | 0.1 | -5.9 | 0.0 | 3.4 | 0.2 | -3.6 | 12.4 | 1.9 |
| KEEP FALLS | 0.0 | +0.1 | 0.0 | 0.0 | 0.1 | +0.5 | 0.0 | 0.0 |
| KEEPS ITS PREY | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +0.2 | 0.0 | 0.0 |
| KEEPS ITS TARGET | 1.4 | +42.5 | 152.3 | 20.8 | 2.0 | +59.2 | 147.6 | 35.4 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KILLS COUNT | 1.3 | +68.1 | 104.0 | 32.7 | 2.0 | +81.1 | 134.6 | 44.7 |
| KILLS COUNT NEXT TURN | 4.1 | +119.0 | 200.7 | 102.5 | 6.9 | +276.8 | 278.9 | 138.3 |
| LONE CHARACTER SAFE SPOT | 0.4 | +16.9 | 4.4 | 12.3 | 0.4 | +6.8 | 10.2 | 0.0 |
| LONE WIZARD HOLDS BACK | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 7.1 | 5.9 |
| LONE WIZARD KEPT IN | 0.7 | +49.1 | 0.0 | 0.0 | 0.2 | +24.5 | 0.0 | 0.0 |
| LONG SHOT | 0.5 | -4.5 | 13.1 | 17.3 | 0.8 | -0.8 | 53.7 | 16.2 |
| LOST CHARGE | 2.8 | -34.2 | 126.9 | 54.5 | 3.1 | -47.1 | 75.8 | 115.4 |
| LURE BY WHAT IT DRAWS | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MAKE SURE TOGETHER | 0.2 | +4.1 | 0.0 | 16.5 | 0.7 | +27.1 | 26.2 | 21.0 |
| MANOEUVRE | 0.1 | +2.3 | 0.0 | 0.8 | 0.2 | +5.3 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.1 | +1.7 | 0.0 | 0.0 | 0.1 | +1.2 | 0.0 | 4.4 |
| MARCH CHECK | 0.6 | +41.7 | 0.0 | 15.2 | 0.5 | +27.5 | 0.0 | 3.0 |
| MARCH ODDS | 0.2 | +13.5 | 2.9 | 0.0 | 0.4 | +36.2 | 6.0 | 16.4 |
| MARCH OVER CASTS | 0.4 | +47.2 | 0.0 | 0.0 | 0.3 | +18.1 | 0.0 | 32.4 |
| MAX FOR POSITIONING | 4.8 | +187.7 | 0.0 | 89.5 | 5.0 | +170.7 | 0.0 | 101.4 |
| MISSILES IN THE MOVE | 4.2 | +148.7 | 0.0 | 83.0 | 3.3 | +63.5 | 0.0 | 83.3 |
| MISSILES NEXT TURN | 4.7 | +97.5 | 0.0 | 80.8 | 4.1 | +41.7 | 0.0 | 130.7 |
| MODEL FACING | 0.3 | +84.8 | 0.0 | 5.0 | - | - | - | - |
| MONSTER WIZARD ROAMS | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 12.1 |
| MOVE AND CAST | 0.3 | +19.9 | 0.0 | 10.2 | 0.5 | +19.6 | 0.0 | 4.4 |
| MOVE SPELL IN RANGE | 0.2 | +6.4 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.3 | -53.7 | 0.0 | 26.9 | 0.0 | -2.0 | 0.0 | 7.6 |
| MOVE SPELL SPOT | 0.2 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 13.1 |
| MOVE TO CHARGE | 2.1 | +161.9 | 96.2 | 31.9 | 4.2 | +265.1 | 188.9 | 128.8 |
| MOVES UNITS SPELL | 0.1 | +3.4 | 0.0 | 0.0 | 0.1 | +1.8 | 0.0 | 0.0 |
| NEEDED THERE | - | - | - | - | 0.0 | +0.5 | 6.5 | 3.5 |
| NO CHARGE WHY | 2.4 | +0.0 | 70.0 | 75.2 | 3.5 | +0.0 | 185.0 | 112.6 |
| NOT NEEDED | 0.3 | -10.2 | 47.8 | 4.9 | 0.2 | -10.5 | 27.7 | 0.0 |
| NOT TURNED | 5.9 | +114.4 | 0.0 | 139.7 | 5.4 | +97.0 | 0.0 | 130.9 |
| NOT WORTH A CAST | 0.8 | -0.6 | 0.0 | 31.0 | 0.3 | -0.2 | 0.0 | 15.0 |
| OFF BEST | 15.5 | -750.7 | 3.1 | 300.0 | 15.7 | -863.5 | 0.9 | 262.5 |
| OPENS A LANE | 0.2 | +0.8 | 12.3 | 0.0 | 0.1 | +0.5 | 1.4 | 0.0 |
| OPENS UP | 0.2 | +14.2 | 11.2 | 0.0 | 0.1 | +5.9 | 3.6 | 7.9 |
| OVERRUNS AWAY | 0.3 | +7.0 | 37.0 | 8.7 | 0.5 | +9.7 | 45.0 | 7.1 |
| PATHS CROSS | 2.0 | +103.9 | 0.0 | 17.6 | 2.4 | +122.4 | 0.0 | 60.1 |
| PERIAPT WORTH | 0.0 | +2.8 | 0.0 | 0.0 | - | - | - | - |
| PIVOT GUARDS FLANK | 0.2 | -5.3 | 0.0 | 21.3 | 0.2 | -3.8 | 0.0 | 9.9 |
| PLAN RESULT | 37.4 | +1244.3 | 1243.2 | 879.8 | 37.1 | +1073.2 | 1445.6 | 852.1 |
| PURSUES BIG PREY | 0.1 | -9.2 | 0.0 | 0.0 | 0.2 | -34.8 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE NEXT TURN | - | - | - | - | 0.1 | +12.3 | 0.0 | 1.5 |
| RANDOM MOVE BY FIGURES | 1.0 | +13.3 | 0.0 | 20.8 | 1.4 | +22.2 | 0.0 | 40.1 |
| RANDOM MOVER NO PROMISE | 0.1 | -5.0 | 0.0 | 4.0 | 0.3 | -9.5 | 4.6 | 4.7 |
| REDIRECT BY WHAT IT STOPS | 0.2 | -1.5 | 0.0 | 5.5 | 0.6 | -7.9 | 0.0 | 9.1 |
| REDIRECT COUNTER | 2.0 | +135.0 | 0.0 | 46.2 | 3.8 | +372.5 | 0.0 | 61.8 |
| REDIRECT WEIGHED | 0.3 | -0.5 | 0.0 | 4.9 | 0.3 | +16.9 | 26.6 | 3.5 |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 23.0 |
| RESERVE FALL BACK | 0.4 | +10.4 | 0.0 | 7.1 | 1.0 | +45.3 | 0.0 | 18.1 |
| RESTRAINS TO SHOOT | 0.1 | +4.6 | 0.0 | 0.0 | 0.1 | +1.9 | 0.0 | 0.0 |
| RISK BY ARC | 2.2 | +89.7 | 193.3 | 90.4 | 2.8 | +71.4 | 242.9 | 88.9 |
| SAFE SURE CHARGE | 0.0 | -0.8 | 0.0 | 0.0 | - | - | - | - |
| SAFER THAN THE JOB | 1.0 | +62.3 | 0.0 | 34.7 | 0.7 | +38.6 | 0.0 | 17.2 |
| SCOUT SPOT | 0.4 | +0.7 | 0.0 | 0.0 | 0.3 | +0.6 | 0.0 | 0.9 |
| SCOUT WAITS | 0.4 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.9 |
| SCREEN BY WHAT IT SAVES | 0.1 | -4.0 | 0.0 | 1.9 | 0.2 | -1.0 | 0.0 | 3.9 |
| SEARCH SPOT | 1.9 | +81.5 | 0.0 | 34.9 | 2.9 | +147.2 | 0.0 | 43.2 |
| SELF MOVE SPELL | 0.3 | +16.8 | 0.0 | 18.1 | 0.2 | -0.3 | 0.0 | 0.0 |
| SET UP TOGETHER | 0.4 | +6.5 | 0.0 | 17.9 | 1.7 | +98.4 | 36.7 | 59.9 |
| SET-UP ANY TARGET | 0.2 | +17.6 | 0.0 | 3.6 | 0.1 | +8.5 | 0.0 | 0.0 |
| SET-UP MISSED | 0.1 | +6.3 | 0.0 | 0.0 | 0.1 | +6.1 | 0.0 | 0.0 |
| SET-UP SPOT | 4.1 | +67.6 | 103.4 | 57.0 | - | - | - | - |
| SHOOTER COUNTED ONCE | - | - | - | - | 0.1 | -0.2 | 0.0 | 1.7 |
| SHOOTERS IN TWO RANKS | 0.4 | +0.9 | 0.0 | 0.0 | 0.3 | +0.8 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.4 | +46.9 | 92.0 | 21.6 | 0.9 | +25.4 | 32.8 | 6.7 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 3.2 | 0.0 | +0.0 | 0.0 | 0.0 |
| SHOT REPLANNED | 0.6 | +0.0 | 131.6 | 0.0 | 0.3 | +0.0 | 40.4 | 8.0 |
| SHOTS IN THE MOVE | 14.3 | +614.9 | 0.0 | 194.5 | 10.0 | +253.1 | 0.0 | 76.6 |
| SPELL SETS UP CHARGE | 0.4 | +88.2 | 0.0 | 3.6 | 0.1 | +8.5 | 0.0 | 0.0 |
| SPELL WORTH | 1.2 | +18.9 | 33.7 | 43.1 | 1.4 | +35.1 | 115.4 | 125.4 |
| SPELLS IN THE FIGHT | 0.5 | +4.3 | 76.1 | 20.6 | 0.6 | -14.0 | 45.9 | 21.1 |
| STABLE ROLE | 10.9 | +0.0 | 333.2 | 226.1 | 9.7 | +0.0 | 366.9 | 152.0 |
| STANDS TO CAST | - | - | - | - | 0.1 | +7.8 | 0.0 | 0.0 |
| STAY WEIGHED | 0.0 | +1.1 | 0.0 | 0.0 | - | - | - | - |
| STOPS | - | - | - | - | 0.0 | +0.1 | 0.0 | 0.0 |
| STOPS SHORT OF THE FLANK | 0.5 | +17.9 | 0.0 | 8.0 | 0.3 | +11.9 | 0.0 | 13.2 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 4.7 | 0.2 | +0.0 | 0.0 | 0.0 |
| SUPPORT NARROWED | 5.2 | -40.3 | 267.8 | 143.9 | 6.8 | -49.6 | 380.5 | 147.7 |
| SUPPORTS | 3.4 | +40.3 | 105.4 | 76.2 | 4.5 | +50.0 | 218.8 | 84.2 |
| SURE CHARGE BEATS ADVANCE | 0.1 | -2.2 | 3.6 | 0.0 | 0.1 | -3.3 | 11.0 | 0.0 |
| SURE REACH TOGETHER | 0.7 | -5.0 | 45.0 | 7.8 | 0.9 | +0.7 | 13.4 | 11.6 |
| THROUGH LINE OF FIRE | 0.6 | +16.7 | 0.0 | 8.6 | 0.1 | +5.9 | 0.0 | 0.0 |
| TURN WORTH | 0.2 | -16.1 | 12.7 | 6.3 | 0.2 | -10.9 | 26.9 | 1.2 |
| TWO OR MORE ARRIVE | - | - | - | - | 0.5 | +3.7 | 0.0 | 12.1 |
| WAIT AFTER COSTS | 5.7 | -282.5 | 232.0 | 79.6 | 7.6 | -394.7 | 300.1 | 201.0 |
| WALKS TO THE FIGHT | 1.5 | +26.0 | 34.9 | 28.8 | 0.8 | +20.7 | 38.8 | 20.2 |
| WAR ENGINE CHARGES | 0.1 | +10.1 | 12.7 | 0.0 | 0.1 | +4.7 | 0.0 | 2.1 |
| WAR ENGINE JOBS | 0.5 | +0.0 | 32.9 | 25.0 | 0.5 | +0.0 | 8.0 | 7.2 |
| WEARS DOWN | 1.4 | +61.9 | 126.9 | 55.7 | 1.4 | +39.7 | 142.4 | 56.4 |
| WHO HITS BACK | 0.2 | +11.3 | 0.0 | 11.3 | 0.2 | +31.2 | 0.0 | 3.8 |
| WHOLE FIGHT | 0.2 | +13.1 | 12.6 | 3.4 | 0.5 | +32.0 | 58.7 | 15.1 |
| WHOLE FIGHT GAIN | 0.4 | +33.1 | 10.2 | 8.3 | 0.6 | +35.1 | 46.1 | 14.7 |
| WIDER SPREAD | 2.3 | -7.4 | 186.6 | 70.6 | 3.2 | -8.1 | 233.9 | 102.4 |
| WOUNDED STAYS OUT | - | - | - | - | 0.0 | +0.0 | 4.9 | 0.0 |

### Rule changes: su-h2h-mine-e45904b-p1

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 1122 | 1122 | 1122 | 31.17 | -58111 | -51.8 |
| BEST FIRST | 286 | 286 | 286 | 7.94 | +12069 | +42.2 |
| SEARCH SPOT | 172 | 172 | 170 | 4.72 | +8245 | +48.5 |
| COUNTER-CHARGE COVER | 560 | 292 | 165 | 4.58 | +10689 | +64.8 |
| PATHS CROSS | 157 | 157 | 157 | 4.36 | +8145 | +51.9 |
| MOVE TO CHARGE | 226 | 226 | 122 | 3.39 | +4923 | +40.3 |
| FACES THE THREAT | 108 | 108 | 108 | 3.00 | +6755 | +62.5 |
| KILLS COUNT NEXT TURN | 393 | 393 | 106 | 2.94 | +3614 | +34.1 |
| SUPPORTS | 285 | 285 | 103 | 2.86 | +898 | +8.7 |
| FALLBACK BY WORTH | 350 | 350 | 78 | 2.17 | +4539 | +58.2 |
| FOLLOW UP WEIGHED | 72 | 72 | 72 | 2.00 | +12386 | +172.0 |
| SET-UP SPOT | 149 | 149 | 72 | 2.00 | +2460 | +34.2 |
| SHOTS IN THE MOVE | 877 | 596 | 69 | 1.92 | +2205 | +32.0 |
| WAIT AFTER COSTS | 477 | 477 | 65 | 1.81 | +1376 | +21.2 |
| SAFER THAN THE JOB | 61 | 61 | 61 | 1.69 | +3631 | +59.5 |
| ARTILLERY RE-ROLL WEIGHED | 54 | 54 | 54 | 1.50 | +0 | +0.0 |
| CANNON SIGHT KEPT | 51 | 51 | 51 | 1.42 | +0 | +0.0 |
| RANDOM MOVE BY FIGURES | 87 | 87 | 51 | 1.42 | +1276 | +25.0 |
| RESERVE FALL BACK | 50 | 50 | 50 | 1.39 | +2007 | +40.1 |
| BEST FACING | 48 | 48 | 48 | 1.33 | +1800 | +37.5 |
| CANNON PLANNED TARGET | 238 | 238 | 48 | 1.33 | -98 | -2.0 |
| WALKS TO THE FIGHT | 84 | 84 | 47 | 1.31 | +742 | +15.8 |
| ADVANCE LANE KEPT | 46 | 46 | 46 | 1.28 | +0 | +0.0 |
| HOLDS AMBUSHERS | 44 | 44 | 44 | 1.22 | +0 | +0.0 |
| REDIRECT COUNTER | 208 | 110 | 43 | 1.19 | +3655 | +85.0 |
| SHOOTS FROM THE BEST SPOT | 82 | 82 | 41 | 1.14 | +1374 | +33.5 |
| COMBAT PIVOT | 39 | 39 | 39 | 1.08 | +0 | +0.0 |
| MARCH CHECK | 41 | 40 | 39 | 1.08 | +2617 | +67.1 |
| MAX FOR POSITIONING | 353 | 179 | 39 | 1.08 | +628 | +16.1 |
| RISK BY ARC | 179 | 174 | 39 | 1.08 | +1376 | +35.3 |
| BEST OVERALL | 38 | 38 | 38 | 1.06 | +2383 | +62.7 |
| CHARGE NOW WEIGHED | 37 | 37 | 37 | 1.03 | +2054 | +55.5 |
| LONE WIZARD KEPT IN | 34 | 34 | 34 | 0.94 | +2648 | +77.9 |
| MISSILES IN THE MOVE | 270 | 161 | 34 | 0.94 | +733 | +21.5 |
| SET UP TOGETHER | 78 | 67 | 34 | 0.94 | +1283 | +37.7 |
| SHOT REPLANNED | 33 | 33 | 33 | 0.92 | +0 | +0.0 |
| KILLS COUNT | 118 | 116 | 29 | 0.81 | +1121 | +38.7 |
| STOPS SHORT OF THE FLANK | 29 | 29 | 29 | 0.81 | +1076 | +37.1 |
| CHARGE NOW FIRST | 158 | 158 | 27 | 0.75 | -1348 | -49.9 |
| MOVE AND CAST | 27 | 27 | 27 | 0.75 | +1425 | +52.8 |
| CASTER AWAY FROM SCREEN | 26 | 26 | 26 | 0.72 | +0 | +0.0 |
| SCOUT WAITS | 26 | 26 | 26 | 0.72 | +0 | +0.0 |
| THROUGH LINE OF FIRE | 26 | 26 | 26 | 0.72 | +814 | +31.3 |
| HONEST WORTH | 556 | 552 | 24 | 0.67 | +206 | +8.6 |
| SHOOTERS IN TWO RANKS | 24 | 24 | 24 | 0.67 | +58 | +2.4 |
| INVITES THE FIGHT | 118 | 118 | 22 | 0.61 | +518 | +23.6 |
| MARCH ODDS | 23 | 23 | 22 | 0.61 | +233 | +10.6 |
| BEST PREY | 76 | 76 | 21 | 0.58 | +674 | +32.1 |
| REDIRECT WEIGHED | 21 | 21 | 21 | 0.58 | +921 | +43.9 |
| KEEPS ITS TARGET | 122 | 120 | 19 | 0.53 | +283 | +14.9 |
| BLOCKED WHEEL | 17 | 17 | 17 | 0.47 | +295 | +17.3 |
| WEARS DOWN | 103 | 100 | 16 | 0.44 | +612 | +38.2 |
| CASTING BLOCK | 22 | 22 | 15 | 0.42 | +644 | +43.0 |
| WHO HITS BACK | 15 | 15 | 15 | 0.42 | +1202 | +80.1 |
| WHOLE FIGHT GAIN | 35 | 34 | 15 | 0.42 | +587 | +39.1 |
| BIG CHARACTER SAFETY | 14 | 14 | 14 | 0.39 | -32 | -2.3 |
| CASTS FROM BEHIND | 14 | 14 | 14 | 0.39 | +0 | +0.0 |
| CHAFF PASSED | 14 | 14 | 14 | 0.39 | -24 | -1.7 |
| PIVOT GUARDS FLANK | 14 | 14 | 14 | 0.39 | -327 | -23.4 |
| CAST JOB | 26 | 26 | 13 | 0.36 | +334 | +25.7 |
| CHARGE BAND | 13 | 13 | 13 | 0.36 | +0 | +0.0 |
| FRIENDS SHOTS CHECKED | 13 | 13 | 13 | 0.36 | +643 | +49.4 |
| STUCK PIVOT | 13 | 13 | 13 | 0.36 | +0 | +0.0 |
| PURSUES BIG PREY | 12 | 12 | 12 | 0.33 | -1587 | -132.2 |
| MANOEUVRE | 11 | 11 | 11 | 0.31 | +273 | +24.9 |
| MODEL FACING | 10 | 10 | 10 | 0.28 | +3052 | +305.2 |
| MAKE SURE TOGETHER | 31 | 22 | 9 | 0.25 | +371 | +41.3 |
| OPENS UP | 11 | 11 | 8 | 0.22 | +144 | +18.1 |
| SHORT GUN FORWARD | 8 | 8 | 8 | 0.22 | +0 | +0.0 |
| WAR ENGINE JOBS | 34 | 34 | 8 | 0.22 | -543 | -67.9 |
| WHOLE FIGHT | 23 | 22 | 8 | 0.22 | +613 | +76.6 |
| HUNT IN PAIRS | 30 | 18 | 7 | 0.19 | +306 | +43.7 |
| MOVES UNITS SPELL | 7 | 7 | 7 | 0.19 | +186 | +26.5 |
| SURE CHARGE BEATS ADVANCE | 7 | 7 | 7 | 0.19 | -199 | -28.5 |
| JOINT AS ONE | 87 | 87 | 6 | 0.17 | -125 | -20.9 |
| RESTRAINS TO SHOOT | 6 | 6 | 6 | 0.17 | +231 | +38.5 |
| BEST PRIZE | 5 | 5 | 5 | 0.14 | -158 | -31.6 |
| BLOCKED CHARGE SKIPPED | 5 | 5 | 5 | 0.14 | +0 | +0.0 |
| HUNT ADVANCE | 8 | 8 | 5 | 0.14 | +116 | +23.2 |
| MISSILES NEXT TURN | 319 | 188 | 5 | 0.14 | +12 | +2.4 |
| SUPPORT NARROWED | 432 | 432 | 5 | 0.14 | -39 | -7.8 |
| SURE REACH TOGETHER | 57 | 38 | 5 | 0.14 | +10 | +2.1 |
| BACKUP TARGETS | 72 | 33 | 4 | 0.11 | +18 | +4.6 |
| CATCH ODDS | 4 | 4 | 4 | 0.11 | -88 | -21.9 |
| REFUSING RETIRES | 20 | 20 | 4 | 0.11 | -2 | -0.5 |
| SPELLS IN THE FIGHT | 37 | 36 | 4 | 0.11 | +66 | +16.4 |
| CONTINUE AHEAD WEIGHED | 3 | 3 | 3 | 0.08 | +0 | +0.0 |
| FOCUS FIRE | 3 | 3 | 3 | 0.08 | +158 | +52.5 |
| KEEP FALLS | 3 | 3 | 3 | 0.08 | +38 | +12.7 |
| OVERRUNS AWAY | 29 | 29 | 3 | 0.08 | +20 | +6.6 |
| RAIDS THE BAGGAGE NEXT TURN | 4 | 4 | 3 | 0.08 | +146 | +48.7 |
| STANDS TO CAST | 3 | 3 | 3 | 0.08 | -130 | -43.4 |
| WIDER SPREAD | 198 | 189 | 3 | 0.08 | +41 | +13.8 |
| CARRIES OUT CLOSE-IN | 16 | 16 | 2 | 0.06 | -355 | -177.7 |
| EDGE GIVE GROUND | 12 | 12 | 2 | 0.06 | +42 | +20.9 |
| ELIXIR WORTH | 2 | 2 | 2 | 0.06 | +76 | +38.0 |
| JOINT CHARGE PLAN | 10 | 10 | 2 | 0.06 | +40 | +20.1 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| LONG SHOT | 45 | 45 | 2 | 0.06 | +4 | +1.9 |
| LOST CHARGE | 213 | 212 | 2 | 0.06 | +41 | +20.5 |
| OPENS A LANE | 9 | 6 | 2 | 0.06 | +5 | +2.5 |
| REDIRECT BY WHAT IT STOPS | 30 | 30 | 2 | 0.06 | +148 | +73.8 |
| TWO OR MORE ARRIVE | 18 | 18 | 2 | 0.06 | +25 | +12.5 |
| BLOWS WHERE AIMED | 19 | 17 | 1 | 0.03 | +64 | +64.5 |
| CARRIES OUT COUNTER | 4 | 4 | 1 | 0.03 | -4 | -3.5 |
| CARRIES OUT SET-UP | 6 | 6 | 1 | 0.03 | -51 | -51.2 |
| CHARIOT NO STATIC JOB | 1 | 1 | 1 | 0.03 | -50 | -50.1 |
| DEFENSIVE ARMY | 7 | 7 | 1 | 0.03 | -137 | -137.2 |
| NEEDED THERE | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.03 | +99 | +99.0 |
| SAFE SURE CHARGE | 1 | 1 | 1 | 0.03 | -38 | -38.2 |
| SCREEN BY WHAT IT SAVES | 12 | 12 | 1 | 0.03 | +16 | +16.4 |
| STAY WEIGHED | 1 | 1 | 1 | 0.03 | +38 | +38.3 |
| STOPS | 1 | 1 | 1 | 0.03 | +3 | +2.9 |
| WOUNDED STAYS OUT | 1 | 1 | 1 | 0.03 | -40 | -39.8 |
| ALREADY CARRIED | 1 | not checked | - | - | - | - |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 33 | 33 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 28 | trace | - | - | - | - |
| CATCH FLIERS | 1 | not checked | - | - | - | - |
| CHARGER SLAIN LOST | 44 | 43 | 0 | 0.00 | - | - |
| CHARIOT WIZARD CAREFUL | 7 | 7 | 0 | 0.00 | - | - |
| CHEAP HELPER | 5 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 29 | not checked | - | - | - | - |
| DEFENSIVE FLOOR | 1 | 1 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 2 | 2 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 377 | not checked | - | - | - | - |
| GIVES UP | 3 | 3 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 1 | 1 | 0 | 0.00 | - | - |
| GROUND FLIERS | 2 | not checked | - | - | - | - |
| HELPER ALREADY ASKED | 2 | not checked | - | - | - | - |
| HELPER UNSEEN | 23 | 22 | 0 | 0.00 | - | - |
| HILL BY ITS CHANCE | 3 | 3 | 0 | 0.00 | - | - |
| HUNT DROPPED | 3 | trace | - | - | - | - |
| HUNT KEPT | 3 | trace | - | - | - | - |
| HUNT RESULT | 6 | trace | - | - | - | - |
| HUNT THE GUNS | 7 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 8 | 6 | 0 | 0.00 | - | - |
| KEEPS ITS PREY | 3 | 3 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 30 | not checked | - | - | - | - |
| LONE WIZARD HOLDS BACK | 9 | 9 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 1 | 1 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 5 | trace | - | - | - | - |
| MARCH OVER CASTS | 26 | 26 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 10 | 10 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 6 | 3 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 13 | trace | - | - | - | - |
| MOVE SPELL SPOT | 13 | not checked | - | - | - | - |
| NO CHARGE WHY | 210 | not checked | - | - | - | - |
| NOT NEEDED | 17 | 17 | 0 | 0.00 | - | - |
| NOT TURNED | 407 | 407 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 42 | not checked | - | - | - | - |
| PLAN RESULT | 2684 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 14 | 14 | 0 | 0.00 | - | - |
| SCOUT SPOT | 23 | 23 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 16 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 14 | not checked | - | - | - | - |
| SET-UP MISSED | 4 | trace | - | - | - | - |
| SHOOTER COUNTED ONCE | 2 | 2 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 18 | not checked | - | - | - | - |
| SPELL WORTH | 92 | not checked | - | - | - | - |
| STABLE ROLE | 742 | 740 | 0 | 0.00 | - | - |
| TURN WORTH | 15 | 14 | 0 | 0.00 | - | - |
| WAR ENGINE CHARGES | 4 | 4 | 0 | 0.00 | - | - |

### Off best figure: su-h2h-mine-e45904b-p1

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 13.61 | 13.86 | 53.5 |
| FALLBACK | gate | 0.58 | 0.75 | 51.6 |
| TURN GATE | gate | 0.61 | 0.67 | 30.8 |
| CHARGE NOW FIRST | rule | 0.33 | 0.42 | 49.9 |
| PATHS CROSS | rule | 0.19 | 0.19 | 53.0 |
| PIVOT GUARDS FLANK | rule | 0.19 | 0.19 | 23.4 |
| PURSUES BIG PREY | rule | 0.14 | 0.19 | 132.2 |
| NO REASON | gate | 0.28 | - | 11.9 |
| LONE CHARACTER SAFE SPOT | gate | 0.08 | 0.17 | 56.7 |
| SUPPORT REQUEST | gate | 0.14 | 0.11 | 68.2 |
| BIG CHARACTER SAFETY | rule | 0.14 | 0.08 | 6.8 |
| CANNON PLANNED TARGET | rule | 0.14 | 0.06 | 38.3 |
| MARCH ODDS | rule | 0.06 | 0.14 | 21.9 |
| SURE CHARGE BEATS ADVANCE | rule | 0.08 | 0.11 | 28.5 |
| WAR ENGINE JOBS | rule | 0.14 | 0.06 | 77.5 |
| AFTERMATH BAND | gate | 0.08 | 0.06 | 2.2 |
| BEST PRIZE | rule | 0.06 | 0.08 | 31.6 |
| CHAFF PASSED | rule | 0.03 | 0.11 | 4.8 |
| JOINT AS ONE | rule | 0.14 | - | 25.1 |
| CATCH ODDS | rule | - | 0.11 | 21.9 |
| SUPPORT NARROWED | rule | 0.08 | 0.03 | 9.7 |
| THROUGH LINE OF FIRE | rule | 0.06 | 0.06 | 15.2 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.03 | 0.06 | 29.9 |
| CHARGE NOW WEIGHED | rule | 0.06 | 0.03 | 38.3 |
| FIGHT ORDER BAND | gate | 0.08 | - | 2.1 |
| SAFER THAN THE JOB | rule | 0.03 | 0.06 | 5.7 |
| STANDS TO CAST | rule | - | 0.08 | 43.4 |
| STOPS SHORT OF THE FLANK | rule | 0.08 | - | 10.4 |
| BLOCKED WHEEL | rule | 0.03 | 0.03 | 5.8 |
| CARRIES OUT CLOSE-IN | rule | 0.06 | - | 177.7 |
| FACES THE THREAT | rule | 0.03 | 0.03 | 2.9 |
| REDIRECT WEIGHED | rule | 0.03 | 0.03 | 48.4 |
| REFUSING RETIRES | rule | 0.03 | 0.03 | 0.9 |
| SET-UP SPOT | rule | 0.06 | - | 36.2 |
| CARRIES OUT COUNTER | rule | - | 0.03 | 3.5 |
| CARRIES OUT SET-UP | rule | 0.03 | - | 51.2 |
| CHARIOT NO STATIC JOB | rule | 0.03 | - | 50.1 |
| DEFENSIVE ARMY | rule | - | 0.03 | 137.2 |
| FALLBACK BY WORTH | rule | - | 0.03 | 97.3 |
| LONG SHOT | rule | 0.03 | - | 0.7 |
| MOVE AND CAST | rule | - | 0.03 | 37.6 |
| SAFE SURE CHARGE | rule | 0.03 | - | 38.2 |
| WOUNDED STAYS OUT | rule | - | 0.03 | 39.8 |

### Plans: su-h2h-mine-e45904b-p1

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 11.8 | 16% | 463 | 255 | 55% |
| Mine | charge | 3.0 | 62% | 273 | 289 | 106% |
| Mine | close in | 3.5 | 33% | 151 | 102 | 67% |
| Mine | hold | 5.5 | 41% | 343 | 0 | 0% |
| Mine | join | 0.6 | 100% | 19 | 0 | 0% |
| Mine | shoot | 9.4 | 57% | 310 | 599 | 194% |
| Mine | support | 3.7 | 83% | 34 | 0 | 0% |
| Opponent | advance | 12.1 | 14% | 381 | 252 | 66% |
| Opponent | charge | 4.1 | 62% | 363 | 363 | 100% |
| Opponent | close in | 5.4 | 30% | 344 | 166 | 48% |
| Opponent | hold | 4.4 | 47% | 268 | 0 | 0% |
| Opponent | join | 1.0 | 100% | 53 | 0 | 0% |
| Opponent | shoot | 4.8 | 60% | 107 | 297 | 276% |
| Opponent | support | 5.2 | 87% | 49 | 0 | 0% |

### Packages: hunt the guns, su-h2h-mine-e45904b-p1

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.1 | 2 | 0 | 0% | 0% | 0% | - | 300 | 0 | 0% | 32 |
| Opponent | 0.1 | 5 | 1 | 0% | 0% | 0% | - | 405 | 0 | 0% | 88 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 125 |
| Dwarfen Mountain Holds | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 385 | 0 | 0% | 159 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 29 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 87 |
| High Elf Realms | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 214 | 0 | 0% | 83 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 88 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 89 |
| Tomb Kings of Khemri | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 44 |
| Vampire Counts | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 32 |
| Warriors of Chaos | 0.5 | 4 | 1 | 0% | 0% | 0% | - | 430 | 0 | 0% | 79 |
| Wood Elf Realms | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 329 | 0 | 0% | 61 |

### Battle groups: su-h2h-mine-e45904b-p1

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 8.9 | 23% | 54% | 10% | 57% | 35% | 3% | 9% | 52% | 0% |
| Mine | REDIRECT COUNTER | 2.0 | 35% | 56% | 4% | 0% | 12% | 4% | 12% | 67% | 4% |
| Opponent | COUNTER-CHARGE COVER | 6.7 | 20% | 58% | 25% | 25% | 39% | 11% | 6% | 44% | 0% |
| Opponent | REDIRECT COUNTER | 3.8 | 26% | 67% | 8% | 0% | 24% | 0% | 3% | 67% | 6% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: su-h2h-mine-e45904b-p1

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 3 | 0 (3) | 0 | 0 | 81 | 33% | 5.0 | 0 (1) | 0 (1) | 0 (1) | - | 0 (3) |
| Mine | Chaff | 37 | 13 (37) | 11 | 1 | 57 | 32% | 2.3 | 3 (16) | 22 (9) | 17 (12) | 21 (24) | 0 (13) |
| Mine | Character | 123 | 48 (123) | 48 | 0 | 30 | 21% | 2.4 | 62 (33) | 49 (57) | 20 (11) | 62 (54) | 41 (47) |
| Mine | Clean-up | 24 | 43 (24) | 12 | 32 | 38 | 42% | 3.1 | 61 (9) | 32 (11) | 0 (4) | 70 (14) | 12 (10) |
| Mine | Fast | 4 | 81 (4) | 81 | 0 | 47 | 0% | 2.2 | 67 (1) | 0 (2) | 362 (1) | 81 (4) | - |
| Mine | Fast Hammer | 41 | 46 (41) | 27 | 19 | 37 | 27% | 3.0 | 40 (18) | 62 (12) | 41 (11) | 57 (28) | 24 (13) |
| Mine | Fragile | 5 | 0 (5) | 0 | 0 | 60 | 0% | 1.6 | - | 0 (4) | 0 (1) | 0 (1) | 0 (4) |
| Mine | Hammer | 58 | 40 (58) | 25 | 14 | 49 | 14% | 2.4 | 11 (10) | 47 (38) | 36 (10) | 49 (34) | 29 (24) |
| Mine | Holder | 25 | 94 (25) | 22 | 73 | 33 | 36% | 3.6 | 113 (8) | 78 (14) | 123 (3) | 121 (11) | 74 (14) |
| Mine | Shooter | 44 | 81 (44) | 21 | 60 | 51 | 5% | 1.7 | 7 (5) | 92 (32) | 105 (7) | 121 (23) | 41 (21) |
| Mine | Support | 5 | 0 (5) | 0 | 0 | 42 | 20% | 2.8 | 0 (2) | 0 (2) | - | 0 (2) | 0 (2) |
| Mine | War machine | 56 | 48 (56) | 48 | 0 | 34 | 7% | 1.2 | 62 (13) | 38 (37) | 80 (6) | 71 (11) | 42 (45) |
| Mine | Wizard | 23 | 21 (23) | 21 | 0 | 41 | 13% | 2.7 | 28 (7) | 37 (8) | 0 (2) | 59 (2) | 20 (15) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Chaff | 66 | 81 (66) | 37 | 43 | 48 | 42% | 3.2 | 130 (28) | 35 (16) | 57 (22) | 100 (48) | 27 (18) |
| Opponent | Character | 114 | 46 (114) | 46 | 0 | 32 | 20% | 2.6 | 74 (40) | 34 (51) | 45 (5) | 60 (65) | 37 (31) |
| Opponent | Clean-up | 16 | 21 (16) | 18 | 3 | 47 | 50% | 3.1 | 13 (5) | 19 (8) | 37 (3) | 33 (8) | 12 (8) |
| Opponent | Early | 1 | 0 (1) | 0 | 0 | 0 | 0% | 6.0 | - | 0 (1) | - | - | 0 (1) |
| Opponent | Fast Hammer | 58 | 50 (58) | 28 | 22 | 53 | 33% | 2.4 | 54 (25) | 41 (19) | 53 (14) | 58 (42) | 28 (16) |
| Opponent | Fragile | 10 | 23 (10) | 23 | 0 | 55 | 30% | 1.6 | 86 (3) | 0 (3) | 0 (3) | 25 (9) | - |
| Opponent | Hammer | 65 | 44 (65) | 36 | 8 | 44 | 18% | 2.7 | 19 (16) | 51 (42) | 49 (7) | 35 (40) | 62 (25) |
| Opponent | Holder | 40 | 73 (40) | 16 | 57 | 26 | 42% | 3.4 | 25 (13) | 115 (18) | 52 (8) | 91 (21) | 54 (18) |
| Opponent | Shooter | 30 | 85 (30) | 23 | 63 | 29 | 3% | 1.3 | 72 (7) | 95 (18) | 64 (5) | 81 (16) | 92 (14) |
| Opponent | Support | 2 | 0 (2) | 0 | 0 | 0 | 100% | - | 0 (1) | 0 (1) | - | - | 0 (2) |
| Opponent | War machine | 13 | 80 (13) | 80 | 0 | 18 | 0% | 1.2 | 68 (5) | 95 (5) | 72 (3) | 101 (3) | 74 (10) |
| Opponent | Wizard | 22 | 5 (22) | 5 | 0 | 30 | 14% | 1.6 | 3 (12) | 0 (3) | 0 (3) | 0 (10) | 6 (8) |

### Charged fights: su-h2h-mine-e45904b-p1

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 5 | 127 | 144 | 2.0 | 1.0 | 72 | 14 | +58 | 3 of 10 | 8 of 10 | - | +58 |
| Mine | Chaos Dwarfs | 3 | 22 | 532 | 4.0 | 1.1 | 133 | 54 | +79 | 7 of 12 | 8 of 12 | +138 | +74 |
| Mine | Dwarfen Mountain Holds | 4 | 408 | 0 | 0.8 | 1.3 | 0 | 20 | -20 | 0 of 3 | 2 of 3 | +0 | -30 |
| Mine | Empire of Man | 5 | 231 | 205 | 2.8 | 1.1 | 73 | 33 | +41 | 4 of 14 | 8 of 14 | +0 | +47 |
| Mine | Grand Cathay | 4 | 827 | 225 | 2.0 | 1.5 | 112 | 0 | +112 | 5 of 8 | 7 of 8 | +180 | +72 |
| Mine | High Elf Realms | 4 | 126 | 466 | 5.0 | 1.1 | 93 | 35 | +58 | 11 of 20 | 11 of 20 | +216 | +40 |
| Mine | Kingdom of Bretonnia | 1 | 254 | 1212 | 5.0 | 1.2 | 242 | 0 | +242 | 1 of 5 | 5 of 5 | +877 | +84 |
| Mine | Lizardmen | 1 | 70 | 60 | 2.0 | 1.0 | 30 | 70 | -40 | 1 of 2 | 1 of 2 | - | -40 |
| Mine | Ogre Kingdoms | 1 | 70 | 0 | 2.0 | 1.0 | 0 | 45 | -45 | 2 of 2 | 0 of 2 | - | -45 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 395 | 7.0 | 1.1 | 56 | 16 | +41 | 3 of 7 | 3 of 7 | +195 | +15 |
| Mine | Skaven | 2 | 22 | 25 | 0.5 | 1.0 | 50 | 0 | +50 | 0 of 1 | 1 of 1 | - | +50 |
| Mine | Tomb Kings of Khemri | 2 | 278 | 814 | 3.5 | 1.3 | 232 | 38 | +195 | 3 of 7 | 5 of 7 | +102 | +210 |
| Mine | Vampire Counts | 2 | 0 | 276 | 4.0 | 1.1 | 69 | 6 | +64 | 3 of 8 | 4 of 8 | +53 | +65 |
| Mine | Warriors of Chaos | 1 | 0 | 107 | 2.0 | 1.0 | 54 | 15 | +38 | 0 of 2 | 1 of 2 | - | +38 |
| **Mine** | all armies | 36 | 230 | 281 | 2.8 | 1.1 | 100 | 27 | +73 | 43 of 101 | 64 of 101 | +180 | +58 |
| Opponent | Beastmen Brayherds | 1 | 0 | 952 | 6.0 | 1.3 | 159 | 135 | +24 | 3 of 6 | 4 of 6 | +15 | +26 |
| Opponent | Dwarfen Mountain Holds | 1 | 375 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Empire of Man | 1 | 399 | 0 | 2.0 | 1.0 | 0 | 0 | +0 | 2 of 2 | 1 of 2 | - | +0 |
| Opponent | Grand Cathay | 1 | 706 | 185 | 2.0 | 1.0 | 92 | 0 | +92 | 2 of 2 | 1 of 2 | - | +92 |
| Opponent | High Elf Realms | 2 | 104 | 360 | 3.0 | 1.0 | 120 | 74 | +46 | 4 of 6 | 5 of 6 | - | +46 |
| Opponent | Lizardmen | 1 | 0 | 378 | 2.0 | 1.0 | 189 | 0 | +189 | 2 of 2 | 2 of 2 | - | +189 |
| Opponent | Ogre Kingdoms | 2 | 26 | 154 | 3.0 | 1.2 | 52 | 0 | +52 | 3 of 6 | 5 of 6 | +130 | +36 |
| Opponent | Orc & Goblin Tribes | 2 | 35 | 966 | 4.5 | 1.1 | 215 | 18 | +196 | 2 of 9 | 8 of 9 | -55 | +228 |
| Opponent | Skaven | 2 | 56 | 0 | 2.0 | 1.0 | 0 | 118 | -118 | 2 of 4 | 1 of 4 | - | -118 |
| Opponent | Tomb Kings of Khemri | 4 | 73 | 998 | 4.8 | 1.2 | 210 | 56 | +154 | 9 of 19 | 12 of 19 | +194 | +143 |
| Opponent | Vampire Counts | 6 | 0 | 456 | 4.5 | 1.1 | 101 | 31 | +71 | 12 of 27 | 23 of 26 | +167 | +54 |
| Opponent | Warriors of Chaos | 7 | 0 | 363 | 2.9 | 1.0 | 127 | 22 | +105 | 9 of 20 | 16 of 20 | - | +105 |
| Opponent | Wood Elf Realms | 6 | 26 | 543 | 2.8 | 1.1 | 192 | 19 | +172 | 5 of 17 | 14 of 17 | +476 | +132 |
| **Opponent** | all armies | 36 | 66 | 472 | 3.3 | 1.1 | 142 | 38 | +104 | 55 of 120 | 92 of 119 | +191 | +93 |

### Effective charges: su-h2h-mine-e45904b-p1

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 10 | 0 | 0 | 0 | 2 (net -42) | 0 | 3 (net +186) | 5 | 0% (0 of 5) |
| Mine | Chaos Dwarfs | 12 | 4 (net +2) | 0 | 0 | 2 (net +237) | 0 | 5 (net +93) | 1 | 0% (0 of 11) |
| Mine | Dwarfen Mountain Holds | 3 | 0 | 0 | 0 | 2 (net -30) | 0 | 1 (net +0) | 0 | 0% (0 of 3) |
| Mine | Empire of Man | 14 | 4 (net -48) | 0 | 2 (net +49) | 2 (net +42) | 1 (net +0) | 5 (net +116) | 0 | 14% (2 of 14) |
| Mine | Grand Cathay | 8 | 0 | 0 | 3 (net +106) | 1 (net +540) | 2 (net +20) | 2 (net +0) | 0 | 38% (3 of 8) |
| Mine | High Elf Realms | 20 | 3 (net -95) | 2 (net +246) | 8 (net +51) | 0 | 2 (net +216) | 4 (net -4) | 1 | 42% (8 of 19) |
| Mine | Kingdom of Bretonnia | 5 | 0 | 0 | 2 (net +461) | 1 (net +147) | 1 (net +68) | 1 (net +75) | 0 | 40% (2 of 5) |
| Mine | Lizardmen | 2 | 0 | 0 | 0 | 1 (net +60) | 0 | 0 | 1 | 0% (0 of 1) |
| Mine | Orc & Goblin Tribes | 7 | 0 | 0 | 1 (net +195) | 0 | 0 | 0 | 6 | 100% (1 of 1) |
| Mine | Skaven | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +50) | 0 | 0% (0 of 1) |
| Mine | Tomb Kings of Khemri | 7 | 0 | 2 (net +214) | 0 | 3 (net +217) | 0 | 2 (net +142) | 0 | 0% (0 of 7) |
| Mine | Vampire Counts | 8 | 1 (net +0) | 3 (net +57) | 0 | 1 (net +53) | 0 | 2 (net +142) | 1 | 0% (0 of 7) |
| Mine | Warriors of Chaos | 2 | 1 (net -30) | 0 | 0 | 0 | 0 | 1 (net +107) | 0 | 0% (0 of 2) |
| Opponent | Beastmen Brayherds | 6 | 2 (net -52) | 0 | 2 (net +65) | 0 | 0 | 1 (net +15) | 1 | 40% (2 of 5) |
| Opponent | Empire of Man | 2 | 0 | 0 | 1 (net +0) | 1 (net +0) | 0 | 0 | 0 | 50% (1 of 2) |
| Opponent | Grand Cathay | 2 | 1 (net +185) | 0 | 0 | 1 (net +0) | 0 | 0 | 0 | 0% (0 of 2) |
| Opponent | High Elf Realms | 6 | 1 (net +0) | 0 | 2 (net -158) | 0 | 0 | 2 (net +184) | 1 | 40% (2 of 5) |
| Opponent | Lizardmen | 2 | 0 | 0 | 0 | 0 | 0 | 2 (net +189) | 0 | 0% (0 of 2) |
| Opponent | Ogre Kingdoms | 6 | 0 | 0 | 2 (net +107) | 0 | 0 | 2 (net +32) | 2 | 50% (2 of 4) |
| Opponent | Orc & Goblin Tribes | 9 | 0 | 0 | 2 (net +173) | 0 | 0 | 0 | 7 | 100% (2 of 2) |
| Opponent | Skaven | 4 | 3 (net +0) | 0 | 1 (net -474) | 0 | 0 | 0 | 0 | 25% (1 of 4) |
| Opponent | Tomb Kings of Khemri | 19 | 2 (net +20) | 1 (net +0) | 4 (net +216) | 6 (net +169) | 1 (net +404) | 4 (net +105) | 1 | 22% (4 of 18) |
| Opponent | Vampire Counts | 27 | 3 (net -114) | 2 (net +0) | 10 (net +80) | 6 (net +112) | 0 | 5 (net +156) | 1 | 38% (10 of 26) |
| Opponent | Warriors of Chaos | 20 | 1 (net +509) | 1 (net +55) | 1 (net +250) | 9 (net +51) | 0 | 5 (net +126) | 3 | 6% (1 of 17) |
| Opponent | Wood Elf Realms | 17 | 1 (net +772) | 1 (net -200) | 4 (net +56) | 4 (net +176) | 1 (net +254) | 4 (net +276) | 2 | 27% (4 of 15) |

### Charged fights, damage counted: su-h2h-mine-e45904b-p1

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 13 | 257 | 242 | -38 | 80 | 109 | -28 | -11.1 |
| Mine | 50-54% | 7 | 357 | 277 | +156 | 245 | 38 | +207 | +58.0 |
| Mine | Effective (55-75%) | 16 | 308 | 188 | +121 | 135 | 39 | +96 | +31.1 |
| Mine | 76-89% | 15 | 284 | 140 | +124 | 152 | 20 | +132 | +46.5 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 27 | 263 | 181 | +88 | 131 | 39 | +92 | +35.0 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 6 | 466 | 132 | +90 | 120 | 18 | +102 | +21.8 |
| Mine | No odds | 17 | 268 | 169 | +6 | 54 | 53 | +1 | +0.4 |
| Mine | All fights | 101 | 292 | 185 | +73 | 123 | 46 | +76 | +26.2 |
| Opponent | Long shot (under 50%) | 14 | 148 | 258 | +76 | 150 | 98 | +51 | +34.7 |
| Opponent | 50-54% | 5 | 306 | 263 | -29 | 107 | 104 | +3 | +1.1 |
| Opponent | Effective (55-75%) | 29 | 235 | 174 | +70 | 143 | 77 | +66 | +27.8 |
| Opponent | 76-89% | 27 | 214 | 183 | +106 | 159 | 39 | +120 | +56.3 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 25 | 337 | 193 | +150 | 192 | 37 | +156 | +46.2 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 2 | 562 | 110 | +329 | 329 | 0 | +329 | +58.5 |
| Opponent | No odds | 18 | 237 | 243 | +124 | 172 | 68 | +104 | +43.7 |
| Opponent | All fights | 120 | 250 | 203 | +104 | 164 | 61 | +103 | +41.0 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| su-h2h-mine-e45904b-p1 | move | 476 | 105 (22%) | 81 (17%) | 69 (14%) | 302 (63%) |
| su-h2h-mine-e45904b-p1 | objective | 325 | 63 (19%) | 47 (14%) | 44 (14%) | 218 (67%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0102, L0118, L0135, L2531, L2730 |
| Charmed Shield | Opponent | L0524, L1224, L1527, L1625, L2025, L2127, L2934 |
| Clockwork Compass | Mine | L1224 |
| Clockwork Compass | Opponent | L0612 |
| Elixir of Power | Mine | L1114, L1131, L1923 |
| Elixir of Power | Opponent | L0319, L1319 |
| Fistful of Laurels | Mine | L1823 |
| Fistful of Laurels | Opponent | L0118, L0218 |
| Horn of the Wild Hunt | Opponent | L0733 |
| Invocation of Nehek | Mine | L2531, L2730 |
| Invocation of Nehek | Opponent | L0524, L1224, L1527, L1625, L2025, L2127 |
| Opal Amulet | Mine | L1431 |
| Opal Amulet | Opponent | L1114 |
| Periapt of Soul Exchange | Mine | L2025, L2127 |
| Periapt of Soul Exchange | Opponent | L0421, L1021 |
| Ring of Doom | Mine | L0218, L0235, L1114, L1131, L1224, L1527 |
| Ring of Doom | Opponent | L0102, L0612, L0733, L1131, L1431, L2231, L2531 |
| Ring of Jet | Mine | L1021, L1114, L1131, L1224 |
| Ring of Jet | Opponent | L0612 |
| Standard of the Fell Warrior | Mine | L1319, L1335 |
| Standard of the Fell Warrior | Opponent | L0913 |
| Storm Daemon (Renegade 2.0) | Mine | L2127 |
| Storm Daemon (Renegade 2.0) | Opponent | L0421, L1021 |
| Twice-Blessed Armour | Mine | L0717, L0733, L1021 |
| Witch Hunter's Ward | Mine | L0717, L0733, L0823 |
| Witch Hunter's Ward | Opponent | L0508 |

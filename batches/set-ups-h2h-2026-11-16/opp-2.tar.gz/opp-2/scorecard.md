# Doctrine scorecard: su-h2h-opp-e45904b-p2

### Scorecard: su-h2h-opp-e45904b-p2

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0106 | 4 | 1 | Mine | no | 1 | 4 | 2 | 2 | 0 | 0 | 0 | 65 |
| L0106 | 4 | 1 | Opponent | no | 0 | 4 | 1 | 3 | 0 | 0 | 0 | 615 |
| L0122 | 2 | 1 | Mine | - | - | - | 0 | 2 | 0 | 0 | 0 | 322 |
| L0122 | 2 | 1 | Opponent | - | - | 2 | 3 | 0 | 0 | 0 | 0 | 0 |
| L0206 | 2 | 1 | Mine | - | - | 6 | 1 | 4 | 0 | 0 | 0 | 0 |
| L0206 | 2 | 1 | Opponent | - | - | 3 | 2 | 1 | 0 | 0 | 0 | 615 |
| L0222 | 6 | 1 | Mine | no | 2 | 2 | 5 | 2 | 0 | 0 | 0 | 281 |
| L0222 | 6 | 1 | Opponent | no | 11 | 2 | 1 | 1 | 0 | 0 | 0 | 55 |
| L0307 | 1 | 1 | Mine | yes | 0 | - | 4 | 0 | 0 | 0 | 0 | 760 |
| L0307 | 1 | 1 | Opponent | yes | 0 | 3 | 1 | 0 | 1 | 0 | 0 | 375 |
| L0323 | 5 | 1 | Mine | no | - | 2 | 1 | 1 | 0 | 0 | 0 | 590 |
| L0323 | 5 | 1 | Opponent | yes | - | 2 | 3 | 0 | 1 | 0 | 0 | 0 |
| L0409 | 1 | 1 | Mine | no | 2 | 2 | 3 | 3 | 0 | 0 | 0 | 0 |
| L0409 | 1 | 1 | Opponent | no | 7 | 5 | 0 | 1 | 0 | 0 | 0 | 420 |
| L0425 | 5 | 1 | Mine | yes | - | 2 | 2 | 4 | 0 | 0 | 0 | 0 |
| L0425 | 5 | 1 | Opponent | yes | - | - | 2 | 3 | 0 | 0 | 0 | 0 |
| L0512 | 2 | 1 | Mine | - | - | - | 1 | 2 | 0 | 0 | 0 | 475 |
| L0512 | 2 | 1 | Opponent | - | - | 2 | 1 | 0 | 2 | 0 | 0 | 330 |
| L0528 | 6 | 1 | Mine | no | 0 | - | 1 | 2 | 0 | 0 | 0 | 475 |
| L0528 | 6 | 1 | Opponent | no | 5 | - | 1 | 1 | 0 | 0 | 0 | 0 |
| L0616 | 4 | 1 | Mine | no | 0 | 6 | 3 | 0 | 1 | 0 | 0 | 615 |
| L0616 | 4 | 1 | Opponent | no | 2 | 2 | 3 | 0 | 1 | 0 | 0 | 200 |
| L0632 | 2 | 1 | Mine | - | - | 2 | 1 | 0 | 0 | 0 | 0 | 993 |
| L0632 | 2 | 1 | Opponent | - | - | 2 | 1 | 4 | 1 | 0 | 0 | 170 |
| L0721 | 1 | 1 | Mine | yes | 0 | 2 | 4 | 0 | 0 | 0 | 0 | 420 |
| L0721 | 1 | 1 | Opponent | no | 0 | - | 0 | 5 | 2 | 0 | 0 | 355 |
| L0810 | 6 | 1 | Mine | no | 5 | 4 | 1 | 2 | 0 | 0 | 0 | 605 |
| L0810 | 6 | 1 | Opponent | no | 8 | 2 | 2 | 0 | 1 | 0 | 0 | 501 |
| L0827 | 5 | 1 | Mine | no | - | 6 | 1 | 1 | 0 | 0 | 0 | 1012 |
| L0827 | 5 | 1 | Opponent | yes | - | 3 | 5 | 6 | 0 | 0 | 0 | 0 |
| L0918 | 6 | 1 | Mine | no | 3 | 3 | 2 | 1 | 0 | 0 | 0 | 726 |
| L0918 | 6 | 1 | Opponent | no | 13 | 2 | 3 | 2 | 0 | 0 | 0 | 419 |
| L0934 | 4 | 1 | Mine | no | 1 | 1 | 1 | 1 | 0 | 0 | 0 | 736 |
| L0934 | 4 | 1 | Opponent | no | 0 | 2 | 7 | 2 | 0 | 0 | 0 | 160 |
| L1026 | 6 | 1 | Mine | no | 3 | 2 | 2 | 1 | 0 | 0 | 0 | 330 |
| L1026 | 6 | 1 | Opponent | no | 7 | 3 | 1 | 3 | 0 | 0 | 0 | 0 |
| L1118 | 2 | 1 | Mine | - | - | 2 | 5 | 1 | 0 | 0 | 0 | 330 |
| L1118 | 2 | 1 | Opponent | - | - | 4 | 4 | 2 | 0 | 0 | 0 | 370 |
| L1135 | 1 | 1 | Mine | yes | 0 | 2 | 2 | 0 | 0 | 0 | 0 | 330 |
| L1135 | 1 | 1 | Opponent | yes | 1 | 2 | 7 | 0 | 0 | 0 | 0 | 0 |
| L1228 | 4 | 1 | Mine | no | 4 | 6 | 1 | 0 | 0 | 0 | 0 | 524 |
| L1228 | 4 | 1 | Opponent | no | 2 | - | 0 | 2 | 0 | 0 | 0 | 111 |
| L1323 | 3 | 1 | Mine | yes | 4 | 2 | 3 | 0 | 1 | 0 | 0 | 140 |
| L1323 | 3 | 1 | Opponent | no | 7 | 1 | 4 | 1 | 1 | 0 | 0 | 0 |
| L1418 | 2 | 1 | Mine | - | - | 2 | 5 | 1 | 0 | 0 | 0 | 0 |
| L1418 | 2 | 1 | Opponent | - | - | - | 3 | 0 | 0 | 0 | 0 | 234 |
| L1435 | 1 | 1 | Mine | no | 0 | 3 | 3 | 1 | 0 | 0 | 0 | 0 |
| L1435 | 1 | 1 | Opponent | no | 0 | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L1531 | 1 | 1 | Mine | no | 0 | - | 3 | 1 | 0 | 0 | 0 | 0 |
| L1531 | 1 | 1 | Opponent | yes | 0 | 3 | 3 | 1 | 0 | 0 | 0 | 340 |
| L1629 | 3 | 1 | Mine | no | 4 | 1 | 2 | 2 | 0 | 0 | 0 | 616 |
| L1629 | 3 | 1 | Opponent | no | 0 | 2 | 2 | 2 | 0 | 0 | 0 | 170 |
| L1727 | 5 | 1 | Mine | yes | - | 4 | 4 | 0 | 0 | 0 | 0 | 49 |
| L1727 | 5 | 1 | Opponent | yes | - | 2 | 2 | 4 | 0 | 0 | 0 | 0 |
| L1827 | 3 | 1 | Mine | no | 1 | 4 | 1 | 2 | 0 | 0 | 0 | 716 |
| L1827 | 3 | 1 | Opponent | no | 10 | 2 | 4 | 2 | 0 | 0 | 0 | 0 |
| L1927 | 1 | 1 | Mine | no | 3 | 1 | 3 | 1 | 0 | 0 | 0 | 0 |
| L1927 | 1 | 1 | Opponent | no | 0 | 2 | 1 | 4 | 0 | 0 | 0 | 190 |
| L2029 | 1 | 1 | Mine | no | 0 | - | 1 | 0 | 0 | 0 | 0 | 617 |
| L2029 | 1 | 1 | Opponent | no | 1 | 2 | 4 | 0 | 0 | 0 | 0 | 0 |
| L2131 | 1 | 1 | Mine | yes | 7 | - | 2 | 2 | 0 | 0 | 0 | 355 |
| L2131 | 1 | 1 | Opponent | no | 0 | 2 | 1 | 1 | 1 | 0 | 0 | 170 |
| L2235 | 3 | 1 | Mine | no | 4 | 1 | 4 | 0 | 0 | 0 | 0 | 0 |
| L2235 | 3 | 1 | Opponent | no | 0 | 3 | 6 | 1 | 1 | 0 | 0 | 0 |
| L2429 | 5 | 1 | Mine | yes | - | 3 | 1 | 2 | 1 | 0 | 0 | 0 |
| L2429 | 5 | 1 | Opponent | yes | - | 3 | 3 | 3 | 0 | 0 | 0 | 0 |
| L2535 | 3 | 1 | Mine | no | 8 | 4 | 2 | 1 | 0 | 0 | 0 | 0 |
| L2535 | 3 | 1 | Opponent | no | 3 | 1 | 1 | 1 | 0 | 0 | 0 | 0 |
| L2735 | 5 | 1 | Mine | yes | - | 3 | 2 | 2 | 0 | 0 | 0 | 0 |
| L2735 | 5 | 1 | Opponent | yes | - | 3 | 5 | 2 | 0 | 0 | 0 | 0 |
| L3033 | 3 | 1 | Mine | yes | 5 | 5 | 0 | 0 | 1 | 0 | 0 | 0 |
| L3033 | 3 | 1 | Opponent | no | 0 | 1 | 9 | 2 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 33% | 2.4 | 3.0 | 2.2 | 1.2 | 0.1 | 0.0 | 0.0 | 335.6 |
| **Average** | | | Opponent | 30% | 3.2 | 2.4 | 2.8 | 1.7 | 0.3 | 0.0 | 0.0 | 161.1 |

### KPIs: su-h2h-opp-e45904b-p2

Rules off - Mine only: SET-UP SPOT, CARRIES OUT CLOSE-IN, JOINT AS ONE.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 23% (41 of 176) | 12% (22 of 190) | 17% (63 of 366) |
| Winner chose to follow up after the loser gave ground |  | 100% (63 of 63); on the table 100% | 96% (50 of 52); on the table 96% | 98% (113 of 115); on the table 98% |
| Winner chose to pursue after the loser fell back in good order |  | 79% (11 of 14); on the table 79% | 100% (9 of 9); on the table 100% | 87% (20 of 23); on the table 87% |
| Winner chose to pursue after the loser fled |  | 64% (21 of 33); on the table 67% | 60% (25 of 42); on the table 67% | 61% (46 of 75); on the table 67% |
| Winner chose to follow up or pursue (all three) |  | 86% (95 of 110); on the table 87% | 82% (84 of 103); on the table 84% | 84% (179 of 213); on the table 86% |
| Magic missiles tried each own turn | 50%+ | 36% (123 of 342) | 38% (59 of 156) | 37% (182 of 498) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 51% (111 of 217) | 48% (59 of 123) | 50% (170 of 340) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 60% (18 of 30) | 47% (28 of 59) | 52% (46 of 89) |
| Points that never fought | lower | 35% (25333 of 71583) | 42% (30113 of 71989) | 39% (55446 of 143572) |
|   infantry points that never fought | lower | 38% (6134 of 16324) | 60% (8439 of 14029) | 48% (14573 of 30353) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 60% (170 of 284) | 53% (157 of 297) | 56% (327 of 581) |
| Bound items with a magic missile used (at least once a game) |  | 90% (18 of 20); 1.4 uses a game | 72% (13 of 18); 1.3 uses a game | 82% (31 of 38); 1.3 uses a game |
| Bound items with another spell used |  | 56% (10 of 18); 0.6 uses a game | 0% (0 of 2); 0.0 uses a game | 50% (10 of 20); 0.3 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 45% (9 of 20); 0.2 uses a game | 29% (2 of 7); 0.1 uses a game | 41% (11 of 27); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 56% (33659 of 60231) | 49% (31287 of 63281) | 53% (64946 of 123512) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.5 (24%) | 0.9 (33%) | 2.4 (27%) |
| MARCHED: its unit marched | 1.1 (18%) | 0.5 (20%) | 1.6 (19%) |
| CHARGED: its unit charged | 0.1 (1%) | 0.0 (1%) | 0.1 (1%) |
| IN COMBAT: engaged in combat | 1.6 (26%) | 0.4 (14%) | 2.0 (22%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.1 (5%) | 0.2 (2%) |
| FLEEING: fleeing | 0.2 (4%) | 0.1 (4%) | 0.4 (4%) |
| GONE: slain | 1.3 (21%) | 0.4 (15%) | 1.7 (19%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| STUPIDITY: Stupidity | 0.1 (2%) | 0.0 (0%) | 0.1 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| NOT OFFERED: not in the cast list | 0.1 (1%) | 0.2 (7%) | 0.3 (3%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 3.9 | 1.4 | 1.1 | 5.1 | 0.6 | 1.8 |
| not cast | 4.0 | 3.5 | 3.9 | 8.8 | 1.8 | 19.9 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) | 1.0 (5%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (1%) | 1.4 (41%) | 0.1 (3%) | 2.4 (27%) | 0.4 (22%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.6 (19%) | 0.4 (21%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.1 (1%) | 0.2 (6%) | 0.6 (15%) | 2.0 (22%) | 0.2 (10%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.3 (7%) | 0.3 (10%) | 0.3 (7%) | 0.2 (2%) | 0.0 (0%) | 0.0 (0%) |
| NO CASTS LEFT: every cast used on other spells | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (6%) | 0.0 (0%) |
| FLEEING: fleeing | 0.2 (6%) | 0.2 (7%) | 0.1 (3%) | 0.4 (4%) | 0.1 (3%) | 0.5 (3%) |
| GONE: slain | 0.9 (22%) | 0.6 (16%) | 0.9 (22%) | 1.7 (19%) | 0.3 (19%) | 3.1 (16%) |
| OFF THE TABLE: off the table or not arrived | 0.3 (7%) | 0.3 (8%) | 0.3 (7%) | 0.0 (0%) | 0.1 (5%) | 0.8 (4%) |
| STUPIDITY: Stupidity | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) | 0.1 (1%) | 0.0 (0%) | 0.3 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (1%) | 0.2 (6%) | 0.0 (1%) | 0.1 (1%) | 0.2 (14%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (3%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.1 (54%) | 0.2 (6%) | 1.6 (40%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 14.2 (72%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.5 a game | 0.6 a game | 0.6 a game |
| stood (cast and not dispelled) | 62% (10 of 16) | 65% (15 of 23) | 64% (25 of 39) |
| the unit moved after it | 80% (8 of 10) | 67% (10 of 15) | 72% (18 of 25) |
| it charged on its next turn | 0% (0 of 10) | 13% (2 of 15) | 8% (2 of 25) |
| the enemy charged it first | 30% (3 of 10) | 7% (1 of 15) | 16% (4 of 25) |
| it fought by the end of its next turn | 10% (1 of 10) | 0% (0 of 15) | 4% (1 of 25) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 10) | 7% (1 of 15) | 4% (1 of 25) |
| none of these (no charge, no fight, no charge escaped) | 70% (7 of 10) | 73% (11 of 15) | 72% (18 of 25) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 65% (547 of 845) | 55% (446 of 805) | 60% (993 of 1650) |
|   cavalry | 59% (48 of 82) | 62% (98 of 159) | 61% (146 of 241) |
|   character | 39% (35 of 89) | 28% (31 of 110) | 33% (66 of 199) |
|   chariot | 57% (59 of 104) | 64% (29 of 45) | 59% (88 of 149) |
|   infantry | 60% (152 of 252) | 57% (182 of 321) | 58% (334 of 573) |
|   monster | 49% (19 of 39) | 51% (22 of 43) | 50% (41 of 82) |
|   war machine | 84% (234 of 279) | 66% (84 of 127) | 78% (318 of 406) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.4 (30%) | 2.4 (24%) | 4.9 (27%) |
| CHARGED: it charged | 0.9 (11%) | 2.1 (21%) | 3.0 (16%) |
| FLEEING: it fled or was fleeing | 0.2 (2%) | 0.2 (2%) | 0.3 (2%) |
| IN COMBAT: it fought this turn or the last | 0.9 (11%) | 0.6 (6%) | 1.5 (8%) |
| MOVED: a war machine that moved | 0.1 (1%) | 0.0 (0%) | 0.1 (0%) |
| HELD FIRE: a target, but it held its fire | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NO TARGET IN RANGE | 1.1 (14%) | 1.7 (17%) | 2.8 (15%) |
| ONLY IN COMBAT: the only targets were in combat | 0.4 (5%) | 0.5 (5%) | 0.9 (5%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.6 (20%) | 1.7 (17%) | 3.4 (18%) |
| SHELTERED: the target was sheltered | 0.3 (3%) | 0.2 (2%) | 0.5 (3%) |
| STUPIDITY | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR | 0.2 (3%) | 0.6 (6%) | 0.8 (5%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 6.4 | 1.5 | 82% | 4.7 pts | 30 pts |
| character | 2.0 | 0.7 | 75% | 9.2 pts | 18 pts |
| chariot | 2.4 | 1.8 | 64% | 11.5 pts | 28 pts |
| infantry | 12.5 | 4.8 | 73% | 8.5 pts | 106 pts |
| monster | 1.4 | 0.5 | 74% | 8.5 pts | 12 pts |
| war machine | 8.8 | 7.2 | 61% | 30.4 pts | 269 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.7 | 5.6 | 4.7 |
| Charges that made contact a game | 3.1 | 4.2 | 3.6 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.73 declared, 0.69 contact (26 units) | 0.69 declared, 0.62 contact (13 units) | 0.72 declared, 0.67 contact (39 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.25 declared, 0.25 contact (8 units) | 0.91 declared, 0.82 contact (11 units) | 0.63 declared, 0.58 contact (19 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.46 declared, 0.36 contact (247 units) | 0.64 declared, 0.47 contact (287 units) | 0.56 declared, 0.42 contact (534 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 48% (35 of 73) | 44% (8 of 18) | 50% (6 of 12) | 48% (49 of 103) |
| Character in a unit | 74% (26 of 35) | 65% (11 of 17) | 75% (3 of 4) | 71% (40 of 56) |
| Character on its own | 81% (30 of 37) | 65% (24 of 37) | 34% (21 of 62) | 55% (75 of 136) |
| Chariot | 82% (14 of 17) | 69% (9 of 13) | - | 77% (23 of 30) |
| Infantry | 50% (47 of 94) | 44% (15 of 34) | 33% (1 of 3) | 48% (63 of 131) |
| Monster | 52% (15 of 29) | 67% (6 of 9) | - | 55% (21 of 38) |
| Monstrous | 36% (5 of 14) | 50% (7 of 14) | - | 43% (12 of 28) |
| War Machines | 74% (42 of 57) | 100% (2 of 2) | - | 75% (44 of 59) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 94% (15 of 16); on the table 94% | 31% (32 of 102) | 25% | 50% (11 of 22) | 100% (6 of 6); 3.2 uses a game | 50% (1 of 2); 0.2 uses a game | 67% (4 of 6); 1.0 uses a game |
| Chaos Dwarfs | 4 | 87% (13 of 15); on the table 87% | 42% (15 of 36) | 54% | 69% (22 of 32) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |
| Dwarfen Mountain Holds | 6 | 100% (11 of 11); on the table 100% | - | 52% | 65% (35 of 54) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 7 | 75% (9 of 12); on the table 75% | 31% (15 of 48) | 49% | 61% (46 of 76) | 0.0 uses a game | 50% (1 of 2); 0.3 uses a game | 50% (2 of 4); 0.3 uses a game |
| Grand Cathay | 6 | 100% (15 of 15); on the table 100% | 37% (51 of 138) | 49% | 61% (33 of 54) | 86% (12 of 14); 6.3 uses a game | 0% (0 of 2); 0.0 uses a game | 0% (0 of 6); 0.0 uses a game |
| High Elf Realms | 4 | 76% (13 of 17); on the table 76% | 6% (1 of 18) | 24% | 33% (11 of 33) | 100% (3 of 3); 2.2 uses a game | 57% (8 of 14); 4.2 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 2 | 100% (7 of 7); on the table 100% | - | 43% | 50% (6 of 12) | 0.0 uses a game | 0.0 uses a game | 100% (2 of 2); 1.0 uses a game |
| Lizardmen | 1 | 100% (1 of 1); on the table 100% | - | 17% | 57% (4 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 4 | 78% (7 of 9); on the table 78% | 0% (0 of 18) | 41% | 82% (23 of 28) | 100% (4 of 4); 3.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 1 | - | 58% (7 of 12) | 6% | 12% (1 of 8) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Skaven | 3 | 56% (5 of 9); on the table 56% | 33% (6 of 18) | 41% | 56% (14 of 25) | 50% (1 of 2); 1.3 uses a game | 0.0 uses a game | 67% (2 of 3); 0.7 uses a game |
| Tomb Kings of Khemri | 5 | 56% (5 of 9); on the table 56% | - | 30% | 24% (6 of 25) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 9 | 78% (29 of 37); on the table 84% | 50% (33 of 66) | 40% | 70% (38 of 54) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 9 | 91% (21 of 23); on the table 96% | 56% (10 of 18) | 34% | 51% (37 of 73) | 100% (2 of 2); 1.0 uses a game | 0.0 uses a game | 100% (1 of 1); 0.1 uses a game |
| Wood Elf Realms | 7 | 88% (28 of 32); on the table 91% | 50% (12 of 24) | 30% | 51% (40 of 78) | 43% (3 of 7); 1.7 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (su-h2h-opp-e45904b-p2, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 51% (44) | 37% (22) | 45% (66) |
| ...free all their last turn and able to turn (per game) | 0.83 | 0.33 | 1.17 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.11 | 0.14 | 0.25 |
| ...with the charger already in that arc before they moved (per game) | 0.64 | 0.19 | 0.83 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 1.81 | 1.50 | 3.31 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 1.28 | 1.25 | 2.53 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 6.67 | 5.53 | 12.19 |

### Quality by phase: su-h2h-opp-e45904b-p2

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.8 | 3.3 |
| Strategy | Charge objectives carried out (made contact) | 57% (61 of 107) | 45% (92 of 205) |
| Strategy | Shoot objectives carried out (shot that target) | 39% (144 of 365) | 53% (124 of 232) |
| Strategy | Close-in objectives charged next turn | 13% (17 of 128) | 23% (44 of 193) |
| Strategy | Support requests answered (helper made contact too) | 42% (5 of 12) | 38% (13 of 34) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (3 of 3) | 100% (3 of 3) |
| Strategy | Hexes on a unit its side charged or shot that turn | 62% (8 of 13) | 60% (6 of 10) |
| Strategy | Joined characters whose unit fought | 61% (27 of 44) | 36% (16 of 45) |
| Strategy | Lone characters that fought | 71% (72 of 101) | 76% (59 of 78) |
| Movement | Charges halted short of contact | 0.2 | 0.3 |
| Movement | Idle units | 1.2 | 1.7 |
| Movement | Points that never moved of their own | 335.6 | 161.1 |
| Movement | Fights charged into per game | 2.7 | 3.4 |
| Movement | Charges with odds: long shots (under 50%) | 12 of 87, net +8 | 25 of 107, net +13 |
| Movement | Charges with odds: sweet spot (55-75%) | 14 of 87, net +37 | 17 of 107, net +39 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 5 of 87, net +83 | 6 of 107, net +146 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 31 of 87, net +42 | 33 of 107, net +148 |
| Shooting | Shots by shooting units (incl. breath weapons) | 9.6 | 10.9 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 37% (129 of 345) | 44% (174 of 394) |
| Shooting | Points destroyed by shooting units | 111.6 | 49.5 |
| Shooting | War machine shots | 6.5 | 2.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 59% (137 of 234) | 56% (47 of 84) |
| Shooting | Points destroyed by war machines | 97.8 | 54.6 |
| Magic | Magic missiles cast | 2.2 | 0.9 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 40% (32 of 81) | 35% (11 of 31) |
| Magic | Wounds caused by magic missiles | 2.9 | 1.7 |
| Magic | Wounds caused by other spells | 2.2 | 0.5 |
| Magic | Points destroyed by magic (all spells) | 42.4 | 28.2 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.9 / 0.4 / 0.9 / 0.2 | 1.8 / 0.3 / 0.3 / 0.2 |
| Combat | Points destroyed in combat | 280.4 | 428.7 |
| Combat | Points run down | 35.6 | 100.1 |
| Combat | Net points per charged fight, damage counted | +36 | +93 |
| Combat | Net per 100 charger points, damage counted | +13.7 | +33.0 |
| Combat | First round won (charged fights) | 76% | 71% |
| Combat | Net points per charged fight | +29 | +88 |
| Combat | Net points per supported fight / lone fight | +68 / +23 | +229 / +54 |
| Combat | Charged fights on a top-3 enemy unit | 30 of 98 | 52 of 123 |
| Game | Points lost | 786.8 | 653.1 |
| Game | VP from objectives | 512.8 | 605.3 |
| Game | Lone holders (player turns) | 2.4 | 3.2 |

- Mine won / drew / lost: 12 / 6 / 18 of 36 ended games (of 36); mean margin (Mine - Opponent) -224 VP
- The side that went first won 12 of 30 games with a winner
- Points traded per game (both sides' losses): 1440
- Games not ended: 0; findings 0, warnings 1

### Opponent rules: su-h2h-opp-e45904b-p2

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 0.5 | +0.0 | 0.0 | 0.0 |
| ARRIVAL HUNT | - | - | - | - | 0.1 | +4.9 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.6 | +0.0 | 0.0 | 23.9 | 0.1 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | 1.0 | +9.5 | 0.0 | 42.5 | 0.9 | +8.1 | 0.0 | 8.9 |
| BEST FACING | 0.8 | +20.1 | 0.0 | 20.6 | 0.6 | +21.4 | 0.0 | 1.8 |
| BEST FIRST | 4.7 | +178.7 | 180.7 | 103.8 | 5.1 | +173.6 | 133.1 | 111.6 |
| BEST OVERALL | 0.8 | +48.3 | 0.0 | 28.6 | 0.8 | +51.6 | 0.0 | 24.1 |
| BEST PREY | 1.2 | +51.3 | 35.2 | 26.3 | 0.6 | +19.6 | 20.6 | 1.9 |
| BEST PRIZE | - | - | - | - | 0.1 | -8.5 | 9.9 | 18.8 |
| BIG CHARACTER SAFETY | 0.3 | +0.3 | 0.0 | 0.0 | 0.2 | -1.4 | 0.0 | 33.1 |
| BLOCKED CHARGE SKIPPED | 0.1 | +0.0 | 0.0 | 4.1 | 0.1 | +0.0 | 0.0 | 5.2 |
| BLOCKED WHEEL | 0.2 | +1.4 | 0.0 | 0.0 | 0.2 | +0.4 | 0.0 | 0.8 |
| BLOWS WHERE AIMED | 0.1 | -9.3 | 16.3 | 0.0 | 0.4 | -41.0 | 72.0 | 33.8 |
| BOMBING RUN | 0.0 | +0.9 | 0.0 | 0.0 | - | - | - | - |
| BOUND ASSAILMENT | 0.1 | +0.0 | 0.0 | 6.8 | - | - | - | - |
| CANNON PLAN MISSED | 0.8 | +0.0 | 160.0 | 10.3 | 0.2 | +0.0 | 55.1 | 0.0 |
| CANNON PLANNED TARGET | 5.0 | +219.5 | 516.6 | 80.0 | 1.8 | +113.8 | 189.0 | 16.1 |
| CANNON SIGHT KEPT | 1.3 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 13.1 |
| CARRIES OUT CLOSE-IN | - | - | - | - | 0.6 | -10.1 | 73.9 | 1.1 |
| CARRIES OUT COUNTER | 0.0 | +0.0 | 0.0 | 0.0 | 0.0 | +3.1 | 3.2 | 0.0 |
| CARRIES OUT SET-UP | 0.0 | +0.0 | 0.0 | 5.2 | 0.2 | -0.9 | 47.8 | 5.7 |
| CAST JOB | 0.6 | +15.3 | 19.3 | 4.9 | 0.4 | +4.0 | 35.7 | 10.5 |
| CASTER AWAY FROM SCREEN | 0.3 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.2 | +10.9 | 6.8 | 0.0 | 0.2 | +10.9 | 2.7 | 0.0 |
| CASTS AFTER FRIENDS | 0.2 | +0.0 | 0.0 | 2.6 | 0.4 | +0.0 | 0.0 | 24.1 |
| CASTS FROM BEHIND | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.0 | +1.2 | 0.0 | 0.0 | - | - | - | - |
| CATCH ODDS | 0.0 | +0.3 | 0.0 | 8.2 | 0.0 | +2.4 | 0.0 | 0.0 |
| CHAFF PASSED | 0.2 | -0.2 | 0.0 | 2.9 | 0.2 | -0.4 | 10.1 | 7.9 |
| CHARGE BAND | 0.1 | +0.0 | 6.9 | 0.0 | 0.2 | +0.0 | 16.4 | 1.2 |
| CHARGE NOW FIRST | 2.0 | +0.0 | 157.5 | 76.8 | 2.4 | +0.0 | 314.2 | 141.3 |
| CHARGE NOW WEIGHED | 0.5 | -28.2 | 26.2 | 4.8 | 0.7 | -36.8 | 10.1 | 34.2 |
| CHARGER SLAIN LOST | 0.3 | -7.0 | 19.6 | 26.8 | 0.5 | -12.7 | 38.8 | 17.7 |
| CHARIOT NO STATIC JOB | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHARIOT WIZARD CAREFUL | 0.1 | -0.3 | 0.0 | 15.0 | - | - | - | - |
| CHEAP HELPER | - | - | - | - | 0.1 | +0.0 | 9.2 | 1.8 |
| COMBAT PIVOT | 0.5 | +0.0 | 15.4 | 26.8 | 0.4 | +0.0 | 12.2 | 26.2 |
| CONVEYANCE SEARCH | 0.3 | +52.0 | 6.7 | 2.6 | 0.6 | +63.0 | 31.1 | 37.0 |
| COUNTER-CHARGE COVER | 11.6 | +1022.3 | 0.0 | 296.2 | 7.6 | +693.2 | 0.0 | 170.9 |
| DEFENSIVE ARMY | 0.2 | +0.0 | 0.0 | 1.1 | 0.0 | +0.0 | 0.0 | 0.0 |
| EDGE GIVE GROUND | 0.1 | +0.5 | 6.9 | 0.0 | 0.3 | +10.1 | 43.6 | 0.0 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 1.8 | +122.4 | 0.0 | 60.7 | 1.5 | +108.0 | 0.0 | 56.4 |
| FALLBACK BY WORTH | 4.7 | +37.1 | 0.0 | 87.1 | 5.0 | +26.4 | 0.0 | 50.5 |
| FIGHT LIFT | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FIRE AND FLEE | 0.1 | +0.9 | 7.7 | 0.0 | 0.0 | +0.4 | 0.0 | 0.0 |
| FLANK NOT WEIGHED | 6.9 | +0.0 | 0.0 | 176.0 | 5.0 | +0.0 | 0.0 | 111.1 |
| FOCUS FIRE | - | - | - | - | 0.1 | +1.9 | 0.0 | 0.0 |
| FOLLOW UP WEIGHED | 0.9 | +131.5 | 0.0 | 55.1 | 0.8 | +83.7 | 0.0 | 28.2 |
| FRIENDS SHOTS CHECKED | 0.2 | +24.3 | 0.0 | 30.7 | 0.4 | +14.6 | 0.0 | 28.4 |
| GIVES UP | 0.1 | -1.7 | 4.4 | 9.2 | 0.1 | -0.3 | 9.3 | 0.0 |
| GIVES UP ITS SCREEN | 0.0 | -0.4 | 0.0 | 3.2 | 0.0 | -0.0 | 3.4 | 0.0 |
| GROUND FLIERS | 0.0 | +0.6 | 0.0 | 7.5 | - | - | - | - |
| HELPER ALREADY ASKED | - | - | - | - | 0.1 | +0.0 | 8.0 | 5.7 |
| HELPER UNSEEN | 0.2 | +0.0 | 19.9 | 15.4 | 0.6 | +0.0 | 84.7 | 63.7 |
| HILL BY ITS CHANCE | 0.5 | -34.5 | 0.0 | 0.0 | 0.6 | -58.4 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 6.3 | -97.7 | 223.4 | 182.7 | 9.8 | -202.4 | 740.0 | 244.8 |
| HORN WORTH | - | - | - | - | 0.0 | +0.1 | 0.0 | 0.0 |
| HUNT ADVANCE | 0.0 | +0.2 | 0.0 | 0.0 | 0.2 | +3.9 | 4.6 | 1.9 |
| HUNT DROPPED | 0.0 | +0.0 | 0.0 | 3.2 | 0.1 | +0.0 | 0.0 | 3.9 |
| HUNT IN PAIRS | 0.4 | +36.3 | 0.0 | 0.0 | 0.4 | +37.3 | 0.0 | 1.9 |
| HUNT KEPT | - | - | - | - | 0.1 | +5.0 | 18.3 | 0.0 |
| HUNT RESULT | 0.1 | +0.0 | 0.0 | 3.2 | 0.2 | +33.4 | 0.0 | 3.9 |
| HUNT THE GUNS | 0.1 | +12.6 | 0.0 | 3.2 | 0.2 | +70.4 | 9.2 | 1.9 |
| INVITES THE FIGHT | 1.6 | +26.8 | 52.4 | 22.7 | 1.2 | +22.5 | 52.1 | 15.1 |
| JOINT AS ONE | - | - | - | - | 1.6 | -9.1 | 100.6 | 54.2 |
| JOINT CHARGE PLAN | - | - | - | - | 0.1 | +0.1 | 0.0 | 3.5 |
| JOINT KNOWS CHALLENGE | - | - | - | - | 0.1 | -0.6 | 10.3 | 0.0 |
| KEEP FALLS | 0.1 | +0.9 | 0.0 | 0.0 | - | - | - | - |
| KEEPS ITS PREY | 0.0 | +1.7 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| KEEPS ITS TARGET | 1.3 | +38.3 | 89.3 | 80.7 | 2.0 | +60.8 | 245.6 | 29.2 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| KILLS COUNT | 1.3 | +61.8 | 65.6 | 46.1 | 1.9 | +76.1 | 155.1 | 48.2 |
| KILLS COUNT NEXT TURN | 5.6 | +173.0 | 113.3 | 147.2 | 7.0 | +227.5 | 335.4 | 130.6 |
| LONE CHARACTER SAFE SPOT | 0.3 | +26.0 | 12.2 | 3.2 | 0.4 | +10.4 | 13.1 | 16.6 |
| LONE WIZARD HOLDS BACK | 0.1 | +0.0 | 0.0 | 3.2 | 0.4 | +0.0 | 10.6 | 16.1 |
| LONE WIZARD KEPT IN | 0.6 | +39.4 | 0.0 | 0.0 | 0.3 | +23.5 | 0.0 | 0.0 |
| LONG SHOT | 0.2 | -2.2 | 6.3 | 13.7 | 0.9 | +1.4 | 33.5 | 9.4 |
| LOST CHARGE | 3.0 | -47.8 | 85.8 | 109.7 | 2.2 | -34.1 | 66.8 | 62.6 |
| LURE BY WHAT IT DRAWS | 0.0 | -0.9 | 0.0 | 0.0 | 0.1 | -11.2 | 0.0 | 4.4 |
| MAKE SURE TOGETHER | 0.2 | +16.0 | 0.0 | 18.9 | 0.3 | +15.6 | 6.5 | 8.3 |
| MANOEUVRE | 0.3 | +4.4 | 0.0 | 7.7 | 0.4 | +7.7 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.1 | +1.7 | 0.0 | 0.0 | 0.0 | +0.6 | 0.0 | 0.0 |
| MARCH CHECK | 0.6 | +18.2 | 0.0 | 11.0 | 0.5 | +17.8 | 0.0 | 0.0 |
| MARCH ODDS | 0.1 | +5.5 | 0.0 | 0.0 | 0.2 | +16.3 | 4.6 | 10.5 |
| MARCH OVER CASTS | 0.5 | +27.7 | 0.0 | 11.0 | 0.3 | +27.2 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 5.9 | +192.2 | 0.0 | 141.7 | 4.8 | +202.4 | 0.0 | 118.8 |
| MISSILES IN THE MOVE | 3.8 | +82.5 | 0.0 | 82.6 | 3.4 | +69.0 | 0.0 | 75.7 |
| MISSILES NEXT TURN | 4.4 | +62.8 | 0.0 | 103.8 | 3.8 | +43.2 | 0.0 | 97.1 |
| MODEL FACING | 0.3 | +71.6 | 0.0 | 1.7 | 0.2 | +43.4 | 0.0 | 1.7 |
| MONSTER WIZARD ROAMS | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 24.1 | 0.0 |
| MOVE AND CAST | 0.3 | +8.3 | 0.0 | 0.0 | 0.3 | +16.4 | 0.0 | 4.4 |
| MOVE SPELL IN RANGE | 0.1 | +5.9 | 0.0 | 32.2 | - | - | - | - |
| MOVE SPELL NOT WORTH | 0.0 | -0.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.2 | -6.4 | 2.2 | 2.6 | 0.2 | -9.7 | 0.0 | 7.6 |
| MOVE SPELL SPOT | 0.2 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE | 2.2 | +148.8 | 57.7 | 103.3 | 3.9 | +239.8 | 232.9 | 109.8 |
| MOVES UNITS SPELL | 0.1 | +3.4 | 0.0 | 0.0 | - | - | - | - |
| NEEDED THERE | 0.0 | +6.7 | 0.0 | 0.0 | - | - | - | - |
| NO CHARGE WHY | 2.6 | +0.0 | 112.6 | 104.3 | 3.8 | +0.0 | 156.4 | 207.4 |
| NO RALLY LEFT | 0.1 | +0.9 | 0.0 | 4.2 | - | - | - | - |
| NOT NEEDED | 0.1 | -11.0 | 15.1 | 0.8 | 0.5 | -24.0 | 56.6 | 3.5 |
| NOT TURNED | 6.7 | +108.9 | 0.0 | 161.9 | 5.5 | +33.4 | 0.0 | 105.3 |
| NOT WORTH A CAST | 0.5 | -0.2 | 0.0 | 0.0 | 0.8 | -0.7 | 0.0 | 0.0 |
| OFF BEST | 15.8 | -678.7 | 18.3 | 277.0 | 16.2 | -865.5 | 9.1 | 317.1 |
| OPENS A LANE | 0.1 | +1.0 | 3.9 | 0.0 | 0.1 | +0.4 | 4.2 | 0.0 |
| OPENS UP | 0.1 | +3.1 | 6.2 | 0.0 | 0.1 | +6.0 | 4.1 | 0.0 |
| OVERRUN THREAT | - | - | - | - | 0.0 | +7.1 | 0.0 | 0.0 |
| OVERRUNS AWAY | 0.4 | +4.3 | 30.0 | 5.6 | 0.5 | +9.1 | 33.5 | 6.0 |
| PATHS CROSS | 1.9 | +102.5 | 0.0 | 50.3 | 3.2 | +200.4 | 0.0 | 58.7 |
| PERIAPT WORTH | 0.0 | +2.8 | 0.0 | 0.0 | 0.0 | +1.4 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.1 | -2.3 | 0.0 | 8.6 | 0.1 | -0.9 | 0.0 | 5.1 |
| PLAN RESULT | 37.4 | +1630.2 | 1367.6 | 1010.5 | 41.6 | +1298.1 | 1490.9 | 933.0 |
| PURSUES BIG PREY | 0.1 | -9.2 | 0.0 | 0.0 | 0.0 | -3.6 | 0.0 | 0.0 |
| PURSUES ON | 0.0 | +1.5 | 0.0 | 0.0 | - | - | - | - |
| RAIDS THE BAGGAGE NEXT TURN | 0.0 | +1.7 | 0.0 | 3.4 | - | - | - | - |
| RANDOM MOVE BY FIGURES | 0.8 | +15.0 | 0.0 | 30.6 | 1.6 | +14.1 | 0.0 | 12.8 |
| RANDOM MOVER NO PROMISE | 0.2 | -13.8 | 4.0 | 9.4 | 0.3 | -20.2 | 1.0 | 0.0 |
| REDIRECT BY WHAT IT STOPS | 0.2 | -6.0 | 0.0 | 1.7 | 0.4 | -5.0 | 0.0 | 6.6 |
| REDIRECT COUNTER | 2.5 | +189.1 | 0.0 | 36.7 | 4.1 | +328.4 | 0.0 | 59.8 |
| REDIRECT WEIGHED | 0.1 | +1.8 | 3.1 | 0.8 | 0.5 | -1.9 | 24.9 | 22.9 |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 37.3 |
| RESERVE FALL BACK | 0.4 | +7.6 | 0.0 | 2.2 | 1.0 | +20.3 | 0.0 | 20.4 |
| RESTRAINS TO SHOOT | 0.1 | +3.6 | 0.0 | 6.6 | 0.1 | +4.1 | 0.0 | 3.0 |
| RISK BY ARC | 2.2 | +88.9 | 140.3 | 97.2 | 3.4 | +90.7 | 336.9 | 110.6 |
| SAFER THAN THE JOB | 1.3 | +73.5 | 0.0 | 27.5 | 1.2 | +92.9 | 0.0 | 62.5 |
| SCOUT SPOT | 0.3 | +0.9 | 0.0 | 0.0 | 0.5 | +2.4 | 0.0 | 0.0 |
| SCOUT WAITS | 0.3 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.2 | -16.1 | 0.0 | 2.5 | 0.4 | -23.4 | 0.0 | 2.3 |
| SEARCH SPOT | 2.8 | +134.2 | 0.0 | 42.5 | 2.5 | +102.7 | 0.0 | 27.4 |
| SECOND HUNTER | - | - | - | - | 0.1 | -0.7 | 9.2 | 0.0 |
| SELF MOVE SPELL | 0.2 | +3.0 | 0.0 | 21.9 | - | - | - | - |
| SET UP TOGETHER | 0.4 | +25.0 | 0.0 | 18.9 | 1.2 | +59.0 | 66.5 | 25.5 |
| SET-UP ANY TARGET | 0.1 | +6.1 | 0.0 | 0.0 | 0.2 | +34.7 | 7.9 | 7.6 |
| SET-UP SPOT | - | - | - | - | 6.2 | +86.3 | 133.5 | 179.0 |
| SHOOTERS IN TWO RANKS | 0.4 | +0.8 | 0.0 | 0.0 | 0.3 | +0.6 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.4 | +65.7 | 59.6 | 15.3 | 0.9 | +53.6 | 14.8 | 15.1 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| SHOT REPLANNED | 0.8 | +0.0 | 158.8 | 7.2 | 0.4 | +0.0 | 104.9 | 0.0 |
| SHOTS IN THE MOVE | 13.9 | +668.3 | 0.0 | 223.4 | 11.2 | +390.0 | 0.0 | 170.8 |
| SPELL CATCH ODDS | 0.0 | -0.9 | 0.0 | 0.0 | 0.0 | -0.4 | 0.0 | 0.0 |
| SPELL SETS UP CHARGE | 0.1 | +47.3 | 0.0 | 0.0 | 0.2 | +46.1 | 7.9 | 7.6 |
| SPELL WORTH | 0.7 | +21.7 | 62.0 | 64.2 | 1.6 | +24.3 | 69.2 | 69.2 |
| SPELLS IN THE FIGHT | 0.5 | +7.3 | 73.9 | 25.0 | 0.8 | -13.4 | 122.9 | 51.0 |
| STABLE ROLE | 11.5 | +0.0 | 361.9 | 160.0 | 11.5 | +0.0 | 425.0 | 202.9 |
| STANDS TO CAST | 0.1 | +0.8 | 0.0 | 2.2 | 0.1 | +3.9 | 0.0 | 0.0 |
| STAY WEIGHED | 0.0 | +2.5 | 0.0 | 0.0 | 0.0 | +1.8 | 0.0 | 0.0 |
| STOPS | 0.0 | +0.3 | 0.0 | 3.2 | 0.1 | +8.0 | 18.3 | 0.0 |
| STOPS SHORT OF THE FLANK | 0.6 | +32.8 | 0.0 | 13.5 | 0.3 | +21.9 | 0.0 | 1.8 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 4.7 | 0.2 | +0.0 | 0.0 | 8.1 |
| SUPPORT NARROWED | 6.4 | -57.3 | 248.5 | 123.9 | 7.7 | -49.5 | 348.4 | 98.1 |
| SUPPORTS | 4.8 | +60.5 | 170.8 | 71.7 | 4.9 | +50.3 | 113.5 | 39.7 |
| SURE CHARGE BEATS ADVANCE | 0.1 | -3.4 | 9.7 | 8.6 | 0.1 | -1.6 | 4.7 | 0.0 |
| SURE REACH TOGETHER | 0.3 | +1.1 | 0.0 | 31.4 | 0.8 | +5.8 | 14.2 | 27.8 |
| THROUGH LINE OF FIRE | 0.2 | +13.7 | 0.0 | 18.2 | 0.4 | +25.7 | 0.0 | 0.0 |
| TURN WORTH | 0.2 | -9.3 | 15.5 | 9.4 | 0.3 | -15.6 | 23.0 | 11.2 |
| TWO OR MORE ARRIVE | 0.1 | +0.2 | 0.0 | 1.4 | 0.2 | +0.3 | 0.0 | 3.5 |
| WAIT AFTER COSTS | 5.4 | -247.5 | 146.4 | 146.6 | 7.2 | -342.9 | 404.8 | 153.0 |
| WALKS TO THE FIGHT | 1.1 | +20.7 | 30.8 | 4.4 | 1.4 | +20.9 | 63.9 | 10.3 |
| WAR ENGINE CHARGES | 0.0 | +2.5 | 0.0 | 0.0 | 0.1 | +10.7 | 5.6 | 0.0 |
| WAR ENGINE JOBS | 0.6 | +0.0 | 22.2 | 19.7 | 0.2 | +0.0 | 14.0 | 20.6 |
| WEARS DOWN | 0.9 | +37.1 | 80.1 | 45.4 | 2.4 | +72.3 | 267.4 | 102.6 |
| WHO HITS BACK | 0.2 | +18.7 | 0.0 | 0.0 | 0.1 | +10.6 | 0.0 | 0.0 |
| WHOLE FIGHT | 0.2 | +4.3 | 6.7 | 5.7 | 0.3 | +8.2 | 33.0 | 5.2 |
| WHOLE FIGHT GAIN | 0.3 | +28.5 | 19.7 | 2.4 | 0.9 | +101.2 | 60.5 | 28.2 |
| WIDER SPREAD | 1.9 | -5.6 | 158.1 | 82.0 | 4.1 | -3.2 | 394.6 | 91.2 |

### Rule changes: su-h2h-opp-e45904b-p2

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 1152 | 1152 | 1152 | 32.00 | -55589 | -48.3 |
| BEST FIRST | 353 | 353 | 353 | 9.81 | +12685 | +35.9 |
| SEARCH SPOT | 191 | 191 | 189 | 5.25 | +8539 | +45.2 |
| PATHS CROSS | 185 | 185 | 185 | 5.14 | +10901 | +58.9 |
| COUNTER-CHARGE COVER | 690 | 365 | 173 | 4.81 | +10725 | +62.0 |
| KILLS COUNT NEXT TURN | 453 | 453 | 158 | 4.39 | +4482 | +28.4 |
| SUPPORTS | 349 | 349 | 128 | 3.56 | +1165 | +9.1 |
| MOVE TO CHARGE | 219 | 219 | 125 | 3.47 | +4694 | +37.5 |
| FACES THE THREAT | 119 | 119 | 119 | 3.31 | +8295 | +69.7 |
| SET-UP SPOT | 223 | 223 | 101 | 2.81 | +3160 | +31.3 |
| SAFER THAN THE JOB | 91 | 91 | 91 | 2.53 | +5991 | +65.8 |
| FALLBACK BY WORTH | 349 | 349 | 83 | 2.31 | +2288 | +27.6 |
| SHOTS IN THE MOVE | 907 | 589 | 79 | 2.19 | +2522 | +31.9 |
| CANNON SIGHT KEPT | 70 | 70 | 70 | 1.94 | +0 | +0.0 |
| ARTILLERY RE-ROLL WEIGHED | 62 | 62 | 62 | 1.72 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 61 | 61 | 61 | 1.69 | +7746 | +127.0 |
| MAX FOR POSITIONING | 383 | 228 | 61 | 1.69 | +1017 | +16.7 |
| WAIT AFTER COSTS | 454 | 454 | 61 | 1.69 | +1490 | +24.4 |
| BEST OVERALL | 59 | 59 | 59 | 1.64 | +3596 | +60.9 |
| REDIRECT COUNTER | 239 | 128 | 53 | 1.47 | +4108 | +77.5 |
| WALKS TO THE FIGHT | 90 | 90 | 51 | 1.42 | +632 | +12.4 |
| BEST FACING | 49 | 49 | 49 | 1.36 | +1495 | +30.5 |
| RESERVE FALL BACK | 49 | 49 | 49 | 1.36 | +1002 | +20.5 |
| RANDOM MOVE BY FIGURES | 89 | 89 | 46 | 1.28 | +1046 | +22.8 |
| SHOOTS FROM THE BEST SPOT | 82 | 82 | 43 | 1.19 | +2454 | +57.1 |
| SHOT REPLANNED | 43 | 43 | 43 | 1.19 | +0 | +0.0 |
| ADVANCE LANE KEPT | 42 | 42 | 42 | 1.17 | +0 | +0.0 |
| CHARGE NOW WEIGHED | 41 | 41 | 41 | 1.14 | +1940 | +47.3 |
| HOLDS AMBUSHERS | 40 | 40 | 40 | 1.11 | +0 | +0.0 |
| MARCH CHECK | 40 | 39 | 37 | 1.03 | +1257 | +34.0 |
| RISK BY ARC | 203 | 196 | 37 | 1.03 | +1207 | +32.6 |
| KILLS COUNT | 115 | 111 | 33 | 0.92 | +1233 | +37.4 |
| LONE WIZARD KEPT IN | 33 | 33 | 33 | 0.92 | +2266 | +68.7 |
| SCOUT WAITS | 32 | 32 | 32 | 0.89 | +0 | +0.0 |
| STOPS SHORT OF THE FLANK | 32 | 32 | 32 | 0.89 | +1970 | +61.5 |
| CANNON PLANNED TARGET | 243 | 243 | 31 | 0.86 | -995 | -32.1 |
| COMBAT PIVOT | 31 | 31 | 31 | 0.86 | +0 | +0.0 |
| CHARGE NOW FIRST | 159 | 159 | 30 | 0.83 | -1245 | -41.5 |
| MISSILES IN THE MOVE | 261 | 142 | 27 | 0.75 | +521 | +19.3 |
| SHOOTERS IN TWO RANKS | 25 | 25 | 25 | 0.69 | +50 | +2.0 |
| BEST PREY | 65 | 65 | 22 | 0.61 | +749 | +34.1 |
| INVITES THE FIGHT | 102 | 102 | 22 | 0.61 | +325 | +14.8 |
| MOVE AND CAST | 22 | 22 | 22 | 0.61 | +891 | +40.5 |
| SET UP TOGETHER | 60 | 49 | 22 | 0.61 | +1080 | +49.1 |
| FRIENDS SHOTS CHECKED | 21 | 21 | 21 | 0.58 | +1400 | +66.7 |
| HONEST WORTH | 579 | 572 | 21 | 0.58 | +113 | +5.4 |
| THROUGH LINE OF FIRE | 21 | 21 | 21 | 0.58 | +1420 | +67.6 |
| REDIRECT WEIGHED | 20 | 20 | 20 | 0.56 | +911 | +45.5 |
| WHOLE FIGHT GAIN | 43 | 41 | 20 | 0.56 | +1367 | +68.3 |
| BIG CHARACTER SAFETY | 19 | 19 | 19 | 0.53 | -42 | -2.2 |
| CAST JOB | 38 | 38 | 19 | 0.53 | +172 | +9.0 |
| MANOEUVRE | 23 | 23 | 19 | 0.53 | +435 | +22.9 |
| MODEL FACING | 18 | 18 | 18 | 0.50 | +4142 | +230.1 |
| WEARS DOWN | 118 | 115 | 18 | 0.50 | +783 | +43.5 |
| BLOCKED WHEEL | 16 | 16 | 16 | 0.44 | +65 | +4.1 |
| CASTER AWAY FROM SCREEN | 16 | 16 | 16 | 0.44 | +0 | +0.0 |
| CHAFF PASSED | 16 | 16 | 16 | 0.44 | -19 | -1.2 |
| KEEPS ITS TARGET | 119 | 114 | 16 | 0.44 | +300 | +18.7 |
| CASTS FROM BEHIND | 15 | 15 | 15 | 0.42 | +0 | +0.0 |
| SHORT GUN FORWARD | 14 | 14 | 14 | 0.39 | +0 | +0.0 |
| CASTING BLOCK | 17 | 17 | 13 | 0.36 | +430 | +33.0 |
| WHO HITS BACK | 13 | 13 | 13 | 0.36 | +694 | +53.4 |
| MARCH ODDS | 12 | 12 | 12 | 0.33 | +129 | +10.8 |
| CHARGE BAND | 10 | 10 | 10 | 0.28 | +0 | +0.0 |
| STUCK PIVOT | 10 | 10 | 10 | 0.28 | +0 | +0.0 |
| JOINT AS ONE | 59 | 59 | 8 | 0.22 | -177 | -22.2 |
| PIVOT GUARDS FLANK | 8 | 8 | 8 | 0.22 | -115 | -14.4 |
| RESTRAINS TO SHOOT | 8 | 8 | 8 | 0.22 | +280 | +35.0 |
| SURE CHARGE BEATS ADVANCE | 8 | 8 | 8 | 0.22 | -180 | -22.5 |
| LOST CHARGE | 188 | 188 | 7 | 0.19 | +174 | +24.8 |
| REFUSING RETIRES | 24 | 24 | 7 | 0.19 | -2 | -0.3 |
| SUPPORT NARROWED | 509 | 509 | 7 | 0.19 | -94 | -13.5 |
| SURE REACH TOGETHER | 42 | 28 | 7 | 0.19 | +77 | +11.0 |
| MISSILES NEXT TURN | 294 | 159 | 6 | 0.17 | +21 | +3.5 |
| BLOCKED CHARGE SKIPPED | 5 | 5 | 5 | 0.14 | +0 | +0.0 |
| CARRIES OUT CLOSE-IN | 20 | 20 | 5 | 0.14 | -366 | -73.1 |
| HUNT IN PAIRS | 31 | 19 | 5 | 0.14 | +380 | +75.9 |
| LONE WIZARD HOLDS BACK | 17 | 17 | 5 | 0.14 | +0 | +0.0 |
| MAKE SURE TOGETHER | 21 | 11 | 5 | 0.14 | +372 | +74.5 |
| SPELLS IN THE FIGHT | 47 | 44 | 5 | 0.14 | +105 | +21.0 |
| STANDS TO CAST | 5 | 5 | 5 | 0.14 | -9 | -1.8 |
| WAR ENGINE JOBS | 31 | 31 | 5 | 0.14 | -292 | -58.5 |
| WHOLE FIGHT | 18 | 18 | 5 | 0.14 | +218 | +43.5 |
| BACKUP TARGETS | 70 | 38 | 4 | 0.11 | +48 | +11.9 |
| BEST PRIZE | 4 | 4 | 4 | 0.11 | -422 | -105.4 |
| KEEPS SCOUTS OR AMBUSH | 4 | 4 | 4 | 0.11 | +0 | +0.0 |
| MOVES UNITS SPELL | 4 | 4 | 4 | 0.11 | +122 | +30.4 |
| PURSUES BIG PREY | 4 | 4 | 4 | 0.11 | -462 | -115.4 |
| WIDER SPREAD | 217 | 208 | 4 | 0.11 | +7 | +1.8 |
| FIRE AND FLEE | 3 | 3 | 3 | 0.08 | +47 | +15.6 |
| FOCUS FIRE | 3 | 3 | 3 | 0.08 | +69 | +22.9 |
| OPENS UP | 4 | 4 | 3 | 0.08 | +201 | +66.9 |
| BOUND ASSAILMENT | 2 | 2 | 2 | 0.06 | +0 | +0.2 |
| CATCH ODDS | 2 | 2 | 2 | 0.06 | -45 | -22.4 |
| CHARIOT NO STATIC JOB | 2 | 2 | 2 | 0.06 | -364 | -181.9 |
| DEFENSIVE ARMY | 8 | 8 | 2 | 0.06 | -159 | -79.6 |
| KEEP FALLS | 2 | 2 | 2 | 0.06 | +112 | +55.8 |
| LONG SHOT | 42 | 41 | 2 | 0.06 | +64 | +32.0 |
| NO RALLY LEFT | 2 | 2 | 2 | 0.06 | +18 | +9.1 |
| OVERRUNS AWAY | 33 | 33 | 2 | 0.06 | +19 | +9.6 |
| PERIAPT WORTH | 2 | 2 | 2 | 0.06 | +153 | +76.6 |
| STAY WEIGHED | 2 | 2 | 2 | 0.06 | +154 | +76.9 |
| BLOWS WHERE AIMED | 17 | 15 | 1 | 0.03 | +0 | +0.3 |
| BOMBING RUN | 1 | 1 | 1 | 0.03 | +32 | +32.5 |
| CARRIES OUT COUNTER | 2 | 2 | 1 | 0.03 | +112 | +112.3 |
| CARRIES OUT SET-UP | 9 | 9 | 1 | 0.03 | -33 | -33.2 |
| HORN WORTH | 1 | 1 | 1 | 0.03 | +3 | +3.0 |
| KEEPS ITS PREY | 2 | 2 | 1 | 0.03 | +1 | +0.9 |
| MOVE SPELL IN RANGE | 5 | 5 | 1 | 0.03 | +1 | +1.1 |
| NEEDED THERE | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| OPENS A LANE | 4 | 2 | 1 | 0.03 | +15 | +15.3 |
| PURSUES ON | 1 | 1 | 1 | 0.03 | +54 | +53.6 |
| RAIDS THE BAGGAGE NEXT TURN | 1 | 1 | 1 | 0.03 | +16 | +16.5 |
| REDIRECT BY WHAT IT STOPS | 21 | 21 | 1 | 0.03 | +120 | +120.0 |
| STOPS | 6 | 6 | 1 | 0.03 | +42 | +41.5 |
| ARRIVAL HUNT | 4 | 4 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 37 | 37 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 21 | trace | - | - | - | - |
| CATCH FLIERS | 1 | not checked | - | - | - | - |
| CHARGER SLAIN LOST | 30 | 29 | 0 | 0.00 | - | - |
| CHARIOT WIZARD CAREFUL | 2 | 2 | 0 | 0.00 | - | - |
| CHEAP HELPER | 5 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 31 | not checked | - | - | - | - |
| EDGE GIVE GROUND | 14 | 13 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT LIFT | 1 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 431 | not checked | - | - | - | - |
| GIVES UP | 6 | 4 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 2 | 2 | 0 | 0.00 | - | - |
| GROUND FLIERS | 1 | not checked | - | - | - | - |
| HELPER ALREADY ASKED | 5 | not checked | - | - | - | - |
| HELPER UNSEEN | 29 | 27 | 0 | 0.00 | - | - |
| HILL BY ITS CHANCE | 37 | 37 | 0 | 0.00 | - | - |
| HUNT ADVANCE | 7 | 7 | 0 | 0.00 | - | - |
| HUNT DROPPED | 5 | trace | - | - | - | - |
| HUNT KEPT | 5 | trace | - | - | - | - |
| HUNT RESULT | 9 | trace | - | - | - | - |
| HUNT THE GUNS | 10 | trace | - | - | - | - |
| JOINT CHARGE PLAN | 2 | 2 | 0 | 0.00 | - | - |
| JOINT KNOWS CHALLENGE | 3 | 3 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 25 | not checked | - | - | - | - |
| LURE BY WHAT IT DRAWS | 5 | 5 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 5 | trace | - | - | - | - |
| MARCH OVER CASTS | 28 | 28 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 12 | 12 | 0 | 0.00 | - | - |
| MOVE SPELL NOT WORTH | 1 | not checked | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 15 | trace | - | - | - | - |
| MOVE SPELL SPOT | 9 | not checked | - | - | - | - |
| NO CHARGE WHY | 227 | not checked | - | - | - | - |
| NOT NEEDED | 23 | 21 | 0 | 0.00 | - | - |
| NOT TURNED | 439 | 439 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 45 | not checked | - | - | - | - |
| OVERRUN THREAT | 1 | not checked | - | - | - | - |
| PLAN RESULT | 2846 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 20 | 20 | 0 | 0.00 | - | - |
| SCOUT SPOT | 28 | 28 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 21 | 21 | 0 | 0.00 | - | - |
| SECOND HUNTER | 2 | 2 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 9 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 9 | not checked | - | - | - | - |
| SPELL CATCH ODDS | 2 | not checked | - | - | - | - |
| SPELL SETS UP CHARGE | 14 | not checked | - | - | - | - |
| SPELL WORTH | 85 | not checked | - | - | - | - |
| STABLE ROLE | 829 | 829 | 0 | 0.00 | - | - |
| TURN WORTH | 18 | 18 | 0 | 0.00 | - | - |
| TWO OR MORE ARRIVE | 11 | 11 | 0 | 0.00 | - | - |
| WAR ENGINE CHARGES | 6 | 6 | 0 | 0.00 | - | - |

### Off best figure: su-h2h-opp-e45904b-p2

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 13.83 | 14.19 | 49.8 |
| TURN GATE | gate | 0.61 | 0.75 | 35.6 |
| FALLBACK | gate | 0.86 | 0.42 | 47.5 |
| CHARGE NOW FIRST | rule | 0.33 | 0.47 | 42.9 |
| NO REASON | gate | - | 0.44 | 19.1 |
| CANNON PLANNED TARGET | rule | 0.36 | 0.06 | 66.3 |
| LONE CHARACTER SAFE SPOT | gate | 0.17 | 0.14 | 41.8 |
| PATHS CROSS | rule | 0.14 | 0.11 | 40.2 |
| PIVOT GUARDS FLANK | rule | 0.08 | 0.14 | 14.4 |
| SURE CHARGE BEATS ADVANCE | rule | 0.11 | 0.11 | 22.5 |
| AFTERMATH BAND | gate | 0.17 | 0.03 | 2.1 |
| BIG CHARACTER SAFETY | rule | 0.06 | 0.14 | 10.3 |
| JOINT AS ONE | rule | - | 0.19 | 27.0 |
| SUPPORT NARROWED | rule | 0.08 | 0.11 | 13.5 |
| SUPPORT REQUEST | gate | 0.06 | 0.11 | 60.9 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.08 | 0.06 | 33.1 |
| CARRIES OUT CLOSE-IN | rule | - | 0.14 | 73.1 |
| CHAFF PASSED | rule | 0.08 | 0.06 | 3.7 |
| CHARGE NOW WEIGHED | rule | 0.03 | 0.11 | 25.5 |
| WAR ENGINE JOBS | rule | 0.11 | 0.03 | 58.5 |
| BEST PRIZE | rule | - | 0.11 | 105.4 |
| PURSUES BIG PREY | rule | 0.08 | 0.03 | 115.4 |
| SAFER THAN THE JOB | rule | 0.03 | 0.06 | 9.4 |
| STANDS TO CAST | rule | 0.03 | 0.06 | 7.5 |
| THROUGH LINE OF FIRE | rule | 0.06 | 0.03 | 9.9 |
| CATCH ODDS | rule | 0.03 | 0.03 | 22.4 |
| CHARIOT NO STATIC JOB | rule | 0.06 | - | 181.9 |
| DEFENSIVE ARMY | rule | 0.03 | 0.03 | 79.6 |
| FACES THE THREAT | rule | 0.03 | 0.03 | 16.9 |
| FIGHT ORDER BAND | gate | - | 0.06 | 2.0 |
| REDIRECT WEIGHED | rule | - | 0.06 | 69.1 |
| STOPS SHORT OF THE FLANK | rule | - | 0.06 | 5.2 |
| BLOCKED WHEEL | rule | - | 0.03 | 20.5 |
| CARRIES OUT SET-UP | rule | - | 0.03 | 33.2 |
| FALLBACK BY WORTH | rule | - | 0.03 | 146.2 |
| FRIENDS SHOTS CHECKED | rule | 0.03 | - | 3.9 |
| MARCH ODDS | rule | 0.03 | - | 16.5 |
| REFUSING RETIRES | rule | 0.03 | - | 0.6 |
| RULE SWITCHED OFF | gate | 0.03 | - | 64.0 |

### Plans: su-h2h-opp-e45904b-p2

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 12.3 | 21% | 479 | 405 | 85% |
| Mine | charge | 2.6 | 53% | 237 | 233 | 98% |
| Mine | close in | 3.5 | 24% | 173 | 99 | 57% |
| Mine | hold | 4.8 | 35% | 327 | 0 | 0% |
| Mine | join | 0.7 | 96% | 28 | 0 | 0% |
| Mine | shoot | 8.6 | 64% | 353 | 893 | 253% |
| Mine | support | 5.0 | 93% | 40 | 0 | 0% |
| Opponent | advance | 15.1 | 17% | 366 | 348 | 95% |
| Opponent | charge | 4.8 | 57% | 461 | 445 | 97% |
| Opponent | close in | 5.3 | 31% | 270 | 147 | 55% |
| Opponent | hold | 4.5 | 38% | 332 | 0 | 0% |
| Opponent | join | 0.9 | 97% | 39 | 0 | 0% |
| Opponent | shoot | 5.3 | 52% | 209 | 360 | 172% |
| Opponent | support | 5.6 | 92% | 39 | 0 | 0% |

### Packages: hunt the guns, su-h2h-opp-e45904b-p2

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.1 | 2 | 0 | 0% | 0% | 0% | - | 227 | 0 | 0% | 68 |
| Opponent | 0.2 | 8 | 1 | 29% | 43% | 0% | 3.3 | 349 | 172 | 29% | 122 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 250 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 222 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 49 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 77 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 36 |
| High Elf Realms | 0.5 | 2 | 0 | 0% | 0% | 0% | - | 227 | 0 | 0% | 0 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 374 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Ogre Kingdoms | 1.0 | 4 | 0 | 50% | 50% | 0% | 3.0 | 452 | 238 | 50% | 197 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 265 |
| Tomb Kings of Khemri | 0.6 | 3 | 1 | 0% | 0% | 0% | - | 131 | 0 | 0% | 78 |
| Vampire Counts | 0.1 | 1 | 0 | 0% | 100% | 0% | 4.0 | 374 | 249 | 0% | 0 |
| Warriors of Chaos | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 129 |
| Wood Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |

### Battle groups: su-h2h-opp-e45904b-p2

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 11.6 | 21% | 56% | 10% | 56% | 39% | 9% | 13% | 39% | 0% |
| Mine | REDIRECT COUNTER | 2.5 | 28% | 72% | 0% | - | 24% | 0% | 12% | 64% | 0% |
| Opponent | COUNTER-CHARGE COVER | 7.6 | 18% | 72% | 26% | 23% | 38% | 8% | 5% | 49% | 0% |
| Opponent | REDIRECT COUNTER | 4.1 | 18% | 85% | 15% | 0% | 22% | 4% | 22% | 52% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: su-h2h-opp-e45904b-p2

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 5 | 0 (5) | 0 | 0 | 17 | 40% | 2.0 | - | 0 (5) | - | 0 (1) | 0 (4) |
| Mine | Chaff | 34 | 40 (34) | 3 | 37 | 62 | 38% | 3.1 | 34 (19) | 68 (7) | 27 (8) | 47 (23) | 24 (11) |
| Mine | Character | 123 | 38 (123) | 38 | 0 | 40 | 20% | 2.6 | 36 (37) | 43 (48) | 58 (11) | 47 (46) | 35 (50) |
| Mine | Clean-up | 21 | 42 (21) | 12 | 30 | 34 | 57% | 2.7 | 32 (5) | 38 (13) | 95 (3) | 75 (13) | 9 (8) |
| Mine | Fast | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Mine | Fast Hammer | 48 | 48 (48) | 21 | 27 | 51 | 19% | 2.9 | 45 (23) | 71 (16) | 13 (9) | 47 (29) | 49 (19) |
| Mine | Fragile | 5 | 62 (5) | 62 | 0 | 40 | 0% | 2.0 | - | 103 (3) | 0 (2) | 62 (5) | - |
| Mine | Hammer | 57 | 35 (57) | 25 | 9 | 49 | 18% | 2.6 | 31 (18) | 32 (29) | 48 (10) | 35 (38) | 34 (19) |
| Mine | Holder | 28 | 53 (28) | 6 | 47 | 21 | 32% | 3.0 | 67 (11) | 62 (9) | 20 (8) | 55 (21) | 48 (7) |
| Mine | Shooter | 41 | 89 (41) | 38 | 51 | 41 | 0% | 1.6 | 135 (5) | 87 (30) | 70 (6) | 128 (25) | 29 (16) |
| Mine | Support | 2 | 0 (2) | 0 | 0 | 66 | 100% | - | - | 0 (2) | - | - | 0 (2) |
| Mine | War machine | 59 | 61 (59) | 61 | 0 | 46 | 3% | 1.2 | 75 (10) | 60 (37) | 55 (12) | 47 (10) | 64 (49) |
| Mine | Wizard | 22 | 4 (22) | 4 | 0 | 30 | 18% | 2.1 | 5 (8) | 8 (5) | 0 (4) | 5 (8) | 4 (9) |
| Opponent | Blocker | 2 | 0 (2) | 0 | 0 | 0 | 50% | 4.0 | 0 (1) | 0 (1) | - | - | 0 (2) |
| Opponent | Chaff | 76 | 60 (76) | 23 | 36 | 46 | 41% | 2.5 | 84 (32) | 39 (19) | 48 (25) | 85 (54) | 0 (22) |
| Opponent | Character | 97 | 61 (97) | 61 | 0 | 36 | 25% | 2.3 | 78 (44) | 53 (41) | 15 (5) | 57 (62) | 76 (28) |
| Opponent | Clean-up | 19 | 39 (19) | 31 | 8 | 44 | 26% | 2.7 | 38 (9) | 39 (10) | - | 44 (14) | 25 (5) |
| Opponent | Early | 2 | 0 (2) | 0 | 0 | 0 | 50% | 5.0 | - | 0 (2) | - | 0 (1) | 0 (1) |
| Opponent | Fast Hammer | 48 | 32 (48) | 21 | 11 | 42 | 23% | 2.4 | 29 (22) | 23 (16) | 55 (10) | 25 (28) | 44 (20) |
| Opponent | Fragile | 5 | 0 (5) | 0 | 0 | 61 | 40% | 2.0 | - | 0 (3) | 0 (2) | 0 (4) | 0 (1) |
| Opponent | Hammer | 70 | 42 (70) | 35 | 7 | 27 | 21% | 3.1 | 30 (17) | 40 (42) | 76 (11) | 43 (43) | 41 (27) |
| Opponent | Holder | 35 | 57 (35) | 10 | 48 | 24 | 29% | 3.0 | 28 (5) | 61 (23) | 73 (6) | 65 (22) | 49 (12) |
| Opponent | Shooter | 33 | 76 (33) | 14 | 61 | 27 | 6% | 1.8 | 79 (8) | 78 (19) | 64 (6) | 117 (22) | 12 (11) |
| Opponent | Support | 3 | 28 (3) | 28 | 0 | 50 | 67% | 4.0 | 56 (1) | 0 (2) | - | 56 (1) | 0 (2) |
| Opponent | War machine | 24 | 86 (24) | 86 | 0 | 31 | 8% | 1.6 | 144 (6) | 71 (14) | 63 (4) | 85 (3) | 86 (21) |
| Opponent | Wizard | 26 | 10 (26) | 10 | 0 | 36 | 12% | 1.7 | 0 (9) | 23 (8) | 11 (6) | 4 (7) | 18 (16) |

### Charged fights: su-h2h-opp-e45904b-p2

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 92 | 167 | 2.8 | 1.0 | 61 | 3 | +58 | 3 of 11 | 9 of 11 | - | +58 |
| Mine | Chaos Dwarfs | 4 | 118 | 112 | 2.8 | 1.1 | 41 | 68 | -27 | 6 of 11 | 6 of 11 | +0 | -30 |
| Mine | Dwarfen Mountain Holds | 4 | 780 | 136 | 1.5 | 1.2 | 91 | 18 | +73 | 1 of 6 | 5 of 6 | +0 | +88 |
| Mine | Empire of Man | 5 | 468 | 171 | 2.0 | 1.1 | 86 | 167 | -81 | 4 of 10 | 8 of 10 | -189 | -69 |
| Mine | Grand Cathay | 4 | 123 | 136 | 1.8 | 1.0 | 78 | 0 | +78 | 2 of 7 | 6 of 7 | - | +78 |
| Mine | High Elf Realms | 4 | 305 | 406 | 4.8 | 1.2 | 86 | 0 | +86 | 6 of 19 | 16 of 19 | +245 | +56 |
| Mine | Kingdom of Bretonnia | 1 | 0 | 0 | 3.0 | 1.0 | 0 | 249 | -249 | 1 of 3 | 2 of 3 | - | -249 |
| Mine | Lizardmen | 1 | 0 | 372 | 4.0 | 1.0 | 93 | 0 | +93 | 2 of 4 | 2 of 4 | - | +93 |
| Mine | Ogre Kingdoms | 1 | 0 | 0 | 4.0 | 1.2 | 0 | 0 | +0 | 0 of 4 | 0 of 2 | +0 | +0 |
| Mine | Orc & Goblin Tribes | 1 | 50 | 481 | 4.0 | 1.2 | 120 | 0 | +120 | 1 of 4 | 4 of 4 | +45 | +145 |
| Mine | Skaven | 2 | 341 | 72 | 2.0 | 1.0 | 36 | 10 | +26 | 0 of 4 | 2 of 4 | - | +26 |
| Mine | Tomb Kings of Khemri | 1 | 240 | 235 | 6.0 | 1.2 | 39 | 9 | +30 | 1 of 6 | 6 of 6 | +125 | +11 |
| Mine | Vampire Counts | 3 | 28 | 253 | 2.7 | 1.2 | 95 | 61 | +34 | 3 of 8 | 7 of 8 | +49 | +29 |
| Mine | Warriors of Chaos | 1 | 0 | 0 | 1.0 | 2.0 | 0 | 0 | +0 | 0 of 1 | 0 of 1 | +0 | - |
| **Mine** | all armies | 36 | 252 | 185 | 2.7 | 1.1 | 68 | 40 | +29 | 30 of 98 | 73 of 96 | +68 | +23 |
| Opponent | Dwarfen Mountain Holds | 2 | 584 | 126 | 2.5 | 1.0 | 51 | 0 | +51 | 1 of 5 | 2 of 5 | - | +51 |
| Opponent | Empire of Man | 2 | 656 | 0 | 1.5 | 1.0 | 0 | 127 | -127 | 3 of 3 | 1 of 3 | - | -127 |
| Opponent | Grand Cathay | 2 | 241 | 526 | 2.0 | 1.5 | 263 | 51 | +212 | 3 of 4 | 2 of 4 | +407 | +146 |
| Opponent | Kingdom of Bretonnia | 1 | 175 | 390 | 5.0 | 1.0 | 78 | 0 | +78 | 2 of 5 | 5 of 5 | - | +78 |
| Opponent | Ogre Kingdoms | 3 | 41 | 290 | 4.0 | 1.1 | 72 | 6 | +66 | 3 of 12 | 4 of 12 | +0 | +72 |
| Opponent | Skaven | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Tomb Kings of Khemri | 4 | 48 | 844 | 4.0 | 1.3 | 211 | 143 | +68 | 8 of 16 | 10 of 16 | +384 | -37 |
| Opponent | Vampire Counts | 6 | 86 | 477 | 3.2 | 1.3 | 151 | 80 | +70 | 8 of 19 | 13 of 19 | +246 | +7 |
| Opponent | Warriors of Chaos | 8 | 16 | 496 | 2.5 | 1.3 | 198 | 36 | +162 | 11 of 20 | 19 of 20 | +299 | +104 |
| Opponent | Wood Elf Realms | 7 | 95 | 648 | 5.6 | 1.3 | 116 | 32 | +85 | 13 of 39 | 31 of 39 | +76 | +87 |
| **Opponent** | all armies | 36 | 132 | 481 | 3.4 | 1.2 | 141 | 52 | +88 | 52 of 123 | 87 of 123 | +229 | +54 |

### Effective charges: su-h2h-opp-e45904b-p2

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 11 | 0 | 0 | 0 | 3 (net +58) | 0 | 5 (net +40) | 3 | 0% (0 of 8) |
| Mine | Chaos Dwarfs | 11 | 2 (net +0) | 0 | 2 (net +0) | 4 (net +64) | 0 | 3 (net -183) | 0 | 18% (2 of 11) |
| Mine | Dwarfen Mountain Holds | 6 | 0 | 0 | 1 (net +0) | 2 (net +0) | 0 | 3 (net +147) | 0 | 17% (1 of 6) |
| Mine | Empire of Man | 10 | 0 | 0 | 3 (net -3) | 2 (net -62) | 0 | 3 (net -36) | 2 | 38% (3 of 8) |
| Mine | Grand Cathay | 7 | 2 (net +0) | 0 | 1 (net +0) | 1 (net +60) | 1 (net +40) | 1 (net +329) | 1 | 17% (1 of 6) |
| Mine | High Elf Realms | 19 | 1 (net +0) | 1 (net +0) | 3 (net +205) | 3 (net +62) | 4 (net +94) | 6 (net +75) | 1 | 17% (3 of 18) |
| Mine | Kingdom of Bretonnia | 3 | 0 | 1 (net +0) | 1 (net -277) | 1 (net -471) | 0 | 0 | 0 | 33% (1 of 3) |
| Mine | Lizardmen | 4 | 3 (net +62) | 0 | 0 | 1 (net +186) | 0 | 0 | 0 | 0% (0 of 4) |
| Mine | Ogre Kingdoms | 4 | 2 (net +0) | 0 | 0 | 1 (net +0) | 0 | 0 | 1 | 0% (0 of 3) |
| Mine | Orc & Goblin Tribes | 4 | 0 | 0 | 1 (net +45) | 0 | 0 | 1 (net +190) | 2 | 50% (1 of 2) |
| Mine | Skaven | 4 | 1 (net -38) | 0 | 1 (net +144) | 1 (net +0) | 0 | 1 (net +0) | 0 | 25% (1 of 4) |
| Mine | Tomb Kings of Khemri | 6 | 0 | 0 | 0 | 1 (net +125) | 0 | 5 (net +11) | 0 | 0% (0 of 6) |
| Mine | Vampire Counts | 8 | 1 (net -50) | 0 | 1 (net +0) | 3 (net +13) | 0 | 3 (net +95) | 0 | 12% (1 of 8) |
| Opponent | Dwarfen Mountain Holds | 5 | 1 (net +0) | 0 | 4 (net +63) | 0 | 0 | 0 | 0 | 80% (4 of 5) |
| Opponent | Empire of Man | 3 | 3 (net -127) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 3) |
| Opponent | Grand Cathay | 4 | 2 (net +204) | 0 | 1 (net +135) | 1 (net +304) | 0 | 0 | 0 | 25% (1 of 4) |
| Opponent | Kingdom of Bretonnia | 5 | 0 | 0 | 1 (net +95) | 1 (net +0) | 0 | 1 (net +115) | 2 | 33% (1 of 3) |
| Opponent | Ogre Kingdoms | 12 | 4 (net +64) | 0 | 1 (net +369) | 2 (net +85) | 0 | 1 (net +0) | 4 | 12% (1 of 8) |
| Opponent | Tomb Kings of Khemri | 16 | 6 (net -187) | 1 (net +81) | 0 | 4 (net +237) | 1 (net +170) | 4 (net +254) | 0 | 0% (0 of 16) |
| Opponent | Vampire Counts | 19 | 2 (net -12) | 0 | 4 (net -54) | 8 (net +107) | 2 (net +153) | 3 (net +140) | 0 | 21% (4 of 19) |
| Opponent | Warriors of Chaos | 20 | 2 (net -72) | 1 (net +563) | 3 (net +229) | 0 | 0 | 10 (net +202) | 4 | 19% (3 of 16) |
| Opponent | Wood Elf Realms | 39 | 5 (net +268) | 0 | 3 (net -221) | 8 (net +77) | 3 (net +134) | 14 (net +94) | 6 | 9% (3 of 33) |

### Charged fights, damage counted: su-h2h-opp-e45904b-p2

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 12 | 177 | 244 | +8 | 53 | 68 | -15 | -8.5 |
| Mine | 50-54% | 2 | 195 | 200 | +0 | 51 | 0 | +51 | +26.3 |
| Mine | Effective (55-75%) | 14 | 306 | 233 | +37 | 112 | 76 | +36 | +11.7 |
| Mine | 76-89% | 23 | 260 | 175 | +19 | 68 | 58 | +11 | +4.0 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 31 | 243 | 149 | +42 | 128 | 50 | +79 | +32.3 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 5 | 407 | 68 | +83 | 88 | 27 | +61 | +15.0 |
| Mine | No odds | 11 | 305 | 140 | +5 | 98 | 87 | +11 | +3.5 |
| Mine | All fights | 98 | 262 | 175 | +29 | 96 | 60 | +36 | +13.7 |
| Opponent | Long shot (under 50%) | 25 | 283 | 296 | +13 | 184 | 155 | +30 | +10.5 |
| Opponent | 50-54% | 2 | 529 | 200 | +322 | 366 | 60 | +306 | +57.9 |
| Opponent | Effective (55-75%) | 17 | 275 | 207 | +39 | 157 | 123 | +34 | +12.2 |
| Opponent | 76-89% | 24 | 222 | 187 | +120 | 164 | 23 | +140 | +63.2 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 33 | 297 | 183 | +148 | 178 | 45 | +133 | +44.9 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 6 | 553 | 96 | +146 | 169 | 6 | +163 | +29.5 |
| Opponent | No odds | 16 | 213 | 175 | +37 | 86 | 39 | +47 | +22.1 |
| Opponent | All fights | 123 | 282 | 205 | +88 | 164 | 71 | +93 | +33.0 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| su-h2h-opp-e45904b-p2 | move | 476 | 101 (21%) | 75 (16%) | 59 (12%) | 316 (66%) |
| su-h2h-opp-e45904b-p2 | objective | 321 | 61 (19%) | 45 (14%) | 33 (10%) | 227 (71%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0106, L0122, L2429, L2535, L2735 |
| Charmed Shield | Opponent | L0425, L0827, L0934, L1026, L1727, L1827, L1927 |
| Clockwork Compass | Mine | L1228 |
| Clockwork Compass | Opponent | L0512 |
| Elixir of Power | Mine | L1118, L1135, L1927 |
| Fistful of Laurels | Mine | L1827 |
| Fistful of Laurels | Opponent | L0918, L1118, L1418 |
| Horn of the Wild Hunt | Opponent | L3033 |
| Invocation of Nehek | Mine | L2429, L2535, L2735 |
| Invocation of Nehek | Opponent | L0425, L0827, L1727, L1827, L1927 |
| Opal Amulet | Mine | L1418, L1435 |
| Periapt of Soul Exchange | Mine | L2029, L2131 |
| Periapt of Soul Exchange | Opponent | L0721 |
| Ring of Doom | Mine | L0206, L0222, L1118, L1135, L1228, L1531 |
| Ring of Doom | Opponent | L0512, L1531, L2131, L3033 |
| Ring of Jet | Mine | L1026, L1118, L1135, L1228 |
| Ring of Jet | Opponent | L0512, L0810 |
| Standard of the Fell Warrior | Mine | L1323 |
| Storm Daemon (Renegade 2.0) | Mine | L2131 |
| Storm Daemon (Renegade 2.0) | Opponent | L0721 |
| Twice-Blessed Armour | Mine | L0721, L1026 |
| Twice-Blessed Armour | Opponent | L0307, L0810 |
| Witch Hunter's Ward | Mine | L0721, L0810, L0827 |
| Witch Hunter's Ward | Opponent | L0307 |

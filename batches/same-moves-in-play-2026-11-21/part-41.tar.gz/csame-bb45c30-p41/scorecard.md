# Doctrine scorecard: csame-bb45c30-p41

### Scorecard: csame-bb45c30-p41

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0721 | 1 | 1 | Mine | no | 3 | 1 | 3 | 1 | 0 | 0 | 0 | 420 |
| L0721 | 1 | 1 | Opponent | yes | 1 | - | 1 | 5 | 1 | 0 | 0 | 410 |
| L0810 | 6 | 1 | Mine | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 461 |
| L0810 | 6 | 1 | Opponent | no | 18 | 2 | 2 | 0 | 1 | 0 | 0 | 330 |
| L0827 | 5 | 1 | Mine | no | - | - | 0 | 3 | 0 | 0 | 0 | 560 |
| L0827 | 5 | 1 | Opponent | yes | - | 2 | 3 | 6 | 0 | 0 | 0 | 60 |
| **Average** | | | Mine | 0% | 1.5 | 1.0 | 1.0 | 2.0 | 0.0 | 0.0 | 0.0 | 480.3 |
| **Average** | | | Opponent | 67% | 9.5 | 2.0 | 2.0 | 3.7 | 0.7 | 0.0 | 0.0 | 266.7 |

### KPIs: csame-bb45c30-p41

Rules off - Opponent only: NO OLD ONE-MOVE GUESS; both sides: ONE RUN A PLAN.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 100% (15 of 15) | 0% (0 of 14) | 52% (15 of 29) |
| Winner chose to follow up after the loser gave ground |  | 50% (1 of 2); on the table 100% | 100% (3 of 3); on the table 100% | 80% (4 of 5); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | - | - | - |
| Winner chose to pursue after the loser fled |  | 0% (0 of 1); on the table 0% | 0% (0 of 1); on the table 100% | 0% (0 of 2); on the table 50% |
| Winner chose to follow up or pursue (all three) |  | 33% (1 of 3); on the table 67% | 75% (3 of 4); on the table 100% | 57% (4 of 7); on the table 86% |
| Magic missiles tried each own turn | 50%+ | 50% (3 of 6) | 39% (14 of 36) | 40% (17 of 42) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 60% (3 of 5) | 52% (14 of 27) | 53% (17 of 32) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 40% (4 of 10) | 40% (4 of 10) |
| Points that never fought | lower | 74% (4411 of 5999) | 69% (4150 of 5998) | 71% (8561 of 11997) |
|   infantry points that never fought | lower | 84% (814 of 968) | 92% (1021 of 1113) | 88% (1835 of 2081) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 67% (20 of 30) | 64% (16 of 25) | 65% (36 of 55) |
| Bound items with a magic missile used (at least once a game) |  | 0.0 uses a game | 67% (2 of 3); 2.0 uses a game | 67% (2 of 3); 1.0 uses a game |
| Bound items with another spell used |  | 100% (1 of 1); 1.0 uses a game | 0% (0 of 1); 0.0 uses a game | 50% (1 of 2); 0.5 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 67% (2 of 3); 0.7 uses a game | 50% (1 of 2); 0.3 uses a game | 60% (3 of 5); 0.5 uses a game |
|   their share of the points of units over 100 pts | lower | 62% (3309 of 5378) | 66% (3436 of 5181) | 64% (6745 of 10559) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 2.7 (36%) | 2.7 (32%) |
| MARCHED: its unit marched | 0.7 (67%) | 1.7 (23%) | 2.3 (28%) |
| IN COMBAT: engaged in combat | 0.3 (33%) | 1.0 (14%) | 1.3 (16%) |
| GONE: slain | 0.0 (0%) | 2.0 (27%) | 2.0 (24%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 6.3 | 1.7 | 3.7 | 5.7 | 0.7 | 1.0 |
| not cast | 3.7 | 0.3 | 2.3 | 8.3 | 3.3 | 27.0 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (2%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.3 (100%) | 0.3 (14%) | 2.7 (32%) | 1.3 (40%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.3 (28%) | 0.7 (20%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.0 (0%) | 0.3 (14%) | 1.3 (16%) | 0.3 (10%) | 0.0 (0%) |
| GONE: slain | 0.7 (18%) | 0.0 (0%) | 0.0 (0%) | 2.0 (24%) | 0.0 (0%) | 3.7 (14%) |
| STUPIDITY: Stupidity | 0.3 (9%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.0 (30%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.7 (73%) | 0.0 (0%) | 1.7 (71%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 22.7 (84%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.0 a game | 3.7 a game | 1.8 a game |
| stood (cast and not dispelled) | - | 73% (8 of 11) | 73% (8 of 11) |
| the unit moved after it | - | 38% (3 of 8) | 38% (3 of 8) |
| it charged on its next turn | - | 0% (0 of 8) | 0% (0 of 8) |
| the enemy charged it first | - | 0% (0 of 8) | 0% (0 of 8) |
| it fought by the end of its next turn | - | 0% (0 of 8) | 0% (0 of 8) |
| it moved out of a charge the enemy had planned (not charged first) | - | 0% (0 of 8) | 0% (0 of 8) |
| none of these (no charge, no fight, no charge escaped) | - | 100% (8 of 8) | 100% (8 of 8) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 78% (75 of 96) | 67% (16 of 24) | 76% (91 of 120) |
|   cavalry | 95% (18 of 19) | - | 95% (18 of 19) |
|   chariot | 73% (8 of 11) | 71% (10 of 14) | 72% (18 of 25) |
|   infantry | 73% (8 of 11) | 43% (3 of 7) | 61% (11 of 18) |
|   war machine | 75% (41 of 55) | 100% (3 of 3) | 76% (44 of 58) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 0.7 (10%) | 0.3 (12%) | 1.0 (10%) |
| IN COMBAT: it fought this turn or the last | 0.7 (10%) | 0.7 (25%) | 1.3 (14%) |
| MOVED: a war machine that moved | 0.3 (5%) | 0.0 (0%) | 0.3 (3%) |
| NO TARGET IN RANGE | 0.7 (10%) | 1.3 (50%) | 2.0 (21%) |
| ONLY IN COMBAT: the only targets were in combat | 1.7 (24%) | 0.3 (12%) | 2.0 (21%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 2.3 (33%) | 0.0 (0%) | 2.3 (24%) |
| SHELTERED: the target was sheltered | 0.3 (5%) | 0.0 (0%) | 0.3 (3%) |
| OTHER BAR | 0.3 (5%) | 0.0 (0%) | 0.3 (3%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 13.0 | 4.3 | 77% | 7.9 pts | 103 pts |
| chariot | 6.3 | 0.3 | 95% | 0.2 pts | 1 pts |
| infantry | 3.7 | 0.3 | 91% | 2.6 pts | 10 pts |
| war machine | 15.0 | 18.0 | 56% | 47.6 pts | 713 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 1.3 | 3.0 | 2.2 |
| Charges that made contact a game | 1.3 | 1.7 | 1.5 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.00 declared, 1.00 contact (1 units) | 0.40 declared, 0.40 contact (5 units) | 0.50 declared, 0.50 contact (6 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 0.00 declared, 0.00 contact (2 units) | 0.00 declared, 0.00 contact (2 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.14 declared, 0.14 contact (22 units) | 0.32 declared, 0.14 contact (22 units) | 0.23 declared, 0.14 contact (44 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 56% (5 of 9) | 0% (0 of 3) | 100% (1 of 1) | 46% (6 of 13) |
| Character in a unit | 100% (8 of 8) | - | - | 100% (8 of 8) |
| Character on its own | 67% (2 of 3) | 0% (0 of 2) | 75% (3 of 4) | 56% (5 of 9) |
| Chariot | 67% (2 of 3) | 100% (2 of 2) | - | 80% (4 of 5) |
| Infantry | 67% (2 of 3) | 100% (1 of 1) | 50% (1 of 2) | 67% (4 of 6) |
| Monster | - | 0% (0 of 1) | - | 0% (0 of 1) |
| War Machines | 69% (9 of 13) | - | - | 69% (9 of 13) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Empire of Man | 3 | 33% (1 of 3); on the table 67% | 50% (3 of 6) | 74% | 67% (20 of 30) | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game | 67% (2 of 3); 0.7 uses a game |
| Grand Cathay | 1 | - | 42% (10 of 24) | 73% | 40% (4 of 10) | 50% (1 of 2); 5.0 uses a game | 0% (0 of 1); 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Skaven | 1 | 0% (0 of 1); on the table 100% | 17% (1 of 6) | 46% | 78% (7 of 9) | 100% (1 of 1); 1.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Vampire Counts | 1 | 100% (3 of 3); on the table 100% | 50% (3 of 6) | 88% | 83% (5 of 6) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (csame-bb45c30-p41, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 0% (0) | 67% (2) | 33% (2) |
| ...free all their last turn and able to turn (per game) | 0.00 | 0.67 | 0.67 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.33 | 0.33 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.33 | 0.33 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: csame-bb45c30-p41

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.0 | 3.7 |
| Strategy | Charge objectives carried out (made contact) | 75% (3 of 4) | 62% (5 of 8) |
| Strategy | Shoot objectives carried out (shot that target) | 26% (14 of 54) | 22% (2 of 9) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | - | 100% (2 of 2) |
| Strategy | Hexes on a unit its side charged or shot that turn | 50% (2 of 4) | - |
| Strategy | Joined characters whose unit fought | 0% (0 of 7) | 0% (0 of 3) |
| Strategy | Lone characters that fought | 29% (2 of 7) | 40% (4 of 10) |
| Movement | Charges halted short of contact | 0.0 | 0.3 |
| Movement | Idle units | 2.0 | 3.7 |
| Movement | Points that never moved of their own | 480.3 | 266.7 |
| Movement | Fights charged into per game | 1.3 | 1.7 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 4 | 1 of 5, net +130 |
| Movement | Charges with odds: sweet spot (55-75%) | 1 of 4, net -281 | 1 of 5, net +164 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 1 of 4, net +0 | 0 of 5 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 of 4, net +8 | 0 of 5 |
| Shooting | Shots by shooting units (incl. breath weapons) | 12.3 | 4.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 41% (15 of 37) | 77% (10 of 13) |
| Shooting | Points destroyed by shooting units | 334.3 | 0.0 |
| Shooting | War machine shots | 13.7 | 1.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 44% (18 of 41) | 0% (0 of 4) |
| Shooting | Points destroyed by war machines | 318.3 | 43.3 |
| Magic | Magic missiles cast | 1.0 | 3.0 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 67% (2 of 3) | 78% (7 of 9) |
| Magic | Wounds caused by magic missiles | 1.0 | 4.7 |
| Magic | Wounds caused by other spells | 1.7 | 3.0 |
| Magic | Points destroyed by magic (all spells) | 63.3 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.7 / 1.3 / 0.3 / 0.0 | 3.3 / 0.0 / 0.7 / 0.3 |
| Combat | Points destroyed in combat | 0.0 | 250.0 |
| Combat | Points run down | 0.0 | 25.7 |
| Combat | Net points per charged fight, damage counted | -52 | +145 |
| Combat | Net per 100 charger points, damage counted | -22.1 | +88.8 |
| Combat | First round won (charged fights) | 100% | 80% |
| Combat | Net points per charged fight | -66 | +118 |
| Combat | Net points per supported fight / lone fight | - / -66 | - / +118 |
| Combat | Charged fights on a top-3 enemy unit | 0 of 4 | 1 of 5 |
| Game | Points lost | 323.7 | 911.0 |
| Game | VP from objectives | 420.0 | 803.3 |
| Game | Lone holders (player turns) | 1.5 | 9.5 |

- Mine won / drew / lost: 1 / 0 / 2 of 3 ended games (of 3); mean margin (Mine - Opponent) +139 VP
- The side that went first won 1 of 3 games with a winner
- Points traded per game (both sides' losses): 1235
- Games not ended: 0; findings 1, warnings 0

### Opponent rules: csame-bb45c30-p41

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.3 | +19.1 | 0.0 | 71.3 | - | - | - | - |
| ARMY TABLE | 14.0 | +91.2 | 0.0 | 106.0 | 16.3 | +812.8 | 0.0 | 456.7 |
| ARTILLERY RE-ROLL WEIGHED | 4.7 | +0.0 | 0.0 | 41.7 | 0.3 | +0.0 | 0.0 | 55.0 |
| CANNON PLAN MISSED | 0.7 | +0.0 | 180.0 | 0.0 | 0.3 | +0.0 | 43.3 | 55.0 |
| CANNON PLANNED TARGET | 13.7 | +790.1 | 1062.7 | 85.0 | 1.0 | +107.3 | 86.7 | 165.0 |
| CANNON SIGHT KEPT | 2.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 55.0 |
| CARRIES OUT SET-UP | - | - | - | - | 0.3 | -0.3 | 0.0 | 0.0 |
| CAST JOB | - | - | - | - | 2.3 | +65.8 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | - | - | - | - | 2.3 | +0.0 | 0.0 | 123.0 |
| CASTS FROM BEHIND | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.3 | +10.7 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | - | - | - | - | 1.7 | +47.9 | 0.0 | 36.3 |
| CHAFF PASSED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHARACTER GUNS | - | - | - | - | 2.7 | +0.0 | 0.0 | 296.0 |
| CHARGE LOSSES | 11.3 | -268.9 | 0.0 | 51.3 | 18.3 | -1544.9 | 0.0 | 1059.0 |
| CHARGE NOT DECLARED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CHARGE NOW FIRST | 1.0 | +0.0 | 48.3 | 93.7 | 1.3 | +0.0 | 139.7 | 68.3 |
| CLOSES ON WHAT IT BEATS | 4.0 | +0.0 | 0.0 | 0.0 | 14.3 | +0.0 | 0.0 | 167.3 |
| COMBAT PIVOT | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 48.3 |
| CONVEYANCE SEARCH | - | - | - | - | 4.0 | +665.8 | 369.0 | 246.0 |
| COVER ONCE | 6.7 | -603.1 | 0.0 | 43.3 | 7.0 | -527.3 | 0.0 | 104.7 |
| DEFENSIVE ARMY | 0.7 | +0.0 | 360.0 | 0.0 | - | - | - | - |
| DENIED BY THE FIGHT | 0.7 | -1.7 | 0.0 | 0.0 | 1.3 | -13.8 | 96.3 | 68.3 |
| DEPLOY BY FIGURES | 7.0 | -106.9 | 0.0 | 0.0 | 7.3 | -20.3 | 0.0 | 55.0 |
| DUEL STOPS AT THE KILL | - | - | - | - | 0.7 | -4.9 | 71.3 | 0.0 |
| EXACT ROUND | 0.7 | +0.3 | 79.0 | 93.7 | 2.0 | -6.2 | 139.7 | 68.3 |
| FALL BACK GOOD ORDER | 1.3 | +114.7 | 79.0 | 93.7 | 2.7 | +0.9 | 139.7 | 68.3 |
| FALLS SHORT | - | - | - | - | 23.0 | +354.2 | 0.0 | 759.7 |
| FEATURE BUFFS | 0.3 | +10.2 | 0.0 | 54.7 | 1.7 | +21.8 | 0.0 | 0.0 |
| FIGHT TO THE END | 0.7 | -0.3 | 48.3 | 93.7 | 0.3 | +46.3 | 0.0 | 0.0 |
| FIVE ACTION | 95.7 | +7472.2 | 4696.7 | 747.7 | 90.7 | +4243.0 | 527.0 | 2360.0 |
| FLANK NOT WEIGHED | 5.3 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 52.3 |
| FOLLOW UP WEIGHED | 1.0 | +145.9 | 0.0 | 93.7 | 0.7 | +129.7 | 0.0 | 0.0 |
| FOUR ROUNDS | 1.3 | +161.8 | 79.0 | 93.7 | 3.0 | +201.0 | 211.0 | 68.3 |
| FREED FROM HIS FIGHT | 2.3 | +0.0 | 0.0 | 0.0 | 5.7 | +0.0 | 0.0 | 144.0 |
| FRIEND SHOOTS FIRST | 0.3 | -2.9 | 0.0 | 0.0 | - | - | - | - |
| GIVES UP | - | - | - | - | 0.7 | -10.9 | 71.3 | 0.0 |
| GOAL WALK | 7.7 | +418.2 | 0.0 | 0.0 | 15.7 | +1228.7 | 0.0 | 0.0 |
| GUN FIGURES | 2.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.6 | 0.0 | 65.0 |
| GUN MASK | 0.7 | +0.0 | 0.0 | 54.7 | - | - | - | - |
| HARD STAY DROPPED | 2.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HE REFORMS ONCE FREED | - | - | - | - | 2.7 | +0.0 | 0.0 | 74.0 |
| HIS CHARGE BY HIS RUN | 5.3 | +0.0 | 0.0 | 0.0 | 7.3 | +0.0 | 0.0 | 404.7 |
| HIS CHARGE DENIED | 0.7 | +27.8 | 0.0 | 0.0 | - | - | - | - |
| HIS CHARGE LIST | 3.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 148.3 |
| HIS LEGAL MOVES | 2.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 4.3 | -44.0 | 0.0 | 0.0 | 4.0 | -208.9 | 0.0 | 364.3 |
| HIS MOVE AS HE DECIDES | - | - | - | - | 30.3 | +10.3 | 342.3 | 0.0 |
| HIS MOVE WHY | 10.0 | +0.0 | 0.0 | 54.7 | - | - | - | - |
| HIS ONE MOVE | - | - | - | - | 25.3 | -271.0 | 0.0 | 0.0 |
| HIS ONE QUARTER | - | - | - | - | 4.7 | +0.0 | 0.0 | 96.0 |
| HIS OWN BEST MOVE | 3.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVE | 11.7 | +0.0 | 0.0 | 51.3 | - | - | - | - |
| HIS RANDOM MOVER COMES | 3.3 | +0.0 | 0.0 | 51.3 | - | - | - | - |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 34.7 | +928.3 | 0.0 | 164.0 | 61.7 | +5177.4 | 0.0 | 1940.0 |
| HIS SHOTS BY HIS RUN | 21.7 | +511.6 | 0.0 | 122.7 | 46.0 | +1613.1 | 0.0 | 1705.3 |
| HIS TURN DENIED | - | - | - | - | 2.7 | +137.8 | 211.0 | 68.3 |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 12.7 | +0.0 | 0.0 | 270.0 | 20.0 | +0.0 | 0.0 | 61.3 |
| HOLDER ASSIGNMENT | 8.0 | +779.6 | 0.0 | 135.0 | 12.3 | +1007.8 | 0.0 | 30.7 |
| HOLDS AMBUSHERS | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 1.3 | -32.7 | 79.0 | 93.7 | 2.3 | -72.1 | 211.0 | 68.3 |
| HUNT IN PAIRS | - | - | - | - | 0.7 | +26.1 | 0.0 | 0.0 |
| IDLE COST | - | - | - | - | 17.0 | -184.6 | 0.0 | 445.3 |
| KEEP FALLS | 0.3 | +4.8 | 0.0 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 2.7 | +0.0 | 0.0 | 51.3 | - | - | - | - |
| LANE BY FIGURES | 0.3 | +1.4 | 0.0 | 0.0 | 1.0 | +51.5 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 4.0 | +0.0 | 70.0 | 446.0 | 4.0 | +0.0 | 0.0 | 180.0 |
| LONE WIZARD KEPT IN | 0.7 | +46.6 | 0.0 | 0.0 | 0.3 | +58.3 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | 1.0 | +0.1 | 79.0 | 93.7 | 1.7 | +2.6 | 139.7 | 68.3 |
| MANOEUVRE | 2.3 | -7.8 | 0.0 | 0.0 | 1.0 | -7.5 | 0.0 | 30.7 |
| MARCH BY THE SUM | 0.3 | +0.8 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | - | - | - | - | 0.7 | +34.3 | 0.0 | 0.0 |
| MARCH OF THE TABLE | - | - | - | - | 1.0 | +56.4 | 0.0 | 68.3 |
| MARCH OVER CASTS | 0.3 | -121.7 | 0.0 | 0.0 | 0.3 | +120.5 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MAX FOR POSITIONING | 1.3 | +41.6 | 0.0 | 0.0 | 2.0 | +42.3 | 0.0 | 248.3 |
| MEETS IN TIME | 4.0 | +342.3 | 0.0 | 0.0 | 4.3 | +157.8 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 1.0 | +87.5 | 0.0 | 0.0 | 5.0 | +69.4 | 0.0 | 328.0 |
| MISSILES NEXT TURN | 1.3 | +55.0 | 0.0 | 0.0 | 9.3 | +122.0 | 0.0 | 519.3 |
| MOVE ORDER | 0.7 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 104.7 | 74.0 |
| MOVE SPELL SPOT | - | - | - | - | 2.0 | +0.0 | 0.0 | 246.0 |
| MOVE TO CHARGE COMPUTED | 3.0 | +289.6 | 0.0 | 0.0 | 3.3 | +486.0 | 0.0 | 136.7 |
| NEARER NOT NEEDED | 8.0 | +302.1 | 0.0 | 126.0 | 8.3 | +404.7 | 0.0 | 104.7 |
| NEXT CHARGE BY LIST | 0.7 | +100.2 | 0.0 | 0.0 | 2.7 | +377.6 | 0.0 | 136.7 |
| NO DOUBLE ROUNDS | 1.3 | -66.1 | 79.0 | 93.7 | 3.0 | -100.0 | 211.0 | 68.3 |
| NO LATE CUT | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 1.3 | -1.3 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 3.7 | -323.8 | 0.0 | 0.0 | 2.7 | -169.2 | 0.0 | 55.0 |
| OGRE LOADER SECOND SHOT | - | - | - | - | 0.3 | +36.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 2.7 | -56.5 | 0.0 | 0.0 | 3.3 | -75.2 | 0.0 | 248.3 |
| ONE OBJECTIVE FORMULA | 3.0 | +32.7 | 0.0 | 109.3 | 8.3 | -110.7 | 0.0 | 30.7 |
| ONE ROUTE | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| OPENS UP | 0.3 | +67.5 | 0.0 | 0.0 | - | - | - | - |
| OVERRUNS AWAY | 0.7 | +14.1 | 30.7 | 0.0 | 0.3 | +58.3 | 0.0 | 0.0 |
| PATHS CROSS | - | - | - | - | 0.7 | +2.1 | 0.0 | 0.0 |
| PERIAPT WORTH | - | - | - | - | 0.3 | +24.8 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | - | - | - | - | 0.3 | -28.6 | 0.0 | 0.0 |
| PLAN RESULT | 41.7 | +1591.8 | 1849.7 | 470.7 | 44.7 | +369.6 | 43.3 | 1408.3 |
| PROMISE BY ITS OWN SUM | 7.0 | -242.7 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | 0.3 | -2.9 | 0.0 | 0.0 | 0.3 | -28.2 | 0.0 | 0.0 |
| PROMISE SHOT AWAY | 0.3 | -0.3 | 0.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | 19.7 | +1633.2 | 591.3 | 138.0 | 16.3 | +1501.4 | 43.3 | 144.3 |
| RANDOM MOVE BY FIGURES | - | - | - | - | 3.3 | +18.7 | 0.0 | 285.0 |
| REAL GROUND | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| REDIRECT COUNTER | 0.3 | +16.5 | 0.0 | 0.0 | 0.3 | +20.2 | 0.0 | 0.0 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| REFORMS TO MEET IT | 0.7 | -7.3 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | 1.3 | +20.0 | 79.0 | 93.7 | 3.0 | -34.2 | 211.0 | 68.3 |
| ROUNDS AFTER TERROR | 0.3 | -2.0 | 0.0 | 0.0 | 1.0 | -15.4 | 98.0 | 0.0 |
| RUN DOWN | 1.3 | -4.4 | 79.0 | 93.7 | 2.7 | -26.9 | 211.0 | 68.3 |
| SAFER THAN THE JOB | - | - | - | - | 0.3 | +7.2 | 0.0 | 0.0 |
| SCOUT SPOT | 0.7 | +4.7 | 0.0 | 0.0 | - | - | - | - |
| SCOUT WAITS | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 1.7 | -112.1 | 0.0 | 55.0 |
| SET CREDITED ONCE | - | - | - | - | 1.3 | -6.0 | 0.0 | 0.0 |
| SET UP BY THE SET | - | - | - | - | 2.0 | -15.4 | 0.0 | 30.7 |
| SET-UP MISSED | - | - | - | - | 0.7 | +70.9 | 68.3 | 0.0 |
| SHOOTERS ON THE TABLE | 19.7 | +0.0 | 0.0 | 211.0 | 2.7 | +0.0 | 0.0 | 165.0 |
| SHOOTS FROM THE BEST SPOT | 1.3 | +124.4 | 369.0 | 0.0 | 1.3 | +23.0 | 142.7 | 0.0 |
| SHORT GUN FORWARD | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SHOT OR CHARGE | - | - | - | - | 0.3 | -0.4 | 71.3 | 0.0 |
| SHOT REPLANNED | - | - | - | - | 0.3 | +0.0 | 43.3 | 55.0 |
| SHOT RISK POINTS | 15.7 | +174.5 | 0.0 | 97.0 | 38.7 | +284.6 | 0.0 | 1622.7 |
| SHOTS AFTER THE MOVES | 6.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 24.0 | +2104.6 | 0.0 | 236.7 | 5.0 | +190.7 | 0.0 | 378.0 |
| SPELL WORTH | 0.7 | +1.9 | 0.0 | 0.0 | 5.0 | +79.5 | 360.0 | 360.0 |
| SPELLS IN THE FIGHT | 0.3 | +7.6 | 48.3 | 93.7 | - | - | - | - |
| SPOT AS THE GAME MOVES | 4.0 | +0.0 | 0.0 | 0.0 | 9.0 | +0.0 | 0.0 | 366.7 |
| STAND AND SHOOT | - | - | - | - | 0.7 | -22.3 | 71.3 | 0.0 |
| STANDS FOR A REASON | - | - | - | - | 2.3 | +0.0 | 142.7 | 0.0 |
| STANDS STILL | 66.7 | +0.0 | 4617.7 | 438.7 | 23.0 | +0.0 | 316.0 | 683.0 |
| STAY WORTH | 40.3 | +1286.6 | 3358.7 | 80.3 | 5.7 | +80.6 | 173.3 | 560.0 |
| STUCK PIVOT | - | - | - | - | 0.7 | +0.0 | 0.0 | 48.3 |
| SUPPORT ADDS | 2.7 | +168.7 | 0.0 | 54.7 | 1.3 | +47.9 | 0.0 | 0.0 |
| SUPPORT WORKED OUT | 2.7 | +168.7 | 0.0 | 54.7 | 1.3 | +47.9 | 0.0 | 0.0 |
| SURE REACH TOGETHER | 0.3 | +5.7 | 0.0 | 0.0 | - | - | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 1.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| THE PROMISE ADDS | - | - | - | - | 0.3 | -28.2 | 0.0 | 0.0 |
| THE PROMISED MOVE | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE ROW IN ITS ORDER | 3.7 | +0.0 | 0.0 | 0.0 | 4.7 | +0.0 | 0.0 | 52.3 |
| THE ROW KEEPS ITS WAY | 0.7 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 0.3 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 42.7 | +0.0 | 0.0 | 291.3 | 44.0 | +0.0 | 0.0 | 1003.3 |
| TIED UP BY THE SUM | 1.0 | +104.3 | 30.7 | 0.0 | 0.3 | +21.8 | 54.7 | 0.0 |
| TIME ON OUR SIDE | 45.3 | +514.9 | 0.0 | 180.7 | - | - | - | - |
| WAITS AGAIN | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| WHO FIGHTS | - | - | - | - | 1.3 | +27.1 | 54.7 | 0.0 |
| WHO HITS BACK | - | - | - | - | 0.3 | +2.3 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | 4.0 | -177.1 | 0.0 | 51.3 | 1.0 | -58.7 | 0.0 | 0.0 |
| WOUNDS ON THE RANKS | 2.7 | +22.0 | 0.0 | 0.0 | 3.0 | +103.6 | 0.0 | 148.0 |

### Rule changes: csame-bb45c30-p41

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS SHOT LIST | 289 | 282 | 69 | 23.00 | +2692 | +39.0 |
| ARMY TABLE | 91 | 91 | 62 | 20.67 | +2449 | +39.5 |
| HIS MOVE AS HE DECIDES | 91 | 91 | 60 | 20.00 | +0 | +0.0 |
| HOLDER ASSIGNMENT | 61 | 61 | 56 | 18.67 | +5157 | +92.1 |
| HIS SHOTS BY HIS RUN | 203 | 199 | 46 | 15.33 | +916 | +19.9 |
| SHOT RISK POINTS | 163 | 157 | 42 | 14.00 | +1696 | +40.4 |
| TIME ON OUR SIDE | 136 | 124 | 31 | 10.33 | +104 | +3.4 |
| DEPLOY BY FIGURES | 43 | 43 | 25 | 8.33 | +379 | +15.2 |
| LEGAL CHARGES ONLY | 24 | 24 | 24 | 8.00 | +0 | +0.0 |
| THE TABLE AGAIN | 36 | 36 | 24 | 8.00 | +0 | +0.0 |
| FIVE ACTION | 559 | 548 | 22 | 7.33 | +1396 | +63.5 |
| GOAL WALK | 70 | 69 | 22 | 7.33 | +901 | +41.0 |
| HIS ONE MOVE | 76 | 76 | 22 | 7.33 | +0 | +0.0 |
| OFF BEST | 19 | 19 | 19 | 6.33 | -1479 | -77.8 |
| QUARTER ODDS | 108 | 102 | 16 | 5.33 | +1636 | +102.2 |
| ARTILLERY RE-ROLL WEIGHED | 15 | 15 | 15 | 5.00 | +0 | +0.0 |
| MOVE TO CHARGE COMPUTED | 19 | 18 | 14 | 4.67 | +638 | +45.6 |
| IDLE COST | 51 | 42 | 12 | 4.00 | +60 | +5.0 |
| MEETS IN TIME | 25 | 25 | 12 | 4.00 | +880 | +73.3 |
| MOVE ORDER | 11 | 11 | 11 | 3.67 | +0 | +0.0 |
| CANNON SIGHT KEPT | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| CHARGE LOSSES | 89 | 85 | 9 | 3.00 | +648 | +72.0 |
| FOUR ROUNDS | 13 | 12 | 8 | 2.67 | +315 | +39.4 |
| HIS MOVE WHY | 30 | 30 | 8 | 2.67 | +0 | +0.0 |
| PROMISE BY ITS OWN SUM | 32 | 32 | 8 | 2.67 | -728 | -91.0 |
| ADVANCE LANE KEPT | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| HARD STAY DROPPED | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| NEXT CHARGE BY LIST | 10 | 10 | 6 | 2.00 | +360 | +60.0 |
| CAST JOB | 7 | 7 | 5 | 1.67 | +118 | +23.5 |
| FOLLOW UP WEIGHED | 5 | 5 | 5 | 1.67 | +827 | +165.3 |
| SHOOTS FROM THE BEST SPOT | 8 | 8 | 5 | 1.67 | +75 | +15.0 |
| SUPPORT ADDS | 12 | 12 | 5 | 1.67 | +41 | +8.3 |
| SUPPORT WORKED OUT | 12 | 12 | 5 | 1.67 | +41 | +8.3 |
| COMBAT PIVOT | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| LANE BY FIGURES | 4 | 4 | 4 | 1.33 | +159 | +39.7 |
| MAX FOR POSITIONING | 10 | 10 | 4 | 1.33 | +11 | +2.6 |
| RANDOM MOVE BY FIGURES | 10 | 10 | 4 | 1.33 | +56 | +14.0 |
| SHOTS IN THE MOVE | 87 | 67 | 4 | 1.33 | +122 | +30.6 |
| TIED UP BY THE SUM | 4 | 4 | 4 | 1.33 | +192 | +48.1 |
| CHARGE NOW FIRST | 7 | 7 | 3 | 1.00 | -186 | -62.0 |
| HOLDS AMBUSHERS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| LONE WIZARD KEPT IN | 3 | 3 | 3 | 1.00 | +315 | +104.9 |
| MARCH OF THE TABLE | 3 | 3 | 3 | 1.00 | -169 | -56.4 |
| REDIRECT FOR A FRIEND IN REACH | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| RISK BY ARC | 13 | 12 | 3 | 1.00 | +51 | +17.1 |
| THE ROW IN ITS ORDER | 25 | 3 | 3 | 1.00 | +0 | +0.0 |
| CANNON PLANNED TARGET | 44 | 44 | 2 | 0.67 | +78 | +39.2 |
| CASTS FROM BEHIND | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| CHAFF IN THE MOVE | 5 | 4 | 2 | 0.67 | +15 | +7.3 |
| FALL BACK GOOD ORDER | 12 | 11 | 2 | 0.67 | +90 | +45.2 |
| MARCH CHECK | 2 | 2 | 2 | 0.67 | +62 | +31.0 |
| NEARER NOT NEEDED | 49 | 48 | 2 | 0.67 | +72 | +35.9 |
| PATHS CROSS | 2 | 2 | 2 | 0.67 | +6 | +3.1 |
| SCOUT WAITS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| SHORT GUN FORWARD | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| STUCK PIVOT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| AFTERMATH IN POINTS | 1 | 1 | 1 | 0.33 | +58 | +57.5 |
| CARRIES OUT SET-UP | 1 | 1 | 1 | 0.33 | -1 | -0.9 |
| CHAFF PASSED | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CHARGE NOT DECLARED | 1 | 1 | 1 | 0.33 | -207 | -207.2 |
| COVER ONCE | 41 | 29 | 1 | 0.33 | +3 | +2.6 |
| FALLS SHORT | 69 | 53 | 1 | 0.33 | +0 | +0.0 |
| FIGHT TO THE END | 3 | 3 | 1 | 0.33 | +95 | +95.4 |
| HIS CHARGE DENIED | 2 | 2 | 1 | 0.33 | +65 | +65.2 |
| HIS TURN DENIED | 8 | 8 | 1 | 0.33 | +41 | +41.1 |
| HUNT IN PAIRS | 2 | 2 | 1 | 0.33 | +25 | +25.0 |
| KEEP FALLS | 1 | 1 | 1 | 0.33 | +47 | +46.7 |
| MARCH BY THE SUM | 1 | 1 | 1 | 0.33 | +2 | +2.3 |
| NO DOUBLE ROUNDS | 13 | 12 | 1 | 0.33 | +15 | +14.7 |
| OGRE LOADER SECOND SHOT | 1 | 1 | 1 | 0.33 | +108 | +108.0 |
| ONE FIGHT FORMULA | 18 | 11 | 1 | 0.33 | +99 | +98.8 |
| ONE OBJECTIVE FORMULA | 34 | 25 | 1 | 0.33 | +179 | +179.3 |
| OPENS UP | 1 | 1 | 1 | 0.33 | +65 | +65.2 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.33 | +74 | +74.4 |
| PIVOT GUARDS FLANK | 1 | 1 | 1 | 0.33 | -86 | -85.7 |
| PROMISE SHOT AWAY | 1 | 1 | 1 | 0.33 | -1 | -0.9 |
| SAFER THAN THE JOB | 1 | 1 | 1 | 0.33 | +22 | +21.7 |
| SHOT REPLANNED | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| SHOTS AFTER THE MOVES | 21 | 21 | 1 | 0.33 | +0 | +0.0 |
| SPELLS IN THE FIGHT | 1 | 1 | 1 | 0.33 | +5 | +5.4 |
| STAY WORTH | 138 | 128 | 1 | 0.33 | +9 | +8.8 |
| SURE REACH TOGETHER | 1 | 1 | 1 | 0.33 | +17 | +16.6 |
| WHO HITS BACK | 1 | 1 | 1 | 0.33 | +7 | +6.9 |
| WHOLE FIGHT DANGER | 15 | 15 | 1 | 0.33 | +10 | +9.6 |
| WOUNDS ON THE RANKS | 17 | 17 | 1 | 0.33 | +74 | +74.5 |
| CANNON PLAN MISSED | 3 | 3 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 7 | trace | - | - | - | - |
| CATCH FLIERS | 1 | not checked | - | - | - | - |
| CHARACTER GUNS | 8 | 8 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 55 | 55 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 12 | not checked | - | - | - | - |
| DEFENSIVE ARMY | 2 | 2 | 0 | 0.00 | - | - |
| DENIED BY THE FIGHT | 6 | 6 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 2 | 2 | 0 | 0.00 | - | - |
| EXACT ROUND | 8 | 7 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 6 | 6 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 28 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 24 | 24 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 1 | 1 | 0 | 0.00 | - | - |
| GIVES UP | 2 | 2 | 0 | 0.00 | - | - |
| GUN FIGURES | 11 | not checked | - | - | - | - |
| GUN MASK | 2 | 2 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 8 | 8 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 38 | 35 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 15 | 15 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 12 | 11 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 25 | 24 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 14 | 13 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 14 | 12 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 35 | 33 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 10 | 10 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN RUN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 98 | 98 | 0 | 0.00 | - | - |
| HONEST WORTH | 11 | 10 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 8 | 8 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 8 | 8 | 0 | 0.00 | - | - |
| MANOEUVRE | 10 | 10 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 2 | 2 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 4 | 4 | 0 | 0.00 | - | - |
| MISSILES IN THE MOVE | 18 | 12 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 32 | 24 | 0 | 0.00 | - | - |
| MOVE SPELL SPOT | 6 | not checked | - | - | - | - |
| NO LATE CUT | 3 | 3 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 18 | 18 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 4 | not checked | - | - | - | - |
| ONE ROUTE | 4 | 4 | 0 | 0.00 | - | - |
| OVERRUNS AWAY | 3 | 3 | 0 | 0.00 | - | - |
| PLAN RESULT | 259 | trace | - | - | - | - |
| PROMISE READS THE TABLE | 2 | 2 | 0 | 0.00 | - | - |
| REAL GROUND | 4 | 4 | 0 | 0.00 | - | - |
| REDIRECT COUNTER | 2 | 2 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 2 | 1 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 4 | 4 | 0 | 0.00 | - | - |
| RUN DOWN | 12 | 11 | 0 | 0.00 | - | - |
| SCOUT SPOT | 2 | 2 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 5 | 5 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 4 | 4 | 0 | 0.00 | - | - |
| SET UP BY THE SET | 6 | 6 | 0 | 0.00 | - | - |
| SET-UP MISSED | 2 | trace | - | - | - | - |
| SHOOTERS ON THE TABLE | 67 | not checked | - | - | - | - |
| SHOT OR CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| SPELL WORTH | 17 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 39 | 36 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 2 | 2 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 7 | 7 | 0 | 0.00 | - | - |
| STANDS STILL | 269 | 262 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 6 | not checked | - | - | - | - |
| THE PROMISE ADDS | 1 | 1 | 0 | 0.00 | - | - |
| THE PROMISED MOVE | 3 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 14 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 8 | not checked | - | - | - | - |
| THE TABLE BINDS | 260 | not checked | - | - | - | - |
| WAITS AGAIN | 4 | 4 | 0 | 0.00 | - | - |
| WHO FIGHTS | 4 | 4 | 0 | 0.00 | - | - |

### Off best figure: csame-bb45c30-p41

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 3.67 | 1.67 | 83.1 |
| ARMY TABLE | rule | 3.33 | 0.33 | 47.1 |
| PROMISE BY ITS OWN SUM | rule | 2.67 | - | 91.0 |
| CHARGE NOW FIRST | rule | 0.67 | 0.33 | 62.0 |
| MARCH OF THE TABLE | rule | - | 1.00 | 56.4 |
| RULE SWITCHED OFF | gate | - | 1.00 | 50.0 |
| CARRIES OUT SET-UP | rule | - | 0.33 | 0.9 |
| CHARGE NOT DECLARED | rule | - | 0.33 | 207.2 |
| PIVOT GUARDS FLANK | rule | - | 0.33 | 85.7 |
| PROMISE SHOT AWAY | rule | 0.33 | - | 0.9 |

### Plans: csame-bb45c30-p41

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.3 | 50% | 210 | 74 | 35% |
| Mine | move | 25.7 | 96% | 1510 | 0 | 0% |
| Mine | shoot | 14.7 | 64% | 1988 | 1518 | 76% |
| Opponent | charge | 2.7 | 62% | 355 | 215 | 61% |
| Opponent | join | 1.7 | 100% | 43 | 0 | 0% |
| Opponent | move | 36.7 | 94% | 1837 | 0 | 0% |
| Opponent | shoot | 2.7 | 62% | 195 | 155 | 79% |
| Opponent | support | 1.0 | 67% | 6 | 0 | 0% |

### Battle groups: csame-bb45c30-p41

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 0.3 | 0% | - | - | - | - | - | - | - | - |
| Opponent | REDIRECT COUNTER | 0.3 | 100% | 0% | 0% | - | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: csame-bb45c30-p41

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 2 | 0 (2) | 0 | 0 | 0 | 100% | - | 0 (1) | - | 0 (1) | 0 (1) | 0 (1) |
| Mine | Character | 12 | 13 (12) | 13 | 0 | 19 | 83% | 1.0 | 0 (4) | 0 (4) | 24 (4) | 18 (7) | 0 (5) |
| Mine | Fast Hammer | 5 | 19 (5) | 6 | 13 | 0 | 60% | 1.5 | 6 (3) | 27 (1) | 38 (1) | 22 (3) | 14 (2) |
| Mine | Hammer | 4 | 28 (4) | 0 | 28 | 0 | 50% | 1.0 | 0 (1) | 40 (3) | - | 0 (3) | 97 (1) |
| Mine | Shooter | 5 | 29 (5) | 24 | 4 | 67 | 0% | 1.2 | 0 (1) | 0 (2) | 70 (2) | 29 (5) | - |
| Mine | War machine | 11 | 109 (11) | 109 | 0 | 27 | 18% | 1.1 | 10 (5) | 191 (6) | - | 0 (2) | 133 (9) |
| Mine | Wizard | 2 | 0 (2) | 0 | 0 | 0 | 50% | 3.0 | 0 (1) | 0 (1) | - | 0 (1) | 0 (1) |
| Opponent | Chaff | 5 | 0 (5) | 0 | 0 | 19 | 100% | - | 0 (3) | 0 (2) | - | 0 (5) | - |
| Opponent | Character | 11 | 19 (11) | 19 | 0 | 58 | 36% | 2.6 | 0 (3) | 21 (3) | 37 (3) | 28 (5) | 17 (4) |
| Opponent | Clean-up | 1 | 220 (1) | 0 | 220 | 100 | 0% | 3.0 | - | 220 (1) | - | 220 (1) | - |
| Opponent | Fast Hammer | 6 | 60 (6) | 13 | 47 | 0 | 50% | 1.3 | 45 (3) | 84 (3) | - | 88 (4) | 29 (2) |
| Opponent | Fragile | 2 | 0 (2) | 0 | 0 | 100 | 100% | - | - | 0 (1) | 0 (1) | - | 0 (2) |
| Opponent | Hammer | 4 | 79 (4) | 79 | 0 | 100 | 25% | 1.7 | 99 (2) | 134 (1) | 0 (1) | 114 (3) | 0 (1) |
| Opponent | Holder | 4 | 92 (4) | 0 | 92 | 19 | 75% | 2.0 | - | 0 (2) | 171 (2) | 92 (4) | - |
| Opponent | Shooter | 2 | 0 (2) | 0 | 0 | 100 | 0% | 2.5 | - | - | 0 (2) | 0 (1) | 0 (1) |
| Opponent | War machine | 2 | 39 (2) | 39 | 0 | 100 | 0% | 1.0 | - | 39 (2) | - | 79 (1) | 0 (1) |
| Opponent | Wizard | 2 | 0 (2) | 0 | 0 | 0 | 0% | 1.0 | 0 (2) | - | - | 0 (2) | - |

### Charged fights: csame-bb45c30-p41

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Empire of Man | 3 | 716 | 31 | 1.3 | 1.0 | 23 | 90 | -66 | 0 of 4 | 4 of 4 | - | -66 |
| Opponent | Grand Cathay | 1 | 130 | 339 | 2.0 | 1.0 | 170 | 0 | +170 | 0 of 2 | 1 of 2 | - | +170 |
| Opponent | Skaven | 1 | 0 | 0 | 1.0 | 1.0 | 0 | 41 | -41 | 0 of 1 | 1 of 1 | - | -41 |
| Opponent | Vampire Counts | 1 | 0 | 294 | 2.0 | 1.0 | 147 | 0 | +147 | 1 of 2 | 2 of 2 | - | +147 |
| **Opponent** | all armies | 3 | 43 | 211 | 1.7 | 1.0 | 127 | 8 | +118 | 1 of 5 | 4 of 5 | - | +118 |

### Effective charges: csame-bb45c30-p41

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Empire of Man | 4 | 0 | 0 | 1 (net -281) | 0 | 1 (net +0) | 2 (net +8) | 0 | 25% (1 of 4) |
| Opponent | Grand Cathay | 2 | 0 | 0 | 0 | 2 (net +170) | 0 | 0 | 0 | 0% (0 of 2) |
| Opponent | Skaven | 1 | 0 | 0 | 0 | 1 (net -41) | 0 | 0 | 0 | 0% (0 of 1) |
| Opponent | Vampire Counts | 2 | 1 (net +130) | 0 | 1 (net +164) | 0 | 0 | 0 | 0 | 50% (1 of 2) |

### Charged fights, damage counted: csame-bb45c30-p41

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Effective (55-75%) | 1 | 181 | 145 | -281 | 87 | 340 | -254 | -140.1 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 189 | 92 | +8 | 132 | 122 | +9 | +4.8 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 380 | 41 | +0 | 28 | 0 | +28 | +7.5 |
| Mine | All fights | 4 | 235 | 92 | -66 | 95 | 146 | -52 | -22.1 |
| Opponent | Long shot (under 50%) | 1 | 50 | 130 | +130 | 130 | 0 | +130 | +260.0 |
| Opponent | Effective (55-75%) | 1 | 186 | 265 | +164 | 296 | 0 | +296 | +159.4 |
| Opponent | 76-89% | 3 | 193 | 122 | +99 | 113 | 14 | +99 | +51.4 |
| Opponent | All fights | 5 | 163 | 152 | +118 | 153 | 8 | +145 | +88.8 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| csame-bb45c30-p41 | move | 13 | 4 (31%) | 3 (23%) | 2 (15%) | 7 (54%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L0827 |
| Invocation of Nehek | Opponent | L0827 |
| Periapt of Soul Exchange | Opponent | L0721 |
| Ring of Jet | Opponent | L0810 |
| Storm Daemon (Renegade 2.0) | Opponent | L0721 |
| Twice-Blessed Armour | Mine | L0721 |
| Twice-Blessed Armour | Opponent | L0810 |
| Witch Hunter's Ward | Mine | L0721, L0810, L0827 |

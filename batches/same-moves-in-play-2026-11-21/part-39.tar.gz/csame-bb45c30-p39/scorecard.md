# Doctrine scorecard: csame-bb45c30-p39

### Scorecard: csame-bb45c30-p39

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0409 | 1 | 1 | Mine | no | 11 | - | 1 | 3 | 0 | 0 | 0 | 0 |
| L0409 | 1 | 1 | Opponent | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 295 |
| L0425 | 5 | 1 | Mine | yes | - | 2 | 1 | 4 | 0 | 0 | 0 | 65 |
| L0425 | 5 | 1 | Opponent | no | - | 4 | 4 | 5 | 0 | 0 | 0 | 0 |
| L0512 | 2 | 1 | Mine | - | - | - | 0 | 2 | 0 | 0 | 0 | 503 |
| L0512 | 2 | 1 | Opponent | - | - | - | 0 | 2 | 0 | 0 | 0 | 165 |
| **Average** | | | Mine | 50% | 11.0 | 2.0 | 0.7 | 3.0 | 0.0 | 0.0 | 0.0 | 189.3 |
| **Average** | | | Opponent | 0% | 0.0 | 4.0 | 1.3 | 2.7 | 0.0 | 0.0 | 0.0 | 153.3 |

### KPIs: csame-bb45c30-p39

Rules off - Opponent only: NO OLD ONE-MOVE GUESS; both sides: ONE RUN A PLAN.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 10) | 0% (0 of 11) | 0% (0 of 21) |
| Winner chose to follow up after the loser gave ground |  | 67% (2 of 3); on the table 100% | - | 67% (2 of 3); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | - | 100% (1 of 1); on the table 100% | 100% (1 of 1); on the table 100% |
| Winner chose to pursue after the loser fled |  | 0% (0 of 1); on the table 0% | - | 0% (0 of 1); on the table 0% |
| Winner chose to follow up or pursue (all three) |  | 50% (2 of 4); on the table 75% | 100% (1 of 1); on the table 100% | 60% (3 of 5); on the table 80% |
| Magic missiles tried each own turn | 50%+ | 67% (8 of 12) | 31% (11 of 36) | 40% (19 of 48) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 73% (8 of 11) | 31% (11 of 35) | 41% (19 of 46) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | - | - |
| Points that never fought | lower | 84% (5059 of 5998) | 77% (4636 of 5998) | 81% (9695 of 11996) |
|   infantry points that never fought | lower | 92% (1304 of 1424) | 84% (998 of 1187) | 88% (2302 of 2611) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 74% (17 of 23) | 93% (25 of 27) | 84% (42 of 50) |
| Bound items with a magic missile used (at least once a game) |  | 0.0 uses a game | 33% (1 of 3); 1.7 uses a game | 33% (1 of 3); 0.8 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
|   their share of the points of units over 100 pts | lower | 73% (3720 of 5120) | 96% (5213 of 5442) | 85% (8933 of 10562) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 0.3 (25%) | 5.3 (64%) | 5.7 (59%) |
| MARCHED: its unit marched | 0.7 (50%) | 2.3 (28%) | 3.0 (31%) |
| IN COMBAT: engaged in combat | 0.3 (25%) | 0.3 (4%) | 0.7 (7%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.3 (4%) | 0.3 (3%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 7.0 | 1.0 | 2.0 | 6.3 | 0.7 | 0.0 |
| not cast | 3.0 | 5.0 | 4.0 | 9.7 | 1.3 | 20.0 |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 4.3 (87%) | 3.0 (75%) | 5.7 (59%) | 0.0 (0%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 3.0 (31%) | 0.3 (25%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.7 (13%) | 0.3 (8%) | 0.7 (7%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.3 (12%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.3 (8%) | 0.3 (3%) | 1.0 (75%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 3.0 (100%) | 0.0 (0%) | 0.3 (8%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 17.7 (88%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.3 a game | 1.7 a game | 1.0 a game |
| stood (cast and not dispelled) | 100% (1 of 1) | 80% (4 of 5) | 83% (5 of 6) |
| the unit moved after it | 0% (0 of 1) | 100% (4 of 4) | 80% (4 of 5) |
| it charged on its next turn | 0% (0 of 1) | 25% (1 of 4) | 20% (1 of 5) |
| the enemy charged it first | 0% (0 of 1) | 0% (0 of 4) | 0% (0 of 5) |
| it fought by the end of its next turn | 0% (0 of 1) | 0% (0 of 4) | 0% (0 of 5) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 1) | 0% (0 of 4) | 0% (0 of 5) |
| none of these (no charge, no fight, no charge escaped) | 100% (1 of 1) | 75% (3 of 4) | 80% (4 of 5) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 69% (70 of 102) | 63% (45 of 71) | 66% (115 of 173) |
|   cavalry | 58% (7 of 12) | - | 58% (7 of 12) |
|   character | 92% (22 of 24) | 100% (3 of 3) | 93% (25 of 27) |
|   chariot | 25% (6 of 24) | 100% (6 of 6) | 40% (12 of 30) |
|   infantry | 75% (9 of 12) | 50% (14 of 28) | 58% (23 of 40) |
|   monster | - | 67% (4 of 6) | 67% (4 of 6) |
|   war machine | 87% (26 of 30) | 64% (18 of 28) | 76% (44 of 58) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.3 (22%) | 1.3 (15%) | 3.7 (19%) |
| IN COMBAT: it fought this turn or the last | 0.0 (0%) | 0.3 (4%) | 0.3 (2%) |
| MOVED: a war machine that moved | 0.0 (0%) | 0.7 (8%) | 0.7 (3%) |
| NO TARGET IN RANGE | 5.3 (50%) | 2.7 (31%) | 8.0 (41%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 2.3 (22%) | 2.0 (23%) | 4.3 (22%) |
| SHELTERED: the target was sheltered | 0.0 (0%) | 1.3 (15%) | 1.3 (7%) |
| OTHER BAR | 0.7 (6%) | 0.3 (4%) | 1.0 (5%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 2.3 | 0.3 | 86% | 8.6 pts | 20 pts |
| character | 8.3 | 1.7 | 84% | 3.9 pts | 33 pts |
| chariot | 4.0 | 5.7 | 33% | 11.9 pts | 47 pts |
| infantry | 10.7 | 0.7 | 94% | 0.8 pts | 8 pts |
| monster | 2.7 | 0.7 | 75% | 9.1 pts | 24 pts |
| war machine | 14.7 | 10.0 | 68% | 20.3 pts | 297 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 1.0 | 1.3 | 1.2 |
| Charges that made contact a game | 0.7 | 0.3 | 0.5 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.50 declared, 0.50 contact (2 units) | 0.00 declared, 0.00 contact (3 units) | 0.20 declared, 0.20 contact (5 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 1.00 declared, 1.00 contact (1 units) | 1.00 declared, 1.00 contact (1 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.10 declared, 0.05 contact (21 units) | 0.17 declared, 0.00 contact (18 units) | 0.13 declared, 0.03 contact (39 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 75% (3 of 4) | 100% (2 of 2) | - | 83% (5 of 6) |
| Character in a unit | 100% (7 of 7) | 100% (2 of 2) | - | 100% (9 of 9) |
| Character on its own | - | 100% (5 of 5) | 75% (3 of 4) | 89% (8 of 9) |
| Chariot | - | 80% (4 of 5) | - | 80% (4 of 5) |
| Infantry | 75% (9 of 12) | 67% (2 of 3) | - | 73% (11 of 15) |
| Monstrous | - | 100% (1 of 1) | - | 100% (1 of 1) |
| War Machines | 80% (4 of 5) | - | - | 80% (4 of 5) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Chaos Dwarfs | 2 | 50% (2 of 4); on the table 75% | 67% (8 of 12) | 77% | 69% (11 of 16) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Dwarfen Mountain Holds | 1 | - | - | 100% | 86% (6 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 1 | - | 25% (3 of 12) | 82% | 83% (10 of 12) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Grand Cathay | 1 | - | 17% (3 of 18) | 100% | 100% (9 of 9) | 33% (1 of 3); 5.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Vampire Counts | 1 | 100% (1 of 1); on the table 100% | 83% (5 of 6) | 50% | 100% (6 of 6) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (csame-bb45c30-p39, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 100% (1) | 0% (0) | 50% (1) |
| ...free all their last turn and able to turn (per game) | 0.00 | 0.00 | 0.00 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.00 | 0.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.33 | 0.00 | 0.33 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.33 | 0.00 | 0.33 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.67 | 0.00 | 0.67 |

### Quality by phase: csame-bb45c30-p39

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.7 | 4.0 |
| Strategy | Charge objectives carried out (made contact) | 67% (2 of 3) | 33% (1 of 3) |
| Strategy | Shoot objectives carried out (shot that target) | 44% (20 of 45) | 52% (17 of 33) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | - | 100% (1 of 1) |
| Strategy | Joined characters whose unit fought | 0% (0 of 6) | 43% (3 of 7) |
| Strategy | Lone characters that fought | 40% (2 of 5) | 14% (1 of 7) |
| Movement | Charges halted short of contact | 0.3 | 1.0 |
| Movement | Idle units | 3.0 | 2.7 |
| Movement | Points that never moved of their own | 189.3 | 153.3 |
| Movement | Fights charged into per game | 0.7 | 0.3 |
| Movement | Charges with odds: long shots (under 50%) | 1 of 1, net +0 | 0 of 1 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 1 | 1 of 1, net +0 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 1 | 0 of 1 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 0 of 1 | 0 of 1 |
| Shooting | Shots by shooting units (incl. breath weapons) | 14.7 | 9.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 48% (21 of 44) | 52% (14 of 27) |
| Shooting | Points destroyed by shooting units | 15.0 | 0.0 |
| Shooting | War machine shots | 8.7 | 6.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 50% (13 of 26) | 39% (7 of 18) |
| Shooting | Points destroyed by war machines | 123.3 | 46.3 |
| Magic | Magic missiles cast | 1.3 | 2.0 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 75% (3 of 4) | 67% (4 of 6) |
| Magic | Wounds caused by magic missiles | 4.7 | 1.3 |
| Magic | Points destroyed by magic (all spells) | 84.7 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 2.0 / 0.0 / 0.0 / 0.0 | 2.3 / 0.0 / 0.0 / 0.3 |
| Combat | Points destroyed in combat | 0.0 | 0.0 |
| Combat | Points run down | 0.0 | 0.0 |
| Combat | Net points per charged fight, damage counted | +51 | -215 |
| Combat | Net per 100 charger points, damage counted | +17.0 | -44.7 |
| Combat | First round won (charged fights) | 50% | 0% |
| Combat | Net points per charged fight | +0 | +0 |
| Combat | Net points per supported fight / lone fight | - / +0 | - / +0 |
| Combat | Charged fights on a top-3 enemy unit | 1 of 2 | 1 of 1 |
| Game | Points lost | 46.3 | 280.7 |
| Game | VP from objectives | 790.0 | 296.7 |
| Game | Lone holders (player turns) | 11.0 | 0.0 |

- Mine won / drew / lost: 3 / 0 / 0 of 3 ended games (of 3); mean margin (Mine - Opponent) +791 VP
- The side that went first won 1 of 3 games with a winner
- Points traded per game (both sides' losses): 327
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: csame-bb45c30-p39

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.3 | +2.1 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | 16.3 | +71.4 | 0.0 | 0.0 | 19.7 | +86.4 | 0.0 | 98.3 |
| ARTILLERY RE-ROLL WEIGHED | 2.3 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 55.0 |
| BACKUP TARGETS | 0.7 | +6.7 | 0.0 | 0.0 | - | - | - | - |
| CANNON PLAN MISSED | 0.3 | +0.0 | 68.3 | 0.0 | - | - | - | - |
| CANNON PLANNED TARGET | 8.0 | +55.0 | 454.3 | 0.0 | 5.3 | +135.5 | 231.7 | 55.0 |
| CANNON SIGHT KEPT | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CAST JOB | 2.0 | +119.2 | 0.0 | 0.0 | 4.3 | +70.9 | 0.0 | 0.0 |
| CASTER AWAY FROM SCREEN | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 0.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | 1.0 | +18.7 | 0.0 | 0.0 | - | - | - | - |
| CHALLENGE BY POINTS | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHAMPION KNOWS CHALLENGE | 0.3 | -2.8 | 0.0 | 0.0 | - | - | - | - |
| CHARACTER GUNS | 1.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| CHARGE LOSSES | 13.7 | -363.5 | 0.0 | 185.3 | 12.7 | -476.9 | 0.0 | 205.0 |
| CHARGE NOW FIRST | 0.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 8.3 | +0.0 | 0.0 | 0.0 | 5.7 | +0.0 | 0.0 | 0.0 |
| COMBAT PIVOT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | 0.3 | +45.0 | 0.0 | 0.0 | 0.7 | +50.2 | 0.0 | 0.0 |
| COVER ONCE | 10.3 | -498.8 | 0.0 | 0.0 | 3.7 | -306.4 | 0.0 | 68.3 |
| DENIED BY THE FIGHT | - | - | - | - | 1.3 | -10.7 | 0.0 | 0.0 |
| DEPLOY BY FIGURES | 8.7 | +61.0 | 0.0 | 0.0 | 6.3 | +5.3 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | 0.3 | -1.4 | 0.0 | 0.0 | - | - | - | - |
| EVASIVE BY THE ODDS | 0.3 | +5.6 | 0.0 | 0.0 | - | - | - | - |
| EXACT ROUND | - | - | - | - | 1.3 | +22.5 | 0.0 | 0.0 |
| FACES THE THREAT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FALL BACK GOOD ORDER | 1.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| FALLS SHORT | 7.3 | +111.1 | 0.0 | 0.0 | 19.7 | +97.6 | 0.0 | 283.3 |
| FEATURE BUFFS | 0.7 | +0.6 | 0.0 | 0.0 | 0.7 | +13.1 | 0.0 | 0.0 |
| FIGHT TO THE END | 0.7 | +16.3 | 0.0 | 0.0 | 1.0 | +7.8 | 0.0 | 0.0 |
| FIRE IN ORDER | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FIVE ACTION | 106.7 | +5137.9 | 1249.3 | 185.3 | 96.0 | +2912.1 | 556.0 | 977.3 |
| FLANK NOT WEIGHED | 5.0 | +0.0 | 0.0 | 0.0 | 5.0 | +0.0 | 0.0 | 136.7 |
| FOLLOW UP WEIGHED | 0.7 | +134.9 | 0.0 | 0.0 | - | - | - | - |
| FOUR ROUNDS | 1.0 | +108.0 | 0.0 | 0.0 | 1.3 | +24.7 | 0.0 | 0.0 |
| FREED FROM HIS FIGHT | 2.7 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| GOAL WALK | 11.7 | +902.2 | 0.0 | 0.0 | 6.0 | +334.3 | 0.0 | 421.3 |
| GUN FIGURES | 0.7 | +0.0 | 0.0 | 0.0 | 1.3 | +17.6 | 46.3 | 0.0 |
| GUN MASK | 0.7 | +1.9 | 0.0 | 0.0 | 0.7 | +74.6 | 0.0 | 0.0 |
| HARD STAY DROPPED | 4.0 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 2.7 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 4.0 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 136.7 |
| HIS CHARGE DENIED | - | - | - | - | 0.3 | +48.4 | 0.0 | 0.0 |
| HIS CHARGE LIST | 10.7 | +0.0 | 0.0 | 0.0 | 5.3 | +0.0 | 0.0 | 136.7 |
| HIS LEGAL MOVES | 4.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 4.7 | -33.2 | 0.0 | 92.7 | 1.0 | -17.4 | 0.0 | 15.0 |
| HIS MOVE AS HE DECIDES | - | - | - | - | 43.7 | +18.7 | 92.7 | 0.0 |
| HIS MOVE WHY | 17.3 | +0.0 | 0.0 | 92.7 | - | - | - | - |
| HIS ONE MOVE | - | - | - | - | 17.0 | -16.0 | 0.0 | 68.3 |
| HIS ONE QUARTER | 5.7 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 4.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 48.7 | +4018.0 | 0.0 | 185.3 | 52.0 | +3943.1 | 0.0 | 837.3 |
| HIS SHOTS BY HIS RUN | 32.0 | +479.3 | 0.0 | 185.3 | 36.0 | +877.0 | 0.0 | 528.7 |
| HIS TURN DENIED | - | - | - | - | 1.0 | +35.2 | 0.0 | 0.0 |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 15.0 | +0.0 | 0.0 | 0.0 | 9.3 | +0.0 | 0.0 | 0.0 |
| HOLDER ASSIGNMENT | 10.0 | +882.9 | 0.0 | 0.0 | 7.0 | +663.5 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 1.0 | -53.5 | 0.0 | 0.0 | 1.3 | -42.3 | 0.0 | 0.0 |
| HUNT IN PAIRS | 0.3 | +37.8 | 0.0 | 0.0 | - | - | - | - |
| IDLE COST | 5.7 | -103.9 | 0.0 | 92.7 | 13.3 | -209.4 | 0.0 | 237.7 |
| KEPT FROM ITS LAST STOP | 3.3 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 1.3 | +64.9 | 0.0 | 0.0 | - | - | - | - |
| LEGAL CHARGES ONLY | 2.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| LONE CHARACTER SAFE SPOT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| LONE WIZARD KEPT IN | - | - | - | - | 0.7 | +30.1 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | 0.3 | -6.1 | 0.0 | 0.0 | 1.3 | +15.5 | 0.0 | 0.0 |
| MANOEUVRE | 1.0 | -7.2 | 0.0 | 0.0 | 4.0 | -5.6 | 0.0 | 57.7 |
| MARCH BY THE SUM | - | - | - | - | 0.7 | +79.0 | 0.0 | 0.0 |
| MARCH CHECK | 0.3 | +12.8 | 0.0 | 0.0 | 1.7 | +114.0 | 0.0 | 0.0 |
| MARCH OF THE TABLE | - | - | - | - | 0.7 | +37.0 | 0.0 | 0.0 |
| MARCH OVER CASTS | 0.3 | -1.7 | 0.0 | 0.0 | 1.3 | +31.3 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 1.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 2.3 | +55.6 | 0.0 | 0.0 | 1.3 | +9.5 | 0.0 | 0.0 |
| MEETS IN TIME | 5.3 | +153.6 | 0.0 | 0.0 | 2.3 | +33.0 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 2.7 | +169.7 | 0.0 | 0.0 | 8.3 | +83.6 | 0.0 | 57.7 |
| MISSILES NEXT TURN | 3.0 | +79.0 | 0.0 | 0.0 | 11.3 | +92.3 | 0.0 | 115.3 |
| MOVE ORDER | 1.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| MOVE SPELL IN RANGE | 3.7 | +143.1 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.7 | -1.7 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL SPOT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 1.7 | +117.6 | 0.0 | 0.0 | 0.7 | +35.4 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 9.3 | +413.6 | 0.0 | 0.0 | 8.7 | +363.3 | 0.0 | 57.7 |
| NEXT CHARGE BY LIST | 0.7 | +29.9 | 0.0 | 0.0 | 0.3 | +27.6 | 0.0 | 0.0 |
| NEXT OBJECTIVE NEARER | 0.7 | -6.9 | 0.0 | 0.0 | - | - | - | - |
| NO DOUBLE ROUNDS | 0.7 | -2.7 | 0.0 | 0.0 | 1.0 | -120.9 | 0.0 | 0.0 |
| NO LATE CUT | 1.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 4.0 | -124.6 | 0.0 | 0.0 | 4.7 | -128.6 | 0.0 | 68.3 |
| OGRE LOADER SECOND SHOT | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| ONE CHECK AFTER THE LAST CHANGE | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 2.3 | -65.6 | 0.0 | 0.0 | 1.3 | -16.8 | 0.0 | 0.0 |
| ONE OBJECTIVE FORMULA | 3.0 | -15.5 | 0.0 | 0.0 | 3.3 | -184.3 | 0.0 | 0.0 |
| ONE ROUTE | 1.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| OPENS A LANE | - | - | - | - | 0.3 | +0.3 | 0.0 | 0.0 |
| OPENS UP | 0.3 | +16.7 | 0.0 | 0.0 | - | - | - | - |
| OVERRUNS AWAY | - | - | - | - | 0.3 | +0.2 | 0.0 | 0.0 |
| PATHS CROSS | 0.7 | +9.4 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.3 | -11.1 | 0.0 | 0.0 | - | - | - | - |
| PLAN RESULT | 47.3 | +783.2 | 303.3 | 92.7 | 43.7 | +316.6 | 278.0 | 361.3 |
| PROMISE BELOW ZERO | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE BY ITS OWN SUM | 6.0 | -263.2 | 0.0 | 0.0 | 1.0 | -7.8 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| QUARTER ODDS | 17.3 | +1543.8 | 0.0 | 0.0 | 18.7 | +1199.8 | 0.0 | 0.0 |
| REAL GROUND | 1.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | 0.7 | +66.0 | 0.0 | 0.0 | 0.3 | +52.9 | 0.0 | 0.0 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 1.0 | +0.0 | 0.0 | 15.0 |
| REFORMS TO MEET IT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| RESERVE FALL BACK | 0.3 | +1.5 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | 1.0 | +17.3 | 0.0 | 0.0 | 1.3 | -42.3 | 0.0 | 0.0 |
| RISK ON THE WAY | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| RUN DOWN | - | - | - | - | 1.3 | -11.7 | 0.0 | 0.0 |
| SAFER THAN THE JOB | 0.3 | +35.0 | 0.0 | 0.0 | - | - | - | - |
| SCOUT SPOT | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| SCOUT WAITS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 1.0 | -96.0 | 0.0 | 0.0 | 1.3 | -39.2 | 0.0 | 30.0 |
| SEARCH SPOT | 1.0 | +14.4 | 0.0 | 0.0 | 0.3 | +0.2 | 0.0 | 0.0 |
| SECOND LOOK | - | - | - | - | 0.3 | +1.5 | 0.0 | 0.0 |
| SET UP BY THE SET | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| SET-UP ANY TARGET | 0.3 | +20.9 | 0.0 | 0.0 | 0.3 | +19.1 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.7 | +1.3 | 0.0 | 0.0 | 0.3 | +0.7 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 16.3 | +0.0 | 0.0 | 0.0 | 12.3 | +0.0 | 0.0 | 70.0 |
| SHOOTS FROM THE BEST SPOT | 5.7 | +235.1 | 314.0 | 0.0 | 3.3 | +15.4 | 0.0 | 0.0 |
| SHOT OR CHARGE | - | - | - | - | 0.3 | -0.5 | 0.0 | 0.0 |
| SHOT RISK POINTS | 24.0 | +155.1 | 0.0 | 185.3 | 28.3 | -125.0 | 0.0 | 582.7 |
| SHOTS AFTER THE MOVES | 3.7 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 18.3 | +367.8 | 0.0 | 0.0 | 16.7 | +465.3 | 0.0 | 55.0 |
| SPELL SETS UP CHARGE | 0.3 | +20.9 | 0.0 | 0.0 | 0.3 | +19.1 | 0.0 | 0.0 |
| SPELL WORTH | 0.3 | +1.7 | 0.0 | 0.0 | 2.0 | +43.9 | 0.0 | 0.0 |
| SPOT AS THE GAME MOVES | 3.7 | +0.0 | 0.0 | 46.3 | 3.7 | +0.0 | 0.0 | 84.7 |
| STANDS FOR A REASON | 0.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 64.0 | +0.0 | 1249.3 | 0.0 | 47.0 | +0.0 | 556.0 | 220.0 |
| STAY WORTH | 34.7 | -77.3 | 935.3 | 0.0 | 27.3 | -213.4 | 556.0 | 165.0 |
| STUBBORN BY POINTS | 0.3 | +52.3 | 0.0 | 0.0 | - | - | - | - |
| SUPPORT ADDS | 3.3 | +147.0 | 0.0 | 0.0 | 5.3 | +117.3 | 0.0 | 30.0 |
| SUPPORT WORKED OUT | 3.3 | +147.0 | 0.0 | 0.0 | 5.3 | +117.3 | 0.0 | 30.0 |
| SURE REACH TOGETHER | 0.3 | +0.5 | 0.0 | 0.0 | - | - | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 2.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| THE PROMISED MOVE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE ROW IN ITS ORDER | 2.0 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 3.7 | +0.0 | 0.0 | 46.3 | 3.7 | +0.0 | 0.0 | 84.7 |
| THE STEP BACK IS MADE | 1.7 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 52.3 | +0.0 | 0.0 | 92.7 | 45.3 | +0.0 | 0.0 | 448.7 |
| TIED UP BY THE SUM | 0.3 | +29.1 | 0.0 | 0.0 | - | - | - | - |
| TIME ON OUR SIDE | 43.3 | +444.0 | 166.7 | 0.0 | 17.3 | +180.7 | 0.0 | 0.0 |
| WAITS AGAIN | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT DANGER | 1.7 | -26.1 | 0.0 | 0.0 | 1.0 | -84.6 | 0.0 | 0.0 |
| WOUNDS ON THE RANKS | 3.7 | +145.6 | 0.0 | 0.0 | 1.3 | +6.0 | 0.0 | 0.0 |

### Rule changes: csame-bb45c30-p39

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 108 | 108 | 77 | 25.67 | +544 | +7.1 |
| HIS SHOT LIST | 302 | 292 | 77 | 25.67 | +2229 | +28.9 |
| HIS MOVE AS HE DECIDES | 131 | 131 | 75 | 25.00 | +0 | +0.0 |
| HIS SHOTS BY HIS RUN | 204 | 199 | 61 | 20.33 | +543 | +8.9 |
| HOLDER ASSIGNMENT | 51 | 51 | 49 | 16.33 | +3266 | +66.7 |
| SHOT RISK POINTS | 157 | 152 | 42 | 14.00 | +1405 | +33.5 |
| HIS MOVE WHY | 52 | 52 | 35 | 11.67 | +0 | +0.0 |
| OFF BEST | 26 | 26 | 26 | 8.67 | -760 | -29.2 |
| THE TABLE AGAIN | 36 | 36 | 24 | 8.00 | +0 | +0.0 |
| TIME ON OUR SIDE | 182 | 170 | 24 | 8.00 | +39 | +1.6 |
| DEPLOY BY FIGURES | 45 | 45 | 22 | 7.33 | +460 | +20.9 |
| HARD STAY DROPPED | 19 | 19 | 19 | 6.33 | +0 | +0.0 |
| HIS ONE MOVE | 51 | 51 | 19 | 6.33 | +0 | +0.0 |
| SHOOTS FROM THE BEST SPOT | 27 | 27 | 19 | 6.33 | +167 | +8.8 |
| QUARTER ODDS | 108 | 101 | 18 | 6.00 | +881 | +48.9 |
| ARTILLERY RE-ROLL WEIGHED | 14 | 14 | 14 | 4.67 | +0 | +0.0 |
| CAST JOB | 19 | 19 | 12 | 4.00 | +110 | +9.2 |
| CHARGE LOSSES | 79 | 77 | 12 | 4.00 | +768 | +64.0 |
| GOAL WALK | 53 | 53 | 11 | 3.67 | +580 | +52.7 |
| FIVE ACTION | 608 | 592 | 10 | 3.33 | +444 | +44.4 |
| MEETS IN TIME | 23 | 23 | 10 | 3.33 | +383 | +38.3 |
| IDLE COST | 57 | 48 | 9 | 3.00 | +54 | +5.9 |
| LEGAL CHARGES ONLY | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| MOVE ORDER | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| PROMISE BY ITS OWN SUM | 21 | 21 | 9 | 3.00 | -813 | -90.3 |
| SUPPORT ADDS | 26 | 26 | 9 | 3.00 | +81 | +9.0 |
| SUPPORT WORKED OUT | 26 | 26 | 9 | 3.00 | +81 | +9.0 |
| ADVANCE LANE KEPT | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| MARCH CHECK | 6 | 6 | 5 | 1.67 | +120 | +23.9 |
| CANNON SIGHT KEPT | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| COVER ONCE | 42 | 33 | 4 | 1.33 | +43 | +10.7 |
| LANE BY FIGURES | 4 | 4 | 4 | 1.33 | +195 | +48.6 |
| MOVE TO CHARGE COMPUTED | 7 | 6 | 4 | 1.33 | +187 | +46.9 |
| OGRE LOADER SECOND SHOT | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| SHOTS AFTER THE MOVES | 21 | 21 | 4 | 1.33 | +0 | +0.0 |
| WOUNDS ON THE RANKS | 15 | 15 | 4 | 1.33 | +200 | +50.0 |
| CANNON PLANNED TARGET | 40 | 40 | 3 | 1.00 | +0 | +0.0 |
| CHAFF IN THE MOVE | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| MAX FOR POSITIONING | 11 | 10 | 3 | 1.00 | +5 | +1.7 |
| MISSILES IN THE MOVE | 33 | 26 | 3 | 1.00 | +89 | +29.8 |
| NEARER NOT NEEDED | 54 | 53 | 3 | 1.00 | +165 | +54.9 |
| PATHS CROSS | 3 | 3 | 3 | 1.00 | +28 | +9.4 |
| REDIRECT FOR A FRIEND IN REACH | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| SHOOTERS IN TWO RANKS | 3 | 3 | 3 | 1.00 | +6 | +2.0 |
| THE ROW IN ITS ORDER | 12 | 3 | 3 | 1.00 | +0 | +0.0 |
| CASTS FROM BEHIND | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| FALLS SHORT | 81 | 73 | 2 | 0.67 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 2 | 2 | 2 | 0.67 | +405 | +202.4 |
| FOUR ROUNDS | 7 | 6 | 2 | 0.67 | +128 | +63.8 |
| GUN MASK | 4 | 4 | 2 | 0.67 | +217 | +108.6 |
| HOLDS AMBUSHERS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| LONE WIZARD KEPT IN | 2 | 2 | 2 | 0.67 | +90 | +45.1 |
| MANOEUVRE | 15 | 15 | 2 | 0.67 | +30 | +14.9 |
| MARCH BY THE SUM | 2 | 2 | 2 | 0.67 | +237 | +118.4 |
| MARCH OF THE TABLE | 2 | 2 | 2 | 0.67 | -111 | -55.5 |
| SCOUT WAITS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| SEARCH SPOT | 4 | 4 | 2 | 0.67 | +82 | +41.0 |
| STAY WORTH | 186 | 173 | 2 | 0.67 | +4 | +2.1 |
| AFTERMATH IN POINTS | 1 | 1 | 1 | 0.33 | +6 | +6.2 |
| CASTER AWAY FROM SCREEN | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CHALLENGE BY POINTS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CHARGE NOW FIRST | 4 | 4 | 1 | 0.33 | -3 | -2.9 |
| COMBAT PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| EVASIVE BY THE ODDS | 1 | 1 | 1 | 0.33 | +17 | +16.9 |
| FACES THE THREAT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FIRE IN ORDER | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| HIS CHARGE DENIED | 1 | 1 | 1 | 0.33 | +71 | +71.4 |
| MISSILES NEXT TURN | 43 | 38 | 1 | 0.33 | +5 | +4.6 |
| NEXT CHARGE BY LIST | 3 | 3 | 1 | 0.33 | +72 | +71.7 |
| OPENS UP | 1 | 1 | 1 | 0.33 | +33 | +33.2 |
| PIVOT GUARDS FLANK | 1 | 1 | 1 | 0.33 | -33 | -33.3 |
| RESERVE FALL BACK | 1 | 1 | 1 | 0.33 | +4 | +4.4 |
| RISK BY ARC | 7 | 6 | 1 | 0.33 | +33 | +33.2 |
| SAFER THAN THE JOB | 1 | 1 | 1 | 0.33 | +105 | +105.0 |
| SECOND LOOK | 1 | 1 | 1 | 0.33 | +4 | +4.5 |
| STUBBORN BY POINTS | 1 | 1 | 1 | 0.33 | +157 | +156.7 |
| SURE REACH TOGETHER | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| TIED UP BY THE SUM | 1 | 1 | 1 | 0.33 | +33 | +33.2 |
| BACKUP TARGETS | 2 | 2 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 1 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 4 | trace | - | - | - | - |
| CHAMPION KNOWS CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| CHARACTER GUNS | 9 | 7 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 42 | 42 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 3 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 4 | 3 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 1 | 1 | 0 | 0.00 | - | - |
| EXACT ROUND | 4 | 3 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 7 | 6 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 5 | 5 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 30 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 15 | 11 | 0 | 0.00 | - | - |
| GUN FIGURES | 6 | not checked | - | - | - | - |
| HE REFORMS ONCE FREED | 15 | 11 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 22 | 21 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 48 | 48 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 15 | 14 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 17 | 16 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 27 | 26 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 15 | 14 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 3 | 2 | 0 | 0.00 | - | - |
| HIS TURN RUN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 73 | 72 | 0 | 0.00 | - | - |
| HONEST WORTH | 7 | 6 | 0 | 0.00 | - | - |
| HUNT IN PAIRS | 1 | 1 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 18 | 17 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 1 | not checked | - | - | - | - |
| LOST AFTER ESCAPE | 5 | 4 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 5 | 5 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 9 | 8 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 11 | 6 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 2 | trace | - | - | - | - |
| MOVE SPELL SPOT | 1 | not checked | - | - | - | - |
| NEXT OBJECTIVE NEARER | 2 | 2 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 5 | 5 | 0 | 0.00 | - | - |
| NO LATE CUT | 8 | 7 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 18 | 18 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT TURNED | 2 | 2 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 2 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 11 | 10 | 0 | 0.00 | - | - |
| ONE OBJECTIVE FORMULA | 19 | 16 | 0 | 0.00 | - | - |
| ONE ROUTE | 9 | 8 | 0 | 0.00 | - | - |
| OPENS A LANE | 1 | not checked | - | - | - | - |
| OVERRUNS AWAY | 1 | 1 | 0 | 0.00 | - | - |
| PLAN RESULT | 273 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE KNOWS THE FIGHT | 3 | 3 | 0 | 0.00 | - | - |
| REAL GROUND | 9 | 8 | 0 | 0.00 | - | - |
| REDIRECT COUNTER | 3 | 3 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 1 | 1 | 0 | 0.00 | - | - |
| REFUSING RETIRES | 1 | 1 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 2 | 2 | 0 | 0.00 | - | - |
| RUN DOWN | 4 | 3 | 0 | 0.00 | - | - |
| SCOUT SPOT | 2 | 2 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 7 | 7 | 0 | 0.00 | - | - |
| SET UP BY THE SET | 2 | 2 | 0 | 0.00 | - | - |
| SET-UP ANY TARGET | 2 | not checked | - | - | - | - |
| SHOOTERS ON THE TABLE | 86 | not checked | - | - | - | - |
| SHOT OR CHARGE | 1 | not checked | - | - | - | - |
| SHOTS IN THE MOVE | 105 | 87 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 2 | not checked | - | - | - | - |
| SPELL WORTH | 7 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 22 | 19 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 6 | 6 | 0 | 0.00 | - | - |
| STANDS STILL | 333 | 326 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 9 | not checked | - | - | - | - |
| THE PROMISED MOVE | 1 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 22 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 12 | not checked | - | - | - | - |
| THE TABLE BINDS | 293 | not checked | - | - | - | - |
| WAITS AGAIN | 2 | 2 | 0 | 0.00 | - | - |
| WHOLE FIGHT DANGER | 8 | 8 | 0 | 0.00 | - | - |

### Off best figure: csame-bb45c30-p39

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 4.00 | 3.00 | 31.3 |
| ARMY TABLE | rule | 2.33 | 1.67 | 63.1 |
| PROMISE BY ITS OWN SUM | rule | 2.67 | 0.33 | 90.3 |
| RULE SWITCHED OFF | gate | - | 1.67 | 20.6 |
| HOLDER ASSIGNMENT | rule | 0.33 | 0.33 | 33.1 |
| MARCH OF THE TABLE | rule | - | 0.67 | 55.5 |
| CHARGE NOW FIRST | rule | 0.33 | - | 2.9 |
| PIVOT GUARDS FLANK | rule | 0.33 | - | 33.3 |

### Plans: csame-bb45c30-p39

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.0 | 0% | 125 | 20 | 16% |
| Mine | join | 1.3 | 100% | 46 | 0 | 0% |
| Mine | move | 32.3 | 99% | 1739 | 0 | 0% |
| Mine | shoot | 12.0 | 53% | 236 | 763 | 323% |
| Mine | support | 0.7 | 100% | 0 | 0 | - |
| Opponent | charge | 1.0 | 33% | 89 | 48 | 54% |
| Opponent | join | 1.7 | 100% | 93 | 0 | 0% |
| Opponent | move | 31.3 | 96% | 902 | 0 | 0% |
| Opponent | shoot | 9.0 | 56% | 275 | 268 | 98% |
| Opponent | support | 0.7 | 50% | 0 | 0 | - |

### Battle groups: csame-bb45c30-p39

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 0.7 | 0% | - | - | - | - | - | - | - | - |
| Opponent | REDIRECT COUNTER | 0.3 | 100% | 100% | 0% | - | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: csame-bb45c30-p39

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | 0 (1) | - | - | 0 (1) | - |
| Mine | Character | 11 | 10 (11) | 10 | 0 | 0 | 27% | 2.2 | 15 (7) | 0 (4) | - | 13 (8) | 0 (3) |
| Mine | Clean-up | 6 | 83 (6) | 0 | 83 | 0 | 67% | 4.0 | 0 (3) | 148 (2) | 250 (1) | 102 (5) | 0 (1) |
| Mine | Fast Hammer | 1 | 0 (1) | 0 | 0 | 0 | 0% | 1.0 | - | 0 (1) | - | - | 0 (1) |
| Mine | Hammer | 6 | 3 (6) | 3 | 0 | 0 | 50% | 2.7 | 0 (2) | 5 (4) | - | 0 (5) | 15 (1) |
| Mine | Holder | 2 | 11 (2) | 0 | 11 | 50 | 100% | - | 22 (1) | 0 (1) | - | 11 (2) | - |
| Mine | Shooter | 2 | 63 (2) | 0 | 63 | 0 | 0% | 2.0 | 126 (1) | 0 (1) | - | 63 (2) | - |
| Mine | War machine | 5 | 78 (5) | 78 | 0 | 0 | 0% | 1.2 | 195 (2) | 0 (1) | 0 (2) | - | 78 (5) |
| Opponent | Chaff | 4 | 0 (4) | 0 | 0 | 18 | 100% | - | 0 (4) | - | - | 0 (3) | 0 (1) |
| Opponent | Character | 9 | 0 (9) | 0 | 0 | 12 | 56% | 3.0 | 0 (3) | 0 (5) | 0 (1) | 0 (5) | 0 (4) |
| Opponent | Clean-up | 2 | 0 (2) | 0 | 0 | 57 | 50% | 5.0 | 0 (1) | 0 (1) | - | 0 (1) | 0 (1) |
| Opponent | Fast Hammer | 1 | 0 (1) | 0 | 0 | 0 | 0% | 3.0 | 0 (1) | - | - | - | 0 (1) |
| Opponent | Hammer | 3 | 0 (3) | 0 | 0 | 0 | 33% | 1.5 | - | 0 (3) | - | 0 (2) | 0 (1) |
| Opponent | Holder | 3 | 0 (3) | 0 | 0 | 32 | 67% | 5.0 | - | 0 (2) | 0 (1) | 0 (2) | 0 (1) |
| Opponent | Shooter | 3 | 29 (3) | 0 | 29 | 0 | 0% | 1.0 | - | 87 (1) | 0 (2) | 43 (2) | 0 (1) |
| Opponent | Support | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | War machine | 5 | 20 (5) | 20 | 0 | 23 | 0% | 1.4 | - | - | 20 (5) | - | 20 (5) |
| Opponent | Wizard | 5 | 0 (5) | 0 | 0 | 0 | 20% | 2.8 | 0 (3) | 0 (2) | - | 0 (2) | 0 (3) |

### Charged fights: csame-bb45c30-p39

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaos Dwarfs | 2 | 150 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 1 of 2 | 1 of 2 | - | +0 |
| Mine | Dwarfen Mountain Holds | 1 | 370 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| **Mine** | all armies | 3 | 223 | 0 | 0.7 | 1.0 | 0 | 0 | +0 | 1 of 2 | 1 of 2 | - | +0 |
| Opponent | Empire of Man | 1 | 139 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Grand Cathay | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Vampire Counts | 1 | 0 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 1 of 1 | 0 of 1 | - | +0 |
| **Opponent** | all armies | 3 | 46 | 0 | 0.3 | 1.0 | 0 | 0 | +0 | 1 of 1 | 0 of 1 | - | +0 |

### Effective charges: csame-bb45c30-p39

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaos Dwarfs | 2 | 1 (net +0) | 0 | 0 | 0 | 0 | 0 | 1 | 0% (0 of 1) |
| Opponent | Vampire Counts | 1 | 0 | 0 | 1 (net +0) | 0 | 0 | 0 | 0 | 100% (1 of 1) |

### Charged fights, damage counted: csame-bb45c30-p39

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 1 | 120 | 189 | +0 | 111 | 9 | +102 | +84.8 |
| Mine | No odds | 1 | 480 | 348 | +0 | 0 | 0 | +0 | +0.0 |
| Mine | All fights | 2 | 300 | 268 | +0 | 55 | 4 | +51 | +17.0 |
| Opponent | Effective (55-75%) | 1 | 480 | 339 | +0 | 145 | 360 | -215 | -44.7 |
| Opponent | All fights | 1 | 480 | 339 | +0 | 145 | 360 | -215 | -44.7 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| csame-bb45c30-p39 | move | 6 | 0 (0%) | 0 (0%) | 0 (0%) | 6 (100%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L0425 |
| Clockwork Compass | Opponent | L0512 |
| Invocation of Nehek | Opponent | L0425 |
| Ring of Doom | Opponent | L0512 |
| Ring of Jet | Opponent | L0512 |

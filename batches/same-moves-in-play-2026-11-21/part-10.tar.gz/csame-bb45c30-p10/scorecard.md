# Doctrine scorecard: csame-bb45c30-p10

### Scorecard: csame-bb45c30-p10

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L1823 | 5 | 1 | Mine | no | - | - | 1 | 1 | 1 | 0 | 0 | 0 |
| L1823 | 5 | 1 | Opponent | yes | - | 1 | 4 | 1 | 0 | 0 | 0 | 130 |
| L1923 | 3 | 1 | Mine | no | 1 | 1 | 5 | 0 | 0 | 0 | 0 | 359 |
| L1923 | 3 | 1 | Opponent | yes | 12 | 2 | 3 | 2 | 0 | 0 | 0 | 397 |
| L2025 | 3 | 1 | Mine | yes | 12 | - | 0 | 1 | 0 | 0 | 0 | 420 |
| L2025 | 3 | 1 | Opponent | no | 0 | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 33% | 6.5 | 1.0 | 2.0 | 0.7 | 0.3 | 0.0 | 0.0 | 259.7 |
| **Average** | | | Opponent | 67% | 6.0 | 1.7 | 3.3 | 1.3 | 0.0 | 0.0 | 0.0 | 175.7 |

### KPIs: csame-bb45c30-p10

Rules off - Mine only: NO OLD ONE-MOVE GUESS; both sides: ONE RUN A PLAN.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 12) | 0% (0 of 13) | 0% (0 of 25) |
| Winner chose to follow up after the loser gave ground |  | 89% (8 of 9); on the table 89% | 89% (8 of 9); on the table 89% | 89% (16 of 18); on the table 89% |
| Winner chose to pursue after the loser fell back in good order |  | - | 100% (1 of 1); on the table 100% | 100% (1 of 1); on the table 100% |
| Winner chose to pursue after the loser fled |  | - | 60% (3 of 5); on the table 60% | 60% (3 of 5); on the table 60% |
| Winner chose to follow up or pursue (all three) |  | 89% (8 of 9); on the table 89% | 80% (12 of 15); on the table 80% | 83% (20 of 24); on the table 83% |
| Magic missiles tried each own turn | 50%+ | 17% (5 of 30) | 44% (8 of 18) | 27% (13 of 48) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 28% (5 of 18) | 44% (8 of 18) | 36% (13 of 36) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 17% (1 of 6) | - | 17% (1 of 6) |
| Points that never fought | lower | 26% (1576 of 5999) | 34% (2056 of 5999) | 30% (3632 of 11998) |
|   infantry points that never fought | lower | 75% (741 of 993) | 55% (574 of 1037) | 65% (1315 of 2030) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 59% (13 of 22) | 62% (10 of 16) | 61% (23 of 38) |
| Bound items with a magic missile used (at least once a game) |  | 100% (1 of 1); 0.7 uses a game | 0.0 uses a game | 100% (1 of 1); 0.3 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 50% (1 of 2); 0.3 uses a game | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 65% (3343 of 5151) | 57% (2564 of 4500) | 61% (5907 of 9651) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 0.3 (4%) | 3.3 (100%) | 3.7 (31%) |
| MARCHED: its unit marched | 1.7 (20%) | 0.0 (0%) | 1.7 (14%) |
| CHARGED: its unit charged | 0.7 (8%) | 0.0 (0%) | 0.7 (6%) |
| IN COMBAT: engaged in combat | 1.7 (20%) | 0.0 (0%) | 1.7 (14%) |
| REAR RANK: in a rear rank | 1.0 (12%) | 0.0 (0%) | 1.0 (9%) |
| GONE: slain | 2.0 (24%) | 0.0 (0%) | 2.0 (17%) |
| OFF THE TABLE: off the table or not arrived | 0.3 (4%) | 0.0 (0%) | 0.3 (3%) |
| NOT OFFERED: not in the cast list | 0.7 (8%) | 0.0 (0%) | 0.7 (6%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 3.3 | 1.3 | 1.3 | 4.3 | 0.3 |
| not cast | 6.7 | 0.7 | 4.7 | 11.7 | 19.7 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.7 (8%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.3 (50%) | 0.0 (0%) | 3.7 (31%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.7 (14%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (6%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.7 (14%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 1.7 (25%) | 0.0 (0%) | 1.7 (36%) | 1.0 (9%) | 0.0 (0%) |
| GONE: slain | 1.7 (25%) | 0.0 (0%) | 0.3 (7%) | 2.0 (17%) | 3.0 (15%) |
| OFF THE TABLE: off the table or not arrived | 0.3 (5%) | 0.0 (0%) | 0.3 (7%) | 0.3 (3%) | 1.3 (7%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.3 (50%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (6%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 3.0 (45%) | 0.0 (0%) | 2.3 (50%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 13.7 (69%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.0 a game | 1.3 a game | 0.7 a game |
| stood (cast and not dispelled) | - | 100% (4 of 4) | 100% (4 of 4) |
| the unit moved after it | - | 100% (4 of 4) | 100% (4 of 4) |
| it charged on its next turn | - | 0% (0 of 4) | 0% (0 of 4) |
| the enemy charged it first | - | 0% (0 of 4) | 0% (0 of 4) |
| it fought by the end of its next turn | - | 0% (0 of 4) | 0% (0 of 4) |
| it moved out of a charge the enemy had planned (not charged first) | - | 0% (0 of 4) | 0% (0 of 4) |
| none of these (no charge, no fight, no charge escaped) | - | 100% (4 of 4) | 100% (4 of 4) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 51% (33 of 65) | 53% (42 of 79) | 52% (75 of 144) |
|   cavalry | - | 87% (13 of 15) | 87% (13 of 15) |
|   character | 100% (6 of 6) | 0% (0 of 21) | 22% (6 of 27) |
|   chariot | 45% (5 of 11) | - | 45% (5 of 11) |
|   infantry | 36% (13 of 36) | 67% (29 of 43) | 53% (42 of 79) |
|   monster | 75% (9 of 12) | - | 75% (9 of 12) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.7 (16%) | 0.0 (0%) | 1.7 (7%) |
| CHARGED: it charged | 0.0 (0%) | 2.0 (16%) | 2.0 (9%) |
| IN COMBAT: it fought this turn or the last | 0.0 (0%) | 1.3 (11%) | 1.3 (6%) |
| NO TARGET IN RANGE | 4.0 (38%) | 3.7 (30%) | 7.7 (33%) |
| ONLY IN COMBAT: the only targets were in combat | 0.7 (6%) | 3.7 (30%) | 4.3 (19%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 2.3 (22%) | 1.7 (14%) | 4.0 (17%) |
| SHELTERED: the target was sheltered | 0.7 (6%) | 0.0 (0%) | 0.7 (3%) |
| OTHER BAR | 1.3 (12%) | 0.0 (0%) | 1.3 (6%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 5.0 | 1.7 | 73% | 6.7 pts | 34 pts |
| character | 2.0 | 0.7 | 83% | 10.8 pts | 22 pts |
| chariot | 2.0 | 1.0 | 83% | 11.7 pts | 23 pts |
| infantry | 15.7 | 8.3 | 64% | 7.4 pts | 115 pts |
| monster | 3.0 | 0.3 | 89% | 3.6 pts | 11 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 2.7 | 7.3 | 5.0 |
| Charges that made contact a game | 2.3 | 5.3 | 3.8 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.00 declared, 0.00 contact (1 units) | 0.00 declared, 0.00 contact (2 units) | 0.00 declared, 0.00 contact (3 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 3.00 declared, 2.00 contact (1 units) | 3.00 declared, 2.00 contact (1 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.29 declared, 0.25 contact (28 units) | 0.63 declared, 0.47 contact (30 units) | 0.47 declared, 0.36 contact (58 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | - | 67% (2 of 3) | - | 67% (2 of 3) |
| Character in a unit | 100% (1 of 1) | - | - | 100% (1 of 1) |
| Character on its own | 25% (1 of 4) | 75% (3 of 4) | 57% (4 of 7) | 53% (8 of 15) |
| Chariot | 50% (1 of 2) | - | - | 50% (1 of 2) |
| Infantry | 67% (4 of 6) | - | - | 67% (4 of 6) |
| Monster | 25% (1 of 4) | 67% (2 of 3) | - | 43% (3 of 7) |
| Monstrous | - | 100% (4 of 4) | - | 100% (4 of 4) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Ogre Kingdoms | 1 | 50% (1 of 2); on the table 50% | 0% (0 of 6) | 40% | 86% (6 of 7) | 100% (1 of 1); 2.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 1 | 100% (2 of 2); on the table 100% | 17% (2 of 12) | 3% | 50% (4 of 8) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Skaven | 1 | 100% (5 of 5); on the table 100% | 25% (3 of 12) | 36% | 43% (3 of 7) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Tomb Kings of Khemri | 2 | 83% (10 of 12); on the table 83% | 0% (0 of 6) | 37% | 50% (5 of 10) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 1 | 67% (2 of 3); on the table 67% | 67% (8 of 12) | 30% | 83% (5 of 6) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (csame-bb45c30-p10, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 50% (6) | 50% (1) | 50% (7) |
| ...free all their last turn and able to turn (per game) | 1.67 | 0.00 | 1.67 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.33 | 0.33 |
| ...with the charger already in that arc before they moved (per game) | 1.00 | 0.00 | 1.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: csame-bb45c30-p10

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.7 | 2.3 |
| Strategy | Charge objectives carried out (made contact) | 100% (3 of 3) | 55% (12 of 22) |
| Strategy | Shoot objectives carried out (shot that target) | 29% (5 of 17) | 58% (14 of 24) |
| Strategy | Support requests answered (helper made contact too) | - | 100% (3 of 3) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 0% (0 of 1) | - |
| Strategy | Hexes on a unit its side charged or shot that turn | - | 0% (0 of 3) |
| Strategy | Joined characters whose unit fought | 0% (0 of 1) | 33% (1 of 3) |
| Strategy | Lone characters that fought | 89% (8 of 9) | 62% (5 of 8) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 0.7 | 1.3 |
| Movement | Points that never moved of their own | 259.7 | 175.7 |
| Movement | Fights charged into per game | 2.0 | 4.3 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 3 | 2 of 12, net +524 |
| Movement | Charges with odds: sweet spot (55-75%) | 1 of 3, net +66 | 1 of 12, net +405 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 1 of 3, net +66 | 2 of 12, net +148 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 0 of 3 | 6 of 12, net +122 |
| Shooting | Shots by shooting units (incl. breath weapons) | 11.0 | 15.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 48% (16 of 33) | 30% (14 of 46) |
| Shooting | Points destroyed by shooting units | 15.0 | 29.7 |
| Shooting | Points destroyed by war machines | 23.3 | 0.0 |
| Magic | Magic missiles cast | 1.0 | 1.0 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 33% (1 of 3) | 0% (0 of 3) |
| Magic | Points destroyed by magic (all spells) | 0.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.7 / 0.0 / 0.0 / 0.0 | 1.0 / 1.0 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 177.3 | 791.3 |
| Combat | Points run down | 0.0 | 25.7 |
| Combat | Net points per charged fight, damage counted | -81 | +235 |
| Combat | Net per 100 charger points, damage counted | -38.8 | +68.4 |
| Combat | First round won (charged fights) | 50% | 69% |
| Combat | Net points per charged fight | -98 | +221 |
| Combat | Net points per supported fight / lone fight | +66 / -131 | +377 / +174 |
| Combat | Charged fights on a top-3 enemy unit | 2 of 6 | 7 of 13 |
| Game | Points lost | 1259.0 | 215.7 |
| Game | VP from objectives | 463.3 | 930.0 |
| Game | Lone holders (player turns) | 6.5 | 6.0 |

- Mine won / drew / lost: 0 / 1 / 2 of 3 ended games (of 3); mean margin (Mine - Opponent) -1686 VP
- The side that went first won 1 of 2 games with a winner
- Points traded per game (both sides' losses): 1475
- Games not ended: 0; findings 1, warnings 0

### Opponent rules: csame-bb45c30-p10

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.3 | +5.2 | 0.0 | 0.0 | 0.3 | +51.5 | 0.0 | 0.0 |
| AFTERMATH WITH FRIENDS | - | - | - | - | 0.3 | +30.9 | 0.0 | 0.0 |
| ARMY TABLE | 20.0 | -92.0 | 0.0 | 306.7 | 19.0 | +310.7 | 0.0 | 44.0 |
| BACKUP TARGETS | 1.0 | +10.0 | 0.0 | 0.0 | 0.3 | +6.4 | 0.0 | 0.0 |
| CAST JOB | - | - | - | - | 1.7 | +2.3 | 0.0 | 0.0 |
| CASTER AWAY FROM SCREEN | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 1.0 | +9.0 | 66.0 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | 0.3 | +0.7 | 0.0 | 11.3 | - | - | - | - |
| CHAFF PASSED | 0.3 | -0.3 | 0.0 | 0.0 | 0.3 | -0.7 | 78.3 | 22.0 |
| CHALLENGE BY POINTS | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CHAMPION KNOWS CHALLENGE | - | - | - | - | 0.3 | -43.4 | 0.0 | 0.0 |
| CHARGE LOSSES | 16.7 | -1206.4 | 0.0 | 880.0 | 10.7 | -348.4 | 0.0 | 0.0 |
| CHARGE NOT DECLARED | 0.7 | +0.0 | 22.0 | 0.0 | - | - | - | - |
| CHARGE NOW FIRST | 0.7 | +0.0 | 22.0 | 0.0 | 4.3 | +0.0 | 675.0 | 65.7 |
| CLOSES ON WHAT IT BEATS | 7.0 | +0.0 | 0.0 | 276.7 | 13.0 | +0.0 | 0.0 | 88.3 |
| COMBAT PIVOT | 0.3 | +0.0 | 0.0 | 70.0 | 1.0 | +0.0 | 0.0 | 25.0 |
| CONTINUE AHEAD WEIGHED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | - | - | - | - | 1.0 | +24.3 | 0.0 | 0.0 |
| COVER ONCE | 13.0 | -521.3 | 0.0 | 78.3 | 1.7 | -77.5 | 0.0 | 0.0 |
| DENIED BY THE FIGHT | - | - | - | - | 1.7 | -15.4 | 0.0 | 49.0 |
| DEPLOY BY FIGURES | 7.7 | +43.1 | 0.0 | 36.7 | 7.3 | +33.6 | 0.0 | 23.3 |
| DUEL STOPS AT THE KILL | - | - | - | - | 0.3 | -198.2 | 131.0 | 0.0 |
| EDGE GIVE GROUND | - | - | - | - | 0.3 | +4.1 | 85.0 | 0.0 |
| EXACT ROUND | 1.0 | -2.3 | 22.0 | 29.7 | 6.0 | +24.7 | 970.3 | 49.0 |
| FALL BACK GOOD ORDER | 1.3 | +0.0 | 44.0 | 29.7 | 5.7 | +10.3 | 915.7 | 65.7 |
| FALLS SHORT | 2.3 | +20.5 | 0.0 | 200.0 | 14.0 | +136.7 | 0.0 | 74.7 |
| FEATURE BUFFS | 1.7 | +11.7 | 0.0 | 0.0 | 0.7 | +6.9 | 0.0 | 44.0 |
| FIGHT TO THE END | 0.3 | +0.7 | 0.0 | 0.0 | 3.7 | +19.8 | 413.3 | 65.7 |
| FIVE ACTION | 81.3 | +6091.9 | 170.0 | 1496.7 | 96.7 | +6685.5 | 1875.0 | 466.3 |
| FLANK NOT WEIGHED | 14.3 | +0.0 | 0.0 | 331.3 | 3.0 | +0.0 | 0.0 | 47.7 |
| FOLLOW UP WEIGHED | 1.3 | +133.8 | 0.0 | 0.0 | 2.0 | +607.7 | 0.0 | 0.0 |
| FOUR ROUNDS | 1.3 | +36.0 | 44.0 | 29.7 | 7.3 | +661.2 | 1101.3 | 65.7 |
| FREED FROM HIS FIGHT | 12.3 | +0.0 | 0.0 | 197.3 | 3.0 | +0.0 | 0.0 | 70.3 |
| FRIEND SHOOTS FIRST | 1.0 | -16.4 | 0.0 | 0.0 | 1.3 | -9.1 | 0.0 | 0.0 |
| GIVES UP | - | - | - | - | 1.0 | -10.8 | 78.3 | 0.0 |
| GOAL WALK | 10.3 | +700.0 | 0.0 | 350.0 | 8.0 | +478.9 | 0.0 | 50.0 |
| GUN FIGURES | 2.3 | +38.5 | 0.0 | 0.0 | - | - | - | - |
| HARD STAY DROPPED | 2.3 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 11.3 | +0.0 | 0.0 | 259.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HELPER UNSEEN | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 15.0 | +0.0 | 0.0 | 763.3 | 2.0 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE DENIED | - | - | - | - | 0.7 | +18.0 | 0.0 | 49.0 |
| HIS CHARGE LIST | 5.3 | +0.0 | 0.0 | 84.7 | 0.7 | +0.0 | 0.0 | 22.0 |
| HIS LEGAL MOVES | 6.0 | +0.0 | 0.0 | 233.3 | 3.3 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 2.3 | -5.6 | 0.0 | 201.7 | 7.3 | -125.2 | 0.0 | 45.0 |
| HIS MOVE AS HE DECIDES | 42.0 | +16.3 | 210.7 | 0.0 | - | - | - | - |
| HIS MOVE WHY | - | - | - | - | 35.7 | +0.0 | 0.0 | 175.0 |
| HIS ONE MOVE | 21.7 | -92.8 | 0.0 | 85.0 | - | - | - | - |
| HIS ONE QUARTER | 10.0 | +0.0 | 0.0 | 125.3 | 4.0 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 3.0 | +0.0 | 0.0 | 233.3 | 6.0 | +0.0 | 0.0 | 30.0 |
| HIS RANDOM MOVE | - | - | - | - | 7.0 | +0.0 | 0.0 | 50.0 |
| HIS RANDOM MOVER COMES | - | - | - | - | 5.0 | +0.0 | 0.0 | 45.3 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 39.7 | +381.2 | 0.0 | 858.7 | 25.0 | +505.4 | 0.0 | 89.0 |
| HIS SHOTS BY HIS RUN | 38.7 | +231.5 | 0.0 | 1291.3 | 31.0 | +435.8 | 0.0 | 232.0 |
| HIS TURN DENIED | 0.7 | +1.7 | 44.0 | 11.3 | 2.3 | +33.2 | 241.7 | 0.0 |
| HIS TURN RUN | 5.3 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 17.7 | +0.0 | 0.0 | 102.7 | 12.7 | +0.0 | 0.0 | 216.0 |
| HOLDER ASSIGNMENT | 9.7 | +776.9 | 0.0 | 69.7 | 8.7 | +672.9 | 0.0 | 106.0 |
| HOLDS AMBUSHERS | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 1.0 | -47.4 | 44.0 | 29.7 | 5.0 | -199.7 | 817.3 | 0.0 |
| HUNT IN PAIRS | - | - | - | - | 0.7 | +10.3 | 0.0 | 0.0 |
| IDLE COST | 1.3 | -33.8 | 0.0 | 116.7 | 10.0 | -158.6 | 0.0 | 41.7 |
| JOINT CHARGE NOW | - | - | - | - | 2.7 | -2.4 | 483.3 | 49.0 |
| JOINT KNOWS CHALLENGE | - | - | - | - | 0.3 | -3.4 | 0.0 | 0.0 |
| KEPT FROM ITS LAST STOP | - | - | - | - | 2.0 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 0.3 | +6.3 | 0.0 | 0.0 | 1.7 | +89.0 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 5.0 | +0.0 | 101.0 | 444.3 | 9.0 | +0.0 | 650.3 | 224.7 |
| LONE WIZARD KEPT IN | 0.3 | +16.1 | 0.0 | 0.0 | 0.7 | +39.2 | 0.0 | 0.0 |
| LONG SHOT | 0.7 | +0.0 | 30.0 | 0.0 | 0.7 | +4.8 | 180.0 | 16.7 |
| LOST AFTER ESCAPE | 0.3 | -0.2 | 22.0 | 11.3 | 4.7 | +6.7 | 283.0 | 65.7 |
| LOST CHARGE | - | - | - | - | 0.3 | -0.2 | 85.0 | 0.0 |
| MANOEUVRE | 3.0 | +2.3 | 0.0 | 0.0 | 1.0 | +9.9 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.3 | +1.4 | 0.0 | 0.0 | - | - | - | - |
| MARCH BY THE SUM | 1.0 | +60.5 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | 1.3 | +41.6 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 1.3 | +26.5 | 0.0 | 180.0 | - | - | - | - |
| MARCH WHEELS ONLY | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 1.7 | +45.1 | 0.0 | 0.0 | 3.0 | +105.3 | 0.0 | 40.0 |
| MEETS IN TIME | 3.7 | +210.7 | 0.0 | 18.3 | 2.3 | +191.0 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 2.3 | +22.5 | 0.0 | 0.0 | 3.3 | +12.8 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 4.0 | +50.9 | 0.0 | 180.0 | 4.0 | +14.4 | 0.0 | 0.0 |
| MOVE ORDER | 2.0 | +0.0 | 0.0 | 180.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 4.3 | +390.0 | 0.0 | 0.0 | 8.7 | +628.2 | 0.0 | 30.0 |
| MOVES UNITS SPELL | 0.3 | +1.4 | 0.0 | 0.0 | - | - | - | - |
| NEARER NOT NEEDED | 9.7 | +372.5 | 0.0 | 78.3 | 11.7 | +391.5 | 0.0 | 86.7 |
| NEXT CHARGE BY LIST | 1.3 | +192.7 | 0.0 | 0.0 | 4.7 | +332.4 | 0.0 | 30.0 |
| NO DOUBLE ROUNDS | 0.7 | -7.8 | 22.0 | 29.7 | 6.0 | -349.3 | 933.3 | 49.0 |
| NO LATE CUT | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| NO RALLY LEFT | 0.3 | +24.6 | 0.0 | 0.0 | - | - | - | - |
| NO SECOND RUN | 5.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 2.3 | -1.1 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 5.3 | -81.8 | 0.0 | 110.7 | 4.7 | -210.9 | 0.0 | 64.0 |
| ONE CHECK AFTER THE LAST CHANGE | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ONE FIGHT FORMULA | 6.0 | -69.3 | 0.0 | 180.0 | 6.7 | -130.5 | 0.0 | 40.0 |
| ONE JOINT FIGURE | - | - | - | - | 1.3 | -13.1 | 180.0 | 16.7 |
| ONE OBJECTIVE FORMULA | 6.3 | -93.3 | 0.0 | 51.3 | 3.3 | -45.0 | 0.0 | 64.0 |
| ONE PROMISE A TARGET | - | - | - | - | 0.7 | -9.0 | 0.0 | 0.0 |
| ONE ROUTE | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| OPENS UP | - | - | - | - | 0.3 | +23.2 | 36.7 | 0.0 |
| OVERRUNS AWAY | 0.3 | +0.9 | 22.0 | 11.3 | 3.3 | +24.6 | 494.7 | 49.0 |
| PERIAPT WORTH | 0.3 | +18.1 | 0.0 | 0.0 | - | - | - | - |
| PLAN RESULT | 37.3 | +144.1 | 59.0 | 1293.0 | 46.0 | +1081.5 | 1065.7 | 324.0 |
| PROMISE BELOW ZERO | - | - | - | - | 1.0 | +0.0 | 0.0 | 15.0 |
| PROMISE BY ITS OWN SUM | 6.3 | -230.1 | 0.0 | 0.0 | 14.0 | -605.3 | 0.0 | 0.0 |
| PROMISE IN STEPS | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | 1.3 | +0.0 | 0.0 | 0.0 | 3.3 | -5.1 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | 1.3 | -26.5 | 0.0 | 0.0 | 0.3 | -1.9 | 0.0 | 0.0 |
| PROMISE SHOT AWAY | 0.3 | -3.1 | 0.0 | 61.7 | 2.0 | -1.3 | 246.7 | 0.0 |
| QUARTER ODDS | 21.0 | +2266.3 | 0.0 | 125.3 | 28.0 | +3355.1 | 580.0 | 0.0 |
| RANDOM MOVE BY FIGURES | 2.0 | +24.7 | 0.0 | 70.0 | - | - | - | - |
| REAL GROUND | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | 4.0 | +176.0 | 0.0 | 48.0 | 3.3 | +105.8 | 0.0 | 113.7 |
| REDIRECT FOR A FRIEND IN REACH | 3.0 | +0.0 | 0.0 | 103.3 | 4.3 | +0.0 | 0.0 | 96.7 |
| REDIRECT WEIGHED | - | - | - | - | 0.7 | +0.0 | 0.0 | 49.0 |
| REFORMS TO MEET IT | - | - | - | - | 0.7 | -29.6 | 0.0 | 0.0 |
| RESERVE FALL BACK | - | - | - | - | 1.3 | +40.6 | 0.0 | 0.0 |
| RESTRAINS TO SHOOT | - | - | - | - | 0.3 | +9.0 | 0.0 | 0.0 |
| RISK BY ARC | 0.7 | +22.9 | 22.0 | 18.3 | 6.3 | -111.0 | 1075.7 | 65.7 |
| RISK ON THE WAY | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| ROUNDS AFTER TERROR | - | - | - | - | 5.0 | -164.3 | 418.3 | 16.7 |
| RUN DOWN | - | - | - | - | 6.0 | -50.2 | 491.3 | 65.7 |
| SAME TERRAIN AS THE BOARD | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SCOUT SPOT | 0.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| SCOUT WAITS | 1.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| SEARCH SPOT | 1.0 | +3.9 | 0.0 | 0.0 | 1.7 | +75.2 | 0.0 | 22.0 |
| SECOND LOOK | 0.3 | +1.0 | 0.0 | 0.0 | - | - | - | - |
| SELF MOVE SPELL | 1.7 | -3.4 | 0.0 | 217.3 | - | - | - | - |
| SET CREDITED ONCE | - | - | - | - | 0.3 | -21.1 | 0.0 | 0.0 |
| SET UP BY THE SET | 1.0 | -2.1 | 0.0 | 0.0 | 1.0 | -22.0 | 0.0 | 0.0 |
| SET UP TOGETHER | - | - | - | - | 0.3 | +2.3 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | - | - | - | - | 0.3 | +1.7 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 5.3 | +0.0 | 0.0 | 0.0 | 6.7 | +0.0 | 0.0 | 20.0 |
| SHOOTS FROM THE BEST SPOT | 3.0 | +41.6 | 30.0 | 0.0 | 1.7 | +29.5 | 131.0 | 0.0 |
| SHOT OR CHARGE | - | - | - | - | 1.7 | -33.6 | 192.7 | 0.0 |
| SHOT RISK POINTS | 18.0 | -129.7 | 0.0 | 579.3 | 18.0 | +33.0 | 0.0 | 104.0 |
| SHOTS AFTER THE MOVES | 2.7 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 13.3 | +514.5 | 0.0 | 87.3 | 13.7 | +106.2 | 0.0 | 106.0 |
| SPELL WORTH | 0.7 | +10.4 | 180.0 | 180.0 | - | - | - | - |
| SPELLS IN THE FIGHT | - | - | - | - | 1.3 | -47.8 | 180.0 | 0.0 |
| SPOT AS THE GAME MOVES | 6.3 | +0.0 | 0.0 | 144.7 | 5.3 | +0.0 | 0.0 | 111.7 |
| STAND AND SHOOT | 0.3 | -0.5 | 0.0 | 18.3 | 1.0 | -6.3 | 61.7 | 0.0 |
| STANDS FOR A REASON | 1.0 | +0.0 | 22.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 28.7 | +0.0 | 126.0 | 228.0 | 42.7 | +0.0 | 773.7 | 40.0 |
| STAY WORTH | 8.7 | +27.1 | 22.0 | 0.0 | 20.0 | +117.6 | 528.3 | 42.0 |
| STRIKE BY THE ODDS | - | - | - | - | 1.7 | +48.3 | 108.7 | 0.0 |
| STUPIDITY NEXT TURN | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 7.0 | +1013.1 | 0.0 | 0.0 | 3.0 | +88.0 | 0.0 | 22.0 |
| SUPPORT NARROWED | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 65.7 |
| SUPPORT WORKED OUT | 7.0 | +1013.1 | 0.0 | 0.0 | 3.0 | +88.0 | 0.0 | 22.0 |
| SURE REACH TOGETHER | 0.3 | +1.3 | 0.0 | 0.0 | 0.3 | +1.0 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| THE PROMISE ADDS | 0.3 | -10.1 | 0.0 | 0.0 | - | - | - | - |
| THE PROMISED MOVE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE ROW IN ITS ORDER | 4.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 4.3 | +0.0 | 0.0 | 140.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 3.7 | +0.0 | 0.0 | 61.7 | 0.3 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 5.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 38.0 | +0.0 | 0.0 | 597.7 | 46.0 | +0.0 | 0.0 | 200.3 |
| TIED UP BY THE SUM | 0.3 | +82.5 | 22.0 | 0.0 | 2.3 | +244.3 | 319.7 | 0.0 |
| TIME ON OUR SIDE | 33.7 | +350.1 | 44.0 | 241.7 | 23.3 | +193.3 | 0.0 | 84.0 |
| WAITS AGAIN | 2.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| WAR ENGINE JOBS | 1.3 | +0.0 | 0.0 | 61.7 | - | - | - | - |
| WEAPON BY POINTS | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| WHAT THE JOINER ADDS | 0.7 | -34.5 | 0.0 | 0.0 | 0.7 | +2.3 | 22.7 | 0.0 |
| WHO FIGHTS | 0.7 | -2.4 | 22.0 | 29.7 | 2.3 | +3.5 | 320.7 | 0.0 |
| WHO HITS BACK | 0.7 | +23.6 | 0.0 | 0.0 | 1.7 | +153.8 | 0.0 | 0.0 |
| WHOLE FIGHT | 0.3 | +18.0 | 0.0 | 0.0 | 0.3 | +1.3 | 11.3 | 0.0 |
| WHOLE FIGHT DANGER | 5.3 | -1083.4 | 0.0 | 421.7 | 2.7 | -213.9 | 0.0 | 0.0 |
| WHOLE FIGHT GAIN | - | - | - | - | 0.7 | +78.4 | 180.0 | 0.0 |
| WOUNDS ON THE RANKS | 4.3 | +123.4 | 0.0 | 0.0 | 1.0 | +0.6 | 0.0 | 0.0 |

### Rule changes: csame-bb45c30-p10

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS MOVE AS HE DECIDES | 126 | 126 | 77 | 25.67 | +0 | +0.0 |
| ARMY TABLE | 117 | 117 | 70 | 23.33 | +462 | +6.6 |
| HIS MOVE WHY | 107 | 107 | 64 | 21.33 | +0 | +0.0 |
| FIVE ACTION | 534 | 501 | 49 | 16.33 | +3018 | +61.6 |
| HOLDER ASSIGNMENT | 55 | 55 | 49 | 16.33 | +3137 | +64.0 |
| LEGAL CHARGES ONLY | 42 | 42 | 42 | 14.00 | +0 | +0.0 |
| HIS SHOTS BY HIS RUN | 209 | 196 | 34 | 11.33 | +289 | +8.5 |
| HIS SHOT LIST | 194 | 174 | 32 | 10.67 | +203 | +6.3 |
| OFF BEST | 30 | 30 | 30 | 10.00 | -878 | -29.3 |
| PROMISE BY ITS OWN SUM | 61 | 61 | 29 | 9.67 | -2506 | -86.4 |
| THE TABLE AGAIN | 33 | 33 | 29 | 9.67 | +0 | +0.0 |
| REDIRECT FOR A FRIEND IN REACH | 22 | 22 | 22 | 7.33 | +0 | +0.0 |
| MOVE TO CHARGE COMPUTED | 39 | 30 | 20 | 6.67 | +690 | +34.5 |
| DEPLOY BY FIGURES | 45 | 45 | 19 | 6.33 | +155 | +8.1 |
| QUARTER ODDS | 147 | 135 | 18 | 6.00 | +1868 | +103.8 |
| TIME ON OUR SIDE | 171 | 150 | 18 | 6.00 | +67 | +3.7 |
| GOAL WALK | 55 | 51 | 17 | 5.67 | +419 | +24.7 |
| HARD STAY DROPPED | 17 | 17 | 17 | 5.67 | +0 | +0.0 |
| HIS ONE MOVE | 65 | 62 | 16 | 5.33 | +0 | +0.0 |
| SHOT RISK POINTS | 108 | 105 | 15 | 5.00 | +217 | +14.4 |
| FOUR ROUNDS | 26 | 25 | 12 | 4.00 | +620 | +51.7 |
| MOVE ORDER | 12 | 12 | 12 | 4.00 | +0 | +0.0 |
| SUPPORT ADDS | 30 | 30 | 12 | 4.00 | +642 | +53.5 |
| SUPPORT WORKED OUT | 30 | 30 | 12 | 4.00 | +642 | +53.5 |
| FOLLOW UP WEIGHED | 10 | 10 | 10 | 3.33 | +2224 | +222.4 |
| CHARGE LOSSES | 82 | 77 | 9 | 3.00 | +1176 | +130.7 |
| NEXT CHARGE BY LIST | 18 | 15 | 9 | 3.00 | +515 | +57.2 |
| ADVANCE LANE KEPT | 8 | 8 | 8 | 2.67 | +0 | +0.0 |
| JOINT CHARGE NOW | 8 | 8 | 8 | 2.67 | -7 | -0.9 |
| MEETS IN TIME | 18 | 18 | 8 | 2.67 | +507 | +63.4 |
| SHOTS IN THE MOVE | 81 | 61 | 8 | 2.67 | +294 | +36.8 |
| TIED UP BY THE SUM | 8 | 8 | 8 | 2.67 | +237 | +29.7 |
| COVER ONCE | 44 | 36 | 7 | 2.33 | +116 | +16.6 |
| PROMISE SHOT AWAY | 7 | 7 | 7 | 2.33 | -13 | -1.9 |
| SCOUT WAITS | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| SHOOTS FROM THE BEST SPOT | 14 | 14 | 7 | 2.33 | +12 | +1.6 |
| STAY WORTH | 86 | 76 | 7 | 2.33 | +44 | +6.2 |
| WHO HITS BACK | 7 | 7 | 7 | 2.33 | +335 | +47.8 |
| EXACT ROUND | 21 | 20 | 6 | 2.00 | +71 | +11.8 |
| LANE BY FIGURES | 6 | 6 | 6 | 2.00 | +286 | +47.6 |
| CHARGE NOW FIRST | 15 | 15 | 5 | 1.67 | -137 | -27.3 |
| MAX FOR POSITIONING | 14 | 12 | 5 | 1.67 | +20 | +4.0 |
| CAST JOB | 5 | 5 | 4 | 1.33 | +0 | +0.0 |
| CASTER AWAY FROM SCREEN | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| COMBAT PIVOT | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| RESERVE FALL BACK | 4 | 4 | 4 | 1.33 | +122 | +30.4 |
| SEARCH SPOT | 8 | 8 | 4 | 1.33 | +237 | +59.3 |
| WHOLE FIGHT DANGER | 24 | 22 | 4 | 1.33 | +479 | +119.6 |
| HOLDS AMBUSHERS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| LONE WIZARD KEPT IN | 3 | 3 | 3 | 1.00 | +166 | +55.3 |
| MANOEUVRE | 12 | 12 | 3 | 1.00 | +40 | +13.3 |
| MARCH BY THE SUM | 3 | 3 | 3 | 1.00 | +182 | +60.5 |
| ONE FIGHT FORMULA | 38 | 21 | 3 | 1.00 | +31 | +10.3 |
| ONE OBJECTIVE FORMULA | 29 | 20 | 3 | 1.00 | +101 | +33.8 |
| PROMISE KNOWS THE FIGHT | 14 | 11 | 3 | 1.00 | -15 | -5.1 |
| RISK BY ARC | 21 | 21 | 3 | 1.00 | +29 | +9.5 |
| WOUNDS ON THE RANKS | 16 | 16 | 3 | 1.00 | +20 | +6.5 |
| AFTERMATH IN POINTS | 2 | 2 | 2 | 0.67 | +170 | +85.0 |
| CASTS FROM BEHIND | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| CHAFF PASSED | 2 | 2 | 2 | 0.67 | -3 | -1.6 |
| CHARGE NOT DECLARED | 2 | 2 | 2 | 0.67 | -53 | -26.4 |
| HONEST WORTH | 18 | 18 | 2 | 0.67 | +19 | +9.5 |
| IDLE COST | 34 | 17 | 2 | 0.67 | +4 | +2.1 |
| MARCH CHECK | 4 | 4 | 2 | 0.67 | +17 | +8.6 |
| NEARER NOT NEEDED | 64 | 62 | 2 | 0.67 | +55 | +27.6 |
| NO DOUBLE ROUNDS | 20 | 20 | 2 | 0.67 | +24 | +12.2 |
| ONE JOINT FIGURE | 4 | 4 | 2 | 0.67 | +8 | +3.9 |
| ONE PROMISE A TARGET | 2 | 2 | 2 | 0.67 | -27 | -13.5 |
| REDIRECT WEIGHED | 2 | 2 | 2 | 0.67 | +146 | +72.9 |
| SET UP BY THE SET | 6 | 6 | 2 | 0.67 | +236 | +118.2 |
| SHOTS AFTER THE MOVES | 17 | 17 | 2 | 0.67 | +0 | +0.0 |
| STRIKE BY THE ODDS | 5 | 5 | 2 | 0.67 | +179 | +89.5 |
| SUPPORT NARROWED | 4 | 4 | 2 | 0.67 | -511 | -255.4 |
| THE ROW IN ITS ORDER | 15 | 2 | 2 | 0.67 | +0 | +0.0 |
| WHOLE FIGHT GAIN | 2 | 2 | 2 | 0.67 | +82 | +41.1 |
| AFTERMATH WITH FRIENDS | 1 | 1 | 1 | 0.33 | +93 | +92.6 |
| CASTING BLOCK | 3 | 3 | 1 | 0.33 | +1 | +0.9 |
| CHALLENGE BY POINTS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CONTINUE AHEAD WEIGHED | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| EDGE GIVE GROUND | 1 | 1 | 1 | 0.33 | +1 | +1.2 |
| FALLS SHORT | 49 | 44 | 1 | 0.33 | +35 | +35.2 |
| FEATURE BUFFS | 7 | 7 | 1 | 0.33 | +2 | +2.0 |
| FIGHT TO THE END | 12 | 11 | 1 | 0.33 | +1 | +1.2 |
| HIS CHARGE DENIED | 2 | 2 | 1 | 0.33 | +20 | +20.5 |
| HIS MOVE AND SHOT | 29 | 28 | 1 | 0.33 | +51 | +50.8 |
| HIS TURN DENIED | 9 | 9 | 1 | 0.33 | +23 | +23.2 |
| LONG SHOT | 4 | 4 | 1 | 0.33 | +2 | +1.8 |
| LOST AFTER ESCAPE | 15 | 15 | 1 | 0.33 | +0 | +0.0 |
| MOVES UNITS SPELL | 1 | 1 | 1 | 0.33 | +4 | +4.3 |
| NO RALLY LEFT | 1 | 1 | 1 | 0.33 | +40 | +39.8 |
| OPENS UP | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| OVERRUNS AWAY | 11 | 11 | 1 | 0.33 | +11 | +10.9 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.33 | +54 | +54.4 |
| RANDOM MOVE BY FIGURES | 6 | 6 | 1 | 0.33 | +74 | +74.2 |
| REDIRECT COUNTER | 22 | 20 | 1 | 0.33 | +32 | +32.3 |
| RESTRAINS TO SHOOT | 1 | 1 | 1 | 0.33 | +27 | +27.1 |
| ROUNDS AFTER TERROR | 15 | 15 | 1 | 0.33 | +20 | +19.7 |
| SECOND LOOK | 1 | 1 | 1 | 0.33 | +3 | +2.9 |
| SHOOTERS IN TWO RANKS | 1 | 1 | 1 | 0.33 | +5 | +5.0 |
| SURE REACH TOGETHER | 2 | 2 | 1 | 0.33 | +0 | +0.0 |
| WEAPON BY POINTS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| WHO FIGHTS | 9 | 9 | 1 | 0.33 | +2 | +1.8 |
| BACKUP TARGETS | 4 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 4 | trace | - | - | - | - |
| CHAFF IN THE MOVE | 1 | not checked | - | - | - | - |
| CHAMPION KNOWS CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 60 | 59 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 3 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 5 | 5 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 1 | 1 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 21 | 20 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 52 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 46 | 41 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 7 | 6 | 0 | 0.00 | - | - |
| GIVES UP | 3 | 3 | 0 | 0.00 | - | - |
| GUN FIGURES | 7 | not checked | - | - | - | - |
| HE REFORMS ONCE FREED | 36 | 30 | 0 | 0.00 | - | - |
| HELPER UNSEEN | 2 | 1 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 51 | 50 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 18 | 16 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 28 | 25 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 42 | 35 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 27 | 25 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 21 | 18 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 15 | 12 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN RUN | 34 | 34 | 0 | 0.00 | - | - |
| HOLD ODDS | 91 | 91 | 0 | 0.00 | - | - |
| HUNT IN PAIRS | 2 | 2 | 0 | 0.00 | - | - |
| JOINT KNOWS CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 6 | 6 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 2 | 2 | 0 | 0.00 | - | - |
| LOST CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 4 | 4 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 4 | 4 | 0 | 0.00 | - | - |
| MISSILES IN THE MOVE | 17 | 10 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 24 | 16 | 0 | 0.00 | - | - |
| NO LATE CUT | 2 | 2 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 18 | 18 | 0 | 0.00 | - | - |
| NO SECOND RUN | 33 | 33 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 7 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 2 | not checked | - | - | - | - |
| ONE ROUTE | 4 | 4 | 0 | 0.00 | - | - |
| PLAN RESULT | 250 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 3 | 3 | 0 | 0.00 | - | - |
| PROMISE IN STEPS | 3 | 3 | 0 | 0.00 | - | - |
| PROMISE READS THE TABLE | 5 | 5 | 0 | 0.00 | - | - |
| REAL GROUND | 4 | 4 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 2 | 2 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 1 | 1 | 0 | 0.00 | - | - |
| RUN DOWN | 18 | 18 | 0 | 0.00 | - | - |
| SAME TERRAIN AS THE BOARD | 1 | not checked | - | - | - | - |
| SCOUT SPOT | 6 | 6 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 5 | not checked | - | - | - | - |
| SET CREDITED ONCE | 1 | 1 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 1 | 1 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 36 | not checked | - | - | - | - |
| SHOT OR CHARGE | 5 | 5 | 0 | 0.00 | - | - |
| SPELL WORTH | 2 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 4 | 4 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 35 | 33 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 4 | 4 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 6 | 5 | 0 | 0.00 | - | - |
| STANDS STILL | 214 | 202 | 0 | 0.00 | - | - |
| STUPIDITY NEXT TURN | 3 | 1 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 4 | not checked | - | - | - | - |
| THE PROMISE ADDS | 1 | 1 | 0 | 0.00 | - | - |
| THE PROMISED MOVE | 1 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 18 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 12 | not checked | - | - | - | - |
| THE TABLE BINDS | 252 | not checked | - | - | - | - |
| WAITS AGAIN | 9 | 9 | 0 | 0.00 | - | - |
| WAR ENGINE JOBS | 4 | 4 | 0 | 0.00 | - | - |
| WHAT THE JOINER ADDS | 4 | 2 | 0 | 0.00 | - | - |
| WHOLE FIGHT | 2 | 1 | 0 | 0.00 | - | - |

### Off best figure: csame-bb45c30-p10

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| PROMISE BY ITS OWN SUM | rule | 2.67 | 7.00 | 86.4 |
| JOB FIRST | gate | 2.67 | 4.33 | 35.9 |
| RULE SWITCHED OFF | gate | 2.67 | 0.33 | 13.7 |
| ARMY TABLE | rule | 2.00 | - | 104.5 |
| CHARGE NOW FIRST | rule | - | 1.67 | 27.3 |
| PROMISE SHOT AWAY | rule | 0.33 | 1.33 | 2.4 |
| JOINT CHARGE NOW | rule | - | 1.33 | 106.5 |
| PROMISE KNOWS THE FIGHT | rule | - | 1.00 | 5.1 |
| CHAFF PASSED | rule | 0.33 | 0.33 | 1.6 |
| CHARGE NOT DECLARED | rule | 0.67 | - | 26.4 |
| ONE PROMISE A TARGET | rule | - | 0.67 | 13.5 |
| SUPPORT NARROWED | rule | 0.67 | - | 255.4 |
| DEPLOY BY FIGURES | rule | 0.33 | - | 1.1 |
| HOLDER ASSIGNMENT | rule | - | 0.33 | 28.1 |

### Plans: csame-bb45c30-p10

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.3 | 50% | 39 | 44 | 112% |
| Mine | move | 31.3 | 93% | 2251 | 0 | 0% |
| Mine | shoot | 4.7 | 57% | 457 | 100 | 22% |
| Opponent | charge | 6.7 | 60% | 1120 | 879 | 78% |
| Opponent | join | 2.0 | 100% | 76 | 0 | 0% |
| Opponent | move | 30.7 | 97% | 1217 | 0 | 0% |
| Opponent | shoot | 6.7 | 60% | 430 | 202 | 47% |

### Battle groups: csame-bb45c30-p10

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 4.0 | 8% | 100% | 0% | - | 0% | 0% | 100% | 0% | 0% |
| Opponent | REDIRECT COUNTER | 3.3 | 40% | 50% | 25% | 0% | 33% | 0% | 33% | 33% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: csame-bb45c30-p10

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 0% | 4.0 | - | 0 (1) | - | - | 0 (1) |
| Mine | Chaff | 7 | 29 (7) | 20 | 9 | 76 | 29% | 2.6 | 33 (6) | 0 (1) | - | 29 (7) | - |
| Mine | Character | 8 | 8 (8) | 8 | 0 | 99 | 0% | 2.4 | 0 (3) | - | 13 (2) | 56 (1) | 0 (4) |
| Mine | Clean-up | 4 | 145 (4) | 24 | 121 | 0 | 75% | 4.0 | 93 (2) | 202 (1) | 395 (1) | 188 (1) | 126 (3) |
| Mine | Fast Hammer | 1 | 5 (1) | 5 | 0 | 115 | 0% | 2.0 | 5 (1) | - | - | - | 5 (1) |
| Mine | Hammer | 11 | 13 (11) | 10 | 3 | 60 | 0% | 2.0 | 10 (3) | 15 (7) | 0 (1) | 8 (4) | 15 (7) |
| Mine | Shooter | 3 | 23 (3) | 23 | 0 | 0 | 0% | 2.0 | 0 (2) | 69 (1) | - | 0 (1) | 35 (2) |
| Mine | Wizard | 2 | 4 (2) | 4 | 0 | 126 | 0% | 2.0 | - | - | - | - | - |
| Opponent | Chaff | 8 | 91 (8) | 11 | 81 | 62 | 12% | 1.9 | 63 (2) | 146 (4) | 0 (2) | 139 (5) | 0 (3) |
| Opponent | Character | 8 | 110 (8) | 110 | 0 | 2 | 12% | 3.1 | 12 (5) | 268 (3) | - | 0 (3) | 173 (5) |
| Opponent | Clean-up | 4 | 0 (4) | 0 | 0 | 27 | 75% | 4.0 | 0 (2) | 0 (2) | - | 0 (2) | 0 (2) |
| Opponent | Fast Hammer | 7 | 91 (7) | 91 | 0 | 6 | 14% | 3.2 | 20 (2) | 145 (5) | - | 27 (4) | 137 (3) |
| Opponent | Holder | 4 | 123 (4) | 21 | 102 | 23 | 0% | 1.8 | 225 (2) | - | 38 (2) | 225 (2) | 38 (2) |
| Opponent | Shooter | 4 | 7 (4) | 7 | 0 | 0 | 0% | 1.5 | 14 (2) | 0 (2) | - | 28 (2) | 0 (2) |
| Opponent | Wizard | 3 | 0 (3) | 0 | 0 | 0 | 33% | 2.0 | 0 (1) | 0 (1) | 0 (1) | - | 0 (3) |

### Charged fights: csame-bb45c30-p10

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Ogre Kingdoms | 1 | 70 | 66 | 2.0 | 1.5 | 33 | 187 | -154 | 1 of 2 | 1 of 2 | +66 | -374 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 126 | 4.0 | 1.0 | 32 | 101 | -70 | 1 of 4 | 2 of 4 | - | -70 |
| Mine | Skaven | 1 | 45 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| **Mine** | all armies | 3 | 38 | 64 | 2.0 | 1.2 | 32 | 130 | -98 | 2 of 6 | 3 of 6 | +66 | -131 |
| Opponent | Tomb Kings of Khemri | 2 | 44 | 1232 | 4.5 | 1.2 | 274 | 0 | +274 | 5 of 9 | 7 of 9 | +295 | +268 |
| Opponent | Vampire Counts | 1 | 0 | 750 | 4.0 | 1.2 | 188 | 85 | +102 | 2 of 4 | 2 of 4 | +540 | -43 |
| **Opponent** | all armies | 3 | 30 | 1071 | 4.3 | 1.2 | 247 | 26 | +221 | 7 of 13 | 9 of 13 | +377 | +174 |

### Effective charges: csame-bb45c30-p10

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Ogre Kingdoms | 2 | 0 | 0 | 1 (net +66) | 0 | 0 | 0 | 1 | 100% (1 of 1) |
| Mine | Orc & Goblin Tribes | 4 | 0 | 0 | 0 | 1 (net -55) | 1 (net +66) | 0 | 2 | 0% (0 of 2) |
| Opponent | Tomb Kings of Khemri | 9 | 1 (net +1240) | 0 | 1 (net +405) | 0 | 2 (net +148) | 5 (net +105) | 0 | 11% (1 of 9) |
| Opponent | Vampire Counts | 4 | 1 (net -193) | 0 | 0 | 1 (net +540) | 0 | 1 (net +210) | 1 | 0% (0 of 3) |

### Charged fights, damage counted: csame-bb45c30-p10

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Effective (55-75%) | 1 | 68 | 66 | +66 | 66 | 0 | +66 | +97.1 |
| Mine | 76-89% | 1 | 55 | 66 | -55 | 0 | 55 | -55 | -100.0 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 343 | 66 | +66 | 66 | 28 | +38 | +11.2 |
| Mine | No odds | 3 | 261 | 232 | -221 | 63 | 241 | -178 | -68.2 |
| Mine | All fights | 6 | 208 | 149 | -98 | 54 | 134 | -81 | -38.8 |
| Opponent | Long shot (under 50%) | 2 | 245 | 189 | +524 | 701 | 202 | +499 | +203.8 |
| Opponent | Effective (55-75%) | 1 | 390 | 297 | +405 | 405 | 0 | +405 | +103.8 |
| Opponent | 76-89% | 1 | 548 | 440 | +540 | 556 | 0 | +556 | +101.5 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 6 | 303 | 206 | +122 | 163 | 5 | +157 | +51.9 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 2 | 533 | 122 | +148 | 148 | 0 | +148 | +27.7 |
| Opponent | No odds | 1 | 147 | 192 | -147 | 0 | 147 | -147 | -100.0 |
| Opponent | All fights | 13 | 343 | 214 | +221 | 280 | 45 | +235 | +68.4 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| csame-bb45c30-p10 | move | 22 | 9 (41%) | 8 (36%) | 2 (9%) | 11 (50%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L2025 |
| Elixir of Power | Mine | L1923 |
| Fistful of Laurels | Mine | L1823 |
| Invocation of Nehek | Opponent | L2025 |
| Periapt of Soul Exchange | Mine | L2025 |

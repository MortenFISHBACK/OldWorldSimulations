# Doctrine scorecard: csame-bb45c30-p6

### Scorecard: csame-bb45c30-p6

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0913 | 1 | 1 | Mine | no | 2 | 4 | 1 | 1 | 0 | 0 | 0 | 420 |
| L0913 | 1 | 1 | Opponent | no | 18 | 3 | 1 | 0 | 2 | 0 | 0 | 140 |
| L0930 | 6 | 1 | Mine | no | 0 | 3 | 2 | 0 | 0 | 0 | 0 | 310 |
| L0930 | 6 | 1 | Opponent | no | 12 | - | 0 | 3 | 0 | 0 | 0 | 0 |
| L1021 | 1 | 1 | Mine | no | 6 | 3 | 1 | 0 | 0 | 0 | 0 | 330 |
| L1021 | 1 | 1 | Opponent | no | 4 | - | 0 | 5 | 1 | 0 | 0 | 290 |
| **Average** | | | Mine | 0% | 2.7 | 3.3 | 1.3 | 0.3 | 0.0 | 0.0 | 0.0 | 353.3 |
| **Average** | | | Opponent | 0% | 11.3 | 3.0 | 0.3 | 2.7 | 1.0 | 0.0 | 0.0 | 143.3 |

### KPIs: csame-bb45c30-p6

Rules off - Mine only: NO OLD ONE-MOVE GUESS; both sides: ONE RUN A PLAN.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 67% (10 of 15) | 0% (0 of 11) | 38% (10 of 26) |
| Winner chose to follow up after the loser gave ground |  | 100% (1 of 1); on the table 100% | - | 100% (1 of 1); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | - | - | - |
| Winner chose to pursue after the loser fled |  | - | - | - |
| Winner chose to follow up or pursue (all three) |  | 100% (1 of 1); on the table 100% | - | 100% (1 of 1); on the table 100% |
| Magic missiles tried each own turn | 50%+ | 44% (21 of 48) | 8% (1 of 12) | 37% (22 of 60) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 47% (21 of 45) | 11% (1 of 9) | 41% (22 of 54) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 54% (7 of 13) | 54% (7 of 13) |
| Points that never fought | lower | 83% (4980 of 5997) | 82% (4924 of 5999) | 83% (9904 of 11996) |
|   infantry points that never fought | lower | 80% (1278 of 1591) | 88% (1456 of 1660) | 84% (2734 of 3251) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 50% (17 of 34) | 65% (15 of 23) | 56% (32 of 57) |
| Bound items with a magic missile used (at least once a game) |  | 100% (2 of 2); 3.0 uses a game | 50% (1 of 2); 1.7 uses a game | 75% (3 of 4); 2.3 uses a game |
| Bound items with another spell used |  | 0% (0 of 1); 0.0 uses a game | 0% (0 of 2); 0.0 uses a game | 0% (0 of 3); 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0% (0 of 1); 0.0 uses a game | 100% (2 of 2); 0.7 uses a game | 67% (2 of 3); 0.3 uses a game |
|   their share of the points of units over 100 pts | lower | 52% (2960 of 5667) | 69% (3543 of 5150) | 60% (6503 of 10817) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 4.0 (44%) | 1.7 (45%) | 5.7 (45%) |
| MARCHED: its unit marched | 4.0 (44%) | 0.7 (18%) | 4.7 (37%) |
| IN COMBAT: engaged in combat | 1.0 (11%) | 0.0 (0%) | 1.0 (8%) |
| GONE: slain | 0.0 (0%) | 1.0 (27%) | 1.0 (8%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.3 (9%) | 0.3 (3%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 3.0 | 3.3 | 1.0 | 7.3 | 0.3 | 0.3 |
| not cast | 1.0 | 4.7 | 1.0 | 12.7 | 1.7 | 19.7 |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 3.7 (79%) | 0.0 (0%) | 5.7 (45%) | 0.0 (0%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 4.7 (37%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.0 (8%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | 1.0 (100%) | 0.0 (0%) | 1.0 (100%) | 1.0 (8%) | 0.0 (0%) | 2.7 (14%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 1.0 (21%) | 0.0 (0%) | 0.3 (3%) | 1.7 (100%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 17.0 (86%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.0 a game | 1.0 a game | 0.5 a game |
| stood (cast and not dispelled) | - | 67% (2 of 3) | 67% (2 of 3) |
| the unit moved after it | - | 50% (1 of 2) | 50% (1 of 2) |
| it charged on its next turn | - | 0% (0 of 2) | 0% (0 of 2) |
| the enemy charged it first | - | 0% (0 of 2) | 0% (0 of 2) |
| it fought by the end of its next turn | - | 0% (0 of 2) | 0% (0 of 2) |
| it moved out of a charge the enemy had planned (not charged first) | - | 0% (0 of 2) | 0% (0 of 2) |
| none of these (no charge, no fight, no charge escaped) | - | 100% (2 of 2) | 100% (2 of 2) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 63% (80 of 127) | 84% (36 of 43) | 68% (116 of 170) |
|   character | 100% (5 of 5) | 50% (4 of 8) | 69% (9 of 13) |
|   chariot | 83% (15 of 18) | 100% (7 of 7) | 88% (22 of 25) |
|   infantry | 47% (23 of 49) | 83% (15 of 18) | 57% (38 of 67) |
|   monster | 42% (5 of 12) | - | 42% (5 of 12) |
|   war machine | 74% (32 of 43) | 100% (10 of 10) | 79% (42 of 53) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 4.3 (28%) | 1.3 (57%) | 5.7 (31%) |
| CHARGED: it charged | 1.3 (9%) | 0.3 (14%) | 1.7 (9%) |
| IN COMBAT: it fought this turn or the last | 0.3 (2%) | 0.0 (0%) | 0.3 (2%) |
| MOVED: a war machine that moved | 1.3 (9%) | 0.0 (0%) | 1.3 (7%) |
| NO TARGET IN RANGE | 3.3 (21%) | 0.7 (29%) | 4.0 (22%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 4.0 (26%) | 0.0 (0%) | 4.0 (22%) |
| SHELTERED: the target was sheltered | 0.7 (4%) | 0.0 (0%) | 0.7 (4%) |
| OTHER BAR | 0.3 (2%) | 0.0 (0%) | 0.3 (2%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| character | 3.7 | 1.3 | 64% | 5.9 pts | 22 pts |
| chariot | 7.3 | 3.3 | 68% | 16.8 pts | 123 pts |
| infantry | 16.3 | 6.3 | 67% | 9.8 pts | 160 pts |
| monster | 3.3 | 0.7 | 80% | 6.0 pts | 20 pts |
| war machine | 14.3 | 13.3 | 60% | 33.7 pts | 483 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 2.3 | 1.0 | 1.7 |
| Charges that made contact a game | 1.0 | 0.7 | 0.8 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.33 declared, 0.33 contact (3 units) | 0.00 declared, 0.00 contact (2 units) | 0.20 declared, 0.20 contact (5 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 0.00 declared, 0.00 contact (1 units) | 0.00 declared, 0.00 contact (1 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.30 declared, 0.10 contact (20 units) | 0.13 declared, 0.09 contact (23 units) | 0.21 declared, 0.09 contact (43 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 20% (1 of 5) | - | - | 20% (1 of 5) |
| Character in a unit | 100% (6 of 6) | 100% (2 of 2) | - | 100% (8 of 8) |
| Character on its own | 100% (1 of 1) | 100% (4 of 4) | 50% (2 of 4) | 78% (7 of 9) |
| Chariot | 33% (1 of 3) | 50% (1 of 2) | - | 40% (2 of 5) |
| Infantry | 21% (3 of 14) | 75% (3 of 4) | - | 33% (6 of 18) |
| Monster | - | 100% (2 of 2) | - | 100% (2 of 2) |
| Monstrous | - | 100% (2 of 2) | - | 100% (2 of 2) |
| War Machines | 50% (4 of 8) | - | - | 50% (4 of 8) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Empire of Man | 2 | 100% (1 of 1); on the table 100% | 54% (13 of 24) | 87% | 54% (13 of 24) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Grand Cathay | 1 | - | 33% (8 of 24) | 75% | 40% (4 of 10) | 100% (2 of 2); 9.0 uses a game | 0% (0 of 1); 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| High Elf Realms | 1 | - | 17% (1 of 6) | 88% | 38% (3 of 8) | 100% (1 of 1); 5.0 uses a game | 0% (0 of 2); 0.0 uses a game | 0.0 uses a game |
| Skaven | 1 | - | 0% (0 of 6) | 83% | 78% (7 of 9) | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Warriors of Chaos | 1 | - | - | 76% | 83% (5 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |

Flank and rear charges a unit could have turned to face (csame-bb45c30-p6, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 100% (2) | 67% (2) | 80% (4) |
| ...free all their last turn and able to turn (per game) | 0.33 | 0.67 | 1.00 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.33 | 0.00 | 0.33 |
| ...with the charger already in that arc before they moved (per game) | 0.33 | 0.67 | 1.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: csame-bb45c30-p6

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.3 | 2.7 |
| Strategy | Charge objectives carried out (made contact) | 14% (1 of 7) | 50% (1 of 2) |
| Strategy | Shoot objectives carried out (shot that target) | 20% (10 of 50) | 50% (10 of 20) |
| Strategy | Support requests answered (helper made contact too) | 0% (0 of 1) | - |
| Strategy | Hexes on a unit its side charged or shot that turn | 67% (2 of 3) | - |
| Strategy | Joined characters whose unit fought | 12% (1 of 8) | 0% (0 of 4) |
| Strategy | Lone characters that fought | 33% (2 of 6) | 40% (2 of 5) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 0.3 | 2.7 |
| Movement | Points that never moved of their own | 353.3 | 143.3 |
| Movement | Fights charged into per game | 1.0 | 0.7 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 3 | 0 of 1 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 3 | 0 of 1 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 3 | 0 of 1 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 of 3, net -32 | 1 of 1, net +0 |
| Shooting | Shots by shooting units (incl. breath weapons) | 16.0 | 9.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 48% (23 of 48) | 55% (16 of 29) |
| Shooting | Points destroyed by shooting units | 15.0 | 41.7 |
| Shooting | War machine shots | 10.7 | 3.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 50% (16 of 32) | 30% (3 of 10) |
| Shooting | Points destroyed by war machines | 617.0 | 0.0 |
| Magic | Magic missiles cast | 4.3 | 0.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 46% (6 of 13) | 0% (0 of 1) |
| Magic | Wounds caused by magic missiles | 10.3 | 6.7 |
| Magic | Points destroyed by magic (all spells) | 88.3 | 76.3 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.0 / 1.0 / 0.0 / 0.3 | 2.3 / 2.0 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 48.3 | 80.0 |
| Combat | Points run down | 30.7 | 0.0 |
| Combat | Net points per charged fight, damage counted | +9 | -143 |
| Combat | Net per 100 charger points, damage counted | +4.0 | -79.9 |
| Combat | First round won (charged fights) | 100% | 100% |
| Combat | Net points per charged fight | -32 | -46 |
| Combat | Net points per supported fight / lone fight | - / -32 | - / -46 |
| Combat | Charged fights on a top-3 enemy unit | 1 of 3 | 0 of 2 |
| Game | Points lost | 164.7 | 749.3 |
| Game | VP from objectives | 720.0 | 910.0 |
| Game | Lone holders (player turns) | 2.7 | 11.3 |

- Mine won / drew / lost: 1 / 2 / 0 of 3 ended games (of 3); mean margin (Mine - Opponent) +409 VP
- The side that went first won 0 of 1 games with a winner
- Points traded per game (both sides' losses): 914
- Games not ended: 0; findings 1, warnings 0

### Opponent rules: csame-bb45c30-p6

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| AFTERMATH WITH FRIENDS | - | - | - | - | 0.3 | +25.4 | 0.0 | 30.7 |
| ARMY TABLE | 21.3 | +464.0 | 0.0 | 34.7 | 18.3 | +473.8 | 0.0 | 88.3 |
| ARTILLERY RE-ROLL WEIGHED | 4.0 | +0.0 | 0.0 | 41.7 | - | - | - | - |
| BACKUP TARGETS | 0.3 | +0.3 | 0.0 | 0.0 | 0.7 | +3.5 | 0.0 | 159.7 |
| CANNON PLAN MISSED | 0.3 | +0.0 | 133.3 | 41.7 | 0.7 | +0.0 | 83.3 | 23.3 |
| CANNON PLANNED TARGET | 11.0 | +691.4 | 1146.0 | 83.3 | 3.3 | +87.7 | 125.0 | 46.7 |
| CANNON SIGHT KEPT | 2.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| CAST JOB | 3.0 | +97.3 | 266.7 | 0.0 | 0.7 | +11.1 | 0.0 | 0.0 |
| CASTER AWAY FROM SCREEN | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | - | - | - | - | 0.7 | +0.0 | 0.0 | 133.3 |
| CHAFF IN THE MOVE | - | - | - | - | 1.3 | +20.0 | 0.0 | 0.0 |
| CHAFF PASSED | 0.3 | -0.1 | 0.0 | 0.0 | 0.7 | -6.3 | 41.7 | 0.0 |
| CHALLENGE BY POINTS | - | - | - | - | 0.7 | +4.3 | 0.0 | 319.3 |
| CHAMPION KNOWS CHALLENGE | 0.3 | +46.0 | 159.7 | 0.0 | - | - | - | - |
| CHARACTER GUNS | 4.7 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| CHARGE LIST READ AGAIN | 0.3 | +7.1 | 0.0 | 0.0 | - | - | - | - |
| CHARGE LOSSES | 16.0 | -591.7 | 0.0 | 0.0 | 31.3 | -2372.6 | 0.0 | 1818.3 |
| CHARGE NOW FIRST | 1.7 | +0.0 | 238.7 | 0.0 | 0.3 | +0.0 | 34.7 | 99.0 |
| CLOSES ON WHAT IT BEATS | 6.3 | +0.0 | 0.0 | 0.0 | 9.0 | +0.0 | 0.0 | 36.7 |
| CONVEYANCE SEARCH | - | - | - | - | 1.0 | +197.2 | 266.7 | 266.7 |
| COVER ONCE | 7.0 | -799.7 | 0.0 | 76.3 | 4.7 | -167.7 | 0.0 | 314.7 |
| DENIED BY THE FIGHT | 0.3 | -0.6 | 159.7 | 0.0 | 0.3 | -67.3 | 34.7 | 99.0 |
| DEPLOY BY FIGURES | 8.7 | -63.5 | 0.0 | 0.0 | 7.0 | +37.9 | 0.0 | 0.0 |
| EXACT ROUND | 1.7 | +17.7 | 178.0 | 0.0 | 0.7 | -1.6 | 0.0 | 0.0 |
| FALL BACK GOOD ORDER | 1.7 | +4.0 | 190.3 | 0.0 | 0.7 | +0.0 | 34.7 | 99.0 |
| FALLS SHORT | - | - | - | - | 27.3 | +324.3 | 0.0 | 577.7 |
| FEATURE BUFFS | 2.0 | +38.7 | 0.0 | 0.0 | 2.7 | +44.9 | 0.0 | 61.3 |
| FIGHT TO THE END | 0.3 | +1.6 | 159.7 | 0.0 | 0.3 | -0.4 | 0.0 | 0.0 |
| FIRE IN ORDER | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FIVE ACTION | 107.7 | +8603.7 | 4058.7 | 236.0 | 94.7 | +5239.5 | 534.7 | 2481.0 |
| FLANK NOT WEIGHED | 5.0 | +0.0 | 0.0 | 0.0 | 5.0 | +0.0 | 0.0 | 289.3 |
| FOLLOW UP WEIGHED | - | - | - | - | 0.3 | +12.6 | 0.0 | 0.0 |
| FOUR ROUNDS | 2.3 | +50.6 | 337.7 | 0.0 | 1.0 | +37.5 | 34.7 | 99.0 |
| FREED FROM HIS FIGHT | 1.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 40.0 |
| GOAL WALK | 9.7 | +1461.5 | 0.0 | 0.0 | 14.0 | +1739.1 | 0.0 | 61.3 |
| GUN FIGURES | 2.7 | +78.5 | 133.3 | 0.0 | 1.3 | +11.9 | 0.0 | 45.0 |
| GUN MASK | 7.3 | +111.6 | 0.0 | 0.0 | 0.3 | -3.4 | 0.0 | 0.0 |
| HARD STAY DROPPED | 1.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 7.3 | +0.0 | 0.0 | 0.0 | 12.3 | +0.0 | 0.0 | 761.7 |
| HIS CHARGE DENIED | 0.3 | +19.3 | 159.7 | 0.0 | - | - | - | - |
| HIS CHARGE LIST | 7.7 | +0.0 | 0.0 | 34.7 | 5.3 | +0.0 | 0.0 | 146.3 |
| HIS LEGAL MOVES | 3.3 | +0.0 | 0.0 | 0.0 | 5.7 | +0.0 | 0.0 | 533.3 |
| HIS MOVE AND SHOT | 2.7 | -20.9 | 0.0 | 0.0 | 8.0 | -246.2 | 0.0 | 1071.7 |
| HIS MOVE AS HE DECIDES | 41.3 | +10.3 | 1110.0 | 0.0 | - | - | - | - |
| HIS MOVE WHY | - | - | - | - | 42.0 | +0.0 | 0.0 | 888.0 |
| HIS ONE MOVE | 18.0 | -8.8 | 0.0 | 0.0 | - | - | - | - |
| HIS ONE QUARTER | 1.7 | +0.0 | 0.0 | 0.0 | 5.7 | +0.0 | 0.0 | 576.7 |
| HIS OWN BEST MOVE | 2.3 | +0.0 | 0.0 | 0.0 | 6.3 | +0.0 | 0.0 | 533.3 |
| HIS RANDOM MOVE | 21.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS RANDOM MOVER COMES | 5.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 37.7 | +1396.2 | 0.0 | 34.7 | 74.7 | +6201.2 | 0.0 | 2004.0 |
| HIS SHOTS BY HIS RUN | 29.3 | +612.3 | 0.0 | 34.7 | 72.0 | +2510.1 | 0.0 | 2029.0 |
| HIS TURN DENIED | - | - | - | - | 0.7 | +78.1 | 34.7 | 99.0 |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 20.7 | +0.0 | 0.0 | 0.0 | 32.7 | +0.0 | 0.0 | 122.7 |
| HOLDER ASSIGNMENT | 12.7 | +998.1 | 0.0 | 0.0 | 17.0 | +1583.5 | 0.0 | 30.7 |
| HOLDS AMBUSHERS | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 2.3 | -41.0 | 337.7 | 0.0 | 0.7 | -12.1 | 34.7 | 99.0 |
| IDLE COST | - | - | - | - | 12.3 | -257.2 | 0.0 | 203.3 |
| JOINT CHARGE NOW | 0.7 | +12.6 | 0.0 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 2.7 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 0.7 | +11.3 | 0.0 | 0.0 | 0.7 | +40.1 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | - | - | - | - | 2.3 | +0.0 | 0.0 | 988.7 |
| LONE WIZARD KEPT IN | 1.3 | +60.0 | 0.0 | 0.0 | 0.3 | +58.3 | 0.0 | 0.0 |
| LONG SHOT | 1.0 | -25.5 | 159.7 | 0.0 | - | - | - | - |
| LOST AFTER ESCAPE | 1.3 | +7.0 | 190.3 | 0.0 | 0.7 | +1.0 | 0.0 | 0.0 |
| LOST CHARGE | 0.3 | -1.8 | 99.0 | 0.0 | - | - | - | - |
| MANOEUVRE | 1.7 | -5.4 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 21.7 |
| MARCH AT ESCAPER | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MARCH BY THE SUM | 1.7 | +153.9 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | 0.3 | +14.5 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 2.7 | -248.3 | 0.0 | 0.0 | 0.3 | +29.6 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 1.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 3.3 | +29.9 | 0.0 | 0.0 | 0.7 | +11.8 | 0.0 | 266.7 |
| MEETS IN TIME | 4.3 | +509.9 | 0.0 | 0.0 | 3.3 | +324.0 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 10.7 | +282.8 | 0.0 | 0.0 | 2.7 | +64.4 | 0.0 | 133.3 |
| MISSILES NEXT TURN | 14.3 | +242.7 | 0.0 | 0.0 | 5.0 | +58.0 | 0.0 | 446.7 |
| MOVE ORDER | 2.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| MOVE SPELL SPOT | - | - | - | - | 0.7 | +0.0 | 0.0 | 133.3 |
| MOVE TO CHARGE COMPUTED | 3.7 | +144.1 | 0.0 | 0.0 | 2.7 | +325.8 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 13.0 | +589.2 | 0.0 | 0.0 | 7.0 | +309.3 | 0.0 | 30.7 |
| NEXT CHARGE BY LIST | 1.0 | +52.2 | 0.0 | 0.0 | 2.0 | +240.0 | 0.0 | 0.0 |
| NEXT OBJECTIVE NEARER | 0.3 | -10.0 | 0.0 | 0.0 | 0.7 | -0.4 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 2.0 | -122.2 | 337.7 | 0.0 | 0.7 | -30.7 | 34.7 | 99.0 |
| NO LATE CUT | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| NO RALLY LEFT | - | - | - | - | 0.3 | +12.2 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OFF BEST | 7.3 | -413.8 | 0.0 | 0.0 | 2.3 | -53.7 | 0.0 | 18.3 |
| OGRE LOADER SECOND SHOT | 2.7 | +142.2 | 180.0 | 0.0 | - | - | - | - |
| ONE CHALLENGE TEST | 0.3 | +46.0 | 159.7 | 0.0 | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ONE FIGHT FORMULA | 5.3 | -117.7 | 0.0 | 0.0 | 4.3 | -107.2 | 0.0 | 525.3 |
| ONE OBJECTIVE FORMULA | 5.7 | -54.4 | 0.0 | 0.0 | 8.0 | +32.5 | 0.0 | 30.7 |
| ONE ROUTE | 1.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| OVERRUNS AWAY | 0.3 | +12.3 | 30.7 | 0.0 | 1.0 | +8.2 | 34.7 | 99.0 |
| PATHS CROSS | 0.3 | +60.5 | 0.0 | 0.0 | - | - | - | - |
| PERIAPT WORTH | - | - | - | - | 0.3 | +18.0 | 0.0 | 0.0 |
| PLAN RESULT | 46.3 | +1736.1 | 2131.7 | 236.0 | 44.3 | +240.3 | 159.7 | 1540.3 |
| PROMISE BELOW ZERO | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE BY ITS OWN SUM | 8.3 | -222.8 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| QUARTER ODDS | 21.3 | +1921.2 | 738.3 | 0.0 | 15.0 | +1834.7 | 83.3 | 800.0 |
| RANDOM MOVE BY FIGURES | - | - | - | - | 4.3 | +107.5 | 0.0 | 193.3 |
| REAL GROUND | 1.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | - | - | - | - | 0.3 | -15.2 | 0.0 | 0.0 |
| REFORMS TO MEET IT | 0.3 | -6.9 | 0.0 | 0.0 | 0.7 | -22.0 | 0.0 | 0.0 |
| REFUSING RETIRES | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | 0.7 | -18.8 | 79.0 | 0.0 | 1.0 | -15.2 | 34.7 | 99.0 |
| ROUNDS AFTER TERROR | 0.7 | -2.8 | 99.0 | 0.0 | - | - | - | - |
| RUN DOWN | 2.0 | -19.4 | 238.7 | 0.0 | 1.0 | -11.4 | 34.7 | 99.0 |
| SCOUT SPOT | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SCOUT WAITS | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 2.0 | -114.0 | 0.0 | 0.0 |
| SEARCH SPOT | 0.7 | +1.1 | 0.0 | 0.0 | 0.7 | +28.5 | 0.0 | 0.0 |
| SET CREDITED ONCE | 0.7 | -55.2 | 0.0 | 0.0 | - | - | - | - |
| SET UP BY THE SET | 0.7 | +55.2 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.7 | +1.3 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS ON THE TABLE | 16.7 | +0.0 | 0.0 | 83.3 | 7.0 | +0.0 | 0.0 | 167.3 |
| SHOOTS FROM THE BEST SPOT | 2.0 | +43.7 | 18.3 | 0.0 | 2.0 | +105.2 | 83.3 | 0.0 |
| SHOT OR CHARGE | 1.0 | -70.9 | 479.0 | 0.0 | - | - | - | - |
| SHOT RISK POINTS | 16.3 | +177.0 | 0.0 | 0.0 | 46.3 | -682.8 | 0.0 | 1719.3 |
| SHOTS AFTER THE MOVES | 5.7 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 29.3 | +1925.4 | 0.0 | 118.0 | 11.3 | +414.2 | 0.0 | 482.0 |
| SPELL WORTH | - | - | - | - | 3.0 | +99.0 | 626.7 | 626.7 |
| SPELLS IN THE FIGHT | 0.3 | +1.3 | 48.3 | 0.0 | - | - | - | - |
| SPOT AS THE GAME MOVES | 5.0 | +0.0 | 0.0 | 0.0 | 7.7 | +0.0 | 0.0 | 300.0 |
| STAND AND SHOOT | 0.3 | -0.2 | 99.0 | 0.0 | - | - | - | - |
| STANDS FOR A REASON | - | - | - | - | 4.3 | +0.0 | 0.0 | 517.3 |
| STANDS STILL | 48.3 | +0.0 | 3721.0 | 201.3 | 37.3 | +0.0 | 500.0 | 1422.3 |
| STAY WORTH | 47.7 | +334.3 | 3049.7 | 250.0 | 17.0 | +345.1 | 416.7 | 295.0 |
| STUCK PIVOT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 1.0 | +32.6 | 0.0 | 0.0 | 3.7 | +192.3 | 0.0 | 0.0 |
| SUPPORT NARROWED | 0.3 | +0.0 | 30.7 | 0.0 | - | - | - | - |
| SUPPORT WORKED OUT | 1.0 | +32.6 | 0.0 | 0.0 | 3.7 | +192.3 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 1.7 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 40.0 |
| THE PROMISED MOVE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE ROW IN ITS ORDER | 3.7 | +0.0 | 0.0 | 0.0 | 6.3 | +0.0 | 0.0 | 70.7 |
| THE ROW KEEPS ITS WAY | 3.3 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 1.7 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 48.7 | +0.0 | 0.0 | 83.3 | 45.7 | +0.0 | 0.0 | 1094.3 |
| TIED UP BY THE SUM | 0.7 | +58.5 | 79.0 | 0.0 | 0.3 | +39.4 | 34.7 | 99.0 |
| TIME ON OUR SIDE | 40.0 | +569.4 | 0.0 | 34.7 | - | - | - | - |
| WAITS AGAIN | 1.7 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| WAR ENGINE JOBS | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WHAT THE JOINER ADDS | - | - | - | - | 0.7 | +0.6 | 0.0 | 0.0 |
| WHOLE FIGHT | - | - | - | - | 0.3 | +1.7 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | 5.3 | -394.8 | 0.0 | 0.0 | 4.0 | -364.6 | 0.0 | 686.7 |
| WOUNDS ON THE RANKS | 1.3 | +20.8 | 0.0 | 0.0 | 2.3 | +161.4 | 0.0 | 0.0 |

### Rule changes: csame-bb45c30-p6

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS MOVE WHY | 126 | 126 | 101 | 33.67 | +0 | +0.0 |
| HIS MOVE AS HE DECIDES | 124 | 124 | 93 | 31.00 | +0 | +0.0 |
| HIS SHOT LIST | 337 | 329 | 87 | 29.00 | +3432 | +39.5 |
| HOLDER ASSIGNMENT | 89 | 89 | 84 | 28.00 | +5163 | +61.5 |
| ARMY TABLE | 119 | 119 | 76 | 25.33 | +1469 | +19.3 |
| HIS SHOTS BY HIS RUN | 304 | 303 | 66 | 22.00 | +1139 | +17.3 |
| SHOT RISK POINTS | 188 | 185 | 45 | 15.00 | +2250 | +50.0 |
| DEPLOY BY FIGURES | 47 | 47 | 33 | 11.00 | +783 | +23.7 |
| OFF BEST | 29 | 29 | 29 | 9.67 | -1402 | -48.3 |
| THE TABLE AGAIN | 36 | 36 | 27 | 9.00 | +0 | +0.0 |
| GOAL WALK | 71 | 69 | 20 | 6.67 | +3023 | +151.2 |
| HIS ONE MOVE | 54 | 54 | 18 | 6.00 | +0 | +0.0 |
| QUARTER ODDS | 109 | 105 | 18 | 6.00 | +1638 | +91.0 |
| CHARGE LOSSES | 142 | 140 | 14 | 4.67 | +1312 | +93.7 |
| PROMISE BY ITS OWN SUM | 33 | 33 | 13 | 4.33 | -669 | -51.4 |
| ARTILLERY RE-ROLL WEIGHED | 12 | 12 | 12 | 4.00 | +0 | +0.0 |
| FIVE ACTION | 607 | 597 | 12 | 4.00 | +436 | +36.4 |
| CAST JOB | 11 | 11 | 11 | 3.67 | +90 | +8.2 |
| MEETS IN TIME | 23 | 23 | 11 | 3.67 | +1042 | +94.7 |
| TIME ON OUR SIDE | 120 | 100 | 11 | 3.67 | +9 | +0.8 |
| CANNON SIGHT KEPT | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| MOVE ORDER | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| MOVE TO CHARGE COMPUTED | 19 | 19 | 9 | 3.00 | +235 | +26.1 |
| STAY WORTH | 194 | 178 | 9 | 3.00 | +123 | +13.7 |
| OGRE LOADER SECOND SHOT | 8 | 8 | 8 | 2.67 | +426 | +53.3 |
| SHOTS AFTER THE MOVES | 24 | 24 | 8 | 2.67 | +0 | +0.0 |
| HARD STAY DROPPED | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| LEGAL CHARGES ONLY | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| RANDOM MOVE BY FIGURES | 13 | 13 | 7 | 2.33 | +322 | +46.0 |
| FOUR ROUNDS | 10 | 10 | 6 | 2.00 | +157 | +26.2 |
| SHOOTS FROM THE BEST SPOT | 12 | 12 | 6 | 2.00 | +114 | +19.0 |
| CANNON PLANNED TARGET | 43 | 43 | 5 | 1.67 | +176 | +35.2 |
| COVER ONCE | 35 | 24 | 5 | 1.67 | +134 | +26.8 |
| LONE WIZARD KEPT IN | 5 | 5 | 5 | 1.67 | +355 | +71.0 |
| MARCH BY THE SUM | 5 | 5 | 5 | 1.67 | +461 | +92.3 |
| CASTER AWAY FROM SCREEN | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| CHAFF IN THE MOVE | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| FALLS SHORT | 82 | 67 | 4 | 1.33 | +29 | +7.4 |
| LANE BY FIGURES | 4 | 4 | 4 | 1.33 | +154 | +38.5 |
| ONE OBJECTIVE FORMULA | 41 | 29 | 4 | 1.33 | +207 | +51.6 |
| SHOTS IN THE MOVE | 122 | 95 | 4 | 1.33 | +416 | +104.0 |
| CHAFF PASSED | 3 | 3 | 3 | 1.00 | -19 | -6.4 |
| CHARGE NOW FIRST | 6 | 6 | 3 | 1.00 | -96 | -31.9 |
| FEATURE BUFFS | 14 | 14 | 3 | 1.00 | +32 | +10.7 |
| HOLDS AMBUSHERS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| IDLE COST | 37 | 28 | 3 | 1.00 | +18 | +5.8 |
| NEXT CHARGE BY LIST | 9 | 9 | 3 | 1.00 | +78 | +26.0 |
| SEARCH SPOT | 4 | 4 | 3 | 1.00 | +89 | +29.6 |
| TIED UP BY THE SUM | 3 | 3 | 3 | 1.00 | +43 | +14.4 |
| CHALLENGE BY POINTS | 2 | 2 | 2 | 0.67 | +13 | +6.4 |
| EXACT ROUND | 7 | 7 | 2 | 0.67 | +13 | +6.5 |
| GUN MASK | 23 | 23 | 2 | 0.67 | +23 | +11.4 |
| JOINT CHARGE NOW | 2 | 2 | 2 | 0.67 | +38 | +18.9 |
| NEXT OBJECTIVE NEARER | 3 | 3 | 2 | 0.67 | +216 | +107.8 |
| SCOUT WAITS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| SHOOTERS IN TWO RANKS | 2 | 2 | 2 | 0.67 | +4 | +2.0 |
| SUPPORT ADDS | 14 | 14 | 2 | 0.67 | +3 | +1.6 |
| SUPPORT WORKED OUT | 14 | 14 | 2 | 0.67 | +3 | +1.6 |
| WAR ENGINE JOBS | 2 | 2 | 2 | 0.67 | -4 | -2.1 |
| WOUNDS ON THE RANKS | 11 | 11 | 2 | 0.67 | +17 | +8.4 |
| ADVANCE LANE KEPT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| AFTERMATH WITH FRIENDS | 1 | 1 | 1 | 0.33 | +76 | +76.3 |
| CHAMPION KNOWS CHALLENGE | 1 | 1 | 1 | 0.33 | +89 | +89.4 |
| CHARGE LIST READ AGAIN | 1 | 1 | 1 | 0.33 | +21 | +21.3 |
| FALL BACK GOOD ORDER | 7 | 7 | 1 | 0.33 | +8 | +7.5 |
| FIRE IN ORDER | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 1 | 1 | 1 | 0.33 | +38 | +37.9 |
| HIS MOVE AND SHOT | 32 | 31 | 1 | 0.33 | +1 | +1.1 |
| HIS TURN DENIED | 2 | 2 | 1 | 0.33 | +31 | +30.7 |
| MISSILES IN THE MOVE | 40 | 27 | 1 | 0.33 | +11 | +11.3 |
| NEARER NOT NEEDED | 60 | 54 | 1 | 0.33 | +22 | +21.5 |
| NO RALLY LEFT | 1 | 1 | 1 | 0.33 | +32 | +32.5 |
| ONE CHALLENGE TEST | 1 | 1 | 1 | 0.33 | +89 | +89.4 |
| OVERRUNS AWAY | 4 | 4 | 1 | 0.33 | +8 | +7.5 |
| PATHS CROSS | 1 | 1 | 1 | 0.33 | +182 | +181.5 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.33 | +54 | +54.0 |
| SET UP BY THE SET | 3 | 3 | 1 | 0.33 | +17 | +16.7 |
| STUCK PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| THE ROW IN ITS ORDER | 30 | 1 | 1 | 0.33 | +0 | +0.0 |
| WHOLE FIGHT DANGER | 28 | 27 | 1 | 0.33 | +10 | +10.0 |
| BACKUP TARGETS | 3 | 1 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 3 | 3 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 2 | trace | - | - | - | - |
| CHARACTER GUNS | 22 | 22 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 46 | 44 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 3 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 2 | 2 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 30 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 9 | 7 | 0 | 0.00 | - | - |
| GUN FIGURES | 12 | not checked | - | - | - | - |
| HIS CHARGE BY HIS RUN | 59 | 58 | 0 | 0.00 | - | - |
| HIS CHARGE DENIED | 1 | 1 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 39 | 39 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 27 | 27 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 22 | 22 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 26 | 26 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 63 | 56 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 15 | 14 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN RUN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 160 | 160 | 0 | 0.00 | - | - |
| HONEST WORTH | 9 | 9 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 13 | 13 | 0 | 0.00 | - | - |
| LONG SHOT | 3 | 3 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 6 | 6 | 0 | 0.00 | - | - |
| LOST CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| MANOEUVRE | 10 | 10 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH CHECK | 1 | 1 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 9 | 9 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 6 | 6 | 0 | 0.00 | - | - |
| MAX FOR POSITIONING | 12 | 11 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 58 | 39 | 0 | 0.00 | - | - |
| MOVE SPELL SPOT | 2 | not checked | - | - | - | - |
| NO DOUBLE ROUNDS | 8 | 8 | 0 | 0.00 | - | - |
| NO LATE CUT | 3 | 3 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 18 | 18 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 3 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 29 | 19 | 0 | 0.00 | - | - |
| ONE ROUTE | 6 | 6 | 0 | 0.00 | - | - |
| PLAN RESULT | 272 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 1 | 1 | 0 | 0.00 | - | - |
| REAL GROUND | 6 | 6 | 0 | 0.00 | - | - |
| REDIRECT COUNTER | 1 | not checked | - | - | - | - |
| REFORMS TO MEET IT | 3 | 3 | 0 | 0.00 | - | - |
| REFUSING RETIRES | 2 | 2 | 0 | 0.00 | - | - |
| RISK BY ARC | 5 | 5 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 2 | 2 | 0 | 0.00 | - | - |
| RUN DOWN | 9 | 9 | 0 | 0.00 | - | - |
| SCOUT SPOT | 2 | 2 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 6 | 6 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 2 | 2 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 71 | not checked | - | - | - | - |
| SHOT OR CHARGE | 3 | 3 | 0 | 0.00 | - | - |
| SPELL WORTH | 9 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 38 | 35 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 1 | 1 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 13 | 13 | 0 | 0.00 | - | - |
| STANDS STILL | 257 | 257 | 0 | 0.00 | - | - |
| SUPPORT NARROWED | 1 | 1 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 11 | not checked | - | - | - | - |
| THE PROMISED MOVE | 1 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 22 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 10 | not checked | - | - | - | - |
| THE TABLE BINDS | 283 | not checked | - | - | - | - |
| WAITS AGAIN | 10 | 10 | 0 | 0.00 | - | - |
| WHAT THE JOINER ADDS | 2 | 2 | 0 | 0.00 | - | - |
| WHOLE FIGHT | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: csame-bb45c30-p6

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 6.67 | 2.00 | 50.2 |
| ARMY TABLE | rule | 3.67 | 1.33 | 49.3 |
| PROMISE BY ITS OWN SUM | rule | 4.33 | - | 51.4 |
| HOLDER ASSIGNMENT | rule | 1.00 | 0.67 | 20.8 |
| CHARGE NOW FIRST | rule | 0.67 | 0.33 | 31.9 |
| CHAFF PASSED | rule | - | 0.67 | 9.4 |
| RULE SWITCHED OFF | gate | 0.33 | 0.33 | 1.2 |
| WAR ENGINE JOBS | rule | 0.67 | - | 2.1 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.33 | - | 95.8 |
| JOINT CHARGE NOW | rule | 0.33 | - | 22.3 |

### Plans: csame-bb45c30-p6

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.3 | 75% | 123 | 152 | 124% |
| Mine | move | 30.3 | 100% | 2412 | 0 | 0% |
| Mine | shoot | 14.7 | 48% | 927 | 1584 | 171% |
| Opponent | charge | 0.7 | 0% | 19 | 17 | 90% |
| Opponent | move | 36.7 | 95% | 2417 | 0 | 0% |
| Opponent | shoot | 6.0 | 56% | 419 | 223 | 53% |
| Opponent | support | 1.0 | 100% | 0 | 0 | - |

### Battle groups: csame-bb45c30-p6

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | REDIRECT COUNTER | 0.3 | 0% | - | - | - | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: csame-bb45c30-p6

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Character | 10 | 13 (10) | 13 | 0 | 15 | 40% | 2.8 | 19 (6) | 0 (4) | - | 17 (7) | 0 (3) |
| Mine | Clean-up | 3 | 82 (3) | 0 | 82 | 0 | 100% | - | 16 (1) | 117 (2) | - | 82 (3) | - |
| Mine | Fast Hammer | 3 | 63 (3) | 63 | 0 | 0 | 0% | 2.7 | 61 (2) | - | 68 (1) | 63 (3) | - |
| Mine | Hammer | 6 | 21 (6) | 21 | 0 | 0 | 17% | 2.0 | 0 (2) | 31 (4) | - | 25 (5) | 0 (1) |
| Mine | Shooter | 6 | 82 (6) | 0 | 82 | 17 | 0% | 1.5 | 0 (1) | 115 (3) | 72 (2) | 82 (6) | - |
| Mine | War machine | 8 | 144 (8) | 144 | 0 | 23 | 0% | 1.4 | 125 (3) | 128 (3) | 183 (2) | 0 (1) | 163 (7) |
| Mine | Wizard | 4 | 0 (4) | 0 | 0 | 0 | 50% | 2.0 | 0 (1) | 0 (3) | - | 0 (3) | 0 (1) |
| Opponent | Chaff | 2 | 288 (2) | 0 | 288 | 44 | 100% | - | 514 (1) | 0 (1) | - | 514 (1) | 0 (1) |
| Opponent | Character | 9 | 9 (9) | 9 | 0 | 64 | 56% | 1.5 | 0 (1) | 13 (7) | 0 (1) | 0 (5) | 21 (4) |
| Opponent | Clean-up | 3 | 97 (3) | 0 | 97 | 0 | 100% | - | 0 (1) | 177 (2) | - | 177 (2) | 0 (1) |
| Opponent | Fast Hammer | 6 | 70 (6) | 0 | 70 | 0 | 83% | 1.0 | - | 105 (4) | 16 (2) | 70 (6) | - |
| Opponent | Fragile | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | - | 0 (1) | - | 0 (1) |
| Opponent | Hammer | 4 | 7 (4) | 7 | 0 | 43 | 50% | 1.0 | - | 0 (2) | 14 (2) | 7 (4) | - |
| Opponent | Holder | 4 | 38 (4) | 0 | 38 | 23 | 50% | 3.5 | - | 38 (4) | - | 0 (1) | 49 (3) |
| Opponent | Shooter | 4 | 75 (4) | 75 | 0 | 28 | 25% | 1.7 | 0 (1) | 0 (1) | 104 (2) | 88 (3) | 0 (1) |
| Opponent | War machine | 2 | 0 (2) | 0 | 0 | 50 | 0% | 1.0 | - | - | 0 (2) | 0 (1) | 0 (1) |

### Charged fights: csame-bb45c30-p6

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Empire of Man | 2 | 623 | 0 | 0.5 | 1.0 | 0 | 240 | -240 | 1 of 1 | 1 of 1 | - | -240 |
| Mine | Grand Cathay | 1 | 915 | 145 | 2.0 | 1.0 | 72 | 0 | +72 | 0 of 2 | 2 of 2 | - | +72 |
| **Mine** | all armies | 3 | 720 | 48 | 1.0 | 1.0 | 48 | 80 | -32 | 1 of 3 | 3 of 3 | - | -32 |
| Opponent | High Elf Realms | 1 | 354 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 0 of 1 | 1 of 1 | - | +0 |
| Opponent | Skaven | 1 | 0 | 0 | 1.0 | 1.0 | 0 | 92 | -92 | 0 of 1 | 1 of 1 | - | -92 |
| Opponent | Warriors of Chaos | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| **Opponent** | all armies | 3 | 118 | 0 | 0.7 | 1.0 | 0 | 46 | -46 | 0 of 2 | 2 of 2 | - | -46 |

### Effective charges: csame-bb45c30-p6

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Empire of Man | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net -240) | 0 | 0% (0 of 1) |
| Mine | Grand Cathay | 2 | 0 | 0 | 0 | 0 | 0 | 2 (net +72) | 0 | 0% (0 of 2) |
| Opponent | High Elf Realms | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +0) | 0 | 0% (0 of 1) |

### Charged fights, damage counted: csame-bb45c30-p6

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 | 238 | 239 | -32 | 112 | 102 | +9 | +4.0 |
| Mine | All fights | 3 | 238 | 239 | -32 | 112 | 102 | +9 | +4.0 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 247 | 104 | +0 | 39 | 206 | -167 | -67.7 |
| Opponent | No odds | 1 | 112 | 135 | -92 | 149 | 268 | -120 | -106.8 |
| Opponent | All fights | 2 | 180 | 120 | -46 | 94 | 237 | -143 | -79.9 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| csame-bb45c30-p6 | move | 16 | 5 (31%) | 3 (19%) | 0 (0%) | 11 (69%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Periapt of Soul Exchange | Opponent | L1021 |
| Ring of Jet | Mine | L1021 |
| Standard of the Fell Warrior | Opponent | L0913 |
| Storm Daemon (Renegade 2.0) | Opponent | L1021 |
| Twice-Blessed Armour | Mine | L1021 |

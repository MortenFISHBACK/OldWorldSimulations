# Doctrine scorecard: csame-bb45c30-p24

### Scorecard: csame-bb45c30-p24

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L2535 | 3 | 1 | Mine | - | - | - | - | - | - | - | - | - |
| L2535 | 3 | 1 | Opponent | - | - | - | - | - | - | - | - | - |
| L2735 | 5 | 1 | Mine | yes | - | 2 | 2 | 5 | 0 | 0 | 0 | 0 |
| L2735 | 5 | 1 | Opponent | yes | - | 4 | 3 | 3 | 0 | 0 | 0 | 0 |
| L3033 | 3 | 1 | Mine | no | 7 | 2 | 4 | 2 | 0 | 0 | 0 | 0 |
| L3033 | 3 | 1 | Opponent | no | 1 | 2 | 2 | 2 | 0 | 0 | 0 | 19 |
| **Average** | | | Mine | 50% | 7.0 | 2.0 | 3.0 | 3.5 | 0.0 | 0.0 | 0.0 | 0.0 |
| **Average** | | | Opponent | 50% | 1.0 | 3.0 | 2.5 | 2.5 | 0.0 | 0.0 | 0.0 | 9.5 |

### KPIs: csame-bb45c30-p24

Rules off - Mine only: NO OLD ONE-MOVE GUESS; both sides: ONE RUN A PLAN.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 11) | 27% (3 of 11) | 14% (3 of 22) |
| Winner chose to follow up after the loser gave ground |  | 100% (1 of 1); on the table 100% | - | 100% (1 of 1); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | 100% (1 of 1); on the table 100% | 100% (1 of 1); on the table 100% | 100% (2 of 2); on the table 100% |
| Winner chose to pursue after the loser fled |  | 33% (1 of 3); on the table 33% | 0% (0 of 1); on the table 100% | 25% (1 of 4); on the table 50% |
| Winner chose to follow up or pursue (all three) |  | 60% (3 of 5); on the table 60% | 50% (1 of 2); on the table 100% | 57% (4 of 7); on the table 71% |
| Magic missiles tried each own turn | 50%+ | 53% (8 of 15) | 43% (6 of 14) | 48% (14 of 29) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 57% (8 of 14) | 43% (6 of 14) | 50% (14 of 28) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | - | - |
| Points that never fought | lower | 56% (2255 of 4000) | 43% (1709 of 4000) | 50% (3964 of 8000) |
|   infantry points that never fought | lower | 53% (264 of 497) | 30% (390 of 1293) | 37% (654 of 1790) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 67% (8 of 12) | 77% (17 of 22) | 74% (25 of 34) |
| Bound items with a magic missile used (at least once a game) |  | 0.0 uses a game | 50% (2 of 4); 1.3 uses a game | 50% (2 of 4); 0.7 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 100% (1 of 1); 0.3 uses a game | 0% (0 of 1); 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 56% (1792 of 3200) | 70% (2771 of 3962) | 64% (4563 of 7162) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.3 (57%) | 1.3 (50%) | 2.7 (53%) |
| MARCHED: its unit marched | 0.3 (14%) | 1.0 (38%) | 1.3 (27%) |
| GONE: slain | 0.3 (14%) | 0.0 (0%) | 0.3 (7%) |
| STUPIDITY: Stupidity | 0.3 (14%) | 0.0 (0%) | 0.3 (7%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.3 (12%) | 0.3 (7%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.0 | 1.3 | 3.3 | 4.7 | 2.0 | 1.3 |
| not cast | 2.7 | 0.3 | 1.7 | 5.0 | 4.0 | 14.7 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.3 (9%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.3 (100%) | 0.3 (20%) | 2.7 (53%) | 1.7 (42%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.3 (27%) | 0.7 (17%) | 0.0 (0%) |
| GONE: slain | 0.3 (12%) | 0.0 (0%) | 0.0 (0%) | 0.3 (7%) | 0.3 (8%) | 1.0 (7%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (7%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (7%) | 1.3 (33%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.3 (88%) | 0.0 (0%) | 1.3 (80%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 12.3 (84%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.7 a game | 2.7 a game | 1.7 a game |
| stood (cast and not dispelled) | 50% (1 of 2) | 50% (4 of 8) | 50% (5 of 10) |
| the unit moved after it | 100% (1 of 1) | 50% (2 of 4) | 60% (3 of 5) |
| it charged on its next turn | 0% (0 of 1) | 25% (1 of 4) | 20% (1 of 5) |
| the enemy charged it first | 0% (0 of 1) | 0% (0 of 4) | 0% (0 of 5) |
| it fought by the end of its next turn | 0% (0 of 1) | 0% (0 of 4) | 0% (0 of 5) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 1) | 0% (0 of 4) | 0% (0 of 5) |
| none of these (no charge, no fight, no charge escaped) | 100% (1 of 1) | 75% (3 of 4) | 80% (4 of 5) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 0% (0 of 4) | 67% (37 of 55) | 63% (37 of 59) |
|   cavalry | - | 79% (15 of 19) | 79% (15 of 19) |
|   character | 0% (0 of 4) | 83% (10 of 12) | 62% (10 of 16) |
|   infantry | - | 50% (12 of 24) | 50% (12 of 24) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 0.0 (0%) | 3.0 (50%) | 3.0 (41%) |
| CHARGED: it charged | 1.3 (100%) | 0.7 (11%) | 2.0 (27%) |
| FLEEING: it fled or was fleeing | 0.0 (0%) | 0.7 (11%) | 0.7 (9%) |
| IN COMBAT: it fought this turn or the last | 0.0 (0%) | 1.0 (17%) | 1.0 (14%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.0 (0%) | 0.7 (11%) | 0.7 (9%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 6.3 | 1.0 | 84% | 6.6 pts | 42 pts |
| character | 3.3 | 2.0 | 40% | 9.7 pts | 32 pts |
| infantry | 6.0 | 0.7 | 89% | 3.4 pts | 20 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 5.0 | 1.7 | 3.3 |
| Charges that made contact a game | 4.0 | 0.7 | 2.3 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.00 declared, 0.00 contact (4 units) | - | 0.00 declared, 0.00 contact (4 units) |
|   per unit a game, units carrying another wizard (or one alone) | 1.67 declared, 1.33 contact (3 units) | - | 1.67 declared, 1.33 contact (3 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.50 declared, 0.40 contact (20 units) | 0.16 declared, 0.06 contact (31 units) | 0.29 declared, 0.20 contact (51 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 88% (7 of 8) | - | 100% (1 of 1) | 89% (8 of 9) |
| Character in a unit | 100% (3 of 3) | 75% (3 of 4) | 100% (1 of 1) | 88% (7 of 8) |
| Character on its own | 100% (1 of 1) | - | 0% (0 of 3) | 25% (1 of 4) |
| Infantry | 83% (5 of 6) | 67% (2 of 3) | - | 78% (7 of 9) |
| Monster | - | 0% (0 of 1) | - | 0% (0 of 1) |
| Monstrous | 67% (2 of 3) | - | - | 67% (2 of 3) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Vampire Counts | 1 | 33% (1 of 3); on the table 33% | 67% (4 of 6) | 45% | 83% (5 of 6) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 1 | 100% (2 of 2); on the table 100% | - | 67% | 50% (3 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Wood Elf Realms | 2 | 50% (1 of 2); on the table 100% | 50% (6 of 12) | 43% | 77% (17 of 22) | 67% (2 of 3); 2.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (csame-bb45c30-p24, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 0% (0) | 40% (2) | 33% (2) |
| ...free all their last turn and able to turn (per game) | 0.00 | 0.67 | 0.67 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.67 | 0.67 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: csame-bb45c30-p24

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.7 | 0.7 |
| Strategy | Charge objectives carried out (made contact) | 90% (9 of 10) | 67% (2 of 3) |
| Strategy | Shoot objectives carried out (shot that target) | - | 29% (2 of 7) |
| Strategy | Joined characters whose unit fought | 0% (0 of 4) | 40% (2 of 5) |
| Strategy | Lone characters that fought | 60% (3 of 5) | 100% (1 of 1) |
| Movement | Charges halted short of contact | 0.3 | 0.0 |
| Movement | Idle units | 3.5 | 2.5 |
| Movement | Points that never moved of their own | 0.0 | 9.5 |
| Movement | Fights charged into per game | 5.5 | 1.0 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 8 | 0 of 2 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 8 | 0 of 2 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 5 of 8, net +141 | 0 of 2 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 of 8, net +86 | 1 of 2, net +186 |
| Shooting | Shots by shooting units (incl. breath weapons) | 0.7 | 13.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 0% (0 of 2) | 59% (23 of 39) |
| Shooting | Points destroyed by shooting units | 0.0 | 0.0 |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | 1.3 | 2.0 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 0% (0 of 4) | 67% (4 of 6) |
| Magic | Wounds caused by magic missiles | - | 1.7 |
| Magic | Points destroyed by magic (all spells) | 0.0 | 15.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.3 / 0.3 / 0.3 / 0.7 | 1.3 / 0.3 / 0.0 / 0.7 |
| Combat | Points destroyed in combat | 242.3 | 145.3 |
| Combat | Points run down | 85.0 | 0.0 |
| Combat | Net points per charged fight, damage counted | +89 | +210 |
| Combat | Net per 100 charger points, damage counted | +22.7 | +69.7 |
| Combat | First round won (charged fights) | 82% | 50% |
| Combat | Net points per charged fight | +88 | +218 |
| Combat | Net points per supported fight / lone fight | - / +88 | - / +218 |
| Combat | Charged fights on a top-3 enemy unit | 1 of 11 | 0 of 2 |
| Game | Points lost | 265.5 | 466.0 |
| Game | VP from objectives | 740.0 | 610.0 |
| Game | Lone holders (player turns) | 7.0 | 1.0 |

- Mine won / drew / lost: 1 / 0 / 1 of 2 ended games (of 3); mean margin (Mine - Opponent) +340 VP
- The side that went first won 0 of 2 games with a winner
- Points traded per game (both sides' losses): 732
- Games not ended: 1 (L2535-1); findings 1, warnings 0

### Opponent rules: csame-bb45c30-p24

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| ARMY TABLE | 20.7 | +518.8 | 0.0 | 172.3 | 30.7 | +446.2 | 0.0 | 579.0 |
| BACKUP TARGETS | 0.7 | +1.2 | 0.0 | 0.0 | 0.3 | +1.1 | 0.0 | 0.0 |
| CAST JOB | 0.3 | +0.6 | 0.0 | 0.0 | - | - | - | - |
| CASTER AWAY FROM SCREEN | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | - | - | - | - | 1.0 | +76.6 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 0.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | 4.7 | +139.8 | 0.0 | 45.0 | - | - | - | - |
| CHAFF PASSED | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| CHALLENGE BY POINTS | - | - | - | - | 0.7 | +31.9 | 0.0 | 127.7 |
| CHARACTER GUNS | - | - | - | - | 5.7 | +0.0 | 0.0 | 0.0 |
| CHARGE LOSSES | 19.0 | -727.3 | 0.0 | 206.0 | 8.7 | -355.4 | 0.0 | 402.0 |
| CHARGE NOW FIRST | 3.0 | +0.0 | 324.7 | 0.0 | 0.3 | +0.0 | 20.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 12.7 | +0.0 | 0.0 | 0.0 | 6.7 | +0.0 | 0.0 | 38.0 |
| COMBAT PIVOT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CONVEYANCE SEARCH | 0.7 | +20.3 | 0.0 | 0.0 | 2.0 | +75.0 | 0.0 | 0.0 |
| COVER ONCE | 6.0 | -300.1 | 0.0 | 36.7 | 13.0 | -498.9 | 0.0 | 79.7 |
| DEPLOY BY FIGURES | 7.0 | +35.9 | 0.0 | 0.0 | 10.0 | -110.5 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | 0.3 | -4.7 | 78.7 | 0.0 | - | - | - | - |
| EDGE GIVE GROUND | 0.7 | +23.9 | 38.0 | 0.0 | - | - | - | - |
| EXACT ROUND | 2.7 | +16.0 | 162.7 | 0.0 | 1.0 | +5.5 | 82.0 | 0.0 |
| FALL BACK GOOD ORDER | 3.0 | +5.3 | 328.0 | 0.0 | 0.7 | +0.0 | 20.0 | 0.0 |
| FALLBACK BY WORTH | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FALLS SHORT | 20.0 | +203.5 | 0.0 | 0.0 | - | - | - | - |
| FEATURE BUFFS | 1.7 | +19.2 | 0.0 | 0.0 | 2.0 | +28.9 | 0.0 | 0.0 |
| FIGHT TO THE END | 0.7 | +10.2 | 0.0 | 0.0 | 0.3 | -0.1 | 0.0 | 0.0 |
| FIVE ACTION | 75.7 | +4007.2 | 455.0 | 336.3 | 74.7 | +5580.2 | 82.0 | 940.0 |
| FLANK NOT WEIGHED | 5.3 | +0.0 | 0.0 | 78.7 | 4.7 | +0.0 | 0.0 | 127.7 |
| FOLLOW UP WEIGHED | 1.0 | +107.7 | 0.0 | 0.0 | 1.0 | +17.8 | 0.0 | 0.0 |
| FOUR ROUNDS | 4.3 | +273.6 | 455.0 | 0.0 | 1.0 | +121.5 | 82.0 | 0.0 |
| FREED FROM HIS FIGHT | 1.0 | +0.0 | 0.0 | 62.0 | 3.3 | +0.0 | 0.0 | 83.3 |
| FRIEND SHOOTS FIRST | - | - | - | - | 0.3 | -0.1 | 0.0 | 0.0 |
| GOAL WALK | 7.0 | +426.5 | 0.0 | 0.0 | 20.3 | +1417.0 | 0.0 | 69.3 |
| HARD STAY DROPPED | 1.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 0.3 | +0.0 | 0.0 | 62.0 | - | - | - | - |
| HIS CHARGE BY HIS RUN | 13.7 | +0.0 | 0.0 | 144.0 | 8.3 | +0.0 | 0.0 | 367.3 |
| HIS CHARGE DENIED | - | - | - | - | 0.3 | +30.2 | 62.0 | 0.0 |
| HIS CHARGE LIST | 4.3 | +0.0 | 0.0 | 15.0 | 9.0 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 7.0 | +0.0 | 0.0 | 0.0 | 7.0 | +0.0 | 0.0 | 76.0 |
| HIS MOVE AND SHOT | 8.3 | -72.5 | 0.0 | 62.0 | 1.3 | -40.0 | 0.0 | 34.7 |
| HIS MOVE AS HE DECIDES | 37.0 | +7.7 | 404.0 | 0.0 | - | - | - | - |
| HIS MOVE WHY | - | - | - | - | 12.3 | +0.0 | 0.0 | 82.0 |
| HIS ONE MOVE | 24.0 | -82.4 | 0.0 | 139.0 | - | - | - | - |
| HIS ONE QUARTER | 4.3 | +0.0 | 0.0 | 62.0 | 3.0 | +0.0 | 0.0 | 86.0 |
| HIS OWN BEST MOVE | 2.3 | +0.0 | 0.0 | 0.0 | 9.3 | +0.0 | 0.0 | 76.0 |
| HIS RUN AFTER OUR TURN | 4.7 | +0.0 | 0.0 | 0.0 | 4.7 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 54.7 | +1245.8 | 0.0 | 88.3 | 21.0 | +233.7 | 0.0 | 207.3 |
| HIS SHOTS BY HIS RUN | 51.3 | +720.2 | 0.0 | 336.3 | 13.7 | +160.1 | 0.0 | 636.0 |
| HIS TURN RUN | 5.0 | +0.0 | 0.0 | 0.0 | 4.7 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 18.3 | +0.0 | 0.0 | 40.0 | 11.0 | +0.0 | 0.0 | 172.0 |
| HOLDER ASSIGNMENT | 10.0 | +663.1 | 0.0 | 20.0 | 7.0 | +533.9 | 0.0 | 86.0 |
| HOLDS AMBUSHERS | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HONEST WORTH | 4.3 | -201.0 | 455.0 | 0.0 | 1.0 | -30.8 | 82.0 | 0.0 |
| IDLE COST | 17.7 | -217.7 | 0.0 | 15.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 3.3 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 0.3 | +4.5 | 0.0 | 0.0 | 0.7 | +50.8 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 0.3 | +0.0 | 0.0 | 20.0 | 6.7 | +0.0 | 0.0 | 50.7 |
| LONG SHOT | 0.3 | +0.2 | 0.0 | 0.0 | 0.7 | +8.6 | 20.0 | 0.0 |
| LOST AFTER ESCAPE | 1.3 | +0.9 | 250.7 | 0.0 | 0.3 | -0.0 | 62.0 | 0.0 |
| LURE BY WHAT IT DRAWS | - | - | - | - | 0.7 | -29.8 | 0.0 | 12.7 |
| MANOEUVRE | 1.3 | -4.9 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| MARCH AT ESCAPER | - | - | - | - | 0.3 | +4.8 | 0.0 | 0.0 |
| MARCH BY THE SUM | - | - | - | - | 1.3 | +65.2 | 0.0 | 86.0 |
| MARCH CHECK | - | - | - | - | 2.0 | +89.4 | 0.0 | 0.0 |
| MARCH OF THE TABLE | 0.3 | +21.2 | 0.0 | 0.0 | 0.3 | +7.1 | 0.0 | 86.0 |
| MARCH OVER CASTS | 0.3 | -20.7 | 0.0 | 0.0 | 2.0 | +66.1 | 0.0 | 86.0 |
| MARCH WHEELS ONLY | 2.7 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 1.0 | +8.4 | 0.0 | 62.0 | 3.0 | +55.2 | 0.0 | 48.3 |
| MEETS IN TIME | 4.0 | +174.0 | 0.0 | 0.0 | 5.7 | +191.1 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 2.0 | +8.3 | 0.0 | 20.0 | 4.7 | +147.5 | 0.0 | 86.0 |
| MISSILES NEXT TURN | 4.0 | +11.1 | 0.0 | 20.0 | 5.7 | +98.3 | 0.0 | 86.0 |
| MOVE ORDER | 1.3 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 86.0 |
| MOVE SPELL NOT WORTH | - | - | - | - | 0.3 | -0.4 | 0.0 | 0.0 |
| MOVE SPELL OUT OF RANGE | - | - | - | - | 2.7 | -71.2 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 7.3 | +783.1 | 0.0 | 0.0 | 5.0 | +443.9 | 0.0 | 34.7 |
| NEARER NOT NEEDED | 7.3 | +242.9 | 0.0 | 0.0 | 5.7 | +235.4 | 0.0 | 78.7 |
| NEXT CHARGE BY LIST | 6.0 | +690.2 | 0.0 | 0.0 | 1.3 | +152.9 | 0.0 | 0.0 |
| NEXT OBJECTIVE NEARER | - | - | - | - | 0.3 | -8.4 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 4.0 | -131.2 | 413.3 | 0.0 | 1.0 | -16.8 | 82.0 | 0.0 |
| NO LATE CUT | 2.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | - | - | - | - | 4.7 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 5.0 | +0.0 | 0.0 | 0.0 | 4.7 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 0.3 | -0.1 | 0.0 | 0.0 | 0.7 | -1.4 | 0.0 | 0.0 |
| OFF BEST | 6.0 | -95.5 | 0.0 | 62.0 | 7.0 | -270.6 | 0.0 | 86.0 |
| ONE CHECK AFTER THE LAST CHANGE | 1.3 | +0.0 | 0.0 | 62.0 | 0.3 | +0.0 | 0.0 | 86.0 |
| ONE FIGHT FORMULA | 6.0 | -88.0 | 0.0 | 0.0 | 4.7 | -81.7 | 0.0 | 0.0 |
| ONE JOINT FIGURE | - | - | - | - | 0.3 | +9.6 | 20.0 | 0.0 |
| ONE OBJECTIVE FORMULA | 4.0 | -47.7 | 0.0 | 20.0 | 1.7 | +20.0 | 0.0 | 86.0 |
| ONE PROMISE A TARGET | 0.3 | -34.1 | 0.0 | 0.0 | - | - | - | - |
| ONE ROUTE | 2.7 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| OPENS UP | 1.0 | +49.7 | 79.0 | 0.0 | - | - | - | - |
| OVERRUNS AWAY | 2.0 | +84.5 | 199.3 | 0.0 | - | - | - | - |
| PATHS CROSS | 1.7 | +17.2 | 0.0 | 0.0 | - | - | - | - |
| PIVOT GUARDS FLANK | 0.3 | -3.3 | 0.0 | 0.0 | - | - | - | - |
| PLAN RESULT | 38.0 | +292.9 | 206.3 | 227.3 | 30.7 | +67.6 | 40.0 | 610.3 |
| PROMISE BY ITS OWN SUM | 7.0 | -104.9 | 0.0 | 0.0 | 10.7 | -480.9 | 0.0 | 34.7 |
| PROMISE KNOWS THE FIGHT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE READS THE TABLE | - | - | - | - | 0.3 | -0.1 | 0.0 | 0.0 |
| QUARTER ODDS | 19.7 | +2092.1 | 127.7 | 321.3 | 16.0 | +1886.2 | 62.0 | 258.0 |
| REAL GROUND | 2.7 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| REDIRECT BY WHAT IT STOPS | 0.7 | +11.5 | 0.0 | 0.0 | - | - | - | - |
| REDIRECT COUNTER | 3.3 | +221.8 | 0.0 | 30.0 | 0.3 | +13.3 | 0.0 | 6.3 |
| REDIRECT FOR A FRIEND IN REACH | 2.7 | +45.3 | 0.0 | 30.0 | 1.3 | +0.0 | 0.0 | 6.3 |
| REDIRECT WEIGHED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| REFORMS TO MEET IT | 0.7 | -0.1 | 0.0 | 0.0 | 3.0 | -115.6 | 0.0 | 0.0 |
| REFUSING RETIRES | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | 0.3 | +20.5 | 0.0 | 0.0 | 0.7 | +34.2 | 0.0 | 38.0 |
| RISK BY ARC | 4.0 | -153.1 | 369.0 | 0.0 | 0.3 | -0.2 | 20.0 | 0.0 |
| RISK ON THE WAY | 1.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| ROUNDS AFTER TERROR | 2.3 | -29.0 | 330.7 | 0.0 | - | - | - | - |
| RUN DOWN | 3.7 | -27.6 | 407.0 | 0.0 | - | - | - | - |
| SCREEN BY WHAT IT SAVES | 2.3 | -45.5 | 0.0 | 45.0 | - | - | - | - |
| SEARCH SPOT | 1.3 | +3.2 | 0.0 | 0.0 | - | - | - | - |
| SECOND LOOK | 0.7 | +35.4 | 0.0 | 0.0 | - | - | - | - |
| SET CREDITED ONCE | 1.0 | -5.1 | 0.0 | 0.0 | 0.7 | -5.9 | 0.0 | 78.7 |
| SET UP BY THE SET | 2.0 | -50.6 | 78.7 | 0.0 | 0.7 | +2.6 | 0.0 | 78.7 |
| SET-UP ANY TARGET | - | - | - | - | 0.3 | +18.3 | 0.0 | 0.0 |
| SET-UP MISSED | - | - | - | - | 0.3 | +36.8 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | - | - | - | - | 0.7 | +0.7 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 1.3 | +0.0 | 0.0 | 15.0 | 3.3 | +0.0 | 0.0 | 48.3 |
| SHOOTS FROM THE BEST SPOT | - | - | - | - | 0.3 | +8.0 | 0.0 | 0.0 |
| SHOT RISK POINTS | 40.3 | -442.0 | 0.0 | 254.3 | 5.7 | -39.8 | 0.0 | 142.0 |
| SHOTS AFTER THE MOVES | - | - | - | - | 2.3 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | - | - | - | - | 13.7 | +149.2 | 0.0 | 244.7 |
| SPELL SETS UP CHARGE | - | - | - | - | 0.3 | +18.3 | 0.0 | 0.0 |
| SPELL WORTH | 1.7 | +0.6 | 0.0 | 0.0 | 2.0 | +11.3 | 0.0 | 0.0 |
| SPELLS IN THE FIGHT | - | - | - | - | 0.7 | -2.0 | 20.0 | 0.0 |
| SPOT AS THE GAME MOVES | 10.7 | +0.0 | 0.0 | 82.0 | 9.0 | +0.0 | 0.0 | 148.0 |
| STAND AND SHOOT | 0.3 | -2.5 | 86.0 | 0.0 | - | - | - | - |
| STANDS FOR A REASON | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| STANDS STILL | 12.7 | +0.0 | 0.0 | 33.3 | 25.0 | +0.0 | 0.0 | 374.3 |
| STAY WORTH | 0.3 | +0.6 | 0.0 | 0.0 | 9.7 | +42.1 | 0.0 | 0.0 |
| STUPIDITY NEXT TURN | 2.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SUPPORT ADDS | 3.7 | +161.7 | 0.0 | 157.3 | 5.0 | +216.6 | 0.0 | 120.7 |
| SUPPORT NARROWED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| SUPPORT WORKED OUT | 3.7 | +161.7 | 0.0 | 157.3 | 5.0 | +216.6 | 0.0 | 120.7 |
| THE DEARER SUM KEEPS ITS PLAN | 1.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 4.0 | +0.0 | 0.0 | 0.0 | 4.7 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 6.3 | +0.0 | 0.0 | 20.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 3.7 | +0.0 | 0.0 | 20.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 5.0 | +0.0 | 0.0 | 0.0 | 4.7 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 40.3 | +0.0 | 0.0 | 190.7 | 36.7 | +0.0 | 0.0 | 419.7 |
| TIED UP BY THE SUM | 3.0 | +399.0 | 369.0 | 0.0 | - | - | - | - |
| TIME ON OUR SIDE | - | - | - | - | 42.0 | +483.1 | 0.0 | 379.3 |
| WAITS AGAIN | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 34.7 |
| WHO FIGHTS | - | - | - | - | 0.3 | -0.6 | 62.0 | 0.0 |
| WHOLE FIGHT DANGER | 3.3 | -207.5 | 0.0 | 82.0 | 2.7 | -266.7 | 0.0 | 329.3 |
| WOUNDS ON THE RANKS | 3.7 | +81.3 | 0.0 | 20.0 | 0.7 | +31.4 | 0.0 | 0.0 |

### Rule changes: csame-bb45c30-p24

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 154 | 154 | 106 | 35.33 | +3470 | +32.7 |
| HIS MOVE AS HE DECIDES | 111 | 111 | 88 | 29.33 | +0 | +0.0 |
| HOLDER ASSIGNMENT | 51 | 51 | 44 | 14.67 | +2802 | +63.7 |
| OFF BEST | 39 | 39 | 39 | 13.00 | -1098 | -28.2 |
| DEPLOY BY FIGURES | 51 | 51 | 35 | 11.67 | +412 | +11.8 |
| HIS SHOT LIST | 227 | 210 | 32 | 10.67 | +187 | +5.8 |
| THE TABLE AGAIN | 29 | 29 | 26 | 8.67 | +0 | +0.0 |
| FIVE ACTION | 451 | 420 | 22 | 7.33 | +937 | +42.6 |
| HIS SHOTS BY HIS RUN | 195 | 178 | 22 | 7.33 | +67 | +3.0 |
| GOAL WALK | 82 | 80 | 21 | 7.00 | +770 | +36.6 |
| LEGAL CHARGES ONLY | 21 | 21 | 21 | 7.00 | +0 | +0.0 |
| MOVE TO CHARGE COMPUTED | 37 | 28 | 21 | 7.00 | +1371 | +65.3 |
| PROMISE BY ITS OWN SUM | 53 | 53 | 20 | 6.67 | -1757 | -87.9 |
| HIS MOVE WHY | 37 | 37 | 19 | 6.33 | +0 | +0.0 |
| QUARTER ODDS | 107 | 99 | 18 | 6.00 | +1788 | +99.4 |
| NEXT CHARGE BY LIST | 22 | 21 | 17 | 5.67 | +1470 | +86.4 |
| HIS ONE MOVE | 72 | 68 | 15 | 5.00 | +0 | +0.0 |
| TIME ON OUR SIDE | 126 | 94 | 15 | 5.00 | +53 | +3.5 |
| MOVE ORDER | 12 | 12 | 12 | 4.00 | +0 | +0.0 |
| ADVANCE LANE KEPT | 11 | 11 | 11 | 3.67 | +0 | +0.0 |
| IDLE COST | 53 | 39 | 11 | 3.67 | +42 | +3.8 |
| SHOT RISK POINTS | 138 | 129 | 11 | 3.67 | +80 | +7.3 |
| REDIRECT FOR A FRIEND IN REACH | 12 | 12 | 10 | 3.33 | +0 | +0.0 |
| FOUR ROUNDS | 16 | 14 | 9 | 3.00 | +287 | +31.9 |
| MEETS IN TIME | 29 | 29 | 9 | 3.00 | +409 | +45.5 |
| TIED UP BY THE SUM | 9 | 9 | 9 | 3.00 | +323 | +35.9 |
| CHAFF IN THE MOVE | 14 | 13 | 8 | 2.67 | +36 | +4.5 |
| COVER ONCE | 57 | 32 | 7 | 2.33 | +51 | +7.3 |
| HARD STAY DROPPED | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| SUPPORT ADDS | 26 | 25 | 7 | 2.33 | +61 | +8.7 |
| SUPPORT WORKED OUT | 26 | 25 | 7 | 2.33 | +61 | +8.7 |
| FOLLOW UP WEIGHED | 6 | 6 | 6 | 2.00 | +376 | +62.7 |
| MAX FOR POSITIONING | 12 | 12 | 6 | 2.00 | +28 | +4.7 |
| PATHS CROSS | 5 | 5 | 5 | 1.67 | +52 | +10.3 |
| CASTS FROM BEHIND | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| CHARGE LOSSES | 83 | 76 | 4 | 1.33 | +230 | +57.5 |
| CHARGE NOW FIRST | 10 | 10 | 4 | 1.33 | -153 | -38.2 |
| MARCH BY THE SUM | 4 | 4 | 4 | 1.33 | +196 | +48.9 |
| NEARER NOT NEEDED | 39 | 35 | 4 | 1.33 | +140 | +35.0 |
| WHOLE FIGHT DANGER | 18 | 16 | 4 | 1.33 | +120 | +29.9 |
| CASTING BLOCK | 3 | 3 | 3 | 1.00 | +204 | +67.9 |
| CHAFF PASSED | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| FEATURE BUFFS | 11 | 11 | 3 | 1.00 | +18 | +6.1 |
| LANE BY FIGURES | 3 | 3 | 3 | 1.00 | +166 | +55.2 |
| RESERVE FALL BACK | 3 | 3 | 3 | 1.00 | +164 | +54.6 |
| CHALLENGE BY POINTS | 2 | 2 | 2 | 0.67 | +96 | +47.8 |
| FALLS SHORT | 60 | 50 | 2 | 0.67 | +35 | +17.7 |
| HOLDS AMBUSHERS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| MARCH CHECK | 6 | 6 | 2 | 0.67 | +33 | +16.7 |
| MARCH OF THE TABLE | 2 | 2 | 2 | 0.67 | -85 | -42.5 |
| OPENS UP | 3 | 3 | 2 | 0.67 | +62 | +30.9 |
| SCREEN BY WHAT IT SAVES | 7 | 7 | 2 | 0.67 | +0 | +0.0 |
| SEARCH SPOT | 4 | 4 | 2 | 0.67 | +10 | +4.8 |
| SECOND LOOK | 2 | 2 | 2 | 0.67 | +106 | +53.1 |
| SET UP BY THE SET | 8 | 8 | 2 | 0.67 | +128 | +64.2 |
| SHOOTERS IN TWO RANKS | 2 | 2 | 2 | 0.67 | +2 | +1.0 |
| SHOTS IN THE MOVE | 41 | 28 | 2 | 0.67 | +37 | +18.6 |
| THE ROW IN ITS ORDER | 26 | 2 | 2 | 0.67 | +0 | +0.0 |
| WOUNDS ON THE RANKS | 13 | 13 | 2 | 0.67 | +59 | +29.6 |
| CASTER AWAY FROM SCREEN | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| COMBAT PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| DUEL STOPS AT THE KILL | 1 | 1 | 1 | 0.33 | +85 | +85.2 |
| EXACT ROUND | 11 | 10 | 1 | 0.33 | +4 | +3.9 |
| HONEST WORTH | 16 | 14 | 1 | 0.33 | +85 | +85.2 |
| ONE PROMISE A TARGET | 1 | 1 | 1 | 0.33 | -102 | -102.2 |
| OVERRUNS AWAY | 6 | 5 | 1 | 0.33 | +23 | +22.9 |
| PIVOT GUARDS FLANK | 1 | 1 | 1 | 0.33 | -10 | -9.8 |
| REDIRECT COUNTER | 11 | 9 | 1 | 0.33 | +0 | +0.0 |
| REDIRECT WEIGHED | 1 | 1 | 1 | 0.33 | +28 | +28.1 |
| REFUSING RETIRES | 1 | 1 | 1 | 0.33 | -4 | -4.4 |
| RISK BY ARC | 13 | 11 | 1 | 0.33 | +4 | +3.5 |
| SHOOTS FROM THE BEST SPOT | 1 | 1 | 1 | 0.33 | +2 | +2.0 |
| SHOTS AFTER THE MOVES | 7 | 7 | 1 | 0.33 | +0 | +0.0 |
| STAY WORTH | 30 | 22 | 1 | 0.33 | +0 | +0.1 |
| SUPPORT NARROWED | 1 | 1 | 1 | 0.33 | -61 | -61.0 |
| BACKUP TARGETS | 3 | not checked | - | - | - | - |
| CAST JOB | 1 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 6 | trace | - | - | - | - |
| CHARACTER GUNS | 17 | 16 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 58 | 55 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 8 | not checked | - | - | - | - |
| EDGE GIVE GROUND | 2 | 1 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 11 | 10 | 0 | 0.00 | - | - |
| FALLBACK BY WORTH | 1 | 1 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 3 | 1 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 30 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 13 | 13 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 1 | 1 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 1 | 1 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 66 | 59 | 0 | 0.00 | - | - |
| HIS CHARGE DENIED | 1 | 1 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 40 | 36 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 42 | 35 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 29 | 27 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 22 | 18 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 35 | 32 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 28 | 28 | 0 | 0.00 | - | - |
| HIS TURN RUN | 29 | 29 | 0 | 0.00 | - | - |
| HOLD ODDS | 88 | 83 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 18 | 14 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 3 | 3 | 0 | 0.00 | - | - |
| LONG SHOT | 3 | 2 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 5 | 4 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 2 | 2 | 0 | 0.00 | - | - |
| MANOEUVRE | 5 | 5 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 7 | 7 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 13 | 9 | 0 | 0.00 | - | - |
| MISSILES IN THE MOVE | 20 | 16 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 29 | 22 | 0 | 0.00 | - | - |
| MOVE SPELL NOT WORTH | 1 | not checked | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 8 | trace | - | - | - | - |
| NEXT OBJECTIVE NEARER | 1 | 1 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 15 | 13 | 0 | 0.00 | - | - |
| NO LATE CUT | 9 | 6 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 14 | 14 | 0 | 0.00 | - | - |
| NO SECOND RUN | 29 | 29 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 3 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 5 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 32 | 12 | 0 | 0.00 | - | - |
| ONE JOINT FIGURE | 1 | 1 | 0 | 0.00 | - | - |
| ONE OBJECTIVE FORMULA | 17 | 11 | 0 | 0.00 | - | - |
| ONE ROUTE | 13 | 9 | 0 | 0.00 | - | - |
| PLAN RESULT | 206 | trace | - | - | - | - |
| PROMISE KNOWS THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE READS THE TABLE | 1 | 1 | 0 | 0.00 | - | - |
| REAL GROUND | 13 | 9 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 2 | 2 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 11 | 8 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 7 | 4 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 7 | 6 | 0 | 0.00 | - | - |
| RUN DOWN | 11 | 9 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 5 | 5 | 0 | 0.00 | - | - |
| SET-UP ANY TARGET | 1 | not checked | - | - | - | - |
| SET-UP MISSED | 1 | trace | - | - | - | - |
| SHOOTERS ON THE TABLE | 14 | not checked | - | - | - | - |
| SPELL SETS UP CHARGE | 1 | not checked | - | - | - | - |
| SPELL WORTH | 11 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 59 | 52 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 1 | 1 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 2 | not checked | - | - | - | - |
| STANDS STILL | 113 | 107 | 0 | 0.00 | - | - |
| STUPIDITY NEXT TURN | 6 | 5 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 8 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 25 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 14 | not checked | - | - | - | - |
| THE TABLE BINDS | 231 | not checked | - | - | - | - |
| WAITS AGAIN | 5 | 3 | 0 | 0.00 | - | - |
| WHO FIGHTS | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: csame-bb45c30-p24

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 3.33 | 5.67 | 31.9 |
| PROMISE BY ITS OWN SUM | rule | 1.67 | 5.00 | 87.9 |
| ARMY TABLE | rule | 1.00 | 3.67 | 54.0 |
| RULE SWITCHED OFF | gate | 2.33 | 1.00 | 19.6 |
| CHARGE NOW FIRST | rule | 1.00 | 0.33 | 38.2 |
| MARCH OF THE TABLE | rule | 0.33 | 0.33 | 42.5 |
| FALLBACK | gate | 0.33 | - | 35.8 |
| FIGHT ORDER BAND | gate | - | 0.33 | 3.9 |
| HOLDER ASSIGNMENT | rule | - | 0.33 | 0.9 |
| ONE PROMISE A TARGET | rule | 0.33 | - | 102.2 |
| PIVOT GUARDS FLANK | rule | 0.33 | - | 9.8 |
| REFUSING RETIRES | rule | - | 0.33 | 4.4 |
| SUPPORT NARROWED | rule | - | 0.33 | 61.0 |

### Plans: csame-bb45c30-p24

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 3.3 | 70% | 291 | 293 | 101% |
| Mine | join | 4.0 | 100% | 163 | 0 | 0% |
| Mine | move | 29.3 | 98% | 1314 | 0 | 0% |
| Mine | support | 1.3 | 75% | 14 | 0 | 0% |
| Opponent | charge | 0.7 | 50% | 146 | 20 | 14% |
| Opponent | move | 28.7 | 95% | 1767 | 0 | 0% |
| Opponent | shoot | 1.0 | 33% | 74 | 48 | 64% |
| Opponent | support | 0.3 | 0% | 0 | 0 | - |

### Battle groups: csame-bb45c30-p24

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 3.3 | 0% | - | - | - | - | - | - | - | - |
| Opponent | REDIRECT COUNTER | 0.3 | 100% | 100% | 0% | - | 0% | 0% | 100% | 0% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: csame-bb45c30-p24

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 5 | 48 (5) | 0 | 48 | 34 | 80% | 5.0 | 60 (4) | 0 (1) | - | 48 (5) | - |
| Mine | Character | 7 | 57 (7) | 57 | 0 | 3 | 71% | 1.5 | 42 (4) | 71 (3) | - | 45 (3) | 67 (4) |
| Mine | Fast Hammer | 7 | 31 (7) | 1 | 30 | 13 | 57% | 5.3 | 0 (1) | 4 (4) | 109 (2) | 0 (1) | 43 (6) |
| Mine | Hammer | 1 | 87 (1) | 0 | 87 | 0 | 0% | 2.0 | 87 (1) | - | - | 87 (1) | - |
| Mine | Holder | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | 0 (1) | - | - | - | 0 (1) |
| Mine | Support | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | 0 (1) | - | - | - | 0 (1) |
| Mine | Wizard | 2 | 0 (2) | 0 | 0 | 76 | 0% | 1.0 | 0 (2) | - | - | 0 (2) | - |
| Opponent | Chaff | 2 | 0 (2) | 0 | 0 | 50 | 100% | - | 0 (2) | - | - | 0 (2) | - |
| Opponent | Character | 5 | 15 (5) | 15 | 0 | 0 | 0% | 1.0 | 16 (4) | - | 0 (1) | 9 (2) | 18 (3) |
| Opponent | Clean-up | 2 | 55 (2) | 0 | 55 | 0 | 0% | 1.5 | 111 (1) | 0 (1) | - | 111 (1) | 0 (1) |
| Opponent | Fast Hammer | 3 | 0 (3) | 0 | 0 | 59 | 0% | 1.7 | 0 (1) | 0 (2) | - | 0 (1) | 0 (2) |
| Opponent | Hammer | 6 | 31 (6) | 31 | 0 | 16 | 50% | 4.0 | 0 (3) | 123 (2) | 0 (1) | 0 (1) | 36 (5) |
| Opponent | Shooter | 5 | 19 (5) | 0 | 19 | 75 | 0% | 1.2 | 0 (1) | 35 (3) | 0 (1) | 0 (2) | 26 (3) |
| Opponent | Wizard | 1 | 0 (1) | 0 | 0 | 0 | 0% | 2.0 | - | - | 0 (1) | - | 0 (1) |

### Charged fights: csame-bb45c30-p24

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Vampire Counts | 1 | 0 | 365 | 5.0 | 1.0 | 73 | 0 | +73 | 0 of 5 | 5 of 5 | - | +73 |
| Mine | Warriors of Chaos | 1 | 0 | 598 | 6.0 | 1.0 | 100 | 0 | +100 | 1 of 6 | 4 of 6 | - | +100 |
| **Mine** | all armies | 2 | 0 | 482 | 5.5 | 1.0 | 88 | 0 | +88 | 1 of 11 | 9 of 11 | - | +88 |
| Opponent | Wood Elf Realms | 2 | 22 | 218 | 1.0 | 1.0 | 218 | 0 | +218 | 0 of 2 | 1 of 2 | - | +218 |

### Effective charges: csame-bb45c30-p24

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Vampire Counts | 5 | 0 | 0 | 0 | 0 | 4 (net +91) | 1 (net +0) | 0 | 0% (0 of 5) |
| Mine | Warriors of Chaos | 6 | 0 | 0 | 0 | 0 | 1 (net +340) | 2 (net +129) | 3 | 0% (0 of 3) |
| Opponent | Wood Elf Realms | 2 | 0 | 1 (net +250) | 0 | 0 | 0 | 1 (net +186) | 0 | 0% (0 of 2) |

### Charged fights, damage counted: csame-bb45c30-p24

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 | 381 | 175 | +86 | 119 | 0 | +119 | +31.2 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 5 | 473 | 119 | +141 | 141 | 12 | +129 | +27.3 |
| Mine | No odds | 3 | 275 | 190 | +0 | 36 | 42 | -6 | -2.3 |
| Mine | All fights | 11 | 394 | 154 | +88 | 106 | 17 | +89 | +22.7 |
| Opponent | 50-54% | 1 | 102 | 60 | +250 | 250 | 17 | +233 | +228.4 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 499 | 186 | +186 | 186 | 0 | +186 | +37.3 |
| Opponent | All fights | 2 | 300 | 123 | +218 | 218 | 8 | +210 | +69.7 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| csame-bb45c30-p24 | move | 24 | 5 (21%) | 5 (21%) | 1 (4%) | 18 (75%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L2535, L2735 |
| Horn of the Wild Hunt | Opponent | L3033 |
| Invocation of Nehek | Mine | L2535, L2735 |
| Ring of Doom | Opponent | L3033 |

# Doctrine scorecard: csame-bb45c30-p18

### Scorecard: csame-bb45c30-p18

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0918 | 6 | 1 | Mine | no | 0 | 6 | 0 | 1 | 0 | 0 | 0 | 250 |
| L0918 | 6 | 1 | Opponent | no | 4 | - | 2 | 3 | 1 | 0 | 0 | 185 |
| L0934 | 4 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 503 |
| L0934 | 4 | 1 | Opponent | no | 0 | 3 | 5 | 5 | 0 | 0 | 0 | 500 |
| L1026 | 6 | 1 | Mine | no | 12 | 2 | 4 | 0 | 0 | 0 | 0 | 0 |
| L1026 | 6 | 1 | Opponent | no | 0 | 3 | 3 | 2 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 0% | 4.0 | 4.0 | 1.3 | 0.7 | 0.0 | 0.0 | 0.0 | 251.0 |
| **Average** | | | Opponent | 0% | 1.3 | 3.0 | 3.3 | 3.3 | 0.3 | 0.0 | 0.0 | 228.3 |

### KPIs: csame-bb45c30-p18

Rules off - Mine only: NO OLD ONE-MOVE GUESS; both sides: ONE RUN A PLAN.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 62% (8 of 13) | 0% (0 of 13) | 31% (8 of 26) |
| Winner chose to follow up after the loser gave ground |  | 83% (5 of 6); on the table 83% | 100% (1 of 1); on the table 100% | 86% (6 of 7); on the table 86% |
| Winner chose to pursue after the loser fell back in good order |  | 100% (1 of 1); on the table 100% | 100% (2 of 2); on the table 100% | 100% (3 of 3); on the table 100% |
| Winner chose to pursue after the loser fled |  | 100% (2 of 2); on the table 100% | - | 100% (2 of 2); on the table 100% |
| Winner chose to follow up or pursue (all three) |  | 89% (8 of 9); on the table 89% | 100% (3 of 3); on the table 100% | 92% (11 of 12); on the table 92% |
| Magic missiles tried each own turn | 50%+ | 44% (21 of 48) | 25% (3 of 12) | 40% (24 of 60) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 52% (21 of 40) | 25% (3 of 12) | 46% (24 of 52) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | - | - |
| Points that never fought | lower | 59% (3551 of 5997) | 79% (4744 of 5998) | 69% (8295 of 11995) |
|   infantry points that never fought | lower | 55% (881 of 1591) | 79% (910 of 1147) | 65% (1791 of 2738) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 68% (23 of 34) | 80% (16 of 20) | 72% (39 of 54) |
| Bound items with a magic missile used (at least once a game) |  | 100% (2 of 2); 1.3 uses a game | 100% (1 of 1); 1.3 uses a game | 100% (3 of 3); 1.3 uses a game |
| Bound items with another spell used |  | 100% (1 of 1); 0.3 uses a game | 0.0 uses a game | 100% (1 of 1); 0.2 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0% (0 of 1); 0.0 uses a game | 0% (0 of 1); 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |
|   their share of the points of units over 100 pts | lower | 62% (3535 of 5667) | 78% (4063 of 5186) | 70% (7598 of 10853) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 4.7 (52%) | 0.0 (0%) | 4.7 (39%) |
| MARCHED: its unit marched | 1.7 (19%) | 1.0 (33%) | 2.7 (22%) |
| IN COMBAT: engaged in combat | 2.7 (30%) | 0.0 (0%) | 2.7 (22%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.7 (22%) | 0.7 (6%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 1.3 (44%) | 1.3 (11%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 4.0 | 0.3 | 8.0 | 1.3 | 0.3 |
| not cast | 2.0 | 5.7 | 12.0 | 2.7 | 15.7 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (2%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 3.3 (59%) | 4.7 (39%) | 0.7 (25%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 2.7 (22%) | 0.7 (25%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.0 (0%) | 2.7 (22%) | 0.7 (25%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 2.0 (100%) | 2.0 (35%) | 0.7 (6%) | 0.0 (0%) | 0.0 (0%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (0%) | 0.3 (6%) | 0.0 (0%) | 0.0 (0%) | 0.7 (4%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (25%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 1.3 (11%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 14.7 (94%) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 60% (79 of 131) | 77% (57 of 74) | 66% (136 of 205) |
|   cavalry | - | 67% (8 of 12) | 67% (8 of 12) |
|   character | 100% (7 of 7) | 78% (14 of 18) | 84% (21 of 25) |
|   chariot | 76% (13 of 17) | 100% (5 of 5) | 82% (18 of 22) |
|   infantry | 45% (21 of 47) | 67% (18 of 27) | 53% (39 of 74) |
|   monster | 75% (9 of 12) | 100% (12 of 12) | 88% (21 of 24) |
|   war machine | 60% (29 of 48) | - | 60% (29 of 48) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 3.7 (21%) | 3.7 (65%) | 7.3 (32%) |
| CHARGED: it charged | 0.3 (2%) | 0.7 (12%) | 1.0 (4%) |
| IN COMBAT: it fought this turn or the last | 1.0 (6%) | 0.3 (6%) | 1.3 (6%) |
| MOVED: a war machine that moved | 1.7 (10%) | 0.0 (0%) | 1.7 (7%) |
| NO TARGET IN RANGE | 2.7 (15%) | 0.3 (6%) | 3.0 (13%) |
| ONLY IN COMBAT: the only targets were in combat | 0.7 (4%) | 0.0 (0%) | 0.7 (3%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 2.7 (15%) | 0.7 (12%) | 3.3 (14%) |
| SHELTERED: the target was sheltered | 4.0 (23%) | 0.0 (0%) | 4.0 (17%) |
| OTHER BAR | 0.7 (4%) | 0.0 (0%) | 0.7 (3%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 4.0 | 0.3 | 92% | 1.1 pts | 4 pts |
| character | 7.0 | 2.7 | 67% | 5.7 pts | 40 pts |
| chariot | 6.0 | 4.0 | 72% | 10.7 pts | 64 pts |
| infantry | 13.3 | 7.3 | 68% | 7.9 pts | 106 pts |
| monster | 10.0 | 2.3 | 83% | 4.0 pts | 40 pts |
| war machine | 9.7 | 7.3 | 69% | 18.6 pts | 179 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 2.3 | 3.0 | 2.7 |
| Charges that made contact a game | 2.3 | 2.0 | 2.2 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.67 declared, 1.67 contact (3 units) | 0.00 declared, 0.00 contact (1 units) | 1.25 declared, 1.25 contact (4 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 3.00 declared, 2.00 contact (1 units) | 3.00 declared, 2.00 contact (1 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.10 declared, 0.10 contact (20 units) | 0.19 declared, 0.13 contact (31 units) | 0.16 declared, 0.12 contact (51 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 50% (2 of 4) | - | - | 50% (2 of 4) |
| Character in a unit | 100% (5 of 5) | 100% (1 of 1) | - | 100% (6 of 6) |
| Character on its own | - | 33% (1 of 3) | 60% (3 of 5) | 50% (4 of 8) |
| Chariot | 100% (3 of 3) | 50% (1 of 2) | - | 80% (4 of 5) |
| Infantry | 45% (5 of 11) | 100% (2 of 2) | 0% (0 of 1) | 50% (7 of 14) |
| Monster | 100% (1 of 1) | 100% (1 of 1) | - | 100% (2 of 2) |
| Monstrous | 100% (2 of 2) | 100% (5 of 5) | - | 100% (7 of 7) |
| War Machines | 88% (7 of 8) | - | - | 88% (7 of 8) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Empire of Man | 2 | 100% (5 of 5); on the table 100% | 54% (13 of 24) | 61% | 75% (18 of 24) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Grand Cathay | 1 | 75% (3 of 4); on the table 75% | 33% (8 of 24) | 57% | 50% (5 of 10) | 100% (2 of 2); 4.0 uses a game | 100% (1 of 1); 1.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Ogre Kingdoms | 1 | - | 0% (0 of 6) | 92% | 100% (7 of 7) | 100% (1 of 1); 4.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 1 | 100% (1 of 1); on the table 100% | 50% (3 of 6) | 50% | 80% (4 of 5) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 1 | 100% (2 of 2); on the table 100% | - | 95% | 62% (5 of 8) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (csame-bb45c30-p18, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 25% (1) | 40% (2) | 33% (3) |
| ...free all their last turn and able to turn (per game) | 0.33 | 0.67 | 1.00 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.33 | 0.33 | 0.67 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: csame-bb45c30-p18

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.3 | 2.0 |
| Strategy | Charge objectives carried out (made contact) | 100% (6 of 6) | 43% (3 of 7) |
| Strategy | Shoot objectives carried out (shot that target) | 30% (16 of 54) | 61% (11 of 18) |
| Strategy | Support requests answered (helper made contact too) | 100% (1 of 1) | 0% (0 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | 100% (1 of 1) | - |
| Strategy | Joined characters whose unit fought | 56% (5 of 9) | 0% (0 of 1) |
| Strategy | Lone characters that fought | 40% (2 of 5) | 20% (1 of 5) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 0.7 | 3.3 |
| Movement | Points that never moved of their own | 251.0 | 228.3 |
| Movement | Fights charged into per game | 2.0 | 2.0 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 5 | 0 of 5 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 5 | 3 of 5, net +35 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 3 of 5, net +61 | 0 of 5 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 of 5, net +0 | 1 of 5, net +0 |
| Shooting | Shots by shooting units (incl. breath weapons) | 17.0 | 19.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 29% (15 of 51) | 53% (30 of 57) |
| Shooting | Points destroyed by shooting units | 0.0 | 0.0 |
| Shooting | War machine shots | 9.7 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 62% (18 of 29) | - |
| Shooting | Points destroyed by war machines | 41.3 | 0.0 |
| Magic | Magic missiles cast | 4.0 | 1.0 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 8% (1 of 12) | 100% (3 of 3) |
| Magic | Wounds caused by magic missiles | 8.3 | 0.3 |
| Magic | Wounds caused by other spells | 2.3 | - |
| Magic | Points destroyed by magic (all spells) | 32.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.0 / 0.3 / 0.3 / 0.7 | 2.3 / 0.0 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 66.3 | 0.0 |
| Combat | Points run down | 25.7 | 34.7 |
| Combat | Net points per charged fight, damage counted | +51 | +49 |
| Combat | Net per 100 charger points, damage counted | +16.5 | +22.9 |
| Combat | First round won (charged fights) | 100% | 67% |
| Combat | Net points per charged fight | +40 | +29 |
| Combat | Net points per supported fight / lone fight | +77 / +33 | - / +29 |
| Combat | Charged fights on a top-3 enemy unit | 0 of 6 | 0 of 6 |
| Game | Points lost | 104.0 | 288.7 |
| Game | VP from objectives | 590.0 | 610.0 |
| Game | Lone holders (player turns) | 4.0 | 1.3 |

- Mine won / drew / lost: 2 / 0 / 1 of 3 ended games (of 3); mean margin (Mine - Opponent) +202 VP
- The side that went first won 3 of 3 games with a winner
- Points traded per game (both sides' losses): 393
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: csame-bb45c30-p18

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.3 | +14.0 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | 11.0 | +309.5 | 0.0 | 104.0 | 31.7 | +167.0 | 0.0 | 159.7 |
| ARRIVAL HUNT | - | - | - | - | 0.3 | +15.6 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 6.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| BACKUP TARGETS | - | - | - | - | 0.3 | +0.9 | 0.0 | 0.0 |
| BEST PRIZE | - | - | - | - | 0.7 | -34.8 | 0.0 | 0.0 |
| BOUND ASSAILMENT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CANNON PLANNED TARGET | 8.0 | +91.7 | 64.0 | 0.0 | - | - | - | - |
| CANNON SIGHT KEPT | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CAST JOB | 5.7 | +94.1 | 81.3 | 0.0 | - | - | - | - |
| CASTER AWAY FROM SCREEN | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | - | - | - | - | 1.3 | +29.1 | 0.0 | 0.0 |
| CHALLENGE BY POINTS | 1.0 | +4.4 | 0.0 | 0.0 | 0.3 | +1.4 | 0.0 | 0.0 |
| CHAMPION KNOWS CHALLENGE | 0.3 | -1.7 | 25.7 | 0.0 | - | - | - | - |
| CHARACTER GUNS | 5.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHARGE LOSSES | 16.0 | -476.8 | 0.0 | 138.7 | 18.0 | -639.1 | 0.0 | 60.0 |
| CHARGE NOW FIRST | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 8.3 | +0.0 | 0.0 | 0.0 | 16.3 | +0.0 | 0.0 | 26.3 |
| COVER ONCE | 8.7 | -256.1 | 0.0 | 34.7 | 3.7 | -400.1 | 0.0 | 0.0 |
| DENIED BY THE FIGHT | 0.3 | -0.2 | 25.7 | 0.0 | 1.3 | -17.6 | 104.0 | 0.0 |
| DEPLOY BY FIGURES | 9.0 | -55.1 | 0.0 | 0.0 | 9.0 | +40.5 | 0.0 | 0.0 |
| EVASIVE BY THE ODDS | - | - | - | - | 1.0 | +2.3 | 0.0 | 0.0 |
| EXACT ROUND | 1.7 | +8.1 | 80.7 | 0.0 | 1.0 | -11.3 | 34.7 | 0.0 |
| FALL BACK GOOD ORDER | 2.0 | +0.0 | 86.3 | 0.0 | 2.0 | +0.7 | 104.0 | 0.0 |
| FALLS SHORT | - | - | - | - | 32.0 | +369.2 | 0.0 | 341.0 |
| FEATURE BUFFS | - | - | - | - | 0.7 | +10.0 | 0.0 | 0.0 |
| FIGHT TO THE END | 0.3 | +4.0 | 0.0 | 0.0 | 0.7 | +1.4 | 34.7 | 0.0 |
| FIRE IN ORDER | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FIVE ACTION | 106.3 | +4805.5 | 693.7 | 208.0 | 103.0 | +4917.8 | 104.0 | 832.7 |
| FLANK NOT WEIGHED | 5.0 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 13.3 |
| FOLLOW UP WEIGHED | 0.7 | +32.1 | 0.0 | 0.0 | - | - | - | - |
| FOUR ROUNDS | 2.3 | +60.2 | 106.3 | 0.0 | 2.7 | +187.3 | 104.0 | 0.0 |
| FREED FROM HIS FIGHT | 2.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 0.3 | -0.5 | 0.0 | 0.0 | 0.7 | -3.8 | 0.0 | 0.0 |
| FRIENDS SHOTS CHECKED | 0.3 | -1.1 | 0.0 | 0.0 | 0.3 | -0.3 | 0.0 | 0.0 |
| GIVES UP | 1.0 | -6.0 | 55.0 | 0.0 | - | - | - | - |
| GOAL WALK | 9.0 | +446.5 | 0.0 | 0.0 | 24.3 | +2229.6 | 0.0 | 97.3 |
| GROUND FLIERS | 0.3 | +4.9 | 0.0 | 0.0 | - | - | - | - |
| GUN FIGURES | 2.3 | +33.1 | 61.7 | 0.0 | 0.3 | +7.7 | 0.0 | 0.0 |
| GUN MASK | 5.7 | +378.2 | 0.0 | 0.0 | - | - | - | - |
| HARD STAY DROPPED | 3.3 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 246.7 |
| HE REFORMS ONCE FREED | 1.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 8.7 | +0.0 | 0.0 | 104.0 | 5.3 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE LIST | 3.7 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 20.0 |
| HIS LEGAL MOVES | 1.0 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 22.7 |
| HIS MOVE AND SHOT | 2.7 | -6.0 | 0.0 | 69.3 | 7.0 | -83.6 | 0.0 | 60.7 |
| HIS MOVE AS HE DECIDES | 51.0 | +15.0 | 486.0 | 0.0 | - | - | - | - |
| HIS MOVE WHY | - | - | - | - | 24.3 | +0.0 | 0.0 | 37.3 |
| HIS ONE MOVE | 17.3 | +21.3 | 0.0 | 0.0 | - | - | - | - |
| HIS ONE QUARTER | 1.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 0.7 | +0.0 | 0.0 | 0.0 | 5.7 | +0.0 | 0.0 | 22.7 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 41.7 | +1246.7 | 0.0 | 208.0 | 81.3 | +6034.7 | 0.0 | 302.0 |
| HIS SHOTS BY HIS RUN | 33.0 | +564.7 | 0.0 | 208.0 | 65.3 | +1633.0 | 0.0 | 264.7 |
| HIS TURN DENIED | 0.3 | +0.8 | 25.7 | 0.0 | 1.7 | +90.9 | 104.0 | 0.0 |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 17.0 | +0.0 | 0.0 | 138.7 | 19.3 | +0.0 | 0.0 | 51.3 |
| HOLDER ASSIGNMENT | 12.3 | +1325.3 | 0.0 | 69.3 | 13.3 | +1250.9 | 0.0 | 25.7 |
| HOLDS AMBUSHERS | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 2.0 | -46.9 | 80.7 | 0.0 | 2.3 | -124.3 | 69.3 | 0.0 |
| IDLE COST | - | - | - | - | 22.3 | -347.8 | 0.0 | 69.7 |
| JOINT CHARGE NOW | 0.7 | +26.5 | 51.3 | 0.0 | 0.3 | +12.1 | 0.0 | 0.0 |
| KEPT FROM ITS LAST STOP | 5.7 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 0.7 | +15.4 | 0.0 | 0.0 | 1.3 | +93.2 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 1.0 | +0.0 | 35.0 | 34.7 | 5.7 | +0.0 | 104.0 | 105.3 |
| LONE WIZARD KEPT IN | 1.3 | +43.3 | 0.0 | 0.0 | - | - | - | - |
| LONG SHOT | 0.3 | +24.0 | 25.7 | 0.0 | 1.0 | +10.8 | 69.3 | 0.0 |
| LOST AFTER ESCAPE | 2.0 | +2.4 | 91.3 | 0.0 | 2.0 | +7.1 | 69.3 | 0.0 |
| MAKE SURE TOGETHER | 1.0 | +3.2 | 0.0 | 0.0 | - | - | - | - |
| MANOEUVRE | 2.3 | -12.7 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| MARCH BY THE SUM | 1.0 | +74.8 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | 1.3 | +74.7 | 0.0 | 0.0 | 0.3 | +17.4 | 0.0 | 0.0 |
| MARCH OF THE TABLE | 0.7 | +8.8 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 1.3 | +11.8 | 0.0 | 0.0 | - | - | - | - |
| MARCH WHEELS ONLY | 4.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 1.7 | +7.8 | 0.0 | 0.0 | 1.7 | +14.7 | 0.0 | 42.7 |
| MEETS IN TIME | 3.7 | +414.2 | 0.0 | 0.0 | 3.7 | +549.1 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 10.0 | +167.4 | 0.0 | 0.0 | 2.3 | +31.4 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 12.0 | +117.2 | 0.0 | 0.0 | 3.0 | +24.2 | 0.0 | 0.0 |
| MOVE ORDER | 1.3 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 41.3 | 11.3 |
| MOVE TO CHARGE COMPUTED | 3.3 | +151.2 | 0.0 | 0.0 | 2.7 | +128.5 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 5.7 | +247.7 | 0.0 | 0.0 | 6.3 | +282.0 | 0.0 | 20.0 |
| NEXT CHARGE BY LIST | 2.3 | +105.9 | 0.0 | 0.0 | 2.7 | +128.5 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 1.7 | -22.4 | 91.3 | 0.0 | 2.3 | -115.5 | 69.3 | 0.0 |
| NO LATE CUT | 4.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OFF BEST | 5.0 | -177.5 | 20.0 | 0.0 | 5.0 | -57.3 | 0.0 | 25.7 |
| OGRE LOADER SECOND SHOT | 3.7 | +10.3 | 0.0 | 0.0 | - | - | - | - |
| ONE CHALLENGE TEST | 0.3 | -3.3 | 0.0 | 0.0 | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ONE FIGHT FORMULA | 3.7 | -69.4 | 0.0 | 0.0 | 3.0 | -63.4 | 0.0 | 11.3 |
| ONE OBJECTIVE FORMULA | 3.7 | +90.6 | 0.0 | 34.7 | 5.0 | -29.3 | 0.0 | 25.7 |
| ONE ROUTE | 4.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| OPENS UP | - | - | - | - | 0.3 | +17.2 | 34.7 | 0.0 |
| OVERRUNS AWAY | 0.3 | +107.9 | 15.0 | 0.0 | 1.3 | +8.2 | 0.0 | 0.0 |
| OWN CAST FIRST | - | - | - | - | 0.3 | -0.1 | 0.0 | 0.0 |
| PLAN RESULT | 45.7 | +803.3 | 165.0 | 173.3 | 47.0 | +146.4 | 34.7 | 486.0 |
| PROMISE BY ITS OWN SUM | 8.3 | -338.3 | 0.0 | 0.0 | 3.3 | -94.5 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE READS THE TABLE | 0.3 | -0.5 | 0.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | 10.0 | +827.0 | 0.0 | 0.0 | 15.0 | +915.5 | 0.0 | 0.0 |
| REAL GROUND | 4.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | - | - | - | - | 4.7 | +258.9 | 0.0 | 60.7 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 5.0 | +0.0 | 0.0 | 51.0 |
| REFORMS TO MEET IT | 0.7 | -1.6 | 0.0 | 0.0 | - | - | - | - |
| REFUSING RETIRES | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | - | - | - | - | 0.7 | +31.4 | 0.0 | 13.3 |
| RISK BY ARC | 2.3 | -31.0 | 106.3 | 0.0 | 2.0 | -127.4 | 69.3 | 0.0 |
| RISK ON THE WAY | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| ROUNDS AFTER TERROR | 0.3 | +10.0 | 25.7 | 0.0 | 1.0 | -35.1 | 34.7 | 0.0 |
| RUN DOWN | 0.7 | -8.0 | 51.3 | 0.0 | 2.7 | -49.7 | 104.0 | 0.0 |
| SCOUT SPOT | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +7.2 | 0.0 | 0.0 |
| SCOUT WAITS | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 2.7 | -266.7 | 0.0 | 0.0 |
| SEARCH SPOT | 1.0 | +5.2 | 0.0 | 34.7 | 0.3 | +39.2 | 0.0 | 0.0 |
| SECOND LOOK | 0.3 | +8.1 | 20.0 | 0.0 | 0.3 | +12.4 | 0.0 | 0.0 |
| SET CREDITED ONCE | 0.3 | -0.4 | 0.0 | 0.0 | - | - | - | - |
| SET UP BY THE SET | 1.7 | +21.6 | 30.0 | 0.0 | - | - | - | - |
| SET UP TOGETHER | 1.0 | +3.2 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | 0.7 | +1.3 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS ON THE TABLE | 18.0 | +0.0 | 0.0 | 0.0 | 7.7 | +0.0 | 0.0 | 265.3 |
| SHOOTS FROM THE BEST SPOT | 2.7 | +12.7 | 37.3 | 0.0 | 0.7 | +2.3 | 0.0 | 0.0 |
| SHOT OR CHARGE | - | - | - | - | 0.7 | -16.0 | 0.0 | 0.0 |
| SHOT RISK POINTS | 23.7 | -246.2 | 0.0 | 104.0 | 46.7 | +118.1 | 0.0 | 184.0 |
| SHOTS AFTER THE MOVES | 5.3 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 29.0 | +935.9 | 0.0 | 69.3 | 18.7 | +300.3 | 0.0 | 291.0 |
| SPELL WORTH | - | - | - | - | 4.0 | +46.0 | 0.0 | 0.0 |
| SPELLS IN THE FIGHT | 0.3 | +1.1 | 20.0 | 0.0 | - | - | - | - |
| SPOT AS THE GAME MOVES | 4.0 | +0.0 | 0.0 | 0.0 | 7.0 | +0.0 | 0.0 | 80.0 |
| STAND AND SHOOT | 0.3 | -1.4 | 25.7 | 0.0 | 1.3 | -8.6 | 34.7 | 0.0 |
| STANDS FOR A REASON | - | - | - | - | 12.0 | +0.0 | 0.0 | 37.3 |
| STANDS STILL | 59.7 | +0.0 | 587.3 | 0.0 | 31.3 | +0.0 | 0.0 | 530.7 |
| STAY WORTH | 46.7 | +217.7 | 550.0 | 34.7 | 25.7 | +237.3 | 0.0 | 814.7 |
| STRIKE BY THE ODDS | - | - | - | - | 0.7 | +1.4 | 0.0 | 37.0 |
| SUPPORT ADDS | 2.0 | +102.0 | 0.0 | 0.0 | 3.0 | +68.2 | 0.0 | 15.0 |
| SUPPORT NARROWED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SUPPORT WORKED OUT | 2.0 | +102.0 | 0.0 | 0.0 | 3.0 | +68.2 | 0.0 | 15.0 |
| SWIFTSTRIDE BY POINTS | 0.3 | +1.8 | 0.0 | 0.0 | - | - | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 1.7 | +0.0 | 0.0 | 34.7 | 1.7 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 3.3 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 48.7 |
| THE ROW KEEPS ITS WAY | 2.7 | +0.0 | 0.0 | 34.7 | 5.7 | +0.0 | 0.0 | 59.0 |
| THE STEP BACK IS MADE | 2.0 | +0.0 | 0.0 | 34.7 | 4.3 | +0.0 | 0.0 | 45.7 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 44.3 | +0.0 | 0.0 | 104.0 | 50.3 | +0.0 | 0.0 | 410.7 |
| TIED UP BY THE SUM | 0.7 | +77.9 | 35.0 | 0.0 | 0.7 | +115.7 | 34.7 | 0.0 |
| TIME ON OUR SIDE | 53.3 | +661.1 | 242.0 | 104.0 | - | - | - | - |
| WAITS AGAIN | 1.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| WAR ENGINE JOBS | 0.7 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 493.3 |
| WHO FIGHTS | 0.7 | -0.1 | 25.7 | 0.0 | 0.3 | +0.8 | 0.0 | 0.0 |
| WHO HITS BACK | 0.7 | +86.4 | 0.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT DANGER | 1.7 | -93.8 | 0.0 | 34.7 | 1.0 | -41.0 | 0.0 | 0.0 |
| WOUNDS ON THE RANKS | 4.0 | +39.1 | 0.0 | 0.0 | 0.7 | +10.5 | 0.0 | 0.0 |

### Rule changes: csame-bb45c30-p18

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS SHOT LIST | 369 | 365 | 136 | 45.33 | +2318 | +17.0 |
| HIS MOVE AS HE DECIDES | 153 | 153 | 108 | 36.00 | +0 | +0.0 |
| ARMY TABLE | 128 | 128 | 94 | 31.33 | +1274 | +13.6 |
| HIS SHOTS BY HIS RUN | 295 | 291 | 85 | 28.33 | +1209 | +14.2 |
| HOLDER ASSIGNMENT | 77 | 77 | 71 | 23.67 | +4645 | +65.4 |
| HIS MOVE WHY | 73 | 73 | 52 | 17.33 | +0 | +0.0 |
| SHOT RISK POINTS | 211 | 208 | 49 | 16.33 | +1525 | +31.1 |
| GOAL WALK | 100 | 99 | 36 | 12.00 | +1578 | +43.8 |
| DEPLOY BY FIGURES | 54 | 54 | 32 | 10.67 | +492 | +15.4 |
| OFF BEST | 30 | 30 | 30 | 10.00 | -705 | -23.5 |
| THE TABLE AGAIN | 36 | 36 | 26 | 8.67 | +0 | +0.0 |
| HARD STAY DROPPED | 23 | 23 | 23 | 7.67 | +0 | +0.0 |
| TIME ON OUR SIDE | 160 | 134 | 23 | 7.67 | +123 | +5.4 |
| LEGAL CHARGES ONLY | 20 | 20 | 20 | 6.67 | +0 | +0.0 |
| ARTILLERY RE-ROLL WEIGHED | 19 | 19 | 19 | 6.33 | +0 | +0.0 |
| HIS ONE MOVE | 52 | 46 | 18 | 6.00 | +0 | +0.0 |
| MEETS IN TIME | 22 | 22 | 18 | 6.00 | +1382 | +76.8 |
| PROMISE BY ITS OWN SUM | 35 | 35 | 17 | 5.67 | -1299 | -76.4 |
| STAY WORTH | 217 | 192 | 17 | 5.67 | +141 | +8.3 |
| REDIRECT FOR A FRIEND IN REACH | 15 | 15 | 15 | 5.00 | +0 | +0.0 |
| CAST JOB | 17 | 17 | 13 | 4.33 | +115 | +8.9 |
| MOVE ORDER | 13 | 13 | 13 | 4.33 | +0 | +0.0 |
| OGRE LOADER SECOND SHOT | 11 | 11 | 11 | 3.67 | +31 | +2.8 |
| IDLE COST | 67 | 44 | 10 | 3.33 | +97 | +9.7 |
| FIVE ACTION | 628 | 616 | 9 | 3.00 | +379 | +42.1 |
| MOVE TO CHARGE COMPUTED | 18 | 11 | 9 | 3.00 | +183 | +20.4 |
| NEXT CHARGE BY LIST | 15 | 11 | 8 | 2.67 | +183 | +22.9 |
| CHARGE LOSSES | 102 | 99 | 7 | 2.33 | +876 | +125.2 |
| FOUR ROUNDS | 15 | 14 | 7 | 2.33 | +245 | +35.0 |
| GUN MASK | 17 | 17 | 6 | 2.00 | +258 | +43.1 |
| LANE BY FIGURES | 6 | 6 | 6 | 2.00 | +326 | +54.3 |
| SUPPORT ADDS | 15 | 15 | 6 | 2.00 | +187 | +31.2 |
| SUPPORT WORKED OUT | 15 | 15 | 6 | 2.00 | +187 | +31.2 |
| SCOUT WAITS | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| SHOTS AFTER THE MOVES | 25 | 25 | 5 | 1.67 | +0 | +0.0 |
| SHOTS IN THE MOVE | 143 | 113 | 5 | 1.67 | +140 | +28.0 |
| WOUNDS ON THE RANKS | 14 | 14 | 5 | 1.67 | +28 | +5.7 |
| ADVANCE LANE KEPT | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| CASTING BLOCK | 4 | 4 | 4 | 1.33 | +37 | +9.2 |
| CHALLENGE BY POINTS | 4 | 4 | 4 | 1.33 | +17 | +4.4 |
| LONE WIZARD KEPT IN | 4 | 4 | 4 | 1.33 | +130 | +32.5 |
| MAX FOR POSITIONING | 10 | 9 | 4 | 1.33 | +0 | +0.0 |
| MISSILES IN THE MOVE | 37 | 26 | 4 | 1.33 | +45 | +11.3 |
| NEARER NOT NEEDED | 36 | 34 | 4 | 1.33 | +90 | +22.6 |
| QUARTER ODDS | 75 | 74 | 4 | 1.33 | +171 | +42.6 |
| SHOOTS FROM THE BEST SPOT | 10 | 10 | 4 | 1.33 | +12 | +3.0 |
| TIED UP BY THE SUM | 4 | 4 | 4 | 1.33 | +183 | +45.8 |
| CANNON SIGHT KEPT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| COVER ONCE | 37 | 27 | 3 | 1.00 | +2 | +0.7 |
| FALLS SHORT | 96 | 76 | 3 | 1.00 | +22 | +7.2 |
| JOINT CHARGE NOW | 3 | 3 | 3 | 1.00 | +116 | +38.5 |
| MARCH BY THE SUM | 3 | 3 | 3 | 1.00 | +224 | +74.8 |
| MARCH CHECK | 5 | 5 | 3 | 1.00 | +34 | +11.3 |
| MISSILES NEXT TURN | 45 | 31 | 3 | 1.00 | +1 | +0.4 |
| WHOLE FIGHT DANGER | 8 | 8 | 3 | 1.00 | +189 | +63.0 |
| BEST PRIZE | 2 | 2 | 2 | 0.67 | -104 | -52.2 |
| CASTER AWAY FROM SCREEN | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 2 | 2 | 2 | 0.67 | +96 | +48.2 |
| FRIENDS SHOTS CHECKED | 2 | 2 | 2 | 0.67 | -4 | -2.1 |
| HIS MOVE AND SHOT | 29 | 28 | 2 | 0.67 | +6 | +3.0 |
| LONG SHOT | 4 | 4 | 2 | 0.67 | +69 | +34.6 |
| MARCH OF THE TABLE | 2 | 2 | 2 | 0.67 | -26 | -13.2 |
| REFUSING RETIRES | 2 | 2 | 2 | 0.67 | -40 | -20.0 |
| RESERVE FALL BACK | 2 | 2 | 2 | 0.67 | +94 | +47.1 |
| RISK BY ARC | 13 | 12 | 2 | 0.67 | +37 | +18.6 |
| SEARCH SPOT | 4 | 4 | 2 | 0.67 | +133 | +66.7 |
| SECOND LOOK | 2 | 2 | 2 | 0.67 | +62 | +30.8 |
| SET UP BY THE SET | 5 | 5 | 2 | 0.67 | +20 | +9.8 |
| SHOOTERS IN TWO RANKS | 2 | 2 | 2 | 0.67 | +4 | +2.0 |
| STRIKE BY THE ODDS | 2 | 2 | 2 | 0.67 | +4 | +2.0 |
| THE ROW IN ITS ORDER | 22 | 2 | 2 | 0.67 | +0 | +0.0 |
| WAR ENGINE JOBS | 10 | 10 | 2 | 0.67 | -17 | -8.5 |
| WHO HITS BACK | 2 | 2 | 2 | 0.67 | +236 | +118.1 |
| AFTERMATH IN POINTS | 1 | 1 | 1 | 0.33 | +42 | +42.0 |
| BOUND ASSAILMENT | 1 | 1 | 1 | 0.33 | +0 | +0.1 |
| CANNON PLANNED TARGET | 24 | 24 | 1 | 0.33 | -30 | -29.8 |
| EVASIVE BY THE ODDS | 3 | 3 | 1 | 0.33 | +0 | +0.0 |
| FIRE IN ORDER | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| HIS TURN DENIED | 6 | 6 | 1 | 0.33 | +62 | +62.0 |
| HOLDS AMBUSHERS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| MANOEUVRE | 9 | 9 | 1 | 0.33 | +1 | +0.6 |
| OVERRUNS AWAY | 5 | 5 | 1 | 0.33 | +43 | +42.6 |
| OWN CAST FIRST | 1 | 1 | 1 | 0.33 | -0 | -0.4 |
| PROMISE READS THE TABLE | 1 | 1 | 1 | 0.33 | +11 | +11.0 |
| SWIFTSTRIDE BY POINTS | 1 | 1 | 1 | 0.33 | +5 | +5.4 |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| BACKUP TARGETS | 1 | 1 | 0 | 0.00 | - | - |
| CHAMPION KNOWS CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| CHARACTER GUNS | 17 | 16 | 0 | 0.00 | - | - |
| CHARGE NOW FIRST | 3 | 3 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 74 | 73 | 0 | 0.00 | - | - |
| DENIED BY THE FIGHT | 5 | 5 | 0 | 0.00 | - | - |
| EXACT ROUND | 8 | 7 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 12 | 12 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 2 | 2 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 3 | 3 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 26 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 10 | 9 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 3 | 3 | 0 | 0.00 | - | - |
| GIVES UP | 3 | 2 | 0 | 0.00 | - | - |
| GROUND FLIERS | 1 | not checked | - | - | - | - |
| GUN FIGURES | 8 | not checked | - | - | - | - |
| HE REFORMS ONCE FREED | 7 | 6 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 42 | 41 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 23 | 22 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 15 | 15 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 7 | 6 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 19 | 19 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN RUN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 109 | 109 | 0 | 0.00 | - | - |
| HONEST WORTH | 13 | 12 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 23 | 23 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 12 | 11 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 3 | not checked | - | - | - | - |
| MARCH OVER CASTS | 4 | 4 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 14 | 14 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 12 | 11 | 0 | 0.00 | - | - |
| NO LATE CUT | 14 | 14 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 18 | 18 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| ONE CHALLENGE TEST | 1 | 1 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 3 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 20 | 13 | 0 | 0.00 | - | - |
| ONE OBJECTIVE FORMULA | 26 | 23 | 0 | 0.00 | - | - |
| ONE ROUTE | 14 | 14 | 0 | 0.00 | - | - |
| OPENS UP | 1 | 1 | 0 | 0.00 | - | - |
| PLAN RESULT | 278 | trace | - | - | - | - |
| PROMISE KNOWS THE FIGHT | 1 | not checked | - | - | - | - |
| REAL GROUND | 14 | 14 | 0 | 0.00 | - | - |
| REDIRECT COUNTER | 14 | 14 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 2 | not checked | - | - | - | - |
| RISK ON THE WAY | 2 | 2 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 4 | 4 | 0 | 0.00 | - | - |
| RUN DOWN | 10 | 10 | 0 | 0.00 | - | - |
| SCOUT SPOT | 4 | 4 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 8 | 8 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 1 | 1 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 3 | 2 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 77 | not checked | - | - | - | - |
| SHOT OR CHARGE | 2 | 2 | 0 | 0.00 | - | - |
| SPELL WORTH | 12 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 33 | 31 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 5 | 5 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 36 | 34 | 0 | 0.00 | - | - |
| STANDS STILL | 273 | 269 | 0 | 0.00 | - | - |
| SUPPORT NARROWED | 1 | 1 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 10 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 25 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 19 | not checked | - | - | - | - |
| THE TABLE BINDS | 284 | not checked | - | - | - | - |
| WAITS AGAIN | 5 | 5 | 0 | 0.00 | - | - |
| WHO FIGHTS | 3 | 3 | 0 | 0.00 | - | - |

### Off best figure: csame-bb45c30-p18

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 4.33 | 4.67 | 25.5 |
| PROMISE BY ITS OWN SUM | rule | 5.00 | 0.67 | 76.4 |
| ARMY TABLE | rule | - | 3.67 | 51.8 |
| HOLDER ASSIGNMENT | rule | 0.67 | 0.67 | 25.1 |
| AFTERMATH BAND | gate | 0.33 | 0.33 | 2.1 |
| BEST PRIZE | rule | - | 0.67 | 52.2 |
| FRIENDS SHOTS CHECKED | rule | 0.33 | 0.33 | 2.1 |
| MARCH OF THE TABLE | rule | 0.67 | - | 13.2 |
| REFUSING RETIRES | rule | - | 0.67 | 20.0 |
| WAR ENGINE JOBS | rule | 0.67 | - | 8.5 |
| CANNON PLANNED TARGET | rule | 0.33 | - | 29.8 |
| RULE SWITCHED OFF | gate | 0.33 | - | 13.0 |

### Plans: csame-bb45c30-p18

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.3 | 75% | 63 | 77 | 122% |
| Mine | move | 28.7 | 99% | 1412 | 0 | 0% |
| Mine | shoot | 15.7 | 55% | 681 | 726 | 107% |
| Opponent | charge | 1.7 | 40% | 79 | 75 | 95% |
| Opponent | move | 39.3 | 95% | 1915 | 0 | 0% |
| Opponent | shoot | 4.7 | 36% | 250 | 72 | 29% |
| Opponent | support | 1.3 | 100% | 0 | 0 | - |

### Battle groups: csame-bb45c30-p18

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | REDIRECT COUNTER | 4.7 | 29% | 75% | 0% | - | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: csame-bb45c30-p18

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Character | 12 | 15 (12) | 15 | 0 | 0 | 25% | 3.1 | 16 (5) | 9 (5) | 32 (2) | 12 (8) | 18 (4) |
| Mine | Clean-up | 2 | 83 (2) | 0 | 83 | 0 | 100% | - | - | - | 83 (2) | 83 (2) | - |
| Mine | Fast Hammer | 3 | 39 (3) | 0 | 39 | 0 | 0% | 2.3 | 0 (1) | 61 (2) | - | 55 (2) | 0 (1) |
| Mine | Hammer | 7 | 13 (7) | 13 | 0 | 0 | 14% | 1.8 | 0 (1) | 5 (3) | 23 (3) | 18 (5) | 0 (2) |
| Mine | Shooter | 6 | 111 (6) | 0 | 111 | 50 | 0% | 2.0 | 0 (1) | 231 (2) | 67 (3) | 133 (5) | 0 (1) |
| Mine | War machine | 8 | 3 (8) | 3 | 0 | 0 | 0% | 1.1 | 0 (1) | 7 (4) | 0 (3) | - | 3 (8) |
| Mine | Wizard | 2 | 0 (2) | 0 | 0 | 0 | 50% | 2.0 | - | 0 (2) | - | 0 (2) | - |
| Opponent | Chaff | 11 | 133 (11) | 21 | 112 | 72 | 36% | 3.1 | 176 (3) | 117 (1) | 118 (7) | 133 (11) | - |
| Opponent | Character | 6 | 4 (6) | 4 | 0 | 0 | 0% | 1.7 | 0 (2) | 14 (2) | 0 (2) | 10 (2) | 0 (4) |
| Opponent | Clean-up | 4 | 27 (4) | 0 | 27 | 0 | 50% | 1.0 | - | 56 (2) | 0 (2) | 36 (3) | 0 (1) |
| Opponent | Early | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Fragile | 1 | 0 (1) | 0 | 0 | 100 | 0% | 2.0 | 0 (1) | - | - | 0 (1) | - |
| Opponent | Hammer | 10 | 0 (10) | 0 | 0 | 20 | 40% | 2.0 | 0 (4) | 0 (4) | 0 (2) | 0 (2) | 0 (8) |
| Opponent | Holder | 1 | 92 (1) | 0 | 92 | 0 | 100% | - | - | 92 (1) | - | - | 92 (1) |
| Opponent | Shooter | 1 | 150 (1) | 0 | 150 | 0 | 0% | 1.0 | - | 150 (1) | - | 150 (1) | - |

### Charged fights: csame-bb45c30-p18

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Empire of Man | 2 | 90 | 38 | 0.5 | 2.0 | 77 | 0 | +77 | 0 of 1 | 1 of 1 | +77 | - |
| Mine | Grand Cathay | 1 | 40 | 165 | 5.0 | 1.0 | 33 | 0 | +33 | 0 of 5 | 5 of 5 | - | +33 |
| **Mine** | all armies | 3 | 73 | 81 | 2.0 | 1.2 | 40 | 0 | +40 | 0 of 6 | 6 of 6 | +77 | +33 |
| Opponent | Ogre Kingdoms | 1 | 0 | 104 | 2.0 | 1.0 | 52 | 17 | +35 | 0 of 2 | 1 of 2 | - | +35 |
| Opponent | Vampire Counts | 1 | 0 | 0 | 2.0 | 1.0 | 0 | 0 | +0 | 0 of 2 | 1 of 2 | - | +0 |
| Opponent | Wood Elf Realms | 1 | 0 | 104 | 2.0 | 1.0 | 52 | 0 | +52 | 0 of 2 | 2 of 2 | - | +52 |
| **Opponent** | all armies | 3 | 0 | 69 | 2.0 | 1.0 | 35 | 6 | +29 | 0 of 6 | 4 of 6 | - | +29 |

### Effective charges: csame-bb45c30-p18

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Empire of Man | 1 | 0 | 0 | 0 | 0 | 1 (net +77) | 0 | 0 | 0% (0 of 1) |
| Mine | Grand Cathay | 5 | 0 | 0 | 0 | 0 | 2 (net +52) | 2 (net +0) | 1 | 0% (0 of 4) |
| Opponent | Ogre Kingdoms | 2 | 0 | 0 | 1 (net +104) | 0 | 0 | 0 | 1 | 100% (1 of 1) |
| Opponent | Vampire Counts | 2 | 0 | 0 | 2 (net +0) | 0 | 0 | 0 | 0 | 100% (2 of 2) |
| Opponent | Wood Elf Realms | 2 | 0 | 0 | 0 | 1 (net +104) | 0 | 1 (net +0) | 0 | 0% (0 of 2) |

### Charged fights, damage counted: csame-bb45c30-p18

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 205 | 329 | +0 | 31 | 0 | +31 | +15.3 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 3 | 410 | 61 | +61 | 61 | 0 | +61 | +14.8 |
| Mine | No odds | 1 | 205 | 60 | +60 | 60 | 0 | +60 | +29.3 |
| Mine | All fights | 6 | 308 | 150 | +40 | 51 | 0 | +51 | +16.5 |
| Opponent | Effective (55-75%) | 3 | 347 | 146 | +35 | 49 | 22 | +26 | +7.6 |
| Opponent | 76-89% | 1 | 109 | 104 | +104 | 176 | 0 | +176 | +161.3 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 109 | 104 | +0 | 74 | 0 | +74 | +68.3 |
| Opponent | No odds | 1 | 34 | 189 | -34 | 0 | 34 | -34 | -100.0 |
| Opponent | All fights | 6 | 215 | 139 | +29 | 66 | 17 | +49 | +22.9 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| csame-bb45c30-p18 | move | 11 | 3 (27%) | 2 (18%) | 1 (9%) | 7 (64%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L0934, L1026 |
| Fistful of Laurels | Opponent | L0918 |
| Ring of Jet | Mine | L1026 |
| Twice-Blessed Armour | Mine | L1026 |

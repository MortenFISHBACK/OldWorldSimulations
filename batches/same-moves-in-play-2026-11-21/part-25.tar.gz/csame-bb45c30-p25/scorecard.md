# Doctrine scorecard: csame-bb45c30-p25

### Scorecard: csame-bb45c30-p25

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0102 | 6 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 55 |
| L0102 | 6 | 1 | Opponent | no | 7 | 2 | 1 | 4 | 0 | 0 | 0 | 170 |
| L0118 | 4 | 1 | Mine | no | 1 | - | 0 | 1 | 0 | 0 | 0 | 0 |
| L0118 | 4 | 1 | Opponent | no | 0 | 4 | 2 | 4 | 0 | 0 | 0 | 0 |
| L0135 | 3 | 1 | Mine | no | 2 | - | 0 | 3 | 0 | 0 | 0 | 55 |
| L0135 | 3 | 1 | Opponent | no | 2 | 2 | 2 | 5 | 0 | 0 | 0 | 224 |
| **Average** | | | Mine | 0% | 1.0 | - | 0.0 | 1.7 | 0.0 | 0.0 | 0.0 | 36.7 |
| **Average** | | | Opponent | 0% | 3.0 | 2.7 | 1.7 | 4.3 | 0.0 | 0.0 | 0.0 | 131.3 |

### KPIs: csame-bb45c30-p25

Rules off - Opponent only: NO OLD ONE-MOVE GUESS; both sides: ONE RUN A PLAN.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 3) | 0% (0 of 15) | 0% (0 of 18) |
| Winner chose to follow up after the loser gave ground |  | - | - | - |
| Winner chose to pursue after the loser fell back in good order |  | - | - | - |
| Winner chose to pursue after the loser fled |  | - | 0% (0 of 1); on the table 0% | 0% (0 of 1); on the table 0% |
| Winner chose to follow up or pursue (all three) |  | - | 0% (0 of 1); on the table 0% | 0% (0 of 1); on the table 0% |
| Magic missiles tried each own turn | 50%+ | 29% (26 of 90) | 29% (7 of 24) | 29% (33 of 114) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 32% (26 of 81) | 29% (7 of 24) | 31% (33 of 105) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 67% (2 of 3) | 67% (2 of 3) |
| Points that never fought | lower | 54% (3106 of 5700) | 91% (5359 of 5899) | 73% (8465 of 11599) |
|   infantry points that never fought | lower | 60% (1627 of 2703) | 100% (1219 of 1219) | 73% (2846 of 3922) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 67% (10 of 15) | 72% (18 of 25) | 70% (28 of 40) |
| Bound items with a magic missile used (at least once a game) |  | 100% (3 of 3); 4.3 uses a game | 75% (3 of 4); 1.7 uses a game | 86% (6 of 7); 3.0 uses a game |
| Bound items with another spell used |  | 100% (3 of 3); 1.7 uses a game | 0.0 uses a game | 100% (3 of 3); 0.8 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 100% (3 of 3); 1.0 uses a game | 50% (1 of 2); 0.3 uses a game | 80% (4 of 5); 0.7 uses a game |
|   their share of the points of units over 100 pts | lower | 65% (2669 of 4077) | 71% (3480 of 4883) | 69% (6149 of 8960) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 13.3 (62%) | 3.3 (59%) | 16.7 (62%) |
| MARCHED: its unit marched | 2.3 (11%) | 2.3 (41%) | 4.7 (17%) |
| REAR RANK: in a rear rank | 1.0 (5%) | 0.0 (0%) | 1.0 (4%) |
| OFF THE TABLE: off the table or not arrived | 3.0 (14%) | 0.0 (0%) | 3.0 (11%) |
| STUPIDITY: Stupidity | 1.3 (6%) | 0.0 (0%) | 1.3 (5%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.3 (2%) | 0.0 (0%) | 0.3 (1%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 8.7 | 2.0 | 9.7 | 11.0 | 0.3 |
| not cast | 9.3 | 8.0 | 6.3 | 27.0 | 43.7 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.3 (3%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 4.3 (54%) | 1.0 (16%) | 16.7 (62%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 4.7 (17%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.0 (4%) | 0.0 (0%) |
| OFF THE TABLE: off the table or not arrived | 1.0 (11%) | 1.0 (12%) | 1.0 (16%) | 3.0 (11%) | 3.7 (8%) |
| STUPIDITY: Stupidity | 0.7 (7%) | 0.0 (0%) | 1.3 (21%) | 1.3 (5%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (1%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 7.7 (82%) | 2.7 (33%) | 3.0 (47%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 38.7 (89%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 8.7 a game | 2.7 a game | 5.7 a game |
| stood (cast and not dispelled) | 69% (18 of 26) | 75% (6 of 8) | 71% (24 of 34) |
| the unit moved after it | 67% (12 of 18) | 33% (2 of 6) | 58% (14 of 24) |
| it charged on its next turn | 0% (0 of 18) | 0% (0 of 6) | 0% (0 of 24) |
| the enemy charged it first | 17% (3 of 18) | 0% (0 of 6) | 12% (3 of 24) |
| it fought by the end of its next turn | 0% (0 of 18) | 0% (0 of 6) | 0% (0 of 24) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 18) | 0% (0 of 6) | 0% (0 of 24) |
| none of these (no charge, no fight, no charge escaped) | 83% (15 of 18) | 100% (6 of 6) | 88% (21 of 24) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 57% (17 of 30) | 49% (35 of 71) | 51% (52 of 101) |
|   cavalry | - | 75% (9 of 12) | 75% (9 of 12) |
|   character | - | 82% (9 of 11) | 82% (9 of 11) |
|   chariot | - | 42% (5 of 12) | 42% (5 of 12) |
|   infantry | 57% (17 of 30) | 17% (4 of 24) | 39% (21 of 54) |
|   monster | - | 67% (8 of 12) | 67% (8 of 12) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.0 (46%) | 2.0 (17%) | 4.0 (24%) |
| CHARGED: it charged | 0.0 (0%) | 0.3 (3%) | 0.3 (2%) |
| IN COMBAT: it fought this turn or the last | 0.3 (8%) | 0.0 (0%) | 0.3 (2%) |
| NO TARGET IN RANGE | 0.3 (8%) | 7.3 (61%) | 7.7 (47%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.0 (23%) | 0.3 (3%) | 1.3 (8%) |
| SHELTERED: the target was sheltered | 0.7 (15%) | 1.3 (11%) | 2.0 (12%) |
| OTHER BAR | 0.0 (0%) | 0.7 (6%) | 0.7 (4%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 4.3 | 3.0 | 46% | 6.0 pts | 26 pts |
| character | 3.0 | 2.3 | 44% | 6.5 pts | 20 pts |
| chariot | 1.7 | 0.7 | 80% | 3.1 pts | 5 pts |
| infantry | 7.0 | 2.3 | 76% | 4.2 pts | 29 pts |
| monster | 2.7 | 0.3 | 88% | 1.0 pts | 3 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 0.0 | 2.3 | 1.2 |
| Charges that made contact a game | 0.0 | 1.3 | 0.7 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | - | - | - |
|   per unit a game, units carrying another wizard (or one alone) | - | - | - |
|   per unit a game, the other units (no war machines, no joined characters) | 0.00 declared, 0.00 contact (15 units) | 0.22 declared, 0.12 contact (32 units) | 0.15 declared, 0.09 contact (47 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 67% (2 of 3) | - | - | 67% (2 of 3) |
| Character in a unit | 50% (2 of 4) | 100% (9 of 9) | - | 85% (11 of 13) |
| Character on its own | 100% (1 of 1) | 100% (2 of 2) | 100% (1 of 1) | 100% (4 of 4) |
| Chariot | 100% (2 of 2) | - | - | 100% (2 of 2) |
| Infantry | 80% (4 of 5) | 29% (2 of 7) | - | 50% (6 of 12) |
| Monster | 0% (0 of 1) | 100% (1 of 1) | - | 50% (1 of 2) |
| Monstrous | 100% (2 of 2) | 0% (0 of 2) | - | 50% (2 of 4) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 0% (0 of 1); on the table 0% | 30% (32 of 108) | 63% | 62% (13 of 21) | 100% (5 of 5); 4.2 uses a game | 100% (3 of 3); 1.2 uses a game | 80% (4 of 5); 1.0 uses a game |
| Ogre Kingdoms | 1 | - | - | 86% | 71% (5 of 7) | 100% (1 of 1); 1.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 1 | - | 17% (1 of 6) | 100% | 83% (10 of 12) | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (csame-bb45c30-p25, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 25% (1) | - | 25% (1) |
| ...free all their last turn and able to turn (per game) | 0.33 | 0.00 | 0.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.33 | 0.00 | 0.33 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: csame-bb45c30-p25

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 0.0 | 1.7 |
| Strategy | Charge objectives carried out (made contact) | - | 33% (2 of 6) |
| Strategy | Shoot objectives carried out (shot that target) | 17% (3 of 18) | 27% (6 of 22) |
| Strategy | Hexes on a unit its side charged or shot that turn | 0% (0 of 3) | 67% (2 of 3) |
| Strategy | Joined characters whose unit fought | 40% (6 of 15) | 0% (0 of 7) |
| Strategy | Lone characters that fought | 100% (3 of 3) | 0% (0 of 3) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 1.7 | 4.3 |
| Movement | Points that never moved of their own | 36.7 | 131.3 |
| Movement | Fights charged into per game | 0.0 | 1.3 |
| Movement | Charges with odds: long shots (under 50%) | - | 1 of 3, net -85 |
| Movement | Charges with odds: sweet spot (55-75%) | - | 0 of 3 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | - | 0 of 3 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | - | 2 of 3, net +431 |
| Shooting | Shots by shooting units (incl. breath weapons) | 5.7 | 12.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 65% (11 of 17) | 64% (23 of 36) |
| Shooting | Points destroyed by shooting units | 0.0 | 18.3 |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | 5.3 | 1.0 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 6% (1 of 16) | 0% (0 of 3) |
| Magic | Wounds caused by magic missiles | 17.3 | 4.0 |
| Magic | Points destroyed by magic (all spells) | 188.0 | 21.7 |
| Magic | Augments / hexes / assailments / vortexes cast | 5.7 / 1.0 / 0.0 / 0.0 | 1.7 / 1.0 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 39.7 | 21.7 |
| Combat | Points run down | 0.0 | 0.0 |
| Combat | Net points per charged fight, damage counted | - | +186 |
| Combat | Net per 100 charger points, damage counted | - | +163.4 |
| Combat | First round won (charged fights) | - | 25% |
| Combat | Net points per charged fight | - | +186 |
| Combat | Net points per supported fight / lone fight | - / - | - / +186 |
| Combat | Charged fights on a top-3 enemy unit | - | 3 of 4 |
| Game | Points lost | 347.3 | 264.3 |
| Game | VP from objectives | 646.7 | 776.7 |
| Game | Lone holders (player turns) | 1.0 | 3.0 |

- Mine won / drew / lost: 1 / 1 / 1 of 3 ended games (of 3); mean margin (Mine - Opponent) -229 VP
- The side that went first won 2 of 2 games with a winner
- Points traded per game (both sides' losses): 612
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: csame-bb45c30-p25

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 36.7 |
| ARMY TABLE | 10.0 | +161.7 | 0.0 | 83.3 | 23.3 | -79.2 | 0.0 | 0.0 |
| CAST JOB | - | - | - | - | 2.7 | +22.1 | 429.3 | 0.0 |
| CASTER AWAY FROM SCREEN | 1.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 4.7 | +483.9 | 70.0 | 214.7 | 2.7 | +28.4 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 5.7 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | 0.3 | +5.5 | 0.0 | 0.0 | 0.7 | +16.0 | 0.0 | 20.0 |
| CHAFF PASSED | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| CHARGE LOSSES | 12.3 | -263.7 | 0.0 | 130.0 | 10.7 | -474.2 | 0.0 | 140.0 |
| CHARGE NOW FIRST | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 125.7 | 0.0 |
| CLOSES ON WHAT IT BEATS | 2.3 | +0.0 | 0.0 | 18.3 | 10.7 | +0.0 | 0.0 | 83.3 |
| CONVEYANCE SEARCH | 7.3 | +996.0 | 107.3 | 118.3 | 2.7 | +237.1 | 0.0 | 0.0 |
| COVER ONCE | 2.0 | -50.6 | 0.0 | 129.0 | 4.7 | -167.1 | 0.0 | 0.0 |
| DENIED BY THE FIGHT | - | - | - | - | 0.3 | -63.5 | 107.3 | 0.0 |
| DEPLOY BY FIGURES | 5.0 | +41.5 | 0.0 | 0.0 | 10.0 | -145.9 | 0.0 | 74.7 |
| EVASIVE BY THE ODDS | - | - | - | - | 1.0 | +10.8 | 0.0 | 0.0 |
| EXACT ROUND | - | - | - | - | 1.0 | -1.1 | 36.7 | 0.0 |
| FALL BACK GOOD ORDER | - | - | - | - | 1.7 | +2.8 | 125.7 | 28.3 |
| FALLS SHORT | 4.7 | +128.2 | 0.0 | 107.3 | 19.7 | +159.6 | 0.0 | 0.0 |
| FEATURE BUFFS | 14.0 | +561.8 | 0.0 | 203.3 | 0.3 | +12.8 | 0.0 | 56.7 |
| FIGHT TO THE END | - | - | - | - | 0.3 | +0.6 | 107.3 | 0.0 |
| FIRE IN ORDER | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| FIVE ACTION | 54.0 | +8084.0 | 211.7 | 454.7 | 107.3 | +4358.6 | 1183.3 | 342.3 |
| FLANK NOT WEIGHED | 1.3 | +0.0 | 0.0 | 107.3 | 4.7 | +0.0 | 0.0 | 10.0 |
| FOUR ROUNDS | - | - | - | - | 2.0 | +78.0 | 144.0 | 28.3 |
| FREED FROM HIS FIGHT | 0.7 | +0.0 | 0.0 | 43.3 | - | - | - | - |
| FRIEND SHOOTS FIRST | - | - | - | - | 0.3 | -1.0 | 0.0 | 0.0 |
| GOAL WALK | 4.7 | +622.0 | 0.0 | 0.0 | - | - | - | - |
| GROUND FLIERS | - | - | - | - | 0.3 | +6.1 | 0.0 | 0.0 |
| GUN FIGURES | - | - | - | - | 1.7 | +0.0 | 107.3 | 0.0 |
| HARD STAY DROPPED | 1.7 | +0.0 | 0.0 | 107.3 | 7.3 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 5.0 | +0.0 | 0.0 | 130.0 | 5.3 | +0.0 | 0.0 | 140.0 |
| HIS CHARGE LIST | - | - | - | - | 3.0 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 1.7 | +0.0 | 0.0 | 0.0 | 5.0 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 3.7 | -34.4 | 0.0 | 36.7 | 5.7 | -272.1 | 0.0 | 113.3 |
| HIS MOVE AS HE DECIDES | - | - | - | - | 28.0 | +6.7 | 316.3 | 0.0 |
| HIS MOVE WHY | 14.3 | +0.0 | 0.0 | 101.7 | - | - | - | - |
| HIS ONE MOVE | - | - | - | - | 20.0 | -53.0 | 0.0 | 0.0 |
| HIS ONE QUARTER | 5.0 | +0.0 | 0.0 | 0.0 | 7.0 | +0.0 | 0.0 | 83.3 |
| HIS OWN BEST MOVE | 1.7 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVE | 4.0 | +0.0 | 0.0 | 86.7 | - | - | - | - |
| HIS RANDOM MOVER COMES | 2.0 | +0.0 | 0.0 | 130.0 | - | - | - | - |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 30.0 | +443.2 | 0.0 | 73.3 | 52.3 | +2425.3 | 0.0 | 90.7 |
| HIS SHOTS BY HIS RUN | 33.3 | +360.4 | 0.0 | 240.0 | 43.7 | +981.4 | 0.0 | 291.3 |
| HIS TURN DENIED | - | - | - | - | 0.3 | +14.7 | 107.3 | 0.0 |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 38.3 | +0.0 | 0.0 | 345.0 | 15.0 | +0.0 | 0.0 | 56.7 |
| HOLDER ASSIGNMENT | 16.3 | +1849.7 | 0.0 | 83.3 | 11.0 | +1131.6 | 0.0 | 94.7 |
| HOLDS AMBUSHERS | 1.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | - | - | - | - | 1.0 | -7.2 | 36.7 | 0.0 |
| IDLE COST | 1.7 | -7.9 | 0.0 | 0.0 | 24.7 | -300.4 | 0.0 | 81.3 |
| JOINT CHARGE NOW | - | - | - | - | 0.3 | -4.3 | 0.0 | 0.0 |
| KEPT FROM ITS LAST STOP | 4.0 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | - | - | - | - | 0.3 | +0.6 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 10.7 | +0.0 | 68.0 | 196.7 | - | - | - | - |
| LONE WIZARD KEPT IN | 3.0 | +270.0 | 0.0 | 0.0 | 0.7 | +87.5 | 0.0 | 0.0 |
| LONG SHOT | - | - | - | - | 1.0 | +1.6 | 125.7 | 0.0 |
| LOST AFTER ESCAPE | - | - | - | - | 0.3 | +0.3 | 107.3 | 0.0 |
| MANOEUVRE | 1.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MARCH BY THE SUM | 1.0 | +28.1 | 0.0 | 0.0 | 0.3 | +54.2 | 0.0 | 0.0 |
| MARCH CHECK | 0.3 | +17.4 | 0.0 | 0.0 | - | - | - | - |
| MARCH OF THE TABLE | 0.3 | +2.2 | 0.0 | 0.0 | 0.3 | +0.4 | 0.0 | 0.0 |
| MARCH OVER CASTS | 0.3 | -68.5 | 0.0 | 0.0 | 0.7 | -37.4 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 0.7 | +7.0 | 0.0 | 0.0 | 0.3 | +0.5 | 0.0 | 0.0 |
| MEETS IN TIME | 1.7 | +224.8 | 0.0 | 0.0 | 7.7 | +309.7 | 0.0 | 74.7 |
| MISSILES IN THE MOVE | 8.7 | +577.5 | 0.0 | 107.3 | 5.0 | +74.0 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 8.0 | +418.3 | 0.0 | 107.3 | 6.3 | +56.6 | 0.0 | 0.0 |
| MISSILES ON ONE TARGET | 2.7 | -100.7 | 0.0 | 107.3 | - | - | - | - |
| MOVE ORDER | 1.0 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 11.3 |
| MOVE SPELL OUT OF RANGE | 1.0 | -57.3 | 0.0 | 118.3 | - | - | - | - |
| MOVE SPELL SPOT | 0.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | - | - | - | - | 3.3 | +136.1 | 0.0 | 0.0 |
| MOVES UNITS SPELL | - | - | - | - | 0.3 | +18.4 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 8.0 | +421.9 | 0.0 | 43.3 | 3.7 | +202.0 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | - | - | - | - | 1.3 | +52.3 | 0.0 | 0.0 |
| NEXT OBJECTIVE NEARER | 0.3 | -2.9 | 0.0 | 0.0 | - | - | - | - |
| NO DOUBLE ROUNDS | - | - | - | - | 1.7 | -68.5 | 144.0 | 28.3 |
| NO LATE CUT | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 3.0 | -5.1 | 0.0 | 118.3 | 2.3 | -2.7 | 0.0 | 0.0 |
| OFF BEST | 1.3 | -69.8 | 0.0 | 0.0 | 4.0 | -101.0 | 0.0 | 0.0 |
| ONE CHECK AFTER THE LAST CHANGE | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ONE FIGHT FORMULA | 2.7 | -26.9 | 0.0 | 18.3 | 3.3 | -54.1 | 0.0 | 0.0 |
| ONE JOINT FIGURE | - | - | - | - | 0.7 | +132.4 | 0.0 | 0.0 |
| ONE OBJECTIVE FORMULA | 6.7 | +212.7 | 0.0 | 83.3 | 3.0 | +62.3 | 0.0 | 0.0 |
| ONE ROUTE | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| OPENS A LANE | 0.3 | +0.3 | 41.7 | 0.0 | - | - | - | - |
| OVERRUNS AWAY | - | - | - | - | 0.7 | +22.8 | 36.7 | 0.0 |
| PATHS CROSS | - | - | - | - | 0.3 | +58.0 | 0.0 | 0.0 |
| PLAN RESULT | 23.0 | +181.0 | 28.3 | 356.3 | 46.7 | +440.2 | 447.7 | 316.3 |
| PROMISE BY ITS OWN SUM | - | - | - | - | 3.3 | -17.4 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | - | - | - | - | 0.3 | -1.0 | 0.0 | 0.0 |
| QUARTER ODDS | 13.3 | +2076.7 | 0.0 | 0.0 | 24.0 | +2430.4 | 0.0 | 83.3 |
| RANDOM MOVE BY FIGURES | - | - | - | - | 1.0 | +97.1 | 0.0 | 56.7 |
| REAL GROUND | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | 0.3 | +10.7 | 0.0 | 0.0 | 2.3 | +42.0 | 0.0 | 11.3 |
| REDIRECT FOR A FRIEND IN REACH | 2.7 | +0.0 | 0.0 | 55.0 | 4.0 | +0.0 | 0.0 | 51.0 |
| REFORMS TO MEET IT | - | - | - | - | 0.3 | -25.5 | 0.0 | 0.0 |
| RESERVE FALL BACK | 0.3 | +9.5 | 0.0 | 0.0 | - | - | - | - |
| RESERVE MOVE SPELL | 2.0 | +65.4 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | - | - | - | - | 1.3 | -55.9 | 144.0 | 0.0 |
| RUN DOWN | - | - | - | - | 1.0 | -11.2 | 144.0 | 0.0 |
| SCOUT SPOT | 1.0 | +1.2 | 0.0 | 0.0 | 0.7 | +2.1 | 0.0 | 0.0 |
| SCOUT WAITS | 1.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 0.7 | -0.7 | 0.0 | 20.0 |
| SEARCH SPOT | 0.7 | +71.1 | 0.0 | 0.0 | 0.3 | +1.9 | 0.0 | 0.0 |
| SET-UP ANY TARGET | - | - | - | - | 0.3 | +38.7 | 0.0 | 0.0 |
| SHOOTER COUNTED ONCE | - | - | - | - | 0.7 | -1.3 | 0.0 | 20.0 |
| SHOOTERS IN TWO RANKS | - | - | - | - | 0.3 | +0.3 | 0.0 | 36.7 |
| SHOOTERS ON THE TABLE | 4.7 | +0.0 | 0.0 | 107.3 | 7.0 | +0.0 | 0.0 | 10.0 |
| SHOOTS FROM THE BEST SPOT | 4.3 | +87.5 | 141.7 | 0.0 | 0.7 | +1.0 | 0.0 | 0.0 |
| SHOT OR CHARGE | - | - | - | - | 0.7 | -6.4 | 125.7 | 0.0 |
| SHOT RISK POINTS | 18.0 | -214.3 | 0.0 | 181.7 | 50.7 | +474.9 | 0.0 | 314.0 |
| SHOTS AFTER THE MOVES | 1.3 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 7.3 | +144.4 | 0.0 | 65.0 | 12.7 | +113.6 | 0.0 | 0.0 |
| SPELL SETS UP CHARGE | 1.3 | +741.3 | 0.0 | 0.0 | 0.7 | +138.4 | 0.0 | 0.0 |
| SPELL WORTH | 1.7 | +6.1 | 0.0 | 0.0 | 1.7 | +4.3 | 0.0 | 0.0 |
| SPELLS IN THE FIGHT | - | - | - | - | 0.3 | -3.2 | 0.0 | 0.0 |
| SPOT AS THE GAME MOVES | 5.3 | +0.0 | 0.0 | 55.0 | 4.0 | +0.0 | 0.0 | 0.0 |
| STANDS FOR A REASON | - | - | - | - | 8.7 | +0.0 | 36.7 | 0.0 |
| STANDS STILL | 16.3 | +0.0 | 211.7 | 251.3 | 48.0 | +0.0 | 1039.3 | 94.7 |
| STAY WORTH | 12.0 | +130.3 | 0.0 | 0.0 | 21.0 | +99.4 | 1039.3 | 0.0 |
| STRIKE BY THE ODDS | - | - | - | - | 0.3 | +0.3 | 0.0 | 28.3 |
| SUPPORT ADDS | 3.7 | +198.6 | 0.0 | 0.0 | - | - | - | - |
| SUPPORT WORKED OUT | 3.7 | +198.6 | 0.0 | 0.0 | - | - | - | - |
| SURE REACH TOGETHER | - | - | - | - | 0.3 | +0.6 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 0.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 0.3 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 1.3 | +0.0 | 0.0 | 0.0 | 4.7 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 0.7 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 25.3 | +0.0 | 0.0 | 227.3 | 52.3 | +0.0 | 0.0 | 133.0 |
| TIED UP BY THE SUM | - | - | - | - | 0.3 | +7.8 | 18.3 | 0.0 |
| TIME ON OUR SIDE | 19.0 | +501.5 | 0.0 | 156.7 | 21.7 | +151.7 | 966.0 | 11.3 |
| WAITS AGAIN | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | 3.3 | -133.3 | 0.0 | 130.0 | - | - | - | - |
| WHOLE FIGHT GAIN | - | - | - | - | 0.3 | +4.3 | 0.0 | 0.0 |
| WOUNDS ON THE RANKS | 6.7 | +123.9 | 0.0 | 0.0 | 1.3 | +76.0 | 0.0 | 0.0 |

### Rule changes: csame-bb45c30-p25

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HOLDER ASSIGNMENT | 82 | 82 | 74 | 24.67 | +3675 | +49.7 |
| ARMY TABLE | 100 | 100 | 73 | 24.33 | +537 | +7.4 |
| HIS SHOT LIST | 247 | 246 | 71 | 23.67 | +346 | +4.9 |
| HIS MOVE AS HE DECIDES | 84 | 84 | 64 | 21.33 | +0 | +0.0 |
| HIS SHOTS BY HIS RUN | 231 | 228 | 62 | 20.67 | +649 | +10.5 |
| SHOT RISK POINTS | 206 | 205 | 45 | 15.00 | +598 | +13.3 |
| HIS MOVE WHY | 43 | 43 | 32 | 10.67 | +0 | +0.0 |
| LEGAL CHARGES ONLY | 32 | 32 | 32 | 10.67 | +0 | +0.0 |
| DEPLOY BY FIGURES | 45 | 45 | 30 | 10.00 | +432 | +14.4 |
| HARD STAY DROPPED | 27 | 27 | 27 | 9.00 | +0 | +0.0 |
| THE TABLE AGAIN | 36 | 36 | 21 | 7.00 | +0 | +0.0 |
| CASTING BLOCK | 22 | 22 | 20 | 6.67 | +660 | +33.0 |
| REDIRECT FOR A FRIEND IN REACH | 20 | 20 | 20 | 6.67 | +0 | +0.0 |
| QUARTER ODDS | 112 | 105 | 18 | 6.00 | +2026 | +112.6 |
| TIME ON OUR SIDE | 122 | 111 | 18 | 6.00 | +158 | +8.8 |
| HIS ONE MOVE | 60 | 60 | 17 | 5.67 | +0 | +0.0 |
| OFF BEST | 16 | 16 | 16 | 5.33 | -512 | -32.0 |
| MEETS IN TIME | 28 | 28 | 14 | 4.67 | +257 | +18.3 |
| FIVE ACTION | 484 | 476 | 12 | 4.00 | +928 | +77.3 |
| LONE WIZARD KEPT IN | 11 | 11 | 11 | 3.67 | +1073 | +97.5 |
| MOVE ORDER | 11 | 11 | 11 | 3.67 | +0 | +0.0 |
| STAY WORTH | 99 | 81 | 10 | 3.33 | +68 | +6.8 |
| FEATURE BUFFS | 43 | 43 | 9 | 3.00 | +223 | +24.8 |
| WOUNDS ON THE RANKS | 24 | 24 | 9 | 3.00 | +147 | +16.4 |
| CASTER AWAY FROM SCREEN | 8 | 8 | 8 | 2.67 | +0 | +0.0 |
| FALLS SHORT | 73 | 59 | 7 | 2.33 | +125 | +17.8 |
| IDLE COST | 79 | 64 | 7 | 2.33 | +81 | +11.6 |
| MOVE TO CHARGE COMPUTED | 10 | 10 | 7 | 2.33 | +197 | +28.1 |
| SHOOTS FROM THE BEST SPOT | 15 | 15 | 7 | 2.33 | +139 | +19.8 |
| GOAL WALK | 14 | 14 | 6 | 2.00 | +1220 | +203.2 |
| RESERVE MOVE SPELL | 6 | 6 | 6 | 2.00 | +196 | +32.7 |
| SCOUT WAITS | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| SUPPORT ADDS | 11 | 11 | 6 | 2.00 | +152 | +25.4 |
| SUPPORT WORKED OUT | 11 | 11 | 6 | 2.00 | +152 | +25.4 |
| ADVANCE LANE KEPT | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| HOLDS AMBUSHERS | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| CAST JOB | 8 | 8 | 4 | 1.33 | +35 | +8.7 |
| CHARGE LOSSES | 69 | 69 | 4 | 1.33 | +49 | +12.3 |
| MARCH BY THE SUM | 4 | 4 | 4 | 1.33 | +247 | +61.7 |
| NEXT CHARGE BY LIST | 4 | 4 | 4 | 1.33 | +113 | +28.2 |
| PROMISE BY ITS OWN SUM | 10 | 10 | 3 | 1.00 | -52 | -17.4 |
| SEARCH SPOT | 3 | 3 | 3 | 1.00 | +219 | +73.1 |
| CHAFF IN THE MOVE | 3 | 2 | 2 | 0.67 | +19 | +9.4 |
| CHAFF PASSED | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| COVER ONCE | 20 | 14 | 2 | 0.67 | +3 | +1.7 |
| FOUR ROUNDS | 6 | 6 | 2 | 0.67 | +26 | +12.8 |
| MARCH OF THE TABLE | 2 | 2 | 2 | 0.67 | -8 | -4.0 |
| MAX FOR POSITIONING | 3 | 3 | 2 | 0.67 | +4 | +1.8 |
| MISSILES IN THE MOVE | 41 | 33 | 2 | 0.67 | +61 | +30.5 |
| MISSILES NEXT TURN | 43 | 32 | 2 | 0.67 | +74 | +37.1 |
| NEARER NOT NEEDED | 35 | 30 | 2 | 0.67 | +94 | +47.0 |
| ONE JOINT FIGURE | 2 | 2 | 2 | 0.67 | +61 | +30.6 |
| RANDOM MOVE BY FIGURES | 3 | 3 | 2 | 0.67 | +291 | +145.7 |
| REDIRECT COUNTER | 8 | 5 | 2 | 0.67 | +38 | +19.2 |
| FIRE IN ORDER | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| JOINT CHARGE NOW | 1 | 1 | 1 | 0.33 | -13 | -12.8 |
| LANE BY FIGURES | 1 | 1 | 1 | 0.33 | +2 | +1.7 |
| LONG SHOT | 3 | 3 | 1 | 0.33 | +11 | +10.6 |
| MOVES UNITS SPELL | 1 | 1 | 1 | 0.33 | +55 | +55.1 |
| ONE OBJECTIVE FORMULA | 29 | 17 | 1 | 0.33 | +58 | +57.7 |
| OVERRUNS AWAY | 2 | 2 | 1 | 0.33 | +32 | +32.3 |
| PATHS CROSS | 1 | 1 | 1 | 0.33 | +174 | +174.0 |
| RESERVE FALL BACK | 1 | 1 | 1 | 0.33 | +28 | +28.5 |
| SHOOTERS IN TWO RANKS | 1 | 1 | 1 | 0.33 | +1 | +1.0 |
| SHOTS IN THE MOVE | 60 | 33 | 1 | 0.33 | +8 | +8.4 |
| STRIKE BY THE ODDS | 1 | 1 | 1 | 0.33 | +1 | +0.8 |
| SURE REACH TOGETHER | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CASTS AFTER FRIENDS | 22 | trace | - | - | - | - |
| CHARGE NOW FIRST | 3 | 3 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 39 | 38 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 30 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| EVASIVE BY THE ODDS | 3 | 3 | 0 | 0.00 | - | - |
| EXACT ROUND | 3 | 3 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 5 | 5 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 1 | 1 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 18 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 1 | 1 | 0 | 0.00 | - | - |
| GROUND FLIERS | 1 | not checked | - | - | - | - |
| GUN FIGURES | 5 | not checked | - | - | - | - |
| HIS CHARGE BY HIS RUN | 31 | 31 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 9 | 9 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 20 | 20 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 28 | 28 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 36 | 32 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 12 | 12 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 12 | 12 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 6 | 6 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 1 | 1 | 0 | 0.00 | - | - |
| HIS TURN RUN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 160 | 160 | 0 | 0.00 | - | - |
| HONEST WORTH | 3 | 3 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 22 | 22 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 1 | 1 | 0 | 0.00 | - | - |
| MANOEUVRE | 5 | 5 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH CHECK | 1 | 1 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 3 | 3 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 2 | 2 | 0 | 0.00 | - | - |
| MISSILES ON ONE TARGET | 8 | not checked | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 3 | trace | - | - | - | - |
| MOVE SPELL SPOT | 6 | not checked | - | - | - | - |
| NEXT OBJECTIVE NEARER | 1 | 1 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 5 | 5 | 0 | 0.00 | - | - |
| NO LATE CUT | 2 | 2 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 18 | 18 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 16 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 3 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 18 | 12 | 0 | 0.00 | - | - |
| ONE ROUTE | 2 | 2 | 0 | 0.00 | - | - |
| OPENS A LANE | 1 | 1 | 0 | 0.00 | - | - |
| PLAN RESULT | 209 | trace | - | - | - | - |
| PROMISE READS THE TABLE | 1 | 1 | 0 | 0.00 | - | - |
| REAL GROUND | 2 | 2 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 1 | 1 | 0 | 0.00 | - | - |
| RISK BY ARC | 4 | 4 | 0 | 0.00 | - | - |
| RUN DOWN | 3 | 3 | 0 | 0.00 | - | - |
| SCOUT SPOT | 5 | 5 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 2 | 2 | 0 | 0.00 | - | - |
| SET-UP ANY TARGET | 1 | not checked | - | - | - | - |
| SHOOTER COUNTED ONCE | 2 | 2 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 35 | not checked | - | - | - | - |
| SHOT OR CHARGE | 2 | 2 | 0 | 0.00 | - | - |
| SHOTS AFTER THE MOVES | 14 | 14 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 6 | not checked | - | - | - | - |
| SPELL WORTH | 10 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 28 | 27 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 26 | 26 | 0 | 0.00 | - | - |
| STANDS STILL | 193 | 189 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 5 | not checked | - | - | - | - |
| THE ROW IN ITS ORDER | 10 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 18 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 10 | not checked | - | - | - | - |
| THE TABLE BINDS | 233 | not checked | - | - | - | - |
| TIED UP BY THE SUM | 1 | 1 | 0 | 0.00 | - | - |
| WAITS AGAIN | 2 | 2 | 0 | 0.00 | - | - |
| WHOLE FIGHT DANGER | 10 | 10 | 0 | 0.00 | - | - |
| WHOLE FIGHT GAIN | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: csame-bb45c30-p25

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 1.00 | 3.00 | 30.3 |
| ARMY TABLE | rule | 1.67 | 1.67 | 64.2 |
| HOLDER ASSIGNMENT | rule | 1.00 | 0.67 | 17.5 |
| PROMISE BY ITS OWN SUM | rule | - | 1.00 | 17.4 |
| RULE SWITCHED OFF | gate | - | 1.00 | 48.9 |
| MARCH OF THE TABLE | rule | 0.33 | 0.33 | 4.0 |
| AFTERMATH BAND | gate | 0.33 | - | 1.9 |
| JOINT CHARGE NOW | rule | - | 0.33 | 12.8 |

### Plans: csame-bb45c30-p25

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | move | 17.7 | 96% | 2451 | 0 | 0% |
| Mine | shoot | 5.3 | 38% | 685 | 181 | 26% |
| Opponent | charge | 1.3 | 75% | 88 | 147 | 167% |
| Opponent | move | 39.0 | 97% | 1171 | 0 | 0% |
| Opponent | shoot | 6.0 | 61% | 224 | 294 | 131% |
| Opponent | support | 0.3 | 0% | 3 | 0 | 0% |

### Battle groups: csame-bb45c30-p25

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 0.3 | 0% | - | - | - | - | - | - | - | - |
| Opponent | REDIRECT COUNTER | 2.3 | 0% | - | - | - | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: csame-bb45c30-p25

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 3 | 0 (3) | 0 | 0 | 67 | 67% | 2.0 | 0 (1) | 0 (1) | 0 (1) | 0 (2) | 0 (1) |
| Mine | Character | 18 | 22 (18) | 22 | 0 | 19 | 6% | 2.2 | 76 (3) | 19 (9) | 0 (3) | 36 (9) | 11 (6) |
| Mine | Hammer | 6 | 41 (6) | 2 | 39 | 17 | 50% | 4.0 | 112 (1) | 31 (4) | 11 (1) | 45 (4) | 33 (2) |
| Mine | Holder | 3 | 91 (3) | 0 | 91 | 0 | 100% | - | 0 (1) | 136 (2) | - | 273 (1) | 0 (2) |
| Mine | Shooter | 6 | 46 (6) | 0 | 46 | 33 | 0% | 1.7 | - | 55 (5) | 0 (1) | 58 (4) | 23 (2) |
| Opponent | Chaff | 6 | 118 (6) | 0 | 118 | 25 | 83% | 2.0 | 0 (3) | 429 (2) | 0 (1) | 118 (6) | - |
| Opponent | Character | 8 | 0 (8) | 0 | 0 | 0 | 25% | 1.3 | 0 (4) | 0 (4) | - | 0 (4) | 0 (4) |
| Opponent | Early | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Fast Hammer | 7 | 38 (7) | 18 | 20 | 14 | 57% | 2.0 | 111 (1) | 0 (3) | 25 (3) | 29 (3) | 42 (4) |
| Opponent | Hammer | 13 | 54 (13) | 43 | 11 | 19 | 54% | 2.2 | - | 77 (8) | 0 (5) | 11 (3) | 69 (10) |
| Opponent | Holder | 1 | 250 (1) | 0 | 250 | 0 | 100% | - | - | 250 (1) | - | - | 250 (1) |
| Opponent | Shooter | 3 | 99 (3) | 0 | 99 | 62 | 67% | 1.0 | 257 (1) | 0 (2) | - | 257 (1) | 0 (2) |
| Opponent | Wizard | 2 | 31 (2) | 31 | 0 | 0 | 50% | 3.0 | - | 31 (2) | - | 31 (2) | - |

### Charged fights: csame-bb45c30-p25

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 3 | 188 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Beastmen Brayherds | 1 | 65 | 55 | 2.0 | 1.0 | 28 | 42 | -15 | 1 of 2 | 0 of 2 | - | -15 |
| Opponent | Ogre Kingdoms | 1 | 0 | 807 | 2.0 | 1.0 | 404 | 17 | +386 | 2 of 2 | 1 of 2 | - | +386 |
| Opponent | Wood Elf Realms | 1 | 55 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| **Opponent** | all armies | 3 | 40 | 287 | 1.3 | 1.0 | 216 | 30 | +186 | 3 of 4 | 1 of 4 | - | +186 |

### Effective charges: csame-bb45c30-p25

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | Beastmen Brayherds | 2 | 1 (net -85) | 0 | 0 | 0 | 0 | 1 (net +55) | 0 | 0% (0 of 2) |
| Opponent | Ogre Kingdoms | 2 | 0 | 0 | 0 | 0 | 0 | 1 (net +807) | 1 | 0% (0 of 1) |

### Charged fights, damage counted: csame-bb45c30-p25

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | Long shot (under 50%) | 1 | 85 | 836 | -85 | 32 | 85 | -53 | -62.7 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 168 | 188 | +431 | 447 | 31 | +415 | +247.3 |
| Opponent | No odds | 1 | 34 | 836 | -34 | 0 | 34 | -34 | -100.0 |
| Opponent | All fights | 4 | 114 | 512 | +186 | 231 | 45 | +186 | +163.4 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| csame-bb45c30-p25 | move | 10 | 1 (10%) | 1 (10%) | 1 (10%) | 8 (80%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0102, L0118, L0135 |
| Fistful of Laurels | Opponent | L0118 |
| Ring of Doom | Opponent | L0102 |

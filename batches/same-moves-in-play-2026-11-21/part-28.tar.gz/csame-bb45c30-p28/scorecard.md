# Doctrine scorecard: csame-bb45c30-p28

### Scorecard: csame-bb45c30-p28

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0524 | 2 | 1 | Mine | - | - | 5 | 1 | 1 | 0 | 0 | 0 | 380 |
| L0524 | 2 | 1 | Opponent | - | - | - | 1 | 4 | 0 | 0 | 0 | 0 |
| L0612 | 6 | 1 | Mine | no | 0 | - | 0 | 4 | 1 | 0 | 0 | 500 |
| L0612 | 6 | 1 | Opponent | no | 10 | 4 | 1 | 0 | 0 | 0 | 0 | 330 |
| L0628 | 4 | 1 | Mine | no | 0 | - | 0 | 3 | 0 | 0 | 0 | 361 |
| L0628 | 4 | 1 | Opponent | no | 10 | - | 0 | 1 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 0% | 0.0 | 5.0 | 0.3 | 2.7 | 0.3 | 0.0 | 0.0 | 413.7 |
| **Average** | | | Opponent | 0% | 10.0 | 4.0 | 0.7 | 1.7 | 0.0 | 0.0 | 0.0 | 110.0 |

### KPIs: csame-bb45c30-p28

Rules off - Opponent only: NO OLD ONE-MOVE GUESS; both sides: ONE RUN A PLAN.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 100% (15 of 15) | 0% (0 of 16) | 48% (15 of 31) |
| Winner chose to follow up after the loser gave ground |  | 67% (2 of 3); on the table 67% | - | 67% (2 of 3); on the table 67% |
| Winner chose to pursue after the loser fell back in good order |  | 0% (0 of 1); on the table 0% | 100% (1 of 1); on the table 100% | 50% (1 of 2); on the table 50% |
| Winner chose to pursue after the loser fled |  | 100% (1 of 1); on the table 100% | - | 100% (1 of 1); on the table 100% |
| Winner chose to follow up or pursue (all three) |  | 60% (3 of 5); on the table 60% | 100% (1 of 1); on the table 100% | 67% (4 of 6); on the table 67% |
| Magic missiles tried each own turn | 50%+ | - | 43% (13 of 30) | 43% (13 of 30) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | - | 48% (13 of 27) | 48% (13 of 27) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | - | - |
| Points that never fought | lower | 87% (5229 of 6000) | 78% (4695 of 5998) | 83% (9924 of 11998) |
|   infantry points that never fought | lower | 81% (1816 of 2232) | 100% (694 of 694) | 86% (2510 of 2926) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 63% (17 of 27) | 52% (12 of 23) | 58% (29 of 50) |
| Bound items with a magic missile used (at least once a game) |  | 0.0 uses a game | 100% (3 of 3); 3.3 uses a game | 100% (3 of 3); 1.7 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0.0 uses a game | 100% (1 of 1); 0.3 uses a game | 100% (1 of 1); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 57% (2431 of 4232) | 57% (3305 of 5787) | 57% (5736 of 10019) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | - | 1.3 (24%) | 1.3 (24%) |
| MARCHED: its unit marched | - | 3.3 (59%) | 3.3 (59%) |
| IN COMBAT: engaged in combat | - | 1.0 (18%) | 1.0 (18%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 6.0 | 1.3 | 4.3 | 1.3 | 1.0 |
| not cast | 2.0 | 2.7 | 5.7 | 2.7 | 23.0 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (1%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 2.7 (100%) | 1.3 (24%) | 0.0 (0%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 3.3 (59%) | 1.3 (50%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.0 (0%) | 1.0 (18%) | 0.3 (12%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.0 (38%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.0 (100%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 22.7 (99%) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 66% (139 of 211) | 67% (10 of 15) | 66% (149 of 226) |
|   cavalry | 45% (10 of 22) | 17% (1 of 6) | 39% (11 of 28) |
|   character | 84% (26 of 31) | - | 84% (26 of 31) |
|   infantry | 49% (27 of 55) | - | 49% (27 of 55) |
|   monster | 67% (8 of 12) | - | 67% (8 of 12) |
|   war machine | 75% (68 of 91) | 100% (9 of 9) | 77% (77 of 100) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 4.3 (18%) | 0.3 (20%) | 4.7 (18%) |
| CHARGED: it charged | 1.0 (4%) | 0.0 (0%) | 1.0 (4%) |
| IN COMBAT: it fought this turn or the last | 0.7 (3%) | 0.0 (0%) | 0.7 (3%) |
| NO TARGET IN RANGE | 10.7 (44%) | 0.7 (40%) | 11.3 (44%) |
| ONLY IN COMBAT: the only targets were in combat | 1.0 (4%) | 0.0 (0%) | 1.0 (4%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 5.7 (24%) | 0.7 (40%) | 6.3 (25%) |
| SHELTERED: the target was sheltered | 0.7 (3%) | 0.0 (0%) | 0.7 (3%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 4.0 | 1.0 | 83% | 6.4 pts | 26 pts |
| character | 9.7 | 3.7 | 83% | 4.7 pts | 45 pts |
| infantry | 18.3 | 5.0 | 75% | 6.7 pts | 123 pts |
| monster | 2.7 | 1.3 | 75% | 15.1 pts | 40 pts |
| war machine | 25.7 | 13.0 | 75% | 16.2 pts | 416 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 1.3 | 2.3 | 1.8 |
| Charges that made contact a game | 1.0 | 1.3 | 1.2 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | - | 0.67 declared, 0.67 contact (3 units) | 0.67 declared, 0.67 contact (3 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 0.00 declared, 0.00 contact (1 units) | 0.00 declared, 0.00 contact (1 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.19 declared, 0.14 contact (21 units) | 0.38 declared, 0.15 contact (13 units) | 0.26 declared, 0.15 contact (34 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 0% (0 of 4) | 100% (1 of 1) | 50% (1 of 2) | 29% (2 of 7) |
| Character in a unit | 88% (7 of 8) | 100% (4 of 4) | 100% (1 of 1) | 92% (12 of 13) |
| Character on its own | - | 67% (2 of 3) | 50% (1 of 2) | 60% (3 of 5) |
| Infantry | 29% (2 of 7) | 17% (1 of 6) | - | 23% (3 of 13) |
| Monster | 50% (1 of 2) | - | - | 50% (1 of 2) |
| War Machines | 80% (8 of 10) | - | - | 80% (8 of 10) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Dwarfen Mountain Holds | 3 | 60% (3 of 5); on the table 60% | - | 87% | 63% (17 of 27) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Grand Cathay | 1 | - | 44% (8 of 18) | 54% | 33% (3 of 9) | 100% (3 of 3); 10.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Vampire Counts | 1 | 100% (1 of 1); on the table 100% | 33% (2 of 6) | 89% | 57% (4 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 1 | - | 50% (3 of 6) | 92% | 71% (5 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (csame-bb45c30-p28, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 33% (1) | - | 33% (1) |
| ...free all their last turn and able to turn (per game) | 0.33 | 0.00 | 0.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.00 | 0.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.33 | 0.00 | 0.33 |

### Quality by phase: csame-bb45c30-p28

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.3 | 3.0 |
| Strategy | Charge objectives carried out (made contact) | 75% (3 of 4) | 57% (4 of 7) |
| Strategy | Shoot objectives carried out (shot that target) | 59% (44 of 75) | 29% (6 of 21) |
| Strategy | Support requests answered (helper made contact too) | - | 100% (1 of 1) |
| Strategy | Joined characters whose unit fought | 8% (1 of 12) | 0% (0 of 6) |
| Strategy | Lone characters that fought | 0% (0 of 1) | 50% (3 of 6) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 2.7 | 1.7 |
| Movement | Points that never moved of their own | 413.7 | 110.0 |
| Movement | Fights charged into per game | 1.0 | 1.0 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 3 | 0 of 3 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 3 | 0 of 3 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 3 | 1 of 3, net -434 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 of 3, net +14 | 1 of 3, net +95 |
| Shooting | Shots by shooting units (incl. breath weapons) | 25.3 | 0.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 50% (38 of 76) | 0% (0 of 2) |
| Shooting | Points destroyed by shooting units | 94.3 | 0.0 |
| Shooting | War machine shots | 22.7 | 3.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 59% (40 of 68) | 11% (1 of 9) |
| Shooting | Points destroyed by war machines | 0.0 | 60.0 |
| Magic | Magic missiles cast | - | 3.0 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | - | 56% (5 of 9) |
| Magic | Wounds caused by magic missiles | - | 5.0 |
| Magic | Wounds caused by other spells | - | 3.0 |
| Magic | Points destroyed by magic (all spells) | 0.0 | 55.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.0 / 0.0 / 0.0 / 0.0 | 4.3 / 0.0 / 0.7 / 0.7 |
| Combat | Points destroyed in combat | 144.7 | 109.3 |
| Combat | Points run down | 13.7 | 0.0 |
| Combat | Net points per charged fight, damage counted | +27 | +25 |
| Combat | Net per 100 charger points, damage counted | +38.0 | +7.0 |
| Combat | First round won (charged fights) | 100% | 33% |
| Combat | Net points per charged fight | +14 | -35 |
| Combat | Net points per supported fight / lone fight | - / +14 | -434 / +164 |
| Combat | Charged fights on a top-3 enemy unit | 0 of 3 | 2 of 3 |
| Game | Points lost | 241.0 | 274.3 |
| Game | VP from objectives | 636.7 | 683.3 |
| Game | Lone holders (player turns) | 0.0 | 10.0 |

- Mine won / drew / lost: 0 / 3 / 0 of 3 ended games (of 3); mean margin (Mine - Opponent) -28 VP
- Points traded per game (both sides' losses): 515
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: csame-bb45c30-p28

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.7 | +18.8 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | 12.7 | +37.9 | 0.0 | 145.0 | 9.0 | +223.9 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| CANNON PLAN MISSED | 1.3 | +0.0 | 155.3 | 0.0 | - | - | - | - |
| CANNON PLANNED TARGET | 18.0 | +195.7 | 226.7 | 106.7 | 3.0 | +135.7 | 80.0 | 110.0 |
| CANNON SIGHT KEPT | 2.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT SET-UP | - | - | - | - | 0.3 | -7.5 | 77.7 | 0.0 |
| CAST JOB | - | - | - | - | 6.0 | +56.9 | 160.0 | 202.3 |
| CASTS FROM BEHIND | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | - | - | - | - | 0.7 | +20.8 | 0.0 | 0.0 |
| CHALLENGE BY POINTS | 0.3 | +2.3 | 0.0 | 0.0 | - | - | - | - |
| CHARACTER GUNS | 7.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHARGE LOSSES | 17.0 | -456.9 | 0.0 | 457.0 | 19.3 | -918.7 | 0.0 | 202.3 |
| CHARGE NOW FIRST | 0.7 | +0.0 | 13.7 | 0.0 | 1.3 | +0.0 | 109.3 | 0.0 |
| CLOSES ON WHAT IT BEATS | 8.0 | +0.0 | 0.0 | 155.3 | 8.3 | +0.0 | 0.0 | 33.3 |
| COVER ONCE | 10.7 | -736.1 | 0.0 | 109.3 | 5.7 | -213.8 | 0.0 | 202.3 |
| DEFENSIVE ARMY | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| DENIED BY THE FIGHT | - | - | - | - | 0.7 | -7.8 | 77.7 | 0.0 |
| DEPLOY BY FIGURES | 13.3 | -169.6 | 0.0 | 0.0 | 4.3 | +35.7 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | - | - | - | - | 0.7 | -25.3 | 77.7 | 0.0 |
| EXACT ROUND | 1.0 | +2.5 | 33.7 | 0.0 | 1.3 | +20.3 | 31.7 | 144.7 |
| FALL BACK GOOD ORDER | 0.7 | +0.0 | 20.0 | 0.0 | 2.0 | +2.5 | 109.3 | 161.3 |
| FALLS SHORT | - | - | - | - | 23.0 | +344.8 | 0.0 | 202.3 |
| FEATURE BUFFS | - | - | - | - | 0.7 | +1.3 | 0.0 | 0.0 |
| FIGHT TO THE END | 1.0 | +0.7 | 13.7 | 0.0 | 0.3 | +1.6 | 77.7 | 0.0 |
| FIRE IN ORDER | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FIVE ACTION | 136.7 | +3962.8 | 1050.3 | 812.0 | 67.7 | +2620.9 | 429.3 | 846.7 |
| FLANK NOT WEIGHED | 4.7 | +0.0 | 0.0 | 77.7 | 5.7 | +0.0 | 0.0 | 57.7 |
| FOLLOW UP WEIGHED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FOUR ROUNDS | 1.3 | +25.3 | 33.7 | 0.0 | 2.3 | +108.4 | 109.3 | 161.3 |
| FREED FROM HIS FIGHT | 3.3 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 1.3 | -0.7 | 0.0 | 0.0 | 0.3 | -0.3 | 0.0 | 0.0 |
| GIVES UP | 0.3 | -1.5 | 0.0 | 0.0 | - | - | - | - |
| GOAL WALK | 3.0 | +250.4 | 0.0 | 0.0 | 1.7 | +91.3 | 0.0 | 0.0 |
| GUN FIGURES | 1.7 | +18.1 | 144.7 | 0.0 | - | - | - | - |
| GUN MASK | 2.3 | +32.5 | 0.0 | 0.0 | 0.7 | +44.5 | 0.0 | 0.0 |
| HARD STAY DROPPED | 6.7 | +0.0 | 0.0 | 35.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 2.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS CHARGE BY HIS RUN | 11.7 | +0.0 | 0.0 | 387.0 | 11.0 | +0.0 | 0.0 | 202.3 |
| HIS CHARGE LIST | 16.0 | +0.0 | 0.0 | 103.3 | 10.3 | +0.0 | 0.0 | 202.3 |
| HIS LEGAL MOVES | 2.0 | +0.0 | 0.0 | 0.0 | 5.7 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 3.3 | -17.4 | 0.0 | 0.0 | 4.3 | -38.3 | 0.0 | 57.7 |
| HIS MOVE AS HE DECIDES | - | - | - | - | 38.0 | +14.7 | 187.7 | 0.0 |
| HIS MOVE WHY | 41.3 | +0.0 | 0.0 | 110.0 | - | - | - | - |
| HIS ONE MOVE | - | - | - | - | 16.7 | +12.0 | 0.0 | 57.7 |
| HIS OWN BEST MOVE | 3.0 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 48.0 | +1381.1 | 0.0 | 265.0 | 40.7 | +3928.8 | 0.0 | 229.7 |
| HIS SHOTS BY HIS RUN | 25.0 | +350.3 | 0.0 | 420.3 | 37.3 | +1054.7 | 0.0 | 229.7 |
| HIS TURN DENIED | - | - | - | - | 0.7 | +51.2 | 77.7 | 0.0 |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 13.0 | +0.0 | 0.0 | 155.3 | 13.3 | +0.0 | 0.0 | 0.0 |
| HOLDER ASSIGNMENT | 9.7 | +915.6 | 0.0 | 77.7 | 9.3 | +1119.5 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 1.0 | -5.8 | 33.7 | 0.0 | 1.7 | -46.0 | 109.3 | 0.0 |
| HUNT IN PAIRS | - | - | - | - | 2.0 | +157.2 | 0.0 | 144.7 |
| IDLE COST | - | - | - | - | 15.3 | -368.0 | 0.0 | 30.3 |
| JOINT CHARGE NOW | 0.3 | -5.6 | 0.0 | 0.0 | 1.0 | +5.5 | 77.7 | 144.7 |
| KEEP FALLS | - | - | - | - | 0.3 | +0.9 | 0.0 | 0.0 |
| KEEPS SCOUTS OR AMBUSH | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 1.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | - | - | - | - | 0.7 | +42.7 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 0.7 | +0.0 | 0.0 | 77.7 | 0.7 | +0.0 | 0.0 | 40.0 |
| LOST AFTER ESCAPE | 1.0 | +4.8 | 13.7 | 0.0 | 1.0 | -16.9 | 77.7 | 144.7 |
| MAKE SURE TOGETHER | 0.3 | +0.2 | 0.0 | 0.0 | 0.7 | +10.3 | 0.0 | 0.0 |
| MANOEUVRE | 1.7 | -16.6 | 0.0 | 0.0 | 1.7 | -23.0 | 0.0 | 0.0 |
| MARCH AT ESCAPER | - | - | - | - | 0.3 | +4.4 | 0.0 | 57.7 |
| MARCH BY THE SUM | - | - | - | - | 0.3 | +5.0 | 0.0 | 0.0 |
| MARCH CHECK | - | - | - | - | 1.3 | +79.5 | 0.0 | 0.0 |
| MARCH OF THE TABLE | - | - | - | - | 1.3 | +50.3 | 0.0 | 57.7 |
| MARCH OVER CASTS | - | - | - | - | 2.0 | +165.5 | 0.0 | 57.7 |
| MARCH WHEELS ONLY | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MAX FOR POSITIONING | 0.3 | +1.2 | 0.0 | 0.0 | 3.3 | +51.5 | 0.0 | 144.7 |
| MEETS IN TIME | 9.3 | +185.0 | 0.0 | 0.0 | 2.3 | +331.4 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | - | - | - | - | 6.7 | +49.6 | 0.0 | 144.7 |
| MISSILES NEXT TURN | - | - | - | - | 9.3 | +56.9 | 0.0 | 202.3 |
| MODEL FACING | 2.7 | +653.1 | 0.0 | 0.0 | - | - | - | - |
| MOVE ORDER | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 1.7 | +38.4 | 0.0 | 0.0 | 3.0 | +198.3 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 5.3 | +244.2 | 0.0 | 77.7 | 4.3 | +192.7 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | - | - | - | - | 2.0 | +111.3 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 1.3 | -11.6 | 33.7 | 0.0 | 1.7 | -38.3 | 109.3 | 144.7 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 7.0 | -162.4 | 0.0 | 0.0 | 4.3 | -112.7 | 0.0 | 110.0 |
| OGRE LOADER SECOND SHOT | - | - | - | - | 1.7 | +10.3 | 0.0 | 0.0 |
| ONE CHALLENGE TEST | - | - | - | - | 0.3 | +38.0 | 0.0 | 144.7 |
| ONE CHECK AFTER THE LAST CHANGE | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 3.0 | -17.6 | 0.0 | 0.0 | 2.7 | -58.5 | 0.0 | 0.0 |
| ONE JOINT FIGURE | - | - | - | - | 1.0 | +64.9 | 77.7 | 144.7 |
| ONE OBJECTIVE FORMULA | 5.7 | -65.3 | 0.0 | 77.7 | 3.7 | -51.0 | 0.0 | 0.0 |
| ONE ROUTE | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| OVERRUNS AWAY | 0.3 | +1.7 | 20.0 | 0.0 | - | - | - | - |
| PIVOT GUARDS FLANK | - | - | - | - | 0.3 | -7.0 | 0.0 | 144.7 |
| PLAN RESULT | 60.3 | +768.5 | 212.0 | 482.0 | 31.3 | +236.1 | 262.0 | 595.3 |
| PROMISE BELOW ZERO | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| PROMISE BY ITS OWN SUM | 5.3 | -75.4 | 0.0 | 0.0 | 3.7 | -45.5 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | 0.7 | -0.1 | 0.0 | 0.0 | 0.3 | -0.3 | 0.0 | 0.0 |
| QUARTER ODDS | 18.0 | +1087.9 | 0.0 | 0.0 | 3.3 | +799.1 | 0.0 | 0.0 |
| REAL GROUND | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| REDIRECT BY WHAT IT STOPS | - | - | - | - | 0.7 | +10.6 | 0.0 | 0.0 |
| REDIRECT COUNTER | 1.0 | +50.2 | 0.0 | 0.0 | 1.0 | +39.2 | 0.0 | 13.7 |
| REDIRECT FOR A FRIEND IN REACH | 0.3 | +0.0 | 0.0 | 0.0 | 1.3 | +9.2 | 0.0 | 13.7 |
| REDIRECT WEIGHED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| REFORMS TO MEET IT | 0.3 | -1.3 | 0.0 | 0.0 | 0.7 | -2.6 | 0.0 | 0.0 |
| REFUSING RETIRES | - | - | - | - | 0.3 | +0.0 | 0.0 | 144.7 |
| RISK BY ARC | 1.3 | +56.4 | 33.7 | 0.0 | 1.3 | +76.4 | 77.7 | 16.7 |
| ROUNDS AFTER TERROR | - | - | - | - | 1.3 | -9.4 | 31.7 | 16.7 |
| RUN DOWN | 1.0 | -15.4 | 13.7 | 0.0 | 1.3 | -2.3 | 77.7 | 144.7 |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 0.7 | -99.9 | 0.0 | 0.0 |
| SEARCH SPOT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SET CREDITED ONCE | 0.7 | -6.5 | 0.0 | 0.0 | 1.7 | -19.6 | 0.0 | 144.7 |
| SET UP BY THE SET | 1.3 | +7.3 | 0.0 | 0.0 | 2.3 | -16.1 | 0.0 | 144.7 |
| SET UP TOGETHER | 0.3 | +0.2 | 0.0 | 0.0 | 0.7 | +10.3 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 2.0 | +4.0 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS ON THE TABLE | 25.3 | +0.0 | 0.0 | 141.7 | 5.3 | +0.0 | 0.0 | 110.0 |
| SHOOTS FROM THE BEST SPOT | 2.7 | +129.8 | 0.0 | 0.0 | 0.7 | +2.3 | 0.0 | 0.0 |
| SHORT GUN FORWARD | 2.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SHOT OR CHARGE | 0.7 | -7.6 | 13.7 | 0.0 | 0.3 | -0.4 | 0.0 | 144.7 |
| SHOT RISK POINTS | 26.3 | +587.0 | 0.0 | 345.0 | 22.7 | -685.5 | 0.0 | 172.0 |
| SHOTS AFTER THE MOVES | 6.0 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 33.0 | +939.3 | 0.0 | 176.7 | 4.0 | +241.4 | 0.0 | 110.0 |
| SPELL WORTH | - | - | - | - | 6.0 | +132.5 | 289.3 | 289.3 |
| SPELLS IN THE FIGHT | - | - | - | - | 0.3 | +12.3 | 0.0 | 144.7 |
| SPOT AS THE GAME MOVES | 3.7 | +0.0 | 0.0 | 0.0 | 5.7 | +0.0 | 0.0 | 164.7 |
| STANDS FOR A REASON | - | - | - | - | 4.0 | +0.0 | 0.0 | 144.7 |
| STANDS STILL | 101.3 | +0.0 | 1016.7 | 576.7 | 20.3 | +0.0 | 320.0 | 422.3 |
| STAY WORTH | 57.3 | +64.8 | 68.3 | 340.0 | 11.3 | +175.2 | 230.0 | 330.0 |
| SUPPORT ADDS | 5.0 | +312.9 | 0.0 | 60.0 | 0.3 | +0.8 | 0.0 | 0.0 |
| SUPPORT NARROWED | - | - | - | - | 0.3 | +0.0 | 0.0 | 16.7 |
| SUPPORT WORKED OUT | 5.0 | +312.9 | 0.0 | 60.0 | 0.3 | +0.8 | 0.0 | 0.0 |
| SURE REACH TOGETHER | 0.3 | +0.2 | 0.0 | 0.0 | 0.3 | +9.6 | 0.0 | 0.0 |
| SWIFTSTRIDE BY POINTS | - | - | - | - | 0.3 | +2.5 | 0.0 | 13.7 |
| THE DEARER SUM KEEPS ITS PLAN | 1.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 2.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 1.0 | +0.0 | 0.0 | 77.7 | 3.7 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 0.7 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 57.7 | +0.0 | 0.0 | 294.3 | 33.7 | +0.0 | 0.0 | 342.7 |
| TIED UP BY THE SUM | 0.7 | +19.0 | 13.7 | 0.0 | 0.7 | +44.0 | 31.7 | 0.0 |
| TIME ON OUR SIDE | 59.7 | +619.8 | 40.0 | 187.7 | - | - | - | - |
| WAITS AGAIN | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WHO FIGHTS | - | - | - | - | 1.3 | +36.4 | 31.7 | 144.7 |
| WHO HITS BACK | - | - | - | - | 0.3 | +4.8 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | 3.7 | -210.6 | 0.0 | 267.0 | 1.0 | -75.7 | 0.0 | 57.7 |
| WHOLE FIGHT GAIN | 0.3 | +1.0 | 0.0 | 0.0 | 1.0 | +159.4 | 77.7 | 144.7 |
| WOUNDS ON THE RANKS | 2.3 | +16.7 | 0.0 | 0.0 | 3.7 | +373.3 | 0.0 | 0.0 |

### Rule changes: csame-bb45c30-p28

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS SHOT LIST | 266 | 265 | 95 | 31.67 | +2920 | +30.7 |
| HIS MOVE AS HE DECIDES | 114 | 114 | 70 | 23.33 | +0 | +0.0 |
| HIS MOVE WHY | 124 | 124 | 64 | 21.33 | +0 | +0.0 |
| HOLDER ASSIGNMENT | 57 | 57 | 53 | 17.67 | +3059 | +57.7 |
| ARMY TABLE | 65 | 65 | 50 | 16.67 | +1067 | +21.3 |
| HIS SHOTS BY HIS RUN | 187 | 181 | 43 | 14.33 | +846 | +19.7 |
| SHOT RISK POINTS | 147 | 146 | 43 | 14.33 | +1650 | +38.4 |
| OFF BEST | 34 | 34 | 34 | 11.33 | -825 | -24.3 |
| DEPLOY BY FIGURES | 53 | 53 | 32 | 10.67 | +329 | +10.3 |
| TIME ON OUR SIDE | 179 | 161 | 28 | 9.33 | +88 | +3.1 |
| THE TABLE AGAIN | 36 | 36 | 25 | 8.33 | +0 | +0.0 |
| HARD STAY DROPPED | 21 | 21 | 21 | 7.00 | +0 | +0.0 |
| HIS ONE MOVE | 50 | 50 | 20 | 6.67 | +0 | +0.0 |
| CHARGE LOSSES | 109 | 108 | 19 | 6.33 | +762 | +40.1 |
| COVER ONCE | 49 | 44 | 16 | 5.33 | +145 | +9.1 |
| MEETS IN TIME | 35 | 35 | 14 | 4.67 | +462 | +33.0 |
| FIVE ACTION | 613 | 606 | 13 | 4.33 | +456 | +35.1 |
| CAST JOB | 18 | 18 | 11 | 3.67 | +15 | +1.4 |
| IDLE COST | 46 | 41 | 11 | 3.67 | +346 | +31.5 |
| PROMISE BY ITS OWN SUM | 27 | 27 | 11 | 3.67 | -363 | -33.0 |
| CANNON SIGHT KEPT | 10 | 10 | 10 | 3.33 | +0 | +0.0 |
| MODEL FACING | 8 | 8 | 8 | 2.67 | +1959 | +244.9 |
| SUPPORT ADDS | 16 | 16 | 8 | 2.67 | +216 | +27.0 |
| SUPPORT WORKED OUT | 16 | 16 | 8 | 2.67 | +216 | +27.0 |
| ARTILLERY RE-ROLL WEIGHED | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| SHOOTS FROM THE BEST SPOT | 10 | 10 | 7 | 2.33 | +204 | +29.1 |
| SHOTS IN THE MOVE | 111 | 92 | 7 | 2.33 | +271 | +38.7 |
| MOVE TO CHARGE COMPUTED | 14 | 12 | 6 | 2.00 | +68 | +11.4 |
| QUARTER ODDS | 64 | 64 | 6 | 2.00 | +948 | +158.0 |
| SET UP BY THE SET | 11 | 11 | 6 | 2.00 | +87 | +14.4 |
| SHOOTERS IN TWO RANKS | 6 | 6 | 6 | 2.00 | +12 | +2.0 |
| SHORT GUN FORWARD | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| SHOTS AFTER THE MOVES | 24 | 24 | 6 | 2.00 | +0 | +0.0 |
| CANNON PLANNED TARGET | 63 | 63 | 5 | 1.67 | +0 | +0.0 |
| GOAL WALK | 14 | 14 | 5 | 1.67 | +460 | +91.9 |
| OGRE LOADER SECOND SHOT | 5 | 5 | 5 | 1.67 | +31 | +6.2 |
| REDIRECT FOR A FRIEND IN REACH | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| RISK BY ARC | 8 | 7 | 5 | 1.67 | +78 | +15.7 |
| STAY WORTH | 206 | 195 | 5 | 1.67 | +48 | +9.6 |
| WOUNDS ON THE RANKS | 18 | 17 | 5 | 1.67 | +319 | +63.9 |
| FOUR ROUNDS | 11 | 10 | 4 | 1.33 | +26 | +6.6 |
| JOINT CHARGE NOW | 4 | 4 | 4 | 1.33 | -0 | -0.1 |
| LEGAL CHARGES ONLY | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| MARCH OF THE TABLE | 4 | 4 | 4 | 1.33 | -151 | -37.7 |
| TIED UP BY THE SUM | 4 | 4 | 4 | 1.33 | +41 | +10.4 |
| ADVANCE LANE KEPT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| FALLS SHORT | 69 | 63 | 3 | 1.00 | +66 | +21.9 |
| HUNT IN PAIRS | 6 | 6 | 3 | 1.00 | +196 | +65.4 |
| MAX FOR POSITIONING | 11 | 10 | 3 | 1.00 | +13 | +4.2 |
| AFTERMATH IN POINTS | 2 | 2 | 2 | 0.67 | +56 | +28.2 |
| CHARGE NOW FIRST | 6 | 6 | 2 | 0.67 | -18 | -8.9 |
| HOLDS AMBUSHERS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| LANE BY FIGURES | 2 | 2 | 2 | 0.67 | +128 | +64.0 |
| MARCH CHECK | 4 | 4 | 2 | 0.67 | +49 | +24.6 |
| MOVE ORDER | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| NEXT CHARGE BY LIST | 6 | 6 | 2 | 0.67 | +47 | +23.3 |
| REDIRECT BY WHAT IT STOPS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| WHO FIGHTS | 4 | 4 | 2 | 0.67 | +8 | +4.2 |
| CARRIES OUT SET-UP | 1 | 1 | 1 | 0.33 | -22 | -22.5 |
| CASTS FROM BEHIND | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CHAFF IN THE MOVE | 2 | 2 | 1 | 0.33 | +0 | +0.0 |
| CHALLENGE BY POINTS | 1 | 1 | 1 | 0.33 | +7 | +6.9 |
| EXACT ROUND | 7 | 7 | 1 | 0.33 | +0 | +0.0 |
| FIRE IN ORDER | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| GUN MASK | 9 | 9 | 1 | 0.33 | +27 | +27.4 |
| KEEP FALLS | 1 | 1 | 1 | 0.33 | +6 | +5.5 |
| LOST AFTER ESCAPE | 6 | 5 | 1 | 0.33 | +5 | +4.8 |
| MANOEUVRE | 10 | 10 | 1 | 0.33 | +1 | +0.6 |
| MARCH BY THE SUM | 1 | 1 | 1 | 0.33 | +15 | +15.0 |
| NEARER NOT NEEDED | 29 | 28 | 1 | 0.33 | +59 | +58.8 |
| ONE OBJECTIVE FORMULA | 28 | 26 | 1 | 0.33 | +360 | +359.7 |
| PIVOT GUARDS FLANK | 1 | 1 | 1 | 0.33 | -21 | -21.1 |
| REDIRECT WEIGHED | 1 | 1 | 1 | 0.33 | +90 | +89.6 |
| SET CREDITED ONCE | 7 | 7 | 1 | 0.33 | +23 | +22.8 |
| SWIFTSTRIDE BY POINTS | 1 | 1 | 1 | 0.33 | +8 | +7.6 |
| THE ROW IN ITS ORDER | 9 | 1 | 1 | 0.33 | +0 | +0.0 |
| WHO HITS BACK | 1 | 1 | 1 | 0.33 | +14 | +14.4 |
| CANNON PLAN MISSED | 4 | 4 | 0 | 0.00 | - | - |
| CHARACTER GUNS | 22 | 21 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 49 | 49 | 0 | 0.00 | - | - |
| DEFENSIVE ARMY | 2 | 2 | 0 | 0.00 | - | - |
| DENIED BY THE FIGHT | 2 | 1 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 2 | 1 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 8 | 7 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 2 | 2 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 4 | 3 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 31 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 17 | 17 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 5 | 5 | 0 | 0.00 | - | - |
| GIVES UP | 1 | 1 | 0 | 0.00 | - | - |
| GUN FIGURES | 5 | not checked | - | - | - | - |
| HE REFORMS ONCE FREED | 8 | 8 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 68 | 67 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 79 | 79 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 23 | 23 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 23 | 23 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 21 | 21 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 2 | 1 | 0 | 0.00 | - | - |
| HIS TURN RUN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 79 | 79 | 0 | 0.00 | - | - |
| HONEST WORTH | 8 | 7 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 7 | 7 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 3 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 6 | 6 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 3 | 3 | 0 | 0.00 | - | - |
| MISSILES IN THE MOVE | 20 | 15 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 28 | 24 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 9 | 8 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 18 | 18 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT TURNED | 1 | 1 | 0 | 0.00 | - | - |
| ONE CHALLENGE TEST | 1 | 1 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 3 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 17 | 13 | 0 | 0.00 | - | - |
| ONE JOINT FIGURE | 3 | 2 | 0 | 0.00 | - | - |
| ONE ROUTE | 3 | 3 | 0 | 0.00 | - | - |
| OVERRUNS AWAY | 1 | 1 | 0 | 0.00 | - | - |
| PLAN RESULT | 275 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 3 | 3 | 0 | 0.00 | - | - |
| PROMISE READS THE TABLE | 3 | 3 | 0 | 0.00 | - | - |
| REAL GROUND | 3 | 3 | 0 | 0.00 | - | - |
| REDIRECT COUNTER | 6 | 6 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 3 | 3 | 0 | 0.00 | - | - |
| REFUSING RETIRES | 1 | 1 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 4 | 4 | 0 | 0.00 | - | - |
| RUN DOWN | 7 | 6 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 2 | 2 | 0 | 0.00 | - | - |
| SEARCH SPOT | 1 | 1 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 3 | 2 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 92 | not checked | - | - | - | - |
| SHOT OR CHARGE | 3 | 3 | 0 | 0.00 | - | - |
| SPELL WORTH | 18 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 28 | 22 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 12 | 12 | 0 | 0.00 | - | - |
| STANDS STILL | 365 | 361 | 0 | 0.00 | - | - |
| SUPPORT NARROWED | 1 | 1 | 0 | 0.00 | - | - |
| SURE REACH TOGETHER | 2 | 2 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 5 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 14 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 8 | not checked | - | - | - | - |
| THE TABLE BINDS | 274 | not checked | - | - | - | - |
| WAITS AGAIN | 1 | 1 | 0 | 0.00 | - | - |
| WHOLE FIGHT DANGER | 14 | 14 | 0 | 0.00 | - | - |
| WHOLE FIGHT GAIN | 4 | 3 | 0 | 0.00 | - | - |

### Off best figure: csame-bb45c30-p28

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 6.33 | 4.33 | 23.7 |
| PROMISE BY ITS OWN SUM | rule | 3.00 | 0.67 | 33.0 |
| ARMY TABLE | rule | 1.00 | 0.67 | 22.7 |
| MARCH OF THE TABLE | rule | - | 1.33 | 37.7 |
| HOLDER ASSIGNMENT | rule | 0.33 | 0.67 | 4.4 |
| CHARGE NOW FIRST | rule | - | 0.67 | 8.9 |
| JOINT CHARGE NOW | rule | 0.33 | 0.33 | 106.3 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.33 | - | 27.0 |
| CARRIES OUT SET-UP | rule | - | 0.33 | 22.5 |
| DEPLOY BY FIGURES | rule | 0.33 | - | 6.9 |
| FALLBACK | gate | 0.33 | - | 38.9 |
| PIVOT GUARDS FLANK | rule | - | 0.33 | 21.1 |

### Plans: csame-bb45c30-p28

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.3 | 25% | 39 | 40 | 102% |
| Mine | join | 1.7 | 100% | 54 | 0 | 0% |
| Mine | move | 36.7 | 98% | 1077 | 0 | 0% |
| Mine | shoot | 20.7 | 58% | 534 | 728 | 136% |
| Opponent | charge | 1.7 | 40% | 75 | 93 | 123% |
| Opponent | join | 1.0 | 100% | 54 | 0 | 0% |
| Opponent | move | 22.0 | 98% | 517 | 0 | 0% |
| Opponent | shoot | 5.7 | 41% | 299 | 143 | 48% |
| Opponent | support | 1.0 | 100% | 25 | 0 | 0% |

### Battle groups: csame-bb45c30-p28

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 1.0 | 33% | 100% | 0% | - | 0% | 0% | 0% | 100% | 0% |
| Opponent | REDIRECT COUNTER | 1.0 | 67% | 50% | 0% | - | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: csame-bb45c30-p28

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | 0 (1) | - | - | 0 (1) | - |
| Mine | Character | 13 | 3 (13) | 3 | 0 | 0 | 31% | 3.1 | 6 (6) | 0 (6) | 0 (1) | 4 (11) | 0 (2) |
| Mine | Clean-up | 4 | 20 (4) | 0 | 20 | 0 | 75% | 1.0 | 0 (1) | 0 (1) | 39 (2) | 20 (4) | - |
| Mine | Fast | 3 | 0 (3) | 0 | 0 | 73 | 33% | 1.0 | - | 0 (1) | 0 (2) | 0 (3) | - |
| Mine | Hammer | 4 | 114 (4) | 10 | 104 | 0 | 25% | 3.0 | 25 (1) | 177 (3) | - | 114 (4) | - |
| Mine | Shooter | 8 | 92 (8) | 37 | 54 | 18 | 12% | 2.1 | 49 (1) | 169 (4) | 9 (3) | 102 (6) | 66 (2) |
| Mine | War machine | 17 | 10 (17) | 10 | 0 | 22 | 12% | 1.4 | 0 (4) | 19 (9) | 0 (4) | 0 (3) | 13 (14) |
| Opponent | Chaff | 3 | 0 (3) | 0 | 0 | 63 | 33% | 4.0 | 0 (2) | - | 0 (1) | 0 (3) | - |
| Opponent | Character | 10 | 12 (10) | 12 | 0 | 20 | 60% | 2.8 | 6 (3) | 22 (5) | 0 (2) | 15 (9) | 0 (1) |
| Opponent | Clean-up | 1 | 59 (1) | 59 | 0 | 0 | 0% | 3.0 | - | 59 (1) | - | 59 (1) | - |
| Opponent | Fast Hammer | 3 | 25 (3) | 0 | 25 | 0 | 100% | - | 0 (1) | 84 (1) | 0 (1) | 35 (2) | 0 (1) |
| Opponent | Holder | 6 | 97 (6) | 10 | 87 | 16 | 50% | 3.0 | 17 (1) | 112 (5) | - | 136 (4) | 32 (2) |
| Opponent | War machine | 2 | 55 (2) | 55 | 0 | 50 | 0% | 1.0 | - | 109 (1) | 0 (1) | - | 55 (2) |
| Opponent | Wizard | 2 | 0 (2) | 0 | 0 | 0 | 0% | 1.5 | 0 (1) | 0 (1) | - | 0 (2) | - |

### Charged fights: csame-bb45c30-p28

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Dwarfen Mountain Holds | 3 | 94 | 14 | 1.0 | 1.0 | 14 | 0 | +14 | 0 of 3 | 3 of 3 | - | +14 |
| Opponent | Grand Cathay | 1 | 345 | 233 | 2.0 | 1.5 | 116 | 217 | -100 | 2 of 2 | 0 of 2 | -434 | +233 |
| Opponent | Vampire Counts | 1 | 0 | 95 | 1.0 | 1.0 | 95 | 0 | +95 | 0 of 1 | 1 of 1 | - | +95 |
| Opponent | Warriors of Chaos | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| **Opponent** | all armies | 3 | 115 | 109 | 1.0 | 1.3 | 109 | 145 | -35 | 2 of 3 | 1 of 3 | -434 | +164 |

### Effective charges: csame-bb45c30-p28

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Dwarfen Mountain Holds | 3 | 0 | 0 | 0 | 0 | 0 | 3 (net +14) | 0 | 0% (0 of 3) |
| Opponent | Grand Cathay | 2 | 0 | 0 | 0 | 1 (net +233) | 1 (net -434) | 0 | 0 | 0% (0 of 2) |
| Opponent | Vampire Counts | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +95) | 0 | 0% (0 of 1) |

### Charged fights, damage counted: csame-bb45c30-p28

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 | 72 | 71 | +14 | 66 | 39 | +27 | +38.0 |
| Mine | All fights | 3 | 72 | 71 | +14 | 66 | 39 | +27 | +38.0 |
| Opponent | 76-89% | 1 | 379 | 183 | +233 | 342 | 0 | +342 | +90.1 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 161 | 95 | +95 | 142 | 0 | +142 | +88.5 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 551 | 183 | -434 | 26 | 434 | -408 | -74.0 |
| Opponent | All fights | 3 | 364 | 154 | -35 | 170 | 145 | +25 | +7.0 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| csame-bb45c30-p28 | move | 12 | 4 (33%) | 4 (33%) | 1 (8%) | 7 (58%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L0524 |
| Clockwork Compass | Opponent | L0612 |
| Invocation of Nehek | Opponent | L0524 |
| Ring of Doom | Opponent | L0612 |
| Ring of Jet | Opponent | L0612 |

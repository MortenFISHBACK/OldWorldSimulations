# Doctrine scorecard: csame-bb45c30-p19

### Scorecard: csame-bb45c30-p19

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L1118 | 2 | 1 | Mine | - | - | 2 | 1 | 0 | 0 | 0 | 0 | 330 |
| L1118 | 2 | 1 | Opponent | - | - | 3 | 3 | 3 | 1 | 0 | 0 | 413 |
| L1135 | 1 | 1 | Mine | yes | 0 | 2 | 2 | 0 | 1 | 0 | 0 | 165 |
| L1135 | 1 | 1 | Opponent | no | 0 | 3 | 4 | 2 | 0 | 0 | 0 | 274 |
| L1228 | 4 | 1 | Mine | no | 0 | 2 | 2 | 0 | 0 | 0 | 0 | 330 |
| L1228 | 4 | 1 | Opponent | no | 0 | - | 0 | 0 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 50% | 0.0 | 2.0 | 1.7 | 0.0 | 0.3 | 0.0 | 0.0 | 275.0 |
| **Average** | | | Opponent | 0% | 0.0 | 3.0 | 2.3 | 1.7 | 0.3 | 0.0 | 0.0 | 229.0 |

### KPIs: csame-bb45c30-p19

Rules off - Mine only: NO OLD ONE-MOVE GUESS; both sides: ONE RUN A PLAN.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 29% (4 of 14) | 0% (0 of 18) | 12% (4 of 32) |
| Winner chose to follow up after the loser gave ground |  | 100% (5 of 5); on the table 100% | 100% (2 of 2); on the table 100% | 100% (7 of 7); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | - | - | - |
| Winner chose to pursue after the loser fled |  | 50% (3 of 6); on the table 50% | - | 50% (3 of 6); on the table 50% |
| Winner chose to follow up or pursue (all three) |  | 73% (8 of 11); on the table 73% | 100% (2 of 2); on the table 100% | 77% (10 of 13); on the table 77% |
| Magic missiles tried each own turn | 50%+ | 29% (21 of 72) | 33% (6 of 18) | 30% (27 of 90) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 40% (21 of 52) | 43% (6 of 14) | 41% (27 of 66) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | - | - |
| Points that never fought | lower | 33% (1985 of 5998) | 55% (3320 of 6000) | 44% (5305 of 11998) |
|   infantry points that never fought | lower | 77% (559 of 730) | 45% (352 of 782) | 60% (911 of 1512) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 64% (16 of 25) | 65% (17 of 26) | 65% (33 of 51) |
| Bound items with a magic missile used (at least once a game) |  | 86% (6 of 7); 5.3 uses a game | 50% (1 of 2); 1.0 uses a game | 78% (7 of 9); 3.2 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0% (0 of 3); 0.0 uses a game | 0.0 uses a game | 0% (0 of 3); 0.0 uses a game |
|   their share of the points of units over 100 pts | lower | 57% (3195 of 5614) | 53% (3010 of 5644) | 55% (6205 of 11258) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 2.3 (14%) | 0.0 (0%) | 2.3 (11%) |
| MARCHED: its unit marched | 6.7 (39%) | 0.3 (8%) | 7.0 (33%) |
| CHARGED: its unit charged | 1.3 (8%) | 0.0 (0%) | 1.3 (6%) |
| IN COMBAT: engaged in combat | 6.0 (35%) | 0.3 (8%) | 6.3 (30%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 1.0 (25%) | 1.0 (5%) |
| FLEEING: fleeing | 0.0 (0%) | 1.0 (25%) | 1.0 (5%) |
| GONE: slain | 0.7 (4%) | 0.0 (0%) | 0.7 (3%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.3 (8%) | 0.3 (2%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 1.0 (25%) | 1.0 (5%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 2.0 | 6.3 | 0.7 | 9.0 | 0.7 | 3.7 |
| not cast | 2.0 | 9.7 | 5.3 | 21.0 | 3.3 | 24.3 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.0 (4%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 5.3 (55%) | 0.0 (0%) | 2.3 (11%) | 0.3 (10%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 7.0 (33%) | 1.0 (30%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.3 (6%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.7 (7%) | 0.3 (6%) | 6.3 (30%) | 1.7 (50%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 2.0 (21%) | 2.0 (38%) | 1.0 (5%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 1.0 (50%) | 0.0 (0%) | 1.0 (19%) | 1.0 (5%) | 0.0 (0%) | 2.0 (8%) |
| GONE: slain | 0.0 (0%) | 0.7 (7%) | 0.0 (0%) | 0.7 (3%) | 0.3 (10%) | 1.7 (7%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (1%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.3 (3%) | 0.3 (6%) | 0.3 (2%) | 0.0 (0%) | 0.7 (3%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.7 (7%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.0 (5%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.0 (50%) | 0.0 (0%) | 1.7 (31%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 18.7 (77%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.0 a game | 0.7 a game | 0.3 a game |
| stood (cast and not dispelled) | - | 0% (0 of 2) | 0% (0 of 2) |
| the unit moved after it | - | - | - |
| it charged on its next turn | - | - | - |
| the enemy charged it first | - | - | - |
| it fought by the end of its next turn | - | - | - |
| it moved out of a charge the enemy had planned (not charged first) | - | - | - |
| none of these (no charge, no fight, no charge escaped) | - | - | - |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 69% (33 of 48) | 55% (44 of 80) | 60% (77 of 128) |
|   cavalry | - | 59% (10 of 17) | 59% (10 of 17) |
|   character | - | 58% (7 of 12) | 58% (7 of 12) |
|   chariot | 44% (4 of 9) | 92% (11 of 12) | 71% (15 of 21) |
|   infantry | 89% (8 of 9) | 32% (9 of 28) | 46% (17 of 37) |
|   monster | - | 64% (7 of 11) | 64% (7 of 11) |
|   war machine | 70% (21 of 30) | - | 70% (21 of 30) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.0 (20%) | 4.3 (36%) | 5.3 (31%) |
| CHARGED: it charged | 0.3 (7%) | 1.7 (14%) | 2.0 (12%) |
| FLEEING: it fled or was fleeing | 0.7 (13%) | 0.0 (0%) | 0.7 (4%) |
| IN COMBAT: it fought this turn or the last | 0.0 (0%) | 0.3 (3%) | 0.3 (2%) |
| MOVED: a war machine that moved | 0.3 (7%) | 0.0 (0%) | 0.3 (2%) |
| NO TARGET IN RANGE | 0.0 (0%) | 3.0 (25%) | 3.0 (18%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.3 (7%) | 2.3 (19%) | 2.7 (16%) |
| SHELTERED: the target was sheltered | 2.0 (40%) | 0.3 (3%) | 2.3 (14%) |
| OTHER BAR | 0.3 (7%) | 0.0 (0%) | 0.3 (2%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 5.0 | 0.7 | 93% | 3.2 pts | 16 pts |
| character | 2.3 | 1.3 | 71% | 30.8 pts | 72 pts |
| chariot | 5.0 | 0.7 | 93% | 7.3 pts | 37 pts |
| infantry | 7.7 | 3.0 | 74% | 10.0 pts | 76 pts |
| monster | 2.3 | 1.3 | 71% | 9.8 pts | 23 pts |
| war machine | 8.3 | 8.7 | 48% | 23.1 pts | 193 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.7 | 3.3 | 4.0 |
| Charges that made contact a game | 4.0 | 3.0 | 3.5 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.67 declared, 1.33 contact (6 units) | - | 1.67 declared, 1.33 contact (6 units) |
|   per unit a game, units carrying another wizard (or one alone) | 2.00 declared, 2.00 contact (1 units) | - | 2.00 declared, 2.00 contact (1 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.22 declared, 0.22 contact (9 units) | 0.38 declared, 0.35 contact (26 units) | 0.34 declared, 0.31 contact (35 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 83% (5 of 6) | - | 0% (0 of 4) | 50% (5 of 10) |
| Character in a unit | 67% (2 of 3) | 67% (2 of 3) | 100% (1 of 1) | 71% (5 of 7) |
| Character on its own | - | 57% (4 of 7) | 25% (1 of 4) | 45% (5 of 11) |
| Chariot | 75% (3 of 4) | - | - | 75% (3 of 4) |
| Infantry | 75% (6 of 8) | - | - | 75% (6 of 8) |
| Monster | - | 0% (0 of 1) | - | 0% (0 of 1) |
| Monstrous | 100% (2 of 2) | 50% (1 of 2) | - | 75% (3 of 4) |
| War Machines | 100% (6 of 6) | - | - | 100% (6 of 6) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Grand Cathay | 3 | 73% (8 of 11); on the table 73% | 29% (21 of 72) | 33% | 64% (16 of 25) | 86% (6 of 7); 5.3 uses a game | 0.0 uses a game | 0% (0 of 3); 0.0 uses a game |
| Ogre Kingdoms | 1 | - | 0% (0 of 6) | 85% | 57% (4 of 7) | 100% (1 of 1); 3.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 1 | - | 67% (4 of 6) | 53% | 29% (2 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 1 | 100% (2 of 2); on the table 100% | 33% (2 of 6) | 29% | 92% (11 of 12) | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (csame-bb45c30-p19, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 67% (6) | 33% (2) | 53% (8) |
| ...free all their last turn and able to turn (per game) | 2.00 | 0.67 | 2.67 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 1.33 | 0.67 | 2.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: csame-bb45c30-p19

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.7 | 1.0 |
| Strategy | Charge objectives carried out (made contact) | 79% (11 of 14) | 100% (7 of 7) |
| Strategy | Shoot objectives carried out (shot that target) | 35% (15 of 43) | 68% (15 of 22) |
| Strategy | Support requests answered (helper made contact too) | 100% (2 of 2) | - |
| Strategy | Hexes on a unit its side charged or shot that turn | 57% (4 of 7) | 100% (1 of 1) |
| Strategy | Joined characters whose unit fought | 75% (3 of 4) | 40% (2 of 5) |
| Strategy | Lone characters that fought | 100% (8 of 8) | 67% (2 of 3) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 0.0 | 1.7 |
| Movement | Points that never moved of their own | 275.0 | 229.0 |
| Movement | Fights charged into per game | 3.0 | 3.0 |
| Movement | Charges with odds: long shots (under 50%) | 4 of 9, net -146 | 1 of 7, net +0 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 9 | 0 of 7 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 2 of 9, net +236 | 1 of 7, net +383 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 of 9, net +70 | 2 of 7, net +260 |
| Shooting | Shots by shooting units (incl. breath weapons) | 4.0 | 15.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 0% (0 of 12) | 58% (26 of 45) |
| Shooting | Points destroyed by shooting units | 38.0 | 110.0 |
| Shooting | War machine shots | 7.3 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 36% (8 of 22) | - |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | 5.0 | 0.7 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 27% (4 of 15) | 50% (1 of 2) |
| Magic | Wounds caused by magic missiles | 3.7 | - |
| Magic | Wounds caused by other spells | 0.7 | 1.0 |
| Magic | Points destroyed by magic (all spells) | 131.3 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.0 / 2.3 / 0.7 / 0.3 | 0.3 / 0.3 / 0.7 / 0.0 |
| Combat | Points destroyed in combat | 64.0 | 369.0 |
| Combat | Points run down | 88.3 | 0.0 |
| Combat | Net points per charged fight, damage counted | +18 | +84 |
| Combat | Net per 100 charger points, damage counted | +4.8 | +36.6 |
| Combat | First round won (charged fights) | 67% | 56% |
| Combat | Net points per charged fight | +3 | +83 |
| Combat | Net points per supported fight / lone fight | +144 / -67 | - / +83 |
| Combat | Charged fights on a top-3 enemy unit | 5 of 9 | 5 of 9 |
| Game | Points lost | 637.7 | 426.7 |
| Game | VP from objectives | 653.3 | 550.0 |
| Game | Lone holders (player turns) | 0.0 | 0.0 |

- Mine won / drew / lost: 1 / 2 / 0 of 3 ended games (of 3); mean margin (Mine - Opponent) +10 VP
- The side that went first won 1 of 1 games with a winner
- Points traded per game (both sides' losses): 1064
- Games not ended: 0; findings 1, warnings 0

### Opponent rules: csame-bb45c30-p19

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | - | - | - | - | 0.3 | +184.4 | 0.0 | 0.0 |
| ARMY TABLE | 6.0 | +0.2 | 0.0 | 132.3 | 31.7 | +504.9 | 0.0 | 252.0 |
| ARTILLERY RE-ROLL WEIGHED | 3.3 | +0.0 | 0.0 | 55.0 | - | - | - | - |
| ASSAILMENT BY POINTS | 0.7 | +4.9 | 0.0 | 194.7 | 0.3 | +1.5 | 0.0 | 91.3 |
| BACKUP TARGETS | 0.3 | +3.1 | 0.0 | 0.0 | 0.3 | +4.0 | 0.0 | 0.0 |
| BEST PRIZE | 0.3 | -13.7 | 0.0 | 0.0 | - | - | - | - |
| BOMBING RUN | 0.3 | +10.8 | 0.0 | 50.0 | - | - | - | - |
| CANNON PLAN MISSED | 0.3 | +0.0 | 38.0 | 0.0 | - | - | - | - |
| CANNON PLANNED TARGET | 6.7 | +377.4 | 38.0 | 165.0 | - | - | - | - |
| CANNON SIGHT KEPT | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CAST JOB | 4.3 | +128.4 | 89.3 | 0.0 | 1.0 | +4.6 | 0.0 | 0.0 |
| CASTER AWAY FROM SCREEN | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 2.0 | +28.2 | 0.0 | 0.0 | 0.7 | +6.3 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | - | - | - | - | 1.3 | +42.1 | 0.0 | 34.0 |
| CHAFF PASSED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CHALLENGE BY POINTS | - | - | - | - | 0.3 | +24.9 | 0.0 | 0.0 |
| CHAMPION KNOWS CHALLENGE | - | - | - | - | 0.3 | -7.8 | 0.0 | 0.0 |
| CHARGE LOSSES | 16.3 | -808.8 | 0.0 | 346.0 | 19.3 | -1789.8 | 0.0 | 291.0 |
| CHARGE NOW FIRST | 3.3 | +0.0 | 338.0 | 223.7 | 1.0 | +0.0 | 173.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 5.3 | +0.0 | 0.0 | 123.0 | 5.7 | +0.0 | 0.0 | 22.7 |
| COMBAT PIVOT | 1.0 | +0.0 | 0.0 | 123.0 | - | - | - | - |
| CONVEYANCE SEARCH | - | - | - | - | 0.7 | +89.7 | 0.0 | 91.3 |
| COVER ONCE | 6.7 | -373.3 | 0.0 | 281.7 | 10.0 | -980.8 | 0.0 | 0.0 |
| DEFENSIVE FLOOR | - | - | - | - | 0.3 | +3.2 | 0.0 | 0.0 |
| DENIED BY THE FIGHT | 1.0 | -5.2 | 152.0 | 0.0 | 0.3 | -1.1 | 0.0 | 0.0 |
| DEPLOY BY FIGURES | 6.0 | -45.0 | 0.0 | 0.0 | 8.3 | -61.2 | 0.0 | 0.0 |
| EDGE GIVE GROUND | 1.0 | +175.3 | 158.0 | 0.0 | - | - | - | - |
| EVASIVE BY THE ODDS | - | - | - | - | 0.7 | +15.9 | 0.0 | 0.0 |
| EXACT ROUND | 2.0 | +36.9 | 289.0 | 0.0 | 2.3 | -11.9 | 300.7 | 0.0 |
| FALL BACK GOOD ORDER | 3.3 | +1.6 | 257.7 | 68.3 | 1.7 | +6.9 | 50.0 | 0.0 |
| FALLS SHORT | 4.7 | +117.5 | 0.0 | 82.3 | 18.3 | +255.6 | 0.0 | 190.7 |
| FEATURE BUFFS | 1.0 | +8.9 | 0.0 | 0.0 | 1.3 | +8.8 | 0.0 | 0.0 |
| FIGHT LIFT | - | - | - | - | 0.3 | +9.1 | 0.0 | 0.0 |
| FIGHT TO THE END | 1.7 | +22.6 | 105.3 | 68.3 | 0.7 | +20.9 | 0.0 | 0.0 |
| FIRE IN ORDER | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FIVE ACTION | 76.0 | +6902.2 | 554.7 | 1786.3 | 82.0 | +5939.2 | 960.7 | 648.0 |
| FLANK NOT WEIGHED | 6.0 | +0.0 | 0.0 | 50.0 | 7.7 | +0.0 | 0.0 | 144.7 |
| FOLLOW UP WEIGHED | 1.0 | +267.2 | 0.0 | 0.0 | 1.0 | +158.3 | 0.0 | 0.0 |
| FOUR ROUNDS | 4.7 | +1379.6 | 349.3 | 263.0 | 2.7 | +247.1 | 300.7 | 0.0 |
| FREED FROM HIS FIGHT | 2.3 | +0.0 | 0.0 | 100.0 | 5.3 | +0.0 | 0.0 | 93.3 |
| FRIEND CHARGES FIRST | - | - | - | - | 0.3 | -16.7 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 1.0 | -89.7 | 0.0 | 126.3 | 0.3 | -2.1 | 0.0 | 0.0 |
| GIVES UP | 1.0 | -4.3 | 11.3 | 68.3 | 0.3 | -12.9 | 77.7 | 0.0 |
| GOAL WALK | 2.0 | +162.1 | 0.0 | 0.0 | 12.3 | +1128.8 | 0.0 | 83.3 |
| GUN MASK | 2.0 | +109.2 | 0.0 | 0.0 | - | - | - | - |
| HARD STAY DROPPED | 1.0 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 42.0 |
| HE REFORMS ONCE FREED | 0.7 | +0.0 | 0.0 | 100.0 | 6.0 | +0.0 | 0.0 | 93.3 |
| HIS CHARGE BY HIS RUN | 12.3 | +0.0 | 0.0 | 246.0 | 15.0 | +0.0 | 0.0 | 197.7 |
| HIS CHARGE DENIED | - | - | - | - | 0.7 | +28.4 | 123.0 | 0.0 |
| HIS CHARGE LIST | 3.3 | +0.0 | 0.0 | 0.0 | 7.0 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 4.3 | +0.0 | 0.0 | 123.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 4.0 | -32.7 | 0.0 | 123.0 | 7.0 | -45.1 | 0.0 | 167.3 |
| HIS MOVE AS HE DECIDES | 41.7 | +9.0 | 648.0 | 0.0 | - | - | - | - |
| HIS ONE MOVE | 16.0 | -0.9 | 0.0 | 0.0 | - | - | - | - |
| HIS ONE QUARTER | 2.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 2.0 | +0.0 | 0.0 | 0.0 | 7.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 30.0 | +880.2 | 0.0 | 601.0 | 48.0 | +2468.4 | 0.0 | 345.0 |
| HIS SHOTS BY HIS RUN | 36.7 | +950.8 | 0.0 | 847.0 | 46.3 | +1365.7 | 0.0 | 262.0 |
| HIS TURN DENIED | 1.3 | +39.4 | 230.0 | 0.0 | 0.7 | +4.4 | 50.0 | 0.0 |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 13.0 | +0.0 | 0.0 | 64.7 | 10.0 | +0.0 | 0.0 | 0.0 |
| HOLDER ASSIGNMENT | 9.3 | +849.9 | 0.0 | 32.3 | 7.0 | +875.0 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 4.0 | -109.4 | 349.3 | 263.0 | 1.7 | -73.1 | 250.7 | 0.0 |
| HUNT IN PAIRS | 0.7 | +28.1 | 0.0 | 0.0 | - | - | - | - |
| IDLE COST | 0.7 | -30.8 | 0.0 | 0.0 | 9.7 | -164.4 | 0.0 | 135.3 |
| JOINT CHARGE NOW | 1.7 | -160.3 | 52.7 | 68.3 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 2.0 | +0.0 | 0.0 | 64.7 | 1.3 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 1.3 | +33.7 | 0.0 | 0.0 | 0.3 | +15.7 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 3.0 | +0.0 | 0.0 | 401.3 | 5.3 | +0.0 | 123.0 | 198.0 |
| LONE WIZARD KEPT IN | 0.7 | +52.8 | 0.0 | 0.0 | - | - | - | - |
| LOST AFTER ESCAPE | 3.3 | -8.9 | 219.0 | 263.0 | 2.0 | +2.7 | 200.7 | 0.0 |
| MANOEUVRE | 1.7 | +3.3 | 0.0 | 0.0 | 1.7 | -1.3 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +8.0 | 0.0 | 0.0 |
| MARCH BY THE SUM | 1.0 | +40.5 | 0.0 | 0.0 | 1.0 | +45.0 | 0.0 | 0.0 |
| MARCH CHECK | 2.0 | +70.4 | 0.0 | 0.0 | 0.3 | +24.1 | 0.0 | 0.0 |
| MARCH OF THE TABLE | 1.7 | +284.2 | 0.0 | 0.0 | 0.7 | +37.1 | 0.0 | 0.0 |
| MARCH OVER CASTS | 3.0 | -88.3 | 0.0 | 0.0 | 1.3 | +14.1 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 4.0 | +123.8 | 0.0 | 123.0 | 3.7 | +140.0 | 0.0 | 0.0 |
| MEETS IN TIME | 1.7 | +155.5 | 0.0 | 0.0 | 4.0 | +307.2 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 9.3 | +362.0 | 0.0 | 327.0 | 3.0 | +31.4 | 0.0 | 52.7 |
| MISSILES NEXT TURN | 14.0 | +256.3 | 0.0 | 327.0 | 3.7 | +27.0 | 0.0 | 52.7 |
| MISSILES ON ONE TARGET | 0.7 | -16.9 | 0.0 | 0.0 | - | - | - | - |
| MOVE ORDER | 0.3 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| MOVE SPELL OUT OF RANGE | - | - | - | - | 0.3 | -8.4 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 1.7 | +262.0 | 0.0 | 0.0 | 4.0 | +472.5 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 5.0 | +229.0 | 0.0 | 32.3 | 5.7 | +270.4 | 0.0 | 46.7 |
| NEXT CHARGE BY LIST | 1.0 | +97.6 | 0.0 | 0.0 | 2.3 | +174.6 | 0.0 | 0.0 |
| NEXT OBJECTIVE NEARER | 0.3 | -4.2 | 38.0 | 0.0 | 0.3 | -33.3 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 2.7 | -116.2 | 349.3 | 0.0 | 2.3 | -135.6 | 300.7 | 0.0 |
| NO LATE CUT | 1.3 | +0.0 | 0.0 | 64.7 | - | - | - | - |
| NO OLD ONE-MOVE GUESS | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 0.7 | -0.1 | 0.0 | 0.0 | 0.3 | -2.7 | 0.0 | 91.3 |
| OFF BEST | 5.3 | -101.9 | 0.0 | 0.0 | 5.7 | -171.0 | 0.0 | 11.3 |
| OGRE LOADER SECOND SHOT | 5.3 | +78.8 | 0.0 | 55.0 | - | - | - | - |
| ONE CHALLENGE TEST | 0.7 | +6.3 | 105.3 | 0.0 | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ONE FIGHT FORMULA | 4.7 | -97.0 | 0.0 | 77.7 | 6.0 | -138.9 | 0.0 | 0.0 |
| ONE OBJECTIVE FORMULA | 5.3 | +135.5 | 0.0 | 0.0 | 3.3 | -70.3 | 0.0 | 0.0 |
| OPENS UP | 0.3 | +8.2 | 11.3 | 0.0 | - | - | - | - |
| OVERRUNS AWAY | 1.7 | +55.4 | 271.7 | 0.0 | - | - | - | - |
| PATHS CROSS | 0.3 | +22.3 | 0.0 | 0.0 | - | - | - | - |
| PLAN RESULT | 34.7 | +721.4 | 286.7 | 1120.3 | 37.3 | +465.7 | 525.7 | 659.3 |
| PROMISE BY ITS OWN SUM | 3.7 | -60.7 | 0.0 | 0.0 | 7.3 | -498.1 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | 1.0 | -175.2 | 0.0 | 126.3 | - | - | - | - |
| PROMISE SHOT AWAY | 0.7 | -177.3 | 0.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | 14.3 | +1759.4 | 0.0 | 508.0 | 10.7 | +1530.0 | 127.7 | 0.0 |
| REDIRECT COUNTER | - | - | - | - | 2.0 | +320.4 | 0.0 | 11.3 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 2.0 | +0.0 | 0.0 | 36.3 |
| REFORMS TO MEET IT | - | - | - | - | 1.3 | -56.8 | 0.0 | 0.0 |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| RESERVE FALL BACK | 0.3 | +0.9 | 0.0 | 50.0 | - | - | - | - |
| RISK BY ARC | 4.3 | +123.3 | 335.7 | 263.0 | 2.0 | +8.3 | 250.7 | 0.0 |
| RISK ON THE WAY | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ROUNDS AFTER TERROR | 0.3 | -7.8 | 13.7 | 0.0 | 1.0 | -29.0 | 250.7 | 0.0 |
| RUN DOWN | 3.3 | -25.6 | 349.3 | 126.3 | 2.3 | -18.1 | 250.7 | 0.0 |
| SCOUT SPOT | - | - | - | - | 0.7 | +2.9 | 0.0 | 0.0 |
| SCOUT WAITS | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 1.0 | -39.5 | 0.0 | 34.0 |
| SEARCH SPOT | - | - | - | - | 1.0 | +20.4 | 0.0 | 0.0 |
| SET CREDITED ONCE | 1.7 | -433.2 | 0.0 | 126.3 | 1.7 | -85.6 | 0.0 | 0.0 |
| SET UP BY THE SET | 1.7 | +295.5 | 0.0 | 126.3 | 3.3 | +32.7 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | - | - | - | - | 0.3 | +0.3 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 14.3 | +0.0 | 0.0 | 275.0 | 7.3 | +0.0 | 0.0 | 64.0 |
| SHOOTS FROM THE BEST SPOT | 4.3 | +110.8 | 78.0 | 155.3 | 1.3 | +17.4 | 0.0 | 0.0 |
| SHOT OR CHARGE | 1.0 | -204.5 | 0.0 | 68.3 | - | - | - | - |
| SHOT RISK POINTS | 16.0 | -52.0 | 0.0 | 310.0 | 28.7 | +189.8 | 0.0 | 422.0 |
| SHOTS AFTER THE MOVES | 5.0 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 13.7 | +844.7 | 0.0 | 352.3 | 14.3 | +563.4 | 0.0 | 219.3 |
| SPELL WORTH | 1.3 | +14.8 | 0.0 | 0.0 | 2.3 | +31.4 | 91.3 | 91.3 |
| SPELLS IN THE FIGHT | 1.0 | -2.4 | 183.3 | 0.0 | - | - | - | - |
| SPOT AS THE GAME MOVES | 1.7 | +0.0 | 0.0 | 176.3 | 6.3 | +0.0 | 0.0 | 41.7 |
| STAND AND SHOOT | 0.3 | -0.8 | 52.7 | 0.0 | - | - | - | - |
| STANDS FOR A REASON | - | - | - | - | 4.0 | +0.0 | 0.0 | 189.3 |
| STANDS STILL | 40.0 | +0.0 | 205.3 | 760.0 | 30.7 | +0.0 | 660.0 | 189.3 |
| STANDS TO CAST | - | - | - | - | 0.3 | +42.9 | 0.0 | 0.0 |
| STAY WORTH | 27.3 | +156.9 | 89.3 | 729.3 | 22.3 | +292.3 | 550.0 | 126.7 |
| STRIKE BY THE ODDS | 1.3 | +35.2 | 0.0 | 68.3 | 0.3 | +0.0 | 68.3 | 0.0 |
| SUPPORT ADDS | 1.7 | +91.4 | 0.0 | 0.0 | 13.7 | +1873.1 | 0.0 | 0.0 |
| SUPPORT NARROWED | 0.7 | +0.0 | 58.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| SUPPORT WORKED OUT | 1.7 | +91.4 | 0.0 | 0.0 | 13.7 | +1873.1 | 0.0 | 0.0 |
| SURE REACH TOGETHER | 1.0 | +13.1 | 0.0 | 0.0 | - | - | - | - |
| SWIFTSTRIDE BY POINTS | 0.3 | -2.7 | 0.0 | 126.3 | - | - | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 2.0 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | - | - | - | - | 2.3 | +0.0 | 41.7 | 0.0 |
| THE ROW KEEPS ITS WAY | 2.0 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 103.0 |
| THE STEP BACK IS MADE | 1.0 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 91.7 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 32.7 | +0.0 | 0.0 | 706.7 | 39.0 | +0.0 | 0.0 | 335.3 |
| TIED UP BY THE SUM | 1.3 | +106.5 | 113.3 | 0.0 | 0.7 | +82.6 | 127.7 | 0.0 |
| TIME ON OUR SIDE | 22.7 | +346.4 | 0.0 | 205.3 | 20.3 | +196.4 | 0.0 | 156.0 |
| WAITS AGAIN | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| WHO FIGHTS | - | - | - | - | 1.0 | +4.1 | 0.0 | 0.0 |
| WHO GETS IN | 0.7 | +100.8 | 0.0 | 0.0 | - | - | - | - |
| WHO HITS BACK | - | - | - | - | 0.3 | +81.2 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | 3.0 | -492.3 | 0.0 | 246.0 | 6.0 | -1218.2 | 0.0 | 213.0 |
| WOUNDS ON THE RANKS | 5.7 | +70.9 | 0.0 | 0.0 | 4.3 | +114.7 | 0.0 | 0.0 |

### Rule changes: csame-bb45c30-p19

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS MOVE AS HE DECIDES | 125 | 125 | 98 | 32.67 | +0 | +0.0 |
| ARMY TABLE | 113 | 113 | 83 | 27.67 | +1351 | +16.3 |
| HIS SHOTS BY HIS RUN | 249 | 231 | 56 | 18.67 | +1146 | +20.5 |
| HIS SHOT LIST | 234 | 213 | 51 | 17.00 | +1356 | +26.6 |
| HOLDER ASSIGNMENT | 49 | 49 | 43 | 14.33 | +3362 | +78.2 |
| OFF BEST | 33 | 33 | 33 | 11.00 | -819 | -24.8 |
| THE TABLE AGAIN | 36 | 36 | 29 | 9.67 | +0 | +0.0 |
| LEGAL CHARGES ONLY | 25 | 25 | 25 | 8.33 | +0 | +0.0 |
| DEPLOY BY FIGURES | 43 | 43 | 22 | 7.33 | +408 | +18.6 |
| FIVE ACTION | 474 | 453 | 21 | 7.00 | +2015 | +96.0 |
| HIS ONE MOVE | 48 | 48 | 18 | 6.00 | +0 | +0.0 |
| SHOT RISK POINTS | 134 | 124 | 17 | 5.67 | +843 | +49.6 |
| SUPPORT ADDS | 46 | 42 | 17 | 5.67 | +2316 | +136.2 |
| SUPPORT WORKED OUT | 46 | 42 | 17 | 5.67 | +2316 | +136.2 |
| OGRE LOADER SECOND SHOT | 16 | 16 | 16 | 5.33 | +236 | +14.8 |
| TIME ON OUR SIDE | 129 | 114 | 15 | 5.00 | +42 | +2.8 |
| CAST JOB | 16 | 16 | 14 | 4.67 | +115 | +8.2 |
| FOUR ROUNDS | 22 | 22 | 14 | 4.67 | +2349 | +167.8 |
| MOVE TO CHARGE COMPUTED | 17 | 14 | 12 | 4.00 | +714 | +59.5 |
| GOAL WALK | 43 | 37 | 11 | 3.67 | +367 | +33.4 |
| PROMISE BY ITS OWN SUM | 33 | 33 | 11 | 3.67 | -1677 | -152.4 |
| SHOOTS FROM THE BEST SPOT | 17 | 17 | 11 | 3.67 | +38 | +3.5 |
| ARTILLERY RE-ROLL WEIGHED | 10 | 10 | 10 | 3.33 | +0 | +0.0 |
| MEETS IN TIME | 17 | 17 | 10 | 3.33 | +481 | +48.1 |
| SET UP BY THE SET | 15 | 15 | 10 | 3.33 | +848 | +84.8 |
| HARD STAY DROPPED | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| NEXT CHARGE BY LIST | 10 | 10 | 8 | 2.67 | +381 | +47.6 |
| MARCH OF THE TABLE | 7 | 7 | 7 | 2.33 | -964 | -137.7 |
| MOVE ORDER | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| QUARTER ODDS | 75 | 74 | 7 | 2.33 | +688 | +98.3 |
| ADVANCE LANE KEPT | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| COVER ONCE | 50 | 32 | 6 | 2.00 | +97 | +16.1 |
| FOLLOW UP WEIGHED | 6 | 6 | 6 | 2.00 | +1276 | +212.7 |
| MARCH BY THE SUM | 6 | 6 | 6 | 2.00 | +256 | +42.8 |
| REDIRECT FOR A FRIEND IN REACH | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| SHOTS AFTER THE MOVES | 25 | 25 | 6 | 2.00 | +0 | +0.0 |
| CANNON SIGHT KEPT | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| JOINT CHARGE NOW | 5 | 5 | 5 | 1.67 | -481 | -96.2 |
| LANE BY FIGURES | 5 | 5 | 5 | 1.67 | +148 | +29.7 |
| STRIKE BY THE ODDS | 5 | 5 | 5 | 1.67 | +106 | +21.1 |
| TIED UP BY THE SUM | 6 | 6 | 5 | 1.67 | +151 | +30.2 |
| WHOLE FIGHT DANGER | 27 | 26 | 5 | 1.67 | +1503 | +300.6 |
| WOUNDS ON THE RANKS | 30 | 29 | 5 | 1.67 | +161 | +32.2 |
| CASTING BLOCK | 8 | 8 | 4 | 1.33 | +25 | +6.1 |
| CHARGE LOSSES | 107 | 100 | 4 | 1.33 | +94 | +23.6 |
| CHARGE NOW FIRST | 13 | 13 | 4 | 1.33 | -147 | -36.7 |
| HOLDS AMBUSHERS | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| MARCH CHECK | 7 | 7 | 4 | 1.33 | +102 | +25.4 |
| MAX FOR POSITIONING | 23 | 20 | 4 | 1.33 | +139 | +34.9 |
| MISSILES IN THE MOVE | 37 | 25 | 4 | 1.33 | +157 | +39.2 |
| STAY WORTH | 149 | 138 | 4 | 1.33 | +3 | +0.8 |
| ASSAILMENT BY POINTS | 3 | 3 | 3 | 1.00 | +19 | +6.4 |
| CHAFF IN THE MOVE | 4 | 4 | 3 | 1.00 | +27 | +9.0 |
| COMBAT PIVOT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| IDLE COST | 31 | 16 | 3 | 1.00 | +63 | +21.1 |
| RISK BY ARC | 19 | 19 | 3 | 1.00 | +201 | +67.0 |
| SCOUT WAITS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| SEARCH SPOT | 3 | 3 | 3 | 1.00 | +61 | +20.4 |
| THE ROW IN ITS ORDER | 7 | 3 | 3 | 1.00 | +0 | +0.0 |
| EVASIVE BY THE ODDS | 2 | 2 | 2 | 0.67 | +48 | +23.9 |
| LONE WIZARD KEPT IN | 2 | 2 | 2 | 0.67 | +158 | +79.2 |
| MANOEUVRE | 10 | 10 | 2 | 0.67 | +18 | +8.9 |
| MISSILES NEXT TURN | 53 | 34 | 2 | 0.67 | +0 | +0.1 |
| ONE OBJECTIVE FORMULA | 26 | 18 | 2 | 0.67 | +201 | +100.7 |
| PROMISE SHOT AWAY | 2 | 2 | 2 | 0.67 | -532 | -265.8 |
| SHOTS IN THE MOVE | 84 | 69 | 2 | 0.67 | +72 | +36.0 |
| SUPPORT NARROWED | 3 | 3 | 2 | 0.67 | -57 | -28.6 |
| WHO GETS IN | 2 | 2 | 2 | 0.67 | +302 | +151.1 |
| AFTERMATH IN POINTS | 1 | 1 | 1 | 0.33 | +553 | +553.3 |
| BEST PRIZE | 1 | 1 | 1 | 0.33 | -41 | -41.0 |
| BOMBING RUN | 1 | 1 | 1 | 0.33 | +32 | +32.5 |
| CASTER AWAY FROM SCREEN | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CHAFF PASSED | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CHALLENGE BY POINTS | 1 | 1 | 1 | 0.33 | +75 | +74.6 |
| DEFENSIVE FLOOR | 1 | 1 | 1 | 0.33 | +5 | +5.3 |
| EDGE GIVE GROUND | 3 | 3 | 1 | 0.33 | +44 | +43.5 |
| FALLS SHORT | 69 | 55 | 1 | 0.33 | +0 | +0.0 |
| FEATURE BUFFS | 7 | 7 | 1 | 0.33 | +14 | +13.6 |
| FIGHT TO THE END | 7 | 7 | 1 | 0.33 | +54 | +53.6 |
| FIRE IN ORDER | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| HIS CHARGE DENIED | 2 | 2 | 1 | 0.33 | +82 | +82.1 |
| HIS MOVE AND SHOT | 33 | 32 | 1 | 0.33 | +0 | +0.0 |
| HUNT IN PAIRS | 2 | 2 | 1 | 0.33 | +60 | +60.2 |
| NEARER NOT NEEDED | 32 | 31 | 1 | 0.33 | +61 | +60.7 |
| ONE FIGHT FORMULA | 32 | 19 | 1 | 0.33 | +9 | +9.4 |
| OPENS UP | 1 | 1 | 1 | 0.33 | +20 | +19.9 |
| PATHS CROSS | 1 | 1 | 1 | 0.33 | +67 | +66.9 |
| PROMISE READS THE TABLE | 3 | 3 | 1 | 0.33 | -174 | -173.7 |
| REDIRECT COUNTER | 6 | 6 | 1 | 0.33 | +15 | +14.8 |
| RESERVE FALL BACK | 1 | 1 | 1 | 0.33 | +3 | +2.6 |
| SET CREDITED ONCE | 10 | 10 | 1 | 0.33 | +1 | +0.8 |
| SHOOTERS IN TWO RANKS | 1 | 1 | 1 | 0.33 | +1 | +1.0 |
| STANDS TO CAST | 1 | 1 | 1 | 0.33 | -57 | -57.5 |
| SURE REACH TOGETHER | 3 | 2 | 1 | 0.33 | +16 | +15.9 |
| SWIFTSTRIDE BY POINTS | 1 | 1 | 1 | 0.33 | -8 | -8.0 |
| WHO HITS BACK | 1 | 1 | 1 | 0.33 | +19 | +19.0 |
| BACKUP TARGETS | 2 | not checked | - | - | - | - |
| CANNON PLAN MISSED | 1 | 1 | 0 | 0.00 | - | - |
| CANNON PLANNED TARGET | 20 | 20 | 0 | 0.00 | - | - |
| CHAMPION KNOWS CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 33 | 33 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 2 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 4 | 4 | 0 | 0.00 | - | - |
| EXACT ROUND | 13 | 13 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 15 | 15 | 0 | 0.00 | - | - |
| FIGHT LIFT | 1 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 41 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 23 | 20 | 0 | 0.00 | - | - |
| FRIEND CHARGES FIRST | 1 | 1 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 4 | 4 | 0 | 0.00 | - | - |
| GIVES UP | 4 | 4 | 0 | 0.00 | - | - |
| GUN MASK | 6 | 6 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 20 | 14 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 82 | 76 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 31 | 28 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 31 | 30 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 8 | 7 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 27 | 27 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 6 | 6 | 0 | 0.00 | - | - |
| HIS TURN RUN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 69 | 69 | 0 | 0.00 | - | - |
| HONEST WORTH | 17 | 17 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 10 | 10 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 16 | 16 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 3 | trace | - | - | - | - |
| MARCH OVER CASTS | 13 | 13 | 0 | 0.00 | - | - |
| MISSILES ON ONE TARGET | 2 | not checked | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 1 | trace | - | - | - | - |
| NEXT OBJECTIVE NEARER | 2 | 2 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 15 | 15 | 0 | 0.00 | - | - |
| NO LATE CUT | 4 | 4 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 18 | 18 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 3 | not checked | - | - | - | - |
| ONE CHALLENGE TEST | 2 | 2 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 1 | not checked | - | - | - | - |
| OVERRUNS AWAY | 5 | 5 | 0 | 0.00 | - | - |
| PLAN RESULT | 216 | trace | - | - | - | - |
| PROMISE KNOWS THE FIGHT | 4 | 1 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 4 | 4 | 0 | 0.00 | - | - |
| REFUSING RETIRES | 1 | 1 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 1 | 1 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 4 | 4 | 0 | 0.00 | - | - |
| RUN DOWN | 17 | 17 | 0 | 0.00 | - | - |
| SCOUT SPOT | 2 | 2 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 3 | 3 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 65 | not checked | - | - | - | - |
| SHOT OR CHARGE | 3 | 3 | 0 | 0.00 | - | - |
| SPELL WORTH | 11 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 3 | 3 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 24 | 22 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 1 | 1 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 12 | 10 | 0 | 0.00 | - | - |
| STANDS STILL | 212 | 202 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 13 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 18 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 15 | not checked | - | - | - | - |
| THE TABLE BINDS | 215 | not checked | - | - | - | - |
| WAITS AGAIN | 3 | 2 | 0 | 0.00 | - | - |
| WHO FIGHTS | 3 | 3 | 0 | 0.00 | - | - |

### Off best figure: csame-bb45c30-p19

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 5.00 | 4.33 | 24.7 |
| PROMISE BY ITS OWN SUM | rule | 1.00 | 2.67 | 152.4 |
| ARMY TABLE | rule | 0.67 | 2.67 | 84.9 |
| MARCH OF THE TABLE | rule | 1.67 | 0.67 | 137.7 |
| RULE SWITCHED OFF | gate | 0.33 | 1.33 | 25.6 |
| CHARGE NOW FIRST | rule | 1.33 | - | 36.7 |
| JOINT CHARGE NOW | rule | 0.67 | - | 426.4 |
| PROMISE SHOT AWAY | rule | 0.67 | - | 265.8 |
| SUPPORT NARROWED | rule | 0.67 | - | 28.6 |
| BEST PRIZE | rule | 0.33 | - | 41.0 |
| PROMISE READS THE TABLE | rule | 0.33 | - | 173.7 |
| STANDS TO CAST | rule | - | 0.33 | 57.5 |
| SWIFTSTRIDE BY POINTS | rule | 0.33 | - | 8.0 |

### Plans: csame-bb45c30-p19

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 4.0 | 50% | 935 | 482 | 52% |
| Mine | move | 18.7 | 95% | 1360 | 0 | 0% |
| Mine | shoot | 12.0 | 33% | 1052 | 239 | 23% |
| Opponent | charge | 2.0 | 67% | 276 | 276 | 100% |
| Opponent | move | 28.0 | 92% | 2088 | 0 | 0% |
| Opponent | shoot | 6.7 | 20% | 716 | 190 | 27% |
| Opponent | support | 0.7 | 50% | 5 | 0 | 0% |

### Battle groups: csame-bb45c30-p19

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | REDIRECT COUNTER | 2.0 | 33% | 100% | 0% | - | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: csame-bb45c30-p19

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Character | 12 | 34 (12) | 34 | 0 | 41 | 8% | 2.7 | - | 2 (7) | 76 (5) | 31 (7) | 37 (5) |
| Mine | Fast Hammer | 4 | 30 (4) | 16 | 15 | 30 | 0% | 2.5 | 42 (2) | 26 (2) | - | 42 (3) | 9 (1) |
| Mine | Holder | 5 | 75 (5) | 0 | 75 | 0 | 40% | 4.7 | - | 93 (4) | 0 (1) | 123 (3) | 0 (2) |
| Mine | Shooter | 2 | 291 (2) | 59 | 232 | 50 | 0% | 1.0 | 272 (1) | 309 (1) | - | 291 (2) | - |
| Mine | War machine | 6 | 0 (6) | 0 | 0 | 33 | 0% | 1.3 | 0 (2) | 0 (2) | 0 (2) | 0 (1) | 0 (5) |
| Opponent | Chaff | 6 | 75 (6) | 0 | 75 | 41 | 17% | 3.4 | 44 (5) | 250 (1) | - | 106 (5) | 0 (1) |
| Opponent | Character | 7 | 70 (7) | 70 | 0 | 14 | 29% | 1.6 | 72 (1) | 70 (6) | - | 53 (5) | 97 (2) |
| Opponent | Clean-up | 3 | 0 (3) | 0 | 0 | 36 | 33% | 1.5 | - | 0 (3) | - | 0 (2) | 0 (1) |
| Opponent | Early | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | - | 0 (1) | 0 (1) | - |
| Opponent | Fast Hammer | 4 | 27 (4) | 11 | 16 | 25 | 25% | 1.3 | - | 30 (3) | 0 (1) | 30 (3) | 0 (1) |
| Opponent | Hammer | 8 | 34 (8) | 21 | 13 | 24 | 25% | 2.0 | 0 (2) | 36 (2) | 52 (4) | 53 (5) | 0 (3) |
| Opponent | Holder | 1 | 108 (1) | 0 | 108 | 0 | 0% | 3.0 | - | 108 (1) | - | 108 (1) | - |
| Opponent | Shooter | 2 | 0 (2) | 0 | 0 | 56 | 0% | 1.0 | 0 (1) | 0 (1) | - | 0 (2) | - |
| Opponent | Wizard | 1 | 0 (1) | 0 | 0 | 0 | 0% | 3.0 | - | 0 (1) | - | 0 (1) | - |

### Charged fights: csame-bb45c30-p19

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Grand Cathay | 3 | 169 | 204 | 3.0 | 1.3 | 68 | 65 | +3 | 5 of 9 | 6 of 9 | +144 | -67 |
| Opponent | Ogre Kingdoms | 1 | 330 | 150 | 4.0 | 1.0 | 38 | 8 | +29 | 2 of 4 | 1 of 4 | - | +29 |
| Opponent | Warriors of Chaos | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Wood Elf Realms | 1 | 0 | 752 | 5.0 | 1.0 | 150 | 25 | +125 | 3 of 5 | 4 of 5 | - | +125 |
| **Opponent** | all armies | 3 | 110 | 301 | 3.0 | 1.0 | 100 | 18 | +83 | 5 of 9 | 5 of 9 | - | +83 |

### Effective charges: csame-bb45c30-p19

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Grand Cathay | 9 | 4 (net -146) | 0 | 0 | 1 (net +0) | 2 (net +236) | 2 (net +70) | 0 | 0% (0 of 9) |
| Opponent | Ogre Kingdoms | 4 | 0 | 1 (net +0) | 0 | 0 | 0 | 1 (net +150) | 2 | 0% (0 of 2) |
| Opponent | Wood Elf Realms | 5 | 1 (net +0) | 1 (net -125) | 0 | 1 (net +0) | 1 (net +383) | 1 (net +369) | 0 | 0% (0 of 5) |

### Charged fights, damage counted: csame-bb45c30-p19

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 4 | 470 | 494 | -146 | 30 | 146 | -116 | -24.6 |
| Mine | 76-89% | 1 | 369 | 234 | +0 | 0 | 0 | +0 | +0.0 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 192 | 132 | +70 | 78 | 0 | +78 | +41.0 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 2 | 410 | 100 | +236 | 236 | 0 | +236 | +57.8 |
| Mine | All fights | 9 | 384 | 297 | +3 | 83 | 65 | +18 | +4.8 |
| Opponent | Long shot (under 50%) | 1 | 102 | 358 | +0 | 0 | 0 | +0 | +0.0 |
| Opponent | 50-54% | 2 | 82 | 160 | -62 | 24 | 139 | -115 | -139.5 |
| Opponent | 76-89% | 1 | 499 | 369 | +0 | 0 | 0 | +0 | +0.0 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 366 | 192 | +260 | 314 | 8 | +306 | +83.6 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 499 | 150 | +383 | 383 | 0 | +383 | +76.8 |
| Opponent | No odds | 2 | 34 | 296 | -17 | 12 | 17 | -5 | -14.9 |
| Opponent | All fights | 9 | 230 | 241 | +83 | 120 | 36 | +84 | +36.6 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| csame-bb45c30-p19 | move | 22 | 4 (18%) | 4 (18%) | 3 (14%) | 15 (68%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Clockwork Compass | Mine | L1228 |
| Elixir of Power | Mine | L1118, L1135 |
| Fistful of Laurels | Opponent | L1118 |
| Ring of Doom | Mine | L1118, L1135, L1228 |
| Ring of Jet | Mine | L1118, L1135, L1228 |

# Doctrine scorecard: csame-bb45c30-p2

### Scorecard: csame-bb45c30-p2

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0218 | 2 | 1 | Mine | - | - | 6 | 1 | 7 | 0 | 0 | 0 | 255 |
| L0218 | 2 | 1 | Opponent | - | - | - | 1 | 4 | 0 | 0 | 0 | 74 |
| L0235 | 1 | 1 | Mine | no | 2 | 2 | 1 | 3 | 0 | 0 | 0 | 0 |
| L0235 | 1 | 1 | Opponent | no | 0 | 2 | 1 | 4 | 0 | 0 | 0 | 125 |
| L0319 | 1 | 1 | Mine | no | 7 | - | 0 | 0 | 0 | 0 | 0 | 420 |
| L0319 | 1 | 1 | Opponent | no | 2 | 3 | 4 | 1 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 0% | 4.5 | 4.0 | 0.7 | 3.3 | 0.0 | 0.0 | 0.0 | 225.0 |
| **Average** | | | Opponent | 0% | 1.0 | 2.5 | 2.0 | 3.0 | 0.0 | 0.0 | 0.0 | 66.3 |

### KPIs: csame-bb45c30-p2

Rules off - Mine only: NO OLD ONE-MOVE GUESS; both sides: ONE RUN A PLAN.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 27% (3 of 11) | 0% (0 of 15) | 12% (3 of 26) |
| Winner chose to follow up after the loser gave ground |  | 0% (0 of 1); on the table 100% | 100% (2 of 2); on the table 100% | 67% (2 of 3); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | 50% (1 of 2); on the table 50% | - | 50% (1 of 2); on the table 50% |
| Winner chose to pursue after the loser fled |  | 0% (0 of 1); on the table 0% | 100% (1 of 1); on the table 100% | 50% (1 of 2); on the table 50% |
| Winner chose to follow up or pursue (all three) |  | 25% (1 of 4); on the table 50% | 100% (3 of 3); on the table 100% | 57% (4 of 7); on the table 71% |
| Magic missiles tried each own turn | 50%+ | 43% (18 of 42) | 25% (6 of 24) | 36% (24 of 66) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 43% (18 of 42) | 25% (6 of 24) | 36% (24 of 66) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 67% (8 of 12) | - | 67% (8 of 12) |
| Points that never fought | lower | 53% (3087 of 5797) | 50% (3026 of 6000) | 52% (6113 of 11797) |
|   infantry points that never fought | lower | 45% (613 of 1374) | 78% (657 of 842) | 57% (1270 of 2216) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 60% (12 of 20) | 63% (17 of 27) | 62% (29 of 47) |
| Bound items with a magic missile used (at least once a game) |  | 100% (4 of 4); 6.3 uses a game | 50% (1 of 2); 1.3 uses a game | 83% (5 of 6); 3.8 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 40% (2 of 5); 0.7 uses a game | 100% (1 of 1); 0.3 uses a game | 50% (3 of 6); 0.5 uses a game |
|   their share of the points of units over 100 pts | lower | 48% (1951 of 4039) | 59% (3256 of 5515) | 55% (5207 of 9554) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 7.3 (92%) | 0.0 (0%) | 7.3 (52%) |
| MARCHED: its unit marched | 0.7 (8%) | 0.0 (0%) | 0.7 (5%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 4.7 (78%) | 4.7 (33%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 1.3 (22%) | 1.3 (10%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Hexes | Movement spells | Magic missiles | Assailments |
| --- | --- | --- | --- | --- |
| tried | 1.3 | 4.3 | 8.0 | 0.7 |
| not cast | 2.7 | 5.7 | 14.0 | 27.3 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 4.3 (16%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.7 (25%) | 0.0 (0%) | 7.3 (52%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.7 (5%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 2.0 (75%) | 4.0 (71%) | 4.7 (33%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 1.3 (10%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 0.0 (0%) | 1.7 (29%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 23.0 (84%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 2.7 a game | 1.7 a game | 2.2 a game |
| stood (cast and not dispelled) | 62% (5 of 8) | 60% (3 of 5) | 62% (8 of 13) |
| the unit moved after it | 60% (3 of 5) | 0% (0 of 3) | 38% (3 of 8) |
| it charged on its next turn | 0% (0 of 5) | 0% (0 of 3) | 0% (0 of 8) |
| the enemy charged it first | 0% (0 of 5) | 0% (0 of 3) | 0% (0 of 8) |
| it fought by the end of its next turn | 0% (0 of 5) | 0% (0 of 3) | 0% (0 of 8) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 5) | 33% (1 of 3) | 12% (1 of 8) |
| none of these (no charge, no fight, no charge escaped) | 100% (5 of 5) | 67% (2 of 3) | 88% (7 of 8) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 64% (23 of 36) | 49% (39 of 79) | 54% (62 of 115) |
|   cavalry | - | 61% (11 of 18) | 61% (11 of 18) |
|   character | - | 55% (6 of 11) | 55% (6 of 11) |
|   chariot | 50% (6 of 12) | 58% (7 of 12) | 54% (13 of 24) |
|   infantry | - | 23% (6 of 26) | 23% (6 of 26) |
|   monster | - | 75% (9 of 12) | 75% (9 of 12) |
|   war machine | 71% (17 of 24) | - | 71% (17 of 24) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.3 (31%) | 2.7 (20%) | 4.0 (23%) |
| CHARGED: it charged | 0.0 (0%) | 0.7 (5%) | 0.7 (4%) |
| IN COMBAT: it fought this turn or the last | 0.7 (15%) | 0.0 (0%) | 0.7 (4%) |
| MOVED: a war machine that moved | 0.7 (15%) | 0.0 (0%) | 0.7 (4%) |
| NO TARGET IN RANGE | 0.0 (0%) | 5.7 (42%) | 5.7 (32%) |
| ONLY IN COMBAT: the only targets were in combat | 0.0 (0%) | 0.3 (2%) | 0.3 (2%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.7 (38%) | 1.3 (10%) | 3.0 (17%) |
| SHELTERED: the target was sheltered | 0.0 (0%) | 1.0 (8%) | 1.0 (6%) |
| OTHER BAR | 0.0 (0%) | 1.7 (12%) | 1.7 (9%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 6.3 | 1.7 | 79% | 2.4 pts | 15 pts |
| character | 2.0 | 0.3 | 83% | 4.7 pts | 9 pts |
| chariot | 4.3 | 5.3 | 46% | 27.4 pts | 119 pts |
| infantry | 2.0 | 0.0 | 100% | 0.0 pts | 0 pts |
| monster | 3.0 | 2.3 | 56% | 12.1 pts | 36 pts |
| war machine | 5.7 | 3.3 | 71% | 6.8 pts | 38 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 1.0 | 3.3 | 2.2 |
| Charges that made contact a game | 0.7 | 3.0 | 1.8 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.00 declared, 0.00 contact (2 units) | - | 0.00 declared, 0.00 contact (2 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | - | - |
|   per unit a game, the other units (no war machines, no joined characters) | 0.12 declared, 0.08 contact (25 units) | 0.34 declared, 0.31 contact (29 units) | 0.24 declared, 0.20 contact (54 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 67% (2 of 3) | 100% (1 of 1) | - | 75% (3 of 4) |
| Character in a unit | 83% (5 of 6) | 43% (3 of 7) | - | 62% (8 of 13) |
| Character on its own | 100% (2 of 2) | 100% (1 of 1) | 50% (1 of 2) | 80% (4 of 5) |
| Chariot | 50% (1 of 2) | 0% (0 of 2) | - | 25% (1 of 4) |
| Infantry | 60% (3 of 5) | 0% (0 of 3) | - | 38% (3 of 8) |
| Monster | 100% (2 of 2) | 0% (0 of 1) | - | 67% (2 of 3) |
| Monstrous | 100% (2 of 2) | 50% (2 of 4) | - | 67% (4 of 6) |
| War Machines | 100% (3 of 3) | 100% (1 of 1) | - | 100% (4 of 4) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 2 | 0% (0 of 2); on the table 50% | 60% (18 of 30) | 59% | 67% (8 of 12) | 100% (4 of 4); 9.5 uses a game | 0.0 uses a game | 50% (2 of 4); 1.0 uses a game |
| Chaos Dwarfs | 1 | 50% (1 of 2); on the table 50% | 0% (0 of 12) | 43% | 50% (4 of 8) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Ogre Kingdoms | 1 | - | 0% (0 of 6) | 68% | 43% (3 of 7) | 100% (1 of 1); 4.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 1 | 100% (2 of 2); on the table 100% | 0% (0 of 12) | 17% | 75% (6 of 8) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Wood Elf Realms | 1 | 100% (1 of 1); on the table 100% | 100% (6 of 6) | 66% | 67% (8 of 12) | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (csame-bb45c30-p2, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 22% (2) | 50% (1) | 27% (3) |
| ...free all their last turn and able to turn (per game) | 0.67 | 0.00 | 0.67 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.33 | 0.33 |
| ...with the charger already in that arc before they moved (per game) | 0.33 | 0.00 | 0.33 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.33 | 0.00 | 0.33 |

### Quality by phase: csame-bb45c30-p2

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.3 | 1.3 |
| Strategy | Charge objectives carried out (made contact) | 67% (2 of 3) | 100% (5 of 5) |
| Strategy | Shoot objectives carried out (shot that target) | 45% (13 of 29) | 25% (2 of 8) |
| Strategy | Hexes on a unit its side charged or shot that turn | - | 75% (3 of 4) |
| Strategy | Joined characters whose unit fought | 55% (6 of 11) | 100% (4 of 4) |
| Strategy | Lone characters that fought | 0% (0 of 4) | 60% (3 of 5) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 3.3 | 3.0 |
| Movement | Points that never moved of their own | 225.0 | 66.3 |
| Movement | Fights charged into per game | 0.7 | 3.0 |
| Movement | Charges with odds: long shots (under 50%) | 1 of 2, net -52 | 1 of 4, net +0 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 2 | 1 of 4, net +85 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 2 | 0 of 4 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 of 2, net -52 | 0 of 4 |
| Shooting | Shots by shooting units (incl. breath weapons) | 2.0 | 13.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 83% (5 of 6) | 18% (7 of 40) |
| Shooting | Points destroyed by shooting units | 34.7 | 28.3 |
| Shooting | War machine shots | 5.7 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 47% (8 of 17) | - |
| Shooting | Points destroyed by war machines | 0.0 | 28.3 |
| Magic | Magic missiles cast | 3.7 | 1.7 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 0% (0 of 11) | 0% (0 of 5) |
| Magic | Wounds caused by magic missiles | 15.0 | 3.7 |
| Magic | Wounds caused by other spells | 0.3 | - |
| Magic | Points destroyed by magic (all spells) | 83.3 | 17.3 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.0 / 0.0 / 0.3 / 0.0 | 0.0 / 1.3 / 0.3 / 0.0 |
| Combat | Points destroyed in combat | 135.0 | 138.0 |
| Combat | Points run down | 0.0 | 28.3 |
| Combat | Net points per charged fight, damage counted | -0 | +8 |
| Combat | Net per 100 charger points, damage counted | -0.9 | +4.5 |
| Combat | First round won (charged fights) | 50% | 67% |
| Combat | Net points per charged fight | -52 | -1 |
| Combat | Net points per supported fight / lone fight | - / -52 | - / -1 |
| Combat | Charged fights on a top-3 enemy unit | 1 of 2 | 6 of 9 |
| Game | Points lost | 250.3 | 269.3 |
| Game | VP from objectives | 743.3 | 870.0 |
| Game | Lone holders (player turns) | 4.5 | 1.0 |

- Mine won / drew / lost: 1 / 2 / 0 of 3 ended games (of 3); mean margin (Mine - Opponent) +56 VP
- The side that went first won 1 of 1 games with a winner
- Points traded per game (both sides' losses): 520
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: csame-bb45c30-p2

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | - | - | - | - | 1.0 | +0.0 | 0.0 | 41.7 |
| AFTERMATH IN POINTS | 0.3 | +4.1 | 0.0 | 17.3 | - | - | - | - |
| AFTERMATH WITH FRIENDS | - | - | - | - | 0.3 | +2.2 | 0.0 | 0.0 |
| ARMY TABLE | 13.7 | +161.9 | 0.0 | 97.7 | 24.7 | -1.2 | 0.0 | 115.0 |
| ARTILLERY RE-ROLL WEIGHED | 3.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| BACKUP TARGETS | - | - | - | - | 0.3 | +0.5 | 0.0 | 0.0 |
| BLOWS WHERE AIMED | 0.3 | +0.8 | 0.0 | 17.3 | - | - | - | - |
| CANNON PLAN MISSED | 1.0 | +0.0 | 55.0 | 0.0 | - | - | - | - |
| CANNON PLANNED TARGET | 5.3 | +253.9 | 165.0 | 0.0 | - | - | - | - |
| CANNON SIGHT KEPT | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CAST JOB | 4.0 | +61.0 | 0.0 | 0.0 | - | - | - | - |
| CASTER AWAY FROM SCREEN | 1.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | - | - | - | - | 1.7 | +51.0 | 206.7 | 0.0 |
| CASTS AFTER FRIENDS | 1.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | 2.0 | +70.9 | 0.0 | 115.0 | 1.0 | +4.5 | 0.0 | 0.0 |
| CHAFF PASSED | 0.3 | -6.8 | 0.0 | 0.0 | 1.0 | -0.3 | 0.0 | 0.0 |
| CHARGE LOSSES | 11.7 | -244.6 | 0.0 | 120.7 | 8.3 | -185.3 | 0.0 | 41.7 |
| CHARGE NOW FIRST | 1.0 | +0.0 | 0.0 | 17.3 | 1.3 | +0.0 | 56.7 | 0.0 |
| CLOSES ON WHAT IT BEATS | 11.0 | +0.0 | 0.0 | 0.0 | 10.7 | +0.0 | 0.0 | 55.0 |
| CONVEYANCE SEARCH | 2.0 | +248.9 | 0.0 | 0.0 | 1.7 | +130.5 | 0.0 | 0.0 |
| COVER ONCE | 2.7 | -128.5 | 0.0 | 17.3 | 4.0 | -124.5 | 0.0 | 0.0 |
| DEFENSIVE FLOOR | - | - | - | - | 0.3 | +12.2 | 28.3 | 0.0 |
| DENIED BY THE FIGHT | - | - | - | - | 0.3 | -0.6 | 103.3 | 0.0 |
| DEPLOY BY FIGURES | 9.7 | +22.3 | 0.0 | 28.3 | 8.3 | +76.7 | 0.0 | 41.7 |
| DUEL STOPS AT THE KILL | - | - | - | - | 0.3 | -2.3 | 0.0 | 0.0 |
| ELIXIR WORTH | - | - | - | - | 0.3 | +13.2 | 0.0 | 0.0 |
| ENGINEER BY LORE | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| EXACT ROUND | 0.7 | -0.4 | 0.0 | 34.7 | 1.7 | +5.5 | 160.0 | 0.0 |
| FALL BACK GOOD ORDER | 1.0 | +0.2 | 0.0 | 52.0 | 1.7 | +3.6 | 131.7 | 0.0 |
| FALLS SHORT | 23.7 | +290.2 | 0.0 | 80.3 | 3.7 | +59.5 | 0.0 | 0.0 |
| FEATURE BUFFS | 10.7 | +432.6 | 0.0 | 0.0 | 1.7 | +26.6 | 0.0 | 0.0 |
| FIGHT TO THE END | 0.3 | -0.1 | 0.0 | 17.3 | 1.0 | +9.9 | 28.3 | 0.0 |
| FIRE IN ORDER | - | - | - | - | 0.3 | +0.0 | 10.0 | 0.0 |
| FIVE ACTION | 95.7 | +7950.9 | 256.7 | 648.0 | 93.0 | +7354.5 | 592.3 | 300.7 |
| FLANK NOT WEIGHED | 4.7 | +0.0 | 0.0 | 131.7 | 4.3 | +0.0 | 0.0 | 0.0 |
| FOLLOW UP WEIGHED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| FOUR ROUNDS | 1.0 | +50.5 | 0.0 | 52.0 | 2.0 | +162.4 | 160.0 | 0.0 |
| FREED FROM HIS FIGHT | 0.3 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 0.3 | -1.0 | 0.0 | 0.0 | 0.3 | -1.6 | 0.0 | 0.0 |
| GOAL WALK | 6.7 | +570.7 | 0.0 | 56.7 | 12.3 | +977.0 | 0.0 | 0.0 |
| GUN FIGURES | 1.3 | +1.9 | 0.0 | 103.3 | 2.0 | +38.5 | 28.3 | 0.0 |
| HARD STAY DROPPED | 3.7 | +0.0 | 0.0 | 17.3 | 2.0 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | - | - | - | - | 3.0 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 6.0 | +0.0 | 0.0 | 120.7 | 1.0 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE DENIED | - | - | - | - | 0.3 | +96.8 | 103.3 | 0.0 |
| HIS CHARGE LIST | 6.7 | +0.0 | 0.0 | 103.3 | 2.3 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 1.3 | +0.0 | 0.0 | 17.3 | 2.3 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 5.3 | -101.4 | 0.0 | 85.0 | 1.3 | -27.5 | 0.0 | 0.0 |
| HIS MOVE AS HE DECIDES | 46.3 | +12.3 | 271.0 | 0.0 | - | - | - | - |
| HIS MOVE WHY | - | - | - | - | 21.0 | +0.0 | 0.0 | 22.7 |
| HIS ONE MOVE | 15.3 | +19.6 | 0.0 | 17.3 | - | - | - | - |
| HIS ONE QUARTER | 4.7 | +0.0 | 0.0 | 206.7 | 4.0 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | - | - | - | - | 4.0 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVE | - | - | - | - | 21.7 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 59.0 | +1802.8 | 0.0 | 389.3 | 61.3 | +2987.2 | 0.0 | 300.7 |
| HIS SHOTS BY HIS RUN | 51.7 | +979.8 | 0.0 | 286.0 | 38.3 | +715.6 | 0.0 | 264.0 |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 33.0 | +0.0 | 0.0 | 0.0 | 22.3 | +0.0 | 0.0 | 73.3 |
| HOLDER ASSIGNMENT | 15.3 | +1613.7 | 0.0 | 0.0 | 14.3 | +1451.4 | 0.0 | 36.7 |
| HOLDS AMBUSHERS | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 0.7 | -1.0 | 0.0 | 34.7 | 1.7 | -55.8 | 56.7 | 0.0 |
| IDLE COST | 15.3 | -88.7 | 0.0 | 63.0 | 3.3 | -64.9 | 0.0 | 18.3 |
| KEEP FALLS | 0.3 | +3.3 | 0.0 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 4.0 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 73.3 |
| LANE BY FIGURES | - | - | - | - | 0.7 | +17.7 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| LEGAL CHARGES ONLY | 1.0 | +0.0 | 0.0 | 17.3 | 3.3 | +0.0 | 52.0 | 0.0 |
| LONE WIZARD KEPT IN | 1.3 | +116.7 | 0.0 | 0.0 | - | - | - | - |
| LOST AFTER ESCAPE | 0.7 | -0.2 | 0.0 | 34.7 | 2.0 | -1.8 | 160.0 | 0.0 |
| MANOEUVRE | 1.7 | +19.5 | 0.0 | 0.0 | 2.3 | -6.3 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MARCH BY THE SUM | 0.7 | +75.2 | 0.0 | 0.0 | 0.3 | +15.6 | 0.0 | 0.0 |
| MARCH CHECK | 0.7 | +22.1 | 0.0 | 0.0 | 0.7 | +24.5 | 0.0 | 0.0 |
| MARCH OF THE TABLE | 0.3 | +0.3 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 0.7 | -15.9 | 0.0 | 0.0 | - | - | - | - |
| MARCH WHEELS ONLY | 2.7 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 73.3 |
| MAX FOR POSITIONING | 1.3 | +20.6 | 0.0 | 56.7 | 0.7 | +7.0 | 0.0 | 0.0 |
| MEETS IN TIME | 3.3 | +262.7 | 0.0 | 0.0 | 3.0 | +302.4 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 6.7 | +334.9 | 0.0 | 0.0 | 4.7 | +102.3 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 6.7 | +223.1 | 0.0 | 0.0 | 4.0 | +55.9 | 0.0 | 0.0 |
| MISSILES ON ONE TARGET | 1.0 | -76.4 | 0.0 | 0.0 | - | - | - | - |
| MOVE ORDER | 2.0 | +0.0 | 17.3 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| MOVE SPELL OUT OF RANGE | - | - | - | - | 1.3 | -75.6 | 0.0 | 0.0 |
| MOVE SPELL SPOT | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 2.7 | +699.0 | 0.0 | 224.0 | 3.3 | +95.6 | 0.0 | 0.0 |
| MOVES UNITS SPELL | 0.7 | +36.7 | 0.0 | 0.0 | 0.3 | +1.4 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 3.7 | +182.0 | 0.0 | 0.0 | 10.7 | +456.0 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 1.3 | +350.0 | 0.0 | 17.3 | 1.7 | +61.2 | 17.3 | 0.0 |
| NO DOUBLE ROUNDS | 1.0 | -28.1 | 0.0 | 52.0 | 1.3 | -33.4 | 56.7 | 0.0 |
| NO LATE CUT | 0.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 73.3 |
| NO OLD ONE-MOVE GUESS | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | 0.3 | +0.3 | 0.0 | 10.0 | - | - | - | - |
| OFF BEST | 2.7 | -794.8 | 0.0 | 0.0 | 3.7 | -66.1 | 28.3 | 0.0 |
| OGRE LOADER SECOND SHOT | 2.0 | +0.5 | 0.0 | 0.0 | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ONE FIGHT FORMULA | 3.3 | -40.7 | 0.0 | 205.7 | 4.3 | -66.6 | 0.0 | 0.0 |
| ONE JOINT FIGURE | - | - | - | - | 0.3 | +19.6 | 0.0 | 0.0 |
| ONE OBJECTIVE FORMULA | 10.0 | +41.5 | 0.0 | 0.0 | 5.0 | +67.0 | 0.0 | 0.0 |
| ONE ROUTE | 2.7 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 73.3 |
| OPENS A LANE | 0.3 | +1.1 | 0.0 | 0.0 | - | - | - | - |
| OVERRUNS AWAY | 0.3 | +0.2 | 0.0 | 17.3 | - | - | - | - |
| PATHS CROSS | - | - | - | - | 0.3 | -19.8 | 0.0 | 0.0 |
| PLAN RESULT | 43.3 | +135.5 | 128.3 | 398.3 | 42.0 | +159.7 | 28.3 | 282.3 |
| PROMISE BY ITS OWN SUM | 4.7 | -992.3 | 0.0 | 224.0 | 6.3 | -134.2 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | 0.7 | +0.0 | 0.0 | 206.7 | 0.7 | -4.4 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | - | - | - | - | 0.3 | -1.6 | 0.0 | 0.0 |
| PROMISE SHOT AWAY | 0.3 | -0.5 | 0.0 | 0.0 | - | - | - | - |
| PURSUES BIG PREY | 0.3 | -53.8 | 0.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | 17.0 | +1569.2 | 0.0 | 413.3 | 15.3 | +1990.7 | 310.0 | 36.7 |
| RANDOM MOVE BY FIGURES | 4.0 | +109.5 | 0.0 | 0.0 | - | - | - | - |
| REAL GROUND | 2.7 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 73.3 |
| REDIRECT BY WHAT IT STOPS | 0.7 | +27.5 | 0.0 | 56.7 | - | - | - | - |
| REDIRECT COUNTER | 3.0 | +82.2 | 0.0 | 66.7 | 2.0 | -54.2 | 0.0 | 0.0 |
| REDIRECT FOR A FRIEND IN REACH | 4.7 | +34.4 | 0.0 | 85.0 | 3.3 | +0.0 | 0.0 | 59.3 |
| REFORMS TO MEET IT | 0.7 | -68.6 | 0.0 | 17.3 | 1.0 | -21.0 | 0.0 | 0.0 |
| REFUSING RETIRES | - | - | - | - | 0.3 | +0.0 | 0.0 | 36.7 |
| RESTRAINS TO SHOOT | 0.3 | +36.7 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | 0.3 | +0.7 | 0.0 | 17.3 | 1.7 | -9.6 | 56.7 | 0.0 |
| RISK ON THE WAY | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| ROUNDS AFTER TERROR | - | - | - | - | 0.3 | -19.2 | 0.0 | 0.0 |
| RUN DOWN | 0.7 | -0.7 | 0.0 | 34.7 | 1.0 | -4.6 | 56.7 | 0.0 |
| SAME TERRAIN AS THE BOARD | 0.3 | +0.0 | 0.0 | 28.3 | - | - | - | - |
| SCOUT SPOT | - | - | - | - | 0.7 | -0.1 | 0.0 | 0.0 |
| SCOUT WAITS | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 1.3 | -22.0 | 0.0 | 20.0 | 1.0 | -49.6 | 0.0 | 0.0 |
| SEARCH SPOT | 1.3 | +22.5 | 0.0 | 103.3 | - | - | - | - |
| SECOND LOOK | - | - | - | - | 0.3 | +4.6 | 28.3 | 0.0 |
| SET CREDITED ONCE | - | - | - | - | 0.3 | -1.6 | 0.0 | 0.0 |
| SET UP BY THE SET | - | - | - | - | 1.0 | +5.0 | 0.0 | 0.0 |
| SET-UP ANY TARGET | 0.3 | +59.5 | 0.0 | 0.0 | 0.3 | +26.5 | 0.0 | 0.0 |
| SHOOTER COUNTED ONCE | 1.3 | -5.8 | 0.0 | 20.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | - | - | - | - | 0.3 | +0.3 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 9.7 | +0.0 | 0.0 | 131.7 | 4.7 | +0.0 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 4.0 | +395.5 | 0.0 | 103.3 | 1.3 | +20.7 | 0.0 | 0.0 |
| SHOT OR CHARGE | - | - | - | - | 0.3 | -4.5 | 103.3 | 0.0 |
| SHOT REPLANNED | 0.3 | +0.0 | 18.3 | 0.0 | - | - | - | - |
| SHOT RISK POINTS | 43.7 | +587.0 | 0.0 | 286.0 | 43.3 | +247.8 | 0.0 | 227.3 |
| SHOTS AFTER THE MOVES | 2.0 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 8.0 | +552.7 | 0.0 | 206.7 | 16.7 | +374.7 | 0.0 | 36.7 |
| SPELL SETS UP CHARGE | 0.3 | +59.5 | 0.0 | 0.0 | 0.3 | +26.5 | 0.0 | 0.0 |
| SPELLS IN THE FIGHT | 0.3 | -7.2 | 0.0 | 17.3 | - | - | - | - |
| SPOT AS THE GAME MOVES | 7.3 | +0.0 | 0.0 | 74.0 | 7.0 | +0.0 | 0.0 | 36.7 |
| STAND AND SHOOT | 0.3 | -3.7 | 0.0 | 17.3 | - | - | - | - |
| STANDS FOR A REASON | 0.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 47.7 | +0.0 | 256.7 | 155.3 | 37.0 | +0.0 | 432.3 | 117.3 |
| STAY WORTH | 18.7 | +24.3 | 256.7 | 103.3 | 17.3 | +126.2 | 159.0 | 36.7 |
| STRIKE BY THE ODDS | - | - | - | - | 1.0 | +12.2 | 0.0 | 48.0 |
| STUCK PIVOT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SUPPORT ADDS | 1.7 | +49.5 | 0.0 | 0.0 | 2.7 | +586.0 | 0.0 | 0.0 |
| SUPPORT NARROWED | 0.3 | +0.0 | 0.0 | 17.3 | 1.0 | +0.0 | 56.7 | 0.0 |
| SUPPORT WORKED OUT | 1.7 | +49.5 | 0.0 | 0.0 | 2.7 | +586.0 | 0.0 | 0.0 |
| SURE REACH TOGETHER | - | - | - | - | 1.0 | +7.4 | 0.0 | 11.3 |
| SWIFTSTRIDE BY POINTS | - | - | - | - | 0.3 | +0.1 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| THE PROMISED MOVE | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 6.7 | +0.0 | 0.0 | 56.7 | 2.3 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 2.7 | +0.0 | 0.0 | 0.0 | 4.7 | +0.0 | 0.0 | 36.7 |
| THE STEP BACK IS MADE | 1.3 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 36.7 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 42.7 | +0.0 | 0.0 | 326.3 | 44.3 | +0.0 | 0.0 | 108.0 |
| TIED UP BY THE SUM | 0.3 | +7.9 | 0.0 | 17.3 | - | - | - | - |
| TIME ON OUR SIDE | 8.7 | +135.9 | 0.0 | 0.0 | 56.7 | +504.6 | 0.0 | 207.0 |
| WAITS AGAIN | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| WAR ENGINE JOBS | - | - | - | - | 1.3 | +0.0 | 56.7 | 0.0 |
| WHO FIGHTS | 0.7 | +0.4 | 0.0 | 34.7 | 1.0 | -4.9 | 28.3 | 0.0 |
| WHOLE FIGHT DANGER | 0.7 | -33.3 | 0.0 | 0.0 | - | - | - | - |
| WOUNDS ON THE RANKS | 3.0 | +296.8 | 0.0 | 0.0 | 2.3 | +241.3 | 0.0 | 0.0 |

### Rule changes: csame-bb45c30-p2

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS MOVE AS HE DECIDES | 139 | 139 | 102 | 34.00 | +0 | +0.0 |
| SHOT RISK POINTS | 261 | 258 | 101 | 33.67 | +1749 | +17.3 |
| HIS SHOT LIST | 361 | 358 | 97 | 32.33 | +1014 | +10.5 |
| HIS SHOTS BY HIS RUN | 270 | 265 | 93 | 31.00 | +1234 | +13.3 |
| HOLDER ASSIGNMENT | 89 | 89 | 83 | 27.67 | +4214 | +50.8 |
| ARMY TABLE | 115 | 115 | 75 | 25.00 | +344 | +4.6 |
| DEPLOY BY FIGURES | 54 | 54 | 36 | 12.00 | +491 | +13.6 |
| THE TABLE AGAIN | 36 | 36 | 30 | 10.00 | +0 | +0.0 |
| HIS MOVE WHY | 63 | 63 | 25 | 8.33 | +0 | +0.0 |
| TIME ON OUR SIDE | 196 | 171 | 25 | 8.33 | +48 | +1.9 |
| REDIRECT FOR A FRIEND IN REACH | 24 | 24 | 24 | 8.00 | +0 | +0.0 |
| FIVE ACTION | 566 | 555 | 22 | 7.33 | +1041 | +47.3 |
| OFF BEST | 19 | 19 | 19 | 6.33 | -2582 | -135.9 |
| HARD STAY DROPPED | 17 | 17 | 17 | 5.67 | +0 | +0.0 |
| HIS ONE MOVE | 46 | 46 | 17 | 5.67 | +0 | +0.0 |
| GOAL WALK | 57 | 54 | 15 | 5.00 | +899 | +60.0 |
| SHOOTS FROM THE BEST SPOT | 16 | 16 | 15 | 5.00 | +349 | +23.3 |
| MOVE ORDER | 14 | 14 | 14 | 4.67 | +0 | +0.0 |
| LEGAL CHARGES ONLY | 13 | 13 | 13 | 4.33 | +0 | +0.0 |
| MEETS IN TIME | 19 | 19 | 13 | 4.33 | +889 | +68.4 |
| PROMISE BY ITS OWN SUM | 33 | 33 | 13 | 4.33 | -3379 | -260.0 |
| QUARTER ODDS | 97 | 96 | 13 | 4.33 | +1132 | +87.1 |
| MOVE TO CHARGE COMPUTED | 18 | 17 | 11 | 3.67 | +1817 | +165.2 |
| STAY WORTH | 108 | 89 | 11 | 3.67 | +90 | +8.2 |
| ARTILLERY RE-ROLL WEIGHED | 10 | 10 | 10 | 3.33 | +0 | +0.0 |
| CAST JOB | 12 | 12 | 10 | 3.33 | +17 | +1.7 |
| RANDOM MOVE BY FIGURES | 12 | 12 | 8 | 2.67 | +328 | +41.1 |
| CHAFF IN THE MOVE | 9 | 9 | 7 | 2.33 | +3 | +0.4 |
| CASTER AWAY FROM SCREEN | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| CHARGE LOSSES | 60 | 57 | 6 | 2.00 | +116 | +19.3 |
| MISSILES IN THE MOVE | 34 | 19 | 6 | 2.00 | +476 | +79.3 |
| NEXT CHARGE BY LIST | 9 | 9 | 6 | 2.00 | +935 | +155.8 |
| OGRE LOADER SECOND SHOT | 6 | 6 | 6 | 2.00 | +1 | +0.2 |
| SUPPORT ADDS | 13 | 12 | 6 | 2.00 | +46 | +7.6 |
| SUPPORT WORKED OUT | 13 | 12 | 6 | 2.00 | +46 | +7.6 |
| CASTING BLOCK | 5 | 5 | 5 | 1.67 | +41 | +8.2 |
| FOUR ROUNDS | 9 | 8 | 5 | 1.67 | +227 | +45.4 |
| MAX FOR POSITIONING | 6 | 6 | 5 | 1.67 | +7 | +1.3 |
| CHAFF PASSED | 4 | 4 | 4 | 1.33 | -21 | -5.3 |
| LONE WIZARD KEPT IN | 4 | 4 | 4 | 1.33 | +350 | +87.5 |
| SEARCH SPOT | 4 | 4 | 4 | 1.33 | +67 | +16.9 |
| WOUNDS ON THE RANKS | 16 | 15 | 4 | 1.33 | +339 | +84.8 |
| ADVANCE LANE KEPT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| FALLS SHORT | 82 | 63 | 3 | 1.00 | +47 | +15.7 |
| HOLDS AMBUSHERS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| MARCH BY THE SUM | 3 | 3 | 3 | 1.00 | +273 | +90.8 |
| MOVES UNITS SPELL | 3 | 3 | 3 | 1.00 | +114 | +38.2 |
| SCOUT WAITS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| SHOTS AFTER THE MOVES | 11 | 11 | 3 | 1.00 | +0 | +0.0 |
| SHOTS IN THE MOVE | 74 | 53 | 3 | 1.00 | +170 | +56.6 |
| STRIKE BY THE ODDS | 3 | 3 | 3 | 1.00 | +37 | +12.2 |
| THE ROW IN ITS ORDER | 27 | 3 | 3 | 1.00 | +0 | +0.0 |
| CANNON SIGHT KEPT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| COVER ONCE | 20 | 14 | 2 | 0.67 | +43 | +21.4 |
| LANE BY FIGURES | 2 | 2 | 2 | 0.67 | +53 | +26.6 |
| ONE OBJECTIVE FORMULA | 45 | 29 | 2 | 0.67 | +114 | +57.1 |
| REDIRECT BY WHAT IT STOPS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| AFTERMATH IN POINTS | 1 | 1 | 1 | 0.33 | +12 | +12.2 |
| AFTERMATH WITH FRIENDS | 1 | 1 | 1 | 0.33 | +7 | +6.7 |
| CANNON PLANNED TARGET | 16 | 16 | 1 | 0.33 | +0 | +0.2 |
| CHARGE NOW FIRST | 7 | 7 | 1 | 0.33 | -94 | -94.3 |
| DEFENSIVE FLOOR | 1 | 1 | 1 | 0.33 | +31 | +31.5 |
| ELIXIR WORTH | 1 | 1 | 1 | 0.33 | +40 | +39.7 |
| FEATURE BUFFS | 37 | 37 | 1 | 0.33 | +7 | +6.8 |
| FIRE IN ORDER | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| HIS CHARGE DENIED | 1 | 1 | 1 | 0.33 | +204 | +203.6 |
| HIS MOVE AND SHOT | 20 | 20 | 1 | 0.33 | +0 | +0.0 |
| IDLE COST | 56 | 43 | 1 | 0.33 | +0 | +0.0 |
| KEEP FALLS | 1 | 1 | 1 | 0.33 | +14 | +13.6 |
| MANOEUVRE | 12 | 12 | 1 | 0.33 | +67 | +66.8 |
| MARCH CHECK | 4 | 4 | 1 | 0.33 | +29 | +28.7 |
| MARCH OF THE TABLE | 1 | 1 | 1 | 0.33 | -1 | -1.0 |
| NEARER NOT NEEDED | 43 | 38 | 1 | 0.33 | +16 | +15.7 |
| PATHS CROSS | 1 | 1 | 1 | 0.33 | -60 | -59.5 |
| PROMISE KNOWS THE FIGHT | 4 | 4 | 1 | 0.33 | -13 | -13.2 |
| PROMISE SHOT AWAY | 1 | 1 | 1 | 0.33 | -2 | -1.6 |
| PURSUES BIG PREY | 1 | 1 | 1 | 0.33 | -162 | -161.5 |
| REFUSING RETIRES | 1 | 1 | 1 | 0.33 | -1 | -0.8 |
| RESTRAINS TO SHOOT | 1 | 1 | 1 | 0.33 | +110 | +110.2 |
| SECOND LOOK | 1 | 1 | 1 | 0.33 | +14 | +13.8 |
| SET UP BY THE SET | 3 | 3 | 1 | 0.33 | +12 | +11.9 |
| SHOOTERS IN TWO RANKS | 1 | 1 | 1 | 0.33 | +1 | +1.0 |
| SHOT REPLANNED | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| STUCK PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| SUPPORT NARROWED | 4 | 4 | 1 | 0.33 | -117 | -116.8 |
| SURE REACH TOGETHER | 3 | 2 | 1 | 0.33 | +0 | +0.0 |
| SWIFTSTRIDE BY POINTS | 1 | 1 | 1 | 0.33 | +0 | +0.2 |
| BACKUP TARGETS | 1 | not checked | - | - | - | - |
| BLOWS WHERE AIMED | 1 | 1 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 3 | 3 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 6 | trace | - | - | - | - |
| CLOSES ON WHAT IT BEATS | 65 | 63 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 11 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 1 | 1 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 2 | 2 | 0 | 0.00 | - | - |
| EXACT ROUND | 7 | 6 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 8 | 8 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 4 | 3 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 27 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 13 | 13 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 2 | 2 | 0 | 0.00 | - | - |
| GUN FIGURES | 10 | not checked | - | - | - | - |
| HE REFORMS ONCE FREED | 9 | 9 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 21 | 20 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 27 | 26 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 11 | 11 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 26 | 25 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 12 | 12 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 65 | 64 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN RUN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 166 | 166 | 0 | 0.00 | - | - |
| HONEST WORTH | 7 | 6 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 23 | 23 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 2 | 2 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 8 | 7 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 2 | 2 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 14 | 14 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 32 | 18 | 0 | 0.00 | - | - |
| MISSILES ON ONE TARGET | 3 | not checked | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 4 | trace | - | - | - | - |
| MOVE SPELL SPOT | 5 | not checked | - | - | - | - |
| NO DOUBLE ROUNDS | 7 | 6 | 0 | 0.00 | - | - |
| NO LATE CUT | 6 | 6 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 18 | 18 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT TURNED | 1 | 1 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 1 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 23 | 13 | 0 | 0.00 | - | - |
| ONE JOINT FIGURE | 1 | 1 | 0 | 0.00 | - | - |
| ONE ROUTE | 14 | 14 | 0 | 0.00 | - | - |
| OPENS A LANE | 1 | not checked | - | - | - | - |
| OVERRUNS AWAY | 1 | 1 | 0 | 0.00 | - | - |
| PLAN RESULT | 256 | trace | - | - | - | - |
| PROMISE READS THE TABLE | 1 | 1 | 0 | 0.00 | - | - |
| REAL GROUND | 14 | 14 | 0 | 0.00 | - | - |
| REDIRECT COUNTER | 15 | 10 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 5 | 4 | 0 | 0.00 | - | - |
| RISK BY ARC | 6 | 5 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 5 | 5 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 1 | 1 | 0 | 0.00 | - | - |
| RUN DOWN | 5 | 4 | 0 | 0.00 | - | - |
| SAME TERRAIN AS THE BOARD | 1 | not checked | - | - | - | - |
| SCOUT SPOT | 2 | 2 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 7 | 7 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 1 | 1 | 0 | 0.00 | - | - |
| SET-UP ANY TARGET | 2 | not checked | - | - | - | - |
| SHOOTER COUNTED ONCE | 4 | 4 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 43 | not checked | - | - | - | - |
| SHOT OR CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 2 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 43 | 35 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 1 | 1 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 6 | 6 | 0 | 0.00 | - | - |
| STANDS STILL | 254 | 249 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 5 | not checked | - | - | - | - |
| THE PROMISED MOVE | 2 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 22 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 15 | not checked | - | - | - | - |
| THE TABLE BINDS | 261 | not checked | - | - | - | - |
| TIED UP BY THE SUM | 1 | 1 | 0 | 0.00 | - | - |
| WAITS AGAIN | 2 | 2 | 0 | 0.00 | - | - |
| WAR ENGINE JOBS | 4 | 4 | 0 | 0.00 | - | - |
| WHO FIGHTS | 5 | 5 | 0 | 0.00 | - | - |
| WHOLE FIGHT DANGER | 2 | 2 | 0 | 0.00 | - | - |

### Off best figure: csame-bb45c30-p2

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| ARMY TABLE | rule | 0.67 | 4.67 | 60.6 |
| JOB FIRST | gate | 2.33 | 3.00 | 124.8 |
| PROMISE BY ITS OWN SUM | rule | 2.00 | 2.33 | 260.0 |
| HOLDER ASSIGNMENT | rule | 1.33 | 1.00 | 32.2 |
| RULE SWITCHED OFF | gate | 0.33 | 0.67 | 195.3 |
| CHAFF PASSED | rule | 0.33 | 0.33 | 10.5 |
| CHARGE NOW FIRST | rule | - | 0.33 | 94.3 |
| MARCH OF THE TABLE | rule | 0.33 | - | 1.0 |
| PATHS CROSS | rule | - | 0.33 | 59.5 |
| PROMISE KNOWS THE FIGHT | rule | - | 0.33 | 13.2 |
| PROMISE SHOT AWAY | rule | 0.33 | - | 1.6 |
| PURSUES BIG PREY | rule | 0.33 | - | 161.5 |
| REFUSING RETIRES | rule | - | 0.33 | 0.8 |
| SUPPORT NARROWED | rule | - | 0.33 | 116.8 |

### Plans: csame-bb45c30-p2

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 0.7 | 50% | 16 | 18 | 111% |
| Mine | move | 34.7 | 98% | 2372 | 0 | 0% |
| Mine | shoot | 7.3 | 45% | 428 | 118 | 27% |
| Mine | support | 0.7 | 0% | 18 | 0 | 0% |
| Opponent | charge | 1.7 | 40% | 253 | 89 | 35% |
| Opponent | move | 38.3 | 95% | 2719 | 0 | 0% |
| Opponent | shoot | 1.7 | 60% | 93 | 71 | 76% |
| Opponent | support | 0.3 | 100% | 0 | 0 | 0% |

### Battle groups: csame-bb45c30-p2

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 3.0 | 33% | 100% | 33% | 0% | 0% | 0% | 0% | 100% | 0% |
| Opponent | REDIRECT COUNTER | 2.0 | 0% | - | - | - | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: csame-bb45c30-p2

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 2 | 0 (2) | 0 | 0 | 50 | 100% | - | - | 0 (2) | - | 0 (2) | - |
| Mine | Character | 11 | 17 (11) | 17 | 0 | 0 | 27% | 2.2 | - | 5 (6) | 30 (5) | 17 (11) | - |
| Mine | Clean-up | 2 | 226 (2) | 0 | 226 | 0 | 50% | 4.0 | 221 (1) | - | 231 (1) | 226 (2) | - |
| Mine | Fast Hammer | 10 | 0 (10) | 0 | 0 | 63 | 70% | 3.7 | 0 (6) | 0 (1) | 0 (3) | 0 (7) | 0 (3) |
| Mine | Hammer | 9 | 57 (9) | 23 | 33 | 16 | 22% | 3.7 | 22 (2) | 62 (4) | 83 (3) | 57 (9) | - |
| Mine | Holder | 2 | 0 (2) | 0 | 0 | 0 | 50% | 5.0 | 0 (1) | - | 0 (1) | - | 0 (2) |
| Mine | War machine | 4 | 0 (4) | 0 | 0 | 0 | 0% | 1.2 | 0 (4) | - | - | - | 0 (4) |
| Mine | Wizard | 4 | 0 (4) | 0 | 0 | 0 | 75% | 1.0 | 0 (2) | 0 (1) | 0 (1) | 0 (2) | 0 (2) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Chaff | 8 | 53 (8) | 0 | 53 | 59 | 62% | 4.3 | 109 (3) | 0 (4) | 0 (1) | 59 (7) | 0 (1) |
| Opponent | Character | 7 | 20 (7) | 20 | 0 | 19 | 0% | 2.0 | 89 (1) | 9 (3) | 0 (1) | 5 (3) | 50 (2) |
| Opponent | Clean-up | 3 | 0 (3) | 0 | 0 | 0 | 67% | 3.0 | - | 0 (3) | - | 0 (3) | - |
| Opponent | Fast Hammer | 1 | 0 (1) | 0 | 0 | 0 | 0% | 3.0 | - | 0 (1) | - | 0 (1) | - |
| Opponent | Hammer | 10 | 58 (10) | 17 | 41 | 12 | 30% | 2.6 | 12 (5) | 100 (4) | 110 (1) | 29 (5) | 79 (5) |
| Opponent | Shooter | 4 | 52 (4) | 0 | 52 | 21 | 0% | 1.5 | 0 (1) | 11 (2) | 171 (1) | 59 (3) | 26 (1) |
| Opponent | Wizard | 2 | 0 (2) | 0 | 0 | 0 | 0% | 3.0 | - | 0 (2) | - | 0 (2) | - |

### Charged fights: csame-bb45c30-p2

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 2 | 125 | 0 | 1.0 | 1.0 | 0 | 52 | -52 | 1 of 2 | 1 of 2 | - | -52 |
| Mine | Chaos Dwarfs | 1 | 104 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| **Mine** | all armies | 3 | 118 | 0 | 0.7 | 1.0 | 0 | 52 | -52 | 1 of 2 | 1 of 2 | - | -52 |
| Opponent | Ogre Kingdoms | 1 | 170 | 0 | 1.0 | 1.0 | 0 | 34 | -34 | 1 of 1 | 0 of 1 | - | -34 |
| Opponent | Orc & Goblin Tribes | 1 | 0 | 310 | 6.0 | 1.0 | 52 | 62 | -10 | 5 of 6 | 4 of 6 | - | -10 |
| Opponent | Wood Elf Realms | 1 | 52 | 85 | 2.0 | 1.0 | 42 | 0 | +42 | 0 of 2 | 2 of 2 | - | +42 |
| **Opponent** | all armies | 3 | 74 | 132 | 3.0 | 1.0 | 44 | 45 | -1 | 6 of 9 | 6 of 9 | - | -1 |

### Effective charges: csame-bb45c30-p2

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 2 | 1 (net -52) | 0 | 0 | 0 | 0 | 1 (net -52) | 0 | 0% (0 of 2) |
| Opponent | Orc & Goblin Tribes | 6 | 1 (net +0) | 1 (net +310) | 0 | 0 | 0 | 0 | 4 | 0% (0 of 2) |
| Opponent | Wood Elf Realms | 2 | 0 | 0 | 1 (net +85) | 1 (net +0) | 0 | 0 | 0 | 50% (1 of 2) |

### Charged fights, damage counted: csame-bb45c30-p2

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 1 | 52 | 297 | -52 | 50 | 52 | -2 | -4.8 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 52 | 125 | -52 | 54 | 52 | +2 | +3.0 |
| Mine | All fights | 2 | 52 | 211 | -52 | 52 | 52 | -0 | -0.9 |
| Opponent | Long shot (under 50%) | 1 | 255 | 314 | +0 | 58 | 128 | -70 | -27.5 |
| Opponent | 50-54% | 1 | 350 | 310 | +310 | 310 | 0 | +310 | +88.6 |
| Opponent | Effective (55-75%) | 1 | 125 | 85 | +85 | 85 | 0 | +85 | +68.0 |
| Opponent | 76-89% | 1 | 126 | 84 | +0 | 84 | 0 | +84 | +67.1 |
| Opponent | No odds | 5 | 169 | 260 | -81 | 14 | 81 | -67 | -39.4 |
| Opponent | All fights | 9 | 189 | 233 | -1 | 68 | 59 | +8 | +4.5 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| csame-bb45c30-p2 | move | 17 | 1 (6%) | 1 (6%) | 4 (24%) | 12 (71%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Elixir of Power | Opponent | L0319 |
| Fistful of Laurels | Opponent | L0218 |
| Ring of Doom | Mine | L0218, L0235 |

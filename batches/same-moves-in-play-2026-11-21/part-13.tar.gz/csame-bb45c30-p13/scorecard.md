# Doctrine scorecard: csame-bb45c30-p13

### Scorecard: csame-bb45c30-p13

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0106 | 4 | 1 | Mine | no | 1 | 6 | 1 | 2 | 0 | 0 | 0 | 0 |
| L0106 | 4 | 1 | Opponent | no | 0 | - | 1 | 3 | 0 | 0 | 0 | 937 |
| L0122 | 2 | 1 | Mine | - | - | - | 0 | 2 | 0 | 0 | 0 | 0 |
| L0122 | 2 | 1 | Opponent | - | - | 3 | 2 | 3 | 1 | 0 | 0 | 0 |
| L0206 | 2 | 1 | Mine | - | - | 3 | 0 | 6 | 0 | 0 | 0 | 170 |
| L0206 | 2 | 1 | Opponent | - | - | 4 | 0 | 1 | 0 | 0 | 0 | 678 |
| **Average** | | | Mine | 0% | 1.0 | 4.5 | 0.3 | 3.3 | 0.0 | 0.0 | 0.0 | 56.7 |
| **Average** | | | Opponent | 0% | 0.0 | 3.5 | 1.0 | 2.3 | 0.3 | 0.0 | 0.0 | 538.3 |

### KPIs: csame-bb45c30-p13

Rules off - Mine only: NO OLD ONE-MOVE GUESS; both sides: ONE RUN A PLAN.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 11) | 65% (11 of 17) | 39% (11 of 28) |
| Winner chose to follow up after the loser gave ground |  | 67% (2 of 3); on the table 67% | - | 67% (2 of 3); on the table 67% |
| Winner chose to pursue after the loser fell back in good order |  | - | - | - |
| Winner chose to pursue after the loser fled |  | 100% (2 of 2); on the table 100% | - | 100% (2 of 2); on the table 100% |
| Winner chose to follow up or pursue (all three) |  | 80% (4 of 5); on the table 80% | - | 80% (4 of 5); on the table 80% |
| Magic missiles tried each own turn | 50%+ | 46% (41 of 90) | - | 46% (41 of 90) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 51% (41 of 80) | - | 51% (41 of 80) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 50% (3 of 6) | - | 50% (3 of 6) |
| Points that never fought | lower | 50% (2832 of 5699) | 76% (4552 of 6000) | 63% (7384 of 11699) |
|   infantry points that never fought | lower | 52% (1158 of 2239) | 91% (1925 of 2111) | 71% (3083 of 4350) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 50% (8 of 16) | 64% (16 of 25) | 59% (24 of 41) |
| Bound items with a magic missile used (at least once a game) |  | 100% (4 of 4); 3.0 uses a game | 0.0 uses a game | 100% (4 of 4); 1.5 uses a game |
| Bound items with another spell used |  | 50% (1 of 2); 1.3 uses a game | 0.0 uses a game | 50% (1 of 2); 0.7 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 100% (4 of 4); 1.3 uses a game | 0.0 uses a game | 100% (4 of 4); 0.7 uses a game |
|   their share of the points of units over 100 pts | lower | 43% (1703 of 3916) | 61% (2690 of 4382) | 53% (4393 of 8298) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 7.3 (45%) | - | 7.3 (45%) |
| MARCHED: its unit marched | 5.7 (35%) | - | 5.7 (35%) |
| IN COMBAT: engaged in combat | 2.0 (12%) | - | 2.0 (12%) |
| GONE: slain | 1.3 (8%) | - | 1.3 (8%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.0 | 1.7 | 7.3 | 13.7 | 0.3 | 2.0 |
| not cast | 2.0 | 2.3 | 2.7 | 16.3 | 1.7 | 26.0 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.7 (6%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.7 (71%) | 0.7 (25%) | 7.3 (45%) | 1.3 (80%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 5.7 (35%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.0 (0%) | 0.3 (12%) | 2.0 (12%) | 0.3 (20%) | 0.0 (0%) |
| GONE: slain | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.3 (8%) | 0.0 (0%) | 1.3 (5%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.0 (100%) | 0.7 (29%) | 1.7 (62%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 23.0 (88%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 8.7 a game | 0.0 a game | 4.3 a game |
| stood (cast and not dispelled) | 46% (12 of 26) | - | 46% (12 of 26) |
| the unit moved after it | 50% (6 of 12) | - | 50% (6 of 12) |
| it charged on its next turn | 0% (0 of 12) | - | 0% (0 of 12) |
| the enemy charged it first | 8% (1 of 12) | - | 8% (1 of 12) |
| it fought by the end of its next turn | 0% (0 of 12) | - | 0% (0 of 12) |
| it moved out of a charge the enemy had planned (not charged first) | 8% (1 of 12) | - | 8% (1 of 12) |
| none of these (no charge, no fight, no charge escaped) | 83% (10 of 12) | - | 83% (10 of 12) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 64% (14 of 22) | 63% (126 of 200) | 63% (140 of 222) |
|   cavalry | - | 57% (17 of 30) | 57% (17 of 30) |
|   character | - | 40% (6 of 15) | 40% (6 of 15) |
|   chariot | - | 83% (5 of 6) | 83% (5 of 6) |
|   infantry | 64% (14 of 22) | 59% (41 of 70) | 60% (55 of 92) |
|   monster | - | 85% (11 of 13) | 85% (11 of 13) |
|   war machine | - | 70% (46 of 66) | 70% (46 of 66) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.0 (75%) | 1.0 (4%) | 3.0 (11%) |
| CHARGED: it charged | 0.0 (0%) | 1.7 (7%) | 1.7 (6%) |
| NO TARGET IN RANGE | 0.7 (25%) | 12.0 (49%) | 12.7 (46%) |
| ONLY IN COMBAT: the only targets were in combat | 0.0 (0%) | 0.3 (1%) | 0.3 (1%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.0 (0%) | 5.3 (22%) | 5.3 (20%) |
| SHELTERED: the target was sheltered | 0.0 (0%) | 0.3 (1%) | 0.3 (1%) |
| OTHER BAR | 0.0 (0%) | 4.0 (16%) | 4.0 (15%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 9.0 | 3.7 | 70% | 3.8 pts | 34 pts |
| character | 2.0 | 3.7 | 33% | 30.7 pts | 61 pts |
| chariot | 1.7 | 0.7 | 60% | 3.8 pts | 6 pts |
| infantry | 27.7 | 12.0 | 64% | 4.8 pts | 133 pts |
| monster | 3.7 | 1.0 | 82% | 2.2 pts | 8 pts |
| war machine | 15.3 | 12.0 | 59% | 13.4 pts | 206 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 1.0 | 2.7 | 1.8 |
| Charges that made contact a game | 1.0 | 2.0 | 1.5 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | - | - | - |
|   per unit a game, units carrying another wizard (or one alone) | - | - | - |
|   per unit a game, the other units (no war machines, no joined characters) | 0.15 declared, 0.15 contact (20 units) | 0.30 declared, 0.22 contact (27 units) | 0.23 declared, 0.19 contact (47 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Character in a unit | 67% (2 of 3) | 50% (2 of 4) | - | 57% (4 of 7) |
| Character on its own | 100% (3 of 3) | 50% (1 of 2) | 50% (1 of 2) | 71% (5 of 7) |
| Infantry | 43% (3 of 7) | 43% (3 of 7) | - | 43% (6 of 14) |
| Monster | 60% (3 of 5) | - | - | 60% (3 of 5) |
| War Machines | 75% (6 of 8) | - | - | 75% (6 of 8) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 3 | 80% (4 of 5); on the table 80% | 46% (41 of 90) | 50% | 50% (8 of 16) | 100% (4 of 4); 3.0 uses a game | 50% (1 of 2); 1.3 uses a game | 100% (4 of 4); 1.3 uses a game |
| Dwarfen Mountain Holds | 2 | - | - | 90% | 65% (13 of 20) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Tomb Kings of Khemri | 1 | - | - | 48% | 60% (3 of 5) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (csame-bb45c30-p13, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 33% (1) | - | 33% (1) |
| ...free all their last turn and able to turn (per game) | 0.33 | 0.00 | 0.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.33 | 0.00 | 0.33 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.33 | 0.00 | 0.33 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.33 | 0.00 | 0.33 |

### Quality by phase: csame-bb45c30-p13

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 0.7 | 0.7 |
| Strategy | Charge objectives carried out (made contact) | 100% (3 of 3) | 43% (3 of 7) |
| Strategy | Shoot objectives carried out (shot that target) | 30% (3 of 10) | 43% (38 of 88) |
| Strategy | Support requests answered (helper made contact too) | 100% (1 of 1) | - |
| Strategy | Hexes on a unit its side charged or shot that turn | 67% (2 of 3) | - |
| Strategy | Joined characters whose unit fought | 80% (8 of 10) | 0% (0 of 8) |
| Strategy | Lone characters that fought | 12% (1 of 8) | 100% (2 of 2) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 3.3 | 2.3 |
| Movement | Points that never moved of their own | 56.7 | 538.3 |
| Movement | Fights charged into per game | 0.7 | 1.7 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 2 | 1 of 4, net +0 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 2 | 1 of 4, net +0 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 2 | 1 of 4, net -130 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 of 2, net +93 | 1 of 4, net +0 |
| Shooting | Shots by shooting units (incl. breath weapons) | 5.0 | 28.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 40% (6 of 15) | 58% (50 of 86) |
| Shooting | Points destroyed by shooting units | 0.0 | 169.0 |
| Shooting | War machine shots | - | 15.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | - | 76% (35 of 46) |
| Shooting | Points destroyed by war machines | 0.0 | 95.0 |
| Magic | Magic missiles cast | 6.7 | - |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 75% (15 of 20) | - |
| Magic | Wounds caused by magic missiles | 13.3 | - |
| Magic | Wounds caused by other spells | 2.3 | - |
| Magic | Points destroyed by magic (all spells) | 147.3 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.0 / 1.0 / 1.7 / 0.3 | 3.3 / 0.0 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 147.0 | 21.7 |
| Combat | Points run down | 0.0 | 0.0 |
| Combat | Net points per charged fight, damage counted | +119 | +66 |
| Combat | Net per 100 charger points, damage counted | +52.0 | +21.2 |
| Combat | First round won (charged fights) | 100% | 20% |
| Combat | Net points per charged fight | +93 | -26 |
| Combat | Net points per supported fight / lone fight | +0 / +186 | -130 / +0 |
| Combat | Charged fights on a top-3 enemy unit | 1 of 2 | 3 of 5 |
| Game | Points lost | 344.0 | 294.3 |
| Game | VP from objectives | 786.7 | 516.7 |
| Game | Lone holders (player turns) | 1.0 | 0.0 |

- Mine won / drew / lost: 1 / 1 / 1 of 3 ended games (of 3); mean margin (Mine - Opponent) +107 VP
- The side that went first won 0 of 2 games with a winner
- Points traded per game (both sides' losses): 638
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: csame-bb45c30-p13

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.3 | +172.7 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | 23.7 | +152.4 | 0.0 | 338.3 | 21.0 | +413.7 | 0.0 | 24.0 |
| BEST PRIZE | - | - | - | - | 0.3 | +0.6 | 0.0 | 0.0 |
| CANNON PLAN MISSED | - | - | - | - | 1.3 | +0.0 | 238.0 | 0.0 |
| CANNON PLANNED TARGET | - | - | - | - | 15.0 | +342.1 | 996.0 | 38.3 |
| CANNON SIGHT KEPT | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| CASTER AWAY FROM SCREEN | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CASTING BLOCK | 4.7 | +356.6 | 48.0 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | 4.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CATCH FLIERS | 0.3 | +8.0 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | 4.7 | +108.6 | 0.0 | 85.0 | - | - | - | - |
| CHAFF PASSED | - | - | - | - | 3.7 | -0.7 | 0.0 | 0.0 |
| CHALLENGE BY POINTS | 1.0 | +62.3 | 0.0 | 0.0 | - | - | - | - |
| CHARACTER GUNS | - | - | - | - | 3.3 | +0.0 | 0.0 | 0.0 |
| CHARGE LOSSES | 16.3 | -1662.6 | 0.0 | 360.3 | 10.3 | -298.2 | 0.0 | 20.0 |
| CHARGE NOW FIRST | 0.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 43.3 | 65.0 |
| CHARIOT NO STATIC JOB | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CLOSES ON WHAT IT BEATS | 10.7 | +0.0 | 0.0 | 0.0 | 7.0 | +0.0 | 0.0 | 130.0 |
| CONVEYANCE SEARCH | 6.7 | +1446.5 | 181.3 | 0.0 | - | - | - | - |
| COVER ONCE | 7.7 | -309.0 | 0.0 | 134.0 | 8.0 | -293.2 | 0.0 | 147.0 |
| DENIED BY THE FIGHT | 0.3 | -1.2 | 0.0 | 0.0 | 0.7 | -0.8 | 21.7 | 0.0 |
| DEPLOY BY FIGURES | 6.7 | +87.5 | 0.0 | 0.0 | 12.3 | -197.3 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | - | - | - | - | 0.3 | -245.9 | 0.0 | 0.0 |
| EXACT ROUND | 0.7 | -0.8 | 0.0 | 0.0 | 1.7 | +6.5 | 50.0 | 85.0 |
| FACES THE THREAT | 0.3 | +8.6 | 0.0 | 0.0 | - | - | - | - |
| FALL BACK GOOD ORDER | 1.0 | +2.4 | 62.0 | 0.0 | 2.3 | +2.1 | 71.7 | 85.0 |
| FALLBACK BY WORTH | 0.3 | +1.0 | 0.0 | 0.0 | - | - | - | - |
| FALLS SHORT | 15.3 | +351.3 | 0.0 | 298.0 | 17.0 | +80.4 | 0.0 | 219.0 |
| FEATURE BUFFS | 15.7 | +519.4 | 0.0 | 156.7 | 1.0 | +5.0 | 0.0 | 0.0 |
| FIGHT TO THE END | 0.7 | +1.8 | 0.0 | 0.0 | 0.7 | +48.1 | 0.0 | 0.0 |
| FIVE ACTION | 76.0 | +6814.4 | 110.0 | 786.0 | 145.3 | +6073.0 | 3202.3 | 667.7 |
| FLANK NOT WEIGHED | 5.7 | +0.0 | 0.0 | 113.3 | 3.3 | +0.0 | 0.0 | 0.0 |
| FOUR ROUNDS | 1.0 | +51.4 | 62.0 | 0.0 | 2.7 | +134.4 | 71.7 | 85.0 |
| FREED FROM HIS FIGHT | 1.3 | +0.0 | 0.0 | 28.3 | - | - | - | - |
| FRIEND CHARGES FIRST | - | - | - | - | 0.3 | -22.8 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | - | - | - | - | 3.0 | -80.6 | 0.0 | 40.0 |
| FRIENDS SHOTS CHECKED | - | - | - | - | 0.3 | -0.1 | 0.0 | 0.0 |
| GOAL WALK | 12.7 | +2379.5 | 0.0 | 0.0 | 0.3 | +11.9 | 0.0 | 0.0 |
| GUN FIGURES | - | - | - | - | 1.3 | +33.9 | 0.0 | 0.0 |
| GUN MASK | - | - | - | - | 2.0 | +27.2 | 0.0 | 0.0 |
| HARD STAY DROPPED | 0.7 | +0.0 | 0.0 | 0.0 | 7.3 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 12.7 | +0.0 | 0.0 | 293.7 | 5.0 | +0.0 | 0.0 | 20.0 |
| HIS CHARGE LIST | 15.7 | +0.0 | 0.0 | 261.3 | 7.7 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 3.3 | +0.0 | 0.0 | 0.0 | 5.0 | +0.0 | 0.0 | 40.0 |
| HIS MOVE AND SHOT | 4.0 | -40.8 | 0.0 | 113.3 | 1.7 | -92.6 | 0.0 | 20.0 |
| HIS MOVE AS HE DECIDES | 48.0 | +19.3 | 492.0 | 0.0 | - | - | - | - |
| HIS MOVE WHY | - | - | - | - | 16.0 | +0.0 | 0.0 | 164.0 |
| HIS ONE MOVE | 16.3 | -113.2 | 0.0 | 0.0 | - | - | - | - |
| HIS ONE QUARTER | 2.0 | +0.0 | 0.0 | 0.0 | 4.7 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 2.0 | +0.0 | 0.0 | 0.0 | 7.7 | +0.0 | 0.0 | 40.0 |
| HIS RANDOM MOVE | - | - | - | - | 8.0 | +0.0 | 0.0 | 40.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 62.3 | +2220.5 | 0.0 | 786.0 | 56.7 | +2255.4 | 0.0 | 80.0 |
| HIS SHOTS BY HIS RUN | 50.3 | +1404.9 | 0.0 | 786.0 | 37.0 | +1039.7 | 0.0 | 194.0 |
| HIS TURN DENIED | 1.0 | +37.2 | 62.0 | 0.0 | 1.3 | +26.5 | 21.7 | 20.0 |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 41.0 | +0.0 | 0.0 | 697.7 | 12.0 | +0.0 | 0.0 | 24.0 |
| HOLDER ASSIGNMENT | 14.0 | +1616.8 | 0.0 | 253.0 | 8.3 | +935.3 | 0.0 | 24.0 |
| HOLDS AMBUSHERS | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 1.0 | -16.7 | 62.0 | 0.0 | 2.3 | -66.7 | 71.7 | 85.0 |
| HUNT IN PAIRS | - | - | - | - | 2.3 | +288.3 | 0.0 | 65.0 |
| IDLE COST | 14.0 | -94.7 | 0.0 | 46.7 | 6.3 | -126.9 | 0.0 | 0.0 |
| JOINT CHARGE NOW | 0.7 | +0.2 | 0.0 | 0.0 | 1.0 | -28.2 | 21.7 | 65.0 |
| KEEPS SCOUTS OR AMBUSH | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| KEPT FROM ITS LAST STOP | 5.7 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | - | - | - | - | 0.7 | +18.2 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| LEGAL CHARGES ONLY | 7.0 | +0.0 | 243.0 | 43.3 | 4.3 | +0.0 | 43.3 | 48.0 |
| LONE CHARACTER SAFE SPOT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| LONE WIZARD KEPT IN | 2.7 | +247.6 | 0.0 | 0.0 | 0.7 | +60.4 | 0.0 | 0.0 |
| LONG SHOT | 0.3 | -16.6 | 62.0 | 0.0 | - | - | - | - |
| LOST AFTER ESCAPE | 1.0 | +0.1 | 62.0 | 0.0 | 2.3 | +2.2 | 43.3 | 85.0 |
| MAKE SURE TOGETHER | - | - | - | - | 0.3 | +0.6 | 0.0 | 0.0 |
| MANOEUVRE | 0.3 | +0.0 | 0.0 | 90.7 | 1.7 | -18.1 | 0.0 | 65.0 |
| MARCH BY THE SUM | 1.7 | +222.1 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | 1.0 | +22.3 | 0.0 | 0.0 | - | - | - | - |
| MARCH OF THE TABLE | 0.7 | +4.1 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 2.0 | -120.2 | 0.0 | 0.0 | - | - | - | - |
| MARCH WHEELS ONLY | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 3.3 | +52.3 | 0.0 | 119.0 | 2.3 | +51.4 | 0.0 | 0.0 |
| MEETS IN TIME | 3.0 | +105.1 | 0.0 | 0.0 | 7.7 | +68.6 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 8.3 | +394.9 | 0.0 | 213.0 | - | - | - | - |
| MISSILES NEXT TURN | 10.3 | +326.5 | 0.0 | 213.0 | - | - | - | - |
| MISSILES ON ONE TARGET | 4.3 | -119.6 | 0.0 | 90.7 | - | - | - | - |
| MODEL FACING | - | - | - | - | 5.0 | +884.1 | 0.0 | 40.0 |
| MOVE ORDER | 1.7 | +0.0 | 21.7 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| MOVE SPELL IN RANGE | 0.7 | +15.7 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 1.7 | -30.6 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL SPOT | 3.0 | +0.0 | 0.0 | 181.3 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 2.0 | +196.3 | 0.0 | 56.7 | 7.0 | +237.3 | 0.0 | 40.0 |
| MOVES UNITS SPELL | 0.3 | +18.4 | 0.0 | 0.0 | - | - | - | - |
| NEARER NOT NEEDED | 5.0 | +216.1 | 0.0 | 43.3 | 10.7 | +459.9 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 1.3 | +147.3 | 0.0 | 0.0 | 3.7 | +155.4 | 0.0 | 40.0 |
| NEXT OBJECTIVE NEARER | - | - | - | - | 0.3 | -66.7 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 1.0 | -23.9 | 62.0 | 0.0 | 2.3 | -34.9 | 43.3 | 85.0 |
| NO LATE CUT | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NO OLD ONE-MOVE GUESS | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | 0.3 | +0.0 | 0.0 | 28.3 | - | - | - | - |
| NOT WORTH A CAST | 0.7 | -0.9 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 4.7 | -177.7 | 0.0 | 56.7 | 5.7 | -145.1 | 0.0 | 20.0 |
| ONE CHECK AFTER THE LAST CHANGE | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 3.7 | -94.1 | 0.0 | 209.7 | 6.7 | -78.4 | 0.0 | 20.0 |
| ONE JOINT FIGURE | - | - | - | - | 1.0 | +107.0 | 0.0 | 0.0 |
| ONE OBJECTIVE FORMULA | 8.0 | -237.4 | 0.0 | 231.3 | 3.3 | +22.9 | 0.0 | 24.0 |
| ONE ROUTE | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| OPENS A LANE | - | - | - | - | 0.7 | +0.8 | 56.7 | 0.0 |
| OVERRUNS AWAY | 0.3 | +0.2 | 0.0 | 0.0 | 1.0 | +37.7 | 71.7 | 65.0 |
| PLAN RESULT | 35.0 | +35.0 | 0.0 | 356.3 | 62.3 | +1658.8 | 1232.3 | 588.7 |
| PROMISE BY ITS OWN SUM | 2.0 | +0.0 | 0.0 | 0.0 | 7.0 | -46.0 | 0.0 | 0.0 |
| PROMISE IN STEPS | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | - | - | - | - | 1.0 | -29.4 | 0.0 | 0.0 |
| QUARTER ODDS | 5.3 | +905.3 | 0.0 | 0.0 | 18.3 | +800.2 | 73.3 | 308.0 |
| RANDOM MOVE BY FIGURES | 2.0 | +9.3 | 0.0 | 0.0 | - | - | - | - |
| REAL GROUND | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| REDIRECT BY WHAT IT STOPS | 1.3 | +3.5 | 0.0 | 56.7 | - | - | - | - |
| REDIRECT COUNTER | 2.7 | +83.9 | 0.0 | 75.0 | 2.3 | +83.5 | 0.0 | 0.0 |
| REDIRECT FOR A FRIEND IN REACH | 5.0 | +17.3 | 0.0 | 113.3 | 3.0 | +0.0 | 0.0 | 24.0 |
| REFORMS TO MEET IT | - | - | - | - | 1.7 | -22.9 | 0.0 | 0.0 |
| REFUSING RETIRES | - | - | - | - | 0.3 | +0.0 | 0.0 | 62.0 |
| RESERVE FALL BACK | - | - | - | - | 0.7 | -2.1 | 0.0 | 0.0 |
| RESERVE MOVE SPELL | 1.3 | +30.9 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | 0.7 | -5.5 | 0.0 | 0.0 | 2.0 | -3.0 | 71.7 | 85.0 |
| RISK ON THE WAY | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ROUNDS AFTER TERROR | - | - | - | - | 1.3 | +38.6 | 43.3 | 65.0 |
| RUN DOWN | 1.0 | -10.5 | 62.0 | 0.0 | 2.0 | -32.3 | 43.3 | 65.0 |
| SAME CHARGE LATER | - | - | - | - | 0.3 | -2.8 | 0.0 | 0.0 |
| SCOUT SPOT | 0.7 | +0.4 | 0.0 | 0.0 | 0.7 | -0.1 | 0.0 | 0.0 |
| SCOUT WAITS | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 1.0 | +48.3 | 0.0 | 0.0 | - | - | - | - |
| SEARCH SPOT | 0.3 | +1.0 | 0.0 | 0.0 | 0.7 | +14.9 | 0.0 | 0.0 |
| SECOND LOOK | - | - | - | - | 0.3 | +2.2 | 0.0 | 20.0 |
| SET CREDITED ONCE | - | - | - | - | 3.3 | -400.7 | 0.0 | 0.0 |
| SET UP BY THE SET | - | - | - | - | 5.7 | +568.6 | 0.0 | 130.0 |
| SET UP TOGETHER | - | - | - | - | 0.7 | +1.2 | 0.0 | 0.0 |
| SET-UP MISSED | 0.3 | +29.4 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | - | - | - | - | 1.7 | +4.0 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 4.3 | +0.0 | 0.0 | 0.0 | 29.0 | +0.0 | 0.0 | 162.3 |
| SHOOTS FROM THE BEST SPOT | 0.7 | +17.8 | 0.0 | 0.0 | 1.0 | +151.1 | 0.0 | 0.0 |
| SHORT GUN FORWARD | - | - | - | - | 2.0 | +0.0 | 0.0 | 0.0 |
| SHOT OR CHARGE | - | - | - | - | 1.0 | -64.7 | 28.3 | 0.0 |
| SHOT RISK POINTS | 41.3 | +74.9 | 0.0 | 545.3 | 45.7 | +523.8 | 0.0 | 234.0 |
| SHOTS AFTER THE MOVES | 1.0 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 4.7 | +104.8 | 0.0 | 43.3 | 48.0 | +1182.8 | 0.0 | 186.3 |
| SPELL SETS UP CHARGE | 0.3 | +139.0 | 0.0 | 0.0 | - | - | - | - |
| SPELL WORTH | 1.7 | +4.9 | 130.0 | 0.0 | - | - | - | - |
| SPOT AS THE GAME MOVES | 5.3 | +0.0 | 0.0 | 175.7 | 6.3 | +0.0 | 0.0 | 85.0 |
| STAND AND SHOOT | 1.0 | -15.8 | 62.0 | 0.0 | 0.7 | -3.5 | 43.3 | 65.0 |
| STANDS FOR A REASON | 1.3 | +0.0 | 0.0 | 0.0 | 7.3 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 15.7 | +0.0 | 48.0 | 106.7 | 97.7 | +0.0 | 3130.7 | 348.7 |
| STAY WORTH | 5.0 | +31.4 | 0.0 | 0.0 | 71.3 | +390.5 | 2230.0 | 179.0 |
| SUPPORT ADDS | 7.0 | +539.7 | 0.0 | 86.7 | - | - | - | - |
| SUPPORT NARROWED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SUPPORT WORKED OUT | 7.0 | +539.7 | 0.0 | 86.7 | - | - | - | - |
| SURE REACH TOGETHER | - | - | - | - | 0.3 | +1.1 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 1.3 | +0.0 | 0.0 | 21.7 | 2.0 | +0.0 | 0.0 | 24.0 |
| THE ROW IN ITS ORDER | 2.0 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 20.0 |
| THE ROW KEEPS ITS WAY | 3.3 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 2.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 37.0 | +0.0 | 0.0 | 359.7 | 65.7 | +0.0 | 0.0 | 291.3 |
| TIED UP BY THE SUM | - | - | - | - | 0.7 | +62.4 | 43.3 | 65.0 |
| TIME ON OUR SIDE | 13.0 | +281.9 | 48.0 | 43.3 | 42.0 | +375.5 | 0.0 | 20.0 |
| WAITS AGAIN | 2.7 | +0.0 | 0.0 | 86.7 | 1.3 | +0.0 | 0.0 | 0.0 |
| WEAPON BY POINTS | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| WHO HITS BACK | 0.3 | +15.5 | 0.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT DANGER | 3.0 | -1186.1 | 0.0 | 181.3 | 0.3 | -16.1 | 0.0 | 0.0 |
| WHOLE FIGHT GAIN | - | - | - | - | 0.7 | +29.9 | 0.0 | 0.0 |
| WOUNDS ON THE RANKS | 7.3 | +784.1 | 0.0 | 272.0 | 0.7 | +21.3 | 0.0 | 0.0 |

### Rule changes: csame-bb45c30-p13

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS SHOT LIST | 357 | 343 | 103 | 34.33 | +1756 | +17.0 |
| ARMY TABLE | 134 | 134 | 96 | 32.00 | +1563 | +16.3 |
| HIS MOVE AS HE DECIDES | 144 | 144 | 86 | 28.67 | +0 | +0.0 |
| HIS SHOTS BY HIS RUN | 262 | 252 | 69 | 23.00 | +1515 | +22.0 |
| HOLDER ASSIGNMENT | 67 | 67 | 65 | 21.67 | +3130 | +48.2 |
| SHOT RISK POINTS | 261 | 253 | 64 | 21.33 | +1137 | +17.8 |
| DEPLOY BY FIGURES | 57 | 57 | 34 | 11.33 | +500 | +14.7 |
| LEGAL CHARGES ONLY | 34 | 34 | 34 | 11.33 | +0 | +0.0 |
| FIVE ACTION | 664 | 649 | 33 | 11.00 | +1737 | +52.6 |
| OFF BEST | 31 | 31 | 31 | 10.33 | -969 | -31.3 |
| HIS MOVE WHY | 48 | 48 | 27 | 9.00 | +0 | +0.0 |
| HARD STAY DROPPED | 24 | 24 | 24 | 8.00 | +0 | +0.0 |
| THE TABLE AGAIN | 36 | 36 | 23 | 7.67 | +0 | +0.0 |
| REDIRECT FOR A FRIEND IN REACH | 24 | 24 | 22 | 7.33 | +0 | +0.0 |
| GOAL WALK | 39 | 39 | 21 | 7.00 | +4186 | +199.4 |
| TIME ON OUR SIDE | 165 | 150 | 20 | 6.67 | +198 | +9.9 |
| HIS ONE MOVE | 49 | 49 | 18 | 6.00 | +0 | +0.0 |
| CANNON PLANNED TARGET | 45 | 45 | 16 | 5.33 | -55 | -3.5 |
| MODEL FACING | 15 | 15 | 15 | 5.00 | +2652 | +176.8 |
| CASTING BLOCK | 14 | 14 | 14 | 4.67 | +390 | +27.9 |
| MOVE TO CHARGE COMPUTED | 27 | 24 | 14 | 4.67 | +492 | +35.2 |
| MEETS IN TIME | 32 | 32 | 12 | 4.00 | +122 | +10.1 |
| CHAFF PASSED | 11 | 11 | 11 | 3.67 | -2 | -0.2 |
| WOUNDS ON THE RANKS | 24 | 24 | 11 | 3.67 | +702 | +63.9 |
| LONE WIZARD KEPT IN | 10 | 10 | 10 | 3.33 | +924 | +92.4 |
| PROMISE BY ITS OWN SUM | 27 | 27 | 9 | 3.00 | -138 | -15.3 |
| SUPPORT ADDS | 21 | 21 | 9 | 3.00 | +314 | +34.9 |
| SUPPORT WORKED OUT | 21 | 21 | 9 | 3.00 | +314 | +34.9 |
| ADVANCE LANE KEPT | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| MAX FOR POSITIONING | 17 | 16 | 7 | 2.33 | +32 | +4.5 |
| CHAFF IN THE MOVE | 14 | 14 | 6 | 2.00 | +48 | +8.0 |
| CHARGE LOSSES | 80 | 79 | 6 | 2.00 | +662 | +110.3 |
| FEATURE BUFFS | 50 | 50 | 6 | 2.00 | +33 | +5.5 |
| IDLE COST | 61 | 42 | 6 | 2.00 | +48 | +8.0 |
| MOVE ORDER | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| NEXT CHARGE BY LIST | 15 | 15 | 6 | 2.00 | +358 | +59.7 |
| SET UP BY THE SET | 17 | 17 | 6 | 2.00 | +382 | +63.7 |
| SHORT GUN FORWARD | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| CASTER AWAY FROM SCREEN | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| FALLS SHORT | 97 | 70 | 5 | 1.67 | +14 | +2.9 |
| FOUR ROUNDS | 11 | 10 | 5 | 1.67 | +224 | +44.7 |
| JOINT CHARGE NOW | 5 | 5 | 5 | 1.67 | -84 | -16.8 |
| MARCH BY THE SUM | 5 | 5 | 5 | 1.67 | +666 | +133.3 |
| SHOOTERS IN TWO RANKS | 5 | 5 | 5 | 1.67 | +12 | +2.4 |
| SHOOTS FROM THE BEST SPOT | 5 | 5 | 5 | 1.67 | +240 | +48.1 |
| COVER ONCE | 47 | 32 | 4 | 1.33 | +61 | +15.3 |
| HOLDS AMBUSHERS | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| ONE OBJECTIVE FORMULA | 34 | 22 | 4 | 1.33 | +164 | +41.0 |
| QUARTER ODDS | 71 | 67 | 4 | 1.33 | +71 | +17.7 |
| RESERVE MOVE SPELL | 4 | 4 | 4 | 1.33 | +93 | +23.2 |
| SCOUT WAITS | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| CANNON SIGHT KEPT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| CHALLENGE BY POINTS | 3 | 3 | 3 | 1.00 | +187 | +62.3 |
| NEARER NOT NEEDED | 47 | 46 | 3 | 1.00 | +140 | +46.7 |
| RANDOM MOVE BY FIGURES | 6 | 6 | 3 | 1.00 | +28 | +9.3 |
| SEARCH SPOT | 3 | 3 | 3 | 1.00 | +48 | +15.9 |
| SHOTS AFTER THE MOVES | 16 | 16 | 3 | 1.00 | +0 | +0.0 |
| GUN MASK | 6 | 6 | 2 | 0.67 | +68 | +33.9 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| LANE BY FIGURES | 2 | 2 | 2 | 0.67 | +55 | +27.4 |
| MARCH OF THE TABLE | 2 | 2 | 2 | 0.67 | -12 | -6.2 |
| ONE FIGHT FORMULA | 31 | 19 | 2 | 0.67 | +2 | +0.9 |
| REDIRECT COUNTER | 15 | 13 | 2 | 0.67 | +52 | +26.1 |
| RESERVE FALL BACK | 2 | 2 | 2 | 0.67 | -6 | -3.2 |
| RISK BY ARC | 8 | 7 | 2 | 0.67 | +28 | +14.1 |
| AFTERMATH IN POINTS | 1 | 1 | 1 | 0.33 | +518 | +518.2 |
| BEST PRIZE | 1 | 1 | 1 | 0.33 | -15 | -14.7 |
| CHARIOT NO STATIC JOB | 1 | 1 | 1 | 0.33 | -85 | -84.9 |
| EXACT ROUND | 7 | 6 | 1 | 0.33 | +7 | +7.1 |
| FACES THE THREAT | 1 | 1 | 1 | 0.33 | +26 | +25.8 |
| FALLBACK BY WORTH | 1 | 1 | 1 | 0.33 | +3 | +2.9 |
| FRIENDS SHOTS CHECKED | 1 | 1 | 1 | 0.33 | -0 | -0.2 |
| HIS MOVE AND SHOT | 17 | 17 | 1 | 0.33 | +0 | +0.2 |
| HIS TURN DENIED | 7 | 6 | 1 | 0.33 | +2 | +1.9 |
| MARCH CHECK | 3 | 3 | 1 | 0.33 | +22 | +21.5 |
| MISSILES IN THE MOVE | 25 | 19 | 1 | 0.33 | +2 | +1.6 |
| MOVES UNITS SPELL | 1 | 1 | 1 | 0.33 | +55 | +55.1 |
| ONE JOINT FIGURE | 3 | 3 | 1 | 0.33 | +144 | +143.5 |
| OVERRUNS AWAY | 4 | 4 | 1 | 0.33 | +7 | +7.1 |
| REFUSING RETIRES | 1 | 1 | 1 | 0.33 | -1 | -1.0 |
| ROUNDS AFTER TERROR | 4 | 4 | 1 | 0.33 | +72 | +72.4 |
| SECOND LOOK | 1 | 1 | 1 | 0.33 | +7 | +6.6 |
| STAY WORTH | 229 | 219 | 1 | 0.33 | +2 | +1.6 |
| SUPPORT NARROWED | 1 | 1 | 1 | 0.33 | -7 | -7.0 |
| THE ROW IN ITS ORDER | 14 | 1 | 1 | 0.33 | +0 | +0.0 |
| TIED UP BY THE SUM | 2 | 2 | 1 | 0.33 | +72 | +72.4 |
| WEAPON BY POINTS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| WHO HITS BACK | 1 | 1 | 1 | 0.33 | +29 | +29.0 |
| CANNON PLAN MISSED | 4 | 4 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 12 | trace | - | - | - | - |
| CATCH FLIERS | 1 | not checked | - | - | - | - |
| CHARACTER GUNS | 10 | 10 | 0 | 0.00 | - | - |
| CHARGE NOW FIRST | 4 | 4 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 53 | 53 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 20 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 3 | 3 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 1 | 1 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 10 | 9 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 4 | 4 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 27 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 4 | 4 | 0 | 0.00 | - | - |
| FRIEND CHARGES FIRST | 1 | 1 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 9 | 9 | 0 | 0.00 | - | - |
| GUN FIGURES | 4 | not checked | - | - | - | - |
| HIS CHARGE BY HIS RUN | 53 | 52 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 70 | 70 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 25 | 25 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 20 | 17 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 29 | 29 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 24 | 22 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN RUN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 159 | 159 | 0 | 0.00 | - | - |
| HONEST WORTH | 10 | 9 | 0 | 0.00 | - | - |
| HUNT IN PAIRS | 7 | 7 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 24 | 24 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 4 | 4 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 1 | not checked | - | - | - | - |
| LONG SHOT | 1 | 1 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 10 | 9 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 1 | not checked | - | - | - | - |
| MANOEUVRE | 6 | 6 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 6 | 6 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 2 | 2 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 31 | 20 | 0 | 0.00 | - | - |
| MISSILES ON ONE TARGET | 13 | not checked | - | - | - | - |
| MOVE SPELL IN RANGE | 2 | 1 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 5 | trace | - | - | - | - |
| MOVE SPELL SPOT | 9 | not checked | - | - | - | - |
| NEXT OBJECTIVE NEARER | 1 | not checked | - | - | - | - |
| NO DOUBLE ROUNDS | 10 | 9 | 0 | 0.00 | - | - |
| NO LATE CUT | 2 | 2 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 18 | 18 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT TURNED | 1 | 1 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 2 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 3 | not checked | - | - | - | - |
| ONE ROUTE | 2 | 2 | 0 | 0.00 | - | - |
| OPENS A LANE | 2 | 2 | 0 | 0.00 | - | - |
| PLAN RESULT | 292 | trace | - | - | - | - |
| PROMISE IN STEPS | 3 | 3 | 0 | 0.00 | - | - |
| PROMISE KNOWS THE FIGHT | 3 | 1 | 0 | 0.00 | - | - |
| PROMISE READS THE TABLE | 3 | 3 | 0 | 0.00 | - | - |
| REAL GROUND | 2 | 2 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 4 | 4 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 5 | 4 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 4 | 4 | 0 | 0.00 | - | - |
| RUN DOWN | 9 | 9 | 0 | 0.00 | - | - |
| SAME CHARGE LATER | 1 | 1 | 0 | 0.00 | - | - |
| SCOUT SPOT | 4 | 4 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 3 | 3 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 10 | 10 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 2 | 1 | 0 | 0.00 | - | - |
| SET-UP MISSED | 1 | trace | - | - | - | - |
| SHOOTERS ON THE TABLE | 100 | not checked | - | - | - | - |
| SHOT OR CHARGE | 3 | 3 | 0 | 0.00 | - | - |
| SHOTS IN THE MOVE | 158 | 129 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 1 | not checked | - | - | - | - |
| SPELL WORTH | 5 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 35 | 33 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 5 | 5 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 26 | 24 | 0 | 0.00 | - | - |
| STANDS STILL | 340 | 332 | 0 | 0.00 | - | - |
| SURE REACH TOGETHER | 1 | 1 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 10 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 16 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 9 | not checked | - | - | - | - |
| THE TABLE BINDS | 308 | not checked | - | - | - | - |
| WAITS AGAIN | 12 | 11 | 0 | 0.00 | - | - |
| WHOLE FIGHT DANGER | 10 | 10 | 0 | 0.00 | - | - |
| WHOLE FIGHT GAIN | 2 | 2 | 0 | 0.00 | - | - |

### Off best figure: csame-bb45c30-p13

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 3.67 | 4.67 | 23.6 |
| ARMY TABLE | rule | 3.33 | 1.67 | 38.4 |
| HOLDER ASSIGNMENT | rule | 3.00 | 0.33 | 32.9 |
| PROMISE BY ITS OWN SUM | rule | - | 3.00 | 15.3 |
| RULE SWITCHED OFF | gate | 0.67 | 1.00 | 75.1 |
| JOINT CHARGE NOW | rule | 0.33 | 1.00 | 22.4 |
| CANNON PLANNED TARGET | rule | - | 1.00 | 25.8 |
| CHAFF PASSED | rule | - | 0.67 | 1.1 |
| MARCH OF THE TABLE | rule | 0.67 | - | 6.2 |
| AFTERMATH BAND | gate | 0.33 | - | 2.7 |
| BEST PRIZE | rule | - | 0.33 | 14.7 |
| CHARIOT NO STATIC JOB | rule | 0.33 | - | 84.9 |
| REFUSING RETIRES | rule | - | 0.33 | 1.0 |
| RESERVE FALL BACK | rule | - | 0.33 | 22.1 |
| SUPPORT NARROWED | rule | 0.33 | - | 7.0 |

### Plans: csame-bb45c30-p13

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 0.7 | 0% | 21 | 35 | 167% |
| Mine | join | 0.3 | 100% | 0 | 0 | - |
| Mine | move | 31.0 | 94% | 3066 | 0 | 0% |
| Mine | shoot | 2.3 | 0% | 334 | 0 | 0% |
| Mine | support | 0.7 | 50% | 44 | 0 | 0% |
| Opponent | charge | 1.7 | 60% | 183 | 82 | 45% |
| Opponent | move | 37.0 | 98% | 1074 | 0 | 0% |
| Opponent | shoot | 23.7 | 83% | 1262 | 1577 | 125% |

### Battle groups: csame-bb45c30-p13

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 2.7 | 25% | 50% | 0% | - | 50% | 0% | 0% | 50% | 0% |
| Opponent | REDIRECT COUNTER | 2.3 | 0% | - | - | - | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: csame-bb45c30-p13

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 4 | 0 (4) | 0 | 0 | 25 | 50% | 2.5 | 0 (2) | - | 0 (2) | 0 (3) | 0 (1) |
| Mine | Character | 15 | 13 (15) | 13 | 0 | 17 | 27% | 3.2 | - | 23 (9) | 0 (3) | 5 (7) | 31 (5) |
| Mine | Clean-up | 3 | 0 (3) | 0 | 0 | 0 | 67% | 3.0 | 0 (1) | 0 (2) | - | 0 (3) | - |
| Mine | Fast Hammer | 2 | 0 (2) | 0 | 0 | 100 | 50% | 3.0 | 0 (2) | - | - | 0 (1) | 0 (1) |
| Mine | Hammer | 6 | 81 (6) | 26 | 56 | 16 | 33% | 4.5 | 35 (1) | 119 (3) | 34 (2) | 75 (4) | 93 (2) |
| Mine | Holder | 5 | 0 (5) | 0 | 0 | 0 | 60% | 3.5 | 0 (4) | - | 0 (1) | 0 (1) | 0 (4) |
| Mine | Shooter | 2 | 154 (2) | 0 | 154 | 50 | 0% | 1.0 | - | 308 (1) | 0 (1) | 154 (2) | - |
| Mine | Wizard | 3 | 27 (3) | 27 | 0 | 22 | 0% | 3.0 | - | 0 (1) | 52 (1) | 0 (1) | 52 (1) |
| Opponent | Chaff | 2 | 208 (2) | 0 | 208 | 50 | 0% | 1.5 | 417 (1) | 0 (1) | - | 208 (2) | - |
| Opponent | Character | 8 | 10 (8) | 10 | 0 | 0 | 50% | 2.5 | 74 (1) | 5 (5) | 0 (2) | 31 (3) | 5 (5) |
| Opponent | Clean-up | 6 | 0 (6) | 0 | 0 | 8 | 17% | 2.6 | 0 (1) | 0 (5) | - | 0 (5) | 0 (1) |
| Opponent | Fast Hammer | 4 | 2 (4) | 2 | 0 | 69 | 25% | 2.3 | 0 (1) | 7 (1) | 0 (2) | 3 (3) | 0 (1) |
| Opponent | Hammer | 3 | 0 (3) | 0 | 0 | 0 | 100% | - | 0 (1) | 0 (1) | 0 (1) | 0 (2) | 0 (1) |
| Opponent | Holder | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Shooter | 10 | 56 (10) | 11 | 46 | 19 | 10% | 2.1 | 87 (2) | 53 (8) | - | 77 (8) | 0 (2) |
| Opponent | War machine | 12 | 45 (12) | 45 | 0 | 9 | 8% | 1.7 | 47 (10) | - | 38 (2) | 0 (2) | 56 (10) |
| Opponent | Wizard | 2 | 0 (2) | 0 | 0 | 0 | 0% | 1.0 | - | 0 (2) | - | - | 0 (2) |

### Charged fights: csame-bb45c30-p13

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 3 | 147 | 62 | 0.7 | 1.5 | 93 | 0 | +93 | 1 of 2 | 2 of 2 | +0 | +186 |
| Opponent | Dwarfen Mountain Holds | 2 | 396 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 1 of 2 | 0 of 2 | - | +0 |
| Opponent | Tomb Kings of Khemri | 1 | 0 | 65 | 3.0 | 1.3 | 22 | 65 | -43 | 2 of 3 | 1 of 3 | -130 | +0 |
| **Opponent** | all armies | 3 | 264 | 22 | 1.7 | 1.2 | 13 | 39 | -26 | 3 of 5 | 1 of 5 | -130 | +0 |

### Effective charges: csame-bb45c30-p13

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 2 | 0 | 0 | 0 | 0 | 0 | 2 (net +93) | 0 | 0% (0 of 2) |
| Opponent | Dwarfen Mountain Holds | 2 | 0 | 0 | 1 (net +0) | 0 | 0 | 0 | 1 | 100% (1 of 1) |
| Opponent | Tomb Kings of Khemri | 3 | 1 (net +0) | 0 | 0 | 0 | 1 (net -130) | 1 (net +0) | 0 | 0% (0 of 3) |

### Charged fights, damage counted: csame-bb45c30-p13

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 230 | 146 | +93 | 119 | 0 | +119 | +52.0 |
| Mine | All fights | 2 | 230 | 146 | +93 | 119 | 0 | +119 | +52.0 |
| Opponent | Long shot (under 50%) | 1 | 411 | 322 | +0 | 0 | 0 | +0 | +0.0 |
| Opponent | Effective (55-75%) | 1 | 60 | 55 | +0 | 282 | 0 | +282 | +469.6 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 431 | 322 | +0 | 85 | 0 | +85 | +19.7 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 606 | 65 | -130 | 160 | 195 | -35 | -5.8 |
| Opponent | No odds | 1 | 60 | 322 | +0 | 0 | 0 | +0 | +0.0 |
| Opponent | All fights | 5 | 314 | 217 | -26 | 105 | 39 | +66 | +21.2 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| csame-bb45c30-p13 | move | 21 | 2 (10%) | 1 (5%) | 1 (5%) | 18 (86%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0106, L0122 |
| Ring of Doom | Mine | L0206 |

# Doctrine scorecard: csame-bb45c30-p38

### Scorecard: csame-bb45c30-p38

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0222 | 6 | 1 | Mine | no | 0 | 2 | 2 | 5 | 0 | 0 | 0 | 0 |
| L0222 | 6 | 1 | Opponent | no | 2 | 2 | 4 | 1 | 0 | 0 | 0 | 72 |
| L0307 | 1 | 1 | Mine | yes | 1 | - | 0 | 2 | 0 | 0 | 0 | 590 |
| L0307 | 1 | 1 | Opponent | no | 18 | 5 | 1 | 3 | 0 | 0 | 0 | 375 |
| L0323 | 5 | 1 | Mine | no | - | 2 | 2 | 2 | 0 | 0 | 0 | 450 |
| L0323 | 5 | 1 | Opponent | yes | - | 4 | 1 | 1 | 1 | 0 | 0 | 245 |
| **Average** | | | Mine | 33% | 0.5 | 2.0 | 1.3 | 3.0 | 0.0 | 0.0 | 0.0 | 346.7 |
| **Average** | | | Opponent | 33% | 10.0 | 3.7 | 2.0 | 1.7 | 0.3 | 0.0 | 0.0 | 230.7 |

### KPIs: csame-bb45c30-p38

Rules off - Opponent only: NO OLD ONE-MOVE GUESS; both sides: ONE RUN A PLAN.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 47% (7 of 15) | 6% (1 of 16) | 26% (8 of 31) |
| Winner chose to follow up after the loser gave ground |  | 75% (3 of 4); on the table 75% | 100% (4 of 4); on the table 100% | 88% (7 of 8); on the table 88% |
| Winner chose to pursue after the loser fell back in good order |  | - | - | - |
| Winner chose to pursue after the loser fled |  | - | - | - |
| Winner chose to follow up or pursue (all three) |  | 75% (3 of 4); on the table 75% | 100% (4 of 4); on the table 100% | 88% (7 of 8); on the table 88% |
| Magic missiles tried each own turn | 50%+ | 25% (9 of 36) | 67% (4 of 6) | 31% (13 of 42) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 30% (9 of 30) | 67% (4 of 6) | 36% (13 of 36) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 0% (0 of 2) | - | 0% (0 of 2) |
| Points that never fought | lower | 58% (3408 of 5897) | 64% (3858 of 5999) | 61% (7266 of 11896) |
|   infantry points that never fought | lower | 53% (760 of 1437) | 100% (938 of 938) | 71% (1698 of 2375) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 73% (16 of 22) | 70% (14 of 20) | 71% (30 of 42) |
| Bound items with a magic missile used (at least once a game) |  | 100% (2 of 2); 2.0 uses a game | 0.0 uses a game | 100% (2 of 2); 1.0 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 75% (3 of 4); 1.0 uses a game | 0% (0 of 1); 0.0 uses a game | 60% (3 of 5); 0.5 uses a game |
|   their share of the points of units over 100 pts | lower | 70% (3148 of 4484) | 60% (2773 of 4648) | 65% (5921 of 9132) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 6.0 (67%) | 0.0 (0%) | 6.0 (62%) |
| MARCHED: its unit marched | 1.0 (11%) | 0.7 (100%) | 1.7 (17%) |
| IN COMBAT: engaged in combat | 2.0 (22%) | 0.0 (0%) | 2.0 (21%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 6.0 | 1.0 | 4.3 | 0.3 | 1.7 |
| not cast | 0.0 | 3.0 | 9.7 | 1.7 | 6.3 |
| NOT CHOSEN: could have been cast at a target | - | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (11%) |
| NO TARGET: no enemy in range, sight and arc it may target | - | 0.0 (0%) | 6.0 (62%) | 0.7 (40%) | 0.0 (0%) |
| MARCHED: its unit marched | - | 0.0 (0%) | 1.7 (17%) | 0.3 (20%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | - | 2.0 (67%) | 2.0 (21%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | - | 0.0 (0%) | 0.0 (0%) | 0.7 (40%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | - | 1.0 (33%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | - | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 5.7 (89%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.0 a game | 0.0 a game | 0.5 a game |
| stood (cast and not dispelled) | 100% (3 of 3) | - | 100% (3 of 3) |
| the unit moved after it | 100% (3 of 3) | - | 100% (3 of 3) |
| it charged on its next turn | 0% (0 of 3) | - | 0% (0 of 3) |
| the enemy charged it first | 0% (0 of 3) | - | 0% (0 of 3) |
| it fought by the end of its next turn | 0% (0 of 3) | - | 0% (0 of 3) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 3) | - | 0% (0 of 3) |
| none of these (no charge, no fight, no charge escaped) | 100% (3 of 3) | - | 100% (3 of 3) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 88% (50 of 57) | 67% (73 of 109) | 74% (123 of 166) |
|   cavalry | - | 93% (14 of 15) | 93% (14 of 15) |
|   character | - | 0% (0 of 15) | 0% (0 of 15) |
|   chariot | 77% (17 of 22) | 83% (5 of 6) | 79% (22 of 28) |
|   infantry | - | 69% (42 of 61) | 69% (42 of 61) |
|   war machine | 94% (33 of 35) | 100% (12 of 12) | 96% (45 of 47) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 0.3 (14%) | 0.7 (6%) | 1.0 (7%) |
| CHARGED: it charged | 0.3 (14%) | 2.3 (19%) | 2.7 (19%) |
| IN COMBAT: it fought this turn or the last | 0.3 (14%) | 0.0 (0%) | 0.3 (2%) |
| MOVED: a war machine that moved | 0.3 (14%) | 0.0 (0%) | 0.3 (2%) |
| NO TARGET IN RANGE | 0.3 (14%) | 6.7 (56%) | 7.0 (49%) |
| ONLY IN COMBAT: the only targets were in combat | 0.0 (0%) | 0.3 (3%) | 0.3 (2%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.7 (29%) | 2.0 (17%) | 2.7 (19%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 6.0 | 0.3 | 94% | 0.6 pts | 4 pts |
| chariot | 7.7 | 7.0 | 61% | 23.0 pts | 176 pts |
| infantry | 16.7 | 7.7 | 70% | 8.2 pts | 137 pts |
| war machine | 15.0 | 20.7 | 71% | 46.2 pts | 694 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 2.0 | 3.3 | 2.7 |
| Charges that made contact a game | 1.0 | 2.7 | 1.8 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.00 declared, 0.00 contact (4 units) | 0.00 declared, 0.00 contact (1 units) | 0.00 declared, 0.00 contact (5 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | - | - |
|   per unit a game, the other units (no war machines, no joined characters) | 0.30 declared, 0.15 contact (20 units) | 0.33 declared, 0.27 contact (30 units) | 0.32 declared, 0.22 contact (50 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 100% (3 of 3) | 0% (0 of 1) | - | 75% (3 of 4) |
| Character in a unit | 100% (4 of 4) | 50% (1 of 2) | - | 83% (5 of 6) |
| Character on its own | 100% (2 of 2) | - | 40% (2 of 5) | 57% (4 of 7) |
| Chariot | - | 75% (3 of 4) | - | 75% (3 of 4) |
| Infantry | 0% (0 of 2) | 33% (1 of 3) | - | 20% (1 of 5) |
| Monster | 100% (5 of 5) | - | - | 100% (5 of 5) |
| War Machines | 78% (7 of 9) | 100% (2 of 2) | - | 82% (9 of 11) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 1 | 100% (2 of 2); on the table 100% | 33% (4 of 12) | 29% | 67% (4 of 6) | 100% (2 of 2); 6.0 uses a game | 0.0 uses a game | 50% (1 of 2); 1.0 uses a game |
| Chaos Dwarfs | 2 | 50% (1 of 2); on the table 50% | 21% (5 of 24) | 71% | 75% (12 of 16) | 0.0 uses a game | 0.0 uses a game | 100% (2 of 2); 1.0 uses a game |
| Empire of Man | 1 | - | 67% (4 of 6) | 91% | 90% (9 of 10) | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Tomb Kings of Khemri | 2 | 100% (4 of 4); on the table 100% | - | 51% | 50% (5 of 10) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (csame-bb45c30-p38, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 33% (2) | 100% (1) | 43% (3) |
| ...free all their last turn and able to turn (per game) | 0.33 | 0.33 | 0.67 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.33 | 0.33 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: csame-bb45c30-p38

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 0.7 | 2.7 |
| Strategy | Charge objectives carried out (made contact) | 43% (3 of 7) | 56% (5 of 9) |
| Strategy | Shoot objectives carried out (shot that target) | 60% (26 of 43) | 44% (17 of 39) |
| Strategy | Support requests answered (helper made contact too) | 0% (0 of 1) | 100% (1 of 1) |
| Strategy | Joined characters whose unit fought | 83% (5 of 6) | 0% (0 of 4) |
| Strategy | Lone characters that fought | 17% (1 of 6) | 43% (3 of 7) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 3.0 | 1.7 |
| Movement | Points that never moved of their own | 346.7 | 230.7 |
| Movement | Fights charged into per game | 1.0 | 2.3 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 3 | 1 of 5, net +0 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 3 | 2 of 5, net -35 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 1 of 3, net +66 | 0 of 5 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 of 3, net +20 | 0 of 5 |
| Shooting | Shots by shooting units (incl. breath weapons) | 5.7 | 22.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 53% (9 of 17) | 21% (14 of 68) |
| Shooting | Points destroyed by shooting units | 0.0 | 120.7 |
| Shooting | War machine shots | 11.0 | 4.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 42% (14 of 33) | 50% (6 of 12) |
| Shooting | Points destroyed by war machines | 106.7 | 0.0 |
| Magic | Magic missiles cast | 2.3 | 1.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 14% (1 of 7) | 25% (1 of 4) |
| Magic | Wounds caused by magic missiles | 3.3 | 0.7 |
| Magic | Wounds caused by other spells | 1.0 | - |
| Magic | Points destroyed by magic (all spells) | 264.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.0 / 0.0 / 1.3 / 0.0 | 4.7 / 0.0 / 0.0 / 0.3 |
| Combat | Points destroyed in combat | 318.7 | 243.3 |
| Combat | Points run down | 0.0 | 0.0 |
| Combat | Net points per charged fight, damage counted | -17 | -21 |
| Combat | Net per 100 charger points, damage counted | -11.4 | -6.0 |
| Combat | First round won (charged fights) | 100% | 57% |
| Combat | Net points per charged fight | +29 | -13 |
| Combat | Net points per supported fight / lone fight | - / +29 | -70 / -3 |
| Combat | Charged fights on a top-3 enemy unit | 1 of 3 | 5 of 7 |
| Game | Points lost | 493.0 | 606.0 |
| Game | VP from objectives | 403.3 | 933.3 |
| Game | Lone holders (player turns) | 0.5 | 10.0 |

- Mine won / drew / lost: 0 / 1 / 2 of 3 ended games (of 3); mean margin (Mine - Opponent) -350 VP
- The side that went first won 1 of 2 games with a winner
- Points traded per game (both sides' losses): 1099
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: csame-bb45c30-p38

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.3 | +37.8 | 0.0 | 103.3 | - | - | - | - |
| ALREADY CARRIED | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | 11.0 | -156.4 | 0.0 | 91.7 | 31.3 | +700.4 | 0.0 | 156.0 |
| ARTILLERY RE-ROLL WEIGHED | 4.0 | +0.0 | 0.0 | 76.7 | 0.3 | +0.0 | 0.0 | 0.0 |
| ASSAILMENT BY POINTS | 0.3 | +0.4 | 0.0 | 0.0 | - | - | - | - |
| BACKUP TARGETS | 0.7 | +2.5 | 0.0 | 17.3 | - | - | - | - |
| BEST PRIZE | - | - | - | - | 0.3 | -17.0 | 56.7 | 0.0 |
| BLOWS WHERE AIMED | - | - | - | - | 0.3 | -12.9 | 0.0 | 40.7 |
| CANNON PLAN MISSED | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CANNON PLANNED TARGET | 9.0 | +15.4 | 130.0 | 263.3 | 4.0 | +97.8 | 0.0 | 0.0 |
| CANNON SIGHT KEPT | 1.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 41.7 |
| CAST JOB | 3.3 | +51.5 | 374.7 | 0.0 | - | - | - | - |
| CASTER AWAY FROM SCREEN | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | 1.3 | +16.7 | 0.0 | 40.0 | 0.7 | +4.6 | 0.0 | 64.7 |
| CHAFF PASSED | 0.3 | -2.1 | 0.0 | 0.0 | - | - | - | - |
| CHARGE LOSSES | 20.7 | -631.7 | 0.0 | 332.7 | 19.0 | -365.0 | 0.0 | 340.7 |
| CHARGE NOW FIRST | 2.0 | +0.0 | 233.3 | 17.3 | 1.3 | +0.0 | 177.3 | 0.0 |
| CLOSES ON WHAT IT BEATS | 8.7 | +0.0 | 0.0 | 0.0 | 11.7 | +0.0 | 0.0 | 0.0 |
| COMBAT PIVOT | - | - | - | - | 1.3 | +0.0 | 0.0 | 143.7 |
| CONVEYANCE SEARCH | 0.3 | +6.9 | 0.0 | 0.0 | - | - | - | - |
| COVER ONCE | 14.0 | -1205.7 | 0.0 | 189.0 | 3.7 | -90.2 | 0.0 | 23.3 |
| DEPLOY BY FIGURES | 9.0 | -61.4 | 0.0 | 0.0 | 7.3 | -45.6 | 0.0 | 41.7 |
| ENGINEER BY LORE | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| EXACT ROUND | 1.7 | -0.4 | 46.0 | 17.3 | 3.3 | +2.3 | 415.7 | 129.0 |
| FALL BACK GOOD ORDER | 1.3 | +0.0 | 46.0 | 17.3 | 3.3 | +2.6 | 415.7 | 129.0 |
| FALLS SHORT | 6.7 | +108.4 | 0.0 | 130.7 | 13.0 | +158.8 | 0.0 | 161.0 |
| FEATURE BUFFS | 5.0 | +95.2 | 0.0 | 0.0 | 2.7 | +48.0 | 0.0 | 44.0 |
| FIGHT TO THE END | - | - | - | - | 0.7 | -0.9 | 206.7 | 0.0 |
| FIRE IN ORDER | 0.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 17.3 | 0.0 |
| FIVE ACTION | 89.7 | +3577.5 | 1271.3 | 1166.7 | 113.3 | +9109.7 | 2028.3 | 840.3 |
| FLANK NOT WEIGHED | 11.7 | +0.0 | 0.0 | 264.7 | 3.0 | +0.0 | 0.0 | 134.3 |
| FOLLOW UP WEIGHED | 0.3 | +214.0 | 0.0 | 0.0 | 1.0 | +83.0 | 0.0 | 0.0 |
| FOUR ROUNDS | 2.3 | +60.3 | 46.0 | 17.3 | 3.3 | +260.6 | 415.7 | 129.0 |
| FREED FROM HIS FIGHT | 3.3 | +0.0 | 0.0 | 31.7 | 0.3 | +0.0 | 0.0 | 0.0 |
| FRIENDS SHOTS CHECKED | - | - | - | - | 0.7 | +1.4 | 0.0 | 0.0 |
| GIVES UP | - | - | - | - | 0.3 | -9.3 | 0.0 | 0.0 |
| GOAL WALK | 11.3 | +718.9 | 0.0 | 0.0 | 18.7 | +2273.8 | 0.0 | 23.3 |
| GUN FIGURES | 3.7 | +67.4 | 65.0 | 103.3 | - | - | - | - |
| GUN MASK | - | - | - | - | 2.7 | +52.9 | 0.0 | 0.0 |
| HARD STAY DROPPED | 1.0 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 22.0 |
| HE REFORMS ONCE FREED | 2.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| HELPER UNSEEN | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS CHARGE BY HIS RUN | 16.3 | +0.0 | 0.0 | 332.7 | 4.3 | +0.0 | 0.0 | 210.7 |
| HIS CHARGE DENIED | 0.7 | +15.6 | 0.0 | 0.0 | 0.7 | +13.0 | 17.3 | 0.0 |
| HIS CHARGE LIST | 10.0 | +0.0 | 0.0 | 263.3 | 1.0 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 3.7 | +0.0 | 0.0 | 28.3 | 7.0 | +0.0 | 0.0 | 264.3 |
| HIS MOVE AND SHOT | 3.7 | -3.2 | 0.0 | 0.0 | 4.3 | -125.7 | 0.0 | 232.7 |
| HIS MOVE AS HE DECIDES | - | - | - | - | 33.3 | +11.3 | 282.0 | 0.0 |
| HIS MOVE WHY | 26.0 | +0.0 | 0.0 | 175.3 | - | - | - | - |
| HIS ONE MOVE | - | - | - | - | 27.0 | -50.0 | 0.0 | 40.7 |
| HIS ONE QUARTER | 5.0 | +0.0 | 0.0 | 63.3 | 2.0 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 9.7 | +0.0 | 0.0 | 63.0 | 3.7 | +0.0 | 0.0 | 158.7 |
| HIS RANDOM MOVE | - | - | - | - | 6.3 | +0.0 | 0.0 | 48.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 49.0 | +1153.4 | 0.0 | 416.0 | 64.3 | +2366.0 | 0.0 | 524.0 |
| HIS SHOTS BY HIS RUN | 44.0 | +507.5 | 0.0 | 559.3 | 51.0 | +861.8 | 0.0 | 640.0 |
| HIS TURN DENIED | 0.3 | +1.6 | 24.0 | 17.3 | 1.3 | +153.5 | 310.0 | 23.3 |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 15.7 | +0.0 | 0.0 | 0.0 | 28.7 | +0.0 | 0.0 | 218.0 |
| HOLDER ASSIGNMENT | 6.7 | +687.3 | 0.0 | 0.0 | 17.3 | +1457.8 | 0.0 | 152.0 |
| HOLDS AMBUSHERS | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 1.3 | -15.5 | 46.0 | 17.3 | 2.3 | -104.4 | 312.3 | 65.0 |
| HUNT IN PAIRS | - | - | - | - | 1.3 | +398.8 | 0.0 | 0.0 |
| IDLE COST | 7.7 | -47.0 | 0.0 | 17.3 | 13.3 | -214.2 | 0.0 | 23.3 |
| JOINT CHARGE NOW | 0.7 | +59.1 | 0.0 | 0.0 | 0.7 | +50.4 | 206.7 | 23.3 |
| KEEP FALLS | 0.7 | +5.5 | 0.0 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | - | - | - | - | 5.7 | +0.0 | 0.0 | 130.0 |
| LANE BY FIGURES | - | - | - | - | 1.3 | +45.8 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 0.3 | +0.0 | 0.0 | 0.0 | 15.0 | +0.0 | 459.7 | 1040.3 |
| LONE WIZARD KEPT IN | 0.7 | +17.5 | 0.0 | 0.0 | 1.0 | +78.3 | 0.0 | 0.0 |
| LONG SHOT | 0.3 | -1.1 | 0.0 | 0.0 | - | - | - | - |
| LOST AFTER ESCAPE | 0.7 | -0.7 | 0.0 | 0.0 | 1.0 | +0.3 | 31.7 | 105.7 |
| MAKE SURE TOGETHER | - | - | - | - | 0.3 | +1.1 | 0.0 | 0.0 |
| MANOEUVRE | 2.0 | +0.0 | 0.0 | 0.0 | 1.7 | -12.3 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.3 | +1.1 | 0.0 | 0.0 | - | - | - | - |
| MARCH BY THE SUM | 0.3 | +3.8 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | 0.7 | +30.8 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 0.3 | -1.1 | 0.0 | 0.0 | 0.7 | +34.6 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | - | - | - | - | 1.7 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 3.7 | +56.0 | 0.0 | 102.3 | 4.3 | +73.5 | 0.0 | 40.7 |
| MEETS IN TIME | 3.3 | +203.8 | 0.0 | 0.0 | 1.7 | +142.6 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 4.3 | +196.0 | 0.0 | 0.0 | 1.3 | +29.8 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 6.3 | +96.0 | 0.0 | 0.0 | 1.7 | +41.0 | 0.0 | 0.0 |
| MOVE ORDER | 2.7 | +0.0 | 48.3 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 10.7 | +499.8 | 0.0 | 204.7 | 5.0 | +201.5 | 0.0 | 0.0 |
| MOVES UNITS SPELL | 0.3 | +18.4 | 0.0 | 0.0 | - | - | - | - |
| NEARER NOT NEEDED | 6.0 | +293.9 | 0.0 | 0.0 | 12.0 | +520.7 | 0.0 | 46.0 |
| NEXT CHARGE BY LIST | 4.7 | +209.0 | 0.0 | 63.0 | 3.7 | +150.4 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 1.3 | -16.9 | 24.0 | 17.3 | 3.0 | -197.1 | 312.3 | 105.7 |
| NO LATE CUT | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OFF BEST | 4.3 | -76.1 | 0.0 | 210.0 | 9.0 | -344.8 | 103.3 | 23.3 |
| OGRE LOADER SECOND SHOT | 2.7 | +0.6 | 0.0 | 76.7 | - | - | - | - |
| ONE FIGHT FORMULA | 5.7 | -20.3 | 0.0 | 74.0 | 6.7 | -102.7 | 0.0 | 134.3 |
| ONE JOINT FIGURE | 0.3 | +12.6 | 0.0 | 0.0 | - | - | - | - |
| ONE OBJECTIVE FORMULA | 4.7 | +25.6 | 0.0 | 0.0 | 7.3 | +289.6 | 0.0 | 22.0 |
| ONE PROMISE A TARGET | 0.3 | -17.4 | 0.0 | 28.3 | - | - | - | - |
| ONE ROUTE | - | - | - | - | 1.7 | +0.0 | 0.0 | 0.0 |
| OPENS A LANE | - | - | - | - | 0.7 | +3.4 | 56.7 | 0.0 |
| OPENS UP | - | - | - | - | 1.0 | +29.2 | 49.0 | 65.0 |
| OVERRUNS AWAY | 0.3 | +0.7 | 0.0 | 0.0 | - | - | - | - |
| PIVOT GUARDS FLANK | 0.3 | -1.3 | 0.0 | 28.3 | - | - | - | - |
| PLAN RESULT | 41.0 | +534.5 | 346.0 | 726.0 | 49.7 | +904.6 | 429.3 | 935.3 |
| PROMISE BELOW ZERO | 1.3 | +0.0 | 0.0 | 45.7 | - | - | - | - |
| PROMISE BY ITS OWN SUM | 10.7 | -267.9 | 0.0 | 85.0 | 8.0 | -162.7 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | 0.3 | -0.8 | 0.0 | 28.3 | - | - | - | - |
| PROMISE READS THE TABLE | 0.3 | -18.6 | 0.0 | 28.3 | - | - | - | - |
| PROMISE SHOT AWAY | 0.7 | -0.7 | 0.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | 15.0 | +947.2 | 195.0 | 63.3 | 20.0 | +2065.2 | 548.3 | 195.0 |
| RANDOM MOVE BY FIGURES | 0.7 | +0.0 | 0.0 | 56.7 | - | - | - | - |
| REAL GROUND | - | - | - | - | 1.7 | +0.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | 3.3 | +131.0 | 0.0 | 123.3 | 3.3 | +137.5 | 0.0 | 86.7 |
| REDIRECT FOR A FRIEND IN REACH | 2.0 | +0.0 | 0.0 | 85.0 | 5.0 | +0.0 | 0.0 | 44.0 |
| REFORMS TO MEET IT | 2.7 | -7.8 | 0.0 | 56.7 | 0.3 | -4.6 | 0.0 | 0.0 |
| RESERVE FALL BACK | - | - | - | - | 2.0 | +48.9 | 0.0 | 23.3 |
| RESERVE MOVE SPELL | 1.0 | +50.8 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | 2.3 | +52.5 | 46.0 | 17.3 | 2.7 | -6.8 | 415.7 | 88.3 |
| RISK ON THE WAY | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| ROUNDS AFTER TERROR | - | - | - | - | 0.3 | -5.3 | 31.7 | 65.0 |
| RUN DOWN | - | - | - | - | 0.7 | -5.0 | 31.7 | 105.7 |
| SCOUT SPOT | - | - | - | - | 2.0 | +1.8 | 0.0 | 0.0 |
| SCOUT WAITS | - | - | - | - | 2.0 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 1.3 | -155.4 | 0.0 | 40.0 | - | - | - | - |
| SEARCH SPOT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| SECOND LOOK | - | - | - | - | 0.3 | +4.8 | 103.3 | 0.0 |
| SET CREDITED ONCE | - | - | - | - | 2.0 | -408.6 | 0.0 | 0.0 |
| SET UP BY THE SET | 0.3 | +0.0 | 0.0 | 0.0 | 2.3 | +327.2 | 0.0 | 0.0 |
| SET UP TOGETHER | - | - | - | - | 0.7 | +2.8 | 0.0 | 0.0 |
| SHOOTER COUNTED ONCE | 0.7 | -2.6 | 0.0 | 20.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | - | - | - | - | 0.3 | +1.3 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 14.3 | +0.0 | 0.0 | 283.3 | 14.0 | +0.0 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 4.0 | +155.1 | 281.0 | 0.0 | 3.7 | +35.0 | 91.3 | 0.0 |
| SHOT OR CHARGE | - | - | - | - | 1.0 | -14.1 | 34.7 | 0.0 |
| SHOT RISK POINTS | 27.0 | -260.3 | 0.0 | 457.0 | 32.3 | +4.5 | 0.0 | 305.3 |
| SHOTS AFTER THE MOVES | 4.0 | +0.0 | 0.0 | 0.0 | 5.0 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 17.3 | +425.3 | 0.0 | 366.7 | 23.3 | +550.2 | 0.0 | 108.7 |
| SPOT AS THE GAME MOVES | 9.0 | +0.0 | 0.0 | 193.7 | 5.7 | +0.0 | 0.0 | 0.0 |
| STAND AND SHOOT | 0.7 | -0.2 | 0.0 | 0.0 | 0.7 | -11.0 | 103.3 | 0.0 |
| STANDS FOR A REASON | - | - | - | - | 6.0 | +0.0 | 0.0 | 44.0 |
| STANDS STILL | 44.3 | +0.0 | 1225.3 | 615.0 | 42.3 | +0.0 | 1612.7 | 180.3 |
| STAY WORTH | 25.0 | -438.9 | 439.7 | 680.0 | 37.0 | +406.6 | 1269.3 | 22.0 |
| STRIKE BY THE ODDS | 0.3 | +0.2 | 23.3 | 103.3 | 1.3 | +125.6 | 166.7 | 431.0 |
| STUCK PIVOT | 0.3 | +0.0 | 0.0 | 56.7 | - | - | - | - |
| SUPPORT ADDS | 4.3 | +603.1 | 0.0 | 77.3 | 7.3 | +90.3 | 0.0 | 23.3 |
| SUPPORT NARROWED | 0.7 | +0.0 | 93.7 | 0.0 | 0.3 | +0.0 | 17.3 | 0.0 |
| SUPPORT WORKED OUT | 4.3 | +603.1 | 0.0 | 77.3 | 7.3 | +90.3 | 0.0 | 23.3 |
| SURE REACH TOGETHER | - | - | - | - | 2.0 | +10.7 | 0.0 | 0.0 |
| SWIFTSTRIDE BY POINTS | - | - | - | - | 0.3 | +0.3 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 1.0 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 22.0 |
| THE PROMISE ADDS | 1.0 | -60.5 | 0.0 | 28.3 | - | - | - | - |
| THE PROMISED MOVE | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 3.7 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 1.7 | +0.0 | 0.0 | 28.3 | 2.3 | +0.0 | 0.0 | 65.0 |
| THE STEP BACK IS MADE | 1.3 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 65.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 41.0 | +0.0 | 0.0 | 566.3 | 54.3 | +0.0 | 0.0 | 355.7 |
| TIED UP BY THE SUM | 0.7 | +31.6 | 46.0 | 17.3 | 1.0 | +88.7 | 49.0 | 65.0 |
| TIME ON OUR SIDE | 21.3 | +304.5 | 0.0 | 103.3 | 20.0 | +206.7 | 0.0 | 129.7 |
| WAITS AGAIN | 2.0 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| WAR ENGINE JOBS | 3.0 | +0.0 | 281.0 | 0.0 | - | - | - | - |
| WHAT THE JOINER ADDS | - | - | - | - | 0.7 | -39.8 | 0.0 | 81.3 |
| WHO FIGHTS | 1.0 | +3.4 | 0.0 | 0.0 | 0.3 | +53.3 | 0.0 | 40.7 |
| WHO HITS BACK | 0.7 | +84.8 | 0.0 | 17.3 | - | - | - | - |
| WHOLE FIGHT | - | - | - | - | 0.3 | +48.5 | 0.0 | 40.7 |
| WHOLE FIGHT DANGER | 2.3 | -331.4 | 0.0 | 17.3 | 1.3 | -25.5 | 0.0 | 187.3 |
| WHOLE FIGHT GAIN | 0.3 | +2.7 | 0.0 | 0.0 | 0.3 | +4.2 | 103.3 | 23.3 |
| WOUNDED STAYS OUT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| WOUNDS ON THE RANKS | 3.0 | +49.6 | 0.0 | 0.0 | 1.0 | +33.3 | 0.0 | 0.0 |

### Rule changes: csame-bb45c30-p38

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 127 | 127 | 83 | 27.67 | +1960 | +23.6 |
| HIS SHOT LIST | 340 | 334 | 71 | 23.67 | +1389 | +19.6 |
| HOLDER ASSIGNMENT | 72 | 72 | 68 | 22.67 | +4601 | +67.7 |
| HIS MOVE AS HE DECIDES | 100 | 100 | 66 | 22.00 | +0 | +0.0 |
| HIS SHOTS BY HIS RUN | 285 | 279 | 56 | 18.67 | +515 | +9.2 |
| HIS MOVE WHY | 78 | 78 | 55 | 18.33 | +0 | +0.0 |
| LEGAL CHARGES ONLY | 46 | 46 | 46 | 15.33 | +0 | +0.0 |
| FIVE ACTION | 609 | 595 | 41 | 13.67 | +2015 | +49.1 |
| OFF BEST | 40 | 40 | 40 | 13.33 | -1263 | -31.6 |
| THE TABLE AGAIN | 36 | 36 | 33 | 11.00 | +0 | +0.0 |
| DEPLOY BY FIGURES | 49 | 49 | 32 | 10.67 | +405 | +12.6 |
| MOVE TO CHARGE COMPUTED | 47 | 41 | 29 | 9.67 | +455 | +15.7 |
| HIS ONE MOVE | 81 | 79 | 26 | 8.67 | +0 | +0.0 |
| PROMISE BY ITS OWN SUM | 56 | 56 | 26 | 8.67 | -1292 | -49.7 |
| REDIRECT FOR A FRIEND IN REACH | 21 | 21 | 21 | 7.00 | +0 | +0.0 |
| GOAL WALK | 90 | 88 | 19 | 6.33 | +1268 | +66.7 |
| SHOT RISK POINTS | 178 | 173 | 18 | 6.00 | +627 | +34.9 |
| NEXT CHARGE BY LIST | 25 | 24 | 16 | 5.33 | +363 | +22.7 |
| TIME ON OUR SIDE | 124 | 105 | 16 | 5.33 | +69 | +4.3 |
| ARTILLERY RE-ROLL WEIGHED | 13 | 13 | 13 | 4.33 | +0 | +0.0 |
| SHOOTS FROM THE BEST SPOT | 23 | 23 | 13 | 4.33 | +176 | +13.5 |
| QUARTER ODDS | 105 | 102 | 12 | 4.00 | +1108 | +92.3 |
| HARD STAY DROPPED | 11 | 11 | 11 | 3.67 | +0 | +0.0 |
| MOVE ORDER | 11 | 11 | 11 | 3.67 | +0 | +0.0 |
| SUPPORT ADDS | 35 | 34 | 10 | 3.33 | +448 | +44.8 |
| SUPPORT WORKED OUT | 35 | 34 | 10 | 3.33 | +448 | +44.8 |
| STAY WORTH | 186 | 168 | 9 | 3.00 | +26 | +2.9 |
| COVER ONCE | 53 | 37 | 8 | 2.67 | +188 | +23.4 |
| OGRE LOADER SECOND SHOT | 8 | 8 | 8 | 2.67 | +2 | +0.2 |
| MAX FOR POSITIONING | 24 | 21 | 7 | 2.33 | +15 | +2.2 |
| SHOTS AFTER THE MOVES | 27 | 27 | 7 | 2.33 | +0 | +0.0 |
| CANNON SIGHT KEPT | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| MEETS IN TIME | 15 | 15 | 6 | 2.00 | +516 | +86.1 |
| RESERVE FALL BACK | 6 | 6 | 6 | 2.00 | +147 | +24.5 |
| SCOUT WAITS | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| ADVANCE LANE KEPT | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| CHARGE LOSSES | 119 | 117 | 5 | 1.67 | +410 | +81.9 |
| LONE WIZARD KEPT IN | 5 | 5 | 5 | 1.67 | +288 | +57.5 |
| STRIKE BY THE ODDS | 5 | 5 | 5 | 1.67 | +377 | +75.5 |
| CHAFF IN THE MOVE | 6 | 6 | 4 | 1.33 | +3 | +0.8 |
| COMBAT PIVOT | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| FIRE IN ORDER | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 4 | 4 | 4 | 1.33 | +891 | +222.7 |
| FOUR ROUNDS | 17 | 16 | 4 | 1.33 | +100 | +24.9 |
| JOINT CHARGE NOW | 4 | 4 | 4 | 1.33 | +328 | +82.1 |
| LANE BY FIGURES | 4 | 4 | 4 | 1.33 | +137 | +34.3 |
| SET UP BY THE SET | 8 | 8 | 4 | 1.33 | +1046 | +261.4 |
| SHOTS IN THE MOVE | 122 | 92 | 4 | 1.33 | +116 | +29.0 |
| TIED UP BY THE SUM | 5 | 5 | 4 | 1.33 | +107 | +26.7 |
| HOLDS AMBUSHERS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| IDLE COST | 63 | 38 | 3 | 1.00 | +52 | +17.2 |
| RESERVE MOVE SPELL | 3 | 3 | 3 | 1.00 | +154 | +51.5 |
| CANNON PLANNED TARGET | 39 | 39 | 2 | 0.67 | -9 | -4.5 |
| CASTER AWAY FROM SCREEN | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| CHARGE NOW FIRST | 10 | 10 | 2 | 0.67 | -37 | -18.6 |
| FALLS SHORT | 59 | 48 | 2 | 0.67 | +0 | +0.0 |
| FRIENDS SHOTS CHECKED | 2 | 2 | 2 | 0.67 | +4 | +2.0 |
| HIS TURN DENIED | 5 | 4 | 2 | 0.67 | +82 | +40.8 |
| HUNT IN PAIRS | 4 | 4 | 2 | 0.67 | +558 | +278.9 |
| KEEP FALLS | 2 | 2 | 2 | 0.67 | +79 | +39.7 |
| MARCH CHECK | 2 | 2 | 2 | 0.67 | +61 | +30.5 |
| ONE FIGHT FORMULA | 37 | 22 | 2 | 0.67 | +1 | +0.7 |
| ONE OBJECTIVE FORMULA | 36 | 31 | 2 | 0.67 | +18 | +8.8 |
| OPENS UP | 3 | 3 | 2 | 0.67 | +37 | +18.4 |
| PROMISE SHOT AWAY | 2 | 2 | 2 | 0.67 | -2 | -1.0 |
| RISK BY ARC | 15 | 14 | 2 | 0.67 | +45 | +22.5 |
| THE ROW IN ITS ORDER | 19 | 2 | 2 | 0.67 | +0 | +0.0 |
| WHO HITS BACK | 2 | 2 | 2 | 0.67 | +253 | +126.7 |
| WHOLE FIGHT DANGER | 11 | 11 | 2 | 0.67 | +146 | +73.1 |
| AFTERMATH IN POINTS | 1 | 1 | 1 | 0.33 | +113 | +113.4 |
| ASSAILMENT BY POINTS | 1 | 1 | 1 | 0.33 | +1 | +1.1 |
| BEST PRIZE | 1 | 1 | 1 | 0.33 | -51 | -51.1 |
| CHAFF PASSED | 1 | 1 | 1 | 0.33 | -6 | -6.4 |
| EXACT ROUND | 15 | 14 | 1 | 0.33 | +6 | +5.8 |
| FALL BACK GOOD ORDER | 14 | 13 | 1 | 0.33 | +6 | +5.8 |
| HIS MOVE AND SHOT | 24 | 24 | 1 | 0.33 | +46 | +46.0 |
| MANOEUVRE | 11 | 11 | 1 | 0.33 | +6 | +5.9 |
| MARCH BY THE SUM | 1 | 1 | 1 | 0.33 | +11 | +11.4 |
| MISSILES IN THE MOVE | 17 | 10 | 1 | 0.33 | +50 | +50.1 |
| MISSILES NEXT TURN | 24 | 16 | 1 | 0.33 | +3 | +3.2 |
| MOVES UNITS SPELL | 1 | 1 | 1 | 0.33 | +55 | +55.1 |
| NEARER NOT NEEDED | 54 | 51 | 1 | 0.33 | +61 | +61.4 |
| ONE PROMISE A TARGET | 1 | 1 | 1 | 0.33 | -52 | -52.3 |
| PIVOT GUARDS FLANK | 1 | 1 | 1 | 0.33 | -4 | -3.8 |
| PROMISE KNOWS THE FIGHT | 1 | 1 | 1 | 0.33 | -2 | -2.5 |
| SECOND LOOK | 1 | 1 | 1 | 0.33 | +14 | +14.3 |
| SHOOTERS IN TWO RANKS | 1 | 1 | 1 | 0.33 | +4 | +4.0 |
| STUCK PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| SUPPORT NARROWED | 3 | 3 | 1 | 0.33 | -3 | -3.1 |
| SURE REACH TOGETHER | 6 | 6 | 1 | 0.33 | +3 | +3.0 |
| SWIFTSTRIDE BY POINTS | 1 | 1 | 1 | 0.33 | +1 | +0.9 |
| WAR ENGINE JOBS | 9 | 9 | 1 | 0.33 | -10 | -10.0 |
| WOUNDED STAYS OUT | 1 | 1 | 1 | 0.33 | -61 | -61.0 |
| ALREADY CARRIED | 2 | not checked | - | - | - | - |
| BACKUP TARGETS | 2 | 1 | 0 | 0.00 | - | - |
| BLOWS WHERE AIMED | 1 | 1 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 2 | 2 | 0 | 0.00 | - | - |
| CAST JOB | 10 | 10 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 2 | trace | - | - | - | - |
| CLOSES ON WHAT IT BEATS | 61 | 60 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 1 | not checked | - | - | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 23 | 23 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 2 | 1 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 44 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 11 | 11 | 0 | 0.00 | - | - |
| GIVES UP | 1 | 1 | 0 | 0.00 | - | - |
| GUN FIGURES | 11 | not checked | - | - | - | - |
| GUN MASK | 8 | 8 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 7 | 7 | 0 | 0.00 | - | - |
| HELPER UNSEEN | 1 | 1 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 62 | 60 | 0 | 0.00 | - | - |
| HIS CHARGE DENIED | 4 | 4 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 33 | 30 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 32 | 31 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 21 | 21 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 40 | 37 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 19 | 19 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN RUN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 133 | 133 | 0 | 0.00 | - | - |
| HONEST WORTH | 11 | 10 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 17 | 17 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 1 | 1 | 0 | 0.00 | - | - |
| LONG SHOT | 1 | 1 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 5 | 5 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 1 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 3 | 3 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 5 | 5 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 13 | 12 | 0 | 0.00 | - | - |
| NO LATE CUT | 4 | 4 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 18 | 18 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| ONE JOINT FIGURE | 1 | 1 | 0 | 0.00 | - | - |
| ONE ROUTE | 5 | 5 | 0 | 0.00 | - | - |
| OPENS A LANE | 2 | 2 | 0 | 0.00 | - | - |
| OVERRUNS AWAY | 1 | 1 | 0 | 0.00 | - | - |
| PLAN RESULT | 272 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 4 | 4 | 0 | 0.00 | - | - |
| PROMISE READS THE TABLE | 1 | 1 | 0 | 0.00 | - | - |
| RANDOM MOVE BY FIGURES | 2 | 2 | 0 | 0.00 | - | - |
| REAL GROUND | 5 | 5 | 0 | 0.00 | - | - |
| REDIRECT COUNTER | 20 | 14 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 9 | 8 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 2 | 2 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 1 | 1 | 0 | 0.00 | - | - |
| RUN DOWN | 2 | 2 | 0 | 0.00 | - | - |
| SCOUT SPOT | 6 | 6 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 4 | 4 | 0 | 0.00 | - | - |
| SEARCH SPOT | 1 | 1 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 6 | 6 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 2 | 2 | 0 | 0.00 | - | - |
| SHOOTER COUNTED ONCE | 2 | 2 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 85 | not checked | - | - | - | - |
| SHOT OR CHARGE | 3 | 3 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 44 | 39 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 4 | 4 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 18 | 18 | 0 | 0.00 | - | - |
| STANDS STILL | 260 | 257 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 15 | not checked | - | - | - | - |
| THE PROMISE ADDS | 3 | 3 | 0 | 0.00 | - | - |
| THE PROMISED MOVE | 1 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 12 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 11 | not checked | - | - | - | - |
| THE TABLE BINDS | 286 | not checked | - | - | - | - |
| WAITS AGAIN | 11 | 10 | 0 | 0.00 | - | - |
| WHAT THE JOINER ADDS | 2 | 2 | 0 | 0.00 | - | - |
| WHO FIGHTS | 4 | 4 | 0 | 0.00 | - | - |
| WHOLE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| WHOLE FIGHT GAIN | 2 | 2 | 0 | 0.00 | - | - |
| WOUNDS ON THE RANKS | 12 | 12 | 0 | 0.00 | - | - |

### Off best figure: csame-bb45c30-p38

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 4.33 | 8.00 | 29.0 |
| PROMISE BY ITS OWN SUM | rule | 5.67 | 3.00 | 49.7 |
| ARMY TABLE | rule | 1.33 | 0.67 | 93.0 |
| HOLDER ASSIGNMENT | rule | - | 1.00 | 33.7 |
| CHARGE NOW FIRST | rule | 0.33 | 0.33 | 18.6 |
| PROMISE SHOT AWAY | rule | 0.67 | - | 1.0 |
| RULE SWITCHED OFF | gate | - | 0.67 | 95.0 |
| AFTERMATH BAND | gate | - | 0.33 | 1.6 |
| BEST PRIZE | rule | - | 0.33 | 51.1 |
| CANNON PLANNED TARGET | rule | 0.33 | - | 9.1 |
| CHAFF PASSED | rule | 0.33 | - | 6.4 |
| FRIENDS SHOTS CHECKED | rule | - | 0.33 | 1.6 |
| ONE PROMISE A TARGET | rule | 0.33 | - | 52.3 |
| PIVOT GUARDS FLANK | rule | 0.33 | - | 3.8 |
| PROMISE KNOWS THE FIGHT | rule | 0.33 | - | 2.5 |
| SUPPORT NARROWED | rule | - | 0.33 | 3.1 |
| WAR ENGINE JOBS | rule | 0.33 | - | 10.0 |
| WOUNDED STAYS OUT | rule | - | 0.33 | 61.0 |

### Plans: csame-bb45c30-p38

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 2.3 | 29% | 150 | 86 | 58% |
| Mine | move | 26.0 | 95% | 1640 | 0 | 0% |
| Mine | shoot | 12.0 | 44% | 337 | 448 | 133% |
| Mine | support | 0.7 | 50% | 1 | 0 | 0% |
| Opponent | charge | 2.7 | 38% | 407 | 221 | 54% |
| Opponent | move | 37.0 | 97% | 2950 | 0 | 0% |
| Opponent | shoot | 10.0 | 53% | 554 | 684 | 123% |

### Battle groups: csame-bb45c30-p38

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 3.3 | 20% | 0% | 0% | - | 100% | 0% | 0% | 0% | 0% |
| Opponent | REDIRECT COUNTER | 3.3 | 30% | 100% | 33% | 0% | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: csame-bb45c30-p38

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Mine | Character | 7 | 55 (7) | 55 | 0 | 23 | 29% | 2.8 | 0 (1) | 0 (1) | 81 (4) | 73 (5) | 0 (1) |
| Mine | Clean-up | 4 | 0 (4) | 0 | 0 | 26 | 75% | 5.0 | 0 (1) | 0 (3) | - | 0 (3) | 0 (1) |
| Mine | Fast Hammer | 5 | 22 (5) | 22 | 0 | 84 | 80% | 2.0 | - | 46 (3) | 0 (2) | 26 (4) | 0 (1) |
| Mine | Hammer | 9 | 49 (9) | 34 | 15 | 20 | 11% | 2.8 | 0 (1) | 12 (4) | 105 (4) | 66 (7) | 0 (2) |
| Mine | Holder | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | 0 (1) | - | - | - | 0 (1) |
| Mine | War machine | 8 | 27 (8) | 27 | 0 | 38 | 0% | 1.0 | 57 (2) | 20 (5) | 0 (1) | 43 (3) | 17 (5) |
| Mine | Wizard | 5 | 65 (5) | 65 | 0 | 0 | 40% | 3.3 | 0 (1) | 0 (2) | 156 (2) | 0 (2) | 110 (3) |
| Opponent | Chaff | 5 | 17 (5) | 0 | 17 | 75 | 0% | 1.0 | 0 (1) | 22 (4) | - | 17 (5) | - |
| Opponent | Character | 8 | 30 (8) | 30 | 0 | 50 | 38% | 3.0 | 34 (3) | 21 (2) | 33 (3) | 37 (6) | 0 (2) |
| Opponent | Clean-up | 4 | 68 (4) | 0 | 68 | 14 | 75% | 4.0 | 0 (2) | 0 (1) | 139 (1) | 79 (3) | 0 (1) |
| Opponent | Fast Hammer | 6 | 0 (6) | 0 | 0 | 34 | 50% | 5.3 | 0 (3) | 0 (3) | - | 0 (2) | 0 (4) |
| Opponent | Holder | 9 | 177 (9) | 38 | 139 | 0 | 0% | 2.4 | 271 (2) | 193 (4) | 103 (3) | 273 (4) | 98 (5) |
| Opponent | Shooter | 2 | 39 (2) | 39 | 0 | 0 | 0% | 1.5 | 59 (1) | 18 (1) | - | 59 (1) | 18 (1) |
| Opponent | War machine | 3 | 0 (3) | 0 | 0 | 33 | 33% | 1.0 | 0 (3) | - | - | 0 (2) | 0 (1) |
| Opponent | Wizard | 3 | 0 (3) | 0 | 0 | 0 | 0% | 1.0 | 0 (1) | 0 (2) | - | 0 (1) | 0 (2) |

### Charged fights: csame-bb45c30-p38

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 1 | 511 | 72 | 1.0 | 1.0 | 72 | 52 | +20 | 0 of 1 | 1 of 1 | - | +20 |
| Mine | Chaos Dwarfs | 2 | 300 | 33 | 1.0 | 1.0 | 33 | 0 | +33 | 1 of 2 | 2 of 2 | - | +33 |
| **Mine** | all armies | 3 | 371 | 46 | 1.0 | 1.0 | 46 | 17 | +29 | 1 of 3 | 3 of 3 | - | +29 |
| Opponent | Empire of Man | 1 | 0 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 1 of 1 | 0 of 1 | - | +0 |
| Opponent | Tomb Kings of Khemri | 2 | 181 | 365 | 3.0 | 1.2 | 122 | 136 | -15 | 4 of 6 | 4 of 6 | -70 | -4 |
| **Opponent** | all armies | 3 | 121 | 243 | 2.3 | 1.1 | 104 | 117 | -13 | 5 of 7 | 4 of 7 | -70 | -3 |

### Effective charges: csame-bb45c30-p38

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +20) | 0 | 0% (0 of 1) |
| Mine | Chaos Dwarfs | 2 | 0 | 0 | 0 | 1 (net +0) | 1 (net +66) | 0 | 0 | 0% (0 of 2) |
| Opponent | Empire of Man | 1 | 1 (net +0) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 1) |
| Opponent | Tomb Kings of Khemri | 6 | 0 | 0 | 2 (net -35) | 2 (net -249) | 0 | 0 | 2 | 50% (2 of 4) |

### Charged fights, damage counted: csame-bb45c30-p38

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 76-89% | 1 | 91 | 195 | +0 | 0 | 74 | -74 | -81.0 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 52 | 72 | +20 | 72 | 116 | -44 | -84.1 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 310 | 66 | +66 | 66 | 0 | +66 | +21.3 |
| Mine | All fights | 3 | 151 | 111 | +29 | 46 | 63 | -17 | -11.4 |
| Opponent | Long shot (under 50%) | 1 | 189 | 314 | +0 | 131 | 105 | +26 | +13.7 |
| Opponent | Effective (55-75%) | 2 | 475 | 310 | -35 | 111 | 83 | +28 | +5.9 |
| Opponent | 76-89% | 2 | 252 | 221 | -249 | 130 | 374 | -244 | -97.2 |
| Opponent | No odds | 2 | 426 | 240 | +240 | 289 | 160 | +129 | +30.4 |
| Opponent | All fights | 7 | 356 | 265 | -13 | 170 | 191 | -21 | -6.0 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| csame-bb45c30-p38 | move | 25 | 2 (8%) | 2 (8%) | 2 (8%) | 21 (84%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Ring of Doom | Mine | L0222 |
| Twice-Blessed Armour | Opponent | L0307 |
| Witch Hunter's Ward | Opponent | L0307 |

# Doctrine scorecard: csame-bb45c30-p8

### Scorecard: csame-bb45c30-p8

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L1319 | 5 | 1 | Mine | yes | - | 3 | 2 | 3 | 0 | 0 | 0 | 140 |
| L1319 | 5 | 1 | Opponent | no | - | 2 | 2 | 5 | 0 | 0 | 0 | 0 |
| L1335 | 3 | 1 | Mine | no | 7 | 3 | 0 | 0 | 0 | 0 | 0 | 540 |
| L1335 | 3 | 1 | Opponent | no | 2 | 3 | 3 | 3 | 0 | 0 | 0 | 110 |
| L1431 | 3 | 1 | Mine | no | 2 | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| L1431 | 3 | 1 | Opponent | no | 1 | - | 4 | 0 | 2 | 0 | 0 | 0 |
| **Average** | | | Mine | 33% | 4.5 | 2.7 | 1.3 | 1.3 | 0.0 | 0.0 | 0.0 | 226.7 |
| **Average** | | | Opponent | 0% | 1.5 | 2.5 | 3.0 | 2.7 | 0.7 | 0.0 | 0.0 | 36.7 |

### KPIs: csame-bb45c30-p8

Rules off - Mine only: NO OLD ONE-MOVE GUESS; both sides: ONE RUN A PLAN.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 25% (4 of 16) | 0% (0 of 13) | 14% (4 of 29) |
| Winner chose to follow up after the loser gave ground |  | 100% (2 of 2); on the table 100% | - | 100% (2 of 2); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | 100% (1 of 1); on the table 100% | 100% (1 of 1); on the table 100% | 100% (2 of 2); on the table 100% |
| Winner chose to pursue after the loser fled |  | 25% (1 of 4); on the table 25% | 100% (1 of 1); on the table 100% | 40% (2 of 5); on the table 40% |
| Winner chose to follow up or pursue (all three) |  | 57% (4 of 7); on the table 57% | 100% (2 of 2); on the table 100% | 67% (6 of 9); on the table 67% |
| Magic missiles tried each own turn | 50%+ | 22% (4 of 18) | 50% (12 of 24) | 38% (16 of 42) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 31% (4 of 13) | 52% (12 of 23) | 44% (16 of 36) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 20% (2 of 10) | 20% (2 of 10) |
| Points that never fought | lower | 49% (2940 of 6000) | 35% (2129 of 6000) | 42% (5069 of 12000) |
|   infantry points that never fought | lower | 87% (1138 of 1315) | 61% (560 of 921) | 76% (1698 of 2236) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 60% (15 of 25) | 72% (23 of 32) | 67% (38 of 57) |
| Bound items with a magic missile used (at least once a game) |  | 100% (2 of 2); 3.7 uses a game | 50% (1 of 2); 1.0 uses a game | 75% (3 of 4); 2.3 uses a game |
| Bound items with another spell used |  | 30% (3 of 10); 1.7 uses a game | 0.0 uses a game | 30% (3 of 10); 0.8 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
|   their share of the points of units over 100 pts | lower | 58% (3306 of 5720) | 65% (3808 of 5830) | 62% (7114 of 11550) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.3 (29%) | 1.3 (33%) | 2.7 (31%) |
| MARCHED: its unit marched | 1.3 (29%) | 1.7 (42%) | 3.0 (35%) |
| CHARGED: its unit charged | 0.3 (7%) | 0.7 (17%) | 1.0 (12%) |
| IN COMBAT: engaged in combat | 0.7 (14%) | 0.0 (0%) | 0.7 (8%) |
| FLEEING: fleeing | 0.0 (0%) | 0.3 (8%) | 0.3 (4%) |
| GONE: slain | 1.0 (21%) | 0.0 (0%) | 1.0 (12%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.3 | 1.3 | 2.7 | 5.3 | 0.3 | 3.0 |
| not cast | 3.7 | 2.7 | 3.3 | 8.7 | 1.7 | 21.0 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (3%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.7 (62%) | 0.3 (10%) | 2.7 (31%) | 0.3 (20%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 3.0 (35%) | 0.7 (40%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.0 (12%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.7 (25%) | 0.0 (0%) | 0.7 (8%) | 0.7 (40%) | 0.0 (0%) |
| FLEEING: fleeing | 0.3 (9%) | 0.3 (12%) | 0.0 (0%) | 0.3 (4%) | 0.0 (0%) | 0.7 (3%) |
| GONE: slain | 1.0 (27%) | 0.0 (0%) | 1.0 (30%) | 1.0 (12%) | 0.0 (0%) | 2.0 (10%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.3 (64%) | 0.0 (0%) | 2.0 (60%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 17.7 (84%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 2.3 a game | 0.3 a game | 1.3 a game |
| stood (cast and not dispelled) | 71% (5 of 7) | - | 71% (5 of 7) |
| the unit moved after it | 40% (2 of 5) | - | 40% (2 of 5) |
| it charged on its next turn | 0% (0 of 5) | - | 0% (0 of 5) |
| the enemy charged it first | 20% (1 of 5) | - | 20% (1 of 5) |
| it fought by the end of its next turn | 20% (1 of 5) | - | 20% (1 of 5) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 5) | - | 0% (0 of 5) |
| none of these (no charge, no fight, no charge escaped) | 80% (4 of 5) | - | 80% (4 of 5) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 71% (63 of 89) | 76% (19 of 25) | 72% (82 of 114) |
|   cavalry | 92% (11 of 12) | 86% (12 of 14) | 88% (23 of 26) |
|   character | 32% (9 of 28) | 25% (1 of 4) | 31% (10 of 32) |
|   infantry | 79% (23 of 29) | 86% (6 of 7) | 81% (29 of 36) |
|   war machine | 100% (20 of 20) | - | 100% (20 of 20) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.3 (27%) | 0.3 (17%) | 2.7 (25%) |
| CHARGED: it charged | 1.3 (15%) | 0.7 (33%) | 2.0 (19%) |
| FLEEING: it fled or was fleeing | 0.0 (0%) | 0.3 (17%) | 0.3 (3%) |
| IN COMBAT: it fought this turn or the last | 1.0 (12%) | 0.0 (0%) | 1.0 (9%) |
| NO TARGET IN RANGE | 2.0 (23%) | 0.3 (17%) | 2.3 (22%) |
| ONLY IN COMBAT: the only targets were in combat | 0.3 (4%) | 0.0 (0%) | 0.3 (3%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.7 (19%) | 0.3 (17%) | 2.0 (19%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 12.7 | 0.0 | 100% | 0.0 pts | 0 pts |
| character | 5.7 | 0.7 | 94% | 5.9 pts | 33 pts |
| infantry | 16.7 | 5.7 | 72% | 10.5 pts | 174 pts |
| war machine | 6.7 | 0.3 | 95% | 0.9 pts | 6 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 2.3 | 4.3 | 3.3 |
| Charges that made contact a game | 1.7 | 3.0 | 2.3 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.33 declared, 0.00 contact (3 units) | 0.00 declared, 0.00 contact (1 units) | 0.25 declared, 0.00 contact (4 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | - | - |
|   per unit a game, the other units (no war machines, no joined characters) | 0.27 declared, 0.23 contact (22 units) | 0.57 declared, 0.39 contact (23 units) | 0.42 declared, 0.31 contact (45 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 53% (8 of 15) | 50% (1 of 2) | - | 53% (9 of 17) |
| Character in a unit | 100% (2 of 2) | 100% (2 of 2) | - | 100% (4 of 4) |
| Character on its own | 80% (4 of 5) | 75% (3 of 4) | 43% (3 of 7) | 62% (10 of 16) |
| Infantry | 83% (10 of 12) | 50% (1 of 2) | - | 79% (11 of 14) |
| Monster | 50% (1 of 2) | - | - | 50% (1 of 2) |
| Monstrous | 50% (1 of 2) | 100% (2 of 2) | - | 75% (3 of 4) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| High Elf Realms | 3 | 57% (4 of 7); on the table 57% | 22% (4 of 18) | 49% | 60% (15 of 25) | 100% (2 of 2); 3.7 uses a game | 30% (3 of 10); 1.7 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 1 | 100% (1 of 1); on the table 100% | 67% (8 of 12) | 33% | 75% (6 of 8) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Warriors of Chaos | 1 | - | 33% (2 of 6) | 10% | 75% (9 of 12) | 100% (1 of 1); 3.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 1 | 100% (1 of 1); on the table 100% | 33% (2 of 6) | 64% | 67% (8 of 12) | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (csame-bb45c30-p8, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 40% (2) | 25% (1) | 33% (3) |
| ...free all their last turn and able to turn (per game) | 0.67 | 0.33 | 1.00 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.67 | 0.00 | 0.67 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.67 | 0.67 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: csame-bb45c30-p8

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 4.0 | 3.0 |
| Strategy | Charge objectives carried out (made contact) | 40% (2 of 5) | 70% (7 of 10) |
| Strategy | Shoot objectives carried out (shot that target) | 65% (20 of 31) | 7% (1 of 14) |
| Strategy | Support requests answered (helper made contact too) | - | 100% (1 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | - | 67% (2 of 3) |
| Strategy | Joined characters whose unit fought | - | 75% (3 of 4) |
| Strategy | Lone characters that fought | 75% (6 of 8) | 88% (7 of 8) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 1.3 | 2.7 |
| Movement | Points that never moved of their own | 226.7 | 36.7 |
| Movement | Fights charged into per game | 1.3 | 2.7 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 2 | 2 of 7, net -130 |
| Movement | Charges with odds: sweet spot (55-75%) | 2 of 2, net +100 | 0 of 7 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 2 | 1 of 7, net +70 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 0 of 2 | 3 of 7, net +266 |
| Shooting | Shots by shooting units (incl. breath weapons) | 15.7 | 7.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 43% (20 of 47) | 81% (17 of 21) |
| Shooting | Points destroyed by shooting units | 0.0 | 0.0 |
| Shooting | War machine shots | 6.7 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 70% (14 of 20) | - |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | 1.0 | 2.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 33% (1 of 3) | 57% (4 of 7) |
| Magic | Wounds caused by magic missiles | 5.7 | 3.7 |
| Magic | Wounds caused by other spells | 1.7 | - |
| Magic | Points destroyed by magic (all spells) | 93.3 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 2.0 / 0.0 / 1.7 / 0.3 | 1.7 / 1.0 / 0.3 / 0.0 |
| Combat | Points destroyed in combat | 173.7 | 429.3 |
| Combat | Points run down | 0.0 | 147.3 |
| Combat | Net points per charged fight, damage counted | +9 | +76 |
| Combat | Net per 100 charger points, damage counted | +2.6 | +31.8 |
| Combat | First round won (charged fights) | 75% | 62% |
| Combat | Net points per charged fight | +36 | +119 |
| Combat | Net points per supported fight / lone fight | +0 / +48 | +177 / +111 |
| Combat | Charged fights on a top-3 enemy unit | 2 of 4 | 4 of 8 |
| Game | Points lost | 533.3 | 586.3 |
| Game | VP from objectives | 843.3 | 360.0 |
| Game | Lone holders (player turns) | 4.5 | 1.5 |

- Mine won / drew / lost: 2 / 1 / 0 of 3 ended games (of 3); mean margin (Mine - Opponent) +652 VP
- The side that went first won 1 of 2 games with a winner
- Points traded per game (both sides' losses): 1120
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: csame-bb45c30-p8

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 2.0 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| AFTERMATH WITH FRIENDS | 0.3 | +28.7 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | 32.0 | +10.1 | 0.0 | 551.0 | 24.7 | +200.1 | 0.0 | 255.0 |
| ASSAILMENT BY POINTS | 1.0 | +5.0 | 0.0 | 133.3 | 0.3 | +0.7 | 0.0 | 0.0 |
| BACKUP TARGETS | 0.7 | +3.0 | 0.0 | 0.0 | 0.7 | +0.7 | 0.0 | 0.0 |
| BEST PRIZE | - | - | - | - | 0.7 | -27.4 | 0.0 | 0.0 |
| BOUND ASSAILMENT | 0.3 | +0.1 | 0.0 | 50.3 | - | - | - | - |
| CANNON PLANNED TARGET | 6.7 | +119.2 | 76.0 | 93.3 | - | - | - | - |
| CARRIES OUT SET-UP | 0.3 | -3.5 | 18.3 | 0.0 | - | - | - | - |
| CAST JOB | - | - | - | - | 0.3 | +1.7 | 0.0 | 0.0 |
| CASTING BLOCK | - | - | - | - | 2.0 | +25.9 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 1.7 | +0.0 | 0.0 | 266.7 | 0.3 | +0.0 | 0.0 | 0.0 |
| CHALLENGE BY POINTS | - | - | - | - | 1.0 | +30.4 | 0.0 | 41.7 |
| CHAMPION KNOWS CHALLENGE | 0.7 | -3.2 | 0.0 | 0.0 | 0.3 | -1.0 | 59.0 | 0.0 |
| CHARGE LOSSES | 19.0 | -658.8 | 0.0 | 810.3 | 19.0 | -1084.2 | 0.0 | 344.0 |
| CHARGE NOW FIRST | 1.3 | +0.0 | 108.7 | 0.0 | 4.0 | +0.0 | 340.3 | 38.7 |
| CHARGER SLAIN LOST | - | - | - | - | 0.3 | -0.8 | 59.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 6.3 | +0.0 | 0.0 | 0.0 | 6.3 | +0.0 | 0.0 | 84.7 |
| COMBAT PIVOT | - | - | - | - | 0.3 | +0.0 | 47.7 | 56.7 |
| CONVEYANCE SEARCH | 1.7 | +178.3 | 266.7 | 266.7 | - | - | - | - |
| COVER ONCE | 11.3 | -864.9 | 0.0 | 109.3 | 6.7 | -570.2 | 0.0 | 67.0 |
| DENIED BY THE FIGHT | - | - | - | - | 0.7 | -0.7 | 118.0 | 0.0 |
| DEPLOY BY FIGURES | 7.3 | -21.6 | 0.0 | 0.0 | 7.7 | +43.4 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | 0.7 | -49.4 | 41.7 | 147.3 | 0.3 | -19.0 | 59.0 | 0.0 |
| EDGE GIVE GROUND | - | - | - | - | 0.3 | +10.4 | 0.0 | 0.0 |
| EVASIVE BY THE ODDS | - | - | - | - | 4.3 | +65.3 | 180.0 | 0.0 |
| EXACT ROUND | 0.3 | +0.4 | 18.3 | 0.0 | 2.3 | +51.7 | 280.7 | 38.7 |
| FACES THE THREAT | - | - | - | - | 0.7 | +0.0 | 0.0 | 38.7 |
| FALL BACK GOOD ORDER | 1.0 | +0.0 | 18.3 | 147.3 | 2.0 | +0.2 | 206.3 | 38.7 |
| FALLS SHORT | - | - | - | - | 18.0 | +286.5 | 0.0 | 428.0 |
| FEATURE BUFFS | 0.7 | +7.3 | 0.0 | 0.0 | 1.7 | +11.6 | 0.0 | 55.0 |
| FIGHT TO THE END | 1.0 | +24.3 | 0.0 | 147.3 | 0.7 | +4.7 | 50.3 | 0.0 |
| FIRE IN ORDER | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FIVE ACTION | 97.7 | +6314.8 | 425.7 | 1576.7 | 71.7 | +5532.3 | 982.3 | 768.7 |
| FLANK NOT WEIGHED | 8.7 | +0.0 | 0.0 | 50.3 | 7.0 | +0.0 | 0.0 | 18.3 |
| FOLLOW UP WEIGHED | 0.3 | +115.4 | 0.0 | 0.0 | - | - | - | - |
| FOUR ROUNDS | 2.3 | +368.9 | 127.0 | 147.3 | 3.3 | +234.1 | 398.7 | 86.7 |
| FREED FROM HIS FIGHT | 2.0 | +0.0 | 0.0 | 0.0 | 5.0 | +0.0 | 0.0 | 55.0 |
| FRIEND SHOOTS FIRST | 1.3 | -8.1 | 0.0 | 0.0 | 0.7 | -2.3 | 0.0 | 0.0 |
| FRIENDS SHOTS CHECKED | 0.3 | +0.5 | 0.0 | 0.0 | - | - | - | - |
| GIVES UP | 0.3 | -11.3 | 0.0 | 147.3 | - | - | - | - |
| GOAL WALK | 5.3 | +224.7 | 0.0 | 0.0 | 8.0 | +326.8 | 0.0 | 67.0 |
| GUN MASK | 2.3 | +10.7 | 0.0 | 50.3 | - | - | - | - |
| HARD STAY DROPPED | 4.7 | +0.0 | 0.0 | 266.7 | 2.3 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 0.7 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 10.7 | +0.0 | 0.0 | 298.3 | 11.0 | +0.0 | 0.0 | 268.0 |
| HIS CHARGE DENIED | - | - | - | - | 0.3 | +0.6 | 0.0 | 48.0 |
| HIS CHARGE LIST | 2.3 | +0.0 | 0.0 | 50.3 | 3.0 | +0.0 | 0.0 | 56.7 |
| HIS LEGAL MOVES | 6.0 | +0.0 | 0.0 | 197.7 | 1.0 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 2.7 | -19.7 | 0.0 | 148.3 | 4.7 | -22.9 | 0.0 | 134.0 |
| HIS MOVE AS HE DECIDES | 38.0 | +7.0 | 420.0 | 0.0 | - | - | - | - |
| HIS MOVE WHY | - | - | - | - | 8.3 | +0.0 | 0.0 | 240.3 |
| HIS ONE MOVE | 23.3 | -87.4 | 0.0 | 390.0 | - | - | - | - |
| HIS ONE QUARTER | 6.0 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 1.3 | +0.0 | 0.0 | 50.3 | 4.0 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVE | 16.7 | +0.0 | 0.0 | 95.3 | - | - | - | - |
| HIS RANDOM MOVER COMES | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 40.7 | +1229.3 | 0.0 | 830.0 | 43.0 | +1166.3 | 0.0 | 529.7 |
| HIS SHOTS BY HIS RUN | 40.7 | +931.5 | 0.0 | 1124.7 | 51.3 | +1104.9 | 0.0 | 643.3 |
| HIS TURN DENIED | 0.7 | +3.5 | 0.0 | 147.3 | 1.3 | +90.5 | 164.7 | 0.0 |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 16.7 | +0.0 | 0.0 | 0.0 | 9.3 | +0.0 | 0.0 | 244.0 |
| HOLDER ASSIGNMENT | 9.7 | +748.0 | 0.0 | 0.0 | 5.3 | +393.6 | 0.0 | 103.7 |
| HOLDS AMBUSHERS | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 2.3 | -107.6 | 127.0 | 147.3 | 2.0 | -61.2 | 339.7 | 0.0 |
| IDLE COST | - | - | - | - | 11.3 | -132.9 | 0.0 | 172.7 |
| JOINT CHARGE NOW | 0.3 | -18.4 | 0.0 | 0.0 | 1.0 | +37.6 | 168.3 | 0.0 |
| JOINT KNOWS CHALLENGE | - | - | - | - | 0.3 | -5.4 | 50.3 | 0.0 |
| KEPT FROM ITS LAST STOP | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| LANE BY FIGURES | 1.3 | +97.5 | 0.0 | 0.0 | 0.3 | +7.0 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 7.7 | +0.0 | 212.0 | 231.3 | 2.7 | +0.0 | 115.7 | 79.7 |
| LONE CHARACTER SAFE SPOT | - | - | - | - | 1.0 | +6.4 | 201.0 | 0.0 |
| LOST AFTER ESCAPE | 1.0 | -1.6 | 0.0 | 147.3 | 2.0 | +2.5 | 218.7 | 38.7 |
| MAKE SURE TOGETHER | 0.7 | +7.5 | 0.0 | 0.0 | 0.3 | +0.5 | 0.0 | 0.0 |
| MANOEUVRE | 2.0 | +0.0 | 0.0 | 50.3 | 0.7 | +3.2 | 0.0 | 0.0 |
| MARCH AT ESCAPER | - | - | - | - | 1.0 | +33.9 | 0.0 | 0.0 |
| MARCH BY THE SUM | 0.3 | +22.4 | 0.0 | 0.0 | 1.3 | +32.5 | 0.0 | 0.0 |
| MARCH CHECK | - | - | - | - | 1.3 | +44.6 | 0.0 | 0.0 |
| MARCH OF THE TABLE | 0.7 | +63.2 | 0.0 | 0.0 | 0.3 | +6.0 | 0.0 | 0.0 |
| MARCH OVER CASTS | 0.7 | -2.9 | 0.0 | 0.0 | 2.3 | +165.5 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MAX FOR POSITIONING | 3.3 | +82.8 | 0.0 | 0.0 | 2.7 | +89.4 | 0.0 | 0.0 |
| MEETS IN TIME | 3.3 | +197.2 | 0.0 | 0.0 | 4.3 | +88.5 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 5.3 | +77.6 | 0.0 | 266.7 | 5.0 | +133.2 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 6.7 | +47.9 | 0.0 | 266.7 | 6.3 | +142.5 | 0.0 | 0.0 |
| MOVE ORDER | 0.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| MOVE SPELL SPOT | 1.7 | +0.0 | 0.0 | 266.7 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 7.3 | +472.8 | 0.0 | 390.0 | 4.3 | +354.3 | 0.0 | 0.0 |
| MOVES UNITS SPELL | - | - | - | - | 0.3 | +1.4 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 6.3 | +280.1 | 0.0 | 50.3 | 4.3 | +164.0 | 0.0 | 133.3 |
| NEXT CHARGE BY LIST | 2.0 | +168.0 | 0.0 | 0.0 | 3.0 | +319.7 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 1.7 | -88.4 | 127.0 | 0.0 | 3.3 | -112.5 | 398.7 | 86.7 |
| NO OLD ONE-MOVE GUESS | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 0.3 | -0.2 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 7.7 | -402.2 | 41.7 | 156.7 | 2.3 | -89.0 | 0.0 | 38.7 |
| ONE CHALLENGE TEST | - | - | - | - | 0.3 | -1.0 | 59.0 | 0.0 |
| ONE CHECK AFTER THE LAST CHANGE | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 6.0 | -142.6 | 0.0 | 195.0 | 6.0 | -137.2 | 0.0 | 105.7 |
| ONE JOINT FIGURE | - | - | - | - | 0.3 | +4.1 | 59.0 | 0.0 |
| ONE OBJECTIVE FORMULA | 5.0 | +1.0 | 0.0 | 0.0 | 2.0 | +3.5 | 0.0 | 67.0 |
| ONE ROUTE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| OPENS UP | - | - | - | - | 0.7 | +34.2 | 46.7 | 0.0 |
| OVERRUNS AWAY | - | - | - | - | 1.3 | +9.4 | 215.7 | 0.0 |
| PATHS CROSS | - | - | - | - | 0.3 | +34.1 | 0.0 | 0.0 |
| PLAN RESULT | 42.7 | +428.6 | 173.3 | 1061.0 | 37.0 | +481.1 | 614.0 | 572.0 |
| PROMISE BELOW ZERO | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE BY ITS OWN SUM | 11.3 | -313.1 | 0.0 | 390.0 | 6.0 | -16.1 | 0.0 | 0.0 |
| PROMISE IN STEPS | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE KNOWS THE FIGHT | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE READS THE TABLE | 0.3 | -3.6 | 0.0 | 0.0 | 0.7 | -36.3 | 0.0 | 0.0 |
| PROMISE SHOT AWAY | 1.0 | -12.2 | 111.3 | 0.0 | - | - | - | - |
| QUARTER ODDS | 28.3 | +3533.5 | 0.0 | 306.7 | 20.3 | +2324.5 | 141.3 | 48.0 |
| RANDOM MOVE BY FIGURES | - | - | - | - | 3.3 | +12.7 | 0.0 | 56.7 |
| REAL GROUND | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| REDIRECT COUNTER | - | - | - | - | 1.7 | +367.2 | 0.0 | 36.7 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 1.3 | +0.0 | 0.0 | 36.7 |
| REDIRECT WEIGHED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| REFORMS TO MEET IT | 2.7 | -34.4 | 0.0 | 95.3 | 1.0 | -4.7 | 0.0 | 0.0 |
| REFUSING RETIRES | 1.0 | +0.0 | 0.0 | 59.0 | - | - | - | - |
| RISK BY ARC | 2.0 | +41.7 | 127.0 | 147.3 | 2.7 | +59.0 | 325.0 | 86.7 |
| RISK ON THE WAY | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ROUNDS AFTER TERROR | 0.7 | -26.0 | 67.0 | 147.3 | 0.7 | -6.8 | 156.7 | 0.0 |
| RUN DOWN | 2.0 | -86.3 | 127.0 | 0.0 | 2.7 | -12.1 | 375.3 | 38.7 |
| SEARCH SPOT | 0.3 | +0.4 | 0.0 | 0.0 | 0.7 | +41.4 | 0.0 | 0.0 |
| SECOND LOOK | 0.7 | +12.5 | 41.7 | 0.0 | - | - | - | - |
| SELF MOVE SPELL | - | - | - | - | 2.0 | +2.3 | 0.0 | 0.0 |
| SET CREDITED ONCE | 2.0 | -61.5 | 0.0 | 0.0 | 2.0 | -147.0 | 0.0 | 0.0 |
| SET UP BY THE SET | 2.0 | +41.5 | 0.0 | 0.0 | 3.3 | +188.8 | 0.0 | 77.3 |
| SET UP TOGETHER | 1.0 | +7.9 | 0.0 | 0.0 | 0.7 | +1.3 | 0.0 | 0.0 |
| SET-UP ANY TARGET | 0.3 | +18.5 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | - | - | - | - | 0.3 | +0.3 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 10.0 | +0.0 | 0.0 | 152.3 | 5.7 | +0.0 | 0.0 | 38.7 |
| SHOOTS FROM THE BEST SPOT | 2.3 | +78.0 | 0.0 | 118.0 | 2.3 | +275.5 | 0.0 | 0.0 |
| SHOT OR CHARGE | - | - | - | - | 0.7 | -13.2 | 183.7 | 0.0 |
| SHOT RISK POINTS | 28.7 | -283.4 | 0.0 | 973.7 | 25.0 | -336.9 | 0.0 | 437.7 |
| SHOTS AFTER THE MOVES | 5.7 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 21.3 | +507.4 | 0.0 | 419.0 | 6.7 | +457.4 | 0.0 | 74.7 |
| SPELL SETS UP CHARGE | 0.3 | +18.5 | 0.0 | 0.0 | - | - | - | - |
| SPELL WORTH | 2.7 | +68.4 | 266.7 | 266.7 | 1.7 | +11.5 | 0.0 | 0.0 |
| SPELLS IN THE FIGHT | - | - | - | - | 1.3 | -18.5 | 100.7 | 38.7 |
| SPOT AS THE GAME MOVES | 4.3 | +0.0 | 0.0 | 50.3 | 8.7 | +0.0 | 0.0 | 142.0 |
| STAND AND SHOOT | - | - | - | - | 0.7 | -16.8 | 82.3 | 0.0 |
| STANDS FOR A REASON | - | - | - | - | 3.3 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 48.7 | +0.0 | 298.7 | 704.7 | 20.3 | +0.0 | 583.7 | 158.0 |
| STAY WORTH | 26.0 | -9.5 | 298.7 | 273.3 | 9.7 | +119.1 | 583.7 | 74.7 |
| STRIKE BY THE ODDS | 0.3 | +10.3 | 0.0 | 147.3 | - | - | - | - |
| STUCK PIVOT | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 4.3 | +234.3 | 0.0 | 50.3 | 6.0 | +1201.8 | 0.0 | 153.0 |
| SUPPORT NARROWED | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 23.3 | 38.7 |
| SUPPORT WORKED OUT | 4.3 | +234.3 | 0.0 | 50.3 | 6.0 | +1201.8 | 0.0 | 153.0 |
| SURE REACH TOGETHER | 1.0 | +1.0 | 0.0 | 0.0 | 1.3 | +4.4 | 0.0 | 0.0 |
| SWIFTSTRIDE BY POINTS | - | - | - | - | 0.3 | +21.2 | 0.0 | 67.0 |
| THE DEARER SUM KEEPS ITS PLAN | 2.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 2.7 | +0.0 | 0.0 | 50.3 | 2.3 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 3.3 | +0.0 | 0.0 | 50.3 | 4.0 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 1.3 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 47.7 | +0.0 | 0.0 | 714.7 | 33.7 | +0.0 | 0.0 | 370.7 |
| TIED UP BY THE SUM | 1.0 | +90.6 | 60.0 | 0.0 | 0.3 | +32.0 | 23.3 | 0.0 |
| TIME ON OUR SIDE | 46.7 | +530.2 | 73.3 | 1098.3 | - | - | - | - |
| WAITS AGAIN | 0.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 38.7 |
| WHO FIGHTS | - | - | - | - | 0.3 | -2.6 | 0.0 | 0.0 |
| WHO HITS BACK | 1.3 | +69.2 | 0.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT DANGER | 3.0 | -201.6 | 0.0 | 151.0 | 2.3 | -517.4 | 0.0 | 67.0 |
| WHOLE FIGHT GAIN | - | - | - | - | 0.3 | +0.9 | 50.3 | 0.0 |
| WOUNDS ON THE RANKS | - | - | - | - | 4.0 | +201.7 | 0.0 | 268.0 |

### Rule changes: csame-bb45c30-p8

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 170 | 170 | 117 | 39.00 | +2059 | +17.6 |
| HIS MOVE AS HE DECIDES | 114 | 114 | 93 | 31.00 | +0 | +0.0 |
| HIS SHOTS BY HIS RUN | 276 | 262 | 54 | 18.00 | +537 | +9.9 |
| HIS SHOT LIST | 251 | 237 | 52 | 17.33 | +1190 | +22.9 |
| HOLDER ASSIGNMENT | 45 | 45 | 38 | 12.67 | +1905 | +50.1 |
| FIVE ACTION | 508 | 487 | 32 | 10.67 | +1413 | +44.1 |
| LEGAL CHARGES ONLY | 31 | 31 | 31 | 10.33 | +0 | +0.0 |
| OFF BEST | 30 | 30 | 30 | 10.00 | -1474 | -49.1 |
| THE TABLE AGAIN | 36 | 36 | 29 | 9.67 | +0 | +0.0 |
| DEPLOY BY FIGURES | 45 | 45 | 26 | 8.67 | +294 | +11.3 |
| MOVE TO CHARGE COMPUTED | 35 | 31 | 23 | 7.67 | +686 | +29.8 |
| HARD STAY DROPPED | 21 | 21 | 21 | 7.00 | +0 | +0.0 |
| HIS MOVE WHY | 25 | 25 | 21 | 7.00 | +0 | +0.0 |
| QUARTER ODDS | 146 | 135 | 19 | 6.33 | +1448 | +76.2 |
| HIS ONE MOVE | 70 | 66 | 18 | 6.00 | +0 | +0.0 |
| PROMISE BY ITS OWN SUM | 52 | 52 | 18 | 6.00 | -987 | -54.9 |
| SHOT RISK POINTS | 161 | 151 | 18 | 6.00 | +311 | +17.3 |
| SHOOTS FROM THE BEST SPOT | 14 | 14 | 13 | 4.33 | +345 | +26.5 |
| ADVANCE LANE KEPT | 12 | 12 | 12 | 4.00 | +0 | +0.0 |
| NEXT CHARGE BY LIST | 15 | 14 | 12 | 4.00 | +574 | +47.8 |
| COVER ONCE | 54 | 35 | 11 | 3.67 | +395 | +35.9 |
| FOUR ROUNDS | 17 | 15 | 10 | 3.33 | +602 | +60.2 |
| MEETS IN TIME | 23 | 23 | 8 | 2.67 | +188 | +23.5 |
| CHARGE LOSSES | 114 | 109 | 7 | 2.33 | +846 | +120.8 |
| TIME ON OUR SIDE | 140 | 117 | 7 | 2.33 | +40 | +5.7 |
| WHOLE FIGHT DANGER | 16 | 16 | 7 | 2.33 | +324 | +46.3 |
| MOVE ORDER | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| SET UP BY THE SET | 16 | 15 | 6 | 2.00 | +613 | +102.1 |
| SUPPORT ADDS | 31 | 30 | 6 | 2.00 | +278 | +46.4 |
| SUPPORT WORKED OUT | 31 | 30 | 6 | 2.00 | +278 | +46.4 |
| LANE BY FIGURES | 5 | 5 | 5 | 1.67 | +314 | +62.7 |
| MARCH BY THE SUM | 5 | 5 | 5 | 1.67 | +165 | +32.9 |
| RISK BY ARC | 14 | 12 | 5 | 1.67 | +78 | +15.7 |
| ASSAILMENT BY POINTS | 4 | 4 | 4 | 1.33 | +17 | +4.3 |
| EVASIVE BY THE ODDS | 13 | 13 | 4 | 1.33 | +99 | +24.7 |
| GOAL WALK | 40 | 40 | 4 | 1.33 | +275 | +68.7 |
| JOINT CHARGE NOW | 4 | 4 | 4 | 1.33 | +58 | +14.4 |
| MAX FOR POSITIONING | 18 | 15 | 4 | 1.33 | +40 | +10.0 |
| REDIRECT FOR A FRIEND IN REACH | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| SHOTS IN THE MOVE | 84 | 57 | 4 | 1.33 | +170 | +42.5 |
| WHO HITS BACK | 4 | 4 | 4 | 1.33 | +149 | +37.3 |
| CHALLENGE BY POINTS | 3 | 3 | 3 | 1.00 | +91 | +30.4 |
| HOLDS AMBUSHERS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| IDLE COST | 34 | 24 | 3 | 1.00 | +0 | +0.1 |
| MARCH OF THE TABLE | 3 | 3 | 3 | 1.00 | -208 | -69.2 |
| PROMISE SHOT AWAY | 3 | 3 | 3 | 1.00 | -36 | -12.2 |
| BEST PRIZE | 2 | 2 | 2 | 0.67 | -82 | -41.1 |
| CASTING BLOCK | 6 | 6 | 2 | 0.67 | +0 | +0.0 |
| CHARGE NOW FIRST | 16 | 16 | 2 | 0.67 | -42 | -20.8 |
| EXACT ROUND | 8 | 7 | 2 | 0.67 | +24 | +12.2 |
| FACES THE THREAT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| FALLS SHORT | 54 | 49 | 2 | 0.67 | +43 | +21.4 |
| MANOEUVRE | 8 | 8 | 2 | 0.67 | +10 | +4.9 |
| MARCH CHECK | 4 | 4 | 2 | 0.67 | +65 | +32.5 |
| NO DOUBLE ROUNDS | 15 | 13 | 2 | 0.67 | +101 | +50.3 |
| PROMISE READS THE TABLE | 3 | 3 | 2 | 0.67 | -92 | -46.2 |
| RANDOM MOVE BY FIGURES | 10 | 10 | 2 | 0.67 | +38 | +19.0 |
| REDIRECT COUNTER | 5 | 5 | 2 | 0.67 | +49 | +24.3 |
| REFORMS TO MEET IT | 11 | 7 | 2 | 0.67 | +5 | +2.4 |
| REFUSING RETIRES | 3 | 3 | 2 | 0.67 | -11 | -5.6 |
| SEARCH SPOT | 3 | 3 | 2 | 0.67 | +125 | +62.7 |
| SECOND LOOK | 2 | 2 | 2 | 0.67 | +38 | +18.8 |
| SHOTS AFTER THE MOVES | 22 | 22 | 2 | 0.67 | +0 | +0.0 |
| STUCK PIVOT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| TIED UP BY THE SUM | 4 | 2 | 2 | 0.67 | +65 | +32.6 |
| AFTERMATH WITH FRIENDS | 1 | 1 | 1 | 0.33 | +86 | +86.2 |
| BOUND ASSAILMENT | 1 | 1 | 1 | 0.33 | +0 | +0.2 |
| CARRIES OUT SET-UP | 1 | 1 | 1 | 0.33 | -10 | -10.5 |
| CAST JOB | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| COMBAT PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| EDGE GIVE GROUND | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FIGHT TO THE END | 5 | 5 | 1 | 0.33 | +0 | +0.0 |
| FIRE IN ORDER | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 1 | 1 | 1 | 0.33 | +346 | +346.1 |
| FRIENDS SHOTS CHECKED | 1 | 1 | 1 | 0.33 | +2 | +1.5 |
| GUN MASK | 7 | 7 | 1 | 0.33 | +6 | +5.7 |
| MISSILES IN THE MOVE | 31 | 19 | 1 | 0.33 | +2 | +2.3 |
| MOVES UNITS SPELL | 1 | 1 | 1 | 0.33 | +4 | +4.3 |
| NEARER NOT NEEDED | 32 | 32 | 1 | 0.33 | +61 | +61.2 |
| OPENS UP | 2 | 2 | 1 | 0.33 | +29 | +29.2 |
| OVERRUNS AWAY | 4 | 4 | 1 | 0.33 | +0 | +0.0 |
| PATHS CROSS | 1 | 1 | 1 | 0.33 | +102 | +102.2 |
| REDIRECT WEIGHED | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| SHOOTERS IN TWO RANKS | 1 | 1 | 1 | 0.33 | +1 | +1.0 |
| STRIKE BY THE ODDS | 1 | 1 | 1 | 0.33 | +31 | +31.0 |
| SUPPORT NARROWED | 3 | 3 | 1 | 0.33 | -326 | -325.7 |
| SWIFTSTRIDE BY POINTS | 1 | 1 | 1 | 0.33 | +64 | +63.7 |
| THE ROW IN ITS ORDER | 15 | 1 | 1 | 0.33 | +0 | +0.0 |
| WOUNDS ON THE RANKS | 12 | 12 | 1 | 0.33 | +10 | +10.0 |
| BACKUP TARGETS | 4 | 3 | 0 | 0.00 | - | - |
| CANNON PLANNED TARGET | 20 | 20 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 6 | trace | - | - | - | - |
| CHAMPION KNOWS CHALLENGE | 3 | 3 | 0 | 0.00 | - | - |
| CHARGER SLAIN LOST | 1 | 1 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 38 | 38 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 5 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 3 | 2 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 9 | 8 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 7 | 7 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 47 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 21 | 21 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 6 | 5 | 0 | 0.00 | - | - |
| GIVES UP | 1 | 1 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 14 | 14 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 65 | 62 | 0 | 0.00 | - | - |
| HIS CHARGE DENIED | 1 | 1 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 16 | 16 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 21 | 20 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 22 | 19 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 30 | 27 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 16 | 16 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 50 | 43 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 4 | 4 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 6 | 6 | 0 | 0.00 | - | - |
| HIS TURN RUN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 78 | 78 | 0 | 0.00 | - | - |
| HONEST WORTH | 13 | 11 | 0 | 0.00 | - | - |
| JOINT KNOWS CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 2 | 2 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 3 | not checked | - | - | - | - |
| LOST AFTER ESCAPE | 9 | 9 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 3 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 3 | trace | - | - | - | - |
| MARCH OVER CASTS | 9 | 9 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 1 | 1 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 39 | 26 | 0 | 0.00 | - | - |
| MOVE SPELL SPOT | 5 | not checked | - | - | - | - |
| NO OLD ONE-MOVE GUESS | 18 | 18 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 1 | not checked | - | - | - | - |
| ONE CHALLENGE TEST | 1 | 1 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 1 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 36 | 20 | 0 | 0.00 | - | - |
| ONE JOINT FIGURE | 1 | 1 | 0 | 0.00 | - | - |
| ONE OBJECTIVE FORMULA | 21 | 14 | 0 | 0.00 | - | - |
| ONE ROUTE | 1 | 1 | 0 | 0.00 | - | - |
| PLAN RESULT | 239 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE IN STEPS | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE KNOWS THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| REAL GROUND | 1 | 1 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 1 | 1 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 4 | 4 | 0 | 0.00 | - | - |
| RUN DOWN | 14 | 12 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 6 | not checked | - | - | - | - |
| SET CREDITED ONCE | 12 | 11 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 5 | 2 | 0 | 0.00 | - | - |
| SET-UP ANY TARGET | 1 | not checked | - | - | - | - |
| SHOOTERS ON THE TABLE | 47 | not checked | - | - | - | - |
| SHOT OR CHARGE | 2 | 2 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 1 | not checked | - | - | - | - |
| SPELL WORTH | 13 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 4 | 4 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 39 | 37 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 2 | 2 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 10 | 10 | 0 | 0.00 | - | - |
| STANDS STILL | 207 | 200 | 0 | 0.00 | - | - |
| STAY WORTH | 107 | 94 | 0 | 0.00 | - | - |
| SURE REACH TOGETHER | 7 | 6 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 9 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 22 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 13 | not checked | - | - | - | - |
| THE TABLE BINDS | 244 | not checked | - | - | - | - |
| WAITS AGAIN | 6 | 6 | 0 | 0.00 | - | - |
| WHO FIGHTS | 1 | 1 | 0 | 0.00 | - | - |
| WHOLE FIGHT GAIN | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: csame-bb45c30-p8

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 5.67 | 2.00 | 51.6 |
| ARMY TABLE | rule | 3.67 | 2.33 | 75.5 |
| PROMISE BY ITS OWN SUM | rule | 5.33 | 0.67 | 54.9 |
| RULE SWITCHED OFF | gate | 2.00 | - | 46.1 |
| JOINT CHARGE NOW | rule | 0.33 | 0.67 | 30.4 |
| MARCH OF THE TABLE | rule | 0.67 | 0.33 | 69.2 |
| PROMISE SHOT AWAY | rule | 1.00 | - | 12.2 |
| BEST PRIZE | rule | - | 0.67 | 41.1 |
| CHARGE NOW FIRST | rule | 0.33 | 0.33 | 20.8 |
| PROMISE READS THE TABLE | rule | - | 0.67 | 46.2 |
| REFUSING RETIRES | rule | 0.67 | - | 5.6 |
| CARRIES OUT SET-UP | rule | 0.33 | - | 10.5 |
| DEPLOY BY FIGURES | rule | - | 0.33 | 6.7 |
| HOLDER ASSIGNMENT | rule | 0.33 | - | 10.4 |
| LONE CHARACTER SAFE SPOT | gate | - | 0.33 | 10.3 |
| SUPPORT NARROWED | rule | - | 0.33 | 325.7 |

### Plans: csame-bb45c30-p8

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 2.0 | 33% | 260 | 110 | 42% |
| Mine | move | 32.3 | 97% | 1629 | 0 | 0% |
| Mine | shoot | 8.3 | 32% | 167 | 319 | 191% |
| Opponent | charge | 2.3 | 43% | 196 | 237 | 121% |
| Opponent | join | 2.3 | 100% | 108 | 0 | 0% |
| Opponent | move | 28.7 | 92% | 2387 | 0 | 0% |
| Opponent | shoot | 3.7 | 36% | 412 | 244 | 59% |

### Battle groups: csame-bb45c30-p8

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | REDIRECT COUNTER | 1.7 | 20% | 100% | 0% | - | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: csame-bb45c30-p8

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Character | 8 | 47 (8) | 47 | 0 | 40 | 12% | 2.1 | 50 (6) | 35 (2) | - | 0 (2) | 60 (6) |
| Mine | Clean-up | 3 | 69 (3) | 0 | 69 | 37 | 0% | 1.7 | 110 (2) | 0 (1) | - | 110 (2) | 0 (1) |
| Mine | Fast Hammer | 7 | 48 (7) | 11 | 37 | 14 | 57% | 3.0 | 66 (3) | 46 (3) | 0 (1) | 99 (2) | 28 (5) |
| Mine | Holder | 2 | 59 (2) | 0 | 59 | 0 | 100% | - | 59 (2) | - | - | 59 (2) | - |
| Mine | Shooter | 5 | 13 (5) | 13 | 0 | 21 | 0% | 1.4 | 0 (4) | 68 (1) | - | 0 (4) | 68 (1) |
| Mine | War machine | 4 | 0 (4) | 0 | 0 | 50 | 0% | 1.0 | 0 (2) | 0 (2) | - | 0 (2) | 0 (2) |
| Opponent | Chaff | 3 | 0 (3) | 0 | 0 | 65 | 100% | - | 0 (3) | - | - | 0 (3) | - |
| Opponent | Character | 9 | 47 (9) | 47 | 0 | 46 | 0% | 2.7 | 79 (3) | 25 (4) | - | 93 (3) | 47 (4) |
| Opponent | Clean-up | 3 | 46 (3) | 46 | 0 | 0 | 33% | 1.5 | - | 46 (3) | - | 148 (1) | 0 (2) |
| Opponent | Fast Hammer | 3 | 93 (3) | 63 | 30 | 29 | 0% | 2.3 | 133 (1) | 81 (2) | - | 129 (1) | 58 (2) |
| Opponent | Hammer | 8 | 11 (8) | 11 | 0 | 22 | 50% | 3.5 | 0 (4) | 42 (2) | 0 (2) | 16 (5) | 0 (3) |
| Opponent | Holder | 3 | 24 (3) | 16 | 7 | 35 | 0% | 5.3 | - | 0 (1) | 36 (2) | 67 (1) | 0 (2) |
| Opponent | Shooter | 3 | 25 (3) | 0 | 25 | 62 | 0% | 1.3 | - | 35 (2) | 0 (1) | - | 25 (3) |
| Opponent | Wizard | 3 | 0 (3) | 0 | 0 | 0 | 33% | 1.0 | 0 (1) | 0 (2) | - | 0 (2) | 0 (1) |

### Charged fights: csame-bb45c30-p8

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | High Elf Realms | 3 | 93 | 196 | 1.3 | 1.2 | 147 | 110 | +36 | 2 of 4 | 3 of 4 | +0 | +48 |
| Opponent | Orc & Goblin Tribes | 1 | 0 | 417 | 2.0 | 1.0 | 208 | 0 | +208 | 1 of 2 | 1 of 2 | - | +208 |
| Opponent | Warriors of Chaos | 1 | 0 | 177 | 3.0 | 1.3 | 59 | 87 | -28 | 2 of 3 | 1 of 3 | +177 | -130 |
| Opponent | Wood Elf Realms | 1 | 0 | 621 | 3.0 | 1.0 | 207 | 0 | +207 | 1 of 3 | 3 of 3 | - | +207 |
| **Opponent** | all armies | 3 | 0 | 405 | 2.7 | 1.1 | 152 | 32 | +119 | 4 of 8 | 5 of 8 | +177 | +111 |

### Effective charges: csame-bb45c30-p8

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | High Elf Realms | 4 | 0 | 0 | 2 (net +100) | 0 | 0 | 0 | 2 | 100% (2 of 2) |
| Opponent | Orc & Goblin Tribes | 2 | 0 | 0 | 0 | 0 | 1 (net +70) | 0 | 1 | 0% (0 of 1) |
| Opponent | Warriors of Chaos | 3 | 2 (net -130) | 0 | 0 | 0 | 0 | 1 (net +177) | 0 | 0% (0 of 3) |
| Opponent | Wood Elf Realms | 3 | 0 | 1 (net +0) | 0 | 0 | 0 | 2 (net +310) | 0 | 0% (0 of 3) |

### Charged fights, damage counted: csame-bb45c30-p8

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Effective (55-75%) | 2 | 392 | 158 | +100 | 130 | 15 | +114 | +29.2 |
| Mine | No odds | 2 | 294 | 234 | -28 | 227 | 324 | -97 | -32.8 |
| Mine | All fights | 4 | 343 | 196 | +36 | 178 | 170 | +9 | +2.6 |
| Opponent | Long shot (under 50%) | 2 | 130 | 316 | -130 | 0 | 178 | -178 | -136.9 |
| Opponent | 50-54% | 1 | 102 | 151 | +0 | 0 | 0 | +0 | +0.0 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 | 287 | 243 | +266 | 304 | 87 | +217 | +75.5 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 350 | 70 | +70 | 70 | 0 | +70 | +20.0 |
| Opponent | No odds | 1 | 350 | 247 | +347 | 347 | 100 | +247 | +70.6 |
| Opponent | All fights | 8 | 240 | 228 | +119 | 166 | 90 | +76 | +31.8 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| csame-bb45c30-p8 | move | 27 | 4 (15%) | 4 (15%) | 6 (22%) | 17 (63%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Elixir of Power | Opponent | L1319 |
| Opal Amulet | Mine | L1431 |
| Ring of Doom | Opponent | L1431 |
| Standard of the Fell Warrior | Mine | L1319, L1335 |

# Doctrine scorecard: csame-bb45c30-p23

### Scorecard: csame-bb45c30-p23

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L2131 | 1 | 1 | Mine | yes | 9 | - | 2 | 3 | 0 | 0 | 0 | 410 |
| L2131 | 1 | 1 | Opponent | no | 0 | - | 0 | 2 | 1 | 0 | 0 | 170 |
| L2235 | 3 | 1 | Mine | no | 0 | 2 | 1 | 0 | 1 | 0 | 0 | 0 |
| L2235 | 3 | 1 | Opponent | no | 1 | 4 | 3 | 1 | 0 | 0 | 0 | 0 |
| L2429 | 5 | 1 | Mine | yes | - | - | 1 | 4 | 0 | 0 | 0 | 0 |
| L2429 | 5 | 1 | Opponent | yes | - | 3 | 3 | 6 | 1 | 0 | 0 | 0 |
| **Average** | | | Mine | 67% | 4.5 | 2.0 | 1.3 | 2.3 | 0.3 | 0.0 | 0.0 | 136.7 |
| **Average** | | | Opponent | 33% | 0.5 | 3.5 | 2.0 | 3.0 | 0.7 | 0.0 | 0.0 | 56.7 |

### KPIs: csame-bb45c30-p23

Rules off - Mine only: NO OLD ONE-MOVE GUESS; both sides: ONE RUN A PLAN.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 15) | 0% (0 of 15) | 0% (0 of 30) |
| Winner chose to follow up after the loser gave ground |  | 75% (3 of 4); on the table 100% | - | 75% (3 of 4); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | 67% (2 of 3); on the table 100% | - | 67% (2 of 3); on the table 100% |
| Winner chose to pursue after the loser fled |  | - | - | - |
| Winner chose to follow up or pursue (all three) |  | 71% (5 of 7); on the table 100% | - | 71% (5 of 7); on the table 100% |
| Magic missiles tried each own turn | 50%+ | 17% (2 of 12) | - | 17% (2 of 12) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 18% (2 of 11) | - | 18% (2 of 11) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 67% (8 of 12) | 31% (4 of 13) | 48% (12 of 25) |
| Points that never fought | lower | 59% (3531 of 5997) | 46% (2770 of 5999) | 53% (6301 of 11996) |
|   infantry points that never fought | lower | 89% (1498 of 1675) | 72% (946 of 1306) | 82% (2444 of 2981) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 67% (14 of 21) | 81% (25 of 31) | 75% (39 of 52) |
| Bound items with a magic missile used (at least once a game) |  | 100% (1 of 1); 1.7 uses a game | 100% (2 of 2); 2.0 uses a game | 100% (3 of 3); 1.8 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 100% (1 of 1); 0.3 uses a game | 0.0 uses a game | 100% (1 of 1); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 64% (3095 of 4866) | 68% (4001 of 5884) | 66% (7096 of 10750) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.0 (30%) | - | 1.0 (30%) |
| MARCHED: its unit marched | 2.0 (60%) | - | 2.0 (60%) |
| IN COMBAT: engaged in combat | 0.3 (10%) | - | 0.3 (10%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 6.0 | 3.3 | 1.0 | 0.7 | 1.0 |
| not cast | 4.0 | 4.7 | 1.0 | 3.3 | 23.0 |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 4.7 (100%) | 0.3 (33%) | 1.0 (30%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.0 (60%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (10%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 4.0 (100%) | 0.0 (0%) | 0.7 (67%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 23.0 (100%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.0 a game | 1.0 a game | 0.5 a game |
| stood (cast and not dispelled) | - | 67% (2 of 3) | 67% (2 of 3) |
| the unit moved after it | - | 0% (0 of 2) | 0% (0 of 2) |
| it charged on its next turn | - | 0% (0 of 2) | 0% (0 of 2) |
| the enemy charged it first | - | 0% (0 of 2) | 0% (0 of 2) |
| it fought by the end of its next turn | - | 0% (0 of 2) | 0% (0 of 2) |
| it moved out of a charge the enemy had planned (not charged first) | - | 0% (0 of 2) | 0% (0 of 2) |
| none of these (no charge, no fight, no charge escaped) | - | 100% (2 of 2) | 100% (2 of 2) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 79% (57 of 72) | 48% (19 of 40) | 68% (76 of 112) |
|   cavalry | 100% (12 of 12) | 53% (10 of 19) | 71% (22 of 31) |
|   character | 0% (0 of 9) | 11% (1 of 9) | 6% (1 of 18) |
|   chariot | 100% (13 of 13) | - | 100% (13 of 13) |
|   infantry | 84% (32 of 38) | 67% (8 of 12) | 80% (40 of 50) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 0.0 (0%) | 2.3 (33%) | 2.3 (19%) |
| CHARGED: it charged | 1.7 (33%) | 1.3 (19%) | 3.0 (25%) |
| IN COMBAT: it fought this turn or the last | 0.0 (0%) | 0.3 (5%) | 0.3 (3%) |
| NO TARGET IN RANGE | 1.7 (33%) | 2.3 (33%) | 4.0 (33%) |
| ONLY IN COMBAT: the only targets were in combat | 0.3 (7%) | 0.0 (0%) | 0.3 (3%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.3 (27%) | 0.7 (10%) | 2.0 (17%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 13.3 | 0.7 | 95% | 1.2 pts | 16 pts |
| character | 0.3 | 0.0 | 100% | 0.0 pts | 0 pts |
| chariot | 4.3 | 0.3 | 92% | 5.0 pts | 22 pts |
| infantry | 14.3 | 4.3 | 72% | 8.0 pts | 115 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.3 | 2.0 | 2.7 |
| Charges that made contact a game | 3.3 | 1.0 | 2.2 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.00 declared, 0.00 contact (2 units) | - | 0.00 declared, 0.00 contact (2 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 0.00 declared, 0.00 contact (1 units) | 0.00 declared, 0.00 contact (1 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.36 declared, 0.36 contact (28 units) | 0.24 declared, 0.12 contact (25 units) | 0.30 declared, 0.25 contact (53 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 67% (4 of 6) | 100% (4 of 4) | - | 80% (8 of 10) |
| Character in a unit | 100% (2 of 2) | 100% (2 of 2) | 0% (0 of 1) | 80% (4 of 5) |
| Character on its own | 100% (5 of 5) | - | 43% (3 of 7) | 67% (8 of 12) |
| Chariot | 100% (2 of 2) | - | - | 100% (2 of 2) |
| Infantry | 91% (10 of 11) | 75% (3 of 4) | - | 87% (13 of 15) |
| Monster | 40% (2 of 5) | 0% (0 of 1) | - | 33% (2 of 6) |
| Monstrous | 100% (2 of 2) | - | - | 100% (2 of 2) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Skaven | 1 | 50% (1 of 2); on the table 100% | 17% (1 of 6) | 49% | 56% (5 of 9) | 100% (1 of 1); 5.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Tomb Kings of Khemri | 1 | 80% (4 of 5); on the table 100% | - | 38% | 60% (3 of 5) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 1 | - | 17% (1 of 6) | 89% | 86% (6 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 2 | - | - | 49% | 79% (15 of 19) | 100% (1 of 1); 2.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 1 | - | - | 41% | 83% (10 of 12) | 100% (1 of 1); 2.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (csame-bb45c30-p23, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 100% (1) | 71% (5) | 75% (6) |
| ...free all their last turn and able to turn (per game) | 0.33 | 1.67 | 2.00 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 1.67 | 1.67 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.67 | 0.67 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 1.00 | 1.00 |

### Quality by phase: csame-bb45c30-p23

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.7 | 3.7 |
| Strategy | Charge objectives carried out (made contact) | 86% (6 of 7) | 60% (3 of 5) |
| Strategy | Shoot objectives carried out (shot that target) | 36% (8 of 22) | 25% (2 of 8) |
| Strategy | Hexes on a unit its side charged or shot that turn | 0% (0 of 2) | 17% (1 of 6) |
| Strategy | Joined characters whose unit fought | 0% (0 of 5) | 50% (1 of 2) |
| Strategy | Lone characters that fought | 50% (3 of 6) | 57% (4 of 7) |
| Movement | Charges halted short of contact | 0.0 | 0.7 |
| Movement | Idle units | 2.3 | 3.0 |
| Movement | Points that never moved of their own | 136.7 | 56.7 |
| Movement | Fights charged into per game | 3.0 | 1.0 |
| Movement | Charges with odds: long shots (under 50%) | 1 of 7, net +0 | 0 of 3 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 7 | 0 of 3 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 4 of 7, net +144 | 1 of 3, net +60 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 of 7, net +0 | 2 of 3, net +195 |
| Shooting | Shots by shooting units (incl. breath weapons) | 20.0 | 7.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 45% (27 of 60) | 65% (15 of 23) |
| Shooting | Points destroyed by shooting units | 34.0 | 0.0 |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | 0.3 | - |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 0% (0 of 1) | - |
| Magic | Wounds caused by magic missiles | 0.3 | 1.7 |
| Magic | Wounds caused by other spells | 2.0 | - |
| Magic | Points destroyed by magic (all spells) | 56.7 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 5.0 / 0.7 / 0.7 / 0.0 | 0.0 / 2.0 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 293.7 | 290.0 |
| Combat | Points run down | 0.0 | 0.0 |
| Combat | Net points per charged fight, damage counted | +115 | +76 |
| Combat | Net per 100 charger points, damage counted | +36.9 | +15.3 |
| Combat | First round won (charged fights) | 89% | 100% |
| Combat | Net points per charged fight | +83 | +150 |
| Combat | Net points per supported fight / lone fight | +364 / +48 | - / +150 |
| Combat | Charged fights on a top-3 enemy unit | 2 of 9 | 2 of 3 |
| Game | Points lost | 303.7 | 426.0 |
| Game | VP from objectives | 1006.7 | 326.7 |
| Game | Lone holders (player turns) | 4.5 | 0.5 |

- Mine won / drew / lost: 3 / 0 / 0 of 3 ended games (of 3); mean margin (Mine - Opponent) +833 VP
- The side that went first won 1 of 3 games with a winner
- Points traded per game (both sides' losses): 730
- Games not ended: 0; findings 2, warnings 0

### Opponent rules: csame-bb45c30-p23

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 2.0 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.3 | +58.6 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | 31.0 | +290.5 | 0.0 | 225.0 | 30.0 | -73.2 | 0.0 | 317.7 |
| BACKUP TARGETS | - | - | - | - | 0.3 | +1.7 | 0.0 | 0.0 |
| CAST JOB | 1.3 | +50.0 | 226.7 | 0.0 | 1.7 | +12.6 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | 0.7 | +21.1 | 0.0 | 20.0 | 1.3 | +5.9 | 0.0 | 0.0 |
| CHAFF PASSED | - | - | - | - | 0.3 | -0.3 | 65.0 | 0.0 |
| CHALLENGE BY POINTS | - | - | - | - | 0.3 | +15.2 | 0.0 | 0.0 |
| CHARACTER GUNS | 3.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHARGE LOSSES | 12.7 | -486.7 | 0.0 | 281.7 | 27.3 | -1082.3 | 0.0 | 473.3 |
| CHARGE NOW FIRST | 2.3 | +0.0 | 222.3 | 0.0 | 1.0 | +0.0 | 150.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 13.0 | +0.0 | 0.0 | 65.0 | 7.0 | +0.0 | 0.0 | 80.3 |
| COMBAT PIVOT | 0.3 | +0.0 | 0.0 | 70.0 | - | - | - | - |
| CONVEYANCE SEARCH | - | - | - | - | 1.0 | +38.5 | 0.0 | 0.0 |
| COVER ONCE | 7.0 | -490.7 | 0.0 | 151.7 | 12.0 | -677.7 | 0.0 | 148.3 |
| DENIED BY THE FIGHT | 0.3 | -0.2 | 34.0 | 0.0 | - | - | - | - |
| DEPLOY BY FIGURES | 7.7 | +9.0 | 0.0 | 0.0 | 7.7 | +16.7 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | 0.3 | -0.6 | 0.0 | 0.0 | - | - | - | - |
| EVASIVE BY THE ODDS | - | - | - | - | 5.3 | +1070.5 | 0.0 | 0.0 |
| EXACT ROUND | 2.3 | +29.5 | 185.7 | 0.0 | 0.7 | +2.7 | 65.0 | 0.0 |
| FACES THE THREAT | - | - | - | - | 0.7 | +28.3 | 0.0 | 0.0 |
| FALL BACK GOOD ORDER | 2.7 | +67.3 | 185.7 | 0.0 | 1.0 | +0.0 | 65.0 | 0.0 |
| FALLS SHORT | 7.7 | +111.4 | 0.0 | 20.0 | 17.7 | +201.0 | 0.0 | 312.7 |
| FEATURE BUFFS | - | - | - | - | 0.7 | +21.5 | 0.0 | 96.0 |
| FIGHT TO THE END | 0.7 | +22.0 | 0.0 | 0.0 | - | - | - | - |
| FIRE IN ORDER | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| FIVE ACTION | 108.0 | +6859.6 | 899.0 | 579.0 | 90.7 | +5016.7 | 670.0 | 799.3 |
| FLANK NOT WEIGHED | 5.7 | +0.0 | 0.0 | 65.0 | 11.3 | +0.0 | 0.0 | 180.3 |
| FOCUS FIRE | 0.3 | +37.9 | 0.0 | 0.0 | - | - | - | - |
| FOLLOW UP WEIGHED | 2.0 | +171.3 | 0.0 | 70.0 | - | - | - | - |
| FOUR ROUNDS | 3.3 | +259.9 | 222.3 | 0.0 | 2.0 | +155.0 | 150.0 | 0.0 |
| FREED FROM HIS FIGHT | 0.7 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 104.7 |
| FRIEND SHOOTS FIRST | 1.7 | -34.0 | 0.0 | 0.0 | - | - | - | - |
| GIVES UP | 0.3 | -5.5 | 0.0 | 0.0 | 0.3 | -0.5 | 0.0 | 0.0 |
| GOAL WALK | 4.3 | +155.9 | 0.0 | 0.0 | 15.3 | +1519.4 | 0.0 | 179.3 |
| GUN FIGURES | 2.0 | +1.4 | 0.0 | 0.0 | - | - | - | - |
| HARD STAY DROPPED | 2.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | - | - | - | - | 5.0 | +0.0 | 0.0 | 138.7 |
| HIS CHARGE BY HIS RUN | 8.0 | +0.0 | 0.0 | 281.7 | 15.0 | +0.0 | 0.0 | 348.7 |
| HIS CHARGE DENIED | 0.3 | +13.1 | 34.0 | 0.0 | 0.7 | +42.2 | 130.0 | 0.0 |
| HIS CHARGE LIST | 10.0 | +0.0 | 0.0 | 150.0 | 9.3 | +0.0 | 0.0 | 162.7 |
| HIS LEGAL MOVES | 1.7 | +0.0 | 0.0 | 0.0 | 6.7 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 2.7 | -20.2 | 0.0 | 40.0 | 8.3 | -44.1 | 0.0 | 158.7 |
| HIS MOVE AS HE DECIDES | 43.0 | +14.0 | 309.0 | 0.0 | - | - | - | - |
| HIS MOVE WHY | - | - | - | - | 28.7 | +0.0 | 0.0 | 267.3 |
| HIS ONE MOVE | 23.7 | -25.4 | 0.0 | 170.0 | - | - | - | - |
| HIS ONE QUARTER | 3.7 | +0.0 | 0.0 | 0.0 | 9.7 | +0.0 | 0.0 | 56.7 |
| HIS OWN BEST MOVE | 2.3 | +0.0 | 0.0 | 0.0 | 7.7 | +0.0 | 0.0 | 34.0 |
| HIS RANDOM MOVE | 26.7 | +0.0 | 0.0 | 227.3 | 12.7 | +0.0 | 0.0 | 230.0 |
| HIS RANDOM MOVER COMES | 4.7 | +0.0 | 0.0 | 27.3 | 4.3 | +0.0 | 0.0 | 38.7 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 29.3 | +445.6 | 0.0 | 357.3 | 52.3 | +1027.9 | 0.0 | 638.7 |
| HIS SHOTS BY HIS RUN | 31.7 | +360.8 | 0.0 | 411.7 | 46.7 | +613.6 | 0.0 | 686.7 |
| HIS TURN DENIED | 0.7 | +8.2 | 74.7 | 0.0 | - | - | - | - |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 21.7 | +0.0 | 0.0 | 27.3 | 6.7 | +0.0 | 0.0 | 192.0 |
| HOLDER ASSIGNMENT | 16.0 | +1084.5 | 0.0 | 13.7 | 4.3 | +316.4 | 0.0 | 48.0 |
| HOLDS AMBUSHERS | 1.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 2.7 | -91.2 | 222.3 | 0.0 | 2.0 | -104.4 | 150.0 | 0.0 |
| IDLE COST | 5.0 | -88.9 | 0.0 | 0.0 | 12.7 | -143.9 | 0.0 | 224.3 |
| JOINT CHARGE NOW | 0.3 | +5.2 | 0.0 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 5.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 0.3 | +16.4 | 0.0 | 0.0 | 0.3 | +0.7 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| LEGAL CHARGES ONLY | 9.3 | +0.0 | 313.7 | 0.0 | 5.3 | +0.0 | 70.0 | 345.7 |
| LONE WIZARD KEPT IN | 1.0 | +52.2 | 0.0 | 0.0 | - | - | - | - |
| LONG SHOT | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| LOST AFTER ESCAPE | 1.3 | +4.1 | 78.3 | 0.0 | - | - | - | - |
| LURE BY WHAT IT DRAWS | 0.3 | -19.7 | 0.0 | 20.0 | - | - | - | - |
| MANOEUVRE | 1.3 | -2.2 | 0.0 | 86.7 | 1.7 | +85.8 | 0.0 | 0.0 |
| MARCH BY THE SUM | 1.0 | +26.8 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | 0.3 | +16.0 | 0.0 | 0.0 | 0.7 | +37.5 | 0.0 | 0.0 |
| MARCH OF THE TABLE | 0.3 | +9.7 | 0.0 | 0.0 | 0.3 | +7.3 | 0.0 | 0.0 |
| MARCH OVER CASTS | 1.0 | -26.4 | 0.0 | 0.0 | 1.0 | +223.9 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 1.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 0.7 | +61.3 | 0.0 | 0.0 | 1.7 | +16.9 | 0.0 | 38.7 |
| MEETS IN TIME | 5.3 | +188.6 | 0.0 | 0.0 | 3.7 | +115.9 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 3.0 | +72.1 | 0.0 | 0.0 | 2.3 | +24.8 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 4.3 | +29.0 | 0.0 | 0.0 | 3.0 | +22.1 | 0.0 | 0.0 |
| MOVE ORDER | 1.0 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 48.0 | 38.0 |
| MOVE SPELL NOT WORTH | - | - | - | - | 0.3 | -0.1 | 34.0 | 0.0 |
| MOVE SPELL OUT OF RANGE | - | - | - | - | 1.0 | -16.5 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 8.3 | +804.2 | 0.0 | 105.0 | 7.7 | +740.2 | 0.0 | 111.3 |
| NEARER NOT NEEDED | 11.7 | +459.3 | 0.0 | 20.0 | 8.0 | +388.6 | 0.0 | 48.0 |
| NEXT CHARGE BY LIST | 6.3 | +625.0 | 0.0 | 105.0 | 4.0 | +257.6 | 0.0 | 72.7 |
| NEXT OBJECTIVE NEARER | 1.0 | -83.9 | 0.0 | 0.0 | - | - | - | - |
| NO DOUBLE ROUNDS | 3.0 | -153.4 | 222.3 | 0.0 | 1.3 | -25.5 | 150.0 | 0.0 |
| NO LATE CUT | 2.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NO OLD ONE-MOVE GUESS | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | - | - | - | - | 1.0 | +7.1 | 0.0 | 0.0 |
| NOT WORTH A CAST | 4.0 | -3.8 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 6.3 | -219.0 | 0.0 | 86.7 | 6.3 | -167.2 | 0.0 | 124.7 |
| ONE CHECK AFTER THE LAST CHANGE | 0.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 36.7 |
| ONE FIGHT FORMULA | 5.0 | -79.1 | 0.0 | 65.0 | 5.3 | -220.2 | 0.0 | 72.7 |
| ONE OBJECTIVE FORMULA | 5.7 | +52.3 | 0.0 | 13.7 | 1.3 | +23.6 | 0.0 | 48.0 |
| ONE PROMISE A TARGET | - | - | - | - | 1.0 | +14.6 | 0.0 | 38.7 |
| ONE ROUTE | 1.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| OPENS UP | 0.7 | +29.2 | 76.0 | 0.0 | 0.3 | +3.1 | 20.0 | 0.0 |
| OVERRUNS AWAY | 0.3 | +1.0 | 36.7 | 0.0 | 0.3 | +4.5 | 65.0 | 0.0 |
| PATHS CROSS | 0.3 | +4.4 | 0.0 | 0.0 | 0.3 | +8.4 | 0.0 | 0.0 |
| PERIAPT WORTH | 0.3 | +40.5 | 0.0 | 0.0 | - | - | - | - |
| PIVOT GUARDS FLANK | - | - | - | - | 0.3 | -2.7 | 0.0 | 0.0 |
| PLAN RESULT | 50.7 | +513.6 | 324.3 | 559.0 | 43.3 | +150.0 | 195.0 | 601.0 |
| PROMISE BELOW ZERO | 0.3 | +0.0 | 0.0 | 20.0 | - | - | - | - |
| PROMISE BY ITS OWN SUM | 7.3 | -200.9 | 0.0 | 40.0 | 14.7 | -581.1 | 0.0 | 72.7 |
| PROMISE HOLDS THE SPOT | 0.3 | +23.5 | 0.0 | 0.0 | - | - | - | - |
| PROMISE KNOWS THE FIGHT | 0.7 | -2.6 | 0.0 | 0.0 | 2.0 | -0.8 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | 0.3 | -68.0 | 0.0 | 65.0 | - | - | - | - |
| QUARTER ODDS | 31.0 | +2584.9 | 263.3 | 97.3 | 26.7 | +2612.2 | 130.0 | 130.0 |
| RANDOM MOVE BY FIGURES | 4.0 | +174.4 | 0.0 | 188.3 | 4.3 | +25.1 | 0.0 | 113.3 |
| REAL GROUND | 1.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | 3.0 | +124.7 | 0.0 | 0.0 | 1.7 | +39.3 | 0.0 | 0.0 |
| REDIRECT FOR A FRIEND IN REACH | 4.3 | +0.0 | 0.0 | 53.7 | 0.7 | +0.0 | 0.0 | 0.0 |
| REFORMS TO MEET IT | 2.7 | -56.6 | 0.0 | 65.0 | - | - | - | - |
| RESERVE FALL BACK | 1.7 | +56.7 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | 2.7 | +70.1 | 222.3 | 0.0 | 1.7 | +44.4 | 130.0 | 0.0 |
| RISK ON THE WAY | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| ROUNDS AFTER TERROR | 0.7 | -3.5 | 74.7 | 0.0 | - | - | - | - |
| RUN DOWN | 1.3 | -15.0 | 78.3 | 0.0 | - | - | - | - |
| SCOUT SPOT | 0.7 | +0.4 | 0.0 | 0.0 | - | - | - | - |
| SCOUT WAITS | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 1.3 | -97.3 | 0.0 | 0.0 |
| SECOND LOOK | 0.3 | +23.4 | 0.0 | 0.0 | 0.3 | +9.9 | 0.0 | 0.0 |
| SET CREDITED ONCE | 1.3 | -43.2 | 0.0 | 65.0 | - | - | - | - |
| SET UP BY THE SET | 4.0 | +173.1 | 38.0 | 130.0 | 0.7 | -13.5 | 0.0 | 34.0 |
| SET UP TOGETHER | - | - | - | - | 0.3 | +1.2 | 0.0 | 38.7 |
| SHOOTERS IN TWO RANKS | 0.3 | +1.3 | 0.0 | 0.0 | 0.3 | +0.3 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 7.0 | +0.0 | 0.0 | 21.7 | 2.7 | +0.0 | 0.0 | 38.0 |
| SHOOTS FROM THE BEST SPOT | 2.3 | +37.6 | 34.0 | 0.0 | 0.7 | +16.2 | 0.0 | 0.0 |
| SHOT RISK POINTS | 17.3 | -269.2 | 0.0 | 321.7 | 23.3 | -218.2 | 0.0 | 363.7 |
| SHOTS AFTER THE MOVES | 2.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 19.7 | +468.2 | 0.0 | 21.7 | 7.3 | +74.5 | 0.0 | 112.7 |
| SPELL WORTH | 2.0 | +39.6 | 0.0 | 0.0 | - | - | - | - |
| SPELLS IN THE FIGHT | 0.3 | -6.1 | 0.0 | 0.0 | - | - | - | - |
| SPOT AS THE GAME MOVES | 6.0 | +0.0 | 0.0 | 175.0 | 10.3 | +0.0 | 0.0 | 175.7 |
| STAND AND SHOOT | - | - | - | - | 0.3 | -0.5 | 0.0 | 0.0 |
| STANDS FOR A REASON | - | - | - | - | 2.0 | +0.0 | 130.0 | 76.0 |
| STANDS STILL | 44.3 | +0.0 | 676.7 | 205.0 | 34.0 | +0.0 | 520.0 | 240.0 |
| STAY WORTH | 17.3 | +186.6 | 461.3 | 0.0 | 7.7 | +70.2 | 325.0 | 187.3 |
| STRIKE BY THE ODDS | 0.7 | +16.6 | 0.0 | 70.0 | - | - | - | - |
| STUCK PIVOT | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 4.7 | +463.8 | 0.0 | 41.7 | 8.3 | +313.6 | 0.0 | 230.0 |
| SUPPORT NARROWED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SUPPORT WORKED OUT | 4.7 | +463.8 | 0.0 | 41.7 | 8.3 | +313.6 | 0.0 | 230.0 |
| SURE REACH TOGETHER | - | - | - | - | 2.3 | +6.0 | 0.0 | 38.7 |
| SWIFTSTRIDE BY POINTS | - | - | - | - | 0.3 | +13.6 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 1.0 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| THE PROMISE ADDS | 0.3 | -30.3 | 0.0 | 65.0 | - | - | - | - |
| THE ROW IN ITS ORDER | 2.3 | +0.0 | 0.0 | 0.0 | 6.7 | +0.0 | 0.0 | 80.3 |
| THE ROW KEEPS ITS WAY | 4.3 | +0.0 | 0.0 | 13.7 | 2.7 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 4.7 | +0.0 | 0.0 | 35.3 | 1.7 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 51.7 | +0.0 | 0.0 | 185.3 | 42.3 | +0.0 | 0.0 | 306.3 |
| TIED UP BY THE SUM | 2.7 | +329.0 | 222.3 | 0.0 | 1.0 | +146.1 | 150.0 | 0.0 |
| TIME ON OUR SIDE | 34.0 | +313.8 | 0.0 | 346.7 | 17.3 | +173.1 | 0.0 | 0.0 |
| WAITS AGAIN | 1.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| WALKS ON ITS ROUTE | 0.3 | -7.6 | 0.0 | 0.0 | - | - | - | - |
| WHAT THE JOINER ADDS | - | - | - | - | 1.3 | +35.1 | 0.0 | 0.0 |
| WHO FIGHTS | - | - | - | - | 0.3 | -0.4 | 0.0 | 0.0 |
| WHO GETS IN | 0.3 | +5.2 | 0.0 | 0.0 | - | - | - | - |
| WHO HITS BACK | 1.0 | +264.4 | 0.0 | 0.0 | 1.0 | +99.2 | 0.0 | 0.0 |
| WHOLE FIGHT | - | - | - | - | 0.7 | +0.8 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | 3.7 | -274.0 | 0.0 | 0.0 | 6.0 | -590.1 | 0.0 | 148.3 |
| WOUNDS ON THE RANKS | 2.0 | +6.2 | 0.0 | 0.0 | 3.7 | +108.6 | 0.0 | 0.0 |

### Rule changes: csame-bb45c30-p23

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 183 | 183 | 125 | 41.67 | +393 | +3.1 |
| HIS MOVE AS HE DECIDES | 129 | 129 | 87 | 29.00 | +0 | +0.0 |
| HOLDER ASSIGNMENT | 61 | 61 | 57 | 19.00 | +3233 | +56.7 |
| HIS MOVE WHY | 86 | 86 | 56 | 18.67 | +0 | +0.0 |
| LEGAL CHARGES ONLY | 44 | 44 | 44 | 14.67 | +0 | +0.0 |
| HIS SHOT LIST | 245 | 221 | 42 | 14.00 | +507 | +12.1 |
| HIS SHOTS BY HIS RUN | 235 | 211 | 39 | 13.00 | +474 | +12.2 |
| OFF BEST | 38 | 38 | 38 | 12.67 | -1159 | -30.5 |
| FIVE ACTION | 596 | 555 | 37 | 12.33 | +1839 | +49.7 |
| QUARTER ODDS | 173 | 164 | 34 | 11.33 | +2985 | +87.8 |
| THE TABLE AGAIN | 36 | 36 | 31 | 10.33 | +0 | +0.0 |
| PROMISE BY ITS OWN SUM | 66 | 66 | 29 | 9.67 | -2346 | -80.9 |
| DEPLOY BY FIGURES | 46 | 46 | 23 | 7.67 | +275 | +12.0 |
| HIS ONE MOVE | 71 | 69 | 18 | 6.00 | +0 | +0.0 |
| MOVE TO CHARGE COMPUTED | 48 | 34 | 17 | 5.67 | +1010 | +59.4 |
| REDIRECT FOR A FRIEND IN REACH | 15 | 15 | 15 | 5.00 | +0 | +0.0 |
| TIME ON OUR SIDE | 154 | 134 | 15 | 5.00 | +26 | +1.7 |
| MOVE ORDER | 14 | 14 | 14 | 4.67 | +0 | +0.0 |
| NEXT CHARGE BY LIST | 31 | 24 | 14 | 4.67 | +881 | +62.9 |
| ADVANCE LANE KEPT | 13 | 13 | 13 | 4.33 | +0 | +0.0 |
| GOAL WALK | 59 | 55 | 13 | 4.33 | +511 | +39.3 |
| EVASIVE BY THE ODDS | 16 | 16 | 12 | 4.00 | +3167 | +263.9 |
| HARD STAY DROPPED | 12 | 12 | 12 | 4.00 | +0 | +0.0 |
| RANDOM MOVE BY FIGURES | 25 | 25 | 12 | 4.00 | +599 | +49.9 |
| SHOT RISK POINTS | 122 | 105 | 12 | 4.00 | +201 | +16.8 |
| COVER ONCE | 57 | 36 | 11 | 3.67 | +86 | +7.8 |
| MEETS IN TIME | 27 | 27 | 11 | 3.67 | +349 | +31.8 |
| CHARGE LOSSES | 120 | 103 | 10 | 3.33 | +525 | +52.5 |
| FOUR ROUNDS | 16 | 14 | 10 | 3.33 | +245 | +24.5 |
| TIED UP BY THE SUM | 11 | 10 | 10 | 3.33 | +450 | +45.0 |
| HOLDS AMBUSHERS | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| SET UP BY THE SET | 14 | 14 | 7 | 2.33 | +615 | +87.8 |
| SHOOTS FROM THE BEST SPOT | 9 | 9 | 7 | 2.33 | +37 | +5.3 |
| SUPPORT ADDS | 39 | 35 | 7 | 2.33 | +133 | +19.0 |
| SUPPORT WORKED OUT | 39 | 35 | 7 | 2.33 | +133 | +19.0 |
| FOLLOW UP WEIGHED | 6 | 6 | 6 | 2.00 | +514 | +85.6 |
| IDLE COST | 53 | 31 | 6 | 2.00 | +24 | +4.0 |
| WHO HITS BACK | 6 | 6 | 6 | 2.00 | +962 | +160.3 |
| CAST JOB | 9 | 9 | 5 | 1.67 | +5 | +0.9 |
| CHAFF IN THE MOVE | 6 | 6 | 5 | 1.67 | +0 | +0.0 |
| NEARER NOT NEEDED | 59 | 57 | 5 | 1.67 | +266 | +53.2 |
| RESERVE FALL BACK | 5 | 5 | 5 | 1.67 | +170 | +34.0 |
| FIRE IN ORDER | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| RISK BY ARC | 13 | 12 | 4 | 1.33 | +55 | +13.8 |
| THE ROW IN ITS ORDER | 27 | 4 | 4 | 1.33 | +0 | +0.0 |
| CHARGE NOW FIRST | 10 | 10 | 3 | 1.00 | -153 | -51.1 |
| EXACT ROUND | 9 | 9 | 3 | 1.00 | +20 | +6.6 |
| LONE WIZARD KEPT IN | 3 | 3 | 3 | 1.00 | +157 | +52.2 |
| MARCH BY THE SUM | 3 | 3 | 3 | 1.00 | +80 | +26.8 |
| ONE FIGHT FORMULA | 31 | 14 | 3 | 1.00 | +157 | +52.2 |
| ONE PROMISE A TARGET | 3 | 3 | 3 | 1.00 | +44 | +14.6 |
| REDIRECT COUNTER | 14 | 11 | 3 | 1.00 | +151 | +50.2 |
| STUCK PIVOT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| FACES THE THREAT | 2 | 2 | 2 | 0.67 | +85 | +42.4 |
| FALL BACK GOOD ORDER | 11 | 9 | 2 | 0.67 | +109 | +54.6 |
| LANE BY FIGURES | 2 | 2 | 2 | 0.67 | +51 | +25.7 |
| MANOEUVRE | 9 | 9 | 2 | 0.67 | +258 | +128.8 |
| MARCH OF THE TABLE | 2 | 2 | 2 | 0.67 | -51 | -25.5 |
| OPENS UP | 3 | 3 | 2 | 0.67 | +15 | +7.7 |
| PATHS CROSS | 2 | 2 | 2 | 0.67 | +38 | +19.2 |
| PROMISE KNOWS THE FIGHT | 8 | 3 | 2 | 0.67 | -10 | -5.1 |
| SCOUT WAITS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| SECOND LOOK | 2 | 2 | 2 | 0.67 | +100 | +50.0 |
| SHOOTERS IN TWO RANKS | 2 | 2 | 2 | 0.67 | +5 | +2.5 |
| STAY WORTH | 75 | 66 | 2 | 0.67 | +61 | +30.7 |
| STRIKE BY THE ODDS | 2 | 2 | 2 | 0.67 | +50 | +24.8 |
| WHAT THE JOINER ADDS | 4 | 2 | 2 | 0.67 | +1 | +0.4 |
| AFTERMATH IN POINTS | 1 | 1 | 1 | 0.33 | +176 | +175.8 |
| CASTS FROM BEHIND | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CHAFF PASSED | 1 | 1 | 1 | 0.33 | -1 | -0.9 |
| CHALLENGE BY POINTS | 1 | 1 | 1 | 0.33 | +46 | +45.7 |
| COMBAT PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FIGHT TO THE END | 2 | 2 | 1 | 0.33 | +37 | +37.5 |
| FOCUS FIRE | 1 | 1 | 1 | 0.33 | +114 | +113.6 |
| HIS CHARGE DENIED | 3 | 3 | 1 | 0.33 | +6 | +6.2 |
| HIS TURN DENIED | 2 | 2 | 1 | 0.33 | +6 | +6.4 |
| JOINT CHARGE NOW | 1 | 1 | 1 | 0.33 | +16 | +15.7 |
| MAX FOR POSITIONING | 7 | 5 | 1 | 0.33 | +0 | +0.0 |
| MISSILES IN THE MOVE | 16 | 11 | 1 | 0.33 | +4 | +4.2 |
| NO DOUBLE ROUNDS | 13 | 12 | 1 | 0.33 | +5 | +5.2 |
| ONE OBJECTIVE FORMULA | 21 | 13 | 1 | 0.33 | +37 | +36.5 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.33 | +122 | +121.5 |
| PIVOT GUARDS FLANK | 1 | 1 | 1 | 0.33 | -8 | -8.2 |
| PROMISE HOLDS THE SPOT | 1 | 1 | 1 | 0.33 | +70 | +70.4 |
| PROMISE READS THE TABLE | 1 | 1 | 1 | 0.33 | -172 | -171.9 |
| SHOTS AFTER THE MOVES | 12 | 12 | 1 | 0.33 | +0 | +0.0 |
| SUPPORT NARROWED | 1 | 1 | 1 | 0.33 | -2 | -1.7 |
| SWIFTSTRIDE BY POINTS | 1 | 1 | 1 | 0.33 | +41 | +40.7 |
| WALKS ON ITS ROUTE | 1 | 1 | 1 | 0.33 | -23 | -22.9 |
| WHO GETS IN | 1 | 1 | 1 | 0.33 | +16 | +15.7 |
| WHOLE FIGHT | 2 | 1 | 1 | 0.33 | +0 | +0.4 |
| WHOLE FIGHT DANGER | 29 | 26 | 1 | 0.33 | +35 | +35.4 |
| BACKUP TARGETS | 1 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 2 | trace | - | - | - | - |
| CHARACTER GUNS | 10 | 10 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 60 | 55 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 3 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 1 | not checked | - | - | - | - |
| FALLS SHORT | 76 | 63 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 2 | 2 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 51 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 20 | 19 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 5 | 5 | 0 | 0.00 | - | - |
| GIVES UP | 2 | 1 | 0 | 0.00 | - | - |
| GUN FIGURES | 6 | not checked | - | - | - | - |
| HE REFORMS ONCE FREED | 15 | 13 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 69 | 63 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 58 | 54 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 25 | 21 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 33 | 25 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 40 | 34 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 30 | 27 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 118 | 107 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 27 | 25 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN RUN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 85 | 83 | 0 | 0.00 | - | - |
| HONEST WORTH | 14 | 12 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 19 | 17 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 2 | 2 | 0 | 0.00 | - | - |
| LONG SHOT | 2 | 2 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 4 | 3 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 1 | 1 | 0 | 0.00 | - | - |
| MARCH CHECK | 3 | 2 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 6 | 6 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 8 | 6 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 22 | 19 | 0 | 0.00 | - | - |
| MOVE SPELL NOT WORTH | 1 | not checked | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 3 | trace | - | - | - | - |
| NEXT OBJECTIVE NEARER | 3 | 3 | 0 | 0.00 | - | - |
| NO LATE CUT | 6 | 4 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 18 | 18 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT TURNED | 3 | 3 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 12 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 4 | not checked | - | - | - | - |
| ONE ROUTE | 8 | 6 | 0 | 0.00 | - | - |
| OVERRUNS AWAY | 2 | 2 | 0 | 0.00 | - | - |
| PLAN RESULT | 282 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 1 | 1 | 0 | 0.00 | - | - |
| REAL GROUND | 8 | 6 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 8 | 6 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 3 | 1 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 2 | 2 | 0 | 0.00 | - | - |
| RUN DOWN | 4 | 3 | 0 | 0.00 | - | - |
| SCOUT SPOT | 2 | 2 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 4 | 4 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 4 | 4 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 1 | not checked | - | - | - | - |
| SHOOTERS ON THE TABLE | 29 | not checked | - | - | - | - |
| SHOTS IN THE MOVE | 81 | 53 | 0 | 0.00 | - | - |
| SPELL WORTH | 6 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 49 | 46 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 1 | 1 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 6 | 3 | 0 | 0.00 | - | - |
| STANDS STILL | 235 | 223 | 0 | 0.00 | - | - |
| SURE REACH TOGETHER | 7 | 5 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 8 | not checked | - | - | - | - |
| THE PROMISE ADDS | 1 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 21 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 19 | not checked | - | - | - | - |
| THE TABLE BINDS | 282 | not checked | - | - | - | - |
| WAITS AGAIN | 5 | 4 | 0 | 0.00 | - | - |
| WHO FIGHTS | 1 | 1 | 0 | 0.00 | - | - |
| WOUNDS ON THE RANKS | 17 | 17 | 0 | 0.00 | - | - |

### Off best figure: csame-bb45c30-p23

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| ARMY TABLE | rule | 4.00 | 5.67 | 76.3 |
| PROMISE BY ITS OWN SUM | rule | 2.33 | 7.33 | 80.9 |
| JOB FIRST | gate | 4.00 | 5.33 | 30.7 |
| RULE SWITCHED OFF | gate | 2.00 | 1.00 | 32.9 |
| CHARGE NOW FIRST | rule | 0.67 | 0.33 | 51.1 |
| HOLDER ASSIGNMENT | rule | 0.67 | 0.33 | 7.5 |
| MARCH OF THE TABLE | rule | 0.33 | 0.33 | 25.5 |
| PROMISE KNOWS THE FIGHT | rule | 0.33 | 0.33 | 5.1 |
| AFTERMATH BAND | gate | 0.33 | - | 4.2 |
| CHAFF PASSED | rule | - | 0.33 | 0.9 |
| FOLLOW UP WEIGHED | rule | 0.33 | - | 4.2 |
| ONE PROMISE A TARGET | rule | - | 0.33 | 23.6 |
| PIVOT GUARDS FLANK | rule | - | 0.33 | 8.2 |
| PROMISE READS THE TABLE | rule | 0.33 | - | 171.9 |
| SET UP BY THE SET | rule | 0.33 | - | 30.1 |
| SUPPORT NARROWED | rule | 0.33 | - | 1.7 |
| WALKS ON ITS ROUTE | rule | 0.33 | - | 22.9 |

### Plans: csame-bb45c30-p23

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 3.0 | 78% | 370 | 269 | 73% |
| Mine | join | 1.7 | 100% | 96 | 0 | 0% |
| Mine | move | 41.0 | 94% | 1850 | 0 | 0% |
| Mine | shoot | 5.0 | 53% | 399 | 245 | 61% |
| Opponent | charge | 2.0 | 50% | 274 | 150 | 55% |
| Opponent | join | 1.3 | 100% | 52 | 0 | 0% |
| Opponent | move | 37.3 | 97% | 1676 | 0 | 0% |
| Opponent | shoot | 2.0 | 0% | 93 | 0 | 0% |
| Opponent | support | 0.7 | 100% | 0 | 0 | - |

### Battle groups: csame-bb45c30-p23

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 3.0 | 11% | 100% | 0% | - | 0% | 0% | 0% | 100% | 0% |
| Opponent | REDIRECT COUNTER | 1.7 | 0% | - | - | - | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: csame-bb45c30-p23

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | - | - | - | - |
| Mine | Chaff | 5 | 113 (5) | 0 | 113 | 19 | 40% | 1.7 | 139 (4) | 0 (1) | - | 139 (4) | 0 (1) |
| Mine | Character | 9 | 20 (9) | 20 | 0 | 0 | 44% | 2.6 | 19 (5) | 23 (4) | - | 15 (4) | 24 (5) |
| Mine | Clean-up | 2 | 84 (2) | 44 | 39 | 0 | 50% | 3.0 | - | 106 (1) | 68 (1) | 68 (1) | 106 (1) |
| Mine | Fast Hammer | 4 | 16 (4) | 16 | 0 | 48 | 25% | 2.3 | 23 (2) | 0 (2) | - | 64 (1) | 0 (3) |
| Mine | Hammer | 4 | 39 (4) | 39 | 0 | 53 | 0% | 1.5 | 0 (1) | 73 (2) | 0 (1) | 52 (3) | 0 (1) |
| Mine | Holder | 7 | 38 (7) | 0 | 38 | 5 | 57% | 4.0 | 104 (2) | 0 (3) | 0 (2) | 41 (6) | 0 (1) |
| Mine | Shooter | 5 | 96 (5) | 35 | 61 | 22 | 0% | 1.2 | 513 (1) | 0 (2) | 0 (2) | 152 (3) | 0 (2) |
| Mine | Wizard | 2 | 0 (2) | 0 | 0 | 0 | 0% | 1.0 | 0 (2) | - | - | - | 0 (2) |
| Opponent | Chaff | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Character | 9 | 26 (9) | 26 | 0 | 5 | 33% | 3.0 | 24 (6) | 0 (2) | 54 (1) | 42 (6) | 5 (3) |
| Opponent | Clean-up | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Fast Hammer | 5 | 3 (5) | 0 | 3 | 0 | 40% | 2.3 | 5 (3) | - | 0 (2) | 0 (2) | 6 (3) |
| Opponent | Hammer | 10 | 14 (10) | 14 | 0 | 52 | 20% | 2.6 | 27 (4) | 0 (5) | 0 (1) | 34 (4) | 0 (6) |
| Opponent | Holder | 4 | 0 (4) | 0 | 0 | 29 | 75% | 3.0 | 0 (1) | 0 (3) | - | 0 (1) | 0 (3) |
| Opponent | Shooter | 3 | 0 (3) | 0 | 0 | 62 | 0% | 1.3 | 0 (1) | 0 (2) | - | - | 0 (3) |

### Charged fights: csame-bb45c30-p23

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Skaven | 1 | 170 | 0 | 2.0 | 1.0 | 0 | 0 | +0 | 2 of 2 | 1 of 2 | - | +0 |
| Mine | Tomb Kings of Khemri | 1 | 102 | 576 | 6.0 | 1.2 | 96 | 0 | +96 | 0 of 6 | 6 of 6 | +364 | +42 |
| Mine | Vampire Counts | 1 | 0 | 170 | 1.0 | 1.0 | 170 | 0 | +170 | 0 of 1 | 1 of 1 | - | +170 |
| **Mine** | all armies | 3 | 91 | 249 | 3.0 | 1.1 | 83 | 0 | +83 | 2 of 9 | 8 of 9 | +364 | +48 |
| Opponent | Warriors of Chaos | 2 | 0 | 30 | 0.5 | 1.0 | 60 | 0 | +60 | 0 of 1 | 1 of 1 | - | +60 |
| Opponent | Wood Elf Realms | 1 | 0 | 390 | 2.0 | 1.0 | 195 | 0 | +195 | 2 of 2 | 2 of 2 | - | +195 |
| **Opponent** | all armies | 3 | 0 | 150 | 1.0 | 1.0 | 150 | 0 | +150 | 2 of 3 | 3 of 3 | - | +150 |

### Effective charges: csame-bb45c30-p23

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Skaven | 2 | 1 (net +0) | 0 | 0 | 0 | 0 | 1 (net +0) | 0 | 0% (0 of 2) |
| Mine | Tomb Kings of Khemri | 6 | 0 | 0 | 0 | 0 | 4 (net +144) | 1 (net +0) | 1 | 0% (0 of 5) |
| Opponent | Warriors of Chaos | 1 | 0 | 0 | 0 | 0 | 1 (net +60) | 0 | 0 | 0% (0 of 1) |
| Opponent | Wood Elf Realms | 2 | 0 | 0 | 0 | 0 | 0 | 2 (net +195) | 0 | 0% (0 of 2) |

### Charged fights, damage counted: csame-bb45c30-p23

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 1 | 0 | 201 | +0 | 22 | 0 | +22 | - |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 154 | 160 | +0 | 49 | 8 | +40 | +26.3 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 4 | 475 | 107 | +144 | 190 | 0 | +190 | +40.0 |
| Mine | No odds | 2 | 296 | 148 | +85 | 85 | 0 | +85 | +28.7 |
| Mine | All fights | 9 | 311 | 138 | +83 | 117 | 2 | +115 | +36.9 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 499 | 195 | +195 | 195 | 111 | +84 | +16.9 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 494 | 60 | +60 | 60 | 0 | +60 | +12.1 |
| Opponent | All fights | 3 | 497 | 150 | +150 | 150 | 74 | +76 | +15.3 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| csame-bb45c30-p23 | move | 20 | 2 (10%) | 1 (5%) | 2 (10%) | 16 (80%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L2429 |
| Invocation of Nehek | Mine | L2429 |
| Periapt of Soul Exchange | Mine | L2131 |
| Ring of Doom | Opponent | L2131 |
| Storm Daemon (Renegade 2.0) | Mine | L2131 |

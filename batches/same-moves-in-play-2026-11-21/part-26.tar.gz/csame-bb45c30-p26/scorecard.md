# Doctrine scorecard: csame-bb45c30-p26

### Scorecard: csame-bb45c30-p26

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0218 | 2 | 1 | Mine | - | - | 6 | 1 | 7 | 0 | 0 | 0 | 255 |
| L0218 | 2 | 1 | Opponent | - | - | - | 1 | 4 | 0 | 0 | 0 | 74 |
| L0235 | 1 | 1 | Mine | no | 8 | 6 | 1 | 4 | 0 | 0 | 0 | 0 |
| L0235 | 1 | 1 | Opponent | yes | 3 | 3 | 1 | 4 | 0 | 0 | 0 | 125 |
| L0319 | 1 | 1 | Mine | no | 11 | - | 0 | 0 | 0 | 0 | 0 | 420 |
| L0319 | 1 | 1 | Opponent | no | 2 | 3 | 2 | 3 | 0 | 0 | 0 | 235 |
| **Average** | | | Mine | 0% | 9.5 | 6.0 | 0.7 | 3.7 | 0.0 | 0.0 | 0.0 | 225.0 |
| **Average** | | | Opponent | 50% | 2.5 | 3.0 | 1.3 | 3.7 | 0.0 | 0.0 | 0.0 | 144.7 |

### KPIs: csame-bb45c30-p26

Rules off - Opponent only: NO OLD ONE-MOVE GUESS; both sides: ONE RUN A PLAN.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 8) | 0% (0 of 13) | 0% (0 of 21) |
| Winner chose to follow up after the loser gave ground |  | - | - | - |
| Winner chose to pursue after the loser fell back in good order |  | - | - | - |
| Winner chose to pursue after the loser fled |  | - | - | - |
| Winner chose to follow up or pursue (all three) |  | - | - | - |
| Magic missiles tried each own turn | 50%+ | 48% (20 of 42) | 17% (4 of 24) | 36% (24 of 66) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 48% (20 of 42) | 17% (4 of 24) | 36% (24 of 66) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 78% (7 of 9) | - | 78% (7 of 9) |
| Points that never fought | lower | 66% (3830 of 5797) | 71% (4275 of 6000) | 69% (8105 of 11797) |
|   infantry points that never fought | lower | 57% (788 of 1374) | 100% (842 of 842) | 74% (1630 of 2216) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 70% (14 of 20) | 63% (17 of 27) | 66% (31 of 47) |
| Bound items with a magic missile used (at least once a game) |  | 100% (4 of 4); 5.7 uses a game | 50% (1 of 2); 1.3 uses a game | 83% (5 of 6); 3.5 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 80% (4 of 5); 1.3 uses a game | 0% (0 of 1); 0.0 uses a game | 67% (4 of 6); 0.7 uses a game |
|   their share of the points of units over 100 pts | lower | 59% (2380 of 4039) | 55% (3054 of 5515) | 57% (5434 of 9554) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 7.3 (100%) | 0.0 (0%) | 7.3 (52%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.7 (10%) | 0.7 (5%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 4.7 (70%) | 4.7 (33%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 1.3 (20%) | 1.3 (10%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Hexes | Movement spells | Magic missiles | Assailments |
| --- | --- | --- | --- | --- |
| tried | 1.3 | 3.7 | 8.0 | 0.3 |
| not cast | 2.7 | 6.3 | 14.0 | 27.7 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (2%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.7 (25%) | 0.0 (0%) | 7.3 (52%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.7 (5%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 2.0 (75%) | 4.0 (63%) | 4.7 (33%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 1.3 (10%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 0.0 (0%) | 2.3 (37%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 27.0 (98%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 2.7 a game | 1.0 a game | 1.8 a game |
| stood (cast and not dispelled) | 62% (5 of 8) | 33% (1 of 3) | 55% (6 of 11) |
| the unit moved after it | 80% (4 of 5) | 0% (0 of 1) | 67% (4 of 6) |
| it charged on its next turn | 0% (0 of 5) | 0% (0 of 1) | 0% (0 of 6) |
| the enemy charged it first | 0% (0 of 5) | 0% (0 of 1) | 0% (0 of 6) |
| it fought by the end of its next turn | 0% (0 of 5) | 0% (0 of 1) | 0% (0 of 6) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 5) | 0% (0 of 1) | 0% (0 of 6) |
| none of these (no charge, no fight, no charge escaped) | 100% (5 of 5) | 100% (1 of 1) | 100% (6 of 6) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 72% (26 of 36) | 48% (39 of 81) | 56% (65 of 117) |
|   cavalry | - | 63% (12 of 19) | 63% (12 of 19) |
|   character | - | 36% (4 of 11) | 36% (4 of 11) |
|   chariot | 75% (9 of 12) | 58% (7 of 12) | 67% (16 of 24) |
|   infantry | - | 26% (7 of 27) | 26% (7 of 27) |
|   monster | - | 75% (9 of 12) | 75% (9 of 12) |
|   war machine | 71% (17 of 24) | - | 71% (17 of 24) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.0 (30%) | 2.0 (14%) | 3.0 (17%) |
| CHARGED: it charged | 0.0 (0%) | 0.7 (5%) | 0.7 (4%) |
| FLEEING: it fled or was fleeing | 0.0 (0%) | 0.3 (2%) | 0.3 (2%) |
| MOVED: a war machine that moved | 1.0 (30%) | 0.0 (0%) | 1.0 (6%) |
| NO TARGET IN RANGE | 0.0 (0%) | 6.7 (48%) | 6.7 (38%) |
| ONLY IN COMBAT: the only targets were in combat | 0.0 (0%) | 0.3 (2%) | 0.3 (2%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.3 (40%) | 1.3 (10%) | 2.7 (15%) |
| SHELTERED: the target was sheltered | 0.0 (0%) | 1.0 (7%) | 1.0 (6%) |
| OTHER BAR | 0.0 (0%) | 1.7 (12%) | 1.7 (10%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 5.0 | 1.0 | 80% | 3.3 pts | 17 pts |
| character | 1.3 | 0.7 | 50% | 10.0 pts | 13 pts |
| chariot | 5.3 | 6.0 | 56% | 22.4 pts | 120 pts |
| infantry | 2.3 | 2.0 | 29% | 13.6 pts | 32 pts |
| monster | 3.0 | 2.3 | 56% | 12.1 pts | 36 pts |
| war machine | 6.0 | 3.3 | 72% | 5.9 pts | 35 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 1.0 | 2.0 | 1.5 |
| Charges that made contact a game | 1.0 | 1.3 | 1.2 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.00 declared, 0.00 contact (2 units) | - | 0.00 declared, 0.00 contact (2 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | - | - |
|   per unit a game, the other units (no war machines, no joined characters) | 0.12 declared, 0.12 contact (25 units) | 0.21 declared, 0.14 contact (29 units) | 0.17 declared, 0.13 contact (54 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 33% (1 of 3) | 100% (1 of 1) | - | 50% (2 of 4) |
| Character in a unit | 100% (8 of 8) | 43% (3 of 7) | - | 73% (11 of 15) |
| Character on its own | - | 100% (1 of 1) | 50% (1 of 2) | 67% (2 of 3) |
| Chariot | 50% (1 of 2) | 50% (1 of 2) | - | 50% (2 of 4) |
| Infantry | 80% (4 of 5) | 0% (0 of 3) | - | 50% (4 of 8) |
| Monster | 100% (2 of 2) | 0% (0 of 1) | - | 67% (2 of 3) |
| Monstrous | 100% (2 of 2) | 50% (2 of 4) | - | 67% (4 of 6) |
| War Machines | 100% (3 of 3) | 100% (1 of 1) | - | 100% (4 of 4) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 2 | - | 67% (20 of 30) | 60% | 67% (8 of 12) | 100% (4 of 4); 8.5 uses a game | 0.0 uses a game | 75% (3 of 4); 1.5 uses a game |
| Chaos Dwarfs | 1 | - | 0% (0 of 12) | 78% | 75% (6 of 8) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Ogre Kingdoms | 1 | - | 0% (0 of 6) | 68% | 43% (3 of 7) | 100% (1 of 1); 4.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 1 | - | 0% (0 of 12) | 82% | 88% (7 of 8) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Wood Elf Realms | 1 | - | 67% (4 of 6) | 63% | 58% (7 of 12) | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (csame-bb45c30-p26, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 0% (0) | 0% (0) | 0% (0) |
| ...free all their last turn and able to turn (per game) | 0.00 | 0.00 | 0.00 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.00 | 0.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: csame-bb45c30-p26

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.3 | 1.3 |
| Strategy | Charge objectives carried out (made contact) | 100% (3 of 3) | 75% (3 of 4) |
| Strategy | Shoot objectives carried out (shot that target) | 52% (14 of 27) | 25% (3 of 12) |
| Strategy | Hexes on a unit its side charged or shot that turn | - | 75% (3 of 4) |
| Strategy | Joined characters whose unit fought | 55% (6 of 11) | 17% (1 of 6) |
| Strategy | Lone characters that fought | 0% (0 of 4) | 67% (2 of 3) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 3.7 | 3.7 |
| Movement | Points that never moved of their own | 225.0 | 144.7 |
| Movement | Fights charged into per game | 1.0 | 1.3 |
| Movement | Charges with odds: long shots (under 50%) | 1 of 3, net -52 | 0 of 2 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 3 | 0 of 2 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 3 | 1 of 2, net +85 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 of 3, net +63 | 1 of 2, net +170 |
| Shooting | Shots by shooting units (incl. breath weapons) | 3.0 | 13.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 89% (8 of 9) | 22% (9 of 40) |
| Shooting | Points destroyed by shooting units | 18.3 | 45.7 |
| Shooting | War machine shots | 6.0 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 39% (7 of 18) | - |
| Shooting | Points destroyed by war machines | 0.0 | 28.3 |
| Magic | Magic missiles cast | 4.3 | 1.0 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 0% (0 of 13) | 0% (0 of 3) |
| Magic | Wounds caused by magic missiles | 17.7 | 5.0 |
| Magic | Wounds caused by other spells | 0.3 | - |
| Magic | Points destroyed by magic (all spells) | 120.0 | 10.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.0 / 0.0 / 0.3 / 0.0 | 0.0 / 1.3 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 53.3 | 102.3 |
| Combat | Points run down | 0.0 | 0.0 |
| Combat | Net points per charged fight, damage counted | +66 | +18 |
| Combat | Net per 100 charger points, damage counted | +127.9 | +5.2 |
| Combat | First round won (charged fights) | 67% | 50% |
| Combat | Net points per charged fight | +25 | +55 |
| Combat | Net points per supported fight / lone fight | - / +25 | - / +55 |
| Combat | Charged fights on a top-3 enemy unit | 1 of 3 | 2 of 4 |
| Game | Points lost | 241.7 | 221.3 |
| Game | VP from objectives | 816.7 | 863.3 |
| Game | Lone holders (player turns) | 9.5 | 2.5 |

- Mine won / drew / lost: 1 / 1 / 1 of 3 ended games (of 3); mean margin (Mine - Opponent) +40 VP
- The side that went first won 1 of 2 games with a winner
- Points traded per game (both sides' losses): 463
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: csame-bb45c30-p26

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | - | - | - | - | 1.0 | +0.0 | 0.0 | 41.7 |
| ARMY TABLE | 15.0 | +227.1 | 0.0 | 176.3 | 26.7 | -33.9 | 0.0 | 102.3 |
| ARTILLERY RE-ROLL WEIGHED | 3.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| BEST PRIZE | - | - | - | - | 0.3 | -7.7 | 0.0 | 0.0 |
| CANNON PLAN MISSED | 1.0 | +0.0 | 55.0 | 0.0 | - | - | - | - |
| CANNON PLANNED TARGET | 5.3 | +38.6 | 110.0 | 0.0 | - | - | - | - |
| CANNON SIGHT KEPT | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CAST JOB | 5.3 | +65.6 | 0.0 | 54.0 | - | - | - | - |
| CASTER AWAY FROM SCREEN | 1.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | - | - | - | - | 1.3 | +37.8 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 1.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | 0.3 | +10.0 | 0.0 | 10.0 | 1.0 | +4.5 | 0.0 | 0.0 |
| CHAFF PASSED | - | - | - | - | 0.7 | -1.0 | 56.7 | 0.0 |
| CHARGE LOSSES | 12.3 | -239.5 | 0.0 | 74.0 | 10.0 | -326.0 | 0.0 | 0.0 |
| CHARGE NOW FIRST | - | - | - | - | 1.0 | +0.0 | 85.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 12.3 | +0.0 | 0.0 | 74.0 | 7.3 | +0.0 | 0.0 | 55.0 |
| CONVEYANCE SEARCH | 2.7 | +269.1 | 0.0 | 0.0 | 1.0 | +311.5 | 0.0 | 0.0 |
| COVER ONCE | 4.0 | -203.5 | 0.0 | 17.3 | 3.7 | -94.9 | 0.0 | 0.0 |
| DENIED BY THE FIGHT | 0.3 | -0.6 | 0.0 | 17.3 | - | - | - | - |
| DEPLOY BY FIGURES | 9.7 | +22.3 | 0.0 | 28.3 | 8.3 | +76.7 | 0.0 | 41.7 |
| DUEL STOPS AT THE KILL | - | - | - | - | 0.3 | -2.3 | 0.0 | 0.0 |
| ENGINEER BY LORE | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| EXACT ROUND | 0.3 | +2.1 | 42.0 | 0.0 | 0.7 | +4.4 | 56.7 | 0.0 |
| FALL BACK GOOD ORDER | 0.7 | +0.0 | 0.0 | 34.7 | 0.7 | +0.0 | 28.3 | 0.0 |
| FALLBACK BY WORTH | 0.3 | +0.0 | 0.0 | 10.0 | - | - | - | - |
| FALLS SHORT | 23.0 | +295.7 | 0.0 | 158.0 | 3.0 | +104.5 | 0.0 | 18.3 |
| FEATURE BUFFS | 10.0 | +444.3 | 0.0 | 190.0 | 1.0 | +33.4 | 0.0 | 0.0 |
| FIGHT TO THE END | - | - | - | - | 0.3 | +1.9 | 0.0 | 0.0 |
| FIRE IN ORDER | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FIVE ACTION | 101.0 | +7981.1 | 188.7 | 582.0 | 95.7 | +6559.7 | 479.0 | 348.0 |
| FLANK NOT WEIGHED | 3.7 | +0.0 | 0.0 | 28.3 | 3.0 | +0.0 | 0.0 | 18.3 |
| FOUR ROUNDS | 1.0 | +14.6 | 42.0 | 34.7 | 1.3 | +111.4 | 113.3 | 0.0 |
| FREED FROM HIS FIGHT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FRIEND SHOOTS FIRST | 1.3 | -2.7 | 0.0 | 0.0 | 0.3 | -3.7 | 0.0 | 0.0 |
| GIVES UP | - | - | - | - | 0.3 | -0.4 | 28.3 | 0.0 |
| GOAL WALK | 7.7 | +828.4 | 0.0 | 0.0 | 13.3 | +998.5 | 0.0 | 0.0 |
| GROUND FLIERS | 0.3 | +6.5 | 0.0 | 0.0 | - | - | - | - |
| GUN FIGURES | 3.0 | +89.3 | 18.3 | 0.0 | 2.0 | +38.5 | 28.3 | 0.0 |
| HARD STAY DROPPED | 5.0 | +0.0 | 0.0 | 17.3 | 3.3 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 5.7 | +0.0 | 0.0 | 56.7 | 2.3 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE DENIED | - | - | - | - | 0.7 | +88.1 | 56.7 | 0.0 |
| HIS CHARGE LIST | 1.7 | +0.0 | 0.0 | 112.0 | 3.0 | +0.0 | 0.0 | 83.3 |
| HIS LEGAL MOVES | - | - | - | - | 2.7 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 8.7 | -146.0 | 0.0 | 187.3 | 2.0 | -33.5 | 0.0 | 0.0 |
| HIS MOVE AS HE DECIDES | - | - | - | - | 39.7 | +9.3 | 275.0 | 0.0 |
| HIS MOVE WHY | 28.7 | +0.0 | 0.0 | 121.0 | - | - | - | - |
| HIS ONE MOVE | - | - | - | - | 19.7 | -93.6 | 0.0 | 0.0 |
| HIS ONE QUARTER | 3.3 | +0.0 | 0.0 | 61.7 | - | - | - | - |
| HIS OWN BEST MOVE | 1.7 | +0.0 | 0.0 | 28.3 | 2.7 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVE | - | - | - | - | 12.0 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVER COMES | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 61.7 | +1920.3 | 0.0 | 409.7 | 64.7 | +3813.0 | 0.0 | 348.0 |
| HIS SHOTS BY HIS RUN | 58.7 | +1184.4 | 0.0 | 456.3 | 44.3 | +979.8 | 0.0 | 180.7 |
| HIS TURN DENIED | 0.3 | +1.8 | 0.0 | 17.3 | - | - | - | - |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 34.7 | +0.0 | 0.0 | 190.0 | 18.7 | +0.0 | 0.0 | 36.7 |
| HOLDER ASSIGNMENT | 16.3 | +1694.6 | 0.0 | 123.3 | 13.7 | +1529.8 | 0.0 | 60.3 |
| HOLDS AMBUSHERS | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 0.7 | -2.2 | 42.0 | 17.3 | 1.3 | -85.3 | 113.3 | 0.0 |
| IDLE COST | 17.0 | -94.6 | 0.0 | 45.7 | 4.0 | -67.2 | 0.0 | 18.3 |
| KEEP FALLS | 0.3 | +0.8 | 0.0 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 3.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | - | - | - | - | 0.7 | +17.7 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| LEGAL CHARGES ONLY | 0.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 56.7 | 0.0 |
| LONE WIZARD KEPT IN | 1.3 | +116.7 | 0.0 | 0.0 | - | - | - | - |
| LOST AFTER ESCAPE | 1.0 | -0.1 | 42.0 | 34.7 | 0.3 | -0.0 | 0.0 | 0.0 |
| MANOEUVRE | 1.3 | +19.5 | 0.0 | 0.0 | 2.3 | -6.3 | 0.0 | 0.0 |
| MARCH BY THE SUM | 0.3 | +54.1 | 0.0 | 0.0 | 0.3 | +15.6 | 0.0 | 0.0 |
| MARCH CHECK | 1.0 | +57.3 | 0.0 | 27.0 | 2.0 | +78.6 | 0.0 | 0.0 |
| MARCH OF THE TABLE | - | - | - | - | 0.3 | +8.4 | 0.0 | 0.0 |
| MARCH OVER CASTS | 0.3 | -4.4 | 0.0 | 0.0 | 1.3 | +335.7 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 2.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 1.7 | +31.3 | 0.0 | 83.7 | 0.7 | +7.4 | 0.0 | 0.0 |
| MEETS IN TIME | 3.3 | +262.7 | 0.0 | 0.0 | 3.0 | +302.4 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 6.3 | +385.8 | 0.0 | 27.0 | 4.3 | +92.9 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 6.7 | +260.2 | 0.0 | 27.0 | 5.0 | +64.2 | 0.0 | 0.0 |
| MISSILES ON ONE TARGET | 1.7 | -97.2 | 0.0 | 0.0 | - | - | - | - |
| MOVE ORDER | 1.7 | +0.0 | 28.3 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| MOVE SPELL OUT OF RANGE | - | - | - | - | 1.3 | -136.7 | 0.0 | 0.0 |
| MOVE SPELL SPOT | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 5.7 | +781.4 | 0.0 | 119.7 | 2.7 | +84.1 | 0.0 | 0.0 |
| MOVES UNITS SPELL | 0.7 | +36.7 | 0.0 | 0.0 | 0.3 | +1.4 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 3.7 | +185.1 | 0.0 | 0.0 | 10.7 | +487.6 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 3.3 | +518.2 | 0.0 | 63.0 | 1.3 | +23.6 | 0.0 | 0.0 |
| NEXT OBJECTIVE NEARER | - | - | - | - | 1.0 | -55.7 | 56.7 | 0.0 |
| NO DOUBLE ROUNDS | 1.0 | -19.8 | 42.0 | 34.7 | 1.0 | -36.4 | 113.3 | 0.0 |
| NO LATE CUT | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NO RALLY LEFT | - | - | - | - | 0.3 | +2.2 | 0.0 | 42.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OFF BEST | 3.7 | -2056.9 | 0.0 | 0.0 | 3.3 | -197.6 | 0.0 | 42.0 |
| OGRE LOADER SECOND SHOT | 2.3 | +6.4 | 0.0 | 0.0 | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ONE FIGHT FORMULA | 3.7 | -17.2 | 0.0 | 74.0 | 4.0 | -79.2 | 0.0 | 0.0 |
| ONE OBJECTIVE FORMULA | 9.7 | +54.6 | 0.0 | 66.7 | 4.3 | +119.9 | 0.0 | 18.3 |
| ONE PROMISE A TARGET | 1.3 | -52.5 | 0.0 | 34.7 | - | - | - | - |
| ONE ROUTE | 2.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| OPENS A LANE | 0.3 | +1.1 | 0.0 | 0.0 | - | - | - | - |
| OVERRUNS AWAY | 0.7 | +6.8 | 42.0 | 17.3 | - | - | - | - |
| PLAN RESULT | 44.7 | +189.6 | 18.3 | 416.7 | 43.3 | +257.3 | 112.0 | 329.7 |
| PROMISE BY ITS OWN SUM | 10.3 | -4341.1 | 0.0 | 0.0 | 5.0 | -152.1 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | 0.3 | -0.9 | 0.0 | 28.3 | - | - | - | - |
| PROMISE READS THE TABLE | 1.3 | -2.7 | 0.0 | 0.0 | 0.3 | -3.7 | 0.0 | 0.0 |
| PROMISE SHOT AWAY | 3.3 | -19.3 | 0.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | 17.7 | +1378.7 | 42.0 | 160.0 | 15.3 | +2116.0 | 0.0 | 167.3 |
| RANDOM MOVE BY FIGURES | 3.0 | +88.3 | 0.0 | 113.3 | - | - | - | - |
| REAL GROUND | 2.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | 3.0 | +113.4 | 0.0 | 150.3 | 1.3 | -59.2 | 0.0 | 0.0 |
| REDIRECT FOR A FRIEND IN REACH | 4.0 | +0.0 | 0.0 | 93.7 | 2.3 | +0.0 | 0.0 | 41.0 |
| REDIRECT WEIGHED | - | - | - | - | 0.3 | -7.7 | 0.0 | 0.0 |
| REFORMS TO MEET IT | 4.0 | -223.8 | 0.0 | 91.3 | 1.0 | -21.2 | 0.0 | 0.0 |
| RESERVE FALL BACK | - | - | - | - | 0.3 | +86.1 | 0.0 | 0.0 |
| RISK BY ARC | 0.7 | +0.1 | 42.0 | 17.3 | 1.3 | +2.1 | 113.3 | 0.0 |
| RISK ON THE WAY | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| ROUNDS AFTER TERROR | - | - | - | - | 0.7 | -23.7 | 28.3 | 0.0 |
| RUN DOWN | 0.7 | -2.2 | 42.0 | 17.3 | 0.7 | +0.0 | 56.7 | 0.0 |
| SCOUT SPOT | - | - | - | - | 0.7 | -0.1 | 0.0 | 0.0 |
| SCOUT WAITS | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 1.0 | -22.7 | 0.0 | 10.0 | 1.0 | -49.6 | 0.0 | 0.0 |
| SEARCH SPOT | 0.7 | +3.3 | 0.0 | 10.0 | - | - | - | - |
| SET-UP ANY TARGET | 0.3 | +59.5 | 0.0 | 0.0 | 0.3 | +36.6 | 0.0 | 0.0 |
| SHOOTER COUNTED ONCE | 0.7 | -5.0 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | - | - | - | - | 0.3 | +0.3 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 8.3 | +0.0 | 0.0 | 27.0 | 5.0 | +0.0 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.7 | +155.2 | 0.0 | 0.0 | 1.3 | +20.7 | 0.0 | 0.0 |
| SHOT OR CHARGE | - | - | - | - | 0.3 | -0.0 | 28.3 | 0.0 |
| SHOT REPLANNED | 0.3 | +0.0 | 18.3 | 0.0 | - | - | - | - |
| SHOT RISK POINTS | 48.3 | +594.7 | 0.0 | 381.3 | 48.0 | +1236.1 | 0.0 | 348.0 |
| SHOTS AFTER THE MOVES | 2.0 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 9.3 | +415.3 | 0.0 | 0.0 | 16.3 | +372.8 | 0.0 | 36.7 |
| SPELL SETS UP CHARGE | 0.3 | +59.5 | 0.0 | 0.0 | 0.3 | +36.6 | 0.0 | 0.0 |
| SPOT AS THE GAME MOVES | 8.3 | +0.0 | 0.0 | 233.0 | 6.7 | +0.0 | 0.0 | 0.0 |
| STAND AND SHOOT | 0.7 | -2.0 | 42.0 | 17.3 | - | - | - | - |
| STANDS FOR A REASON | 0.7 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 50.3 | +0.0 | 146.7 | 145.7 | 43.3 | +0.0 | 365.7 | 201.3 |
| STAY WORTH | 21.7 | +109.3 | 146.7 | 0.0 | 21.3 | +54.3 | 309.0 | 78.7 |
| STRIKE BY THE ODDS | - | - | - | - | 0.3 | +1.0 | 0.0 | 11.3 |
| STUCK PIVOT | 0.3 | +0.0 | 0.0 | 56.7 | - | - | - | - |
| SUPPORT ADDS | 1.7 | +142.2 | 0.0 | 38.3 | 1.3 | +40.6 | 0.0 | 42.0 |
| SUPPORT NARROWED | - | - | - | - | 0.3 | +0.0 | 28.3 | 0.0 |
| SUPPORT WORKED OUT | 1.7 | +142.2 | 0.0 | 38.3 | 1.3 | +40.6 | 0.0 | 42.0 |
| SURE REACH TOGETHER | - | - | - | - | 0.3 | +2.7 | 0.0 | 11.3 |
| SWIFTSTRIDE BY POINTS | - | - | - | - | 0.3 | +0.1 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE PROMISED MOVE | 0.3 | +0.0 | 0.0 | 28.3 | 0.3 | +0.0 | 0.0 | 18.3 |
| THE ROW IN ITS ORDER | 5.7 | +0.0 | 56.7 | 56.7 | 3.7 | +0.0 | 0.0 | 18.3 |
| THE ROW KEEPS ITS WAY | 3.3 | +0.0 | 0.0 | 0.0 | 4.7 | +0.0 | 0.0 | 36.7 |
| THE STEP BACK IS MADE | 2.0 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 36.7 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 45.7 | +0.0 | 0.0 | 222.0 | 45.7 | +0.0 | 0.0 | 126.3 |
| TIED UP BY THE SUM | - | - | - | - | 0.7 | +119.5 | 85.0 | 0.0 |
| TIME ON OUR SIDE | 9.3 | +156.5 | 0.0 | 0.0 | 59.0 | +493.8 | 0.0 | 82.0 |
| WAITS AGAIN | 0.7 | +0.0 | 0.0 | 28.3 | 1.0 | +0.0 | 0.0 | 0.0 |
| WALKS ON ITS ROUTE | - | - | - | - | 0.3 | -26.1 | 0.0 | 42.0 |
| WAR ENGINE JOBS | - | - | - | - | 1.3 | +0.0 | 56.7 | 0.0 |
| WHO FIGHTS | 0.3 | -2.1 | 0.0 | 17.3 | 0.3 | +0.3 | 28.3 | 0.0 |
| WHO HITS BACK | 0.3 | +107.4 | 0.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT DANGER | 0.3 | -9.6 | 0.0 | 0.0 | - | - | - | - |
| WOUNDS ON THE RANKS | 5.0 | +432.3 | 0.0 | 0.0 | 3.7 | +561.3 | 0.0 | 0.0 |

### Rule changes: csame-bb45c30-p26

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| SHOT RISK POINTS | 289 | 281 | 112 | 37.33 | +3171 | +28.3 |
| HIS SHOT LIST | 379 | 370 | 101 | 33.67 | +1107 | +11.0 |
| HIS SHOTS BY HIS RUN | 309 | 288 | 94 | 31.33 | +1509 | +16.1 |
| HIS MOVE AS HE DECIDES | 119 | 119 | 91 | 30.33 | +0 | +0.0 |
| HOLDER ASSIGNMENT | 90 | 90 | 84 | 28.00 | +5160 | +61.4 |
| ARMY TABLE | 125 | 125 | 79 | 26.33 | +418 | +5.3 |
| HIS MOVE WHY | 86 | 86 | 44 | 14.67 | +0 | +0.0 |
| DEPLOY BY FIGURES | 54 | 54 | 36 | 12.00 | +491 | +13.6 |
| THE TABLE AGAIN | 36 | 36 | 28 | 9.33 | +0 | +0.0 |
| TIME ON OUR SIDE | 205 | 182 | 27 | 9.00 | +58 | +2.1 |
| HARD STAY DROPPED | 25 | 25 | 25 | 8.33 | +0 | +0.0 |
| FIVE ACTION | 590 | 564 | 23 | 7.67 | +1823 | +79.3 |
| PROMISE BY ITS OWN SUM | 46 | 46 | 22 | 7.33 | -13480 | -612.7 |
| OFF BEST | 21 | 21 | 21 | 7.00 | -6764 | -322.1 |
| REDIRECT FOR A FRIEND IN REACH | 19 | 19 | 19 | 6.33 | +0 | +0.0 |
| HIS ONE MOVE | 59 | 57 | 18 | 6.00 | +0 | +0.0 |
| GOAL WALK | 63 | 59 | 14 | 4.67 | +610 | +43.6 |
| QUARTER ODDS | 99 | 92 | 14 | 4.67 | +1815 | +129.7 |
| MEETS IN TIME | 19 | 19 | 13 | 4.33 | +889 | +68.4 |
| CAST JOB | 16 | 16 | 12 | 4.00 | +17 | +1.4 |
| ARTILLERY RE-ROLL WEIGHED | 10 | 10 | 10 | 3.33 | +0 | +0.0 |
| MOVE ORDER | 10 | 10 | 10 | 3.33 | +0 | +0.0 |
| PROMISE SHOT AWAY | 10 | 10 | 10 | 3.33 | -57 | -5.7 |
| STAY WORTH | 129 | 109 | 10 | 3.33 | +24 | +2.4 |
| MOVE TO CHARGE COMPUTED | 25 | 22 | 9 | 3.00 | +857 | +95.2 |
| SHOOTS FROM THE BEST SPOT | 9 | 9 | 9 | 3.00 | +59 | +6.6 |
| WOUNDS ON THE RANKS | 26 | 25 | 9 | 3.00 | +896 | +99.5 |
| OGRE LOADER SECOND SHOT | 7 | 7 | 7 | 2.33 | +19 | +2.7 |
| RANDOM MOVE BY FIGURES | 9 | 9 | 7 | 2.33 | +265 | +37.9 |
| CASTER AWAY FROM SCREEN | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| MISSILES IN THE MOVE | 32 | 22 | 6 | 2.00 | +476 | +79.3 |
| LEGAL CHARGES ONLY | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| NEXT CHARGE BY LIST | 14 | 12 | 5 | 1.67 | +603 | +120.6 |
| CASTING BLOCK | 4 | 4 | 4 | 1.33 | +25 | +6.4 |
| CHAFF IN THE MOVE | 4 | 4 | 4 | 1.33 | +1 | +0.1 |
| FALLS SHORT | 78 | 58 | 4 | 1.33 | +47 | +11.7 |
| LONE WIZARD KEPT IN | 4 | 4 | 4 | 1.33 | +350 | +87.5 |
| MARCH CHECK | 9 | 9 | 4 | 1.33 | +92 | +22.9 |
| ONE PROMISE A TARGET | 4 | 4 | 4 | 1.33 | -157 | -39.3 |
| SHOTS IN THE MOVE | 77 | 58 | 4 | 1.33 | +388 | +97.0 |
| ADVANCE LANE KEPT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| FOUR ROUNDS | 7 | 7 | 3 | 1.00 | +43 | +14.3 |
| HIS MOVE AND SHOT | 32 | 31 | 3 | 1.00 | +0 | +0.0 |
| HOLDS AMBUSHERS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| MAX FOR POSITIONING | 7 | 7 | 3 | 1.00 | +5 | +1.7 |
| MOVES UNITS SPELL | 3 | 3 | 3 | 1.00 | +114 | +38.2 |
| SCOUT WAITS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| CANNON SIGHT KEPT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| CHAFF PASSED | 2 | 2 | 2 | 0.67 | -3 | -1.6 |
| CHARGE LOSSES | 67 | 64 | 2 | 0.67 | +78 | +39.2 |
| COVER ONCE | 23 | 16 | 2 | 0.67 | +43 | +21.4 |
| HIS CHARGE DENIED | 2 | 2 | 2 | 0.67 | +183 | +91.6 |
| LANE BY FIGURES | 2 | 2 | 2 | 0.67 | +53 | +26.6 |
| MARCH BY THE SUM | 2 | 2 | 2 | 0.67 | +209 | +104.5 |
| SHOTS AFTER THE MOVES | 11 | 11 | 2 | 0.67 | +0 | +0.0 |
| SUPPORT ADDS | 9 | 9 | 2 | 0.67 | +44 | +22.1 |
| SUPPORT WORKED OUT | 9 | 9 | 2 | 0.67 | +44 | +22.1 |
| THE ROW IN ITS ORDER | 28 | 2 | 2 | 0.67 | +0 | +0.0 |
| TIED UP BY THE SUM | 2 | 2 | 2 | 0.67 | +116 | +57.9 |
| BEST PRIZE | 1 | 1 | 1 | 0.33 | -48 | -48.5 |
| CANNON PLANNED TARGET | 16 | 16 | 1 | 0.33 | +0 | +0.2 |
| CHARGE NOW FIRST | 3 | 3 | 1 | 0.33 | -76 | -75.9 |
| FEATURE BUFFS | 33 | 33 | 1 | 0.33 | +41 | +41.4 |
| FIRE IN ORDER | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| KEEP FALLS | 1 | 1 | 1 | 0.33 | +23 | +22.9 |
| MANOEUVRE | 11 | 11 | 1 | 0.33 | +67 | +66.8 |
| MARCH OF THE TABLE | 1 | 1 | 1 | 0.33 | -25 | -25.1 |
| NO DOUBLE ROUNDS | 6 | 6 | 1 | 0.33 | +4 | +4.4 |
| NO RALLY LEFT | 1 | 1 | 1 | 0.33 | +3 | +2.8 |
| ONE FIGHT FORMULA | 23 | 11 | 1 | 0.33 | +16 | +16.3 |
| OVERRUNS AWAY | 2 | 2 | 1 | 0.33 | +4 | +4.4 |
| PROMISE KNOWS THE FIGHT | 1 | 1 | 1 | 0.33 | -3 | -2.8 |
| REDIRECT COUNTER | 13 | 8 | 1 | 0.33 | +3 | +2.8 |
| REDIRECT WEIGHED | 1 | 1 | 1 | 0.33 | -48 | -48.5 |
| RESERVE FALL BACK | 1 | 1 | 1 | 0.33 | +258 | +258.4 |
| RISK BY ARC | 6 | 6 | 1 | 0.33 | +4 | +4.4 |
| SEARCH SPOT | 2 | 2 | 1 | 0.33 | +10 | +10.0 |
| SHOOTERS IN TWO RANKS | 1 | 1 | 1 | 0.33 | +1 | +1.0 |
| SHOT REPLANNED | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| STRIKE BY THE ODDS | 1 | 1 | 1 | 0.33 | +3 | +3.0 |
| STUCK PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| SUPPORT NARROWED | 1 | 1 | 1 | 0.33 | -4 | -4.3 |
| SURE REACH TOGETHER | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| SWIFTSTRIDE BY POINTS | 1 | 1 | 1 | 0.33 | +0 | +0.2 |
| WALKS ON ITS ROUTE | 1 | 1 | 1 | 0.33 | -78 | -78.4 |
| WHO HITS BACK | 1 | 1 | 1 | 0.33 | +294 | +293.8 |
| CANNON PLAN MISSED | 3 | 3 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 6 | trace | - | - | - | - |
| CLOSES ON WHAT IT BEATS | 59 | 57 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 11 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 1 | 1 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 2 | 2 | 0 | 0.00 | - | - |
| EXACT ROUND | 3 | 3 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 4 | 4 | 0 | 0.00 | - | - |
| FALLBACK BY WORTH | 1 | 1 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 1 | 1 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 20 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 5 | 5 | 0 | 0.00 | - | - |
| GIVES UP | 1 | 1 | 0 | 0.00 | - | - |
| GROUND FLIERS | 1 | not checked | - | - | - | - |
| GUN FIGURES | 15 | not checked | - | - | - | - |
| HIS CHARGE BY HIS RUN | 24 | 22 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 14 | 14 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 8 | 8 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 10 | 10 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 13 | 13 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 36 | 35 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 1 | 1 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 1 | 1 | 0 | 0.00 | - | - |
| HIS TURN RUN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 160 | 159 | 0 | 0.00 | - | - |
| HONEST WORTH | 6 | 6 | 0 | 0.00 | - | - |
| IDLE COST | 63 | 48 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 15 | 14 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 2 | 2 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 4 | 4 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 5 | 5 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 9 | 9 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 35 | 24 | 0 | 0.00 | - | - |
| MISSILES ON ONE TARGET | 5 | not checked | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 4 | trace | - | - | - | - |
| MOVE SPELL SPOT | 5 | not checked | - | - | - | - |
| NEARER NOT NEEDED | 43 | 39 | 0 | 0.00 | - | - |
| NEXT OBJECTIVE NEARER | 3 | 3 | 0 | 0.00 | - | - |
| NO LATE CUT | 3 | 3 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 18 | 18 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 1 | not checked | - | - | - | - |
| ONE OBJECTIVE FORMULA | 42 | 30 | 0 | 0.00 | - | - |
| ONE ROUTE | 9 | 9 | 0 | 0.00 | - | - |
| OPENS A LANE | 1 | not checked | - | - | - | - |
| PLAN RESULT | 264 | trace | - | - | - | - |
| PROMISE READS THE TABLE | 5 | 5 | 0 | 0.00 | - | - |
| REAL GROUND | 9 | 9 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 15 | 14 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 3 | 3 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 2 | 2 | 0 | 0.00 | - | - |
| RUN DOWN | 4 | 4 | 0 | 0.00 | - | - |
| SCOUT SPOT | 2 | 2 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 6 | 6 | 0 | 0.00 | - | - |
| SET-UP ANY TARGET | 2 | not checked | - | - | - | - |
| SHOOTER COUNTED ONCE | 2 | 2 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 40 | not checked | - | - | - | - |
| SHOT OR CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 2 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 45 | 39 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 2 | 2 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 8 | 8 | 0 | 0.00 | - | - |
| STANDS STILL | 281 | 263 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 2 | not checked | - | - | - | - |
| THE PROMISED MOVE | 2 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 24 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 17 | not checked | - | - | - | - |
| THE TABLE BINDS | 274 | not checked | - | - | - | - |
| WAITS AGAIN | 5 | 4 | 0 | 0.00 | - | - |
| WAR ENGINE JOBS | 4 | 4 | 0 | 0.00 | - | - |
| WHO FIGHTS | 2 | 2 | 0 | 0.00 | - | - |
| WHOLE FIGHT DANGER | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: csame-bb45c30-p26

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| PROMISE BY ITS OWN SUM | rule | 5.33 | 2.00 | 612.7 |
| JOB FIRST | gate | 3.33 | 2.00 | 395.6 |
| ARMY TABLE | rule | 0.33 | 4.33 | 65.9 |
| HOLDER ASSIGNMENT | rule | 0.67 | 2.67 | 34.4 |
| PROMISE SHOT AWAY | rule | 3.33 | - | 5.7 |
| RULE SWITCHED OFF | gate | 0.33 | 1.33 | 86.9 |
| ONE PROMISE A TARGET | rule | 1.33 | - | 39.3 |
| BEST PRIZE | rule | - | 0.33 | 48.5 |
| CHAFF PASSED | rule | - | 0.33 | 3.1 |
| CHARGE NOW FIRST | rule | - | 0.33 | 75.9 |
| MARCH OF THE TABLE | rule | - | 0.33 | 25.1 |
| PROMISE KNOWS THE FIGHT | rule | 0.33 | - | 2.8 |
| REDIRECT WEIGHED | rule | - | 0.33 | 48.5 |
| SUPPORT NARROWED | rule | - | 0.33 | 4.3 |
| WALKS ON ITS ROUTE | rule | - | 0.33 | 78.4 |

### Plans: csame-bb45c30-p26

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | move | 37.3 | 96% | 2896 | 0 | 0% |
| Mine | shoot | 7.3 | 64% | 250 | 190 | 76% |
| Opponent | charge | 1.3 | 75% | 163 | 122 | 75% |
| Opponent | move | 38.0 | 94% | 2213 | 0 | 0% |
| Opponent | shoot | 3.7 | 55% | 211 | 135 | 64% |
| Opponent | support | 0.3 | 100% | 0 | 0 | 0% |

### Battle groups: csame-bb45c30-p26

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 3.0 | 44% | 75% | 0% | - | 0% | 0% | 0% | 100% | 0% |
| Opponent | REDIRECT COUNTER | 1.3 | 0% | - | - | - | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: csame-bb45c30-p26

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 2 | 0 (2) | 0 | 0 | 50 | 100% | - | - | 0 (2) | - | 0 (2) | - |
| Mine | Character | 11 | 21 (11) | 21 | 0 | 0 | 27% | 2.8 | - | 1 (6) | 44 (5) | 21 (11) | - |
| Mine | Clean-up | 2 | 339 (2) | 0 | 339 | 0 | 100% | - | 316 (1) | - | 363 (1) | 339 (2) | - |
| Mine | Fast Hammer | 10 | 19 (10) | 19 | 0 | 68 | 60% | 5.5 | 37 (6) | 0 (1) | 0 (3) | 27 (7) | 0 (3) |
| Mine | Hammer | 9 | 40 (9) | 4 | 36 | 13 | 22% | 3.1 | 0 (2) | 41 (4) | 83 (3) | 40 (9) | - |
| Mine | Holder | 2 | 0 (2) | 0 | 0 | 0 | 100% | - | 0 (1) | - | 0 (1) | - | 0 (2) |
| Mine | War machine | 4 | 0 (4) | 0 | 0 | 0 | 0% | 1.2 | 0 (4) | - | - | - | 0 (4) |
| Mine | Wizard | 4 | 0 (4) | 0 | 0 | 0 | 75% | 1.0 | 0 (2) | 0 (1) | 0 (1) | 0 (2) | 0 (2) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Chaff | 8 | 23 (8) | 0 | 23 | 45 | 75% | 4.5 | 47 (3) | 0 (4) | 0 (1) | 25 (7) | 0 (1) |
| Opponent | Character | 7 | 16 (7) | 16 | 0 | 0 | 29% | 1.8 | 0 (1) | 4 (5) | 51 (1) | 23 (5) | 3 (2) |
| Opponent | Clean-up | 3 | 0 (3) | 0 | 0 | 38 | 67% | 2.0 | - | 0 (3) | - | 0 (3) | - |
| Opponent | Fast Hammer | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Hammer | 10 | 54 (10) | 10 | 44 | 12 | 50% | 2.4 | 9 (5) | 110 (4) | 0 (1) | 10 (5) | 87 (5) |
| Opponent | Shooter | 4 | 79 (4) | 10 | 69 | 21 | 0% | 2.0 | 0 (1) | 110 (2) | 80 (1) | 64 (3) | 132 (1) |
| Opponent | Wizard | 2 | 0 (2) | 0 | 0 | 0 | 100% | - | - | 0 (2) | - | 0 (2) | - |

### Charged fights: csame-bb45c30-p26

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 2 | 180 | 63 | 1.5 | 1.0 | 42 | 17 | +25 | 1 of 3 | 2 of 3 | - | +25 |
| Mine | Chaos Dwarfs | 1 | 55 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| **Mine** | all armies | 3 | 138 | 42 | 1.0 | 1.0 | 42 | 17 | +25 | 1 of 3 | 2 of 3 | - | +25 |
| Opponent | Ogre Kingdoms | 1 | 170 | 0 | 1.0 | 1.0 | 0 | 34 | -34 | 1 of 1 | 0 of 1 | - | -34 |
| Opponent | Orc & Goblin Tribes | 1 | 0 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 1 of 1 | 0 of 1 | - | +0 |
| Opponent | Wood Elf Realms | 1 | 82 | 255 | 2.0 | 1.0 | 128 | 0 | +128 | 0 of 2 | 2 of 2 | - | +128 |
| **Opponent** | all armies | 3 | 84 | 85 | 1.3 | 1.0 | 64 | 8 | +55 | 2 of 4 | 2 of 4 | - | +55 |

### Effective charges: csame-bb45c30-p26

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 3 | 1 (net -52) | 0 | 0 | 0 | 0 | 2 (net +63) | 0 | 0% (0 of 3) |
| Opponent | Wood Elf Realms | 2 | 0 | 0 | 0 | 0 | 1 (net +85) | 1 (net +170) | 0 | 0% (0 of 2) |

### Charged fights, damage counted: csame-bb45c30-p26

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 1 | 52 | 297 | -52 | 50 | 52 | -2 | -4.8 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 52 | 120 | +63 | 101 | 0 | +101 | +194.2 |
| Mine | All fights | 3 | 52 | 179 | +25 | 84 | 17 | +66 | +127.9 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 499 | 170 | +170 | 170 | 0 | +170 | +34.1 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 499 | 85 | +85 | 85 | 0 | +85 | +17.0 |
| Opponent | No odds | 2 | 192 | 293 | -17 | 13 | 104 | -91 | -47.6 |
| Opponent | All fights | 4 | 346 | 210 | +55 | 70 | 52 | +18 | +5.2 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| csame-bb45c30-p26 | move | 17 | 2 (12%) | 1 (6%) | 3 (18%) | 12 (71%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Elixir of Power | Opponent | L0319 |
| Fistful of Laurels | Opponent | L0218 |
| Ring of Doom | Mine | L0218, L0235 |

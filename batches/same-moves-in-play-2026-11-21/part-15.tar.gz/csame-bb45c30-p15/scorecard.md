# Doctrine scorecard: csame-bb45c30-p15

### Scorecard: csame-bb45c30-p15

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0409 | 1 | 1 | Mine | no | 11 | 3 | 0 | 2 | 0 | 0 | 0 | 0 |
| L0409 | 1 | 1 | Opponent | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 399 |
| L0425 | 5 | 1 | Mine | yes | - | 2 | 3 | 3 | 0 | 0 | 0 | 0 |
| L0425 | 5 | 1 | Opponent | no | - | - | 0 | 5 | 0 | 0 | 0 | 0 |
| L0512 | 2 | 1 | Mine | - | - | - | 0 | 2 | 0 | 0 | 0 | 453 |
| L0512 | 2 | 1 | Opponent | - | - | 3 | 0 | 1 | 1 | 0 | 0 | 330 |
| **Average** | | | Mine | 50% | 11.0 | 2.5 | 1.0 | 2.3 | 0.0 | 0.0 | 0.0 | 151.0 |
| **Average** | | | Opponent | 0% | 0.0 | 3.0 | 0.0 | 2.7 | 0.3 | 0.0 | 0.0 | 243.0 |

### KPIs: csame-bb45c30-p15

Rules off - Mine only: NO OLD ONE-MOVE GUESS; both sides: ONE RUN A PLAN.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 20% (3 of 15) | 0% (0 of 14) | 10% (3 of 29) |
| Winner chose to follow up after the loser gave ground |  | 100% (3 of 3); on the table 100% | - | 100% (3 of 3); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | - | - | - |
| Winner chose to pursue after the loser fled |  | - | - | - |
| Winner chose to follow up or pursue (all three) |  | 100% (3 of 3); on the table 100% | - | 100% (3 of 3); on the table 100% |
| Magic missiles tried each own turn | 50%+ | 58% (7 of 12) | 44% (16 of 36) | 48% (23 of 48) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 70% (7 of 10) | 53% (16 of 30) | 58% (23 of 40) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | - | - |
| Points that never fought | lower | 74% (4423 of 5998) | 83% (4979 of 5998) | 78% (9402 of 11996) |
|   infantry points that never fought | lower | 73% (1046 of 1424) | 100% (1187 of 1187) | 86% (2233 of 2611) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 74% (17 of 23) | 89% (24 of 27) | 82% (41 of 50) |
| Bound items with a magic missile used (at least once a game) |  | 0.0 uses a game | 100% (3 of 3); 3.0 uses a game | 100% (3 of 3); 1.5 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
|   their share of the points of units over 100 pts | lower | 81% (4133 of 5120) | 92% (5007 of 5442) | 87% (9140 of 10562) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 0.3 (20%) | 3.3 (50%) | 3.7 (44%) |
| MARCHED: its unit marched | 0.7 (40%) | 1.3 (20%) | 2.0 (24%) |
| GONE: slain | 0.7 (40%) | 2.0 (30%) | 2.7 (32%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 5.3 | 0.0 | 1.3 | 7.7 | 0.7 | 0.3 |
| not cast | 4.7 | 6.0 | 4.7 | 8.3 | 1.3 | 19.7 |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 4.0 (67%) | 3.0 (64%) | 3.7 (44%) | 0.0 (0%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.0 (24%) | 0.3 (25%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (2%) |
| GONE: slain | 0.7 (14%) | 2.0 (33%) | 0.7 (14%) | 2.7 (32%) | 1.0 (75%) | 2.0 (10%) |
| HELD BACK: the computer weighed it and chose not to cast it | 4.0 (86%) | 0.0 (0%) | 1.0 (21%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 17.3 (88%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.3 a game | 1.0 a game | 0.7 a game |
| stood (cast and not dispelled) | 100% (1 of 1) | 67% (2 of 3) | 75% (3 of 4) |
| the unit moved after it | 100% (1 of 1) | 50% (1 of 2) | 67% (2 of 3) |
| it charged on its next turn | 0% (0 of 1) | 0% (0 of 2) | 0% (0 of 3) |
| the enemy charged it first | 0% (0 of 1) | 0% (0 of 2) | 0% (0 of 3) |
| it fought by the end of its next turn | 0% (0 of 1) | 0% (0 of 2) | 0% (0 of 3) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 1) | 0% (0 of 2) | 0% (0 of 3) |
| none of these (no charge, no fight, no charge escaped) | 100% (1 of 1) | 100% (2 of 2) | 100% (3 of 3) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 70% (74 of 105) | 60% (40 of 67) | 66% (114 of 172) |
|   cavalry | 25% (3 of 12) | - | 25% (3 of 12) |
|   character | 93% (25 of 27) | 100% (3 of 3) | 93% (28 of 30) |
|   chariot | 29% (7 of 24) | 50% (2 of 4) | 32% (9 of 28) |
|   infantry | 83% (10 of 12) | 52% (14 of 27) | 62% (24 of 39) |
|   monster | - | 67% (4 of 6) | 67% (4 of 6) |
|   war machine | 97% (29 of 30) | 63% (17 of 27) | 81% (46 of 57) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.7 (26%) | 1.3 (15%) | 4.0 (21%) |
| MOVED: a war machine that moved | 0.0 (0%) | 0.3 (4%) | 0.3 (2%) |
| NO TARGET IN RANGE | 6.0 (58%) | 1.0 (11%) | 7.0 (36%) |
| ONLY IN COMBAT: the only targets were in combat | 0.3 (3%) | 1.3 (15%) | 1.7 (9%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.3 (13%) | 2.0 (22%) | 3.3 (17%) |
| SHELTERED: the target was sheltered | 0.0 (0%) | 2.7 (30%) | 2.7 (14%) |
| OTHER BAR | 0.0 (0%) | 0.3 (4%) | 0.3 (2%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 1.0 | 0.0 | 100% | 0.0 pts | 0 pts |
| character | 9.3 | 1.7 | 82% | 7.6 pts | 71 pts |
| chariot | 3.0 | 4.3 | 44% | 22.5 pts | 68 pts |
| infantry | 11.3 | 1.7 | 85% | 7.9 pts | 90 pts |
| monster | 2.7 | 2.0 | 25% | 48.4 pts | 129 pts |
| war machine | 15.7 | 11.3 | 70% | 23.6 pts | 370 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 2.7 | 0.7 | 1.7 |
| Charges that made contact a game | 1.7 | 0.3 | 1.0 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.00 declared, 0.00 contact (2 units) | 0.00 declared, 0.00 contact (3 units) | 0.00 declared, 0.00 contact (5 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 0.50 declared, 0.50 contact (2 units) | 0.50 declared, 0.50 contact (2 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.36 declared, 0.23 contact (22 units) | 0.06 declared, 0.00 contact (17 units) | 0.23 declared, 0.13 contact (39 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 75% (3 of 4) | 100% (2 of 2) | - | 83% (5 of 6) |
| Character in a unit | 83% (5 of 6) | 100% (2 of 2) | - | 88% (7 of 8) |
| Character on its own | 100% (1 of 1) | 80% (4 of 5) | 100% (4 of 4) | 90% (9 of 10) |
| Chariot | - | 100% (5 of 5) | - | 100% (5 of 5) |
| Infantry | 58% (7 of 12) | 100% (3 of 3) | - | 67% (10 of 15) |
| Monstrous | - | 0% (0 of 1) | - | 0% (0 of 1) |
| War Machines | 100% (5 of 5) | - | - | 100% (5 of 5) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Chaos Dwarfs | 2 | 100% (3 of 3); on the table 100% | 58% (7 of 12) | 80% | 69% (11 of 16) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Dwarfen Mountain Holds | 1 | - | - | 62% | 86% (6 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 1 | - | 58% (7 of 12) | 74% | 75% (9 of 12) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Grand Cathay | 1 | - | 28% (5 of 18) | 90% | 100% (9 of 9) | 100% (3 of 3); 9.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Vampire Counts | 1 | - | 67% (4 of 6) | 85% | 100% (6 of 6) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (csame-bb45c30-p15, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 100% (1) | 75% (3) | 80% (4) |
| ...free all their last turn and able to turn (per game) | 0.33 | 0.33 | 0.67 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.67 | 0.67 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.33 | 0.33 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.33 | 0.00 | 0.33 |

### Quality by phase: csame-bb45c30-p15

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.7 | 4.0 |
| Strategy | Charge objectives carried out (made contact) | 62% (5 of 8) | 50% (1 of 2) |
| Strategy | Shoot objectives carried out (shot that target) | 23% (11 of 48) | 41% (16 of 39) |
| Strategy | Support requests answered (helper made contact too) | 0% (0 of 1) | 0% (0 of 1) |
| Strategy | Joined characters whose unit fought | 60% (3 of 5) | 0% (0 of 7) |
| Strategy | Lone characters that fought | 33% (2 of 6) | 14% (1 of 7) |
| Movement | Charges halted short of contact | 0.3 | 0.0 |
| Movement | Idle units | 2.3 | 2.7 |
| Movement | Points that never moved of their own | 151.0 | 243.0 |
| Movement | Fights charged into per game | 1.7 | 0.3 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 5 | 1 of 1, net +0 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 5 | 0 of 1 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 1 of 5, net +45 | 0 of 1 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 of 5, net +125 | 0 of 1 |
| Shooting | Shots by shooting units (incl. breath weapons) | 15.0 | 7.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 44% (20 of 45) | 57% (13 of 23) |
| Shooting | Points destroyed by shooting units | 126.3 | 193.3 |
| Shooting | War machine shots | 9.7 | 6.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 69% (20 of 29) | 39% (7 of 18) |
| Shooting | Points destroyed by war machines | 200.7 | 0.0 |
| Magic | Magic missiles cast | 1.7 | 3.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 40% (2 of 5) | 10% (1 of 10) |
| Magic | Wounds caused by magic missiles | 6.0 | 0.3 |
| Magic | Points destroyed by magic (all spells) | 0.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.7 / 0.0 / 0.0 / 0.0 | 1.3 / 0.0 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 186.7 | 0.0 |
| Combat | Points run down | 0.0 | 0.0 |
| Combat | Net points per charged fight, damage counted | +112 | -333 |
| Combat | Net per 100 charger points, damage counted | +37.5 | -162.6 |
| Combat | First round won (charged fights) | 100% | 0% |
| Combat | Net points per charged fight | +112 | +0 |
| Combat | Net points per supported fight / lone fight | - / +112 | - / +0 |
| Combat | Charged fights on a top-3 enemy unit | 2 of 5 | 1 of 1 |
| Game | Points lost | 176.7 | 480.3 |
| Game | VP from objectives | 610.0 | 373.3 |
| Game | Lone holders (player turns) | 11.0 | 0.0 |

- Mine won / drew / lost: 2 / 1 / 0 of 3 ended games (of 3); mean margin (Mine - Opponent) +557 VP
- The side that went first won 1 of 2 games with a winner
- Points traded per game (both sides' losses): 657
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: csame-bb45c30-p15

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| ARMY TABLE | 19.7 | +212.8 | 0.0 | 0.0 | 25.7 | +245.1 | 0.0 | 282.7 |
| ARTILLERY RE-ROLL WEIGHED | 2.3 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 41.7 |
| BACKUP TARGETS | 0.3 | +3.7 | 0.0 | 0.0 | - | - | - | - |
| CANNON PLAN MISSED | 2.0 | +0.0 | 635.7 | 0.0 | - | - | - | - |
| CANNON PLANNED TARGET | 9.3 | +226.1 | 1541.3 | 0.0 | 5.3 | +76.5 | 0.0 | 83.3 |
| CANNON SIGHT KEPT | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CAST JOB | 2.7 | +125.3 | 176.7 | 386.7 | 4.7 | +36.3 | 0.0 | 144.7 |
| CASTER AWAY FROM SCREEN | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| CHAFF PASSED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CHALLENGE BY POINTS | 0.3 | +12.2 | 0.0 | 0.0 | - | - | - | - |
| CHAMPION KNOWS CHALLENGE | - | - | - | - | 0.3 | -7.0 | 0.0 | 56.0 |
| CHARACTER GUNS | 1.0 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| CHARGE LOSSES | 11.3 | -344.8 | 0.0 | 193.3 | 15.3 | -657.3 | 0.0 | 672.3 |
| CHARGE NOW FIRST | 1.7 | +0.0 | 118.3 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 3.0 | +0.0 | 0.0 | 0.0 | 7.3 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | 0.3 | +67.1 | 0.0 | 0.0 | 0.3 | +0.9 | 0.0 | 0.0 |
| COVER ONCE | 10.0 | -1433.8 | 0.0 | 0.0 | 8.3 | -748.2 | 0.0 | 0.0 |
| DEPLOY BY FIGURES | 8.7 | +61.0 | 0.0 | 0.0 | 6.3 | +5.3 | 0.0 | 0.0 |
| EXACT ROUND | 2.0 | +40.3 | 171.7 | 0.0 | 0.3 | -10.4 | 0.0 | 56.0 |
| FALL BACK GOOD ORDER | 2.3 | +0.0 | 160.0 | 0.0 | - | - | - | - |
| FALLBACK BY WORTH | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| FALLS SHORT | 7.7 | +93.1 | 0.0 | 386.7 | 15.0 | +182.6 | 0.0 | 724.3 |
| FIGHT TO THE END | 0.3 | +16.1 | 88.3 | 0.0 | 0.7 | +19.6 | 0.0 | 56.0 |
| FIRE IN ORDER | 0.7 | +0.0 | 56.0 | 0.0 | - | - | - | - |
| FIVE ACTION | 106.3 | +6725.7 | 3685.0 | 773.3 | 97.3 | +3423.7 | 1546.7 | 1448.7 |
| FLANK NOT WEIGHED | 5.3 | +0.0 | 0.0 | 0.0 | 9.0 | +0.0 | 0.0 | 0.0 |
| FOLLOW UP WEIGHED | 0.7 | +51.3 | 0.0 | 0.0 | - | - | - | - |
| FOUR ROUNDS | 2.7 | +169.5 | 201.7 | 0.0 | 0.7 | +99.2 | 0.0 | 56.0 |
| FREED FROM HIS FIGHT | - | - | - | - | 1.7 | +0.0 | 0.0 | 126.3 |
| FRIEND SHOOTS FIRST | 0.7 | -0.2 | 0.0 | 0.0 | - | - | - | - |
| GIVES UP | 0.7 | -9.4 | 0.0 | 0.0 | - | - | - | - |
| GOAL WALK | 11.0 | +800.8 | 0.0 | 0.0 | 4.0 | +157.0 | 0.0 | 0.0 |
| GUN FIGURES | 1.0 | +0.4 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| GUN MASK | 1.3 | +66.1 | 0.0 | 0.0 | 1.0 | +57.1 | 0.0 | 0.0 |
| HARD STAY DROPPED | 3.0 | +0.0 | 0.0 | 193.3 | 1.7 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | - | - | - | - | 1.7 | +0.0 | 0.0 | 126.3 |
| HIS CHARGE BY HIS RUN | 4.3 | +0.0 | 0.0 | 0.0 | 8.3 | +0.0 | 0.0 | 434.0 |
| HIS CHARGE LIST | 2.7 | +0.0 | 0.0 | 0.0 | 13.3 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 3.3 | +0.0 | 0.0 | 193.3 | 2.0 | +0.0 | 0.0 | 401.3 |
| HIS MOVE AND SHOT | 1.0 | -5.4 | 0.0 | 0.0 | 0.3 | -12.6 | 0.0 | 0.0 |
| HIS MOVE AS HE DECIDES | 39.3 | +12.3 | 757.3 | 0.0 | - | - | - | - |
| HIS MOVE WHY | - | - | - | - | 27.3 | +0.0 | 0.0 | 539.3 |
| HIS ONE MOVE | 23.0 | -34.0 | 0.0 | 0.0 | - | - | - | - |
| HIS ONE QUARTER | 5.7 | +0.0 | 0.0 | 0.0 | 4.7 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 2.3 | +0.0 | 0.0 | 193.3 | 2.0 | +0.0 | 0.0 | 401.3 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 44.7 | +3558.8 | 0.0 | 386.7 | 53.0 | +3700.2 | 0.0 | 1051.3 |
| HIS SHOTS BY HIS RUN | 32.7 | +741.4 | 0.0 | 386.7 | 26.3 | +816.6 | 0.0 | 798.7 |
| HIS TURN DENIED | 1.0 | +27.0 | 171.7 | 0.0 | - | - | - | - |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 10.3 | +0.0 | 0.0 | 0.0 | 11.3 | +0.0 | 0.0 | 0.0 |
| HOLDER ASSIGNMENT | 7.0 | +632.7 | 0.0 | 0.0 | 9.3 | +849.4 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 2.7 | -85.2 | 201.7 | 0.0 | 0.7 | -21.0 | 0.0 | 56.0 |
| HUNT IN PAIRS | - | - | - | - | 2.3 | +282.9 | 0.0 | 271.0 |
| IDLE COST | 5.3 | -94.5 | 0.0 | 0.0 | 14.7 | -231.3 | 0.0 | 412.3 |
| JOINT CHARGE NOW | 0.7 | -5.3 | 30.0 | 0.0 | 0.7 | +84.1 | 0.0 | 56.0 |
| KEPT FROM ITS LAST STOP | 2.0 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 1.3 | +64.9 | 0.0 | 0.0 | - | - | - | - |
| LEGAL CHARGES ONLY | 0.3 | +0.0 | 88.3 | 0.0 | 0.7 | +0.0 | 0.0 | 176.7 |
| LONE WIZARD KEPT IN | - | - | - | - | 0.7 | +30.1 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | 0.7 | -0.1 | 88.3 | 0.0 | 0.3 | -0.7 | 0.0 | 0.0 |
| MANOEUVRE | 1.7 | -23.4 | 0.0 | 0.0 | 3.3 | -15.0 | 0.0 | 0.0 |
| MARCH BY THE SUM | 0.3 | +14.7 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | 0.3 | +23.1 | 0.0 | 0.0 | 1.7 | +86.6 | 0.0 | 0.0 |
| MARCH OF THE TABLE | 0.3 | +7.4 | 0.0 | 0.0 | 0.7 | +38.0 | 0.0 | 126.3 |
| MARCH OVER CASTS | 0.3 | +1.9 | 0.0 | 0.0 | 0.3 | -26.9 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 1.3 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 2.0 | +63.6 | 0.0 | 386.7 | 2.3 | +35.9 | 0.0 | 271.0 |
| MEETS IN TIME | 5.3 | +153.6 | 0.0 | 0.0 | 2.3 | +33.0 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 2.3 | +111.0 | 0.0 | 386.7 | 10.0 | +78.9 | 0.0 | 471.7 |
| MISSILES NEXT TURN | 3.0 | +94.1 | 0.0 | 386.7 | 10.7 | +84.4 | 0.0 | 453.3 |
| MOVE ORDER | 1.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| MOVE SPELL IN RANGE | 3.3 | +170.7 | 0.0 | 386.7 | - | - | - | - |
| MOVE SPELL SPOT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 3.0 | +263.5 | 0.0 | 193.3 | 1.7 | +197.9 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 9.0 | +391.8 | 0.0 | 0.0 | 9.3 | +371.5 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 1.0 | +116.6 | 0.0 | 0.0 | 0.7 | +40.8 | 0.0 | 0.0 |
| NEXT OBJECTIVE NEARER | - | - | - | - | 0.3 | -10.0 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 1.7 | -66.2 | 201.7 | 0.0 | 0.3 | -6.0 | 0.0 | 56.0 |
| NO LATE CUT | 0.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 5.0 | -234.8 | 0.0 | 0.0 | 7.0 | -375.1 | 0.0 | 168.0 |
| OGRE LOADER SECOND SHOT | - | - | - | - | 2.7 | +0.0 | 0.0 | 0.0 |
| ONE CHECK AFTER THE LAST CHANGE | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ONE FIGHT FORMULA | 2.7 | -52.6 | 0.0 | 386.7 | 4.3 | -84.4 | 0.0 | 200.7 |
| ONE OBJECTIVE FORMULA | 0.7 | +6.7 | 0.0 | 0.0 | 4.3 | -15.6 | 0.0 | 0.0 |
| ONE ROUTE | 1.3 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| OPENS UP | 0.3 | +16.7 | 15.0 | 0.0 | - | - | - | - |
| OVERRUNS AWAY | 0.3 | +4.0 | 41.7 | 0.0 | - | - | - | - |
| PATHS CROSS | 0.7 | +28.4 | 0.0 | 0.0 | 0.7 | -2.2 | 0.0 | 0.0 |
| PLAN RESULT | 47.3 | +1355.0 | 634.3 | 386.7 | 43.0 | +968.8 | 773.3 | 868.0 |
| PROMISE BELOW ZERO | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE BY ITS OWN SUM | 4.7 | -141.3 | 0.0 | 193.3 | 4.0 | -157.1 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | 0.3 | +0.0 | 0.0 | 193.3 | 0.7 | +0.0 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | 0.7 | -0.2 | 0.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | 20.0 | +2548.7 | 83.3 | 0.0 | 18.7 | +1310.2 | 0.0 | 83.3 |
| REAL GROUND | 1.3 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | 1.7 | +339.8 | 0.0 | 0.0 | 0.3 | +52.9 | 0.0 | 15.0 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 0.3 | +0.0 | 0.0 | 15.0 |
| REFORMS TO MEET IT | 1.0 | -32.9 | 0.0 | 0.0 | 0.3 | -15.8 | 0.0 | 0.0 |
| REFUSING RETIRES | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| RISK BY ARC | 2.3 | -51.6 | 201.7 | 0.0 | 0.7 | -51.5 | 0.0 | 56.0 |
| RISK ON THE WAY | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ROUNDS AFTER TERROR | 0.7 | -11.1 | 83.3 | 0.0 | - | - | - | - |
| RUN DOWN | 0.7 | +0.0 | 83.3 | 0.0 | - | - | - | - |
| SCOUT SPOT | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| SCOUT WAITS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 0.7 | -19.6 | 0.0 | 30.0 |
| SEARCH SPOT | 0.7 | +9.3 | 0.0 | 0.0 | - | - | - | - |
| SET CREDITED ONCE | - | - | - | - | 3.0 | -202.2 | 0.0 | 0.0 |
| SET UP BY THE SET | - | - | - | - | 3.7 | +215.7 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.7 | +1.3 | 0.0 | 0.0 | 0.3 | +0.7 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 17.7 | +0.0 | 0.0 | 193.3 | 12.0 | +0.0 | 0.0 | 243.0 |
| SHOOTS FROM THE BEST SPOT | 2.3 | +329.9 | 0.0 | 0.0 | 3.7 | +15.2 | 0.0 | 0.0 |
| SHOT OR CHARGE | 0.3 | -15.9 | 0.0 | 0.0 | 0.3 | -8.8 | 0.0 | 0.0 |
| SHOT RISK POINTS | 22.7 | +572.7 | 0.0 | 386.7 | 27.3 | +358.7 | 0.0 | 906.7 |
| SHOTS AFTER THE MOVES | 3.3 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 17.3 | +938.1 | 0.0 | 0.0 | 15.7 | +449.4 | 0.0 | 83.3 |
| SPELL WORTH | - | - | - | - | 2.0 | +56.8 | 289.3 | 289.3 |
| SPOT AS THE GAME MOVES | 3.0 | +0.0 | 0.0 | 0.0 | 8.3 | +0.0 | 0.0 | 0.0 |
| STAND AND SHOOT | - | - | - | - | 0.3 | -2.6 | 0.0 | 56.0 |
| STANDS FOR A REASON | 0.7 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 434.0 |
| STANDS STILL | 65.3 | +0.0 | 3483.3 | 386.7 | 43.0 | +0.0 | 1546.7 | 437.7 |
| STAY WORTH | 33.0 | +40.6 | 1784.0 | 386.7 | 26.7 | -154.5 | 773.3 | 125.0 |
| SUPPORT ADDS | 3.7 | +255.0 | 0.0 | 0.0 | 2.7 | +162.5 | 0.0 | 0.0 |
| SUPPORT WORKED OUT | 3.7 | +255.0 | 0.0 | 0.0 | 2.7 | +162.5 | 0.0 | 0.0 |
| SURE REACH TOGETHER | - | - | - | - | 1.0 | +31.2 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 2.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 1.3 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 2.0 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 1.3 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 52.3 | +0.0 | 0.0 | 386.7 | 45.3 | +0.0 | 0.0 | 711.3 |
| TIED UP BY THE SUM | 0.7 | +58.8 | 56.7 | 0.0 | - | - | - | - |
| TIME ON OUR SIDE | 41.3 | +452.2 | 112.0 | 0.0 | 15.7 | +165.9 | 0.0 | 0.0 |
| WAITS AGAIN | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WAR ENGINE JOBS | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT DANGER | 1.3 | -46.0 | 0.0 | 0.0 | 2.7 | -137.0 | 0.0 | 144.7 |
| WOUNDS ON THE RANKS | 1.7 | +61.0 | 0.0 | 0.0 | - | - | - | - |

### Rule changes: csame-bb45c30-p15

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 136 | 136 | 83 | 27.67 | +1333 | +16.1 |
| HIS MOVE AS HE DECIDES | 118 | 118 | 81 | 27.00 | +0 | +0.0 |
| HIS SHOT LIST | 293 | 281 | 61 | 20.33 | +1156 | +19.0 |
| HIS MOVE WHY | 82 | 82 | 60 | 20.00 | +0 | +0.0 |
| HOLDER ASSIGNMENT | 49 | 49 | 47 | 15.67 | +3120 | +66.4 |
| HIS SHOTS BY HIS RUN | 177 | 165 | 46 | 15.33 | +555 | +12.1 |
| SHOT RISK POINTS | 150 | 143 | 42 | 14.00 | +909 | +21.6 |
| OFF BEST | 36 | 36 | 36 | 12.00 | -1830 | -50.8 |
| THE TABLE AGAIN | 36 | 36 | 26 | 8.67 | +0 | +0.0 |
| TIME ON OUR SIDE | 171 | 157 | 24 | 8.00 | +112 | +4.7 |
| DEPLOY BY FIGURES | 45 | 45 | 22 | 7.33 | +460 | +20.9 |
| HIS ONE MOVE | 69 | 66 | 21 | 7.00 | +0 | +0.0 |
| ARTILLERY RE-ROLL WEIGHED | 17 | 17 | 17 | 5.67 | +0 | +0.0 |
| CAST JOB | 22 | 22 | 17 | 5.67 | +90 | +5.3 |
| COVER ONCE | 55 | 46 | 16 | 5.33 | +318 | +19.9 |
| QUARTER ODDS | 116 | 101 | 16 | 5.33 | +1439 | +89.9 |
| FIVE ACTION | 611 | 587 | 14 | 4.67 | +380 | +27.1 |
| HARD STAY DROPPED | 14 | 14 | 14 | 4.67 | +0 | +0.0 |
| MEETS IN TIME | 23 | 23 | 10 | 3.33 | +383 | +38.3 |
| SHOOTS FROM THE BEST SPOT | 18 | 18 | 9 | 3.00 | +279 | +31.0 |
| OGRE LOADER SECOND SHOT | 8 | 8 | 8 | 2.67 | +0 | +0.0 |
| PROMISE BY ITS OWN SUM | 26 | 26 | 8 | 2.67 | -895 | -111.9 |
| STAY WORTH | 179 | 167 | 8 | 2.67 | +19 | +2.4 |
| IDLE COST | 60 | 50 | 7 | 2.33 | +40 | +5.8 |
| GOAL WALK | 45 | 45 | 6 | 2.00 | +107 | +17.8 |
| MOVE ORDER | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| SUPPORT ADDS | 19 | 19 | 6 | 2.00 | +181 | +30.2 |
| SUPPORT WORKED OUT | 19 | 19 | 6 | 2.00 | +181 | +30.2 |
| ADVANCE LANE KEPT | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| CHARGE LOSSES | 80 | 75 | 5 | 1.67 | +101 | +20.2 |
| FOUR ROUNDS | 10 | 10 | 5 | 1.67 | +233 | +46.7 |
| MARCH CHECK | 6 | 6 | 5 | 1.67 | +106 | +21.1 |
| SET UP BY THE SET | 11 | 11 | 5 | 1.67 | +304 | +60.8 |
| SHOTS IN THE MOVE | 99 | 80 | 5 | 1.67 | +375 | +75.0 |
| CANNON SIGHT KEPT | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| JOINT CHARGE NOW | 4 | 4 | 4 | 1.33 | +236 | +59.1 |
| LANE BY FIGURES | 4 | 4 | 4 | 1.33 | +195 | +48.6 |
| MANOEUVRE | 15 | 15 | 4 | 1.33 | +44 | +10.9 |
| MOVE TO CHARGE COMPUTED | 14 | 8 | 4 | 1.33 | +195 | +48.7 |
| PATHS CROSS | 4 | 4 | 4 | 1.33 | +78 | +19.6 |
| SHOTS AFTER THE MOVES | 21 | 21 | 4 | 1.33 | +0 | +0.0 |
| CANNON PLANNED TARGET | 44 | 44 | 3 | 1.00 | +0 | +0.0 |
| CHARGE NOW FIRST | 6 | 6 | 3 | 1.00 | -380 | -126.6 |
| LEGAL CHARGES ONLY | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| MARCH OF THE TABLE | 3 | 3 | 3 | 1.00 | -136 | -45.4 |
| SHOOTERS IN TWO RANKS | 3 | 3 | 3 | 1.00 | +6 | +2.0 |
| CASTS FROM BEHIND | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| FALLS SHORT | 68 | 59 | 2 | 0.67 | +26 | +12.8 |
| FIRE IN ORDER | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 2 | 2 | 2 | 0.67 | +154 | +77.0 |
| HOLDS AMBUSHERS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| HONEST WORTH | 10 | 10 | 2 | 0.67 | +59 | +29.4 |
| HUNT IN PAIRS | 7 | 6 | 2 | 0.67 | +129 | +64.5 |
| LONE WIZARD KEPT IN | 2 | 2 | 2 | 0.67 | +90 | +45.1 |
| MAX FOR POSITIONING | 13 | 12 | 2 | 0.67 | +1 | +0.5 |
| NEXT CHARGE BY LIST | 5 | 5 | 2 | 0.67 | +193 | +96.4 |
| RISK BY ARC | 9 | 9 | 2 | 0.67 | +41 | +20.6 |
| SCOUT WAITS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| TIED UP BY THE SUM | 2 | 2 | 2 | 0.67 | +69 | +34.5 |
| CASTER AWAY FROM SCREEN | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CHAFF PASSED | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CHALLENGE BY POINTS | 1 | 1 | 1 | 0.33 | +37 | +36.5 |
| EXACT ROUND | 7 | 7 | 1 | 0.33 | +16 | +15.7 |
| FIGHT TO THE END | 3 | 3 | 1 | 0.33 | +40 | +40.5 |
| HIS TURN DENIED | 3 | 3 | 1 | 0.33 | +2 | +2.1 |
| MARCH BY THE SUM | 1 | 1 | 1 | 0.33 | +44 | +44.1 |
| MISSILES NEXT TURN | 41 | 30 | 1 | 0.33 | +0 | +0.0 |
| NEARER NOT NEEDED | 55 | 53 | 1 | 0.33 | +39 | +39.0 |
| ONE OBJECTIVE FORMULA | 15 | 10 | 1 | 0.33 | +75 | +75.3 |
| OPENS UP | 1 | 1 | 1 | 0.33 | +26 | +25.9 |
| REDIRECT COUNTER | 6 | 5 | 1 | 0.33 | +217 | +217.3 |
| REDIRECT FOR A FRIEND IN REACH | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| REFUSING RETIRES | 1 | 1 | 1 | 0.33 | -1 | -0.6 |
| SEARCH SPOT | 2 | 2 | 1 | 0.33 | +28 | +27.9 |
| THE ROW IN ITS ORDER | 14 | 1 | 1 | 0.33 | +0 | +0.0 |
| WOUNDS ON THE RANKS | 5 | 5 | 1 | 0.33 | +11 | +10.7 |
| BACKUP TARGETS | 1 | not checked | - | - | - | - |
| CANNON PLAN MISSED | 6 | 6 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 2 | trace | - | - | - | - |
| CHAMPION KNOWS CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| CHARACTER GUNS | 8 | 6 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 31 | 31 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 2 | not checked | - | - | - | - |
| FALL BACK GOOD ORDER | 7 | 7 | 0 | 0.00 | - | - |
| FALLBACK BY WORTH | 1 | 1 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 43 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 5 | 5 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 2 | 2 | 0 | 0.00 | - | - |
| GIVES UP | 2 | 2 | 0 | 0.00 | - | - |
| GUN FIGURES | 4 | not checked | - | - | - | - |
| GUN MASK | 7 | 7 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 5 | 5 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 38 | 37 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 48 | 46 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 16 | 16 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 4 | 3 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 31 | 24 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 13 | 13 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN RUN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 65 | 65 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 17 | 17 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 3 | 3 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 2 | 2 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 11 | 11 | 0 | 0.00 | - | - |
| MISSILES IN THE MOVE | 37 | 26 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 10 | 6 | 0 | 0.00 | - | - |
| MOVE SPELL SPOT | 1 | not checked | - | - | - | - |
| NEXT OBJECTIVE NEARER | 1 | 1 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 6 | 6 | 0 | 0.00 | - | - |
| NO LATE CUT | 6 | 6 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 18 | 18 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT TURNED | 1 | 1 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 2 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 21 | 13 | 0 | 0.00 | - | - |
| ONE ROUTE | 11 | 11 | 0 | 0.00 | - | - |
| OVERRUNS AWAY | 1 | 1 | 0 | 0.00 | - | - |
| PLAN RESULT | 271 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE KNOWS THE FIGHT | 3 | not checked | - | - | - | - |
| PROMISE READS THE TABLE | 2 | 2 | 0 | 0.00 | - | - |
| REAL GROUND | 11 | 11 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 4 | 1 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 2 | 2 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 2 | 2 | 0 | 0.00 | - | - |
| RUN DOWN | 2 | 2 | 0 | 0.00 | - | - |
| SCOUT SPOT | 2 | 2 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 2 | 2 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 9 | 9 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 89 | not checked | - | - | - | - |
| SHOT OR CHARGE | 2 | 2 | 0 | 0.00 | - | - |
| SPELL WORTH | 6 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 34 | 28 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 1 | 1 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 9 | 9 | 0 | 0.00 | - | - |
| STANDS STILL | 325 | 313 | 0 | 0.00 | - | - |
| SURE REACH TOGETHER | 3 | 2 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 12 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 18 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 15 | not checked | - | - | - | - |
| THE TABLE BINDS | 293 | not checked | - | - | - | - |
| WAITS AGAIN | 4 | 3 | 0 | 0.00 | - | - |
| WAR ENGINE JOBS | 2 | 2 | 0 | 0.00 | - | - |
| WHOLE FIGHT DANGER | 12 | 12 | 0 | 0.00 | - | - |

### Off best figure: csame-bb45c30-p15

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 1.67 | 6.67 | 55.1 |
| ARMY TABLE | rule | 1.00 | 4.00 | 63.3 |
| RULE SWITCHED OFF | gate | 3.33 | 0.33 | 41.2 |
| PROMISE BY ITS OWN SUM | rule | 1.67 | 1.00 | 111.9 |
| HOLDER ASSIGNMENT | rule | 0.33 | 1.33 | 38.9 |
| CHARGE NOW FIRST | rule | 0.67 | 0.33 | 126.6 |
| MARCH OF THE TABLE | rule | 0.33 | 0.67 | 45.4 |
| JOINT CHARGE NOW | rule | 0.33 | - | 41.8 |
| PATHS CROSS | rule | - | 0.33 | 6.7 |
| REFUSING RETIRES | rule | - | 0.33 | 0.6 |

### Plans: csame-bb45c30-p15

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 2.0 | 67% | 247 | 125 | 50% |
| Mine | join | 1.0 | 100% | 30 | 0 | 0% |
| Mine | move | 31.7 | 99% | 2143 | 0 | 0% |
| Mine | shoot | 12.7 | 61% | 482 | 1230 | 255% |
| Opponent | charge | 0.7 | 0% | 80 | 0 | 0% |
| Opponent | join | 1.0 | 100% | 51 | 0 | 0% |
| Opponent | move | 29.7 | 98% | 1031 | 0 | 0% |
| Opponent | shoot | 11.3 | 59% | 510 | 969 | 190% |
| Opponent | support | 0.3 | 0% | 0 | 0 | - |

### Battle groups: csame-bb45c30-p15

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 1.7 | 0% | - | - | - | - | - | - | - | - |
| Opponent | REDIRECT COUNTER | 0.3 | 100% | 100% | 0% | - | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: csame-bb45c30-p15

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | 0 (1) | - | - | 0 (1) | - |
| Mine | Character | 11 | 35 (11) | 35 | 0 | 23 | 9% | 3.0 | 26 (8) | 67 (3) | - | 47 (8) | 0 (3) |
| Mine | Clean-up | 6 | 92 (6) | 0 | 92 | 0 | 100% | - | 0 (3) | 185 (2) | 250 (1) | 113 (5) | 0 (1) |
| Mine | Fast Hammer | 1 | 0 (1) | 0 | 0 | 0 | 0% | 1.0 | - | 0 (1) | - | - | 0 (1) |
| Mine | Hammer | 6 | 0 (6) | 0 | 0 | 0 | 33% | 4.0 | 0 (2) | 0 (4) | - | 0 (5) | 0 (1) |
| Mine | Holder | 2 | 27 (2) | 16 | 11 | 0 | 50% | 2.0 | 22 (1) | 32 (1) | - | 27 (2) | - |
| Mine | Shooter | 2 | 0 (2) | 0 | 0 | 0 | 0% | 2.0 | 0 (1) | 0 (1) | - | 0 (2) | - |
| Mine | War machine | 5 | 127 (5) | 127 | 0 | 0 | 0% | 1.2 | 317 (2) | 0 (1) | 0 (2) | - | 127 (5) |
| Opponent | Chaff | 4 | 0 (4) | 0 | 0 | 18 | 75% | 2.0 | 0 (4) | - | - | 0 (3) | 0 (1) |
| Opponent | Character | 9 | 0 (9) | 0 | 0 | 25 | 67% | 2.7 | 0 (3) | 0 (5) | 0 (1) | 0 (5) | 0 (4) |
| Opponent | Clean-up | 2 | 0 (2) | 0 | 0 | 0 | 50% | 6.0 | 0 (1) | 0 (1) | - | 0 (1) | 0 (1) |
| Opponent | Fast Hammer | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | 0 (1) | - | - | - | 0 (1) |
| Opponent | Hammer | 3 | 83 (3) | 83 | 0 | 38 | 33% | 1.5 | - | 83 (3) | - | 118 (2) | 0 (1) |
| Opponent | Holder | 3 | 0 (3) | 0 | 0 | 31 | 67% | 3.0 | - | 0 (2) | 0 (1) | 0 (2) | 0 (1) |
| Opponent | Shooter | 3 | 87 (3) | 0 | 87 | 0 | 0% | 1.0 | - | 231 (1) | 14 (2) | 115 (2) | 29 (1) |
| Opponent | Support | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | War machine | 5 | 0 (5) | 0 | 0 | 35 | 20% | 1.0 | - | - | 0 (5) | - | 0 (5) |
| Opponent | Wizard | 5 | 0 (5) | 0 | 0 | 48 | 20% | 2.5 | 0 (3) | 0 (2) | - | 0 (2) | 0 (3) |

### Charged fights: csame-bb45c30-p15

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaos Dwarfs | 2 | 0 | 280 | 2.5 | 1.0 | 112 | 0 | +112 | 2 of 5 | 5 of 5 | - | +112 |
| Mine | Dwarfen Mountain Holds | 1 | 981 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| **Mine** | all armies | 3 | 327 | 187 | 1.7 | 1.0 | 112 | 0 | +112 | 2 of 5 | 5 of 5 | - | +112 |
| Opponent | Empire of Man | 1 | 580 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Grand Cathay | 1 | 0 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 1 of 1 | 0 of 1 | - | +0 |
| Opponent | Vampire Counts | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| **Opponent** | all armies | 3 | 193 | 0 | 0.3 | 1.0 | 0 | 0 | +0 | 1 of 1 | 0 of 1 | - | +0 |

### Effective charges: csame-bb45c30-p15

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaos Dwarfs | 5 | 0 | 0 | 0 | 2 (net +132) | 1 (net +45) | 2 (net +125) | 0 | 0% (0 of 5) |
| Opponent | Grand Cathay | 1 | 1 (net +0) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 1) |

### Charged fights, damage counted: csame-bb45c30-p15

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 76-89% | 2 | 339 | 260 | +132 | 132 | 0 | +132 | +39.1 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 339 | 125 | +125 | 125 | 0 | +125 | +36.9 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 139 | 45 | +45 | 45 | 0 | +45 | +32.4 |
| Mine | All fights | 5 | 299 | 163 | +112 | 112 | 0 | +112 | +37.5 |
| Opponent | Long shot (under 50%) | 1 | 205 | 239 | +0 | 15 | 348 | -333 | -162.6 |
| Opponent | All fights | 1 | 205 | 239 | +0 | 15 | 348 | -333 | -162.6 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| csame-bb45c30-p15 | move | 9 | 1 (11%) | 1 (11%) | 0 (0%) | 8 (89%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L0425 |
| Clockwork Compass | Opponent | L0512 |
| Invocation of Nehek | Opponent | L0425 |
| Ring of Doom | Opponent | L0512 |
| Ring of Jet | Opponent | L0512 |

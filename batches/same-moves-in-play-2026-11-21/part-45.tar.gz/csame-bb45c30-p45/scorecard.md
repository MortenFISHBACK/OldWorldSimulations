# Doctrine scorecard: csame-bb45c30-p45

### Scorecard: csame-bb45c30-p45

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L1531 | 1 | 1 | Mine | no | 0 | 2 | 4 | 0 | 0 | 0 | 0 | 0 |
| L1531 | 1 | 1 | Opponent | no | 2 | 4 | 2 | 3 | 4 | 0 | 0 | 732 |
| L1629 | 3 | 1 | Mine | no | 4 | 2 | 3 | 1 | 0 | 0 | 0 | 200 |
| L1629 | 3 | 1 | Opponent | no | 0 | 3 | 2 | 3 | 0 | 0 | 0 | 0 |
| L1727 | 5 | 1 | Mine | yes | - | 3 | 2 | 0 | 0 | 0 | 0 | 0 |
| L1727 | 5 | 1 | Opponent | yes | - | 2 | 7 | 6 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 33% | 2.0 | 2.3 | 3.0 | 0.3 | 0.0 | 0.0 | 0.0 | 66.7 |
| **Average** | | | Opponent | 33% | 1.0 | 3.0 | 3.7 | 4.0 | 1.3 | 0.0 | 0.0 | 244.0 |

### KPIs: csame-bb45c30-p45

Rules off - Opponent only: NO OLD ONE-MOVE GUESS; both sides: ONE RUN A PLAN.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 17) | 0% (0 of 16) | 0% (0 of 33) |
| Winner chose to follow up after the loser gave ground |  | 100% (5 of 5); on the table 100% | 80% (4 of 5); on the table 80% | 90% (9 of 10); on the table 90% |
| Winner chose to pursue after the loser fell back in good order |  | - | 0% (0 of 1); on the table 0% | 0% (0 of 1); on the table 0% |
| Winner chose to pursue after the loser fled |  | 50% (1 of 2); on the table 50% | - | 50% (1 of 2); on the table 50% |
| Winner chose to follow up or pursue (all three) |  | 86% (6 of 7); on the table 86% | 67% (4 of 6); on the table 67% | 77% (10 of 13); on the table 77% |
| Magic missiles tried each own turn | 50%+ | - | 33% (4 of 12) | 33% (4 of 12) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | - | 40% (4 of 10) | 40% (4 of 10) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 60% (9 of 15) | 60% (9 of 15) |
| Points that never fought | lower | 20% (1230 of 6000) | 48% (2902 of 5999) | 34% (4132 of 11999) |
|   infantry points that never fought | lower | 27% (366 of 1332) | 86% (735 of 855) | 50% (1101 of 2187) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 40% (8 of 20) | 76% (19 of 25) | 60% (27 of 45) |
| Bound items with a magic missile used (at least once a game) |  | 100% (2 of 2); 2.3 uses a game | 100% (1 of 1); 0.7 uses a game | 100% (3 of 3); 1.5 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 100% (1 of 1); 0.3 uses a game | 0.0 uses a game | 100% (1 of 1); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 32% (1636 of 5135) | 71% (3849 of 5430) | 52% (5485 of 10565) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | - | 1.7 (62%) | 1.7 (62%) |
| MARCHED: its unit marched | - | 0.3 (12%) | 0.3 (12%) |
| OFF THE TABLE: off the table or not arrived | - | 0.7 (25%) | 0.7 (25%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 3.7 | 1.0 | 0.7 | 1.3 | 2.0 |
| not cast | 6.3 | 1.0 | 1.3 | 2.7 | 18.0 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.7 (9%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.7 (62%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (12%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.3 (5%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (2%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (25%) | 0.0 (0%) |
| STUPIDITY: Stupidity | 0.3 (5%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 1.0 (16%) | 1.0 (100%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 4.7 (74%) | 0.0 (0%) | 1.3 (100%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 16.0 (89%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.7 a game | 0.0 a game | 0.3 a game |
| stood (cast and not dispelled) | - | - | - |
| the unit moved after it | - | - | - |
| it charged on its next turn | - | - | - |
| the enemy charged it first | - | - | - |
| it fought by the end of its next turn | - | - | - |
| it moved out of a charge the enemy had planned (not charged first) | - | - | - |
| none of these (no charge, no fight, no charge escaped) | - | - | - |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 51% (39 of 77) | 25% (1 of 4) | 49% (40 of 81) |
|   cavalry | 83% (10 of 12) | 33% (1 of 3) | 73% (11 of 15) |
|   character | 30% (3 of 10) | 0% (0 of 1) | 27% (3 of 11) |
|   chariot | 0% (0 of 6) | - | 0% (0 of 6) |
|   infantry | 53% (18 of 34) | - | 53% (18 of 34) |
|   monster | 42% (5 of 12) | - | 42% (5 of 12) |
|   war machine | 100% (3 of 3) | - | 100% (3 of 3) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.0 (16%) | 0.3 (33%) | 2.3 (17%) |
| CHARGED: it charged | 2.0 (16%) | 0.0 (0%) | 2.0 (15%) |
| IN COMBAT: it fought this turn or the last | 1.3 (11%) | 0.0 (0%) | 1.3 (10%) |
| NO TARGET IN RANGE | 3.0 (24%) | 0.3 (33%) | 3.3 (24%) |
| ONLY IN COMBAT: the only targets were in combat | 2.3 (18%) | 0.0 (0%) | 2.3 (17%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 2.0 (16%) | 0.3 (33%) | 2.3 (17%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 3.7 | 1.0 | 73% | 4.6 pts | 17 pts |
| character | 1.7 | 1.0 | 60% | 19.1 pts | 32 pts |
| infantry | 10.7 | 1.7 | 88% | 4.4 pts | 47 pts |
| monster | 2.3 | 0.0 | 100% | 0.0 pts | 0 pts |
| war machine | 1.0 | 0.0 | 100% | 0.0 pts | 0 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 5.0 | 4.7 | 4.8 |
| Charges that made contact a game | 4.0 | 3.7 | 3.8 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | - | 0.50 declared, 0.50 contact (2 units) | 0.50 declared, 0.50 contact (2 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.75 declared, 0.50 contact (4 units) | 1.33 declared, 1.00 contact (3 units) | 1.00 declared, 0.71 contact (7 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.60 declared, 0.50 contact (20 units) | 0.45 declared, 0.35 contact (20 units) | 0.53 declared, 0.42 contact (40 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 80% (4 of 5) | 100% (3 of 3) | 50% (1 of 2) | 80% (8 of 10) |
| Character in a unit | 100% (2 of 2) | - | - | 100% (2 of 2) |
| Character on its own | 60% (3 of 5) | 50% (1 of 2) | 33% (3 of 9) | 44% (7 of 16) |
| Chariot | 100% (1 of 1) | - | - | 100% (1 of 1) |
| Infantry | 43% (3 of 7) | 0% (0 of 3) | - | 30% (3 of 10) |
| Monster | 100% (6 of 6) | - | - | 100% (6 of 6) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| High Elf Realms | 1 | 67% (2 of 3); on the table 67% | - | 19% | 29% (2 of 7) | 100% (2 of 2); 7.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | 100% (3 of 3); on the table 100% | - | 18% | 33% (2 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Lizardmen | 1 | 100% (1 of 1); on the table 100% | - | 24% | 57% (4 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 1 | 50% (1 of 2); on the table 50% | 17% (1 of 6) | 62% | 67% (4 of 6) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 2 | 75% (3 of 4); on the table 75% | 50% (3 of 6) | 41% | 79% (15 of 19) | 100% (1 of 1); 1.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (csame-bb45c30-p45, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 60% (3) | 62% (5) | 62% (8) |
| ...free all their last turn and able to turn (per game) | 0.33 | 1.00 | 1.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.67 | 0.67 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.00 | 0.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.67 | 0.67 |

### Quality by phase: csame-bb45c30-p45

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.3 | 4.3 |
| Strategy | Charge objectives carried out (made contact) | 42% (5 of 12) | 46% (6 of 13) |
| Strategy | Shoot objectives carried out (shot that target) | 41% (7 of 17) | 0% (0 of 3) |
| Strategy | Support requests answered (helper made contact too) | 75% (3 of 4) | 100% (1 of 1) |
| Strategy | Joined characters whose unit fought | 100% (1 of 1) | 0% (0 of 3) |
| Strategy | Lone characters that fought | 88% (7 of 8) | 80% (8 of 10) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 0.3 | 4.0 |
| Movement | Points that never moved of their own | 66.7 | 244.0 |
| Movement | Fights charged into per game | 3.0 | 3.3 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 6 | 1 of 8, net -186 |
| Movement | Charges with odds: sweet spot (55-75%) | 3 of 6, net +248 | 1 of 8, net +405 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 1 of 6, net +85 | 1 of 8, net +0 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 of 6, net +0 | 3 of 8, net -106 |
| Shooting | Shots by shooting units (incl. breath weapons) | 15.0 | 1.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 33% (15 of 45) | 0% (0 of 3) |
| Shooting | Points destroyed by shooting units | 56.7 | 0.0 |
| Shooting | War machine shots | 1.0 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 100% (3 of 3) | - |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | - | 0.7 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | - | 0% (0 of 2) |
| Magic | Wounds caused by magic missiles | 1.0 | - |
| Magic | Wounds caused by other spells | 1.0 | 0.7 |
| Magic | Points destroyed by magic (all spells) | 0.0 | 33.3 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.0 / 0.3 / 0.7 / 0.0 | 1.3 / 0.0 / 0.7 / 0.0 |
| Combat | Points destroyed in combat | 486.3 | 232.0 |
| Combat | Points run down | 229.0 | 27.7 |
| Combat | Net points per charged fight, damage counted | +113 | -72 |
| Combat | Net per 100 charger points, damage counted | +28.3 | -32.3 |
| Combat | First round won (charged fights) | 100% | 70% |
| Combat | Net points per charged fight | +110 | -46 |
| Combat | Net points per supported fight / lone fight | +247 / +71 | -492 / +4 |
| Combat | Charged fights on a top-3 enemy unit | 3 of 9 | 4 of 10 |
| Game | Points lost | 326.3 | 722.0 |
| Game | VP from objectives | 646.7 | 556.7 |
| Game | Lone holders (player turns) | 2.0 | 1.0 |

- Mine won / drew / lost: 2 / 1 / 0 of 3 ended games (of 3); mean margin (Mine - Opponent) +463 VP
- The side that went first won 1 of 2 games with a winner
- Points traded per game (both sides' losses): 1048
- Games not ended: 0; findings 1, warnings 0

### Opponent rules: csame-bb45c30-p45

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | - | - | - | - | 0.7 | +75.9 | 0.0 | 83.7 |
| AFTERMATH WITH FRIENDS | 0.3 | +12.9 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | 26.3 | +162.6 | 0.0 | 374.0 | 23.0 | +363.2 | 0.0 | 38.7 |
| ARRIVAL HUNT | - | - | - | - | 0.3 | +1.1 | 0.0 | 0.0 |
| ASSAILMENT BY POINTS | 0.3 | +4.4 | 0.0 | 0.0 | - | - | - | - |
| BACKUP TARGETS | 0.7 | +4.8 | 0.0 | 0.0 | 0.3 | +1.8 | 0.0 | 0.0 |
| CANNON PLANNED TARGET | 1.0 | +0.0 | 0.0 | 66.7 | - | - | - | - |
| CANNON SIGHT KEPT | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CAST JOB | 1.0 | +12.6 | 195.0 | 0.0 | 1.0 | +36.8 | 0.0 | 130.0 |
| CASTS FROM BEHIND | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | 0.3 | +49.5 | 0.0 | 0.0 | 3.0 | +99.1 | 0.0 | 56.7 |
| CHAFF PASSED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHALLENGE BY POINTS | 1.0 | +95.3 | 0.0 | 0.0 | 0.7 | +11.1 | 0.0 | 16.7 |
| CHAMPION KNOWS CHALLENGE | 0.3 | -52.1 | 83.7 | 0.0 | - | - | - | - |
| CHARGE LOSSES | 10.0 | -549.4 | 0.0 | 290.3 | 17.7 | -905.1 | 0.0 | 711.7 |
| CHARGE NOW FIRST | 2.7 | +0.0 | 335.3 | 0.0 | 2.0 | +0.0 | 190.0 | 38.7 |
| CLOSES ON WHAT IT BEATS | 11.3 | +0.0 | 0.0 | 0.0 | 14.7 | +0.0 | 0.0 | 203.3 |
| COMBAT PIVOT | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| COVER ONCE | 12.0 | -1048.6 | 0.0 | 259.7 | 10.7 | -1002.4 | 0.0 | 77.3 |
| DENIED BY THE FIGHT | - | - | - | - | 0.7 | -0.8 | 84.0 | 0.0 |
| DEPLOY BY FIGURES | 7.3 | -26.0 | 0.0 | 33.3 | 6.3 | +63.8 | 0.0 | 15.0 |
| EDGE GIVE GROUND | 0.3 | +0.5 | 0.0 | 0.0 | - | - | - | - |
| EXACT ROUND | 3.7 | +53.7 | 555.3 | 0.0 | 3.7 | +7.1 | 323.7 | 117.3 |
| FALL BACK GOOD ORDER | 2.7 | +0.0 | 270.3 | 0.0 | 4.0 | +6.0 | 365.7 | 134.0 |
| FALLBACK BY WORTH | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FALLS SHORT | 4.0 | +59.3 | 0.0 | 0.0 | 17.3 | +246.7 | 0.0 | 296.7 |
| FEATURE BUFFS | 2.3 | +54.2 | 0.0 | 42.0 | 2.3 | +140.1 | 0.0 | 0.0 |
| FIGHT TO THE END | 0.7 | -0.3 | 164.7 | 0.0 | 1.0 | +0.6 | 42.0 | 0.0 |
| FIRE IN ORDER | 0.7 | +0.0 | 56.7 | 173.7 | - | - | - | - |
| FIVE ACTION | 86.7 | +7344.4 | 1253.7 | 680.3 | 79.3 | +4915.6 | 365.7 | 1227.0 |
| FLANK NOT WEIGHED | 7.7 | +0.0 | 0.0 | 58.3 | 11.0 | +0.0 | 0.0 | 368.0 |
| FOLLOW UP WEIGHED | 1.3 | +81.5 | 0.0 | 0.0 | 1.0 | +263.9 | 0.0 | 0.0 |
| FOUR ROUNDS | 4.7 | +538.5 | 583.7 | 0.0 | 4.3 | +312.2 | 365.7 | 134.0 |
| FREED FROM HIS FIGHT | 7.7 | +0.0 | 0.0 | 187.0 | 2.7 | +0.0 | 0.0 | 193.0 |
| FRIEND SHOOTS FIRST | 0.3 | -5.6 | 0.0 | 0.0 | 0.3 | -0.3 | 0.0 | 0.0 |
| GIVES UP | 0.3 | -0.4 | 0.0 | 0.0 | 0.3 | -13.4 | 42.0 | 0.0 |
| GOAL WALK | 11.3 | +895.5 | 0.0 | 0.0 | 6.3 | +526.8 | 0.0 | 0.0 |
| HARD STAY DROPPED | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HE REFORMS ONCE FREED | 3.3 | +0.0 | 0.0 | 131.7 | 2.3 | +0.0 | 0.0 | 28.3 |
| HIS CHARGE BY HIS RUN | 7.0 | +0.0 | 0.0 | 158.7 | 15.0 | +0.0 | 0.0 | 711.7 |
| HIS CHARGE LIST | 5.3 | +0.0 | 0.0 | 0.0 | 11.3 | +0.0 | 0.0 | 56.7 |
| HIS LEGAL MOVES | 5.0 | +0.0 | 0.0 | 0.0 | 7.3 | +0.0 | 0.0 | 30.0 |
| HIS MOVE AND SHOT | 2.3 | -48.9 | 0.0 | 0.0 | 4.0 | -65.6 | 0.0 | 56.7 |
| HIS MOVE AS HE DECIDES | - | - | - | - | 41.7 | +10.3 | 345.7 | 0.0 |
| HIS MOVE WHY | 15.0 | +0.0 | 0.0 | 173.7 | - | - | - | - |
| HIS ONE MOVE | - | - | - | - | 21.0 | -227.8 | 0.0 | 125.3 |
| HIS ONE QUARTER | 5.3 | +0.0 | 0.0 | 131.7 | 7.0 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 8.0 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVE | 21.7 | +0.0 | 0.0 | 305.3 | - | - | - | - |
| HIS RANDOM MOVER COMES | 6.3 | +0.0 | 0.0 | 42.0 | - | - | - | - |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 9.3 | +124.9 | 0.0 | 263.3 | 35.7 | +816.9 | 0.0 | 603.7 |
| HIS SHOTS BY HIS RUN | 11.7 | +90.6 | 0.0 | 173.7 | 42.0 | +613.2 | 0.0 | 933.0 |
| HIS TURN DENIED | - | - | - | - | 1.7 | +104.7 | 249.0 | 38.7 |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 11.7 | +0.0 | 0.0 | 84.0 | 14.3 | +0.0 | 0.0 | 56.7 |
| HOLDER ASSIGNMENT | 6.7 | +656.4 | 0.0 | 42.0 | 8.0 | +780.3 | 0.0 | 28.3 |
| HOLDS AMBUSHERS | 0.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 1.7 | -53.2 | 105.7 | 0.0 | 3.3 | -110.6 | 192.0 | 78.7 |
| HUNT RESULT | 0.3 | +70.6 | 0.0 | 0.0 | 0.3 | +131.7 | 131.7 | 38.7 |
| HUNT THE GUNS | 0.3 | +76.1 | 65.0 | 0.0 | 0.3 | +141.2 | 131.7 | 38.7 |
| IDLE COST | 0.7 | -4.4 | 0.0 | 0.0 | 14.3 | -191.3 | 0.0 | 383.0 |
| JOINT CHARGE NOW | 2.0 | +250.4 | 329.3 | 0.0 | 0.7 | +139.2 | 84.0 | 0.0 |
| JOINT ON THE TABLE | 0.3 | +45.7 | 0.0 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 0.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 56.7 |
| LANE BY FIGURES | 1.3 | +91.8 | 0.0 | 0.0 | 1.0 | +8.0 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 17.3 | +0.0 | 387.7 | 375.0 | 2.0 | +0.0 | 86.0 | 186.0 |
| LONE WIZARD KEPT IN | 0.3 | +5.0 | 0.0 | 0.0 | - | - | - | - |
| LONG SHOT | 0.3 | +3.5 | 0.0 | 0.0 | - | - | - | - |
| LOST AFTER ESCAPE | 2.0 | -0.5 | 357.7 | 0.0 | 0.7 | +4.3 | 131.7 | 100.7 |
| MAKE SURE TOGETHER | 0.7 | +3.9 | 0.0 | 131.7 | - | - | - | - |
| MANOEUVRE | 2.0 | -0.4 | 0.0 | 0.0 | 1.0 | +1.8 | 0.0 | 28.3 |
| MARCH AT ESCAPER | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| MARCH CHECK | 0.7 | +29.2 | 0.0 | 0.0 | - | - | - | - |
| MARCH OF THE TABLE | - | - | - | - | 0.3 | +0.2 | 0.0 | 0.0 |
| MARCH OVER CASTS | - | - | - | - | 0.3 | +0.5 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 4.0 | +74.1 | 0.0 | 131.7 | 4.0 | +104.3 | 0.0 | 15.0 |
| MEETS IN TIME | 3.7 | +211.0 | 0.0 | 0.0 | 3.3 | +109.0 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 2.7 | +44.6 | 0.0 | 131.7 | 2.7 | +49.1 | 0.0 | 65.0 |
| MISSILES NEXT TURN | 3.0 | +42.3 | 0.0 | 131.7 | 3.3 | +42.5 | 0.0 | 65.0 |
| MOVE ORDER | 1.3 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 105.7 |
| MOVE TO CHARGE COMPUTED | 13.0 | +1179.0 | 0.0 | 0.0 | 7.3 | +360.5 | 0.0 | 68.7 |
| MOVES UNITS SPELL | 0.3 | +2.4 | 0.0 | 0.0 | - | - | - | - |
| NEARER NOT NEEDED | 8.0 | +330.2 | 0.0 | 42.0 | 4.7 | +209.4 | 0.0 | 28.3 |
| NEXT CHARGE BY LIST | 9.7 | +855.6 | 0.0 | 0.0 | 4.0 | +210.4 | 0.0 | 0.0 |
| NEXT OBJECTIVE NEARER | 0.3 | -7.6 | 0.0 | 0.0 | - | - | - | - |
| NO DOUBLE ROUNDS | 4.0 | -330.6 | 518.7 | 0.0 | 3.7 | -239.0 | 365.7 | 100.7 |
| NO LATE CUT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 0.3 | -0.2 | 0.0 | 0.0 | 1.0 | -0.2 | 0.0 | 0.0 |
| OFF BEST | 4.7 | -87.3 | 0.0 | 75.3 | 6.3 | -351.0 | 0.0 | 67.0 |
| ONE CHECK AFTER THE LAST CHANGE | 0.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 8.0 | -204.6 | 0.0 | 131.7 | 6.0 | -137.5 | 0.0 | 179.7 |
| ONE JOINT FIGURE | 1.3 | +403.8 | 164.7 | 0.0 | - | - | - | - |
| ONE OBJECTIVE FORMULA | 3.0 | +42.3 | 0.0 | 42.0 | 3.7 | +18.6 | 0.0 | 0.0 |
| ONE PROMISE A TARGET | 0.3 | +4.5 | 0.0 | 0.0 | - | - | - | - |
| OPENS A LANE | 0.3 | +0.5 | 56.7 | 0.0 | - | - | - | - |
| OPENS UP | 0.7 | +48.3 | 77.3 | 0.0 | 0.3 | +17.3 | 33.3 | 0.0 |
| OVERRUNS AWAY | 1.0 | +3.8 | 242.0 | 0.0 | 1.0 | +122.7 | 75.3 | 0.0 |
| PATHS CROSS | 0.3 | +81.9 | 0.0 | 0.0 | 0.7 | -0.4 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | - | - | - | - | 0.3 | -54.5 | 0.0 | 0.0 |
| PLAN RESULT | 39.7 | +853.9 | 845.0 | 586.0 | 41.7 | +453.4 | 405.7 | 1057.0 |
| PROMISE BELOW ZERO | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE BY ITS OWN SUM | 14.0 | -446.7 | 0.0 | 0.0 | 8.3 | -130.9 | 0.0 | 68.7 |
| PROMISE KNOWS THE FIGHT | 2.0 | -4.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | 0.3 | -6.2 | 0.0 | 0.0 | 0.3 | -26.2 | 0.0 | 0.0 |
| QUARTER ODDS | 26.3 | +3141.5 | 410.7 | 263.3 | 21.0 | +2770.0 | 0.0 | 179.0 |
| RANDOM MOVE BY FIGURES | - | - | - | - | 5.0 | +175.6 | 0.0 | 56.7 |
| REDIRECT BY WHAT IT STOPS | 0.7 | -12.7 | 0.0 | 0.0 | 2.0 | +18.6 | 0.0 | 56.7 |
| REDIRECT COUNTER | 2.7 | +98.1 | 0.0 | 0.0 | 2.7 | +230.3 | 0.0 | 43.3 |
| REDIRECT FOR A FRIEND IN REACH | 3.3 | +24.2 | 0.0 | 0.0 | 0.7 | +44.0 | 0.0 | 0.0 |
| REFORMS TO MEET IT | 5.0 | -278.2 | 0.0 | 0.0 | 0.7 | -1.6 | 0.0 | 0.0 |
| REFUSING RETIRES | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 83.7 |
| RESERVE FALL BACK | 1.0 | +11.6 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | 4.3 | +52.3 | 583.7 | 0.0 | 3.7 | +387.1 | 249.0 | 134.0 |
| ROUNDS AFTER TERROR | 0.7 | -8.9 | 77.3 | 0.0 | 0.3 | -0.6 | 0.0 | 16.7 |
| RUN DOWN | 2.7 | -46.2 | 354.0 | 0.0 | 2.0 | -8.4 | 249.0 | 100.7 |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 0.7 | -65.9 | 0.0 | 0.0 |
| SEARCH SPOT | 0.3 | +1.0 | 0.0 | 0.0 | 0.3 | +2.3 | 0.0 | 0.0 |
| SECOND LOOK | 0.3 | +50.5 | 38.7 | 0.0 | - | - | - | - |
| SELF MOVE SPELL | 2.0 | +74.6 | 0.0 | 263.3 | - | - | - | - |
| SET UP BY THE SET | 2.3 | +37.1 | 38.7 | 0.0 | 1.7 | -16.4 | 0.0 | 0.0 |
| SET UP TOGETHER | 0.7 | +3.9 | 0.0 | 131.7 | - | - | - | - |
| SHOOTERS IN TWO RANKS | 1.0 | +2.0 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS ON THE TABLE | 3.7 | +0.0 | 0.0 | 66.7 | 2.3 | +0.0 | 0.0 | 65.0 |
| SHOOTS FROM THE BEST SPOT | 2.0 | +13.9 | 0.0 | 0.0 | 1.3 | +4.0 | 0.0 | 0.0 |
| SHOT OR CHARGE | 0.7 | -50.5 | 148.7 | 0.0 | - | - | - | - |
| SHOT RISK POINTS | 6.7 | -59.4 | 0.0 | 131.7 | 21.7 | -121.7 | 0.0 | 711.7 |
| SHOTS AFTER THE MOVES | 2.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SHOTS IN THE MOVE | 12.7 | +288.8 | 0.0 | 240.3 | 0.3 | +4.0 | 0.0 | 28.3 |
| SPELL WORTH | 1.0 | +12.8 | 0.0 | 0.0 | 2.7 | +5.7 | 0.0 | 0.0 |
| SPELLS IN THE FIGHT | 0.3 | +9.7 | 0.0 | 0.0 | 1.0 | -38.4 | 131.7 | 55.3 |
| SPOT AS THE GAME MOVES | 6.0 | +0.0 | 0.0 | 42.0 | 8.3 | +0.0 | 0.0 | 0.0 |
| STAND AND SHOOT | - | - | - | - | 1.0 | -8.9 | 173.7 | 38.7 |
| STANDS STILL | 26.3 | +0.0 | 670.0 | 261.3 | 14.7 | +0.0 | 0.0 | 213.7 |
| STAY WORTH | 10.7 | +51.3 | 421.7 | 100.0 | 0.3 | +1.8 | 0.0 | 28.3 |
| STOPS | 0.3 | +5.2 | 65.0 | 0.0 | 0.3 | +0.3 | 131.7 | 38.7 |
| STRIKE BY THE ODDS | 1.0 | +51.2 | 83.7 | 42.0 | - | - | - | - |
| STUBBORN BY POINTS | 0.7 | +19.3 | 16.7 | 0.0 | - | - | - | - |
| STUCK PIVOT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| STUPIDITY NEXT TURN | 1.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 7.7 | +340.6 | 0.0 | 55.3 | 5.3 | +352.3 | 0.0 | 67.0 |
| SUPPORT NARROWED | 1.0 | +0.0 | 93.3 | 0.0 | 0.7 | +0.0 | 33.3 | 16.7 |
| SUPPORT WORKED OUT | 7.7 | +340.6 | 0.0 | 55.3 | 5.3 | +352.3 | 0.0 | 67.0 |
| SURE REACH TOGETHER | 2.3 | +20.0 | 0.0 | 0.0 | 0.7 | +2.2 | 0.0 | 65.0 |
| THE DEARER SUM KEEPS ITS PLAN | 1.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| THE PROMISE ADDS | 0.3 | -6.2 | 0.0 | 0.0 | 1.0 | -29.6 | 0.0 | 0.0 |
| THE PROMISED MOVE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE ROW IN ITS ORDER | 3.7 | +0.0 | 0.0 | 42.0 | 6.3 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 3.0 | +0.0 | 0.0 | 58.3 | 3.7 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 2.0 | +0.0 | 0.0 | 58.3 | 1.3 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 39.7 | +0.0 | 0.0 | 326.3 | 37.3 | +0.0 | 0.0 | 515.0 |
| TIED UP BY THE SUM | 1.3 | +159.1 | 105.7 | 0.0 | 1.7 | +257.5 | 192.0 | 0.0 |
| TIME ON OUR SIDE | 33.3 | +452.0 | 0.0 | 214.0 | - | - | - | - |
| WAITS AGAIN | 2.3 | +0.0 | 0.0 | 131.7 | 2.7 | +0.0 | 0.0 | 30.0 |
| WEAPON BY POINTS | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 28.3 |
| WHAT THE JOINER ADDS | - | - | - | - | 0.7 | +11.6 | 0.0 | 33.3 |
| WHO FIGHTS | 1.7 | -26.0 | 83.7 | 0.0 | 1.0 | +25.8 | 42.0 | 0.0 |
| WHO GETS IN | 0.3 | +45.7 | 0.0 | 0.0 | 0.7 | +139.2 | 84.0 | 0.0 |
| WHO HITS BACK | 0.3 | +104.8 | 0.0 | 0.0 | 1.0 | +228.8 | 0.0 | 83.7 |
| WHOLE FIGHT | - | - | - | - | 0.3 | +0.0 | 0.0 | 16.7 |
| WHOLE FIGHT DANGER | 7.0 | -480.6 | 0.0 | 158.7 | 2.7 | -438.2 | 0.0 | 56.7 |
| WHOLE FIGHT GAIN | 0.7 | +131.8 | 164.7 | 0.0 | - | - | - | - |
| WOUNDS ON THE RANKS | 1.3 | +6.8 | 0.0 | 0.0 | 3.0 | +259.4 | 0.0 | 83.7 |

### Rule changes: csame-bb45c30-p45

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 148 | 148 | 96 | 32.00 | +2329 | +24.3 |
| HIS MOVE AS HE DECIDES | 125 | 125 | 94 | 31.33 | +0 | +0.0 |
| LEGAL CHARGES ONLY | 58 | 58 | 58 | 19.33 | +0 | +0.0 |
| HOLDER ASSIGNMENT | 44 | 44 | 41 | 13.67 | +2648 | +64.6 |
| HIS SHOT LIST | 135 | 127 | 35 | 11.67 | +411 | +11.8 |
| FIVE ACTION | 498 | 472 | 34 | 11.33 | +2564 | +75.4 |
| OFF BEST | 33 | 33 | 33 | 11.00 | -1315 | -39.8 |
| THE TABLE AGAIN | 36 | 36 | 33 | 11.00 | +0 | +0.0 |
| HIS SHOTS BY HIS RUN | 161 | 151 | 29 | 9.67 | +93 | +3.2 |
| HIS MOVE WHY | 45 | 45 | 27 | 9.00 | +0 | +0.0 |
| PROMISE BY ITS OWN SUM | 67 | 67 | 26 | 8.67 | -1733 | -66.7 |
| DEPLOY BY FIGURES | 41 | 41 | 25 | 8.33 | +230 | +9.2 |
| MOVE TO CHARGE COMPUTED | 61 | 49 | 25 | 8.33 | +1069 | +42.8 |
| QUARTER ODDS | 142 | 133 | 20 | 6.67 | +1427 | +71.3 |
| HIS ONE MOVE | 63 | 57 | 18 | 6.00 | +0 | +0.0 |
| FOUR ROUNDS | 27 | 27 | 15 | 5.00 | +871 | +58.1 |
| SUPPORT ADDS | 39 | 36 | 15 | 5.00 | +475 | +31.6 |
| SUPPORT WORKED OUT | 39 | 36 | 15 | 5.00 | +475 | +31.6 |
| NEXT CHARGE BY LIST | 41 | 36 | 13 | 4.33 | +984 | +75.7 |
| REDIRECT FOR A FRIEND IN REACH | 12 | 12 | 12 | 4.00 | +112 | +9.4 |
| GOAL WALK | 53 | 52 | 11 | 3.67 | +664 | +60.4 |
| MOVE ORDER | 11 | 11 | 11 | 3.67 | +0 | +0.0 |
| RANDOM MOVE BY FIGURES | 15 | 15 | 9 | 3.00 | +527 | +58.5 |
| SHOT RISK POINTS | 85 | 78 | 9 | 3.00 | +99 | +11.0 |
| JOINT CHARGE NOW | 8 | 8 | 8 | 2.67 | +1169 | +146.1 |
| MEETS IN TIME | 21 | 21 | 8 | 2.67 | +429 | +53.6 |
| TIED UP BY THE SUM | 9 | 9 | 8 | 2.67 | +304 | +38.0 |
| ADVANCE LANE KEPT | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| CHAFF IN THE MOVE | 10 | 10 | 7 | 2.33 | +55 | +7.9 |
| FOLLOW UP WEIGHED | 7 | 7 | 7 | 2.33 | +1036 | +148.0 |
| LANE BY FIGURES | 7 | 7 | 7 | 2.33 | +300 | +42.8 |
| SHOOTS FROM THE BEST SPOT | 10 | 10 | 7 | 2.33 | +1 | +0.1 |
| HOLDS AMBUSHERS | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| RISK BY ARC | 24 | 24 | 6 | 2.00 | +279 | +46.5 |
| THE ROW IN ITS ORDER | 30 | 6 | 6 | 2.00 | +0 | +0.0 |
| WHOLE FIGHT DANGER | 29 | 29 | 6 | 2.00 | +621 | +103.5 |
| CHALLENGE BY POINTS | 5 | 5 | 5 | 1.67 | +319 | +63.8 |
| CHARGE LOSSES | 83 | 77 | 5 | 1.67 | +540 | +108.0 |
| COVER ONCE | 68 | 42 | 5 | 1.67 | +114 | +22.9 |
| TIME ON OUR SIDE | 100 | 79 | 5 | 1.67 | +0 | +0.0 |
| CAST JOB | 6 | 6 | 4 | 1.33 | +22 | +5.6 |
| HARD STAY DROPPED | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| IDLE COST | 45 | 36 | 4 | 1.33 | +28 | +6.9 |
| NEARER NOT NEEDED | 38 | 37 | 4 | 1.33 | +152 | +38.0 |
| ONE JOINT FIGURE | 4 | 4 | 4 | 1.33 | +477 | +119.2 |
| SET UP BY THE SET | 12 | 12 | 4 | 1.33 | +286 | +71.4 |
| SURE REACH TOGETHER | 9 | 9 | 4 | 1.33 | +0 | +0.0 |
| WHO HITS BACK | 4 | 4 | 4 | 1.33 | +658 | +164.4 |
| CANNON SIGHT KEPT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| CHARGE NOW FIRST | 14 | 14 | 3 | 1.00 | -250 | -83.2 |
| COMBAT PIVOT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| MAX FOR POSITIONING | 24 | 17 | 3 | 1.00 | +18 | +6.1 |
| PATHS CROSS | 3 | 3 | 3 | 1.00 | +244 | +81.5 |
| REDIRECT COUNTER | 16 | 12 | 3 | 1.00 | +286 | +95.3 |
| RESERVE FALL BACK | 3 | 3 | 3 | 1.00 | +35 | +11.6 |
| SHOOTERS IN TWO RANKS | 3 | 3 | 3 | 1.00 | +6 | +2.0 |
| STRIKE BY THE ODDS | 3 | 3 | 3 | 1.00 | +140 | +46.7 |
| WEAPON BY POINTS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| WHO GETS IN | 3 | 3 | 3 | 1.00 | +555 | +185.0 |
| AFTERMATH IN POINTS | 2 | 2 | 2 | 0.67 | +228 | +113.8 |
| CASTS FROM BEHIND | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| FEATURE BUFFS | 14 | 14 | 2 | 0.67 | +135 | +67.3 |
| FIRE IN ORDER | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| MANOEUVRE | 9 | 9 | 2 | 0.67 | +34 | +16.8 |
| MARCH CHECK | 2 | 2 | 2 | 0.67 | +45 | +22.6 |
| MISSILES IN THE MOVE | 16 | 8 | 2 | 0.67 | +3 | +1.4 |
| MISSILES NEXT TURN | 19 | 13 | 2 | 0.67 | +3 | +1.6 |
| NO DOUBLE ROUNDS | 23 | 23 | 2 | 0.67 | +32 | +15.9 |
| OPENS UP | 3 | 3 | 2 | 0.67 | +30 | +14.8 |
| PROMISE KNOWS THE FIGHT | 8 | 7 | 2 | 0.67 | -12 | -6.0 |
| SEARCH SPOT | 2 | 2 | 2 | 0.67 | +10 | +5.0 |
| STUBBORN BY POINTS | 2 | 2 | 2 | 0.67 | +58 | +29.0 |
| WHO FIGHTS | 8 | 8 | 2 | 0.67 | +16 | +7.8 |
| AFTERMATH WITH FRIENDS | 1 | 1 | 1 | 0.33 | +39 | +38.7 |
| ASSAILMENT BY POINTS | 1 | 1 | 1 | 0.33 | +13 | +13.3 |
| BACKUP TARGETS | 3 | 3 | 1 | 0.33 | +1 | +1.0 |
| CHAFF PASSED | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| EXACT ROUND | 22 | 22 | 1 | 0.33 | +0 | +0.0 |
| FALL BACK GOOD ORDER | 20 | 20 | 1 | 0.33 | +5 | +4.7 |
| FALLS SHORT | 64 | 52 | 1 | 0.33 | +0 | +0.0 |
| FIGHT TO THE END | 5 | 5 | 1 | 0.33 | +0 | +0.0 |
| HIS MOVE AND SHOT | 19 | 18 | 1 | 0.33 | +44 | +44.1 |
| HIS TURN DENIED | 5 | 5 | 1 | 0.33 | +37 | +36.9 |
| JOINT ON THE TABLE | 1 | 1 | 1 | 0.33 | +137 | +137.2 |
| LONE WIZARD KEPT IN | 1 | 1 | 1 | 0.33 | +15 | +15.0 |
| MARCH OF THE TABLE | 1 | 1 | 1 | 0.33 | -1 | -0.7 |
| MOVES UNITS SPELL | 1 | 1 | 1 | 0.33 | +7 | +7.3 |
| ONE PROMISE A TARGET | 1 | 1 | 1 | 0.33 | +13 | +13.4 |
| OVERRUNS AWAY | 6 | 6 | 1 | 0.33 | +141 | +140.6 |
| PIVOT GUARDS FLANK | 1 | 1 | 1 | 0.33 | -163 | -163.4 |
| REDIRECT BY WHAT IT STOPS | 8 | 8 | 1 | 0.33 | +35 | +35.4 |
| REFUSING RETIRES | 4 | 4 | 1 | 0.33 | +259 | +259.1 |
| SECOND LOOK | 1 | 1 | 1 | 0.33 | +152 | +151.6 |
| SHOTS AFTER THE MOVES | 8 | 8 | 1 | 0.33 | +0 | +0.0 |
| SHOTS IN THE MOVE | 39 | 23 | 1 | 0.33 | +88 | +87.7 |
| STUCK PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| SUPPORT NARROWED | 5 | 5 | 1 | 0.33 | -24 | -23.6 |
| WHOLE FIGHT GAIN | 2 | 2 | 1 | 0.33 | +88 | +88.2 |
| WOUNDS ON THE RANKS | 13 | 13 | 1 | 0.33 | +254 | +254.4 |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| CANNON PLANNED TARGET | 3 | 3 | 0 | 0.00 | - | - |
| CHAMPION KNOWS CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 78 | 73 | 0 | 0.00 | - | - |
| DENIED BY THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| EDGE GIVE GROUND | 1 | 1 | 0 | 0.00 | - | - |
| FALLBACK BY WORTH | 1 | 1 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 56 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 31 | 28 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 2 | 2 | 0 | 0.00 | - | - |
| GIVES UP | 2 | 2 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 17 | 15 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 66 | 60 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 50 | 44 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 37 | 34 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 37 | 32 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 33 | 32 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 65 | 61 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 19 | 18 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN RUN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 78 | 78 | 0 | 0.00 | - | - |
| HONEST WORTH | 15 | 15 | 0 | 0.00 | - | - |
| HUNT RESULT | 2 | trace | - | - | - | - |
| HUNT THE GUNS | 2 | trace | - | - | - | - |
| KEPT FROM ITS LAST STOP | 6 | 6 | 0 | 0.00 | - | - |
| LONG SHOT | 1 | 1 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 8 | 8 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 2 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 1 | 1 | 0 | 0.00 | - | - |
| NEXT OBJECTIVE NEARER | 1 | 1 | 0 | 0.00 | - | - |
| NO LATE CUT | 1 | 1 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 18 | 18 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT TURNED | 2 | 2 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 4 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 4 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 42 | 18 | 0 | 0.00 | - | - |
| ONE OBJECTIVE FORMULA | 20 | 14 | 0 | 0.00 | - | - |
| OPENS A LANE | 1 | not checked | - | - | - | - |
| PLAN RESULT | 244 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 3 | 3 | 0 | 0.00 | - | - |
| PROMISE READS THE TABLE | 2 | 2 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 17 | 14 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 3 | 3 | 0 | 0.00 | - | - |
| RUN DOWN | 14 | 14 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 2 | 2 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 6 | not checked | - | - | - | - |
| SET UP TOGETHER | 2 | 1 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 18 | not checked | - | - | - | - |
| SHOT OR CHARGE | 2 | 2 | 0 | 0.00 | - | - |
| SPELL WORTH | 11 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 4 | 4 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 43 | 40 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 3 | 3 | 0 | 0.00 | - | - |
| STANDS STILL | 123 | 119 | 0 | 0.00 | - | - |
| STAY WORTH | 33 | 26 | 0 | 0.00 | - | - |
| STOPS | 2 | 2 | 0 | 0.00 | - | - |
| STUPIDITY NEXT TURN | 7 | 7 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 7 | not checked | - | - | - | - |
| THE PROMISE ADDS | 4 | 3 | 0 | 0.00 | - | - |
| THE PROMISED MOVE | 1 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 20 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 10 | not checked | - | - | - | - |
| THE TABLE BINDS | 231 | not checked | - | - | - | - |
| WAITS AGAIN | 15 | 11 | 0 | 0.00 | - | - |
| WHAT THE JOINER ADDS | 2 | 2 | 0 | 0.00 | - | - |
| WHOLE FIGHT | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: csame-bb45c30-p45

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 4.00 | 5.00 | 35.3 |
| PROMISE BY ITS OWN SUM | rule | 5.33 | 3.33 | 66.7 |
| ARMY TABLE | rule | 5.67 | 2.67 | 52.7 |
| RULE SWITCHED OFF | gate | 0.67 | 1.33 | 60.3 |
| CHARGE NOW FIRST | rule | 0.67 | 0.33 | 83.2 |
| HOLDER ASSIGNMENT | rule | 0.33 | 0.33 | 25.1 |
| PROMISE KNOWS THE FIGHT | rule | 0.67 | - | 6.0 |
| JOINT CHARGE NOW | rule | 0.33 | - | 171.4 |
| MARCH OF THE TABLE | rule | - | 0.33 | 0.7 |
| PATHS CROSS | rule | - | 0.33 | 18.3 |
| PIVOT GUARDS FLANK | rule | - | 0.33 | 163.4 |
| SUPPORT NARROWED | rule | 0.33 | - | 23.6 |

### Plans: csame-bb45c30-p45

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 4.3 | 54% | 646 | 693 | 107% |
| Mine | move | 30.3 | 97% | 2082 | 0 | 0% |
| Mine | shoot | 4.7 | 29% | 518 | 161 | 31% |
| Mine | support | 0.3 | 100% | 12 | 0 | 0% |
| Opponent | charge | 3.7 | 55% | 525 | 453 | 86% |
| Opponent | join | 3.0 | 78% | 76 | 0 | 0% |
| Opponent | move | 33.0 | 95% | 1641 | 0 | 0% |
| Opponent | shoot | 0.7 | 0% | 77 | 0 | 0% |
| Opponent | support | 1.3 | 75% | 48 | 0 | 0% |

### Packages: hunt the guns, csame-bb45c30-p45

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.3 | 1 | 0 | 100% | 100% | 0% | 2.0 | 228 | 212 | 100% | 0 |
| Opponent | 0.3 | 1 | 0 | 100% | 100% | 0% | 2.0 | 424 | 395 | 100% | 0 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| High Elf Realms | 1.0 | 1 | 0 | 100% | 100% | 0% | 2.0 | 228 | 212 | 100% | 0 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Vampire Counts | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Warriors of Chaos | 0.5 | 1 | 0 | 100% | 100% | 0% | 2.0 | 424 | 395 | 100% | 0 |

### Battle groups: csame-bb45c30-p45

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 2.7 | 12% | 100% | 0% | - | 0% | 0% | 0% | 100% | 0% |
| Opponent | REDIRECT COUNTER | 2.7 | 25% | 50% | 0% | - | 0% | 0% | 100% | 0% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: csame-bb45c30-p45

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 3 | 24 (3) | 24 | 0 | 0 | 0% | 6.0 | 24 (3) | - | - | 24 (3) | - |
| Mine | Chaff | 2 | 75 (2) | 0 | 75 | 0 | 0% | 1.5 | 150 (1) | 0 (1) | - | 150 (1) | 0 (1) |
| Mine | Character | 8 | 42 (8) | 42 | 0 | 14 | 12% | 3.0 | 51 (4) | 30 (3) | 31 (1) | 50 (5) | 19 (3) |
| Mine | Clean-up | 1 | 56 (1) | 0 | 56 | 0 | 0% | 3.0 | 56 (1) | - | - | 56 (1) | - |
| Mine | Fast | 1 | 325 (1) | 325 | 0 | 0 | 0% | 3.0 | 325 (1) | - | - | 325 (1) | - |
| Mine | Fast Hammer | 4 | 80 (4) | 80 | 0 | 0 | 0% | 2.8 | 100 (3) | 0 (1) | - | 91 (3) | 0 (1) |
| Mine | Hammer | 3 | 13 (3) | 0 | 13 | 26 | 0% | 3.0 | 0 (1) | 18 (2) | - | 0 (1) | 18 (2) |
| Mine | Shooter | 6 | 36 (6) | 27 | 9 | 31 | 0% | 2.0 | 46 (3) | 21 (3) | - | 22 (3) | 50 (3) |
| Mine | Support | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Mine | War machine | 2 | 0 (2) | 0 | 0 | 100 | 0% | 1.0 | 0 (2) | - | - | 0 (1) | 0 (1) |
| Mine | Wizard | 1 | 0 (1) | 0 | 0 | 0 | 0% | 1.0 | - | 0 (1) | - | - | 0 (1) |
| Opponent | Chaff | 5 | 0 (5) | 0 | 0 | 17 | 80% | 1.0 | 0 (2) | 0 (3) | - | 0 (1) | 0 (4) |
| Opponent | Character | 10 | 35 (10) | 35 | 0 | 60 | 20% | 3.1 | 90 (4) | 0 (4) | 13 (2) | 53 (7) | 10 (3) |
| Opponent | Clean-up | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Fast Hammer | 6 | 6 (6) | 6 | 0 | 32 | 67% | 2.5 | 0 (3) | 14 (3) | - | 11 (4) | 0 (2) |
| Opponent | Hammer | 5 | 38 (5) | 0 | 38 | 18 | 40% | 4.3 | 59 (3) | 0 (2) | - | 46 (4) | 0 (1) |
| Opponent | Holder | 4 | 12 (4) | 0 | 12 | 17 | 50% | 3.5 | 0 (2) | 29 (2) | - | 0 (2) | 29 (2) |
| Opponent | Support | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Wizard | 3 | 0 (3) | 0 | 0 | 44 | 0% | 4.0 | 0 (1) | 0 (1) | 0 (1) | 0 (1) | 0 (2) |

### Charged fights: csame-bb45c30-p45

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | High Elf Realms | 1 | 170 | 367 | 4.0 | 1.5 | 92 | 0 | +92 | 2 of 4 | 4 of 4 | +0 | +122 |
| Mine | Kingdom of Bretonnia | 1 | 0 | 579 | 3.0 | 1.3 | 193 | 0 | +193 | 1 of 3 | 3 of 3 | +494 | +42 |
| Mine | Lizardmen | 1 | 0 | 45 | 2.0 | 1.0 | 22 | 0 | +22 | 0 of 2 | 2 of 2 | - | +22 |
| **Mine** | all armies | 3 | 57 | 330 | 3.0 | 1.3 | 110 | 0 | +110 | 3 of 9 | 9 of 9 | +247 | +71 |
| Opponent | Vampire Counts | 1 | 0 | 175 | 5.0 | 1.0 | 35 | 47 | -12 | 2 of 5 | 3 of 5 | - | -12 |
| Opponent | Warriors of Chaos | 2 | 50 | 260 | 2.5 | 1.2 | 104 | 184 | -80 | 2 of 5 | 4 of 5 | -492 | +24 |
| **Opponent** | all armies | 3 | 33 | 232 | 3.3 | 1.1 | 70 | 116 | -46 | 4 of 10 | 7 of 10 | -492 | +4 |

### Effective charges: csame-bb45c30-p45

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | High Elf Realms | 4 | 0 | 0 | 1 (net +251) | 0 | 0 | 1 (net +0) | 2 | 50% (1 of 2) |
| Mine | Kingdom of Bretonnia | 3 | 0 | 0 | 1 (net +494) | 0 | 1 (net +85) | 1 (net +0) | 0 | 33% (1 of 3) |
| Mine | Lizardmen | 2 | 0 | 0 | 1 (net +0) | 0 | 0 | 0 | 1 | 100% (1 of 1) |
| Opponent | Vampire Counts | 5 | 1 (net -186) | 0 | 0 | 2 (net +0) | 0 | 1 (net +175) | 1 | 0% (0 of 4) |
| Opponent | Warriors of Chaos | 5 | 0 | 0 | 1 (net +405) | 0 | 1 (net +0) | 2 (net -246) | 1 | 25% (1 of 4) |

### Charged fights, damage counted: csame-bb45c30-p45

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Effective (55-75%) | 3 | 401 | 294 | +248 | 248 | 0 | +248 | +62.0 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 483 | 186 | +0 | 57 | 22 | +35 | +7.2 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 277 | 85 | +85 | 85 | 0 | +85 | +30.7 |
| Mine | No odds | 3 | 378 | 92 | +54 | 54 | 16 | +38 | +10.0 |
| Mine | All fights | 9 | 398 | 179 | +110 | 123 | 10 | +113 | +28.3 |
| Opponent | Long shot (under 50%) | 1 | 186 | 399 | -186 | 0 | 186 | -186 | -100.0 |
| Opponent | Effective (55-75%) | 1 | 116 | 395 | +405 | 521 | 116 | +405 | +349.1 |
| Opponent | 76-89% | 2 | 118 | 180 | +0 | 0 | 0 | +0 | +0.0 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 | 384 | 192 | -106 | 58 | 188 | -130 | -33.8 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 365 | 100 | +0 | 0 | 0 | +0 | +0.0 |
| Opponent | No odds | 2 | 85 | 316 | -180 | 3 | 277 | -274 | -322.6 |
| Opponent | All fights | 10 | 223 | 246 | -46 | 70 | 142 | -72 | -32.3 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| csame-bb45c30-p45 | move | 34 | 3 (9%) | 2 (6%) | 6 (18%) | 25 (74%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L1727 |
| Invocation of Nehek | Opponent | L1727 |
| Ring of Doom | Mine | L1531 |
| Ring of Doom | Opponent | L1531 |

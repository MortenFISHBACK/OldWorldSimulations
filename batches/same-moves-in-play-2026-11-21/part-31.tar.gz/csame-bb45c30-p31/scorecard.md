# Doctrine scorecard: csame-bb45c30-p31

### Scorecard: csame-bb45c30-p31

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L1114 | 4 | 1 | Mine | no | 0 | 2 | 1 | 0 | 0 | 0 | 0 | 165 |
| L1114 | 4 | 1 | Opponent | no | 3 | 6 | 1 | 2 | 0 | 0 | 0 | 0 |
| L1131 | 3 | 1 | Mine | no | 0 | - | 1 | 0 | 0 | 0 | 0 | 262 |
| L1131 | 3 | 1 | Opponent | yes | 1 | 3 | 2 | 2 | 0 | 0 | 0 | 340 |
| L1224 | 6 | 1 | Mine | no | 9 | 1 | 5 | 0 | 0 | 0 | 0 | 330 |
| L1224 | 6 | 1 | Opponent | no | 11 | 3 | 1 | 2 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 0% | 3.0 | 1.5 | 2.3 | 0.0 | 0.0 | 0.0 | 0.0 | 252.3 |
| **Average** | | | Opponent | 33% | 5.0 | 4.0 | 1.3 | 2.0 | 0.0 | 0.0 | 0.0 | 113.3 |

### KPIs: csame-bb45c30-p31

Rules off - Opponent only: NO OLD ONE-MOVE GUESS; both sides: ONE RUN A PLAN.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 53% (9 of 17) | 0% (0 of 16) | 27% (9 of 33) |
| Winner chose to follow up after the loser gave ground |  | 0% (0 of 1); on the table 0% | 100% (4 of 4); on the table 100% | 80% (4 of 5); on the table 80% |
| Winner chose to pursue after the loser fell back in good order |  | 0% (0 of 1); on the table 0% | 50% (2 of 4); on the table 50% | 40% (2 of 5); on the table 40% |
| Winner chose to pursue after the loser fled |  | - | 50% (1 of 2); on the table 50% | 50% (1 of 2); on the table 50% |
| Winner chose to follow up or pursue (all three) |  | 0% (0 of 2); on the table 0% | 70% (7 of 10); on the table 70% | 58% (7 of 12); on the table 58% |
| Magic missiles tried each own turn | 50%+ | 30% (20 of 66) | 39% (7 of 18) | 32% (27 of 84) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 36% (20 of 56) | 39% (7 of 18) | 36% (27 of 74) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 50% (6 of 12) | 50% (6 of 12) |
| Points that never fought | lower | 65% (3887 of 5998) | 62% (3725 of 5998) | 63% (7612 of 11996) |
|   infantry points that never fought | lower | 100% (730 of 730) | 100% (913 of 913) | 100% (1643 of 1643) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 64% (16 of 25) | 68% (19 of 28) | 66% (35 of 53) |
| Bound items with a magic missile used (at least once a game) |  | 100% (7 of 7); 7.7 uses a game | 100% (1 of 1); 0.3 uses a game | 100% (8 of 8); 4.0 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 33% (2 of 6); 0.7 uses a game | 33% (2 of 6); 0.3 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 33% (1 of 3); 0.3 uses a game | 0.0 uses a game | 33% (1 of 3); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 68% (3793 of 5614) | 72% (4210 of 5828) | 70% (8003 of 11442) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 3.3 (22%) | 1.7 (45%) | 5.0 (26%) |
| MARCHED: its unit marched | 6.0 (39%) | 2.0 (55%) | 8.0 (42%) |
| CHARGED: its unit charged | 2.7 (17%) | 0.0 (0%) | 2.7 (14%) |
| IN COMBAT: engaged in combat | 3.0 (20%) | 0.0 (0%) | 3.0 (16%) |
| GONE: slain | 0.3 (2%) | 0.0 (0%) | 0.3 (2%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 2.3 | 6.3 | 3.0 | 9.0 | 2.3 | 0.7 |
| not cast | 1.7 | 5.7 | 1.0 | 19.0 | 5.7 | 35.3 |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 5.0 (88%) | 0.0 (0%) | 5.0 (26%) | 0.3 (6%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 8.0 (42%) | 1.0 (18%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.7 (14%) | 0.7 (12%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 3.0 (16%) | 0.3 (6%) | 0.0 (0%) |
| NO CASTS LEFT: every cast used on other spells | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (12%) | 0.0 (0%) |
| GONE: slain | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (2%) | 0.3 (6%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.7 (12%) | 0.0 (0%) | 0.0 (0%) | 2.3 (41%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.7 (100%) | 0.0 (0%) | 1.0 (100%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 35.3 (100%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.0 a game | 3.0 a game | 1.5 a game |
| stood (cast and not dispelled) | - | 78% (7 of 9) | 78% (7 of 9) |
| the unit moved after it | - | 43% (3 of 7) | 43% (3 of 7) |
| it charged on its next turn | - | 0% (0 of 7) | 0% (0 of 7) |
| the enemy charged it first | - | 29% (2 of 7) | 29% (2 of 7) |
| it fought by the end of its next turn | - | 14% (1 of 7) | 14% (1 of 7) |
| it moved out of a charge the enemy had planned (not charged first) | - | 0% (0 of 7) | 0% (0 of 7) |
| none of these (no charge, no fight, no charge escaped) | - | 71% (5 of 7) | 71% (5 of 7) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 84% (48 of 57) | 36% (8 of 22) | 71% (56 of 79) |
|   cavalry | - | 33% (2 of 6) | 33% (2 of 6) |
|   character | - | 0% (0 of 10) | 0% (0 of 10) |
|   chariot | 44% (4 of 9) | - | 44% (4 of 9) |
|   infantry | 92% (11 of 12) | 100% (6 of 6) | 94% (17 of 18) |
|   war machine | 92% (33 of 36) | - | 92% (33 of 36) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.3 (44%) | 0.7 (14%) | 2.0 (26%) |
| CHARGED: it charged | 0.3 (11%) | 0.0 (0%) | 0.3 (4%) |
| IN COMBAT: it fought this turn or the last | 0.3 (11%) | 0.0 (0%) | 0.3 (4%) |
| MOVED: a war machine that moved | 0.7 (22%) | 0.0 (0%) | 0.7 (9%) |
| NO TARGET IN RANGE | 0.0 (0%) | 3.7 (79%) | 3.7 (48%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.0 (0%) | 0.3 (7%) | 0.3 (4%) |
| SHELTERED: the target was sheltered | 0.3 (11%) | 0.0 (0%) | 0.3 (4%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 1.3 | 0.0 | 100% | 0.0 pts | 0 pts |
| chariot | 1.3 | 0.3 | 75% | 6.2 pts | 8 pts |
| infantry | 12.0 | 0.0 | 100% | 0.0 pts | 0 pts |
| war machine | 12.3 | 11.7 | 54% | 21.6 pts | 266 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.3 | 1.7 | 2.5 |
| Charges that made contact a game | 2.0 | 1.7 | 1.8 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.86 declared, 0.29 contact (7 units) | 0.00 declared, 0.00 contact (3 units) | 0.60 declared, 0.20 contact (10 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | - | - |
|   per unit a game, the other units (no war machines, no joined characters) | 0.40 declared, 0.40 contact (10 units) | 0.24 declared, 0.24 contact (21 units) | 0.29 declared, 0.29 contact (31 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 64% (7 of 11) | 50% (1 of 2) | 50% (1 of 2) | 60% (9 of 15) |
| Character in a unit | 100% (1 of 1) | - | - | 100% (1 of 1) |
| Character on its own | 67% (4 of 6) | 67% (4 of 6) | 86% (6 of 7) | 74% (14 of 19) |
| Chariot | 50% (1 of 2) | - | - | 50% (1 of 2) |
| Infantry | 67% (4 of 6) | 50% (1 of 2) | - | 62% (5 of 8) |
| Monster | 50% (1 of 2) | - | - | 50% (1 of 2) |
| War Machines | 67% (4 of 6) | - | - | 67% (4 of 6) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Grand Cathay | 3 | 0% (0 of 2); on the table 0% | 30% (20 of 66) | 65% | 64% (16 of 25) | 100% (7 of 7); 7.7 uses a game | 0.0 uses a game | 33% (1 of 3); 0.3 uses a game |
| High Elf Realms | 1 | 100% (1 of 1); on the table 100% | 33% (2 of 6) | 79% | 78% (7 of 9) | 0.0 uses a game | 33% (2 of 6); 2.0 uses a game | 0.0 uses a game |
| Vampire Counts | 1 | 67% (2 of 3); on the table 67% | 50% (3 of 6) | 65% | 86% (6 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 1 | 67% (4 of 6); on the table 67% | 33% (2 of 6) | 42% | 50% (6 of 12) | 100% (1 of 1); 1.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (csame-bb45c30-p31, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 75% (3) | 75% (3) | 75% (6) |
| ...free all their last turn and able to turn (per game) | 1.00 | 1.00 | 2.00 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.67 | 0.33 | 1.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.33 | 0.33 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: csame-bb45c30-p31

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 4.3 | 3.7 |
| Strategy | Charge objectives carried out (made contact) | 50% (4 of 8) | 80% (4 of 5) |
| Strategy | Shoot objectives carried out (shot that target) | 26% (14 of 54) | 43% (3 of 7) |
| Strategy | Hexes on a unit its side charged or shot that turn | 67% (4 of 6) | 33% (1 of 3) |
| Strategy | Joined characters whose unit fought | 0% (0 of 3) | - |
| Strategy | Lone characters that fought | 67% (6 of 9) | 36% (4 of 11) |
| Movement | Charges halted short of contact | 0.3 | 0.0 |
| Movement | Idle units | 0.0 | 2.0 |
| Movement | Points that never moved of their own | 252.3 | 113.3 |
| Movement | Fights charged into per game | 2.0 | 1.7 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 5 | 2 of 4, net +327 |
| Movement | Charges with odds: sweet spot (55-75%) | 1 of 5, net +0 | 0 of 4 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 1 of 5, net +60 | 0 of 4 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 of 5, net +62 | 1 of 4, net +150 |
| Shooting | Shots by shooting units (incl. breath weapons) | 5.0 | 3.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 60% (9 of 15) | 27% (3 of 11) |
| Shooting | Points destroyed by shooting units | 0.0 | 0.0 |
| Shooting | War machine shots | 11.0 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 45% (15 of 33) | - |
| Shooting | Points destroyed by war machines | 114.7 | 0.0 |
| Magic | Magic missiles cast | 5.0 | 2.0 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 53% (8 of 15) | 50% (3 of 6) |
| Magic | Wounds caused by magic missiles | 6.7 | 2.0 |
| Magic | Wounds caused by other spells | - | 0.7 |
| Magic | Points destroyed by magic (all spells) | 0.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.3 / 2.0 / 0.0 / 1.3 | 2.0 / 1.0 / 0.3 / 0.0 |
| Combat | Points destroyed in combat | 61.0 | 127.7 |
| Combat | Points run down | 47.7 | 0.0 |
| Combat | Net points per charged fight, damage counted | +119 | +221 |
| Combat | Net per 100 charger points, damage counted | +51.0 | +118.3 |
| Combat | First round won (charged fights) | 83% | 80% |
| Combat | Net points per charged fight | +54 | +207 |
| Combat | Net points per supported fight / lone fight | - / +54 | - / +207 |
| Combat | Charged fights on a top-3 enemy unit | 3 of 6 | 3 of 5 |
| Game | Points lost | 312.3 | 264.3 |
| Game | VP from objectives | 680.0 | 656.7 |
| Game | Lone holders (player turns) | 3.0 | 5.0 |

- Mine won / drew / lost: 1 / 1 / 1 of 3 ended games (of 3); mean margin (Mine - Opponent) -58 VP
- The side that went first won 2 of 2 games with a winner
- Points traded per game (both sides' losses): 577
- Games not ended: 0; findings 1, warnings 0

### Opponent rules: csame-bb45c30-p31

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| ARMY TABLE | 8.0 | +255.2 | 0.0 | 0.0 | 25.3 | -779.7 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 8.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| BACKUP TARGETS | - | - | - | - | 0.3 | +0.4 | 0.0 | 0.0 |
| BEST PRIZE | - | - | - | - | 0.3 | +6.0 | 77.7 | 0.0 |
| BOMBING RUN | 0.3 | +15.0 | 41.0 | 0.0 | - | - | - | - |
| CANNON PLAN MISSED | 0.3 | +0.0 | 67.0 | 0.0 | - | - | - | - |
| CANNON PLANNED TARGET | 10.7 | +338.8 | 363.3 | 0.0 | - | - | - | - |
| CANNON SIGHT KEPT | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CAST JOB | 6.0 | +196.8 | 0.0 | 0.0 | 1.0 | +2.1 | 119.3 | 0.0 |
| CASTS AFTER FRIENDS | - | - | - | - | 2.3 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | - | - | - | - | 3.0 | +94.0 | 0.0 | 80.0 |
| CHALLENGE BY POINTS | 0.7 | +4.5 | 0.0 | 0.0 | 0.3 | +4.2 | 0.0 | 47.7 |
| CHAMPION KNOWS CHALLENGE | - | - | - | - | 0.7 | -8.7 | 0.0 | 0.0 |
| CHARGE LOSSES | 10.0 | -472.4 | 0.0 | 288.7 | 29.3 | -1126.2 | 0.0 | 298.7 |
| CHARGE NOW FIRST | 2.7 | +0.0 | 61.0 | 0.0 | 0.7 | +0.0 | 50.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 8.3 | +0.0 | 0.0 | 0.0 | 11.0 | +0.0 | 0.0 | 0.0 |
| COMBAT PIVOT | 1.0 | +0.0 | 0.0 | 77.7 | - | - | - | - |
| CONVEYANCE SEARCH | - | - | - | - | 2.7 | +335.0 | 0.0 | 0.0 |
| COVER ONCE | 12.3 | -812.7 | 0.0 | 50.0 | 6.3 | -305.2 | 0.0 | 47.7 |
| DEFENSIVE ARMY | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| DENIED BY THE FIGHT | 0.3 | -4.5 | 0.0 | 0.0 | 0.3 | -0.9 | 0.0 | 0.0 |
| DEPLOY BY FIGURES | 6.0 | +5.5 | 0.0 | 0.0 | 6.7 | +127.1 | 0.0 | 0.0 |
| EDGE GIVE GROUND | 0.3 | +39.2 | 0.0 | 0.0 | - | - | - | - |
| EXACT ROUND | 1.7 | +51.9 | 61.0 | 0.0 | 1.0 | -9.2 | 50.0 | 0.0 |
| FACES THE THREAT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| FALL BACK GOOD ORDER | 2.0 | +4.0 | 67.7 | 0.0 | 1.7 | +0.9 | 169.3 | 0.0 |
| FALLS SHORT | - | - | - | - | 24.0 | +203.8 | 0.0 | 102.0 |
| FIGHT TO THE END | 1.3 | +22.7 | 47.7 | 0.0 | 0.7 | +44.8 | 119.3 | 0.0 |
| FIVE ACTION | 84.0 | +6428.8 | 1410.0 | 338.7 | 91.7 | +4166.8 | 288.7 | 461.7 |
| FLANK NOT WEIGHED | 7.3 | +0.0 | 0.0 | 169.3 | 6.3 | +0.0 | 0.0 | 47.7 |
| FOLLOW UP WEIGHED | - | - | - | - | 1.0 | +159.6 | 0.0 | 0.0 |
| FOUR ROUNDS | 3.3 | +247.6 | 108.7 | 0.0 | 1.7 | +246.9 | 169.3 | 0.0 |
| FREED FROM HIS FIGHT | 2.7 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 2.7 | -68.3 | 0.0 | 0.0 | - | - | - | - |
| GOAL WALK | 1.7 | +163.4 | 0.0 | 0.0 | 11.0 | +1524.3 | 0.0 | 95.3 |
| GUN MASK | 3.3 | +95.8 | 0.0 | 0.0 | - | - | - | - |
| HARD STAY DROPPED | 0.7 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 1.0 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 7.7 | +0.0 | 0.0 | 288.7 | 11.0 | +0.0 | 0.0 | 231.7 |
| HIS CHARGE DENIED | 0.3 | +9.1 | 0.0 | 0.0 | - | - | - | - |
| HIS CHARGE LIST | 5.0 | +0.0 | 0.0 | 0.0 | 7.3 | +0.0 | 0.0 | 40.0 |
| HIS LEGAL MOVES | 6.0 | +0.0 | 0.0 | 0.0 | 6.7 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 3.7 | -13.3 | 0.0 | 0.0 | 12.0 | -165.2 | 0.0 | 87.0 |
| HIS MOVE AS HE DECIDES | - | - | - | - | 32.3 | +8.7 | 416.3 | 0.0 |
| HIS MOVE WHY | 10.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS ONE MOVE | - | - | - | - | 22.0 | +27.4 | 0.0 | 238.3 |
| HIS ONE QUARTER | 3.0 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 9.0 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVE | 10.7 | +0.0 | 0.0 | 338.7 | - | - | - | - |
| HIS RANDOM MOVER COMES | 0.7 | +0.0 | 0.0 | 238.7 | - | - | - | - |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 19.7 | +177.7 | 0.0 | 0.0 | 73.7 | +6388.9 | 0.0 | 420.7 |
| HIS SHOTS BY HIS RUN | 23.3 | +267.2 | 0.0 | 338.7 | 58.3 | +2101.8 | 0.0 | 461.7 |
| HIS TURN DENIED | 0.3 | +12.4 | 0.0 | 0.0 | 0.3 | +31.1 | 0.0 | 0.0 |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 10.3 | +0.0 | 0.0 | 0.0 | 17.0 | +0.0 | 0.0 | 82.0 |
| HOLDER ASSIGNMENT | 10.0 | +1024.8 | 0.0 | 0.0 | 10.7 | +1098.7 | 0.0 | 41.0 |
| HOLDS AMBUSHERS | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 3.0 | -66.3 | 108.7 | 0.0 | 1.0 | -69.5 | 119.3 | 0.0 |
| HUNT IN PAIRS | 0.3 | +3.6 | 0.0 | 0.0 | - | - | - | - |
| HUNT RESULT | - | - | - | - | 0.3 | +28.9 | 0.0 | 0.0 |
| HUNT THE GUNS | - | - | - | - | 0.3 | +112.8 | 0.0 | 0.0 |
| IDLE COST | - | - | - | - | 21.7 | -383.6 | 0.0 | 136.3 |
| KEEP FALLS | 0.3 | +1.8 | 0.0 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 1.7 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 1.0 | +5.5 | 0.0 | 0.0 | 0.7 | +40.1 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 4.7 | +0.0 | 0.0 | 155.3 | 6.3 | +0.0 | 77.7 | 190.0 |
| LONE WIZARD KEPT IN | 0.7 | +41.6 | 0.0 | 0.0 | - | - | - | - |
| LOST AFTER ESCAPE | 1.7 | +2.1 | 47.7 | 0.0 | 1.3 | +5.4 | 169.3 | 0.0 |
| MANOEUVRE | 1.0 | +0.0 | 0.0 | 0.0 | 1.0 | -9.6 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.3 | +1.7 | 0.0 | 0.0 | 0.7 | +4.9 | 0.0 | 0.0 |
| MARCH BY THE SUM | 1.3 | +17.5 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | 2.3 | +95.8 | 0.0 | 0.0 | - | - | - | - |
| MARCH OF THE TABLE | 1.0 | +39.8 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| MARCH OVER CASTS | 3.7 | +344.2 | 0.0 | 0.0 | 2.0 | +269.1 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 7.0 | +136.3 | 0.0 | 0.0 | 2.7 | +55.5 | 0.0 | 0.0 |
| MEETS IN TIME | 3.7 | +420.3 | 0.0 | 0.0 | 3.7 | +347.5 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 13.7 | +385.8 | 0.0 | 0.0 | 3.7 | +20.6 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 16.7 | +300.0 | 0.0 | 0.0 | 6.7 | +32.5 | 0.0 | 0.0 |
| MISSILES ON ONE TARGET | 0.3 | -14.9 | 0.0 | 0.0 | - | - | - | - |
| MOVE ORDER | 0.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| MOVE SPELL SPOT | - | - | - | - | 2.3 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 8.7 | +878.2 | 0.0 | 50.0 | 4.3 | +421.5 | 0.0 | 95.3 |
| NEARER NOT NEEDED | 5.7 | +240.0 | 0.0 | 119.3 | 5.7 | +203.9 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 4.0 | +427.7 | 0.0 | 0.0 | 1.3 | +179.8 | 0.0 | 0.0 |
| NEXT OBJECTIVE NEARER | 0.3 | -10.0 | 0.0 | 0.0 | - | - | - | - |
| NO DOUBLE ROUNDS | 2.7 | -145.7 | 67.7 | 0.0 | 1.3 | -30.1 | 169.3 | 0.0 |
| NO LATE CUT | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 1.7 | -0.1 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 9.0 | -444.4 | 0.0 | 0.0 | 5.0 | -590.2 | 0.0 | 20.0 |
| OGRE LOADER SECOND SHOT | 12.7 | +95.6 | 0.0 | 0.0 | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 7.0 | -162.3 | 0.0 | 50.0 | 5.7 | -104.3 | 0.0 | 47.7 |
| ONE OBJECTIVE FORMULA | 3.0 | +58.2 | 0.0 | 0.0 | 3.0 | -17.6 | 0.0 | 0.0 |
| ONE PROMISE A TARGET | 0.3 | -22.1 | 0.0 | 0.0 | - | - | - | - |
| ONE ROUTE | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| OPENS A LANE | 0.7 | +0.5 | 0.0 | 0.0 | - | - | - | - |
| OPENS UP | 0.3 | +17.2 | 20.0 | 0.0 | - | - | - | - |
| OVERRUNS AWAY | - | - | - | - | 0.3 | +1.5 | 50.0 | 0.0 |
| OWN CAST FIRST | 0.3 | -6.9 | 0.0 | 0.0 | - | - | - | - |
| PLAN RESULT | 37.3 | +719.0 | 430.3 | 416.3 | 43.3 | +196.8 | 67.0 | 373.0 |
| PROMISE BELOW ZERO | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE BY ITS OWN SUM | 20.0 | -1305.1 | 0.0 | 50.0 | 5.7 | -183.5 | 0.0 | 0.0 |
| PROMISE IN STEPS | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE KNOWS THE FIGHT | 3.3 | -27.3 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | 1.3 | -5.6 | 0.0 | 0.0 | - | - | - | - |
| PROMISE SHOT AWAY | 0.7 | -3.1 | 0.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | 13.3 | +1811.2 | 41.0 | 0.0 | 17.0 | +1546.5 | 119.3 | 0.0 |
| RANDOM MOVE BY FIGURES | - | - | - | - | 4.0 | +52.8 | 0.0 | 0.0 |
| REAL GROUND | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| REDIRECT BY WHAT IT STOPS | - | - | - | - | 0.7 | +78.9 | 0.0 | 40.0 |
| REDIRECT COUNTER | - | - | - | - | 1.0 | +127.7 | 0.0 | 40.0 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 0.7 | +100.3 | 0.0 | 40.0 |
| REFORMS TO MEET IT | 2.7 | -54.1 | 0.0 | 0.0 | 1.3 | -42.4 | 0.0 | 95.3 |
| REFUSING RETIRES | - | - | - | - | 2.0 | +0.0 | 0.0 | 0.0 |
| RISK BY ARC | 2.7 | +124.6 | 108.7 | 0.0 | 1.3 | -63.9 | 169.3 | 0.0 |
| RISK ON THE WAY | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ROUNDS AFTER TERROR | - | - | - | - | 0.3 | -8.7 | 0.0 | 0.0 |
| RUN DOWN | 1.3 | -22.0 | 47.7 | 0.0 | 1.7 | -20.4 | 169.3 | 0.0 |
| SAME CHARGE LATER | 0.3 | -3.2 | 0.0 | 0.0 | - | - | - | - |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 1.3 | +49.2 | 0.0 | 0.0 |
| SEARCH SPOT | 0.7 | +8.7 | 0.0 | 119.3 | 1.0 | +3.0 | 0.0 | 0.0 |
| SECOND LOOK | 0.7 | +12.3 | 47.7 | 0.0 | - | - | - | - |
| SET CREDITED ONCE | 0.7 | -8.1 | 0.0 | 0.0 | 0.3 | -5.3 | 0.0 | 0.0 |
| SET UP BY THE SET | 1.3 | +15.5 | 0.0 | 0.0 | 1.0 | +3.9 | 0.0 | 0.0 |
| SET UP TOGETHER | - | - | - | - | 0.3 | +0.3 | 0.0 | 0.0 |
| SHOOTER COUNTED ONCE | - | - | - | - | 0.7 | -1.9 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 18.3 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 5.0 | +330.4 | 402.0 | 0.0 | 0.7 | +86.5 | 0.0 | 0.0 |
| SHOT REPLANNED | 0.3 | +0.0 | 67.0 | 0.0 | - | - | - | - |
| SHOT RISK POINTS | 11.7 | -81.4 | 0.0 | 288.7 | 49.3 | +1619.9 | 0.0 | 420.7 |
| SHOTS AFTER THE MOVES | 6.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 16.7 | +854.6 | 0.0 | 0.0 | 3.3 | +76.7 | 0.0 | 41.0 |
| SPELL WORTH | 0.3 | +1.4 | 0.0 | 0.0 | 2.0 | +46.6 | 0.0 | 0.0 |
| SPELLS IN THE FIGHT | 1.3 | -21.3 | 0.0 | 0.0 | - | - | - | - |
| SPOT AS THE GAME MOVES | 4.7 | +0.0 | 0.0 | 119.3 | 6.3 | +0.0 | 0.0 | 67.0 |
| STAND AND SHOOT | 0.7 | -3.2 | 41.0 | 0.0 | 0.3 | -2.6 | 50.0 | 0.0 |
| STANDS FOR A REASON | - | - | - | - | 5.0 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 45.3 | +0.0 | 1301.3 | 0.0 | 22.0 | +0.0 | 119.3 | 0.0 |
| STAY WORTH | 31.0 | -463.9 | 631.3 | 0.0 | 4.0 | -33.5 | 119.3 | 0.0 |
| STOPS | - | - | - | - | 0.3 | +39.2 | 0.0 | 0.0 |
| SUPPORT ADDS | 3.0 | +218.9 | 0.0 | 0.0 | 2.7 | +267.8 | 0.0 | 0.0 |
| SUPPORT NARROWED | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| SUPPORT WORKED OUT | 3.0 | +218.9 | 0.0 | 0.0 | 2.7 | +267.8 | 0.0 | 0.0 |
| SURE REACH TOGETHER | - | - | - | - | 1.0 | +4.9 | 0.0 | 0.0 |
| SWIFTSTRIDE BY POINTS | 0.3 | -13.0 | 0.0 | 119.3 | - | - | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 2.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 2.3 | +0.0 | 0.0 | 119.3 | 2.7 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 2.3 | +0.0 | 0.0 | 119.3 | 4.0 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 1.3 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 37.7 | +0.0 | 0.0 | 169.3 | 44.7 | +0.0 | 0.0 | 197.3 |
| TIED UP BY THE SUM | 1.0 | +77.4 | 61.0 | 0.0 | 0.7 | +29.0 | 50.0 | 0.0 |
| TIME ON OUR SIDE | 27.7 | +534.6 | 0.0 | 169.3 | - | - | - | - |
| WAITS AGAIN | 3.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| WALKS ON ITS ROUTE | 0.3 | -5.8 | 0.0 | 0.0 | - | - | - | - |
| WHO FIGHTS | 0.3 | -7.0 | 0.0 | 0.0 | - | - | - | - |
| WHO HITS BACK | - | - | - | - | 0.7 | +173.6 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | 1.3 | -350.0 | 0.0 | 238.7 | 2.3 | -156.1 | 0.0 | 47.7 |
| WOUNDED STAYS OUT | 0.7 | +0.0 | 20.0 | 0.0 | - | - | - | - |
| WOUNDS ON THE RANKS | 2.7 | +6.4 | 0.0 | 238.7 | - | - | - | - |

### Rule changes: csame-bb45c30-p31

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS MOVE AS HE DECIDES | 97 | 97 | 71 | 23.67 | +0 | +0.0 |
| HIS SHOT LIST | 280 | 266 | 67 | 22.33 | +3243 | +48.4 |
| ARMY TABLE | 100 | 100 | 62 | 20.67 | +110 | +1.8 |
| HOLDER ASSIGNMENT | 62 | 62 | 56 | 18.67 | +3566 | +63.7 |
| HIS SHOTS BY HIS RUN | 245 | 234 | 44 | 14.67 | +702 | +15.9 |
| OFF BEST | 42 | 42 | 42 | 14.00 | -3104 | -73.9 |
| FIVE ACTION | 527 | 508 | 40 | 13.33 | +3426 | +85.6 |
| PROMISE BY ITS OWN SUM | 77 | 77 | 40 | 13.33 | -4466 | -111.7 |
| OGRE LOADER SECOND SHOT | 38 | 38 | 38 | 12.67 | +287 | +7.6 |
| LEGAL CHARGES ONLY | 33 | 33 | 33 | 11.00 | +0 | +0.0 |
| THE TABLE AGAIN | 36 | 36 | 31 | 10.33 | +0 | +0.0 |
| SHOT RISK POINTS | 183 | 178 | 30 | 10.00 | +2201 | +73.4 |
| ARTILLERY RE-ROLL WEIGHED | 26 | 26 | 26 | 8.67 | +0 | +0.0 |
| QUARTER ODDS | 91 | 90 | 22 | 7.33 | +1831 | +83.2 |
| CAST JOB | 21 | 21 | 18 | 6.00 | +69 | +3.8 |
| CHARGE LOSSES | 118 | 115 | 18 | 6.00 | +2556 | +142.0 |
| DEPLOY BY FIGURES | 38 | 38 | 18 | 6.00 | +443 | +24.6 |
| HIS MOVE WHY | 32 | 32 | 18 | 6.00 | +0 | +0.0 |
| HIS ONE MOVE | 66 | 66 | 18 | 6.00 | +0 | +0.0 |
| MOVE TO CHARGE COMPUTED | 39 | 32 | 18 | 6.00 | +979 | +54.4 |
| GOAL WALK | 38 | 38 | 13 | 4.33 | +2075 | +159.6 |
| SHOOTS FROM THE BEST SPOT | 17 | 17 | 13 | 4.33 | +186 | +14.3 |
| MEETS IN TIME | 22 | 22 | 12 | 4.00 | +535 | +44.6 |
| COVER ONCE | 56 | 43 | 10 | 3.33 | +238 | +23.8 |
| FOUR ROUNDS | 15 | 15 | 8 | 2.67 | +782 | +97.7 |
| NEXT CHARGE BY LIST | 16 | 12 | 8 | 2.67 | +570 | +71.3 |
| HARD STAY DROPPED | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| ADVANCE LANE KEPT | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| MARCH CHECK | 7 | 7 | 6 | 2.00 | +152 | +25.3 |
| MOVE ORDER | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| RANDOM MOVE BY FIGURES | 12 | 12 | 6 | 2.00 | +158 | +26.4 |
| SHOTS AFTER THE MOVES | 21 | 21 | 6 | 2.00 | +0 | +0.0 |
| CANNON SIGHT KEPT | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| HOLDS AMBUSHERS | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| LANE BY FIGURES | 5 | 5 | 5 | 1.67 | +137 | +27.3 |
| SUPPORT ADDS | 17 | 16 | 5 | 1.67 | +243 | +48.6 |
| SUPPORT WORKED OUT | 17 | 16 | 5 | 1.67 | +243 | +48.6 |
| TIME ON OUR SIDE | 83 | 64 | 5 | 1.67 | +90 | +17.9 |
| CANNON PLANNED TARGET | 32 | 32 | 4 | 1.33 | -101 | -25.2 |
| IDLE COST | 65 | 47 | 4 | 1.33 | +81 | +20.2 |
| MARCH BY THE SUM | 4 | 4 | 4 | 1.33 | +52 | +13.1 |
| MARCH OF THE TABLE | 4 | 4 | 4 | 1.33 | -119 | -29.8 |
| MAX FOR POSITIONING | 29 | 26 | 4 | 1.33 | +27 | +6.7 |
| MISSILES IN THE MOVE | 52 | 35 | 4 | 1.33 | +153 | +38.2 |
| PROMISE KNOWS THE FIGHT | 12 | 9 | 4 | 1.33 | -82 | -20.5 |
| RISK BY ARC | 12 | 12 | 4 | 1.33 | +150 | +37.5 |
| SCREEN BY WHAT IT SAVES | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| CHALLENGE BY POINTS | 3 | 3 | 3 | 1.00 | +26 | +8.6 |
| COMBAT PIVOT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| FALLS SHORT | 72 | 68 | 3 | 1.00 | +21 | +6.9 |
| FOLLOW UP WEIGHED | 3 | 3 | 3 | 1.00 | +479 | +159.6 |
| SEARCH SPOT | 5 | 5 | 3 | 1.00 | +35 | +11.7 |
| TIED UP BY THE SUM | 5 | 5 | 3 | 1.00 | +134 | +44.5 |
| CHAFF IN THE MOVE | 9 | 9 | 2 | 0.67 | +0 | +0.0 |
| EXACT ROUND | 8 | 8 | 2 | 0.67 | +83 | +41.5 |
| GUN MASK | 10 | 10 | 2 | 0.67 | +38 | +19.2 |
| LONE WIZARD KEPT IN | 2 | 2 | 2 | 0.67 | +125 | +62.4 |
| MANOEUVRE | 6 | 6 | 2 | 0.67 | +36 | +17.8 |
| NEARER NOT NEEDED | 34 | 31 | 2 | 0.67 | +47 | +23.6 |
| ONE OBJECTIVE FORMULA | 18 | 11 | 2 | 0.67 | +79 | +39.7 |
| PROMISE SHOT AWAY | 2 | 2 | 2 | 0.67 | -9 | -4.5 |
| REDIRECT FOR A FRIEND IN REACH | 2 | 2 | 2 | 0.67 | +273 | +136.7 |
| SECOND LOOK | 2 | 2 | 2 | 0.67 | +37 | +18.5 |
| SET UP BY THE SET | 7 | 7 | 2 | 0.67 | +76 | +38.2 |
| WHO HITS BACK | 2 | 2 | 2 | 0.67 | +465 | +232.5 |
| BEST PRIZE | 1 | 1 | 1 | 0.33 | -14 | -14.2 |
| BOMBING RUN | 1 | 1 | 1 | 0.33 | +45 | +45.1 |
| CASTS FROM BEHIND | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CHARGE NOW FIRST | 10 | 10 | 1 | 0.33 | -67 | -66.8 |
| EDGE GIVE GROUND | 1 | 1 | 1 | 0.33 | +104 | +104.3 |
| FACES THE THREAT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FIGHT TO THE END | 6 | 6 | 1 | 0.33 | +0 | +0.3 |
| KEEP FALLS | 1 | 1 | 1 | 0.33 | +9 | +8.7 |
| NO DOUBLE ROUNDS | 12 | 12 | 1 | 0.33 | +0 | +0.3 |
| ONE PROMISE A TARGET | 1 | 1 | 1 | 0.33 | -66 | -66.2 |
| OWN CAST FIRST | 1 | 1 | 1 | 0.33 | -21 | -20.9 |
| RUN DOWN | 9 | 9 | 1 | 0.33 | +0 | +0.3 |
| SHOT REPLANNED | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| SUPPORT NARROWED | 2 | 2 | 1 | 0.33 | -188 | -187.5 |
| SURE REACH TOGETHER | 3 | 3 | 1 | 0.33 | +0 | +0.0 |
| SWIFTSTRIDE BY POINTS | 1 | 1 | 1 | 0.33 | -39 | -39.0 |
| THE ROW IN ITS ORDER | 15 | 1 | 1 | 0.33 | +0 | +0.0 |
| WALKS ON ITS ROUTE | 1 | 1 | 1 | 0.33 | -17 | -17.3 |
| WHOLE FIGHT DANGER | 11 | 10 | 1 | 0.33 | +5 | +5.1 |
| BACKUP TARGETS | 1 | 1 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 1 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 7 | trace | - | - | - | - |
| CHAMPION KNOWS CHALLENGE | 2 | 2 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 58 | 57 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 8 | not checked | - | - | - | - |
| DEFENSIVE ARMY | 1 | 1 | 0 | 0.00 | - | - |
| DENIED BY THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 11 | 11 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 41 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 19 | 18 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 8 | 8 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 10 | 9 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 56 | 53 | 0 | 0.00 | - | - |
| HIS CHARGE DENIED | 1 | 1 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 37 | 33 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 38 | 34 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 47 | 45 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 15 | 14 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 37 | 31 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 32 | 31 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 2 | 2 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 2 | 2 | 0 | 0.00 | - | - |
| HIS TURN RUN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 82 | 82 | 0 | 0.00 | - | - |
| HONEST WORTH | 12 | 12 | 0 | 0.00 | - | - |
| HUNT IN PAIRS | 1 | not checked | - | - | - | - |
| HUNT RESULT | 1 | trace | - | - | - | - |
| HUNT THE GUNS | 1 | trace | - | - | - | - |
| KEPT FROM ITS LAST STOP | 16 | 16 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 9 | 9 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 3 | trace | - | - | - | - |
| MARCH OVER CASTS | 17 | 17 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 1 | 1 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 70 | 51 | 0 | 0.00 | - | - |
| MISSILES ON ONE TARGET | 1 | not checked | - | - | - | - |
| MOVE SPELL SPOT | 7 | not checked | - | - | - | - |
| NEXT OBJECTIVE NEARER | 1 | 1 | 0 | 0.00 | - | - |
| NO LATE CUT | 2 | 2 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 18 | 18 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 5 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 3 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 38 | 27 | 0 | 0.00 | - | - |
| ONE ROUTE | 1 | 1 | 0 | 0.00 | - | - |
| OPENS A LANE | 2 | 2 | 0 | 0.00 | - | - |
| OPENS UP | 1 | 1 | 0 | 0.00 | - | - |
| OVERRUNS AWAY | 1 | 1 | 0 | 0.00 | - | - |
| PLAN RESULT | 242 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 2 | 2 | 0 | 0.00 | - | - |
| PROMISE IN STEPS | 5 | 5 | 0 | 0.00 | - | - |
| PROMISE READS THE TABLE | 4 | 4 | 0 | 0.00 | - | - |
| REAL GROUND | 1 | 1 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 2 | 2 | 0 | 0.00 | - | - |
| REDIRECT COUNTER | 3 | 3 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 12 | 11 | 0 | 0.00 | - | - |
| REFUSING RETIRES | 6 | 6 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 2 | 2 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 1 | 1 | 0 | 0.00 | - | - |
| SAME CHARGE LATER | 1 | 1 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 3 | 3 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 1 | not checked | - | - | - | - |
| SHOOTER COUNTED ONCE | 2 | 2 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 65 | not checked | - | - | - | - |
| SHOTS IN THE MOVE | 60 | 34 | 0 | 0.00 | - | - |
| SPELL WORTH | 7 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 4 | 4 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 33 | 26 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 3 | 3 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 15 | 15 | 0 | 0.00 | - | - |
| STANDS STILL | 202 | 196 | 0 | 0.00 | - | - |
| STAY WORTH | 105 | 87 | 0 | 0.00 | - | - |
| STOPS | 1 | 1 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 11 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 19 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 12 | not checked | - | - | - | - |
| THE TABLE BINDS | 247 | not checked | - | - | - | - |
| WAITS AGAIN | 11 | 8 | 0 | 0.00 | - | - |
| WHO FIGHTS | 1 | 1 | 0 | 0.00 | - | - |
| WOUNDED STAYS OUT | 2 | 2 | 0 | 0.00 | - | - |
| WOUNDS ON THE RANKS | 8 | 7 | 0 | 0.00 | - | - |

### Off best figure: csame-bb45c30-p31

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| PROMISE BY ITS OWN SUM | rule | 11.33 | 2.00 | 111.7 |
| JOB FIRST | gate | 8.67 | 4.33 | 79.3 |
| ARMY TABLE | rule | 2.00 | 3.33 | 91.2 |
| PROMISE KNOWS THE FIGHT | rule | 1.33 | - | 20.5 |
| MARCH OF THE TABLE | rule | 1.00 | - | 39.8 |
| AFTERMATH BAND | gate | 0.33 | 0.33 | 4.3 |
| HOLDER ASSIGNMENT | rule | 0.67 | - | 10.6 |
| PROMISE SHOT AWAY | rule | 0.67 | - | 4.5 |
| BEST PRIZE | rule | - | 0.33 | 14.2 |
| CANNON PLANNED TARGET | rule | 0.33 | - | 156.9 |
| CHARGE NOW FIRST | rule | - | 0.33 | 66.8 |
| ONE PROMISE A TARGET | rule | 0.33 | - | 66.2 |
| OWN CAST FIRST | rule | 0.33 | - | 20.9 |
| RULE SWITCHED OFF | gate | - | 0.33 | 1.6 |
| SUPPORT NARROWED | rule | - | 0.33 | 187.5 |
| SWIFTSTRIDE BY POINTS | rule | 0.33 | - | 39.0 |
| WALKS ON ITS ROUTE | rule | 0.33 | - | 17.3 |

### Plans: csame-bb45c30-p31

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 2.3 | 43% | 338 | 161 | 48% |
| Mine | move | 20.3 | 98% | 1417 | 0 | 0% |
| Mine | shoot | 14.7 | 50% | 977 | 558 | 57% |
| Opponent | charge | 1.3 | 100% | 277 | 197 | 71% |
| Opponent | join | 1.0 | 100% | 35 | 0 | 0% |
| Opponent | move | 37.7 | 96% | 1777 | 0 | 0% |
| Opponent | shoot | 2.3 | 0% | 74 | 0 | 0% |
| Opponent | support | 1.0 | 67% | 113 | 0 | 0% |

### Packages: hunt the guns, csame-bb45c30-p31

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Opponent | 0.3 | 1 | 0 | 0% | 0% | 100% | - | 338 | 87 | 0% | 115 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 143 |
| Vampire Counts | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Warriors of Chaos | 1.0 | 1 | 0 | 0% | 0% | 100% | - | 338 | 87 | 0% | 201 |

### Battle groups: csame-bb45c30-p31

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | REDIRECT COUNTER | 1.0 | 67% | 100% | 0% | - | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: csame-bb45c30-p31

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Character | 9 | 9 (9) | 9 | 0 | 13 | 22% | 2.3 | 44 (2) | 4 (6) | - | 6 (5) | 15 (3) |
| Mine | Clean-up | 2 | 74 (2) | 0 | 74 | 0 | 0% | 3.0 | 0 (1) | 139 (1) | - | 74 (2) | - |
| Mine | Fast Hammer | 4 | 48 (4) | 12 | 35 | 50 | 25% | 3.0 | 41 (2) | 50 (2) | - | 73 (3) | 0 (1) |
| Mine | Holder | 1 | 158 (1) | 0 | 158 | 0 | 0% | 1.0 | 158 (1) | - | - | 158 (1) | - |
| Mine | Shooter | 4 | 17 (4) | 0 | 17 | 0 | 25% | 2.0 | 21 (3) | 0 (1) | - | 17 (4) | - |
| Mine | War machine | 6 | 35 (6) | 35 | 0 | 0 | 0% | 1.0 | 61 (2) | 43 (2) | 0 (2) | 0 (1) | 42 (5) |
| Mine | Wizard | 3 | 0 (3) | 0 | 0 | 33 | 0% | 3.3 | 0 (2) | 0 (1) | - | 0 (3) | - |
| Opponent | Chaff | 2 | 300 (2) | 0 | 300 | 50 | 50% | 5.0 | - | 600 (1) | 0 (1) | 300 (2) | - |
| Opponent | Character | 10 | 21 (10) | 21 | 0 | 0 | 40% | 3.2 | 31 (3) | 19 (5) | 0 (2) | 22 (5) | 19 (5) |
| Opponent | Fast Hammer | 9 | 18 (9) | 0 | 18 | 48 | 44% | 3.4 | 30 (2) | 15 (7) | - | 7 (5) | 32 (4) |
| Opponent | Hammer | 3 | 107 (3) | 107 | 0 | 0 | 33% | 3.0 | 171 (2) | 0 (1) | - | 171 (2) | 0 (1) |
| Opponent | Holder | 5 | 46 (5) | 0 | 46 | 0 | 100% | - | 34 (3) | 0 (1) | 102 (1) | 48 (2) | 44 (3) |
| Opponent | Shooter | 1 | 0 (1) | 0 | 0 | 0 | 0% | 1.0 | - | 0 (1) | - | 0 (1) | - |
| Opponent | Wizard | 1 | 0 (1) | 0 | 0 | 0 | 0% | 3.0 | - | - | 0 (1) | - | 0 (1) |

### Charged fights: csame-bb45c30-p31

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Grand Cathay | 3 | 115 | 109 | 2.0 | 1.0 | 54 | 0 | +54 | 3 of 6 | 5 of 6 | - | +54 |
| Opponent | High Elf Realms | 1 | 0 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 1 of 1 | 1 of 1 | - | +0 |
| Opponent | Vampire Counts | 1 | 0 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 0 of 1 | 0 of 1 | - | +0 |
| Opponent | Warriors of Chaos | 1 | 0 | 1037 | 3.0 | 1.0 | 346 | 0 | +346 | 2 of 3 | 3 of 3 | - | +346 |
| **Opponent** | all armies | 3 | 0 | 346 | 1.7 | 1.0 | 207 | 0 | +207 | 3 of 5 | 4 of 5 | - | +207 |

### Effective charges: csame-bb45c30-p31

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Grand Cathay | 6 | 0 | 0 | 1 (net +0) | 1 (net +0) | 1 (net +60) | 2 (net +62) | 1 | 20% (1 of 5) |
| Opponent | High Elf Realms | 1 | 0 | 0 | 0 | 1 (net +0) | 0 | 0 | 0 | 0% (0 of 1) |
| Opponent | Vampire Counts | 1 | 1 (net +0) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 1) |
| Opponent | Warriors of Chaos | 3 | 1 (net +654) | 0 | 0 | 0 | 0 | 1 (net +150) | 1 | 0% (0 of 2) |

### Charged fights, damage counted: csame-bb45c30-p31

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Effective (55-75%) | 1 | 217 | 470 | +0 | 0 | 0 | +0 | +0.0 |
| Mine | 76-89% | 1 | 217 | 470 | +0 | 294 | 0 | +294 | +135.4 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 260 | 162 | +62 | 151 | 41 | +110 | +42.2 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 217 | 60 | +60 | 60 | 0 | +60 | +27.6 |
| Mine | No odds | 1 | 233 | 143 | +143 | 143 | 0 | +143 | +61.4 |
| Mine | All fights | 6 | 234 | 244 | +54 | 133 | 14 | +119 | +51.0 |
| Opponent | Long shot (under 50%) | 2 | 276 | 282 | +327 | 375 | 0 | +375 | +135.6 |
| Opponent | 76-89% | 1 | 151 | 233 | +0 | 39 | 0 | +39 | +25.7 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 116 | 150 | +150 | 150 | 0 | +150 | +129.3 |
| Opponent | No odds | 1 | 116 | 233 | +233 | 233 | 65 | +168 | +144.8 |
| Opponent | All fights | 5 | 187 | 236 | +207 | 234 | 13 | +221 | +118.3 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| csame-bb45c30-p31 | move | 29 | 2 (7%) | 0 (0%) | 4 (14%) | 23 (79%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L1224 |
| Clockwork Compass | Mine | L1224 |
| Elixir of Power | Mine | L1114, L1131 |
| Invocation of Nehek | Opponent | L1224 |
| Opal Amulet | Opponent | L1114 |
| Ring of Doom | Mine | L1114, L1131, L1224 |
| Ring of Doom | Opponent | L1131 |
| Ring of Jet | Mine | L1114, L1131, L1224 |

# Doctrine scorecard: csame-bb45c30-p3

### Scorecard: csame-bb45c30-p3

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0405 | 3 | 1 | Mine | no | 0 | 2 | 2 | 3 | 0 | 0 | 0 | 139 |
| L0405 | 3 | 1 | Opponent | no | 0 | - | 1 | 1 | 0 | 0 | 0 | 1331 |
| L0421 | 1 | 1 | Mine | no | 9 | 2 | 5 | 0 | 0 | 0 | 0 | 0 |
| L0421 | 1 | 1 | Opponent | no | 0 | - | 0 | 6 | 0 | 0 | 0 | 210 |
| L0508 | 4 | 1 | Mine | no | 7 | - | 0 | 2 | 0 | 0 | 0 | 380 |
| L0508 | 4 | 1 | Opponent | no | 0 | - | 0 | 3 | 0 | 0 | 0 | 560 |
| **Average** | | | Mine | 0% | 5.3 | 2.0 | 2.3 | 1.7 | 0.0 | 0.0 | 0.0 | 173.0 |
| **Average** | | | Opponent | 0% | 0.0 | - | 0.3 | 3.3 | 0.0 | 0.0 | 0.0 | 700.3 |

### KPIs: csame-bb45c30-p3

Rules off - Mine only: NO OLD ONE-MOVE GUESS; both sides: ONE RUN A PLAN.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 11) | 56% (5 of 9) | 25% (5 of 20) |
| Winner chose to follow up after the loser gave ground |  | - | 0% (0 of 2); on the table 0% | 0% (0 of 2); on the table 0% |
| Winner chose to pursue after the loser fell back in good order |  | - | 0% (0 of 1); on the table 100% | 0% (0 of 1); on the table 100% |
| Winner chose to pursue after the loser fled |  | - | - | - |
| Winner chose to follow up or pursue (all three) |  | - | 0% (0 of 3); on the table 33% | 0% (0 of 3); on the table 33% |
| Magic missiles tried each own turn | 50%+ | 42% (5 of 12) | 67% (4 of 6) | 50% (9 of 18) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 45% (5 of 11) | 80% (4 of 5) | 56% (9 of 16) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 60% (6 of 10) | 60% (6 of 10) |
| Points that never fought | lower | 76% (4531 of 5998) | 87% (5212 of 5999) | 81% (9743 of 11997) |
|   infantry points that never fought | lower | 78% (1115 of 1424) | 79% (1349 of 1703) | 79% (2464 of 3127) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 52% (12 of 23) | 69% (18 of 26) | 61% (30 of 49) |
| Bound items with a magic missile used (at least once a game) |  | 0.0 uses a game | 100% (1 of 1); 0.7 uses a game | 100% (1 of 1); 0.3 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0.0 uses a game | 50% (1 of 2); 0.3 uses a game | 50% (1 of 2); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 46% (2332 of 5120) | 65% (3058 of 4677) | 55% (5390 of 9797) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.3 (57%) | 0.0 (0%) | 1.3 (44%) |
| MARCHED: its unit marched | 0.7 (29%) | 0.3 (50%) | 1.0 (33%) |
| IN COMBAT: engaged in combat | 0.3 (14%) | 0.0 (0%) | 0.3 (11%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (0%) | 0.3 (50%) | 0.3 (11%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 3.3 | 0.7 | 3.0 | 2.0 | 0.3 |
| not cast | 2.7 | 3.3 | 3.0 | 2.0 | 11.7 |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 2.7 (80%) | 1.3 (44%) | 0.3 (17%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 1.0 (33%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.3 (10%) | 0.3 (11%) | 0.3 (17%) | 0.0 (0%) |
| FLEEING: fleeing | 0.3 (12%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (3%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (0%) | 0.0 (0%) | 0.3 (11%) | 0.0 (0%) | 0.7 (6%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.3 (67%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.3 (88%) | 0.3 (10%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 10.7 (91%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.7 a game | 0.0 a game | 0.3 a game |
| stood (cast and not dispelled) | 50% (1 of 2) | - | 50% (1 of 2) |
| the unit moved after it | 0% (0 of 1) | - | 0% (0 of 1) |
| it charged on its next turn | 0% (0 of 1) | - | 0% (0 of 1) |
| the enemy charged it first | 0% (0 of 1) | - | 0% (0 of 1) |
| it fought by the end of its next turn | 0% (0 of 1) | - | 0% (0 of 1) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 1) | - | 0% (0 of 1) |
| none of these (no charge, no fight, no charge escaped) | 100% (1 of 1) | - | 100% (1 of 1) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 66% (54 of 82) | 82% (81 of 99) | 75% (135 of 181) |
|   cavalry | 50% (5 of 10) | 0% (0 of 7) | 29% (5 of 17) |
|   character | 50% (5 of 10) | 91% (20 of 22) | 78% (25 of 32) |
|   chariot | 83% (20 of 24) | 62% (8 of 13) | 76% (28 of 37) |
|   infantry | 17% (2 of 12) | 78% (14 of 18) | 53% (16 of 30) |
|   war machine | 85% (22 of 26) | 100% (39 of 39) | 94% (61 of 65) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.0 (21%) | 1.3 (22%) | 3.3 (22%) |
| NO TARGET IN RANGE | 4.0 (43%) | 3.0 (50%) | 7.0 (46%) |
| ONLY IN COMBAT: the only targets were in combat | 0.3 (4%) | 0.0 (0%) | 0.3 (2%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 3.0 (32%) | 1.7 (28%) | 4.7 (30%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 1.7 | 0.0 | 100% | 0.0 pts | 0 pts |
| character | 9.0 | 5.3 | 67% | 14.5 pts | 130 pts |
| chariot | 9.3 | 13.3 | 32% | 26.8 pts | 250 pts |
| infantry | 8.3 | 2.3 | 76% | 9.8 pts | 82 pts |
| war machine | 20.3 | 19.0 | 66% | 21.4 pts | 435 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.7 | 0.3 | 2.0 |
| Charges that made contact a game | 1.7 | 0.0 | 0.8 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.50 declared, 0.50 contact (2 units) | 0.00 declared, 0.00 contact (1 units) | 0.33 declared, 0.33 contact (3 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | - | - |
|   per unit a game, the other units (no war machines, no joined characters) | 0.45 declared, 0.18 contact (22 units) | 0.05 declared, 0.00 contact (22 units) | 0.25 declared, 0.09 contact (44 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 0% (0 of 3) | 100% (1 of 1) | - | 25% (1 of 4) |
| Character in a unit | 100% (9 of 9) | 50% (1 of 2) | - | 91% (10 of 11) |
| Character on its own | 67% (2 of 3) | 0% (0 of 2) | 67% (2 of 3) | 50% (4 of 8) |
| Chariot | 50% (1 of 2) | 60% (3 of 5) | - | 57% (4 of 7) |
| Infantry | 75% (6 of 8) | 40% (2 of 5) | 0% (0 of 1) | 57% (8 of 14) |
| Monster | - | 0% (0 of 1) | - | 0% (0 of 1) |
| War Machines | 75% (3 of 4) | - | - | 75% (3 of 4) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Chaos Dwarfs | 2 | - | 42% (5 of 12) | 63% | 44% (7 of 16) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Dwarfen Mountain Holds | 2 | 0% (0 of 2); on the table 0% | - | 87% | 71% (10 of 14) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 1 | - | - | 100% | 70% (7 of 10) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Skaven | 1 | 0% (0 of 1); on the table 100% | 67% (4 of 6) | 86% | 67% (6 of 9) | 100% (1 of 1); 2.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |

Flank and rear charges a unit could have turned to face (csame-bb45c30-p3, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | - | - | - |
| ...free all their last turn and able to turn (per game) | 0.00 | 0.00 | 0.00 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.00 | 0.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.33 | 0.33 |

### Quality by phase: csame-bb45c30-p3

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.7 | 2.0 |
| Strategy | Charge objectives carried out (made contact) | 20% (2 of 10) | 0% (0 of 1) |
| Strategy | Shoot objectives carried out (shot that target) | 59% (22 of 37) | 68% (34 of 50) |
| Strategy | Joined characters whose unit fought | 0% (0 of 5) | 0% (0 of 8) |
| Strategy | Lone characters that fought | 50% (3 of 6) | 29% (2 of 7) |
| Movement | Charges halted short of contact | 0.3 | 0.0 |
| Movement | Idle units | 1.7 | 3.3 |
| Movement | Points that never moved of their own | 173.0 | 700.3 |
| Movement | Fights charged into per game | 1.7 | 0.0 |
| Movement | Charges with odds: long shots (under 50%) | 1 of 4, net +0 | - |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 4 | - |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 1 of 4, net +65 | - |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 of 4, net +750 | - |
| Shooting | Shots by shooting units (incl. breath weapons) | 10.7 | 14.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 50% (16 of 32) | 84% (37 of 44) |
| Shooting | Points destroyed by shooting units | 252.0 | 46.3 |
| Shooting | War machine shots | 7.3 | 13.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 23% (5 of 22) | 62% (24 of 39) |
| Shooting | Points destroyed by war machines | 176.0 | 21.7 |
| Magic | Magic missiles cast | 1.0 | 0.7 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 67% (2 of 3) | 0% (0 of 2) |
| Magic | Wounds caused by magic missiles | 1.0 | 1.3 |
| Magic | Points destroyed by magic (all spells) | 0.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.0 / 0.0 / 0.3 / 1.7 | 1.7 / 0.0 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 137.7 | 21.7 |
| Combat | Points run down | 0.0 | 0.0 |
| Combat | Net points per charged fight, damage counted | +182 | - |
| Combat | Net per 100 charger points, damage counted | +49.6 | - |
| Combat | First round won (charged fights) | 60% | - |
| Combat | Net points per charged fight | +210 | - |
| Combat | Net points per supported fight / lone fight | - / +210 | - / - |
| Combat | Charged fights on a top-3 enemy unit | 3 of 5 | - |
| Game | Points lost | 231.7 | 817.3 |
| Game | VP from objectives | 1016.7 | 793.3 |
| Game | Lone holders (player turns) | 5.3 | 0.0 |

- Mine won / drew / lost: 3 / 0 / 0 of 3 ended games (of 3); mean margin (Mine - Opponent) +749 VP
- The side that went first won 1 of 3 games with a winner
- Points traded per game (both sides' losses): 1049
- Games not ended: 0; findings 1, warnings 0

### Opponent rules: csame-bb45c30-p3

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | - | - | - | - | 0.7 | +138.7 | 0.0 | 0.0 |
| ARMY TABLE | 14.0 | -144.1 | 0.0 | 129.0 | 11.7 | +172.5 | 0.0 | 156.3 |
| ARTILLERY RE-ROLL WEIGHED | 1.7 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 43.3 |
| BEST PRIZE | 0.3 | -30.2 | 0.0 | 0.0 | - | - | - | - |
| CANNON PLAN MISSED | 1.7 | +0.0 | 233.3 | 31.7 | 1.0 | +0.0 | 114.3 | 0.0 |
| CANNON PLANNED TARGET | 6.7 | +26.8 | 565.3 | 95.0 | 13.0 | +368.6 | 272.0 | 190.0 |
| CANNON SIGHT KEPT | 1.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| CAST JOB | 0.7 | +18.7 | 0.0 | 0.0 | 1.3 | +6.8 | 74.7 | 360.0 |
| CASTS AFTER FRIENDS | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | - | - | - | - | 1.0 | +1.9 | 0.0 | 12.0 |
| CHARACTER GUNS | 3.3 | +0.0 | 0.0 | 0.0 | 4.7 | +0.0 | 0.0 | 0.0 |
| CHARGE LOSSES | 18.7 | -972.7 | 0.0 | 175.3 | 8.7 | -547.7 | 0.0 | 337.7 |
| CHARGE NOW FIRST | 3.0 | +0.0 | 505.0 | 0.0 | - | - | - | - |
| CLOSES ON WHAT IT BEATS | 9.3 | +0.0 | 0.0 | 43.3 | 7.3 | +0.0 | 0.0 | 156.7 |
| CONVEYANCE SEARCH | 0.7 | +28.3 | 46.3 | 0.0 | - | - | - | - |
| COVER ONCE | 3.7 | -128.1 | 0.0 | 78.0 | 5.3 | -487.2 | 0.0 | 361.0 |
| DENIED BY THE FIGHT | 0.7 | -15.3 | 0.0 | 0.0 | - | - | - | - |
| DEPLOY BY FIGURES | 8.7 | +40.3 | 0.0 | 0.0 | 9.0 | -53.5 | 0.0 | 135.0 |
| DUEL STOPS AT THE KILL | 1.0 | -46.2 | 0.0 | 0.0 | - | - | - | - |
| EXACT ROUND | 2.3 | +22.3 | 176.7 | 0.0 | - | - | - | - |
| FALL BACK GOOD ORDER | 2.0 | +7.7 | 201.7 | 0.0 | - | - | - | - |
| FALLS SHORT | 8.3 | +120.8 | 0.0 | 0.0 | 9.0 | +137.6 | 0.0 | 43.3 |
| FEATURE BUFFS | - | - | - | - | 2.0 | +8.2 | 0.0 | 0.0 |
| FIGHT TO THE END | 0.3 | +16.7 | 0.0 | 0.0 | - | - | - | - |
| FIRE IN ORDER | 1.3 | +0.0 | 41.7 | 31.7 | 0.3 | +0.0 | 0.0 | 0.0 |
| FIVE ACTION | 91.0 | +6399.2 | 2914.7 | 633.3 | 91.0 | +3727.9 | 896.7 | 1719.0 |
| FLANK NOT WEIGHED | 1.0 | +0.0 | 0.0 | 41.3 | 3.0 | +0.0 | 0.0 | 339.3 |
| FOUR ROUNDS | 3.7 | +261.7 | 356.7 | 0.0 | 0.3 | +6.1 | 0.0 | 0.0 |
| FREED FROM HIS FIGHT | 0.7 | +0.0 | 0.0 | 82.7 | - | - | - | - |
| GIVES UP | 1.0 | -28.1 | 21.7 | 0.0 | - | - | - | - |
| GOAL WALK | 10.7 | +1567.7 | 0.0 | 43.3 | 3.0 | +87.8 | 0.0 | 0.0 |
| GUN FIGURES | 3.3 | +32.3 | 101.3 | 0.0 | 2.7 | +0.9 | 0.0 | 65.0 |
| HARD STAY DROPPED | 2.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 4.0 | +0.0 | 0.0 | 46.3 | 3.7 | +0.0 | 0.0 | 79.7 |
| HIS CHARGE LIST | 1.0 | +0.0 | 0.0 | 0.0 | 4.7 | +0.0 | 0.0 | 123.3 |
| HIS LEGAL MOVES | 2.0 | +0.0 | 0.0 | 46.3 | - | - | - | - |
| HIS MOVE AND SHOT | 1.0 | -2.6 | 0.0 | 0.0 | 0.3 | -4.5 | 0.0 | 0.0 |
| HIS MOVE AS HE DECIDES | 30.3 | +8.7 | 459.3 | 0.0 | - | - | - | - |
| HIS MOVE WHY | - | - | - | - | 24.3 | +0.0 | 0.0 | 271.3 |
| HIS ONE MOVE | 22.0 | -106.7 | 0.0 | 37.3 | - | - | - | - |
| HIS ONE QUARTER | 1.3 | +0.0 | 0.0 | 0.0 | 5.3 | +0.0 | 0.0 | 123.3 |
| HIS OWN BEST MOVE | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS RANDOM MOVE | 4.3 | +0.0 | 0.0 | 80.7 | - | - | - | - |
| HIS RANDOM MOVER COMES | 1.7 | +0.0 | 0.0 | 126.0 | - | - | - | - |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 45.3 | +2773.1 | 0.0 | 356.7 | 33.7 | +1362.3 | 0.0 | 670.0 |
| HIS SHOTS BY HIS RUN | 32.7 | +721.4 | 0.0 | 179.3 | 26.7 | +706.8 | 0.0 | 605.0 |
| HIS TURN DENIED | 1.7 | +197.5 | 63.3 | 0.0 | - | - | - | - |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 14.0 | +0.0 | 0.0 | 0.0 | 17.0 | +0.0 | 0.0 | 79.7 |
| HOLDER ASSIGNMENT | 9.3 | +913.9 | 0.0 | 0.0 | 10.0 | +842.8 | 0.0 | 147.0 |
| HOLDS AMBUSHERS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 3.7 | -147.9 | 356.7 | 0.0 | - | - | - | - |
| HUNT IN PAIRS | 0.3 | +1.8 | 0.0 | 0.0 | - | - | - | - |
| IDLE COST | 6.7 | -99.8 | 0.0 | 68.0 | 9.3 | -116.2 | 0.0 | 55.3 |
| JOINT CHARGE NOW | 0.3 | -71.5 | 0.0 | 0.0 | 0.3 | -0.3 | 0.0 | 0.0 |
| KEPT FROM ITS LAST STOP | 2.0 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 1.3 | +36.6 | 0.0 | 0.0 | - | - | - | - |
| LEGAL CHARGES ONLY | 0.3 | +0.0 | 0.0 | 21.7 | - | - | - | - |
| LONE WIZARD KEPT IN | - | - | - | - | 0.7 | +63.4 | 0.0 | 0.0 |
| LONG SHOT | 0.3 | +2.2 | 0.0 | 0.0 | - | - | - | - |
| LOST AFTER ESCAPE | 1.0 | -1.5 | 0.0 | 0.0 | - | - | - | - |
| MANOEUVRE | 0.7 | +1.5 | 0.0 | 0.0 | 2.3 | -13.7 | 0.0 | 65.0 |
| MARCH AT ESCAPER | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| MARCH CHECK | 1.3 | +110.4 | 0.0 | 0.0 | 0.3 | +20.1 | 0.0 | 0.0 |
| MARCH OVER CASTS | 0.3 | -16.7 | 0.0 | 0.0 | - | - | - | - |
| MARCH WHEELS ONLY | 0.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 2.3 | +120.9 | 0.0 | 0.0 | 0.3 | +0.2 | 0.0 | 0.0 |
| MEETS IN TIME | 2.7 | +300.6 | 0.0 | 0.0 | 3.7 | +178.8 | 0.0 | 41.7 |
| MISSILES IN THE MOVE | 2.7 | +53.2 | 0.0 | 0.0 | 3.0 | +23.0 | 0.0 | 180.0 |
| MISSILES NEXT TURN | 3.0 | +35.0 | 0.0 | 0.0 | 3.0 | +17.2 | 0.0 | 180.0 |
| MOVE ORDER | 2.7 | +0.0 | 37.3 | 46.3 | 2.0 | +0.0 | 0.0 | 0.0 |
| MOVE SPELL IN RANGE | 2.3 | +79.3 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 4.0 | -229.4 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL SPOT | 0.3 | +0.0 | 0.0 | 46.3 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 2.7 | +333.6 | 0.0 | 0.0 | - | - | - | - |
| NEARER NOT NEEDED | 4.3 | +184.5 | 0.0 | 41.3 | 5.7 | +238.0 | 0.0 | 79.7 |
| NEXT CHARGE BY LIST | 2.3 | +344.1 | 180.0 | 0.0 | - | - | - | - |
| NO DOUBLE ROUNDS | 3.3 | -61.4 | 356.7 | 0.0 | - | - | - | - |
| NO LATE CUT | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NO OLD ONE-MOVE GUESS | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | - | - | - | - | 0.3 | -0.2 | 0.0 | 0.0 |
| OFF BEST | 3.7 | -168.8 | 0.0 | 78.0 | 2.7 | -86.7 | 0.0 | 105.0 |
| ONE CHECK AFTER THE LAST CHANGE | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 5.0 | -195.9 | 0.0 | 46.3 | 2.0 | -18.6 | 0.0 | 180.0 |
| ONE JOINT FIGURE | 0.3 | +6.8 | 0.0 | 0.0 | 0.3 | -22.2 | 0.0 | 0.0 |
| ONE OBJECTIVE FORMULA | 2.3 | -2.2 | 0.0 | 0.0 | 4.3 | -26.9 | 0.0 | 79.7 |
| ONE ROUTE | 0.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| OPENS UP | 1.0 | +35.9 | 75.0 | 0.0 | - | - | - | - |
| OVERRUNS AWAY | 2.0 | +16.9 | 123.3 | 0.0 | - | - | - | - |
| PERIAPT WORTH | - | - | - | - | 0.3 | +33.0 | 0.0 | 0.0 |
| PLAN RESULT | 41.0 | +1259.5 | 879.3 | 420.0 | 42.0 | +694.5 | 358.7 | 1044.0 |
| PROMISE BY ITS OWN SUM | 5.7 | -190.7 | 0.0 | 0.0 | - | - | - | - |
| PROMISE KNOWS THE FIGHT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE READS THE TABLE | 0.3 | -19.1 | 0.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | 25.0 | +2297.9 | 1326.7 | 63.3 | 25.0 | +2109.1 | 0.0 | 852.7 |
| RANDOM MOVE BY FIGURES | - | - | - | - | 3.3 | +76.9 | 0.0 | 118.3 |
| REAL GROUND | 0.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | 0.3 | +36.3 | 0.0 | 21.7 | 0.3 | +10.5 | 0.0 | 21.7 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 0.7 | +0.0 | 0.0 | 43.3 |
| REDIRECT WEIGHED | 0.7 | -6.8 | 0.0 | 0.0 | - | - | - | - |
| RESERVE FALL BACK | 1.0 | +25.8 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | 3.0 | -20.0 | 303.3 | 0.0 | - | - | - | - |
| RISK ON THE WAY | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| ROUNDS AFTER TERROR | 2.3 | -27.4 | 85.0 | 0.0 | - | - | - | - |
| RUN DOWN | 1.3 | -1.9 | 0.0 | 0.0 | - | - | - | - |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 1.3 | -166.9 | 0.0 | 0.0 |
| SEARCH SPOT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SET CREDITED ONCE | 0.3 | -2.8 | 0.0 | 0.0 | - | - | - | - |
| SET UP BY THE SET | 0.7 | +0.3 | 21.7 | 0.0 | 0.3 | -2.6 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.7 | +1.3 | 0.0 | 0.0 | 0.7 | +1.3 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 12.3 | +0.0 | 0.0 | 95.0 | 16.3 | +0.0 | 0.0 | 449.7 |
| SHOOTS FROM THE BEST SPOT | 3.0 | +86.0 | 426.7 | 0.0 | 0.3 | +3.8 | 0.0 | 21.7 |
| SHORT GUN FORWARD | - | - | - | - | 0.3 | +0.0 | 0.0 | 45.0 |
| SHOT OR CHARGE | 0.3 | -1.9 | 180.0 | 0.0 | 0.3 | -3.9 | 0.0 | 0.0 |
| SHOT RISK POINTS | 29.3 | +693.3 | 0.0 | 280.0 | 16.7 | +9.7 | 0.0 | 590.3 |
| SHOTS AFTER THE MOVES | 4.3 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 19.0 | +555.3 | 0.0 | 164.0 | 23.0 | +982.3 | 0.0 | 418.0 |
| SPELL WORTH | - | - | - | - | 3.3 | +67.8 | 180.0 | 180.0 |
| SPOT AS THE GAME MOVES | 4.7 | +0.0 | 0.0 | 46.3 | 4.7 | +0.0 | 0.0 | 70.0 |
| STAND AND SHOOT | 0.7 | -4.2 | 43.3 | 0.0 | - | - | - | - |
| STANDS FOR A REASON | 2.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 74.7 | 0.0 |
| STANDS STILL | 46.7 | +0.0 | 2558.0 | 296.7 | 53.3 | +0.0 | 896.7 | 1227.0 |
| STAY WORTH | 33.7 | +396.6 | 1572.0 | 259.0 | 40.0 | -150.7 | 711.3 | 607.3 |
| STUCK PIVOT | - | - | - | - | 1.0 | +0.0 | 0.0 | 48.3 |
| SUPPORT ADDS | - | - | - | - | 2.7 | +382.1 | 0.0 | 0.0 |
| SUPPORT WORKED OUT | - | - | - | - | 2.7 | +382.1 | 0.0 | 0.0 |
| SURE REACH TOGETHER | 0.3 | +25.1 | 0.0 | 0.0 | - | - | - | - |
| SWIFTSTRIDE BY POINTS | 0.3 | +2.9 | 0.0 | 37.3 | - | - | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| THE PROMISE ADDS | 0.3 | -1.4 | 0.0 | 0.0 | - | - | - | - |
| THE ROW IN ITS ORDER | 3.0 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 180.0 |
| THE ROW KEEPS ITS WAY | 4.0 | +0.0 | 0.0 | 63.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 2.7 | +0.0 | 0.0 | 21.7 | 2.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 42.0 | +0.0 | 0.0 | 285.0 | 43.3 | +0.0 | 0.0 | 711.3 |
| TIED UP BY THE SUM | 1.7 | +159.4 | 145.0 | 0.0 | - | - | - | - |
| TIME ON OUR SIDE | 20.0 | +284.5 | 269.3 | 165.3 | 15.0 | +205.2 | 0.0 | 233.7 |
| WAITS AGAIN | 3.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WALKS ON ITS ROUTE | - | - | - | - | 0.3 | -20.0 | 0.0 | 67.3 |
| WAR ENGINE JOBS | 4.7 | +0.0 | 586.3 | 0.0 | - | - | - | - |
| WHO FIGHTS | 0.3 | -0.1 | 0.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT DANGER | 2.3 | -146.7 | 0.0 | 82.7 | 1.7 | -162.7 | 0.0 | 79.7 |
| WHOLE FIGHT GAIN | 0.3 | +81.2 | 0.0 | 0.0 | 0.3 | +0.3 | 0.0 | 0.0 |
| WOUNDS ON THE RANKS | 2.7 | +199.1 | 0.0 | 0.0 | 0.7 | +9.1 | 0.0 | 134.7 |

### Rule changes: csame-bb45c30-p3

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS MOVE AS HE DECIDES | 91 | 91 | 65 | 21.67 | +0 | +0.0 |
| HIS SHOT LIST | 237 | 224 | 63 | 21.00 | +955 | +15.2 |
| HOLDER ASSIGNMENT | 58 | 58 | 54 | 18.00 | +2746 | +50.9 |
| ARMY TABLE | 77 | 77 | 51 | 17.00 | +64 | +1.2 |
| HIS MOVE WHY | 73 | 73 | 42 | 14.00 | +0 | +0.0 |
| HIS SHOTS BY HIS RUN | 178 | 168 | 42 | 14.00 | +469 | +11.2 |
| DEPLOY BY FIGURES | 53 | 53 | 38 | 12.67 | +613 | +16.1 |
| HIS ONE MOVE | 66 | 66 | 26 | 8.67 | +0 | +0.0 |
| SHOT RISK POINTS | 138 | 128 | 21 | 7.00 | +357 | +17.0 |
| OFF BEST | 19 | 19 | 19 | 6.33 | -766 | -40.3 |
| THE TABLE AGAIN | 36 | 36 | 17 | 5.67 | +0 | +0.0 |
| MOVE ORDER | 14 | 14 | 14 | 4.67 | +0 | +0.0 |
| TIME ON OUR SIDE | 105 | 91 | 14 | 4.67 | +31 | +2.2 |
| GOAL WALK | 41 | 38 | 13 | 4.33 | +1646 | +126.6 |
| HARD STAY DROPPED | 11 | 11 | 11 | 3.67 | +0 | +0.0 |
| ARTILLERY RE-ROLL WEIGHED | 10 | 10 | 10 | 3.33 | +0 | +0.0 |
| ADVANCE LANE KEPT | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| CANNON PLANNED TARGET | 59 | 59 | 8 | 2.67 | -1054 | -131.8 |
| FIVE ACTION | 546 | 533 | 8 | 2.67 | +478 | +59.7 |
| IDLE COST | 48 | 39 | 8 | 2.67 | +32 | +4.0 |
| PROMISE BY ITS OWN SUM | 17 | 17 | 7 | 2.33 | -572 | -81.7 |
| STAY WORTH | 221 | 197 | 7 | 2.33 | +160 | +22.8 |
| FOUR ROUNDS | 12 | 12 | 6 | 2.00 | +278 | +46.3 |
| MOVE TO CHARGE COMPUTED | 8 | 6 | 6 | 2.00 | +472 | +78.7 |
| RANDOM MOVE BY FIGURES | 10 | 10 | 6 | 2.00 | +231 | +38.5 |
| SHOOTS FROM THE BEST SPOT | 10 | 10 | 6 | 2.00 | +3 | +0.6 |
| CANNON SIGHT KEPT | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| FIRE IN ORDER | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| MAX FOR POSITIONING | 8 | 8 | 5 | 1.67 | +192 | +38.5 |
| MEETS IN TIME | 19 | 19 | 5 | 1.67 | +199 | +39.8 |
| NEXT CHARGE BY LIST | 7 | 7 | 5 | 1.67 | +468 | +93.6 |
| TIED UP BY THE SUM | 5 | 5 | 5 | 1.67 | +159 | +31.8 |
| CHARGE NOW FIRST | 9 | 9 | 4 | 1.33 | -318 | -79.6 |
| LANE BY FIGURES | 4 | 4 | 4 | 1.33 | +110 | +27.4 |
| MARCH CHECK | 5 | 5 | 4 | 1.33 | +213 | +53.3 |
| SHOOTERS IN TWO RANKS | 4 | 4 | 4 | 1.33 | +8 | +2.0 |
| SUPPORT ADDS | 8 | 8 | 4 | 1.33 | +487 | +121.7 |
| SUPPORT WORKED OUT | 8 | 8 | 4 | 1.33 | +487 | +121.7 |
| WAR ENGINE JOBS | 14 | 14 | 4 | 1.33 | -334 | -83.6 |
| CAST JOB | 6 | 6 | 3 | 1.00 | +1 | +0.2 |
| CHARGE LOSSES | 82 | 73 | 3 | 1.00 | +302 | +100.8 |
| MISSILES IN THE MOVE | 17 | 7 | 3 | 1.00 | +3 | +0.8 |
| OPENS UP | 3 | 3 | 3 | 1.00 | +65 | +21.6 |
| QUARTER ODDS | 150 | 148 | 3 | 1.00 | +524 | +174.7 |
| RESERVE FALL BACK | 3 | 3 | 3 | 1.00 | +77 | +25.8 |
| RISK BY ARC | 9 | 9 | 3 | 1.00 | +36 | +11.8 |
| SHOTS IN THE MOVE | 126 | 86 | 3 | 1.00 | +210 | +70.0 |
| STUCK PIVOT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| THE ROW IN ITS ORDER | 17 | 3 | 3 | 1.00 | +0 | +0.0 |
| AFTERMATH IN POINTS | 2 | 2 | 2 | 0.67 | +416 | +208.0 |
| CHAFF IN THE MOVE | 3 | 3 | 2 | 0.67 | +0 | +0.0 |
| FALLS SHORT | 52 | 44 | 2 | 0.67 | +22 | +10.8 |
| HIS TURN DENIED | 5 | 5 | 2 | 0.67 | +33 | +16.6 |
| HOLDS AMBUSHERS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| HONEST WORTH | 11 | 11 | 2 | 0.67 | +33 | +16.6 |
| JOINT CHARGE NOW | 2 | 2 | 2 | 0.67 | -216 | -107.8 |
| LONE WIZARD KEPT IN | 2 | 2 | 2 | 0.67 | +190 | +95.2 |
| NO DOUBLE ROUNDS | 10 | 10 | 2 | 0.67 | +33 | +16.6 |
| REDIRECT FOR A FRIEND IN REACH | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| REDIRECT WEIGHED | 2 | 2 | 2 | 0.67 | +20 | +10.1 |
| SHOTS AFTER THE MOVES | 25 | 25 | 2 | 0.67 | +0 | +0.0 |
| WHOLE FIGHT DANGER | 12 | 11 | 2 | 0.67 | +4 | +2.0 |
| BEST PRIZE | 1 | 1 | 1 | 0.33 | -91 | -90.6 |
| COVER ONCE | 27 | 23 | 1 | 0.33 | +2 | +1.8 |
| EXACT ROUND | 7 | 7 | 1 | 0.33 | +5 | +5.3 |
| FALL BACK GOOD ORDER | 6 | 6 | 1 | 0.33 | +5 | +4.9 |
| FIGHT TO THE END | 1 | 1 | 1 | 0.33 | +3 | +2.7 |
| LEGAL CHARGES ONLY | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| LONG SHOT | 1 | 1 | 1 | 0.33 | +5 | +4.9 |
| MANOEUVRE | 9 | 9 | 1 | 0.33 | +4 | +4.5 |
| ONE OBJECTIVE FORMULA | 20 | 14 | 1 | 0.33 | +28 | +28.1 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.33 | +99 | +99.0 |
| PROMISE READS THE TABLE | 1 | 1 | 1 | 0.33 | +111 | +110.6 |
| REDIRECT COUNTER | 2 | 2 | 1 | 0.33 | +56 | +56.4 |
| SET UP BY THE SET | 3 | 3 | 1 | 0.33 | +13 | +13.1 |
| SHORT GUN FORWARD | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| SURE REACH TOGETHER | 1 | 1 | 1 | 0.33 | +38 | +38.2 |
| SWIFTSTRIDE BY POINTS | 1 | 1 | 1 | 0.33 | +9 | +8.8 |
| WALKS ON ITS ROUTE | 1 | 1 | 1 | 0.33 | -60 | -60.0 |
| WHOLE FIGHT GAIN | 2 | 2 | 1 | 0.33 | +112 | +112.2 |
| CANNON PLAN MISSED | 8 | 8 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 1 | trace | - | - | - | - |
| CHARACTER GUNS | 24 | 24 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 50 | 49 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 2 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 3 | 3 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 6 | 6 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 12 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| GIVES UP | 3 | 3 | 0 | 0.00 | - | - |
| GUN FIGURES | 18 | not checked | - | - | - | - |
| HIS CHARGE BY HIS RUN | 23 | 23 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 17 | 17 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 6 | 6 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 4 | 3 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 20 | 20 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 4 | 4 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 13 | 10 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 5 | 4 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN RUN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 93 | 92 | 0 | 0.00 | - | - |
| HUNT IN PAIRS | 1 | not checked | - | - | - | - |
| KEPT FROM ITS LAST STOP | 12 | 11 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 3 | 3 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 1 | 1 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 6 | 6 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 18 | 9 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 7 | 1 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 12 | trace | - | - | - | - |
| MOVE SPELL SPOT | 1 | not checked | - | - | - | - |
| NEARER NOT NEEDED | 30 | 29 | 0 | 0.00 | - | - |
| NO LATE CUT | 2 | 2 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 18 | 18 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT TURNED | 1 | 1 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 1 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 1 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 21 | 11 | 0 | 0.00 | - | - |
| ONE JOINT FIGURE | 2 | 2 | 0 | 0.00 | - | - |
| ONE ROUTE | 6 | 6 | 0 | 0.00 | - | - |
| OVERRUNS AWAY | 6 | 6 | 0 | 0.00 | - | - |
| PLAN RESULT | 249 | trace | - | - | - | - |
| PROMISE KNOWS THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| REAL GROUND | 6 | 6 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 2 | 2 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 7 | 7 | 0 | 0.00 | - | - |
| RUN DOWN | 4 | 4 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 4 | 4 | 0 | 0.00 | - | - |
| SEARCH SPOT | 1 | 1 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 1 | 1 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 86 | not checked | - | - | - | - |
| SHOT OR CHARGE | 2 | 2 | 0 | 0.00 | - | - |
| SPELL WORTH | 10 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 28 | 19 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 2 | 2 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 10 | 9 | 0 | 0.00 | - | - |
| STANDS STILL | 300 | 295 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 4 | not checked | - | - | - | - |
| THE PROMISE ADDS | 1 | 1 | 0 | 0.00 | - | - |
| THE ROW KEEPS ITS WAY | 20 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 14 | not checked | - | - | - | - |
| THE TABLE BINDS | 256 | not checked | - | - | - | - |
| WAITS AGAIN | 9 | 7 | 0 | 0.00 | - | - |
| WHO FIGHTS | 1 | 1 | 0 | 0.00 | - | - |
| WOUNDS ON THE RANKS | 10 | 10 | 0 | 0.00 | - | - |

### Off best figure: csame-bb45c30-p3

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 2.67 | 2.67 | 32.8 |
| PROMISE BY ITS OWN SUM | rule | 2.33 | - | 81.7 |
| ARMY TABLE | rule | 1.67 | 0.33 | 218.3 |
| CANNON PLANNED TARGET | rule | - | 1.33 | 263.6 |
| CHARGE NOW FIRST | rule | 1.33 | - | 79.6 |
| WAR ENGINE JOBS | rule | 1.33 | - | 83.6 |
| RULE SWITCHED OFF | gate | 1.00 | - | 80.7 |
| JOINT CHARGE NOW | rule | 0.33 | 0.33 | 107.8 |
| BEST PRIZE | rule | 0.33 | - | 90.6 |
| REDIRECT WEIGHED | rule | 0.33 | - | 50.4 |
| WALKS ON ITS ROUTE | rule | - | 0.33 | 60.0 |

### Plans: csame-bb45c30-p3

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 3.3 | 30% | 440 | 296 | 67% |
| Mine | join | 0.3 | 100% | 11 | 0 | 0% |
| Mine | move | 27.0 | 93% | 1955 | 0 | 0% |
| Mine | shoot | 10.3 | 71% | 441 | 963 | 219% |
| Opponent | join | 1.0 | 100% | 35 | 0 | 0% |
| Opponent | move | 25.7 | 91% | 919 | 0 | 0% |
| Opponent | shoot | 14.7 | 57% | 517 | 694 | 134% |
| Opponent | support | 0.7 | 100% | 0 | 0 | - |

### Battle groups: csame-bb45c30-p3

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 0.3 | 0% | - | - | - | - | - | - | - | - |
| Opponent | REDIRECT COUNTER | 0.3 | 0% | - | - | - | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: csame-bb45c30-p3

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 2 | 0 (2) | 0 | 0 | 50 | 100% | - | 0 (1) | - | 0 (1) | 0 (2) | - |
| Mine | Character | 11 | 28 (11) | 28 | 0 | 0 | 18% | 2.0 | 38 (5) | 33 (4) | 0 (2) | 31 (7) | 24 (4) |
| Mine | Clean-up | 3 | 99 (3) | 0 | 99 | 34 | 33% | 3.5 | 99 (3) | - | - | 150 (2) | 0 (1) |
| Mine | Hammer | 8 | 45 (8) | 30 | 15 | 4 | 12% | 1.7 | 0 (2) | 54 (6) | - | 37 (5) | 53 (3) |
| Mine | Holder | 4 | 105 (4) | 0 | 105 | 27 | 75% | 1.0 | 0 (1) | 138 (3) | - | 237 (1) | 56 (3) |
| Mine | Shooter | 1 | 27 (1) | 0 | 27 | 100 | 0% | 1.0 | 27 (1) | - | - | - | 27 (1) |
| Mine | War machine | 5 | 111 (5) | 111 | 0 | 40 | 0% | 1.0 | 111 (5) | - | - | 278 (2) | 0 (3) |
| Opponent | Chaff | 3 | 0 (3) | 0 | 0 | 65 | 100% | - | 0 (1) | 0 (1) | 0 (1) | 0 (1) | 0 (2) |
| Opponent | Character | 14 | 7 (14) | 7 | 0 | 49 | 43% | 2.5 | 10 (10) | 0 (3) | - | 9 (9) | 0 (4) |
| Opponent | Clean-up | 4 | 96 (4) | 0 | 96 | 0 | 75% | 6.0 | - | 96 (4) | - | 96 (4) | - |
| Opponent | Fragile | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | - | 0 (1) | - | 0 (1) |
| Opponent | Hammer | 6 | 44 (6) | 27 | 17 | 48 | 17% | 2.4 | 44 (2) | 0 (1) | 67 (3) | 44 (6) | - |
| Opponent | Holder | 3 | 0 (3) | 0 | 0 | 0 | 100% | - | - | 0 (2) | 0 (1) | 0 (1) | 0 (2) |
| Opponent | Shooter | 4 | 12 (4) | 0 | 12 | 67 | 50% | 2.0 | - | 20 (3) | 0 (1) | 12 (4) | - |
| Opponent | War machine | 9 | 7 (9) | 7 | 0 | 62 | 11% | 1.0 | 7 (9) | - | - | 0 (1) | 8 (8) |
| Opponent | Wizard | 1 | 0 (1) | 0 | 0 | 0 | 0% | 6.0 | - | 0 (1) | - | 0 (1) | - |

### Charged fights: csame-bb45c30-p3

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaos Dwarfs | 2 | 277 | 524 | 2.5 | 1.0 | 210 | 0 | +210 | 3 of 5 | 3 of 5 | - | +210 |
| Mine | Dwarfen Mountain Holds | 1 | 730 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| **Mine** | all armies | 3 | 428 | 349 | 1.7 | 1.0 | 210 | 0 | +210 | 3 of 5 | 3 of 5 | - | +210 |
| Opponent | Dwarfen Mountain Holds | 1 | 139 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Empire of Man | 1 | 65 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Skaven | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| **Opponent** | all armies | 3 | 68 | 0 | 0.0 | - | - | - | - | - | - | - | - |

### Effective charges: csame-bb45c30-p3

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaos Dwarfs | 5 | 1 (net +0) | 0 | 0 | 1 (net +138) | 1 (net +65) | 1 (net +750) | 1 | 0% (0 of 4) |

### Charged fights, damage counted: csame-bb45c30-p3

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 1 | 339 | 239 | +0 | 0 | 49 | -49 | -14.4 |
| Mine | 76-89% | 1 | 339 | 239 | +138 | 345 | 294 | +51 | +14.9 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 480 | 210 | +750 | 808 | 60 | +748 | +155.8 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 339 | 65 | +65 | 65 | 0 | +65 | +19.2 |
| Mine | No odds | 1 | 339 | 50 | +95 | 95 | 0 | +95 | +28.0 |
| Mine | All fights | 5 | 367 | 161 | +210 | 263 | 81 | +182 | +49.6 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| csame-bb45c30-p3 | move | 7 | 1 (14%) | 1 (14%) | 1 (14%) | 5 (71%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Periapt of Soul Exchange | Opponent | L0421 |
| Storm Daemon (Renegade 2.0) | Opponent | L0421 |
| Witch Hunter's Ward | Opponent | L0508 |

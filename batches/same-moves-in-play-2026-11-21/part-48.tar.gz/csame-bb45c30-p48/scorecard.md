# Doctrine scorecard: csame-bb45c30-p48

### Scorecard: csame-bb45c30-p48

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L2535 | 3 | 1 | Mine | no | 1 | - | 1 | 1 | 1 | 0 | 0 | 0 |
| L2535 | 3 | 1 | Opponent | no | 2 | 2 | 4 | 4 | 0 | 0 | 0 | 0 |
| L2735 | 5 | 1 | Mine | no | - | 2 | 2 | 4 | 0 | 0 | 0 | 0 |
| L2735 | 5 | 1 | Opponent | yes | - | 2 | 6 | 2 | 0 | 0 | 0 | 0 |
| L3033 | 3 | 1 | Mine | yes | 6 | 2 | 4 | 2 | 0 | 0 | 0 | 0 |
| L3033 | 3 | 1 | Opponent | no | 0 | 2 | 6 | 2 | 1 | 0 | 0 | 549 |
| **Average** | | | Mine | 33% | 3.5 | 2.0 | 2.3 | 2.3 | 0.3 | 0.0 | 0.0 | 0.0 |
| **Average** | | | Opponent | 33% | 1.0 | 2.0 | 5.3 | 2.7 | 0.3 | 0.0 | 0.0 | 183.0 |

### KPIs: csame-bb45c30-p48

Rules off - Opponent only: NO OLD ONE-MOVE GUESS; both sides: ONE RUN A PLAN.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 14) | 29% (5 of 17) | 16% (5 of 31) |
| Winner chose to follow up after the loser gave ground |  | 50% (1 of 2); on the table 50% | 100% (10 of 10); on the table 100% | 92% (11 of 12); on the table 92% |
| Winner chose to pursue after the loser fell back in good order |  | 0% (0 of 1); on the table 100% | - | 0% (0 of 1); on the table 100% |
| Winner chose to pursue after the loser fled |  | 0% (0 of 1); on the table 0% | 100% (1 of 1); on the table 100% | 50% (1 of 2); on the table 50% |
| Winner chose to follow up or pursue (all three) |  | 25% (1 of 4); on the table 50% | 100% (11 of 11); on the table 100% | 80% (12 of 15); on the table 87% |
| Magic missiles tried each own turn | 50%+ | 54% (13 of 24) | 39% (7 of 18) | 48% (20 of 42) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 59% (13 of 22) | 41% (7 of 17) | 51% (20 of 39) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | - | - |
| Points that never fought | lower | 31% (1841 of 5999) | 36% (2134 of 6000) | 33% (3975 of 11999) |
|   infantry points that never fought | lower | 56% (435 of 780) | 46% (890 of 1918) | 49% (1325 of 2698) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 72% (13 of 18) | 65% (22 of 34) | 67% (35 of 52) |
| Bound items with a magic missile used (at least once a game) |  | 0.0 uses a game | 50% (2 of 4); 1.3 uses a game | 50% (2 of 4); 0.7 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 100% (1 of 1); 0.3 uses a game | 0% (0 of 1); 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 63% (3025 of 4808) | 54% (3227 of 5962) | 58% (6252 of 10770) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.0 (27%) | 2.0 (55%) | 3.0 (41%) |
| MARCHED: its unit marched | 1.0 (27%) | 1.3 (36%) | 2.3 (32%) |
| IN COMBAT: engaged in combat | 0.3 (9%) | 0.3 (9%) | 0.7 (9%) |
| GONE: slain | 0.3 (9%) | 0.0 (0%) | 0.3 (5%) |
| STUPIDITY: Stupidity | 1.0 (27%) | 0.0 (0%) | 1.0 (14%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 5.0 | 3.0 | 3.7 | 6.7 | 2.7 | 2.7 |
| not cast | 3.0 | 0.3 | 2.3 | 7.3 | 3.3 | 21.3 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.7 (8%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.3 (100%) | 0.0 (0%) | 3.0 (41%) | 1.3 (40%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.3 (32%) | 0.7 (20%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.0 (0%) | 0.7 (29%) | 0.7 (9%) | 0.3 (10%) | 0.0 (0%) |
| GONE: slain | 0.7 (22%) | 0.0 (0%) | 0.3 (14%) | 0.3 (5%) | 0.0 (0%) | 3.7 (17%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.0 (14%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.0 (30%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.3 (78%) | 0.0 (0%) | 1.3 (57%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 16.0 (75%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.0 a game | 2.7 a game | 1.8 a game |
| stood (cast and not dispelled) | 67% (2 of 3) | 50% (4 of 8) | 55% (6 of 11) |
| the unit moved after it | 100% (2 of 2) | 0% (0 of 4) | 33% (2 of 6) |
| it charged on its next turn | 0% (0 of 2) | 0% (0 of 4) | 0% (0 of 6) |
| the enemy charged it first | 0% (0 of 2) | 0% (0 of 4) | 0% (0 of 6) |
| it fought by the end of its next turn | 0% (0 of 2) | 0% (0 of 4) | 0% (0 of 6) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 2) | 0% (0 of 4) | 0% (0 of 6) |
| none of these (no charge, no fight, no charge escaped) | 100% (2 of 2) | 100% (4 of 4) | 100% (6 of 6) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 0% (0 of 5) | 58% (50 of 86) | 55% (50 of 91) |
|   cavalry | - | 64% (27 of 42) | 64% (27 of 42) |
|   character | 0% (0 of 5) | 33% (5 of 15) | 25% (5 of 20) |
|   infantry | - | 62% (18 of 29) | 62% (18 of 29) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 0.0 (0%) | 4.0 (33%) | 4.0 (29%) |
| CHARGED: it charged | 0.3 (20%) | 6.0 (50%) | 6.3 (46%) |
| FLEEING: it fled or was fleeing | 0.0 (0%) | 0.3 (3%) | 0.3 (2%) |
| IN COMBAT: it fought this turn or the last | 0.0 (0%) | 0.3 (3%) | 0.3 (2%) |
| NO TARGET IN RANGE | 0.7 (40%) | 0.0 (0%) | 0.7 (5%) |
| ONLY IN COMBAT: the only targets were in combat | 0.3 (20%) | 0.0 (0%) | 0.3 (2%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.3 (20%) | 1.3 (11%) | 1.7 (12%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 12.3 | 1.0 | 92% | 3.4 pts | 42 pts |
| character | 1.7 | 1.3 | 40% | 23.2 pts | 39 pts |
| infantry | 9.0 | 2.0 | 85% | 2.3 pts | 21 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 2.7 | 8.7 | 5.7 |
| Charges that made contact a game | 2.0 | 6.3 | 4.2 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.00 declared, 0.00 contact (4 units) | - | 0.00 declared, 0.00 contact (4 units) |
|   per unit a game, units carrying another wizard (or one alone) | 1.67 declared, 1.67 contact (3 units) | - | 1.67 declared, 1.67 contact (3 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.16 declared, 0.05 contact (19 units) | 0.84 declared, 0.61 contact (31 units) | 0.58 declared, 0.40 contact (50 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 64% (7 of 11) | 50% (1 of 2) | 100% (1 of 1) | 64% (9 of 14) |
| Character in a unit | 100% (2 of 2) | 60% (3 of 5) | - | 71% (5 of 7) |
| Character on its own | 100% (3 of 3) | 100% (1 of 1) | 17% (1 of 6) | 50% (5 of 10) |
| Infantry | 83% (10 of 12) | 67% (2 of 3) | - | 80% (12 of 15) |
| Monster | - | 100% (1 of 1) | - | 100% (1 of 1) |
| Monstrous | 60% (3 of 5) | - | - | 60% (3 of 5) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Vampire Counts | 2 | 0% (0 of 2); on the table 50% | 54% (13 of 24) | 37% | 83% (10 of 12) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 1 | 50% (1 of 2); on the table 50% | - | 18% | 50% (3 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Wood Elf Realms | 3 | 100% (11 of 11); on the table 100% | 39% (7 of 18) | 36% | 65% (22 of 34) | 50% (2 of 4); 1.3 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (csame-bb45c30-p48, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 56% (9) | 50% (1) | 56% (10) |
| ...free all their last turn and able to turn (per game) | 2.67 | 0.00 | 2.67 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 2.33 | 0.00 | 2.33 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: csame-bb45c30-p48

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.7 | 0.7 |
| Strategy | Charge objectives carried out (made contact) | 57% (4 of 7) | 60% (12 of 20) |
| Strategy | Shoot objectives carried out (shot that target) | 0% (0 of 3) | 50% (4 of 8) |
| Strategy | Support requests answered (helper made contact too) | 0% (0 of 1) | 100% (3 of 3) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (1 of 1) | - |
| Strategy | Hexes on a unit its side charged or shot that turn | - | 80% (4 of 5) |
| Strategy | Joined characters whose unit fought | 50% (3 of 6) | 33% (1 of 3) |
| Strategy | Lone characters that fought | 75% (6 of 8) | 100% (5 of 5) |
| Movement | Charges halted short of contact | 0.3 | 0.7 |
| Movement | Idle units | 2.3 | 2.7 |
| Movement | Points that never moved of their own | 0.0 | 183.0 |
| Movement | Fights charged into per game | 2.0 | 5.7 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 5 | 3 of 13, net +400 |
| Movement | Charges with odds: sweet spot (55-75%) | 1 of 5, net +505 | 0 of 13 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 1 of 5, net +349 | 2 of 13, net +111 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 of 5, net +247 | 6 of 13, net +34 |
| Shooting | Shots by shooting units (incl. breath weapons) | 0.3 | 17.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 0% (0 of 1) | 68% (36 of 53) |
| Shooting | Points destroyed by shooting units | 0.0 | 0.0 |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | 3.3 | 1.7 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 40% (4 of 10) | 60% (3 of 5) |
| Magic | Wounds caused by magic missiles | - | 3.3 |
| Magic | Wounds caused by other spells | 1.7 | - |
| Magic | Points destroyed by magic (all spells) | 0.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.7 / 1.3 / 2.0 / 0.7 | 1.3 / 1.7 / 0.3 / 1.3 |
| Combat | Points destroyed in combat | 526.0 | 807.0 |
| Combat | Points run down | 124.0 | 0.0 |
| Combat | Net points per charged fight, damage counted | +140 | +61 |
| Combat | Net per 100 charger points, damage counted | +36.9 | +29.6 |
| Combat | First round won (charged fights) | 83% | 65% |
| Combat | Net points per charged fight | +130 | +60 |
| Combat | Net points per supported fight / lone fight | - / +130 | +186 / +52 |
| Combat | Charged fights on a top-3 enemy unit | 3 of 6 | 4 of 17 |
| Game | Points lost | 796.3 | 662.0 |
| Game | VP from objectives | 640.0 | 753.3 |
| Game | Lone holders (player turns) | 3.5 | 1.0 |

- Mine won / drew / lost: 1 / 0 / 2 of 3 ended games (of 3); mean margin (Mine - Opponent) -247 VP
- The side that went first won 0 of 3 games with a winner
- Points traded per game (both sides' losses): 1458
- Games not ended: 0; findings 1, warnings 0

### Opponent rules: csame-bb45c30-p48

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.3 | +222.7 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | 24.3 | +316.1 | 0.0 | 324.3 | 37.0 | +459.6 | 0.0 | 470.0 |
| ASSAILMENT BY POINTS | 1.0 | +3.7 | 0.0 | 260.7 | - | - | - | - |
| BACKUP TARGETS | 0.7 | +1.2 | 0.0 | 0.0 | - | - | - | - |
| CARRIES OUT SET-UP | - | - | - | - | 0.3 | +0.0 | 62.0 | 0.0 |
| CAST JOB | 1.7 | +5.4 | 0.0 | 0.0 | - | - | - | - |
| CASTER AWAY FROM SCREEN | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | - | - | - | - | 0.7 | +40.7 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 0.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | 5.0 | +129.0 | 0.0 | 0.0 | 0.3 | +27.8 | 0.0 | 0.0 |
| CHAFF PASSED | - | - | - | - | 0.7 | -0.1 | 0.0 | 0.0 |
| CHALLENGE BY POINTS | - | - | - | - | 1.0 | +97.8 | 0.0 | 41.7 |
| CHARACTER GUNS | - | - | - | - | 3.3 | +0.0 | 0.0 | 0.0 |
| CHARGE LIST READ AGAIN | - | - | - | - | 0.3 | +88.6 | 84.7 | 0.0 |
| CHARGE LOSSES | 17.0 | -603.7 | 0.0 | 254.7 | 13.0 | -648.2 | 0.0 | 404.0 |
| CHARGE NOW FIRST | 1.0 | +0.0 | 202.7 | 190.3 | 2.7 | +0.0 | 274.3 | 0.0 |
| CLOSES ON WHAT IT BEATS | 16.7 | +0.0 | 0.0 | 140.7 | 5.3 | +0.0 | 0.0 | 38.0 |
| COMBAT PIVOT | 0.7 | +0.0 | 42.0 | 0.0 | 0.3 | +0.0 | 84.7 | 0.0 |
| CONVEYANCE SEARCH | 1.0 | +9.5 | 0.0 | 0.0 | 2.3 | +255.9 | 86.0 | 0.0 |
| COVER ONCE | 7.3 | -598.9 | 0.0 | 264.3 | 12.0 | -395.2 | 0.0 | 74.7 |
| DENIED BY THE FIGHT | 0.3 | -0.4 | 0.0 | 0.0 | - | - | - | - |
| DEPLOY BY FIGURES | 7.0 | +35.9 | 0.0 | 0.0 | 10.0 | -110.5 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | 0.3 | -4.7 | 78.7 | 0.0 | 0.7 | -118.7 | 132.7 | 0.0 |
| EDGE GIVE GROUND | 0.3 | +9.4 | 0.0 | 84.7 | 0.3 | +12.7 | 0.0 | 42.0 |
| EXACT ROUND | 2.0 | +69.0 | 367.0 | 275.0 | 5.3 | +41.7 | 386.3 | 84.0 |
| FALL BACK GOOD ORDER | 1.7 | +21.8 | 239.3 | 0.0 | 3.7 | +0.0 | 249.0 | 0.0 |
| FALLBACK BY WORTH | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| FALLS SHORT | 22.3 | +310.4 | 0.0 | 321.0 | - | - | - | - |
| FEATURE BUFFS | 1.7 | +9.5 | 0.0 | 0.0 | 1.3 | +10.4 | 0.0 | 111.3 |
| FIGHT TO THE END | 0.3 | +0.2 | 0.0 | 84.7 | 1.0 | -2.6 | 62.0 | 0.0 |
| FIRE AND FLEE | - | - | - | - | 0.3 | +3.5 | 0.0 | 38.0 |
| FIVE ACTION | 78.3 | +4905.9 | 445.7 | 1313.0 | 93.3 | +7446.5 | 559.0 | 1041.0 |
| FLANK NOT WEIGHED | 7.0 | +0.0 | 0.0 | 210.3 | 4.3 | +0.0 | 0.0 | 36.7 |
| FOLLOW UP WEIGHED | 0.3 | +46.2 | 0.0 | 0.0 | 1.3 | +302.0 | 0.0 | 0.0 |
| FOUR ROUNDS | 2.7 | +125.5 | 445.7 | 275.0 | 7.0 | +801.3 | 534.0 | 84.0 |
| FREED FROM HIS FIGHT | 2.0 | +0.0 | 0.0 | 0.0 | 11.7 | +0.0 | 0.0 | 159.3 |
| GIVES UP | 0.3 | -15.5 | 0.0 | 84.7 | 1.0 | -20.6 | 132.7 | 0.0 |
| GIVES UP ITS SCREEN | 0.3 | -2.3 | 38.0 | 0.0 | - | - | - | - |
| GOAL WALK | 5.3 | +372.8 | 0.0 | 0.0 | 17.7 | +1402.1 | 0.0 | 156.7 |
| HARD STAY DROPPED | 0.3 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | - | - | - | - | 8.0 | +0.0 | 0.0 | 76.0 |
| HELPER UNSEEN | 0.3 | +0.0 | 38.0 | 0.0 | - | - | - | - |
| HIS CHARGE BY HIS RUN | 12.0 | +0.0 | 0.0 | 254.7 | 10.3 | +0.0 | 0.0 | 404.0 |
| HIS CHARGE DENIED | - | - | - | - | 1.0 | +62.7 | 208.7 | 0.0 |
| HIS CHARGE LIST | 12.3 | +0.0 | 0.0 | 289.7 | 7.7 | +0.0 | 0.0 | 38.0 |
| HIS LEGAL MOVES | 5.0 | +0.0 | 0.0 | 124.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 3.3 | -34.8 | 0.0 | 32.7 | 1.3 | -9.0 | 0.0 | 0.0 |
| HIS MOVE AS HE DECIDES | - | - | - | - | 40.0 | +11.7 | 586.3 | 0.0 |
| HIS MOVE WHY | 30.3 | +0.0 | 0.0 | 396.0 | - | - | - | - |
| HIS ONE MOVE | - | - | - | - | 23.3 | +26.9 | 0.0 | 0.0 |
| HIS ONE QUARTER | 5.3 | +0.0 | 0.0 | 83.3 | 1.3 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 9.7 | +0.0 | 0.0 | 173.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 60.0 | +1281.5 | 0.0 | 599.7 | 32.3 | +184.8 | 0.0 | 318.0 |
| HIS SHOTS BY HIS RUN | 58.3 | +839.5 | 0.0 | 610.7 | 21.7 | +143.3 | 0.0 | 230.0 |
| HIS TURN DENIED | 0.7 | +11.1 | 38.0 | 0.0 | 0.3 | +1.2 | 132.7 | 0.0 |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 14.3 | +0.0 | 0.0 | 65.3 | 14.7 | +0.0 | 0.0 | 380.0 |
| HOLDER ASSIGNMENT | 9.0 | +612.4 | 0.0 | 32.7 | 9.3 | +670.9 | 0.0 | 153.3 |
| HOLDS AMBUSHERS | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HONEST WORTH | 2.0 | -81.9 | 239.3 | 275.0 | 6.3 | -259.5 | 410.0 | 84.0 |
| IDLE COST | 15.0 | -164.7 | 0.0 | 230.7 | - | - | - | - |
| JOINT CHARGE NOW | 0.7 | +44.3 | 76.0 | 190.3 | 2.0 | +128.8 | 186.0 | 0.0 |
| KEPT FROM ITS LAST STOP | 2.3 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 157.3 |
| LANE BY FIGURES | 0.3 | +4.5 | 0.0 | 0.0 | 0.7 | +50.8 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| LEGAL CHARGES ONLY | 4.3 | +0.0 | 175.0 | 690.0 | 11.7 | +0.0 | 954.0 | 209.0 |
| LONE CHARACTER SAFE SPOT | 0.3 | +0.3 | 0.0 | 0.0 | - | - | - | - |
| LONG SHOT | - | - | - | - | 1.3 | +5.6 | 101.3 | 0.0 |
| LOST AFTER ESCAPE | 1.3 | +0.7 | 333.0 | 0.0 | 2.0 | +0.7 | 209.7 | 0.0 |
| LURE BY WHAT IT DRAWS | 0.3 | -14.9 | 0.0 | 0.0 | 0.7 | -29.8 | 0.0 | 0.0 |
| MANOEUVRE | 1.7 | -0.1 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| MARCH BY THE SUM | 0.7 | +94.4 | 0.0 | 0.0 | 0.3 | +46.1 | 0.0 | 0.0 |
| MARCH CHECK | - | - | - | - | 1.7 | +56.7 | 0.0 | 0.0 |
| MARCH OF THE TABLE | 0.3 | +27.3 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 1.0 | -70.3 | 0.0 | 0.0 | 1.7 | +411.6 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 1.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 2.0 | +44.0 | 0.0 | 15.0 | 2.0 | +35.3 | 0.0 | 0.0 |
| MEETS IN TIME | 4.0 | +174.0 | 0.0 | 0.0 | 5.7 | +191.1 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 4.0 | +13.0 | 0.0 | 132.7 | 5.3 | +152.9 | 0.0 | 86.0 |
| MISSILES NEXT TURN | 5.0 | +12.3 | 0.0 | 132.7 | 6.0 | +112.0 | 0.0 | 86.0 |
| MOVE ORDER | 2.3 | +0.0 | 62.0 | 0.0 | 4.7 | +0.0 | 36.7 | 36.7 |
| MOVE SPELL OUT OF RANGE | - | - | - | - | 1.0 | -21.9 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 9.0 | +1069.6 | 0.0 | 222.0 | 7.3 | +696.8 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 9.7 | +365.7 | 0.0 | 165.3 | 7.0 | +304.2 | 0.0 | 78.7 |
| NEXT CHARGE BY LIST | 6.7 | +782.0 | 0.0 | 173.0 | 4.0 | +464.6 | 0.0 | 0.0 |
| NEXT OBJECTIVE NEARER | 0.7 | -12.3 | 0.0 | 0.0 | - | - | - | - |
| NO DOUBLE ROUNDS | 2.3 | -106.0 | 277.3 | 275.0 | 6.0 | -191.8 | 447.0 | 84.0 |
| NO LATE CUT | 1.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | - | - | - | - | 1.0 | -1.9 | 0.0 | 0.0 |
| OFF BEST | 4.0 | -115.4 | 0.0 | 84.7 | 5.0 | -200.5 | 0.0 | 91.3 |
| ONE CHECK AFTER THE LAST CHANGE | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 4.3 | -80.9 | 0.0 | 87.0 | 5.7 | -66.8 | 0.0 | 0.0 |
| ONE JOINT FIGURE | 0.3 | +6.6 | 38.0 | 0.0 | 1.0 | +76.5 | 256.7 | 0.0 |
| ONE OBJECTIVE FORMULA | 4.0 | -94.9 | 0.0 | 32.7 | 2.7 | -13.4 | 0.0 | 0.0 |
| ONE PROMISE A TARGET | 1.0 | -120.7 | 0.0 | 49.0 | - | - | - | - |
| ONE ROUTE | 1.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| OPENS UP | 0.3 | +16.9 | 38.0 | 190.3 | - | - | - | - |
| OVERRUNS AWAY | 1.0 | +9.9 | 116.7 | 0.0 | 1.0 | +1.7 | 25.0 | 42.0 |
| OWN CAST FIRST | 0.3 | -1.5 | 0.0 | 0.0 | - | - | - | - |
| PATHS CROSS | 1.7 | +24.9 | 0.0 | 0.0 | 0.3 | +51.5 | 0.0 | 0.0 |
| PLAN RESULT | 42.0 | +287.3 | 172.0 | 1115.0 | 44.7 | +557.0 | 328.3 | 691.3 |
| PROMISE BELOW ZERO | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE BY ITS OWN SUM | 9.7 | -118.3 | 0.0 | 49.0 | 9.3 | -268.4 | 0.0 | 0.0 |
| PROMISE IN STEPS | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE KNOWS THE FIGHT | 0.3 | -0.6 | 0.0 | 49.0 | 0.7 | -0.2 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | - | - | - | - | 0.7 | -68.5 | 0.0 | 0.0 |
| QUARTER ODDS | 18.3 | +2559.1 | 168.3 | 150.0 | 26.3 | +2739.0 | 91.7 | 210.3 |
| REAL GROUND | 1.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| REDIRECT BY WHAT IT STOPS | - | - | - | - | 1.7 | +11.6 | 0.0 | 0.0 |
| REDIRECT COUNTER | 5.3 | +459.0 | 0.0 | 15.0 | 0.7 | +11.5 | 0.0 | 0.0 |
| REDIRECT FOR A FRIEND IN REACH | 3.7 | +0.0 | 0.0 | 65.0 | 2.3 | +106.1 | 0.0 | 0.0 |
| REDIRECT WEIGHED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| REFORMS TO MEET IT | 1.3 | -32.4 | 0.0 | 49.0 | 1.3 | -56.6 | 0.0 | 0.0 |
| REFUSING RETIRES | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | 0.7 | +16.7 | 0.0 | 49.0 | - | - | - | - |
| RESTRAINS TO SHOOT | - | - | - | - | 0.3 | +2.3 | 0.0 | 42.0 |
| RISK BY ARC | 2.3 | -51.6 | 277.3 | 275.0 | 5.3 | +132.7 | 376.3 | 84.0 |
| RISK ON THE WAY | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| ROUNDS AFTER TERROR | 1.7 | -29.4 | 201.3 | 84.7 | - | - | - | - |
| RUN DOWN | 2.3 | -35.3 | 277.3 | 275.0 | 0.3 | -3.3 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 2.3 | -12.9 | 0.0 | 0.0 | - | - | - | - |
| SEARCH SPOT | 1.3 | +18.0 | 0.0 | 0.0 | 0.7 | +3.1 | 0.0 | 0.0 |
| SECOND LOOK | 0.3 | +104.5 | 0.0 | 84.7 | 0.3 | +0.2 | 0.0 | 0.0 |
| SET CREDITED ONCE | 4.0 | -152.1 | 0.0 | 62.0 | 1.0 | -18.6 | 0.0 | 0.0 |
| SET UP BY THE SET | 4.7 | +229.7 | 0.0 | 62.0 | 1.0 | +38.6 | 0.0 | 0.0 |
| SET-UP ANY TARGET | - | - | - | - | 0.3 | +53.6 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | - | - | - | - | 0.7 | +0.7 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 1.7 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 0.7 | +416.0 | 0.0 | 265.3 | 1.0 | +187.0 | 0.0 | 168.3 |
| SHOT OR CHARGE | - | - | - | - | 0.7 | -11.7 | 25.0 | 0.0 |
| SHOT RISK POINTS | 42.3 | -392.4 | 0.0 | 443.3 | 7.7 | -32.0 | 0.0 | 69.3 |
| SHOTS AFTER THE MOVES | - | - | - | - | 2.7 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | - | - | - | - | 14.7 | +166.2 | 0.0 | 318.0 |
| SPELL SETS UP CHARGE | - | - | - | - | 0.3 | +53.6 | 0.0 | 0.0 |
| SPELL WORTH | 2.0 | +2.2 | 0.0 | 0.0 | 2.3 | +19.7 | 126.7 | 126.7 |
| SPELLS IN THE FIGHT | - | - | - | - | 0.3 | +7.4 | 62.0 | 0.0 |
| SPOT AS THE GAME MOVES | 12.7 | +0.0 | 0.0 | 314.3 | 6.0 | +0.0 | 0.0 | 116.3 |
| STAND AND SHOOT | 1.0 | -13.9 | 74.7 | 190.3 | - | - | - | - |
| STANDS FOR A REASON | 2.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| STANDS STILL | 16.3 | +0.0 | 0.0 | 498.0 | 36.0 | +0.0 | 25.0 | 395.0 |
| STAY WORTH | - | - | - | - | 11.0 | +59.7 | 0.0 | 78.7 |
| STRIKE BY THE ODDS | 0.3 | +22.7 | 0.0 | 0.0 | 0.7 | +1.4 | 0.0 | 0.0 |
| STUBBORN BY POINTS | - | - | - | - | 0.7 | +8.9 | 22.7 | 0.0 |
| STUPIDITY NEXT TURN | 2.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SUPPORT ADDS | 7.7 | +362.5 | 0.0 | 113.3 | 7.7 | +385.2 | 0.0 | 111.0 |
| SUPPORT NARROWED | - | - | - | - | 1.3 | +0.0 | 208.7 | 0.0 |
| SUPPORT WORKED OUT | 7.7 | +362.5 | 0.0 | 113.3 | 7.7 | +385.2 | 0.0 | 111.0 |
| THE DEARER SUM KEEPS ITS PLAN | 1.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 41.7 |
| THE PROMISE ADDS | - | - | - | - | 1.0 | -111.4 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 3.3 | +0.0 | 0.0 | 62.0 | 4.0 | +0.0 | 0.0 | 78.3 |
| THE ROW KEEPS ITS WAY | 5.3 | +0.0 | 0.0 | 49.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 3.7 | +0.0 | 0.0 | 49.0 | - | - | - | - |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 42.0 | +0.0 | 0.0 | 386.3 | 43.3 | +0.0 | 0.0 | 359.7 |
| TIED UP BY THE SUM | 1.7 | +218.2 | 239.3 | 275.0 | 2.3 | +302.6 | 74.0 | 84.0 |
| TIME ON OUR SIDE | - | - | - | - | 45.3 | +462.6 | 0.0 | 394.3 |
| WAITS AGAIN | 0.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| WHO FIGHTS | 0.7 | -6.2 | 38.0 | 0.0 | 2.7 | -15.8 | 139.0 | 0.0 |
| WHO HITS BACK | 1.0 | +86.4 | 0.0 | 25.0 | - | - | - | - |
| WHOLE FIGHT DANGER | 1.0 | -95.8 | 0.0 | 98.0 | 4.7 | -585.9 | 0.0 | 404.0 |
| WHOLE FIGHT GAIN | 0.3 | +18.7 | 38.0 | 0.0 | 0.7 | +25.5 | 62.0 | 0.0 |
| WOUNDED STAYS OUT | - | - | - | - | 0.3 | +0.0 | 25.0 | 42.0 |
| WOUNDS ON THE RANKS | 5.0 | +171.8 | 0.0 | 0.0 | 2.7 | +41.7 | 0.0 | 0.0 |

### Rule changes: csame-bb45c30-p48

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 184 | 184 | 114 | 38.00 | +2310 | +20.3 |
| HIS MOVE AS HE DECIDES | 120 | 120 | 85 | 28.33 | +0 | +0.0 |
| HIS MOVE WHY | 91 | 91 | 61 | 20.33 | +0 | +0.0 |
| HOLDER ASSIGNMENT | 55 | 55 | 48 | 16.00 | +2958 | +61.6 |
| LEGAL CHARGES ONLY | 48 | 48 | 48 | 16.00 | +0 | +0.0 |
| HIS SHOTS BY HIS RUN | 240 | 234 | 37 | 12.33 | +322 | +8.7 |
| FIVE ACTION | 515 | 497 | 36 | 12.00 | +1456 | +40.5 |
| HIS SHOT LIST | 277 | 268 | 36 | 12.00 | +92 | +2.6 |
| DEPLOY BY FIGURES | 51 | 51 | 35 | 11.67 | +412 | +11.8 |
| THE TABLE AGAIN | 36 | 36 | 31 | 10.33 | +0 | +0.0 |
| OFF BEST | 27 | 27 | 27 | 9.00 | -947 | -35.1 |
| MOVE TO CHARGE COMPUTED | 49 | 45 | 26 | 8.67 | +1959 | +75.3 |
| MOVE ORDER | 21 | 21 | 21 | 7.00 | +0 | +0.0 |
| HIS ONE MOVE | 70 | 67 | 18 | 6.00 | +0 | +0.0 |
| TIME ON OUR SIDE | 136 | 107 | 18 | 6.00 | +59 | +3.3 |
| NEXT CHARGE BY LIST | 32 | 31 | 17 | 5.67 | +1732 | +101.9 |
| PROMISE BY ITS OWN SUM | 57 | 57 | 17 | 5.67 | -1160 | -68.3 |
| QUARTER ODDS | 134 | 129 | 17 | 5.67 | +1268 | +74.6 |
| GOAL WALK | 69 | 67 | 16 | 5.33 | +748 | +46.7 |
| SUPPORT ADDS | 46 | 44 | 16 | 5.33 | +301 | +18.8 |
| SUPPORT WORKED OUT | 46 | 44 | 16 | 5.33 | +301 | +18.8 |
| REDIRECT FOR A FRIEND IN REACH | 18 | 18 | 15 | 5.00 | +4 | +0.3 |
| FOUR ROUNDS | 29 | 27 | 14 | 4.67 | +635 | +45.4 |
| SHOT RISK POINTS | 150 | 142 | 13 | 4.33 | +156 | +12.0 |
| ADVANCE LANE KEPT | 11 | 11 | 11 | 3.67 | +0 | +0.0 |
| IDLE COST | 45 | 33 | 9 | 3.00 | +29 | +3.3 |
| MEETS IN TIME | 29 | 29 | 9 | 3.00 | +409 | +45.5 |
| TIED UP BY THE SUM | 12 | 11 | 9 | 3.00 | +548 | +60.8 |
| CHAFF IN THE MOVE | 16 | 16 | 8 | 2.67 | +8 | +1.0 |
| JOINT CHARGE NOW | 8 | 8 | 8 | 2.67 | +519 | +64.9 |
| HARD STAY DROPPED | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| PATHS CROSS | 6 | 6 | 6 | 2.00 | +229 | +38.2 |
| CHARGE NOW FIRST | 11 | 11 | 5 | 1.67 | -463 | -92.6 |
| COVER ONCE | 58 | 30 | 5 | 1.67 | +79 | +15.8 |
| FOLLOW UP WEIGHED | 5 | 5 | 5 | 1.67 | +1045 | +209.0 |
| SHOOTS FROM THE BEST SPOT | 5 | 5 | 5 | 1.67 | +82 | +16.4 |
| WOUNDS ON THE RANKS | 23 | 23 | 5 | 1.67 | +91 | +18.1 |
| CASTS FROM BEHIND | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| CHARGE LOSSES | 90 | 83 | 4 | 1.33 | +487 | +121.8 |
| RISK BY ARC | 23 | 21 | 4 | 1.33 | +77 | +19.2 |
| SEARCH SPOT | 6 | 6 | 4 | 1.33 | +63 | +15.8 |
| ASSAILMENT BY POINTS | 3 | 3 | 3 | 1.00 | +11 | +3.7 |
| CHALLENGE BY POINTS | 3 | 3 | 3 | 1.00 | +293 | +97.8 |
| COMBAT PIVOT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| HONEST WORTH | 25 | 23 | 3 | 1.00 | +69 | +23.1 |
| LANE BY FIGURES | 3 | 3 | 3 | 1.00 | +166 | +55.2 |
| MARCH BY THE SUM | 3 | 3 | 3 | 1.00 | +422 | +140.6 |
| MAX FOR POSITIONING | 12 | 9 | 3 | 1.00 | +7 | +2.3 |
| NEARER NOT NEEDED | 50 | 48 | 3 | 1.00 | +113 | +37.8 |
| ONE PROMISE A TARGET | 3 | 3 | 3 | 1.00 | -362 | -120.8 |
| SCREEN BY WHAT IT SAVES | 7 | 7 | 3 | 1.00 | +8 | +2.7 |
| STRIKE BY THE ODDS | 3 | 3 | 3 | 1.00 | +72 | +24.1 |
| SUPPORT NARROWED | 4 | 4 | 3 | 1.00 | -118 | -39.2 |
| WHO HITS BACK | 3 | 3 | 3 | 1.00 | +192 | +64.0 |
| CASTING BLOCK | 2 | 2 | 2 | 0.67 | +38 | +18.8 |
| CHAFF PASSED | 2 | 2 | 2 | 0.67 | -0 | -0.1 |
| FALLS SHORT | 67 | 57 | 2 | 0.67 | +36 | +18.2 |
| HOLDS AMBUSHERS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| PROMISE KNOWS THE FIGHT | 3 | 3 | 2 | 0.67 | -2 | -1.2 |
| REDIRECT COUNTER | 18 | 17 | 2 | 0.67 | +96 | +48.2 |
| RESERVE FALL BACK | 2 | 2 | 2 | 0.67 | +50 | +25.0 |
| SECOND LOOK | 2 | 2 | 2 | 0.67 | +314 | +157.1 |
| SET UP BY THE SET | 17 | 17 | 2 | 0.67 | +196 | +98.1 |
| SHOOTERS IN TWO RANKS | 2 | 2 | 2 | 0.67 | +2 | +1.0 |
| STUBBORN BY POINTS | 2 | 2 | 2 | 0.67 | +27 | +13.3 |
| AFTERMATH IN POINTS | 1 | 1 | 1 | 0.33 | +668 | +668.1 |
| CAST JOB | 5 | 5 | 1 | 0.33 | +0 | +0.0 |
| CASTER AWAY FROM SCREEN | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CHARGE LIST READ AGAIN | 1 | 1 | 1 | 0.33 | +266 | +265.8 |
| EDGE GIVE GROUND | 2 | 1 | 1 | 0.33 | +11 | +11.1 |
| EXACT ROUND | 22 | 21 | 1 | 0.33 | +6 | +5.9 |
| FALL BACK GOOD ORDER | 16 | 15 | 1 | 0.33 | +43 | +43.2 |
| FIRE AND FLEE | 1 | 1 | 1 | 0.33 | +10 | +10.4 |
| HIS CHARGE DENIED | 3 | 3 | 1 | 0.33 | +6 | +5.9 |
| LONG SHOT | 4 | 3 | 1 | 0.33 | +5 | +5.1 |
| MARCH CHECK | 5 | 5 | 1 | 0.33 | +11 | +10.8 |
| MARCH OF THE TABLE | 1 | 1 | 1 | 0.33 | -82 | -81.8 |
| ONE JOINT FIGURE | 4 | 4 | 1 | 0.33 | +25 | +24.8 |
| ONE OBJECTIVE FORMULA | 20 | 19 | 1 | 0.33 | +49 | +49.0 |
| OWN CAST FIRST | 1 | 1 | 1 | 0.33 | -5 | -4.6 |
| REDIRECT BY WHAT IT STOPS | 5 | 5 | 1 | 0.33 | +4 | +4.0 |
| REDIRECT WEIGHED | 1 | 1 | 1 | 0.33 | +63 | +62.7 |
| RESTRAINS TO SHOOT | 1 | 1 | 1 | 0.33 | +7 | +7.0 |
| SHOTS AFTER THE MOVES | 8 | 8 | 1 | 0.33 | +0 | +0.0 |
| STAY WORTH | 33 | 25 | 1 | 0.33 | +13 | +12.8 |
| THE ROW IN ITS ORDER | 22 | 1 | 1 | 0.33 | +0 | +0.0 |
| WHOLE FIGHT GAIN | 3 | 3 | 1 | 0.33 | +73 | +73.0 |
| BACKUP TARGETS | 2 | not checked | - | - | - | - |
| CARRIES OUT SET-UP | 1 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 6 | trace | - | - | - | - |
| CHARACTER GUNS | 10 | 8 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 66 | 63 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 10 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 3 | 3 | 0 | 0.00 | - | - |
| FALLBACK BY WORTH | 2 | 2 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 9 | 9 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 4 | 2 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 34 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 41 | 39 | 0 | 0.00 | - | - |
| GIVES UP | 4 | 3 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 1 | 1 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 24 | 22 | 0 | 0.00 | - | - |
| HELPER UNSEEN | 1 | 1 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 67 | 63 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 60 | 58 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 24 | 22 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 14 | 14 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 20 | 19 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 36 | 34 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 3 | 3 | 0 | 0.00 | - | - |
| HIS TURN RUN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 87 | 86 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 20 | 19 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 1 | 1 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 1 | not checked | - | - | - | - |
| LOST AFTER ESCAPE | 10 | 9 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 3 | 3 | 0 | 0.00 | - | - |
| MANOEUVRE | 7 | 7 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 8 | 8 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 7 | 7 | 0 | 0.00 | - | - |
| MISSILES IN THE MOVE | 28 | 18 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 33 | 24 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 3 | trace | - | - | - | - |
| NEXT OBJECTIVE NEARER | 2 | 2 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 25 | 23 | 0 | 0.00 | - | - |
| NO LATE CUT | 7 | 7 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 18 | 18 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 3 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 4 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 30 | 14 | 0 | 0.00 | - | - |
| ONE ROUTE | 7 | 7 | 0 | 0.00 | - | - |
| OPENS UP | 1 | 1 | 0 | 0.00 | - | - |
| OVERRUNS AWAY | 6 | 5 | 0 | 0.00 | - | - |
| PLAN RESULT | 260 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE IN STEPS | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE READS THE TABLE | 2 | 2 | 0 | 0.00 | - | - |
| REAL GROUND | 7 | 7 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 8 | 7 | 0 | 0.00 | - | - |
| REFUSING RETIRES | 1 | 1 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 4 | 4 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 5 | 4 | 0 | 0.00 | - | - |
| RUN DOWN | 8 | 6 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 15 | 15 | 0 | 0.00 | - | - |
| SET-UP ANY TARGET | 1 | not checked | - | - | - | - |
| SHOOTERS ON THE TABLE | 16 | not checked | - | - | - | - |
| SHOT OR CHARGE | 2 | 2 | 0 | 0.00 | - | - |
| SHOTS IN THE MOVE | 44 | 28 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 1 | not checked | - | - | - | - |
| SPELL WORTH | 13 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 56 | 49 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 3 | 3 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 6 | 6 | 0 | 0.00 | - | - |
| STANDS STILL | 157 | 152 | 0 | 0.00 | - | - |
| STUPIDITY NEXT TURN | 8 | 7 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 7 | not checked | - | - | - | - |
| THE PROMISE ADDS | 3 | 3 | 0 | 0.00 | - | - |
| THE ROW KEEPS ITS WAY | 17 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 11 | not checked | - | - | - | - |
| THE TABLE BINDS | 256 | not checked | - | - | - | - |
| WAITS AGAIN | 6 | 6 | 0 | 0.00 | - | - |
| WHO FIGHTS | 10 | 10 | 0 | 0.00 | - | - |
| WHOLE FIGHT DANGER | 17 | 16 | 0 | 0.00 | - | - |
| WOUNDED STAYS OUT | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: csame-bb45c30-p48

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 3.33 | 4.00 | 28.1 |
| ARMY TABLE | rule | 1.33 | 4.33 | 68.4 |
| PROMISE BY ITS OWN SUM | rule | 1.67 | 4.00 | 68.3 |
| CHARGE NOW FIRST | rule | 0.67 | 1.00 | 92.6 |
| HOLDER ASSIGNMENT | rule | 0.67 | 0.33 | 1.1 |
| ONE PROMISE A TARGET | rule | 1.00 | - | 120.8 |
| RULE SWITCHED OFF | gate | 0.67 | 0.33 | 29.4 |
| SUPPORT NARROWED | rule | - | 1.00 | 39.2 |
| AFTERMATH NEEDS NEXT CHARGE | gate | - | 0.67 | 120.3 |
| JOINT CHARGE NOW | rule | - | 0.67 | 21.4 |
| PROMISE KNOWS THE FIGHT | rule | 0.33 | 0.33 | 1.2 |
| MARCH OF THE TABLE | rule | 0.33 | - | 81.8 |
| OWN CAST FIRST | rule | 0.33 | - | 4.6 |

### Plans: csame-bb45c30-p48

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 2.3 | 71% | 174 | 287 | 165% |
| Mine | join | 4.3 | 100% | 195 | 0 | 0% |
| Mine | move | 34.0 | 94% | 2049 | 0 | 0% |
| Mine | shoot | 0.3 | 0% | 0 | 0 | - |
| Mine | support | 1.0 | 100% | 14 | 0 | 0% |
| Opponent | charge | 5.7 | 59% | 968 | 512 | 53% |
| Opponent | move | 36.7 | 95% | 2471 | 0 | 0% |
| Opponent | shoot | 1.0 | 67% | 101 | 45 | 44% |
| Opponent | support | 1.3 | 100% | 73 | 0 | 0% |

### Battle groups: csame-bb45c30-p48

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 5.3 | 44% | 57% | 0% | - | 57% | 0% | 0% | 43% | 0% |
| Opponent | REDIRECT COUNTER | 0.7 | 0% | - | - | - | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: csame-bb45c30-p48

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 9 | 74 (9) | 42 | 32 | 46 | 44% | 4.0 | 96 (7) | 0 (1) | 0 (1) | 84 (8) | 0 (1) |
| Mine | Character | 10 | 81 (10) | 81 | 0 | 41 | 30% | 3.7 | 26 (5) | 130 (4) | - | 27 (4) | 125 (5) |
| Mine | Clean-up | 1 | 0 (1) | 0 | 0 | 100 | 0% | 2.0 | 0 (1) | - | - | 0 (1) | - |
| Mine | Fast Hammer | 8 | 5 (8) | 0 | 5 | 44 | 25% | 3.7 | 4 (2) | 0 (4) | 16 (2) | 0 (1) | 6 (7) |
| Mine | Hammer | 2 | 94 (2) | 0 | 94 | 46 | 50% | 3.0 | 173 (1) | 0 (1) | - | 173 (1) | 0 (1) |
| Mine | Holder | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Mine | Support | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | 0 (1) | - | - | - | 0 (1) |
| Mine | Wizard | 4 | 0 (4) | 0 | 0 | 39 | 0% | 1.2 | 0 (3) | - | 0 (1) | 0 (2) | 0 (2) |
| Opponent | Chaff | 2 | 0 (2) | 0 | 0 | 0 | 100% | - | 0 (2) | - | - | 0 (2) | - |
| Opponent | Character | 7 | 76 (7) | 76 | 0 | 28 | 0% | 1.1 | 40 (5) | 220 (1) | 0 (1) | 3 (3) | 112 (4) |
| Opponent | Clean-up | 2 | 83 (2) | 0 | 83 | 0 | 0% | 2.5 | 167 (1) | 0 (1) | - | 167 (1) | 0 (1) |
| Opponent | Fast Hammer | 5 | 33 (5) | 7 | 27 | 34 | 0% | 1.4 | 57 (2) | 0 (2) | 36 (1) | 57 (2) | 13 (3) |
| Opponent | Hammer | 11 | 42 (11) | 42 | 0 | 29 | 55% | 2.8 | 0 (3) | 88 (6) | 0 (2) | 127 (2) | 27 (9) |
| Opponent | Shooter | 8 | 26 (8) | 0 | 26 | 61 | 0% | 1.4 | 21 (2) | 37 (5) | 0 (1) | 16 (3) | 30 (5) |
| Opponent | Wizard | 1 | 0 (1) | 0 | 0 | 100 | 0% | 2.0 | - | - | - | - | - |

### Charged fights: csame-bb45c30-p48

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Vampire Counts | 2 | 0 | 174 | 1.0 | 1.0 | 174 | 286 | -111 | 1 of 2 | 1 of 2 | - | -111 |
| Mine | Warriors of Chaos | 1 | 0 | 999 | 4.0 | 1.0 | 250 | 0 | +250 | 2 of 4 | 4 of 4 | - | +250 |
| **Mine** | all armies | 3 | 0 | 449 | 2.0 | 1.0 | 225 | 95 | +130 | 3 of 6 | 5 of 6 | - | +130 |
| Opponent | Wood Elf Realms | 3 | 0 | 617 | 5.7 | 1.1 | 109 | 49 | +60 | 4 of 17 | 11 of 17 | +186 | +52 |

### Effective charges: csame-bb45c30-p48

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Vampire Counts | 2 | 0 | 0 | 0 | 0 | 1 (net +349) | 0 | 1 | 0% (0 of 1) |
| Mine | Warriors of Chaos | 4 | 0 | 0 | 1 (net +505) | 1 (net +0) | 0 | 2 (net +247) | 0 | 25% (1 of 4) |
| Opponent | Wood Elf Realms | 17 | 3 (net +400) | 0 | 0 | 2 (net +0) | 2 (net +111) | 6 (net +34) | 4 | 0% (0 of 13) |

### Charged fights, damage counted: csame-bb45c30-p48

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Effective (55-75%) | 1 | 285 | 405 | +505 | 505 | 0 | +505 | +177.2 |
| Mine | 76-89% | 1 | 285 | 208 | +0 | 0 | 0 | +0 | +0.0 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 382 | 222 | +247 | 247 | 0 | +247 | +64.7 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 471 | 110 | +349 | 412 | 0 | +412 | +87.4 |
| Mine | No odds | 1 | 471 | 499 | -571 | 0 | 571 | -571 | -121.2 |
| Mine | All fights | 6 | 379 | 278 | +130 | 235 | 95 | +140 | +36.9 |
| Opponent | Long shot (under 50%) | 3 | 367 | 255 | +400 | 400 | 6 | +394 | +107.5 |
| Opponent | 76-89% | 2 | 114 | 150 | +0 | 0 | 0 | +0 | +0.0 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 6 | 161 | 105 | +34 | 65 | 40 | +25 | +15.2 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 2 | 499 | 111 | +111 | 111 | 0 | +111 | +22.2 |
| Opponent | No odds | 4 | 53 | 341 | -154 | 50 | 178 | -128 | -240.3 |
| Opponent | All fights | 17 | 206 | 193 | +60 | 118 | 57 | +61 | +29.6 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| csame-bb45c30-p48 | move | 17 | 3 (18%) | 3 (18%) | 4 (24%) | 10 (59%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L2535, L2735 |
| Horn of the Wild Hunt | Opponent | L3033 |
| Invocation of Nehek | Mine | L2535, L2735 |
| Ring of Doom | Opponent | L3033 |

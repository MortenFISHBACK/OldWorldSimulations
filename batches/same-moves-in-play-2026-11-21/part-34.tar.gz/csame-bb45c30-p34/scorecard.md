# Doctrine scorecard: csame-bb45c30-p34

### Scorecard: csame-bb45c30-p34

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L1823 | 5 | 1 | Mine | yes | - | - | 2 | 3 | 0 | 0 | 0 | 0 |
| L1823 | 5 | 1 | Opponent | yes | - | 1 | 5 | 2 | 1 | 0 | 0 | 130 |
| L1923 | 3 | 1 | Mine | no | 2 | 1 | 7 | 0 | 0 | 0 | 0 | 0 |
| L1923 | 3 | 1 | Opponent | yes | 6 | 2 | 4 | 0 | 0 | 0 | 0 | 0 |
| L2025 | 3 | 1 | Mine | yes | 4 | - | 0 | 0 | 0 | 0 | 0 | 420 |
| L2025 | 3 | 1 | Opponent | no | 3 | 2 | 6 | 2 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 67% | 3.0 | 1.0 | 3.0 | 1.0 | 0.0 | 0.0 | 0.0 | 140.0 |
| **Average** | | | Opponent | 67% | 4.5 | 1.7 | 5.0 | 1.3 | 0.3 | 0.0 | 0.0 | 43.3 |

### KPIs: csame-bb45c30-p34

Rules off - Opponent only: NO OLD ONE-MOVE GUESS; both sides: ONE RUN A PLAN.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 12) | 7% (1 of 14) | 4% (1 of 26) |
| Winner chose to follow up after the loser gave ground |  | 91% (10 of 11); on the table 91% | 86% (6 of 7); on the table 86% | 89% (16 of 18); on the table 89% |
| Winner chose to pursue after the loser fell back in good order |  | - | - | - |
| Winner chose to pursue after the loser fled |  | - | 100% (1 of 1); on the table 100% | 100% (1 of 1); on the table 100% |
| Winner chose to follow up or pursue (all three) |  | 91% (10 of 11); on the table 91% | 88% (7 of 8); on the table 88% | 89% (17 of 19); on the table 89% |
| Magic missiles tried each own turn | 50%+ | 17% (5 of 30) | 39% (7 of 18) | 25% (12 of 48) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 24% (5 of 21) | 39% (7 of 18) | 31% (12 of 39) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 17% (1 of 6) | - | 17% (1 of 6) |
| Points that never fought | lower | 14% (861 of 5999) | 34% (2041 of 5999) | 24% (2902 of 11998) |
|   infantry points that never fought | lower | 55% (549 of 993) | 44% (457 of 1037) | 50% (1006 of 2030) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 50% (11 of 22) | 69% (11 of 16) | 58% (22 of 38) |
| Bound items with a magic missile used (at least once a game) |  | 100% (1 of 1); 1.3 uses a game | 0.0 uses a game | 100% (1 of 1); 0.7 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 100% (2 of 2); 0.7 uses a game | 0.0 uses a game | 100% (2 of 2); 0.3 uses a game |
|   their share of the points of units over 100 pts | lower | 54% (2794 of 5151) | 61% (2750 of 4500) | 57% (5544 of 9651) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.3 (16%) | 3.7 (100%) | 5.0 (42%) |
| MARCHED: its unit marched | 1.3 (16%) | 0.0 (0%) | 1.3 (11%) |
| CHARGED: its unit charged | 0.7 (8%) | 0.0 (0%) | 0.7 (6%) |
| IN COMBAT: engaged in combat | 1.3 (16%) | 0.0 (0%) | 1.3 (11%) |
| REAR RANK: in a rear rank | 0.7 (8%) | 0.0 (0%) | 0.7 (6%) |
| GONE: slain | 1.7 (20%) | 0.0 (0%) | 1.7 (14%) |
| NOT OFFERED: not in the cast list | 1.3 (16%) | 0.0 (0%) | 1.3 (11%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 2.0 | 1.3 | 1.3 | 4.0 | 1.0 |
| not cast | 8.0 | 0.7 | 4.7 | 12.0 | 19.0 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.0 (5%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.7 (100%) | 0.0 (0%) | 5.0 (42%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.3 (11%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (6%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.3 (11%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 2.0 (25%) | 0.0 (0%) | 2.0 (43%) | 0.7 (6%) | 0.0 (0%) |
| GONE: slain | 2.3 (29%) | 0.0 (0%) | 0.0 (0%) | 1.7 (14%) | 2.0 (11%) |
| OFF THE TABLE: off the table or not arrived | 0.3 (4%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (2%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.3 (11%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 3.3 (42%) | 0.0 (0%) | 2.7 (57%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 15.7 (82%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.0 a game | 1.3 a game | 0.7 a game |
| stood (cast and not dispelled) | - | 100% (4 of 4) | 100% (4 of 4) |
| the unit moved after it | - | 100% (4 of 4) | 100% (4 of 4) |
| it charged on its next turn | - | 0% (0 of 4) | 0% (0 of 4) |
| the enemy charged it first | - | 0% (0 of 4) | 0% (0 of 4) |
| it fought by the end of its next turn | - | 0% (0 of 4) | 0% (0 of 4) |
| it moved out of a charge the enemy had planned (not charged first) | - | 0% (0 of 4) | 0% (0 of 4) |
| none of these (no charge, no fight, no charge escaped) | - | 100% (4 of 4) | 100% (4 of 4) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 54% (32 of 59) | 62% (42 of 68) | 58% (74 of 127) |
|   cavalry | - | 94% (15 of 16) | 94% (15 of 16) |
|   character | 100% (6 of 6) | 0% (0 of 16) | 27% (6 of 22) |
|   chariot | 73% (8 of 11) | - | 73% (8 of 11) |
|   infantry | 39% (14 of 36) | 75% (27 of 36) | 57% (41 of 72) |
|   monster | 67% (4 of 6) | - | 67% (4 of 6) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.3 (26%) | 0.0 (0%) | 2.3 (13%) |
| CHARGED: it charged | 0.0 (0%) | 1.7 (19%) | 1.7 (9%) |
| IN COMBAT: it fought this turn or the last | 0.7 (7%) | 1.7 (19%) | 2.3 (13%) |
| NO TARGET IN RANGE | 3.7 (41%) | 2.3 (27%) | 6.0 (34%) |
| ONLY IN COMBAT: the only targets were in combat | 0.3 (4%) | 1.3 (15%) | 1.7 (9%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.3 (15%) | 1.7 (19%) | 3.0 (17%) |
| SHELTERED: the target was sheltered | 0.3 (4%) | 0.0 (0%) | 0.3 (2%) |
| OTHER BAR | 0.3 (4%) | 0.0 (0%) | 0.3 (2%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 6.0 | 1.3 | 78% | 3.6 pts | 21 pts |
| character | 2.3 | 1.0 | 71% | 12.6 pts | 29 pts |
| chariot | 3.0 | 2.0 | 67% | 18.6 pts | 56 pts |
| infantry | 15.3 | 8.0 | 57% | 6.1 pts | 93 pts |
| monster | 1.7 | 0.0 | 100% | 0.0 pts | 0 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.0 | 6.7 | 4.8 |
| Charges that made contact a game | 2.3 | 5.0 | 3.7 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.00 declared, 0.00 contact (1 units) | 0.00 declared, 0.00 contact (2 units) | 0.00 declared, 0.00 contact (3 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 4.00 declared, 3.00 contact (1 units) | 4.00 declared, 3.00 contact (1 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.32 declared, 0.25 contact (28 units) | 0.53 declared, 0.40 contact (30 units) | 0.43 declared, 0.33 contact (58 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | - | 67% (2 of 3) | - | 67% (2 of 3) |
| Character in a unit | 40% (2 of 5) | 100% (2 of 2) | - | 57% (4 of 7) |
| Character on its own | - | 50% (1 of 2) | 43% (3 of 7) | 44% (4 of 9) |
| Chariot | 50% (1 of 2) | - | - | 50% (1 of 2) |
| Infantry | 50% (3 of 6) | - | - | 50% (3 of 6) |
| Monster | 50% (2 of 4) | 67% (2 of 3) | - | 57% (4 of 7) |
| Monstrous | - | 100% (4 of 4) | - | 100% (4 of 4) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Ogre Kingdoms | 1 | 100% (2 of 2); on the table 100% | 0% (0 of 6) | 19% | 71% (5 of 7) | 100% (1 of 1); 4.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 1 | 100% (4 of 4); on the table 100% | 25% (3 of 12) | 3% | 50% (4 of 8) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Skaven | 1 | 80% (4 of 5); on the table 80% | 17% (2 of 12) | 22% | 29% (2 of 7) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Tomb Kings of Khemri | 2 | 86% (6 of 7); on the table 86% | 0% (0 of 6) | 28% | 60% (6 of 10) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 1 | 100% (1 of 1); on the table 100% | 58% (7 of 12) | 46% | 83% (5 of 6) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (csame-bb45c30-p34, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 69% (9) | 100% (2) | 73% (11) |
| ...free all their last turn and able to turn (per game) | 2.67 | 0.67 | 3.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 2.00 | 0.33 | 2.33 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: csame-bb45c30-p34

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.7 | 2.3 |
| Strategy | Charge objectives carried out (made contact) | 100% (2 of 2) | 56% (10 of 18) |
| Strategy | Shoot objectives carried out (shot that target) | 44% (8 of 18) | 64% (14 of 22) |
| Strategy | Support requests answered (helper made contact too) | - | 0% (0 of 2) |
| Strategy | Hexes on a unit its side charged or shot that turn | - | 0% (0 of 2) |
| Strategy | Joined characters whose unit fought | 100% (6 of 6) | 0% (0 of 2) |
| Strategy | Lone characters that fought | 100% (4 of 4) | 67% (6 of 9) |
| Movement | Charges halted short of contact | 0.3 | 0.3 |
| Movement | Idle units | 1.0 | 1.3 |
| Movement | Points that never moved of their own | 140.0 | 43.3 |
| Movement | Fights charged into per game | 2.3 | 5.0 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 2 | 2 of 13, net -224 |
| Movement | Charges with odds: sweet spot (55-75%) | 1 of 2, net +66 | 2 of 13, net -343 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 2 | 0 of 13 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 0 of 2 | 7 of 13, net +189 |
| Shooting | Shots by shooting units (incl. breath weapons) | 11.3 | 16.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 50% (17 of 34) | 17% (8 of 48) |
| Shooting | Points destroyed by shooting units | 38.3 | 49.7 |
| Shooting | Points destroyed by war machines | 23.3 | 0.0 |
| Magic | Magic missiles cast | 1.3 | 2.0 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 25% (1 of 4) | 0% (0 of 6) |
| Magic | Wounds caused by magic missiles | 0.7 | - |
| Magic | Points destroyed by magic (all spells) | 0.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.3 / 0.0 / 0.7 / 0.0 | 0.7 / 0.7 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 705.3 | 597.7 |
| Combat | Points run down | 0.0 | 78.3 |
| Combat | Net points per charged fight, damage counted | +147 | +77 |
| Combat | Net per 100 charger points, damage counted | +65.7 | +25.7 |
| Combat | First round won (charged fights) | 86% | 73% |
| Combat | Net points per charged fight | +140 | +77 |
| Combat | Net points per supported fight / lone fight | - / +140 | - / +77 |
| Combat | Charged fights on a top-3 enemy unit | 2 of 7 | 6 of 15 |
| Game | Points lost | 760.7 | 793.7 |
| Game | VP from objectives | 710.0 | 736.7 |
| Game | Lone holders (player turns) | 3.0 | 4.5 |

- Mine won / drew / lost: 1 / 1 / 1 of 3 ended games (of 3); mean margin (Mine - Opponent) -183 VP
- The side that went first won 0 of 2 games with a winner
- Points traded per game (both sides' losses): 1554
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: csame-bb45c30-p34

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.3 | +24.0 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | 22.7 | +418.7 | 0.0 | 437.3 | 14.0 | +277.5 | 0.0 | 371.7 |
| ASSAILMENT BY POINTS | 0.3 | +0.6 | 0.0 | 0.0 | - | - | - | - |
| BACKUP TARGETS | 1.0 | +6.2 | 0.0 | 0.0 | - | - | - | - |
| BLOWS WHERE AIMED | - | - | - | - | 0.3 | -7.9 | 0.0 | 0.0 |
| CAST JOB | 0.7 | +21.4 | 0.0 | 0.0 | 2.3 | +24.9 | 0.0 | 0.0 |
| CASTER AWAY FROM SCREEN | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.7 | +6.9 | 44.0 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | - | - | - | - | 0.3 | +15.0 | 0.0 | 15.0 |
| CHALLENGE BY POINTS | 0.3 | +8.7 | 0.0 | 0.0 | 0.7 | +1.9 | 0.0 | 143.7 |
| CHAMPION KNOWS CHALLENGE | - | - | - | - | 0.3 | -2.8 | 0.0 | 84.7 |
| CHARGE LOSSES | 14.7 | -1224.3 | 0.0 | 1088.3 | 6.0 | -427.4 | 0.0 | 195.0 |
| CHARGE NOW FIRST | 1.0 | +0.0 | 44.0 | 0.0 | 4.7 | +0.0 | 753.0 | 81.7 |
| CLOSES ON WHAT IT BEATS | 8.7 | +0.0 | 0.0 | 105.0 | 15.3 | +0.0 | 0.0 | 137.3 |
| COMBAT PIVOT | 0.7 | +0.0 | 65.0 | 131.7 | 1.7 | +0.0 | 96.0 | 168.7 |
| CONTINUE AHEAD WEIGHED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | - | - | - | - | 1.0 | +25.6 | 0.0 | 0.0 |
| COVER ONCE | 15.0 | -868.2 | 0.0 | 394.0 | 3.7 | -98.5 | 0.0 | 208.7 |
| DENIED BY THE FIGHT | - | - | - | - | 1.7 | -18.3 | 178.3 | 0.0 |
| DEPLOY BY FIGURES | 7.7 | +43.1 | 0.0 | 0.0 | 7.3 | +33.6 | 0.0 | 23.3 |
| DUEL STOPS AT THE KILL | - | - | - | - | 0.3 | -72.6 | 0.0 | 0.0 |
| ELIXIR WORTH | 0.3 | +23.9 | 0.0 | 0.0 | - | - | - | - |
| EXACT ROUND | - | - | - | - | 4.7 | +95.4 | 1109.7 | 0.0 |
| FALL BACK GOOD ORDER | 0.3 | +0.0 | 22.0 | 0.0 | 6.0 | +8.5 | 1167.7 | 101.3 |
| FALLS SHORT | 3.3 | +69.4 | 0.0 | 181.7 | 17.3 | +148.9 | 0.0 | 37.0 |
| FEATURE BUFFS | 1.3 | +8.3 | 0.0 | 0.0 | 1.0 | +10.6 | 0.0 | 44.0 |
| FIGHT TO THE END | - | - | - | - | 4.0 | +11.4 | 592.0 | 81.7 |
| FIRE IN ORDER | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| FIVE ACTION | 81.7 | +6307.6 | 596.3 | 1736.0 | 86.7 | +6861.5 | 1840.0 | 1694.7 |
| FLANK NOT WEIGHED | 17.3 | +0.0 | 0.0 | 601.7 | 4.0 | +0.0 | 0.0 | 233.7 |
| FOLLOW UP WEIGHED | 1.3 | +82.9 | 0.0 | 0.0 | 1.7 | +534.9 | 0.0 | 0.0 |
| FOUR ROUNDS | 0.7 | +9.1 | 44.0 | 0.0 | 6.7 | +635.8 | 1187.7 | 166.3 |
| FREED FROM HIS FIGHT | 17.7 | +0.0 | 0.0 | 508.0 | 3.7 | +0.0 | 0.0 | 47.0 |
| FRIEND SHOOTS FIRST | 1.3 | -8.7 | 0.0 | 0.0 | 4.0 | -8.9 | 156.0 | 0.0 |
| GIVES UP | - | - | - | - | 0.7 | -8.2 | 78.3 | 0.0 |
| GOAL WALK | 11.3 | +690.5 | 0.0 | 241.3 | 5.7 | +555.2 | 0.0 | 50.0 |
| GUN FIGURES | 3.0 | +59.8 | 15.0 | 0.0 | - | - | - | - |
| HARD STAY DROPPED | 1.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 12.0 | +0.0 | 0.0 | 344.7 | 1.3 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 12.7 | +0.0 | 0.0 | 1088.3 | 4.0 | +0.0 | 0.0 | 65.0 |
| HIS CHARGE LIST | 4.3 | +0.0 | 0.0 | 61.7 | 3.3 | +0.0 | 0.0 | 132.3 |
| HIS LEGAL MOVES | 5.3 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 143.7 |
| HIS MOVE AND SHOT | 1.0 | -0.8 | 0.0 | 100.3 | 4.3 | -136.9 | 0.0 | 117.0 |
| HIS MOVE AS HE DECIDES | - | - | - | - | 39.7 | +9.3 | 1139.7 | 0.0 |
| HIS MOVE WHY | 15.7 | +0.0 | 0.0 | 319.3 | - | - | - | - |
| HIS ONE MOVE | - | - | - | - | 21.7 | -110.8 | 0.0 | 317.3 |
| HIS ONE QUARTER | 6.0 | +0.0 | 0.0 | 22.7 | 6.3 | +0.0 | 0.0 | 346.0 |
| HIS OWN BEST MOVE | 8.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVE | - | - | - | - | 8.0 | +0.0 | 0.0 | 50.0 |
| HIS RANDOM MOVER COMES | - | - | - | - | 4.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 40.3 | +329.8 | 0.0 | 1057.7 | 24.7 | +805.7 | 0.0 | 516.0 |
| HIS SHOTS BY HIS RUN | 41.0 | +212.0 | 0.0 | 1506.0 | 26.0 | +704.6 | 0.0 | 484.7 |
| HIS TURN DENIED | 0.7 | +13.9 | 44.0 | 0.0 | 2.3 | +40.9 | 434.3 | 0.0 |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 17.0 | +0.0 | 0.0 | 0.0 | 15.3 | +0.0 | 0.0 | 344.0 |
| HOLDER ASSIGNMENT | 10.3 | +638.4 | 0.0 | 0.0 | 9.0 | +720.1 | 0.0 | 150.0 |
| HOLDS AMBUSHERS | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 0.7 | -1.7 | 44.0 | 0.0 | 5.0 | -221.1 | 831.3 | 84.7 |
| HUNT IN PAIRS | - | - | - | - | 1.7 | +13.2 | 0.0 | 143.7 |
| IDLE COST | 2.3 | -12.3 | 0.0 | 105.0 | 10.3 | -153.8 | 0.0 | 56.7 |
| JOINT CHARGE NOW | - | - | - | - | 1.0 | -9.7 | 460.3 | 0.0 |
| KEPT FROM ITS LAST STOP | 1.3 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 0.3 | +6.3 | 0.0 | 0.0 | 1.7 | +89.0 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 6.0 | +0.0 | 645.7 | 251.7 | 14.3 | +0.0 | 646.7 | 959.0 |
| LONE WIZARD KEPT IN | 0.3 | +16.1 | 0.0 | 0.0 | 0.7 | +39.2 | 0.0 | 0.0 |
| LONG SHOT | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +4.8 | 180.0 | 16.7 |
| LOST AFTER ESCAPE | 0.3 | -0.2 | 22.0 | 0.0 | 5.3 | +10.7 | 577.7 | 166.3 |
| MAKE SURE TOGETHER | - | - | - | - | 0.3 | +2.3 | 0.0 | 0.0 |
| MANOEUVRE | 1.3 | -0.2 | 0.0 | 100.3 | 1.7 | -5.8 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.3 | +1.4 | 0.0 | 0.0 | - | - | - | - |
| MARCH BY THE SUM | 0.7 | +42.7 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | 1.7 | +62.1 | 0.0 | 0.0 | 0.3 | +1.4 | 0.0 | 0.0 |
| MARCH OVER CASTS | 1.0 | +27.9 | 0.0 | 180.0 | - | - | - | - |
| MARCH WHEELS ONLY | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 5.0 | +227.9 | 0.0 | 94.3 | 4.3 | +74.5 | 0.0 | 255.7 |
| MEETS IN TIME | 3.7 | +210.7 | 0.0 | 0.0 | 2.3 | +191.0 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 3.0 | +126.1 | 0.0 | 0.0 | 3.3 | +17.0 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 4.7 | +96.0 | 0.0 | 180.0 | 4.7 | +19.7 | 0.0 | 0.0 |
| MISSILES ON ONE TARGET | 0.3 | -9.4 | 0.0 | 0.0 | - | - | - | - |
| MOVE ORDER | 2.0 | +0.0 | 78.0 | 180.0 | 2.3 | +0.0 | 22.0 | 20.0 |
| MOVE TO CHARGE COMPUTED | 5.3 | +227.3 | 0.0 | 114.7 | 13.0 | +626.2 | 0.0 | 317.3 |
| MOVES UNITS SPELL | 0.3 | +1.4 | 0.0 | 0.0 | - | - | - | - |
| NEARER NOT NEEDED | 8.7 | +343.8 | 0.0 | 100.3 | 10.3 | +327.9 | 0.0 | 164.3 |
| NEXT CHARGE BY LIST | 3.3 | +133.3 | 0.0 | 96.3 | 6.3 | +210.4 | 156.0 | 0.0 |
| NO DOUBLE ROUNDS | 0.7 | -7.6 | 44.0 | 0.0 | 5.7 | -445.1 | 1187.7 | 0.0 |
| NO LATE CUT | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 1.7 | -0.9 | 0.0 | 31.7 | - | - | - | - |
| OFF BEST | 2.3 | -40.3 | 0.0 | 85.0 | 5.7 | -117.4 | 0.0 | 87.3 |
| ONE CHECK AFTER THE LAST CHANGE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ONE FIGHT FORMULA | 4.7 | -46.7 | 0.0 | 414.0 | 10.0 | -190.8 | 0.0 | 313.7 |
| ONE JOINT FIGURE | - | - | - | - | 1.0 | +23.2 | 180.0 | 16.7 |
| ONE OBJECTIVE FORMULA | 7.0 | -53.9 | 0.0 | 0.0 | 3.7 | -74.8 | 0.0 | 108.0 |
| ONE PROMISE A TARGET | - | - | - | - | 2.0 | -0.7 | 78.0 | 0.0 |
| ONE ROUTE | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| OVERRUNS AWAY | - | - | - | - | 2.3 | +15.1 | 421.7 | 84.7 |
| PERIAPT WORTH | 0.3 | +18.1 | 0.0 | 0.0 | - | - | - | - |
| PLAN RESULT | 38.3 | +123.8 | 232.0 | 1380.3 | 43.3 | +1145.7 | 869.7 | 1309.0 |
| PROMISE BELOW ZERO | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE BY ITS OWN SUM | 5.3 | -21.8 | 0.0 | 96.3 | 14.3 | -450.2 | 0.0 | 317.3 |
| PROMISE IN STEPS | - | - | - | - | 3.0 | +0.0 | 156.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | 0.7 | +0.0 | 0.0 | 78.0 | 7.7 | -2.6 | 156.0 | 0.0 |
| PROMISE READS THE TABLE | 1.7 | -37.7 | 0.0 | 0.0 | 1.3 | -5.5 | 0.0 | 0.0 |
| PROMISE SHOT AWAY | - | - | - | - | 2.3 | -2.2 | 0.0 | 0.0 |
| PURSUES BIG PREY | - | - | - | - | 0.3 | -1.7 | 0.0 | 0.0 |
| QUARTER ODDS | 18.3 | +1955.9 | 413.3 | 326.7 | 19.7 | +3061.2 | 197.3 | 524.0 |
| RANDOM MOVE BY FIGURES | 2.0 | +24.7 | 0.0 | 70.0 | - | - | - | - |
| REAL GROUND | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | 6.3 | +437.8 | 0.0 | 18.3 | 3.3 | +87.5 | 0.0 | 113.0 |
| REDIRECT FOR A FRIEND IN REACH | 2.7 | +0.0 | 0.0 | 48.0 | 4.0 | +0.0 | 0.0 | 74.0 |
| REFORMS TO MEET IT | 1.0 | -1.1 | 0.0 | 0.0 | 1.0 | -11.0 | 0.0 | 0.0 |
| REFUSING RETIRES | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 84.7 |
| RESERVE FALL BACK | - | - | - | - | 2.3 | +90.8 | 0.0 | 122.3 |
| RESTRAINS TO SHOOT | - | - | - | - | 0.3 | +7.2 | 0.0 | 0.0 |
| RISK BY ARC | 0.7 | +10.0 | 44.0 | 0.0 | 5.7 | -25.6 | 1091.7 | 101.3 |
| RISK ON THE WAY | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| ROUNDS AFTER TERROR | - | - | - | - | 4.0 | -151.5 | 479.7 | 101.3 |
| RUN DOWN | - | - | - | - | 5.3 | -60.8 | 577.7 | 166.3 |
| SCOUT SPOT | 0.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| SCOUT WAITS | 1.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 0.3 | -32.0 | 0.0 | 15.0 |
| SEARCH SPOT | 1.3 | +57.4 | 0.0 | 0.0 | 1.3 | +67.7 | 0.0 | 0.0 |
| SELF MOVE SPELL | 2.0 | -4.0 | 0.0 | 0.0 | - | - | - | - |
| SET CREDITED ONCE | 1.3 | -36.7 | 0.0 | 76.0 | 0.7 | -9.1 | 0.0 | 15.0 |
| SET UP BY THE SET | 2.3 | +38.0 | 0.0 | 76.0 | 2.0 | +6.1 | 139.7 | 15.0 |
| SET UP TOGETHER | - | - | - | - | 0.3 | +2.3 | 0.0 | 0.0 |
| SET-UP ANY TARGET | - | - | - | - | 0.3 | +21.8 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | - | - | - | - | 0.3 | +1.7 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 6.0 | +0.0 | 0.0 | 154.0 | 7.3 | +0.0 | 0.0 | 98.3 |
| SHOOTS FROM THE BEST SPOT | 3.3 | +210.2 | 355.0 | 0.0 | 2.7 | +27.6 | 76.0 | 0.0 |
| SHOT OR CHARGE | - | - | - | - | 0.3 | -0.9 | 100.3 | 0.0 |
| SHOT RISK POINTS | 18.0 | -102.2 | 0.0 | 329.3 | 17.7 | +214.8 | 0.0 | 403.7 |
| SHOTS AFTER THE MOVES | 3.0 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 11.7 | +445.6 | 0.0 | 470.0 | 13.3 | +136.4 | 0.0 | 248.3 |
| SPELL SETS UP CHARGE | - | - | - | - | 0.3 | +21.8 | 0.0 | 0.0 |
| SPELL WORTH | 0.7 | +10.4 | 180.0 | 180.0 | - | - | - | - |
| SPELLS IN THE FIGHT | - | - | - | - | 0.3 | -35.5 | 180.0 | 0.0 |
| SPOT AS THE GAME MOVES | 7.7 | +0.0 | 0.0 | 194.7 | 4.0 | +0.0 | 0.0 | 240.3 |
| STAND AND SHOOT | 0.3 | -0.3 | 22.0 | 0.0 | 1.0 | -4.5 | 254.3 | 0.0 |
| STANDS FOR A REASON | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 27.0 | +0.0 | 552.3 | 400.7 | 28.3 | +0.0 | 652.3 | 335.0 |
| STAY WORTH | 7.3 | +56.9 | 0.0 | 156.0 | 19.0 | +126.1 | 531.0 | 102.0 |
| STRIKE BY THE ODDS | - | - | - | - | 1.3 | +11.7 | 0.0 | 65.0 |
| STUPIDITY NEXT TURN | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 12.7 | +1803.2 | 0.0 | 266.7 | 6.0 | +341.8 | 0.0 | 368.7 |
| SUPPORT NARROWED | 0.7 | +0.0 | 22.0 | 0.0 | 0.3 | +0.0 | 0.0 | 16.7 |
| SUPPORT WORKED OUT | 12.7 | +1803.2 | 0.0 | 266.7 | 6.0 | +341.8 | 0.0 | 368.7 |
| SURE REACH TOGETHER | - | - | - | - | 0.3 | +3.1 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 1.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| THE PROMISE ADDS | 0.7 | -31.3 | 0.0 | 0.0 | - | - | - | - |
| THE ROW IN ITS ORDER | 4.3 | +0.0 | 0.0 | 78.0 | 1.3 | +0.0 | 65.0 | 131.3 |
| THE ROW KEEPS ITS WAY | 5.3 | +0.0 | 0.0 | 100.3 | 3.7 | +0.0 | 0.0 | 23.3 |
| THE STEP BACK IS MADE | 3.3 | +0.0 | 0.0 | 100.3 | 2.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 37.7 | +0.0 | 0.0 | 784.7 | 41.7 | +0.0 | 0.0 | 771.7 |
| TIED UP BY THE SUM | - | - | - | - | 1.7 | +212.2 | 366.3 | 0.0 |
| TIME ON OUR SIDE | 34.3 | +351.1 | 44.0 | 598.3 | 16.7 | +133.4 | 0.0 | 615.0 |
| WAITS AGAIN | 4.3 | +0.0 | 0.0 | 188.7 | 0.3 | +0.0 | 0.0 | 0.0 |
| WAR ENGINE JOBS | 2.3 | +0.0 | 130.0 | 0.0 | - | - | - | - |
| WHAT THE JOINER ADDS | - | - | - | - | 0.7 | -9.5 | 0.0 | 130.0 |
| WHO FIGHTS | 0.7 | -4.0 | 44.0 | 0.0 | 1.0 | +0.8 | 280.3 | 0.0 |
| WHO HITS BACK | 0.7 | +18.2 | 0.0 | 0.0 | 0.3 | +3.5 | 0.0 | 0.0 |
| WHOLE FIGHT | - | - | - | - | 0.3 | +23.6 | 0.0 | 65.0 |
| WHOLE FIGHT DANGER | 6.0 | -1135.4 | 0.0 | 932.3 | 1.0 | -41.9 | 0.0 | 0.0 |
| WHOLE FIGHT GAIN | - | - | - | - | 0.3 | +26.8 | 180.0 | 0.0 |
| WOUNDS ON THE RANKS | 3.7 | +64.2 | 0.0 | 0.0 | - | - | - | - |

### Rule changes: csame-bb45c30-p34

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS MOVE AS HE DECIDES | 119 | 119 | 91 | 30.33 | +0 | +0.0 |
| ARMY TABLE | 110 | 110 | 71 | 23.67 | +1946 | +27.4 |
| LEGAL CHARGES ONLY | 61 | 61 | 61 | 20.33 | +0 | +0.0 |
| FIVE ACTION | 505 | 489 | 60 | 20.00 | +2661 | +44.3 |
| HOLDER ASSIGNMENT | 58 | 58 | 52 | 17.33 | +2620 | +50.4 |
| THE TABLE AGAIN | 36 | 36 | 30 | 10.00 | +0 | +0.0 |
| HIS SHOT LIST | 195 | 185 | 29 | 9.67 | +114 | +3.9 |
| PROMISE BY ITS OWN SUM | 59 | 59 | 28 | 9.33 | -1416 | -50.6 |
| HIS MOVE WHY | 47 | 47 | 27 | 9.00 | +0 | +0.0 |
| HIS SHOTS BY HIS RUN | 201 | 191 | 25 | 8.33 | +224 | +9.0 |
| MOVE TO CHARGE COMPUTED | 55 | 47 | 25 | 8.33 | +435 | +17.4 |
| OFF BEST | 24 | 24 | 24 | 8.00 | -473 | -19.7 |
| QUARTER ODDS | 114 | 110 | 22 | 7.33 | +2252 | +102.3 |
| REDIRECT FOR A FRIEND IN REACH | 20 | 20 | 20 | 6.67 | +0 | +0.0 |
| DEPLOY BY FIGURES | 45 | 45 | 19 | 6.33 | +155 | +8.1 |
| SUPPORT ADDS | 56 | 55 | 19 | 6.33 | +1587 | +83.6 |
| SUPPORT WORKED OUT | 56 | 55 | 19 | 6.33 | +1587 | +83.6 |
| HIS ONE MOVE | 65 | 63 | 18 | 6.00 | +0 | +0.0 |
| GOAL WALK | 51 | 49 | 15 | 5.00 | +895 | +59.7 |
| SHOOTS FROM THE BEST SPOT | 18 | 18 | 14 | 4.67 | +353 | +25.2 |
| MOVE ORDER | 13 | 13 | 13 | 4.33 | +0 | +0.0 |
| FOUR ROUNDS | 22 | 22 | 12 | 4.00 | +308 | +25.7 |
| TIME ON OUR SIDE | 153 | 137 | 12 | 4.00 | +49 | +4.1 |
| FOLLOW UP WEIGHED | 9 | 9 | 9 | 3.00 | +1853 | +205.9 |
| ADVANCE LANE KEPT | 8 | 8 | 8 | 2.67 | +0 | +0.0 |
| HARD STAY DROPPED | 8 | 8 | 8 | 2.67 | +0 | +0.0 |
| MEETS IN TIME | 18 | 18 | 8 | 2.67 | +507 | +63.4 |
| NEXT CHARGE BY LIST | 29 | 27 | 8 | 2.67 | +261 | +32.6 |
| COMBAT PIVOT | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| COVER ONCE | 56 | 43 | 7 | 2.33 | +88 | +12.6 |
| PROMISE KNOWS THE FIGHT | 25 | 23 | 7 | 2.33 | -8 | -1.1 |
| PROMISE SHOT AWAY | 7 | 7 | 7 | 2.33 | -7 | -1.0 |
| RESERVE FALL BACK | 7 | 7 | 7 | 2.33 | +272 | +38.9 |
| SCOUT WAITS | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| SHOT RISK POINTS | 107 | 100 | 7 | 2.33 | +125 | +17.9 |
| SHOTS IN THE MOVE | 75 | 64 | 7 | 2.33 | +313 | +44.7 |
| EXACT ROUND | 14 | 14 | 6 | 2.00 | +29 | +4.8 |
| LANE BY FIGURES | 6 | 6 | 6 | 2.00 | +286 | +47.6 |
| MAX FOR POSITIONING | 28 | 26 | 6 | 2.00 | +3 | +0.5 |
| ONE PROMISE A TARGET | 6 | 6 | 6 | 2.00 | -2 | -0.3 |
| CHARGE LOSSES | 62 | 55 | 5 | 1.67 | +233 | +46.6 |
| SEARCH SPOT | 8 | 8 | 5 | 1.67 | +375 | +75.1 |
| STAY WORTH | 79 | 75 | 5 | 1.67 | +78 | +15.6 |
| WHOLE FIGHT DANGER | 21 | 18 | 5 | 1.67 | +315 | +62.9 |
| CASTER AWAY FROM SCREEN | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| MARCH CHECK | 6 | 6 | 4 | 1.33 | +34 | +8.6 |
| THE ROW IN ITS ORDER | 17 | 4 | 4 | 1.33 | +0 | +0.0 |
| CHALLENGE BY POINTS | 3 | 3 | 3 | 1.00 | +32 | +10.6 |
| CHARGE NOW FIRST | 17 | 17 | 3 | 1.00 | -167 | -55.6 |
| HOLDS AMBUSHERS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| IDLE COST | 38 | 24 | 3 | 1.00 | +7 | +2.4 |
| JOINT CHARGE NOW | 3 | 3 | 3 | 1.00 | -29 | -9.7 |
| LONE WIZARD KEPT IN | 3 | 3 | 3 | 1.00 | +166 | +55.3 |
| REDIRECT COUNTER | 29 | 26 | 3 | 1.00 | +100 | +33.5 |
| STRIKE BY THE ODDS | 4 | 4 | 3 | 1.00 | +59 | +19.6 |
| TIED UP BY THE SUM | 5 | 5 | 3 | 1.00 | +44 | +14.6 |
| WHO HITS BACK | 3 | 3 | 3 | 1.00 | +42 | +13.9 |
| CAST JOB | 9 | 9 | 2 | 0.67 | +0 | +0.0 |
| CASTS FROM BEHIND | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| HIS TURN DENIED | 9 | 9 | 2 | 0.67 | +29 | +14.5 |
| MARCH BY THE SUM | 2 | 2 | 2 | 0.67 | +128 | +64.1 |
| MISSILES IN THE MOVE | 19 | 13 | 2 | 0.67 | +5 | +2.6 |
| ONE FIGHT FORMULA | 44 | 26 | 2 | 0.67 | +32 | +16.2 |
| ONE JOINT FIGURE | 3 | 3 | 2 | 0.67 | +8 | +3.9 |
| ONE OBJECTIVE FORMULA | 32 | 25 | 2 | 0.67 | +61 | +30.3 |
| PROMISE READS THE TABLE | 9 | 9 | 2 | 0.67 | +437 | +218.7 |
| RISK BY ARC | 19 | 19 | 2 | 0.67 | +71 | +35.5 |
| SET UP BY THE SET | 13 | 13 | 2 | 0.67 | -33 | -16.7 |
| SHOTS AFTER THE MOVES | 19 | 19 | 2 | 0.67 | +0 | +0.0 |
| WOUNDS ON THE RANKS | 11 | 11 | 2 | 0.67 | +14 | +6.8 |
| AFTERMATH IN POINTS | 1 | 1 | 1 | 0.33 | +72 | +72.2 |
| ASSAILMENT BY POINTS | 1 | 1 | 1 | 0.33 | +2 | +1.7 |
| BACKUP TARGETS | 3 | 3 | 1 | 0.33 | +0 | +0.0 |
| CHAFF IN THE MOVE | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CONTINUE AHEAD WEIGHED | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| ELIXIR WORTH | 1 | 1 | 1 | 0.33 | +72 | +71.8 |
| FALLS SHORT | 62 | 52 | 1 | 0.33 | +4 | +4.1 |
| FIGHT TO THE END | 12 | 12 | 1 | 0.33 | +10 | +9.7 |
| FIRE IN ORDER | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| HIS MOVE AND SHOT | 16 | 15 | 1 | 0.33 | +114 | +113.8 |
| HONEST WORTH | 17 | 17 | 1 | 0.33 | +18 | +17.7 |
| LONG SHOT | 3 | 3 | 1 | 0.33 | +2 | +1.8 |
| MOVES UNITS SPELL | 1 | 1 | 1 | 0.33 | +4 | +4.3 |
| NEARER NOT NEEDED | 57 | 54 | 1 | 0.33 | +52 | +52.2 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.33 | +54 | +54.4 |
| PURSUES BIG PREY | 1 | 1 | 1 | 0.33 | -5 | -5.1 |
| RANDOM MOVE BY FIGURES | 6 | 6 | 1 | 0.33 | +74 | +74.2 |
| RESTRAINS TO SHOOT | 1 | 1 | 1 | 0.33 | +21 | +21.4 |
| ROUNDS AFTER TERROR | 12 | 12 | 1 | 0.33 | +0 | +0.2 |
| RUN DOWN | 16 | 16 | 1 | 0.33 | +0 | +0.2 |
| SHOOTERS IN TWO RANKS | 1 | 1 | 1 | 0.33 | +5 | +5.0 |
| SUPPORT NARROWED | 3 | 3 | 1 | 0.33 | -393 | -393.0 |
| SURE REACH TOGETHER | 1 | 1 | 1 | 0.33 | +4 | +3.8 |
| WHO FIGHTS | 5 | 5 | 1 | 0.33 | +2 | +1.8 |
| WHOLE FIGHT | 1 | 1 | 1 | 0.33 | +2 | +1.6 |
| WHOLE FIGHT GAIN | 1 | 1 | 1 | 0.33 | +2 | +1.8 |
| BLOWS WHERE AIMED | 1 | 1 | 0 | 0.00 | - | - |
| CASTING BLOCK | 2 | 2 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 4 | trace | - | - | - | - |
| CHAMPION KNOWS CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 72 | 70 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 3 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 5 | 5 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 1 | 1 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 19 | 19 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 7 | 7 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 64 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 64 | 61 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 16 | 16 | 0 | 0.00 | - | - |
| GIVES UP | 2 | 2 | 0 | 0.00 | - | - |
| GUN FIGURES | 9 | not checked | - | - | - | - |
| HE REFORMS ONCE FREED | 40 | 38 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 50 | 45 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 23 | 22 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 24 | 22 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 37 | 35 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 28 | 28 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 24 | 20 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 12 | 9 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN RUN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 97 | 97 | 0 | 0.00 | - | - |
| HUNT IN PAIRS | 5 | 3 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 14 | 14 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 2 | 2 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 17 | 17 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 1 | not checked | - | - | - | - |
| MANOEUVRE | 9 | 9 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 3 | 3 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 4 | 4 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 28 | 19 | 0 | 0.00 | - | - |
| MISSILES ON ONE TARGET | 1 | not checked | - | - | - | - |
| NO DOUBLE ROUNDS | 19 | 19 | 0 | 0.00 | - | - |
| NO LATE CUT | 2 | 2 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 18 | 18 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 5 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 1 | not checked | - | - | - | - |
| ONE ROUTE | 4 | 4 | 0 | 0.00 | - | - |
| OVERRUNS AWAY | 7 | 7 | 0 | 0.00 | - | - |
| PLAN RESULT | 245 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE IN STEPS | 9 | 9 | 0 | 0.00 | - | - |
| REAL GROUND | 4 | 4 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 6 | 6 | 0 | 0.00 | - | - |
| REFUSING RETIRES | 3 | 3 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 1 | 1 | 0 | 0.00 | - | - |
| SCOUT SPOT | 6 | 6 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 1 | 1 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 6 | not checked | - | - | - | - |
| SET CREDITED ONCE | 6 | 6 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 1 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 1 | not checked | - | - | - | - |
| SHOOTERS ON THE TABLE | 40 | not checked | - | - | - | - |
| SHOT OR CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 1 | not checked | - | - | - | - |
| SPELL WORTH | 2 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 35 | 32 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 4 | 4 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 2 | 1 | 0 | 0.00 | - | - |
| STANDS STILL | 166 | 163 | 0 | 0.00 | - | - |
| STUPIDITY NEXT TURN | 2 | not checked | - | - | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 7 | not checked | - | - | - | - |
| THE PROMISE ADDS | 2 | 2 | 0 | 0.00 | - | - |
| THE ROW KEEPS ITS WAY | 27 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 16 | not checked | - | - | - | - |
| THE TABLE BINDS | 238 | not checked | - | - | - | - |
| WAITS AGAIN | 14 | 13 | 0 | 0.00 | - | - |
| WAR ENGINE JOBS | 7 | 7 | 0 | 0.00 | - | - |
| WHAT THE JOINER ADDS | 2 | 2 | 0 | 0.00 | - | - |

### Off best figure: csame-bb45c30-p34

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| PROMISE BY ITS OWN SUM | rule | 1.00 | 8.33 | 50.6 |
| JOB FIRST | gate | 2.33 | 4.33 | 18.2 |
| ARMY TABLE | rule | 2.33 | 0.33 | 48.0 |
| PROMISE KNOWS THE FIGHT | rule | - | 2.00 | 1.2 |
| PROMISE SHOT AWAY | rule | - | 2.00 | 1.1 |
| CHARGE NOW FIRST | rule | - | 1.00 | 55.6 |
| ONE PROMISE A TARGET | rule | - | 1.00 | 0.7 |
| RULE SWITCHED OFF | gate | - | 1.00 | 26.4 |
| AFTERMATH NEEDS NEXT CHARGE | gate | - | 0.33 | 29.3 |
| DEPLOY BY FIGURES | rule | 0.33 | - | 1.1 |
| HOLDER ASSIGNMENT | rule | - | 0.33 | 15.1 |
| JOINT CHARGE NOW | rule | - | 0.33 | 92.3 |
| PROMISE READS THE TABLE | rule | - | 0.33 | 1.0 |
| PURSUES BIG PREY | rule | - | 0.33 | 5.1 |
| SET UP BY THE SET | rule | - | 0.33 | 64.2 |
| SUPPORT NARROWED | rule | 0.33 | - | 393.0 |

### Plans: csame-bb45c30-p34

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 0.7 | 100% | 51 | 44 | 87% |
| Mine | move | 33.0 | 92% | 2400 | 0 | 0% |
| Mine | shoot | 4.7 | 36% | 484 | 80 | 17% |
| Opponent | charge | 6.0 | 61% | 1110 | 915 | 82% |
| Opponent | join | 2.0 | 100% | 76 | 0 | 0% |
| Opponent | move | 28.7 | 91% | 1725 | 0 | 0% |
| Opponent | shoot | 6.3 | 47% | 292 | 231 | 79% |
| Opponent | support | 0.3 | 0% | 0 | 0 | - |

### Battle groups: csame-bb45c30-p34

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 6.3 | 5% | 100% | 0% | - | 0% | 0% | 100% | 0% | 0% |
| Opponent | REDIRECT COUNTER | 3.3 | 50% | 80% | 0% | - | 40% | 0% | 0% | 60% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: csame-bb45c30-p34

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 1 | 217 (1) | 217 | 0 | 0 | 0% | 6.0 | - | 217 (1) | - | - | 217 (1) |
| Mine | Chaff | 7 | 66 (7) | 39 | 27 | 27 | 57% | 2.3 | 75 (6) | 0 (1) | - | 66 (7) | - |
| Mine | Character | 8 | 67 (8) | 67 | 0 | 46 | 0% | 2.6 | 17 (5) | - | 195 (2) | - | 71 (7) |
| Mine | Clean-up | 4 | 126 (4) | 0 | 126 | 0 | 50% | 5.5 | 69 (2) | 125 (1) | 711 (1) | 125 (1) | 126 (3) |
| Mine | Fast Hammer | 1 | 57 (1) | 57 | 0 | 0 | 0% | 4.0 | 57 (1) | - | - | - | 57 (1) |
| Mine | Hammer | 11 | 24 (11) | 22 | 3 | 69 | 0% | 2.3 | 10 (3) | 34 (7) | 0 (1) | 8 (4) | 34 (7) |
| Mine | Shooter | 3 | 23 (3) | 23 | 0 | 0 | 0% | 2.0 | 35 (2) | 0 (1) | - | 69 (1) | 0 (2) |
| Mine | Wizard | 2 | 0 (2) | 0 | 0 | 0 | 0% | 2.0 | 0 (2) | - | - | - | 0 (2) |
| Opponent | Chaff | 8 | 103 (8) | 11 | 92 | 74 | 25% | 1.5 | 63 (2) | 134 (4) | 80 (2) | 130 (5) | 50 (3) |
| Opponent | Character | 8 | 62 (8) | 62 | 0 | 19 | 38% | 1.6 | 30 (5) | 113 (3) | - | 50 (3) | 68 (5) |
| Opponent | Clean-up | 4 | 0 (4) | 0 | 0 | 73 | 0% | 4.8 | 0 (2) | 0 (2) | - | 0 (2) | 0 (2) |
| Opponent | Fast Hammer | 7 | 57 (7) | 57 | 0 | 57 | 43% | 3.2 | 0 (2) | 99 (5) | - | 92 (4) | 32 (3) |
| Opponent | Holder | 4 | 91 (4) | 23 | 68 | 45 | 0% | 2.5 | 150 (2) | 83 (1) | 0 (1) | 125 (3) | 0 (1) |
| Opponent | Shooter | 4 | 7 (4) | 7 | 0 | 48 | 0% | 1.2 | 0 (2) | 14 (2) | - | 28 (2) | 0 (2) |
| Opponent | Wizard | 3 | 0 (3) | 0 | 0 | 23 | 0% | 2.3 | 0 (1) | - | 0 (1) | - | 0 (2) |

### Charged fights: csame-bb45c30-p34

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Ogre Kingdoms | 1 | 140 | 261 | 2.0 | 1.0 | 130 | 0 | +130 | 1 of 2 | 1 of 2 | - | +130 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 722 | 5.0 | 1.0 | 144 | 0 | +144 | 1 of 5 | 5 of 5 | - | +144 |
| Mine | Skaven | 1 | 45 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| **Mine** | all armies | 3 | 62 | 328 | 2.3 | 1.0 | 140 | 0 | +140 | 2 of 7 | 6 of 7 | - | +140 |
| Opponent | Tomb Kings of Khemri | 2 | 74 | 719 | 4.5 | 1.0 | 160 | 76 | +84 | 4 of 9 | 8 of 9 | - | +84 |
| Opponent | Vampire Counts | 1 | 0 | 845 | 6.0 | 1.0 | 141 | 74 | +66 | 2 of 6 | 3 of 6 | - | +66 |
| **Opponent** | all armies | 3 | 50 | 761 | 5.0 | 1.0 | 152 | 76 | +77 | 6 of 15 | 11 of 15 | - | +77 |

### Effective charges: csame-bb45c30-p34

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Ogre Kingdoms | 2 | 0 | 0 | 1 (net +66) | 0 | 0 | 0 | 1 | 100% (1 of 1) |
| Mine | Orc & Goblin Tribes | 5 | 0 | 0 | 0 | 1 (net +66) | 0 | 0 | 4 | 0% (0 of 1) |
| Opponent | Tomb Kings of Khemri | 9 | 0 | 0 | 2 (net -343) | 0 | 0 | 5 (net +204) | 2 | 29% (2 of 7) |
| Opponent | Vampire Counts | 6 | 2 (net -224) | 0 | 0 | 2 (net +270) | 0 | 2 (net +152) | 0 | 0% (0 of 6) |

### Charged fights, damage counted: csame-bb45c30-p34

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Effective (55-75%) | 1 | 34 | 66 | +66 | 66 | 0 | +66 | +194.1 |
| Mine | 76-89% | 1 | 55 | 66 | +66 | 66 | 0 | +66 | +120.0 |
| Mine | No odds | 5 | 295 | 189 | +170 | 179 | 0 | +179 | +60.7 |
| Mine | All fights | 7 | 224 | 154 | +140 | 147 | 0 | +147 | +65.7 |
| Opponent | Long shot (under 50%) | 2 | 152 | 114 | -224 | 3 | 224 | -221 | -145.2 |
| Opponent | Effective (55-75%) | 2 | 132 | 205 | -343 | 15 | 343 | -328 | -247.5 |
| Opponent | 76-89% | 2 | 314 | 238 | +270 | 276 | 49 | +227 | +72.5 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 7 | 381 | 238 | +189 | 211 | 14 | +197 | +51.6 |
| Opponent | No odds | 2 | 318 | 210 | +210 | 210 | 0 | +210 | +66.3 |
| Opponent | All fights | 15 | 300 | 213 | +77 | 166 | 89 | +77 | +25.7 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| csame-bb45c30-p34 | move | 24 | 4 (17%) | 2 (8%) | 2 (8%) | 18 (75%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L2025 |
| Elixir of Power | Mine | L1923 |
| Fistful of Laurels | Mine | L1823 |
| Invocation of Nehek | Opponent | L2025 |
| Periapt of Soul Exchange | Mine | L2025 |

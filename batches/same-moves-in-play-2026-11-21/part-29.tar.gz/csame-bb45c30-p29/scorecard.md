# Doctrine scorecard: csame-bb45c30-p29

### Scorecard: csame-bb45c30-p29

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0717 | 3 | 1 | Mine | no | 2 | 6 | 1 | 2 | 0 | 0 | 0 | 420 |
| L0717 | 3 | 1 | Opponent | yes | 2 | 5 | 1 | 0 | 1 | 0 | 0 | 141 |
| L0733 | 1 | 1 | Mine | no | 7 | 3 | 1 | 0 | 0 | 0 | 0 | 170 |
| L0733 | 1 | 1 | Opponent | no | 0 | 4 | 1 | 4 | 0 | 0 | 0 | 0 |
| L0823 | 1 | 1 | Mine | no | 12 | 5 | 1 | 1 | 0 | 0 | 0 | 421 |
| L0823 | 1 | 1 | Opponent | no | 0 | 2 | 0 | 4 | 0 | 0 | 0 | 195 |
| **Average** | | | Mine | 0% | 7.0 | 4.7 | 1.0 | 1.0 | 0.0 | 0.0 | 0.0 | 337.0 |
| **Average** | | | Opponent | 33% | 0.7 | 3.7 | 0.7 | 2.7 | 0.3 | 0.0 | 0.0 | 112.0 |

### KPIs: csame-bb45c30-p29

Rules off - Opponent only: NO OLD ONE-MOVE GUESS; both sides: ONE RUN A PLAN.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 94% (15 of 16) | 0% (0 of 13) | 52% (15 of 29) |
| Winner chose to follow up after the loser gave ground |  | 100% (1 of 1); on the table 100% | 100% (3 of 3); on the table 100% | 100% (4 of 4); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | - | - | - |
| Winner chose to pursue after the loser fled |  | - | - | - |
| Winner chose to follow up or pursue (all three) |  | 100% (1 of 1); on the table 100% | 100% (3 of 3); on the table 100% | 100% (4 of 4); on the table 100% |
| Magic missiles tried each own turn | 50%+ | 50% (6 of 12) | 33% (4 of 12) | 42% (10 of 24) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 50% (6 of 12) | 33% (4 of 12) | 42% (10 of 24) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | - | - |
| Points that never fought | lower | 82% (4946 of 5998) | 73% (4376 of 6000) | 78% (9322 of 11998) |
|   infantry points that never fought | lower | 100% (715 of 715) | 76% (1075 of 1418) | 84% (1790 of 2133) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 63% (19 of 30) | 68% (15 of 22) | 65% (34 of 52) |
| Bound items with a magic missile used (at least once a game) |  | 0.0 uses a game | 100% (2 of 2); 2.0 uses a game | 100% (2 of 2); 1.0 uses a game |
| Bound items with another spell used |  | 0% (0 of 2); 0.0 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 33% (1 of 3); 0.3 uses a game | 0% (0 of 1); 0.0 uses a game | 25% (1 of 4); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 66% (3569 of 5389) | 66% (3310 of 5023) | 66% (6879 of 10412) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 0.3 (17%) | 2.3 (88%) | 2.7 (57%) |
| MARCHED: its unit marched | 1.3 (67%) | 0.3 (12%) | 1.7 (36%) |
| CHARGED: its unit charged | 0.3 (17%) | 0.0 (0%) | 0.3 (7%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 5.7 | 1.0 | 3.3 | 1.7 | 0.3 |
| not cast | 2.3 | 1.0 | 4.7 | 0.3 | 11.7 |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.0 (100%) | 2.7 (57%) | 0.0 (0%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 1.7 (36%) | 0.3 (100%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.3 (7%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.3 (100%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 11.7 (100%) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 73% (72 of 99) | 71% (71 of 100) | 72% (143 of 199) |
|   cavalry | 70% (7 of 10) | 62% (13 of 21) | 65% (20 of 31) |
|   character | - | 69% (9 of 13) | 69% (9 of 13) |
|   chariot | 80% (4 of 5) | - | 80% (4 of 5) |
|   infantry | 58% (14 of 24) | 84% (48 of 57) | 77% (62 of 81) |
|   monster | - | 11% (1 of 9) | 11% (1 of 9) |
|   war machine | 78% (47 of 60) | - | 78% (47 of 60) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.7 (30%) | 1.0 (10%) | 3.7 (20%) |
| CHARGED: it charged | 0.0 (0%) | 2.3 (24%) | 2.3 (12%) |
| IN COMBAT: it fought this turn or the last | 0.3 (4%) | 0.3 (3%) | 0.7 (4%) |
| MOVED: a war machine that moved | 1.0 (11%) | 0.0 (0%) | 1.0 (5%) |
| NO TARGET IN RANGE | 1.3 (15%) | 2.0 (21%) | 3.3 (18%) |
| ONLY IN COMBAT: the only targets were in combat | 0.0 (0%) | 0.7 (7%) | 0.7 (4%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.7 (19%) | 3.3 (34%) | 5.0 (27%) |
| SHELTERED: the target was sheltered | 0.7 (7%) | 0.0 (0%) | 0.7 (4%) |
| OTHER BAR | 1.3 (15%) | 0.0 (0%) | 1.3 (7%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 9.0 | 3.3 | 70% | 8.1 pts | 72 pts |
| character | 3.0 | 0.7 | 78% | 8.4 pts | 25 pts |
| chariot | 1.3 | 0.0 | 100% | 0.0 pts | 0 pts |
| infantry | 30.3 | 17.0 | 68% | 11.5 pts | 348 pts |
| monster | 0.3 | 0.0 | 100% | 0.0 pts | 0 pts |
| war machine | 15.7 | 12.7 | 60% | 27.3 pts | 428 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 1.3 | 2.7 | 2.0 |
| Charges that made contact a game | 1.0 | 1.7 | 1.3 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.50 declared, 0.00 contact (2 units) | - | 0.50 declared, 0.00 contact (2 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 0.67 declared, 0.33 contact (3 units) | 0.67 declared, 0.33 contact (3 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.13 declared, 0.13 contact (23 units) | 0.22 declared, 0.15 contact (27 units) | 0.18 declared, 0.14 contact (50 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 56% (5 of 9) | 33% (1 of 3) | - | 50% (6 of 12) |
| Character in a unit | 100% (5 of 5) | 100% (1 of 1) | 0% (0 of 1) | 86% (6 of 7) |
| Character on its own | 100% (4 of 4) | - | 83% (5 of 6) | 90% (9 of 10) |
| Chariot | - | 100% (1 of 1) | - | 100% (1 of 1) |
| Infantry | 0% (0 of 2) | 33% (1 of 3) | 0% (0 of 1) | 17% (1 of 6) |
| Monster | 100% (5 of 5) | - | - | 100% (5 of 5) |
| Monstrous | 100% (1 of 1) | - | - | 100% (1 of 1) |
| War Machines | 50% (5 of 10) | - | - | 50% (5 of 10) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Empire of Man | 3 | 100% (1 of 1); on the table 100% | 50% (6 of 12) | 82% | 63% (19 of 30) | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game | 33% (1 of 3); 0.3 uses a game |
| Lizardmen | 1 | - | - | 77% | 86% (6 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Tomb Kings of Khemri | 1 | 100% (1 of 1); on the table 100% | 33% (2 of 6) | 78% | 60% (3 of 5) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 1 | 100% (2 of 2); on the table 100% | 33% (2 of 6) | 64% | 60% (6 of 10) | 100% (2 of 2); 6.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (csame-bb45c30-p29, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 50% (2) | 67% (2) | 57% (4) |
| ...free all their last turn and able to turn (per game) | 0.67 | 0.67 | 1.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.67 | 0.67 | 1.33 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: csame-bb45c30-p29

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.3 | 2.0 |
| Strategy | Charge objectives carried out (made contact) | 50% (2 of 4) | 25% (1 of 4) |
| Strategy | Shoot objectives carried out (shot that target) | 29% (17 of 59) | 68% (13 of 19) |
| Strategy | Hexes on a unit its side charged or shot that turn | 67% (2 of 3) | - |
| Strategy | Joined characters whose unit fought | 0% (0 of 4) | 20% (1 of 5) |
| Strategy | Lone characters that fought | 0% (0 of 9) | 20% (1 of 5) |
| Movement | Charges halted short of contact | 0.0 | 0.7 |
| Movement | Idle units | 1.0 | 2.7 |
| Movement | Points that never moved of their own | 337.0 | 112.0 |
| Movement | Fights charged into per game | 1.0 | 1.3 |
| Movement | Charges with odds: long shots (under 50%) | 2 of 3, net -40 | 1 of 1, net +0 |
| Movement | Charges with odds: sweet spot (55-75%) | 1 of 3, net +0 | 0 of 1 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 3 | 0 of 1 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 0 of 3 | 0 of 1 |
| Shooting | Shots by shooting units (incl. breath weapons) | 8.7 | 26.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 58% (15 of 26) | 63% (50 of 79) |
| Shooting | Points destroyed by shooting units | 65.0 | 54.7 |
| Shooting | War machine shots | 15.7 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 55% (26 of 47) | - |
| Shooting | Points destroyed by war machines | 269.7 | 0.0 |
| Magic | Magic missiles cast | 2.0 | 0.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 0% (0 of 6) | 0% (0 of 1) |
| Magic | Wounds caused by magic missiles | 4.0 | 2.3 |
| Magic | Points destroyed by magic (all spells) | 0.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.3 / 1.0 / 0.0 / 0.0 | 1.3 / 0.0 / 0.0 / 1.3 |
| Combat | Points destroyed in combat | 0.0 | 188.0 |
| Combat | Points run down | 110.7 | 0.0 |
| Combat | Net points per charged fight, damage counted | -10 | +75 |
| Combat | Net per 100 charger points, damage counted | -5.5 | +104.5 |
| Combat | First round won (charged fights) | 67% | 75% |
| Combat | Net points per charged fight | -27 | +75 |
| Combat | Net points per supported fight / lone fight | - / -27 | +189 / +37 |
| Combat | Charged fights on a top-3 enemy unit | 1 of 3 | 3 of 4 |
| Game | Points lost | 344.0 | 428.7 |
| Game | VP from objectives | 910.0 | 763.3 |
| Game | Lone holders (player turns) | 7.0 | 0.7 |

- Mine won / drew / lost: 2 / 0 / 1 of 3 ended games (of 3); mean margin (Mine - Opponent) +280 VP
- The side that went first won 1 of 3 games with a winner
- Points traded per game (both sides' losses): 773
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: csame-bb45c30-p29

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| ARMY TABLE | 21.7 | +288.6 | 0.0 | 176.7 | 33.0 | +329.8 | 0.0 | 175.0 |
| ARRIVAL HUNT | - | - | - | - | 0.3 | +0.7 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 6.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CANNON PLAN MISSED | 1.3 | +0.0 | 222.0 | 0.0 | - | - | - | - |
| CANNON PLANNED TARGET | 13.7 | +475.2 | 969.7 | 0.0 | - | - | - | - |
| CANNON SIGHT KEPT | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CAST JOB | 2.0 | +117.7 | 0.0 | 0.0 | - | - | - | - |
| CASTER AWAY FROM SCREEN | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | - | - | - | - | 0.7 | +12.7 | 63.0 | 0.0 |
| CHAFF IN THE MOVE | - | - | - | - | 1.0 | +69.0 | 0.0 | 0.0 |
| CHAFF PASSED | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | -4.7 | 67.3 | 0.0 |
| CHARACTER GUNS | - | - | - | - | 5.7 | +0.0 | 0.0 | 0.0 |
| CHARGE LOSSES | 23.0 | -1202.0 | 0.0 | 506.7 | 23.0 | -1540.7 | 0.0 | 556.0 |
| CHARGE NOT DECLARED | - | - | - | - | 0.7 | +0.0 | 126.0 | 0.0 |
| CHARGE NOW FIRST | 0.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 63.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 7.3 | +0.0 | 0.0 | 0.0 | 13.3 | +0.0 | 0.0 | 71.0 |
| COVER ONCE | 13.7 | -594.0 | 0.0 | 109.3 | 10.7 | -959.4 | 0.0 | 185.0 |
| DENIED BY THE FIGHT | 0.7 | -1.9 | 61.7 | 63.0 | - | - | - | - |
| DEPLOY BY FIGURES | 8.7 | -71.5 | 0.0 | 0.0 | 8.7 | +28.7 | 0.0 | 65.0 |
| EXACT ROUND | 1.0 | -4.8 | 34.7 | 151.3 | 2.0 | +11.4 | 126.0 | 0.0 |
| FALL BACK GOOD ORDER | 1.3 | +0.0 | 96.3 | 151.3 | 1.7 | +0.0 | 63.0 | 0.0 |
| FALLS SHORT | - | - | - | - | 22.3 | +267.8 | 0.0 | 0.0 |
| FEATURE BUFFS | 1.3 | +45.9 | 0.0 | 0.0 | 1.3 | +10.3 | 0.0 | 0.0 |
| FIGHT TO THE END | 0.7 | +3.6 | 0.0 | 151.3 | 0.3 | +2.9 | 0.0 | 0.0 |
| FIRE IN ORDER | 1.7 | +0.0 | 116.7 | 88.3 | 0.7 | +0.0 | 0.0 | 0.0 |
| FIVE ACTION | 117.3 | +7950.5 | 2223.3 | 712.7 | 97.0 | +6216.2 | 496.0 | 650.7 |
| FLANK NOT WEIGHED | 9.0 | +0.0 | 0.0 | 36.7 | 6.0 | +0.0 | 0.0 | 254.3 |
| FOLLOW UP WEIGHED | 0.3 | +94.9 | 0.0 | 63.0 | 0.3 | +59.7 | 0.0 | 0.0 |
| FOUR ROUNDS | 1.3 | +75.8 | 96.3 | 151.3 | 2.0 | +215.4 | 126.0 | 0.0 |
| FREED FROM HIS FIGHT | 2.7 | +0.0 | 0.0 | 73.3 | 1.3 | +0.0 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 1.7 | -117.6 | 0.0 | 0.0 | - | - | - | - |
| GIVES UP | 0.3 | -2.5 | 0.0 | 88.3 | 0.3 | -8.3 | 63.0 | 0.0 |
| GOAL WALK | 6.0 | +435.7 | 0.0 | 0.0 | 13.7 | +837.3 | 0.0 | 25.3 |
| GUN FIGURES | 1.0 | +13.6 | 0.0 | 0.0 | - | - | - | - |
| GUN MASK | 1.7 | +111.8 | 0.0 | 54.7 | - | - | - | - |
| HARD STAY DROPPED | 2.0 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 1.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| HELPER UNSEEN | 0.3 | +0.0 | 61.7 | 0.0 | - | - | - | - |
| HIS CHARGE BY HIS RUN | 15.7 | +0.0 | 0.0 | 54.7 | 13.7 | +0.0 | 0.0 | 439.3 |
| HIS CHARGE LIST | 5.0 | +0.0 | 0.0 | 176.7 | 6.0 | +0.0 | 0.0 | 240.0 |
| HIS LEGAL MOVES | 4.7 | +0.0 | 0.0 | 109.3 | 5.7 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 3.0 | -33.5 | 0.0 | 0.0 | 4.3 | -82.0 | 0.0 | 0.0 |
| HIS MOVE AS HE DECIDES | - | - | - | - | 41.7 | +10.0 | 531.7 | 0.0 |
| HIS MOVE WHY | 29.3 | +0.0 | 0.0 | 332.3 | - | - | - | - |
| HIS ONE MOVE | - | - | - | - | 24.7 | -48.1 | 0.0 | 99.7 |
| HIS ONE QUARTER | 6.0 | +0.0 | 0.0 | 176.7 | 4.7 | +0.0 | 0.0 | 69.3 |
| HIS OWN BEST MOVE | 10.7 | +0.0 | 0.0 | 109.3 | 2.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 55.3 | +2619.6 | 0.0 | 561.3 | 65.3 | +4178.7 | 0.0 | 499.3 |
| HIS SHOTS BY HIS RUN | 44.3 | +1093.9 | 0.0 | 561.3 | 51.7 | +2204.0 | 0.0 | 603.3 |
| HIS TURN DENIED | 0.7 | +34.9 | 61.7 | 63.0 | 0.7 | +24.4 | 0.0 | 0.0 |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 29.0 | +0.0 | 0.0 | 488.0 | 18.7 | +0.0 | 0.0 | 123.3 |
| HOLDER ASSIGNMENT | 17.3 | +1600.4 | 0.0 | 244.0 | 12.0 | +1150.8 | 0.0 | 61.7 |
| HOLDS AMBUSHERS | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 1.3 | -30.0 | 96.3 | 151.3 | 1.3 | -65.9 | 63.0 | 0.0 |
| IDLE COST | - | - | - | - | 15.0 | -242.8 | 0.0 | 129.3 |
| KEEP FALLS | 0.3 | +3.6 | 0.0 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 6.7 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 0.3 | +17.2 | 0.0 | 0.0 | 1.3 | +85.6 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| LEGAL CHARGES ONLY | 2.3 | +0.0 | 0.0 | 0.0 | 14.0 | +0.0 | 239.7 | 6.3 |
| LONE WIZARD KEPT IN | 0.3 | +19.8 | 0.0 | 0.0 | 0.3 | +37.5 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | 0.7 | -1.9 | 61.7 | 63.0 | 1.0 | +0.3 | 126.0 | 0.0 |
| MAKE SURE TOGETHER | 0.3 | +3.9 | 0.0 | 0.0 | - | - | - | - |
| MANOEUVRE | 1.3 | +0.0 | 0.0 | 0.0 | 1.7 | -15.5 | 0.0 | 0.0 |
| MARCH AT ESCAPER | - | - | - | - | 0.3 | +4.3 | 0.0 | 0.0 |
| MARCH BY THE SUM | 0.3 | +12.3 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | - | - | - | - | 1.0 | +25.4 | 0.0 | 0.0 |
| MARCH OF THE TABLE | 0.3 | +3.8 | 0.0 | 0.0 | 0.3 | +0.8 | 0.0 | 0.0 |
| MARCH OVER CASTS | 1.0 | +161.7 | 0.0 | 0.0 | 0.7 | +12.0 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MAX FOR POSITIONING | 2.0 | +64.5 | 0.0 | 0.0 | 0.7 | +1.4 | 0.0 | 0.0 |
| MEETS IN TIME | 4.3 | +404.6 | 0.0 | 0.0 | 4.0 | +319.6 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 2.3 | +160.8 | 0.0 | 0.0 | 4.0 | +39.6 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 3.3 | +101.3 | 0.0 | 0.0 | 4.3 | +41.5 | 0.0 | 0.0 |
| MOVE ORDER | 2.3 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 120.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 7.0 | +812.6 | 0.0 | 0.0 | 3.3 | +243.3 | 0.0 | 130.0 |
| NEARER NOT NEEDED | 7.7 | +347.5 | 0.0 | 122.0 | 10.0 | +487.7 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 4.7 | +480.2 | 0.0 | 0.0 | 1.3 | +113.2 | 0.0 | 65.0 |
| NO DOUBLE ROUNDS | 1.0 | -22.9 | 61.7 | 151.3 | 1.7 | -143.8 | 63.0 | 0.0 |
| NO LATE CUT | 1.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 2.3 | -1.0 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 3.3 | -138.3 | 0.0 | 54.7 | 6.3 | -162.9 | 63.0 | 0.0 |
| ONE CHECK AFTER THE LAST CHANGE | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 4.3 | -116.5 | 0.0 | 54.7 | 3.0 | -80.7 | 0.0 | 65.0 |
| ONE OBJECTIVE FORMULA | 5.7 | -16.4 | 0.0 | 176.7 | 4.7 | -22.0 | 0.0 | 61.7 |
| ONE PROMISE A TARGET | 0.3 | -1.5 | 0.0 | 0.0 | 0.3 | -33.1 | 0.0 | 65.0 |
| ONE ROUTE | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| OPENS A LANE | 3.7 | +8.9 | 38.0 | 0.0 | - | - | - | - |
| OPENS UP | 0.3 | +14.1 | 34.7 | 0.0 | 0.3 | +6.4 | 0.0 | 0.0 |
| OVERRUNS AWAY | - | - | - | - | 0.7 | +14.8 | 63.0 | 0.0 |
| PATHS CROSS | - | - | - | - | 0.7 | +10.4 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | - | - | - | - | 0.3 | -3.7 | 0.0 | 0.0 |
| PLAN RESULT | 53.3 | +1252.7 | 34.7 | 620.0 | 43.3 | +440.1 | 126.0 | 504.0 |
| PROMISE BELOW ZERO | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE BY ITS OWN SUM | 6.0 | -173.9 | 0.0 | 0.0 | 3.7 | -40.8 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | - | - | - | - | 0.7 | +0.0 | 0.0 | 65.0 |
| PROMISE READS THE TABLE | 1.0 | -58.6 | 0.0 | 0.0 | - | - | - | - |
| PROMISE SHOT AWAY | - | - | - | - | 0.7 | -0.4 | 0.0 | 0.0 |
| QUARTER ODDS | 35.3 | +2503.1 | 755.0 | 405.7 | 25.3 | +2862.0 | 134.7 | 268.7 |
| REAL GROUND | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| REDIRECT BY WHAT IT STOPS | - | - | - | - | 2.3 | +189.5 | 0.0 | 0.0 |
| REDIRECT COUNTER | - | - | - | - | 1.0 | +10.7 | 0.0 | 0.0 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 4.0 | +230.7 | 0.0 | 6.3 |
| REFORMS TO MEET IT | 1.3 | -9.9 | 0.0 | 0.0 | 0.3 | -1.5 | 0.0 | 0.0 |
| RESERVE FALL BACK | - | - | - | - | 0.3 | +24.0 | 0.0 | 0.0 |
| RISK BY ARC | 1.0 | +33.6 | 61.7 | 151.3 | 1.0 | -31.3 | 63.0 | 0.0 |
| RISK ON THE WAY | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ROUNDS AFTER TERROR | - | - | - | - | 1.0 | -11.9 | 63.0 | 0.0 |
| RUN DOWN | 0.7 | -0.4 | 61.7 | 63.0 | 1.3 | -7.5 | 126.0 | 0.0 |
| SCOUT SPOT | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +1.8 | 0.0 | 0.0 |
| SCOUT WAITS | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| SEARCH SPOT | 0.7 | +5.0 | 0.0 | 54.7 | 0.3 | +12.1 | 0.0 | 0.0 |
| SECOND LOOK | - | - | - | - | 0.7 | +26.9 | 126.0 | 0.0 |
| SET UP BY THE SET | 0.3 | -5.1 | 0.0 | 0.0 | 1.7 | -32.7 | 0.0 | 65.0 |
| SET UP TOGETHER | 0.3 | +3.9 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | - | - | - | - | 0.7 | +3.0 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 21.7 | +0.0 | 0.0 | 0.0 | 5.3 | +0.0 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 0.7 | +31.9 | 0.0 | 0.0 | 1.3 | +20.6 | 0.0 | 0.0 |
| SHORT GUN FORWARD | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SHOT OR CHARGE | 1.3 | -89.9 | 34.7 | 0.0 | - | - | - | - |
| SHOT RISK POINTS | 37.7 | -4.7 | 0.0 | 506.7 | 42.0 | +772.5 | 0.0 | 603.3 |
| SHOTS AFTER THE MOVES | 6.0 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 27.0 | +1277.2 | 0.0 | 176.7 | 21.7 | +599.1 | 0.0 | 61.7 |
| SPELL WORTH | 1.7 | +12.0 | 0.0 | 0.0 | 4.0 | +38.2 | 0.0 | 0.0 |
| SPELLS IN THE FIGHT | - | - | - | - | 0.7 | +4.5 | 0.0 | 0.0 |
| SPOT AS THE GAME MOVES | 4.7 | +0.0 | 0.0 | 122.0 | 3.3 | +0.0 | 0.0 | 34.7 |
| STAND AND SHOOT | 0.3 | -4.7 | 0.0 | 63.0 | - | - | - | - |
| STANDS FOR A REASON | - | - | - | - | 7.0 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 67.3 | +0.0 | 2127.0 | 73.3 | 31.3 | +0.0 | 370.0 | 34.7 |
| STAY WORTH | 52.3 | +541.7 | 1421.0 | 244.0 | 18.3 | +207.7 | 244.0 | 0.0 |
| STRIKE BY THE ODDS | 0.3 | +0.4 | 0.0 | 63.0 | - | - | - | - |
| STUBBORN BY POINTS | - | - | - | - | 0.3 | +6.4 | 0.0 | 0.0 |
| SUPPORT ADDS | 2.7 | +160.2 | 0.0 | 0.0 | 4.3 | +551.2 | 0.0 | 34.7 |
| SUPPORT NARROWED | - | - | - | - | 0.3 | +0.0 | 63.0 | 0.0 |
| SUPPORT WORKED OUT | 2.7 | +160.2 | 0.0 | 0.0 | 4.3 | +551.2 | 0.0 | 34.7 |
| SURE REACH TOGETHER | 0.7 | +21.0 | 0.0 | 0.0 | - | - | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 1.3 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 2.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 34.7 |
| THE ROW KEEPS ITS WAY | 1.0 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 61.7 |
| THE STEP BACK IS MADE | 1.0 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 55.7 | +0.0 | 0.0 | 280.7 | 47.0 | +0.0 | 0.0 | 325.3 |
| TIED UP BY THE SUM | - | - | - | - | 0.3 | +17.7 | 0.0 | 0.0 |
| TIME ON OUR SIDE | 43.7 | +516.0 | 0.0 | 122.0 | - | - | - | - |
| WAITS AGAIN | 2.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| WHAT THE JOINER ADDS | - | - | - | - | 1.0 | +0.9 | 189.0 | 0.0 |
| WHO FIGHTS | 0.3 | -1.0 | 0.0 | 63.0 | 0.3 | -5.0 | 0.0 | 0.0 |
| WHOLE FIGHT | - | - | - | - | 0.7 | +19.3 | 126.0 | 0.0 |
| WHOLE FIGHT DANGER | 3.3 | -506.3 | 0.0 | 73.3 | 2.0 | -365.0 | 0.0 | 93.0 |
| WOUNDS ON THE RANKS | 7.7 | +254.3 | 0.0 | 269.3 | 3.0 | +179.8 | 0.0 | 123.3 |

### Rule changes: csame-bb45c30-p29

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 164 | 164 | 110 | 36.67 | +1442 | +13.1 |
| HIS SHOT LIST | 362 | 352 | 97 | 32.33 | +3403 | +35.1 |
| HIS MOVE AS HE DECIDES | 125 | 125 | 95 | 31.67 | +0 | +0.0 |
| HOLDER ASSIGNMENT | 88 | 88 | 77 | 25.67 | +4550 | +59.1 |
| HIS SHOTS BY HIS RUN | 288 | 278 | 55 | 18.33 | +732 | +13.3 |
| HIS MOVE WHY | 88 | 88 | 52 | 17.33 | +0 | +0.0 |
| LEGAL CHARGES ONLY | 49 | 49 | 49 | 16.33 | +0 | +0.0 |
| SHOT RISK POINTS | 239 | 230 | 37 | 12.33 | +2185 | +59.0 |
| DEPLOY BY FIGURES | 52 | 52 | 33 | 11.00 | +478 | +14.5 |
| THE TABLE AGAIN | 36 | 36 | 30 | 10.00 | +0 | +0.0 |
| OFF BEST | 29 | 29 | 29 | 9.67 | -904 | -31.2 |
| QUARTER ODDS | 182 | 178 | 23 | 7.67 | +2293 | +99.7 |
| HIS ONE MOVE | 74 | 73 | 22 | 7.33 | +0 | +0.0 |
| FIVE ACTION | 643 | 628 | 21 | 7.00 | +1521 | +72.4 |
| ARTILLERY RE-ROLL WEIGHED | 20 | 20 | 20 | 6.67 | +0 | +0.0 |
| TIME ON OUR SIDE | 131 | 108 | 20 | 6.67 | +52 | +2.6 |
| MOVE ORDER | 19 | 19 | 19 | 6.33 | +0 | +0.0 |
| CHARGE LOSSES | 138 | 134 | 15 | 5.00 | +1012 | +67.5 |
| MOVE TO CHARGE COMPUTED | 31 | 29 | 15 | 5.00 | +1153 | +76.9 |
| HARD STAY DROPPED | 13 | 13 | 13 | 4.33 | +0 | +0.0 |
| STAY WORTH | 212 | 193 | 13 | 4.33 | +66 | +5.1 |
| REDIRECT FOR A FRIEND IN REACH | 12 | 12 | 12 | 4.00 | +276 | +23.0 |
| NEXT CHARGE BY LIST | 18 | 18 | 11 | 3.67 | +703 | +63.9 |
| GOAL WALK | 59 | 59 | 10 | 3.33 | +441 | +44.1 |
| MEETS IN TIME | 25 | 25 | 9 | 3.00 | +266 | +29.5 |
| FIRE IN ORDER | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| ADVANCE LANE KEPT | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| COVER ONCE | 73 | 47 | 6 | 2.00 | +110 | +18.4 |
| SUPPORT ADDS | 21 | 21 | 6 | 2.00 | +478 | +79.7 |
| SUPPORT WORKED OUT | 21 | 21 | 6 | 2.00 | +478 | +79.7 |
| WOUNDS ON THE RANKS | 32 | 32 | 6 | 2.00 | +124 | +20.6 |
| CANNON SIGHT KEPT | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| FOUR ROUNDS | 10 | 8 | 5 | 1.67 | +261 | +52.3 |
| LANE BY FIGURES | 5 | 5 | 5 | 1.67 | +308 | +61.7 |
| PROMISE BY ITS OWN SUM | 29 | 29 | 5 | 1.67 | -644 | -128.8 |
| IDLE COST | 45 | 28 | 4 | 1.33 | +35 | +8.6 |
| SCOUT WAITS | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| REDIRECT BY WHAT IT STOPS | 7 | 7 | 3 | 1.00 | +233 | +77.8 |
| SET UP BY THE SET | 6 | 6 | 3 | 1.00 | +69 | +23.0 |
| CASTING BLOCK | 2 | 2 | 2 | 0.67 | +35 | +17.5 |
| CHAFF IN THE MOVE | 3 | 3 | 2 | 0.67 | +96 | +47.8 |
| CHAFF PASSED | 2 | 2 | 2 | 0.67 | -14 | -7.0 |
| CHARGE NOT DECLARED | 2 | 2 | 2 | 0.67 | -103 | -51.6 |
| CHARGE NOW FIRST | 4 | 4 | 2 | 0.67 | -183 | -91.7 |
| FALLS SHORT | 67 | 61 | 2 | 0.67 | +20 | +9.8 |
| FOLLOW UP WEIGHED | 2 | 2 | 2 | 0.67 | +464 | +231.9 |
| LONE WIZARD KEPT IN | 2 | 2 | 2 | 0.67 | +172 | +86.0 |
| MARCH CHECK | 3 | 3 | 2 | 0.67 | +37 | +18.4 |
| MARCH OF THE TABLE | 2 | 2 | 2 | 0.67 | -14 | -6.9 |
| MISSILES IN THE MOVE | 19 | 14 | 2 | 0.67 | +28 | +14.0 |
| NEARER NOT NEEDED | 53 | 50 | 2 | 0.67 | +80 | +39.9 |
| ONE FIGHT FORMULA | 22 | 12 | 2 | 0.67 | +0 | +0.1 |
| ONE PROMISE A TARGET | 2 | 2 | 2 | 0.67 | -104 | -51.9 |
| PATHS CROSS | 2 | 2 | 2 | 0.67 | +31 | +15.6 |
| PROMISE SHOT AWAY | 2 | 2 | 2 | 0.67 | -1 | -0.5 |
| RISK BY ARC | 6 | 5 | 2 | 0.67 | +35 | +17.6 |
| SEARCH SPOT | 3 | 3 | 2 | 0.67 | +56 | +27.8 |
| SECOND LOOK | 2 | 2 | 2 | 0.67 | +81 | +40.3 |
| SHOOTERS IN TWO RANKS | 2 | 2 | 2 | 0.67 | +9 | +4.5 |
| SHOOTS FROM THE BEST SPOT | 6 | 6 | 2 | 0.67 | +54 | +26.9 |
| SHOTS IN THE MOVE | 146 | 108 | 2 | 0.67 | +90 | +45.0 |
| THE ROW IN ITS ORDER | 12 | 2 | 2 | 0.67 | +0 | +0.0 |
| WHOLE FIGHT DANGER | 16 | 16 | 2 | 0.67 | +1 | +0.3 |
| CANNON PLANNED TARGET | 41 | 41 | 1 | 0.33 | +2 | +2.2 |
| CAST JOB | 6 | 6 | 1 | 0.33 | +9 | +8.7 |
| CASTER AWAY FROM SCREEN | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| EXACT ROUND | 9 | 7 | 1 | 0.33 | +12 | +12.2 |
| HIS TURN DENIED | 4 | 4 | 1 | 0.33 | +14 | +14.0 |
| HOLDS AMBUSHERS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| KEEP FALLS | 1 | 1 | 1 | 0.33 | +53 | +53.2 |
| MANOEUVRE | 9 | 9 | 1 | 0.33 | +6 | +6.0 |
| MARCH BY THE SUM | 1 | 1 | 1 | 0.33 | +37 | +37.0 |
| MAX FOR POSITIONING | 8 | 7 | 1 | 0.33 | +0 | +0.0 |
| OPENS UP | 2 | 2 | 1 | 0.33 | +12 | +12.2 |
| PIVOT GUARDS FLANK | 1 | 1 | 1 | 0.33 | -11 | -11.0 |
| RESERVE FALL BACK | 1 | 1 | 1 | 0.33 | +72 | +72.0 |
| SHORT GUN FORWARD | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| SHOTS AFTER THE MOVES | 29 | 29 | 1 | 0.33 | +0 | +0.0 |
| STRIKE BY THE ODDS | 1 | 1 | 1 | 0.33 | +1 | +1.1 |
| STUBBORN BY POINTS | 1 | 1 | 1 | 0.33 | +19 | +19.2 |
| SUPPORT NARROWED | 1 | 1 | 1 | 0.33 | -127 | -127.3 |
| SURE REACH TOGETHER | 2 | 1 | 1 | 0.33 | +0 | +0.0 |
| TIED UP BY THE SUM | 1 | 1 | 1 | 0.33 | +35 | +35.2 |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 4 | 4 | 0 | 0.00 | - | - |
| CHARACTER GUNS | 17 | 15 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 62 | 61 | 0 | 0.00 | - | - |
| DENIED BY THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 9 | 8 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 8 | 8 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 3 | 3 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 45 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 12 | 11 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 5 | 5 | 0 | 0.00 | - | - |
| GIVES UP | 2 | 1 | 0 | 0.00 | - | - |
| GUN FIGURES | 3 | not checked | - | - | - | - |
| GUN MASK | 5 | 5 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 6 | 5 | 0 | 0.00 | - | - |
| HELPER UNSEEN | 1 | 1 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 88 | 88 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 33 | 32 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 31 | 31 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 22 | 22 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 32 | 30 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 38 | 38 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN RUN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 143 | 143 | 0 | 0.00 | - | - |
| HONEST WORTH | 8 | 7 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 25 | 25 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 2 | 2 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 5 | 3 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 1 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 5 | 5 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 4 | 4 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 23 | 18 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 8 | 7 | 0 | 0.00 | - | - |
| NO LATE CUT | 6 | 6 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 18 | 18 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 7 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 2 | not checked | - | - | - | - |
| ONE OBJECTIVE FORMULA | 31 | 24 | 0 | 0.00 | - | - |
| ONE ROUTE | 4 | 4 | 0 | 0.00 | - | - |
| OPENS A LANE | 11 | 9 | 0 | 0.00 | - | - |
| OVERRUNS AWAY | 2 | 1 | 0 | 0.00 | - | - |
| PLAN RESULT | 290 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE KNOWS THE FIGHT | 2 | 1 | 0 | 0.00 | - | - |
| PROMISE READS THE TABLE | 3 | 3 | 0 | 0.00 | - | - |
| REAL GROUND | 4 | 4 | 0 | 0.00 | - | - |
| REDIRECT COUNTER | 3 | 1 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 5 | 5 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 2 | 2 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 3 | 2 | 0 | 0.00 | - | - |
| RUN DOWN | 6 | 4 | 0 | 0.00 | - | - |
| SCOUT SPOT | 4 | 4 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 1 | 1 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 81 | not checked | - | - | - | - |
| SHOT OR CHARGE | 4 | 4 | 0 | 0.00 | - | - |
| SPELL WORTH | 17 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 24 | 23 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 1 | 1 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 21 | 21 | 0 | 0.00 | - | - |
| STANDS STILL | 296 | 289 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 11 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 11 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 10 | not checked | - | - | - | - |
| THE TABLE BINDS | 308 | not checked | - | - | - | - |
| WAITS AGAIN | 7 | 6 | 0 | 0.00 | - | - |
| WHAT THE JOINER ADDS | 3 | not checked | - | - | - | - |
| WHO FIGHTS | 2 | 2 | 0 | 0.00 | - | - |
| WHOLE FIGHT | 2 | not checked | - | - | - | - |

### Off best figure: csame-bb45c30-p29

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 3.00 | 5.00 | 28.2 |
| ARMY TABLE | rule | 1.67 | 4.33 | 92.4 |
| HOLDER ASSIGNMENT | rule | 2.00 | 0.67 | 26.3 |
| PROMISE BY ITS OWN SUM | rule | 1.00 | 0.67 | 128.8 |
| RULE SWITCHED OFF | gate | 0.33 | 1.33 | 45.3 |
| CHARGE NOT DECLARED | rule | - | 0.67 | 51.6 |
| CHARGE NOW FIRST | rule | 0.33 | 0.33 | 91.7 |
| MARCH OF THE TABLE | rule | 0.33 | 0.33 | 6.9 |
| ONE PROMISE A TARGET | rule | 0.33 | 0.33 | 51.9 |
| CHAFF PASSED | rule | - | 0.33 | 14.0 |
| PIVOT GUARDS FLANK | rule | - | 0.33 | 11.0 |
| PROMISE SHOT AWAY | rule | - | 0.33 | 1.0 |
| SET UP BY THE SET | rule | - | 0.33 | 185.3 |
| SUPPORT NARROWED | rule | - | 0.33 | 127.3 |

### Plans: csame-bb45c30-p29

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 0.7 | 50% | 38 | 0 | 0% |
| Mine | join | 2.7 | 100% | 65 | 0 | 0% |
| Mine | move | 33.3 | 98% | 2284 | 0 | 0% |
| Mine | shoot | 16.7 | 50% | 1223 | 1253 | 102% |
| Opponent | charge | 1.7 | 40% | 213 | 144 | 68% |
| Opponent | move | 35.7 | 95% | 1855 | 0 | 0% |
| Opponent | shoot | 5.0 | 73% | 365 | 296 | 81% |
| Opponent | support | 1.0 | 100% | 116 | 0 | 0% |

### Battle groups: csame-bb45c30-p29

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | REDIRECT COUNTER | 1.0 | 0% | - | - | - | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: csame-bb45c30-p29

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | - | 0 (1) | 0 (1) | - |
| Mine | Character | 12 | 0 (12) | 0 | 0 | 6 | 83% | 1.5 | 0 (6) | 0 (2) | 0 (3) | 0 (6) | 0 (5) |
| Mine | Clean-up | 1 | 82 (1) | 0 | 82 | 100 | 0% | 6.0 | - | 82 (1) | - | 82 (1) | - |
| Mine | Fast Hammer | 8 | 65 (8) | 34 | 31 | 25 | 38% | 4.2 | 50 (4) | 68 (3) | 113 (1) | 83 (4) | 46 (4) |
| Mine | Hammer | 2 | 57 (2) | 0 | 57 | 42 | 50% | 1.0 | - | 0 (1) | 97 (1) | 57 (2) | - |
| Mine | Shooter | 5 | 127 (5) | 0 | 127 | 35 | 0% | 1.4 | 214 (2) | 146 (1) | 19 (2) | 179 (3) | 19 (2) |
| Mine | War machine | 10 | 64 (10) | 64 | 0 | 0 | 0% | 1.4 | 31 (8) | 196 (2) | - | 0 (1) | 72 (9) |
| Mine | Wizard | 1 | 0 (1) | 0 | 0 | 0 | 0% | 3.0 | - | - | 0 (1) | 0 (1) | - |
| Opponent | Chaff | 4 | 0 (4) | 0 | 0 | 11 | 50% | 1.0 | 0 (3) | 0 (1) | - | 0 (4) | - |
| Opponent | Character | 9 | 17 (9) | 17 | 0 | 5 | 44% | 1.0 | 0 (1) | 0 (4) | 37 (4) | 27 (5) | 0 (4) |
| Opponent | Clean-up | 3 | 0 (3) | 0 | 0 | 0 | 100% | - | 0 (2) | 0 (1) | - | 0 (1) | 0 (2) |
| Opponent | Fast Hammer | 5 | 14 (5) | 14 | 0 | 63 | 40% | 4.0 | 0 (1) | 39 (2) | 0 (2) | 0 (3) | 39 (2) |
| Opponent | Fragile | 3 | 0 (3) | 0 | 0 | 100 | 0% | 6.0 | - | - | - | - | - |
| Opponent | Hammer | 3 | 0 (3) | 0 | 0 | 61 | 33% | 1.0 | - | 0 (1) | 0 (2) | - | 0 (3) |
| Opponent | Holder | 3 | 188 (3) | 0 | 188 | 0 | 33% | 1.0 | 0 (1) | 600 (1) | - | 300 (2) | - |
| Opponent | Shooter | 7 | 79 (7) | 16 | 63 | 18 | 0% | 1.1 | 124 (2) | 68 (3) | 64 (2) | 51 (3) | 110 (4) |
| Opponent | Wizard | 1 | 0 (1) | 0 | 0 | 0 | 0% | 1.0 | - | - | 0 (1) | - | 0 (1) |

### Charged fights: csame-bb45c30-p29

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Empire of Man | 3 | 335 | 62 | 1.0 | 1.0 | 62 | 88 | -27 | 1 of 3 | 2 of 3 | - | -27 |
| Opponent | Lizardmen | 1 | 0 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 1 of 1 | 0 of 1 | - | +0 |
| Opponent | Tomb Kings of Khemri | 1 | 164 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Wood Elf Realms | 1 | 0 | 299 | 3.0 | 1.3 | 100 | 0 | +100 | 2 of 3 | 3 of 3 | +189 | +55 |
| **Opponent** | all armies | 3 | 55 | 100 | 1.3 | 1.2 | 75 | 0 | +75 | 3 of 4 | 3 of 4 | +189 | +37 |

### Effective charges: csame-bb45c30-p29

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Empire of Man | 3 | 2 (net -40) | 0 | 1 (net +0) | 0 | 0 | 0 | 0 | 33% (1 of 3) |
| Opponent | Lizardmen | 1 | 1 (net +0) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 1) |

### Charged fights, damage counted: csame-bb45c30-p29

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 2 | 188 | 288 | -40 | 117 | 132 | -16 | -8.3 |
| Mine | Effective (55-75%) | 1 | 189 | 208 | +0 | 0 | 0 | +0 | +0.0 |
| Mine | All fights | 3 | 188 | 261 | -27 | 78 | 88 | -10 | -5.5 |
| Opponent | Long shot (under 50%) | 1 | 185 | 189 | +0 | 0 | 37 | -37 | -20.0 |
| Opponent | No odds | 3 | 35 | 163 | +100 | 174 | 61 | +113 | +325.9 |
| Opponent | All fights | 4 | 72 | 169 | +75 | 130 | 55 | +75 | +104.5 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| csame-bb45c30-p29 | move | 18 | 2 (11%) | 2 (11%) | 1 (6%) | 15 (83%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Horn of the Wild Hunt | Opponent | L0733 |
| Ring of Doom | Opponent | L0733 |
| Twice-Blessed Armour | Mine | L0717, L0733 |
| Witch Hunter's Ward | Mine | L0717, L0733, L0823 |

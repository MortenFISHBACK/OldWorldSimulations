# Doctrine scorecard: csame-bb45c30-p36

### Scorecard: csame-bb45c30-p36

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L2531 | 5 | 1 | Mine | yes | - | 4 | 3 | 3 | 0 | 0 | 0 | 211 |
| L2531 | 5 | 1 | Opponent | yes | - | 2 | 2 | 3 | 1 | 0 | 0 | 170 |
| L2730 | 6 | 1 | Mine | no | 0 | 2 | 8 | 2 | 0 | 0 | 0 | 0 |
| L2730 | 6 | 1 | Opponent | no | 3 | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L2934 | 6 | 1 | Mine | - | - | - | - | - | - | - | - | - |
| L2934 | 6 | 1 | Opponent | - | - | - | - | - | - | - | - | - |
| **Average** | | | Mine | 50% | 0.0 | 3.0 | 5.5 | 2.5 | 0.0 | 0.0 | 0.0 | 105.5 |
| **Average** | | | Opponent | 50% | 3.0 | 2.0 | 2.5 | 2.0 | 0.5 | 0.0 | 0.0 | 85.0 |

### KPIs: csame-bb45c30-p36

Rules off - Opponent only: NO OLD ONE-MOVE GUESS; both sides: ONE RUN A PLAN.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 13) | 0% (0 of 10) | 0% (0 of 23) |
| Winner chose to follow up after the loser gave ground |  | 100% (1 of 1); on the table 100% | 60% (3 of 5); on the table 60% | 67% (4 of 6); on the table 67% |
| Winner chose to pursue after the loser fell back in good order |  | - | - | - |
| Winner chose to pursue after the loser fled |  | - | - | - |
| Winner chose to follow up or pursue (all three) |  | 100% (1 of 1); on the table 100% | 60% (3 of 5); on the table 60% | 67% (4 of 6); on the table 67% |
| Magic missiles tried each own turn | 50%+ | 67% (4 of 6) | 17% (1 of 6) | 42% (5 of 12) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 67% (4 of 6) | 25% (1 of 4) | 50% (5 of 10) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 100% (2 of 2) | 86% (6 of 7) | 89% (8 of 9) |
| Points that never fought | lower | 41% (1639 of 3999) | 27% (1063 of 4000) | 34% (2702 of 7999) |
|   infantry points that never fought | lower | 68% (310 of 457) | 87% (489 of 559) | 79% (799 of 1016) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 58% (7 of 12) | 78% (14 of 18) | 70% (21 of 30) |
| Bound items with a magic missile used (at least once a game) |  | 0.0 uses a game | 100% (1 of 1); 0.3 uses a game | 100% (1 of 1); 0.2 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |
|   their share of the points of units over 100 pts | lower | 44% (1383 of 3154) | 80% (2937 of 3654) | 63% (4320 of 6808) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 0.7 (100%) | 1.0 (60%) | 1.7 (71%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.3 (20%) | 0.3 (14%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (0%) | 0.3 (20%) | 0.3 (14%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 1.3 | 1.3 | 1.3 | 1.7 | 0.7 | 1.0 |
| not cast | 4.7 | 0.0 | 2.7 | 2.3 | 1.3 | 20.0 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | - | 0.3 (12%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | - | 0.0 (0%) | 1.7 (71%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | - | 0.0 (0%) | 0.3 (14%) | 0.0 (0%) | 0.0 (0%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (0%) | - | 0.0 (0%) | 0.3 (14%) | 0.0 (0%) | 0.3 (2%) |
| STUPIDITY: Stupidity | 0.0 (0%) | - | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (3%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | - | 0.0 (0%) | 0.0 (0%) | 1.3 (100%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 4.7 (100%) | - | 2.3 (88%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | - | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 19.0 (95%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.3 a game | 0.0 a game | 0.7 a game |
| stood (cast and not dispelled) | 100% (4 of 4) | - | 100% (4 of 4) |
| the unit moved after it | 100% (4 of 4) | - | 100% (4 of 4) |
| it charged on its next turn | 0% (0 of 4) | - | 0% (0 of 4) |
| the enemy charged it first | 25% (1 of 4) | - | 25% (1 of 4) |
| it fought by the end of its next turn | 0% (0 of 4) | - | 0% (0 of 4) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 4) | - | 0% (0 of 4) |
| none of these (no charge, no fight, no charge escaped) | 75% (3 of 4) | - | 75% (3 of 4) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | - | 0% (0 of 5) | 0% (0 of 5) |
|   character | - | 0% (0 of 5) | 0% (0 of 5) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| CHARGED: it charged | - | 0.7 (40%) | 0.7 (40%) |
| NO TARGET IN RANGE | - | 0.7 (40%) | 0.7 (40%) |
| ONLY IN COMBAT: the only targets were in combat | - | 0.3 (20%) | 0.3 (20%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.3 | 3.0 | 3.7 |
| Charges that made contact a game | 2.7 | 2.7 | 2.7 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.00 declared, 0.00 contact (1 units) | - | 0.00 declared, 0.00 contact (1 units) |
|   per unit a game, units carrying another wizard (or one alone) | 1.33 declared, 1.00 contact (3 units) | 0.00 declared, 0.00 contact (1 units) | 1.00 declared, 0.75 contact (4 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.38 declared, 0.21 contact (24 units) | 0.35 declared, 0.31 contact (26 units) | 0.36 declared, 0.26 contact (50 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 80% (4 of 5) | 67% (2 of 3) | 0% (0 of 1) | 67% (6 of 9) |
| Character in a unit | 100% (3 of 3) | 0% (0 of 1) | - | 75% (3 of 4) |
| Character on its own | 50% (2 of 4) | 100% (2 of 2) | 50% (2 of 4) | 60% (6 of 10) |
| Infantry | 75% (3 of 4) | - | - | 75% (3 of 4) |
| Monster | 100% (2 of 2) | 100% (1 of 1) | - | 100% (3 of 3) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Vampire Counts | 2 | 100% (1 of 1); on the table 100% | 67% (4 of 6) | 41% | 58% (7 of 12) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 2 | 60% (3 of 5); on the table 60% | 17% (1 of 6) | 27% | 78% (14 of 18) | 100% (1 of 1); 0.5 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (csame-bb45c30-p36, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 43% (3) | 62% (5) | 53% (8) |
| ...free all their last turn and able to turn (per game) | 1.00 | 1.33 | 2.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 1.33 | 1.33 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.33 | 0.33 |

### Quality by phase: csame-bb45c30-p36

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.7 | 3.3 |
| Strategy | Charge objectives carried out (made contact) | 55% (6 of 11) | 67% (4 of 6) |
| Strategy | Shoot objectives carried out (shot that target) | - | 0% (0 of 2) |
| Strategy | Support requests answered (helper made contact too) | 0% (0 of 1) | - |
| Strategy | Joined characters whose unit fought | 20% (1 of 5) | 100% (1 of 1) |
| Strategy | Lone characters that fought | 33% (2 of 6) | 86% (6 of 7) |
| Movement | Charges halted short of contact | 1.0 | 0.0 |
| Movement | Idle units | 2.5 | 2.0 |
| Movement | Points that never moved of their own | 105.5 | 85.0 |
| Movement | Fights charged into per game | 4.0 | 3.5 |
| Movement | Charges with odds: long shots (under 50%) | 2 of 7, net +346 | 2 of 6, net +0 |
| Movement | Charges with odds: sweet spot (55-75%) | 1 of 7, net +0 | 0 of 6 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 7 | 0 of 6 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 4 of 7, net +258 | 4 of 6, net +76 |
| Shooting | Points destroyed by shooting units | 0.0 | 0.0 |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | 0.7 | 0.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 0% (0 of 2) | 100% (1 of 1) |
| Magic | Points destroyed by magic (all spells) | 0.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.0 / 0.0 / 0.0 / 0.7 | 0.0 / 1.0 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 417.3 | 220.7 |
| Combat | Points run down | 23.3 | 0.0 |
| Combat | Net points per charged fight, damage counted | +219 | +79 |
| Combat | Net per 100 charger points, damage counted | +76.8 | +27.1 |
| Combat | First round won (charged fights) | 88% | 86% |
| Combat | Net points per charged fight | +241 | +70 |
| Combat | Net points per supported fight / lone fight | - / +241 | +231 / +44 |
| Combat | Charged fights on a top-3 enemy unit | 3 of 8 | 3 of 7 |
| Game | Points lost | 331.0 | 1097.5 |
| Game | VP from objectives | 610.0 | 580.0 |
| Game | Lone holders (player turns) | 0.0 | 3.0 |

- Mine won / drew / lost: 2 / 0 / 0 of 2 ended games (of 3); mean margin (Mine - Opponent) +846 VP
- The side that went first won 1 of 2 games with a winner
- Points traded per game (both sides' losses): 1428
- Games not ended: 1 (L2934-1); findings 2, warnings 0

### Opponent rules: csame-bb45c30-p36

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | - | - | - | - | 0.7 | +302.5 | 0.0 | 67.0 |
| ARMY TABLE | 19.7 | +522.1 | 0.0 | 99.0 | 16.0 | -339.4 | 0.0 | 347.7 |
| ASSAILMENT BY POINTS | 0.3 | +2.3 | 0.0 | 0.0 | - | - | - | - |
| CAST JOB | - | - | - | - | 1.7 | +10.0 | 84.7 | 0.0 |
| CASTER AWAY FROM SCREEN | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CASTS FROM BEHIND | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | 3.0 | +81.2 | 0.0 | 0.0 | - | - | - | - |
| CHALLENGE BY POINTS | 0.3 | +7.4 | 0.0 | 84.7 | 1.0 | +44.2 | 0.0 | 67.0 |
| CHARGE LOSSES | 6.3 | -125.0 | 0.0 | 0.0 | 6.0 | -393.7 | 0.0 | 320.0 |
| CHARGE NOW FIRST | 2.7 | +0.0 | 358.7 | 62.0 | 1.0 | +0.0 | 194.3 | 0.0 |
| CLOSES ON WHAT IT BEATS | 19.7 | +0.0 | 0.0 | 0.0 | 7.7 | +0.0 | 0.0 | 0.0 |
| COMBAT PIVOT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CONVEYANCE SEARCH | 1.0 | +155.5 | 0.0 | 0.0 | - | - | - | - |
| COVER ONCE | 4.0 | -257.4 | 0.0 | 0.0 | 7.7 | -321.1 | 0.0 | 194.7 |
| DEPLOY BY FIGURES | 7.0 | +107.4 | 0.0 | 0.0 | 7.3 | -37.6 | 0.0 | 0.0 |
| EXACT ROUND | 3.7 | +12.7 | 437.0 | 62.0 | 2.0 | +25.5 | 74.0 | 0.0 |
| FALL BACK GOOD ORDER | 3.7 | +9.1 | 376.3 | 62.0 | 2.7 | +0.0 | 305.3 | 0.0 |
| FALLS SHORT | 15.7 | +238.7 | 0.0 | 74.0 | - | - | - | - |
| FEATURE BUFFS | - | - | - | - | 0.3 | +3.5 | 0.0 | 32.7 |
| FIGHT TO THE END | 2.0 | +74.7 | 253.3 | 62.0 | 1.0 | +61.0 | 49.0 | 0.0 |
| FIRE IN ORDER | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| FIVE ACTION | 70.3 | +3439.2 | 504.0 | 260.0 | 57.0 | +4388.8 | 390.0 | 1205.0 |
| FLANK NOT WEIGHED | 5.0 | +0.0 | 0.0 | 49.0 | 10.7 | +0.0 | 0.0 | 276.0 |
| FOCUS FIRE | - | - | - | - | 0.3 | +5.7 | 0.0 | 0.0 |
| FOLLOW UP WEIGHED | 0.7 | +77.6 | 0.0 | 62.0 | 1.3 | +333.7 | 0.0 | 0.0 |
| FOUR ROUNDS | 4.3 | +502.0 | 504.0 | 62.0 | 3.0 | +384.8 | 305.3 | 0.0 |
| FREED FROM HIS FIGHT | 4.0 | +0.0 | 0.0 | 0.0 | 4.7 | +0.0 | 0.0 | 304.3 |
| GIVES UP | - | - | - | - | 1.0 | -16.4 | 111.0 | 0.0 |
| GOAL WALK | 6.7 | +581.4 | 0.0 | 0.0 | 10.0 | +871.2 | 0.0 | 302.0 |
| HARD STAY DROPPED | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | - | - | - | - | 3.0 | +0.0 | 0.0 | 239.0 |
| HELPER UNSEEN | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 3.7 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 320.0 |
| HIS CHARGE DENIED | - | - | - | - | 0.7 | +3.2 | 0.0 | 0.0 |
| HIS CHARGE LIST | 0.3 | +0.0 | 0.0 | 0.0 | 8.7 | +0.0 | 0.0 | 553.3 |
| HIS LEGAL MOVES | 2.3 | +0.0 | 0.0 | 0.0 | 4.7 | +0.0 | 0.0 | 254.7 |
| HIS MOVE AND SHOT | 2.7 | -13.6 | 0.0 | 0.0 | 0.3 | -1.7 | 0.0 | 0.0 |
| HIS MOVE AS HE DECIDES | - | - | - | - | 34.3 | +8.3 | 161.0 | 0.0 |
| HIS MOVE WHY | 21.0 | +0.0 | 0.0 | 74.0 | - | - | - | - |
| HIS ONE MOVE | - | - | - | - | 13.3 | +7.1 | 0.0 | 293.7 |
| HIS ONE QUARTER | 1.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 5.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVE | 12.7 | +0.0 | 0.0 | 148.0 | 4.0 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVER COMES | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS RUN AFTER OUR TURN | 4.7 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 18.0 | +171.2 | 0.0 | 49.0 | 7.7 | +18.1 | 0.0 | 0.0 |
| HIS SHOTS BY HIS RUN | 17.0 | +120.7 | 0.0 | 49.0 | 4.7 | +5.2 | 0.0 | 0.0 |
| HIS TURN RUN | 4.7 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 14.0 | +0.0 | 0.0 | 0.0 | 13.3 | +0.0 | 0.0 | 210.0 |
| HOLDER ASSIGNMENT | 8.7 | +868.7 | 0.0 | 0.0 | 8.7 | +952.5 | 0.0 | 121.3 |
| HOLDS AMBUSHERS | 0.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 3.7 | -139.2 | 471.3 | 62.0 | 2.0 | -81.6 | 256.3 | 0.0 |
| IDLE COST | 20.7 | -246.8 | 0.0 | 49.0 | - | - | - | - |
| JOINT CHARGE NOW | 0.7 | -2.2 | 89.3 | 0.0 | 0.3 | -54.2 | 84.7 | 0.0 |
| JOINT LOOK BACK | - | - | - | - | 0.3 | +3.6 | 84.7 | 0.0 |
| KEPT FROM ITS LAST STOP | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 1.0 | +42.8 | 0.0 | 0.0 | 0.7 | +13.7 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 5.0 | +0.0 | 308.0 | 338.7 | 2.7 | +0.0 | 146.7 | 190.0 |
| LOST AFTER ESCAPE | 3.7 | +16.0 | 380.3 | 62.0 | 1.0 | -2.1 | 84.7 | 0.0 |
| LOST CHARGE | - | - | - | - | 0.3 | -0.9 | 84.7 | 0.0 |
| MANOEUVRE | 1.7 | -16.7 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| MARCH AT ESCAPER | - | - | - | - | 0.3 | +2.2 | 0.0 | 0.0 |
| MARCH BY THE SUM | - | - | - | - | 0.7 | +9.9 | 0.0 | 0.0 |
| MARCH CHECK | - | - | - | - | 0.3 | +2.0 | 0.0 | 0.0 |
| MARCH OF THE TABLE | - | - | - | - | 0.3 | +37.6 | 0.0 | 0.0 |
| MARCH OVER CASTS | 0.3 | +61.2 | 0.0 | 0.0 | 0.7 | +54.1 | 0.0 | 67.0 |
| MARCH WHEELS ONLY | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 1.0 | +25.5 | 0.0 | 0.0 | 3.0 | +20.6 | 0.0 | 23.3 |
| MEETS IN TIME | 3.7 | +311.9 | 0.0 | 0.0 | 3.3 | +260.0 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 1.7 | +5.7 | 0.0 | 0.0 | 2.0 | +37.8 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 1.7 | +3.2 | 0.0 | 0.0 | 3.3 | +49.9 | 0.0 | 67.0 |
| MOVE ORDER | 2.7 | +0.0 | 49.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 5.7 | +406.7 | 0.0 | 0.0 | 3.7 | +243.1 | 0.0 | 159.7 |
| NEARER NOT NEEDED | 7.3 | +264.6 | 0.0 | 0.0 | 7.7 | +334.4 | 0.0 | 98.0 |
| NEXT CHARGE BY LIST | 5.0 | +346.1 | 0.0 | 0.0 | 2.3 | +151.0 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 3.7 | -225.0 | 438.7 | 62.0 | 2.0 | -145.5 | 243.3 | 0.0 |
| NO LATE CUT | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 4.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NO SECOND RUN | 4.7 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | - | - | - | - | 0.3 | +31.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 2.7 | -0.8 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 3.3 | -52.2 | 0.0 | 49.0 | 3.3 | -192.6 | 62.0 | 101.7 |
| ONE CHALLENGE TEST | - | - | - | - | 1.0 | +57.2 | 169.3 | 0.0 |
| ONE CHECK AFTER THE LAST CHANGE | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 3.0 | -87.3 | 0.0 | 0.0 | 2.7 | -39.3 | 0.0 | 0.0 |
| ONE JOINT FIGURE | 0.3 | +2.5 | 56.7 | 0.0 | 0.3 | +45.7 | 0.0 | 0.0 |
| ONE OBJECTIVE FORMULA | 4.0 | -20.0 | 0.0 | 0.0 | 4.3 | +18.0 | 0.0 | 88.7 |
| ONE PROMISE A TARGET | 0.7 | -39.1 | 0.0 | 0.0 | - | - | - | - |
| ONE ROUTE | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| OVERRUNS AWAY | 0.3 | +1.9 | 32.7 | 0.0 | - | - | - | - |
| PATHS CROSS | 1.0 | +20.7 | 0.0 | 0.0 | - | - | - | - |
| PIVOT GUARDS FLANK | - | - | - | - | 0.3 | -7.3 | 0.0 | 0.0 |
| PLAN RESULT | 36.0 | +361.3 | 478.0 | 356.7 | 24.0 | +307.9 | 347.3 | 946.3 |
| PROMISE BY ITS OWN SUM | 6.7 | -78.9 | 0.0 | 0.0 | 7.7 | -319.7 | 0.0 | 159.7 |
| PROMISE KNOWS THE FIGHT | 0.3 | -0.6 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| QUARTER ODDS | 8.0 | +667.1 | 67.0 | 50.0 | 9.0 | +1074.8 | 25.0 | 134.0 |
| RANDOM MOVE BY FIGURES | 0.7 | +44.3 | 0.0 | 0.0 | 2.3 | +20.4 | 0.0 | 0.0 |
| REAL GROUND | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| REDIRECT BY WHAT IT STOPS | 1.3 | +87.3 | 0.0 | 0.0 | - | - | - | - |
| REDIRECT COUNTER | 3.7 | +223.9 | 0.0 | 25.0 | 1.3 | +69.1 | 0.0 | 23.3 |
| REDIRECT FOR A FRIEND IN REACH | 3.0 | +52.3 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 23.3 |
| REFORMS TO MEET IT | 2.0 | -5.6 | 0.0 | 0.0 | 0.3 | -0.5 | 0.0 | 0.0 |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| RISK BY ARC | 3.3 | +165.5 | 480.7 | 62.0 | 2.7 | +202.3 | 305.3 | 0.0 |
| RISK ON THE WAY | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| ROUNDS AFTER TERROR | 1.7 | -29.9 | 192.0 | 0.0 | - | - | - | - |
| RUN DOWN | 4.0 | -57.7 | 447.3 | 62.0 | - | - | - | - |
| SCREEN BY WHAT IT SAVES | 2.3 | -123.0 | 0.0 | 0.0 | - | - | - | - |
| SEARCH SPOT | 1.3 | -3.2 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| SECOND LOOK | 0.3 | +1.3 | 0.0 | 0.0 | 0.7 | +87.9 | 62.0 | 0.0 |
| SET CREDITED ONCE | 1.0 | -22.2 | 0.0 | 0.0 | 1.3 | -7.2 | 0.0 | 0.0 |
| SET UP BY THE SET | 2.7 | +36.7 | 69.0 | 0.0 | 1.3 | +7.2 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 2.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 69.0 |
| SHOT OR CHARGE | - | - | - | - | 0.3 | -0.2 | 0.0 | 0.0 |
| SHOT RISK POINTS | 7.3 | -56.4 | 0.0 | 0.0 | 2.3 | -8.6 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | - | - | - | - | 1.7 | +12.7 | 0.0 | 0.0 |
| SPELL WORTH | 1.3 | +9.9 | 0.0 | 0.0 | - | - | - | - |
| SPELLS IN THE FIGHT | - | - | - | - | 0.3 | -0.3 | 0.0 | 0.0 |
| SPOT AS THE GAME MOVES | 7.3 | +0.0 | 0.0 | 98.0 | 6.0 | +0.0 | 0.0 | 162.0 |
| STANDS STILL | 12.0 | +0.0 | 0.0 | 149.0 | 20.3 | +0.0 | 84.7 | 144.7 |
| STAY WORTH | - | - | - | - | 3.7 | +76.3 | 84.7 | 0.0 |
| STUCK PIVOT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| STUPIDITY NEXT TURN | 2.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SUPPORT ADDS | 4.0 | +256.1 | 0.0 | 50.0 | 5.7 | +727.2 | 0.0 | 207.0 |
| SUPPORT NARROWED | 1.0 | +0.0 | 69.0 | 0.0 | 1.0 | +0.0 | 194.3 | 0.0 |
| SUPPORT WORKED OUT | 4.0 | +256.1 | 0.0 | 50.0 | 5.7 | +727.2 | 0.0 | 207.0 |
| SWIFTSTRIDE BY POINTS | - | - | - | - | 0.3 | -3.4 | 0.0 | 159.7 |
| THE DEARER SUM KEEPS ITS PLAN | 1.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| THE PROMISE ADDS | 0.3 | -1.4 | 0.0 | 0.0 | - | - | - | - |
| THE ROW IN ITS ORDER | 1.7 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 32.7 |
| THE ROW KEEPS ITS WAY | 3.0 | +0.0 | 0.0 | 49.0 | 2.7 | +0.0 | 0.0 | 23.3 |
| THE STEP BACK IS MADE | 1.7 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 23.3 |
| THE TABLE AGAIN | 4.7 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 37.7 | +0.0 | 0.0 | 99.0 | 26.7 | +0.0 | 0.0 | 637.0 |
| TIED UP BY THE SUM | 1.0 | +72.8 | 134.3 | 0.0 | 1.0 | +109.1 | 74.0 | 0.0 |
| TIME ON OUR SIDE | - | - | - | - | 35.3 | +410.8 | 0.0 | 714.7 |
| WAITS AGAIN | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| WALKS ON ITS ROUTE | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| WHAT THE JOINER ADDS | 1.3 | -31.3 | 130.7 | 0.0 | 0.7 | +23.7 | 124.0 | 0.0 |
| WHO FIGHTS | 1.3 | +42.1 | 127.7 | 62.0 | 0.7 | -18.5 | 49.0 | 0.0 |
| WHO HITS BACK | 1.0 | +116.6 | 0.0 | 84.7 | 0.3 | +3.3 | 0.0 | 0.0 |
| WHOLE FIGHT | 0.7 | +33.5 | 65.3 | 0.0 | 0.3 | -34.5 | 62.0 | 0.0 |
| WHOLE FIGHT DANGER | 1.7 | -77.7 | 0.0 | 0.0 | 3.7 | -381.1 | 0.0 | 320.0 |
| WHOLE FIGHT GAIN | 0.3 | +1.3 | 56.7 | 0.0 | - | - | - | - |
| WOUNDS ON THE RANKS | 0.7 | +1.0 | 0.0 | 0.0 | - | - | - | - |

### Rule changes: csame-bb45c30-p36

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS MOVE AS HE DECIDES | 103 | 103 | 78 | 26.00 | +0 | +0.0 |
| ARMY TABLE | 107 | 107 | 60 | 20.00 | +2098 | +35.0 |
| HOLDER ASSIGNMENT | 52 | 52 | 47 | 15.67 | +3088 | +65.7 |
| HIS MOVE WHY | 63 | 63 | 46 | 15.33 | +0 | +0.0 |
| FIVE ACTION | 382 | 367 | 40 | 13.33 | +2795 | +69.9 |
| DEPLOY BY FIGURES | 43 | 43 | 24 | 8.00 | +122 | +5.1 |
| LEGAL CHARGES ONLY | 23 | 23 | 23 | 7.67 | +0 | +0.0 |
| THE TABLE AGAIN | 27 | 27 | 22 | 7.33 | +0 | +0.0 |
| OFF BEST | 20 | 20 | 20 | 6.67 | -734 | -36.7 |
| GOAL WALK | 50 | 50 | 19 | 6.33 | +1269 | +66.8 |
| IDLE COST | 62 | 43 | 17 | 5.67 | +108 | +6.4 |
| PROMISE BY ITS OWN SUM | 43 | 43 | 16 | 5.33 | -1195 | -74.7 |
| FOUR ROUNDS | 22 | 19 | 15 | 5.00 | +1057 | +70.4 |
| HIS ONE MOVE | 40 | 36 | 13 | 4.33 | +0 | +0.0 |
| MEETS IN TIME | 21 | 21 | 13 | 4.33 | +865 | +66.5 |
| MOVE ORDER | 12 | 12 | 12 | 4.00 | +0 | +0.0 |
| QUARTER ODDS | 51 | 50 | 12 | 4.00 | +1114 | +92.9 |
| HIS SHOT LIST | 77 | 72 | 10 | 3.33 | +22 | +2.2 |
| MOVE TO CHARGE COMPUTED | 28 | 22 | 9 | 3.00 | +227 | +25.3 |
| REDIRECT FOR A FRIEND IN REACH | 11 | 11 | 9 | 3.00 | +0 | +0.0 |
| RISK BY ARC | 18 | 16 | 9 | 3.00 | +345 | +38.3 |
| TIME ON OUR SIDE | 106 | 85 | 9 | 3.00 | +98 | +10.9 |
| RANDOM MOVE BY FIGURES | 9 | 9 | 8 | 2.67 | +194 | +24.3 |
| SUPPORT ADDS | 29 | 29 | 7 | 2.33 | +167 | +23.9 |
| SUPPORT WORKED OUT | 29 | 29 | 7 | 2.33 | +167 | +23.9 |
| ADVANCE LANE KEPT | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 6 | 6 | 6 | 2.00 | +1234 | +205.7 |
| HOLDS AMBUSHERS | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| TIED UP BY THE SUM | 6 | 6 | 6 | 2.00 | +175 | +29.2 |
| CHAFF IN THE MOVE | 9 | 9 | 5 | 1.67 | +21 | +4.1 |
| CHARGE LOSSES | 37 | 34 | 5 | 1.67 | +201 | +40.2 |
| EXACT ROUND | 17 | 16 | 5 | 1.67 | +31 | +6.1 |
| HARD STAY DROPPED | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| LANE BY FIGURES | 5 | 5 | 5 | 1.67 | +170 | +33.9 |
| SET UP BY THE SET | 12 | 11 | 5 | 1.67 | +221 | +44.3 |
| WHOLE FIGHT DANGER | 16 | 16 | 5 | 1.67 | +178 | +35.7 |
| CASTS FROM BEHIND | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| CHALLENGE BY POINTS | 4 | 4 | 4 | 1.33 | +155 | +38.7 |
| FIGHT TO THE END | 9 | 9 | 4 | 1.33 | +124 | +31.1 |
| MAX FOR POSITIONING | 12 | 11 | 4 | 1.33 | +6 | +1.5 |
| NEXT CHARGE BY LIST | 22 | 17 | 4 | 1.33 | +35 | +8.7 |
| STAY WORTH | 11 | 9 | 4 | 1.33 | +204 | +51.0 |
| WHO HITS BACK | 4 | 4 | 4 | 1.33 | +310 | +77.6 |
| CHARGE NOW FIRST | 11 | 11 | 3 | 1.00 | -195 | -65.1 |
| FALLS SHORT | 47 | 35 | 3 | 1.00 | +0 | +0.0 |
| HIS SHOTS BY HIS RUN | 65 | 59 | 3 | 1.00 | +11 | +3.8 |
| JOINT CHARGE NOW | 3 | 3 | 3 | 1.00 | -170 | -56.5 |
| PATHS CROSS | 3 | 3 | 3 | 1.00 | +62 | +20.7 |
| SECOND LOOK | 3 | 3 | 3 | 1.00 | +268 | +89.2 |
| SUPPORT NARROWED | 6 | 6 | 3 | 1.00 | -164 | -54.5 |
| AFTERMATH IN POINTS | 2 | 2 | 2 | 0.67 | +907 | +453.7 |
| COVER ONCE | 35 | 21 | 2 | 0.67 | +23 | +11.4 |
| MARCH BY THE SUM | 2 | 2 | 2 | 0.67 | +30 | +14.8 |
| ONE CHALLENGE TEST | 3 | 3 | 2 | 0.67 | +14 | +6.9 |
| ONE PROMISE A TARGET | 2 | 2 | 2 | 0.67 | -117 | -58.6 |
| REDIRECT BY WHAT IT STOPS | 4 | 4 | 2 | 0.67 | +80 | +40.1 |
| REDIRECT COUNTER | 15 | 15 | 2 | 0.67 | +7 | +3.7 |
| WHOLE FIGHT | 3 | 2 | 2 | 0.67 | +4 | +2.2 |
| ASSAILMENT BY POINTS | 1 | 1 | 1 | 0.33 | +7 | +7.0 |
| CAST JOB | 5 | 5 | 1 | 0.33 | +4 | +4.5 |
| CASTER AWAY FROM SCREEN | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| COMBAT PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FIRE IN ORDER | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FOCUS FIRE | 1 | 1 | 1 | 0.33 | +17 | +17.0 |
| HIS MOVE AND SHOT | 9 | 8 | 1 | 0.33 | +0 | +0.5 |
| JOINT LOOK BACK | 1 | 1 | 1 | 0.33 | +11 | +10.6 |
| LOST AFTER ESCAPE | 14 | 13 | 1 | 0.33 | +0 | +0.3 |
| MARCH OF THE TABLE | 1 | 1 | 1 | 0.33 | -113 | -112.7 |
| MISSILES IN THE MOVE | 11 | 4 | 1 | 0.33 | +65 | +64.9 |
| NEARER NOT NEEDED | 45 | 41 | 1 | 0.33 | +15 | +14.6 |
| ONE JOINT FIGURE | 2 | 2 | 1 | 0.33 | +12 | +12.2 |
| ONE OBJECTIVE FORMULA | 25 | 22 | 1 | 0.33 | +40 | +39.7 |
| OVERRUNS AWAY | 1 | 1 | 1 | 0.33 | +4 | +4.1 |
| PIVOT GUARDS FLANK | 1 | 1 | 1 | 0.33 | -22 | -21.8 |
| PROMISE KNOWS THE FIGHT | 2 | 2 | 1 | 0.33 | -2 | -1.7 |
| REFUSING RETIRES | 2 | 2 | 1 | 0.33 | +0 | +0.3 |
| SEARCH SPOT | 5 | 5 | 1 | 0.33 | +93 | +93.0 |
| SHOT RISK POINTS | 29 | 25 | 1 | 0.33 | +0 | +0.0 |
| STUCK PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| SWIFTSTRIDE BY POINTS | 1 | 1 | 1 | 0.33 | -10 | -10.1 |
| THE ROW IN ITS ORDER | 17 | 1 | 1 | 0.33 | +0 | +0.0 |
| WALKS ON ITS ROUTE | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| WHO FIGHTS | 6 | 6 | 1 | 0.33 | +42 | +42.3 |
| WOUNDS ON THE RANKS | 2 | 2 | 1 | 0.33 | +1 | +0.7 |
| CASTS AFTER FRIENDS | 4 | trace | - | - | - | - |
| CLOSES ON WHAT IT BEATS | 82 | 81 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 3 | not checked | - | - | - | - |
| FALL BACK GOOD ORDER | 19 | 16 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 1 | 1 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 47 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 26 | 26 | 0 | 0.00 | - | - |
| GIVES UP | 3 | 1 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 9 | 9 | 0 | 0.00 | - | - |
| HELPER UNSEEN | 1 | 1 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 29 | 28 | 0 | 0.00 | - | - |
| HIS CHARGE DENIED | 2 | 2 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 27 | 26 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 21 | 19 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 5 | 5 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 18 | 17 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 50 | 47 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 3 | 3 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 27 | 27 | 0 | 0.00 | - | - |
| HIS TURN RUN | 27 | 27 | 0 | 0.00 | - | - |
| HOLD ODDS | 82 | 81 | 0 | 0.00 | - | - |
| HONEST WORTH | 17 | 15 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 5 | 5 | 0 | 0.00 | - | - |
| LOST CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| MANOEUVRE | 6 | 6 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH CHECK | 1 | 1 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 3 | 3 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 2 | 2 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 15 | 9 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 17 | 16 | 0 | 0.00 | - | - |
| NO LATE CUT | 2 | 2 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 14 | 14 | 0 | 0.00 | - | - |
| NO SECOND RUN | 27 | 27 | 0 | 0.00 | - | - |
| NOT TURNED | 1 | 1 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 8 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 3 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 17 | 7 | 0 | 0.00 | - | - |
| ONE ROUTE | 2 | 2 | 0 | 0.00 | - | - |
| PLAN RESULT | 180 | trace | - | - | - | - |
| REAL GROUND | 2 | 2 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 7 | 6 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 1 | 1 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 5 | 4 | 0 | 0.00 | - | - |
| RUN DOWN | 12 | 11 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 7 | 7 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 7 | 6 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 12 | not checked | - | - | - | - |
| SHOT OR CHARGE | 1 | not checked | - | - | - | - |
| SHOTS IN THE MOVE | 5 | 3 | 0 | 0.00 | - | - |
| SPELL WORTH | 4 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 1 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 40 | 37 | 0 | 0.00 | - | - |
| STANDS STILL | 97 | 93 | 0 | 0.00 | - | - |
| STUPIDITY NEXT TURN | 7 | 7 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 6 | not checked | - | - | - | - |
| THE PROMISE ADDS | 1 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 17 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 10 | not checked | - | - | - | - |
| THE TABLE BINDS | 193 | not checked | - | - | - | - |
| WAITS AGAIN | 5 | 5 | 0 | 0.00 | - | - |
| WHAT THE JOINER ADDS | 6 | 4 | 0 | 0.00 | - | - |
| WHOLE FIGHT GAIN | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: csame-bb45c30-p36

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| PROMISE BY ITS OWN SUM | rule | 1.33 | 4.00 | 74.7 |
| JOB FIRST | gate | 1.67 | 2.00 | 34.7 |
| RULE SWITCHED OFF | gate | 0.67 | 1.00 | 48.8 |
| ARMY TABLE | rule | 0.33 | 0.67 | 74.4 |
| CHARGE NOW FIRST | rule | 1.00 | - | 65.1 |
| JOINT CHARGE NOW | rule | 0.67 | 0.33 | 56.5 |
| SUPPORT NARROWED | rule | 0.67 | 0.33 | 54.5 |
| FALLBACK | gate | 0.33 | 0.33 | 52.3 |
| ONE PROMISE A TARGET | rule | 0.67 | - | 58.6 |
| AFTERMATH BAND | gate | 0.33 | - | 2.3 |
| FIGHT ORDER BAND | gate | 0.33 | - | 2.3 |
| HOLDER ASSIGNMENT | rule | 0.33 | - | 59.2 |
| MARCH OF THE TABLE | rule | - | 0.33 | 112.7 |
| PIVOT GUARDS FLANK | rule | - | 0.33 | 21.8 |
| PROMISE KNOWS THE FIGHT | rule | 0.33 | - | 1.7 |
| SWIFTSTRIDE BY POINTS | rule | - | 0.33 | 10.1 |
| WHO HITS BACK | rule | 0.33 | - | 2.3 |

### Plans: csame-bb45c30-p36

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 3.7 | 64% | 538 | 361 | 67% |
| Mine | join | 4.3 | 100% | 171 | 0 | 0% |
| Mine | move | 26.3 | 99% | 1048 | 0 | 0% |
| Mine | support | 1.7 | 100% | 75 | 0 | 0% |
| Opponent | charge | 2.7 | 50% | 353 | 308 | 87% |
| Opponent | join | 1.3 | 100% | 45 | 0 | 0% |
| Opponent | move | 19.3 | 93% | 1725 | 0 | 0% |
| Opponent | shoot | 0.7 | 0% | 51 | 0 | 0% |

### Battle groups: csame-bb45c30-p36

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 3.7 | 9% | 100% | 0% | - | 0% | 0% | 0% | 100% | 0% |
| Opponent | REDIRECT COUNTER | 1.3 | 25% | 0% | 0% | - | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: csame-bb45c30-p36

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 8 | 91 (8) | 0 | 91 | 15 | 75% | 4.0 | 0 (4) | 229 (2) | 156 (2) | 146 (5) | 0 (3) |
| Mine | Character | 7 | 105 (7) | 105 | 0 | 0 | 57% | 4.3 | 155 (2) | 0 (4) | 0 (1) | 114 (5) | 0 (2) |
| Mine | Fast | 1 | 67 (1) | 67 | 0 | 100 | 0% | 2.0 | - | 67 (1) | - | - | 67 (1) |
| Mine | Fast Hammer | 4 | 61 (4) | 50 | 11 | 17 | 25% | 4.0 | - | 13 (3) | 295 (1) | 13 (3) | 295 (1) |
| Mine | Support | 2 | 0 (2) | 0 | 0 | 73 | 50% | 2.0 | 0 (1) | 0 (1) | - | 0 (1) | 0 (1) |
| Mine | Wizard | 4 | 0 (4) | 0 | 0 | 0 | 50% | 1.0 | 0 (2) | 0 (1) | 0 (1) | 0 (3) | 0 (1) |
| Opponent | Chaff | 1 | 343 (1) | 0 | 343 | 100 | 0% | 6.0 | - | 343 (1) | - | 343 (1) | - |
| Opponent | Character | 8 | 34 (8) | 34 | 0 | 71 | 12% | 3.1 | - | 58 (5) | 0 (1) | 33 (5) | 219 (1) |
| Opponent | Fast Hammer | 5 | 34 (5) | 0 | 34 | 78 | 0% | 3.4 | 50 (2) | 0 (1) | 39 (2) | 51 (2) | 26 (3) |
| Opponent | Hammer | 4 | 19 (4) | 0 | 19 | 27 | 75% | 2.0 | - | 19 (4) | - | 0 (2) | 42 (2) |
| Opponent | Holder | 4 | 0 (4) | 0 | 0 | 0 | 100% | - | 0 (1) | 0 (1) | 0 (1) | - | 0 (3) |

### Charged fights: csame-bb45c30-p36

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Vampire Counts | 2 | 0 | 965 | 4.0 | 1.0 | 241 | 0 | +241 | 3 of 8 | 7 of 8 | - | +241 |
| Opponent | Warriors of Chaos | 2 | 0 | 331 | 3.5 | 1.1 | 95 | 24 | +70 | 3 of 7 | 6 of 7 | +231 | +44 |

### Effective charges: csame-bb45c30-p36

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Vampire Counts | 8 | 2 (net +346) | 0 | 1 (net +0) | 0 | 0 | 4 (net +258) | 1 | 14% (1 of 7) |
| Opponent | Warriors of Chaos | 7 | 2 (net +0) | 0 | 0 | 0 | 0 | 4 (net +76) | 1 | 0% (0 of 6) |

### Charged fights, damage counted: csame-bb45c30-p36

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 2 | 367 | 186 | +346 | 346 | 90 | +256 | +69.9 |
| Mine | Effective (55-75%) | 1 | 186 | 285 | +0 | 0 | 0 | +0 | +0.0 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 4 | 222 | 138 | +258 | 258 | 0 | +258 | +116.0 |
| Mine | No odds | 1 | 471 | 207 | +207 | 207 | 0 | +207 | +43.9 |
| Mine | All fights | 8 | 285 | 177 | +241 | 241 | 22 | +219 | +76.8 |
| Opponent | Long shot (under 50%) | 2 | 298 | 410 | +0 | 32 | 0 | +32 | +10.6 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 4 | 236 | 166 | +76 | 119 | 42 | +76 | +32.4 |
| Opponent | No odds | 1 | 510 | 186 | +186 | 186 | 0 | +186 | +36.5 |
| Opponent | All fights | 7 | 293 | 238 | +70 | 104 | 24 | +79 | +27.1 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| csame-bb45c30-p36 | move | 14 | 0 (0%) | 0 (0%) | 4 (29%) | 10 (71%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L2531, L2730 |
| Charmed Shield | Opponent | L2934 |
| Invocation of Nehek | Mine | L2531, L2730 |
| Ring of Doom | Opponent | L2531 |

# Doctrine scorecard: csame-bb45c30-p12

### Scorecard: csame-bb45c30-p12

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L2531 | 5 | 1 | Mine | yes | - | 4 | 4 | 4 | 0 | 0 | 0 | 0 |
| L2531 | 5 | 1 | Opponent | yes | - | 2 | 3 | 1 | 0 | 0 | 0 | 170 |
| L2730 | 6 | 1 | Mine | no | 0 | 2 | 4 | 1 | 0 | 0 | 0 | 60 |
| L2730 | 6 | 1 | Opponent | no | 3 | 2 | 3 | 2 | 0 | 0 | 0 | 0 |
| L2934 | 6 | 1 | Mine | no | 3 | 3 | 1 | 2 | 0 | 0 | 0 | 170 |
| L2934 | 6 | 1 | Opponent | no | 2 | 3 | 3 | 2 | 0 | 0 | 0 | 91 |
| **Average** | | | Mine | 33% | 1.5 | 3.0 | 3.0 | 2.3 | 0.0 | 0.0 | 0.0 | 76.7 |
| **Average** | | | Opponent | 33% | 2.5 | 2.3 | 3.0 | 1.7 | 0.0 | 0.0 | 0.0 | 87.0 |

### KPIs: csame-bb45c30-p12

Rules off - Mine only: NO OLD ONE-MOVE GUESS; both sides: ONE RUN A PLAN.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 16) | 0% (0 of 16) | 0% (0 of 32) |
| Winner chose to follow up after the loser gave ground |  | 80% (4 of 5); on the table 80% | 89% (8 of 9); on the table 100% | 86% (12 of 14); on the table 93% |
| Winner chose to pursue after the loser fell back in good order |  | 100% (1 of 1); on the table 100% | - | 100% (1 of 1); on the table 100% |
| Winner chose to pursue after the loser fled |  | 0% (0 of 2); on the table 50% | 50% (1 of 2); on the table 50% | 25% (1 of 4); on the table 50% |
| Winner chose to follow up or pursue (all three) |  | 62% (5 of 8); on the table 75% | 82% (9 of 11); on the table 91% | 74% (14 of 19); on the table 84% |
| Magic missiles tried each own turn | 50%+ | 67% (4 of 6) | 17% (1 of 6) | 42% (5 of 12) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 80% (4 of 5) | 20% (1 of 5) | 50% (5 of 10) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 80% (4 of 5) | 71% (5 of 7) | 75% (9 of 12) |
| Points that never fought | lower | 29% (1760 of 5998) | 28% (1657 of 5998) | 28% (3417 of 11996) |
|   infantry points that never fought | lower | 86% (780 of 902) | 13% (136 of 1072) | 46% (916 of 1974) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 63% (12 of 19) | 65% (17 of 26) | 64% (29 of 45) |
| Bound items with a magic missile used (at least once a game) |  | 0.0 uses a game | 100% (1 of 1); 0.3 uses a game | 100% (1 of 1); 0.2 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |
|   their share of the points of units over 100 pts | lower | 56% (2842 of 5038) | 57% (3056 of 5360) | 57% (5898 of 10398) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 0.3 (50%) | 1.3 (80%) | 1.7 (71%) |
| IN COMBAT: engaged in combat | 0.3 (50%) | 0.3 (20%) | 0.7 (29%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.3 | 1.3 | 1.7 | 1.7 | 0.3 | 2.0 |
| not cast | 1.7 | 0.0 | 2.3 | 2.3 | 1.7 | 22.0 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | - | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.0 (5%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | - | 0.0 (0%) | 1.7 (71%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | - | 0.3 (14%) | 0.7 (29%) | 0.0 (0%) | 0.0 (0%) |
| STUPIDITY: Stupidity | 0.3 (20%) | - | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (3%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | - | 0.0 (0%) | 0.0 (0%) | 1.7 (100%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.3 (80%) | - | 2.0 (86%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | - | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 20.3 (92%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.7 a game | 0.0 a game | 0.8 a game |
| stood (cast and not dispelled) | 80% (4 of 5) | - | 80% (4 of 5) |
| the unit moved after it | 100% (4 of 4) | - | 100% (4 of 4) |
| it charged on its next turn | 25% (1 of 4) | - | 25% (1 of 4) |
| the enemy charged it first | 0% (0 of 4) | - | 0% (0 of 4) |
| it fought by the end of its next turn | 0% (0 of 4) | - | 0% (0 of 4) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 4) | - | 0% (0 of 4) |
| none of these (no charge, no fight, no charge escaped) | 75% (3 of 4) | - | 75% (3 of 4) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 22% (2 of 9) | 67% (22 of 33) | 57% (24 of 42) |
|   cavalry | 40% (2 of 5) | 92% (11 of 12) | 76% (13 of 17) |
|   character | 0% (0 of 4) | 18% (2 of 11) | 13% (2 of 15) |
|   infantry | - | 90% (9 of 10) | 90% (9 of 10) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 0.0 (0%) | 0.3 (9%) | 0.3 (6%) |
| CHARGED: it charged | 1.0 (43%) | 2.3 (64%) | 3.3 (56%) |
| NO TARGET IN RANGE | 1.3 (57%) | 0.3 (9%) | 1.7 (28%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.0 (0%) | 0.7 (18%) | 0.7 (11%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 8.3 | 1.3 | 88% | 1.7 pts | 14 pts |
| character | 0.7 | 0.0 | 100% | 0.0 pts | 0 pts |
| infantry | 5.0 | 0.3 | 93% | 0.4 pts | 2 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 5.3 | 4.7 | 5.0 |
| Charges that made contact a game | 3.7 | 4.3 | 4.0 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.00 declared, 0.00 contact (1 units) | - | 0.00 declared, 0.00 contact (1 units) |
|   per unit a game, units carrying another wizard (or one alone) | 1.00 declared, 0.75 contact (4 units) | 0.00 declared, 0.00 contact (1 units) | 0.80 declared, 0.60 contact (5 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.55 declared, 0.36 contact (22 units) | 0.54 declared, 0.50 contact (26 units) | 0.54 declared, 0.44 contact (48 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 71% (5 of 7) | 60% (3 of 5) | 100% (1 of 1) | 69% (9 of 13) |
| Character in a unit | 100% (4 of 4) | 100% (2 of 2) | 100% (1 of 1) | 100% (7 of 7) |
| Character on its own | 67% (2 of 3) | 0% (0 of 1) | 14% (1 of 7) | 27% (3 of 11) |
| Infantry | 57% (4 of 7) | 100% (1 of 1) | - | 62% (5 of 8) |
| Monster | 67% (2 of 3) | 100% (1 of 1) | - | 75% (3 of 4) |
| Monstrous | 100% (2 of 2) | - | - | 100% (2 of 2) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Vampire Counts | 2 | 50% (3 of 6); on the table 67% | 67% (4 of 6) | 22% | 75% (9 of 12) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 3 | 90% (9 of 10); on the table 100% | 17% (1 of 6) | 36% | 64% (16 of 25) | 100% (1 of 1); 0.3 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Wood Elf Realms | 1 | 67% (2 of 3); on the table 67% | - | 20% | 50% (4 of 8) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (csame-bb45c30-p12, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 44% (4) | 78% (7) | 61% (11) |
| ...free all their last turn and able to turn (per game) | 0.33 | 1.33 | 1.67 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.33 | 0.33 |
| ...with the charger already in that arc before they moved (per game) | 0.33 | 1.33 | 1.67 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.67 | 0.67 |

### Quality by phase: csame-bb45c30-p12

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.7 | 3.3 |
| Strategy | Charge objectives carried out (made contact) | 33% (5 of 15) | 92% (11 of 12) |
| Strategy | Shoot objectives carried out (shot that target) | 0% (0 of 2) | 20% (2 of 10) |
| Strategy | Support requests answered (helper made contact too) | 100% (2 of 2) | 0% (0 of 1) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (4 of 4) | - |
| Strategy | Joined characters whose unit fought | 50% (3 of 6) | 67% (2 of 3) |
| Strategy | Lone characters that fought | 86% (6 of 7) | 71% (5 of 7) |
| Movement | Charges halted short of contact | 0.7 | 0.0 |
| Movement | Idle units | 2.3 | 1.7 |
| Movement | Points that never moved of their own | 76.7 | 87.0 |
| Movement | Fights charged into per game | 3.3 | 4.3 |
| Movement | Charges with odds: long shots (under 50%) | 2 of 9, net +0 | 1 of 10, net +0 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 9 | 0 of 10 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 3 of 9, net +216 | 3 of 10, net +43 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 4 of 9, net -65 | 3 of 10, net +83 |
| Shooting | Shots by shooting units (incl. breath weapons) | 1.7 | 9.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 80% (4 of 5) | 34% (10 of 29) |
| Shooting | Points destroyed by shooting units | 0.0 | 0.0 |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Points destroyed by magic (all spells) | 0.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 3.7 / 0.0 / 0.3 / 0.3 | 0.0 / 1.3 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 278.0 | 246.7 |
| Combat | Points run down | 49.0 | 0.0 |
| Combat | Net points per charged fight, damage counted | +24 | +67 |
| Combat | Net per 100 charger points, damage counted | +7.4 | +22.8 |
| Combat | First round won (charged fights) | 70% | 77% |
| Combat | Net points per charged fight | +49 | +40 |
| Combat | Net points per supported fight / lone fight | -261 / +83 | - / +40 |
| Combat | Charged fights on a top-3 enemy unit | 5 of 10 | 4 of 13 |
| Game | Points lost | 325.0 | 413.7 |
| Game | VP from objectives | 466.7 | 560.0 |
| Game | Lone holders (player turns) | 1.5 | 2.5 |

- Mine won / drew / lost: 0 / 2 / 1 of 3 ended games (of 3); mean margin (Mine - Opponent) -105 VP
- The side that went first won 1 of 1 games with a winner
- Points traded per game (both sides' losses): 739
- Games not ended: 0; findings 1, warnings 0

### Opponent rules: csame-bb45c30-p12

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.3 | +91.7 | 0.0 | 0.0 | 0.3 | +27.2 | 0.0 | 0.0 |
| ARMY TABLE | 21.7 | +492.4 | 0.0 | 233.3 | 18.3 | -381.2 | 0.0 | 196.0 |
| ASSAILMENT BY POINTS | 0.7 | +2.4 | 0.0 | 0.0 | - | - | - | - |
| BACKUP TARGETS | 0.3 | +5.5 | 0.0 | 0.0 | 0.3 | +0.5 | 0.0 | 0.0 |
| CAST JOB | 1.0 | +4.0 | 56.7 | 0.0 | 2.0 | +14.9 | 199.3 | 77.3 |
| CASTER AWAY FROM SCREEN | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CASTS FROM BEHIND | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | 1.0 | +10.3 | 0.0 | 15.0 | 1.0 | +22.3 | 0.0 | 0.0 |
| CHALLENGE BY POINTS | 0.7 | +31.3 | 0.0 | 0.0 | 1.0 | +46.4 | 0.0 | 123.0 |
| CHARGE LOSSES | 12.0 | -234.7 | 0.0 | 68.3 | 7.0 | -278.7 | 0.0 | 280.3 |
| CHARGE NOT DECLARED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHARGE NOW FIRST | 3.0 | +0.0 | 261.0 | 0.0 | 2.0 | +0.0 | 198.7 | 0.0 |
| CLOSES ON WHAT IT BEATS | 15.3 | +0.0 | 0.0 | 55.0 | 14.7 | +0.0 | 0.0 | 9.0 |
| COMBAT PIVOT | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CONTINUE AHEAD WEIGHED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CONVEYANCE SEARCH | 1.3 | +17.2 | 0.0 | 0.0 | - | - | - | - |
| COVER ONCE | 8.7 | -437.2 | 0.0 | 68.3 | 7.3 | -306.0 | 0.0 | 107.3 |
| DENIED BY THE FIGHT | 0.3 | -0.5 | 0.0 | 0.0 | - | - | - | - |
| DEPLOY BY FIGURES | 7.0 | +107.4 | 0.0 | 0.0 | 7.3 | -37.6 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | - | - | - | - | 0.3 | -122.6 | 0.0 | 0.0 |
| EDGE GIVE GROUND | - | - | - | - | 0.3 | +6.5 | 68.3 | 0.0 |
| EVASIVE BY THE ODDS | - | - | - | - | 0.7 | +2.7 | 28.3 | 0.0 |
| EXACT ROUND | 3.3 | +142.8 | 39.3 | 68.3 | 2.0 | +5.1 | 122.0 | 0.0 |
| FALL BACK GOOD ORDER | 4.7 | +0.8 | 240.7 | 0.0 | 3.0 | +0.0 | 245.3 | 0.0 |
| FALLBACK BY WORTH | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| FALLS SHORT | 23.3 | +281.1 | 0.0 | 15.0 | 3.7 | +26.0 | 0.0 | 0.0 |
| FEATURE BUFFS | 0.3 | +0.8 | 0.0 | 0.0 | 1.0 | +10.7 | 0.0 | 65.3 |
| FIGHT TO THE END | 1.0 | +102.2 | 0.0 | 0.0 | 0.3 | +0.1 | 0.0 | 0.0 |
| FIRE IN ORDER | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| FIVE ACTION | 81.0 | +4240.8 | 306.3 | 495.0 | 84.0 | +5209.7 | 473.0 | 714.0 |
| FLANK NOT WEIGHED | 7.7 | +0.0 | 0.0 | 96.7 | 10.3 | +0.0 | 0.0 | 256.0 |
| FOCUS FIRE | - | - | - | - | 0.3 | +5.7 | 0.0 | 0.0 |
| FOLLOW UP WEIGHED | 2.0 | +152.4 | 0.0 | 0.0 | 2.0 | +252.0 | 0.0 | 0.0 |
| FOUR ROUNDS | 5.3 | +535.5 | 249.7 | 68.3 | 4.3 | +413.1 | 273.7 | 0.0 |
| FREED FROM HIS FIGHT | 1.3 | +0.0 | 0.0 | 0.0 | 15.0 | +0.0 | 0.0 | 126.0 |
| FRIEND CHARGES FIRST | - | - | - | - | 0.3 | -0.1 | 0.0 | 0.0 |
| GIVES UP | - | - | - | - | 1.0 | -16.3 | 16.7 | 0.0 |
| GOAL WALK | 6.3 | +569.0 | 0.0 | 68.3 | 12.7 | +1036.9 | 0.0 | 0.0 |
| HARD STAY DROPPED | 0.3 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 38.7 |
| HE REFORMS ONCE FREED | 0.3 | +0.0 | 0.0 | 0.0 | 12.0 | +0.0 | 0.0 | 65.3 |
| HELPER UNSEEN | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS CHARGE BY HIS RUN | 8.7 | +0.0 | 0.0 | 68.3 | 6.0 | +0.0 | 0.0 | 219.7 |
| HIS CHARGE DENIED | 0.7 | +141.4 | 9.0 | 68.3 | 0.3 | +6.1 | 15.0 | 0.0 |
| HIS CHARGE LIST | 1.7 | +0.0 | 0.0 | 96.7 | 8.3 | +0.0 | 0.0 | 106.7 |
| HIS LEGAL MOVES | 3.0 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 1.0 | -11.6 | 0.0 | 28.3 | - | - | - | - |
| HIS MOVE AS HE DECIDES | 45.0 | +12.0 | 641.3 | 0.0 | - | - | - | - |
| HIS MOVE WHY | - | - | - | - | 13.7 | +0.0 | 0.0 | 32.7 |
| HIS ONE MOVE | 20.0 | -24.9 | 0.0 | 30.0 | - | - | - | - |
| HIS OWN BEST MOVE | 2.0 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVE | 12.0 | +0.0 | 0.0 | 63.3 | 13.3 | +0.0 | 0.0 | 262.0 |
| HIS RANDOM MOVER COMES | 1.3 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 137.3 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 34.3 | +519.1 | 0.0 | 320.0 | 14.3 | +125.2 | 0.0 | 245.3 |
| HIS SHOTS BY HIS RUN | 31.0 | +383.0 | 0.0 | 265.0 | 7.7 | +63.1 | 0.0 | 265.3 |
| HIS TURN DENIED | 0.3 | +6.2 | 0.0 | 0.0 | 0.3 | +0.9 | 0.0 | 0.0 |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 15.7 | +0.0 | 0.0 | 113.3 | 16.3 | +0.0 | 0.0 | 130.7 |
| HOLDER ASSIGNMENT | 10.0 | +887.7 | 0.0 | 56.7 | 10.0 | +1102.6 | 0.0 | 32.7 |
| HOLDS AMBUSHERS | 0.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 5.3 | -207.8 | 249.7 | 68.3 | 4.0 | -134.4 | 205.3 | 0.0 |
| HUNT IN PAIRS | - | - | - | - | 0.3 | +26.3 | 0.0 | 0.0 |
| IDLE COST | 16.3 | -252.1 | 0.0 | 141.7 | 4.0 | -43.4 | 0.0 | 66.7 |
| JOINT CHARGE NOW | 1.7 | +37.1 | 0.0 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 0.7 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 1.0 | +42.8 | 0.0 | 0.0 | 0.7 | +13.7 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 8.3 | +0.0 | 250.0 | 378.0 | 10.0 | +0.0 | 171.7 | 66.7 |
| LONG SHOT | - | - | - | - | 0.3 | -1.7 | 15.0 | 0.0 |
| LOST AFTER ESCAPE | 3.3 | +78.2 | 72.7 | 0.0 | 2.0 | +0.2 | 68.3 | 0.0 |
| LURE BY WHAT IT DRAWS | - | - | - | - | 0.3 | -21.0 | 0.0 | 0.0 |
| MANOEUVRE | 1.3 | +0.0 | 0.0 | 0.0 | 0.7 | -0.1 | 0.0 | 0.0 |
| MARCH BY THE SUM | - | - | - | - | 0.3 | +7.4 | 0.0 | 0.0 |
| MARCH OF THE TABLE | - | - | - | - | 0.3 | +37.6 | 0.0 | 0.0 |
| MARCH OVER CASTS | - | - | - | - | 0.3 | -1.8 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | - | - | - | - | 2.0 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 4.3 | +121.5 | 0.0 | 43.3 | 2.7 | +66.4 | 0.0 | 9.0 |
| MEETS IN TIME | 3.7 | +311.9 | 0.0 | 0.0 | 3.3 | +260.0 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 1.7 | +5.2 | 0.0 | 0.0 | 1.7 | +22.1 | 0.0 | 38.7 |
| MISSILES NEXT TURN | 1.7 | +3.4 | 0.0 | 0.0 | 2.7 | +27.0 | 0.0 | 38.7 |
| MOVE ORDER | 3.0 | +0.0 | 15.0 | 31.7 | 1.3 | +0.0 | 0.0 | 32.7 |
| MOVE TO CHARGE COMPUTED | 8.0 | +512.5 | 0.0 | 0.0 | 3.3 | +238.3 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 9.3 | +360.0 | 0.0 | 0.0 | 8.0 | +325.6 | 0.0 | 88.0 |
| NEXT CHARGE BY LIST | 6.3 | +392.1 | 0.0 | 0.0 | 4.0 | +309.2 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 3.7 | -282.0 | 240.7 | 0.0 | 3.3 | -113.1 | 196.7 | 0.0 |
| NO LATE CUT | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | - | - | - | - | 0.7 | +19.5 | 0.0 | 0.0 |
| NOT WORTH A CAST | 0.7 | -0.2 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 5.7 | -101.2 | 0.0 | 30.0 | 3.3 | -98.4 | 0.0 | 0.0 |
| ONE CHALLENGE TEST | 0.3 | +1.1 | 30.3 | 0.0 | 0.7 | -4.9 | 0.0 | 0.0 |
| ONE CHECK AFTER THE LAST CHANGE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ONE FIGHT FORMULA | 7.3 | -111.0 | 0.0 | 15.0 | 4.0 | -124.4 | 0.0 | 0.0 |
| ONE JOINT FIGURE | 0.3 | +2.5 | 0.0 | 0.0 | - | - | - | - |
| ONE OBJECTIVE FORMULA | 5.3 | -26.4 | 0.0 | 56.7 | 4.3 | +54.5 | 0.0 | 32.7 |
| ONE PROMISE A TARGET | 0.3 | +5.1 | 0.0 | 0.0 | 0.3 | -32.5 | 0.0 | 0.0 |
| ONE ROUTE | - | - | - | - | 2.0 | +0.0 | 0.0 | 0.0 |
| OPENS UP | 0.3 | +17.0 | 30.3 | 0.0 | 0.7 | +57.3 | 43.3 | 0.0 |
| OVERRUNS AWAY | 2.0 | +19.9 | 83.7 | 0.0 | - | - | - | - |
| PATHS CROSS | 1.7 | +39.9 | 0.0 | 0.0 | 0.7 | +11.5 | 0.0 | 0.0 |
| PLAN RESULT | 43.7 | +335.1 | 119.7 | 352.0 | 43.0 | +442.3 | 417.0 | 674.0 |
| PROMISE BY ITS OWN SUM | 8.0 | -151.6 | 0.0 | 0.0 | 8.0 | -525.1 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | 2.3 | -0.6 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | 0.3 | -21.6 | 0.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | 6.7 | +589.3 | 48.0 | 0.0 | 5.0 | +785.5 | 0.0 | 0.0 |
| RANDOM MOVE BY FIGURES | 1.7 | +69.0 | 0.0 | 0.0 | 2.3 | +4.8 | 0.0 | 0.0 |
| REAL GROUND | - | - | - | - | 2.0 | +0.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | 4.0 | +212.7 | 0.0 | 45.0 | 2.3 | -1.6 | 0.0 | 9.0 |
| REDIRECT FOR A FRIEND IN REACH | 1.7 | +0.0 | 0.0 | 58.3 | 2.3 | +0.0 | 0.0 | 9.0 |
| REFORMS TO MEET IT | 0.3 | -1.3 | 0.0 | 0.0 | 0.3 | -21.8 | 0.0 | 0.0 |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 68.3 | 0.7 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | 0.3 | +36.3 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | 4.7 | +48.4 | 249.7 | 68.3 | 3.7 | +90.1 | 245.3 | 0.0 |
| ROUNDS AFTER TERROR | 1.7 | -43.3 | 134.0 | 0.0 | 0.7 | -20.6 | 28.3 | 0.0 |
| RUN DOWN | 4.3 | -98.0 | 204.3 | 0.0 | 1.7 | -12.0 | 165.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 1.3 | -85.5 | 0.0 | 30.0 | 1.3 | -28.5 | 0.0 | 0.0 |
| SEARCH SPOT | 1.0 | +31.0 | 0.0 | 0.0 | 1.0 | +13.6 | 0.0 | 0.0 |
| SECOND LOOK | - | - | - | - | 0.3 | +27.1 | 62.0 | 0.0 |
| SET CREDITED ONCE | 2.3 | -28.9 | 0.0 | 30.0 | 1.3 | -42.1 | 0.0 | 9.0 |
| SET UP BY THE SET | 4.7 | +31.9 | 32.7 | 30.0 | 1.7 | +113.3 | 0.0 | 9.0 |
| SET UP TOGETHER | 0.7 | +1.3 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS ON THE TABLE | 1.3 | +0.0 | 0.0 | 15.0 | 4.3 | +0.0 | 0.0 | 38.7 |
| SHOOTS FROM THE BEST SPOT | - | - | - | - | 1.3 | +25.8 | 0.0 | 0.0 |
| SHOT OR CHARGE | - | - | - | - | 1.3 | -17.2 | 15.0 | 0.0 |
| SHOT RISK POINTS | 11.3 | -92.3 | 0.0 | 183.3 | 5.7 | -32.7 | 0.0 | 177.3 |
| SHOTS AFTER THE MOVES | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 0.7 | +3.7 | 0.0 | 28.3 | 7.3 | +59.1 | 0.0 | 53.3 |
| SPELL WORTH | 3.0 | +5.5 | 0.0 | 0.0 | - | - | - | - |
| SPOT AS THE GAME MOVES | 10.7 | +0.0 | 0.0 | 56.7 | 5.0 | +0.0 | 0.0 | 75.7 |
| STAND AND SHOOT | - | - | - | - | 0.3 | -1.3 | 28.3 | 0.0 |
| STANDS FOR A REASON | 0.7 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 15.7 | +0.0 | 56.7 | 0.0 | 31.7 | +0.0 | 199.3 | 214.3 |
| STAY WORTH | 0.3 | +0.2 | 0.0 | 0.0 | 10.7 | +30.7 | 0.0 | 53.3 |
| STRIKE BY THE ODDS | 0.7 | +1.0 | 0.0 | 62.0 | - | - | - | - |
| STUCK PIVOT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| STUPIDITY NEXT TURN | 2.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SUPPORT ADDS | 12.7 | +844.1 | 0.0 | 125.0 | 7.3 | +1015.6 | 0.0 | 32.7 |
| SUPPORT NARROWED | 1.0 | +0.0 | 9.0 | 68.3 | 0.3 | +0.0 | 62.0 | 0.0 |
| SUPPORT WORKED OUT | 12.7 | +844.1 | 0.0 | 125.0 | 7.3 | +1015.6 | 0.0 | 32.7 |
| SURE REACH TOGETHER | - | - | - | - | 0.3 | +4.3 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 2.0 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| THE PROMISE ADDS | 1.3 | -68.3 | 0.0 | 15.0 | - | - | - | - |
| THE PROMISED MOVE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE ROW IN ITS ORDER | 2.7 | +0.0 | 0.0 | 28.3 | 2.3 | +0.0 | 0.0 | 36.3 |
| THE ROW KEEPS ITS WAY | 5.3 | +0.0 | 0.0 | 28.3 | 2.7 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 3.0 | +0.0 | 0.0 | 28.3 | 1.7 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 41.0 | +0.0 | 0.0 | 228.3 | 39.7 | +0.0 | 0.0 | 357.0 |
| TIED UP BY THE SUM | 2.3 | +322.3 | 213.3 | 68.3 | 1.7 | +240.5 | 213.7 | 0.0 |
| TIME ON OUR SIDE | 5.3 | +68.1 | 0.0 | 56.7 | 53.7 | +539.6 | 30.0 | 474.7 |
| WAITS AGAIN | 5.3 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| WHAT THE JOINER ADDS | 2.7 | -28.5 | 0.0 | 0.0 | 1.3 | +30.2 | 124.0 | 0.0 |
| WHO GETS IN | 0.7 | +18.3 | 0.0 | 0.0 | - | - | - | - |
| WHO HITS BACK | 0.7 | +245.9 | 0.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT | 1.3 | -7.2 | 0.0 | 0.0 | 0.7 | -20.2 | 62.0 | 0.0 |
| WHOLE FIGHT DANGER | 3.7 | -163.1 | 0.0 | 0.0 | 3.7 | -226.1 | 0.0 | 210.0 |
| WHOLE FIGHT GAIN | 0.3 | +1.3 | 0.0 | 0.0 | - | - | - | - |
| WOUNDS ON THE RANKS | 0.3 | +0.5 | 0.0 | 0.0 | 0.7 | +5.3 | 0.0 | 0.0 |

### Rule changes: csame-bb45c30-p12

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS MOVE AS HE DECIDES | 135 | 135 | 99 | 33.00 | +0 | +0.0 |
| ARMY TABLE | 120 | 120 | 78 | 26.00 | +1824 | +23.4 |
| HOLDER ASSIGNMENT | 60 | 60 | 55 | 18.33 | +3675 | +66.8 |
| LEGAL CHARGES ONLY | 55 | 55 | 55 | 18.33 | +0 | +0.0 |
| THE TABLE AGAIN | 36 | 36 | 34 | 11.33 | +0 | +0.0 |
| FIVE ACTION | 495 | 473 | 27 | 9.00 | +2219 | +82.2 |
| OFF BEST | 27 | 27 | 27 | 9.00 | -599 | -22.2 |
| HIS MOVE WHY | 41 | 41 | 25 | 8.33 | +0 | +0.0 |
| DEPLOY BY FIGURES | 43 | 43 | 24 | 8.00 | +122 | +5.1 |
| TIME ON OUR SIDE | 177 | 153 | 24 | 8.00 | +32 | +1.3 |
| GOAL WALK | 57 | 56 | 20 | 6.67 | +1266 | +63.3 |
| SUPPORT ADDS | 60 | 56 | 19 | 6.33 | +1447 | +76.2 |
| SUPPORT WORKED OUT | 60 | 56 | 19 | 6.33 | +1447 | +76.2 |
| FOUR ROUNDS | 29 | 28 | 18 | 6.00 | +866 | +48.1 |
| HIS ONE MOVE | 60 | 57 | 18 | 6.00 | +0 | +0.0 |
| PROMISE BY ITS OWN SUM | 48 | 48 | 18 | 6.00 | -2030 | -112.8 |
| HIS SHOT LIST | 146 | 134 | 15 | 5.00 | +105 | +7.0 |
| MEETS IN TIME | 21 | 21 | 13 | 4.33 | +865 | +66.5 |
| MOVE ORDER | 13 | 13 | 13 | 4.33 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 12 | 12 | 12 | 4.00 | +1213 | +101.1 |
| HIS SHOTS BY HIS RUN | 116 | 113 | 12 | 4.00 | +184 | +15.3 |
| IDLE COST | 61 | 41 | 12 | 4.00 | +118 | +9.8 |
| REDIRECT FOR A FRIEND IN REACH | 12 | 12 | 12 | 4.00 | +0 | +0.0 |
| HARD STAY DROPPED | 11 | 11 | 11 | 3.67 | +0 | +0.0 |
| TIED UP BY THE SUM | 12 | 11 | 11 | 3.67 | +284 | +25.8 |
| FALLS SHORT | 81 | 65 | 9 | 3.00 | +17 | +1.9 |
| MAX FOR POSITIONING | 21 | 20 | 9 | 3.00 | +37 | +4.1 |
| MOVE TO CHARGE COMPUTED | 34 | 23 | 9 | 3.00 | +256 | +28.4 |
| NEXT CHARGE BY LIST | 31 | 23 | 9 | 3.00 | +285 | +31.7 |
| RANDOM MOVE BY FIGURES | 12 | 12 | 9 | 3.00 | +221 | +24.6 |
| CAST JOB | 9 | 9 | 7 | 2.33 | +3 | +0.4 |
| EXACT ROUND | 16 | 15 | 7 | 2.33 | +167 | +23.9 |
| PATHS CROSS | 7 | 7 | 7 | 2.33 | +154 | +22.1 |
| QUARTER ODDS | 35 | 34 | 7 | 2.33 | +897 | +128.1 |
| RISK BY ARC | 25 | 24 | 7 | 2.33 | +101 | +14.4 |
| ADVANCE LANE KEPT | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| CHARGE NOW FIRST | 15 | 15 | 6 | 2.00 | -235 | -39.1 |
| HOLDS AMBUSHERS | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| SET UP BY THE SET | 19 | 18 | 6 | 2.00 | +304 | +50.6 |
| CHAFF IN THE MOVE | 6 | 6 | 5 | 1.67 | +0 | +0.0 |
| CHALLENGE BY POINTS | 5 | 5 | 5 | 1.67 | +233 | +46.6 |
| JOINT CHARGE NOW | 5 | 5 | 5 | 1.67 | +111 | +22.2 |
| LANE BY FIGURES | 5 | 5 | 5 | 1.67 | +170 | +33.9 |
| LOST AFTER ESCAPE | 16 | 16 | 5 | 1.67 | +112 | +22.5 |
| CASTS FROM BEHIND | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| COVER ONCE | 48 | 32 | 4 | 1.33 | +69 | +17.2 |
| SEARCH SPOT | 6 | 6 | 4 | 1.33 | +134 | +33.4 |
| WHOLE FIGHT DANGER | 22 | 21 | 4 | 1.33 | +50 | +12.5 |
| REDIRECT COUNTER | 19 | 16 | 3 | 1.00 | +161 | +53.7 |
| AFTERMATH IN POINTS | 2 | 2 | 2 | 0.67 | +357 | +178.3 |
| ASSAILMENT BY POINTS | 2 | 2 | 2 | 0.67 | +7 | +3.5 |
| COMBAT PIVOT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| HONEST WORTH | 28 | 27 | 2 | 0.67 | +60 | +30.1 |
| NEARER NOT NEEDED | 52 | 49 | 2 | 0.67 | +55 | +27.4 |
| ONE OBJECTIVE FORMULA | 29 | 28 | 2 | 0.67 | +133 | +66.5 |
| ONE PROMISE A TARGET | 2 | 2 | 2 | 0.67 | -82 | -41.1 |
| OPENS UP | 3 | 3 | 2 | 0.67 | +73 | +36.3 |
| OVERRUNS AWAY | 6 | 6 | 2 | 0.67 | +0 | +0.0 |
| STAY WORTH | 33 | 28 | 2 | 0.67 | +16 | +8.1 |
| STRIKE BY THE ODDS | 2 | 2 | 2 | 0.67 | +3 | +1.5 |
| SUPPORT NARROWED | 4 | 4 | 2 | 0.67 | -331 | -165.6 |
| WHAT THE JOINER ADDS | 12 | 10 | 2 | 0.67 | +67 | +33.3 |
| WHO GETS IN | 2 | 2 | 2 | 0.67 | +55 | +27.4 |
| WHO HITS BACK | 2 | 2 | 2 | 0.67 | +594 | +297.1 |
| CASTER AWAY FROM SCREEN | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CHARGE NOT DECLARED | 1 | 1 | 1 | 0.33 | -80 | -80.0 |
| CONTINUE AHEAD WEIGHED | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FIRE IN ORDER | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FOCUS FIRE | 1 | 1 | 1 | 0.33 | +17 | +17.0 |
| HUNT IN PAIRS | 1 | 1 | 1 | 0.33 | +19 | +18.8 |
| MANOEUVRE | 6 | 6 | 1 | 0.33 | +0 | +0.5 |
| MARCH BY THE SUM | 1 | 1 | 1 | 0.33 | +22 | +22.3 |
| MARCH OF THE TABLE | 1 | 1 | 1 | 0.33 | -113 | -112.7 |
| ONE CHALLENGE TEST | 3 | 3 | 1 | 0.33 | +0 | +0.0 |
| PROMISE KNOWS THE FIGHT | 8 | 4 | 1 | 0.33 | -2 | -1.7 |
| REFUSING RETIRES | 3 | 3 | 1 | 0.33 | -32 | -32.0 |
| RESERVE FALL BACK | 1 | 1 | 1 | 0.33 | +109 | +108.8 |
| SECOND LOOK | 1 | 1 | 1 | 0.33 | +81 | +81.4 |
| SET UP TOGETHER | 2 | 2 | 1 | 0.33 | +0 | +0.0 |
| SHOT RISK POINTS | 51 | 48 | 1 | 0.33 | +2 | +2.4 |
| SHOTS AFTER THE MOVES | 4 | 4 | 1 | 0.33 | +0 | +0.0 |
| SHOTS IN THE MOVE | 24 | 17 | 1 | 0.33 | +5 | +4.9 |
| STUCK PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| BACKUP TARGETS | 2 | 2 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 5 | trace | - | - | - | - |
| CHARGE LOSSES | 57 | 54 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 90 | 88 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 4 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 1 | 1 | 0 | 0.00 | - | - |
| EDGE GIVE GROUND | 1 | 1 | 0 | 0.00 | - | - |
| EVASIVE BY THE ODDS | 2 | 2 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 23 | 22 | 0 | 0.00 | - | - |
| FALLBACK BY WORTH | 2 | 2 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 4 | 4 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 54 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 49 | 48 | 0 | 0.00 | - | - |
| FRIEND CHARGES FIRST | 1 | 1 | 0 | 0.00 | - | - |
| GIVES UP | 3 | 3 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 37 | 36 | 0 | 0.00 | - | - |
| HELPER UNSEEN | 1 | 1 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 44 | 43 | 0 | 0.00 | - | - |
| HIS CHARGE DENIED | 3 | 3 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 30 | 30 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 16 | 12 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 3 | 3 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 17 | 14 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 76 | 69 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 12 | 12 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 2 | 2 | 0 | 0.00 | - | - |
| HIS TURN RUN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 96 | 96 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 11 | 11 | 0 | 0.00 | - | - |
| LONG SHOT | 1 | 1 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 1 | 1 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 1 | 1 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 6 | 6 | 0 | 0.00 | - | - |
| MISSILES IN THE MOVE | 10 | 5 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 13 | 7 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 21 | 21 | 0 | 0.00 | - | - |
| NO LATE CUT | 4 | 4 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 18 | 18 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT TURNED | 2 | 2 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 2 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 1 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 34 | 19 | 0 | 0.00 | - | - |
| ONE JOINT FIGURE | 1 | 1 | 0 | 0.00 | - | - |
| ONE ROUTE | 6 | 6 | 0 | 0.00 | - | - |
| PLAN RESULT | 260 | trace | - | - | - | - |
| PROMISE READS THE TABLE | 1 | 1 | 0 | 0.00 | - | - |
| REAL GROUND | 6 | 6 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 2 | 2 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 7 | 7 | 0 | 0.00 | - | - |
| RUN DOWN | 18 | 18 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 8 | 8 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 11 | 10 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 17 | not checked | - | - | - | - |
| SHOOTS FROM THE BEST SPOT | 4 | 4 | 0 | 0.00 | - | - |
| SHOT OR CHARGE | 4 | 4 | 0 | 0.00 | - | - |
| SPELL WORTH | 9 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 47 | 41 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 1 | 1 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 9 | 9 | 0 | 0.00 | - | - |
| STANDS STILL | 142 | 135 | 0 | 0.00 | - | - |
| STUPIDITY NEXT TURN | 8 | 6 | 0 | 0.00 | - | - |
| SURE REACH TOGETHER | 1 | not checked | - | - | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 11 | not checked | - | - | - | - |
| THE PROMISE ADDS | 4 | 2 | 0 | 0.00 | - | - |
| THE PROMISED MOVE | 1 | not checked | - | - | - | - |
| THE ROW IN ITS ORDER | 15 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 24 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 14 | not checked | - | - | - | - |
| THE TABLE BINDS | 242 | not checked | - | - | - | - |
| WAITS AGAIN | 23 | 20 | 0 | 0.00 | - | - |
| WHOLE FIGHT | 6 | 5 | 0 | 0.00 | - | - |
| WHOLE FIGHT GAIN | 1 | 1 | 0 | 0.00 | - | - |
| WOUNDS ON THE RANKS | 3 | 3 | 0 | 0.00 | - | - |

### Off best figure: csame-bb45c30-p12

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 3.67 | 3.33 | 25.8 |
| PROMISE BY ITS OWN SUM | rule | 2.00 | 4.00 | 112.8 |
| ARMY TABLE | rule | 0.67 | 2.33 | 95.6 |
| CHARGE NOW FIRST | rule | 0.67 | 1.33 | 39.1 |
| RULE SWITCHED OFF | gate | 1.33 | - | 12.2 |
| AFTERMATH BAND | gate | 0.67 | - | 3.9 |
| SUPPORT NARROWED | rule | 0.33 | 0.33 | 165.6 |
| CHARGE NOT DECLARED | rule | 0.33 | - | 80.0 |
| HOLDER ASSIGNMENT | rule | 0.33 | - | 36.5 |
| JOINT CHARGE NOW | rule | 0.33 | - | 3.8 |
| MARCH OF THE TABLE | rule | - | 0.33 | 112.7 |
| ONE PROMISE A TARGET | rule | - | 0.33 | 97.4 |
| PATHS CROSS | rule | 0.33 | - | 5.1 |
| PROMISE KNOWS THE FIGHT | rule | 0.33 | - | 1.7 |
| REFUSING RETIRES | rule | 0.33 | - | 32.0 |

### Plans: csame-bb45c30-p12

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 4.0 | 67% | 662 | 278 | 42% |
| Mine | join | 4.3 | 100% | 170 | 0 | 0% |
| Mine | move | 34.0 | 94% | 1507 | 0 | 0% |
| Mine | shoot | 0.7 | 50% | 69 | 57 | 82% |
| Mine | support | 0.7 | 100% | 0 | 0 | - |
| Opponent | charge | 3.7 | 82% | 383 | 245 | 64% |
| Opponent | join | 2.0 | 100% | 185 | 0 | 0% |
| Opponent | move | 33.3 | 95% | 1932 | 0 | 0% |
| Opponent | shoot | 3.3 | 90% | 159 | 198 | 124% |
| Opponent | support | 0.7 | 100% | 0 | 0 | - |

### Battle groups: csame-bb45c30-p12

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 4.0 | 33% | 50% | 25% | 0% | 0% | 0% | 33% | 67% | 0% |
| Opponent | REDIRECT COUNTER | 2.3 | 14% | 100% | 100% | 0% | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: csame-bb45c30-p12

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 9 | 86 (9) | 0 | 86 | 37 | 56% | 3.0 | 0 (4) | 267 (3) | 67 (2) | 133 (6) | 0 (3) |
| Mine | Character | 9 | 33 (9) | 33 | 0 | 2 | 11% | 3.5 | 50 (2) | 21 (6) | 0 (1) | 42 (6) | 0 (3) |
| Mine | Clean-up | 1 | 74 (1) | 0 | 74 | 0 | 0% | 4.0 | - | - | 74 (1) | 74 (1) | - |
| Mine | Fast | 1 | 67 (1) | 67 | 0 | 100 | 0% | 2.0 | - | 67 (1) | - | - | 67 (1) |
| Mine | Fast Hammer | 6 | 2 (6) | 2 | 0 | 26 | 17% | 3.8 | - | 0 (4) | 7 (2) | 0 (3) | 5 (3) |
| Mine | Hammer | 2 | 60 (2) | 60 | 0 | 0 | 50% | 3.0 | - | 60 (2) | - | 175 (1) | 0 (1) |
| Mine | Holder | 1 | 247 (1) | 0 | 247 | 100 | 0% | 3.0 | - | 247 (1) | - | - | 247 (1) |
| Mine | Support | 2 | 0 (2) | 0 | 0 | 0 | 100% | - | 0 (1) | 0 (1) | - | 0 (1) | 0 (1) |
| Mine | Wizard | 4 | 0 (4) | 0 | 0 | 0 | 25% | 1.3 | 0 (2) | 0 (1) | 0 (1) | 0 (3) | 0 (1) |
| Opponent | Chaff | 3 | 97 (3) | 0 | 97 | 22 | 33% | 3.5 | 0 (1) | 171 (1) | 0 (1) | 97 (3) | - |
| Opponent | Character | 10 | 31 (10) | 31 | 0 | 0 | 30% | 3.3 | 19 (3) | 26 (6) | 126 (1) | 40 (6) | 17 (4) |
| Opponent | Clean-up | 2 | 0 (2) | 0 | 0 | 50 | 50% | 6.0 | - | 0 (2) | - | 0 (1) | 0 (1) |
| Opponent | Fast Hammer | 5 | 31 (5) | 0 | 31 | 11 | 20% | 3.8 | 70 (2) | 0 (1) | 16 (2) | 20 (2) | 36 (3) |
| Opponent | Fragile | 2 | 0 (2) | 0 | 0 | 67 | 0% | 2.0 | 0 (1) | - | 0 (1) | 0 (2) | - |
| Opponent | Hammer | 6 | 31 (6) | 6 | 26 | 58 | 0% | 4.2 | - | 41 (4) | 0 (2) | 0 (3) | 67 (3) |
| Opponent | Holder | 6 | 47 (6) | 0 | 47 | 38 | 33% | 2.8 | 61 (3) | 40 (2) | 0 (1) | - | 47 (6) |
| Opponent | Shooter | 1 | 0 (1) | 0 | 0 | 100 | 0% | 1.0 | - | - | 0 (1) | 0 (1) | - |

### Charged fights: csame-bb45c30-p12

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Vampire Counts | 2 | 0 | 239 | 4.0 | 1.1 | 60 | 33 | +27 | 4 of 8 | 5 of 8 | -261 | +68 |
| Mine | Warriors of Chaos | 1 | 0 | 269 | 2.0 | 1.0 | 134 | 0 | +134 | 1 of 2 | 2 of 2 | - | +134 |
| **Mine** | all armies | 3 | 0 | 249 | 3.3 | 1.1 | 75 | 26 | +49 | 5 of 10 | 7 of 10 | -261 | +83 |
| Opponent | Warriors of Chaos | 2 | 0 | 197 | 4.0 | 1.0 | 49 | 21 | +28 | 4 of 8 | 5 of 8 | - | +28 |
| Opponent | Wood Elf Realms | 1 | 0 | 290 | 5.0 | 1.0 | 58 | 0 | +58 | 0 of 5 | 5 of 5 | - | +58 |
| **Opponent** | all armies | 3 | 0 | 228 | 4.3 | 1.0 | 53 | 13 | +40 | 4 of 13 | 10 of 13 | - | +40 |

### Effective charges: csame-bb45c30-p12

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Vampire Counts | 8 | 2 (net +0) | 0 | 0 | 0 | 1 (net +380) | 4 (net -65) | 1 | 0% (0 of 7) |
| Mine | Warriors of Chaos | 2 | 0 | 0 | 0 | 0 | 2 (net +134) | 0 | 0 | 0% (0 of 2) |
| Opponent | Warriors of Chaos | 8 | 1 (net +0) | 0 | 0 | 2 (net -60) | 1 (net +45) | 1 (net +45) | 3 | 0% (0 of 5) |
| Opponent | Wood Elf Realms | 5 | 0 | 0 | 0 | 1 (net +0) | 2 (net +42) | 2 (net +102) | 0 | 0% (0 of 5) |

### Charged fights, damage counted: csame-bb45c30-p12

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 2 | 367 | 186 | +0 | 78 | 210 | -132 | -35.9 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 4 | 130 | 384 | -65 | 18 | 65 | -48 | -36.6 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 3 | 489 | 130 | +216 | 216 | 18 | +198 | +40.5 |
| Mine | No odds | 1 | 471 | 98 | +98 | 98 | 0 | +98 | +20.8 |
| Mine | All fights | 10 | 320 | 239 | +49 | 97 | 74 | +24 | +7.4 |
| Opponent | Long shot (under 50%) | 1 | 479 | 380 | +0 | 0 | 0 | +0 | +0.0 |
| Opponent | 76-89% | 3 | 86 | 111 | -40 | 22 | 64 | -42 | -48.8 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 | 371 | 140 | +83 | 121 | 0 | +121 | +32.6 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 3 | 493 | 84 | +43 | 75 | 0 | +75 | +15.1 |
| Opponent | No odds | 3 | 165 | 335 | +85 | 164 | 27 | +137 | +82.9 |
| Opponent | All fights | 13 | 294 | 184 | +40 | 88 | 21 | +67 | +22.8 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| csame-bb45c30-p12 | move | 18 | 5 (28%) | 5 (28%) | 3 (17%) | 10 (56%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L2531, L2730 |
| Charmed Shield | Opponent | L2934 |
| Invocation of Nehek | Mine | L2531, L2730 |
| Ring of Doom | Opponent | L2531 |

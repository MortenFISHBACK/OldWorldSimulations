# Doctrine scorecard: h5-mine-8766b98-p1

### Scorecard: h5-mine-8766b98-p1

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0103 | 1 | 1 | Mine | no | 2 | 6 | 0 | 1 | 0 | 0 | 0 | 0 |
| L0103 | 1 | 1 | Opponent | no | 0 | 4 | 1 | 1 | 0 | 0 | 0 | 360 |
| L0120 | 6 | 1 | Mine | no | 4 | 6 | 1 | 2 | 0 | 0 | 0 | 0 |
| L0120 | 6 | 1 | Opponent | no | 5 | 4 | 1 | 3 | 0 | 0 | 0 | 0 |
| L0204 | 6 | 1 | Mine | no | 0 | 5 | 1 | 4 | 1 | 0 | 0 | 170 |
| L0204 | 6 | 1 | Opponent | no | 4 | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| L0219 | 3 | 1 | Mine | no | 9 | 2 | 4 | 1 | 1 | 0 | 0 | 255 |
| L0219 | 3 | 1 | Opponent | yes | 3 | 2 | 1 | 1 | 0 | 0 | 0 | 0 |
| L0304 | 4 | 1 | Mine | no | 0 | - | 0 | 0 | 0 | 0 | 0 | 625 |
| L0304 | 4 | 1 | Opponent | no | 0 | 3 | 4 | 4 | 0 | 0 | 0 | 0 |
| L0321 | 3 | 1 | Mine | no | 2 | 5 | 1 | 0 | 0 | 0 | 0 | 225 |
| L0321 | 3 | 1 | Opponent | no | 4 | - | 0 | 4 | 2 | 0 | 0 | 565 |
| L0406 | 4 | 1 | Mine | no | 0 | 3 | 3 | 2 | 0 | 0 | 0 | 0 |
| L0406 | 4 | 1 | Opponent | no | 0 | - | 1 | 0 | 0 | 0 | 0 | 852 |
| L0423 | 3 | 1 | Mine | no | 7 | 2 | 7 | 3 | 0 | 0 | 0 | 422 |
| L0423 | 3 | 1 | Opponent | no | 2 | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| L0510 | 6 | 1 | Mine | no | 4 | - | 1 | 0 | 0 | 0 | 0 | 233 |
| L0510 | 6 | 1 | Opponent | no | 5 | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L0525 | 3 | 1 | Mine | no | 1 | - | 0 | 0 | 0 | 0 | 0 | 318 |
| L0525 | 3 | 1 | Opponent | no | 1 | 3 | 3 | 2 | 0 | 0 | 0 | 0 |
| L0613 | 1 | 1 | Mine | no | 0 | - | 1 | 2 | 0 | 0 | 0 | 636 |
| L0613 | 1 | 1 | Opponent | no | 0 | 3 | 2 | 1 | 2 | 0 | 0 | 70 |
| L0630 | 6 | 1 | Mine | no | 0 | - | 0 | 0 | 0 | 0 | 0 | 643 |
| L0630 | 6 | 1 | Opponent | no | 8 | 2 | 2 | 1 | 1 | 0 | 0 | 0 |
| L0718 | 4 | 1 | Mine | no | 0 | 2 | 2 | 1 | 0 | 0 | 0 | 247 |
| L0718 | 4 | 1 | Opponent | no | 0 | 2 | 5 | 1 | 1 | 0 | 0 | 228 |
| **Average** | | | Mine | 0% | 2.2 | 3.9 | 1.6 | 1.2 | 0.2 | 0.0 | 0.0 | 290.3 |
| **Average** | | | Opponent | 8% | 2.5 | 2.6 | 2.1 | 1.6 | 0.5 | 0.0 | 0.0 | 159.6 |

### KPIs: h5-mine-8766b98-p1

Rules off - Opponent only: HOLDER ASSIGNMENT, QUARTER ODDS.

Morten 2026-11-10; 13 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 35% (19 of 54) | 11% (7 of 64) | 22% (26 of 118) |
| Winner chose to follow up after the loser gave ground |  | 68% (13 of 19); on the table 79% | 100% (12 of 12); on the table 100% | 81% (25 of 31); on the table 87% |
| Winner chose to pursue after the loser fell back in good order |  | 60% (3 of 5); on the table 60% | 100% (2 of 2); on the table 100% | 71% (5 of 7); on the table 71% |
| Winner chose to pursue after the loser fled |  | 60% (3 of 5); on the table 60% | 77% (10 of 13); on the table 77% | 72% (13 of 18); on the table 72% |
| Winner chose to follow up or pursue (all three) |  | 66% (19 of 29); on the table 72% | 89% (24 of 27); on the table 89% | 77% (43 of 56); on the table 80% |
| Magic missiles tried each own turn | 50%+ | 42% (61 of 144) | 32% (29 of 90) | 38% (90 of 234) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 49% (61 of 125) | 44% (29 of 66) | 47% (90 of 191) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 60% (3 of 5) | 63% (12 of 19) | 62% (15 of 24) |
| Points that never fought | lower | 46% (11330 of 24787) | 49% (12795 of 25993) | 48% (24125 of 50780) |
|   infantry points that never fought | lower | 48% (3536 of 7300) | 77% (4440 of 5732) | 61% (7976 of 13032) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 56% (54 of 96) | 56% (56 of 100) | 56% (110 of 196) |
| Bound items with a magic missile used (at least once a game) |  | 100% (6 of 6); 1.8 uses a game | 60% (3 of 5); 1.1 uses a game | 82% (9 of 11); 1.4 uses a game |
| Bound items with another spell used |  | 67% (2 of 3); 0.3 uses a game | 33% (1 of 3); 0.3 uses a game | 50% (3 of 6); 0.3 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 56% (5 of 9); 0.4 uses a game | 50% (3 of 6); 0.2 uses a game | 53% (8 of 15); 0.3 uses a game |
|   their share of the points of units over 100 pts | lower | 49% (9277 of 18932) | 50% (11173 of 22355) | 50% (20450 of 41287) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 3.4 (53%) | 1.0 (21%) | 4.4 (40%) |
| MARCHED: its unit marched | 1.3 (20%) | 0.9 (20%) | 2.2 (20%) |
| CHARGED: its unit charged | 0.2 (4%) | 0.5 (10%) | 0.7 (6%) |
| IN COMBAT: engaged in combat | 1.1 (17%) | 0.9 (20%) | 2.0 (18%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.1 (2%) | 0.1 (1%) |
| FLEEING: fleeing | 0.0 (0%) | 0.1 (2%) | 0.1 (1%) |
| GONE: slain | 0.2 (2%) | 0.8 (18%) | 1.0 (9%) |
| OFF THE TABLE: off the table or not arrived | 0.2 (4%) | 0.0 (0%) | 0.2 (2%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.4 (8%) | 0.4 (3%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.2 | 0.7 | 1.9 | 6.9 | 0.7 | 1.2 |
| not cast | 3.2 | 1.4 | 4.5 | 11.1 | 2.1 | 18.2 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.3 (7%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.4 (28%) | 0.8 (17%) | 4.4 (40%) | 0.2 (7%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.2 (20%) | 0.2 (11%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (6%) | 0.2 (7%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.2 (7%) | 0.3 (22%) | 0.8 (17%) | 2.0 (18%) | 0.5 (22%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.5 (14%) | 0.5 (33%) | 0.0 (0%) | 0.1 (1%) | 0.5 (22%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (0%) | 0.0 (0%) | 0.1 (2%) | 0.1 (1%) | 0.0 (0%) | 0.2 (1%) |
| GONE: slain | 0.5 (14%) | 0.1 (6%) | 0.2 (5%) | 1.0 (9%) | 0.1 (4%) | 1.0 (5%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (2%) | 0.0 (0%) | 0.0 (0%) |
| STUPIDITY: Stupidity | 0.1 (2%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.5 (26%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.4 (3%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.0 (62%) | 0.2 (11%) | 2.7 (59%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 15.7 (86%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.4 a game | 0.7 a game | 1.0 a game |
| stood (cast and not dispelled) | 61% (11 of 18) | 38% (3 of 8) | 54% (14 of 26) |
| the unit moved after it | 73% (8 of 11) | 100% (3 of 3) | 79% (11 of 14) |
| it charged on its next turn | 0% (0 of 11) | 0% (0 of 3) | 0% (0 of 14) |
| the enemy charged it first | 9% (1 of 11) | 0% (0 of 3) | 7% (1 of 14) |
| it fought by the end of its next turn | 9% (1 of 11) | 0% (0 of 3) | 7% (1 of 14) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 11) | 0% (0 of 3) | 0% (0 of 14) |
| none of these (no charge, no fight, no charge escaped) | 91% (10 of 11) | 100% (3 of 3) | 93% (13 of 14) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 63% (223 of 356) | 67% (191 of 286) | 64% (414 of 642) |
|   cavalry | 30% (6 of 20) | 87% (27 of 31) | 65% (33 of 51) |
|   character | 76% (28 of 37) | 41% (11 of 27) | 61% (39 of 64) |
|   chariot | 30% (10 of 33) | 54% (33 of 61) | 46% (43 of 94) |
|   infantry | 51% (46 of 90) | 69% (61 of 89) | 60% (107 of 179) |
|   monster | 83% (10 of 12) | 79% (11 of 14) | 81% (21 of 26) |
|   war machine | 75% (123 of 164) | 75% (48 of 64) | 75% (171 of 228) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.1 (20%) | 1.7 (23%) | 3.8 (21%) |
| CHARGED: it charged | 0.5 (5%) | 0.9 (13%) | 1.4 (8%) |
| FLEEING: it fled or was fleeing | 0.1 (1%) | 0.1 (1%) | 0.2 (1%) |
| IN COMBAT: it fought this turn or the last | 1.5 (14%) | 0.5 (6%) | 1.9 (11%) |
| MOVED: a war machine that moved | 1.6 (16%) | 0.5 (7%) | 2.2 (12%) |
| NO TARGET IN RANGE | 1.7 (17%) | 1.6 (22%) | 3.3 (19%) |
| ONLY IN COMBAT: the only targets were in combat | 0.2 (2%) | 0.4 (5%) | 0.6 (4%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.8 (18%) | 1.2 (16%) | 3.0 (17%) |
| SHELTERED: the target was sheltered | 0.2 (2%) | 0.1 (1%) | 0.2 (1%) |
| OTHER BAR | 0.6 (6%) | 0.4 (5%) | 1.0 (6%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 2.5 | 0.9 | 76% | 6.2 pts | 16 pts |
| character | 3.5 | 2.0 | 71% | 13.6 pts | 47 pts |
| chariot | 3.6 | 4.2 | 43% | 26.7 pts | 96 pts |
| infantry | 13.2 | 2.9 | 82% | 6.2 pts | 82 pts |
| monster | 1.6 | 0.2 | 86% | 5.0 pts | 8 pts |
| war machine | 13.2 | 15.2 | 61% | 35.5 pts | 467 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.2 | 3.8 | 3.5 |
| Charges that made contact a game | 2.6 | 2.5 | 2.6 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.00 declared, 0.86 contact (7 units) | 0.82 declared, 0.55 contact (11 units) | 0.89 declared, 0.67 contact (18 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 1.00 declared, 1.00 contact (2 units) | 1.00 declared, 1.00 contact (2 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.41 declared, 0.33 contact (86 units) | 0.38 declared, 0.24 contact (104 units) | 0.39 declared, 0.28 contact (190 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 50% (6 of 12) | 0% (0 of 4) | - | 38% (6 of 16) |
| Character in a unit | 85% (17 of 20) | 54% (7 of 13) | - | 73% (24 of 33) |
| Character on its own | 80% (8 of 10) | 45% (5 of 11) | 21% (3 of 14) | 46% (16 of 35) |
| Chariot | 20% (1 of 5) | 75% (9 of 12) | - | 59% (10 of 17) |
| Infantry | 50% (16 of 32) | 28% (5 of 18) | - | 42% (21 of 50) |
| Monster | 71% (5 of 7) | 60% (3 of 5) | - | 67% (8 of 12) |
| Monstrous | - | 50% (2 of 4) | - | 50% (2 of 4) |
| War Machines | 81% (21 of 26) | 67% (2 of 3) | - | 79% (23 of 29) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 92% (11 of 12); on the table 92% | 52% (53 of 102) | 48% | 55% (12 of 22) | 100% (6 of 6); 5.8 uses a game | 50% (1 of 2); 0.5 uses a game | 67% (4 of 6); 1.0 uses a game |
| Chaos Dwarfs | 7 | 62% (5 of 8); on the table 75% | 32% (19 of 60) | 49% | 54% (29 of 54) | 0.0 uses a game | 0.0 uses a game | 33% (1 of 3); 0.1 uses a game |
| Dwarfen Mountain Holds | 5 | 44% (4 of 9); on the table 44% | - | 39% | 68% (30 of 44) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 1 | 60% (3 of 5); on the table 80% | 17% (1 of 6) | 53% | 50% (5 of 10) | 0.0 uses a game | 100% (1 of 1); 2.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Grand Cathay | 1 | 100% (5 of 5); on the table 100% | 20% (6 of 30) | 55% | 50% (5 of 10) | 0% (0 of 2); 0.0 uses a game | 0% (0 of 1); 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| High Elf Realms | 1 | 100% (3 of 3); on the table 100% | 17% (1 of 6) | 68% | 62% (5 of 8) | 100% (1 of 1); 4.0 uses a game | 50% (1 of 2); 4.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 1 | 0% (0 of 1); on the table 0% | 0% (0 of 6) | 35% | 57% (4 of 7) | 100% (1 of 1); 5.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 1 | 100% (4 of 4); on the table 100% | 33% (2 of 6) | 27% | 38% (3 of 8) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Skaven | 2 | 100% (3 of 3); on the table 100% | 50% (6 of 12) | 68% | 56% (9 of 16) | 100% (1 of 1); 2.5 uses a game | 0.0 uses a game | 100% (2 of 2); 1.0 uses a game |
| Tomb Kings of Khemri | 1 | 75% (3 of 4); on the table 75% | - | 27% | 40% (2 of 5) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 1 | 100% (2 of 2); on the table 100% | 33% (2 of 6) | 57% | 50% (3 of 6) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 1 | - | - | 53% | 50% (3 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |

Flank and rear charges a unit could have turned to face (h5-mine-8766b98-p1, 13 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 65% (13) | 38% (8) | 51% (21) |
| ...free all their last turn and able to turn (per game) | 0.69 | 0.31 | 1.00 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.15 | 0.15 | 0.31 |
| ...with the charger already in that arc before they moved (per game) | 0.54 | 0.23 | 0.77 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.08 | 0.08 | 0.15 |

### Quality by phase: h5-mine-8766b98-p1

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.5 | 2.0 |
| Strategy | Charge objectives carried out (made contact) | 55% (21 of 38) | 56% (25 of 45) |
| Strategy | Shoot objectives carried out (shot that target) | 36% (73 of 201) | 64% (71 of 111) |
| Strategy | Support requests answered (helper made contact too) | 50% (2 of 4) | 33% (1 of 3) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (1 of 1) | 100% (3 of 3) |
| Strategy | Hexes on a unit its side charged or shot that turn | 0% (0 of 1) | 100% (1 of 1) |
| Strategy | Joined characters whose unit fought | 50% (17 of 34) | 33% (5 of 15) |
| Strategy | Lone characters that fought | 71% (17 of 24) | 69% (18 of 26) |
| Movement | Charges halted short of contact | 0.0 | 0.2 |
| Movement | Idle units | 1.2 | 1.6 |
| Movement | Points that never moved of their own | 290.3 | 159.6 |
| Movement | Fights charged into per game | 2.5 | 2.4 |
| Movement | Charges with odds: long shots (under 50%) | 7 of 30, net +14 | 8 of 30, net +124 |
| Movement | Charges with odds: sweet spot (55-75%) | 6 of 30, net +53 | 5 of 30, net +40 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 4 of 30, net +32 | 4 of 30, net +134 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 6 of 30, net +12 | 9 of 30, net +118 |
| Shooting | Shots by shooting units (incl. breath weapons) | 8.4 | 12.2 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 50% (55 of 109) | 43% (68 of 159) |
| Shooting | Points destroyed by shooting units | 167.6 | 57.6 |
| Shooting | War machine shots | 9.5 | 3.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 41% (51 of 123) | 52% (25 of 48) |
| Shooting | Points destroyed by war machines | 142.1 | 19.2 |
| Magic | Magic missiles cast | 2.8 | 1.5 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 41% (15 of 37) | 15% (3 of 20) |
| Magic | Wounds caused by magic missiles | 5.4 | 1.8 |
| Magic | Wounds caused by other spells | 0.8 | 0.1 |
| Magic | Points destroyed by magic (all spells) | 42.2 | 11.2 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.9 / 0.1 / 0.6 / 0.2 | 2.2 / 0.2 / 0.1 / 0.3 |
| Combat | Points destroyed in combat | 170.4 | 279.9 |
| Combat | Points run down | 68.9 | 78.9 |
| Combat | Net points per charged fight, damage counted | +72 | +94 |
| Combat | Net per 100 charger points, damage counted | +30.3 | +32.8 |
| Combat | First round won (charged fights) | 72% | 71% |
| Combat | Net points per charged fight | +55 | +119 |
| Combat | Net points per supported fight / lone fight | -30 / +61 | +255 / +109 |
| Combat | Charged fights on a top-3 enemy unit | 12 of 32 | 13 of 31 |
| Game | Points lost | 562.0 | 610.9 |
| Game | VP from objectives | 713.1 | 678.5 |
| Game | Lone holders (player turns) | 2.2 | 2.5 |

- Mine won / drew / lost: 6 / 3 / 4 of 13 ended games (of 13); mean margin (Mine - Opponent) +127 VP
- The side that went first won 4 of 10 games with a winner
- Points traded per game (both sides' losses): 1173
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: h5-mine-8766b98-p1

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.8 | +0.0 | 0.0 | 8.6 | 1.2 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.5 | +62.7 | 0.0 | 49.0 | - | - | - | - |
| ALREADY CARRIED | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARRIVAL HUNT | - | - | - | - | 0.1 | +6.0 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 2.4 | +0.0 | 0.0 | 17.7 | 0.3 | +0.0 | 0.0 | 12.7 |
| BACKUP TARGETS | 0.1 | +0.1 | 0.0 | 0.0 | 0.4 | +1.4 | 0.0 | 0.0 |
| BEST PRIZE | 0.1 | -28.1 | 0.0 | 44.6 | 0.2 | -6.7 | 0.0 | 0.0 |
| BLOWS WHERE AIMED | 0.1 | +1.5 | 0.0 | 0.0 | 0.2 | -30.2 | 19.2 | 0.0 |
| BOMBING RUN | - | - | - | - | 0.1 | +1.2 | 0.0 | 0.0 |
| CANNON PLAN MISSED | 1.3 | +0.0 | 181.9 | 24.6 | 0.1 | +0.0 | 0.0 | 0.0 |
| CANNON PLANNED TARGET | 8.9 | +191.6 | 937.3 | 110.8 | 3.2 | +11.3 | 129.1 | 69.2 |
| CANNON SIGHT KEPT | 0.9 | +0.0 | 0.0 | 9.6 | 0.5 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT COUNTER | 0.2 | -1.1 | 15.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT SET-UP | 0.1 | -0.0 | 0.0 | 0.0 | - | - | - | - |
| CAST JOB | 0.3 | +4.3 | 0.0 | 19.6 | 0.5 | +7.9 | 0.0 | 6.5 |
| CASTER AWAY FROM SCREEN | 0.4 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.5 | +44.0 | 16.2 | 0.0 | 0.1 | +1.3 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 0.8 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | - | - | - | - | 0.2 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | - | - | - | - | 0.1 | +1.2 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | 0.1 | +6.5 | 0.0 | 6.5 | 0.5 | +36.5 | 0.0 | 12.7 |
| CHAFF PASSED | 0.2 | -0.2 | 0.0 | 0.0 | 0.2 | -0.8 | 9.2 | 0.0 |
| CHARACTER GUNS | 0.5 | +0.0 | 0.0 | 0.0 | 0.8 | +0.0 | 0.0 | 0.0 |
| CHARGE LOSSES | 5.1 | -184.6 | 0.0 | 160.7 | 6.7 | -404.5 | 0.0 | 265.0 |
| CHARGE NOT DECLARED | 0.7 | +0.0 | 47.3 | 102.3 | 0.7 | +0.0 | 136.2 | 15.0 |
| CHARGE NOW FIRST | 0.8 | +0.0 | 83.5 | 8.0 | 2.3 | +0.0 | 188.5 | 38.2 |
| CHARGER SLAIN LOST | 0.7 | -19.3 | 40.4 | 17.1 | 0.2 | -17.9 | 89.2 | 0.0 |
| CHEAP HELPER | 0.2 | +0.0 | 0.0 | 4.6 | 0.1 | +0.0 | 44.6 | 0.0 |
| CHEAPEST HOLDER | - | - | - | - | 0.2 | -8.3 | 0.0 | 0.0 |
| COMBAT PIVOT | 0.5 | +0.0 | 0.0 | 88.1 | 0.8 | +0.0 | 23.8 | 97.8 |
| CONTINUE AHEAD WEIGHED | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CONVEYANCE SEARCH | 0.9 | +221.5 | 0.0 | 0.0 | 0.3 | +53.1 | 30.8 | 30.8 |
| COVER ONCE | 6.1 | -362.3 | 0.0 | 173.1 | 5.5 | -335.2 | 0.0 | 113.8 |
| DEPLOY BY FIGURES | 9.3 | +9.4 | 0.0 | 25.5 | 8.4 | +38.5 | 0.0 | 4.2 |
| EDGE GIVE GROUND | 0.2 | +8.5 | 8.5 | 0.0 | 0.4 | +6.1 | 30.2 | 0.0 |
| ENGINEER BY LORE | 0.3 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| FALL BACK GOOD ORDER | 2.0 | +0.5 | 141.0 | 113.3 | 2.2 | +3.7 | 179.2 | 62.1 |
| FALLBACK BY WORTH | 0.1 | +0.0 | 0.0 | 0.0 | 0.4 | +0.1 | 0.0 | 0.0 |
| FALLS SHORT | 5.7 | +114.1 | 0.0 | 35.6 | 17.8 | +241.3 | 0.0 | 258.4 |
| FEATURE BUFFS | 1.4 | +41.3 | 0.0 | 4.2 | 0.6 | +9.2 | 0.0 | 0.0 |
| FIGHT LIFT | 0.2 | +1.6 | 0.0 | 0.0 | 0.1 | +0.2 | 0.0 | 0.0 |
| FIGHT TO THE END | 0.8 | +50.8 | 101.4 | 17.5 | 1.3 | +58.4 | 105.5 | 62.1 |
| FIRE IN ORDER | 0.3 | +0.0 | 0.0 | 9.6 | 0.2 | +0.0 | 0.0 | 0.0 |
| FIVE ACTION | 46.5 | +2796.5 | 1518.2 | 622.9 | 48.2 | +2558.6 | 679.9 | 711.8 |
| FLANK NOT WEIGHED | 4.1 | +0.0 | 0.0 | 139.3 | 3.5 | +0.0 | 0.0 | 78.0 |
| FOLLOW UP WEIGHED | 0.6 | +170.0 | 0.0 | 6.5 | 0.6 | +210.2 | 0.0 | 0.0 |
| FOUR ROUNDS | 2.9 | +258.7 | 207.2 | 121.3 | 3.3 | +265.5 | 255.8 | 65.9 |
| FRIEND CHARGES FIRST | 0.2 | -18.7 | 0.0 | 0.0 | 0.1 | -0.7 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 0.5 | -5.1 | 11.2 | 4.0 | 0.5 | -9.5 | 0.0 | 0.0 |
| FRIENDS SHOTS CHECKED | - | - | - | - | 0.2 | +11.0 | 0.0 | 67.4 |
| GIVES UP | 0.3 | -8.7 | 30.0 | 48.6 | 0.3 | -3.7 | 26.5 | 0.0 |
| GROUND FLIERS | 0.1 | +5.4 | 0.0 | 0.0 | - | - | - | - |
| GUN FIGURES | 0.9 | +2.6 | 0.0 | 47.7 | 1.7 | +51.3 | 58.1 | 42.7 |
| GUN MASK | 0.8 | +30.9 | 0.0 | 14.3 | 0.4 | +6.5 | 0.0 | 22.8 |
| HARD STAY DROPPED | 2.0 | +0.0 | 0.0 | 53.6 | 0.5 | +0.0 | 0.0 | 17.5 |
| HE SHOOTS OR CHARGES | 2.1 | +0.0 | 0.0 | 69.5 | 2.5 | +0.0 | 0.0 | 81.9 |
| HELPER ALREADY ASKED | - | - | - | - | 0.1 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE DENIED | 0.2 | +4.7 | 0.0 | 0.0 | 0.2 | +4.1 | 0.0 | 0.0 |
| HIS CHARGE LIST | 2.8 | +0.0 | 0.0 | 36.6 | 3.8 | +0.0 | 0.0 | 106.6 |
| HIS LEGAL MOVES | 3.0 | +0.0 | 0.0 | 70.2 | 3.3 | +0.0 | 0.0 | 30.8 |
| HIS MOVE AND SHOT | 1.6 | -28.8 | 0.0 | 32.7 | 1.2 | -30.2 | 0.0 | 69.5 |
| HIS RANDOM MOVE | 1.5 | +0.0 | 0.0 | 11.2 | 1.5 | +0.0 | 0.0 | 8.5 |
| HIS SHOT LIST | 18.8 | +531.8 | 0.0 | 238.1 | 23.9 | +1099.6 | 0.0 | 423.1 |
| HIS TURN DENIED | 1.2 | +27.5 | 98.4 | 89.2 | 2.0 | +134.2 | 117.3 | 47.1 |
| HOLD ODDS | 9.8 | +0.0 | 0.0 | 70.4 | - | - | - | - |
| HOLDER ASSIGNMENT | 12.5 | +1276.3 | 0.0 | 107.8 | - | - | - | - |
| HOLDER AT DEPLOYMENT | - | - | - | - | 2.1 | +357.0 | 0.0 | 4.2 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 2.1 | -85.4 | 176.1 | 106.8 | 3.1 | -152.2 | 211.2 | 62.1 |
| HUNT IN PAIRS | - | - | - | - | 0.3 | +2.1 | 0.0 | 15.0 |
| IDLE COST | 4.8 | -48.8 | 0.0 | 46.9 | 10.2 | -149.0 | 0.0 | 332.4 |
| JOINT KNOWS CHALLENGE | - | - | - | - | 0.2 | -5.1 | 22.2 | 0.0 |
| KEEP FALLS | 0.1 | +0.2 | 0.0 | 0.0 | - | - | - | - |
| KEEPS SCOUTS OR AMBUSH | 0.2 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 0.4 | +10.6 | 0.0 | 0.0 | 0.9 | +53.0 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 4.2 | +0.0 | 151.5 | 148.5 | 3.2 | +0.0 | 220.0 | 72.8 |
| LONE CHARACTER SAFE SPOT | - | - | - | - | 0.2 | +23.7 | 0.0 | 0.0 |
| LONE WIZARD KEPT IN | 0.8 | +47.5 | 0.0 | 0.0 | 0.2 | +25.1 | 0.0 | 0.0 |
| LONG SHOT | 0.5 | -12.7 | 41.5 | 7.0 | 0.2 | -0.7 | 0.0 | 0.0 |
| LOST CHARGE | - | - | - | - | 0.1 | -0.2 | 0.0 | 0.0 |
| LURE BY WHAT IT DRAWS | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MAKE SURE TOGETHER | - | - | - | - | 0.3 | +2.2 | 0.0 | 0.0 |
| MANOEUVRE | 1.3 | +1.4 | 0.0 | 63.2 | 1.7 | +27.8 | 0.0 | 0.0 |
| MARCH BY THE SUM | 0.2 | +13.1 | 0.0 | 0.0 | 0.3 | +9.4 | 0.0 | 30.8 |
| MARCH CHECK | 0.5 | +18.9 | 0.0 | 12.5 | 1.3 | +70.5 | 0.0 | 12.8 |
| MARCH OVER CASTS | 0.3 | -3.3 | 0.0 | 0.0 | 0.5 | +20.7 | 0.0 | 43.6 |
| MAX FOR POSITIONING | 3.5 | +46.2 | 0.0 | 80.6 | 4.5 | +52.2 | 0.0 | 160.2 |
| MISSILES IN THE MOVE | 3.4 | +157.7 | 0.0 | 38.3 | 3.5 | +54.1 | 0.0 | 112.2 |
| MISSILES NEXT TURN | 3.9 | +116.3 | 0.0 | 44.8 | 4.4 | +41.3 | 0.0 | 168.3 |
| MODEL FACING | 1.1 | +301.5 | 0.0 | 9.2 | 0.5 | +89.0 | 0.0 | 0.0 |
| MOVE SPELL IN RANGE | 0.5 | +13.6 | 0.0 | 0.0 | 0.4 | +4.5 | 0.0 | 0.0 |
| MOVE SPELL OUT OF RANGE | 1.7 | -25.0 | 0.0 | 0.0 | 0.5 | -20.1 | 0.0 | 0.0 |
| MOVE SPELL SPOT | 0.5 | +0.0 | 0.0 | 9.5 | 0.1 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 3.6 | +254.4 | 0.0 | 66.5 | 3.2 | +480.6 | 0.0 | 34.0 |
| MOVES UNITS SPELL | 0.2 | +8.5 | 0.0 | 0.0 | 0.1 | +0.3 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 5.1 | +226.8 | 0.0 | 60.4 | 5.2 | +204.0 | 0.0 | 18.5 |
| NEXT CHARGE BY LIST | 5.3 | -149.6 | 33.1 | 68.8 | 4.4 | -156.0 | 6.5 | 69.0 |
| NEXT OBJECTIVE NEARER | 0.2 | -1.7 | 0.0 | 0.0 | 12.1 | -640.4 | 139.2 | 79.1 |
| NO DOUBLE ROUNDS | 2.1 | -89.0 | 155.7 | 70.2 | 2.5 | -74.2 | 175.8 | 62.1 |
| NOT TURNED | 0.1 | +0.0 | 0.0 | 6.5 | 0.1 | +0.0 | 0.0 | 8.5 |
| NOT WORTH A CAST | 0.7 | -0.4 | 0.0 | 44.6 | 0.1 | -0.1 | 0.0 | 0.0 |
| OFF BEST | 0.5 | -10.8 | 0.0 | 15.5 | 0.5 | -35.0 | 0.0 | 34.0 |
| ONE CHARGE A CHARGER | 1.8 | +0.0 | 0.0 | 26.5 | 2.5 | +0.0 | 0.0 | 57.6 |
| ONE FIGHT FORMULA | 5.5 | -85.3 | 0.0 | 61.7 | 5.0 | -119.8 | 0.0 | 195.5 |
| ONE OBJECTIVE FORMULA | 4.5 | +81.7 | 0.0 | 65.6 | 3.4 | +14.5 | 0.0 | 18.2 |
| ONE TARGET A SHOOTER | 15.5 | +331.9 | 0.0 | 191.1 | 22.9 | +742.0 | 0.0 | 241.8 |
| OPENS UP | 0.3 | +33.1 | 13.1 | 44.6 | 0.5 | +27.6 | 19.6 | 0.0 |
| OVERRUNS AWAY | 0.7 | +51.1 | 61.8 | 102.8 | 0.6 | +30.6 | 70.4 | 26.6 |
| PATHS CROSS | 3.4 | +83.4 | 0.0 | 17.5 | 4.5 | +123.1 | 0.0 | 47.8 |
| PERIAPT WORTH | - | - | - | - | 0.2 | +11.8 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.1 | -1.5 | 0.0 | 0.0 | 0.1 | -1.5 | 0.0 | 0.0 |
| PLAN RESULT | 41.2 | +1419.2 | 673.3 | 827.5 | 43.4 | +439.1 | 553.4 | 1095.5 |
| PURSUES BIG PREY | 0.1 | -0.9 | 0.0 | 0.0 | 0.1 | -0.8 | 0.0 | 0.0 |
| QUARTER ODDS | 4.8 | +573.9 | 131.0 | 130.4 | - | - | - | - |
| RANDOM MOVE BY FIGURES | 0.4 | +5.0 | 0.0 | 13.1 | 1.5 | +16.5 | 0.0 | 43.5 |
| REDIRECT BY WHAT IT STOPS | 0.1 | -0.8 | 0.0 | 6.5 | 0.2 | -7.8 | 0.0 | 12.7 |
| REDIRECT COUNTER | 1.2 | +27.3 | 0.0 | 33.4 | 2.5 | +233.8 | 0.0 | 22.0 |
| REDIRECT WEIGHED | 0.1 | +5.7 | 14.3 | 0.0 | 0.4 | +10.8 | 8.8 | 0.0 |
| REFORMS TO MEET IT | 0.5 | -43.8 | 0.0 | 4.0 | 0.4 | -15.6 | 0.0 | 0.0 |
| REFUSING RETIRES | 0.4 | +0.0 | 0.0 | 38.5 | 0.1 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | 0.2 | +37.4 | 0.0 | 0.0 | 0.8 | +39.9 | 0.0 | 0.0 |
| RESTRAINS TO SHOOT | 0.1 | +3.3 | 0.0 | 0.0 | 0.1 | +1.0 | 0.0 | 0.0 |
| RISK BY ARC | 2.5 | -25.5 | 182.2 | 121.3 | 2.5 | -11.7 | 181.8 | 62.1 |
| RISK BY HIS FIGURE | 9.5 | -125.3 | 0.0 | 232.2 | 11.1 | -202.8 | 0.0 | 162.2 |
| RUN DOWN | 1.7 | -14.4 | 114.5 | 113.3 | 1.8 | -16.9 | 95.7 | 50.5 |
| SAME CHARGE LATER | 0.1 | -1.5 | 0.0 | 0.0 | 0.1 | -0.9 | 0.0 | 0.0 |
| SCOUT SPOT | 0.3 | +1.4 | 0.0 | 0.0 | 0.3 | +1.4 | 0.0 | 0.0 |
| SCOUT WAITS | 0.3 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 0.2 | -0.4 | 0.0 | 0.0 |
| SEARCH SPOT | 4.4 | +156.3 | 0.0 | 28.1 | 6.7 | +239.5 | 0.0 | 89.1 |
| SELF MOVE SPELL | - | - | - | - | 0.4 | -0.6 | 0.0 | 0.0 |
| SET UP TOGETHER | 0.2 | +1.2 | 0.0 | 0.0 | 0.6 | +8.5 | 0.0 | 34.0 |
| SET-UP ANY TARGET | 0.2 | +18.3 | 0.0 | 0.0 | - | - | - | - |
| SHOOTER COUNTED ONCE | - | - | - | - | 0.1 | -0.9 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.6 | +1.2 | 0.0 | 0.0 | 0.2 | +0.7 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.2 | +31.4 | 57.2 | 0.0 | 1.6 | +28.3 | 69.4 | 57.2 |
| SHORT GUN FORWARD | 0.5 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| SHOT OR CHARGE | 0.3 | -4.7 | 11.2 | 7.0 | 0.2 | -8.0 | 32.7 | 0.0 |
| SHOT RISK POINTS | 8.2 | -38.7 | 0.0 | 163.7 | 12.5 | -35.2 | 0.0 | 347.8 |
| SHOTS IN THE MOVE | 18.5 | +727.2 | 0.0 | 232.8 | 16.4 | +322.9 | 0.0 | 261.6 |
| SPELL OFF EDGE | 0.2 | +18.6 | 0.0 | 0.0 | - | - | - | - |
| SPELL SETS UP CHARGE | 0.2 | +89.2 | 0.0 | 0.0 | - | - | - | - |
| SPELL WORTH | 0.5 | +5.0 | 44.6 | 44.6 | 1.2 | +25.4 | 103.1 | 103.1 |
| SPELLS IN THE FIGHT | 0.7 | -1.7 | 81.4 | 44.6 | 0.9 | -2.3 | 130.1 | 47.1 |
| STAND AND SHOOT | 0.4 | -1.9 | 17.5 | 44.6 | 0.7 | -12.2 | 58.3 | 11.6 |
| STANDS FOR A REASON | 0.3 | +0.0 | 0.0 | 12.2 | 0.8 | +0.0 | 0.0 | 23.8 |
| STANDS STILL | 21.8 | +0.0 | 1311.0 | 227.3 | 13.1 | +0.0 | 424.2 | 231.0 |
| STAY WORTH | 23.6 | +82.2 | 735.8 | 277.2 | 15.0 | +36.4 | 267.9 | 296.5 |
| STUCK PIVOT | - | - | - | - | 0.3 | +0.0 | 0.0 | 32.3 |
| SUPPORT NARROWED | 0.5 | +0.0 | 20.4 | 8.0 | 0.7 | +0.0 | 56.8 | 26.6 |
| SURE REACH TOGETHER | 0.2 | +5.1 | 0.0 | 0.0 | 0.3 | +5.3 | 0.0 | 22.8 |
| THE DEARER SUM KEEPS ITS PLAN | 3.6 | +0.0 | 0.0 | 10.2 | 4.5 | +0.0 | 0.0 | 17.1 |
| THE PROMISE ADDS | 0.1 | -1.0 | 0.0 | 0.0 | - | - | - | - |
| THE PROMISED MOVE | 0.7 | +0.0 | 0.0 | 14.5 | 0.2 | +0.0 | 0.0 | 0.0 |
| TIED UP BY THE SUM | 0.2 | +28.2 | 18.8 | 44.6 | 0.5 | +52.6 | 55.9 | 26.6 |
| TIME ON OUR SIDE | 23.1 | +364.3 | 3.5 | 238.2 | 10.3 | +149.0 | 0.0 | 81.6 |
| TWO OR MORE ARRIVE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WAITS AGAIN | 1.8 | +0.0 | 0.0 | 38.4 | 0.7 | +0.0 | 0.0 | 34.0 |
| WAR ENGINE CHARGES | 0.1 | +7.1 | 16.2 | 0.0 | 0.2 | +11.9 | 0.0 | 23.8 |
| WAR ENGINE JOBS | 0.3 | +0.0 | 22.3 | 0.0 | 0.7 | +0.0 | 80.2 | 23.8 |
| WHO HITS BACK | 0.3 | +33.5 | 0.0 | 6.5 | 0.2 | +71.7 | 0.0 | 31.2 |
| WHOLE FIGHT | 0.2 | -1.6 | 21.2 | 6.5 | 0.2 | +13.1 | 89.2 | 0.0 |
| WHOLE FIGHT GAIN | 0.2 | +14.0 | 22.7 | 6.5 | 0.2 | +3.1 | 0.0 | 0.0 |
| WIDER SPREAD | 2.2 | +0.4 | 192.5 | 62.2 | 2.5 | -10.0 | 216.4 | 62.1 |
| WOUNDS ON THE RANKS | 1.6 | +68.9 | 0.0 | 0.0 | 1.2 | +80.0 | 0.0 | 12.8 |

### Rule changes: h5-mine-8766b98-p1

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS SHOT LIST | 556 | 556 | 177 | 13.62 | +3543 | +20.0 |
| HOLDER ASSIGNMENT | 162 | 162 | 152 | 11.69 | +8292 | +54.5 |
| DEPLOY BY FIGURES | 230 | 230 | 142 | 10.92 | +2580 | +18.2 |
| SEARCH SPOT | 144 | 144 | 140 | 10.77 | +5145 | +36.7 |
| ONE TARGET A SHOOTER | 499 | 499 | 130 | 10.00 | +1561 | +12.0 |
| FIVE ACTION | 1232 | 1229 | 107 | 8.23 | +3260 | +30.5 |
| PATHS CROSS | 102 | 102 | 102 | 7.85 | +2685 | +26.3 |
| LEGAL CHARGES ONLY | 96 | 96 | 96 | 7.38 | +0 | +0.0 |
| TIME ON OUR SIDE | 434 | 387 | 92 | 7.08 | +250 | +2.7 |
| MOVE TO CHARGE COMPUTED | 89 | 89 | 53 | 4.08 | +3979 | +75.1 |
| SHOT RISK POINTS | 269 | 269 | 47 | 3.62 | +1278 | +27.2 |
| ARTILLERY RE-ROLL WEIGHED | 35 | 35 | 35 | 2.69 | +0 | +0.0 |
| HARD STAY DROPPED | 33 | 33 | 33 | 2.54 | +0 | +0.0 |
| SHOTS IN THE MOVE | 453 | 423 | 32 | 2.46 | +780 | +24.4 |
| CANNON PLANNED TARGET | 158 | 158 | 28 | 2.15 | -171 | -6.1 |
| FOUR ROUNDS | 81 | 78 | 28 | 2.15 | +1428 | +51.0 |
| ADVANCE LANE KEPT | 26 | 26 | 26 | 2.00 | +0 | +0.0 |
| COVER ONCE | 150 | 121 | 26 | 2.00 | +198 | +7.6 |
| NEXT OBJECTIVE NEARER | 159 | 159 | 24 | 1.85 | +420 | +17.5 |
| SHOOTS FROM THE BEST SPOT | 36 | 36 | 23 | 1.77 | +137 | +6.0 |
| MAX FOR POSITIONING | 105 | 102 | 21 | 1.62 | +100 | +4.8 |
| IDLE COST | 195 | 162 | 20 | 1.54 | +148 | +7.4 |
| MODEL FACING | 20 | 20 | 20 | 1.54 | +5076 | +253.8 |
| MARCH CHECK | 24 | 24 | 19 | 1.46 | +536 | +28.2 |
| CANNON SIGHT KEPT | 18 | 18 | 18 | 1.38 | +0 | +0.0 |
| CHARGE NOT DECLARED | 18 | 18 | 18 | 1.38 | -3288 | -182.7 |
| MANOEUVRE | 39 | 39 | 18 | 1.38 | +455 | +25.3 |
| MISSILES IN THE MOVE | 90 | 69 | 18 | 1.38 | +332 | +18.5 |
| FALLS SHORT | 305 | 267 | 17 | 1.31 | +86 | +5.1 |
| LANE BY FIGURES | 17 | 17 | 17 | 1.31 | +827 | +48.6 |
| CHARGE LOSSES | 153 | 153 | 16 | 1.23 | +752 | +47.0 |
| COMBAT PIVOT | 16 | 16 | 16 | 1.23 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 16 | 16 | 16 | 1.23 | +4942 | +308.9 |
| RANDOM MOVE BY FIGURES | 24 | 24 | 15 | 1.15 | +281 | +18.7 |
| HOLDER AT DEPLOYMENT | 27 | 27 | 14 | 1.08 | +677 | +48.3 |
| NEXT CHARGE BY LIST | 126 | 126 | 14 | 1.08 | +272 | +19.5 |
| LONE WIZARD KEPT IN | 13 | 13 | 13 | 1.00 | +944 | +72.7 |
| OFF BEST | 13 | 13 | 13 | 1.00 | -595 | -45.8 |
| QUARTER ODDS | 63 | 62 | 13 | 1.00 | +1476 | +113.5 |
| REDIRECT COUNTER | 49 | 40 | 13 | 1.00 | +1167 | +89.7 |
| RESERVE FALL BACK | 13 | 13 | 13 | 1.00 | +1004 | +77.2 |
| RISK BY ARC | 65 | 62 | 13 | 1.00 | +510 | +39.3 |
| HIS TURN DENIED | 42 | 42 | 11 | 0.85 | +580 | +52.8 |
| SHOOTERS IN TWO RANKS | 11 | 11 | 11 | 0.85 | +25 | +2.3 |
| HOLDS AMBUSHERS | 10 | 10 | 10 | 0.77 | +0 | +0.0 |
| WOUNDS ON THE RANKS | 37 | 37 | 10 | 0.77 | +551 | +55.1 |
| SCOUT WAITS | 9 | 9 | 9 | 0.69 | +0 | +0.0 |
| SHORT GUN FORWARD | 9 | 9 | 9 | 0.69 | +0 | +0.0 |
| CHARGE NOW FIRST | 41 | 41 | 8 | 0.62 | -910 | -113.7 |
| TIED UP BY THE SUM | 10 | 10 | 8 | 0.62 | +278 | +34.8 |
| CASTER AWAY FROM SCREEN | 7 | 7 | 7 | 0.54 | +0 | +0.0 |
| MARCH BY THE SUM | 7 | 7 | 7 | 0.54 | +292 | +41.7 |
| NEARER NOT NEEDED | 134 | 129 | 7 | 0.54 | +200 | +28.6 |
| WHO HITS BACK | 7 | 7 | 7 | 0.54 | +922 | +131.7 |
| AFTERMATH IN POINTS | 6 | 6 | 6 | 0.46 | +815 | +135.8 |
| CASTING BLOCK | 7 | 7 | 6 | 0.46 | +122 | +20.3 |
| FIRE IN ORDER | 6 | 6 | 6 | 0.46 | +0 | +0.0 |
| OPENS UP | 10 | 10 | 6 | 0.46 | +126 | +21.0 |
| REDIRECT WEIGHED | 6 | 6 | 6 | 0.46 | +293 | +48.9 |
| STAY WORTH | 502 | 482 | 6 | 0.46 | +94 | +15.6 |
| FEATURE BUFFS | 26 | 26 | 5 | 0.38 | +134 | +26.9 |
| OVERRUNS AWAY | 17 | 17 | 5 | 0.38 | +107 | +21.4 |
| RISK BY HIS FIGURE | 268 | 268 | 5 | 0.38 | +316 | +63.3 |
| CHAFF IN THE MOVE | 8 | 8 | 4 | 0.31 | +62 | +15.6 |
| CHAFF PASSED | 4 | 4 | 4 | 0.31 | -13 | -3.2 |
| ONE FIGHT FORMULA | 137 | 75 | 4 | 0.31 | +13 | +3.2 |
| ONE OBJECTIVE FORMULA | 103 | 78 | 4 | 0.31 | +415 | +103.8 |
| STUCK PIVOT | 4 | 4 | 4 | 0.31 | +0 | +0.0 |
| SURE REACH TOGETHER | 6 | 6 | 4 | 0.31 | +47 | +11.9 |
| WHOLE FIGHT GAIN | 5 | 5 | 4 | 0.31 | +152 | +38.1 |
| BEST PRIZE | 3 | 3 | 3 | 0.23 | -452 | -150.7 |
| CARRIES OUT COUNTER | 3 | 3 | 3 | 0.23 | -14 | -4.8 |
| EDGE GIVE GROUND | 7 | 6 | 3 | 0.23 | +46 | +15.5 |
| FIGHT TO THE END | 28 | 25 | 3 | 0.23 | +164 | +54.5 |
| HONEST WORTH | 67 | 65 | 3 | 0.23 | +29 | +9.7 |
| KEEPS SCOUTS OR AMBUSH | 3 | 3 | 3 | 0.23 | +0 | +0.0 |
| MISSILES NEXT TURN | 108 | 76 | 3 | 0.23 | +23 | +7.8 |
| MOVES UNITS SPELL | 3 | 3 | 3 | 0.23 | +114 | +38.2 |
| REFUSING RETIRES | 6 | 6 | 3 | 0.23 | -1 | -0.3 |
| SET UP TOGETHER | 10 | 9 | 3 | 0.23 | +18 | +6.1 |
| WAR ENGINE JOBS | 13 | 13 | 3 | 0.23 | -202 | -67.3 |
| CAST JOB | 10 | 10 | 2 | 0.15 | +7 | +3.6 |
| CASTS FROM BEHIND | 2 | 2 | 2 | 0.15 | +0 | +0.0 |
| FRIENDS SHOTS CHECKED | 2 | 2 | 2 | 0.15 | +144 | +71.8 |
| GUN MASK | 16 | 16 | 2 | 0.15 | +210 | +105.0 |
| HIS MOVE AND SHOT | 37 | 37 | 2 | 0.15 | +3 | +1.4 |
| PERIAPT WORTH | 2 | 2 | 2 | 0.15 | +153 | +76.7 |
| PIVOT GUARDS FLANK | 2 | 2 | 2 | 0.15 | -38 | -19.2 |
| PURSUES BIG PREY | 2 | 2 | 2 | 0.15 | -22 | -10.8 |
| RESTRAINS TO SHOOT | 2 | 2 | 2 | 0.15 | +56 | +27.9 |
| WAR ENGINE CHARGES | 3 | 3 | 2 | 0.15 | +179 | +89.5 |
| WHOLE FIGHT | 6 | 5 | 2 | 0.15 | +58 | +28.9 |
| BOMBING RUN | 1 | 1 | 1 | 0.08 | +15 | +15.2 |
| CARRIES OUT SET-UP | 1 | 1 | 1 | 0.08 | -0 | -0.2 |
| CONTINUE AHEAD WEIGHED | 1 | 1 | 1 | 0.08 | +0 | +0.0 |
| FALLBACK BY WORTH | 6 | 6 | 1 | 0.08 | +1 | +1.1 |
| HIS CHARGE DENIED | 5 | 5 | 1 | 0.08 | +22 | +22.3 |
| HUNT IN PAIRS | 4 | 2 | 1 | 0.08 | +10 | +9.8 |
| KEEP FALLS | 1 | 1 | 1 | 0.08 | +24 | +24.2 |
| LONG SHOT | 9 | 8 | 1 | 0.08 | +10 | +10.4 |
| SCREEN BY WHAT IT SAVES | 2 | 2 | 1 | 0.08 | +0 | +0.0 |
| SPELLS IN THE FIGHT | 21 | 20 | 1 | 0.08 | +54 | +54.1 |
| WIDER SPREAD | 61 | 59 | 1 | 0.08 | +11 | +10.9 |
| ALREADY CARRIED | 1 | not checked | - | - | - | - |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| BACKUP TARGETS | 6 | not checked | - | - | - | - |
| BLOWS WHERE AIMED | 4 | 4 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 18 | 18 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 14 | trace | - | - | - | - |
| CATCH FLIERS | 1 | not checked | - | - | - | - |
| CHARACTER GUNS | 17 | 17 | 0 | 0.00 | - | - |
| CHARGER SLAIN LOST | 12 | 12 | 0 | 0.00 | - | - |
| CHEAP HELPER | 3 | not checked | - | - | - | - |
| CHEAPEST HOLDER | 2 | 2 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 16 | not checked | - | - | - | - |
| ENGINEER BY LORE | 6 | 6 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 55 | 54 | 0 | 0.00 | - | - |
| FIGHT LIFT | 4 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 98 | not checked | - | - | - | - |
| FRIEND CHARGES FIRST | 4 | 4 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 13 | 13 | 0 | 0.00 | - | - |
| GIVES UP | 8 | 7 | 0 | 0.00 | - | - |
| GROUND FLIERS | 1 | not checked | - | - | - | - |
| GUN FIGURES | 34 | not checked | - | - | - | - |
| HE SHOOTS OR CHARGES | 59 | 59 | 0 | 0.00 | - | - |
| HELPER ALREADY ASKED | 1 | not checked | - | - | - | - |
| HIS CHARGE LIST | 86 | 86 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 82 | 82 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 39 | 39 | 0 | 0.00 | - | - |
| HOLD ODDS | 127 | 127 | 0 | 0.00 | - | - |
| JOINT KNOWS CHALLENGE | 2 | 2 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 3 | not checked | - | - | - | - |
| LOST CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 1 | 1 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 4 | not checked | - | - | - | - |
| MARCH OVER CASTS | 10 | 10 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 11 | 9 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 28 | trace | - | - | - | - |
| MOVE SPELL SPOT | 8 | not checked | - | - | - | - |
| NO DOUBLE ROUNDS | 60 | 58 | 0 | 0.00 | - | - |
| NOT TURNED | 2 | 2 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 10 | not checked | - | - | - | - |
| ONE CHARGE A CHARGER | 57 | 57 | 0 | 0.00 | - | - |
| PLAN RESULT | 1100 | trace | - | - | - | - |
| REDIRECT BY WHAT IT STOPS | 3 | 3 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 11 | 11 | 0 | 0.00 | - | - |
| RUN DOWN | 45 | 43 | 0 | 0.00 | - | - |
| SAME CHARGE LATER | 2 | 2 | 0 | 0.00 | - | - |
| SCOUT SPOT | 8 | 8 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 5 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 2 | not checked | - | - | - | - |
| SHOOTER COUNTED ONCE | 1 | 1 | 0 | 0.00 | - | - |
| SHOT OR CHARGE | 6 | 6 | 0 | 0.00 | - | - |
| SPELL OFF EDGE | 2 | not checked | - | - | - | - |
| SPELL SETS UP CHARGE | 3 | not checked | - | - | - | - |
| SPELL WORTH | 21 | not checked | - | - | - | - |
| STAND AND SHOOT | 14 | 14 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 14 | 14 | 0 | 0.00 | - | - |
| STANDS STILL | 454 | 454 | 0 | 0.00 | - | - |
| SUPPORT NARROWED | 16 | 16 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 106 | not checked | - | - | - | - |
| THE PROMISE ADDS | 1 | 1 | 0 | 0.00 | - | - |
| THE PROMISED MOVE | 12 | not checked | - | - | - | - |
| TWO OR MORE ARRIVE | 1 | not checked | - | - | - | - |
| WAITS AGAIN | 32 | 32 | 0 | 0.00 | - | - |

### Off best figure: h5-mine-8766b98-p1

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| CHARGE NOT DECLARED | rule | 0.62 | 0.69 | 193.4 |
| HOLDER ASSIGNMENT | rule | 1.15 | - | 15.6 |
| PATHS CROSS | rule | 0.23 | 0.54 | 13.5 |
| CHARGE NOW FIRST | rule | 0.08 | 0.54 | 113.7 |
| JOB FIRST | gate | 0.23 | 0.38 | 51.6 |
| CANNON PLANNED TARGET | rule | 0.46 | 0.08 | 24.5 |
| BEST PRIZE | rule | 0.08 | 0.15 | 150.7 |
| CHAFF PASSED | rule | 0.08 | 0.15 | 4.2 |
| WAR ENGINE JOBS | rule | - | 0.23 | 67.3 |
| AFTERMATH BAND | gate | 0.08 | 0.08 | 4.0 |
| CARRIES OUT COUNTER | rule | 0.15 | - | 7.2 |
| PIVOT GUARDS FLANK | rule | 0.08 | 0.08 | 19.2 |
| PURSUES BIG PREY | rule | 0.08 | 0.08 | 10.8 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.08 | - | 37.1 |
| FIGHT ORDER BAND | gate | 0.08 | - | 0.7 |
| RULE SWITCHED OFF | gate | - | 0.08 | 136.9 |

### Plans: h5-mine-8766b98-p1

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 2.3 | 47% | 312 | 153 | 49% |
| Mine | join | 0.3 | 100% | 11 | 0 | 0% |
| Mine | move | 25.4 | 94% | 1499 | 0 | 0% |
| Mine | shoot | 13.1 | 58% | 540 | 1266 | 234% |
| Mine | support | 0.2 | 50% | 8 | 0 | 0% |
| Opponent | charge | 2.6 | 59% | 486 | 171 | 35% |
| Opponent | join | 0.8 | 100% | 46 | 0 | 0% |
| Opponent | move | 32.8 | 94% | 1581 | 0 | 0% |
| Opponent | shoot | 6.9 | 51% | 180 | 268 | 149% |
| Opponent | support | 0.2 | 33% | 10 | 0 | 0% |

### Battle groups: h5-mine-8766b98-p1

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 1.2 | 12% | 100% | 0% | - | 0% | 0% | 0% | 100% | 0% |
| Opponent | REDIRECT COUNTER | 2.5 | 21% | 100% | 0% | - | 14% | 0% | 14% | 71% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: h5-mine-8766b98-p1

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 0% | 6.0 | - | - | 0 (1) | - | 0 (1) |
| Mine | Chaff | 8 | 44 (8) | 0 | 44 | 49 | 50% | 2.8 | - | 51 (7) | 0 (1) | 66 (5) | 0 (3) |
| Mine | Character | 51 | 36 (51) | 36 | 0 | 23 | 20% | 2.5 | 34 (27) | 46 (15) | 35 (7) | 32 (36) | 51 (13) |
| Mine | Clean-up | 8 | 65 (8) | 25 | 40 | 29 | 25% | 4.0 | 93 (3) | 11 (4) | 144 (1) | 74 (7) | 25 (1) |
| Mine | Fast | 3 | 0 (3) | 0 | 0 | 67 | 0% | 2.0 | - | 0 (1) | 0 (2) | 0 (2) | 0 (1) |
| Mine | Fast Hammer | 12 | 51 (12) | 33 | 18 | 39 | 42% | 3.7 | - | 52 (9) | 43 (3) | 43 (5) | 59 (7) |
| Mine | Hammer | 26 | 32 (26) | 9 | 23 | 30 | 31% | 2.7 | 38 (7) | 31 (11) | 25 (8) | 36 (16) | 23 (10) |
| Mine | Holder | 12 | 99 (12) | 29 | 70 | 27 | 67% | 3.2 | 153 (2) | 108 (6) | 51 (4) | 125 (6) | 75 (6) |
| Mine | Shooter | 12 | 91 (12) | 16 | 75 | 33 | 0% | 1.5 | 5 (5) | 185 (5) | 48 (2) | 119 (10) | 0 (2) |
| Mine | War machine | 33 | 76 (33) | 76 | 0 | 44 | 3% | 1.4 | 74 (15) | 49 (12) | 137 (6) | 0 (3) | 84 (30) |
| Mine | Wizard | 7 | 0 (7) | 0 | 0 | 27 | 43% | 3.0 | 0 (4) | 0 (1) | 0 (2) | 0 (2) | 0 (5) |
| Opponent | Chaff | 22 | 129 (22) | 9 | 119 | 29 | 41% | 2.9 | 75 (9) | 207 (7) | 101 (6) | 170 (16) | 22 (6) |
| Opponent | Character | 34 | 42 (34) | 42 | 0 | 34 | 26% | 2.1 | 30 (8) | 35 (18) | 75 (7) | 36 (16) | 48 (17) |
| Opponent | Clean-up | 11 | 62 (11) | 23 | 39 | 30 | 73% | 4.0 | 0 (1) | 60 (9) | 237 (1) | 94 (6) | 43 (5) |
| Opponent | Early | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | - | 0 (1) | - | 0 (1) |
| Opponent | Fast | 1 | 1198 (1) | 1198 | 0 | 0 | 0% | 1.0 | - | 1198 (1) | - | 1198 (1) | - |
| Opponent | Fast Hammer | 10 | 40 (10) | 27 | 12 | 53 | 30% | 2.6 | 84 (2) | 31 (6) | 38 (2) | 32 (5) | 46 (5) |
| Opponent | Fragile | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | - | 0 (1) | 0 (1) | - |
| Opponent | Hammer | 24 | 30 (24) | 16 | 15 | 34 | 25% | 2.5 | 0 (3) | 30 (15) | 48 (6) | 29 (16) | 33 (8) |
| Opponent | Holder | 16 | 98 (16) | 11 | 87 | 3 | 69% | 2.8 | 132 (10) | 0 (3) | 136 (3) | 100 (9) | 95 (7) |
| Opponent | Shooter | 13 | 31 (13) | 8 | 23 | 24 | 8% | 1.7 | 0 (2) | 33 (11) | - | 67 (5) | 12 (8) |
| Opponent | War machine | 14 | 0 (14) | 0 | 0 | 65 | 7% | 1.5 | 0 (2) | 0 (4) | 0 (8) | 0 (3) | 0 (11) |
| Opponent | Wizard | 7 | 28 (7) | 28 | 0 | 0 | 14% | 2.3 | 0 (2) | 2 (4) | 135 (1) | 0 (2) | 33 (5) |

### Charged fights: h5-mine-8766b98-p1

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 143 | 109 | 2.5 | 1.1 | 44 | 19 | +25 | 4 of 10 | 6 of 10 | +0 | +27 |
| Mine | Chaos Dwarfs | 4 | 342 | 326 | 3.2 | 1.0 | 100 | 7 | +93 | 6 of 13 | 10 of 13 | - | +93 |
| Mine | Dwarfen Mountain Holds | 4 | 591 | 0 | 1.0 | 1.2 | 0 | 15 | -15 | 2 of 4 | 2 of 4 | -60 | +0 |
| Mine | Empire of Man | 1 | 268 | 370 | 5.0 | 1.0 | 74 | 0 | +74 | 0 of 5 | 5 of 5 | - | +74 |
| **Mine** | all armies | 13 | 352 | 162 | 2.5 | 1.1 | 66 | 11 | +55 | 12 of 32 | 23 of 32 | -30 | +61 |
| Opponent | Chaos Dwarfs | 3 | 112 | 162 | 2.0 | 1.0 | 81 | 52 | +29 | 2 of 6 | 4 of 6 | - | +29 |
| Opponent | Dwarfen Mountain Holds | 1 | 139 | 580 | 2.0 | 1.5 | 290 | 92 | +198 | 1 of 2 | 2 of 2 | +395 | +0 |
| Opponent | Grand Cathay | 1 | 239 | 778 | 4.0 | 1.0 | 194 | 0 | +194 | 2 of 4 | 2 of 4 | - | +194 |
| Opponent | High Elf Realms | 1 | 180 | 115 | 3.0 | 1.0 | 38 | 0 | +38 | 2 of 3 | 2 of 3 | - | +38 |
| Opponent | Ogre Kingdoms | 1 | 250 | 77 | 2.0 | 1.0 | 38 | 114 | -76 | 0 of 2 | 1 of 2 | - | -76 |
| Opponent | Orc & Goblin Tribes | 1 | 0 | 450 | 3.0 | 1.0 | 150 | 0 | +150 | 0 of 3 | 3 of 3 | - | +150 |
| Opponent | Skaven | 2 | 0 | 32 | 0.5 | 1.0 | 65 | 0 | +65 | 0 of 1 | 1 of 1 | - | +65 |
| Opponent | Tomb Kings of Khemri | 1 | 0 | 744 | 4.0 | 1.0 | 186 | 0 | +186 | 3 of 4 | 3 of 4 | - | +186 |
| Opponent | Vampire Counts | 1 | 0 | 820 | 4.0 | 1.0 | 205 | 12 | +192 | 3 of 4 | 2 of 4 | - | +192 |
| Opponent | Warriors of Chaos | 1 | 0 | 340 | 2.0 | 1.5 | 170 | 0 | +170 | 0 of 2 | 2 of 2 | +115 | +225 |
| **Opponent** | all armies | 13 | 88 | 343 | 2.4 | 1.1 | 144 | 25 | +119 | 13 of 31 | 22 of 31 | +255 | +109 |

### Effective charges: h5-mine-8766b98-p1

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 10 | 3 (net +52) | 0 | 3 (net +37) | 1 (net +0) | 0 | 3 (net -7) | 0 | 30% (3 of 10) |
| Mine | Chaos Dwarfs | 13 | 2 (net +0) | 0 | 1 (net +210) | 5 (net +135) | 2 (net +63) | 1 (net -91) | 2 | 9% (1 of 11) |
| Mine | Dwarfen Mountain Holds | 4 | 2 (net -30) | 0 | 1 (net +0) | 0 | 0 | 1 (net +0) | 0 | 25% (1 of 4) |
| Mine | Empire of Man | 5 | 0 | 0 | 1 (net +0) | 1 (net +185) | 2 (net +0) | 1 (net +185) | 0 | 20% (1 of 5) |
| Opponent | Chaos Dwarfs | 6 | 1 (net +0) | 0 | 1 (net -310) | 1 (net +315) | 1 (net +0) | 2 (net +85) | 0 | 17% (1 of 6) |
| Opponent | Dwarfen Mountain Holds | 2 | 1 (net +0) | 0 | 0 | 0 | 0 | 1 (net +395) | 0 | 0% (0 of 2) |
| Opponent | Grand Cathay | 4 | 2 (net +250) | 0 | 1 (net +117) | 1 (net +160) | 0 | 0 | 0 | 25% (1 of 4) |
| Opponent | High Elf Realms | 3 | 1 (net +0) | 0 | 1 (net +115) | 0 | 0 | 1 (net +0) | 0 | 33% (1 of 3) |
| Opponent | Ogre Kingdoms | 2 | 0 | 1 (net +77) | 0 | 0 | 0 | 1 (net -228) | 0 | 0% (0 of 2) |
| Opponent | Orc & Goblin Tribes | 3 | 0 | 0 | 0 | 0 | 2 (net +210) | 0 | 1 | 0% (0 of 2) |
| Opponent | Skaven | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +65) | 0 | 0% (0 of 1) |
| Opponent | Tomb Kings of Khemri | 4 | 0 | 0 | 1 (net +0) | 1 (net +310) | 0 | 2 (net +217) | 0 | 25% (1 of 4) |
| Opponent | Vampire Counts | 4 | 3 (net +163) | 0 | 1 (net +280) | 0 | 0 | 0 | 0 | 25% (1 of 4) |
| Opponent | Warriors of Chaos | 2 | 0 | 0 | 0 | 0 | 1 (net +115) | 1 (net +225) | 0 | 0% (0 of 2) |

### Charged fights, damage counted: h5-mine-8766b98-p1

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 7 | 136 | 339 | +14 | 90 | 26 | +64 | +47.1 |
| Mine | Effective (55-75%) | 6 | 120 | 163 | +53 | 60 | 4 | +55 | +45.9 |
| Mine | 76-89% | 7 | 349 | 131 | +123 | 127 | 10 | +117 | +33.6 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 6 | 291 | 175 | +12 | 108 | 62 | +45 | +15.6 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 4 | 244 | 50 | +32 | 39 | 0 | +39 | +15.9 |
| Mine | No odds | 2 | 410 | 118 | +146 | 146 | 0 | +146 | +35.5 |
| Mine | All fights | 32 | 239 | 180 | +55 | 93 | 20 | +72 | +30.3 |
| Opponent | Long shot (under 50%) | 8 | 300 | 220 | +124 | 190 | 68 | +122 | +40.7 |
| Opponent | 50-54% | 1 | 34 | 77 | +77 | 77 | 0 | +77 | +226.5 |
| Opponent | Effective (55-75%) | 5 | 272 | 226 | +40 | 102 | 80 | +23 | +8.3 |
| Opponent | 76-89% | 3 | 325 | 153 | +262 | 262 | 80 | +182 | +56.0 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 9 | 251 | 196 | +118 | 189 | 87 | +102 | +40.6 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 4 | 458 | 100 | +134 | 134 | 68 | +66 | +14.4 |
| Opponent | No odds | 1 | 55 | 30 | +30 | 30 | 0 | +30 | +54.5 |
| Opponent | All fights | 31 | 288 | 181 | +119 | 167 | 72 | +94 | +32.8 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| h5-mine-8766b98-p1 | move | 91 | 19 (21%) | 18 (20%) | 14 (15%) | 58 (64%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0103, L0120 |
| Charmed Shield | Opponent | L0525 |
| Elixir of Power | Opponent | L0219 |
| Fistful of Laurels | Opponent | L0718 |
| Invocation of Nehek | Opponent | L0525 |
| Periapt of Soul Exchange | Opponent | L0120, L0321 |
| Ring of Doom | Mine | L0204, L0219 |
| Ring of Jet | Opponent | L0510 |
| Standard of the Fell Warrior | Opponent | L0613 |
| Storm Daemon (Renegade 2.0) | Opponent | L0321 |
| Twice-Blessed Armour | Mine | L0718 |
| Twice-Blessed Armour | Opponent | L0510 |
| Witch Hunter's Ward | Mine | L0718 |

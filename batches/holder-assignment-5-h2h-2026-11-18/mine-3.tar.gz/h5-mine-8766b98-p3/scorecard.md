# Doctrine scorecard: h5-mine-8766b98-p3

### Scorecard: h5-mine-8766b98-p3

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0111 | 3 | 1 | Mine | yes | 3 | - | 0 | 3 | 0 | 0 | 0 | 0 |
| L0111 | 3 | 1 | Opponent | no | 9 | 4 | 2 | 0 | 0 | 0 | 0 | 0 |
| L0128 | 2 | 1 | Mine | - | - | - | 0 | 4 | 0 | 0 | 0 | 0 |
| L0128 | 2 | 1 | Opponent | - | - | - | 0 | 3 | 0 | 0 | 0 | 0 |
| L0211 | 1 | 1 | Mine | no | 0 | 3 | 1 | 4 | 1 | 0 | 0 | 255 |
| L0211 | 1 | 1 | Opponent | yes | 17 | 2 | 1 | 0 | 0 | 0 | 0 | 0 |
| L0228 | 6 | 1 | Mine | no | 0 | 2 | 3 | 4 | 0 | 0 | 0 | 170 |
| L0228 | 6 | 1 | Opponent | no | 11 | - | 0 | 0 | 0 | 0 | 0 | 0 |
| L0313 | 1 | 1 | Mine | no | 15 | - | 0 | 0 | 0 | 0 | 0 | 110 |
| L0313 | 1 | 1 | Opponent | no | 5 | 2 | 1 | 0 | 0 | 0 | 0 | 70 |
| L0330 | 6 | 1 | Mine | no | 5 | - | 1 | 1 | 0 | 0 | 0 | 530 |
| L0330 | 6 | 1 | Opponent | no | 12 | 2 | 1 | 2 | 0 | 0 | 0 | 285 |
| L0415 | 1 | 1 | Mine | no | 8 | 2 | 6 | 0 | 0 | 0 | 0 | 310 |
| L0415 | 1 | 1 | Opponent | no | 19 | 2 | 3 | 0 | 0 | 0 | 0 | 0 |
| L0432 | 6 | 1 | Mine | no | 2 | 2 | 1 | 0 | 0 | 0 | 0 | 0 |
| L0432 | 6 | 1 | Opponent | no | 0 | 2 | 5 | 4 | 1 | 0 | 0 | 340 |
| L0518 | 2 | 1 | Mine | - | - | 5 | 1 | 1 | 0 | 0 | 0 | 233 |
| L0518 | 2 | 1 | Opponent | - | - | 4 | 1 | 2 | 0 | 0 | 0 | 0 |
| L0534 | 6 | 1 | Mine | no | 6 | 4 | 0 | 1 | 0 | 0 | 0 | 472 |
| L0534 | 6 | 1 | Opponent | no | 1 | 3 | 3 | 2 | 0 | 0 | 0 | 500 |
| L0621 | 3 | 1 | Mine | no | 0 | - | 2 | 1 | 0 | 0 | 0 | 361 |
| L0621 | 3 | 1 | Opponent | no | 10 | - | 1 | 3 | 0 | 0 | 0 | 500 |
| L0710 | 2 | 1 | Mine | - | - | 4 | 3 | 2 | 0 | 0 | 0 | 0 |
| L0710 | 2 | 1 | Opponent | - | - | 4 | 2 | 0 | 0 | 0 | 0 | 369 |
| L0726 | 6 | 1 | Mine | no | 9 | 2 | 1 | 0 | 0 | 0 | 0 | 314 |
| L0726 | 6 | 1 | Opponent | no | 0 | 2 | 3 | 1 | 1 | 0 | 0 | 0 |
| **Average** | | | Mine | 10% | 4.8 | 3.0 | 1.5 | 1.6 | 0.1 | 0.0 | 0.0 | 211.9 |
| **Average** | | | Opponent | 10% | 8.4 | 2.7 | 1.8 | 1.3 | 0.2 | 0.0 | 0.0 | 158.8 |

### KPIs: h5-mine-8766b98-p3

Rules off - Opponent only: HOLDER ASSIGNMENT, QUARTER ODDS.

Morten 2026-11-10; 13 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 47% (28 of 60) | 9% (6 of 64) | 27% (34 of 124) |
| Winner chose to follow up after the loser gave ground |  | 90% (9 of 10); on the table 90% | 69% (11 of 16); on the table 75% | 77% (20 of 26); on the table 81% |
| Winner chose to pursue after the loser fell back in good order |  | 67% (2 of 3); on the table 100% | 50% (2 of 4); on the table 100% | 57% (4 of 7); on the table 100% |
| Winner chose to pursue after the loser fled |  | 83% (5 of 6); on the table 83% | 60% (6 of 10); on the table 80% | 69% (11 of 16); on the table 81% |
| Winner chose to follow up or pursue (all three) |  | 84% (16 of 19); on the table 89% | 63% (19 of 30); on the table 80% | 71% (35 of 49); on the table 84% |
| Magic missiles tried each own turn | 50%+ | 51% (70 of 138) | 31% (32 of 102) | 42% (102 of 240) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 57% (70 of 122) | 40% (32 of 81) | 50% (102 of 203) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 62% (5 of 8) | 45% (5 of 11) | 53% (10 of 19) |
| Points that never fought | lower | 62% (15782 of 25562) | 52% (13520 of 25993) | 57% (29302 of 51555) |
|   infantry points that never fought | lower | 68% (4627 of 6788) | 66% (2549 of 3879) | 67% (7176 of 10667) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 62% (61 of 98) | 52% (51 of 98) | 57% (112 of 196) |
| Bound items with a magic missile used (at least once a game) |  | 100% (6 of 6); 1.5 uses a game | 91% (10 of 11); 2.9 uses a game | 94% (16 of 17); 2.2 uses a game |
| Bound items with another spell used |  | 100% (4 of 4); 0.7 uses a game | 33% (1 of 3); 0.2 uses a game | 71% (5 of 7); 0.4 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 80% (8 of 10); 0.6 uses a game | 33% (2 of 6); 0.2 uses a game | 62% (10 of 16); 0.4 uses a game |
|   their share of the points of units over 100 pts | lower | 61% (12103 of 19862) | 48% (11355 of 23683) | 54% (23458 of 43545) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 2.5 (49%) | 0.9 (17%) | 3.5 (33%) |
| MARCHED: its unit marched | 1.2 (22%) | 1.8 (33%) | 2.9 (28%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.3 (6%) | 0.3 (3%) |
| IN COMBAT: engaged in combat | 0.4 (7%) | 0.5 (10%) | 0.9 (9%) |
| REAR RANK: in a rear rank | 0.3 (6%) | 0.4 (7%) | 0.7 (7%) |
| FLEEING: fleeing | 0.0 (0%) | 0.2 (3%) | 0.2 (1%) |
| GONE: slain | 0.8 (16%) | 0.9 (17%) | 1.8 (17%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.2 (3%) | 0.2 (1%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.2 (4%) | 0.2 (2%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 3.8 | 1.7 | 1.6 | 7.8 | 0.4 | 1.3 |
| not cast | 2.6 | 4.8 | 3.0 | 10.6 | 1.9 | 21.8 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.9 (4%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.9 (40%) | 0.1 (3%) | 3.5 (33%) | 0.3 (16%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.9 (28%) | 0.4 (20%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (3%) | 0.2 (8%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.4 (15%) | 0.1 (2%) | 0.2 (5%) | 0.9 (9%) | 0.2 (12%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.1 (3%) | 1.0 (21%) | 0.0 (0%) | 0.7 (7%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (0%) | 0.2 (3%) | 0.0 (0%) | 0.2 (1%) | 0.0 (0%) | 0.1 (0%) |
| GONE: slain | 0.2 (6%) | 0.3 (6%) | 1.0 (33%) | 1.8 (17%) | 0.5 (28%) | 3.0 (14%) |
| OFF THE TABLE: off the table or not arrived | 0.2 (6%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (0%) |
| STUPIDITY: Stupidity | 0.1 (3%) | 0.1 (2%) | 0.1 (3%) | 0.2 (1%) | 0.0 (0%) | 0.5 (2%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.3 (6%) | 0.0 (0%) | 0.0 (0%) | 0.3 (16%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (2%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.8 (68%) | 0.9 (19%) | 1.7 (56%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 17.2 (79%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.5 a game | 0.5 a game | 1.0 a game |
| stood (cast and not dispelled) | 63% (12 of 19) | 0% (0 of 1) | 60% (12 of 20) |
| the unit moved after it | 50% (6 of 12) | - | 50% (6 of 12) |
| it charged on its next turn | 8% (1 of 12) | - | 8% (1 of 12) |
| the enemy charged it first | 8% (1 of 12) | - | 8% (1 of 12) |
| it fought by the end of its next turn | 8% (1 of 12) | - | 8% (1 of 12) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 12) | - | 0% (0 of 12) |
| none of these (no charge, no fight, no charge escaped) | 83% (10 of 12) | - | 83% (10 of 12) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 68% (248 of 365) | 49% (105 of 213) | 61% (353 of 578) |
|   cavalry | 67% (12 of 18) | 44% (8 of 18) | 56% (20 of 36) |
|   character | 78% (31 of 40) | 31% (13 of 42) | 54% (44 of 82) |
|   chariot | 47% (18 of 38) | 56% (15 of 27) | 51% (33 of 65) |
|   infantry | 55% (50 of 91) | 50% (33 of 66) | 53% (83 of 157) |
|   monster | 100% (6 of 6) | 58% (7 of 12) | 72% (13 of 18) |
|   war machine | 76% (131 of 172) | 60% (29 of 48) | 73% (160 of 220) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.2 (24%) | 2.9 (35%) | 5.1 (29%) |
| CHARGED: it charged | 0.2 (2%) | 1.2 (14%) | 1.3 (8%) |
| FLEEING: it fled or was fleeing | 0.1 (1%) | 0.2 (2%) | 0.2 (1%) |
| IN COMBAT: it fought this turn or the last | 0.9 (10%) | 0.2 (3%) | 1.2 (7%) |
| MOVED: a war machine that moved | 2.0 (22%) | 1.2 (15%) | 3.2 (19%) |
| NO TARGET IN RANGE | 1.5 (16%) | 1.0 (12%) | 2.5 (14%) |
| ONLY IN COMBAT: the only targets were in combat | 0.3 (3%) | 0.2 (2%) | 0.5 (3%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.2 (14%) | 0.7 (8%) | 1.9 (11%) |
| SHELTERED: the target was sheltered | 0.5 (5%) | 0.5 (6%) | 1.0 (6%) |
| STUPIDITY | 0.0 (0%) | 0.1 (1%) | 0.1 (0%) |
| OTHER BAR | 0.2 (3%) | 0.2 (2%) | 0.4 (2%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 1.8 | 0.6 | 75% | 5.7 pts | 11 pts |
| character | 4.2 | 1.6 | 70% | 10.0 pts | 42 pts |
| chariot | 2.5 | 2.5 | 42% | 21.3 pts | 54 pts |
| infantry | 10.5 | 3.5 | 74% | 7.5 pts | 79 pts |
| monster | 1.0 | 0.2 | 85% | 1.1 pts | 1 pts |
| war machine | 12.3 | 9.8 | 59% | 22.3 pts | 274 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 2.1 | 3.5 | 2.8 |
| Charges that made contact a game | 1.8 | 2.7 | 2.2 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.33 declared, 0.17 contact (6 units) | 0.80 declared, 0.50 contact (10 units) | 0.62 declared, 0.38 contact (16 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.50 declared, 0.50 contact (2 units) | 2.00 declared, 1.50 contact (2 units) | 1.25 declared, 1.00 contact (4 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.28 declared, 0.24 contact (87 units) | 0.38 declared, 0.30 contact (90 units) | 0.33 declared, 0.27 contact (177 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 43% (9 of 21) | 0% (0 of 2) | 14% (1 of 7) | 33% (10 of 30) |
| Character in a unit | 90% (19 of 21) | 75% (12 of 16) | 50% (1 of 2) | 82% (32 of 39) |
| Character on its own | 57% (4 of 7) | 60% (6 of 10) | 44% (8 of 18) | 51% (18 of 35) |
| Chariot | 88% (7 of 8) | 75% (6 of 8) | - | 81% (13 of 16) |
| Infantry | 29% (6 of 21) | 40% (6 of 15) | 0% (0 of 1) | 32% (12 of 37) |
| Monster | 67% (4 of 6) | 67% (2 of 3) | - | 67% (6 of 9) |
| Monstrous | 100% (3 of 3) | 67% (2 of 3) | - | 83% (5 of 6) |
| War Machines | 64% (14 of 22) | 100% (2 of 2) | - | 67% (16 of 24) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | - | 53% (54 of 102) | 79% | 68% (15 of 22) | 100% (6 of 6); 4.8 uses a game | 100% (2 of 2); 1.2 uses a game | 83% (5 of 6); 1.2 uses a game |
| Chaos Dwarfs | 4 | 75% (9 of 12); on the table 83% | 44% (16 of 36) | 53% | 53% (17 of 32) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
| Dwarfen Mountain Holds | 3 | 100% (3 of 3); on the table 100% | - | 61% | 62% (15 of 24) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 2 | 100% (4 of 4); on the table 100% | - | 48% | 70% (14 of 20) | 0.0 uses a game | 100% (2 of 2); 2.0 uses a game | 100% (2 of 2); 1.0 uses a game |
| Grand Cathay | 3 | 40% (2 of 5); on the table 60% | 35% (23 of 66) | 56% | 50% (13 of 26) | 83% (5 of 6); 5.7 uses a game | 100% (1 of 1); 0.7 uses a game | 33% (1 of 3); 0.3 uses a game |
| High Elf Realms | 2 | 71% (5 of 7); on the table 71% | 0% (0 of 6) | 45% | 47% (7 of 15) | 100% (3 of 3); 7.5 uses a game | 0% (0 of 2); 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 1 | 75% (3 of 4); on the table 75% | 0% (0 of 6) | 50% | 43% (3 of 7) | 100% (1 of 1); 3.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Skaven | 1 | 0% (0 of 2); on the table 100% | 50% (3 of 6) | 82% | 67% (6 of 9) | 100% (1 of 1); 3.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Vampire Counts | 1 | 67% (2 of 3); on the table 67% | 17% (1 of 6) | 36% | 60% (3 of 5) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 4 | 100% (5 of 5); on the table 100% | 42% (5 of 12) | 49% | 57% (16 of 28) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Wood Elf Realms | 1 | 50% (2 of 4); on the table 100% | - | 54% | 38% (3 of 8) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (h5-mine-8766b98-p3, 13 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 46% (11) | 50% (9) | 48% (20) |
| ...free all their last turn and able to turn (per game) | 0.46 | 0.62 | 1.08 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.15 | 0.00 | 0.15 |
| ...with the charger already in that arc before they moved (per game) | 0.38 | 0.23 | 0.62 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.15 | 0.08 | 0.23 |

### Quality by phase: h5-mine-8766b98-p3

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.8 | 2.5 |
| Strategy | Charge objectives carried out (made contact) | 81% (22 of 27) | 72% (28 of 39) |
| Strategy | Shoot objectives carried out (shot that target) | 41% (86 of 208) | 46% (31 of 68) |
| Strategy | Support requests answered (helper made contact too) | - | 50% (1 of 2) |
| Strategy | Hexes on a unit its side charged or shot that turn | 0% (0 of 1) | 50% (2 of 4) |
| Strategy | Joined characters whose unit fought | 11% (4 of 35) | 39% (7 of 18) |
| Strategy | Lone characters that fought | 58% (14 of 24) | 71% (15 of 21) |
| Movement | Charges halted short of contact | 0.0 | 0.1 |
| Movement | Idle units | 1.6 | 1.3 |
| Movement | Points that never moved of their own | 211.9 | 158.8 |
| Movement | Fights charged into per game | 1.8 | 2.5 |
| Movement | Charges with odds: long shots (under 50%) | 6 of 23, net -17 | 5 of 29, net +28 |
| Movement | Charges with odds: sweet spot (55-75%) | 2 of 23, net +198 | 4 of 29, net +40 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 23 | 3 of 29, net +0 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 6 of 23, net +50 | 8 of 29, net +124 |
| Shooting | Shots by shooting units (incl. breath weapons) | 9.6 | 6.8 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 34% (43 of 125) | 51% (45 of 88) |
| Shooting | Points destroyed by shooting units | 82.6 | 0.0 |
| Shooting | War machine shots | 10.1 | 2.2 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 40% (52 of 131) | 69% (20 of 29) |
| Shooting | Points destroyed by war machines | 110.7 | 58.1 |
| Magic | Magic missiles cast | 2.2 | 1.7 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 34% (10 of 29) | 45% (10 of 22) |
| Magic | Wounds caused by magic missiles | 4.5 | 4.2 |
| Magic | Wounds caused by other spells | 0.8 | 0.6 |
| Magic | Points destroyed by magic (all spells) | 26.3 | 24.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.2 / 0.1 / 0.9 / 0.2 | 1.2 / 0.5 / 0.2 / 0.0 |
| Combat | Points destroyed in combat | 85.1 | 337.5 |
| Combat | Points run down | 36.4 | 72.9 |
| Combat | Net points per charged fight, damage counted | +43 | +109 |
| Combat | Net per 100 charger points, damage counted | +24.1 | +34.5 |
| Combat | First round won (charged fights) | 65% | 81% |
| Combat | Net points per charged fight | +39 | +114 |
| Combat | Net points per supported fight / lone fight | - / +39 | +113 / +115 |
| Combat | Charged fights on a top-3 enemy unit | 7 of 23 | 15 of 32 |
| Game | Points lost | 524.7 | 421.5 |
| Game | VP from objectives | 514.6 | 799.2 |
| Game | Lone holders (player turns) | 4.8 | 8.4 |

- Mine won / drew / lost: 1 / 4 / 8 of 13 ended games (of 13); mean margin (Mine - Opponent) -379 VP
- The side that went first won 4 of 9 games with a winner
- Points traded per game (both sides' losses): 946
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: h5-mine-8766b98-p3

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.5 | +0.0 | 0.0 | 0.0 | 0.5 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.1 | +46.0 | 0.0 | 23.8 | 0.2 | +31.1 | 0.0 | 0.0 |
| ALREADY CARRIED | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARRIVAL HUNT | - | - | - | - | 0.1 | +1.3 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 2.8 | +0.0 | 0.0 | 26.5 | 0.5 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | 0.2 | +0.6 | 0.0 | 0.0 | 0.2 | +0.4 | 0.0 | 0.0 |
| BEST PRIZE | - | - | - | - | 0.1 | -1.3 | 4.0 | 0.0 |
| BLOWS WHERE AIMED | - | - | - | - | 0.1 | -24.2 | 22.2 | 0.0 |
| BOMBING RUN | - | - | - | - | 0.2 | +6.5 | 28.6 | 11.5 |
| CANNON PLAN MISSED | 1.7 | +0.0 | 90.6 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CANNON PLANNED TARGET | 8.9 | +204.9 | 425.9 | 68.8 | 1.9 | +40.7 | 110.9 | 0.0 |
| CANNON SIGHT KEPT | 1.5 | +0.0 | 0.0 | 0.0 | 0.5 | +0.0 | 0.0 | 34.0 |
| CARRIES OUT COUNTER | - | - | - | - | 0.1 | -7.0 | 29.2 | 0.0 |
| CARRIES OUT SET-UP | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | -1.1 | 0.0 | 0.0 |
| CAST JOB | 0.6 | +17.9 | 45.6 | 0.0 | 0.4 | +5.5 | 4.2 | 0.0 |
| CASTER AWAY FROM SCREEN | 0.3 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.5 | +53.2 | 17.1 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 0.6 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 30.4 |
| CHAFF IN THE MOVE | 0.5 | +21.5 | 0.0 | 17.3 | 0.8 | +34.1 | 0.0 | 30.8 |
| CHAFF PASSED | 0.2 | -1.6 | 0.0 | 0.0 | 0.2 | -0.1 | 0.0 | 0.0 |
| CHARACTER GUNS | 0.4 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CHARGE LOSSES | 6.0 | -219.4 | 0.0 | 265.5 | 6.5 | -351.6 | 0.0 | 51.8 |
| CHARGE NOT DECLARED | 0.3 | +0.0 | 13.1 | 0.0 | 0.8 | +0.0 | 50.4 | 8.4 |
| CHARGE NOW FIRST | 1.0 | +0.0 | 19.3 | 29.2 | 1.5 | +0.0 | 208.5 | 22.8 |
| CHARGER SLAIN LOST | - | - | - | - | 0.2 | -0.7 | 0.0 | 0.0 |
| CHEAPEST HOLDER | - | - | - | - | 0.1 | -2.3 | 0.0 | 0.0 |
| COMBAT PIVOT | 0.2 | +0.0 | 0.0 | 47.7 | 0.2 | +0.0 | 8.6 | 17.7 |
| CONVEYANCE SEARCH | 1.3 | +144.2 | 87.1 | 85.8 | 0.1 | +2.9 | 0.0 | 0.0 |
| COVER ONCE | 7.4 | -446.5 | 0.0 | 120.5 | 4.3 | -250.6 | 0.0 | 93.2 |
| DEFENSIVE FLOOR | 0.1 | -5.8 | 0.0 | 6.2 | - | - | - | - |
| DEPLOY BY FIGURES | 8.3 | +50.6 | 0.0 | 11.5 | 7.3 | +32.3 | 0.0 | 33.1 |
| EDGE GIVE GROUND | 0.2 | +5.3 | 3.2 | 0.0 | - | - | - | - |
| ENGINEER BY LORE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FALL BACK GOOD ORDER | 1.5 | +0.8 | 22.9 | 40.8 | 2.4 | +18.5 | 306.2 | 27.5 |
| FALLBACK BY WORTH | 0.3 | +0.0 | 0.0 | 6.5 | 0.2 | +0.0 | 0.0 | 2.6 |
| FALLS SHORT | 4.8 | +89.0 | 0.0 | 126.5 | 18.6 | +320.4 | 0.0 | 169.7 |
| FEATURE BUFFS | 1.8 | +50.1 | 0.0 | 11.3 | 0.9 | +17.9 | 0.0 | 0.0 |
| FIGHT LIFT | 0.1 | +0.3 | 0.0 | 0.0 | - | - | - | - |
| FIGHT TO THE END | 1.0 | +45.7 | 24.4 | 34.2 | 1.2 | +154.5 | 213.2 | 27.5 |
| FIRE IN ORDER | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| FIVE ACTION | 49.0 | +2769.2 | 677.2 | 645.6 | 40.5 | +3069.3 | 511.5 | 434.9 |
| FLANK NOT WEIGHED | 4.5 | +0.0 | 0.0 | 111.1 | 5.4 | +0.0 | 0.0 | 68.5 |
| FOLLOW UP WEIGHED | 0.6 | +185.7 | 0.0 | 58.5 | 0.6 | +159.2 | 0.0 | 0.0 |
| FOUR ROUNDS | 2.1 | +211.7 | 50.4 | 53.5 | 3.0 | +468.8 | 320.5 | 35.8 |
| FRIEND CHARGES FIRST | 0.2 | -11.3 | 0.0 | 0.0 | 0.1 | -6.7 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 0.5 | -9.6 | 0.0 | 0.0 | 0.5 | -17.3 | 0.0 | 34.0 |
| FRIENDS SHOTS CHECKED | 0.2 | +1.0 | 0.0 | 0.0 | 0.2 | +18.8 | 0.0 | 0.0 |
| GIVES UP | 0.2 | -4.0 | 0.0 | 0.0 | 0.1 | -0.9 | 0.0 | 0.0 |
| GUN FIGURES | 1.2 | +16.0 | 30.7 | 56.5 | 0.3 | +4.6 | 5.0 | 19.2 |
| GUN MASK | 0.5 | +6.9 | 0.0 | 8.5 | 1.2 | +6.3 | 0.0 | 14.2 |
| HARD STAY DROPPED | 1.7 | +0.0 | 0.0 | 38.4 | 0.2 | +0.0 | 0.0 | 38.5 |
| HE SHOOTS OR CHARGES | 2.4 | +0.0 | 0.0 | 55.8 | 1.8 | +0.0 | 0.0 | 36.5 |
| HELPER ALREADY ASKED | - | - | - | - | 0.1 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE DENIED | 0.2 | +4.2 | 0.0 | 5.0 | 0.4 | +13.6 | 5.0 | 0.0 |
| HIS CHARGE LIST | 2.2 | +0.0 | 0.0 | 23.2 | 2.5 | +0.0 | 0.0 | 20.8 |
| HIS LEGAL MOVES | 3.2 | +0.0 | 0.0 | 101.0 | 4.1 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 2.8 | -23.2 | 0.0 | 71.6 | 1.5 | -28.3 | 0.0 | 37.5 |
| HIS RANDOM MOVE | 2.3 | +0.0 | 0.0 | 38.2 | 1.0 | +0.0 | 0.0 | 46.8 |
| HIS SHOT LIST | 18.9 | +681.6 | 0.0 | 220.8 | 21.4 | +1376.9 | 0.0 | 253.1 |
| HIS TURN DENIED | 0.6 | +16.7 | 27.9 | 0.0 | 1.7 | +78.9 | 213.7 | 13.0 |
| HOLD ODDS | 12.5 | +0.0 | 0.0 | 105.1 | - | - | - | - |
| HOLDER ASSIGNMENT | 15.0 | +1397.8 | 0.0 | 127.3 | - | - | - | - |
| HOLDER AT DEPLOYMENT | - | - | - | - | 1.5 | +222.0 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 1.7 | -43.0 | 50.4 | 34.2 | 2.6 | -111.2 | 313.2 | 35.8 |
| HUNT IN PAIRS | - | - | - | - | 0.5 | +12.5 | 0.0 | 0.0 |
| HUNT RESULT | - | - | - | - | 0.1 | +9.6 | 9.6 | 0.0 |
| HUNT THE GUNS | - | - | - | - | 0.1 | +16.0 | 9.6 | 0.0 |
| IDLE COST | 3.5 | -30.5 | 0.0 | 79.6 | 10.2 | -169.7 | 0.0 | 173.8 |
| JOINT KNOWS CHALLENGE | - | - | - | - | 0.1 | -2.1 | 0.0 | 0.0 |
| KEEP FALLS | 0.3 | +3.8 | 0.0 | 0.0 | 0.1 | +0.8 | 0.0 | 0.0 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| LANE BY FIGURES | 0.4 | +15.6 | 0.0 | 0.0 | 0.8 | +33.4 | 0.0 | 62.4 |
| LEGAL CHARGES ONLY | 4.2 | +0.0 | 95.0 | 215.8 | 2.2 | +0.0 | 175.9 | 119.2 |
| LONE CHARACTER SAFE SPOT | 0.2 | +4.2 | 0.0 | 0.0 | - | - | - | - |
| LONE WIZARD KEPT IN | 0.8 | +65.1 | 0.0 | 0.0 | 0.2 | +29.9 | 0.0 | 0.0 |
| LONG SHOT | 0.1 | -0.2 | 0.0 | 6.2 | 0.2 | -0.1 | 0.0 | 0.0 |
| LURE BY WHAT IT DRAWS | - | - | - | - | 0.1 | -1.4 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 0.2 | +8.5 | 0.0 | 0.0 | 0.2 | +5.3 | 0.0 | 22.8 |
| MANOEUVRE | 1.6 | +18.5 | 0.0 | 0.0 | 0.8 | +6.6 | 0.0 | 13.5 |
| MARCH AT ESCAPER | 0.2 | +1.7 | 0.0 | 0.0 | 0.1 | +0.1 | 0.0 | 0.0 |
| MARCH BY THE SUM | 0.2 | +19.8 | 0.0 | 0.0 | 0.8 | +30.1 | 0.0 | 17.9 |
| MARCH CHECK | 0.8 | +68.1 | 0.0 | 0.0 | 2.2 | +128.3 | 0.0 | 17.9 |
| MARCH OVER CASTS | 0.3 | -3.5 | 0.0 | 0.0 | 1.3 | +42.6 | 0.0 | 17.9 |
| MAX FOR POSITIONING | 4.6 | +68.5 | 0.0 | 28.0 | 7.5 | +87.0 | 0.0 | 70.5 |
| MISSILES IN THE MOVE | 4.7 | +256.0 | 0.0 | 63.5 | 4.9 | +68.4 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 4.5 | +166.5 | 0.0 | 63.5 | 6.4 | +55.7 | 0.0 | 17.9 |
| MODEL FACING | 0.5 | +149.5 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL IN RANGE | 0.2 | +4.5 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.8 | -113.5 | 0.0 | 58.5 | - | - | - | - |
| MOVE SPELL SPOT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 2.6 | +245.5 | 0.0 | 43.8 | 4.1 | +599.2 | 0.0 | 84.0 |
| MOVES UNITS SPELL | 0.2 | +8.5 | 0.0 | 0.0 | 0.1 | +0.6 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 7.0 | +306.6 | 0.0 | 64.5 | 3.1 | +193.7 | 0.0 | 11.3 |
| NEXT CHARGE BY LIST | 5.3 | -119.6 | 0.0 | 81.5 | 5.1 | -181.9 | 0.0 | 92.8 |
| NEXT OBJECTIVE NEARER | 0.3 | -4.5 | 0.0 | 9.2 | 7.2 | -361.0 | 0.0 | 71.6 |
| NO DOUBLE ROUNDS | 1.8 | -95.8 | 50.4 | 53.5 | 2.3 | -159.2 | 229.3 | 35.8 |
| NOT TURNED | 0.2 | +0.0 | 0.0 | 6.5 | 0.1 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 0.7 | -0.9 | 0.0 | 0.0 | 0.3 | -0.5 | 0.0 | 0.0 |
| OFF BEST | 0.3 | -21.1 | 0.0 | 5.0 | 0.2 | -14.7 | 0.0 | 4.2 |
| ONE CHARGE A CHARGER | 2.7 | +0.0 | 0.0 | 69.5 | 1.7 | +0.0 | 0.0 | 31.0 |
| ONE FIGHT FORMULA | 5.5 | -89.4 | 0.0 | 86.2 | 4.8 | -133.5 | 0.0 | 87.3 |
| ONE OBJECTIVE FORMULA | 6.8 | +41.2 | 0.0 | 109.2 | 4.5 | -97.3 | 0.0 | 49.7 |
| ONE TARGET A SHOOTER | 16.0 | +310.5 | 0.0 | 149.0 | 19.1 | +672.1 | 0.0 | 263.2 |
| OPENS A LANE | - | - | - | - | 0.1 | +0.1 | 0.0 | 0.0 |
| OPENS UP | - | - | - | - | 0.2 | +18.0 | 13.5 | 0.0 |
| OVERRUNS AWAY | 0.2 | +1.5 | 11.3 | 0.0 | 0.5 | +9.3 | 78.8 | 4.6 |
| PATHS CROSS | 3.5 | +308.2 | 0.0 | 11.6 | 4.5 | +158.9 | 0.0 | 14.7 |
| PERIAPT WORTH | - | - | - | - | 0.1 | +4.5 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.1 | -8.9 | 0.0 | 0.0 | 0.2 | -5.7 | 0.0 | 0.0 |
| PLAN RESULT | 43.5 | +967.1 | 245.2 | 801.5 | 35.8 | +449.8 | 325.1 | 505.9 |
| PURSUES BIG PREY | - | - | - | - | 0.1 | -11.0 | 0.0 | 0.0 |
| QUARTER ODDS | 2.7 | +444.8 | 16.7 | 0.0 | - | - | - | - |
| RANDOM MOVE BY FIGURES | 0.6 | +23.3 | 0.0 | 39.2 | 0.8 | +6.3 | 0.0 | 46.5 |
| REDIRECT BY WHAT IT STOPS | 0.5 | -30.4 | 0.0 | 17.3 | 0.5 | -35.9 | 0.0 | 6.3 |
| REDIRECT COUNTER | 2.0 | +154.4 | 0.0 | 22.2 | 4.3 | +207.0 | 0.0 | 74.9 |
| REDIRECT WEIGHED | - | - | - | - | 0.3 | -1.3 | 4.0 | 0.0 |
| REFORMS TO MEET IT | 0.7 | -24.4 | 0.0 | 0.0 | 0.8 | -45.4 | 0.0 | 5.2 |
| RESERVE FALL BACK | 0.4 | +16.8 | 0.0 | 17.2 | 0.1 | +6.8 | 0.0 | 0.0 |
| RESTRAINS TO SHOOT | - | - | - | - | 0.1 | +0.5 | 0.0 | 0.0 |
| RISK BY ARC | 1.8 | +59.8 | 36.8 | 47.0 | 1.6 | -7.1 | 189.6 | 22.8 |
| RISK BY HIS FIGURE | 12.9 | -161.1 | 0.0 | 319.2 | 12.2 | -204.8 | 0.0 | 198.6 |
| RUN DOWN | 1.5 | -16.0 | 34.2 | 5.0 | 2.2 | -14.0 | 217.8 | 27.5 |
| SAME CHARGE LATER | - | - | - | - | 0.2 | -2.3 | 0.0 | 0.0 |
| SCOUT SPOT | 0.5 | +1.8 | 0.0 | 0.0 | 0.2 | -0.0 | 0.0 | 0.0 |
| SCOUT WAITS | 0.5 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 0.7 | -33.5 | 0.0 | 9.9 |
| SEARCH SPOT | 5.4 | +188.5 | 0.0 | 38.6 | 7.1 | +282.8 | 0.0 | 51.8 |
| SELF MOVE SPELL | - | - | - | - | 0.5 | +73.1 | 0.0 | 60.8 |
| SET UP TOGETHER | 0.5 | +9.8 | 0.0 | 0.0 | 0.5 | +5.6 | 0.0 | 25.5 |
| SET-UP ANY TARGET | 0.3 | +40.6 | 29.2 | 29.2 | - | - | - | - |
| SHOOTER COUNTED ONCE | - | - | - | - | 0.1 | -0.1 | 0.0 | 3.1 |
| SHOOTERS IN TWO RANKS | 0.5 | +0.9 | 0.0 | 0.0 | 0.2 | +0.2 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.5 | +74.9 | 0.0 | 0.0 | 0.8 | +18.4 | 29.2 | 0.0 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SHOT OR CHARGE | - | - | - | - | 0.4 | -12.5 | 0.0 | 0.0 |
| SHOT RISK POINTS | 10.2 | +102.7 | 0.0 | 222.5 | 13.0 | -133.5 | 0.0 | 151.5 |
| SHOTS IN THE MOVE | 18.8 | +830.3 | 0.0 | 222.8 | 10.5 | +288.7 | 0.0 | 119.7 |
| SPELL SETS UP CHARGE | 0.7 | +333.6 | 29.2 | 29.2 | - | - | - | - |
| SPELL WORTH | 0.2 | +6.6 | 0.0 | 0.0 | 1.8 | +30.9 | 0.0 | 0.0 |
| SPELLS IN THE FIGHT | 0.3 | +9.2 | 3.1 | 29.2 | 0.4 | -4.5 | 58.5 | 0.0 |
| STAND AND SHOOT | 0.4 | -5.1 | 24.8 | 0.0 | 0.5 | -8.8 | 54.7 | 13.0 |
| STANDS FOR A REASON | - | - | - | - | 0.6 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 23.4 | +0.0 | 626.8 | 249.5 | 8.6 | +0.0 | 191.1 | 35.4 |
| STAY WORTH | 24.6 | +111.8 | 512.3 | 148.8 | 12.4 | +85.2 | 132.6 | 131.5 |
| STOPS | - | - | - | - | 0.1 | +1.3 | 9.6 | 0.0 |
| SUPPORT NARROWED | 0.7 | +0.0 | 9.4 | 5.0 | 0.7 | +0.0 | 50.4 | 0.0 |
| SURE REACH TOGETHER | 0.2 | +2.7 | 0.0 | 5.0 | 0.5 | +3.2 | 0.0 | 22.8 |
| THE DEARER SUM KEEPS ITS PLAN | 3.8 | +0.0 | 0.0 | 3.2 | 5.0 | +0.0 | 0.0 | 28.9 |
| THE PROMISE ADDS | - | - | - | - | 0.2 | -12.8 | 0.0 | 0.0 |
| THE PROMISED MOVE | 0.5 | +0.0 | 0.0 | 28.6 | - | - | - | - |
| TIED UP BY THE SUM | 0.2 | +3.1 | 6.3 | 0.0 | 0.5 | +68.7 | 23.8 | 0.0 |
| TIME ON OUR SIDE | 28.9 | +475.8 | 2.6 | 360.1 | 5.3 | +103.1 | 0.0 | 70.0 |
| WAITS AGAIN | 1.2 | +0.0 | 0.0 | 0.0 | 1.8 | +0.0 | 0.0 | 4.6 |
| WAR ENGINE JOBS | 0.4 | +0.0 | 19.4 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| WHO HITS BACK | 0.2 | +19.3 | 0.0 | 5.0 | 0.1 | +3.9 | 0.0 | 0.0 |
| WHOLE FIGHT | 0.2 | +5.2 | 0.0 | 0.0 | 0.2 | +11.4 | 58.5 | 0.0 |
| WHOLE FIGHT GAIN | - | - | - | - | 0.2 | +8.8 | 5.0 | 0.0 |
| WIDER SPREAD | 1.5 | -3.7 | 33.7 | 34.2 | 2.2 | -8.4 | 245.8 | 27.5 |
| WOUNDS ON THE RANKS | 1.3 | +57.1 | 0.0 | 57.2 | 1.4 | +42.0 | 0.0 | 0.0 |

### Rule changes: h5-mine-8766b98-p3

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HOLDER ASSIGNMENT | 195 | 195 | 183 | 14.08 | +10246 | +56.0 |
| HIS SHOT LIST | 524 | 524 | 164 | 12.62 | +4331 | +26.4 |
| SEARCH SPOT | 162 | 162 | 151 | 11.62 | +6174 | +40.9 |
| ONE TARGET A SHOOTER | 456 | 456 | 122 | 9.38 | +1205 | +9.9 |
| DEPLOY BY FIGURES | 203 | 203 | 115 | 8.85 | +1537 | +13.4 |
| PATHS CROSS | 104 | 104 | 104 | 8.00 | +6072 | +58.4 |
| TIME ON OUR SIDE | 445 | 388 | 85 | 6.54 | +256 | +3.0 |
| LEGAL CHARGES ONLY | 83 | 83 | 83 | 6.38 | +0 | +0.0 |
| FIVE ACTION | 1163 | 1161 | 81 | 6.23 | +3040 | +37.5 |
| MOVE TO CHARGE COMPUTED | 87 | 87 | 57 | 4.38 | +3569 | +62.6 |
| SHOT RISK POINTS | 302 | 302 | 48 | 3.69 | +1409 | +29.4 |
| ARTILLERY RE-ROLL WEIGHED | 42 | 42 | 42 | 3.23 | +0 | +0.0 |
| FOUR ROUNDS | 66 | 64 | 37 | 2.85 | +3116 | +84.2 |
| MAX FOR POSITIONING | 158 | 158 | 33 | 2.54 | +91 | +2.8 |
| CANNON PLANNED TARGET | 141 | 141 | 32 | 2.46 | -523 | -16.4 |
| COVER ONCE | 152 | 119 | 32 | 2.46 | +533 | +16.6 |
| MARCH CHECK | 39 | 39 | 30 | 2.31 | +728 | +24.2 |
| CANNON SIGHT KEPT | 27 | 27 | 27 | 2.08 | +0 | +0.0 |
| REDIRECT COUNTER | 82 | 75 | 26 | 2.00 | +1404 | +54.0 |
| HARD STAY DROPPED | 25 | 25 | 25 | 1.92 | +0 | +0.0 |
| CHARGE LOSSES | 162 | 162 | 21 | 1.62 | +1226 | +58.4 |
| SHOTS IN THE MOVE | 380 | 358 | 21 | 1.62 | +677 | +32.2 |
| IDLE COST | 178 | 148 | 20 | 1.54 | +173 | +8.7 |
| RISK BY HIS FIGURE | 326 | 326 | 19 | 1.46 | +1024 | +53.9 |
| MISSILES IN THE MOVE | 125 | 100 | 18 | 1.38 | +599 | +33.3 |
| NEARER NOT NEEDED | 131 | 125 | 18 | 1.38 | +586 | +32.6 |
| SHOOTS FROM THE BEST SPOT | 31 | 31 | 18 | 1.38 | +317 | +17.6 |
| FOLLOW UP WEIGHED | 16 | 16 | 16 | 1.23 | +4484 | +280.2 |
| NEXT CHARGE BY LIST | 135 | 135 | 16 | 1.23 | +298 | +18.6 |
| NEXT OBJECTIVE NEARER | 98 | 98 | 16 | 1.23 | +530 | +33.1 |
| LANE BY FIGURES | 15 | 15 | 15 | 1.15 | +638 | +42.5 |
| RISK BY ARC | 45 | 44 | 15 | 1.15 | +277 | +18.5 |
| CHARGE NOT DECLARED | 14 | 14 | 14 | 1.08 | -2662 | -190.2 |
| MANOEUVRE | 31 | 31 | 14 | 1.08 | +334 | +23.8 |
| ONE OBJECTIVE FORMULA | 148 | 131 | 14 | 1.08 | +1000 | +71.4 |
| ADVANCE LANE KEPT | 13 | 13 | 13 | 1.00 | +0 | +0.0 |
| HIS TURN DENIED | 30 | 29 | 13 | 1.00 | +263 | +20.2 |
| LONE WIZARD KEPT IN | 13 | 13 | 13 | 1.00 | +1236 | +95.0 |
| MARCH BY THE SUM | 13 | 13 | 13 | 1.00 | +649 | +49.9 |
| HOLDER AT DEPLOYMENT | 19 | 19 | 12 | 0.92 | +376 | +31.4 |
| CHAFF IN THE MOVE | 17 | 16 | 11 | 0.85 | +0 | +0.0 |
| FALLS SHORT | 305 | 274 | 11 | 0.85 | +148 | +13.5 |
| HOLDS AMBUSHERS | 10 | 10 | 10 | 0.77 | +0 | +0.0 |
| QUARTER ODDS | 35 | 35 | 10 | 0.77 | +1095 | +109.5 |
| RANDOM MOVE BY FIGURES | 19 | 19 | 10 | 0.77 | +385 | +38.5 |
| CAST JOB | 13 | 13 | 9 | 0.69 | +84 | +9.3 |
| ONE FIGHT FORMULA | 134 | 83 | 9 | 0.69 | +45 | +5.1 |
| SCOUT WAITS | 9 | 9 | 9 | 0.69 | +0 | +0.0 |
| TIED UP BY THE SUM | 9 | 9 | 9 | 0.69 | +297 | +33.0 |
| FIGHT TO THE END | 28 | 27 | 8 | 0.62 | +1059 | +132.3 |
| SHOOTERS IN TWO RANKS | 8 | 8 | 8 | 0.62 | +14 | +1.8 |
| MODEL FACING | 7 | 7 | 7 | 0.54 | +1944 | +277.7 |
| OFF BEST | 7 | 7 | 7 | 0.54 | -466 | -66.5 |
| CHARGE NOW FIRST | 32 | 32 | 6 | 0.46 | -289 | -48.1 |
| RESERVE FALL BACK | 6 | 6 | 6 | 0.46 | +307 | +51.2 |
| STAY WORTH | 481 | 462 | 6 | 0.46 | +40 | +6.6 |
| WOUNDS ON THE RANKS | 35 | 35 | 6 | 0.46 | +186 | +31.0 |
| CASTER AWAY FROM SCREEN | 5 | 5 | 5 | 0.38 | +0 | +0.0 |
| CASTING BLOCK | 7 | 7 | 5 | 0.38 | +52 | +10.4 |
| FEATURE BUFFS | 36 | 36 | 5 | 0.38 | +62 | +12.3 |
| KEEP FALLS | 5 | 5 | 5 | 0.38 | +110 | +22.0 |
| SURE REACH TOGETHER | 10 | 10 | 5 | 0.38 | +10 | +2.0 |
| AFTERMATH IN POINTS | 4 | 4 | 4 | 0.31 | +1002 | +250.6 |
| CHAFF PASSED | 4 | 4 | 4 | 0.31 | -21 | -5.3 |
| COMBAT PIVOT | 4 | 4 | 4 | 0.31 | +0 | +0.0 |
| FRIENDS SHOTS CHECKED | 4 | 4 | 4 | 0.31 | +257 | +64.2 |
| REDIRECT WEIGHED | 4 | 4 | 4 | 0.31 | +8 | +2.0 |
| WHO HITS BACK | 4 | 4 | 4 | 0.31 | +205 | +51.3 |
| BOMBING RUN | 3 | 3 | 3 | 0.23 | +85 | +28.3 |
| HIS MOVE AND SHOT | 55 | 55 | 3 | 0.23 | +12 | +4.1 |
| MOVES UNITS SPELL | 3 | 3 | 3 | 0.23 | +118 | +39.2 |
| PIVOT GUARDS FLANK | 3 | 3 | 3 | 0.23 | -189 | -63.0 |
| SHORT GUN FORWARD | 3 | 3 | 3 | 0.23 | +0 | +0.0 |
| FIRE IN ORDER | 2 | 2 | 2 | 0.15 | +0 | +0.0 |
| GUN MASK | 23 | 23 | 2 | 0.15 | +47 | +23.3 |
| HONEST WORTH | 56 | 55 | 2 | 0.15 | +55 | +27.4 |
| HUNT IN PAIRS | 6 | 3 | 2 | 0.15 | +89 | +44.3 |
| NO DOUBLE ROUNDS | 54 | 54 | 2 | 0.15 | +44 | +21.8 |
| SUPPORT NARROWED | 18 | 18 | 2 | 0.15 | -19 | -9.4 |
| BEST PRIZE | 1 | 1 | 1 | 0.08 | -31 | -31.0 |
| CARRIES OUT COUNTER | 1 | 1 | 1 | 0.08 | -91 | -90.7 |
| CARRIES OUT SET-UP | 2 | 2 | 1 | 0.08 | -15 | -14.7 |
| HIS CHARGE DENIED | 7 | 7 | 1 | 0.08 | +20 | +19.9 |
| KEEPS SCOUTS OR AMBUSH | 1 | 1 | 1 | 0.08 | +0 | +0.0 |
| OVERRUNS AWAY | 10 | 10 | 1 | 0.08 | +31 | +31.3 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.08 | +58 | +58.3 |
| PURSUES BIG PREY | 1 | 1 | 1 | 0.08 | -142 | -142.4 |
| REFORMS TO MEET IT | 20 | 20 | 1 | 0.08 | +8 | +8.3 |
| RESTRAINS TO SHOOT | 1 | 1 | 1 | 0.08 | +7 | +7.1 |
| SAME CHARGE LATER | 2 | 2 | 1 | 0.08 | +0 | +0.0 |
| SCREEN BY WHAT IT SAVES | 9 | 9 | 1 | 0.08 | +40 | +39.7 |
| SET UP TOGETHER | 13 | 11 | 1 | 0.08 | +36 | +36.1 |
| WHOLE FIGHT | 6 | 5 | 1 | 0.08 | +24 | +24.1 |
| WHOLE FIGHT GAIN | 3 | 2 | 1 | 0.08 | +37 | +36.9 |
| ALREADY CARRIED | 1 | not checked | - | - | - | - |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| BACKUP TARGETS | 5 | 3 | 0 | 0.00 | - | - |
| BLOWS WHERE AIMED | 1 | 1 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 25 | 25 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 12 | trace | - | - | - | - |
| CHARACTER GUNS | 8 | 8 | 0 | 0.00 | - | - |
| CHARGER SLAIN LOST | 2 | 2 | 0 | 0.00 | - | - |
| CHEAPEST HOLDER | 1 | 1 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 18 | not checked | - | - | - | - |
| DEFENSIVE FLOOR | 1 | 1 | 0 | 0.00 | - | - |
| EDGE GIVE GROUND | 2 | 2 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 51 | 50 | 0 | 0.00 | - | - |
| FALLBACK BY WORTH | 6 | 6 | 0 | 0.00 | - | - |
| FIGHT LIFT | 1 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 129 | not checked | - | - | - | - |
| FRIEND CHARGES FIRST | 4 | 4 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 13 | 13 | 0 | 0.00 | - | - |
| GIVES UP | 3 | 3 | 0 | 0.00 | - | - |
| GUN FIGURES | 20 | not checked | - | - | - | - |
| HE SHOOTS OR CHARGES | 54 | 54 | 0 | 0.00 | - | - |
| HELPER ALREADY ASKED | 1 | not checked | - | - | - | - |
| HIS CHARGE LIST | 61 | 61 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 94 | 94 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 43 | 43 | 0 | 0.00 | - | - |
| HOLD ODDS | 163 | 163 | 0 | 0.00 | - | - |
| HUNT RESULT | 1 | trace | - | - | - | - |
| HUNT THE GUNS | 1 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 2 | not checked | - | - | - | - |
| LONG SHOT | 3 | 2 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 1 | 1 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 6 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 3 | trace | - | - | - | - |
| MARCH OVER CASTS | 21 | 21 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 142 | 105 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 3 | 3 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 11 | trace | - | - | - | - |
| MOVE SPELL SPOT | 4 | not checked | - | - | - | - |
| NOT TURNED | 3 | 3 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 13 | not checked | - | - | - | - |
| ONE CHARGE A CHARGER | 57 | 57 | 0 | 0.00 | - | - |
| OPENS A LANE | 1 | not checked | - | - | - | - |
| OPENS UP | 3 | 3 | 0 | 0.00 | - | - |
| PLAN RESULT | 1031 | trace | - | - | - | - |
| REDIRECT BY WHAT IT STOPS | 13 | 13 | 0 | 0.00 | - | - |
| RUN DOWN | 48 | 47 | 0 | 0.00 | - | - |
| SCOUT SPOT | 8 | 8 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 6 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 4 | not checked | - | - | - | - |
| SHOOTER COUNTED ONCE | 1 | 1 | 0 | 0.00 | - | - |
| SHOT OR CHARGE | 5 | 5 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 9 | not checked | - | - | - | - |
| SPELL WORTH | 27 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 9 | 8 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 11 | 11 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 8 | 8 | 0 | 0.00 | - | - |
| STANDS STILL | 416 | 416 | 0 | 0.00 | - | - |
| STOPS | 1 | 1 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 114 | not checked | - | - | - | - |
| THE PROMISE ADDS | 2 | 2 | 0 | 0.00 | - | - |
| THE PROMISED MOVE | 6 | not checked | - | - | - | - |
| WAITS AGAIN | 38 | 38 | 0 | 0.00 | - | - |
| WAR ENGINE JOBS | 6 | 6 | 0 | 0.00 | - | - |
| WIDER SPREAD | 47 | 46 | 0 | 0.00 | - | - |

### Off best figure: h5-mine-8766b98-p3

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| HOLDER ASSIGNMENT | rule | 1.31 | - | 18.8 |
| CHARGE NOT DECLARED | rule | 0.31 | 0.77 | 190.2 |
| PATHS CROSS | rule | 0.08 | 0.92 | 32.3 |
| CANNON PLANNED TARGET | rule | 0.54 | 0.08 | 82.2 |
| CHARGE NOW FIRST | rule | 0.23 | 0.23 | 48.1 |
| CHAFF PASSED | rule | 0.15 | 0.08 | 7.1 |
| JOB FIRST | gate | 0.15 | 0.08 | 22.2 |
| PIVOT GUARDS FLANK | rule | 0.08 | 0.15 | 63.0 |
| SUPPORT NARROWED | rule | 0.08 | 0.08 | 9.4 |
| AFTERMATH BAND | gate | 0.08 | - | 1.6 |
| AFTERMATH NEEDS NEXT CHARGE | gate | - | 0.08 | 175.7 |
| BEST PRIZE | rule | - | 0.08 | 31.0 |
| CARRIES OUT COUNTER | rule | - | 0.08 | 90.7 |
| CARRIES OUT SET-UP | rule | - | 0.08 | 14.7 |
| DEPLOY BY FIGURES | rule | - | 0.08 | 4.7 |
| NO REASON | gate | 0.08 | - | 221.4 |
| PURSUES BIG PREY | rule | - | 0.08 | 142.4 |
| REDIRECT WEIGHED | rule | - | 0.08 | 31.0 |
| RULE SWITCHED OFF | gate | - | 0.08 | 0.5 |
| WHO HITS BACK | rule | 0.08 | - | 1.6 |

### Plans: h5-mine-8766b98-p3

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.8 | 48% | 221 | 104 | 47% |
| Mine | join | 0.8 | 100% | 21 | 0 | 0% |
| Mine | move | 27.2 | 95% | 1652 | 0 | 0% |
| Mine | shoot | 13.2 | 60% | 667 | 864 | 129% |
| Mine | support | 0.5 | 83% | 3 | 0 | 0% |
| Opponent | charge | 2.2 | 46% | 516 | 259 | 50% |
| Opponent | move | 28.2 | 93% | 1926 | 0 | 0% |
| Opponent | shoot | 4.3 | 57% | 153 | 190 | 124% |
| Opponent | support | 1.2 | 87% | 1 | 0 | 0% |

### Packages: hunt the guns, h5-mine-8766b98-p3

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 53 |
| Opponent | 0.1 | 1 | 0 | 100% | 100% | 0% | 2.0 | 209 | 125 | 0% | 137 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 78 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 190 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 123 |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 221 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 34 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 410 |
| Vampire Counts | 1.0 | 1 | 0 | 100% | 100% | 0% | 2.0 | 209 | 125 | 0% | 110 |
| Warriors of Chaos | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 71 |
| Wood Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 134 |

### Battle groups: h5-mine-8766b98-p3

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 2.0 | 19% | 60% | 20% | 100% | 25% | 0% | 0% | 75% | 0% |
| Opponent | REDIRECT COUNTER | 4.3 | 16% | 67% | 11% | 100% | 0% | 0% | 12% | 88% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: h5-mine-8766b98-p3

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 9 | 24 (9) | 14 | 10 | 58 | 56% | 2.8 | 30 (4) | 42 (2) | 0 (3) | 26 (8) | 0 (1) |
| Mine | Character | 51 | 16 (51) | 16 | 0 | 21 | 31% | 2.0 | 4 (14) | 22 (28) | 0 (5) | 17 (34) | 8 (13) |
| Mine | Clean-up | 9 | 38 (9) | 3 | 35 | 36 | 56% | 2.8 | 38 (1) | 53 (5) | 0 (3) | 83 (4) | 0 (5) |
| Mine | Fast Hammer | 11 | 39 (11) | 0 | 39 | 43 | 36% | 3.6 | 64 (5) | 12 (3) | 0 (3) | 41 (10) | 0 (1) |
| Mine | Fragile | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | - | - | - | - |
| Mine | Hammer | 26 | 33 (26) | 20 | 13 | 36 | 31% | 2.5 | 10 (9) | 29 (14) | 212 (3) | 49 (18) | 6 (8) |
| Mine | Holder | 15 | 82 (15) | 20 | 62 | 29 | 60% | 3.2 | 77 (3) | 38 (4) | 106 (8) | 92 (13) | 0 (2) |
| Mine | Shooter | 12 | 73 (12) | 18 | 55 | 18 | 8% | 1.7 | 55 (3) | 74 (6) | 105 (3) | 96 (6) | 40 (6) |
| Mine | War machine | 30 | 51 (30) | 51 | 0 | 26 | 0% | 1.3 | 86 (8) | 51 (14) | 17 (8) | 70 (9) | 44 (21) |
| Mine | Wizard | 8 | 20 (8) | 20 | 0 | 0 | 38% | 4.2 | - | 20 (8) | - | 0 (2) | 27 (6) |
| Opponent | Blocker | 1 | 16 (1) | 16 | 0 | 0 | 0% | 4.0 | - | 16 (1) | - | - | 16 (1) |
| Opponent | Chaff | 25 | 101 (25) | 19 | 82 | 34 | 48% | 3.9 | 131 (6) | 117 (10) | 60 (9) | 123 (19) | 18 (6) |
| Opponent | Character | 36 | 41 (36) | 41 | 0 | 20 | 28% | 2.1 | 65 (9) | 34 (21) | 11 (6) | 45 (20) | 36 (16) |
| Opponent | Clean-up | 4 | 100 (4) | 29 | 72 | 18 | 25% | 2.3 | 70 (1) | 114 (2) | 108 (1) | 97 (3) | 108 (1) |
| Opponent | Fast | 1 | 0 (1) | 0 | 0 | 100 | 0% | 3.0 | 0 (1) | - | - | 0 (1) | - |
| Opponent | Fast Hammer | 20 | 61 (20) | 4 | 57 | 22 | 45% | 2.4 | 30 (4) | 68 (11) | 67 (5) | 67 (13) | 46 (7) |
| Opponent | Fragile | 2 | 0 (2) | 0 | 0 | 55 | 50% | 1.0 | - | 0 (1) | - | 0 (1) | - |
| Opponent | Hammer | 16 | 42 (16) | 17 | 25 | 28 | 25% | 2.8 | - | 66 (7) | 16 (9) | 16 (7) | 55 (9) |
| Opponent | Holder | 9 | 70 (9) | 0 | 70 | 22 | 56% | 3.2 | 248 (2) | 64 (5) | 0 (2) | 97 (4) | 57 (5) |
| Opponent | Shooter | 10 | 70 (10) | 0 | 70 | 37 | 10% | 2.6 | 115 (3) | 67 (6) | 0 (1) | 72 (7) | 65 (3) |
| Opponent | War machine | 8 | 61 (8) | 61 | 0 | 0 | 0% | 1.4 | 115 (2) | 9 (5) | 155 (1) | - | 61 (8) |
| Opponent | Wizard | 3 | 16 (3) | 16 | 0 | 0 | 33% | 4.5 | 89 (1) | 0 (1) | 12 (1) | 16 (3) | - |

### Charged fights: h5-mine-8766b98-p3

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 76 | 105 | 1.5 | 1.0 | 70 | 42 | +28 | 3 of 6 | 3 of 6 | - | +28 |
| Mine | Chaos Dwarfs | 4 | 298 | 185 | 2.0 | 1.0 | 93 | 16 | +77 | 4 of 8 | 4 of 8 | - | +77 |
| Mine | Dwarfen Mountain Holds | 3 | 295 | 27 | 1.3 | 1.0 | 20 | 0 | +20 | 0 of 4 | 3 of 4 | - | +20 |
| Mine | Empire of Man | 2 | 240 | 20 | 2.5 | 1.0 | 8 | 0 | +8 | 0 of 5 | 5 of 5 | - | +8 |
| **Mine** | all armies | 13 | 220 | 99 | 1.8 | 1.0 | 56 | 16 | +39 | 7 of 23 | 15 of 23 | - | +39 |
| Opponent | Grand Cathay | 3 | 334 | 197 | 2.3 | 1.0 | 85 | 0 | +85 | 2 of 7 | 7 of 7 | - | +85 |
| Opponent | High Elf Realms | 2 | 0 | 155 | 3.0 | 1.0 | 52 | 50 | +2 | 2 of 6 | 4 of 6 | - | +2 |
| Opponent | Ogre Kingdoms | 1 | 65 | 113 | 2.0 | 2.5 | 56 | 17 | +40 | 2 of 2 | 1 of 2 | +113 | -34 |
| Opponent | Skaven | 1 | 0 | 301 | 1.0 | 1.0 | 301 | 112 | +189 | 1 of 1 | 0 of 1 | - | +189 |
| Opponent | Vampire Counts | 1 | 0 | 1008 | 6.0 | 1.0 | 168 | 0 | +168 | 4 of 6 | 6 of 6 | - | +168 |
| Opponent | Warriors of Chaos | 4 | 0 | 296 | 1.2 | 1.0 | 237 | 0 | +237 | 2 of 5 | 4 of 5 | - | +237 |
| Opponent | Wood Elf Realms | 1 | 0 | 707 | 5.0 | 1.0 | 141 | 22 | +120 | 2 of 5 | 4 of 5 | - | +120 |
| **Opponent** | all armies | 13 | 82 | 324 | 2.5 | 1.1 | 132 | 17 | +114 | 15 of 32 | 26 of 32 | +113 | +115 |

### Effective charges: h5-mine-8766b98-p3

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 6 | 4 (net -26) | 0 | 0 | 1 (net +233) | 0 | 1 (net +41) | 0 | 0% (0 of 6) |
| Mine | Chaos Dwarfs | 8 | 1 (net +0) | 0 | 1 (net +395) | 5 (net +9) | 0 | 1 (net +176) | 0 | 12% (1 of 8) |
| Mine | Dwarfen Mountain Holds | 4 | 0 | 0 | 0 | 1 (net +0) | 0 | 3 (net +27) | 0 | 0% (0 of 4) |
| Mine | Empire of Man | 5 | 1 (net +0) | 0 | 1 (net +0) | 2 (net +20) | 0 | 1 (net +0) | 0 | 20% (1 of 5) |
| Opponent | Grand Cathay | 7 | 1 (net +0) | 0 | 0 | 3 (net +197) | 2 (net +0) | 1 (net +0) | 0 | 0% (0 of 7) |
| Opponent | High Elf Realms | 6 | 0 | 0 | 1 (net +0) | 2 (net +6) | 1 (net +0) | 1 (net +0) | 1 | 20% (1 of 5) |
| Opponent | Ogre Kingdoms | 2 | 0 | 0 | 0 | 0 | 0 | 1 (net +113) | 1 | 0% (0 of 1) |
| Opponent | Skaven | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +189) | 0 | 0% (0 of 1) |
| Opponent | Vampire Counts | 6 | 2 (net +125) | 0 | 0 | 1 (net +380) | 0 | 3 (net +126) | 0 | 0% (0 of 6) |
| Opponent | Warriors of Chaos | 5 | 1 (net +0) | 0 | 1 (net +65) | 1 (net +620) | 0 | 1 (net +310) | 1 | 25% (1 of 4) |
| Opponent | Wood Elf Realms | 5 | 1 (net -109) | 1 (net +427) | 2 (net +48) | 1 (net +185) | 0 | 0 | 0 | 40% (2 of 5) |

### Charged fights, damage counted: h5-mine-8766b98-p3

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 6 | 98 | 364 | -17 | 47 | 69 | -22 | -22.0 |
| Mine | Effective (55-75%) | 2 | 330 | 283 | +198 | 198 | 0 | +198 | +59.8 |
| Mine | 76-89% | 9 | 236 | 179 | +35 | 59 | 16 | +43 | +18.0 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 6 | 123 | 96 | +50 | 57 | 0 | +57 | +46.5 |
| Mine | All fights | 23 | 179 | 214 | +39 | 67 | 24 | +43 | +24.1 |
| Opponent | Long shot (under 50%) | 5 | 92 | 140 | +28 | 82 | 25 | +57 | +62.1 |
| Opponent | 50-54% | 1 | 499 | 239 | +427 | 427 | 0 | +427 | +85.6 |
| Opponent | Effective (55-75%) | 4 | 187 | 92 | +40 | 60 | 10 | +50 | +26.6 |
| Opponent | 76-89% | 8 | 375 | 226 | +224 | 262 | 82 | +180 | +48.0 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 8 | 410 | 248 | +124 | 166 | 62 | +104 | +25.3 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 3 | 400 | 89 | +0 | 54 | 0 | +54 | +13.5 |
| Opponent | No odds | 3 | 322 | 167 | +52 | 63 | 11 | +52 | +16.1 |
| Opponent | All fights | 32 | 317 | 183 | +114 | 152 | 42 | +109 | +34.5 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| h5-mine-8766b98-p3 | move | 91 | 22 (24%) | 20 (22%) | 10 (11%) | 59 (65%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0111, L0128 |
| Charmed Shield | Opponent | L0534, L0726 |
| Elixir of Power | Opponent | L0111, L0211 |
| Fistful of Laurels | Opponent | L0518 |
| Periapt of Soul Exchange | Opponent | L0621 |
| Ring of Doom | Mine | L0211, L0228 |
| Ring of Doom | Opponent | L0111, L0211, L0415 |
| Ring of Jet | Opponent | L0111, L0211, L0710 |
| Standard of the Fell Warrior | Opponent | L0313 |
| Storm Daemon (Renegade 2.0) | Opponent | L0621 |
| Twice-Blessed Armour | Mine | L0710, L0726 |
| Twice-Blessed Armour | Opponent | L0710 |
| Witch Hunter's Ward | Mine | L0710, L0726 |

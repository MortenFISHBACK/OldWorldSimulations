import json,glob,re,collections,sys
stats=collections.Counter()
show=int(sys.argv[1]) if len(sys.argv)>1 else 6
for txt in sorted(glob.glob('*/*/game-*.txt')):
    t=open(txt,errors='ignore').read()
    if 'pecial feature' not in t: continue
    on='Mine' if txt.startswith('mine') else 'Opponent'
    ctrl=None
    for side in ('Mine','Opponent'):
        m=re.search(r'^\s*'+side+r': \d+ VP = (.*)$',t,re.M)
        if m and 'special feature Special Features: controlled' in m.group(1): ctrl=side
    won = ctrl==on
    rows=[json.loads(l) for l in open(txt.replace('.txt','.log.jsonl')) if l.startswith('{')]
    dom=any('QUARTER ODDS' in (r.get('summary') or '') for r in rows)
    stats[('dom' if dom else 'nodom', 'ON' if won else 'OFF' if ctrl else 'nobody')]+=1
    if won: continue
    assigned={}
    for r in rows:
        s=r.get('summary') or ''
        if r.get('side')!=on or (r.get('turn') or 0)<5: continue
        m=re.match(r'HOLDER ASSIGNMENT: The special feature goes to (.*?) \((holds it this turn|walks on to it)',s)
        if m: assigned[r['turn']]=(m.group(1),m.group(2))
    for turn,(unit,how) in assigned.items():
        for r in rows:
            s=r.get('summary') or ''
            if r.get('side')==on and r.get('turn')==turn and r.get('actor')==unit and r.get('type')=='JobRisk':
                sp=re.search(r'SPLIT: (A objectives.*?\| B [^|]*)',s)
                q=re.search(r'quarter (-?[\d.]+)',s)
                stats[('pick has quarter' if q else 'pick no quarter', how)]+=1
                if show>0:
                    show-=1
                    print('\n',txt,'T',turn,unit,how,'|',s[:160],'||',sp.group(1) if sp else '')
            if r.get('side')==on and r.get('turn')==turn and r.get('actor')==unit and r.get('type')=='JobSplit' and s.startswith('JOB SPLIT') and show>=0:
                opts=re.findall(r'\d\. (.*?): worth ([+-][\d.]+).*?\{(.*?)\}',s)
                print('    opts:',[(o[0][:40],o[1],re.findall(r'(QUARTER ODDS [+-][\d.]+|HOLD ODDS [+-][\d.]+|FEATURE[A-Z ]* [+-][\d.]+)',o[2])) for o in opts][:4])
for k,v in sorted(stats.items()): print(k,v)

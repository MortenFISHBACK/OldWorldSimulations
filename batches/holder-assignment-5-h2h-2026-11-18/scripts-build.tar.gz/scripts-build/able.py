import json,glob,re,collections
st=collections.Counter(); ends=collections.Counter()
for txt in sorted(glob.glob('b4/*/*/game-*.txt')):
    t=open(txt,errors='ignore').read()
    if 'The special feature Special Features' not in t: continue
    on='Mine' if txt.split('/')[1].startswith('mine') else 'Opponent'
    off='Opponent' if on=='Mine' else 'Mine'
    vp={}
    for side in ('Mine','Opponent'):
        m=re.search(r'^\s*'+side+r': \d+ VP = (.*)$',t,re.M); vp[side]=m.group(1) if m else ''
    res={}
    for side in (on,off):
        m=re.search(r'The special feature Special Features: ([^;]*)',vp[side]); res[side]=m.group(1) if m else ''
    won='controlled' in res[on]; lost='controlled' in res[off]
    rows=[json.loads(l) for l in open(txt.replace('.txt','.log.jsonl')) if l.startswith('{')]
    turns=collections.defaultdict(lambda: {'table':False,'feat':None})
    for r in rows:
        if r.get('side')!=on: continue
        s=r.get('summary') or ''; tn=r.get('turn') or 0
        if s.startswith('HOLDER ASSIGNMENT:'):
            turns[tn]['table']=True
            m=re.match(r'HOLDER ASSIGNMENT: The special feature (goes to|would go by the figures to|stays empty)',s)
            if m: turns[tn]['feat']=m.group(1)
    st['games']+=1
    out='ON holds' if won else 'OFF holds' if lost else 'nobody'
    st[out]+=1
    played=[tn for tn in turns]
    for tn in (5,6):
        if tn not in turns and not any(r.get('side')==on and (r.get('turn') or 0)==tn for r in rows): st[f'T{tn} not played']+=1; continue
        f=turns[tn]['feat']
        k='no able free unit (no line)' if f is None else 'a unit assigned' if f!='stays empty' else 'able unit, stays empty'
        st[f'T{tn}: {k}']+=1; st[f'T{tn}: {k} / {out}']+=1
    ends[re.sub(r'\(.*','',res[on]).strip()[:60]+' | '+re.sub(r'\(.*','',res[off]).strip()[:60]]+=1
for k,v in sorted(st.items()): print(v,k)
print()
for k,v in ends.most_common(): print(v,k)

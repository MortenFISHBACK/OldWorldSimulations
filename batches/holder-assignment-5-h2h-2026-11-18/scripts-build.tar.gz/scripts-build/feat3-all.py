import json,glob,re,collections,sys
def run(pattern, onof):
    st=collections.Counter()
    for txt in sorted(glob.glob(pattern)):
        t=open(txt,errors='ignore').read()
        if 'pecial feature' not in t: continue
        on=onof(txt)
        ctrl=None
        vp={}
        for side in ('Mine','Opponent'):
            m=re.search(r'^\s*'+side+r': \d+ VP = (.*)$',t,re.M)
            vp[side]=m.group(1) if m else ''
            if 'special feature Special Features: controlled' in vp[side]: ctrl=side
        won=ctrl==on
        st['games']+=1; st['ON ends with it' if won else 'OFF ends with it' if ctrl else 'nobody']+=1
        rows=[json.loads(l) for l in open(txt.replace('.txt','.log.jsonl')) if l.startswith('{')]
        last={}
        for r in rows:
            s=r.get('summary') or ''
            if r.get('side')!=on: continue
            m=re.match(r'HOLDER ASSIGNMENT: The special feature (goes to (.*?) \((holds it this turn|walks on to it)|stays empty)',s)
            if m:
                tn=r.get('turn') or 0
                st[('T%d'%tn if tn<5 else 'T5+', m.group(3) or 'stays empty')]+=1
                last=(tn,m.group(2),m.group(3) or 'stays empty')
        if last:
            st[('last table row', last[2], 'won' if won else 'lost')]+=1
            if not won and last[2]=='holds it this turn':
                other='Opponent' if on=='Mine' else 'Mine'
                gone = last[1] in vp[other]   # enemy scored VP for it (destroyed/fleeing/quarter)
                st[('held in last row and lost: holder in enemy VP list' if gone else 'held in last row and lost: holder intact')]+=1
    for k,v in sorted(st.items(),key=str): print(k,v)
run('*/*/game-*.txt', lambda p:'Mine' if p.split('/')[0].startswith('mine') else 'Opponent')

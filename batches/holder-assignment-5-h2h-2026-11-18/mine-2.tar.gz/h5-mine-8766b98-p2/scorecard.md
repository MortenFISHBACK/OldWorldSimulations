# Doctrine scorecard: h5-mine-8766b98-p2

### Scorecard: h5-mine-8766b98-p2

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0108 | 6 | 1 | Mine | no | 7 | - | 0 | 2 | 0 | 0 | 0 | 55 |
| L0108 | 6 | 1 | Opponent | yes | 0 | 2 | 2 | 1 | 0 | 0 | 0 | 225 |
| L0123 | 3 | 1 | Mine | no | 6 | - | 0 | 1 | 0 | 0 | 0 | 55 |
| L0123 | 3 | 1 | Opponent | no | 0 | 1 | 2 | 2 | 0 | 0 | 0 | 0 |
| L0207 | 3 | 1 | Mine | no | 7 | - | 0 | 6 | 0 | 0 | 0 | 170 |
| L0207 | 3 | 1 | Opponent | no | 0 | 2 | 1 | 0 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 0% | 6.7 | - | 0.0 | 3.0 | 0.0 | 0.0 | 0.0 | 93.3 |
| **Average** | | | Opponent | 33% | 0.0 | 1.7 | 1.7 | 1.0 | 0.0 | 0.0 | 0.0 | 75.0 |

### KPIs: h5-mine-8766b98-p2

Rules off - Opponent only: HOLDER ASSIGNMENT, QUARTER ODDS.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 6) | 65% (11 of 17) | 48% (11 of 23) |
| Winner chose to follow up after the loser gave ground |  | 100% (1 of 1); on the table 100% | 100% (3 of 3); on the table 100% | 100% (4 of 4); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | - | - | - |
| Winner chose to pursue after the loser fled |  | 100% (1 of 1); on the table 100% | 100% (1 of 1); on the table 100% | 100% (2 of 2); on the table 100% |
| Winner chose to follow up or pursue (all three) |  | 100% (2 of 2); on the table 100% | 100% (4 of 4); on the table 100% | 100% (6 of 6); on the table 100% |
| Magic missiles tried each own turn | 50%+ | 50% (45 of 90) | 58% (7 of 12) | 51% (52 of 102) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 52% (45 of 87) | 58% (7 of 12) | 53% (52 of 99) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 50% (3 of 6) | - | 50% (3 of 6) |
| Points that never fought | lower | 80% (4562 of 5699) | 75% (4476 of 5999) | 77% (9038 of 11698) |
|   infantry points that never fought | lower | 72% (1622 of 2239) | 92% (861 of 938) | 78% (2483 of 3177) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 56% (9 of 16) | 56% (14 of 25) | 56% (23 of 41) |
| Bound items with a magic missile used (at least once a game) |  | 100% (4 of 4); 4.7 uses a game | 0.0 uses a game | 100% (4 of 4); 2.3 uses a game |
| Bound items with another spell used |  | 100% (2 of 2); 2.7 uses a game | 0% (0 of 1); 0.0 uses a game | 67% (2 of 3); 1.3 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 75% (3 of 4); 1.0 uses a game | 100% (2 of 2); 0.7 uses a game | 83% (5 of 6); 0.8 uses a game |
|   their share of the points of units over 100 pts | lower | 54% (2128 of 3916) | 50% (2496 of 5035) | 52% (4624 of 8951) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 5.0 (33%) | 0.7 (40%) | 5.7 (34%) |
| MARCHED: its unit marched | 6.0 (40%) | 1.0 (60%) | 7.0 (42%) |
| IN COMBAT: engaged in combat | 0.3 (2%) | 0.0 (0%) | 0.3 (2%) |
| REAR RANK: in a rear rank | 1.7 (11%) | 0.0 (0%) | 1.7 (10%) |
| GONE: slain | 0.7 (4%) | 0.0 (0%) | 0.7 (4%) |
| STUPIDITY: Stupidity | 1.3 (9%) | 0.0 (0%) | 1.3 (8%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 5.3 | 0.0 | 5.7 | 17.3 | 0.3 |
| not cast | 4.7 | 2.0 | 6.3 | 16.7 | 27.7 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (2%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.3 (7%) | 1.3 (67%) | 2.0 (32%) | 5.7 (34%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 7.0 (42%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (2%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 1.7 (36%) | 0.0 (0%) | 0.0 (0%) | 1.7 (10%) | 0.0 (0%) |
| GONE: slain | 0.3 (7%) | 0.0 (0%) | 0.3 (5%) | 0.7 (4%) | 0.0 (0%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.0 (0%) | 0.7 (11%) | 1.3 (8%) | 2.7 (10%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.3 (50%) | 0.7 (33%) | 3.3 (53%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 24.3 (88%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 8.3 a game | 0.0 a game | 4.2 a game |
| stood (cast and not dispelled) | 76% (19 of 25) | - | 76% (19 of 25) |
| the unit moved after it | 68% (13 of 19) | - | 68% (13 of 19) |
| it charged on its next turn | 0% (0 of 19) | - | 0% (0 of 19) |
| the enemy charged it first | 0% (0 of 19) | - | 0% (0 of 19) |
| it fought by the end of its next turn | 0% (0 of 19) | - | 0% (0 of 19) |
| it moved out of a charge the enemy had planned (not charged first) | 11% (2 of 19) | - | 11% (2 of 19) |
| none of these (no charge, no fight, no charge escaped) | 89% (17 of 19) | - | 89% (17 of 19) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 71% (12 of 17) | 57% (62 of 109) | 59% (74 of 126) |
|   cavalry | - | 50% (12 of 24) | 50% (12 of 24) |
|   character | - | 0% (0 of 4) | 0% (0 of 4) |
|   chariot | - | 83% (5 of 6) | 83% (5 of 6) |
|   infantry | 71% (12 of 17) | 58% (19 of 33) | 62% (31 of 50) |
|   war machine | - | 62% (26 of 42) | 62% (26 of 42) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.0 (60%) | 3.0 (19%) | 4.0 (23%) |
| CHARGED: it charged | 0.0 (0%) | 1.0 (6%) | 1.0 (6%) |
| FLEEING: it fled or was fleeing | 0.0 (0%) | 0.3 (2%) | 0.3 (2%) |
| IN COMBAT: it fought this turn or the last | 0.3 (20%) | 0.0 (0%) | 0.3 (2%) |
| MOVED: a war machine that moved | 0.0 (0%) | 3.7 (23%) | 3.7 (21%) |
| NO TARGET IN RANGE | 0.3 (20%) | 3.7 (23%) | 4.0 (23%) |
| ONLY IN COMBAT: the only targets were in combat | 0.0 (0%) | 0.3 (2%) | 0.3 (2%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.0 (0%) | 2.0 (13%) | 2.0 (12%) |
| SHELTERED: the target was sheltered | 0.0 (0%) | 0.3 (2%) | 0.3 (2%) |
| OTHER BAR | 0.0 (0%) | 1.3 (9%) | 1.3 (8%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 6.0 | 6.7 | 28% | 8.1 pts | 49 pts |
| chariot | 1.7 | 2.0 | 40% | 9.5 pts | 16 pts |
| infantry | 12.0 | 10.3 | 61% | 7.8 pts | 94 pts |
| war machine | 8.7 | 11.0 | 46% | 14.2 pts | 123 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 0.0 | 3.7 | 1.8 |
| Charges that made contact a game | 0.0 | 2.0 | 1.0 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | - | 0.00 declared, 0.00 contact (1 units) | 0.00 declared, 0.00 contact (1 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | - | - |
|   per unit a game, the other units (no war machines, no joined characters) | 0.00 declared, 0.00 contact (20 units) | 0.42 declared, 0.23 contact (26 units) | 0.24 declared, 0.13 contact (46 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 25% (1 of 4) | 0% (0 of 2) | - | 17% (1 of 6) |
| Character in a unit | 80% (4 of 5) | 80% (4 of 5) | - | 80% (8 of 10) |
| Character on its own | 100% (3 of 3) | 100% (1 of 1) | 33% (1 of 3) | 71% (5 of 7) |
| Chariot | - | 100% (1 of 1) | - | 100% (1 of 1) |
| Infantry | 0% (0 of 1) | 20% (1 of 5) | 0% (0 of 1) | 14% (1 of 7) |
| Monster | 67% (2 of 3) | - | - | 67% (2 of 3) |
| War Machines | 71% (5 of 7) | - | - | 71% (5 of 7) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 3 | 100% (2 of 2); on the table 100% | 50% (45 of 90) | 80% | 56% (9 of 16) | 100% (4 of 4); 4.7 uses a game | 100% (2 of 2); 2.7 uses a game | 75% (3 of 4); 1.0 uses a game |
| Empire of Man | 2 | 100% (1 of 1); on the table 100% | 58% (7 of 12) | 80% | 55% (11 of 20) | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game | 100% (2 of 2); 1.0 uses a game |
| Tomb Kings of Khemri | 1 | 100% (3 of 3); on the table 100% | - | 65% | 60% (3 of 5) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (h5-mine-8766b98-p2, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 67% (2) | - | 67% (2) |
| ...free all their last turn and able to turn (per game) | 0.67 | 0.00 | 0.67 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.67 | 0.00 | 0.67 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: h5-mine-8766b98-p2

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 0.7 | 1.7 |
| Strategy | Charge objectives carried out (made contact) | - | 27% (3 of 11) |
| Strategy | Shoot objectives carried out (shot that target) | 10% (1 of 10) | 45% (17 of 38) |
| Strategy | Joined characters whose unit fought | 0% (0 of 15) | 0% (0 of 3) |
| Strategy | Lone characters that fought | 67% (2 of 3) | 33% (3 of 9) |
| Movement | Charges halted short of contact | 0.0 | 0.3 |
| Movement | Idle units | 3.0 | 1.0 |
| Movement | Points that never moved of their own | 93.3 | 75.0 |
| Movement | Fights charged into per game | 0.0 | 1.7 |
| Movement | Charges with odds: long shots (under 50%) | - | 0 of 5 |
| Movement | Charges with odds: sweet spot (55-75%) | - | 0 of 5 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | - | 1 of 5, net +65 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | - | 3 of 5, net +27 |
| Shooting | Shots by shooting units (incl. breath weapons) | 4.0 | 14.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 50% (6 of 12) | 50% (22 of 44) |
| Shooting | Points destroyed by shooting units | 0.0 | 80.0 |
| Shooting | War machine shots | - | 8.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | - | 42% (11 of 26) |
| Shooting | Points destroyed by war machines | 0.0 | 56.7 |
| Magic | Magic missiles cast | 9.3 | 1.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 57% (16 of 28) | 0% (0 of 4) |
| Magic | Wounds caused by magic missiles | 25.0 | 2.3 |
| Magic | Points destroyed by magic (all spells) | 137.7 | 34.7 |
| Magic | Augments / hexes / assailments / vortexes cast | 2.0 / 0.0 / 0.0 / 0.0 | 2.0 / 0.0 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 105.0 | 118.3 |
| Combat | Points run down | 0.0 | 27.0 |
| Combat | Net points per charged fight, damage counted | - | +96 |
| Combat | Net per 100 charger points, damage counted | - | +39.6 |
| Combat | First round won (charged fights) | - | 80% |
| Combat | Net points per charged fight | - | +100 |
| Combat | Net points per supported fight / lone fight | - / - | +0 / +125 |
| Combat | Charged fights on a top-3 enemy unit | - | 1 of 5 |
| Game | Points lost | 379.7 | 296.0 |
| Game | VP from objectives | 610.0 | 623.3 |
| Game | Lone holders (player turns) | 6.7 | 0.0 |

- Mine won / drew / lost: 1 / 1 / 1 of 3 ended games (of 3); mean margin (Mine - Opponent) +11 VP
- The side that went first won 0 of 2 games with a winner
- Points traded per game (both sides' losses): 676
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: h5-mine-8766b98-p2

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | - | - | - | - | 2.0 | +0.0 | 0.0 | 0.0 |
| BEST PRIZE | - | - | - | - | 0.3 | -1.9 | 28.3 | 0.0 |
| BLOWS WHERE AIMED | - | - | - | - | 0.7 | -76.9 | 21.7 | 0.0 |
| CANNON PLAN MISSED | - | - | - | - | 2.3 | +0.0 | 91.3 | 43.3 |
| CANNON PLANNED TARGET | - | - | - | - | 5.7 | +102.6 | 144.0 | 131.7 |
| CANNON SIGHT KEPT | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| CASTER AWAY FROM SCREEN | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CASTING BLOCK | 2.0 | +205.0 | 67.3 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | 6.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | 0.7 | +24.7 | 0.0 | 27.0 | - | - | - | - |
| CHAFF PASSED | 0.3 | -3.1 | 0.0 | 0.0 | - | - | - | - |
| CHARGE LOSSES | 8.7 | -796.8 | 0.0 | 82.3 | 7.7 | -289.8 | 0.0 | 93.0 |
| CHARGE NOT DECLARED | - | - | - | - | 1.0 | +0.0 | 55.3 | 0.0 |
| CHARGE NOW FIRST | - | - | - | - | 0.7 | +0.0 | 55.3 | 0.0 |
| CHARGER SLAIN LOST | - | - | - | - | 0.3 | -1.7 | 0.0 | 0.0 |
| CHEAPEST HOLDER | - | - | - | - | 0.3 | -15.4 | 21.7 | 0.0 |
| CONVEYANCE SEARCH | 6.7 | +624.3 | 0.0 | 118.3 | - | - | - | - |
| COVER ONCE | 3.7 | -192.2 | 0.0 | 43.3 | 12.3 | -475.7 | 0.0 | 0.0 |
| DEPLOY BY FIGURES | 6.7 | +76.2 | 0.0 | 18.3 | 8.0 | -108.2 | 0.0 | 0.0 |
| FALL BACK GOOD ORDER | - | - | - | - | 2.7 | +0.0 | 98.7 | 0.0 |
| FALLBACK BY WORTH | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| FALLS SHORT | 12.3 | +371.3 | 0.0 | 312.0 | 13.3 | +135.5 | 0.0 | 0.0 |
| FEATURE BUFFS | 3.0 | +100.2 | 0.0 | 21.7 | 1.0 | +41.0 | 0.0 | 0.0 |
| FIGHT TO THE END | - | - | - | - | 0.3 | +17.8 | 0.0 | 0.0 |
| FIRE IN ORDER | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| FIVE ACTION | 27.7 | +2450.9 | 110.7 | 416.3 | 60.7 | +5198.3 | 475.7 | 432.3 |
| FLANK NOT WEIGHED | 5.3 | +0.0 | 0.0 | 118.3 | 4.7 | +0.0 | 0.0 | 0.0 |
| FOLLOW UP WEIGHED | - | - | - | - | 0.7 | +76.1 | 0.0 | 0.0 |
| FOUR ROUNDS | - | - | - | - | 3.7 | +109.4 | 120.3 | 0.0 |
| FRIEND CHARGES FIRST | - | - | - | - | 0.7 | -112.1 | 0.0 | 0.0 |
| GIVES UP | - | - | - | - | 0.3 | -0.4 | 0.0 | 0.0 |
| GROUND FLIERS | - | - | - | - | 0.7 | +9.2 | 0.0 | 0.0 |
| GUN FIGURES | - | - | - | - | 1.7 | +20.4 | 21.7 | 0.0 |
| GUN MASK | - | - | - | - | 3.7 | +60.6 | 0.0 | 0.0 |
| HARD STAY DROPPED | 1.0 | +0.0 | 0.0 | 17.3 | - | - | - | - |
| HE SHOOTS OR CHARGES | 2.7 | +0.0 | 0.0 | 92.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| HELPER UNSEEN | - | - | - | - | 0.3 | +0.0 | 21.7 | 0.0 |
| HIS CHARGE DENIED | - | - | - | - | 0.3 | +1.1 | 0.0 | 0.0 |
| HIS CHARGE LIST | 2.3 | +0.0 | 0.0 | 96.3 | 5.0 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 2.0 | +0.0 | 0.0 | 0.0 | 8.3 | +0.0 | 0.0 | 67.3 |
| HIS MOVE AND SHOT | 2.0 | -26.0 | 0.0 | 0.0 | 1.7 | -74.8 | 0.0 | 25.7 |
| HIS RANDOM MOVE | - | - | - | - | 9.7 | +0.0 | 0.0 | 25.7 |
| HIS SHOT LIST | 20.7 | +681.2 | 0.0 | 329.7 | 17.0 | +640.7 | 0.0 | 0.0 |
| HIS TURN DENIED | - | - | - | - | 1.7 | +36.0 | 92.0 | 0.0 |
| HOLD ODDS | 11.3 | +0.0 | 0.0 | 21.7 | - | - | - | - |
| HOLDER ASSIGNMENT | 15.0 | +1541.3 | 0.0 | 21.7 | - | - | - | - |
| HOLDER AT DEPLOYMENT | - | - | - | - | 1.3 | +273.0 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | - | - | - | - | 3.3 | -89.9 | 98.7 | 0.0 |
| HUNT IN PAIRS | - | - | - | - | 3.3 | +201.9 | 0.0 | 0.0 |
| IDLE COST | 5.3 | -39.5 | 0.0 | 129.0 | 4.0 | -77.1 | 0.0 | 0.0 |
| KEEP FALLS | 0.3 | +1.5 | 0.0 | 0.0 | - | - | - | - |
| LANE BY FIGURES | - | - | - | - | 1.0 | +59.5 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 11.0 | +0.0 | 25.7 | 376.7 | 4.3 | +0.0 | 120.0 | 0.0 |
| LONE WIZARD KEPT IN | 2.0 | +228.8 | 0.0 | 0.0 | 0.7 | +72.9 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | - | - | - | - | 1.0 | +18.5 | 0.0 | 0.0 |
| MANOEUVRE | 0.7 | +7.1 | 0.0 | 0.0 | 0.7 | +0.7 | 0.0 | 0.0 |
| MARCH BY THE SUM | 0.3 | +1.8 | 0.0 | 0.0 | 0.3 | +9.4 | 0.0 | 0.0 |
| MARCH CHECK | 3.3 | +346.4 | 0.0 | 27.0 | 2.0 | +196.6 | 0.0 | 0.0 |
| MARCH OVER CASTS | 0.7 | +15.8 | 0.0 | 27.0 | 1.0 | +47.4 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 4.7 | +183.8 | 0.0 | 157.3 | 6.0 | +209.7 | 0.0 | 12.0 |
| MISSILES IN THE MOVE | 8.3 | +625.4 | 0.0 | 48.7 | 2.7 | +42.0 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 9.0 | +389.6 | 0.0 | 75.7 | 3.3 | +29.0 | 0.0 | 0.0 |
| MOVE SPELL OUT OF RANGE | 3.0 | -35.9 | 0.0 | 236.7 | - | - | - | - |
| MOVE SPELL SPOT | 3.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 0.7 | +174.7 | 0.0 | 0.0 | 4.7 | +1572.7 | 0.0 | 0.0 |
| MOVES UNITS SPELL | 0.3 | +18.4 | 0.0 | 0.0 | - | - | - | - |
| NEARER NOT NEEDED | 5.7 | +237.5 | 0.0 | 25.7 | 8.7 | +627.9 | 0.0 | 67.3 |
| NEXT CHARGE BY LIST | 2.0 | +141.9 | 0.0 | 36.7 | 5.7 | -0.9 | 18.3 | 0.0 |
| NEXT OBJECTIVE NEARER | - | - | - | - | 19.0 | -1526.5 | 76.7 | 79.3 |
| NO DOUBLE ROUNDS | - | - | - | - | 3.0 | -86.1 | 98.7 | 0.0 |
| NOT WORTH A CAST | 1.0 | -1.4 | 0.0 | 0.0 | 2.0 | -0.8 | 0.0 | 0.0 |
| ONE CHARGE A CHARGER | 1.7 | +0.0 | 0.0 | 34.7 | 1.7 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 3.3 | -114.0 | 0.0 | 46.7 | 4.3 | -134.1 | 0.0 | 0.0 |
| ONE OBJECTIVE FORMULA | 6.7 | +41.0 | 0.0 | 21.7 | 5.0 | +99.6 | 0.0 | 67.3 |
| ONE TARGET A SHOOTER | 15.7 | +505.9 | 0.0 | 207.0 | 23.0 | +791.2 | 0.0 | 93.0 |
| OPENS A LANE | 1.0 | +0.7 | 0.0 | 0.0 | 0.7 | +4.0 | 45.7 | 0.0 |
| OVERRUNS AWAY | - | - | - | - | 0.3 | +66.2 | 21.7 | 0.0 |
| PATHS CROSS | 2.7 | +87.3 | 0.0 | 67.3 | 7.7 | +336.0 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.3 | -0.5 | 0.0 | 0.0 | - | - | - | - |
| PLAN RESULT | 25.3 | +26.9 | 45.0 | 414.0 | 51.3 | +405.7 | 157.3 | 446.0 |
| QUARTER ODDS | 3.0 | +600.9 | 0.0 | 0.0 | - | - | - | - |
| RANDOM MOVE BY FIGURES | 2.0 | +23.6 | 0.0 | 0.0 | - | - | - | - |
| REDIRECT COUNTER | 2.3 | +200.2 | 0.0 | 110.7 | 2.3 | +43.8 | 0.0 | 12.0 |
| REDIRECT WEIGHED | - | - | - | - | 0.7 | +0.7 | 55.3 | 0.0 |
| REFORMS TO MEET IT | - | - | - | - | 1.0 | -146.1 | 0.0 | 0.0 |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | 1.7 | +95.4 | 0.0 | 0.0 | 1.0 | +12.7 | 0.0 | 0.0 |
| RESTRAINS TO SHOOT | - | - | - | - | 0.3 | +11.8 | 0.0 | 0.0 |
| RISK BY ARC | - | - | - | - | 2.3 | +55.3 | 98.7 | 0.0 |
| RISK BY HIS FIGURE | 12.7 | -740.9 | 0.0 | 297.0 | 11.7 | -123.6 | 0.0 | 0.0 |
| RUN DOWN | - | - | - | - | 3.7 | -25.7 | 120.3 | 0.0 |
| SCOUT SPOT | 0.7 | +1.8 | 0.0 | 18.3 | 1.3 | +0.3 | 0.0 | 0.0 |
| SCOUT WAITS | 0.7 | +0.0 | 0.0 | 18.3 | 1.3 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.3 | -5.7 | 0.0 | 0.0 | - | - | - | - |
| SEARCH SPOT | 4.7 | +128.0 | 0.0 | 75.7 | 7.0 | +156.1 | 0.0 | 93.0 |
| SET UP TOGETHER | - | - | - | - | 1.0 | +18.5 | 0.0 | 0.0 |
| SET-UP ANY TARGET | 1.0 | +124.4 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | - | - | - | - | 0.3 | +1.7 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.3 | +111.0 | 43.3 | 21.7 | 0.3 | +1.4 | 0.0 | 0.0 |
| SHORT GUN FORWARD | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| SHOT OR CHARGE | - | - | - | - | 1.0 | -60.8 | 71.7 | 86.7 |
| SHOT RISK POINTS | 14.7 | +36.4 | 0.0 | 246.0 | 16.7 | -77.9 | 0.0 | 93.0 |
| SHOTS IN THE MOVE | 3.7 | +64.4 | 0.0 | 86.7 | 28.3 | +519.0 | 0.0 | 260.0 |
| SPELL SETS UP CHARGE | 1.7 | +577.0 | 0.0 | 0.0 | - | - | - | - |
| SPELL WORTH | 1.3 | +11.6 | 21.7 | 236.7 | - | - | - | - |
| STAND AND SHOOT | - | - | - | - | 1.0 | -9.5 | 43.3 | 0.0 |
| STANDS FOR A REASON | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 6.3 | +0.0 | 110.7 | 86.7 | 21.0 | +0.0 | 355.3 | 339.3 |
| STAY WORTH | 1.7 | +108.5 | 0.0 | 0.0 | 28.7 | +130.6 | 271.3 | 353.0 |
| SUPPORT NARROWED | - | - | - | - | 0.3 | +0.0 | 28.3 | 0.0 |
| SURE REACH TOGETHER | - | - | - | - | 1.3 | +15.8 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 2.3 | +0.0 | 0.0 | 39.0 | 9.3 | +0.0 | 0.0 | 67.3 |
| THE PROMISE ADDS | - | - | - | - | 0.3 | -125.5 | 0.0 | 0.0 |
| THE PROMISED MOVE | 1.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| TIED UP BY THE SUM | - | - | - | - | 1.7 | +92.5 | 77.0 | 0.0 |
| TIME ON OUR SIDE | 8.0 | +205.3 | 0.0 | 116.7 | 23.3 | +383.5 | 0.0 | 188.7 |
| TWO OR MORE ARRIVE | - | - | - | - | 0.3 | +1.0 | 0.0 | 0.0 |
| WAITS AGAIN | 1.3 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| WHOLE FIGHT | - | - | - | - | 1.0 | +34.5 | 0.0 | 0.0 |
| WIDER SPREAD | - | - | - | - | 1.7 | -0.9 | 43.3 | 0.0 |
| WOUNDS ON THE RANKS | 3.7 | +378.1 | 0.0 | 0.0 | 3.3 | +126.7 | 0.0 | 67.3 |

### Rule changes: h5-mine-8766b98-p2

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| LEGAL CHARGES ONLY | 46 | 46 | 46 | 15.33 | +0 | +0.0 |
| FIVE ACTION | 265 | 265 | 45 | 15.00 | +1580 | +35.1 |
| HOLDER ASSIGNMENT | 45 | 45 | 41 | 13.67 | +2758 | +67.3 |
| SEARCH SPOT | 35 | 35 | 34 | 11.33 | +852 | +25.0 |
| PATHS CROSS | 31 | 31 | 31 | 10.33 | +1270 | +41.0 |
| ONE TARGET A SHOOTER | 116 | 116 | 30 | 10.00 | +272 | +9.1 |
| HIS SHOT LIST | 113 | 113 | 28 | 9.33 | +282 | +10.1 |
| DEPLOY BY FIGURES | 44 | 44 | 25 | 8.33 | +290 | +11.6 |
| TIME ON OUR SIDE | 94 | 89 | 19 | 6.33 | +56 | +3.0 |
| SHOT RISK POINTS | 94 | 94 | 17 | 5.67 | +215 | +12.6 |
| MOVE TO CHARGE COMPUTED | 16 | 16 | 13 | 4.33 | +3564 | +274.1 |
| COVER ONCE | 48 | 38 | 10 | 3.33 | +196 | +19.6 |
| MARCH CHECK | 16 | 16 | 10 | 3.33 | +287 | +28.7 |
| NEXT OBJECTIVE NEARER | 57 | 57 | 10 | 3.33 | +146 | +14.6 |
| MAX FOR POSITIONING | 32 | 32 | 9 | 3.00 | +32 | +3.5 |
| LONE WIZARD KEPT IN | 8 | 8 | 8 | 2.67 | +905 | +113.2 |
| RESERVE FALL BACK | 8 | 8 | 8 | 2.67 | +325 | +40.6 |
| FALLS SHORT | 77 | 67 | 7 | 2.33 | +131 | +18.8 |
| WOUNDS ON THE RANKS | 21 | 21 | 7 | 2.33 | +493 | +70.5 |
| ADVANCE LANE KEPT | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| ARTILLERY RE-ROLL WEIGHED | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| SCOUT WAITS | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| CASTER AWAY FROM SCREEN | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| RISK BY HIS FIGURE | 73 | 73 | 5 | 1.67 | +622 | +124.4 |
| CASTING BLOCK | 6 | 6 | 4 | 1.33 | +209 | +52.3 |
| FOUR ROUNDS | 11 | 11 | 4 | 1.33 | +23 | +5.7 |
| GUN MASK | 11 | 11 | 4 | 1.33 | +39 | +9.8 |
| HOLDS AMBUSHERS | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| MISSILES IN THE MOVE | 33 | 28 | 4 | 1.33 | +340 | +85.1 |
| NEXT CHARGE BY LIST | 23 | 23 | 4 | 1.33 | +410 | +102.6 |
| TIED UP BY THE SUM | 5 | 5 | 4 | 1.33 | +73 | +18.2 |
| CANNON SIGHT KEPT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| CHARGE LOSSES | 49 | 49 | 3 | 1.00 | +12 | +3.9 |
| CHARGE NOT DECLARED | 3 | 3 | 3 | 1.00 | -226 | -75.3 |
| HARD STAY DROPPED | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| LANE BY FIGURES | 3 | 3 | 3 | 1.00 | +178 | +59.5 |
| NEARER NOT NEEDED | 43 | 42 | 3 | 1.00 | +92 | +30.6 |
| RANDOM MOVE BY FIGURES | 6 | 6 | 3 | 1.00 | +71 | +23.5 |
| REDIRECT COUNTER | 14 | 14 | 3 | 1.00 | +168 | +56.0 |
| RISK BY ARC | 7 | 7 | 3 | 1.00 | +65 | +21.6 |
| SHOOTS FROM THE BEST SPOT | 5 | 5 | 3 | 1.00 | +2 | +0.8 |
| STAY WORTH | 91 | 90 | 3 | 1.00 | +212 | +70.7 |
| CANNON PLANNED TARGET | 17 | 17 | 2 | 0.67 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 2 | 2 | 2 | 0.67 | +228 | +114.1 |
| MANOEUVRE | 4 | 4 | 2 | 0.67 | +23 | +11.7 |
| MARCH BY THE SUM | 2 | 2 | 2 | 0.67 | +33 | +16.7 |
| QUARTER ODDS | 9 | 9 | 2 | 0.67 | +507 | +253.4 |
| REDIRECT WEIGHED | 2 | 2 | 2 | 0.67 | +154 | +77.2 |
| SHOTS IN THE MOVE | 96 | 93 | 2 | 0.67 | +6 | +3.2 |
| WHOLE FIGHT | 3 | 3 | 2 | 0.67 | +8 | +3.8 |
| BEST PRIZE | 1 | 1 | 1 | 0.33 | -6 | -5.6 |
| CHAFF PASSED | 1 | 1 | 1 | 0.33 | -9 | -9.4 |
| FEATURE BUFFS | 12 | 12 | 1 | 0.33 | +23 | +23.2 |
| FIRE IN ORDER | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| HIS TURN DENIED | 5 | 5 | 1 | 0.33 | +7 | +7.0 |
| HOLDER AT DEPLOYMENT | 4 | 4 | 1 | 0.33 | +39 | +39.0 |
| HUNT IN PAIRS | 10 | 4 | 1 | 0.33 | +49 | +49.0 |
| IDLE COST | 28 | 20 | 1 | 0.33 | +4 | +3.8 |
| KEEP FALLS | 1 | 1 | 1 | 0.33 | +24 | +24.0 |
| MISSILES NEXT TURN | 37 | 32 | 1 | 0.33 | +5 | +5.3 |
| MOVES UNITS SPELL | 1 | 1 | 1 | 0.33 | +55 | +55.1 |
| ONE FIGHT FORMULA | 23 | 14 | 1 | 0.33 | +0 | +0.4 |
| OPENS A LANE | 5 | 1 | 1 | 0.33 | +3 | +3.0 |
| OVERRUNS AWAY | 1 | 1 | 1 | 0.33 | +7 | +7.0 |
| PIVOT GUARDS FLANK | 1 | 1 | 1 | 0.33 | -2 | -1.6 |
| REFUSING RETIRES | 2 | 2 | 1 | 0.33 | -0 | -0.3 |
| RESTRAINS TO SHOOT | 1 | 1 | 1 | 0.33 | +35 | +35.5 |
| SHOOTERS IN TWO RANKS | 1 | 1 | 1 | 0.33 | +5 | +5.0 |
| SHORT GUN FORWARD | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| SURE REACH TOGETHER | 4 | 4 | 1 | 0.33 | +0 | +0.0 |
| WIDER SPREAD | 5 | 5 | 1 | 0.33 | +2 | +2.3 |
| BLOWS WHERE AIMED | 2 | 2 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 7 | 7 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 19 | trace | - | - | - | - |
| CHAFF IN THE MOVE | 2 | 2 | 0 | 0.00 | - | - |
| CHARGE NOW FIRST | 2 | 2 | 0 | 0.00 | - | - |
| CHARGER SLAIN LOST | 1 | 1 | 0 | 0.00 | - | - |
| CHEAPEST HOLDER | 1 | 1 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 20 | not checked | - | - | - | - |
| FALL BACK GOOD ORDER | 8 | 8 | 0 | 0.00 | - | - |
| FALLBACK BY WORTH | 1 | 1 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 1 | 1 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 30 | not checked | - | - | - | - |
| FRIEND CHARGES FIRST | 2 | 2 | 0 | 0.00 | - | - |
| GIVES UP | 1 | 1 | 0 | 0.00 | - | - |
| GROUND FLIERS | 2 | not checked | - | - | - | - |
| GUN FIGURES | 5 | not checked | - | - | - | - |
| HE SHOOTS OR CHARGES | 13 | 13 | 0 | 0.00 | - | - |
| HELPER UNSEEN | 1 | 1 | 0 | 0.00 | - | - |
| HIS CHARGE DENIED | 1 | 1 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 22 | 22 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 31 | 31 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 11 | 11 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 29 | 29 | 0 | 0.00 | - | - |
| HOLD ODDS | 34 | 34 | 0 | 0.00 | - | - |
| HONEST WORTH | 10 | 10 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 3 | not checked | - | - | - | - |
| MARCH OVER CASTS | 5 | 5 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 9 | trace | - | - | - | - |
| MOVE SPELL SPOT | 9 | not checked | - | - | - | - |
| NO DOUBLE ROUNDS | 9 | 9 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 9 | not checked | - | - | - | - |
| ONE CHARGE A CHARGER | 10 | 10 | 0 | 0.00 | - | - |
| ONE OBJECTIVE FORMULA | 35 | 24 | 0 | 0.00 | - | - |
| PLAN RESULT | 230 | trace | - | - | - | - |
| REFORMS TO MEET IT | 3 | 3 | 0 | 0.00 | - | - |
| RUN DOWN | 11 | 11 | 0 | 0.00 | - | - |
| SCOUT SPOT | 6 | 6 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 1 | 1 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 3 | 3 | 0 | 0.00 | - | - |
| SET-UP ANY TARGET | 3 | not checked | - | - | - | - |
| SHOT OR CHARGE | 3 | 3 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 5 | not checked | - | - | - | - |
| SPELL WORTH | 4 | not checked | - | - | - | - |
| STAND AND SHOOT | 3 | 3 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 3 | 3 | 0 | 0.00 | - | - |
| STANDS STILL | 82 | 82 | 0 | 0.00 | - | - |
| SUPPORT NARROWED | 1 | 1 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 35 | not checked | - | - | - | - |
| THE PROMISE ADDS | 1 | 1 | 0 | 0.00 | - | - |
| THE PROMISED MOVE | 5 | not checked | - | - | - | - |
| TWO OR MORE ARRIVE | 1 | not checked | - | - | - | - |
| WAITS AGAIN | 12 | 12 | 0 | 0.00 | - | - |

### Off best figure: h5-mine-8766b98-p2

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| HOLDER ASSIGNMENT | rule | 1.67 | - | 6.4 |
| PATHS CROSS | rule | - | 1.33 | 31.1 |
| CHARGE NOT DECLARED | rule | - | 1.00 | 75.3 |
| BEST PRIZE | rule | - | 0.33 | 5.6 |
| CHAFF PASSED | rule | 0.33 | - | 9.4 |
| PIVOT GUARDS FLANK | rule | 0.33 | - | 1.6 |

### Plans: h5-mine-8766b98-p2

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | move | 22.3 | 84% | 1650 | 0 | 0% |
| Mine | shoot | 2.7 | 12% | 583 | 27 | 5% |
| Mine | support | 0.3 | 100% | 0 | 0 | - |
| Opponent | charge | 2.7 | 75% | 305 | 114 | 38% |
| Opponent | join | 0.3 | 100% | 4 | 0 | 0% |
| Opponent | move | 38.7 | 97% | 3010 | 0 | 0% |
| Opponent | shoot | 9.7 | 62% | 286 | 291 | 102% |

### Battle groups: h5-mine-8766b98-p2

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 2.3 | 100% | 71% | 0% | - | 0% | 14% | 0% | 86% | 0% |
| Opponent | REDIRECT COUNTER | 2.3 | 0% | - | - | - | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: h5-mine-8766b98-p2

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 3 | 0 (3) | 0 | 0 | 100 | 100% | - | 0 (1) | 0 (1) | 0 (1) | 0 (2) | 0 (1) |
| Mine | Character | 18 | 14 (18) | 14 | 0 | 12 | 33% | 1.7 | 10 (13) | - | 39 (3) | 15 (9) | 17 (7) |
| Mine | Clean-up | 3 | 0 (3) | 0 | 0 | 100 | 100% | - | - | 0 (2) | 0 (1) | - | 0 (3) |
| Mine | Fast Hammer | 2 | 0 (2) | 0 | 0 | 100 | 100% | - | - | 0 (2) | - | - | 0 (2) |
| Mine | Hammer | 8 | 62 (8) | 17 | 45 | 8 | 50% | 3.2 | 76 (3) | 73 (4) | 0 (1) | 62 (3) | 62 (5) |
| Mine | Holder | 3 | 63 (3) | 0 | 63 | 32 | 67% | 5.0 | 93 (2) | - | - | - | 93 (2) |
| Mine | Shooter | 3 | 46 (3) | 0 | 46 | 100 | 0% | 1.3 | - | 69 (2) | 0 (1) | 69 (2) | 0 (1) |
| Opponent | Chaff | 3 | 54 (3) | 0 | 54 | 21 | 33% | 2.0 | 68 (2) | - | 0 (1) | 68 (2) | 0 (1) |
| Opponent | Character | 10 | 23 (10) | 23 | 0 | 14 | 50% | 2.0 | 44 (4) | 0 (3) | 0 (1) | 16 (4) | 33 (4) |
| Opponent | Clean-up | 1 | 88 (1) | 0 | 88 | 0 | 100% | - | 88 (1) | - | - | 88 (1) | - |
| Opponent | Fast Hammer | 8 | 24 (8) | 7 | 17 | 17 | 38% | 4.4 | 45 (5) | 0 (3) | - | 38 (5) | 0 (3) |
| Opponent | Hammer | 2 | 14 (2) | 0 | 14 | 0 | 50% | 2.0 | - | 0 (1) | 24 (1) | 0 (1) | 24 (1) |
| Opponent | Holder | 3 | 0 (3) | 0 | 0 | 34 | 0% | 5.3 | 0 (1) | 0 (2) | - | - | 0 (3) |
| Opponent | Shooter | 4 | 147 (4) | 26 | 122 | 0 | 0% | 2.2 | 346 (2) | 79 (2) | - | 220 (3) | 35 (1) |
| Opponent | War machine | 7 | 33 (7) | 33 | 0 | 44 | 0% | 2.1 | 68 (2) | 19 (5) | - | 89 (1) | 23 (6) |
| Opponent | Wizard | 2 | 0 (2) | 0 | 0 | 0 | 50% | 1.0 | - | 0 (1) | 0 (1) | - | 0 (2) |

### Charged fights: h5-mine-8766b98-p2

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 3 | 138 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Empire of Man | 2 | 197 | 73 | 1.5 | 1.0 | 49 | 0 | +49 | 0 of 3 | 2 of 3 | - | +49 |
| Opponent | Tomb Kings of Khemri | 1 | 120 | 355 | 2.0 | 1.5 | 178 | 0 | +178 | 1 of 2 | 2 of 2 | +0 | +355 |
| **Opponent** | all armies | 3 | 171 | 167 | 1.7 | 1.2 | 100 | 0 | +100 | 1 of 5 | 4 of 5 | +0 | +125 |

### Effective charges: h5-mine-8766b98-p2

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | Empire of Man | 3 | 0 | 0 | 0 | 0 | 1 (net +65) | 2 (net +40) | 0 | 0% (0 of 3) |
| Opponent | Tomb Kings of Khemri | 2 | 0 | 0 | 0 | 1 (net +355) | 0 | 1 (net +0) | 0 | 0% (0 of 2) |

### Charged fights, damage counted: h5-mine-8766b98-p2

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | 76-89% | 1 | 440 | 65 | +355 | 440 | 0 | +440 | +100.1 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 | 188 | 162 | +27 | 40 | 22 | +18 | +9.4 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 202 | 65 | +65 | 65 | 81 | -16 | -7.8 |
| Opponent | All fights | 5 | 241 | 123 | +100 | 125 | 29 | +96 | +39.6 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| h5-mine-8766b98-p2 | move | 10 | 1 (10%) | 1 (10%) | 0 (0%) | 9 (90%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0108, L0123 |
| Ring of Doom | Mine | L0207 |
| Twice-Blessed Armour | Opponent | L0207 |
| Witch Hunter's Ward | Opponent | L0108, L0207 |

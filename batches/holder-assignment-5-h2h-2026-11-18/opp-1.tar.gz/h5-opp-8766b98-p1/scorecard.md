# Doctrine scorecard: h5-opp-8766b98-p1

### Scorecard: h5-opp-8766b98-p1

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0103 | 1 | 1 | Mine | no | 2 | - | 0 | 1 | 0 | 0 | 0 | 0 |
| L0103 | 1 | 1 | Opponent | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 445 |
| L0120 | 6 | 1 | Mine | no | 0 | - | 0 | 0 | 0 | 0 | 0 | 0 |
| L0120 | 6 | 1 | Opponent | no | 3 | - | 1 | 5 | 0 | 0 | 0 | 210 |
| L0204 | 6 | 1 | Mine | yes | 7 | 6 | 0 | 3 | 0 | 0 | 0 | 0 |
| L0204 | 6 | 1 | Opponent | no | 4 | 1 | 3 | 1 | 0 | 0 | 0 | 0 |
| L0219 | 3 | 1 | Mine | no | 0 | 2 | 1 | 2 | 1 | 0 | 0 | 170 |
| L0219 | 3 | 1 | Opponent | yes | 9 | 2 | 1 | 0 | 1 | 0 | 0 | 0 |
| L0304 | 4 | 1 | Mine | no | 0 | - | 0 | 0 | 0 | 0 | 0 | 110 |
| L0304 | 4 | 1 | Opponent | no | 0 | 2 | 3 | 2 | 0 | 0 | 0 | 112 |
| L0321 | 3 | 1 | Mine | no | 10 | 3 | 2 | 1 | 0 | 0 | 0 | 225 |
| L0321 | 3 | 1 | Opponent | yes | 4 | - | 0 | 4 | 1 | 0 | 0 | 500 |
| L0406 | 4 | 1 | Mine | no | 4 | 3 | 2 | 1 | 0 | 0 | 0 | 0 |
| L0406 | 4 | 1 | Opponent | no | 0 | - | 1 | 1 | 1 | 0 | 0 | 451 |
| L0423 | 3 | 1 | Mine | no | 3 | 2 | 6 | 2 | 0 | 0 | 0 | 0 |
| L0423 | 3 | 1 | Opponent | yes | 2 | 2 | 2 | 1 | 1 | 0 | 0 | 0 |
| L0510 | 6 | 1 | Mine | no | 2 | - | 0 | 1 | 0 | 0 | 0 | 646 |
| L0510 | 6 | 1 | Opponent | no | 4 | 2 | 1 | 2 | 1 | 0 | 0 | 330 |
| L0525 | 3 | 1 | Mine | no | 5 | - | 1 | 0 | 0 | 0 | 0 | 574 |
| L0525 | 3 | 1 | Opponent | no | 8 | 2 | 3 | 2 | 0 | 0 | 0 | 0 |
| L0613 | 1 | 1 | Mine | no | 5 | 3 | 1 | 0 | 0 | 0 | 0 | 586 |
| L0613 | 1 | 1 | Opponent | no | 0 | 2 | 0 | 0 | 1 | 0 | 0 | 317 |
| L0630 | 6 | 1 | Mine | no | 2 | - | 3 | 2 | 0 | 0 | 0 | 290 |
| L0630 | 6 | 1 | Opponent | no | 2 | 2 | 2 | 0 | 1 | 0 | 0 | 0 |
| L0718 | 4 | 1 | Mine | no | 0 | 4 | 3 | 1 | 0 | 0 | 0 | 125 |
| L0718 | 4 | 1 | Opponent | no | 0 | - | 2 | 2 | 2 | 0 | 0 | 40 |
| **Average** | | | Mine | 8% | 3.1 | 3.3 | 1.5 | 1.1 | 0.1 | 0.0 | 0.0 | 209.7 |
| **Average** | | | Opponent | 23% | 2.8 | 1.9 | 1.5 | 1.7 | 0.7 | 0.0 | 0.0 | 185.0 |

### KPIs: h5-opp-8766b98-p1

Rules off - Mine only: HOLDER ASSIGNMENT, QUARTER ODDS.

Morten 2026-11-10; 13 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 42% (23 of 55) | 16% (10 of 61) | 28% (33 of 116) |
| Winner chose to follow up after the loser gave ground |  | 82% (9 of 11); on the table 82% | 93% (14 of 15); on the table 93% | 88% (23 of 26); on the table 88% |
| Winner chose to pursue after the loser fell back in good order |  | 100% (2 of 2); on the table 100% | 100% (7 of 7); on the table 100% | 100% (9 of 9); on the table 100% |
| Winner chose to pursue after the loser fled |  | 100% (4 of 4); on the table 100% | 80% (4 of 5); on the table 80% | 89% (8 of 9); on the table 89% |
| Winner chose to follow up or pursue (all three) |  | 88% (15 of 17); on the table 88% | 93% (25 of 27); on the table 93% | 91% (40 of 44); on the table 91% |
| Magic missiles tried each own turn | 50%+ | 46% (66 of 144) | 20% (18 of 90) | 36% (84 of 234) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 52% (66 of 126) | 28% (18 of 64) | 44% (84 of 190) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 29% (2 of 7) | 53% (8 of 15) | 45% (10 of 22) |
| Points that never fought | lower | 52% (12867 of 24787) | 60% (15645 of 25993) | 56% (28512 of 50780) |
|   infantry points that never fought | lower | 67% (4913 of 7300) | 73% (4201 of 5732) | 70% (9114 of 13032) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 59% (57 of 96) | 57% (57 of 100) | 58% (114 of 196) |
| Bound items with a magic missile used (at least once a game) |  | 83% (5 of 6); 0.9 uses a game | 60% (3 of 5); 0.7 uses a game | 73% (8 of 11); 0.8 uses a game |
| Bound items with another spell used |  | 100% (3 of 3); 0.7 uses a game | 33% (1 of 3); 0.2 uses a game | 67% (4 of 6); 0.4 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 56% (5 of 9); 0.4 uses a game | 50% (3 of 6); 0.2 uses a game | 53% (8 of 15); 0.3 uses a game |
|   their share of the points of units over 100 pts | lower | 53% (9941 of 18932) | 53% (11921 of 22355) | 53% (21862 of 41287) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 2.6 (44%) | 1.7 (31%) | 4.3 (37%) |
| MARCHED: its unit marched | 2.0 (33%) | 1.2 (22%) | 3.2 (28%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.2 (4%) | 0.2 (2%) |
| IN COMBAT: engaged in combat | 1.0 (17%) | 1.3 (24%) | 2.3 (20%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.2 (3%) | 0.2 (1%) |
| FLEEING: fleeing | 0.0 (0%) | 0.1 (1%) | 0.1 (1%) |
| GONE: slain | 0.4 (6%) | 0.5 (8%) | 0.8 (7%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (0%) | 0.2 (3%) | 0.2 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.1 (1%) | 0.1 (1%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.2 (3%) | 0.2 (1%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.7 | 0.5 | 2.5 | 6.5 | 0.5 | 1.3 |
| not cast | 2.7 | 1.5 | 4.0 | 11.5 | 2.3 | 18.1 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.8 (5%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.4 (26%) | 0.8 (21%) | 4.3 (37%) | 0.5 (23%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 3.2 (28%) | 0.4 (17%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (2%) | 0.1 (3%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.2 (11%) | 0.8 (19%) | 2.3 (20%) | 0.7 (30%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.3 (11%) | 0.3 (21%) | 0.0 (0%) | 0.2 (1%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (0%) | 0.0 (0%) | 0.1 (2%) | 0.1 (1%) | 0.1 (3%) | 0.5 (3%) |
| GONE: slain | 0.3 (11%) | 0.3 (21%) | 0.0 (0%) | 0.8 (7%) | 0.2 (7%) | 0.3 (2%) |
| OFF THE TABLE: off the table or not arrived | 0.1 (3%) | 0.0 (0%) | 0.2 (4%) | 0.2 (1%) | 0.2 (7%) | 0.9 (5%) |
| STUPIDITY: Stupidity | 0.1 (3%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.1 (2%) | 0.1 (1%) | 0.2 (10%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (1%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.9 (71%) | 0.3 (21%) | 2.1 (52%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 15.5 (86%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 2.0 a game | 1.0 a game | 1.5 a game |
| stood (cast and not dispelled) | 54% (14 of 26) | 25% (3 of 12) | 45% (17 of 38) |
| the unit moved after it | 79% (11 of 14) | 100% (3 of 3) | 82% (14 of 17) |
| it charged on its next turn | 0% (0 of 14) | 0% (0 of 3) | 0% (0 of 17) |
| the enemy charged it first | 14% (2 of 14) | 0% (0 of 3) | 12% (2 of 17) |
| it fought by the end of its next turn | 14% (2 of 14) | 0% (0 of 3) | 12% (2 of 17) |
| it moved out of a charge the enemy had planned (not charged first) | 14% (2 of 14) | 0% (0 of 3) | 12% (2 of 17) |
| none of these (no charge, no fight, no charge escaped) | 71% (10 of 14) | 100% (3 of 3) | 76% (13 of 17) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 62% (213 of 343) | 62% (170 of 275) | 62% (383 of 618) |
|   cavalry | 64% (16 of 25) | 68% (17 of 25) | 66% (33 of 50) |
|   character | 85% (33 of 39) | 41% (14 of 34) | 64% (47 of 73) |
|   chariot | 35% (12 of 34) | 51% (27 of 53) | 45% (39 of 87) |
|   infantry | 45% (43 of 96) | 53% (49 of 92) | 49% (92 of 188) |
|   monster | 67% (8 of 12) | 100% (12 of 12) | 83% (20 of 24) |
|   war machine | 74% (101 of 137) | 86% (51 of 59) | 78% (152 of 196) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 3.4 (34%) | 2.5 (31%) | 5.9 (33%) |
| CHARGED: it charged | 0.5 (5%) | 0.9 (11%) | 1.4 (8%) |
| IN COMBAT: it fought this turn or the last | 0.6 (6%) | 0.5 (6%) | 1.1 (6%) |
| MOVED: a war machine that moved | 1.4 (14%) | 0.1 (1%) | 1.5 (8%) |
| NO TARGET IN RANGE | 1.7 (17%) | 2.0 (25%) | 3.7 (20%) |
| ONLY IN COMBAT: the only targets were in combat | 0.1 (1%) | 0.3 (4%) | 0.4 (2%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.3 (13%) | 1.2 (14%) | 2.5 (14%) |
| SHELTERED: the target was sheltered | 0.2 (2%) | 0.1 (1%) | 0.2 (1%) |
| OTHER BAR | 0.9 (9%) | 0.5 (7%) | 1.5 (8%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 2.5 | 0.8 | 73% | 4.8 pts | 12 pts |
| character | 4.2 | 2.4 | 76% | 7.3 pts | 31 pts |
| chariot | 3.3 | 3.4 | 51% | 15.9 pts | 53 pts |
| infantry | 10.8 | 4.5 | 71% | 10.3 pts | 111 pts |
| monster | 1.5 | 0.6 | 65% | 13.7 pts | 21 pts |
| war machine | 11.7 | 9.3 | 63% | 23.5 pts | 274 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 2.5 | 4.0 | 3.2 |
| Charges that made contact a game | 2.2 | 2.8 | 2.5 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.29 declared, 0.29 contact (7 units) | 1.09 declared, 0.91 contact (11 units) | 0.78 declared, 0.67 contact (18 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 1.50 declared, 1.50 contact (2 units) | 1.50 declared, 1.50 contact (2 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.35 declared, 0.31 contact (85 units) | 0.37 declared, 0.24 contact (101 units) | 0.36 declared, 0.27 contact (186 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 42% (5 of 12) | 50% (2 of 4) | - | 44% (7 of 16) |
| Character in a unit | 94% (16 of 17) | 83% (10 of 12) | - | 90% (26 of 29) |
| Character on its own | 77% (10 of 13) | 33% (4 of 12) | 29% (4 of 14) | 46% (18 of 39) |
| Chariot | 80% (4 of 5) | 58% (7 of 12) | - | 65% (11 of 17) |
| Infantry | 41% (13 of 32) | 33% (6 of 18) | - | 38% (19 of 50) |
| Monster | 86% (6 of 7) | 80% (4 of 5) | - | 83% (10 of 12) |
| Monstrous | - | 50% (2 of 4) | - | 50% (2 of 4) |
| War Machines | 73% (19 of 26) | 67% (2 of 3) | - | 72% (21 of 29) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 100% (4 of 4); on the table 100% | 41% (42 of 102) | 46% | 55% (12 of 22) | 83% (5 of 6); 3.0 uses a game | 100% (2 of 2); 1.8 uses a game | 67% (4 of 6); 1.0 uses a game |
| Chaos Dwarfs | 7 | 88% (7 of 8); on the table 88% | 50% (30 of 60) | 56% | 50% (27 of 54) | 0.0 uses a game | 0.0 uses a game | 33% (1 of 3); 0.1 uses a game |
| Dwarfen Mountain Holds | 5 | 60% (3 of 5); on the table 60% | - | 63% | 75% (33 of 44) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 1 | 100% (3 of 3); on the table 100% | 67% (4 of 6) | 51% | 50% (5 of 10) | 0.0 uses a game | 100% (1 of 1); 2.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Grand Cathay | 1 | 100% (8 of 8); on the table 100% | 3% (1 of 30) | 48% | 30% (3 of 10) | 50% (1 of 2); 1.0 uses a game | 0% (0 of 1); 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| High Elf Realms | 1 | 100% (1 of 1); on the table 100% | 0% (0 of 6) | 52% | 12% (1 of 8) | 100% (1 of 1); 6.0 uses a game | 50% (1 of 2); 2.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 1 | 100% (2 of 2); on the table 100% | 0% (0 of 6) | 50% | 86% (6 of 7) | 100% (1 of 1); 2.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 1 | 100% (3 of 3); on the table 100% | 17% (1 of 6) | 12% | 25% (2 of 8) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Skaven | 2 | - | 17% (2 of 12) | 87% | 81% (13 of 16) | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.5 uses a game |
| Tomb Kings of Khemri | 1 | 100% (7 of 7); on the table 100% | - | 29% | 80% (4 of 5) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 1 | 67% (2 of 3); on the table 67% | 67% (4 of 6) | 63% | 67% (4 of 6) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 1 | - | - | 86% | 67% (4 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |

Flank and rear charges a unit could have turned to face (h5-opp-8766b98-p1, 13 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 48% (11) | 41% (7) | 45% (18) |
| ...free all their last turn and able to turn (per game) | 0.38 | 0.38 | 0.77 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.46 | 0.08 | 0.54 |
| ...with the charger already in that arc before they moved (per game) | 0.31 | 0.31 | 0.62 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.23 | 0.08 | 0.31 |

### Quality by phase: h5-opp-8766b98-p1

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.5 | 2.1 |
| Strategy | Charge objectives carried out (made contact) | 63% (19 of 30) | 51% (22 of 43) |
| Strategy | Shoot objectives carried out (shot that target) | 26% (47 of 181) | 56% (57 of 101) |
| Strategy | Support requests answered (helper made contact too) | 100% (3 of 3) | 67% (2 of 3) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | - | 100% (4 of 4) |
| Strategy | Hexes on a unit its side charged or shot that turn | 0% (0 of 1) | 100% (1 of 1) |
| Strategy | Joined characters whose unit fought | 41% (13 of 32) | 0% (0 of 14) |
| Strategy | Lone characters that fought | 62% (16 of 26) | 74% (20 of 27) |
| Movement | Charges halted short of contact | 0.0 | 0.2 |
| Movement | Idle units | 1.1 | 1.7 |
| Movement | Points that never moved of their own | 209.7 | 185.0 |
| Movement | Fights charged into per game | 1.9 | 2.4 |
| Movement | Charges with odds: long shots (under 50%) | 4 of 21, net +175 | 7 of 27, net +95 |
| Movement | Charges with odds: sweet spot (55-75%) | 4 of 21, net +246 | 2 of 27, net +142 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 21 | 3 of 27, net +88 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 8 of 21, net +55 | 11 of 27, net +188 |
| Shooting | Shots by shooting units (incl. breath weapons) | 8.9 | 10.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 40% (46 of 116) | 32% (41 of 130) |
| Shooting | Points destroyed by shooting units | 139.8 | 74.7 |
| Shooting | War machine shots | 7.8 | 3.9 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 49% (49 of 101) | 69% (35 of 51) |
| Shooting | Points destroyed by war machines | 112.2 | 5.0 |
| Magic | Magic missiles cast | 2.8 | 0.7 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 39% (14 of 36) | 67% (6 of 9) |
| Magic | Wounds caused by magic missiles | 4.2 | 1.4 |
| Magic | Wounds caused by other spells | 0.5 | 0.5 |
| Magic | Points destroyed by magic (all spells) | 40.6 | 15.1 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.2 / 0.1 / 0.7 / 0.2 | 2.5 / 0.2 / 0.2 / 0.1 |
| Combat | Points destroyed in combat | 179.1 | 245.1 |
| Combat | Points run down | 71.3 | 56.0 |
| Combat | Net points per charged fight, damage counted | +105 | +94 |
| Combat | Net per 100 charger points, damage counted | +52.6 | +30.1 |
| Combat | First round won (charged fights) | 76% | 77% |
| Combat | Net points per charged fight | +95 | +101 |
| Combat | Net points per supported fight / lone fight | +23 / +105 | +272 / +75 |
| Combat | Charged fights on a top-3 enemy unit | 10 of 25 | 14 of 31 |
| Game | Points lost | 567.0 | 644.8 |
| Game | VP from objectives | 702.3 | 762.3 |
| Game | Lone holders (player turns) | 3.1 | 2.8 |

- Mine won / drew / lost: 7 / 2 / 4 of 13 ended games (of 13); mean margin (Mine - Opponent) +89 VP
- The side that went first won 6 of 11 games with a winner
- Points traded per game (both sides' losses): 1212
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: h5-opp-8766b98-p1

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.6 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.2 | +30.0 | 0.0 | 0.0 | 0.1 | +5.8 | 0.0 | 0.0 |
| ALREADY CARRIED | 0.2 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARRIVAL HUNT | - | - | - | - | 0.1 | +5.9 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 2.5 | +0.0 | 0.0 | 50.4 | 0.5 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | 0.2 | +1.5 | 0.0 | 0.0 | 0.2 | +0.2 | 0.0 | 0.0 |
| BEST PRIZE | 0.2 | -19.1 | 12.7 | 0.0 | 0.2 | -9.1 | 28.8 | 0.0 |
| BLOWS WHERE AIMED | 0.1 | -3.0 | 18.1 | 0.0 | 0.2 | -27.5 | 0.0 | 36.8 |
| BOMBING RUN | 0.1 | +2.9 | 0.0 | 0.0 | - | - | - | - |
| CANNON PLAN MISSED | 1.3 | +0.0 | 159.8 | 26.2 | 0.2 | +0.0 | 21.8 | 12.7 |
| CANNON PLANNED TARGET | 7.6 | +144.4 | 886.5 | 196.2 | 4.0 | +98.3 | 161.2 | 50.4 |
| CANNON SIGHT KEPT | 1.6 | +0.0 | 0.0 | 0.0 | 0.5 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT COUNTER | 0.1 | +0.0 | 0.0 | 26.1 | 0.1 | -0.0 | 0.0 | 0.0 |
| CARRIES OUT SET-UP | - | - | - | - | 0.1 | -1.5 | 14.3 | 0.0 |
| CAST JOB | 1.1 | +10.3 | 0.0 | 0.0 | 0.8 | +5.9 | 6.5 | 0.0 |
| CASTER AWAY FROM SCREEN | 0.2 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CASTING BLOCK | 0.4 | +34.3 | 0.0 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | 1.0 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | - | - | - | - | 0.2 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.1 | +1.6 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | 0.2 | +8.7 | 0.0 | 6.5 | 0.5 | +19.5 | 0.0 | 5.2 |
| CHAFF PASSED | 0.2 | -0.2 | 0.0 | 0.0 | 0.2 | -0.0 | 0.0 | 11.2 |
| CHARACTER GUNS | 0.8 | +0.0 | 0.0 | 0.0 | 0.8 | +0.0 | 0.0 | 0.0 |
| CHARGE LOSSES | 6.2 | -274.3 | 0.0 | 112.8 | 6.1 | -255.6 | 0.0 | 199.6 |
| CHARGE NOT DECLARED | 0.3 | +0.0 | 18.1 | 15.5 | 0.3 | +0.0 | 15.8 | 23.8 |
| CHARGE NOW FIRST | 1.2 | +0.0 | 146.1 | 30.1 | 1.8 | +0.0 | 161.9 | 64.2 |
| CHARGER SLAIN LOST | 0.4 | -22.5 | 3.5 | 6.5 | 0.1 | -1.5 | 22.2 | 0.0 |
| CHEAP HELPER | 0.1 | +0.0 | 0.0 | 4.0 | - | - | - | - |
| CHEAPEST HOLDER | 0.3 | -10.6 | 4.6 | 0.0 | - | - | - | - |
| COMBAT PIVOT | 0.6 | +0.0 | 0.0 | 86.8 | 0.3 | +0.0 | 5.0 | 31.2 |
| CONTINUE AHEAD WEIGHED | - | - | - | - | 0.1 | +0.0 | 8.1 | 36.8 |
| CONVEYANCE SEARCH | 1.3 | +107.9 | 0.0 | 0.0 | 0.4 | +9.4 | 0.0 | 0.0 |
| COVER ONCE | 6.9 | -367.8 | 0.0 | 139.6 | 5.0 | -336.6 | 0.0 | 62.2 |
| DEFENSIVE ARMY | 0.2 | +0.0 | 36.8 | 0.0 | - | - | - | - |
| DEPLOY BY FIGURES | 9.4 | +6.7 | 0.0 | 5.0 | 8.2 | +26.3 | 0.0 | 29.9 |
| EDGE GIVE GROUND | 0.1 | +0.9 | 0.0 | 0.0 | 0.2 | +35.6 | 6.5 | 23.8 |
| ELIXIR WORTH | - | - | - | - | 0.1 | +1.5 | 0.0 | 0.0 |
| ENGINEER BY LORE | 0.3 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| FALL BACK GOOD ORDER | 1.5 | +0.0 | 107.8 | 50.1 | 2.4 | +5.5 | 258.5 | 73.8 |
| FALLBACK BY WORTH | 0.2 | +0.0 | 0.0 | 6.5 | 0.1 | +0.0 | 0.0 | 0.0 |
| FALLS SHORT | 6.2 | +117.8 | 0.0 | 25.4 | 16.9 | +215.7 | 0.0 | 135.2 |
| FEATURE BUFFS | 1.8 | +39.1 | 0.0 | 8.5 | 0.2 | +8.7 | 0.0 | 8.5 |
| FIGHT LIFT | - | - | - | - | 0.1 | +0.2 | 0.0 | 0.0 |
| FIGHT TO THE END | 0.8 | +50.6 | 117.5 | 31.1 | 1.3 | +85.0 | 101.2 | 64.2 |
| FIRE IN ORDER | 0.4 | +0.0 | 2.6 | 18.1 | 0.1 | +0.0 | 0.0 | 0.0 |
| FIVE ACTION | 47.8 | +2185.7 | 1342.6 | 664.4 | 48.3 | +2705.1 | 625.3 | 515.8 |
| FLANK NOT WEIGHED | 4.0 | +0.0 | 0.0 | 49.5 | 5.2 | +0.0 | 0.0 | 73.1 |
| FOLLOW UP WEIGHED | 0.5 | +117.2 | 0.0 | 22.2 | 0.5 | +166.9 | 0.0 | 0.0 |
| FOUR ROUNDS | 2.3 | +200.3 | 165.6 | 50.1 | 3.2 | +353.2 | 313.6 | 73.8 |
| FRIEND CHARGES FIRST | 0.2 | -4.1 | 0.0 | 0.0 | 0.1 | -3.9 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 0.5 | -24.7 | 0.0 | 0.0 | 0.2 | -4.3 | 0.0 | 0.0 |
| FRIENDS SHOTS CHECKED | 0.2 | +9.2 | 0.0 | 0.0 | 0.3 | +12.6 | 0.0 | 26.7 |
| GIVES UP | 0.2 | -2.2 | 18.1 | 6.5 | 0.2 | -3.7 | 35.9 | 0.0 |
| GROUND FLIERS | 0.1 | +3.2 | 0.0 | 16.8 | - | - | - | - |
| GUN FIGURES | 0.9 | -0.9 | 5.1 | 23.8 | 1.6 | +19.3 | 46.5 | 43.1 |
| GUN MASK | 0.7 | +11.4 | 0.0 | 14.3 | 0.1 | +1.9 | 0.0 | 0.0 |
| HARD STAY DROPPED | 0.7 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| HE SHOOTS OR CHARGES | 1.3 | +0.0 | 0.0 | 57.6 | 1.9 | +0.0 | 0.0 | 0.0 |
| HELPER ALREADY ASKED | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS CHARGE DENIED | 0.5 | +8.8 | 28.8 | 0.0 | 0.2 | +4.6 | 14.5 | 0.0 |
| HIS CHARGE LIST | 2.0 | +0.0 | 0.0 | 47.5 | 2.8 | +0.0 | 0.0 | 54.4 |
| HIS LEGAL MOVES | 2.8 | +0.0 | 0.0 | 14.5 | 3.5 | +0.0 | 0.0 | 97.5 |
| HIS MOVE AND SHOT | 2.2 | -36.1 | 0.0 | 63.3 | 2.1 | -50.9 | 0.0 | 103.3 |
| HIS RANDOM MOVE | 1.3 | +0.0 | 0.0 | 4.2 | 0.8 | +0.0 | 0.0 | 8.8 |
| HIS SHOT LIST | 18.0 | +483.8 | 0.0 | 265.6 | 24.3 | +1109.9 | 0.0 | 256.3 |
| HIS TURN DENIED | 0.8 | +25.5 | 111.9 | 32.6 | 1.9 | +103.2 | 150.2 | 60.7 |
| HOLD ODDS | - | - | - | - | 13.8 | +0.0 | 0.0 | 27.8 |
| HOLDER ASSIGNMENT | - | - | - | - | 16.3 | +1415.7 | 0.0 | 27.8 |
| HOLDER AT DEPLOYMENT | 1.0 | +199.5 | 0.0 | 0.0 | - | - | - | - |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 1.6 | -38.2 | 116.2 | 39.5 | 2.8 | -128.5 | 289.1 | 50.0 |
| HUNT IN PAIRS | - | - | - | - | 0.3 | +3.6 | 0.0 | 0.0 |
| HUNT RESULT | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +33.0 | 0.0 | 2.6 |
| HUNT THE GUNS | 0.1 | +35.9 | 0.0 | 0.0 | 0.1 | +38.8 | 9.6 | 0.0 |
| IDLE COST | 5.1 | -48.1 | 0.0 | 56.8 | 11.9 | -169.6 | 0.0 | 187.3 |
| JOINT KNOWS CHALLENGE | - | - | - | - | 0.2 | -10.4 | 44.5 | 0.0 |
| KEEP FALLS | 0.1 | +1.2 | 0.0 | 0.0 | - | - | - | - |
| KEEPS SCOUTS OR AMBUSH | 0.2 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| KILLS COUNT | - | - | - | - | 0.1 | +2.5 | 7.3 | 0.0 |
| LANE BY FIGURES | 0.3 | +7.8 | 0.0 | 0.0 | 0.8 | +35.3 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 3.6 | +0.0 | 289.5 | 71.2 | 3.8 | +0.0 | 105.2 | 343.5 |
| LONE WIZARD KEPT IN | 0.8 | +47.5 | 0.0 | 8.8 | 0.2 | +25.1 | 0.0 | 0.0 |
| LONG SHOT | 0.2 | +0.3 | 0.0 | 0.0 | 0.1 | -0.3 | 0.0 | 0.0 |
| LOST CHARGE | 0.2 | -0.3 | 0.0 | 0.0 | 0.1 | -0.1 | 14.3 | 0.0 |
| LURE BY WHAT IT DRAWS | 0.1 | -6.1 | 0.0 | 6.5 | - | - | - | - |
| MAKE SURE TOGETHER | - | - | - | - | 0.2 | +0.2 | 0.0 | 0.0 |
| MANOEUVRE | 1.1 | +14.7 | 0.0 | 50.2 | 1.0 | +15.2 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.1 | +0.3 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| MARCH BY THE SUM | 0.3 | +13.9 | 0.0 | 0.0 | 0.2 | +9.6 | 0.0 | 0.0 |
| MARCH CHECK | 0.5 | +25.8 | 0.0 | 0.0 | 0.6 | +19.0 | 0.0 | 0.0 |
| MARCH OVER CASTS | 0.5 | -7.6 | 0.0 | 0.0 | 0.6 | +24.8 | 0.0 | 12.8 |
| MAX FOR POSITIONING | 3.2 | +28.5 | 0.0 | 29.2 | 4.8 | +45.6 | 0.0 | 82.3 |
| MISSILES IN THE MOVE | 4.2 | +188.9 | 0.0 | 18.7 | 2.9 | +37.3 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 4.4 | +105.6 | 0.0 | 18.7 | 4.5 | +37.9 | 0.0 | 12.8 |
| MODEL FACING | 0.8 | +247.8 | 0.0 | 9.2 | 0.6 | +88.3 | 0.0 | 4.6 |
| MOVE SPELL IN RANGE | 0.4 | +10.6 | 0.0 | 0.0 | 0.2 | +3.0 | 0.0 | 0.0 |
| MOVE SPELL NOT WORTH | 0.2 | -0.1 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 1.6 | -46.0 | 6.2 | 0.0 | 0.2 | -3.3 | 0.0 | 0.0 |
| MOVE SPELL SPOT | 0.7 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 3.5 | +269.3 | 0.0 | 13.6 | 3.6 | +338.9 | 0.0 | 48.3 |
| MOVES UNITS SPELL | 0.2 | +8.5 | 0.0 | 0.0 | 0.1 | +0.3 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 4.3 | +257.2 | 0.0 | 64.5 | 6.2 | +264.7 | 0.0 | 14.3 |
| NEEDED THERE | - | - | - | - | 0.1 | +11.4 | 7.3 | 0.0 |
| NEXT CHARGE BY LIST | 5.2 | -100.3 | 4.6 | 44.5 | 5.1 | -151.6 | 0.0 | 91.5 |
| NEXT OBJECTIVE NEARER | 7.9 | -373.5 | 179.8 | 92.5 | 0.1 | -1.3 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 1.8 | -92.4 | 152.3 | 50.1 | 2.6 | -105.5 | 257.8 | 60.7 |
| NOT TURNED | 0.2 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 0.8 | -0.6 | 0.0 | 0.0 | 0.2 | -0.1 | 0.0 | 0.0 |
| OFF BEST | 0.4 | -5.6 | 0.0 | 0.0 | 0.8 | -14.2 | 0.0 | 0.0 |
| ONE CHARGE A CHARGER | 2.4 | +0.0 | 0.0 | 80.5 | 1.8 | +0.0 | 0.0 | 2.9 |
| ONE FIGHT FORMULA | 4.8 | -68.2 | 0.0 | 41.8 | 5.2 | -120.4 | 0.0 | 112.3 |
| ONE OBJECTIVE FORMULA | 4.4 | +42.5 | 0.0 | 28.7 | 4.5 | +25.2 | 0.0 | 17.7 |
| ONE TARGET A SHOOTER | 15.3 | +451.8 | 0.0 | 193.1 | 22.2 | +577.0 | 0.0 | 119.8 |
| OPENS UP | 0.2 | +6.0 | 8.1 | 0.0 | 0.3 | +9.0 | 8.8 | 0.0 |
| OVERRUNS AWAY | 0.2 | +2.7 | 8.1 | 0.0 | 0.5 | +12.8 | 70.5 | 9.7 |
| PATHS CROSS | 3.2 | +100.7 | 0.0 | 4.6 | 3.6 | +121.6 | 0.0 | 5.8 |
| PERIAPT WORTH | - | - | - | - | 0.1 | +7.6 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.1 | -1.3 | 0.0 | 0.0 | 0.1 | -0.1 | 0.0 | 0.0 |
| PLAN RESULT | 41.8 | +1269.8 | 1146.7 | 773.8 | 42.7 | +768.9 | 277.5 | 865.8 |
| QUARTER ODDS | - | - | - | - | 4.8 | +654.7 | 110.8 | 56.2 |
| RANDOM MOVE BY FIGURES | 0.5 | +13.1 | 0.0 | 26.2 | 1.2 | +18.3 | 0.0 | 54.6 |
| REDIRECT BY WHAT IT STOPS | 0.1 | -0.2 | 0.0 | 0.0 | 0.2 | +5.1 | 0.0 | 0.0 |
| REDIRECT COUNTER | 1.6 | +70.5 | 0.0 | 36.4 | 1.5 | +55.6 | 0.0 | 15.1 |
| REDIRECT WEIGHED | 0.1 | +9.5 | 14.3 | 0.0 | 0.2 | +0.0 | 0.0 | 4.6 |
| REFORMS TO MEET IT | 1.2 | -36.8 | 0.0 | 9.0 | 0.6 | -6.9 | 0.0 | 4.6 |
| REFUSING RETIRES | 0.2 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | 0.7 | +39.0 | 0.0 | 17.2 | 0.6 | +13.9 | 0.0 | 5.1 |
| RESTRAINS TO SHOOT | 0.1 | +8.1 | 0.0 | 0.0 | 0.2 | +11.7 | 0.0 | 0.0 |
| RISK BY ARC | 1.5 | -1.7 | 127.3 | 50.1 | 1.9 | -28.7 | 177.5 | 50.0 |
| RISK BY HIS FIGURE | 11.9 | -136.7 | 0.0 | 209.7 | 10.6 | -116.5 | 0.0 | 179.4 |
| RUN DOWN | 1.3 | -10.7 | 58.1 | 34.5 | 1.7 | -12.1 | 194.1 | 64.2 |
| SAME CHARGE LATER | - | - | - | - | 0.1 | -1.6 | 0.0 | 0.0 |
| SCOUT SPOT | 0.3 | +2.1 | 0.0 | 0.0 | 0.3 | +2.0 | 0.0 | 0.0 |
| SCOUT WAITS | 0.3 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.1 | -12.3 | 0.0 | 0.0 | 0.1 | -5.4 | 0.0 | 0.0 |
| SEARCH SPOT | 5.9 | +185.5 | 0.0 | 68.6 | 5.2 | +175.4 | 0.0 | 24.6 |
| SELF MOVE SPELL | - | - | - | - | 0.2 | -0.2 | 0.0 | 0.0 |
| SET UP TOGETHER | 0.3 | +1.8 | 0.0 | 6.5 | 0.3 | +1.4 | 0.0 | 34.0 |
| SET-UP ANY TARGET | 0.4 | +64.5 | 0.0 | 0.0 | 0.1 | +4.1 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.6 | +1.2 | 0.0 | 0.0 | 0.2 | +0.7 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.1 | +45.4 | 28.8 | 0.0 | 1.1 | +22.7 | 28.2 | 5.0 |
| SHORT GUN FORWARD | 0.5 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| SHOT OR CHARGE | 0.2 | -4.3 | 5.2 | 10.5 | 0.1 | -0.3 | 5.0 | 3.5 |
| SHOT RISK POINTS | 9.2 | -93.1 | 0.0 | 181.2 | 12.4 | -36.5 | 0.0 | 166.8 |
| SHOTS IN THE MOVE | 18.0 | +728.9 | 0.0 | 322.2 | 13.8 | +327.2 | 0.0 | 242.9 |
| SPELL SETS UP CHARGE | 0.4 | +64.5 | 0.0 | 0.0 | 0.1 | +4.1 | 0.0 | 0.0 |
| SPELL WORTH | 0.6 | +3.6 | 0.0 | 0.0 | 1.6 | +27.5 | 0.0 | 0.0 |
| SPELLS IN THE FIGHT | 0.4 | -6.2 | 59.2 | 0.0 | 0.4 | -6.1 | 25.1 | 0.0 |
| STAND AND SHOOT | 0.4 | -7.9 | 35.6 | 0.0 | 0.8 | -18.6 | 81.9 | 9.7 |
| STANDS FOR A REASON | 0.1 | +0.0 | 0.0 | 0.0 | 0.8 | +0.0 | 11.5 | 0.0 |
| STANDS STILL | 20.6 | +0.0 | 1177.0 | 346.5 | 13.8 | +0.0 | 275.2 | 135.1 |
| STAY WORTH | 21.9 | +69.9 | 823.5 | 279.2 | 14.4 | +51.2 | 153.6 | 144.0 |
| STOPS | 0.1 | +0.5 | 0.0 | 0.0 | 0.1 | +0.8 | 9.6 | 0.0 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| SUPPORT NARROWED | 1.0 | +0.0 | 57.5 | 35.1 | 1.0 | +0.0 | 92.6 | 60.7 |
| SURE REACH TOGETHER | 0.3 | +1.6 | 0.0 | 6.5 | 0.6 | +9.1 | 0.0 | 36.6 |
| THE DEARER SUM KEEPS ITS PLAN | 3.9 | +0.0 | 0.0 | 21.2 | 4.0 | +0.0 | 0.0 | 2.9 |
| THE PROMISE ADDS | 0.1 | -0.1 | 0.0 | 4.0 | 0.2 | -4.1 | 22.2 | 9.7 |
| THE PROMISED MOVE | 0.2 | +0.0 | 0.0 | 0.0 | 1.2 | +0.0 | 0.0 | 4.2 |
| TIED UP BY THE SUM | 0.2 | +26.1 | 16.2 | 0.0 | 0.5 | +53.1 | 45.1 | 0.0 |
| TIME ON OUR SIDE | 24.0 | +377.8 | 12.8 | 210.2 | 10.2 | +142.5 | 0.0 | 50.1 |
| WAITS AGAIN | 2.3 | +0.0 | 0.0 | 12.5 | 1.1 | +0.0 | 0.0 | 9.7 |
| WAR ENGINE CHARGES | 0.1 | +15.1 | 0.0 | 0.0 | 0.1 | +41.1 | 0.0 | 23.8 |
| WAR ENGINE JOBS | 0.4 | +0.0 | 32.3 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| WHO HITS BACK | 0.2 | +143.2 | 0.0 | 0.0 | 0.1 | +2.7 | 0.0 | 3.5 |
| WHOLE FIGHT | 0.1 | +2.7 | 0.0 | 0.0 | 0.2 | +8.6 | 44.5 | 0.0 |
| WHOLE FIGHT GAIN | 0.2 | +7.8 | 9.2 | 0.0 | 0.1 | +12.3 | 28.0 | 0.0 |
| WIDER SPREAD | 1.8 | -1.0 | 155.8 | 20.0 | 2.2 | -13.7 | 184.2 | 64.2 |
| WOUNDS ON THE RANKS | 2.2 | +95.4 | 0.0 | 14.1 | 1.2 | +31.6 | 0.0 | 12.8 |

### Rule changes: h5-opp-8766b98-p1

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HOLDER ASSIGNMENT | 212 | 212 | 196 | 15.08 | +8412 | +42.9 |
| HIS SHOT LIST | 550 | 550 | 164 | 12.62 | +3417 | +20.8 |
| SEARCH SPOT | 144 | 144 | 141 | 10.85 | +4692 | +33.3 |
| ONE TARGET A SHOOTER | 487 | 487 | 139 | 10.69 | +1163 | +8.4 |
| DEPLOY BY FIGURES | 229 | 229 | 138 | 10.62 | +2564 | +18.6 |
| LEGAL CHARGES ONLY | 97 | 97 | 97 | 7.46 | +0 | +0.0 |
| PATHS CROSS | 89 | 89 | 89 | 6.85 | +2890 | +32.5 |
| TIME ON OUR SIDE | 445 | 397 | 86 | 6.62 | +382 | +4.4 |
| FIVE ACTION | 1249 | 1247 | 66 | 5.08 | +2550 | +38.6 |
| MOVE TO CHARGE COMPUTED | 92 | 92 | 61 | 4.69 | +3010 | +49.3 |
| SHOT RISK POINTS | 281 | 281 | 49 | 3.77 | +1365 | +27.9 |
| ARTILLERY RE-ROLL WEIGHED | 39 | 39 | 39 | 3.00 | +0 | +0.0 |
| FOUR ROUNDS | 72 | 70 | 39 | 3.00 | +2905 | +74.5 |
| SHOTS IN THE MOVE | 413 | 384 | 34 | 2.62 | +1241 | +36.5 |
| HARD STAY DROPPED | 31 | 31 | 31 | 2.38 | +0 | +0.0 |
| IDLE COST | 221 | 179 | 30 | 2.31 | +277 | +9.2 |
| FALLS SHORT | 300 | 250 | 29 | 2.23 | +358 | +12.3 |
| CANNON SIGHT KEPT | 28 | 28 | 28 | 2.15 | +0 | +0.0 |
| MAX FOR POSITIONING | 105 | 102 | 27 | 2.08 | +54 | +2.0 |
| COVER ONCE | 155 | 131 | 25 | 1.92 | +334 | +13.4 |
| CANNON PLANNED TARGET | 151 | 151 | 23 | 1.77 | -354 | -15.4 |
| NEXT OBJECTIVE NEARER | 104 | 104 | 23 | 1.77 | +224 | +9.7 |
| SHOOTS FROM THE BEST SPOT | 28 | 28 | 21 | 1.62 | +298 | +14.2 |
| MODEL FACING | 19 | 19 | 19 | 1.46 | +4369 | +229.9 |
| MANOEUVRE | 27 | 27 | 18 | 1.38 | +445 | +24.7 |
| ONE OBJECTIVE FORMULA | 116 | 101 | 18 | 1.38 | +897 | +49.9 |
| ADVANCE LANE KEPT | 17 | 17 | 17 | 1.31 | +0 | +0.0 |
| MISSILES IN THE MOVE | 92 | 78 | 17 | 1.31 | +390 | +22.9 |
| RESERVE FALL BACK | 17 | 17 | 17 | 1.31 | +687 | +40.4 |
| CHARGE LOSSES | 160 | 160 | 15 | 1.15 | +935 | +62.3 |
| LANE BY FIGURES | 15 | 15 | 15 | 1.15 | +561 | +37.4 |
| OFF BEST | 15 | 15 | 15 | 1.15 | -257 | -17.2 |
| RISK BY HIS FIGURE | 293 | 293 | 14 | 1.08 | +1068 | +76.3 |
| LONE WIZARD KEPT IN | 13 | 13 | 13 | 1.00 | +944 | +72.7 |
| CHARGE NOW FIRST | 40 | 40 | 12 | 0.92 | -1290 | -107.5 |
| COMBAT PIVOT | 12 | 12 | 12 | 0.92 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 12 | 12 | 12 | 0.92 | +3694 | +307.8 |
| NEXT CHARGE BY LIST | 134 | 134 | 11 | 0.85 | +237 | +21.5 |
| SHOOTERS IN TWO RANKS | 11 | 11 | 11 | 0.85 | +25 | +2.3 |
| HOLDS AMBUSHERS | 10 | 10 | 10 | 0.77 | +0 | +0.0 |
| NEARER NOT NEEDED | 136 | 132 | 10 | 0.77 | +370 | +37.0 |
| RANDOM MOVE BY FIGURES | 22 | 22 | 10 | 0.77 | +408 | +40.8 |
| HOLDER AT DEPLOYMENT | 13 | 13 | 9 | 0.69 | +414 | +46.0 |
| MARCH CHECK | 14 | 13 | 9 | 0.69 | +200 | +22.2 |
| RISK BY ARC | 45 | 44 | 9 | 0.69 | +371 | +41.3 |
| SCOUT WAITS | 9 | 9 | 9 | 0.69 | +0 | +0.0 |
| SHORT GUN FORWARD | 9 | 9 | 9 | 0.69 | +0 | +0.0 |
| CHAFF IN THE MOVE | 9 | 9 | 8 | 0.62 | +107 | +13.4 |
| CHARGE NOT DECLARED | 8 | 8 | 8 | 0.62 | -1109 | -138.6 |
| QUARTER ODDS | 62 | 62 | 8 | 0.62 | +1245 | +155.6 |
| TIED UP BY THE SUM | 10 | 10 | 8 | 0.62 | +240 | +30.0 |
| FIGHT TO THE END | 27 | 26 | 7 | 0.54 | +462 | +66.0 |
| MARCH BY THE SUM | 7 | 7 | 7 | 0.54 | +306 | +43.7 |
| CAST JOB | 24 | 24 | 6 | 0.46 | +12 | +1.9 |
| FIRE IN ORDER | 6 | 6 | 6 | 0.46 | +0 | +0.0 |
| FRIENDS SHOTS CHECKED | 6 | 6 | 6 | 0.46 | +284 | +47.3 |
| HIS TURN DENIED | 35 | 34 | 6 | 0.46 | +265 | +44.1 |
| SURE REACH TOGETHER | 12 | 12 | 6 | 0.46 | +2 | +0.4 |
| CHAFF PASSED | 5 | 5 | 5 | 0.38 | -2 | -0.4 |
| OPENS UP | 7 | 7 | 5 | 0.38 | +93 | +18.7 |
| WOUNDS ON THE RANKS | 45 | 45 | 5 | 0.38 | +376 | +75.3 |
| BEST PRIZE | 4 | 4 | 4 | 0.31 | -367 | -91.6 |
| CASTING BLOCK | 5 | 5 | 4 | 0.31 | +111 | +27.7 |
| FEATURE BUFFS | 27 | 27 | 4 | 0.31 | +43 | +10.8 |
| REDIRECT WEIGHED | 4 | 4 | 4 | 0.31 | +247 | +61.7 |
| STAY WORTH | 472 | 445 | 4 | 0.31 | +29 | +7.2 |
| WHO HITS BACK | 4 | 4 | 4 | 0.31 | +1486 | +371.4 |
| WHOLE FIGHT GAIN | 4 | 4 | 4 | 0.31 | +174 | +43.5 |
| AFTERMATH IN POINTS | 3 | 3 | 3 | 0.23 | +464 | +154.7 |
| CASTER AWAY FROM SCREEN | 3 | 3 | 3 | 0.23 | +0 | +0.0 |
| HIS CHARGE DENIED | 8 | 8 | 3 | 0.23 | +73 | +24.2 |
| HONEST WORTH | 58 | 57 | 3 | 0.23 | +11 | +3.5 |
| KEEPS SCOUTS OR AMBUSH | 3 | 3 | 3 | 0.23 | +0 | +0.0 |
| MOVES UNITS SPELL | 3 | 3 | 3 | 0.23 | +114 | +38.2 |
| REDIRECT COUNTER | 40 | 31 | 3 | 0.23 | +120 | +39.9 |
| RESTRAINS TO SHOOT | 3 | 3 | 3 | 0.23 | +257 | +85.7 |
| STUCK PIVOT | 3 | 3 | 3 | 0.23 | +0 | +0.0 |
| SUPPORT NARROWED | 26 | 26 | 3 | 0.23 | -56 | -18.8 |
| CASTS FROM BEHIND | 2 | 2 | 2 | 0.15 | +0 | +0.0 |
| GUN MASK | 10 | 10 | 2 | 0.15 | +22 | +11.2 |
| HIS MOVE AND SHOT | 55 | 55 | 2 | 0.15 | +40 | +19.8 |
| ONE FIGHT FORMULA | 129 | 66 | 2 | 0.15 | +3 | +1.5 |
| OVERRUNS AWAY | 9 | 8 | 2 | 0.15 | +1 | +0.4 |
| PIVOT GUARDS FLANK | 2 | 2 | 2 | 0.15 | -18 | -9.1 |
| REFUSING RETIRES | 4 | 4 | 2 | 0.15 | -0 | -0.2 |
| STAND AND SHOOT | 15 | 14 | 2 | 0.15 | +9 | +4.6 |
| WAR ENGINE JOBS | 8 | 8 | 2 | 0.15 | -126 | -63.0 |
| WIDER SPREAD | 53 | 52 | 2 | 0.15 | +30 | +15.2 |
| BACKUP TARGETS | 4 | 2 | 1 | 0.08 | +7 | +7.2 |
| BOMBING RUN | 1 | 1 | 1 | 0.08 | +38 | +37.6 |
| CARRIES OUT COUNTER | 2 | 2 | 1 | 0.08 | -0 | -0.1 |
| CARRIES OUT SET-UP | 1 | 1 | 1 | 0.08 | -20 | -20.1 |
| CONTINUE AHEAD WEIGHED | 1 | 1 | 1 | 0.08 | +0 | +0.0 |
| ELIXIR WORTH | 1 | 1 | 1 | 0.08 | +20 | +19.9 |
| KEEP FALLS | 1 | 1 | 1 | 0.08 | +52 | +51.8 |
| KILLS COUNT | 1 | 1 | 1 | 0.08 | +0 | +0.0 |
| LONG SHOT | 3 | 3 | 1 | 0.08 | +1 | +0.6 |
| MISSILES NEXT TURN | 115 | 88 | 1 | 0.08 | +4 | +4.5 |
| NEEDED THERE | 1 | 1 | 1 | 0.08 | +0 | +0.0 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.08 | +99 | +99.0 |
| REDIRECT BY WHAT IT STOPS | 4 | 4 | 1 | 0.08 | +37 | +36.7 |
| SAME CHARGE LATER | 1 | 1 | 1 | 0.08 | +18 | +17.6 |
| SET UP TOGETHER | 8 | 6 | 1 | 0.08 | +0 | +0.0 |
| WHOLE FIGHT | 3 | 3 | 1 | 0.08 | +73 | +72.6 |
| ALREADY CARRIED | 3 | not checked | - | - | - | - |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| BLOWS WHERE AIMED | 3 | 3 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 20 | 20 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 16 | trace | - | - | - | - |
| CATCH FLIERS | 1 | not checked | - | - | - | - |
| CHARACTER GUNS | 20 | 20 | 0 | 0.00 | - | - |
| CHARGER SLAIN LOST | 6 | 6 | 0 | 0.00 | - | - |
| CHEAP HELPER | 1 | not checked | - | - | - | - |
| CHEAPEST HOLDER | 4 | 4 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 22 | not checked | - | - | - | - |
| DEFENSIVE ARMY | 2 | 2 | 0 | 0.00 | - | - |
| EDGE GIVE GROUND | 3 | 3 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 6 | 6 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 51 | 49 | 0 | 0.00 | - | - |
| FALLBACK BY WORTH | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT LIFT | 1 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 120 | not checked | - | - | - | - |
| FRIEND CHARGES FIRST | 4 | 4 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 9 | 9 | 0 | 0.00 | - | - |
| GIVES UP | 5 | 4 | 0 | 0.00 | - | - |
| GROUND FLIERS | 1 | not checked | - | - | - | - |
| GUN FIGURES | 33 | not checked | - | - | - | - |
| HE SHOOTS OR CHARGES | 42 | 42 | 0 | 0.00 | - | - |
| HELPER ALREADY ASKED | 1 | not checked | - | - | - | - |
| HIS CHARGE LIST | 63 | 63 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 81 | 81 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 27 | 27 | 0 | 0.00 | - | - |
| HOLD ODDS | 180 | 180 | 0 | 0.00 | - | - |
| HUNT IN PAIRS | 4 | 2 | 0 | 0.00 | - | - |
| HUNT RESULT | 2 | trace | - | - | - | - |
| HUNT THE GUNS | 2 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 2 | 2 | 0 | 0.00 | - | - |
| LOST CHARGE | 3 | 2 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 1 | 1 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 2 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 2 | trace | - | - | - | - |
| MARCH OVER CASTS | 14 | 14 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 8 | 4 | 0 | 0.00 | - | - |
| MOVE SPELL NOT WORTH | 2 | not checked | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 24 | trace | - | - | - | - |
| MOVE SPELL SPOT | 11 | not checked | - | - | - | - |
| NO DOUBLE ROUNDS | 57 | 55 | 0 | 0.00 | - | - |
| NOT TURNED | 4 | 4 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 12 | not checked | - | - | - | - |
| ONE CHARGE A CHARGER | 54 | 54 | 0 | 0.00 | - | - |
| PLAN RESULT | 1098 | trace | - | - | - | - |
| REFORMS TO MEET IT | 23 | 23 | 0 | 0.00 | - | - |
| RUN DOWN | 39 | 37 | 0 | 0.00 | - | - |
| SCOUT SPOT | 8 | 8 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 2 | 2 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 3 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 6 | not checked | - | - | - | - |
| SHOT OR CHARGE | 4 | 4 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 6 | not checked | - | - | - | - |
| SPELL WORTH | 29 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 10 | 10 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 11 | 11 | 0 | 0.00 | - | - |
| STANDS STILL | 448 | 448 | 0 | 0.00 | - | - |
| STOPS | 2 | 2 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 103 | not checked | - | - | - | - |
| THE PROMISE ADDS | 3 | 3 | 0 | 0.00 | - | - |
| THE PROMISED MOVE | 18 | not checked | - | - | - | - |
| WAITS AGAIN | 44 | 44 | 0 | 0.00 | - | - |
| WAR ENGINE CHARGES | 2 | 2 | 0 | 0.00 | - | - |

### Off best figure: h5-opp-8766b98-p1

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| HOLDER ASSIGNMENT | rule | - | 1.23 | 15.9 |
| CHARGE NOW FIRST | rule | 0.23 | 0.69 | 107.5 |
| PATHS CROSS | rule | 0.85 | 0.08 | 33.4 |
| CHARGE NOT DECLARED | rule | 0.31 | 0.31 | 138.6 |
| CANNON PLANNED TARGET | rule | 0.31 | 0.15 | 59.0 |
| JOB FIRST | gate | 0.08 | 0.38 | 20.6 |
| BEST PRIZE | rule | 0.15 | 0.15 | 91.7 |
| AFTERMATH BAND | gate | 0.08 | 0.15 | 2.9 |
| SUPPORT NARROWED | rule | 0.15 | 0.08 | 18.8 |
| NO REASON | gate | - | 0.15 | 33.3 |
| PIVOT GUARDS FLANK | rule | 0.08 | 0.08 | 9.1 |
| WAR ENGINE JOBS | rule | 0.08 | 0.08 | 63.0 |
| CARRIES OUT SET-UP | rule | - | 0.08 | 20.1 |
| CHAFF PASSED | rule | 0.08 | - | 2.1 |
| FALLBACK | gate | 0.08 | - | 8.4 |
| FIGHT ORDER BAND | gate | - | 0.08 | 1.3 |
| FRIENDS SHOTS CHECKED | rule | 0.08 | - | 3.1 |
| RESERVE FALL BACK | rule | - | 0.08 | 33.1 |
| RULE SWITCHED OFF | gate | 0.08 | - | 11.1 |
| TURN GATE | gate | 0.08 | - | 37.8 |

### Plans: h5-opp-8766b98-p1

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.5 | 63% | 173 | 114 | 66% |
| Mine | join | 0.4 | 100% | 13 | 0 | 0% |
| Mine | move | 27.5 | 95% | 1396 | 0 | 0% |
| Mine | shoot | 12.2 | 64% | 559 | 1156 | 207% |
| Mine | support | 0.2 | 50% | 1 | 0 | 0% |
| Opponent | charge | 3.1 | 72% | 532 | 321 | 60% |
| Opponent | join | 0.3 | 100% | 17 | 0 | 0% |
| Opponent | move | 32.4 | 94% | 1543 | 0 | 0% |
| Opponent | shoot | 6.6 | 59% | 165 | 448 | 272% |
| Opponent | support | 0.3 | 100% | 11 | 0 | 0% |

### Packages: hunt the guns, h5-opp-8766b98-p1

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.1 | 1 | 0 | 0% | 0% | 0% | - | 467 | 0 | 0% | 36 |
| Opponent | 0.1 | 1 | 0 | 100% | 100% | 0% | 2.0 | 505 | 429 | 100% | 149 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 93 |
| Dwarfen Mountain Holds | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 467 | 0 | 0% | 25 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 330 |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Ogre Kingdoms | 1.0 | 1 | 0 | 100% | 100% | 0% | 2.0 | 505 | 429 | 100% | 453 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 145 |
| Tomb Kings of Khemri | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Vampire Counts | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 75 |
| Warriors of Chaos | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 479 |

### Battle groups: h5-opp-8766b98-p1

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 1.6 | 48% | 50% | 10% | 100% | 11% | 0% | 0% | 56% | 33% |
| Opponent | REDIRECT COUNTER | 1.5 | 11% | 100% | 0% | - | 50% | 0% | 0% | 50% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: h5-opp-8766b98-p1

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 1 | 226 (1) | 226 | 0 | 0 | 0% | 5.0 | - | 226 (1) | - | - | 226 (1) |
| Mine | Chaff | 9 | 45 (9) | 9 | 36 | 60 | 44% | 2.8 | 80 (1) | 49 (6) | 0 (2) | 49 (6) | 34 (3) |
| Mine | Character | 51 | 27 (51) | 27 | 0 | 18 | 14% | 2.9 | 14 (8) | 14 (29) | 55 (13) | 18 (31) | 40 (19) |
| Mine | Clean-up | 9 | 81 (9) | 0 | 81 | 0 | 56% | 3.8 | 0 (2) | 147 (4) | 0 (3) | 89 (6) | 71 (3) |
| Mine | Fast | 3 | 0 (3) | 0 | 0 | 67 | 0% | 1.0 | - | 0 (1) | 0 (2) | 0 (2) | 0 (1) |
| Mine | Fast Hammer | 11 | 81 (11) | 62 | 20 | 47 | 27% | 4.1 | 398 (1) | 35 (6) | 0 (4) | 140 (5) | 0 (6) |
| Mine | Hammer | 26 | 49 (26) | 23 | 26 | 28 | 23% | 2.8 | 19 (5) | 87 (12) | 14 (9) | 58 (14) | 38 (12) |
| Mine | Holder | 12 | 55 (12) | 0 | 55 | 22 | 58% | 4.2 | 0 (1) | 65 (8) | 45 (3) | 51 (6) | 60 (6) |
| Mine | Shooter | 11 | 120 (11) | 32 | 88 | 27 | 0% | 2.5 | 37 (4) | 190 (5) | 65 (2) | 125 (9) | 78 (2) |
| Mine | War machine | 33 | 52 (33) | 52 | 0 | 54 | 6% | 1.4 | 55 (8) | 65 (16) | 28 (9) | 26 (6) | 58 (27) |
| Mine | Wizard | 7 | 0 (7) | 0 | 0 | 18 | 29% | 1.8 | 0 (2) | 0 (1) | 0 (3) | 0 (3) | 0 (3) |
| Opponent | Chaff | 22 | 125 (22) | 28 | 97 | 44 | 41% | 3.1 | 104 (10) | 245 (5) | 73 (7) | 182 (12) | 67 (10) |
| Opponent | Character | 34 | 39 (34) | 39 | 0 | 33 | 35% | 2.4 | 33 (9) | 42 (16) | 54 (6) | 54 (17) | 25 (14) |
| Opponent | Clean-up | 12 | 100 (12) | 26 | 74 | 3 | 75% | 5.0 | 32 (5) | 157 (6) | 156 (1) | 148 (9) | 0 (3) |
| Opponent | Early | 1 | 0 (1) | 0 | 0 | 0 | 0% | 4.0 | - | 0 (1) | - | - | 0 (1) |
| Opponent | Fast | 1 | 0 (1) | 0 | 0 | 0 | 0% | 1.0 | - | 0 (1) | - | 0 (1) | - |
| Opponent | Fast Hammer | 10 | 25 (10) | 15 | 10 | 33 | 40% | 2.3 | 51 (2) | 25 (4) | 9 (4) | 67 (3) | 12 (7) |
| Opponent | Fragile | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | - | 0 (1) | 0 (1) | - |
| Opponent | Hammer | 23 | 11 (23) | 7 | 4 | 41 | 26% | 2.2 | 0 (4) | 10 (16) | 26 (3) | 8 (10) | 13 (13) |
| Opponent | Holder | 16 | 118 (16) | 6 | 112 | 7 | 69% | 3.0 | 114 (5) | 114 (8) | 138 (3) | 117 (8) | 120 (8) |
| Opponent | Shooter | 13 | 39 (13) | 16 | 23 | 46 | 15% | 2.1 | 0 (3) | 59 (7) | 0 (3) | 58 (7) | 10 (6) |
| Opponent | War machine | 14 | 28 (14) | 28 | 0 | 59 | 14% | 1.5 | 123 (3) | 0 (3) | 12 (8) | 106 (4) | 5 (10) |
| Opponent | Wizard | 7 | 28 (7) | 28 | 0 | 54 | 29% | 2.4 | 57 (3) | 0 (1) | - | 99 (2) | 0 (2) |

### Charged fights: h5-opp-8766b98-p1

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 132 | 30 | 1.0 | 1.8 | 30 | 56 | -26 | 2 of 4 | 3 of 4 | +34 | -85 |
| Mine | Chaos Dwarfs | 4 | 192 | 389 | 2.8 | 1.0 | 141 | 6 | +136 | 6 of 11 | 9 of 11 | - | +136 |
| Mine | Dwarfen Mountain Holds | 4 | 513 | 28 | 1.8 | 1.3 | 16 | 0 | +16 | 1 of 7 | 5 of 7 | +0 | +19 |
| Mine | Empire of Man | 1 | 453 | 980 | 3.0 | 1.0 | 327 | 37 | +290 | 1 of 3 | 2 of 3 | - | +290 |
| **Mine** | all armies | 13 | 293 | 213 | 1.9 | 1.2 | 111 | 16 | +95 | 10 of 25 | 19 of 25 | +23 | +105 |
| Opponent | Chaos Dwarfs | 3 | 74 | 366 | 2.7 | 1.1 | 137 | 39 | +98 | 6 of 8 | 6 of 8 | +364 | +60 |
| Opponent | Dwarfen Mountain Holds | 1 | 339 | 189 | 2.0 | 1.5 | 94 | 0 | +94 | 0 of 2 | 2 of 2 | +189 | +0 |
| Opponent | Grand Cathay | 1 | 65 | 829 | 5.0 | 1.2 | 166 | 0 | +166 | 2 of 5 | 4 of 5 | +289 | +135 |
| Opponent | High Elf Realms | 1 | 418 | 571 | 4.0 | 1.2 | 143 | 0 | +143 | 1 of 4 | 4 of 4 | +246 | +108 |
| Opponent | Ogre Kingdoms | 1 | 189 | 125 | 2.0 | 1.0 | 62 | 0 | +62 | 1 of 2 | 1 of 2 | - | +62 |
| Opponent | Orc & Goblin Tribes | 1 | 0 | 0 | 2.0 | 1.0 | 0 | 28 | -28 | 0 of 2 | 1 of 2 | - | -28 |
| Opponent | Skaven | 2 | 0 | 55 | 1.0 | 1.0 | 55 | 0 | +55 | 1 of 2 | 1 of 2 | - | +55 |
| Opponent | Tomb Kings of Khemri | 1 | 0 | 310 | 2.0 | 1.0 | 155 | 0 | +155 | 2 of 2 | 2 of 2 | - | +155 |
| Opponent | Vampire Counts | 1 | 0 | 255 | 4.0 | 1.0 | 64 | 0 | +64 | 1 of 4 | 3 of 4 | - | +64 |
| Opponent | Warriors of Chaos | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| **Opponent** | all armies | 13 | 95 | 268 | 2.4 | 1.1 | 112 | 12 | +101 | 14 of 31 | 24 of 31 | +272 | +75 |

### Effective charges: h5-opp-8766b98-p1

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 1 (net -52) | 0 | 1 (net +120) | 1 (net +0) | 0 | 0 | 1 | 33% (1 of 3) |
| Mine | Chaos Dwarfs | 11 | 0 | 0 | 2 (net +432) | 4 (net +32) | 0 | 3 (net +70) | 2 | 22% (2 of 9) |
| Mine | Dwarfen Mountain Holds | 7 | 2 (net +0) | 0 | 1 (net +0) | 0 | 0 | 3 (net +38) | 1 | 17% (1 of 6) |
| Mine | Empire of Man | 3 | 1 (net +752) | 0 | 0 | 0 | 0 | 2 (net +59) | 0 | 0% (0 of 3) |
| Opponent | Chaos Dwarfs | 8 | 2 (net +167) | 0 | 0 | 1 (net -310) | 2 (net +84) | 2 (net +297) | 1 | 0% (0 of 7) |
| Opponent | Dwarfen Mountain Holds | 2 | 0 | 0 | 0 | 1 (net +0) | 0 | 1 (net +189) | 0 | 0% (0 of 2) |
| Opponent | Grand Cathay | 5 | 1 (net +138) | 0 | 1 (net +190) | 2 (net +106) | 0 | 1 (net +289) | 0 | 20% (1 of 5) |
| Opponent | High Elf Realms | 4 | 0 | 0 | 0 | 0 | 0 | 4 (net +143) | 0 | 0% (0 of 4) |
| Opponent | Ogre Kingdoms | 2 | 1 (net +125) | 0 | 0 | 0 | 0 | 0 | 1 | 0% (0 of 1) |
| Opponent | Skaven | 2 | 1 (net +0) | 0 | 0 | 0 | 0 | 1 (net +110) | 0 | 0% (0 of 2) |
| Opponent | Tomb Kings of Khemri | 2 | 0 | 0 | 0 | 0 | 0 | 2 (net +155) | 0 | 0% (0 of 2) |
| Opponent | Vampire Counts | 4 | 2 (net +32) | 0 | 1 (net +95) | 0 | 1 (net +95) | 0 | 0 | 25% (1 of 4) |

### Charged fights, damage counted: h5-opp-8766b98-p1

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 4 | 118 | 300 | +175 | 315 | 62 | +253 | +215.2 |
| Mine | Effective (55-75%) | 4 | 279 | 230 | +246 | 268 | 11 | +257 | +92.3 |
| Mine | 76-89% | 5 | 256 | 188 | +26 | 88 | 90 | -2 | -0.9 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 8 | 125 | 102 | +55 | 75 | 36 | +39 | +31.3 |
| Mine | No odds | 4 | 285 | 202 | +29 | 115 | 42 | +73 | +25.5 |
| Mine | All fights | 25 | 200 | 187 | +95 | 153 | 48 | +105 | +52.6 |
| Opponent | Long shot (under 50%) | 7 | 250 | 225 | +95 | 96 | 0 | +96 | +38.4 |
| Opponent | Effective (55-75%) | 2 | 342 | 95 | +142 | 142 | 0 | +142 | +41.6 |
| Opponent | 76-89% | 4 | 257 | 149 | -24 | 80 | 125 | -45 | -17.7 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 11 | 362 | 212 | +188 | 188 | 12 | +175 | +48.5 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 3 | 433 | 88 | +88 | 88 | 0 | +88 | +20.3 |
| Opponent | No odds | 4 | 244 | 187 | -14 | 33 | 43 | -10 | -4.1 |
| Opponent | All fights | 31 | 313 | 184 | +101 | 120 | 26 | +94 | +30.1 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| h5-opp-8766b98-p1 | move | 97 | 20 (21%) | 15 (15%) | 11 (11%) | 66 (68%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0103, L0120 |
| Charmed Shield | Opponent | L0525 |
| Elixir of Power | Opponent | L0219 |
| Fistful of Laurels | Opponent | L0718 |
| Invocation of Nehek | Opponent | L0525 |
| Periapt of Soul Exchange | Opponent | L0120, L0321 |
| Ring of Doom | Mine | L0204, L0219 |
| Ring of Jet | Opponent | L0510 |
| Standard of the Fell Warrior | Opponent | L0613 |
| Storm Daemon (Renegade 2.0) | Opponent | L0321 |
| Twice-Blessed Armour | Mine | L0718 |
| Twice-Blessed Armour | Opponent | L0510 |
| Witch Hunter's Ward | Mine | L0718 |

# Doctrine scorecard: h5-opp-8766b98-p2

### Scorecard: h5-opp-8766b98-p2

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0108 | 6 | 1 | Mine | no | 3 | - | 0 | 2 | 0 | 0 | 0 | 0 |
| L0108 | 6 | 1 | Opponent | no | 2 | 5 | 1 | 1 | 0 | 0 | 0 | 0 |
| L0123 | 3 | 1 | Mine | yes | 4 | 5 | 1 | 1 | 0 | 0 | 0 | 0 |
| L0123 | 3 | 1 | Opponent | yes | 5 | 2 | 5 | 1 | 1 | 0 | 0 | 0 |
| L0207 | 3 | 1 | Mine | no | 7 | - | 2 | 4 | 0 | 0 | 0 | 170 |
| L0207 | 3 | 1 | Opponent | no | 4 | 4 | 2 | 0 | 0 | 0 | 0 | 125 |
| L0224 | 2 | 1 | Mine | - | - | 1 | 3 | 2 | 0 | 0 | 0 | 251 |
| L0224 | 2 | 1 | Opponent | - | - | 4 | 3 | 1 | 0 | 0 | 0 | 0 |
| L0308 | 2 | 1 | Mine | - | - | - | 0 | 3 | 0 | 0 | 0 | 110 |
| L0308 | 2 | 1 | Opponent | - | - | - | 0 | 3 | 0 | 0 | 0 | 470 |
| L0325 | 1 | 1 | Mine | no | 0 | 2 | 1 | 0 | 0 | 0 | 0 | 0 |
| L0325 | 1 | 1 | Opponent | no | 2 | 4 | 0 | 2 | 0 | 0 | 0 | 0 |
| L0411 | 3 | 1 | Mine | no | 0 | 2 | 2 | 2 | 0 | 0 | 0 | 0 |
| L0411 | 3 | 1 | Opponent | no | 2 | - | 0 | 1 | 1 | 0 | 0 | 330 |
| L0427 | 1 | 1 | Mine | no | 0 | 3 | 3 | 0 | 0 | 0 | 0 | 0 |
| L0427 | 1 | 1 | Opponent | no | 1 | 1 | 1 | 3 | 1 | 0 | 0 | 0 |
| L0513 | 3 | 1 | Mine | no | 10 | - | 0 | 1 | 0 | 0 | 0 | 328 |
| L0513 | 3 | 1 | Opponent | yes | 10 | 4 | 1 | 0 | 1 | 0 | 0 | 177 |
| L0530 | 2 | 1 | Mine | - | - | - | 1 | 1 | 0 | 0 | 0 | 95 |
| L0530 | 2 | 1 | Opponent | - | - | 2 | 1 | 3 | 0 | 0 | 0 | 0 |
| L0618 | 6 | 1 | Mine | no | 2 | - | 0 | 4 | 0 | 0 | 0 | 400 |
| L0618 | 6 | 1 | Opponent | no | 3 | - | 0 | 3 | 0 | 0 | 0 | 0 |
| L0633 | 3 | 1 | Mine | yes | 4 | - | 1 | 1 | 0 | 0 | 0 | 385 |
| L0633 | 3 | 1 | Opponent | no | 0 | 2 | 1 | 3 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 22% | 3.3 | 2.6 | 1.2 | 1.8 | 0.0 | 0.0 | 0.0 | 144.9 |
| **Average** | | | Opponent | 22% | 3.2 | 3.1 | 1.2 | 1.8 | 0.3 | 0.0 | 0.0 | 91.8 |

### KPIs: h5-opp-8766b98-p2

Rules off - Mine only: HOLDER ASSIGNMENT, QUARTER ODDS.

Morten 2026-11-10; 12 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 50% (25 of 50) | 20% (12 of 60) | 34% (37 of 110) |
| Winner chose to follow up after the loser gave ground |  | 71% (10 of 14); on the table 71% | 85% (11 of 13); on the table 100% | 78% (21 of 27); on the table 85% |
| Winner chose to pursue after the loser fell back in good order |  | 100% (4 of 4); on the table 100% | 100% (1 of 1); on the table 100% | 100% (5 of 5); on the table 100% |
| Winner chose to pursue after the loser fled |  | 0% (0 of 1); on the table 0% | 87% (13 of 15); on the table 87% | 81% (13 of 16); on the table 81% |
| Winner chose to follow up or pursue (all three) |  | 74% (14 of 19); on the table 74% | 86% (25 of 29); on the table 93% | 81% (39 of 48); on the table 85% |
| Magic missiles tried each own turn | 50%+ | 31% (43 of 138) | 33% (16 of 48) | 32% (59 of 186) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 36% (43 of 121) | 42% (16 of 38) | 37% (59 of 159) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 40% (4 of 10) | - | 40% (4 of 10) |
| Points that never fought | lower | 55% (13024 of 23594) | 56% (13377 of 23995) | 55% (26401 of 47589) |
|   infantry points that never fought | lower | 61% (4487 of 7332) | 72% (3072 of 4287) | 65% (7559 of 11619) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 61% (54 of 88) | 61% (57 of 93) | 61% (111 of 181) |
| Bound items with a magic missile used (at least once a game) |  | 100% (6 of 6); 1.2 uses a game | 83% (5 of 6); 1.5 uses a game | 92% (11 of 12); 1.4 uses a game |
| Bound items with another spell used |  | 100% (2 of 2); 0.8 uses a game | 33% (1 of 3); 0.2 uses a game | 60% (3 of 5); 0.5 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 62% (5 of 8); 0.4 uses a game | 33% (2 of 6); 0.2 uses a game | 50% (7 of 14); 0.3 uses a game |
|   their share of the points of units over 100 pts | lower | 56% (10023 of 17752) | 58% (12090 of 20774) | 57% (22113 of 38526) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 3.8 (47%) | 1.0 (38%) | 4.8 (45%) |
| MARCHED: its unit marched | 2.8 (35%) | 0.7 (25%) | 3.4 (32%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.2 (6%) | 0.2 (2%) |
| IN COMBAT: engaged in combat | 1.1 (14%) | 0.4 (16%) | 1.5 (14%) |
| GONE: slain | 0.3 (4%) | 0.4 (16%) | 0.8 (7%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.1 | 0.9 | 2.9 | 4.9 | 0.8 | 1.3 |
| not cast | 3.4 | 1.9 | 4.6 | 10.6 | 1.2 | 20.7 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.9 (9%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.1 (2%) | 1.6 (83%) | 0.5 (11%) | 4.8 (45%) | 0.8 (60%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 3.4 (32%) | 0.1 (7%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (2%) | 0.1 (7%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.3 (10%) | 0.3 (17%) | 0.8 (18%) | 1.5 (14%) | 0.2 (20%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (0%) |
| GONE: slain | 0.8 (24%) | 0.0 (0%) | 0.4 (9%) | 0.8 (7%) | 0.0 (0%) | 1.0 (5%) |
| STUPIDITY: Stupidity | 0.1 (2%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (7%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.1 (61%) | 0.0 (0%) | 2.8 (62%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 17.7 (85%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 2.7 a game | 1.0 a game | 1.8 a game |
| stood (cast and not dispelled) | 69% (22 of 32) | 67% (8 of 12) | 68% (30 of 44) |
| the unit moved after it | 64% (14 of 22) | 38% (3 of 8) | 57% (17 of 30) |
| it charged on its next turn | 0% (0 of 22) | 0% (0 of 8) | 0% (0 of 30) |
| the enemy charged it first | 23% (5 of 22) | 0% (0 of 8) | 17% (5 of 30) |
| it fought by the end of its next turn | 14% (3 of 22) | 0% (0 of 8) | 10% (3 of 30) |
| it moved out of a charge the enemy had planned (not charged first) | 14% (3 of 22) | 0% (0 of 8) | 10% (3 of 30) |
| none of these (no charge, no fight, no charge escaped) | 64% (14 of 22) | 100% (8 of 8) | 73% (22 of 30) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 60% (218 of 366) | 52% (142 of 271) | 57% (360 of 637) |
|   cavalry | 46% (12 of 26) | 65% (26 of 40) | 58% (38 of 66) |
|   character | 71% (24 of 34) | 42% (11 of 26) | 58% (35 of 60) |
|   chariot | 48% (23 of 48) | 63% (19 of 30) | 54% (42 of 78) |
|   infantry | 49% (42 of 86) | 49% (39 of 79) | 49% (81 of 165) |
|   monster | 42% (5 of 12) | 88% (7 of 8) | 60% (12 of 20) |
|   war machine | 70% (112 of 160) | 45% (40 of 88) | 61% (152 of 248) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 4.0 (32%) | 3.0 (28%) | 7.0 (30%) |
| CHARGED: it charged | 0.5 (4%) | 0.8 (7%) | 1.2 (5%) |
| FLEEING: it fled or was fleeing | 0.0 (0%) | 0.1 (1%) | 0.1 (0%) |
| IN COMBAT: it fought this turn or the last | 0.2 (2%) | 0.2 (2%) | 0.5 (2%) |
| MOVED: a war machine that moved | 1.1 (9%) | 1.7 (16%) | 2.8 (12%) |
| NO TARGET IN RANGE | 3.6 (29%) | 1.4 (13%) | 5.0 (22%) |
| ONLY IN COMBAT: the only targets were in combat | 0.5 (4%) | 0.1 (1%) | 0.6 (3%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.8 (14%) | 2.3 (22%) | 4.1 (18%) |
| SHELTERED: the target was sheltered | 0.2 (1%) | 0.2 (2%) | 0.4 (2%) |
| OTHER BAR | 0.5 (4%) | 0.9 (9%) | 1.4 (6%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 4.2 | 2.2 | 66% | 6.2 pts | 26 pts |
| character | 2.9 | 2.3 | 57% | 13.9 pts | 40 pts |
| chariot | 3.5 | 3.2 | 60% | 22.0 pts | 77 pts |
| infantry | 11.0 | 4.2 | 70% | 7.0 pts | 77 pts |
| monster | 1.0 | 0.4 | 75% | 5.3 pts | 5 pts |
| war machine | 12.7 | 11.8 | 64% | 18.0 pts | 228 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 2.0 | 3.6 | 2.8 |
| Charges that made contact a game | 1.7 | 2.5 | 2.1 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.33 declared, 0.33 contact (6 units) | 0.50 declared, 0.00 contact (4 units) | 0.40 declared, 0.20 contact (10 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 0.75 declared, 0.50 contact (4 units) | 0.75 declared, 0.50 contact (4 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.26 declared, 0.21 contact (84 units) | 0.43 declared, 0.32 contact (88 units) | 0.35 declared, 0.27 contact (172 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 40% (6 of 15) | 33% (2 of 6) | 100% (2 of 2) | 43% (10 of 23) |
| Character in a unit | 83% (19 of 23) | 77% (10 of 13) | 0% (0 of 1) | 78% (29 of 37) |
| Character on its own | 88% (7 of 8) | 78% (7 of 9) | 45% (5 of 11) | 68% (19 of 28) |
| Chariot | 67% (2 of 3) | 70% (7 of 10) | - | 69% (9 of 13) |
| Infantry | 28% (5 of 18) | 35% (7 of 20) | 0% (0 of 2) | 30% (12 of 40) |
| Monster | 67% (4 of 6) | 50% (1 of 2) | - | 62% (5 of 8) |
| Monstrous | 100% (1 of 1) | 100% (2 of 2) | - | 100% (3 of 3) |
| War Machines | 85% (23 of 27) | 50% (1 of 2) | - | 83% (24 of 29) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 80% (8 of 10); on the table 80% | 29% (30 of 102) | 24% | 41% (9 of 22) | 100% (6 of 6); 3.8 uses a game | 100% (2 of 2); 2.2 uses a game | 83% (5 of 6); 1.2 uses a game |
| Chaos Dwarfs | 4 | 71% (5 of 7); on the table 71% | 36% (13 of 36) | 68% | 72% (23 of 32) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |
| Dwarfen Mountain Holds | 4 | 50% (1 of 2); on the table 50% | - | 72% | 65% (22 of 34) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 3 | - | 33% (4 of 12) | 78% | 57% (17 of 30) | 0.0 uses a game | 100% (1 of 1); 0.7 uses a game | 33% (1 of 3); 0.3 uses a game |
| Grand Cathay | 1 | - | 42% (5 of 12) | 53% | 88% (7 of 8) | 100% (2 of 2); 4.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| High Elf Realms | 1 | 100% (1 of 1); on the table 100% | 0% (0 of 6) | 71% | 25% (2 of 8) | 100% (1 of 1); 5.0 uses a game | 0% (0 of 2); 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 1 | - | 0% (0 of 6) | 98% | 71% (5 of 7) | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Tomb Kings of Khemri | 1 | 100% (2 of 2); on the table 100% | - | 23% | 80% (4 of 5) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 3 | 80% (16 of 20); on the table 90% | 58% (7 of 12) | 36% | 63% (12 of 19) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 1 | 100% (2 of 2); on the table 100% | - | 35% | 50% (3 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Wood Elf Realms | 1 | 100% (4 of 4); on the table 100% | - | 47% | 70% (7 of 10) | 100% (2 of 2); 9.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (h5-opp-8766b98-p2, 12 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 56% (9) | 50% (7) | 53% (16) |
| ...free all their last turn and able to turn (per game) | 0.58 | 0.50 | 1.08 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.17 | 0.08 | 0.25 |
| ...with the charger already in that arc before they moved (per game) | 0.33 | 0.33 | 0.67 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.17 | 0.25 | 0.42 |

### Quality by phase: h5-opp-8766b98-p2

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.4 | 2.2 |
| Strategy | Charge objectives carried out (made contact) | 76% (16 of 21) | 55% (16 of 29) |
| Strategy | Shoot objectives carried out (shot that target) | 61% (100 of 164) | 49% (46 of 94) |
| Strategy | Support requests answered (helper made contact too) | 100% (2 of 2) | 67% (2 of 3) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (2 of 2) | - |
| Strategy | Hexes on a unit its side charged or shot that turn | - | 67% (4 of 6) |
| Strategy | Joined characters whose unit fought | 57% (21 of 37) | 25% (5 of 20) |
| Strategy | Lone characters that fought | 41% (7 of 17) | 64% (18 of 28) |
| Movement | Charges halted short of contact | 0.0 | 0.3 |
| Movement | Idle units | 1.8 | 1.8 |
| Movement | Points that never moved of their own | 144.9 | 91.8 |
| Movement | Fights charged into per game | 1.4 | 2.1 |
| Movement | Charges with odds: long shots (under 50%) | 2 of 16, net +78 | 5 of 21, net -228 |
| Movement | Charges with odds: sweet spot (55-75%) | 3 of 16, net +42 | 4 of 21, net +40 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 1 of 16, net +45 | 5 of 21, net +219 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 4 of 16, net +71 | 2 of 21, net -389 |
| Shooting | Shots by shooting units (incl. breath weapons) | 9.3 | 9.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 35% (39 of 112) | 45% (49 of 108) |
| Shooting | Points destroyed by shooting units | 59.9 | 26.9 |
| Shooting | War machine shots | 9.3 | 3.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 29% (32 of 112) | 40% (16 of 40) |
| Shooting | Points destroyed by war machines | 68.4 | 52.1 |
| Magic | Magic missiles cast | 1.8 | 1.1 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 27% (6 of 22) | 15% (2 of 13) |
| Magic | Wounds caused by magic missiles | 5.2 | 2.0 |
| Magic | Wounds caused by other spells | 0.7 | 0.3 |
| Magic | Points destroyed by magic (all spells) | 30.9 | 16.2 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.2 / 0.0 / 1.0 / 0.0 | 2.1 / 0.8 / 0.1 / 0.4 |
| Combat | Points destroyed in combat | 271.8 | 93.4 |
| Combat | Points run down | 0.0 | 125.9 |
| Combat | Net points per charged fight, damage counted | +45 | -0 |
| Combat | Net per 100 charger points, damage counted | +15.8 | -0.0 |
| Combat | First round won (charged fights) | 88% | 68% |
| Combat | Net points per charged fight | +46 | -5 |
| Combat | Net points per supported fight / lone fight | +30 / +49 | +216 / -47 |
| Combat | Charged fights on a top-3 enemy unit | 4 of 17 | 10 of 25 |
| Game | Points lost | 347.3 | 497.2 |
| Game | VP from objectives | 711.7 | 805.8 |
| Game | Lone holders (player turns) | 3.3 | 3.2 |

- Mine won / drew / lost: 5 / 3 / 4 of 12 ended games (of 12); mean margin (Mine - Opponent) +82 VP
- The side that went first won 4 of 9 games with a winner
- Points traded per game (both sides' losses): 844
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: h5-opp-8766b98-p2

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.4 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.3 | +35.5 | 0.0 | 0.0 | 0.2 | +13.6 | 0.0 | 0.0 |
| ALREADY CARRIED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARRIVAL HUNT | - | - | - | - | 0.1 | +0.2 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 2.4 | +0.0 | 0.0 | 0.0 | 0.8 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | - | - | - | - | 0.2 | +0.5 | 0.0 | 0.0 |
| BLOWS WHERE AIMED | 0.2 | -7.3 | 0.0 | 0.0 | 0.3 | -82.8 | 24.1 | 27.9 |
| BOMBING RUN | - | - | - | - | 0.1 | +1.4 | 0.0 | 0.0 |
| CANNON PLAN MISSED | 0.6 | +0.0 | 16.8 | 8.3 | 0.6 | +0.0 | 19.5 | 0.0 |
| CANNON PLANNED TARGET | 8.1 | +171.0 | 476.3 | 107.5 | 2.8 | +66.9 | 133.8 | 37.9 |
| CANNON SIGHT KEPT | 1.3 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT SET-UP | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | -2.4 | 15.8 | 0.0 |
| CAST JOB | 0.6 | +9.7 | 15.5 | 0.0 | 0.2 | +4.4 | 0.0 | 0.0 |
| CASTER AWAY FROM SCREEN | 0.8 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.2 | +16.7 | 23.4 | 0.0 | 0.1 | +2.6 | 5.0 | 0.0 |
| CASTS AFTER FRIENDS | 1.8 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 33.3 |
| CASTS FROM BEHIND | - | - | - | - | 0.4 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | 0.2 | +9.9 | 0.0 | 12.2 | 1.2 | +32.1 | 0.0 | 11.3 |
| CHAFF PASSED | 0.1 | -0.3 | 0.0 | 0.0 | 0.3 | -2.2 | 0.0 | 0.0 |
| CHARACTER GUNS | 0.6 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| CHARGE LOSSES | 6.0 | -223.5 | 0.0 | 80.5 | 5.0 | -221.4 | 0.0 | 81.8 |
| CHARGE NOT DECLARED | 0.1 | +0.0 | 5.0 | 0.0 | 0.2 | +0.0 | 37.4 | 0.0 |
| CHARGE NOW FIRST | 1.0 | +0.0 | 24.2 | 30.8 | 1.2 | +0.0 | 43.8 | 27.9 |
| CHARGER SLAIN LOST | 0.3 | -3.1 | 10.4 | 2.5 | 0.1 | -1.1 | 7.1 | 0.0 |
| CHEAPEST HOLDER | 0.2 | -13.8 | 5.0 | 0.0 | - | - | - | - |
| COMBAT PIVOT | 0.3 | +0.0 | 9.0 | 0.0 | 0.1 | +0.0 | 0.0 | 35.9 |
| CONVEYANCE SEARCH | 1.8 | +151.0 | 0.0 | 0.0 | 0.8 | +89.8 | 42.3 | 33.3 |
| COVER ONCE | 6.0 | -276.1 | 0.0 | 76.5 | 5.8 | -259.2 | 0.0 | 56.6 |
| DEPLOY BY FIGURES | 9.5 | +3.4 | 0.0 | 0.0 | 7.7 | -30.4 | 0.0 | 10.0 |
| EDGE GIVE GROUND | 0.1 | +0.1 | 13.8 | 0.0 | - | - | - | - |
| ENGINEER BY LORE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FALL BACK GOOD ORDER | 1.2 | +8.1 | 34.2 | 16.3 | 1.5 | +0.7 | 49.1 | 96.6 |
| FALLBACK BY WORTH | 0.2 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| FALLS SHORT | 8.6 | +165.3 | 0.0 | 95.5 | 16.1 | +223.3 | 0.0 | 158.3 |
| FEATURE BUFFS | 2.7 | +66.3 | 0.0 | 7.1 | 0.4 | +10.0 | 0.0 | 5.0 |
| FIGHT TO THE END | 1.0 | +21.8 | 0.0 | 39.5 | 0.9 | +17.1 | 54.8 | 45.9 |
| FIRE IN ORDER | 0.2 | +0.0 | 16.2 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| FIVE ACTION | 50.4 | +2388.1 | 647.6 | 507.7 | 48.0 | +2841.1 | 384.5 | 468.2 |
| FLANK NOT WEIGHED | 4.8 | +0.0 | 0.0 | 97.7 | 5.5 | +0.0 | 0.0 | 36.4 |
| FOLLOW UP WEIGHED | 0.5 | +123.2 | 0.0 | 25.8 | 0.2 | +31.1 | 0.0 | 0.0 |
| FOUR ROUNDS | 1.8 | +147.9 | 42.1 | 49.0 | 2.4 | +155.8 | 110.2 | 106.6 |
| FRIEND CHARGES FIRST | - | - | - | - | 0.1 | -0.1 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 0.2 | -0.5 | 0.0 | 0.0 | 0.2 | -10.8 | 0.0 | 0.0 |
| FRIENDS SHOTS CHECKED | 0.2 | +1.8 | 0.0 | 5.0 | - | - | - | - |
| GIVES UP | - | - | - | - | 0.2 | -5.4 | 39.8 | 0.0 |
| GROUND FLIERS | 0.1 | +1.0 | 0.0 | 0.0 | 0.1 | +4.4 | 0.0 | 0.0 |
| GUN FIGURES | 1.8 | +16.6 | 29.2 | 0.0 | 0.8 | +37.3 | 51.7 | 0.0 |
| GUN MASK | 0.2 | +0.8 | 0.0 | 0.0 | 1.3 | +29.5 | 0.0 | 0.0 |
| HARD STAY DROPPED | 1.8 | +0.0 | 0.0 | 0.0 | 1.4 | +0.0 | 0.0 | 19.5 |
| HE SHOOTS OR CHARGES | 2.2 | +0.0 | 0.0 | 33.8 | 2.2 | +0.0 | 0.0 | 8.2 |
| HELPER UNSEEN | 0.2 | +0.0 | 0.0 | 7.0 | - | - | - | - |
| HIS CHARGE DENIED | 0.7 | +10.6 | 17.9 | 25.8 | 0.2 | +3.7 | 0.0 | 0.0 |
| HIS CHARGE LIST | 2.1 | +0.0 | 0.0 | 35.2 | 3.2 | +0.0 | 0.0 | 9.0 |
| HIS LEGAL MOVES | 3.8 | +0.0 | 0.0 | 67.4 | 4.2 | +0.0 | 0.0 | 36.9 |
| HIS MOVE AND SHOT | 1.4 | -11.7 | 0.0 | 28.9 | 1.9 | -48.1 | 0.0 | 23.8 |
| HIS RANDOM MOVE | - | - | - | - | 2.2 | +0.0 | 0.0 | 33.4 |
| HIS SHOT LIST | 21.9 | +896.6 | 0.0 | 199.8 | 25.2 | +1394.4 | 0.0 | 197.9 |
| HIS TURN DENIED | 0.5 | +15.9 | 24.2 | 7.0 | 1.3 | +65.5 | 50.3 | 100.8 |
| HOLD ODDS | - | - | - | - | 11.9 | +0.0 | 0.0 | 0.0 |
| HOLDER ASSIGNMENT | - | - | - | - | 14.0 | +1435.2 | 0.0 | 18.7 |
| HOLDER AT DEPLOYMENT | 1.0 | +183.6 | 0.0 | 0.0 | - | - | - | - |
| HOLDS AMBUSHERS | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 1.5 | -37.2 | 42.1 | 39.5 | 2.2 | -109.3 | 110.2 | 68.0 |
| HORN WORTH | - | - | - | - | 0.1 | +2.5 | 0.0 | 0.0 |
| HUNT IN PAIRS | - | - | - | - | 0.6 | +40.0 | 0.0 | 22.1 |
| IDLE COST | 3.7 | -47.0 | 0.0 | 48.6 | 10.1 | -151.8 | 0.0 | 93.2 |
| JOINT KNOWS CHALLENGE | 0.1 | -0.4 | 0.0 | 0.0 | - | - | - | - |
| KEEP FALLS | 0.1 | +0.4 | 0.0 | 0.0 | - | - | - | - |
| KEEPS SCOUTS OR AMBUSH | 0.2 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| LANE BY FIGURES | 0.2 | +11.9 | 0.0 | 0.0 | 0.7 | +26.2 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 5.6 | +0.0 | 125.4 | 110.9 | 7.4 | +0.0 | 58.3 | 357.0 |
| LONE CHARACTER SAFE SPOT | 0.2 | +0.0 | 0.0 | 9.4 | 0.1 | +3.8 | 0.0 | 0.0 |
| LONE WIZARD KEPT IN | 0.8 | +66.3 | 0.0 | 0.0 | 0.2 | +25.3 | 0.0 | 0.0 |
| LONG SHOT | 0.1 | +0.5 | 0.0 | 0.0 | - | - | - | - |
| LOST CHARGE | 0.3 | -1.0 | 10.0 | 4.3 | - | - | - | - |
| LURE BY WHAT IT DRAWS | 0.1 | -5.4 | 0.0 | 5.4 | 0.1 | +0.0 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | - | - | - | - | 0.6 | +34.9 | 0.0 | 0.0 |
| MANOEUVRE | 1.2 | +54.4 | 0.0 | 57.0 | 1.0 | +34.0 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.3 | +0.5 | 0.0 | 0.0 | 0.2 | +0.5 | 0.0 | 0.0 |
| MARCH BY THE SUM | 0.2 | +9.4 | 0.0 | 0.0 | 0.2 | +23.7 | 0.0 | 0.0 |
| MARCH CHECK | 0.4 | +22.8 | 0.0 | 6.8 | 0.5 | +32.0 | 0.0 | 0.0 |
| MARCH OVER CASTS | 0.6 | +27.0 | 0.0 | 6.8 | 0.7 | -17.7 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 5.2 | +92.8 | 0.0 | 66.2 | 6.1 | +88.1 | 0.0 | 96.4 |
| MISSILES IN THE MOVE | 3.2 | +201.5 | 0.0 | 13.8 | 3.0 | +44.2 | 0.0 | 9.0 |
| MISSILES NEXT TURN | 3.8 | +132.9 | 0.0 | 20.6 | 4.1 | +31.4 | 0.0 | 42.3 |
| MODEL FACING | 0.8 | +106.9 | 0.0 | 20.0 | - | - | - | - |
| MOVE SPELL IN RANGE | 0.3 | +11.4 | 0.0 | 0.0 | 0.2 | +5.0 | 0.0 | 0.0 |
| MOVE SPELL OUT OF RANGE | 0.7 | -27.4 | 0.0 | 0.0 | 0.3 | -5.0 | 0.0 | 0.0 |
| MOVE SPELL SPOT | 0.9 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 33.3 |
| MOVE TO CHARGE COMPUTED | 2.5 | +294.2 | 0.0 | 9.2 | 4.1 | +365.1 | 0.0 | 40.6 |
| MOVES UNITS SPELL | 0.2 | +9.2 | 0.0 | 0.0 | - | - | - | - |
| NEARER NOT NEEDED | 4.1 | +200.7 | 0.0 | 68.7 | 6.7 | +267.0 | 0.0 | 13.7 |
| NEXT CHARGE BY LIST | 3.5 | -153.9 | 8.7 | 16.2 | 6.4 | -146.4 | 7.6 | 86.8 |
| NEXT OBJECTIVE NEARER | 7.0 | -304.0 | 38.4 | 97.4 | 0.1 | -0.7 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 1.1 | -48.2 | 20.4 | 30.8 | 1.7 | -53.6 | 58.5 | 96.6 |
| NOT TURNED | 0.2 | +0.0 | 0.0 | 7.9 | 0.2 | +20.2 | 0.0 | 0.0 |
| NOT WORTH A CAST | 0.2 | -0.1 | 0.0 | 0.0 | 0.8 | -0.4 | 0.0 | 0.0 |
| OFF BEST | 0.4 | -5.6 | 0.0 | 5.0 | 0.9 | -23.9 | 0.0 | 0.0 |
| ONE CHARGE A CHARGER | 2.7 | +0.0 | 0.0 | 65.4 | 1.8 | +0.0 | 0.0 | 7.3 |
| ONE FIGHT FORMULA | 4.2 | -72.7 | 0.0 | 30.4 | 5.7 | -116.0 | 0.0 | 24.8 |
| ONE OBJECTIVE FORMULA | 4.7 | -63.3 | 0.0 | 33.4 | 4.5 | +32.2 | 0.0 | 13.7 |
| ONE TARGET A SHOOTER | 17.8 | +520.0 | 0.0 | 95.2 | 17.8 | +551.8 | 0.0 | 139.8 |
| OPENS A LANE | - | - | - | - | 0.1 | +0.7 | 0.0 | 0.0 |
| OVERRUNS AWAY | 0.2 | +1.7 | 10.4 | 0.0 | 0.3 | +34.0 | 25.5 | 0.0 |
| PATHS CROSS | 3.7 | +82.1 | 0.0 | 13.8 | 4.4 | +181.4 | 0.0 | 8.2 |
| PLAN RESULT | 44.5 | +649.5 | 474.0 | 507.3 | 43.2 | +396.1 | 165.7 | 771.4 |
| PURSUES BIG PREY | - | - | - | - | 0.1 | -23.8 | 0.0 | 0.0 |
| QUARTER ODDS | - | - | - | - | 3.9 | +717.9 | 14.1 | 45.9 |
| RANDOM MOVE BY FIGURES | 0.8 | +49.3 | 0.0 | 0.0 | - | - | - | - |
| REDIRECT BY WHAT IT STOPS | 0.1 | -1.4 | 0.0 | 2.5 | 0.2 | -6.8 | 0.0 | 0.0 |
| REDIRECT COUNTER | 2.1 | +151.1 | 0.0 | 54.5 | 3.0 | +94.3 | 0.0 | 36.8 |
| REDIRECT WEIGHED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| REFORMS TO MEET IT | 0.3 | -13.5 | 0.0 | 0.0 | 0.9 | -12.6 | 0.0 | 7.8 |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | 0.6 | +42.1 | 0.0 | 0.0 | 0.8 | +38.1 | 0.0 | 14.5 |
| RISK BY ARC | 1.2 | +33.5 | 20.4 | 18.8 | 1.4 | +50.2 | 70.7 | 11.7 |
| RISK BY HIS FIGURE | 12.8 | -187.9 | 0.0 | 173.8 | 11.0 | -101.8 | 0.0 | 73.5 |
| RUN DOWN | 0.7 | -5.6 | 24.2 | 5.0 | 1.8 | -11.1 | 70.3 | 60.7 |
| SAME CHARGE LATER | 0.1 | -6.7 | 15.5 | 0.0 | 0.1 | -0.4 | 0.0 | 0.0 |
| SCOUT SPOT | 0.2 | +0.6 | 0.0 | 0.0 | 0.5 | +0.4 | 0.0 | 0.0 |
| SCOUT WAITS | 0.2 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 0.2 | -14.8 | 0.0 | 3.0 |
| SEARCH SPOT | 5.8 | +227.7 | 0.0 | 26.9 | 6.2 | +372.2 | 0.0 | 26.6 |
| SET UP TOGETHER | 0.2 | +1.2 | 0.0 | 0.0 | 0.6 | +34.9 | 0.0 | 0.0 |
| SET-UP ANY TARGET | - | - | - | - | 0.2 | +16.2 | 0.0 | 0.0 |
| SET-UP MISSED | 0.1 | +9.5 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | 0.7 | +1.3 | 0.0 | 0.0 | - | - | - | - |
| SHOOTS FROM THE BEST SPOT | 1.2 | +42.6 | 44.8 | 25.8 | 1.3 | +27.6 | 42.7 | 0.0 |
| SHORT GUN FORWARD | 0.5 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| SHOT OR CHARGE | 0.2 | -0.7 | 3.8 | 0.0 | 0.3 | -9.8 | 5.4 | 0.0 |
| SHOT RISK POINTS | 11.7 | +113.8 | 0.0 | 172.5 | 14.3 | +200.3 | 0.0 | 192.6 |
| SHOTS IN THE MOVE | 17.2 | +593.9 | 0.0 | 178.2 | 15.2 | +474.8 | 0.0 | 131.5 |
| SPELL SETS UP CHARGE | 0.2 | +43.2 | 0.0 | 0.0 | 0.2 | +16.2 | 0.0 | 0.0 |
| SPELL WORTH | 0.6 | +6.6 | 5.4 | 0.0 | 2.2 | +33.4 | 106.5 | 97.5 |
| SPELLS IN THE FIGHT | 0.3 | -1.0 | 4.2 | 0.0 | 0.1 | +0.3 | 7.0 | 0.0 |
| STAND AND SHOOT | 0.1 | -1.4 | 0.0 | 0.0 | 0.4 | -3.9 | 10.4 | 0.0 |
| STANDS FOR A REASON | 0.2 | +0.0 | 16.8 | 0.0 | 0.5 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 23.9 | +0.0 | 605.5 | 204.1 | 15.2 | +0.0 | 274.2 | 89.5 |
| STAY WORTH | 22.9 | +62.5 | 406.8 | 160.2 | 17.2 | +109.7 | 194.5 | 164.6 |
| SUPPORT NARROWED | 0.6 | +0.0 | 0.0 | 9.3 | 0.8 | +0.0 | 16.9 | 19.5 |
| SURE REACH TOGETHER | 0.4 | +5.9 | 0.0 | 0.0 | 0.5 | +8.8 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 3.8 | +0.0 | 0.0 | 13.8 | 4.8 | +0.0 | 0.0 | 8.2 |
| THE PROMISE ADDS | - | - | - | - | 0.1 | -1.4 | 0.0 | 0.0 |
| THE PROMISED MOVE | 0.2 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| TIED UP BY THE SUM | 0.2 | +11.4 | 13.8 | 0.0 | 0.6 | +56.9 | 35.2 | 0.0 |
| TIME ON OUR SIDE | 24.4 | +354.0 | 4.4 | 243.8 | 11.3 | +206.1 | 0.0 | 87.4 |
| WAITS AGAIN | 0.9 | +0.0 | 0.0 | 7.1 | 1.2 | +0.0 | 0.0 | 23.4 |
| WAR ENGINE CHARGES | 0.2 | +7.8 | 0.0 | 0.0 | - | - | - | - |
| WAR ENGINE JOBS | 0.4 | +0.0 | 0.0 | 5.4 | - | - | - | - |
| WHO HITS BACK | - | - | - | - | 0.2 | +28.5 | 0.0 | 0.0 |
| WHOLE FIGHT | - | - | - | - | 0.1 | +5.2 | 15.8 | 0.0 |
| WHOLE FIGHT GAIN | 0.1 | +8.4 | 0.0 | 0.0 | 0.1 | +0.4 | 0.0 | 0.0 |
| WIDER SPREAD | 1.5 | -4.7 | 42.1 | 33.3 | 1.8 | -7.0 | 96.9 | 33.8 |
| WOUNDS ON THE RANKS | 1.5 | +69.1 | 0.0 | 24.1 | 1.5 | +79.5 | 0.0 | 0.0 |

### Rule changes: h5-opp-8766b98-p2

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS SHOT LIST | 565 | 565 | 157 | 13.08 | +4327 | +27.6 |
| LEGAL CHARGES ONLY | 156 | 156 | 156 | 13.00 | +0 | +0.0 |
| HOLDER ASSIGNMENT | 168 | 168 | 155 | 12.92 | +9765 | +63.0 |
| SEARCH SPOT | 145 | 145 | 129 | 10.75 | +7199 | +55.8 |
| DEPLOY BY FIGURES | 206 | 206 | 127 | 10.58 | +1988 | +15.7 |
| ONE TARGET A SHOOTER | 428 | 428 | 122 | 10.17 | +1527 | +12.5 |
| TIME ON OUR SIDE | 429 | 395 | 101 | 8.42 | +415 | +4.1 |
| PATHS CROSS | 97 | 97 | 97 | 8.08 | +3162 | +32.6 |
| SHOT RISK POINTS | 312 | 312 | 65 | 5.42 | +2597 | +39.9 |
| FIVE ACTION | 1181 | 1180 | 49 | 4.08 | +1735 | +35.4 |
| MOVE TO CHARGE COMPUTED | 79 | 79 | 40 | 3.33 | +2385 | +59.6 |
| ARTILLERY RE-ROLL WEIGHED | 38 | 38 | 38 | 3.17 | +0 | +0.0 |
| HARD STAY DROPPED | 38 | 38 | 38 | 3.17 | +0 | +0.0 |
| MAX FOR POSITIONING | 136 | 133 | 30 | 2.50 | +131 | +4.4 |
| COVER ONCE | 141 | 116 | 27 | 2.25 | +286 | +10.6 |
| CANNON PLANNED TARGET | 131 | 131 | 25 | 2.08 | -232 | -9.3 |
| FOUR ROUNDS | 50 | 49 | 25 | 2.08 | +1272 | +50.9 |
| FALLS SHORT | 296 | 251 | 22 | 1.83 | +176 | +8.0 |
| NEXT OBJECTIVE NEARER | 85 | 85 | 20 | 1.67 | +287 | +14.4 |
| CANNON SIGHT KEPT | 19 | 19 | 19 | 1.58 | +0 | +0.0 |
| SHOOTS FROM THE BEST SPOT | 31 | 31 | 19 | 1.58 | +238 | +12.6 |
| SHOTS IN THE MOVE | 390 | 359 | 18 | 1.50 | +421 | +23.4 |
| RESERVE FALL BACK | 17 | 17 | 17 | 1.42 | +963 | +56.7 |
| IDLE COST | 165 | 137 | 16 | 1.33 | +93 | +5.8 |
| OFF BEST | 16 | 16 | 16 | 1.33 | -354 | -22.1 |
| CHARGE LOSSES | 132 | 132 | 15 | 1.25 | +1038 | +69.2 |
| MISSILES IN THE MOVE | 75 | 57 | 15 | 1.25 | +448 | +29.9 |
| ADVANCE LANE KEPT | 13 | 13 | 13 | 1.08 | +0 | +0.0 |
| LONE WIZARD KEPT IN | 13 | 13 | 13 | 1.08 | +1099 | +84.5 |
| QUARTER ODDS | 47 | 47 | 13 | 1.08 | +2217 | +170.5 |
| RISK BY HIS FIGURE | 286 | 286 | 13 | 1.08 | +873 | +67.2 |
| REDIRECT COUNTER | 61 | 55 | 12 | 1.00 | +844 | +70.4 |
| RISK BY ARC | 32 | 31 | 12 | 1.00 | +356 | +29.6 |
| LANE BY FIGURES | 11 | 11 | 11 | 0.92 | +457 | +41.6 |
| MANOEUVRE | 26 | 26 | 11 | 0.92 | +1068 | +97.1 |
| CASTER AWAY FROM SCREEN | 10 | 10 | 10 | 0.83 | +0 | +0.0 |
| WOUNDS ON THE RANKS | 36 | 36 | 10 | 0.83 | +259 | +25.9 |
| CHARGE NOW FIRST | 27 | 27 | 9 | 0.75 | -499 | -55.5 |
| MODEL FACING | 9 | 9 | 9 | 0.75 | +1283 | +142.5 |
| SCOUT WAITS | 9 | 9 | 9 | 0.75 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 8 | 8 | 8 | 0.67 | +1852 | +231.5 |
| HOLDER AT DEPLOYMENT | 12 | 12 | 8 | 0.67 | +376 | +47.0 |
| HOLDS AMBUSHERS | 8 | 8 | 8 | 0.67 | +0 | +0.0 |
| NEXT CHARGE BY LIST | 119 | 119 | 8 | 0.67 | +48 | +6.0 |
| SHOOTERS IN TWO RANKS | 8 | 8 | 8 | 0.67 | +16 | +2.0 |
| SHORT GUN FORWARD | 8 | 8 | 8 | 0.67 | +0 | +0.0 |
| STAY WORTH | 482 | 455 | 8 | 0.67 | +62 | +7.8 |
| TIED UP BY THE SUM | 10 | 9 | 8 | 0.67 | +165 | +20.6 |
| ONE OBJECTIVE FORMULA | 110 | 95 | 7 | 0.58 | +339 | +48.5 |
| AFTERMATH IN POINTS | 6 | 6 | 6 | 0.50 | +589 | +98.2 |
| CHAFF IN THE MOVE | 18 | 17 | 6 | 0.50 | +37 | +6.2 |
| FEATURE BUFFS | 37 | 37 | 6 | 0.50 | +138 | +23.1 |
| MARCH CHECK | 11 | 11 | 6 | 0.50 | +75 | +12.5 |
| ONE FIGHT FORMULA | 118 | 66 | 6 | 0.50 | +22 | +3.6 |
| CASTS FROM BEHIND | 5 | 5 | 5 | 0.42 | +0 | +0.0 |
| CHAFF PASSED | 5 | 5 | 5 | 0.42 | -30 | -6.1 |
| COMBAT PIVOT | 5 | 5 | 5 | 0.42 | +0 | +0.0 |
| FIRE IN ORDER | 5 | 5 | 5 | 0.42 | +0 | +0.0 |
| MARCH BY THE SUM | 5 | 5 | 5 | 0.42 | +397 | +79.4 |
| NEARER NOT NEEDED | 129 | 125 | 5 | 0.42 | +196 | +39.3 |
| CAST JOB | 9 | 9 | 4 | 0.33 | +28 | +6.9 |
| CHARGE NOT DECLARED | 4 | 4 | 4 | 0.33 | -316 | -79.0 |
| HIS TURN DENIED | 22 | 22 | 4 | 0.33 | +168 | +42.0 |
| RANDOM MOVE BY FIGURES | 10 | 10 | 4 | 0.33 | +592 | +148.0 |
| REDIRECT WEIGHED | 4 | 4 | 4 | 0.33 | +316 | +78.9 |
| CASTING BLOCK | 3 | 3 | 3 | 0.25 | +44 | +14.6 |
| HIS MOVE AND SHOT | 40 | 40 | 3 | 0.25 | +90 | +30.1 |
| MISSILES NEXT TURN | 94 | 73 | 3 | 0.25 | +14 | +4.8 |
| OVERRUNS AWAY | 7 | 7 | 3 | 0.25 | +91 | +30.4 |
| SURE REACH TOGETHER | 11 | 11 | 3 | 0.25 | +5 | +1.7 |
| FRIENDS SHOTS CHECKED | 2 | 2 | 2 | 0.17 | +21 | +10.5 |
| HUNT IN PAIRS | 7 | 3 | 2 | 0.17 | +33 | +16.6 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.17 | +0 | +0.0 |
| MOVES UNITS SPELL | 2 | 2 | 2 | 0.17 | +110 | +55.1 |
| NO DOUBLE ROUNDS | 33 | 32 | 2 | 0.17 | +26 | +12.9 |
| WAR ENGINE JOBS | 5 | 5 | 2 | 0.17 | -28 | -13.8 |
| WHO HITS BACK | 2 | 2 | 2 | 0.17 | +293 | +146.5 |
| BOMBING RUN | 1 | 1 | 1 | 0.08 | +17 | +17.2 |
| CARRIES OUT SET-UP | 3 | 3 | 1 | 0.08 | -29 | -28.8 |
| CHARGER SLAIN LOST | 5 | 5 | 1 | 0.08 | +27 | +26.9 |
| FIGHT TO THE END | 23 | 23 | 1 | 0.08 | +30 | +30.1 |
| FRIEND SHOOTS FIRST | 5 | 5 | 1 | 0.08 | +10 | +10.2 |
| GUN MASK | 19 | 19 | 1 | 0.08 | +8 | +7.9 |
| HIS CHARGE DENIED | 10 | 10 | 1 | 0.08 | +7 | +6.7 |
| HONEST WORTH | 44 | 43 | 1 | 0.08 | +4 | +3.5 |
| HORN WORTH | 1 | 1 | 1 | 0.08 | +30 | +29.5 |
| KEEP FALLS | 1 | 1 | 1 | 0.08 | +10 | +9.7 |
| PURSUES BIG PREY | 1 | 1 | 1 | 0.08 | -286 | -285.9 |
| REFUSING RETIRES | 5 | 5 | 1 | 0.08 | -0 | -0.4 |
| SPELLS IN THE FIGHT | 5 | 5 | 1 | 0.08 | +4 | +3.9 |
| SUPPORT NARROWED | 16 | 16 | 1 | 0.08 | -5 | -5.3 |
| WHOLE FIGHT | 1 | 1 | 1 | 0.08 | +34 | +34.5 |
| ALREADY CARRIED | 4 | not checked | - | - | - | - |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| BACKUP TARGETS | 3 | 2 | 0 | 0.00 | - | - |
| BLOWS WHERE AIMED | 6 | 6 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 14 | 14 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 29 | trace | - | - | - | - |
| CHARACTER GUNS | 14 | 14 | 0 | 0.00 | - | - |
| CHEAPEST HOLDER | 2 | 2 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 32 | not checked | - | - | - | - |
| EDGE GIVE GROUND | 1 | 1 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 32 | 31 | 0 | 0.00 | - | - |
| FALLBACK BY WORTH | 5 | 5 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 123 | not checked | - | - | - | - |
| FRIEND CHARGES FIRST | 1 | 1 | 0 | 0.00 | - | - |
| GIVES UP | 2 | 2 | 0 | 0.00 | - | - |
| GROUND FLIERS | 2 | not checked | - | - | - | - |
| GUN FIGURES | 32 | not checked | - | - | - | - |
| HE SHOOTS OR CHARGES | 54 | 54 | 0 | 0.00 | - | - |
| HELPER UNSEEN | 2 | 2 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 64 | 64 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 96 | 96 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 27 | 27 | 0 | 0.00 | - | - |
| HOLD ODDS | 143 | 143 | 0 | 0.00 | - | - |
| JOINT KNOWS CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 3 | not checked | - | - | - | - |
| LONG SHOT | 1 | 1 | 0 | 0.00 | - | - |
| LOST CHARGE | 4 | 4 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 2 | 2 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 7 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 6 | trace | - | - | - | - |
| MARCH OVER CASTS | 15 | 15 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 6 | 5 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 12 | trace | - | - | - | - |
| MOVE SPELL SPOT | 13 | not checked | - | - | - | - |
| NOT TURNED | 5 | 5 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 11 | not checked | - | - | - | - |
| ONE CHARGE A CHARGER | 53 | 53 | 0 | 0.00 | - | - |
| OPENS A LANE | 1 | 1 | 0 | 0.00 | - | - |
| PLAN RESULT | 1052 | trace | - | - | - | - |
| REDIRECT BY WHAT IT STOPS | 3 | 3 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 15 | 15 | 0 | 0.00 | - | - |
| RUN DOWN | 30 | 29 | 0 | 0.00 | - | - |
| SAME CHARGE LATER | 2 | 2 | 0 | 0.00 | - | - |
| SCOUT SPOT | 8 | 8 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 3 | 3 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 9 | 7 | 0 | 0.00 | - | - |
| SET-UP ANY TARGET | 2 | not checked | - | - | - | - |
| SET-UP MISSED | 1 | trace | - | - | - | - |
| SHOT OR CHARGE | 6 | 6 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 4 | not checked | - | - | - | - |
| SPELL WORTH | 33 | not checked | - | - | - | - |
| STAND AND SHOOT | 6 | 6 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 9 | 9 | 0 | 0.00 | - | - |
| STANDS STILL | 469 | 469 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 104 | not checked | - | - | - | - |
| THE PROMISE ADDS | 1 | 1 | 0 | 0.00 | - | - |
| THE PROMISED MOVE | 10 | not checked | - | - | - | - |
| WAITS AGAIN | 25 | 25 | 0 | 0.00 | - | - |
| WAR ENGINE CHARGES | 2 | 2 | 0 | 0.00 | - | - |
| WHOLE FIGHT GAIN | 2 | 2 | 0 | 0.00 | - | - |
| WIDER SPREAD | 39 | 39 | 0 | 0.00 | - | - |

### Off best figure: h5-opp-8766b98-p2

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| PATHS CROSS | rule | 0.92 | 0.67 | 21.3 |
| HOLDER ASSIGNMENT | rule | - | 0.83 | 13.8 |
| CHARGE NOW FIRST | rule | 0.25 | 0.50 | 55.5 |
| CANNON PLANNED TARGET | rule | 0.58 | 0.08 | 42.2 |
| JOB FIRST | gate | - | 0.58 | 20.5 |
| CHARGE NOT DECLARED | rule | 0.08 | 0.25 | 79.0 |
| AFTERMATH NEEDS NEXT CHARGE | gate | - | 0.25 | 47.4 |
| CHAFF PASSED | rule | 0.08 | 0.17 | 10.1 |
| FALLBACK | gate | 0.25 | - | 11.6 |
| DEPLOY BY FIGURES | rule | - | 0.17 | 28.4 |
| AFTERMATH BAND | gate | 0.08 | - | 4.7 |
| CARRIES OUT SET-UP | rule | - | 0.08 | 28.8 |
| FRIENDS SHOTS CHECKED | rule | 0.08 | - | 4.7 |
| LONE CHARACTER SAFE SPOT | gate | 0.08 | - | 27.5 |
| PURSUES BIG PREY | rule | - | 0.08 | 285.9 |
| SUPPORT NARROWED | rule | - | 0.08 | 5.3 |
| TURN GATE | gate | - | 0.08 | 1.4 |
| WAR ENGINE JOBS | rule | 0.08 | - | 27.4 |

### Plans: h5-opp-8766b98-p2

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.5 | 50% | 153 | 83 | 54% |
| Mine | join | 0.8 | 89% | 23 | 0 | 0% |
| Mine | move | 30.9 | 95% | 1524 | 0 | 0% |
| Mine | shoot | 11.2 | 58% | 454 | 566 | 125% |
| Mine | support | 0.1 | 100% | 0 | 0 | - |
| Opponent | charge | 2.2 | 59% | 233 | 141 | 60% |
| Opponent | join | 1.1 | 100% | 38 | 0 | 0% |
| Opponent | move | 32.9 | 95% | 1775 | 0 | 0% |
| Opponent | shoot | 6.4 | 64% | 274 | 255 | 93% |
| Opponent | support | 0.5 | 67% | 32 | 0 | 0% |

### Battle groups: h5-opp-8766b98-p2

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 2.1 | 36% | 33% | 0% | - | 22% | 0% | 0% | 67% | 11% |
| Opponent | REDIRECT COUNTER | 3.0 | 11% | 75% | 0% | - | 25% | 0% | 0% | 75% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: h5-opp-8766b98-p2

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 9 | 0 (9) | 0 | 0 | 46 | 56% | 2.8 | 0 (3) | 0 (3) | 0 (3) | 0 (5) | 0 (4) |
| Mine | Character | 49 | 29 (49) | 29 | 0 | 9 | 22% | 2.9 | 9 (12) | 35 (27) | 37 (8) | 16 (12) | 35 (35) |
| Mine | Clean-up | 14 | 87 (14) | 23 | 64 | 43 | 43% | 3.4 | 120 (4) | 111 (6) | 28 (4) | 86 (9) | 89 (5) |
| Mine | Fast Hammer | 4 | 18 (4) | 18 | 0 | 75 | 75% | 1.0 | 35 (2) | 0 (2) | - | 71 (1) | 0 (3) |
| Mine | Hammer | 30 | 54 (30) | 21 | 33 | 15 | 27% | 2.8 | 53 (6) | 61 (18) | 37 (6) | 33 (10) | 62 (20) |
| Mine | Holder | 9 | 56 (9) | 0 | 56 | 49 | 67% | 4.0 | 220 (1) | 60 (5) | 0 (3) | 116 (3) | 18 (6) |
| Mine | Shooter | 14 | 108 (14) | 7 | 101 | 7 | 0% | 2.5 | 117 (3) | 91 (8) | 152 (3) | 117 (10) | 90 (4) |
| Mine | War machine | 30 | 28 (30) | 28 | 0 | 26 | 7% | 1.3 | 42 (14) | 0 (7) | 26 (9) | 0 (5) | 34 (25) |
| Mine | Wizard | 5 | 26 (5) | 26 | 0 | 18 | 40% | 3.3 | 0 (1) | 31 (4) | - | - | 26 (5) |
| Opponent | Chaff | 25 | 119 (25) | 0 | 119 | 42 | 60% | 2.8 | 78 (8) | 175 (9) | 96 (8) | 150 (19) | 44 (6) |
| Opponent | Character | 38 | 17 (38) | 17 | 0 | 27 | 32% | 2.5 | 11 (12) | 23 (19) | 0 (5) | 26 (21) | 8 (15) |
| Opponent | Clean-up | 6 | 40 (6) | 26 | 15 | 47 | 50% | 2.0 | 63 (1) | 33 (5) | - | 56 (4) | 0 (2) |
| Opponent | Early | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Fast | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Fast Hammer | 18 | 43 (18) | 28 | 15 | 36 | 28% | 3.2 | 36 (8) | 43 (9) | 115 (1) | 66 (11) | 10 (7) |
| Opponent | Hammer | 11 | 45 (11) | 18 | 27 | 18 | 45% | 1.8 | - | 59 (7) | 20 (4) | 65 (7) | 6 (4) |
| Opponent | Holder | 6 | 95 (6) | 6 | 90 | 17 | 50% | 3.3 | 76 (1) | 130 (4) | 0 (1) | - | 95 (6) |
| Opponent | Shooter | 13 | 68 (13) | 17 | 51 | 25 | 0% | 1.7 | 55 (6) | 127 (3) | 63 (4) | 97 (6) | 32 (7) |
| Opponent | Support | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | War machine | 15 | 9 (15) | 9 | 0 | 22 | 13% | 2.4 | 31 (5) | 0 (6) | 0 (4) | 0 (3) | 11 (12) |
| Opponent | Wizard | 10 | 0 (10) | 0 | 0 | 7 | 40% | 2.5 | 0 (3) | 0 (4) | 0 (2) | 0 (6) | 0 (3) |

### Charged fights: h5-opp-8766b98-p2

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 15 | 106 | 1.2 | 1.2 | 85 | 16 | +68 | 0 of 5 | 4 of 5 | -82 | +106 |
| Mine | Chaos Dwarfs | 4 | 133 | 188 | 2.2 | 1.2 | 83 | 34 | +49 | 4 of 9 | 9 of 9 | +86 | +38 |
| Mine | Dwarfen Mountain Holds | 4 | 330 | 0 | 0.8 | 1.0 | 0 | 0 | +0 | 0 of 3 | 2 of 3 | - | +0 |
| **Mine** | all armies | 12 | 159 | 98 | 1.4 | 1.2 | 69 | 23 | +46 | 4 of 17 | 15 of 17 | +30 | +49 |
| Opponent | Empire of Man | 3 | 246 | 17 | 1.0 | 1.0 | 17 | 88 | -71 | 2 of 3 | 1 of 3 | - | -71 |
| Opponent | Grand Cathay | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | High Elf Realms | 1 | 230 | 65 | 2.0 | 1.0 | 32 | 0 | +32 | 1 of 2 | 2 of 2 | - | +32 |
| Opponent | Ogre Kingdoms | 1 | 120 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Tomb Kings of Khemri | 1 | 55 | 65 | 5.0 | 1.0 | 13 | 165 | -152 | 2 of 5 | 2 of 5 | - | -152 |
| Opponent | Vampire Counts | 3 | 0 | 118 | 2.3 | 1.4 | 51 | 118 | -68 | 3 of 7 | 5 of 7 | +94 | -133 |
| Opponent | Warriors of Chaos | 1 | 0 | 962 | 3.0 | 1.3 | 321 | 0 | +321 | 1 of 3 | 3 of 3 | +677 | +142 |
| Opponent | Wood Elf Realms | 1 | 0 | 295 | 5.0 | 1.2 | 59 | 0 | +59 | 1 of 5 | 4 of 5 | +0 | +74 |
| **Opponent** | all armies | 12 | 95 | 149 | 2.1 | 1.2 | 72 | 77 | -5 | 10 of 25 | 17 of 25 | +216 | -47 |

### Effective charges: h5-opp-8766b98-p2

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 5 | 2 (net +78) | 0 | 1 (net +125) | 0 | 0 | 1 (net +60) | 1 | 25% (1 of 4) |
| Mine | Chaos Dwarfs | 9 | 0 | 0 | 1 (net +0) | 5 (net +34) | 1 (net +45) | 2 (net +112) | 0 | 11% (1 of 9) |
| Mine | Dwarfen Mountain Holds | 3 | 0 | 0 | 1 (net +0) | 1 (net +0) | 0 | 1 (net +0) | 0 | 33% (1 of 3) |
| Opponent | Empire of Man | 3 | 2 (net -132) | 0 | 0 | 1 (net +52) | 0 | 0 | 0 | 0% (0 of 3) |
| Opponent | High Elf Realms | 2 | 0 | 0 | 2 (net +32) | 0 | 0 | 0 | 0 | 100% (2 of 2) |
| Opponent | Tomb Kings of Khemri | 5 | 2 (net -413) | 0 | 0 | 2 (net +0) | 1 (net +65) | 0 | 0 | 0% (0 of 5) |
| Opponent | Vampire Counts | 7 | 1 (net -50) | 0 | 1 (net +0) | 0 | 3 (net +118) | 2 (net -389) | 0 | 14% (1 of 7) |
| Opponent | Warriors of Chaos | 3 | 0 | 0 | 1 (net +95) | 1 (net +190) | 1 (net +677) | 0 | 0 | 33% (1 of 3) |
| Opponent | Wood Elf Realms | 5 | 0 | 0 | 0 | 1 (net +0) | 0 | 0 | 4 | 0% (0 of 1) |

### Charged fights, damage counted: h5-opp-8766b98-p2

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 2 | 67 | 136 | +78 | 119 | 54 | +65 | +97.0 |
| Mine | Effective (55-75%) | 3 | 176 | 234 | +42 | 42 | 0 | +42 | +23.6 |
| Mine | 76-89% | 6 | 364 | 165 | +28 | 57 | 55 | +2 | +0.6 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 4 | 198 | 185 | +71 | 198 | 82 | +115 | +58.1 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 310 | 45 | +45 | 45 | 0 | +45 | +14.5 |
| Mine | No odds | 1 | 836 | 60 | +0 | 0 | 16 | -16 | -1.9 |
| Mine | All fights | 17 | 282 | 165 | +46 | 91 | 46 | +45 | +15.8 |
| Opponent | Long shot (under 50%) | 5 | 201 | 508 | -228 | 16 | 249 | -233 | -116.0 |
| Opponent | Effective (55-75%) | 4 | 431 | 184 | +40 | 61 | 0 | +61 | +14.1 |
| Opponent | 76-89% | 5 | 256 | 95 | +48 | 72 | 24 | +47 | +18.6 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 236 | 162 | -389 | 13 | 389 | -376 | -159.3 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 5 | 588 | 111 | +219 | 219 | 3 | +216 | +36.7 |
| Opponent | No odds | 4 | 79 | 100 | +74 | 93 | 4 | +89 | +112.2 |
| Opponent | All fights | 25 | 310 | 201 | -5 | 87 | 87 | -0 | -0.0 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| h5-opp-8766b98-p2 | move | 79 | 11 (14%) | 9 (11%) | 12 (15%) | 56 (71%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0108, L0123 |
| Charmed Shield | Opponent | L0224, L0325, L0427 |
| Elixir of Power | Opponent | L0411 |
| Fistful of Laurels | Opponent | L0618 |
| Horn of the Wild Hunt | Opponent | L0633 |
| Invocation of Nehek | Opponent | L0224, L0325, L0427 |
| Ring of Doom | Mine | L0207, L0224 |
| Ring of Doom | Opponent | L0411, L0633 |
| Ring of Jet | Opponent | L0411 |
| Standard of the Fell Warrior | Opponent | L0513 |
| Twice-Blessed Armour | Opponent | L0207 |
| Witch Hunter's Ward | Opponent | L0108, L0207, L0308 |

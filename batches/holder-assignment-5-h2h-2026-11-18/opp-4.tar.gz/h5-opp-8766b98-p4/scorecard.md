# Doctrine scorecard: h5-opp-8766b98-p4

### Scorecard: h5-opp-8766b98-p4

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0115 | 1 | 1 | Mine | no | 1 | - | 0 | 2 | 0 | 0 | 0 | 0 |
| L0115 | 1 | 1 | Opponent | yes | 14 | 2 | 5 | 2 | 1 | 0 | 0 | 0 |
| L0132 | 6 | 1 | Mine | no | 13 | 4 | 1 | 1 | 0 | 0 | 0 | 0 |
| L0132 | 6 | 1 | Opponent | no | 4 | 3 | 3 | 7 | 0 | 0 | 0 | 340 |
| **Average** | | | Mine | 0% | 7.0 | 4.0 | 0.5 | 1.5 | 0.0 | 0.0 | 0.0 | 0.0 |
| **Average** | | | Opponent | 50% | 9.0 | 2.5 | 4.0 | 4.5 | 0.5 | 0.0 | 0.0 | 170.0 |

### KPIs: h5-opp-8766b98-p4

Rules off - Mine only: HOLDER ASSIGNMENT, QUARTER ODDS.

Morten 2026-11-10; 2 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 5) | 0% (0 of 8) | 0% (0 of 13) |
| Winner chose to follow up after the loser gave ground |  | 50% (1 of 2); on the table 50% | 100% (2 of 2); on the table 100% | 75% (3 of 4); on the table 75% |
| Winner chose to pursue after the loser fell back in good order |  | - | 67% (2 of 3); on the table 67% | 67% (2 of 3); on the table 67% |
| Winner chose to pursue after the loser fled |  | 0% (0 of 1); on the table 100% | - | 0% (0 of 1); on the table 100% |
| Winner chose to follow up or pursue (all three) |  | 33% (1 of 3); on the table 67% | 80% (4 of 5); on the table 80% | 62% (5 of 8); on the table 75% |
| Magic missiles tried each own turn | 50%+ | 50% (36 of 72) | 33% (2 of 6) | 49% (38 of 78) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 56% (36 of 64) | 67% (2 of 3) | 57% (38 of 67) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 75% (9 of 12) | 75% (9 of 12) |
| Points that never fought | lower | 31% (1165 of 3800) | 58% (2336 of 3999) | 45% (3501 of 7799) |
|   infantry points that never fought | lower | 36% (646 of 1802) | 83% (302 of 365) | 44% (948 of 2167) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 40% (4 of 10) | 60% (9 of 15) | 52% (13 of 25) |
| Bound items with a magic missile used (at least once a game) |  | 100% (2 of 2); 4.5 uses a game | 100% (2 of 2); 2.0 uses a game | 100% (4 of 4); 3.2 uses a game |
| Bound items with another spell used |  | 100% (2 of 2); 2.0 uses a game | 0.0 uses a game | 100% (2 of 2); 1.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 100% (2 of 2); 1.0 uses a game | 0.0 uses a game | 100% (2 of 2); 0.5 uses a game |
|   their share of the points of units over 100 pts | lower | 34% (912 of 2718) | 67% (2574 of 3816) | 53% (3486 of 6534) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 12.0 (67%) | 0.0 (0%) | 12.0 (60%) |
| MARCHED: its unit marched | 2.0 (11%) | 0.5 (25%) | 2.5 (12%) |
| IN COMBAT: engaged in combat | 1.0 (6%) | 0.0 (0%) | 1.0 (5%) |
| GONE: slain | 3.0 (17%) | 1.5 (75%) | 4.5 (22%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Movement spells | Magic missiles | Assailments |
| --- | --- | --- | --- | --- |
| tried | 13.0 | 5.5 | 19.0 | 1.5 |
| not cast | 14.0 | 6.5 | 20.0 | 22.5 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 3.5 (16%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.0 (0%) | 12.0 (60%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 2.5 (12%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.0 (0%) | 1.0 (5%) | 0.0 (0%) |
| GONE: slain | 2.5 (18%) | 1.5 (23%) | 4.5 (22%) | 6.0 (27%) |
| HELD BACK: the computer weighed it and chose not to cast it | 11.5 (82%) | 5.0 (77%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 13.0 (58%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 6.0 a game | 1.5 a game | 3.8 a game |
| stood (cast and not dispelled) | 92% (11 of 12) | - | 92% (11 of 12) |
| the unit moved after it | 55% (6 of 11) | - | 55% (6 of 11) |
| it charged on its next turn | 0% (0 of 11) | - | 0% (0 of 11) |
| the enemy charged it first | 9% (1 of 11) | - | 9% (1 of 11) |
| it fought by the end of its next turn | 0% (0 of 11) | - | 0% (0 of 11) |
| it moved out of a charge the enemy had planned (not charged first) | 36% (4 of 11) | - | 36% (4 of 11) |
| none of these (no charge, no fight, no charge escaped) | 55% (6 of 11) | - | 55% (6 of 11) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 77% (17 of 22) | 28% (9 of 32) | 48% (26 of 54) |
|   character | - | 12% (2 of 16) | 12% (2 of 16) |
|   chariot | - | 0% (0 of 4) | 0% (0 of 4) |
|   infantry | 77% (17 of 22) | 58% (7 of 12) | 71% (24 of 34) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.0 (40%) | 2.5 (22%) | 3.5 (25%) |
| CHARGED: it charged | 0.0 (0%) | 3.0 (26%) | 3.0 (21%) |
| IN COMBAT: it fought this turn or the last | 1.0 (40%) | 0.5 (4%) | 1.5 (11%) |
| NO TARGET IN RANGE | 0.0 (0%) | 2.5 (22%) | 2.5 (18%) |
| ONLY IN COMBAT: the only targets were in combat | 0.5 (20%) | 1.0 (9%) | 1.5 (11%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.0 (0%) | 2.0 (17%) | 2.0 (14%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| character | 2.0 | 1.0 | 50% | 2.7 pts | 5 pts |
| infantry | 13.0 | 2.0 | 85% | 1.5 pts | 20 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 0.5 | 4.0 | 2.2 |
| Charges that made contact a game | 0.5 | 3.5 | 2.0 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | - | 0.00 declared, 0.00 contact (1 units) | 0.00 declared, 0.00 contact (1 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | - | - |
|   per unit a game, the other units (no war machines, no joined characters) | 0.10 declared, 0.10 contact (10 units) | 0.47 declared, 0.41 contact (17 units) | 0.33 declared, 0.30 contact (27 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 50% (2 of 4) | - | 100% (1 of 1) | 60% (3 of 5) |
| Character in a unit | 100% (2 of 2) | 33% (1 of 3) | - | 60% (3 of 5) |
| Character on its own | - | 0% (0 of 1) | 75% (3 of 4) | 60% (3 of 5) |
| Chariot | 0% (0 of 1) | - | - | 0% (0 of 1) |
| Infantry | 0% (0 of 2) | 25% (1 of 4) | - | 17% (1 of 6) |
| Monster | 100% (2 of 2) | - | - | 100% (2 of 2) |
| Monstrous | 100% (1 of 1) | - | - | 100% (1 of 1) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 2 | 33% (1 of 3); on the table 67% | 50% (36 of 72) | 31% | 40% (4 of 10) | 100% (2 of 2); 4.5 uses a game | 100% (2 of 2); 2.0 uses a game | 100% (2 of 2); 1.0 uses a game |
| High Elf Realms | 1 | 67% (2 of 3); on the table 67% | 33% (2 of 6) | 69% | 43% (3 of 7) | 100% (2 of 2); 4.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 1 | 100% (2 of 2); on the table 100% | - | 47% | 75% (6 of 8) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (h5-opp-8766b98-p4, 2 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 67% (2) | 0% (0) | 50% (2) |
| ...free all their last turn and able to turn (per game) | 1.00 | 0.00 | 1.00 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 1.00 | 0.00 | 1.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: h5-opp-8766b98-p4

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 0.0 | 3.5 |
| Strategy | Charge objectives carried out (made contact) | - | 38% (3 of 8) |
| Strategy | Shoot objectives carried out (shot that target) | 12% (1 of 8) | 100% (3 of 3) |
| Strategy | Joined characters whose unit fought | 73% (8 of 11) | - |
| Strategy | Lone characters that fought | 100% (1 of 1) | 75% (3 of 4) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 1.5 | 4.5 |
| Movement | Points that never moved of their own | 0.0 | 170.0 |
| Movement | Fights charged into per game | 0.5 | 3.5 |
| Movement | Charges with odds: long shots (under 50%) | - | 1 of 7, net +0 |
| Movement | Charges with odds: sweet spot (55-75%) | - | 3 of 7, net +59 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | - | 1 of 7, net +65 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | - | 2 of 7, net +32 |
| Shooting | Shots by shooting units (incl. breath weapons) | 8.5 | 7.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 35% (6 of 17) | 36% (5 of 14) |
| Shooting | Points destroyed by shooting units | 0.0 | 0.0 |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | 14.5 | 0.5 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 41% (12 of 29) | 100% (1 of 1) |
| Magic | Wounds caused by magic missiles | 25.5 | - |
| Magic | Points destroyed by magic (all spells) | 400.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 9.5 / 0.0 / 0.0 / 0.0 | 0.0 / 0.0 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 57.5 | 242.5 |
| Combat | Points run down | 31.5 | 0.0 |
| Combat | Net points per charged fight, damage counted | +73 | +43 |
| Combat | Net per 100 charger points, damage counted | +8.7 | +16.4 |
| Combat | First round won (charged fights) | 100% | 43% |
| Combat | Net points per charged fight | +0 | +44 |
| Combat | Net points per supported fight / lone fight | - / +0 | - / +44 |
| Combat | Charged fights on a top-3 enemy unit | 1 of 1 | 4 of 7 |
| Game | Points lost | 220.0 | 557.5 |
| Game | VP from objectives | 1005.0 | 515.0 |
| Game | Lone holders (player turns) | 7.0 | 9.0 |

- Mine won / drew / lost: 2 / 0 / 0 of 2 ended games (of 2); mean margin (Mine - Opponent) +761 VP
- The side that went first won 0 of 2 games with a winner
- Points traded per game (both sides' losses): 778
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: h5-opp-8766b98-p4

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | - | - | - | - | 0.5 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.5 | +142.3 | 0.0 | 0.0 | - | - | - | - |
| ALREADY CARRIED | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| BLOWS WHERE AIMED | - | - | - | - | 1.5 | -245.4 | 0.0 | 57.5 |
| CASTER AWAY FROM SCREEN | 2.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CASTING BLOCK | 2.5 | +308.9 | 354.5 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | 5.0 | +0.0 | 0.0 | 0.0 | 0.5 | +0.0 | 0.0 | 197.5 |
| CHAFF IN THE MOVE | 0.5 | +4.9 | 0.0 | 0.0 | - | - | - | - |
| CHARGE LOSSES | 7.0 | -354.7 | 0.0 | 32.5 | 5.0 | -114.3 | 0.0 | 99.5 |
| CHARGE NOT DECLARED | - | - | - | - | 0.5 | +0.0 | 0.0 | 31.5 |
| CHARGE NOW FIRST | - | - | - | - | 2.0 | +0.0 | 0.0 | 57.5 |
| CHARIOT NO STATIC JOB | - | - | - | - | 0.5 | +0.0 | 0.0 | 57.5 |
| CHEAPEST HOLDER | 1.0 | -71.0 | 0.0 | 0.0 | - | - | - | - |
| COMBAT PIVOT | - | - | - | - | 1.5 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | 5.0 | +507.2 | 0.0 | 177.5 | - | - | - | - |
| COVER ONCE | 4.5 | -422.8 | 0.0 | 32.5 | 1.5 | -93.0 | 0.0 | 0.0 |
| DEPLOY BY FIGURES | 5.5 | +61.1 | 0.0 | 0.0 | 8.0 | +4.0 | 0.0 | 15.0 |
| FALL BACK GOOD ORDER | - | - | - | - | 3.5 | +7.9 | 65.0 | 120.5 |
| FALLS SHORT | - | - | - | - | 20.0 | +354.5 | 0.0 | 594.0 |
| FEATURE BUFFS | 7.0 | +312.9 | 0.0 | 0.0 | 0.5 | +16.7 | 0.0 | 0.0 |
| FIGHT TO THE END | - | - | - | - | 2.0 | +58.7 | 0.0 | 57.5 |
| FIVE ACTION | 28.0 | +4691.0 | 530.5 | 92.5 | 47.0 | +2974.1 | 65.0 | 974.0 |
| FLANK NOT WEIGHED | 3.0 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 15.0 |
| FOLLOW UP WEIGHED | 0.5 | +149.4 | 0.0 | 0.0 | - | - | - | - |
| FOUR ROUNDS | - | - | - | - | 4.0 | +253.6 | 65.0 | 120.5 |
| FRIEND SHOOTS FIRST | - | - | - | - | 0.5 | -6.7 | 0.0 | 0.0 |
| FRIENDS SHOTS CHECKED | - | - | - | - | 0.5 | +1.1 | 0.0 | 0.0 |
| HARD STAY DROPPED | 0.5 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HE SHOOTS OR CHARGES | 3.0 | +0.0 | 0.0 | 65.0 | 2.0 | +0.0 | 0.0 | 68.5 |
| HIS CHARGE LIST | 3.0 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 2.5 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 3.0 | -66.0 | 0.0 | 0.0 | 1.0 | -100.0 | 0.0 | 0.0 |
| HIS RANDOM MOVE | 2.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS SHOT LIST | 10.0 | +246.2 | 0.0 | 32.5 | 26.0 | +1763.5 | 0.0 | 785.0 |
| HIS TURN DENIED | - | - | - | - | 3.5 | +613.5 | 32.5 | 120.5 |
| HOLD ODDS | - | - | - | - | 12.0 | +0.0 | 0.0 | 199.0 |
| HOLDER ASSIGNMENT | - | - | - | - | 15.5 | +1157.1 | 0.0 | 199.0 |
| HOLDER AT DEPLOYMENT | 2.0 | +302.2 | 0.0 | 0.0 | - | - | - | - |
| HOLDS AMBUSHERS | 1.0 | +0.0 | 0.0 | 0.0 | 0.5 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | - | - | - | - | 3.5 | -222.3 | 65.0 | 89.0 |
| IDLE COST | - | - | - | - | 17.5 | -239.7 | 0.0 | 478.5 |
| LANE BY FIGURES | - | - | - | - | 0.5 | +12.8 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 11.5 | +0.0 | 78.0 | 130.0 | 2.0 | +0.0 | 32.5 | 115.0 |
| LONE WIZARD KEPT IN | 3.0 | +167.4 | 0.0 | 0.0 | - | - | - | - |
| MANOEUVRE | 1.5 | +55.9 | 0.0 | 0.0 | 1.5 | +27.1 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.5 | +71.8 | 0.0 | 0.0 | 0.5 | +1.4 | 0.0 | 0.0 |
| MARCH BY THE SUM | 0.5 | +10.1 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | 1.5 | +70.5 | 0.0 | 0.0 | 1.5 | +61.8 | 0.0 | 199.0 |
| MARCH OVER CASTS | - | - | - | - | 0.5 | +50.5 | 0.0 | 197.5 |
| MAX FOR POSITIONING | 3.5 | +86.8 | 0.0 | 27.5 | 4.0 | +87.8 | 0.0 | 212.5 |
| MISSILES IN THE MOVE | 9.0 | +1477.1 | 0.0 | 0.0 | 1.5 | +22.6 | 0.0 | 297.0 |
| MISSILES NEXT TURN | 9.5 | +949.8 | 0.0 | 0.0 | 3.5 | +23.2 | 0.0 | 594.0 |
| MOVE SPELL OUT OF RANGE | 2.0 | -19.4 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL SPOT | 2.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | - | - | - | - | 4.5 | +450.2 | 0.0 | 0.0 |
| MOVES UNITS SPELL | - | - | - | - | 0.5 | +3.6 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 8.0 | +420.2 | 0.0 | 32.5 | 7.5 | +297.0 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 1.0 | -14.3 | 0.0 | 0.0 | 5.0 | -70.8 | 0.0 | 0.0 |
| NEXT OBJECTIVE NEARER | 3.5 | -168.6 | 0.0 | 32.5 | - | - | - | - |
| NO DOUBLE ROUNDS | - | - | - | - | 4.0 | -109.4 | 65.0 | 120.5 |
| NOT WORTH A CAST | 1.0 | -0.5 | 0.0 | 0.0 | 1.0 | -0.5 | 0.0 | 395.0 |
| OFF BEST | - | - | - | - | 1.0 | -1.4 | 0.0 | 0.0 |
| ONE CHARGE A CHARGER | 3.0 | +0.0 | 0.0 | 27.5 | 0.5 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 2.0 | -27.7 | 0.0 | 0.0 | 4.5 | -129.8 | 0.0 | 463.5 |
| ONE OBJECTIVE FORMULA | 9.5 | +15.3 | 0.0 | 32.5 | 4.5 | -50.7 | 0.0 | 99.5 |
| ONE TARGET A SHOOTER | 10.5 | +128.9 | 0.0 | 60.0 | 16.0 | +683.3 | 0.0 | 168.0 |
| OPENS UP | - | - | - | - | 0.5 | +15.9 | 32.5 | 0.0 |
| PATHS CROSS | 3.5 | +328.5 | 0.0 | 27.5 | 5.5 | +290.2 | 0.0 | 99.5 |
| PLAN RESULT | 23.5 | +344.7 | 343.0 | 157.5 | 40.0 | +126.5 | 0.0 | 1027.5 |
| QUARTER ODDS | - | - | - | - | 2.5 | +316.4 | 0.0 | 0.0 |
| RANDOM MOVE BY FIGURES | - | - | - | - | 6.0 | +19.6 | 0.0 | 0.0 |
| REDIRECT COUNTER | 1.5 | +104.5 | 0.0 | 27.5 | 4.5 | +168.1 | 0.0 | 83.5 |
| REFORMS TO MEET IT | - | - | - | - | 0.5 | -12.6 | 0.0 | 0.0 |
| REFUSING RETIRES | 1.5 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| RESTRAINS TO SHOOT | - | - | - | - | 0.5 | +14.7 | 0.0 | 57.5 |
| RISK BY ARC | - | - | - | - | 3.5 | +97.5 | 65.0 | 89.0 |
| RISK BY HIS FIGURE | 10.0 | -285.1 | 0.0 | 92.5 | 9.0 | -38.7 | 0.0 | 68.5 |
| RUN DOWN | - | - | - | - | 3.5 | -21.1 | 65.0 | 63.0 |
| SCOUT SPOT | 0.5 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SCOUT WAITS | 0.5 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SEARCH SPOT | 6.5 | +78.3 | 0.0 | 32.5 | 4.5 | +242.1 | 0.0 | 88.0 |
| SELF MOVE SPELL | - | - | - | - | 1.5 | +168.6 | 0.0 | 395.0 |
| SET UP TOGETHER | - | - | - | - | 0.5 | +1.1 | 0.0 | 0.0 |
| SET-UP ANY TARGET | 2.0 | +423.3 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | - | - | - | - | 1.0 | +1.0 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.0 | +236.9 | 176.0 | 0.0 | 1.0 | +19.5 | 0.0 | 0.0 |
| SHOT RISK POINTS | 8.0 | -97.9 | 0.0 | 27.5 | 21.0 | +423.5 | 0.0 | 656.0 |
| SHOTS IN THE MOVE | 6.5 | +206.1 | 0.0 | 32.5 | 8.0 | +154.8 | 0.0 | 285.5 |
| SPELL SETS UP CHARGE | 2.0 | +423.3 | 0.0 | 0.0 | - | - | - | - |
| SPELL WORTH | 4.0 | +63.2 | 0.0 | 355.0 | - | - | - | - |
| SPELLS IN THE FIGHT | - | - | - | - | 0.5 | -5.8 | 0.0 | 0.0 |
| STAND AND SHOOT | - | - | - | - | 1.5 | -10.4 | 65.0 | 31.5 |
| STANDS FOR A REASON | - | - | - | - | 0.5 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 7.0 | +0.0 | 530.5 | 0.0 | 9.0 | +0.0 | 0.0 | 0.0 |
| STAY WORTH | 4.5 | +34.2 | 57.5 | 0.0 | 8.5 | +91.8 | 0.0 | 285.5 |
| SUPPORT NARROWED | - | - | - | - | 0.5 | +0.0 | 0.0 | 0.0 |
| SURE REACH TOGETHER | - | - | - | - | 0.5 | +3.5 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 4.5 | +0.0 | 0.0 | 27.5 | 4.0 | +0.0 | 0.0 | 99.5 |
| THE PROMISED MOVE | - | - | - | - | 1.5 | +0.0 | 0.0 | 99.5 |
| TIED UP BY THE SUM | - | - | - | - | 1.0 | +89.3 | 32.5 | 0.0 |
| TIME ON OUR SIDE | 25.5 | +713.8 | 0.0 | 92.5 | - | - | - | - |
| WAITS AGAIN | - | - | - | - | 0.5 | +0.0 | 0.0 | 0.0 |
| WIDER SPREAD | - | - | - | - | 2.5 | -38.5 | 0.0 | 89.0 |
| WOUNDS ON THE RANKS | 3.5 | +120.1 | 0.0 | 0.0 | - | - | - | - |

### Rule changes: h5-opp-8766b98-p4

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HOLDER ASSIGNMENT | 31 | 31 | 29 | 14.50 | +978 | +33.7 |
| LEGAL CHARGES ONLY | 27 | 27 | 27 | 13.50 | +0 | +0.0 |
| HIS SHOT LIST | 72 | 72 | 24 | 12.00 | +559 | +23.3 |
| SEARCH SPOT | 22 | 22 | 21 | 10.50 | +641 | +30.5 |
| PATHS CROSS | 18 | 18 | 18 | 9.00 | +1237 | +68.7 |
| DEPLOY BY FIGURES | 27 | 27 | 17 | 8.50 | +186 | +10.9 |
| ONE TARGET A SHOOTER | 53 | 53 | 14 | 7.00 | +242 | +17.3 |
| RANDOM MOVE BY FIGURES | 12 | 12 | 9 | 4.50 | +39 | +4.4 |
| SHOT RISK POINTS | 58 | 58 | 8 | 4.00 | +172 | +21.6 |
| SHOTS IN THE MOVE | 29 | 24 | 7 | 3.50 | +257 | +36.8 |
| LONE WIZARD KEPT IN | 6 | 6 | 6 | 3.00 | +335 | +55.8 |
| MAX FOR POSITIONING | 15 | 15 | 5 | 2.50 | +77 | +15.4 |
| MISSILES IN THE MOVE | 21 | 18 | 5 | 2.50 | +663 | +132.6 |
| TIME ON OUR SIDE | 51 | 42 | 5 | 2.50 | +82 | +16.4 |
| CASTER AWAY FROM SCREEN | 4 | 4 | 4 | 2.00 | +0 | +0.0 |
| MANOEUVRE | 6 | 6 | 4 | 2.00 | +166 | +41.5 |
| MARCH CHECK | 6 | 6 | 4 | 2.00 | +91 | +22.8 |
| MOVE TO CHARGE COMPUTED | 9 | 9 | 4 | 2.00 | +369 | +92.2 |
| CASTING BLOCK | 5 | 5 | 3 | 1.50 | +60 | +19.9 |
| COMBAT PIVOT | 3 | 3 | 3 | 1.50 | +0 | +0.0 |
| FEATURE BUFFS | 15 | 15 | 3 | 1.50 | +112 | +37.3 |
| HIS TURN DENIED | 7 | 7 | 3 | 1.50 | +401 | +133.7 |
| HOLDS AMBUSHERS | 3 | 3 | 3 | 1.50 | +0 | +0.0 |
| SHOOTS FROM THE BEST SPOT | 4 | 4 | 3 | 1.50 | +30 | +10.0 |
| CHARGE LOSSES | 24 | 24 | 2 | 1.00 | +51 | +25.6 |
| COVER ONCE | 12 | 6 | 2 | 1.00 | +43 | +21.6 |
| FIVE ACTION | 150 | 150 | 2 | 1.00 | +56 | +28.2 |
| FOUR ROUNDS | 8 | 8 | 2 | 1.00 | +24 | +12.0 |
| NEARER NOT NEEDED | 31 | 29 | 2 | 1.00 | +80 | +40.0 |
| NEXT OBJECTIVE NEARER | 7 | 7 | 2 | 1.00 | +126 | +63.0 |
| OFF BEST | 2 | 2 | 2 | 1.00 | -3 | -1.4 |
| ONE OBJECTIVE FORMULA | 28 | 21 | 2 | 1.00 | +99 | +49.7 |
| QUARTER ODDS | 5 | 5 | 2 | 1.00 | +131 | +65.5 |
| REDIRECT COUNTER | 12 | 11 | 2 | 1.00 | +48 | +24.1 |
| RISK BY ARC | 7 | 7 | 2 | 1.00 | +24 | +12.0 |
| RISK BY HIS FIGURE | 38 | 38 | 2 | 1.00 | +123 | +61.4 |
| SHOOTERS IN TWO RANKS | 2 | 2 | 2 | 1.00 | +2 | +1.0 |
| TIED UP BY THE SUM | 2 | 2 | 2 | 1.00 | +24 | +12.0 |
| ADVANCE LANE KEPT | 1 | 1 | 1 | 0.50 | +0 | +0.0 |
| AFTERMATH IN POINTS | 1 | 1 | 1 | 0.50 | +285 | +284.6 |
| CHARGE NOT DECLARED | 1 | 1 | 1 | 0.50 | -115 | -114.7 |
| FALLS SHORT | 40 | 39 | 1 | 0.50 | +19 | +19.2 |
| FOLLOW UP WEIGHED | 1 | 1 | 1 | 0.50 | +299 | +298.9 |
| FRIENDS SHOTS CHECKED | 1 | 1 | 1 | 0.50 | +2 | +2.4 |
| HARD STAY DROPPED | 1 | 1 | 1 | 0.50 | +0 | +0.0 |
| HOLDER AT DEPLOYMENT | 4 | 4 | 1 | 0.50 | +74 | +73.6 |
| LANE BY FIGURES | 1 | 1 | 1 | 0.50 | +26 | +25.6 |
| MARCH BY THE SUM | 1 | 1 | 1 | 0.50 | +20 | +20.1 |
| MISSILES NEXT TURN | 26 | 22 | 1 | 0.50 | +11 | +10.9 |
| MOVES UNITS SPELL | 1 | 1 | 1 | 0.50 | +7 | +7.3 |
| NEXT CHARGE BY LIST | 12 | 12 | 1 | 0.50 | +10 | +9.8 |
| OPENS UP | 1 | 1 | 1 | 0.50 | +9 | +9.0 |
| REFUSING RETIRES | 3 | 3 | 1 | 0.50 | -0 | -0.1 |
| RESTRAINS TO SHOOT | 1 | 1 | 1 | 0.50 | +29 | +29.4 |
| SCOUT WAITS | 1 | 1 | 1 | 0.50 | +0 | +0.0 |
| SURE REACH TOGETHER | 1 | 1 | 1 | 0.50 | +0 | +0.0 |
| WOUNDS ON THE RANKS | 7 | 7 | 1 | 0.50 | +34 | +33.6 |
| ALREADY CARRIED | 2 | not checked | - | - | - | - |
| BLOWS WHERE AIMED | 3 | 3 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 11 | trace | - | - | - | - |
| CHAFF IN THE MOVE | 1 | 1 | 0 | 0.00 | - | - |
| CHARGE NOW FIRST | 4 | 4 | 0 | 0.00 | - | - |
| CHARIOT NO STATIC JOB | 1 | 1 | 0 | 0.00 | - | - |
| CHEAPEST HOLDER | 2 | 2 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 10 | not checked | - | - | - | - |
| FALL BACK GOOD ORDER | 7 | 7 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 4 | 4 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 14 | not checked | - | - | - | - |
| FRIEND SHOOTS FIRST | 1 | 1 | 0 | 0.00 | - | - |
| HE SHOOTS OR CHARGES | 10 | 10 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 12 | 12 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 11 | 11 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 8 | 8 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 4 | 4 | 0 | 0.00 | - | - |
| HOLD ODDS | 24 | 24 | 0 | 0.00 | - | - |
| HONEST WORTH | 7 | 7 | 0 | 0.00 | - | - |
| IDLE COST | 35 | 30 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 2 | trace | - | - | - | - |
| MARCH OVER CASTS | 1 | 1 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 4 | trace | - | - | - | - |
| MOVE SPELL SPOT | 4 | not checked | - | - | - | - |
| NO DOUBLE ROUNDS | 8 | 8 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 4 | not checked | - | - | - | - |
| ONE CHARGE A CHARGER | 7 | 7 | 0 | 0.00 | - | - |
| ONE FIGHT FORMULA | 13 | 9 | 0 | 0.00 | - | - |
| PLAN RESULT | 127 | trace | - | - | - | - |
| REFORMS TO MEET IT | 1 | 1 | 0 | 0.00 | - | - |
| RUN DOWN | 7 | 7 | 0 | 0.00 | - | - |
| SCOUT SPOT | 1 | 1 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 3 | not checked | - | - | - | - |
| SET UP TOGETHER | 1 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 4 | not checked | - | - | - | - |
| SPELL SETS UP CHARGE | 4 | not checked | - | - | - | - |
| SPELL WORTH | 8 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 3 | 3 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 1 | 1 | 0 | 0.00 | - | - |
| STANDS STILL | 32 | 32 | 0 | 0.00 | - | - |
| STAY WORTH | 26 | 23 | 0 | 0.00 | - | - |
| SUPPORT NARROWED | 1 | 1 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 17 | not checked | - | - | - | - |
| THE PROMISED MOVE | 3 | not checked | - | - | - | - |
| WAITS AGAIN | 1 | 1 | 0 | 0.00 | - | - |
| WIDER SPREAD | 5 | 5 | 0 | 0.00 | - | - |

### Off best figure: h5-opp-8766b98-p4

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| HOLDER ASSIGNMENT | rule | - | 1.50 | 8.9 |
| FIGHT ORDER BAND | gate | - | 1.00 | 1.4 |
| CHARGE NOT DECLARED | rule | - | 0.50 | 114.7 |

### Plans: h5-opp-8766b98-p4

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | move | 20.0 | 95% | 2954 | 0 | 0% |
| Mine | shoot | 3.5 | 71% | 1038 | 345 | 33% |
| Opponent | charge | 3.0 | 50% | 933 | 99 | 11% |
| Opponent | move | 35.5 | 94% | 1373 | 0 | 0% |
| Opponent | shoot | 1.5 | 33% | 114 | 28 | 24% |

### Battle groups: h5-opp-8766b98-p4

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 1.5 | 0% | - | - | - | - | - | - | - | - |
| Opponent | REDIRECT COUNTER | 4.5 | 0% | - | - | - | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: h5-opp-8766b98-p4

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 2 | 0 (2) | 0 | 0 | 50 | 100% | - | - | 0 (1) | 0 (1) | 0 (1) | 0 (1) |
| Mine | Character | 12 | 44 (12) | 44 | 0 | 18 | 8% | 2.3 | - | 107 (5) | 3 (6) | 93 (5) | 17 (6) |
| Mine | Hammer | 4 | 33 (4) | 7 | 26 | 0 | 25% | 4.0 | - | 9 (2) | 57 (2) | 42 (2) | 24 (2) |
| Mine | Holder | 2 | 78 (2) | 0 | 78 | 0 | 100% | - | - | 117 (1) | 39 (1) | - | 78 (2) |
| Mine | Shooter | 4 | 81 (4) | 0 | 81 | 50 | 0% | 1.2 | - | 81 (4) | - | 0 (2) | 162 (2) |
| Opponent | Chaff | 2 | 0 (2) | 0 | 0 | 50 | 100% | - | 0 (1) | - | 0 (1) | 0 (2) | - |
| Opponent | Character | 4 | 3 (4) | 3 | 0 | 21 | 0% | 2.2 | - | 0 (3) | 13 (1) | 7 (2) | 0 (2) |
| Opponent | Clean-up | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | 0 (1) | - | - | 0 (1) | - |
| Opponent | Fast Hammer | 6 | 52 (6) | 31 | 21 | 39 | 67% | 2.0 | 65 (2) | 71 (2) | 0 (2) | 58 (5) | 0 (1) |
| Opponent | Hammer | 3 | 16 (3) | 16 | 0 | 16 | 67% | 5.0 | - | 28 (2) | 0 (1) | 28 (2) | 0 (1) |
| Opponent | Holder | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | - | 0 (1) | 0 (1) | - |
| Opponent | Shooter | 2 | 179 (2) | 0 | 179 | 58 | 0% | 2.5 | 262 (1) | - | 119 (1) | 179 (2) | - |

### Charged fights: h5-opp-8766b98-p4

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 2 | 400 | 0 | 0.5 | 1.0 | 0 | 0 | +0 | 1 of 1 | 1 of 1 | - | +0 |
| Opponent | High Elf Realms | 1 | 0 | 355 | 4.0 | 1.0 | 89 | 29 | +60 | 3 of 4 | 1 of 4 | - | +60 |
| Opponent | Warriors of Chaos | 1 | 0 | 130 | 3.0 | 1.0 | 43 | 21 | +22 | 1 of 3 | 2 of 3 | - | +22 |
| **Opponent** | all armies | 2 | 0 | 242 | 3.5 | 1.0 | 69 | 25 | +44 | 4 of 7 | 3 of 7 | - | +44 |

### Effective charges: h5-opp-8766b98-p4

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | High Elf Realms | 4 | 1 (net +0) | 0 | 2 (net +120) | 0 | 0 | 1 (net +0) | 0 | 50% (2 of 4) |
| Opponent | Warriors of Chaos | 3 | 0 | 0 | 1 (net -63) | 0 | 1 (net +65) | 1 (net +65) | 0 | 33% (1 of 3) |

### Charged fights, damage counted: h5-opp-8766b98-p4

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | No odds | 1 | 836 | 499 | +0 | 200 | 127 | +73 | +8.7 |
| Mine | All fights | 1 | 836 | 499 | +0 | 200 | 127 | +73 | +8.7 |
| Opponent | Long shot (under 50%) | 1 | 497 | 322 | +0 | 0 | 0 | +0 | +0.0 |
| Opponent | Effective (55-75%) | 3 | 225 | 322 | +59 | 180 | 142 | +38 | +16.7 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 89 | 65 | +32 | 62 | 0 | +62 | +70.0 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 489 | 65 | +65 | 65 | 0 | +65 | +13.3 |
| Opponent | All fights | 7 | 263 | 212 | +44 | 104 | 61 | +43 | +16.4 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| h5-opp-8766b98-p4 | move | 9 | 3 (33%) | 3 (33%) | 0 (0%) | 6 (67%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0115, L0132 |
| Ring of Doom | Opponent | L0115 |

# Doctrine scorecard: h5-smoke-8766b98

### Scorecard: h5-smoke-8766b98

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0103 | 1 | 1 | Mine | no | 2 | 6 | 0 | 1 | 0 | 0 | 0 | 0 |
| L0103 | 1 | 1 | Opponent | no | 0 | 4 | 1 | 1 | 0 | 0 | 0 | 360 |
| L0120 | 6 | 1 | Mine | no | 4 | 6 | 1 | 2 | 0 | 0 | 0 | 0 |
| L0120 | 6 | 1 | Opponent | no | 5 | 4 | 1 | 3 | 0 | 0 | 0 | 0 |
| L0204 | 6 | 1 | Mine | no | 0 | 5 | 1 | 4 | 1 | 0 | 0 | 170 |
| L0204 | 6 | 1 | Opponent | no | 4 | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 0% | 2.0 | 5.7 | 0.7 | 2.3 | 0.3 | 0.0 | 0.0 | 56.7 |
| **Average** | | | Opponent | 0% | 3.0 | 3.3 | 1.3 | 1.7 | 0.0 | 0.0 | 0.0 | 120.0 |

### KPIs: h5-smoke-8766b98

Rules off - Opponent only: HOLDER ASSIGNMENT, QUARTER ODDS.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 11) | 29% (4 of 14) | 16% (4 of 25) |
| Winner chose to follow up after the loser gave ground |  | 86% (6 of 7); on the table 86% | 100% (1 of 1); on the table 100% | 88% (7 of 8); on the table 88% |
| Winner chose to pursue after the loser fell back in good order |  | 100% (2 of 2); on the table 100% | - | 100% (2 of 2); on the table 100% |
| Winner chose to pursue after the loser fled |  | - | 50% (1 of 2); on the table 50% | 50% (1 of 2); on the table 50% |
| Winner chose to follow up or pursue (all three) |  | 89% (8 of 9); on the table 89% | 67% (2 of 3); on the table 67% | 83% (10 of 12); on the table 83% |
| Magic missiles tried each own turn | 50%+ | 55% (46 of 84) | 62% (15 of 24) | 56% (61 of 108) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 61% (46 of 76) | 75% (15 of 20) | 64% (61 of 96) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 100% (2 of 2) | 80% (8 of 10) | 83% (10 of 12) |
| Points that never fought | lower | 41% (2361 of 5699) | 53% (3187 of 5997) | 47% (5548 of 11696) |
|   infantry points that never fought | lower | 51% (1143 of 2239) | 78% (1343 of 1724) | 63% (2486 of 3963) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 50% (8 of 16) | 52% (12 of 23) | 51% (20 of 39) |
| Bound items with a magic missile used (at least once a game) |  | 100% (4 of 4); 6.0 uses a game | 0.0 uses a game | 100% (4 of 4); 3.0 uses a game |
| Bound items with another spell used |  | 50% (1 of 2); 0.7 uses a game | 0.0 uses a game | 50% (1 of 2); 0.3 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 75% (3 of 4); 1.0 uses a game | 50% (1 of 2); 0.3 uses a game | 67% (4 of 6); 0.7 uses a game |
|   their share of the points of units over 100 pts | lower | 44% (1713 of 3916) | 48% (2510 of 5213) | 46% (4223 of 9129) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 6.0 (47%) | 1.0 (33%) | 7.0 (45%) |
| MARCHED: its unit marched | 3.3 (26%) | 0.7 (22%) | 4.0 (26%) |
| CHARGED: its unit charged | 0.7 (5%) | 0.0 (0%) | 0.7 (4%) |
| IN COMBAT: engaged in combat | 2.7 (21%) | 0.3 (11%) | 3.0 (19%) |
| GONE: slain | 0.0 (0%) | 1.0 (33%) | 1.0 (6%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 9.3 | 0.3 | 5.7 | 20.3 | 0.7 | 1.7 |
| not cast | 2.7 | 1.7 | 10.3 | 15.7 | 1.3 | 30.3 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.3 (4%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.3 (20%) | 1.3 (13%) | 7.0 (45%) | 0.3 (25%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 4.0 (26%) | 0.0 (0%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (4%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.7 (25%) | 0.7 (40%) | 2.0 (19%) | 3.0 (19%) | 0.3 (25%) | 0.0 (0%) |
| GONE: slain | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.0 (6%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (50%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.0 (75%) | 0.7 (40%) | 7.0 (68%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 29.0 (96%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 4.7 a game | 1.7 a game | 3.2 a game |
| stood (cast and not dispelled) | 50% (7 of 14) | 20% (1 of 5) | 42% (8 of 19) |
| the unit moved after it | 71% (5 of 7) | 100% (1 of 1) | 75% (6 of 8) |
| it charged on its next turn | 0% (0 of 7) | 0% (0 of 1) | 0% (0 of 8) |
| the enemy charged it first | 0% (0 of 7) | 0% (0 of 1) | 0% (0 of 8) |
| it fought by the end of its next turn | 0% (0 of 7) | 0% (0 of 1) | 0% (0 of 8) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 7) | 0% (0 of 1) | 0% (0 of 8) |
| none of these (no charge, no fight, no charge escaped) | 100% (7 of 7) | 100% (1 of 1) | 100% (8 of 8) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 64% (14 of 22) | 56% (35 of 63) | 58% (49 of 85) |
|   cavalry | - | 83% (5 of 6) | 83% (5 of 6) |
|   chariot | - | 48% (11 of 23) | 48% (11 of 23) |
|   infantry | 64% (14 of 22) | 44% (7 of 16) | 55% (21 of 38) |
|   war machine | - | 67% (12 of 18) | 67% (12 of 18) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.3 (50%) | 1.7 (18%) | 3.0 (25%) |
| CHARGED: it charged | 1.0 (38%) | 0.7 (7%) | 1.7 (14%) |
| IN COMBAT: it fought this turn or the last | 0.0 (0%) | 0.7 (7%) | 0.7 (6%) |
| MOVED: a war machine that moved | 0.0 (0%) | 0.3 (4%) | 0.3 (3%) |
| NO TARGET IN RANGE | 0.0 (0%) | 2.3 (25%) | 2.3 (19%) |
| ONLY IN COMBAT: the only targets were in combat | 0.3 (12%) | 0.3 (4%) | 0.7 (6%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.0 (0%) | 2.0 (21%) | 2.0 (17%) |
| OTHER BAR | 0.0 (0%) | 1.3 (14%) | 1.3 (11%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 1.7 | 1.7 | 60% | 6.0 pts | 10 pts |
| chariot | 3.7 | 5.3 | 27% | 21.0 pts | 77 pts |
| infantry | 7.0 | 2.3 | 76% | 6.4 pts | 45 pts |
| war machine | 4.0 | 8.3 | 42% | 16.5 pts | 66 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.0 | 1.7 | 2.3 |
| Charges that made contact a game | 2.3 | 1.3 | 1.8 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | - | 0.25 declared, 0.25 contact (4 units) | 0.25 declared, 0.25 contact (4 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | - | - |
|   per unit a game, the other units (no war machines, no joined characters) | 0.45 declared, 0.35 contact (20 units) | 0.17 declared, 0.13 contact (23 units) | 0.30 declared, 0.23 contact (43 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 0% (0 of 1) | - | - | 0% (0 of 1) |
| Character in a unit | 83% (5 of 6) | 50% (3 of 6) | - | 67% (8 of 12) |
| Character on its own | - | 0% (0 of 1) | 50% (1 of 2) | 33% (1 of 3) |
| Chariot | - | 50% (2 of 4) | - | 50% (2 of 4) |
| Infantry | 33% (2 of 6) | 17% (1 of 6) | - | 25% (3 of 12) |
| Monster | 100% (1 of 1) | 50% (1 of 2) | - | 67% (2 of 3) |
| War Machines | 100% (3 of 3) | 100% (1 of 1) | - | 100% (4 of 4) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 3 | 89% (8 of 9); on the table 89% | 55% (46 of 84) | 41% | 50% (8 of 16) | 100% (4 of 4); 6.0 uses a game | 50% (1 of 2); 0.7 uses a game | 75% (3 of 4); 1.0 uses a game |
| Chaos Dwarfs | 2 | 67% (2 of 3); on the table 67% | 56% (10 of 18) | 51% | 50% (8 of 16) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Skaven | 1 | - | 83% (5 of 6) | 58% | 57% (4 of 7) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |

Flank and rear charges a unit could have turned to face (h5-smoke-8766b98, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 33% (1) | 33% (2) | 33% (3) |
| ...free all their last turn and able to turn (per game) | 0.33 | 0.33 | 0.67 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.33 | 0.33 | 0.67 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.33 | 0.00 | 0.33 |

### Quality by phase: h5-smoke-8766b98

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 0.7 | 1.3 |
| Strategy | Charge objectives carried out (made contact) | 43% (3 of 7) | 40% (2 of 5) |
| Strategy | Shoot objectives carried out (shot that target) | 0% (0 of 8) | 47% (14 of 30) |
| Strategy | Support requests answered (helper made contact too) | 50% (1 of 2) | - |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | - | 100% (1 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | 0% (0 of 1) | - |
| Strategy | Joined characters whose unit fought | 65% (11 of 17) | 0% (0 of 3) |
| Strategy | Lone characters that fought | 100% (1 of 1) | 60% (3 of 5) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 2.3 | 1.7 |
| Movement | Points that never moved of their own | 56.7 | 120.0 |
| Movement | Fights charged into per game | 2.0 | 1.3 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 6 | 1 of 4, net +0 |
| Movement | Charges with odds: sweet spot (55-75%) | 3 of 6, net +37 | 1 of 4, net -310 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 6 | 0 of 4 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 of 6, net -7 | 2 of 4, net +118 |
| Shooting | Shots by shooting units (incl. breath weapons) | 4.7 | 7.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 79% (11 of 14) | 13% (3 of 23) |
| Shooting | Points destroyed by shooting units | 70.0 | 83.7 |
| Shooting | War machine shots | - | 4.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | - | 75% (9 of 12) |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | 9.3 | 3.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 39% (11 of 28) | 20% (2 of 10) |
| Magic | Wounds caused by magic missiles | 15.0 | 5.0 |
| Magic | Wounds caused by other spells | 1.3 | - |
| Magic | Points destroyed by magic (all spells) | 84.3 | 28.3 |
| Magic | Augments / hexes / assailments / vortexes cast | 3.7 / 0.3 / 0.7 / 0.7 | 3.0 / 0.0 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 125.0 | 103.3 |
| Combat | Points run down | 76.7 | 21.7 |
| Combat | Net points per charged fight, damage counted | +37 | -113 |
| Combat | Net per 100 charger points, damage counted | +17.4 | -34.1 |
| Combat | First round won (charged fights) | 67% | 50% |
| Combat | Net points per charged fight | +15 | -19 |
| Combat | Net points per supported fight / lone fight | +0 / +18 | - / -19 |
| Combat | Charged fights on a top-3 enemy unit | 1 of 6 | 2 of 4 |
| Game | Points lost | 254.3 | 471.0 |
| Game | VP from objectives | 946.7 | 656.7 |
| Game | Lone holders (player turns) | 2.0 | 3.0 |

- Mine won / drew / lost: 2 / 0 / 1 of 3 ended games (of 3); mean margin (Mine - Opponent) +507 VP
- The side that went first won 1 of 3 games with a winner
- Points traded per game (both sides' losses): 725
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: h5-smoke-8766b98

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.3 | +2.8 | 0.0 | 0.0 | - | - | - | - |
| ALREADY CARRIED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARTILLERY RE-ROLL WEIGHED | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| BEST PRIZE | - | - | - | - | 0.3 | -1.3 | 0.0 | 0.0 |
| CANNON PLANNED TARGET | - | - | - | - | 2.7 | +10.0 | 0.0 | 83.3 |
| CANNON SIGHT KEPT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT SET-UP | 0.3 | -0.1 | 0.0 | 0.0 | - | - | - | - |
| CAST JOB | - | - | - | - | 2.0 | +34.3 | 0.0 | 28.3 |
| CASTER AWAY FROM SCREEN | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CASTING BLOCK | 2.0 | +190.5 | 70.0 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | 2.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | - | - | - | - | 0.3 | +5.3 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | 0.3 | +28.3 | 0.0 | 28.3 | - | - | - | - |
| CHARGE LOSSES | 4.3 | -185.4 | 0.0 | 21.7 | 7.3 | -419.2 | 0.0 | 159.3 |
| CHARGE NOT DECLARED | 0.7 | +0.0 | 43.3 | 56.7 | 0.7 | +0.0 | 83.7 | 0.0 |
| CHARGE NOW FIRST | 0.7 | +0.0 | 0.0 | 17.3 | 2.0 | +0.0 | 160.7 | 0.0 |
| CHARGER SLAIN LOST | 1.3 | -2.4 | 156.7 | 56.7 | - | - | - | - |
| COMBAT PIVOT | 0.7 | +0.0 | 0.0 | 85.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | 3.0 | +749.2 | 0.0 | 0.0 | 1.0 | +103.6 | 0.0 | 0.0 |
| COVER ONCE | 2.3 | -35.9 | 0.0 | 21.7 | 13.0 | -566.4 | 0.0 | 126.7 |
| DEPLOY BY FIGURES | 6.7 | +78.7 | 0.0 | 0.0 | 8.7 | +25.1 | 0.0 | 0.0 |
| EDGE GIVE GROUND | 0.7 | +36.9 | 36.7 | 0.0 | - | - | - | - |
| ENGINEER BY LORE | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| FALL BACK GOOD ORDER | 2.3 | +0.2 | 156.7 | 74.0 | 1.7 | +5.4 | 105.3 | 103.3 |
| FALLS SHORT | 16.7 | +380.6 | 0.0 | 82.3 | 14.0 | +201.8 | 0.0 | 47.0 |
| FEATURE BUFFS | 5.0 | +149.5 | 0.0 | 18.3 | 2.7 | +39.7 | 0.0 | 0.0 |
| FIGHT LIFT | 1.0 | +7.1 | 0.0 | 0.0 | 0.3 | +0.9 | 0.0 | 0.0 |
| FIGHT TO THE END | 1.3 | +1.2 | 58.3 | 45.7 | 0.7 | +77.2 | 56.7 | 103.3 |
| FIRE IN ORDER | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| FIVE ACTION | 34.0 | +3395.2 | 296.7 | 309.7 | 51.7 | +3407.9 | 320.7 | 590.3 |
| FLANK NOT WEIGHED | 3.7 | +0.0 | 0.0 | 48.3 | 5.3 | +0.0 | 0.0 | 0.0 |
| FOLLOW UP WEIGHED | 0.3 | +42.8 | 0.0 | 28.3 | - | - | - | - |
| FOUR ROUNDS | 2.3 | +108.1 | 156.7 | 74.0 | 1.7 | +108.0 | 105.3 | 103.3 |
| GUN FIGURES | - | - | - | - | 4.0 | +44.8 | 65.0 | 21.7 |
| HARD STAY DROPPED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| HE SHOOTS OR CHARGES | 2.3 | +0.0 | 0.0 | 95.7 | 3.3 | +0.0 | 0.0 | 146.7 |
| HIS CHARGE LIST | 4.0 | +0.0 | 0.0 | 27.0 | 4.3 | +0.0 | 0.0 | 104.3 |
| HIS LEGAL MOVES | 1.3 | +0.0 | 0.0 | 18.3 | 4.3 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 2.0 | -41.4 | 0.0 | 18.3 | 0.7 | -12.4 | 0.0 | 0.0 |
| HIS RANDOM MOVE | 4.3 | +0.0 | 0.0 | 18.3 | 3.3 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 21.3 | +636.9 | 0.0 | 225.7 | 24.3 | +710.2 | 0.0 | 316.0 |
| HIS TURN DENIED | 1.0 | +11.4 | 113.3 | 0.0 | 1.3 | +58.3 | 48.7 | 103.3 |
| HOLD ODDS | 13.3 | +0.0 | 0.0 | 40.0 | - | - | - | - |
| HOLDER ASSIGNMENT | 17.0 | +2091.9 | 0.0 | 68.3 | - | - | - | - |
| HOLDER AT DEPLOYMENT | - | - | - | - | 2.3 | +351.0 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HONEST WORTH | 1.0 | -25.5 | 21.7 | 45.7 | 1.7 | -83.7 | 105.3 | 103.3 |
| IDLE COST | 11.3 | -79.9 | 0.0 | 110.7 | 4.3 | -38.7 | 0.0 | 86.7 |
| KEEP FALLS | 0.3 | +0.8 | 0.0 | 0.0 | - | - | - | - |
| LANE BY FIGURES | - | - | - | - | 0.7 | +28.1 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 9.3 | +0.0 | 281.7 | 160.0 | 2.7 | +0.0 | 56.7 | 146.7 |
| LONE WIZARD KEPT IN | 2.7 | +181.7 | 0.0 | 0.0 | 0.3 | +39.6 | 0.0 | 0.0 |
| LONG SHOT | 1.3 | -64.3 | 113.3 | 0.0 | - | - | - | - |
| MAKE SURE TOGETHER | - | - | - | - | 0.7 | +2.4 | 0.0 | 0.0 |
| MANOEUVRE | 1.7 | +22.8 | 0.0 | 0.0 | 1.7 | +14.9 | 0.0 | 0.0 |
| MARCH BY THE SUM | 0.7 | +54.4 | 0.0 | 0.0 | 0.3 | +13.0 | 0.0 | 0.0 |
| MARCH CHECK | 1.3 | +32.9 | 0.0 | 27.0 | 2.3 | +183.1 | 0.0 | 0.0 |
| MARCH OVER CASTS | 0.7 | -37.6 | 0.0 | 0.0 | 0.3 | +104.4 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 5.3 | +69.2 | 0.0 | 73.7 | 3.0 | +25.3 | 0.0 | 28.3 |
| MISSILES IN THE MOVE | 8.3 | +489.7 | 0.0 | 54.0 | 4.7 | +77.4 | 0.0 | 28.3 |
| MISSILES NEXT TURN | 9.0 | +372.8 | 0.0 | 54.0 | 5.3 | +43.3 | 0.0 | 28.3 |
| MOVE SPELL IN RANGE | - | - | - | - | 1.7 | +19.5 | 0.0 | 0.0 |
| MOVE SPELL OUT OF RANGE | 5.7 | -79.9 | 0.0 | 0.0 | 2.0 | -86.9 | 0.0 | 0.0 |
| MOVE SPELL SPOT | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 1.3 | +22.2 | 0.0 | 18.3 | 1.3 | +257.5 | 0.0 | 0.0 |
| MOVES UNITS SPELL | 0.3 | +18.4 | 0.0 | 0.0 | - | - | - | - |
| NEARER NOT NEEDED | 5.3 | +261.8 | 0.0 | 21.7 | 6.3 | +478.5 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 3.3 | -132.1 | 0.0 | 18.3 | 2.0 | -77.8 | 28.3 | 0.0 |
| NEXT OBJECTIVE NEARER | - | - | - | - | 20.0 | -1622.0 | 113.3 | 165.3 |
| NO DOUBLE ROUNDS | 2.0 | -80.0 | 135.0 | 45.7 | 1.7 | -67.2 | 105.3 | 103.3 |
| NOT TURNED | 0.3 | +0.0 | 0.0 | 28.3 | - | - | - | - |
| NOT WORTH A CAST | 0.7 | -0.7 | 0.0 | 0.0 | 0.3 | -0.2 | 0.0 | 0.0 |
| OFF BEST | 0.3 | -1.6 | 0.0 | 28.3 | 0.3 | -1.3 | 0.0 | 0.0 |
| ONE CHARGE A CHARGER | 3.0 | +0.0 | 0.0 | 66.7 | 3.3 | +0.0 | 0.0 | 81.0 |
| ONE FIGHT FORMULA | 4.3 | -78.6 | 0.0 | 18.3 | 2.0 | -46.8 | 0.0 | 0.0 |
| ONE OBJECTIVE FORMULA | 8.0 | +391.2 | 0.0 | 40.0 | 5.0 | +114.9 | 0.0 | 0.0 |
| ONE TARGET A SHOOTER | 14.7 | +281.0 | 0.0 | 133.7 | 25.7 | +567.6 | 0.0 | 264.3 |
| OVERRUNS AWAY | 0.3 | +17.0 | 21.7 | 28.3 | - | - | - | - |
| PATHS CROSS | 5.7 | +185.5 | 0.0 | 27.0 | 5.7 | +73.2 | 0.0 | 0.0 |
| PERIAPT WORTH | - | - | - | - | 0.3 | +18.1 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | - | - | - | - | 0.3 | -6.5 | 0.0 | 0.0 |
| PLAN RESULT | 30.7 | +281.8 | 43.3 | 508.7 | 45.7 | +381.0 | 158.7 | 876.0 |
| QUARTER ODDS | 2.3 | +424.8 | 113.3 | 0.0 | - | - | - | - |
| RANDOM MOVE BY FIGURES | 0.7 | +19.7 | 0.0 | 56.7 | 3.3 | +69.2 | 0.0 | 140.0 |
| REDIRECT BY WHAT IT STOPS | 0.3 | -3.5 | 0.0 | 28.3 | - | - | - | - |
| REDIRECT COUNTER | 3.0 | +88.4 | 0.0 | 85.0 | 1.7 | +86.3 | 0.0 | 0.0 |
| REFORMS TO MEET IT | 0.7 | -3.1 | 0.0 | 0.0 | - | - | - | - |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| RESERVE FALL BACK | 0.3 | +135.0 | 0.0 | 0.0 | 1.0 | +51.8 | 0.0 | 0.0 |
| RISK BY ARC | 2.0 | +52.0 | 156.7 | 74.0 | 1.7 | +17.0 | 105.3 | 103.3 |
| RISK BY HIS FIGURE | 9.0 | -75.4 | 0.0 | 189.0 | 17.7 | -359.2 | 0.0 | 227.7 |
| RUN DOWN | 2.0 | -7.2 | 156.7 | 74.0 | 1.0 | -18.5 | 48.7 | 103.3 |
| SCOUT SPOT | 0.7 | +5.9 | 0.0 | 0.0 | - | - | - | - |
| SCOUT WAITS | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 0.3 | -29.3 | 0.0 | 0.0 |
| SEARCH SPOT | 4.3 | +184.7 | 0.0 | 18.3 | 6.0 | +272.6 | 0.0 | 12.7 |
| SET UP TOGETHER | 0.7 | +5.4 | 0.0 | 0.0 | 0.7 | +2.4 | 0.0 | 0.0 |
| SET-UP ANY TARGET | 0.3 | +44.9 | 0.0 | 0.0 | - | - | - | - |
| SHOOTS FROM THE BEST SPOT | 0.3 | +11.7 | 0.0 | 0.0 | 2.0 | +65.1 | 28.3 | 0.0 |
| SHOT RISK POINTS | 12.7 | -23.5 | 0.0 | 83.7 | 15.0 | -108.2 | 0.0 | 362.7 |
| SHOTS IN THE MOVE | 4.7 | +110.0 | 0.0 | 21.7 | 15.0 | +303.4 | 0.0 | 160.0 |
| SPELL OFF EDGE | 0.7 | +80.6 | 0.0 | 0.0 | - | - | - | - |
| SPELL SETS UP CHARGE | 0.3 | +44.9 | 0.0 | 0.0 | - | - | - | - |
| SPELL WORTH | 1.7 | +19.4 | 0.0 | 0.0 | 2.0 | +32.6 | 0.0 | 0.0 |
| SPELLS IN THE FIGHT | - | - | - | - | 0.3 | -33.7 | 0.0 | 103.3 |
| STAND AND SHOOT | - | - | - | - | 0.3 | -2.0 | 21.7 | 0.0 |
| STANDS FOR A REASON | 0.7 | +0.0 | 0.0 | 27.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 5.3 | +0.0 | 140.0 | 56.7 | 16.7 | +0.0 | 215.3 | 305.0 |
| STAY WORTH | 5.3 | +68.5 | 140.0 | 0.0 | 13.3 | +79.6 | 83.7 | 75.0 |
| STUCK PIVOT | - | - | - | - | 1.3 | +0.0 | 0.0 | 140.0 |
| SUPPORT NARROWED | 0.3 | +0.0 | 0.0 | 17.3 | 1.0 | +0.0 | 78.3 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 4.3 | +0.0 | 0.0 | 27.0 | 5.7 | +0.0 | 0.0 | 0.0 |
| THE PROMISED MOVE | 1.3 | +0.0 | 0.0 | 21.7 | 0.3 | +0.0 | 0.0 | 0.0 |
| TIED UP BY THE SUM | - | - | - | - | 0.7 | +77.6 | 83.7 | 0.0 |
| TIME ON OUR SIDE | 9.0 | +277.0 | 0.0 | 40.0 | 25.3 | +425.3 | 0.0 | 28.3 |
| TWO OR MORE ARRIVE | 0.3 | +0.2 | 0.0 | 0.0 | - | - | - | - |
| WAITS AGAIN | 0.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| WAR ENGINE CHARGES | - | - | - | - | 0.3 | +56.4 | 0.0 | 103.3 |
| WAR ENGINE JOBS | - | - | - | - | 1.0 | +0.0 | 85.0 | 0.0 |
| WHO HITS BACK | 0.3 | +22.8 | 0.0 | 28.3 | - | - | - | - |
| WHOLE FIGHT | 0.3 | -2.1 | 21.7 | 28.3 | - | - | - | - |
| WHOLE FIGHT GAIN | 0.7 | +52.3 | 98.3 | 28.3 | - | - | - | - |
| WIDER SPREAD | 1.7 | -1.4 | 135.0 | 45.7 | 1.0 | -15.8 | 83.7 | 103.3 |
| WOUNDS ON THE RANKS | 3.0 | +202.0 | 0.0 | 0.0 | - | - | - | - |

### Rule changes: h5-smoke-8766b98

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HOLDER ASSIGNMENT | 51 | 51 | 47 | 15.67 | +2548 | +54.2 |
| HIS SHOT LIST | 137 | 137 | 38 | 12.67 | +634 | +16.7 |
| LEGAL CHARGES ONLY | 36 | 36 | 36 | 12.00 | +0 | +0.0 |
| PATHS CROSS | 34 | 34 | 34 | 11.33 | +776 | +22.8 |
| DEPLOY BY FIGURES | 46 | 46 | 32 | 10.67 | +716 | +22.4 |
| ONE TARGET A SHOOTER | 121 | 121 | 29 | 9.67 | +187 | +6.4 |
| SEARCH SPOT | 31 | 31 | 29 | 9.67 | +1372 | +47.3 |
| FIVE ACTION | 257 | 256 | 28 | 9.33 | +430 | +15.4 |
| SHOT RISK POINTS | 83 | 83 | 18 | 6.00 | +237 | +13.2 |
| NEXT OBJECTIVE NEARER | 60 | 60 | 11 | 3.67 | +257 | +23.3 |
| RANDOM MOVE BY FIGURES | 12 | 12 | 10 | 3.33 | +267 | +26.7 |
| LONE WIZARD KEPT IN | 9 | 9 | 9 | 3.00 | +664 | +73.8 |
| FALLS SHORT | 92 | 78 | 8 | 2.67 | +19 | +2.4 |
| MARCH CHECK | 11 | 11 | 8 | 2.67 | +315 | +39.4 |
| TIME ON OUR SIDE | 103 | 90 | 8 | 2.67 | +81 | +10.1 |
| IDLE COST | 47 | 39 | 7 | 2.33 | +29 | +4.1 |
| MISSILES IN THE MOVE | 39 | 29 | 6 | 2.00 | +186 | +31.1 |
| REDIRECT COUNTER | 14 | 12 | 6 | 2.00 | +303 | +50.5 |
| ADVANCE LANE KEPT | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| CASTER AWAY FROM SCREEN | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| CASTING BLOCK | 6 | 6 | 5 | 1.67 | +122 | +24.4 |
| COVER ONCE | 46 | 38 | 5 | 1.67 | +34 | +6.8 |
| SHOTS IN THE MOVE | 59 | 54 | 5 | 1.67 | +91 | +18.2 |
| CHARGE NOT DECLARED | 4 | 4 | 4 | 1.33 | -534 | -133.6 |
| FEATURE BUFFS | 23 | 23 | 4 | 1.33 | +130 | +32.6 |
| MANOEUVRE | 10 | 10 | 4 | 1.33 | +113 | +28.3 |
| MAX FOR POSITIONING | 25 | 24 | 4 | 1.33 | +24 | +6.0 |
| MOVE TO CHARGE COMPUTED | 8 | 8 | 4 | 1.33 | +365 | +91.3 |
| RESERVE FALL BACK | 4 | 4 | 4 | 1.33 | +560 | +140.0 |
| STUCK PIVOT | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| ARTILLERY RE-ROLL WEIGHED | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| COMBAT PIVOT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| FOUR ROUNDS | 12 | 11 | 3 | 1.00 | +186 | +61.9 |
| HOLDER AT DEPLOYMENT | 7 | 7 | 3 | 1.00 | +78 | +26.1 |
| HOLDS AMBUSHERS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| MARCH BY THE SUM | 3 | 3 | 3 | 1.00 | +202 | +67.4 |
| MISSILES NEXT TURN | 43 | 29 | 3 | 1.00 | +23 | +7.8 |
| RISK BY ARC | 11 | 10 | 3 | 1.00 | +194 | +64.7 |
| SHOOTS FROM THE BEST SPOT | 7 | 7 | 3 | 1.00 | +6 | +2.0 |
| CHARGE LOSSES | 35 | 35 | 2 | 0.67 | +210 | +105.0 |
| LANE BY FIGURES | 2 | 2 | 2 | 0.67 | +84 | +42.2 |
| NEARER NOT NEEDED | 35 | 33 | 2 | 0.67 | +45 | +22.3 |
| OFF BEST | 2 | 2 | 2 | 0.67 | -9 | -4.4 |
| ONE OBJECTIVE FORMULA | 39 | 26 | 2 | 0.67 | +154 | +76.8 |
| QUARTER ODDS | 7 | 7 | 2 | 0.67 | +314 | +157.1 |
| SCOUT WAITS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| STAY WORTH | 56 | 50 | 2 | 0.67 | +19 | +9.5 |
| WHOLE FIGHT GAIN | 2 | 2 | 2 | 0.67 | +140 | +69.8 |
| WOUNDS ON THE RANKS | 9 | 9 | 2 | 0.67 | +209 | +104.4 |
| AFTERMATH IN POINTS | 1 | 1 | 1 | 0.33 | +9 | +8.5 |
| BEST PRIZE | 1 | 1 | 1 | 0.33 | -4 | -4.0 |
| CANNON PLANNED TARGET | 8 | 8 | 1 | 0.33 | -3 | -2.7 |
| CANNON SIGHT KEPT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CARRIES OUT SET-UP | 1 | 1 | 1 | 0.33 | -0 | -0.2 |
| CHAFF IN THE MOVE | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| EDGE GIVE GROUND | 2 | 1 | 1 | 0.33 | +32 | +31.5 |
| FIGHT TO THE END | 6 | 5 | 1 | 0.33 | +69 | +69.2 |
| FIRE IN ORDER | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 1 | 1 | 1 | 0.33 | +128 | +128.4 |
| HARD STAY DROPPED | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| HIS TURN DENIED | 7 | 7 | 1 | 0.33 | +13 | +12.7 |
| KEEP FALLS | 1 | 1 | 1 | 0.33 | +24 | +24.2 |
| MOVES UNITS SPELL | 1 | 1 | 1 | 0.33 | +55 | +55.1 |
| ONE FIGHT FORMULA | 19 | 14 | 1 | 0.33 | +2 | +2.4 |
| OVERRUNS AWAY | 1 | 1 | 1 | 0.33 | +39 | +39.3 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.33 | +54 | +54.4 |
| PIVOT GUARDS FLANK | 1 | 1 | 1 | 0.33 | -20 | -19.6 |
| REFUSING RETIRES | 1 | 1 | 1 | 0.33 | -0 | -0.2 |
| RISK BY HIS FIGURE | 80 | 80 | 1 | 0.33 | +183 | +182.7 |
| SET UP TOGETHER | 4 | 4 | 1 | 0.33 | +8 | +8.5 |
| TIED UP BY THE SUM | 2 | 2 | 1 | 0.33 | +69 | +69.2 |
| WAR ENGINE CHARGES | 1 | 1 | 1 | 0.33 | +157 | +157.2 |
| WHO HITS BACK | 1 | 1 | 1 | 0.33 | +5 | +4.8 |
| ALREADY CARRIED | 1 | not checked | - | - | - | - |
| CAST JOB | 6 | 6 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 8 | trace | - | - | - | - |
| CATCH FLIERS | 1 | not checked | - | - | - | - |
| CHARGE NOW FIRST | 8 | 8 | 0 | 0.00 | - | - |
| CHARGER SLAIN LOST | 4 | 4 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 12 | not checked | - | - | - | - |
| ENGINEER BY LORE | 2 | 2 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 12 | 11 | 0 | 0.00 | - | - |
| FIGHT LIFT | 4 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 27 | not checked | - | - | - | - |
| GUN FIGURES | 12 | not checked | - | - | - | - |
| HE SHOOTS OR CHARGES | 17 | 17 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 25 | 25 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 17 | 17 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 8 | 8 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 23 | 23 | 0 | 0.00 | - | - |
| HOLD ODDS | 40 | 40 | 0 | 0.00 | - | - |
| HONEST WORTH | 8 | 8 | 0 | 0.00 | - | - |
| LONG SHOT | 4 | 3 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 2 | not checked | - | - | - | - |
| MARCH OVER CASTS | 3 | 3 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 5 | 4 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 23 | trace | - | - | - | - |
| MOVE SPELL SPOT | 4 | not checked | - | - | - | - |
| NEXT CHARGE BY LIST | 16 | 16 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 11 | 10 | 0 | 0.00 | - | - |
| NOT TURNED | 1 | 1 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 3 | not checked | - | - | - | - |
| ONE CHARGE A CHARGER | 19 | 19 | 0 | 0.00 | - | - |
| PLAN RESULT | 229 | trace | - | - | - | - |
| REDIRECT BY WHAT IT STOPS | 1 | 1 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 2 | 2 | 0 | 0.00 | - | - |
| RUN DOWN | 9 | 8 | 0 | 0.00 | - | - |
| SCOUT SPOT | 2 | 2 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 1 | 1 | 0 | 0.00 | - | - |
| SET-UP ANY TARGET | 1 | not checked | - | - | - | - |
| SPELL OFF EDGE | 2 | not checked | - | - | - | - |
| SPELL SETS UP CHARGE | 1 | not checked | - | - | - | - |
| SPELL WORTH | 11 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 1 | 1 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 4 | 4 | 0 | 0.00 | - | - |
| STANDS STILL | 66 | 66 | 0 | 0.00 | - | - |
| SUPPORT NARROWED | 4 | 4 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 30 | not checked | - | - | - | - |
| THE PROMISED MOVE | 5 | not checked | - | - | - | - |
| TWO OR MORE ARRIVE | 1 | not checked | - | - | - | - |
| WAITS AGAIN | 6 | 6 | 0 | 0.00 | - | - |
| WAR ENGINE JOBS | 3 | 3 | 0 | 0.00 | - | - |
| WHOLE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| WIDER SPREAD | 8 | 7 | 0 | 0.00 | - | - |

### Off best figure: h5-smoke-8766b98

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| HOLDER ASSIGNMENT | rule | 2.67 | - | 19.4 |
| PATHS CROSS | rule | - | 1.33 | 11.1 |
| CHARGE NOT DECLARED | rule | 0.33 | 0.67 | 178.2 |
| AFTERMATH BAND | gate | 0.33 | - | 4.8 |
| BEST PRIZE | rule | - | 0.33 | 4.0 |
| CANNON PLANNED TARGET | rule | - | 0.33 | 2.7 |
| JOB FIRST | gate | - | 0.33 | 4.0 |
| PIVOT GUARDS FLANK | rule | - | 0.33 | 19.6 |

### Plans: h5-smoke-8766b98

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.7 | 40% | 82 | 74 | 90% |
| Mine | move | 26.3 | 94% | 2122 | 0 | 0% |
| Mine | shoot | 2.3 | 57% | 439 | 208 | 47% |
| Mine | support | 0.3 | 0% | 0 | 0 | - |
| Opponent | charge | 1.7 | 60% | 392 | 101 | 26% |
| Opponent | move | 35.3 | 95% | 2056 | 0 | 0% |
| Opponent | shoot | 8.7 | 54% | 238 | 280 | 118% |

### Battle groups: h5-smoke-8766b98

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 3.0 | 0% | - | - | - | - | - | - | - | - |
| Opponent | REDIRECT COUNTER | 1.7 | 20% | 100% | 0% | - | 100% | 0% | 0% | 0% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: h5-smoke-8766b98

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 3 | 0 (3) | 0 | 0 | 100 | 67% | 4.0 | - | 0 (3) | - | 0 (3) | - |
| Mine | Character | 15 | 15 (15) | 15 | 0 | 3 | 7% | 2.6 | 30 (4) | 7 (7) | 19 (4) | 18 (13) | 0 (2) |
| Mine | Clean-up | 3 | 0 (3) | 0 | 0 | 33 | 67% | 4.0 | 0 (1) | 0 (2) | - | 0 (3) | - |
| Mine | Fast Hammer | 2 | 38 (2) | 38 | 0 | 100 | 50% | 5.0 | - | 76 (1) | 0 (1) | 38 (2) | - |
| Mine | Hammer | 7 | 30 (7) | 9 | 22 | 14 | 29% | 3.4 | 0 (1) | 24 (3) | 51 (3) | 32 (5) | 25 (2) |
| Mine | Holder | 5 | 166 (5) | 92 | 73 | 0 | 60% | 2.5 | - | 270 (3) | 0 (2) | 179 (3) | 149 (2) |
| Mine | Shooter | 2 | 531 (2) | 162 | 369 | 50 | 0% | 1.5 | - | 877 (1) | 185 (1) | 531 (2) | - |
| Mine | Wizard | 3 | 0 (3) | 0 | 0 | 0 | 0% | 2.7 | - | 0 (1) | 0 (2) | 0 (2) | 0 (1) |
| Opponent | Chaff | 2 | 153 (2) | 17 | 136 | 37 | 0% | 3.5 | - | 153 (2) | - | 153 (2) | - |
| Opponent | Character | 7 | 15 (7) | 15 | 0 | 5 | 43% | 1.8 | 18 (4) | 0 (1) | 0 (2) | 17 (3) | 11 (4) |
| Opponent | Clean-up | 4 | 116 (4) | 0 | 116 | 51 | 100% | - | - | 95 (3) | 237 (1) | 183 (3) | 0 (1) |
| Opponent | Hammer | 10 | 37 (10) | 13 | 23 | 20 | 40% | 3.0 | 0 (1) | 41 (8) | 26 (1) | 32 (7) | 48 (3) |
| Opponent | Holder | 3 | 108 (3) | 22 | 86 | 0 | 67% | 4.0 | - | 0 (1) | 170 (2) | 93 (2) | 141 (1) |
| Opponent | Shooter | 3 | 0 (3) | 0 | 0 | 67 | 0% | 1.3 | - | 0 (3) | - | 0 (2) | 0 (1) |
| Opponent | War machine | 4 | 0 (4) | 0 | 0 | 81 | 0% | 2.0 | - | - | 0 (4) | - | 0 (4) |
| Opponent | Wizard | 1 | 0 (1) | 0 | 0 | 0 | 0% | 5.0 | 0 (1) | - | - | 0 (1) | - |

### Charged fights: h5-smoke-8766b98

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 3 | 154 | 58 | 2.0 | 1.2 | 29 | 14 | +15 | 1 of 6 | 4 of 6 | +0 | +18 |
| Opponent | Chaos Dwarfs | 2 | 168 | 85 | 1.5 | 1.0 | 57 | 103 | -47 | 2 of 3 | 1 of 3 | - | -47 |
| Opponent | Skaven | 1 | 0 | 65 | 1.0 | 1.0 | 65 | 0 | +65 | 0 of 1 | 1 of 1 | - | +65 |
| **Opponent** | all armies | 3 | 112 | 78 | 1.3 | 1.0 | 59 | 78 | -19 | 2 of 4 | 2 of 4 | - | -19 |

### Effective charges: h5-smoke-8766b98

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 6 | 0 | 0 | 3 (net +37) | 0 | 0 | 3 (net -7) | 0 | 50% (3 of 6) |
| Opponent | Chaos Dwarfs | 3 | 1 (net +0) | 0 | 1 (net -310) | 0 | 0 | 1 (net +170) | 0 | 33% (1 of 3) |
| Opponent | Skaven | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +65) | 0 | 0% (0 of 1) |

### Charged fights, damage counted: h5-smoke-8766b98

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Effective (55-75%) | 3 | 61 | 155 | +37 | 37 | 9 | +28 | +46.2 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 | 364 | 190 | -7 | 81 | 35 | +46 | +12.6 |
| Mine | All fights | 6 | 212 | 172 | +15 | 59 | 22 | +37 | +17.4 |
| Opponent | Long shot (under 50%) | 1 | 480 | 272 | +0 | 99 | 206 | -106 | -22.1 |
| Opponent | Effective (55-75%) | 1 | 310 | 322 | -310 | 0 | 399 | -399 | -128.6 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 266 | 118 | +118 | 118 | 90 | +27 | +10.3 |
| Opponent | All fights | 4 | 330 | 207 | -19 | 84 | 196 | -113 | -34.1 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| h5-smoke-8766b98 | move | 11 | 3 (27%) | 3 (27%) | 1 (9%) | 7 (64%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0103, L0120 |
| Periapt of Soul Exchange | Opponent | L0120 |
| Ring of Doom | Mine | L0204 |

# Doctrine scorecard: h5-mine-8766b98-p4

### Scorecard: h5-mine-8766b98-p4

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0115 | 1 | 1 | Mine | no | 4 | - | 0 | 2 | 0 | 0 | 0 | 0 |
| L0115 | 1 | 1 | Opponent | yes | 2 | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L0132 | 6 | 1 | Mine | no | 13 | 3 | 0 | 2 | 0 | 0 | 0 | 0 |
| L0132 | 6 | 1 | Opponent | no | 6 | 3 | 3 | 6 | 0 | 0 | 0 | 340 |
| L0216 | 6 | 1 | Mine | no | 2 | - | 0 | 4 | 0 | 0 | 0 | 170 |
| L0216 | 6 | 1 | Opponent | no | 0 | 2 | 3 | 0 | 1 | 0 | 0 | 100 |
| L0232 | 4 | 1 | Mine | no | 1 | 3 | 3 | 1 | 2 | 0 | 0 | 170 |
| L0232 | 4 | 1 | Opponent | no | 0 | 2 | 6 | 1 | 1 | 0 | 0 | 170 |
| L0316 | 4 | 1 | Mine | no | 0 | 5 | 2 | 1 | 0 | 0 | 0 | 370 |
| L0316 | 4 | 1 | Opponent | no | 0 | 3 | 1 | 2 | 0 | 0 | 0 | 0 |
| L0333 | 3 | 1 | Mine | yes | 6 | 4 | 1 | 0 | 0 | 0 | 0 | 110 |
| L0333 | 3 | 1 | Opponent | yes | 1 | 3 | 2 | 4 | 0 | 0 | 0 | 0 |
| L0420 | 6 | 1 | Mine | no | 12 | 2 | 4 | 1 | 0 | 0 | 0 | 310 |
| L0420 | 6 | 1 | Opponent | no | 4 | - | 0 | 2 | 1 | 0 | 0 | 485 |
| L0435 | 3 | 1 | Mine | no | 1 | 3 | 3 | 1 | 0 | 0 | 0 | 0 |
| L0435 | 3 | 1 | Opponent | no | 0 | 5 | 2 | 2 | 0 | 0 | 0 | 0 |
| L0522 | 6 | 1 | Mine | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 423 |
| L0522 | 6 | 1 | Opponent | no | 5 | 2 | 3 | 0 | 1 | 0 | 0 | 0 |
| L0609 | 3 | 1 | Mine | no | 0 | - | 1 | 3 | 0 | 0 | 0 | 230 |
| L0609 | 3 | 1 | Opponent | no | 11 | - | 0 | 2 | 0 | 0 | 0 | 0 |
| L0625 | 1 | 1 | Mine | no | 1 | - | 0 | 2 | 0 | 0 | 0 | 60 |
| L0625 | 1 | 1 | Opponent | no | 3 | 2 | 4 | 2 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 9% | 3.6 | 3.3 | 1.3 | 1.7 | 0.2 | 0.0 | 0.0 | 167.5 |
| **Average** | | | Opponent | 18% | 2.9 | 2.7 | 2.5 | 2.0 | 0.4 | 0.0 | 0.0 | 99.5 |

### KPIs: h5-mine-8766b98-p4

Rules off - Opponent only: HOLDER ASSIGNMENT, QUARTER ODDS.

Morten 2026-11-10; 11 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 45% (22 of 49) | 0% (0 of 55) | 21% (22 of 104) |
| Winner chose to follow up after the loser gave ground |  | 79% (11 of 14); on the table 79% | 100% (8 of 8); on the table 100% | 86% (19 of 22); on the table 86% |
| Winner chose to pursue after the loser fell back in good order |  | 100% (2 of 2); on the table 100% | 0% (0 of 1); on the table 0% | 67% (2 of 3); on the table 67% |
| Winner chose to pursue after the loser fled |  | 100% (3 of 3); on the table 100% | 100% (3 of 3); on the table 100% | 100% (6 of 6); on the table 100% |
| Winner chose to follow up or pursue (all three) |  | 84% (16 of 19); on the table 84% | 92% (11 of 12); on the table 92% | 87% (27 of 31); on the table 87% |
| Magic missiles tried each own turn | 50%+ | 30% (40 of 132) | 31% (13 of 42) | 30% (53 of 174) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 41% (40 of 98) | 35% (13 of 37) | 39% (53 of 135) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 75% (3 of 4) | 67% (16 of 24) | 68% (19 of 28) |
| Points that never fought | lower | 49% (10667 of 21594) | 54% (11925 of 21995) | 52% (22592 of 43589) |
|   infantry points that never fought | lower | 58% (3917 of 6804) | 87% (4517 of 5211) | 70% (8434 of 12015) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 57% (46 of 81) | 47% (41 of 87) | 52% (87 of 168) |
| Bound items with a magic missile used (at least once a game) |  | 83% (5 of 6); 1.2 uses a game | 40% (2 of 5); 1.0 uses a game | 64% (7 of 11); 1.1 uses a game |
| Bound items with another spell used |  | 100% (2 of 2); 0.3 uses a game | 0.0 uses a game | 100% (2 of 2); 0.1 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 62% (5 of 8); 0.5 uses a game | 75% (3 of 4); 0.3 uses a game | 67% (8 of 12); 0.4 uses a game |
|   their share of the points of units over 100 pts | lower | 49% (8117 of 16500) | 39% (7493 of 19294) | 44% (15610 of 35794) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 2.6 (32%) | 1.5 (55%) | 4.1 (37%) |
| MARCHED: its unit marched | 2.2 (26%) | 0.7 (28%) | 2.9 (26%) |
| CHARGED: its unit charged | 0.3 (3%) | 0.0 (0%) | 0.3 (2%) |
| IN COMBAT: engaged in combat | 0.8 (10%) | 0.1 (3%) | 0.9 (8%) |
| GONE: slain | 1.5 (18%) | 0.3 (10%) | 1.8 (17%) |
| OFF THE TABLE: off the table or not arrived | 0.7 (9%) | 0.1 (3%) | 0.8 (7%) |
| STUPIDITY: Stupidity | 0.2 (2%) | 0.0 (0%) | 0.2 (2%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 5.3 | 0.5 | 2.5 | 4.8 | 0.6 |
| not cast | 5.6 | 0.6 | 3.5 | 11.0 | 15.7 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.1 (3%) | 0.0 (0%) | 0.4 (2%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.2 (29%) | 1.2 (33%) | 4.1 (37%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.9 (26%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (2%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.1 (2%) | 0.0 (0%) | 0.5 (15%) | 0.9 (8%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (1%) |
| GONE: slain | 0.5 (10%) | 0.0 (0%) | 0.4 (10%) | 1.8 (17%) | 1.5 (10%) |
| OFF THE TABLE: off the table or not arrived | 0.3 (5%) | 0.4 (57%) | 0.4 (10%) | 0.8 (7%) | 1.1 (7%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.0 (0%) | 0.2 (5%) | 0.2 (2%) | 0.1 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.2 (3%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 4.5 (81%) | 0.1 (14%) | 0.8 (23%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 12.5 (79%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.9 a game | 0.8 a game | 1.4 a game |
| stood (cast and not dispelled) | 57% (12 of 21) | 40% (2 of 5) | 54% (14 of 26) |
| the unit moved after it | 83% (10 of 12) | 100% (2 of 2) | 86% (12 of 14) |
| it charged on its next turn | 8% (1 of 12) | 0% (0 of 2) | 7% (1 of 14) |
| the enemy charged it first | 42% (5 of 12) | 0% (0 of 2) | 36% (5 of 14) |
| it fought by the end of its next turn | 8% (1 of 12) | 0% (0 of 2) | 7% (1 of 14) |
| it moved out of a charge the enemy had planned (not charged first) | 8% (1 of 12) | 0% (0 of 2) | 7% (1 of 14) |
| none of these (no charge, no fight, no charge escaped) | 50% (6 of 12) | 100% (2 of 2) | 57% (8 of 14) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 66% (190 of 288) | 52% (141 of 272) | 59% (331 of 560) |
|   cavalry | 48% (12 of 25) | 55% (30 of 55) | 52% (42 of 80) |
|   character | 89% (24 of 27) | 35% (17 of 48) | 55% (41 of 75) |
|   chariot | 67% (32 of 48) | 73% (11 of 15) | 68% (43 of 63) |
|   infantry | 52% (36 of 69) | 53% (56 of 106) | 53% (92 of 175) |
|   monster | 67% (4 of 6) | 50% (3 of 6) | 58% (7 of 12) |
|   war machine | 73% (82 of 113) | 57% (24 of 42) | 68% (106 of 155) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.1 (23%) | 4.1 (34%) | 6.2 (30%) |
| CHARGED: it charged | 0.3 (3%) | 1.6 (14%) | 1.9 (9%) |
| FLEEING: it fled or was fleeing | 0.3 (3%) | 0.0 (0%) | 0.3 (1%) |
| IN COMBAT: it fought this turn or the last | 0.4 (4%) | 0.0 (0%) | 0.4 (2%) |
| MOVED: a war machine that moved | 1.1 (12%) | 1.1 (9%) | 2.2 (10%) |
| NO TARGET IN RANGE | 2.5 (29%) | 3.1 (26%) | 5.6 (27%) |
| ONLY IN COMBAT: the only targets were in combat | 0.2 (2%) | 0.5 (5%) | 0.7 (3%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.9 (21%) | 0.9 (8%) | 2.8 (14%) |
| SHELTERED: the target was sheltered | 0.1 (1%) | 0.4 (3%) | 0.5 (2%) |
| OTHER BAR | 0.1 (1%) | 0.2 (2%) | 0.3 (1%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 4.9 | 0.7 | 89% | 2.9 pts | 14 pts |
| character | 4.0 | 0.8 | 84% | 3.0 pts | 12 pts |
| chariot | 3.9 | 3.0 | 56% | 18.4 pts | 72 pts |
| infantry | 11.7 | 3.7 | 73% | 6.1 pts | 72 pts |
| monster | 0.9 | 0.3 | 70% | 5.3 pts | 5 pts |
| war machine | 9.6 | 6.7 | 64% | 14.1 pts | 135 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 1.6 | 4.6 | 3.1 |
| Charges that made contact a game | 1.2 | 3.6 | 2.4 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.40 declared, 0.20 contact (5 units) | 0.00 declared, 0.00 contact (3 units) | 0.25 declared, 0.12 contact (8 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 0.50 declared, 0.50 contact (2 units) | 0.50 declared, 0.50 contact (2 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.20 declared, 0.15 contact (79 units) | 0.53 declared, 0.41 contact (95 units) | 0.38 declared, 0.29 contact (174 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 36% (5 of 14) | 0% (0 of 2) | 0% (0 of 1) | 29% (5 of 17) |
| Character in a unit | 87% (13 of 15) | 33% (2 of 6) | - | 71% (15 of 21) |
| Character on its own | 100% (5 of 5) | 67% (8 of 12) | 12% (2 of 16) | 45% (15 of 33) |
| Chariot | 100% (1 of 1) | 67% (6 of 9) | - | 70% (7 of 10) |
| Infantry | 37% (11 of 30) | 30% (6 of 20) | - | 34% (17 of 50) |
| Monster | 70% (7 of 10) | 100% (2 of 2) | - | 75% (9 of 12) |
| Monstrous | 100% (5 of 5) | 0% (0 of 1) | - | 83% (5 of 6) |
| War Machines | 76% (13 of 17) | 50% (1 of 2) | - | 74% (14 of 19) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 78% (7 of 9); on the table 78% | 25% (25 of 102) | 41% | 64% (14 of 22) | 83% (5 of 6); 3.2 uses a game | 100% (2 of 2); 0.8 uses a game | 67% (4 of 6); 1.0 uses a game |
| Chaos Dwarfs | 4 | 100% (9 of 9); on the table 100% | 50% (15 of 30) | 47% | 38% (12 of 32) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
| Dwarfen Mountain Holds | 3 | 0% (0 of 1); on the table 0% | - | 64% | 74% (20 of 27) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 1 | - | 25% (3 of 12) | 95% | 50% (6 of 12) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| High Elf Realms | 1 | 100% (1 of 1); on the table 100% | 17% (1 of 6) | 65% | 29% (2 of 7) | 50% (1 of 2); 5.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 2 | 75% (3 of 4); on the table 75% | - | 66% | 42% (5 of 12) | 0.0 uses a game | 0.0 uses a game | 100% (2 of 2); 1.0 uses a game |
| Skaven | 1 | - | 83% (5 of 6) | 65% | 57% (4 of 7) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Tomb Kings of Khemri | 1 | - | - | 38% | 40% (2 of 5) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 1 | 100% (2 of 2); on the table 100% | 0% (0 of 6) | 41% | 17% (1 of 6) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 2 | 100% (4 of 4); on the table 100% | - | 31% | 50% (8 of 16) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 2 | 100% (1 of 1); on the table 100% | 33% (4 of 12) | 50% | 59% (13 of 22) | 33% (1 of 3); 3.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (h5-mine-8766b98-p4, 11 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 41% (12) | 50% (4) | 43% (16) |
| ...free all their last turn and able to turn (per game) | 0.64 | 0.36 | 1.00 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.27 | 0.00 | 0.27 |
| ...with the charger already in that arc before they moved (per game) | 0.64 | 0.27 | 0.91 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.09 | 0.09 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.18 | 0.00 | 0.18 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.09 | 0.36 | 0.45 |

### Quality by phase: h5-mine-8766b98-p4

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.2 | 2.0 |
| Strategy | Charge objectives carried out (made contact) | 44% (7 of 16) | 50% (24 of 48) |
| Strategy | Shoot objectives carried out (shot that target) | 51% (78 of 153) | 41% (28 of 68) |
| Strategy | Support requests answered (helper made contact too) | - | 67% (2 of 3) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 50% (1 of 2) | - |
| Strategy | Hexes on a unit its side charged or shot that turn | - | 50% (2 of 4) |
| Strategy | Joined characters whose unit fought | 46% (11 of 24) | 8% (1 of 13) |
| Strategy | Lone characters that fought | 70% (16 of 23) | 71% (17 of 24) |
| Movement | Charges halted short of contact | 0.0 | 0.2 |
| Movement | Idle units | 1.7 | 2.0 |
| Movement | Points that never moved of their own | 167.5 | 99.5 |
| Movement | Fights charged into per game | 1.2 | 3.4 |
| Movement | Charges with odds: long shots (under 50%) | 3 of 11, net +0 | 15 of 35, net +53 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 11 | 9 of 35, net +156 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 1 of 11, net +80 | 2 of 35, net +42 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 4 of 11, net +180 | 4 of 35, net +132 |
| Shooting | Shots by shooting units (incl. breath weapons) | 10.0 | 12.4 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 45% (50 of 110) | 46% (62 of 136) |
| Shooting | Points destroyed by shooting units | 77.9 | 20.7 |
| Shooting | War machine shots | 7.5 | 2.2 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 43% (35 of 82) | 12% (3 of 24) |
| Shooting | Points destroyed by war machines | 21.3 | 29.1 |
| Magic | Magic missiles cast | 1.9 | 0.6 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 29% (6 of 21) | 14% (1 of 7) |
| Magic | Wounds caused by magic missiles | 5.0 | 1.5 |
| Magic | Wounds caused by other spells | 0.6 | 0.2 |
| Magic | Points destroyed by magic (all spells) | 71.0 | 20.5 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.4 / 0.0 / 0.5 / 0.0 | 2.7 / 0.4 / 0.1 / 0.0 |
| Combat | Points destroyed in combat | 137.7 | 294.0 |
| Combat | Points run down | 9.5 | 104.1 |
| Combat | Net points per charged fight, damage counted | +123 | +88 |
| Combat | Net per 100 charger points, damage counted | +49.1 | +29.7 |
| Combat | First round won (charged fights) | 85% | 56% |
| Combat | Net points per charged fight | +104 | +111 |
| Combat | Net points per supported fight / lone fight | - / +104 | +306 / +100 |
| Combat | Charged fights on a top-3 enemy unit | 6 of 13 | 16 of 37 |
| Game | Points lost | 579.3 | 418.8 |
| Game | VP from objectives | 579.1 | 846.4 |
| Game | Lone holders (player turns) | 3.6 | 2.9 |

- Mine won / drew / lost: 1 / 3 / 7 of 11 ended games (of 11); mean margin (Mine - Opponent) -458 VP
- The side that went first won 4 of 8 games with a winner
- Points traded per game (both sides' losses): 998
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: h5-mine-8766b98-p4

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.5 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.3 | +28.4 | 0.0 | 0.0 | - | - | - | - |
| ALREADY CARRIED | 0.2 | +0.0 | 29.3 | 11.8 | - | - | - | - |
| ARTILLERY RE-ROLL WEIGHED | 1.9 | +0.0 | 0.0 | 33.6 | 0.3 | +0.0 | 0.0 | 0.0 |
| BEST PRIZE | 0.1 | -3.9 | 10.4 | 0.0 | 0.4 | -47.9 | 17.5 | 91.8 |
| BLOWS WHERE AIMED | 0.2 | -1.6 | 14.4 | 0.0 | 0.7 | -159.5 | 81.8 | 35.5 |
| CANNON PLAN MISSED | 0.7 | +0.0 | 49.0 | 17.3 | 0.5 | +0.0 | 16.4 | 0.0 |
| CANNON PLANNED TARGET | 6.5 | +90.8 | 193.0 | 137.7 | 2.0 | +74.8 | 61.4 | 9.1 |
| CANNON SIGHT KEPT | 1.6 | +0.0 | 0.0 | 10.9 | 0.7 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT COUNTER | 0.1 | +0.0 | 45.9 | 0.0 | - | - | - | - |
| CARRIES OUT SET-UP | - | - | - | - | 0.2 | -0.9 | 31.0 | 17.7 |
| CAST JOB | 0.5 | +10.5 | 70.8 | 0.0 | 0.2 | +2.0 | 10.9 | 0.0 |
| CASTER AWAY FROM SCREEN | 0.6 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.6 | +48.3 | 0.0 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | 1.1 | +0.0 | 0.0 | 32.3 | 0.4 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | - | - | - | - | 0.2 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | 0.3 | +12.3 | 0.0 | 0.0 | 1.3 | +55.5 | 0.0 | 7.5 |
| CHAFF PASSED | 0.2 | -0.0 | 0.0 | 16.9 | 0.5 | +0.0 | 0.0 | 0.0 |
| CHAMPION TAKES THE CHALLENGE | 0.1 | +0.4 | 0.0 | 0.0 | - | - | - | - |
| CHARACTER GUNS | 0.4 | +0.0 | 0.0 | 26.3 | 0.5 | +0.0 | 0.0 | 0.0 |
| CHARGE LOSSES | 5.5 | -141.1 | 0.0 | 94.6 | 5.3 | -273.8 | 0.0 | 72.8 |
| CHARGE NOT DECLARED | 0.1 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 89.8 | 35.5 |
| CHARGE NOW FIRST | 0.5 | +0.0 | 91.9 | 5.5 | 2.1 | +0.0 | 186.6 | 27.5 |
| CHARGER SLAIN LOST | 0.2 | -3.0 | 0.0 | 4.7 | 0.3 | -11.6 | 10.0 | 35.5 |
| CHEAP HELPER | - | - | - | - | 0.1 | +0.0 | 0.0 | 10.5 |
| CHEAPEST HOLDER | - | - | - | - | 0.7 | -61.4 | 9.7 | 36.2 |
| COMBAT PIVOT | 0.4 | +0.0 | 0.0 | 51.4 | 0.4 | +0.0 | 0.0 | 52.3 |
| CONTINUE AHEAD WEIGHED | 0.1 | +0.0 | 9.3 | 0.0 | - | - | - | - |
| CONVEYANCE SEARCH | 1.7 | +312.9 | 58.5 | 44.1 | 0.3 | +15.7 | 0.0 | 0.0 |
| COVER ONCE | 8.7 | -844.3 | 0.0 | 143.0 | 3.4 | -154.7 | 0.0 | 9.5 |
| DEFENSIVE FLOOR | - | - | - | - | 0.1 | +0.3 | 0.0 | 0.0 |
| DEPLOY BY FIGURES | 9.6 | +43.6 | 0.0 | 10.9 | 8.0 | +31.8 | 0.0 | 7.2 |
| EDGE GIVE GROUND | 0.1 | +2.9 | 17.5 | 0.0 | 0.2 | +10.2 | 20.9 | 9.5 |
| ENGINEER BY LORE | 0.4 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | - | - | - | - | 0.1 | +3.3 | 0.0 | 0.0 |
| FALL BACK GOOD ORDER | 1.0 | +3.0 | 60.4 | 14.9 | 3.1 | +0.9 | 237.5 | 74.6 |
| FALLBACK BY WORTH | 0.4 | +0.2 | 0.0 | 6.6 | 0.4 | +0.0 | 0.0 | 0.0 |
| FALLS SHORT | 2.9 | +54.1 | 0.0 | 29.6 | 23.6 | +302.3 | 0.0 | 121.9 |
| FEATURE BUFFS | 3.2 | +83.0 | 0.0 | 46.5 | 0.8 | +18.0 | 0.0 | 20.9 |
| FIGHT LIFT | - | - | - | - | 0.2 | +0.8 | 0.0 | 8.6 |
| FIGHT TO THE END | 0.6 | +39.5 | 46.0 | 10.2 | 1.8 | +93.7 | 143.2 | 27.2 |
| FIRE IN ORDER | 0.3 | +0.0 | 10.4 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| FIVE ACTION | 47.8 | +3116.8 | 662.3 | 593.6 | 51.4 | +3285.0 | 464.1 | 507.2 |
| FLANK NOT WEIGHED | 7.1 | +0.0 | 0.0 | 29.5 | 4.9 | +0.0 | 0.0 | 32.3 |
| FOCUS FIRE | 0.1 | +0.9 | 0.0 | 0.0 | 0.1 | +3.0 | 10.2 | 0.0 |
| FOLLOW UP WEIGHED | 0.6 | +77.1 | 0.0 | 0.0 | 0.5 | +110.8 | 0.0 | 12.5 |
| FOUR ROUNDS | 1.4 | +140.7 | 116.7 | 14.9 | 4.3 | +460.9 | 307.2 | 98.5 |
| FRIEND CHARGES FIRST | - | - | - | - | 0.1 | -4.2 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 0.5 | -13.0 | 0.0 | 0.0 | 0.1 | -0.0 | 0.0 | 0.0 |
| FRIENDS SHOTS CHECKED | - | - | - | - | 0.1 | +2.1 | 0.0 | 18.1 |
| GIVES UP | - | - | - | - | 0.3 | -2.3 | 13.4 | 0.0 |
| GUN FIGURES | 2.0 | +34.3 | 66.7 | 21.4 | 1.0 | +17.2 | 5.5 | 30.0 |
| GUN MASK | 0.7 | +10.6 | 0.0 | 9.5 | 1.3 | +43.8 | 0.0 | 16.7 |
| HARD STAY DROPPED | 2.2 | +0.0 | 0.0 | 28.2 | 0.6 | +0.0 | 0.0 | 0.0 |
| HE SHOOTS OR CHARGES | 1.2 | +0.0 | 0.0 | 58.5 | 2.1 | +0.0 | 0.0 | 34.2 |
| HELPER ALREADY ASKED | - | - | - | - | 0.1 | +0.0 | 26.3 | 17.7 |
| HIS CHARGE DENIED | 0.2 | +3.3 | 0.0 | 0.0 | - | - | - | - |
| HIS CHARGE LIST | 1.8 | +0.0 | 0.0 | 0.0 | 1.9 | +0.0 | 0.0 | 5.9 |
| HIS LEGAL MOVES | 4.0 | +0.0 | 0.0 | 32.5 | 3.2 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 1.8 | -32.7 | 0.0 | 30.9 | 1.5 | -82.9 | 0.0 | 66.7 |
| HIS RANDOM MOVE | 3.3 | +0.0 | 0.0 | 70.5 | 1.6 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 17.3 | +562.1 | 0.0 | 255.8 | 22.9 | +1089.7 | 0.0 | 268.5 |
| HIS TURN DENIED | 0.4 | +14.9 | 31.1 | 5.5 | 2.8 | +81.5 | 229.2 | 77.6 |
| HOLD ODDS | 11.8 | +0.0 | 0.0 | 108.2 | - | - | - | - |
| HOLDER ASSIGNMENT | 14.6 | +1500.3 | 0.0 | 108.2 | - | - | - | - |
| HOLDER AT DEPLOYMENT | - | - | - | - | 1.9 | +273.0 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.5 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 1.4 | -39.3 | 116.7 | 10.2 | 3.6 | -192.3 | 307.2 | 54.5 |
| HORN WORTH | - | - | - | - | 0.1 | +1.8 | 0.0 | 45.9 |
| HUNT IN PAIRS | 0.2 | +0.7 | 0.0 | 0.0 | 0.3 | +10.2 | 0.0 | 0.0 |
| HUNT KEPT | - | - | - | - | 0.1 | +0.0 | 0.0 | 9.5 |
| HUNT RESULT | - | - | - | - | 0.1 | +0.0 | 0.0 | 0.0 |
| HUNT THE GUNS | - | - | - | - | 0.1 | +33.0 | 0.0 | 9.5 |
| IDLE COST | 1.5 | -6.8 | 0.0 | 20.2 | 13.3 | -197.4 | 0.0 | 16.3 |
| JOINT KNOWS CHALLENGE | - | - | - | - | 0.2 | -5.5 | 52.5 | 17.7 |
| KEEP FALLS | 0.2 | +0.9 | 0.0 | 0.0 | - | - | - | - |
| KEEPS SCOUTS OR AMBUSH | 0.2 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| LANE BY FIGURES | 0.3 | +10.5 | 0.0 | 0.0 | 0.9 | +29.1 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 3.9 | +0.0 | 143.9 | 99.3 | 3.5 | +0.0 | 4.7 | 114.6 |
| LONE CHARACTER SAFE SPOT | - | - | - | - | 0.3 | +24.8 | 0.0 | 0.0 |
| LONE WIZARD KEPT IN | 0.9 | +59.1 | 0.0 | 0.0 | 0.6 | +44.2 | 0.0 | 0.0 |
| LONG SHOT | 0.1 | +2.5 | 0.0 | 0.0 | - | - | - | - |
| MAKE SURE TOGETHER | - | - | - | - | 0.5 | +1.6 | 0.0 | 0.0 |
| MANOEUVRE | 1.3 | +9.8 | 0.0 | 0.0 | 1.5 | +6.8 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.3 | +5.9 | 0.0 | 0.0 | - | - | - | - |
| MARCH BY THE SUM | 0.5 | +44.3 | 0.0 | 0.0 | 0.3 | +5.8 | 0.0 | 18.1 |
| MARCH CHECK | 1.2 | +119.3 | 0.0 | 0.0 | 1.3 | +65.2 | 0.0 | 32.5 |
| MARCH OVER CASTS | 0.9 | +23.7 | 0.0 | 0.0 | 0.4 | +26.1 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 6.1 | +86.6 | 0.0 | 47.7 | 4.5 | +36.9 | 0.0 | 16.2 |
| MISSILES IN THE MOVE | 4.2 | +221.2 | 0.0 | 37.0 | 2.3 | +17.5 | 0.0 | 14.4 |
| MISSILES NEXT TURN | 5.2 | +193.4 | 0.0 | 37.0 | 3.5 | +22.1 | 0.0 | 32.5 |
| MODEL FACING | 0.7 | +122.5 | 0.0 | 21.8 | - | - | - | - |
| MOVE SPELL IN RANGE | 0.8 | +43.2 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL NOT WORTH | - | - | - | - | 0.1 | -0.0 | 0.0 | 0.0 |
| MOVE SPELL OUT OF RANGE | 1.3 | -65.6 | 0.0 | 88.2 | - | - | - | - |
| MOVE SPELL SPOT | 0.8 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 3.6 | +470.3 | 0.0 | 19.6 | 3.5 | +625.6 | 0.0 | 0.0 |
| MOVES UNITS SPELL | 0.2 | +10.0 | 0.0 | 0.0 | 0.1 | +0.7 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 6.4 | +310.0 | 0.0 | 55.5 | 5.4 | +283.4 | 0.0 | 26.8 |
| NEEDED THERE | 0.1 | +26.7 | 0.0 | 0.0 | - | - | - | - |
| NEXT CHARGE BY LIST | 5.7 | -277.1 | 9.5 | 34.6 | 5.2 | -258.7 | 0.0 | 102.3 |
| NEXT OBJECTIVE NEARER | 0.2 | -0.1 | 0.0 | 0.0 | 12.0 | -619.2 | 47.7 | 76.8 |
| NO DOUBLE ROUNDS | 1.3 | -82.2 | 116.7 | 10.2 | 3.6 | -121.9 | 273.5 | 86.5 |
| NOT TURNED | 0.1 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 0.2 | -0.1 | 0.0 | 0.0 | 0.5 | -0.7 | 0.0 | 0.0 |
| OFF BEST | 0.4 | -3.2 | 0.0 | 6.6 | 0.7 | -8.4 | 0.0 | 0.0 |
| ONE CHARGE A CHARGER | 4.8 | +0.0 | 0.0 | 83.0 | 3.5 | +0.0 | 0.0 | 17.9 |
| ONE FIGHT FORMULA | 5.4 | -77.5 | 0.0 | 73.4 | 4.7 | -138.5 | 0.0 | 10.5 |
| ONE OBJECTIVE FORMULA | 5.8 | +100.2 | 0.0 | 65.0 | 2.9 | +27.4 | 0.0 | 19.9 |
| ONE TARGET A SHOOTER | 13.3 | +266.6 | 0.0 | 133.3 | 21.5 | +622.5 | 0.0 | 213.3 |
| OPENS UP | 0.1 | +2.9 | 3.2 | 0.0 | 0.3 | +22.9 | 16.4 | 0.0 |
| OVERRUNS AWAY | 0.4 | +7.5 | 7.3 | 0.0 | 0.5 | +27.9 | 80.7 | 35.5 |
| PATHS CROSS | 3.2 | +85.5 | 0.0 | 32.4 | 6.6 | +256.8 | 0.0 | 37.1 |
| PERIAPT WORTH | - | - | - | - | 0.1 | +4.9 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.1 | -1.7 | 0.0 | 4.7 | 0.3 | -2.1 | 0.0 | 0.0 |
| PLAN RESULT | 42.5 | +700.8 | 503.4 | 718.7 | 45.4 | +483.6 | 90.5 | 571.9 |
| PURSUES BIG PREY | - | - | - | - | 0.1 | -2.4 | 0.0 | 0.0 |
| QUARTER ODDS | 3.5 | +431.0 | 25.7 | 68.7 | - | - | - | - |
| RANDOM MOVE BY FIGURES | 0.4 | +22.0 | 0.0 | 46.4 | 2.2 | +16.2 | 0.0 | 19.1 |
| REDIRECT BY WHAT IT STOPS | 0.2 | -2.1 | 0.0 | 0.0 | 0.5 | -9.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | 2.4 | +90.5 | 0.0 | 18.2 | 4.4 | +149.9 | 0.0 | 10.6 |
| REDIRECT WEIGHED | 0.1 | +0.0 | 0.0 | 0.0 | 0.5 | -47.9 | 17.5 | 91.8 |
| REFORMS TO MEET IT | 0.5 | -3.3 | 0.0 | 9.5 | 0.9 | -66.8 | 0.0 | 0.0 |
| REFUSING RETIRES | 0.4 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | 0.5 | +21.9 | 0.0 | 20.4 | 1.5 | +38.6 | 0.0 | 0.0 |
| RISK BY ARC | 1.1 | +4.4 | 39.0 | 14.9 | 2.0 | -19.0 | 243.9 | 65.7 |
| RISK BY HIS FIGURE | 14.1 | -89.6 | 0.0 | 193.8 | 14.1 | -151.1 | 0.0 | 186.4 |
| RUN DOWN | 1.0 | -19.3 | 51.7 | 10.2 | 2.7 | -17.5 | 194.9 | 63.0 |
| SAFER THAN THE JOB | 0.2 | +3.2 | 0.0 | 0.0 | - | - | - | - |
| SAME CHARGE LATER | 0.1 | -6.0 | 0.0 | 0.0 | - | - | - | - |
| SCOUT SPOT | 0.1 | -0.0 | 0.0 | 0.0 | 0.4 | +0.4 | 0.0 | 0.0 |
| SCOUT WAITS | 0.1 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 0.0 |
| SEARCH SPOT | 6.0 | +193.0 | 0.0 | 87.6 | 9.5 | +306.1 | 0.0 | 29.9 |
| SELF MOVE SPELL | - | - | - | - | 0.5 | +22.5 | 0.0 | 0.0 |
| SET UP TOGETHER | 0.1 | +0.5 | 0.0 | 5.5 | 0.8 | +5.2 | 0.0 | 10.4 |
| SET-UP ANY TARGET | 0.3 | +41.3 | 29.3 | 0.0 | 0.2 | +22.0 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.5 | +1.1 | 0.0 | 0.0 | 0.5 | +0.8 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.6 | +127.8 | 81.7 | 37.0 | 1.4 | +18.4 | 15.6 | 66.3 |
| SHORT GUN FORWARD | 0.5 | +0.0 | 0.0 | 10.9 | - | - | - | - |
| SHOT OR CHARGE | 0.2 | -0.7 | 0.0 | 0.0 | 0.2 | -5.8 | 8.6 | 9.3 |
| SHOT RISK POINTS | 9.7 | +96.8 | 0.0 | 144.5 | 15.8 | -19.0 | 0.0 | 199.2 |
| SHOTS IN THE MOVE | 17.0 | +527.8 | 0.0 | 273.0 | 15.0 | +284.0 | 0.0 | 90.6 |
| SPELL SETS UP CHARGE | 0.6 | +162.7 | 29.3 | 0.0 | 0.2 | +22.0 | 0.0 | 0.0 |
| SPELL WORTH | 0.5 | +6.0 | 49.3 | 84.5 | 2.2 | +28.5 | 24.9 | 33.5 |
| SPELLS IN THE FIGHT | - | - | - | - | 0.2 | -2.5 | 0.0 | 9.3 |
| STAND AND SHOOT | 0.2 | -1.5 | 16.7 | 5.5 | 0.5 | -5.4 | 76.8 | 0.0 |
| STANDS FOR A REASON | - | - | - | - | 0.6 | +0.0 | 5.5 | 18.1 |
| STANDS STILL | 22.5 | +0.0 | 545.5 | 332.8 | 11.8 | +0.0 | 130.6 | 95.5 |
| STAY WORTH | 18.5 | +62.3 | 265.0 | 182.8 | 16.0 | +119.9 | 82.3 | 50.3 |
| STOPS | - | - | - | - | 0.1 | +5.3 | 0.0 | 9.5 |
| STUCK PIVOT | - | - | - | - | 0.1 | +0.0 | 0.0 | 0.0 |
| SUPPORT NARROWED | 0.5 | +0.0 | 55.5 | 5.5 | 1.0 | +0.0 | 29.6 | 30.3 |
| SURE REACH TOGETHER | 0.1 | +0.2 | 0.0 | 0.0 | 1.2 | +32.7 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 4.1 | +0.0 | 0.0 | 64.1 | 6.4 | +0.0 | 0.0 | 31.5 |
| THE PROMISE ADDS | 0.4 | -26.1 | 0.0 | 0.0 | - | - | - | - |
| THE PROMISED MOVE | 0.7 | +0.0 | 0.0 | 0.0 | 0.5 | +0.0 | 0.0 | 0.0 |
| TIED UP BY THE SUM | 0.1 | +3.4 | 0.0 | 0.0 | 0.5 | +70.5 | 65.3 | 18.1 |
| TIME ON OUR SIDE | 32.0 | +495.2 | 60.9 | 215.4 | 4.1 | +73.4 | 0.0 | 50.4 |
| WAITS AGAIN | 1.8 | +0.0 | 0.0 | 14.2 | 0.6 | +0.0 | 0.0 | 0.0 |
| WAR ENGINE CHARGES | 0.2 | +49.0 | 45.9 | 0.0 | - | - | - | - |
| WAR ENGINE JOBS | 0.6 | +0.0 | 45.9 | 0.0 | - | - | - | - |
| WHO HITS BACK | 0.1 | +4.3 | 0.0 | 0.0 | 0.4 | +16.5 | 0.0 | 0.0 |
| WHOLE FIGHT | 0.2 | -1.6 | 45.9 | 0.0 | 0.2 | +2.0 | 0.0 | 2.7 |
| WIDER SPREAD | 0.7 | -3.5 | 91.9 | 10.2 | 3.0 | -7.6 | 239.0 | 62.5 |
| WOUNDS ON THE RANKS | 2.2 | +61.5 | 0.0 | 26.3 | 0.7 | +20.7 | 0.0 | 0.0 |

### Rule changes: h5-mine-8766b98-p4

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| SEARCH SPOT | 171 | 171 | 157 | 14.27 | +5491 | +35.0 |
| HOLDER ASSIGNMENT | 161 | 161 | 150 | 13.64 | +8127 | +54.2 |
| HIS SHOT LIST | 442 | 442 | 132 | 12.00 | +2339 | +17.7 |
| DEPLOY BY FIGURES | 194 | 194 | 123 | 11.18 | +1578 | +12.8 |
| PATHS CROSS | 108 | 108 | 108 | 9.82 | +3766 | +34.9 |
| ONE TARGET A SHOOTER | 382 | 382 | 95 | 8.64 | +810 | +8.5 |
| FIVE ACTION | 1091 | 1090 | 93 | 8.45 | +2522 | +27.1 |
| LEGAL CHARGES ONLY | 82 | 82 | 82 | 7.45 | +0 | +0.0 |
| TIME ON OUR SIDE | 397 | 340 | 65 | 5.91 | +361 | +5.6 |
| SHOT RISK POINTS | 281 | 281 | 46 | 4.18 | +1522 | +33.1 |
| MOVE TO CHARGE COMPUTED | 79 | 79 | 42 | 3.82 | +4622 | +110.1 |
| FOUR ROUNDS | 62 | 61 | 39 | 3.55 | +1738 | +44.6 |
| COVER ONCE | 133 | 107 | 31 | 2.82 | +469 | +15.1 |
| HARD STAY DROPPED | 31 | 31 | 31 | 2.82 | +0 | +0.0 |
| CANNON SIGHT KEPT | 26 | 26 | 26 | 2.36 | +0 | +0.0 |
| ARTILLERY RE-ROLL WEIGHED | 24 | 24 | 24 | 2.18 | +0 | +0.0 |
| SHOTS IN THE MOVE | 352 | 330 | 24 | 2.18 | +489 | +20.4 |
| NEXT OBJECTIVE NEARER | 134 | 134 | 23 | 2.09 | +282 | +12.3 |
| RESERVE FALL BACK | 22 | 22 | 22 | 2.00 | +666 | +30.3 |
| MAX FOR POSITIONING | 117 | 113 | 21 | 1.91 | +75 | +3.6 |
| MARCH CHECK | 27 | 27 | 19 | 1.73 | +522 | +27.5 |
| RANDOM MOVE BY FIGURES | 28 | 28 | 19 | 1.73 | +420 | +22.1 |
| SHOOTS FROM THE BEST SPOT | 33 | 33 | 19 | 1.73 | +758 | +39.9 |
| CANNON PLANNED TARGET | 94 | 94 | 18 | 1.64 | -94 | -5.2 |
| LONE WIZARD KEPT IN | 17 | 17 | 17 | 1.55 | +1136 | +66.8 |
| ADVANCE LANE KEPT | 16 | 16 | 16 | 1.45 | +0 | +0.0 |
| REDIRECT COUNTER | 74 | 59 | 16 | 1.45 | +952 | +59.5 |
| CHARGE NOT DECLARED | 15 | 15 | 15 | 1.36 | -2306 | -153.8 |
| MISSILES IN THE MOVE | 71 | 53 | 14 | 1.27 | +271 | +19.4 |
| NEXT CHARGE BY LIST | 120 | 120 | 14 | 1.27 | +303 | +21.7 |
| RISK BY ARC | 34 | 33 | 14 | 1.27 | +256 | +18.3 |
| LANE BY FIGURES | 13 | 13 | 13 | 1.18 | +435 | +33.5 |
| FOLLOW UP WEIGHED | 12 | 12 | 12 | 1.09 | +2067 | +172.3 |
| IDLE COST | 162 | 131 | 12 | 1.09 | +112 | +9.4 |
| MANOEUVRE | 30 | 30 | 12 | 1.09 | +326 | +27.2 |
| OFF BEST | 12 | 12 | 12 | 1.09 | -128 | -10.6 |
| FALLS SHORT | 292 | 254 | 11 | 1.00 | +20 | +1.8 |
| SHOOTERS IN TWO RANKS | 11 | 11 | 11 | 1.00 | +21 | +1.9 |
| HOLDER AT DEPLOYMENT | 21 | 21 | 10 | 0.91 | +443 | +44.3 |
| WOUNDS ON THE RANKS | 32 | 32 | 10 | 0.91 | +181 | +18.1 |
| CASTER AWAY FROM SCREEN | 9 | 9 | 9 | 0.82 | +0 | +0.0 |
| CHARGE LOSSES | 118 | 118 | 9 | 0.82 | +541 | +60.1 |
| HIS TURN DENIED | 35 | 35 | 9 | 0.82 | +110 | +12.3 |
| HOLDS AMBUSHERS | 9 | 9 | 9 | 0.82 | +0 | +0.0 |
| CHAFF IN THE MOVE | 17 | 15 | 8 | 0.73 | +77 | +9.6 |
| CHAFF PASSED | 8 | 8 | 8 | 0.73 | -0 | -0.0 |
| COMBAT PIVOT | 8 | 8 | 8 | 0.73 | +0 | +0.0 |
| MARCH BY THE SUM | 8 | 8 | 8 | 0.73 | +552 | +69.0 |
| MODEL FACING | 8 | 8 | 8 | 0.73 | +1347 | +168.4 |
| NEARER NOT NEEDED | 129 | 120 | 8 | 0.73 | +311 | +38.9 |
| ONE OBJECTIVE FORMULA | 96 | 83 | 8 | 0.73 | +269 | +33.7 |
| QUARTER ODDS | 39 | 39 | 8 | 0.73 | +514 | +64.3 |
| RISK BY HIS FIGURE | 310 | 310 | 8 | 0.73 | +472 | +59.0 |
| MISSILES NEXT TURN | 95 | 67 | 7 | 0.64 | +54 | +7.7 |
| STAY WORTH | 379 | 358 | 7 | 0.64 | +36 | +5.1 |
| FEATURE BUFFS | 44 | 44 | 6 | 0.55 | +100 | +16.7 |
| REDIRECT WEIGHED | 6 | 6 | 6 | 0.55 | +351 | +58.5 |
| SHORT GUN FORWARD | 6 | 6 | 6 | 0.55 | +0 | +0.0 |
| TIED UP BY THE SUM | 7 | 7 | 6 | 0.55 | +212 | +35.3 |
| BEST PRIZE | 5 | 5 | 5 | 0.45 | -573 | -114.6 |
| CASTING BLOCK | 7 | 7 | 5 | 0.45 | +114 | +22.9 |
| CHARGE NOW FIRST | 28 | 28 | 5 | 0.45 | -177 | -35.4 |
| FIGHT TO THE END | 27 | 27 | 5 | 0.45 | +312 | +62.4 |
| SCOUT WAITS | 5 | 5 | 5 | 0.45 | +0 | +0.0 |
| WHO HITS BACK | 5 | 5 | 5 | 0.45 | +150 | +29.9 |
| FIRE IN ORDER | 4 | 4 | 4 | 0.36 | +0 | +0.0 |
| GUN MASK | 22 | 22 | 4 | 0.36 | +137 | +34.2 |
| ONE FIGHT FORMULA | 111 | 60 | 4 | 0.36 | +17 | +4.2 |
| PIVOT GUARDS FLANK | 4 | 4 | 4 | 0.36 | -42 | -10.6 |
| SURE REACH TOGETHER | 14 | 14 | 4 | 0.36 | +0 | +0.0 |
| WIDER SPREAD | 41 | 40 | 4 | 0.36 | +24 | +6.1 |
| AFTERMATH IN POINTS | 3 | 3 | 3 | 0.27 | +312 | +104.0 |
| CAST JOB | 8 | 8 | 3 | 0.27 | +33 | +10.9 |
| HONEST WORTH | 55 | 54 | 3 | 0.27 | +12 | +4.1 |
| MOVES UNITS SPELL | 3 | 3 | 3 | 0.27 | +118 | +39.2 |
| CASTS FROM BEHIND | 2 | 2 | 2 | 0.18 | +0 | +0.0 |
| EDGE GIVE GROUND | 3 | 3 | 2 | 0.18 | +15 | +7.6 |
| FALL BACK GOOD ORDER | 45 | 44 | 2 | 0.18 | +5 | +2.3 |
| FOCUS FIRE | 2 | 2 | 2 | 0.18 | +43 | +21.4 |
| HIS MOVE AND SHOT | 37 | 37 | 2 | 0.18 | +100 | +50.1 |
| KEEP FALLS | 2 | 2 | 2 | 0.18 | +89 | +44.5 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.18 | +0 | +0.0 |
| NO DOUBLE ROUNDS | 54 | 53 | 2 | 0.18 | +12 | +6.0 |
| OPENS UP | 4 | 4 | 2 | 0.18 | +80 | +40.1 |
| OVERRUNS AWAY | 9 | 9 | 2 | 0.18 | +135 | +67.5 |
| SAFER THAN THE JOB | 2 | 2 | 2 | 0.18 | +35 | +17.6 |
| SET UP TOGETHER | 10 | 9 | 2 | 0.18 | +3 | +1.7 |
| SUPPORT NARROWED | 17 | 17 | 2 | 0.18 | -47 | -23.5 |
| WAR ENGINE CHARGES | 2 | 2 | 2 | 0.18 | +34 | +17.2 |
| CARRIES OUT SET-UP | 2 | 2 | 1 | 0.09 | -10 | -9.5 |
| CHAMPION TAKES THE CHALLENGE | 1 | 1 | 1 | 0.09 | +0 | +0.0 |
| CONTINUE AHEAD WEIGHED | 1 | 1 | 1 | 0.09 | +0 | +0.0 |
| DEFENSIVE FLOOR | 1 | 1 | 1 | 0.09 | +0 | +0.4 |
| FACES THE THREAT | 1 | 1 | 1 | 0.09 | +37 | +36.7 |
| FALLBACK BY WORTH | 8 | 8 | 1 | 0.09 | +2 | +2.3 |
| FRIENDS SHOTS CHECKED | 1 | 1 | 1 | 0.09 | +23 | +23.1 |
| HORN WORTH | 1 | 1 | 1 | 0.09 | +20 | +19.9 |
| HUNT IN PAIRS | 5 | 1 | 1 | 0.09 | +0 | +0.0 |
| MOVE SPELL IN RANGE | 9 | 5 | 1 | 0.09 | +41 | +41.2 |
| NEEDED THERE | 1 | 1 | 1 | 0.09 | +0 | +0.0 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.09 | +54 | +54.4 |
| PURSUES BIG PREY | 1 | 1 | 1 | 0.09 | -26 | -26.3 |
| REDIRECT BY WHAT IT STOPS | 8 | 8 | 1 | 0.09 | +17 | +17.3 |
| REFUSING RETIRES | 5 | 5 | 1 | 0.09 | +0 | +0.0 |
| RUN DOWN | 41 | 40 | 1 | 0.09 | +1 | +0.7 |
| STOPS | 1 | 1 | 1 | 0.09 | +35 | +35.4 |
| STUCK PIVOT | 1 | 1 | 1 | 0.09 | +0 | +0.0 |
| WAR ENGINE JOBS | 7 | 7 | 1 | 0.09 | -19 | -18.9 |
| WHOLE FIGHT | 4 | 4 | 1 | 0.09 | +0 | +0.0 |
| ALREADY CARRIED | 2 | not checked | - | - | - | - |
| BLOWS WHERE AIMED | 10 | 10 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 13 | 13 | 0 | 0.00 | - | - |
| CARRIES OUT COUNTER | 1 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 16 | trace | - | - | - | - |
| CHARACTER GUNS | 10 | 10 | 0 | 0.00 | - | - |
| CHARGER SLAIN LOST | 5 | 5 | 0 | 0.00 | - | - |
| CHEAP HELPER | 1 | not checked | - | - | - | - |
| CHEAPEST HOLDER | 8 | 8 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 22 | not checked | - | - | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT LIFT | 2 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 132 | not checked | - | - | - | - |
| FRIEND CHARGES FIRST | 1 | 1 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 6 | 6 | 0 | 0.00 | - | - |
| GIVES UP | 3 | 2 | 0 | 0.00 | - | - |
| GUN FIGURES | 33 | not checked | - | - | - | - |
| HE SHOOTS OR CHARGES | 36 | 36 | 0 | 0.00 | - | - |
| HELPER ALREADY ASKED | 1 | not checked | - | - | - | - |
| HIS CHARGE DENIED | 2 | 2 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 41 | 41 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 79 | 79 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 54 | 54 | 0 | 0.00 | - | - |
| HOLD ODDS | 130 | 130 | 0 | 0.00 | - | - |
| HUNT KEPT | 1 | trace | - | - | - | - |
| HUNT RESULT | 1 | trace | - | - | - | - |
| HUNT THE GUNS | 1 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 2 | 2 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 3 | not checked | - | - | - | - |
| LONG SHOT | 1 | 1 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 5 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 3 | trace | - | - | - | - |
| MARCH OVER CASTS | 14 | 14 | 0 | 0.00 | - | - |
| MOVE SPELL NOT WORTH | 1 | not checked | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 14 | trace | - | - | - | - |
| MOVE SPELL SPOT | 11 | not checked | - | - | - | - |
| NOT TURNED | 5 | 5 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 8 | not checked | - | - | - | - |
| ONE CHARGE A CHARGER | 91 | 91 | 0 | 0.00 | - | - |
| PLAN RESULT | 966 | trace | - | - | - | - |
| REFORMS TO MEET IT | 16 | 16 | 0 | 0.00 | - | - |
| SAME CHARGE LATER | 1 | 1 | 0 | 0.00 | - | - |
| SCOUT SPOT | 5 | 5 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 6 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 5 | not checked | - | - | - | - |
| SHOT OR CHARGE | 4 | 4 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 9 | not checked | - | - | - | - |
| SPELL WORTH | 29 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 8 | 8 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 7 | 7 | 0 | 0.00 | - | - |
| STANDS STILL | 377 | 377 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 115 | not checked | - | - | - | - |
| THE PROMISE ADDS | 4 | 4 | 0 | 0.00 | - | - |
| THE PROMISED MOVE | 14 | not checked | - | - | - | - |
| WAITS AGAIN | 27 | 27 | 0 | 0.00 | - | - |

### Off best figure: h5-mine-8766b98-p4

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| CHARGE NOT DECLARED | rule | 0.09 | 1.27 | 153.8 |
| HOLDER ASSIGNMENT | rule | 1.27 | - | 17.7 |
| PATHS CROSS | rule | 0.55 | 0.73 | 24.7 |
| JOB FIRST | gate | 0.18 | 0.36 | 16.0 |
| BEST PRIZE | rule | 0.09 | 0.36 | 114.6 |
| CHARGE NOW FIRST | rule | 0.18 | 0.27 | 35.4 |
| PIVOT GUARDS FLANK | rule | 0.09 | 0.27 | 10.6 |
| CANNON PLANNED TARGET | rule | 0.18 | 0.09 | 33.6 |
| AFTERMATH BAND | gate | - | 0.18 | 3.1 |
| FALLBACK | gate | 0.09 | 0.09 | 5.1 |
| SUPPORT NARROWED | rule | 0.09 | 0.09 | 23.5 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.09 | - | 14.2 |
| CARRIES OUT SET-UP | rule | - | 0.09 | 9.5 |
| FIGHT ORDER BAND | gate | - | 0.09 | 0.7 |
| PURSUES BIG PREY | rule | - | 0.09 | 26.3 |
| REDIRECT WEIGHED | rule | - | 0.09 | 4.0 |
| WAR ENGINE JOBS | rule | 0.09 | - | 18.9 |
| WHO HITS BACK | rule | - | 0.09 | 4.1 |

### Plans: h5-mine-8766b98-p4

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.0 | 55% | 204 | 101 | 50% |
| Mine | join | 0.5 | 100% | 16 | 0 | 0% |
| Mine | move | 28.5 | 94% | 1912 | 0 | 0% |
| Mine | shoot | 12.4 | 58% | 514 | 600 | 117% |
| Mine | support | 0.1 | 100% | 0 | 0 | - |
| Opponent | charge | 3.5 | 62% | 568 | 309 | 54% |
| Opponent | join | 1.0 | 100% | 48 | 0 | 0% |
| Opponent | move | 35.9 | 95% | 1895 | 0 | 0% |
| Opponent | shoot | 4.5 | 52% | 241 | 175 | 73% |
| Opponent | support | 0.4 | 100% | 7 | 0 | 0% |

### Packages: hunt the guns, h5-mine-8766b98-p4

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 29 |
| Opponent | 0.1 | 1 | 0 | 100% | 0% | 0% | - | 363 | 0 | 0% | 59 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 21 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 78 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 265 |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Tomb Kings of Khemri | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Vampire Counts | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 45 |
| Warriors of Chaos | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Wood Elf Realms | 0.5 | 1 | 0 | 100% | 0% | 0% | - | 363 | 0 | 0% | 169 |

### Battle groups: h5-mine-8766b98-p4

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 2.4 | 12% | 67% | 0% | - | 33% | 0% | 0% | 33% | 33% |
| Opponent | REDIRECT COUNTER | 4.4 | 10% | 100% | 20% | 0% | 25% | 0% | 0% | 50% | 25% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: h5-mine-8766b98-p4

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 6 | 0 (6) | 0 | 0 | 28 | 83% | 2.0 | 0 (2) | 0 (3) | 0 (1) | 0 (4) | 0 (2) |
| Mine | Character | 41 | 26 (41) | 26 | 0 | 36 | 15% | 2.7 | 23 (17) | 55 (12) | 13 (2) | 24 (12) | 39 (19) |
| Mine | Clean-up | 6 | 71 (6) | 0 | 71 | 39 | 67% | 1.0 | 65 (3) | 77 (3) | - | 80 (5) | 0 (1) |
| Mine | Fast Hammer | 10 | 21 (10) | 21 | 0 | 74 | 30% | 4.4 | 0 (1) | 0 (5) | 40 (4) | 27 (8) | 0 (2) |
| Mine | Hammer | 28 | 30 (28) | 16 | 15 | 19 | 29% | 2.4 | 43 (10) | 21 (14) | 40 (4) | 41 (17) | 17 (11) |
| Mine | Holder | 10 | 111 (10) | 0 | 111 | 8 | 90% | 4.0 | 149 (3) | 106 (6) | 0 (1) | 185 (4) | 66 (6) |
| Mine | Shooter | 16 | 73 (16) | 11 | 63 | 33 | 0% | 2.0 | 66 (7) | 110 (7) | 16 (2) | 65 (13) | 115 (3) |
| Mine | War machine | 25 | 22 (25) | 22 | 0 | 54 | 4% | 1.5 | 33 (15) | 5 (8) | 0 (2) | 0 (6) | 29 (19) |
| Mine | Wizard | 6 | 49 (6) | 49 | 0 | 0 | 33% | 3.5 | 60 (5) | 0 (1) | - | 0 (1) | 58 (5) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 0% | 6.0 | 0 (1) | - | - | - | 0 (1) |
| Opponent | Chaff | 23 | 18 (23) | 0 | 18 | 35 | 35% | 3.3 | 0 (8) | 32 (10) | 13 (5) | 13 (16) | 30 (7) |
| Opponent | Character | 27 | 50 (27) | 50 | 0 | 15 | 22% | 2.1 | 38 (7) | 66 (7) | 54 (11) | 42 (14) | 69 (11) |
| Opponent | Clean-up | 10 | 52 (10) | 14 | 38 | 25 | 40% | 2.7 | 15 (3) | 61 (5) | 70 (2) | 60 (6) | 39 (4) |
| Opponent | Fast Hammer | 11 | 78 (11) | 32 | 46 | 44 | 55% | 2.0 | 42 (4) | 183 (4) | 0 (3) | 88 (9) | 0 (2) |
| Opponent | Hammer | 17 | 28 (17) | 24 | 4 | 29 | 47% | 3.1 | 7 (4) | 13 (10) | 89 (3) | 36 (8) | 20 (9) |
| Opponent | Holder | 13 | 129 (13) | 0 | 129 | 19 | 38% | 2.8 | 122 (5) | 156 (5) | 95 (3) | 137 (12) | 29 (1) |
| Opponent | Shooter | 10 | 62 (10) | 0 | 62 | 10 | 10% | 2.2 | 83 (4) | 86 (2) | 0 (4) | 64 (6) | 58 (4) |
| Opponent | Support | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | 0 (1) | - | - | - | 0 (1) |
| Opponent | War machine | 7 | 41 (7) | 41 | 0 | 13 | 0% | 2.3 | 41 (5) | 85 (1) | 0 (1) | - | 41 (7) |
| Opponent | Wizard | 10 | 23 (10) | 23 | 0 | 10 | 10% | 2.2 | 36 (3) | 42 (2) | 0 (4) | 0 (2) | 31 (7) |

### Charged fights: h5-mine-8766b98-p4

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 163 | 0 | 1.0 | 1.0 | 0 | 26 | -26 | 2 of 4 | 2 of 4 | - | -26 |
| Mine | Chaos Dwarfs | 4 | 153 | 407 | 2.0 | 1.0 | 204 | 35 | +168 | 4 of 8 | 8 of 8 | - | +168 |
| Mine | Dwarfen Mountain Holds | 3 | 203 | 35 | 0.3 | 1.0 | 104 | 0 | +104 | 0 of 1 | 1 of 1 | - | +104 |
| **Mine** | all armies | 11 | 170 | 157 | 1.2 | 1.0 | 133 | 30 | +104 | 6 of 13 | 11 of 13 | - | +104 |
| Opponent | Empire of Man | 1 | 460 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | High Elf Realms | 1 | 0 | 355 | 3.0 | 1.0 | 118 | 0 | +118 | 2 of 3 | 1 of 3 | - | +118 |
| Opponent | Kingdom of Bretonnia | 2 | 42 | 464 | 4.0 | 1.0 | 116 | 0 | +116 | 0 of 8 | 8 of 8 | - | +116 |
| Opponent | Skaven | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Tomb Kings of Khemri | 1 | 168 | 707 | 4.0 | 1.5 | 177 | 0 | +177 | 3 of 4 | 2 of 3 | +612 | +32 |
| Opponent | Vampire Counts | 1 | 60 | 411 | 6.0 | 1.2 | 68 | 0 | +68 | 2 of 6 | 3 of 6 | +0 | +82 |
| Opponent | Warriors of Chaos | 2 | 0 | 996 | 5.5 | 1.0 | 181 | 36 | +145 | 7 of 11 | 4 of 11 | - | +145 |
| Opponent | Wood Elf Realms | 2 | 0 | 155 | 2.5 | 1.0 | 62 | 41 | +21 | 2 of 5 | 2 of 5 | - | +21 |
| **Opponent** | all armies | 11 | 70 | 428 | 3.4 | 1.1 | 127 | 16 | +111 | 16 of 37 | 20 of 36 | +306 | +100 |

### Effective charges: h5-mine-8766b98-p4

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 2 (net -52) | 0 | 0 | 0 | 0 | 1 (net +0) | 1 | 0% (0 of 3) |
| Mine | Chaos Dwarfs | 8 | 0 | 0 | 0 | 3 (net +145) | 1 (net +80) | 3 (net +240) | 1 | 0% (0 of 7) |
| Mine | Dwarfen Mountain Holds | 1 | 1 (net +104) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 1) |
| Opponent | High Elf Realms | 3 | 1 (net +355) | 0 | 1 (net +0) | 0 | 1 (net +0) | 0 | 0 | 33% (1 of 3) |
| Opponent | Kingdom of Bretonnia | 8 | 0 | 0 | 2 (net +158) | 3 (net +102) | 1 (net +85) | 1 (net +170) | 1 | 29% (2 of 7) |
| Opponent | Tomb Kings of Khemri | 4 | 2 (net +0) | 0 | 1 (net +95) | 1 (net +612) | 0 | 0 | 0 | 25% (1 of 4) |
| Opponent | Vampire Counts | 6 | 2 (net +0) | 0 | 3 (net +75) | 0 | 0 | 1 (net +186) | 0 | 50% (3 of 6) |
| Opponent | Warriors of Chaos | 11 | 7 (net +93) | 0 | 2 (net +386) | 0 | 0 | 2 (net +85) | 0 | 18% (2 of 11) |
| Opponent | Wood Elf Realms | 5 | 3 (net -69) | 0 | 0 | 1 (net +310) | 0 | 0 | 1 | 0% (0 of 4) |

### Charged fights, damage counted: h5-mine-8766b98-p4

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 3 | 55 | 222 | +0 | 35 | 41 | -7 | -12.2 |
| Mine | 76-89% | 3 | 320 | 329 | +145 | 358 | 108 | +250 | +78.3 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 4 | 269 | 149 | +180 | 180 | 10 | +170 | +63.1 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 314 | 80 | +80 | 80 | 0 | +80 | +25.5 |
| Mine | No odds | 2 | 376 | 142 | +57 | 57 | 0 | +57 | +15.2 |
| Mine | All fights | 13 | 251 | 201 | +104 | 161 | 38 | +123 | +49.1 |
| Opponent | Long shot (under 50%) | 15 | 210 | 315 | +53 | 111 | 81 | +31 | +14.5 |
| Opponent | Effective (55-75%) | 9 | 304 | 158 | +156 | 157 | 44 | +113 | +37.1 |
| Opponent | 76-89% | 5 | 468 | 177 | +245 | 245 | 17 | +228 | +48.8 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 4 | 372 | 153 | +132 | 142 | 5 | +137 | +36.8 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 2 | 285 | 70 | +42 | 64 | 45 | +19 | +6.8 |
| Opponent | No odds | 2 | 340 | 96 | +26 | 26 | 0 | +26 | +7.6 |
| Opponent | All fights | 37 | 296 | 215 | +111 | 137 | 49 | +88 | +29.7 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| h5-mine-8766b98-p4 | move | 76 | 16 (21%) | 13 (17%) | 8 (11%) | 52 (68%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0115, L0132 |
| Charmed Shield | Opponent | L0625 |
| Horn of the Wild Hunt | Opponent | L0333 |
| Invocation of Nehek | Opponent | L0625 |
| Periapt of Soul Exchange | Opponent | L0420 |
| Ring of Doom | Mine | L0216, L0232 |
| Ring of Doom | Opponent | L0115, L0333 |

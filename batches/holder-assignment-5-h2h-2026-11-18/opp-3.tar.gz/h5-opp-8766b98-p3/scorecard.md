# Doctrine scorecard: h5-opp-8766b98-p3

### Scorecard: h5-opp-8766b98-p3

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0111 | 3 | 1 | Mine | no | 4 | - | 0 | 1 | 0 | 0 | 0 | 0 |
| L0111 | 3 | 1 | Opponent | no | 0 | 2 | 1 | 0 | 0 | 0 | 0 | 0 |
| L0128 | 2 | 1 | Mine | - | - | - | 0 | 5 | 0 | 0 | 0 | 0 |
| L0128 | 2 | 1 | Opponent | - | - | - | 0 | 4 | 0 | 0 | 0 | 0 |
| L0211 | 1 | 1 | Mine | no | 0 | - | 1 | 4 | 0 | 0 | 0 | 170 |
| L0211 | 1 | 1 | Opponent | yes | 15 | 2 | 0 | 0 | 0 | 0 | 0 | 0 |
| L0228 | 6 | 1 | Mine | yes | 9 | 2 | 2 | 2 | 0 | 0 | 0 | 170 |
| L0228 | 6 | 1 | Opponent | no | 8 | 3 | 1 | 0 | 0 | 0 | 0 | 0 |
| L0313 | 1 | 1 | Mine | no | 6 | 5 | 1 | 0 | 0 | 0 | 0 | 140 |
| L0313 | 1 | 1 | Opponent | no | 10 | 2 | 3 | 0 | 1 | 0 | 0 | 70 |
| L0330 | 6 | 1 | Mine | no | 0 | - | 0 | 0 | 0 | 0 | 0 | 110 |
| L0330 | 6 | 1 | Opponent | no | 16 | 2 | 2 | 0 | 0 | 0 | 0 | 0 |
| L0415 | 1 | 1 | Mine | no | 7 | 5 | 1 | 2 | 0 | 0 | 0 | 310 |
| L0415 | 1 | 1 | Opponent | no | 2 | 2 | 1 | 1 | 0 | 0 | 0 | 0 |
| L0432 | 6 | 1 | Mine | no | 0 | 3 | 3 | 2 | 0 | 0 | 0 | 310 |
| L0432 | 6 | 1 | Opponent | no | 0 | 2 | 1 | 1 | 2 | 0 | 0 | 340 |
| L0518 | 2 | 1 | Mine | - | - | - | 0 | 2 | 0 | 0 | 0 | 943 |
| L0518 | 2 | 1 | Opponent | - | - | - | 0 | 5 | 2 | 0 | 0 | 0 |
| **Average** | | | Mine | 14% | 3.7 | 3.8 | 0.9 | 2.0 | 0.0 | 0.0 | 0.0 | 239.2 |
| **Average** | | | Opponent | 14% | 7.3 | 2.1 | 1.0 | 1.2 | 0.6 | 0.0 | 0.0 | 45.6 |

### KPIs: h5-opp-8766b98-p3

Rules off - Mine only: HOLDER ASSIGNMENT, QUARTER ODDS.

Morten 2026-11-10; 9 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 33% (14 of 42) | 2% (1 of 44) | 17% (15 of 86) |
| Winner chose to follow up after the loser gave ground |  | 80% (4 of 5); on the table 100% | 100% (12 of 12); on the table 100% | 94% (16 of 17); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | 100% (1 of 1); on the table 100% | 0% (0 of 1); on the table 0% | 50% (1 of 2); on the table 50% |
| Winner chose to pursue after the loser fled |  | 50% (2 of 4); on the table 50% | 100% (1 of 1); on the table 100% | 60% (3 of 5); on the table 60% |
| Winner chose to follow up or pursue (all three) |  | 70% (7 of 10); on the table 80% | 93% (13 of 14); on the table 93% | 83% (20 of 24); on the table 88% |
| Magic missiles tried each own turn | 50%+ | 46% (63 of 138) | 42% (25 of 60) | 44% (88 of 198) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 51% (63 of 124) | 54% (25 of 46) | 52% (88 of 170) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 40% (4 of 10) | 20% (1 of 5) | 33% (5 of 15) |
| Points that never fought | lower | 57% (9997 of 17564) | 58% (10418 of 17997) | 57% (20415 of 35561) |
|   infantry points that never fought | lower | 69% (3516 of 5100) | 74% (1441 of 1950) | 70% (4957 of 7050) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 56% (34 of 61) | 50% (33 of 66) | 53% (67 of 127) |
| Bound items with a magic missile used (at least once a game) |  | 83% (5 of 6); 2.1 uses a game | 75% (6 of 8); 2.0 uses a game | 79% (11 of 14); 2.1 uses a game |
| Bound items with another spell used |  | 100% (2 of 2); 0.8 uses a game | 0% (0 of 2); 0.0 uses a game | 50% (2 of 4); 0.4 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 88% (7 of 8); 0.8 uses a game | 33% (1 of 3); 0.1 uses a game | 73% (8 of 11); 0.4 uses a game |
|   their share of the points of units over 100 pts | lower | 51% (6909 of 13520) | 48% (7974 of 16547) | 49% (14883 of 30067) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 4.1 (49%) | 0.2 (6%) | 4.3 (35%) |
| MARCHED: its unit marched | 1.6 (19%) | 1.4 (37%) | 3.0 (25%) |
| CHARGED: its unit charged | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| IN COMBAT: engaged in combat | 0.3 (4%) | 1.1 (29%) | 1.4 (12%) |
| REAR RANK: in a rear rank | 0.7 (8%) | 0.6 (14%) | 1.2 (10%) |
| GONE: slain | 0.8 (9%) | 0.4 (11%) | 1.2 (10%) |
| OFF THE TABLE: off the table or not arrived | 0.4 (5%) | 0.0 (0%) | 0.4 (4%) |
| STUPIDITY: Stupidity | 0.2 (3%) | 0.1 (3%) | 0.3 (3%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 3.2 | 2.6 | 2.0 | 9.8 | 0.4 | 1.2 |
| not cast | 4.1 | 5.8 | 2.7 | 12.2 | 1.6 | 22.8 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.4 (6%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 2.9 (50%) | 0.0 (0%) | 4.3 (35%) | 0.6 (36%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 3.0 (25%) | 0.3 (21%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.2 (4%) | 0.1 (4%) | 1.4 (12%) | 0.4 (29%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 1.1 (19%) | 0.7 (25%) | 1.2 (10%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | 0.4 (11%) | 0.0 (0%) | 0.7 (25%) | 1.2 (10%) | 0.0 (0%) | 1.6 (7%) |
| OFF THE TABLE: off the table or not arrived | 0.2 (5%) | 0.0 (0%) | 0.0 (0%) | 0.4 (4%) | 0.0 (0%) | 0.6 (2%) |
| STUPIDITY: Stupidity | 0.3 (8%) | 0.1 (2%) | 0.0 (0%) | 0.3 (3%) | 0.1 (7%) | 0.2 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.3 (6%) | 0.0 (0%) | 0.1 (1%) | 0.1 (7%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 3.1 (76%) | 1.1 (19%) | 1.2 (46%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 19.0 (83%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 2.0 a game | 0.8 a game | 1.4 a game |
| stood (cast and not dispelled) | 39% (7 of 18) | 100% (1 of 1) | 42% (8 of 19) |
| the unit moved after it | 29% (2 of 7) | 100% (1 of 1) | 38% (3 of 8) |
| it charged on its next turn | 0% (0 of 7) | 0% (0 of 1) | 0% (0 of 8) |
| the enemy charged it first | 43% (3 of 7) | 0% (0 of 1) | 38% (3 of 8) |
| it fought by the end of its next turn | 43% (3 of 7) | 0% (0 of 1) | 38% (3 of 8) |
| it moved out of a charge the enemy had planned (not charged first) | 14% (1 of 7) | 0% (0 of 1) | 12% (1 of 8) |
| none of these (no charge, no fight, no charge escaped) | 43% (3 of 7) | 100% (1 of 1) | 50% (4 of 8) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 68% (119 of 176) | 52% (79 of 153) | 60% (198 of 329) |
|   cavalry | 78% (7 of 9) | 57% (4 of 7) | 69% (11 of 16) |
|   character | 89% (25 of 28) | 16% (5 of 31) | 51% (30 of 59) |
|   chariot | 42% (16 of 38) | 59% (10 of 17) | 47% (26 of 55) |
|   infantry | 61% (19 of 31) | 65% (35 of 54) | 64% (54 of 85) |
|   monster | - | 40% (4 of 10) | 40% (4 of 10) |
|   war machine | 74% (52 of 70) | 62% (21 of 34) | 70% (73 of 104) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.2 (19%) | 2.4 (30%) | 3.7 (25%) |
| CHARGED: it charged | 0.2 (4%) | 1.2 (15%) | 1.4 (10%) |
| IN COMBAT: it fought this turn or the last | 0.9 (14%) | 0.2 (3%) | 1.1 (8%) |
| MOVED: a war machine that moved | 1.2 (19%) | 1.4 (18%) | 2.7 (18%) |
| NO TARGET IN RANGE | 1.3 (21%) | 1.6 (19%) | 2.9 (20%) |
| ONLY IN COMBAT: the only targets were in combat | 0.0 (0%) | 0.1 (1%) | 0.1 (1%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.8 (12%) | 0.9 (11%) | 1.7 (11%) |
| SHELTERED: the target was sheltered | 0.2 (4%) | 0.3 (4%) | 0.6 (4%) |
| OTHER BAR | 0.4 (7%) | 0.0 (0%) | 0.4 (3%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 1.2 | 0.3 | 73% | 7.7 pts | 9 pts |
| character | 3.3 | 2.6 | 57% | 13.3 pts | 44 pts |
| chariot | 2.9 | 2.7 | 42% | 41.7 pts | 120 pts |
| infantry | 9.6 | 4.3 | 66% | 11.1 pts | 106 pts |
| monster | 0.4 | 0.0 | 100% | 0.0 pts | 0 pts |
| war machine | 8.1 | 10.3 | 56% | 30.8 pts | 250 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 1.8 | 3.1 | 2.4 |
| Charges that made contact a game | 1.6 | 2.4 | 2.0 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.67 declared, 0.50 contact (6 units) | 1.00 declared, 0.80 contact (5 units) | 0.82 declared, 0.64 contact (11 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 2.00 declared, 2.00 contact (2 units) | 2.00 declared, 2.00 contact (2 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.20 declared, 0.18 contact (61 units) | 0.33 declared, 0.25 contact (57 units) | 0.26 declared, 0.21 contact (118 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 36% (4 of 11) | - | 43% (3 of 7) | 39% (7 of 18) |
| Character in a unit | 86% (12 of 14) | 67% (10 of 15) | 50% (1 of 2) | 74% (23 of 31) |
| Character on its own | 100% (2 of 2) | 50% (4 of 8) | 30% (3 of 10) | 45% (9 of 20) |
| Chariot | 80% (4 of 5) | 62% (5 of 8) | - | 69% (9 of 13) |
| Infantry | 23% (3 of 13) | 9% (1 of 11) | - | 17% (4 of 24) |
| Monster | 50% (2 of 4) | 50% (1 of 2) | - | 50% (3 of 6) |
| Monstrous | 100% (1 of 1) | 100% (2 of 2) | - | 100% (3 of 3) |
| War Machines | 70% (7 of 10) | 100% (2 of 2) | - | 75% (9 of 12) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 67% (2 of 3); on the table 67% | 44% (45 of 102) | 61% | 59% (13 of 22) | 83% (5 of 6); 4.8 uses a game | 100% (2 of 2); 1.8 uses a game | 83% (5 of 6); 1.2 uses a game |
| Chaos Dwarfs | 4 | 71% (5 of 7); on the table 86% | 50% (18 of 36) | 42% | 53% (17 of 32) | 0.0 uses a game | 0.0 uses a game | 100% (2 of 2); 0.5 uses a game |
| Dwarfen Mountain Holds | 1 | - | - | 100% | 57% (4 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Grand Cathay | 2 | 100% (2 of 2); on the table 100% | 50% (18 of 36) | 65% | 44% (7 of 16) | 100% (4 of 4); 5.5 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |
| High Elf Realms | 2 | 100% (5 of 5); on the table 100% | 0% (0 of 6) | 63% | 33% (5 of 15) | 67% (2 of 3); 3.5 uses a game | 0% (0 of 2); 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 1 | - | 17% (1 of 6) | 100% | 86% (6 of 7) | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 4 | 86% (6 of 7); on the table 86% | 50% (6 of 12) | 41% | 54% (15 of 28) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 0.2 uses a game |

Flank and rear charges a unit could have turned to face (h5-opp-8766b98-p3, 9 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 47% (7) | 40% (4) | 44% (11) |
| ...free all their last turn and able to turn (per game) | 0.67 | 0.44 | 1.11 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.11 | 0.00 | 0.11 |
| ...with the charger already in that arc before they moved (per game) | 0.56 | 0.33 | 0.89 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.11 | 0.22 | 0.33 |

### Quality by phase: h5-opp-8766b98-p3

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.3 | 2.3 |
| Strategy | Charge objectives carried out (made contact) | 88% (14 of 16) | 48% (13 of 27) |
| Strategy | Shoot objectives carried out (shot that target) | 46% (51 of 110) | 49% (26 of 53) |
| Strategy | Support requests answered (helper made contact too) | 50% (1 of 2) | 33% (1 of 3) |
| Strategy | Hexes on a unit its side charged or shot that turn | - | 50% (4 of 8) |
| Strategy | Joined characters whose unit fought | 23% (6 of 26) | 27% (4 of 15) |
| Strategy | Lone characters that fought | 40% (6 of 15) | 69% (9 of 13) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 2.0 | 1.2 |
| Movement | Points that never moved of their own | 239.2 | 45.6 |
| Movement | Fights charged into per game | 1.3 | 2.2 |
| Movement | Charges with odds: long shots (under 50%) | 4 of 12, net -72 | 3 of 18, net -7 |
| Movement | Charges with odds: sweet spot (55-75%) | 2 of 12, net +101 | 1 of 18, net +230 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 1 of 12, net +137 | 5 of 18, net +47 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 of 12, net +88 | 5 of 18, net +170 |
| Shooting | Shots by shooting units (incl. breath weapons) | 7.4 | 7.6 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 34% (23 of 67) | 50% (34 of 68) |
| Shooting | Points destroyed by shooting units | 78.0 | 18.0 |
| Shooting | War machine shots | 5.8 | 2.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 50% (26 of 52) | 62% (13 of 21) |
| Shooting | Points destroyed by war machines | 106.4 | 47.8 |
| Magic | Magic missiles cast | 2.2 | 2.1 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 45% (9 of 20) | 37% (7 of 19) |
| Magic | Wounds caused by magic missiles | 4.7 | 4.8 |
| Magic | Wounds caused by other spells | 0.8 | 1.1 |
| Magic | Points destroyed by magic (all spells) | 21.2 | 73.7 |
| Magic | Augments / hexes / assailments / vortexes cast | 2.0 / 0.0 / 0.2 / 0.1 | 0.1 / 1.3 / 0.6 / 0.0 |
| Combat | Points destroyed in combat | 131.8 | 291.9 |
| Combat | Points run down | 35.9 | 16.3 |
| Combat | Net points per charged fight, damage counted | +51 | +141 |
| Combat | Net per 100 charger points, damage counted | +22.8 | +35.2 |
| Combat | First round won (charged fights) | 67% | 85% |
| Combat | Net points per charged fight | +59 | +135 |
| Combat | Net points per supported fight / lone fight | -274 / +90 | +521 / +92 |
| Combat | Charged fights on a top-3 enemy unit | 4 of 12 | 11 of 20 |
| Game | Points lost | 547.4 | 437.8 |
| Game | VP from objectives | 571.1 | 980.0 |
| Game | Lone holders (player turns) | 3.7 | 7.3 |

- Mine won / drew / lost: 3 / 1 / 5 of 9 ended games (of 9); mean margin (Mine - Opponent) -496 VP
- The side that went first won 3 of 8 games with a winner
- Points traded per game (both sides' losses): 985
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: h5-opp-8766b98-p3

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.1 | +3.6 | 0.0 | 0.0 | 0.1 | +49.7 | 0.0 | 0.0 |
| ALREADY CARRIED | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARRIVAL HUNT | - | - | - | - | 0.1 | +1.9 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 2.3 | +0.0 | 0.0 | 51.1 | 0.6 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | - | - | - | - | 0.2 | +1.3 | 0.0 | 0.0 |
| BEST PRIZE | - | - | - | - | 0.1 | -2.3 | 0.0 | 0.0 |
| BOMBING RUN | - | - | - | - | 0.2 | +6.3 | 0.0 | 33.3 |
| CANNON PLAN MISSED | 0.7 | +0.0 | 146.2 | 25.6 | 0.2 | +0.0 | 34.1 | 0.0 |
| CANNON PLANNED TARGET | 5.3 | +51.9 | 291.4 | 92.2 | 2.1 | +38.7 | 49.7 | 0.0 |
| CANNON SIGHT KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| CAST JOB | 1.2 | +27.8 | 93.6 | 27.9 | 0.2 | +2.7 | 0.0 | 0.0 |
| CASTER AWAY FROM SCREEN | 0.6 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 1.0 | +71.8 | 42.4 | 0.0 | 0.3 | +1.5 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 0.7 | +0.0 | 0.0 | 39.4 | 0.6 | +0.0 | 0.0 | 44.4 |
| CHAFF IN THE MOVE | 0.4 | +20.5 | 0.0 | 31.1 | 0.4 | +5.7 | 0.0 | 3.8 |
| CHAFF PASSED | - | - | - | - | 0.2 | -0.1 | 0.0 | 16.7 |
| CHARACTER GUNS | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHARGE LOSSES | 5.6 | -194.7 | 0.0 | 154.1 | 4.9 | -292.0 | 0.0 | 240.6 |
| CHARGE NOT DECLARED | 1.0 | +0.0 | 62.3 | 21.0 | 0.3 | +0.0 | 94.4 | 0.0 |
| CHARGE NOW FIRST | 1.1 | +0.0 | 134.9 | 0.0 | 1.8 | +0.0 | 367.3 | 25.9 |
| CHARGER SLAIN LOST | 0.6 | -53.4 | 16.7 | 21.0 | 0.2 | -1.3 | 34.4 | 6.7 |
| CHEAP HELPER | 0.2 | +0.0 | 0.0 | 5.8 | - | - | - | - |
| COMBAT PIVOT | 0.6 | +0.0 | 0.0 | 68.9 | - | - | - | - |
| CONVEYANCE SEARCH | 1.7 | +392.0 | 71.6 | 78.9 | 0.1 | +44.4 | 44.4 | 44.4 |
| COVER ONCE | 5.9 | -725.6 | 0.0 | 120.8 | 4.0 | -147.7 | 0.0 | 51.3 |
| DEFENSIVE FLOOR | 0.1 | +1.8 | 15.4 | 0.0 | - | - | - | - |
| DEPLOY BY FIGURES | 7.8 | +52.9 | 0.0 | 7.2 | 6.7 | +5.8 | 0.0 | 0.0 |
| EDGE GIVE GROUND | - | - | - | - | 0.3 | +25.3 | 97.1 | 0.0 |
| ENGINEER BY LORE | 0.4 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FALL BACK GOOD ORDER | 1.1 | +14.5 | 73.4 | 18.4 | 1.8 | +8.6 | 255.8 | 25.9 |
| FALLBACK BY WORTH | 0.2 | +4.0 | 0.0 | 12.8 | 0.2 | +0.0 | 0.0 | 7.6 |
| FALLS SHORT | 5.7 | +118.4 | 0.0 | 108.8 | 18.0 | +312.9 | 0.0 | 361.6 |
| FEATURE BUFFS | 3.0 | +82.5 | 0.0 | 93.1 | 0.8 | +18.8 | 0.0 | 0.0 |
| FIGHT TO THE END | 0.7 | +4.6 | 70.6 | 0.0 | 1.1 | +193.2 | 219.9 | 19.2 |
| FIVE ACTION | 44.2 | +2483.5 | 1051.1 | 554.9 | 39.4 | +3973.7 | 630.8 | 723.1 |
| FLANK NOT WEIGHED | 3.7 | +0.0 | 0.0 | 73.1 | 4.8 | +0.0 | 0.0 | 165.1 |
| FOLLOW UP WEIGHED | 0.3 | +63.7 | 0.0 | 0.0 | 0.9 | +278.3 | 0.0 | 0.0 |
| FOUR ROUNDS | 1.8 | +172.2 | 122.3 | 30.0 | 2.9 | +592.0 | 454.6 | 85.9 |
| FRIEND SHOOTS FIRST | 0.6 | -22.7 | 0.0 | 34.4 | 0.2 | -10.2 | 0.0 | 44.4 |
| GIVES UP | - | - | - | - | 0.2 | -6.5 | 0.0 | 0.0 |
| GROUND FLIERS | 0.1 | +4.7 | 0.0 | 0.0 | - | - | - | - |
| GUN FIGURES | 0.8 | +5.7 | 18.9 | 34.4 | 0.2 | +6.1 | 7.2 | 20.6 |
| GUN MASK | 0.1 | +0.5 | 0.0 | 0.0 | 1.1 | +21.5 | 0.0 | 53.9 |
| HARD STAY DROPPED | 1.7 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| HE SHOOTS OR CHARGES | 2.7 | +0.0 | 0.0 | 71.8 | 2.1 | +0.0 | 0.0 | 165.8 |
| HELPER ALREADY ASKED | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HELPER UNSEEN | 0.1 | +0.0 | 0.0 | 9.0 | - | - | - | - |
| HIS CHARGE DENIED | 0.3 | +6.8 | 16.7 | 18.4 | 0.3 | +14.2 | 54.4 | 49.1 |
| HIS CHARGE LIST | 3.4 | +0.0 | 0.0 | 93.6 | 1.7 | +0.0 | 0.0 | 16.1 |
| HIS LEGAL MOVES | 2.7 | +0.0 | 0.0 | 0.0 | 3.2 | +0.0 | 0.0 | 90.0 |
| HIS MOVE AND SHOT | 1.7 | -22.4 | 0.0 | 36.8 | 1.7 | -90.4 | 0.0 | 104.2 |
| HIS RANDOM MOVE | 1.8 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 21.2 |
| HIS SHOT LIST | 17.8 | +499.7 | 0.0 | 207.7 | 21.1 | +1223.8 | 0.0 | 455.2 |
| HIS TURN DENIED | 0.3 | +27.9 | 12.8 | 0.0 | 1.7 | +106.0 | 311.2 | 0.0 |
| HOLD ODDS | - | - | - | - | 14.2 | +0.0 | 0.0 | 62.8 |
| HOLDER ASSIGNMENT | - | - | - | - | 16.9 | +1613.1 | 0.0 | 62.8 |
| HOLDER AT DEPLOYMENT | 1.4 | +171.2 | 0.0 | 0.0 | - | - | - | - |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 1.1 | -54.3 | 105.7 | 0.0 | 2.4 | -131.8 | 420.1 | 68.3 |
| HUNT IN PAIRS | 0.2 | +8.3 | 0.0 | 0.0 | 0.6 | +20.5 | 0.0 | 0.0 |
| IDLE COST | 1.8 | -12.9 | 0.0 | 6.1 | 9.0 | -185.7 | 0.0 | 206.3 |
| JOINT KNOWS CHALLENGE | - | - | - | - | 0.2 | -11.1 | 71.6 | 0.0 |
| KEEP FALLS | 0.2 | +2.3 | 0.0 | 0.0 | - | - | - | - |
| LANE BY FIGURES | 0.4 | +30.8 | 0.0 | 0.0 | 0.6 | +8.6 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 5.3 | +0.0 | 210.4 | 309.7 | 0.9 | +0.0 | 110.6 | 6.7 |
| LONE WIZARD KEPT IN | 1.1 | +94.1 | 0.0 | 0.0 | 0.2 | +23.8 | 0.0 | 0.0 |
| LONG SHOT | 0.1 | -0.3 | 0.0 | 9.0 | 0.1 | +0.1 | 0.0 | 19.2 |
| LOST CHARGE | - | - | - | - | 0.1 | -0.2 | 0.0 | 19.2 |
| MAKE SURE TOGETHER | - | - | - | - | 0.2 | +4.3 | 0.0 | 0.0 |
| MANOEUVRE | 1.1 | +14.5 | 0.0 | 0.0 | 1.7 | +12.3 | 0.0 | 12.8 |
| MARCH AT ESCAPER | 0.6 | +3.4 | 0.0 | 0.0 | 0.1 | +1.3 | 0.0 | 0.0 |
| MARCH BY THE SUM | 0.2 | +7.5 | 0.0 | 0.0 | 1.1 | +113.6 | 0.0 | 0.0 |
| MARCH CHECK | 1.4 | +119.9 | 0.0 | 9.0 | 2.2 | +124.2 | 0.0 | 0.0 |
| MARCH OVER CASTS | 0.6 | +144.3 | 0.0 | 0.0 | 1.7 | +44.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 6.0 | +92.8 | 0.0 | 177.0 | 5.3 | +50.3 | 0.0 | 141.4 |
| MISSILES IN THE MOVE | 6.2 | +264.1 | 0.0 | 117.9 | 4.1 | +93.7 | 0.0 | 44.4 |
| MISSILES NEXT TURN | 6.7 | +161.6 | 0.0 | 108.4 | 5.9 | +62.2 | 0.0 | 88.9 |
| MOVE SPELL NOT WORTH | 0.1 | -0.1 | 7.2 | 39.4 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.7 | -131.4 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL SPOT | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 44.4 |
| MOVE TO CHARGE COMPUTED | 3.4 | +459.2 | 0.0 | 49.7 | 4.0 | +803.5 | 0.0 | 139.9 |
| MOVES UNITS SPELL | 0.2 | +12.2 | 0.0 | 0.0 | 0.1 | +0.8 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 5.6 | +355.9 | 0.0 | 21.1 | 6.6 | +271.8 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 4.8 | -207.5 | 23.7 | 49.7 | 5.6 | -330.0 | 0.0 | 228.9 |
| NEXT OBJECTIVE NEARER | 7.0 | -401.2 | 97.9 | 18.4 | 0.3 | -2.2 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 1.4 | -57.3 | 83.7 | 30.0 | 2.0 | -170.6 | 335.1 | 68.3 |
| NO RALLY LEFT | 0.1 | +31.5 | 0.0 | 0.0 | 0.1 | +8.6 | 0.0 | 0.0 |
| NOT TURNED | 0.1 | +0.0 | 0.0 | 9.4 | 0.2 | +0.0 | 0.0 | 3.8 |
| NOT WORTH A CAST | 1.0 | -1.3 | 0.0 | 0.0 | 0.3 | -0.3 | 0.0 | 0.0 |
| OFF BEST | 0.2 | -5.2 | 0.0 | 3.3 | 0.3 | -24.3 | 0.0 | 0.0 |
| ONE CHARGE A CHARGER | 2.8 | +0.0 | 0.0 | 62.8 | 1.2 | +0.0 | 0.0 | 57.0 |
| ONE FIGHT FORMULA | 5.2 | -88.9 | 0.0 | 14.8 | 4.8 | -165.6 | 0.0 | 216.3 |
| ONE OBJECTIVE FORMULA | 5.0 | -129.9 | 0.0 | 95.7 | 6.4 | -9.1 | 0.0 | 47.3 |
| ONE TARGET A SHOOTER | 16.7 | +336.2 | 0.0 | 234.2 | 16.3 | +420.7 | 0.0 | 343.0 |
| OPENS UP | 0.2 | +7.7 | 19.8 | 0.0 | 0.2 | +18.9 | 10.6 | 0.0 |
| OVERRUNS AWAY | - | - | - | - | 0.7 | +77.2 | 94.1 | 49.1 |
| PATHS CROSS | 3.8 | +172.0 | 0.0 | 118.2 | 4.3 | +166.1 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.2 | -2.5 | 0.0 | 34.4 | - | - | - | - |
| PLAN RESULT | 38.9 | +973.0 | 662.4 | 822.4 | 34.7 | +538.7 | 339.7 | 721.7 |
| PURSUES BIG PREY | 0.1 | -13.3 | 0.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | - | - | - | - | 3.3 | +607.3 | 79.4 | 111.0 |
| RANDOM MOVE BY FIGURES | 1.1 | +34.1 | 0.0 | 18.9 | 0.6 | +17.6 | 0.0 | 18.9 |
| REDIRECT BY WHAT IT STOPS | 0.2 | -4.9 | 0.0 | 18.9 | 0.2 | -8.2 | 0.0 | 7.6 |
| REDIRECT COUNTER | 2.1 | +132.1 | 0.0 | 66.1 | 2.3 | +92.5 | 0.0 | 103.4 |
| REDIRECT WEIGHED | - | - | - | - | 0.1 | -2.3 | 0.0 | 0.0 |
| REFORMS TO MEET IT | 0.9 | -46.8 | 0.0 | 15.2 | 0.8 | -81.0 | 0.0 | 12.8 |
| REFUSING RETIRES | - | - | - | - | 0.1 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | 0.3 | +10.4 | 0.0 | 0.0 | 0.1 | +9.3 | 0.0 | 16.7 |
| RISK BY ARC | 1.4 | +50.9 | 92.8 | 30.0 | 1.9 | -40.1 | 318.8 | 75.0 |
| RISK BY HIS FIGURE | 12.0 | -152.0 | 0.0 | 238.1 | 10.7 | -254.5 | 0.0 | 358.0 |
| RUN DOWN | 1.1 | -7.0 | 103.4 | 0.0 | 1.6 | -14.0 | 213.4 | 49.1 |
| SAME CHARGE LATER | - | - | - | - | 0.3 | -2.1 | 0.0 | 33.0 |
| SCOUT SPOT | 0.2 | +0.3 | 0.0 | 0.0 | 0.2 | -0.0 | 0.0 | 0.0 |
| SCOUT WAITS | 0.2 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.4 | -45.9 | 0.0 | 3.3 | 0.3 | -15.3 | 0.0 | 0.0 |
| SEARCH SPOT | 3.6 | +123.6 | 0.0 | 48.2 | 3.7 | +166.4 | 0.0 | 90.9 |
| SELF MOVE SPELL | - | - | - | - | 0.7 | +151.8 | 0.0 | 0.0 |
| SET UP TOGETHER | - | - | - | - | 0.3 | +4.4 | 0.0 | 0.0 |
| SET-UP ANY TARGET | 0.1 | +23.9 | 35.8 | 39.4 | - | - | - | - |
| SHOOTER COUNTED ONCE | 0.1 | -0.7 | 0.0 | 3.3 | - | - | - | - |
| SHOOTERS IN TWO RANKS | 0.2 | +0.4 | 0.0 | 0.0 | 0.2 | +0.2 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.1 | +63.9 | 76.8 | 0.0 | 0.7 | +8.6 | 19.1 | 26.0 |
| SHOT OR CHARGE | 0.1 | -1.9 | 0.0 | 9.4 | 0.2 | -34.9 | 51.1 | 0.0 |
| SHOT RISK POINTS | 9.6 | +96.8 | 0.0 | 158.2 | 11.8 | -48.5 | 0.0 | 437.3 |
| SHOTS IN THE MOVE | 12.7 | +576.0 | 0.0 | 226.3 | 10.9 | +336.9 | 0.0 | 262.4 |
| SPELL SETS UP CHARGE | 0.2 | +91.4 | 35.8 | 39.4 | - | - | - | - |
| SPELL WORTH | - | - | - | - | 0.2 | +6.5 | 88.9 | 88.9 |
| SPELLS IN THE FIGHT | 0.4 | +3.3 | 55.4 | 0.0 | 0.1 | +0.9 | 9.4 | 0.0 |
| STAND AND SHOOT | 0.2 | -2.4 | 12.8 | 0.0 | 0.2 | -3.4 | 19.7 | 0.0 |
| STANDS FOR A REASON | - | - | - | - | 0.6 | +0.0 | 0.0 | 26.0 |
| STANDS STILL | 20.3 | +0.0 | 928.8 | 243.6 | 9.2 | +0.0 | 160.7 | 66.0 |
| STAY WORTH | 15.3 | +85.5 | 402.6 | 65.6 | 12.4 | +149.5 | 118.3 | 261.2 |
| SUPPORT NARROWED | 0.9 | +0.0 | 58.7 | 9.4 | 1.1 | +0.0 | 161.8 | 25.9 |
| SURE REACH TOGETHER | 0.1 | +0.8 | 0.0 | 0.0 | - | - | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 4.2 | +0.0 | 0.0 | 118.2 | 4.7 | +0.0 | 0.0 | 37.3 |
| THE PROMISE ADDS | 0.6 | -11.2 | 0.0 | 5.8 | 0.4 | -17.4 | 35.8 | 0.0 |
| THE PROMISED MOVE | 0.6 | +0.0 | 0.0 | 0.0 | 1.2 | +0.0 | 0.0 | 33.0 |
| TIED UP BY THE SUM | 0.4 | +40.2 | 51.6 | 0.0 | 0.3 | +42.0 | 29.1 | 0.0 |
| TIME ON OUR SIDE | 31.0 | +495.8 | 13.6 | 271.0 | 5.7 | +120.3 | 0.0 | 62.8 |
| WAITS AGAIN | 1.6 | +0.0 | 0.0 | 50.8 | 1.4 | +0.0 | 0.0 | 44.9 |
| WAR ENGINE JOBS | 0.9 | +0.0 | 125.3 | 68.9 | - | - | - | - |
| WHO HITS BACK | - | - | - | - | 0.2 | +4.6 | 0.0 | 0.0 |
| WHOLE FIGHT | 0.1 | +8.7 | 18.9 | 0.0 | 0.2 | +18.3 | 68.9 | 6.7 |
| WHOLE FIGHT GAIN | 0.3 | +13.8 | 0.0 | 11.6 | 0.2 | +24.8 | 0.0 | 10.9 |
| WIDER SPREAD | 1.2 | +13.1 | 77.7 | 21.0 | 2.3 | -7.5 | 372.4 | 25.9 |
| WOUNDS ON THE RANKS | 1.7 | +58.9 | 0.0 | 71.6 | 1.8 | +76.8 | 0.0 | 0.0 |

### Rule changes: h5-opp-8766b98-p3

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HOLDER ASSIGNMENT | 152 | 152 | 143 | 15.89 | +7059 | +49.4 |
| HIS SHOT LIST | 350 | 350 | 100 | 11.11 | +2186 | +21.9 |
| DEPLOY BY FIGURES | 130 | 130 | 79 | 8.78 | +1210 | +15.3 |
| ONE TARGET A SHOOTER | 297 | 297 | 79 | 8.78 | +694 | +8.8 |
| PATHS CROSS | 73 | 73 | 73 | 8.11 | +3043 | +41.7 |
| SEARCH SPOT | 65 | 65 | 59 | 6.56 | +2611 | +44.2 |
| TIME ON OUR SIDE | 330 | 288 | 57 | 6.33 | +280 | +4.9 |
| LEGAL CHARGES ONLY | 56 | 56 | 56 | 6.22 | +0 | +0.0 |
| FIVE ACTION | 753 | 753 | 46 | 5.11 | +2043 | +44.4 |
| MOVE TO CHARGE COMPUTED | 67 | 67 | 40 | 4.44 | +3095 | +77.4 |
| FOUR ROUNDS | 42 | 42 | 30 | 3.33 | +3225 | +107.5 |
| SHOT RISK POINTS | 192 | 192 | 30 | 3.33 | +1220 | +40.7 |
| ARTILLERY RE-ROLL WEIGHED | 26 | 26 | 26 | 2.89 | +0 | +0.0 |
| MARCH CHECK | 33 | 33 | 24 | 2.67 | +472 | +19.7 |
| MAX FOR POSITIONING | 102 | 99 | 19 | 2.11 | +96 | +5.1 |
| FALLS SHORT | 213 | 181 | 18 | 2.00 | +98 | +5.4 |
| SHOTS IN THE MOVE | 212 | 200 | 18 | 2.00 | +626 | +34.8 |
| HARD STAY DROPPED | 17 | 17 | 17 | 1.89 | +0 | +0.0 |
| MISSILES IN THE MOVE | 93 | 67 | 17 | 1.89 | +793 | +46.6 |
| MANOEUVRE | 25 | 25 | 14 | 1.56 | +241 | +17.2 |
| CHARGE NOT DECLARED | 12 | 12 | 12 | 1.33 | -2510 | -209.2 |
| COVER ONCE | 89 | 62 | 12 | 1.33 | +228 | +19.0 |
| LONE WIZARD KEPT IN | 12 | 12 | 12 | 1.33 | +1060 | +88.4 |
| MARCH BY THE SUM | 12 | 12 | 12 | 1.33 | +1089 | +90.8 |
| RISK BY HIS FIGURE | 204 | 204 | 12 | 1.33 | +1186 | +98.8 |
| ADVANCE LANE KEPT | 11 | 11 | 11 | 1.22 | +0 | +0.0 |
| CANNON SIGHT KEPT | 11 | 11 | 11 | 1.22 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 11 | 11 | 11 | 1.22 | +3078 | +279.8 |
| REDIRECT COUNTER | 40 | 33 | 11 | 1.22 | +995 | +90.5 |
| SHOOTS FROM THE BEST SPOT | 16 | 16 | 11 | 1.22 | +80 | +7.2 |
| CANNON PLANNED TARGET | 67 | 67 | 10 | 1.11 | -139 | -13.9 |
| CASTING BLOCK | 12 | 12 | 10 | 1.11 | +171 | +17.1 |
| CHARGE LOSSES | 94 | 94 | 10 | 1.11 | +944 | +94.4 |
| LANE BY FIGURES | 9 | 9 | 9 | 1.00 | +355 | +39.4 |
| NEXT CHARGE BY LIST | 93 | 93 | 9 | 1.00 | +126 | +14.0 |
| NEXT OBJECTIVE NEARER | 66 | 66 | 9 | 1.00 | +169 | +18.8 |
| STAY WORTH | 250 | 240 | 9 | 1.00 | +94 | +10.4 |
| HOLDER AT DEPLOYMENT | 13 | 13 | 8 | 0.89 | +314 | +39.2 |
| RISK BY ARC | 30 | 30 | 8 | 0.89 | +230 | +28.7 |
| WOUNDS ON THE RANKS | 31 | 31 | 8 | 0.89 | +181 | +22.6 |
| HOLDS AMBUSHERS | 7 | 7 | 7 | 0.78 | +0 | +0.0 |
| IDLE COST | 97 | 74 | 7 | 0.78 | +110 | +15.8 |
| NEARER NOT NEEDED | 109 | 103 | 7 | 0.78 | +248 | +35.5 |
| ONE OBJECTIVE FORMULA | 103 | 89 | 7 | 0.78 | +245 | +35.0 |
| CASTER AWAY FROM SCREEN | 6 | 6 | 6 | 0.67 | +0 | +0.0 |
| CHAFF IN THE MOVE | 8 | 8 | 5 | 0.56 | +0 | +0.0 |
| CHARGE NOW FIRST | 26 | 26 | 5 | 0.56 | -286 | -57.1 |
| COMBAT PIVOT | 5 | 5 | 5 | 0.56 | +0 | +0.0 |
| OFF BEST | 5 | 5 | 5 | 0.56 | -265 | -53.1 |
| RANDOM MOVE BY FIGURES | 15 | 15 | 5 | 0.56 | +465 | +93.0 |
| SCOUT WAITS | 5 | 5 | 5 | 0.56 | +0 | +0.0 |
| TIED UP BY THE SUM | 7 | 7 | 5 | 0.56 | +209 | +41.8 |
| FIGHT TO THE END | 16 | 16 | 4 | 0.44 | +604 | +151.0 |
| ONE FIGHT FORMULA | 90 | 46 | 4 | 0.44 | +23 | +5.8 |
| OVERRUNS AWAY | 6 | 6 | 4 | 0.44 | +226 | +56.4 |
| QUARTER ODDS | 30 | 30 | 4 | 0.44 | +819 | +204.8 |
| RESERVE FALL BACK | 4 | 4 | 4 | 0.44 | +178 | +44.4 |
| SHOOTERS IN TWO RANKS | 4 | 4 | 4 | 0.44 | +6 | +1.5 |
| FEATURE BUFFS | 34 | 34 | 3 | 0.33 | +17 | +5.8 |
| HIS TURN DENIED | 18 | 18 | 3 | 0.33 | +191 | +63.8 |
| MOVES UNITS SPELL | 3 | 3 | 3 | 0.33 | +118 | +39.2 |
| OPENS UP | 4 | 4 | 3 | 0.33 | +162 | +53.8 |
| AFTERMATH IN POINTS | 2 | 2 | 2 | 0.22 | +480 | +240.2 |
| BOMBING RUN | 2 | 2 | 2 | 0.22 | +57 | +28.4 |
| CAST JOB | 13 | 13 | 2 | 0.22 | +1 | +0.4 |
| CHAFF PASSED | 2 | 2 | 2 | 0.22 | -1 | -0.4 |
| KEEP FALLS | 2 | 2 | 2 | 0.22 | +30 | +15.2 |
| NO RALLY LEFT | 2 | 2 | 2 | 0.22 | +119 | +59.7 |
| PIVOT GUARDS FLANK | 2 | 2 | 2 | 0.22 | -22 | -11.2 |
| SUPPORT NARROWED | 18 | 18 | 2 | 0.22 | -11 | -5.6 |
| WHO HITS BACK | 2 | 2 | 2 | 0.22 | +19 | +9.5 |
| WHOLE FIGHT | 3 | 3 | 2 | 0.22 | +127 | +63.5 |
| WHOLE FIGHT GAIN | 5 | 5 | 2 | 0.22 | +66 | +33.2 |
| BEST PRIZE | 1 | 1 | 1 | 0.11 | -21 | -20.9 |
| EDGE GIVE GROUND | 3 | 3 | 1 | 0.11 | +27 | +26.7 |
| FALL BACK GOOD ORDER | 26 | 26 | 1 | 0.11 | +95 | +94.9 |
| FALLBACK BY WORTH | 4 | 4 | 1 | 0.11 | +36 | +36.1 |
| GUN MASK | 11 | 11 | 1 | 0.11 | +33 | +33.4 |
| HUNT IN PAIRS | 7 | 1 | 1 | 0.11 | +121 | +120.9 |
| MISSILES NEXT TURN | 113 | 78 | 1 | 0.11 | +0 | +0.0 |
| PURSUES BIG PREY | 1 | 1 | 1 | 0.11 | -120 | -120.0 |
| REDIRECT WEIGHED | 1 | 1 | 1 | 0.11 | +206 | +206.0 |
| REFUSING RETIRES | 1 | 1 | 1 | 0.11 | -0 | -0.5 |
| SCREEN BY WHAT IT SAVES | 7 | 7 | 1 | 0.11 | +2 | +1.8 |
| SET UP TOGETHER | 3 | 1 | 1 | 0.11 | +15 | +15.1 |
| SPELLS IN THE FIGHT | 5 | 5 | 1 | 0.11 | +6 | +5.7 |
| SURE REACH TOGETHER | 1 | 1 | 1 | 0.11 | +6 | +5.5 |
| THE PROMISE ADDS | 9 | 9 | 1 | 0.11 | +0 | +0.1 |
| ALREADY CARRIED | 1 | not checked | - | - | - | - |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| BACKUP TARGETS | 2 | 1 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 8 | 8 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 11 | trace | - | - | - | - |
| CHARACTER GUNS | 1 | 1 | 0 | 0.00 | - | - |
| CHARGER SLAIN LOST | 7 | 7 | 0 | 0.00 | - | - |
| CHEAP HELPER | 2 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 16 | not checked | - | - | - | - |
| DEFENSIVE FLOOR | 1 | 1 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 76 | not checked | - | - | - | - |
| FRIEND SHOOTS FIRST | 7 | 7 | 0 | 0.00 | - | - |
| GIVES UP | 2 | 2 | 0 | 0.00 | - | - |
| GROUND FLIERS | 1 | not checked | - | - | - | - |
| GUN FIGURES | 9 | not checked | - | - | - | - |
| HE SHOOTS OR CHARGES | 43 | 43 | 0 | 0.00 | - | - |
| HELPER ALREADY ASKED | 1 | not checked | - | - | - | - |
| HELPER UNSEEN | 1 | 1 | 0 | 0.00 | - | - |
| HIS CHARGE DENIED | 6 | 6 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 46 | 46 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 53 | 53 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 30 | 30 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 31 | 31 | 0 | 0.00 | - | - |
| HOLD ODDS | 128 | 128 | 0 | 0.00 | - | - |
| HONEST WORTH | 32 | 32 | 0 | 0.00 | - | - |
| JOINT KNOWS CHALLENGE | 2 | 2 | 0 | 0.00 | - | - |
| LONG SHOT | 2 | 2 | 0 | 0.00 | - | - |
| LOST CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 2 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 6 | trace | - | - | - | - |
| MARCH OVER CASTS | 20 | 20 | 0 | 0.00 | - | - |
| MOVE SPELL NOT WORTH | 1 | not checked | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 6 | trace | - | - | - | - |
| MOVE SPELL SPOT | 2 | not checked | - | - | - | - |
| NO DOUBLE ROUNDS | 31 | 31 | 0 | 0.00 | - | - |
| NOT TURNED | 3 | 3 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 12 | not checked | - | - | - | - |
| ONE CHARGE A CHARGER | 36 | 36 | 0 | 0.00 | - | - |
| PLAN RESULT | 662 | trace | - | - | - | - |
| REDIRECT BY WHAT IT STOPS | 4 | 4 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 15 | 15 | 0 | 0.00 | - | - |
| RUN DOWN | 24 | 24 | 0 | 0.00 | - | - |
| SAME CHARGE LATER | 3 | 3 | 0 | 0.00 | - | - |
| SCOUT SPOT | 4 | 4 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 6 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 1 | not checked | - | - | - | - |
| SHOOTER COUNTED ONCE | 1 | 1 | 0 | 0.00 | - | - |
| SHOT OR CHARGE | 3 | 3 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 2 | not checked | - | - | - | - |
| SPELL WORTH | 2 | not checked | - | - | - | - |
| STAND AND SHOOT | 4 | 4 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 5 | 5 | 0 | 0.00 | - | - |
| STANDS STILL | 266 | 266 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 80 | not checked | - | - | - | - |
| THE PROMISED MOVE | 16 | not checked | - | - | - | - |
| WAITS AGAIN | 27 | 27 | 0 | 0.00 | - | - |
| WAR ENGINE JOBS | 8 | 8 | 0 | 0.00 | - | - |
| WIDER SPREAD | 32 | 32 | 0 | 0.00 | - | - |

### Off best figure: h5-opp-8766b98-p3

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| PATHS CROSS | rule | 0.67 | 0.89 | 36.7 |
| HOLDER ASSIGNMENT | rule | - | 1.44 | 21.8 |
| CHARGE NOT DECLARED | rule | 1.00 | 0.33 | 209.2 |
| CHARGE NOW FIRST | rule | 0.11 | 0.44 | 57.1 |
| CANNON PLANNED TARGET | rule | 0.33 | 0.11 | 44.3 |
| AFTERMATH BAND | gate | 0.11 | 0.11 | 2.8 |
| PIVOT GUARDS FLANK | rule | 0.22 | - | 11.2 |
| SUPPORT NARROWED | rule | - | 0.22 | 5.6 |
| AFTERMATH NEEDS NEXT CHARGE | gate | - | 0.11 | 202.0 |
| BEST PRIZE | rule | - | 0.11 | 20.9 |
| CHAFF PASSED | rule | - | 0.11 | 0.9 |
| DEPLOY BY FIGURES | rule | - | 0.11 | 4.7 |
| JOB FIRST | gate | 0.11 | - | 42.5 |
| NO REASON | gate | - | 0.11 | 15.3 |
| PURSUES BIG PREY | rule | 0.11 | - | 120.0 |

### Plans: h5-opp-8766b98-p3

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.6 | 64% | 171 | 131 | 77% |
| Mine | join | 0.1 | 100% | 4 | 0 | 0% |
| Mine | move | 26.0 | 96% | 1714 | 0 | 0% |
| Mine | shoot | 10.7 | 66% | 564 | 842 | 149% |
| Mine | support | 0.6 | 80% | 8 | 0 | 0% |
| Opponent | charge | 2.3 | 71% | 702 | 377 | 54% |
| Opponent | move | 27.1 | 92% | 2412 | 0 | 0% |
| Opponent | shoot | 4.7 | 38% | 247 | 162 | 65% |
| Opponent | support | 0.6 | 100% | 0 | 0 | - |

### Battle groups: h5-opp-8766b98-p3

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 2.1 | 16% | 100% | 0% | - | 0% | 0% | 0% | 67% | 33% |
| Opponent | REDIRECT COUNTER | 2.3 | 29% | 83% | 0% | - | 0% | 0% | 33% | 67% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: h5-opp-8766b98-p3

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 8 | 5 (8) | 0 | 5 | 47 | 75% | 1.5 | 0 (3) | 12 (3) | 0 (2) | 6 (7) | 0 (1) |
| Mine | Character | 33 | 13 (33) | 13 | 0 | 9 | 33% | 2.0 | 8 (5) | 18 (22) | 0 (3) | 11 (20) | 18 (10) |
| Mine | Clean-up | 6 | 97 (6) | 97 | 0 | 33 | 33% | 3.0 | 13 (1) | 0 (2) | 190 (3) | 195 (3) | 0 (3) |
| Mine | Fast Hammer | 4 | 0 (4) | 0 | 0 | 100 | 25% | 3.3 | - | - | 0 (4) | 0 (2) | 0 (2) |
| Mine | Hammer | 22 | 36 (22) | 22 | 15 | 39 | 27% | 2.0 | 53 (4) | 33 (16) | 0 (2) | 40 (17) | 27 (5) |
| Mine | Holder | 14 | 92 (14) | 10 | 82 | 37 | 71% | 4.5 | 0 (2) | 104 (7) | 103 (5) | 118 (7) | 59 (7) |
| Mine | Shooter | 5 | 150 (5) | 46 | 104 | 26 | 20% | 2.0 | 138 (1) | 178 (3) | 0 (1) | 165 (4) | 46 (1) |
| Mine | War machine | 13 | 77 (13) | 77 | 0 | 45 | 0% | 1.3 | 0 (2) | 112 (7) | 58 (4) | 0 (4) | 113 (9) |
| Mine | Wizard | 8 | 0 (8) | 0 | 0 | 22 | 25% | 4.2 | 0 (1) | 0 (7) | - | 0 (3) | 0 (5) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Chaff | 13 | 198 (13) | 0 | 198 | 59 | 54% | 4.0 | 551 (3) | 147 (6) | 0 (4) | 135 (10) | 371 (3) |
| Opponent | Character | 25 | 49 (25) | 49 | 0 | 19 | 28% | 2.3 | 30 (4) | 52 (15) | 54 (6) | 45 (16) | 57 (9) |
| Opponent | Clean-up | 2 | 44 (2) | 0 | 44 | 0 | 0% | 4.0 | - | 44 (2) | - | 53 (1) | 35 (1) |
| Opponent | Fast | 1 | 0 (1) | 0 | 0 | 100 | 0% | 3.0 | 0 (1) | - | - | 0 (1) | - |
| Opponent | Fast Hammer | 18 | 62 (18) | 10 | 52 | 18 | 61% | 3.0 | 87 (4) | 35 (9) | 96 (5) | 73 (11) | 43 (7) |
| Opponent | Hammer | 9 | 7 (9) | 4 | 3 | 58 | 22% | 2.6 | - | 0 (4) | 13 (5) | 13 (6) | 0 (3) |
| Opponent | Holder | 3 | 114 (3) | 0 | 114 | 31 | 67% | 4.0 | - | 114 (3) | - | 98 (2) | 188 (1) |
| Opponent | Shooter | 7 | 108 (7) | 41 | 67 | 16 | 0% | 2.0 | 55 (2) | 108 (4) | 188 (1) | 131 (5) | 50 (2) |
| Opponent | War machine | 6 | 7 (6) | 7 | 0 | 21 | 0% | 2.3 | 8 (4) | 0 (2) | - | - | 7 (6) |
| Opponent | Wizard | 3 | 2 (3) | 2 | 0 | 0 | 0% | 2.0 | - | 0 (2) | 4 (1) | 2 (3) | - |

### Charged fights: h5-opp-8766b98-p3

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 48 | 84 | 1.5 | 1.3 | 56 | 73 | -17 | 3 of 6 | 3 of 6 | -274 | +34 |
| Mine | Chaos Dwarfs | 4 | 285 | 204 | 1.5 | 1.0 | 136 | 0 | +136 | 1 of 6 | 5 of 6 | - | +136 |
| Mine | Dwarfen Mountain Holds | 1 | 521 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| **Mine** | all armies | 9 | 206 | 128 | 1.3 | 1.2 | 96 | 37 | +59 | 4 of 12 | 8 of 12 | -274 | +90 |
| Opponent | Grand Cathay | 2 | 229 | 451 | 1.5 | 1.3 | 301 | 0 | +301 | 1 of 3 | 3 of 3 | +902 | +0 |
| Opponent | High Elf Realms | 2 | 168 | 472 | 3.0 | 1.0 | 158 | 10 | +148 | 3 of 6 | 5 of 6 | - | +148 |
| Opponent | Ogre Kingdoms | 1 | 65 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Warriors of Chaos | 4 | 99 | 295 | 2.8 | 1.1 | 107 | 25 | +83 | 7 of 11 | 9 of 11 | +140 | +77 |
| **Opponent** | all armies | 9 | 139 | 336 | 2.2 | 1.1 | 151 | 17 | +135 | 11 of 20 | 17 of 20 | +521 | +92 |

### Effective charges: h5-opp-8766b98-p3

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 6 | 4 (net -72) | 0 | 0 | 1 (net +147) | 0 | 1 (net +41) | 0 | 0% (0 of 6) |
| Mine | Chaos Dwarfs | 6 | 0 | 0 | 2 (net +101) | 2 (net +170) | 1 (net +137) | 1 (net +135) | 0 | 33% (2 of 6) |
| Opponent | Grand Cathay | 3 | 0 | 0 | 0 | 1 (net +902) | 2 (net +0) | 0 | 0 | 0% (0 of 3) |
| Opponent | High Elf Realms | 6 | 1 (net +250) | 0 | 1 (net +230) | 2 (net +155) | 2 (net +48) | 0 | 0 | 17% (1 of 6) |
| Opponent | Warriors of Chaos | 11 | 2 (net -136) | 0 | 0 | 1 (net +0) | 1 (net +140) | 5 (net +170) | 2 | 0% (0 of 9) |

### Charged fights, damage counted: h5-opp-8766b98-p3

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 4 | 94 | 374 | -72 | 62 | 116 | -55 | -58.5 |
| Mine | Effective (55-75%) | 2 | 302 | 101 | +101 | 101 | 4 | +97 | +32.0 |
| Mine | 76-89% | 3 | 290 | 148 | +162 | 165 | 0 | +165 | +57.0 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 181 | 88 | +88 | 88 | 0 | +88 | +48.6 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 480 | 137 | +137 | 137 | 170 | -32 | -6.8 |
| Mine | All fights | 12 | 224 | 204 | +59 | 105 | 54 | +51 | +22.8 |
| Opponent | Long shot (under 50%) | 3 | 110 | 313 | -7 | 103 | 110 | -7 | -6.3 |
| Opponent | Effective (55-75%) | 1 | 342 | 230 | +230 | 230 | 0 | +230 | +67.3 |
| Opponent | 76-89% | 4 | 519 | 313 | +303 | 358 | 119 | +239 | +46.1 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 5 | 449 | 286 | +170 | 224 | 0 | +224 | +49.8 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 5 | 448 | 99 | +47 | 71 | 0 | +71 | +15.8 |
| Opponent | No odds | 2 | 392 | 115 | +94 | 94 | 0 | +94 | +24.1 |
| Opponent | All fights | 20 | 401 | 229 | +135 | 182 | 40 | +141 | +35.2 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| h5-opp-8766b98-p3 | move | 65 | 14 (22%) | 9 (14%) | 10 (15%) | 41 (63%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0111, L0128 |
| Elixir of Power | Opponent | L0111, L0211 |
| Fistful of Laurels | Opponent | L0518 |
| Ring of Doom | Mine | L0211, L0228 |
| Ring of Doom | Opponent | L0111, L0211, L0415 |
| Ring of Jet | Opponent | L0111, L0211 |
| Standard of the Fell Warrior | Opponent | L0313 |

# Doctrine scorecard: h3-mine-efe7e34-p2

### Scorecard: h3-mine-efe7e34-p2

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0108 | 6 | 1 | Mine | no | 15 | - | 0 | 1 | 0 | 0 | 0 | 55 |
| L0108 | 6 | 1 | Opponent | no | 2 | 4 | 2 | 2 | 0 | 0 | 0 | 135 |
| L0123 | 3 | 1 | Mine | no | 6 | - | 0 | 2 | 0 | 0 | 0 | 55 |
| L0123 | 3 | 1 | Opponent | no | 2 | 2 | 4 | 3 | 1 | 0 | 0 | 0 |
| L0207 | 3 | 1 | Mine | no | 0 | 5 | 1 | 5 | 0 | 0 | 0 | 170 |
| L0207 | 3 | 1 | Opponent | no | 0 | 3 | 1 | 1 | 0 | 0 | 0 | 0 |
| L0224 | 2 | 1 | Mine | - | - | - | 4 | 4 | 0 | 0 | 0 | 353 |
| L0224 | 2 | 1 | Opponent | - | - | 4 | 1 | 2 | 0 | 0 | 0 | 0 |
| L0308 | 2 | 1 | Mine | - | - | 2 | 1 | 3 | 0 | 0 | 0 | 0 |
| L0308 | 2 | 1 | Opponent | - | - | - | 0 | 1 | 0 | 0 | 0 | 300 |
| L0325 | 1 | 1 | Mine | no | 0 | - | 0 | 0 | 0 | 0 | 0 | 110 |
| L0325 | 1 | 1 | Opponent | no | 6 | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| L0411 | 3 | 1 | Mine | no | 4 | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L0411 | 3 | 1 | Opponent | yes | 5 | - | 0 | 0 | 1 | 0 | 0 | 0 |
| L0427 | 1 | 1 | Mine | no | 0 | 5 | 3 | 1 | 0 | 0 | 0 | 65 |
| L0427 | 1 | 1 | Opponent | no | 0 | 2 | 3 | 5 | 1 | 0 | 0 | 0 |
| L0513 | 3 | 1 | Mine | no | 5 | - | 0 | 2 | 0 | 0 | 0 | 233 |
| L0513 | 3 | 1 | Opponent | no | 6 | 4 | 2 | 0 | 2 | 0 | 0 | 70 |
| L0530 | 2 | 1 | Mine | - | - | 5 | 0 | 1 | 0 | 0 | 0 | 835 |
| L0530 | 2 | 1 | Opponent | - | - | 2 | 3 | 5 | 0 | 0 | 0 | 0 |
| L0618 | 6 | 1 | Mine | no | 2 | - | 0 | 3 | 0 | 0 | 0 | 165 |
| L0618 | 6 | 1 | Opponent | no | 12 | - | 2 | 1 | 1 | 0 | 0 | 0 |
| L0633 | 3 | 1 | Mine | no | 10 | 4 | 2 | 1 | 0 | 0 | 0 | 115 |
| L0633 | 3 | 1 | Opponent | no | 0 | 4 | 2 | 4 | 0 | 0 | 0 | 234 |
| L0722 | 2 | 1 | Mine | - | - | 2 | 4 | 1 | 1 | 0 | 0 | 295 |
| L0722 | 2 | 1 | Opponent | - | - | 2 | 1 | 0 | 0 | 0 | 0 | 72 |
| L0812 | 2 | 1 | Mine | - | - | 5 | 1 | 2 | 0 | 0 | 0 | 435 |
| L0812 | 2 | 1 | Opponent | - | - | 2 | 2 | 0 | 0 | 0 | 0 | 165 |
| L0828 | 6 | 1 | Mine | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 585 |
| L0828 | 6 | 1 | Opponent | yes | 1 | - | 1 | 2 | 0 | 0 | 0 | 0 |
| L0919 | 1 | 1 | Mine | no | 0 | 5 | 2 | 1 | 0 | 0 | 0 | 265 |
| L0919 | 1 | 1 | Opponent | no | 0 | 2 | 3 | 4 | 0 | 0 | 0 | 0 |
| L1011 | 3 | 1 | Mine | no | 4 | 2 | 3 | 0 | 0 | 0 | 0 | 300 |
| L1011 | 3 | 1 | Opponent | yes | 9 | 4 | 0 | 0 | 0 | 0 | 0 | 165 |
| L1027 | 1 | 1 | Mine | no | 0 | 2 | 4 | 0 | 0 | 0 | 0 | 0 |
| L1027 | 1 | 1 | Opponent | no | 1 | 4 | 3 | 4 | 2 | 0 | 0 | 75 |
| L1119 | 3 | 1 | Mine | no | 6 | 5 | 1 | 0 | 0 | 0 | 0 | 0 |
| L1119 | 3 | 1 | Opponent | no | 5 | 1 | 6 | 1 | 0 | 0 | 0 | 255 |
| L1213 | 1 | 1 | Mine | yes | 3 | 3 | 3 | 0 | 1 | 0 | 0 | 0 |
| L1213 | 1 | 1 | Opponent | yes | 6 | 3 | 3 | 1 | 2 | 0 | 0 | 70 |
| L1230 | 6 | 1 | Mine | no | 7 | 3 | 7 | 0 | 0 | 0 | 0 | 0 |
| L1230 | 6 | 1 | Opponent | no | 4 | 4 | 1 | 1 | 0 | 0 | 0 | 0 |
| L1323 | 3 | 1 | Mine | no | 12 | 4 | 3 | 1 | 0 | 0 | 0 | 177 |
| L1323 | 3 | 1 | Opponent | yes | 0 | 4 | 1 | 3 | 0 | 0 | 0 | 0 |
| L1419 | 3 | 1 | Mine | yes | 10 | 3 | 4 | 0 | 0 | 0 | 0 | 0 |
| L1419 | 3 | 1 | Opponent | no | 5 | 2 | 3 | 0 | 1 | 0 | 0 | 0 |
| L1516 | 4 | 1 | Mine | yes | 8 | 1 | 6 | 0 | 0 | 0 | 0 | 0 |
| L1516 | 4 | 1 | Opponent | no | 1 | 2 | 1 | 0 | 1 | 0 | 0 | 421 |
| L1532 | 2 | 1 | Mine | - | - | 4 | 3 | 0 | 1 | 0 | 0 | 547 |
| L1532 | 2 | 1 | Opponent | - | - | 2 | 5 | 4 | 0 | 0 | 0 | 0 |
| L1630 | 4 | 1 | Mine | no | 7 | 2 | 7 | 1 | 0 | 0 | 0 | 100 |
| L1630 | 4 | 1 | Opponent | no | 0 | 1 | 4 | 0 | 0 | 0 | 0 | 0 |
| L1729 | 1 | 1 | Mine | no | 3 | 1 | 5 | 0 | 1 | 0 | 0 | 175 |
| L1729 | 1 | 1 | Opponent | no | 8 | 2 | 4 | 1 | 1 | 0 | 0 | 0 |
| L1827 | 3 | 1 | Mine | yes | 1 | 6 | 2 | 0 | 1 | 0 | 0 | 0 |
| L1827 | 3 | 1 | Opponent | no | 0 | 3 | 3 | 4 | 0 | 0 | 0 | 0 |
| L1928 | 2 | 1 | Mine | - | - | 2 | 4 | 0 | 0 | 0 | 0 | 0 |
| L1928 | 2 | 1 | Opponent | - | - | - | 2 | 0 | 0 | 0 | 0 | 494 |
| L2030 | 2 | 1 | Mine | - | - | - | 0 | 4 | 3 | 0 | 0 | 650 |
| L2030 | 2 | 1 | Opponent | - | - | 2 | 2 | 3 | 1 | 0 | 0 | 0 |
| L2132 | 2 | 1 | Mine | - | - | - | 0 | 4 | 0 | 0 | 0 | 290 |
| L2132 | 2 | 1 | Opponent | - | - | 2 | 4 | 6 | 0 | 0 | 0 | 0 |
| L2324 | 2 | 1 | Mine | - | - | 1 | 4 | 1 | 3 | 0 | 0 | 0 |
| L2324 | 2 | 1 | Opponent | - | - | 2 | 5 | 0 | 0 | 0 | 0 | 0 |
| L2430 | 6 | 1 | Mine | no | 3 | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| L2430 | 6 | 1 | Opponent | no | 5 | - | 0 | 1 | 0 | 0 | 0 | 0 |
| L2628 | 6 | 1 | Mine | no | 3 | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L2628 | 6 | 1 | Opponent | no | 3 | - | 0 | 1 | 0 | 0 | 0 | 168 |
| L2829 | 3 | 1 | Mine | yes | 7 | - | 0 | 1 | 2 | 0 | 0 | 0 |
| L2829 | 3 | 1 | Opponent | no | 8 | 1 | 4 | 1 | 1 | 0 | 0 | 740 |
| L3034 | 4 | 1 | Mine | no | 5 | 2 | 1 | 0 | 0 | 0 | 0 | 0 |
| L3034 | 4 | 1 | Opponent | no | 0 | 2 | 6 | 4 | 0 | 0 | 0 | 406 |
| **Average** | | | Mine | 19% | 4.7 | 3.1 | 2.4 | 1.2 | 0.4 | 0.0 | 0.0 | 166.0 |
| **Average** | | | Opponent | 19% | 3.4 | 2.6 | 2.4 | 1.8 | 0.4 | 0.0 | 0.0 | 104.7 |

### KPIs: h3-mine-efe7e34-p2

Rules off - Opponent only: HOLDER ASSIGNMENT.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 27% (49 of 182) | 8% (14 of 177) | 18% (63 of 359) |
| Winner chose to follow up after the loser gave ground |  | 88% (52 of 59); on the table 92% | 94% (34 of 36); on the table 97% | 91% (86 of 95); on the table 94% |
| Winner chose to pursue after the loser fell back in good order |  | 89% (8 of 9); on the table 89% | 77% (10 of 13); on the table 85% | 82% (18 of 22); on the table 86% |
| Winner chose to pursue after the loser fled |  | 72% (23 of 32); on the table 81% | 82% (23 of 28); on the table 89% | 77% (46 of 60); on the table 85% |
| Winner chose to follow up or pursue (all three) |  | 83% (83 of 100); on the table 88% | 87% (67 of 77); on the table 92% | 85% (150 of 177); on the table 90% |
| Magic missiles tried each own turn | 50%+ | 33% (109 of 334) | 25% (40 of 157) | 30% (149 of 491) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 44% (109 of 249) | 34% (40 of 119) | 40% (149 of 368) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 62% (15 of 24) | 57% (16 of 28) | 60% (31 of 52) |
| Points that never fought | lower | 40% (28115 of 70360) | 47% (33719 of 71986) | 43% (61834 of 142346) |
|   infantry points that never fought | lower | 66% (10384 of 15655) | 61% (6506 of 10608) | 64% (16890 of 26263) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 54% (149 of 274) | 61% (158 of 260) | 57% (307 of 534) |
| Bound items with a magic missile used (at least once a game) |  | 88% (22 of 25); 1.8 uses a game | 100% (12 of 12); 1.1 uses a game | 92% (34 of 37); 1.5 uses a game |
| Bound items with another spell used |  | 38% (5 of 13); 0.4 uses a game | 60% (3 of 5); 0.2 uses a game | 44% (8 of 18); 0.3 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 62% (13 of 21); 0.4 uses a game | 53% (9 of 17); 0.3 uses a game | 58% (22 of 38); 0.3 uses a game |
|   their share of the points of units over 100 pts | lower | 46% (27596 of 59989) | 56% (35192 of 62998) | 51% (62788 of 122987) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.5 (24%) | 0.4 (14%) | 1.9 (20%) |
| MARCHED: its unit marched | 1.9 (31%) | 0.6 (17%) | 2.5 (26%) |
| CHARGED: its unit charged | 0.1 (1%) | 0.1 (3%) | 0.2 (2%) |
| IN COMBAT: engaged in combat | 1.4 (22%) | 0.4 (12%) | 1.8 (18%) |
| REAR RANK: in a rear rank | 0.2 (4%) | 0.9 (26%) | 1.1 (11%) |
| FLEEING: fleeing | 0.1 (2%) | 0.0 (1%) | 0.1 (1%) |
| GONE: slain | 0.6 (9%) | 0.6 (19%) | 1.2 (12%) |
| OFF THE TABLE: off the table or not arrived | 0.3 (5%) | 0.0 (1%) | 0.4 (4%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.1 (2%) | 0.1 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (1%) | 0.1 (2%) | 0.1 (1%) |
| NOT OFFERED: not in the cast list | 0.1 (1%) | 0.1 (4%) | 0.2 (2%) |
| HELD BACK: the computer weighed it and chose not to cast it | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 3.4 | 2.0 | 1.5 | 4.1 | 0.4 | 1.6 |
| not cast | 3.9 | 2.7 | 3.6 | 9.5 | 2.3 | 22.4 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) | 0.0 (0%) | 1.8 (8%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.6 (57%) | 0.2 (6%) | 1.9 (20%) | 0.8 (33%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.5 (26%) | 0.5 (21%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (2%) | 0.0 (1%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.1 (4%) | 0.2 (7%) | 0.5 (13%) | 1.8 (18%) | 0.4 (16%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.9 (23%) | 0.1 (5%) | 0.8 (23%) | 1.1 (11%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.1 (4%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.2 (1%) |
| GONE: slain | 0.7 (18%) | 0.3 (11%) | 0.4 (11%) | 1.2 (12%) | 0.4 (16%) | 2.1 (9%) |
| OFF THE TABLE: off the table or not arrived | 0.4 (9%) | 0.0 (1%) | 0.2 (5%) | 0.4 (4%) | 0.0 (0%) | 0.6 (3%) |
| STUPIDITY: Stupidity | 0.1 (1%) | 0.0 (1%) | 0.0 (1%) | 0.1 (1%) | 0.0 (0%) | 0.2 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (1%) | 0.4 (14%) | 0.1 (2%) | 0.1 (1%) | 0.3 (13%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (2%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.6 (40%) | 0.1 (3%) | 1.4 (39%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 17.5 (78%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.3 a game | 0.4 a game | 0.9 a game |
| stood (cast and not dispelled) | 71% (25 of 35) | 87% (13 of 15) | 76% (38 of 50) |
| the unit moved after it | 76% (19 of 25) | 92% (12 of 13) | 82% (31 of 38) |
| it charged on its next turn | 4% (1 of 25) | 0% (0 of 13) | 3% (1 of 38) |
| the enemy charged it first | 12% (3 of 25) | 8% (1 of 13) | 11% (4 of 38) |
| it fought by the end of its next turn | 4% (1 of 25) | 0% (0 of 13) | 3% (1 of 38) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 25) | 0% (0 of 13) | 0% (0 of 38) |
| none of these (no charge, no fight, no charge escaped) | 80% (20 of 25) | 92% (12 of 13) | 84% (32 of 38) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 59% (507 of 853) | 54% (275 of 506) | 58% (782 of 1359) |
|   cavalry | 63% (49 of 78) | 55% (53 of 96) | 59% (102 of 174) |
|   character | 49% (49 of 100) | 18% (19 of 104) | 33% (68 of 204) |
|   chariot | 60% (54 of 90) | 74% (20 of 27) | 63% (74 of 117) |
|   infantry | 58% (140 of 241) | 69% (97 of 141) | 62% (237 of 382) |
|   monster | 69% (27 of 39) | 90% (9 of 10) | 73% (36 of 49) |
|   war machine | 62% (188 of 305) | 60% (77 of 128) | 61% (265 of 433) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.2 (23%) | 1.1 (17%) | 3.4 (21%) |
| CHARGED: it charged | 0.7 (8%) | 1.2 (18%) | 1.9 (12%) |
| FLEEING: it fled or was fleeing | 0.1 (1%) | 0.1 (1%) | 0.1 (1%) |
| IN COMBAT: it fought this turn or the last | 0.5 (5%) | 0.2 (3%) | 0.8 (5%) |
| MOVED: a war machine that moved | 1.3 (14%) | 0.9 (13%) | 2.2 (14%) |
| NO TARGET IN RANGE | 1.8 (19%) | 1.3 (20%) | 3.1 (19%) |
| ONLY IN COMBAT: the only targets were in combat | 0.6 (6%) | 0.2 (3%) | 0.8 (5%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.5 (16%) | 0.9 (14%) | 2.4 (15%) |
| SHELTERED: the target was sheltered | 0.4 (4%) | 0.2 (4%) | 0.6 (4%) |
| OTHER BAR | 0.5 (5%) | 0.4 (6%) | 0.8 (5%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 4.3 | 1.4 | 74% | 7.2 pts | 31 pts |
| character | 2.1 | 1.2 | 67% | 10.4 pts | 22 pts |
| chariot | 2.1 | 1.9 | 60% | 17.6 pts | 37 pts |
| infantry | 9.5 | 3.7 | 71% | 7.7 pts | 73 pts |
| monster | 1.1 | 0.3 | 75% | 8.7 pts | 10 pts |
| war machine | 7.4 | 6.7 | 61% | 28.5 pts | 211 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.9 | 4.4 | 4.2 |
| Charges that made contact a game | 3.1 | 3.2 | 3.2 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.08 declared, 1.00 contact (25 units) | 0.64 declared, 0.43 contact (14 units) | 0.92 declared, 0.79 contact (39 units) |
|   per unit a game, units carrying another wizard (or one alone) | 1.00 declared, 0.88 contact (8 units) | 1.00 declared, 0.69 contact (13 units) | 1.00 declared, 0.76 contact (21 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.44 declared, 0.33 contact (239 units) | 0.54 declared, 0.40 contact (256 units) | 0.49 declared, 0.37 contact (495 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 56% (36 of 64) | 58% (11 of 19) | 31% (5 of 16) | 53% (52 of 99) |
| Character in a unit | 95% (39 of 41) | 64% (18 of 28) | 0% (0 of 3) | 79% (57 of 72) |
| Character on its own | 82% (23 of 28) | 59% (24 of 41) | 26% (17 of 66) | 47% (64 of 135) |
| Chariot | 83% (10 of 12) | 62% (8 of 13) | - | 72% (18 of 25) |
| Infantry | 40% (23 of 57) | 44% (15 of 34) | 40% (2 of 5) | 42% (40 of 96) |
| Monster | 59% (13 of 22) | 82% (9 of 11) | - | 67% (22 of 33) |
| Monstrous | 60% (3 of 5) | 57% (8 of 14) | - | 58% (11 of 19) |
| War Machines | 77% (41 of 53) | 100% (2 of 2) | - | 78% (43 of 55) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 62% (5 of 8); on the table 62% | 48% (49 of 102) | 56% | 59% (13 of 22) | 100% (6 of 6); 5.8 uses a game | 100% (2 of 2); 1.8 uses a game | 83% (5 of 6); 1.2 uses a game |
| Chaos Dwarfs | 4 | 100% (13 of 13); on the table 100% | 39% (14 of 36) | 48% | 59% (19 of 32) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |
| Dwarfen Mountain Holds | 4 | 86% (6 of 7); on the table 86% | - | 61% | 62% (21 of 34) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 7 | 71% (5 of 7); on the table 86% | 47% (14 of 30) | 72% | 64% (46 of 72) | 0.0 uses a game | 100% (2 of 2); 0.6 uses a game | 50% (3 of 6); 0.4 uses a game |
| Grand Cathay | 8 | 80% (16 of 20); on the table 90% | 26% (43 of 167) | 41% | 55% (36 of 66) | 89% (17 of 19); 6.4 uses a game | 0% (0 of 2); 0.0 uses a game | 38% (3 of 8); 0.5 uses a game |
| High Elf Realms | 6 | 83% (19 of 23); on the table 83% | 12% (3 of 24) | 35% | 40% (19 of 47) | 86% (6 of 7); 3.0 uses a game | 33% (4 of 12); 1.3 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 2 | 75% (3 of 4); on the table 100% | - | 31% | 75% (9 of 12) | 0.0 uses a game | 0.0 uses a game | 100% (2 of 2); 1.0 uses a game |
| Lizardmen | 1 | 75% (3 of 4); on the table 75% | - | 22% | 43% (3 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 2 | 100% (5 of 5); on the table 100% | 0% (0 of 12) | 64% | 64% (9 of 14) | 100% (2 of 2); 3.5 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 4 | 100% (5 of 5); on the table 100% | 14% (6 of 42) | 22% | 69% (22 of 32) | 0.0 uses a game | 0.0 uses a game | 50% (2 of 4); 0.5 uses a game |
| Skaven | 2 | 50% (1 of 2); on the table 100% | 17% (2 of 12) | 34% | 62% (10 of 16) | 100% (1 of 1); 0.5 uses a game | 0.0 uses a game | 50% (1 of 2); 0.5 uses a game |
| Tomb Kings of Khemri | 4 | 88% (7 of 8); on the table 88% | - | 43% | 50% (10 of 20) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 8 | 97% (32 of 33); on the table 97% | 29% (12 of 42) | 38% | 62% (31 of 50) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 14 | 76% (25 of 33); on the table 88% | 25% (6 of 24) | 34% | 54% (50 of 92) | 0.0 uses a game | 0.0 uses a game | 100% (6 of 6); 0.4 uses a game |
| Wood Elf Realms | 2 | 100% (5 of 5); on the table 100% | - | 50% | 50% (9 of 18) | 100% (2 of 2); 2.5 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (h3-mine-efe7e34-p2, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 45% (32) | 47% (34) | 46% (66) |
| ...free all their last turn and able to turn (per game) | 0.58 | 0.67 | 1.25 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.19 | 0.14 | 0.33 |
| ...with the charger already in that arc before they moved (per game) | 0.50 | 0.47 | 0.97 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.03 | 0.03 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.31 | 0.39 | 0.69 |

### Quality by phase: h3-mine-efe7e34-p2

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.3 | 2.2 |
| Strategy | Charge objectives carried out (made contact) | 67% (86 of 128) | 53% (70 of 133) |
| Strategy | Shoot objectives carried out (shot that target) | 39% (145 of 369) | 42% (73 of 174) |
| Strategy | Support requests answered (helper made contact too) | 80% (8 of 10) | 67% (6 of 9) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (1 of 1) | 50% (1 of 2) |
| Strategy | Hexes on a unit its side charged or shot that turn | 53% (8 of 15) | 67% (2 of 3) |
| Strategy | Joined characters whose unit fought | 49% (24 of 49) | 31% (15 of 48) |
| Strategy | Lone characters that fought | 72% (63 of 87) | 75% (65 of 87) |
| Movement | Charges halted short of contact | 0.1 | 0.1 |
| Movement | Idle units | 1.2 | 1.8 |
| Movement | Points that never moved of their own | 166.0 | 104.7 |
| Movement | Fights charged into per game | 2.6 | 2.8 |
| Movement | Charges with odds: long shots (under 50%) | 15 of 86, net +106 | 19 of 85, net +89 |
| Movement | Charges with odds: sweet spot (55-75%) | 11 of 86, net +34 | 8 of 85, net +104 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 17 of 86, net +58 | 11 of 85, net +73 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 25 of 86, net +133 | 20 of 85, net +194 |
| Shooting | Shots by shooting units (incl. breath weapons) | 9.8 | 6.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 49% (171 of 351) | 43% (104 of 240) |
| Shooting | Points destroyed by shooting units | 121.6 | 26.1 |
| Shooting | War machine shots | 5.2 | 2.2 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 51% (96 of 188) | 61% (48 of 79) |
| Shooting | Points destroyed by war machines | 36.3 | 25.2 |
| Magic | Magic missiles cast | 1.9 | 0.7 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 34% (23 of 68) | 32% (8 of 25) |
| Magic | Wounds caused by magic missiles | 4.0 | 0.8 |
| Magic | Wounds caused by other spells | 2.1 | 0.6 |
| Magic | Points destroyed by magic (all spells) | 81.1 | 17.3 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.1 / 0.5 / 0.8 / 0.1 | 1.3 / 0.6 / 0.1 / 0.1 |
| Combat | Points destroyed in combat | 292.4 | 334.2 |
| Combat | Points run down | 88.4 | 115.5 |
| Combat | Net points per charged fight, damage counted | +93 | +108 |
| Combat | Net per 100 charger points, damage counted | +26.8 | +38.3 |
| Combat | First round won (charged fights) | 84% | 72% |
| Combat | Net points per charged fight | +85 | +112 |
| Combat | Net points per supported fight / lone fight | +134 / +74 | +128 / +109 |
| Combat | Charged fights on a top-3 enemy unit | 32 of 92 | 42 of 102 |
| Game | Points lost | 616.4 | 662.4 |
| Game | VP from objectives | 670.6 | 569.2 |
| Game | Lone holders (player turns) | 4.7 | 3.4 |

- Mine won / drew / lost: 16 / 9 / 11 of 36 ended games (of 36); mean margin (Mine - Opponent) +140 VP
- The side that went first won 15 of 27 games with a winner
- Points traded per game (both sides' losses): 1279
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: h3-mine-efe7e34-p2

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.8 | +0.0 | 0.0 | 0.0 | 0.8 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.2 | +13.8 | 0.0 | 8.6 | 0.2 | +19.9 | 0.0 | 16.0 |
| ARRIVAL HUNT | - | - | - | - | 0.1 | +1.5 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.4 | +0.0 | 0.0 | 9.9 | 0.2 | +0.0 | 0.0 | 4.6 |
| BACKUP TARGETS | 0.2 | +1.2 | 0.0 | 7.6 | 0.4 | +4.1 | 0.0 | 0.0 |
| BEST PRIZE | - | - | - | - | 0.1 | -0.6 | 6.6 | 0.0 |
| BLOWS WHERE AIMED | 0.1 | -10.4 | 20.8 | 0.0 | 0.1 | -29.2 | 30.9 | 0.0 |
| BOMBING RUN | 0.1 | +1.4 | 0.9 | 4.2 | 0.1 | +1.6 | 0.0 | 8.3 |
| BOUND ASSAILMENT | 0.0 | +0.0 | 0.0 | 4.2 | - | - | - | - |
| CANNON PLAN MISSED | 0.8 | +0.0 | 99.7 | 3.1 | 0.3 | +0.0 | 17.1 | 3.5 |
| CANNON PLANNED TARGET | 4.6 | +122.3 | 286.0 | 35.3 | 1.8 | +60.1 | 134.1 | 31.5 |
| CANNON SIGHT KEPT | 1.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT COUNTER | 0.1 | -0.2 | 9.2 | 0.0 | 0.0 | -2.9 | 0.0 | 0.0 |
| CARRIES OUT SET-UP | 0.1 | -40.3 | 11.3 | 0.0 | 0.0 | -0.5 | 2.3 | 0.0 |
| CAST JOB | 0.6 | +14.8 | 24.1 | 12.9 | 0.2 | +1.9 | 4.6 | 9.8 |
| CASTER AWAY FROM SCREEN | 0.3 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.3 | +21.3 | 21.8 | 0.0 | 0.0 | +0.5 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 0.9 | +0.0 | 0.0 | 33.2 | 0.4 | +0.0 | 0.0 | 20.2 |
| CASTS FROM BEHIND | 0.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.0 | +0.1 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | 0.3 | +17.1 | 0.0 | 16.1 | 0.8 | +26.5 | 0.0 | 19.1 |
| CHAFF PASSED | 0.4 | -1.0 | 4.7 | 4.9 | 0.1 | -0.3 | 0.0 | 0.0 |
| CHARACTER GUNS | 0.4 | +0.0 | 0.0 | 6.2 | 0.2 | +0.0 | 0.0 | 0.0 |
| CHARGE LOSSES | 5.4 | -280.6 | 0.0 | 145.6 | 5.2 | -352.6 | 0.0 | 223.2 |
| CHARGE NOT DECLARED | 0.7 | +0.0 | 59.8 | 25.4 | 0.8 | +0.0 | 106.2 | 10.1 |
| CHARGE NOW FIRST | 1.8 | +0.0 | 262.0 | 48.6 | 1.5 | +0.0 | 197.2 | 61.9 |
| CHARGER SLAIN LOST | 0.2 | -6.8 | 36.2 | 18.2 | 0.3 | -13.1 | 41.6 | 19.6 |
| CHEAP HELPER | 0.0 | +0.0 | 0.0 | 3.2 | 0.0 | +0.0 | 1.8 | 0.0 |
| CHEAPEST HOLDER | - | - | - | - | 0.2 | -2.5 | 11.8 | 0.0 |
| COMBAT PIVOT | 0.5 | +0.0 | 40.3 | 35.5 | 0.3 | +0.0 | 5.4 | 26.4 |
| CONVEYANCE SEARCH | 0.7 | +67.0 | 19.4 | 22.8 | 0.2 | +11.4 | 0.0 | 0.0 |
| COVER ONCE | 6.6 | -391.0 | 0.0 | 141.7 | 4.8 | -434.8 | 0.0 | 129.9 |
| DEFENSIVE ARMY | 0.0 | +0.0 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| DEFENSIVE FLOOR | 0.0 | +1.7 | 0.0 | 0.0 | - | - | - | - |
| DEPLOY BY FIGURES | 7.9 | -5.2 | 0.0 | 5.6 | 7.0 | +14.5 | 0.0 | 9.6 |
| EDGE GIVE GROUND | 0.2 | +4.2 | 35.0 | 0.0 | 0.2 | +8.7 | 23.1 | 4.7 |
| ELIXIR WORTH | 0.0 | +0.3 | 0.0 | 9.7 | 0.0 | +0.8 | 0.0 | 0.0 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FALL BACK GOOD ORDER | 2.3 | +6.1 | 265.4 | 74.0 | 2.2 | +4.8 | 244.2 | 50.4 |
| FALLBACK BY WORTH | 0.5 | +2.0 | 0.0 | 4.9 | 0.4 | +0.0 | 0.0 | 1.5 |
| FALLS SHORT | 5.5 | +99.3 | 0.0 | 70.4 | 17.2 | +248.7 | 0.0 | 223.1 |
| FEATURE BUFFS | 1.0 | +22.1 | 0.0 | 13.7 | 0.6 | +7.4 | 0.0 | 5.6 |
| FIGHT LIFT | 0.0 | +0.1 | 0.0 | 0.0 | - | - | - | - |
| FIGHT TO THE END | 1.2 | +67.9 | 161.7 | 55.1 | 1.1 | +51.9 | 118.1 | 44.7 |
| FIRE AND FLEE | 0.0 | +0.3 | 0.0 | 0.0 | - | - | - | - |
| FIRE IN ORDER | 0.2 | +0.0 | 34.4 | 4.9 | 0.0 | +0.0 | 0.0 | 0.0 |
| FIVE ACTION | 46.1 | +2888.3 | 1165.9 | 618.5 | 41.9 | +2685.8 | 578.8 | 699.8 |
| FLANK NOT WEIGHED | 5.2 | +0.0 | 0.0 | 134.2 | 5.6 | +0.0 | 0.0 | 192.8 |
| FOCUS FIRE | 0.1 | +0.6 | 11.8 | 0.0 | 0.0 | +0.7 | 1.5 | 0.0 |
| FOLLOW UP WEIGHED | 0.9 | +188.5 | 0.0 | 11.3 | 0.7 | +180.4 | 0.0 | 30.2 |
| FOUR ROUNDS | 3.4 | +469.1 | 461.0 | 89.1 | 3.4 | +323.2 | 354.9 | 97.7 |
| FRIEND CHARGES FIRST | 0.1 | -8.9 | 0.0 | 0.0 | 0.2 | -13.2 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 0.3 | -8.9 | 1.2 | 0.0 | 0.1 | -6.0 | 0.0 | 0.0 |
| FRIENDS SHOTS CHECKED | 0.1 | +13.0 | 0.0 | 12.2 | 0.0 | +0.7 | 0.0 | 0.0 |
| GIVES UP | 0.2 | -7.8 | 47.7 | 0.0 | 0.1 | -0.5 | 4.7 | 7.8 |
| GIVES UP ITS SCREEN | 0.0 | -0.0 | 15.1 | 0.0 | - | - | - | - |
| GROUND FLIERS | 0.0 | +2.6 | 0.0 | 0.0 | 0.1 | +0.8 | 0.0 | 0.0 |
| GUN FIGURES | 1.5 | +18.7 | 96.5 | 1.8 | 0.5 | +2.0 | 4.2 | 14.7 |
| GUN MASK | 0.4 | +12.1 | 0.0 | 10.6 | 0.8 | +8.2 | 0.0 | 4.2 |
| HARD STAY DROPPED | 1.4 | +0.0 | 0.0 | 13.9 | 0.8 | +0.0 | 0.0 | 7.4 |
| HE SHOOTS OR CHARGES | 1.6 | +0.0 | 0.0 | 30.8 | 2.6 | +0.0 | 0.0 | 58.6 |
| HELPER ALREADY ASKED | - | - | - | - | 0.0 | +0.0 | 1.9 | 0.8 |
| HELPER UNSEEN | 0.0 | +0.0 | 6.5 | 0.0 | 0.1 | +0.0 | 1.8 | 0.0 |
| HIS CHARGE DENIED | 0.4 | +26.5 | 87.3 | 18.3 | 0.2 | +19.4 | 49.4 | 1.7 |
| HIS CHARGE LIST | 2.6 | +0.0 | 0.0 | 24.3 | 2.7 | +0.0 | 0.0 | 59.4 |
| HIS LEGAL MOVES | 4.0 | +0.0 | 0.0 | 59.2 | 4.0 | +0.0 | 0.0 | 101.8 |
| HIS MOVE AND SHOT | 1.7 | -28.5 | 0.0 | 57.6 | 2.5 | -57.4 | 0.0 | 90.9 |
| HIS RANDOM MOVE | 1.5 | +0.0 | 0.0 | 33.4 | 2.1 | +0.0 | 0.0 | 27.5 |
| HIS SHOT LIST | 16.5 | +526.9 | 0.0 | 241.6 | 20.5 | +1019.1 | 0.0 | 362.4 |
| HIS TURN DENIED | 1.0 | +43.6 | 109.4 | 34.3 | 1.7 | +87.2 | 150.4 | 62.8 |
| HOLD ODDS | 6.2 | +0.0 | 0.0 | 65.6 | - | - | - | - |
| HOLDER ASSIGNMENT | 11.8 | +1089.4 | 0.0 | 107.5 | - | - | - | - |
| HOLDER AT DEPLOYMENT | - | - | - | - | 1.1 | +189.6 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.5 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 3.0 | -109.5 | 354.0 | 77.8 | 3.0 | -113.6 | 303.9 | 84.8 |
| HORN WORTH | - | - | - | - | 0.0 | +0.5 | 0.0 | 0.0 |
| HUNT IN PAIRS | 0.1 | +3.8 | 0.0 | 0.0 | 0.6 | +16.4 | 0.0 | 28.6 |
| HUNT KEPT | - | - | - | - | 0.1 | +0.0 | 0.0 | 2.5 |
| HUNT RESULT | - | - | - | - | 0.1 | +3.9 | 0.0 | 0.0 |
| HUNT THE GUNS | - | - | - | - | 0.1 | +12.9 | 3.1 | 0.0 |
| IDLE COST | 2.8 | -49.1 | 0.0 | 48.1 | 10.2 | -174.0 | 0.0 | 174.9 |
| JOINT KNOWS CHALLENGE | - | - | - | - | 0.0 | -1.2 | 0.0 | 0.0 |
| KEEP FALLS | 0.2 | +2.1 | 0.0 | 0.0 | - | - | - | - |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KILLS COUNT | 0.1 | +1.8 | 4.8 | 10.6 | 0.1 | +2.6 | 14.1 | 0.0 |
| LANE BY FIGURES | 0.6 | +26.8 | 0.0 | 0.0 | 0.9 | +50.9 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 4.8 | +0.0 | 272.6 | 193.4 | 5.9 | +0.0 | 251.9 | 456.1 |
| LINE HITS NO ONE | 0.1 | -0.4 | 0.0 | 0.0 | - | - | - | - |
| LONE CHARACTER SAFE SPOT | 0.1 | +0.9 | 0.0 | 0.0 | - | - | - | - |
| LONE WIZARD KEPT IN | 0.5 | +30.6 | 0.0 | 0.0 | 0.2 | +23.3 | 0.0 | 0.0 |
| LONG SHOT | 0.2 | +0.3 | 1.2 | 2.8 | 0.2 | +1.8 | 4.7 | 3.8 |
| LOST CHARGE | 0.1 | -0.2 | 4.8 | 0.0 | - | - | - | - |
| LURE BY WHAT IT DRAWS | 0.1 | -4.2 | 0.0 | 6.7 | 0.1 | -3.8 | 0.0 | 6.1 |
| MAKE SURE TOGETHER | 0.1 | +1.6 | 0.0 | 4.2 | 0.2 | +5.0 | 0.0 | 0.0 |
| MANOEUVRE | 1.2 | +22.4 | 0.0 | 20.2 | 1.2 | +38.3 | 0.0 | 34.0 |
| MARCH AT ESCAPER | 0.2 | +6.9 | 0.0 | 13.0 | 0.1 | +1.8 | 0.0 | 4.5 |
| MARCH BY THE SUM | 0.3 | +17.0 | 0.0 | 21.7 | 0.3 | +14.2 | 0.0 | 0.0 |
| MARCH CHECK | 1.0 | +56.1 | 0.0 | 25.8 | 0.9 | +57.1 | 0.0 | 15.8 |
| MARCH ODDS | 0.0 | +1.9 | 0.0 | 0.0 | 0.0 | +0.5 | 0.0 | 0.0 |
| MARCH OVER CASTS | 1.1 | +135.0 | 0.0 | 38.5 | 0.6 | +75.4 | 0.0 | 4.5 |
| MAX FOR POSITIONING | 6.9 | +105.0 | 0.0 | 127.1 | 5.9 | +80.6 | 0.0 | 129.2 |
| MISSILES IN THE MOVE | 4.1 | +171.6 | 0.0 | 72.5 | 2.3 | +38.9 | 0.0 | 86.7 |
| MISSILES NEXT TURN | 5.6 | +117.8 | 0.0 | 121.1 | 3.1 | +25.8 | 0.0 | 88.1 |
| MODEL FACING | 0.2 | +77.4 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL IN RANGE | 0.1 | +2.8 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL NOT WORTH | 0.0 | -0.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.4 | -14.1 | 0.0 | 31.0 | - | - | - | - |
| MOVE SPELL SPOT | 0.4 | +0.0 | 0.0 | 8.8 | 0.2 | +0.0 | 0.0 | 11.1 |
| MOVE TO CHARGE COMPUTED | 4.0 | +449.8 | 0.0 | 9.7 | 5.0 | +754.3 | 0.0 | 103.6 |
| MOVES UNITS SPELL | 0.1 | +3.6 | 0.0 | 0.0 | 0.1 | +0.4 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 4.2 | +192.5 | 0.0 | 56.9 | 4.1 | +208.1 | 0.0 | 60.6 |
| NEEDED THERE | 0.1 | +9.5 | 4.8 | 10.6 | 0.2 | +31.8 | 14.1 | 0.0 |
| NEXT CHARGE BY LIST | 5.5 | -262.8 | 19.2 | 63.1 | 6.2 | -233.8 | 0.0 | 137.8 |
| NEXT OBJECTIVE NEARER | 6.2 | -210.9 | 32.3 | 127.9 | 7.8 | -400.7 | 17.0 | 108.9 |
| NO DOUBLE ROUNDS | 2.7 | -119.1 | 363.4 | 71.6 | 2.7 | -106.1 | 302.8 | 84.9 |
| NOT TURNED | 0.3 | +0.2 | 0.0 | 7.9 | 0.4 | -1.5 | 0.0 | 7.4 |
| NOT WORTH A CAST | 0.6 | -0.4 | 0.0 | 0.0 | 0.4 | -0.3 | 0.0 | 12.4 |
| OFF BEST | 0.5 | -16.7 | 0.0 | 12.4 | 0.8 | -28.2 | 0.0 | 2.7 |
| ONE CHARGE A CHARGER | 2.9 | +0.0 | 0.0 | 58.8 | 2.7 | +0.0 | 0.0 | 39.2 |
| ONE FIGHT FORMULA | 6.3 | -132.6 | 0.0 | 90.9 | 6.0 | -154.4 | 0.0 | 161.1 |
| ONE OBJECTIVE FORMULA | 4.6 | -8.5 | 0.0 | 77.1 | 3.4 | -102.0 | 0.0 | 56.7 |
| ONE TARGET A SHOOTER | 12.0 | +290.4 | 0.0 | 108.4 | 18.8 | +562.4 | 0.0 | 270.5 |
| OPENS A LANE | 0.2 | +1.1 | 28.4 | 10.5 | 0.0 | +0.6 | 0.0 | 0.0 |
| OPENS UP | 0.3 | +19.9 | 22.2 | 0.0 | 0.1 | +9.8 | 5.5 | 0.0 |
| OVERRUNS AWAY | 0.5 | +27.6 | 55.2 | 50.3 | 0.6 | +38.8 | 78.4 | 20.6 |
| PATHS CROSS | 3.6 | +176.0 | 0.0 | 48.4 | 4.7 | +200.3 | 0.0 | 39.2 |
| PERIAPT WORTH | 0.0 | +3.4 | 0.0 | 15.0 | - | - | - | - |
| PIVOT GUARDS FLANK | 0.0 | -1.6 | 0.0 | 0.0 | 0.2 | -3.2 | 0.0 | 0.0 |
| PLAN RESULT | 41.0 | +874.3 | 627.0 | 834.5 | 38.1 | +489.0 | 269.7 | 956.0 |
| PURSUES BIG PREY | 0.1 | -24.0 | 0.0 | 0.0 | - | - | - | - |
| RANDOM MOVE BY FIGURES | 0.7 | +10.8 | 0.0 | 19.7 | 0.8 | +2.0 | 0.0 | 18.9 |
| REDIRECT BY WHAT IT STOPS | 0.2 | -11.6 | 0.0 | 5.1 | 0.4 | -3.0 | 0.0 | 3.5 |
| REDIRECT COUNTER | 2.5 | +223.0 | 0.0 | 47.2 | 3.9 | +306.4 | 0.0 | 60.2 |
| REDIRECT WEIGHED | 0.2 | +8.7 | 10.2 | 6.0 | 0.2 | +0.4 | 4.8 | 1.5 |
| REFORMS TO MEET IT | 1.0 | -43.7 | 0.0 | 2.5 | 1.4 | -72.8 | 0.0 | 17.2 |
| REFUSING RETIRES | 0.2 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 9.5 |
| RESERVE FALL BACK | 0.3 | +20.8 | 0.0 | 8.0 | 0.5 | +13.8 | 0.0 | 15.2 |
| RESTRAINS TO SHOOT | 0.1 | +4.0 | 0.0 | 5.9 | - | - | - | - |
| RISK BY ARC | 2.3 | +114.4 | 279.4 | 85.1 | 2.5 | +9.8 | 260.4 | 96.0 |
| RISK BY HIS FIGURE | 13.2 | -217.2 | 0.0 | 254.8 | 13.5 | -233.6 | 0.0 | 347.5 |
| RUN DOWN | 1.9 | -21.5 | 203.9 | 56.6 | 2.6 | -38.4 | 228.8 | 78.2 |
| SAFER THAN THE JOB | - | - | - | - | 0.0 | +2.4 | 0.0 | 0.0 |
| SAME CHARGE LATER | 0.2 | -7.6 | 9.5 | 1.7 | 0.1 | -1.0 | 0.0 | 0.0 |
| SCOUT SPOT | 0.3 | +0.5 | 0.0 | 1.5 | 0.3 | +0.6 | 0.0 | 0.0 |
| SCOUT WAITS | 0.3 | +0.0 | 0.0 | 1.5 | 0.3 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.1 | +0.6 | 0.0 | 0.0 | 0.3 | -24.3 | 0.0 | 0.9 |
| SEARCH SPOT | 6.2 | +398.6 | 0.0 | 75.2 | 5.4 | +226.0 | 0.0 | 77.8 |
| SELF MOVE SPELL | 0.5 | +52.9 | 0.0 | 0.0 | 0.1 | +1.4 | 0.0 | 9.1 |
| SET UP TOGETHER | 0.2 | +2.4 | 0.0 | 4.2 | 0.3 | +15.1 | 0.0 | 11.1 |
| SET-UP ANY TARGET | 0.1 | +24.9 | 0.0 | 0.0 | 0.1 | +2.2 | 0.0 | 0.0 |
| SET-UP MISSED | 0.1 | +9.3 | 0.0 | 0.0 | 0.1 | +3.5 | 6.4 | 0.0 |
| SHOOTER COUNTED ONCE | 0.0 | -0.0 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | 0.4 | +0.9 | 0.0 | 0.0 | 0.1 | +0.2 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.2 | +57.9 | 64.5 | 13.6 | 0.7 | +21.4 | 10.1 | 35.1 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| SHOT OR CHARGE | 0.4 | -8.4 | 41.0 | 4.6 | 0.2 | -3.1 | 4.7 | 0.0 |
| SHOT RISK POINTS | 7.6 | -23.8 | 0.0 | 165.4 | 12.4 | -47.7 | 0.0 | 292.5 |
| SHOTS IN THE MOVE | 15.2 | +653.5 | 0.0 | 188.9 | 9.3 | +254.5 | 0.0 | 155.9 |
| SPELL SETS UP CHARGE | 0.2 | +75.9 | 0.0 | 0.0 | 0.1 | +2.2 | 0.0 | 0.0 |
| SPELL WORTH | 1.1 | +23.8 | 33.6 | 49.7 | 1.3 | +22.5 | 60.1 | 48.0 |
| SPELLS IN THE FIGHT | 0.6 | +6.5 | 58.2 | 34.6 | 0.5 | +3.0 | 67.3 | 38.7 |
| STAND AND SHOOT | 0.3 | -4.1 | 40.0 | 13.8 | 0.7 | -8.6 | 42.1 | 12.8 |
| STANDS FOR A REASON | 0.1 | +0.0 | 6.2 | 0.0 | 0.4 | +0.0 | 0.0 | 15.5 |
| STANDS STILL | 17.5 | +0.0 | 603.6 | 182.3 | 10.4 | +0.0 | 195.2 | 169.6 |
| STANDS TO CAST | - | - | - | - | 0.0 | +0.9 | 0.0 | 0.0 |
| STAY WORTH | 17.6 | +104.4 | 313.0 | 145.8 | 9.4 | +25.1 | 146.5 | 114.5 |
| STOPS | - | - | - | - | 0.1 | +1.0 | 3.1 | 0.0 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 5.8 | 0.2 | +0.0 | 0.0 | 4.7 |
| SUPPORT NARROWED | 1.2 | +0.0 | 123.2 | 40.4 | 1.0 | +0.0 | 99.1 | 37.6 |
| SURE REACH TOGETHER | 0.2 | +2.5 | 0.0 | 0.0 | 0.6 | +15.8 | 0.0 | 11.1 |
| THE DEARER SUM KEEPS ITS PLAN | 4.1 | +0.0 | 0.0 | 44.5 | 4.5 | +0.0 | 0.0 | 43.9 |
| THE PROMISE ADDS | 0.2 | -17.3 | 9.5 | 0.0 | 0.2 | -23.9 | 5.6 | 0.0 |
| THE PROMISED MOVE | 1.7 | +0.0 | 0.0 | 25.8 | 0.8 | +0.0 | 0.0 | 0.0 |
| TIED UP BY THE SUM | 0.9 | +102.9 | 83.9 | 41.7 | 0.8 | +79.6 | 61.2 | 13.6 |
| TIME ON OUR SIDE | 26.6 | +393.1 | 8.1 | 298.8 | 7.9 | +133.0 | 0.0 | 136.1 |
| TWO OR MORE ARRIVE | - | - | - | - | 0.1 | +0.5 | 0.0 | 0.0 |
| WAITS AGAIN | 1.8 | +0.0 | 0.0 | 36.6 | 1.4 | +0.0 | 0.0 | 20.4 |
| WAR ENGINE CHARGES | 0.1 | +12.9 | 36.5 | 0.0 | - | - | - | - |
| WAR ENGINE JOBS | 0.1 | +0.0 | 0.0 | 5.6 | 0.1 | +0.0 | 0.0 | 0.0 |
| WEARS DOWN | - | - | - | - | 0.0 | +1.8 | 0.0 | 0.0 |
| WHO HITS BACK | 0.3 | +70.7 | 0.0 | 6.4 | 0.3 | +63.3 | 0.0 | 18.0 |
| WHOLE FIGHT | 0.2 | +25.8 | 26.2 | 0.0 | 0.4 | +6.1 | 34.4 | 13.1 |
| WHOLE FIGHT GAIN | 0.2 | +10.7 | 24.8 | 0.0 | 0.3 | +33.2 | 30.0 | 3.9 |
| WIDER SPREAD | 2.2 | -2.3 | 273.0 | 69.8 | 2.3 | -3.9 | 263.0 | 81.4 |
| WOUNDED STAYS OUT | 0.0 | +0.0 | 0.0 | 6.0 | - | - | - | - |
| WOUNDS ON THE RANKS | 1.2 | +61.1 | 0.0 | 27.5 | 1.4 | +98.9 | 0.0 | 49.9 |

### Rule changes: h3-mine-efe7e34-p2

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HOLDER ASSIGNMENT | 424 | 424 | 403 | 11.19 | +23954 | +59.4 |
| SEARCH SPOT | 417 | 417 | 399 | 11.08 | +22533 | +56.5 |
| LEGAL CHARGES ONLY | 384 | 384 | 384 | 10.67 | +0 | +0.0 |
| HIS SHOT LIST | 1334 | 1334 | 363 | 10.08 | +7722 | +21.3 |
| FIVE ACTION | 3166 | 3162 | 358 | 9.94 | +14981 | +41.8 |
| DEPLOY BY FIGURES | 538 | 538 | 326 | 9.06 | +4447 | +13.6 |
| PATHS CROSS | 298 | 298 | 298 | 8.28 | +13548 | +45.5 |
| ONE TARGET A SHOOTER | 1111 | 1111 | 281 | 7.81 | +3082 | +11.0 |
| TIME ON OUR SIDE | 1240 | 1105 | 229 | 6.36 | +573 | +2.5 |
| MOVE TO CHARGE COMPUTED | 323 | 323 | 192 | 5.33 | +18344 | +95.5 |
| FOUR ROUNDS | 243 | 239 | 136 | 3.78 | +9781 | +71.9 |
| SHOT RISK POINTS | 720 | 720 | 121 | 3.36 | +3209 | +26.5 |
| MAX FOR POSITIONING | 460 | 449 | 101 | 2.81 | +231 | +2.3 |
| HARD STAY DROPPED | 77 | 77 | 77 | 2.14 | +0 | +0.0 |
| COVER ONCE | 410 | 315 | 69 | 1.92 | +1108 | +16.1 |
| ARTILLERY RE-ROLL WEIGHED | 61 | 61 | 61 | 1.69 | +0 | +0.0 |
| NEXT OBJECTIVE NEARER | 503 | 503 | 61 | 1.69 | +1311 | +21.5 |
| SHOTS IN THE MOVE | 881 | 835 | 60 | 1.67 | +1689 | +28.2 |
| REDIRECT COUNTER | 232 | 204 | 58 | 1.61 | +4262 | +73.5 |
| FOLLOW UP WEIGHED | 57 | 57 | 57 | 1.58 | +13279 | +233.0 |
| LANE BY FIGURES | 57 | 57 | 57 | 1.58 | +2796 | +49.1 |
| RISK BY ARC | 172 | 169 | 57 | 1.58 | +1591 | +27.9 |
| ADVANCE LANE KEPT | 56 | 56 | 56 | 1.56 | +0 | +0.0 |
| CANNON SIGHT KEPT | 52 | 52 | 52 | 1.44 | +0 | +0.0 |
| CHARGE NOT DECLARED | 52 | 52 | 52 | 1.44 | -8248 | -158.6 |
| SHOOTS FROM THE BEST SPOT | 70 | 70 | 52 | 1.44 | +423 | +8.1 |
| FALLS SHORT | 816 | 711 | 51 | 1.42 | +312 | +6.1 |
| MANOEUVRE | 87 | 87 | 51 | 1.42 | +2302 | +45.1 |
| CHARGE LOSSES | 384 | 384 | 50 | 1.39 | +4966 | +99.3 |
| RISK BY HIS FIGURE | 963 | 963 | 50 | 1.39 | +5061 | +101.2 |
| OFF BEST | 48 | 48 | 48 | 1.33 | -1616 | -33.7 |
| TIED UP BY THE SUM | 61 | 57 | 47 | 1.31 | +1248 | +26.6 |
| MARCH CHECK | 70 | 70 | 41 | 1.14 | +1182 | +28.8 |
| IDLE COST | 467 | 373 | 40 | 1.11 | +546 | +13.6 |
| MISSILES IN THE MOVE | 231 | 189 | 38 | 1.06 | +1216 | +32.0 |
| NEXT CHARGE BY LIST | 423 | 423 | 37 | 1.03 | +887 | +24.0 |
| HOLDS AMBUSHERS | 33 | 33 | 33 | 0.92 | +0 | +0.0 |
| RANDOM MOVE BY FIGURES | 52 | 52 | 31 | 0.86 | +461 | +14.9 |
| COMBAT PIVOT | 30 | 30 | 30 | 0.83 | +0 | +0.0 |
| HIS TURN DENIED | 96 | 96 | 30 | 0.83 | +1807 | +60.2 |
| CANNON PLANNED TARGET | 231 | 231 | 29 | 0.81 | -601 | -20.7 |
| RESERVE FALL BACK | 29 | 29 | 29 | 0.81 | +1243 | +42.9 |
| ONE OBJECTIVE FORMULA | 287 | 256 | 28 | 0.78 | +988 | +35.3 |
| STAY WORTH | 972 | 931 | 28 | 0.78 | +386 | +13.8 |
| LONE WIZARD KEPT IN | 26 | 26 | 26 | 0.72 | +1940 | +74.6 |
| CHAFF IN THE MOVE | 41 | 39 | 25 | 0.69 | +176 | +7.1 |
| CHARGE NOW FIRST | 119 | 119 | 25 | 0.69 | -1422 | -56.9 |
| HOLDER AT DEPLOYMENT | 40 | 40 | 24 | 0.67 | +1519 | +63.3 |
| WHO HITS BACK | 24 | 24 | 24 | 0.67 | +3494 | +145.6 |
| WOUNDS ON THE RANKS | 94 | 94 | 24 | 0.67 | +1140 | +47.5 |
| MARCH BY THE SUM | 22 | 22 | 22 | 0.61 | +1123 | +51.0 |
| SCOUT WAITS | 22 | 22 | 22 | 0.61 | +0 | +0.0 |
| SURE REACH TOGETHER | 28 | 28 | 18 | 0.50 | +58 | +3.2 |
| CAST JOB | 30 | 30 | 17 | 0.47 | +87 | +5.1 |
| FIGHT TO THE END | 81 | 80 | 17 | 0.47 | +470 | +27.6 |
| NEARER NOT NEEDED | 300 | 285 | 17 | 0.47 | +417 | +24.5 |
| OVERRUNS AWAY | 39 | 39 | 17 | 0.47 | +414 | +24.4 |
| SHOOTERS IN TWO RANKS | 17 | 17 | 17 | 0.47 | +40 | +2.4 |
| CHAFF PASSED | 15 | 15 | 15 | 0.42 | -44 | -3.0 |
| AFTERMATH IN POINTS | 14 | 14 | 14 | 0.39 | +1211 | +86.5 |
| ONE FIGHT FORMULA | 441 | 266 | 13 | 0.36 | +184 | +14.2 |
| REDIRECT WEIGHED | 13 | 13 | 13 | 0.36 | +603 | +46.4 |
| WHOLE FIGHT GAIN | 18 | 18 | 13 | 0.36 | +442 | +34.0 |
| CASTER AWAY FROM SCREEN | 12 | 12 | 12 | 0.33 | +0 | +0.0 |
| CASTS FROM BEHIND | 11 | 11 | 11 | 0.31 | +0 | +0.0 |
| SHORT GUN FORWARD | 10 | 10 | 10 | 0.28 | +0 | +0.0 |
| STUCK PIVOT | 10 | 10 | 10 | 0.28 | +0 | +0.0 |
| FIRE IN ORDER | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| MODEL FACING | 8 | 8 | 8 | 0.22 | +2786 | +348.3 |
| MOVES UNITS SPELL | 8 | 8 | 8 | 0.22 | +142 | +17.8 |
| NEEDED THERE | 9 | 9 | 8 | 0.22 | +0 | +0.0 |
| OPENS UP | 17 | 16 | 8 | 0.22 | +295 | +36.8 |
| GUN MASK | 44 | 44 | 7 | 0.19 | +97 | +13.9 |
| PIVOT GUARDS FLANK | 7 | 7 | 7 | 0.19 | -172 | -24.6 |
| WHOLE FIGHT | 20 | 19 | 7 | 0.19 | +172 | +24.6 |
| WIDER SPREAD | 164 | 160 | 7 | 0.19 | +40 | +5.7 |
| CASTING BLOCK | 11 | 11 | 6 | 0.17 | +69 | +11.5 |
| FALLBACK BY WORTH | 31 | 31 | 6 | 0.17 | +72 | +12.0 |
| FRIENDS SHOTS CHECKED | 6 | 6 | 6 | 0.17 | +492 | +82.0 |
| HIS CHARGE DENIED | 25 | 24 | 6 | 0.17 | +241 | +40.2 |
| HIS MOVE AND SHOT | 153 | 153 | 6 | 0.17 | +223 | +37.1 |
| HONEST WORTH | 216 | 212 | 6 | 0.17 | +87 | +14.5 |
| KEEP FALLS | 6 | 6 | 6 | 0.17 | +394 | +65.6 |
| KILLS COUNT | 6 | 6 | 6 | 0.17 | +0 | +0.0 |
| SUPPORT NARROWED | 78 | 78 | 6 | 0.17 | -80 | -13.4 |
| REFUSING RETIRES | 15 | 15 | 5 | 0.14 | -2 | -0.3 |
| BOMBING RUN | 4 | 4 | 4 | 0.11 | +110 | +27.4 |
| EDGE GIVE GROUND | 17 | 16 | 4 | 0.11 | +44 | +10.9 |
| FEATURE BUFFS | 59 | 59 | 4 | 0.11 | +23 | +5.8 |
| PURSUES BIG PREY | 4 | 4 | 4 | 0.11 | -864 | -216.0 |
| SET UP TOGETHER | 19 | 15 | 4 | 0.11 | +204 | +51.0 |
| SPELLS IN THE FIGHT | 38 | 36 | 4 | 0.11 | +17 | +4.3 |
| BEST PRIZE | 3 | 3 | 3 | 0.08 | -90 | -29.8 |
| FALL BACK GOOD ORDER | 164 | 161 | 3 | 0.08 | +65 | +21.8 |
| FOCUS FIRE | 3 | 3 | 3 | 0.08 | +48 | +15.9 |
| HUNT IN PAIRS | 25 | 9 | 3 | 0.08 | +16 | +5.2 |
| LINE HITS NO ONE | 3 | 3 | 3 | 0.08 | +13 | +4.3 |
| LONG SHOT | 12 | 12 | 3 | 0.08 | +23 | +7.8 |
| OPENS A LANE | 7 | 3 | 3 | 0.08 | +32 | +10.5 |
| WAR ENGINE JOBS | 7 | 7 | 3 | 0.08 | -513 | -171.1 |
| BACKUP TARGETS | 21 | 14 | 2 | 0.06 | +2 | +0.8 |
| CARRIES OUT COUNTER | 4 | 4 | 2 | 0.06 | -110 | -55.2 |
| CARRIES OUT SET-UP | 3 | 3 | 2 | 0.06 | -1470 | -735.0 |
| ELIXIR WORTH | 2 | 2 | 2 | 0.06 | +40 | +20.1 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| MARCH ODDS | 2 | 2 | 2 | 0.06 | -58 | -29.0 |
| MISSILES NEXT TURN | 313 | 238 | 2 | 0.06 | +16 | +7.8 |
| NO DOUBLE ROUNDS | 193 | 190 | 2 | 0.06 | +14 | +7.0 |
| RESTRAINS TO SHOOT | 2 | 2 | 2 | 0.06 | +144 | +72.0 |
| WAR ENGINE CHARGES | 3 | 3 | 2 | 0.06 | +46 | +22.8 |
| BLOWS WHERE AIMED | 8 | 8 | 1 | 0.03 | +18 | +18.5 |
| BOUND ASSAILMENT | 1 | 1 | 1 | 0.03 | +0 | +0.1 |
| DEFENSIVE ARMY | 2 | 2 | 1 | 0.03 | -9 | -9.0 |
| FIRE AND FLEE | 1 | 1 | 1 | 0.03 | +10 | +10.0 |
| HORN WORTH | 1 | 1 | 1 | 0.03 | +18 | +17.8 |
| MOVE SPELL IN RANGE | 5 | 5 | 1 | 0.03 | +14 | +13.5 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.03 | +122 | +121.9 |
| REDIRECT BY WHAT IT STOPS | 23 | 23 | 1 | 0.03 | +148 | +148.3 |
| REFORMS TO MEET IT | 86 | 86 | 1 | 0.03 | +0 | +0.0 |
| RUN DOWN | 164 | 160 | 1 | 0.03 | +10 | +9.5 |
| SAFER THAN THE JOB | 1 | 1 | 1 | 0.03 | +88 | +88.1 |
| STANDS TO CAST | 1 | 1 | 1 | 0.03 | -7 | -7.2 |
| STOPS | 2 | 2 | 1 | 0.03 | +2 | +2.5 |
| WEARS DOWN | 1 | 1 | 1 | 0.03 | +6 | +6.4 |
| WOUNDED STAYS OUT | 1 | 1 | 1 | 0.03 | -44 | -43.9 |
| ARRIVAL HUNT | 3 | 3 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 38 | 38 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 45 | trace | - | - | - | - |
| CATCH FLIERS | 1 | not checked | - | - | - | - |
| CHARACTER GUNS | 21 | 21 | 0 | 0.00 | - | - |
| CHARGER SLAIN LOST | 19 | 19 | 0 | 0.00 | - | - |
| CHEAP HELPER | 2 | not checked | - | - | - | - |
| CHEAPEST HOLDER | 6 | 5 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 32 | not checked | - | - | - | - |
| DEFENSIVE FLOOR | 1 | 1 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT LIFT | 1 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 387 | not checked | - | - | - | - |
| FRIEND CHARGES FIRST | 13 | 13 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 16 | 16 | 0 | 0.00 | - | - |
| GIVES UP | 11 | 10 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 1 | 1 | 0 | 0.00 | - | - |
| GROUND FLIERS | 3 | not checked | - | - | - | - |
| GUN FIGURES | 70 | not checked | - | - | - | - |
| HE SHOOTS OR CHARGES | 148 | 148 | 0 | 0.00 | - | - |
| HELPER ALREADY ASKED | 1 | not checked | - | - | - | - |
| HELPER UNSEEN | 3 | 3 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 193 | 193 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 288 | 288 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 129 | 129 | 0 | 0.00 | - | - |
| HOLD ODDS | 222 | 222 | 0 | 0.00 | - | - |
| HUNT KEPT | 2 | trace | - | - | - | - |
| HUNT RESULT | 2 | trace | - | - | - | - |
| HUNT THE GUNS | 2 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 5 | not checked | - | - | - | - |
| LOST CHARGE | 2 | 2 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 6 | 6 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 13 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 13 | trace | - | - | - | - |
| MARCH OVER CASTS | 61 | 61 | 0 | 0.00 | - | - |
| MOVE SPELL NOT WORTH | 1 | not checked | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 14 | trace | - | - | - | - |
| MOVE SPELL SPOT | 23 | not checked | - | - | - | - |
| NOT TURNED | 25 | 25 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 37 | not checked | - | - | - | - |
| ONE CHARGE A CHARGER | 203 | 203 | 0 | 0.00 | - | - |
| PLAN RESULT | 2846 | trace | - | - | - | - |
| SAME CHARGE LATER | 11 | 11 | 0 | 0.00 | - | - |
| SCOUT SPOT | 20 | 20 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 13 | 13 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 21 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 8 | not checked | - | - | - | - |
| SET-UP MISSED | 4 | trace | - | - | - | - |
| SHOOTER COUNTED ONCE | 1 | 1 | 0 | 0.00 | - | - |
| SHOT OR CHARGE | 21 | 21 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 12 | not checked | - | - | - | - |
| SPELL WORTH | 86 | not checked | - | - | - | - |
| STAND AND SHOOT | 36 | 36 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 20 | 20 | 0 | 0.00 | - | - |
| STANDS STILL | 1004 | 1004 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 307 | not checked | - | - | - | - |
| THE PROMISE ADDS | 16 | 16 | 0 | 0.00 | - | - |
| THE PROMISED MOVE | 87 | not checked | - | - | - | - |
| TWO OR MORE ARRIVE | 2 | not checked | - | - | - | - |
| WAITS AGAIN | 114 | 114 | 0 | 0.00 | - | - |

### Off best figure: h3-mine-efe7e34-p2

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| CHARGE NOT DECLARED | rule | 0.58 | 0.75 | 171.8 |
| PATHS CROSS | rule | 0.67 | 0.56 | 29.6 |
| HOLDER ASSIGNMENT | rule | 0.97 | - | 23.4 |
| JOB FIRST | gate | 0.14 | 0.69 | 43.5 |
| CHARGE NOW FIRST | rule | 0.50 | 0.19 | 56.9 |
| CANNON PLANNED TARGET | rule | 0.22 | 0.03 | 73.2 |
| CHAFF PASSED | rule | 0.19 | 0.06 | 4.9 |
| PIVOT GUARDS FLANK | rule | 0.03 | 0.17 | 24.6 |
| AFTERMATH BAND | gate | 0.08 | 0.06 | 3.0 |
| DEPLOY BY FIGURES | rule | 0.03 | 0.11 | 17.8 |
| FALLBACK | gate | 0.11 | - | 13.1 |
| PURSUES BIG PREY | rule | 0.11 | - | 216.0 |
| SUPPORT NARROWED | rule | 0.08 | 0.03 | 19.9 |
| BEST PRIZE | rule | - | 0.08 | 29.8 |
| FIGHT ORDER BAND | gate | 0.03 | 0.06 | 2.2 |
| WAR ENGINE JOBS | rule | - | 0.08 | 171.1 |
| CARRIES OUT COUNTER | rule | 0.03 | 0.03 | 55.2 |
| CARRIES OUT SET-UP | rule | 0.03 | 0.03 | 735.0 |
| LONE CHARACTER SAFE SPOT | gate | 0.06 | - | 3.3 |
| MARCH ODDS | rule | 0.03 | 0.03 | 29.0 |
| NO REASON | gate | 0.06 | - | 69.0 |
| REDIRECT WEIGHED | rule | - | 0.06 | 35.0 |
| AFTERMATH IN POINTS | rule | 0.03 | - | 1.6 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.03 | - | 6.9 |
| DEFENSIVE ARMY | rule | - | 0.03 | 9.0 |
| REFUSING RETIRES | rule | 0.03 | - | 1.3 |
| RULE SWITCHED OFF | gate | - | 0.03 | 85.5 |
| STANDS TO CAST | rule | - | 0.03 | 7.2 |
| WOUNDED STAYS OUT | rule | 0.03 | - | 43.9 |

### Plans: h3-mine-efe7e34-p2

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 2.8 | 67% | 527 | 347 | 66% |
| Mine | join | 0.8 | 100% | 22 | 0 | 0% |
| Mine | move | 28.4 | 95% | 1661 | 0 | 0% |
| Mine | shoot | 8.6 | 57% | 442 | 527 | 119% |
| Mine | support | 0.3 | 75% | 4 | 0 | 0% |
| Opponent | charge | 3.1 | 62% | 507 | 307 | 61% |
| Opponent | join | 0.9 | 100% | 30 | 0 | 0% |
| Opponent | move | 29.6 | 94% | 1743 | 0 | 0% |
| Opponent | shoot | 3.9 | 50% | 156 | 182 | 117% |
| Opponent | support | 0.7 | 83% | 9 | 0 | 0% |

### Packages: hunt the guns, h3-mine-efe7e34-p2

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 41 |
| Opponent | 0.1 | 2 | 0 | 100% | 50% | 0% | 2.0 | 232 | 70 | 50% | 57 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 53 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 156 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 38 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 132 |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 19 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Tomb Kings of Khemri | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 18 |
| Vampire Counts | 0.2 | 2 | 0 | 100% | 50% | 0% | 2.0 | 232 | 70 | 50% | 15 |
| Warriors of Chaos | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 74 |
| Wood Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |

### Battle groups: h3-mine-efe7e34-p2

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 2.5 | 34% | 65% | 3% | 0% | 30% | 0% | 13% | 53% | 3% |
| Opponent | REDIRECT COUNTER | 3.9 | 21% | 77% | 10% | 0% | 22% | 0% | 15% | 63% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: h3-mine-efe7e34-p2

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 4 | 0 (4) | 0 | 0 | 0 | 75% | 5.0 | 0 (3) | 0 (1) | - | 0 (3) | 0 (1) |
| Mine | Chaff | 33 | 116 (33) | 8 | 108 | 45 | 42% | 3.2 | 100 (9) | 149 (16) | 69 (8) | 137 (25) | 46 (8) |
| Mine | Character | 123 | 51 (123) | 50 | 1 | 34 | 20% | 2.6 | 73 (44) | 46 (46) | 44 (17) | 60 (59) | 51 (48) |
| Mine | Clean-up | 25 | 61 (25) | 5 | 55 | 14 | 44% | 2.6 | 116 (6) | 41 (11) | 57 (8) | 58 (17) | 68 (8) |
| Mine | Fast Hammer | 39 | 44 (39) | 24 | 19 | 38 | 23% | 2.7 | 36 (11) | 50 (23) | 19 (5) | 42 (21) | 45 (18) |
| Mine | Hammer | 59 | 40 (59) | 22 | 18 | 28 | 29% | 2.7 | 58 (16) | 28 (31) | 46 (12) | 44 (33) | 35 (26) |
| Mine | Holder | 24 | 83 (24) | 1 | 82 | 35 | 67% | 3.1 | 99 (9) | 59 (12) | 139 (3) | 92 (14) | 63 (10) |
| Mine | Shooter | 43 | 102 (43) | 52 | 51 | 43 | 5% | 1.8 | 87 (9) | 128 (23) | 53 (11) | 111 (30) | 83 (13) |
| Mine | Support | 2 | 0 (2) | 0 | 0 | 30 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Mine | War machine | 56 | 30 (56) | 30 | 0 | 29 | 5% | 1.5 | 21 (27) | 70 (15) | 0 (14) | 72 (10) | 19 (46) |
| Mine | Wizard | 13 | 20 (13) | 20 | 0 | 40 | 31% | 3.1 | 0 (1) | 42 (6) | 0 (4) | 92 (1) | 22 (10) |
| Opponent | Chaff | 73 | 81 (73) | 13 | 68 | 53 | 40% | 3.0 | 78 (23) | 125 (23) | 46 (27) | 52 (50) | 132 (23) |
| Opponent | Character | 106 | 50 (106) | 49 | 1 | 30 | 29% | 2.4 | 46 (35) | 61 (43) | 46 (22) | 48 (63) | 57 (37) |
| Opponent | Clean-up | 14 | 27 (14) | 0 | 27 | 58 | 50% | 3.4 | 16 (3) | 46 (8) | 0 (3) | 20 (8) | 40 (6) |
| Opponent | Early | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Fast | 1 | 0 (1) | 0 | 0 | 0 | 0% | 5.0 | - | 0 (1) | - | 0 (1) | - |
| Opponent | Fast Hammer | 65 | 41 (65) | 24 | 17 | 32 | 45% | 3.1 | 40 (21) | 39 (34) | 52 (10) | 40 (38) | 43 (27) |
| Opponent | Fragile | 1 | 0 (1) | 0 | 0 | 0 | 0% | 2.0 | - | 0 (1) | - | 0 (1) | - |
| Opponent | Hammer | 36 | 25 (36) | 6 | 19 | 39 | 39% | 3.0 | 61 (7) | 25 (18) | 3 (11) | 35 (25) | 8 (11) |
| Opponent | Holder | 28 | 83 (28) | 2 | 81 | 20 | 32% | 3.2 | 123 (7) | 87 (15) | 37 (6) | 122 (11) | 56 (17) |
| Opponent | Shooter | 19 | 70 (19) | 13 | 57 | 64 | 11% | 1.8 | 98 (9) | 76 (6) | 7 (4) | 104 (13) | 13 (6) |
| Opponent | Support | 4 | 0 (4) | 0 | 0 | 40 | 75% | 3.0 | - | 0 (3) | 0 (1) | - | 0 (4) |
| Opponent | War machine | 23 | 51 (23) | 51 | 0 | 43 | 0% | 1.7 | 27 (8) | 55 (11) | 86 (4) | 89 (5) | 42 (18) |
| Opponent | Wizard | 29 | 8 (29) | 8 | 0 | 40 | 21% | 2.0 | 0 (4) | 8 (13) | 24 (5) | 19 (12) | 0 (10) |

### Charged fights: h3-mine-efe7e34-p2

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 122 | 30 | 1.0 | 1.0 | 30 | 0 | +30 | 0 of 4 | 4 of 4 | - | +30 |
| Mine | Chaos Dwarfs | 4 | 109 | 390 | 2.8 | 1.3 | 142 | 0 | +142 | 4 of 11 | 10 of 10 | +32 | +183 |
| Mine | Dwarfen Mountain Holds | 4 | 418 | 27 | 0.8 | 1.7 | 36 | 39 | -3 | 1 of 3 | 1 of 3 | -117 | +54 |
| Mine | Empire of Man | 4 | 679 | 79 | 1.5 | 1.3 | 52 | 110 | -58 | 1 of 6 | 6 of 6 | -330 | +79 |
| Mine | Grand Cathay | 5 | 243 | 271 | 3.4 | 1.0 | 80 | 32 | +47 | 5 of 17 | 17 of 17 | - | +47 |
| Mine | High Elf Realms | 4 | 308 | 883 | 5.2 | 1.3 | 168 | 3 | +165 | 9 of 21 | 18 of 21 | +197 | +153 |
| Mine | Kingdom of Bretonnia | 1 | 0 | 150 | 4.0 | 1.0 | 38 | 0 | +38 | 0 of 4 | 4 of 4 | - | +38 |
| Mine | Lizardmen | 1 | 30 | 925 | 5.0 | 1.0 | 185 | 100 | +85 | 1 of 5 | 3 of 5 | - | +85 |
| Mine | Ogre Kingdoms | 1 | 75 | 45 | 3.0 | 1.0 | 15 | 11 | +4 | 0 of 3 | 1 of 3 | - | +4 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 111 | 5.0 | 1.2 | 22 | 81 | -59 | 4 of 5 | 2 of 5 | +111 | -101 |
| Mine | Skaven | 2 | 306 | 0 | 0.5 | 1.0 | 0 | 0 | +0 | 0 of 1 | 1 of 1 | - | +0 |
| Mine | Tomb Kings of Khemri | 1 | 60 | 778 | 3.0 | 1.3 | 259 | 0 | +259 | 2 of 3 | 2 of 3 | +393 | +192 |
| Mine | Vampire Counts | 2 | 35 | 690 | 4.0 | 1.6 | 172 | 41 | +131 | 5 of 8 | 6 of 8 | +427 | -46 |
| Mine | Warriors of Chaos | 2 | 0 | 54 | 0.5 | 1.0 | 109 | 0 | +109 | 0 of 1 | 1 of 1 | - | +109 |
| **Mine** | all armies | 36 | 239 | 291 | 2.6 | 1.2 | 114 | 29 | +85 | 32 of 92 | 76 of 91 | +134 | +74 |
| Opponent | Empire of Man | 3 | 390 | 0 | 1.0 | 1.0 | 0 | 94 | -94 | 1 of 3 | 1 of 3 | - | -94 |
| Opponent | Grand Cathay | 3 | 121 | 164 | 1.3 | 1.0 | 123 | 0 | +123 | 1 of 4 | 4 of 4 | - | +123 |
| Opponent | High Elf Realms | 2 | 276 | 321 | 4.0 | 1.1 | 80 | 55 | +25 | 2 of 8 | 6 of 8 | +217 | -2 |
| Opponent | Kingdom of Bretonnia | 1 | 115 | 0 | 1.0 | 1.0 | 0 | 471 | -471 | 1 of 1 | 0 of 1 | - | -471 |
| Opponent | Ogre Kingdoms | 1 | 120 | 0 | 2.0 | 1.0 | 0 | 17 | -17 | 0 of 2 | 0 of 1 | - | -17 |
| Opponent | Orc & Goblin Tribes | 3 | 0 | 632 | 4.3 | 1.0 | 146 | 8 | +137 | 7 of 13 | 9 of 13 | - | +137 |
| Opponent | Tomb Kings of Khemri | 3 | 0 | 328 | 2.3 | 1.1 | 140 | 9 | +132 | 3 of 7 | 6 of 7 | +287 | +106 |
| Opponent | Vampire Counts | 6 | 0 | 394 | 4.2 | 1.3 | 95 | 13 | +81 | 7 of 25 | 19 of 25 | +112 | +71 |
| Opponent | Warriors of Chaos | 12 | 12 | 569 | 2.4 | 1.0 | 236 | 32 | +204 | 16 of 29 | 21 of 29 | +0 | +211 |
| Opponent | Wood Elf Realms | 2 | 0 | 551 | 5.0 | 1.4 | 110 | 29 | +81 | 4 of 10 | 7 of 10 | +118 | +66 |
| **Opponent** | all armies | 36 | 68 | 398 | 2.8 | 1.1 | 140 | 29 | +112 | 42 of 102 | 73 of 101 | +128 | +109 |

### Effective charges: h3-mine-efe7e34-p2

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 0 | 1 (net +60) | 1 (net +0) | 2 (net +30) | 0 | 0 | 0 | 25% (1 of 4) |
| Mine | Chaos Dwarfs | 11 | 0 | 0 | 2 (net +333) | 3 (net +62) | 1 (net +190) | 4 (net +38) | 1 | 20% (2 of 10) |
| Mine | Dwarfen Mountain Holds | 3 | 0 | 0 | 1 (net -117) | 1 (net +0) | 0 | 0 | 1 | 50% (1 of 2) |
| Mine | Empire of Man | 6 | 0 | 0 | 2 (net -330) | 1 (net +0) | 1 (net +55) | 2 (net +130) | 0 | 33% (2 of 6) |
| Mine | Grand Cathay | 17 | 4 (net +194) | 0 | 2 (net +0) | 3 (net +20) | 3 (net -103) | 5 (net +55) | 0 | 12% (2 of 17) |
| Mine | High Elf Realms | 21 | 0 | 0 | 2 (net +244) | 5 (net +94) | 4 (net +116) | 10 (net +205) | 0 | 10% (2 of 21) |
| Mine | Kingdom of Bretonnia | 4 | 0 | 0 | 0 | 0 | 2 (net +40) | 1 (net +0) | 1 | 0% (0 of 3) |
| Mine | Lizardmen | 5 | 1 (net +0) | 0 | 0 | 1 (net +0) | 0 | 1 (net +205) | 2 | 0% (0 of 3) |
| Mine | Ogre Kingdoms | 3 | 1 (net +0) | 0 | 1 (net +0) | 0 | 1 (net +11) | 0 | 0 | 33% (1 of 3) |
| Mine | Orc & Goblin Tribes | 5 | 3 (net -117) | 0 | 0 | 0 | 1 (net +111) | 0 | 1 | 0% (0 of 4) |
| Mine | Skaven | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +0) | 0 | 0% (0 of 1) |
| Mine | Tomb Kings of Khemri | 3 | 2 (net +192) | 0 | 0 | 0 | 0 | 1 (net +393) | 0 | 0% (0 of 3) |
| Mine | Vampire Counts | 8 | 4 (net +195) | 0 | 0 | 1 (net +0) | 3 (net +90) | 0 | 0 | 0% (0 of 8) |
| Mine | Warriors of Chaos | 1 | 0 | 0 | 0 | 0 | 1 (net +109) | 0 | 0 | 0% (0 of 1) |
| Opponent | Empire of Man | 3 | 1 (net +0) | 0 | 1 (net -281) | 0 | 0 | 1 (net +0) | 0 | 33% (1 of 3) |
| Opponent | Grand Cathay | 4 | 0 | 0 | 0 | 4 (net +123) | 0 | 0 | 0 | 0% (0 of 4) |
| Opponent | High Elf Realms | 8 | 1 (net +0) | 0 | 2 (net +0) | 3 (net -20) | 0 | 2 (net +130) | 0 | 25% (2 of 8) |
| Opponent | Kingdom of Bretonnia | 1 | 0 | 0 | 0 | 1 (net -471) | 0 | 0 | 0 | 0% (0 of 1) |
| Opponent | Ogre Kingdoms | 2 | 1 (net -34) | 0 | 0 | 0 | 0 | 0 | 1 | 0% (0 of 1) |
| Opponent | Orc & Goblin Tribes | 13 | 1 (net +0) | 0 | 0 | 1 (net +369) | 0 | 3 (net +135) | 8 | 0% (0 of 5) |
| Opponent | Tomb Kings of Khemri | 7 | 0 | 1 (net +0) | 0 | 0 | 1 (net +0) | 3 (net +146) | 2 | 0% (0 of 5) |
| Opponent | Vampire Counts | 25 | 6 (net +24) | 4 (net +56) | 3 (net +251) | 2 (net -74) | 7 (net +84) | 3 (net +155) | 0 | 12% (3 of 25) |
| Opponent | Warriors of Chaos | 29 | 5 (net +282) | 0 | 1 (net +362) | 11 (net +194) | 2 (net +72) | 7 (net +290) | 3 | 4% (1 of 26) |
| Opponent | Wood Elf Realms | 10 | 4 (net +45) | 0 | 1 (net +0) | 0 | 1 (net +70) | 1 (net +285) | 3 | 14% (1 of 7) |

### Charged fights, damage counted: h3-mine-efe7e34-p2

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 15 | 337 | 353 | +106 | 174 | 76 | +97 | +28.9 |
| Mine | 50-54% | 1 | 52 | 60 | +60 | 60 | 0 | +60 | +115.4 |
| Mine | Effective (55-75%) | 11 | 366 | 234 | +34 | 146 | 97 | +49 | +13.4 |
| Mine | 76-89% | 17 | 340 | 191 | +46 | 70 | 11 | +59 | +17.5 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 25 | 344 | 175 | +133 | 154 | 8 | +146 | +42.6 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 17 | 421 | 91 | +58 | 92 | 28 | +64 | +15.2 |
| Mine | No odds | 6 | 210 | 205 | +119 | 234 | 112 | +122 | +58.1 |
| Mine | All fights | 92 | 347 | 199 | +85 | 133 | 41 | +93 | +26.8 |
| Opponent | Long shot (under 50%) | 19 | 191 | 245 | +89 | 139 | 71 | +68 | +35.5 |
| Opponent | 50-54% | 5 | 156 | 165 | +45 | 111 | 13 | +98 | +63.2 |
| Opponent | Effective (55-75%) | 8 | 287 | 161 | +104 | 177 | 35 | +142 | +49.5 |
| Opponent | 76-89% | 22 | 281 | 226 | +105 | 165 | 71 | +94 | +33.3 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 20 | 340 | 186 | +194 | 214 | 37 | +177 | +52.1 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 11 | 433 | 91 | +73 | 114 | 14 | +100 | +23.2 |
| Opponent | No odds | 17 | 253 | 215 | +95 | 144 | 61 | +82 | +32.5 |
| Opponent | All fights | 102 | 282 | 197 | +112 | 159 | 51 | +108 | +38.3 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| h3-mine-efe7e34-p2 | move | 317 | 59 (19%) | 51 (16%) | 48 (15%) | 210 (66%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0108, L0123, L2430, L2628 |
| Charmed Shield | Opponent | L0224, L0325, L0427, L1027, L1827, L2324, L3034 |
| Clockwork Compass | Mine | L1213, L1230 |
| Clockwork Compass | Opponent | L0812 |
| Elixir of Power | Mine | L1119, L1928 |
| Elixir of Power | Opponent | L0411, L0919, L1011, L1119, L1419 |
| Fistful of Laurels | Mine | L1827 |
| Fistful of Laurels | Opponent | L0618 |
| Horn of the Wild Hunt | Opponent | L0633 |
| Invocation of Nehek | Mine | L2430 |
| Invocation of Nehek | Opponent | L0224, L0325, L0427, L1027, L1827, L2324 |
| Opal Amulet | Mine | L1419 |
| Periapt of Soul Exchange | Mine | L2030, L2132 |
| Ring of Doom | Mine | L0207, L0224, L1119, L1213, L1230, L1516, L1532 |
| Ring of Doom | Opponent | L0411, L0633, L0812, L1011 |
| Ring of Jet | Mine | L1011, L1027, L1119, L1213, L1230 |
| Ring of Jet | Opponent | L0411, L0812, L1011 |
| Standard of the Fell Warrior | Mine | L1323 |
| Standard of the Fell Warrior | Opponent | L0513, L1213 |
| Storm Daemon (Renegade 2.0) | Mine | L2132 |
| Twice-Blessed Armour | Mine | L0722, L1011, L1027 |
| Twice-Blessed Armour | Opponent | L0207 |
| Witch Hunter's Ward | Mine | L0722, L0812, L0828 |
| Witch Hunter's Ward | Opponent | L0108, L0207, L0308 |

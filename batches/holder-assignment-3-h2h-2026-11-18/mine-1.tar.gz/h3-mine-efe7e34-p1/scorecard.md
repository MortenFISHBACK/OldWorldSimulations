# Doctrine scorecard: h3-mine-efe7e34-p1

### Scorecard: h3-mine-efe7e34-p1

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0103 | 1 | 1 | Mine | no | 0 | - | 0 | 3 | 0 | 0 | 0 | 0 |
| L0103 | 1 | 1 | Opponent | no | 0 | 6 | 1 | 1 | 0 | 0 | 0 | 480 |
| L0120 | 6 | 1 | Mine | no | 8 | - | 0 | 2 | 0 | 0 | 0 | 0 |
| L0120 | 6 | 1 | Opponent | no | 1 | - | 1 | 3 | 0 | 0 | 0 | 210 |
| L0204 | 6 | 1 | Mine | no | 0 | - | 0 | 4 | 0 | 0 | 0 | 170 |
| L0204 | 6 | 1 | Opponent | no | 0 | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L0219 | 3 | 1 | Mine | no | 5 | 2 | 3 | 1 | 0 | 0 | 0 | 255 |
| L0219 | 3 | 1 | Opponent | yes | 6 | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| L0304 | 4 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 539 |
| L0304 | 4 | 1 | Opponent | no | 7 | 3 | 2 | 3 | 0 | 0 | 0 | 310 |
| L0321 | 3 | 1 | Mine | no | 3 | - | 0 | 0 | 0 | 0 | 0 | 225 |
| L0321 | 3 | 1 | Opponent | no | 5 | - | 1 | 5 | 0 | 0 | 0 | 210 |
| L0406 | 4 | 1 | Mine | no | 2 | 3 | 3 | 3 | 1 | 0 | 0 | 0 |
| L0406 | 4 | 1 | Opponent | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 681 |
| L0423 | 3 | 1 | Mine | no | 6 | 2 | 6 | 2 | 0 | 0 | 0 | 0 |
| L0423 | 3 | 1 | Opponent | no | 8 | 2 | 2 | 1 | 0 | 0 | 0 | 66 |
| L0510 | 6 | 1 | Mine | no | 5 | - | 1 | 0 | 0 | 0 | 0 | 574 |
| L0510 | 6 | 1 | Opponent | no | 5 | 2 | 3 | 0 | 0 | 0 | 0 | 0 |
| L0525 | 3 | 1 | Mine | no | 5 | - | 0 | 2 | 0 | 0 | 0 | 328 |
| L0525 | 3 | 1 | Opponent | no | 9 | 3 | 2 | 2 | 1 | 0 | 0 | 211 |
| L0613 | 1 | 1 | Mine | no | 0 | - | 0 | 2 | 1 | 0 | 0 | 416 |
| L0613 | 1 | 1 | Opponent | no | 0 | 3 | 1 | 0 | 0 | 0 | 0 | 140 |
| L0630 | 6 | 1 | Mine | no | 1 | - | 3 | 0 | 0 | 0 | 0 | 508 |
| L0630 | 6 | 1 | Opponent | no | 6 | 2 | 4 | 1 | 1 | 0 | 0 | 0 |
| L0718 | 4 | 1 | Mine | no | 2 | 2 | 1 | 2 | 0 | 0 | 0 | 247 |
| L0718 | 4 | 1 | Opponent | no | 0 | 2 | 5 | 1 | 1 | 0 | 0 | 228 |
| L0734 | 2 | 1 | Mine | - | - | 3 | 1 | 2 | 0 | 0 | 0 | 250 |
| L0734 | 2 | 1 | Opponent | - | - | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L0824 | 2 | 1 | Mine | - | - | 3 | 3 | 2 | 0 | 0 | 0 | 310 |
| L0824 | 2 | 1 | Opponent | - | - | 2 | 3 | 3 | 1 | 0 | 0 | 0 |
| L0915 | 3 | 1 | Mine | no | 1 | - | 0 | 0 | 1 | 0 | 0 | 257 |
| L0915 | 3 | 1 | Opponent | no | 5 | 2 | 4 | 1 | 1 | 0 | 0 | 0 |
| L0931 | 1 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 117 |
| L0931 | 1 | 1 | Opponent | no | 2 | 3 | 5 | 1 | 1 | 0 | 0 | 0 |
| L1023 | 3 | 1 | Mine | no | 8 | 2 | 5 | 0 | 0 | 0 | 0 | 0 |
| L1023 | 3 | 1 | Opponent | no | 0 | 3 | 4 | 4 | 2 | 0 | 0 | 138 |
| L1116 | 6 | 1 | Mine | no | 14 | 2 | 2 | 1 | 0 | 0 | 0 | 427 |
| L1116 | 6 | 1 | Opponent | yes | 5 | 3 | 2 | 2 | 1 | 0 | 0 | 0 |
| L1131 | 3 | 1 | Mine | no | 2 | - | 4 | 0 | 0 | 0 | 0 | 0 |
| L1131 | 3 | 1 | Opponent | no | 0 | - | 0 | 1 | 1 | 0 | 0 | 170 |
| L1225 | 1 | 1 | Mine | yes | 13 | 2 | 8 | 0 | 0 | 0 | 0 | 330 |
| L1225 | 1 | 1 | Opponent | no | 4 | 2 | 3 | 1 | 2 | 0 | 0 | 0 |
| L1320 | 6 | 1 | Mine | no | 6 | 2 | 2 | 0 | 0 | 0 | 0 | 140 |
| L1320 | 6 | 1 | Opponent | no | 5 | - | 1 | 1 | 1 | 0 | 0 | 485 |
| L1335 | 3 | 1 | Mine | no | 7 | - | 2 | 0 | 0 | 0 | 0 | 140 |
| L1335 | 3 | 1 | Opponent | no | 2 | - | 2 | 3 | 0 | 0 | 0 | 499 |
| L1431 | 3 | 1 | Mine | no | 3 | 2 | 3 | 0 | 0 | 0 | 0 | 0 |
| L1431 | 3 | 1 | Opponent | no | 0 | - | 3 | 1 | 2 | 0 | 0 | 0 |
| L1528 | 4 | 1 | Mine | no | 4 | 3 | 1 | 0 | 0 | 0 | 0 | 0 |
| L1528 | 4 | 1 | Opponent | no | 2 | - | 0 | 1 | 1 | 0 | 0 | 0 |
| L1627 | 1 | 1 | Mine | yes | 8 | 2 | 3 | 0 | 0 | 0 | 0 | 0 |
| L1627 | 1 | 1 | Opponent | yes | 10 | 1 | 3 | 1 | 0 | 0 | 0 | 0 |
| L1724 | 2 | 1 | Mine | - | - | 1 | 4 | 0 | 1 | 0 | 0 | 0 |
| L1724 | 2 | 1 | Opponent | - | - | 2 | 7 | 1 | 0 | 0 | 0 | 0 |
| L1824 | 6 | 1 | Mine | no | 0 | 3 | 7 | 0 | 1 | 0 | 0 | 0 |
| L1824 | 6 | 1 | Opponent | no | 1 | 2 | 5 | 0 | 0 | 0 | 0 | 0 |
| L1924 | 4 | 1 | Mine | no | 0 | 2 | 3 | 0 | 0 | 0 | 0 | 235 |
| L1924 | 4 | 1 | Opponent | no | 0 | 2 | 5 | 0 | 0 | 0 | 0 | 60 |
| L2025 | 3 | 1 | Mine | yes | 7 | - | 1 | 2 | 0 | 0 | 0 | 420 |
| L2025 | 3 | 1 | Opponent | no | 2 | 1 | 5 | 1 | 0 | 0 | 0 | 0 |
| L2128 | 4 | 1 | Mine | no | 0 | - | 1 | 2 | 0 | 0 | 0 | 467 |
| L2128 | 4 | 1 | Opponent | no | 12 | 5 | 0 | 1 | 0 | 0 | 0 | 0 |
| L2233 | 1 | 1 | Mine | yes | 1 | 2 | 3 | 0 | 0 | 0 | 0 | 0 |
| L2233 | 1 | 1 | Opponent | yes | 0 | 2 | 4 | 2 | 1 | 0 | 0 | 785 |
| L2425 | 1 | 1 | Mine | no | 3 | 1 | 4 | 0 | 0 | 0 | 0 | 285 |
| L2425 | 1 | 1 | Opponent | no | 5 | 2 | 6 | 0 | 0 | 0 | 0 | 0 |
| L2532 | 6 | 1 | Mine | no | 11 | - | 5 | 0 | 1 | 0 | 0 | 0 |
| L2532 | 6 | 1 | Opponent | no | 6 | 1 | 5 | 1 | 0 | 0 | 0 | 170 |
| L2732 | 2 | 1 | Mine | - | - | 2 | 5 | 4 | 0 | 0 | 0 | 0 |
| L2732 | 2 | 1 | Opponent | - | - | 4 | 3 | 5 | 0 | 0 | 0 | 505 |
| L3031 | 1 | 1 | Mine | no | 5 | 2 | 2 | 0 | 0 | 0 | 0 | 0 |
| L3031 | 1 | 1 | Opponent | no | 4 | - | 3 | 2 | 0 | 0 | 0 | 170 |
| **Average** | | | Mine | 12% | 4.1 | 2.1 | 2.4 | 1.0 | 0.2 | 0.0 | 0.0 | 184.4 |
| **Average** | | | Opponent | 12% | 3.5 | 2.4 | 2.9 | 1.5 | 0.5 | 0.0 | 0.0 | 153.3 |

### KPIs: h3-mine-efe7e34-p1

Rules off - Opponent only: HOLDER ASSIGNMENT.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 30% (50 of 167) | 5% (8 of 177) | 17% (58 of 344) |
| Winner chose to follow up after the loser gave ground |  | 92% (65 of 71); on the table 94% | 81% (44 of 54); on the table 89% | 87% (109 of 125); on the table 92% |
| Winner chose to pursue after the loser fell back in good order |  | 100% (2 of 2); on the table 100% | 75% (12 of 16); on the table 81% | 78% (14 of 18); on the table 83% |
| Winner chose to pursue after the loser fled |  | 45% (10 of 22); on the table 59% | 79% (22 of 28); on the table 82% | 64% (32 of 50); on the table 72% |
| Winner chose to follow up or pursue (all three) |  | 81% (77 of 95); on the table 86% | 80% (78 of 98); on the table 86% | 80% (155 of 193); on the table 86% |
| Magic missiles tried each own turn | 50%+ | 35% (114 of 328) | 31% (58 of 188) | 33% (172 of 516) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 43% (114 of 265) | 45% (58 of 130) | 44% (172 of 395) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 45% (10 of 22) | 57% (48 of 84) | 55% (58 of 106) |
| Points that never fought | lower | 44% (30366 of 69069) | 40% (28923 of 71977) | 42% (59289 of 141046) |
|   infantry points that never fought | lower | 60% (9582 of 16104) | 52% (7200 of 13743) | 56% (16782 of 29847) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 51% (140 of 276) | 56% (161 of 285) | 54% (301 of 561) |
| Bound items with a magic missile used (at least once a game) |  | 100% (21 of 21); 2.2 uses a game | 93% (13 of 14); 1.3 uses a game | 97% (34 of 35); 1.7 uses a game |
| Bound items with another spell used |  | 53% (8 of 15); 0.4 uses a game | 100% (3 of 3); 0.2 uses a game | 61% (11 of 18); 0.3 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 55% (11 of 20); 0.3 uses a game | 60% (6 of 10); 0.2 uses a game | 57% (17 of 30); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 45% (25907 of 58081) | 54% (34340 of 63977) | 49% (60247 of 122058) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 2.1 (36%) | 1.0 (27%) | 3.1 (33%) |
| MARCHED: its unit marched | 1.2 (21%) | 0.7 (19%) | 1.9 (20%) |
| CHARGED: its unit charged | 0.2 (3%) | 0.1 (4%) | 0.3 (3%) |
| IN COMBAT: engaged in combat | 1.2 (21%) | 0.6 (17%) | 1.8 (19%) |
| REAR RANK: in a rear rank | 0.4 (7%) | 0.0 (1%) | 0.4 (5%) |
| FLEEING: fleeing | 0.1 (1%) | 0.1 (3%) | 0.2 (2%) |
| GONE: slain | 0.3 (5%) | 0.9 (25%) | 1.2 (12%) |
| OFF THE TABLE: off the table or not arrived | 0.2 (3%) | 0.0 (0%) | 0.2 (2%) |
| STUPIDITY: Stupidity | 0.2 (3%) | 0.0 (1%) | 0.2 (2%) |
| NOT OFFERED: not in the cast list | 0.1 (1%) | 0.1 (4%) | 0.2 (2%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.3 | 1.8 | 1.7 | 4.8 | 0.5 | 1.4 |
| not cast | 4.4 | 2.4 | 4.0 | 9.6 | 2.5 | 20.2 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) | 0.0 (0%) | 1.4 (7%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.2 (51%) | 0.3 (8%) | 3.1 (33%) | 0.4 (18%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.9 (20%) | 0.6 (24%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (3%) | 0.1 (5%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.1 (1%) | 0.1 (5%) | 0.5 (12%) | 1.8 (19%) | 0.6 (23%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.3 (8%) | 0.3 (14%) | 0.4 (10%) | 0.4 (5%) | 0.2 (7%) | 0.0 (0%) |
| FLEEING: fleeing | 0.2 (4%) | 0.0 (0%) | 0.0 (0%) | 0.2 (2%) | 0.0 (0%) | 0.5 (2%) |
| GONE: slain | 1.1 (25%) | 0.0 (0%) | 0.5 (13%) | 1.2 (12%) | 0.2 (7%) | 1.5 (7%) |
| OFF THE TABLE: off the table or not arrived | 0.1 (2%) | 0.1 (5%) | 0.0 (1%) | 0.2 (2%) | 0.0 (0%) | 0.1 (1%) |
| STUPIDITY: Stupidity | 0.2 (4%) | 0.0 (0%) | 0.1 (3%) | 0.2 (2%) | 0.1 (3%) | 0.2 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.3 (14%) | 0.0 (0%) | 0.0 (0%) | 0.3 (13%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (2%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.5 (57%) | 0.3 (12%) | 2.1 (52%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 16.4 (81%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.9 a game | 0.9 a game | 0.9 a game |
| stood (cast and not dispelled) | 60% (18 of 30) | 63% (17 of 27) | 61% (35 of 57) |
| the unit moved after it | 67% (12 of 18) | 100% (17 of 17) | 83% (29 of 35) |
| it charged on its next turn | 0% (0 of 18) | 12% (2 of 17) | 6% (2 of 35) |
| the enemy charged it first | 11% (2 of 18) | 6% (1 of 17) | 9% (3 of 35) |
| it fought by the end of its next turn | 11% (2 of 18) | 0% (0 of 17) | 6% (2 of 35) |
| it moved out of a charge the enemy had planned (not charged first) | 6% (1 of 18) | 0% (0 of 17) | 3% (1 of 35) |
| none of these (no charge, no fight, no charge escaped) | 83% (15 of 18) | 82% (14 of 17) | 83% (29 of 35) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 65% (565 of 866) | 60% (289 of 480) | 63% (854 of 1346) |
|   cavalry | 49% (24 of 49) | 66% (42 of 64) | 58% (66 of 113) |
|   character | 57% (55 of 96) | 28% (20 of 72) | 45% (75 of 168) |
|   chariot | 67% (62 of 93) | 52% (31 of 60) | 61% (93 of 153) |
|   infantry | 58% (169 of 292) | 65% (116 of 178) | 61% (285 of 470) |
|   monster | 59% (24 of 41) | 100% (14 of 14) | 69% (38 of 55) |
|   war machine | 78% (231 of 295) | 72% (66 of 92) | 77% (297 of 387) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.9 (23%) | 1.4 (26%) | 3.3 (24%) |
| CHARGED: it charged | 0.7 (8%) | 0.8 (15%) | 1.4 (11%) |
| FLEEING: it fled or was fleeing | 0.1 (1%) | 0.1 (2%) | 0.2 (2%) |
| IN COMBAT: it fought this turn or the last | 0.9 (11%) | 0.2 (4%) | 1.1 (8%) |
| MOVED: a war machine that moved | 1.1 (13%) | 0.3 (6%) | 1.4 (10%) |
| NO TARGET IN RANGE | 1.7 (21%) | 1.0 (19%) | 2.8 (20%) |
| ONLY IN COMBAT: the only targets were in combat | 0.4 (4%) | 0.2 (5%) | 0.6 (4%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.2 (14%) | 1.1 (20%) | 2.2 (16%) |
| SHELTERED: the target was sheltered | 0.1 (1%) | 0.0 (1%) | 0.1 (1%) |
| STUPIDITY | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) |
| OTHER BAR | 0.4 (4%) | 0.1 (2%) | 0.5 (3%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 2.7 | 0.5 | 81% | 5.5 pts | 15 pts |
| character | 2.6 | 1.1 | 72% | 12.0 pts | 31 pts |
| chariot | 2.6 | 2.0 | 59% | 21.5 pts | 56 pts |
| infantry | 11.6 | 4.8 | 75% | 11.1 pts | 128 pts |
| monster | 1.2 | 0.3 | 83% | 6.3 pts | 7 pts |
| war machine | 8.2 | 7.8 | 65% | 31.8 pts | 262 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.8 | 4.9 | 4.3 |
| Charges that made contact a game | 3.0 | 3.7 | 3.4 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.00 declared, 0.88 contact (24 units) | 0.57 declared, 0.48 contact (21 units) | 0.80 declared, 0.69 contact (45 units) |
|   per unit a game, units carrying another wizard (or one alone) | 1.12 declared, 0.88 contact (8 units) | 1.40 declared, 1.00 contact (10 units) | 1.28 declared, 0.94 contact (18 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.43 declared, 0.34 contact (240 units) | 0.55 declared, 0.42 contact (274 units) | 0.49 declared, 0.38 contact (514 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 44% (28 of 64) | 46% (11 of 24) | 30% (3 of 10) | 43% (42 of 98) |
| Character in a unit | 67% (28 of 42) | 55% (12 of 22) | 75% (3 of 4) | 63% (43 of 68) |
| Character on its own | 90% (36 of 40) | 49% (17 of 35) | 32% (19 of 60) | 53% (72 of 135) |
| Chariot | 50% (7 of 14) | 60% (9 of 15) | - | 55% (16 of 29) |
| Infantry | 44% (37 of 85) | 40% (16 of 40) | 100% (1 of 1) | 43% (54 of 126) |
| Monster | 65% (17 of 26) | 83% (10 of 12) | - | 71% (27 of 38) |
| Monstrous | 71% (5 of 7) | 50% (5 of 10) | - | 59% (10 of 17) |
| War Machines | 72% (34 of 47) | 100% (3 of 3) | - | 74% (37 of 50) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 62% (5 of 8); on the table 88% | 50% (51 of 102) | 62% | 59% (13 of 22) | 100% (6 of 6); 6.0 uses a game | 100% (2 of 2); 1.5 uses a game | 67% (4 of 6); 1.0 uses a game |
| Chaos Dwarfs | 7 | 80% (8 of 10); on the table 80% | 20% (12 of 60) | 54% | 56% (30 of 54) | 0.0 uses a game | 0.0 uses a game | 67% (2 of 3); 0.3 uses a game |
| Dwarfen Mountain Holds | 5 | 89% (8 of 9); on the table 89% | - | 59% | 52% (23 of 44) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 5 | 62% (5 of 8); on the table 75% | 47% (17 of 36) | 50% | 70% (38 of 54) | 0.0 uses a game | 100% (2 of 2); 0.6 uses a game | 0% (0 of 3); 0.0 uses a game |
| Grand Cathay | 5 | 80% (16 of 20); on the table 85% | 26% (30 of 114) | 43% | 40% (18 of 45) | 100% (11 of 11); 6.2 uses a game | 50% (1 of 2); 0.2 uses a game | 40% (2 of 5); 0.4 uses a game |
| High Elf Realms | 6 | 92% (11 of 12); on the table 92% | 21% (5 of 24) | 41% | 40% (19 of 47) | 100% (7 of 7); 5.0 uses a game | 50% (6 of 12); 1.5 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 2 | 83% (5 of 6); on the table 83% | - | 46% | 42% (5 of 12) | 0.0 uses a game | 0.0 uses a game | 100% (2 of 2); 1.0 uses a game |
| Lizardmen | 1 | 100% (6 of 6); on the table 100% | - | 33% | 86% (6 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 2 | 0% (0 of 2); on the table 0% | 0% (0 of 12) | 32% | 57% (8 of 14) | 100% (2 of 2); 4.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 2 | 100% (5 of 5); on the table 100% | 8% (1 of 12) | 14% | 12% (2 of 16) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |
| Skaven | 5 | 55% (6 of 11); on the table 82% | 33% (12 of 36) | 68% | 62% (24 of 39) | 100% (2 of 2); 1.8 uses a game | 0.0 uses a game | 100% (5 of 5); 1.0 uses a game |
| Tomb Kings of Khemri | 3 | 75% (9 of 12); on the table 83% | 0% (0 of 6) | 35% | 53% (8 of 15) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 12 | 85% (53 of 62); on the table 87% | 42% (30 of 72) | 26% | 50% (37 of 74) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 10 | 88% (14 of 16); on the table 94% | 28% (10 of 36) | 28% | 57% (50 of 88) | 100% (4 of 4); 1.4 uses a game | 0.0 uses a game | 100% (2 of 2); 0.2 uses a game |
| Wood Elf Realms | 3 | 67% (4 of 6); on the table 83% | 67% (4 of 6) | 46% | 67% (20 of 30) | 67% (2 of 3); 2.7 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (h3-mine-efe7e34-p1, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 56% (44) | 55% (47) | 56% (91) |
| ...free all their last turn and able to turn (per game) | 0.78 | 0.75 | 1.53 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.33 | 0.22 | 0.56 |
| ...with the charger already in that arc before they moved (per game) | 0.56 | 0.58 | 1.14 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.06 | 0.06 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.03 | 0.03 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.14 | 0.44 | 0.58 |

### Quality by phase: h3-mine-efe7e34-p1

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.2 | 2.6 |
| Strategy | Charge objectives carried out (made contact) | 58% (74 of 127) | 62% (96 of 155) |
| Strategy | Shoot objectives carried out (shot that target) | 39% (161 of 417) | 57% (84 of 148) |
| Strategy | Support requests answered (helper made contact too) | 75% (6 of 8) | 67% (6 of 9) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (2 of 2) | 100% (4 of 4) |
| Strategy | Hexes on a unit its side charged or shot that turn | 62% (10 of 16) | 56% (5 of 9) |
| Strategy | Joined characters whose unit fought | 32% (19 of 59) | 62% (24 of 39) |
| Strategy | Lone characters that fought | 72% (59 of 82) | 65% (59 of 91) |
| Movement | Charges halted short of contact | 0.1 | 0.2 |
| Movement | Idle units | 1.0 | 1.5 |
| Movement | Points that never moved of their own | 184.4 | 153.3 |
| Movement | Fights charged into per game | 2.9 | 3.3 |
| Movement | Charges with odds: long shots (under 50%) | 17 of 96, net +46 | 32 of 111, net +62 |
| Movement | Charges with odds: sweet spot (55-75%) | 11 of 96, net +177 | 8 of 111, net +246 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 18 of 96, net +76 | 15 of 111, net +80 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 26 of 96, net +96 | 31 of 111, net +79 |
| Shooting | Shots by shooting units (incl. breath weapons) | 10.0 | 6.9 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 46% (166 of 360) | 41% (101 of 249) |
| Shooting | Points destroyed by shooting units | 131.4 | 67.9 |
| Shooting | War machine shots | 6.4 | 1.8 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 44% (102 of 231) | 61% (40 of 66) |
| Shooting | Points destroyed by war machines | 65.5 | 6.9 |
| Magic | Magic missiles cast | 2.1 | 1.2 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 29% (22 of 75) | 23% (10 of 44) |
| Magic | Wounds caused by magic missiles | 5.6 | 1.2 |
| Magic | Wounds caused by other spells | 0.8 | 0.7 |
| Magic | Points destroyed by magic (all spells) | 70.1 | 29.1 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.9 / 0.6 / 0.6 / 0.0 | 2.1 / 0.4 / 0.2 / 0.2 |
| Combat | Points destroyed in combat | 273.2 | 244.4 |
| Combat | Points run down | 55.2 | 92.2 |
| Combat | Net points per charged fight, damage counted | +100 | +76 |
| Combat | Net per 100 charger points, damage counted | +36.3 | +27.3 |
| Combat | First round won (charged fights) | 76% | 81% |
| Combat | Net points per charged fight | +96 | +84 |
| Combat | Net points per supported fight / lone fight | +376 / +73 | +20 / +90 |
| Combat | Charged fights on a top-3 enemy unit | 40 of 103 | 44 of 119 |
| Game | Points lost | 562.3 | 679.4 |
| Game | VP from objectives | 733.9 | 633.3 |
| Game | Lone holders (player turns) | 4.1 | 3.5 |

- Mine won / drew / lost: 15 / 10 / 11 of 36 ended games (of 36); mean margin (Mine - Opponent) +231 VP
- The side that went first won 15 of 26 games with a winner
- Points traded per game (both sides' losses): 1242
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: h3-mine-efe7e34-p1

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.9 | +0.0 | 0.0 | 0.0 | 1.1 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.2 | +7.1 | 0.0 | 3.5 | 0.1 | +11.6 | 0.0 | 10.7 |
| ALREADY CARRIED | 0.1 | +0.0 | 0.0 | 3.6 | - | - | - | - |
| ARRIVAL HUNT | 0.0 | +0.2 | 0.0 | 0.0 | 0.1 | +2.3 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.2 | +0.0 | 0.0 | 22.4 | 0.3 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | 0.2 | +1.3 | 0.0 | 8.2 | 0.2 | +0.7 | 0.0 | 9.4 |
| BEST PRIZE | - | - | - | - | 0.0 | -0.8 | 2.1 | 0.0 |
| BLOWS WHERE AIMED | 0.2 | -24.7 | 12.7 | 14.2 | 0.2 | -52.1 | 38.1 | 13.3 |
| BOMBING RUN | 0.1 | +2.7 | 11.9 | 0.0 | - | - | - | - |
| BOUND ASSAILMENT | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CANNON PLAN MISSED | 0.9 | +0.0 | 136.8 | 22.9 | 0.1 | +0.0 | 0.0 | 0.0 |
| CANNON PLANNED TARGET | 6.1 | +129.9 | 630.9 | 99.3 | 1.8 | +35.9 | 52.5 | 12.2 |
| CANNON SIGHT KEPT | 0.9 | +0.0 | 0.0 | 3.5 | 0.2 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT COUNTER | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT SET-UP | 0.1 | -8.1 | 15.0 | 12.3 | 0.1 | -2.9 | 4.6 | 4.0 |
| CAST JOB | 0.5 | +12.3 | 44.2 | 33.5 | 0.2 | +6.3 | 19.4 | 3.2 |
| CASTER AWAY FROM SCREEN | 0.2 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.1 | +22.4 | 16.1 | 0.0 | 0.0 | +0.4 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 0.5 | +0.0 | 0.0 | 3.6 | 0.5 | +0.0 | 0.0 | 6.5 |
| CASTS FROM BEHIND | 0.1 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.0 | +0.2 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | 0.1 | +5.7 | 0.0 | 3.6 | 0.8 | +36.5 | 0.0 | 19.6 |
| CHAFF PASSED | 0.3 | -0.1 | 9.7 | 0.0 | 0.1 | -0.2 | 3.3 | 7.0 |
| CHARACTER GUNS | 0.6 | +0.0 | 0.0 | 5.2 | 0.3 | +0.0 | 0.0 | 7.6 |
| CHARGE LOSSES | 5.3 | -240.8 | 0.0 | 142.3 | 6.6 | -409.8 | 0.0 | 282.3 |
| CHARGE NOT DECLARED | 0.6 | +0.0 | 83.4 | 0.0 | 0.6 | +0.0 | 31.4 | 10.9 |
| CHARGE NOW FIRST | 1.9 | +0.0 | 212.0 | 12.6 | 1.9 | +0.0 | 175.7 | 62.1 |
| CHARGER SLAIN LOST | 0.2 | -9.1 | 46.6 | 6.9 | 0.4 | -9.3 | 15.7 | 6.7 |
| CHEAP HELPER | 0.1 | +0.0 | 3.3 | 0.0 | 0.0 | +0.0 | 1.2 | 0.0 |
| CHEAPEST HOLDER | - | - | - | - | 0.1 | -5.4 | 3.5 | 0.0 |
| COMBAT PIVOT | 0.6 | +0.0 | 28.4 | 17.2 | 0.3 | +0.0 | 0.0 | 15.3 |
| CONTINUE AHEAD WEIGHED | 0.1 | +0.0 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | 0.5 | +45.0 | 0.0 | 7.2 | 0.4 | +28.3 | 23.4 | 24.1 |
| COVER ONCE | 6.9 | -465.2 | 0.0 | 159.9 | 5.3 | -348.8 | 0.0 | 148.2 |
| DEFENSIVE ARMY | 0.1 | +0.0 | 3.2 | 0.0 | - | - | - | - |
| DEFENSIVE FLOOR | - | - | - | - | 0.0 | -0.3 | 0.0 | 7.9 |
| DEPLOY BY FIGURES | 8.1 | -10.4 | 0.0 | 26.1 | 7.6 | +84.3 | 0.0 | 4.4 |
| EDGE GIVE GROUND | 0.2 | +5.4 | 14.1 | 0.0 | 0.2 | +5.7 | 24.7 | 4.3 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| FACES THE THREAT | - | - | - | - | 0.1 | +7.6 | 0.0 | 0.0 |
| FALL BACK GOOD ORDER | 2.4 | +3.4 | 243.9 | 38.6 | 2.7 | +7.4 | 225.8 | 88.3 |
| FALLBACK BY WORTH | 0.2 | +0.7 | 0.0 | 1.2 | 0.6 | +6.6 | 0.0 | 8.3 |
| FALLS SHORT | 3.6 | +61.5 | 0.0 | 48.9 | 18.1 | +255.7 | 0.0 | 284.1 |
| FEATURE BUFFS | 0.9 | +19.4 | 0.0 | 9.7 | 0.4 | +4.8 | 0.0 | 5.1 |
| FIGHT LIFT | - | - | - | - | 0.1 | +1.6 | 16.1 | 22.6 |
| FIGHT TO THE END | 1.2 | +58.6 | 119.9 | 24.9 | 1.8 | +66.1 | 150.3 | 82.8 |
| FIRE AND FLEE | - | - | - | - | 0.0 | +0.1 | 0.0 | 0.0 |
| FIRE IN ORDER | 0.3 | +0.0 | 6.7 | 11.7 | 0.1 | +0.0 | 0.0 | 0.0 |
| FIVE ACTION | 46.4 | +2844.7 | 1300.0 | 723.6 | 42.6 | +2451.1 | 418.9 | 697.3 |
| FLANK NOT WEIGHED | 6.0 | +0.0 | 0.0 | 84.2 | 5.6 | +0.0 | 0.0 | 159.3 |
| FOLLOW UP WEIGHED | 1.2 | +208.4 | 0.0 | 0.0 | 0.9 | +176.1 | 0.0 | 21.2 |
| FOUR ROUNDS | 3.4 | +339.1 | 318.2 | 52.3 | 4.2 | +400.5 | 285.1 | 95.8 |
| FRIEND CHARGES FIRST | 0.2 | -7.9 | 0.0 | 0.0 | 0.1 | -8.1 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 0.5 | -14.1 | 1.8 | 18.3 | 0.2 | -4.2 | 0.0 | 20.5 |
| FRIENDS SHOTS CHECKED | 0.1 | +3.9 | 0.0 | 0.0 | 0.1 | +0.8 | 0.0 | 3.2 |
| GIVES UP | 0.2 | -2.1 | 29.1 | 17.7 | 0.2 | -2.1 | 10.6 | 0.0 |
| GIVES UP ITS SCREEN | - | - | - | - | 0.1 | -2.0 | 5.9 | 0.0 |
| GROUND FLIERS | 0.1 | +1.5 | 0.0 | 0.0 | 0.0 | +0.4 | 0.0 | 0.0 |
| GUN FIGURES | 1.2 | +18.5 | 43.5 | 29.0 | 0.8 | +28.8 | 51.2 | 27.9 |
| GUN MASK | 0.7 | +29.8 | 0.0 | 13.9 | 0.2 | +8.0 | 0.0 | 3.8 |
| HARD STAY DROPPED | 1.5 | +0.0 | 0.0 | 35.5 | 0.6 | +0.0 | 0.0 | 18.1 |
| HE SHOOTS OR CHARGES | 1.4 | +0.0 | 0.0 | 61.7 | 2.0 | +0.0 | 0.0 | 55.1 |
| HELPER ALREADY ASKED | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |
| HELPER UNSEEN | 0.1 | +0.0 | 6.9 | 0.0 | 0.1 | +0.0 | 0.0 | 1.4 |
| HIS CHARGE DENIED | 0.2 | +7.8 | 14.9 | 5.3 | 0.4 | +29.4 | 12.3 | 5.5 |
| HIS CHARGE LIST | 1.7 | +0.0 | 0.0 | 12.5 | 2.6 | +0.0 | 0.0 | 65.8 |
| HIS LEGAL MOVES | 4.3 | +0.0 | 0.0 | 68.2 | 3.3 | +0.0 | 0.0 | 58.2 |
| HIS MOVE AND SHOT | 1.4 | -24.7 | 0.0 | 30.0 | 2.0 | -69.7 | 0.0 | 74.4 |
| HIS RANDOM MOVE | 3.1 | +0.0 | 0.0 | 41.6 | 1.2 | +0.0 | 0.0 | 40.5 |
| HIS SHOT LIST | 14.2 | +358.3 | 0.0 | 201.5 | 20.5 | +1010.0 | 0.0 | 427.0 |
| HIS TURN DENIED | 1.2 | +30.8 | 121.6 | 37.0 | 2.2 | +110.5 | 159.5 | 50.9 |
| HOLD ODDS | 6.8 | +0.0 | 0.0 | 105.3 | - | - | - | - |
| HOLDER ASSIGNMENT | 12.6 | +1177.3 | 0.0 | 146.9 | - | - | - | - |
| HOLDER AT DEPLOYMENT | - | - | - | - | 1.5 | +245.4 | 0.0 | 1.5 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 3.1 | -109.7 | 257.2 | 16.7 | 3.4 | -156.5 | 248.0 | 67.4 |
| HUNT DROPPED | - | - | - | - | 0.1 | +0.0 | 3.5 | 0.0 |
| HUNT IN PAIRS | 0.2 | +10.4 | 0.0 | 0.0 | 0.3 | +9.2 | 0.0 | 0.0 |
| HUNT RESULT | - | - | - | - | 0.1 | +17.2 | 3.5 | 3.2 |
| HUNT THE GUNS | - | - | - | - | 0.1 | +46.7 | 6.9 | 4.4 |
| IDLE COST | 2.8 | -37.9 | 0.0 | 21.7 | 10.8 | -162.2 | 0.0 | 223.3 |
| JOINT KNOWS CHALLENGE | 0.1 | -8.0 | 30.2 | 0.0 | 0.0 | -0.7 | 3.8 | 0.0 |
| KEEP FALLS | 0.1 | +0.6 | 0.0 | 0.0 | - | - | - | - |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| KILLS COUNT | 0.0 | +0.4 | 1.7 | 0.0 | 0.1 | +1.3 | 3.3 | 0.0 |
| LANE BY FIGURES | 0.7 | +21.7 | 0.0 | 0.0 | 0.8 | +43.7 | 0.0 | 16.6 |
| LEGAL CHARGES ONLY | 6.6 | +0.0 | 298.2 | 187.2 | 5.3 | +0.0 | 214.1 | 253.4 |
| LONE CHARACTER SAFE SPOT | 0.1 | +1.5 | 2.1 | 0.0 | 0.1 | +7.4 | 0.0 | 5.4 |
| LONE WIZARD KEPT IN | 0.6 | +35.1 | 0.0 | 0.0 | 0.2 | +17.6 | 0.0 | 0.0 |
| LONG SHOT | 0.3 | +0.4 | 16.2 | 5.3 | 0.2 | +1.8 | 1.2 | 1.2 |
| LOST CHARGE | 0.1 | -0.2 | 8.8 | 4.0 | - | - | - | - |
| LURE BY WHAT IT DRAWS | - | - | - | - | 0.1 | -12.0 | 0.0 | 0.5 |
| MAKE SURE TOGETHER | 0.2 | +9.9 | 0.0 | 0.0 | 0.2 | +8.0 | 0.0 | 0.0 |
| MANOEUVRE | 1.2 | +17.9 | 0.0 | 39.8 | 1.0 | +19.2 | 0.0 | 2.8 |
| MARCH AT ESCAPER | 0.1 | +1.6 | 0.0 | 0.0 | 0.2 | +0.6 | 0.0 | 0.0 |
| MARCH BY THE SUM | 0.4 | +15.7 | 0.0 | 0.0 | 0.3 | +12.9 | 0.0 | 18.0 |
| MARCH CHECK | 1.1 | +59.8 | 0.0 | 4.5 | 1.3 | +67.9 | 0.0 | 25.6 |
| MARCH OVER CASTS | 0.9 | +42.7 | 0.0 | 16.1 | 0.8 | +29.6 | 0.0 | 51.8 |
| MAX FOR POSITIONING | 5.4 | +82.2 | 0.0 | 126.2 | 5.4 | +77.8 | 0.0 | 117.7 |
| MISSILES IN THE MOVE | 4.5 | +119.4 | 0.0 | 93.6 | 3.2 | +38.2 | 0.0 | 60.9 |
| MISSILES NEXT TURN | 5.3 | +87.5 | 0.0 | 97.9 | 4.1 | +31.2 | 0.0 | 123.5 |
| MODEL FACING | 0.3 | +76.2 | 0.0 | 1.7 | 0.1 | +29.0 | 0.0 | 3.3 |
| MOVE SPELL IN RANGE | 0.2 | +5.3 | 0.0 | 32.2 | 0.1 | +2.9 | 0.0 | 13.0 |
| MOVE SPELL OUT OF RANGE | 0.8 | -13.1 | 0.0 | 16.1 | 0.3 | -12.4 | 3.4 | 38.7 |
| MOVE SPELL SPOT | 0.2 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 4.9 | +611.1 | 0.0 | 74.6 | 3.9 | +533.5 | 0.0 | 65.1 |
| MOVES UNITS SPELL | 0.1 | +3.4 | 0.0 | 0.0 | 0.1 | +0.3 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 4.1 | +176.8 | 0.0 | 83.5 | 3.8 | +208.2 | 0.0 | 53.1 |
| NEEDED THERE | 0.0 | +7.2 | 1.7 | 0.0 | 0.1 | +20.2 | 3.3 | 0.0 |
| NEXT CHARGE BY LIST | 6.1 | -227.7 | 20.4 | 125.3 | 5.1 | -165.5 | 0.0 | 130.2 |
| NEXT OBJECTIVE NEARER | 6.3 | -210.7 | 88.0 | 144.6 | 7.7 | -368.0 | 16.9 | 102.4 |
| NO DOUBLE ROUNDS | 2.5 | -104.4 | 254.0 | 46.7 | 3.3 | -143.8 | 255.9 | 89.4 |
| NOT TURNED | 0.1 | +0.0 | 0.0 | 3.3 | 0.4 | +1.3 | 0.0 | 17.8 |
| NOT WORTH A CAST | 0.9 | -3.1 | 0.0 | 15.4 | 0.6 | -0.5 | 0.0 | 6.5 |
| OFF BEST | 0.5 | -8.3 | 0.0 | 0.0 | 1.1 | -38.7 | 0.0 | 17.1 |
| ONE CHARGE A CHARGER | 2.5 | +0.0 | 0.0 | 63.4 | 3.5 | +0.0 | 0.0 | 90.6 |
| ONE FIGHT FORMULA | 6.0 | -121.0 | 0.0 | 150.8 | 5.4 | -130.2 | 0.0 | 121.3 |
| ONE OBJECTIVE FORMULA | 4.9 | -21.2 | 0.0 | 90.4 | 3.2 | -19.7 | 0.0 | 37.3 |
| ONE TARGET A SHOOTER | 12.4 | +238.3 | 0.0 | 207.4 | 18.4 | +558.7 | 0.0 | 350.1 |
| OPENS A LANE | 0.1 | +0.7 | 1.0 | 0.0 | 0.0 | +0.6 | 0.0 | 0.0 |
| OPENS UP | 0.2 | +23.3 | 9.1 | 0.0 | 0.1 | +8.7 | 4.2 | 0.0 |
| OVERRUNS AWAY | 0.4 | +22.8 | 18.0 | 0.0 | 0.4 | +12.3 | 29.2 | 19.8 |
| PATHS CROSS | 3.3 | +164.4 | 0.0 | 37.9 | 4.1 | +197.5 | 0.0 | 50.7 |
| PERIAPT WORTH | 0.1 | +3.0 | 0.0 | 0.0 | 0.1 | +7.0 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.1 | -0.4 | 0.0 | 0.0 | 0.1 | -1.1 | 0.0 | 3.2 |
| PLAN RESULT | 41.0 | +1135.7 | 802.0 | 831.6 | 39.5 | +496.0 | 270.6 | 1043.5 |
| PURSUES BIG PREY | 0.1 | -9.0 | 0.0 | 12.3 | 0.1 | -3.6 | 0.0 | 11.1 |
| RANDOM MOVE BY FIGURES | 0.6 | +9.1 | 0.0 | 34.3 | 2.3 | +50.5 | 0.0 | 64.9 |
| REDIRECT BY WHAT IT STOPS | 0.2 | -0.5 | 0.0 | 4.6 | 0.5 | -14.6 | 0.0 | 18.6 |
| REDIRECT COUNTER | 1.9 | +150.6 | 0.0 | 41.8 | 3.7 | +348.9 | 0.0 | 62.8 |
| REDIRECT WEIGHED | 0.1 | +1.7 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| REFORMS TO MEET IT | 1.1 | -53.9 | 0.0 | 17.2 | 0.7 | -49.9 | 0.0 | 0.0 |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | 0.3 | +7.2 | 0.0 | 7.3 | 0.5 | +31.6 | 0.0 | 7.8 |
| RESTRAINS TO SHOOT | 0.1 | +5.5 | 0.0 | 5.2 | - | - | - | - |
| RISK BY ARC | 2.5 | +46.3 | 225.9 | 45.8 | 2.4 | +29.3 | 190.0 | 82.7 |
| RISK BY HIS FIGURE | 12.4 | -195.0 | 0.0 | 282.4 | 13.0 | -278.7 | 0.0 | 328.3 |
| RUN DOWN | 1.6 | -21.8 | 139.8 | 19.6 | 2.7 | -28.7 | 204.2 | 61.6 |
| SAFER THAN THE JOB | - | - | - | - | 0.0 | +3.2 | 0.0 | 5.9 |
| SAME CHARGE LATER | 0.3 | -4.4 | 4.9 | 0.0 | 0.0 | -0.0 | 0.0 | 0.0 |
| SCOUT SPOT | 0.3 | +0.8 | 0.0 | 0.0 | 0.2 | +0.8 | 0.0 | 1.8 |
| SCOUT WAITS | 0.4 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 1.8 |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 0.1 | -7.3 | 0.0 | 0.0 |
| SEARCH SPOT | 5.6 | +201.0 | 0.0 | 58.2 | 5.9 | +216.9 | 0.0 | 107.1 |
| SELF MOVE SPELL | 0.2 | +3.9 | 0.0 | 0.0 | 0.3 | +31.4 | 0.0 | 0.0 |
| SET UP TOGETHER | 0.3 | +11.4 | 0.0 | 11.1 | 0.7 | +15.2 | 0.0 | 7.9 |
| SET-UP ANY TARGET | 0.1 | +12.3 | 0.0 | 0.0 | 0.1 | +12.9 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.4 | +0.8 | 0.0 | 0.0 | 0.2 | +0.5 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.5 | +64.8 | 46.0 | 14.9 | 0.6 | +18.9 | 12.6 | 4.0 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| SHOT OR CHARGE | 0.4 | -9.7 | 39.4 | 4.6 | 0.2 | -3.3 | 1.5 | 2.5 |
| SHOT RISK POINTS | 6.4 | -59.0 | 0.0 | 139.5 | 11.0 | -27.4 | 0.0 | 307.6 |
| SHOTS IN THE MOVE | 16.3 | +668.0 | 0.0 | 279.5 | 8.6 | +229.3 | 0.0 | 136.3 |
| SPELL SETS UP CHARGE | 0.2 | +17.7 | 0.0 | 0.0 | 0.1 | +12.9 | 0.0 | 0.0 |
| SPELL WORTH | 1.2 | +12.5 | 46.1 | 34.3 | 1.7 | +35.3 | 95.6 | 102.1 |
| SPELLS IN THE FIGHT | 0.6 | +6.6 | 93.6 | 31.2 | 0.6 | -4.0 | 29.7 | 18.8 |
| STAND AND SHOOT | 0.4 | -3.9 | 24.8 | 0.0 | 0.7 | -8.2 | 48.7 | 18.8 |
| STANDS FOR A REASON | 0.1 | +0.0 | 0.0 | 2.1 | 0.4 | +0.0 | 0.0 | 9.4 |
| STANDS STILL | 17.6 | +0.0 | 954.0 | 275.6 | 9.8 | +0.0 | 122.4 | 99.1 |
| STANDS TO CAST | 0.0 | +1.4 | 0.0 | 0.0 | - | - | - | - |
| STAY WORTH | 19.1 | +104.2 | 681.2 | 286.7 | 8.4 | +30.8 | 60.5 | 83.2 |
| STOPS | - | - | - | - | 0.1 | +9.4 | 6.9 | 4.4 |
| STUCK PIVOT | 0.0 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 10.6 |
| SUPPORT NARROWED | 1.4 | +0.0 | 118.9 | 8.2 | 1.2 | +0.0 | 67.5 | 18.5 |
| SURE REACH TOGETHER | 0.2 | +5.0 | 0.0 | 2.9 | 0.6 | +10.2 | 0.0 | 8.9 |
| THE DEARER SUM KEEPS ITS PLAN | 3.9 | +0.0 | 0.0 | 56.0 | 3.8 | +0.0 | 0.0 | 53.3 |
| THE PROMISE ADDS | 0.3 | -14.7 | 0.0 | 0.0 | 0.2 | -13.7 | 0.0 | 5.4 |
| THE PROMISED MOVE | 1.2 | +0.0 | 0.0 | 34.8 | 0.4 | +0.0 | 0.0 | 3.2 |
| TIED UP BY THE SUM | 0.8 | +91.5 | 68.9 | 4.2 | 0.6 | +63.6 | 53.6 | 17.0 |
| TIME ON OUR SIDE | 27.5 | +419.5 | 16.4 | 387.3 | 6.9 | +83.9 | 0.0 | 76.8 |
| TWO OR MORE ARRIVE | 0.0 | +0.0 | 0.0 | 11.1 | - | - | - | - |
| WAITS AGAIN | 2.0 | +0.0 | 0.0 | 35.4 | 0.9 | +0.0 | 0.0 | 24.2 |
| WAR ENGINE CHARGES | 0.1 | +8.0 | 0.0 | 13.8 | 0.1 | +5.5 | 0.0 | 0.0 |
| WAR ENGINE JOBS | 0.3 | +0.0 | 25.7 | 4.2 | - | - | - | - |
| WHO HITS BACK | 0.3 | +51.9 | 0.0 | 1.7 | 0.3 | +56.6 | 0.0 | 7.0 |
| WHOLE FIGHT | 0.4 | +0.4 | 43.7 | 0.0 | 0.3 | +2.5 | 9.4 | 4.0 |
| WHOLE FIGHT GAIN | 0.1 | +5.1 | 23.5 | 1.5 | 0.2 | +9.1 | 17.9 | 9.6 |
| WIDER SPREAD | 2.1 | -6.0 | 215.2 | 44.1 | 2.5 | -7.5 | 183.0 | 57.2 |
| WOUNDS ON THE RANKS | 1.1 | +45.9 | 0.0 | 39.6 | 1.0 | +54.1 | 0.0 | 32.5 |

### Rule changes: h3-mine-efe7e34-p1

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| LEGAL CHARGES ONLY | 429 | 429 | 429 | 11.92 | +0 | +0.0 |
| HOLDER ASSIGNMENT | 453 | 453 | 413 | 11.47 | +21671 | +52.5 |
| SEARCH SPOT | 414 | 414 | 388 | 10.78 | +15073 | +38.8 |
| DEPLOY BY FIGURES | 564 | 564 | 349 | 9.69 | +5626 | +16.1 |
| HIS SHOT LIST | 1247 | 1247 | 349 | 9.69 | +8716 | +25.0 |
| FIVE ACTION | 3204 | 3201 | 336 | 9.33 | +13774 | +41.0 |
| PATHS CROSS | 266 | 266 | 266 | 7.39 | +13030 | +49.0 |
| ONE TARGET A SHOOTER | 1110 | 1110 | 264 | 7.33 | +3333 | +12.6 |
| TIME ON OUR SIDE | 1238 | 1105 | 239 | 6.64 | +547 | +2.3 |
| MOVE TO CHARGE COMPUTED | 320 | 320 | 204 | 5.67 | +16847 | +82.6 |
| FOUR ROUNDS | 272 | 269 | 147 | 4.08 | +8368 | +56.9 |
| SHOT RISK POINTS | 626 | 626 | 108 | 3.00 | +3596 | +33.3 |
| MAX FOR POSITIONING | 390 | 383 | 96 | 2.67 | +322 | +3.4 |
| COVER ONCE | 438 | 359 | 94 | 2.61 | +1848 | +19.7 |
| ADVANCE LANE KEPT | 74 | 74 | 74 | 2.06 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 74 | 74 | 74 | 2.06 | +13842 | +187.1 |
| HARD STAY DROPPED | 74 | 74 | 74 | 2.06 | +0 | +0.0 |
| SHOTS IN THE MOVE | 896 | 861 | 74 | 2.06 | +3134 | +42.4 |
| SHOOTS FROM THE BEST SPOT | 76 | 76 | 61 | 1.69 | +1068 | +17.5 |
| MARCH CHECK | 88 | 88 | 58 | 1.61 | +1208 | +20.8 |
| RANDOM MOVE BY FIGURES | 106 | 106 | 58 | 1.61 | +2145 | +37.0 |
| ARTILLERY RE-ROLL WEIGHED | 56 | 56 | 56 | 1.56 | +0 | +0.0 |
| OFF BEST | 55 | 55 | 55 | 1.53 | -1689 | -30.7 |
| LANE BY FIGURES | 53 | 53 | 53 | 1.47 | +2355 | +44.4 |
| IDLE COST | 490 | 378 | 52 | 1.44 | +406 | +7.8 |
| NEXT CHARGE BY LIST | 403 | 403 | 52 | 1.44 | +1258 | +24.2 |
| NEXT OBJECTIVE NEARER | 506 | 506 | 52 | 1.44 | +564 | +10.8 |
| MANOEUVRE | 81 | 81 | 51 | 1.42 | +1537 | +30.1 |
| CANNON PLANNED TARGET | 283 | 283 | 49 | 1.36 | -318 | -6.5 |
| CHARGE LOSSES | 428 | 428 | 49 | 1.36 | +4162 | +84.9 |
| RISK BY ARC | 177 | 175 | 48 | 1.33 | +1252 | +26.1 |
| REDIRECT COUNTER | 201 | 166 | 45 | 1.25 | +3967 | +88.2 |
| CHARGE NOT DECLARED | 44 | 44 | 44 | 1.22 | -5110 | -116.1 |
| FALLS SHORT | 780 | 679 | 44 | 1.22 | +269 | +6.1 |
| MISSILES IN THE MOVE | 275 | 221 | 43 | 1.19 | +1058 | +24.6 |
| RISK BY HIS FIGURE | 916 | 916 | 40 | 1.11 | +4274 | +106.9 |
| CANNON SIGHT KEPT | 38 | 38 | 38 | 1.06 | +0 | +0.0 |
| CHARGE NOW FIRST | 136 | 136 | 38 | 1.06 | -2094 | -55.1 |
| TIED UP BY THE SUM | 52 | 51 | 38 | 1.06 | +1068 | +28.1 |
| HOLDS AMBUSHERS | 36 | 36 | 36 | 1.00 | +0 | +0.0 |
| HIS TURN DENIED | 123 | 121 | 35 | 0.97 | +1579 | +45.1 |
| COMBAT PIVOT | 30 | 30 | 30 | 0.83 | +0 | +0.0 |
| HOLDER AT DEPLOYMENT | 54 | 54 | 29 | 0.81 | +1349 | +46.5 |
| RESERVE FALL BACK | 29 | 29 | 29 | 0.81 | +1397 | +48.2 |
| LONE WIZARD KEPT IN | 28 | 28 | 28 | 0.78 | +1895 | +67.7 |
| MARCH BY THE SUM | 25 | 25 | 25 | 0.69 | +1027 | +41.1 |
| FIGHT TO THE END | 108 | 106 | 24 | 0.67 | +674 | +28.1 |
| ONE OBJECTIVE FORMULA | 291 | 259 | 23 | 0.64 | +710 | +30.9 |
| WHO HITS BACK | 23 | 23 | 23 | 0.64 | +2969 | +129.1 |
| SHOOTERS IN TWO RANKS | 21 | 21 | 21 | 0.58 | +47 | +2.2 |
| SCOUT WAITS | 20 | 20 | 20 | 0.56 | +0 | +0.0 |
| STAY WORTH | 990 | 951 | 20 | 0.56 | +264 | +13.2 |
| CASTS FROM BEHIND | 19 | 19 | 19 | 0.53 | +0 | +0.0 |
| CHAFF IN THE MOVE | 34 | 30 | 19 | 0.53 | +95 | +5.0 |
| SUPPORT NARROWED | 93 | 93 | 18 | 0.50 | -430 | -23.9 |
| CAST JOB | 26 | 26 | 17 | 0.47 | +192 | +11.3 |
| ONE FIGHT FORMULA | 408 | 222 | 17 | 0.47 | +114 | +6.7 |
| MODEL FACING | 16 | 16 | 16 | 0.44 | +3788 | +236.8 |
| SURE REACH TOGETHER | 30 | 30 | 16 | 0.44 | +104 | +6.5 |
| CHAFF PASSED | 15 | 15 | 15 | 0.42 | -12 | -0.8 |
| NEARER NOT NEEDED | 285 | 272 | 15 | 0.42 | +456 | +30.4 |
| WOUNDS ON THE RANKS | 77 | 77 | 15 | 0.42 | +812 | +54.1 |
| STUCK PIVOT | 14 | 14 | 14 | 0.39 | +0 | +0.0 |
| FIRE IN ORDER | 13 | 13 | 13 | 0.36 | +0 | +0.0 |
| AFTERMATH IN POINTS | 11 | 11 | 11 | 0.31 | +672 | +61.1 |
| OVERRUNS AWAY | 28 | 28 | 11 | 0.31 | +199 | +18.1 |
| CASTER AWAY FROM SCREEN | 10 | 10 | 10 | 0.28 | +0 | +0.0 |
| PURSUES BIG PREY | 10 | 10 | 10 | 0.28 | -456 | -45.6 |
| REFUSING RETIRES | 16 | 16 | 10 | 0.28 | -5 | -0.5 |
| SHORT GUN FORWARD | 10 | 10 | 10 | 0.28 | +0 | +0.0 |
| FEATURE BUFFS | 46 | 46 | 9 | 0.25 | +76 | +8.5 |
| FALLBACK BY WORTH | 30 | 30 | 8 | 0.22 | +263 | +32.9 |
| MISSILES NEXT TURN | 340 | 250 | 8 | 0.22 | +68 | +8.5 |
| WHOLE FIGHT GAIN | 12 | 12 | 8 | 0.22 | +122 | +15.2 |
| GUN MASK | 32 | 32 | 7 | 0.19 | +216 | +30.9 |
| REDIRECT WEIGHED | 7 | 7 | 7 | 0.19 | +281 | +40.1 |
| FALL BACK GOOD ORDER | 184 | 182 | 6 | 0.17 | +66 | +11.0 |
| FRIENDS SHOTS CHECKED | 6 | 6 | 6 | 0.17 | +171 | +28.6 |
| HIS CHARGE DENIED | 23 | 23 | 6 | 0.17 | +212 | +35.4 |
| HONEST WORTH | 234 | 233 | 6 | 0.17 | +152 | +25.3 |
| MOVES UNITS SPELL | 6 | 6 | 6 | 0.17 | +133 | +22.2 |
| PERIAPT WORTH | 5 | 5 | 5 | 0.14 | +361 | +72.2 |
| PIVOT GUARDS FLANK | 5 | 5 | 5 | 0.14 | -52 | -10.4 |
| WAR ENGINE JOBS | 12 | 12 | 5 | 0.14 | -462 | -92.4 |
| CARRIES OUT SET-UP | 5 | 5 | 4 | 0.11 | -394 | -98.4 |
| CASTING BLOCK | 6 | 6 | 4 | 0.11 | +521 | +130.2 |
| CONTINUE AHEAD WEIGHED | 4 | 4 | 4 | 0.11 | +0 | +0.0 |
| EDGE GIVE GROUND | 14 | 13 | 4 | 0.11 | +35 | +8.8 |
| HIS MOVE AND SHOT | 123 | 123 | 4 | 0.11 | +29 | +7.2 |
| HUNT IN PAIRS | 19 | 11 | 4 | 0.11 | +27 | +6.7 |
| NO DOUBLE ROUNDS | 208 | 205 | 4 | 0.11 | +76 | +19.1 |
| OPENS UP | 11 | 11 | 4 | 0.11 | +196 | +49.1 |
| SPELLS IN THE FIGHT | 41 | 40 | 4 | 0.11 | +72 | +17.9 |
| WHOLE FIGHT | 23 | 22 | 4 | 0.11 | +6 | +1.4 |
| WIDER SPREAD | 165 | 163 | 4 | 0.11 | +11 | +2.8 |
| BOMBING RUN | 3 | 3 | 3 | 0.08 | +96 | +32.1 |
| KEEP FALLS | 3 | 3 | 3 | 0.08 | +191 | +63.7 |
| KEEPS SCOUTS OR AMBUSH | 3 | 3 | 3 | 0.08 | +0 | +0.0 |
| KILLS COUNT | 3 | 3 | 3 | 0.08 | +0 | +0.0 |
| LONG SHOT | 18 | 18 | 3 | 0.08 | +17 | +5.8 |
| NEEDED THERE | 3 | 3 | 3 | 0.08 | +0 | +0.0 |
| RESTRAINS TO SHOOT | 3 | 3 | 3 | 0.08 | +197 | +65.6 |
| SAME CHARGE LATER | 12 | 12 | 3 | 0.08 | +3 | +0.9 |
| SET UP TOGETHER | 34 | 26 | 3 | 0.08 | +119 | +39.5 |
| FACES THE THREAT | 2 | 2 | 2 | 0.06 | +274 | +137.1 |
| SHOT OR CHARGE | 19 | 19 | 2 | 0.06 | +0 | +0.0 |
| THE PROMISE ADDS | 16 | 16 | 2 | 0.06 | +5 | +2.7 |
| BEST PRIZE | 1 | 1 | 1 | 0.03 | -30 | -29.5 |
| BLOWS WHERE AIMED | 17 | 17 | 1 | 0.03 | +15 | +15.3 |
| BOUND ASSAILMENT | 1 | 1 | 1 | 0.03 | +0 | +0.2 |
| CARRIES OUT COUNTER | 3 | 3 | 1 | 0.03 | +0 | +0.0 |
| FIRE AND FLEE | 1 | 1 | 1 | 0.03 | +3 | +3.2 |
| OPENS A LANE | 5 | 2 | 1 | 0.03 | +20 | +20.2 |
| REFORMS TO MEET IT | 63 | 63 | 1 | 0.03 | +2 | +2.0 |
| SAFER THAN THE JOB | 1 | 1 | 1 | 0.03 | +116 | +116.5 |
| STANDS TO CAST | 1 | 1 | 1 | 0.03 | -42 | -42.2 |
| STOPS | 5 | 5 | 1 | 0.03 | +51 | +50.7 |
| WAR ENGINE CHARGES | 4 | 4 | 1 | 0.03 | +2 | +2.4 |
| ALREADY CARRIED | 2 | not checked | - | - | - | - |
| ARRIVAL HUNT | 3 | 3 | 0 | 0.00 | - | - |
| BACKUP TARGETS | 17 | 8 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 36 | 36 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 35 | trace | - | - | - | - |
| CATCH FLIERS | 1 | not checked | - | - | - | - |
| CHARACTER GUNS | 30 | 30 | 0 | 0.00 | - | - |
| CHARGER SLAIN LOST | 21 | 21 | 0 | 0.00 | - | - |
| CHEAP HELPER | 3 | not checked | - | - | - | - |
| CHEAPEST HOLDER | 5 | 5 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 33 | not checked | - | - | - | - |
| DEFENSIVE ARMY | 2 | 2 | 0 | 0.00 | - | - |
| DEFENSIVE FLOOR | 1 | 1 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 6 | 6 | 0 | 0.00 | - | - |
| FIGHT LIFT | 4 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 417 | not checked | - | - | - | - |
| FRIEND CHARGES FIRST | 10 | 10 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 26 | 26 | 0 | 0.00 | - | - |
| GIVES UP | 15 | 14 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 2 | 2 | 0 | 0.00 | - | - |
| GROUND FLIERS | 3 | not checked | - | - | - | - |
| GUN FIGURES | 70 | not checked | - | - | - | - |
| HE SHOOTS OR CHARGES | 123 | 123 | 0 | 0.00 | - | - |
| HELPER ALREADY ASKED | 1 | not checked | - | - | - | - |
| HELPER UNSEEN | 5 | 5 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 153 | 153 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 272 | 272 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 157 | 157 | 0 | 0.00 | - | - |
| HOLD ODDS | 246 | 246 | 0 | 0.00 | - | - |
| HUNT DROPPED | 2 | trace | - | - | - | - |
| HUNT RESULT | 5 | trace | - | - | - | - |
| HUNT THE GUNS | 5 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 5 | 5 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 5 | not checked | - | - | - | - |
| LOST CHARGE | 4 | 4 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 3 | 3 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 17 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 10 | trace | - | - | - | - |
| MARCH OVER CASTS | 60 | 60 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 12 | 8 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 39 | trace | - | - | - | - |
| MOVE SPELL SPOT | 15 | not checked | - | - | - | - |
| NOT TURNED | 21 | 21 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 55 | not checked | - | - | - | - |
| ONE CHARGE A CHARGER | 216 | 216 | 0 | 0.00 | - | - |
| PLAN RESULT | 2897 | trace | - | - | - | - |
| REDIRECT BY WHAT IT STOPS | 25 | 25 | 0 | 0.00 | - | - |
| RUN DOWN | 154 | 152 | 0 | 0.00 | - | - |
| SCOUT SPOT | 18 | 18 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 5 | 5 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 18 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 8 | not checked | - | - | - | - |
| SPELL SETS UP CHARGE | 9 | not checked | - | - | - | - |
| SPELL WORTH | 104 | not checked | - | - | - | - |
| STAND AND SHOOT | 40 | 40 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 18 | 18 | 0 | 0.00 | - | - |
| STANDS STILL | 988 | 988 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 277 | not checked | - | - | - | - |
| THE PROMISED MOVE | 57 | not checked | - | - | - | - |
| TWO OR MORE ARRIVE | 1 | not checked | - | - | - | - |
| WAITS AGAIN | 104 | 104 | 0 | 0.00 | - | - |

### Off best figure: h3-mine-efe7e34-p1

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| HOLDER ASSIGNMENT | rule | 1.28 | - | 20.9 |
| CHARGE NOT DECLARED | rule | 0.56 | 0.53 | 131.0 |
| PATHS CROSS | rule | 0.39 | 0.67 | 24.9 |
| CHARGE NOW FIRST | rule | 0.56 | 0.47 | 56.6 |
| JOB FIRST | gate | 0.17 | 0.81 | 36.5 |
| SUPPORT NARROWED | rule | 0.33 | 0.17 | 23.9 |
| PURSUES BIG PREY | rule | 0.14 | 0.14 | 45.6 |
| CANNON PLANNED TARGET | rule | 0.19 | - | 65.2 |
| AFTERMATH BAND | gate | 0.03 | 0.11 | 3.1 |
| DEPLOY BY FIGURES | rule | 0.08 | 0.06 | 4.4 |
| PIVOT GUARDS FLANK | rule | 0.06 | 0.08 | 10.4 |
| FIGHT ORDER BAND | gate | 0.11 | - | 1.9 |
| REFUSING RETIRES | rule | 0.08 | 0.03 | 0.8 |
| WAR ENGINE JOBS | rule | 0.11 | - | 115.5 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.06 | 0.03 | 18.2 |
| CARRIES OUT SET-UP | rule | 0.03 | 0.06 | 131.2 |
| CHAFF PASSED | rule | 0.03 | 0.06 | 3.7 |
| FALLBACK | gate | 0.03 | 0.06 | 35.4 |
| NO REASON | gate | 0.08 | - | 66.4 |
| WHO HITS BACK | rule | - | 0.06 | 2.8 |
| BEST PRIZE | rule | - | 0.03 | 29.5 |
| LONE CHARACTER SAFE SPOT | gate | - | 0.03 | 0.8 |
| RULE SWITCHED OFF | gate | - | 0.03 | 27.5 |
| STANDS TO CAST | rule | 0.03 | - | 42.2 |

### Plans: h3-mine-efe7e34-p1

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 2.8 | 63% | 383 | 281 | 73% |
| Mine | join | 0.6 | 100% | 20 | 0 | 0% |
| Mine | move | 27.4 | 94% | 1801 | 0 | 0% |
| Mine | shoot | 10.1 | 61% | 447 | 855 | 191% |
| Mine | support | 0.1 | 80% | 2 | 0 | 0% |
| Opponent | charge | 3.4 | 65% | 592 | 300 | 51% |
| Opponent | join | 1.4 | 94% | 68 | 0 | 0% |
| Opponent | move | 30.8 | 92% | 1566 | 0 | 0% |
| Opponent | shoot | 3.2 | 51% | 117 | 196 | 167% |
| Opponent | support | 0.7 | 79% | 2 | 0 | 0% |

### Packages: hunt the guns, h3-mine-efe7e34-p1

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 19 |
| Opponent | 0.1 | 5 | 0 | 40% | 40% | 0% | 2.0 | 336 | 124 | 40% | 104 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 171 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 21 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| High Elf Realms | 0.2 | 1 | 0 | 100% | 100% | 0% | 2.0 | 412 | 355 | 100% | 142 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 117 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 29 |
| Tomb Kings of Khemri | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 130 |
| Vampire Counts | 0.2 | 3 | 0 | 33% | 33% | 0% | 2.0 | 339 | 88 | 33% | 34 |
| Warriors of Chaos | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 96 |
| Wood Elf Realms | 0.3 | 1 | 0 | 0% | 0% | 0% | - | 253 | 0 | 0% | 42 |

### Battle groups: h3-mine-efe7e34-p1

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 1.9 | 29% | 65% | 20% | 25% | 19% | 6% | 12% | 62% | 0% |
| Opponent | REDIRECT COUNTER | 3.7 | 20% | 93% | 15% | 0% | 17% | 0% | 4% | 52% | 26% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: h3-mine-efe7e34-p1

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 6 | 0 (6) | 0 | 0 | 64 | 17% | 3.2 | 0 (1) | 0 (2) | - | 0 (1) | 0 (2) |
| Mine | Chaff | 34 | 74 (34) | 10 | 64 | 57 | 29% | 3.0 | 59 (8) | 55 (13) | 99 (13) | 81 (27) | 47 (7) |
| Mine | Character | 117 | 43 (117) | 43 | 0 | 23 | 24% | 2.4 | 58 (61) | 29 (33) | 28 (15) | 53 (78) | 28 (31) |
| Mine | Clean-up | 26 | 85 (26) | 19 | 65 | 24 | 23% | 3.5 | 85 (11) | 92 (13) | 54 (2) | 91 (20) | 68 (6) |
| Mine | Fast | 3 | 0 (3) | 0 | 0 | 33 | 0% | 1.7 | - | 0 (1) | 0 (2) | 0 (2) | 0 (1) |
| Mine | Fast Hammer | 41 | 57 (41) | 29 | 28 | 42 | 27% | 3.0 | 62 (12) | 63 (23) | 17 (6) | 63 (23) | 45 (18) |
| Mine | Fragile | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | - | - | - | - |
| Mine | Hammer | 54 | 34 (54) | 20 | 14 | 33 | 26% | 2.2 | 60 (11) | 39 (24) | 8 (19) | 44 (33) | 17 (21) |
| Mine | Holder | 23 | 97 (23) | 4 | 92 | 7 | 48% | 2.5 | 92 (4) | 125 (14) | 8 (4) | 131 (13) | 55 (9) |
| Mine | Shooter | 43 | 114 (43) | 50 | 64 | 34 | 5% | 1.8 | 123 (11) | 133 (23) | 59 (9) | 152 (30) | 34 (13) |
| Mine | Support | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | 0 (1) | - | - | - | 0 (1) |
| Mine | War machine | 60 | 52 (60) | 52 | 0 | 47 | 5% | 1.3 | 45 (33) | 63 (18) | 56 (9) | 57 (9) | 51 (51) |
| Mine | Wizard | 24 | 25 (24) | 25 | 0 | 21 | 8% | 3.0 | 43 (10) | 0 (4) | 0 (6) | 41 (11) | 12 (9) |
| Opponent | Chaff | 67 | 71 (67) | 12 | 59 | 61 | 34% | 3.1 | 50 (21) | 124 (21) | 31 (25) | 86 (48) | 35 (19) |
| Opponent | Character | 106 | 47 (106) | 46 | 1 | 31 | 28% | 2.4 | 57 (34) | 44 (47) | 47 (19) | 52 (59) | 45 (41) |
| Opponent | Clean-up | 23 | 37 (23) | 5 | 32 | 47 | 39% | 3.6 | 12 (5) | 49 (15) | 18 (3) | 61 (15) | 7 (8) |
| Opponent | Early | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | - | 0 (1) | - | 0 (1) |
| Opponent | Fast | 2 | 0 (2) | 0 | 0 | 100 | 50% | 2.0 | 0 (1) | 0 (1) | - | 0 (2) | - |
| Opponent | Fast Hammer | 47 | 35 (47) | 15 | 20 | 43 | 30% | 3.1 | 64 (14) | 22 (25) | 32 (8) | 36 (27) | 33 (20) |
| Opponent | Fragile | 2 | 0 (2) | 0 | 0 | 0 | 50% | 1.0 | 0 (1) | - | 0 (1) | 0 (1) | 0 (1) |
| Opponent | Hammer | 54 | 29 (54) | 17 | 12 | 37 | 30% | 2.9 | 38 (12) | 25 (31) | 33 (11) | 24 (36) | 37 (18) |
| Opponent | Holder | 42 | 103 (42) | 17 | 85 | 29 | 48% | 3.5 | 135 (19) | 104 (14) | 56 (9) | 131 (22) | 72 (20) |
| Opponent | Shooter | 26 | 78 (26) | 39 | 39 | 36 | 8% | 1.5 | 108 (4) | 70 (18) | 93 (4) | 113 (10) | 60 (16) |
| Opponent | Support | 2 | 0 (2) | 0 | 0 | 100 | 50% | 5.0 | - | 0 (1) | 0 (1) | - | 0 (2) |
| Opponent | War machine | 16 | 37 (16) | 37 | 0 | 12 | 6% | 1.9 | 0 (2) | 0 (4) | 59 (10) | 40 (3) | 36 (13) |
| Opponent | Wizard | 24 | 4 (24) | 4 | 0 | 39 | 8% | 2.1 | 0 (5) | 2 (8) | 11 (7) | 10 (8) | 1 (12) |

### Charged fights: h3-mine-efe7e34-p1

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 341 | 47 | 1.2 | 1.4 | 38 | 21 | +17 | 2 of 5 | 3 of 5 | +94 | -35 |
| Mine | Chaos Dwarfs | 4 | 372 | 176 | 1.8 | 1.0 | 100 | 0 | +100 | 4 of 7 | 5 of 7 | - | +100 |
| Mine | Dwarfen Mountain Holds | 4 | 764 | 133 | 1.0 | 1.0 | 133 | 0 | +133 | 0 of 4 | 4 of 4 | - | +133 |
| Mine | Empire of Man | 5 | 256 | 173 | 1.8 | 1.0 | 96 | 34 | +62 | 3 of 9 | 6 of 9 | - | +62 |
| Mine | Grand Cathay | 4 | 388 | 535 | 4.2 | 1.0 | 126 | 10 | +116 | 5 of 17 | 15 of 17 | - | +116 |
| Mine | High Elf Realms | 4 | 153 | 704 | 3.2 | 1.3 | 217 | 11 | +206 | 7 of 13 | 10 of 13 | +553 | +51 |
| Mine | Kingdom of Bretonnia | 1 | 0 | 549 | 6.0 | 1.0 | 92 | 0 | +92 | 1 of 6 | 6 of 6 | - | +92 |
| Mine | Lizardmen | 1 | 0 | 315 | 4.0 | 1.0 | 79 | 70 | +8 | 1 of 4 | 3 of 4 | - | +8 |
| Mine | Ogre Kingdoms | 1 | 0 | 453 | 6.0 | 1.0 | 76 | 0 | +76 | 2 of 6 | 3 of 6 | - | +76 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 405 | 5.0 | 1.0 | 81 | 0 | +81 | 2 of 5 | 4 of 5 | - | +81 |
| Mine | Skaven | 2 | 0 | 93 | 2.0 | 1.0 | 46 | 72 | -25 | 1 of 4 | 3 of 4 | - | -25 |
| Mine | Tomb Kings of Khemri | 1 | 250 | 1349 | 3.0 | 1.7 | 450 | 0 | +450 | 1 of 3 | 2 of 3 | +608 | +370 |
| Mine | Vampire Counts | 3 | 0 | 173 | 5.7 | 1.1 | 30 | 4 | +27 | 10 of 17 | 12 of 17 | +0 | +29 |
| Mine | Warriors of Chaos | 1 | 0 | 260 | 3.0 | 1.0 | 87 | 0 | +87 | 1 of 3 | 2 of 3 | - | +87 |
| **Mine** | all armies | 36 | 267 | 313 | 2.9 | 1.1 | 110 | 13 | +96 | 40 of 103 | 78 of 103 | +376 | +73 |
| Opponent | Chaos Dwarfs | 3 | 64 | 152 | 3.0 | 1.1 | 51 | 13 | +37 | 5 of 9 | 5 of 9 | +0 | +42 |
| Opponent | Dwarfen Mountain Holds | 1 | 890 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Grand Cathay | 1 | 0 | 975 | 4.0 | 1.2 | 244 | 32 | +212 | 3 of 4 | 3 of 4 | -126 | +325 |
| Opponent | High Elf Realms | 2 | 192 | 844 | 4.5 | 1.3 | 188 | 17 | +171 | 5 of 9 | 9 of 9 | +18 | +215 |
| Opponent | Kingdom of Bretonnia | 1 | 0 | 150 | 2.0 | 1.0 | 75 | 0 | +75 | 1 of 2 | 1 of 2 | - | +75 |
| Opponent | Ogre Kingdoms | 1 | 250 | 77 | 2.0 | 1.0 | 38 | 114 | -76 | 0 of 2 | 1 of 2 | - | -76 |
| Opponent | Orc & Goblin Tribes | 1 | 0 | 450 | 5.0 | 1.0 | 90 | 0 | +90 | 0 of 5 | 5 of 5 | - | +90 |
| Opponent | Skaven | 3 | 299 | 0 | 0.7 | 1.0 | 0 | 0 | +0 | 1 of 2 | 1 of 2 | - | +0 |
| Opponent | Tomb Kings of Khemri | 2 | 68 | 217 | 3.5 | 1.0 | 62 | 0 | +62 | 4 of 7 | 7 of 7 | - | +62 |
| Opponent | Vampire Counts | 9 | 28 | 410 | 4.8 | 1.1 | 86 | 17 | +69 | 14 of 43 | 36 of 43 | +59 | +70 |
| Opponent | Warriors of Chaos | 9 | 33 | 374 | 2.8 | 1.0 | 135 | 5 | +130 | 7 of 25 | 22 of 25 | +0 | +136 |
| Opponent | Wood Elf Realms | 3 | 149 | 154 | 3.7 | 1.0 | 42 | 30 | +13 | 4 of 11 | 6 of 11 | - | +13 |
| **Opponent** | all armies | 36 | 104 | 326 | 3.3 | 1.1 | 99 | 15 | +84 | 44 of 119 | 96 of 119 | +20 | +90 |

### Effective charges: h3-mine-efe7e34-p1

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 5 | 3 (net -35) | 0 | 0 | 2 (net +94) | 0 | 0 | 0 | 0% (0 of 5) |
| Mine | Chaos Dwarfs | 7 | 0 | 0 | 2 (net +48) | 2 (net +113) | 0 | 3 (net +127) | 0 | 29% (2 of 7) |
| Mine | Dwarfen Mountain Holds | 4 | 1 (net +162) | 0 | 1 (net +98) | 0 | 0 | 2 (net +136) | 0 | 25% (1 of 4) |
| Mine | Empire of Man | 9 | 2 (net -152) | 0 | 1 (net +0) | 4 (net +170) | 0 | 2 (net +92) | 0 | 11% (1 of 9) |
| Mine | Grand Cathay | 17 | 3 (net +174) | 0 | 2 (net -38) | 4 (net +261) | 6 (net +57) | 2 (net +72) | 0 | 12% (2 of 17) |
| Mine | High Elf Realms | 13 | 2 (net +0) | 0 | 2 (net +834) | 2 (net +542) | 2 (net +0) | 4 (net +16) | 1 | 17% (2 of 12) |
| Mine | Kingdom of Bretonnia | 6 | 0 | 0 | 0 | 2 (net +85) | 3 (net +63) | 1 (net +190) | 0 | 0% (0 of 6) |
| Mine | Lizardmen | 4 | 0 | 0 | 0 | 2 (net +128) | 1 (net +60) | 0 | 1 | 0% (0 of 3) |
| Mine | Ogre Kingdoms | 6 | 1 (net +0) | 0 | 0 | 2 (net +0) | 1 (net +60) | 1 (net +393) | 1 | 0% (0 of 5) |
| Mine | Orc & Goblin Tribes | 5 | 0 | 0 | 0 | 0 | 0 | 2 (net +142) | 3 | 0% (0 of 2) |
| Mine | Skaven | 4 | 0 | 0 | 1 (net +0) | 0 | 0 | 3 (net -34) | 0 | 25% (1 of 4) |
| Mine | Tomb Kings of Khemri | 3 | 1 (net +505) | 0 | 0 | 0 | 1 (net +608) | 1 (net +236) | 0 | 0% (0 of 3) |
| Mine | Vampire Counts | 17 | 4 (net +0) | 0 | 1 (net +165) | 4 (net +0) | 3 (net -5) | 4 (net +77) | 1 | 6% (1 of 16) |
| Mine | Warriors of Chaos | 3 | 0 | 0 | 1 (net +0) | 0 | 1 (net +116) | 1 (net +144) | 0 | 33% (1 of 3) |
| Opponent | Chaos Dwarfs | 9 | 3 (net +0) | 0 | 2 (net +0) | 0 | 0 | 4 (net +84) | 0 | 22% (2 of 9) |
| Opponent | Grand Cathay | 4 | 2 (net +131) | 0 | 0 | 1 (net +587) | 1 (net +0) | 0 | 0 | 0% (0 of 4) |
| Opponent | High Elf Realms | 9 | 1 (net +406) | 0 | 1 (net +559) | 2 (net +125) | 1 (net -151) | 4 (net +118) | 0 | 11% (1 of 9) |
| Opponent | Kingdom of Bretonnia | 2 | 1 (net +0) | 0 | 0 | 0 | 0 | 1 (net +150) | 0 | 0% (0 of 2) |
| Opponent | Ogre Kingdoms | 2 | 0 | 1 (net +77) | 0 | 0 | 0 | 1 (net -228) | 0 | 0% (0 of 2) |
| Opponent | Orc & Goblin Tribes | 5 | 0 | 0 | 0 | 0 | 2 (net +83) | 0 | 3 | 0% (0 of 2) |
| Opponent | Skaven | 2 | 1 (net +0) | 0 | 0 | 0 | 0 | 1 (net +0) | 0 | 0% (0 of 2) |
| Opponent | Tomb Kings of Khemri | 7 | 0 | 0 | 1 (net +0) | 3 (net +0) | 1 (net +310) | 2 (net +62) | 0 | 14% (1 of 7) |
| Opponent | Vampire Counts | 43 | 12 (net +23) | 2 (net -22) | 2 (net +152) | 9 (net +44) | 8 (net +75) | 7 (net +147) | 3 | 5% (2 of 40) |
| Opponent | Warriors of Chaos | 25 | 5 (net +202) | 0 | 2 (net +552) | 6 (net +82) | 2 (net +135) | 8 (net +29) | 2 | 9% (2 of 23) |
| Opponent | Wood Elf Realms | 11 | 7 (net +5) | 0 | 0 | 1 (net -234) | 0 | 3 (net +113) | 0 | 0% (0 of 11) |

### Charged fights, damage counted: h3-mine-efe7e34-p1

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 17 | 187 | 311 | +46 | 86 | 37 | +49 | +26.0 |
| Mine | Effective (55-75%) | 11 | 384 | 202 | +177 | 225 | 41 | +183 | +47.8 |
| Mine | 76-89% | 24 | 267 | 235 | +152 | 167 | 21 | +146 | +54.9 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 26 | 242 | 166 | +96 | 124 | 24 | +101 | +41.5 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 18 | 375 | 81 | +76 | 98 | 11 | +87 | +23.3 |
| Mine | No odds | 7 | 220 | 169 | -44 | 32 | 64 | -32 | -14.6 |
| Mine | All fights | 103 | 276 | 195 | +96 | 128 | 28 | +100 | +36.3 |
| Opponent | Long shot (under 50%) | 32 | 238 | 228 | +62 | 116 | 57 | +59 | +24.9 |
| Opponent | 50-54% | 3 | 145 | 174 | +11 | 39 | 31 | +8 | +5.5 |
| Opponent | Effective (55-75%) | 8 | 383 | 213 | +246 | 257 | 53 | +204 | +53.2 |
| Opponent | 76-89% | 22 | 250 | 172 | +68 | 85 | 20 | +65 | +26.0 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 31 | 266 | 166 | +79 | 125 | 53 | +71 | +26.8 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 15 | 403 | 97 | +80 | 99 | 33 | +67 | +16.5 |
| Opponent | No odds | 8 | 272 | 122 | +104 | 104 | 0 | +104 | +38.1 |
| Opponent | All fights | 119 | 278 | 175 | +84 | 117 | 41 | +76 | +27.3 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| h3-mine-efe7e34-p1 | move | 276 | 65 (24%) | 53 (19%) | 46 (17%) | 165 (60%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0103, L0120, L2425, L2532, L2732 |
| Charmed Shield | Opponent | L0525, L0734, L0824, L1225, L1627, L1724, L1824, L1924, L2025, L2425 |
| Clockwork Compass | Mine | L1225 |
| Elixir of Power | Mine | L1116, L1131, L1924 |
| Elixir of Power | Opponent | L0219 |
| Fistful of Laurels | Mine | L1824 |
| Fistful of Laurels | Opponent | L0718 |
| Horn of the Wild Hunt | Opponent | L2233 |
| Invocation of Nehek | Mine | L2425, L2532, L2732 |
| Invocation of Nehek | Opponent | L0525, L0824, L1225, L1627, L1724, L1824, L1924, L2025, L2425 |
| Opal Amulet | Mine | L1431 |
| Periapt of Soul Exchange | Mine | L2025, L2128 |
| Periapt of Soul Exchange | Opponent | L0120, L0321, L1320 |
| Ring of Doom | Mine | L0204, L0219, L1116, L1131, L1225, L1528 |
| Ring of Doom | Opponent | L0915, L0931, L1131, L1431, L2233, L3031 |
| Ring of Jet | Mine | L1023, L1116, L1131, L1225 |
| Ring of Jet | Opponent | L0510 |
| Standard of the Fell Warrior | Mine | L1320, L1335 |
| Standard of the Fell Warrior | Opponent | L0613 |
| Storm Daemon (Renegade 2.0) | Mine | L2128 |
| Storm Daemon (Renegade 2.0) | Opponent | L0321 |
| Twice-Blessed Armour | Mine | L0718, L0734, L1023 |
| Twice-Blessed Armour | Opponent | L0510 |
| Witch Hunter's Ward | Mine | L0718, L0734, L0824 |

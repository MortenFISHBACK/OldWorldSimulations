# Doctrine scorecard: h3-opp-efe7e34-p1

### Scorecard: h3-opp-efe7e34-p1

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0103 | 1 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 0 |
| L0103 | 1 | 1 | Opponent | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 445 |
| L0120 | 6 | 1 | Mine | no | 9 | - | 0 | 0 | 0 | 0 | 0 | 0 |
| L0120 | 6 | 1 | Opponent | no | 2 | - | 0 | 6 | 0 | 0 | 0 | 420 |
| L0204 | 6 | 1 | Mine | no | 7 | - | 0 | 7 | 0 | 0 | 0 | 0 |
| L0204 | 6 | 1 | Opponent | no | 1 | 1 | 3 | 0 | 0 | 0 | 0 | 0 |
| L0219 | 3 | 1 | Mine | no | 5 | 4 | 2 | 1 | 0 | 0 | 0 | 166 |
| L0219 | 3 | 1 | Opponent | yes | 8 | 2 | 2 | 2 | 0 | 0 | 0 | 0 |
| L0304 | 4 | 1 | Mine | no | 0 | 5 | 1 | 0 | 0 | 0 | 0 | 110 |
| L0304 | 4 | 1 | Opponent | no | 1 | 2 | 6 | 1 | 0 | 0 | 0 | 112 |
| L0321 | 3 | 1 | Mine | no | 1 | - | 0 | 1 | 0 | 0 | 0 | 119 |
| L0321 | 3 | 1 | Opponent | yes | 2 | 6 | 1 | 5 | 1 | 0 | 0 | 500 |
| L0406 | 4 | 1 | Mine | no | 2 | 3 | 1 | 1 | 0 | 0 | 0 | 0 |
| L0406 | 4 | 1 | Opponent | no | 0 | - | 2 | 2 | 1 | 0 | 0 | 616 |
| L0423 | 3 | 1 | Mine | no | 3 | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L0423 | 3 | 1 | Opponent | no | 11 | 2 | 1 | 0 | 1 | 0 | 0 | 0 |
| L0510 | 6 | 1 | Mine | no | 3 | - | 1 | 1 | 0 | 0 | 0 | 573 |
| L0510 | 6 | 1 | Opponent | no | 1 | 2 | 1 | 2 | 0 | 0 | 0 | 330 |
| L0525 | 3 | 1 | Mine | no | 8 | - | 0 | 2 | 0 | 0 | 0 | 574 |
| L0525 | 3 | 1 | Opponent | no | 2 | 2 | 5 | 4 | 0 | 0 | 0 | 0 |
| L0613 | 1 | 1 | Mine | no | 3 | 3 | 1 | 0 | 0 | 0 | 0 | 586 |
| L0613 | 1 | 1 | Opponent | no | 0 | 2 | 2 | 0 | 1 | 0 | 0 | 317 |
| L0630 | 6 | 1 | Mine | no | 2 | - | 2 | 1 | 0 | 0 | 0 | 290 |
| L0630 | 6 | 1 | Opponent | no | 10 | 2 | 1 | 1 | 1 | 0 | 0 | 0 |
| L0718 | 4 | 1 | Mine | no | 1 | 4 | 4 | 1 | 0 | 0 | 0 | 250 |
| L0718 | 4 | 1 | Opponent | no | 0 | - | 1 | 1 | 1 | 0 | 0 | 0 |
| L0734 | 2 | 1 | Mine | - | - | 4 | 0 | 1 | 0 | 0 | 0 | 250 |
| L0734 | 2 | 1 | Opponent | - | - | 2 | 4 | 3 | 0 | 0 | 0 | 107 |
| L0824 | 2 | 1 | Mine | - | - | 4 | 3 | 2 | 0 | 0 | 0 | 376 |
| L0824 | 2 | 1 | Opponent | - | - | 2 | 3 | 2 | 1 | 0 | 0 | 0 |
| L0915 | 3 | 1 | Mine | no | 8 | - | 0 | 1 | 0 | 0 | 0 | 382 |
| L0915 | 3 | 1 | Opponent | no | 6 | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L0931 | 1 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 170 |
| L0931 | 1 | 1 | Opponent | no | 2 | 4 | 1 | 2 | 1 | 0 | 0 | 0 |
| L1023 | 3 | 1 | Mine | no | 4 | 2 | 5 | 0 | 1 | 0 | 0 | 0 |
| L1023 | 3 | 1 | Opponent | yes | 1 | 2 | 3 | 3 | 0 | 0 | 0 | 60 |
| L1116 | 6 | 1 | Mine | no | 7 | 2 | 5 | 0 | 0 | 0 | 0 | 0 |
| L1116 | 6 | 1 | Opponent | no | 6 | - | 0 | 0 | 1 | 0 | 0 | 200 |
| L1131 | 3 | 1 | Mine | no | 0 | - | 3 | 0 | 0 | 0 | 0 | 165 |
| L1131 | 3 | 1 | Opponent | no | 3 | - | 0 | 1 | 0 | 0 | 0 | 170 |
| L1225 | 1 | 1 | Mine | yes | 7 | 1 | 4 | 0 | 0 | 0 | 0 | 165 |
| L1225 | 1 | 1 | Opponent | no | 3 | 4 | 3 | 2 | 1 | 0 | 0 | 0 |
| L1320 | 6 | 1 | Mine | no | 6 | 2 | 2 | 0 | 1 | 0 | 0 | 0 |
| L1320 | 6 | 1 | Opponent | no | 2 | - | 2 | 3 | 1 | 0 | 0 | 0 |
| L1335 | 3 | 1 | Mine | yes | 10 | 3 | 5 | 0 | 0 | 0 | 0 | 70 |
| L1335 | 3 | 1 | Opponent | no | 0 | 4 | 0 | 1 | 0 | 0 | 0 | 499 |
| L1431 | 3 | 1 | Mine | no | 2 | 3 | 4 | 1 | 0 | 0 | 0 | 0 |
| L1431 | 3 | 1 | Opponent | no | 0 | - | 0 | 1 | 1 | 0 | 0 | 456 |
| L1528 | 4 | 1 | Mine | no | 0 | 2 | 5 | 2 | 0 | 0 | 0 | 0 |
| L1528 | 4 | 1 | Opponent | no | 1 | - | 0 | 1 | 2 | 0 | 0 | 0 |
| L1627 | 1 | 1 | Mine | yes | 6 | 2 | 4 | 0 | 0 | 0 | 0 | 100 |
| L1627 | 1 | 1 | Opponent | no | 0 | 2 | 8 | 2 | 1 | 0 | 0 | 0 |
| L1724 | 2 | 1 | Mine | - | - | 2 | 4 | 0 | 0 | 0 | 0 | 0 |
| L1724 | 2 | 1 | Opponent | - | - | 2 | 5 | 2 | 0 | 0 | 0 | 0 |
| L1824 | 6 | 1 | Mine | no | 4 | 4 | 1 | 0 | 0 | 0 | 0 | 0 |
| L1824 | 6 | 1 | Opponent | no | 1 | 3 | 3 | 0 | 0 | 0 | 0 | 0 |
| L1924 | 4 | 1 | Mine | no | 1 | 1 | 6 | 0 | 1 | 0 | 0 | 382 |
| L1924 | 4 | 1 | Opponent | no | 0 | 2 | 5 | 1 | 0 | 0 | 0 | 500 |
| L2025 | 3 | 1 | Mine | yes | 2 | - | 1 | 1 | 1 | 0 | 0 | 210 |
| L2025 | 3 | 1 | Opponent | no | 6 | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L2128 | 4 | 1 | Mine | no | 0 | - | 1 | 5 | 1 | 0 | 0 | 795 |
| L2128 | 4 | 1 | Opponent | no | 5 | - | 0 | 1 | 0 | 0 | 0 | 0 |
| L2233 | 1 | 1 | Mine | yes | 1 | 2 | 4 | 0 | 0 | 0 | 0 | 0 |
| L2233 | 1 | 1 | Opponent | yes | 1 | 2 | 2 | 2 | 0 | 0 | 0 | 144 |
| L2425 | 1 | 1 | Mine | no | 4 | 2 | 4 | 0 | 0 | 0 | 0 | 50 |
| L2425 | 1 | 1 | Opponent | no | 2 | 2 | 1 | 1 | 0 | 0 | 0 | 0 |
| L2532 | 6 | 1 | Mine | no | 0 | 4 | 6 | 0 | 0 | 0 | 0 | 0 |
| L2532 | 6 | 1 | Opponent | no | 5 | 2 | 4 | 2 | 2 | 0 | 0 | 170 |
| L2732 | 2 | 1 | Mine | - | - | 1 | 3 | 3 | 0 | 0 | 0 | 0 |
| L2732 | 2 | 1 | Opponent | - | - | 5 | 2 | 6 | 1 | 0 | 0 | 170 |
| L3031 | 1 | 1 | Mine | no | 5 | 3 | 2 | 1 | 0 | 0 | 0 | 0 |
| L3031 | 1 | 1 | Opponent | no | 3 | - | 3 | 1 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 16% | 3.5 | 2.7 | 2.4 | 1.0 | 0.1 | 0.0 | 0.0 | 160.6 |
| **Average** | | | Opponent | 12% | 2.7 | 2.5 | 2.2 | 1.8 | 0.5 | 0.0 | 0.0 | 144.9 |

### KPIs: h3-opp-efe7e34-p1

Rules off - Mine only: HOLDER ASSIGNMENT.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 34% (58 of 172) | 7% (11 of 166) | 20% (69 of 338) |
| Winner chose to follow up after the loser gave ground |  | 80% (48 of 60); on the table 83% | 78% (38 of 49); on the table 80% | 79% (86 of 109); on the table 82% |
| Winner chose to pursue after the loser fell back in good order |  | 75% (6 of 8); on the table 88% | 75% (15 of 20); on the table 75% | 75% (21 of 28); on the table 79% |
| Winner chose to pursue after the loser fled |  | 72% (13 of 18); on the table 83% | 52% (12 of 23); on the table 61% | 61% (25 of 41); on the table 71% |
| Winner chose to follow up or pursue (all three) |  | 78% (67 of 86); on the table 84% | 71% (65 of 92); on the table 74% | 74% (132 of 178); on the table 79% |
| Magic missiles tried each own turn | 50%+ | 34% (111 of 328) | 31% (59 of 188) | 33% (170 of 516) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 43% (105 of 245) | 44% (59 of 134) | 43% (164 of 379) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 46% (17 of 37) | 58% (52 of 89) | 55% (69 of 126) |
| Points that never fought | lower | 42% (29208 of 69069) | 43% (31030 of 71977) | 43% (60238 of 141046) |
|   infantry points that never fought | lower | 53% (8567 of 16104) | 59% (8135 of 13743) | 56% (16702 of 29847) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 58% (160 of 276) | 58% (166 of 285) | 58% (326 of 561) |
| Bound items with a magic missile used (at least once a game) |  | 90% (19 of 21); 1.5 uses a game | 93% (13 of 14); 1.1 uses a game | 91% (32 of 35); 1.3 uses a game |
| Bound items with another spell used |  | 67% (10 of 15); 0.4 uses a game | 67% (2 of 3); 0.2 uses a game | 67% (12 of 18); 0.3 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 50% (10 of 20); 0.3 uses a game | 60% (6 of 10); 0.2 uses a game | 53% (16 of 30); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 52% (30211 of 58081) | 54% (34859 of 63977) | 53% (65070 of 122058) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 2.0 (33%) | 0.9 (25%) | 2.9 (30%) |
| MARCHED: its unit marched | 1.4 (24%) | 0.9 (25%) | 2.3 (24%) |
| CHARGED: its unit charged | 0.3 (5%) | 0.1 (2%) | 0.4 (4%) |
| IN COMBAT: engaged in combat | 1.1 (18%) | 0.8 (23%) | 1.9 (20%) |
| REAR RANK: in a rear rank | 0.1 (1%) | 0.0 (1%) | 0.1 (1%) |
| FLEEING: fleeing | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| GONE: slain | 1.0 (16%) | 0.6 (16%) | 1.6 (16%) |
| OFF THE TABLE: off the table or not arrived | 0.1 (1%) | 0.1 (2%) | 0.1 (1%) |
| STUPIDITY: Stupidity | 0.1 (1%) | 0.1 (2%) | 0.1 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.1 (2%) | 0.1 (1%) |
| NOT OFFERED: not in the cast list | 0.1 (1%) | 0.1 (2%) | 0.1 (1%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.1 | 1.6 | 1.9 | 4.7 | 0.3 | 1.9 |
| not cast | 4.6 | 2.6 | 3.8 | 9.6 | 2.7 | 19.7 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.4 (7%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.2 (46%) | 0.4 (11%) | 2.9 (30%) | 0.8 (31%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.3 (24%) | 0.6 (24%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.4 (4%) | 0.1 (2%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.2 (4%) | 0.1 (4%) | 0.6 (16%) | 1.9 (20%) | 0.6 (22%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.2 (5%) | 0.1 (3%) | 0.1 (4%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) |
| NO CASTS LEFT: every cast used on other spells | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (2%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (0%) | 0.1 (2%) | 0.1 (1%) | 0.1 (1%) | 0.0 (0%) | 0.3 (1%) |
| GONE: slain | 1.1 (25%) | 0.4 (17%) | 0.6 (15%) | 1.6 (16%) | 0.1 (4%) | 3.3 (17%) |
| OFF THE TABLE: off the table or not arrived | 0.2 (4%) | 0.1 (4%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.2 (1%) |
| STUPIDITY: Stupidity | 0.1 (2%) | 0.1 (2%) | 0.0 (1%) | 0.1 (1%) | 0.0 (0%) | 0.2 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.2 (4%) | 0.3 (12%) | 0.0 (1%) | 0.1 (1%) | 0.4 (15%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.5 (55%) | 0.2 (9%) | 1.9 (51%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 14.3 (73%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.9 a game | 1.0 a game | 1.0 a game |
| stood (cast and not dispelled) | 61% (19 of 31) | 63% (19 of 30) | 62% (38 of 61) |
| the unit moved after it | 84% (16 of 19) | 89% (17 of 19) | 87% (33 of 38) |
| it charged on its next turn | 5% (1 of 19) | 0% (0 of 19) | 3% (1 of 38) |
| the enemy charged it first | 16% (3 of 19) | 11% (2 of 19) | 13% (5 of 38) |
| it fought by the end of its next turn | 11% (2 of 19) | 11% (2 of 19) | 11% (4 of 38) |
| it moved out of a charge the enemy had planned (not charged first) | 5% (1 of 19) | 0% (0 of 19) | 3% (1 of 38) |
| none of these (no charge, no fight, no charge escaped) | 74% (14 of 19) | 89% (17 of 19) | 82% (31 of 38) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 61% (548 of 895) | 59% (269 of 458) | 60% (817 of 1353) |
|   cavalry | 65% (39 of 60) | 62% (46 of 74) | 63% (85 of 134) |
|   character | 59% (63 of 107) | 32% (23 of 72) | 48% (86 of 179) |
|   chariot | 60% (56 of 93) | 49% (32 of 65) | 56% (88 of 158) |
|   infantry | 55% (157 of 287) | 60% (95 of 158) | 57% (252 of 445) |
|   monster | 60% (25 of 42) | 82% (9 of 11) | 64% (34 of 53) |
|   war machine | 68% (208 of 306) | 82% (64 of 78) | 71% (272 of 384) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.4 (24%) | 1.5 (29%) | 3.9 (26%) |
| CHARGED: it charged | 0.6 (7%) | 0.8 (16%) | 1.5 (10%) |
| FLEEING: it fled or was fleeing | 0.0 (0%) | 0.1 (2%) | 0.1 (1%) |
| IN COMBAT: it fought this turn or the last | 0.7 (7%) | 0.4 (7%) | 1.1 (7%) |
| MOVED: a war machine that moved | 1.4 (15%) | 0.0 (1%) | 1.5 (10%) |
| NO TARGET IN RANGE | 1.8 (18%) | 0.9 (16%) | 2.6 (18%) |
| ONLY IN COMBAT: the only targets were in combat | 0.5 (5%) | 0.4 (7%) | 0.9 (6%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.4 (14%) | 0.8 (15%) | 2.2 (15%) |
| SHELTERED: the target was sheltered | 0.3 (3%) | 0.1 (2%) | 0.4 (3%) |
| STUPIDITY | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| OTHER BAR | 0.4 (4%) | 0.2 (4%) | 0.6 (4%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 3.4 | 0.5 | 86% | 4.0 pts | 14 pts |
| character | 2.8 | 1.0 | 80% | 5.9 pts | 16 pts |
| chariot | 2.5 | 2.2 | 59% | 12.9 pts | 33 pts |
| infantry | 10.0 | 4.2 | 72% | 8.7 pts | 87 pts |
| monster | 1.1 | 0.3 | 72% | 13.0 pts | 14 pts |
| war machine | 7.6 | 5.9 | 64% | 22.6 pts | 171 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.6 | 4.9 | 4.3 |
| Charges that made contact a game | 2.8 | 3.8 | 3.3 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.83 declared, 0.71 contact (24 units) | 1.10 declared, 0.95 contact (20 units) | 0.95 declared, 0.82 contact (44 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.67 declared, 0.33 contact (9 units) | 1.27 declared, 1.09 contact (11 units) | 1.00 declared, 0.75 contact (20 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.44 declared, 0.34 contact (240 units) | 0.52 declared, 0.39 contact (268 units) | 0.48 declared, 0.37 contact (508 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 52% (33 of 64) | 54% (13 of 24) | 20% (2 of 10) | 49% (48 of 98) |
| Character in a unit | 97% (37 of 38) | 100% (17 of 17) | 75% (3 of 4) | 97% (57 of 59) |
| Character on its own | 86% (38 of 44) | 50% (20 of 40) | 35% (21 of 60) | 55% (79 of 144) |
| Chariot | 64% (9 of 14) | 67% (10 of 15) | - | 66% (19 of 29) |
| Infantry | 44% (37 of 85) | 30% (12 of 40) | 100% (1 of 1) | 40% (50 of 126) |
| Monster | 50% (13 of 26) | 75% (9 of 12) | - | 58% (22 of 38) |
| Monstrous | 57% (4 of 7) | 70% (7 of 10) | - | 65% (11 of 17) |
| War Machines | 79% (37 of 47) | 100% (3 of 3) | - | 80% (40 of 50) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 50% (1 of 2); on the table 50% | 36% (37 of 102) | 51% | 73% (16 of 22) | 100% (6 of 6); 4.5 uses a game | 50% (1 of 2); 0.5 uses a game | 83% (5 of 6); 1.2 uses a game |
| Chaos Dwarfs | 7 | 81% (13 of 16); on the table 81% | 40% (24 of 60) | 57% | 52% (28 of 54) | 0.0 uses a game | 0.0 uses a game | 33% (1 of 3); 0.1 uses a game |
| Dwarfen Mountain Holds | 5 | 50% (3 of 6); on the table 50% | - | 53% | 70% (31 of 44) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 5 | 86% (6 of 7); on the table 86% | 56% (20 of 36) | 52% | 63% (34 of 54) | 0.0 uses a game | 100% (2 of 2); 0.4 uses a game | 33% (1 of 3); 0.2 uses a game |
| Grand Cathay | 5 | 73% (8 of 11); on the table 91% | 26% (30 of 114) | 48% | 47% (21 of 45) | 100% (11 of 11); 6.4 uses a game | 50% (1 of 2); 0.6 uses a game | 0% (0 of 5); 0.0 uses a game |
| High Elf Realms | 6 | 82% (14 of 17); on the table 82% | 8% (2 of 24) | 44% | 36% (17 of 47) | 86% (6 of 7); 2.8 uses a game | 67% (8 of 12); 2.5 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 2 | 80% (4 of 5); on the table 100% | - | 35% | 50% (6 of 12) | 0.0 uses a game | 0.0 uses a game | 100% (2 of 2); 1.0 uses a game |
| Lizardmen | 1 | 100% (4 of 4); on the table 100% | - | 21% | 71% (5 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 2 | 100% (1 of 1); on the table 100% | 0% (0 of 12) | 36% | 86% (12 of 14) | 100% (2 of 2); 2.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 2 | 100% (5 of 5); on the table 100% | 33% (4 of 12) | 31% | 75% (12 of 16) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.5 uses a game |
| Skaven | 5 | 71% (5 of 7); on the table 86% | 19% (7 of 36) | 62% | 59% (23 of 39) | 50% (1 of 2); 0.2 uses a game | 0.0 uses a game | 60% (3 of 5); 0.6 uses a game |
| Tomb Kings of Khemri | 3 | 94% (15 of 16); on the table 100% | 17% (1 of 6) | 25% | 33% (5 of 15) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 12 | 62% (35 of 56); on the table 66% | 39% (28 of 72) | 29% | 59% (44 of 74) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 10 | 70% (14 of 20); on the table 75% | 39% (14 of 36) | 38% | 60% (53 of 88) | 100% (4 of 4); 1.2 uses a game | 0.0 uses a game | 100% (2 of 2); 0.2 uses a game |
| Wood Elf Realms | 3 | 80% (4 of 5); on the table 80% | 50% (3 of 6) | 36% | 63% (19 of 30) | 67% (2 of 3); 3.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.3 uses a game |

Flank and rear charges a unit could have turned to face (h3-opp-efe7e34-p1, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 46% (35) | 46% (36) | 46% (71) |
| ...free all their last turn and able to turn (per game) | 0.58 | 0.69 | 1.28 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.19 | 0.11 | 0.31 |
| ...with the charger already in that arc before they moved (per game) | 0.44 | 0.56 | 1.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.03 | 0.03 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.14 | 0.19 | 0.33 |

### Quality by phase: h3-opp-efe7e34-p1

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.3 | 2.7 |
| Strategy | Charge objectives carried out (made contact) | 64% (79 of 124) | 54% (77 of 143) |
| Strategy | Shoot objectives carried out (shot that target) | 30% (109 of 363) | 48% (70 of 146) |
| Strategy | Support requests answered (helper made contact too) | 50% (7 of 14) | 70% (14 of 20) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (3 of 3) | 100% (7 of 7) |
| Strategy | Hexes on a unit its side charged or shot that turn | 45% (5 of 11) | 22% (2 of 9) |
| Strategy | Joined characters whose unit fought | 41% (20 of 49) | 19% (7 of 37) |
| Strategy | Lone characters that fought | 73% (67 of 92) | 78% (73 of 93) |
| Movement | Charges halted short of contact | 0.1 | 0.3 |
| Movement | Idle units | 1.0 | 1.8 |
| Movement | Points that never moved of their own | 160.6 | 144.9 |
| Movement | Fights charged into per game | 2.7 | 3.1 |
| Movement | Charges with odds: long shots (under 50%) | 21 of 94, net +123 | 26 of 102, net +54 |
| Movement | Charges with odds: sweet spot (55-75%) | 12 of 94, net +147 | 16 of 102, net +73 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 15 of 94, net +22 | 11 of 102, net +98 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 26 of 94, net +100 | 28 of 102, net +147 |
| Shooting | Shots by shooting units (incl. breath weapons) | 10.4 | 6.6 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 38% (142 of 374) | 38% (89 of 236) |
| Shooting | Points destroyed by shooting units | 63.6 | 45.9 |
| Shooting | War machine shots | 5.8 | 1.8 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 48% (100 of 208) | 61% (39 of 64) |
| Shooting | Points destroyed by war machines | 59.4 | 6.0 |
| Magic | Magic missiles cast | 1.8 | 0.9 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 37% (23 of 63) | 36% (12 of 33) |
| Magic | Wounds caused by magic missiles | 3.3 | 1.0 |
| Magic | Wounds caused by other spells | 1.0 | 1.1 |
| Magic | Points destroyed by magic (all spells) | 28.1 | 16.4 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.7 / 0.5 / 0.7 / 0.1 | 2.1 / 0.4 / 0.5 / 0.1 |
| Combat | Points destroyed in combat | 317.0 | 320.1 |
| Combat | Points run down | 103.4 | 101.5 |
| Combat | Net points per charged fight, damage counted | +111 | +95 |
| Combat | Net per 100 charger points, damage counted | +40.6 | +34.5 |
| Combat | First round won (charged fights) | 73% | 68% |
| Combat | Net points per charged fight | +101 | +98 |
| Combat | Net points per supported fight / lone fight | +100 / +102 | +107 / +97 |
| Combat | Charged fights on a top-3 enemy unit | 33 of 98 | 47 of 111 |
| Game | Points lost | 591.9 | 615.2 |
| Game | VP from objectives | 697.5 | 661.9 |
| Game | Lone holders (player turns) | 3.5 | 2.7 |

- Mine won / drew / lost: 15 / 7 / 14 of 36 ended games (of 36); mean margin (Mine - Opponent) +102 VP
- The side that went first won 16 of 29 games with a winner
- Points traded per game (both sides' losses): 1207
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: h3-opp-efe7e34-p1

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 0.8 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.4 | +88.3 | 0.0 | 26.1 | 0.3 | +51.0 | 0.0 | 15.1 |
| ALREADY CARRIED | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARRIVAL HUNT | - | - | - | - | 0.1 | +2.2 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.6 | +0.0 | 0.0 | 18.2 | 0.1 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | 0.3 | +1.5 | 0.0 | 7.3 | 0.4 | +3.1 | 0.0 | 6.5 |
| BEST PRIZE | 0.1 | -9.1 | 1.1 | 0.0 | 0.1 | -16.4 | 1.8 | 0.0 |
| BLOWS WHERE AIMED | 0.2 | -8.1 | 23.8 | 12.3 | 0.1 | -11.7 | 21.1 | 0.0 |
| BOMBING RUN | 0.1 | +3.4 | 13.1 | 0.0 | - | - | - | - |
| BOUND ASSAILMENT | 0.1 | +0.0 | 0.0 | 7.0 | - | - | - | - |
| CANNON PLAN MISSED | 0.8 | +0.0 | 120.7 | 6.1 | 0.2 | +0.0 | 31.6 | 2.9 |
| CANNON PLANNED TARGET | 5.4 | +111.0 | 528.1 | 81.7 | 1.8 | +29.3 | 90.5 | 13.6 |
| CANNON SIGHT KEPT | 1.0 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT COUNTER | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CARRIES OUT SET-UP | - | - | - | - | 0.1 | -0.6 | 10.3 | 0.0 |
| CAST JOB | 0.5 | +17.2 | 31.1 | 2.2 | 0.4 | +5.1 | 8.3 | 18.2 |
| CASTER AWAY FROM SCREEN | 0.2 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.1 | +3.9 | 0.0 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | 0.5 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 11.7 |
| CASTS FROM BEHIND | 0.1 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.1 | +2.1 | 0.0 | 0.0 | 0.0 | +1.7 | 0.0 | 0.0 |
| CATCH ODDS | - | - | - | - | 0.1 | +1.2 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | 0.3 | +11.0 | 0.0 | 2.3 | 0.7 | +17.8 | 0.0 | 6.2 |
| CHAFF PASSED | 0.1 | -0.1 | 3.1 | 4.2 | 0.1 | -0.1 | 0.0 | 0.0 |
| CHAMPION TAKES THE CHALLENGE | 0.0 | +2.3 | 1.9 | 0.0 | 0.0 | +1.3 | 9.5 | 0.0 |
| CHARACTER GUNS | 0.6 | +0.0 | 0.0 | 5.2 | 0.4 | +0.0 | 0.0 | 0.0 |
| CHARGE LOSSES | 5.5 | -193.4 | 0.0 | 148.6 | 6.0 | -345.0 | 0.0 | 209.4 |
| CHARGE NOT DECLARED | 0.6 | +0.0 | 76.8 | 18.0 | 0.8 | +0.0 | 64.5 | 2.8 |
| CHARGE NOW FIRST | 1.9 | +0.0 | 219.5 | 53.0 | 1.8 | +0.0 | 190.9 | 37.8 |
| CHARGER SLAIN LOST | 0.3 | -14.8 | 18.9 | 9.3 | 0.2 | -4.8 | 25.1 | 6.1 |
| CHEAP HELPER | 0.1 | +0.0 | 22.9 | 0.0 | 0.1 | +0.0 | 4.7 | 0.0 |
| CHEAPEST HOLDER | 0.2 | -10.8 | 6.2 | 0.0 | - | - | - | - |
| COMBAT PIVOT | 0.3 | +0.0 | 0.0 | 35.7 | 0.5 | +0.0 | 18.1 | 6.8 |
| CONVEYANCE SEARCH | 0.5 | +62.8 | 11.1 | 11.1 | 0.4 | +28.5 | 1.8 | 0.0 |
| COVER ONCE | 7.6 | -557.1 | 0.0 | 179.8 | 4.8 | -331.6 | 0.0 | 81.6 |
| DEFENSIVE ARMY | 0.1 | +0.0 | 13.1 | 0.0 | - | - | - | - |
| DEFENSIVE FLOOR | - | - | - | - | 0.1 | +3.4 | 0.0 | 0.0 |
| DEPLOY BY FIGURES | 8.1 | -15.9 | 0.0 | 1.8 | 7.4 | +76.6 | 0.0 | 26.6 |
| EDGE GIVE GROUND | 0.2 | +14.7 | 41.5 | 1.2 | 0.1 | +1.9 | 13.8 | 1.7 |
| ELIXIR WORTH | 0.0 | +0.2 | 0.0 | 0.0 | - | - | - | - |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| FALL BACK GOOD ORDER | 2.0 | +3.9 | 165.9 | 35.4 | 2.9 | +6.5 | 279.1 | 38.2 |
| FALLBACK BY WORTH | 0.2 | +5.2 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 6.4 |
| FALLS SHORT | 4.6 | +70.0 | 0.0 | 41.4 | 18.3 | +262.2 | 0.0 | 240.9 |
| FEATURE BUFFS | 0.9 | +17.2 | 0.0 | 14.3 | 0.3 | +22.8 | 0.0 | 9.9 |
| FIGHT LIFT | 0.1 | +0.7 | 0.0 | 0.0 | 0.1 | +1.8 | 0.0 | 0.0 |
| FIGHT TO THE END | 1.1 | +45.8 | 69.3 | 36.6 | 1.7 | +89.5 | 178.6 | 15.2 |
| FIRE AND FLEE | - | - | - | - | 0.0 | +0.2 | 0.0 | 0.0 |
| FIRE IN ORDER | 0.2 | +0.0 | 2.6 | 3.5 | 0.1 | +0.0 | 0.0 | 3.0 |
| FIVE ACTION | 47.7 | +3008.3 | 1133.0 | 674.1 | 43.2 | +2355.0 | 563.7 | 577.1 |
| FLANK NOT WEIGHED | 6.2 | +0.0 | 0.0 | 172.4 | 5.0 | +0.0 | 0.0 | 105.7 |
| FOCUS FIRE | 0.1 | +1.9 | 3.1 | 0.0 | - | - | - | - |
| FOLLOW UP WEIGHED | 0.8 | +177.4 | 0.0 | 30.0 | 0.9 | +256.2 | 0.0 | 18.4 |
| FOUR ROUNDS | 3.4 | +375.1 | 318.1 | 67.3 | 3.8 | +403.3 | 355.1 | 58.6 |
| FRIEND CHARGES FIRST | 0.2 | -29.2 | 0.0 | 0.0 | 0.2 | -17.4 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 0.6 | -8.5 | 5.8 | 18.2 | 0.1 | -1.6 | 0.0 | 0.0 |
| FRIENDS SHOTS CHECKED | 0.1 | +1.8 | 0.0 | 0.0 | 0.1 | +1.8 | 0.0 | 0.0 |
| GIVES UP | 0.2 | -2.5 | 4.1 | 4.2 | 0.3 | -3.4 | 35.8 | 6.1 |
| GIVES UP ITS SCREEN | - | - | - | - | 0.0 | -0.0 | 0.0 | 0.0 |
| GROUND FLIERS | 0.0 | +1.2 | 0.0 | 6.1 | - | - | - | - |
| GUN FIGURES | 1.2 | +11.2 | 35.1 | 10.4 | 0.7 | +15.5 | 37.9 | 12.4 |
| GUN MASK | 1.2 | +32.9 | 0.0 | 9.4 | 0.1 | +1.9 | 0.0 | 0.0 |
| HARD STAY DROPPED | 1.1 | +0.0 | 0.0 | 30.0 | 1.2 | +0.0 | 0.0 | 3.2 |
| HE SHOOTS OR CHARGES | 1.7 | +0.0 | 0.0 | 46.3 | 2.1 | +0.0 | 0.0 | 57.4 |
| HELPER ALREADY ASKED | - | - | - | - | 0.1 | +0.0 | 0.0 | 0.8 |
| HELPER UNSEEN | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 12.0 | 0.0 |
| HIS CHARGE DENIED | 0.3 | +13.2 | 13.9 | 21.0 | 0.4 | +17.3 | 11.4 | 5.4 |
| HIS CHARGE LIST | 2.9 | +0.0 | 0.0 | 62.2 | 2.3 | +0.0 | 0.0 | 52.7 |
| HIS LEGAL MOVES | 4.5 | +0.0 | 0.0 | 72.1 | 3.9 | +0.0 | 0.0 | 55.6 |
| HIS MOVE AND SHOT | 1.2 | -19.5 | 0.0 | 5.4 | 1.9 | -55.4 | 0.0 | 111.7 |
| HIS RANDOM MOVE | 4.6 | +0.0 | 0.0 | 56.8 | 1.5 | +0.0 | 0.0 | 4.3 |
| HIS SHOT LIST | 15.8 | +364.3 | 0.0 | 296.8 | 22.1 | +1134.9 | 0.0 | 309.9 |
| HIS TURN DENIED | 1.1 | +30.8 | 125.6 | 4.2 | 1.6 | +86.1 | 154.5 | 31.4 |
| HOLD ODDS | - | - | - | - | 6.2 | +0.0 | 0.0 | 32.3 |
| HOLDER ASSIGNMENT | - | - | - | - | 12.6 | +1259.9 | 0.0 | 68.7 |
| HOLDER AT DEPLOYMENT | 1.2 | +211.8 | 0.0 | 0.0 | - | - | - | - |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 2.8 | -110.1 | 262.0 | 54.2 | 3.1 | -124.4 | 277.9 | 48.1 |
| HUNT IN PAIRS | 0.2 | +5.7 | 0.0 | 0.0 | 0.3 | +20.8 | 0.0 | 0.0 |
| HUNT KEPT | 0.0 | +0.0 | 0.0 | 2.5 | - | - | - | - |
| HUNT RESULT | 0.0 | +0.0 | 0.0 | 0.0 | 0.0 | +11.9 | 0.0 | 0.9 |
| HUNT THE GUNS | 0.1 | +26.3 | 0.0 | 2.5 | 0.0 | +14.0 | 3.5 | 0.0 |
| IDLE COST | 2.3 | -26.5 | 0.0 | 15.0 | 11.0 | -159.9 | 0.0 | 164.0 |
| JOINT KNOWS CHALLENGE | 0.1 | -6.1 | 40.9 | 0.0 | 0.1 | -2.5 | 32.6 | 0.0 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| KILLS COUNT | 0.0 | +0.8 | 4.1 | 0.0 | - | - | - | - |
| LANE BY FIGURES | 0.7 | +19.6 | 0.0 | 0.0 | 0.7 | +33.0 | 0.0 | 16.6 |
| LEGAL CHARGES ONLY | 6.3 | +0.0 | 227.9 | 283.0 | 5.3 | +0.0 | 226.8 | 151.7 |
| LONE CHARACTER SAFE SPOT | 0.1 | +9.1 | 0.0 | 0.0 | 0.1 | +5.9 | 0.0 | 0.0 |
| LONE WIZARD KEPT IN | 0.6 | +35.1 | 0.0 | 5.8 | 0.2 | +17.6 | 0.0 | 0.0 |
| LONG SHOT | 0.1 | -1.3 | 3.1 | 0.0 | 0.1 | -0.1 | 12.0 | 6.0 |
| LOST CHARGE | 0.1 | -0.1 | 0.0 | 0.0 | 0.1 | -0.1 | 14.7 | 0.0 |
| LURE BY WHAT IT DRAWS | - | - | - | - | 0.1 | -2.8 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 0.2 | +2.3 | 0.0 | 0.0 | 0.1 | +2.2 | 0.0 | 0.0 |
| MANOEUVRE | 1.3 | +12.6 | 0.0 | 37.2 | 0.8 | +15.0 | 0.0 | 15.5 |
| MARCH AT ESCAPER | 0.1 | +1.5 | 0.0 | 0.0 | 0.2 | +1.1 | 0.0 | 0.0 |
| MARCH BY THE SUM | 0.5 | +26.1 | 0.0 | 17.4 | 0.2 | +6.6 | 0.0 | 0.0 |
| MARCH CHECK | 1.2 | +75.3 | 0.0 | 7.6 | 0.9 | +42.5 | 0.0 | 33.9 |
| MARCH OVER CASTS | 0.8 | +26.0 | 0.0 | 23.3 | 0.8 | +125.4 | 0.0 | 32.2 |
| MAX FOR POSITIONING | 5.7 | +91.2 | 0.0 | 83.2 | 6.3 | +82.7 | 0.0 | 95.1 |
| MISSILES IN THE MOVE | 4.2 | +133.3 | 0.0 | 60.7 | 2.8 | +36.0 | 0.0 | 44.1 |
| MISSILES NEXT TURN | 5.3 | +85.4 | 0.0 | 121.2 | 4.0 | +32.7 | 0.0 | 76.2 |
| MODEL FACING | 0.3 | +73.9 | 0.0 | 3.3 | 0.1 | +18.5 | 0.0 | 0.0 |
| MOVE SPELL IN RANGE | 0.1 | +2.9 | 0.0 | 0.0 | 0.1 | +1.2 | 0.0 | 0.0 |
| MOVE SPELL OUT OF RANGE | 0.5 | -10.0 | 0.0 | 43.5 | 0.3 | -2.4 | 0.0 | 0.0 |
| MOVE SPELL SPOT | 0.4 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 4.1 | +552.7 | 0.0 | 54.9 | 3.8 | +507.6 | 0.0 | 54.8 |
| MOVES UNITS SPELL | 0.1 | +3.4 | 0.0 | 0.0 | 0.1 | +0.3 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 4.5 | +238.9 | 0.0 | 82.4 | 3.0 | +137.1 | 0.0 | 21.0 |
| NEEDED THERE | 0.0 | +10.3 | 4.1 | 0.0 | - | - | - | - |
| NEXT CHARGE BY LIST | 5.7 | -176.3 | 28.5 | 63.5 | 5.3 | -170.1 | 12.0 | 102.5 |
| NEXT OBJECTIVE NEARER | 8.2 | -398.0 | 87.5 | 85.9 | 6.0 | -212.4 | 2.9 | 67.1 |
| NO DOUBLE ROUNDS | 2.6 | -129.3 | 261.0 | 63.5 | 2.8 | -166.0 | 266.5 | 24.6 |
| NO RALLY LEFT | 0.1 | +10.7 | 0.0 | 23.0 | 0.0 | +0.2 | 0.0 | 0.0 |
| NOT TURNED | 0.1 | +0.0 | 0.0 | 4.8 | 0.2 | +0.1 | 0.0 | 5.9 |
| NOT WORTH A CAST | 1.1 | -0.8 | 0.0 | 74.0 | 0.4 | -0.3 | 0.0 | 0.0 |
| OFF BEST | 0.4 | -29.0 | 0.0 | 1.2 | 1.0 | -28.6 | 0.0 | 5.9 |
| ONE CHARGE A CHARGER | 3.4 | +0.0 | 0.0 | 70.7 | 3.2 | +0.0 | 0.0 | 38.2 |
| ONE FIGHT FORMULA | 5.2 | -106.6 | 0.0 | 42.9 | 6.3 | -145.4 | 0.0 | 170.0 |
| ONE OBJECTIVE FORMULA | 4.7 | +14.4 | 0.0 | 80.0 | 4.5 | +14.3 | 0.0 | 24.9 |
| ONE TARGET A SHOOTER | 14.1 | +289.4 | 0.0 | 160.5 | 18.1 | +554.1 | 0.0 | 191.4 |
| OPENS A LANE | 0.1 | +1.4 | 14.2 | 0.0 | 0.0 | +0.2 | 0.0 | 0.0 |
| OPENS UP | 0.3 | +18.6 | 20.7 | 0.0 | 0.2 | +7.5 | 13.0 | 26.9 |
| OVERRUNS AWAY | 0.4 | +42.7 | 45.1 | 0.0 | 0.5 | +13.4 | 49.9 | 25.9 |
| PATHS CROSS | 3.8 | +142.5 | 0.0 | 36.2 | 4.2 | +135.5 | 0.0 | 23.2 |
| PERIAPT WORTH | - | - | - | - | 0.1 | +8.5 | 0.0 | 15.0 |
| PIVOT GUARDS FLANK | 0.1 | -9.3 | 0.0 | 0.0 | 0.1 | -1.3 | 0.0 | 13.1 |
| PLAN RESULT | 41.9 | +1064.0 | 632.9 | 860.4 | 39.1 | +476.9 | 325.4 | 750.3 |
| PURSUES BIG PREY | 0.1 | -5.8 | 0.0 | 0.0 | 0.1 | -6.7 | 0.0 | 0.0 |
| RANDOM MOVE BY FIGURES | 1.0 | +8.5 | 0.0 | 10.6 | 2.5 | +38.6 | 0.0 | 42.9 |
| REDIRECT BY WHAT IT STOPS | 0.1 | -3.3 | 0.0 | 2.3 | 0.2 | -2.7 | 0.0 | 3.2 |
| REDIRECT COUNTER | 2.2 | +154.4 | 0.0 | 28.7 | 3.6 | +224.5 | 0.0 | 64.4 |
| REDIRECT WEIGHED | 0.0 | +0.0 | 0.0 | 1.2 | 0.1 | +0.1 | 0.0 | 0.0 |
| REFORMS TO MEET IT | 0.9 | -52.9 | 0.0 | 20.1 | 0.6 | -13.5 | 0.0 | 6.2 |
| REFUSING RETIRES | 0.1 | +0.0 | 0.0 | 12.3 | 0.2 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | 0.4 | +20.4 | 0.0 | 2.0 | 0.5 | +29.9 | 0.0 | 7.4 |
| RESTRAINS TO SHOOT | 0.1 | +4.9 | 0.0 | 0.0 | 0.1 | +4.2 | 0.0 | 0.0 |
| RISK BY ARC | 2.3 | +10.9 | 222.1 | 48.5 | 2.4 | +8.7 | 214.5 | 50.5 |
| RISK BY HIS FIGURE | 14.4 | -151.3 | 0.0 | 317.3 | 14.0 | -225.1 | 0.0 | 315.1 |
| RUN DOWN | 1.8 | -38.7 | 160.5 | 39.7 | 2.4 | -32.5 | 251.1 | 26.9 |
| SAFER THAN THE JOB | - | - | - | - | 0.0 | +4.8 | 0.0 | 0.0 |
| SAME CHARGE LATER | 0.1 | -0.8 | 0.0 | 2.0 | 0.1 | -3.0 | 5.2 | 0.0 |
| SCOUT SPOT | 0.3 | +1.0 | 0.0 | 0.0 | 0.2 | +0.7 | 0.0 | 0.0 |
| SCOUT WAITS | 0.4 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.1 | -0.0 | 0.0 | 0.0 | 0.1 | -1.2 | 0.0 | 0.5 |
| SEARCH SPOT | 6.1 | +275.6 | 0.0 | 90.4 | 6.4 | +260.5 | 0.0 | 53.9 |
| SELF MOVE SPELL | 0.3 | +3.2 | 0.0 | 9.1 | 0.3 | +55.5 | 0.0 | 0.0 |
| SET UP TOGETHER | 0.2 | +2.4 | 0.0 | 0.0 | 0.4 | +9.5 | 0.0 | 13.9 |
| SET-UP ANY TARGET | 0.1 | +18.6 | 0.0 | 0.0 | 0.1 | +10.3 | 0.0 | 0.0 |
| SET-UP MISSED | 0.0 | +1.4 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | 0.4 | +0.8 | 0.0 | 0.0 | 0.2 | +0.3 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.2 | +52.1 | 76.5 | 28.0 | 0.7 | +21.8 | 40.8 | 5.9 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| SHOT OR CHARGE | 0.1 | -1.7 | 16.9 | 0.0 | 0.2 | -4.8 | 13.0 | 4.2 |
| SHOT RISK POINTS | 7.2 | -51.9 | 0.0 | 132.3 | 11.3 | +58.8 | 0.0 | 285.5 |
| SHOTS IN THE MOVE | 16.1 | +625.4 | 0.0 | 192.1 | 8.2 | +189.0 | 0.0 | 92.5 |
| SPELL SETS UP CHARGE | 0.1 | +18.6 | 0.0 | 0.0 | 0.1 | +10.3 | 0.0 | 0.0 |
| SPELL WORTH | 1.0 | +10.8 | 32.0 | 32.0 | 1.8 | +33.9 | 47.9 | 47.9 |
| SPELLS IN THE FIGHT | 0.7 | -10.5 | 62.2 | 27.7 | 0.4 | -2.7 | 55.0 | 1.4 |
| STAND AND SHOOT | 0.3 | -2.8 | 39.4 | 0.0 | 0.5 | -7.9 | 33.6 | 6.6 |
| STANDS FOR A REASON | 0.1 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 9.6 | 31.7 |
| STANDS STILL | 17.3 | +0.0 | 802.2 | 220.0 | 10.3 | +0.0 | 180.0 | 135.0 |
| STAY WORTH | 18.9 | +12.2 | 581.5 | 192.3 | 7.8 | +35.4 | 49.7 | 78.6 |
| STOPS | 0.1 | +0.3 | 0.0 | 2.5 | 0.0 | +0.3 | 3.5 | 0.0 |
| STUCK PIVOT | 0.2 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 4.7 |
| SUPPORT NARROWED | 1.2 | +0.0 | 129.1 | 6.2 | 1.1 | +0.0 | 101.5 | 43.2 |
| SURE REACH TOGETHER | 0.3 | +9.6 | 0.0 | 11.1 | 0.4 | +4.4 | 0.0 | 13.9 |
| THE DEARER SUM KEEPS ITS PLAN | 4.4 | +0.0 | 0.0 | 49.1 | 4.1 | +0.0 | 0.0 | 23.2 |
| THE PROMISE ADDS | 0.3 | -29.0 | 21.0 | 2.0 | 0.2 | -18.3 | 0.0 | 0.0 |
| THE PROMISED MOVE | 0.3 | +0.0 | 0.0 | 17.8 | 1.0 | +0.0 | 0.0 | 5.1 |
| TIED UP BY THE SUM | 0.7 | +65.8 | 59.1 | 19.6 | 0.4 | +39.6 | 24.4 | 16.8 |
| TIME ON OUR SIDE | 27.9 | +419.8 | 6.0 | 390.8 | 7.7 | +94.6 | 1.5 | 63.9 |
| WAITS AGAIN | 1.9 | +0.0 | 0.0 | 28.4 | 1.2 | +0.0 | 0.0 | 3.6 |
| WAR ENGINE CHARGES | 0.0 | +9.1 | 0.0 | 0.0 | - | - | - | - |
| WAR ENGINE JOBS | 0.2 | +0.0 | 9.4 | 8.6 | 0.1 | +0.0 | 1.5 | 0.0 |
| WEARS DOWN | - | - | - | - | 0.0 | +0.8 | 0.0 | 0.0 |
| WHO HITS BACK | 0.3 | +72.0 | 0.0 | 5.1 | 0.1 | +11.2 | 0.0 | 1.2 |
| WHOLE FIGHT | 0.4 | +22.8 | 64.4 | 2.5 | 0.4 | +13.0 | 49.4 | 0.0 |
| WHOLE FIGHT GAIN | 0.1 | +8.4 | 10.1 | 1.2 | 0.5 | +25.8 | 57.0 | 4.8 |
| WIDER SPREAD | 2.2 | -2.1 | 226.9 | 47.7 | 2.6 | -3.8 | 247.2 | 52.2 |
| WOUNDS ON THE RANKS | 1.1 | +27.3 | 0.0 | 15.6 | 1.0 | +70.6 | 0.0 | 47.2 |

### Rule changes: h3-opp-efe7e34-p1

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| SEARCH SPOT | 451 | 451 | 430 | 11.94 | +19316 | +44.9 |
| LEGAL CHARGES ONLY | 417 | 417 | 417 | 11.58 | +0 | +0.0 |
| HOLDER ASSIGNMENT | 452 | 452 | 414 | 11.50 | +23469 | +56.7 |
| HIS SHOT LIST | 1365 | 1365 | 383 | 10.64 | +7856 | +20.5 |
| FIVE ACTION | 3271 | 3270 | 335 | 9.31 | +14185 | +42.3 |
| DEPLOY BY FIGURES | 560 | 560 | 325 | 9.03 | +5205 | +16.0 |
| PATHS CROSS | 288 | 288 | 288 | 8.00 | +10008 | +34.7 |
| ONE TARGET A SHOOTER | 1158 | 1158 | 274 | 7.61 | +3025 | +11.0 |
| TIME ON OUR SIDE | 1283 | 1144 | 239 | 6.64 | +643 | +2.7 |
| MOVE TO CHARGE COMPUTED | 284 | 284 | 172 | 4.78 | +14621 | +85.0 |
| FOUR ROUNDS | 259 | 258 | 134 | 3.72 | +8797 | +65.6 |
| MAX FOR POSITIONING | 433 | 423 | 128 | 3.56 | +452 | +3.5 |
| SHOT RISK POINTS | 664 | 664 | 111 | 3.08 | +4648 | +41.9 |
| COVER ONCE | 445 | 367 | 98 | 2.72 | +1471 | +15.0 |
| HARD STAY DROPPED | 84 | 84 | 84 | 2.33 | +0 | +0.0 |
| NEXT OBJECTIVE NEARER | 511 | 511 | 79 | 2.19 | +1327 | +16.8 |
| RANDOM MOVE BY FIGURES | 126 | 126 | 69 | 1.92 | +1694 | +24.6 |
| ARTILLERY RE-ROLL WEIGHED | 60 | 60 | 60 | 1.67 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 59 | 59 | 59 | 1.64 | +15609 | +264.6 |
| SHOTS IN THE MOVE | 873 | 834 | 56 | 1.56 | +1520 | +27.1 |
| ADVANCE LANE KEPT | 53 | 53 | 53 | 1.47 | +0 | +0.0 |
| FALLS SHORT | 823 | 726 | 51 | 1.42 | +351 | +6.9 |
| MARCH CHECK | 77 | 76 | 51 | 1.42 | +798 | +15.6 |
| OFF BEST | 51 | 51 | 51 | 1.42 | -2072 | -40.6 |
| CHARGE NOT DECLARED | 50 | 50 | 50 | 1.39 | -4453 | -89.1 |
| REDIRECT COUNTER | 210 | 168 | 50 | 1.39 | +2895 | +57.9 |
| RISK BY ARC | 169 | 168 | 50 | 1.39 | +1147 | +22.9 |
| LANE BY FIGURES | 49 | 49 | 49 | 1.36 | +1895 | +38.7 |
| MANOEUVRE | 75 | 75 | 49 | 1.36 | +1162 | +23.7 |
| NEXT CHARGE BY LIST | 398 | 398 | 49 | 1.36 | +1045 | +21.3 |
| CHARGE LOSSES | 413 | 413 | 46 | 1.28 | +4815 | +104.7 |
| IDLE COST | 480 | 383 | 46 | 1.28 | +305 | +6.6 |
| SHOOTS FROM THE BEST SPOT | 66 | 66 | 46 | 1.28 | +549 | +11.9 |
| CANNON SIGHT KEPT | 45 | 45 | 45 | 1.25 | +0 | +0.0 |
| RISK BY HIS FIGURE | 1023 | 1023 | 44 | 1.22 | +4744 | +107.8 |
| MISSILES IN THE MOVE | 253 | 217 | 40 | 1.11 | +882 | +22.1 |
| CANNON PLANNED TARGET | 260 | 260 | 39 | 1.08 | -190 | -4.9 |
| HOLDS AMBUSHERS | 36 | 36 | 36 | 1.00 | +0 | +0.0 |
| TIED UP BY THE SUM | 40 | 40 | 33 | 0.92 | +1020 | +30.9 |
| RESERVE FALL BACK | 32 | 32 | 32 | 0.89 | +1812 | +56.6 |
| COMBAT PIVOT | 30 | 30 | 30 | 0.83 | +0 | +0.0 |
| ONE OBJECTIVE FORMULA | 330 | 305 | 30 | 0.83 | +991 | +33.0 |
| LONE WIZARD KEPT IN | 28 | 28 | 28 | 0.78 | +1895 | +67.7 |
| HOLDER AT DEPLOYMENT | 45 | 45 | 27 | 0.75 | +1111 | +41.2 |
| CHARGE NOW FIRST | 132 | 132 | 25 | 0.69 | -1924 | -77.0 |
| MARCH BY THE SUM | 25 | 25 | 25 | 0.69 | +1178 | +47.1 |
| AFTERMATH IN POINTS | 24 | 24 | 24 | 0.67 | +5016 | +209.0 |
| HIS TURN DENIED | 99 | 98 | 22 | 0.61 | +887 | +40.3 |
| NEARER NOT NEEDED | 271 | 258 | 20 | 0.56 | +523 | +26.2 |
| SCOUT WAITS | 20 | 20 | 20 | 0.56 | +0 | +0.0 |
| SHOOTERS IN TWO RANKS | 20 | 20 | 20 | 0.56 | +42 | +2.1 |
| CASTS FROM BEHIND | 19 | 19 | 19 | 0.53 | +0 | +0.0 |
| CAST JOB | 33 | 33 | 17 | 0.47 | +98 | +5.8 |
| STUCK PIVOT | 17 | 17 | 17 | 0.47 | +0 | +0.0 |
| STAY WORTH | 962 | 925 | 16 | 0.44 | +198 | +12.4 |
| MODEL FACING | 15 | 15 | 15 | 0.42 | +3328 | +221.9 |
| ONE FIGHT FORMULA | 414 | 235 | 15 | 0.42 | +38 | +2.6 |
| WHO HITS BACK | 15 | 15 | 15 | 0.42 | +1798 | +119.9 |
| FIGHT TO THE END | 101 | 100 | 14 | 0.39 | +1226 | +87.6 |
| WOUNDS ON THE RANKS | 76 | 76 | 14 | 0.39 | +381 | +27.2 |
| SURE REACH TOGETHER | 27 | 27 | 13 | 0.36 | +12 | +0.9 |
| CHAFF IN THE MOVE | 34 | 28 | 12 | 0.33 | +67 | +5.6 |
| HIS CHARGE DENIED | 24 | 24 | 12 | 0.33 | +367 | +30.6 |
| OVERRUNS AWAY | 35 | 34 | 12 | 0.33 | +392 | +32.7 |
| WHOLE FIGHT GAIN | 23 | 23 | 12 | 0.33 | +215 | +17.9 |
| FIRE IN ORDER | 11 | 11 | 11 | 0.31 | +0 | +0.0 |
| WHOLE FIGHT | 31 | 31 | 11 | 0.31 | +326 | +29.7 |
| GUN MASK | 48 | 48 | 10 | 0.28 | +439 | +43.9 |
| SHORT GUN FORWARD | 10 | 10 | 10 | 0.28 | +0 | +0.0 |
| CASTER AWAY FROM SCREEN | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| OPENS UP | 19 | 19 | 9 | 0.25 | +262 | +29.1 |
| WIDER SPREAD | 174 | 174 | 9 | 0.25 | +31 | +3.5 |
| CHAFF PASSED | 8 | 8 | 8 | 0.22 | -5 | -0.6 |
| REFUSING RETIRES | 13 | 13 | 8 | 0.22 | +3 | +0.4 |
| SUPPORT NARROWED | 85 | 85 | 8 | 0.22 | -248 | -31.0 |
| HIS MOVE AND SHOT | 112 | 112 | 7 | 0.19 | +42 | +6.1 |
| BEST PRIZE | 6 | 6 | 6 | 0.17 | -982 | -163.7 |
| MOVES UNITS SPELL | 6 | 6 | 6 | 0.17 | +133 | +22.2 |
| EDGE GIVE GROUND | 12 | 12 | 5 | 0.14 | +305 | +61.0 |
| NO RALLY LEFT | 5 | 5 | 5 | 0.14 | +125 | +24.9 |
| PIVOT GUARDS FLANK | 5 | 5 | 5 | 0.14 | -380 | -76.1 |
| PURSUES BIG PREY | 5 | 5 | 5 | 0.14 | -452 | -90.3 |
| REDIRECT WEIGHED | 5 | 5 | 5 | 0.14 | +106 | +21.2 |
| RESTRAINS TO SHOOT | 5 | 5 | 5 | 0.14 | +330 | +66.0 |
| SET UP TOGETHER | 24 | 20 | 5 | 0.14 | +46 | +9.2 |
| WAR ENGINE JOBS | 13 | 13 | 5 | 0.14 | -196 | -39.1 |
| FALL BACK GOOD ORDER | 178 | 177 | 4 | 0.11 | +40 | +10.1 |
| FRIENDS SHOTS CHECKED | 4 | 4 | 4 | 0.11 | +128 | +32.0 |
| HUNT IN PAIRS | 18 | 11 | 4 | 0.11 | +192 | +48.0 |
| MISSILES NEXT TURN | 334 | 259 | 4 | 0.11 | +3 | +0.7 |
| BOMBING RUN | 3 | 3 | 3 | 0.08 | +121 | +40.3 |
| BOUND ASSAILMENT | 3 | 3 | 3 | 0.08 | +0 | +0.2 |
| CASTING BLOCK | 3 | 3 | 3 | 0.08 | +12 | +4.1 |
| FALLBACK BY WORTH | 18 | 18 | 3 | 0.08 | +186 | +62.0 |
| FEATURE BUFFS | 43 | 43 | 3 | 0.08 | +27 | +9.0 |
| HONEST WORTH | 212 | 211 | 3 | 0.08 | +17 | +5.7 |
| KEEPS SCOUTS OR AMBUSH | 3 | 3 | 3 | 0.08 | +0 | +0.0 |
| PERIAPT WORTH | 3 | 3 | 3 | 0.08 | +304 | +101.5 |
| BLOWS WHERE AIMED | 11 | 11 | 2 | 0.06 | +20 | +10.0 |
| CATCH ODDS | 2 | 2 | 2 | 0.06 | -26 | -13.2 |
| FOCUS FIRE | 2 | 2 | 2 | 0.06 | +68 | +34.1 |
| SPELLS IN THE FIGHT | 37 | 37 | 2 | 0.06 | +56 | +28.1 |
| BACKUP TARGETS | 24 | 9 | 1 | 0.03 | +5 | +4.6 |
| CARRIES OUT SET-UP | 4 | 4 | 1 | 0.03 | -20 | -20.1 |
| CHARGER SLAIN LOST | 17 | 17 | 1 | 0.03 | +44 | +43.8 |
| DEFENSIVE FLOOR | 2 | 2 | 1 | 0.03 | +127 | +127.1 |
| ELIXIR WORTH | 1 | 1 | 1 | 0.03 | +7 | +6.7 |
| FIRE AND FLEE | 1 | 1 | 1 | 0.03 | +8 | +8.0 |
| KILLS COUNT | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| NEEDED THERE | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| NO DOUBLE ROUNDS | 196 | 195 | 1 | 0.03 | +16 | +16.4 |
| REDIRECT BY WHAT IT STOPS | 13 | 13 | 1 | 0.03 | +37 | +36.7 |
| SAFER THAN THE JOB | 1 | 1 | 1 | 0.03 | +173 | +173.2 |
| THE PROMISE ADDS | 20 | 20 | 1 | 0.03 | +3 | +3.3 |
| ALREADY CARRIED | 1 | not checked | - | - | - | - |
| ARRIVAL HUNT | 2 | 2 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 36 | 36 | 0 | 0.00 | - | - |
| CARRIES OUT COUNTER | 1 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 42 | trace | - | - | - | - |
| CATCH FLIERS | 5 | not checked | - | - | - | - |
| CHAMPION TAKES THE CHALLENGE | 2 | 2 | 0 | 0.00 | - | - |
| CHARACTER GUNS | 34 | 34 | 0 | 0.00 | - | - |
| CHEAP HELPER | 9 | not checked | - | - | - | - |
| CHEAPEST HOLDER | 9 | 9 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 32 | not checked | - | - | - | - |
| DEFENSIVE ARMY | 3 | 3 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 6 | 6 | 0 | 0.00 | - | - |
| FIGHT LIFT | 6 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 404 | not checked | - | - | - | - |
| FRIEND CHARGES FIRST | 13 | 13 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 25 | 25 | 0 | 0.00 | - | - |
| GIVES UP | 18 | 17 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 1 | 1 | 0 | 0.00 | - | - |
| GROUND FLIERS | 1 | not checked | - | - | - | - |
| GUN FIGURES | 66 | not checked | - | - | - | - |
| HE SHOOTS OR CHARGES | 137 | 137 | 0 | 0.00 | - | - |
| HELPER ALREADY ASKED | 2 | not checked | - | - | - | - |
| HELPER UNSEEN | 4 | 4 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 186 | 186 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 300 | 300 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 219 | 219 | 0 | 0.00 | - | - |
| HOLD ODDS | 222 | 222 | 0 | 0.00 | - | - |
| HUNT KEPT | 1 | trace | - | - | - | - |
| HUNT RESULT | 2 | trace | - | - | - | - |
| HUNT THE GUNS | 3 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 9 | 9 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 8 | not checked | - | - | - | - |
| LONG SHOT | 10 | 10 | 0 | 0.00 | - | - |
| LOST CHARGE | 4 | 3 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 3 | 3 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 11 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 8 | trace | - | - | - | - |
| MARCH OVER CASTS | 57 | 57 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 7 | 5 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 27 | trace | - | - | - | - |
| MOVE SPELL SPOT | 22 | not checked | - | - | - | - |
| NOT TURNED | 12 | 12 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 55 | not checked | - | - | - | - |
| ONE CHARGE A CHARGER | 240 | 240 | 0 | 0.00 | - | - |
| OPENS A LANE | 4 | 3 | 0 | 0.00 | - | - |
| PLAN RESULT | 2913 | trace | - | - | - | - |
| REFORMS TO MEET IT | 54 | 54 | 0 | 0.00 | - | - |
| RUN DOWN | 153 | 152 | 0 | 0.00 | - | - |
| SAME CHARGE LATER | 7 | 7 | 0 | 0.00 | - | - |
| SCOUT SPOT | 18 | 18 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 4 | 4 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 22 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 8 | not checked | - | - | - | - |
| SET-UP MISSED | 1 | trace | - | - | - | - |
| SHOT OR CHARGE | 10 | 10 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 8 | not checked | - | - | - | - |
| SPELL WORTH | 101 | not checked | - | - | - | - |
| STAND AND SHOOT | 31 | 30 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 30 | 30 | 0 | 0.00 | - | - |
| STANDS STILL | 994 | 994 | 0 | 0.00 | - | - |
| STOPS | 3 | 3 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 309 | not checked | - | - | - | - |
| THE PROMISED MOVE | 47 | not checked | - | - | - | - |
| WAITS AGAIN | 110 | 110 | 0 | 0.00 | - | - |
| WAR ENGINE CHARGES | 1 | 1 | 0 | 0.00 | - | - |
| WEARS DOWN | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: h3-opp-efe7e34-p1

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| CHARGE NOT DECLARED | rule | 0.61 | 0.58 | 106.3 |
| HOLDER ASSIGNMENT | rule | - | 1.08 | 27.3 |
| PATHS CROSS | rule | 0.53 | 0.53 | 37.0 |
| JOB FIRST | gate | 0.11 | 0.89 | 23.6 |
| CHARGE NOW FIRST | rule | 0.25 | 0.44 | 77.0 |
| SUPPORT NARROWED | rule | 0.11 | 0.08 | 35.3 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.14 | 0.03 | 193.8 |
| BEST PRIZE | rule | 0.06 | 0.11 | 163.7 |
| CANNON PLANNED TARGET | rule | 0.11 | 0.06 | 36.3 |
| PIVOT GUARDS FLANK | rule | 0.08 | 0.06 | 76.1 |
| PURSUES BIG PREY | rule | 0.06 | 0.08 | 90.3 |
| WAR ENGINE JOBS | rule | 0.06 | 0.06 | 48.9 |
| CHAFF PASSED | rule | 0.06 | 0.03 | 1.7 |
| FIGHT ORDER BAND | gate | 0.08 | - | 3.3 |
| AFTERMATH BAND | gate | - | 0.06 | 2.7 |
| DEPLOY BY FIGURES | rule | - | 0.06 | 6.0 |
| LONE CHARACTER SAFE SPOT | gate | 0.03 | 0.03 | 9.3 |
| CARRIES OUT SET-UP | rule | - | 0.03 | 20.1 |
| CATCH ODDS | rule | - | 0.03 | 26.1 |
| FALLBACK | gate | - | 0.03 | 13.9 |
| REDIRECT WEIGHED | rule | - | 0.03 | 60.5 |
| RULE SWITCHED OFF | gate | 0.03 | - | 11.1 |

### Plans: h3-opp-efe7e34-p1

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 2.6 | 66% | 464 | 278 | 60% |
| Mine | join | 0.6 | 95% | 20 | 0 | 0% |
| Mine | move | 29.8 | 95% | 1809 | 0 | 0% |
| Mine | shoot | 8.7 | 59% | 381 | 786 | 206% |
| Mine | support | 0.1 | 75% | 1 | 0 | 0% |
| Opponent | charge | 3.3 | 59% | 496 | 314 | 63% |
| Opponent | join | 1.1 | 98% | 54 | 0 | 0% |
| Opponent | move | 30.9 | 94% | 1464 | 0 | 0% |
| Opponent | shoot | 3.4 | 61% | 87 | 163 | 187% |
| Opponent | support | 0.4 | 85% | 12 | 0 | 0% |

### Packages: hunt the guns, h3-opp-efe7e34-p1

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.1 | 2 | 1 | 0% | 0% | 0% | - | 467 | 0 | 0% | 19 |
| Opponent | 0.0 | 1 | 0 | 100% | 100% | 0% | 2.0 | 505 | 429 | 100% | 91 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 44 |
| Dwarfen Mountain Holds | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 467 | 0 | 0% | 44 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 96 |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 19 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 236 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Ogre Kingdoms | 1.0 | 2 | 1 | 100% | 100% | 0% | 2.0 | 505 | 429 | 100% | 210 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 66 |
| Tomb Kings of Khemri | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 23 |
| Vampire Counts | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 39 |
| Warriors of Chaos | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 48 |
| Wood Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 200 |

### Battle groups: h3-opp-efe7e34-p1

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 2.2 | 28% | 59% | 14% | 33% | 32% | 0% | 0% | 68% | 0% |
| Opponent | REDIRECT COUNTER | 3.6 | 20% | 73% | 19% | 0% | 14% | 0% | 0% | 71% | 14% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: h3-opp-efe7e34-p1

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 6 | 0 (6) | 0 | 0 | 87 | 33% | 3.0 | - | 0 (2) | - | - | 0 (2) |
| Mine | Chaff | 35 | 93 (35) | 6 | 87 | 52 | 31% | 2.7 | 124 (9) | 100 (16) | 46 (10) | 121 (27) | 0 (8) |
| Mine | Character | 117 | 42 (117) | 42 | 0 | 32 | 17% | 2.5 | 45 (32) | 42 (53) | 46 (23) | 37 (67) | 55 (41) |
| Mine | Clean-up | 26 | 53 (26) | 3 | 50 | 30 | 42% | 3.8 | 18 (13) | 120 (10) | 0 (3) | 63 (17) | 40 (9) |
| Mine | Fast | 3 | 0 (3) | 0 | 0 | 67 | 0% | 1.3 | - | 0 (1) | 0 (2) | 0 (2) | 0 (1) |
| Mine | Fast Hammer | 40 | 74 (40) | 43 | 31 | 21 | 28% | 3.6 | 94 (10) | 72 (25) | 23 (5) | 91 (21) | 43 (19) |
| Mine | Fragile | 1 | 98 (1) | 98 | 0 | 0 | 0% | 6.0 | - | 98 (1) | - | - | 98 (1) |
| Mine | Hammer | 54 | 36 (54) | 15 | 21 | 37 | 19% | 2.6 | 35 (14) | 51 (23) | 15 (17) | 24 (27) | 48 (27) |
| Mine | Holder | 24 | 57 (24) | 8 | 49 | 27 | 46% | 3.5 | 77 (5) | 71 (13) | 0 (6) | 66 (14) | 41 (10) |
| Mine | Shooter | 42 | 88 (42) | 27 | 61 | 27 | 7% | 2.0 | 76 (12) | 117 (22) | 34 (8) | 112 (31) | 18 (11) |
| Mine | Support | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | 0 (1) | - | - | - | 0 (1) |
| Mine | War machine | 60 | 46 (60) | 46 | 0 | 36 | 2% | 1.4 | 43 (22) | 40 (26) | 61 (12) | 97 (11) | 35 (49) |
| Mine | Wizard | 24 | 26 (24) | 26 | 0 | 40 | 12% | 2.5 | 64 (7) | 12 (8) | 0 (5) | 66 (8) | 9 (12) |
| Opponent | Chaff | 69 | 70 (69) | 9 | 61 | 49 | 39% | 2.9 | 75 (28) | 79 (17) | 54 (24) | 81 (53) | 35 (16) |
| Opponent | Character | 106 | 44 (106) | 44 | 0 | 31 | 33% | 2.5 | 35 (31) | 32 (51) | 108 (16) | 43 (63) | 51 (35) |
| Opponent | Clean-up | 28 | 69 (28) | 28 | 41 | 14 | 46% | 3.9 | 37 (9) | 95 (16) | 43 (3) | 51 (18) | 95 (10) |
| Opponent | Early | 1 | 0 (1) | 0 | 0 | 0 | 0% | 4.0 | - | 0 (1) | - | - | 0 (1) |
| Opponent | Fast | 2 | 0 (2) | 0 | 0 | 50 | 0% | 2.0 | 0 (1) | 0 (1) | - | 0 (2) | - |
| Opponent | Fast Hammer | 44 | 47 (44) | 21 | 26 | 42 | 34% | 3.0 | 37 (12) | 48 (25) | 70 (7) | 55 (25) | 37 (19) |
| Opponent | Fragile | 2 | 45 (2) | 45 | 0 | 0 | 50% | 1.0 | - | - | 80 (1) | 80 (1) | - |
| Opponent | Hammer | 53 | 33 (53) | 20 | 14 | 34 | 26% | 3.2 | 62 (8) | 26 (35) | 46 (10) | 38 (28) | 29 (25) |
| Opponent | Holder | 39 | 79 (39) | 2 | 78 | 8 | 62% | 3.7 | 84 (14) | 75 (21) | 94 (4) | 110 (16) | 53 (23) |
| Opponent | Shooter | 26 | 55 (26) | 33 | 22 | 44 | 15% | 1.8 | 27 (6) | 72 (13) | 42 (7) | 71 (14) | 35 (12) |
| Opponent | Support | 2 | 0 (2) | 0 | 0 | 66 | 50% | 5.0 | - | 0 (2) | - | - | 0 (2) |
| Opponent | War machine | 16 | 36 (16) | 36 | 0 | 29 | 12% | 1.6 | 113 (3) | 0 (3) | 29 (10) | 124 (4) | 14 (12) |
| Opponent | Wizard | 24 | 11 (24) | 11 | 0 | 52 | 12% | 2.4 | 38 (6) | 8 (7) | 0 (5) | 37 (8) | 0 (10) |

### Charged fights: h3-opp-efe7e34-p1

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 16 | 28 | 0.8 | 1.0 | 37 | 17 | +19 | 0 of 3 | 2 of 3 | - | +19 |
| Mine | Chaos Dwarfs | 4 | 148 | 153 | 2.0 | 1.0 | 76 | 72 | +4 | 5 of 8 | 8 of 8 | - | +4 |
| Mine | Dwarfen Mountain Holds | 4 | 379 | 24 | 1.0 | 1.0 | 24 | 0 | +24 | 1 of 4 | 1 of 4 | - | +24 |
| Mine | Empire of Man | 5 | 337 | 201 | 1.4 | 1.1 | 144 | 15 | +129 | 2 of 7 | 4 of 7 | +228 | +113 |
| Mine | Grand Cathay | 4 | 230 | 482 | 4.0 | 1.1 | 120 | 0 | +120 | 2 of 16 | 14 of 16 | +446 | +99 |
| Mine | High Elf Realms | 4 | 97 | 1030 | 3.8 | 1.1 | 275 | 72 | +202 | 6 of 15 | 12 of 15 | +74 | +222 |
| Mine | Kingdom of Bretonnia | 1 | 0 | 246 | 4.0 | 1.0 | 62 | 0 | +62 | 0 of 4 | 3 of 4 | - | +62 |
| Mine | Lizardmen | 1 | 0 | 453 | 4.0 | 1.2 | 113 | 0 | +113 | 2 of 4 | 4 of 4 | +453 | +0 |
| Mine | Ogre Kingdoms | 1 | 0 | 0 | 3.0 | 2.0 | 0 | 135 | -135 | 3 of 3 | 2 of 3 | -202 | +0 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 339 | 5.0 | 1.0 | 68 | 0 | +68 | 1 of 5 | 4 of 5 | - | +68 |
| Mine | Skaven | 2 | 22 | 56 | 1.5 | 1.3 | 37 | 0 | +37 | 0 of 3 | 1 of 3 | +111 | +0 |
| Mine | Tomb Kings of Khemri | 1 | 19 | 712 | 4.0 | 1.2 | 178 | 0 | +178 | 0 of 4 | 2 of 4 | +144 | +189 |
| Mine | Vampire Counts | 3 | 72 | 489 | 6.7 | 1.1 | 73 | 16 | +57 | 10 of 20 | 11 of 18 | +25 | +63 |
| Mine | Warriors of Chaos | 1 | 0 | 1286 | 2.0 | 1.0 | 643 | 0 | +643 | 1 of 2 | 2 of 2 | - | +643 |
| **Mine** | all armies | 36 | 151 | 347 | 2.7 | 1.1 | 127 | 26 | +101 | 33 of 98 | 70 of 96 | +100 | +102 |
| Opponent | Chaos Dwarfs | 3 | 40 | 216 | 3.3 | 1.0 | 65 | 0 | +65 | 8 of 10 | 3 of 10 | - | +65 |
| Opponent | Dwarfen Mountain Holds | 1 | 310 | 120 | 3.0 | 1.3 | 40 | 0 | +40 | 0 of 3 | 2 of 3 | +120 | +0 |
| Opponent | Grand Cathay | 1 | 65 | 1032 | 3.0 | 1.7 | 344 | 0 | +344 | 1 of 3 | 3 of 3 | +725 | +154 |
| Opponent | High Elf Realms | 2 | 256 | 883 | 5.5 | 1.2 | 161 | 0 | +161 | 4 of 11 | 9 of 11 | +175 | +157 |
| Opponent | Kingdom of Bretonnia | 1 | 150 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Ogre Kingdoms | 1 | 0 | 125 | 2.0 | 1.0 | 62 | 0 | +62 | 1 of 2 | 1 of 2 | - | +62 |
| Opponent | Orc & Goblin Tribes | 1 | 0 | 420 | 5.0 | 1.4 | 84 | 11 | +73 | 1 of 5 | 4 of 5 | +42 | +93 |
| Opponent | Skaven | 3 | 133 | 121 | 1.0 | 1.0 | 121 | 0 | +121 | 3 of 3 | 2 of 3 | - | +121 |
| Opponent | Tomb Kings of Khemri | 2 | 60 | 500 | 4.5 | 1.0 | 111 | 60 | +51 | 2 of 9 | 8 of 9 | - | +51 |
| Opponent | Vampire Counts | 9 | 37 | 639 | 4.7 | 1.1 | 137 | 28 | +108 | 20 of 42 | 26 of 42 | -18 | +122 |
| Opponent | Warriors of Chaos | 9 | 21 | 73 | 1.4 | 1.1 | 51 | 11 | +40 | 4 of 13 | 9 of 13 | -144 | +55 |
| Opponent | Wood Elf Realms | 3 | 87 | 334 | 3.3 | 1.4 | 100 | 3 | +97 | 3 of 10 | 9 of 10 | +136 | +72 |
| **Opponent** | all armies | 36 | 68 | 358 | 3.1 | 1.1 | 116 | 18 | +98 | 47 of 111 | 76 of 111 | +107 | +97 |

### Effective charges: h3-opp-efe7e34-p1

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 3 | 1 (net -52) | 0 | 1 (net +0) | 0 | 0 | 1 (net +110) | 0 | 33% (1 of 3) |
| Mine | Chaos Dwarfs | 8 | 0 | 0 | 1 (net +0) | 3 (net -158) | 1 (net +66) | 3 (net +147) | 0 | 12% (1 of 8) |
| Mine | Dwarfen Mountain Holds | 4 | 2 (net +0) | 0 | 1 (net +0) | 0 | 0 | 1 (net +98) | 0 | 25% (1 of 4) |
| Mine | Empire of Man | 7 | 3 (net +217) | 0 | 1 (net +0) | 3 (net +85) | 0 | 0 | 0 | 14% (1 of 7) |
| Mine | Grand Cathay | 16 | 0 | 0 | 2 (net +223) | 5 (net +190) | 4 (net +54) | 5 (net +64) | 0 | 12% (2 of 16) |
| Mine | High Elf Realms | 15 | 2 (net +641) | 0 | 1 (net +743) | 2 (net +49) | 2 (net -94) | 7 (net +178) | 1 | 7% (1 of 14) |
| Mine | Kingdom of Bretonnia | 4 | 2 (net +30) | 0 | 0 | 0 | 0 | 2 (net +93) | 0 | 0% (0 of 4) |
| Mine | Lizardmen | 4 | 0 | 0 | 2 (net +226) | 0 | 1 (net +0) | 1 (net +0) | 0 | 50% (2 of 4) |
| Mine | Ogre Kingdoms | 3 | 1 (net +0) | 0 | 0 | 0 | 0 | 2 (net -202) | 0 | 0% (0 of 3) |
| Mine | Orc & Goblin Tribes | 5 | 1 (net +0) | 0 | 0 | 0 | 1 (net +60) | 0 | 3 | 0% (0 of 2) |
| Mine | Skaven | 3 | 1 (net +0) | 0 | 1 (net +0) | 1 (net +111) | 0 | 0 | 0 | 33% (1 of 3) |
| Mine | Tomb Kings of Khemri | 4 | 0 | 0 | 0 | 1 (net +104) | 0 | 3 (net +203) | 0 | 0% (0 of 4) |
| Mine | Vampire Counts | 20 | 8 (net +79) | 1 (net +0) | 2 (net +62) | 2 (net +106) | 6 (net +29) | 1 (net +0) | 0 | 10% (2 of 20) |
| Mine | Warriors of Chaos | 2 | 0 | 0 | 0 | 2 (net +643) | 0 | 0 | 0 | 0% (0 of 2) |
| Opponent | Chaos Dwarfs | 10 | 5 (net +67) | 0 | 1 (net +0) | 0 | 0 | 2 (net +115) | 2 | 12% (1 of 8) |
| Opponent | Dwarfen Mountain Holds | 3 | 1 (net +0) | 0 | 1 (net +0) | 0 | 1 (net +120) | 0 | 0 | 33% (1 of 3) |
| Opponent | Grand Cathay | 3 | 0 | 0 | 1 (net +190) | 2 (net +421) | 0 | 0 | 0 | 33% (1 of 3) |
| Opponent | High Elf Realms | 11 | 1 (net +0) | 0 | 0 | 2 (net +50) | 2 (net +114) | 6 (net +240) | 0 | 0% (0 of 11) |
| Opponent | Ogre Kingdoms | 2 | 1 (net +125) | 0 | 0 | 0 | 0 | 0 | 1 | 0% (0 of 1) |
| Opponent | Orc & Goblin Tribes | 5 | 0 | 0 | 0 | 0 | 3 (net +140) | 1 (net +0) | 1 | 0% (0 of 4) |
| Opponent | Skaven | 3 | 1 (net +0) | 0 | 0 | 0 | 0 | 1 (net +364) | 1 | 0% (0 of 2) |
| Opponent | Tomb Kings of Khemri | 9 | 0 | 0 | 3 (net -85) | 2 (net +146) | 1 (net +0) | 3 (net +141) | 0 | 33% (3 of 9) |
| Opponent | Vampire Counts | 42 | 13 (net +74) | 0 | 7 (net +188) | 10 (net +62) | 3 (net +77) | 7 (net +147) | 2 | 18% (7 of 40) |
| Opponent | Warriors of Chaos | 13 | 3 (net +0) | 1 (net +0) | 1 (net -144) | 2 (net +200) | 0 | 5 (net +51) | 1 | 8% (1 of 12) |
| Opponent | Wood Elf Realms | 10 | 1 (net -27) | 0 | 2 (net +28) | 2 (net +252) | 1 (net +77) | 3 (net +121) | 1 | 22% (2 of 9) |

### Charged fights, damage counted: h3-opp-efe7e34-p1

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 21 | 193 | 331 | +123 | 161 | 30 | +131 | +67.9 |
| Mine | 50-54% | 1 | 147 | 499 | +0 | 0 | 0 | +0 | +0.0 |
| Mine | Effective (55-75%) | 12 | 310 | 234 | +147 | 167 | 8 | +159 | +51.3 |
| Mine | 76-89% | 19 | 328 | 170 | +134 | 213 | 64 | +149 | +45.3 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 26 | 279 | 192 | +100 | 134 | 24 | +110 | +39.5 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 15 | 303 | 66 | +22 | 59 | 33 | +25 | +8.4 |
| Mine | No odds | 4 | 224 | 128 | +34 | 91 | 47 | +44 | +19.7 |
| Mine | All fights | 98 | 274 | 204 | +101 | 144 | 33 | +111 | +40.6 |
| Opponent | Long shot (under 50%) | 26 | 226 | 250 | +54 | 85 | 34 | +51 | +22.4 |
| Opponent | 50-54% | 1 | 30 | 50 | +0 | 0 | 0 | +0 | +0.0 |
| Opponent | Effective (55-75%) | 16 | 258 | 176 | +73 | 155 | 76 | +79 | +30.6 |
| Opponent | 76-89% | 20 | 353 | 208 | +138 | 191 | 54 | +137 | +38.8 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 28 | 274 | 192 | +147 | 158 | 23 | +135 | +49.3 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 11 | 399 | 97 | +98 | 105 | 1 | +104 | +26.1 |
| Opponent | No odds | 9 | 161 | 232 | +47 | 66 | 31 | +35 | +22.0 |
| Opponent | All fights | 111 | 275 | 198 | +98 | 132 | 37 | +95 | +34.5 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| h3-opp-efe7e34-p1 | move | 301 | 69 (23%) | 55 (18%) | 37 (12%) | 195 (65%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0103, L0120, L2425, L2532, L2732 |
| Charmed Shield | Opponent | L0525, L0734, L0824, L1225, L1627, L1724, L1824, L1924, L2025, L2425 |
| Clockwork Compass | Mine | L1225 |
| Elixir of Power | Mine | L1116, L1131, L1924 |
| Elixir of Power | Opponent | L0219 |
| Fistful of Laurels | Mine | L1824 |
| Fistful of Laurels | Opponent | L0718 |
| Horn of the Wild Hunt | Opponent | L2233 |
| Invocation of Nehek | Mine | L2425, L2532, L2732 |
| Invocation of Nehek | Opponent | L0525, L0824, L1225, L1627, L1724, L1824, L1924, L2025, L2425 |
| Opal Amulet | Mine | L1431 |
| Periapt of Soul Exchange | Mine | L2025, L2128 |
| Periapt of Soul Exchange | Opponent | L0120, L0321, L1320 |
| Ring of Doom | Mine | L0204, L0219, L1116, L1131, L1225, L1528 |
| Ring of Doom | Opponent | L0915, L0931, L1131, L1431, L2233, L3031 |
| Ring of Jet | Mine | L1023, L1116, L1131, L1225 |
| Ring of Jet | Opponent | L0510 |
| Standard of the Fell Warrior | Mine | L1320, L1335 |
| Standard of the Fell Warrior | Opponent | L0613 |
| Storm Daemon (Renegade 2.0) | Mine | L2128 |
| Storm Daemon (Renegade 2.0) | Opponent | L0321 |
| Twice-Blessed Armour | Mine | L0718, L0734, L1023 |
| Twice-Blessed Armour | Opponent | L0510 |
| Witch Hunter's Ward | Mine | L0718, L0734, L0824 |

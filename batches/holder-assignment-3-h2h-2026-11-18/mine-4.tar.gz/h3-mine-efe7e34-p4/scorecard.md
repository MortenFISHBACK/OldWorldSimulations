# Doctrine scorecard: h3-mine-efe7e34-p4

### Scorecard: h3-mine-efe7e34-p4

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0115 | 1 | 1 | Mine | no | 10 | - | 0 | 2 | 0 | 0 | 0 | 0 |
| L0115 | 1 | 1 | Opponent | yes | 3 | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L0132 | 6 | 1 | Mine | no | 14 | - | 0 | 2 | 0 | 0 | 0 | 0 |
| L0132 | 6 | 1 | Opponent | no | 3 | 3 | 4 | 4 | 1 | 0 | 0 | 170 |
| L0216 | 6 | 1 | Mine | no | 0 | - | 0 | 7 | 0 | 0 | 0 | 222 |
| L0216 | 6 | 1 | Opponent | no | 2 | 2 | 1 | 1 | 1 | 0 | 0 | 0 |
| L0232 | 4 | 1 | Mine | no | 1 | 3 | 1 | 1 | 0 | 0 | 0 | 170 |
| L0232 | 4 | 1 | Opponent | no | 0 | 2 | 2 | 1 | 0 | 0 | 0 | 170 |
| L0316 | 4 | 1 | Mine | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 370 |
| L0316 | 4 | 1 | Opponent | no | 6 | 3 | 2 | 2 | 0 | 0 | 0 | 0 |
| L0333 | 3 | 1 | Mine | no | 5 | - | 0 | 0 | 0 | 0 | 0 | 110 |
| L0333 | 3 | 1 | Opponent | yes | 4 | 3 | 3 | 4 | 0 | 0 | 0 | 0 |
| L0420 | 6 | 1 | Mine | no | 6 | 2 | 1 | 2 | 0 | 0 | 0 | 310 |
| L0420 | 6 | 1 | Opponent | no | 0 | 6 | 1 | 2 | 2 | 0 | 0 | 485 |
| L0435 | 3 | 1 | Mine | no | 0 | 4 | 1 | 1 | 0 | 0 | 0 | 0 |
| L0435 | 3 | 1 | Opponent | no | 0 | 4 | 4 | 1 | 0 | 0 | 0 | 0 |
| L0522 | 6 | 1 | Mine | no | 4 | - | 0 | 1 | 0 | 0 | 0 | 383 |
| L0522 | 6 | 1 | Opponent | no | 2 | 2 | 6 | 1 | 1 | 0 | 0 | 0 |
| L0609 | 3 | 1 | Mine | yes | 1 | - | 1 | 4 | 0 | 0 | 0 | 220 |
| L0609 | 3 | 1 | Opponent | no | 0 | - | 1 | 1 | 0 | 0 | 0 | 125 |
| L0625 | 1 | 1 | Mine | no | 1 | - | 0 | 1 | 0 | 0 | 0 | 280 |
| L0625 | 1 | 1 | Opponent | yes | 6 | 3 | 4 | 2 | 0 | 0 | 0 | 0 |
| L0714 | 6 | 1 | Mine | no | 2 | 2 | 5 | 0 | 0 | 0 | 0 | 125 |
| L0714 | 6 | 1 | Opponent | no | 8 | 2 | 4 | 1 | 0 | 0 | 0 | 177 |
| L0730 | 4 | 1 | Mine | no | 5 | 6 | 3 | 1 | 0 | 0 | 0 | 314 |
| L0730 | 4 | 1 | Opponent | no | 6 | 2 | 2 | 3 | 0 | 0 | 0 | 0 |
| L0820 | 4 | 1 | Mine | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 336 |
| L0820 | 4 | 1 | Opponent | no | 4 | 5 | 3 | 3 | 1 | 0 | 0 | 210 |
| L0910 | 4 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 170 |
| L0910 | 4 | 1 | Opponent | no | 5 | 3 | 1 | 1 | 0 | 0 | 0 | 165 |
| L0927 | 3 | 1 | Mine | no | 0 | 4 | 1 | 1 | 0 | 0 | 0 | 518 |
| L0927 | 3 | 1 | Opponent | no | 3 | 1 | 6 | 3 | 0 | 0 | 0 | 0 |
| L1020 | 6 | 1 | Mine | no | 14 | 3 | 5 | 0 | 0 | 0 | 0 | 0 |
| L1020 | 6 | 1 | Opponent | no | 0 | - | 0 | 5 | 0 | 0 | 0 | 0 |
| L1035 | 3 | 1 | Mine | no | 2 | 2 | 2 | 0 | 0 | 0 | 0 | 205 |
| L1035 | 3 | 1 | Opponent | no | 2 | 2 | 3 | 2 | 0 | 0 | 0 | 0 |
| L1128 | 6 | 1 | Mine | no | 10 | 3 | 2 | 0 | 0 | 0 | 0 | 0 |
| L1128 | 6 | 1 | Opponent | no | 2 | 6 | 0 | 0 | 0 | 0 | 0 | 287 |
| L1221 | 3 | 1 | Mine | no | 7 | 2 | 4 | 0 | 1 | 0 | 0 | 165 |
| L1221 | 3 | 1 | Opponent | yes | 3 | - | 0 | 2 | 1 | 0 | 0 | 355 |
| L1315 | 1 | 1 | Mine | yes | 10 | 2 | 2 | 1 | 1 | 0 | 0 | 247 |
| L1315 | 1 | 1 | Opponent | yes | 1 | 3 | 1 | 0 | 1 | 0 | 0 | 176 |
| L1332 | 6 | 1 | Mine | no | 11 | 2 | 4 | 0 | 0 | 0 | 0 | 70 |
| L1332 | 6 | 1 | Opponent | no | 2 | 3 | 6 | 3 | 1 | 0 | 0 | 170 |
| L1428 | 6 | 1 | Mine | no | 3 | 2 | 4 | 3 | 0 | 0 | 0 | 286 |
| L1428 | 6 | 1 | Opponent | no | 6 | - | 0 | 1 | 0 | 0 | 0 | 0 |
| L1524 | 6 | 1 | Mine | no | 6 | 4 | 1 | 0 | 1 | 0 | 0 | 0 |
| L1524 | 6 | 1 | Opponent | no | 7 | 2 | 6 | 1 | 1 | 0 | 0 | 0 |
| L1622 | 2 | 1 | Mine | - | - | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L1622 | 2 | 1 | Opponent | - | - | 1 | 6 | 0 | 1 | 0 | 0 | 0 |
| L1720 | 4 | 1 | Mine | yes | 1 | 2 | 5 | 0 | 1 | 0 | 0 | 0 |
| L1720 | 4 | 1 | Opponent | no | 0 | 3 | 1 | 2 | 0 | 0 | 0 | 210 |
| L1820 | 2 | 1 | Mine | - | - | 5 | 4 | 1 | 0 | 0 | 0 | 0 |
| L1820 | 2 | 1 | Opponent | - | - | - | 0 | 6 | 1 | 0 | 0 | 275 |
| L1920 | 6 | 1 | Mine | no | 6 | 2 | 4 | 2 | 0 | 0 | 0 | 0 |
| L1920 | 6 | 1 | Opponent | no | 2 | - | 0 | 2 | 0 | 0 | 0 | 1028 |
| L2022 | 6 | 1 | Mine | no | 10 | - | 0 | 1 | 1 | 0 | 0 | 420 |
| L2022 | 6 | 1 | Opponent | no | 0 | 2 | 5 | 0 | 0 | 0 | 0 | 0 |
| L2125 | 1 | 1 | Mine | no | 0 | - | 0 | 5 | 0 | 0 | 0 | 330 |
| L2125 | 1 | 1 | Opponent | no | 0 | 4 | 3 | 3 | 0 | 0 | 0 | 0 |
| L2228 | 2 | 1 | Mine | - | - | 1 | 3 | 2 | 0 | 0 | 0 | 72 |
| L2228 | 2 | 1 | Opponent | - | - | - | 1 | 1 | 1 | 0 | 0 | 127 |
| L2332 | 4 | 1 | Mine | no | 0 | 2 | 6 | 0 | 0 | 0 | 0 | 0 |
| L2332 | 4 | 1 | Opponent | no | 1 | 3 | 3 | 2 | 1 | 0 | 0 | 170 |
| L2528 | 2 | 1 | Mine | - | - | 2 | 2 | 3 | 1 | 0 | 0 | 168 |
| L2528 | 2 | 1 | Opponent | - | - | 2 | 2 | 0 | 0 | 0 | 0 | 41 |
| L2635 | 1 | 1 | Mine | no | 11 | 2 | 3 | 3 | 0 | 0 | 0 | 0 |
| L2635 | 1 | 1 | Opponent | no | 0 | 1 | 4 | 2 | 0 | 0 | 0 | 0 |
| L2931 | 3 | 1 | Mine | no | 7 | 2 | 3 | 2 | 1 | 0 | 0 | 200 |
| L2931 | 3 | 1 | Opponent | no | 0 | - | 2 | 1 | 3 | 0 | 0 | 456 |
| L3334 | 4 | 1 | Mine | no | 1 | 2 | 3 | 2 | 0 | 0 | 0 | 352 |
| L3334 | 4 | 1 | Opponent | no | 0 | 2 | 3 | 4 | 0 | 0 | 0 | 107 |
| **Average** | | | Mine | 9% | 4.6 | 2.6 | 2.1 | 1.5 | 0.2 | 0.0 | 0.0 | 167.9 |
| **Average** | | | Opponent | 16% | 2.4 | 2.8 | 2.6 | 1.9 | 0.5 | 0.0 | 0.0 | 136.2 |

### KPIs: h3-mine-efe7e34-p4

Rules off - Opponent only: HOLDER ASSIGNMENT.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 36% (60 of 168) | 0% (0 of 173) | 18% (60 of 341) |
| Winner chose to follow up after the loser gave ground |  | 78% (47 of 60); on the table 85% | 88% (28 of 32); on the table 94% | 82% (75 of 92); on the table 88% |
| Winner chose to pursue after the loser fell back in good order |  | 100% (5 of 5); on the table 100% | 75% (9 of 12); on the table 92% | 82% (14 of 17); on the table 94% |
| Winner chose to pursue after the loser fled |  | 79% (19 of 24); on the table 88% | 90% (26 of 29); on the table 90% | 85% (45 of 53); on the table 89% |
| Winner chose to follow up or pursue (all three) |  | 80% (71 of 89); on the table 87% | 86% (63 of 73); on the table 92% | 83% (134 of 162); on the table 89% |
| Magic missiles tried each own turn | 50%+ | 34% (114 of 336) | 29% (53 of 180) | 32% (167 of 516) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 45% (114 of 255) | 42% (53 of 127) | 44% (167 of 382) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 60% (15 of 25) | 50% (52 of 105) | 52% (67 of 130) |
| Points that never fought | lower | 47% (33266 of 70036) | 45% (32209 of 71981) | 46% (65475 of 142017) |
|   infantry points that never fought | lower | 55% (8807 of 16041) | 73% (10799 of 14728) | 64% (19606 of 30769) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 55% (154 of 281) | 53% (148 of 280) | 54% (302 of 561) |
| Bound items with a magic missile used (at least once a game) |  | 87% (20 of 23); 1.9 uses a game | 69% (9 of 13); 0.9 uses a game | 81% (29 of 36); 1.4 uses a game |
| Bound items with another spell used |  | 38% (6 of 16); 0.3 uses a game | 29% (2 of 7); 0.1 uses a game | 35% (8 of 23); 0.2 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 35% (7 of 20); 0.2 uses a game | 69% (9 of 13); 0.2 uses a game | 48% (16 of 33); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 48% (28856 of 59592) | 47% (30062 of 63783) | 48% (58918 of 123375) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 2.0 (33%) | 1.1 (31%) | 3.1 (32%) |
| MARCHED: its unit marched | 1.5 (24%) | 0.7 (20%) | 2.2 (22%) |
| CHARGED: its unit charged | 0.2 (3%) | 0.1 (3%) | 0.3 (3%) |
| IN COMBAT: engaged in combat | 1.2 (20%) | 0.4 (13%) | 1.7 (17%) |
| REAR RANK: in a rear rank | 0.1 (2%) | 0.1 (4%) | 0.3 (3%) |
| FLEEING: fleeing | 0.0 (0%) | 0.1 (2%) | 0.1 (1%) |
| GONE: slain | 0.7 (11%) | 0.7 (19%) | 1.3 (14%) |
| OFF THE TABLE: off the table or not arrived | 0.3 (5%) | 0.3 (9%) | 0.6 (6%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 5.4 | 1.3 | 1.8 | 4.6 | 0.4 | 1.4 |
| not cast | 3.8 | 2.3 | 3.4 | 9.7 | 1.6 | 22.0 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.9 (4%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.9 (41%) | 0.4 (12%) | 3.1 (32%) | 0.4 (24%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.2 (22%) | 0.3 (19%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (3%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.1 (4%) | 0.1 (2%) | 0.4 (13%) | 1.7 (17%) | 0.2 (15%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.2 (4%) | 0.2 (7%) | 0.1 (2%) | 0.3 (3%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (1%) | 0.1 (2%) | 0.0 (1%) | 0.1 (1%) | 0.0 (0%) | 0.6 (3%) |
| GONE: slain | 0.7 (19%) | 0.2 (10%) | 0.5 (14%) | 1.3 (14%) | 0.2 (15%) | 2.2 (10%) |
| OFF THE TABLE: off the table or not arrived | 0.2 (4%) | 0.2 (7%) | 0.1 (4%) | 0.6 (6%) | 0.1 (5%) | 0.7 (3%) |
| STUPIDITY: Stupidity | 0.1 (1%) | 0.0 (0%) | 0.1 (2%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (3%) | 0.3 (14%) | 0.0 (0%) | 0.0 (0%) | 0.4 (22%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.4 (64%) | 0.4 (16%) | 1.8 (52%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 17.6 (80%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.1 a game | 0.9 a game | 1.0 a game |
| stood (cast and not dispelled) | 59% (22 of 37) | 70% (16 of 23) | 63% (38 of 60) |
| the unit moved after it | 68% (15 of 22) | 69% (11 of 16) | 68% (26 of 38) |
| it charged on its next turn | 9% (2 of 22) | 0% (0 of 16) | 5% (2 of 38) |
| the enemy charged it first | 14% (3 of 22) | 0% (0 of 16) | 8% (3 of 38) |
| it fought by the end of its next turn | 5% (1 of 22) | 0% (0 of 16) | 3% (1 of 38) |
| it moved out of a charge the enemy had planned (not charged first) | 5% (1 of 22) | 0% (0 of 16) | 3% (1 of 38) |
| none of these (no charge, no fight, no charge escaped) | 68% (15 of 22) | 100% (16 of 16) | 82% (31 of 38) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 58% (515 of 888) | 55% (332 of 608) | 57% (847 of 1496) |
|   cavalry | 62% (52 of 84) | 70% (87 of 125) | 67% (139 of 209) |
|   character | 42% (33 of 78) | 25% (28 of 111) | 32% (61 of 189) |
|   chariot | 62% (69 of 112) | 71% (30 of 42) | 64% (99 of 154) |
|   infantry | 52% (153 of 296) | 57% (157 of 274) | 54% (310 of 570) |
|   monster | 50% (24 of 48) | 67% (4 of 6) | 52% (28 of 54) |
|   war machine | 68% (184 of 270) | 52% (26 of 50) | 66% (210 of 320) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.2 (21%) | 1.7 (22%) | 3.9 (22%) |
| CHARGED: it charged | 0.9 (9%) | 1.6 (21%) | 2.5 (14%) |
| FLEEING: it fled or was fleeing | 0.1 (1%) | 0.1 (1%) | 0.2 (1%) |
| IN COMBAT: it fought this turn or the last | 0.5 (5%) | 0.2 (3%) | 0.8 (4%) |
| MOVED: a war machine that moved | 1.5 (15%) | 0.4 (5%) | 1.9 (11%) |
| NO TARGET IN RANGE | 3.0 (29%) | 1.8 (24%) | 4.8 (27%) |
| ONLY IN COMBAT: the only targets were in combat | 0.6 (6%) | 0.5 (6%) | 1.1 (6%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.0 (10%) | 1.1 (14%) | 2.1 (12%) |
| SHELTERED: the target was sheltered | 0.2 (2%) | 0.1 (2%) | 0.3 (2%) |
| OTHER BAR | 0.4 (3%) | 0.1 (1%) | 0.4 (2%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 5.6 | 1.1 | 83% | 5.2 pts | 29 pts |
| character | 2.0 | 0.5 | 83% | 6.3 pts | 13 pts |
| chariot | 2.8 | 1.9 | 61% | 16.6 pts | 46 pts |
| infantry | 12.1 | 5.2 | 71% | 9.4 pts | 113 pts |
| monster | 1.0 | 0.2 | 83% | 3.3 pts | 3 pts |
| war machine | 5.8 | 4.8 | 61% | 21.1 pts | 123 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.0 | 4.2 | 3.6 |
| Charges that made contact a game | 2.4 | 2.8 | 2.6 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.09 declared, 0.86 contact (22 units) | 0.47 declared, 0.33 contact (15 units) | 0.84 declared, 0.65 contact (37 units) |
|   per unit a game, units carrying another wizard (or one alone) | 1.14 declared, 0.86 contact (7 units) | 1.43 declared, 0.57 contact (7 units) | 1.29 declared, 0.71 contact (14 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.30 declared, 0.25 contact (257 units) | 0.46 declared, 0.30 contact (298 units) | 0.38 declared, 0.28 contact (555 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 41% (30 of 73) | 64% (9 of 14) | 62% (8 of 13) | 47% (47 of 100) |
| Character in a unit | 82% (28 of 34) | 72% (13 of 18) | 33% (1 of 3) | 76% (42 of 55) |
| Character on its own | 97% (28 of 29) | 56% (19 of 34) | 24% (17 of 72) | 47% (64 of 135) |
| Chariot | 77% (10 of 13) | 75% (9 of 12) | - | 76% (19 of 25) |
| Infantry | 43% (43 of 99) | 39% (12 of 31) | 0% (0 of 2) | 42% (55 of 132) |
| Monster | 66% (19 of 29) | 39% (7 of 18) | - | 55% (26 of 47) |
| Monstrous | 79% (11 of 14) | 50% (4 of 8) | - | 68% (15 of 22) |
| War Machines | 74% (32 of 43) | 100% (2 of 2) | - | 76% (34 of 45) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 57% (8 of 14); on the table 79% | 38% (39 of 102) | 52% | 50% (11 of 22) | 100% (6 of 6); 4.8 uses a game | 100% (2 of 2); 1.5 uses a game | 67% (4 of 6); 1.0 uses a game |
| Chaos Dwarfs | 4 | 100% (13 of 13); on the table 100% | 33% (10 of 30) | 76% | 56% (18 of 32) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |
| Dwarfen Mountain Holds | 3 | 25% (1 of 4); on the table 50% | - | 57% | 74% (20 of 27) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 6 | 100% (6 of 6); on the table 100% | 22% (8 of 36) | 55% | 64% (42 of 66) | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game | 0% (0 of 3); 0.0 uses a game |
| Grand Cathay | 5 | 87% (13 of 15); on the table 87% | 27% (34 of 126) | 53% | 49% (23 of 47) | 91% (10 of 11); 6.2 uses a game | 33% (1 of 3); 0.2 uses a game | 0% (0 of 5); 0.0 uses a game |
| High Elf Realms | 7 | 88% (14 of 16); on the table 88% | 10% (3 of 30) | 40% | 38% (20 of 53) | 88% (7 of 8); 4.0 uses a game | 25% (4 of 16); 0.9 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 3 | 100% (7 of 7); on the table 100% | - | 56% | 33% (6 of 18) | 0.0 uses a game | 0.0 uses a game | 100% (3 of 3); 1.0 uses a game |
| Lizardmen | 1 | 100% (3 of 3); on the table 100% | - | 52% | 57% (4 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 1 | 0% (0 of 1); on the table 0% | 0% (0 of 6) | 64% | 71% (5 of 7) | 100% (1 of 1); 3.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 1 | 100% (1 of 1); on the table 100% | 75% (9 of 12) | 61% | 75% (6 of 8) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Skaven | 9 | 62% (10 of 16); on the table 88% | 28% (17 of 60) | 50% | 49% (33 of 67) | 50% (1 of 2); 0.2 uses a game | 0.0 uses a game | 89% (8 of 9); 0.9 uses a game |
| Tomb Kings of Khemri | 5 | 82% (9 of 11); on the table 82% | 17% (1 of 6) | 40% | 44% (11 of 25) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 6 | 84% (16 of 19); on the table 95% | 48% (20 of 42) | 32% | 56% (20 of 36) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 11 | 87% (20 of 23); on the table 87% | 33% (12 of 36) | 25% | 52% (44 of 84) | 100% (1 of 1); 0.2 uses a game | 0.0 uses a game | 100% (1 of 1); 0.1 uses a game |
| Wood Elf Realms | 6 | 100% (13 of 13); on the table 100% | 47% (14 of 30) | 48% | 63% (39 of 62) | 43% (3 of 7); 2.7 uses a game | 0.0 uses a game | 0% (0 of 3); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (h3-mine-efe7e34-p4, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 43% (28) | 56% (35) | 49% (63) |
| ...free all their last turn and able to turn (per game) | 0.47 | 0.50 | 0.97 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.17 | 0.17 | 0.33 |
| ...with the charger already in that arc before they moved (per game) | 0.42 | 0.36 | 0.78 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.08 | 0.08 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.03 | 0.00 | 0.03 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.17 | 0.28 | 0.44 |

### Quality by phase: h3-mine-efe7e34-p4

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.1 | 2.1 |
| Strategy | Charge objectives carried out (made contact) | 55% (53 of 96) | 48% (70 of 145) |
| Strategy | Shoot objectives carried out (shot that target) | 39% (139 of 357) | 42% (48 of 115) |
| Strategy | Support requests answered (helper made contact too) | 100% (2 of 2) | 21% (3 of 14) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (4 of 4) | 100% (3 of 3) |
| Strategy | Hexes on a unit its side charged or shot that turn | 45% (5 of 11) | 38% (6 of 16) |
| Strategy | Joined characters whose unit fought | 29% (15 of 52) | 26% (10 of 39) |
| Strategy | Lone characters that fought | 78% (64 of 82) | 70% (57 of 81) |
| Movement | Charges halted short of contact | 0.0 | 0.3 |
| Movement | Idle units | 1.5 | 1.9 |
| Movement | Points that never moved of their own | 167.9 | 136.2 |
| Movement | Fights charged into per game | 2.3 | 2.6 |
| Movement | Charges with odds: long shots (under 50%) | 7 of 71, net +218 | 20 of 85, net +24 |
| Movement | Charges with odds: sweet spot (55-75%) | 11 of 71, net -13 | 18 of 85, net +84 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 8 of 71, net +168 | 10 of 85, net +47 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 24 of 71, net +79 | 21 of 85, net +169 |
| Shooting | Shots by shooting units (incl. breath weapons) | 9.9 | 10.1 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 47% (168 of 356) | 41% (149 of 364) |
| Shooting | Points destroyed by shooting units | 52.8 | 27.6 |
| Shooting | War machine shots | 5.1 | 0.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 54% (100 of 184) | 23% (6 of 26) |
| Shooting | Points destroyed by war machines | 62.9 | 14.7 |
| Magic | Magic missiles cast | 1.8 | 1.0 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 25% (16 of 65) | 38% (14 of 37) |
| Magic | Wounds caused by magic missiles | 5.2 | 1.5 |
| Magic | Wounds caused by other spells | 0.6 | 0.7 |
| Magic | Points destroyed by magic (all spells) | 80.4 | 28.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.6 / 0.3 / 0.4 / 0.1 | 2.2 / 0.6 / 0.4 / 0.1 |
| Combat | Points destroyed in combat | 262.6 | 287.9 |
| Combat | Points run down | 72.7 | 130.7 |
| Combat | Net points per charged fight, damage counted | +92 | +105 |
| Combat | Net per 100 charger points, damage counted | +33.1 | +33.8 |
| Combat | First round won (charged fights) | 72% | 68% |
| Combat | Net points per charged fight | +89 | +105 |
| Combat | Net points per supported fight / lone fight | +173 / +84 | +113 / +104 |
| Combat | Charged fights on a top-3 enemy unit | 29 of 83 | 40 of 92 |
| Game | Points lost | 619.4 | 656.4 |
| Game | VP from objectives | 618.1 | 630.8 |
| Game | Lone holders (player turns) | 4.6 | 2.4 |

- Mine won / drew / lost: 14 / 5 / 17 of 36 ended games (of 36); mean margin (Mine - Opponent) +34 VP
- The side that went first won 13 of 31 games with a winner
- Points traded per game (both sides' losses): 1276
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: h3-mine-efe7e34-p4

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 0.8 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.3 | +41.8 | 0.0 | 0.0 | 0.1 | +14.5 | 0.0 | 19.7 |
| ALREADY CARRIED | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARTILLERY RE-ROLL WEIGHED | 1.4 | +0.0 | 0.0 | 16.9 | 0.2 | +0.0 | 0.0 | 9.2 |
| BACKUP TARGETS | 0.2 | +0.8 | 0.0 | 2.2 | 0.2 | +1.3 | 0.0 | 3.1 |
| BEST FACING | - | - | - | - | 0.0 | +3.1 | 0.0 | 3.2 |
| BEST PRIZE | 0.1 | -5.5 | 4.0 | 0.0 | 0.2 | -6.2 | 14.4 | 0.0 |
| BLOWS WHERE AIMED | 0.1 | -25.4 | 0.0 | 0.0 | 0.2 | -74.7 | 12.8 | 0.0 |
| BOUND ASSAILMENT | 0.0 | +0.0 | 0.0 | 3.5 | - | - | - | - |
| CANNON PLAN MISSED | 0.6 | +0.0 | 66.4 | 6.9 | 0.1 | +0.0 | 3.2 | 0.0 |
| CANNON PLANNED TARGET | 4.4 | +84.4 | 181.3 | 65.8 | 0.7 | +21.7 | 26.9 | 9.2 |
| CANNON SIGHT KEPT | 1.3 | +0.0 | 0.0 | 3.3 | 0.3 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT COUNTER | 0.0 | -2.5 | 0.0 | 0.0 | - | - | - | - |
| CARRIES OUT SET-UP | 0.0 | -1.0 | 3.1 | 0.0 | 0.2 | -35.5 | 18.6 | 0.0 |
| CAST JOB | 0.4 | +11.2 | 27.4 | 8.2 | 0.4 | +7.7 | 16.6 | 0.0 |
| CASTER AWAY FROM SCREEN | 0.4 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.2 | +18.2 | 17.1 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | 0.6 | +0.0 | 0.0 | 11.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | 0.3 | +5.4 | 0.0 | 8.7 | 0.4 | +10.6 | 0.0 | 5.6 |
| CHAFF PASSED | 0.3 | -1.0 | 0.0 | 8.6 | 0.1 | -0.3 | 5.8 | 0.0 |
| CHARACTER GUNS | 0.5 | +0.0 | 0.0 | 12.0 | 0.4 | +0.0 | 0.0 | 6.2 |
| CHARGE LOSSES | 5.8 | -224.8 | 0.0 | 153.8 | 6.9 | -375.4 | 0.0 | 203.2 |
| CHARGE NOT DECLARED | 0.6 | +0.0 | 71.1 | 14.0 | 0.6 | +0.0 | 69.2 | 11.4 |
| CHARGE NOW FIRST | 1.6 | +0.0 | 249.6 | 38.9 | 1.9 | +0.0 | 215.3 | 28.5 |
| CHARGER SLAIN LOST | 0.1 | -0.8 | 5.8 | 7.3 | 0.3 | -8.1 | 15.1 | 10.7 |
| CHEAP HELPER | - | - | - | - | 0.1 | +0.0 | 0.0 | 0.0 |
| CHEAPEST HOLDER | - | - | - | - | 0.2 | -20.2 | 10.7 | 11.1 |
| COMBAT PIVOT | 0.3 | +0.0 | 18.8 | 12.3 | 0.5 | +0.0 | 20.0 | 4.7 |
| CONTINUE AHEAD WEIGHED | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | 0.6 | +47.2 | 5.9 | 15.7 | 0.3 | +23.0 | 10.2 | 0.0 |
| COVER ONCE | 6.9 | -499.8 | 0.0 | 153.6 | 5.3 | -481.6 | 0.0 | 88.1 |
| DEFENSIVE ARMY | 0.0 | +0.0 | 3.2 | 4.4 | - | - | - | - |
| DEFENSIVE FLOOR | 0.0 | -0.1 | 0.0 | 0.0 | - | - | - | - |
| DEPLOY BY FIGURES | 8.3 | +20.4 | 0.0 | 6.4 | 7.6 | +83.8 | 0.0 | 19.5 |
| EDGE GIVE GROUND | 0.1 | +2.0 | 13.7 | 0.0 | 0.1 | +3.0 | 20.6 | 0.0 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | - | - | - | - | 0.1 | +3.1 | 0.0 | 3.2 |
| FALL BACK GOOD ORDER | 1.9 | +3.4 | 220.9 | 45.3 | 2.8 | +4.6 | 277.2 | 53.1 |
| FALLBACK BY WORTH | 0.3 | +0.0 | 0.0 | 4.4 | 0.4 | +0.0 | 0.0 | 2.1 |
| FALLS SHORT | 3.6 | +54.5 | 0.0 | 96.2 | 19.9 | +270.4 | 0.0 | 307.8 |
| FEATURE BUFFS | 1.2 | +30.2 | 0.0 | 8.2 | 0.7 | +11.8 | 0.0 | 13.6 |
| FIGHT LIFT | - | - | - | - | 0.1 | +0.5 | 4.2 | 0.0 |
| FIGHT TO THE END | 0.9 | +72.1 | 156.8 | 15.3 | 1.3 | +47.3 | 111.1 | 30.1 |
| FIRE AND FLEE | 0.0 | +0.0 | 12.0 | 2.2 | 0.0 | +0.2 | 0.0 | 0.0 |
| FIRE IN ORDER | 0.2 | +0.0 | 4.9 | 5.6 | 0.1 | +0.0 | 0.0 | 4.4 |
| FIVE ACTION | 46.9 | +2880.9 | 834.9 | 734.4 | 43.9 | +2527.9 | 461.9 | 651.0 |
| FLANK NOT WEIGHED | 5.9 | +0.0 | 0.0 | 153.4 | 6.4 | +0.0 | 0.0 | 114.9 |
| FOCUS FIRE | 0.0 | +1.5 | 3.0 | 0.0 | 0.1 | +0.8 | 4.3 | 3.9 |
| FOLLOW UP WEIGHED | 0.7 | +194.7 | 0.0 | 31.8 | 0.8 | +137.4 | 0.0 | 16.6 |
| FOUR ROUNDS | 2.6 | +364.4 | 310.2 | 60.4 | 3.8 | +360.0 | 339.0 | 80.9 |
| FRIEND CHARGES FIRST | 0.1 | -6.3 | 0.0 | 0.0 | 0.2 | -17.5 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 0.6 | -12.6 | 1.1 | 6.0 | 0.1 | -1.7 | 0.0 | 0.0 |
| FRIENDS SHOTS CHECKED | 0.1 | +6.1 | 0.0 | 0.0 | 0.1 | +7.7 | 0.0 | 6.3 |
| GIVES UP | 0.1 | -1.7 | 20.8 | 0.0 | 0.3 | -3.0 | 11.2 | 9.1 |
| GROUND FLIERS | 0.0 | +0.3 | 0.0 | 0.0 | - | - | - | - |
| GUN FIGURES | 1.6 | +35.6 | 48.2 | 11.0 | 1.0 | +6.7 | 38.7 | 9.0 |
| GUN MASK | 0.5 | +8.2 | 0.0 | 17.4 | 0.4 | +13.3 | 0.0 | 4.4 |
| HARD STAY DROPPED | 2.1 | +0.0 | 0.0 | 25.1 | 0.8 | +0.0 | 0.0 | 15.0 |
| HE SHOOTS OR CHARGES | 2.0 | +0.0 | 0.0 | 50.7 | 2.6 | +0.0 | 0.0 | 64.3 |
| HELPER ALREADY ASKED | - | - | - | - | 0.1 | +0.0 | 4.5 | 2.8 |
| HELPER UNSEEN | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 3.1 | 1.7 |
| HIS CHARGE DENIED | 0.2 | +14.2 | 54.6 | 0.0 | 0.4 | +21.8 | 12.0 | 14.1 |
| HIS CHARGE LIST | 2.3 | +0.0 | 0.0 | 52.3 | 2.5 | +0.0 | 0.0 | 61.9 |
| HIS LEGAL MOVES | 4.6 | +0.0 | 0.0 | 80.6 | 3.5 | +0.0 | 0.0 | 78.8 |
| HIS MOVE AND SHOT | 1.6 | -27.1 | 0.0 | 29.3 | 2.5 | -56.8 | 0.0 | 77.2 |
| HIS RANDOM MOVE | 5.1 | +0.0 | 0.0 | 90.6 | 2.0 | +0.0 | 0.0 | 36.4 |
| HIS SHOT LIST | 15.6 | +425.5 | 0.0 | 268.5 | 23.9 | +1111.0 | 0.0 | 367.1 |
| HIS TURN DENIED | 0.8 | +32.4 | 106.4 | 23.7 | 1.8 | +64.8 | 185.0 | 24.6 |
| HOLD ODDS | 6.3 | +0.0 | 0.0 | 77.3 | - | - | - | - |
| HOLDER ASSIGNMENT | 12.5 | +1193.9 | 0.0 | 129.3 | - | - | - | - |
| HOLDER AT DEPLOYMENT | - | - | - | - | 1.5 | +233.5 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 2.3 | -89.3 | 268.9 | 28.7 | 3.3 | -160.2 | 294.3 | 63.0 |
| HORN WORTH | 0.0 | +0.1 | 0.0 | 0.0 | - | - | - | - |
| HUNT IN PAIRS | 0.3 | +4.5 | 0.0 | 1.9 | 0.5 | +22.8 | 0.0 | 0.0 |
| HUNT RESULT | - | - | - | - | 0.0 | +5.8 | 0.0 | 2.9 |
| HUNT THE GUNS | - | - | - | - | 0.0 | +6.8 | 3.1 | 0.0 |
| IDLE COST | 2.8 | -38.9 | 0.0 | 68.1 | 10.9 | -165.2 | 0.0 | 186.5 |
| JOINT KNOWS CHALLENGE | - | - | - | - | 0.1 | -6.8 | 19.8 | 2.9 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KILLS COUNT | 0.0 | +3.1 | 5.8 | 0.0 | 0.1 | +1.8 | 0.0 | 3.5 |
| LANE BY FIGURES | 0.8 | +30.6 | 0.0 | 0.0 | 0.7 | +37.2 | 0.0 | 10.2 |
| LEGAL CHARGES ONLY | 5.0 | +0.0 | 252.5 | 238.2 | 5.2 | +0.0 | 134.7 | 307.5 |
| LONE CHARACTER SAFE SPOT | 0.1 | +0.2 | 0.0 | 0.0 | 0.1 | +2.4 | 0.0 | 0.0 |
| LONE WIZARD KEPT IN | 0.6 | +30.6 | 0.0 | 0.0 | 0.5 | +37.1 | 0.0 | 0.0 |
| LONG SHOT | 0.1 | -0.4 | 0.0 | 6.3 | 0.2 | +1.5 | 8.8 | 4.4 |
| LOST CHARGE | 0.0 | -0.1 | 0.0 | 0.0 | - | - | - | - |
| LURE BY WHAT IT DRAWS | 0.0 | -3.8 | 0.0 | 0.8 | 0.1 | -4.6 | 0.0 | 4.8 |
| MAKE SURE TOGETHER | 0.0 | +0.4 | 0.0 | 0.0 | 0.2 | +1.9 | 0.0 | 0.0 |
| MANOEUVRE | 1.2 | +26.6 | 0.0 | 8.3 | 1.2 | +18.6 | 0.0 | 18.1 |
| MARCH AT ESCAPER | 0.2 | +3.8 | 0.0 | 5.3 | 0.1 | +0.7 | 0.0 | 9.9 |
| MARCH BY THE SUM | 0.4 | +37.5 | 0.0 | 0.0 | 0.3 | +15.7 | 0.0 | 25.7 |
| MARCH CHECK | 1.0 | +45.8 | 0.0 | 21.6 | 0.9 | +33.9 | 0.0 | 24.3 |
| MARCH OVER CASTS | 0.9 | +42.9 | 0.0 | 26.7 | 0.5 | +36.0 | 0.0 | 33.9 |
| MAX FOR POSITIONING | 5.8 | +75.2 | 0.0 | 85.8 | 5.8 | +81.7 | 0.0 | 110.9 |
| MISSILES IN THE MOVE | 4.7 | +163.5 | 0.0 | 126.4 | 2.6 | +31.1 | 0.0 | 76.8 |
| MISSILES NEXT TURN | 5.7 | +108.5 | 0.0 | 141.7 | 3.6 | +27.2 | 0.0 | 137.0 |
| MODEL FACING | 0.3 | +55.3 | 0.0 | 5.0 | - | - | - | - |
| MOVE SPELL IN RANGE | 0.5 | +21.2 | 0.0 | 0.0 | 0.1 | +2.2 | 0.0 | 0.0 |
| MOVE SPELL NOT WORTH | - | - | - | - | 0.0 | -0.0 | 0.0 | 0.0 |
| MOVE SPELL OUT OF RANGE | 0.6 | -21.2 | 4.4 | 3.6 | 0.2 | -8.9 | 0.0 | 15.2 |
| MOVE SPELL SPOT | 0.4 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 10.2 |
| MOVE TO CHARGE COMPUTED | 4.3 | +527.8 | 0.0 | 47.6 | 4.5 | +693.8 | 0.0 | 64.2 |
| MOVES UNITS SPELL | 0.1 | +3.4 | 0.0 | 0.0 | 0.1 | +0.4 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 4.3 | +186.8 | 0.0 | 47.6 | 5.2 | +233.9 | 0.0 | 60.3 |
| NEEDED THERE | 0.1 | +26.2 | 5.8 | 0.0 | 0.1 | +16.0 | 4.2 | 3.5 |
| NEXT CHARGE BY LIST | 5.7 | -228.7 | 14.6 | 80.9 | 5.8 | -281.1 | 0.0 | 110.9 |
| NEXT OBJECTIVE NEARER | 6.2 | -190.0 | 27.3 | 66.1 | 9.2 | -430.0 | 35.7 | 81.2 |
| NO DOUBLE ROUNDS | 2.2 | -117.1 | 286.8 | 59.2 | 2.9 | -132.3 | 298.7 | 56.2 |
| NO RALLY LEFT | 0.1 | +1.9 | 0.0 | 4.4 | - | - | - | - |
| NOT TURNED | 0.2 | +0.0 | 0.0 | 3.0 | 0.3 | +0.0 | 0.0 | 8.0 |
| NOT WORTH A CAST | 0.5 | -0.3 | 0.0 | 0.0 | 0.6 | -0.7 | 0.0 | 17.6 |
| OFF BEST | 0.5 | -19.1 | 0.0 | 9.8 | 0.7 | -12.9 | 0.0 | 6.1 |
| ONE CHARGE A CHARGER | 3.0 | +0.0 | 0.0 | 73.8 | 3.3 | +0.0 | 0.0 | 33.9 |
| ONE FIGHT FORMULA | 6.0 | -115.6 | 0.0 | 107.4 | 5.3 | -134.6 | 0.0 | 103.8 |
| ONE OBJECTIVE FORMULA | 5.1 | -27.0 | 0.0 | 83.1 | 3.5 | -65.1 | 0.0 | 37.3 |
| ONE TARGET A SHOOTER | 12.1 | +214.6 | 0.0 | 193.9 | 20.1 | +583.6 | 0.0 | 291.0 |
| OPENS A LANE | 0.2 | +1.9 | 33.1 | 3.6 | 0.0 | +0.2 | 4.7 | 0.0 |
| OPENS UP | 0.1 | +8.6 | 1.0 | 0.0 | 0.4 | +46.7 | 17.6 | 12.0 |
| OVERRUNS AWAY | 0.3 | +21.2 | 26.1 | 22.7 | 0.6 | +49.6 | 64.6 | 13.1 |
| PATHS CROSS | 3.8 | +145.5 | 0.0 | 46.8 | 4.9 | +199.5 | 0.0 | 53.7 |
| PERIAPT WORTH | 0.1 | +6.8 | 0.0 | 30.0 | 0.2 | +12.5 | 0.0 | 30.0 |
| PIVOT GUARDS FLANK | 0.1 | -3.2 | 0.0 | 4.4 | 0.1 | -1.6 | 0.0 | 1.0 |
| PLAN RESULT | 41.5 | +740.1 | 485.5 | 891.9 | 39.8 | +392.1 | 281.8 | 846.2 |
| PURSUES BIG PREY | - | - | - | - | 0.1 | -2.8 | 0.0 | 0.0 |
| PURSUES ON | 0.0 | -0.0 | 0.0 | 0.0 | - | - | - | - |
| RANDOM MOVE BY FIGURES | 0.7 | +33.7 | 0.0 | 44.4 | 2.9 | +50.2 | 0.0 | 80.4 |
| REDIRECT BY WHAT IT STOPS | 0.2 | -7.3 | 0.0 | 4.7 | 0.3 | -6.0 | 0.0 | 3.8 |
| REDIRECT COUNTER | 1.5 | +106.5 | 0.0 | 27.0 | 3.9 | +265.9 | 0.0 | 75.2 |
| REDIRECT WEIGHED | 0.1 | +1.7 | 6.9 | 0.0 | 0.4 | +4.3 | 17.3 | 0.0 |
| REFORMS TO MEET IT | 0.9 | -24.3 | 0.0 | 14.7 | 0.9 | -31.9 | 0.0 | 20.1 |
| REFUSING RETIRES | 0.4 | +0.0 | 0.0 | 15.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | 0.3 | +17.8 | 0.0 | 1.8 | 0.9 | +44.1 | 0.0 | 22.1 |
| RESTRAINS TO SHOOT | 0.1 | +1.3 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | 2.0 | +81.1 | 236.4 | 60.4 | 2.6 | +11.1 | 215.3 | 73.7 |
| RISK BY HIS FIGURE | 13.2 | -184.3 | 0.0 | 329.7 | 15.4 | -250.8 | 0.0 | 314.1 |
| RUN DOWN | 1.8 | -23.1 | 165.0 | 41.1 | 2.6 | -22.5 | 230.9 | 49.5 |
| SAFER THAN THE JOB | 0.0 | +0.3 | 0.0 | 0.0 | - | - | - | - |
| SAME CHARGE LATER | 0.2 | -5.8 | 0.0 | 0.0 | 0.1 | -2.8 | 0.0 | 0.0 |
| SCOUT SPOT | 0.3 | +0.6 | 0.0 | 0.0 | 0.2 | +0.9 | 0.0 | 0.0 |
| SCOUT WAITS | 0.3 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.1 | -9.3 | 0.0 | 2.3 | 0.3 | -25.8 | 0.0 | 0.0 |
| SEARCH SPOT | 6.4 | +267.8 | 0.0 | 123.6 | 6.4 | +267.1 | 0.0 | 93.6 |
| SELF MOVE SPELL | 0.2 | +1.2 | 0.0 | 11.0 | 0.3 | +62.4 | 0.0 | 0.0 |
| SET UP TOGETHER | 0.1 | +0.5 | 0.0 | 0.0 | 0.5 | +7.1 | 0.0 | 6.4 |
| SET-UP ANY TARGET | 0.1 | +15.8 | 0.0 | 0.0 | 0.1 | +6.8 | 10.2 | 0.0 |
| SET-UP MISSED | 0.0 | +4.0 | 0.0 | 0.0 | 0.0 | +0.6 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.4 | +0.9 | 0.0 | 0.0 | 0.3 | +0.6 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.4 | +75.7 | 73.9 | 33.7 | 0.6 | +41.1 | 22.4 | 12.9 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 3.3 | - | - | - | - |
| SHOT OR CHARGE | 0.2 | -8.0 | 61.4 | 1.9 | 0.2 | -2.1 | 10.5 | 0.0 |
| SHOT RISK POINTS | 8.1 | +36.3 | 0.0 | 130.4 | 13.0 | -29.1 | 0.0 | 315.1 |
| SHOTS IN THE MOVE | 15.5 | +644.4 | 0.0 | 256.7 | 10.1 | +188.3 | 0.0 | 138.2 |
| SPELL SETS UP CHARGE | 0.1 | +15.8 | 0.0 | 0.0 | 0.1 | +6.8 | 10.2 | 0.0 |
| SPELL WORTH | 1.5 | +36.1 | 70.6 | 80.4 | 2.4 | +44.9 | 118.3 | 112.6 |
| SPELLS IN THE FIGHT | 0.6 | +0.1 | 71.7 | 9.9 | 0.1 | -2.0 | 0.0 | 4.0 |
| STAND AND SHOOT | 0.4 | -5.1 | 41.4 | 1.7 | 0.7 | -5.0 | 53.0 | 13.7 |
| STANDS FOR A REASON | 0.1 | +0.0 | 0.0 | 15.0 | 0.5 | +0.0 | 5.4 | 39.3 |
| STANDS STILL | 17.4 | +0.0 | 500.9 | 227.9 | 8.7 | +0.0 | 104.9 | 103.9 |
| STAY WORTH | 17.3 | +93.9 | 290.9 | 192.7 | 9.7 | +71.4 | 67.1 | 108.1 |
| STOPS | - | - | - | - | 0.0 | +1.2 | 3.1 | 0.0 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 11.7 |
| SUPPORT NARROWED | 0.9 | +0.0 | 107.1 | 25.9 | 1.1 | +0.0 | 97.4 | 23.0 |
| SURE REACH TOGETHER | 0.2 | +1.4 | 0.0 | 11.0 | 0.6 | +10.2 | 0.0 | 20.0 |
| THE DEARER SUM KEEPS ITS PLAN | 4.3 | +0.0 | 0.0 | 56.8 | 4.8 | +0.0 | 0.0 | 48.3 |
| THE PROMISE ADDS | 0.1 | -3.8 | 0.0 | 0.0 | 0.4 | -28.4 | 6.5 | 0.0 |
| THE PROMISED MOVE | 1.0 | +0.0 | 0.0 | 4.5 | 0.9 | +0.0 | 0.0 | 5.5 |
| TIED UP BY THE SUM | 0.9 | +74.2 | 66.6 | 13.6 | 0.7 | +83.8 | 54.3 | 28.5 |
| TIME ON OUR SIDE | 31.2 | +461.8 | 5.2 | 364.6 | 6.5 | +91.4 | 1.5 | 76.3 |
| TWO OR MORE ARRIVE | - | - | - | - | 0.0 | +0.1 | 0.0 | 0.0 |
| WAITS AGAIN | 1.7 | +0.0 | 0.0 | 5.7 | 1.1 | +0.0 | 0.0 | 14.6 |
| WAR ENGINE JOBS | 0.3 | +0.0 | 16.0 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| WHO HITS BACK | 0.3 | +24.0 | 0.0 | 4.7 | 0.2 | +22.2 | 0.0 | 2.9 |
| WHOLE FIGHT | 0.2 | +4.5 | 15.9 | 0.0 | 0.3 | +10.8 | 24.0 | 9.9 |
| WHOLE FIGHT GAIN | 0.0 | +0.1 | 16.6 | 0.0 | 0.4 | +39.9 | 37.5 | 8.5 |
| WIDER SPREAD | 1.6 | -7.6 | 170.4 | 23.8 | 2.3 | -5.7 | 193.1 | 48.4 |
| WOUNDS ON THE RANKS | 1.3 | +30.7 | 0.0 | 16.7 | 1.3 | +73.3 | 0.0 | 55.1 |

### Rule changes: h3-mine-efe7e34-p4

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| SEARCH SPOT | 459 | 459 | 439 | 12.19 | +19260 | +43.9 |
| HOLDER ASSIGNMENT | 450 | 450 | 417 | 11.58 | +21410 | +51.3 |
| HIS SHOT LIST | 1423 | 1423 | 390 | 10.83 | +8942 | +22.9 |
| LEGAL CHARGES ONLY | 368 | 368 | 368 | 10.22 | +0 | +0.0 |
| FIVE ACTION | 3269 | 3265 | 366 | 10.17 | +12995 | +35.5 |
| DEPLOY BY FIGURES | 572 | 572 | 362 | 10.06 | +5152 | +14.2 |
| PATHS CROSS | 315 | 315 | 315 | 8.75 | +12423 | +39.4 |
| TIME ON OUR SIDE | 1356 | 1224 | 269 | 7.47 | +893 | +3.3 |
| ONE TARGET A SHOOTER | 1160 | 1160 | 257 | 7.14 | +2848 | +11.1 |
| MOVE TO CHARGE COMPUTED | 316 | 316 | 182 | 5.06 | +14708 | +80.8 |
| SHOT RISK POINTS | 758 | 758 | 132 | 3.67 | +4520 | +34.2 |
| FOUR ROUNDS | 230 | 226 | 129 | 3.58 | +8789 | +68.1 |
| HARD STAY DROPPED | 103 | 103 | 103 | 2.86 | +0 | +0.0 |
| MAX FOR POSITIONING | 416 | 403 | 90 | 2.50 | +322 | +3.6 |
| COVER ONCE | 438 | 353 | 88 | 2.44 | +1508 | +17.1 |
| NEXT OBJECTIVE NEARER | 554 | 554 | 69 | 1.92 | +932 | +13.5 |
| RANDOM MOVE BY FIGURES | 130 | 130 | 67 | 1.86 | +3021 | +45.1 |
| SHOTS IN THE MOVE | 921 | 869 | 59 | 1.64 | +1547 | +26.2 |
| RISK BY ARC | 165 | 163 | 58 | 1.61 | +1461 | +25.2 |
| CANNON SIGHT KEPT | 57 | 57 | 57 | 1.58 | +0 | +0.0 |
| ADVANCE LANE KEPT | 56 | 56 | 56 | 1.56 | +0 | +0.0 |
| MANOEUVRE | 88 | 88 | 56 | 1.56 | +1670 | +29.8 |
| ARTILLERY RE-ROLL WEIGHED | 55 | 55 | 55 | 1.53 | +0 | +0.0 |
| FALLS SHORT | 847 | 751 | 55 | 1.53 | +244 | +4.4 |
| LANE BY FIGURES | 54 | 54 | 54 | 1.50 | +2442 | +45.2 |
| FOLLOW UP WEIGHED | 52 | 52 | 52 | 1.44 | +11954 | +229.9 |
| IDLE COST | 492 | 390 | 52 | 1.44 | +521 | +10.0 |
| RISK BY HIS FIGURE | 1030 | 1030 | 48 | 1.33 | +3991 | +83.1 |
| SHOOTS FROM THE BEST SPOT | 75 | 75 | 48 | 1.33 | +820 | +17.1 |
| REDIRECT COUNTER | 194 | 169 | 47 | 1.31 | +4197 | +89.3 |
| TIED UP BY THE SUM | 56 | 55 | 46 | 1.28 | +1369 | +29.8 |
| CHARGE NOT DECLARED | 45 | 45 | 45 | 1.25 | -5696 | -126.6 |
| NEXT CHARGE BY LIST | 415 | 415 | 45 | 1.25 | +1119 | +24.9 |
| CHARGE LOSSES | 454 | 454 | 44 | 1.22 | +3682 | +83.7 |
| RESERVE FALL BACK | 43 | 43 | 43 | 1.19 | +2226 | +51.8 |
| OFF BEST | 42 | 42 | 42 | 1.17 | -1151 | -27.4 |
| MARCH CHECK | 68 | 68 | 41 | 1.14 | +646 | +15.7 |
| LONE WIZARD KEPT IN | 39 | 39 | 39 | 1.08 | +2437 | +62.5 |
| CHARGE NOW FIRST | 128 | 128 | 33 | 0.92 | -2216 | -67.2 |
| HOLDS AMBUSHERS | 30 | 30 | 30 | 0.83 | +0 | +0.0 |
| MISSILES IN THE MOVE | 264 | 205 | 30 | 0.83 | +1008 | +33.6 |
| STAY WORTH | 972 | 921 | 30 | 0.83 | +390 | +13.0 |
| CANNON PLANNED TARGET | 182 | 182 | 29 | 0.81 | -347 | -12.0 |
| HOLDER AT DEPLOYMENT | 55 | 55 | 29 | 0.81 | +1093 | +37.7 |
| NEARER NOT NEEDED | 342 | 329 | 29 | 0.81 | +811 | +28.0 |
| COMBAT PIVOT | 28 | 28 | 28 | 0.78 | +0 | +0.0 |
| FIGHT TO THE END | 80 | 78 | 27 | 0.75 | +1105 | +40.9 |
| ONE OBJECTIVE FORMULA | 310 | 282 | 26 | 0.72 | +726 | +27.9 |
| MARCH BY THE SUM | 25 | 25 | 25 | 0.69 | +1916 | +76.7 |
| HIS TURN DENIED | 94 | 93 | 24 | 0.67 | +527 | +22.0 |
| SHOOTERS IN TWO RANKS | 24 | 24 | 24 | 0.67 | +52 | +2.2 |
| WHO HITS BACK | 21 | 21 | 21 | 0.58 | +977 | +46.5 |
| SCOUT WAITS | 20 | 20 | 20 | 0.56 | +0 | +0.0 |
| CASTER AWAY FROM SCREEN | 19 | 19 | 19 | 0.53 | +0 | +0.0 |
| CAST JOB | 27 | 27 | 18 | 0.50 | +115 | +6.4 |
| ONE FIGHT FORMULA | 408 | 227 | 18 | 0.50 | +185 | +10.3 |
| OVERRUNS AWAY | 34 | 34 | 18 | 0.50 | +420 | +23.3 |
| REDIRECT WEIGHED | 18 | 18 | 18 | 0.50 | +940 | +52.2 |
| SURE REACH TOGETHER | 28 | 27 | 17 | 0.47 | +49 | +2.9 |
| WOUNDS ON THE RANKS | 94 | 94 | 17 | 0.47 | +405 | +23.8 |
| AFTERMATH IN POINTS | 16 | 16 | 16 | 0.44 | +2024 | +126.5 |
| CHAFF PASSED | 15 | 15 | 15 | 0.42 | -48 | -3.2 |
| STUCK PIVOT | 15 | 15 | 15 | 0.42 | +0 | +0.0 |
| OPENS UP | 20 | 20 | 14 | 0.39 | +574 | +41.0 |
| CHAFF IN THE MOVE | 26 | 25 | 12 | 0.33 | +14 | +1.1 |
| FIRE IN ORDER | 12 | 12 | 12 | 0.33 | +0 | +0.0 |
| BEST PRIZE | 10 | 10 | 10 | 0.28 | -659 | -65.9 |
| FEATURE BUFFS | 70 | 70 | 10 | 0.28 | +130 | +13.0 |
| FRIENDS SHOTS CHECKED | 10 | 10 | 10 | 0.28 | +498 | +49.8 |
| HONEST WORTH | 203 | 199 | 10 | 0.28 | +279 | +27.9 |
| MODEL FACING | 10 | 10 | 10 | 0.28 | +1991 | +199.1 |
| CASTS FROM BEHIND | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| REFUSING RETIRES | 21 | 21 | 9 | 0.25 | -3 | -0.3 |
| WHOLE FIGHT GAIN | 15 | 15 | 9 | 0.25 | +317 | +35.2 |
| PERIAPT WORTH | 8 | 8 | 8 | 0.22 | +696 | +87.0 |
| SUPPORT NARROWED | 69 | 69 | 8 | 0.22 | -350 | -43.7 |
| HIS CHARGE DENIED | 22 | 21 | 7 | 0.19 | +292 | +41.7 |
| PIVOT GUARDS FLANK | 7 | 7 | 7 | 0.19 | -173 | -24.7 |
| SHORT GUN FORWARD | 7 | 7 | 7 | 0.19 | +0 | +0.0 |
| GUN MASK | 32 | 32 | 6 | 0.17 | +272 | +45.3 |
| HIS MOVE AND SHOT | 145 | 145 | 6 | 0.17 | +170 | +28.3 |
| MISSILES NEXT TURN | 333 | 239 | 6 | 0.17 | +27 | +4.5 |
| MOVES UNITS SPELL | 6 | 6 | 6 | 0.17 | +136 | +22.7 |
| WIDER SPREAD | 142 | 141 | 6 | 0.17 | +5 | +0.8 |
| CASTING BLOCK | 8 | 8 | 5 | 0.14 | +113 | +22.7 |
| NEEDED THERE | 5 | 5 | 5 | 0.14 | +0 | +0.0 |
| FALL BACK GOOD ORDER | 169 | 166 | 4 | 0.11 | +29 | +7.2 |
| FOCUS FIRE | 4 | 4 | 4 | 0.11 | +84 | +21.1 |
| NO DOUBLE ROUNDS | 183 | 179 | 4 | 0.11 | +190 | +47.6 |
| WAR ENGINE JOBS | 13 | 13 | 4 | 0.11 | -52 | -13.0 |
| WHOLE FIGHT | 18 | 18 | 4 | 0.11 | +64 | +15.9 |
| CARRIES OUT SET-UP | 7 | 7 | 3 | 0.08 | -1311 | -437.1 |
| EDGE GIVE GROUND | 9 | 9 | 3 | 0.08 | +34 | +11.3 |
| FACES THE THREAT | 3 | 3 | 3 | 0.08 | +113 | +37.6 |
| KILLS COUNT | 3 | 3 | 3 | 0.08 | +0 | +0.0 |
| PURSUES BIG PREY | 3 | 3 | 3 | 0.08 | -101 | -33.6 |
| SAME CHARGE LATER | 12 | 12 | 3 | 0.08 | +55 | +18.4 |
| SET UP TOGETHER | 19 | 14 | 3 | 0.08 | +89 | +29.6 |
| FIRE AND FLEE | 2 | 2 | 2 | 0.06 | +8 | +3.8 |
| HUNT IN PAIRS | 27 | 14 | 2 | 0.06 | +21 | +10.5 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| LONG SHOT | 13 | 13 | 2 | 0.06 | +3 | +1.6 |
| NO RALLY LEFT | 2 | 2 | 2 | 0.06 | +60 | +30.1 |
| REDIRECT BY WHAT IT STOPS | 19 | 19 | 2 | 0.06 | +16 | +8.2 |
| RESTRAINS TO SHOOT | 2 | 2 | 2 | 0.06 | +46 | +23.2 |
| SPELLS IN THE FIGHT | 25 | 25 | 2 | 0.06 | +0 | +0.0 |
| BEST FACING | 1 | 1 | 1 | 0.03 | +110 | +110.4 |
| BOUND ASSAILMENT | 1 | 1 | 1 | 0.03 | +0 | +0.1 |
| CARRIES OUT COUNTER | 1 | 1 | 1 | 0.03 | -89 | -88.7 |
| CONTINUE AHEAD WEIGHED | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| HORN WORTH | 1 | 1 | 1 | 0.03 | +3 | +3.4 |
| MOVE SPELL IN RANGE | 20 | 11 | 1 | 0.03 | +40 | +39.7 |
| OPENS A LANE | 9 | 6 | 1 | 0.03 | +3 | +3.4 |
| PURSUES ON | 1 | 1 | 1 | 0.03 | -0 | -0.2 |
| RUN DOWN | 159 | 155 | 1 | 0.03 | +29 | +28.8 |
| SAFER THAN THE JOB | 1 | 1 | 1 | 0.03 | +10 | +10.1 |
| STOPS | 1 | 1 | 1 | 0.03 | +14 | +13.5 |
| THE PROMISE ADDS | 20 | 20 | 1 | 0.03 | +7 | +6.8 |
| ALREADY CARRIED | 2 | not checked | - | - | - | - |
| BACKUP TARGETS | 13 | 9 | 0 | 0.00 | - | - |
| BLOWS WHERE AIMED | 12 | 11 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 22 | 22 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 45 | trace | - | - | - | - |
| CHARACTER GUNS | 32 | 32 | 0 | 0.00 | - | - |
| CHARGER SLAIN LOST | 12 | 12 | 0 | 0.00 | - | - |
| CHEAP HELPER | 3 | not checked | - | - | - | - |
| CHEAPEST HOLDER | 9 | 9 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 34 | not checked | - | - | - | - |
| DEFENSIVE ARMY | 1 | 1 | 0 | 0.00 | - | - |
| DEFENSIVE FLOOR | 1 | 1 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FALLBACK BY WORTH | 25 | 25 | 0 | 0.00 | - | - |
| FIGHT LIFT | 5 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 443 | not checked | - | - | - | - |
| FRIEND CHARGES FIRST | 10 | 10 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 24 | 24 | 0 | 0.00 | - | - |
| GIVES UP | 14 | 14 | 0 | 0.00 | - | - |
| GROUND FLIERS | 1 | not checked | - | - | - | - |
| GUN FIGURES | 91 | not checked | - | - | - | - |
| HE SHOOTS OR CHARGES | 164 | 164 | 0 | 0.00 | - | - |
| HELPER ALREADY ASKED | 2 | not checked | - | - | - | - |
| HELPER UNSEEN | 7 | 7 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 172 | 172 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 292 | 292 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 257 | 257 | 0 | 0.00 | - | - |
| HOLD ODDS | 226 | 226 | 0 | 0.00 | - | - |
| HUNT RESULT | 1 | trace | - | - | - | - |
| HUNT THE GUNS | 1 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 4 | 4 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 4 | not checked | - | - | - | - |
| LOST CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 5 | 5 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 8 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 9 | trace | - | - | - | - |
| MARCH OVER CASTS | 50 | 50 | 0 | 0.00 | - | - |
| MOVE SPELL NOT WORTH | 1 | not checked | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 27 | trace | - | - | - | - |
| MOVE SPELL SPOT | 18 | not checked | - | - | - | - |
| NOT TURNED | 16 | 16 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 40 | not checked | - | - | - | - |
| ONE CHARGE A CHARGER | 225 | 225 | 0 | 0.00 | - | - |
| PLAN RESULT | 2927 | trace | - | - | - | - |
| REFORMS TO MEET IT | 63 | 63 | 0 | 0.00 | - | - |
| SCOUT SPOT | 19 | 19 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 14 | 14 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 21 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 7 | not checked | - | - | - | - |
| SET-UP MISSED | 2 | trace | - | - | - | - |
| SHOT OR CHARGE | 18 | 18 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 7 | not checked | - | - | - | - |
| SPELL WORTH | 140 | not checked | - | - | - | - |
| STAND AND SHOOT | 39 | 39 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 22 | 22 | 0 | 0.00 | - | - |
| STANDS STILL | 939 | 939 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 326 | not checked | - | - | - | - |
| THE PROMISED MOVE | 69 | not checked | - | - | - | - |
| TWO OR MORE ARRIVE | 1 | not checked | - | - | - | - |
| WAITS AGAIN | 101 | 101 | 0 | 0.00 | - | - |

### Off best figure: h3-mine-efe7e34-p4

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| HOLDER ASSIGNMENT | rule | 1.33 | - | 21.1 |
| CHARGE NOT DECLARED | rule | 0.61 | 0.56 | 135.6 |
| PATHS CROSS | rule | 0.39 | 0.64 | 18.2 |
| CHARGE NOW FIRST | rule | 0.42 | 0.44 | 71.5 |
| JOB FIRST | gate | 0.19 | 0.50 | 14.5 |
| BEST PRIZE | rule | 0.08 | 0.19 | 65.9 |
| CANNON PLANNED TARGET | rule | 0.22 | 0.03 | 49.5 |
| SUPPORT NARROWED | rule | 0.08 | 0.14 | 43.7 |
| PIVOT GUARDS FLANK | rule | 0.11 | 0.08 | 24.7 |
| AFTERMATH BAND | gate | 0.06 | 0.11 | 2.5 |
| CHAFF PASSED | rule | 0.11 | 0.06 | 7.9 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.11 | 0.03 | 61.8 |
| WAR ENGINE JOBS | rule | 0.08 | 0.03 | 12.9 |
| CARRIES OUT SET-UP | rule | 0.03 | 0.06 | 437.1 |
| DEPLOY BY FIGURES | rule | - | 0.08 | 19.2 |
| NO REASON | gate | 0.08 | - | 139.9 |
| PURSUES BIG PREY | rule | - | 0.08 | 33.6 |
| REDIRECT WEIGHED | rule | 0.03 | 0.06 | 51.0 |
| REFUSING RETIRES | rule | 0.08 | - | 0.7 |
| CARRIES OUT COUNTER | rule | 0.03 | - | 88.7 |
| FALLBACK | gate | 0.03 | - | 2.0 |
| FIGHT ORDER BAND | gate | 0.03 | - | 4.8 |
| FOLLOW UP WEIGHED | rule | - | 0.03 | 2.9 |
| FRIENDS SHOTS CHECKED | rule | - | 0.03 | 4.5 |
| LONE CHARACTER SAFE SPOT | gate | - | 0.03 | 38.4 |

### Plans: h3-mine-efe7e34-p4

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 2.1 | 68% | 442 | 265 | 60% |
| Mine | join | 0.5 | 100% | 12 | 0 | 0% |
| Mine | move | 30.1 | 94% | 1792 | 0 | 0% |
| Mine | shoot | 8.6 | 54% | 403 | 476 | 118% |
| Mine | support | 0.2 | 56% | 0 | 0 | 0% |
| Opponent | charge | 3.3 | 58% | 477 | 304 | 64% |
| Opponent | join | 0.7 | 92% | 29 | 0 | 0% |
| Opponent | move | 32.6 | 92% | 1708 | 0 | 0% |
| Opponent | shoot | 2.6 | 55% | 109 | 88 | 81% |
| Opponent | support | 0.6 | 81% | 4 | 0 | 0% |

### Packages: hunt the guns, h3-mine-efe7e34-p4

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 15 |
| Opponent | 0.0 | 1 | 0 | 100% | 100% | 0% | 2.0 | 243 | 210 | 100% | 47 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 21 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 78 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 35 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 166 |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 51 |
| Tomb Kings of Khemri | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 53 |
| Vampire Counts | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 8 |
| Warriors of Chaos | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Wood Elf Realms | 0.2 | 1 | 0 | 100% | 100% | 0% | 2.0 | 243 | 210 | 100% | 17 |

### Battle groups: h3-mine-efe7e34-p4

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 1.5 | 31% | 41% | 18% | 0% | 29% | 0% | 14% | 57% | 0% |
| Opponent | REDIRECT COUNTER | 3.9 | 22% | 70% | 23% | 14% | 35% | 0% | 9% | 52% | 4% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: h3-mine-efe7e34-p4

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 2 | 0 (2) | 0 | 0 | 67 | 50% | 4.0 | - | - | 0 (1) | 0 (1) | - |
| Mine | Chaff | 29 | 78 (29) | 11 | 67 | 52 | 41% | 2.4 | 29 (14) | 215 (8) | 41 (7) | 97 (23) | 12 (6) |
| Mine | Character | 114 | 51 (114) | 51 | 0 | 32 | 22% | 2.6 | 29 (32) | 64 (44) | 67 (25) | 48 (52) | 60 (49) |
| Mine | Clean-up | 24 | 75 (24) | 13 | 62 | 32 | 54% | 3.4 | 76 (4) | 73 (16) | 79 (4) | 79 (20) | 54 (4) |
| Mine | Fast Hammer | 50 | 46 (50) | 13 | 33 | 39 | 36% | 2.4 | 74 (8) | 36 (27) | 48 (15) | 62 (33) | 17 (17) |
| Mine | Hammer | 57 | 31 (57) | 14 | 17 | 21 | 28% | 2.4 | 41 (16) | 32 (30) | 16 (11) | 40 (36) | 18 (21) |
| Mine | Holder | 29 | 122 (29) | 23 | 99 | 26 | 41% | 2.9 | 67 (11) | 237 (11) | 94 (7) | 144 (18) | 76 (11) |
| Mine | Shooter | 48 | 75 (48) | 28 | 46 | 45 | 4% | 1.9 | 99 (16) | 96 (19) | 23 (13) | 88 (34) | 36 (14) |
| Mine | Support | 4 | 0 (4) | 0 | 0 | 42 | 75% | 4.0 | - | 0 (4) | - | - | 0 (4) |
| Mine | War machine | 55 | 25 (55) | 25 | 0 | 40 | 5% | 1.3 | 6 (20) | 29 (18) | 47 (17) | 8 (8) | 28 (47) |
| Mine | Wizard | 20 | 12 (20) | 12 | 0 | 20 | 40% | 2.2 | 0 (7) | 0 (7) | 41 (5) | 0 (10) | 24 (9) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | 0 (1) | - | - | - | 0 (1) |
| Opponent | Chaff | 58 | 55 (58) | 7 | 48 | 50 | 41% | 2.9 | 27 (17) | 97 (19) | 37 (22) | 52 (43) | 66 (15) |
| Opponent | Character | 92 | 45 (92) | 45 | 0 | 34 | 18% | 2.4 | 57 (25) | 52 (37) | 34 (19) | 46 (53) | 54 (28) |
| Opponent | Clean-up | 31 | 72 (31) | 10 | 61 | 29 | 42% | 3.7 | 73 (11) | 94 (16) | 17 (4) | 80 (20) | 61 (11) |
| Opponent | Fast Hammer | 54 | 48 (54) | 28 | 20 | 38 | 24% | 2.9 | 49 (9) | 38 (29) | 71 (16) | 53 (42) | 29 (12) |
| Opponent | Fragile | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Hammer | 58 | 34 (58) | 28 | 6 | 36 | 34% | 3.2 | 15 (13) | 26 (32) | 74 (13) | 34 (35) | 35 (23) |
| Opponent | Holder | 32 | 82 (32) | 9 | 73 | 13 | 56% | 3.0 | 98 (11) | 85 (13) | 58 (8) | 83 (23) | 79 (9) |
| Opponent | Shooter | 48 | 72 (48) | 20 | 52 | 53 | 17% | 1.7 | 48 (14) | 100 (24) | 48 (10) | 96 (32) | 31 (16) |
| Opponent | Support | 2 | 0 (2) | 0 | 0 | 0 | 100% | - | 0 (1) | 0 (1) | - | - | 0 (2) |
| Opponent | War machine | 9 | 48 (9) | 48 | 0 | 15 | 0% | 2.2 | 41 (5) | 32 (2) | 78 (2) | - | 48 (9) |
| Opponent | Wizard | 28 | 5 (28) | 5 | 0 | 26 | 25% | 1.9 | 0 (9) | 0 (6) | 1 (9) | 1 (13) | 0 (11) |

### Charged fights: h3-mine-efe7e34-p4

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 192 | 8 | 0.8 | 1.0 | 10 | 0 | +10 | 0 of 3 | 3 of 3 | - | +10 |
| Mine | Chaos Dwarfs | 4 | 159 | 274 | 1.5 | 1.2 | 183 | 0 | +183 | 1 of 6 | 5 of 6 | +287 | +162 |
| Mine | Dwarfen Mountain Holds | 3 | 104 | 25 | 1.3 | 1.0 | 19 | 0 | +19 | 0 of 4 | 4 of 4 | - | +19 |
| Mine | Empire of Man | 5 | 329 | 0 | 1.0 | 1.0 | 0 | 37 | -37 | 1 of 5 | 3 of 5 | - | -37 |
| Mine | Grand Cathay | 4 | 333 | 731 | 3.8 | 1.1 | 195 | 14 | +180 | 7 of 15 | 9 of 15 | +931 | +127 |
| Mine | High Elf Realms | 4 | 147 | 166 | 2.2 | 1.0 | 74 | 148 | -75 | 3 of 9 | 5 of 9 | - | -75 |
| Mine | Kingdom of Bretonnia | 1 | 0 | 1263 | 4.0 | 1.0 | 316 | 0 | +316 | 2 of 4 | 3 of 4 | - | +316 |
| Mine | Lizardmen | 1 | 65 | 785 | 3.0 | 1.0 | 262 | 0 | +262 | 2 of 3 | 3 of 3 | - | +262 |
| Mine | Ogre Kingdoms | 1 | 670 | 0 | 4.0 | 1.0 | 0 | 88 | -88 | 3 of 4 | 0 of 4 | - | -88 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 392 | 3.0 | 1.0 | 131 | 18 | +112 | 2 of 3 | 2 of 3 | - | +112 |
| Mine | Skaven | 2 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Mine | Tomb Kings of Khemri | 2 | 315 | 932 | 5.0 | 1.1 | 186 | 54 | +132 | 4 of 10 | 9 of 10 | -540 | +207 |
| Mine | Vampire Counts | 2 | 51 | 234 | 3.5 | 1.1 | 67 | 6 | +60 | 1 of 7 | 5 of 7 | +187 | +39 |
| Mine | Warriors of Chaos | 1 | 0 | 286 | 4.0 | 1.2 | 72 | 0 | +72 | 1 of 4 | 4 of 4 | +0 | +95 |
| Mine | Wood Elf Realms | 1 | 313 | 385 | 6.0 | 1.0 | 64 | 17 | +47 | 2 of 6 | 5 of 6 | - | +47 |
| **Mine** | all armies | 36 | 196 | 284 | 2.3 | 1.1 | 123 | 34 | +89 | 29 of 83 | 60 of 83 | +173 | +84 |
| Opponent | Empire of Man | 1 | 355 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 1 of 1 | 1 of 1 | - | +0 |
| Opponent | Grand Cathay | 1 | 208 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 0 of 1 | 1 of 1 | - | +0 |
| Opponent | High Elf Realms | 3 | 79 | 397 | 3.3 | 1.1 | 119 | 6 | +113 | 7 of 10 | 6 of 10 | +220 | +101 |
| Opponent | Kingdom of Bretonnia | 2 | 84 | 322 | 2.5 | 1.0 | 129 | 0 | +129 | 0 of 5 | 5 of 5 | - | +129 |
| Opponent | Skaven | 7 | 69 | 68 | 0.7 | 1.0 | 95 | 50 | +45 | 3 of 5 | 3 of 5 | - | +45 |
| Opponent | Tomb Kings of Khemri | 3 | 87 | 798 | 4.3 | 1.0 | 184 | 15 | +169 | 8 of 13 | 8 of 13 | - | +169 |
| Opponent | Vampire Counts | 4 | 124 | 588 | 5.2 | 1.0 | 112 | 38 | +74 | 12 of 21 | 15 of 21 | - | +74 |
| Opponent | Warriors of Chaos | 10 | 17 | 316 | 1.9 | 1.1 | 166 | 16 | +150 | 6 of 19 | 15 of 19 | +242 | +140 |
| Opponent | Wood Elf Realms | 5 | 31 | 251 | 3.4 | 1.2 | 74 | 14 | +60 | 3 of 17 | 9 of 17 | -9 | +75 |
| **Opponent** | all armies | 36 | 70 | 319 | 2.6 | 1.1 | 125 | 20 | +105 | 40 of 92 | 63 of 92 | +113 | +104 |

### Effective charges: h3-mine-efe7e34-p4

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 3 | 0 | 0 | 0 | 0 | 0 | 3 (net +10) | 0 | 0% (0 of 3) |
| Mine | Chaos Dwarfs | 6 | 0 | 0 | 0 | 2 (net +210) | 1 (net +287) | 3 (net +130) | 0 | 0% (0 of 6) |
| Mine | Dwarfen Mountain Holds | 4 | 0 | 0 | 1 (net +0) | 2 (net +38) | 0 | 1 (net +0) | 0 | 25% (1 of 4) |
| Mine | Empire of Man | 5 | 0 | 0 | 1 (net -77) | 0 | 1 (net +0) | 1 (net -110) | 2 | 33% (1 of 3) |
| Mine | Grand Cathay | 15 | 1 (net +931) | 0 | 5 (net +28) | 5 (net +150) | 0 | 4 (net +222) | 0 | 33% (5 of 15) |
| Mine | High Elf Realms | 9 | 3 (net -246) | 0 | 0 | 1 (net -247) | 0 | 5 (net +63) | 0 | 0% (0 of 9) |
| Mine | Kingdom of Bretonnia | 4 | 0 | 0 | 0 | 3 (net +379) | 1 (net +127) | 0 | 0 | 0% (0 of 4) |
| Mine | Lizardmen | 3 | 0 | 0 | 0 | 0 | 1 (net +575) | 2 (net +105) | 0 | 0% (0 of 3) |
| Mine | Ogre Kingdoms | 4 | 0 | 0 | 0 | 1 (net +0) | 0 | 1 (net -228) | 2 | 0% (0 of 2) |
| Mine | Orc & Goblin Tribes | 3 | 0 | 0 | 0 | 1 (net +392) | 0 | 0 | 2 | 0% (0 of 1) |
| Mine | Tomb Kings of Khemri | 10 | 2 (net +572) | 0 | 3 (net -125) | 1 (net +170) | 0 | 3 (net +83) | 1 | 33% (3 of 9) |
| Mine | Vampire Counts | 7 | 1 (net +187) | 1 (net +0) | 0 | 2 (net +0) | 3 (net +79) | 0 | 0 | 0% (0 of 7) |
| Mine | Warriors of Chaos | 4 | 0 | 0 | 1 (net +170) | 2 (net +0) | 1 (net +116) | 0 | 0 | 25% (1 of 4) |
| Mine | Wood Elf Realms | 6 | 0 | 0 | 0 | 0 | 0 | 1 (net +160) | 5 | 0% (0 of 1) |
| Opponent | Empire of Man | 1 | 1 (net +0) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 1) |
| Opponent | Grand Cathay | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +0) | 0 | 0% (0 of 1) |
| Opponent | High Elf Realms | 10 | 2 (net +178) | 1 (net +238) | 2 (net +65) | 1 (net +220) | 1 (net +0) | 2 (net +0) | 1 | 22% (2 of 9) |
| Opponent | Kingdom of Bretonnia | 5 | 0 | 0 | 2 (net +141) | 1 (net +110) | 1 (net +81) | 1 (net +170) | 0 | 40% (2 of 5) |
| Opponent | Skaven | 5 | 3 (net -28) | 0 | 1 (net +45) | 0 | 0 | 1 (net +265) | 0 | 20% (1 of 5) |
| Opponent | Tomb Kings of Khemri | 13 | 3 (net +182) | 1 (net +138) | 4 (net +73) | 1 (net +73) | 0 | 2 (net +414) | 2 | 36% (4 of 11) |
| Opponent | Vampire Counts | 21 | 4 (net -94) | 1 (net +509) | 2 (net +36) | 4 (net +35) | 2 (net +104) | 6 (net +113) | 2 | 11% (2 of 19) |
| Opponent | Warriors of Chaos | 19 | 3 (net +11) | 0 | 4 (net +68) | 3 (net +225) | 3 (net +69) | 5 (net +297) | 1 | 22% (4 of 18) |
| Opponent | Wood Elf Realms | 17 | 4 (net +0) | 0 | 3 (net +138) | 3 (net +143) | 3 (net -9) | 3 (net +39) | 1 | 19% (3 of 16) |

### Charged fights, damage counted: h3-mine-efe7e34-p4

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 7 | 497 | 436 | +218 | 474 | 180 | +295 | +59.3 |
| Mine | 50-54% | 1 | 45 | 41 | +0 | 20 | 0 | +20 | +45.6 |
| Mine | Effective (55-75%) | 11 | 283 | 207 | -13 | 70 | 111 | -41 | -14.6 |
| Mine | 76-89% | 20 | 316 | 201 | +135 | 175 | 55 | +120 | +37.9 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 24 | 212 | 145 | +79 | 110 | 18 | +93 | +43.7 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 8 | 446 | 102 | +168 | 174 | 7 | +167 | +37.4 |
| Mine | No odds | 12 | 132 | 172 | +7 | 43 | 36 | +7 | +5.5 |
| Mine | All fights | 83 | 279 | 190 | +89 | 147 | 54 | +92 | +33.1 |
| Opponent | Long shot (under 50%) | 20 | 188 | 259 | +24 | 94 | 73 | +21 | +10.9 |
| Opponent | 50-54% | 3 | 369 | 229 | +295 | 349 | 0 | +349 | +94.6 |
| Opponent | Effective (55-75%) | 18 | 299 | 221 | +84 | 114 | 45 | +69 | +23.1 |
| Opponent | 76-89% | 13 | 327 | 194 | +127 | 165 | 28 | +137 | +41.9 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 21 | 307 | 204 | +169 | 211 | 50 | +161 | +52.3 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 10 | 474 | 89 | +47 | 76 | 11 | +65 | +13.8 |
| Opponent | No odds | 7 | 392 | 200 | +159 | 159 | 0 | +159 | +40.6 |
| Opponent | All fights | 92 | 309 | 206 | +105 | 146 | 41 | +105 | +33.8 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| h3-mine-efe7e34-p4 | move | 297 | 57 (19%) | 44 (15%) | 41 (14%) | 199 (67%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0115, L0132, L2528, L2635 |
| Charmed Shield | Opponent | L0625, L0927, L1524, L2125, L3334 |
| Clockwork Compass | Mine | L1221 |
| Elixir of Power | Mine | L1128, L1920 |
| Fistful of Laurels | Mine | L1820 |
| Horn of the Wild Hunt | Mine | L3334 |
| Horn of the Wild Hunt | Opponent | L0333 |
| Invocation of Nehek | Mine | L2528 |
| Invocation of Nehek | Opponent | L0625, L0927, L1524, L2125 |
| Opal Amulet | Mine | L1428 |
| Opal Amulet | Opponent | L0714 |
| Periapt of Soul Exchange | Mine | L2022, L2125 |
| Periapt of Soul Exchange | Opponent | L0420, L0820, L1020, L1221, L1720, L1820, L1920 |
| Ring of Doom | Mine | L0216, L0232, L1128, L1221, L1524, L3334 |
| Ring of Doom | Opponent | L0115, L0333, L1315, L2931 |
| Ring of Jet | Mine | L1020, L1035, L1128, L1221 |
| Ring of Jet | Opponent | L0910 |
| Standard of the Fell Warrior | Mine | L1315, L1332 |
| Storm Daemon (Renegade 2.0) | Mine | L2125 |
| Storm Daemon (Renegade 2.0) | Opponent | L1221 |
| Twice-Blessed Armour | Mine | L0714, L0730, L1020, L1035 |
| Twice-Blessed Armour | Opponent | L0910 |
| Witch Hunter's Ward | Mine | L0714, L0730, L0820 |

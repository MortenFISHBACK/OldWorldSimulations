# Doctrine scorecard: h3-mine-efe7e34-p3

### Scorecard: h3-mine-efe7e34-p3

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0111 | 3 | 1 | Mine | no | 3 | - | 0 | 3 | 1 | 0 | 0 | 0 |
| L0111 | 3 | 1 | Opponent | no | 5 | 1 | 3 | 0 | 0 | 0 | 0 | 0 |
| L0128 | 2 | 1 | Mine | - | - | - | 0 | 4 | 0 | 0 | 0 | 0 |
| L0128 | 2 | 1 | Opponent | - | - | - | 0 | 4 | 0 | 0 | 0 | 0 |
| L0211 | 1 | 1 | Mine | no | 0 | 3 | 1 | 3 | 1 | 0 | 0 | 255 |
| L0211 | 1 | 1 | Opponent | yes | 13 | 2 | 1 | 0 | 0 | 0 | 0 | 0 |
| L0228 | 6 | 1 | Mine | no | 0 | 2 | 2 | 2 | 0 | 0 | 0 | 170 |
| L0228 | 6 | 1 | Opponent | no | 7 | - | 0 | 0 | 0 | 0 | 0 | 0 |
| L0313 | 1 | 1 | Mine | no | 9 | - | 0 | 1 | 0 | 0 | 0 | 140 |
| L0313 | 1 | 1 | Opponent | no | 4 | 2 | 1 | 0 | 1 | 0 | 0 | 70 |
| L0330 | 6 | 1 | Mine | no | 7 | - | 1 | 1 | 0 | 0 | 0 | 760 |
| L0330 | 6 | 1 | Opponent | no | 7 | 2 | 1 | 1 | 1 | 0 | 0 | 0 |
| L0415 | 1 | 1 | Mine | no | 8 | 2 | 5 | 2 | 0 | 0 | 0 | 310 |
| L0415 | 1 | 1 | Opponent | no | 7 | 2 | 3 | 0 | 1 | 0 | 0 | 0 |
| L0432 | 6 | 1 | Mine | no | 6 | 2 | 3 | 1 | 0 | 0 | 0 | 310 |
| L0432 | 6 | 1 | Opponent | no | 9 | 2 | 1 | 2 | 2 | 0 | 0 | 340 |
| L0518 | 2 | 1 | Mine | - | - | - | 0 | 1 | 0 | 0 | 0 | 138 |
| L0518 | 2 | 1 | Opponent | - | - | 4 | 1 | 1 | 0 | 0 | 0 | 0 |
| L0534 | 6 | 1 | Mine | no | 5 | - | 0 | 2 | 0 | 0 | 0 | 318 |
| L0534 | 6 | 1 | Opponent | no | 0 | 2 | 4 | 4 | 0 | 0 | 0 | 0 |
| L0621 | 3 | 1 | Mine | no | 4 | - | 1 | 1 | 1 | 0 | 0 | 175 |
| L0621 | 3 | 1 | Opponent | no | 6 | - | 1 | 3 | 0 | 0 | 0 | 500 |
| L0710 | 2 | 1 | Mine | - | - | 5 | 0 | 1 | 0 | 0 | 0 | 125 |
| L0710 | 2 | 1 | Opponent | - | - | 3 | 1 | 0 | 0 | 0 | 0 | 369 |
| L0726 | 6 | 1 | Mine | no | 5 | 2 | 4 | 0 | 0 | 0 | 0 | 439 |
| L0726 | 6 | 1 | Opponent | no | 6 | 2 | 5 | 0 | 0 | 0 | 0 | 0 |
| L0816 | 6 | 1 | Mine | no | 1 | 4 | 1 | 0 | 0 | 0 | 0 | 515 |
| L0816 | 6 | 1 | Opponent | no | 6 | - | 1 | 0 | 1 | 0 | 0 | 0 |
| L0832 | 4 | 1 | Mine | no | 0 | - | 0 | 0 | 0 | 0 | 0 | 327 |
| L0832 | 4 | 1 | Opponent | yes | 5 | 2 | 2 | 3 | 0 | 0 | 0 | 340 |
| L0922 | 4 | 1 | Mine | no | 2 | - | 0 | 1 | 0 | 0 | 0 | 346 |
| L0922 | 4 | 1 | Opponent | no | 2 | 2 | 4 | 3 | 1 | 0 | 0 | 195 |
| L1015 | 1 | 1 | Mine | no | 3 | 2 | 4 | 0 | 0 | 0 | 0 | 165 |
| L1015 | 1 | 1 | Opponent | no | 1 | 2 | 2 | 1 | 2 | 0 | 0 | 115 |
| L1032 | 6 | 1 | Mine | no | 9 | 3 | 2 | 0 | 0 | 0 | 0 | 0 |
| L1032 | 6 | 1 | Opponent | no | 0 | 5 | 1 | 3 | 0 | 0 | 0 | 0 |
| L1124 | 2 | 1 | Mine | - | - | 1 | 4 | 0 | 0 | 0 | 0 | 0 |
| L1124 | 2 | 1 | Opponent | - | - | 5 | 1 | 2 | 0 | 0 | 0 | 0 |
| L1216 | 4 | 1 | Mine | no | 10 | 3 | 2 | 0 | 0 | 0 | 0 | 0 |
| L1216 | 4 | 1 | Opponent | no | 3 | 4 | 1 | 1 | 0 | 0 | 0 | 0 |
| L1233 | 3 | 1 | Mine | yes | 19 | 2 | 6 | 0 | 0 | 0 | 0 | 165 |
| L1233 | 3 | 1 | Opponent | no | 0 | 2 | 2 | 3 | 1 | 0 | 0 | 739 |
| L1328 | 2 | 1 | Mine | - | - | 5 | 2 | 2 | 0 | 0 | 0 | 177 |
| L1328 | 2 | 1 | Opponent | - | - | - | 0 | 1 | 0 | 0 | 0 | 351 |
| L1423 | 1 | 1 | Mine | no | 4 | 3 | 3 | 1 | 1 | 0 | 0 | 0 |
| L1423 | 1 | 1 | Opponent | no | 4 | 2 | 4 | 1 | 1 | 0 | 0 | 255 |
| L1520 | 2 | 1 | Mine | - | - | 2 | 6 | 0 | 0 | 0 | 0 | 0 |
| L1520 | 2 | 1 | Opponent | - | - | - | 0 | 2 | 1 | 0 | 0 | 210 |
| L1618 | 4 | 1 | Mine | no | 8 | 3 | 1 | 0 | 1 | 0 | 0 | 100 |
| L1618 | 4 | 1 | Opponent | no | 0 | 5 | 5 | 0 | 1 | 0 | 0 | 234 |
| L1634 | 2 | 1 | Mine | - | - | 2 | 2 | 0 | 0 | 0 | 0 | 0 |
| L1634 | 2 | 1 | Opponent | - | - | 1 | 6 | 1 | 1 | 0 | 0 | 0 |
| L1732 | 4 | 1 | Mine | no | 8 | 3 | 4 | 0 | 1 | 0 | 0 | 72 |
| L1732 | 4 | 1 | Opponent | no | 1 | 2 | 5 | 2 | 1 | 0 | 0 | 340 |
| L1832 | 2 | 1 | Mine | - | - | 2 | 4 | 0 | 0 | 0 | 0 | 0 |
| L1832 | 2 | 1 | Opponent | - | - | 2 | 5 | 2 | 0 | 0 | 0 | 170 |
| L1933 | 1 | 1 | Mine | no | 0 | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L1933 | 1 | 1 | Opponent | no | 0 | 4 | 2 | 3 | 0 | 0 | 0 | 144 |
| L2034 | 6 | 1 | Mine | no | 2 | - | 1 | 4 | 1 | 0 | 0 | 275 |
| L2034 | 6 | 1 | Opponent | no | 0 | 4 | 5 | 4 | 0 | 0 | 0 | 291 |
| L2224 | 4 | 1 | Mine | no | 0 | 2 | 4 | 0 | 0 | 0 | 0 | 242 |
| L2224 | 4 | 1 | Opponent | no | 0 | 1 | 4 | 1 | 0 | 0 | 0 | 470 |
| L2329 | 1 | 1 | Mine | no | 1 | 2 | 3 | 1 | 0 | 0 | 0 | 460 |
| L2329 | 1 | 1 | Opponent | no | 7 | 2 | 7 | 1 | 0 | 0 | 0 | 170 |
| L2433 | 3 | 1 | Mine | no | 11 | 4 | 5 | 0 | 0 | 0 | 0 | 0 |
| L2433 | 3 | 1 | Opponent | no | 1 | 1 | 6 | 1 | 0 | 0 | 0 | 163 |
| L2631 | 3 | 1 | Mine | no | 0 | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L2631 | 3 | 1 | Opponent | no | 0 | 6 | 1 | 1 | 2 | 0 | 0 | 1043 |
| L2834 | 2 | 1 | Mine | - | - | - | 0 | 3 | 0 | 0 | 0 | 0 |
| L2834 | 2 | 1 | Opponent | - | - | 2 | 1 | 4 | 0 | 0 | 0 | 274 |
| L3134 | 2 | 1 | Mine | - | - | 3 | 1 | 1 | 2 | 0 | 0 | 340 |
| L3134 | 2 | 1 | Opponent | - | - | 2 | 10 | 3 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 4% | 4.8 | 2.6 | 2.2 | 1.0 | 0.2 | 0.0 | 0.0 | 175.7 |
| **Average** | | | Opponent | 8% | 3.6 | 2.6 | 2.7 | 1.6 | 0.5 | 0.0 | 0.0 | 188.4 |

### KPIs: h3-mine-efe7e34-p3

Rules off - Opponent only: HOLDER ASSIGNMENT.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 26% (44 of 170) | 9% (16 of 172) | 18% (60 of 342) |
| Winner chose to follow up after the loser gave ground |  | 91% (63 of 69); on the table 93% | 90% (38 of 42); on the table 90% | 91% (101 of 111); on the table 92% |
| Winner chose to pursue after the loser fell back in good order |  | 58% (7 of 12); on the table 58% | 78% (7 of 9); on the table 78% | 67% (14 of 21); on the table 67% |
| Winner chose to pursue after the loser fled |  | 73% (27 of 37); on the table 81% | 55% (12 of 22); on the table 64% | 66% (39 of 59); on the table 75% |
| Winner chose to follow up or pursue (all three) |  | 82% (97 of 118); on the table 86% | 78% (57 of 73); on the table 81% | 81% (154 of 191); on the table 84% |
| Magic missiles tried each own turn | 50%+ | 39% (128 of 330) | 32% (46 of 144) | 37% (174 of 474) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 46% (128 of 279) | 46% (46 of 99) | 46% (174 of 378) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 55% (12 of 22) | 40% (29 of 73) | 43% (41 of 95) |
| Points that never fought | lower | 41% (29196 of 71555) | 40% (28667 of 71975) | 40% (57863 of 143530) |
|   infantry points that never fought | lower | 56% (8409 of 15035) | 54% (7143 of 13201) | 55% (15552 of 28236) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 55% (155 of 282) | 57% (157 of 275) | 56% (312 of 557) |
| Bound items with a magic missile used (at least once a game) |  | 100% (23 of 23); 2.1 uses a game | 95% (20 of 21); 2.1 uses a game | 98% (43 of 44); 2.1 uses a game |
| Bound items with another spell used |  | 36% (5 of 14); 0.4 uses a game | 0% (0 of 3); 0.0 uses a game | 29% (5 of 17); 0.2 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 67% (14 of 21); 0.4 uses a game | 31% (5 of 16); 0.1 uses a game | 51% (19 of 37); 0.3 uses a game |
|   their share of the points of units over 100 pts | lower | 51% (31154 of 61235) | 53% (34164 of 64665) | 52% (65318 of 125900) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 2.4 (43%) | 0.4 (16%) | 2.9 (34%) |
| MARCHED: its unit marched | 1.5 (27%) | 0.6 (21%) | 2.1 (25%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.1 (3%) | 0.1 (1%) |
| IN COMBAT: engaged in combat | 1.3 (23%) | 0.5 (18%) | 1.8 (22%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.1 (4%) | 0.1 (2%) |
| NO CASTS LEFT: every cast used on other spells | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | 0.1 (2%) | 0.5 (19%) | 0.6 (8%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (0%) | 0.2 (8%) | 0.2 (3%) |
| STUPIDITY: Stupidity | 0.1 (1%) | 0.0 (1%) | 0.1 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| NOT OFFERED: not in the cast list | 0.1 (1%) | 0.2 (8%) | 0.3 (4%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.4 | 1.8 | 1.4 | 4.8 | 0.6 | 1.8 |
| not cast | 2.8 | 3.1 | 3.1 | 8.3 | 1.9 | 18.5 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.4 (8%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.3 (41%) | 0.0 (1%) | 2.9 (34%) | 0.2 (9%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.1 (25%) | 0.3 (16%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (1%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.1 (3%) | 0.2 (6%) | 0.6 (18%) | 1.8 (22%) | 0.6 (29%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.1 (4%) | 0.5 (16%) | 0.3 (9%) | 0.1 (2%) | 0.0 (0%) | 0.0 (0%) |
| NO CASTS LEFT: every cast used on other spells | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) |
| FLEEING: fleeing | 0.1 (4%) | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) | 0.0 (1%) | 0.2 (1%) |
| GONE: slain | 0.5 (19%) | 0.2 (7%) | 0.6 (19%) | 0.6 (8%) | 0.2 (11%) | 2.5 (13%) |
| OFF THE TABLE: off the table or not arrived | 0.2 (7%) | 0.1 (4%) | 0.1 (4%) | 0.2 (3%) | 0.1 (7%) | 0.3 (2%) |
| STUPIDITY: Stupidity | 0.1 (3%) | 0.0 (1%) | 0.0 (0%) | 0.1 (1%) | 0.0 (1%) | 0.1 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (4%) | 0.4 (12%) | 0.0 (1%) | 0.1 (1%) | 0.4 (21%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (4%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.5 (56%) | 0.4 (13%) | 1.5 (47%) | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 14.0 (76%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.2 a game | 0.4 a game | 0.8 a game |
| stood (cast and not dispelled) | 58% (22 of 38) | 60% (3 of 5) | 58% (25 of 43) |
| the unit moved after it | 68% (15 of 22) | 100% (3 of 3) | 72% (18 of 25) |
| it charged on its next turn | 0% (0 of 22) | 0% (0 of 3) | 0% (0 of 25) |
| the enemy charged it first | 5% (1 of 22) | 0% (0 of 3) | 4% (1 of 25) |
| it fought by the end of its next turn | 0% (0 of 22) | 0% (0 of 3) | 0% (0 of 25) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 22) | 0% (0 of 3) | 0% (0 of 25) |
| none of these (no charge, no fight, no charge escaped) | 95% (21 of 22) | 100% (3 of 3) | 96% (24 of 25) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 62% (519 of 833) | 51% (341 of 666) | 57% (860 of 1499) |
|   cavalry | 67% (64 of 95) | 64% (83 of 130) | 65% (147 of 225) |
|   character | 58% (49 of 85) | 28% (46 of 166) | 38% (95 of 251) |
|   chariot | 62% (49 of 79) | 74% (31 of 42) | 66% (80 of 121) |
|   infantry | 59% (139 of 237) | 54% (130 of 239) | 57% (269 of 476) |
|   monster | 77% (23 of 30) | 58% (11 of 19) | 69% (34 of 49) |
|   war machine | 64% (195 of 307) | 57% (40 of 70) | 62% (235 of 377) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.7 (19%) | 1.7 (19%) | 3.4 (19%) |
| CHARGED: it charged | 0.7 (8%) | 2.1 (24%) | 2.9 (16%) |
| FLEEING: it fled or was fleeing | 0.2 (2%) | 0.1 (1%) | 0.2 (1%) |
| IN COMBAT: it fought this turn or the last | 0.7 (8%) | 0.5 (6%) | 1.2 (7%) |
| MOVED: a war machine that moved | 1.9 (21%) | 0.6 (7%) | 2.5 (14%) |
| NO TARGET IN RANGE | 1.5 (18%) | 1.5 (16%) | 3.0 (17%) |
| ONLY IN COMBAT: the only targets were in combat | 0.3 (4%) | 0.4 (5%) | 0.7 (4%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.4 (16%) | 1.7 (18%) | 3.0 (17%) |
| SHELTERED: the target was sheltered | 0.1 (2%) | 0.2 (2%) | 0.3 (2%) |
| STUPIDITY | 0.0 (0%) | 0.1 (1%) | 0.1 (0%) |
| OTHER BAR | 0.3 (3%) | 0.1 (1%) | 0.4 (2%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 6.1 | 1.4 | 81% | 4.8 pts | 29 pts |
| character | 3.2 | 0.7 | 84% | 7.4 pts | 24 pts |
| chariot | 2.2 | 1.4 | 56% | 15.6 pts | 35 pts |
| infantry | 11.0 | 3.7 | 77% | 7.3 pts | 80 pts |
| monster | 1.1 | 0.2 | 85% | 2.8 pts | 3 pts |
| war machine | 6.5 | 6.2 | 60% | 29.6 pts | 194 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.6 | 4.8 | 4.2 |
| Charges that made contact a game | 2.9 | 3.5 | 3.2 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.16 declared, 1.00 contact (25 units) | 0.85 declared, 0.69 contact (13 units) | 1.05 declared, 0.89 contact (38 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.57 declared, 0.57 contact (7 units) | 0.83 declared, 0.50 contact (6 units) | 0.69 declared, 0.54 contact (13 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.40 declared, 0.32 contact (240 units) | 0.53 declared, 0.38 contact (297 units) | 0.47 declared, 0.35 contact (537 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 37% (28 of 76) | 50% (6 of 12) | 50% (7 of 14) | 40% (41 of 102) |
| Character in a unit | 91% (31 of 34) | 71% (15 of 21) | 75% (3 of 4) | 83% (49 of 59) |
| Character on its own | 75% (21 of 28) | 56% (23 of 41) | 37% (28 of 75) | 50% (72 of 144) |
| Chariot | 76% (13 of 17) | 73% (8 of 11) | - | 75% (21 of 28) |
| Infantry | 48% (31 of 65) | 37% (15 of 41) | 50% (2 of 4) | 44% (48 of 110) |
| Monster | 68% (21 of 31) | 67% (6 of 9) | - | 68% (27 of 40) |
| Monstrous | 78% (14 of 18) | 45% (5 of 11) | - | 66% (19 of 29) |
| War Machines | 77% (33 of 43) | 100% (2 of 2) | - | 78% (35 of 45) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 60% (3 of 5); on the table 60% | 45% (46 of 102) | 75% | 77% (17 of 22) | 100% (6 of 6); 5.2 uses a game | 100% (2 of 2); 2.2 uses a game | 83% (5 of 6); 1.2 uses a game |
| Chaos Dwarfs | 4 | 83% (10 of 12); on the table 92% | 50% (18 of 36) | 46% | 44% (14 of 32) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
| Dwarfen Mountain Holds | 3 | 43% (3 of 7); on the table 57% | - | 48% | 67% (16 of 24) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 5 | 100% (11 of 11); on the table 100% | 44% (8 of 18) | 39% | 67% (35 of 52) | 0.0 uses a game | 100% (2 of 2); 0.8 uses a game | 75% (3 of 4); 0.6 uses a game |
| Grand Cathay | 8 | 81% (17 of 21); on the table 81% | 37% (67 of 180) | 51% | 47% (34 of 72) | 100% (18 of 18); 7.2 uses a game | 0% (0 of 3); 0.0 uses a game | 38% (3 of 8); 0.4 uses a game |
| High Elf Realms | 6 | 76% (13 of 17); on the table 76% | 29% (7 of 24) | 35% | 43% (20 of 46) | 100% (8 of 8); 4.8 uses a game | 10% (1 of 10); 0.2 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 4 | 83% (5 of 6); on the table 83% | - | 43% | 67% (16 of 24) | 0.0 uses a game | 0.0 uses a game | 75% (3 of 4); 0.8 uses a game |
| Lizardmen | 1 | 100% (1 of 1); on the table 100% | - | 8% | 43% (3 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 3 | 88% (7 of 8); on the table 88% | 0% (0 of 18) | 38% | 62% (13 of 21) | 100% (3 of 3); 3.7 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 1 | 100% (5 of 5); on the table 100% | 33% (2 of 6) | 18% | 62% (5 of 8) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Skaven | 3 | 50% (4 of 8); on the table 62% | 17% (4 of 24) | 55% | 43% (10 of 23) | 100% (1 of 1); 1.0 uses a game | 0.0 uses a game | 100% (3 of 3); 1.0 uses a game |
| Tomb Kings of Khemri | 4 | 100% (14 of 14); on the table 100% | - | 31% | 45% (9 of 20) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 5 | 83% (25 of 30); on the table 87% | 17% (5 of 30) | 18% | 45% (14 of 31) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 13 | 73% (22 of 30); on the table 80% | 47% (17 of 36) | 37% | 60% (63 of 105) | 100% (2 of 2); 0.5 uses a game | 0.0 uses a game | 100% (1 of 1); 0.1 uses a game |
| Wood Elf Realms | 8 | 88% (14 of 16); on the table 88% | - | 38% | 61% (43 of 70) | 83% (5 of 6); 2.4 uses a game | 0.0 uses a game | 0% (0 of 8); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (h3-mine-efe7e34-p3, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 56% (44) | 57% (43) | 56% (87) |
| ...free all their last turn and able to turn (per game) | 0.81 | 0.92 | 1.72 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.19 | 0.14 | 0.33 |
| ...with the charger already in that arc before they moved (per game) | 0.72 | 0.56 | 1.28 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.03 | 0.03 | 0.06 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.22 | 0.22 | 0.44 |

### Quality by phase: h3-mine-efe7e34-p3

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.4 | 2.2 |
| Strategy | Charge objectives carried out (made contact) | 73% (86 of 118) | 57% (82 of 145) |
| Strategy | Shoot objectives carried out (shot that target) | 32% (125 of 385) | 43% (54 of 126) |
| Strategy | Support requests answered (helper made contact too) | 75% (6 of 8) | 35% (6 of 17) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (1 of 1) | - |
| Strategy | Hexes on a unit its side charged or shot that turn | 41% (9 of 22) | 57% (4 of 7) |
| Strategy | Joined characters whose unit fought | 38% (21 of 56) | 43% (12 of 28) |
| Strategy | Lone characters that fought | 73% (64 of 88) | 76% (61 of 80) |
| Movement | Charges halted short of contact | 0.2 | 0.1 |
| Movement | Idle units | 1.0 | 1.6 |
| Movement | Points that never moved of their own | 175.7 | 188.4 |
| Movement | Fights charged into per game | 2.6 | 3.2 |
| Movement | Charges with odds: long shots (under 50%) | 15 of 90, net +47 | 21 of 102, net +23 |
| Movement | Charges with odds: sweet spot (55-75%) | 15 of 90, net +71 | 13 of 102, net +89 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 9 of 90, net +43 | 12 of 102, net +84 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 31 of 90, net +76 | 31 of 102, net +168 |
| Shooting | Shots by shooting units (incl. breath weapons) | 9.9 | 9.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 47% (167 of 356) | 43% (143 of 334) |
| Shooting | Points destroyed by shooting units | 56.5 | 31.5 |
| Shooting | War machine shots | 5.4 | 1.1 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 55% (107 of 195) | 62% (25 of 40) |
| Shooting | Points destroyed by war machines | 70.6 | 17.5 |
| Magic | Magic missiles cast | 1.9 | 0.9 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 31% (22 of 70) | 39% (12 of 31) |
| Magic | Wounds caused by magic missiles | 4.6 | 1.9 |
| Magic | Wounds caused by other spells | 1.8 | 0.2 |
| Magic | Points destroyed by magic (all spells) | 139.7 | 35.3 |
| Magic | Augments / hexes / assailments / vortexes cast | 2.2 / 0.6 / 0.9 / 0.1 | 1.1 / 0.4 / 0.3 / 0.2 |
| Combat | Points destroyed in combat | 234.0 | 369.5 |
| Combat | Points run down | 99.4 | 107.6 |
| Combat | Net points per charged fight, damage counted | +83 | +88 |
| Combat | Net per 100 charger points, damage counted | +29.1 | +29.2 |
| Combat | First round won (charged fights) | 77% | 67% |
| Combat | Net points per charged fight | +74 | +88 |
| Combat | Net points per supported fight / lone fight | +190 / +63 | +181 / +79 |
| Combat | Charged fights on a top-3 enemy unit | 30 of 95 | 53 of 115 |
| Game | Points lost | 615.1 | 683.3 |
| Game | VP from objectives | 627.8 | 620.8 |
| Game | Lone holders (player turns) | 4.8 | 3.6 |

- Mine won / drew / lost: 16 / 5 / 15 of 36 ended games (of 36); mean margin (Mine - Opponent) +61 VP
- The side that went first won 11 of 31 games with a winner
- Points traded per game (both sides' losses): 1298
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: h3-mine-efe7e34-p3

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.6 | +0.0 | 0.0 | 0.0 | 0.8 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.1 | +15.6 | 0.0 | 3.1 | 0.1 | +8.6 | 0.0 | 9.6 |
| ALREADY CARRIED | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARRIVAL HUNT | - | - | - | - | 0.1 | +1.6 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.5 | +0.0 | 0.0 | 13.2 | 0.2 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | 0.2 | +1.0 | 0.0 | 0.0 | 0.2 | +1.6 | 0.0 | 27.6 |
| BEST PRIZE | - | - | - | - | 0.1 | -1.0 | 2.7 | 0.0 |
| BLOWS WHERE AIMED | 0.2 | -10.8 | 34.8 | 13.1 | 0.2 | -35.4 | 28.2 | 13.9 |
| BOMBING RUN | 0.0 | +0.4 | 1.7 | 0.0 | 0.1 | +1.6 | 3.1 | 0.0 |
| CANNON PLAN MISSED | 0.7 | +0.0 | 60.6 | 0.0 | 0.2 | +0.0 | 4.7 | 0.0 |
| CANNON PLANNED TARGET | 5.0 | +110.3 | 281.2 | 77.8 | 0.8 | +15.4 | 23.5 | 0.0 |
| CANNON SIGHT KEPT | 1.2 | +0.0 | 0.0 | 2.8 | 0.2 | +0.0 | 0.0 | 12.3 |
| CARRIES OUT SET-UP | 0.1 | -0.4 | 11.3 | 3.9 | - | - | - | - |
| CAST JOB | 0.6 | +19.9 | 41.4 | 4.5 | 0.1 | +1.8 | 1.5 | 3.2 |
| CASTER AWAY FROM SCREEN | 0.2 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.2 | +23.9 | 5.6 | 0.0 | 0.1 | +1.1 | 3.0 | 0.0 |
| CASTS AFTER FRIENDS | 0.6 | +0.0 | 0.0 | 9.9 | 0.2 | +0.0 | 0.0 | 11.1 |
| CASTS FROM BEHIND | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | 0.2 | +6.0 | 0.0 | 8.6 | 1.0 | +55.1 | 0.0 | 13.8 |
| CHAFF PASSED | 0.3 | -0.5 | 5.4 | 7.8 | 0.3 | -0.5 | 5.8 | 4.5 |
| CHARACTER GUNS | 0.3 | +0.0 | 0.0 | 0.0 | 0.5 | +0.0 | 0.0 | 0.0 |
| CHARGE LOSSES | 5.2 | -242.7 | 0.0 | 170.7 | 5.2 | -264.7 | 0.0 | 170.2 |
| CHARGE NOT DECLARED | 0.2 | +0.0 | 34.4 | 0.0 | 0.7 | +0.0 | 102.0 | 0.0 |
| CHARGE NOW FIRST | 1.8 | +0.0 | 220.7 | 60.9 | 1.7 | +0.0 | 241.6 | 17.6 |
| CHARGER SLAIN LOST | 0.2 | -11.1 | 20.9 | 4.7 | 0.4 | -6.8 | 44.3 | 6.4 |
| CHEAP HELPER | 0.1 | +0.0 | 11.0 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| CHEAPEST HOLDER | - | - | - | - | 0.1 | -3.9 | 5.2 | 0.0 |
| COMBAT PIVOT | 0.4 | +0.0 | 25.2 | 44.2 | 0.4 | +0.0 | 12.0 | 54.2 |
| CONTINUE AHEAD WEIGHED | 0.0 | +0.0 | 0.0 | 0.0 | 0.0 | +0.0 | 2.0 | 16.6 |
| CONVEYANCE SEARCH | 0.6 | +30.5 | 21.1 | 31.0 | 0.1 | +1.3 | 11.1 | 11.1 |
| COVER ONCE | 6.8 | -415.3 | 0.0 | 160.9 | 4.3 | -297.9 | 0.0 | 118.4 |
| DEFENSIVE ARMY | 0.0 | +0.0 | 6.5 | 0.0 | - | - | - | - |
| DEFENSIVE FLOOR | 0.0 | +0.3 | 0.0 | 2.2 | 0.0 | +0.1 | 3.2 | 2.5 |
| DEPLOY BY FIGURES | 7.6 | +17.2 | 0.0 | 8.6 | 7.9 | +50.0 | 0.0 | 14.1 |
| EDGE GIVE GROUND | 0.1 | +2.5 | 0.0 | 8.9 | 0.2 | +2.0 | 24.4 | 13.6 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 0.0 | +0.5 | 0.0 | 1.2 | 0.0 | +10.7 | 0.0 | 0.0 |
| FALL BACK GOOD ORDER | 2.2 | +15.4 | 235.1 | 62.1 | 2.7 | +11.2 | 290.9 | 41.2 |
| FALLBACK BY WORTH | 0.2 | +1.0 | 0.0 | 5.7 | 0.4 | +8.6 | 0.0 | 17.1 |
| FALLS SHORT | 6.3 | +111.7 | 0.0 | 154.1 | 15.6 | +227.9 | 0.0 | 264.4 |
| FEATURE BUFFS | 1.6 | +33.7 | 0.0 | 11.8 | 0.9 | +11.7 | 0.0 | 9.9 |
| FIGHT LIFT | 0.1 | +0.6 | 0.0 | 0.0 | - | - | - | - |
| FIGHT TO THE END | 1.3 | +106.6 | 188.3 | 39.4 | 1.3 | +110.6 | 149.4 | 14.9 |
| FIRE AND FLEE | 0.0 | +0.4 | 0.0 | 2.2 | - | - | - | - |
| FIRE IN ORDER | 0.1 | +0.0 | 3.0 | 0.0 | 0.2 | +0.0 | 12.2 | 0.0 |
| FIVE ACTION | 45.4 | +2948.1 | 988.5 | 709.6 | 43.1 | +2891.2 | 536.2 | 658.1 |
| FLANK NOT WEIGHED | 4.9 | +0.0 | 0.0 | 120.1 | 5.7 | +0.0 | 0.0 | 160.2 |
| FOCUS FIRE | 0.0 | +0.3 | 0.8 | 0.0 | 0.1 | +0.7 | 1.1 | 0.0 |
| FOLLOW UP WEIGHED | 1.0 | +213.5 | 0.0 | 56.8 | 1.0 | +230.7 | 0.0 | 29.6 |
| FOUR ROUNDS | 3.2 | +537.3 | 368.6 | 77.5 | 3.8 | +453.7 | 414.0 | 61.3 |
| FRIEND CHARGES FIRST | 0.1 | -4.8 | 0.0 | 1.4 | 0.1 | -0.6 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 0.5 | -16.6 | 6.5 | 0.0 | 0.3 | -6.6 | 0.0 | 12.3 |
| FRIENDS SHOTS CHECKED | 0.3 | +5.9 | 0.0 | 7.3 | 0.0 | +1.9 | 0.0 | 0.0 |
| GIVES UP | 0.2 | -3.9 | 24.3 | 0.0 | 0.3 | -5.4 | 16.8 | 0.8 |
| GIVES UP ITS SCREEN | - | - | - | - | 0.1 | -0.7 | 4.0 | 1.9 |
| GROUND FLIERS | 0.0 | +1.6 | 0.0 | 0.0 | - | - | - | - |
| GUN FIGURES | 0.6 | +14.2 | 36.2 | 28.5 | 0.5 | +4.5 | 33.2 | 10.6 |
| GUN MASK | 0.7 | +18.0 | 0.0 | 6.1 | 0.7 | +22.5 | 0.0 | 24.9 |
| HARD STAY DROPPED | 1.8 | +0.0 | 0.0 | 48.2 | 0.9 | +0.0 | 0.0 | 0.0 |
| HE SHOOTS OR CHARGES | 1.6 | +0.0 | 0.0 | 29.6 | 2.8 | +0.0 | 0.0 | 76.8 |
| HELPER ALREADY ASKED | 0.0 | +0.0 | 10.9 | 0.0 | 0.1 | +0.0 | 20.9 | 0.8 |
| HELPER UNSEEN | - | - | - | - | 0.1 | +0.0 | 13.1 | 0.0 |
| HIS CHARGE DENIED | 0.3 | +10.9 | 34.6 | 7.0 | 0.3 | +9.5 | 21.6 | 7.8 |
| HIS CHARGE LIST | 2.9 | +0.0 | 0.0 | 79.7 | 2.4 | +0.0 | 0.0 | 64.7 |
| HIS LEGAL MOVES | 4.8 | +0.0 | 0.0 | 133.2 | 3.3 | +0.0 | 0.0 | 96.1 |
| HIS MOVE AND SHOT | 2.0 | -26.3 | 0.0 | 71.8 | 1.9 | -45.0 | 0.0 | 63.3 |
| HIS RANDOM MOVE | 2.8 | +0.0 | 0.0 | 54.7 | 1.4 | +0.0 | 0.0 | 18.2 |
| HIS SHOT LIST | 18.6 | +627.1 | 0.0 | 337.1 | 23.7 | +1128.7 | 0.0 | 363.1 |
| HIS TURN DENIED | 0.9 | +29.4 | 115.4 | 25.2 | 1.8 | +88.4 | 172.2 | 29.1 |
| HOLD ODDS | 5.5 | +0.0 | 0.0 | 97.5 | - | - | - | - |
| HOLDER ASSIGNMENT | 11.6 | +1176.3 | 0.0 | 123.1 | - | - | - | - |
| HOLDER AT DEPLOYMENT | - | - | - | - | 1.1 | +188.5 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 0.5 | +0.0 | 0.0 | 0.0 | 0.5 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 2.7 | -96.8 | 307.1 | 53.6 | 2.9 | -127.6 | 328.4 | 67.0 |
| HORN WORTH | - | - | - | - | 0.1 | +0.7 | 0.0 | 14.0 |
| HUNT DROPPED | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |
| HUNT IN PAIRS | 0.4 | +8.3 | 0.0 | 10.8 | 0.2 | +6.5 | 0.0 | 0.0 |
| HUNT RESULT | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |
| HUNT THE GUNS | - | - | - | - | 0.1 | +9.9 | 2.6 | 0.0 |
| IDLE COST | 3.7 | -59.2 | 0.0 | 84.7 | 9.6 | -156.3 | 0.0 | 246.4 |
| JOINT KNOWS CHALLENGE | 0.0 | -0.3 | 0.0 | 0.0 | 0.2 | -7.1 | 29.3 | 1.6 |
| KEEP FALLS | 0.2 | +2.6 | 0.0 | 0.0 | 0.0 | +0.3 | 0.0 | 0.0 |
| KEEPS SCOUTS OR AMBUSH | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KILLS COUNT | - | - | - | - | 0.1 | +11.8 | 15.0 | 13.9 |
| LANE BY FIGURES | 0.8 | +30.4 | 0.0 | 0.0 | 1.0 | +47.7 | 0.0 | 22.5 |
| LEGAL CHARGES ONLY | 8.1 | +0.0 | 387.4 | 298.4 | 5.4 | +0.0 | 254.8 | 330.3 |
| LONE CHARACTER SAFE SPOT | 0.0 | +0.9 | 0.0 | 1.2 | - | - | - | - |
| LONE WIZARD KEPT IN | 0.6 | +34.3 | 0.0 | 0.0 | 0.2 | +22.4 | 0.0 | 0.0 |
| LONG SHOT | 0.1 | -0.6 | 4.5 | 2.2 | 0.4 | -0.4 | 19.5 | 11.3 |
| LOST CHARGE | 0.0 | -0.0 | 3.9 | 0.0 | - | - | - | - |
| LURE BY WHAT IT DRAWS | - | - | - | - | 0.1 | -8.6 | 0.0 | 6.1 |
| MAKE SURE TOGETHER | 0.3 | +4.2 | 0.0 | 13.1 | 0.1 | +1.8 | 0.0 | 18.5 |
| MANOEUVRE | 0.9 | +7.0 | 0.0 | 8.1 | 1.1 | +8.6 | 0.0 | 12.8 |
| MARCH AT ESCAPER | 0.2 | +0.9 | 0.0 | 0.0 | 0.1 | +0.4 | 0.0 | 22.0 |
| MARCH BY THE SUM | 0.4 | +31.9 | 0.0 | 11.3 | 0.4 | +16.7 | 0.0 | 19.5 |
| MARCH CHECK | 0.9 | +47.8 | 0.0 | 14.5 | 1.3 | +64.1 | 0.0 | 31.0 |
| MARCH ODDS | 0.1 | +1.4 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 0.8 | +77.8 | 0.0 | 11.3 | 0.6 | +8.1 | 0.0 | 34.5 |
| MAX FOR POSITIONING | 6.8 | +124.2 | 0.0 | 125.8 | 6.0 | +79.9 | 0.0 | 131.5 |
| MISSILES IN THE MOVE | 5.1 | +199.9 | 0.0 | 54.9 | 3.1 | +49.3 | 0.0 | 106.5 |
| MISSILES NEXT TURN | 5.9 | +118.6 | 0.0 | 71.7 | 3.7 | +33.0 | 0.0 | 131.6 |
| MODEL FACING | 0.2 | +52.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL IN RANGE | 0.1 | +1.5 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.4 | -22.9 | 0.0 | 21.1 | 0.2 | -5.6 | 0.0 | 0.0 |
| MOVE SPELL SPOT | 0.3 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 11.1 |
| MOVE TO CHARGE COMPUTED | 4.1 | +603.2 | 0.0 | 87.1 | 4.0 | +683.6 | 0.0 | 96.3 |
| MOVES UNITS SPELL | 0.1 | +3.4 | 0.0 | 0.0 | 0.1 | +0.4 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 3.7 | +147.0 | 0.0 | 29.4 | 3.8 | +194.4 | 0.0 | 13.7 |
| NEEDED THERE | 0.0 | +7.5 | 0.0 | 0.0 | 0.1 | +49.0 | 15.0 | 13.9 |
| NEXT CHARGE BY LIST | 5.8 | -204.1 | 45.2 | 121.6 | 4.9 | -155.5 | 0.0 | 98.1 |
| NEXT OBJECTIVE NEARER | 5.2 | -159.9 | 29.2 | 27.3 | 7.6 | -319.9 | 7.6 | 81.0 |
| NO DOUBLE ROUNDS | 2.7 | -150.7 | 312.8 | 70.5 | 2.8 | -157.6 | 324.7 | 52.0 |
| NO RALLY LEFT | 0.1 | +1.7 | 0.0 | 6.6 | - | - | - | - |
| NOT TURNED | 0.2 | -0.2 | 0.0 | 7.0 | 0.2 | +0.0 | 0.0 | 12.9 |
| NOT WORTH A CAST | 0.5 | -0.5 | 0.0 | 0.0 | 0.2 | -0.2 | 0.0 | 0.0 |
| OFF BEST | 0.4 | -4.5 | 0.0 | 10.5 | 0.6 | -13.9 | 0.0 | 21.3 |
| ONE CHARGE A CHARGER | 2.9 | +0.0 | 0.0 | 94.8 | 3.7 | +0.0 | 0.0 | 66.6 |
| ONE FIGHT FORMULA | 6.8 | -126.4 | 0.0 | 183.6 | 4.9 | -114.2 | 0.0 | 132.6 |
| ONE OBJECTIVE FORMULA | 5.0 | +6.5 | 0.0 | 58.2 | 3.9 | -145.1 | 0.0 | 71.5 |
| ONE TARGET A SHOOTER | 14.9 | +314.0 | 0.0 | 270.1 | 19.1 | +534.9 | 0.0 | 231.3 |
| OPENS A LANE | 0.2 | +1.3 | 9.1 | 9.8 | - | - | - | - |
| OPENS UP | 0.2 | +12.8 | 12.0 | 0.0 | 0.1 | +5.8 | 5.1 | 0.0 |
| OVERRUNS AWAY | 0.4 | +15.6 | 64.3 | 21.4 | 0.3 | +16.7 | 39.5 | 7.9 |
| PATHS CROSS | 3.9 | +222.3 | 0.0 | 32.3 | 4.5 | +180.8 | 0.0 | 66.0 |
| PERIAPT WORTH | 0.0 | +3.6 | 0.0 | 0.0 | 0.1 | +7.1 | 0.0 | 15.0 |
| PIVOT GUARDS FLANK | 0.1 | -0.3 | 0.0 | 7.4 | 0.1 | -0.5 | 0.0 | 0.0 |
| PLAN RESULT | 40.0 | +944.9 | 570.1 | 879.8 | 39.6 | +494.5 | 356.0 | 860.2 |
| PURSUES BIG PREY | 0.1 | -7.1 | 0.0 | 0.0 | 0.1 | -8.0 | 0.0 | 0.0 |
| RANDOM MOVE BY FIGURES | 0.6 | +9.2 | 0.0 | 26.9 | 2.0 | +16.7 | 0.0 | 45.1 |
| REDIRECT BY WHAT IT STOPS | 0.2 | -6.1 | 0.0 | 3.9 | 0.8 | -8.7 | 0.0 | 8.4 |
| REDIRECT COUNTER | 2.5 | +138.8 | 0.0 | 33.4 | 5.2 | +330.7 | 0.0 | 98.4 |
| REDIRECT WEIGHED | 0.1 | +1.9 | 0.0 | 11.3 | 0.1 | +1.5 | 6.2 | 0.8 |
| REFORMS TO MEET IT | 1.1 | -67.8 | 0.0 | 24.8 | 0.6 | -14.9 | 0.0 | 3.4 |
| REFUSING RETIRES | 0.2 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 10.7 |
| RESERVE FALL BACK | 0.6 | +23.6 | 0.0 | 4.4 | 0.9 | +56.1 | 0.0 | 11.7 |
| RESTRAINS TO SHOOT | 0.0 | +1.4 | 0.0 | 0.0 | 0.1 | +2.9 | 0.0 | 0.0 |
| RISK BY ARC | 2.2 | +37.4 | 247.8 | 66.3 | 2.6 | +8.2 | 298.9 | 69.9 |
| RISK BY HIS FIGURE | 13.1 | -191.1 | 0.0 | 328.9 | 14.3 | -191.5 | 0.0 | 357.1 |
| RUN DOWN | 2.1 | -26.2 | 213.9 | 43.7 | 2.3 | -27.1 | 218.3 | 48.1 |
| SAME CHARGE LATER | 0.2 | -3.7 | 0.0 | 0.0 | 0.1 | -1.6 | 0.0 | 0.0 |
| SCOUT SPOT | 0.3 | +0.8 | 0.0 | 0.0 | 0.2 | +1.0 | 0.0 | 0.0 |
| SCOUT WAITS | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.0 | -1.4 | 0.0 | 0.0 | 0.6 | -39.7 | 0.0 | 4.0 |
| SEARCH SPOT | 4.9 | +235.1 | 0.0 | 80.2 | 6.1 | +244.8 | 0.0 | 104.9 |
| SELF MOVE SPELL | 0.3 | +13.6 | 0.0 | 18.1 | 0.3 | +48.1 | 0.0 | 11.0 |
| SET UP TOGETHER | 0.4 | +5.3 | 0.0 | 13.1 | 0.2 | +3.5 | 0.0 | 18.5 |
| SET-UP ANY TARGET | 0.1 | +6.0 | 10.6 | 10.6 | - | - | - | - |
| SET-UP MISSED | 0.0 | +3.0 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | 0.3 | +0.8 | 0.0 | 0.0 | 0.2 | +0.4 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.2 | +48.7 | 61.2 | 9.3 | 0.9 | +19.3 | 27.0 | 1.8 |
| SHORT GUN FORWARD | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SHOT OR CHARGE | 0.2 | -12.9 | 24.4 | 0.0 | 0.2 | -6.5 | 12.1 | 0.0 |
| SHOT RISK POINTS | 9.1 | +13.5 | 0.0 | 204.4 | 11.8 | -30.6 | 0.0 | 266.9 |
| SHOTS IN THE MOVE | 15.4 | +607.1 | 0.0 | 228.1 | 10.1 | +259.7 | 0.0 | 127.6 |
| SPELL SETS UP CHARGE | 0.1 | +67.4 | 10.6 | 10.6 | - | - | - | - |
| SPELL WORTH | 1.6 | +26.8 | 34.7 | 34.7 | 1.5 | +28.5 | 97.7 | 101.2 |
| SPELLS IN THE FIGHT | 0.5 | +4.0 | 57.3 | 26.5 | 0.3 | -2.4 | 51.0 | 0.0 |
| STAND AND SHOOT | 0.2 | -2.9 | 38.6 | 7.0 | 0.8 | -11.0 | 62.1 | 32.0 |
| STANDS FOR A REASON | 0.0 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 21.3 |
| STANDS STILL | 17.2 | +0.0 | 595.0 | 210.1 | 10.5 | +0.0 | 110.8 | 69.0 |
| STAY WORTH | 17.7 | +5.1 | 388.8 | 168.6 | 9.6 | +65.2 | 59.0 | 100.6 |
| STOPS | - | - | - | - | 0.1 | +0.7 | 2.6 | 0.0 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| SUPPORT NARROWED | 0.9 | +0.0 | 66.4 | 29.7 | 1.4 | +0.0 | 167.6 | 17.5 |
| SURE REACH TOGETHER | 0.5 | +3.9 | 0.0 | 13.7 | 0.4 | +4.7 | 0.0 | 25.1 |
| THE DEARER SUM KEEPS ITS PLAN | 4.4 | +0.0 | 0.0 | 34.9 | 4.6 | +0.0 | 0.0 | 58.9 |
| THE PROMISE ADDS | 0.1 | -3.7 | 0.0 | 0.0 | 0.2 | -24.4 | 26.3 | 0.0 |
| THE PROMISED MOVE | 1.1 | +0.0 | 0.0 | 5.5 | 0.5 | +0.0 | 0.0 | 0.0 |
| TIED UP BY THE SUM | 0.8 | +78.2 | 82.2 | 8.4 | 0.6 | +70.9 | 68.5 | 0.0 |
| TIME ON OUR SIDE | 24.7 | +381.4 | 22.2 | 303.4 | 12.9 | +161.7 | 24.9 | 93.0 |
| WAITS AGAIN | 1.7 | +0.0 | 0.0 | 35.1 | 0.9 | +0.0 | 0.0 | 8.8 |
| WAR ENGINE CHARGES | 0.0 | +2.2 | 3.8 | 5.1 | - | - | - | - |
| WAR ENGINE JOBS | 0.1 | +0.0 | 16.2 | 5.1 | 0.1 | +0.0 | 0.0 | 5.1 |
| WHO HITS BACK | 0.3 | +39.7 | 0.0 | 5.2 | 0.2 | +35.4 | 0.0 | 0.0 |
| WHOLE FIGHT | 0.3 | +14.4 | 56.5 | 0.0 | 0.2 | +19.1 | 35.3 | 0.0 |
| WHOLE FIGHT GAIN | 0.2 | +9.7 | 21.8 | 1.4 | 0.5 | +37.9 | 76.5 | 2.3 |
| WIDER SPREAD | 2.1 | +0.9 | 230.2 | 58.5 | 2.4 | -5.5 | 279.1 | 27.5 |
| WOUNDS ON THE RANKS | 1.2 | +52.1 | 0.0 | 33.4 | 1.1 | +35.7 | 0.0 | 10.0 |

### Rule changes: h3-mine-efe7e34-p3

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| LEGAL CHARGES ONLY | 484 | 484 | 484 | 13.44 | +0 | +0.0 |
| HIS SHOT LIST | 1520 | 1520 | 435 | 12.08 | +8997 | +20.7 |
| HOLDER ASSIGNMENT | 419 | 419 | 391 | 10.86 | +24580 | +62.9 |
| SEARCH SPOT | 398 | 398 | 380 | 10.56 | +17337 | +45.6 |
| DEPLOY BY FIGURES | 559 | 559 | 337 | 9.36 | +4442 | +13.2 |
| TIME ON OUR SIDE | 1354 | 1213 | 304 | 8.44 | +934 | +3.1 |
| PATHS CROSS | 302 | 302 | 302 | 8.39 | +14509 | +48.0 |
| ONE TARGET A SHOOTER | 1226 | 1226 | 301 | 8.36 | +3031 | +10.1 |
| FIVE ACTION | 3183 | 3182 | 299 | 8.31 | +14211 | +47.5 |
| MOVE TO CHARGE COMPUTED | 292 | 292 | 182 | 5.06 | +18542 | +101.9 |
| FOUR ROUNDS | 251 | 250 | 148 | 4.11 | +12958 | +87.6 |
| MAX FOR POSITIONING | 461 | 452 | 113 | 3.14 | +296 | +2.6 |
| SHOT RISK POINTS | 754 | 754 | 110 | 3.06 | +2469 | +22.4 |
| HARD STAY DROPPED | 98 | 98 | 98 | 2.72 | +0 | +0.0 |
| REDIRECT COUNTER | 277 | 241 | 76 | 2.11 | +4793 | +63.1 |
| FOLLOW UP WEIGHED | 71 | 71 | 71 | 1.97 | +15993 | +225.3 |
| COVER ONCE | 399 | 304 | 66 | 1.83 | +1465 | +22.2 |
| LANE BY FIGURES | 65 | 65 | 65 | 1.81 | +2810 | +43.2 |
| NEXT OBJECTIVE NEARER | 460 | 460 | 62 | 1.72 | +1194 | +19.3 |
| ARTILLERY RE-ROLL WEIGHED | 60 | 60 | 60 | 1.67 | +0 | +0.0 |
| MARCH CHECK | 78 | 77 | 58 | 1.61 | +1055 | +18.2 |
| SHOTS IN THE MOVE | 918 | 864 | 58 | 1.61 | +2708 | +46.7 |
| MISSILES IN THE MOVE | 294 | 252 | 57 | 1.58 | +1594 | +28.0 |
| RESERVE FALL BACK | 53 | 53 | 53 | 1.47 | +2870 | +54.2 |
| SHOOTS FROM THE BEST SPOT | 75 | 75 | 52 | 1.44 | +523 | +10.1 |
| CANNON SIGHT KEPT | 51 | 51 | 51 | 1.42 | +0 | +0.0 |
| RISK BY ARC | 171 | 170 | 49 | 1.36 | +1036 | +21.1 |
| ADVANCE LANE KEPT | 47 | 47 | 47 | 1.31 | +0 | +0.0 |
| FALLS SHORT | 789 | 694 | 47 | 1.31 | +263 | +5.6 |
| IDLE COST | 479 | 382 | 45 | 1.25 | +419 | +9.3 |
| CHARGE LOSSES | 373 | 373 | 43 | 1.19 | +4133 | +96.1 |
| RANDOM MOVE BY FIGURES | 95 | 95 | 41 | 1.14 | +930 | +22.7 |
| MANOEUVRE | 72 | 72 | 40 | 1.11 | +671 | +16.8 |
| TIED UP BY THE SUM | 49 | 49 | 40 | 1.11 | +1542 | +38.5 |
| NEXT CHARGE BY LIST | 382 | 382 | 39 | 1.08 | +570 | +14.6 |
| RISK BY HIS FIGURE | 988 | 988 | 37 | 1.03 | +3790 | +102.4 |
| OFF BEST | 36 | 36 | 36 | 1.00 | -663 | -18.4 |
| HOLDS AMBUSHERS | 35 | 35 | 35 | 0.97 | +0 | +0.0 |
| COMBAT PIVOT | 32 | 32 | 32 | 0.89 | +0 | +0.0 |
| CHARGE NOT DECLARED | 31 | 31 | 31 | 0.86 | -6292 | -203.0 |
| LONE WIZARD KEPT IN | 30 | 30 | 30 | 0.83 | +2041 | +68.0 |
| NEARER NOT NEEDED | 270 | 258 | 30 | 0.83 | +944 | +31.5 |
| CHARGE NOW FIRST | 125 | 125 | 29 | 0.81 | -1273 | -43.9 |
| ONE OBJECTIVE FORMULA | 318 | 280 | 29 | 0.81 | +735 | +25.4 |
| CHAFF IN THE MOVE | 43 | 38 | 28 | 0.78 | +164 | +5.8 |
| FIGHT TO THE END | 92 | 92 | 28 | 0.78 | +1608 | +57.4 |
| MARCH BY THE SUM | 27 | 27 | 27 | 0.75 | +1749 | +64.8 |
| CANNON PLANNED TARGET | 208 | 208 | 24 | 0.67 | -511 | -21.3 |
| HIS TURN DENIED | 100 | 100 | 23 | 0.64 | +1011 | +43.9 |
| SCOUT WAITS | 22 | 22 | 22 | 0.61 | +0 | +0.0 |
| CHAFF PASSED | 21 | 21 | 21 | 0.58 | -36 | -1.7 |
| HOLDER AT DEPLOYMENT | 39 | 39 | 21 | 0.58 | +883 | +42.0 |
| WHO HITS BACK | 21 | 21 | 21 | 0.58 | +2014 | +95.9 |
| SHOOTERS IN TWO RANKS | 18 | 18 | 18 | 0.50 | +42 | +2.3 |
| CAST JOB | 25 | 25 | 16 | 0.44 | +246 | +15.4 |
| SURE REACH TOGETHER | 33 | 33 | 16 | 0.44 | +18 | +1.1 |
| WOUNDS ON THE RANKS | 84 | 84 | 16 | 0.44 | +667 | +41.7 |
| STAY WORTH | 984 | 933 | 14 | 0.39 | +183 | +13.1 |
| FRIENDS SHOTS CHECKED | 13 | 13 | 13 | 0.36 | +283 | +21.8 |
| WHOLE FIGHT GAIN | 23 | 23 | 12 | 0.33 | +466 | +38.8 |
| FIRE IN ORDER | 11 | 11 | 11 | 0.31 | +0 | +0.0 |
| AFTERMATH IN POINTS | 10 | 10 | 10 | 0.28 | +873 | +87.3 |
| ONE FIGHT FORMULA | 423 | 238 | 10 | 0.28 | +78 | +7.8 |
| CASTER AWAY FROM SCREEN | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| FEATURE BUFFS | 88 | 88 | 9 | 0.25 | +52 | +5.8 |
| HONEST WORTH | 202 | 201 | 9 | 0.25 | +149 | +16.5 |
| REDIRECT WEIGHED | 9 | 9 | 9 | 0.25 | +217 | +24.1 |
| STUCK PIVOT | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| CASTING BLOCK | 12 | 12 | 8 | 0.22 | +265 | +33.1 |
| GUN MASK | 51 | 51 | 8 | 0.22 | +192 | +24.1 |
| SUPPORT NARROWED | 82 | 82 | 8 | 0.22 | -49 | -6.2 |
| WIDER SPREAD | 161 | 160 | 8 | 0.22 | +39 | +4.8 |
| KEEP FALLS | 7 | 7 | 7 | 0.19 | +155 | +22.1 |
| OVERRUNS AWAY | 26 | 26 | 7 | 0.19 | +222 | +31.7 |
| HIS CHARGE DENIED | 22 | 22 | 6 | 0.17 | +98 | +16.4 |
| MISSILES NEXT TURN | 344 | 269 | 6 | 0.17 | +43 | +7.2 |
| MODEL FACING | 6 | 6 | 6 | 0.17 | +1872 | +312.0 |
| MOVES UNITS SPELL | 6 | 6 | 6 | 0.17 | +136 | +22.7 |
| NEEDED THERE | 6 | 6 | 6 | 0.17 | +0 | +0.0 |
| OPENS UP | 10 | 10 | 6 | 0.17 | +149 | +24.9 |
| REDIRECT BY WHAT IT STOPS | 35 | 35 | 6 | 0.17 | +60 | +10.0 |
| REFUSING RETIRES | 19 | 19 | 6 | 0.17 | -1 | -0.2 |
| WHOLE FIGHT | 18 | 18 | 6 | 0.17 | +326 | +54.4 |
| FALL BACK GOOD ORDER | 176 | 175 | 5 | 0.14 | +314 | +62.9 |
| HIS MOVE AND SHOT | 143 | 143 | 5 | 0.14 | +15 | +3.0 |
| KILLS COUNT | 5 | 5 | 5 | 0.14 | +0 | +0.0 |
| PURSUES BIG PREY | 5 | 5 | 5 | 0.14 | -544 | -108.8 |
| SHORT GUN FORWARD | 5 | 5 | 5 | 0.14 | +0 | +0.0 |
| BEST PRIZE | 4 | 4 | 4 | 0.11 | -229 | -57.1 |
| BOMBING RUN | 4 | 4 | 4 | 0.11 | +72 | +17.9 |
| FALLBACK BY WORTH | 23 | 23 | 4 | 0.11 | +346 | +86.6 |
| HUNT IN PAIRS | 21 | 10 | 4 | 0.11 | +17 | +4.4 |
| PIVOT GUARDS FLANK | 4 | 4 | 4 | 0.11 | -31 | -7.7 |
| CASTS FROM BEHIND | 3 | 3 | 3 | 0.08 | +0 | +0.0 |
| FOCUS FIRE | 3 | 3 | 3 | 0.08 | +36 | +12.0 |
| NO DOUBLE ROUNDS | 198 | 197 | 3 | 0.08 | +60 | +20.1 |
| NO RALLY LEFT | 3 | 3 | 3 | 0.08 | +25 | +8.3 |
| PERIAPT WORTH | 3 | 3 | 3 | 0.08 | +383 | +127.7 |
| RESTRAINS TO SHOOT | 3 | 3 | 3 | 0.08 | +153 | +51.0 |
| SET UP TOGETHER | 24 | 20 | 3 | 0.08 | +43 | +14.3 |
| CONTINUE AHEAD WEIGHED | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| FACES THE THREAT | 2 | 2 | 2 | 0.06 | +404 | +202.1 |
| HORN WORTH | 2 | 2 | 2 | 0.06 | +25 | +12.5 |
| MARCH ODDS | 2 | 2 | 2 | 0.06 | -31 | -15.4 |
| RUN DOWN | 158 | 157 | 2 | 0.06 | +29 | +14.4 |
| SAME CHARGE LATER | 12 | 12 | 2 | 0.06 | +0 | +0.0 |
| SPELLS IN THE FIGHT | 31 | 31 | 2 | 0.06 | +10 | +4.9 |
| THE PROMISE ADDS | 12 | 12 | 2 | 0.06 | +65 | +32.7 |
| CARRIES OUT SET-UP | 3 | 3 | 1 | 0.03 | -14 | -14.1 |
| FIRE AND FLEE | 1 | 1 | 1 | 0.03 | +15 | +15.2 |
| FRIEND SHOOTS FIRST | 29 | 29 | 1 | 0.03 | +0 | +0.0 |
| KEEPS SCOUTS OR AMBUSH | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| LONG SHOT | 17 | 17 | 1 | 0.03 | +10 | +10.5 |
| MOVE SPELL IN RANGE | 3 | 2 | 1 | 0.03 | +12 | +12.5 |
| ALREADY CARRIED | 2 | not checked | - | - | - | - |
| ARRIVAL HUNT | 2 | 2 | 0 | 0.00 | - | - |
| BACKUP TARGETS | 16 | 7 | 0 | 0.00 | - | - |
| BLOWS WHERE AIMED | 15 | 15 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 35 | 35 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 31 | trace | - | - | - | - |
| CHARACTER GUNS | 28 | 28 | 0 | 0.00 | - | - |
| CHARGER SLAIN LOST | 22 | 22 | 0 | 0.00 | - | - |
| CHEAP HELPER | 5 | not checked | - | - | - | - |
| CHEAPEST HOLDER | 4 | 4 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 26 | not checked | - | - | - | - |
| DEFENSIVE ARMY | 1 | 1 | 0 | 0.00 | - | - |
| DEFENSIVE FLOOR | 2 | 2 | 0 | 0.00 | - | - |
| EDGE GIVE GROUND | 8 | 8 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT LIFT | 4 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 383 | not checked | - | - | - | - |
| FRIEND CHARGES FIRST | 5 | 5 | 0 | 0.00 | - | - |
| GIVES UP | 17 | 17 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 3 | 3 | 0 | 0.00 | - | - |
| GROUND FLIERS | 1 | not checked | - | - | - | - |
| GUN FIGURES | 42 | not checked | - | - | - | - |
| HE SHOOTS OR CHARGES | 159 | 159 | 0 | 0.00 | - | - |
| HELPER ALREADY ASKED | 4 | not checked | - | - | - | - |
| HELPER UNSEEN | 3 | 3 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 188 | 188 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 293 | 293 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 153 | 153 | 0 | 0.00 | - | - |
| HOLD ODDS | 197 | 197 | 0 | 0.00 | - | - |
| HUNT DROPPED | 1 | trace | - | - | - | - |
| HUNT RESULT | 1 | trace | - | - | - | - |
| HUNT THE GUNS | 2 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 9 | 9 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 1 | not checked | - | - | - | - |
| LOST CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 4 | 4 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 14 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 10 | trace | - | - | - | - |
| MARCH OVER CASTS | 48 | 48 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 21 | trace | - | - | - | - |
| MOVE SPELL SPOT | 13 | not checked | - | - | - | - |
| NOT TURNED | 16 | 16 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 24 | not checked | - | - | - | - |
| ONE CHARGE A CHARGER | 236 | 236 | 0 | 0.00 | - | - |
| OPENS A LANE | 9 | 5 | 0 | 0.00 | - | - |
| PLAN RESULT | 2866 | trace | - | - | - | - |
| REFORMS TO MEET IT | 63 | 63 | 0 | 0.00 | - | - |
| SCOUT SPOT | 20 | 20 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 21 | 21 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 23 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 2 | not checked | - | - | - | - |
| SET-UP MISSED | 1 | trace | - | - | - | - |
| SHOT OR CHARGE | 15 | 15 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 5 | not checked | - | - | - | - |
| SPELL WORTH | 111 | not checked | - | - | - | - |
| STAND AND SHOOT | 38 | 38 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 22 | 22 | 0 | 0.00 | - | - |
| STANDS STILL | 997 | 997 | 0 | 0.00 | - | - |
| STOPS | 2 | 2 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 323 | not checked | - | - | - | - |
| THE PROMISED MOVE | 58 | not checked | - | - | - | - |
| WAITS AGAIN | 94 | 94 | 0 | 0.00 | - | - |
| WAR ENGINE CHARGES | 1 | 1 | 0 | 0.00 | - | - |
| WAR ENGINE JOBS | 6 | 6 | 0 | 0.00 | - | - |

### Off best figure: h3-mine-efe7e34-p3

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| PATHS CROSS | rule | 0.33 | 0.92 | 24.8 |
| HOLDER ASSIGNMENT | rule | 0.94 | - | 23.7 |
| CHARGE NOT DECLARED | rule | 0.17 | 0.67 | 209.7 |
| CHARGE NOW FIRST | rule | 0.47 | 0.33 | 43.9 |
| JOB FIRST | gate | 0.08 | 0.31 | 8.2 |
| AFTERMATH BAND | gate | 0.19 | 0.08 | 2.6 |
| CHAFF PASSED | rule | 0.11 | 0.11 | 4.3 |
| SUPPORT NARROWED | rule | 0.03 | 0.19 | 6.1 |
| CANNON PLANNED TARGET | rule | 0.19 | - | 93.1 |
| DEPLOY BY FIGURES | rule | 0.08 | 0.08 | 22.9 |
| FRIENDS SHOTS CHECKED | rule | 0.14 | - | 2.6 |
| PURSUES BIG PREY | rule | 0.08 | 0.06 | 108.8 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.08 | 0.03 | 34.4 |
| BEST PRIZE | rule | - | 0.11 | 57.1 |
| PIVOT GUARDS FLANK | rule | 0.06 | 0.06 | 7.7 |
| FIGHT ORDER BAND | gate | 0.03 | 0.06 | 2.2 |
| RULE SWITCHED OFF | gate | - | 0.08 | 122.7 |
| WHO HITS BACK | rule | 0.03 | 0.06 | 3.0 |
| MARCH ODDS | rule | 0.06 | - | 15.4 |
| REDIRECT WEIGHED | rule | - | 0.06 | 82.7 |
| CARRIES OUT SET-UP | rule | 0.03 | - | 14.1 |
| FALLBACK | gate | - | 0.03 | 0.7 |
| REFUSING RETIRES | rule | 0.03 | - | 0.7 |
| TURN GATE | gate | 0.03 | - | 9.5 |

### Plans: h3-mine-efe7e34-p3

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 2.8 | 66% | 564 | 297 | 53% |
| Mine | join | 0.5 | 88% | 16 | 0 | 0% |
| Mine | move | 27.5 | 95% | 1757 | 0 | 0% |
| Mine | shoot | 9.1 | 61% | 406 | 648 | 159% |
| Mine | support | 0.2 | 100% | 5 | 0 | 0% |
| Opponent | charge | 3.4 | 61% | 634 | 395 | 62% |
| Opponent | join | 0.4 | 94% | 21 | 0 | 0% |
| Opponent | move | 31.9 | 94% | 1895 | 0 | 0% |
| Opponent | shoot | 2.7 | 51% | 92 | 99 | 108% |
| Opponent | support | 1.2 | 82% | 16 | 0 | 0% |

### Packages: hunt the guns, h3-mine-efe7e34-p3

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 13 |
| Opponent | 0.1 | 2 | 1 | 0% | 0% | 0% | - | 208 | 0 | 0% | 76 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 21 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 76 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 46 |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 140 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Ogre Kingdoms | 0.3 | 1 | 1 | - | - | - | - | - | - | - | 151 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 137 |
| Tomb Kings of Khemri | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 49 |
| Vampire Counts | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 208 | 0 | 0% | 36 |
| Warriors of Chaos | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 22 |
| Wood Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 2 |

### Battle groups: h3-mine-efe7e34-p3

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 2.5 | 30% | 59% | 22% | 17% | 33% | 0% | 0% | 67% | 0% |
| Opponent | REDIRECT COUNTER | 5.2 | 19% | 71% | 6% | 50% | 30% | 3% | 9% | 58% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: h3-mine-efe7e34-p3

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 4 | 58 (4) | 58 | 0 | 62 | 0% | 3.2 | - | 152 (1) | - | - | 152 (1) |
| Mine | Chaff | 35 | 63 (35) | 20 | 43 | 61 | 31% | 2.3 | 63 (17) | 107 (9) | 12 (9) | 69 (32) | 0 (3) |
| Mine | Character | 125 | 51 (125) | 50 | 1 | 24 | 21% | 2.6 | 54 (45) | 45 (57) | 80 (15) | 54 (83) | 54 (34) |
| Mine | Clean-up | 21 | 75 (21) | 12 | 64 | 35 | 24% | 3.4 | 39 (6) | 106 (11) | 0 (4) | 76 (15) | 69 (6) |
| Mine | Fast | 1 | 236 (1) | 236 | 0 | 0 | 0% | 4.0 | 236 (1) | - | - | 236 (1) | - |
| Mine | Fast Hammer | 42 | 49 (42) | 25 | 24 | 47 | 21% | 3.0 | 58 (8) | 52 (25) | 27 (9) | 55 (34) | 17 (8) |
| Mine | Fragile | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | - | - | - | - |
| Mine | Hammer | 52 | 30 (52) | 18 | 12 | 43 | 25% | 2.5 | 34 (19) | 25 (24) | 36 (9) | 33 (39) | 26 (13) |
| Mine | Holder | 33 | 97 (33) | 9 | 88 | 17 | 42% | 3.1 | 70 (6) | 93 (14) | 125 (13) | 134 (21) | 48 (12) |
| Mine | Infantry | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Mine | Shooter | 35 | 67 (35) | 11 | 56 | 41 | 6% | 1.8 | 34 (14) | 108 (15) | 30 (6) | 97 (21) | 19 (14) |
| Mine | Support | 2 | 0 (2) | 0 | 0 | 50 | 0% | 5.5 | 0 (1) | 0 (1) | - | - | 0 (2) |
| Mine | War machine | 57 | 39 (57) | 39 | 0 | 29 | 2% | 1.2 | 35 (22) | 49 (24) | 18 (11) | 60 (13) | 33 (44) |
| Mine | Wizard | 19 | 14 (19) | 14 | 0 | 40 | 16% | 2.9 | 0 (3) | 32 (9) | 0 (3) | 0 (6) | 39 (9) |
| Opponent | Blocker | 1 | 106 (1) | 106 | 0 | 0 | 0% | 6.0 | - | 106 (1) | - | - | 106 (1) |
| Opponent | Chaff | 82 | 111 (82) | 43 | 68 | 41 | 43% | 3.1 | 139 (26) | 121 (26) | 72 (30) | 125 (67) | 49 (15) |
| Opponent | Character | 93 | 51 (93) | 50 | 1 | 30 | 19% | 2.1 | 44 (27) | 62 (47) | 37 (15) | 45 (51) | 62 (38) |
| Opponent | Clean-up | 14 | 90 (14) | 15 | 75 | 24 | 21% | 3.6 | 0 (2) | 103 (9) | 88 (3) | 104 (10) | 66 (4) |
| Opponent | Early | 1 | 87 (1) | 87 | 0 | 0 | 0% | 3.0 | - | - | 87 (1) | - | 87 (1) |
| Opponent | Fast | 2 | 0 (2) | 0 | 0 | 100 | 50% | 3.0 | 0 (1) | 0 (1) | - | 0 (2) | - |
| Opponent | Fast Hammer | 51 | 45 (51) | 11 | 34 | 43 | 37% | 2.8 | 50 (13) | 42 (25) | 47 (13) | 57 (31) | 21 (20) |
| Opponent | Fragile | 5 | 0 (5) | 0 | 0 | 0 | 20% | 2.8 | - | 0 (4) | - | 0 (3) | 0 (1) |
| Opponent | Hammer | 61 | 36 (61) | 23 | 13 | 37 | 28% | 3.2 | 52 (8) | 30 (28) | 38 (25) | 42 (38) | 27 (23) |
| Opponent | Holder | 28 | 48 (28) | 1 | 47 | 40 | 39% | 3.2 | 35 (7) | 73 (14) | 0 (7) | 53 (15) | 44 (13) |
| Opponent | Shooter | 33 | 61 (33) | 9 | 52 | 57 | 6% | 1.8 | 62 (10) | 65 (20) | 19 (3) | 62 (19) | 60 (14) |
| Opponent | Support | 1 | 0 (1) | 0 | 0 | 0 | 0% | 5.0 | - | 0 (1) | - | - | 0 (1) |
| Opponent | War machine | 12 | 30 (12) | 30 | 0 | 11 | 0% | 2.0 | 72 (4) | 0 (5) | 23 (3) | - | 30 (12) |
| Opponent | Wizard | 15 | 2 (15) | 2 | 0 | 49 | 13% | 2.5 | 0 (1) | 0 (7) | 10 (2) | 5 (4) | 0 (6) |

### Charged fights: h3-mine-efe7e34-p3

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 76 | 47 | 1.8 | 1.4 | 27 | 51 | -24 | 4 of 7 | 3 of 7 | -92 | +4 |
| Mine | Chaos Dwarfs | 4 | 478 | 272 | 1.8 | 1.0 | 156 | 0 | +156 | 3 of 7 | 6 of 7 | - | +156 |
| Mine | Dwarfen Mountain Holds | 3 | 268 | 0 | 0.7 | 1.5 | 0 | 30 | -30 | 0 of 2 | 2 of 2 | -60 | +0 |
| Mine | Empire of Man | 5 | 290 | 132 | 1.8 | 1.1 | 73 | 28 | +45 | 0 of 9 | 8 of 9 | +221 | +24 |
| Mine | Grand Cathay | 5 | 560 | 274 | 3.8 | 1.0 | 72 | 0 | +72 | 5 of 19 | 16 of 19 | - | +72 |
| Mine | High Elf Realms | 3 | 106 | 370 | 3.7 | 1.1 | 101 | 44 | +57 | 5 of 11 | 6 of 11 | +758 | -13 |
| Mine | Kingdom of Bretonnia | 2 | 117 | 429 | 2.5 | 1.0 | 172 | 0 | +172 | 3 of 5 | 5 of 5 | - | +172 |
| Mine | Lizardmen | 1 | 629 | 477 | 6.0 | 1.0 | 80 | 107 | -27 | 2 of 6 | 5 of 6 | - | -27 |
| Mine | Ogre Kingdoms | 1 | 624 | 167 | 6.0 | 1.0 | 28 | 6 | +22 | 0 of 6 | 4 of 6 | - | +22 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 464 | 4.0 | 1.0 | 116 | 82 | +34 | 1 of 4 | 3 of 4 | - | +34 |
| Mine | Skaven | 1 | 0 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 0 of 1 | 0 of 1 | - | +0 |
| Mine | Tomb Kings of Khemri | 2 | 30 | 779 | 2.5 | 1.4 | 312 | 0 | +312 | 3 of 5 | 5 of 5 | +393 | +291 |
| Mine | Vampire Counts | 2 | 170 | 628 | 5.5 | 1.2 | 114 | 0 | +114 | 4 of 11 | 9 of 11 | +198 | +96 |
| Mine | Warriors of Chaos | 2 | 67 | 46 | 1.0 | 1.0 | 46 | 58 | -12 | 0 of 2 | 1 of 2 | - | -12 |
| **Mine** | all armies | 36 | 267 | 258 | 2.6 | 1.1 | 98 | 24 | +74 | 30 of 95 | 73 of 95 | +190 | +63 |
| Opponent | Grand Cathay | 3 | 367 | 71 | 2.7 | 1.1 | 27 | 0 | +27 | 3 of 8 | 5 of 8 | +77 | +20 |
| Opponent | High Elf Realms | 3 | 91 | 249 | 2.0 | 1.0 | 124 | 10 | +114 | 2 of 6 | 4 of 6 | - | +114 |
| Opponent | Kingdom of Bretonnia | 2 | 0 | 62 | 2.0 | 1.0 | 31 | 112 | -80 | 2 of 4 | 3 of 4 | - | -80 |
| Opponent | Ogre Kingdoms | 2 | 268 | 440 | 5.5 | 1.0 | 80 | 27 | +53 | 4 of 11 | 6 of 11 | - | +53 |
| Opponent | Skaven | 2 | 110 | 93 | 1.0 | 1.0 | 93 | 0 | +93 | 1 of 2 | 0 of 2 | - | +93 |
| Opponent | Tomb Kings of Khemri | 2 | 62 | 856 | 5.0 | 1.0 | 171 | 82 | +90 | 5 of 10 | 7 of 9 | - | +90 |
| Opponent | Vampire Counts | 3 | 0 | 596 | 3.7 | 1.1 | 163 | 30 | +133 | 5 of 11 | 8 of 11 | +0 | +146 |
| Opponent | Warriors of Chaos | 11 | 15 | 473 | 2.4 | 1.1 | 200 | 1 | +199 | 13 of 26 | 22 of 26 | +284 | +188 |
| Opponent | Wood Elf Realms | 8 | 77 | 408 | 4.6 | 1.1 | 88 | 55 | +33 | 18 of 37 | 21 of 37 | +177 | +11 |
| **Opponent** | all armies | 36 | 84 | 392 | 3.2 | 1.1 | 123 | 35 | +88 | 53 of 115 | 76 of 114 | +181 | +79 |

### Effective charges: h3-mine-efe7e34-p3

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 7 | 5 (net -42) | 0 | 0 | 1 (net +0) | 0 | 1 (net +41) | 0 | 0% (0 of 7) |
| Mine | Chaos Dwarfs | 7 | 0 | 0 | 1 (net +482) | 4 (net +76) | 0 | 2 (net +151) | 0 | 14% (1 of 7) |
| Mine | Dwarfen Mountain Holds | 2 | 0 | 0 | 0 | 1 (net +0) | 0 | 1 (net -60) | 0 | 0% (0 of 2) |
| Mine | Empire of Man | 9 | 0 | 0 | 2 (net +0) | 2 (net +82) | 1 (net +60) | 4 (net +46) | 0 | 22% (2 of 9) |
| Mine | Grand Cathay | 19 | 0 | 1 (net +432) | 4 (net +0) | 4 (net +97) | 2 (net +30) | 8 (net +61) | 0 | 21% (4 of 19) |
| Mine | High Elf Realms | 11 | 3 (net +77) | 0 | 2 (net +30) | 1 (net +758) | 2 (net +0) | 2 (net -241) | 1 | 20% (2 of 10) |
| Mine | Kingdom of Bretonnia | 5 | 0 | 0 | 2 (net +250) | 0 | 2 (net +46) | 1 (net +267) | 0 | 40% (2 of 5) |
| Mine | Lizardmen | 6 | 0 | 0 | 0 | 1 (net +0) | 0 | 4 (net +119) | 1 | 0% (0 of 5) |
| Mine | Ogre Kingdoms | 6 | 2 (net -17) | 0 | 1 (net +30) | 1 (net +137) | 0 | 2 (net +0) | 0 | 17% (1 of 6) |
| Mine | Orc & Goblin Tribes | 4 | 0 | 1 (net +0) | 1 (net +0) | 0 | 0 | 0 | 2 | 50% (1 of 2) |
| Mine | Skaven | 1 | 0 | 0 | 1 (net +0) | 0 | 0 | 0 | 0 | 100% (1 of 1) |
| Mine | Tomb Kings of Khemri | 5 | 1 (net +465) | 0 | 0 | 1 (net +470) | 1 (net +60) | 2 (net +282) | 0 | 0% (0 of 5) |
| Mine | Vampire Counts | 11 | 4 (net +63) | 0 | 1 (net +0) | 2 (net +201) | 1 (net +120) | 3 (net +161) | 0 | 9% (1 of 11) |
| Mine | Warriors of Chaos | 2 | 0 | 0 | 0 | 0 | 0 | 1 (net +91) | 1 | 0% (0 of 1) |
| Opponent | Grand Cathay | 8 | 2 (net +42) | 0 | 0 | 3 (net +26) | 3 (net +17) | 0 | 0 | 0% (0 of 8) |
| Opponent | High Elf Realms | 6 | 0 | 0 | 1 (net -60) | 3 (net +145) | 0 | 1 (net +310) | 1 | 20% (1 of 5) |
| Opponent | Kingdom of Bretonnia | 4 | 1 (net +0) | 0 | 1 (net +125) | 0 | 1 (net +0) | 1 (net -446) | 0 | 25% (1 of 4) |
| Opponent | Ogre Kingdoms | 11 | 1 (net +471) | 0 | 4 (net +39) | 1 (net -228) | 0 | 3 (net +73) | 2 | 44% (4 of 9) |
| Opponent | Skaven | 2 | 1 (net +0) | 0 | 0 | 0 | 0 | 1 (net +186) | 0 | 0% (0 of 2) |
| Opponent | Tomb Kings of Khemri | 10 | 2 (net +108) | 0 | 2 (net +96) | 3 (net -3) | 1 (net +149) | 1 (net +227) | 1 | 22% (2 of 9) |
| Opponent | Vampire Counts | 11 | 3 (net +41) | 0 | 0 | 3 (net +17) | 2 (net +161) | 3 (net +322) | 0 | 0% (0 of 11) |
| Opponent | Warriors of Chaos | 26 | 1 (net +0) | 0 | 2 (net +56) | 6 (net +361) | 4 (net +91) | 11 (net +199) | 2 | 8% (2 of 24) |
| Opponent | Wood Elf Realms | 37 | 10 (net -42) | 2 (net +58) | 3 (net +212) | 4 (net +58) | 1 (net +120) | 10 (net +157) | 7 | 10% (3 of 30) |

### Charged fights, damage counted: h3-mine-efe7e34-p3

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 15 | 244 | 293 | +47 | 102 | 62 | +40 | +16.3 |
| Mine | 50-54% | 2 | 360 | 328 | +216 | 216 | 0 | +216 | +60.1 |
| Mine | Effective (55-75%) | 15 | 284 | 244 | +71 | 115 | 14 | +100 | +35.3 |
| Mine | 76-89% | 18 | 283 | 170 | +146 | 168 | 23 | +145 | +51.0 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 31 | 287 | 176 | +76 | 127 | 33 | +93 | +32.6 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 9 | 315 | 71 | +43 | 43 | 0 | +43 | +13.8 |
| Mine | No odds | 5 | 342 | 178 | -112 | 162 | 263 | -101 | -29.5 |
| Mine | All fights | 95 | 286 | 197 | +74 | 124 | 41 | +83 | +29.1 |
| Opponent | Long shot (under 50%) | 21 | 180 | 243 | +23 | 64 | 48 | +16 | +8.8 |
| Opponent | 50-54% | 2 | 27 | 144 | +58 | 72 | 14 | +58 | +216.7 |
| Opponent | Effective (55-75%) | 13 | 198 | 146 | +89 | 173 | 90 | +83 | +42.0 |
| Opponent | 76-89% | 23 | 384 | 246 | +118 | 176 | 49 | +127 | +33.1 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 31 | 407 | 221 | +168 | 204 | 27 | +177 | +43.5 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 12 | 433 | 94 | +84 | 103 | 13 | +90 | +20.8 |
| Opponent | No odds | 13 | 133 | 225 | -46 | 63 | 130 | -67 | -50.6 |
| Opponent | All fights | 115 | 303 | 207 | +88 | 141 | 52 | +88 | +29.2 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| h3-mine-efe7e34-p3 | move | 296 | 72 (24%) | 59 (20%) | 33 (11%) | 191 (65%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0111, L0128, L2433, L2631 |
| Charmed Shield | Opponent | L0534, L0726, L1124, L1634, L2034, L2224, L2834, L3134 |
| Clockwork Compass | Mine | L1216, L1233 |
| Elixir of Power | Mine | L1124, L1933 |
| Elixir of Power | Opponent | L0111, L0211 |
| Fistful of Laurels | Mine | L1832 |
| Fistful of Laurels | Opponent | L0518, L1618 |
| Horn of the Wild Hunt | Opponent | L1233, L1933, L2433 |
| Invocation of Nehek | Mine | L2433 |
| Invocation of Nehek | Opponent | L1124, L2224 |
| Opal Amulet | Mine | L1423 |
| Periapt of Soul Exchange | Mine | L2034 |
| Periapt of Soul Exchange | Opponent | L0621, L1520 |
| Ring of Doom | Mine | L0211, L0228, L1124, L1216, L1233, L1520, L3134 |
| Ring of Doom | Opponent | L0111, L0211, L0415, L1015, L1233, L1933, L2433, L2631 |
| Ring of Jet | Mine | L1015, L1032, L1124, L1216, L1233 |
| Ring of Jet | Opponent | L0111, L0211, L0710 |
| Standard of the Fell Warrior | Mine | L1328 |
| Standard of the Fell Warrior | Opponent | L0313 |
| Storm Daemon (Renegade 2.0) | Opponent | L0621 |
| Twice-Blessed Armour | Mine | L0710, L0726, L1015, L1032 |
| Twice-Blessed Armour | Opponent | L0710 |
| Witch Hunter's Ward | Mine | L0710, L0726, L0816, L0832 |

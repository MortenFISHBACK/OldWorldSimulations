# Doctrine scorecard: h3-opp-efe7e34-p3

### Scorecard: h3-opp-efe7e34-p3

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0111 | 3 | 1 | Mine | yes | 5 | - | 0 | 2 | 0 | 0 | 0 | 0 |
| L0111 | 3 | 1 | Opponent | no | 7 | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L0128 | 2 | 1 | Mine | - | - | - | 0 | 4 | 0 | 0 | 0 | 0 |
| L0128 | 2 | 1 | Opponent | - | - | - | 0 | 3 | 0 | 0 | 0 | 0 |
| L0211 | 1 | 1 | Mine | no | 2 | 3 | 1 | 3 | 0 | 0 | 0 | 281 |
| L0211 | 1 | 1 | Opponent | yes | 13 | 2 | 1 | 1 | 0 | 0 | 0 | 0 |
| L0228 | 6 | 1 | Mine | no | 0 | 2 | 3 | 2 | 1 | 0 | 0 | 170 |
| L0228 | 6 | 1 | Opponent | no | 4 | - | 0 | 0 | 0 | 0 | 0 | 0 |
| L0313 | 1 | 1 | Mine | no | 2 | - | 0 | 1 | 0 | 0 | 0 | 85 |
| L0313 | 1 | 1 | Opponent | no | 7 | 2 | 2 | 0 | 1 | 0 | 0 | 70 |
| L0330 | 6 | 1 | Mine | no | 6 | - | 0 | 0 | 0 | 0 | 0 | 110 |
| L0330 | 6 | 1 | Opponent | no | 2 | 2 | 0 | 2 | 0 | 0 | 0 | 0 |
| L0415 | 1 | 1 | Mine | no | 5 | 5 | 1 | 3 | 0 | 0 | 0 | 310 |
| L0415 | 1 | 1 | Opponent | no | 4 | 2 | 1 | 0 | 0 | 0 | 0 | 0 |
| L0432 | 6 | 1 | Mine | no | 1 | 3 | 3 | 2 | 0 | 0 | 0 | 310 |
| L0432 | 6 | 1 | Opponent | no | 3 | 2 | 4 | 3 | 2 | 0 | 0 | 340 |
| L0518 | 2 | 1 | Mine | - | - | 1 | 0 | 1 | 0 | 0 | 0 | 839 |
| L0518 | 2 | 1 | Opponent | - | - | 5 | 2 | 2 | 1 | 0 | 0 | 0 |
| L0534 | 6 | 1 | Mine | no | 2 | 5 | 2 | 0 | 0 | 0 | 0 | 596 |
| L0534 | 6 | 1 | Opponent | no | 4 | 2 | 6 | 5 | 0 | 0 | 0 | 56 |
| L0621 | 3 | 1 | Mine | no | 0 | - | 1 | 2 | 0 | 0 | 0 | 400 |
| L0621 | 3 | 1 | Opponent | yes | 3 | - | 0 | 5 | 1 | 0 | 0 | 500 |
| L0710 | 2 | 1 | Mine | - | - | 2 | 2 | 1 | 0 | 0 | 0 | 250 |
| L0710 | 2 | 1 | Opponent | - | - | 2 | 1 | 1 | 0 | 0 | 0 | 0 |
| L0726 | 6 | 1 | Mine | no | 9 | 2 | 1 | 0 | 0 | 0 | 0 | 250 |
| L0726 | 6 | 1 | Opponent | no | 1 | 2 | 2 | 0 | 1 | 0 | 0 | 0 |
| L0816 | 6 | 1 | Mine | no | 2 | - | 0 | 2 | 0 | 0 | 0 | 0 |
| L0816 | 6 | 1 | Opponent | no | 9 | - | 2 | 0 | 0 | 0 | 0 | 100 |
| L0832 | 4 | 1 | Mine | no | 0 | - | 1 | 0 | 0 | 0 | 0 | 520 |
| L0832 | 4 | 1 | Opponent | no | 1 | 2 | 2 | 2 | 2 | 0 | 0 | 170 |
| L0922 | 4 | 1 | Mine | no | 0 | - | 0 | 0 | 0 | 0 | 0 | 162 |
| L0922 | 4 | 1 | Opponent | yes | 2 | 2 | 5 | 2 | 2 | 0 | 0 | 0 |
| L1015 | 1 | 1 | Mine | no | 2 | 3 | 3 | 2 | 0 | 0 | 0 | 0 |
| L1015 | 1 | 1 | Opponent | no | 0 | 3 | 1 | 2 | 0 | 0 | 0 | 115 |
| L1032 | 6 | 1 | Mine | no | 3 | 4 | 1 | 0 | 1 | 0 | 0 | 499 |
| L1032 | 6 | 1 | Opponent | no | 4 | 3 | 5 | 1 | 0 | 0 | 0 | 0 |
| L1124 | 2 | 1 | Mine | - | - | 1 | 5 | 0 | 0 | 0 | 0 | 165 |
| L1124 | 2 | 1 | Opponent | - | - | 6 | 1 | 4 | 0 | 0 | 0 | 0 |
| L1216 | 4 | 1 | Mine | no | 0 | 2 | 6 | 0 | 0 | 0 | 0 | 330 |
| L1216 | 4 | 1 | Opponent | no | 6 | 6 | 1 | 1 | 0 | 0 | 0 | 471 |
| L1233 | 3 | 1 | Mine | no | 6 | 2 | 3 | 0 | 0 | 0 | 0 | 165 |
| L1233 | 3 | 1 | Opponent | no | 2 | 1 | 2 | 3 | 1 | 0 | 0 | 783 |
| L1328 | 2 | 1 | Mine | - | - | 3 | 3 | 1 | 0 | 0 | 0 | 317 |
| L1328 | 2 | 1 | Opponent | - | - | - | 0 | 1 | 0 | 0 | 0 | 0 |
| L1423 | 1 | 1 | Mine | no | 1 | 2 | 3 | 0 | 0 | 0 | 0 | 0 |
| L1423 | 1 | 1 | Opponent | no | 3 | 2 | 3 | 2 | 1 | 0 | 0 | 66 |
| L1520 | 2 | 1 | Mine | - | - | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L1520 | 2 | 1 | Opponent | - | - | 6 | 1 | 1 | 0 | 0 | 0 | 420 |
| L1618 | 4 | 1 | Mine | no | 5 | 6 | 2 | 1 | 0 | 0 | 0 | 0 |
| L1618 | 4 | 1 | Opponent | no | 1 | 2 | 5 | 0 | 1 | 0 | 0 | 234 |
| L1634 | 2 | 1 | Mine | - | - | 2 | 3 | 1 | 0 | 0 | 0 | 100 |
| L1634 | 2 | 1 | Opponent | - | - | 1 | 5 | 1 | 0 | 0 | 0 | 56 |
| L1732 | 4 | 1 | Mine | no | 1 | 2 | 1 | 0 | 1 | 0 | 0 | 0 |
| L1732 | 4 | 1 | Opponent | no | 0 | 2 | 7 | 2 | 1 | 0 | 0 | 340 |
| L1832 | 2 | 1 | Mine | - | - | 2 | 7 | 0 | 0 | 0 | 0 | 0 |
| L1832 | 2 | 1 | Opponent | - | - | 2 | 3 | 3 | 0 | 0 | 0 | 170 |
| L1933 | 1 | 1 | Mine | no | 2 | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L1933 | 1 | 1 | Opponent | yes | 6 | 3 | 1 | 1 | 0 | 0 | 0 | 549 |
| L2034 | 6 | 1 | Mine | no | 1 | - | 0 | 3 | 0 | 0 | 0 | 420 |
| L2034 | 6 | 1 | Opponent | no | 0 | 3 | 3 | 3 | 0 | 0 | 0 | 315 |
| L2224 | 4 | 1 | Mine | no | 0 | 2 | 7 | 1 | 0 | 0 | 0 | 170 |
| L2224 | 4 | 1 | Opponent | no | 0 | 1 | 1 | 0 | 1 | 0 | 0 | 0 |
| L2329 | 1 | 1 | Mine | no | 5 | 2 | 4 | 1 | 0 | 0 | 0 | 70 |
| L2329 | 1 | 1 | Opponent | no | 4 | 3 | 5 | 2 | 2 | 0 | 0 | 170 |
| L2433 | 3 | 1 | Mine | no | 8 | 3 | 2 | 0 | 0 | 0 | 0 | 0 |
| L2433 | 3 | 1 | Opponent | no | 6 | 2 | 8 | 2 | 0 | 0 | 0 | 405 |
| L2631 | 3 | 1 | Mine | no | 0 | 2 | 8 | 2 | 0 | 0 | 0 | 0 |
| L2631 | 3 | 1 | Opponent | no | 3 | 5 | 1 | 0 | 0 | 0 | 0 | 927 |
| L2834 | 2 | 1 | Mine | - | - | - | 0 | 1 | 1 | 0 | 0 | 0 |
| L2834 | 2 | 1 | Opponent | - | - | 2 | 0 | 6 | 0 | 0 | 0 | 291 |
| L3134 | 2 | 1 | Mine | - | - | 2 | 3 | 0 | 0 | 0 | 0 | 456 |
| L3134 | 2 | 1 | Opponent | - | - | 2 | 4 | 5 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 4% | 2.6 | 2.6 | 2.3 | 1.1 | 0.1 | 0.0 | 0.0 | 193.8 |
| **Average** | | | Opponent | 15% | 3.7 | 2.6 | 2.4 | 1.9 | 0.5 | 0.0 | 0.0 | 181.9 |

### KPIs: h3-opp-efe7e34-p3

Rules off - Mine only: HOLDER ASSIGNMENT.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 27% (48 of 180) | 8% (14 of 171) | 18% (62 of 351) |
| Winner chose to follow up after the loser gave ground |  | 77% (47 of 61); on the table 80% | 86% (42 of 49); on the table 88% | 81% (89 of 110); on the table 84% |
| Winner chose to pursue after the loser fell back in good order |  | 73% (8 of 11); on the table 73% | 75% (6 of 8); on the table 75% | 74% (14 of 19); on the table 74% |
| Winner chose to pursue after the loser fled |  | 67% (16 of 24); on the table 71% | 55% (11 of 20); on the table 55% | 61% (27 of 44); on the table 64% |
| Winner chose to follow up or pursue (all three) |  | 74% (71 of 96); on the table 77% | 77% (59 of 77); on the table 78% | 75% (130 of 173); on the table 77% |
| Magic missiles tried each own turn | 50%+ | 32% (107 of 330) | 33% (47 of 144) | 32% (154 of 474) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 45% (107 of 240) | 41% (47 of 116) | 43% (154 of 356) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 53% (10 of 19) | 47% (36 of 77) | 48% (46 of 96) |
| Points that never fought | lower | 41% (29324 of 71555) | 42% (30340 of 71975) | 42% (59664 of 143530) |
|   infantry points that never fought | lower | 60% (9093 of 15035) | 66% (8711 of 13201) | 63% (17804 of 28236) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 56% (159 of 282) | 51% (141 of 275) | 54% (300 of 557) |
| Bound items with a magic missile used (at least once a game) |  | 87% (20 of 23); 2.0 uses a game | 95% (20 of 21); 1.6 uses a game | 91% (40 of 44); 1.8 uses a game |
| Bound items with another spell used |  | 43% (6 of 14); 0.4 uses a game | 0% (0 of 3); 0.0 uses a game | 35% (6 of 17); 0.2 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 57% (12 of 21); 0.3 uses a game | 38% (6 of 16); 0.2 uses a game | 49% (18 of 37); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 52% (32121 of 61235) | 49% (31441 of 64665) | 50% (63562 of 125900) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.7 (27%) | 0.6 (22%) | 2.3 (26%) |
| MARCHED: its unit marched | 1.4 (23%) | 0.8 (30%) | 2.2 (25%) |
| CHARGED: its unit charged | 0.2 (3%) | 0.1 (3%) | 0.3 (3%) |
| IN COMBAT: engaged in combat | 1.5 (24%) | 0.5 (20%) | 2.0 (23%) |
| REAR RANK: in a rear rank | 0.2 (3%) | 0.1 (5%) | 0.3 (3%) |
| FLEEING: fleeing | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| GONE: slain | 0.6 (10%) | 0.2 (7%) | 0.8 (9%) |
| OFF THE TABLE: off the table or not arrived | 0.3 (5%) | 0.1 (2%) | 0.4 (4%) |
| STUPIDITY: Stupidity | 0.1 (2%) | 0.1 (4%) | 0.2 (3%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.1 (1%) | 0.2 (7%) | 0.2 (3%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.2 | 1.7 | 1.2 | 4.3 | 0.5 | 2.0 |
| not cast | 3.0 | 3.1 | 3.3 | 8.9 | 2.0 | 18.3 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.1 (6%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.4 (43%) | 0.2 (6%) | 2.3 (26%) | 0.3 (15%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.2 (25%) | 0.6 (29%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (3%) | 0.1 (4%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.2 (6%) | 0.3 (11%) | 0.6 (17%) | 2.0 (23%) | 0.7 (35%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.1 (3%) | 0.5 (16%) | 0.4 (12%) | 0.3 (3%) | 0.0 (0%) | 0.0 (0%) |
| NO CASTS LEFT: every cast used on other spells | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) |
| FLEEING: fleeing | 0.1 (3%) | 0.0 (1%) | 0.0 (1%) | 0.1 (1%) | 0.0 (0%) | 0.3 (2%) |
| GONE: slain | 0.9 (31%) | 0.3 (11%) | 0.5 (16%) | 0.8 (9%) | 0.2 (10%) | 1.8 (10%) |
| OFF THE TABLE: off the table or not arrived | 0.1 (5%) | 0.0 (0%) | 0.0 (0%) | 0.4 (4%) | 0.0 (0%) | 0.2 (1%) |
| STUPIDITY: Stupidity | 0.1 (4%) | 0.1 (3%) | 0.1 (4%) | 0.2 (3%) | 0.1 (3%) | 0.5 (3%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.2 (7%) | 0.3 (10%) | 0.0 (0%) | 0.0 (0%) | 0.1 (3%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (3%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.2 (42%) | 0.2 (6%) | 1.4 (44%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 14.4 (79%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.9 a game | 0.5 a game | 0.7 a game |
| stood (cast and not dispelled) | 56% (18 of 32) | 88% (7 of 8) | 62% (25 of 40) |
| the unit moved after it | 50% (9 of 18) | 100% (7 of 7) | 64% (16 of 25) |
| it charged on its next turn | 6% (1 of 18) | 0% (0 of 7) | 4% (1 of 25) |
| the enemy charged it first | 6% (1 of 18) | 0% (0 of 7) | 4% (1 of 25) |
| it fought by the end of its next turn | 0% (0 of 18) | 0% (0 of 7) | 0% (0 of 25) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 18) | 29% (2 of 7) | 8% (2 of 25) |
| none of these (no charge, no fight, no charge escaped) | 89% (16 of 18) | 71% (5 of 7) | 84% (21 of 25) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 66% (563 of 852) | 53% (334 of 635) | 60% (897 of 1487) |
|   cavalry | 71% (70 of 98) | 66% (87 of 131) | 69% (157 of 229) |
|   character | 55% (57 of 103) | 35% (58 of 164) | 43% (115 of 267) |
|   chariot | 76% (63 of 83) | 53% (24 of 45) | 68% (87 of 128) |
|   infantry | 59% (140 of 236) | 57% (124 of 216) | 58% (264 of 452) |
|   monster | 58% (21 of 36) | 47% (8 of 17) | 55% (29 of 53) |
|   war machine | 72% (212 of 296) | 53% (33 of 62) | 68% (245 of 358) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.6 (20%) | 2.0 (24%) | 3.6 (22%) |
| CHARGED: it charged | 0.7 (9%) | 1.5 (18%) | 2.2 (14%) |
| FLEEING: it fled or was fleeing | 0.2 (3%) | 0.2 (2%) | 0.4 (3%) |
| IN COMBAT: it fought this turn or the last | 0.7 (8%) | 0.3 (4%) | 1.0 (6%) |
| MOVED: a war machine that moved | 1.2 (15%) | 0.6 (8%) | 1.8 (11%) |
| NO TARGET IN RANGE | 1.2 (15%) | 1.6 (19%) | 2.8 (17%) |
| ONLY IN COMBAT: the only targets were in combat | 0.5 (7%) | 0.1 (1%) | 0.6 (4%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.5 (19%) | 1.5 (18%) | 3.0 (18%) |
| SHELTERED: the target was sheltered | 0.2 (3%) | 0.2 (2%) | 0.4 (3%) |
| STUPIDITY | 0.0 (0%) | 0.2 (2%) | 0.2 (1%) |
| OTHER BAR | 0.2 (2%) | 0.1 (2%) | 0.3 (2%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 6.9 | 1.3 | 86% | 4.9 pts | 34 pts |
| character | 3.6 | 1.0 | 83% | 7.8 pts | 28 pts |
| chariot | 2.4 | 2.0 | 56% | 25.6 pts | 62 pts |
| infantry | 10.9 | 4.6 | 71% | 9.3 pts | 102 pts |
| monster | 0.9 | 0.2 | 79% | 6.5 pts | 6 pts |
| war machine | 6.8 | 7.1 | 54% | 29.0 pts | 198 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.9 | 3.8 | 3.8 |
| Charges that made contact a game | 2.9 | 3.1 | 3.0 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.00 declared, 0.88 contact (24 units) | 0.85 declared, 0.69 contact (13 units) | 0.95 declared, 0.81 contact (37 units) |
|   per unit a game, units carrying another wizard (or one alone) | 1.14 declared, 0.86 contact (7 units) | 0.86 declared, 0.71 contact (7 units) | 1.00 declared, 0.79 contact (14 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.45 declared, 0.33 contact (239 units) | 0.41 declared, 0.33 contact (296 units) | 0.43 declared, 0.33 contact (535 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 32% (24 of 76) | 42% (5 of 12) | 71% (10 of 14) | 38% (39 of 102) |
| Character in a unit | 89% (24 of 27) | 73% (16 of 22) | 100% (3 of 3) | 83% (43 of 52) |
| Character on its own | 69% (24 of 35) | 52% (21 of 40) | 36% (27 of 76) | 48% (72 of 151) |
| Chariot | 76% (13 of 17) | 73% (8 of 11) | - | 75% (21 of 28) |
| Infantry | 51% (33 of 65) | 29% (12 of 41) | 25% (1 of 4) | 42% (46 of 110) |
| Monster | 58% (18 of 31) | 67% (6 of 9) | - | 60% (24 of 40) |
| Monstrous | 83% (15 of 18) | 73% (8 of 11) | - | 79% (23 of 29) |
| War Machines | 70% (30 of 43) | 100% (2 of 2) | - | 71% (32 of 45) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 75% (3 of 4); on the table 75% | 41% (42 of 102) | 63% | 73% (16 of 22) | 83% (5 of 6); 4.0 uses a game | 100% (2 of 2); 1.8 uses a game | 67% (4 of 6); 1.0 uses a game |
| Chaos Dwarfs | 4 | 60% (3 of 5); on the table 60% | 42% (15 of 36) | 59% | 56% (18 of 32) | 0.0 uses a game | 0.0 uses a game | 100% (2 of 2); 0.5 uses a game |
| Dwarfen Mountain Holds | 3 | 70% (7 of 10); on the table 70% | - | 61% | 54% (13 of 24) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 5 | 58% (7 of 12); on the table 58% | 28% (5 of 18) | 45% | 63% (33 of 52) | 0.0 uses a game | 50% (1 of 2); 0.6 uses a game | 50% (2 of 4); 0.4 uses a game |
| Grand Cathay | 8 | 86% (19 of 22); on the table 86% | 31% (55 of 180) | 44% | 42% (30 of 72) | 83% (15 of 18); 7.0 uses a game | 0% (0 of 3); 0.0 uses a game | 25% (2 of 8); 0.2 uses a game |
| High Elf Realms | 6 | 79% (11 of 14); on the table 79% | 21% (5 of 24) | 52% | 50% (23 of 46) | 100% (8 of 8); 4.5 uses a game | 30% (3 of 10); 0.5 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 4 | 73% (8 of 11); on the table 73% | - | 46% | 58% (14 of 24) | 0.0 uses a game | 0.0 uses a game | 100% (4 of 4); 1.0 uses a game |
| Lizardmen | 1 | 100% (4 of 4); on the table 100% | - | 14% | 43% (3 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 3 | 71% (5 of 7); on the table 86% | 0% (0 of 18) | 40% | 71% (15 of 21) | 100% (3 of 3); 3.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 1 | 75% (3 of 4); on the table 75% | 17% (1 of 6) | 16% | 38% (3 of 8) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Skaven | 3 | 0% (0 of 4); on the table 25% | 42% (10 of 24) | 54% | 57% (13 of 23) | 100% (1 of 1); 1.0 uses a game | 0.0 uses a game | 100% (3 of 3); 1.0 uses a game |
| Tomb Kings of Khemri | 4 | 94% (15 of 16); on the table 100% | - | 27% | 35% (7 of 20) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 5 | 82% (14 of 17); on the table 82% | 17% (5 of 30) | 32% | 39% (12 of 31) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 13 | 71% (22 of 31); on the table 74% | 44% (16 of 36) | 32% | 57% (60 of 105) | 100% (2 of 2); 0.5 uses a game | 0.0 uses a game | 100% (1 of 1); 0.1 uses a game |
| Wood Elf Realms | 8 | 75% (9 of 12); on the table 75% | - | 33% | 57% (40 of 70) | 100% (6 of 6); 1.5 uses a game | 0.0 uses a game | 0% (0 of 8); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (h3-opp-efe7e34-p3, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 46% (32) | 52% (38) | 49% (70) |
| ...free all their last turn and able to turn (per game) | 0.61 | 0.67 | 1.28 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.11 | 0.08 | 0.19 |
| ...with the charger already in that arc before they moved (per game) | 0.47 | 0.42 | 0.89 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.03 | 0.03 | 0.06 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.33 | 0.22 | 0.56 |

### Quality by phase: h3-opp-efe7e34-p3

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.4 | 2.2 |
| Strategy | Charge objectives carried out (made contact) | 68% (81 of 119) | 63% (76 of 121) |
| Strategy | Shoot objectives carried out (shot that target) | 40% (157 of 395) | 46% (58 of 126) |
| Strategy | Support requests answered (helper made contact too) | 38% (3 of 8) | 60% (3 of 5) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 50% (1 of 2) | - |
| Strategy | Hexes on a unit its side charged or shot that turn | 60% (9 of 15) | 36% (4 of 11) |
| Strategy | Joined characters whose unit fought | 32% (14 of 44) | 45% (14 of 31) |
| Strategy | Lone characters that fought | 79% (79 of 100) | 75% (58 of 77) |
| Movement | Charges halted short of contact | 0.1 | 0.1 |
| Movement | Idle units | 1.1 | 1.9 |
| Movement | Points that never moved of their own | 193.8 | 181.9 |
| Movement | Fights charged into per game | 2.7 | 2.9 |
| Movement | Charges with odds: long shots (under 50%) | 22 of 88, net +10 | 19 of 96, net +85 |
| Movement | Charges with odds: sweet spot (55-75%) | 12 of 88, net +133 | 14 of 96, net +136 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 8 of 88, net +62 | 8 of 96, net +59 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 21 of 88, net +99 | 26 of 96, net +123 |
| Shooting | Shots by shooting units (incl. breath weapons) | 10.7 | 9.5 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 52% (200 of 384) | 44% (152 of 343) |
| Shooting | Points destroyed by shooting units | 76.9 | 35.2 |
| Shooting | War machine shots | 5.9 | 0.9 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 50% (105 of 212) | 36% (12 of 33) |
| Shooting | Points destroyed by war machines | 82.3 | 32.9 |
| Magic | Magic missiles cast | 1.8 | 0.8 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 36% (23 of 64) | 21% (6 of 29) |
| Magic | Wounds caused by magic missiles | 3.7 | 2.1 |
| Magic | Wounds caused by other spells | 1.4 | 1.2 |
| Magic | Points destroyed by magic (all spells) | 86.9 | 22.9 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.8 / 0.4 / 0.9 / 0.1 | 1.2 / 0.4 / 0.4 / 0.2 |
| Combat | Points destroyed in combat | 282.7 | 367.6 |
| Combat | Points run down | 66.8 | 48.6 |
| Combat | Net points per charged fight, damage counted | +59 | +90 |
| Combat | Net per 100 charger points, damage counted | +22.0 | +30.1 |
| Combat | First round won (charged fights) | 60% | 63% |
| Combat | Net points per charged fight | +61 | +87 |
| Combat | Net points per supported fight / lone fight | +222 / +47 | -19 / +93 |
| Combat | Charged fights on a top-3 enemy unit | 32 of 97 | 48 of 106 |
| Game | Points lost | 614.2 | 626.5 |
| Game | VP from objectives | 612.8 | 659.2 |
| Game | Lone holders (player turns) | 2.6 | 3.7 |

- Mine won / drew / lost: 12 / 9 / 15 of 36 ended games (of 36); mean margin (Mine - Opponent) -47 VP
- The side that went first won 17 of 27 games with a winner
- Points traded per game (both sides' losses): 1241
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: h3-opp-efe7e34-p3

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.6 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 2.9 |
| AFTERMATH IN POINTS | 0.3 | +75.4 | 0.0 | 32.6 | 0.2 | +16.3 | 0.0 | 4.0 |
| ALREADY CARRIED | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARRIVAL HUNT | - | - | - | - | 0.1 | +1.4 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.4 | +0.0 | 0.0 | 11.7 | 0.1 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | 0.3 | +0.9 | 0.0 | 3.5 | 0.4 | +2.8 | 0.0 | 13.9 |
| BEST PRIZE | 0.1 | -2.0 | 4.2 | 0.0 | 0.0 | -0.6 | 1.1 | 0.0 |
| BLOWS WHERE AIMED | 0.2 | -0.8 | 7.6 | 13.5 | 0.1 | -21.8 | 9.6 | 0.0 |
| BOMBING RUN | 0.0 | +0.4 | 1.7 | 0.0 | 0.0 | +0.8 | 2.4 | 0.0 |
| CANNON PLAN MISSED | 0.9 | +0.0 | 47.9 | 4.6 | 0.1 | +0.0 | 10.6 | 0.0 |
| CANNON PLANNED TARGET | 5.1 | +134.6 | 369.0 | 67.1 | 0.9 | +39.5 | 77.9 | 11.9 |
| CANNON SIGHT KEPT | 1.1 | +0.0 | 0.0 | 3.5 | 0.3 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT COUNTER | 0.1 | -7.3 | 3.0 | 0.0 | - | - | - | - |
| CARRIES OUT SET-UP | 0.1 | -1.2 | 18.6 | 0.0 | 0.0 | +0.0 | 6.6 | 0.0 |
| CAST JOB | 0.8 | +13.1 | 55.0 | 19.2 | 0.3 | +9.7 | 31.7 | 3.2 |
| CASTER AWAY FROM SCREEN | 0.2 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.2 | +14.5 | 1.1 | 0.0 | 0.1 | +0.7 | 1.8 | 0.0 |
| CASTS AFTER FRIENDS | 0.5 | +0.0 | 0.0 | 21.1 | 0.4 | +0.0 | 0.0 | 11.1 |
| CASTS FROM BEHIND | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | - | - | - | - | 0.0 | +3.3 | 0.0 | 0.0 |
| CATCH ODDS | 0.0 | +4.8 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | 0.3 | +16.0 | 0.0 | 6.5 | 0.8 | +24.8 | 0.0 | 12.9 |
| CHAFF PASSED | 0.3 | -1.2 | 0.0 | 3.4 | 0.2 | -0.2 | 7.3 | 1.6 |
| CHARACTER GUNS | 0.1 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 22.8 |
| CHARGE LOSSES | 6.0 | -327.1 | 0.0 | 166.3 | 5.4 | -304.8 | 0.0 | 202.0 |
| CHARGE NOT DECLARED | 0.3 | +0.0 | 8.8 | 8.0 | 0.6 | +0.0 | 58.6 | 12.0 |
| CHARGE NOW FIRST | 1.7 | +0.0 | 239.5 | 24.6 | 1.7 | +0.0 | 189.3 | 30.1 |
| CHARGER SLAIN LOST | 0.6 | -19.5 | 27.0 | 20.7 | 0.2 | -8.1 | 12.6 | 0.8 |
| CHEAP HELPER | 0.1 | +0.0 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 2.7 |
| CHEAPEST HOLDER | 0.2 | -12.0 | 10.5 | 0.0 | - | - | - | - |
| COMBAT PIVOT | 0.6 | +0.0 | 7.3 | 40.6 | 0.3 | +0.0 | 4.0 | 34.7 |
| CONTINUE AHEAD WEIGHED | - | - | - | - | 0.0 | +0.0 | 1.4 | 0.0 |
| CONVEYANCE SEARCH | 0.6 | +134.3 | 21.1 | 21.1 | 0.1 | +26.4 | 11.1 | 11.1 |
| COVER ONCE | 7.6 | -520.7 | 0.0 | 178.6 | 5.0 | -436.5 | 0.0 | 123.5 |
| DEFENSIVE ARMY | 0.1 | +0.0 | 0.0 | 2.7 | 0.0 | +0.0 | 0.0 | 6.6 |
| DEFENSIVE FLOOR | 0.1 | -1.6 | 0.0 | 7.3 | - | - | - | - |
| DEPLOY BY FIGURES | 7.6 | +22.3 | 0.0 | 20.6 | 7.9 | +50.3 | 0.0 | 12.5 |
| EDGE GIVE GROUND | 0.1 | +1.7 | 12.8 | 0.0 | 0.1 | +0.6 | 8.5 | 0.0 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 0.0 | +2.7 | 0.0 | 0.0 | 0.0 | +10.7 | 0.0 | 0.0 |
| FALL BACK GOOD ORDER | 2.3 | +3.4 | 217.5 | 36.5 | 2.7 | +7.2 | 236.2 | 45.5 |
| FALLBACK BY WORTH | 0.2 | +0.3 | 0.0 | 1.1 | 0.3 | +0.2 | 0.0 | 0.9 |
| FALLS SHORT | 6.6 | +103.4 | 0.0 | 132.8 | 16.0 | +229.8 | 0.0 | 226.7 |
| FEATURE BUFFS | 1.0 | +23.7 | 0.0 | 6.4 | 0.8 | +13.5 | 0.0 | 0.0 |
| FIGHT LIFT | 0.0 | +1.0 | 0.0 | 0.0 | - | - | - | - |
| FIGHT TO THE END | 1.3 | +90.6 | 161.9 | 34.8 | 1.1 | +115.7 | 124.5 | 12.0 |
| FIRE IN ORDER | 0.2 | +0.0 | 3.8 | 5.6 | 0.2 | +0.0 | 2.1 | 0.0 |
| FIVE ACTION | 44.9 | +2795.5 | 1010.0 | 599.4 | 44.4 | +3111.1 | 476.0 | 657.1 |
| FLANK NOT WEIGHED | 6.2 | +0.0 | 0.0 | 138.5 | 6.1 | +0.0 | 0.0 | 127.8 |
| FOCUS FIRE | 0.1 | +2.0 | 3.1 | 0.0 | 0.1 | +1.9 | 3.1 | 0.0 |
| FOLLOW UP WEIGHED | 0.7 | +114.0 | 0.0 | 2.3 | 1.1 | +262.9 | 0.0 | 54.4 |
| FOUR ROUNDS | 3.2 | +466.2 | 292.7 | 50.8 | 3.2 | +504.8 | 283.1 | 46.3 |
| FRIEND CHARGES FIRST | 0.2 | -35.5 | 0.0 | 0.0 | 0.1 | -7.7 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 0.4 | -20.0 | 16.6 | 16.9 | 0.2 | -7.2 | 0.0 | 19.5 |
| FRIENDS SHOTS CHECKED | 0.1 | +9.1 | 0.0 | 3.4 | 0.0 | +4.0 | 0.0 | 0.0 |
| GIVES UP | 0.2 | -3.7 | 15.3 | 6.4 | 0.3 | -5.3 | 29.4 | 12.0 |
| GIVES UP ITS SCREEN | 0.0 | -0.3 | 0.0 | 0.0 | 0.0 | -0.3 | 0.0 | 0.0 |
| GROUND FLIERS | 0.1 | +2.0 | 0.0 | 0.0 | - | - | - | - |
| GUN FIGURES | 0.8 | +11.1 | 39.2 | 15.6 | 0.5 | +13.8 | 11.8 | 3.6 |
| GUN MASK | 0.9 | +23.3 | 0.0 | 0.0 | 0.4 | +8.7 | 0.0 | 6.5 |
| HARD STAY DROPPED | 1.6 | +0.0 | 0.0 | 7.2 | 0.9 | +0.0 | 0.0 | 1.7 |
| HE SHOOTS OR CHARGES | 2.4 | +0.0 | 0.0 | 50.1 | 2.7 | +0.0 | 0.0 | 64.0 |
| HELPER ALREADY ASKED | - | - | - | - | 0.0 | +0.0 | 6.6 | 0.0 |
| HELPER UNSEEN | 0.0 | +0.0 | 3.1 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE DENIED | 0.4 | +10.2 | 22.6 | 13.7 | 0.5 | +22.5 | 42.6 | 15.8 |
| HIS CHARGE LIST | 2.5 | +0.0 | 0.0 | 55.2 | 3.8 | +0.0 | 0.0 | 62.6 |
| HIS LEGAL MOVES | 4.4 | +0.0 | 0.0 | 40.6 | 3.3 | +0.0 | 0.0 | 81.2 |
| HIS MOVE AND SHOT | 2.2 | -35.8 | 0.0 | 38.3 | 2.4 | -44.2 | 0.0 | 87.8 |
| HIS RANDOM MOVE | 3.7 | +0.0 | 0.0 | 45.2 | 1.5 | +0.0 | 0.0 | 14.5 |
| HIS SHOT LIST | 18.7 | +588.1 | 0.0 | 265.5 | 24.7 | +1300.3 | 0.0 | 372.2 |
| HIS TURN DENIED | 1.2 | +32.4 | 128.4 | 9.6 | 1.6 | +81.2 | 142.0 | 28.8 |
| HOLD ODDS | - | - | - | - | 6.6 | +0.0 | 0.0 | 79.0 |
| HOLDER ASSIGNMENT | - | - | - | - | 12.8 | +1268.1 | 0.0 | 130.2 |
| HOLDER AT DEPLOYMENT | 1.0 | +172.8 | 0.0 | 0.0 | - | - | - | - |
| HOLDS AMBUSHERS | 0.5 | +0.0 | 0.0 | 0.0 | 0.5 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 2.5 | -84.6 | 260.9 | 9.0 | 2.9 | -124.6 | 258.0 | 44.5 |
| HORN WORTH | - | - | - | - | 0.0 | +0.6 | 0.0 | 0.0 |
| HUNT IN PAIRS | 0.3 | +9.4 | 0.0 | 2.5 | 0.8 | +29.5 | 0.0 | 10.8 |
| HUNT RESULT | - | - | - | - | 0.0 | +7.2 | 3.5 | 0.0 |
| HUNT THE GUNS | - | - | - | - | 0.0 | +9.0 | 3.5 | 0.0 |
| IDLE COST | 3.3 | -56.8 | 0.0 | 52.3 | 10.3 | -166.6 | 0.0 | 135.9 |
| JOINT KNOWS CHALLENGE | 0.0 | -0.8 | 0.0 | 0.0 | 0.1 | -3.6 | 29.8 | 0.0 |
| KEEP FALLS | 0.1 | +2.5 | 0.0 | 5.2 | - | - | - | - |
| KEEPS SCOUTS OR AMBUSH | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KILLS COUNT | - | - | - | - | 0.1 | +11.2 | 11.2 | 0.0 |
| LANE BY FIGURES | 0.8 | +30.7 | 0.0 | 0.0 | 1.0 | +51.3 | 0.0 | 13.1 |
| LEGAL CHARGES ONLY | 6.6 | +0.0 | 312.6 | 248.7 | 6.7 | +0.0 | 233.9 | 317.1 |
| LONE CHARACTER SAFE SPOT | 0.1 | +0.6 | 0.0 | 1.2 | 0.0 | +5.0 | 0.0 | 0.0 |
| LONE WIZARD KEPT IN | 0.6 | +34.3 | 0.0 | 2.6 | 0.2 | +22.4 | 0.0 | 0.0 |
| LONG SHOT | 0.3 | +0.6 | 0.0 | 15.3 | 0.2 | +1.7 | 4.4 | 0.0 |
| LOST CHARGE | 0.1 | -0.3 | 0.0 | 13.7 | - | - | - | - |
| LURE BY WHAT IT DRAWS | 0.1 | -19.2 | 0.0 | 1.1 | 0.0 | -0.5 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 0.1 | +0.8 | 0.0 | 1.9 | 0.2 | +9.9 | 0.0 | 7.4 |
| MANOEUVRE | 1.2 | +16.1 | 0.0 | 22.3 | 1.4 | +23.6 | 0.0 | 21.8 |
| MARCH AT ESCAPER | 0.1 | +0.8 | 0.0 | 0.0 | 0.1 | +1.3 | 0.0 | 0.0 |
| MARCH BY THE SUM | 0.6 | +43.4 | 0.0 | 10.5 | 0.2 | +11.7 | 0.0 | 0.0 |
| MARCH CHECK | 1.2 | +60.7 | 0.0 | 23.9 | 1.0 | +57.4 | 0.0 | 8.8 |
| MARCH OVER CASTS | 0.8 | +52.8 | 0.0 | 4.8 | 0.8 | +97.2 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 6.9 | +120.8 | 0.0 | 95.5 | 7.9 | +112.1 | 0.0 | 132.7 |
| MISSILES IN THE MOVE | 4.3 | +122.8 | 0.0 | 88.9 | 3.1 | +52.5 | 0.0 | 55.2 |
| MISSILES NEXT TURN | 5.5 | +92.5 | 0.0 | 111.4 | 4.0 | +37.2 | 0.0 | 66.3 |
| MODEL FACING | 0.2 | +58.8 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL IN RANGE | 0.2 | +4.8 | 0.0 | 21.1 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.5 | -45.5 | 23.7 | 21.1 | 0.2 | -7.0 | 7.6 | 0.0 |
| MOVE SPELL SPOT | 0.2 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 11.1 |
| MOVE TO CHARGE COMPUTED | 4.4 | +568.5 | 0.0 | 77.8 | 4.0 | +935.1 | 0.0 | 58.2 |
| MOVES UNITS SPELL | 0.1 | +3.4 | 0.0 | 0.0 | 0.1 | +0.4 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 5.3 | +249.4 | 0.0 | 61.0 | 3.5 | +147.6 | 0.0 | 57.7 |
| NEEDED THERE | 0.0 | +3.4 | 3.3 | 0.0 | 0.1 | +58.8 | 11.2 | 0.0 |
| NEXT CHARGE BY LIST | 5.8 | -228.5 | 23.5 | 120.0 | 5.4 | -318.3 | 6.8 | 101.7 |
| NEXT OBJECTIVE NEARER | 7.5 | -344.3 | 62.5 | 71.0 | 6.2 | -200.4 | 17.6 | 88.4 |
| NO DOUBLE ROUNDS | 2.6 | -137.6 | 239.8 | 40.3 | 2.6 | -155.7 | 230.6 | 44.5 |
| NO RALLY LEFT | - | - | - | - | 0.1 | +5.9 | 0.0 | 0.0 |
| NOT TURNED | 0.3 | +4.4 | 0.0 | 5.1 | 0.2 | +0.0 | 0.0 | 4.0 |
| NOT WORTH A CAST | 0.3 | -0.2 | 0.0 | 0.0 | 0.1 | -0.2 | 0.0 | 0.0 |
| OFF BEST | 0.3 | -6.7 | 0.0 | 9.5 | 0.3 | -3.5 | 0.0 | 0.0 |
| ONE CHARGE A CHARGER | 3.2 | +0.0 | 0.0 | 82.1 | 3.6 | +0.0 | 0.0 | 94.5 |
| ONE FIGHT FORMULA | 5.9 | -116.5 | 0.0 | 96.4 | 5.8 | -169.1 | 0.0 | 153.0 |
| ONE OBJECTIVE FORMULA | 3.3 | -57.9 | 0.0 | 47.9 | 4.4 | -26.2 | 0.0 | 44.4 |
| ONE TARGET A SHOOTER | 15.2 | +307.0 | 0.0 | 257.4 | 19.9 | +594.9 | 0.0 | 289.9 |
| OPENS A LANE | 0.3 | +0.9 | 40.8 | 5.4 | 0.2 | +0.7 | 31.7 | 0.0 |
| OPENS UP | 0.1 | +9.2 | 8.2 | 0.0 | 0.2 | +12.8 | 7.8 | 0.0 |
| OVERRUNS AWAY | 0.3 | +18.8 | 14.9 | 0.0 | 0.5 | +22.4 | 30.5 | 2.9 |
| PATHS CROSS | 3.9 | +139.1 | 0.0 | 19.2 | 4.5 | +206.6 | 0.0 | 56.0 |
| PERIAPT WORTH | 0.0 | +2.8 | 0.0 | 15.0 | 0.1 | +4.3 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | - | - | - | - | 0.0 | -1.0 | 0.0 | 0.0 |
| PLAN RESULT | 40.1 | +1026.8 | 474.8 | 861.3 | 39.8 | +418.8 | 282.6 | 886.5 |
| PURSUES BIG PREY | 0.0 | -0.5 | 0.0 | 0.0 | - | - | - | - |
| RANDOM MOVE BY FIGURES | 0.5 | +7.5 | 0.0 | 20.0 | 2.1 | +33.1 | 0.0 | 85.1 |
| REDIRECT BY WHAT IT STOPS | 0.2 | -4.2 | 0.0 | 3.6 | 0.6 | -27.9 | 0.0 | 10.1 |
| REDIRECT COUNTER | 2.4 | +130.2 | 0.0 | 37.8 | 4.8 | +330.8 | 0.0 | 71.2 |
| REDIRECT WEIGHED | 0.2 | -1.5 | 3.7 | 0.0 | 0.1 | +1.6 | 9.6 | 15.0 |
| REFORMS TO MEET IT | 1.1 | -53.3 | 0.0 | 38.3 | 0.9 | -41.8 | 0.0 | 5.1 |
| REFUSING RETIRES | 0.2 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | 0.5 | +16.3 | 0.0 | 3.4 | 0.8 | +35.0 | 0.0 | 8.9 |
| RESTRAINS TO SHOOT | 0.1 | +1.6 | 0.0 | 0.0 | 0.0 | +0.6 | 0.0 | 0.0 |
| RISK BY ARC | 2.3 | +60.1 | 196.1 | 44.4 | 2.4 | +5.2 | 212.9 | 34.3 |
| RISK BY HIS FIGURE | 14.2 | -287.7 | 0.0 | 284.8 | 14.8 | -212.2 | 0.0 | 300.3 |
| RUN DOWN | 2.1 | -19.3 | 169.7 | 26.6 | 2.3 | -28.5 | 175.7 | 43.7 |
| SAME CHARGE LATER | 0.2 | -2.9 | 9.4 | 0.0 | 0.2 | -2.2 | 2.4 | 3.2 |
| SCOUT SPOT | 0.3 | +0.8 | 0.0 | 0.0 | 0.2 | +1.1 | 0.0 | 0.0 |
| SCOUT WAITS | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.0 | -0.3 | 0.0 | 0.0 | 0.3 | -23.5 | 0.0 | 1.9 |
| SEARCH SPOT | 5.4 | +270.6 | 0.0 | 56.2 | 5.8 | +245.9 | 0.0 | 101.3 |
| SELF MOVE SPELL | 0.2 | +1.7 | 0.0 | 11.0 | 0.3 | +66.8 | 0.0 | 0.0 |
| SET UP TOGETHER | 0.4 | +2.3 | 0.0 | 9.8 | 0.2 | +9.9 | 0.0 | 7.4 |
| SET-UP ANY TARGET | 0.1 | +24.1 | 10.6 | 10.6 | - | - | - | - |
| SHOOTER COUNTED ONCE | - | - | - | - | 0.0 | -0.1 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.3 | +0.8 | 0.0 | 0.0 | 0.2 | +0.4 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.0 | +30.4 | 31.2 | 15.0 | 0.7 | +13.3 | 10.6 | 15.0 |
| SHORT GUN FORWARD | 0.1 | +0.0 | 0.0 | 3.8 | - | - | - | - |
| SHOT OR CHARGE | 0.5 | -17.4 | 25.2 | 7.8 | 0.1 | -2.5 | 10.9 | 0.0 |
| SHOT RISK POINTS | 9.1 | +6.2 | 0.0 | 146.6 | 12.9 | -39.2 | 0.0 | 330.8 |
| SHOTS IN THE MOVE | 15.6 | +576.2 | 0.0 | 249.9 | 10.5 | +309.7 | 0.0 | 159.0 |
| SPELL SETS UP CHARGE | 0.2 | +43.5 | 10.6 | 10.6 | 0.0 | +11.7 | 0.0 | 0.0 |
| SPELL WORTH | 1.6 | +30.5 | 54.1 | 54.1 | 1.4 | +33.8 | 77.5 | 78.0 |
| SPELLS IN THE FIGHT | 0.5 | +2.7 | 26.4 | 0.0 | 0.4 | -4.4 | 53.4 | 15.0 |
| STAND AND SHOOT | 0.3 | -3.4 | 15.2 | 7.3 | 0.5 | -5.6 | 12.0 | 2.9 |
| STANDS FOR A REASON | 0.1 | +0.0 | 0.0 | 20.6 | 0.4 | +0.0 | 0.0 | 36.8 |
| STANDS STILL | 16.8 | +0.0 | 702.7 | 223.3 | 11.2 | +0.0 | 186.3 | 168.9 |
| STAY WORTH | 17.3 | +27.7 | 475.8 | 186.5 | 9.9 | +98.2 | 103.7 | 140.6 |
| STOPS | - | - | - | - | 0.0 | +0.3 | 3.5 | 0.0 |
| STUCK PIVOT | - | - | - | - | 0.1 | +0.0 | 0.0 | 0.0 |
| SUPPORT NARROWED | 1.3 | +0.0 | 152.2 | 24.6 | 1.0 | +0.0 | 88.3 | 1.2 |
| SURE REACH TOGETHER | 0.5 | +4.0 | 0.0 | 1.9 | 0.3 | +2.8 | 0.0 | 8.3 |
| THE DEARER SUM KEEPS ITS PLAN | 4.3 | +0.0 | 0.0 | 34.6 | 4.4 | +0.0 | 0.0 | 57.0 |
| THE PROMISE ADDS | 0.1 | -6.6 | 2.2 | 0.0 | 0.2 | -14.1 | 16.5 | 3.2 |
| THE PROMISED MOVE | 0.2 | +0.0 | 0.0 | 0.0 | 1.8 | +0.0 | 0.0 | 30.0 |
| TIED UP BY THE SUM | 0.5 | +47.7 | 43.5 | 0.0 | 0.4 | +47.4 | 40.5 | 0.0 |
| TIME ON OUR SIDE | 25.5 | +381.1 | 15.1 | 263.0 | 14.4 | +176.6 | 4.1 | 116.6 |
| WAITS AGAIN | 1.5 | +0.0 | 0.0 | 30.9 | 1.2 | +0.0 | 0.0 | 12.5 |
| WAR ENGINE CHARGES | 0.0 | +1.6 | 0.0 | 0.0 | 0.0 | +9.0 | 0.0 | 0.0 |
| WAR ENGINE JOBS | 0.2 | +0.0 | 16.2 | 13.8 | 0.1 | +0.0 | 16.1 | 5.1 |
| WHO HITS BACK | 0.4 | +46.1 | 0.0 | 4.5 | 0.1 | +20.3 | 0.0 | 0.0 |
| WHOLE FIGHT | 0.4 | +12.2 | 59.4 | 7.8 | 0.2 | +17.9 | 26.0 | 0.8 |
| WHOLE FIGHT GAIN | 0.1 | +5.1 | 10.4 | 1.5 | 0.0 | +0.8 | 0.0 | 0.0 |
| WIDER SPREAD | 2.4 | +0.3 | 217.9 | 44.4 | 2.0 | -5.5 | 198.4 | 29.5 |
| WOUNDED STAYS OUT | 0.2 | +0.0 | 22.4 | 0.0 | - | - | - | - |
| WOUNDS ON THE RANKS | 0.9 | +22.7 | 0.0 | 4.6 | 1.2 | +47.4 | 0.0 | 22.2 |

### Rule changes: h3-opp-efe7e34-p3

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS SHOT LIST | 1562 | 1562 | 491 | 13.64 | +10554 | +21.5 |
| LEGAL CHARGES ONLY | 481 | 481 | 481 | 13.36 | +0 | +0.0 |
| HOLDER ASSIGNMENT | 460 | 460 | 432 | 12.00 | +25552 | +59.1 |
| SEARCH SPOT | 404 | 404 | 377 | 10.47 | +18594 | +49.3 |
| DEPLOY BY FIGURES | 558 | 558 | 327 | 9.08 | +4495 | +13.7 |
| ONE TARGET A SHOOTER | 1264 | 1264 | 324 | 9.00 | +3782 | +11.7 |
| FIVE ACTION | 3216 | 3212 | 316 | 8.78 | +15382 | +48.7 |
| PATHS CROSS | 303 | 303 | 303 | 8.42 | +12446 | +41.1 |
| TIME ON OUR SIDE | 1435 | 1269 | 292 | 8.11 | +673 | +2.3 |
| MOVE TO CHARGE COMPUTED | 300 | 300 | 197 | 5.47 | +22578 | +114.6 |
| FOUR ROUNDS | 233 | 230 | 133 | 3.69 | +14448 | +108.6 |
| MAX FOR POSITIONING | 532 | 524 | 131 | 3.64 | +587 | +4.5 |
| SHOT RISK POINTS | 792 | 792 | 117 | 3.25 | +3568 | +30.5 |
| HARD STAY DROPPED | 90 | 90 | 90 | 2.50 | +0 | +0.0 |
| COVER ONCE | 455 | 346 | 86 | 2.39 | +2170 | +25.2 |
| REDIRECT COUNTER | 261 | 232 | 71 | 1.97 | +4391 | +61.8 |
| LANE BY FIGURES | 66 | 66 | 66 | 1.83 | +2951 | +44.7 |
| SHOTS IN THE MOVE | 938 | 885 | 66 | 1.83 | +2411 | +36.5 |
| FOLLOW UP WEIGHED | 64 | 64 | 64 | 1.78 | +13567 | +212.0 |
| NEXT OBJECTIVE NEARER | 495 | 495 | 60 | 1.67 | +848 | +14.1 |
| MARCH CHECK | 79 | 79 | 56 | 1.56 | +1096 | +19.6 |
| IDLE COST | 491 | 408 | 55 | 1.53 | +561 | +10.2 |
| ARTILLERY RE-ROLL WEIGHED | 54 | 54 | 54 | 1.50 | +0 | +0.0 |
| FALLS SHORT | 813 | 726 | 54 | 1.50 | +317 | +5.9 |
| CANNON SIGHT KEPT | 49 | 49 | 49 | 1.36 | +0 | +0.0 |
| CANNON PLANNED TARGET | 215 | 215 | 48 | 1.33 | -469 | -9.8 |
| RESERVE FALL BACK | 47 | 47 | 47 | 1.31 | +1846 | +39.3 |
| RANDOM MOVE BY FIGURES | 96 | 96 | 46 | 1.28 | +1462 | +31.8 |
| RISK BY ARC | 170 | 167 | 46 | 1.28 | +1133 | +24.6 |
| MANOEUVRE | 93 | 93 | 45 | 1.25 | +1619 | +36.0 |
| SHOOTS FROM THE BEST SPOT | 60 | 60 | 45 | 1.25 | +474 | +10.5 |
| ADVANCE LANE KEPT | 43 | 43 | 43 | 1.19 | +0 | +0.0 |
| CHARGE LOSSES | 411 | 411 | 41 | 1.14 | +3405 | +83.1 |
| NEXT CHARGE BY LIST | 405 | 405 | 40 | 1.11 | +827 | +20.7 |
| RISK BY HIS FIGURE | 1044 | 1044 | 39 | 1.08 | +3341 | +85.7 |
| HOLDS AMBUSHERS | 35 | 35 | 35 | 0.97 | +0 | +0.0 |
| MISSILES IN THE MOVE | 267 | 222 | 34 | 0.94 | +874 | +25.7 |
| CHARGE NOW FIRST | 121 | 121 | 33 | 0.92 | -2210 | -67.0 |
| CHARGE NOT DECLARED | 32 | 32 | 32 | 0.89 | -7295 | -228.0 |
| COMBAT PIVOT | 31 | 31 | 31 | 0.86 | +0 | +0.0 |
| LONE WIZARD KEPT IN | 30 | 30 | 30 | 0.83 | +2041 | +68.0 |
| MARCH BY THE SUM | 30 | 30 | 30 | 0.83 | +1983 | +66.1 |
| TIED UP BY THE SUM | 33 | 33 | 27 | 0.75 | +713 | +26.4 |
| CHAFF IN THE MOVE | 40 | 39 | 26 | 0.72 | +62 | +2.4 |
| CAST JOB | 40 | 40 | 22 | 0.61 | +126 | +5.7 |
| OFF BEST | 22 | 22 | 22 | 0.61 | -367 | -16.7 |
| SCOUT WAITS | 22 | 22 | 22 | 0.61 | +0 | +0.0 |
| STAY WORTH | 977 | 938 | 22 | 0.61 | +223 | +10.1 |
| FIGHT TO THE END | 88 | 87 | 20 | 0.56 | +1343 | +67.2 |
| WHO HITS BACK | 20 | 20 | 20 | 0.56 | +1642 | +82.1 |
| AFTERMATH IN POINTS | 19 | 19 | 19 | 0.53 | +3300 | +173.7 |
| NEARER NOT NEEDED | 315 | 302 | 19 | 0.53 | +762 | +40.1 |
| CHAFF PASSED | 18 | 18 | 18 | 0.50 | -52 | -2.9 |
| HIS TURN DENIED | 98 | 96 | 18 | 0.50 | +710 | +39.5 |
| SHOOTERS IN TWO RANKS | 18 | 18 | 18 | 0.50 | +42 | +2.3 |
| HOLDER AT DEPLOYMENT | 37 | 37 | 17 | 0.47 | +806 | +47.4 |
| ONE OBJECTIVE FORMULA | 278 | 240 | 15 | 0.42 | +446 | +29.7 |
| SURE REACH TOGETHER | 29 | 29 | 15 | 0.42 | +49 | +3.3 |
| WOUNDS ON THE RANKS | 76 | 76 | 14 | 0.39 | +436 | +31.2 |
| FIRE IN ORDER | 13 | 13 | 13 | 0.36 | +0 | +0.0 |
| REDIRECT WEIGHED | 12 | 12 | 12 | 0.33 | +551 | +45.9 |
| SUPPORT NARROWED | 82 | 82 | 12 | 0.33 | -310 | -25.8 |
| CASTER AWAY FROM SCREEN | 10 | 10 | 10 | 0.28 | +0 | +0.0 |
| FEATURE BUFFS | 63 | 63 | 10 | 0.28 | +175 | +17.5 |
| CASTING BLOCK | 11 | 11 | 9 | 0.25 | +39 | +4.3 |
| OVERRUNS AWAY | 27 | 27 | 9 | 0.25 | +384 | +42.7 |
| WHOLE FIGHT | 22 | 21 | 9 | 0.25 | +215 | +23.9 |
| WIDER SPREAD | 156 | 155 | 9 | 0.25 | +52 | +5.7 |
| ONE FIGHT FORMULA | 419 | 233 | 8 | 0.22 | +41 | +5.2 |
| HIS CHARGE DENIED | 32 | 32 | 7 | 0.19 | +221 | +31.5 |
| MODEL FACING | 7 | 7 | 7 | 0.19 | +2117 | +302.4 |
| OPENS UP | 11 | 11 | 7 | 0.19 | +230 | +32.9 |
| FALLBACK BY WORTH | 20 | 20 | 6 | 0.17 | +19 | +3.2 |
| FRIENDS SHOTS CHECKED | 6 | 6 | 6 | 0.17 | +472 | +78.7 |
| HONEST WORTH | 194 | 191 | 6 | 0.17 | +32 | +5.4 |
| MOVES UNITS SPELL | 6 | 6 | 6 | 0.17 | +136 | +22.7 |
| NO DOUBLE ROUNDS | 184 | 182 | 6 | 0.17 | +119 | +19.8 |
| HIS MOVE AND SHOT | 167 | 167 | 5 | 0.14 | +28 | +5.5 |
| KEEP FALLS | 5 | 5 | 5 | 0.14 | +132 | +26.3 |
| NEEDED THERE | 5 | 5 | 5 | 0.14 | +0 | +0.0 |
| SHORT GUN FORWARD | 5 | 5 | 5 | 0.14 | +0 | +0.0 |
| BEST PRIZE | 4 | 4 | 4 | 0.11 | -294 | -73.5 |
| FALL BACK GOOD ORDER | 178 | 176 | 4 | 0.11 | +18 | +4.5 |
| FOCUS FIRE | 4 | 4 | 4 | 0.11 | +141 | +35.2 |
| GUN MASK | 47 | 47 | 4 | 0.11 | +105 | +26.2 |
| HUNT IN PAIRS | 41 | 24 | 4 | 0.11 | +45 | +11.3 |
| LONG SHOT | 18 | 18 | 4 | 0.11 | +20 | +5.0 |
| REFORMS TO MEET IT | 73 | 73 | 4 | 0.11 | +39 | +9.7 |
| REFUSING RETIRES | 18 | 18 | 4 | 0.11 | -2 | -0.4 |
| SPELLS IN THE FIGHT | 31 | 31 | 4 | 0.11 | +37 | +9.3 |
| STUCK PIVOT | 4 | 4 | 4 | 0.11 | +0 | +0.0 |
| BLOWS WHERE AIMED | 11 | 11 | 3 | 0.08 | +108 | +36.1 |
| CASTS FROM BEHIND | 3 | 3 | 3 | 0.08 | +0 | +0.0 |
| KILLS COUNT | 3 | 3 | 3 | 0.08 | +0 | +0.0 |
| MISSILES NEXT TURN | 343 | 252 | 3 | 0.08 | +16 | +5.3 |
| PERIAPT WORTH | 3 | 3 | 3 | 0.08 | +253 | +84.3 |
| RESTRAINS TO SHOOT | 3 | 3 | 3 | 0.08 | +78 | +26.1 |
| WHOLE FIGHT GAIN | 6 | 6 | 3 | 0.08 | +36 | +11.9 |
| WOUNDED STAYS OUT | 7 | 7 | 3 | 0.08 | -369 | -123.0 |
| BACKUP TARGETS | 26 | 10 | 2 | 0.06 | +0 | +0.2 |
| BOMBING RUN | 2 | 2 | 2 | 0.06 | +41 | +20.5 |
| CARRIES OUT COUNTER | 2 | 2 | 2 | 0.06 | -262 | -131.1 |
| CHARGER SLAIN LOST | 29 | 29 | 2 | 0.06 | +23 | +11.6 |
| FACES THE THREAT | 2 | 2 | 2 | 0.06 | +483 | +241.4 |
| NO RALLY LEFT | 2 | 2 | 2 | 0.06 | +132 | +66.0 |
| OPENS A LANE | 17 | 12 | 2 | 0.06 | +0 | +0.0 |
| CARRIES OUT SET-UP | 4 | 4 | 1 | 0.03 | -43 | -43.2 |
| CATCH ODDS | 1 | 1 | 1 | 0.03 | -118 | -117.8 |
| CONTINUE AHEAD WEIGHED | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| HORN WORTH | 1 | 1 | 1 | 0.03 | +23 | +22.6 |
| KEEPS SCOUTS OR AMBUSH | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| PIVOT GUARDS FLANK | 1 | 1 | 1 | 0.03 | -38 | -37.7 |
| PURSUES BIG PREY | 1 | 1 | 1 | 0.03 | -16 | -16.3 |
| SAME CHARGE LATER | 16 | 16 | 1 | 0.03 | +0 | +0.0 |
| SET UP TOGETHER | 22 | 12 | 1 | 0.03 | +15 | +15.1 |
| ALREADY CARRIED | 3 | not checked | - | - | - | - |
| ARRIVAL HUNT | 3 | 3 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 34 | 34 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 31 | trace | - | - | - | - |
| CATCH FLIERS | 1 | not checked | - | - | - | - |
| CHARACTER GUNS | 24 | 24 | 0 | 0.00 | - | - |
| CHEAP HELPER | 3 | not checked | - | - | - | - |
| CHEAPEST HOLDER | 8 | 8 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 28 | not checked | - | - | - | - |
| DEFENSIVE ARMY | 4 | 4 | 0 | 0.00 | - | - |
| DEFENSIVE FLOOR | 3 | 3 | 0 | 0.00 | - | - |
| EDGE GIVE GROUND | 5 | 4 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT LIFT | 1 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 442 | not checked | - | - | - | - |
| FRIEND CHARGES FIRST | 10 | 10 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 22 | 22 | 0 | 0.00 | - | - |
| GIVES UP | 19 | 19 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 2 | 2 | 0 | 0.00 | - | - |
| GROUND FLIERS | 3 | not checked | - | - | - | - |
| GUN FIGURES | 45 | not checked | - | - | - | - |
| HE SHOOTS OR CHARGES | 183 | 183 | 0 | 0.00 | - | - |
| HELPER ALREADY ASKED | 1 | not checked | - | - | - | - |
| HELPER UNSEEN | 3 | 3 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 227 | 227 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 277 | 277 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 188 | 188 | 0 | 0.00 | - | - |
| HOLD ODDS | 239 | 239 | 0 | 0.00 | - | - |
| HUNT RESULT | 1 | trace | - | - | - | - |
| HUNT THE GUNS | 1 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 6 | 6 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 6 | not checked | - | - | - | - |
| LOST CHARGE | 2 | 2 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 4 | 4 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 12 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 6 | trace | - | - | - | - |
| MARCH OVER CASTS | 58 | 58 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 7 | 1 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 27 | trace | - | - | - | - |
| MOVE SPELL SPOT | 15 | not checked | - | - | - | - |
| NOT TURNED | 20 | 20 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 15 | not checked | - | - | - | - |
| ONE CHARGE A CHARGER | 244 | 244 | 0 | 0.00 | - | - |
| PLAN RESULT | 2873 | trace | - | - | - | - |
| REDIRECT BY WHAT IT STOPS | 29 | 29 | 0 | 0.00 | - | - |
| RUN DOWN | 157 | 154 | 0 | 0.00 | - | - |
| SCOUT SPOT | 20 | 20 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 11 | 11 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 21 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 5 | not checked | - | - | - | - |
| SHOOTER COUNTED ONCE | 1 | 1 | 0 | 0.00 | - | - |
| SHOT OR CHARGE | 24 | 24 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 8 | not checked | - | - | - | - |
| SPELL WORTH | 108 | not checked | - | - | - | - |
| STAND AND SHOOT | 30 | 30 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 19 | 19 | 0 | 0.00 | - | - |
| STANDS STILL | 1010 | 1010 | 0 | 0.00 | - | - |
| STOPS | 1 | 1 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 315 | not checked | - | - | - | - |
| THE PROMISE ADDS | 11 | 11 | 0 | 0.00 | - | - |
| THE PROMISED MOVE | 72 | not checked | - | - | - | - |
| WAITS AGAIN | 100 | 100 | 0 | 0.00 | - | - |
| WAR ENGINE CHARGES | 2 | 2 | 0 | 0.00 | - | - |
| WAR ENGINE JOBS | 12 | 12 | 0 | 0.00 | - | - |

### Off best figure: h3-opp-efe7e34-p3

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| PATHS CROSS | rule | 0.86 | 0.58 | 29.0 |
| HOLDER ASSIGNMENT | rule | - | 1.14 | 21.3 |
| CHARGE NOT DECLARED | rule | 0.33 | 0.56 | 228.0 |
| CHARGE NOW FIRST | rule | 0.58 | 0.31 | 69.0 |
| SUPPORT NARROWED | rule | 0.14 | 0.19 | 25.8 |
| JOB FIRST | gate | 0.14 | 0.14 | 24.8 |
| CANNON PLANNED TARGET | rule | 0.11 | 0.11 | 72.8 |
| CHAFF PASSED | rule | 0.11 | 0.11 | 6.5 |
| DEPLOY BY FIGURES | rule | 0.08 | 0.06 | 6.6 |
| BEST PRIZE | rule | 0.08 | 0.03 | 73.5 |
| AFTERMATH BAND | gate | 0.06 | 0.03 | 2.7 |
| LONE CHARACTER SAFE SPOT | gate | 0.08 | - | 4.4 |
| WOUNDED STAYS OUT | rule | 0.08 | - | 123.0 |
| CARRIES OUT COUNTER | rule | 0.06 | - | 131.1 |
| FIGHT ORDER BAND | gate | 0.03 | 0.03 | 2.5 |
| NO REASON | gate | - | 0.06 | 19.5 |
| REFUSING RETIRES | rule | 0.06 | - | 0.6 |
| AFTERMATH NEEDS NEXT CHARGE | gate | - | 0.03 | 51.9 |
| CARRIES OUT SET-UP | rule | 0.03 | - | 43.2 |
| CATCH ODDS | rule | 0.03 | - | 117.8 |
| PIVOT GUARDS FLANK | rule | - | 0.03 | 37.7 |
| PURSUES BIG PREY | rule | 0.03 | - | 16.3 |
| REDIRECT WEIGHED | rule | 0.03 | - | 244.9 |
| RULE SWITCHED OFF | gate | 0.03 | - | 1.7 |

### Plans: h3-opp-efe7e34-p3

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 2.5 | 64% | 486 | 241 | 49% |
| Mine | join | 0.6 | 87% | 27 | 0 | 0% |
| Mine | move | 27.5 | 94% | 1642 | 0 | 0% |
| Mine | shoot | 9.1 | 65% | 450 | 786 | 175% |
| Mine | support | 0.3 | 90% | 0 | 0 | 0% |
| Opponent | charge | 2.5 | 62% | 623 | 260 | 42% |
| Opponent | join | 0.3 | 100% | 16 | 0 | 0% |
| Opponent | move | 33.4 | 94% | 2115 | 0 | 0% |
| Opponent | shoot | 2.7 | 59% | 114 | 159 | 139% |
| Opponent | support | 0.8 | 82% | 0 | 0 | 0% |

### Packages: hunt the guns, h3-opp-efe7e34-p3

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 40 |
| Opponent | 0.0 | 1 | 0 | 100% | 100% | 0% | 2.0 | 325 | 258 | 100% | 100 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 27 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 135 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 159 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 19 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 138 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 151 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 140 |
| Tomb Kings of Khemri | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 18 |
| Vampire Counts | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Warriors of Chaos | 0.1 | 1 | 0 | 100% | 100% | 0% | 2.0 | 325 | 258 | 100% | 84 |
| Wood Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 112 |

### Battle groups: h3-opp-efe7e34-p3

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 2.4 | 23% | 85% | 25% | 0% | 40% | 0% | 0% | 53% | 7% |
| Opponent | REDIRECT COUNTER | 4.8 | 25% | 80% | 11% | 0% | 21% | 0% | 10% | 69% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: h3-opp-efe7e34-p3

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 4 | 0 (4) | 0 | 0 | 100 | 75% | 5.0 | - | 0 (1) | - | 0 (1) | - |
| Mine | Chaff | 34 | 48 (34) | 16 | 32 | 47 | 26% | 2.5 | 72 (15) | 17 (10) | 54 (9) | 52 (32) | 0 (2) |
| Mine | Character | 125 | 41 (125) | 41 | 0 | 32 | 18% | 2.6 | 54 (42) | 28 (57) | 67 (15) | 44 (75) | 47 (39) |
| Mine | Clean-up | 22 | 63 (22) | 7 | 56 | 27 | 50% | 3.1 | 57 (8) | 68 (10) | 66 (4) | 77 (14) | 44 (8) |
| Mine | Fast | 1 | 240 (1) | 240 | 0 | 0 | 0% | 2.0 | 240 (1) | - | - | 240 (1) | - |
| Mine | Fast Hammer | 42 | 60 (42) | 37 | 23 | 39 | 14% | 2.9 | 37 (8) | 79 (24) | 14 (10) | 65 (34) | 32 (8) |
| Mine | Fragile | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Mine | Hammer | 51 | 48 (51) | 22 | 25 | 38 | 22% | 2.5 | 30 (14) | 58 (30) | 39 (7) | 52 (39) | 37 (12) |
| Mine | Holder | 33 | 67 (33) | 2 | 65 | 14 | 48% | 3.4 | 40 (7) | 84 (13) | 71 (13) | 113 (19) | 12 (14) |
| Mine | Shooter | 37 | 58 (37) | 15 | 43 | 37 | 8% | 1.7 | 26 (13) | 68 (21) | 144 (3) | 62 (21) | 52 (16) |
| Mine | Support | 2 | 0 (2) | 0 | 0 | 0 | 100% | - | 0 (1) | 0 (1) | - | - | 0 (2) |
| Mine | War machine | 57 | 51 (57) | 51 | 0 | 34 | 5% | 1.3 | 47 (19) | 34 (31) | 154 (7) | 52 (16) | 50 (41) |
| Mine | Wizard | 19 | 14 (19) | 14 | 0 | 35 | 21% | 2.2 | 0 (3) | 30 (9) | 0 (3) | 0 (6) | 38 (9) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Chaff | 82 | 49 (82) | 4 | 45 | 40 | 44% | 2.8 | 31 (30) | 80 (23) | 35 (29) | 54 (61) | 38 (21) |
| Opponent | Character | 93 | 43 (93) | 43 | 0 | 28 | 17% | 2.3 | 28 (22) | 46 (50) | 51 (19) | 41 (53) | 46 (38) |
| Opponent | Clean-up | 15 | 100 (15) | 1 | 98 | 16 | 40% | 3.2 | 42 (3) | 122 (10) | 0 (2) | 132 (11) | 38 (4) |
| Opponent | Early | 1 | 0 (1) | 0 | 0 | 0 | 0% | 6.0 | - | 0 (1) | - | 0 (1) | - |
| Opponent | Fast | 2 | 0 (2) | 0 | 0 | 50 | 50% | 3.0 | 0 (1) | 0 (1) | - | 0 (2) | - |
| Opponent | Fast Hammer | 51 | 51 (51) | 17 | 34 | 37 | 33% | 3.2 | 73 (12) | 29 (24) | 71 (15) | 53 (30) | 48 (21) |
| Opponent | Fragile | 5 | 64 (5) | 64 | 0 | 32 | 20% | 3.0 | 0 (1) | 71 (3) | 170 (1) | 123 (3) | 0 (2) |
| Opponent | Hammer | 61 | 41 (61) | 30 | 10 | 46 | 30% | 3.1 | 13 (11) | 55 (29) | 31 (21) | 36 (44) | 49 (17) |
| Opponent | Holder | 27 | 92 (27) | 4 | 88 | 22 | 52% | 3.1 | 125 (5) | 87 (16) | 84 (6) | 111 (14) | 72 (13) |
| Opponent | Shooter | 33 | 84 (33) | 7 | 77 | 50 | 9% | 1.7 | 47 (8) | 103 (21) | 74 (4) | 85 (18) | 83 (15) |
| Opponent | Support | 1 | 0 (1) | 0 | 0 | 100 | 0% | 4.0 | - | 0 (1) | - | - | 0 (1) |
| Opponent | War machine | 12 | 94 (12) | 94 | 0 | 24 | 8% | 2.0 | 48 (7) | 269 (3) | 68 (2) | - | 94 (12) |
| Opponent | Wizard | 15 | 4 (15) | 4 | 0 | 28 | 20% | 2.6 | 0 (1) | 1 (8) | 0 (2) | 1 (7) | 0 (4) |

### Charged fights: h3-opp-efe7e34-p3

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 48 | 48 | 1.8 | 1.0 | 27 | 63 | -36 | 4 of 7 | 2 of 7 | - | -36 |
| Mine | Chaos Dwarfs | 4 | 380 | 163 | 1.0 | 1.0 | 163 | 0 | +163 | 3 of 4 | 4 of 4 | - | +163 |
| Mine | Dwarfen Mountain Holds | 3 | 536 | 27 | 1.3 | 1.2 | 20 | 0 | +20 | 0 of 4 | 4 of 4 | +27 | +18 |
| Mine | Empire of Man | 5 | 167 | 69 | 1.4 | 1.1 | 49 | 6 | +43 | 1 of 7 | 5 of 7 | +110 | +32 |
| Mine | Grand Cathay | 5 | 748 | 274 | 3.6 | 1.1 | 76 | 34 | +42 | 5 of 18 | 9 of 18 | +304 | +9 |
| Mine | High Elf Realms | 3 | 136 | 112 | 3.0 | 1.0 | 37 | 0 | +37 | 4 of 9 | 6 of 9 | - | +37 |
| Mine | Kingdom of Bretonnia | 2 | 263 | 282 | 4.5 | 1.0 | 63 | 29 | +33 | 3 of 9 | 7 of 9 | - | +33 |
| Mine | Lizardmen | 1 | 30 | 139 | 2.0 | 1.0 | 70 | 0 | +70 | 0 of 2 | 2 of 2 | - | +70 |
| Mine | Ogre Kingdoms | 1 | 0 | 0 | 6.0 | 1.0 | 0 | 130 | -130 | 2 of 6 | 2 of 6 | - | -130 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 1236 | 6.0 | 1.2 | 206 | 44 | +162 | 0 of 6 | 4 of 6 | -55 | +205 |
| Mine | Skaven | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Mine | Tomb Kings of Khemri | 2 | 0 | 1172 | 5.5 | 1.1 | 213 | 0 | +213 | 7 of 11 | 7 of 11 | +373 | +197 |
| Mine | Vampire Counts | 2 | 0 | 680 | 5.0 | 1.2 | 136 | 27 | +109 | 1 of 10 | 3 of 10 | +356 | +47 |
| Mine | Warriors of Chaos | 2 | 0 | 54 | 2.0 | 1.0 | 27 | 29 | -2 | 2 of 4 | 3 of 4 | - | -2 |
| **Mine** | all armies | 36 | 246 | 242 | 2.7 | 1.1 | 90 | 29 | +61 | 32 of 97 | 58 of 97 | +222 | +47 |
| Opponent | Grand Cathay | 3 | 424 | 168 | 2.7 | 1.1 | 63 | 88 | -25 | 4 of 8 | 7 of 8 | -704 | +72 |
| Opponent | High Elf Realms | 3 | 217 | 207 | 1.3 | 1.0 | 155 | 0 | +155 | 3 of 4 | 2 of 4 | - | +155 |
| Opponent | Kingdom of Bretonnia | 2 | 68 | 252 | 2.5 | 1.0 | 101 | 0 | +101 | 0 of 5 | 4 of 5 | - | +101 |
| Opponent | Ogre Kingdoms | 2 | 141 | 356 | 3.5 | 1.0 | 102 | 10 | +92 | 3 of 7 | 3 of 7 | - | +92 |
| Opponent | Skaven | 2 | 30 | 100 | 0.5 | 1.0 | 199 | 0 | +199 | 0 of 1 | 1 of 1 | - | +199 |
| Opponent | Tomb Kings of Khemri | 2 | 84 | 750 | 5.0 | 1.0 | 150 | 123 | +27 | 6 of 10 | 9 of 10 | - | +27 |
| Opponent | Vampire Counts | 3 | 50 | 104 | 3.0 | 1.1 | 35 | 12 | +23 | 5 of 9 | 5 of 9 | +0 | +26 |
| Opponent | Warriors of Chaos | 11 | 0 | 379 | 3.1 | 1.0 | 123 | 14 | +108 | 12 of 34 | 21 of 34 | -98 | +115 |
| Opponent | Wood Elf Realms | 8 | 70 | 468 | 3.5 | 1.1 | 134 | 16 | +118 | 15 of 28 | 15 of 28 | +230 | +104 |
| **Opponent** | all armies | 36 | 91 | 341 | 2.9 | 1.1 | 116 | 29 | +87 | 48 of 106 | 67 of 106 | -19 | +93 |

### Effective charges: h3-opp-efe7e34-p3

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 7 | 5 (net -59) | 0 | 1 (net +41) | 0 | 0 | 1 (net +0) | 0 | 14% (1 of 7) |
| Mine | Chaos Dwarfs | 4 | 0 | 0 | 1 (net +482) | 2 (net +85) | 0 | 1 (net +0) | 0 | 25% (1 of 4) |
| Mine | Dwarfen Mountain Holds | 4 | 0 | 0 | 0 | 2 (net +0) | 0 | 2 (net +41) | 0 | 0% (0 of 4) |
| Mine | Empire of Man | 7 | 1 (net +0) | 0 | 0 | 4 (net +26) | 1 (net +60) | 1 (net +135) | 0 | 0% (0 of 7) |
| Mine | Grand Cathay | 18 | 2 (net -204) | 1 (net +0) | 3 (net +0) | 7 (net +96) | 3 (net +36) | 2 (net +192) | 0 | 17% (3 of 18) |
| Mine | High Elf Realms | 9 | 3 (net +0) | 0 | 1 (net +275) | 0 | 1 (net +0) | 4 (net +15) | 0 | 11% (1 of 9) |
| Mine | Kingdom of Bretonnia | 9 | 1 (net -264) | 0 | 0 | 3 (net +19) | 1 (net +209) | 3 (net +100) | 1 | 0% (0 of 8) |
| Mine | Lizardmen | 2 | 0 | 0 | 0 | 2 (net +70) | 0 | 0 | 0 | 0% (0 of 2) |
| Mine | Ogre Kingdoms | 6 | 2 (net -231) | 0 | 1 (net -40) | 0 | 0 | 1 (net +0) | 2 | 25% (1 of 4) |
| Mine | Orc & Goblin Tribes | 6 | 1 (net +505) | 0 | 1 (net -55) | 0 | 0 | 0 | 4 | 50% (1 of 2) |
| Mine | Tomb Kings of Khemri | 11 | 4 (net +237) | 0 | 3 (net +128) | 0 | 0 | 4 (net +253) | 0 | 27% (3 of 11) |
| Mine | Vampire Counts | 10 | 3 (net +69) | 0 | 1 (net +505) | 3 (net +37) | 2 (net +60) | 0 | 1 | 11% (1 of 9) |
| Mine | Warriors of Chaos | 4 | 0 | 0 | 0 | 1 (net +0) | 0 | 2 (net +54) | 1 | 0% (0 of 3) |
| Opponent | Grand Cathay | 8 | 1 (net +238) | 0 | 1 (net +0) | 2 (net +32) | 2 (net +101) | 2 (net -352) | 0 | 12% (1 of 8) |
| Opponent | High Elf Realms | 4 | 1 (net +310) | 0 | 1 (net +310) | 1 (net +0) | 1 (net +0) | 0 | 0 | 25% (1 of 4) |
| Opponent | Kingdom of Bretonnia | 5 | 0 | 1 (net +165) | 3 (net +113) | 1 (net +0) | 0 | 0 | 0 | 60% (3 of 5) |
| Opponent | Ogre Kingdoms | 7 | 4 (net +169) | 0 | 1 (net +0) | 0 | 0 | 1 (net +0) | 1 | 17% (1 of 6) |
| Opponent | Skaven | 1 | 0 | 0 | 1 (net +199) | 0 | 0 | 0 | 0 | 100% (1 of 1) |
| Opponent | Tomb Kings of Khemri | 10 | 2 (net +180) | 0 | 0 | 3 (net -295) | 0 | 5 (net +159) | 0 | 0% (0 of 10) |
| Opponent | Vampire Counts | 9 | 1 (net -45) | 0 | 2 (net +61) | 2 (net -30) | 1 (net +0) | 3 (net +63) | 0 | 22% (2 of 9) |
| Opponent | Warriors of Chaos | 34 | 4 (net +7) | 2 (net +30) | 4 (net +234) | 6 (net +138) | 3 (net +42) | 10 (net +190) | 5 | 14% (4 of 29) |
| Opponent | Wood Elf Realms | 28 | 6 (net +8) | 4 (net +231) | 1 (net +0) | 7 (net +112) | 1 (net +144) | 5 (net +203) | 4 | 4% (1 of 24) |

### Charged fights, damage counted: h3-opp-efe7e34-p3

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 22 | 201 | 315 | +10 | 110 | 105 | +5 | +2.6 |
| Mine | 50-54% | 1 | 369 | 432 | +0 | 0 | 0 | +0 | +0.0 |
| Mine | Effective (55-75%) | 12 | 327 | 235 | +133 | 154 | 42 | +112 | +34.3 |
| Mine | 76-89% | 24 | 282 | 127 | +52 | 96 | 41 | +55 | +19.4 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 21 | 269 | 188 | +99 | 132 | 20 | +113 | +41.9 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 8 | 411 | 90 | +62 | 96 | 23 | +72 | +17.6 |
| Mine | No odds | 9 | 191 | 205 | +30 | 102 | 97 | +5 | +2.5 |
| Mine | All fights | 97 | 269 | 203 | +61 | 114 | 54 | +59 | +22.0 |
| Opponent | Long shot (under 50%) | 19 | 170 | 244 | +85 | 134 | 50 | +84 | +49.5 |
| Opponent | 50-54% | 7 | 293 | 165 | +164 | 166 | 41 | +125 | +42.7 |
| Opponent | Effective (55-75%) | 14 | 264 | 222 | +136 | 154 | 11 | +144 | +54.3 |
| Opponent | 76-89% | 22 | 364 | 216 | +33 | 125 | 86 | +39 | +10.6 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 26 | 398 | 242 | +123 | 196 | 65 | +131 | +32.9 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 8 | 425 | 103 | +59 | 78 | 6 | +71 | +16.8 |
| Opponent | No odds | 10 | 106 | 263 | +17 | 77 | 52 | +25 | +23.6 |
| Opponent | All fights | 106 | 300 | 221 | +87 | 142 | 52 | +90 | +30.1 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| h3-opp-efe7e34-p3 | move | 300 | 69 (23%) | 54 (18%) | 37 (12%) | 194 (65%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0111, L0128, L2433, L2631 |
| Charmed Shield | Opponent | L0534, L0726, L1124, L1634, L2034, L2224, L2834, L3134 |
| Clockwork Compass | Mine | L1216, L1233 |
| Elixir of Power | Mine | L1124, L1933 |
| Elixir of Power | Opponent | L0111, L0211 |
| Fistful of Laurels | Mine | L1832 |
| Fistful of Laurels | Opponent | L0518, L1618 |
| Horn of the Wild Hunt | Opponent | L1233, L1933, L2433 |
| Invocation of Nehek | Mine | L2433 |
| Invocation of Nehek | Opponent | L1124, L2224 |
| Opal Amulet | Mine | L1423 |
| Periapt of Soul Exchange | Mine | L2034 |
| Periapt of Soul Exchange | Opponent | L0621, L1520 |
| Ring of Doom | Mine | L0211, L0228, L1124, L1216, L1233, L1520, L3134 |
| Ring of Doom | Opponent | L0111, L0211, L0415, L1015, L1233, L1933, L2433, L2631 |
| Ring of Jet | Mine | L1015, L1032, L1124, L1216, L1233 |
| Ring of Jet | Opponent | L0111, L0211, L0710 |
| Standard of the Fell Warrior | Mine | L1328 |
| Standard of the Fell Warrior | Opponent | L0313 |
| Storm Daemon (Renegade 2.0) | Opponent | L0621 |
| Twice-Blessed Armour | Mine | L0710, L0726, L1015, L1032 |
| Twice-Blessed Armour | Opponent | L0710 |
| Witch Hunter's Ward | Mine | L0710, L0726, L0816, L0832 |

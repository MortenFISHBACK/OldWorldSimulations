# Doctrine scorecard: h3-opp-efe7e34-p2

### Scorecard: h3-opp-efe7e34-p2

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0108 | 6 | 1 | Mine | yes | 1 | 3 | 1 | 2 | 0 | 0 | 0 | 0 |
| L0108 | 6 | 1 | Opponent | no | 1 | 3 | 1 | 2 | 0 | 0 | 0 | 0 |
| L0123 | 3 | 1 | Mine | yes | 1 | - | 0 | 1 | 0 | 0 | 0 | 0 |
| L0123 | 3 | 1 | Opponent | yes | 1 | 2 | 5 | 3 | 0 | 0 | 0 | 0 |
| L0207 | 3 | 1 | Mine | no | 1 | 3 | 2 | 4 | 0 | 0 | 0 | 170 |
| L0207 | 3 | 1 | Opponent | no | 10 | 3 | 1 | 1 | 0 | 0 | 0 | 45 |
| L0224 | 2 | 1 | Mine | - | - | 1 | 5 | 2 | 1 | 0 | 0 | 251 |
| L0224 | 2 | 1 | Opponent | - | - | 5 | 1 | 2 | 0 | 0 | 0 | 0 |
| L0308 | 2 | 1 | Mine | - | - | - | 0 | 2 | 0 | 0 | 0 | 0 |
| L0308 | 2 | 1 | Opponent | - | - | - | 0 | 3 | 0 | 0 | 0 | 45 |
| L0325 | 1 | 1 | Mine | no | 0 | 2 | 1 | 0 | 0 | 0 | 0 | 590 |
| L0325 | 1 | 1 | Opponent | no | 5 | 2 | 1 | 2 | 0 | 0 | 0 | 0 |
| L0411 | 3 | 1 | Mine | no | 3 | 2 | 3 | 2 | 1 | 0 | 0 | 0 |
| L0411 | 3 | 1 | Opponent | no | 14 | 4 | 4 | 0 | 0 | 0 | 0 | 330 |
| L0427 | 1 | 1 | Mine | no | 0 | 3 | 2 | 0 | 0 | 0 | 0 | 0 |
| L0427 | 1 | 1 | Opponent | no | 0 | 1 | 1 | 4 | 0 | 0 | 0 | 0 |
| L0513 | 3 | 1 | Mine | no | 8 | - | 0 | 2 | 0 | 0 | 0 | 276 |
| L0513 | 3 | 1 | Opponent | yes | 10 | 2 | 1 | 0 | 2 | 0 | 0 | 140 |
| L0530 | 2 | 1 | Mine | - | - | - | 2 | 0 | 0 | 0 | 0 | 285 |
| L0530 | 2 | 1 | Opponent | - | - | 2 | 2 | 3 | 1 | 0 | 0 | 0 |
| L0618 | 6 | 1 | Mine | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 455 |
| L0618 | 6 | 1 | Opponent | no | 0 | - | 4 | 1 | 1 | 0 | 0 | 0 |
| L0633 | 3 | 1 | Mine | no | 5 | - | 4 | 3 | 0 | 0 | 0 | 440 |
| L0633 | 3 | 1 | Opponent | no | 0 | 3 | 2 | 4 | 0 | 0 | 0 | 0 |
| L0722 | 2 | 1 | Mine | - | - | 2 | 3 | 2 | 0 | 0 | 0 | 484 |
| L0722 | 2 | 1 | Opponent | - | - | 2 | 2 | 1 | 1 | 0 | 0 | 72 |
| L0812 | 2 | 1 | Mine | - | - | 3 | 1 | 2 | 0 | 0 | 0 | 623 |
| L0812 | 2 | 1 | Opponent | - | - | 2 | 3 | 0 | 0 | 0 | 0 | 165 |
| L0828 | 6 | 1 | Mine | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 102 |
| L0828 | 6 | 1 | Opponent | no | 8 | 2 | 2 | 0 | 0 | 0 | 0 | 0 |
| L0919 | 1 | 1 | Mine | no | 0 | 3 | 0 | 1 | 0 | 0 | 0 | 0 |
| L0919 | 1 | 1 | Opponent | no | 0 | 3 | 2 | 4 | 1 | 0 | 0 | 0 |
| L1011 | 3 | 1 | Mine | yes | 12 | 2 | 1 | 0 | 0 | 0 | 0 | 0 |
| L1011 | 3 | 1 | Opponent | no | 4 | 2 | 2 | 0 | 0 | 0 | 0 | 165 |
| L1027 | 1 | 1 | Mine | no | 0 | 3 | 4 | 1 | 0 | 0 | 0 | 165 |
| L1027 | 1 | 1 | Opponent | no | 9 | 4 | 2 | 3 | 0 | 0 | 0 | 0 |
| L1119 | 3 | 1 | Mine | no | 4 | 3 | 2 | 0 | 0 | 0 | 0 | 0 |
| L1119 | 3 | 1 | Opponent | no | 7 | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L1213 | 1 | 1 | Mine | yes | 7 | 2 | 5 | 0 | 0 | 0 | 0 | 0 |
| L1213 | 1 | 1 | Opponent | yes | 15 | 5 | 0 | 0 | 1 | 0 | 0 | 232 |
| L1230 | 6 | 1 | Mine | no | 9 | 2 | 4 | 0 | 0 | 0 | 0 | 0 |
| L1230 | 6 | 1 | Opponent | no | 4 | 2 | 2 | 0 | 1 | 0 | 0 | 0 |
| L1323 | 3 | 1 | Mine | no | 0 | 2 | 1 | 2 | 1 | 0 | 0 | 0 |
| L1323 | 3 | 1 | Opponent | yes | 0 | 2 | 3 | 2 | 0 | 0 | 0 | 66 |
| L1419 | 3 | 1 | Mine | yes | 7 | 2 | 6 | 1 | 0 | 0 | 0 | 0 |
| L1419 | 3 | 1 | Opponent | no | 5 | 2 | 5 | 0 | 1 | 0 | 0 | 156 |
| L1516 | 4 | 1 | Mine | no | 3 | 1 | 3 | 1 | 1 | 0 | 0 | 0 |
| L1516 | 4 | 1 | Opponent | no | 3 | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L1532 | 2 | 1 | Mine | - | - | 1 | 3 | 0 | 0 | 0 | 0 | 0 |
| L1532 | 2 | 1 | Opponent | - | - | 3 | 6 | 4 | 0 | 0 | 0 | 0 |
| L1630 | 4 | 1 | Mine | no | 1 | 6 | 3 | 0 | 0 | 0 | 0 | 207 |
| L1630 | 4 | 1 | Opponent | no | 0 | 1 | 8 | 0 | 0 | 0 | 0 | 0 |
| L1729 | 1 | 1 | Mine | no | 10 | 2 | 3 | 0 | 0 | 0 | 0 | 0 |
| L1729 | 1 | 1 | Opponent | no | 8 | 2 | 5 | 2 | 1 | 0 | 0 | 0 |
| L1827 | 3 | 1 | Mine | no | 7 | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L1827 | 3 | 1 | Opponent | no | 5 | 3 | 1 | 3 | 1 | 0 | 0 | 0 |
| L1928 | 2 | 1 | Mine | - | - | 3 | 4 | 3 | 0 | 0 | 0 | 0 |
| L1928 | 2 | 1 | Opponent | - | - | - | 0 | 0 | 0 | 0 | 0 | 0 |
| L2030 | 2 | 1 | Mine | - | - | - | 0 | 3 | 1 | 0 | 0 | 420 |
| L2030 | 2 | 1 | Opponent | - | - | 2 | 7 | 4 | 0 | 0 | 0 | 0 |
| L2132 | 2 | 1 | Mine | - | - | - | 1 | 1 | 0 | 0 | 0 | 940 |
| L2132 | 2 | 1 | Opponent | - | - | 3 | 3 | 3 | 0 | 0 | 0 | 170 |
| L2324 | 2 | 1 | Mine | - | - | 1 | 6 | 1 | 0 | 0 | 0 | 0 |
| L2324 | 2 | 1 | Opponent | - | - | 2 | 6 | 1 | 1 | 0 | 0 | 0 |
| L2430 | 6 | 1 | Mine | no | 8 | 3 | 9 | 0 | 0 | 0 | 0 | 0 |
| L2430 | 6 | 1 | Opponent | no | 2 | 1 | 4 | 1 | 0 | 0 | 0 | 0 |
| L2628 | 6 | 1 | Mine | no | 3 | 2 | 1 | 0 | 0 | 0 | 0 | 0 |
| L2628 | 6 | 1 | Opponent | no | 2 | - | 0 | 0 | 0 | 0 | 0 | 328 |
| L2829 | 3 | 1 | Mine | yes | 4 | - | 1 | 1 | 1 | 0 | 0 | 0 |
| L2829 | 3 | 1 | Opponent | yes | 2 | 2 | 4 | 0 | 0 | 0 | 0 | 170 |
| L3034 | 4 | 1 | Mine | no | 0 | 3 | 1 | 1 | 0 | 0 | 0 | 0 |
| L3034 | 4 | 1 | Opponent | no | 0 | 2 | 6 | 3 | 0 | 0 | 0 | 147 |
| **Average** | | | Mine | 23% | 3.6 | 2.4 | 2.4 | 1.2 | 0.2 | 0.0 | 0.0 | 150.2 |
| **Average** | | | Opponent | 19% | 4.4 | 2.4 | 2.8 | 1.6 | 0.3 | 0.0 | 0.0 | 62.0 |

### KPIs: h3-opp-efe7e34-p2

Rules off - Mine only: HOLDER ASSIGNMENT.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 30% (53 of 174) | 3% (6 of 182) | 17% (59 of 356) |
| Winner chose to follow up after the loser gave ground |  | 80% (37 of 46); on the table 83% | 77% (43 of 56); on the table 82% | 78% (80 of 102); on the table 82% |
| Winner chose to pursue after the loser fell back in good order |  | 89% (16 of 18); on the table 89% | 80% (8 of 10); on the table 80% | 86% (24 of 28); on the table 86% |
| Winner chose to pursue after the loser fled |  | 84% (21 of 25); on the table 84% | 81% (26 of 32); on the table 84% | 82% (47 of 57); on the table 84% |
| Winner chose to follow up or pursue (all three) |  | 83% (74 of 89); on the table 84% | 79% (77 of 98); on the table 83% | 81% (151 of 187); on the table 83% |
| Magic missiles tried each own turn | 50%+ | 26% (87 of 335) | 25% (39 of 156) | 26% (126 of 491) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 34% (81 of 239) | 33% (39 of 119) | 34% (120 of 358) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 58% (11 of 19) | 50% (14 of 28) | 53% (25 of 47) |
| Points that never fought | lower | 42% (29489 of 70360) | 39% (28091 of 71986) | 40% (57580 of 142346) |
|   infantry points that never fought | lower | 56% (8730 of 15655) | 62% (6559 of 10608) | 58% (15289 of 26263) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 62% (169 of 274) | 54% (140 of 260) | 58% (309 of 534) |
| Bound items with a magic missile used (at least once a game) |  | 88% (22 of 25); 1.5 uses a game | 92% (11 of 12); 0.9 uses a game | 89% (33 of 37); 1.2 uses a game |
| Bound items with another spell used |  | 69% (9 of 13); 0.5 uses a game | 40% (2 of 5); 0.1 uses a game | 61% (11 of 18); 0.3 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 57% (12 of 21); 0.3 uses a game | 35% (6 of 17); 0.2 uses a game | 47% (18 of 38); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 56% (33678 of 59989) | 49% (31181 of 62998) | 53% (64859 of 122987) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.9 (28%) | 0.8 (26%) | 2.8 (27%) |
| MARCHED: its unit marched | 1.6 (23%) | 0.7 (22%) | 2.3 (23%) |
| CHARGED: its unit charged | 0.4 (5%) | 0.2 (8%) | 0.6 (6%) |
| IN COMBAT: engaged in combat | 1.3 (19%) | 0.6 (17%) | 1.9 (18%) |
| REAR RANK: in a rear rank | 0.1 (1%) | 0.4 (13%) | 0.5 (5%) |
| FLEEING: fleeing | 0.1 (1%) | 0.1 (2%) | 0.1 (1%) |
| GONE: slain | 1.0 (15%) | 0.4 (12%) | 1.4 (14%) |
| OFF THE TABLE: off the table or not arrived | 0.1 (2%) | 0.0 (1%) | 0.1 (1%) |
| STUPIDITY: Stupidity | 0.2 (3%) | 0.0 (0%) | 0.2 (2%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| HELD BACK: the computer weighed it and chose not to cast it | 0.2 (2%) | 0.0 (0%) | 0.2 (2%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.0 | 1.8 | 1.5 | 3.5 | 0.7 | 2.0 |
| not cast | 3.3 | 2.6 | 3.6 | 10.1 | 1.9 | 22.0 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.9 (9%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.7 (65%) | 0.2 (5%) | 2.8 (27%) | 0.4 (23%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.3 (23%) | 0.5 (25%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.6 (6%) | 0.1 (6%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.1 (2%) | 0.1 (4%) | 0.2 (7%) | 1.9 (18%) | 0.4 (20%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.6 (19%) | 0.2 (6%) | 0.4 (11%) | 0.5 (5%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (0%) | 0.0 (1%) | 0.0 (1%) | 0.1 (1%) | 0.0 (1%) | 0.2 (1%) |
| GONE: slain | 0.9 (28%) | 0.2 (6%) | 0.9 (26%) | 1.4 (14%) | 0.2 (13%) | 2.3 (10%) |
| OFF THE TABLE: off the table or not arrived | 0.3 (10%) | 0.2 (6%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.3 (2%) |
| STUPIDITY: Stupidity | 0.1 (2%) | 0.0 (0%) | 0.1 (2%) | 0.2 (2%) | 0.0 (0%) | 0.3 (2%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (1%) | 0.3 (11%) | 0.0 (1%) | 0.0 (0%) | 0.2 (12%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.3 (39%) | 0.0 (0%) | 1.7 (47%) | 0.2 (2%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 17.0 (77%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.1 a game | 0.7 a game | 0.9 a game |
| stood (cast and not dispelled) | 71% (22 of 31) | 65% (13 of 20) | 69% (35 of 51) |
| the unit moved after it | 73% (16 of 22) | 77% (10 of 13) | 74% (26 of 35) |
| it charged on its next turn | 0% (0 of 22) | 8% (1 of 13) | 3% (1 of 35) |
| the enemy charged it first | 14% (3 of 22) | 8% (1 of 13) | 11% (4 of 35) |
| it fought by the end of its next turn | 0% (0 of 22) | 0% (0 of 13) | 0% (0 of 35) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 22) | 8% (1 of 13) | 3% (1 of 35) |
| none of these (no charge, no fight, no charge escaped) | 86% (19 of 22) | 77% (10 of 13) | 83% (29 of 35) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 61% (520 of 848) | 52% (271 of 521) | 58% (791 of 1369) |
|   cavalry | 62% (52 of 84) | 63% (63 of 100) | 62% (115 of 184) |
|   character | 56% (49 of 88) | 20% (22 of 109) | 36% (71 of 197) |
|   chariot | 62% (58 of 93) | 74% (26 of 35) | 66% (84 of 128) |
|   infantry | 59% (145 of 245) | 67% (97 of 144) | 62% (242 of 389) |
|   monster | 68% (26 of 38) | 78% (7 of 9) | 70% (33 of 47) |
|   war machine | 63% (190 of 300) | 45% (56 of 124) | 58% (246 of 424) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.3 (26%) | 1.1 (16%) | 3.4 (21%) |
| CHARGED: it charged | 0.9 (10%) | 1.2 (18%) | 2.1 (13%) |
| FLEEING: it fled or was fleeing | 0.1 (1%) | 0.1 (2%) | 0.2 (1%) |
| IN COMBAT: it fought this turn or the last | 0.6 (6%) | 0.1 (2%) | 0.7 (4%) |
| MOVED: a war machine that moved | 1.4 (16%) | 1.2 (17%) | 2.6 (16%) |
| NO TARGET IN RANGE | 1.8 (19%) | 1.3 (19%) | 3.1 (19%) |
| ONLY IN COMBAT: the only targets were in combat | 0.1 (2%) | 0.2 (3%) | 0.4 (2%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.4 (15%) | 1.4 (20%) | 2.8 (17%) |
| SHELTERED: the target was sheltered | 0.1 (2%) | 0.1 (1%) | 0.2 (1%) |
| STUPIDITY | 0.0 (0%) | 0.0 (0%) | 0.1 (0%) |
| OTHER BAR | 0.3 (4%) | 0.2 (2%) | 0.5 (3%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 4.9 | 1.4 | 76% | 6.8 pts | 34 pts |
| character | 2.3 | 1.0 | 74% | 9.3 pts | 22 pts |
| chariot | 2.4 | 1.9 | 64% | 17.8 pts | 42 pts |
| infantry | 10.2 | 4.4 | 73% | 9.4 pts | 96 pts |
| monster | 1.1 | 0.3 | 76% | 5.2 pts | 6 pts |
| war machine | 6.9 | 6.8 | 61% | 26.1 pts | 180 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.0 | 4.8 | 4.4 |
| Charges that made contact a game | 3.1 | 3.4 | 3.2 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.09 declared, 0.83 contact (23 units) | 0.85 declared, 0.46 contact (13 units) | 1.00 declared, 0.69 contact (36 units) |
|   per unit a game, units carrying another wizard (or one alone) | 1.12 declared, 1.00 contact (8 units) | 1.07 declared, 0.93 contact (15 units) | 1.09 declared, 0.96 contact (23 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.46 declared, 0.36 contact (238 units) | 0.59 declared, 0.41 contact (249 units) | 0.53 declared, 0.38 contact (487 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 48% (31 of 64) | 58% (11 of 19) | 50% (8 of 16) | 51% (50 of 99) |
| Character in a unit | 86% (30 of 35) | 67% (18 of 27) | 80% (4 of 5) | 78% (52 of 67) |
| Character on its own | 79% (27 of 34) | 62% (26 of 42) | 28% (18 of 64) | 51% (71 of 140) |
| Chariot | 92% (11 of 12) | 54% (7 of 13) | - | 72% (18 of 25) |
| Infantry | 44% (25 of 57) | 32% (11 of 34) | 60% (3 of 5) | 41% (39 of 96) |
| Monster | 64% (14 of 22) | 91% (10 of 11) | - | 73% (24 of 33) |
| Monstrous | 80% (4 of 5) | 50% (7 of 14) | - | 58% (11 of 19) |
| War Machines | 79% (42 of 53) | 100% (2 of 2) | - | 80% (44 of 55) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 100% (5 of 5); on the table 100% | 27% (28 of 102) | 46% | 59% (13 of 22) | 83% (5 of 6); 3.2 uses a game | 100% (2 of 2); 2.0 uses a game | 83% (5 of 6); 1.2 uses a game |
| Chaos Dwarfs | 4 | 60% (3 of 5); on the table 60% | 56% (20 of 36) | 64% | 72% (23 of 32) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |
| Dwarfen Mountain Holds | 4 | 33% (1 of 3); on the table 33% | - | 66% | 71% (24 of 34) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 7 | 64% (7 of 11); on the table 73% | 67% (20 of 30) | 64% | 61% (44 of 72) | 0.0 uses a game | 100% (2 of 2); 0.3 uses a game | 17% (1 of 6); 0.1 uses a game |
| Grand Cathay | 8 | 80% (12 of 15); on the table 80% | 16% (26 of 167) | 34% | 42% (28 of 66) | 100% (19 of 19); 6.0 uses a game | 100% (2 of 2); 0.4 uses a game | 25% (2 of 8); 0.2 uses a game |
| High Elf Realms | 6 | 84% (16 of 19); on the table 84% | 17% (4 of 24) | 36% | 51% (24 of 47) | 71% (5 of 7); 2.7 uses a game | 42% (5 of 12); 1.3 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 2 | 88% (7 of 8); on the table 88% | - | 34% | 75% (9 of 12) | 0.0 uses a game | 0.0 uses a game | 100% (2 of 2); 1.0 uses a game |
| Lizardmen | 1 | 100% (3 of 3); on the table 100% | - | 48% | 71% (5 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 2 | 100% (2 of 2); on the table 100% | 8% (1 of 12) | 68% | 79% (11 of 14) | 50% (1 of 2); 1.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 4 | 100% (6 of 6); on the table 100% | 10% (4 of 42) | 36% | 62% (20 of 32) | 0.0 uses a game | 0.0 uses a game | 25% (1 of 4); 0.2 uses a game |
| Skaven | 2 | 67% (2 of 3); on the table 67% | 50% (6 of 12) | 32% | 88% (14 of 16) | 100% (1 of 1); 0.5 uses a game | 0.0 uses a game | 50% (1 of 2); 0.5 uses a game |
| Tomb Kings of Khemri | 4 | 79% (11 of 14); on the table 86% | - | 43% | 40% (8 of 20) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 8 | 82% (32 of 39); on the table 87% | 29% (12 of 42) | 34% | 56% (28 of 50) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 14 | 80% (39 of 49); on the table 82% | 21% (5 of 24) | 19% | 49% (45 of 92) | 0.0 uses a game | 0.0 uses a game | 100% (6 of 6); 0.4 uses a game |
| Wood Elf Realms | 2 | 100% (5 of 5); on the table 100% | - | 49% | 72% (13 of 18) | 100% (2 of 2); 4.5 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (h3-opp-efe7e34-p2, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 49% (33) | 49% (40) | 49% (73) |
| ...free all their last turn and able to turn (per game) | 0.61 | 0.81 | 1.42 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.19 | 0.11 | 0.31 |
| ...with the charger already in that arc before they moved (per game) | 0.31 | 0.50 | 0.81 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.03 | 0.00 | 0.03 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.08 | 0.36 | 0.44 |

### Quality by phase: h3-opp-efe7e34-p2

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.2 | 2.2 |
| Strategy | Charge objectives carried out (made contact) | 65% (82 of 126) | 55% (80 of 146) |
| Strategy | Shoot objectives carried out (shot that target) | 40% (144 of 362) | 40% (60 of 150) |
| Strategy | Support requests answered (helper made contact too) | 83% (10 of 12) | 57% (4 of 7) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 0% (0 of 1) | 100% (1 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | 55% (11 of 20) | 20% (1 of 5) |
| Strategy | Joined characters whose unit fought | 35% (17 of 49) | 47% (20 of 43) |
| Strategy | Lone characters that fought | 67% (58 of 87) | 78% (72 of 92) |
| Movement | Charges halted short of contact | 0.0 | 0.3 |
| Movement | Idle units | 1.2 | 1.6 |
| Movement | Points that never moved of their own | 150.2 | 62.0 |
| Movement | Fights charged into per game | 2.7 | 2.9 |
| Movement | Charges with odds: long shots (under 50%) | 17 of 90, net +39 | 23 of 92, net +4 |
| Movement | Charges with odds: sweet spot (55-75%) | 16 of 90, net +77 | 13 of 92, net +99 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 11 of 90, net +42 | 14 of 92, net +148 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 26 of 90, net +100 | 18 of 92, net +124 |
| Shooting | Shots by shooting units (incl. breath weapons) | 10.2 | 7.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 43% (159 of 367) | 50% (126 of 251) |
| Shooting | Points destroyed by shooting units | 58.8 | 20.2 |
| Shooting | War machine shots | 5.3 | 1.6 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 49% (94 of 190) | 64% (37 of 58) |
| Shooting | Points destroyed by war machines | 98.1 | 23.0 |
| Magic | Magic missiles cast | 1.7 | 0.8 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 33% (20 of 60) | 32% (9 of 28) |
| Magic | Wounds caused by magic missiles | 4.1 | 1.2 |
| Magic | Wounds caused by other spells | 1.9 | 0.5 |
| Magic | Points destroyed by magic (all spells) | 82.4 | 31.2 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.3 / 0.6 / 0.8 / 0.2 | 1.6 / 0.4 / 0.4 / 0.2 |
| Combat | Points destroyed in combat | 242.8 | 290.5 |
| Combat | Points run down | 47.4 | 157.6 |
| Combat | Net points per charged fight, damage counted | +78 | +82 |
| Combat | Net per 100 charger points, damage counted | +27.0 | +25.9 |
| Combat | First round won (charged fights) | 72% | 75% |
| Combat | Net points per charged fight | +60 | +93 |
| Combat | Net points per supported fight / lone fight | +52 / +62 | +152 / +84 |
| Combat | Charged fights on a top-3 enemy unit | 38 of 97 | 44 of 106 |
| Game | Points lost | 635.4 | 578.0 |
| Game | VP from objectives | 578.9 | 664.2 |
| Game | Lone holders (player turns) | 3.6 | 4.4 |

- Mine won / drew / lost: 15 / 5 / 16 of 36 ended games (of 36); mean margin (Mine - Opponent) -109 VP
- The side that went first won 15 of 31 games with a winner
- Points traded per game (both sides' losses): 1213
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: h3-opp-efe7e34-p2

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.6 | +0.0 | 0.0 | 0.0 | 0.8 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.2 | +36.7 | 0.0 | 5.1 | 0.4 | +52.9 | 0.0 | 21.8 |
| ALREADY CARRIED | 0.1 | +0.0 | 20.7 | 3.6 | - | - | - | - |
| ARRIVAL HUNT | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +0.6 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.9 | +0.0 | 0.0 | 15.3 | 0.3 | +0.0 | 0.0 | 4.6 |
| BACKUP TARGETS | 0.2 | +1.5 | 0.0 | 0.0 | 0.2 | +2.2 | 0.0 | 0.0 |
| BEST PRIZE | - | - | - | - | 0.1 | -2.7 | 6.4 | 0.0 |
| BLOWS WHERE AIMED | 0.2 | -15.0 | 29.1 | 6.5 | 0.3 | -61.9 | 53.4 | 7.4 |
| BOMBING RUN | 0.0 | +0.3 | 0.5 | 2.9 | 0.1 | +1.6 | 9.4 | 4.2 |
| CANNON PLAN MISSED | 0.8 | +0.0 | 106.6 | 15.8 | 0.2 | +0.0 | 13.7 | 4.6 |
| CANNON PLANNED TARGET | 4.6 | +114.1 | 324.8 | 92.9 | 1.3 | +21.5 | 76.7 | 20.3 |
| CANNON SIGHT KEPT | 1.2 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT COUNTER | 0.2 | -14.3 | 23.4 | 0.0 | - | - | - | - |
| CARRIES OUT SET-UP | 0.1 | -1.4 | 6.1 | 0.0 | 0.1 | -5.5 | 0.8 | 0.0 |
| CAST JOB | 0.6 | +23.9 | 50.0 | 10.2 | 0.3 | +4.8 | 9.3 | 0.0 |
| CASTER AWAY FROM SCREEN | 0.4 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.2 | +11.0 | 12.9 | 0.0 | 0.0 | +0.4 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 0.7 | +0.0 | 0.0 | 42.5 | 0.4 | +0.0 | 0.0 | 17.6 |
| CASTS FROM BEHIND | 0.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.1 | +4.0 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | 0.4 | +25.2 | 0.0 | 17.6 | 1.0 | +33.1 | 0.0 | 24.8 |
| CHAFF PASSED | 0.1 | -0.4 | 0.0 | 0.0 | 0.2 | -0.5 | 10.3 | 8.2 |
| CHARACTER GUNS | 0.4 | +0.0 | 0.0 | 12.8 | 0.2 | +0.0 | 0.0 | 0.0 |
| CHARGE LOSSES | 5.6 | -335.6 | 0.0 | 204.9 | 5.3 | -309.3 | 0.0 | 220.2 |
| CHARGE NOT DECLARED | 0.4 | +0.0 | 42.1 | 9.5 | 1.1 | +0.0 | 117.5 | 12.8 |
| CHARGE NOW FIRST | 1.8 | +0.0 | 199.3 | 30.0 | 2.0 | +0.0 | 157.2 | 17.7 |
| CHARGER SLAIN LOST | 0.2 | -14.7 | 6.5 | 3.3 | 0.2 | -2.0 | 7.9 | 7.0 |
| CHEAP HELPER | 0.1 | +0.0 | 0.0 | 3.1 | 0.1 | +0.0 | 5.2 | 0.0 |
| CHEAPEST HOLDER | 0.2 | -22.4 | 6.2 | 0.0 | - | - | - | - |
| COMBAT PIVOT | 0.4 | +0.0 | 18.8 | 18.1 | 0.2 | +0.0 | 33.1 | 12.0 |
| CONTINUE AHEAD WEIGHED | - | - | - | - | 0.1 | +0.0 | 3.9 | 7.1 |
| CONVEYANCE SEARCH | 0.6 | +74.2 | 12.1 | 32.6 | 0.4 | +25.4 | 0.9 | 0.0 |
| COVER ONCE | 7.1 | -511.7 | 0.0 | 130.3 | 5.9 | -489.5 | 0.0 | 82.1 |
| DEFENSIVE ARMY | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| DEPLOY BY FIGURES | 7.9 | +0.8 | 0.0 | 12.8 | 7.2 | +36.8 | 0.0 | 9.4 |
| EDGE GIVE GROUND | 0.1 | +10.5 | 31.9 | 7.6 | 0.2 | +3.5 | 33.9 | 0.0 |
| ELIXIR WORTH | 0.0 | +0.4 | 0.0 | 0.0 | - | - | - | - |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 0.0 | +6.6 | 0.0 | 0.0 | - | - | - | - |
| FALL BACK GOOD ORDER | 2.4 | +4.8 | 222.4 | 53.8 | 3.0 | +15.7 | 237.1 | 22.1 |
| FALLBACK BY WORTH | 0.2 | +0.0 | 0.0 | 0.0 | 0.3 | +0.1 | 0.0 | 1.5 |
| FALLS SHORT | 5.6 | +86.2 | 0.0 | 55.9 | 16.1 | +237.7 | 0.0 | 221.5 |
| FEATURE BUFFS | 1.0 | +26.4 | 0.0 | 4.9 | 0.5 | +7.0 | 0.0 | 0.0 |
| FIGHT TO THE END | 1.5 | +92.5 | 168.0 | 53.4 | 1.6 | +42.4 | 129.7 | 20.3 |
| FIRE AND FLEE | 0.0 | +7.1 | 13.7 | 0.0 | 0.0 | +3.5 | 0.0 | 0.0 |
| FIRE IN ORDER | 0.2 | +0.0 | 12.3 | 15.9 | 0.0 | +0.0 | 0.0 | 0.0 |
| FIVE ACTION | 45.2 | +3017.2 | 1033.0 | 723.6 | 42.2 | +2576.1 | 549.7 | 583.7 |
| FLANK NOT WEIGHED | 5.7 | +0.0 | 0.0 | 138.4 | 5.9 | +0.0 | 0.0 | 113.1 |
| FOCUS FIRE | 0.0 | +0.9 | 4.2 | 0.0 | 0.0 | +0.6 | 1.5 | 0.0 |
| FOLLOW UP WEIGHED | 0.7 | +157.4 | 0.0 | 19.1 | 0.9 | +163.4 | 0.0 | 6.1 |
| FOUR ROUNDS | 3.4 | +542.4 | 342.1 | 76.7 | 4.0 | +425.0 | 336.6 | 45.0 |
| FRIEND CHARGES FIRST | 0.1 | -6.1 | 0.0 | 0.0 | 0.1 | -5.4 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 0.1 | -3.6 | 0.0 | 0.0 | 0.2 | -6.8 | 0.0 | 8.2 |
| FRIENDS SHOTS CHECKED | 0.0 | +1.5 | 0.0 | 0.0 | 0.1 | +5.0 | 0.0 | 0.0 |
| GIVES UP | 0.3 | -22.2 | 50.6 | 17.5 | 0.4 | -6.9 | 35.5 | 9.2 |
| GIVES UP ITS SCREEN | 0.0 | -0.3 | 6.6 | 0.0 | 0.1 | -1.2 | 0.0 | 1.2 |
| GROUND FLIERS | 0.1 | +1.8 | 0.0 | 0.0 | - | - | - | - |
| GUN FIGURES | 1.6 | +39.8 | 45.8 | 1.8 | 0.4 | +1.4 | 1.7 | 14.7 |
| GUN MASK | 0.7 | +49.8 | 0.0 | 20.7 | 0.6 | +13.3 | 0.0 | 14.6 |
| HARD STAY DROPPED | 1.3 | +0.0 | 0.0 | 26.8 | 0.8 | +0.0 | 0.0 | 22.9 |
| HE SHOOTS OR CHARGES | 1.4 | +0.0 | 0.0 | 22.2 | 2.6 | +0.0 | 0.0 | 73.1 |
| HELPER ALREADY ASKED | - | - | - | - | 0.0 | +0.0 | 6.5 | 0.0 |
| HELPER UNSEEN | 0.0 | +0.0 | 5.4 | 0.0 | 0.1 | +0.0 | 0.0 | 1.7 |
| HIS CHARGE DENIED | 0.6 | +15.4 | 48.3 | 21.5 | 0.5 | +32.0 | 24.2 | 1.7 |
| HIS CHARGE LIST | 2.1 | +0.0 | 0.0 | 49.3 | 2.4 | +0.0 | 0.0 | 43.7 |
| HIS LEGAL MOVES | 4.3 | +0.0 | 0.0 | 83.9 | 4.0 | +0.0 | 0.0 | 43.2 |
| HIS MOVE AND SHOT | 1.5 | -32.4 | 0.0 | 62.8 | 2.4 | -67.3 | 0.0 | 106.5 |
| HIS RANDOM MOVE | 1.5 | +0.0 | 0.0 | 25.6 | 1.5 | +0.0 | 0.0 | 11.0 |
| HIS SHOT LIST | 14.6 | +469.7 | 0.0 | 285.0 | 20.7 | +1066.3 | 0.0 | 396.3 |
| HIS TURN DENIED | 0.9 | +27.1 | 107.6 | 32.4 | 2.2 | +106.0 | 161.2 | 37.7 |
| HOLD ODDS | - | - | - | - | 6.2 | +0.0 | 0.0 | 44.4 |
| HOLDER ASSIGNMENT | - | - | - | - | 12.1 | +1113.9 | 0.0 | 67.2 |
| HOLDER AT DEPLOYMENT | 1.0 | +180.4 | 0.0 | 0.0 | - | - | - | - |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.5 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 3.1 | -121.9 | 321.2 | 69.6 | 3.6 | -159.3 | 300.5 | 34.9 |
| HUNT IN PAIRS | 0.2 | +2.7 | 0.0 | 0.0 | 0.4 | +16.3 | 0.0 | 0.0 |
| HUNT RESULT | 0.0 | +6.6 | 0.0 | 1.7 | 0.0 | +4.3 | 0.0 | 0.0 |
| HUNT THE GUNS | 0.0 | +6.8 | 6.5 | 1.7 | 0.0 | +5.1 | 2.6 | 0.0 |
| IDLE COST | 2.8 | -49.0 | 0.0 | 37.4 | 9.3 | -157.7 | 0.0 | 176.6 |
| JOINT KNOWS CHALLENGE | 0.0 | -0.1 | 0.0 | 0.0 | - | - | - | - |
| KEEP FALLS | 0.0 | +0.6 | 0.0 | 0.0 | - | - | - | - |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KILLS COUNT | 0.0 | +1.4 | 4.8 | 0.0 | 0.0 | +0.2 | 0.0 | 0.0 |
| LANE BY FIGURES | 0.7 | +28.3 | 0.0 | 0.0 | 1.0 | +50.5 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 5.6 | +0.0 | 164.1 | 219.6 | 5.9 | +0.0 | 234.8 | 215.9 |
| LINE HITS NO ONE | 0.2 | -0.7 | 0.0 | 0.0 | - | - | - | - |
| LONE CHARACTER SAFE SPOT | 0.1 | +0.4 | 0.0 | 3.1 | 0.1 | +5.9 | 0.0 | 0.0 |
| LONE WIZARD KEPT IN | 0.5 | +32.2 | 0.0 | 0.0 | 0.2 | +21.3 | 0.0 | 0.0 |
| LONG SHOT | 0.3 | -0.3 | 24.5 | 4.4 | 0.3 | +2.3 | 25.3 | 0.0 |
| LOST CHARGE | 0.1 | -0.3 | 9.4 | 0.0 | 0.0 | -0.0 | 2.4 | 0.0 |
| LURE BY WHAT IT DRAWS | 0.0 | -1.4 | 0.0 | 0.0 | 0.1 | -10.7 | 0.0 | 1.7 |
| MAKE SURE TOGETHER | 0.1 | +2.5 | 0.0 | 4.6 | 0.1 | +9.7 | 0.0 | 0.0 |
| MANOEUVRE | 1.3 | +20.7 | 0.0 | 40.3 | 1.0 | +29.6 | 0.0 | 26.1 |
| MARCH AT ESCAPER | 0.2 | +4.1 | 0.0 | 11.4 | 0.1 | +0.8 | 0.0 | 0.0 |
| MARCH BY THE SUM | 0.3 | +10.4 | 0.0 | 4.6 | 0.2 | +8.2 | 0.0 | 0.0 |
| MARCH CHECK | 1.0 | +50.6 | 0.0 | 42.5 | 0.6 | +24.6 | 0.0 | 0.0 |
| MARCH ODDS | - | - | - | - | 0.1 | +1.3 | 0.0 | 0.0 |
| MARCH OVER CASTS | 0.8 | +39.5 | 0.0 | 26.6 | 0.7 | +130.1 | 0.0 | 13.1 |
| MAX FOR POSITIONING | 6.0 | +88.9 | 0.0 | 119.1 | 6.2 | +95.9 | 0.0 | 75.4 |
| MISSILES IN THE MOVE | 3.8 | +141.9 | 0.0 | 112.6 | 2.4 | +37.9 | 0.0 | 51.0 |
| MISSILES NEXT TURN | 4.9 | +95.4 | 0.0 | 136.9 | 3.3 | +26.7 | 0.0 | 75.2 |
| MODEL FACING | 0.3 | +43.5 | 0.0 | 5.0 | - | - | - | - |
| MOVE SPELL IN RANGE | 0.1 | +4.1 | 0.0 | 16.1 | 0.1 | +3.0 | 0.0 | 6.5 |
| MOVE SPELL OUT OF RANGE | 0.2 | -7.8 | 0.0 | 16.1 | 0.0 | -0.1 | 0.0 | 0.0 |
| MOVE SPELL SPOT | 0.3 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 11.1 |
| MOVE TO CHARGE COMPUTED | 4.1 | +571.1 | 0.0 | 56.0 | 4.8 | +675.7 | 0.0 | 34.5 |
| MOVES UNITS SPELL | 0.1 | +3.6 | 0.0 | 11.0 | 0.1 | +0.4 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 4.2 | +248.1 | 0.0 | 60.8 | 3.6 | +154.5 | 0.0 | 17.8 |
| NEEDED THERE | 0.0 | +2.4 | 4.8 | 0.0 | 0.0 | +10.4 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 5.6 | -297.4 | 19.7 | 75.0 | 6.1 | -184.2 | 0.0 | 69.6 |
| NEXT OBJECTIVE NEARER | 7.2 | -366.5 | 71.2 | 126.6 | 6.0 | -192.4 | 13.9 | 70.1 |
| NO DOUBLE ROUNDS | 2.6 | -122.6 | 293.1 | 69.8 | 3.4 | -153.2 | 265.4 | 43.4 |
| NO RALLY LEFT | 0.0 | +6.5 | 0.0 | 0.0 | 0.0 | +0.2 | 0.0 | 6.1 |
| NOT TURNED | 0.1 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 5.8 |
| NOT WORTH A CAST | 0.3 | -0.1 | 0.0 | 11.0 | 0.3 | -0.1 | 0.0 | 0.0 |
| OFF BEST | 0.3 | -5.4 | 0.0 | 3.1 | 0.6 | -11.5 | 0.0 | 2.7 |
| ONE CHARGE A CHARGER | 3.4 | +0.0 | 0.0 | 104.8 | 2.7 | +0.0 | 0.0 | 46.2 |
| ONE FIGHT FORMULA | 5.2 | -108.9 | 0.0 | 78.8 | 6.5 | -167.9 | 0.0 | 94.1 |
| ONE OBJECTIVE FORMULA | 3.5 | -79.3 | 0.0 | 24.2 | 4.3 | -80.2 | 0.0 | 45.9 |
| ONE TARGET A SHOOTER | 12.9 | +256.9 | 0.0 | 251.8 | 17.8 | +610.0 | 0.0 | 214.0 |
| OPENS A LANE | 0.1 | +0.3 | 5.2 | 0.0 | 0.0 | +0.4 | 2.4 | 0.0 |
| OPENS UP | 0.1 | +3.3 | 5.1 | 0.0 | 0.3 | +15.1 | 4.9 | 7.9 |
| OVERRUNS AWAY | 0.2 | +7.4 | 15.6 | 2.6 | 0.5 | +17.6 | 46.1 | 0.0 |
| PATHS CROSS | 3.4 | +163.0 | 0.0 | 41.4 | 4.0 | +130.5 | 0.0 | 28.8 |
| PERIAPT WORTH | 0.0 | +2.8 | 0.0 | 15.0 | - | - | - | - |
| PIVOT GUARDS FLANK | 0.1 | -9.0 | 0.0 | 8.9 | 0.3 | -13.7 | 0.0 | 0.0 |
| PLAN RESULT | 39.8 | +917.9 | 671.0 | 947.2 | 37.6 | +485.0 | 220.8 | 878.3 |
| PURSUES BIG PREY | 0.1 | -9.7 | 0.0 | 0.0 | 0.1 | -14.2 | 0.0 | 0.0 |
| RANDOM MOVE BY FIGURES | 0.5 | +19.4 | 0.0 | 25.6 | 0.8 | +4.8 | 0.0 | 9.4 |
| REDIRECT BY WHAT IT STOPS | 0.2 | -1.9 | 0.0 | 1.8 | 0.5 | -12.0 | 0.0 | 13.5 |
| REDIRECT COUNTER | 2.2 | +179.0 | 0.0 | 24.0 | 3.7 | +274.2 | 0.0 | 40.8 |
| REDIRECT WEIGHED | 0.1 | +2.1 | 7.9 | 0.0 | 0.3 | -1.8 | 12.4 | 9.5 |
| REFORMS TO MEET IT | 1.2 | -59.4 | 0.0 | 22.2 | 0.8 | -51.0 | 0.0 | 13.7 |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | 0.3 | +8.8 | 0.0 | 18.7 | 0.6 | +17.8 | 0.0 | 9.7 |
| RESTRAINS TO SHOOT | 0.1 | +7.4 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | 2.6 | +140.1 | 267.0 | 63.4 | 2.8 | +43.0 | 230.0 | 22.4 |
| RISK BY HIS FIGURE | 14.1 | -302.5 | 0.0 | 356.9 | 14.3 | -193.8 | 0.0 | 273.0 |
| RUN DOWN | 2.2 | -26.1 | 241.0 | 59.7 | 3.1 | -37.7 | 237.6 | 24.0 |
| SAME CHARGE LATER | 0.2 | -6.9 | 6.8 | 10.2 | 0.1 | -1.2 | 0.0 | 0.0 |
| SCOUT SPOT | 0.3 | +0.5 | 0.0 | 0.0 | 0.3 | +0.6 | 0.0 | 0.0 |
| SCOUT WAITS | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 0.2 | +2.7 | 0.0 | 1.2 |
| SEARCH SPOT | 6.1 | +293.9 | 0.0 | 87.0 | 5.2 | +290.4 | 0.0 | 77.4 |
| SELF MOVE SPELL | 0.4 | +27.8 | 0.0 | 11.0 | 0.3 | +10.1 | 0.0 | 27.2 |
| SET UP TOGETHER | 0.1 | +5.2 | 0.0 | 4.6 | 0.1 | +9.7 | 0.0 | 0.0 |
| SET-UP ANY TARGET | 0.1 | +8.6 | 10.3 | 0.0 | 0.1 | +12.8 | 0.0 | 0.0 |
| SHOOTER COUNTED ONCE | - | - | - | - | 0.1 | -0.1 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.4 | +0.9 | 0.0 | 0.0 | 0.1 | +0.2 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.1 | +39.7 | 55.5 | 6.3 | 0.6 | +20.3 | 24.2 | 9.1 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 3.8 | 0.1 | +0.0 | 0.0 | 0.0 |
| SHOT OR CHARGE | 0.3 | -14.5 | 44.7 | 12.6 | 0.2 | -6.2 | 6.2 | 0.0 |
| SHOT RISK POINTS | 7.2 | -23.9 | 0.0 | 196.5 | 12.9 | +65.3 | 0.0 | 286.6 |
| SHOTS IN THE MOVE | 15.3 | +767.6 | 0.0 | 249.4 | 8.9 | +206.4 | 0.0 | 106.6 |
| SPELL SETS UP CHARGE | 0.2 | +83.0 | 10.3 | 3.6 | 0.1 | +12.8 | 0.0 | 0.0 |
| SPELL WORTH | 1.2 | +30.1 | 48.4 | 58.6 | 1.6 | +32.0 | 80.8 | 70.1 |
| SPELLS IN THE FIGHT | 0.8 | -0.9 | 76.2 | 13.0 | 0.5 | -3.2 | 42.3 | 13.1 |
| STAND AND SHOOT | 0.2 | -3.0 | 9.8 | 2.9 | 0.7 | -11.5 | 32.9 | 10.4 |
| STANDS FOR A REASON | 0.1 | +0.0 | 3.1 | 0.0 | 0.3 | +0.0 | 0.0 | 2.0 |
| STANDS STILL | 17.2 | +0.0 | 660.5 | 212.7 | 9.5 | +0.0 | 168.4 | 108.7 |
| STAY WORTH | 17.4 | +73.3 | 418.7 | 199.8 | 8.2 | +24.9 | 64.9 | 127.1 |
| STOPS | 0.0 | +0.1 | 6.5 | 1.7 | 0.0 | +0.5 | 2.6 | 0.0 |
| STUCK PIVOT | - | - | - | - | 0.2 | +0.0 | 0.0 | 0.0 |
| SUPPORT NARROWED | 0.9 | +0.0 | 79.6 | 24.2 | 1.4 | +0.0 | 92.1 | 5.7 |
| SURE REACH TOGETHER | 0.4 | +8.6 | 0.0 | 8.4 | 0.2 | +0.7 | 0.0 | 5.2 |
| THE DEARER SUM KEEPS ITS PLAN | 3.9 | +0.0 | 0.0 | 47.4 | 4.0 | +0.0 | 0.0 | 29.8 |
| THE PROMISE ADDS | 0.3 | -26.6 | 23.9 | 1.4 | 0.2 | -16.0 | 0.0 | 1.4 |
| THE PROMISED MOVE | 0.3 | +0.0 | 0.0 | 0.0 | 1.2 | +0.0 | 0.0 | 13.6 |
| TIED UP BY THE SUM | 0.6 | +64.3 | 46.9 | 4.2 | 0.6 | +73.0 | 36.5 | 7.9 |
| TIME ON OUR SIDE | 25.9 | +389.6 | 11.2 | 329.9 | 9.1 | +144.3 | 0.0 | 106.8 |
| WAITS AGAIN | 1.4 | +0.0 | 0.0 | 16.0 | 1.6 | +0.0 | 0.0 | 9.2 |
| WAR ENGINE CHARGES | 0.0 | +4.7 | 7.1 | 0.0 | - | - | - | - |
| WAR ENGINE JOBS | 0.3 | +0.0 | 27.6 | 0.0 | - | - | - | - |
| WHO HITS BACK | 0.4 | +45.4 | 0.0 | 6.2 | 0.3 | +45.9 | 0.0 | 0.0 |
| WHOLE FIGHT | 0.3 | -9.2 | 34.7 | 0.0 | 0.1 | -0.2 | 13.1 | 0.0 |
| WHOLE FIGHT GAIN | 0.2 | +13.7 | 25.8 | 1.4 | 0.1 | +4.0 | 11.8 | 0.0 |
| WIDER SPREAD | 2.0 | -3.4 | 176.9 | 44.4 | 2.6 | -3.7 | 211.9 | 25.8 |
| WOUNDS ON THE RANKS | 0.9 | +57.5 | 0.0 | 61.1 | 1.1 | +94.2 | 0.0 | 29.3 |

### Rule changes: h3-opp-efe7e34-p2

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| LEGAL CHARGES ONLY | 415 | 415 | 415 | 11.53 | +0 | +0.0 |
| HOLDER ASSIGNMENT | 437 | 437 | 406 | 11.28 | +21134 | +52.1 |
| SEARCH SPOT | 407 | 407 | 388 | 10.78 | +21032 | +54.2 |
| HIS SHOT LIST | 1272 | 1272 | 369 | 10.25 | +10040 | +27.2 |
| DEPLOY BY FIGURES | 542 | 542 | 328 | 9.11 | +4645 | +14.2 |
| FIVE ACTION | 3148 | 3143 | 316 | 8.78 | +15402 | +48.7 |
| PATHS CROSS | 268 | 268 | 268 | 7.44 | +10566 | +39.4 |
| ONE TARGET A SHOOTER | 1103 | 1103 | 267 | 7.42 | +3314 | +12.4 |
| TIME ON OUR SIDE | 1258 | 1120 | 229 | 6.36 | +638 | +2.8 |
| MOVE TO CHARGE COMPUTED | 321 | 321 | 184 | 5.11 | +16414 | +89.2 |
| FOUR ROUNDS | 268 | 263 | 146 | 4.06 | +11654 | +79.8 |
| SHOT RISK POINTS | 724 | 724 | 122 | 3.39 | +5094 | +41.8 |
| MAX FOR POSITIONING | 441 | 430 | 94 | 2.61 | +522 | +5.6 |
| COVER ONCE | 470 | 378 | 87 | 2.42 | +1605 | +18.5 |
| ARTILLERY RE-ROLL WEIGHED | 78 | 78 | 78 | 2.17 | +0 | +0.0 |
| HARD STAY DROPPED | 74 | 74 | 74 | 2.06 | +0 | +0.0 |
| CHARGE LOSSES | 393 | 393 | 62 | 1.72 | +5379 | +86.8 |
| SHOTS IN THE MOVE | 872 | 820 | 62 | 1.72 | +2072 | +33.4 |
| LANE BY FIGURES | 59 | 59 | 59 | 1.64 | +2839 | +48.1 |
| NEXT OBJECTIVE NEARER | 475 | 475 | 59 | 1.64 | +1008 | +17.1 |
| FOLLOW UP WEIGHED | 56 | 56 | 56 | 1.56 | +11551 | +206.3 |
| RISK BY ARC | 193 | 188 | 56 | 1.56 | +1688 | +30.2 |
| CANNON SIGHT KEPT | 51 | 51 | 51 | 1.42 | +0 | +0.0 |
| CHARGE NOT DECLARED | 51 | 51 | 51 | 1.42 | -8968 | -175.8 |
| ADVANCE LANE KEPT | 50 | 50 | 50 | 1.39 | +0 | +0.0 |
| REDIRECT COUNTER | 214 | 183 | 50 | 1.39 | +3820 | +76.4 |
| MANOEUVRE | 83 | 83 | 48 | 1.33 | +1970 | +41.0 |
| NEXT CHARGE BY LIST | 422 | 422 | 46 | 1.28 | +1003 | +21.8 |
| FALLS SHORT | 780 | 686 | 45 | 1.25 | +164 | +3.7 |
| RISK BY HIS FIGURE | 1023 | 1023 | 45 | 1.25 | +3718 | +82.6 |
| SHOOTS FROM THE BEST SPOT | 60 | 60 | 45 | 1.25 | +412 | +9.2 |
| TIED UP BY THE SUM | 45 | 43 | 39 | 1.08 | +1352 | +34.7 |
| IDLE COST | 436 | 365 | 38 | 1.06 | +386 | +10.2 |
| HIS TURN DENIED | 113 | 111 | 36 | 1.00 | +988 | +27.5 |
| MARCH CHECK | 59 | 59 | 35 | 0.97 | +680 | +19.4 |
| CHARGE NOW FIRST | 135 | 135 | 34 | 0.94 | -2073 | -61.0 |
| RESERVE FALL BACK | 34 | 34 | 34 | 0.94 | +959 | +28.2 |
| HOLDS AMBUSHERS | 33 | 33 | 33 | 0.92 | +0 | +0.0 |
| MISSILES IN THE MOVE | 226 | 190 | 33 | 0.92 | +770 | +23.3 |
| CANNON PLANNED TARGET | 213 | 213 | 32 | 0.89 | -900 | -28.1 |
| OFF BEST | 32 | 32 | 32 | 0.89 | -608 | -19.0 |
| CHAFF IN THE MOVE | 52 | 50 | 27 | 0.75 | +251 | +9.3 |
| LONE WIZARD KEPT IN | 27 | 27 | 27 | 0.75 | +1925 | +71.3 |
| ONE OBJECTIVE FORMULA | 280 | 251 | 26 | 0.72 | +837 | +32.2 |
| WHO HITS BACK | 26 | 26 | 26 | 0.72 | +2451 | +94.3 |
| NEARER NOT NEEDED | 281 | 267 | 25 | 0.69 | +1071 | +42.8 |
| RANDOM MOVE BY FIGURES | 47 | 47 | 25 | 0.69 | +870 | +34.8 |
| CAST JOB | 31 | 31 | 22 | 0.61 | +117 | +5.3 |
| COMBAT PIVOT | 22 | 22 | 22 | 0.61 | +0 | +0.0 |
| SCOUT WAITS | 22 | 22 | 22 | 0.61 | +0 | +0.0 |
| AFTERMATH IN POINTS | 21 | 21 | 21 | 0.58 | +3227 | +153.6 |
| HOLDER AT DEPLOYMENT | 35 | 35 | 21 | 0.58 | +1007 | +48.0 |
| WOUNDS ON THE RANKS | 75 | 75 | 21 | 0.58 | +600 | +28.6 |
| FIGHT TO THE END | 110 | 109 | 20 | 0.56 | +517 | +25.9 |
| CASTER AWAY FROM SCREEN | 19 | 19 | 19 | 0.53 | +0 | +0.0 |
| ONE FIGHT FORMULA | 423 | 245 | 18 | 0.50 | +140 | +7.8 |
| MARCH BY THE SUM | 17 | 17 | 17 | 0.47 | +670 | +39.4 |
| REDIRECT WEIGHED | 17 | 17 | 17 | 0.47 | +990 | +58.2 |
| SHOOTERS IN TWO RANKS | 17 | 17 | 17 | 0.47 | +40 | +2.4 |
| PIVOT GUARDS FLANK | 15 | 15 | 15 | 0.42 | -815 | -54.3 |
| CHAFF PASSED | 14 | 14 | 14 | 0.39 | -33 | -2.4 |
| STAY WORTH | 922 | 893 | 14 | 0.39 | +94 | +6.7 |
| HIS CHARGE DENIED | 37 | 37 | 13 | 0.36 | +666 | +51.2 |
| MODEL FACING | 12 | 12 | 12 | 0.33 | +1566 | +130.5 |
| CASTS FROM BEHIND | 11 | 11 | 11 | 0.31 | +0 | +0.0 |
| SHORT GUN FORWARD | 10 | 10 | 10 | 0.28 | +0 | +0.0 |
| SUPPORT NARROWED | 85 | 85 | 10 | 0.28 | -144 | -14.4 |
| FEATURE BUFFS | 53 | 53 | 9 | 0.25 | +223 | +24.8 |
| FIRE IN ORDER | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| MISSILES NEXT TURN | 294 | 225 | 8 | 0.22 | +95 | +11.9 |
| MOVES UNITS SPELL | 8 | 8 | 8 | 0.22 | +142 | +17.8 |
| SURE REACH TOGETHER | 24 | 24 | 8 | 0.22 | +67 | +8.3 |
| HONEST WORTH | 242 | 237 | 7 | 0.19 | +150 | +21.5 |
| OPENS UP | 12 | 12 | 7 | 0.19 | +145 | +20.7 |
| OVERRUNS AWAY | 25 | 23 | 7 | 0.19 | +102 | +14.6 |
| WIDER SPREAD | 167 | 163 | 7 | 0.19 | +48 | +6.8 |
| FALL BACK GOOD ORDER | 195 | 191 | 6 | 0.17 | +134 | +22.4 |
| GUN MASK | 49 | 49 | 6 | 0.17 | +630 | +105.0 |
| LINE HITS NO ONE | 6 | 6 | 6 | 0.17 | +26 | +4.3 |
| STUCK PIVOT | 6 | 6 | 6 | 0.17 | +0 | +0.0 |
| WHOLE FIGHT GAIN | 12 | 12 | 6 | 0.17 | +228 | +38.1 |
| HIS MOVE AND SHOT | 140 | 140 | 5 | 0.14 | +138 | +27.6 |
| PURSUES BIG PREY | 5 | 5 | 5 | 0.14 | -859 | -171.8 |
| BEST PRIZE | 4 | 4 | 4 | 0.11 | -169 | -42.3 |
| CASTING BLOCK | 7 | 7 | 4 | 0.11 | +170 | +42.5 |
| CONTINUE AHEAD WEIGHED | 4 | 4 | 4 | 0.11 | +0 | +0.0 |
| FRIENDS SHOTS CHECKED | 4 | 4 | 4 | 0.11 | +231 | +57.7 |
| HUNT IN PAIRS | 22 | 13 | 4 | 0.11 | +57 | +14.1 |
| REFUSING RETIRES | 16 | 16 | 4 | 0.11 | -1 | -0.2 |
| BOMBING RUN | 3 | 3 | 3 | 0.08 | +68 | +22.6 |
| CARRIES OUT SET-UP | 4 | 4 | 3 | 0.08 | -250 | -83.4 |
| EDGE GIVE GROUND | 14 | 14 | 3 | 0.08 | +71 | +23.6 |
| NO DOUBLE ROUNDS | 214 | 210 | 3 | 0.08 | +27 | +8.9 |
| RESTRAINS TO SHOOT | 3 | 3 | 3 | 0.08 | +267 | +89.1 |
| SET UP TOGETHER | 7 | 6 | 3 | 0.08 | +80 | +26.6 |
| CARRIES OUT COUNTER | 6 | 6 | 2 | 0.06 | -515 | -257.4 |
| FIRE AND FLEE | 2 | 2 | 2 | 0.06 | +383 | +191.4 |
| FOCUS FIRE | 2 | 2 | 2 | 0.06 | +54 | +27.1 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| KILLS COUNT | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| LONG SHOT | 20 | 19 | 2 | 0.06 | +20 | +10.0 |
| MARCH ODDS | 2 | 2 | 2 | 0.06 | -26 | -12.8 |
| NEEDED THERE | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| NO RALLY LEFT | 2 | 2 | 2 | 0.06 | +152 | +76.2 |
| SPELLS IN THE FIGHT | 47 | 45 | 2 | 0.06 | +10 | +4.9 |
| WHOLE FIGHT | 16 | 15 | 2 | 0.06 | +34 | +17.0 |
| ELIXIR WORTH | 1 | 1 | 1 | 0.03 | +13 | +12.9 |
| FACES THE THREAT | 1 | 1 | 1 | 0.03 | +236 | +235.8 |
| FALLBACK BY WORTH | 17 | 17 | 1 | 0.03 | +2 | +2.2 |
| KEEP FALLS | 1 | 1 | 1 | 0.03 | +47 | +46.7 |
| OPENS A LANE | 4 | 3 | 1 | 0.03 | +0 | +0.0 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.03 | +99 | +99.0 |
| REFORMS TO MEET IT | 73 | 73 | 1 | 0.03 | +12 | +11.6 |
| STAND AND SHOOT | 32 | 31 | 1 | 0.03 | +10 | +10.1 |
| WAR ENGINE CHARGES | 1 | 1 | 1 | 0.03 | +74 | +73.8 |
| WAR ENGINE JOBS | 10 | 10 | 1 | 0.03 | -0 | -0.3 |
| ALREADY CARRIED | 3 | not checked | - | - | - | - |
| ARRIVAL HUNT | 3 | 3 | 0 | 0.00 | - | - |
| BACKUP TARGETS | 18 | 5 | 0 | 0.00 | - | - |
| BLOWS WHERE AIMED | 19 | 19 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 37 | 37 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 42 | trace | - | - | - | - |
| CATCH FLIERS | 2 | not checked | - | - | - | - |
| CHARACTER GUNS | 22 | 22 | 0 | 0.00 | - | - |
| CHARGER SLAIN LOST | 18 | 18 | 0 | 0.00 | - | - |
| CHEAP HELPER | 4 | not checked | - | - | - | - |
| CHEAPEST HOLDER | 7 | 7 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 36 | not checked | - | - | - | - |
| DEFENSIVE ARMY | 1 | 1 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 419 | not checked | - | - | - | - |
| FRIEND CHARGES FIRST | 7 | 7 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 10 | 10 | 0 | 0.00 | - | - |
| GIVES UP | 25 | 24 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 3 | 3 | 0 | 0.00 | - | - |
| GROUND FLIERS | 3 | not checked | - | - | - | - |
| GUN FIGURES | 69 | not checked | - | - | - | - |
| HE SHOOTS OR CHARGES | 145 | 145 | 0 | 0.00 | - | - |
| HELPER ALREADY ASKED | 1 | not checked | - | - | - | - |
| HELPER UNSEEN | 6 | 6 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 160 | 160 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 300 | 300 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 107 | 107 | 0 | 0.00 | - | - |
| HOLD ODDS | 225 | 225 | 0 | 0.00 | - | - |
| HUNT RESULT | 2 | trace | - | - | - | - |
| HUNT THE GUNS | 2 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 4 | not checked | - | - | - | - |
| LOST CHARGE | 5 | 5 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 5 | 5 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 5 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 13 | trace | - | - | - | - |
| MARCH OVER CASTS | 54 | 54 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 7 | 6 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 9 | trace | - | - | - | - |
| MOVE SPELL SPOT | 18 | not checked | - | - | - | - |
| NOT TURNED | 16 | 16 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 21 | not checked | - | - | - | - |
| ONE CHARGE A CHARGER | 222 | 222 | 0 | 0.00 | - | - |
| PLAN RESULT | 2786 | trace | - | - | - | - |
| REDIRECT BY WHAT IT STOPS | 23 | 23 | 0 | 0.00 | - | - |
| RUN DOWN | 189 | 184 | 0 | 0.00 | - | - |
| SAME CHARGE LATER | 11 | 11 | 0 | 0.00 | - | - |
| SCOUT SPOT | 20 | 20 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 8 | 8 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 25 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 6 | not checked | - | - | - | - |
| SHOOTER COUNTED ONCE | 2 | 2 | 0 | 0.00 | - | - |
| SHOT OR CHARGE | 19 | 18 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 12 | not checked | - | - | - | - |
| SPELL WORTH | 104 | not checked | - | - | - | - |
| STANDS FOR A REASON | 17 | 17 | 0 | 0.00 | - | - |
| STANDS STILL | 963 | 963 | 0 | 0.00 | - | - |
| STOPS | 2 | 2 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 287 | not checked | - | - | - | - |
| THE PROMISE ADDS | 18 | 18 | 0 | 0.00 | - | - |
| THE PROMISED MOVE | 55 | not checked | - | - | - | - |
| WAITS AGAIN | 107 | 107 | 0 | 0.00 | - | - |

### Off best figure: h3-opp-efe7e34-p2

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| CHARGE NOT DECLARED | rule | 0.36 | 0.97 | 186.8 |
| HOLDER ASSIGNMENT | rule | - | 1.06 | 21.9 |
| PATHS CROSS | rule | 0.42 | 0.56 | 41.4 |
| CHARGE NOW FIRST | rule | 0.42 | 0.50 | 62.8 |
| PIVOT GUARDS FLANK | rule | 0.14 | 0.28 | 54.3 |
| JOB FIRST | gate | 0.06 | 0.31 | 29.7 |
| CANNON PLANNED TARGET | rule | 0.28 | - | 90.0 |
| SUPPORT NARROWED | rule | 0.11 | 0.17 | 14.3 |
| FIGHT ORDER BAND | gate | 0.11 | 0.11 | 2.0 |
| DEPLOY BY FIGURES | rule | 0.03 | 0.17 | 20.7 |
| AFTERMATH BAND | gate | 0.06 | 0.08 | 3.0 |
| CHAFF PASSED | rule | 0.06 | 0.08 | 6.4 |
| PURSUES BIG PREY | rule | 0.08 | 0.06 | 171.8 |
| BEST PRIZE | rule | - | 0.11 | 42.3 |
| CARRIES OUT SET-UP | rule | 0.03 | 0.06 | 83.4 |
| CARRIES OUT COUNTER | rule | 0.06 | - | 257.4 |
| FALLBACK | gate | 0.06 | - | 23.4 |
| MARCH ODDS | rule | - | 0.06 | 12.8 |
| NO REASON | gate | - | 0.06 | 49.1 |
| REDIRECT WEIGHED | rule | - | 0.06 | 25.5 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.03 | - | 14.0 |
| REFUSING RETIRES | rule | 0.03 | - | 0.7 |
| RULE SWITCHED OFF | gate | 0.03 | - | 32.5 |
| WHO HITS BACK | rule | - | 0.03 | 1.7 |

### Plans: h3-opp-efe7e34-p2

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 2.8 | 57% | 600 | 270 | 45% |
| Mine | join | 0.5 | 94% | 25 | 0 | 0% |
| Mine | move | 28.1 | 95% | 1824 | 0 | 0% |
| Mine | shoot | 8.3 | 60% | 421 | 648 | 154% |
| Mine | support | 0.1 | 80% | 2 | 0 | 0% |
| Opponent | charge | 3.4 | 55% | 538 | 340 | 63% |
| Opponent | join | 0.4 | 100% | 18 | 0 | 0% |
| Opponent | move | 29.8 | 93% | 1721 | 0 | 0% |
| Opponent | shoot | 3.3 | 53% | 109 | 145 | 133% |
| Opponent | support | 0.7 | 62% | 18 | 0 | 0% |

### Packages: hunt the guns, h3-opp-efe7e34-p2

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.0 | 1 | 0 | 100% | 100% | 0% | 2.0 | 244 | 239 | 100% | 28 |
| Opponent | 0.0 | 1 | 0 | 100% | 100% | 0% | 2.0 | 182 | 153 | 100% | 73 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 13 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 145 |
| Dwarfen Mountain Holds | 0.2 | 1 | 0 | 100% | 100% | 0% | 2.0 | 244 | 239 | 100% | 60 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 19 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 48 |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 264 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 108 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Tomb Kings of Khemri | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Vampire Counts | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 15 |
| Warriors of Chaos | 0.1 | 1 | 0 | 100% | 100% | 0% | 2.0 | 182 | 153 | 100% | 0 |
| Wood Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 62 |

### Battle groups: h3-opp-efe7e34-p2

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 2.2 | 40% | 72% | 0% | - | 12% | 0% | 9% | 75% | 3% |
| Opponent | REDIRECT COUNTER | 3.7 | 21% | 64% | 11% | 0% | 24% | 0% | 8% | 68% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: h3-opp-efe7e34-p2

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 4 | 0 (4) | 0 | 0 | 62 | 25% | 4.0 | - | 0 (1) | - | - | 0 (1) |
| Mine | Chaff | 33 | 87 (33) | 8 | 79 | 40 | 33% | 2.5 | 151 (7) | 97 (17) | 25 (9) | 116 (23) | 24 (10) |
| Mine | Character | 121 | 41 (121) | 41 | 0 | 28 | 21% | 2.5 | 32 (37) | 50 (49) | 43 (22) | 48 (51) | 36 (57) |
| Mine | Clean-up | 25 | 58 (25) | 18 | 40 | 44 | 48% | 3.3 | 95 (5) | 78 (13) | 14 (7) | 66 (16) | 49 (9) |
| Mine | Fast Hammer | 39 | 36 (39) | 17 | 19 | 51 | 28% | 2.6 | 36 (15) | 35 (20) | 46 (4) | 37 (23) | 35 (16) |
| Mine | Hammer | 57 | 38 (57) | 23 | 15 | 30 | 28% | 2.2 | 39 (12) | 50 (30) | 17 (15) | 51 (23) | 31 (34) |
| Mine | Holder | 24 | 70 (24) | 9 | 61 | 37 | 42% | 4.1 | 111 (5) | 68 (14) | 43 (5) | 99 (12) | 36 (12) |
| Mine | Shooter | 45 | 75 (45) | 19 | 56 | 32 | 2% | 1.8 | 83 (11) | 73 (23) | 68 (11) | 101 (31) | 26 (14) |
| Mine | Support | 2 | 0 (2) | 0 | 0 | 0 | 50% | 5.0 | 0 (1) | - | 0 (1) | 0 (1) | 0 (1) |
| Mine | War machine | 56 | 39 (56) | 39 | 0 | 41 | 5% | 1.4 | 68 (21) | 12 (17) | 34 (18) | 17 (9) | 43 (47) |
| Mine | Wizard | 15 | 33 (15) | 33 | 0 | 9 | 27% | 2.9 | 129 (4) | 17 (7) | 0 (2) | 260 (1) | 27 (12) |
| Opponent | Chaff | 72 | 105 (72) | 12 | 93 | 49 | 36% | 2.8 | 96 (25) | 204 (19) | 47 (28) | 87 (55) | 155 (17) |
| Opponent | Character | 106 | 47 (106) | 47 | 0 | 20 | 24% | 2.7 | 38 (29) | 51 (50) | 57 (20) | 51 (64) | 44 (35) |
| Opponent | Clean-up | 13 | 38 (13) | 16 | 22 | 53 | 38% | 2.2 | 63 (3) | 34 (9) | 0 (1) | 47 (10) | 0 (3) |
| Opponent | Early | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Fast | 1 | 0 (1) | 0 | 0 | 100 | 0% | 5.0 | - | 0 (1) | - | 0 (1) | - |
| Opponent | Fast Hammer | 66 | 46 (66) | 28 | 18 | 43 | 38% | 3.3 | 50 (21) | 45 (35) | 39 (10) | 56 (39) | 32 (27) |
| Opponent | Fragile | 1 | 0 (1) | 0 | 0 | 0 | 0% | 1.0 | - | 0 (1) | - | 0 (1) | - |
| Opponent | Hammer | 36 | 40 (36) | 15 | 25 | 28 | 39% | 2.8 | 21 (5) | 31 (21) | 66 (10) | 32 (22) | 52 (14) |
| Opponent | Holder | 27 | 99 (27) | 6 | 93 | 20 | 52% | 2.5 | 97 (7) | 106 (16) | 72 (4) | 125 (11) | 81 (16) |
| Opponent | Shooter | 21 | 87 (21) | 30 | 57 | 39 | 5% | 1.8 | 90 (8) | 143 (6) | 42 (7) | 79 (10) | 95 (11) |
| Opponent | Support | 4 | 0 (4) | 0 | 0 | 0 | 100% | - | - | 0 (2) | 0 (2) | 0 (1) | 0 (3) |
| Opponent | War machine | 23 | 35 (23) | 35 | 0 | 35 | 13% | 2.2 | 80 (9) | 0 (7) | 16 (7) | 0 (6) | 45 (17) |
| Opponent | Wizard | 29 | 7 (29) | 7 | 0 | 43 | 10% | 2.5 | 16 (7) | 9 (8) | 2 (7) | 3 (12) | 16 (10) |

### Charged fights: h3-opp-efe7e34-p2

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 118 | 42 | 1.5 | 1.2 | 28 | 0 | +28 | 1 of 6 | 4 of 6 | +0 | +34 |
| Mine | Chaos Dwarfs | 4 | 272 | 75 | 1.5 | 1.2 | 50 | 87 | -38 | 3 of 6 | 5 of 6 | -120 | -21 |
| Mine | Dwarfen Mountain Holds | 4 | 548 | 58 | 1.5 | 1.0 | 39 | 21 | +18 | 3 of 6 | 4 of 6 | - | +18 |
| Mine | Empire of Man | 4 | 556 | 187 | 1.8 | 1.3 | 107 | 0 | +107 | 3 of 7 | 6 of 7 | +98 | +110 |
| Mine | Grand Cathay | 5 | 404 | 337 | 3.6 | 1.2 | 94 | 43 | +51 | 6 of 18 | 11 of 18 | +105 | +40 |
| Mine | High Elf Realms | 4 | 53 | 456 | 3.2 | 1.2 | 140 | 76 | +64 | 6 of 13 | 11 of 13 | -395 | +102 |
| Mine | Kingdom of Bretonnia | 1 | 0 | 458 | 2.0 | 1.0 | 229 | 0 | +229 | 1 of 2 | 2 of 2 | - | +229 |
| Mine | Lizardmen | 1 | 0 | 527 | 5.0 | 1.0 | 105 | 0 | +105 | 0 of 5 | 5 of 5 | - | +105 |
| Mine | Ogre Kingdoms | 1 | 60 | 345 | 5.0 | 1.2 | 69 | 14 | +55 | 1 of 5 | 3 of 5 | +0 | +69 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 539 | 6.0 | 1.0 | 90 | 9 | +81 | 4 of 6 | 3 of 6 | - | +81 |
| Mine | Skaven | 2 | 0 | 0 | 1.5 | 1.0 | 0 | 14 | -14 | 0 of 3 | 3 of 3 | - | -14 |
| Mine | Tomb Kings of Khemri | 1 | 60 | 863 | 4.0 | 1.0 | 216 | 0 | +216 | 3 of 4 | 2 of 4 | - | +216 |
| Mine | Vampire Counts | 2 | 142 | 455 | 6.0 | 1.4 | 76 | 46 | +30 | 6 of 12 | 8 of 12 | +145 | -52 |
| Mine | Warriors of Chaos | 2 | 0 | 173 | 2.0 | 1.0 | 86 | 0 | +86 | 1 of 4 | 3 of 4 | - | +86 |
| **Mine** | all armies | 36 | 239 | 249 | 2.7 | 1.2 | 92 | 32 | +60 | 38 of 97 | 70 of 97 | +52 | +62 |
| Opponent | Empire of Man | 3 | 73 | 46 | 1.7 | 1.2 | 27 | 101 | -73 | 2 of 5 | 3 of 5 | +0 | -92 |
| Opponent | Grand Cathay | 3 | 363 | 215 | 3.0 | 1.0 | 72 | 0 | +72 | 3 of 9 | 6 of 9 | - | +72 |
| Opponent | High Elf Realms | 2 | 291 | 58 | 1.5 | 1.0 | 39 | 0 | +39 | 0 of 3 | 2 of 3 | - | +39 |
| Opponent | Kingdom of Bretonnia | 1 | 0 | 259 | 4.0 | 1.2 | 65 | 0 | +65 | 0 of 4 | 3 of 4 | +199 | +20 |
| Opponent | Ogre Kingdoms | 1 | 60 | 0 | 3.0 | 1.0 | 0 | 11 | -11 | 3 of 3 | 0 of 2 | - | -11 |
| Opponent | Orc & Goblin Tribes | 3 | 0 | 248 | 2.0 | 1.0 | 124 | 9 | +115 | 2 of 6 | 4 of 6 | - | +115 |
| Opponent | Tomb Kings of Khemri | 3 | 69 | 645 | 3.3 | 1.1 | 193 | 50 | +144 | 5 of 10 | 9 of 10 | +77 | +151 |
| Opponent | Vampire Counts | 6 | 0 | 353 | 3.5 | 1.3 | 101 | 23 | +77 | 7 of 21 | 16 of 21 | +70 | +80 |
| Opponent | Warriors of Chaos | 12 | 15 | 473 | 3.1 | 1.2 | 153 | 21 | +132 | 18 of 37 | 29 of 37 | +285 | +108 |
| Opponent | Wood Elf Realms | 2 | 174 | 278 | 4.0 | 1.0 | 70 | 0 | +70 | 4 of 8 | 6 of 7 | - | +70 |
| **Opponent** | all armies | 36 | 74 | 339 | 2.9 | 1.1 | 115 | 22 | +93 | 44 of 106 | 78 of 104 | +152 | +84 |

### Effective charges: h3-opp-efe7e34-p2

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 6 | 3 (net +37) | 0 | 1 (net +0) | 0 | 0 | 2 (net +30) | 0 | 17% (1 of 6) |
| Mine | Chaos Dwarfs | 6 | 0 | 0 | 1 (net -339) | 3 (net +23) | 2 (net +22) | 0 | 0 | 17% (1 of 6) |
| Mine | Dwarfen Mountain Holds | 6 | 1 (net -60) | 0 | 3 (net +78) | 0 | 0 | 1 (net +0) | 1 | 60% (3 of 5) |
| Mine | Empire of Man | 7 | 0 | 0 | 2 (net +98) | 2 (net +82) | 1 (net +55) | 2 (net +166) | 0 | 29% (2 of 7) |
| Mine | Grand Cathay | 18 | 4 (net +65) | 0 | 3 (net +105) | 4 (net +31) | 3 (net +20) | 4 (net +39) | 0 | 17% (3 of 18) |
| Mine | High Elf Realms | 13 | 0 | 2 (net -100) | 2 (net -15) | 2 (net +118) | 1 (net +0) | 6 (net +138) | 0 | 15% (2 of 13) |
| Mine | Kingdom of Bretonnia | 2 | 0 | 0 | 0 | 0 | 0 | 2 (net +229) | 0 | 0% (0 of 2) |
| Mine | Lizardmen | 5 | 0 | 0 | 0 | 2 (net +61) | 0 | 2 (net +188) | 1 | 0% (0 of 4) |
| Mine | Ogre Kingdoms | 5 | 0 | 1 (net -68) | 1 (net +0) | 0 | 1 (net +45) | 2 (net +150) | 0 | 20% (1 of 5) |
| Mine | Orc & Goblin Tribes | 6 | 2 (net +0) | 0 | 0 | 0 | 1 (net +111) | 0 | 3 | 0% (0 of 3) |
| Mine | Skaven | 3 | 0 | 0 | 0 | 1 (net -41) | 0 | 2 (net +0) | 0 | 0% (0 of 3) |
| Mine | Tomb Kings of Khemri | 4 | 1 (net +0) | 0 | 2 (net +432) | 0 | 0 | 1 (net +0) | 0 | 50% (2 of 4) |
| Mine | Vampire Counts | 12 | 5 (net +45) | 0 | 1 (net +0) | 2 (net +0) | 1 (net +41) | 2 (net +49) | 1 | 9% (1 of 11) |
| Mine | Warriors of Chaos | 4 | 1 (net +122) | 0 | 0 | 1 (net +115) | 1 (net +109) | 0 | 1 | 0% (0 of 3) |
| Opponent | Empire of Man | 5 | 2 (net -132) | 0 | 0 | 2 (net +42) | 1 (net -186) | 0 | 0 | 0% (0 of 5) |
| Opponent | Grand Cathay | 9 | 1 (net +0) | 0 | 3 (net +85) | 3 (net +118) | 0 | 1 (net +0) | 1 | 38% (3 of 8) |
| Opponent | High Elf Realms | 3 | 0 | 1 (net +0) | 0 | 2 (net +58) | 0 | 0 | 0 | 0% (0 of 3) |
| Opponent | Kingdom of Bretonnia | 4 | 0 | 0 | 1 (net +0) | 2 (net +100) | 0 | 1 (net +60) | 0 | 25% (1 of 4) |
| Opponent | Ogre Kingdoms | 3 | 1 (net +0) | 0 | 1 (net +0) | 0 | 0 | 0 | 1 | 50% (1 of 2) |
| Opponent | Orc & Goblin Tribes | 6 | 0 | 1 (net +0) | 0 | 0 | 1 (net +147) | 1 (net +227) | 3 | 0% (0 of 3) |
| Opponent | Tomb Kings of Khemri | 10 | 3 (net +62) | 0 | 0 | 0 | 3 (net +77) | 3 (net +319) | 1 | 0% (0 of 9) |
| Opponent | Vampire Counts | 21 | 3 (net -20) | 2 (net +174) | 5 (net +81) | 2 (net +40) | 5 (net +157) | 3 (net +23) | 1 | 25% (5 of 20) |
| Opponent | Warriors of Chaos | 37 | 12 (net +19) | 0 | 2 (net +313) | 7 (net +237) | 3 (net +307) | 8 (net +116) | 5 | 6% (2 of 32) |
| Opponent | Wood Elf Realms | 8 | 1 (net +0) | 0 | 1 (net +0) | 2 (net +192) | 1 (net +173) | 1 (net +0) | 2 | 17% (1 of 6) |

### Charged fights, damage counted: h3-opp-efe7e34-p2

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 17 | 282 | 285 | +39 | 118 | 62 | +56 | +19.8 |
| Mine | 50-54% | 3 | 343 | 340 | -90 | 215 | 240 | -25 | -7.3 |
| Mine | Effective (55-75%) | 16 | 348 | 258 | +77 | 171 | 76 | +96 | +27.5 |
| Mine | 76-89% | 17 | 250 | 205 | +46 | 124 | 73 | +51 | +20.4 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 26 | 270 | 151 | +100 | 140 | 0 | +140 | +51.9 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 11 | 386 | 82 | +42 | 51 | 12 | +39 | +10.0 |
| Mine | No odds | 7 | 193 | 346 | +48 | 82 | 42 | +39 | +20.4 |
| Mine | All fights | 97 | 291 | 214 | +60 | 127 | 48 | +78 | +27.0 |
| Opponent | Long shot (under 50%) | 23 | 250 | 298 | +4 | 71 | 89 | -18 | -7.1 |
| Opponent | 50-54% | 4 | 210 | 195 | +87 | 115 | 0 | +115 | +54.8 |
| Opponent | Effective (55-75%) | 13 | 292 | 175 | +99 | 118 | 4 | +114 | +39.0 |
| Opponent | 76-89% | 20 | 374 | 179 | +144 | 154 | 33 | +121 | +32.4 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 18 | 294 | 171 | +124 | 169 | 70 | +99 | +33.6 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 14 | 529 | 107 | +148 | 166 | 34 | +133 | +25.1 |
| Opponent | No odds | 14 | 208 | 181 | +65 | 112 | 34 | +77 | +37.2 |
| Opponent | All fights | 106 | 316 | 194 | +93 | 129 | 47 | +82 | +25.9 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| h3-opp-efe7e34-p2 | move | 294 | 61 (21%) | 43 (15%) | 39 (13%) | 194 (66%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0108, L0123, L2430, L2628 |
| Charmed Shield | Opponent | L0224, L0325, L0427, L1027, L1827, L2324, L3034 |
| Clockwork Compass | Mine | L1213, L1230 |
| Clockwork Compass | Opponent | L0812 |
| Elixir of Power | Mine | L1119, L1928 |
| Elixir of Power | Opponent | L0411, L0919, L1011, L1119, L1419 |
| Fistful of Laurels | Mine | L1827 |
| Fistful of Laurels | Opponent | L0618 |
| Horn of the Wild Hunt | Opponent | L0633 |
| Invocation of Nehek | Mine | L2430 |
| Invocation of Nehek | Opponent | L0224, L0325, L0427, L1027, L1827, L2324 |
| Opal Amulet | Mine | L1419 |
| Periapt of Soul Exchange | Mine | L2030, L2132 |
| Ring of Doom | Mine | L0207, L0224, L1119, L1213, L1230, L1516, L1532 |
| Ring of Doom | Opponent | L0411, L0633, L0812, L1011 |
| Ring of Jet | Mine | L1011, L1027, L1119, L1213, L1230 |
| Ring of Jet | Opponent | L0411, L0812, L1011 |
| Standard of the Fell Warrior | Mine | L1323 |
| Standard of the Fell Warrior | Opponent | L0513, L1213 |
| Storm Daemon (Renegade 2.0) | Mine | L2132 |
| Twice-Blessed Armour | Mine | L0722, L1011, L1027 |
| Twice-Blessed Armour | Opponent | L0207 |
| Witch Hunter's Ward | Mine | L0722, L0812, L0828 |
| Witch Hunter's Ward | Opponent | L0108, L0207, L0308 |

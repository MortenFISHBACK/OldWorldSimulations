# Doctrine scorecard: h3-opp-efe7e34-p4

### Scorecard: h3-opp-efe7e34-p4

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0115 | 1 | 1 | Mine | yes | 8 | - | 0 | 0 | 0 | 0 | 0 | 0 |
| L0115 | 1 | 1 | Opponent | yes | 7 | 2 | 5 | 1 | 1 | 0 | 0 | 0 |
| L0132 | 6 | 1 | Mine | no | 11 | - | 0 | 1 | 0 | 0 | 0 | 0 |
| L0132 | 6 | 1 | Opponent | no | 2 | 3 | 4 | 6 | 1 | 0 | 0 | 340 |
| L0216 | 6 | 1 | Mine | no | 2 | 5 | 2 | 3 | 0 | 0 | 0 | 0 |
| L0216 | 6 | 1 | Opponent | no | 5 | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L0232 | 4 | 1 | Mine | no | 4 | 5 | 3 | 2 | 1 | 0 | 0 | 170 |
| L0232 | 4 | 1 | Opponent | no | 0 | 2 | 3 | 3 | 0 | 0 | 0 | 170 |
| L0316 | 4 | 1 | Mine | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 370 |
| L0316 | 4 | 1 | Opponent | no | 0 | 2 | 1 | 2 | 2 | 0 | 0 | 200 |
| L0333 | 3 | 1 | Mine | no | 0 | 5 | 0 | 0 | 0 | 0 | 0 | 110 |
| L0333 | 3 | 1 | Opponent | no | 2 | 2 | 1 | 3 | 0 | 0 | 0 | 424 |
| L0420 | 6 | 1 | Mine | no | 3 | 3 | 2 | 2 | 0 | 0 | 0 | 65 |
| L0420 | 6 | 1 | Opponent | no | 5 | - | 2 | 1 | 0 | 0 | 0 | 420 |
| L0435 | 3 | 1 | Mine | no | 1 | 4 | 2 | 1 | 0 | 0 | 0 | 0 |
| L0435 | 3 | 1 | Opponent | no | 5 | 3 | 6 | 1 | 0 | 0 | 0 | 0 |
| L0522 | 6 | 1 | Mine | no | 4 | - | 0 | 2 | 0 | 0 | 0 | 328 |
| L0522 | 6 | 1 | Opponent | no | 9 | 2 | 3 | 2 | 0 | 0 | 0 | 72 |
| L0609 | 3 | 1 | Mine | no | 0 | - | 0 | 4 | 0 | 0 | 0 | 180 |
| L0609 | 3 | 1 | Opponent | yes | 6 | - | 0 | 1 | 0 | 0 | 0 | 0 |
| L0625 | 1 | 1 | Mine | yes | 3 | 6 | 1 | 0 | 0 | 0 | 0 | 275 |
| L0625 | 1 | 1 | Opponent | no | 0 | 2 | 2 | 5 | 0 | 0 | 0 | 0 |
| L0714 | 6 | 1 | Mine | no | 10 | 2 | 3 | 0 | 0 | 0 | 0 | 0 |
| L0714 | 6 | 1 | Opponent | no | 2 | 2 | 2 | 2 | 0 | 0 | 0 | 0 |
| L0730 | 4 | 1 | Mine | no | 5 | 2 | 3 | 1 | 0 | 0 | 0 | 125 |
| L0730 | 4 | 1 | Opponent | no | 0 | 2 | 6 | 1 | 0 | 0 | 0 | 0 |
| L0820 | 4 | 1 | Mine | no | 1 | 4 | 1 | 1 | 0 | 0 | 0 | 175 |
| L0820 | 4 | 1 | Opponent | no | 1 | 4 | 1 | 5 | 1 | 0 | 0 | 420 |
| L0910 | 4 | 1 | Mine | no | 4 | 4 | 2 | 0 | 0 | 0 | 0 | 354 |
| L0910 | 4 | 1 | Opponent | no | 11 | 2 | 3 | 0 | 0 | 0 | 0 | 501 |
| L0927 | 3 | 1 | Mine | no | 2 | 2 | 0 | 1 | 0 | 0 | 0 | 418 |
| L0927 | 3 | 1 | Opponent | no | 0 | 1 | 3 | 2 | 0 | 0 | 0 | 0 |
| L1020 | 6 | 1 | Mine | no | 14 | 3 | 3 | 0 | 0 | 0 | 0 | 165 |
| L1020 | 6 | 1 | Opponent | no | 4 | - | 2 | 2 | 0 | 0 | 0 | 0 |
| L1035 | 3 | 1 | Mine | no | 11 | 1 | 4 | 0 | 0 | 0 | 0 | 0 |
| L1035 | 3 | 1 | Opponent | no | 1 | 2 | 3 | 3 | 0 | 0 | 0 | 0 |
| L1128 | 6 | 1 | Mine | no | 0 | 2 | 2 | 0 | 0 | 0 | 0 | 0 |
| L1128 | 6 | 1 | Opponent | no | 5 | 4 | 1 | 1 | 0 | 0 | 0 | 0 |
| L1221 | 3 | 1 | Mine | no | 8 | 2 | 6 | 0 | 0 | 0 | 0 | 0 |
| L1221 | 3 | 1 | Opponent | yes | 7 | - | 0 | 4 | 0 | 0 | 0 | 290 |
| L1315 | 1 | 1 | Mine | yes | 1 | 3 | 6 | 0 | 0 | 0 | 0 | 70 |
| L1315 | 1 | 1 | Opponent | no | 1 | 5 | 2 | 1 | 0 | 0 | 0 | 0 |
| L1332 | 6 | 1 | Mine | no | 9 | 6 | 1 | 0 | 0 | 0 | 0 | 140 |
| L1332 | 6 | 1 | Opponent | no | 1 | 5 | 1 | 2 | 0 | 0 | 0 | 0 |
| L1428 | 6 | 1 | Mine | no | 17 | 3 | 4 | 1 | 0 | 0 | 0 | 177 |
| L1428 | 6 | 1 | Opponent | no | 0 | - | 0 | 1 | 1 | 0 | 0 | 0 |
| L1524 | 6 | 1 | Mine | no | 0 | 2 | 7 | 0 | 1 | 0 | 0 | 0 |
| L1524 | 6 | 1 | Opponent | no | 14 | 3 | 4 | 0 | 0 | 0 | 0 | 343 |
| L1622 | 2 | 1 | Mine | - | - | 2 | 5 | 1 | 1 | 0 | 0 | 200 |
| L1622 | 2 | 1 | Opponent | - | - | 1 | 4 | 0 | 0 | 0 | 0 | 55 |
| L1720 | 4 | 1 | Mine | no | 3 | 2 | 5 | 2 | 0 | 0 | 0 | 350 |
| L1720 | 4 | 1 | Opponent | no | 0 | - | 1 | 1 | 1 | 0 | 0 | 420 |
| L1820 | 2 | 1 | Mine | - | - | 6 | 2 | 0 | 0 | 0 | 0 | 0 |
| L1820 | 2 | 1 | Opponent | - | - | 5 | 2 | 3 | 0 | 0 | 0 | 210 |
| L1920 | 6 | 1 | Mine | no | 2 | 2 | 7 | 2 | 0 | 0 | 0 | 235 |
| L1920 | 6 | 1 | Opponent | no | 0 | - | 0 | 0 | 1 | 0 | 0 | 485 |
| L2022 | 6 | 1 | Mine | no | 2 | - | 1 | 0 | 0 | 0 | 0 | 420 |
| L2022 | 6 | 1 | Opponent | no | 6 | 1 | 5 | 0 | 0 | 0 | 0 | 0 |
| L2125 | 1 | 1 | Mine | no | 0 | 5 | 2 | 4 | 0 | 0 | 0 | 145 |
| L2125 | 1 | 1 | Opponent | no | 0 | 6 | 0 | 1 | 0 | 0 | 0 | 0 |
| L2228 | 2 | 1 | Mine | - | - | 1 | 2 | 4 | 0 | 0 | 0 | 0 |
| L2228 | 2 | 1 | Opponent | - | - | - | 0 | 1 | 1 | 0 | 0 | 519 |
| L2332 | 4 | 1 | Mine | no | 0 | 3 | 8 | 0 | 1 | 0 | 0 | 245 |
| L2332 | 4 | 1 | Opponent | no | 2 | 1 | 5 | 2 | 0 | 0 | 0 | 170 |
| L2528 | 2 | 1 | Mine | - | - | 5 | 2 | 5 | 0 | 0 | 0 | 0 |
| L2528 | 2 | 1 | Opponent | - | - | - | 0 | 2 | 0 | 0 | 0 | 0 |
| L2635 | 1 | 1 | Mine | yes | 9 | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L2635 | 1 | 1 | Opponent | yes | 0 | 1 | 2 | 0 | 0 | 0 | 0 | 102 |
| L2931 | 3 | 1 | Mine | no | 0 | 2 | 4 | 2 | 1 | 0 | 0 | 170 |
| L2931 | 3 | 1 | Opponent | no | 12 | 3 | 2 | 0 | 1 | 0 | 0 | 340 |
| L3334 | 4 | 1 | Mine | no | 4 | 2 | 2 | 1 | 0 | 0 | 0 | 405 |
| L3334 | 4 | 1 | Opponent | no | 0 | 2 | 2 | 6 | 0 | 0 | 0 | 214 |
| **Average** | | | Mine | 12% | 4.3 | 3.2 | 2.6 | 1.2 | 0.1 | 0.0 | 0.0 | 147.0 |
| **Average** | | | Opponent | 12% | 3.4 | 2.6 | 2.2 | 1.8 | 0.3 | 0.0 | 0.0 | 158.2 |

### KPIs: h3-opp-efe7e34-p4

Rules off - Mine only: HOLDER ASSIGNMENT.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 30% (51 of 170) | 1% (1 of 177) | 15% (52 of 347) |
| Winner chose to follow up after the loser gave ground |  | 73% (33 of 45); on the table 82% | 77% (27 of 35); on the table 89% | 75% (60 of 80); on the table 85% |
| Winner chose to pursue after the loser fell back in good order |  | 100% (4 of 4); on the table 100% | 75% (6 of 8); on the table 75% | 83% (10 of 12); on the table 83% |
| Winner chose to pursue after the loser fled |  | 80% (20 of 25); on the table 84% | 81% (25 of 31); on the table 84% | 80% (45 of 56); on the table 84% |
| Winner chose to follow up or pursue (all three) |  | 77% (57 of 74); on the table 84% | 78% (58 of 74); on the table 85% | 78% (115 of 148); on the table 84% |
| Magic missiles tried each own turn | 50%+ | 31% (102 of 334) | 32% (58 of 182) | 31% (160 of 516) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 38% (102 of 265) | 41% (58 of 142) | 39% (160 of 407) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 72% (18 of 25) | 55% (55 of 100) | 58% (73 of 125) |
| Points that never fought | lower | 41% (28779 of 70036) | 38% (27559 of 71981) | 40% (56338 of 142017) |
|   infantry points that never fought | lower | 54% (8620 of 16041) | 68% (9974 of 14728) | 60% (18594 of 30769) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 53% (150 of 281) | 61% (171 of 280) | 57% (321 of 561) |
| Bound items with a magic missile used (at least once a game) |  | 96% (22 of 23); 2.3 uses a game | 69% (9 of 13); 0.8 uses a game | 86% (31 of 36); 1.6 uses a game |
| Bound items with another spell used |  | 31% (5 of 16); 0.2 uses a game | 0% (0 of 7); 0.0 uses a game | 22% (5 of 23); 0.1 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 50% (10 of 20); 0.3 uses a game | 62% (8 of 13); 0.2 uses a game | 55% (18 of 33); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 46% (27473 of 59592) | 58% (36808 of 63783) | 52% (64281 of 123375) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 2.1 (32%) | 1.2 (35%) | 3.3 (33%) |
| MARCHED: its unit marched | 1.6 (24%) | 0.9 (27%) | 2.5 (25%) |
| CHARGED: its unit charged | 0.3 (4%) | 0.1 (4%) | 0.4 (4%) |
| IN COMBAT: engaged in combat | 1.3 (21%) | 0.3 (8%) | 1.6 (16%) |
| REAR RANK: in a rear rank | 0.4 (6%) | 0.0 (0%) | 0.4 (4%) |
| FLEEING: fleeing | 0.1 (1%) | 0.0 (1%) | 0.1 (1%) |
| GONE: slain | 0.3 (4%) | 0.5 (15%) | 0.8 (8%) |
| OFF THE TABLE: off the table or not arrived | 0.2 (3%) | 0.3 (8%) | 0.5 (5%) |
| STUPIDITY: Stupidity | 0.1 (1%) | 0.1 (2%) | 0.1 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| NOT OFFERED: not in the cast list | 0.1 (2%) | 0.0 (0%) | 0.1 (1%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.9 | 1.7 | 2.1 | 4.4 | 0.2 | 1.3 |
| not cast | 4.2 | 1.9 | 3.1 | 9.9 | 1.8 | 22.1 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.3 (6%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.0 (51%) | 0.3 (11%) | 3.3 (33%) | 0.7 (41%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.5 (25%) | 0.3 (16%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.4 (4%) | 0.1 (8%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.1 (2%) | 0.0 (0%) | 0.6 (19%) | 1.6 (16%) | 0.2 (14%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.2 (4%) | 0.2 (9%) | 0.2 (5%) | 0.4 (4%) | 0.0 (0%) | 0.0 (0%) |
| NO CASTS LEFT: every cast used on other spells | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (2%) | 0.0 (0%) |
| FLEEING: fleeing | 0.1 (1%) | 0.0 (0%) | 0.0 (1%) | 0.1 (1%) | 0.0 (0%) | 0.3 (1%) |
| GONE: slain | 0.8 (20%) | 0.1 (6%) | 0.3 (9%) | 0.8 (8%) | 0.0 (0%) | 1.1 (5%) |
| OFF THE TABLE: off the table or not arrived | 0.4 (9%) | 0.2 (10%) | 0.1 (4%) | 0.5 (5%) | 0.1 (6%) | 1.0 (5%) |
| STUPIDITY: Stupidity | 0.2 (5%) | 0.0 (0%) | 0.1 (4%) | 0.1 (1%) | 0.0 (0%) | 0.2 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.2 (5%) | 0.1 (7%) | 0.0 (1%) | 0.1 (1%) | 0.2 (14%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.3 (55%) | 0.3 (17%) | 1.4 (46%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 18.1 (82%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.3 a game | 0.9 a game | 1.1 a game |
| stood (cast and not dispelled) | 59% (26 of 44) | 69% (18 of 26) | 63% (44 of 70) |
| the unit moved after it | 73% (19 of 26) | 72% (13 of 18) | 73% (32 of 44) |
| it charged on its next turn | 4% (1 of 26) | 11% (2 of 18) | 7% (3 of 44) |
| the enemy charged it first | 19% (5 of 26) | 11% (2 of 18) | 16% (7 of 44) |
| it fought by the end of its next turn | 8% (2 of 26) | 6% (1 of 18) | 7% (3 of 44) |
| it moved out of a charge the enemy had planned (not charged first) | 12% (3 of 26) | 0% (0 of 18) | 7% (3 of 44) |
| none of these (no charge, no fight, no charge escaped) | 65% (17 of 26) | 78% (14 of 18) | 70% (31 of 44) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 60% (562 of 937) | 52% (312 of 604) | 57% (874 of 1541) |
|   cavalry | 67% (58 of 87) | 61% (67 of 109) | 64% (125 of 196) |
|   character | 50% (54 of 109) | 25% (30 of 118) | 37% (84 of 227) |
|   chariot | 65% (75 of 115) | 62% (26 of 42) | 64% (101 of 157) |
|   infantry | 52% (158 of 305) | 57% (166 of 289) | 55% (324 of 594) |
|   monster | 44% (23 of 52) | 33% (2 of 6) | 43% (25 of 58) |
|   war machine | 72% (194 of 269) | 52% (21 of 40) | 70% (215 of 309) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.2 (22%) | 2.0 (24%) | 4.2 (23%) |
| CHARGED: it charged | 0.9 (9%) | 1.5 (18%) | 2.4 (13%) |
| FLEEING: it fled or was fleeing | 0.1 (1%) | 0.1 (1%) | 0.2 (1%) |
| IN COMBAT: it fought this turn or the last | 0.6 (6%) | 0.2 (2%) | 0.8 (4%) |
| MOVED: a war machine that moved | 1.2 (11%) | 0.2 (3%) | 1.4 (8%) |
| NO TARGET IN RANGE | 3.3 (31%) | 2.1 (25%) | 5.3 (29%) |
| ONLY IN COMBAT: the only targets were in combat | 0.4 (4%) | 0.4 (4%) | 0.8 (4%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.2 (12%) | 1.6 (20%) | 2.8 (15%) |
| SHELTERED: the target was sheltered | 0.2 (2%) | 0.1 (1%) | 0.2 (1%) |
| OTHER BAR | 0.2 (2%) | 0.0 (0%) | 0.2 (1%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 4.8 | 1.1 | 81% | 4.1 pts | 20 pts |
| character | 2.8 | 1.0 | 77% | 4.9 pts | 14 pts |
| chariot | 2.8 | 1.3 | 73% | 15.3 pts | 43 pts |
| infantry | 12.3 | 4.4 | 73% | 8.8 pts | 109 pts |
| monster | 0.9 | 0.2 | 85% | 1.4 pts | 1 pts |
| war machine | 6.0 | 4.9 | 62% | 21.3 pts | 127 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.7 | 3.9 | 3.8 |
| Charges that made contact a game | 2.7 | 3.1 | 2.9 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.17 declared, 0.87 contact (23 units) | 0.53 declared, 0.35 contact (17 units) | 0.90 declared, 0.65 contact (40 units) |
|   per unit a game, units carrying another wizard (or one alone) | 1.20 declared, 0.80 contact (5 units) | 0.67 declared, 0.67 contact (6 units) | 0.91 declared, 0.73 contact (11 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.39 declared, 0.28 contact (258 units) | 0.43 declared, 0.34 contact (297 units) | 0.41 declared, 0.31 contact (555 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 40% (29 of 73) | 43% (6 of 14) | 77% (10 of 13) | 45% (45 of 100) |
| Character in a unit | 98% (39 of 40) | 63% (12 of 19) | 100% (2 of 2) | 87% (53 of 61) |
| Character on its own | 91% (21 of 23) | 48% (16 of 33) | 32% (23 of 73) | 47% (60 of 129) |
| Chariot | 62% (8 of 13) | 75% (9 of 12) | - | 68% (17 of 25) |
| Infantry | 47% (47 of 99) | 32% (10 of 31) | 0% (0 of 2) | 43% (57 of 132) |
| Monster | 76% (22 of 29) | 78% (14 of 18) | - | 77% (36 of 47) |
| Monstrous | 86% (12 of 14) | 75% (6 of 8) | - | 82% (18 of 22) |
| War Machines | 81% (35 of 43) | 0% (0 of 2) | - | 78% (35 of 45) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 100% (1 of 1); on the table 100% | 47% (48 of 102) | 28% | 59% (13 of 22) | 100% (6 of 6); 5.8 uses a game | 100% (2 of 2); 1.0 uses a game | 67% (4 of 6); 1.0 uses a game |
| Chaos Dwarfs | 4 | 90% (9 of 10); on the table 90% | 20% (6 of 30) | 54% | 44% (14 of 32) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
| Dwarfen Mountain Holds | 3 | 100% (1 of 1); on the table 100% | - | 67% | 74% (20 of 27) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 6 | 75% (3 of 4); on the table 100% | 39% (14 of 36) | 53% | 62% (41 of 66) | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game | 33% (1 of 3); 0.2 uses a game |
| Grand Cathay | 5 | 75% (6 of 8); on the table 88% | 28% (35 of 126) | 45% | 49% (23 of 47) | 100% (11 of 11); 8.4 uses a game | 0% (0 of 3); 0.0 uses a game | 0% (0 of 5); 0.0 uses a game |
| High Elf Realms | 7 | 82% (14 of 17); on the table 88% | 30% (9 of 30) | 35% | 38% (20 of 53) | 100% (8 of 8); 3.4 uses a game | 12% (2 of 16); 0.6 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 3 | 50% (3 of 6); on the table 50% | - | 57% | 33% (6 of 18) | 0.0 uses a game | 0.0 uses a game | 100% (3 of 3); 1.0 uses a game |
| Lizardmen | 1 | 100% (5 of 5); on the table 100% | - | 42% | 71% (5 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 1 | - | 0% (0 of 6) | 82% | 71% (5 of 7) | 100% (1 of 1); 4.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 1 | 100% (2 of 2); on the table 100% | 0% (0 of 12) | 15% | 75% (6 of 8) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Skaven | 9 | 71% (17 of 24); on the table 83% | 17% (10 of 60) | 44% | 64% (43 of 67) | 100% (2 of 2); 0.9 uses a game | 0.0 uses a game | 78% (7 of 9); 0.8 uses a game |
| Tomb Kings of Khemri | 5 | 74% (17 of 23); on the table 83% | 0% (0 of 6) | 33% | 40% (10 of 25) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 6 | 80% (12 of 15); on the table 87% | 40% (17 of 42) | 36% | 56% (20 of 36) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 11 | 71% (12 of 17); on the table 76% | 47% (17 of 36) | 22% | 60% (50 of 84) | 100% (1 of 1); 0.3 uses a game | 0.0 uses a game | 100% (1 of 1); 0.1 uses a game |
| Wood Elf Realms | 6 | 87% (13 of 15); on the table 87% | 13% (4 of 30) | 32% | 73% (45 of 62) | 29% (2 of 7); 1.5 uses a game | 0.0 uses a game | 0% (0 of 3); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (h3-opp-efe7e34-p4, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 55% (37) | 51% (35) | 53% (72) |
| ...free all their last turn and able to turn (per game) | 0.61 | 0.67 | 1.28 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.14 | 0.11 | 0.25 |
| ...with the charger already in that arc before they moved (per game) | 0.39 | 0.42 | 0.81 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.08 | 0.14 | 0.22 |

### Quality by phase: h3-opp-efe7e34-p4

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.1 | 2.0 |
| Strategy | Charge objectives carried out (made contact) | 49% (60 of 122) | 57% (74 of 130) |
| Strategy | Shoot objectives carried out (shot that target) | 35% (131 of 379) | 40% (45 of 113) |
| Strategy | Support requests answered (helper made contact too) | 56% (5 of 9) | 55% (6 of 11) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (3 of 3) | 100% (1 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | 57% (8 of 14) | 40% (4 of 10) |
| Strategy | Joined characters whose unit fought | 49% (27 of 55) | 38% (16 of 42) |
| Strategy | Lone characters that fought | 73% (58 of 79) | 79% (62 of 78) |
| Movement | Charges halted short of contact | 0.1 | 0.2 |
| Movement | Idle units | 1.2 | 1.8 |
| Movement | Points that never moved of their own | 147.0 | 158.2 |
| Movement | Fights charged into per game | 2.4 | 2.7 |
| Movement | Charges with odds: long shots (under 50%) | 17 of 77, net +175 | 20 of 91, net +37 |
| Movement | Charges with odds: sweet spot (55-75%) | 8 of 77, net +234 | 13 of 91, net +17 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 12 of 77, net +127 | 15 of 91, net +165 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 28 of 77, net +123 | 22 of 91, net +73 |
| Shooting | Shots by shooting units (incl. breath weapons) | 10.6 | 9.8 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 51% (193 of 382) | 46% (164 of 353) |
| Shooting | Points destroyed by shooting units | 29.8 | 45.6 |
| Shooting | War machine shots | 5.4 | 0.6 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 56% (109 of 194) | 29% (6 of 21) |
| Shooting | Points destroyed by war machines | 53.6 | 12.8 |
| Magic | Magic missiles cast | 1.8 | 1.0 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 35% (23 of 66) | 36% (13 of 36) |
| Magic | Wounds caused by magic missiles | 4.9 | 0.8 |
| Magic | Wounds caused by other spells | 1.3 | 0.3 |
| Magic | Points destroyed by magic (all spells) | 82.0 | 3.8 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.1 / 0.4 / 0.6 / 0.1 | 2.1 / 0.4 / 0.2 / 0.0 |
| Combat | Points destroyed in combat | 330.4 | 308.6 |
| Combat | Points run down | 67.0 | 26.5 |
| Combat | Net points per charged fight, damage counted | +106 | +81 |
| Combat | Net per 100 charger points, damage counted | +32.4 | +27.5 |
| Combat | First round won (charged fights) | 73% | 69% |
| Combat | Net points per charged fight | +121 | +70 |
| Combat | Net points per supported fight / lone fight | +383 / +87 | +142 / +63 |
| Combat | Charged fights on a top-3 enemy unit | 41 of 88 | 37 of 98 |
| Game | Points lost | 455.5 | 690.8 |
| Game | VP from objectives | 702.8 | 613.9 |
| Game | Lone holders (player turns) | 4.3 | 3.4 |

- Mine won / drew / lost: 16 / 9 / 11 of 36 ended games (of 36); mean margin (Mine - Opponent) +304 VP
- The side that went first won 10 of 27 games with a winner
- Points traded per game (both sides' losses): 1146
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: h3-opp-efe7e34-p4

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.8 | +0.0 | 0.0 | 0.0 | 0.8 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.3 | +21.0 | 0.0 | 11.8 | 0.2 | +9.3 | 0.0 | 22.9 |
| ALREADY CARRIED | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARTILLERY RE-ROLL WEIGHED | 1.1 | +0.0 | 0.0 | 13.8 | 0.2 | +0.0 | 0.0 | 4.6 |
| BACKUP TARGETS | 0.2 | +1.1 | 0.0 | 0.0 | 0.2 | +0.8 | 0.0 | 13.0 |
| BEST PRIZE | 0.0 | -0.7 | 0.0 | 2.9 | 0.1 | -3.9 | 12.1 | 0.0 |
| BLOWS WHERE AIMED | 0.2 | -39.0 | 62.7 | 0.0 | 0.2 | -39.0 | 16.1 | 0.0 |
| BOMBING RUN | 0.0 | +2.6 | 0.0 | 0.0 | - | - | - | - |
| CANNON PLAN MISSED | 0.6 | +0.0 | 61.9 | 11.0 | 0.1 | +0.0 | 12.8 | 3.5 |
| CANNON PLANNED TARGET | 4.6 | +80.7 | 192.8 | 48.2 | 0.5 | +20.8 | 25.1 | 12.6 |
| CANNON SIGHT KEPT | 1.2 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 4.6 |
| CARRIES OUT COUNTER | 0.0 | -1.8 | 1.4 | 0.0 | - | - | - | - |
| CARRIES OUT SET-UP | 0.1 | -4.6 | 16.6 | 0.0 | 0.0 | +0.0 | 6.5 | 0.0 |
| CAST JOB | 0.6 | +12.2 | 15.7 | 0.0 | 0.4 | +4.0 | 0.0 | 39.9 |
| CASTER AWAY FROM SCREEN | 0.2 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.4 | +34.8 | 51.7 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | 0.7 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 7.6 |
| CASTS FROM BEHIND | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CATCH ODDS | 0.0 | +2.5 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | 0.3 | +12.5 | 0.0 | 10.9 | 0.6 | +19.9 | 0.0 | 9.1 |
| CHAFF PASSED | 0.6 | -0.4 | 4.7 | 4.7 | 0.1 | -0.0 | 5.3 | 0.0 |
| CHARACTER GUNS | 0.6 | +0.0 | 0.0 | 0.0 | 0.5 | +0.0 | 0.0 | 0.0 |
| CHARGE LOSSES | 6.2 | -279.8 | 0.0 | 163.7 | 7.0 | -392.0 | 0.0 | 205.6 |
| CHARGE NOT DECLARED | 0.5 | +0.0 | 81.0 | 9.4 | 0.5 | +0.0 | 18.4 | 41.2 |
| CHARGE NOW FIRST | 1.8 | +0.0 | 265.1 | 20.3 | 1.6 | +0.0 | 119.4 | 66.9 |
| CHARGER SLAIN LOST | 0.3 | -6.1 | 29.8 | 6.7 | 0.4 | -15.5 | 23.3 | 28.8 |
| CHEAP HELPER | 0.1 | +0.0 | 0.0 | 2.9 | 0.0 | +0.0 | 0.0 | 0.0 |
| CHEAPEST HOLDER | 0.2 | -12.7 | 30.4 | 6.5 | - | - | - | - |
| COMBAT PIVOT | 0.4 | +0.0 | 14.0 | 60.9 | 0.4 | +0.0 | 0.0 | 22.9 |
| CONVEYANCE SEARCH | 0.9 | +59.6 | 3.0 | 6.5 | 0.4 | +23.7 | 6.2 | 22.8 |
| COVER ONCE | 6.7 | -539.0 | 0.0 | 116.4 | 4.6 | -440.1 | 0.0 | 161.3 |
| DEFENSIVE ARMY | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| DEFENSIVE FLOOR | 0.0 | +3.5 | 0.0 | 0.0 | - | - | - | - |
| DEPLOY BY FIGURES | 8.2 | +5.2 | 0.0 | 3.3 | 7.6 | +80.2 | 0.0 | 23.0 |
| EDGE GIVE GROUND | 0.2 | +10.4 | 28.1 | 0.0 | 0.2 | +1.5 | 23.1 | 13.6 |
| ELIXIR WORTH | 0.0 | +0.2 | 0.0 | 0.0 | - | - | - | - |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FALL BACK GOOD ORDER | 2.2 | +2.3 | 309.0 | 27.4 | 2.6 | +8.2 | 147.0 | 58.1 |
| FALLBACK BY WORTH | 0.3 | +0.0 | 0.0 | 2.4 | 0.2 | +1.6 | 0.0 | 4.3 |
| FALLS SHORT | 4.9 | +62.2 | 0.0 | 91.0 | 18.7 | +264.9 | 0.0 | 342.7 |
| FEATURE BUFFS | 1.6 | +31.2 | 0.0 | 9.1 | 0.5 | +15.1 | 0.0 | 38.3 |
| FIGHT LIFT | 0.1 | +1.0 | 0.0 | 0.0 | 0.1 | +1.3 | 7.1 | 0.0 |
| FIGHT TO THE END | 0.9 | +60.8 | 171.3 | 12.2 | 1.1 | +44.9 | 78.2 | 36.1 |
| FIRE AND FLEE | 0.0 | +0.0 | 0.0 | 5.6 | - | - | - | - |
| FIRE IN ORDER | 0.2 | +0.0 | 4.2 | 2.9 | 0.1 | +0.0 | 6.0 | 0.0 |
| FIVE ACTION | 49.0 | +3138.9 | 1104.4 | 531.5 | 43.6 | +2475.2 | 312.5 | 713.0 |
| FLANK NOT WEIGHED | 5.7 | +0.0 | 0.0 | 105.1 | 6.0 | +0.0 | 0.0 | 192.8 |
| FOCUS FIRE | 0.1 | +0.6 | 2.3 | 0.0 | 0.1 | +1.9 | 5.4 | 0.0 |
| FOLLOW UP WEIGHED | 0.5 | +87.6 | 0.0 | 0.0 | 0.6 | +168.7 | 0.0 | 0.0 |
| FOUR ROUNDS | 3.3 | +441.8 | 454.4 | 36.8 | 3.4 | +300.8 | 206.5 | 80.6 |
| FRIEND CHARGES FIRST | 0.1 | -13.7 | 15.0 | 0.0 | 0.2 | -10.9 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 0.7 | -40.5 | 30.0 | 0.0 | 0.1 | -3.6 | 0.0 | 0.0 |
| FRIENDS SHOTS CHECKED | 0.2 | +8.9 | 0.0 | 0.0 | 0.1 | +7.3 | 0.0 | 0.0 |
| GIVES UP | 0.1 | -1.0 | 15.0 | 0.0 | 0.3 | -1.4 | 9.3 | 8.9 |
| GROUND FLIERS | 0.0 | +0.6 | 0.0 | 0.0 | - | - | - | - |
| GUN FIGURES | 1.4 | +12.8 | 59.1 | 15.6 | 1.1 | +9.7 | 15.1 | 14.4 |
| GUN MASK | 0.8 | +6.4 | 0.0 | 0.0 | 0.1 | +7.5 | 0.0 | 2.2 |
| HARD STAY DROPPED | 2.0 | +0.0 | 0.0 | 3.3 | 0.8 | +0.0 | 0.0 | 0.0 |
| HE SHOOTS OR CHARGES | 2.2 | +0.0 | 0.0 | 39.0 | 2.6 | +0.0 | 0.0 | 83.2 |
| HELPER ALREADY ASKED | 0.1 | +0.0 | 30.2 | 0.0 | - | - | - | - |
| HELPER UNSEEN | 0.1 | +0.0 | 10.9 | 0.0 | - | - | - | - |
| HIS CHARGE DENIED | 0.7 | +25.6 | 30.7 | 6.7 | 0.4 | +23.2 | 24.8 | 1.8 |
| HIS CHARGE LIST | 2.6 | +0.0 | 0.0 | 48.6 | 3.6 | +0.0 | 0.0 | 80.2 |
| HIS LEGAL MOVES | 4.8 | +0.0 | 0.0 | 33.5 | 4.0 | +0.0 | 0.0 | 50.1 |
| HIS MOVE AND SHOT | 2.3 | -39.0 | 0.0 | 56.5 | 2.2 | -64.8 | 0.0 | 104.2 |
| HIS RANDOM MOVE | 4.1 | +0.0 | 0.0 | 57.4 | 1.4 | +0.0 | 0.0 | 13.3 |
| HIS SHOT LIST | 16.5 | +399.1 | 0.0 | 270.6 | 24.5 | +1023.9 | 0.0 | 364.1 |
| HIS TURN DENIED | 1.1 | +22.0 | 198.4 | 0.0 | 1.7 | +56.9 | 128.0 | 36.7 |
| HOLD ODDS | - | - | - | - | 6.6 | +0.0 | 0.0 | 78.4 |
| HOLDER ASSIGNMENT | - | - | - | - | 13.1 | +1254.4 | 0.0 | 191.5 |
| HOLDER AT DEPLOYMENT | 1.2 | +202.6 | 0.0 | 0.0 | - | - | - | - |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 2.8 | -113.1 | 387.8 | 30.1 | 3.0 | -131.3 | 200.6 | 71.3 |
| HUNT IN PAIRS | 0.2 | +9.7 | 0.0 | 1.9 | 0.4 | +25.6 | 0.0 | 0.0 |
| HUNT RESULT | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |
| HUNT THE GUNS | - | - | - | - | 0.0 | +13.4 | 0.0 | 3.2 |
| IDLE COST | 2.7 | -33.9 | 0.0 | 62.6 | 12.2 | -175.1 | 0.0 | 232.3 |
| JOINT KNOWS CHALLENGE | 0.2 | -5.3 | 67.6 | 0.0 | 0.1 | -0.8 | 18.3 | 0.8 |
| KEEP FALLS | 0.1 | +0.2 | 0.0 | 0.0 | - | - | - | - |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KILLS COUNT | 0.0 | +1.7 | 4.7 | 0.0 | 0.1 | +3.1 | 20.2 | 0.0 |
| LANE BY FIGURES | 0.9 | +36.2 | 0.0 | 0.0 | 0.9 | +40.1 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 5.7 | +0.0 | 245.9 | 182.3 | 5.5 | +0.0 | 220.2 | 216.9 |
| LONE CHARACTER SAFE SPOT | 0.0 | +0.3 | 0.0 | 0.0 | 0.0 | +1.4 | 0.0 | 0.0 |
| LONE WIZARD KEPT IN | 0.6 | +30.6 | 0.0 | 0.0 | 0.5 | +37.1 | 0.0 | 0.0 |
| LONG SHOT | 0.4 | -2.6 | 24.4 | 8.3 | 0.1 | +0.3 | 5.6 | 0.0 |
| LOST CHARGE | 0.0 | -0.0 | 15.0 | 0.0 | - | - | - | - |
| LURE BY WHAT IT DRAWS | 0.1 | -8.9 | 0.0 | 3.9 | 0.1 | -1.5 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 0.1 | +2.0 | 0.0 | 5.2 | 0.3 | +13.1 | 0.0 | 2.2 |
| MANOEUVRE | 1.4 | +31.7 | 0.0 | 9.7 | 1.4 | +9.0 | 0.0 | 27.0 |
| MARCH AT ESCAPER | 0.2 | +0.6 | 0.0 | 15.0 | 0.2 | +1.0 | 0.0 | 30.7 |
| MARCH BY THE SUM | 0.3 | +19.5 | 0.0 | 0.0 | 0.3 | +10.4 | 0.0 | 11.3 |
| MARCH CHECK | 1.2 | +68.0 | 0.0 | 4.5 | 0.9 | +43.8 | 0.0 | 20.1 |
| MARCH OVER CASTS | 0.8 | +63.9 | 0.0 | 15.0 | 0.7 | +63.4 | 0.0 | 45.7 |
| MAX FOR POSITIONING | 6.2 | +88.2 | 0.0 | 45.4 | 6.6 | +118.7 | 0.0 | 136.5 |
| MISSILES IN THE MOVE | 4.8 | +154.2 | 0.0 | 16.5 | 2.8 | +42.3 | 0.0 | 148.7 |
| MISSILES NEXT TURN | 5.7 | +115.3 | 0.0 | 46.5 | 3.9 | +32.3 | 0.0 | 210.5 |
| MODEL FACING | 0.2 | +53.0 | 0.0 | 5.0 | - | - | - | - |
| MOVE SPELL IN RANGE | 0.4 | +17.2 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL NOT WORTH | 0.0 | -0.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.2 | -7.2 | 0.0 | 0.0 | 0.2 | -10.6 | 0.0 | 0.0 |
| MOVE SPELL SPOT | 0.5 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 4.5 | +618.4 | 0.0 | 36.6 | 4.5 | +655.2 | 0.0 | 69.1 |
| MOVES UNITS SPELL | 0.1 | +3.4 | 0.0 | 0.0 | 0.1 | +0.4 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 4.6 | +219.6 | 0.0 | 22.6 | 4.0 | +171.1 | 0.0 | 64.1 |
| NEEDED THERE | 0.0 | +9.1 | 4.7 | 0.0 | 0.1 | +18.1 | 20.2 | 0.0 |
| NEXT CHARGE BY LIST | 6.4 | -228.2 | 54.8 | 54.6 | 6.0 | -217.9 | 2.2 | 106.3 |
| NEXT OBJECTIVE NEARER | 7.5 | -320.9 | 90.8 | 69.9 | 6.4 | -197.8 | 32.3 | 99.4 |
| NO DOUBLE ROUNDS | 2.6 | -147.9 | 391.2 | 10.9 | 2.5 | -107.1 | 143.2 | 75.1 |
| NO RALLY LEFT | 0.0 | +4.0 | 0.0 | 15.0 | 0.1 | +4.1 | 0.0 | 0.0 |
| NOT TURNED | 0.1 | +0.0 | 0.0 | 3.9 | 0.1 | +0.3 | 0.0 | 4.2 |
| NOT WORTH A CAST | 0.5 | -0.3 | 0.0 | 0.0 | 0.6 | -0.5 | 0.0 | 20.3 |
| OFF BEST | 0.2 | -4.3 | 0.0 | 5.8 | 0.6 | -8.7 | 0.0 | 0.0 |
| ONE CHARGE A CHARGER | 3.6 | +0.0 | 0.0 | 115.4 | 3.6 | +0.0 | 0.0 | 98.0 |
| ONE FIGHT FORMULA | 6.0 | -122.7 | 0.0 | 56.9 | 6.0 | -147.9 | 0.0 | 170.9 |
| ONE OBJECTIVE FORMULA | 3.4 | -47.5 | 0.0 | 23.8 | 4.1 | +4.3 | 0.0 | 123.4 |
| ONE TARGET A SHOOTER | 15.3 | +237.7 | 0.0 | 208.3 | 20.8 | +592.4 | 0.0 | 317.0 |
| OPENS A LANE | 0.1 | +1.0 | 3.5 | 0.0 | - | - | - | - |
| OPENS UP | 0.4 | +23.4 | 20.0 | 0.0 | 0.2 | +13.5 | 12.4 | 0.0 |
| OVERRUNS AWAY | 0.4 | +24.3 | 55.6 | 15.0 | 0.5 | +18.0 | 29.2 | 22.9 |
| PATHS CROSS | 3.8 | +169.8 | 0.0 | 25.1 | 4.9 | +197.5 | 0.0 | 40.0 |
| PERIAPT WORTH | 0.1 | +3.4 | 0.0 | 15.0 | 0.1 | +14.4 | 0.0 | 15.0 |
| PIVOT GUARDS FLANK | 0.1 | -4.4 | 0.0 | 0.0 | 0.1 | -2.5 | 0.0 | 0.0 |
| PLAN RESULT | 43.0 | +971.0 | 603.3 | 670.4 | 39.1 | +315.7 | 252.4 | 938.1 |
| PURSUES BIG PREY | - | - | - | - | 0.0 | -1.3 | 0.0 | 0.0 |
| RANDOM MOVE BY FIGURES | 0.7 | +16.7 | 0.0 | 49.2 | 2.8 | +43.2 | 0.0 | 60.8 |
| REDIRECT BY WHAT IT STOPS | 0.2 | -4.3 | 0.0 | 5.2 | 0.2 | -9.4 | 0.0 | 6.4 |
| REDIRECT COUNTER | 1.8 | +147.9 | 0.0 | 18.3 | 3.9 | +305.8 | 0.0 | 85.6 |
| REDIRECT WEIGHED | 0.3 | +7.3 | 3.8 | 0.0 | 0.2 | -2.7 | 3.1 | 13.1 |
| REFORMS TO MEET IT | 0.6 | -22.1 | 0.0 | 6.9 | 0.8 | -45.1 | 0.0 | 7.3 |
| REFUSING RETIRES | 0.4 | +0.0 | 0.0 | 10.3 | 0.2 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | 0.4 | +11.0 | 0.0 | 5.2 | 0.8 | +40.4 | 0.0 | 22.4 |
| RESTRAINS TO SHOOT | 0.1 | +11.6 | 0.0 | 0.0 | 0.0 | +0.2 | 0.0 | 0.0 |
| RISK BY ARC | 1.8 | +57.9 | 252.1 | 25.9 | 2.3 | +16.6 | 151.7 | 65.7 |
| RISK BY HIS FIGURE | 14.3 | -239.8 | 0.0 | 250.3 | 14.3 | -251.7 | 0.0 | 368.2 |
| RUN DOWN | 2.0 | -30.6 | 213.4 | 9.6 | 2.7 | -27.5 | 155.9 | 60.3 |
| SAME CHARGE LATER | - | - | - | - | 0.3 | -4.5 | 0.0 | 0.0 |
| SCOUT SPOT | 0.3 | +0.6 | 0.0 | 0.0 | 0.2 | +0.9 | 0.0 | 0.0 |
| SCOUT WAITS | 0.3 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.2 | -12.2 | 0.0 | 2.8 | 0.2 | -13.0 | 0.0 | 3.8 |
| SEARCH SPOT | 6.3 | +259.3 | 0.0 | 98.8 | 6.2 | +266.4 | 0.0 | 92.0 |
| SELF MOVE SPELL | 0.1 | +12.8 | 0.0 | 0.0 | 0.3 | +57.0 | 0.0 | 0.0 |
| SET UP TOGETHER | 0.4 | +5.0 | 0.0 | 5.2 | 0.3 | +13.6 | 0.0 | 2.2 |
| SET-UP ANY TARGET | 0.3 | +39.2 | 0.0 | 0.0 | 0.1 | +15.2 | 0.0 | 0.0 |
| SHOOTER COUNTED ONCE | 0.0 | -0.0 | 0.0 | 1.2 | - | - | - | - |
| SHOOTERS IN TWO RANKS | 0.4 | +0.9 | 0.0 | 0.0 | 0.3 | +0.6 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.3 | +68.3 | 84.1 | 6.7 | 0.9 | +29.9 | 10.3 | 28.0 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SHOT OR CHARGE | 0.6 | -47.1 | 62.2 | 4.9 | 0.3 | -5.6 | 15.4 | 8.9 |
| SHOT RISK POINTS | 8.2 | -24.8 | 0.0 | 195.8 | 13.5 | -12.7 | 0.0 | 227.6 |
| SHOTS IN THE MOVE | 16.3 | +579.0 | 0.0 | 182.1 | 9.5 | +212.6 | 0.0 | 102.5 |
| SPELL SETS UP CHARGE | 0.3 | +39.2 | 0.0 | 0.0 | 0.1 | +15.2 | 0.0 | 0.0 |
| SPELL WORTH | 1.6 | +27.9 | 73.6 | 83.6 | 2.4 | +49.7 | 183.1 | 167.9 |
| SPELLS IN THE FIGHT | 0.7 | +2.3 | 185.2 | 15.0 | 0.3 | -6.6 | 22.7 | 5.2 |
| STAND AND SHOOT | 0.3 | -3.5 | 23.1 | 0.0 | 0.6 | -7.2 | 22.2 | 1.2 |
| STANDS FOR A REASON | 0.1 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 6.9 | 47.2 |
| STANDS STILL | 18.8 | +0.0 | 573.2 | 197.1 | 9.5 | +0.0 | 106.0 | 152.7 |
| STAY WORTH | 19.0 | +90.0 | 414.7 | 157.1 | 8.7 | +83.4 | 80.0 | 91.2 |
| STOPS | - | - | - | - | 0.0 | +0.0 | 0.0 | 3.2 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 10.6 | 0.4 | +0.0 | 0.0 | 0.0 |
| SUPPORT NARROWED | 0.9 | +0.0 | 130.2 | 5.7 | 1.0 | +0.0 | 37.1 | 20.8 |
| SURE REACH TOGETHER | 0.2 | +1.0 | 0.0 | 0.0 | 0.4 | +4.0 | 0.0 | 9.7 |
| THE DEARER SUM KEEPS ITS PLAN | 4.1 | +0.0 | 0.0 | 31.1 | 4.4 | +0.0 | 0.0 | 25.0 |
| THE PROMISE ADDS | 0.4 | -40.2 | 20.6 | 0.0 | 0.2 | -16.3 | 8.0 | 3.5 |
| THE PROMISED MOVE | 0.4 | +0.0 | 0.0 | 0.0 | 1.4 | +0.0 | 0.0 | 19.1 |
| TIED UP BY THE SUM | 0.8 | +77.7 | 72.4 | 0.0 | 0.7 | +74.8 | 41.6 | 16.3 |
| TIME ON OUR SIDE | 31.9 | +459.4 | 12.6 | 182.9 | 6.7 | +104.3 | 0.0 | 101.4 |
| TWO OR MORE ARRIVE | - | - | - | - | 0.1 | +0.0 | 0.0 | 0.0 |
| WAITS AGAIN | 2.1 | +0.0 | 0.0 | 6.9 | 1.8 | +0.0 | 0.0 | 34.0 |
| WAR ENGINE CHARGES | 0.0 | +2.0 | 0.0 | 0.0 | - | - | - | - |
| WAR ENGINE JOBS | 0.4 | +0.0 | 45.6 | 0.0 | 0.1 | +0.0 | 3.5 | 0.0 |
| WHO HITS BACK | 0.3 | +82.7 | 0.0 | 0.0 | 0.4 | +59.0 | 0.0 | 15.9 |
| WHOLE FIGHT | 0.1 | +2.0 | 16.2 | 15.0 | 0.3 | +11.4 | 10.4 | 5.5 |
| WHOLE FIGHT GAIN | 0.2 | +12.0 | 31.3 | 5.7 | 0.2 | +33.0 | 17.2 | 4.3 |
| WIDER SPREAD | 2.1 | -5.8 | 305.3 | 21.8 | 2.2 | -1.6 | 129.2 | 44.9 |
| WOUNDED STAYS OUT | 0.0 | +0.0 | 5.3 | 0.0 | 0.1 | +0.0 | 1.7 | 0.0 |
| WOUNDS ON THE RANKS | 1.2 | +30.5 | 0.0 | 11.0 | 1.7 | +105.9 | 0.0 | 49.0 |

### Rule changes: h3-opp-efe7e34-p4

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HOLDER ASSIGNMENT | 471 | 471 | 434 | 12.06 | +24178 | +55.7 |
| SEARCH SPOT | 450 | 450 | 426 | 11.83 | +18938 | +44.5 |
| LEGAL CHARGES ONLY | 401 | 401 | 401 | 11.14 | +0 | +0.0 |
| HIS SHOT LIST | 1474 | 1474 | 396 | 11.00 | +7362 | +18.6 |
| DEPLOY BY FIGURES | 568 | 568 | 341 | 9.47 | +4490 | +13.2 |
| PATHS CROSS | 315 | 315 | 315 | 8.75 | +13219 | +42.0 |
| FIVE ACTION | 3335 | 3329 | 309 | 8.58 | +15437 | +50.0 |
| ONE TARGET A SHOOTER | 1298 | 1298 | 270 | 7.50 | +3403 | +12.6 |
| TIME ON OUR SIDE | 1390 | 1234 | 265 | 7.36 | +665 | +2.5 |
| MOVE TO CHARGE COMPUTED | 324 | 324 | 196 | 5.44 | +18016 | +91.9 |
| SHOT RISK POINTS | 783 | 783 | 127 | 3.53 | +3140 | +24.7 |
| FOUR ROUNDS | 242 | 237 | 126 | 3.50 | +9129 | +72.5 |
| MAX FOR POSITIONING | 464 | 453 | 121 | 3.36 | +422 | +3.5 |
| HARD STAY DROPPED | 102 | 102 | 102 | 2.83 | +0 | +0.0 |
| COVER ONCE | 405 | 324 | 80 | 2.22 | +1896 | +23.7 |
| SHOTS IN THE MOVE | 930 | 872 | 79 | 2.19 | +2427 | +30.7 |
| IDLE COST | 537 | 449 | 74 | 2.06 | +524 | +7.1 |
| RANDOM MOVE BY FIGURES | 125 | 125 | 73 | 2.03 | +2155 | +29.5 |
| LANE BY FIGURES | 62 | 62 | 62 | 1.72 | +2745 | +44.3 |
| REDIRECT COUNTER | 206 | 180 | 62 | 1.72 | +5032 | +81.2 |
| MARCH CHECK | 77 | 77 | 60 | 1.67 | +977 | +16.3 |
| NEXT OBJECTIVE NEARER | 499 | 499 | 60 | 1.67 | +1054 | +17.6 |
| SHOOTS FROM THE BEST SPOT | 80 | 80 | 60 | 1.67 | +1020 | +17.0 |
| ADVANCE LANE KEPT | 55 | 55 | 55 | 1.53 | +0 | +0.0 |
| FALLS SHORT | 848 | 744 | 52 | 1.44 | +240 | +4.6 |
| MANOEUVRE | 102 | 102 | 52 | 1.44 | +1586 | +30.5 |
| MISSILES IN THE MOVE | 275 | 236 | 52 | 1.44 | +1320 | +25.4 |
| CANNON SIGHT KEPT | 49 | 49 | 49 | 1.36 | +0 | +0.0 |
| RISK BY HIS FIGURE | 1029 | 1029 | 49 | 1.36 | +4966 | +101.3 |
| ARTILLERY RE-ROLL WEIGHED | 47 | 47 | 47 | 1.31 | +0 | +0.0 |
| NEXT CHARGE BY LIST | 448 | 448 | 47 | 1.31 | +1161 | +24.7 |
| CHARGE LOSSES | 478 | 478 | 46 | 1.28 | +4425 | +96.2 |
| RISK BY ARC | 150 | 147 | 46 | 1.28 | +978 | +21.3 |
| TIED UP BY THE SUM | 53 | 52 | 46 | 1.28 | +1549 | +33.7 |
| RESERVE FALL BACK | 43 | 43 | 43 | 1.19 | +1849 | +43.0 |
| FOLLOW UP WEIGHED | 40 | 40 | 40 | 1.11 | +9226 | +230.6 |
| LONE WIZARD KEPT IN | 39 | 39 | 39 | 1.08 | +2437 | +62.5 |
| CHARGE NOT DECLARED | 38 | 38 | 38 | 1.06 | -6605 | -173.8 |
| CHARGE NOW FIRST | 125 | 125 | 33 | 0.92 | -1361 | -41.2 |
| OFF BEST | 31 | 31 | 31 | 0.86 | -467 | -15.1 |
| HOLDS AMBUSHERS | 30 | 30 | 30 | 0.83 | +0 | +0.0 |
| CANNON PLANNED TARGET | 182 | 182 | 29 | 0.81 | -135 | -4.7 |
| COMBAT PIVOT | 28 | 28 | 28 | 0.78 | +0 | +0.0 |
| HIS TURN DENIED | 100 | 100 | 28 | 0.78 | +567 | +20.3 |
| CHAFF PASSED | 26 | 26 | 26 | 0.72 | -15 | -0.6 |
| WHO HITS BACK | 25 | 25 | 25 | 0.69 | +3303 | +132.1 |
| SHOOTERS IN TWO RANKS | 24 | 24 | 24 | 0.67 | +52 | +2.2 |
| CAST JOB | 34 | 34 | 22 | 0.61 | +148 | +6.7 |
| ONE OBJECTIVE FORMULA | 272 | 240 | 22 | 0.61 | +816 | +37.1 |
| STAY WORTH | 996 | 948 | 22 | 0.61 | +149 | +6.8 |
| WOUNDS ON THE RANKS | 104 | 104 | 22 | 0.61 | +646 | +29.4 |
| HOLDER AT DEPLOYMENT | 45 | 45 | 21 | 0.58 | +871 | +41.5 |
| MARCH BY THE SUM | 20 | 20 | 20 | 0.56 | +1076 | +53.8 |
| SCOUT WAITS | 20 | 20 | 20 | 0.56 | +0 | +0.0 |
| REDIRECT WEIGHED | 19 | 19 | 19 | 0.53 | +746 | +39.3 |
| NEARER NOT NEEDED | 310 | 289 | 18 | 0.50 | +502 | +27.9 |
| AFTERMATH IN POINTS | 17 | 17 | 17 | 0.47 | +1091 | +64.2 |
| STUCK PIVOT | 17 | 17 | 17 | 0.47 | +0 | +0.0 |
| CASTER AWAY FROM SCREEN | 15 | 15 | 15 | 0.42 | +0 | +0.0 |
| FIGHT TO THE END | 75 | 73 | 15 | 0.42 | +506 | +33.7 |
| CHAFF IN THE MOVE | 33 | 31 | 14 | 0.39 | +41 | +2.9 |
| FEATURE BUFFS | 75 | 75 | 13 | 0.36 | +273 | +21.0 |
| OPENS UP | 22 | 21 | 13 | 0.36 | +242 | +18.6 |
| HIS CHARGE DENIED | 39 | 39 | 12 | 0.33 | +350 | +29.2 |
| ONE FIGHT FORMULA | 433 | 250 | 12 | 0.33 | +23 | +1.9 |
| WHOLE FIGHT GAIN | 16 | 16 | 12 | 0.33 | +538 | +44.9 |
| CASTING BLOCK | 13 | 13 | 11 | 0.31 | +283 | +25.7 |
| FRIENDS SHOTS CHECKED | 11 | 11 | 11 | 0.31 | +585 | +53.1 |
| OVERRUNS AWAY | 32 | 31 | 10 | 0.28 | +216 | +21.6 |
| SURE REACH TOGETHER | 22 | 21 | 10 | 0.28 | +12 | +1.2 |
| CASTS FROM BEHIND | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| FIRE IN ORDER | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| PIVOT GUARDS FLANK | 9 | 9 | 9 | 0.25 | -248 | -27.5 |
| REFUSING RETIRES | 22 | 22 | 9 | 0.25 | -3 | -0.4 |
| MODEL FACING | 7 | 7 | 7 | 0.19 | +1908 | +272.6 |
| PERIAPT WORTH | 7 | 7 | 7 | 0.19 | +641 | +91.6 |
| SHORT GUN FORWARD | 7 | 7 | 7 | 0.19 | +0 | +0.0 |
| SUPPORT NARROWED | 71 | 71 | 7 | 0.19 | -212 | -30.3 |
| WIDER SPREAD | 158 | 155 | 7 | 0.19 | +36 | +5.1 |
| BEST PRIZE | 6 | 6 | 6 | 0.17 | -890 | -148.3 |
| MOVES UNITS SPELL | 6 | 6 | 6 | 0.17 | +136 | +22.7 |
| RESTRAINS TO SHOOT | 6 | 6 | 6 | 0.17 | +425 | +70.9 |
| FALL BACK GOOD ORDER | 170 | 166 | 5 | 0.14 | +101 | +20.3 |
| HONEST WORTH | 208 | 203 | 5 | 0.14 | +43 | +8.5 |
| HUNT IN PAIRS | 24 | 12 | 5 | 0.14 | +274 | +54.7 |
| MISSILES NEXT TURN | 346 | 275 | 5 | 0.14 | +79 | +15.7 |
| WAR ENGINE JOBS | 17 | 17 | 5 | 0.14 | -90 | -18.0 |
| CARRIES OUT SET-UP | 5 | 5 | 4 | 0.11 | -164 | -41.0 |
| EDGE GIVE GROUND | 14 | 14 | 4 | 0.11 | +168 | +42.0 |
| FOCUS FIRE | 4 | 4 | 4 | 0.11 | +92 | +23.1 |
| HIS MOVE AND SHOT | 162 | 162 | 4 | 0.11 | +18 | +4.4 |
| NO DOUBLE ROUNDS | 183 | 178 | 4 | 0.11 | +89 | +22.2 |
| NO RALLY LEFT | 4 | 4 | 4 | 0.11 | +88 | +22.1 |
| SET UP TOGETHER | 26 | 18 | 3 | 0.08 | +97 | +32.5 |
| SPELLS IN THE FIGHT | 37 | 36 | 3 | 0.08 | +14 | +4.5 |
| CHARGER SLAIN LOST | 24 | 24 | 2 | 0.06 | +23 | +11.3 |
| GUN MASK | 32 | 32 | 2 | 0.06 | +11 | +5.5 |
| KEEP FALLS | 2 | 2 | 2 | 0.06 | +25 | +12.4 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| KILLS COUNT | 3 | 3 | 2 | 0.06 | +0 | +0.0 |
| NEEDED THERE | 3 | 3 | 2 | 0.06 | +0 | +0.0 |
| RUN DOWN | 169 | 165 | 2 | 0.06 | +46 | +23.2 |
| WHOLE FIGHT | 16 | 16 | 2 | 0.06 | +242 | +120.8 |
| BACKUP TARGETS | 16 | 12 | 1 | 0.03 | +2 | +2.1 |
| BOMBING RUN | 1 | 1 | 1 | 0.03 | +93 | +93.4 |
| CARRIES OUT COUNTER | 1 | 1 | 1 | 0.03 | -66 | -66.1 |
| CATCH ODDS | 1 | 1 | 1 | 0.03 | -25 | -25.2 |
| DEFENSIVE FLOOR | 1 | 1 | 1 | 0.03 | +115 | +115.2 |
| ELIXIR WORTH | 1 | 1 | 1 | 0.03 | +7 | +7.2 |
| FALLBACK BY WORTH | 21 | 21 | 1 | 0.03 | +59 | +58.7 |
| FIRE AND FLEE | 1 | 1 | 1 | 0.03 | +1 | +1.1 |
| LONG SHOT | 16 | 16 | 1 | 0.03 | +0 | +0.1 |
| PURSUES BIG PREY | 1 | 1 | 1 | 0.03 | -46 | -46.1 |
| REDIRECT BY WHAT IT STOPS | 16 | 16 | 1 | 0.03 | +5 | +4.7 |
| THE PROMISE ADDS | 19 | 19 | 1 | 0.03 | +34 | +34.0 |
| WAR ENGINE CHARGES | 1 | 1 | 1 | 0.03 | +55 | +54.6 |
| WOUNDED STAYS OUT | 3 | 3 | 1 | 0.03 | -108 | -108.3 |
| ALREADY CARRIED | 3 | not checked | - | - | - | - |
| BLOWS WHERE AIMED | 17 | 17 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 26 | 26 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 40 | trace | - | - | - | - |
| CHARACTER GUNS | 39 | 39 | 0 | 0.00 | - | - |
| CHEAP HELPER | 3 | not checked | - | - | - | - |
| CHEAPEST HOLDER | 9 | 9 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 48 | not checked | - | - | - | - |
| DEFENSIVE ARMY | 3 | 3 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT LIFT | 7 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 423 | not checked | - | - | - | - |
| FRIEND CHARGES FIRST | 11 | 11 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 31 | 31 | 0 | 0.00 | - | - |
| GIVES UP | 13 | 13 | 0 | 0.00 | - | - |
| GROUND FLIERS | 1 | not checked | - | - | - | - |
| GUN FIGURES | 91 | not checked | - | - | - | - |
| HE SHOOTS OR CHARGES | 172 | 172 | 0 | 0.00 | - | - |
| HELPER ALREADY ASKED | 3 | not checked | - | - | - | - |
| HELPER UNSEEN | 2 | 2 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 223 | 223 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 315 | 315 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 199 | 199 | 0 | 0.00 | - | - |
| HOLD ODDS | 238 | 238 | 0 | 0.00 | - | - |
| HUNT RESULT | 1 | trace | - | - | - | - |
| HUNT THE GUNS | 1 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 9 | 9 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 2 | not checked | - | - | - | - |
| LOST CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 7 | 7 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 14 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 15 | trace | - | - | - | - |
| MARCH OVER CASTS | 52 | 52 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 15 | 8 | 0 | 0.00 | - | - |
| MOVE SPELL NOT WORTH | 1 | not checked | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 13 | trace | - | - | - | - |
| MOVE SPELL SPOT | 24 | not checked | - | - | - | - |
| NOT TURNED | 8 | 8 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 39 | not checked | - | - | - | - |
| ONE CHARGE A CHARGER | 260 | 260 | 0 | 0.00 | - | - |
| OPENS A LANE | 3 | 2 | 0 | 0.00 | - | - |
| PLAN RESULT | 2956 | trace | - | - | - | - |
| REFORMS TO MEET IT | 51 | 51 | 0 | 0.00 | - | - |
| SAME CHARGE LATER | 10 | 10 | 0 | 0.00 | - | - |
| SCOUT SPOT | 19 | 19 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 13 | 13 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 16 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 14 | not checked | - | - | - | - |
| SHOOTER COUNTED ONCE | 1 | 1 | 0 | 0.00 | - | - |
| SHOT OR CHARGE | 31 | 31 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 14 | not checked | - | - | - | - |
| SPELL WORTH | 142 | not checked | - | - | - | - |
| STAND AND SHOOT | 32 | 32 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 29 | 29 | 0 | 0.00 | - | - |
| STANDS STILL | 1017 | 1017 | 0 | 0.00 | - | - |
| STOPS | 1 | 1 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 309 | not checked | - | - | - | - |
| THE PROMISED MOVE | 62 | not checked | - | - | - | - |
| TWO OR MORE ARRIVE | 2 | not checked | - | - | - | - |
| WAITS AGAIN | 138 | 138 | 0 | 0.00 | - | - |

### Off best figure: h3-opp-efe7e34-p4

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| HOLDER ASSIGNMENT | rule | - | 1.53 | 18.4 |
| PATHS CROSS | rule | 0.61 | 0.44 | 24.2 |
| CHARGE NOT DECLARED | rule | 0.50 | 0.50 | 183.5 |
| CHARGE NOW FIRST | rule | 0.56 | 0.33 | 42.5 |
| JOB FIRST | gate | 0.06 | 0.44 | 19.1 |
| CANNON PLANNED TARGET | rule | 0.28 | 0.03 | 16.5 |
| AFTERMATH BAND | gate | 0.14 | 0.14 | 2.6 |
| PIVOT GUARDS FLANK | rule | 0.14 | 0.11 | 27.5 |
| BEST PRIZE | rule | 0.03 | 0.14 | 148.3 |
| SUPPORT NARROWED | rule | 0.06 | 0.11 | 35.4 |
| CHAFF PASSED | rule | 0.11 | 0.03 | 2.9 |
| CARRIES OUT SET-UP | rule | 0.11 | - | 41.0 |
| WAR ENGINE JOBS | rule | 0.06 | 0.06 | 22.4 |
| DEPLOY BY FIGURES | rule | 0.03 | 0.06 | 17.6 |
| FRIENDS SHOTS CHECKED | rule | 0.06 | 0.03 | 4.0 |
| REFUSING RETIRES | rule | 0.06 | 0.03 | 0.8 |
| AFTERMATH NEEDS NEXT CHARGE | gate | - | 0.03 | 7.6 |
| CARRIES OUT COUNTER | rule | 0.03 | - | 66.1 |
| CATCH ODDS | rule | 0.03 | - | 25.2 |
| FALLBACK | gate | - | 0.03 | 42.8 |
| FOLLOW UP WEIGHED | rule | - | 0.03 | 2.1 |
| PURSUES BIG PREY | rule | - | 0.03 | 46.1 |
| REDIRECT WEIGHED | rule | - | 0.03 | 670.7 |
| RULE SWITCHED OFF | gate | 0.03 | - | 46.2 |
| WOUNDED STAYS OUT | rule | 0.03 | - | 108.3 |

### Plans: h3-opp-efe7e34-p4

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 2.5 | 68% | 502 | 360 | 72% |
| Mine | join | 0.3 | 100% | 6 | 0 | 0% |
| Mine | move | 31.0 | 95% | 1779 | 0 | 0% |
| Mine | shoot | 8.8 | 50% | 443 | 611 | 138% |
| Mine | support | 0.4 | 75% | 10 | 0 | 0% |
| Opponent | charge | 2.8 | 58% | 470 | 243 | 52% |
| Opponent | join | 0.6 | 95% | 29 | 0 | 0% |
| Opponent | move | 32.9 | 93% | 1668 | 0 | 0% |
| Opponent | shoot | 2.4 | 42% | 151 | 73 | 48% |
| Opponent | support | 0.4 | 69% | 1 | 0 | 0% |

### Packages: hunt the guns, h3-opp-efe7e34-p4

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 9 |
| Opponent | 0.0 | 1 | 0 | 0% | 0% | 0% | - | 483 | 0 | 0% | 40 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 113 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 66 |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 184 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 23 |
| Tomb Kings of Khemri | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 14 |
| Vampire Counts | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 8 |
| Warriors of Chaos | 0.1 | 1 | 0 | 0% | 0% | 0% | - | 483 | 0 | 0% | 0 |
| Wood Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 38 |

### Battle groups: h3-opp-efe7e34-p4

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 1.8 | 18% | 67% | 25% | 0% | 22% | 0% | 0% | 78% | 0% |
| Opponent | REDIRECT COUNTER | 3.9 | 24% | 64% | 15% | 20% | 4% | 0% | 0% | 89% | 7% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: h3-opp-efe7e34-p4

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 2 | 0 (2) | 0 | 0 | 0 | 100% | - | - | - | 0 (1) | 0 (1) | - |
| Mine | Chaff | 30 | 93 (30) | 2 | 91 | 35 | 53% | 2.1 | 62 (14) | 299 (7) | 0 (9) | 112 (25) | 0 (5) |
| Mine | Character | 116 | 59 (116) | 59 | 0 | 21 | 18% | 2.7 | 59 (37) | 59 (39) | 71 (28) | 57 (56) | 68 (48) |
| Mine | Clean-up | 23 | 88 (23) | 13 | 74 | 42 | 30% | 3.2 | 80 (8) | 102 (13) | 30 (2) | 89 (18) | 83 (5) |
| Mine | Fast Hammer | 50 | 60 (50) | 25 | 35 | 23 | 26% | 3.2 | 79 (9) | 75 (22) | 34 (19) | 70 (37) | 36 (13) |
| Mine | Hammer | 56 | 38 (56) | 24 | 14 | 20 | 25% | 2.7 | 62 (16) | 34 (30) | 17 (10) | 30 (32) | 48 (24) |
| Mine | Holder | 30 | 106 (30) | 7 | 98 | 23 | 43% | 3.3 | 91 (9) | 145 (16) | 46 (5) | 137 (17) | 68 (13) |
| Mine | Shooter | 48 | 61 (48) | 7 | 53 | 32 | 4% | 1.8 | 40 (16) | 90 (20) | 44 (12) | 52 (35) | 85 (13) |
| Mine | Support | 4 | 15 (4) | 15 | 0 | 42 | 0% | 4.0 | 26 (3) | 0 (1) | - | 26 (3) | 0 (1) |
| Mine | War machine | 55 | 21 (55) | 21 | 0 | 40 | 2% | 1.6 | 30 (20) | 10 (22) | 28 (13) | 64 (9) | 14 (46) |
| Mine | Wizard | 18 | 6 (18) | 6 | 0 | 15 | 22% | 2.4 | 21 (6) | 0 (5) | 0 (5) | 9 (12) | 0 (4) |
| Opponent | Chaff | 59 | 61 (59) | 19 | 42 | 51 | 51% | 2.8 | 65 (22) | 67 (17) | 49 (20) | 62 (46) | 58 (13) |
| Opponent | Character | 92 | 39 (92) | 39 | 0 | 33 | 14% | 2.5 | 51 (20) | 34 (40) | 47 (21) | 39 (50) | 48 (31) |
| Opponent | Clean-up | 30 | 59 (30) | 7 | 52 | 19 | 63% | 2.7 | 31 (12) | 79 (13) | 65 (5) | 76 (19) | 39 (11) |
| Opponent | Fast Hammer | 54 | 25 (54) | 10 | 15 | 39 | 28% | 3.0 | 22 (11) | 26 (30) | 26 (13) | 22 (38) | 34 (16) |
| Opponent | Fragile | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | - | - | - | - |
| Opponent | Hammer | 57 | 22 (57) | 19 | 3 | 46 | 30% | 3.3 | 25 (15) | 17 (32) | 34 (10) | 29 (34) | 12 (23) |
| Opponent | Holder | 32 | 110 (32) | 14 | 96 | 28 | 41% | 3.4 | 77 (10) | 148 (16) | 66 (6) | 130 (20) | 73 (12) |
| Opponent | Shooter | 49 | 69 (49) | 12 | 57 | 48 | 10% | 2.0 | 58 (15) | 93 (20) | 52 (14) | 89 (33) | 33 (16) |
| Opponent | Support | 3 | 0 (3) | 0 | 0 | 0 | 100% | - | 0 (2) | 0 (1) | - | - | 0 (3) |
| Opponent | War machine | 9 | 31 (9) | 31 | 0 | 41 | 0% | 1.6 | 59 (5) | 0 (1) | 0 (3) | - | 31 (9) |
| Opponent | Wizard | 28 | 0 (28) | 0 | 0 | 34 | 14% | 2.1 | 0 (5) | 0 (11) | 0 (7) | 0 (10) | 0 (13) |

### Charged fights: h3-opp-efe7e34-p4

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 150 | 36 | 0.8 | 1.0 | 48 | 17 | +30 | 1 of 3 | 2 of 3 | - | +30 |
| Mine | Chaos Dwarfs | 4 | 290 | 323 | 1.2 | 1.2 | 258 | 0 | +258 | 3 of 5 | 5 of 5 | +540 | +188 |
| Mine | Dwarfen Mountain Holds | 3 | 39 | 0 | 0.7 | 1.5 | 0 | 52 | -52 | 2 of 2 | 0 of 2 | -105 | +0 |
| Mine | Empire of Man | 5 | 182 | 99 | 2.2 | 1.1 | 45 | 17 | +28 | 3 of 11 | 8 of 11 | +0 | +31 |
| Mine | Grand Cathay | 4 | 465 | 297 | 3.0 | 1.1 | 99 | 14 | +85 | 6 of 12 | 8 of 12 | +0 | +93 |
| Mine | High Elf Realms | 4 | 52 | 552 | 3.8 | 1.1 | 147 | 4 | +143 | 6 of 15 | 11 of 15 | +272 | +123 |
| Mine | Kingdom of Bretonnia | 1 | 0 | 272 | 5.0 | 1.0 | 54 | 0 | +54 | 3 of 5 | 4 of 5 | - | +54 |
| Mine | Lizardmen | 1 | 65 | 850 | 3.0 | 1.3 | 283 | 0 | +283 | 1 of 3 | 3 of 3 | +392 | +229 |
| Mine | Ogre Kingdoms | 1 | 605 | 0 | 1.0 | 1.0 | 0 | 34 | -34 | 0 of 1 | 0 of 1 | - | -34 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 1334 | 7.0 | 1.1 | 191 | 16 | +175 | 4 of 7 | 5 of 7 | +540 | +114 |
| Mine | Skaven | 2 | 58 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 1 of 2 | 1 of 2 | - | +0 |
| Mine | Tomb Kings of Khemri | 2 | 20 | 1244 | 4.0 | 1.4 | 311 | 54 | +257 | 6 of 8 | 7 of 8 | +960 | +22 |
| Mine | Vampire Counts | 2 | 0 | 788 | 3.0 | 1.0 | 262 | 0 | +262 | 2 of 6 | 6 of 6 | - | +262 |
| Mine | Warriors of Chaos | 1 | 0 | 430 | 4.0 | 1.0 | 108 | 0 | +108 | 1 of 4 | 3 of 4 | - | +108 |
| Mine | Wood Elf Realms | 1 | 268 | 115 | 4.0 | 1.0 | 29 | 152 | -124 | 2 of 4 | 1 of 4 | - | -124 |
| **Mine** | all armies | 36 | 165 | 344 | 2.4 | 1.1 | 141 | 20 | +121 | 41 of 88 | 64 of 88 | +383 | +87 |
| Opponent | Empire of Man | 1 | 460 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Grand Cathay | 1 | 0 | 375 | 4.0 | 1.0 | 94 | 0 | +94 | 0 of 4 | 4 of 4 | - | +94 |
| Opponent | High Elf Realms | 3 | 50 | 742 | 3.7 | 1.0 | 202 | 0 | +202 | 6 of 11 | 8 of 11 | - | +202 |
| Opponent | Kingdom of Bretonnia | 2 | 0 | 278 | 2.5 | 1.0 | 111 | 0 | +111 | 0 of 5 | 5 of 5 | - | +111 |
| Opponent | Skaven | 7 | 51 | 29 | 1.4 | 1.0 | 20 | 21 | -0 | 5 of 10 | 7 of 10 | - | -0 |
| Opponent | Tomb Kings of Khemri | 3 | 369 | 416 | 4.0 | 1.2 | 104 | 16 | +88 | 5 of 12 | 6 of 12 | +304 | +44 |
| Opponent | Vampire Counts | 4 | 0 | 397 | 3.5 | 1.2 | 113 | 30 | +84 | 7 of 14 | 11 of 14 | +131 | +71 |
| Opponent | Warriors of Chaos | 10 | 6 | 180 | 2.1 | 1.0 | 86 | 53 | +32 | 8 of 21 | 14 of 21 | +85 | +30 |
| Opponent | Wood Elf Realms | 5 | 22 | 289 | 4.2 | 1.1 | 69 | 30 | +39 | 6 of 21 | 13 of 21 | +63 | +35 |
| **Opponent** | all armies | 36 | 62 | 262 | 2.7 | 1.1 | 96 | 26 | +70 | 37 of 98 | 68 of 98 | +142 | +63 |

### Effective charges: h3-opp-efe7e34-p4

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 3 | 1 (net -52) | 0 | 0 | 1 (net +80) | 0 | 0 | 1 | 0% (0 of 2) |
| Mine | Chaos Dwarfs | 5 | 0 | 0 | 0 | 0 | 1 (net +0) | 4 (net +323) | 0 | 0% (0 of 5) |
| Mine | Dwarfen Mountain Holds | 2 | 1 (net -105) | 0 | 0 | 0 | 0 | 1 (net +0) | 0 | 0% (0 of 2) |
| Mine | Empire of Man | 11 | 1 (net -189) | 0 | 1 (net +0) | 2 (net +126) | 2 (net +60) | 4 (net +31) | 1 | 10% (1 of 10) |
| Mine | Grand Cathay | 12 | 3 (net +0) | 0 | 2 (net +72) | 3 (net +227) | 1 (net +110) | 3 (net +29) | 0 | 17% (2 of 12) |
| Mine | High Elf Realms | 15 | 5 (net +303) | 0 | 2 (net +204) | 1 (net +0) | 2 (net +56) | 5 (net +22) | 0 | 13% (2 of 15) |
| Mine | Kingdom of Bretonnia | 5 | 0 | 0 | 0 | 2 (net +0) | 2 (net +136) | 1 (net +0) | 0 | 0% (0 of 5) |
| Mine | Lizardmen | 3 | 0 | 0 | 0 | 1 (net +392) | 1 (net +38) | 1 (net +420) | 0 | 0% (0 of 3) |
| Mine | Orc & Goblin Tribes | 7 | 0 | 0 | 1 (net +392) | 0 | 0 | 2 (net +366) | 4 | 33% (1 of 3) |
| Mine | Skaven | 2 | 1 (net +0) | 0 | 1 (net +0) | 0 | 0 | 0 | 0 | 50% (1 of 2) |
| Mine | Tomb Kings of Khemri | 8 | 2 (net +608) | 0 | 1 (net +931) | 1 (net +200) | 0 | 3 (net +46) | 1 | 14% (1 of 7) |
| Mine | Vampire Counts | 6 | 1 (net +589) | 0 | 0 | 0 | 3 (net +292) | 1 (net +111) | 1 | 0% (0 of 5) |
| Mine | Warriors of Chaos | 4 | 1 (net +0) | 0 | 0 | 1 (net +116) | 0 | 2 (net +157) | 0 | 0% (0 of 4) |
| Mine | Wood Elf Realms | 4 | 1 (net +0) | 0 | 0 | 0 | 0 | 1 (net +115) | 2 | 0% (0 of 2) |
| Opponent | Grand Cathay | 4 | 1 (net +0) | 0 | 0 | 3 (net +125) | 0 | 0 | 0 | 0% (0 of 4) |
| Opponent | High Elf Realms | 11 | 2 (net +468) | 1 (net +476) | 0 | 0 | 1 (net +55) | 5 (net +103) | 2 | 0% (0 of 9) |
| Opponent | Kingdom of Bretonnia | 5 | 0 | 0 | 0 | 3 (net +140) | 2 (net +68) | 0 | 0 | 0% (0 of 5) |
| Opponent | Skaven | 10 | 4 (net -1) | 1 (net +0) | 3 (net +0) | 0 | 0 | 2 (net +0) | 0 | 30% (3 of 10) |
| Opponent | Tomb Kings of Khemri | 12 | 3 (net +65) | 0 | 4 (net +29) | 2 (net +48) | 1 (net +802) | 2 (net -78) | 0 | 33% (4 of 12) |
| Opponent | Vampire Counts | 14 | 1 (net +0) | 1 (net +0) | 4 (net +31) | 1 (net +0) | 2 (net +151) | 4 (net +156) | 1 | 31% (4 of 13) |
| Opponent | Warriors of Chaos | 21 | 4 (net -66) | 0 | 2 (net -10) | 3 (net +186) | 4 (net +68) | 6 (net +52) | 2 | 11% (2 of 19) |
| Opponent | Wood Elf Realms | 21 | 5 (net -25) | 0 | 0 | 6 (net +39) | 5 (net +181) | 3 (net +103) | 2 | 0% (0 of 19) |

### Charged fights, damage counted: h3-opp-efe7e34-p4

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 17 | 371 | 407 | +175 | 216 | 77 | +140 | +37.6 |
| Mine | Effective (55-75%) | 8 | 362 | 297 | +234 | 253 | 49 | +204 | +56.4 |
| Mine | 76-89% | 12 | 385 | 248 | +143 | 180 | 43 | +136 | +35.5 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 28 | 312 | 187 | +123 | 152 | 24 | +128 | +40.9 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 12 | 340 | 79 | +127 | 129 | 17 | +112 | +32.8 |
| Mine | No odds | 11 | 209 | 207 | -83 | 33 | 141 | -108 | -51.8 |
| Mine | All fights | 88 | 329 | 236 | +121 | 159 | 53 | +106 | +32.4 |
| Opponent | Long shot (under 50%) | 20 | 230 | 318 | +37 | 124 | 87 | +37 | +16.0 |
| Opponent | 50-54% | 3 | 191 | 112 | +159 | 170 | 5 | +164 | +86.3 |
| Opponent | Effective (55-75%) | 13 | 229 | 218 | +17 | 97 | 32 | +65 | +28.2 |
| Opponent | 76-89% | 18 | 330 | 153 | +93 | 98 | 18 | +80 | +24.1 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 22 | 274 | 192 | +73 | 119 | 20 | +99 | +36.3 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 15 | 470 | 99 | +165 | 189 | 27 | +162 | +34.5 |
| Opponent | No odds | 7 | 242 | 241 | -47 | 71 | 98 | -27 | -11.3 |
| Opponent | All fights | 98 | 295 | 201 | +70 | 122 | 41 | +81 | +27.5 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| h3-opp-efe7e34-p4 | move | 324 | 63 (19%) | 41 (13%) | 36 (11%) | 225 (69%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0115, L0132, L2528, L2635 |
| Charmed Shield | Opponent | L0625, L0927, L1524, L2125, L3334 |
| Clockwork Compass | Mine | L1221 |
| Elixir of Power | Mine | L1128, L1920 |
| Fistful of Laurels | Mine | L1820 |
| Horn of the Wild Hunt | Mine | L3334 |
| Horn of the Wild Hunt | Opponent | L0333 |
| Invocation of Nehek | Mine | L2528 |
| Invocation of Nehek | Opponent | L0625, L0927, L1524, L2125 |
| Opal Amulet | Mine | L1428 |
| Opal Amulet | Opponent | L0714 |
| Periapt of Soul Exchange | Mine | L2022, L2125 |
| Periapt of Soul Exchange | Opponent | L0420, L0820, L1020, L1221, L1720, L1820, L1920 |
| Ring of Doom | Mine | L0216, L0232, L1128, L1221, L1524, L3334 |
| Ring of Doom | Opponent | L0115, L0333, L1315, L2931 |
| Ring of Jet | Mine | L1020, L1035, L1128, L1221 |
| Ring of Jet | Opponent | L0910 |
| Standard of the Fell Warrior | Mine | L1315, L1332 |
| Storm Daemon (Renegade 2.0) | Mine | L2125 |
| Storm Daemon (Renegade 2.0) | Opponent | L1221 |
| Twice-Blessed Armour | Mine | L0714, L0730, L1020, L1035 |
| Twice-Blessed Armour | Opponent | L0910 |
| Witch Hunter's Ward | Mine | L0714, L0730, L0820 |

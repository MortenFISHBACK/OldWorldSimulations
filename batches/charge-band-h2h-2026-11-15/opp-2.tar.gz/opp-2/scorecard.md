# Doctrine scorecard: cb-h2h-opp-24b8cfb-p2

### Scorecard: cb-h2h-opp-24b8cfb-p2

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0106 | 4 | 1 | Mine | no | 0 | 5 | 0 | 2 | 0 | 0 | 0 | 0 |
| L0106 | 4 | 1 | Opponent | no | 0 | 2 | 1 | 1 | 0 | 0 | 0 | 981 |
| L0122 | 2 | 1 | Mine | - | - | 6 | 3 | 2 | 1 | 0 | 0 | 0 |
| L0122 | 2 | 1 | Opponent | - | - | 2 | 2 | 2 | 0 | 0 | 0 | 0 |
| L0206 | 2 | 1 | Mine | - | - | 4 | 2 | 1 | 0 | 0 | 0 | 0 |
| L0206 | 2 | 1 | Opponent | - | - | 2 | 2 | 1 | 0 | 0 | 0 | 615 |
| L0222 | 6 | 1 | Mine | no | 2 | 3 | 2 | 4 | 0 | 0 | 0 | 170 |
| L0222 | 6 | 1 | Opponent | no | 8 | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L0307 | 1 | 1 | Mine | no | 0 | 3 | 2 | 1 | 0 | 0 | 0 | 590 |
| L0307 | 1 | 1 | Opponent | yes | 5 | 2 | 1 | 1 | 2 | 0 | 0 | 420 |
| L0323 | 5 | 1 | Mine | no | - | - | 1 | 2 | 0 | 0 | 0 | 590 |
| L0323 | 5 | 1 | Opponent | yes | - | 2 | 3 | 2 | 1 | 0 | 0 | 0 |
| L0409 | 1 | 1 | Mine | no | 2 | 2 | 4 | 0 | 0 | 0 | 0 | 0 |
| L0409 | 1 | 1 | Opponent | no | 7 | - | 0 | 0 | 0 | 0 | 0 | 821 |
| L0425 | 5 | 1 | Mine | yes | - | 2 | 2 | 4 | 0 | 0 | 0 | 0 |
| L0425 | 5 | 1 | Opponent | yes | - | 2 | 3 | 5 | 0 | 0 | 0 | 0 |
| L0512 | 2 | 1 | Mine | - | - | - | 2 | 1 | 0 | 0 | 0 | 1448 |
| L0512 | 2 | 1 | Opponent | - | - | 2 | 2 | 2 | 2 | 0 | 0 | 330 |
| L0528 | 6 | 1 | Mine | no | 0 | 4 | 1 | 1 | 0 | 0 | 0 | 593 |
| L0528 | 6 | 1 | Opponent | no | 9 | 5 | 2 | 2 | 0 | 0 | 0 | 0 |
| L0616 | 4 | 1 | Mine | no | 0 | 3 | 1 | 1 | 0 | 0 | 0 | 615 |
| L0616 | 4 | 1 | Opponent | no | 0 | 2 | 0 | 0 | 1 | 0 | 0 | 200 |
| L0632 | 2 | 1 | Mine | - | - | 2 | 3 | 0 | 0 | 0 | 0 | 743 |
| L0632 | 2 | 1 | Opponent | - | - | 2 | 3 | 2 | 1 | 0 | 0 | 170 |
| L0721 | 1 | 1 | Mine | yes | 0 | 2 | 4 | 1 | 0 | 0 | 0 | 420 |
| L0721 | 1 | 1 | Opponent | no | 0 | - | 2 | 6 | 0 | 0 | 0 | 290 |
| L0810 | 6 | 1 | Mine | no | 0 | 2 | 1 | 3 | 0 | 0 | 0 | 605 |
| L0810 | 6 | 1 | Opponent | no | 20 | 2 | 4 | 1 | 1 | 0 | 0 | 330 |
| L0827 | 5 | 1 | Mine | no | - | 3 | 1 | 1 | 1 | 0 | 0 | 881 |
| L0827 | 5 | 1 | Opponent | yes | - | 2 | 4 | 5 | 0 | 0 | 0 | 0 |
| L0918 | 6 | 1 | Mine | no | 0 | 3 | 2 | 0 | 0 | 0 | 0 | 420 |
| L0918 | 6 | 1 | Opponent | no | 16 | 2 | 5 | 2 | 0 | 0 | 0 | 419 |
| L0934 | 4 | 1 | Mine | no | 0 | 1 | 1 | 0 | 0 | 0 | 0 | 619 |
| L0934 | 4 | 1 | Opponent | no | 0 | 2 | 6 | 3 | 0 | 0 | 0 | 0 |
| L1026 | 6 | 1 | Mine | no | 1 | 2 | 5 | 0 | 0 | 0 | 0 | 456 |
| L1026 | 6 | 1 | Opponent | no | 2 | 3 | 3 | 2 | 1 | 0 | 0 | 0 |
| L1118 | 2 | 1 | Mine | - | - | 2 | 6 | 1 | 0 | 0 | 0 | 330 |
| L1118 | 2 | 1 | Opponent | - | - | - | 3 | 0 | 0 | 0 | 0 | 459 |
| L1135 | 1 | 1 | Mine | yes | 3 | 2 | 3 | 0 | 0 | 0 | 0 | 501 |
| L1135 | 1 | 1 | Opponent | yes | 0 | 4 | 2 | 3 | 0 | 0 | 0 | 0 |
| L1228 | 4 | 1 | Mine | no | 4 | 2 | 2 | 0 | 0 | 0 | 0 | 524 |
| L1228 | 4 | 1 | Opponent | no | 7 | 4 | 1 | 1 | 0 | 0 | 0 | 111 |
| L1323 | 3 | 1 | Mine | no | 1 | 2 | 5 | 0 | 0 | 0 | 0 | 140 |
| L1323 | 3 | 1 | Opponent | no | 0 | 2 | 5 | 1 | 1 | 0 | 0 | 0 |
| L1418 | 2 | 1 | Mine | - | - | 2 | 3 | 2 | 0 | 0 | 0 | 0 |
| L1418 | 2 | 1 | Opponent | - | - | - | 3 | 1 | 1 | 0 | 0 | 539 |
| L1435 | 1 | 1 | Mine | no | 0 | 3 | 3 | 1 | 0 | 0 | 0 | 0 |
| L1435 | 1 | 1 | Opponent | no | 0 | 3 | 5 | 1 | 0 | 0 | 0 | 0 |
| L1531 | 1 | 1 | Mine | no | 0 | 2 | 4 | 1 | 1 | 0 | 0 | 0 |
| L1531 | 1 | 1 | Opponent | no | 8 | 2 | 2 | 1 | 2 | 0 | 0 | 170 |
| L1629 | 3 | 1 | Mine | no | 2 | 1 | 3 | 1 | 0 | 0 | 0 | 200 |
| L1629 | 3 | 1 | Opponent | no | 0 | 2 | 5 | 1 | 0 | 0 | 0 | 170 |
| L1727 | 5 | 1 | Mine | yes | - | 3 | 0 | 1 | 0 | 0 | 0 | 135 |
| L1727 | 5 | 1 | Opponent | yes | - | 2 | 5 | 1 | 1 | 0 | 0 | 0 |
| L1827 | 3 | 1 | Mine | no | 0 | - | 3 | 1 | 0 | 0 | 0 | 0 |
| L1827 | 3 | 1 | Opponent | no | 6 | 2 | 4 | 2 | 0 | 0 | 0 | 0 |
| L1927 | 1 | 1 | Mine | no | 1 | 1 | 2 | 0 | 0 | 0 | 0 | 0 |
| L1927 | 1 | 1 | Opponent | no | 0 | 2 | 4 | 3 | 0 | 0 | 0 | 0 |
| L2029 | 1 | 1 | Mine | no | 0 | - | 1 | 2 | 0 | 0 | 0 | 210 |
| L2029 | 1 | 1 | Opponent | no | 0 | 2 | 2 | 0 | 0 | 0 | 0 | 170 |
| L2131 | 1 | 1 | Mine | yes | 6 | - | 4 | 2 | 1 | 0 | 0 | 290 |
| L2131 | 1 | 1 | Opponent | no | 0 | 2 | 2 | 0 | 1 | 0 | 0 | 0 |
| L2235 | 3 | 1 | Mine | no | 1 | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L2235 | 3 | 1 | Opponent | no | 0 | 3 | 2 | 1 | 1 | 0 | 0 | 126 |
| L2429 | 5 | 1 | Mine | no | - | 3 | 4 | 1 | 1 | 0 | 0 | 0 |
| L2429 | 5 | 1 | Opponent | no | - | 3 | 3 | 3 | 1 | 0 | 0 | 0 |
| L2535 | 3 | 1 | Mine | no | 9 | 3 | 1 | 1 | 1 | 0 | 0 | 0 |
| L2535 | 3 | 1 | Opponent | no | 0 | 1 | 5 | 0 | 0 | 0 | 0 | 0 |
| L2735 | 5 | 1 | Mine | no | - | 4 | 2 | 1 | 1 | 0 | 0 | 0 |
| L2735 | 5 | 1 | Opponent | yes | - | 1 | 6 | 3 | 1 | 0 | 0 | 0 |
| L3033 | 3 | 1 | Mine | yes | 2 | 2 | 2 | 1 | 1 | 0 | 0 | 0 |
| L3033 | 3 | 1 | Opponent | no | 1 | 1 | 6 | 2 | 0 | 0 | 0 | 144 |
| **Average** | | | Mine | 20% | 1.4 | 2.6 | 2.5 | 1.1 | 0.2 | 0.0 | 0.0 | 291.1 |
| **Average** | | | Opponent | 23% | 3.7 | 2.2 | 3.1 | 1.7 | 0.5 | 0.0 | 0.0 | 179.6 |

### KPIs: cb-h2h-opp-24b8cfb-p2

Rules off - Mine only: CHARGE BAND, JOINT KNOWS CHALLENGE, REFUSING RETIRES, BLOWS WHERE AIMED, SPELLS IN THE FIGHT, CHARGER SLAIN LOST, WIDER SPREAD.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 28% (50 of 180) | 14% (24 of 176) | 21% (74 of 356) |
| Winner chose to follow up after the loser gave ground |  | 94% (61 of 65); on the table 94% | 97% (61 of 63); on the table 97% | 95% (122 of 128); on the table 95% |
| Winner chose to pursue after the loser fell back in good order |  | 100% (11 of 11); on the table 100% | 71% (15 of 21); on the table 86% | 81% (26 of 32); on the table 91% |
| Winner chose to pursue after the loser fled |  | 74% (28 of 38); on the table 74% | 71% (27 of 38); on the table 82% | 72% (55 of 76); on the table 78% |
| Winner chose to follow up or pursue (all three) |  | 88% (100 of 114); on the table 88% | 84% (103 of 122); on the table 90% | 86% (203 of 236); on the table 89% |
| Magic missiles tried each own turn | 50%+ | 35% (121 of 342) | 31% (49 of 156) | 34% (170 of 498) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 49% (121 of 247) | 44% (49 of 111) | 47% (170 of 358) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 64% (14 of 22) | 65% (32 of 49) | 65% (46 of 71) |
| Points that never fought | lower | 35% (24895 of 71583) | 37% (26466 of 71989) | 36% (51361 of 143572) |
|   infantry points that never fought | lower | 43% (7073 of 16324) | 59% (8323 of 14029) | 51% (15396 of 30353) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 62% (175 of 284) | 57% (168 of 297) | 59% (343 of 581) |
| Bound items with a magic missile used (at least once a game) |  | 90% (18 of 20); 1.6 uses a game | 78% (14 of 18); 1.2 uses a game | 84% (32 of 38); 1.4 uses a game |
| Bound items with another spell used |  | 72% (13 of 18); 0.7 uses a game | 50% (1 of 2); 0.1 uses a game | 70% (14 of 20); 0.4 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 55% (11 of 20); 0.3 uses a game | 29% (2 of 7); 0.1 uses a game | 48% (13 of 27); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 56% (33825 of 60231) | 49% (31284 of 63281) | 53% (65109 of 123512) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.7 (28%) | 1.0 (33%) | 2.7 (30%) |
| MARCHED: its unit marched | 1.3 (22%) | 0.4 (12%) | 1.7 (19%) |
| CHARGED: its unit charged | 0.2 (4%) | 0.1 (3%) | 0.3 (4%) |
| IN COMBAT: engaged in combat | 1.6 (26%) | 0.6 (21%) | 2.2 (25%) |
| REAR RANK: in a rear rank | 0.1 (1%) | 0.2 (6%) | 0.2 (2%) |
| FLEEING: fleeing | 0.1 (1%) | 0.0 (1%) | 0.1 (1%) |
| GONE: slain | 0.7 (11%) | 0.5 (17%) | 1.2 (13%) |
| OFF THE TABLE: off the table or not arrived | 0.2 (4%) | 0.1 (3%) | 0.3 (4%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.0 (1%) | 0.1 (1%) |
| NOT OFFERED: not in the cast list | 0.1 (2%) | 0.1 (4%) | 0.2 (2%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.1 | 1.7 | 1.3 | 4.7 | 0.3 | 2.3 |
| not cast | 3.8 | 3.2 | 3.7 | 9.1 | 2.0 | 19.4 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.1 (2%) | 0.0 (0%) | 0.0 (0%) | 1.9 (10%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.7 (52%) | 0.3 (8%) | 2.7 (30%) | 0.5 (26%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.7 (19%) | 0.4 (19%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (4%) | 0.0 (1%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.1 (4%) | 0.6 (19%) | 0.5 (14%) | 2.2 (25%) | 0.3 (15%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.5 (13%) | 0.3 (9%) | 0.4 (11%) | 0.2 (2%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.3 (7%) | 0.1 (2%) | 0.1 (4%) | 0.1 (1%) | 0.0 (0%) | 0.2 (1%) |
| GONE: slain | 0.6 (17%) | 0.3 (9%) | 0.6 (17%) | 1.2 (13%) | 0.4 (19%) | 3.2 (16%) |
| OFF THE TABLE: off the table or not arrived | 0.1 (1%) | 0.1 (3%) | 0.1 (2%) | 0.3 (4%) | 0.0 (0%) | 0.2 (1%) |
| STUPIDITY: Stupidity | 0.1 (3%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.3 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (4%) | 0.1 (3%) | 0.0 (0%) | 0.0 (0%) | 0.4 (18%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (2%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.9 (50%) | 0.1 (4%) | 1.6 (42%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 13.6 (70%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.7 a game | 0.7 a game | 0.7 a game |
| stood (cast and not dispelled) | 48% (12 of 25) | 52% (13 of 25) | 50% (25 of 50) |
| the unit moved after it | 67% (8 of 12) | 54% (7 of 13) | 60% (15 of 25) |
| it charged on its next turn | 8% (1 of 12) | 8% (1 of 13) | 8% (2 of 25) |
| the enemy charged it first | 0% (0 of 12) | 23% (3 of 13) | 12% (3 of 25) |
| it fought by the end of its next turn | 0% (0 of 12) | 23% (3 of 13) | 12% (3 of 25) |
| it moved out of a charge the enemy had planned (not charged first) | 25% (3 of 12) | 8% (1 of 13) | 16% (4 of 25) |
| none of these (no charge, no fight, no charge escaped) | 67% (8 of 12) | 62% (8 of 13) | 64% (16 of 25) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 64% (559 of 876) | 52% (413 of 797) | 58% (972 of 1673) |
|   cavalry | 59% (47 of 80) | 59% (102 of 172) | 59% (149 of 252) |
|   character | 50% (54 of 109) | 24% (27 of 114) | 36% (81 of 223) |
|   chariot | 52% (53 of 102) | 66% (27 of 41) | 56% (80 of 143) |
|   infantry | 56% (146 of 262) | 49% (152 of 311) | 52% (298 of 573) |
|   monster | 45% (22 of 49) | 44% (16 of 36) | 45% (38 of 85) |
|   war machine | 86% (237 of 274) | 72% (89 of 123) | 82% (326 of 397) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.4 (27%) | 2.2 (21%) | 4.6 (24%) |
| CHARGED: it charged | 1.5 (17%) | 2.1 (19%) | 3.5 (18%) |
| FLEEING: it fled or was fleeing | 0.0 (0%) | 0.1 (1%) | 0.1 (1%) |
| IN COMBAT: it fought this turn or the last | 1.0 (11%) | 0.7 (7%) | 1.7 (9%) |
| MOVED: a war machine that moved | 0.1 (1%) | 0.0 (0%) | 0.1 (0%) |
| NO TARGET IN RANGE | 1.5 (17%) | 2.1 (19%) | 3.6 (18%) |
| ONLY IN COMBAT: the only targets were in combat | 0.5 (5%) | 0.5 (5%) | 1.0 (5%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.3 (15%) | 2.2 (20%) | 3.4 (18%) |
| SHELTERED: the target was sheltered | 0.2 (3%) | 0.2 (2%) | 0.4 (2%) |
| STUPIDITY | 0.0 (0%) | 0.0 (0%) | 0.1 (0%) |
| OTHER BAR | 0.3 (3%) | 0.6 (5%) | 0.9 (4%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 6.5 | 1.5 | 82% | 4.0 pts | 26 pts |
| character | 2.6 | 0.6 | 82% | 7.3 pts | 19 pts |
| chariot | 2.2 | 1.2 | 69% | 13.8 pts | 31 pts |
| infantry | 11.1 | 4.6 | 70% | 10.4 pts | 115 pts |
| monster | 1.3 | 0.2 | 85% | 3.4 pts | 4 pts |
| war machine | 9.1 | 7.1 | 64% | 21.3 pts | 193 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.6 | 6.5 | 5.6 |
| Charges that made contact a game | 3.5 | 4.8 | 4.1 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.69 declared, 0.58 contact (26 units) | 0.77 declared, 0.62 contact (13 units) | 0.72 declared, 0.59 contact (39 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.57 declared, 0.57 contact (7 units) | 1.58 declared, 1.42 contact (12 units) | 1.21 declared, 1.11 contact (19 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.58 declared, 0.43 contact (247 units) | 0.72 declared, 0.52 contact (287 units) | 0.66 declared, 0.48 contact (534 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 63% (46 of 73) | 56% (10 of 18) | 42% (5 of 12) | 59% (61 of 103) |
| Character in a unit | 97% (28 of 29) | 79% (15 of 19) | 50% (2 of 4) | 87% (45 of 52) |
| Character on its own | 65% (28 of 43) | 49% (17 of 35) | 23% (14 of 62) | 42% (59 of 140) |
| Chariot | 88% (15 of 17) | 85% (11 of 13) | - | 87% (26 of 30) |
| Infantry | 51% (48 of 94) | 53% (18 of 34) | 33% (1 of 3) | 51% (67 of 131) |
| Monster | 55% (16 of 29) | 89% (8 of 9) | - | 63% (24 of 38) |
| Monstrous | 43% (6 of 14) | 64% (9 of 14) | - | 54% (15 of 28) |
| War Machines | 77% (44 of 57) | 100% (2 of 2) | - | 78% (46 of 59) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 94% (17 of 18); on the table 94% | 27% (28 of 102) | 62% | 77% (17 of 22) | 83% (5 of 6); 3.8 uses a game | 100% (2 of 2); 1.0 uses a game | 83% (5 of 6); 1.2 uses a game |
| Chaos Dwarfs | 4 | 100% (7 of 7); on the table 100% | 39% (14 of 36) | 51% | 72% (23 of 32) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
| Dwarfen Mountain Holds | 6 | 80% (8 of 10); on the table 80% | - | 52% | 65% (35 of 54) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 7 | 74% (17 of 23); on the table 74% | 42% (20 of 48) | 44% | 63% (48 of 76) | 0.0 uses a game | 100% (2 of 2); 0.9 uses a game | 50% (2 of 4); 0.3 uses a game |
| Grand Cathay | 6 | 93% (26 of 28); on the table 96% | 35% (48 of 138) | 37% | 43% (23 of 54) | 86% (12 of 14); 6.2 uses a game | 50% (1 of 2); 0.2 uses a game | 0% (0 of 6); 0.0 uses a game |
| High Elf Realms | 4 | 83% (10 of 12); on the table 83% | 22% (4 of 18) | 11% | 52% (17 of 33) | 100% (3 of 3); 2.2 uses a game | 64% (9 of 14); 4.0 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 2 | 100% (4 of 4); on the table 100% | - | 46% | 42% (5 of 12) | 0.0 uses a game | 0.0 uses a game | 100% (2 of 2); 1.0 uses a game |
| Lizardmen | 1 | 100% (9 of 9); on the table 100% | - | 26% | 43% (3 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 4 | 100% (9 of 9); on the table 100% | 0% (0 of 18) | 25% | 82% (23 of 28) | 100% (4 of 4); 2.5 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 1 | 100% (1 of 1); on the table 100% | 17% (2 of 12) | 0% | 25% (2 of 8) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Skaven | 3 | 88% (7 of 8); on the table 88% | 61% (11 of 18) | 40% | 72% (18 of 25) | 100% (2 of 2); 2.0 uses a game | 0.0 uses a game | 67% (2 of 3); 0.7 uses a game |
| Tomb Kings of Khemri | 5 | 85% (11 of 13); on the table 85% | - | 35% | 40% (10 of 25) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 9 | 79% (30 of 38); on the table 89% | 35% (23 of 66) | 23% | 67% (36 of 54) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 9 | 78% (21 of 27); on the table 85% | 56% (10 of 18) | 28% | 47% (34 of 73) | 100% (2 of 2); 0.8 uses a game | 0.0 uses a game | 100% (1 of 1); 0.1 uses a game |
| Wood Elf Realms | 7 | 90% (26 of 29); on the table 90% | 42% (10 of 24) | 38% | 63% (49 of 78) | 57% (4 of 7); 2.4 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (cb-h2h-opp-24b8cfb-p2, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 52% (54) | 55% (40) | 53% (94) |
| ...free all their last turn and able to turn (per game) | 0.78 | 0.69 | 1.47 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.33 | 0.22 | 0.56 |
| ...with the charger already in that arc before they moved (per game) | 0.64 | 0.42 | 1.06 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 2.06 | 1.72 | 3.78 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 1.14 | 1.19 | 2.33 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 5.86 | 4.53 | 10.39 |

### Quality by phase: cb-h2h-opp-24b8cfb-p2

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.8 | 3.3 |
| Strategy | Charge objectives carried out (made contact) | 55% (74 of 134) | 48% (112 of 232) |
| Strategy | Shoot objectives carried out (shot that target) | 43% (144 of 338) | 48% (109 of 227) |
| Strategy | Close-in objectives charged next turn | 11% (15 of 131) | 18% (45 of 247) |
| Strategy | Support requests answered (helper made contact too) | 72% (13 of 18) | 43% (15 of 35) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (3 of 3) | - |
| Strategy | Hexes on a unit its side charged or shot that turn | 60% (9 of 15) | 72% (13 of 18) |
| Strategy | Joined characters whose unit fought | 38% (19 of 50) | 39% (14 of 36) |
| Strategy | Lone characters that fought | 80% (76 of 95) | 84% (73 of 87) |
| Movement | Charges halted short of contact | 0.1 | 0.4 |
| Movement | Idle units | 1.1 | 1.7 |
| Movement | Points that never moved of their own | 291.1 | 179.6 |
| Movement | Fights charged into per game | 3.0 | 4.1 |
| Movement | Charges with odds: long shots (under 50%) | 10 of 94, net -20 | 26 of 130, net +171 |
| Movement | Charges with odds: sweet spot (55-75%) | 13 of 94, net +144 | 29 of 130, net +41 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 13 of 94, net +90 | 10 of 130, net +84 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 38 of 94, net +128 | 23 of 130, net +74 |
| Shooting | Shots by shooting units (incl. breath weapons) | 9.7 | 9.8 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 42% (145 of 349) | 45% (158 of 352) |
| Shooting | Points destroyed by shooting units | 123.2 | 30.4 |
| Shooting | War machine shots | 6.6 | 2.5 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 51% (120 of 237) | 49% (44 of 89) |
| Shooting | Points destroyed by war machines | 49.6 | 27.0 |
| Magic | Magic missiles cast | 2.2 | 0.9 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 28% (22 of 78) | 52% (16 of 31) |
| Magic | Wounds caused by magic missiles | 3.3 | 1.1 |
| Magic | Wounds caused by other spells | 1.7 | 0.8 |
| Magic | Points destroyed by magic (all spells) | 68.3 | 44.3 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.1 / 0.5 / 0.8 / 0.1 | 1.9 / 0.5 / 0.6 / 0.1 |
| Combat | Points destroyed in combat | 340.4 | 397.9 |
| Combat | Points run down | 81.5 | 101.0 |
| Combat | Net points per charged fight, damage counted | +77 | +88 |
| Combat | Net per 100 charger points, damage counted | +28.2 | +32.4 |
| Combat | First round won (charged fights) | 70% | 68% |
| Combat | Net points per charged fight | +77 | +84 |
| Combat | Net points per supported fight / lone fight | +96 / +73 | +113 / +78 |
| Combat | Charged fights on a top-3 enemy unit | 39 of 108 | 54 of 148 |
| Game | Points lost | 733.2 | 735.4 |
| Game | VP from objectives | 538.9 | 678.3 |
| Game | Lone holders (player turns) | 1.4 | 3.7 |

- Mine won / drew / lost: 11 / 7 / 18 of 36 ended games (of 36); mean margin (Mine - Opponent) -151 VP
- The side that went first won 13 of 29 games with a winner
- Points traded per game (both sides' losses): 1469
- Games not ended: 0; findings 0, warnings 2

### Opponent rules: cb-h2h-opp-24b8cfb-p2

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 0.5 | +0.0 | 0.0 | 0.0 |
| ALREADY CARRIED | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARRIVAL HUNT | 0.0 | +0.0 | 0.0 | 2.5 | 0.1 | +5.2 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.2 | +0.0 | 0.0 | 34.6 | 0.1 | +0.0 | 0.0 | 3.5 |
| BACKUP TARGETS | 1.0 | +7.5 | 0.0 | 13.2 | 0.8 | +6.9 | 0.0 | 32.4 |
| BEST FACING | 0.8 | +24.9 | 0.0 | 19.0 | 0.8 | +27.2 | 0.0 | 64.3 |
| BEST FIRST | 5.3 | +215.8 | 209.3 | 88.0 | 3.4 | +133.4 | 112.7 | 105.5 |
| BEST OVERALL | 0.8 | +61.8 | 0.0 | 25.5 | 0.7 | +49.1 | 0.0 | 34.5 |
| BEST PREY | 0.6 | +28.5 | 22.8 | 2.4 | 0.9 | +37.1 | 23.2 | 8.9 |
| BEST PRIZE | 0.0 | -0.6 | 0.0 | 6.3 | 0.1 | -3.1 | 16.9 | 7.7 |
| BIG CHARACTER SAFETY | 0.2 | -0.5 | 0.0 | 0.0 | 0.1 | -0.1 | 0.0 | 0.0 |
| BLOCKED CHARGE SKIPPED | 0.1 | +0.0 | 3.5 | 5.2 | 0.1 | +0.0 | 12.1 | 9.6 |
| BLOCKED WHEEL | 0.4 | +3.5 | 0.0 | 3.6 | 0.4 | +3.8 | 0.0 | 24.3 |
| BLOWS WHERE AIMED | - | - | - | - | 0.3 | -30.4 | 30.9 | 7.1 |
| BOMBING RUN | 0.1 | +1.1 | 0.0 | 0.0 | - | - | - | - |
| BOUND ASSAILMENT | 0.1 | +0.0 | 0.0 | 10.3 | - | - | - | - |
| CANNON PLAN MISSED | 1.1 | +0.0 | 224.2 | 2.8 | 0.2 | +0.0 | 6.1 | 0.0 |
| CANNON PLANNED TARGET | 4.7 | +171.7 | 365.5 | 95.3 | 2.1 | +70.5 | 60.7 | 13.9 |
| CANNON SIGHT KEPT | 1.3 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 13.1 |
| CARRIES OUT COUNTER | 0.1 | +0.0 | 16.6 | 23.2 | 0.1 | -0.5 | 13.9 | 0.0 |
| CARRIES OUT SET-UP | - | - | - | - | 0.2 | -0.2 | 23.6 | 1.4 |
| CAST JOB | 0.6 | +12.5 | 34.1 | 4.7 | 0.3 | +3.9 | 34.4 | 17.4 |
| CASTER AWAY FROM SCREEN | 0.3 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.4 | +24.1 | 10.8 | 6.1 | 0.1 | +8.1 | 19.3 | 0.0 |
| CASTS AFTER FRIENDS | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 11.2 |
| CASTS FROM BEHIND | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.1 | +4.0 | 0.0 | 0.0 | - | - | - | - |
| CATCH ODDS | - | - | - | - | 0.1 | +4.9 | 0.0 | 0.0 |
| CHAFF PASSED | 0.2 | -0.4 | 5.1 | 0.0 | 0.2 | +0.0 | 0.0 | 5.5 |
| CHAMPION TAKES THE CHALLENGE | 0.0 | +0.1 | 0.0 | 0.0 | - | - | - | - |
| CHARGE BAND | - | - | - | - | 0.2 | +0.0 | 11.5 | 12.9 |
| CHARGE NOW FIRST | 2.7 | +0.0 | 279.3 | 90.6 | 3.6 | +0.0 | 289.0 | 117.0 |
| CHARGE NOW WEIGHED | 0.6 | -36.8 | 10.2 | 3.9 | 0.4 | -45.3 | 7.0 | 28.4 |
| CHARGER SLAIN LOST | - | - | - | - | 0.9 | -19.7 | 78.8 | 26.1 |
| CHARIOT NO STATIC JOB | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHARIOT WIZARD CAREFUL | 0.1 | -1.5 | 0.0 | 0.0 | - | - | - | - |
| CHEAP HELPER | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 13.2 | 0.0 |
| COMBAT PIVOT | 0.5 | +0.0 | 16.1 | 51.2 | 0.5 | +0.0 | 29.3 | 0.0 |
| CONVEYANCE SEARCH | 0.5 | +46.4 | 5.3 | 2.6 | 0.6 | +69.3 | 21.6 | 26.5 |
| COUNTER-CHARGE COVER | 10.2 | +906.0 | 0.0 | 142.4 | 6.8 | +606.7 | 0.0 | 194.4 |
| DEFENSIVE ARMY | 0.3 | +0.0 | 24.1 | 16.7 | 0.1 | +0.0 | 0.0 | 0.0 |
| DEFENSIVE FLOOR | 0.0 | +1.6 | 0.0 | 0.0 | 0.0 | +0.8 | 0.0 | 0.0 |
| EDGE GIVE GROUND | 0.2 | +0.7 | 7.9 | 15.0 | 0.4 | +12.0 | 53.9 | 15.5 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 2.1 | +171.6 | 0.0 | 63.8 | 1.7 | +93.0 | 0.0 | 101.7 |
| FALLBACK BY WORTH | 5.1 | +73.6 | 0.0 | 58.4 | 5.6 | +58.6 | 0.0 | 34.8 |
| FIGHT LIFT | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FIRE AND FLEE | 0.1 | +0.9 | 7.7 | 0.0 | 0.1 | +1.1 | 0.0 | 0.0 |
| FLANK NOT WEIGHED | 6.4 | +0.0 | 0.0 | 112.9 | 4.6 | +0.0 | 0.0 | 164.4 |
| FOCUS FIRE | - | - | - | - | 0.0 | +0.4 | 1.5 | 0.0 |
| FOLLOW UP WEIGHED | 0.9 | +113.8 | 0.0 | 29.3 | 1.1 | +140.8 | 0.0 | 46.2 |
| FRIENDS SHOTS CHECKED | 0.2 | +21.9 | 0.0 | 0.0 | 0.2 | +14.6 | 0.0 | 1.1 |
| GIVES UP | 0.1 | -0.4 | 0.0 | 2.6 | 0.2 | -2.0 | 14.1 | 12.1 |
| GIVES UP ITS SCREEN | - | - | - | - | 0.0 | -0.0 | 3.4 | 0.0 |
| GROUND FLIERS | 0.0 | +0.5 | 0.0 | 0.0 | - | - | - | - |
| HELPER ALREADY ASKED | - | - | - | - | 0.2 | +0.0 | 22.4 | 1.2 |
| HELPER UNSEEN | 0.2 | +0.0 | 70.2 | 15.9 | 0.4 | +0.0 | 25.4 | 5.8 |
| HILL BY ITS CHANCE | 0.4 | -30.8 | 0.0 | 3.4 | 0.5 | -44.4 | 0.0 | 6.3 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HORN WORTH | - | - | - | - | 0.0 | +0.1 | 0.0 | 0.0 |
| HUNT ADVANCE | 0.3 | +1.7 | 38.1 | 1.9 | 0.2 | +1.3 | 0.0 | 0.0 |
| HUNT DROPPED | 0.1 | +0.0 | 7.6 | 4.4 | 0.2 | +0.0 | 0.0 | 5.0 |
| HUNT IN PAIRS | 0.2 | +5.1 | 0.0 | 5.7 | 0.4 | +31.6 | 0.0 | 23.8 |
| HUNT KEPT | 0.2 | +0.9 | 20.6 | 8.3 | 0.1 | +2.2 | 9.2 | 0.0 |
| HUNT RESULT | 0.2 | +15.2 | 23.6 | 5.3 | 0.3 | +37.6 | 0.0 | 5.9 |
| HUNT THE GUNS | 0.2 | +74.8 | 22.8 | 0.0 | 0.3 | +116.3 | 13.8 | 2.9 |
| INVITES THE FIGHT | 1.5 | +26.3 | 67.8 | 15.7 | 1.1 | +17.7 | 45.2 | 36.9 |
| JOINT CHARGE PLAN | 0.0 | +0.1 | 0.0 | 0.0 | 0.1 | +3.3 | 0.0 | 0.0 |
| JOINT KNOWS CHALLENGE | - | - | - | - | 0.2 | -8.0 | 0.0 | 1.8 |
| KEEP FALLS | 0.1 | +3.7 | 0.0 | 0.0 | - | - | - | - |
| KEEPS ITS PREY | 0.1 | +0.9 | 3.3 | 0.0 | - | - | - | - |
| KEEPS ITS TARGET | 1.1 | +33.3 | 100.2 | 46.0 | 2.7 | +80.0 | 198.1 | 94.8 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| KILLS COUNT | 1.6 | +83.6 | 151.3 | 84.9 | 2.8 | +122.7 | 189.1 | 91.6 |
| KILLS COUNT NEXT TURN | 4.7 | +157.1 | 157.8 | 78.5 | 7.2 | +253.8 | 246.4 | 117.9 |
| LONE CHARACTER SAFE SPOT | 0.2 | +19.1 | 3.7 | 0.0 | 0.3 | +2.6 | 0.0 | 4.9 |
| LONE WIZARD HOLDS BACK | 0.1 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 8.1 | 23.6 |
| LONE WIZARD KEPT IN | 0.6 | +39.4 | 0.0 | 0.0 | 0.3 | +23.5 | 0.0 | 0.0 |
| LONG SHOT | 0.5 | +0.4 | 24.6 | 17.1 | 0.7 | +1.2 | 34.8 | 4.7 |
| LOST CHARGE | 3.2 | -50.2 | 84.6 | 22.5 | 2.4 | -41.4 | 85.8 | 98.4 |
| LURE BY WHAT IT DRAWS | 0.1 | -4.2 | 0.0 | 3.1 | 0.1 | -4.8 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 0.2 | +13.7 | 0.0 | 2.9 | 0.4 | +16.7 | 3.2 | 3.1 |
| MANOEUVRE | 0.2 | +8.3 | 0.0 | 14.7 | 0.2 | +10.6 | 0.0 | 3.8 |
| MARCH CHECK | 0.6 | +12.9 | 0.0 | 12.1 | 0.4 | +15.5 | 0.0 | 12.9 |
| MARCH ODDS | 0.3 | +30.3 | 3.1 | 4.6 | 0.3 | +19.9 | 11.0 | 20.3 |
| MARCH OVER CASTS | 0.6 | +58.2 | 0.0 | 12.1 | 0.2 | +11.4 | 0.0 | 19.7 |
| MAX FOR POSITIONING | 4.7 | +158.8 | 0.0 | 49.8 | 4.4 | +171.3 | 0.0 | 105.9 |
| MISSILES IN THE MOVE | 4.2 | +100.0 | 0.0 | 76.3 | 3.0 | +61.8 | 0.0 | 112.1 |
| MISSILES NEXT TURN | 4.7 | +67.9 | 0.0 | 86.8 | 3.4 | +50.1 | 0.0 | 121.2 |
| MODEL FACING | 0.2 | +52.2 | 0.0 | 0.0 | 0.4 | +107.7 | 0.0 | 3.3 |
| MONSTER WIZARD ROAMS | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 24.1 | 10.5 |
| MOVE AND CAST | 0.3 | +16.8 | 0.0 | 9.2 | 0.3 | +29.7 | 0.0 | 9.8 |
| MOVE SPELL IN RANGE | 0.1 | +4.5 | 0.0 | 0.0 | 0.1 | +2.2 | 0.0 | 15.2 |
| MOVE SPELL NOT WORTH | 0.1 | -0.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.3 | -17.1 | 0.0 | 12.5 | 0.1 | -2.8 | 0.0 | 15.2 |
| MOVE SPELL SPOT | 0.2 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE TO CHARGE | 2.7 | +129.2 | 89.8 | 37.0 | 5.3 | +321.6 | 193.4 | 144.9 |
| MOVES UNITS SPELL | 0.1 | +3.4 | 0.0 | 0.0 | - | - | - | - |
| NEEDED THERE | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +2.2 | 1.4 | 0.0 |
| NO RALLY LEFT | 0.1 | +1.7 | 0.0 | 2.4 | - | - | - | - |
| NOT NEEDED | 0.1 | -3.6 | 15.9 | 0.0 | 0.5 | -20.9 | 47.6 | 3.6 |
| NOT TURNED | 5.9 | +107.4 | 0.0 | 95.4 | 4.5 | +77.6 | 0.0 | 117.8 |
| NOT WORTH A CAST | 0.6 | -0.4 | 0.0 | 48.4 | 0.6 | -0.5 | 0.0 | 1.7 |
| OFF BEST | 15.6 | -746.5 | 0.0 | 236.8 | 16.6 | -907.1 | 4.4 | 298.7 |
| OPENS UP | 0.1 | +19.1 | 10.0 | 0.0 | 0.3 | +20.6 | 18.8 | 18.3 |
| OVERRUNS AWAY | 0.5 | +11.1 | 52.1 | 7.8 | 0.7 | +13.5 | 38.2 | 29.9 |
| PATHS CROSS | 2.3 | +151.4 | 0.0 | 14.0 | 2.6 | +160.4 | 0.0 | 78.5 |
| PERIAPT WORTH | 0.0 | +2.8 | 0.0 | 0.0 | 0.0 | +0.2 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.1 | -6.3 | 0.0 | 12.7 | 0.1 | -0.6 | 0.0 | 5.1 |
| PLAN RESULT | 37.1 | +1618.0 | 1561.8 | 944.2 | 41.4 | +1211.2 | 1299.9 | 924.8 |
| PURSUES BIG PREY | 0.2 | -14.1 | 0.0 | 0.0 | - | - | - | - |
| RAIDS THE BAGGAGE NEXT TURN | 0.1 | +5.0 | 0.0 | 3.4 | 0.0 | +2.4 | 0.0 | 0.0 |
| RANDOM MOVE BY FIGURES | 0.6 | +20.7 | 0.0 | 18.6 | 1.4 | +26.0 | 0.0 | 21.5 |
| RANDOM MOVER NO PROMISE | 0.2 | -19.4 | 0.0 | 4.7 | 0.2 | -15.6 | 19.9 | 0.0 |
| REDIRECT BY WHAT IT STOPS | 0.1 | -6.1 | 0.0 | 3.1 | 0.3 | -5.5 | 0.0 | 2.2 |
| REDIRECT COUNTER | 2.0 | +129.8 | 0.0 | 46.9 | 3.3 | +283.4 | 0.0 | 51.9 |
| REDIRECT WEIGHED | 0.2 | +5.5 | 7.3 | 0.0 | 0.5 | +10.6 | 29.1 | 25.2 |
| REFUSING RETIRES | - | - | - | - | 0.2 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | 0.2 | +9.9 | 0.0 | 0.0 | 1.3 | +43.8 | 0.0 | 30.8 |
| RESTRAINS TO SHOOT | 0.1 | +5.0 | 0.0 | 6.5 | 0.1 | +3.9 | 0.0 | 0.0 |
| RISK BY ARC | 2.3 | +80.3 | 226.5 | 79.1 | 4.0 | +115.2 | 289.3 | 117.2 |
| SAFER THAN THE JOB | 1.1 | +65.8 | 0.0 | 26.6 | 1.2 | +79.5 | 0.0 | 42.8 |
| SCOUT SPOT | 0.3 | +0.8 | 0.0 | 0.0 | 0.5 | +2.4 | 0.0 | 0.0 |
| SCOUT WAITS | 0.3 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.2 | -6.7 | 0.0 | 1.2 | 0.3 | -21.7 | 0.0 | 1.2 |
| SEARCH SPOT | 2.7 | +152.4 | 0.0 | 33.6 | 2.3 | +113.3 | 0.0 | 17.5 |
| SECOND HUNTER | 0.1 | -0.7 | 22.8 | 0.9 | 0.1 | -0.4 | 9.2 | 0.0 |
| SELF MOVE SPELL | 0.1 | +7.0 | 0.0 | 20.0 | - | - | - | - |
| SET UP TOGETHER | 0.5 | +25.6 | 0.0 | 9.8 | 2.2 | +132.2 | 48.7 | 44.6 |
| SET-UP ANY TARGET | 0.2 | +19.4 | 0.0 | 0.0 | 0.3 | +40.1 | 0.0 | 7.6 |
| SET-UP MISSED | - | - | - | - | 0.0 | +8.6 | 0.0 | 11.2 |
| SHOOTER COUNTED ONCE | 0.1 | -0.1 | 0.0 | 0.0 | 0.0 | -0.0 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.4 | +0.8 | 0.0 | 0.0 | 0.3 | +0.6 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.0 | +38.6 | 73.9 | 14.6 | 0.8 | +28.8 | 53.3 | 17.8 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| SHOT REPLANNED | 0.8 | +0.0 | 214.6 | 9.3 | 0.3 | +0.0 | 19.9 | 5.2 |
| SHOTS IN THE MOVE | 13.8 | +614.7 | 0.0 | 216.6 | 10.9 | +335.8 | 0.0 | 185.8 |
| SPELL CATCH ODDS | 0.1 | -0.5 | 0.0 | 0.0 | - | - | - | - |
| SPELL SETS UP CHARGE | 0.3 | +56.3 | 0.0 | 0.0 | 0.3 | +40.1 | 0.0 | 7.6 |
| SPELL WORTH | 0.9 | +21.7 | 69.4 | 64.0 | 1.7 | +32.5 | 64.9 | 64.9 |
| SPELLS IN THE FIGHT | - | - | - | - | 0.8 | -9.4 | 43.0 | 22.4 |
| STABLE ROLE | 11.1 | +0.0 | 382.2 | 146.4 | 12.1 | +0.0 | 358.5 | 213.4 |
| STANDS TO CAST | - | - | - | - | 0.0 | +2.5 | 0.0 | 0.0 |
| STAY WEIGHED | 0.0 | +1.9 | 0.0 | 0.0 | - | - | - | - |
| STOPS | 0.1 | +0.9 | 0.0 | 3.2 | 0.2 | +13.4 | 22.9 | 2.9 |
| STOPS SHORT OF THE FLANK | 0.6 | +37.5 | 0.0 | 2.4 | 0.3 | +27.1 | 0.0 | 20.6 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| SUPPORT NARROWED | 6.4 | -43.6 | 441.1 | 143.2 | 7.7 | -51.8 | 426.3 | 164.1 |
| SUPPORTS | 4.2 | +43.6 | 243.1 | 72.1 | 4.5 | +53.2 | 203.7 | 74.5 |
| SURE CHARGE BEATS ADVANCE | 0.2 | -8.8 | 16.2 | 0.0 | 0.1 | -3.8 | 17.4 | 0.0 |
| SURE REACH TOGETHER | 0.6 | +2.9 | 0.0 | 3.1 | 1.1 | +8.2 | 6.5 | 27.8 |
| THROUGH LINE OF FIRE | 0.2 | +7.9 | 0.0 | 0.0 | 0.3 | +7.8 | 0.0 | 1.9 |
| TURN WORTH | 0.5 | -37.3 | 34.5 | 16.6 | 0.2 | -8.6 | 19.4 | 15.8 |
| TWO OR MORE ARRIVE | 0.1 | +0.9 | 0.0 | 1.4 | 0.3 | +1.9 | 0.0 | 7.8 |
| WAIT AFTER COSTS | 5.9 | -227.4 | 204.2 | 63.5 | 8.9 | -391.7 | 337.0 | 216.7 |
| WALKS TO THE FIGHT | 1.7 | +30.1 | 39.8 | 4.6 | 1.7 | +34.2 | 63.4 | 29.6 |
| WAR ENGINE CHARGES | 0.1 | +15.3 | 0.0 | 0.0 | 0.0 | +3.0 | 0.0 | 5.1 |
| WAR ENGINE JOBS | 0.5 | +0.0 | 28.5 | 14.4 | 0.2 | +0.0 | 5.1 | 15.4 |
| WEARS DOWN | 1.2 | +54.7 | 104.6 | 34.7 | 1.8 | +57.1 | 168.9 | 49.7 |
| WHO HITS BACK | 0.3 | +22.2 | 0.0 | 0.0 | 0.3 | +21.9 | 0.0 | 31.9 |
| WHOLE FIGHT | 0.4 | +19.5 | 40.7 | 5.7 | 0.8 | +22.5 | 74.1 | 0.0 |
| WHOLE FIGHT GAIN | 0.4 | +46.2 | 34.4 | 19.6 | 1.0 | +76.9 | 108.3 | 24.8 |
| WIDER SPREAD | - | - | - | - | 4.6 | -9.4 | 376.2 | 86.7 |
| WOUNDED STAYS OUT | 0.0 | +0.0 | 5.7 | 0.0 | 0.0 | +0.0 | 4.5 | 0.0 |

### Rule changes: cb-h2h-opp-24b8cfb-p2

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 1158 | 1158 | 1158 | 32.17 | -59529 | -51.4 |
| BEST FIRST | 312 | 312 | 312 | 8.67 | +12570 | +40.3 |
| SEARCH SPOT | 180 | 180 | 178 | 4.94 | +9618 | +54.0 |
| PATHS CROSS | 177 | 177 | 177 | 4.92 | +11227 | +63.4 |
| COUNTER-CHARGE COVER | 609 | 341 | 150 | 4.17 | +9526 | +63.5 |
| MOVE TO CHARGE | 288 | 287 | 139 | 3.86 | +5293 | +38.1 |
| FACES THE THREAT | 136 | 136 | 136 | 3.78 | +9527 | +70.1 |
| KILLS COUNT NEXT TURN | 428 | 427 | 120 | 3.33 | +3424 | +28.5 |
| SUPPORTS | 311 | 311 | 120 | 3.33 | +1145 | +9.5 |
| SAFER THAN THE JOB | 84 | 84 | 84 | 2.33 | +5228 | +62.2 |
| FALLBACK BY WORTH | 383 | 383 | 72 | 2.00 | +4761 | +66.1 |
| WAIT AFTER COSTS | 534 | 533 | 72 | 2.00 | +1034 | +14.4 |
| CANNON SIGHT KEPT | 70 | 70 | 70 | 1.94 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 69 | 69 | 69 | 1.92 | +9164 | +132.8 |
| SHOTS IN THE MOVE | 888 | 560 | 68 | 1.89 | +1926 | +28.3 |
| WALKS TO THE FIGHT | 120 | 120 | 65 | 1.81 | +781 | +12.0 |
| BEST FACING | 57 | 57 | 57 | 1.58 | +1875 | +32.9 |
| RESERVE FALL BACK | 57 | 57 | 57 | 1.58 | +1932 | +33.9 |
| BEST OVERALL | 52 | 52 | 52 | 1.44 | +3994 | +76.8 |
| ARTILLERY RE-ROLL WEIGHED | 50 | 50 | 50 | 1.39 | +0 | +0.0 |
| MAX FOR POSITIONING | 326 | 199 | 47 | 1.31 | +464 | +9.9 |
| REDIRECT COUNTER | 192 | 100 | 47 | 1.31 | +3685 | +78.4 |
| CANNON PLANNED TARGET | 244 | 244 | 46 | 1.28 | -586 | -12.7 |
| RANDOM MOVE BY FIGURES | 71 | 71 | 46 | 1.28 | +1681 | +36.5 |
| ADVANCE LANE KEPT | 42 | 42 | 42 | 1.17 | +0 | +0.0 |
| RISK BY ARC | 229 | 221 | 41 | 1.14 | +1276 | +31.1 |
| SET UP TOGETHER | 96 | 84 | 41 | 1.14 | +2542 | +62.0 |
| HOLDS AMBUSHERS | 40 | 40 | 40 | 1.11 | +0 | +0.0 |
| SHOT REPLANNED | 39 | 39 | 39 | 1.08 | +0 | +0.0 |
| KILLS COUNT | 155 | 154 | 38 | 1.06 | +1589 | +41.8 |
| MISSILES IN THE MOVE | 260 | 148 | 38 | 1.06 | +665 | +17.5 |
| CHARGE NOW FIRST | 227 | 227 | 36 | 1.00 | -1875 | -52.1 |
| COMBAT PIVOT | 36 | 36 | 36 | 1.00 | +0 | +0.0 |
| CHARGE NOW WEIGHED | 33 | 33 | 33 | 0.92 | +2242 | +68.0 |
| LONE WIZARD KEPT IN | 33 | 33 | 33 | 0.92 | +2266 | +68.7 |
| SHOOTS FROM THE BEST SPOT | 66 | 66 | 33 | 0.92 | +1300 | +39.4 |
| SCOUT WAITS | 32 | 32 | 32 | 0.89 | +0 | +0.0 |
| STOPS SHORT OF THE FLANK | 32 | 32 | 32 | 0.89 | +2324 | +72.6 |
| BLOCKED WHEEL | 29 | 29 | 29 | 0.81 | +263 | +9.1 |
| MARCH CHECK | 33 | 33 | 28 | 0.78 | +828 | +29.6 |
| REDIRECT WEIGHED | 28 | 28 | 28 | 0.78 | +1330 | +47.5 |
| SHOOTERS IN TWO RANKS | 25 | 25 | 25 | 0.69 | +50 | +2.0 |
| WHOLE FIGHT GAIN | 49 | 45 | 23 | 0.64 | +1440 | +62.6 |
| MODEL FACING | 22 | 22 | 22 | 0.61 | +5759 | +261.8 |
| MOVE AND CAST | 22 | 22 | 22 | 0.61 | +1676 | +76.2 |
| INVITES THE FIGHT | 92 | 92 | 21 | 0.58 | +317 | +15.1 |
| MARCH ODDS | 21 | 21 | 21 | 0.58 | +406 | +19.3 |
| WHO HITS BACK | 21 | 21 | 21 | 0.58 | +1071 | +51.0 |
| KEEPS ITS TARGET | 136 | 133 | 17 | 0.47 | +304 | +17.9 |
| CASTER AWAY FROM SCREEN | 16 | 16 | 16 | 0.44 | +0 | +0.0 |
| CHAFF PASSED | 16 | 16 | 16 | 0.44 | -14 | -0.8 |
| FRIENDS SHOTS CHECKED | 16 | 16 | 16 | 0.44 | +1314 | +82.1 |
| LOST CHARGE | 202 | 201 | 16 | 0.44 | +533 | +33.3 |
| THROUGH LINE OF FIRE | 16 | 16 | 16 | 0.44 | +566 | +35.3 |
| BEST PREY | 53 | 53 | 15 | 0.42 | +495 | +33.0 |
| CASTS FROM BEHIND | 15 | 15 | 15 | 0.42 | +0 | +0.0 |
| MANOEUVRE | 16 | 16 | 15 | 0.42 | +683 | +45.5 |
| CAST JOB | 32 | 32 | 14 | 0.39 | +349 | +24.9 |
| SHORT GUN FORWARD | 14 | 14 | 14 | 0.39 | +0 | +0.0 |
| CASTING BLOCK | 17 | 17 | 13 | 0.36 | +620 | +47.7 |
| STUCK PIVOT | 11 | 11 | 11 | 0.31 | +0 | +0.0 |
| BIG CHARACTER SAFETY | 10 | 10 | 10 | 0.28 | -24 | -2.4 |
| SURE CHARGE BEATS ADVANCE | 10 | 10 | 10 | 0.28 | -453 | -45.3 |
| WAR ENGINE JOBS | 24 | 24 | 10 | 0.28 | -561 | -56.1 |
| WEARS DOWN | 108 | 105 | 10 | 0.28 | +281 | +28.1 |
| BLOCKED CHARGE SKIPPED | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| MAKE SURE TOGETHER | 24 | 17 | 9 | 0.25 | +242 | +26.9 |
| RESTRAINS TO SHOOT | 9 | 9 | 9 | 0.25 | +320 | +35.5 |
| OPENS UP | 17 | 17 | 8 | 0.22 | +492 | +61.5 |
| PIVOT GUARDS FLANK | 8 | 8 | 8 | 0.22 | -247 | -30.8 |
| PURSUES BIG PREY | 8 | 8 | 8 | 0.22 | -506 | -63.3 |
| CHARGE BAND | 7 | 7 | 7 | 0.19 | +0 | +0.0 |
| OVERRUNS AWAY | 44 | 41 | 7 | 0.19 | +74 | +10.6 |
| WHOLE FIGHT | 42 | 40 | 7 | 0.19 | +453 | +64.7 |
| BEST PRIZE | 5 | 5 | 5 | 0.14 | -346 | -69.3 |
| BOUND ASSAILMENT | 5 | 5 | 5 | 0.14 | +1 | +0.1 |
| HUNT IN PAIRS | 25 | 13 | 5 | 0.14 | +486 | +97.2 |
| BACKUP TARGETS | 67 | 39 | 4 | 0.11 | +2 | +0.5 |
| FIRE AND FLEE | 4 | 4 | 4 | 0.11 | +75 | +18.8 |
| KEEPS SCOUTS OR AMBUSH | 4 | 4 | 4 | 0.11 | +0 | +0.0 |
| LONE WIZARD HOLDS BACK | 18 | 18 | 4 | 0.11 | -76 | -19.0 |
| MOVES UNITS SPELL | 4 | 4 | 4 | 0.11 | +122 | +30.4 |
| SUPPORT NARROWED | 508 | 508 | 4 | 0.11 | -68 | -17.1 |
| KEEP FALLS | 3 | 3 | 3 | 0.08 | +188 | +62.8 |
| MISSILES NEXT TURN | 289 | 162 | 3 | 0.08 | +6 | +2.1 |
| RAIDS THE BAGGAGE NEXT TURN | 3 | 3 | 3 | 0.08 | +210 | +70.1 |
| SURE REACH TOGETHER | 59 | 37 | 3 | 0.08 | +48 | +16.0 |
| BOMBING RUN | 2 | 2 | 2 | 0.06 | +41 | +20.4 |
| CATCH ODDS | 2 | 2 | 2 | 0.06 | -72 | -36.2 |
| DEFENSIVE ARMY | 13 | 13 | 2 | 0.06 | -97 | -48.3 |
| EDGE GIVE GROUND | 21 | 20 | 2 | 0.06 | +65 | +32.5 |
| HILL BY ITS CHANCE | 32 | 32 | 2 | 0.06 | +54 | +27.2 |
| JOINT CHARGE PLAN | 6 | 6 | 2 | 0.06 | +74 | +36.8 |
| MOVE SPELL IN RANGE | 6 | 5 | 2 | 0.06 | +31 | +15.4 |
| NEEDED THERE | 3 | 3 | 2 | 0.06 | +0 | +0.0 |
| NO RALLY LEFT | 2 | 2 | 2 | 0.06 | +49 | +24.4 |
| PERIAPT WORTH | 2 | 2 | 2 | 0.06 | +108 | +54.1 |
| STOPS | 11 | 11 | 2 | 0.06 | +84 | +42.1 |
| WOUNDED STAYS OUT | 2 | 2 | 2 | 0.06 | -390 | -194.8 |
| BLOWS WHERE AIMED | 11 | 10 | 1 | 0.03 | +125 | +124.7 |
| CARRIES OUT COUNTER | 7 | 7 | 1 | 0.03 | -17 | -16.7 |
| CARRIES OUT SET-UP | 9 | 9 | 1 | 0.03 | -6 | -6.0 |
| DEFENSIVE FLOOR | 2 | 2 | 1 | 0.03 | +16 | +16.2 |
| FOCUS FIRE | 1 | 1 | 1 | 0.03 | +14 | +13.7 |
| HORN WORTH | 1 | 1 | 1 | 0.03 | +3 | +3.0 |
| LONG SHOT | 43 | 43 | 1 | 0.03 | +2 | +2.2 |
| REDIRECT BY WHAT IT STOPS | 15 | 15 | 1 | 0.03 | +3 | +3.4 |
| STANDS TO CAST | 1 | 1 | 1 | 0.03 | -47 | -47.3 |
| STAY WEIGHED | 1 | 1 | 1 | 0.03 | +69 | +69.3 |
| WAR ENGINE CHARGES | 6 | 6 | 1 | 0.03 | +234 | +234.3 |
| WIDER SPREAD | 164 | 159 | 1 | 0.03 | +0 | +0.3 |
| ALREADY CARRIED | 1 | not checked | - | - | - | - |
| ARRIVAL HUNT | 5 | 5 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 48 | 48 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 24 | trace | - | - | - | - |
| CATCH FLIERS | 2 | not checked | - | - | - | - |
| CHAMPION TAKES THE CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| CHARGER SLAIN LOST | 31 | 29 | 0 | 0.00 | - | - |
| CHARIOT NO STATIC JOB | 1 | 1 | 0 | 0.00 | - | - |
| CHARIOT WIZARD CAREFUL | 4 | 4 | 0 | 0.00 | - | - |
| CHEAP HELPER | 7 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 38 | not checked | - | - | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT LIFT | 1 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 397 | not checked | - | - | - | - |
| GIVES UP | 8 | 7 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 1 | 1 | 0 | 0.00 | - | - |
| GROUND FLIERS | 1 | not checked | - | - | - | - |
| HELPER ALREADY ASKED | 6 | not checked | - | - | - | - |
| HELPER UNSEEN | 23 | 23 | 0 | 0.00 | - | - |
| HUNT ADVANCE | 17 | 17 | 0 | 0.00 | - | - |
| HUNT DROPPED | 10 | trace | - | - | - | - |
| HUNT KEPT | 9 | trace | - | - | - | - |
| HUNT RESULT | 20 | trace | - | - | - | - |
| HUNT THE GUNS | 21 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 9 | 9 | 0 | 0.00 | - | - |
| KEEPS ITS PREY | 4 | 4 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 16 | not checked | - | - | - | - |
| LURE BY WHAT IT DRAWS | 4 | 4 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 30 | 30 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 12 | 12 | 0 | 0.00 | - | - |
| MOVE SPELL NOT WORTH | 2 | not checked | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 17 | trace | - | - | - | - |
| MOVE SPELL SPOT | 7 | not checked | - | - | - | - |
| NOT NEEDED | 23 | 23 | 0 | 0.00 | - | - |
| NOT TURNED | 374 | 374 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 44 | not checked | - | - | - | - |
| PLAN RESULT | 2824 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 17 | 17 | 0 | 0.00 | - | - |
| REFUSING RETIRES | 6 | 6 | 0 | 0.00 | - | - |
| SCOUT SPOT | 28 | 28 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 18 | 18 | 0 | 0.00 | - | - |
| SECOND HUNTER | 7 | 7 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 4 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 16 | not checked | - | - | - | - |
| SET-UP MISSED | 1 | trace | - | - | - | - |
| SHOOTER COUNTED ONCE | 3 | 3 | 0 | 0.00 | - | - |
| SPELL CATCH ODDS | 2 | not checked | - | - | - | - |
| SPELL SETS UP CHARGE | 22 | not checked | - | - | - | - |
| SPELL WORTH | 94 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 27 | 25 | 0 | 0.00 | - | - |
| STABLE ROLE | 836 | 835 | 0 | 0.00 | - | - |
| TURN WORTH | 26 | 26 | 0 | 0.00 | - | - |
| TWO OR MORE ARRIVE | 15 | 15 | 0 | 0.00 | - | - |

### Off best figure: cb-h2h-opp-24b8cfb-p2

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 13.50 | 14.69 | 54.0 |
| FALLBACK | gate | 0.92 | 0.75 | 37.6 |
| TURN GATE | gate | 0.69 | 0.58 | 37.0 |
| CHARGE NOW FIRST | rule | 0.47 | 0.53 | 52.1 |
| CANNON PLANNED TARGET | rule | 0.31 | 0.17 | 43.5 |
| PATHS CROSS | rule | 0.14 | 0.14 | 10.6 |
| SURE CHARGE BEATS ADVANCE | rule | 0.17 | 0.11 | 45.3 |
| WAR ENGINE JOBS | rule | 0.25 | 0.03 | 56.1 |
| CHARGE NOW WEIGHED | rule | 0.11 | 0.14 | 57.8 |
| AFTERMATH BAND | gate | 0.17 | 0.06 | 2.0 |
| PIVOT GUARDS FLANK | rule | 0.11 | 0.11 | 30.8 |
| PURSUES BIG PREY | rule | 0.22 | - | 63.3 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.17 | 0.03 | 40.6 |
| LONE CHARACTER SAFE SPOT | gate | 0.03 | 0.17 | 46.3 |
| FIGHT ORDER BAND | gate | 0.08 | 0.08 | 2.4 |
| SUPPORT REQUEST | gate | 0.06 | 0.11 | 19.8 |
| BEST PRIZE | rule | 0.03 | 0.11 | 69.3 |
| BIG CHARACTER SAFETY | rule | 0.08 | 0.03 | 16.0 |
| BLOCKED WHEEL | rule | 0.06 | 0.06 | 29.2 |
| CHAFF PASSED | rule | 0.11 | - | 3.3 |
| SUPPORT NARROWED | rule | 0.06 | 0.06 | 17.0 |
| LONE WIZARD HOLDS BACK | rule | 0.03 | 0.06 | 25.4 |
| NO REASON | gate | - | 0.08 | 2.3 |
| CATCH ODDS | rule | - | 0.06 | 36.2 |
| DEFENSIVE ARMY | rule | 0.03 | 0.03 | 48.3 |
| FACES THE THREAT | rule | 0.03 | 0.03 | 16.0 |
| MARCH ODDS | rule | 0.03 | 0.03 | 2.9 |
| REDIRECT WEIGHED | rule | - | 0.06 | 43.9 |
| STOPS SHORT OF THE FLANK | rule | 0.06 | - | 16.0 |
| WOUNDED STAYS OUT | rule | 0.03 | 0.03 | 194.8 |
| CARRIES OUT COUNTER | rule | - | 0.03 | 16.7 |
| CARRIES OUT SET-UP | rule | - | 0.03 | 6.0 |
| FOLLOW UP WEIGHED | rule | 0.03 | - | 1.5 |
| FRIENDS SHOTS CHECKED | rule | 0.03 | - | 3.6 |
| MOVE AND CAST | rule | 0.03 | - | 60.2 |
| STANDS TO CAST | rule | - | 0.03 | 47.3 |
| THROUGH LINE OF FIRE | rule | - | 0.03 | 78.2 |

### Plans: cb-h2h-opp-24b8cfb-p2

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 12.6 | 17% | 511 | 407 | 80% |
| Mine | charge | 3.4 | 56% | 364 | 330 | 91% |
| Mine | close in | 3.6 | 27% | 184 | 134 | 73% |
| Mine | hold | 4.3 | 25% | 299 | 0 | 0% |
| Mine | join | 0.6 | 96% | 25 | 0 | 0% |
| Mine | shoot | 8.0 | 65% | 244 | 747 | 306% |
| Mine | support | 4.4 | 88% | 24 | 0 | 0% |
| Opponent | advance | 13.3 | 15% | 342 | 323 | 95% |
| Opponent | charge | 5.9 | 50% | 580 | 445 | 77% |
| Opponent | close in | 6.8 | 30% | 441 | 125 | 28% |
| Opponent | hold | 4.6 | 41% | 346 | 0 | 0% |
| Opponent | join | 0.8 | 97% | 35 | 0 | 0% |
| Opponent | shoot | 5.0 | 62% | 171 | 319 | 186% |
| Opponent | support | 4.9 | 90% | 37 | 0 | 0% |

### Packages: hunt the guns, cb-h2h-opp-24b8cfb-p2

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.2 | 9 | 0 | 11% | 22% | 0% | 3.0 | 299 | 61 | 22% | 31 |
| Opponent | 0.3 | 12 | 1 | 27% | 27% | 0% | 2.7 | 366 | 123 | 27% | 80 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 270 | 0 | 0% | 33 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 78 |
| Dwarfen Mountain Holds | 0.3 | 2 | 0 | 0% | 0% | 0% | - | 447 | 0 | 0% | 40 |
| Empire of Man | 0.1 | 1 | 1 | - | - | - | - | - | - | - | 60 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 59 |
| High Elf Realms | 0.2 | 1 | 0 | 100% | 0% | 0% | - | 233 | 0 | 0% | 0 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 236 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Ogre Kingdoms | 2.0 | 8 | 0 | 38% | 38% | 0% | 2.7 | 406 | 169 | 38% | 113 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 290 |
| Tomb Kings of Khemri | 1.4 | 7 | 0 | 0% | 29% | 0% | 3.0 | 248 | 78 | 29% | 13 |
| Vampire Counts | 0.1 | 1 | 0 | 0% | 0% | 0% | - | 331 | 0 | 0% | 0 |
| Warriors of Chaos | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 74 |
| Wood Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |

### Battle groups: cb-h2h-opp-24b8cfb-p2

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 10.2 | 27% | 47% | 14% | 36% | 34% | 7% | 5% | 54% | 0% |
| Mine | REDIRECT COUNTER | 2.0 | 33% | 54% | 17% | 0% | 15% | 5% | 25% | 55% | 0% |
| Opponent | COUNTER-CHARGE COVER | 6.8 | 24% | 71% | 19% | 55% | 40% | 15% | 9% | 36% | 0% |
| Opponent | REDIRECT COUNTER | 3.3 | 31% | 81% | 19% | 0% | 23% | 3% | 10% | 60% | 3% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: cb-h2h-opp-24b8cfb-p2

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 5 | 0 (5) | 0 | 0 | 84 | 20% | 3.0 | 0 (1) | 0 (1) | - | 0 (1) | 0 (1) |
| Mine | Chaff | 33 | 79 (33) | 40 | 39 | 69 | 33% | 2.6 | 44 (18) | 216 (7) | 28 (8) | 106 (22) | 24 (11) |
| Mine | Character | 123 | 57 (123) | 56 | 1 | 33 | 20% | 2.5 | 79 (40) | 47 (54) | 11 (13) | 60 (55) | 56 (52) |
| Mine | Clean-up | 21 | 63 (21) | 31 | 33 | 36 | 33% | 2.9 | 66 (5) | 57 (13) | 87 (3) | 87 (13) | 39 (8) |
| Mine | Fast | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Mine | Fast Hammer | 46 | 27 (46) | 12 | 16 | 44 | 28% | 2.8 | 33 (22) | 25 (16) | 4 (8) | 38 (29) | 11 (17) |
| Mine | Fragile | 5 | 0 (5) | 0 | 0 | 40 | 0% | 1.6 | - | 0 (3) | 0 (2) | 0 (5) | - |
| Mine | Hammer | 57 | 37 (57) | 26 | 10 | 36 | 21% | 2.4 | 9 (18) | 50 (29) | 52 (10) | 43 (38) | 26 (19) |
| Mine | Holder | 28 | 60 (28) | 8 | 52 | 28 | 29% | 3.3 | 82 (8) | 80 (10) | 11 (10) | 72 (18) | 40 (10) |
| Mine | Shooter | 44 | 85 (44) | 39 | 46 | 56 | 2% | 1.5 | 97 (7) | 83 (30) | 86 (7) | 100 (26) | 65 (18) |
| Mine | Support | 2 | 0 (2) | 0 | 0 | 0 | 50% | 6.0 | 0 (1) | 0 (1) | - | - | 0 (2) |
| Mine | War machine | 59 | 40 (59) | 40 | 0 | 48 | 3% | 1.2 | 0 (10) | 46 (37) | 52 (12) | 6 (10) | 47 (49) |
| Mine | Wizard | 22 | 22 (22) | 22 | 0 | 45 | 18% | 2.3 | 0 (6) | 86 (7) | 0 (5) | 0 (5) | 33 (13) |
| Opponent | Blocker | 2 | 0 (2) | 0 | 0 | 0 | 100% | - | 0 (1) | 0 (1) | - | 0 (1) | 0 (1) |
| Opponent | Chaff | 76 | 41 (76) | 19 | 22 | 44 | 37% | 2.5 | 39 (32) | 23 (19) | 61 (25) | 54 (54) | 8 (22) |
| Opponent | Character | 97 | 56 (97) | 56 | 0 | 43 | 22% | 2.4 | 73 (43) | 49 (40) | 17 (7) | 65 (62) | 51 (28) |
| Opponent | Clean-up | 19 | 36 (19) | 16 | 20 | 31 | 21% | 3.1 | 30 (9) | 45 (10) | - | 47 (14) | 5 (5) |
| Opponent | Early | 2 | 0 (2) | 0 | 0 | 0 | 50% | 4.0 | - | 0 (2) | - | 0 (1) | 0 (1) |
| Opponent | Fast Hammer | 48 | 42 (48) | 25 | 16 | 43 | 29% | 2.7 | 22 (22) | 38 (16) | 95 (10) | 47 (28) | 32 (20) |
| Opponent | Fragile | 5 | 0 (5) | 0 | 0 | 46 | 40% | 2.0 | - | 0 (4) | 0 (1) | 0 (4) | 0 (1) |
| Opponent | Hammer | 70 | 30 (70) | 24 | 6 | 46 | 26% | 3.1 | 9 (17) | 28 (42) | 70 (11) | 26 (43) | 35 (27) |
| Opponent | Holder | 35 | 99 (35) | 10 | 89 | 15 | 46% | 2.8 | 130 (8) | 97 (22) | 110 (3) | 131 (21) | 55 (12) |
| Opponent | Shooter | 33 | 75 (33) | 8 | 67 | 25 | 9% | 1.7 | 32 (8) | 101 (19) | 42 (6) | 111 (22) | 21 (11) |
| Opponent | Support | 3 | 0 (3) | 0 | 0 | 25 | 33% | 5.5 | 0 (1) | 0 (1) | - | - | 0 (2) |
| Opponent | War machine | 24 | 39 (24) | 39 | 0 | 26 | 8% | 1.5 | 21 (6) | 40 (14) | 56 (4) | 85 (3) | 32 (21) |
| Opponent | Wizard | 26 | 23 (26) | 23 | 0 | 46 | 12% | 1.4 | 39 (10) | 15 (5) | 22 (7) | 49 (7) | 6 (15) |

### Charged fights: cb-h2h-opp-24b8cfb-p2

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 100 | 233 | 2.0 | 1.2 | 116 | 15 | +102 | 2 of 8 | 7 of 8 | +60 | +116 |
| Mine | Chaos Dwarfs | 4 | 192 | 216 | 2.2 | 1.3 | 96 | 64 | +31 | 4 of 9 | 6 of 9 | +264 | -85 |
| Mine | Dwarfen Mountain Holds | 4 | 828 | 131 | 2.8 | 1.5 | 48 | 21 | +26 | 3 of 11 | 5 of 11 | +69 | -24 |
| Mine | Empire of Man | 5 | 477 | 127 | 1.4 | 1.0 | 91 | 56 | +35 | 4 of 7 | 4 of 7 | - | +35 |
| Mine | Grand Cathay | 4 | 207 | 492 | 3.8 | 1.1 | 131 | 28 | +103 | 5 of 15 | 10 of 15 | -205 | +125 |
| Mine | High Elf Realms | 4 | 160 | 624 | 5.0 | 1.1 | 125 | 20 | +104 | 8 of 20 | 16 of 20 | +117 | +103 |
| Mine | Kingdom of Bretonnia | 1 | 0 | 1569 | 7.0 | 1.0 | 224 | 11 | +213 | 2 of 7 | 6 of 7 | - | +213 |
| Mine | Lizardmen | 1 | 231 | 233 | 2.0 | 1.5 | 116 | 0 | +116 | 1 of 2 | 2 of 2 | +233 | +0 |
| Mine | Ogre Kingdoms | 1 | 0 | 0 | 2.0 | 1.0 | 0 | 62 | -62 | 1 of 2 | 0 of 2 | - | -62 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 235 | 4.0 | 1.2 | 59 | 0 | +59 | 1 of 4 | 3 of 4 | +45 | +63 |
| Mine | Skaven | 2 | 58 | 248 | 3.0 | 1.0 | 82 | 68 | +15 | 2 of 6 | 5 of 6 | - | +15 |
| Mine | Tomb Kings of Khemri | 1 | 0 | 667 | 5.0 | 1.0 | 133 | 0 | +133 | 2 of 5 | 5 of 5 | - | +133 |
| Mine | Vampire Counts | 3 | 0 | 298 | 2.7 | 1.1 | 112 | 149 | -37 | 4 of 8 | 4 of 8 | +0 | -43 |
| Mine | Warriors of Chaos | 1 | 0 | 712 | 4.0 | 1.0 | 178 | 0 | +178 | 0 of 4 | 3 of 4 | - | +178 |
| **Mine** | all armies | 36 | 241 | 340 | 3.0 | 1.2 | 113 | 37 | +77 | 39 of 108 | 76 of 108 | +96 | +73 |
| Opponent | Dwarfen Mountain Holds | 2 | 205 | 42 | 3.0 | 1.0 | 14 | 0 | +14 | 0 of 6 | 3 of 6 | - | +14 |
| Opponent | Empire of Man | 2 | 225 | 88 | 2.5 | 1.2 | 35 | 76 | -41 | 2 of 5 | 3 of 5 | +91 | -74 |
| Opponent | Grand Cathay | 2 | 420 | 606 | 2.5 | 1.4 | 242 | 0 | +242 | 3 of 5 | 2 of 5 | +289 | +231 |
| Opponent | Kingdom of Bretonnia | 1 | 60 | 235 | 2.0 | 1.0 | 118 | 0 | +118 | 0 of 2 | 2 of 2 | - | +118 |
| Opponent | Ogre Kingdoms | 3 | 82 | 186 | 5.0 | 1.1 | 37 | 35 | +2 | 4 of 15 | 6 of 15 | +165 | -9 |
| Opponent | Skaven | 1 | 0 | 0 | 2.0 | 1.0 | 0 | 32 | -32 | 1 of 2 | 2 of 2 | - | -32 |
| Opponent | Tomb Kings of Khemri | 4 | 69 | 606 | 4.5 | 1.2 | 135 | 46 | +89 | 5 of 18 | 12 of 18 | +143 | +74 |
| Opponent | Vampire Counts | 6 | 39 | 611 | 5.0 | 1.3 | 122 | 55 | +67 | 15 of 30 | 22 of 29 | +8 | +84 |
| Opponent | Warriors of Chaos | 8 | 28 | 370 | 3.1 | 1.1 | 118 | 8 | +110 | 12 of 25 | 17 of 25 | +136 | +107 |
| Opponent | Wood Elf Realms | 7 | 132 | 692 | 5.7 | 1.1 | 121 | 3 | +118 | 12 of 40 | 31 of 40 | +168 | +109 |
| **Opponent** | all armies | 36 | 102 | 449 | 4.1 | 1.2 | 109 | 26 | +84 | 54 of 148 | 100 of 147 | +113 | +78 |

### Effective charges: cb-h2h-opp-24b8cfb-p2

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 8 | 0 | 0 | 2 (net -32) | 2 (net +32) | 0 | 3 (net +102) | 1 | 29% (2 of 7) |
| Mine | Chaos Dwarfs | 9 | 3 (net +0) | 0 | 0 | 2 (net -290) | 2 (net +344) | 2 (net +87) | 0 | 0% (0 of 9) |
| Mine | Dwarfen Mountain Holds | 11 | 1 (net +0) | 1 (net +0) | 0 | 0 | 0 | 7 (net +75) | 2 | 0% (0 of 9) |
| Mine | Empire of Man | 7 | 1 (net +210) | 0 | 2 (net -195) | 1 (net +0) | 0 | 2 (net +214) | 1 | 33% (2 of 6) |
| Mine | Grand Cathay | 15 | 1 (net +0) | 0 | 3 (net +241) | 4 (net -3) | 2 (net +20) | 5 (net +159) | 0 | 20% (3 of 15) |
| Mine | High Elf Realms | 20 | 1 (net +0) | 2 (net +0) | 0 | 3 (net +77) | 4 (net +74) | 7 (net +220) | 3 | 0% (0 of 17) |
| Mine | Kingdom of Bretonnia | 7 | 0 | 0 | 3 (net +430) | 0 | 1 (net +30) | 2 (net +0) | 1 | 50% (3 of 6) |
| Mine | Lizardmen | 2 | 0 | 0 | 0 | 1 (net +233) | 1 (net +0) | 0 | 0 | 0% (0 of 2) |
| Mine | Orc & Goblin Tribes | 4 | 0 | 0 | 1 (net +45) | 0 | 1 (net +0) | 1 (net +190) | 1 | 33% (1 of 3) |
| Mine | Skaven | 6 | 1 (net -210) | 0 | 1 (net +270) | 1 (net +0) | 0 | 3 (net +10) | 0 | 17% (1 of 6) |
| Mine | Tomb Kings of Khemri | 5 | 0 | 0 | 0 | 1 (net +274) | 2 (net +55) | 2 (net +142) | 0 | 0% (0 of 5) |
| Mine | Vampire Counts | 8 | 2 (net -98) | 0 | 1 (net +0) | 2 (net +62) | 0 | 2 (net +0) | 1 | 14% (1 of 7) |
| Mine | Warriors of Chaos | 4 | 0 | 0 | 0 | 0 | 0 | 2 (net +304) | 2 | 0% (0 of 2) |
| Opponent | Dwarfen Mountain Holds | 6 | 1 (net +0) | 0 | 1 (net +0) | 4 (net +21) | 0 | 0 | 0 | 17% (1 of 6) |
| Opponent | Empire of Man | 5 | 1 (net +0) | 0 | 2 (net -190) | 0 | 1 (net +91) | 1 (net +85) | 0 | 40% (2 of 5) |
| Opponent | Grand Cathay | 5 | 2 (net +454) | 0 | 0 | 2 (net +0) | 0 | 1 (net +304) | 0 | 0% (0 of 5) |
| Opponent | Kingdom of Bretonnia | 2 | 0 | 1 (net +115) | 0 | 0 | 0 | 0 | 1 | 0% (0 of 1) |
| Opponent | Ogre Kingdoms | 15 | 5 (net +59) | 0 | 3 (net -41) | 1 (net -185) | 0 | 2 (net +0) | 4 | 27% (3 of 11) |
| Opponent | Skaven | 2 | 0 | 0 | 2 (net -32) | 0 | 0 | 0 | 0 | 100% (2 of 2) |
| Opponent | Tomb Kings of Khemri | 18 | 2 (net +46) | 0 | 3 (net +197) | 5 (net +76) | 0 | 4 (net +40) | 4 | 21% (3 of 14) |
| Opponent | Vampire Counts | 30 | 5 (net +214) | 1 (net -186) | 8 (net +96) | 7 (net -118) | 4 (net +86) | 4 (net +119) | 1 | 28% (8 of 29) |
| Opponent | Warriors of Chaos | 25 | 2 (net +59) | 2 (net +125) | 5 (net +71) | 6 (net +98) | 2 (net +0) | 3 (net +107) | 5 | 25% (5 of 20) |
| Opponent | Wood Elf Realms | 40 | 8 (net +244) | 0 | 5 (net +9) | 13 (net +117) | 3 (net +134) | 8 (net +45) | 3 | 14% (5 of 37) |

### Charged fights, damage counted: cb-h2h-opp-24b8cfb-p2

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 10 | 296 | 274 | -20 | 129 | 139 | -11 | -3.7 |
| Mine | 50-54% | 3 | 230 | 269 | +0 | 0 | 0 | +0 | +0.0 |
| Mine | Effective (55-75%) | 13 | 292 | 285 | +144 | 239 | 119 | +120 | +41.0 |
| Mine | 76-89% | 17 | 285 | 229 | +20 | 91 | 60 | +32 | +11.1 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 38 | 239 | 152 | +128 | 144 | 21 | +123 | +51.5 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 13 | 397 | 97 | +90 | 93 | 14 | +79 | +19.8 |
| Mine | No odds | 14 | 198 | 217 | +16 | 108 | 67 | +42 | +21.0 |
| Mine | All fights | 108 | 271 | 196 | +77 | 131 | 54 | +77 | +28.2 |
| Opponent | Long shot (under 50%) | 26 | 246 | 226 | +171 | 211 | 33 | +178 | +72.6 |
| Opponent | 50-54% | 4 | 291 | 272 | +45 | 91 | 46 | +45 | +15.4 |
| Opponent | Effective (55-75%) | 29 | 277 | 219 | +41 | 95 | 53 | +43 | +15.4 |
| Opponent | 76-89% | 38 | 262 | 172 | +41 | 114 | 66 | +48 | +18.3 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 23 | 272 | 161 | +74 | 93 | 21 | +71 | +26.1 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 10 | 463 | 108 | +84 | 85 | 6 | +79 | +17.2 |
| Opponent | No odds | 18 | 193 | 181 | +136 | 174 | 26 | +148 | +76.4 |
| Opponent | All fights | 148 | 270 | 188 | +84 | 129 | 41 | +88 | +32.4 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| cb-h2h-opp-24b8cfb-p2 | move | 429 | 98 (23%) | 77 (18%) | 64 (15%) | 267 (62%) |
| cb-h2h-opp-24b8cfb-p2 | objective | 378 | 60 (16%) | 41 (11%) | 63 (17%) | 255 (67%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0106, L0122, L2429, L2535, L2735 |
| Charmed Shield | Opponent | L0425, L0827, L0934, L1026, L1727, L1827, L1927 |
| Clockwork Compass | Mine | L1228 |
| Clockwork Compass | Opponent | L0512 |
| Elixir of Power | Mine | L1118, L1135, L1927 |
| Fistful of Laurels | Mine | L1827 |
| Fistful of Laurels | Opponent | L0918, L1118, L1418 |
| Horn of the Wild Hunt | Opponent | L3033 |
| Invocation of Nehek | Mine | L2429, L2535, L2735 |
| Invocation of Nehek | Opponent | L0425, L0827, L1727, L1827, L1927 |
| Opal Amulet | Mine | L1418, L1435 |
| Periapt of Soul Exchange | Mine | L2029, L2131 |
| Periapt of Soul Exchange | Opponent | L0721 |
| Ring of Doom | Mine | L0206, L0222, L1118, L1135, L1228, L1531 |
| Ring of Doom | Opponent | L0512, L1531, L2131, L3033 |
| Ring of Jet | Mine | L1026, L1118, L1135, L1228 |
| Ring of Jet | Opponent | L0512, L0810 |
| Standard of the Fell Warrior | Mine | L1323 |
| Storm Daemon (Renegade 2.0) | Mine | L2131 |
| Storm Daemon (Renegade 2.0) | Opponent | L0721 |
| Twice-Blessed Armour | Mine | L0721, L1026 |
| Twice-Blessed Armour | Opponent | L0307, L0810 |
| Witch Hunter's Ward | Mine | L0721, L0810, L0827 |
| Witch Hunter's Ward | Opponent | L0307 |

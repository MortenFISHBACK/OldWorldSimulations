# Doctrine scorecard: cb-h2h-opp-24b8cfb-p1

### Scorecard: cb-h2h-opp-24b8cfb-p1

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0102 | 6 | 1 | Mine | no | 18 | 5 | 1 | 0 | 0 | 0 | 0 | 65 |
| L0102 | 6 | 1 | Opponent | no | 0 | 3 | 2 | 4 | 1 | 0 | 0 | 222 |
| L0118 | 4 | 1 | Mine | no | 3 | 6 | 1 | 2 | 0 | 0 | 0 | 0 |
| L0118 | 4 | 1 | Opponent | no | 2 | 2 | 1 | 4 | 0 | 0 | 0 | 268 |
| L0135 | 3 | 1 | Mine | no | 3 | 2 | 0 | 2 | 0 | 0 | 0 | 55 |
| L0135 | 3 | 1 | Opponent | no | 0 | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L0218 | 2 | 1 | Mine | - | - | 2 | 1 | 4 | 0 | 0 | 0 | 170 |
| L0218 | 2 | 1 | Opponent | - | - | 4 | 1 | 2 | 1 | 0 | 0 | 0 |
| L0235 | 1 | 1 | Mine | no | 7 | 2 | 1 | 4 | 0 | 0 | 0 | 170 |
| L0235 | 1 | 1 | Opponent | no | 3 | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| L0319 | 1 | 1 | Mine | no | 10 | 3 | 2 | 1 | 0 | 0 | 0 | 590 |
| L0319 | 1 | 1 | Opponent | no | 0 | 2 | 2 | 2 | 0 | 0 | 0 | 411 |
| L0405 | 3 | 1 | Mine | yes | 0 | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L0405 | 3 | 1 | Opponent | yes | 5 | - | 2 | 0 | 0 | 0 | 0 | 954 |
| L0421 | 1 | 1 | Mine | no | 0 | 2 | 7 | 2 | 0 | 0 | 0 | 0 |
| L0421 | 1 | 1 | Opponent | no | 0 | - | 0 | 3 | 0 | 0 | 0 | 355 |
| L0508 | 4 | 1 | Mine | no | 5 | 3 | 0 | 2 | 0 | 0 | 0 | 548 |
| L0508 | 4 | 1 | Opponent | no | 3 | 6 | 1 | 3 | 0 | 0 | 0 | 515 |
| L0524 | 2 | 1 | Mine | - | - | 5 | 2 | 1 | 0 | 0 | 0 | 698 |
| L0524 | 2 | 1 | Opponent | - | - | 2 | 5 | 2 | 0 | 0 | 0 | 0 |
| L0612 | 6 | 1 | Mine | no | 0 | - | 3 | 2 | 0 | 0 | 0 | 615 |
| L0612 | 6 | 1 | Opponent | no | 3 | 2 | 3 | 0 | 0 | 0 | 0 | 330 |
| L0628 | 4 | 1 | Mine | no | 0 | 6 | 1 | 2 | 0 | 0 | 0 | 1167 |
| L0628 | 4 | 1 | Opponent | no | 3 | - | 0 | 1 | 0 | 0 | 0 | 0 |
| L0717 | 3 | 1 | Mine | yes | 3 | 2 | 2 | 0 | 0 | 0 | 0 | 420 |
| L0717 | 3 | 1 | Opponent | yes | 3 | 2 | 4 | 2 | 1 | 0 | 0 | 0 |
| L0733 | 1 | 1 | Mine | no | 4 | 3 | 4 | 0 | 0 | 0 | 0 | 420 |
| L0733 | 1 | 1 | Opponent | no | 3 | 3 | 4 | 3 | 0 | 0 | 0 | 0 |
| L0823 | 1 | 1 | Mine | no | 0 | 4 | 1 | 0 | 0 | 0 | 0 | 515 |
| L0823 | 1 | 1 | Opponent | no | 4 | 2 | 3 | 2 | 1 | 0 | 0 | 70 |
| L0913 | 1 | 1 | Mine | no | 4 | 2 | 4 | 0 | 0 | 0 | 0 | 537 |
| L0913 | 1 | 1 | Opponent | no | 4 | 2 | 2 | 1 | 0 | 0 | 0 | 140 |
| L0930 | 6 | 1 | Mine | no | 1 | 4 | 2 | 1 | 0 | 0 | 0 | 584 |
| L0930 | 6 | 1 | Opponent | no | 3 | 2 | 5 | 1 | 0 | 0 | 0 | 0 |
| L1021 | 1 | 1 | Mine | no | 0 | 2 | 6 | 0 | 0 | 0 | 0 | 330 |
| L1021 | 1 | 1 | Opponent | no | 1 | 5 | 4 | 3 | 1 | 0 | 0 | 560 |
| L1114 | 4 | 1 | Mine | no | 0 | 2 | 1 | 1 | 0 | 0 | 0 | 330 |
| L1114 | 4 | 1 | Opponent | no | 0 | 2 | 3 | 3 | 0 | 0 | 0 | 500 |
| L1131 | 3 | 1 | Mine | no | 0 | - | 2 | 0 | 0 | 0 | 0 | 427 |
| L1131 | 3 | 1 | Opponent | no | 2 | 4 | 3 | 2 | 0 | 0 | 0 | 170 |
| L1224 | 6 | 1 | Mine | no | 7 | 2 | 5 | 0 | 1 | 0 | 0 | 330 |
| L1224 | 6 | 1 | Opponent | no | 3 | 2 | 3 | 1 | 2 | 0 | 0 | 0 |
| L1319 | 5 | 1 | Mine | yes | - | 3 | 4 | 1 | 0 | 0 | 0 | 302 |
| L1319 | 5 | 1 | Opponent | yes | - | 2 | 1 | 1 | 0 | 0 | 0 | 0 |
| L1335 | 3 | 1 | Mine | yes | 7 | 2 | 5 | 0 | 0 | 0 | 0 | 140 |
| L1335 | 3 | 1 | Opponent | no | 0 | 3 | 5 | 2 | 1 | 0 | 0 | 236 |
| L1431 | 3 | 1 | Mine | yes | 8 | 2 | 5 | 1 | 0 | 0 | 0 | 177 |
| L1431 | 3 | 1 | Opponent | no | 0 | - | 3 | 1 | 1 | 0 | 0 | 340 |
| L1527 | 3 | 1 | Mine | yes | 5 | 4 | 3 | 0 | 0 | 0 | 0 | 0 |
| L1527 | 3 | 1 | Opponent | no | 1 | 2 | 4 | 1 | 0 | 0 | 0 | 54 |
| L1625 | 5 | 1 | Mine | yes | - | 4 | 3 | 1 | 0 | 0 | 0 | 200 |
| L1625 | 5 | 1 | Opponent | no | - | 1 | 3 | 1 | 1 | 0 | 0 | 0 |
| L1723 | 1 | 1 | Mine | no | 0 | 1 | 1 | 0 | 1 | 0 | 0 | 147 |
| L1723 | 1 | 1 | Opponent | yes | 12 | 2 | 6 | 0 | 0 | 0 | 0 | 0 |
| L1823 | 5 | 1 | Mine | yes | - | - | 3 | 2 | 0 | 0 | 0 | 0 |
| L1823 | 5 | 1 | Opponent | yes | - | 2 | 5 | 2 | 0 | 0 | 0 | 70 |
| L1923 | 3 | 1 | Mine | no | 1 | 2 | 7 | 0 | 0 | 0 | 0 | 255 |
| L1923 | 3 | 1 | Opponent | no | 11 | 2 | 7 | 1 | 1 | 0 | 0 | 0 |
| L2025 | 3 | 1 | Mine | yes | 5 | - | 4 | 0 | 1 | 0 | 0 | 485 |
| L2025 | 3 | 1 | Opponent | no | 11 | 3 | 4 | 1 | 0 | 0 | 0 | 0 |
| L2127 | 3 | 1 | Mine | no | 1 | - | 0 | 3 | 1 | 0 | 0 | 544 |
| L2127 | 3 | 1 | Opponent | no | 9 | 2 | 7 | 2 | 0 | 0 | 0 | 0 |
| L2231 | 5 | 1 | Mine | no | - | 2 | 4 | 0 | 1 | 0 | 0 | 0 |
| L2231 | 5 | 1 | Opponent | no | - | 2 | 6 | 2 | 4 | 0 | 0 | 933 |
| L2335 | 1 | 1 | Mine | no | 0 | 2 | 1 | 0 | 1 | 0 | 0 | 0 |
| L2335 | 1 | 1 | Opponent | no | 1 | 3 | 3 | 0 | 0 | 0 | 0 | 0 |
| L2531 | 5 | 1 | Mine | yes | - | 3 | 3 | 3 | 0 | 0 | 0 | 0 |
| L2531 | 5 | 1 | Opponent | no | - | 4 | 0 | 3 | 1 | 0 | 0 | 0 |
| L2730 | 6 | 1 | Mine | no | 2 | 1 | 5 | 3 | 0 | 0 | 0 | 0 |
| L2730 | 6 | 1 | Opponent | no | 1 | - | 0 | 0 | 1 | 0 | 0 | 0 |
| L2934 | 6 | 1 | Mine | no | 3 | 2 | 2 | 2 | 0 | 0 | 0 | 170 |
| L2934 | 6 | 1 | Opponent | no | 2 | 2 | 2 | 1 | 0 | 0 | 0 | 56 |
| **Average** | | | Mine | 29% | 3.3 | 2.8 | 2.8 | 1.1 | 0.2 | 0.0 | 0.0 | 288.6 |
| **Average** | | | Opponent | 15% | 3.1 | 2.5 | 3.0 | 1.6 | 0.5 | 0.0 | 0.0 | 171.8 |

### KPIs: cb-h2h-opp-24b8cfb-p1

Rules off - Mine only: CHARGE BAND, JOINT KNOWS CHALLENGE, REFUSING RETIRES, BLOWS WHERE AIMED, SPELLS IN THE FIGHT, CHARGER SLAIN LOST, WIDER SPREAD.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 29% (50 of 174) | 3% (5 of 177) | 16% (55 of 351) |
| Winner chose to follow up after the loser gave ground |  | 94% (68 of 72); on the table 100% | 97% (61 of 63); on the table 97% | 96% (129 of 135); on the table 99% |
| Winner chose to pursue after the loser fell back in good order |  | 79% (11 of 14); on the table 86% | 100% (14 of 14); on the table 100% | 89% (25 of 28); on the table 93% |
| Winner chose to pursue after the loser fled |  | 63% (19 of 30); on the table 67% | 74% (26 of 35); on the table 83% | 69% (45 of 65); on the table 75% |
| Winner chose to follow up or pursue (all three) |  | 84% (98 of 116); on the table 90% | 90% (101 of 112); on the table 93% | 87% (199 of 228); on the table 91% |
| Magic missiles tried each own turn | 50%+ | 33% (110 of 330) | 29% (61 of 210) | 32% (171 of 540) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 50% (110 of 222) | 40% (61 of 153) | 46% (171 of 375) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 69% (20 of 29) | 61% (30 of 49) | 64% (50 of 78) |
| Points that never fought | lower | 36% (25960 of 71484) | 39% (28033 of 71889) | 38% (53993 of 143373) |
|   infantry points that never fought | lower | 42% (7112 of 16863) | 57% (7591 of 13348) | 49% (14703 of 30211) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 57% (160 of 279) | 57% (169 of 295) | 57% (329 of 574) |
| Bound items with a magic missile used (at least once a game) |  | 95% (21 of 22); 2.0 uses a game | 80% (16 of 20); 1.5 uses a game | 88% (37 of 42); 1.7 uses a game |
| Bound items with another spell used |  | 62% (10 of 16); 0.6 uses a game | 0% (0 of 8); 0.0 uses a game | 42% (10 of 24); 0.3 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 53% (10 of 19); 0.3 uses a game | 50% (6 of 12); 0.2 uses a game | 52% (16 of 31); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 52% (30947 of 59666) | 52% (32322 of 62699) | 52% (63269 of 122365) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 2.1 (35%) | 1.3 (31%) | 3.4 (33%) |
| MARCHED: its unit marched | 0.7 (11%) | 0.5 (11%) | 1.1 (11%) |
| CHARGED: its unit charged | 0.3 (5%) | 0.1 (3%) | 0.5 (5%) |
| IN COMBAT: engaged in combat | 2.0 (33%) | 0.7 (16%) | 2.7 (26%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.4 (10%) | 0.4 (4%) |
| FLEEING: fleeing | 0.1 (2%) | 0.2 (5%) | 0.3 (3%) |
| GONE: slain | 0.7 (11%) | 0.5 (13%) | 1.2 (12%) |
| OFF THE TABLE: off the table or not arrived | 0.2 (4%) | 0.2 (5%) | 0.4 (4%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.1 (3%) | 0.1 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.1 (2%) | 0.1 (1%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.2 | 1.5 | 1.3 | 4.8 | 0.2 | 2.0 |
| not cast | 3.8 | 2.8 | 3.3 | 10.2 | 2.1 | 22.0 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.9 (8%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.0 (35%) | 0.3 (10%) | 3.4 (33%) | 0.3 (15%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.1 (11%) | 0.2 (11%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.5 (5%) | 0.2 (8%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.2 (6%) | 0.5 (17%) | 0.6 (17%) | 2.7 (26%) | 0.6 (31%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.2 (4%) | 0.3 (12%) | 0.5 (16%) | 0.4 (4%) | 0.0 (0%) | 0.0 (0%) |
| NO CASTS LEFT: every cast used on other spells | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) |
| FLEEING: fleeing | 0.2 (7%) | 0.0 (1%) | 0.1 (2%) | 0.3 (3%) | 0.0 (1%) | 0.8 (4%) |
| GONE: slain | 1.0 (26%) | 0.2 (9%) | 0.4 (11%) | 1.2 (12%) | 0.1 (5%) | 2.1 (9%) |
| OFF THE TABLE: off the table or not arrived | 0.2 (5%) | 0.1 (5%) | 0.2 (6%) | 0.4 (4%) | 0.1 (3%) | 1.0 (5%) |
| STUPIDITY: Stupidity | 0.1 (3%) | 0.1 (2%) | 0.0 (1%) | 0.1 (1%) | 0.0 (0%) | 0.6 (3%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.3 (10%) | 0.0 (0%) | 0.0 (0%) | 0.5 (25%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.9 (50%) | 0.2 (9%) | 1.3 (38%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 15.8 (72%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.1 a game | 0.5 a game | 0.8 a game |
| stood (cast and not dispelled) | 66% (21 of 32) | 53% (9 of 17) | 61% (30 of 49) |
| the unit moved after it | 76% (16 of 21) | 33% (3 of 9) | 63% (19 of 30) |
| it charged on its next turn | 0% (0 of 21) | 0% (0 of 9) | 0% (0 of 30) |
| the enemy charged it first | 10% (2 of 21) | 11% (1 of 9) | 10% (3 of 30) |
| it fought by the end of its next turn | 10% (2 of 21) | 22% (2 of 9) | 13% (4 of 30) |
| it moved out of a charge the enemy had planned (not charged first) | 19% (4 of 21) | 22% (2 of 9) | 20% (6 of 30) |
| none of these (no charge, no fight, no charge escaped) | 71% (15 of 21) | 56% (5 of 9) | 67% (20 of 30) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 61% (555 of 910) | 56% (328 of 584) | 59% (883 of 1494) |
|   cavalry | 57% (48 of 84) | 67% (84 of 126) | 63% (132 of 210) |
|   character | 38% (36 of 96) | 27% (30 of 111) | 32% (66 of 207) |
|   chariot | 48% (48 of 101) | 60% (21 of 35) | 51% (69 of 136) |
|   infantry | 56% (173 of 311) | 57% (130 of 230) | 56% (303 of 541) |
|   monster | 70% (26 of 37) | 26% (6 of 23) | 53% (32 of 60) |
|   war machine | 80% (224 of 281) | 97% (57 of 59) | 83% (281 of 340) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.6 (26%) | 1.4 (20%) | 4.0 (24%) |
| CHARGED: it charged | 1.1 (11%) | 1.3 (19%) | 2.4 (14%) |
| FLEEING: it fled or was fleeing | 0.2 (2%) | 0.2 (3%) | 0.4 (2%) |
| IN COMBAT: it fought this turn or the last | 1.0 (10%) | 0.5 (7%) | 1.5 (9%) |
| MOVED: a war machine that moved | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| FREE: none of these - no target in range or sight, or held its fire | 0.3 (3%) | 0.0 (0%) | 0.3 (2%) |
| NO TARGET IN RANGE | 1.8 (18%) | 2.1 (30%) | 3.9 (23%) |
| ONLY IN COMBAT: the only targets were in combat | 0.2 (3%) | 0.5 (7%) | 0.8 (4%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 2.0 (20%) | 0.7 (10%) | 2.7 (16%) |
| SHELTERED: the target was sheltered | 0.3 (3%) | 0.1 (2%) | 0.4 (2%) |
| STUPIDITY | 0.0 (0%) | 0.1 (1%) | 0.1 (0%) |
| OTHER BAR | 0.4 (4%) | 0.1 (2%) | 0.5 (3%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 5.4 | 1.2 | 81% | 4.8 pts | 26 pts |
| character | 2.1 | 0.8 | 75% | 6.5 pts | 14 pts |
| chariot | 1.9 | 1.1 | 72% | 8.8 pts | 17 pts |
| infantry | 12.3 | 5.4 | 72% | 9.2 pts | 114 pts |
| monster | 1.0 | 0.2 | 86% | 3.4 pts | 3 pts |
| war machine | 7.8 | 6.1 | 62% | 24.0 pts | 187 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.7 | 5.8 | 5.2 |
| Charges that made contact a game | 3.4 | 4.0 | 3.7 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.27 declared, 1.00 contact (22 units) | 0.79 declared, 0.50 contact (14 units) | 1.08 declared, 0.81 contact (36 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.83 declared, 0.67 contact (6 units) | 1.00 declared, 0.67 contact (6 units) | 0.92 declared, 0.67 contact (12 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.54 declared, 0.38 contact (252 units) | 0.68 declared, 0.47 contact (282 units) | 0.61 declared, 0.43 contact (534 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 56% (39 of 70) | 57% (12 of 21) | 50% (4 of 8) | 56% (55 of 99) |
| Character in a unit | 81% (25 of 31) | 69% (18 of 26) | 60% (3 of 5) | 74% (46 of 62) |
| Character on its own | 84% (47 of 56) | 47% (16 of 34) | 25% (15 of 61) | 52% (78 of 151) |
| Chariot | 50% (8 of 16) | 60% (6 of 10) | - | 54% (14 of 26) |
| Infantry | 53% (47 of 89) | 36% (13 of 36) | 50% (1 of 2) | 48% (61 of 127) |
| Monster | 66% (21 of 32) | 90% (9 of 10) | - | 71% (30 of 42) |
| Monstrous | 55% (6 of 11) | 64% (9 of 14) | - | 60% (15 of 25) |
| War Machines | 71% (29 of 41) | 100% (1 of 1) | - | 71% (30 of 42) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 6 | 69% (11 of 16); on the table 75% | 43% (59 of 138) | 39% | 55% (18 of 33) | 100% (9 of 9); 5.2 uses a game | 100% (3 of 3); 1.3 uses a game | 78% (7 of 9); 1.2 uses a game |
| Chaos Dwarfs | 3 | 100% (10 of 10); on the table 100% | 12% (3 of 24) | 41% | 54% (13 of 24) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 0.3 uses a game |
| Dwarfen Mountain Holds | 5 | 88% (14 of 16); on the table 94% | - | 55% | 76% (31 of 41) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 6 | 78% (7 of 9); on the table 89% | 39% (14 of 36) | 53% | 61% (39 of 64) | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game | 0% (0 of 4); 0.0 uses a game |
| Grand Cathay | 5 | 79% (11 of 14); on the table 86% | 25% (27 of 108) | 44% | 41% (18 of 44) | 100% (12 of 12); 8.2 uses a game | 0% (0 of 1); 0.0 uses a game | 40% (2 of 5); 0.4 uses a game |
| High Elf Realms | 6 | 88% (15 of 17); on the table 94% | 27% (8 of 30) | 36% | 51% (25 of 49) | 100% (5 of 5); 3.2 uses a game | 33% (6 of 18); 2.3 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | 100% (4 of 4); on the table 100% | - | 23% | 17% (1 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Lizardmen | 2 | 100% (4 of 4); on the table 100% | - | 25% | 71% (10 of 14) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 3 | 90% (9 of 10); on the table 90% | 8% (1 of 12) | 57% | 62% (13 of 21) | 67% (2 of 3); 2.3 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 3 | 100% (14 of 14); on the table 100% | 14% (5 of 36) | 5% | 58% (14 of 24) | 0.0 uses a game | 0.0 uses a game | 67% (2 of 3); 0.7 uses a game |
| Skaven | 4 | 100% (12 of 12); on the table 100% | 47% (14 of 30) | 30% | 68% (23 of 34) | 100% (3 of 3); 1.2 uses a game | 0.0 uses a game | 50% (2 of 4); 0.5 uses a game |
| Tomb Kings of Khemri | 6 | 70% (26 of 37); on the table 78% | 0% (0 of 12) | 25% | 33% (10 of 30) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 8 | 91% (30 of 33); on the table 94% | 33% (18 of 54) | 32% | 58% (29 of 50) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 8 | 100% (19 of 19); on the table 100% | 33% (10 of 30) | 37% | 72% (53 of 74) | 100% (4 of 4); 1.9 uses a game | 0.0 uses a game | 50% (1 of 2); 0.1 uses a game |
| Wood Elf Realms | 6 | 100% (13 of 13); on the table 100% | 40% (12 of 30) | 42% | 48% (32 of 66) | 33% (2 of 6); 1.2 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (cb-h2h-opp-24b8cfb-p1, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 58% (46) | 42% (34) | 50% (80) |
| ...free all their last turn and able to turn (per game) | 0.61 | 0.61 | 1.22 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.22 | 0.08 | 0.31 |
| ...with the charger already in that arc before they moved (per game) | 0.42 | 0.44 | 0.86 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 1.92 | 1.53 | 3.44 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 1.17 | 0.81 | 1.97 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 5.00 | 5.08 | 10.08 |

### Quality by phase: cb-h2h-opp-24b8cfb-p1

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.1 | 3.4 |
| Strategy | Charge objectives carried out (made contact) | 48% (76 of 157) | 38% (72 of 190) |
| Strategy | Shoot objectives carried out (shot that target) | 50% (188 of 378) | 53% (102 of 194) |
| Strategy | Close-in objectives charged next turn | 16% (21 of 134) | 19% (42 of 224) |
| Strategy | Support requests answered (helper made contact too) | 39% (7 of 18) | 36% (9 of 25) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 75% (3 of 4) | 67% (2 of 3) |
| Strategy | Hexes on a unit its side charged or shot that turn | 67% (12 of 18) | 64% (9 of 14) |
| Strategy | Joined characters whose unit fought | 52% (27 of 52) | 39% (16 of 41) |
| Strategy | Lone characters that fought | 78% (73 of 94) | 80% (76 of 95) |
| Movement | Charges halted short of contact | 0.2 | 0.2 |
| Movement | Idle units | 1.1 | 1.6 |
| Movement | Points that never moved of their own | 288.6 | 171.8 |
| Movement | Fights charged into per game | 3.1 | 3.5 |
| Movement | Charges with odds: long shots (under 50%) | 13 of 95, net +19 | 21 of 108, net +15 |
| Movement | Charges with odds: sweet spot (55-75%) | 25 of 95, net +83 | 23 of 108, net +100 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 9 of 95, net +14 | 7 of 108, net +85 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 37 of 95, net +102 | 32 of 108, net +139 |
| Shooting | Shots by shooting units (incl. breath weapons) | 10.1 | 8.5 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 39% (141 of 362) | 45% (139 of 306) |
| Shooting | Points destroyed by shooting units | 63.0 | 17.6 |
| Shooting | War machine shots | 6.2 | 1.6 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 45% (100 of 224) | 39% (22 of 57) |
| Shooting | Points destroyed by war machines | 64.4 | 12.5 |
| Magic | Magic missiles cast | 2.2 | 0.9 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 32% (25 of 78) | 47% (16 of 34) |
| Magic | Wounds caused by magic missiles | 5.4 | 1.4 |
| Magic | Wounds caused by other spells | 1.8 | 0.7 |
| Magic | Points destroyed by magic (all spells) | 74.1 | 32.9 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.3 / 0.5 / 0.8 / 0.1 | 1.6 / 0.5 / 0.4 / 0.1 |
| Combat | Points destroyed in combat | 374.6 | 380.2 |
| Combat | Points run down | 66.0 | 116.9 |
| Combat | Net points per charged fight, damage counted | +70 | +81 |
| Combat | Net per 100 charger points, damage counted | +24.2 | +33.0 |
| Combat | First round won (charged fights) | 73% | 68% |
| Combat | Net points per charged fight | +64 | +79 |
| Combat | Net points per supported fight / lone fight | +93 / +60 | +95 / +77 |
| Combat | Charged fights on a top-3 enemy unit | 46 of 111 | 59 of 126 |
| Game | Points lost | 729.2 | 760.1 |
| Game | VP from objectives | 632.5 | 588.9 |
| Game | Lone holders (player turns) | 3.3 | 3.1 |

- Mine won / drew / lost: 21 / 2 / 13 of 36 ended games (of 36); mean margin (Mine - Opponent) +72 VP
- The side that went first won 15 of 34 games with a winner
- Points traded per game (both sides' losses): 1489
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: cb-h2h-opp-24b8cfb-p1

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.6 | +0.0 | 0.0 | 1.8 | 0.7 | +0.0 | 0.0 | 0.0 |
| ARRIVAL HUNT | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.1 | +0.0 | 0.0 | 12.5 | 0.2 | +0.0 | 0.0 | 3.6 |
| BACKUP TARGETS | 0.7 | +8.1 | 0.0 | 0.0 | 0.9 | +10.7 | 0.0 | 10.9 |
| BEST FACING | 0.7 | +48.0 | 0.0 | 33.9 | 0.6 | +44.7 | 0.0 | 45.0 |
| BEST FIRST | 4.0 | +206.8 | 141.2 | 47.9 | 3.6 | +147.5 | 109.7 | 41.9 |
| BEST OVERALL | 0.7 | +49.6 | 0.0 | 7.1 | 0.9 | +57.2 | 0.0 | 40.9 |
| BEST PREY | 0.9 | +42.6 | 26.7 | 38.1 | 0.8 | +29.2 | 7.7 | 2.8 |
| BEST PRIZE | 0.1 | +3.6 | 4.7 | 1.4 | 0.1 | +4.0 | 4.6 | 0.0 |
| BIG CHARACTER SAFETY | 0.3 | -1.3 | 0.0 | 0.0 | 0.1 | -0.0 | 0.0 | 0.0 |
| BLOCKED CHARGE SKIPPED | 0.2 | +0.0 | 19.9 | 5.4 | - | - | - | - |
| BLOCKED WHEEL | 0.2 | +7.6 | 0.0 | 1.1 | 0.3 | +18.8 | 0.0 | 5.1 |
| BLOWS WHERE AIMED | - | - | - | - | 0.3 | -35.4 | 51.7 | 9.8 |
| BOMBING RUN | 0.1 | +3.7 | 11.6 | 0.0 | - | - | - | - |
| BOUND ASSAILMENT | 0.1 | +0.0 | 0.0 | 8.4 | - | - | - | - |
| CANNON PLAN MISSED | 0.8 | +0.0 | 68.2 | 14.3 | 0.2 | +0.0 | 6.8 | 0.0 |
| CANNON PLANNED TARGET | 4.8 | +109.2 | 258.9 | 96.7 | 1.3 | +37.4 | 30.0 | 7.1 |
| CANNON SIGHT KEPT | 1.0 | +0.0 | 0.0 | 3.5 | 0.4 | +0.0 | 0.0 | 7.2 |
| CARRIES OUT COUNTER | 0.1 | -1.0 | 16.9 | 0.0 | 0.1 | -3.6 | 21.5 | 0.0 |
| CARRIES OUT SET-UP | 0.1 | +0.0 | 20.1 | 10.6 | 0.1 | -0.2 | 3.0 | 10.5 |
| CAST JOB | 0.7 | +29.1 | 54.7 | 6.2 | 0.4 | +8.7 | 3.3 | 9.7 |
| CASTER AWAY FROM SCREEN | 0.4 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.3 | +31.8 | 19.0 | 0.0 | 0.1 | +4.4 | 3.9 | 4.4 |
| CASTS AFTER FRIENDS | 0.6 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 7.6 |
| CASTS FROM BEHIND | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | - | - | - | - | 0.0 | +0.1 | 0.0 | 0.0 |
| CATCH ODDS | - | - | - | - | 0.1 | +1.8 | 0.0 | 0.0 |
| CHAFF PASSED | 0.2 | -0.1 | 0.0 | 0.0 | 0.1 | -0.1 | 0.0 | 1.8 |
| CHARGE BAND | - | - | - | - | 0.2 | +0.0 | 13.3 | 0.0 |
| CHARGE NOW FIRST | 2.8 | +0.0 | 236.9 | 122.7 | 2.9 | +0.0 | 312.7 | 68.8 |
| CHARGE NOW WEIGHED | 0.4 | -22.7 | 1.8 | 14.9 | 0.5 | -30.3 | 11.5 | 12.3 |
| CHARGER SLAIN LOST | - | - | - | - | 0.8 | -21.3 | 75.8 | 32.4 |
| CHARIOT WIZARD CAREFUL | 0.1 | -3.0 | 7.1 | 0.0 | - | - | - | - |
| CHEAP HELPER | 0.1 | +0.0 | 4.0 | 0.0 | - | - | - | - |
| COMBAT PIVOT | 0.6 | +0.0 | 21.9 | 25.5 | 0.4 | +0.0 | 20.6 | 0.0 |
| CONVEYANCE SEARCH | 0.5 | +39.9 | 3.2 | 11.2 | 0.4 | +43.3 | 0.0 | 15.2 |
| COUNTER-CHARGE COVER | 9.3 | +621.1 | 0.0 | 153.8 | 6.5 | +644.9 | 0.0 | 171.4 |
| DEFENSIVE ARMY | 0.4 | +0.0 | 17.9 | 4.1 | 0.0 | +0.0 | 0.0 | 3.1 |
| DEFENSIVE FLOOR | 0.1 | +5.6 | 4.0 | 7.9 | 0.1 | +8.1 | 4.2 | 3.5 |
| EDGE GIVE GROUND | 0.2 | +8.8 | 18.6 | 21.4 | 0.2 | +4.7 | 13.8 | 0.0 |
| ELIXIR WORTH | - | - | - | - | 0.1 | +1.4 | 0.0 | 0.0 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 1.9 | +144.1 | 0.0 | 71.0 | 1.5 | +121.6 | 0.0 | 61.8 |
| FALLBACK BY WORTH | 4.9 | +81.3 | 0.0 | 68.8 | 5.9 | +56.9 | 0.0 | 68.6 |
| FIRE AND FLEE | 0.1 | +0.5 | 0.0 | 2.4 | - | - | - | - |
| FLANK NOT WEIGHED | 5.2 | +0.0 | 0.0 | 113.9 | 5.5 | +0.0 | 0.0 | 193.9 |
| FOCUS FIRE | 0.0 | +2.7 | 0.0 | 0.0 | - | - | - | - |
| FOLLOW UP WEIGHED | 1.1 | +118.2 | 0.0 | 25.9 | 1.1 | +169.2 | 0.0 | 48.0 |
| FRIENDS SHOTS CHECKED | 0.2 | +9.7 | 0.0 | 3.6 | 0.1 | +4.5 | 0.0 | 0.0 |
| GATEWAY ESCAPE | - | - | - | - | 0.0 | +2.4 | 0.0 | 0.0 |
| GIVES UP | - | - | - | - | 0.2 | -2.8 | 12.0 | 7.9 |
| GROUND FLIERS | 0.0 | +0.4 | 0.0 | 0.0 | - | - | - | - |
| HELPER ALREADY ASKED | - | - | - | - | 0.1 | +0.0 | 43.6 | 3.8 |
| HELPER UNSEEN | 0.3 | +0.0 | 27.5 | 23.4 | 0.3 | +0.0 | 27.0 | 10.5 |
| HILL BY ITS CHANCE | - | - | - | - | 0.2 | -8.5 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.8 | +0.0 | 0.0 | 0.0 |
| HUNT ADVANCE | 0.0 | +0.0 | 5.3 | 0.0 | 0.1 | +8.9 | 0.0 | 6.1 |
| HUNT DROPPED | 0.0 | +0.0 | 10.5 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| HUNT IN PAIRS | 0.5 | +38.1 | 0.0 | 0.0 | 0.4 | +27.9 | 0.0 | 7.4 |
| HUNT KEPT | 0.0 | +0.0 | 5.3 | 0.0 | - | - | - | - |
| HUNT RESULT | 0.1 | +5.5 | 10.5 | 0.0 | 0.2 | +17.1 | 6.5 | 9.7 |
| HUNT THE GUNS | 0.1 | +17.1 | 5.3 | 0.0 | 0.2 | +97.0 | 16.7 | 9.3 |
| INVITES THE FIGHT | 1.4 | +36.1 | 81.6 | 36.5 | 1.6 | +25.8 | 39.8 | 15.9 |
| JOINT CHARGE PLAN | - | - | - | - | 0.2 | +14.1 | 0.0 | 0.8 |
| JOINT KNOWS CHALLENGE | - | - | - | - | 0.2 | -9.6 | 24.0 | 14.7 |
| KEEP FALLS | 0.1 | +1.6 | 0.0 | 0.0 | - | - | - | - |
| KEEPS ITS PREY | 0.0 | +0.3 | 0.0 | 0.0 | - | - | - | - |
| KEEPS ITS TARGET | 1.6 | +49.2 | 143.1 | 79.1 | 1.9 | +58.3 | 99.7 | 44.1 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KILLS COUNT | 2.0 | +89.4 | 184.5 | 74.4 | 1.5 | +61.5 | 131.2 | 24.9 |
| KILLS COUNT NEXT TURN | 4.8 | +173.8 | 189.2 | 94.6 | 6.6 | +259.6 | 161.2 | 201.1 |
| LONE CHARACTER SAFE SPOT | 0.2 | +6.3 | 25.5 | 1.2 | 0.6 | +11.7 | 0.0 | 8.2 |
| LONE WIZARD HOLDS BACK | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 2.0 | 16.1 |
| LONE WIZARD KEPT IN | 0.7 | +49.1 | 0.0 | 0.0 | 0.2 | +24.5 | 0.0 | 0.0 |
| LONG SHOT | 0.6 | -3.5 | 23.9 | 8.2 | 0.6 | +4.6 | 29.4 | 11.5 |
| LOST CHARGE | 2.8 | -44.3 | 108.2 | 122.9 | 2.8 | -40.8 | 46.6 | 91.9 |
| LURE BY WHAT IT DRAWS | 0.1 | -5.6 | 0.0 | 0.0 | 0.1 | -7.8 | 0.0 | 4.6 |
| MAKE SURE TOGETHER | 0.4 | +33.8 | 27.2 | 32.5 | 1.1 | +39.2 | 1.4 | 39.6 |
| MANOEUVRE | 0.2 | +4.3 | 0.0 | 2.4 | 0.2 | +4.6 | 0.0 | 4.8 |
| MARCH AT ESCAPER | 0.1 | +1.4 | 0.0 | 0.0 | 0.0 | +1.1 | 0.0 | 0.0 |
| MARCH CHECK | 0.6 | +15.3 | 0.0 | 11.2 | 0.7 | +38.4 | 0.0 | 21.0 |
| MARCH ODDS | 0.2 | +7.9 | 2.9 | 0.0 | 0.4 | +37.5 | 11.2 | 0.0 |
| MARCH OVER CASTS | 0.4 | +34.1 | 0.0 | 29.4 | 0.3 | +16.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 4.6 | +180.6 | 0.0 | 105.3 | 4.3 | +148.3 | 0.0 | 83.9 |
| MISSILES IN THE MOVE | 4.3 | +193.2 | 0.0 | 53.0 | 3.6 | +58.3 | 0.0 | 81.8 |
| MISSILES NEXT TURN | 4.7 | +112.6 | 0.0 | 105.8 | 4.1 | +38.7 | 0.0 | 86.4 |
| MODEL FACING | 0.3 | +135.2 | 0.0 | 0.0 | - | - | - | - |
| MONSTER WIZARD ROAMS | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| MOVE AND CAST | 0.3 | +23.2 | 0.0 | 0.0 | 0.3 | +16.9 | 0.0 | 0.0 |
| MOVE SPELL IN RANGE | 0.1 | +2.7 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.4 | -90.0 | 0.0 | 0.0 | 0.1 | -0.7 | 0.0 | 7.6 |
| MOVE SPELL SPOT | 0.2 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE | 2.7 | +164.0 | 113.2 | 94.8 | 5.1 | +382.8 | 104.5 | 110.7 |
| MOVES UNITS SPELL | 0.1 | +3.4 | 0.0 | 0.0 | 0.1 | +1.8 | 0.0 | 0.0 |
| NEEDED THERE | 0.0 | +0.0 | 3.5 | 0.0 | - | - | - | - |
| NO RALLY LEFT | 0.1 | +4.4 | 0.0 | 2.1 | - | - | - | - |
| NOT NEEDED | 0.2 | -14.5 | 24.1 | 10.6 | 0.3 | -10.6 | 24.4 | 5.1 |
| NOT TURNED | 5.0 | +80.0 | 0.0 | 101.7 | 5.1 | +57.0 | 0.0 | 118.5 |
| NOT WORTH A CAST | 0.8 | -0.7 | 0.0 | 32.4 | 0.3 | -0.2 | 0.0 | 0.0 |
| OFF BEST | 15.9 | -793.0 | 4.0 | 248.4 | 15.9 | -855.2 | 13.8 | 314.2 |
| OPENS A LANE | 0.2 | +1.7 | 13.3 | 0.0 | 0.1 | +0.6 | 4.5 | 0.0 |
| OPENS UP | 0.2 | +19.3 | 16.6 | 13.7 | 0.4 | +21.4 | 17.8 | 9.9 |
| OVERRUNS AWAY | 0.5 | +9.6 | 55.5 | 46.3 | 0.6 | +13.2 | 60.7 | 29.4 |
| PATHS CROSS | 2.1 | +133.1 | 0.0 | 53.8 | 2.3 | +190.1 | 0.0 | 47.8 |
| PERIAPT WORTH | 0.0 | +1.2 | 0.0 | 0.0 | 0.0 | +1.6 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.1 | -0.8 | 0.0 | 0.0 | 0.2 | -4.4 | 0.0 | 0.0 |
| PLAN RESULT | 37.2 | +1382.1 | 1281.6 | 970.7 | 37.9 | +989.0 | 968.7 | 929.8 |
| PURSUES BIG PREY | 0.1 | -3.1 | 0.0 | 0.0 | - | - | - | - |
| RAIDS THE BAGGAGE NEXT TURN | - | - | - | - | 0.1 | +5.7 | 0.0 | 0.0 |
| RANDOM MOVE BY FIGURES | 0.8 | +17.6 | 0.0 | 4.7 | 1.4 | +20.1 | 0.0 | 80.1 |
| RANDOM MOVER NO PROMISE | 0.1 | -7.7 | 0.0 | 0.0 | 0.3 | -9.6 | 0.0 | 19.3 |
| REDIRECT BY WHAT IT STOPS | 0.1 | +1.8 | 0.0 | 0.8 | 0.6 | -17.2 | 0.0 | 17.3 |
| REDIRECT COUNTER | 2.1 | +156.4 | 0.0 | 40.0 | 4.1 | +321.0 | 0.0 | 61.8 |
| REDIRECT WEIGHED | 0.3 | +10.3 | 8.2 | 6.7 | 0.5 | +7.2 | 9.5 | 3.5 |
| REFUSING RETIRES | - | - | - | - | 0.2 | +0.0 | 0.0 | 10.5 |
| RESERVE FALL BACK | 0.5 | +12.2 | 0.0 | 5.4 | 0.9 | +41.2 | 0.0 | 20.4 |
| RESTRAINS TO SHOOT | 0.2 | +10.1 | 0.0 | 5.8 | 0.1 | +4.1 | 0.0 | 0.0 |
| RISK BY ARC | 2.9 | +97.5 | 229.2 | 161.2 | 3.0 | +68.0 | 229.2 | 97.5 |
| SAFER THAN THE JOB | 1.2 | +65.2 | 0.0 | 11.1 | 0.8 | +30.0 | 0.0 | 26.3 |
| SCOUT SPOT | 0.4 | +0.6 | 0.0 | 0.0 | 0.3 | +0.6 | 0.0 | 0.9 |
| SCOUT WAITS | 0.4 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.9 |
| SCREEN BY WHAT IT SAVES | 0.1 | -5.5 | 0.0 | 1.2 | 0.2 | -6.0 | 0.0 | 3.3 |
| SEARCH SPOT | 2.3 | +99.2 | 0.0 | 49.6 | 2.9 | +149.5 | 0.0 | 41.1 |
| SELF MOVE SPELL | 0.2 | +30.1 | 0.0 | 18.1 | 0.1 | +0.2 | 0.0 | 0.0 |
| SET UP TOGETHER | 0.8 | +80.3 | 35.2 | 35.4 | 2.0 | +147.6 | 1.4 | 52.7 |
| SET-UP ANY TARGET | 0.2 | +18.7 | 0.0 | 0.0 | 0.1 | +12.4 | 0.0 | 0.0 |
| SET-UP MISSED | 0.1 | +16.5 | 0.0 | 11.2 | 0.0 | +2.4 | 0.0 | 0.0 |
| SHOOTER COUNTED ONCE | - | - | - | - | 0.1 | -0.3 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.4 | +0.9 | 0.0 | 0.0 | 0.3 | +0.8 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.3 | +45.8 | 65.0 | 18.2 | 0.8 | +16.9 | 27.1 | 8.8 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 3.2 | 0.0 | +0.0 | 0.0 | 3.8 |
| SHOT REPLANNED | 0.6 | +0.0 | 80.6 | 15.8 | 0.1 | +0.0 | 3.8 | 0.0 |
| SHOTS IN THE MOVE | 14.3 | +475.3 | 0.0 | 244.3 | 8.5 | +196.3 | 0.0 | 115.5 |
| SPELL SETS UP CHARGE | 0.2 | +21.2 | 2.2 | 0.0 | 0.2 | +68.0 | 0.0 | 0.0 |
| SPELL WORTH | 1.3 | +14.7 | 86.8 | 76.1 | 1.7 | +49.2 | 73.2 | 76.7 |
| SPELLS IN THE FIGHT | - | - | - | - | 0.7 | -9.7 | 55.8 | 34.9 |
| STABLE ROLE | 11.7 | +0.0 | 411.2 | 158.5 | 10.3 | +0.0 | 257.1 | 205.1 |
| STANDS TO CAST | 0.0 | +0.5 | 0.0 | 0.0 | 0.1 | +2.7 | 3.2 | 0.0 |
| STOPS | 0.1 | +0.3 | 5.3 | 0.0 | 0.1 | +2.3 | 16.7 | 3.2 |
| STOPS SHORT OF THE FLANK | 0.6 | +24.2 | 0.0 | 13.4 | 0.4 | +29.3 | 0.0 | 9.8 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 8.1 |
| SUPPORT NARROWED | 5.2 | -28.7 | 305.9 | 116.1 | 7.0 | -47.7 | 332.0 | 112.8 |
| SUPPORTS | 3.0 | +29.4 | 139.0 | 51.8 | 4.4 | +47.7 | 115.9 | 64.7 |
| SURE CHARGE BEATS ADVANCE | 0.0 | -0.9 | 0.0 | 0.0 | 0.0 | -0.3 | 0.0 | 0.0 |
| SURE REACH TOGETHER | 0.9 | -1.8 | 26.2 | 24.5 | 0.8 | -1.3 | 11.2 | 26.5 |
| THROUGH LINE OF FIRE | 0.4 | +18.0 | 0.0 | 4.6 | 0.2 | +22.4 | 0.0 | 6.5 |
| TURN WORTH | 0.5 | -40.9 | 53.5 | 41.2 | 0.2 | -14.9 | 25.7 | 0.0 |
| TWO OR MORE ARRIVE | 0.2 | +0.3 | 22.2 | 6.7 | 0.5 | +3.4 | 0.0 | 5.6 |
| WAIT AFTER COSTS | 6.5 | -291.7 | 282.7 | 160.6 | 9.1 | -450.9 | 213.9 | 189.7 |
| WALKS TO THE FIGHT | 2.1 | +54.8 | 71.6 | 1.4 | 1.5 | +29.9 | 29.1 | 35.5 |
| WAR ENGINE JOBS | 0.6 | +0.0 | 35.1 | 1.8 | 0.5 | +0.0 | 1.4 | 14.4 |
| WEARS DOWN | 1.3 | +57.7 | 94.7 | 74.4 | 1.4 | +39.6 | 136.3 | 56.9 |
| WHO HITS BACK | 0.2 | +29.9 | 0.0 | 16.2 | 0.4 | +33.0 | 0.0 | 38.6 |
| WHOLE FIGHT | 0.4 | +23.5 | 79.6 | 2.1 | 0.8 | +34.6 | 105.7 | 16.1 |
| WHOLE FIGHT GAIN | 0.3 | +20.6 | 25.5 | 8.7 | 0.5 | +31.0 | 34.2 | 13.9 |
| WIDER SPREAD | - | - | - | - | 3.4 | -6.9 | 318.9 | 92.8 |
| WOUNDED STAYS OUT | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |

### Rule changes: cb-h2h-opp-24b8cfb-p1

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 1147 | 1147 | 1147 | 31.86 | -59335 | -51.7 |
| BEST FIRST | 273 | 273 | 273 | 7.58 | +12756 | +46.7 |
| SEARCH SPOT | 188 | 188 | 187 | 5.19 | +8950 | +47.9 |
| PATHS CROSS | 161 | 161 | 161 | 4.47 | +11635 | +72.3 |
| COUNTER-CHARGE COVER | 568 | 306 | 160 | 4.44 | +8824 | +55.2 |
| MOVE TO CHARGE | 278 | 278 | 141 | 3.92 | +7370 | +52.3 |
| FACES THE THREAT | 124 | 124 | 124 | 3.44 | +9563 | +77.1 |
| KILLS COUNT NEXT TURN | 408 | 408 | 121 | 3.36 | +4329 | +35.8 |
| FALLBACK BY WORTH | 389 | 389 | 83 | 2.31 | +4976 | +60.0 |
| SUPPORTS | 266 | 266 | 78 | 2.17 | +618 | +7.9 |
| FOLLOW UP WEIGHED | 77 | 77 | 77 | 2.14 | +10347 | +134.4 |
| WAIT AFTER COSTS | 559 | 559 | 74 | 2.06 | +1429 | +19.3 |
| WALKS TO THE FIGHT | 128 | 128 | 74 | 2.06 | +1326 | +17.9 |
| SAFER THAN THE JOB | 71 | 71 | 71 | 1.97 | +3429 | +48.3 |
| BEST OVERALL | 58 | 58 | 58 | 1.61 | +3847 | +66.3 |
| RESERVE FALL BACK | 53 | 53 | 53 | 1.47 | +1923 | +36.3 |
| CANNON SIGHT KEPT | 51 | 51 | 51 | 1.42 | +0 | +0.0 |
| SHOTS IN THE MOVE | 819 | 505 | 51 | 1.42 | +1473 | +28.9 |
| ARTILLERY RE-ROLL WEIGHED | 50 | 50 | 50 | 1.39 | +0 | +0.0 |
| RANDOM MOVE BY FIGURES | 78 | 78 | 50 | 1.39 | +1361 | +27.2 |
| CANNON PLANNED TARGET | 220 | 220 | 48 | 1.33 | -162 | -3.4 |
| ADVANCE LANE KEPT | 46 | 46 | 46 | 1.28 | +0 | +0.0 |
| CHARGE NOW FIRST | 203 | 203 | 46 | 1.28 | -3374 | -73.4 |
| REDIRECT COUNTER | 224 | 124 | 46 | 1.28 | +4151 | +90.2 |
| BEST FACING | 45 | 45 | 45 | 1.25 | +3337 | +74.2 |
| HOLDS AMBUSHERS | 44 | 44 | 44 | 1.22 | +0 | +0.0 |
| MARCH CHECK | 44 | 44 | 44 | 1.22 | +2369 | +53.8 |
| SET UP TOGETHER | 101 | 87 | 42 | 1.17 | +3457 | +82.3 |
| MAX FOR POSITIONING | 319 | 171 | 41 | 1.14 | +584 | +14.3 |
| MISSILES IN THE MOVE | 285 | 163 | 41 | 1.14 | +902 | +22.0 |
| SHOOTS FROM THE BEST SPOT | 76 | 76 | 35 | 0.97 | +608 | +17.4 |
| COMBAT PIVOT | 34 | 34 | 34 | 0.94 | +0 | +0.0 |
| LONE WIZARD KEPT IN | 34 | 34 | 34 | 0.94 | +2648 | +77.9 |
| RISK BY ARC | 212 | 201 | 34 | 0.94 | +1283 | +37.7 |
| CHARGE NOW WEIGHED | 33 | 33 | 33 | 0.92 | +1477 | +44.8 |
| INVITES THE FIGHT | 110 | 110 | 33 | 0.92 | +430 | +13.0 |
| STOPS SHORT OF THE FLANK | 33 | 33 | 33 | 0.92 | +1926 | +58.4 |
| KILLS COUNT | 126 | 121 | 31 | 0.86 | +1345 | +43.4 |
| REDIRECT WEIGHED | 29 | 29 | 29 | 0.81 | +1217 | +42.0 |
| CASTER AWAY FROM SCREEN | 26 | 26 | 26 | 0.72 | +0 | +0.0 |
| SCOUT WAITS | 26 | 26 | 26 | 0.72 | +0 | +0.0 |
| SHOOTERS IN TWO RANKS | 24 | 24 | 24 | 0.67 | +58 | +2.4 |
| SHOT REPLANNED | 24 | 24 | 24 | 0.67 | +0 | +0.0 |
| THROUGH LINE OF FIRE | 24 | 24 | 24 | 0.67 | +1454 | +60.6 |
| MOVE AND CAST | 23 | 23 | 23 | 0.64 | +1443 | +62.7 |
| CAST JOB | 38 | 38 | 22 | 0.61 | +592 | +26.9 |
| KEEPS ITS TARGET | 129 | 127 | 22 | 0.61 | +405 | +18.4 |
| WHO HITS BACK | 22 | 22 | 22 | 0.61 | +1574 | +71.6 |
| MARCH ODDS | 21 | 21 | 20 | 0.56 | -21 | -1.1 |
| BLOCKED WHEEL | 19 | 19 | 19 | 0.53 | +950 | +50.0 |
| BEST PREY | 64 | 64 | 18 | 0.50 | +490 | +27.2 |
| MAKE SURE TOGETHER | 56 | 38 | 15 | 0.42 | +636 | +42.4 |
| WAR ENGINE JOBS | 37 | 37 | 15 | 0.42 | -840 | -56.0 |
| CASTS FROM BEHIND | 14 | 14 | 14 | 0.39 | +0 | +0.0 |
| WHOLE FIGHT GAIN | 29 | 24 | 14 | 0.39 | +607 | +43.4 |
| BIG CHARACTER SAFETY | 13 | 13 | 13 | 0.36 | -49 | -3.8 |
| HUNT IN PAIRS | 33 | 24 | 13 | 0.36 | +757 | +58.3 |
| STUCK PIVOT | 13 | 13 | 13 | 0.36 | +0 | +0.0 |
| CASTING BLOCK | 17 | 17 | 12 | 0.33 | +444 | +37.0 |
| CHAFF PASSED | 12 | 12 | 12 | 0.33 | -9 | -0.7 |
| FRIENDS SHOTS CHECKED | 12 | 12 | 12 | 0.33 | +513 | +42.7 |
| MANOEUVRE | 15 | 15 | 12 | 0.33 | +319 | +26.5 |
| OPENS UP | 22 | 22 | 12 | 0.33 | +569 | +47.4 |
| WEARS DOWN | 98 | 92 | 11 | 0.31 | +659 | +59.9 |
| MODEL FACING | 10 | 10 | 10 | 0.28 | +4867 | +486.7 |
| RESTRAINS TO SHOOT | 10 | 10 | 10 | 0.28 | +511 | +51.1 |
| WHOLE FIGHT | 45 | 43 | 10 | 0.28 | +623 | +62.3 |
| LOST CHARGE | 203 | 202 | 8 | 0.22 | +112 | +13.9 |
| PIVOT GUARDS FLANK | 8 | 8 | 8 | 0.22 | -186 | -23.2 |
| SHORT GUN FORWARD | 8 | 8 | 8 | 0.22 | +0 | +0.0 |
| MOVES UNITS SPELL | 7 | 7 | 7 | 0.19 | +186 | +26.5 |
| BACKUP TARGETS | 57 | 28 | 6 | 0.17 | +19 | +3.1 |
| BLOCKED CHARGE SKIPPED | 6 | 6 | 6 | 0.17 | +0 | +0.0 |
| CHARGE BAND | 6 | 6 | 6 | 0.17 | +0 | +0.0 |
| SUPPORT NARROWED | 438 | 438 | 6 | 0.17 | -44 | -7.4 |
| DEFENSIVE ARMY | 14 | 14 | 5 | 0.14 | -142 | -28.5 |
| OVERRUNS AWAY | 39 | 39 | 5 | 0.14 | +117 | +23.5 |
| BEST PRIZE | 4 | 4 | 4 | 0.11 | -55 | -13.6 |
| BOMBING RUN | 4 | 4 | 4 | 0.11 | +133 | +33.4 |
| SURE REACH TOGETHER | 58 | 44 | 4 | 0.11 | +28 | +6.9 |
| BOUND ASSAILMENT | 3 | 3 | 3 | 0.08 | +1 | +0.2 |
| CARRIES OUT COUNTER | 8 | 8 | 3 | 0.08 | -166 | -55.3 |
| HUNT ADVANCE | 5 | 5 | 3 | 0.08 | +138 | +46.1 |
| KEEP FALLS | 3 | 3 | 3 | 0.08 | +75 | +25.1 |
| LONG SHOT | 43 | 39 | 3 | 0.08 | +1 | +0.2 |
| MISSILES NEXT TURN | 316 | 179 | 3 | 0.08 | +11 | +3.6 |
| NO RALLY LEFT | 3 | 3 | 3 | 0.08 | +168 | +56.0 |
| STANDS TO CAST | 3 | 3 | 3 | 0.08 | +27 | +8.9 |
| CATCH ODDS | 2 | 2 | 2 | 0.06 | -50 | -24.8 |
| DEFENSIVE FLOOR | 6 | 6 | 2 | 0.06 | +166 | +82.9 |
| ELIXIR WORTH | 2 | 2 | 2 | 0.06 | +52 | +25.9 |
| FIRE AND FLEE | 2 | 2 | 2 | 0.06 | +20 | +9.9 |
| JOINT CHARGE PLAN | 9 | 9 | 2 | 0.06 | +145 | +72.5 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| PERIAPT WORTH | 2 | 2 | 2 | 0.06 | +98 | +49.1 |
| PURSUES BIG PREY | 2 | 2 | 2 | 0.06 | -112 | -56.2 |
| SURE CHARGE BEATS ADVANCE | 2 | 2 | 2 | 0.06 | -43 | -21.5 |
| WIDER SPREAD | 124 | 116 | 2 | 0.06 | +15 | +7.3 |
| CARRIES OUT SET-UP | 8 | 8 | 1 | 0.03 | -6 | -6.3 |
| FOCUS FIRE | 1 | 1 | 1 | 0.03 | +98 | +98.4 |
| HILL BY ITS CHANCE | 7 | 7 | 1 | 0.03 | +2 | +2.3 |
| LONE WIZARD HOLDS BACK | 16 | 16 | 1 | 0.03 | +0 | +0.0 |
| MOVE SPELL IN RANGE | 2 | 2 | 1 | 0.03 | +4 | +3.9 |
| OPENS A LANE | 10 | 6 | 1 | 0.03 | +19 | +18.9 |
| RAIDS THE BAGGAGE NEXT TURN | 2 | 2 | 1 | 0.03 | +2 | +2.0 |
| REDIRECT BY WHAT IT STOPS | 25 | 25 | 1 | 0.03 | +18 | +17.7 |
| REFUSING RETIRES | 6 | 6 | 1 | 0.03 | -0 | -0.1 |
| SPELLS IN THE FIGHT | 25 | 22 | 1 | 0.03 | +23 | +23.0 |
| STOPS | 6 | 6 | 1 | 0.03 | +15 | +15.0 |
| WOUNDED STAYS OUT | 1 | 1 | 1 | 0.03 | -43 | -43.4 |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| BLOWS WHERE AIMED | 11 | 8 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 36 | 36 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 32 | trace | - | - | - | - |
| CATCH FLIERS | 1 | not checked | - | - | - | - |
| CHARGER SLAIN LOST | 27 | 25 | 0 | 0.00 | - | - |
| CHARIOT WIZARD CAREFUL | 4 | 4 | 0 | 0.00 | - | - |
| CHEAP HELPER | 4 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 32 | not checked | - | - | - | - |
| EDGE GIVE GROUND | 13 | 13 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 2 | 2 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 387 | not checked | - | - | - | - |
| GATEWAY ESCAPE | 1 | not checked | - | - | - | - |
| GIVES UP | 6 | 6 | 0 | 0.00 | - | - |
| GROUND FLIERS | 1 | not checked | - | - | - | - |
| HELPER ALREADY ASKED | 4 | not checked | - | - | - | - |
| HELPER UNSEEN | 24 | 21 | 0 | 0.00 | - | - |
| HUNT DROPPED | 4 | trace | - | - | - | - |
| HUNT KEPT | 1 | trace | - | - | - | - |
| HUNT RESULT | 10 | trace | - | - | - | - |
| HUNT THE GUNS | 10 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 7 | 6 | 0 | 0.00 | - | - |
| KEEPS ITS PREY | 1 | 1 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 27 | not checked | - | - | - | - |
| LURE BY WHAT IT DRAWS | 6 | 6 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 3 | trace | - | - | - | - |
| MARCH OVER CASTS | 25 | 25 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 9 | 9 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 19 | trace | - | - | - | - |
| MOVE SPELL SPOT | 12 | not checked | - | - | - | - |
| NEEDED THERE | 1 | 1 | 0 | 0.00 | - | - |
| NOT NEEDED | 17 | 17 | 0 | 0.00 | - | - |
| NOT TURNED | 363 | 363 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 39 | not checked | - | - | - | - |
| PLAN RESULT | 2704 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 15 | 15 | 0 | 0.00 | - | - |
| SCOUT SPOT | 23 | 23 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 12 | 12 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 14 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 12 | not checked | - | - | - | - |
| SET-UP MISSED | 5 | trace | - | - | - | - |
| SHOOTER COUNTED ONCE | 2 | 2 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 16 | not checked | - | - | - | - |
| SPELL WORTH | 109 | not checked | - | - | - | - |
| STABLE ROLE | 792 | 789 | 0 | 0.00 | - | - |
| TURN WORTH | 25 | 25 | 0 | 0.00 | - | - |
| TWO OR MORE ARRIVE | 25 | 25 | 0 | 0.00 | - | - |

### Off best figure: cb-h2h-opp-24b8cfb-p1

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 14.25 | 14.33 | 51.9 |
| FALLBACK | gate | 0.58 | 0.78 | 34.0 |
| CHARGE NOW FIRST | rule | 0.64 | 0.58 | 76.7 |
| TURN GATE | gate | 0.69 | 0.36 | 53.6 |
| WAR ENGINE JOBS | rule | 0.22 | 0.19 | 56.0 |
| PATHS CROSS | rule | 0.17 | 0.14 | 40.9 |
| SUPPORT REQUEST | gate | 0.17 | 0.14 | 114.2 |
| LONE CHARACTER SAFE SPOT | gate | 0.06 | 0.17 | 70.0 |
| PIVOT GUARDS FLANK | rule | 0.06 | 0.17 | 23.2 |
| BIG CHARACTER SAFETY | rule | 0.17 | 0.03 | 10.0 |
| CANNON PLANNED TARGET | rule | 0.19 | - | 48.5 |
| CHARGE NOW WEIGHED | rule | 0.08 | 0.08 | 18.2 |
| AFTERMATH BAND | gate | 0.06 | 0.08 | 2.0 |
| DEFENSIVE ARMY | rule | 0.14 | - | 28.5 |
| SUPPORT NARROWED | rule | 0.06 | 0.08 | 8.8 |
| BEST PRIZE | rule | 0.06 | 0.06 | 13.6 |
| CHAFF PASSED | rule | 0.06 | 0.06 | 2.1 |
| MARCH ODDS | rule | - | 0.11 | 64.3 |
| CARRIES OUT COUNTER | rule | 0.03 | 0.06 | 55.3 |
| SAFER THAN THE JOB | rule | 0.06 | 0.03 | 4.5 |
| STOPS SHORT OF THE FLANK | rule | 0.08 | - | 12.7 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.06 | - | 136.9 |
| CATCH ODDS | rule | - | 0.06 | 24.8 |
| FIGHT ORDER BAND | gate | 0.06 | - | 3.6 |
| NO REASON | gate | - | 0.06 | 19.7 |
| PURSUES BIG PREY | rule | 0.06 | - | 56.2 |
| REDIRECT WEIGHED | rule | 0.06 | - | 10.8 |
| SURE CHARGE BEATS ADVANCE | rule | 0.03 | 0.03 | 21.5 |
| WHO HITS BACK | rule | 0.03 | 0.03 | 1.7 |
| CARRIES OUT SET-UP | rule | - | 0.03 | 6.3 |
| FACES THE THREAT | rule | 0.03 | - | 18.2 |
| FOLLOW UP WEIGHED | rule | - | 0.03 | 0.7 |
| LONG SHOT | rule | 0.03 | - | 51.0 |
| RULE SWITCHED OFF | gate | 0.03 | - | 37.3 |
| THROUGH LINE OF FIRE | rule | - | 0.03 | 2.0 |
| WOUNDED STAYS OUT | rule | - | 0.03 | 43.4 |

### Plans: cb-h2h-opp-24b8cfb-p1

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 12.1 | 20% | 542 | 323 | 60% |
| Mine | charge | 3.6 | 62% | 394 | 332 | 84% |
| Mine | close in | 3.7 | 24% | 253 | 118 | 47% |
| Mine | hold | 5.2 | 40% | 348 | 0 | 0% |
| Mine | join | 0.6 | 95% | 18 | 0 | 0% |
| Mine | shoot | 8.9 | 62% | 305 | 609 | 200% |
| Mine | support | 3.2 | 83% | 16 | 0 | 0% |
| Opponent | advance | 12.3 | 12% | 361 | 272 | 75% |
| Opponent | charge | 4.5 | 55% | 432 | 388 | 90% |
| Opponent | close in | 6.2 | 23% | 460 | 132 | 29% |
| Opponent | hold | 4.1 | 49% | 277 | 0 | 0% |
| Opponent | join | 1.2 | 95% | 57 | 0 | 0% |
| Opponent | shoot | 4.5 | 57% | 110 | 198 | 180% |
| Opponent | support | 5.1 | 88% | 37 | 0 | 0% |

### Packages: hunt the guns, cb-h2h-opp-24b8cfb-p1

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.1 | 2 | 0 | 50% | 50% | 0% | 3.0 | 308 | 100 | 50% | 11 |
| Opponent | 0.2 | 8 | 0 | 25% | 25% | 0% | 2.0 | 437 | 77 | 25% | 71 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Dwarfen Mountain Holds | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 410 | 0 | 0% | 79 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 64 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| High Elf Realms | 0.2 | 1 | 0 | 100% | 100% | 0% | 3.0 | 206 | 200 | 100% | 104 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 246 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.2 | 1 | 0 | 100% | 100% | 0% | 2.0 | 450 | 369 | 100% | 36 |
| Tomb Kings of Khemri | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 44 |
| Vampire Counts | 0.1 | 1 | 0 | 0% | 0% | 0% | - | 569 | 0 | 0% | 22 |
| Warriors of Chaos | 0.6 | 5 | 0 | 20% | 20% | 0% | 2.0 | 429 | 50 | 20% | 29 |
| Wood Elf Realms | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 329 | 0 | 0% | 42 |

### Battle groups: cb-h2h-opp-24b8cfb-p1

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 9.3 | 23% | 57% | 8% | 33% | 34% | 13% | 11% | 41% | 0% |
| Mine | REDIRECT COUNTER | 2.1 | 37% | 68% | 4% | 0% | 7% | 4% | 11% | 74% | 4% |
| Opponent | COUNTER-CHARGE COVER | 6.5 | 24% | 60% | 24% | 46% | 38% | 5% | 24% | 33% | 0% |
| Opponent | REDIRECT COUNTER | 4.1 | 22% | 81% | 25% | 12% | 12% | 0% | 17% | 62% | 8% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: cb-h2h-opp-24b8cfb-p1

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 3 | 25 (3) | 25 | 0 | 0 | 67% | 5.0 | 0 (1) | 67 (1) | 0 (1) | 44 (2) | 0 (1) |
| Mine | Chaff | 36 | 37 (36) | 18 | 19 | 56 | 39% | 2.2 | 31 (15) | 31 (9) | 47 (12) | 39 (23) | 35 (13) |
| Mine | Character | 123 | 50 (123) | 50 | 0 | 33 | 19% | 2.6 | 65 (36) | 51 (59) | 8 (9) | 59 (62) | 46 (42) |
| Mine | Clean-up | 24 | 69 (24) | 26 | 43 | 26 | 29% | 3.8 | 73 (9) | 74 (11) | 24 (4) | 131 (13) | 9 (11) |
| Mine | Fast | 4 | 35 (4) | 35 | 0 | 34 | 0% | 1.5 | 67 (1) | 0 (2) | 0 (1) | 35 (4) | - |
| Mine | Fast Hammer | 42 | 21 (42) | 10 | 11 | 58 | 36% | 2.3 | 28 (19) | 19 (12) | 9 (11) | 29 (29) | 5 (13) |
| Mine | Fragile | 5 | 28 (5) | 28 | 0 | 60 | 0% | 2.6 | - | 17 (4) | 69 (1) | 0 (1) | 35 (4) |
| Mine | Hammer | 57 | 48 (57) | 33 | 15 | 39 | 11% | 2.6 | 41 (10) | 49 (37) | 50 (10) | 57 (34) | 37 (23) |
| Mine | Holder | 26 | 87 (26) | 6 | 80 | 38 | 46% | 3.2 | 102 (8) | 77 (15) | 94 (3) | 113 (12) | 64 (14) |
| Mine | Shooter | 44 | 86 (44) | 23 | 63 | 42 | 5% | 1.7 | 41 (6) | 107 (31) | 50 (7) | 112 (25) | 52 (19) |
| Mine | Support | 5 | 28 (5) | 28 | 0 | 42 | 20% | 3.8 | 95 (2) | 0 (3) | - | 49 (2) | 0 (3) |
| Mine | War machine | 56 | 39 (56) | 39 | 0 | 43 | 5% | 1.3 | 82 (13) | 27 (37) | 19 (6) | 50 (11) | 36 (45) |
| Mine | Wizard | 23 | 29 (23) | 29 | 0 | 42 | 13% | 2.5 | 51 (4) | 45 (10) | 0 (2) | 58 (3) | 35 (13) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Chaff | 68 | 83 (68) | 20 | 63 | 44 | 40% | 3.1 | 116 (29) | 38 (17) | 80 (22) | 110 (50) | 3 (18) |
| Opponent | Character | 113 | 58 (113) | 57 | 1 | 28 | 20% | 2.7 | 78 (38) | 47 (59) | 0 (5) | 56 (68) | 65 (34) |
| Opponent | Clean-up | 17 | 51 (17) | 44 | 7 | 54 | 29% | 2.8 | 87 (5) | 32 (9) | 37 (3) | 90 (9) | 15 (8) |
| Opponent | Early | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Fast Hammer | 53 | 50 (53) | 30 | 19 | 56 | 38% | 2.9 | 61 (22) | 34 (17) | 45 (14) | 53 (38) | 42 (15) |
| Opponent | Fragile | 10 | 25 (10) | 25 | 0 | 65 | 30% | 1.6 | 19 (3) | 48 (4) | 0 (3) | 30 (8) | 0 (2) |
| Opponent | Hammer | 64 | 31 (64) | 24 | 7 | 54 | 20% | 2.5 | 11 (16) | 38 (41) | 24 (7) | 27 (39) | 39 (25) |
| Opponent | Holder | 40 | 58 (40) | 5 | 53 | 34 | 42% | 3.5 | 16 (9) | 97 (19) | 21 (11) | 93 (22) | 16 (17) |
| Opponent | Shooter | 32 | 49 (32) | 8 | 40 | 53 | 3% | 1.3 | 50 (8) | 46 (19) | 57 (5) | 52 (17) | 43 (15) |
| Opponent | Support | 2 | 0 (2) | 0 | 0 | 50 | 50% | 4.0 | 0 (2) | - | - | 0 (1) | 0 (1) |
| Opponent | War machine | 13 | 27 (13) | 27 | 0 | 35 | 15% | 1.1 | 12 (5) | 16 (5) | 77 (3) | 0 (3) | 35 (10) |
| Opponent | Wizard | 24 | 5 (24) | 5 | 0 | 27 | 17% | 1.6 | 0 (10) | 14 (8) | 2 (4) | 5 (12) | 6 (10) |

### Charged fights: cb-h2h-opp-24b8cfb-p1

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 5 | 164 | 73 | 1.6 | 1.1 | 46 | 11 | +35 | 0 of 8 | 7 of 8 | -85 | +52 |
| Mine | Chaos Dwarfs | 3 | 0 | 578 | 4.0 | 1.1 | 145 | 28 | +116 | 6 of 12 | 7 of 12 | +0 | +127 |
| Mine | Dwarfen Mountain Holds | 4 | 217 | 120 | 2.2 | 1.1 | 53 | 11 | +43 | 5 of 9 | 7 of 9 | +0 | +48 |
| Mine | Empire of Man | 5 | 315 | 155 | 2.0 | 1.2 | 78 | 107 | -29 | 3 of 10 | 6 of 10 | -204 | +14 |
| Mine | Grand Cathay | 4 | 717 | 280 | 4.0 | 1.1 | 70 | 26 | +44 | 11 of 16 | 8 of 16 | +0 | +46 |
| Mine | High Elf Realms | 4 | 252 | 420 | 4.5 | 1.1 | 93 | 53 | +40 | 8 of 18 | 15 of 17 | +708 | +1 |
| Mine | Kingdom of Bretonnia | 1 | 0 | 526 | 5.0 | 1.0 | 105 | 0 | +105 | 2 of 5 | 5 of 5 | - | +105 |
| Mine | Lizardmen | 1 | 0 | 70 | 2.0 | 1.0 | 35 | 70 | -36 | 1 of 2 | 2 of 2 | - | -36 |
| Mine | Ogre Kingdoms | 1 | 70 | 132 | 3.0 | 1.0 | 44 | 0 | +44 | 0 of 3 | 2 of 3 | - | +44 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 626 | 6.0 | 1.2 | 104 | 73 | +32 | 3 of 6 | 5 of 6 | +265 | -15 |
| Mine | Skaven | 2 | 22 | 38 | 1.0 | 1.0 | 38 | 0 | +38 | 1 of 2 | 1 of 2 | - | +38 |
| Mine | Tomb Kings of Khemri | 2 | 0 | 936 | 5.0 | 1.2 | 187 | 0 | +187 | 4 of 10 | 8 of 10 | +62 | +218 |
| Mine | Vampire Counts | 2 | 0 | 630 | 3.5 | 1.3 | 180 | 27 | +154 | 1 of 7 | 5 of 7 | +256 | +113 |
| Mine | Warriors of Chaos | 1 | 0 | 115 | 3.0 | 1.0 | 38 | 10 | +28 | 1 of 3 | 2 of 3 | - | +28 |
| **Mine** | all armies | 36 | 201 | 301 | 3.1 | 1.1 | 98 | 34 | +64 | 46 of 111 | 80 of 110 | +93 | +60 |
| Opponent | Beastmen Brayherds | 1 | 0 | 65 | 3.0 | 1.3 | 22 | 102 | -81 | 1 of 3 | 1 of 3 | -255 | +6 |
| Opponent | Dwarfen Mountain Holds | 1 | 0 | 0 | 1.0 | 1.0 | 0 | 907 | -907 | 1 of 1 | 1 of 1 | - | -907 |
| Opponent | Empire of Man | 1 | 160 | 0 | 2.0 | 1.0 | 0 | 0 | +0 | 2 of 2 | 1 of 2 | - | +0 |
| Opponent | Grand Cathay | 1 | 235 | 340 | 5.0 | 1.2 | 68 | 41 | +27 | 3 of 5 | 2 of 5 | +115 | +5 |
| Opponent | High Elf Realms | 2 | 0 | 238 | 2.0 | 1.0 | 119 | 0 | +119 | 0 of 4 | 2 of 4 | - | +119 |
| Opponent | Lizardmen | 1 | 0 | 787 | 4.0 | 1.0 | 197 | 0 | +197 | 2 of 4 | 3 of 4 | - | +197 |
| Opponent | Ogre Kingdoms | 2 | 54 | 165 | 3.0 | 1.3 | 55 | 88 | -33 | 1 of 6 | 5 of 6 | -184 | +42 |
| Opponent | Orc & Goblin Tribes | 2 | 0 | 380 | 3.0 | 1.0 | 127 | 150 | -23 | 4 of 6 | 3 of 6 | - | -23 |
| Opponent | Skaven | 2 | 304 | 0 | 2.0 | 1.2 | 0 | 101 | -101 | 3 of 4 | 1 of 4 | +0 | -135 |
| Opponent | Tomb Kings of Khemri | 4 | 83 | 1096 | 5.2 | 1.2 | 209 | 19 | +190 | 9 of 21 | 17 of 21 | +308 | +170 |
| Opponent | Vampire Counts | 6 | 40 | 475 | 5.2 | 1.1 | 92 | 34 | +58 | 17 of 31 | 22 of 31 | +129 | +50 |
| Opponent | Warriors of Chaos | 7 | 0 | 341 | 2.7 | 1.0 | 126 | 18 | +108 | 8 of 19 | 12 of 19 | - | +108 |
| Opponent | Wood Elf Realms | 6 | 98 | 480 | 3.3 | 1.2 | 144 | 11 | +133 | 8 of 20 | 16 of 20 | +156 | +127 |
| **Opponent** | all armies | 36 | 63 | 424 | 3.5 | 1.1 | 121 | 42 | +79 | 59 of 126 | 86 of 126 | +95 | +77 |

### Effective charges: cb-h2h-opp-24b8cfb-p1

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 8 | 0 | 0 | 1 (net -85) | 1 (net +77) | 0 | 1 (net +0) | 5 | 33% (1 of 3) |
| Mine | Chaos Dwarfs | 12 | 2 (net -110) | 0 | 2 (net +272) | 0 | 1 (net +92) | 7 (net +140) | 0 | 17% (2 of 12) |
| Mine | Dwarfen Mountain Holds | 9 | 3 (net +0) | 1 (net +379) | 0 | 0 | 0 | 5 (net +1) | 0 | 0% (0 of 9) |
| Mine | Empire of Man | 10 | 2 (net -22) | 0 | 2 (net +54) | 0 | 2 (net -204) | 3 (net +79) | 1 | 22% (2 of 9) |
| Mine | Grand Cathay | 16 | 2 (net +272) | 0 | 7 (net +19) | 3 (net +20) | 0 | 4 (net -10) | 0 | 44% (7 of 16) |
| Mine | High Elf Realms | 18 | 1 (net +0) | 0 | 5 (net +54) | 2 (net -140) | 1 (net +0) | 7 (net +61) | 2 | 31% (5 of 16) |
| Mine | Kingdom of Bretonnia | 5 | 0 | 0 | 1 (net +0) | 0 | 1 (net +50) | 3 (net +159) | 0 | 20% (1 of 5) |
| Mine | Lizardmen | 2 | 0 | 0 | 0 | 0 | 1 (net +70) | 0 | 1 | 0% (0 of 1) |
| Mine | Ogre Kingdoms | 3 | 0 | 0 | 1 (net +0) | 2 (net +66) | 0 | 0 | 0 | 33% (1 of 3) |
| Mine | Orc & Goblin Tribes | 6 | 0 | 0 | 1 (net +265) | 0 | 0 | 1 (net +235) | 4 | 50% (1 of 2) |
| Mine | Skaven | 2 | 1 (net +0) | 0 | 0 | 0 | 0 | 1 (net +75) | 0 | 0% (0 of 2) |
| Mine | Tomb Kings of Khemri | 10 | 0 | 0 | 2 (net +268) | 1 (net +102) | 1 (net +125) | 3 (net +286) | 3 | 29% (2 of 7) |
| Mine | Vampire Counts | 7 | 1 (net +0) | 1 (net +170) | 2 (net +157) | 0 | 1 (net +80) | 2 (net +256) | 0 | 29% (2 of 7) |
| Mine | Warriors of Chaos | 3 | 1 (net -30) | 0 | 1 (net +0) | 0 | 1 (net +115) | 0 | 0 | 33% (1 of 3) |
| Opponent | Beastmen Brayherds | 3 | 0 | 0 | 2 (net +6) | 1 (net -255) | 0 | 0 | 0 | 67% (2 of 3) |
| Opponent | Dwarfen Mountain Holds | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net -907) | 0 | 0% (0 of 1) |
| Opponent | Empire of Man | 2 | 0 | 0 | 1 (net +0) | 1 (net +0) | 0 | 0 | 0 | 50% (1 of 2) |
| Opponent | Grand Cathay | 5 | 1 (net +0) | 0 | 0 | 2 (net -20) | 1 (net +115) | 1 (net +60) | 0 | 0% (0 of 5) |
| Opponent | High Elf Realms | 4 | 2 (net +156) | 0 | 1 (net +0) | 1 (net +165) | 0 | 0 | 0 | 25% (1 of 4) |
| Opponent | Lizardmen | 4 | 0 | 0 | 0 | 0 | 1 (net +77) | 1 (net +189) | 2 | 0% (0 of 2) |
| Opponent | Ogre Kingdoms | 6 | 1 (net +85) | 0 | 2 (net -157) | 0 | 0 | 1 (net +0) | 2 | 50% (2 of 4) |
| Opponent | Orc & Goblin Tribes | 6 | 0 | 0 | 0 | 1 (net +70) | 0 | 1 (net +310) | 4 | 0% (0 of 2) |
| Opponent | Skaven | 4 | 4 (net -101) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 4) |
| Opponent | Tomb Kings of Khemri | 21 | 1 (net -60) | 1 (net +405) | 5 (net +176) | 3 (net +37) | 0 | 9 (net +266) | 2 | 26% (5 of 19) |
| Opponent | Vampire Counts | 31 | 7 (net -3) | 1 (net -45) | 6 (net +112) | 3 (net -174) | 2 (net +66) | 9 (net +152) | 3 | 21% (6 of 28) |
| Opponent | Warriors of Chaos | 19 | 2 (net +224) | 0 | 4 (net +142) | 5 (net +85) | 2 (net +104) | 3 (net +104) | 3 | 25% (4 of 16) |
| Opponent | Wood Elf Realms | 20 | 3 (net -16) | 1 (net +347) | 2 (net +238) | 5 (net +165) | 1 (net +60) | 6 (net +121) | 2 | 11% (2 of 18) |

### Charged fights, damage counted: cb-h2h-opp-24b8cfb-p1

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 13 | 213 | 289 | +19 | 82 | 65 | +16 | +7.7 |
| Mine | 50-54% | 2 | 152 | 274 | +274 | 274 | 12 | +262 | +172.4 |
| Mine | Effective (55-75%) | 25 | 260 | 233 | +83 | 121 | 35 | +86 | +33.1 |
| Mine | 76-89% | 9 | 242 | 139 | +10 | 44 | 39 | +5 | +2.0 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 37 | 285 | 200 | +102 | 149 | 26 | +123 | +43.1 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 9 | 432 | 96 | +14 | 87 | 61 | +26 | +6.0 |
| Mine | No odds | 16 | 364 | 159 | +13 | 66 | 63 | +2 | +0.7 |
| Mine | All fights | 111 | 289 | 200 | +64 | 111 | 41 | +70 | +24.2 |
| Opponent | Long shot (under 50%) | 21 | 169 | 252 | +15 | 71 | 64 | +7 | +4.1 |
| Opponent | 50-54% | 3 | 328 | 239 | +236 | 251 | 64 | +187 | +56.9 |
| Opponent | Effective (55-75%) | 23 | 224 | 211 | +100 | 137 | 36 | +101 | +45.2 |
| Opponent | 76-89% | 22 | 291 | 168 | +35 | 145 | 91 | +53 | +18.4 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 32 | 290 | 209 | +139 | 189 | 51 | +138 | +47.4 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 7 | 353 | 86 | +85 | 102 | 13 | +89 | +25.1 |
| Opponent | No odds | 18 | 178 | 186 | +48 | 116 | 59 | +57 | +31.9 |
| Opponent | All fights | 126 | 246 | 200 | +79 | 138 | 57 | +81 | +33.0 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| cb-h2h-opp-24b8cfb-p1 | move | 435 | 110 (25%) | 78 (18%) | 60 (14%) | 265 (61%) |
| cb-h2h-opp-24b8cfb-p1 | objective | 358 | 63 (18%) | 43 (12%) | 51 (14%) | 244 (68%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0102, L0118, L0135, L2531, L2730 |
| Charmed Shield | Opponent | L0524, L1224, L1527, L1625, L2025, L2127, L2934 |
| Clockwork Compass | Mine | L1224 |
| Clockwork Compass | Opponent | L0612 |
| Elixir of Power | Mine | L1114, L1131, L1923 |
| Elixir of Power | Opponent | L0319, L1319 |
| Fistful of Laurels | Mine | L1823 |
| Fistful of Laurels | Opponent | L0118, L0218 |
| Horn of the Wild Hunt | Opponent | L0733 |
| Invocation of Nehek | Mine | L2531, L2730 |
| Invocation of Nehek | Opponent | L0524, L1224, L1527, L1625, L2025, L2127 |
| Opal Amulet | Mine | L1431 |
| Opal Amulet | Opponent | L1114 |
| Periapt of Soul Exchange | Mine | L2025, L2127 |
| Periapt of Soul Exchange | Opponent | L0421, L1021 |
| Ring of Doom | Mine | L0218, L0235, L1114, L1131, L1224, L1527 |
| Ring of Doom | Opponent | L0102, L0612, L0733, L1131, L1431, L2231, L2531 |
| Ring of Jet | Mine | L1021, L1114, L1131, L1224 |
| Ring of Jet | Opponent | L0612 |
| Standard of the Fell Warrior | Mine | L1319, L1335 |
| Standard of the Fell Warrior | Opponent | L0913 |
| Storm Daemon (Renegade 2.0) | Mine | L2127 |
| Storm Daemon (Renegade 2.0) | Opponent | L0421, L1021 |
| Twice-Blessed Armour | Mine | L0717, L0733, L1021 |
| Witch Hunter's Ward | Mine | L0717, L0733, L0823 |
| Witch Hunter's Ward | Opponent | L0508 |

# Doctrine scorecard: cb-h2h-mine-24b8cfb-p4

### Scorecard: cb-h2h-mine-24b8cfb-p4

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0114 | 6 | 1 | Mine | no | 4 | 3 | 2 | 0 | 1 | 0 | 0 | 0 |
| L0114 | 6 | 1 | Opponent | no | 10 | 1 | 5 | 0 | 1 | 0 | 0 | 0 |
| L0130 | 4 | 1 | Mine | yes | 2 | 4 | 1 | 2 | 0 | 0 | 0 | 65 |
| L0130 | 4 | 1 | Opponent | no | 1 | 1 | 5 | 3 | 0 | 0 | 0 | 0 |
| L0214 | 4 | 1 | Mine | no | 2 | 3 | 4 | 2 | 2 | 0 | 0 | 170 |
| L0214 | 4 | 1 | Opponent | no | 4 | 2 | 1 | 0 | 0 | 0 | 0 | 177 |
| L0230 | 2 | 1 | Mine | - | - | 1 | 4 | 2 | 1 | 0 | 0 | 170 |
| L0230 | 2 | 1 | Opponent | - | - | 3 | 4 | 1 | 1 | 0 | 0 | 0 |
| L0315 | 3 | 1 | Mine | no | 0 | 4 | 1 | 1 | 0 | 0 | 0 | 590 |
| L0315 | 3 | 1 | Opponent | yes | 4 | 2 | 3 | 0 | 0 | 0 | 0 | 0 |
| L0332 | 2 | 1 | Mine | - | - | 5 | 2 | 0 | 1 | 0 | 0 | 360 |
| L0332 | 2 | 1 | Opponent | - | - | 2 | 4 | 5 | 0 | 0 | 0 | 0 |
| L0417 | 3 | 1 | Mine | yes | 3 | 2 | 5 | 0 | 1 | 0 | 0 | 0 |
| L0417 | 3 | 1 | Opponent | yes | 3 | 2 | 3 | 0 | 0 | 0 | 0 | 0 |
| L0434 | 2 | 1 | Mine | - | - | 2 | 2 | 0 | 1 | 0 | 0 | 0 |
| L0434 | 2 | 1 | Opponent | - | - | 1 | 5 | 1 | 0 | 0 | 0 | 0 |
| L0520 | 4 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 1331 |
| L0520 | 4 | 1 | Opponent | no | 0 | - | 0 | 4 | 1 | 0 | 0 | 210 |
| L0608 | 2 | 1 | Mine | - | - | - | 1 | 3 | 0 | 0 | 0 | 615 |
| L0608 | 2 | 1 | Opponent | - | - | - | 0 | 2 | 0 | 0 | 0 | 605 |
| L0624 | 6 | 1 | Mine | no | 0 | 2 | 2 | 0 | 0 | 0 | 0 | 720 |
| L0624 | 6 | 1 | Opponent | no | 8 | 3 | 2 | 1 | 1 | 0 | 0 | 0 |
| L0713 | 5 | 1 | Mine | no | - | 4 | 0 | 0 | 2 | 0 | 0 | 452 |
| L0713 | 5 | 1 | Opponent | no | - | 2 | 2 | 3 | 1 | 0 | 0 | 302 |
| L0729 | 3 | 1 | Mine | no | 3 | 2 | 4 | 0 | 0 | 0 | 0 | 452 |
| L0729 | 3 | 1 | Opponent | no | 4 | 2 | 5 | 0 | 1 | 0 | 0 | 0 |
| L0819 | 3 | 1 | Mine | no | 0 | - | 0 | 0 | 1 | 0 | 0 | 1007 |
| L0819 | 3 | 1 | Opponent | no | 4 | 2 | 3 | 3 | 1 | 0 | 0 | 0 |
| L0835 | 1 | 1 | Mine | no | 0 | - | 0 | 0 | 0 | 0 | 0 | 515 |
| L0835 | 1 | 1 | Opponent | no | 0 | 2 | 3 | 3 | 0 | 0 | 0 | 0 |
| L0926 | 2 | 1 | Mine | - | - | 3 | 1 | 2 | 0 | 0 | 0 | 492 |
| L0926 | 2 | 1 | Opponent | - | - | 2 | 4 | 5 | 0 | 0 | 0 | 0 |
| L1017 | 3 | 1 | Mine | no | 4 | 2 | 3 | 0 | 1 | 0 | 0 | 456 |
| L1017 | 3 | 1 | Opponent | yes | 2 | 2 | 3 | 0 | 2 | 0 | 0 | 0 |
| L1034 | 2 | 1 | Mine | - | - | 2 | 1 | 0 | 0 | 0 | 0 | 330 |
| L1034 | 2 | 1 | Opponent | - | - | 3 | 1 | 6 | 0 | 0 | 0 | 527 |
| L1126 | 4 | 1 | Mine | no | 1 | 2 | 3 | 0 | 1 | 0 | 0 | 526 |
| L1126 | 4 | 1 | Opponent | no | 3 | 2 | 4 | 3 | 1 | 0 | 0 | 0 |
| L1220 | 2 | 1 | Mine | - | - | 2 | 3 | 0 | 0 | 0 | 0 | 330 |
| L1220 | 2 | 1 | Opponent | - | - | 4 | 3 | 4 | 2 | 0 | 0 | 0 |
| L1314 | 6 | 1 | Mine | no | 0 | 3 | 3 | 1 | 0 | 0 | 0 | 140 |
| L1314 | 6 | 1 | Opponent | no | 2 | 3 | 0 | 3 | 0 | 0 | 0 | 0 |
| L1331 | 5 | 1 | Mine | yes | - | 3 | 0 | 1 | 0 | 0 | 0 | 140 |
| L1331 | 5 | 1 | Opponent | no | - | 4 | 2 | 2 | 1 | 0 | 0 | 170 |
| L1427 | 5 | 1 | Mine | yes | - | 2 | 5 | 1 | 0 | 0 | 0 | 0 |
| L1427 | 5 | 1 | Opponent | no | - | 2 | 4 | 0 | 1 | 0 | 0 | 0 |
| L1523 | 5 | 1 | Mine | yes | - | 2 | 3 | 0 | 1 | 0 | 0 | 0 |
| L1523 | 5 | 1 | Opponent | yes | - | 4 | 3 | 2 | 0 | 0 | 0 | 66 |
| L1621 | 1 | 1 | Mine | no | 4 | 2 | 5 | 0 | 0 | 0 | 0 | 200 |
| L1621 | 1 | 1 | Opponent | no | 2 | 5 | 5 | 3 | 0 | 0 | 0 | 500 |
| L1719 | 3 | 1 | Mine | yes | 2 | 2 | 8 | 0 | 0 | 0 | 0 | 0 |
| L1719 | 3 | 1 | Opponent | yes | 2 | 2 | 5 | 1 | 1 | 0 | 0 | 0 |
| L1819 | 1 | 1 | Mine | no | 1 | 4 | 5 | 1 | 0 | 0 | 0 | 0 |
| L1819 | 1 | 1 | Opponent | no | 2 | 2 | 4 | 0 | 0 | 0 | 0 | 0 |
| L1835 | 5 | 1 | Mine | no | - | 6 | 0 | 3 | 0 | 0 | 0 | 0 |
| L1835 | 5 | 1 | Opponent | yes | - | 2 | 4 | 3 | 0 | 0 | 0 | 0 |
| L2021 | 5 | 1 | Mine | yes | - | - | 2 | 3 | 0 | 0 | 0 | 420 |
| L2021 | 5 | 1 | Opponent | no | - | 4 | 1 | 5 | 0 | 0 | 0 | 145 |
| L2123 | 5 | 1 | Mine | no | - | - | 1 | 5 | 1 | 0 | 0 | 565 |
| L2123 | 5 | 1 | Opponent | yes | - | 2 | 3 | 2 | 1 | 0 | 0 | 0 |
| L2227 | 1 | 1 | Mine | no | 2 | 2 | 1 | 1 | 0 | 0 | 0 | 0 |
| L2227 | 1 | 1 | Opponent | yes | 4 | 1 | 4 | 2 | 1 | 0 | 0 | 75 |
| L2331 | 3 | 1 | Mine | no | 3 | 3 | 2 | 1 | 0 | 0 | 0 | 0 |
| L2331 | 3 | 1 | Opponent | yes | 3 | 5 | 2 | 2 | 1 | 0 | 0 | 170 |
| L2527 | 1 | 1 | Mine | no | 0 | 3 | 2 | 1 | 1 | 0 | 0 | 0 |
| L2527 | 1 | 1 | Opponent | no | 0 | 1 | 2 | 3 | 1 | 0 | 0 | 0 |
| L2634 | 6 | 1 | Mine | no | 0 | 1 | 6 | 0 | 0 | 0 | 0 | 0 |
| L2634 | 6 | 1 | Opponent | no | 6 | 2 | 6 | 2 | 0 | 0 | 0 | 160 |
| L2930 | 2 | 1 | Mine | - | - | 2 | 7 | 1 | 0 | 0 | 0 | 0 |
| L2930 | 2 | 1 | Opponent | - | - | 2 | 6 | 1 | 0 | 0 | 0 | 0 |
| L3234 | 6 | 1 | Mine | no | 0 | 2 | 5 | 3 | 0 | 0 | 0 | 0 |
| L3234 | 6 | 1 | Opponent | no | 0 | 2 | 3 | 0 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 25% | 1.5 | 2.7 | 2.6 | 1.0 | 0.4 | 0.0 | 0.0 | 279.1 |
| **Average** | | | Opponent | 32% | 3.0 | 2.4 | 3.2 | 2.1 | 0.5 | 0.0 | 0.0 | 86.3 |

### KPIs: cb-h2h-mine-24b8cfb-p4

Rules off - Opponent only: CHARGE BAND, JOINT KNOWS CHALLENGE, REFUSING RETIRES, BLOWS WHERE AIMED, SPELLS IN THE FIGHT, CHARGER SLAIN LOST, WIDER SPREAD.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 24% (40 of 166) | 2% (4 of 187) | 12% (44 of 353) |
| Winner chose to follow up after the loser gave ground |  | 98% (44 of 45); on the table 98% | 99% (73 of 74); on the table 99% | 98% (117 of 119); on the table 98% |
| Winner chose to pursue after the loser fell back in good order |  | 89% (8 of 9); on the table 89% | 100% (16 of 16); on the table 100% | 96% (24 of 25); on the table 96% |
| Winner chose to pursue after the loser fled |  | 85% (22 of 26); on the table 85% | 81% (38 of 47); on the table 87% | 82% (60 of 73); on the table 86% |
| Winner chose to follow up or pursue (all three) |  | 92% (74 of 80); on the table 92% | 93% (127 of 137); on the table 95% | 93% (201 of 217); on the table 94% |
| Magic missiles tried each own turn | 50%+ | 29% (78 of 270) | 33% (56 of 171) | 30% (134 of 441) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 43% (78 of 180) | 48% (56 of 117) | 45% (134 of 297) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 58% (22 of 38) | 54% (32 of 59) | 56% (54 of 97) |
| Points that never fought | lower | 33% (22126 of 67942) | 33% (23716 of 71984) | 33% (45842 of 139926) |
|   infantry points that never fought | lower | 39% (5945 of 15347) | 55% (7647 of 13804) | 47% (13592 of 29151) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 61% (165 of 270) | 54% (150 of 280) | 57% (315 of 550) |
| Bound items with a magic missile used (at least once a game) |  | 86% (19 of 22); 1.5 uses a game | 89% (8 of 9); 0.8 uses a game | 87% (27 of 31); 1.1 uses a game |
| Bound items with another spell used |  | 56% (9 of 16); 0.5 uses a game | 50% (10 of 20); 0.3 uses a game | 53% (19 of 36); 0.4 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 58% (11 of 19); 0.3 uses a game | 80% (12 of 15); 0.4 uses a game | 68% (23 of 34); 0.3 uses a game |
|   their share of the points of units over 100 pts | lower | 55% (31547 of 57750) | 46% (29185 of 63347) | 50% (60732 of 121097) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.4 (27%) | 0.8 (25%) | 2.2 (26%) |
| MARCHED: its unit marched | 1.0 (19%) | 0.4 (13%) | 1.4 (17%) |
| CHARGED: its unit charged | 0.3 (6%) | 0.2 (7%) | 0.5 (6%) |
| IN COMBAT: engaged in combat | 1.4 (26%) | 0.6 (19%) | 2.0 (23%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.2 (8%) | 0.2 (3%) |
| FLEEING: fleeing | 0.1 (2%) | 0.0 (0%) | 0.1 (1%) |
| GONE: slain | 1.1 (20%) | 0.9 (28%) | 1.9 (23%) |
| STUPIDITY: Stupidity | 0.1 (2%) | 0.0 (0%) | 0.1 (1%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.4 | 1.3 | 1.9 | 3.7 | 0.3 | 2.2 |
| not cast | 2.8 | 2.6 | 2.9 | 8.5 | 1.7 | 20.7 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.3 (11%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.3 (52%) | 0.2 (8%) | 2.2 (26%) | 0.5 (28%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.4 (17%) | 0.4 (23%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.5 (6%) | 0.1 (3%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.2 (6%) | 0.1 (5%) | 0.6 (21%) | 2.0 (23%) | 0.4 (27%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.2 (6%) | 0.2 (6%) | 0.3 (12%) | 0.2 (3%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.1 (3%) | 0.0 (0%) | 0.1 (3%) | 0.1 (1%) | 0.0 (0%) | 0.4 (2%) |
| GONE: slain | 0.7 (24%) | 0.5 (19%) | 0.4 (15%) | 1.9 (23%) | 0.2 (12%) | 3.7 (18%) |
| OFF THE TABLE: off the table or not arrived | 0.2 (6%) | 0.0 (0%) | 0.1 (5%) | 0.0 (0%) | 0.0 (0%) | 0.1 (0%) |
| STUPIDITY: Stupidity | 0.1 (4%) | 0.0 (0%) | 0.0 (1%) | 0.1 (1%) | 0.0 (0%) | 0.1 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (1%) | 0.3 (13%) | 0.0 (0%) | 0.0 (0%) | 0.1 (7%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.4 (50%) | 0.1 (4%) | 1.0 (36%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 14.1 (68%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.5 a game | 0.6 a game | 1.0 a game |
| stood (cast and not dispelled) | 57% (27 of 47) | 20% (2 of 10) | 51% (29 of 57) |
| the unit moved after it | 74% (20 of 27) | 100% (2 of 2) | 76% (22 of 29) |
| it charged on its next turn | 7% (2 of 27) | 0% (0 of 2) | 7% (2 of 29) |
| the enemy charged it first | 33% (9 of 27) | 0% (0 of 2) | 31% (9 of 29) |
| it fought by the end of its next turn | 22% (6 of 27) | 0% (0 of 2) | 21% (6 of 29) |
| it moved out of a charge the enemy had planned (not charged first) | 7% (2 of 27) | 50% (1 of 2) | 10% (3 of 29) |
| none of these (no charge, no fight, no charge escaped) | 48% (13 of 27) | 50% (1 of 2) | 48% (14 of 29) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 62% (555 of 890) | 50% (281 of 562) | 58% (836 of 1452) |
|   cavalry | 53% (46 of 86) | 66% (85 of 128) | 61% (131 of 214) |
|   character | 40% (42 of 105) | 14% (18 of 129) | 26% (60 of 234) |
|   chariot | 42% (43 of 103) | 56% (10 of 18) | 44% (53 of 121) |
|   infantry | 63% (171 of 272) | 60% (142 of 237) | 61% (313 of 509) |
|   monster | 52% (24 of 46) | 15% (4 of 26) | 39% (28 of 72) |
|   war machine | 82% (229 of 278) | 92% (22 of 24) | 83% (251 of 302) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.1 (23%) | 1.5 (19%) | 3.6 (21%) |
| CHARGED: it charged | 1.2 (13%) | 1.7 (22%) | 3.0 (17%) |
| FLEEING: it fled or was fleeing | 0.1 (1%) | 0.1 (2%) | 0.2 (1%) |
| IN COMBAT: it fought this turn or the last | 1.0 (11%) | 0.5 (6%) | 1.5 (9%) |
| MOVED: a war machine that moved | 0.1 (1%) | 0.0 (0%) | 0.1 (0%) |
| HELD FIRE: a target, but it held its fire | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NO TARGET IN RANGE | 2.1 (23%) | 1.7 (22%) | 3.9 (23%) |
| ONLY IN COMBAT: the only targets were in combat | 0.8 (8%) | 0.6 (7%) | 1.3 (8%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.2 (13%) | 1.6 (20%) | 2.8 (17%) |
| SHELTERED: the target was sheltered | 0.4 (4%) | 0.1 (1%) | 0.4 (2%) |
| OTHER BAR | 0.3 (3%) | 0.1 (1%) | 0.3 (2%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 5.9 | 1.8 | 79% | 5.8 pts | 34 pts |
| character | 1.9 | 0.6 | 80% | 9.3 pts | 18 pts |
| chariot | 1.5 | 0.7 | 74% | 12.6 pts | 19 pts |
| infantry | 12.5 | 4.4 | 75% | 10.5 pts | 131 pts |
| monster | 0.9 | 0.1 | 97% | 1.1 pts | 1 pts |
| war machine | 7.0 | 4.7 | 66% | 24.4 pts | 170 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.5 | 6.8 | 5.6 |
| Charges that made contact a game | 3.6 | 4.9 | 4.2 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.35 declared, 1.00 contact (17 units) | 0.53 declared, 0.40 contact (15 units) | 0.97 declared, 0.72 contact (32 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.78 declared, 0.44 contact (9 units) | 1.46 declared, 1.31 contact (13 units) | 1.18 declared, 0.95 contact (22 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.52 declared, 0.43 contact (250 units) | 0.76 declared, 0.53 contact (288 units) | 0.65 declared, 0.48 contact (538 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 54% (44 of 81) | 38% (6 of 16) | 50% (3 of 6) | 51% (53 of 103) |
| Character in a unit | 79% (19 of 24) | 65% (11 of 17) | 100% (1 of 1) | 74% (31 of 42) |
| Character on its own | 83% (34 of 41) | 44% (11 of 25) | 25% (19 of 77) | 45% (64 of 143) |
| Chariot | 73% (11 of 15) | 75% (9 of 12) | - | 74% (20 of 27) |
| Infantry | 57% (47 of 83) | 44% (11 of 25) | 50% (3 of 6) | 54% (61 of 114) |
| Monster | 74% (25 of 34) | 86% (12 of 14) | - | 77% (37 of 48) |
| Monstrous | 64% (9 of 14) | 50% (7 of 14) | - | 57% (16 of 28) |
| War Machines | 72% (31 of 43) | 100% (2 of 2) | - | 73% (33 of 45) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 92% (12 of 13); on the table 92% | 31% (32 of 102) | 11% | 59% (13 of 22) | 83% (5 of 6); 2.2 uses a game | 100% (2 of 2); 1.0 uses a game | 83% (5 of 6); 1.2 uses a game |
| Chaos Dwarfs | 4 | 92% (12 of 13); on the table 92% | 46% (11 of 24) | 23% | 62% (20 of 32) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
| Dwarfen Mountain Holds | 3 | 67% (2 of 3); on the table 67% | - | 74% | 63% (17 of 27) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 6 | 100% (14 of 14); on the table 100% | 50% (9 of 18) | 47% | 68% (42 of 62) | 0.0 uses a game | 50% (1 of 2); 0.7 uses a game | 60% (3 of 5); 0.5 uses a game |
| Grand Cathay | 4 | 100% (6 of 6); on the table 100% | 23% (19 of 84) | 32% | 46% (17 of 37) | 89% (8 of 9); 6.5 uses a game | 50% (1 of 2); 0.5 uses a game | 25% (1 of 4); 0.2 uses a game |
| High Elf Realms | 9 | 90% (26 of 29); on the table 93% | 19% (7 of 36) | 32% | 49% (34 of 70) | 100% (7 of 7); 2.9 uses a game | 50% (15 of 30); 2.2 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | 100% (1 of 1); on the table 100% | - | 35% | 17% (1 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Lizardmen | 3 | 91% (20 of 22); on the table 91% | 50% (3 of 6) | 21% | 62% (13 of 21) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 2 | 100% (8 of 8); on the table 100% | 83% (5 of 6) | 41% | 79% (11 of 14) | 50% (1 of 2); 1.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 3 | 100% (13 of 13); on the table 100% | 21% (9 of 42) | 17% | 46% (11 of 24) | 0.0 uses a game | 0.0 uses a game | 67% (2 of 3); 0.7 uses a game |
| Skaven | 6 | 100% (10 of 10); on the table 100% | 32% (13 of 40) | 43% | 69% (31 of 45) | 100% (3 of 3); 1.2 uses a game | 0.0 uses a game | 83% (5 of 6); 1.0 uses a game |
| Tomb Kings of Khemri | 4 | 90% (9 of 10); on the table 90% | 0% (0 of 6) | 36% | 40% (8 of 20) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 8 | 88% (22 of 25); on the table 96% | 34% (20 of 59) | 17% | 48% (20 of 42) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 9 | 87% (26 of 30); on the table 87% | 42% (5 of 12) | 30% | 60% (43 of 72) | 100% (2 of 2); 1.0 uses a game | 0.0 uses a game | 100% (3 of 3); 0.3 uses a game |
| Wood Elf Realms | 6 | 100% (20 of 20); on the table 100% | 17% (1 of 6) | 42% | 61% (34 of 56) | 50% (1 of 2); 0.5 uses a game | 0.0 uses a game | 50% (2 of 4); 0.3 uses a game |

Flank and rear charges a unit could have turned to face (cb-h2h-mine-24b8cfb-p4, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 49% (55) | 43% (35) | 46% (90) |
| ...free all their last turn and able to turn (per game) | 0.83 | 0.64 | 1.47 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.36 | 0.17 | 0.53 |
| ...with the charger already in that arc before they moved (per game) | 0.44 | 0.47 | 0.92 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 1.75 | 1.33 | 3.08 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.89 | 0.64 | 1.53 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 5.17 | 5.75 | 10.92 |

### Quality by phase: cb-h2h-mine-24b8cfb-p4

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.1 | 3.6 |
| Strategy | Charge objectives carried out (made contact) | 51% (86 of 170) | 53% (108 of 203) |
| Strategy | Shoot objectives carried out (shot that target) | 53% (205 of 386) | 43% (66 of 154) |
| Strategy | Close-in objectives charged next turn | 18% (25 of 140) | 14% (32 of 226) |
| Strategy | Support requests answered (helper made contact too) | 61% (11 of 18) | 32% (9 of 28) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (3 of 3) | 100% (1 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | 56% (9 of 16) | 100% (1 of 1) |
| Strategy | Joined characters whose unit fought | 48% (16 of 33) | 30% (9 of 30) |
| Strategy | Lone characters that fought | 81% (73 of 90) | 86% (74 of 86) |
| Movement | Charges halted short of contact | 0.1 | 0.2 |
| Movement | Idle units | 1.0 | 2.1 |
| Movement | Points that never moved of their own | 279.1 | 86.3 |
| Movement | Fights charged into per game | 3.2 | 4.2 |
| Movement | Charges with odds: long shots (under 50%) | 16 of 108, net +35 | 19 of 135, net +12 |
| Movement | Charges with odds: sweet spot (55-75%) | 29 of 108, net -6 | 23 of 135, net +67 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 15 of 108, net +74 | 11 of 135, net +176 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 19 of 108, net +124 | 49 of 135, net +78 |
| Shooting | Shots by shooting units (incl. breath weapons) | 9.8 | 8.2 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 48% (169 of 353) | 48% (142 of 296) |
| Shooting | Points destroyed by shooting units | 88.6 | 59.8 |
| Shooting | War machine shots | 6.4 | 0.6 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 53% (122 of 229) | 5% (1 of 22) |
| Shooting | Points destroyed by war machines | 67.3 | 9.4 |
| Magic | Magic missiles cast | 1.3 | 1.2 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 28% (13 of 46) | 24% (10 of 42) |
| Magic | Wounds caused by magic missiles | 2.9 | 1.3 |
| Magic | Wounds caused by other spells | 1.9 | 1.7 |
| Magic | Points destroyed by magic (all spells) | 67.4 | 29.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.3 / 0.5 / 0.9 / 0.1 | 1.9 / 0.3 / 0.8 / 0.1 |
| Combat | Points destroyed in combat | 316.6 | 437.1 |
| Combat | Points run down | 87.4 | 145.0 |
| Combat | Net points per charged fight, damage counted | +72 | +87 |
| Combat | Net per 100 charger points, damage counted | +24.0 | +29.3 |
| Combat | First round won (charged fights) | 72% | 69% |
| Combat | Net points per charged fight | +62 | +86 |
| Combat | Net points per supported fight / lone fight | +42 / +65 | +139 / +80 |
| Combat | Charged fights on a top-3 enemy unit | 44 of 117 | 67 of 150 |
| Game | Points lost | 827.1 | 716.2 |
| Game | VP from objectives | 544.7 | 529.4 |
| Game | Lone holders (player turns) | 1.5 | 3.0 |

- Mine won / drew / lost: 15 / 7 / 14 of 36 ended games (of 36); mean margin (Mine - Opponent) -105 VP
- The side that went first won 13 of 29 games with a winner
- Points traded per game (both sides' losses): 1543
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: cb-h2h-mine-24b8cfb-p4

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 0.8 | +0.0 | 0.0 | 0.0 |
| ALREADY CARRIED | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARTILLERY RE-ROLL WEIGHED | 1.3 | +0.0 | 0.0 | 12.6 | 0.1 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | 1.0 | +6.2 | 0.0 | 11.8 | 1.1 | +11.9 | 0.0 | 6.4 |
| BEST FACING | 0.7 | +30.0 | 0.0 | 25.4 | 0.5 | +12.8 | 0.0 | 9.9 |
| BEST FIRST | 3.9 | +129.6 | 140.9 | 112.7 | 4.0 | +195.9 | 105.4 | 71.6 |
| BEST OVERALL | 0.3 | +40.6 | 0.0 | 8.1 | 0.4 | +25.6 | 0.0 | 12.3 |
| BEST PREY | 0.6 | +44.1 | 21.0 | 7.4 | 0.8 | +23.6 | 37.0 | 0.0 |
| BEST PRIZE | 0.1 | -8.7 | 6.8 | 0.0 | 0.1 | +0.7 | 0.0 | 5.4 |
| BIG CHARACTER SAFETY | 0.2 | +0.1 | 0.0 | 0.0 | 0.2 | +0.6 | 0.0 | 11.1 |
| BLOCKED CHARGE SKIPPED | 0.1 | +0.0 | 0.0 | 13.4 | 0.2 | +0.0 | 0.0 | 0.0 |
| BLOCKED WHEEL | 0.5 | -0.8 | 0.0 | 0.0 | 0.6 | +10.8 | 0.0 | 9.8 |
| BLOWS WHERE AIMED | 0.2 | -32.3 | 37.9 | 24.7 | - | - | - | - |
| BOMBING RUN | 0.0 | +1.0 | 0.0 | 0.0 | - | - | - | - |
| BOUND ASSAILMENT | 0.1 | +0.0 | 0.0 | 11.0 | - | - | - | - |
| CANNON PLAN MISSED | 0.7 | +0.0 | 102.9 | 12.6 | - | - | - | - |
| CANNON PLANNED TARGET | 5.1 | +191.8 | 400.1 | 94.3 | 0.6 | +24.8 | 44.1 | 7.4 |
| CANNON SIGHT KEPT | 1.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT COUNTER | 0.1 | +0.0 | 15.1 | 0.0 | 0.1 | -2.3 | 0.0 | 0.0 |
| CARRIES OUT SET-UP | 0.1 | +0.0 | 1.9 | 6.0 | 0.1 | +0.0 | 0.0 | 5.1 |
| CAST JOB | 0.6 | +33.4 | 54.2 | 2.4 | 0.4 | +12.6 | 23.4 | 18.2 |
| CASTER AWAY FROM SCREEN | 0.3 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.2 | +27.8 | 19.4 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | 0.8 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 22.9 |
| CASTS FROM BEHIND | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.0 | +0.5 | 0.0 | 0.0 | - | - | - | - |
| CHAFF PASSED | 0.2 | -0.1 | 7.9 | 5.0 | 0.1 | -0.7 | 0.0 | 5.6 |
| CHAMPION TAKES THE CHALLENGE | - | - | - | - | 0.1 | +15.5 | 8.9 | 0.0 |
| CHARGE BAND | 0.1 | +0.0 | 0.0 | 2.0 | - | - | - | - |
| CHARGE NOW FIRST | 3.1 | +0.0 | 296.5 | 140.3 | 3.3 | +0.0 | 320.3 | 89.8 |
| CHARGE NOW WEIGHED | 0.4 | -30.8 | 33.9 | 31.7 | 0.7 | -60.2 | 39.6 | 25.6 |
| CHARGER SLAIN LOST | 0.7 | -25.6 | 126.3 | 31.8 | - | - | - | - |
| CHARIOT NO STATIC JOB | 0.0 | +0.0 | 13.9 | 2.4 | - | - | - | - |
| CHARIOT WIZARD CAREFUL | 0.1 | -0.9 | 0.0 | 0.0 | 0.3 | -1.9 | 22.0 | 37.2 |
| CHEAP HELPER | 0.1 | +0.0 | 28.9 | 5.4 | 0.1 | +0.0 | 8.0 | 1.4 |
| COMBAT PIVOT | 0.4 | +0.0 | 25.4 | 30.0 | 0.6 | +0.0 | 27.1 | 59.3 |
| CONVEYANCE SEARCH | 0.9 | +126.8 | 7.8 | 9.3 | 0.2 | +40.5 | 13.9 | 13.9 |
| COUNTER-CHARGE COVER | 8.6 | +604.6 | 0.0 | 196.4 | 7.0 | +630.1 | 0.0 | 151.4 |
| DEFENSIVE ARMY | 0.1 | +0.0 | 9.5 | 3.5 | 0.0 | +0.0 | 0.0 | 0.0 |
| DEFENSIVE FLOOR | 0.1 | +1.8 | 2.6 | 0.0 | 0.1 | +1.8 | 1.8 | 1.8 |
| EDGE GIVE GROUND | 0.1 | +0.7 | 18.6 | 2.6 | 0.1 | +5.7 | 11.2 | 1.2 |
| ELIXIR WORTH | - | - | - | - | 0.1 | +1.3 | 0.0 | 0.0 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 1.8 | +140.6 | 0.0 | 56.0 | 1.3 | +130.5 | 0.0 | 48.7 |
| FALLBACK BY WORTH | 4.8 | +55.2 | 0.0 | 104.6 | 6.3 | +53.7 | 0.0 | 79.6 |
| FIGHT LIFT | 0.2 | +3.8 | 34.6 | 16.1 | - | - | - | - |
| FIRE AND FLEE | 0.0 | +0.6 | 0.0 | 0.0 | 0.0 | +0.2 | 0.0 | 3.0 |
| FLANK NOT WEIGHED | 4.6 | +0.0 | 0.0 | 85.5 | 5.4 | +0.0 | 0.0 | 115.0 |
| FOCUS FIRE | - | - | - | - | 0.0 | +0.5 | 1.2 | 0.0 |
| FOLLOW UP WEIGHED | 0.9 | +132.0 | 0.0 | 63.8 | 1.2 | +205.1 | 0.0 | 73.5 |
| FRIENDS SHOTS CHECKED | 0.2 | +12.9 | 0.0 | 6.5 | 0.2 | +15.8 | 0.0 | 2.5 |
| GIVES UP | 0.1 | -0.3 | 10.7 | 0.0 | 0.1 | -2.6 | 0.0 | 0.0 |
| GIVES UP ITS SCREEN | 0.0 | -0.1 | 0.0 | 1.1 | 0.1 | -0.1 | 0.0 | 1.2 |
| GROUND FLIERS | 0.1 | +0.7 | 0.0 | 6.1 | 0.1 | +1.8 | 0.0 | 0.0 |
| HELPER ALREADY ASKED | 0.1 | +0.0 | 1.8 | 2.6 | 0.0 | +0.0 | 0.0 | 0.8 |
| HELPER UNSEEN | 0.4 | +0.0 | 64.9 | 16.2 | 0.3 | +0.0 | 8.3 | 7.6 |
| HILL BY ITS CHANCE | 0.5 | -63.3 | 0.0 | 16.3 | 0.5 | -49.5 | 0.0 | 10.4 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| HUNT ADVANCE | 0.1 | +0.1 | 10.6 | 0.0 | 0.2 | +2.5 | 6.9 | 3.2 |
| HUNT DROPPED | 0.0 | +0.0 | 13.9 | 2.4 | 0.1 | +0.0 | 0.0 | 5.0 |
| HUNT IN PAIRS | 0.2 | +5.9 | 0.0 | 0.0 | 0.4 | +16.1 | 0.0 | 0.0 |
| HUNT KEPT | 0.1 | +0.1 | 19.2 | 1.5 | 0.0 | +0.0 | 3.5 | 0.0 |
| HUNT RESULT | 0.1 | +48.0 | 13.9 | 3.8 | 0.2 | +17.7 | 4.6 | 7.5 |
| HUNT THE GUNS | 0.1 | +67.2 | 60.0 | 3.9 | 0.2 | +76.2 | 13.9 | 3.2 |
| INVITES THE FIGHT | 1.9 | +38.5 | 107.8 | 38.3 | 1.0 | +14.5 | 33.8 | 21.0 |
| JOINT CHARGE PLAN | 0.2 | +2.5 | 13.4 | 6.0 | 0.3 | +10.5 | 20.7 | 7.4 |
| KEEP FALLS | 0.1 | +0.7 | 0.0 | 6.1 | - | - | - | - |
| KEEPS ITS PREY | 0.1 | +0.8 | 7.9 | 0.0 | 0.1 | +0.1 | 3.5 | 0.0 |
| KEEPS ITS TARGET | 1.8 | +52.5 | 160.5 | 48.3 | 1.9 | +55.8 | 116.7 | 45.1 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KILLS COUNT | 1.9 | +76.0 | 167.4 | 78.0 | 2.3 | +124.6 | 176.8 | 46.5 |
| KILLS COUNT NEXT TURN | 4.9 | +150.2 | 174.7 | 139.0 | 7.4 | +256.3 | 202.0 | 135.8 |
| LONE CHARACTER SAFE SPOT | 0.4 | +3.8 | 0.8 | 11.3 | 0.2 | +9.8 | 7.7 | 24.4 |
| LONE WIZARD HOLDS BACK | 0.1 | +0.0 | 5.2 | 0.0 | 0.3 | +0.0 | 3.7 | 5.3 |
| LONE WIZARD KEPT IN | 0.6 | +26.9 | 0.0 | 0.0 | 0.2 | +20.3 | 0.0 | 0.0 |
| LONG SHOT | 0.4 | -1.3 | 33.2 | 6.7 | 0.5 | +1.2 | 23.6 | 4.8 |
| LOST CHARGE | 3.3 | -41.1 | 132.3 | 71.1 | 1.8 | -27.7 | 44.2 | 55.2 |
| LURE BY WHAT IT DRAWS | 0.1 | -4.8 | 0.0 | 0.0 | 0.1 | -2.5 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 0.6 | +57.0 | 26.7 | 24.4 | 0.7 | +108.2 | 24.6 | 38.8 |
| MANOEUVRE | 0.1 | +3.4 | 0.0 | 8.9 | 0.2 | +6.8 | 0.0 | 2.7 |
| MARCH AT ESCAPER | 0.1 | +0.4 | 0.0 | 0.0 | 0.1 | +1.5 | 0.0 | 5.1 |
| MARCH CHECK | 0.8 | +42.8 | 0.0 | 11.1 | 0.4 | +18.7 | 0.0 | 13.1 |
| MARCH ODDS | 0.3 | +12.6 | 8.4 | 10.8 | 0.3 | +20.4 | 9.5 | 0.0 |
| MARCH OVER CASTS | 0.5 | +33.8 | 0.0 | 4.5 | 0.2 | +27.1 | 0.0 | 5.1 |
| MAX FOR POSITIONING | 4.5 | +151.6 | 0.0 | 79.1 | 4.8 | +171.7 | 0.0 | 128.2 |
| MISSILES IN THE MOVE | 3.6 | +138.1 | 0.0 | 92.1 | 2.4 | +36.3 | 0.0 | 97.4 |
| MISSILES NEXT TURN | 4.5 | +95.2 | 0.0 | 89.3 | 3.0 | +28.8 | 0.0 | 99.3 |
| MODEL FACING | 0.2 | +36.5 | 0.0 | 1.7 | - | - | - | - |
| MONSTER WIZARD ROAMS | 0.2 | +0.0 | 9.1 | 10.6 | 0.2 | +0.0 | 7.8 | 0.0 |
| MOVE AND CAST | 0.3 | +14.1 | 0.0 | 6.9 | 0.2 | +6.3 | 0.0 | 8.5 |
| MOVE SPELL IN RANGE | 0.2 | +4.9 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.8 | -42.7 | 25.2 | 4.7 | 0.1 | -13.6 | 16.6 | 0.0 |
| MOVE SPELL SPOT | 0.4 | +0.0 | 0.0 | 12.3 | 0.0 | +0.0 | 0.0 | 13.9 |
| MOVE TO CHARGE | 2.9 | +115.9 | 86.3 | 63.0 | 4.8 | +416.2 | 189.1 | 81.0 |
| MOVES UNITS SPELL | 0.1 | +3.3 | 0.0 | 0.0 | 0.1 | +0.6 | 0.0 | 0.0 |
| NEEDED THERE | 0.0 | +3.5 | 0.0 | 16.1 | 0.1 | +15.8 | 4.0 | 0.0 |
| NO RALLY LEFT | 0.1 | +3.7 | 0.0 | 11.0 | 0.0 | +1.2 | 0.0 | 0.0 |
| NOT NEEDED | 0.3 | -8.5 | 24.7 | 0.0 | 0.2 | -8.7 | 30.4 | 1.2 |
| NOT TURNED | 5.2 | +85.4 | 0.0 | 113.1 | 5.8 | +83.0 | 0.0 | 96.3 |
| NOT WORTH A CAST | 0.5 | -17.5 | 0.0 | 2.4 | 0.3 | -0.2 | 0.0 | 0.0 |
| OFF BEST | 15.0 | -698.5 | 13.1 | 307.7 | 13.4 | -787.4 | 5.0 | 177.7 |
| OPENS A LANE | 0.2 | +0.6 | 26.5 | 6.4 | - | - | - | - |
| OPENS UP | 0.6 | +48.6 | 35.4 | 21.8 | 0.4 | +37.4 | 22.5 | 0.0 |
| OVERRUNS AWAY | 0.7 | +16.1 | 69.8 | 29.9 | 0.5 | +6.9 | 38.2 | 33.0 |
| PATHS CROSS | 2.2 | +130.1 | 0.0 | 35.3 | 3.2 | +253.3 | 0.0 | 43.9 |
| PERIAPT WORTH | 0.1 | +6.8 | 0.0 | 15.0 | 0.1 | +10.2 | 0.0 | 30.0 |
| PIVOT GUARDS FLANK | 0.1 | -0.7 | 0.0 | 0.0 | 0.1 | -1.4 | 0.0 | 3.8 |
| PLAN RESULT | 38.4 | +1746.1 | 1630.6 | 1066.3 | 39.6 | +1294.3 | 1529.0 | 1020.1 |
| PURSUES BIG PREY | 0.1 | -8.7 | 0.0 | 0.0 | 0.1 | -3.8 | 0.0 | 0.0 |
| PURSUES ON | 0.0 | +0.1 | 0.0 | 0.0 | - | - | - | - |
| RAIDS THE BAGGAGE | - | - | - | - | 0.0 | +4.9 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE NEXT TURN | 0.1 | +7.2 | 0.0 | 2.2 | 0.2 | +20.5 | 0.0 | 5.7 |
| RANDOM MOVE BY FIGURES | 1.1 | +16.4 | 0.0 | 39.7 | 1.6 | +15.1 | 0.0 | 72.9 |
| RANDOM MOVER NO PROMISE | 0.4 | -18.9 | 12.7 | 14.2 | 0.3 | -15.9 | 5.1 | 14.6 |
| REDIRECT BY WHAT IT STOPS | 0.2 | -3.4 | 0.0 | 1.0 | 0.5 | -9.2 | 0.0 | 9.2 |
| REDIRECT COUNTER | 2.4 | +173.0 | 0.0 | 27.5 | 4.0 | +305.8 | 0.0 | 55.8 |
| REDIRECT WEIGHED | 0.2 | -0.7 | 13.7 | 0.0 | 0.5 | +8.8 | 8.1 | 5.4 |
| REFUSING RETIRES | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| RESERVE FALL BACK | 0.7 | +13.2 | 0.0 | 9.8 | 0.6 | +25.8 | 0.0 | 7.4 |
| RESTRAINS TO SHOOT | 0.1 | +6.8 | 0.0 | 11.8 | 0.1 | +1.7 | 0.0 | 0.0 |
| RISK BY ARC | 3.2 | +122.3 | 302.1 | 136.6 | 3.2 | +78.1 | 241.3 | 115.7 |
| SAFER THAN THE JOB | 0.9 | +70.9 | 0.0 | 22.9 | 0.6 | +28.6 | 0.0 | 23.4 |
| SCOUT SPOT | 0.4 | +0.5 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| SCOUT WAITS | 0.5 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.1 | -8.9 | 0.0 | 0.8 | 0.4 | -16.6 | 0.0 | 0.0 |
| SEARCH SPOT | 2.3 | +78.4 | 0.0 | 46.0 | 3.2 | +182.4 | 0.0 | 43.7 |
| SELF MOVE SPELL | 0.2 | +60.5 | 0.0 | 0.0 | 0.4 | +32.5 | 0.0 | 18.1 |
| SET UP TOGETHER | 0.8 | +77.1 | 26.7 | 34.9 | 1.5 | +147.7 | 39.0 | 54.1 |
| SET-UP ANY TARGET | 0.6 | +74.5 | 2.6 | 9.3 | 0.1 | +16.5 | 0.0 | 0.0 |
| SET-UP MISSED | 0.1 | +11.8 | 0.0 | 9.3 | 0.1 | +9.2 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.3 | +0.8 | 0.0 | 0.0 | 0.2 | +0.3 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 0.8 | +24.2 | 44.8 | 36.4 | 0.8 | +30.7 | 29.4 | 25.7 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| SHOT REPLANNED | 0.6 | +0.0 | 142.6 | 12.2 | 0.3 | +0.0 | 42.4 | 7.4 |
| SHOTS IN THE MOVE | 14.5 | +609.4 | 0.0 | 288.5 | 7.2 | +242.6 | 0.0 | 111.8 |
| SPELL CATCH ODDS | 0.1 | -1.2 | 0.0 | 0.0 | - | - | - | - |
| SPELL SETS UP CHARGE | 0.6 | +102.2 | 2.6 | 9.3 | 0.1 | +25.7 | 13.9 | 13.9 |
| SPELL WORTH | 1.5 | +25.5 | 40.1 | 24.3 | 2.2 | +39.2 | 83.7 | 81.0 |
| SPELLS IN THE FIGHT | 1.3 | -12.1 | 204.6 | 90.0 | - | - | - | - |
| STABLE ROLE | 10.9 | +0.0 | 446.1 | 232.0 | 10.6 | +0.0 | 438.4 | 138.2 |
| STANDS TO CAST | 0.0 | +1.8 | 0.0 | 0.0 | - | - | - | - |
| STAY WEIGHED | 0.1 | +6.3 | 0.0 | 0.0 | - | - | - | - |
| STOPS | 0.1 | +1.7 | 68.6 | 5.4 | 0.1 | +1.7 | 6.9 | 0.0 |
| STOPS SHORT OF THE FLANK | 0.6 | +26.4 | 0.0 | 7.8 | 0.4 | +7.5 | 0.0 | 11.1 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 24.0 |
| SUPPORT NARROWED | 5.7 | -38.2 | 355.2 | 149.5 | 8.4 | -48.0 | 509.5 | 120.2 |
| SUPPORTS | 3.2 | +47.2 | 111.8 | 50.1 | 5.8 | +48.0 | 281.5 | 66.0 |
| SURE CHARGE BEATS ADVANCE | 0.1 | -3.3 | 0.0 | 1.4 | 0.1 | -1.9 | 2.6 | 0.0 |
| SURE REACH TOGETHER | 0.3 | -2.4 | 1.9 | 12.0 | 0.4 | -6.6 | 6.6 | 3.2 |
| THROUGH LINE OF FIRE | 0.3 | +9.8 | 0.0 | 2.1 | 0.2 | +4.1 | 0.0 | 1.9 |
| TURN WORTH | 0.5 | -38.3 | 25.0 | 3.9 | 0.5 | -50.7 | 37.5 | 17.9 |
| TWO OR MORE ARRIVE | 0.3 | +1.3 | 6.7 | 6.0 | 0.3 | +2.5 | 0.0 | 1.8 |
| WAIT AFTER COSTS | 7.0 | -273.2 | 282.0 | 130.4 | 7.5 | -388.0 | 306.9 | 127.6 |
| WALKS TO THE FIGHT | 1.8 | +33.6 | 43.7 | 6.5 | 0.8 | +19.8 | 50.4 | 12.0 |
| WAR ENGINE CHARGES | 0.1 | +7.8 | 13.4 | 13.8 | - | - | - | - |
| WAR ENGINE JOBS | 0.8 | +0.0 | 44.3 | 32.4 | 0.1 | +0.0 | 7.5 | 4.0 |
| WEARS DOWN | 1.2 | +52.8 | 121.5 | 76.1 | 1.4 | +44.9 | 92.0 | 44.2 |
| WHO HITS BACK | 0.4 | +25.7 | 0.0 | 3.9 | 0.5 | +32.1 | 0.0 | 44.5 |
| WHOLE FIGHT | 0.4 | +11.4 | 67.7 | 11.1 | 0.6 | +35.1 | 89.5 | 4.9 |
| WHOLE FIGHT GAIN | 0.4 | +18.2 | 48.2 | 36.6 | 0.6 | +54.6 | 30.3 | 7.1 |
| WIDER SPREAD | 3.4 | -7.3 | 334.0 | 187.8 | - | - | - | - |
| WOUNDED STAYS OUT | 0.0 | +0.0 | 0.0 | 13.1 | 0.0 | +0.0 | 0.0 | 0.0 |

### Rule changes: cb-h2h-mine-24b8cfb-p4

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 1023 | 1023 | 1023 | 28.42 | -53492 | -52.3 |
| BEST FIRST | 287 | 287 | 287 | 7.97 | +11718 | +40.8 |
| PATHS CROSS | 195 | 195 | 195 | 5.42 | +13803 | +70.8 |
| SEARCH SPOT | 200 | 200 | 195 | 5.42 | +9426 | +48.3 |
| MOVE TO CHARGE | 274 | 274 | 141 | 3.92 | +7986 | +56.6 |
| COUNTER-CHARGE COVER | 560 | 310 | 139 | 3.86 | +8687 | +62.5 |
| KILLS COUNT NEXT TURN | 441 | 441 | 112 | 3.11 | +3125 | +27.9 |
| FACES THE THREAT | 111 | 111 | 111 | 3.08 | +9760 | +87.9 |
| SUPPORTS | 322 | 322 | 105 | 2.92 | +970 | +9.2 |
| FALLBACK BY WORTH | 399 | 399 | 84 | 2.33 | +3920 | +46.7 |
| FOLLOW UP WEIGHED | 76 | 76 | 76 | 2.11 | +12137 | +159.7 |
| WAIT AFTER COSTS | 523 | 523 | 73 | 2.03 | +1288 | +17.6 |
| SHOTS IN THE MOVE | 784 | 526 | 64 | 1.78 | +3034 | +47.4 |
| WALKS TO THE FIGHT | 95 | 95 | 61 | 1.69 | +809 | +13.3 |
| ADVANCE LANE KEPT | 55 | 55 | 55 | 1.53 | +0 | +0.0 |
| CHARGE NOW FIRST | 231 | 231 | 55 | 1.53 | -3307 | -60.1 |
| SAFER THAN THE JOB | 55 | 55 | 55 | 1.53 | +3581 | +65.1 |
| RANDOM MOVE BY FIGURES | 97 | 97 | 54 | 1.50 | +1133 | +21.0 |
| REDIRECT COUNTER | 230 | 141 | 52 | 1.44 | +3993 | +76.8 |
| ARTILLERY RE-ROLL WEIGHED | 51 | 51 | 51 | 1.42 | +0 | +0.0 |
| RISK BY ARC | 229 | 221 | 46 | 1.28 | +1525 | +33.1 |
| RESERVE FALL BACK | 45 | 45 | 45 | 1.25 | +1402 | +31.2 |
| MAX FOR POSITIONING | 334 | 191 | 43 | 1.19 | +492 | +11.4 |
| CANNON SIGHT KEPT | 42 | 42 | 42 | 1.17 | +0 | +0.0 |
| BEST FACING | 41 | 41 | 41 | 1.14 | +1540 | +37.6 |
| CHARGE NOW WEIGHED | 41 | 41 | 41 | 1.14 | +2158 | +52.6 |
| BLOCKED WHEEL | 40 | 40 | 40 | 1.11 | +359 | +9.0 |
| KILLS COUNT | 151 | 146 | 40 | 1.11 | +2186 | +54.7 |
| CANNON PLANNED TARGET | 205 | 205 | 39 | 1.08 | -375 | -9.6 |
| COMBAT PIVOT | 37 | 37 | 37 | 1.03 | +0 | +0.0 |
| HOLDS AMBUSHERS | 35 | 35 | 35 | 0.97 | +0 | +0.0 |
| MARCH CHECK | 40 | 39 | 35 | 0.97 | +2349 | +67.1 |
| SHOT REPLANNED | 34 | 34 | 34 | 0.94 | +0 | +0.0 |
| STOPS SHORT OF THE FLANK | 34 | 34 | 34 | 0.94 | +1221 | +35.9 |
| SET UP TOGETHER | 84 | 71 | 30 | 0.83 | +3421 | +114.0 |
| WHO HITS BACK | 30 | 30 | 30 | 0.83 | +1484 | +49.5 |
| LONE WIZARD KEPT IN | 28 | 28 | 28 | 0.78 | +1699 | +60.7 |
| MISSILES IN THE MOVE | 216 | 132 | 27 | 0.75 | +961 | +35.6 |
| BEST OVERALL | 26 | 26 | 26 | 0.72 | +2384 | +91.7 |
| REDIRECT WEIGHED | 24 | 24 | 24 | 0.67 | +894 | +37.3 |
| SHOOTS FROM THE BEST SPOT | 56 | 56 | 24 | 0.67 | +659 | +27.5 |
| OPENS UP | 35 | 35 | 22 | 0.61 | +1171 | +53.2 |
| CAST JOB | 38 | 38 | 21 | 0.58 | +709 | +33.8 |
| SCOUT WAITS | 21 | 21 | 21 | 0.58 | +0 | +0.0 |
| MARCH ODDS | 20 | 20 | 20 | 0.56 | +320 | +16.0 |
| MOVE AND CAST | 20 | 20 | 20 | 0.56 | +735 | +36.7 |
| THROUGH LINE OF FIRE | 20 | 20 | 20 | 0.56 | +498 | +24.9 |
| WHOLE FIGHT GAIN | 35 | 33 | 20 | 0.56 | +1106 | +55.3 |
| BEST PREY | 52 | 52 | 19 | 0.53 | +972 | +51.2 |
| KEEPS ITS TARGET | 130 | 130 | 19 | 0.53 | +351 | +18.5 |
| SHOOTERS IN TWO RANKS | 18 | 18 | 18 | 0.50 | +41 | +2.3 |
| CASTER AWAY FROM SCREEN | 17 | 17 | 17 | 0.47 | +0 | +0.0 |
| INVITES THE FIGHT | 105 | 105 | 17 | 0.47 | +170 | +10.0 |
| BIG CHARACTER SAFETY | 16 | 16 | 16 | 0.44 | +22 | +1.4 |
| FRIENDS SHOTS CHECKED | 15 | 15 | 15 | 0.42 | +1033 | +68.9 |
| WAR ENGINE JOBS | 31 | 31 | 15 | 0.42 | -979 | -65.3 |
| WEARS DOWN | 94 | 91 | 15 | 0.42 | +526 | +35.1 |
| STUCK PIVOT | 14 | 14 | 14 | 0.39 | +0 | +0.0 |
| CHAFF PASSED | 12 | 12 | 12 | 0.33 | -31 | -2.6 |
| MAKE SURE TOGETHER | 47 | 33 | 12 | 0.33 | +2618 | +218.2 |
| MANOEUVRE | 10 | 10 | 10 | 0.28 | +365 | +36.5 |
| CASTS FROM BEHIND | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| MODEL FACING | 9 | 9 | 9 | 0.25 | +1312 | +145.8 |
| SHORT GUN FORWARD | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| SUPPORT NARROWED | 509 | 509 | 9 | 0.25 | -100 | -11.1 |
| BLOCKED CHARGE SKIPPED | 8 | 8 | 8 | 0.22 | +0 | +0.0 |
| RAIDS THE BAGGAGE NEXT TURN | 10 | 10 | 8 | 0.22 | +477 | +59.6 |
| RESTRAINS TO SHOOT | 8 | 8 | 8 | 0.22 | +304 | +38.0 |
| MOVES UNITS SPELL | 7 | 7 | 7 | 0.19 | +138 | +19.7 |
| PURSUES BIG PREY | 7 | 7 | 7 | 0.19 | -450 | -64.4 |
| SURE CHARGE BEATS ADVANCE | 7 | 7 | 7 | 0.19 | -188 | -26.9 |
| PERIAPT WORTH | 6 | 6 | 6 | 0.17 | +611 | +101.9 |
| BEST PRIZE | 5 | 5 | 5 | 0.14 | -591 | -118.1 |
| LONG SHOT | 33 | 33 | 5 | 0.14 | +78 | +15.6 |
| OVERRUNS AWAY | 45 | 44 | 5 | 0.14 | +114 | +22.8 |
| PIVOT GUARDS FLANK | 5 | 5 | 5 | 0.14 | -75 | -15.0 |
| SURE REACH TOGETHER | 24 | 21 | 5 | 0.14 | +64 | +12.9 |
| BACKUP TARGETS | 78 | 36 | 4 | 0.11 | +21 | +5.2 |
| CASTING BLOCK | 7 | 7 | 4 | 0.11 | +600 | +150.0 |
| CHARGE BAND | 4 | 4 | 4 | 0.11 | +0 | +0.0 |
| HUNT IN PAIRS | 25 | 14 | 4 | 0.11 | +93 | +23.2 |
| LOST CHARGE | 182 | 181 | 4 | 0.11 | +110 | +27.6 |
| MISSILES NEXT TURN | 269 | 155 | 4 | 0.11 | +7 | +1.6 |
| NO RALLY LEFT | 4 | 4 | 4 | 0.11 | +98 | +24.5 |
| STAY WEIGHED | 4 | 4 | 4 | 0.11 | +229 | +57.1 |
| WHOLE FIGHT | 37 | 37 | 4 | 0.11 | +500 | +125.1 |
| BOUND ASSAILMENT | 3 | 3 | 3 | 0.08 | +0 | +0.2 |
| DEFENSIVE FLOOR | 4 | 4 | 3 | 0.08 | +47 | +15.8 |
| JOINT CHARGE PLAN | 16 | 16 | 3 | 0.08 | +155 | +51.8 |
| NEEDED THERE | 3 | 3 | 3 | 0.08 | +0 | +0.0 |
| DEFENSIVE ARMY | 4 | 4 | 2 | 0.06 | -6 | -2.8 |
| ELIXIR WORTH | 2 | 2 | 2 | 0.06 | +48 | +24.0 |
| FIRE AND FLEE | 2 | 2 | 2 | 0.06 | +30 | +15.2 |
| KEEP FALLS | 2 | 2 | 2 | 0.06 | +98 | +48.9 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| LONE WIZARD HOLDS BACK | 12 | 12 | 2 | 0.06 | -107 | -53.3 |
| REFUSING RETIRES | 3 | 3 | 2 | 0.06 | -1 | -0.6 |
| WIDER SPREAD | 124 | 120 | 2 | 0.06 | +7 | +3.5 |
| BOMBING RUN | 1 | 1 | 1 | 0.03 | +37 | +37.4 |
| CARRIES OUT COUNTER | 4 | 4 | 1 | 0.03 | -83 | -82.8 |
| CHARGER SLAIN LOST | 24 | 22 | 1 | 0.03 | +30 | +29.9 |
| FOCUS FIRE | 1 | 1 | 1 | 0.03 | +18 | +17.8 |
| HUNT ADVANCE | 8 | 8 | 1 | 0.03 | +36 | +35.6 |
| OPENS A LANE | 8 | 6 | 1 | 0.03 | +2 | +1.7 |
| PURSUES ON | 1 | 1 | 1 | 0.03 | +4 | +3.9 |
| RAIDS THE BAGGAGE | 1 | 1 | 1 | 0.03 | +173 | +172.9 |
| REDIRECT BY WHAT IT STOPS | 25 | 25 | 1 | 0.03 | +66 | +65.5 |
| SPELLS IN THE FIGHT | 47 | 46 | 1 | 0.03 | +0 | +0.0 |
| STANDS TO CAST | 1 | 1 | 1 | 0.03 | -42 | -42.3 |
| STOPS | 8 | 8 | 1 | 0.03 | +12 | +11.9 |
| TWO OR MORE ARRIVE | 22 | 22 | 1 | 0.03 | +2 | +2.5 |
| ALREADY CARRIED | 2 | not checked | - | - | - | - |
| BLOWS WHERE AIMED | 9 | 8 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 24 | 24 | 0 | 0.00 | - | - |
| CARRIES OUT SET-UP | 5 | 5 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 37 | trace | - | - | - | - |
| CATCH FLIERS | 1 | not checked | - | - | - | - |
| CHAMPION TAKES THE CHALLENGE | 2 | 2 | 0 | 0.00 | - | - |
| CHARIOT NO STATIC JOB | 1 | 1 | 0 | 0.00 | - | - |
| CHARIOT WIZARD CAREFUL | 13 | 13 | 0 | 0.00 | - | - |
| CHEAP HELPER | 8 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 42 | not checked | - | - | - | - |
| EDGE GIVE GROUND | 9 | 9 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT LIFT | 7 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 359 | not checked | - | - | - | - |
| GIVES UP | 4 | 4 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 3 | 3 | 0 | 0.00 | - | - |
| GROUND FLIERS | 5 | not checked | - | - | - | - |
| HELPER ALREADY ASKED | 3 | not checked | - | - | - | - |
| HELPER UNSEEN | 25 | 24 | 0 | 0.00 | - | - |
| HILL BY ITS CHANCE | 36 | 36 | 0 | 0.00 | - | - |
| HUNT DROPPED | 5 | trace | - | - | - | - |
| HUNT KEPT | 3 | trace | - | - | - | - |
| HUNT RESULT | 13 | trace | - | - | - | - |
| HUNT THE GUNS | 14 | trace | - | - | - | - |
| KEEPS ITS PREY | 6 | 6 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 22 | not checked | - | - | - | - |
| LURE BY WHAT IT DRAWS | 7 | 7 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 7 | trace | - | - | - | - |
| MARCH OVER CASTS | 28 | 28 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 12 | 12 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 8 | 3 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 31 | trace | - | - | - | - |
| MOVE SPELL SPOT | 17 | not checked | - | - | - | - |
| NOT NEEDED | 18 | 18 | 0 | 0.00 | - | - |
| NOT TURNED | 393 | 393 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 30 | not checked | - | - | - | - |
| PLAN RESULT | 2807 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 27 | 27 | 0 | 0.00 | - | - |
| SCOUT SPOT | 19 | 19 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 17 | 17 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 22 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 24 | not checked | - | - | - | - |
| SET-UP MISSED | 4 | trace | - | - | - | - |
| SPELL CATCH ODDS | 2 | not checked | - | - | - | - |
| SPELL SETS UP CHARGE | 27 | not checked | - | - | - | - |
| SPELL WORTH | 135 | not checked | - | - | - | - |
| STABLE ROLE | 775 | 772 | 0 | 0.00 | - | - |
| TURN WORTH | 36 | 36 | 0 | 0.00 | - | - |
| WAR ENGINE CHARGES | 2 | 2 | 0 | 0.00 | - | - |
| WOUNDED STAYS OUT | 2 | 2 | 0 | 0.00 | - | - |

### Off best figure: cb-h2h-mine-24b8cfb-p4

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 12.97 | 11.86 | 54.6 |
| CHARGE NOW FIRST | rule | 0.75 | 0.78 | 60.1 |
| FALLBACK | gate | 0.75 | 0.64 | 50.6 |
| TURN GATE | gate | 0.78 | 0.50 | 24.8 |
| WAR ENGINE JOBS | rule | 0.42 | - | 65.3 |
| CANNON PLANNED TARGET | rule | 0.36 | - | 52.0 |
| LONE CHARACTER SAFE SPOT | gate | 0.17 | 0.17 | 48.7 |
| AFTERMATH BAND | gate | 0.19 | 0.08 | 2.7 |
| PATHS CROSS | rule | 0.17 | 0.11 | 52.5 |
| SUPPORT NARROWED | rule | 0.06 | 0.19 | 11.1 |
| BLOCKED WHEEL | rule | 0.11 | 0.08 | 30.9 |
| CHARGE NOW WEIGHED | rule | 0.08 | 0.11 | 51.7 |
| PURSUES BIG PREY | rule | 0.14 | 0.06 | 64.4 |
| SUPPORT REQUEST | gate | 0.08 | 0.11 | 46.4 |
| SURE CHARGE BEATS ADVANCE | rule | 0.14 | 0.06 | 26.9 |
| BIG CHARACTER SAFETY | rule | 0.08 | 0.08 | 7.8 |
| BEST PRIZE | rule | 0.08 | 0.06 | 118.1 |
| CHAFF PASSED | rule | 0.06 | 0.08 | 6.2 |
| PIVOT GUARDS FLANK | rule | 0.06 | 0.08 | 15.0 |
| STOPS SHORT OF THE FLANK | rule | 0.08 | 0.06 | 9.3 |
| DEFENSIVE ARMY | rule | 0.03 | 0.03 | 2.8 |
| FALLBACK BY WORTH | rule | 0.03 | 0.03 | 48.3 |
| FIGHT ORDER BAND | gate | 0.06 | - | 3.0 |
| LONE WIZARD HOLDS BACK | rule | - | 0.06 | 53.3 |
| THROUGH LINE OF FIRE | rule | 0.06 | - | 43.8 |
| AFTERMATH NEEDS NEXT CHARGE | gate | - | 0.03 | 51.1 |
| CARRIES OUT COUNTER | rule | - | 0.03 | 82.8 |
| FRIENDS SHOTS CHECKED | rule | - | 0.03 | 3.7 |
| LONG SHOT | rule | - | 0.03 | 4.8 |
| MARCH ODDS | rule | - | 0.03 | 4.5 |
| NO REASON | gate | 0.03 | - | 15.7 |
| REDIRECT WEIGHED | rule | 0.03 | - | 24.5 |
| REFUSING RETIRES | rule | 0.03 | - | 0.8 |
| SAFER THAN THE JOB | rule | - | 0.03 | 0.6 |
| STANDS TO CAST | rule | 0.03 | - | 42.3 |

### Plans: cb-h2h-mine-24b8cfb-p4

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 12.5 | 14% | 402 | 341 | 85% |
| Mine | charge | 4.2 | 53% | 360 | 372 | 103% |
| Mine | close in | 3.9 | 28% | 245 | 114 | 47% |
| Mine | hold | 4.4 | 37% | 279 | 0 | 0% |
| Mine | join | 0.6 | 95% | 14 | 0 | 0% |
| Mine | shoot | 9.4 | 62% | 348 | 919 | 264% |
| Mine | support | 3.5 | 92% | 36 | 0 | 0% |
| Opponent | advance | 13.8 | 19% | 389 | 409 | 105% |
| Opponent | charge | 4.9 | 53% | 623 | 430 | 69% |
| Opponent | close in | 6.2 | 27% | 526 | 198 | 38% |
| Opponent | hold | 4.0 | 34% | 252 | 0 | 0% |
| Opponent | join | 0.6 | 95% | 25 | 0 | 0% |
| Opponent | shoot | 3.6 | 60% | 94 | 264 | 280% |
| Opponent | support | 6.4 | 88% | 34 | 0 | 0% |

### Packages: hunt the guns, cb-h2h-mine-24b8cfb-p4

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.1 | 5 | 0 | 60% | 80% | 0% | 2.5 | 484 | 345 | 80% | 28 |
| Opponent | 0.2 | 9 | 1 | 25% | 38% | 0% | 2.0 | 315 | 80 | 38% | 94 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.8 | 3 | 0 | 67% | 67% | 0% | 2.5 | 581 | 355 | 67% | 0 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Dwarfen Mountain Holds | 0.3 | 1 | 0 | 100% | 100% | 0% | 2.0 | 481 | 470 | 100% | 113 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 177 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| High Elf Realms | 0.1 | 1 | 0 | 100% | 100% | 0% | 2.0 | 104 | 98 | 100% | 52 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 117 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 41 |
| Tomb Kings of Khemri | 0.5 | 2 | 0 | 0% | 50% | 0% | 3.0 | 324 | 96 | 50% | 0 |
| Vampire Counts | 0.6 | 5 | 0 | 20% | 40% | 0% | 2.0 | 307 | 108 | 40% | 92 |
| Warriors of Chaos | 0.2 | 2 | 1 | 0% | 0% | 0% | - | 429 | 0 | 0% | 51 |
| Wood Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 121 |

### Battle groups: cb-h2h-mine-24b8cfb-p4

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 8.6 | 25% | 53% | 10% | 25% | 37% | 14% | 4% | 44% | 0% |
| Mine | REDIRECT COUNTER | 2.4 | 38% | 52% | 9% | 33% | 27% | 3% | 3% | 60% | 7% |
| Opponent | COUNTER-CHARGE COVER | 7.0 | 20% | 72% | 26% | 23% | 32% | 14% | 22% | 32% | 0% |
| Opponent | REDIRECT COUNTER | 4.0 | 28% | 78% | 27% | 27% | 27% | 0% | 17% | 57% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: cb-h2h-mine-24b8cfb-p4

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 4 | 0 (4) | 0 | 0 | 100 | 0% | 2.5 | - | 0 (1) | - | - | 0 (1) |
| Mine | Chaff | 34 | 20 (34) | 9 | 11 | 60 | 29% | 2.3 | 34 (14) | 19 (7) | 7 (13) | 19 (22) | 21 (12) |
| Mine | Character | 106 | 44 (106) | 44 | 0 | 43 | 13% | 2.2 | 64 (31) | 38 (51) | 11 (5) | 44 (46) | 47 (41) |
| Mine | Clean-up | 22 | 52 (22) | 27 | 25 | 36 | 18% | 3.3 | 16 (2) | 69 (16) | 19 (4) | 67 (10) | 44 (12) |
| Mine | Early | 1 | 0 (1) | 0 | 0 | 100 | 0% | 6.0 | - | 0 (1) | - | - | 0 (1) |
| Mine | Fast | 4 | 127 (4) | 127 | 0 | 23 | 0% | 3.5 | 0 (2) | 254 (2) | - | 113 (3) | 166 (1) |
| Mine | Fast Hammer | 40 | 47 (40) | 32 | 16 | 52 | 10% | 2.6 | 52 (26) | 48 (9) | 21 (5) | 59 (25) | 29 (15) |
| Mine | Fragile | 4 | 0 (4) | 0 | 0 | 54 | 25% | 3.0 | 0 (1) | 0 (3) | - | 0 (1) | 0 (3) |
| Mine | Hammer | 65 | 37 (65) | 22 | 15 | 42 | 18% | 2.4 | 29 (13) | 38 (45) | 41 (7) | 30 (40) | 45 (25) |
| Mine | Holder | 31 | 101 (31) | 9 | 91 | 40 | 29% | 3.1 | 3 (8) | 174 (17) | 46 (6) | 135 (19) | 58 (12) |
| Mine | Shooter | 35 | 58 (35) | 27 | 31 | 50 | 3% | 1.8 | 44 (9) | 58 (21) | 83 (5) | 55 (25) | 65 (10) |
| Mine | Support | 1 | 0 (1) | 0 | 0 | 0 | 0% | 5.0 | - | 0 (1) | - | - | 0 (1) |
| Mine | War machine | 56 | 49 (56) | 49 | 0 | 48 | 5% | 1.2 | 36 (16) | 38 (30) | 110 (10) | 56 (9) | 48 (47) |
| Mine | Wizard | 17 | 3 (17) | 3 | 0 | 38 | 12% | 2.1 | 0 (5) | 7 (6) | 0 (1) | 10 (6) | 0 (6) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Chaff | 75 | 39 (75) | 16 | 24 | 53 | 39% | 2.7 | 67 (31) | 17 (17) | 27 (27) | 46 (56) | 15 (19) |
| Opponent | Character | 97 | 57 (97) | 57 | 0 | 31 | 22% | 2.3 | 60 (42) | 56 (39) | 75 (6) | 73 (49) | 43 (38) |
| Opponent | Clean-up | 11 | 73 (11) | 38 | 35 | 17 | 27% | 2.6 | 34 (3) | 73 (6) | 100 (2) | 57 (6) | 83 (5) |
| Opponent | Fast | 1 | 142 (1) | 142 | 0 | 0 | 0% | 4.0 | - | 142 (1) | - | 142 (1) | - |
| Opponent | Fast Hammer | 60 | 73 (60) | 55 | 18 | 45 | 27% | 2.5 | 60 (26) | 83 (25) | 100 (9) | 71 (39) | 78 (21) |
| Opponent | Fragile | 17 | 6 (17) | 6 | 0 | 54 | 12% | 2.1 | 0 (5) | 0 (8) | 25 (4) | 8 (14) | 0 (3) |
| Opponent | Hammer | 65 | 37 (65) | 26 | 11 | 41 | 38% | 3.1 | 10 (20) | 47 (38) | 32 (7) | 49 (41) | 18 (24) |
| Opponent | Holder | 29 | 26 (29) | 5 | 21 | 29 | 55% | 3.7 | 26 (11) | 35 (11) | 6 (6) | 40 (16) | 10 (12) |
| Opponent | Shooter | 33 | 97 (33) | 34 | 63 | 43 | 3% | 1.4 | 15 (9) | 133 (21) | 101 (3) | 68 (18) | 130 (15) |
| Opponent | Support | 6 | 0 (6) | 0 | 0 | 34 | 33% | 2.5 | 0 (4) | 0 (1) | 0 (1) | 0 (3) | 0 (3) |
| Opponent | War machine | 6 | 153 (6) | 153 | 0 | 50 | 0% | 1.2 | 61 (3) | 284 (3) | - | 61 (3) | 284 (3) |
| Opponent | Wizard | 19 | 16 (19) | 16 | 0 | 47 | 11% | 1.9 | 22 (10) | 10 (3) | 0 (2) | 14 (8) | 19 (7) |

### Charged fights: cb-h2h-mine-24b8cfb-p4

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 325 | 123 | 3.0 | 1.2 | 41 | 18 | +23 | 4 of 12 | 6 of 12 | -169 | +40 |
| Mine | Chaos Dwarfs | 4 | 116 | 293 | 3.8 | 1.1 | 78 | 43 | +35 | 7 of 15 | 11 of 15 | +0 | +37 |
| Mine | Dwarfen Mountain Holds | 3 | 632 | 71 | 1.0 | 1.0 | 71 | 78 | -6 | 2 of 3 | 1 of 3 | - | -6 |
| Mine | Empire of Man | 5 | 393 | 35 | 1.0 | 1.0 | 35 | 0 | +35 | 1 of 5 | 4 of 5 | - | +35 |
| Mine | Grand Cathay | 4 | 261 | 418 | 3.2 | 1.4 | 128 | 0 | +128 | 4 of 13 | 12 of 13 | +103 | +144 |
| Mine | High Elf Realms | 4 | 130 | 367 | 4.5 | 1.3 | 82 | 0 | +82 | 7 of 18 | 12 of 18 | +48 | +94 |
| Mine | Kingdom of Bretonnia | 1 | 245 | 302 | 5.0 | 1.2 | 60 | 0 | +60 | 4 of 5 | 4 of 5 | +210 | +23 |
| Mine | Lizardmen | 1 | 0 | 1136 | 6.0 | 1.0 | 189 | 91 | +98 | 3 of 6 | 5 of 6 | - | +98 |
| Mine | Ogre Kingdoms | 2 | 51 | 178 | 3.0 | 1.2 | 60 | 59 | +1 | 2 of 6 | 4 of 6 | -318 | +65 |
| Mine | Skaven | 2 | 132 | 105 | 3.0 | 1.0 | 35 | 7 | +28 | 1 of 6 | 4 of 6 | - | +28 |
| Mine | Tomb Kings of Khemri | 2 | 0 | 292 | 3.5 | 1.4 | 84 | 0 | +84 | 2 of 7 | 7 of 7 | +68 | +95 |
| Mine | Vampire Counts | 2 | 116 | 506 | 4.5 | 1.0 | 112 | 0 | +112 | 4 of 9 | 4 of 9 | - | +112 |
| Mine | Warriors of Chaos | 2 | 0 | 228 | 6.0 | 1.1 | 38 | 0 | +38 | 3 of 12 | 10 of 12 | +70 | +35 |
| **Mine** | all armies | 36 | 223 | 257 | 3.2 | 1.2 | 79 | 17 | +62 | 44 of 117 | 84 of 117 | +42 | +65 |
| Opponent | Empire of Man | 1 | 400 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | High Elf Realms | 5 | 274 | 842 | 4.6 | 1.2 | 183 | 60 | +123 | 15 of 23 | 15 of 23 | +327 | +80 |
| Opponent | Lizardmen | 2 | 0 | 458 | 4.5 | 1.2 | 102 | 26 | +76 | 3 of 9 | 9 of 9 | +60 | +80 |
| Opponent | Orc & Goblin Tribes | 3 | 11 | 600 | 3.7 | 1.1 | 164 | 57 | +107 | 3 of 11 | 10 of 11 | +265 | +91 |
| Opponent | Skaven | 4 | 224 | 240 | 3.0 | 1.0 | 80 | 62 | +18 | 5 of 12 | 10 of 12 | - | +18 |
| Opponent | Tomb Kings of Khemri | 2 | 120 | 506 | 2.0 | 1.0 | 253 | 0 | +253 | 1 of 4 | 4 of 4 | - | +253 |
| Opponent | Vampire Counts | 6 | 0 | 767 | 5.8 | 1.2 | 131 | 8 | +124 | 19 of 35 | 17 of 35 | +75 | +136 |
| Opponent | Warriors of Chaos | 7 | 9 | 477 | 4.4 | 1.0 | 108 | 45 | +63 | 14 of 31 | 19 of 31 | +0 | +65 |
| Opponent | Wood Elf Realms | 6 | 88 | 231 | 4.2 | 1.1 | 55 | 25 | +30 | 7 of 25 | 19 of 25 | +0 | +31 |
| **Opponent** | all armies | 36 | 98 | 506 | 4.2 | 1.1 | 122 | 35 | +86 | 67 of 150 | 103 of 150 | +139 | +80 |

### Effective charges: cb-h2h-mine-24b8cfb-p4

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 12 | 2 (net +0) | 0 | 5 (net -20) | 2 (net +36) | 1 (net +123) | 0 | 2 | 50% (5 of 10) |
| Mine | Chaos Dwarfs | 15 | 3 (net -113) | 0 | 2 (net -155) | 3 (net +179) | 2 (net +0) | 4 (net +125) | 1 | 14% (2 of 14) |
| Mine | Dwarfen Mountain Holds | 3 | 2 (net +107) | 0 | 0 | 1 (net -233) | 0 | 0 | 0 | 0% (0 of 3) |
| Mine | Empire of Man | 5 | 1 (net +0) | 0 | 2 (net +0) | 1 (net +0) | 0 | 1 (net +177) | 0 | 40% (2 of 5) |
| Mine | Grand Cathay | 13 | 0 | 0 | 4 (net +44) | 4 (net +247) | 3 (net +60) | 2 (net +164) | 0 | 31% (4 of 13) |
| Mine | High Elf Realms | 18 | 2 (net +332) | 0 | 5 (net +47) | 6 (net +52) | 2 (net +98) | 3 (net +20) | 0 | 28% (5 of 18) |
| Mine | Kingdom of Bretonnia | 5 | 1 (net +0) | 1 (net +210) | 1 (net +92) | 1 (net +0) | 0 | 0 | 1 | 25% (1 of 4) |
| Mine | Lizardmen | 6 | 1 (net +15) | 1 (net -405) | 0 | 2 (net +0) | 0 | 1 (net +980) | 1 | 0% (0 of 5) |
| Mine | Ogre Kingdoms | 6 | 0 | 0 | 3 (net -117) | 2 (net +128) | 0 | 1 (net +102) | 0 | 50% (3 of 6) |
| Mine | Skaven | 6 | 1 (net +0) | 0 | 1 (net -41) | 0 | 0 | 4 (net +52) | 0 | 17% (1 of 6) |
| Mine | Tomb Kings of Khemri | 7 | 0 | 0 | 1 (net +0) | 2 (net +95) | 4 (net +99) | 0 | 0 | 14% (1 of 7) |
| Mine | Vampire Counts | 9 | 2 (net +0) | 0 | 3 (net +29) | 1 (net +216) | 0 | 1 (net +0) | 2 | 43% (3 of 7) |
| Mine | Warriors of Chaos | 12 | 1 (net +0) | 0 | 2 (net +14) | 2 (net +46) | 3 (net +75) | 2 (net +0) | 2 | 20% (2 of 10) |
| Opponent | High Elf Realms | 23 | 2 (net +66) | 0 | 5 (net +161) | 5 (net +98) | 1 (net +91) | 6 (net +240) | 4 | 26% (5 of 19) |
| Opponent | Lizardmen | 9 | 1 (net -185) | 1 (net +0) | 1 (net +339) | 3 (net +176) | 0 | 3 (net +0) | 0 | 11% (1 of 9) |
| Opponent | Orc & Goblin Tribes | 11 | 0 | 0 | 0 | 1 (net +265) | 1 (net +83) | 1 (net +83) | 8 | 0% (0 of 3) |
| Opponent | Skaven | 12 | 2 (net -8) | 0 | 2 (net +40) | 1 (net +0) | 0 | 7 (net +21) | 0 | 17% (2 of 12) |
| Opponent | Tomb Kings of Khemri | 4 | 0 | 0 | 0 | 1 (net +482) | 0 | 2 (net +88) | 1 | 0% (0 of 3) |
| Opponent | Vampire Counts | 35 | 7 (net +64) | 0 | 6 (net +17) | 8 (net +233) | 4 (net +250) | 10 (net +91) | 0 | 17% (6 of 35) |
| Opponent | Warriors of Chaos | 31 | 4 (net -36) | 0 | 5 (net +116) | 5 (net +50) | 3 (net +177) | 12 (net +71) | 2 | 17% (5 of 29) |
| Opponent | Wood Elf Realms | 25 | 3 (net +0) | 1 (net +0) | 4 (net -90) | 7 (net +92) | 2 (net +114) | 8 (net +30) | 0 | 16% (4 of 25) |

### Charged fights, damage counted: cb-h2h-mine-24b8cfb-p4

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 16 | 216 | 374 | +35 | 110 | 34 | +76 | +35.2 |
| Mine | 50-54% | 2 | 524 | 282 | -98 | 105 | 202 | -98 | -18.6 |
| Mine | Effective (55-75%) | 29 | 273 | 205 | -6 | 68 | 54 | +14 | +5.1 |
| Mine | 76-89% | 27 | 315 | 206 | +90 | 126 | 34 | +92 | +29.2 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 19 | 202 | 139 | +124 | 140 | 25 | +116 | +57.3 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 15 | 523 | 100 | +74 | 77 | 0 | +77 | +14.7 |
| Mine | No odds | 9 | 288 | 234 | +126 | 142 | 11 | +131 | +45.6 |
| Mine | All fights | 117 | 301 | 208 | +62 | 106 | 34 | +72 | +24.0 |
| Opponent | Long shot (under 50%) | 19 | 246 | 298 | +12 | 110 | 93 | +18 | +7.2 |
| Opponent | 50-54% | 2 | 254 | 202 | +0 | 0 | 0 | +0 | +0.0 |
| Opponent | Effective (55-75%) | 23 | 244 | 195 | +67 | 130 | 67 | +63 | +25.8 |
| Opponent | 76-89% | 31 | 329 | 168 | +146 | 165 | 31 | +134 | +40.7 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 49 | 302 | 212 | +78 | 141 | 47 | +94 | +31.1 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 11 | 390 | 97 | +176 | 185 | 15 | +170 | +43.6 |
| Opponent | No odds | 15 | 287 | 190 | +56 | 145 | 106 | +39 | +13.6 |
| Opponent | All fights | 150 | 296 | 201 | +86 | 142 | 55 | +87 | +29.3 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| cb-h2h-mine-24b8cfb-p4 | move | 422 | 91 (22%) | 72 (17%) | 71 (17%) | 260 (62%) |
| cb-h2h-mine-24b8cfb-p4 | objective | 366 | 57 (16%) | 45 (12%) | 65 (18%) | 244 (67%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0114, L0130, L2527, L2634 |
| Charmed Shield | Opponent | L0434, L0624, L0926, L1034, L1126, L1427, L2227, L2527, L2634, L3234 |
| Clockwork Compass | Mine | L1220 |
| Elixir of Power | Mine | L1126 |
| Elixir of Power | Opponent | L0819, L1719, L1819 |
| Fistful of Laurels | Mine | L1819, L1835 |
| Invocation of Nehek | Mine | L2527 |
| Invocation of Nehek | Opponent | L0624, L1427, L2227, L2527 |
| Opal Amulet | Mine | L1427 |
| Opal Amulet | Opponent | L0114, L0214, L1314 |
| Periapt of Soul Exchange | Mine | L2021, L2123 |
| Periapt of Soul Exchange | Opponent | L0520, L1220, L1621, L2021 |
| Ring of Doom | Mine | L0214, L0230, L1126, L1220, L1523 |
| Ring of Doom | Opponent | L0315, L1331, L2331 |
| Ring of Jet | Mine | L1017, L1034, L1126, L1220 |
| Standard of the Fell Warrior | Mine | L1314, L1331 |
| Standard of the Fell Warrior | Opponent | L0713 |
| Storm Daemon (Renegade 2.0) | Mine | L2123 |
| Storm Daemon (Renegade 2.0) | Opponent | L1621, L2021 |
| Twice-Blessed Armour | Mine | L0713, L0729, L1017, L1034 |
| Witch Hunter's Ward | Mine | L0713, L0729, L0819, L0835 |
| Witch Hunter's Ward | Opponent | L0608 |

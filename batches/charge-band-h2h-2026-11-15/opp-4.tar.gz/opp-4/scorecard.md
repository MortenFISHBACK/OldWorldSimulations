# Doctrine scorecard: cb-h2h-opp-24b8cfb-p4

### Scorecard: cb-h2h-opp-24b8cfb-p4

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0114 | 6 | 1 | Mine | no | 6 | 5 | 2 | 2 | 1 | 0 | 0 | 0 |
| L0114 | 6 | 1 | Opponent | no | 8 | 1 | 3 | 2 | 0 | 0 | 0 | 0 |
| L0130 | 4 | 1 | Mine | yes | 1 | - | 0 | 2 | 0 | 0 | 0 | 65 |
| L0130 | 4 | 1 | Opponent | no | 1 | 1 | 5 | 1 | 0 | 0 | 0 | 0 |
| L0214 | 4 | 1 | Mine | yes | 1 | 3 | 4 | 2 | 1 | 0 | 0 | 170 |
| L0214 | 4 | 1 | Opponent | no | 0 | 2 | 3 | 0 | 0 | 0 | 0 | 0 |
| L0230 | 2 | 1 | Mine | - | - | 1 | 5 | 3 | 0 | 0 | 0 | 30 |
| L0230 | 2 | 1 | Opponent | - | - | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L0315 | 3 | 1 | Mine | yes | 6 | 2 | 3 | 0 | 0 | 0 | 0 | 590 |
| L0315 | 3 | 1 | Opponent | yes | 12 | 2 | 2 | 1 | 0 | 0 | 0 | 60 |
| L0332 | 2 | 1 | Mine | - | - | - | 0 | 1 | 1 | 0 | 0 | 590 |
| L0332 | 2 | 1 | Opponent | - | - | 2 | 4 | 3 | 0 | 0 | 0 | 0 |
| L0417 | 3 | 1 | Mine | yes | 1 | 2 | 5 | 1 | 0 | 0 | 0 | 0 |
| L0417 | 3 | 1 | Opponent | yes | 2 | 3 | 1 | 0 | 0 | 0 | 0 | 0 |
| L0434 | 2 | 1 | Mine | - | - | 2 | 5 | 0 | 0 | 0 | 0 | 0 |
| L0434 | 2 | 1 | Opponent | - | - | 1 | 0 | 1 | 0 | 0 | 0 | 0 |
| L0520 | 4 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 1258 |
| L0520 | 4 | 1 | Opponent | no | 0 | - | 3 | 2 | 1 | 0 | 0 | 210 |
| L0608 | 2 | 1 | Mine | - | - | 3 | 3 | 1 | 1 | 0 | 0 | 615 |
| L0608 | 2 | 1 | Opponent | - | - | - | 0 | 3 | 0 | 0 | 0 | 605 |
| L0624 | 6 | 1 | Mine | no | 0 | 3 | 4 | 0 | 0 | 0 | 0 | 615 |
| L0624 | 6 | 1 | Opponent | no | 5 | 5 | 1 | 1 | 0 | 0 | 0 | 0 |
| L0713 | 5 | 1 | Mine | no | - | 3 | 3 | 0 | 0 | 0 | 0 | 375 |
| L0713 | 5 | 1 | Opponent | yes | - | 2 | 2 | 1 | 0 | 0 | 0 | 140 |
| L0729 | 3 | 1 | Mine | no | 6 | 2 | 2 | 0 | 0 | 0 | 0 | 452 |
| L0729 | 3 | 1 | Opponent | no | 3 | 2 | 4 | 1 | 1 | 0 | 0 | 170 |
| L0819 | 3 | 1 | Mine | no | 0 | 3 | 2 | 1 | 0 | 0 | 0 | 386 |
| L0819 | 3 | 1 | Opponent | yes | 0 | 2 | 0 | 2 | 2 | 0 | 0 | 0 |
| L0835 | 1 | 1 | Mine | no | 0 | 4 | 1 | 0 | 0 | 0 | 0 | 515 |
| L0835 | 1 | 1 | Opponent | no | 0 | 2 | 5 | 2 | 0 | 0 | 0 | 0 |
| L0926 | 2 | 1 | Mine | - | - | 2 | 1 | 0 | 0 | 0 | 0 | 632 |
| L0926 | 2 | 1 | Opponent | - | - | 2 | 4 | 4 | 0 | 0 | 0 | 0 |
| L1017 | 3 | 1 | Mine | no | 6 | 2 | 5 | 0 | 2 | 0 | 0 | 456 |
| L1017 | 3 | 1 | Opponent | yes | 2 | 2 | 4 | 0 | 2 | 0 | 0 | 98 |
| L1034 | 2 | 1 | Mine | - | - | 2 | 2 | 2 | 0 | 0 | 0 | 330 |
| L1034 | 2 | 1 | Opponent | - | - | - | 2 | 4 | 1 | 0 | 0 | 583 |
| L1126 | 4 | 1 | Mine | no | 1 | 2 | 5 | 0 | 0 | 0 | 0 | 330 |
| L1126 | 4 | 1 | Opponent | no | 0 | 2 | 4 | 1 | 1 | 0 | 0 | 0 |
| L1220 | 2 | 1 | Mine | - | - | 2 | 3 | 0 | 1 | 0 | 0 | 330 |
| L1220 | 2 | 1 | Opponent | - | - | - | 4 | 6 | 0 | 0 | 0 | 197 |
| L1314 | 6 | 1 | Mine | no | 1 | 3 | 3 | 0 | 1 | 0 | 0 | 302 |
| L1314 | 6 | 1 | Opponent | no | 1 | 3 | 3 | 2 | 0 | 0 | 0 | 0 |
| L1331 | 5 | 1 | Mine | no | - | - | 0 | 3 | 0 | 0 | 0 | 317 |
| L1331 | 5 | 1 | Opponent | no | - | 4 | 0 | 4 | 2 | 0 | 0 | 170 |
| L1427 | 5 | 1 | Mine | no | - | 3 | 3 | 1 | 1 | 0 | 0 | 0 |
| L1427 | 5 | 1 | Opponent | yes | - | 2 | 5 | 1 | 0 | 0 | 0 | 0 |
| L1523 | 5 | 1 | Mine | yes | - | 2 | 7 | 0 | 0 | 0 | 0 | 0 |
| L1523 | 5 | 1 | Opponent | yes | - | 2 | 3 | 0 | 1 | 0 | 0 | 66 |
| L1621 | 1 | 1 | Mine | no | 0 | 2 | 3 | 1 | 0 | 0 | 0 | 200 |
| L1621 | 1 | 1 | Opponent | no | 0 | 3 | 4 | 3 | 0 | 0 | 0 | 355 |
| L1719 | 3 | 1 | Mine | no | 0 | 2 | 5 | 0 | 2 | 0 | 0 | 135 |
| L1719 | 3 | 1 | Opponent | yes | 2 | 2 | 9 | 0 | 0 | 0 | 0 | 0 |
| L1819 | 1 | 1 | Mine | no | 3 | 3 | 3 | 0 | 1 | 0 | 0 | 0 |
| L1819 | 1 | 1 | Opponent | no | 8 | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L1835 | 5 | 1 | Mine | yes | - | - | 3 | 3 | 1 | 0 | 0 | 0 |
| L1835 | 5 | 1 | Opponent | no | - | 4 | 1 | 5 | 0 | 0 | 0 | 126 |
| L2021 | 5 | 1 | Mine | yes | - | 4 | 2 | 2 | 1 | 0 | 0 | 420 |
| L2021 | 5 | 1 | Opponent | no | - | - | 0 | 5 | 0 | 0 | 0 | 145 |
| L2123 | 5 | 1 | Mine | no | - | - | 2 | 4 | 1 | 0 | 0 | 555 |
| L2123 | 5 | 1 | Opponent | yes | - | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L2227 | 1 | 1 | Mine | no | 0 | 4 | 2 | 1 | 0 | 0 | 0 | 0 |
| L2227 | 1 | 1 | Opponent | yes | 0 | 1 | 7 | 3 | 0 | 0 | 0 | 0 |
| L2331 | 3 | 1 | Mine | no | 1 | 6 | 4 | 0 | 1 | 0 | 0 | 0 |
| L2331 | 3 | 1 | Opponent | yes | 4 | 3 | 3 | 0 | 2 | 0 | 0 | 170 |
| L2527 | 1 | 1 | Mine | no | 0 | 3 | 0 | 1 | 0 | 0 | 0 | 0 |
| L2527 | 1 | 1 | Opponent | no | 1 | 1 | 3 | 3 | 0 | 0 | 0 | 0 |
| L2634 | 6 | 1 | Mine | no | 5 | 2 | 5 | 0 | 2 | 0 | 0 | 0 |
| L2634 | 6 | 1 | Opponent | no | 3 | 2 | 6 | 0 | 0 | 0 | 0 | 0 |
| L2930 | 2 | 1 | Mine | - | - | 3 | 6 | 2 | 1 | 0 | 0 | 0 |
| L2930 | 2 | 1 | Opponent | - | - | 3 | 5 | 1 | 0 | 0 | 0 | 0 |
| L3234 | 6 | 1 | Mine | no | 0 | 2 | 3 | 2 | 0 | 0 | 0 | 340 |
| L3234 | 6 | 1 | Opponent | no | 0 | 2 | 4 | 2 | 1 | 0 | 0 | 0 |
| **Average** | | | Mine | 25% | 1.8 | 2.7 | 2.9 | 1.0 | 0.5 | 0.0 | 0.0 | 278.0 |
| **Average** | | | Opponent | 39% | 2.5 | 2.2 | 3.2 | 1.9 | 0.4 | 0.0 | 0.0 | 86.0 |

### KPIs: cb-h2h-opp-24b8cfb-p4

Rules off - Mine only: CHARGE BAND, JOINT KNOWS CHALLENGE, REFUSING RETIRES, BLOWS WHERE AIMED, SPELLS IN THE FIGHT, CHARGER SLAIN LOST, WIDER SPREAD.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 27% (48 of 175) | 1% (1 of 174) | 14% (49 of 349) |
| Winner chose to follow up after the loser gave ground |  | 97% (74 of 76); on the table 97% | 98% (59 of 60); on the table 98% | 98% (133 of 136); on the table 98% |
| Winner chose to pursue after the loser fell back in good order |  | 85% (11 of 13); on the table 92% | 100% (11 of 11); on the table 100% | 92% (22 of 24); on the table 96% |
| Winner chose to pursue after the loser fled |  | 70% (14 of 20); on the table 80% | 68% (19 of 28); on the table 79% | 69% (33 of 48); on the table 79% |
| Winner chose to follow up or pursue (all three) |  | 91% (99 of 109); on the table 94% | 90% (89 of 99); on the table 93% | 90% (188 of 208); on the table 93% |
| Magic missiles tried each own turn | 50%+ | 31% (83 of 267) | 37% (64 of 172) | 33% (147 of 439) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 43% (83 of 193) | 50% (64 of 127) | 46% (147 of 320) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 50% (18 of 36) | 52% (37 of 71) | 51% (55 of 107) |
| Points that never fought | lower | 33% (22483 of 67942) | 32% (23017 of 71984) | 33% (45500 of 139926) |
|   infantry points that never fought | lower | 43% (6641 of 15347) | 53% (7318 of 13804) | 48% (13959 of 29151) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 58% (157 of 270) | 53% (149 of 280) | 56% (306 of 550) |
| Bound items with a magic missile used (at least once a game) |  | 95% (21 of 22); 1.3 uses a game | 89% (8 of 9); 0.6 uses a game | 94% (29 of 31); 1.0 uses a game |
| Bound items with another spell used |  | 50% (8 of 16); 0.5 uses a game | 30% (6 of 20); 0.2 uses a game | 39% (14 of 36); 0.4 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 58% (11 of 19); 0.3 uses a game | 87% (13 of 15); 0.4 uses a game | 71% (24 of 34); 0.3 uses a game |
|   their share of the points of units over 100 pts | lower | 51% (29386 of 57750) | 47% (29556 of 63347) | 49% (58942 of 121097) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.8 (34%) | 0.8 (26%) | 2.5 (31%) |
| MARCHED: its unit marched | 1.1 (22%) | 0.5 (17%) | 1.6 (20%) |
| CHARGED: its unit charged | 0.1 (3%) | 0.2 (7%) | 0.4 (4%) |
| IN COMBAT: engaged in combat | 1.4 (28%) | 0.7 (23%) | 2.1 (26%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.2 (6%) | 0.2 (2%) |
| FLEEING: fleeing | 0.1 (2%) | 0.0 (0%) | 0.1 (1%) |
| GONE: slain | 0.5 (10%) | 0.6 (19%) | 1.1 (13%) |
| OFF THE TABLE: off the table or not arrived | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (1%) | 0.0 (1%) | 0.1 (1%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.5 | 1.5 | 2.0 | 4.1 | 0.3 | 2.1 |
| not cast | 2.7 | 2.4 | 2.8 | 8.1 | 1.7 | 20.8 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.8 (9%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.1 (48%) | 0.2 (9%) | 2.5 (31%) | 0.5 (30%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.6 (20%) | 0.3 (20%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.4 (4%) | 0.1 (5%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.1 (3%) | 0.3 (14%) | 0.6 (20%) | 2.1 (26%) | 0.4 (25%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.1 (5%) | 0.1 (5%) | 0.2 (8%) | 0.2 (2%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.1 (2%) | 0.0 (0%) | 0.0 (1%) | 0.1 (1%) | 0.0 (0%) | 0.4 (2%) |
| GONE: slain | 0.6 (21%) | 0.4 (15%) | 0.4 (14%) | 1.1 (13%) | 0.0 (0%) | 2.1 (10%) |
| OFF THE TABLE: off the table or not arrived | 0.1 (4%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.4 (2%) |
| STUPIDITY: Stupidity | 0.0 (1%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (2%) | 0.3 (12%) | 0.1 (2%) | 0.1 (1%) | 0.4 (21%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.7 (62%) | 0.1 (6%) | 1.3 (47%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 16.0 (77%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.5 a game | 0.7 a game | 1.1 a game |
| stood (cast and not dispelled) | 65% (31 of 48) | 57% (8 of 14) | 63% (39 of 62) |
| the unit moved after it | 68% (21 of 31) | 50% (4 of 8) | 64% (25 of 39) |
| it charged on its next turn | 6% (2 of 31) | 12% (1 of 8) | 8% (3 of 39) |
| the enemy charged it first | 19% (6 of 31) | 0% (0 of 8) | 15% (6 of 39) |
| it fought by the end of its next turn | 10% (3 of 31) | 12% (1 of 8) | 10% (4 of 39) |
| it moved out of a charge the enemy had planned (not charged first) | 16% (5 of 31) | 12% (1 of 8) | 15% (6 of 39) |
| none of these (no charge, no fight, no charge escaped) | 55% (17 of 31) | 75% (6 of 8) | 59% (23 of 39) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 63% (553 of 878) | 51% (266 of 518) | 59% (819 of 1396) |
|   cavalry | 53% (42 of 79) | 70% (74 of 106) | 63% (116 of 185) |
|   character | 40% (40 of 101) | 14% (17 of 125) | 25% (57 of 226) |
|   chariot | 49% (50 of 102) | 50% (9 of 18) | 49% (59 of 120) |
|   infantry | 61% (162 of 267) | 61% (139 of 227) | 61% (301 of 494) |
|   monster | 64% (28 of 44) | 38% (9 of 24) | 54% (37 of 68) |
|   war machine | 81% (231 of 285) | 100% (18 of 18) | 82% (249 of 303) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.5 (28%) | 1.6 (23%) | 4.1 (26%) |
| CHARGED: it charged | 1.2 (14%) | 1.9 (27%) | 3.1 (19%) |
| FLEEING: it fled or was fleeing | 0.1 (1%) | 0.1 (2%) | 0.2 (1%) |
| IN COMBAT: it fought this turn or the last | 0.8 (8%) | 0.4 (6%) | 1.1 (7%) |
| MOVED: a war machine that moved | 0.2 (2%) | 0.0 (0%) | 0.2 (1%) |
| NO TARGET IN RANGE | 1.6 (17%) | 1.1 (15%) | 2.6 (16%) |
| ONLY IN COMBAT: the only targets were in combat | 0.6 (7%) | 0.5 (8%) | 1.1 (7%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.6 (18%) | 1.3 (19%) | 2.9 (18%) |
| SHELTERED: the target was sheltered | 0.3 (3%) | 0.0 (0%) | 0.3 (2%) |
| OTHER BAR | 0.3 (3%) | 0.0 (0%) | 0.3 (2%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 5.4 | 1.6 | 79% | 5.6 pts | 30 pts |
| character | 1.8 | 0.7 | 75% | 7.4 pts | 13 pts |
| chariot | 1.7 | 1.3 | 67% | 19.8 pts | 34 pts |
| infantry | 12.0 | 5.0 | 71% | 11.0 pts | 132 pts |
| monster | 1.1 | 0.2 | 85% | 2.9 pts | 3 pts |
| war machine | 6.9 | 6.1 | 63% | 29.8 pts | 206 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.6 | 7.1 | 5.8 |
| Charges that made contact a game | 3.4 | 4.7 | 4.1 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.41 declared, 1.18 contact (17 units) | 0.67 declared, 0.53 contact (15 units) | 1.06 declared, 0.88 contact (32 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.89 declared, 0.56 contact (9 units) | 1.08 declared, 1.00 contact (13 units) | 1.00 declared, 0.82 contact (22 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.53 declared, 0.40 contact (249 units) | 0.78 declared, 0.51 contact (293 units) | 0.67 declared, 0.46 contact (542 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 62% (50 of 81) | 44% (7 of 16) | 33% (2 of 6) | 57% (59 of 103) |
| Character in a unit | 79% (26 of 33) | 71% (10 of 14) | 100% (1 of 1) | 77% (37 of 48) |
| Character on its own | 72% (23 of 32) | 36% (10 of 28) | 30% (23 of 77) | 41% (56 of 137) |
| Chariot | 80% (12 of 15) | 67% (8 of 12) | - | 74% (20 of 27) |
| Infantry | 54% (45 of 83) | 28% (7 of 25) | 33% (2 of 6) | 47% (54 of 114) |
| Monster | 71% (24 of 34) | 64% (9 of 14) | - | 69% (33 of 48) |
| Monstrous | 64% (9 of 14) | 50% (7 of 14) | - | 57% (16 of 28) |
| War Machines | 70% (30 of 43) | 50% (1 of 2) | - | 69% (31 of 45) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 92% (11 of 12); on the table 92% | 36% (37 of 102) | 23% | 50% (11 of 22) | 100% (6 of 6); 3.8 uses a game | 100% (2 of 2); 1.2 uses a game | 67% (4 of 6); 1.0 uses a game |
| Chaos Dwarfs | 4 | 100% (7 of 7); on the table 100% | 42% (10 of 24) | 28% | 53% (17 of 32) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |
| Dwarfen Mountain Holds | 3 | 100% (8 of 8); on the table 100% | - | 63% | 67% (18 of 27) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 6 | 78% (14 of 18); on the table 78% | 50% (9 of 18) | 42% | 61% (38 of 62) | 0.0 uses a game | 50% (1 of 2); 0.5 uses a game | 80% (4 of 5); 0.7 uses a game |
| Grand Cathay | 4 | 92% (12 of 13); on the table 92% | 27% (23 of 84) | 36% | 43% (16 of 37) | 100% (9 of 9); 4.8 uses a game | 50% (1 of 2); 0.5 uses a game | 50% (2 of 4); 0.5 uses a game |
| High Elf Realms | 9 | 83% (24 of 29); on the table 90% | 14% (5 of 35) | 33% | 51% (36 of 70) | 100% (7 of 7); 2.0 uses a game | 33% (10 of 30); 2.0 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | 67% (2 of 3); on the table 67% | - | 39% | 17% (1 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Lizardmen | 3 | 75% (3 of 4); on the table 100% | 67% (4 of 6) | 18% | 62% (13 of 21) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 2 | 78% (7 of 9); on the table 89% | 17% (1 of 6) | 37% | 93% (13 of 14) | 50% (1 of 2); 0.5 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 3 | 100% (13 of 13); on the table 100% | 36% (15 of 42) | 32% | 25% (6 of 24) | 0.0 uses a game | 0.0 uses a game | 67% (2 of 3); 0.7 uses a game |
| Skaven | 6 | 89% (8 of 9); on the table 100% | 33% (14 of 42) | 39% | 71% (32 of 45) | 100% (3 of 3); 1.5 uses a game | 0.0 uses a game | 83% (5 of 6); 1.0 uses a game |
| Tomb Kings of Khemri | 4 | 92% (11 of 12); on the table 100% | 17% (1 of 6) | 16% | 60% (12 of 20) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 8 | 97% (31 of 32); on the table 97% | 34% (19 of 56) | 23% | 45% (19 of 42) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 9 | 93% (25 of 27); on the table 93% | 25% (3 of 12) | 30% | 57% (41 of 72) | 100% (2 of 2); 0.4 uses a game | 0.0 uses a game | 100% (3 of 3); 0.3 uses a game |
| Wood Elf Realms | 6 | 100% (12 of 12); on the table 100% | 100% (6 of 6) | 38% | 59% (33 of 56) | 50% (1 of 2); 0.7 uses a game | 0.0 uses a game | 75% (3 of 4); 0.5 uses a game |

Flank and rear charges a unit could have turned to face (cb-h2h-opp-24b8cfb-p4, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 49% (50) | 54% (41) | 51% (91) |
| ...free all their last turn and able to turn (per game) | 0.64 | 0.64 | 1.28 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.31 | 0.31 | 0.61 |
| ...with the charger already in that arc before they moved (per game) | 0.53 | 0.39 | 0.92 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 1.64 | 1.22 | 2.86 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.81 | 0.64 | 1.44 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 4.89 | 5.56 | 10.44 |

### Quality by phase: cb-h2h-opp-24b8cfb-p4

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.1 | 3.6 |
| Strategy | Charge objectives carried out (made contact) | 51% (83 of 162) | 37% (82 of 224) |
| Strategy | Shoot objectives carried out (shot that target) | 45% (156 of 346) | 40% (57 of 143) |
| Strategy | Close-in objectives charged next turn | 12% (18 of 149) | 14% (29 of 202) |
| Strategy | Support requests answered (helper made contact too) | 42% (5 of 12) | 41% (15 of 37) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (5 of 5) | 100% (1 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | 60% (9 of 15) | 67% (4 of 6) |
| Strategy | Joined characters whose unit fought | 62% (23 of 37) | 39% (13 of 33) |
| Strategy | Lone characters that fought | 78% (67 of 86) | 82% (68 of 83) |
| Movement | Charges halted short of contact | 0.1 | 0.2 |
| Movement | Idle units | 1.0 | 1.9 |
| Movement | Points that never moved of their own | 278.0 | 86.0 |
| Movement | Fights charged into per game | 3.3 | 3.8 |
| Movement | Charges with odds: long shots (under 50%) | 10 of 111, net +48 | 31 of 120, net +27 |
| Movement | Charges with odds: sweet spot (55-75%) | 23 of 111, net -95 | 20 of 120, net +52 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 13 of 111, net +125 | 8 of 120, net +148 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 35 of 111, net +47 | 34 of 120, net +70 |
| Shooting | Shots by shooting units (incl. breath weapons) | 10.0 | 8.2 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 45% (163 of 360) | 47% (138 of 296) |
| Shooting | Points destroyed by shooting units | 71.8 | 32.3 |
| Shooting | War machine shots | 6.4 | 0.5 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 52% (121 of 231) | 6% (1 of 18) |
| Shooting | Points destroyed by war machines | 105.6 | 11.4 |
| Magic | Magic missiles cast | 1.4 | 1.2 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 34% (17 of 50) | 12% (5 of 43) |
| Magic | Wounds caused by magic missiles | 2.5 | 1.6 |
| Magic | Wounds caused by other spells | 1.4 | 1.6 |
| Magic | Points destroyed by magic (all spells) | 76.8 | 46.2 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.2 / 0.4 / 0.6 / 0.2 | 1.9 / 0.4 / 0.8 / 0.1 |
| Combat | Points destroyed in combat | 346.4 | 488.0 |
| Combat | Points run down | 67.1 | 99.3 |
| Combat | Net points per charged fight, damage counted | +27 | +71 |
| Combat | Net per 100 charger points, damage counted | +10.4 | +22.3 |
| Combat | First round won (charged fights) | 71% | 69% |
| Combat | Net points per charged fight | +24 | +71 |
| Combat | Net points per supported fight / lone fight | -6 / +27 | +98 / +66 |
| Combat | Charged fights on a top-3 enemy unit | 42 of 119 | 68 of 138 |
| Game | Points lost | 818.3 | 732.1 |
| Game | VP from objectives | 517.2 | 505.3 |
| Game | Lone holders (player turns) | 1.8 | 2.5 |

- Mine won / drew / lost: 11 / 13 / 12 of 36 ended games (of 36); mean margin (Mine - Opponent) -103 VP
- The side that went first won 14 of 23 games with a winner
- Points traded per game (both sides' losses): 1550
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: cb-h2h-opp-24b8cfb-p4

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 0.8 | +0.0 | 0.0 | 0.0 |
| ALREADY CARRIED | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARRIVAL HUNT | - | - | - | - | 0.0 | +0.4 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.4 | +0.0 | 0.0 | 22.6 | 0.3 | +0.0 | 0.0 | 3.5 |
| BACKUP TARGETS | 1.0 | +6.2 | 0.0 | 31.2 | 1.2 | +10.4 | 0.0 | 39.9 |
| BEST FACING | 0.7 | +46.9 | 0.0 | 47.7 | 0.5 | +19.8 | 0.0 | 33.7 |
| BEST FIRST | 3.5 | +148.0 | 132.4 | 85.8 | 3.6 | +134.2 | 138.1 | 32.9 |
| BEST OVERALL | 0.6 | +43.4 | 0.0 | 23.1 | 0.7 | +43.1 | 0.0 | 39.8 |
| BEST PREY | 0.7 | +52.5 | 10.3 | 12.1 | 0.9 | +33.2 | 14.4 | 32.9 |
| BEST PRIZE | - | - | - | - | 0.0 | +1.4 | 3.1 | 0.0 |
| BIG CHARACTER SAFETY | 0.2 | +0.4 | 0.0 | 27.3 | 0.3 | -0.3 | 0.0 | 16.6 |
| BLOCKED CHARGE SKIPPED | 0.1 | +0.0 | 4.7 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| BLOCKED WHEEL | 0.4 | -1.1 | 0.0 | 0.0 | 0.4 | +19.4 | 0.0 | 0.0 |
| BLOWS WHERE AIMED | - | - | - | - | 0.4 | -59.2 | 25.8 | 0.0 |
| BOMBING RUN | 0.0 | +1.0 | 0.0 | 0.0 | - | - | - | - |
| BOUND ASSAILMENT | 0.1 | +0.0 | 0.0 | 7.0 | 0.1 | +0.0 | 0.0 | 11.4 |
| CANNON PLAN MISSED | 1.0 | +0.0 | 133.4 | 15.4 | 0.1 | +0.0 | 9.0 | 3.5 |
| CANNON PLANNED TARGET | 4.7 | +163.0 | 426.2 | 74.4 | 0.5 | +26.5 | 31.9 | 16.2 |
| CANNON SIGHT KEPT | 1.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT COUNTER | 0.1 | +0.0 | 9.7 | 15.0 | 0.0 | -3.6 | 0.0 | 0.0 |
| CARRIES OUT SET-UP | 0.1 | +0.0 | 3.2 | 5.1 | 0.1 | -1.9 | 14.9 | 0.0 |
| CAST JOB | 0.5 | +29.8 | 74.2 | 7.1 | 0.4 | +2.8 | 15.9 | 18.0 |
| CASTER AWAY FROM SCREEN | 0.3 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.3 | +34.5 | 36.3 | 0.0 | 0.1 | +2.5 | 6.5 | 0.0 |
| CASTS AFTER FRIENDS | 0.9 | +0.0 | 0.0 | 13.9 | 0.3 | +0.0 | 0.0 | 20.2 |
| CASTS FROM BEHIND | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CHAFF PASSED | 0.2 | -0.9 | 12.1 | 8.1 | 0.1 | -0.1 | 8.2 | 0.0 |
| CHARGE BAND | - | - | - | - | 0.0 | +0.0 | 0.0 | 13.9 |
| CHARGE NOW FIRST | 3.1 | +0.0 | 266.2 | 120.1 | 3.7 | +0.0 | 336.1 | 91.9 |
| CHARGE NOW WEIGHED | 0.4 | -47.2 | 3.3 | 33.9 | 0.5 | -23.2 | 20.3 | 13.9 |
| CHARGER SLAIN LOST | - | - | - | - | 0.9 | -24.5 | 64.8 | 45.1 |
| CHARIOT NO STATIC JOB | 0.1 | +0.0 | 0.0 | 2.4 | - | - | - | - |
| CHARIOT WIZARD CAREFUL | 0.1 | -0.4 | 4.7 | 0.0 | 0.1 | -0.5 | 0.0 | 15.0 |
| CHEAP HELPER | 0.1 | +0.0 | 4.4 | 0.0 | 0.1 | +0.0 | 18.8 | 6.4 |
| COMBAT PIVOT | 0.4 | +0.0 | 13.9 | 61.6 | 0.6 | +0.0 | 80.9 | 40.0 |
| CONVEYANCE SEARCH | 1.0 | +123.0 | 9.0 | 0.0 | 0.3 | +30.7 | 11.1 | 22.2 |
| COUNTER-CHARGE COVER | 7.8 | +611.0 | 0.0 | 232.8 | 7.9 | +736.4 | 0.0 | 175.4 |
| DEFENSIVE ARMY | 0.2 | +0.0 | 24.6 | 2.5 | 0.0 | +0.0 | 0.0 | 0.0 |
| DEFENSIVE FLOOR | 0.1 | +1.2 | 5.2 | 3.6 | 0.1 | +7.6 | 3.1 | 0.0 |
| EDGE GIVE GROUND | 0.1 | +1.4 | 7.7 | 2.2 | 0.2 | +7.8 | 30.9 | 1.2 |
| ELIXIR WORTH | - | - | - | - | 0.1 | +1.2 | 0.0 | 0.0 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 1.6 | +127.6 | 0.0 | 94.9 | 1.2 | +86.6 | 0.0 | 55.5 |
| FALLBACK BY WORTH | 5.3 | +87.2 | 0.0 | 82.3 | 6.0 | +44.2 | 0.0 | 64.2 |
| FIGHT LIFT | 0.1 | +1.7 | 21.9 | 0.0 | 0.0 | +0.2 | 0.0 | 0.0 |
| FIRE AND FLEE | - | - | - | - | 0.0 | +0.3 | 0.0 | 3.0 |
| FLANK NOT WEIGHED | 4.7 | +0.0 | 0.0 | 204.0 | 5.4 | +0.0 | 0.0 | 117.8 |
| FOLLOW UP WEIGHED | 1.3 | +218.6 | 0.0 | 107.2 | 1.1 | +153.6 | 0.0 | 26.0 |
| FRIENDS SHOTS CHECKED | 0.2 | +13.0 | 0.0 | 23.1 | 0.1 | +4.1 | 0.0 | 12.3 |
| GIVES UP | 0.0 | -0.3 | 0.0 | 0.0 | 0.1 | -1.2 | 16.9 | 0.0 |
| GIVES UP ITS SCREEN | - | - | - | - | 0.0 | -0.2 | 0.0 | 3.4 |
| GROUND FLIERS | - | - | - | - | 0.1 | +1.9 | 0.0 | 3.2 |
| HELPER ALREADY ASKED | 0.0 | +0.0 | 0.0 | 4.6 | 0.0 | +0.0 | 4.6 | 0.0 |
| HELPER UNSEEN | 0.3 | +0.0 | 34.5 | 19.6 | 0.6 | +0.0 | 38.8 | 1.9 |
| HILL BY ITS CHANCE | 0.4 | -42.5 | 0.0 | 12.8 | 0.5 | -50.0 | 0.0 | 16.7 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| HUNT ADVANCE | - | - | - | - | 0.1 | +2.9 | 0.0 | 9.5 |
| HUNT DROPPED | - | - | - | - | 0.0 | +0.0 | 4.6 | 0.0 |
| HUNT IN PAIRS | 0.2 | +8.7 | 0.0 | 4.9 | 0.6 | +39.8 | 0.0 | 12.8 |
| HUNT RESULT | - | - | - | - | 0.2 | +8.1 | 8.1 | 7.4 |
| HUNT THE GUNS | - | - | - | - | 0.2 | +48.0 | 9.2 | 11.8 |
| INVITES THE FIGHT | 1.8 | +31.3 | 104.9 | 35.6 | 1.1 | +20.5 | 34.2 | 28.7 |
| JOINT CHARGE PLAN | 0.1 | +1.9 | 0.0 | 0.0 | 0.1 | +3.7 | 10.1 | 9.1 |
| JOINT KNOWS CHALLENGE | - | - | - | - | 0.2 | -5.2 | 15.5 | 5.0 |
| KEEP FALLS | 0.1 | +3.7 | 0.0 | 6.6 | 0.1 | +0.5 | 0.0 | 3.2 |
| KEEPS ITS PREY | 0.0 | +0.1 | 0.0 | 0.0 | - | - | - | - |
| KEEPS ITS TARGET | 1.8 | +53.3 | 117.8 | 73.0 | 2.0 | +59.2 | 178.5 | 21.6 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KILLS COUNT | 1.9 | +47.8 | 118.3 | 57.9 | 2.2 | +113.6 | 180.9 | 65.2 |
| KILLS COUNT NEXT TURN | 5.4 | +190.4 | 154.0 | 150.4 | 6.2 | +195.1 | 242.5 | 178.8 |
| LONE CHARACTER SAFE SPOT | 0.4 | +11.1 | 14.9 | 3.8 | 0.1 | +11.7 | 2.0 | 3.2 |
| LONE WIZARD HOLDS BACK | 0.0 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 8.8 | 10.8 |
| LONE WIZARD KEPT IN | 0.6 | +26.9 | 0.0 | 0.0 | 0.2 | +20.3 | 0.0 | 0.0 |
| LONG SHOT | 0.5 | +0.8 | 26.6 | 5.4 | 0.6 | +1.5 | 57.3 | 5.6 |
| LOST CHARGE | 3.0 | -42.0 | 102.2 | 130.7 | 2.0 | -27.6 | 77.1 | 29.0 |
| LURE BY WHAT IT DRAWS | 0.1 | -7.1 | 0.0 | 0.0 | 0.1 | -4.5 | 0.0 | 6.2 |
| MAKE SURE TOGETHER | 0.6 | +30.6 | 4.7 | 27.1 | 0.6 | +60.0 | 30.3 | 15.9 |
| MANOEUVRE | 0.2 | +5.1 | 0.0 | 3.2 | 0.2 | +8.5 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.2 | +1.7 | 0.0 | 0.0 | 0.1 | +0.8 | 0.0 | 0.0 |
| MARCH CHECK | 0.5 | +25.1 | 0.0 | 7.1 | 0.3 | +4.1 | 0.0 | 19.8 |
| MARCH ODDS | 0.2 | +15.9 | 11.3 | 4.6 | 0.4 | +29.3 | 7.9 | 0.0 |
| MARCH OVER CASTS | 0.6 | +53.0 | 0.0 | 34.1 | 0.3 | +22.3 | 0.0 | 5.4 |
| MAX FOR POSITIONING | 4.4 | +139.9 | 0.0 | 116.8 | 4.5 | +176.7 | 0.0 | 121.9 |
| MISSILES IN THE MOVE | 3.5 | +150.8 | 0.0 | 87.9 | 2.2 | +33.8 | 0.0 | 63.5 |
| MISSILES NEXT TURN | 4.6 | +101.1 | 0.0 | 120.3 | 2.9 | +27.3 | 0.0 | 74.6 |
| MODEL FACING | 0.1 | +14.1 | 0.0 | 3.3 | - | - | - | - |
| MONSTER WIZARD ROAMS | 0.3 | +0.0 | 12.3 | 0.0 | 0.2 | +0.0 | 4.8 | 0.0 |
| MOVE AND CAST | 0.3 | +6.0 | 0.0 | 0.0 | 0.2 | +8.3 | 0.0 | 37.4 |
| MOVE SPELL IN RANGE | 0.3 | +7.1 | 0.0 | 0.0 | 0.1 | +3.6 | 0.0 | 0.0 |
| MOVE SPELL NOT WORTH | 0.0 | -0.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.5 | -27.6 | 20.0 | 0.0 | 0.2 | -5.9 | 0.0 | 0.0 |
| MOVE SPELL SPOT | 0.6 | +0.0 | 0.0 | 38.3 | 0.1 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE | 3.3 | +175.5 | 112.9 | 78.2 | 4.2 | +276.2 | 127.3 | 117.8 |
| MOVES UNITS SPELL | 0.1 | +3.3 | 0.0 | 0.0 | 0.1 | +0.6 | 0.0 | 0.0 |
| NEEDED THERE | 0.1 | +13.1 | 8.4 | 4.6 | 0.0 | +1.9 | 0.0 | 0.0 |
| NO RALLY LEFT | 0.1 | +1.1 | 0.0 | 0.0 | 0.0 | +7.4 | 0.0 | 0.0 |
| NOT NEEDED | 0.3 | -14.0 | 27.6 | 1.4 | 0.4 | -18.0 | 48.0 | 6.3 |
| NOT TURNED | 4.9 | +79.6 | 0.0 | 165.6 | 5.6 | +88.9 | 0.0 | 107.1 |
| NOT WORTH A CAST | 0.7 | -0.5 | 0.0 | 0.0 | 0.2 | -0.1 | 0.0 | 0.0 |
| OFF BEST | 15.0 | -682.9 | 6.4 | 335.4 | 13.4 | -706.2 | 22.8 | 274.7 |
| OPENS A LANE | 0.2 | +0.3 | 22.0 | 0.0 | 0.1 | +0.4 | 0.0 | 0.0 |
| OPENS UP | 0.3 | +23.1 | 26.3 | 0.0 | 0.4 | +29.1 | 30.4 | 27.4 |
| OVERRUNS AWAY | 0.8 | +31.1 | 42.8 | 20.6 | 0.7 | +11.5 | 82.7 | 0.0 |
| PATHS CROSS | 2.3 | +159.4 | 0.0 | 52.0 | 2.9 | +202.3 | 0.0 | 73.5 |
| PERIAPT WORTH | 0.1 | +3.6 | 0.0 | 0.0 | 0.1 | +6.5 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.1 | -1.3 | 0.0 | 0.0 | 0.1 | -0.9 | 0.0 | 16.5 |
| PLAN RESULT | 37.9 | +1485.1 | 1624.9 | 1144.5 | 38.1 | +1222.8 | 1497.6 | 1002.7 |
| PURSUES BIG PREY | 0.1 | -8.2 | 0.0 | 0.0 | 0.1 | -11.0 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE | - | - | - | - | 0.1 | +11.5 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE NEXT TURN | 0.1 | +5.3 | 0.0 | 0.0 | 0.1 | +13.9 | 0.0 | 3.0 |
| RANDOM MOVE BY FIGURES | 1.0 | +5.4 | 0.0 | 22.2 | 2.0 | +27.3 | 0.0 | 69.3 |
| RANDOM MOVER NO PROMISE | 0.4 | -22.3 | 5.9 | 4.7 | 0.2 | -6.9 | 8.2 | 4.0 |
| REDIRECT BY WHAT IT STOPS | 0.2 | -5.9 | 0.0 | 8.5 | 0.7 | -15.8 | 0.0 | 9.9 |
| REDIRECT COUNTER | 1.9 | +108.9 | 0.0 | 39.5 | 3.3 | +252.8 | 0.0 | 53.0 |
| REDIRECT WEIGHED | 0.2 | +3.2 | 4.9 | 3.4 | 0.3 | +5.9 | 7.2 | 0.0 |
| REFUSING RETIRES | - | - | - | - | 0.2 | +0.0 | 0.0 | 12.3 |
| RESERVE FALL BACK | 0.6 | +22.2 | 0.0 | 15.2 | 0.5 | +19.8 | 0.0 | 15.3 |
| RESTRAINS TO SHOOT | 0.1 | +5.6 | 0.0 | 5.1 | 0.1 | +7.7 | 0.0 | 5.9 |
| RISK BY ARC | 3.2 | +90.3 | 288.1 | 106.2 | 3.3 | +70.4 | 280.0 | 97.5 |
| SAFER THAN THE JOB | 0.8 | +63.1 | 0.0 | 12.9 | 0.6 | +32.8 | 0.0 | 25.5 |
| SCOUT SPOT | 0.4 | +0.5 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 3.7 |
| SCOUT WAITS | 0.5 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 3.7 |
| SCREEN BY WHAT IT SAVES | 0.1 | -2.6 | 0.0 | 0.0 | 0.3 | -17.6 | 0.0 | 4.3 |
| SEARCH SPOT | 2.7 | +125.6 | 0.0 | 39.9 | 2.7 | +127.2 | 0.0 | 18.9 |
| SELF MOVE SPELL | 0.2 | +38.6 | 0.0 | 0.0 | 0.5 | +18.6 | 0.0 | 9.1 |
| SET UP TOGETHER | 0.7 | +44.1 | 4.7 | 27.1 | 1.1 | +90.0 | 44.6 | 27.4 |
| SET-UP ANY TARGET | 0.7 | +94.6 | 9.0 | 0.0 | 0.1 | +29.4 | 0.0 | 11.1 |
| SET-UP MISSED | 0.1 | +12.9 | 0.0 | 0.0 | 0.1 | +16.3 | 0.0 | 0.0 |
| SHOOTER COUNTED ONCE | 0.0 | -0.1 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | 0.3 | +0.8 | 0.0 | 0.0 | 0.2 | +0.3 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 0.6 | +16.7 | 16.1 | 12.4 | 0.7 | +14.7 | 13.6 | 24.6 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 3.8 |
| SHOT REPLANNED | 0.6 | +0.0 | 127.2 | 7.2 | 0.3 | +0.0 | 27.4 | 6.6 |
| SHOTS IN THE MOVE | 14.0 | +564.6 | 0.0 | 290.8 | 6.6 | +177.9 | 0.0 | 128.3 |
| SPELL CATCH ODDS | 0.1 | -1.5 | 0.0 | 0.0 | 0.0 | -0.3 | 0.0 | 0.0 |
| SPELL SETS UP CHARGE | 0.8 | +101.7 | 9.0 | 0.0 | 0.2 | +42.3 | 0.0 | 11.1 |
| SPELL WORTH | 1.4 | +29.1 | 104.6 | 87.7 | 2.4 | +45.3 | 52.2 | 52.2 |
| SPELLS IN THE FIGHT | - | - | - | - | 1.0 | -15.4 | 60.4 | 44.4 |
| STABLE ROLE | 10.4 | +0.0 | 362.1 | 255.5 | 10.1 | +0.0 | 386.5 | 149.8 |
| STANDS TO CAST | 0.0 | +1.4 | 0.0 | 0.0 | - | - | - | - |
| STAY WEIGHED | 0.2 | +15.4 | 0.0 | 0.0 | - | - | - | - |
| STOPS | - | - | - | - | 0.1 | +2.9 | 9.2 | 2.4 |
| STOPS SHORT OF THE FLANK | 0.4 | +19.3 | 0.0 | 17.4 | 0.5 | +12.2 | 0.0 | 11.9 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 4.7 | 0.4 | +0.0 | 0.0 | 15.7 |
| SUPPORT NARROWED | 6.5 | -45.7 | 377.4 | 155.9 | 8.0 | -65.8 | 367.8 | 77.9 |
| SUPPORTS | 4.0 | +62.6 | 209.1 | 65.5 | 5.2 | +67.8 | 147.7 | 32.0 |
| SURE CHARGE BEATS ADVANCE | 0.1 | -5.2 | 17.6 | 0.0 | 0.1 | -1.1 | 5.5 | 7.9 |
| SURE REACH TOGETHER | 0.5 | -1.4 | 0.0 | 20.0 | 0.6 | +2.6 | 0.0 | 11.2 |
| THROUGH LINE OF FIRE | 0.3 | +6.9 | 0.0 | 0.0 | 0.2 | +24.7 | 0.0 | 3.2 |
| TURN WORTH | 0.6 | -48.8 | 43.9 | 8.0 | 0.4 | -31.2 | 33.0 | 31.2 |
| TWO OR MORE ARRIVE | 0.3 | +0.9 | 4.7 | 0.0 | 0.4 | +2.3 | 10.1 | 4.5 |
| WAIT AFTER COSTS | 6.8 | -282.8 | 253.7 | 138.2 | 7.2 | -339.9 | 242.5 | 181.5 |
| WALKS TO THE FIGHT | 1.5 | +29.5 | 34.3 | 19.4 | 1.0 | +20.5 | 32.6 | 11.9 |
| WAR ENGINE CHARGES | 0.1 | +18.9 | 13.4 | 13.8 | - | - | - | - |
| WAR ENGINE JOBS | 0.7 | +0.0 | 52.6 | 13.8 | 0.1 | +0.0 | 0.0 | 4.0 |
| WEARS DOWN | 1.5 | +74.2 | 154.7 | 69.5 | 1.1 | +38.5 | 63.9 | 20.7 |
| WHO HITS BACK | 0.3 | +32.1 | 0.0 | 16.8 | 0.2 | +7.9 | 0.0 | 14.8 |
| WHOLE FIGHT | 0.5 | +16.4 | 75.1 | 22.5 | 0.6 | +22.0 | 100.7 | 13.6 |
| WHOLE FIGHT GAIN | 0.3 | +39.1 | 22.6 | 4.6 | 0.8 | +53.2 | 63.6 | 26.5 |
| WIDER SPREAD | - | - | - | - | 4.1 | -5.6 | 397.6 | 97.4 |

### Rule changes: cb-h2h-opp-24b8cfb-p4

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 1022 | 1022 | 1022 | 28.39 | -50004 | -48.9 |
| BEST FIRST | 256 | 256 | 256 | 7.11 | +10159 | +39.7 |
| SEARCH SPOT | 194 | 194 | 191 | 5.31 | +9102 | +47.7 |
| PATHS CROSS | 187 | 187 | 187 | 5.19 | +13023 | +69.6 |
| COUNTER-CHARGE COVER | 566 | 326 | 168 | 4.67 | +11015 | +65.6 |
| MOVE TO CHARGE | 268 | 268 | 134 | 3.72 | +6013 | +44.9 |
| SUPPORTS | 331 | 331 | 119 | 3.31 | +1639 | +13.8 |
| KILLS COUNT NEXT TURN | 418 | 418 | 109 | 3.03 | +3095 | +28.4 |
| FACES THE THREAT | 103 | 103 | 103 | 2.86 | +7709 | +74.8 |
| FOLLOW UP WEIGHED | 85 | 85 | 85 | 2.36 | +13399 | +157.6 |
| FALLBACK BY WORTH | 409 | 409 | 77 | 2.14 | +4728 | +61.4 |
| SHOTS IN THE MOVE | 742 | 487 | 61 | 1.69 | +2326 | +38.1 |
| ARTILLERY RE-ROLL WEIGHED | 60 | 60 | 60 | 1.67 | +0 | +0.0 |
| WAIT AFTER COSTS | 503 | 503 | 59 | 1.64 | +779 | +13.2 |
| CHARGE NOW FIRST | 242 | 242 | 55 | 1.53 | -3171 | -57.6 |
| RANDOM MOVE BY FIGURES | 107 | 107 | 55 | 1.53 | +1179 | +21.4 |
| WALKS TO THE FIGHT | 90 | 90 | 55 | 1.53 | +605 | +11.0 |
| ADVANCE LANE KEPT | 54 | 54 | 54 | 1.50 | +0 | +0.0 |
| SAFER THAN THE JOB | 52 | 52 | 52 | 1.44 | +3453 | +66.4 |
| BEST OVERALL | 45 | 45 | 45 | 1.25 | +3116 | +69.2 |
| CANNON SIGHT KEPT | 42 | 42 | 42 | 1.17 | +0 | +0.0 |
| BEST FACING | 41 | 41 | 41 | 1.14 | +2399 | +58.5 |
| MAX FOR POSITIONING | 320 | 196 | 41 | 1.14 | +534 | +13.0 |
| RESERVE FALL BACK | 38 | 38 | 38 | 1.06 | +1514 | +39.8 |
| COMBAT PIVOT | 36 | 36 | 36 | 1.00 | +0 | +0.0 |
| HOLDS AMBUSHERS | 35 | 35 | 35 | 0.97 | +0 | +0.0 |
| REDIRECT COUNTER | 189 | 110 | 34 | 0.94 | +2642 | +77.7 |
| STOPS SHORT OF THE FLANK | 34 | 34 | 34 | 0.94 | +1136 | +33.4 |
| CHARGE NOW WEIGHED | 33 | 33 | 33 | 0.92 | +2075 | +62.9 |
| RISK BY ARC | 232 | 227 | 33 | 0.92 | +997 | +30.2 |
| KILLS COUNT | 147 | 144 | 31 | 0.86 | +1350 | +43.6 |
| SHOT REPLANNED | 30 | 30 | 30 | 0.83 | +0 | +0.0 |
| BLOCKED WHEEL | 28 | 28 | 28 | 0.78 | +657 | +23.5 |
| LONE WIZARD KEPT IN | 28 | 28 | 28 | 0.78 | +1699 | +60.7 |
| MISSILES IN THE MOVE | 204 | 124 | 27 | 0.75 | +530 | +19.6 |
| CANNON PLANNED TARGET | 186 | 186 | 26 | 0.72 | -308 | -11.8 |
| SET UP TOGETHER | 65 | 59 | 24 | 0.67 | +2137 | +89.0 |
| MARCH CHECK | 29 | 28 | 23 | 0.64 | +1144 | +49.7 |
| MARCH ODDS | 23 | 23 | 23 | 0.64 | +467 | +20.3 |
| WHOLE FIGHT GAIN | 38 | 35 | 23 | 0.64 | +1333 | +57.9 |
| INVITES THE FIGHT | 106 | 106 | 22 | 0.61 | +210 | +9.6 |
| KEEPS ITS TARGET | 135 | 134 | 21 | 0.58 | +305 | +14.5 |
| SCOUT WAITS | 21 | 21 | 21 | 0.58 | +0 | +0.0 |
| BIG CHARACTER SAFETY | 19 | 19 | 19 | 0.53 | +3 | +0.2 |
| REDIRECT WEIGHED | 19 | 19 | 19 | 0.53 | +746 | +39.3 |
| SHOOTERS IN TWO RANKS | 18 | 18 | 18 | 0.50 | +41 | +2.3 |
| SHOOTS FROM THE BEST SPOT | 45 | 45 | 18 | 0.50 | +473 | +26.3 |
| STUCK PIVOT | 18 | 18 | 18 | 0.50 | +0 | +0.0 |
| THROUGH LINE OF FIRE | 18 | 18 | 18 | 0.50 | +1138 | +63.2 |
| WHO HITS BACK | 18 | 18 | 18 | 0.50 | +1020 | +56.7 |
| BEST PREY | 58 | 58 | 17 | 0.47 | +905 | +53.3 |
| CASTER AWAY FROM SCREEN | 17 | 17 | 17 | 0.47 | +0 | +0.0 |
| MOVE AND CAST | 17 | 17 | 17 | 0.47 | +516 | +30.4 |
| CHAFF PASSED | 14 | 14 | 14 | 0.39 | -37 | -2.6 |
| CAST JOB | 31 | 31 | 13 | 0.36 | +440 | +33.8 |
| MANOEUVRE | 15 | 15 | 12 | 0.33 | +489 | +40.8 |
| MAKE SURE TOGETHER | 40 | 33 | 11 | 0.31 | +1202 | +109.3 |
| SUPPORT NARROWED | 520 | 520 | 11 | 0.31 | -115 | -10.5 |
| FRIENDS SHOTS CHECKED | 10 | 10 | 10 | 0.28 | +618 | +61.8 |
| MISSILES NEXT TURN | 269 | 154 | 10 | 0.28 | +23 | +2.3 |
| OPENS UP | 25 | 25 | 10 | 0.28 | +402 | +40.2 |
| WAR ENGINE JOBS | 30 | 30 | 10 | 0.28 | -136 | -13.6 |
| CASTING BLOCK | 14 | 14 | 9 | 0.25 | +544 | +60.4 |
| CASTS FROM BEHIND | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| LOST CHARGE | 179 | 178 | 9 | 0.25 | +214 | +23.8 |
| SHORT GUN FORWARD | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| WEARS DOWN | 93 | 90 | 8 | 0.22 | +503 | +62.8 |
| BLOCKED CHARGE SKIPPED | 7 | 7 | 7 | 0.19 | +0 | +0.0 |
| KEEP FALLS | 7 | 7 | 7 | 0.19 | +332 | +47.4 |
| MOVES UNITS SPELL | 7 | 7 | 7 | 0.19 | +138 | +19.7 |
| RAIDS THE BAGGAGE NEXT TURN | 8 | 8 | 7 | 0.19 | +282 | +40.3 |
| RESTRAINS TO SHOOT | 7 | 7 | 7 | 0.19 | +480 | +68.5 |
| STAY WEIGHED | 7 | 7 | 7 | 0.19 | +555 | +79.3 |
| SURE CHARGE BEATS ADVANCE | 7 | 7 | 7 | 0.19 | -228 | -32.6 |
| BACKUP TARGETS | 79 | 43 | 6 | 0.17 | +33 | +5.5 |
| HUNT IN PAIRS | 28 | 15 | 6 | 0.17 | +344 | +57.3 |
| PERIAPT WORTH | 6 | 6 | 6 | 0.17 | +364 | +60.6 |
| PURSUES BIG PREY | 6 | 6 | 6 | 0.17 | -689 | -114.9 |
| BOUND ASSAILMENT | 5 | 5 | 5 | 0.14 | +1 | +0.2 |
| MODEL FACING | 5 | 5 | 5 | 0.14 | +508 | +101.7 |
| NEEDED THERE | 5 | 5 | 5 | 0.14 | +0 | +0.0 |
| PIVOT GUARDS FLANK | 5 | 5 | 5 | 0.14 | -79 | -15.9 |
| SPELLS IN THE FIGHT | 37 | 35 | 5 | 0.14 | +51 | +10.1 |
| WHOLE FIGHT | 40 | 40 | 5 | 0.14 | +330 | +66.0 |
| LONE WIZARD HOLDS BACK | 14 | 14 | 4 | 0.11 | -198 | -49.6 |
| LONG SHOT | 41 | 41 | 4 | 0.11 | +36 | +8.9 |
| OVERRUNS AWAY | 53 | 52 | 4 | 0.11 | +66 | +16.6 |
| WAR ENGINE CHARGES | 5 | 5 | 4 | 0.11 | +522 | +130.5 |
| WIDER SPREAD | 148 | 144 | 4 | 0.11 | +28 | +7.1 |
| NO RALLY LEFT | 3 | 3 | 3 | 0.08 | +209 | +69.5 |
| REFUSING RETIRES | 9 | 9 | 3 | 0.08 | -1 | -0.2 |
| SURE REACH TOGETHER | 42 | 35 | 3 | 0.08 | +12 | +4.1 |
| EDGE GIVE GROUND | 13 | 13 | 2 | 0.06 | +61 | +30.6 |
| ELIXIR WORTH | 2 | 2 | 2 | 0.06 | +43 | +21.6 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| RAIDS THE BAGGAGE | 2 | 2 | 2 | 0.06 | +405 | +202.5 |
| BEST PRIZE | 1 | 1 | 1 | 0.03 | -28 | -27.9 |
| BOMBING RUN | 1 | 1 | 1 | 0.03 | +37 | +37.4 |
| CARRIES OUT COUNTER | 3 | 3 | 1 | 0.03 | -128 | -128.3 |
| CARRIES OUT SET-UP | 4 | 4 | 1 | 0.03 | -67 | -67.3 |
| CHARGE BAND | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| CHARGER SLAIN LOST | 31 | 28 | 1 | 0.03 | +5 | +5.0 |
| DEFENSIVE ARMY | 8 | 8 | 1 | 0.03 | -3 | -3.1 |
| DEFENSIVE FLOOR | 6 | 6 | 1 | 0.03 | +4 | +4.0 |
| FIRE AND FLEE | 1 | 1 | 1 | 0.03 | +12 | +12.3 |
| HILL BY ITS CHANCE | 34 | 34 | 1 | 0.03 | +10 | +10.0 |
| HUNT ADVANCE | 3 | 3 | 1 | 0.03 | +55 | +54.8 |
| REDIRECT BY WHAT IT STOPS | 32 | 32 | 1 | 0.03 | +6 | +6.1 |
| SCREEN BY WHAT IT SAVES | 16 | 16 | 1 | 0.03 | +9 | +9.2 |
| STANDS TO CAST | 1 | 1 | 1 | 0.03 | +38 | +38.5 |
| STOPS | 4 | 4 | 1 | 0.03 | +16 | +16.3 |
| TURN WORTH | 35 | 35 | 1 | 0.03 | +36 | +35.6 |
| ALREADY CARRIED | 2 | not checked | - | - | - | - |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| BLOWS WHERE AIMED | 14 | 13 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 40 | 40 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 45 | trace | - | - | - | - |
| CHARIOT NO STATIC JOB | 2 | 2 | 0 | 0.00 | - | - |
| CHARIOT WIZARD CAREFUL | 8 | 8 | 0 | 0.00 | - | - |
| CHEAP HELPER | 6 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 47 | not checked | - | - | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT LIFT | 4 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 363 | not checked | - | - | - | - |
| GIVES UP | 4 | 4 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 1 | 1 | 0 | 0.00 | - | - |
| GROUND FLIERS | 2 | not checked | - | - | - | - |
| HELPER ALREADY ASKED | 2 | not checked | - | - | - | - |
| HELPER UNSEEN | 30 | 30 | 0 | 0.00 | - | - |
| HUNT DROPPED | 1 | trace | - | - | - | - |
| HUNT RESULT | 7 | trace | - | - | - | - |
| HUNT THE GUNS | 7 | trace | - | - | - | - |
| JOINT CHARGE PLAN | 9 | 9 | 0 | 0.00 | - | - |
| JOINT KNOWS CHALLENGE | 8 | 7 | 0 | 0.00 | - | - |
| KEEPS ITS PREY | 1 | 1 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 18 | not checked | - | - | - | - |
| LURE BY WHAT IT DRAWS | 8 | 8 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 8 | trace | - | - | - | - |
| MARCH OVER CASTS | 32 | 32 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 20 | 20 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 14 | 8 | 0 | 0.00 | - | - |
| MOVE SPELL NOT WORTH | 1 | not checked | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 25 | trace | - | - | - | - |
| MOVE SPELL SPOT | 25 | not checked | - | - | - | - |
| NOT NEEDED | 23 | 23 | 0 | 0.00 | - | - |
| NOT TURNED | 376 | 376 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 33 | not checked | - | - | - | - |
| OPENS A LANE | 12 | 3 | 0 | 0.00 | - | - |
| PLAN RESULT | 2736 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 21 | 21 | 0 | 0.00 | - | - |
| SCOUT SPOT | 19 | 19 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 25 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 31 | not checked | - | - | - | - |
| SET-UP MISSED | 5 | trace | - | - | - | - |
| SHOOTER COUNTED ONCE | 1 | 1 | 0 | 0.00 | - | - |
| SPELL CATCH ODDS | 4 | not checked | - | - | - | - |
| SPELL SETS UP CHARGE | 33 | not checked | - | - | - | - |
| SPELL WORTH | 140 | not checked | - | - | - | - |
| STABLE ROLE | 735 | 734 | 0 | 0.00 | - | - |
| TWO OR MORE ARRIVE | 25 | 25 | 0 | 0.00 | - | - |

### Off best figure: cb-h2h-opp-24b8cfb-p4

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 13.28 | 11.75 | 50.7 |
| CHARGE NOW FIRST | rule | 0.69 | 0.81 | 58.7 |
| FALLBACK | gate | 0.64 | 0.64 | 42.6 |
| TURN GATE | gate | 0.53 | 0.50 | 29.8 |
| PATHS CROSS | rule | 0.17 | 0.17 | 28.4 |
| AFTERMATH BAND | gate | 0.08 | 0.22 | 2.2 |
| SUPPORT NARROWED | rule | 0.14 | 0.17 | 10.5 |
| CANNON PLANNED TARGET | rule | 0.25 | 0.03 | 33.1 |
| WAR ENGINE JOBS | rule | 0.28 | - | 13.6 |
| BIG CHARACTER SAFETY | rule | 0.06 | 0.17 | 7.6 |
| FIGHT ORDER BAND | gate | 0.17 | 0.06 | 2.3 |
| BLOCKED WHEEL | rule | 0.14 | 0.06 | 7.0 |
| CHAFF PASSED | rule | 0.14 | 0.06 | 5.2 |
| LONE CHARACTER SAFE SPOT | gate | 0.17 | 0.03 | 66.1 |
| SUPPORT REQUEST | gate | 0.08 | 0.11 | 90.2 |
| SURE CHARGE BEATS ADVANCE | rule | 0.11 | 0.08 | 32.6 |
| PURSUES BIG PREY | rule | 0.11 | 0.06 | 114.9 |
| STOPS SHORT OF THE FLANK | rule | 0.06 | 0.11 | 8.4 |
| CHARGE NOW WEIGHED | rule | 0.06 | 0.08 | 51.9 |
| PIVOT GUARDS FLANK | rule | 0.08 | 0.06 | 15.9 |
| LONE WIZARD HOLDS BACK | rule | - | 0.11 | 49.6 |
| NO REASON | gate | - | 0.08 | 3.1 |
| THROUGH LINE OF FIRE | rule | 0.06 | - | 16.7 |
| AFTERMATH NEEDS NEXT CHARGE | gate | - | 0.03 | 56.9 |
| BEST PRIZE | rule | - | 0.03 | 27.9 |
| CARRIES OUT COUNTER | rule | - | 0.03 | 128.3 |
| CARRIES OUT SET-UP | rule | - | 0.03 | 67.3 |
| DEFENSIVE ARMY | rule | 0.03 | - | 3.1 |
| FACES THE THREAT | rule | - | 0.03 | 3.7 |
| FALLBACK BY WORTH | rule | 0.03 | - | 15.9 |
| FOLLOW UP WEIGHED | rule | - | 0.03 | 2.0 |
| MARCH ODDS | rule | - | 0.03 | 4.6 |
| RULE SWITCHED OFF | gate | 0.03 | - | 15.7 |
| SAFER THAN THE JOB | rule | - | 0.03 | 6.9 |
| WHO HITS BACK | rule | - | 0.03 | 4.1 |

### Plans: cb-h2h-opp-24b8cfb-p4

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 12.1 | 18% | 436 | 293 | 67% |
| Mine | charge | 3.7 | 58% | 311 | 308 | 99% |
| Mine | close in | 4.1 | 26% | 251 | 141 | 56% |
| Mine | hold | 4.7 | 34% | 279 | 0 | 0% |
| Mine | join | 0.6 | 91% | 10 | 0 | 0% |
| Mine | shoot | 8.3 | 63% | 330 | 743 | 225% |
| Mine | support | 4.3 | 89% | 42 | 0 | 0% |
| Opponent | advance | 12.5 | 18% | 326 | 440 | 135% |
| Opponent | charge | 5.6 | 58% | 526 | 521 | 99% |
| Opponent | close in | 5.6 | 20% | 375 | 92 | 25% |
| Opponent | hold | 4.3 | 31% | 296 | 0 | 0% |
| Opponent | join | 0.6 | 100% | 26 | 0 | 0% |
| Opponent | shoot | 3.2 | 54% | 83 | 177 | 213% |
| Opponent | support | 6.0 | 94% | 52 | 0 | 0% |

### Packages: hunt the guns, cb-h2h-opp-24b8cfb-p4

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 11 |
| Opponent | 0.2 | 7 | 0 | 14% | 14% | 0% | 2.0 | 247 | 41 | 14% | 113 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 137 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 28 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| High Elf Realms | 0.1 | 1 | 0 | 0% | 0% | 0% | - | 268 | 0 | 0% | 71 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 78 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 107 |
| Tomb Kings of Khemri | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Vampire Counts | 0.6 | 5 | 0 | 20% | 20% | 0% | 2.0 | 275 | 58 | 20% | 79 |
| Warriors of Chaos | 0.1 | 1 | 0 | 0% | 0% | 0% | - | 85 | 0 | 0% | 112 |
| Wood Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 126 |

### Battle groups: cb-h2h-opp-24b8cfb-p4

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 7.8 | 30% | 41% | 10% | 12% | 32% | 12% | 15% | 41% | 0% |
| Mine | REDIRECT COUNTER | 1.9 | 52% | 72% | 14% | 40% | 10% | 3% | 19% | 65% | 3% |
| Opponent | COUNTER-CHARGE COVER | 7.9 | 20% | 79% | 28% | 31% | 39% | 5% | 10% | 46% | 0% |
| Opponent | REDIRECT COUNTER | 3.3 | 28% | 79% | 27% | 11% | 46% | 0% | 17% | 33% | 4% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: cb-h2h-opp-24b8cfb-p4

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 4 | 0 (4) | 0 | 0 | 100 | 75% | 4.0 | - | 0 (1) | - | - | 0 (1) |
| Mine | Chaff | 34 | 33 (34) | 26 | 7 | 67 | 32% | 2.4 | 29 (14) | 0 (5) | 48 (15) | 35 (20) | 30 (14) |
| Mine | Character | 106 | 46 (106) | 46 | 0 | 38 | 13% | 2.3 | 53 (32) | 48 (55) | 10 (6) | 48 (47) | 49 (46) |
| Mine | Clean-up | 23 | 52 (23) | 20 | 32 | 68 | 26% | 2.5 | 0 (2) | 58 (17) | 57 (4) | 57 (11) | 48 (12) |
| Mine | Early | 1 | 0 (1) | 0 | 0 | 100 | 0% | 6.0 | - | 0 (1) | - | - | 0 (1) |
| Mine | Fast | 4 | 55 (4) | 55 | 0 | 100 | 0% | 3.2 | 111 (2) | 0 (2) | - | 76 (3) | 0 (1) |
| Mine | Fast Hammer | 41 | 57 (41) | 31 | 25 | 50 | 15% | 2.9 | 51 (27) | 98 (9) | 11 (5) | 78 (25) | 26 (16) |
| Mine | Fragile | 4 | 0 (4) | 0 | 0 | 100 | 25% | 2.3 | 0 (1) | 0 (2) | 0 (1) | 0 (1) | 0 (3) |
| Mine | Hammer | 64 | 38 (64) | 29 | 9 | 50 | 16% | 2.6 | 43 (13) | 38 (44) | 27 (7) | 40 (39) | 36 (25) |
| Mine | Holder | 31 | 71 (31) | 11 | 59 | 41 | 32% | 3.0 | 23 (7) | 121 (17) | 12 (7) | 93 (20) | 36 (11) |
| Mine | Shooter | 34 | 68 (34) | 29 | 39 | 48 | 3% | 1.5 | 46 (8) | 91 (21) | 5 (5) | 77 (25) | 36 (9) |
| Mine | Support | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | - | 0 (1) | 0 (1) | - |
| Mine | War machine | 56 | 60 (56) | 60 | 0 | 44 | 5% | 1.2 | 69 (16) | 52 (30) | 63 (10) | 56 (9) | 60 (47) |
| Mine | Wizard | 17 | 0 (17) | 0 | 0 | 60 | 6% | 2.8 | 0 (3) | 0 (6) | 0 (1) | 0 (3) | 0 (7) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | 0 (1) | - | - | - | 0 (1) |
| Opponent | Chaff | 77 | 45 (77) | 23 | 21 | 59 | 35% | 2.6 | 38 (32) | 61 (18) | 38 (27) | 52 (58) | 18 (19) |
| Opponent | Character | 97 | 59 (97) | 59 | 0 | 31 | 20% | 2.5 | 66 (43) | 52 (39) | 76 (7) | 66 (53) | 55 (36) |
| Opponent | Clean-up | 12 | 36 (12) | 12 | 24 | 55 | 33% | 2.5 | 39 (4) | 18 (5) | 68 (3) | 20 (7) | 46 (5) |
| Opponent | Fast | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Fast Hammer | 54 | 49 (54) | 31 | 18 | 51 | 37% | 2.5 | 53 (22) | 36 (24) | 80 (8) | 40 (33) | 61 (21) |
| Opponent | Fragile | 17 | 13 (17) | 13 | 0 | 72 | 24% | 2.3 | 0 (4) | 24 (9) | 0 (4) | 17 (13) | 0 (4) |
| Opponent | Hammer | 65 | 37 (65) | 23 | 14 | 39 | 37% | 3.0 | 5 (20) | 47 (38) | 51 (7) | 42 (41) | 30 (24) |
| Opponent | Holder | 30 | 32 (30) | 9 | 23 | 17 | 50% | 4.0 | 15 (10) | 47 (15) | 0 (5) | 38 (17) | 24 (13) |
| Opponent | Shooter | 34 | 70 (34) | 29 | 41 | 37 | 0% | 1.5 | 49 (10) | 83 (21) | 55 (3) | 76 (19) | 63 (15) |
| Opponent | Support | 6 | 0 (6) | 0 | 0 | 49 | 50% | 2.0 | 0 (2) | 0 (1) | - | 0 (1) | 0 (2) |
| Opponent | War machine | 6 | 63 (6) | 63 | 0 | 80 | 17% | 1.0 | 106 (3) | 0 (3) | - | 106 (3) | 0 (3) |
| Opponent | Wizard | 20 | 30 (20) | 30 | 0 | 30 | 10% | 2.3 | 20 (12) | 0 (3) | 73 (3) | 39 (12) | 0 (6) |

### Charged fights: cb-h2h-opp-24b8cfb-p4

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 214 | 116 | 2.8 | 1.1 | 42 | 35 | +7 | 3 of 11 | 7 of 11 | +70 | +1 |
| Mine | Chaos Dwarfs | 4 | 128 | 399 | 3.0 | 1.0 | 133 | 52 | +81 | 6 of 12 | 9 of 12 | - | +81 |
| Mine | Dwarfen Mountain Holds | 3 | 560 | 145 | 3.0 | 1.0 | 48 | 7 | +42 | 4 of 9 | 6 of 9 | - | +42 |
| Mine | Empire of Man | 5 | 676 | 149 | 2.0 | 1.2 | 74 | 164 | -90 | 5 of 10 | 4 of 10 | -514 | -42 |
| Mine | Grand Cathay | 4 | 272 | 429 | 4.5 | 1.2 | 95 | 0 | +95 | 3 of 18 | 16 of 18 | +158 | +83 |
| Mine | High Elf Realms | 4 | 220 | 396 | 3.8 | 1.0 | 106 | 20 | +86 | 4 of 15 | 12 of 15 | - | +86 |
| Mine | Kingdom of Bretonnia | 1 | 65 | 987 | 7.0 | 1.3 | 141 | 0 | +141 | 4 of 7 | 6 of 7 | +105 | +155 |
| Mine | Lizardmen | 1 | 0 | 660 | 4.0 | 1.0 | 165 | 119 | +46 | 2 of 4 | 4 of 4 | - | +46 |
| Mine | Ogre Kingdoms | 2 | 0 | 28 | 3.0 | 1.3 | 9 | 220 | -210 | 4 of 6 | 3 of 6 | -150 | -240 |
| Mine | Skaven | 2 | 335 | 162 | 2.5 | 1.0 | 65 | 22 | +42 | 0 of 5 | 4 of 5 | - | +42 |
| Mine | Tomb Kings of Khemri | 2 | 0 | 215 | 3.0 | 1.0 | 72 | 183 | -111 | 2 of 6 | 2 of 6 | - | -111 |
| Mine | Vampire Counts | 2 | 14 | 147 | 4.0 | 1.1 | 37 | 52 | -15 | 2 of 8 | 6 of 8 | +0 | -17 |
| Mine | Warriors of Chaos | 2 | 0 | 416 | 4.0 | 1.0 | 104 | 98 | +6 | 3 of 8 | 6 of 8 | - | +6 |
| **Mine** | all armies | 36 | 254 | 281 | 3.3 | 1.1 | 85 | 61 | +24 | 42 of 119 | 85 of 119 | -6 | +27 |
| Opponent | Empire of Man | 1 | 575 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | High Elf Realms | 5 | 266 | 369 | 3.2 | 1.2 | 115 | 55 | +60 | 7 of 16 | 12 of 16 | +108 | +49 |
| Opponent | Lizardmen | 2 | 0 | 631 | 3.5 | 1.6 | 180 | 32 | +148 | 4 of 7 | 6 of 7 | +52 | +220 |
| Opponent | Orc & Goblin Tribes | 3 | 11 | 267 | 3.3 | 1.2 | 80 | 0 | +80 | 4 of 10 | 9 of 10 | +117 | +71 |
| Opponent | Skaven | 4 | 123 | 69 | 1.8 | 1.0 | 39 | 60 | -21 | 1 of 7 | 5 of 7 | - | -21 |
| Opponent | Tomb Kings of Khemri | 2 | 22 | 1084 | 4.5 | 1.6 | 241 | 0 | +241 | 3 of 9 | 7 of 9 | +200 | +274 |
| Opponent | Vampire Counts | 6 | 25 | 581 | 6.3 | 1.2 | 92 | 35 | +57 | 22 of 38 | 24 of 38 | +108 | +49 |
| Opponent | Warriors of Chaos | 7 | 12 | 373 | 3.4 | 1.0 | 109 | 50 | +58 | 15 of 24 | 14 of 24 | -155 | +68 |
| Opponent | Wood Elf Realms | 6 | 87 | 405 | 4.5 | 1.2 | 90 | 38 | +52 | 12 of 27 | 18 of 27 | +73 | +48 |
| **Opponent** | all armies | 36 | 90 | 413 | 3.8 | 1.2 | 108 | 37 | +71 | 68 of 138 | 95 of 138 | +98 | +66 |

### Effective charges: cb-h2h-opp-24b8cfb-p4

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 11 | 1 (net +0) | 1 (net -85) | 1 (net -81) | 2 (net -62) | 0 | 5 (net +73) | 1 | 10% (1 of 10) |
| Mine | Chaos Dwarfs | 12 | 2 (net +308) | 0 | 3 (net -207) | 3 (net +0) | 2 (net +169) | 1 (net +482) | 1 | 27% (3 of 11) |
| Mine | Dwarfen Mountain Holds | 9 | 0 | 0 | 3 (net +0) | 2 (net +0) | 0 | 4 (net +94) | 0 | 33% (3 of 9) |
| Mine | Empire of Man | 10 | 2 (net -119) | 1 (net -189) | 2 (net -257) | 2 (net +294) | 0 | 2 (net -152) | 1 | 22% (2 of 9) |
| Mine | Grand Cathay | 18 | 0 | 1 (net +0) | 1 (net +329) | 7 (net +41) | 3 (net +119) | 6 (net +124) | 0 | 6% (1 of 18) |
| Mine | High Elf Realms | 15 | 2 (net +0) | 0 | 2 (net +35) | 2 (net +326) | 4 (net +92) | 4 (net +35) | 1 | 14% (2 of 14) |
| Mine | Kingdom of Bretonnia | 7 | 1 (net +0) | 0 | 1 (net +0) | 1 (net +540) | 2 (net +151) | 2 (net +72) | 0 | 14% (1 of 7) |
| Mine | Lizardmen | 4 | 0 | 0 | 0 | 1 (net +255) | 0 | 2 (net -64) | 1 | 0% (0 of 3) |
| Mine | Ogre Kingdoms | 6 | 0 | 0 | 2 (net -65) | 1 (net +0) | 0 | 1 (net -301) | 2 | 50% (2 of 4) |
| Mine | Skaven | 5 | 0 | 0 | 0 | 1 (net +112) | 0 | 4 (net +25) | 0 | 0% (0 of 5) |
| Mine | Tomb Kings of Khemri | 6 | 0 | 0 | 2 (net -388) | 4 (net +27) | 0 | 0 | 0 | 33% (2 of 6) |
| Mine | Vampire Counts | 8 | 1 (net +0) | 0 | 3 (net -123) | 1 (net -18) | 2 (net +134) | 1 (net +0) | 0 | 38% (3 of 8) |
| Mine | Warriors of Chaos | 8 | 1 (net +107) | 0 | 3 (net -29) | 0 | 0 | 3 (net +9) | 1 | 43% (3 of 7) |
| Opponent | High Elf Realms | 16 | 2 (net +119) | 0 | 2 (net +127) | 3 (net +193) | 1 (net +0) | 3 (net +0) | 5 | 18% (2 of 11) |
| Opponent | Lizardmen | 7 | 1 (net -175) | 0 | 2 (net +295) | 4 (net +156) | 0 | 0 | 0 | 29% (2 of 7) |
| Opponent | Orc & Goblin Tribes | 10 | 0 | 1 (net +77) | 1 (net +0) | 3 (net +136) | 0 | 0 | 5 | 20% (1 of 5) |
| Opponent | Skaven | 7 | 3 (net -94) | 1 (net +0) | 0 | 0 | 0 | 3 (net +46) | 0 | 0% (0 of 7) |
| Opponent | Tomb Kings of Khemri | 9 | 1 (net +210) | 0 | 0 | 3 (net +119) | 2 (net +145) | 3 (net +437) | 0 | 0% (0 of 9) |
| Opponent | Vampire Counts | 38 | 11 (net +61) | 1 (net +0) | 7 (net +82) | 7 (net +101) | 1 (net +104) | 9 (net +34) | 2 | 19% (7 of 36) |
| Opponent | Warriors of Chaos | 24 | 5 (net +97) | 0 | 4 (net -93) | 0 | 2 (net +265) | 7 (net -14) | 6 | 22% (4 of 18) |
| Opponent | Wood Elf Realms | 27 | 8 (net -39) | 0 | 4 (net +0) | 4 (net +186) | 2 (net +128) | 9 (net +80) | 0 | 15% (4 of 27) |

### Charged fights, damage counted: cb-h2h-opp-24b8cfb-p4

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 10 | 266 | 295 | +48 | 117 | 86 | +31 | +11.7 |
| Mine | 50-54% | 3 | 176 | 194 | -91 | 18 | 99 | -80 | -45.5 |
| Mine | Effective (55-75%) | 23 | 282 | 239 | -95 | 92 | 164 | -72 | -25.5 |
| Mine | 76-89% | 27 | 242 | 200 | +89 | 135 | 50 | +85 | +35.1 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 35 | 208 | 173 | +47 | 108 | 51 | +57 | +27.2 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 13 | 444 | 100 | +125 | 148 | 27 | +121 | +27.3 |
| Mine | No odds | 8 | 237 | 290 | -99 | 50 | 176 | -126 | -53.3 |
| Mine | All fights | 119 | 262 | 202 | +24 | 110 | 82 | +27 | +10.4 |
| Opponent | Long shot (under 50%) | 31 | 267 | 283 | +27 | 115 | 75 | +40 | +14.9 |
| Opponent | 50-54% | 3 | 147 | 141 | +26 | 31 | 7 | +24 | +16.1 |
| Opponent | Effective (55-75%) | 20 | 257 | 223 | +52 | 130 | 94 | +36 | +14.0 |
| Opponent | 76-89% | 24 | 396 | 201 | +142 | 180 | 42 | +138 | +34.9 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 34 | 303 | 208 | +70 | 114 | 34 | +80 | +26.4 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 8 | 553 | 121 | +148 | 159 | 29 | +131 | +23.6 |
| Opponent | No odds | 18 | 335 | 190 | +49 | 80 | 40 | +40 | +11.8 |
| Opponent | All fights | 138 | 320 | 217 | +71 | 124 | 53 | +71 | +22.3 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| cb-h2h-opp-24b8cfb-p4 | move | 438 | 98 (22%) | 71 (16%) | 64 (15%) | 276 (63%) |
| cb-h2h-opp-24b8cfb-p4 | objective | 351 | 46 (13%) | 37 (11%) | 59 (17%) | 246 (70%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0114, L0130, L2527, L2634 |
| Charmed Shield | Opponent | L0434, L0624, L0926, L1034, L1126, L1427, L2227, L2527, L2634, L3234 |
| Clockwork Compass | Mine | L1220 |
| Elixir of Power | Mine | L1126 |
| Elixir of Power | Opponent | L0819, L1719, L1819 |
| Fistful of Laurels | Mine | L1819, L1835 |
| Invocation of Nehek | Mine | L2527 |
| Invocation of Nehek | Opponent | L0624, L1427, L2227, L2527 |
| Opal Amulet | Mine | L1427 |
| Opal Amulet | Opponent | L0114, L0214, L1314 |
| Periapt of Soul Exchange | Mine | L2021, L2123 |
| Periapt of Soul Exchange | Opponent | L0520, L1220, L1621, L2021 |
| Ring of Doom | Mine | L0214, L0230, L1126, L1220, L1523 |
| Ring of Doom | Opponent | L0315, L1331, L2331 |
| Ring of Jet | Mine | L1017, L1034, L1126, L1220 |
| Standard of the Fell Warrior | Mine | L1314, L1331 |
| Standard of the Fell Warrior | Opponent | L0713 |
| Storm Daemon (Renegade 2.0) | Mine | L2123 |
| Storm Daemon (Renegade 2.0) | Opponent | L1621, L2021 |
| Twice-Blessed Armour | Mine | L0713, L0729, L1017, L1034 |
| Witch Hunter's Ward | Mine | L0713, L0729, L0819, L0835 |
| Witch Hunter's Ward | Opponent | L0608 |

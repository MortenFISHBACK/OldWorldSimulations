# Doctrine scorecard: h8-mine-6ec093a-p1

### Scorecard: h8-mine-6ec093a-p1

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0103 | 1 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 0 |
| L0103 | 1 | 1 | Opponent | no | 0 | 4 | 1 | 1 | 0 | 0 | 0 | 340 |
| L0120 | 6 | 1 | Mine | no | 6 | - | 0 | 2 | 0 | 0 | 0 | 0 |
| L0120 | 6 | 1 | Opponent | no | 1 | - | 0 | 4 | 0 | 0 | 0 | 210 |
| L0204 | 6 | 1 | Mine | no | 0 | 5 | 1 | 4 | 1 | 0 | 0 | 170 |
| L0204 | 6 | 1 | Opponent | no | 4 | 2 | 2 | 0 | 0 | 0 | 0 | 0 |
| L0219 | 3 | 1 | Mine | no | 8 | 2 | 4 | 0 | 1 | 0 | 0 | 255 |
| L0219 | 3 | 1 | Opponent | yes | 4 | 2 | 0 | 0 | 0 | 0 | 0 | 0 |
| L0304 | 4 | 1 | Mine | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 280 |
| L0304 | 4 | 1 | Opponent | no | 0 | 3 | 2 | 4 | 0 | 0 | 0 | 0 |
| L0321 | 3 | 1 | Mine | no | 7 | 5 | 1 | 0 | 0 | 0 | 0 | 140 |
| L0321 | 3 | 1 | Opponent | no | 4 | - | 0 | 3 | 2 | 0 | 0 | 210 |
| L0406 | 4 | 1 | Mine | no | 0 | 3 | 3 | 2 | 0 | 0 | 0 | 0 |
| L0406 | 4 | 1 | Opponent | no | 0 | - | 0 | 0 | 0 | 0 | 0 | 1027 |
| L0423 | 3 | 1 | Mine | no | 7 | 2 | 4 | 0 | 0 | 0 | 0 | 0 |
| L0423 | 3 | 1 | Opponent | no | 5 | 2 | 3 | 1 | 2 | 0 | 0 | 0 |
| **Average** | | | Mine | 0% | 3.5 | 3.4 | 1.6 | 1.4 | 0.2 | 0.0 | 0.0 | 105.6 |
| **Average** | | | Opponent | 12% | 2.2 | 2.6 | 1.0 | 1.6 | 0.5 | 0.0 | 0.0 | 223.4 |

### KPIs: h8-mine-6ec093a-p1

Rules off - Opponent only: HOLDER ASSIGNMENT, QUARTER ODDS, WALK PROMISE, REAL GROUND, RISK ON THE WAY.

Morten 2026-11-10; 8 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 22% (5 of 23) | 22% (7 of 32) | 22% (12 of 55) |
| Winner chose to follow up after the loser gave ground |  | 100% (3 of 3); on the table 100% | 100% (3 of 3); on the table 100% | 100% (6 of 6); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | - | - | - |
| Winner chose to pursue after the loser fled |  | 100% (1 of 1); on the table 100% | 86% (6 of 7); on the table 86% | 88% (7 of 8); on the table 88% |
| Winner chose to follow up or pursue (all three) |  | 100% (4 of 4); on the table 100% | 90% (9 of 10); on the table 90% | 93% (13 of 14); on the table 93% |
| Magic missiles tried each own turn | 50%+ | 42% (58 of 138) | 31% (13 of 42) | 39% (71 of 180) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 47% (58 of 123) | 37% (13 of 35) | 45% (71 of 158) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 43% (3 of 7) | 85% (17 of 20) | 74% (20 of 27) |
| Points that never fought | lower | 62% (9158 of 14788) | 61% (9677 of 15995) | 61% (18835 of 30783) |
|   infantry points that never fought | lower | 83% (3633 of 4386) | 78% (3283 of 4229) | 80% (6916 of 8615) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 56% (29 of 52) | 54% (34 of 63) | 55% (63 of 115) |
| Bound items with a magic missile used (at least once a game) |  | 100% (6 of 6); 3.1 uses a game | 100% (1 of 1); 0.6 uses a game | 100% (7 of 7); 1.9 uses a game |
| Bound items with another spell used |  | 100% (2 of 2); 0.8 uses a game | 0.0 uses a game | 100% (2 of 2); 0.4 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 75% (6 of 8); 0.8 uses a game | 100% (4 of 4); 0.5 uses a game | 83% (10 of 12); 0.6 uses a game |
|   their share of the points of units over 100 pts | lower | 54% (6240 of 11648) | 47% (6429 of 13549) | 50% (12669 of 25197) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 6.6 (66%) | 1.6 (45%) | 8.2 (61%) |
| MARCHED: its unit marched | 1.1 (11%) | 0.9 (24%) | 2.0 (15%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.1 (3%) | 0.1 (1%) |
| IN COMBAT: engaged in combat | 0.5 (5%) | 0.6 (17%) | 1.1 (8%) |
| FLEEING: fleeing | 0.2 (2%) | 0.0 (0%) | 0.2 (2%) |
| GONE: slain | 1.1 (11%) | 0.2 (7%) | 1.4 (10%) |
| STUPIDITY: Stupidity | 0.4 (4%) | 0.0 (0%) | 0.4 (3%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.1 (3%) | 0.1 (1%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 5.5 | 0.0 | 3.1 | 8.9 | 0.4 | 0.6 |
| not cast | 2.8 | 0.8 | 5.9 | 13.6 | 1.9 | 23.4 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.6 (7%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.1 (17%) | 1.0 (17%) | 8.2 (61%) | 0.2 (13%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.0 (15%) | 0.1 (7%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.0 (0%) | 0.5 (9%) | 1.1 (8%) | 0.1 (7%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.8 (40%) | 0.0 (0%) |
| FLEEING: fleeing | 0.1 (5%) | 0.0 (0%) | 0.0 (0%) | 0.2 (2%) | 0.0 (0%) | 0.8 (3%) |
| GONE: slain | 0.8 (27%) | 0.0 (0%) | 0.5 (9%) | 1.4 (10%) | 0.5 (27%) | 1.6 (7%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.4 (2%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.0 (0%) | 0.1 (2%) | 0.4 (3%) | 0.0 (0%) | 0.1 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (5%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.1 (7%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.8 (64%) | 0.6 (83%) | 3.8 (64%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 18.9 (81%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 3.1 a game | 0.8 a game | 1.9 a game |
| stood (cast and not dispelled) | 44% (11 of 25) | 0% (0 of 6) | 35% (11 of 31) |
| the unit moved after it | 36% (4 of 11) | - | 36% (4 of 11) |
| it charged on its next turn | 0% (0 of 11) | - | 0% (0 of 11) |
| the enemy charged it first | 0% (0 of 11) | - | 0% (0 of 11) |
| it fought by the end of its next turn | 0% (0 of 11) | - | 0% (0 of 11) |
| it moved out of a charge the enemy had planned (not charged first) | 9% (1 of 11) | - | 9% (1 of 11) |
| none of these (no charge, no fight, no charge escaped) | 91% (10 of 11) | - | 91% (10 of 11) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 58% (60 of 103) | 71% (146 of 207) | 66% (206 of 310) |
|   cavalry | 25% (2 of 8) | 88% (23 of 26) | 74% (25 of 34) |
|   character | - | 41% (7 of 17) | 41% (7 of 17) |
|   chariot | 30% (9 of 30) | 58% (31 of 53) | 48% (40 of 83) |
|   infantry | 79% (19 of 24) | 74% (42 of 57) | 75% (61 of 81) |
|   monster | - | 67% (4 of 6) | 67% (4 of 6) |
|   war machine | 73% (30 of 41) | 81% (39 of 48) | 78% (69 of 89) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.5 (28%) | 1.0 (13%) | 2.5 (19%) |
| CHARGED: it charged | 0.2 (5%) | 0.9 (11%) | 1.1 (9%) |
| FLEEING: it fled or was fleeing | 0.1 (2%) | 0.0 (0%) | 0.1 (1%) |
| IN COMBAT: it fought this turn or the last | 0.2 (5%) | 0.4 (5%) | 0.6 (5%) |
| MOVED: a war machine that moved | 1.2 (23%) | 0.4 (5%) | 1.6 (12%) |
| NO TARGET IN RANGE | 1.1 (21%) | 2.2 (30%) | 3.4 (26%) |
| ONLY IN COMBAT: the only targets were in combat | 0.1 (2%) | 0.4 (5%) | 0.5 (4%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.8 (14%) | 1.8 (23%) | 2.5 (19%) |
| OTHER BAR | 0.0 (0%) | 0.6 (8%) | 0.6 (5%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 3.1 | 0.8 | 80% | 3.9 pts | 12 pts |
| character | 0.9 | 0.4 | 71% | 10.2 pts | 9 pts |
| chariot | 5.6 | 5.6 | 49% | 14.8 pts | 83 pts |
| infantry | 10.1 | 3.1 | 79% | 6.1 pts | 61 pts |
| monster | 0.5 | 0.1 | 75% | 1.1 pts | 1 pts |
| war machine | 8.6 | 17.9 | 65% | 72.4 pts | 624 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 2.9 | 3.0 | 2.9 |
| Charges that made contact a game | 2.1 | 2.5 | 2.3 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.50 declared, 0.50 contact (6 units) | 0.67 declared, 0.67 contact (6 units) | 0.58 declared, 0.58 contact (12 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | - | - |
|   per unit a game, the other units (no war machines, no joined characters) | 0.38 declared, 0.27 contact (52 units) | 0.30 declared, 0.24 contact (67 units) | 0.34 declared, 0.25 contact (119 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 0% (0 of 4) | 0% (0 of 1) | - | 0% (0 of 5) |
| Character in a unit | 81% (13 of 16) | 67% (6 of 9) | - | 76% (19 of 25) |
| Character on its own | - | 0% (0 of 4) | 33% (3 of 9) | 23% (3 of 13) |
| Chariot | 50% (1 of 2) | 67% (8 of 12) | - | 64% (9 of 14) |
| Infantry | 43% (9 of 21) | 27% (3 of 11) | - | 38% (12 of 32) |
| Monster | 60% (3 of 5) | 100% (3 of 3) | - | 75% (6 of 8) |
| Monstrous | - | 0% (0 of 2) | - | 0% (0 of 2) |
| War Machines | 92% (12 of 13) | 67% (2 of 3) | - | 88% (14 of 16) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 100% (1 of 1); on the table 100% | 52% (53 of 102) | 72% | 64% (14 of 22) | 100% (6 of 6); 6.2 uses a game | 100% (2 of 2); 1.5 uses a game | 83% (5 of 6); 1.2 uses a game |
| Chaos Dwarfs | 7 | 100% (5 of 5); on the table 100% | 17% (10 of 60) | 60% | 52% (28 of 54) | 0.0 uses a game | 0.0 uses a game | 67% (2 of 3); 0.3 uses a game |
| Dwarfen Mountain Holds | 1 | - | - | 64% | 90% (9 of 10) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 1 | 100% (3 of 3); on the table 100% | 33% (2 of 6) | 27% | 12% (1 of 8) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Skaven | 2 | 100% (2 of 2); on the table 100% | 50% (6 of 12) | 85% | 62% (10 of 16) | 100% (1 of 1); 2.5 uses a game | 0.0 uses a game | 100% (2 of 2); 1.0 uses a game |
| Tomb Kings of Khemri | 1 | 67% (2 of 3); on the table 67% | - | 14% | 20% (1 of 5) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (h8-mine-6ec093a-p1, 8 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 61% (11) | 33% (3) | 52% (14) |
| ...free all their last turn and able to turn (per game) | 0.75 | 0.12 | 0.88 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.38 | 0.25 | 0.62 |
| ...with the charger already in that arc before they moved (per game) | 0.50 | 0.12 | 0.62 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.25 | 0.25 | 0.50 |

### Quality by phase: h8-mine-6ec093a-p1

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.0 | 1.4 |
| Strategy | Charge objectives carried out (made contact) | 59% (13 of 22) | 62% (13 of 21) |
| Strategy | Shoot objectives carried out (shot that target) | 29% (19 of 65) | 70% (61 of 87) |
| Strategy | Support requests answered (helper made contact too) | 100% (1 of 1) | - |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | - | 100% (3 of 3) |
| Strategy | Joined characters whose unit fought | 21% (5 of 24) | 45% (5 of 11) |
| Strategy | Lone characters that fought | 70% (7 of 10) | 69% (9 of 13) |
| Movement | Charges halted short of contact | 0.1 | 0.0 |
| Movement | Idle units | 1.4 | 1.6 |
| Movement | Points that never moved of their own | 105.6 | 223.4 |
| Movement | Fights charged into per game | 2.0 | 2.4 |
| Movement | Charges with odds: long shots (under 50%) | 4 of 16, net +89 | 4 of 16, net +60 |
| Movement | Charges with odds: sweet spot (55-75%) | 2 of 16, net +0 | 1 of 16, net +310 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 4 of 16, net -115 | 4 of 16, net +122 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 of 16, net +40 | 4 of 16, net +42 |
| Shooting | Shots by shooting units (incl. breath weapons) | 3.8 | 14.8 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 43% (13 of 30) | 44% (52 of 118) |
| Shooting | Points destroyed by shooting units | 35.0 | 90.2 |
| Shooting | War machine shots | 3.8 | 4.9 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 40% (12 of 30) | 72% (28 of 39) |
| Shooting | Points destroyed by war machines | 85.6 | 0.0 |
| Magic | Magic missiles cast | 4.4 | 1.1 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 40% (14 of 35) | 44% (4 of 9) |
| Magic | Wounds caused by magic missiles | 10.9 | 2.1 |
| Magic | Wounds caused by other spells | - | 0.5 |
| Magic | Points destroyed by magic (all spells) | 137.2 | 10.6 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.2 / 0.0 / 0.1 / 0.4 | 2.9 / 0.0 / 0.2 / 0.0 |
| Combat | Points destroyed in combat | 125.6 | 273.1 |
| Combat | Points run down | 0.0 | 30.6 |
| Combat | Net points per charged fight, damage counted | +30 | +78 |
| Combat | Net per 100 charger points, damage counted | +11.2 | +22.4 |
| Combat | First round won (charged fights) | 75% | 78% |
| Combat | Net points per charged fight | +14 | +92 |
| Combat | Net points per supported fight / lone fight | +65 / +10 | +310 / +80 |
| Combat | Charged fights on a top-3 enemy unit | 3 of 16 | 9 of 19 |
| Game | Points lost | 527.2 | 450.5 |
| Game | VP from objectives | 691.2 | 723.8 |
| Game | Lone holders (player turns) | 3.5 | 2.2 |

- Mine won / drew / lost: 3 / 1 / 4 of 8 ended games (of 8); mean margin (Mine - Opponent) -106 VP
- The side that went first won 2 of 7 games with a winner
- Points traded per game (both sides' losses): 978
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: h8-mine-6ec093a-p1

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.9 | +0.0 | 0.0 | 0.0 | 1.1 | +0.0 | 0.0 | 0.0 |
| ALREADY CARRIED | 0.2 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARTILLERY RE-ROLL WEIGHED | 2.2 | +0.0 | 0.0 | 46.2 | 0.6 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | 0.1 | +0.2 | 0.0 | 0.0 | 0.1 | +0.5 | 0.0 | 0.0 |
| BEST PRIZE | - | - | - | - | 0.2 | -1.6 | 8.1 | 0.0 |
| BLOWS WHERE AIMED | 0.1 | -14.8 | 23.1 | 0.0 | - | - | - | - |
| BOMBING RUN | - | - | - | - | 0.4 | +7.5 | 0.0 | 0.0 |
| CANNON PLAN MISSED | 0.6 | +0.0 | 153.1 | 0.0 | - | - | - | - |
| CANNON PLANNED TARGET | 3.4 | +93.9 | 393.1 | 73.8 | 4.9 | +4.8 | 34.8 | 40.0 |
| CANNON SIGHT KEPT | 0.4 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT COUNTER | 0.1 | -41.4 | 0.0 | 0.0 | - | - | - | - |
| CAST JOB | 0.2 | +2.2 | 0.0 | 21.2 | 0.2 | +2.0 | 0.0 | 0.0 |
| CASTER AWAY FROM SCREEN | 0.6 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.6 | +37.1 | 8.1 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | 1.2 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | 0.2 | +18.8 | 0.0 | 21.2 | 0.2 | +8.3 | 0.0 | 0.0 |
| CHAFF PASSED | 0.1 | -0.5 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CHARACTER GUNS | - | - | - | - | 1.2 | +0.0 | 0.0 | 0.0 |
| CHARGE LOSSES | 5.2 | -114.8 | 0.0 | 166.0 | 6.4 | -172.8 | 0.0 | 232.5 |
| CHARGE NOT DECLARED | 0.2 | +0.0 | 16.2 | 0.0 | 0.8 | +0.0 | 100.6 | 24.4 |
| CHARGE NOW FIRST | 1.0 | +0.0 | 50.6 | 19.5 | 1.9 | +0.0 | 227.6 | 24.4 |
| CHARGER SLAIN LOST | 0.4 | -1.9 | 15.0 | 6.5 | 0.1 | -0.7 | 0.0 | 0.0 |
| COMBAT PIVOT | 0.6 | +0.0 | 0.0 | 60.0 | 0.4 | +0.0 | 111.2 | 24.4 |
| CONVEYANCE SEARCH | 1.6 | +246.1 | 0.0 | 0.0 | 0.4 | +38.0 | 0.0 | 0.0 |
| COVER ONCE | 4.8 | -188.2 | 0.0 | 86.5 | 7.2 | -519.0 | 0.0 | 30.6 |
| DEPLOY BY FIGURES | 8.1 | +32.8 | 0.0 | 0.0 | 9.0 | +19.3 | 0.0 | 6.9 |
| EDGE GIVE GROUND | 0.1 | +15.7 | 23.1 | 0.0 | 0.1 | +0.2 | 10.6 | 0.0 |
| ELIXIR WORTH | - | - | - | - | 0.1 | +4.3 | 0.0 | 0.0 |
| ENGINEER BY LORE | 0.5 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| FALL BACK GOOD ORDER | 1.6 | +7.8 | 60.6 | 24.4 | 1.6 | +0.9 | 178.8 | 24.4 |
| FALLS SHORT | 9.1 | +176.8 | 0.0 | 96.6 | 14.1 | +199.8 | 0.0 | 174.1 |
| FEATURE BUFFS | 2.4 | +91.3 | 0.0 | 13.8 | 0.5 | +7.6 | 0.0 | 0.0 |
| FIGHT LIFT | - | - | - | - | 0.1 | +0.3 | 0.0 | 0.0 |
| FIGHT TO THE END | 0.5 | +4.4 | 31.2 | 6.5 | 0.9 | +115.1 | 220.5 | 24.4 |
| FIRE IN ORDER | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| FIVE ACTION | 40.8 | +2971.7 | 564.4 | 709.1 | 51.0 | +2584.9 | 488.2 | 542.1 |
| FLANK NOT WEIGHED | 4.8 | +0.0 | 0.0 | 134.6 | 4.4 | +0.0 | 0.0 | 0.0 |
| FOLLOW UP WEIGHED | 0.5 | +48.1 | 0.0 | 88.0 | 0.6 | +123.7 | 0.0 | 0.0 |
| FOUR ROUNDS | 2.8 | +132.5 | 96.9 | 109.9 | 2.6 | +325.8 | 313.2 | 24.4 |
| FRIEND CHARGES FIRST | 0.1 | -0.7 | 0.0 | 0.0 | - | - | - | - |
| FRIEND SHOOTS FIRST | 0.5 | -5.6 | 0.0 | 77.5 | 0.2 | -1.4 | 0.0 | 0.0 |
| GIVES UP | 0.4 | -1.4 | 0.0 | 79.0 | 0.4 | -4.2 | 49.4 | 0.0 |
| GROUND FLIERS | 0.1 | +2.8 | 0.0 | 0.0 | - | - | - | - |
| GUN FIGURES | 1.4 | +10.1 | 51.2 | 116.2 | 3.4 | +24.0 | 30.4 | 15.0 |
| HARD STAY DROPPED | 1.6 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| HE SHOOTS OR CHARGES | 3.2 | +0.0 | 0.0 | 88.6 | 1.9 | +0.0 | 0.0 | 66.9 |
| HIS CHARGE DENIED | 0.1 | +4.3 | 0.0 | 0.0 | 0.2 | +5.9 | 26.1 | 24.4 |
| HIS CHARGE LIST | 3.9 | +0.0 | 0.0 | 123.9 | 2.1 | +0.0 | 0.0 | 46.0 |
| HIS LEGAL MOVES | 2.9 | +0.0 | 0.0 | 103.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 1.8 | -28.4 | 0.0 | 0.0 | 0.6 | -7.7 | 0.0 | 6.9 |
| HIS ONE QUARTER | 2.0 | +0.0 | 0.0 | 21.2 | - | - | - | - |
| HIS RANDOM MOVE | 3.5 | +0.0 | 0.0 | 88.9 | 2.4 | +0.0 | 0.0 | 29.4 |
| HIS SHOT LIST | 19.2 | +521.4 | 0.0 | 256.8 | 20.0 | +647.8 | 0.0 | 305.2 |
| HIS TURN DENIED | 1.0 | +23.7 | 58.8 | 0.0 | 1.4 | +48.3 | 221.5 | 0.0 |
| HOLD ODDS | 13.1 | +0.0 | 0.0 | 40.6 | - | - | - | - |
| HOLDER ASSIGNMENT | 13.5 | +1341.4 | 0.0 | 40.6 | - | - | - | - |
| HOLDER AT DEPLOYMENT | - | - | - | - | 2.0 | +360.8 | 0.0 | 6.9 |
| HOLDS AMBUSHERS | 0.5 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 2.2 | -97.4 | 88.8 | 90.4 | 2.4 | -120.5 | 274.5 | 24.4 |
| HUNT IN PAIRS | - | - | - | - | 0.2 | +4.5 | 0.0 | 0.0 |
| IDLE COST | 7.6 | -83.7 | 0.0 | 110.9 | 8.4 | -123.7 | 0.0 | 140.2 |
| KEEP FALLS | 0.2 | +0.5 | 0.0 | 0.0 | 0.1 | +0.2 | 0.0 | 0.0 |
| KEEPS SCOUTS OR AMBUSH | - | - | - | - | 0.1 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 0.5 | +13.1 | 0.0 | 0.0 | 0.9 | +48.2 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 5.6 | +0.0 | 111.2 | 117.4 | 2.4 | +0.0 | 132.5 | 15.0 |
| LONE WIZARD KEPT IN | 1.2 | +77.2 | 0.0 | 0.0 | 0.4 | +40.8 | 0.0 | 0.0 |
| LONG SHOT | 0.1 | +2.4 | 6.9 | 0.0 | - | - | - | - |
| MAKE SURE TOGETHER | - | - | - | - | 0.1 | +0.8 | 0.0 | 0.0 |
| MANOEUVRE | 1.2 | +13.7 | 0.0 | 17.4 | 1.6 | +59.4 | 0.0 | 0.0 |
| MARCH AT ESCAPER | - | - | - | - | 0.1 | +0.0 | 0.0 | 0.0 |
| MARCH BY THE SUM | 0.1 | +0.8 | 0.0 | 72.5 | 0.1 | +4.9 | 0.0 | 0.0 |
| MARCH CHECK | 0.9 | +41.4 | 0.0 | 82.6 | 1.9 | +106.0 | 0.0 | 0.0 |
| MARCH OVER CASTS | 0.4 | +17.9 | 0.0 | 0.0 | 0.2 | +13.9 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 4.4 | +39.0 | 0.0 | 107.9 | 1.9 | +25.0 | 0.0 | 8.1 |
| MISSILES IN THE MOVE | 4.9 | +252.2 | 0.0 | 51.6 | 2.9 | +45.0 | 0.0 | 67.5 |
| MISSILES NEXT TURN | 5.8 | +153.7 | 0.0 | 134.8 | 3.9 | +36.2 | 0.0 | 67.5 |
| MODEL FACING | - | - | - | - | 1.0 | +223.6 | 0.0 | 0.0 |
| MOVE SPELL IN RANGE | 0.6 | +17.2 | 0.0 | 72.5 | 0.5 | +6.3 | 0.0 | 0.0 |
| MOVE SPELL NOT WORTH | 0.4 | -0.2 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 3.2 | -47.7 | 0.0 | 145.0 | 0.6 | -24.7 | 0.0 | 0.0 |
| MOVE SPELL SPOT | 0.4 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 2.8 | +215.0 | 0.0 | 94.6 | 2.5 | +439.8 | 0.0 | 0.0 |
| MOVES UNITS SPELL | 0.2 | +13.8 | 0.0 | 0.0 | 0.1 | +0.5 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 3.4 | +184.0 | 0.0 | 0.0 | 7.0 | +300.1 | 0.0 | 36.9 |
| NEXT CHARGE BY LIST | 3.6 | -137.2 | 0.0 | 139.0 | 3.2 | -71.4 | 10.6 | 0.0 |
| NEXT OBJECTIVE NEARER | 0.1 | -0.4 | 0.0 | 0.0 | 13.1 | -664.1 | 42.5 | 119.0 |
| NO DOUBLE ROUNDS | 1.8 | -59.9 | 48.1 | 37.4 | 2.0 | -95.3 | 269.6 | 0.0 |
| NOT TURNED | 0.2 | +0.0 | 0.0 | 21.2 | 0.2 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 0.9 | -1.1 | 0.0 | 0.0 | 0.1 | -0.1 | 0.0 | 0.0 |
| OFF BEST | 0.2 | -87.5 | 0.0 | 0.0 | 0.2 | -14.3 | 0.0 | 6.9 |
| ONE CHARGE A CHARGER | 2.0 | +0.0 | 0.0 | 87.8 | 1.9 | +0.0 | 0.0 | 20.4 |
| ONE FIGHT FORMULA | 4.6 | -53.7 | 0.0 | 122.2 | 3.5 | -88.8 | 0.0 | 0.0 |
| ONE OBJECTIVE FORMULA | 5.9 | +71.2 | 0.0 | 29.2 | 3.4 | -13.9 | 0.0 | 21.9 |
| ONE TARGET A SHOOTER | 16.2 | +291.6 | 0.0 | 266.1 | 19.5 | +383.8 | 0.0 | 294.8 |
| OPENS UP | 0.8 | +57.1 | 33.1 | 72.5 | 0.5 | +13.9 | 29.4 | 0.0 |
| OVERRUNS AWAY | 0.6 | +38.7 | 41.2 | 0.0 | 0.4 | +13.5 | 69.2 | 24.4 |
| PATHS CROSS | 3.8 | +88.6 | 0.0 | 38.9 | 4.4 | +112.4 | 0.0 | 6.9 |
| PERIAPT WORTH | - | - | - | - | 0.2 | +19.2 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.1 | -2.8 | 0.0 | 38.8 | - | - | - | - |
| PLAN RESULT | 35.8 | +605.0 | 261.9 | 827.6 | 44.9 | +774.5 | 300.2 | 777.0 |
| QUARTER ODDS | 7.6 | +970.5 | 301.2 | 55.0 | - | - | - | - |
| RANDOM MOVE BY FIGURES | 0.9 | +9.6 | 0.0 | 42.5 | 2.5 | +44.7 | 0.0 | 193.8 |
| REAL GROUND | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| REDIRECT BY WHAT IT STOPS | 0.2 | -2.6 | 0.0 | 21.2 | 0.5 | -4.9 | 0.0 | 6.9 |
| REDIRECT COUNTER | 1.9 | +47.2 | 0.0 | 35.1 | 1.2 | +34.8 | 0.0 | 19.8 |
| REDIRECT WEIGHED | 0.1 | +6.9 | 0.0 | 0.0 | 0.1 | +23.8 | 0.0 | 0.0 |
| REFORMS TO MEET IT | 0.6 | -42.4 | 0.0 | 6.5 | 0.4 | -7.7 | 0.0 | 0.0 |
| REFUSING RETIRES | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | 0.5 | +37.9 | 0.0 | 0.0 | 1.2 | +76.9 | 0.0 | 23.1 |
| RISK BY ARC | 2.6 | -31.8 | 89.4 | 109.9 | 1.6 | +4.3 | 199.5 | 24.4 |
| RISK BY HIS FIGURE | 11.1 | -67.1 | 0.0 | 384.0 | 12.0 | -93.0 | 0.0 | 182.6 |
| RISK ON THE WAY | 0.2 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| RUN DOWN | 1.4 | -11.0 | 33.1 | 17.9 | 1.5 | -9.6 | 126.4 | 24.4 |
| SCOUT SPOT | 0.2 | +2.2 | 0.0 | 0.0 | 0.2 | +1.0 | 0.0 | 0.0 |
| SCOUT WAITS | 0.2 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.1 | -20.1 | 0.0 | 0.0 | - | - | - | - |
| SEARCH SPOT | 4.5 | +174.1 | 0.0 | 15.5 | 6.6 | +249.3 | 0.0 | 29.4 |
| SELF MOVE SPELL | - | - | - | - | 0.8 | -1.6 | 0.0 | 0.0 |
| SET UP TOGETHER | 0.2 | +2.0 | 0.0 | 0.0 | 0.1 | +0.8 | 0.0 | 0.0 |
| SET-UP ANY TARGET | 0.1 | +12.8 | 0.0 | 0.0 | - | - | - | - |
| SET-UP MISSED | 0.1 | +4.2 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | - | - | - | - | 0.4 | +1.1 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.5 | +68.3 | 30.0 | 0.0 | 2.0 | +43.5 | 30.9 | 0.0 |
| SHORT GUN FORWARD | - | - | - | - | 0.4 | +0.0 | 0.0 | 0.0 |
| SHOT OR CHARGE | 0.4 | -3.8 | 36.2 | 11.4 | - | - | - | - |
| SHOT RISK POINTS | 9.6 | -72.2 | 0.0 | 213.5 | 12.2 | +38.4 | 0.0 | 297.9 |
| SHOTS IN THE MOVE | 10.1 | +256.7 | 0.0 | 236.2 | 18.9 | +302.0 | 0.0 | 93.1 |
| SPELL SETS UP CHARGE | 0.1 | +12.8 | 0.0 | 0.0 | - | - | - | - |
| SPELL WORTH | 0.8 | +4.9 | 0.0 | 0.0 | 1.6 | +16.1 | 67.5 | 67.5 |
| SPELLS IN THE FIGHT | 0.2 | -0.4 | 0.0 | 72.5 | 0.4 | +7.3 | 46.2 | 0.0 |
| STAND AND SHOOT | 0.5 | -2.2 | 18.1 | 11.4 | 0.5 | -5.0 | 116.2 | 0.0 |
| STANDS FOR A REASON | 0.4 | +0.0 | 0.0 | 10.1 | 0.8 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 13.9 | +0.0 | 467.5 | 205.6 | 17.5 | +0.0 | 136.2 | 125.6 |
| STAY WORTH | 12.9 | +5.7 | 393.1 | 207.5 | 17.2 | -92.0 | 56.0 | 74.4 |
| STUCK PIVOT | - | - | - | - | 0.5 | +0.0 | 0.0 | 52.5 |
| SUPPORT NARROWED | 0.6 | +0.0 | 6.9 | 19.5 | 0.9 | +0.0 | 139.9 | 24.4 |
| SURE REACH TOGETHER | 0.1 | +0.7 | 0.0 | 0.0 | - | - | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 3.4 | +0.0 | 0.0 | 38.9 | 4.2 | +0.0 | 0.0 | 6.9 |
| THE PROMISE ADDS | 0.1 | -1.6 | 0.0 | 0.0 | 0.2 | -11.2 | 0.0 | 0.0 |
| THE PROMISED MOVE | 0.8 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 0.0 |
| TIED UP BY THE SUM | 0.5 | +61.2 | 15.0 | 72.5 | 1.0 | +101.8 | 77.8 | 0.0 |
| TIME ON OUR SIDE | 18.1 | +326.3 | 24.4 | 310.6 | 16.5 | +225.5 | 0.0 | 41.1 |
| TWO OR MORE ARRIVE | 0.1 | +0.1 | 0.0 | 0.0 | - | - | - | - |
| WAITS AGAIN | 1.9 | +0.0 | 0.0 | 167.1 | 1.1 | +0.0 | 0.0 | 0.0 |
| WALK PROMISE | 0.2 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WAR ENGINE JOBS | 0.2 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 60.0 | 0.0 |
| WHO HITS BACK | 0.4 | +46.5 | 0.0 | 11.4 | - | - | - | - |
| WHOLE FIGHT | - | - | - | - | 0.1 | +7.7 | 0.0 | 0.0 |
| WHOLE FIGHT GAIN | 0.1 | +2.1 | 8.1 | 0.0 | - | - | - | - |
| WIDER SPREAD | 1.5 | -4.6 | 73.8 | 79.0 | 1.9 | -7.1 | 245.6 | 24.4 |
| WOUNDS ON THE RANKS | 1.5 | +59.3 | 0.0 | 0.0 | 0.9 | +43.1 | 0.0 | 0.0 |

### Rule changes: h8-mine-6ec093a-p1

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS SHOT LIST | 314 | 314 | 109 | 13.62 | +1704 | +15.6 |
| HOLDER ASSIGNMENT | 108 | 108 | 100 | 12.50 | +4903 | +49.0 |
| DEPLOY BY FIGURES | 137 | 137 | 90 | 11.25 | +1817 | +20.2 |
| SEARCH SPOT | 89 | 89 | 85 | 10.62 | +3387 | +39.9 |
| PATHS CROSS | 65 | 65 | 65 | 8.12 | +1609 | +24.7 |
| LEGAL CHARGES ONLY | 64 | 64 | 64 | 8.00 | +0 | +0.0 |
| FIVE ACTION | 734 | 733 | 58 | 7.25 | +1865 | +32.2 |
| TIME ON OUR SIDE | 277 | 255 | 56 | 7.00 | +168 | +3.0 |
| ONE TARGET A SHOOTER | 286 | 286 | 54 | 6.75 | +576 | +10.7 |
| SHOT RISK POINTS | 175 | 175 | 30 | 3.75 | +845 | +28.2 |
| MOVE TO CHARGE COMPUTED | 42 | 42 | 28 | 3.50 | +3493 | +124.7 |
| SHOTS IN THE MOVE | 232 | 219 | 27 | 3.38 | +544 | +20.2 |
| IDLE COST | 128 | 107 | 25 | 3.12 | +199 | +8.0 |
| ARTILLERY RE-ROLL WEIGHED | 23 | 23 | 23 | 2.88 | +0 | +0.0 |
| HARD STAY DROPPED | 21 | 21 | 21 | 2.62 | +0 | +0.0 |
| RANDOM MOVE BY FIGURES | 27 | 27 | 20 | 2.50 | +434 | +21.7 |
| COVER ONCE | 96 | 81 | 18 | 2.25 | +232 | +12.9 |
| MARCH CHECK | 22 | 22 | 18 | 2.25 | +659 | +36.6 |
| FOUR ROUNDS | 43 | 42 | 17 | 2.12 | +792 | +46.6 |
| ADVANCE LANE KEPT | 16 | 16 | 16 | 2.00 | +0 | +0.0 |
| SHOOTS FROM THE BEST SPOT | 28 | 28 | 16 | 2.00 | +179 | +11.2 |
| FALLS SHORT | 186 | 161 | 15 | 1.88 | +250 | +16.6 |
| RESERVE FALL BACK | 14 | 14 | 14 | 1.75 | +918 | +65.6 |
| CANNON PLANNED TARGET | 66 | 66 | 13 | 1.62 | -9 | -0.7 |
| LONE WIZARD KEPT IN | 13 | 13 | 13 | 1.62 | +944 | +72.7 |
| LANE BY FIGURES | 11 | 11 | 11 | 1.38 | +490 | +44.6 |
| MAX FOR POSITIONING | 50 | 48 | 11 | 1.38 | +31 | +2.8 |
| HOLDER AT DEPLOYMENT | 16 | 16 | 10 | 1.25 | +504 | +50.4 |
| MISSILES IN THE MOVE | 62 | 41 | 10 | 1.25 | +482 | +48.1 |
| TIED UP BY THE SUM | 12 | 11 | 10 | 1.25 | +260 | +26.0 |
| FOLLOW UP WEIGHED | 9 | 9 | 9 | 1.12 | +1375 | +152.8 |
| MANOEUVRE | 23 | 23 | 9 | 1.12 | +590 | +65.5 |
| NEXT OBJECTIVE NEARER | 106 | 106 | 9 | 1.12 | +167 | +18.6 |
| RISK BY ARC | 34 | 33 | 9 | 1.12 | +213 | +23.7 |
| CANNON SIGHT KEPT | 8 | 8 | 8 | 1.00 | +0 | +0.0 |
| CHARGE NOT DECLARED | 8 | 8 | 8 | 1.00 | -1509 | -188.6 |
| COMBAT PIVOT | 8 | 8 | 8 | 1.00 | +0 | +0.0 |
| MODEL FACING | 8 | 8 | 8 | 1.00 | +1789 | +223.6 |
| STAY WORTH | 241 | 235 | 8 | 1.00 | +108 | +13.6 |
| HOLDS AMBUSHERS | 7 | 7 | 7 | 0.88 | +0 | +0.0 |
| NEARER NOT NEEDED | 83 | 80 | 7 | 0.88 | +250 | +35.8 |
| QUARTER ODDS | 61 | 60 | 7 | 0.88 | +918 | +131.2 |
| CASTER AWAY FROM SCREEN | 6 | 6 | 6 | 0.75 | +0 | +0.0 |
| OPENS UP | 10 | 10 | 6 | 0.75 | +323 | +53.9 |
| REDIRECT COUNTER | 25 | 19 | 6 | 0.75 | +246 | +41.0 |
| WOUNDS ON THE RANKS | 19 | 19 | 6 | 0.75 | +187 | +31.2 |
| CHARGE LOSSES | 93 | 93 | 5 | 0.62 | +393 | +78.5 |
| FEATURE BUFFS | 23 | 23 | 5 | 0.62 | +148 | +29.6 |
| CASTING BLOCK | 5 | 5 | 4 | 0.50 | +19 | +4.6 |
| CHAFF IN THE MOVE | 4 | 4 | 4 | 0.50 | +0 | +0.0 |
| CHARGE NOW FIRST | 23 | 23 | 4 | 0.50 | -53 | -13.2 |
| HIS TURN DENIED | 19 | 19 | 4 | 0.50 | +190 | +47.6 |
| OFF BEST | 4 | 4 | 4 | 0.50 | -814 | -203.6 |
| OVERRUNS AWAY | 8 | 8 | 4 | 0.50 | +31 | +7.9 |
| SCOUT WAITS | 4 | 4 | 4 | 0.50 | +0 | +0.0 |
| STUCK PIVOT | 4 | 4 | 4 | 0.50 | +0 | +0.0 |
| BOMBING RUN | 3 | 3 | 3 | 0.38 | +60 | +19.9 |
| FIGHT TO THE END | 11 | 10 | 3 | 0.38 | +354 | +118.0 |
| FIRE IN ORDER | 3 | 3 | 3 | 0.38 | +0 | +0.0 |
| KEEP FALLS | 3 | 3 | 3 | 0.38 | +36 | +11.8 |
| MOVES UNITS SPELL | 3 | 3 | 3 | 0.38 | +114 | +38.2 |
| NEXT CHARGE BY LIST | 55 | 55 | 3 | 0.38 | +4 | +1.3 |
| ONE OBJECTIVE FORMULA | 74 | 49 | 3 | 0.38 | +150 | +49.9 |
| RISK BY HIS FIGURE | 185 | 185 | 3 | 0.38 | +124 | +41.4 |
| SHOOTERS IN TWO RANKS | 3 | 3 | 3 | 0.38 | +9 | +3.0 |
| SHORT GUN FORWARD | 3 | 3 | 3 | 0.38 | +0 | +0.0 |
| SUPPORT NARROWED | 12 | 12 | 3 | 0.38 | -89 | -29.8 |
| WHO HITS BACK | 3 | 3 | 3 | 0.38 | +215 | +71.8 |
| BEST PRIZE | 2 | 2 | 2 | 0.25 | -13 | -6.5 |
| CHAFF PASSED | 2 | 2 | 2 | 0.25 | -4 | -2.0 |
| HONEST WORTH | 37 | 36 | 2 | 0.25 | +23 | +11.7 |
| MARCH BY THE SUM | 2 | 2 | 2 | 0.25 | +46 | +22.9 |
| ONE FIGHT FORMULA | 65 | 33 | 2 | 0.25 | +7 | +3.5 |
| PERIAPT WORTH | 2 | 2 | 2 | 0.25 | +153 | +76.7 |
| REDIRECT WEIGHED | 2 | 2 | 2 | 0.25 | +290 | +144.8 |
| REFUSING RETIRES | 3 | 3 | 2 | 0.25 | -1 | -0.3 |
| CARRIES OUT COUNTER | 1 | 1 | 1 | 0.12 | -331 | -331.1 |
| EDGE GIVE GROUND | 2 | 2 | 1 | 0.12 | +107 | +107.3 |
| ELIXIR WORTH | 1 | 1 | 1 | 0.12 | +34 | +34.3 |
| GIVES UP | 6 | 6 | 1 | 0.12 | +5 | +5.0 |
| HIS MOVE AND SHOT | 19 | 19 | 1 | 0.12 | +0 | +0.0 |
| KEEPS SCOUTS OR AMBUSH | 1 | 1 | 1 | 0.12 | +0 | +0.0 |
| LONG SHOT | 1 | 1 | 1 | 0.12 | +10 | +10.4 |
| MISSILES NEXT TURN | 77 | 53 | 1 | 0.12 | +2 | +1.7 |
| NO DOUBLE ROUNDS | 30 | 29 | 1 | 0.12 | +20 | +20.4 |
| PIVOT GUARDS FLANK | 1 | 1 | 1 | 0.12 | -22 | -22.4 |
| REDIRECT BY WHAT IT STOPS | 6 | 6 | 1 | 0.12 | +86 | +85.6 |
| SET UP TOGETHER | 3 | 3 | 1 | 0.12 | +8 | +8.5 |
| SPELLS IN THE FIGHT | 5 | 5 | 1 | 0.12 | +6 | +5.5 |
| SURE REACH TOGETHER | 1 | 1 | 1 | 0.12 | +1 | +0.9 |
| WAR ENGINE JOBS | 10 | 10 | 1 | 0.12 | -3 | -3.2 |
| WHOLE FIGHT GAIN | 1 | 1 | 1 | 0.12 | +14 | +13.8 |
| ALREADY CARRIED | 2 | not checked | - | - | - | - |
| BACKUP TARGETS | 2 | not checked | - | - | - | - |
| BLOWS WHERE AIMED | 1 | 1 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 5 | 5 | 0 | 0.00 | - | - |
| CAST JOB | 4 | 4 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 10 | trace | - | - | - | - |
| CHARACTER GUNS | 10 | 10 | 0 | 0.00 | - | - |
| CHARGER SLAIN LOST | 4 | 4 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 16 | not checked | - | - | - | - |
| ENGINEER BY LORE | 6 | 6 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 26 | 25 | 0 | 0.00 | - | - |
| FIGHT LIFT | 1 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 73 | not checked | - | - | - | - |
| FRIEND CHARGES FIRST | 1 | 1 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 6 | 6 | 0 | 0.00 | - | - |
| GROUND FLIERS | 1 | not checked | - | - | - | - |
| GUN FIGURES | 38 | not checked | - | - | - | - |
| HE SHOOTS OR CHARGES | 41 | 41 | 0 | 0.00 | - | - |
| HIS CHARGE DENIED | 3 | 3 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 48 | 48 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 47 | 47 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 16 | 16 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 47 | 47 | 0 | 0.00 | - | - |
| HOLD ODDS | 105 | 105 | 0 | 0.00 | - | - |
| HUNT IN PAIRS | 2 | 1 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 1 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 5 | 5 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 9 | 7 | 0 | 0.00 | - | - |
| MOVE SPELL NOT WORTH | 3 | not checked | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 31 | trace | - | - | - | - |
| MOVE SPELL SPOT | 3 | not checked | - | - | - | - |
| NOT TURNED | 4 | 4 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 8 | not checked | - | - | - | - |
| ONE CHARGE A CHARGER | 31 | 31 | 0 | 0.00 | - | - |
| PLAN RESULT | 645 | trace | - | - | - | - |
| REAL GROUND | 1 | 1 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 8 | 8 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 2 | 2 | 0 | 0.00 | - | - |
| RUN DOWN | 23 | 22 | 0 | 0.00 | - | - |
| SCOUT SPOT | 4 | 4 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 1 | 1 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 6 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 1 | not checked | - | - | - | - |
| SET-UP MISSED | 1 | trace | - | - | - | - |
| SHOT OR CHARGE | 3 | 3 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 1 | not checked | - | - | - | - |
| SPELL WORTH | 19 | not checked | - | - | - | - |
| STAND AND SHOOT | 8 | 8 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 9 | 9 | 0 | 0.00 | - | - |
| STANDS STILL | 251 | 251 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 61 | not checked | - | - | - | - |
| THE PROMISE ADDS | 3 | 3 | 0 | 0.00 | - | - |
| THE PROMISED MOVE | 9 | not checked | - | - | - | - |
| TWO OR MORE ARRIVE | 1 | not checked | - | - | - | - |
| WAITS AGAIN | 24 | 24 | 0 | 0.00 | - | - |
| WALK PROMISE | 2 | 2 | 0 | 0.00 | - | - |
| WHOLE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| WIDER SPREAD | 27 | 26 | 0 | 0.00 | - | - |

### Off best figure: h8-mine-6ec093a-p1

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| CHARGE NOT DECLARED | rule | 0.12 | 0.75 | 215.6 |
| HOLDER ASSIGNMENT | rule | 0.88 | - | 20.2 |
| PATHS CROSS | rule | 0.12 | 0.50 | 31.2 |
| CHARGE NOW FIRST | rule | 0.12 | 0.38 | 13.2 |
| SUPPORT NARROWED | rule | 0.12 | 0.25 | 29.8 |
| BEST PRIZE | rule | - | 0.25 | 6.5 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.12 | - | 48.8 |
| CANNON PLANNED TARGET | rule | 0.12 | - | 9.7 |
| CARRIES OUT COUNTER | rule | 0.12 | - | 331.1 |
| CHAFF PASSED | rule | 0.12 | - | 3.9 |
| JOB FIRST | gate | - | 0.12 | 20.6 |
| NO REASON | gate | 0.12 | - | 651.4 |
| PIVOT GUARDS FLANK | rule | 0.12 | - | 22.4 |
| RULE SWITCHED OFF | gate | - | 0.12 | 93.7 |
| WAR ENGINE JOBS | rule | - | 0.12 | 3.2 |

### Plans: h8-mine-6ec093a-p1

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 2.2 | 50% | 215 | 127 | 59% |
| Mine | move | 26.2 | 95% | 1724 | 0 | 0% |
| Mine | shoot | 6.8 | 50% | 349 | 484 | 139% |
| Mine | support | 0.4 | 33% | 0 | 0 | - |
| Opponent | charge | 2.4 | 74% | 452 | 298 | 66% |
| Opponent | move | 32.5 | 91% | 1611 | 0 | 0% |
| Opponent | shoot | 9.5 | 64% | 167 | 477 | 285% |
| Opponent | support | 0.5 | 100% | 20 | 0 | 0% |

### Battle groups: h8-mine-6ec093a-p1

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 1.9 | 20% | 100% | 0% | - | 0% | 0% | 0% | 100% | 0% |
| Opponent | REDIRECT COUNTER | 1.2 | 30% | 100% | 0% | - | 0% | 0% | 67% | 33% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: h8-mine-6ec093a-p1

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 6 | 35 (6) | 0 | 35 | 24 | 67% | 2.0 | - | 35 (6) | - | 48 (4) | 0 (2) |
| Mine | Character | 27 | 33 (27) | 33 | 0 | 11 | 26% | 2.4 | 45 (13) | 16 (9) | 34 (5) | 26 (21) | 44 (6) |
| Mine | Clean-up | 5 | 79 (5) | 49 | 30 | 87 | 40% | 2.7 | 128 (2) | 40 (3) | - | 80 (4) | 75 (1) |
| Mine | Fast Hammer | 8 | 11 (8) | 6 | 5 | 86 | 25% | 3.2 | - | 20 (5) | 0 (3) | 23 (2) | 7 (6) |
| Mine | Hammer | 19 | 28 (19) | 4 | 23 | 31 | 37% | 3.3 | 83 (3) | 18 (10) | 8 (6) | 40 (10) | 11 (9) |
| Mine | Holder | 12 | 85 (12) | 0 | 85 | 20 | 75% | 2.0 | 167 (2) | 61 (6) | 99 (3) | 80 (6) | 103 (5) |
| Mine | Shooter | 2 | 346 (2) | 0 | 346 | 0 | 0% | 1.5 | - | 554 (1) | 138 (1) | 346 (2) | - |
| Mine | War machine | 8 | 58 (8) | 58 | 0 | 41 | 0% | 1.4 | 64 (7) | - | 0 (1) | 0 (1) | 64 (7) |
| Mine | Wizard | 7 | 7 (7) | 7 | 0 | 27 | 14% | 4.2 | 13 (4) | 0 (1) | 0 (2) | 0 (2) | 10 (5) |
| Opponent | Chaff | 10 | 38 (10) | 4 | 34 | 43 | 30% | 2.1 | 20 (5) | 61 (4) | 0 (1) | 41 (8) | 25 (2) |
| Opponent | Character | 20 | 48 (20) | 48 | 0 | 14 | 25% | 2.3 | 29 (7) | 43 (9) | 96 (4) | 65 (8) | 32 (12) |
| Opponent | Clean-up | 8 | 140 (8) | 86 | 54 | 27 | 75% | 3.5 | 0 (1) | 151 (6) | 237 (1) | 106 (5) | 165 (3) |
| Opponent | Fast | 1 | 232 (1) | 232 | 0 | 0 | 0% | 1.0 | - | 232 (1) | - | 232 (1) | - |
| Opponent | Fast Hammer | 3 | 53 (3) | 19 | 34 | 27 | 0% | 2.0 | - | 26 (2) | 128 (1) | - | 53 (3) |
| Opponent | Fragile | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | - | - | - | - |
| Opponent | Hammer | 18 | 35 (18) | 20 | 15 | 26 | 44% | 2.6 | 0 (3) | 44 (13) | 13 (2) | 13 (12) | 79 (6) |
| Opponent | Holder | 13 | 91 (13) | 0 | 91 | 23 | 62% | 2.8 | 116 (8) | 28 (3) | 98 (2) | 130 (7) | 51 (6) |
| Opponent | Shooter | 11 | 29 (11) | 0 | 29 | 26 | 9% | 1.6 | 0 (2) | 33 (9) | - | 97 (4) | 0 (7) |
| Opponent | War machine | 10 | 0 (10) | 0 | 0 | 37 | 10% | 1.4 | - | 0 (4) | 0 (6) | 0 (1) | 0 (9) |
| Opponent | Wizard | 4 | 3 (4) | 3 | 0 | 16 | 25% | 1.7 | 0 (1) | 4 (2) | - | 0 (1) | 4 (2) |

### Charged fights: h8-mine-6ec093a-p1

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 217 | 16 | 1.2 | 1.2 | 13 | 21 | -8 | 2 of 5 | 2 of 5 | +65 | -26 |
| Mine | Chaos Dwarfs | 4 | 299 | 232 | 2.8 | 1.0 | 85 | 61 | +24 | 1 of 11 | 10 of 11 | - | +24 |
| **Mine** | all armies | 8 | 258 | 124 | 2.0 | 1.1 | 62 | 48 | +14 | 3 of 16 | 12 of 16 | +65 | +10 |
| Opponent | Chaos Dwarfs | 3 | 119 | 208 | 2.3 | 1.0 | 89 | 0 | +89 | 5 of 7 | 6 of 7 | - | +89 |
| Opponent | Dwarfen Mountain Holds | 1 | 139 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Orc & Goblin Tribes | 1 | 0 | 503 | 5.0 | 1.0 | 101 | 0 | +101 | 0 of 5 | 5 of 5 | - | +101 |
| Opponent | Skaven | 2 | 155 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 2 of 2 | 0 of 1 | - | +0 |
| Opponent | Tomb Kings of Khemri | 1 | 0 | 809 | 5.0 | 1.2 | 162 | 39 | +123 | 2 of 5 | 3 of 5 | +310 | +76 |
| **Opponent** | all armies | 8 | 101 | 242 | 2.4 | 1.1 | 102 | 10 | +92 | 9 of 19 | 14 of 18 | +310 | +80 |

### Effective charges: h8-mine-6ec093a-p1

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 5 | 2 (net -52) | 0 | 1 (net +0) | 1 (net +0) | 0 | 1 (net +65) | 0 | 20% (1 of 5) |
| Mine | Chaos Dwarfs | 11 | 2 (net +230) | 0 | 1 (net +0) | 2 (net +102) | 4 (net -115) | 2 (net +27) | 0 | 9% (1 of 11) |
| Opponent | Chaos Dwarfs | 7 | 1 (net +0) | 0 | 0 | 3 (net +152) | 0 | 2 (net +85) | 1 | 0% (0 of 6) |
| Opponent | Orc & Goblin Tribes | 5 | 0 | 0 | 0 | 0 | 3 (net +140) | 0 | 2 | 0% (0 of 3) |
| Opponent | Skaven | 2 | 2 (net +0) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 2) |
| Opponent | Tomb Kings of Khemri | 5 | 1 (net +239) | 0 | 1 (net +310) | 0 | 1 (net +65) | 2 (net +0) | 0 | 20% (1 of 5) |

### Charged fights, damage counted: h8-mine-6ec093a-p1

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 4 | 231 | 280 | +89 | 151 | 26 | +125 | +54.3 |
| Mine | Effective (55-75%) | 2 | 266 | 87 | +0 | 4 | 13 | -9 | -3.2 |
| Mine | 76-89% | 3 | 254 | 88 | +68 | 78 | 16 | +62 | +24.5 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 | 190 | 118 | +40 | 118 | 44 | +73 | +38.4 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 4 | 367 | 70 | -115 | 42 | 145 | -103 | -28.2 |
| Mine | All fights | 16 | 266 | 137 | +14 | 86 | 56 | +30 | +11.2 |
| Opponent | Long shot (under 50%) | 4 | 192 | 254 | +60 | 127 | 95 | +33 | +17.1 |
| Opponent | Effective (55-75%) | 1 | 871 | 310 | +310 | 310 | 0 | +310 | +35.6 |
| Opponent | 76-89% | 3 | 433 | 152 | +152 | 152 | 0 | +152 | +35.0 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 4 | 361 | 228 | +42 | 58 | 53 | +4 | +1.1 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 4 | 372 | 79 | +122 | 122 | 0 | +122 | +32.6 |
| Opponent | No odds | 3 | 246 | 131 | +27 | 27 | 0 | +27 | +11.1 |
| Opponent | All fights | 19 | 348 | 179 | +92 | 109 | 31 | +78 | +22.4 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| h8-mine-6ec093a-p1 | move | 50 | 12 (24%) | 12 (24%) | 6 (12%) | 32 (64%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0103, L0120 |
| Elixir of Power | Opponent | L0219 |
| Periapt of Soul Exchange | Opponent | L0120, L0321 |
| Ring of Doom | Mine | L0204, L0219 |
| Storm Daemon (Renegade 2.0) | Opponent | L0321 |

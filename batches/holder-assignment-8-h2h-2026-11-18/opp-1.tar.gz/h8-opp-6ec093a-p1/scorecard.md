# Doctrine scorecard: h8-opp-6ec093a-p1

### Scorecard: h8-opp-6ec093a-p1

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0103 | 1 | 1 | Mine | no | 4 | - | 0 | 2 | 0 | 0 | 0 | 0 |
| L0103 | 1 | 1 | Opponent | no | 0 | - | 0 | 0 | 0 | 0 | 0 | 445 |
| L0120 | 6 | 1 | Mine | no | 7 | - | 0 | 2 | 0 | 0 | 0 | 0 |
| L0120 | 6 | 1 | Opponent | no | 0 | - | 1 | 3 | 0 | 0 | 0 | 0 |
| L0204 | 6 | 1 | Mine | no | 6 | 4 | 0 | 3 | 0 | 0 | 0 | 0 |
| L0204 | 6 | 1 | Opponent | no | 4 | 1 | 1 | 0 | 0 | 0 | 0 | 0 |
| L0219 | 3 | 1 | Mine | yes | 0 | 2 | 4 | 1 | 0 | 0 | 0 | 170 |
| L0219 | 3 | 1 | Opponent | yes | 8 | 2 | 1 | 0 | 1 | 0 | 0 | 0 |
| L0304 | 4 | 1 | Mine | no | 0 | 5 | 1 | 0 | 0 | 0 | 0 | 0 |
| L0304 | 4 | 1 | Opponent | no | 3 | 2 | 4 | 2 | 0 | 0 | 0 | 112 |
| L0321 | 3 | 1 | Mine | no | 6 | 3 | 4 | 1 | 0 | 0 | 0 | 225 |
| L0321 | 3 | 1 | Opponent | yes | 7 | - | 0 | 4 | 1 | 0 | 0 | 500 |
| L0406 | 4 | 1 | Mine | no | 0 | 3 | 2 | 3 | 0 | 0 | 0 | 0 |
| L0406 | 4 | 1 | Opponent | no | 0 | 4 | 2 | 0 | 1 | 0 | 0 | 413 |
| L0423 | 3 | 1 | Mine | no | 8 | 2 | 4 | 2 | 0 | 0 | 0 | 139 |
| L0423 | 3 | 1 | Opponent | no | 4 | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| L0510 | 6 | 1 | Mine | no | 6 | - | 0 | 2 | 0 | 0 | 0 | 350 |
| L0510 | 6 | 1 | Opponent | no | 6 | 2 | 1 | 2 | 0 | 0 | 0 | 330 |
| L0525 | 3 | 1 | Mine | no | 10 | - | 0 | 2 | 0 | 0 | 0 | 383 |
| L0525 | 3 | 1 | Opponent | no | 4 | 2 | 6 | 3 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 10% | 4.7 | 3.2 | 1.5 | 1.8 | 0.0 | 0.0 | 0.0 | 126.7 |
| **Average** | | | Opponent | 20% | 3.6 | 2.1 | 1.8 | 1.5 | 0.3 | 0.0 | 0.0 | 180.0 |

### KPIs: h8-opp-6ec093a-p1

Rules off - Mine only: HOLDER ASSIGNMENT, QUARTER ODDS, WALK PROMISE, REAL GROUND, RISK ON THE WAY.

Morten 2026-11-10; 10 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 37% (15 of 41) | 17% (8 of 46) | 26% (23 of 87) |
| Winner chose to follow up after the loser gave ground |  | 75% (9 of 12); on the table 75% | 82% (9 of 11); on the table 91% | 78% (18 of 23); on the table 83% |
| Winner chose to pursue after the loser fell back in good order |  | 100% (2 of 2); on the table 100% | 100% (1 of 1); on the table 100% | 100% (3 of 3); on the table 100% |
| Winner chose to pursue after the loser fled |  | 45% (5 of 11); on the table 55% | 50% (2 of 4); on the table 50% | 47% (7 of 15); on the table 53% |
| Winner chose to follow up or pursue (all three) |  | 64% (16 of 25); on the table 68% | 75% (12 of 16); on the table 81% | 68% (28 of 41); on the table 73% |
| Magic missiles tried each own turn | 50%+ | 36% (50 of 138) | 33% (26 of 78) | 35% (76 of 216) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 41% (50 of 122) | 44% (26 of 59) | 42% (76 of 181) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 64% (7 of 11) | 65% (11 of 17) | 64% (18 of 28) |
| Points that never fought | lower | 47% (8779 of 18788) | 58% (11524 of 19993) | 52% (20303 of 38781) |
|   infantry points that never fought | lower | 64% (3489 of 5442) | 82% (3829 of 4683) | 72% (7318 of 10125) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 56% (37 of 66) | 62% (49 of 79) | 59% (86 of 145) |
| Bound items with a magic missile used (at least once a game) |  | 100% (6 of 6); 1.3 uses a game | 67% (2 of 3); 0.4 uses a game | 89% (8 of 9); 0.8 uses a game |
| Bound items with another spell used |  | 100% (2 of 2); 1.0 uses a game | 0% (0 of 1); 0.0 uses a game | 67% (2 of 3); 0.5 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 88% (7 of 8); 0.7 uses a game | 40% (2 of 5); 0.2 uses a game | 69% (9 of 13); 0.5 uses a game |
|   their share of the points of units over 100 pts | lower | 50% (7018 of 14152) | 56% (9554 of 17156) | 53% (16572 of 31308) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 4.4 (50%) | 1.9 (37%) | 6.3 (45%) |
| MARCHED: its unit marched | 2.2 (25%) | 1.2 (23%) | 3.4 (24%) |
| CHARGED: its unit charged | 0.2 (2%) | 0.2 (4%) | 0.4 (3%) |
| IN COMBAT: engaged in combat | 1.1 (12%) | 1.5 (29%) | 2.6 (19%) |
| FLEEING: fleeing | 0.0 (0%) | 0.1 (2%) | 0.1 (1%) |
| GONE: slain | 0.5 (6%) | 0.1 (2%) | 0.6 (4%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (0%) | 0.2 (4%) | 0.2 (1%) |
| STUPIDITY: Stupidity | 0.4 (5%) | 0.0 (0%) | 0.4 (3%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 5.3 | 0.7 | 2.5 | 7.6 | 0.9 | 1.1 |
| not cast | 2.5 | 1.1 | 5.3 | 14.0 | 2.7 | 20.5 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.4 (2%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.6 (55%) | 1.5 (28%) | 6.3 (45%) | 0.3 (11%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 3.4 (24%) | 0.6 (22%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.4 (3%) | 0.1 (4%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.3 (12%) | 0.0 (0%) | 0.7 (13%) | 2.6 (19%) | 0.6 (22%) | 0.0 (0%) |
| NO CASTS LEFT: every cast used on other spells | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (4%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (0%) | 0.0 (0%) | 0.1 (2%) | 0.1 (1%) | 0.0 (0%) | 0.3 (1%) |
| GONE: slain | 0.1 (4%) | 0.0 (0%) | 0.1 (2%) | 0.6 (4%) | 0.4 (15%) | 0.7 (3%) |
| OFF THE TABLE: off the table or not arrived | 0.2 (8%) | 0.1 (9%) | 0.2 (4%) | 0.2 (1%) | 0.0 (0%) | 0.4 (2%) |
| STUPIDITY: Stupidity | 0.2 (8%) | 0.0 (0%) | 0.1 (2%) | 0.4 (3%) | 0.1 (4%) | 0.4 (2%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.5 (19%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.7 (68%) | 0.4 (36%) | 2.6 (49%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 18.3 (89%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 2.8 a game | 0.7 a game | 1.8 a game |
| stood (cast and not dispelled) | 61% (17 of 28) | 43% (3 of 7) | 57% (20 of 35) |
| the unit moved after it | 47% (8 of 17) | 100% (3 of 3) | 55% (11 of 20) |
| it charged on its next turn | 0% (0 of 17) | 0% (0 of 3) | 0% (0 of 20) |
| the enemy charged it first | 6% (1 of 17) | 0% (0 of 3) | 5% (1 of 20) |
| it fought by the end of its next turn | 6% (1 of 17) | 0% (0 of 3) | 5% (1 of 20) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 17) | 0% (0 of 3) | 0% (0 of 20) |
| none of these (no charge, no fight, no charge escaped) | 94% (16 of 17) | 100% (3 of 3) | 95% (19 of 20) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 63% (131 of 208) | 65% (141 of 217) | 64% (272 of 425) |
|   cavalry | 60% (6 of 10) | 68% (17 of 25) | 66% (23 of 35) |
|   character | 79% (23 of 29) | 36% (4 of 11) | 68% (27 of 40) |
|   chariot | 42% (14 of 33) | 50% (28 of 56) | 47% (42 of 89) |
|   infantry | 45% (20 of 44) | 65% (44 of 68) | 57% (64 of 112) |
|   monster | - | 100% (3 of 3) | 100% (3 of 3) |
|   war machine | 74% (68 of 92) | 83% (45 of 54) | 77% (113 of 146) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.3 (30%) | 2.2 (29%) | 4.5 (29%) |
| CHARGED: it charged | 0.3 (4%) | 1.0 (13%) | 1.3 (8%) |
| FLEEING: it fled or was fleeing | 0.5 (6%) | 0.0 (0%) | 0.5 (3%) |
| IN COMBAT: it fought this turn or the last | 0.9 (12%) | 0.4 (5%) | 1.3 (8%) |
| MOVED: a war machine that moved | 1.4 (18%) | 0.1 (1%) | 1.5 (10%) |
| NO TARGET IN RANGE | 1.4 (18%) | 1.9 (25%) | 3.3 (22%) |
| ONLY IN COMBAT: the only targets were in combat | 0.1 (1%) | 0.4 (5%) | 0.5 (3%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.1 (1%) | 1.0 (13%) | 1.1 (7%) |
| SHELTERED: the target was sheltered | 0.1 (1%) | 0.1 (1%) | 0.2 (1%) |
| OTHER BAR | 0.6 (8%) | 0.5 (7%) | 1.1 (7%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 2.3 | 0.4 | 83% | 2.8 pts | 6 pts |
| character | 3.0 | 2.4 | 53% | 14.9 pts | 45 pts |
| chariot | 4.5 | 5.1 | 49% | 17.9 pts | 81 pts |
| infantry | 9.5 | 3.8 | 72% | 8.2 pts | 78 pts |
| monster | 0.3 | 0.0 | 100% | 0.0 pts | 0 pts |
| war machine | 11.3 | 8.4 | 68% | 16.8 pts | 190 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 2.5 | 4.1 | 3.3 |
| Charges that made contact a game | 2.0 | 3.2 | 2.6 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.50 declared, 0.50 contact (6 units) | 1.10 declared, 1.00 contact (10 units) | 0.88 declared, 0.81 contact (16 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 2.00 declared, 2.00 contact (1 units) | 2.00 declared, 2.00 contact (1 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.37 declared, 0.28 contact (60 units) | 0.36 declared, 0.26 contact (78 units) | 0.36 declared, 0.27 contact (138 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 33% (2 of 6) | 100% (3 of 3) | - | 56% (5 of 9) |
| Character in a unit | 71% (10 of 14) | 56% (5 of 9) | - | 65% (15 of 23) |
| Character on its own | 92% (11 of 12) | 56% (5 of 9) | 18% (2 of 11) | 56% (18 of 32) |
| Chariot | 100% (3 of 3) | 50% (6 of 12) | - | 60% (9 of 15) |
| Infantry | 48% (11 of 23) | 40% (6 of 15) | - | 45% (17 of 38) |
| Monster | 80% (4 of 5) | 67% (2 of 3) | - | 75% (6 of 8) |
| Monstrous | - | 50% (1 of 2) | - | 50% (1 of 2) |
| War Machines | 80% (12 of 15) | 100% (3 of 3) | - | 83% (15 of 18) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 50% (4 of 8); on the table 62% | 30% (31 of 102) | 45% | 50% (11 of 22) | 100% (6 of 6); 3.2 uses a game | 100% (2 of 2); 2.5 uses a game | 100% (6 of 6); 1.5 uses a game |
| Chaos Dwarfs | 7 | 70% (14 of 20); on the table 70% | 50% (30 of 60) | 55% | 54% (29 of 54) | 0.0 uses a game | 0.0 uses a game | 33% (1 of 3); 0.1 uses a game |
| Dwarfen Mountain Holds | 3 | 67% (2 of 3); on the table 67% | - | 59% | 71% (17 of 24) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Grand Cathay | 1 | - | 23% (7 of 30) | 48% | 40% (4 of 10) | 50% (1 of 2); 1.0 uses a game | 0% (0 of 1); 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Orc & Goblin Tribes | 1 | - | 17% (1 of 6) | 0% | 62% (5 of 8) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Skaven | 2 | 75% (3 of 4); on the table 100% | 42% (5 of 12) | 82% | 75% (12 of 16) | 100% (1 of 1); 1.5 uses a game | 0.0 uses a game | 100% (2 of 2); 1.0 uses a game |
| Tomb Kings of Khemri | 1 | 75% (3 of 4); on the table 75% | - | 30% | 60% (3 of 5) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 1 | 100% (2 of 2); on the table 100% | 33% (2 of 6) | 61% | 83% (5 of 6) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (h8-opp-6ec093a-p1, 10 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 41% (9) | 38% (5) | 40% (14) |
| ...free all their last turn and able to turn (per game) | 0.30 | 0.40 | 0.70 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.40 | 0.00 | 0.40 |
| ...with the charger already in that arc before they moved (per game) | 0.30 | 0.20 | 0.50 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: h8-opp-6ec093a-p1

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.7 | 1.9 |
| Strategy | Charge objectives carried out (made contact) | 71% (17 of 24) | 63% (22 of 35) |
| Strategy | Shoot objectives carried out (shot that target) | 35% (42 of 120) | 46% (47 of 103) |
| Strategy | Support requests answered (helper made contact too) | 67% (2 of 3) | 50% (1 of 2) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | - | 100% (5 of 5) |
| Strategy | Hexes on a unit its side charged or shot that turn | - | 67% (2 of 3) |
| Strategy | Joined characters whose unit fought | 41% (12 of 29) | 11% (1 of 9) |
| Strategy | Lone characters that fought | 63% (12 of 19) | 62% (15 of 24) |
| Movement | Charges halted short of contact | 0.1 | 0.3 |
| Movement | Idle units | 1.8 | 1.5 |
| Movement | Points that never moved of their own | 126.7 | 180.0 |
| Movement | Fights charged into per game | 1.8 | 2.7 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 17 | 6 of 24, net +203 |
| Movement | Charges with odds: sweet spot (55-75%) | 4 of 17, net -66 | 5 of 24, net +38 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 1 of 17, net +0 | 2 of 24, net +55 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 8 of 17, net +20 | 5 of 24, net +47 |
| Shooting | Shots by shooting units (incl. breath weapons) | 6.3 | 10.6 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 29% (18 of 63) | 50% (53 of 106) |
| Shooting | Points destroyed by shooting units | 87.0 | 44.7 |
| Shooting | War machine shots | 6.8 | 4.5 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 40% (27 of 68) | 87% (39 of 45) |
| Shooting | Points destroyed by war machines | 80.1 | 6.5 |
| Magic | Magic missiles cast | 2.4 | 2.0 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 29% (7 of 24) | 55% (11 of 20) |
| Magic | Wounds caused by magic missiles | 7.0 | 3.8 |
| Magic | Wounds caused by other spells | 0.5 | - |
| Magic | Points destroyed by magic (all spells) | 3.5 | 18.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.9 / 0.0 / 0.5 / 0.3 | 2.8 / 0.3 / 0.2 / 0.2 |
| Combat | Points destroyed in combat | 143.4 | 327.9 |
| Combat | Points run down | 11.2 | 6.5 |
| Combat | Net points per charged fight, damage counted | +70 | +70 |
| Combat | Net per 100 charger points, damage counted | +27.8 | +21.0 |
| Combat | First round won (charged fights) | 94% | 67% |
| Combat | Net points per charged fight | +34 | +90 |
| Combat | Net points per supported fight / lone fight | -24 / +46 | +48 / +94 |
| Combat | Charged fights on a top-3 enemy unit | 8 of 18 | 13 of 27 |
| Game | Points lost | 429.0 | 524.6 |
| Game | VP from objectives | 659.0 | 730.0 |
| Game | Lone holders (player turns) | 4.7 | 3.6 |

- Mine won / drew / lost: 5 / 2 / 3 of 10 ended games (of 10); mean margin (Mine - Opponent) +50 VP
- The side that went first won 3 of 8 games with a winner
- Points traded per game (both sides' losses): 954
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: h8-opp-6ec093a-p1

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.8 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.2 | +56.2 | 0.0 | 0.0 | 0.2 | +26.7 | 0.0 | 11.2 |
| ALREADY CARRIED | 0.4 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARTILLERY RE-ROLL WEIGHED | 3.2 | +0.0 | 0.0 | 50.5 | 0.2 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | 0.2 | +1.9 | 0.0 | 0.0 | 0.1 | +0.1 | 0.0 | 0.0 |
| BLOWS WHERE AIMED | 0.1 | -13.6 | 0.0 | 0.0 | 0.2 | +1.9 | 0.0 | 0.0 |
| CANNON PLAN MISSED | 0.6 | +0.0 | 50.2 | 9.5 | 0.5 | +0.0 | 9.5 | 26.5 |
| CANNON PLANNED TARGET | 6.4 | +57.1 | 221.4 | 112.0 | 4.2 | +5.5 | 6.5 | 17.5 |
| CANNON SIGHT KEPT | 1.1 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| CAST JOB | 1.1 | +9.5 | 10.5 | 0.0 | 0.9 | +7.7 | 21.8 | 0.0 |
| CASTER AWAY FROM SCREEN | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CASTING BLOCK | 0.4 | +53.1 | 0.0 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | 1.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 21.1 |
| CASTS FROM BEHIND | - | - | - | - | 0.2 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.1 | +7.2 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | 0.1 | +1.6 | 0.0 | 5.5 | 0.2 | +8.2 | 0.0 | 6.8 |
| CHAFF PASSED | - | - | - | - | 0.1 | +0.0 | 0.0 | 14.5 |
| CHARACTER GUNS | 0.2 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| CHARGE LOSSES | 5.8 | -193.4 | 0.0 | 23.4 | 4.3 | -166.3 | 0.0 | 27.2 |
| CHARGE NOT DECLARED | 0.5 | +0.0 | 13.0 | 13.7 | 0.2 | +0.0 | 8.1 | 0.0 |
| CHARGE NOW FIRST | 1.0 | +0.0 | 45.0 | 0.0 | 2.0 | +0.0 | 99.3 | 38.7 |
| CHARGER SLAIN LOST | 0.5 | -8.7 | 5.5 | 13.7 | 0.3 | -3.4 | 9.5 | 0.0 |
| CHEAP HELPER | 0.2 | +0.0 | 12.4 | 0.0 | - | - | - | - |
| COMBAT PIVOT | 0.3 | +0.0 | 5.5 | 31.0 | 0.7 | +0.0 | 31.0 | 19.5 |
| CONVEYANCE SEARCH | 1.9 | +110.5 | 6.5 | 0.0 | 0.6 | +17.9 | 21.1 | 21.1 |
| COVER ONCE | 5.3 | -306.9 | 0.0 | 42.5 | 5.8 | -403.4 | 0.0 | 58.4 |
| DEPLOY BY FIGURES | 8.4 | +24.5 | 0.0 | 6.5 | 8.4 | +13.2 | 0.0 | 38.9 |
| EDGE GIVE GROUND | 0.1 | +0.9 | 6.5 | 0.0 | - | - | - | - |
| ENGINEER BY LORE | 0.4 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| FALL BACK GOOD ORDER | 1.3 | +6.5 | 39.1 | 8.5 | 2.7 | +2.6 | 176.5 | 30.7 |
| FALLBACK BY WORTH | 0.2 | +2.4 | 0.0 | 0.0 | 0.3 | +0.1 | 0.0 | 0.0 |
| FALLS SHORT | 8.0 | +145.2 | 0.0 | 54.3 | 14.7 | +185.3 | 0.0 | 82.8 |
| FEATURE BUFFS | 1.9 | +61.0 | 0.0 | 11.0 | 0.7 | +20.7 | 0.0 | 12.4 |
| FIGHT TO THE END | 0.7 | +87.0 | 45.0 | 0.0 | 0.9 | +79.9 | 54.0 | 0.0 |
| FIRE IN ORDER | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FIVE ACTION | 44.6 | +2325.8 | 502.0 | 411.0 | 49.4 | +2858.6 | 354.1 | 372.6 |
| FLANK NOT WEIGHED | 3.6 | +0.0 | 0.0 | 65.3 | 4.0 | +0.0 | 0.0 | 76.9 |
| FOLLOW UP WEIGHED | 0.5 | +215.1 | 0.0 | 0.0 | 0.5 | +163.7 | 0.0 | 0.0 |
| FOUR ROUNDS | 2.2 | +307.9 | 103.1 | 18.9 | 3.4 | +371.1 | 202.8 | 49.9 |
| FRIEND CHARGES FIRST | 0.2 | -21.1 | 0.0 | 8.5 | - | - | - | - |
| FRIEND SHOOTS FIRST | 0.5 | -10.1 | 0.0 | 0.0 | 0.2 | -5.6 | 0.0 | 0.0 |
| FRIENDS SHOTS CHECKED | 0.1 | +0.9 | 0.0 | 0.0 | 0.1 | +4.3 | 0.0 | 0.0 |
| GIVES UP | - | - | - | - | 0.3 | -2.3 | 30.0 | 0.0 |
| GROUND FLIERS | 0.2 | +6.6 | 0.0 | 21.9 | - | - | - | - |
| GUN FIGURES | 1.5 | +13.9 | 10.5 | 31.0 | 2.0 | +6.6 | 18.2 | 6.5 |
| GUN MASK | 0.4 | +4.7 | 0.0 | 0.0 | 0.4 | +2.7 | 0.0 | 0.0 |
| HARD STAY DROPPED | 0.8 | +0.0 | 0.0 | 5.2 | 1.4 | +0.0 | 0.0 | 0.0 |
| HE SHOOTS OR CHARGES | 1.9 | +0.0 | 0.0 | 74.2 | 2.3 | +0.0 | 0.0 | 31.5 |
| HIS CHARGE DENIED | 0.1 | +4.8 | 19.5 | 0.0 | 0.2 | +7.5 | 0.0 | 19.5 |
| HIS CHARGE LIST | 2.7 | +0.0 | 0.0 | 9.5 | 0.7 | +0.0 | 0.0 | 3.8 |
| HIS LEGAL MOVES | 2.6 | +0.0 | 0.0 | 0.0 | 2.5 | +0.0 | 0.0 | 16.7 |
| HIS MOVE AND SHOT | 2.2 | -32.7 | 0.0 | 15.0 | 1.0 | -45.9 | 0.0 | 0.0 |
| HIS ONE QUARTER | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVE | 2.1 | +0.0 | 0.0 | 5.5 | 1.4 | +0.0 | 0.0 | 17.9 |
| HIS SHOT LIST | 17.8 | +394.6 | 0.0 | 176.8 | 21.5 | +787.6 | 0.0 | 230.6 |
| HIS TURN DENIED | 0.6 | +19.2 | 16.0 | 0.0 | 1.8 | +48.1 | 160.1 | 19.2 |
| HOLD ODDS | - | - | - | - | 12.8 | +0.0 | 0.0 | 64.4 |
| HOLDER ASSIGNMENT | - | - | - | - | 14.9 | +1294.2 | 0.0 | 52.0 |
| HOLDER AT DEPLOYMENT | 1.0 | +189.2 | 0.0 | 0.0 | - | - | - | - |
| HOLDS AMBUSHERS | 0.5 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 1.5 | -60.7 | 97.6 | 5.2 | 3.0 | -159.5 | 162.3 | 38.7 |
| HUNT IN PAIRS | - | - | - | - | 0.7 | +23.5 | 0.0 | 19.5 |
| HUNT RESULT | - | - | - | - | 0.1 | +14.9 | 9.5 | 0.0 |
| HUNT THE GUNS | - | - | - | - | 0.1 | +16.7 | 9.5 | 0.0 |
| IDLE COST | 5.2 | -53.1 | 0.0 | 24.4 | 11.0 | -145.1 | 0.0 | 67.5 |
| KEEP FALLS | - | - | - | - | 0.1 | +0.5 | 0.0 | 0.0 |
| KEEPS SCOUTS OR AMBUSH | - | - | - | - | 0.1 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 0.3 | +5.4 | 0.0 | 0.0 | 0.9 | +29.0 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 3.2 | +0.0 | 48.5 | 333.1 | 4.4 | +0.0 | 162.4 | 43.0 |
| LONE CHARACTER SAFE SPOT | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| LONE WIZARD KEPT IN | 1.0 | +61.8 | 0.0 | 11.5 | 0.3 | +32.6 | 0.0 | 0.0 |
| LONG SHOT | 0.2 | -2.8 | 0.0 | 0.0 | 0.1 | +4.4 | 0.0 | 0.0 |
| LOST CHARGE | 0.1 | -0.3 | 6.0 | 0.0 | - | - | - | - |
| MAKE SURE TOGETHER | - | - | - | - | 0.2 | +3.6 | 0.0 | 0.0 |
| MANOEUVRE | 1.7 | +25.9 | 0.0 | 0.0 | 0.9 | +2.8 | 0.0 | 5.5 |
| MARCH AT ESCAPER | - | - | - | - | 0.1 | +0.0 | 0.0 | 0.0 |
| MARCH BY THE SUM | 0.4 | +7.6 | 0.0 | 0.0 | 0.3 | +12.8 | 0.0 | 0.0 |
| MARCH CHECK | 1.0 | +66.1 | 0.0 | 16.2 | 0.2 | +10.4 | 0.0 | 0.0 |
| MARCH OVER CASTS | 0.2 | -8.5 | 0.0 | 0.0 | 0.6 | +29.5 | 0.0 | 32.9 |
| MAX FOR POSITIONING | 3.9 | +41.6 | 0.0 | 21.8 | 4.5 | +48.5 | 0.0 | 76.8 |
| MISSILES IN THE MOVE | 4.8 | +217.0 | 0.0 | 16.2 | 3.1 | +44.5 | 0.0 | 21.1 |
| MISSILES NEXT TURN | 4.7 | +127.2 | 0.0 | 24.3 | 4.8 | +45.5 | 0.0 | 54.0 |
| MODEL FACING | - | - | - | - | 0.8 | +128.7 | 0.0 | 0.0 |
| MOVE SPELL IN RANGE | 0.7 | +16.3 | 0.0 | 0.0 | 0.1 | +1.1 | 0.0 | 0.0 |
| MOVE SPELL NOT WORTH | 0.1 | -0.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 2.6 | -51.0 | 0.0 | 0.0 | 0.7 | -20.2 | 0.0 | 0.0 |
| MOVE SPELL SPOT | 0.8 | +0.0 | 0.0 | 6.5 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 2.7 | +196.0 | 0.0 | 8.5 | 3.0 | +331.5 | 0.0 | 12.6 |
| MOVES UNITS SPELL | 0.2 | +11.0 | 0.0 | 0.0 | 0.1 | +0.4 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 3.9 | +210.7 | 0.0 | 27.8 | 5.5 | +233.0 | 0.0 | 44.6 |
| NEXT CHARGE BY LIST | 3.6 | -106.7 | 0.0 | 0.0 | 4.8 | -273.0 | 0.0 | 17.1 |
| NEXT OBJECTIVE NEARER | 5.3 | -198.1 | 16.7 | 22.0 | 0.1 | -0.2 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 2.0 | -118.2 | 85.9 | 18.9 | 2.8 | -116.3 | 146.1 | 38.7 |
| NOT WORTH A CAST | 0.4 | -0.7 | 0.0 | 0.0 | 0.1 | -0.1 | 0.0 | 0.0 |
| OFF BEST | 0.5 | -42.0 | 0.0 | 0.0 | 0.4 | -5.1 | 0.0 | 0.0 |
| ONE CHARGE A CHARGER | 2.9 | +0.0 | 0.0 | 46.3 | 2.1 | +0.0 | 0.0 | 54.3 |
| ONE FIGHT FORMULA | 3.8 | -56.2 | 0.0 | 14.0 | 5.1 | -108.5 | 0.0 | 46.3 |
| ONE OBJECTIVE FORMULA | 4.8 | +115.2 | 0.0 | 6.5 | 4.7 | +0.7 | 0.0 | 26.9 |
| ONE TARGET A SHOOTER | 13.2 | +407.5 | 0.0 | 117.4 | 19.1 | +493.9 | 0.0 | 232.2 |
| OPENS UP | - | - | - | - | 0.5 | +28.9 | 11.0 | 19.5 |
| OVERRUNS AWAY | 0.3 | +5.5 | 10.0 | 0.0 | 0.6 | +18.5 | 36.5 | 19.2 |
| PATHS CROSS | 2.5 | +83.8 | 0.0 | 28.5 | 3.6 | +105.6 | 0.0 | 0.0 |
| PERIAPT WORTH | - | - | - | - | 0.2 | +16.0 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.4 | -9.0 | 0.0 | 0.0 | 0.1 | -0.9 | 0.0 | 0.0 |
| PLAN RESULT | 38.7 | +646.0 | 294.1 | 530.2 | 43.8 | +502.5 | 197.7 | 670.9 |
| QUARTER ODDS | - | - | - | - | 10.1 | +1064.4 | 104.0 | 60.8 |
| RANDOM MOVE BY FIGURES | 1.1 | +3.1 | 0.0 | 0.0 | 1.7 | +28.0 | 0.0 | 71.0 |
| REAL GROUND | - | - | - | - | 0.5 | +0.0 | 0.0 | 0.0 |
| REDIRECT BY WHAT IT STOPS | - | - | - | - | 0.2 | -4.4 | 0.0 | 6.8 |
| REDIRECT COUNTER | 1.7 | +133.3 | 0.0 | 16.6 | 1.4 | +43.5 | 0.0 | 42.1 |
| REDIRECT WEIGHED | 0.3 | +1.2 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 19.5 |
| REFORMS TO MEET IT | 0.5 | -23.4 | 0.0 | 0.0 | 0.5 | -8.1 | 0.0 | 0.0 |
| REFUSING RETIRES | 0.1 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | 0.9 | +32.8 | 0.0 | 0.0 | 0.6 | +15.1 | 0.0 | 11.2 |
| RISK BY ARC | 1.7 | -1.2 | 83.6 | 13.7 | 1.9 | -11.7 | 143.3 | 38.7 |
| RISK BY HIS FIGURE | 12.3 | -151.4 | 0.0 | 150.3 | 10.0 | -71.3 | 0.0 | 167.2 |
| RISK ON THE WAY | - | - | - | - | 0.6 | +0.0 | 0.0 | 0.0 |
| RUN DOWN | 1.3 | -21.6 | 48.1 | 10.4 | 1.4 | -14.6 | 62.6 | 38.7 |
| SCOUT SPOT | 0.2 | +2.4 | 0.0 | 0.0 | 0.2 | +0.4 | 0.0 | 0.0 |
| SCOUT WAITS | 0.2 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 0.1 | -7.0 | 0.0 | 6.0 |
| SEARCH SPOT | 6.1 | +202.5 | 0.0 | 5.2 | 6.0 | +190.5 | 0.0 | 49.5 |
| SELF MOVE SPELL | - | - | - | - | 0.3 | -0.6 | 0.0 | 0.0 |
| SET UP TOGETHER | 0.2 | +0.5 | 0.0 | 0.0 | 0.5 | +21.6 | 0.0 | 12.6 |
| SET-UP ANY TARGET | 0.5 | +77.7 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | 0.4 | +0.8 | 0.0 | 0.0 | 0.3 | +0.9 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.4 | +94.8 | 26.0 | 0.0 | 1.8 | +32.5 | 43.8 | 0.0 |
| SHORT GUN FORWARD | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| SHOT OR CHARGE | 0.3 | -4.8 | 0.0 | 8.5 | 0.4 | -3.5 | 0.0 | 10.0 |
| SHOT RISK POINTS | 9.8 | -36.3 | 0.0 | 112.9 | 11.1 | +50.3 | 0.0 | 180.3 |
| SHOTS IN THE MOVE | 14.1 | +381.2 | 0.0 | 231.8 | 15.3 | +247.3 | 0.0 | 78.2 |
| SPELL SETS UP CHARGE | 0.5 | +77.7 | 0.0 | 0.0 | - | - | - | - |
| SPELL WORTH | 0.7 | +3.8 | 0.0 | 0.0 | 1.6 | +14.1 | 0.0 | 0.0 |
| SPELLS IN THE FIGHT | 0.4 | -0.9 | 49.0 | 0.0 | 0.4 | +3.2 | 34.5 | 0.0 |
| STAND AND SHOOT | 0.1 | -1.0 | 0.0 | 0.0 | 0.6 | -4.5 | 37.5 | 38.7 |
| STANDS FOR A REASON | - | - | - | - | 0.8 | +0.0 | 8.5 | 0.0 |
| STANDS STILL | 19.0 | +0.0 | 398.9 | 245.2 | 17.1 | +0.0 | 132.3 | 105.3 |
| STANDS TO CAST | - | - | - | - | 0.1 | +0.3 | 0.0 | 0.0 |
| STAY WORTH | 17.7 | -30.7 | 232.7 | 221.3 | 15.1 | +17.1 | 27.2 | 101.7 |
| STOPS | - | - | - | - | 0.1 | +0.8 | 9.5 | 0.0 |
| STUCK PIVOT | 0.2 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 21.0 |
| SUPPORT NARROWED | 0.9 | +0.0 | 11.5 | 8.5 | 0.9 | +0.0 | 62.1 | 30.7 |
| SURE REACH TOGETHER | 0.5 | +6.4 | 0.0 | 0.0 | 0.8 | +26.9 | 0.0 | 12.6 |
| THE DEARER SUM KEEPS ITS PLAN | 3.1 | +0.0 | 0.0 | 5.5 | 4.1 | +0.0 | 0.0 | 0.0 |
| THE PROMISE ADDS | 0.3 | -14.6 | 0.0 | 0.0 | - | - | - | - |
| THE PROMISED MOVE | 0.2 | +0.0 | 0.0 | 0.0 | 0.8 | +0.0 | 0.0 | 5.5 |
| TIED UP BY THE SUM | 0.4 | +33.1 | 5.5 | 0.0 | 0.5 | +50.2 | 42.1 | 19.5 |
| TIME ON OUR SIDE | 20.7 | +336.1 | 29.3 | 170.0 | 13.0 | +181.0 | 10.7 | 54.5 |
| WAITS AGAIN | 1.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 19.1 |
| WALK PROMISE | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| WAR ENGINE CHARGES | 0.1 | +19.4 | 0.0 | 0.0 | 0.1 | +6.0 | 9.5 | 0.0 |
| WAR ENGINE JOBS | 0.7 | +0.0 | 26.0 | 0.0 | 0.4 | +0.0 | 18.0 | 0.0 |
| WHO HITS BACK | 0.2 | +121.2 | 0.0 | 0.0 | 0.4 | +48.1 | 0.0 | 21.0 |
| WHOLE FIGHT | 0.3 | +4.2 | 11.2 | 8.5 | 0.2 | +12.1 | 31.0 | 11.2 |
| WHOLE FIGHT GAIN | 0.2 | +2.8 | 12.4 | 5.2 | - | - | - | - |
| WIDER SPREAD | 1.5 | -3.8 | 79.9 | 18.9 | 2.5 | -4.3 | 157.2 | 0.0 |
| WOUNDS ON THE RANKS | 2.0 | +65.0 | 0.0 | 0.0 | 0.9 | +30.2 | 0.0 | 16.7 |

### Rule changes: h8-opp-6ec093a-p1

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HOLDER ASSIGNMENT | 149 | 149 | 137 | 13.70 | +5975 | +43.6 |
| SEARCH SPOT | 121 | 121 | 116 | 11.60 | +3931 | +33.9 |
| HIS SHOT LIST | 393 | 393 | 103 | 10.30 | +1626 | +15.8 |
| DEPLOY BY FIGURES | 168 | 168 | 99 | 9.90 | +2187 | +22.1 |
| ONE TARGET A SHOOTER | 323 | 323 | 84 | 8.40 | +851 | +10.1 |
| LEGAL CHARGES ONLY | 76 | 76 | 76 | 7.60 | +0 | +0.0 |
| TIME ON OUR SIDE | 337 | 305 | 72 | 7.20 | +387 | +5.4 |
| PATHS CROSS | 61 | 61 | 61 | 6.10 | +1894 | +31.0 |
| FIVE ACTION | 940 | 940 | 46 | 4.60 | +1265 | +27.5 |
| MOVE TO CHARGE COMPUTED | 57 | 57 | 44 | 4.40 | +1926 | +43.8 |
| SHOT RISK POINTS | 209 | 209 | 42 | 4.20 | +829 | +19.7 |
| FOUR ROUNDS | 56 | 56 | 35 | 3.50 | +2785 | +79.6 |
| ARTILLERY RE-ROLL WEIGHED | 34 | 34 | 34 | 3.40 | +0 | +0.0 |
| SHOOTS FROM THE BEST SPOT | 32 | 32 | 25 | 2.50 | +397 | +15.9 |
| COVER ONCE | 111 | 92 | 24 | 2.40 | +165 | +6.9 |
| HARD STAY DROPPED | 22 | 22 | 22 | 2.20 | +0 | +0.0 |
| CANNON PLANNED TARGET | 106 | 106 | 20 | 2.00 | -194 | -9.7 |
| IDLE COST | 162 | 130 | 20 | 2.00 | +100 | +5.0 |
| CANNON SIGHT KEPT | 18 | 18 | 18 | 1.80 | +0 | +0.0 |
| MAX FOR POSITIONING | 84 | 84 | 18 | 1.80 | +80 | +4.4 |
| RANDOM MOVE BY FIGURES | 28 | 28 | 18 | 1.80 | +310 | +17.2 |
| SHOTS IN THE MOVE | 294 | 253 | 17 | 1.70 | +700 | +41.2 |
| RESERVE FALL BACK | 15 | 15 | 15 | 1.50 | +479 | +31.9 |
| FALLS SHORT | 227 | 197 | 14 | 1.40 | +145 | +10.4 |
| MANOEUVRE | 26 | 26 | 14 | 1.40 | +301 | +21.5 |
| LONE WIZARD KEPT IN | 13 | 13 | 13 | 1.30 | +944 | +72.7 |
| ADVANCE LANE KEPT | 12 | 12 | 12 | 1.20 | +0 | +0.0 |
| LANE BY FIGURES | 12 | 12 | 12 | 1.20 | +344 | +28.7 |
| MISSILES IN THE MOVE | 79 | 64 | 12 | 1.20 | +283 | +23.6 |
| ONE OBJECTIVE FORMULA | 95 | 83 | 12 | 1.20 | +552 | +46.0 |
| QUARTER ODDS | 101 | 101 | 12 | 1.20 | +781 | +65.1 |
| COMBAT PIVOT | 10 | 10 | 10 | 1.00 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 10 | 10 | 10 | 1.00 | +3788 | +378.8 |
| NEXT OBJECTIVE NEARER | 54 | 54 | 10 | 1.00 | +185 | +18.5 |
| RISK BY ARC | 36 | 36 | 10 | 1.00 | +216 | +21.6 |
| OFF BEST | 9 | 9 | 9 | 0.90 | -471 | -52.3 |
| REDIRECT COUNTER | 31 | 23 | 9 | 0.90 | +1244 | +138.3 |
| HOLDS AMBUSHERS | 8 | 8 | 8 | 0.80 | +0 | +0.0 |
| MARCH CHECK | 12 | 12 | 8 | 0.80 | +171 | +21.4 |
| MODEL FACING | 8 | 8 | 8 | 0.80 | +1287 | +160.9 |
| RISK BY HIS FIGURE | 223 | 223 | 8 | 0.80 | +311 | +38.8 |
| SURE REACH TOGETHER | 13 | 13 | 8 | 0.80 | +38 | +4.8 |
| CHARGE LOSSES | 101 | 101 | 7 | 0.70 | +303 | +43.3 |
| CHARGE NOT DECLARED | 7 | 7 | 7 | 0.70 | -708 | -101.1 |
| MARCH BY THE SUM | 7 | 7 | 7 | 0.70 | +203 | +29.0 |
| SHOOTERS IN TWO RANKS | 7 | 7 | 7 | 0.70 | +17 | +2.4 |
| TIED UP BY THE SUM | 9 | 9 | 7 | 0.70 | +182 | +26.0 |
| WOUNDS ON THE RANKS | 29 | 29 | 7 | 0.70 | +211 | +30.2 |
| CHARGE NOW FIRST | 30 | 30 | 6 | 0.60 | -832 | -138.7 |
| FEATURE BUFFS | 26 | 26 | 6 | 0.60 | +43 | +7.2 |
| HOLDER AT DEPLOYMENT | 10 | 10 | 6 | 0.60 | +279 | +46.6 |
| WHO HITS BACK | 6 | 6 | 6 | 0.60 | +1007 | +167.8 |
| FIGHT TO THE END | 16 | 16 | 5 | 0.50 | +497 | +99.3 |
| NEARER NOT NEEDED | 94 | 90 | 5 | 0.50 | +171 | +34.3 |
| NEXT CHARGE BY LIST | 84 | 84 | 5 | 0.50 | +67 | +13.4 |
| PIVOT GUARDS FLANK | 5 | 5 | 5 | 0.50 | -99 | -19.7 |
| REDIRECT WEIGHED | 5 | 5 | 5 | 0.50 | +175 | +35.1 |
| AFTERMATH IN POINTS | 4 | 4 | 4 | 0.40 | +829 | +207.1 |
| CASTING BLOCK | 4 | 4 | 4 | 0.40 | +348 | +87.0 |
| HIS TURN DENIED | 24 | 24 | 4 | 0.40 | +49 | +12.3 |
| SCOUT WAITS | 4 | 4 | 4 | 0.40 | +0 | +0.0 |
| STAY WORTH | 328 | 302 | 4 | 0.40 | +8 | +2.0 |
| STUCK PIVOT | 4 | 4 | 4 | 0.40 | +0 | +0.0 |
| CAST JOB | 20 | 20 | 3 | 0.30 | +9 | +3.0 |
| CASTER AWAY FROM SCREEN | 3 | 3 | 3 | 0.30 | +0 | +0.0 |
| MOVES UNITS SPELL | 3 | 3 | 3 | 0.30 | +114 | +38.2 |
| SHORT GUN FORWARD | 3 | 3 | 3 | 0.30 | +0 | +0.0 |
| WAR ENGINE JOBS | 11 | 11 | 3 | 0.30 | -128 | -42.7 |
| CASTS FROM BEHIND | 2 | 2 | 2 | 0.20 | +0 | +0.0 |
| CHAFF IN THE MOVE | 3 | 2 | 2 | 0.20 | +0 | +0.0 |
| FALLBACK BY WORTH | 5 | 5 | 2 | 0.20 | +26 | +12.8 |
| FRIENDS SHOTS CHECKED | 2 | 2 | 2 | 0.20 | +53 | +26.4 |
| HIS MOVE AND SHOT | 32 | 32 | 2 | 0.20 | +24 | +12.2 |
| HUNT IN PAIRS | 7 | 5 | 2 | 0.20 | +28 | +14.1 |
| OPENS UP | 5 | 5 | 2 | 0.20 | +62 | +31.2 |
| PERIAPT WORTH | 2 | 2 | 2 | 0.20 | +160 | +80.1 |
| SET UP TOGETHER | 7 | 4 | 2 | 0.20 | +50 | +25.2 |
| WHOLE FIGHT GAIN | 2 | 2 | 2 | 0.20 | +12 | +6.1 |
| BACKUP TARGETS | 3 | 2 | 1 | 0.10 | +5 | +5.4 |
| CHAFF PASSED | 1 | 1 | 1 | 0.10 | +0 | +0.0 |
| FALL BACK GOOD ORDER | 40 | 40 | 1 | 0.10 | +12 | +11.8 |
| FIRE IN ORDER | 1 | 1 | 1 | 0.10 | +0 | +0.0 |
| FRIEND CHARGES FIRST | 2 | 2 | 1 | 0.10 | +1 | +1.3 |
| GUN MASK | 8 | 8 | 1 | 0.10 | +12 | +12.4 |
| HONEST WORTH | 45 | 45 | 1 | 0.10 | +70 | +69.5 |
| KEEP FALLS | 1 | 1 | 1 | 0.10 | +4 | +3.7 |
| KEEPS SCOUTS OR AMBUSH | 1 | 1 | 1 | 0.10 | +0 | +0.0 |
| LONG SHOT | 3 | 3 | 1 | 0.10 | +3 | +3.1 |
| MISSILES NEXT TURN | 95 | 71 | 1 | 0.10 | +4 | +4.4 |
| NO DOUBLE ROUNDS | 48 | 48 | 1 | 0.10 | +7 | +6.7 |
| ONE FIGHT FORMULA | 89 | 43 | 1 | 0.10 | +0 | +0.1 |
| OVERRUNS AWAY | 9 | 9 | 1 | 0.10 | +51 | +50.7 |
| REFUSING RETIRES | 5 | 5 | 1 | 0.10 | -0 | -0.1 |
| STANDS TO CAST | 1 | 1 | 1 | 0.10 | -1 | -0.7 |
| STOPS | 1 | 1 | 1 | 0.10 | +3 | +3.3 |
| SUPPORT NARROWED | 18 | 18 | 1 | 0.10 | -18 | -18.3 |
| WAR ENGINE CHARGES | 2 | 2 | 1 | 0.10 | +13 | +13.5 |
| WHOLE FIGHT | 5 | 5 | 1 | 0.10 | +76 | +75.6 |
| WIDER SPREAD | 40 | 40 | 1 | 0.10 | +3 | +3.3 |
| ALREADY CARRIED | 4 | not checked | - | - | - | - |
| BLOWS WHERE AIMED | 3 | 3 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 11 | 11 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 20 | trace | - | - | - | - |
| CATCH FLIERS | 1 | not checked | - | - | - | - |
| CHARACTER GUNS | 9 | 9 | 0 | 0.00 | - | - |
| CHARGER SLAIN LOST | 8 | 8 | 0 | 0.00 | - | - |
| CHEAP HELPER | 2 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 25 | not checked | - | - | - | - |
| EDGE GIVE GROUND | 1 | 1 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 6 | 6 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 76 | not checked | - | - | - | - |
| FRIEND SHOOTS FIRST | 7 | 7 | 0 | 0.00 | - | - |
| GIVES UP | 3 | 3 | 0 | 0.00 | - | - |
| GROUND FLIERS | 2 | not checked | - | - | - | - |
| GUN FIGURES | 35 | not checked | - | - | - | - |
| HE SHOOTS OR CHARGES | 42 | 42 | 0 | 0.00 | - | - |
| HIS CHARGE DENIED | 3 | 3 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 34 | 34 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 51 | 51 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 13 | 13 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 35 | 35 | 0 | 0.00 | - | - |
| HOLD ODDS | 128 | 128 | 0 | 0.00 | - | - |
| HUNT RESULT | 1 | trace | - | - | - | - |
| HUNT THE GUNS | 1 | trace | - | - | - | - |
| LONE CHARACTER SAFE SPOT | 1 | not checked | - | - | - | - |
| LOST CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 2 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 8 | 8 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 8 | 4 | 0 | 0.00 | - | - |
| MOVE SPELL NOT WORTH | 1 | not checked | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 33 | trace | - | - | - | - |
| MOVE SPELL SPOT | 8 | not checked | - | - | - | - |
| NOT WORTH A CAST | 5 | not checked | - | - | - | - |
| ONE CHARGE A CHARGER | 50 | 50 | 0 | 0.00 | - | - |
| PLAN RESULT | 825 | trace | - | - | - | - |
| REAL GROUND | 5 | 5 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 2 | 2 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 10 | 10 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 6 | 6 | 0 | 0.00 | - | - |
| RUN DOWN | 27 | 27 | 0 | 0.00 | - | - |
| SCOUT SPOT | 4 | 4 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 1 | 1 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 3 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 5 | not checked | - | - | - | - |
| SHOT OR CHARGE | 7 | 7 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 5 | not checked | - | - | - | - |
| SPELL WORTH | 23 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 8 | 8 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 7 | 7 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 8 | 8 | 0 | 0.00 | - | - |
| STANDS STILL | 361 | 361 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 72 | not checked | - | - | - | - |
| THE PROMISE ADDS | 3 | 3 | 0 | 0.00 | - | - |
| THE PROMISED MOVE | 10 | not checked | - | - | - | - |
| WAITS AGAIN | 27 | 27 | 0 | 0.00 | - | - |
| WALK PROMISE | 3 | 3 | 0 | 0.00 | - | - |

### Off best figure: h8-opp-6ec093a-p1

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| HOLDER ASSIGNMENT | rule | - | 1.20 | 15.5 |
| CHARGE NOT DECLARED | rule | 0.50 | 0.20 | 101.1 |
| CANNON PLANNED TARGET | rule | 0.50 | 0.10 | 38.2 |
| CHARGE NOW FIRST | rule | 0.10 | 0.50 | 138.7 |
| JOB FIRST | gate | 0.20 | 0.30 | 12.2 |
| PATHS CROSS | rule | 0.40 | 0.10 | 23.3 |
| PIVOT GUARDS FLANK | rule | 0.40 | 0.10 | 19.7 |
| WAR ENGINE JOBS | rule | 0.20 | 0.10 | 42.7 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.20 | - | 66.0 |
| AFTERMATH BAND | gate | - | 0.10 | 3.5 |
| RULE SWITCHED OFF | gate | 0.10 | - | 274.4 |
| STANDS TO CAST | rule | - | 0.10 | 0.7 |
| SUPPORT NARROWED | rule | - | 0.10 | 18.3 |

### Plans: h8-opp-6ec093a-p1

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.6 | 75% | 284 | 159 | 56% |
| Mine | join | 0.6 | 100% | 20 | 0 | 0% |
| Mine | move | 26.5 | 94% | 1429 | 0 | 0% |
| Mine | shoot | 10.0 | 52% | 360 | 487 | 135% |
| Opponent | charge | 2.8 | 57% | 526 | 180 | 34% |
| Opponent | join | 0.5 | 100% | 28 | 0 | 0% |
| Opponent | move | 31.8 | 92% | 1515 | 0 | 0% |
| Opponent | shoot | 8.4 | 57% | 225 | 323 | 144% |
| Opponent | support | 0.3 | 67% | 0 | 0 | - |

### Packages: hunt the guns, h8-opp-6ec093a-p1

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 6 |
| Opponent | 0.1 | 1 | 0 | 100% | 100% | 0% | 2.0 | 167 | 149 | 100% | 80 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 22 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 456 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 172 |
| Tomb Kings of Khemri | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Vampire Counts | 1.0 | 1 | 0 | 100% | 100% | 0% | 2.0 | 167 | 149 | 100% | 0 |

### Battle groups: h8-opp-6ec093a-p1

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 1.7 | 18% | 33% | 67% | 50% | 0% | 0% | 0% | 0% | 100% |
| Opponent | REDIRECT COUNTER | 1.4 | 36% | 100% | 0% | - | 40% | 0% | 0% | 60% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: h8-opp-6ec093a-p1

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Mine | Chaff | 9 | 46 (9) | 0 | 46 | 49 | 67% | 2.0 | 80 (1) | 50 (6) | 0 (2) | 63 (6) | 0 (3) |
| Mine | Character | 41 | 20 (41) | 20 | 0 | 17 | 12% | 2.4 | 49 (7) | 14 (21) | 15 (12) | 15 (24) | 27 (16) |
| Mine | Clean-up | 7 | 107 (7) | 13 | 94 | 19 | 43% | 5.2 | 0 (1) | 143 (4) | 25 (2) | 174 (4) | 51 (3) |
| Mine | Fast Hammer | 7 | 26 (7) | 26 | 0 | 55 | 14% | 4.0 | - | 6 (3) | 35 (4) | 23 (2) | 28 (5) |
| Mine | Hammer | 23 | 44 (23) | 14 | 30 | 18 | 22% | 2.9 | 29 (4) | 62 (10) | 30 (9) | 31 (13) | 64 (10) |
| Mine | Holder | 11 | 34 (11) | 0 | 34 | 13 | 73% | 3.3 | 0 (1) | 29 (8) | 81 (2) | 26 (5) | 40 (6) |
| Mine | Shooter | 2 | 350 (2) | 50 | 300 | 50 | 0% | 1.0 | 146 (1) | 554 (1) | - | 350 (2) | - |
| Mine | War machine | 18 | 38 (18) | 38 | 0 | 54 | 0% | 1.2 | 39 (7) | 69 (7) | 0 (4) | 0 (3) | 45 (15) |
| Mine | Wizard | 7 | 0 (7) | 0 | 0 | 18 | 43% | 1.5 | 0 (2) | 0 (1) | 0 (3) | 0 (3) | 0 (3) |
| Opponent | Chaff | 14 | 94 (14) | 10 | 84 | 72 | 36% | 2.4 | 118 (5) | 58 (3) | 87 (6) | 113 (6) | 78 (8) |
| Opponent | Character | 26 | 48 (26) | 48 | 0 | 12 | 31% | 2.6 | 33 (6) | 46 (10) | 74 (7) | 56 (12) | 44 (11) |
| Opponent | Clean-up | 12 | 28 (12) | 5 | 23 | 30 | 67% | 5.0 | 0 (5) | 36 (6) | 96 (1) | 32 (9) | 19 (3) |
| Opponent | Fast | 1 | 0 (1) | 0 | 0 | 0 | 0% | 1.0 | - | 0 (1) | - | 0 (1) | - |
| Opponent | Fast Hammer | 6 | 7 (6) | 0 | 7 | 65 | 17% | 2.0 | 0 (1) | 18 (2) | 0 (3) | 54 (1) | 0 (5) |
| Opponent | Fragile | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | - | 0 (1) | 0 (1) | - |
| Opponent | Hammer | 17 | 17 (17) | 6 | 11 | 17 | 24% | 2.9 | 0 (3) | 13 (12) | 58 (2) | 3 (7) | 28 (10) |
| Opponent | Holder | 14 | 129 (14) | 0 | 129 | 29 | 71% | 2.8 | 177 (4) | 119 (7) | 79 (3) | 157 (7) | 89 (7) |
| Opponent | Shooter | 11 | 55 (11) | 25 | 29 | 14 | 0% | 2.5 | 0 (3) | 53 (5) | 159 (3) | 46 (6) | 70 (5) |
| Opponent | War machine | 12 | 4 (12) | 4 | 0 | 39 | 17% | 1.5 | 0 (3) | 0 (3) | 7 (6) | 0 (2) | 5 (10) |
| Opponent | Wizard | 7 | 24 (7) | 24 | 0 | 65 | 14% | 2.3 | 43 (4) | 0 (1) | - | 87 (2) | 0 (3) |

### Charged fights: h8-opp-6ec093a-p1

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 25 | 84 | 1.8 | 1.6 | 48 | 20 | +28 | 2 of 7 | 6 of 7 | -24 | +68 |
| Mine | Chaos Dwarfs | 4 | 141 | 266 | 2.8 | 1.0 | 97 | 59 | +38 | 6 of 11 | 11 of 11 | - | +38 |
| Mine | Dwarfen Mountain Holds | 2 | 520 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| **Mine** | all armies | 10 | 171 | 140 | 1.8 | 1.2 | 78 | 44 | +34 | 8 of 18 | 17 of 18 | -24 | +46 |
| Opponent | Chaos Dwarfs | 3 | 81 | 271 | 2.3 | 1.0 | 116 | 0 | +116 | 6 of 7 | 4 of 7 | - | +116 |
| Opponent | Dwarfen Mountain Holds | 1 | 0 | 0 | 3.0 | 1.3 | 0 | 0 | +0 | 2 of 3 | 2 of 3 | +0 | +0 |
| Opponent | Grand Cathay | 1 | 138 | 592 | 5.0 | 1.4 | 118 | 0 | +118 | 0 of 5 | 4 of 5 | +95 | +124 |
| Opponent | Orc & Goblin Tribes | 1 | 0 | 52 | 1.0 | 1.0 | 52 | 0 | +52 | 0 of 1 | 1 of 1 | - | +52 |
| Opponent | Skaven | 2 | 155 | 32 | 1.0 | 1.0 | 32 | 0 | +32 | 1 of 2 | 2 of 2 | - | +32 |
| Opponent | Tomb Kings of Khemri | 1 | 0 | 0 | 5.0 | 1.0 | 0 | 12 | -12 | 3 of 5 | 4 of 5 | - | -12 |
| Opponent | Vampire Counts | 1 | 0 | 980 | 4.0 | 1.0 | 245 | 0 | +245 | 1 of 4 | 1 of 4 | - | +245 |
| **Opponent** | all armies | 10 | 69 | 250 | 2.7 | 1.1 | 93 | 2 | +90 | 13 of 27 | 18 of 27 | +48 | +94 |

### Effective charges: h8-opp-6ec093a-p1

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 7 | 0 | 0 | 2 (net -26) | 1 (net +271) | 0 | 4 (net -5) | 0 | 29% (2 of 7) |
| Mine | Chaos Dwarfs | 11 | 0 | 0 | 2 (net -106) | 3 (net +80) | 1 (net +0) | 4 (net +44) | 1 | 20% (2 of 10) |
| Opponent | Chaos Dwarfs | 7 | 3 (net +111) | 0 | 0 | 1 (net +140) | 1 (net +110) | 1 (net +230) | 1 | 0% (0 of 6) |
| Opponent | Dwarfen Mountain Holds | 3 | 0 | 0 | 2 (net +0) | 0 | 0 | 1 (net +0) | 0 | 67% (2 of 3) |
| Opponent | Grand Cathay | 5 | 0 | 0 | 1 (net +190) | 4 (net +100) | 0 | 0 | 0 | 20% (1 of 5) |
| Opponent | Skaven | 2 | 1 (net +0) | 0 | 0 | 0 | 0 | 1 (net +65) | 0 | 0% (0 of 2) |
| Opponent | Tomb Kings of Khemri | 5 | 0 | 0 | 1 (net +0) | 1 (net +0) | 1 (net +0) | 2 (net -30) | 0 | 20% (1 of 5) |
| Opponent | Vampire Counts | 4 | 2 (net +442) | 0 | 1 (net +0) | 0 | 0 | 0 | 1 | 33% (1 of 3) |

### Charged fights, damage counted: h8-opp-6ec093a-p1

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Effective (55-75%) | 4 | 208 | 248 | -66 | 79 | 109 | -30 | -14.2 |
| Mine | 76-89% | 4 | 381 | 138 | +128 | 205 | 78 | +128 | +33.5 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 8 | 194 | 146 | +20 | 103 | 16 | +87 | +45.1 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 310 | 60 | +0 | 0 | 0 | +0 | +0.0 |
| Mine | No odds | 1 | 310 | 210 | +210 | 210 | 44 | +166 | +53.5 |
| Mine | All fights | 18 | 252 | 166 | +34 | 121 | 51 | +70 | +27.8 |
| Opponent | Long shot (under 50%) | 6 | 299 | 257 | +203 | 206 | 75 | +131 | +43.8 |
| Opponent | Effective (55-75%) | 5 | 140 | 151 | +38 | 46 | 27 | +19 | +13.7 |
| Opponent | 76-89% | 6 | 437 | 142 | +90 | 90 | 0 | +90 | +20.7 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 5 | 329 | 251 | +47 | 59 | 41 | +18 | +5.5 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 2 | 460 | 115 | +55 | 85 | 0 | +85 | +18.5 |
| Opponent | No odds | 3 | 437 | 154 | +49 | 66 | 0 | +66 | +15.2 |
| Opponent | All fights | 27 | 333 | 189 | +90 | 99 | 29 | +70 | +21.0 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| h8-opp-6ec093a-p1 | move | 66 | 18 (27%) | 10 (15%) | 11 (17%) | 37 (56%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0103, L0120 |
| Charmed Shield | Opponent | L0525 |
| Elixir of Power | Opponent | L0219 |
| Invocation of Nehek | Opponent | L0525 |
| Periapt of Soul Exchange | Opponent | L0120, L0321 |
| Ring of Doom | Mine | L0204, L0219 |
| Ring of Jet | Opponent | L0510 |
| Storm Daemon (Renegade 2.0) | Opponent | L0321 |
| Twice-Blessed Armour | Opponent | L0510 |

# Doctrine scorecard: h8-opp-6ec093a-p2

### Scorecard: h8-opp-6ec093a-p2

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0108 | 6 | 1 | Mine | no | 1 | 5 | 1 | 3 | 0 | 0 | 0 | 0 |
| L0108 | 6 | 1 | Opponent | no | 3 | 6 | 0 | 0 | 0 | 0 | 0 | 36 |
| L0123 | 3 | 1 | Mine | yes | 16 | 6 | 2 | 1 | 1 | 0 | 0 | 0 |
| L0123 | 3 | 1 | Opponent | no | 1 | 3 | 2 | 1 | 1 | 0 | 0 | 257 |
| L0207 | 3 | 1 | Mine | no | 1 | 4 | 2 | 2 | 0 | 0 | 0 | 170 |
| L0207 | 3 | 1 | Opponent | no | 4 | 4 | 3 | 0 | 0 | 0 | 0 | 247 |
| L0224 | 2 | 1 | Mine | - | - | 1 | 3 | 4 | 0 | 0 | 0 | 251 |
| L0224 | 2 | 1 | Opponent | - | - | - | 0 | 4 | 0 | 0 | 0 | 0 |
| L0308 | 2 | 1 | Mine | - | - | 2 | 1 | 3 | 0 | 0 | 0 | 110 |
| L0308 | 2 | 1 | Opponent | - | - | - | 0 | 3 | 0 | 0 | 0 | 425 |
| L0325 | 1 | 1 | Mine | no | 1 | 2 | 1 | 0 | 0 | 0 | 0 | 230 |
| L0325 | 1 | 1 | Opponent | no | 8 | 3 | 1 | 2 | 0 | 0 | 0 | 0 |
| L0411 | 3 | 1 | Mine | no | 2 | 2 | 4 | 2 | 1 | 0 | 0 | 0 |
| L0411 | 3 | 1 | Opponent | no | 5 | 3 | 1 | 0 | 0 | 0 | 0 | 330 |
| L0427 | 1 | 1 | Mine | no | 0 | 3 | 3 | 0 | 0 | 0 | 0 | 0 |
| L0427 | 1 | 1 | Opponent | no | 0 | 1 | 2 | 3 | 1 | 0 | 0 | 0 |
| L0513 | 3 | 1 | Mine | no | 2 | - | 0 | 2 | 0 | 0 | 0 | 263 |
| L0513 | 3 | 1 | Opponent | no | 5 | 6 | 1 | 1 | 1 | 0 | 0 | 339 |
| **Average** | | | Mine | 14% | 3.3 | 3.1 | 1.9 | 1.9 | 0.2 | 0.0 | 0.0 | 113.8 |
| **Average** | | | Opponent | 0% | 3.7 | 3.7 | 1.1 | 1.6 | 0.3 | 0.0 | 0.0 | 181.6 |

### KPIs: h8-opp-6ec093a-p2

Rules off - Mine only: HOLDER ASSIGNMENT, QUARTER ODDS, WALK PROMISE, REAL GROUND, RISK ON THE WAY.

Morten 2026-11-10; 9 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 19% (7 of 37) | 26% (12 of 47) | 23% (19 of 84) |
| Winner chose to follow up after the loser gave ground |  | 25% (1 of 4); on the table 50% | 82% (9 of 11); on the table 82% | 67% (10 of 15); on the table 73% |
| Winner chose to pursue after the loser fell back in good order |  | 50% (1 of 2); on the table 50% | 100% (2 of 2); on the table 100% | 75% (3 of 4); on the table 75% |
| Winner chose to pursue after the loser fled |  | 80% (4 of 5); on the table 100% | 88% (7 of 8); on the table 88% | 85% (11 of 13); on the table 92% |
| Winner chose to follow up or pursue (all three) |  | 55% (6 of 11); on the table 73% | 86% (18 of 21); on the table 86% | 75% (24 of 32); on the table 81% |
| Magic missiles tried each own turn | 50%+ | 29% (40 of 138) | 38% (16 of 42) | 31% (56 of 180) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 34% (40 of 116) | 50% (16 of 32) | 38% (56 of 148) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 42% (5 of 12) | - | 42% (5 of 12) |
| Points that never fought | lower | 53% (9301 of 17594) | 55% (9968 of 17995) | 54% (19269 of 35589) |
|   infantry points that never fought | lower | 57% (2897 of 5100) | 60% (1887 of 3139) | 58% (4784 of 8239) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 57% (35 of 61) | 57% (40 of 70) | 57% (75 of 131) |
| Bound items with a magic missile used (at least once a game) |  | 83% (5 of 6); 1.4 uses a game | 100% (3 of 3); 0.7 uses a game | 89% (8 of 9); 1.1 uses a game |
| Bound items with another spell used |  | 100% (2 of 2); 1.0 uses a game | 33% (1 of 3); 0.1 uses a game | 60% (3 of 5); 0.6 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 50% (4 of 8); 0.4 uses a game | 0% (0 of 4); 0.0 uses a game | 33% (4 of 12); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 52% (7043 of 13520) | 54% (8365 of 15473) | 53% (15408 of 28993) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 6.0 (55%) | 1.2 (42%) | 7.2 (52%) |
| MARCHED: its unit marched | 2.3 (21%) | 0.6 (19%) | 2.9 (21%) |
| IN COMBAT: engaged in combat | 1.1 (10%) | 0.7 (23%) | 1.8 (13%) |
| GONE: slain | 1.3 (12%) | 0.4 (15%) | 1.8 (13%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.1 | 1.2 | 3.0 | 6.2 | 0.7 | 2.0 |
| not cast | 3.9 | 2.1 | 5.7 | 13.8 | 1.3 | 26.0 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.1 (4%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.9 (89%) | 0.4 (8%) | 7.2 (52%) | 0.8 (58%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.9 (21%) | 0.1 (8%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.4 (11%) | 0.2 (11%) | 0.7 (12%) | 1.8 (13%) | 0.1 (8%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.4 (2%) |
| GONE: slain | 0.8 (20%) | 0.0 (0%) | 1.1 (20%) | 1.8 (13%) | 0.0 (0%) | 1.8 (7%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.3 (25%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.7 (69%) | 0.0 (0%) | 3.4 (61%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 22.7 (87%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 3.6 a game | 0.4 a game | 2.0 a game |
| stood (cast and not dispelled) | 53% (17 of 32) | 50% (2 of 4) | 53% (19 of 36) |
| the unit moved after it | 65% (11 of 17) | 100% (2 of 2) | 68% (13 of 19) |
| it charged on its next turn | 6% (1 of 17) | 0% (0 of 2) | 5% (1 of 19) |
| the enemy charged it first | 6% (1 of 17) | 0% (0 of 2) | 5% (1 of 19) |
| it fought by the end of its next turn | 6% (1 of 17) | 0% (0 of 2) | 5% (1 of 19) |
| it moved out of a charge the enemy had planned (not charged first) | 6% (1 of 17) | 0% (0 of 2) | 5% (1 of 19) |
| none of these (no charge, no fight, no charge escaped) | 82% (14 of 17) | 100% (2 of 2) | 84% (16 of 19) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 65% (113 of 174) | 56% (103 of 183) | 61% (216 of 357) |
|   cavalry | 42% (5 of 12) | 59% (17 of 29) | 54% (22 of 41) |
|   character | 65% (13 of 20) | 7% (1 of 14) | 41% (14 of 34) |
|   chariot | 59% (26 of 44) | 83% (15 of 18) | 66% (41 of 62) |
|   infantry | 59% (20 of 34) | 80% (33 of 41) | 71% (53 of 75) |
|   war machine | 77% (49 of 64) | 46% (37 of 81) | 59% (86 of 145) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.8 (26%) | 1.7 (19%) | 3.4 (22%) |
| CHARGED: it charged | 0.6 (8%) | 0.4 (5%) | 1.0 (6%) |
| FLEEING: it fled or was fleeing | 0.1 (2%) | 0.1 (1%) | 0.2 (1%) |
| IN COMBAT: it fought this turn or the last | 0.1 (2%) | 0.3 (4%) | 0.4 (3%) |
| MOVED: a war machine that moved | 0.8 (11%) | 1.9 (21%) | 2.7 (17%) |
| NO TARGET IN RANGE | 2.1 (31%) | 1.1 (12%) | 3.2 (21%) |
| ONLY IN COMBAT: the only targets were in combat | 0.2 (3%) | 0.1 (1%) | 0.3 (2%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.7 (10%) | 2.9 (32%) | 3.6 (23%) |
| SHELTERED: the target was sheltered | 0.2 (3%) | 0.0 (0%) | 0.2 (1%) |
| OTHER BAR | 0.2 (3%) | 0.3 (4%) | 0.6 (4%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 3.6 | 2.3 | 66% | 11.2 pts | 40 pts |
| character | 1.8 | 1.3 | 50% | 12.1 pts | 22 pts |
| chariot | 4.6 | 4.9 | 51% | 24.3 pts | 111 pts |
| infantry | 8.6 | 5.4 | 62% | 10.7 pts | 92 pts |
| war machine | 9.6 | 11.3 | 58% | 27.3 pts | 261 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 2.8 | 3.2 | 3.0 |
| Charges that made contact a game | 2.1 | 2.8 | 2.4 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.17 declared, 0.17 contact (6 units) | 0.60 declared, 0.60 contact (5 units) | 0.36 declared, 0.36 contact (11 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 0.67 declared, 0.67 contact (3 units) | 0.67 declared, 0.67 contact (3 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.39 declared, 0.30 contact (61 units) | 0.40 declared, 0.33 contact (60 units) | 0.40 declared, 0.31 contact (121 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 50% (6 of 12) | 33% (2 of 6) | 50% (1 of 2) | 45% (9 of 20) |
| Character in a unit | 89% (16 of 18) | 78% (7 of 9) | - | 85% (23 of 27) |
| Character on its own | 60% (3 of 5) | 71% (5 of 7) | 50% (5 of 10) | 59% (13 of 22) |
| Chariot | 100% (1 of 1) | 40% (4 of 10) | - | 45% (5 of 11) |
| Infantry | 36% (4 of 11) | 23% (3 of 13) | 0% (0 of 2) | 27% (7 of 26) |
| Monster | 25% (1 of 4) | - | - | 25% (1 of 4) |
| War Machines | 79% (15 of 19) | 100% (2 of 2) | - | 81% (17 of 21) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 75% (6 of 8); on the table 88% | 25% (25 of 102) | 37% | 59% (13 of 22) | 83% (5 of 6); 3.2 uses a game | 100% (2 of 2); 2.2 uses a game | 67% (4 of 6); 1.0 uses a game |
| Chaos Dwarfs | 4 | 0% (0 of 3); on the table 33% | 42% (15 of 36) | 57% | 59% (19 of 32) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |
| Dwarfen Mountain Holds | 1 | - | - | 100% | 43% (3 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 3 | 100% (3 of 3); on the table 100% | 33% (4 of 12) | 54% | 47% (14 of 30) | 0.0 uses a game | 100% (1 of 1); 0.3 uses a game | 0% (0 of 3); 0.0 uses a game |
| Grand Cathay | 1 | - | 58% (7 of 12) | 80% | 75% (6 of 8) | 100% (2 of 2); 5.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| High Elf Realms | 1 | - | 0% (0 of 6) | 100% | 62% (5 of 8) | 100% (1 of 1); 1.0 uses a game | 0% (0 of 2); 0.0 uses a game | 0.0 uses a game |
| Tomb Kings of Khemri | 1 | - | - | 17% | 0% (0 of 5) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 3 | 83% (15 of 18); on the table 83% | 42% (5 of 12) | 46% | 79% (15 of 19) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (h8-opp-6ec093a-p2, 9 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 50% (9) | 30% (3) | 43% (12) |
| ...free all their last turn and able to turn (per game) | 0.67 | 0.11 | 0.78 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.22 | 0.11 | 0.33 |
| ...with the charger already in that arc before they moved (per game) | 0.33 | 0.11 | 0.44 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.11 | 0.00 | 0.11 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.22 | 0.22 |

### Quality by phase: h8-opp-6ec093a-p2

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.4 | 2.7 |
| Strategy | Charge objectives carried out (made contact) | 68% (15 of 22) | 57% (13 of 23) |
| Strategy | Shoot objectives carried out (shot that target) | 47% (41 of 88) | 51% (43 of 84) |
| Strategy | Support requests answered (helper made contact too) | 67% (2 of 3) | 100% (3 of 3) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 50% (1 of 2) | - |
| Strategy | Hexes on a unit its side charged or shot that turn | - | 29% (2 of 7) |
| Strategy | Joined characters whose unit fought | 41% (9 of 22) | 44% (7 of 16) |
| Strategy | Lone characters that fought | 63% (12 of 19) | 61% (14 of 23) |
| Movement | Charges halted short of contact | 0.0 | 0.3 |
| Movement | Idle units | 1.9 | 1.6 |
| Movement | Points that never moved of their own | 113.8 | 181.6 |
| Movement | Fights charged into per game | 1.8 | 2.1 |
| Movement | Charges with odds: long shots (under 50%) | 3 of 14, net +133 | 3 of 19, net +0 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 14 | 2 of 19, net +0 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 2 of 14, net +99 | 5 of 19, net +92 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 4 of 14, net +34 | 4 of 19, net +94 |
| Shooting | Shots by shooting units (incl. breath weapons) | 7.2 | 8.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 38% (25 of 65) | 51% (37 of 72) |
| Shooting | Points destroyed by shooting units | 41.4 | 119.7 |
| Shooting | War machine shots | 5.4 | 4.1 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 57% (28 of 49) | 35% (13 of 37) |
| Shooting | Points destroyed by war machines | 50.0 | 68.9 |
| Magic | Magic missiles cast | 2.8 | 1.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 44% (11 of 25) | 17% (2 of 12) |
| Magic | Wounds caused by magic missiles | 6.7 | 1.2 |
| Magic | Wounds caused by other spells | 1.6 | 0.2 |
| Magic | Points destroyed by magic (all spells) | 55.2 | 18.4 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.3 / 0.0 / 0.8 / 0.0 | 1.8 / 0.8 / 0.3 / 0.2 |
| Combat | Points destroyed in combat | 135.3 | 133.0 |
| Combat | Points run down | 0.0 | 46.2 |
| Combat | Net points per charged fight, damage counted | +82 | +110 |
| Combat | Net per 100 charger points, damage counted | +31.6 | +34.9 |
| Combat | First round won (charged fights) | 88% | 84% |
| Combat | Net points per charged fight | +68 | +115 |
| Combat | Net points per supported fight / lone fight | +0 / +77 | +252 / +79 |
| Combat | Charged fights on a top-3 enemy unit | 2 of 16 | 7 of 19 |
| Game | Points lost | 487.0 | 395.3 |
| Game | VP from objectives | 731.1 | 861.1 |
| Game | Lone holders (player turns) | 3.3 | 3.7 |

- Mine won / drew / lost: 2 / 3 / 4 of 9 ended games (of 9); mean margin (Mine - Opponent) -245 VP
- The side that went first won 3 of 6 games with a winner
- Points traded per game (both sides' losses): 882
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: h8-opp-6ec093a-p2

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.2 | +33.3 | 0.0 | 0.0 | 0.2 | +40.6 | 0.0 | 0.0 |
| ALREADY CARRIED | 0.2 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARTILLERY RE-ROLL WEIGHED | 2.7 | +0.0 | 0.0 | 0.0 | 0.8 | +0.0 | 0.0 | 18.3 |
| BACKUP TARGETS | - | - | - | - | 0.1 | +0.1 | 0.0 | 0.0 |
| BEST OVERALL | 0.1 | +0.8 | 0.0 | 0.0 | - | - | - | - |
| BLOWS WHERE AIMED | 0.4 | -13.5 | 0.0 | 9.4 | 0.4 | -58.2 | 35.2 | 21.7 |
| BOMBING RUN | - | - | - | - | 0.1 | +2.9 | 0.0 | 0.0 |
| CANNON PLAN MISSED | 0.7 | +0.0 | 25.6 | 12.2 | 0.9 | +0.0 | 26.0 | 36.7 |
| CANNON PLANNED TARGET | 4.8 | +99.6 | 166.9 | 12.2 | 3.6 | +69.6 | 227.0 | 36.7 |
| CANNON SIGHT KEPT | 1.2 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT COUNTER | 0.1 | +0.0 | 5.6 | 0.0 | 0.1 | -14.4 | 0.0 | 0.0 |
| CARRIES OUT SET-UP | - | - | - | - | 0.2 | -3.2 | 24.3 | 0.0 |
| CAST JOB | 0.7 | +14.7 | 20.7 | 0.0 | 0.1 | +19.4 | 0.0 | 0.0 |
| CASTER AWAY FROM SCREEN | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CASTING BLOCK | 0.3 | +7.5 | 0.0 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | 1.9 | +0.0 | 0.0 | 14.4 | 0.2 | +0.0 | 0.0 | 44.4 |
| CASTS FROM BEHIND | - | - | - | - | 0.6 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | 0.2 | +4.6 | 0.0 | 15.1 | 0.2 | +5.0 | 0.0 | 8.0 |
| CHAFF PASSED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CHARACTER GUNS | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHARGE LOSSES | 6.1 | -362.5 | 0.0 | 181.9 | 5.9 | -282.1 | 0.0 | 106.7 |
| CHARGE NOT DECLARED | 0.8 | +0.0 | 15.2 | 53.3 | 0.2 | +0.0 | 9.4 | 5.6 |
| CHARGE NOW FIRST | 1.1 | +0.0 | 64.8 | 34.4 | 1.4 | +0.0 | 56.0 | 35.0 |
| CHARGER SLAIN LOST | 0.6 | -8.5 | 25.4 | 9.4 | 0.2 | -11.6 | 0.0 | 27.2 |
| CHEAPEST HOLDER | 0.3 | -15.7 | 6.7 | 0.0 | - | - | - | - |
| COMBAT PIVOT | 0.2 | +0.0 | 5.6 | 0.0 | - | - | - | - |
| CONVEYANCE SEARCH | 2.4 | +334.0 | 35.2 | 130.6 | 0.2 | +3.1 | 44.4 | 44.4 |
| COVER ONCE | 5.4 | -263.4 | 0.0 | 77.0 | 6.9 | -369.5 | 0.0 | 101.7 |
| DEPLOY BY FIGURES | 8.3 | -0.4 | 0.0 | 0.0 | 7.6 | -68.5 | 0.0 | 13.3 |
| EDGE GIVE GROUND | 0.1 | +0.8 | 8.6 | 9.4 | - | - | - | - |
| ENGINEER BY LORE | 0.4 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FALL BACK GOOD ORDER | 1.3 | +1.6 | 47.7 | 34.7 | 2.1 | +0.4 | 117.2 | 35.0 |
| FALLBACK BY WORTH | - | - | - | - | 0.7 | +0.0 | 0.0 | 4.0 |
| FALLS SHORT | 11.8 | +227.8 | 0.0 | 85.4 | 12.4 | +171.5 | 0.0 | 114.9 |
| FEATURE BUFFS | 2.7 | +71.0 | 0.0 | 3.3 | 0.7 | +19.7 | 0.0 | 6.7 |
| FIGHT TO THE END | 0.8 | +18.4 | 36.1 | 16.7 | 1.1 | +34.9 | 48.4 | 29.4 |
| FIRE IN ORDER | - | - | - | - | 0.6 | +0.0 | 19.4 | 7.3 |
| FIVE ACTION | 44.6 | +2367.5 | 358.6 | 531.6 | 47.7 | +3905.5 | 778.8 | 431.3 |
| FLANK NOT WEIGHED | 6.7 | +0.0 | 0.0 | 97.3 | 4.3 | +0.0 | 0.0 | 25.0 |
| FOLLOW UP WEIGHED | 0.1 | +61.6 | 0.0 | 0.0 | 0.6 | +109.0 | 0.0 | 5.6 |
| FOUR ROUNDS | 2.4 | +146.8 | 110.2 | 69.1 | 2.4 | +216.4 | 152.4 | 35.0 |
| FRIEND CHARGES FIRST | - | - | - | - | 0.1 | -2.1 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 0.6 | -2.6 | 0.0 | 0.0 | 0.3 | -19.7 | 13.0 | 0.0 |
| FRIENDS SHOTS CHECKED | - | - | - | - | 0.1 | +0.6 | 0.0 | 7.8 |
| GIVES UP | 0.2 | -13.9 | 19.0 | 0.0 | 0.1 | -3.3 | 21.0 | 0.0 |
| GROUND FLIERS | 0.1 | +1.7 | 0.0 | 0.0 | - | - | - | - |
| GUN FIGURES | 1.7 | +30.9 | 32.2 | 0.0 | 1.2 | +31.7 | 42.8 | 0.0 |
| GUN MASK | 0.3 | +4.2 | 0.0 | 0.0 | 1.3 | +51.4 | 0.0 | 0.0 |
| HARD STAY DROPPED | 1.7 | +0.0 | 0.0 | 0.0 | 1.2 | +0.0 | 0.0 | 8.6 |
| HE SHOOTS OR CHARGES | 1.7 | +0.0 | 0.0 | 7.2 | 2.1 | +0.0 | 0.0 | 0.0 |
| HELPER ALREADY ASKED | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HELPER UNSEEN | - | - | - | - | 0.1 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE DENIED | 0.7 | +10.3 | 11.7 | 0.0 | 0.4 | +90.6 | 79.0 | 7.8 |
| HIS CHARGE LIST | 3.0 | +0.0 | 0.0 | 13.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 2.4 | +0.0 | 0.0 | 40.4 | 4.1 | +0.0 | 0.0 | 42.7 |
| HIS MOVE AND SHOT | 1.4 | -11.7 | 0.0 | 115.2 | 1.8 | -52.0 | 0.0 | 28.0 |
| HIS ONE QUARTER | - | - | - | - | 1.2 | +0.0 | 0.0 | 7.6 |
| HIS RANDOM MOVE | - | - | - | - | 3.9 | +0.0 | 0.0 | 27.7 |
| HIS SHOT LIST | 18.7 | +712.2 | 0.0 | 254.6 | 23.2 | +1004.3 | 0.0 | 174.6 |
| HIS TURN DENIED | 0.9 | +194.4 | 54.4 | 52.4 | 0.8 | +24.2 | 24.4 | 21.7 |
| HOLD ODDS | - | - | - | - | 11.9 | +0.0 | 0.0 | 54.8 |
| HOLDER ASSIGNMENT | - | - | - | - | 13.4 | +1343.7 | 0.0 | 61.4 |
| HOLDER AT DEPLOYMENT | 1.1 | +197.2 | 0.0 | 0.0 | - | - | - | - |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 2.0 | -64.4 | 84.8 | 59.7 | 2.1 | -69.7 | 82.0 | 13.3 |
| HUNT IN PAIRS | - | - | - | - | 0.9 | +48.5 | 0.0 | 21.7 |
| IDLE COST | 4.8 | -51.7 | 0.0 | 24.6 | 8.2 | -132.6 | 0.0 | 75.7 |
| JOINT KNOWS CHALLENGE | 0.1 | -0.6 | 0.0 | 0.0 | 0.2 | -7.3 | 70.4 | 0.0 |
| KEEP FALLS | 0.1 | +0.5 | 0.0 | 0.0 | - | - | - | - |
| LANE BY FIGURES | 0.3 | +15.9 | 0.0 | 0.0 | 0.8 | +29.6 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 4.3 | +0.0 | 86.1 | 60.1 | 4.4 | +0.0 | 119.9 | 173.2 |
| LONE CHARACTER SAFE SPOT | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +5.0 | 0.0 | 0.0 |
| LONE WIZARD KEPT IN | 1.1 | +88.4 | 0.0 | 0.0 | 0.3 | +33.7 | 0.0 | 0.0 |
| LONG SHOT | 0.2 | +1.0 | 0.0 | 15.8 | - | - | - | - |
| LOST CHARGE | 0.3 | -0.8 | 6.7 | 8.6 | - | - | - | - |
| LURE BY WHAT IT DRAWS | - | - | - | - | 0.1 | -14.4 | 0.0 | 4.0 |
| MAKE SURE TOGETHER | 0.2 | +3.0 | 0.0 | 9.4 | - | - | - | - |
| MANOEUVRE | 1.2 | +16.0 | 0.0 | 3.3 | 1.2 | +15.1 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.4 | +1.5 | 0.0 | 0.0 | - | - | - | - |
| MARCH BY THE SUM | 0.3 | +35.7 | 0.0 | 0.0 | 0.3 | +49.4 | 0.0 | 0.0 |
| MARCH CHECK | 1.1 | +69.9 | 0.0 | 9.0 | 0.3 | +3.4 | 0.0 | 38.0 |
| MARCH OVER CASTS | 0.6 | +37.7 | 0.0 | 9.0 | 0.3 | -30.4 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 6.2 | +109.1 | 0.0 | 74.4 | 4.7 | +84.1 | 0.0 | 40.7 |
| MISSILES IN THE MOVE | 4.6 | +222.8 | 0.0 | 53.7 | 2.9 | +190.3 | 0.0 | 56.0 |
| MISSILES NEXT TURN | 5.9 | +163.8 | 0.0 | 101.3 | 3.7 | +89.7 | 0.0 | 100.4 |
| MOVE SPELL IN RANGE | 0.6 | +22.6 | 0.0 | 64.4 | - | - | - | - |
| MOVE SPELL NOT WORTH | 0.1 | -0.1 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.6 | -15.2 | 35.2 | 37.2 | - | - | - | - |
| MOVE SPELL SPOT | 1.2 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 44.4 |
| MOVE TO CHARGE COMPUTED | 2.3 | +238.1 | 0.0 | 19.4 | 4.8 | +512.5 | 0.0 | 21.7 |
| MOVES UNITS SPELL | 0.2 | +12.2 | 0.0 | 0.0 | - | - | - | - |
| NEARER NOT NEEDED | 4.1 | +192.4 | 0.0 | 23.2 | 7.4 | +289.4 | 0.0 | 15.9 |
| NEXT CHARGE BY LIST | 3.3 | -234.7 | 5.6 | 54.7 | 7.3 | -219.6 | 20.2 | 49.3 |
| NEXT OBJECTIVE NEARER | 5.9 | -300.4 | 0.0 | 44.2 | - | - | - | - |
| NO DOUBLE ROUNDS | 1.4 | -73.7 | 36.9 | 34.7 | 2.1 | -64.5 | 119.2 | 35.0 |
| NO RALLY LEFT | 0.1 | +4.6 | 0.0 | 0.0 | - | - | - | - |
| NOT TURNED | - | - | - | - | 0.2 | +0.0 | 0.0 | 4.0 |
| NOT WORTH A CAST | 0.1 | -0.1 | 0.0 | 0.0 | 0.9 | -0.3 | 0.0 | 0.0 |
| OFF BEST | 0.7 | -13.9 | 0.0 | 13.0 | 0.8 | -20.5 | 0.0 | 0.0 |
| ONE CHARGE A CHARGER | 3.3 | +0.0 | 0.0 | 26.0 | 1.7 | +0.0 | 0.0 | 5.6 |
| ONE FIGHT FORMULA | 3.2 | -58.3 | 0.0 | 35.0 | 5.8 | -129.6 | 0.0 | 21.7 |
| ONE OBJECTIVE FORMULA | 4.3 | -43.2 | 0.0 | 8.6 | 4.4 | -35.0 | 0.0 | 19.0 |
| ONE TARGET A SHOOTER | 16.2 | +490.2 | 0.0 | 94.1 | 14.4 | +431.0 | 0.0 | 89.0 |
| OPENS A LANE | - | - | - | - | 0.1 | +2.1 | 7.2 | 0.0 |
| OPENS UP | - | - | - | - | 0.2 | +15.8 | 24.4 | 0.0 |
| OVERRUNS AWAY | - | - | - | - | 0.3 | +83.0 | 33.2 | 0.0 |
| PATHS CROSS | 4.0 | +165.0 | 0.0 | 25.7 | 4.4 | +148.3 | 0.0 | 54.6 |
| PIVOT GUARDS FLANK | - | - | - | - | 0.1 | -2.7 | 0.0 | 0.0 |
| PLAN RESULT | 38.6 | +466.6 | 386.6 | 697.8 | 43.1 | +548.9 | 336.8 | 652.1 |
| QUARTER ODDS | - | - | - | - | 8.1 | +1139.7 | 241.9 | 65.8 |
| RANDOM MOVE BY FIGURES | 1.3 | +20.3 | 0.0 | 0.0 | - | - | - | - |
| REAL GROUND | - | - | - | - | 0.4 | +0.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | 2.4 | +219.3 | 0.0 | 36.4 | 1.3 | +46.2 | 0.0 | 6.7 |
| REFORMS TO MEET IT | 0.3 | -52.3 | 0.0 | 0.0 | 0.7 | -20.8 | 0.0 | 0.0 |
| REFUSING RETIRES | 0.6 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | 0.2 | +14.1 | 0.0 | 0.0 | 0.8 | +17.1 | 0.0 | 0.0 |
| RISK BY ARC | 1.7 | +38.8 | 86.6 | 34.7 | 1.4 | -42.6 | 66.8 | 35.0 |
| RISK BY HIS FIGURE | 13.8 | -329.9 | 0.0 | 286.3 | 11.3 | -146.1 | 0.0 | 88.8 |
| RISK ON THE WAY | - | - | - | - | 0.2 | +0.0 | 0.0 | 0.0 |
| RUN DOWN | 1.1 | -7.6 | 54.4 | 53.3 | 2.0 | -13.1 | 117.2 | 35.0 |
| SAFER THAN THE JOB | 0.1 | +0.8 | 0.0 | 0.0 | - | - | - | - |
| SAME CHARGE LATER | 0.2 | -9.9 | 20.7 | 0.0 | 0.1 | -0.5 | 0.0 | 0.0 |
| SCOUT SPOT | 0.2 | +0.8 | 0.0 | 0.0 | 0.4 | -0.1 | 0.0 | 0.0 |
| SCOUT WAITS | 0.2 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 0.2 | -27.8 | 0.0 | 8.0 |
| SEARCH SPOT | 6.0 | +282.0 | 0.0 | 18.4 | 4.8 | +255.7 | 0.0 | 21.0 |
| SET UP TOGETHER | 0.2 | +3.0 | 0.0 | 9.4 | - | - | - | - |
| SET-UP ANY TARGET | 0.3 | +62.6 | 0.0 | 64.4 | 0.1 | +3.2 | 0.0 | 0.0 |
| SET-UP MISSED | 0.1 | +9.6 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | 0.2 | +0.4 | 0.0 | 0.0 | - | - | - | - |
| SHOOTS FROM THE BEST SPOT | 1.6 | +51.1 | 25.7 | 18.9 | 0.9 | +59.8 | 146.9 | 0.0 |
| SHORT GUN FORWARD | - | - | - | - | 0.2 | +0.0 | 0.0 | 0.0 |
| SHOT OR CHARGE | 0.4 | -4.9 | 12.6 | 0.0 | 0.3 | -64.4 | 35.2 | 36.7 |
| SHOT RISK POINTS | 9.8 | -14.5 | 0.0 | 168.9 | 12.9 | +45.1 | 0.0 | 163.7 |
| SHOTS IN THE MOVE | 12.4 | +411.1 | 0.0 | 106.7 | 15.0 | +640.0 | 0.0 | 161.1 |
| SPELL SETS UP CHARGE | 1.0 | +369.0 | 0.0 | 78.9 | 0.1 | +3.2 | 0.0 | 0.0 |
| SPELL WORTH | 0.4 | +1.5 | 0.0 | 39.4 | 1.3 | +18.9 | 44.4 | 44.4 |
| SPELLS IN THE FIGHT | 0.3 | +0.0 | 5.6 | 7.2 | 0.6 | -30.6 | 35.2 | 21.7 |
| STAND AND SHOOT | 0.2 | -3.2 | 0.0 | 34.4 | 0.2 | -4.4 | 0.0 | 0.0 |
| STANDS FOR A REASON | 0.4 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 17.7 | +0.0 | 248.3 | 228.8 | 16.4 | +0.0 | 626.3 | 150.8 |
| STAY WORTH | 15.7 | +92.1 | 188.9 | 67.8 | 17.4 | +197.9 | 309.9 | 217.4 |
| SUPPORT NARROWED | 1.2 | +0.0 | 60.9 | 59.7 | 1.0 | +0.0 | 25.8 | 27.2 |
| SURE REACH TOGETHER | 0.3 | +4.1 | 0.0 | 0.0 | 0.2 | +0.4 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 4.0 | +0.0 | 0.0 | 41.2 | 4.6 | +0.0 | 0.0 | 54.6 |
| THE PROMISE ADDS | 0.1 | -11.5 | 0.0 | 0.0 | 0.2 | -77.2 | 35.2 | 0.0 |
| THE PROMISED MOVE | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| TIED UP BY THE SUM | 0.7 | +48.8 | 28.8 | 9.4 | 0.6 | +65.0 | 46.0 | 0.0 |
| TIME ON OUR SIDE | 18.1 | +306.4 | 0.0 | 157.6 | 14.3 | +262.4 | 0.0 | 46.6 |
| WAITS AGAIN | 0.3 | +0.0 | 0.0 | 0.0 | 1.4 | +0.0 | 0.0 | 0.0 |
| WAR ENGINE CHARGES | 0.2 | +9.5 | 5.6 | 34.4 | - | - | - | - |
| WAR ENGINE JOBS | 0.6 | +0.0 | 11.1 | 0.0 | 0.1 | +0.0 | 64.4 | 0.0 |
| WHO HITS BACK | 0.1 | +8.7 | 0.0 | 9.4 | 0.2 | +29.0 | 0.0 | 0.0 |
| WHOLE FIGHT | 0.2 | -1.1 | 31.0 | 0.0 | 0.2 | +7.7 | 21.0 | 0.0 |
| WHOLE FIGHT GAIN | 0.3 | +11.8 | 0.0 | 0.0 | 0.1 | +0.4 | 35.2 | 0.0 |
| WIDER SPREAD | 2.0 | -1.4 | 102.7 | 60.6 | 1.9 | +2.6 | 104.4 | 35.0 |
| WOUNDS ON THE RANKS | 2.0 | +136.9 | 0.0 | 70.4 | 2.1 | +59.7 | 0.0 | 7.6 |

### Rule changes: h8-opp-6ec093a-p2

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HOLDER ASSIGNMENT | 121 | 121 | 112 | 12.44 | +7241 | +64.7 |
| DEPLOY BY FIGURES | 143 | 143 | 85 | 9.44 | +1314 | +15.5 |
| SEARCH SPOT | 97 | 97 | 85 | 9.44 | +4839 | +56.9 |
| HIS SHOT LIST | 377 | 377 | 81 | 9.00 | +1597 | +19.7 |
| LEGAL CHARGES ONLY | 79 | 79 | 79 | 8.78 | +0 | +0.0 |
| TIME ON OUR SIDE | 292 | 264 | 78 | 8.67 | +407 | +5.2 |
| ONE TARGET A SHOOTER | 276 | 276 | 76 | 8.44 | +876 | +11.5 |
| PATHS CROSS | 76 | 76 | 76 | 8.44 | +2820 | +37.1 |
| FIVE ACTION | 830 | 828 | 48 | 5.33 | +2450 | +51.0 |
| MOVE TO CHARGE COMPUTED | 64 | 64 | 36 | 4.00 | +2030 | +56.4 |
| ARTILLERY RE-ROLL WEIGHED | 31 | 31 | 31 | 3.44 | +0 | +0.0 |
| SHOT RISK POINTS | 204 | 204 | 31 | 3.44 | +765 | +24.7 |
| HARD STAY DROPPED | 26 | 26 | 26 | 2.89 | +0 | +0.0 |
| FOUR ROUNDS | 44 | 42 | 19 | 2.11 | +1045 | +55.0 |
| COVER ONCE | 111 | 86 | 18 | 2.00 | +147 | +8.2 |
| FALLS SHORT | 218 | 180 | 18 | 2.00 | +183 | +10.2 |
| MAX FOR POSITIONING | 98 | 94 | 18 | 2.00 | +45 | +2.5 |
| CANNON SIGHT KEPT | 14 | 14 | 14 | 1.56 | +0 | +0.0 |
| CHARGE LOSSES | 108 | 108 | 14 | 1.56 | +1517 | +108.4 |
| QUARTER ODDS | 73 | 73 | 14 | 1.56 | +1422 | +101.6 |
| RISK BY HIS FIGURE | 226 | 226 | 14 | 1.56 | +962 | +68.7 |
| SHOTS IN THE MOVE | 247 | 222 | 14 | 1.56 | +534 | +38.2 |
| LONE WIZARD KEPT IN | 13 | 13 | 13 | 1.44 | +1099 | +84.5 |
| MISSILES IN THE MOVE | 67 | 48 | 13 | 1.44 | +406 | +31.2 |
| OFF BEST | 13 | 13 | 13 | 1.44 | -309 | -23.8 |
| SHOOTS FROM THE BEST SPOT | 22 | 22 | 13 | 1.44 | +256 | +19.7 |
| IDLE COST | 117 | 96 | 12 | 1.33 | +136 | +11.3 |
| WOUNDS ON THE RANKS | 37 | 37 | 12 | 1.33 | +402 | +33.5 |
| CANNON PLANNED TARGET | 75 | 75 | 11 | 1.22 | -72 | -6.6 |
| NEXT OBJECTIVE NEARER | 53 | 53 | 11 | 1.22 | +137 | +12.5 |
| LANE BY FIGURES | 10 | 10 | 10 | 1.11 | +410 | +41.0 |
| MANOEUVRE | 22 | 22 | 10 | 1.11 | +285 | +28.5 |
| MARCH CHECK | 13 | 13 | 10 | 1.11 | +141 | +14.1 |
| ADVANCE LANE KEPT | 9 | 9 | 9 | 1.00 | +0 | +0.0 |
| CASTER AWAY FROM SCREEN | 9 | 9 | 9 | 1.00 | +0 | +0.0 |
| CHARGE NOT DECLARED | 9 | 9 | 9 | 1.00 | -662 | -73.6 |
| RESERVE FALL BACK | 9 | 9 | 9 | 1.00 | +281 | +31.3 |
| REDIRECT COUNTER | 34 | 32 | 8 | 0.89 | +750 | +93.8 |
| STAY WORTH | 298 | 281 | 8 | 0.89 | +324 | +40.5 |
| FEATURE BUFFS | 30 | 30 | 7 | 0.78 | +114 | +16.3 |
| RISK BY ARC | 28 | 27 | 7 | 0.78 | +141 | +20.2 |
| FOLLOW UP WEIGHED | 6 | 6 | 6 | 0.67 | +1535 | +255.8 |
| HIS TURN DENIED | 15 | 15 | 6 | 0.67 | +1101 | +183.5 |
| HOLDER AT DEPLOYMENT | 10 | 10 | 6 | 0.67 | +265 | +44.2 |
| HOLDS AMBUSHERS | 6 | 6 | 6 | 0.67 | +0 | +0.0 |
| MARCH BY THE SUM | 6 | 6 | 6 | 0.67 | +766 | +127.7 |
| NEXT CHARGE BY LIST | 96 | 96 | 6 | 0.67 | +204 | +34.1 |
| SCOUT WAITS | 6 | 6 | 6 | 0.67 | +0 | +0.0 |
| CASTS FROM BEHIND | 5 | 5 | 5 | 0.56 | +0 | +0.0 |
| FIRE IN ORDER | 5 | 5 | 5 | 0.56 | +0 | +0.0 |
| ONE OBJECTIVE FORMULA | 79 | 66 | 5 | 0.56 | +139 | +27.9 |
| RANDOM MOVE BY FIGURES | 12 | 12 | 5 | 0.56 | +183 | +36.5 |
| TIED UP BY THE SUM | 11 | 10 | 5 | 0.56 | +148 | +29.6 |
| AFTERMATH IN POINTS | 4 | 4 | 4 | 0.44 | +665 | +166.3 |
| CAST JOB | 7 | 7 | 3 | 0.33 | +168 | +56.1 |
| CHAFF IN THE MOVE | 4 | 4 | 3 | 0.33 | +30 | +10.1 |
| CHAFF PASSED | 3 | 3 | 3 | 0.33 | +0 | +0.0 |
| CHARGE NOW FIRST | 23 | 23 | 3 | 0.33 | -72 | -24.1 |
| GUN MASK | 15 | 15 | 3 | 0.33 | +25 | +8.5 |
| WAR ENGINE JOBS | 6 | 6 | 3 | 0.33 | -31 | -10.2 |
| WHO HITS BACK | 3 | 3 | 3 | 0.33 | +190 | +63.3 |
| COMBAT PIVOT | 2 | 2 | 2 | 0.22 | +0 | +0.0 |
| FIGHT TO THE END | 17 | 17 | 2 | 0.22 | +228 | +114.0 |
| MISSILES NEXT TURN | 86 | 62 | 2 | 0.22 | +12 | +5.9 |
| MOVES UNITS SPELL | 2 | 2 | 2 | 0.22 | +110 | +55.1 |
| ONE FIGHT FORMULA | 81 | 37 | 2 | 0.22 | +7 | +3.7 |
| OPENS UP | 2 | 2 | 2 | 0.22 | +114 | +57.1 |
| OVERRUNS AWAY | 3 | 3 | 2 | 0.22 | +90 | +45.1 |
| REFUSING RETIRES | 8 | 8 | 2 | 0.22 | -0 | -0.1 |
| SHOOTERS IN TWO RANKS | 2 | 2 | 2 | 0.22 | +4 | +2.0 |
| SHORT GUN FORWARD | 2 | 2 | 2 | 0.22 | +0 | +0.0 |
| BEST OVERALL | 1 | 1 | 1 | 0.11 | +7 | +6.8 |
| BOMBING RUN | 1 | 1 | 1 | 0.11 | +26 | +26.0 |
| CARRIES OUT COUNTER | 2 | 2 | 1 | 0.11 | -130 | -129.8 |
| CARRIES OUT SET-UP | 2 | 2 | 1 | 0.11 | -29 | -28.7 |
| FRIENDS SHOTS CHECKED | 1 | 1 | 1 | 0.11 | +5 | +5.4 |
| HIS CHARGE DENIED | 10 | 10 | 1 | 0.11 | +357 | +357.0 |
| HUNT IN PAIRS | 8 | 4 | 1 | 0.11 | +0 | +0.0 |
| KEEP FALLS | 1 | 1 | 1 | 0.11 | +10 | +9.7 |
| NEARER NOT NEEDED | 104 | 100 | 1 | 0.11 | +38 | +37.7 |
| NO RALLY LEFT | 1 | 1 | 1 | 0.11 | +40 | +40.2 |
| PIVOT GUARDS FLANK | 1 | 1 | 1 | 0.11 | -24 | -24.4 |
| SAFER THAN THE JOB | 1 | 1 | 1 | 0.11 | +7 | +6.8 |
| SPELLS IN THE FIGHT | 8 | 7 | 1 | 0.11 | +2 | +2.2 |
| SUPPORT NARROWED | 20 | 20 | 1 | 0.11 | -5 | -5.3 |
| THE PROMISE ADDS | 3 | 3 | 1 | 0.11 | +13 | +12.8 |
| WAR ENGINE CHARGES | 2 | 2 | 1 | 0.11 | +24 | +23.7 |
| WHOLE FIGHT | 4 | 4 | 1 | 0.11 | +34 | +34.5 |
| WHOLE FIGHT GAIN | 4 | 4 | 1 | 0.11 | +26 | +25.9 |
| WIDER SPREAD | 35 | 34 | 1 | 0.11 | +6 | +6.4 |
| ALREADY CARRIED | 2 | not checked | - | - | - | - |
| BACKUP TARGETS | 1 | not checked | - | - | - | - |
| BLOWS WHERE AIMED | 8 | 8 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 14 | 14 | 0 | 0.00 | - | - |
| CASTING BLOCK | 3 | 3 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 19 | trace | - | - | - | - |
| CHARACTER GUNS | 1 | 1 | 0 | 0.00 | - | - |
| CHARGER SLAIN LOST | 7 | 7 | 0 | 0.00 | - | - |
| CHEAPEST HOLDER | 3 | 3 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 24 | not checked | - | - | - | - |
| EDGE GIVE GROUND | 1 | 1 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 31 | 29 | 0 | 0.00 | - | - |
| FALLBACK BY WORTH | 6 | 6 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 99 | not checked | - | - | - | - |
| FRIEND CHARGES FIRST | 1 | 1 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 8 | 8 | 0 | 0.00 | - | - |
| GIVES UP | 3 | 3 | 0 | 0.00 | - | - |
| GROUND FLIERS | 1 | not checked | - | - | - | - |
| GUN FIGURES | 26 | not checked | - | - | - | - |
| HE SHOOTS OR CHARGES | 34 | 34 | 0 | 0.00 | - | - |
| HELPER ALREADY ASKED | 1 | not checked | - | - | - | - |
| HELPER UNSEEN | 1 | 1 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 45 | 45 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 59 | 59 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 29 | 29 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 11 | 11 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 35 | 35 | 0 | 0.00 | - | - |
| HOLD ODDS | 107 | 107 | 0 | 0.00 | - | - |
| HONEST WORTH | 37 | 35 | 0 | 0.00 | - | - |
| JOINT KNOWS CHALLENGE | 3 | 3 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 2 | not checked | - | - | - | - |
| LONG SHOT | 2 | 2 | 0 | 0.00 | - | - |
| LOST CHARGE | 3 | 3 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 1 | 1 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 2 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 4 | trace | - | - | - | - |
| MARCH OVER CASTS | 8 | 8 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 5 | 5 | 0 | 0.00 | - | - |
| MOVE SPELL NOT WORTH | 1 | not checked | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 5 | trace | - | - | - | - |
| MOVE SPELL SPOT | 13 | not checked | - | - | - | - |
| NO DOUBLE ROUNDS | 32 | 30 | 0 | 0.00 | - | - |
| NOT TURNED | 2 | 2 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 9 | not checked | - | - | - | - |
| ONE CHARGE A CHARGER | 45 | 45 | 0 | 0.00 | - | - |
| OPENS A LANE | 1 | 1 | 0 | 0.00 | - | - |
| PLAN RESULT | 735 | trace | - | - | - | - |
| REAL GROUND | 4 | 4 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 9 | 9 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 2 | 2 | 0 | 0.00 | - | - |
| RUN DOWN | 28 | 26 | 0 | 0.00 | - | - |
| SAME CHARGE LATER | 3 | 3 | 0 | 0.00 | - | - |
| SCOUT SPOT | 6 | 6 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 2 | 2 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 2 | 1 | 0 | 0.00 | - | - |
| SET-UP ANY TARGET | 4 | not checked | - | - | - | - |
| SET-UP MISSED | 1 | trace | - | - | - | - |
| SHOT OR CHARGE | 7 | 7 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 10 | not checked | - | - | - | - |
| SPELL WORTH | 16 | not checked | - | - | - | - |
| STAND AND SHOOT | 4 | 4 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 5 | 5 | 0 | 0.00 | - | - |
| STANDS STILL | 307 | 307 | 0 | 0.00 | - | - |
| SURE REACH TOGETHER | 5 | 5 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 77 | not checked | - | - | - | - |
| THE PROMISED MOVE | 9 | not checked | - | - | - | - |
| WAITS AGAIN | 16 | 16 | 0 | 0.00 | - | - |

### Off best figure: h8-opp-6ec093a-p2

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| CHARGE NOT DECLARED | rule | 0.78 | 0.22 | 73.6 |
| HOLDER ASSIGNMENT | rule | - | 1.00 | 22.2 |
| JOB FIRST | gate | 0.33 | 0.67 | 25.3 |
| PATHS CROSS | rule | 0.22 | 0.44 | 24.1 |
| CHARGE NOW FIRST | rule | 0.22 | 0.11 | 24.1 |
| AFTERMATH BAND | gate | 0.11 | 0.11 | 1.0 |
| WAR ENGINE JOBS | rule | 0.22 | - | 15.1 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.11 | - | 78.1 |
| CANNON PLANNED TARGET | rule | - | 0.11 | 72.1 |
| CARRIES OUT COUNTER | rule | - | 0.11 | 129.8 |
| CARRIES OUT SET-UP | rule | - | 0.11 | 28.7 |
| PIVOT GUARDS FLANK | rule | - | 0.11 | 24.4 |
| RULE SWITCHED OFF | gate | 0.11 | - | 1.8 |
| SUPPORT NARROWED | rule | - | 0.11 | 5.3 |

### Plans: h8-opp-6ec093a-p2

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.6 | 64% | 318 | 97 | 30% |
| Mine | join | 0.3 | 100% | 11 | 0 | 0% |
| Mine | move | 28.4 | 96% | 1550 | 0 | 0% |
| Mine | shoot | 8.2 | 47% | 310 | 370 | 119% |
| Opponent | charge | 2.0 | 50% | 283 | 127 | 45% |
| Opponent | join | 1.6 | 100% | 68 | 0 | 0% |
| Opponent | move | 31.3 | 95% | 2090 | 0 | 0% |
| Opponent | shoot | 7.9 | 55% | 439 | 422 | 96% |
| Opponent | support | 0.3 | 67% | 0 | 0 | - |

### Battle groups: h8-opp-6ec093a-p2

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 2.4 | 41% | 78% | 0% | - | 33% | 0% | 0% | 67% | 0% |
| Opponent | REDIRECT COUNTER | 1.3 | 8% | 100% | 0% | - | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: h8-opp-6ec093a-p2

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 8 | 6 (8) | 0 | 6 | 39 | 62% | 2.7 | 0 (2) | 12 (3) | 0 (3) | 13 (4) | 0 (4) |
| Mine | Character | 36 | 20 (36) | 20 | 0 | 32 | 14% | 2.6 | 32 (8) | 12 (17) | 40 (4) | 36 (7) | 13 (22) |
| Mine | Clean-up | 11 | 94 (11) | 0 | 94 | 26 | 64% | 3.5 | 120 (4) | 122 (4) | 34 (3) | 124 (7) | 0 (4) |
| Mine | Fast Hammer | 4 | 108 (4) | 108 | 0 | 75 | 0% | 3.8 | 170 (2) | 45 (2) | - | 71 (1) | 120 (3) |
| Mine | Hammer | 24 | 46 (24) | 20 | 27 | 14 | 17% | 3.0 | 54 (4) | 58 (15) | 9 (5) | 44 (7) | 47 (17) |
| Mine | Holder | 9 | 32 (9) | 0 | 32 | 29 | 67% | 4.0 | 220 (1) | 15 (6) | 0 (2) | 56 (3) | 16 (6) |
| Mine | Shooter | 4 | 288 (4) | 0 | 288 | 50 | 0% | 2.0 | 508 (1) | 138 (2) | 369 (1) | 338 (3) | 138 (1) |
| Mine | War machine | 13 | 27 (13) | 27 | 0 | 37 | 0% | 1.1 | 38 (8) | 8 (5) | - | 20 (2) | 28 (11) |
| Mine | Wizard | 5 | 0 (5) | 0 | 0 | 36 | 20% | 4.0 | 0 (1) | 0 (4) | - | - | 0 (5) |
| Opponent | Chaff | 14 | 179 (14) | 15 | 165 | 38 | 50% | 3.0 | 203 (3) | 220 (5) | 124 (6) | 207 (12) | 0 (2) |
| Opponent | Character | 31 | 27 (31) | 27 | 0 | 12 | 32% | 3.1 | 15 (13) | 41 (14) | 0 (4) | 39 (20) | 14 (11) |
| Opponent | Clean-up | 5 | 10 (5) | 0 | 10 | 41 | 40% | 2.0 | 38 (1) | 0 (4) | - | 12 (4) | 0 (1) |
| Opponent | Fast | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Fast Hammer | 15 | 28 (15) | 4 | 24 | 20 | 40% | 3.8 | 40 (8) | 17 (7) | - | 41 (9) | 13 (6) |
| Opponent | Hammer | 4 | 122 (4) | 70 | 52 | 0 | 25% | 3.0 | - | 165 (3) | 16 (1) | 122 (4) | - |
| Opponent | Holder | 5 | 42 (5) | 0 | 42 | 19 | 60% | 3.0 | - | 56 (4) | 0 (1) | - | 42 (5) |
| Opponent | Shooter | 11 | 114 (11) | 67 | 47 | 50 | 9% | 1.7 | 173 (4) | 133 (3) | 21 (4) | 184 (5) | 23 (6) |
| Opponent | Support | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | War machine | 15 | 29 (15) | 29 | 0 | 31 | 0% | 2.7 | 27 (5) | 39 (6) | 16 (4) | 44 (3) | 26 (12) |
| Opponent | Wizard | 8 | 0 (8) | 0 | 0 | 19 | 25% | 3.7 | 0 (3) | 0 (2) | 0 (2) | 0 (6) | 0 (1) |

### Charged fights: h8-opp-6ec093a-p2

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 65 | 201 | 2.2 | 1.2 | 89 | 9 | +81 | 1 of 9 | 7 of 9 | +0 | +91 |
| Mine | Chaos Dwarfs | 4 | 127 | 105 | 1.8 | 1.1 | 60 | 9 | +51 | 1 of 7 | 7 of 7 | +0 | +59 |
| Mine | Dwarfen Mountain Holds | 1 | 551 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| **Mine** | all armies | 9 | 147 | 136 | 1.8 | 1.2 | 76 | 9 | +68 | 2 of 16 | 14 of 16 | +0 | +77 |
| Opponent | Empire of Man | 3 | 327 | 313 | 1.7 | 1.2 | 188 | 0 | +188 | 2 of 5 | 4 of 5 | +886 | +13 |
| Opponent | Grand Cathay | 1 | 580 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 1 of 1 | 0 of 1 | - | +0 |
| Opponent | High Elf Realms | 1 | 182 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Tomb Kings of Khemri | 1 | 120 | 485 | 3.0 | 1.7 | 162 | 65 | +97 | 2 of 3 | 3 of 3 | -65 | +178 |
| Opponent | Vampire Counts | 3 | 0 | 321 | 3.3 | 1.3 | 96 | 0 | +96 | 2 of 10 | 9 of 10 | +94 | +97 |
| **Opponent** | all armies | 9 | 207 | 265 | 2.1 | 1.3 | 126 | 10 | +115 | 7 of 19 | 16 of 19 | +252 | +79 |

### Effective charges: h8-opp-6ec093a-p2

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 9 | 2 (net +114) | 0 | 0 | 1 (net +0) | 0 | 4 (net +34) | 2 | 0% (0 of 7) |
| Mine | Chaos Dwarfs | 7 | 1 (net +171) | 0 | 0 | 4 (net -4) | 2 (net +99) | 0 | 0 | 0% (0 of 7) |
| Opponent | Empire of Man | 5 | 1 (net +0) | 0 | 0 | 1 (net +886) | 2 (net +26) | 1 (net +0) | 0 | 0% (0 of 5) |
| Opponent | Grand Cathay | 1 | 1 (net +0) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 1) |
| Opponent | Tomb Kings of Khemri | 3 | 0 | 0 | 0 | 1 (net +0) | 0 | 2 (net +145) | 0 | 0% (0 of 3) |
| Opponent | Vampire Counts | 10 | 1 (net +0) | 0 | 2 (net +0) | 3 (net +156) | 3 (net +137) | 1 (net +85) | 0 | 20% (2 of 10) |

### Charged fights, damage counted: h8-opp-6ec093a-p2

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 3 | 159 | 154 | +133 | 133 | 12 | +122 | +76.8 |
| Mine | 76-89% | 5 | 314 | 130 | -3 | 38 | 25 | +13 | +4.2 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 4 | 83 | 68 | +34 | 55 | 19 | +36 | +42.8 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 2 | 310 | 56 | +99 | 99 | 0 | +99 | +31.9 |
| Mine | No odds | 2 | 576 | 278 | +180 | 273 | 4 | +269 | +46.7 |
| Mine | All fights | 16 | 259 | 128 | +68 | 97 | 15 | +82 | +31.6 |
| Opponent | Long shot (under 50%) | 3 | 253 | 282 | +0 | 16 | 102 | -86 | -34.1 |
| Opponent | Effective (55-75%) | 2 | 354 | 339 | +0 | 0 | 0 | +0 | +0.0 |
| Opponent | 76-89% | 5 | 223 | 135 | +271 | 329 | 9 | +320 | +143.2 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 4 | 373 | 203 | +94 | 154 | 79 | +75 | +20.1 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 5 | 377 | 83 | +92 | 92 | 4 | +88 | +23.4 |
| Opponent | All fights | 19 | 314 | 180 | +115 | 146 | 36 | +110 | +34.9 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| h8-opp-6ec093a-p2 | move | 60 | 12 (20%) | 10 (17%) | 7 (12%) | 41 (68%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0108, L0123 |
| Charmed Shield | Opponent | L0224, L0325, L0427 |
| Elixir of Power | Opponent | L0411 |
| Invocation of Nehek | Opponent | L0224, L0325, L0427 |
| Ring of Doom | Mine | L0207, L0224 |
| Ring of Doom | Opponent | L0411 |
| Ring of Jet | Opponent | L0411 |
| Standard of the Fell Warrior | Opponent | L0513 |
| Twice-Blessed Armour | Opponent | L0207 |
| Witch Hunter's Ward | Opponent | L0108, L0207, L0308 |

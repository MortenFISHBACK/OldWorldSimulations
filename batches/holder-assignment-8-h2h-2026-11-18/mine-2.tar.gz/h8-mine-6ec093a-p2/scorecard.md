# Doctrine scorecard: h8-mine-6ec093a-p2

### Scorecard: h8-mine-6ec093a-p2

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0108 | 6 | 1 | Mine | no | 7 | - | 0 | 2 | 0 | 0 | 0 | 55 |
| L0108 | 6 | 1 | Opponent | yes | 0 | 2 | 2 | 1 | 0 | 0 | 0 | 225 |
| L0123 | 3 | 1 | Mine | no | 5 | 6 | 1 | 2 | 0 | 0 | 0 | 55 |
| L0123 | 3 | 1 | Opponent | no | 0 | 2 | 2 | 2 | 0 | 0 | 0 | 0 |
| L0207 | 3 | 1 | Mine | no | 8 | - | 0 | 6 | 0 | 0 | 0 | 170 |
| L0207 | 3 | 1 | Opponent | no | 1 | 2 | 1 | 0 | 0 | 0 | 0 | 0 |
| L0224 | 2 | 1 | Mine | - | - | 5 | 3 | 5 | 0 | 0 | 0 | 85 |
| L0224 | 2 | 1 | Opponent | - | - | 5 | 1 | 1 | 0 | 0 | 0 | 0 |
| L0308 | 2 | 1 | Mine | - | - | 2 | 0 | 2 | 0 | 0 | 0 | 0 |
| L0308 | 2 | 1 | Opponent | - | - | - | 0 | 3 | 0 | 0 | 0 | 430 |
| L0325 | 1 | 1 | Mine | no | 1 | - | 0 | 0 | 0 | 0 | 0 | 110 |
| L0325 | 1 | 1 | Opponent | no | 2 | 2 | 1 | 3 | 0 | 0 | 0 | 0 |
| L0411 | 3 | 1 | Mine | no | 0 | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L0411 | 3 | 1 | Opponent | yes | 8 | 4 | 1 | 0 | 0 | 0 | 0 | 0 |
| L0427 | 1 | 1 | Mine | no | 0 | 2 | 1 | 2 | 0 | 0 | 0 | 65 |
| L0427 | 1 | 1 | Opponent | no | 0 | 1 | 5 | 4 | 0 | 0 | 0 | 0 |
| L0513 | 3 | 1 | Mine | no | 0 | 6 | 0 | 1 | 0 | 0 | 0 | 544 |
| L0513 | 3 | 1 | Opponent | no | 4 | 3 | 1 | 0 | 0 | 0 | 0 | 140 |
| L0530 | 2 | 1 | Mine | - | - | - | 1 | 1 | 0 | 0 | 0 | 595 |
| L0530 | 2 | 1 | Opponent | - | - | 3 | 2 | 2 | 0 | 0 | 0 | 0 |
| L0618 | 6 | 1 | Mine | no | 3 | - | 0 | 2 | 1 | 0 | 0 | 280 |
| L0618 | 6 | 1 | Opponent | no | 12 | - | 0 | 3 | 0 | 0 | 0 | 185 |
| L0633 | 3 | 1 | Mine | yes | 9 | 4 | 3 | 2 | 0 | 0 | 0 | 350 |
| L0633 | 3 | 1 | Opponent | no | 0 | 3 | 1 | 4 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 11% | 3.7 | 3.9 | 1.1 | 2.2 | 0.1 | 0.0 | 0.0 | 192.4 |
| **Average** | | | Opponent | 22% | 3.0 | 2.7 | 1.4 | 1.9 | 0.0 | 0.0 | 0.0 | 81.7 |

### KPIs: h8-mine-6ec093a-p2

Rules off - Opponent only: HOLDER ASSIGNMENT, QUARTER ODDS, WALK PROMISE, REAL GROUND, RISK ON THE WAY.

Morten 2026-11-10; 12 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 47% (24 of 51) | 18% (10 of 56) | 32% (34 of 107) |
| Winner chose to follow up after the loser gave ground |  | 89% (8 of 9); on the table 100% | 70% (7 of 10); on the table 90% | 79% (15 of 19); on the table 95% |
| Winner chose to pursue after the loser fell back in good order |  | 100% (4 of 4); on the table 100% | 86% (6 of 7); on the table 86% | 91% (10 of 11); on the table 91% |
| Winner chose to pursue after the loser fled |  | 67% (2 of 3); on the table 67% | 83% (10 of 12); on the table 83% | 80% (12 of 15); on the table 80% |
| Winner chose to follow up or pursue (all three) |  | 88% (14 of 16); on the table 94% | 79% (23 of 29); on the table 86% | 82% (37 of 45); on the table 89% |
| Magic missiles tried each own turn | 50%+ | 53% (73 of 138) | 40% (19 of 48) | 49% (92 of 186) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 60% (73 of 122) | 46% (19 of 41) | 56% (92 of 163) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 58% (7 of 12) | - | 58% (7 of 12) |
| Points that never fought | lower | 64% (15046 of 23594) | 58% (13865 of 23995) | 61% (28911 of 47589) |
|   infantry points that never fought | lower | 61% (4500 of 7332) | 59% (2508 of 4287) | 60% (7008 of 11619) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 61% (54 of 88) | 60% (56 of 93) | 61% (110 of 181) |
| Bound items with a magic missile used (at least once a game) |  | 83% (5 of 6); 1.6 uses a game | 100% (6 of 6); 1.8 uses a game | 92% (11 of 12); 1.7 uses a game |
| Bound items with another spell used |  | 100% (2 of 2); 0.8 uses a game | 33% (1 of 3); 0.2 uses a game | 60% (3 of 5); 0.5 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 62% (5 of 8); 0.4 uses a game | 50% (3 of 6); 0.2 uses a game | 57% (8 of 14); 0.3 uses a game |
|   their share of the points of units over 100 pts | lower | 58% (10219 of 17752) | 52% (10868 of 20774) | 55% (21087 of 38526) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.4 (26%) | 0.8 (34%) | 2.2 (29%) |
| MARCHED: its unit marched | 1.3 (25%) | 0.3 (14%) | 1.7 (21%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.1 (3%) | 0.1 (1%) |
| IN COMBAT: engaged in combat | 0.3 (6%) | 0.6 (24%) | 0.9 (12%) |
| REAR RANK: in a rear rank | 1.0 (18%) | 0.1 (3%) | 1.1 (14%) |
| GONE: slain | 0.8 (15%) | 0.0 (0%) | 0.8 (11%) |
| OFF THE TABLE: off the table or not arrived | 0.2 (3%) | 0.0 (0%) | 0.2 (2%) |
| STUPIDITY: Stupidity | 0.3 (6%) | 0.1 (3%) | 0.4 (5%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.1 (3%) | 0.1 (1%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.3 (14%) | 0.3 (4%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.8 | 1.2 | 3.1 | 7.7 | 0.8 | 1.0 |
| not cast | 2.7 | 1.7 | 4.4 | 7.8 | 1.2 | 21.0 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.1 (2%) | 0.0 (0%) | 0.0 (0%) | 0.2 (1%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.5 (90%) | 0.9 (21%) | 2.2 (29%) | 0.2 (13%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.7 (21%) | 0.1 (7%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.0 (0%) | 0.2 (6%) | 0.9 (12%) | 0.2 (13%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.9 (34%) | 0.0 (0%) | 0.4 (9%) | 1.1 (14%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (0%) |
| GONE: slain | 0.4 (16%) | 0.0 (0%) | 0.2 (4%) | 0.8 (11%) | 0.2 (13%) | 0.6 (3%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (2%) | 0.0 (0%) | 0.4 (2%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.0 (0%) | 0.2 (4%) | 0.4 (5%) | 0.0 (0%) | 0.7 (3%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.7 (53%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (4%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.3 (50%) | 0.2 (10%) | 2.4 (55%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 19.1 (91%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 2.5 a game | 1.3 a game | 1.9 a game |
| stood (cast and not dispelled) | 77% (23 of 30) | 69% (11 of 16) | 74% (34 of 46) |
| the unit moved after it | 70% (16 of 23) | 100% (11 of 11) | 79% (27 of 34) |
| it charged on its next turn | 0% (0 of 23) | 0% (0 of 11) | 0% (0 of 34) |
| the enemy charged it first | 9% (2 of 23) | 0% (0 of 11) | 6% (2 of 34) |
| it fought by the end of its next turn | 4% (1 of 23) | 0% (0 of 11) | 3% (1 of 34) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 23) | 0% (0 of 11) | 0% (0 of 34) |
| none of these (no charge, no fight, no charge escaped) | 91% (21 of 23) | 100% (11 of 11) | 94% (32 of 34) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 57% (207 of 363) | 55% (154 of 281) | 56% (361 of 644) |
|   cavalry | 54% (14 of 26) | 62% (26 of 42) | 59% (40 of 68) |
|   character | 78% (32 of 41) | 39% (16 of 41) | 59% (48 of 82) |
|   chariot | 49% (23 of 47) | 73% (16 of 22) | 57% (39 of 69) |
|   infantry | 56% (45 of 80) | 52% (43 of 82) | 54% (88 of 162) |
|   monster | 50% (3 of 6) | 43% (3 of 7) | 46% (6 of 13) |
|   war machine | 55% (90 of 163) | 57% (50 of 87) | 56% (140 of 250) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.7 (21%) | 2.7 (25%) | 5.3 (23%) |
| CHARGED: it charged | 0.7 (5%) | 0.8 (8%) | 1.5 (6%) |
| FLEEING: it fled or was fleeing | 0.0 (0%) | 0.2 (2%) | 0.2 (1%) |
| IN COMBAT: it fought this turn or the last | 0.3 (3%) | 0.4 (4%) | 0.8 (3%) |
| MOVED: a war machine that moved | 2.1 (16%) | 1.5 (14%) | 3.6 (15%) |
| NO TARGET IN RANGE | 3.3 (26%) | 1.8 (17%) | 5.1 (22%) |
| ONLY IN COMBAT: the only targets were in combat | 0.2 (2%) | 0.4 (4%) | 0.7 (3%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 2.2 (17%) | 2.2 (21%) | 4.4 (19%) |
| SHELTERED: the target was sheltered | 1.1 (8%) | 0.1 (1%) | 1.2 (5%) |
| OTHER BAR | 0.4 (3%) | 0.5 (5%) | 0.9 (4%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 4.3 | 2.3 | 60% | 7.1 pts | 31 pts |
| character | 4.5 | 1.8 | 70% | 10.9 pts | 49 pts |
| chariot | 3.2 | 3.9 | 41% | 26.3 pts | 86 pts |
| infantry | 12.4 | 4.9 | 70% | 6.0 pts | 75 pts |
| monster | 0.5 | 0.0 | 100% | 0.0 pts | 0 pts |
| war machine | 11.7 | 10.9 | 60% | 18.3 pts | 213 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 1.9 | 4.2 | 3.0 |
| Charges that made contact a game | 1.3 | 2.9 | 2.1 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.00 declared, 0.00 contact (6 units) | 0.67 declared, 0.50 contact (6 units) | 0.33 declared, 0.25 contact (12 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 1.00 declared, 1.00 contact (5 units) | 1.00 declared, 1.00 contact (5 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.28 declared, 0.20 contact (82 units) | 0.45 declared, 0.30 contact (91 units) | 0.37 declared, 0.25 contact (173 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 67% (10 of 15) | 17% (1 of 6) | 50% (1 of 2) | 52% (12 of 23) |
| Character in a unit | 90% (19 of 21) | 58% (7 of 12) | 0% (0 of 1) | 76% (26 of 34) |
| Character on its own | 80% (8 of 10) | 60% (6 of 10) | 36% (4 of 11) | 58% (18 of 31) |
| Chariot | 100% (3 of 3) | 60% (6 of 10) | - | 69% (9 of 13) |
| Infantry | 33% (6 of 18) | 30% (6 of 20) | 50% (1 of 2) | 32% (13 of 40) |
| Monster | 83% (5 of 6) | 100% (2 of 2) | - | 88% (7 of 8) |
| Monstrous | 100% (1 of 1) | 50% (1 of 2) | - | 67% (2 of 3) |
| War Machines | 78% (21 of 27) | 100% (2 of 2) | - | 79% (23 of 29) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 83% (5 of 6); on the table 83% | 56% (57 of 102) | 54% | 55% (12 of 22) | 83% (5 of 6); 4.8 uses a game | 100% (2 of 2); 2.2 uses a game | 67% (4 of 6); 1.0 uses a game |
| Chaos Dwarfs | 4 | 100% (5 of 5); on the table 100% | 44% (16 of 36) | 70% | 66% (21 of 32) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
| Dwarfen Mountain Holds | 4 | 80% (4 of 5); on the table 100% | - | 67% | 62% (21 of 34) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 3 | 100% (1 of 1); on the table 100% | 58% (7 of 12) | 86% | 60% (18 of 30) | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game | 67% (2 of 3); 0.7 uses a game |
| Grand Cathay | 1 | 100% (1 of 1); on the table 100% | 58% (7 of 12) | 33% | 62% (5 of 8) | 100% (2 of 2); 6.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| High Elf Realms | 1 | 100% (4 of 4); on the table 100% | 0% (0 of 6) | 69% | 50% (4 of 8) | 100% (1 of 1); 3.0 uses a game | 50% (1 of 2); 2.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 1 | - | 17% (1 of 6) | 100% | 57% (4 of 7) | 100% (1 of 1); 4.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Tomb Kings of Khemri | 1 | 100% (5 of 5); on the table 100% | - | 23% | 60% (3 of 5) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 3 | 58% (7 of 12); on the table 67% | 33% (4 of 12) | 40% | 68% (13 of 19) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 1 | 100% (4 of 4); on the table 100% | - | 22% | 33% (2 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Wood Elf Realms | 1 | 50% (1 of 2); on the table 100% | - | 68% | 70% (7 of 10) | 100% (2 of 2); 9.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (h8-mine-6ec093a-p2, 12 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 52% (11) | 36% (4) | 47% (15) |
| ...free all their last turn and able to turn (per game) | 0.50 | 0.25 | 0.75 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.25 | 0.08 | 0.33 |
| ...with the charger already in that arc before they moved (per game) | 0.25 | 0.25 | 0.50 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.25 | 0.25 | 0.50 |

### Quality by phase: h8-mine-6ec093a-p2

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.5 | 2.2 |
| Strategy | Charge objectives carried out (made contact) | 62% (13 of 21) | 41% (17 of 41) |
| Strategy | Shoot objectives carried out (shot that target) | 47% (81 of 173) | 47% (43 of 91) |
| Strategy | Support requests answered (helper made contact too) | 50% (1 of 2) | 71% (5 of 7) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (1 of 1) | 100% (3 of 3) |
| Strategy | Hexes on a unit its side charged or shot that turn | - | 33% (2 of 6) |
| Strategy | Joined characters whose unit fought | 28% (9 of 32) | 26% (5 of 19) |
| Strategy | Lone characters that fought | 64% (14 of 22) | 52% (15 of 29) |
| Movement | Charges halted short of contact | 0.0 | 0.4 |
| Movement | Idle units | 2.2 | 1.9 |
| Movement | Points that never moved of their own | 192.4 | 81.7 |
| Movement | Fights charged into per game | 1.2 | 2.4 |
| Movement | Charges with odds: long shots (under 50%) | 2 of 14, net -26 | 10 of 27, net +56 |
| Movement | Charges with odds: sweet spot (55-75%) | 2 of 14, net +0 | 2 of 27, net +104 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 1 of 14, net +0 | 5 of 27, net +74 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 6 of 14, net +122 | 3 of 27, net +27 |
| Shooting | Shots by shooting units (incl. breath weapons) | 10.7 | 8.9 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 43% (55 of 128) | 53% (57 of 107) |
| Shooting | Points destroyed by shooting units | 80.8 | 45.1 |
| Shooting | War machine shots | 7.5 | 4.2 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 46% (41 of 90) | 62% (31 of 50) |
| Shooting | Points destroyed by war machines | 21.1 | 40.0 |
| Magic | Magic missiles cast | 3.2 | 0.9 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 53% (20 of 38) | 55% (6 of 11) |
| Magic | Wounds caused by magic missiles | 7.0 | 1.3 |
| Magic | Wounds caused by other spells | 0.2 | 0.9 |
| Magic | Points destroyed by magic (all spells) | 62.8 | 46.8 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.5 / 0.0 / 0.4 / 0.1 | 2.4 / 0.8 / 0.3 / 0.5 |
| Combat | Points destroyed in combat | 98.0 | 271.8 |
| Combat | Points run down | 40.1 | 47.5 |
| Combat | Net points per charged fight, damage counted | +77 | +100 |
| Combat | Net per 100 charger points, damage counted | +32.6 | +34.2 |
| Combat | First round won (charged fights) | 64% | 72% |
| Combat | Net points per charged fight | +64 | +94 |
| Combat | Net points per supported fight / lone fight | +240 / +35 | +206 / +64 |
| Combat | Charged fights on a top-3 enemy unit | 5 of 14 | 11 of 29 |
| Game | Points lost | 467.4 | 362.8 |
| Game | VP from objectives | 697.5 | 679.2 |
| Game | Lone holders (player turns) | 3.7 | 3.0 |

- Mine won / drew / lost: 3 / 5 / 4 of 12 ended games (of 12); mean margin (Mine - Opponent) -96 VP
- The side that went first won 3 of 7 games with a winner
- Points traded per game (both sides' losses): 830
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: h8-mine-6ec093a-p2

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.8 | +0.0 | 0.0 | 0.0 | 0.8 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.1 | +2.0 | 0.0 | 0.0 | 0.2 | +60.4 | 0.0 | 0.0 |
| ALREADY CARRIED | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARRIVAL HUNT | - | - | - | - | 0.1 | +1.9 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.9 | +0.0 | 0.0 | 7.9 | 1.1 | +0.0 | 0.0 | 13.8 |
| BACKUP TARGETS | 0.1 | +0.1 | 0.0 | 0.0 | 0.2 | +0.3 | 0.0 | 0.0 |
| BEST PRIZE | - | - | - | - | 0.1 | -0.5 | 7.1 | 0.0 |
| BLOWS WHERE AIMED | 0.1 | -1.9 | 18.4 | 0.0 | 0.2 | -75.5 | 5.4 | 0.0 |
| BOMBING RUN | - | - | - | - | 0.1 | +2.2 | 0.0 | 12.5 |
| CANNON PLAN MISSED | 1.2 | +0.0 | 60.1 | 17.5 | 0.8 | +0.0 | 48.7 | 24.6 |
| CANNON PLANNED TARGET | 6.1 | +46.9 | 206.3 | 67.1 | 3.2 | +121.0 | 206.2 | 79.6 |
| CANNON SIGHT KEPT | 1.5 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT COUNTER | - | - | - | - | 0.1 | -22.9 | 31.0 | 0.0 |
| CARRIES OUT SET-UP | - | - | - | - | 0.2 | -17.9 | 31.1 | 0.0 |
| CAST JOB | 0.6 | +5.8 | 11.2 | 7.1 | 0.2 | +3.4 | 0.0 | 0.0 |
| CASTER AWAY FROM SCREEN | 0.6 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CASTING BLOCK | 0.8 | +78.8 | 46.7 | 0.0 | 0.1 | +2.6 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 1.9 | +0.0 | 0.0 | 118.3 | 1.0 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | - | - | - | - | 0.4 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | 0.3 | +13.2 | 0.0 | 6.8 | 0.9 | +37.5 | 0.0 | 35.2 |
| CHAFF PASSED | 0.3 | -1.1 | 11.2 | 25.8 | - | - | - | - |
| CHARACTER GUNS | 0.2 | +0.0 | 0.0 | 0.0 | 0.5 | +0.0 | 0.0 | 0.0 |
| CHARGE LOSSES | 6.4 | -454.9 | 0.0 | 166.9 | 6.4 | -276.2 | 0.0 | 141.2 |
| CHARGE NOT DECLARED | 0.2 | +0.0 | 20.7 | 0.0 | 1.0 | +0.0 | 88.4 | 0.0 |
| CHARGE NOW FIRST | 0.8 | +0.0 | 65.8 | 8.8 | 0.8 | +0.0 | 35.4 | 16.2 |
| CHARGER SLAIN LOST | 0.1 | -0.1 | 8.2 | 0.0 | 0.1 | -7.9 | 48.3 | 0.0 |
| CHEAP HELPER | 0.1 | +0.0 | 18.4 | 0.0 | - | - | - | - |
| CHEAPEST HOLDER | - | - | - | - | 0.2 | -3.9 | 5.4 | 0.0 |
| COMBAT PIVOT | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | 2.2 | +262.0 | 10.8 | 88.8 | 0.6 | +15.2 | 34.6 | 0.0 |
| COVER ONCE | 6.9 | -343.1 | 0.0 | 80.3 | 5.4 | -258.4 | 0.0 | 55.1 |
| DEFENSIVE FLOOR | 0.1 | +16.5 | 0.0 | 0.0 | - | - | - | - |
| DEPLOY BY FIGURES | 9.6 | +3.8 | 0.0 | 9.6 | 7.8 | -40.5 | 0.0 | 10.0 |
| EDGE GIVE GROUND | - | - | - | - | 0.1 | +6.1 | 5.4 | 0.0 |
| ENGINEER BY LORE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FALL BACK GOOD ORDER | 1.2 | +7.1 | 128.2 | 13.1 | 2.3 | +2.6 | 130.5 | 25.0 |
| FALLBACK BY WORTH | 0.3 | +0.5 | 0.0 | 0.0 | 0.5 | +0.1 | 0.0 | 6.8 |
| FALLS SHORT | 5.8 | +140.3 | 0.0 | 78.0 | 18.5 | +293.5 | 0.0 | 98.5 |
| FEATURE BUFFS | 1.4 | +43.0 | 0.0 | 5.4 | 0.5 | +9.4 | 0.0 | 18.7 |
| FIGHT TO THE END | 0.6 | +9.6 | 78.3 | 8.8 | 0.8 | +38.6 | 39.9 | 28.8 |
| FIRE AND FLEE | - | - | - | - | 0.1 | +4.1 | 0.0 | 13.7 |
| FIRE IN ORDER | 0.2 | +0.0 | 2.8 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| FIVE ACTION | 49.1 | +2610.0 | 661.3 | 462.1 | 48.0 | +2987.8 | 602.2 | 455.4 |
| FLANK NOT WEIGHED | 5.2 | +0.0 | 0.0 | 88.6 | 3.7 | +0.0 | 0.0 | 19.1 |
| FOCUS FIRE | 0.1 | +0.7 | 2.8 | 0.0 | 0.1 | +0.7 | 4.6 | 0.0 |
| FOLLOW UP WEIGHED | 0.2 | +33.5 | 0.0 | 0.0 | 0.5 | +55.9 | 0.0 | 0.0 |
| FOUR ROUNDS | 1.7 | +167.1 | 145.7 | 44.1 | 3.0 | +253.0 | 220.8 | 37.6 |
| FRIEND CHARGES FIRST | 0.1 | -2.3 | 0.0 | 0.0 | - | - | - | - |
| FRIEND SHOOTS FIRST | 0.4 | -1.9 | 0.0 | 0.0 | 0.2 | -11.9 | 0.0 | 0.0 |
| FRIENDS SHOTS CHECKED | 0.1 | +0.6 | 0.0 | 0.0 | - | - | - | - |
| GIVES UP | 0.1 | -0.4 | 6.2 | 0.0 | 0.3 | -2.2 | 31.2 | 0.0 |
| GROUND FLIERS | - | - | - | - | 0.2 | +2.3 | 0.0 | 0.0 |
| GUN FIGURES | 1.3 | +13.1 | 22.2 | 25.8 | 1.4 | +2.1 | 5.4 | 0.0 |
| GUN MASK | 0.7 | +15.4 | 0.0 | 0.0 | 1.2 | +24.0 | 0.0 | 12.6 |
| HARD STAY DROPPED | 2.5 | +0.0 | 0.0 | 9.3 | 1.2 | +0.0 | 0.0 | 14.9 |
| HE SHOOTS OR CHARGES | 1.2 | +0.0 | 0.0 | 52.5 | 2.4 | +0.0 | 0.0 | 33.9 |
| HELPER ALREADY ASKED | - | - | - | - | 0.1 | +0.0 | 7.9 | 0.0 |
| HELPER UNSEEN | - | - | - | - | 0.2 | +0.0 | 53.8 | 0.0 |
| HIS CHARGE DENIED | - | - | - | - | 0.1 | +10.9 | 0.0 | 0.0 |
| HIS CHARGE LIST | 2.6 | +0.0 | 0.0 | 19.8 | 4.6 | +0.0 | 0.0 | 58.8 |
| HIS LEGAL MOVES | 2.7 | +0.0 | 0.0 | 47.5 | 4.2 | +0.0 | 0.0 | 76.7 |
| HIS MOVE AND SHOT | 2.2 | -41.2 | 0.0 | 37.8 | 1.8 | -37.0 | 0.0 | 0.0 |
| HIS ONE QUARTER | 2.6 | +0.0 | 0.0 | 13.3 | - | - | - | - |
| HIS RANDOM MOVE | - | - | - | - | 3.4 | +0.0 | 0.0 | 19.9 |
| HIS SHOT LIST | 20.2 | +919.4 | 0.0 | 243.4 | 22.9 | +1257.0 | 0.0 | 178.2 |
| HIS TURN DENIED | 1.1 | +84.3 | 126.2 | 39.8 | 1.6 | +51.1 | 103.7 | 17.6 |
| HOLD ODDS | 11.6 | +0.0 | 0.0 | 68.4 | - | - | - | - |
| HOLDER ASSIGNMENT | 13.0 | +1299.0 | 0.0 | 92.5 | - | - | - | - |
| HOLDER AT DEPLOYMENT | - | - | - | - | 1.1 | +196.6 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 1.7 | -47.1 | 164.1 | 44.1 | 2.3 | -103.6 | 139.2 | 21.2 |
| HUNT IN PAIRS | 0.3 | +4.4 | 0.0 | 0.0 | 0.8 | +41.9 | 0.0 | 0.0 |
| HUNT RESULT | - | - | - | - | 0.4 | +102.2 | 56.2 | 3.8 |
| HUNT THE GUNS | - | - | - | - | 0.5 | +132.5 | 81.7 | 0.0 |
| IDLE COST | 2.7 | -30.6 | 0.0 | 39.8 | 9.8 | -153.1 | 0.0 | 103.8 |
| KEEP FALLS | 0.2 | +1.2 | 0.0 | 0.0 | - | - | - | - |
| KEEPS SCOUTS OR AMBUSH | 0.2 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KILLS COUNT | 0.1 | +9.0 | 18.4 | 0.0 | 0.1 | +0.5 | 9.2 | 0.0 |
| LANE BY FIGURES | 0.2 | +2.2 | 0.0 | 0.0 | 0.7 | +28.5 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 4.6 | +0.0 | 63.6 | 332.3 | 3.0 | +0.0 | 184.2 | 9.7 |
| LONE CHARACTER SAFE SPOT | 0.2 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| LONE WIZARD KEPT IN | 0.7 | +61.6 | 0.0 | 0.0 | 0.3 | +31.3 | 0.0 | 0.0 |
| LONG SHOT | 0.2 | -11.4 | 0.0 | 0.0 | 0.2 | +3.4 | 0.0 | 0.0 |
| LURE BY WHAT IT DRAWS | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MAKE SURE TOGETHER | 0.3 | +6.7 | 0.0 | 0.0 | 0.8 | +29.1 | 0.0 | 0.0 |
| MANOEUVRE | 1.1 | +16.8 | 0.0 | 25.8 | 1.2 | +16.1 | 0.0 | 22.1 |
| MARCH AT ESCAPER | 0.2 | +2.1 | 0.0 | 5.4 | 0.1 | +1.1 | 0.0 | 0.0 |
| MARCH BY THE SUM | 0.2 | +7.5 | 0.0 | 0.0 | 0.2 | +6.2 | 0.0 | 0.0 |
| MARCH CHECK | 1.2 | +104.9 | 0.0 | 12.2 | 1.2 | +87.7 | 0.0 | 0.0 |
| MARCH ODDS | 0.1 | +5.6 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 0.5 | +34.4 | 0.0 | 19.2 | 0.6 | +22.6 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 5.0 | +90.5 | 0.0 | 61.4 | 4.3 | +72.8 | 0.0 | 10.2 |
| MISSILES IN THE MOVE | 4.1 | +219.9 | 0.0 | 12.2 | 3.3 | +53.1 | 0.0 | 18.4 |
| MISSILES NEXT TURN | 4.5 | +148.3 | 0.0 | 31.4 | 4.2 | +51.7 | 0.0 | 18.4 |
| MODEL FACING | 0.8 | +255.4 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL IN RANGE | 0.3 | +6.9 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 1.1 | -35.1 | 0.0 | 59.2 | 0.2 | -7.6 | 0.0 | 0.0 |
| MOVE SPELL SPOT | 1.0 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 14.9 |
| MOVE TO CHARGE COMPUTED | 2.1 | +348.1 | 0.0 | 36.0 | 2.7 | +473.5 | 0.0 | 0.0 |
| MOVES UNITS SPELL | 0.2 | +9.2 | 0.0 | 0.0 | - | - | - | - |
| NEARER NOT NEEDED | 6.3 | +307.0 | 0.0 | 60.0 | 5.8 | +335.5 | 0.0 | 43.4 |
| NEEDED THERE | 0.1 | +19.8 | 18.4 | 0.0 | 0.1 | +16.9 | 9.2 | 0.0 |
| NEXT CHARGE BY LIST | 3.5 | -22.7 | 0.0 | 14.2 | 4.5 | -274.8 | 0.0 | 51.0 |
| NEXT OBJECTIVE NEARER | - | - | - | - | 11.0 | -690.7 | 5.0 | 71.0 |
| NO DOUBLE ROUNDS | 1.6 | -92.4 | 131.9 | 44.1 | 2.6 | -78.1 | 160.0 | 33.8 |
| NOT TURNED | 0.2 | +4.5 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 5.8 |
| NOT WORTH A CAST | 0.2 | -0.4 | 0.0 | 0.0 | 0.8 | -0.6 | 0.0 | 0.0 |
| OFF BEST | 0.4 | -16.9 | 0.0 | 0.0 | 0.8 | -21.1 | 0.0 | 17.8 |
| ONE CHARGE A CHARGER | 1.7 | +0.0 | 0.0 | 27.0 | 1.4 | +0.0 | 0.0 | 8.1 |
| ONE FIGHT FORMULA | 4.1 | -93.9 | 0.0 | 121.8 | 3.8 | -113.4 | 0.0 | 51.8 |
| ONE OBJECTIVE FORMULA | 5.4 | +37.6 | 0.0 | 92.5 | 4.8 | +5.3 | 0.0 | 52.2 |
| ONE TARGET A SHOOTER | 14.4 | +542.9 | 0.0 | 121.2 | 19.9 | +665.6 | 0.0 | 223.2 |
| OPENS A LANE | 0.2 | +0.2 | 0.0 | 0.0 | 0.2 | +1.0 | 11.4 | 0.0 |
| OPENS UP | 0.2 | +10.6 | 14.3 | 0.0 | 0.1 | +4.7 | 7.1 | 0.0 |
| OVERRUNS AWAY | 0.1 | +0.1 | 19.7 | 0.0 | 0.3 | +20.8 | 53.8 | 0.0 |
| PATHS CROSS | 2.8 | +86.4 | 0.0 | 16.8 | 5.8 | +282.3 | 0.0 | 5.0 |
| PLAN RESULT | 43.9 | +697.5 | 394.8 | 612.7 | 43.2 | +592.6 | 543.4 | 588.6 |
| PURSUES BIG PREY | 0.1 | -8.6 | 0.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | 7.6 | +608.7 | 68.0 | 44.3 | - | - | - | - |
| RANDOM MOVE BY FIGURES | 1.0 | +6.2 | 0.0 | 0.0 | - | - | - | - |
| REAL GROUND | 0.6 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| REDIRECT BY WHAT IT STOPS | 0.2 | -1.0 | 0.0 | 0.0 | 0.4 | -16.7 | 0.0 | 15.4 |
| REDIRECT COUNTER | 2.4 | +187.8 | 0.0 | 43.1 | 2.5 | +107.5 | 0.0 | 28.4 |
| REDIRECT WEIGHED | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.2 | 13.8 | 0.0 |
| REFORMS TO MEET IT | 0.2 | -9.9 | 0.0 | 0.0 | 0.3 | -26.5 | 0.0 | 0.0 |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | 0.5 | +35.5 | 0.0 | 5.4 | 0.8 | +35.0 | 0.0 | 0.0 |
| RESTRAINS TO SHOOT | - | - | - | - | 0.1 | +3.0 | 0.0 | 0.0 |
| RISK BY ARC | 1.1 | +16.6 | 110.2 | 39.8 | 2.2 | +57.4 | 184.4 | 32.6 |
| RISK BY HIS FIGURE | 11.5 | -385.1 | 0.0 | 212.2 | 10.8 | -168.6 | 0.0 | 110.6 |
| RISK ON THE WAY | 0.2 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| RUN DOWN | 1.2 | -14.9 | 134.4 | 8.8 | 2.2 | -13.7 | 150.4 | 33.8 |
| SCOUT SPOT | 0.2 | +0.5 | 0.0 | 4.6 | 0.5 | +0.5 | 0.0 | 0.0 |
| SCOUT WAITS | 0.2 | +0.0 | 0.0 | 4.6 | 0.6 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.1 | -1.4 | 0.0 | 0.0 | 0.2 | -1.3 | 0.0 | 2.8 |
| SEARCH SPOT | 4.8 | +298.9 | 0.0 | 94.9 | 7.2 | +246.5 | 0.0 | 64.0 |
| SET UP TOGETHER | 0.3 | +6.7 | 0.0 | 0.0 | 1.0 | +52.8 | 0.0 | 0.0 |
| SET-UP ANY TARGET | 0.3 | +35.7 | 0.0 | 0.0 | 0.1 | +2.4 | 14.9 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.7 | +1.3 | 0.0 | 0.0 | 0.1 | +0.4 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.6 | +87.3 | 45.4 | 8.8 | 0.7 | +17.4 | 0.0 | 0.0 |
| SHORT GUN FORWARD | 0.5 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| SHOT OR CHARGE | 0.1 | -2.6 | 12.5 | 0.0 | 0.7 | -64.2 | 66.1 | 48.0 |
| SHOT RISK POINTS | 12.2 | +113.5 | 0.0 | 177.8 | 12.8 | +27.9 | 0.0 | 164.3 |
| SHOTS IN THE MOVE | 18.2 | +581.8 | 0.0 | 183.2 | 15.7 | +555.0 | 0.0 | 243.0 |
| SPELL SETS UP CHARGE | 0.6 | +191.5 | 0.0 | 0.0 | 0.1 | +2.4 | 14.9 | 0.0 |
| SPELL WORTH | 0.4 | +9.0 | 102.1 | 155.8 | 2.2 | +32.6 | 19.7 | 0.0 |
| SPELLS IN THE FIGHT | 0.2 | -1.6 | 18.4 | 0.0 | 0.7 | -3.3 | 84.8 | 12.6 |
| STAND AND SHOOT | 0.2 | -6.8 | 47.0 | 0.0 | 0.5 | -4.5 | 59.0 | 12.6 |
| STANDS FOR A REASON | 0.2 | +0.0 | 13.7 | 0.0 | 0.5 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 26.3 | +0.0 | 502.0 | 160.3 | 13.2 | +0.0 | 341.0 | 167.6 |
| STAY WORTH | 24.4 | +153.7 | 430.8 | 142.1 | 17.6 | +191.8 | 238.8 | 278.7 |
| STOPS | - | - | - | - | 0.5 | +11.2 | 81.7 | 0.0 |
| STUCK PIVOT | 0.2 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SUPPORT NARROWED | 0.8 | +0.0 | 91.8 | 0.0 | 0.7 | +0.0 | 56.5 | 21.2 |
| SURE REACH TOGETHER | 0.2 | +8.3 | 0.0 | 0.0 | 1.0 | +18.6 | 0.0 | 8.2 |
| THE DEARER SUM KEEPS ITS PLAN | 3.1 | +0.0 | 0.0 | 9.8 | 5.9 | +0.0 | 0.0 | 42.5 |
| THE PROMISE ADDS | - | - | - | - | 0.2 | -61.5 | 9.2 | 0.0 |
| THE PROMISED MOVE | 0.5 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| TIED UP BY THE SUM | 0.3 | +30.1 | 40.5 | 0.0 | 0.7 | +69.8 | 33.3 | 0.0 |
| TIME ON OUR SIDE | 28.8 | +407.3 | 49.7 | 216.5 | 9.2 | +157.0 | 0.0 | 131.2 |
| TWO OR MORE ARRIVE | - | - | - | - | 0.2 | +0.5 | 0.0 | 0.0 |
| WAITS AGAIN | 0.8 | +0.0 | 0.0 | 0.0 | 1.2 | +0.0 | 0.0 | 0.0 |
| WALK PROMISE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WAR ENGINE CHARGES | 0.2 | +21.1 | 32.2 | 0.0 | - | - | - | - |
| WAR ENGINE JOBS | 0.4 | +0.0 | 22.1 | 0.0 | - | - | - | - |
| WHO HITS BACK | - | - | - | - | 0.3 | +74.2 | 0.0 | 0.0 |
| WHOLE FIGHT | - | - | - | - | 0.2 | +11.9 | 79.3 | 0.0 |
| WHOLE FIGHT GAIN | 0.2 | +1.1 | 18.4 | 0.0 | 0.5 | +32.6 | 42.4 | 3.8 |
| WIDER SPREAD | 1.2 | -3.1 | 129.2 | 13.1 | 2.0 | +0.9 | 152.2 | 33.8 |
| WOUNDS ON THE RANKS | 2.1 | +186.6 | 0.0 | 48.2 | 2.8 | +160.4 | 0.0 | 35.2 |

### Rule changes: h8-mine-6ec093a-p2

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HOLDER ASSIGNMENT | 156 | 156 | 146 | 12.17 | +9233 | +63.2 |
| HIS SHOT LIST | 518 | 518 | 141 | 11.75 | +4150 | +29.4 |
| SEARCH SPOT | 144 | 144 | 135 | 11.25 | +6544 | +48.5 |
| DEPLOY BY FIGURES | 208 | 208 | 133 | 11.08 | +2004 | +15.1 |
| ONE TARGET A SHOOTER | 412 | 412 | 114 | 9.50 | +1967 | +17.3 |
| PATHS CROSS | 102 | 102 | 102 | 8.50 | +4424 | +43.4 |
| LEGAL CHARGES ONLY | 91 | 91 | 91 | 7.58 | +0 | +0.0 |
| FIVE ACTION | 1165 | 1163 | 90 | 7.50 | +3305 | +36.7 |
| TIME ON OUR SIDE | 455 | 412 | 90 | 7.50 | +358 | +4.0 |
| SHOT RISK POINTS | 300 | 300 | 56 | 4.67 | +2303 | +41.1 |
| HARD STAY DROPPED | 44 | 44 | 44 | 3.67 | +0 | +0.0 |
| ARTILLERY RE-ROLL WEIGHED | 36 | 36 | 36 | 3.00 | +0 | +0.0 |
| MOVE TO CHARGE COMPUTED | 57 | 57 | 33 | 2.75 | +3245 | +98.3 |
| FOUR ROUNDS | 56 | 54 | 28 | 2.33 | +1862 | +66.5 |
| FALLS SHORT | 292 | 259 | 27 | 2.25 | +259 | +9.6 |
| MAX FOR POSITIONING | 112 | 108 | 27 | 2.25 | +101 | +3.7 |
| CANNON SIGHT KEPT | 25 | 25 | 25 | 2.08 | +0 | +0.0 |
| IDLE COST | 150 | 125 | 25 | 2.08 | +213 | +8.5 |
| SHOTS IN THE MOVE | 406 | 377 | 25 | 2.08 | +956 | +38.3 |
| COVER ONCE | 148 | 115 | 23 | 1.92 | +462 | +20.1 |
| ADVANCE LANE KEPT | 20 | 20 | 20 | 1.67 | +0 | +0.0 |
| NEXT OBJECTIVE NEARER | 132 | 132 | 20 | 1.67 | +246 | +12.3 |
| CHARGE LOSSES | 154 | 154 | 19 | 1.58 | +1178 | +62.0 |
| MARCH CHECK | 28 | 28 | 19 | 1.58 | +540 | +28.4 |
| RISK BY ARC | 39 | 38 | 17 | 1.42 | +390 | +23.0 |
| SHOOTS FROM THE BEST SPOT | 27 | 27 | 17 | 1.42 | +187 | +11.0 |
| WOUNDS ON THE RANKS | 58 | 58 | 17 | 1.42 | +877 | +51.6 |
| REDIRECT COUNTER | 59 | 56 | 16 | 1.33 | +983 | +61.4 |
| RESERVE FALL BACK | 16 | 16 | 16 | 1.33 | +846 | +52.9 |
| CANNON PLANNED TARGET | 112 | 112 | 15 | 1.25 | +180 | +12.0 |
| CHARGE NOT DECLARED | 15 | 15 | 15 | 1.25 | -1465 | -97.7 |
| MANOEUVRE | 28 | 28 | 15 | 1.25 | +395 | +26.3 |
| RISK BY HIS FIGURE | 267 | 267 | 15 | 1.25 | +1418 | +94.6 |
| OFF BEST | 14 | 14 | 14 | 1.17 | -457 | -32.6 |
| STAY WORTH | 504 | 485 | 14 | 1.17 | +488 | +34.8 |
| LONE WIZARD KEPT IN | 12 | 12 | 12 | 1.00 | +1114 | +92.9 |
| HIS TURN DENIED | 32 | 32 | 11 | 0.92 | +489 | +44.4 |
| MISSILES IN THE MOVE | 89 | 63 | 11 | 0.92 | +357 | +32.4 |
| LANE BY FIGURES | 10 | 10 | 10 | 0.83 | +369 | +36.9 |
| MODEL FACING | 10 | 10 | 10 | 0.83 | +3064 | +306.4 |
| NEXT CHARGE BY LIST | 96 | 96 | 10 | 0.83 | +528 | +52.9 |
| TIED UP BY THE SUM | 12 | 11 | 10 | 0.83 | +293 | +29.3 |
| CASTING BLOCK | 11 | 11 | 9 | 0.75 | +388 | +43.2 |
| CHAFF IN THE MOVE | 15 | 15 | 9 | 0.75 | +99 | +11.0 |
| SCOUT WAITS | 9 | 9 | 9 | 0.75 | +0 | +0.0 |
| SHOOTERS IN TWO RANKS | 9 | 9 | 9 | 0.75 | +21 | +2.3 |
| FOLLOW UP WEIGHED | 8 | 8 | 8 | 0.67 | +1073 | +134.1 |
| HOLDS AMBUSHERS | 8 | 8 | 8 | 0.67 | +0 | +0.0 |
| SHORT GUN FORWARD | 8 | 8 | 8 | 0.67 | +0 | +0.0 |
| CASTER AWAY FROM SCREEN | 7 | 7 | 7 | 0.58 | +0 | +0.0 |
| HOLDER AT DEPLOYMENT | 13 | 13 | 7 | 0.58 | +570 | +81.5 |
| QUARTER ODDS | 91 | 91 | 7 | 0.58 | +490 | +70.0 |
| RANDOM MOVE BY FIGURES | 12 | 12 | 7 | 0.58 | +74 | +10.6 |
| CHARGE NOW FIRST | 20 | 20 | 6 | 0.50 | -320 | -53.3 |
| FIRE IN ORDER | 6 | 6 | 6 | 0.50 | +0 | +0.0 |
| GUN MASK | 23 | 23 | 6 | 0.50 | +120 | +20.1 |
| NEARER NOT NEEDED | 145 | 141 | 6 | 0.50 | +189 | +31.4 |
| CASTS FROM BEHIND | 5 | 5 | 5 | 0.42 | +0 | +0.0 |
| FEATURE BUFFS | 23 | 23 | 5 | 0.42 | +70 | +13.9 |
| AFTERMATH IN POINTS | 4 | 4 | 4 | 0.33 | +748 | +187.0 |
| CHAFF PASSED | 4 | 4 | 4 | 0.33 | -13 | -3.4 |
| MARCH BY THE SUM | 4 | 4 | 4 | 0.33 | +164 | +41.1 |
| ONE FIGHT FORMULA | 94 | 59 | 4 | 0.33 | +27 | +6.7 |
| ONE OBJECTIVE FORMULA | 123 | 104 | 4 | 0.33 | +114 | +28.5 |
| REDIRECT WEIGHED | 4 | 4 | 4 | 0.33 | +155 | +38.7 |
| SURE REACH TOGETHER | 14 | 14 | 4 | 0.33 | +49 | +12.2 |
| WHO HITS BACK | 4 | 4 | 4 | 0.33 | +604 | +150.9 |
| WHOLE FIGHT GAIN | 8 | 8 | 4 | 0.33 | +145 | +36.2 |
| CAST JOB | 9 | 9 | 3 | 0.25 | +6 | +2.0 |
| FALLBACK BY WORTH | 10 | 10 | 3 | 0.25 | +7 | +2.4 |
| HIS MOVE AND SHOT | 49 | 49 | 3 | 0.25 | +4 | +1.3 |
| HUNT IN PAIRS | 14 | 8 | 3 | 0.25 | +96 | +31.8 |
| KEEP FALLS | 3 | 3 | 3 | 0.25 | +36 | +11.9 |
| MISSILES NEXT TURN | 105 | 76 | 3 | 0.25 | +5 | +1.6 |
| COMBAT PIVOT | 2 | 2 | 2 | 0.17 | +0 | +0.0 |
| FALL BACK GOOD ORDER | 42 | 40 | 2 | 0.17 | +41 | +20.3 |
| FIGHT TO THE END | 16 | 16 | 2 | 0.17 | +16 | +7.9 |
| FOCUS FIRE | 2 | 2 | 2 | 0.17 | +17 | +8.7 |
| HONEST WORTH | 48 | 46 | 2 | 0.17 | +16 | +7.9 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.17 | +0 | +0.0 |
| KILLS COUNT | 2 | 2 | 2 | 0.17 | +0 | +0.0 |
| MOVES UNITS SPELL | 2 | 2 | 2 | 0.17 | +110 | +55.1 |
| NEEDED THERE | 2 | 2 | 2 | 0.17 | +0 | +0.0 |
| OVERRUNS AWAY | 5 | 5 | 2 | 0.17 | +16 | +7.9 |
| STOPS | 6 | 6 | 2 | 0.17 | +3 | +1.6 |
| STUCK PIVOT | 2 | 2 | 2 | 0.17 | +0 | +0.0 |
| SUPPORT NARROWED | 17 | 17 | 2 | 0.17 | -32 | -15.8 |
| WIDER SPREAD | 38 | 36 | 2 | 0.17 | +3 | +1.7 |
| BEST PRIZE | 1 | 1 | 1 | 0.08 | -6 | -5.6 |
| BOMBING RUN | 1 | 1 | 1 | 0.08 | +26 | +26.0 |
| CARRIES OUT COUNTER | 1 | 1 | 1 | 0.08 | -274 | -274.4 |
| CARRIES OUT SET-UP | 2 | 2 | 1 | 0.08 | -215 | -215.2 |
| DEFENSIVE FLOOR | 1 | 1 | 1 | 0.08 | +133 | +132.6 |
| EDGE GIVE GROUND | 1 | 1 | 1 | 0.08 | +69 | +69.4 |
| FIRE AND FLEE | 1 | 1 | 1 | 0.08 | +49 | +49.2 |
| FRIENDS SHOTS CHECKED | 1 | 1 | 1 | 0.08 | +7 | +7.2 |
| HIS CHARGE DENIED | 1 | 1 | 1 | 0.08 | +27 | +27.3 |
| LONG SHOT | 4 | 4 | 1 | 0.08 | +13 | +12.7 |
| MARCH ODDS | 1 | 1 | 1 | 0.08 | -44 | -44.5 |
| MOVE SPELL IN RANGE | 4 | 4 | 1 | 0.08 | +14 | +13.5 |
| OPENS A LANE | 5 | 1 | 1 | 0.08 | +3 | +3.0 |
| OPENS UP | 3 | 3 | 1 | 0.08 | +14 | +13.9 |
| PURSUES BIG PREY | 1 | 1 | 1 | 0.08 | -103 | -102.8 |
| REFUSING RETIRES | 6 | 6 | 1 | 0.08 | -0 | -0.3 |
| RESTRAINS TO SHOOT | 1 | 1 | 1 | 0.08 | +35 | +35.5 |
| SCREEN BY WHAT IT SAVES | 4 | 4 | 1 | 0.08 | +51 | +51.0 |
| WAR ENGINE CHARGES | 2 | 2 | 1 | 0.08 | +32 | +31.8 |
| ALREADY CARRIED | 1 | not checked | - | - | - | - |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| BACKUP TARGETS | 4 | 2 | 0 | 0.00 | - | - |
| BLOWS WHERE AIMED | 3 | 3 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 24 | 24 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 35 | trace | - | - | - | - |
| CHARACTER GUNS | 9 | 9 | 0 | 0.00 | - | - |
| CHARGER SLAIN LOST | 2 | 2 | 0 | 0.00 | - | - |
| CHEAP HELPER | 1 | not checked | - | - | - | - |
| CHEAPEST HOLDER | 2 | 2 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 34 | not checked | - | - | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 106 | not checked | - | - | - | - |
| FRIEND CHARGES FIRST | 1 | 1 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 8 | 8 | 0 | 0.00 | - | - |
| GIVES UP | 5 | 5 | 0 | 0.00 | - | - |
| GROUND FLIERS | 2 | not checked | - | - | - | - |
| GUN FIGURES | 33 | not checked | - | - | - | - |
| HE SHOOTS OR CHARGES | 44 | 44 | 0 | 0.00 | - | - |
| HELPER ALREADY ASKED | 1 | not checked | - | - | - | - |
| HELPER UNSEEN | 3 | 3 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 86 | 86 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 83 | 83 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 31 | 31 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 41 | 41 | 0 | 0.00 | - | - |
| HOLD ODDS | 139 | 139 | 0 | 0.00 | - | - |
| HUNT RESULT | 5 | trace | - | - | - | - |
| HUNT THE GUNS | 6 | trace | - | - | - | - |
| LONE CHARACTER SAFE SPOT | 2 | not checked | - | - | - | - |
| LURE BY WHAT IT DRAWS | 1 | 1 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 13 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 3 | trace | - | - | - | - |
| MARCH OVER CASTS | 13 | 13 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 16 | trace | - | - | - | - |
| MOVE SPELL SPOT | 17 | not checked | - | - | - | - |
| NO DOUBLE ROUNDS | 50 | 48 | 0 | 0.00 | - | - |
| NOT TURNED | 6 | 6 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 13 | not checked | - | - | - | - |
| ONE CHARGE A CHARGER | 37 | 37 | 0 | 0.00 | - | - |
| PLAN RESULT | 1046 | trace | - | - | - | - |
| REAL GROUND | 7 | 7 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 7 | 7 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 6 | 6 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 3 | 3 | 0 | 0.00 | - | - |
| RUN DOWN | 41 | 39 | 0 | 0.00 | - | - |
| SCOUT SPOT | 8 | 8 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 16 | 14 | 0 | 0.00 | - | - |
| SET-UP ANY TARGET | 5 | not checked | - | - | - | - |
| SHOT OR CHARGE | 9 | 9 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 8 | not checked | - | - | - | - |
| SPELL WORTH | 32 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 10 | 9 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 9 | 9 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 9 | 9 | 0 | 0.00 | - | - |
| STANDS STILL | 475 | 475 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 108 | not checked | - | - | - | - |
| THE PROMISE ADDS | 3 | 3 | 0 | 0.00 | - | - |
| THE PROMISED MOVE | 8 | not checked | - | - | - | - |
| TWO OR MORE ARRIVE | 3 | not checked | - | - | - | - |
| WAITS AGAIN | 24 | 24 | 0 | 0.00 | - | - |
| WALK PROMISE | 1 | 1 | 0 | 0.00 | - | - |
| WAR ENGINE JOBS | 5 | 5 | 0 | 0.00 | - | - |
| WHOLE FIGHT | 3 | 2 | 0 | 0.00 | - | - |

### Off best figure: h8-mine-6ec093a-p2

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| HOLDER ASSIGNMENT | rule | 1.33 | - | 15.4 |
| CHARGE NOT DECLARED | rule | 0.25 | 0.92 | 104.6 |
| JOB FIRST | gate | 0.08 | 0.75 | 34.8 |
| PATHS CROSS | rule | 0.25 | 0.58 | 27.5 |
| CHARGE NOW FIRST | rule | 0.17 | 0.33 | 53.3 |
| CANNON PLANNED TARGET | rule | 0.17 | - | 34.2 |
| CHAFF PASSED | rule | 0.17 | - | 6.7 |
| AFTERMATH BAND | gate | 0.08 | - | 1.8 |
| BEST PRIZE | rule | - | 0.08 | 5.6 |
| CARRIES OUT COUNTER | rule | - | 0.08 | 274.4 |
| CARRIES OUT SET-UP | rule | - | 0.08 | 215.2 |
| DEPLOY BY FIGURES | rule | - | 0.08 | 13.2 |
| FALLBACK | gate | 0.08 | - | 2.6 |
| LONE CHARACTER SAFE SPOT | gate | 0.08 | - | 56.5 |
| MARCH ODDS | rule | 0.08 | - | 44.5 |
| NO REASON | gate | 0.08 | - | 48.2 |
| PURSUES BIG PREY | rule | 0.08 | - | 102.8 |
| SUPPORT NARROWED | rule | - | 0.08 | 31.6 |

### Plans: h8-mine-6ec093a-p2

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.2 | 71% | 237 | 109 | 46% |
| Mine | join | 1.0 | 100% | 46 | 0 | 0% |
| Mine | move | 29.3 | 93% | 1642 | 0 | 0% |
| Mine | shoot | 12.1 | 59% | 520 | 589 | 113% |
| Mine | support | 0.3 | 100% | 11 | 0 | 0% |
| Opponent | charge | 2.8 | 74% | 347 | 305 | 88% |
| Opponent | join | 1.2 | 100% | 57 | 0 | 0% |
| Opponent | move | 32.3 | 96% | 1750 | 0 | 0% |
| Opponent | shoot | 6.3 | 61% | 235 | 287 | 122% |
| Opponent | support | 0.6 | 71% | 9 | 0 | 0% |

### Packages: hunt the guns, h8-mine-6ec093a-p2

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 58 |
| Opponent | 0.5 | 6 | 1 | 100% | 100% | 0% | 2.0 | 263 | 245 | 100% | 24 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 72 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 100 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 268 |
| Tomb Kings of Khemri | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Vampire Counts | 1.7 | 5 | 1 | 100% | 100% | 0% | 2.0 | 291 | 272 | 100% | 0 |
| Warriors of Chaos | 1.0 | 1 | 0 | 100% | 100% | 0% | 2.0 | 153 | 139 | 100% | 0 |
| Wood Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 19 |

### Battle groups: h8-mine-6ec093a-p2

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 2.4 | 38% | 82% | 0% | - | 0% | 9% | 36% | 55% | 0% |
| Opponent | REDIRECT COUNTER | 2.5 | 7% | 50% | 50% | 0% | 0% | 0% | 100% | 0% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: h8-mine-6ec093a-p2

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 9 | 0 (9) | 0 | 0 | 40 | 56% | 3.5 | 0 (4) | 0 (3) | 0 (2) | 0 (6) | 0 (3) |
| Mine | Character | 51 | 13 (51) | 13 | 0 | 30 | 22% | 2.4 | 10 (28) | 7 (13) | 28 (6) | 10 (26) | 15 (21) |
| Mine | Clean-up | 14 | 61 (14) | 23 | 38 | 35 | 57% | 2.7 | 57 (5) | 62 (4) | 64 (5) | 120 (7) | 0 (7) |
| Mine | Fast Hammer | 4 | 0 (4) | 0 | 0 | 50 | 100% | - | 0 (2) | 0 (2) | - | 0 (1) | 0 (3) |
| Mine | Hammer | 31 | 58 (31) | 25 | 33 | 21 | 32% | 2.9 | 71 (9) | 61 (18) | 10 (4) | 65 (17) | 50 (14) |
| Mine | Holder | 9 | 144 (9) | 36 | 108 | 28 | 67% | 5.0 | 230 (3) | 136 (4) | 0 (1) | 254 (3) | 86 (5) |
| Mine | Shooter | 13 | 88 (13) | 22 | 66 | 29 | 0% | 1.9 | 272 (2) | 60 (8) | 42 (3) | 116 (9) | 32 (4) |
| Mine | War machine | 30 | 9 (30) | 9 | 0 | 25 | 10% | 1.7 | 1 (15) | 0 (6) | 30 (9) | 0 (4) | 10 (26) |
| Mine | Wizard | 3 | 14 (3) | 14 | 0 | 0 | 33% | 5.5 | 0 (1) | 20 (2) | - | - | 14 (3) |
| Opponent | Chaff | 25 | 98 (25) | 20 | 79 | 35 | 52% | 2.4 | 99 (6) | 119 (9) | 78 (10) | 86 (19) | 131 (6) |
| Opponent | Character | 38 | 39 (38) | 39 | 0 | 11 | 39% | 2.5 | 34 (13) | 39 (16) | 55 (7) | 47 (21) | 32 (15) |
| Opponent | Clean-up | 7 | 23 (7) | 0 | 23 | 18 | 57% | 2.7 | 61 (2) | 13 (3) | 0 (2) | 38 (4) | 0 (3) |
| Opponent | Early | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Fast | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Fast Hammer | 18 | 49 (18) | 24 | 24 | 22 | 39% | 3.1 | 105 (8) | 19 (9) | 0 (1) | 60 (11) | 31 (7) |
| Opponent | Hammer | 11 | 20 (11) | 0 | 20 | 18 | 45% | 2.7 | 61 (1) | 17 (7) | 12 (3) | 27 (7) | 9 (4) |
| Opponent | Holder | 7 | 85 (7) | 24 | 60 | 0 | 14% | 4.7 | 0 (1) | 125 (5) | 0 (1) | - | 85 (7) |
| Opponent | Shooter | 11 | 85 (11) | 9 | 77 | 29 | 0% | 1.6 | 129 (6) | 59 (4) | 0 (1) | 110 (8) | 39 (3) |
| Opponent | Support | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | War machine | 15 | 37 (15) | 37 | 0 | 52 | 0% | 1.9 | 44 (4) | 32 (10) | 67 (1) | 78 (2) | 30 (13) |
| Opponent | Wizard | 10 | 0 (10) | 0 | 0 | 14 | 40% | 1.8 | 0 (2) | 0 (4) | 0 (2) | 0 (4) | 0 (4) |

### Charged fights: h8-mine-6ec093a-p2

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 179 | 15 | 1.0 | 1.0 | 15 | 13 | +2 | 1 of 4 | 2 of 4 | - | +2 |
| Mine | Chaos Dwarfs | 4 | 55 | 199 | 1.5 | 1.2 | 133 | 0 | +133 | 2 of 6 | 4 of 6 | +481 | +63 |
| Mine | Dwarfen Mountain Holds | 4 | 259 | 24 | 1.0 | 1.2 | 24 | 0 | +24 | 2 of 4 | 3 of 4 | +0 | +33 |
| **Mine** | all armies | 12 | 165 | 80 | 1.2 | 1.1 | 68 | 4 | +64 | 5 of 14 | 9 of 14 | +240 | +35 |
| Opponent | Empire of Man | 3 | 265 | 49 | 1.0 | 1.0 | 49 | 0 | +49 | 0 of 3 | 2 of 3 | - | +49 |
| Opponent | Grand Cathay | 1 | 0 | 65 | 1.0 | 1.0 | 65 | 0 | +65 | 0 of 1 | 1 of 1 | - | +65 |
| Opponent | High Elf Realms | 1 | 338 | 520 | 1.0 | 2.0 | 520 | 0 | +520 | 1 of 1 | 1 of 1 | +520 | - |
| Opponent | Ogre Kingdoms | 1 | 330 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Tomb Kings of Khemri | 1 | 0 | 792 | 4.0 | 1.2 | 198 | 71 | +127 | 3 of 4 | 3 of 4 | +282 | +75 |
| Opponent | Vampire Counts | 3 | 0 | 327 | 4.7 | 1.2 | 70 | 13 | +57 | 5 of 14 | 9 of 14 | +48 | +60 |
| Opponent | Warriors of Chaos | 1 | 0 | 574 | 4.0 | 1.2 | 144 | 0 | +144 | 1 of 4 | 3 of 4 | +289 | +95 |
| Opponent | Wood Elf Realms | 1 | 120 | 105 | 2.0 | 1.0 | 52 | 0 | +52 | 1 of 2 | 2 of 2 | - | +52 |
| **Opponent** | all armies | 12 | 132 | 265 | 2.4 | 1.2 | 110 | 16 | +94 | 11 of 29 | 21 of 29 | +206 | +64 |

### Effective charges: h8-mine-6ec093a-p2

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 1 (net -52) | 0 | 1 (net +0) | 1 (net +60) | 0 | 1 (net +0) | 0 | 25% (1 of 4) |
| Mine | Chaos Dwarfs | 6 | 1 (net +0) | 0 | 0 | 2 (net +82) | 1 (net +0) | 2 (net +316) | 0 | 0% (0 of 6) |
| Mine | Dwarfen Mountain Holds | 4 | 0 | 0 | 1 (net +0) | 0 | 0 | 3 (net +33) | 0 | 25% (1 of 4) |
| Opponent | Empire of Man | 3 | 0 | 0 | 0 | 0 | 1 (net +65) | 2 (net +40) | 0 | 0% (0 of 3) |
| Opponent | Grand Cathay | 1 | 0 | 0 | 0 | 1 (net +65) | 0 | 0 | 0 | 0% (0 of 1) |
| Opponent | High Elf Realms | 1 | 0 | 0 | 0 | 1 (net +520) | 0 | 0 | 0 | 0% (0 of 1) |
| Opponent | Tomb Kings of Khemri | 4 | 2 (net -98) | 0 | 1 (net +282) | 1 (net +420) | 0 | 0 | 0 | 25% (1 of 4) |
| Opponent | Vampire Counts | 14 | 6 (net +79) | 2 (net +48) | 1 (net -75) | 1 (net +0) | 4 (net +76) | 0 | 0 | 7% (1 of 14) |
| Opponent | Warriors of Chaos | 4 | 2 (net +142) | 0 | 0 | 1 (net +289) | 0 | 1 (net +0) | 0 | 0% (0 of 4) |

### Charged fights, damage counted: h8-mine-6ec093a-p2

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 2 | 196 | 338 | -26 | 5 | 26 | -21 | -10.6 |
| Mine | Effective (55-75%) | 2 | 188 | 290 | +0 | 49 | 37 | +12 | +6.2 |
| Mine | 76-89% | 3 | 234 | 153 | +75 | 127 | 16 | +111 | +47.3 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 6 | 247 | 178 | +122 | 149 | 23 | +127 | +51.2 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 339 | 75 | +0 | 0 | 0 | +0 | +0.0 |
| Mine | All fights | 14 | 235 | 204 | +64 | 99 | 22 | +77 | +32.6 |
| Opponent | Long shot (under 50%) | 10 | 207 | 333 | +56 | 117 | 52 | +66 | +31.8 |
| Opponent | 50-54% | 2 | 98 | 62 | +48 | 55 | 0 | +55 | +55.8 |
| Opponent | Effective (55-75%) | 2 | 533 | 330 | +104 | 186 | 89 | +97 | +18.2 |
| Opponent | 76-89% | 5 | 491 | 189 | +259 | 259 | 3 | +256 | +52.1 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 | 157 | 94 | +27 | 47 | 18 | +28 | +18.0 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 5 | 440 | 91 | +74 | 90 | 16 | +73 | +16.7 |
| Opponent | No odds | 2 | 0 | 146 | +52 | 99 | 0 | +99 | - |
| Opponent | All fights | 29 | 292 | 210 | +94 | 129 | 29 | +100 | +34.2 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| h8-mine-6ec093a-p2 | move | 60 | 17 (28%) | 13 (22%) | 6 (10%) | 37 (62%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0108, L0123 |
| Charmed Shield | Opponent | L0224, L0325, L0427 |
| Elixir of Power | Opponent | L0411 |
| Fistful of Laurels | Opponent | L0618 |
| Horn of the Wild Hunt | Opponent | L0633 |
| Invocation of Nehek | Opponent | L0224, L0325, L0427 |
| Ring of Doom | Mine | L0207, L0224 |
| Ring of Doom | Opponent | L0411, L0633 |
| Ring of Jet | Opponent | L0411 |
| Standard of the Fell Warrior | Opponent | L0513 |
| Twice-Blessed Armour | Opponent | L0207 |
| Witch Hunter's Ward | Opponent | L0108, L0207, L0308 |

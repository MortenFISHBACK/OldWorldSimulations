# Doctrine scorecard: h8-mine-6ec093a-p4

### Scorecard: h8-mine-6ec093a-p4

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0115 | 1 | 1 | Mine | no | 4 | - | 0 | 2 | 0 | 0 | 0 | 0 |
| L0115 | 1 | 1 | Opponent | yes | 2 | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L0132 | 6 | 1 | Mine | no | 16 | 2 | 1 | 1 | 0 | 0 | 0 | 0 |
| L0132 | 6 | 1 | Opponent | no | 3 | 3 | 3 | 7 | 0 | 0 | 0 | 340 |
| L0216 | 6 | 1 | Mine | no | 0 | 6 | 1 | 3 | 0 | 0 | 0 | 170 |
| L0216 | 6 | 1 | Opponent | no | 0 | 2 | 2 | 0 | 0 | 0 | 0 | 100 |
| L0232 | 4 | 1 | Mine | no | 3 | 3 | 4 | 2 | 1 | 0 | 0 | 170 |
| L0232 | 4 | 1 | Opponent | no | 0 | 2 | 5 | 1 | 1 | 0 | 0 | 170 |
| L0316 | 4 | 1 | Mine | no | 0 | 5 | 1 | 2 | 0 | 0 | 0 | 370 |
| L0316 | 4 | 1 | Opponent | no | 1 | 3 | 3 | 1 | 0 | 0 | 0 | 0 |
| L0333 | 3 | 1 | Mine | yes | 6 | 4 | 1 | 0 | 0 | 0 | 0 | 110 |
| L0333 | 3 | 1 | Opponent | yes | 3 | 3 | 2 | 4 | 0 | 0 | 0 | 0 |
| L0420 | 6 | 1 | Mine | no | 2 | 2 | 2 | 3 | 0 | 0 | 0 | 310 |
| L0420 | 6 | 1 | Opponent | no | 0 | - | 0 | 5 | 0 | 0 | 0 | 780 |
| L0435 | 3 | 1 | Mine | no | 3 | 3 | 2 | 0 | 0 | 0 | 0 | 310 |
| L0435 | 3 | 1 | Opponent | no | 0 | 3 | 4 | 0 | 1 | 0 | 0 | 0 |
| L0522 | 6 | 1 | Mine | no | 4 | - | 0 | 1 | 0 | 0 | 0 | 496 |
| L0522 | 6 | 1 | Opponent | no | 4 | 2 | 3 | 2 | 1 | 0 | 0 | 0 |
| L0609 | 3 | 1 | Mine | no | 0 | 6 | 2 | 2 | 1 | 0 | 0 | 180 |
| L0609 | 3 | 1 | Opponent | no | 2 | - | 0 | 2 | 0 | 0 | 0 | 125 |
| L0625 | 1 | 1 | Mine | no | 0 | - | 2 | 1 | 0 | 0 | 0 | 105 |
| L0625 | 1 | 1 | Opponent | no | 4 | 2 | 3 | 0 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 9% | 3.5 | 3.9 | 1.5 | 1.5 | 0.2 | 0.0 | 0.0 | 201.9 |
| **Average** | | | Opponent | 18% | 1.7 | 2.4 | 2.5 | 2.1 | 0.3 | 0.0 | 0.0 | 137.7 |

### KPIs: h8-mine-6ec093a-p4

Rules off - Opponent only: HOLDER ASSIGNMENT, QUARTER ODDS, WALK PROMISE, REAL GROUND, RISK ON THE WAY.

Morten 2026-11-10; 11 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 46% (25 of 54) | 0% (0 of 56) | 23% (25 of 110) |
| Winner chose to follow up after the loser gave ground |  | 80% (12 of 15); on the table 87% | 100% (7 of 7); on the table 100% | 86% (19 of 22); on the table 91% |
| Winner chose to pursue after the loser fell back in good order |  | 67% (2 of 3); on the table 67% | 100% (1 of 1); on the table 100% | 75% (3 of 4); on the table 75% |
| Winner chose to pursue after the loser fled |  | 75% (3 of 4); on the table 75% | 73% (8 of 11); on the table 82% | 73% (11 of 15); on the table 80% |
| Winner chose to follow up or pursue (all three) |  | 77% (17 of 22); on the table 82% | 84% (16 of 19); on the table 89% | 80% (33 of 41); on the table 85% |
| Magic missiles tried each own turn | 50%+ | 40% (53 of 132) | 31% (13 of 42) | 38% (66 of 174) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 50% (53 of 105) | 36% (13 of 36) | 47% (66 of 141) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 75% (3 of 4) | 72% (23 of 32) | 72% (26 of 36) |
| Points that never fought | lower | 44% (9486 of 21594) | 52% (11412 of 21995) | 48% (20898 of 43589) |
|   infantry points that never fought | lower | 51% (3489 of 6804) | 81% (4243 of 5211) | 64% (7732 of 12015) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 60% (49 of 81) | 49% (43 of 87) | 55% (92 of 168) |
| Bound items with a magic missile used (at least once a game) |  | 100% (6 of 6); 1.6 uses a game | 40% (2 of 5); 1.0 uses a game | 73% (8 of 11); 1.3 uses a game |
| Bound items with another spell used |  | 100% (2 of 2); 0.5 uses a game | 0.0 uses a game | 100% (2 of 2); 0.2 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 50% (4 of 8); 0.4 uses a game | 75% (3 of 4); 0.3 uses a game | 58% (7 of 12); 0.3 uses a game |
|   their share of the points of units over 100 pts | lower | 55% (9095 of 16500) | 41% (7979 of 19294) | 48% (17074 of 35794) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 2.2 (30%) | 1.4 (52%) | 3.5 (36%) |
| MARCHED: its unit marched | 2.0 (28%) | 0.7 (28%) | 2.7 (28%) |
| CHARGED: its unit charged | 0.4 (5%) | 0.0 (0%) | 0.4 (4%) |
| IN COMBAT: engaged in combat | 1.4 (19%) | 0.1 (3%) | 1.5 (15%) |
| FLEEING: fleeing | 0.0 (0%) | 0.1 (3%) | 0.1 (1%) |
| GONE: slain | 1.1 (15%) | 0.3 (10%) | 1.4 (14%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (0%) | 0.1 (3%) | 0.1 (1%) |
| STUPIDITY: Stupidity | 0.2 (3%) | 0.0 (0%) | 0.2 (2%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 5.5 | 0.2 | 2.0 | 6.0 | 1.0 |
| not cast | 5.4 | 0.9 | 4.0 | 9.8 | 15.4 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.5 (4%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.3 (30%) | 0.8 (20%) | 3.5 (36%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.7 (28%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.4 (4%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.1 (2%) | 0.0 (0%) | 1.3 (32%) | 1.5 (15%) | 0.0 (0%) |
| FLEEING: fleeing | 0.1 (2%) | 0.1 (10%) | 0.0 (0%) | 0.1 (1%) | 0.5 (3%) |
| GONE: slain | 0.5 (8%) | 0.0 (0%) | 0.3 (7%) | 1.4 (14%) | 1.5 (10%) |
| OFF THE TABLE: off the table or not arrived | 0.1 (2%) | 0.1 (10%) | 0.0 (0%) | 0.1 (1%) | 0.2 (1%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.0 (0%) | 0.3 (7%) | 0.2 (2%) | 0.2 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.2 (3%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 4.5 (83%) | 0.5 (50%) | 1.4 (34%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 12.5 (81%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.7 a game | 0.7 a game | 1.2 a game |
| stood (cast and not dispelled) | 74% (14 of 19) | 33% (1 of 3) | 68% (15 of 22) |
| the unit moved after it | 79% (11 of 14) | 100% (1 of 1) | 80% (12 of 15) |
| it charged on its next turn | 7% (1 of 14) | 0% (0 of 1) | 7% (1 of 15) |
| the enemy charged it first | 29% (4 of 14) | 0% (0 of 1) | 27% (4 of 15) |
| it fought by the end of its next turn | 7% (1 of 14) | 0% (0 of 1) | 7% (1 of 15) |
| it moved out of a charge the enemy had planned (not charged first) | 7% (1 of 14) | 0% (0 of 1) | 7% (1 of 15) |
| none of these (no charge, no fight, no charge escaped) | 64% (9 of 14) | 100% (1 of 1) | 67% (10 of 15) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 66% (186 of 280) | 53% (144 of 274) | 60% (330 of 554) |
|   cavalry | 61% (14 of 23) | 46% (26 of 56) | 51% (40 of 79) |
|   character | 88% (23 of 26) | 30% (14 of 46) | 51% (37 of 72) |
|   chariot | 59% (27 of 46) | 56% (9 of 16) | 58% (36 of 62) |
|   infantry | 54% (37 of 69) | 60% (65 of 109) | 57% (102 of 178) |
|   monster | 78% (7 of 9) | 50% (3 of 6) | 67% (10 of 15) |
|   war machine | 73% (78 of 107) | 66% (27 of 41) | 71% (105 of 148) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.9 (22%) | 3.5 (30%) | 5.5 (27%) |
| CHARGED: it charged | 0.6 (7%) | 1.8 (15%) | 2.5 (12%) |
| FLEEING: it fled or was fleeing | 0.0 (0%) | 0.4 (3%) | 0.4 (2%) |
| IN COMBAT: it fought this turn or the last | 0.8 (10%) | 0.1 (1%) | 0.9 (4%) |
| MOVED: a war machine that moved | 0.9 (11%) | 0.8 (7%) | 1.7 (8%) |
| NO TARGET IN RANGE | 2.5 (30%) | 2.8 (24%) | 5.4 (26%) |
| ONLY IN COMBAT: the only targets were in combat | 0.1 (1%) | 0.5 (4%) | 0.5 (3%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.3 (15%) | 1.3 (11%) | 2.5 (12%) |
| SHELTERED: the target was sheltered | 0.1 (1%) | 0.3 (2%) | 0.4 (2%) |
| OTHER BAR | 0.3 (3%) | 0.4 (3%) | 0.6 (3%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 4.5 | 0.5 | 88% | 3.4 pts | 15 pts |
| character | 3.5 | 0.5 | 87% | 2.8 pts | 10 pts |
| chariot | 3.3 | 3.5 | 44% | 21.6 pts | 71 pts |
| infantry | 12.8 | 3.6 | 78% | 6.5 pts | 84 pts |
| monster | 1.5 | 0.7 | 56% | 6.3 pts | 9 pts |
| war machine | 9.5 | 7.0 | 60% | 15.3 pts | 146 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 2.7 | 4.5 | 3.6 |
| Charges that made contact a game | 1.8 | 3.5 | 2.7 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.60 declared, 0.60 contact (5 units) | 0.00 declared, 0.00 contact (3 units) | 0.38 declared, 0.38 contact (8 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 1.50 declared, 1.50 contact (2 units) | 1.50 declared, 1.50 contact (2 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.34 declared, 0.21 contact (80 units) | 0.49 declared, 0.38 contact (94 units) | 0.42 declared, 0.30 contact (174 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 36% (5 of 14) | 0% (0 of 2) | 0% (0 of 1) | 29% (5 of 17) |
| Character in a unit | 86% (12 of 14) | 50% (4 of 8) | - | 73% (16 of 22) |
| Character on its own | 100% (6 of 6) | 80% (8 of 10) | 19% (3 of 16) | 53% (17 of 32) |
| Chariot | 100% (1 of 1) | 78% (7 of 9) | - | 80% (8 of 10) |
| Infantry | 47% (14 of 30) | 25% (5 of 20) | - | 38% (19 of 50) |
| Monster | 70% (7 of 10) | 50% (1 of 2) | - | 67% (8 of 12) |
| Monstrous | 100% (5 of 5) | 0% (0 of 1) | - | 83% (5 of 6) |
| War Machines | 76% (13 of 17) | 50% (1 of 2) | - | 74% (14 of 19) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 69% (9 of 13); on the table 77% | 38% (39 of 102) | 21% | 50% (11 of 22) | 100% (6 of 6); 4.5 uses a game | 100% (2 of 2); 1.2 uses a game | 67% (4 of 6); 1.0 uses a game |
| Chaos Dwarfs | 4 | 80% (4 of 5); on the table 80% | 47% (14 of 30) | 44% | 56% (18 of 32) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |
| Dwarfen Mountain Holds | 3 | 100% (4 of 4); on the table 100% | - | 72% | 74% (20 of 27) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 1 | 100% (1 of 1); on the table 100% | 17% (2 of 12) | 95% | 50% (6 of 12) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| High Elf Realms | 1 | 100% (1 of 1); on the table 100% | 17% (1 of 6) | 44% | 29% (2 of 7) | 50% (1 of 2); 5.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 2 | 100% (1 of 1); on the table 100% | - | 56% | 33% (4 of 12) | 0.0 uses a game | 0.0 uses a game | 100% (2 of 2); 1.0 uses a game |
| Skaven | 1 | 100% (2 of 2); on the table 100% | 83% (5 of 6) | 57% | 57% (4 of 7) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Tomb Kings of Khemri | 1 | - | - | 48% | 20% (1 of 5) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 1 | 80% (4 of 5); on the table 100% | 33% (2 of 6) | 40% | 50% (3 of 6) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 2 | 100% (3 of 3); on the table 100% | - | 41% | 62% (10 of 16) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 2 | 67% (4 of 6); on the table 67% | 25% (3 of 12) | 47% | 59% (13 of 22) | 33% (1 of 3); 3.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (h8-mine-6ec093a-p4, 11 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 59% (17) | 36% (5) | 51% (22) |
| ...free all their last turn and able to turn (per game) | 0.91 | 0.36 | 1.27 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.45 | 0.09 | 0.55 |
| ...with the charger already in that arc before they moved (per game) | 0.82 | 0.27 | 1.09 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.09 | 0.09 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.27 | 0.27 | 0.55 |

### Quality by phase: h8-mine-6ec093a-p4

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.2 | 2.0 |
| Strategy | Charge objectives carried out (made contact) | 48% (12 of 25) | 50% (24 of 48) |
| Strategy | Shoot objectives carried out (shot that target) | 50% (65 of 131) | 47% (31 of 66) |
| Strategy | Support requests answered (helper made contact too) | 50% (1 of 2) | 33% (1 of 3) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (2 of 2) | - |
| Strategy | Hexes on a unit its side charged or shot that turn | - | 0% (0 of 1) |
| Strategy | Joined characters whose unit fought | 64% (16 of 25) | 14% (2 of 14) |
| Strategy | Lone characters that fought | 45% (10 of 22) | 70% (16 of 23) |
| Movement | Charges halted short of contact | 0.0 | 0.1 |
| Movement | Idle units | 1.5 | 2.1 |
| Movement | Points that never moved of their own | 201.9 | 137.7 |
| Movement | Fights charged into per game | 1.7 | 3.5 |
| Movement | Charges with odds: long shots (under 50%) | 4 of 17, net -15 | 10 of 35, net +118 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 17 | 8 of 35, net +64 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 1 of 17, net +534 | 5 of 35, net +115 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 6 of 17, net +24 | 7 of 35, net +84 |
| Shooting | Shots by shooting units (incl. breath weapons) | 10.3 | 12.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 55% (62 of 113) | 47% (64 of 135) |
| Shooting | Points destroyed by shooting units | 7.5 | 14.1 |
| Shooting | War machine shots | 7.1 | 2.5 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 56% (44 of 78) | 41% (11 of 27) |
| Shooting | Points destroyed by war machines | 39.0 | 51.7 |
| Magic | Magic missiles cast | 2.8 | 0.9 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 42% (13 of 31) | 60% (6 of 10) |
| Magic | Wounds caused by magic missiles | 6.2 | 1.8 |
| Magic | Wounds caused by other spells | 0.4 | - |
| Magic | Points destroyed by magic (all spells) | 123.9 | 9.5 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.5 / 0.0 / 0.7 / 0.0 | 2.6 / 0.1 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 120.0 | 360.5 |
| Combat | Points run down | 0.0 | 73.7 |
| Combat | Net points per charged fight, damage counted | +59 | +93 |
| Combat | Net per 100 charger points, damage counted | +25.1 | +29.0 |
| Combat | First round won (charged fights) | 84% | 76% |
| Combat | Net points per charged fight | +41 | +100 |
| Combat | Net points per supported fight / lone fight | +0 / +43 | +120 / +100 |
| Combat | Charged fights on a top-3 enemy unit | 8 of 19 | 12 of 38 |
| Game | Points lost | 578.5 | 327.9 |
| Game | VP from objectives | 609.1 | 825.5 |
| Game | Lone holders (player turns) | 3.5 | 1.7 |

- Mine won / drew / lost: 2 / 2 / 7 of 11 ended games (of 11); mean margin (Mine - Opponent) -491 VP
- The side that went first won 2 of 9 games with a winner
- Points traded per game (both sides' losses): 906
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: h8-mine-6ec093a-p4

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.5 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.3 | +29.8 | 0.0 | 4.7 | - | - | - | - |
| ALREADY CARRIED | 0.2 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARTILLERY RE-ROLL WEIGHED | 2.2 | +0.0 | 0.0 | 73.6 | 0.5 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | 0.1 | +0.1 | 0.0 | 0.0 | 0.2 | +0.2 | 0.0 | 0.0 |
| BEST PRIZE | 0.1 | +3.7 | 11.4 | 0.0 | 0.5 | -13.1 | 13.4 | 45.9 |
| BLOWS WHERE AIMED | 0.1 | -1.1 | 0.0 | 0.0 | 0.6 | -169.5 | 64.6 | 0.0 |
| CANNON PLAN MISSED | 0.6 | +0.0 | 0.0 | 8.6 | 0.6 | +0.0 | 22.8 | 0.0 |
| CANNON PLANNED TARGET | 5.6 | +36.1 | 21.8 | 162.7 | 1.7 | +34.2 | 31.8 | 18.2 |
| CANNON SIGHT KEPT | 1.6 | +0.0 | 0.0 | 10.9 | 0.7 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT COUNTER | 0.1 | +0.0 | 45.9 | 0.0 | - | - | - | - |
| CARRIES OUT SET-UP | - | - | - | - | 0.3 | -31.4 | 47.3 | 0.0 |
| CAST JOB | 0.7 | +31.9 | 70.8 | 0.0 | 0.1 | +0.7 | 5.5 | 0.0 |
| CASTER AWAY FROM SCREEN | 0.6 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.5 | +31.7 | 0.0 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | 1.2 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | - | - | - | - | 0.2 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | 0.5 | +24.0 | 0.0 | 7.7 | 1.2 | +41.7 | 0.0 | 3.5 |
| CHAFF PASSED | - | - | - | - | 0.5 | +0.0 | 0.0 | 0.0 |
| CHARACTER GUNS | 0.5 | +0.0 | 0.0 | 43.5 | 0.6 | +0.0 | 0.0 | 0.0 |
| CHARGE LOSSES | 5.8 | -179.8 | 0.0 | 128.8 | 5.4 | -276.9 | 0.0 | 100.4 |
| CHARGE NOT DECLARED | 0.4 | +0.0 | 13.4 | 0.0 | 1.4 | +0.0 | 86.1 | 8.5 |
| CHARGE NOW FIRST | 1.0 | +0.0 | 59.3 | 36.3 | 2.0 | +0.0 | 192.3 | 31.6 |
| CHARGER SLAIN LOST | 0.5 | -9.5 | 0.0 | 0.0 | 0.3 | -1.3 | 20.9 | 4.1 |
| CHEAP HELPER | - | - | - | - | 0.1 | +0.0 | 0.0 | 10.5 |
| CHEAPEST HOLDER | - | - | - | - | 0.5 | -29.8 | 12.7 | 36.2 |
| COMBAT PIVOT | 0.3 | +0.0 | 0.0 | 71.8 | 0.4 | +0.0 | 36.3 | 15.5 |
| CONVEYANCE SEARCH | 1.1 | +124.4 | 0.0 | 0.0 | - | - | - | - |
| COVER ONCE | 7.4 | -719.8 | 0.0 | 161.3 | 4.5 | -203.1 | 0.0 | 0.0 |
| DEFENSIVE FLOOR | 0.1 | -3.2 | 0.0 | 0.0 | 0.1 | -0.4 | 0.0 | 0.0 |
| DEPLOY BY FIGURES | 9.6 | +43.6 | 0.0 | 10.9 | 8.0 | +31.8 | 0.0 | 7.2 |
| EDGE GIVE GROUND | - | - | - | - | 0.2 | +10.2 | 20.9 | 9.5 |
| ENGINEER BY LORE | 0.4 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | - | - | - | - | 0.1 | +3.8 | 0.0 | 0.0 |
| FALL BACK GOOD ORDER | 1.6 | +2.1 | 26.8 | 46.5 | 2.7 | +2.8 | 253.6 | 9.5 |
| FALLBACK BY WORTH | 0.5 | +10.6 | 0.0 | 7.7 | 0.5 | +0.4 | 0.0 | 0.0 |
| FALLS SHORT | 3.7 | +56.0 | 0.0 | 12.1 | 23.7 | +314.2 | 0.0 | 189.6 |
| FEATURE BUFFS | 3.5 | +142.8 | 0.0 | 4.7 | 0.8 | +22.9 | 0.0 | 20.9 |
| FIGHT LIFT | - | - | - | - | 0.1 | +0.3 | 30.8 | 0.0 |
| FIGHT TO THE END | 0.9 | +46.9 | 25.8 | 41.7 | 1.4 | +85.9 | 147.8 | 9.5 |
| FIRE IN ORDER | 0.2 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 5.5 | 0.0 |
| FIVE ACTION | 48.3 | +3329.6 | 247.0 | 676.0 | 50.7 | +3238.6 | 493.2 | 405.2 |
| FLANK NOT WEIGHED | 7.2 | +0.0 | 0.0 | 111.4 | 4.7 | +0.0 | 0.0 | 2.7 |
| FOLLOW UP WEIGHED | 0.7 | +101.0 | 0.0 | 30.8 | 0.5 | +85.0 | 0.0 | 0.0 |
| FOUR ROUNDS | 2.3 | +204.5 | 86.1 | 46.5 | 4.1 | +415.3 | 327.0 | 40.1 |
| FRIEND CHARGES FIRST | 0.1 | -1.0 | 0.0 | 0.0 | 0.1 | -9.9 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 0.5 | -10.4 | 0.0 | 0.0 | 0.1 | -0.3 | 0.0 | 0.0 |
| FRIENDS SHOTS CHECKED | 0.1 | +2.6 | 0.0 | 0.0 | 0.2 | +2.4 | 0.0 | 18.1 |
| GIVES UP | - | - | - | - | 0.2 | -1.9 | 17.3 | 0.0 |
| GROUND FLIERS | 0.1 | +0.1 | 0.0 | 0.0 | - | - | - | - |
| GUN FIGURES | 2.3 | +20.0 | 56.9 | 38.6 | 0.3 | +0.1 | 5.5 | 0.0 |
| GUN MASK | 0.5 | +7.1 | 0.0 | 9.5 | 1.2 | +41.4 | 0.0 | 0.0 |
| HARD STAY DROPPED | 2.7 | +0.0 | 0.0 | 21.2 | 0.6 | +0.0 | 0.0 | 0.0 |
| HE SHOOTS OR CHARGES | 2.1 | +0.0 | 0.0 | 65.5 | 2.3 | +0.0 | 0.0 | 17.9 |
| HELPER ALREADY ASKED | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS CHARGE DENIED | 0.1 | +1.8 | 0.0 | 0.0 | 0.4 | +20.3 | 5.5 | 0.0 |
| HIS CHARGE LIST | 2.8 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 2.7 | +0.0 | 0.0 | 21.6 | 3.5 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 1.6 | -39.5 | 0.0 | 40.6 | 1.6 | -83.9 | 0.0 | 58.1 |
| HIS ONE QUARTER | 2.5 | +0.0 | 0.0 | 5.9 | - | - | - | - |
| HIS RANDOM MOVE | 4.1 | +0.0 | 0.0 | 75.9 | 1.6 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 18.2 | +613.5 | 0.0 | 316.4 | 22.9 | +1166.8 | 0.0 | 258.1 |
| HIS TURN DENIED | 0.5 | +8.4 | 14.4 | 5.5 | 2.5 | +91.4 | 264.3 | 19.3 |
| HOLD ODDS | 15.5 | +0.0 | 0.0 | 78.5 | - | - | - | - |
| HOLDER ASSIGNMENT | 14.5 | +1506.6 | 0.0 | 74.9 | - | - | - | - |
| HOLDER AT DEPLOYMENT | - | - | - | - | 1.9 | +273.0 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.5 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 1.7 | -36.3 | 86.1 | 46.5 | 3.6 | -205.3 | 320.8 | 27.5 |
| HORN WORTH | - | - | - | - | 0.1 | +1.8 | 0.0 | 45.9 |
| HUNT IN PAIRS | 0.2 | +0.7 | 0.0 | 0.0 | 0.5 | +15.8 | 0.0 | 0.0 |
| HUNT KEPT | - | - | - | - | 0.1 | +0.0 | 0.0 | 9.5 |
| HUNT RESULT | - | - | - | - | 0.1 | +0.0 | 0.0 | 0.0 |
| HUNT THE GUNS | - | - | - | - | 0.1 | +33.0 | 0.0 | 9.5 |
| IDLE COST | 1.1 | -6.2 | 0.0 | 7.7 | 10.7 | -148.8 | 0.0 | 30.8 |
| KEEP FALLS | 0.1 | +0.6 | 0.0 | 0.0 | - | - | - | - |
| KEEPS SCOUTS OR AMBUSH | 0.2 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| LANE BY FIGURES | 0.3 | +10.5 | 0.0 | 0.0 | 0.9 | +29.1 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 3.3 | +0.0 | 104.5 | 144.9 | 5.5 | +0.0 | 49.4 | 86.3 |
| LONE CHARACTER SAFE SPOT | - | - | - | - | 0.1 | +0.0 | 0.0 | 0.0 |
| LONE WIZARD KEPT IN | 0.9 | +59.1 | 0.0 | 0.0 | 0.6 | +44.2 | 0.0 | 0.0 |
| LONG SHOT | 0.5 | +4.3 | 13.4 | 0.0 | 0.2 | +1.4 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | - | - | - | - | 0.5 | +4.2 | 0.0 | 0.0 |
| MANOEUVRE | 0.9 | +15.8 | 0.0 | 0.0 | 1.0 | +11.0 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.3 | +39.0 | 0.0 | 0.0 | - | - | - | - |
| MARCH BY THE SUM | 0.5 | +37.8 | 0.0 | 0.0 | 0.1 | +0.4 | 0.0 | 18.1 |
| MARCH CHECK | 1.0 | +77.7 | 0.0 | 0.0 | 1.0 | +46.9 | 0.0 | 32.5 |
| MARCH OVER CASTS | 0.5 | -7.0 | 0.0 | 0.0 | 0.3 | +59.8 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 6.3 | +83.4 | 0.0 | 41.2 | 5.2 | +45.6 | 0.0 | 15.9 |
| MISSILES IN THE MOVE | 4.3 | +284.0 | 0.0 | 7.4 | 2.5 | +22.3 | 0.0 | 14.4 |
| MISSILES NEXT TURN | 5.3 | +212.2 | 0.0 | 7.4 | 3.4 | +21.7 | 0.0 | 32.5 |
| MODEL FACING | 0.6 | +140.0 | 0.0 | 5.5 | - | - | - | - |
| MOVE SPELL IN RANGE | 0.6 | +34.4 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL NOT WORTH | - | - | - | - | 0.1 | -0.0 | 0.0 | 0.0 |
| MOVE SPELL OUT OF RANGE | 1.7 | -55.7 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL SPOT | 0.7 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 3.0 | +253.0 | 0.0 | 46.5 | 3.8 | +685.4 | 0.0 | 0.0 |
| MOVES UNITS SPELL | 0.2 | +10.0 | 0.0 | 0.0 | 0.1 | +0.7 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 6.1 | +263.8 | 0.0 | 98.5 | 6.1 | +274.4 | 0.0 | 124.1 |
| NEEDED THERE | - | - | - | - | 0.2 | +17.0 | 4.7 | 0.0 |
| NEXT CHARGE BY LIST | 4.6 | -184.5 | 9.5 | 56.0 | 5.5 | -259.4 | 0.0 | 102.3 |
| NEXT OBJECTIVE NEARER | 0.2 | -0.2 | 0.0 | 5.9 | 12.5 | -668.5 | 51.1 | 146.8 |
| NO DOUBLE ROUNDS | 1.8 | -111.4 | 72.7 | 46.5 | 3.3 | -115.2 | 282.2 | 37.4 |
| NO RALLY LEFT | 0.1 | +4.8 | 0.0 | 0.0 | - | - | - | - |
| NOT TURNED | 0.3 | +0.0 | 0.0 | 7.7 | 0.3 | -3.4 | 0.0 | 0.0 |
| NOT WORTH A CAST | 0.3 | -0.3 | 0.0 | 0.0 | 0.8 | -0.7 | 0.0 | 0.0 |
| OFF BEST | 0.3 | -3.4 | 0.0 | 0.0 | 0.8 | -8.5 | 0.0 | 2.7 |
| ONE CHARGE A CHARGER | 4.3 | +0.0 | 0.0 | 59.4 | 2.6 | +0.0 | 0.0 | 14.1 |
| ONE FIGHT FORMULA | 4.2 | -59.5 | 0.0 | 54.6 | 4.7 | -141.5 | 0.0 | 10.5 |
| ONE OBJECTIVE FORMULA | 5.5 | +97.2 | 0.0 | 47.3 | 3.6 | +22.2 | 0.0 | 10.5 |
| ONE TARGET A SHOOTER | 13.1 | +275.8 | 0.0 | 180.0 | 20.4 | +583.6 | 0.0 | 144.0 |
| OPENS UP | - | - | - | - | 0.2 | +3.3 | 8.6 | 0.0 |
| OVERRUNS AWAY | 0.3 | +4.2 | 12.5 | 0.0 | 0.4 | +36.8 | 43.1 | 0.0 |
| PATHS CROSS | 2.8 | +128.5 | 0.0 | 10.5 | 5.5 | +198.0 | 0.0 | 19.7 |
| PERIAPT WORTH | - | - | - | - | 0.1 | +4.9 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.2 | -2.7 | 0.0 | 4.7 | 0.2 | -0.5 | 0.0 | 2.7 |
| PLAN RESULT | 42.5 | +435.5 | 192.9 | 803.0 | 44.9 | +453.5 | 218.7 | 450.5 |
| PURSUES BIG PREY | - | - | - | - | 0.1 | -2.4 | 0.0 | 0.0 |
| QUARTER ODDS | 8.5 | +770.2 | 31.5 | 36.3 | - | - | - | - |
| RANDOM MOVE BY FIGURES | 0.4 | +22.0 | 0.0 | 46.4 | 2.9 | +23.3 | 0.0 | 0.0 |
| REAL GROUND | 0.4 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| REDIRECT BY WHAT IT STOPS | 0.2 | -1.9 | 0.0 | 7.7 | 0.5 | -12.8 | 0.0 | 2.7 |
| REDIRECT COUNTER | 2.5 | +234.6 | 0.0 | 26.3 | 3.7 | +143.5 | 0.0 | 9.9 |
| REDIRECT WEIGHED | 0.1 | +3.7 | 11.4 | 0.0 | 0.5 | -5.5 | 36.1 | 91.8 |
| REFORMS TO MEET IT | 0.5 | -13.1 | 0.0 | 5.5 | 0.7 | -53.5 | 0.0 | 0.0 |
| REFUSING RETIRES | 0.5 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| RESERVE FALL BACK | 0.3 | +46.3 | 0.0 | 10.2 | 1.5 | +40.3 | 0.0 | 7.3 |
| RESTRAINS TO SHOOT | - | - | - | - | 0.2 | +3.1 | 0.0 | 0.0 |
| RISK BY ARC | 1.6 | +22.3 | 40.2 | 46.5 | 2.5 | -38.7 | 229.4 | 40.1 |
| RISK BY HIS FIGURE | 14.5 | -131.9 | 0.0 | 228.1 | 14.5 | -192.6 | 0.0 | 130.0 |
| RISK ON THE WAY | 0.5 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| RUN DOWN | 1.3 | -18.8 | 26.8 | 10.2 | 2.3 | -14.6 | 164.9 | 27.5 |
| SAME CHARGE LATER | 0.1 | -6.0 | 0.0 | 0.0 | 0.1 | -0.5 | 0.0 | 0.0 |
| SCOUT SPOT | 0.1 | -0.0 | 0.0 | 0.0 | 0.4 | +0.4 | 0.0 | 0.0 |
| SCOUT WAITS | 0.1 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.1 | -14.6 | 0.0 | 0.0 | - | - | - | - |
| SEARCH SPOT | 5.5 | +207.2 | 0.0 | 46.4 | 8.5 | +317.5 | 0.0 | 2.7 |
| SELF MOVE SPELL | - | - | - | - | 0.5 | +30.5 | 0.0 | 0.0 |
| SET UP TOGETHER | 0.2 | +1.0 | 0.0 | 5.5 | 1.1 | +11.7 | 0.0 | 0.0 |
| SET-UP ANY TARGET | 0.4 | +17.8 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | 0.5 | +1.1 | 0.0 | 0.0 | 0.5 | +0.8 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.7 | +155.9 | 58.1 | 28.2 | 0.8 | +17.5 | 26.4 | 18.1 |
| SHORT GUN FORWARD | 0.5 | +0.0 | 0.0 | 10.9 | - | - | - | - |
| SHOT OR CHARGE | 0.4 | -6.3 | 0.0 | 0.0 | 0.4 | -4.3 | 43.3 | 0.0 |
| SHOT RISK POINTS | 9.9 | +106.7 | 0.0 | 152.4 | 15.2 | +91.6 | 0.0 | 256.9 |
| SHOTS IN THE MOVE | 16.3 | +408.4 | 0.0 | 406.7 | 14.9 | +330.4 | 0.0 | 50.3 |
| SPELL SETS UP CHARGE | 0.4 | +17.8 | 0.0 | 0.0 | - | - | - | - |
| SPELL WORTH | 0.7 | +12.2 | 0.0 | 32.3 | 2.1 | +43.5 | 55.7 | 24.9 |
| SPELLS IN THE FIGHT | 0.1 | +0.6 | 0.0 | 0.0 | 0.3 | -3.2 | 0.0 | 0.0 |
| STAND AND SHOOT | 0.3 | -2.1 | 14.4 | 5.5 | 0.5 | -5.0 | 94.5 | 0.0 |
| STANDS FOR A REASON | - | - | - | - | 0.5 | +0.0 | 11.4 | 18.1 |
| STANDS STILL | 22.4 | +0.0 | 160.9 | 342.3 | 11.5 | +0.0 | 155.3 | 57.0 |
| STAY WORTH | 16.8 | +39.0 | 50.1 | 192.8 | 15.6 | +161.3 | 105.0 | 68.5 |
| STOPS | - | - | - | - | 0.1 | +5.3 | 0.0 | 9.5 |
| STUCK PIVOT | - | - | - | - | 0.4 | +0.0 | 0.0 | 0.0 |
| SUPPORT NARROWED | 0.8 | +0.0 | 21.9 | 36.3 | 1.2 | +0.0 | 32.3 | 40.1 |
| SURE REACH TOGETHER | 0.1 | +0.2 | 0.0 | 30.8 | 0.8 | +40.1 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 3.9 | +0.0 | 0.0 | 44.1 | 6.0 | +0.0 | 0.0 | 19.7 |
| THE PROMISE ADDS | 0.4 | -33.9 | 0.0 | 0.0 | 0.2 | -10.2 | 21.7 | 0.0 |
| THE PROMISED MOVE | 0.6 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| TIED UP BY THE SUM | 0.1 | +3.4 | 12.5 | 0.0 | 0.7 | +80.8 | 67.9 | 18.1 |
| TIME ON OUR SIDE | 31.6 | +483.4 | 0.0 | 327.2 | 5.3 | +97.5 | 0.0 | 7.3 |
| WAITS AGAIN | 2.0 | +0.0 | 0.0 | 10.2 | 0.5 | +0.0 | 0.0 | 0.0 |
| WALK PROMISE | 0.2 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WAR ENGINE CHARGES | 0.2 | +50.4 | 45.9 | 0.0 | - | - | - | - |
| WAR ENGINE JOBS | 0.5 | +0.0 | 45.9 | 0.0 | - | - | - | - |
| WHO HITS BACK | - | - | - | - | 0.5 | +44.2 | 0.0 | 0.0 |
| WHOLE FIGHT | 0.2 | -0.7 | 45.9 | 0.0 | 0.4 | +3.2 | 4.7 | 2.7 |
| WHOLE FIGHT GAIN | 0.3 | +34.3 | 0.0 | 0.0 | 0.1 | +7.0 | 10.9 | 4.1 |
| WIDER SPREAD | 1.3 | -4.7 | 58.4 | 46.5 | 2.6 | -9.0 | 202.2 | 9.8 |
| WOUNDS ON THE RANKS | 2.7 | +90.1 | 0.0 | 0.0 | 0.7 | +19.5 | 0.0 | 0.0 |

### Rule changes: h8-mine-6ec093a-p4

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HOLDER ASSIGNMENT | 159 | 159 | 148 | 13.45 | +8407 | +56.8 |
| SEARCH SPOT | 154 | 154 | 143 | 13.00 | +5773 | +40.4 |
| HIS SHOT LIST | 452 | 452 | 124 | 11.27 | +2638 | +21.3 |
| DEPLOY BY FIGURES | 194 | 194 | 123 | 11.18 | +1578 | +12.8 |
| FIVE ACTION | 1089 | 1087 | 105 | 9.55 | +3034 | +28.9 |
| LEGAL CHARGES ONLY | 96 | 96 | 96 | 8.73 | +0 | +0.0 |
| PATHS CROSS | 91 | 91 | 91 | 8.27 | +3591 | +39.5 |
| ONE TARGET A SHOOTER | 368 | 368 | 88 | 8.00 | +768 | +8.7 |
| TIME ON OUR SIDE | 406 | 354 | 74 | 6.73 | +299 | +4.0 |
| SHOT RISK POINTS | 276 | 276 | 42 | 3.82 | +1650 | +39.3 |
| MOVE TO CHARGE COMPUTED | 75 | 75 | 41 | 3.73 | +3903 | +95.2 |
| FOUR ROUNDS | 70 | 68 | 40 | 3.64 | +1827 | +45.7 |
| HARD STAY DROPPED | 37 | 37 | 37 | 3.36 | +0 | +0.0 |
| ARTILLERY RE-ROLL WEIGHED | 30 | 30 | 30 | 2.73 | +0 | +0.0 |
| CANNON SIGHT KEPT | 26 | 26 | 26 | 2.36 | +0 | +0.0 |
| COVER ONCE | 130 | 101 | 26 | 2.36 | +377 | +14.5 |
| RANDOM MOVE BY FIGURES | 36 | 36 | 26 | 2.36 | +499 | +19.2 |
| MAX FOR POSITIONING | 126 | 123 | 25 | 2.27 | +28 | +1.1 |
| SHOTS IN THE MOVE | 343 | 300 | 22 | 2.00 | +444 | +20.2 |
| NEXT OBJECTIVE NEARER | 140 | 140 | 21 | 1.91 | +192 | +9.1 |
| REDIRECT COUNTER | 68 | 54 | 20 | 1.82 | +1930 | +96.5 |
| CANNON PLANNED TARGET | 81 | 81 | 19 | 1.73 | +40 | +2.1 |
| CHARGE NOT DECLARED | 19 | 19 | 19 | 1.73 | -2934 | -154.4 |
| RESERVE FALL BACK | 19 | 19 | 19 | 1.73 | +953 | +50.2 |
| FALLS SHORT | 302 | 254 | 17 | 1.55 | +19 | +1.1 |
| LONE WIZARD KEPT IN | 17 | 17 | 17 | 1.55 | +1136 | +66.8 |
| ADVANCE LANE KEPT | 16 | 16 | 16 | 1.45 | +0 | +0.0 |
| SHOOTS FROM THE BEST SPOT | 28 | 28 | 16 | 1.45 | +396 | +24.8 |
| FOLLOW UP WEIGHED | 14 | 14 | 14 | 1.27 | +2046 | +146.1 |
| MARCH CHECK | 22 | 22 | 14 | 1.27 | +285 | +20.4 |
| MISSILES IN THE MOVE | 75 | 47 | 14 | 1.27 | +419 | +29.9 |
| RISK BY ARC | 45 | 44 | 14 | 1.27 | +185 | +13.2 |
| LANE BY FIGURES | 13 | 13 | 13 | 1.18 | +435 | +33.5 |
| MANOEUVRE | 21 | 21 | 13 | 1.18 | +341 | +26.3 |
| RISK BY HIS FIGURE | 320 | 320 | 13 | 1.18 | +832 | +64.0 |
| OFF BEST | 12 | 12 | 12 | 1.09 | -131 | -10.9 |
| QUARTER ODDS | 94 | 94 | 12 | 1.09 | +1316 | +109.6 |
| NEARER NOT NEEDED | 134 | 123 | 11 | 1.00 | +436 | +39.6 |
| SHOOTERS IN TWO RANKS | 11 | 11 | 11 | 1.00 | +21 | +1.9 |
| WOUNDS ON THE RANKS | 38 | 38 | 11 | 1.00 | +287 | +26.1 |
| CHAFF IN THE MOVE | 19 | 19 | 10 | 0.91 | +31 | +3.1 |
| CHARGE LOSSES | 123 | 123 | 10 | 0.91 | +636 | +63.6 |
| HOLDER AT DEPLOYMENT | 21 | 21 | 10 | 0.91 | +443 | +44.3 |
| NEXT CHARGE BY LIST | 111 | 111 | 10 | 0.91 | +166 | +16.6 |
| CASTER AWAY FROM SCREEN | 9 | 9 | 9 | 0.82 | +0 | +0.0 |
| FEATURE BUFFS | 47 | 47 | 9 | 0.82 | +353 | +39.2 |
| HIS TURN DENIED | 33 | 31 | 9 | 0.82 | +254 | +28.2 |
| HOLDS AMBUSHERS | 9 | 9 | 9 | 0.82 | +0 | +0.0 |
| GUN MASK | 19 | 19 | 8 | 0.73 | +176 | +22.0 |
| IDLE COST | 130 | 94 | 8 | 0.73 | +84 | +10.5 |
| STAY WORTH | 357 | 327 | 8 | 0.73 | +68 | +8.5 |
| TIED UP BY THE SUM | 9 | 9 | 8 | 0.73 | +238 | +29.7 |
| CHARGE NOW FIRST | 33 | 33 | 7 | 0.64 | -313 | -44.7 |
| COMBAT PIVOT | 7 | 7 | 7 | 0.64 | +0 | +0.0 |
| FIGHT TO THE END | 25 | 23 | 7 | 0.64 | +393 | +56.1 |
| MODEL FACING | 7 | 7 | 7 | 0.64 | +1540 | +219.9 |
| REDIRECT WEIGHED | 7 | 7 | 7 | 0.64 | +955 | +136.5 |
| BEST PRIZE | 6 | 6 | 6 | 0.55 | -231 | -38.5 |
| MARCH BY THE SUM | 6 | 6 | 6 | 0.55 | +420 | +69.9 |
| MISSILES NEXT TURN | 95 | 60 | 6 | 0.55 | +36 | +6.0 |
| SHORT GUN FORWARD | 6 | 6 | 6 | 0.55 | +0 | +0.0 |
| WHO HITS BACK | 6 | 6 | 6 | 0.55 | +388 | +64.7 |
| CHAFF PASSED | 5 | 5 | 5 | 0.45 | +0 | +0.0 |
| ONE OBJECTIVE FORMULA | 101 | 80 | 5 | 0.45 | +84 | +16.9 |
| SCOUT WAITS | 5 | 5 | 5 | 0.45 | +0 | +0.0 |
| SUPPORT NARROWED | 22 | 22 | 5 | 0.45 | -19 | -3.9 |
| CAST JOB | 9 | 9 | 4 | 0.36 | +27 | +6.8 |
| FIRE IN ORDER | 4 | 4 | 4 | 0.36 | +0 | +0.0 |
| PIVOT GUARDS FLANK | 4 | 4 | 4 | 0.36 | -34 | -8.6 |
| STUCK PIVOT | 4 | 4 | 4 | 0.36 | +0 | +0.0 |
| SURE REACH TOGETHER | 10 | 10 | 4 | 0.36 | +3 | +0.7 |
| AFTERMATH IN POINTS | 3 | 3 | 3 | 0.27 | +328 | +109.4 |
| CASTING BLOCK | 5 | 5 | 3 | 0.27 | +40 | +13.2 |
| FALL BACK GOOD ORDER | 48 | 46 | 3 | 0.27 | +15 | +4.9 |
| FALLBACK BY WORTH | 10 | 10 | 3 | 0.27 | +121 | +40.3 |
| FRIENDS SHOTS CHECKED | 3 | 3 | 3 | 0.27 | +55 | +18.4 |
| MOVES UNITS SPELL | 3 | 3 | 3 | 0.27 | +118 | +39.2 |
| ONE FIGHT FORMULA | 98 | 45 | 3 | 0.27 | +6 | +2.0 |
| CARRIES OUT SET-UP | 3 | 3 | 2 | 0.18 | -345 | -172.7 |
| CASTS FROM BEHIND | 2 | 2 | 2 | 0.18 | +0 | +0.0 |
| EDGE GIVE GROUND | 2 | 2 | 2 | 0.18 | +15 | +7.6 |
| HONEST WORTH | 59 | 57 | 2 | 0.18 | +13 | +6.7 |
| HUNT IN PAIRS | 7 | 3 | 2 | 0.18 | +5 | +2.3 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.18 | +0 | +0.0 |
| NEEDED THERE | 2 | 2 | 2 | 0.18 | +0 | +0.0 |
| OVERRUNS AWAY | 7 | 7 | 2 | 0.18 | +26 | +13.2 |
| REFUSING RETIRES | 5 | 5 | 2 | 0.18 | -0 | -0.2 |
| RESTRAINS TO SHOOT | 2 | 2 | 2 | 0.18 | +35 | +17.3 |
| SET UP TOGETHER | 14 | 9 | 2 | 0.18 | +3 | +1.5 |
| WAR ENGINE CHARGES | 2 | 2 | 2 | 0.18 | +154 | +77.2 |
| WHOLE FIGHT GAIN | 4 | 4 | 2 | 0.18 | +220 | +110.2 |
| WIDER SPREAD | 43 | 42 | 2 | 0.18 | +4 | +2.1 |
| FACES THE THREAT | 1 | 1 | 1 | 0.09 | +41 | +41.3 |
| HIS CHARGE DENIED | 5 | 5 | 1 | 0.09 | +172 | +172.0 |
| HIS MOVE AND SHOT | 36 | 36 | 1 | 0.09 | +44 | +43.9 |
| HORN WORTH | 1 | 1 | 1 | 0.09 | +20 | +19.9 |
| KEEP FALLS | 1 | 1 | 1 | 0.09 | +10 | +10.5 |
| MOVE SPELL IN RANGE | 7 | 2 | 1 | 0.09 | +41 | +41.2 |
| NO RALLY LEFT | 1 | 1 | 1 | 0.09 | +47 | +47.4 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.09 | +54 | +54.4 |
| PURSUES BIG PREY | 1 | 1 | 1 | 0.09 | -26 | -26.0 |
| REDIRECT BY WHAT IT STOPS | 8 | 8 | 1 | 0.09 | +1 | +1.1 |
| STOPS | 1 | 1 | 1 | 0.09 | +35 | +35.4 |
| THE PROMISE ADDS | 6 | 6 | 1 | 0.09 | +9 | +8.6 |
| WAR ENGINE JOBS | 5 | 5 | 1 | 0.09 | -19 | -18.9 |
| WHOLE FIGHT | 6 | 6 | 1 | 0.09 | +0 | +0.0 |
| ALREADY CARRIED | 2 | not checked | - | - | - | - |
| BACKUP TARGETS | 3 | 3 | 0 | 0.00 | - | - |
| BLOWS WHERE AIMED | 8 | 7 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 14 | 14 | 0 | 0.00 | - | - |
| CARRIES OUT COUNTER | 1 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 16 | trace | - | - | - | - |
| CHARACTER GUNS | 12 | 12 | 0 | 0.00 | - | - |
| CHARGER SLAIN LOST | 9 | 9 | 0 | 0.00 | - | - |
| CHEAP HELPER | 1 | not checked | - | - | - | - |
| CHEAPEST HOLDER | 5 | 5 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 12 | not checked | - | - | - | - |
| DEFENSIVE FLOOR | 2 | 2 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT LIFT | 1 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 131 | not checked | - | - | - | - |
| FRIEND CHARGES FIRST | 2 | 2 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 7 | 7 | 0 | 0.00 | - | - |
| GIVES UP | 2 | 2 | 0 | 0.00 | - | - |
| GROUND FLIERS | 1 | not checked | - | - | - | - |
| GUN FIGURES | 28 | not checked | - | - | - | - |
| HE SHOOTS OR CHARGES | 48 | 48 | 0 | 0.00 | - | - |
| HELPER ALREADY ASKED | 1 | not checked | - | - | - | - |
| HIS CHARGE LIST | 56 | 56 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 68 | 68 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 28 | 28 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 63 | 63 | 0 | 0.00 | - | - |
| HOLD ODDS | 170 | 170 | 0 | 0.00 | - | - |
| HUNT KEPT | 1 | trace | - | - | - | - |
| HUNT RESULT | 1 | trace | - | - | - | - |
| HUNT THE GUNS | 1 | trace | - | - | - | - |
| LONE CHARACTER SAFE SPOT | 1 | not checked | - | - | - | - |
| LONG SHOT | 7 | 7 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 5 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 3 | trace | - | - | - | - |
| MARCH OVER CASTS | 9 | 9 | 0 | 0.00 | - | - |
| MOVE SPELL NOT WORTH | 1 | not checked | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 19 | trace | - | - | - | - |
| MOVE SPELL SPOT | 9 | not checked | - | - | - | - |
| NO DOUBLE ROUNDS | 56 | 54 | 0 | 0.00 | - | - |
| NOT TURNED | 6 | 6 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 12 | not checked | - | - | - | - |
| ONE CHARGE A CHARGER | 76 | 76 | 0 | 0.00 | - | - |
| OPENS UP | 2 | 2 | 0 | 0.00 | - | - |
| PLAN RESULT | 962 | trace | - | - | - | - |
| REAL GROUND | 4 | 4 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 13 | 13 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 5 | 5 | 0 | 0.00 | - | - |
| RUN DOWN | 39 | 38 | 0 | 0.00 | - | - |
| SAME CHARGE LATER | 2 | 2 | 0 | 0.00 | - | - |
| SCOUT SPOT | 5 | 5 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 1 | 1 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 6 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 4 | not checked | - | - | - | - |
| SHOT OR CHARGE | 8 | 8 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 4 | not checked | - | - | - | - |
| SPELL WORTH | 31 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 4 | 4 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 8 | 7 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 5 | 5 | 0 | 0.00 | - | - |
| STANDS STILL | 373 | 373 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 109 | not checked | - | - | - | - |
| THE PROMISED MOVE | 14 | not checked | - | - | - | - |
| WAITS AGAIN | 28 | 28 | 0 | 0.00 | - | - |
| WALK PROMISE | 2 | 2 | 0 | 0.00 | - | - |

### Off best figure: h8-mine-6ec093a-p4

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| CHARGE NOT DECLARED | rule | 0.36 | 1.36 | 154.4 |
| HOLDER ASSIGNMENT | rule | 1.55 | - | 18.9 |
| PATHS CROSS | rule | 0.27 | 0.64 | 8.5 |
| CHARGE NOW FIRST | rule | 0.18 | 0.45 | 44.7 |
| JOB FIRST | gate | - | 0.45 | 8.5 |
| BEST PRIZE | rule | 0.09 | 0.27 | 57.5 |
| PIVOT GUARDS FLANK | rule | 0.18 | 0.18 | 8.6 |
| SUPPORT NARROWED | rule | 0.18 | 0.18 | 4.7 |
| CARRIES OUT SET-UP | rule | - | 0.18 | 172.7 |
| FIGHT ORDER BAND | gate | 0.09 | 0.09 | 0.6 |
| REDIRECT WEIGHED | rule | 0.09 | 0.09 | 35.8 |
| AFTERMATH BAND | gate | - | 0.09 | 2.1 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.09 | - | 14.2 |
| FALLBACK | gate | - | 0.09 | 3.3 |
| NO REASON | gate | 0.09 | - | 22.5 |
| PURSUES BIG PREY | rule | - | 0.09 | 26.0 |
| TURN GATE | gate | - | 0.09 | 45.0 |
| WAR ENGINE JOBS | rule | 0.09 | - | 18.9 |

### Plans: h8-mine-6ec093a-p4

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.5 | 41% | 217 | 80 | 37% |
| Mine | join | 0.3 | 100% | 9 | 0 | 0% |
| Mine | move | 30.0 | 94% | 2030 | 0 | 0% |
| Mine | shoot | 10.5 | 52% | 515 | 355 | 69% |
| Mine | support | 0.3 | 67% | 0 | 0 | - |
| Opponent | charge | 3.3 | 61% | 533 | 277 | 52% |
| Opponent | join | 0.9 | 100% | 49 | 0 | 0% |
| Opponent | move | 35.4 | 96% | 1899 | 0 | 0% |
| Opponent | shoot | 4.9 | 54% | 237 | 177 | 74% |
| Opponent | support | 0.5 | 80% | 6 | 0 | 0% |

### Packages: hunt the guns, h8-mine-6ec093a-p4

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 52 |
| Opponent | 0.1 | 1 | 0 | 100% | 0% | 0% | - | 363 | 0 | 0% | 53 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 55 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 117 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Tomb Kings of Khemri | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 195 |
| Vampire Counts | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 45 |
| Warriors of Chaos | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Wood Elf Realms | 0.5 | 1 | 0 | 100% | 0% | 0% | - | 363 | 0 | 0% | 169 |

### Battle groups: h8-mine-6ec093a-p4

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 2.5 | 22% | 83% | 0% | - | 17% | 0% | 33% | 33% | 17% |
| Opponent | REDIRECT COUNTER | 3.7 | 22% | 89% | 44% | 0% | 0% | 0% | 0% | 80% | 20% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: h8-mine-6ec093a-p4

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 6 | 0 (6) | 0 | 0 | 40 | 67% | 3.0 | 0 (2) | 0 (3) | 0 (1) | 0 (4) | 0 (2) |
| Mine | Character | 41 | 28 (41) | 28 | 0 | 35 | 22% | 2.6 | 23 (17) | 17 (13) | 173 (3) | 53 (13) | 23 (20) |
| Mine | Clean-up | 6 | 44 (6) | 0 | 44 | 28 | 67% | 1.0 | 11 (3) | 77 (3) | - | 49 (5) | 0 (1) |
| Mine | Fast Hammer | 10 | 21 (10) | 21 | 0 | 37 | 40% | 4.5 | 0 (1) | 0 (5) | 40 (4) | 27 (8) | 0 (2) |
| Mine | Hammer | 28 | 33 (28) | 11 | 22 | 19 | 29% | 2.7 | 55 (10) | 26 (14) | 15 (4) | 46 (17) | 17 (11) |
| Mine | Holder | 10 | 114 (10) | 0 | 114 | 0 | 40% | 5.7 | 166 (3) | 111 (5) | 17 (2) | 121 (6) | 105 (4) |
| Mine | Shooter | 16 | 61 (16) | 8 | 53 | 43 | 0% | 2.1 | 37 (7) | 113 (7) | 8 (2) | 50 (13) | 115 (3) |
| Mine | War machine | 25 | 20 (25) | 20 | 0 | 62 | 4% | 1.4 | 18 (15) | 29 (8) | 0 (2) | 0 (6) | 26 (19) |
| Mine | Wizard | 6 | 0 (6) | 0 | 0 | 0 | 33% | 4.8 | 0 (5) | 0 (1) | - | 0 (1) | 0 (5) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 0% | 6.0 | 0 (1) | - | - | - | 0 (1) |
| Opponent | Chaff | 23 | 22 (23) | 4 | 18 | 30 | 30% | 3.4 | 0 (8) | 39 (10) | 13 (5) | 24 (16) | 18 (7) |
| Opponent | Character | 27 | 55 (27) | 55 | 0 | 18 | 30% | 2.1 | 54 (7) | 65 (7) | 57 (11) | 56 (14) | 62 (11) |
| Opponent | Clean-up | 10 | 50 (10) | 7 | 43 | 22 | 50% | 3.0 | 15 (3) | 66 (5) | 52 (2) | 40 (6) | 65 (4) |
| Opponent | Fast Hammer | 11 | 51 (11) | 11 | 41 | 35 | 55% | 3.0 | 45 (4) | 92 (4) | 0 (3) | 58 (9) | 0 (2) |
| Opponent | Hammer | 17 | 25 (17) | 22 | 3 | 11 | 41% | 3.4 | 15 (4) | 30 (10) | 26 (3) | 40 (8) | 12 (9) |
| Opponent | Holder | 13 | 127 (13) | 12 | 115 | 0 | 38% | 2.6 | 140 (5) | 169 (5) | 32 (3) | 135 (12) | 29 (1) |
| Opponent | Shooter | 10 | 75 (10) | 0 | 75 | 10 | 20% | 2.0 | 83 (4) | 109 (2) | 25 (4) | 64 (6) | 90 (4) |
| Opponent | Support | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | 0 (1) | - | - | - | 0 (1) |
| Opponent | War machine | 7 | 73 (7) | 73 | 0 | 13 | 0% | 2.1 | 99 (5) | 0 (1) | 0 (1) | - | 73 (7) |
| Opponent | Wizard | 10 | 11 (10) | 11 | 0 | 0 | 20% | 2.0 | 0 (3) | 42 (2) | 0 (5) | 0 (2) | 13 (8) |

### Charged fights: h8-mine-6ec093a-p4

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 308 | 0 | 1.5 | 1.2 | 0 | 0 | +0 | 3 of 6 | 6 of 6 | +0 | +0 |
| Mine | Chaos Dwarfs | 4 | 100 | 291 | 2.5 | 1.0 | 116 | 48 | +68 | 5 of 10 | 8 of 10 | - | +68 |
| Mine | Dwarfen Mountain Holds | 3 | 80 | 49 | 1.0 | 1.0 | 49 | 20 | +29 | 0 of 3 | 2 of 3 | - | +29 |
| **Mine** | all armies | 11 | 170 | 119 | 1.7 | 1.1 | 69 | 28 | +41 | 8 of 19 | 16 of 19 | +0 | +43 |
| Opponent | Empire of Man | 1 | 610 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | High Elf Realms | 1 | 0 | 420 | 4.0 | 1.0 | 105 | 0 | +105 | 2 of 4 | 2 of 4 | - | +105 |
| Opponent | Kingdom of Bretonnia | 2 | 110 | 489 | 3.5 | 1.0 | 140 | 0 | +140 | 0 of 7 | 7 of 7 | - | +140 |
| Opponent | Skaven | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Tomb Kings of Khemri | 1 | 0 | 493 | 4.0 | 1.0 | 123 | 0 | +123 | 0 of 4 | 4 of 4 | - | +123 |
| Opponent | Vampire Counts | 1 | 0 | 809 | 6.0 | 1.2 | 135 | 0 | +135 | 2 of 6 | 5 of 6 | +120 | +138 |
| Opponent | Warriors of Chaos | 2 | 0 | 469 | 4.5 | 1.0 | 104 | 37 | +67 | 5 of 9 | 5 of 9 | - | +67 |
| Opponent | Wood Elf Realms | 2 | 0 | 310 | 4.0 | 1.0 | 78 | 13 | +64 | 3 of 8 | 6 of 8 | - | +64 |
| **Opponent** | all armies | 11 | 75 | 387 | 3.5 | 1.0 | 112 | 12 | +100 | 12 of 38 | 29 of 38 | +120 | +100 |

### Effective charges: h8-mine-6ec093a-p4

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 6 | 2 (net +0) | 0 | 0 | 1 (net +0) | 0 | 2 (net +0) | 1 | 0% (0 of 5) |
| Mine | Chaos Dwarfs | 10 | 1 (net +0) | 0 | 0 | 4 (net +6) | 1 (net +534) | 3 (net +0) | 1 | 0% (0 of 9) |
| Mine | Dwarfen Mountain Holds | 3 | 1 (net -60) | 0 | 0 | 1 (net +0) | 0 | 1 (net +147) | 0 | 0% (0 of 3) |
| Opponent | High Elf Realms | 4 | 1 (net +355) | 0 | 1 (net +0) | 0 | 2 (net +32) | 0 | 0 | 25% (1 of 4) |
| Opponent | Kingdom of Bretonnia | 7 | 1 (net +85) | 0 | 1 (net +230) | 1 (net +110) | 1 (net +81) | 1 (net +170) | 2 | 20% (1 of 5) |
| Opponent | Tomb Kings of Khemri | 4 | 0 | 0 | 3 (net +101) | 1 (net +190) | 0 | 0 | 0 | 75% (3 of 4) |
| Opponent | Vampire Counts | 6 | 2 (net +164) | 0 | 1 (net +115) | 0 | 1 (net +120) | 2 (net +123) | 0 | 17% (1 of 6) |
| Opponent | Warriors of Chaos | 9 | 4 (net +129) | 0 | 2 (net -68) | 1 (net +52) | 0 | 2 (net +85) | 0 | 22% (2 of 9) |
| Opponent | Wood Elf Realms | 8 | 2 (net -52) | 0 | 0 | 2 (net +155) | 1 (net +310) | 2 (net +0) | 1 | 0% (0 of 7) |

### Charged fights, damage counted: h8-mine-6ec093a-p4

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 4 | 85 | 200 | -15 | 16 | 27 | -11 | -12.9 |
| Mine | 76-89% | 6 | 231 | 218 | +4 | 127 | 106 | +21 | +9.2 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 6 | 257 | 222 | +24 | 96 | 21 | +76 | +29.4 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 480 | 158 | +534 | 534 | 0 | +534 | +111.2 |
| Mine | No odds | 2 | 376 | 148 | +62 | 62 | 34 | +28 | +7.5 |
| Mine | All fights | 19 | 237 | 205 | +41 | 109 | 49 | +59 | +25.1 |
| Opponent | Long shot (under 50%) | 10 | 258 | 306 | +118 | 171 | 59 | +112 | +43.6 |
| Opponent | Effective (55-75%) | 8 | 335 | 172 | +64 | 82 | 50 | +32 | +9.4 |
| Opponent | 76-89% | 5 | 366 | 126 | +132 | 139 | 10 | +129 | +35.2 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 7 | 312 | 157 | +84 | 98 | 18 | +81 | +25.9 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 5 | 405 | 92 | +115 | 138 | 6 | +132 | +32.6 |
| Opponent | No odds | 3 | 319 | 101 | +101 | 101 | 0 | +101 | +31.6 |
| Opponent | All fights | 38 | 322 | 182 | +100 | 125 | 31 | +93 | +29.0 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| h8-mine-6ec093a-p4 | move | 67 | 16 (24%) | 13 (19%) | 10 (15%) | 41 (61%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0115, L0132 |
| Charmed Shield | Opponent | L0625 |
| Horn of the Wild Hunt | Opponent | L0333 |
| Invocation of Nehek | Opponent | L0625 |
| Periapt of Soul Exchange | Opponent | L0420 |
| Ring of Doom | Mine | L0216, L0232 |
| Ring of Doom | Opponent | L0115, L0333 |

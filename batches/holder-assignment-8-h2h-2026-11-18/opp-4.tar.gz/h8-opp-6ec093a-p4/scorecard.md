# Doctrine scorecard: h8-opp-6ec093a-p4

### Scorecard: h8-opp-6ec093a-p4

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0115 | 1 | 1 | Mine | no | 1 | - | 0 | 2 | 0 | 0 | 0 | 0 |
| L0115 | 1 | 1 | Opponent | yes | 6 | 2 | 5 | 2 | 0 | 0 | 0 | 0 |
| L0132 | 6 | 1 | Mine | no | 5 | - | 0 | 1 | 0 | 0 | 0 | 0 |
| L0132 | 6 | 1 | Opponent | no | 4 | 3 | 3 | 6 | 0 | 0 | 0 | 340 |
| L0216 | 6 | 1 | Mine | no | 4 | 4 | 2 | 1 | 1 | 0 | 0 | 0 |
| L0216 | 6 | 1 | Opponent | no | 1 | 2 | 3 | 0 | 0 | 0 | 0 | 100 |
| L0232 | 4 | 1 | Mine | no | 0 | 5 | 4 | 4 | 0 | 0 | 0 | 170 |
| L0232 | 4 | 1 | Opponent | no | 1 | 2 | 3 | 2 | 1 | 0 | 0 | 0 |
| L0316 | 4 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 0 |
| L0316 | 4 | 1 | Opponent | no | 0 | 2 | 1 | 3 | 1 | 0 | 0 | 0 |
| L0333 | 3 | 1 | Mine | no | 0 | - | 0 | 0 | 0 | 0 | 0 | 110 |
| L0333 | 3 | 1 | Opponent | no | 3 | 2 | 2 | 4 | 0 | 0 | 0 | 0 |
| L0420 | 6 | 1 | Mine | no | 4 | 3 | 6 | 1 | 0 | 0 | 0 | 0 |
| L0420 | 6 | 1 | Opponent | no | 16 | - | 0 | 1 | 2 | 0 | 0 | 485 |
| L0435 | 3 | 1 | Mine | no | 4 | 4 | 1 | 1 | 0 | 0 | 0 | 0 |
| L0435 | 3 | 1 | Opponent | no | 0 | 4 | 3 | 2 | 0 | 0 | 0 | 0 |
| L0609 | 3 | 1 | Mine | no | 3 | 6 | 1 | 3 | 0 | 0 | 0 | 230 |
| L0609 | 3 | 1 | Opponent | no | 2 | - | 0 | 2 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 0% | 2.3 | 4.4 | 1.6 | 1.6 | 0.1 | 0.0 | 0.0 | 56.7 |
| **Average** | | | Opponent | 11% | 3.7 | 2.4 | 2.2 | 2.4 | 0.4 | 0.0 | 0.0 | 102.8 |

### KPIs: h8-opp-6ec093a-p4

Rules off - Mine only: HOLDER ASSIGNMENT, QUARTER ODDS, WALK PROMISE, REAL GROUND, RISK ON THE WAY.

Morten 2026-11-10; 9 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 32% (12 of 37) | 0% (0 of 48) | 14% (12 of 85) |
| Winner chose to follow up after the loser gave ground |  | 70% (7 of 10); on the table 70% | 88% (7 of 8); on the table 88% | 78% (14 of 18); on the table 78% |
| Winner chose to pursue after the loser fell back in good order |  | 100% (1 of 1); on the table 100% | 100% (1 of 1); on the table 100% | 100% (2 of 2); on the table 100% |
| Winner chose to pursue after the loser fled |  | 67% (6 of 9); on the table 67% | 100% (4 of 4); on the table 100% | 77% (10 of 13); on the table 77% |
| Winner chose to follow up or pursue (all three) |  | 70% (14 of 20); on the table 70% | 92% (12 of 13); on the table 92% | 79% (26 of 33); on the table 79% |
| Magic missiles tried each own turn | 50%+ | 30% (39 of 132) | 36% (13 of 36) | 31% (52 of 168) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 34% (39 of 115) | 39% (13 of 33) | 35% (52 of 148) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 83% (5 of 6) | 70% (16 of 23) | 72% (21 of 29) |
| Points that never fought | lower | 57% (9949 of 17594) | 58% (10489 of 17996) | 57% (20438 of 35590) |
|   infantry points that never fought | lower | 57% (3082 of 5424) | 84% (3801 of 4521) | 69% (6883 of 9945) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 48% (31 of 64) | 63% (48 of 76) | 56% (79 of 140) |
| Bound items with a magic missile used (at least once a game) |  | 100% (6 of 6); 1.9 uses a game | 80% (4 of 5); 1.1 uses a game | 91% (10 of 11); 1.5 uses a game |
| Bound items with another spell used |  | 100% (2 of 2); 0.6 uses a game | 0.0 uses a game | 100% (2 of 2); 0.3 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 62% (5 of 8); 0.6 uses a game | 75% (3 of 4); 0.3 uses a game | 67% (8 of 12); 0.4 uses a game |
|   their share of the points of units over 100 pts | lower | 42% (5773 of 13758) | 63% (10185 of 16284) | 53% (15958 of 30042) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 6.0 (58%) | 1.6 (61%) | 7.6 (59%) |
| MARCHED: its unit marched | 2.1 (20%) | 0.7 (26%) | 2.8 (22%) |
| CHARGED: its unit charged | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| IN COMBAT: engaged in combat | 1.6 (15%) | 0.2 (9%) | 1.8 (14%) |
| GONE: slain | 0.3 (3%) | 0.1 (4%) | 0.4 (3%) |
| STUPIDITY: Stupidity | 0.2 (2%) | 0.0 (0%) | 0.2 (2%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 5.9 | 1.0 | 3.7 | 5.8 | 0.2 |
| not cast | 5.4 | 0.3 | 3.0 | 12.9 | 15.8 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.4 (9%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.0 (0%) | 0.8 (26%) | 7.6 (59%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.8 (22%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.2 (4%) | 0.0 (0%) | 0.8 (26%) | 1.8 (14%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (2%) |
| GONE: slain | 0.0 (0%) | 0.0 (0%) | 0.1 (4%) | 0.4 (3%) | 0.2 (1%) |
| STUPIDITY: Stupidity | 0.3 (6%) | 0.0 (0%) | 0.0 (0%) | 0.2 (2%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.4 (8%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 4.4 (82%) | 0.3 (100%) | 1.3 (44%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 13.8 (87%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 3.6 a game | 0.7 a game | 2.1 a game |
| stood (cast and not dispelled) | 72% (23 of 32) | 50% (1 of 2) | 71% (24 of 34) |
| the unit moved after it | 83% (19 of 23) | 100% (1 of 1) | 83% (20 of 24) |
| it charged on its next turn | 0% (0 of 23) | 0% (0 of 1) | 0% (0 of 24) |
| the enemy charged it first | 13% (3 of 23) | 0% (0 of 1) | 12% (3 of 24) |
| it fought by the end of its next turn | 4% (1 of 23) | 0% (0 of 1) | 4% (1 of 24) |
| it moved out of a charge the enemy had planned (not charged first) | 13% (3 of 23) | 0% (0 of 1) | 12% (3 of 24) |
| none of these (no charge, no fight, no charge escaped) | 74% (17 of 23) | 100% (1 of 1) | 75% (18 of 24) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 59% (108 of 182) | 52% (115 of 223) | 55% (223 of 405) |
|   cavalry | 62% (10 of 16) | 71% (29 of 41) | 68% (39 of 57) |
|   character | 100% (2 of 2) | 32% (12 of 38) | 35% (14 of 40) |
|   chariot | 50% (24 of 48) | 67% (6 of 9) | 53% (30 of 57) |
|   infantry | 59% (23 of 39) | 46% (40 of 87) | 50% (63 of 126) |
|   monster | 33% (2 of 6) | 83% (5 of 6) | 58% (7 of 12) |
|   war machine | 66% (47 of 71) | 55% (23 of 42) | 62% (70 of 113) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.2 (27%) | 3.4 (29%) | 5.7 (28%) |
| CHARGED: it charged | 0.2 (3%) | 1.4 (12%) | 1.7 (8%) |
| IN COMBAT: it fought this turn or the last | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| MOVED: a war machine that moved | 1.8 (22%) | 1.0 (8%) | 2.8 (14%) |
| NO TARGET IN RANGE | 2.4 (30%) | 3.1 (26%) | 5.6 (27%) |
| ONLY IN COMBAT: the only targets were in combat | 0.0 (0%) | 0.4 (4%) | 0.4 (2%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.1 (14%) | 2.0 (17%) | 3.1 (15%) |
| SHELTERED: the target was sheltered | 0.1 (1%) | 0.4 (4%) | 0.6 (3%) |
| OTHER BAR | 0.2 (3%) | 0.1 (1%) | 0.3 (2%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 4.8 | 0.8 | 86% | 2.8 pts | 13 pts |
| character | 1.7 | 0.8 | 67% | 4.2 pts | 7 pts |
| chariot | 3.3 | 3.3 | 57% | 31.2 pts | 104 pts |
| infantry | 9.2 | 3.0 | 78% | 5.6 pts | 51 pts |
| monster | 1.2 | 0.3 | 73% | 4.2 pts | 5 pts |
| war machine | 7.8 | 8.8 | 54% | 32.7 pts | 254 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 2.2 | 3.1 | 2.7 |
| Charges that made contact a game | 1.9 | 2.6 | 2.2 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.60 declared, 0.40 contact (5 units) | 0.00 declared, 0.00 contact (2 units) | 0.43 declared, 0.29 contact (7 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | - | - |
|   per unit a game, the other units (no war machines, no joined characters) | 0.26 declared, 0.23 contact (65 units) | 0.37 declared, 0.30 contact (76 units) | 0.32 declared, 0.27 contact (141 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 43% (6 of 14) | - | 100% (1 of 1) | 47% (7 of 15) |
| Character in a unit | 85% (11 of 13) | 43% (3 of 7) | - | 70% (14 of 20) |
| Character on its own | 100% (1 of 1) | 44% (4 of 9) | 54% (7 of 13) | 52% (12 of 23) |
| Chariot | 0% (0 of 1) | 44% (4 of 9) | - | 40% (4 of 10) |
| Infantry | 40% (10 of 25) | 41% (7 of 17) | - | 40% (17 of 42) |
| Monster | 100% (7 of 7) | 100% (2 of 2) | - | 100% (9 of 9) |
| Monstrous | 80% (4 of 5) | 0% (0 of 1) | - | 67% (4 of 6) |
| War Machines | 77% (10 of 13) | 100% (2 of 2) | - | 80% (12 of 15) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 67% (6 of 9); on the table 67% | 31% (32 of 102) | 48% | 45% (10 of 22) | 100% (6 of 6); 4.2 uses a game | 100% (2 of 2); 1.2 uses a game | 67% (4 of 6); 1.0 uses a game |
| Chaos Dwarfs | 4 | 80% (8 of 10); on the table 80% | 23% (7 of 30) | 60% | 44% (14 of 32) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
| Dwarfen Mountain Holds | 1 | 0% (0 of 1); on the table 0% | - | 77% | 70% (7 of 10) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 1 | - | 42% (5 of 12) | 93% | 58% (7 of 12) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| High Elf Realms | 1 | 100% (1 of 1); on the table 100% | 17% (1 of 6) | 69% | 43% (3 of 7) | 100% (2 of 2); 4.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 2 | 86% (6 of 7); on the table 86% | - | 66% | 58% (7 of 12) | 0.0 uses a game | 0.0 uses a game | 100% (2 of 2); 1.0 uses a game |
| Skaven | 1 | - | 17% (1 of 6) | 55% | 71% (5 of 7) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Warriors of Chaos | 2 | 100% (1 of 1); on the table 100% | - | 35% | 62% (10 of 16) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 2 | 100% (4 of 4); on the table 100% | 50% (6 of 12) | 52% | 73% (16 of 22) | 67% (2 of 3); 3.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (h8-opp-6ec093a-p4, 9 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 44% (8) | 46% (6) | 45% (14) |
| ...free all their last turn and able to turn (per game) | 0.67 | 0.56 | 1.22 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.11 | 0.00 | 0.11 |
| ...with the charger already in that arc before they moved (per game) | 0.67 | 0.22 | 0.89 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.11 | 0.00 | 0.11 |

### Quality by phase: h8-opp-6ec093a-p4

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 0.9 | 1.8 |
| Strategy | Charge objectives carried out (made contact) | 56% (10 of 18) | 70% (19 of 27) |
| Strategy | Shoot objectives carried out (shot that target) | 46% (45 of 97) | 43% (26 of 61) |
| Strategy | Support requests answered (helper made contact too) | 50% (1 of 2) | 0% (0 of 1) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 80% (4 of 5) | - |
| Strategy | Hexes on a unit its side charged or shot that turn | - | 57% (4 of 7) |
| Strategy | Joined characters whose unit fought | 43% (10 of 23) | 9% (1 of 11) |
| Strategy | Lone characters that fought | 57% (8 of 14) | 65% (11 of 17) |
| Movement | Charges halted short of contact | 0.1 | 0.0 |
| Movement | Idle units | 1.6 | 2.4 |
| Movement | Points that never moved of their own | 56.7 | 102.8 |
| Movement | Fights charged into per game | 1.8 | 2.6 |
| Movement | Charges with odds: long shots (under 50%) | 1 of 14, net +0 | 8 of 22, net +63 |
| Movement | Charges with odds: sweet spot (55-75%) | 3 of 14, net +104 | 3 of 22, net +57 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 14 | 5 of 22, net +74 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 9 of 14, net +130 | 4 of 22, net +60 |
| Shooting | Shots by shooting units (incl. breath weapons) | 6.8 | 11.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 41% (25 of 61) | 44% (45 of 102) |
| Shooting | Points destroyed by shooting units | 68.1 | 15.7 |
| Shooting | War machine shots | 5.2 | 2.6 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 43% (20 of 47) | 43% (10 of 23) |
| Shooting | Points destroyed by war machines | 56.1 | 60.0 |
| Magic | Magic missiles cast | 2.7 | 0.8 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 21% (5 of 24) | 43% (3 of 7) |
| Magic | Wounds caused by magic missiles | 7.0 | 1.8 |
| Magic | Wounds caused by other spells | 0.6 | - |
| Magic | Points destroyed by magic (all spells) | 39.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 2.4 / 0.0 / 0.2 / 0.0 | 2.1 / 0.8 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 132.2 | 110.2 |
| Combat | Points run down | 29.1 | 79.6 |
| Combat | Net points per charged fight, damage counted | +127 | +61 |
| Combat | Net per 100 charger points, damage counted | +50.7 | +20.5 |
| Combat | First round won (charged fights) | 81% | 52% |
| Combat | Net points per charged fight | +114 | +56 |
| Combat | Net points per supported fight / lone fight | +0 / +121 | - / +56 |
| Combat | Charged fights on a top-3 enemy unit | 6 of 16 | 7 of 23 |
| Game | Points lost | 287.2 | 485.0 |
| Game | VP from objectives | 718.9 | 602.2 |
| Game | Lone holders (player turns) | 2.3 | 3.7 |

- Mine won / drew / lost: 4 / 4 / 1 of 9 ended games (of 9); mean margin (Mine - Opponent) +399 VP
- The side that went first won 3 of 5 games with a winner
- Points traded per game (both sides' losses): 772
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: h8-opp-6ec093a-p4

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.6 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.3 | +100.3 | 0.0 | 0.0 | 0.1 | +0.7 | 0.0 | 0.0 |
| ALREADY CARRIED | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARTILLERY RE-ROLL WEIGHED | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| BACKUP TARGETS | 0.1 | +1.8 | 0.0 | 0.0 | 0.1 | +0.7 | 0.0 | 0.0 |
| BEST PRIZE | 0.1 | -4.2 | 18.9 | 0.0 | - | - | - | - |
| BLOWS WHERE AIMED | - | - | - | - | 0.2 | -153.5 | 40.8 | 0.0 |
| CANNON PLAN MISSED | 0.7 | +0.0 | 12.0 | 0.0 | 0.4 | +0.0 | 63.9 | 0.0 |
| CANNON PLANNED TARGET | 4.3 | +138.2 | 68.1 | 37.2 | 2.3 | +87.4 | 96.1 | 0.0 |
| CANNON SIGHT KEPT | 1.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| CAST JOB | 0.4 | +4.7 | 0.0 | 0.0 | 0.1 | +1.0 | 0.0 | 0.0 |
| CASTER AWAY FROM SCREEN | 0.8 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.9 | +54.9 | 30.6 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | 2.2 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | 0.6 | +17.0 | 0.0 | 0.0 | 0.2 | +9.5 | 0.0 | 0.0 |
| CHAFF PASSED | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CHARACTER GUNS | 0.1 | +0.0 | 0.0 | 0.0 | 0.8 | +0.0 | 0.0 | 0.0 |
| CHARGE LOSSES | 5.8 | -238.1 | 0.0 | 33.9 | 7.0 | -278.7 | 0.0 | 77.9 |
| CHARGE NOT DECLARED | 0.7 | +0.0 | 88.9 | 0.0 | - | - | - | - |
| CHARGE NOW FIRST | 0.7 | +0.0 | 130.0 | 0.0 | 1.8 | +0.0 | 83.4 | 79.3 |
| CHARGER SLAIN LOST | 0.1 | -1.2 | 0.0 | 0.0 | 0.1 | -5.2 | 0.0 | 0.0 |
| CHEAP HELPER | 0.1 | +0.0 | 0.0 | 9.4 | - | - | - | - |
| CHEAPEST HOLDER | 0.7 | -34.4 | 12.8 | 40.8 | - | - | - | - |
| COMBAT PIVOT | 0.8 | +0.0 | 17.6 | 18.9 | 0.3 | +0.0 | 9.3 | 78.9 |
| CONTINUE AHEAD WEIGHED | - | - | - | - | 0.1 | +0.0 | 5.8 | 0.0 |
| CONVEYANCE SEARCH | 2.6 | +253.6 | 0.0 | 0.0 | 0.2 | +4.2 | 12.0 | 0.0 |
| COVER ONCE | 7.7 | -772.8 | 0.0 | 7.2 | 4.3 | -230.5 | 0.0 | 4.2 |
| DEPLOY BY FIGURES | 8.9 | +47.6 | 0.0 | 13.3 | 8.1 | +31.3 | 0.0 | 3.3 |
| EDGE GIVE GROUND | 0.1 | +0.2 | 0.0 | 0.0 | 0.3 | +1.8 | 9.4 | 0.0 |
| ENGINEER BY LORE | 0.4 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FALL BACK GOOD ORDER | 1.3 | +7.4 | 141.3 | 0.0 | 2.2 | +0.0 | 115.3 | 79.3 |
| FALLBACK BY WORTH | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| FALLS SHORT | 3.9 | +70.6 | 0.0 | 15.1 | 21.8 | +296.1 | 0.0 | 275.0 |
| FEATURE BUFFS | 3.8 | +112.6 | 0.0 | 0.0 | 1.0 | +50.6 | 0.0 | 12.8 |
| FIGHT LIFT | - | - | - | - | 0.1 | +0.3 | 0.0 | 0.0 |
| FIGHT TO THE END | 0.6 | +29.1 | 98.6 | 0.0 | 1.2 | +76.4 | 37.8 | 66.6 |
| FIRE IN ORDER | 0.2 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| FIVE ACTION | 48.1 | +2810.4 | 453.4 | 260.8 | 51.0 | +3582.1 | 401.2 | 488.4 |
| FLANK NOT WEIGHED | 7.8 | +0.0 | 0.0 | 15.1 | 4.7 | +0.0 | 0.0 | 105.6 |
| FOLLOW UP WEIGHED | 0.6 | +135.6 | 0.0 | 0.0 | 0.3 | +137.5 | 0.0 | 66.6 |
| FOUR ROUNDS | 1.9 | +219.0 | 164.0 | 0.0 | 2.8 | +293.7 | 156.1 | 79.3 |
| FRIEND SHOOTS FIRST | 0.3 | -10.4 | 0.0 | 0.0 | 0.3 | -10.7 | 0.0 | 0.0 |
| FRIENDS SHOTS CHECKED | 0.1 | +2.9 | 0.0 | 0.0 | 0.3 | +14.8 | 0.0 | 12.8 |
| GIVES UP | 0.1 | -1.3 | 11.3 | 0.0 | 0.2 | -1.2 | 18.9 | 0.0 |
| GUN FIGURES | 1.9 | +35.6 | 22.7 | 0.0 | 1.2 | +18.6 | 13.3 | 0.0 |
| GUN MASK | 0.4 | +4.1 | 0.0 | 0.0 | 0.6 | +19.1 | 0.0 | 0.0 |
| HARD STAY DROPPED | 2.3 | +0.0 | 0.0 | 0.0 | 1.1 | +0.0 | 0.0 | 0.0 |
| HE SHOOTS OR CHARGES | 2.0 | +0.0 | 0.0 | 26.1 | 3.4 | +0.0 | 0.0 | 51.7 |
| HIS CHARGE DENIED | 0.1 | +1.9 | 0.0 | 0.0 | 0.2 | +18.8 | 0.0 | 0.0 |
| HIS CHARGE LIST | 2.7 | +0.0 | 0.0 | 16.6 | 3.3 | +0.0 | 0.0 | 50.6 |
| HIS LEGAL MOVES | 2.7 | +0.0 | 0.0 | 16.0 | 2.8 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 2.3 | -33.1 | 0.0 | 12.4 | 1.2 | -44.9 | 0.0 | 0.0 |
| HIS ONE QUARTER | - | - | - | - | 2.2 | +0.0 | 0.0 | 29.3 |
| HIS RANDOM MOVE | 2.8 | +0.0 | 0.0 | 18.9 | 0.9 | +0.0 | 0.0 | 8.9 |
| HIS SHOT LIST | 20.7 | +744.2 | 0.0 | 134.4 | 23.9 | +1156.3 | 0.0 | 285.0 |
| HIS TURN DENIED | 0.2 | +4.8 | 17.6 | 0.0 | 1.3 | +66.9 | 67.7 | 79.3 |
| HOLD ODDS | - | - | - | - | 12.3 | +0.0 | 0.0 | 65.2 |
| HOLDER ASSIGNMENT | - | - | - | - | 14.3 | +1266.4 | 0.0 | 78.0 |
| HOLDER AT DEPLOYMENT | 1.6 | +255.7 | 0.0 | 0.0 | - | - | - | - |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 1.8 | -66.8 | 187.3 | 0.0 | 2.7 | -189.4 | 137.2 | 79.3 |
| HUNT IN PAIRS | 0.2 | +5.2 | 0.0 | 0.0 | - | - | - | - |
| IDLE COST | 1.4 | -11.7 | 0.0 | 9.4 | 13.0 | -183.4 | 0.0 | 144.9 |
| JOINT KNOWS CHALLENGE | 0.1 | -1.1 | 0.0 | 0.0 | - | - | - | - |
| KEEP FALLS | 0.2 | +9.3 | 0.0 | 0.0 | - | - | - | - |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KILLS COUNT | - | - | - | - | 0.1 | +4.3 | 0.0 | 0.0 |
| LANE BY FIGURES | 0.4 | +12.3 | 0.0 | 0.0 | 0.9 | +30.9 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 4.3 | +0.0 | 144.4 | 38.3 | 5.0 | +0.0 | 74.7 | 339.9 |
| LONE WIZARD KEPT IN | 1.1 | +72.2 | 0.0 | 0.0 | 0.6 | +37.9 | 0.0 | 0.0 |
| LONG SHOT | 0.3 | +8.1 | 0.0 | 0.0 | 0.3 | +0.8 | 7.2 | 7.2 |
| LURE BY WHAT IT DRAWS | - | - | - | - | 0.1 | +0.0 | 0.0 | 0.0 |
| MANOEUVRE | 1.6 | +61.7 | 0.0 | 0.0 | 1.6 | +4.6 | 0.0 | 26.0 |
| MARCH AT ESCAPER | 0.3 | +16.0 | 0.0 | 0.0 | 0.2 | +0.2 | 0.0 | 0.0 |
| MARCH BY THE SUM | 0.6 | +15.2 | 0.0 | 0.0 | 0.3 | +16.1 | 0.0 | 0.0 |
| MARCH CHECK | 1.2 | +75.1 | 0.0 | 0.0 | 1.2 | +43.3 | 0.0 | 38.0 |
| MARCH OVER CASTS | 0.4 | -7.7 | 0.0 | 0.0 | 0.7 | -10.0 | 0.0 | 26.0 |
| MAX FOR POSITIONING | 7.4 | +102.7 | 0.0 | 18.2 | 4.2 | +58.5 | 0.0 | 50.1 |
| MISSILES IN THE MOVE | 4.3 | +320.3 | 0.0 | 0.0 | 2.7 | +26.9 | 0.0 | 41.6 |
| MISSILES NEXT TURN | 5.7 | +225.7 | 0.0 | 0.0 | 4.2 | +25.4 | 0.0 | 67.6 |
| MODEL FACING | 0.3 | +56.7 | 0.0 | 13.3 | - | - | - | - |
| MOVE SPELL IN RANGE | 0.8 | +40.3 | 0.0 | 0.0 | 0.1 | +0.5 | 0.0 | 26.0 |
| MOVE SPELL OUT OF RANGE | 1.2 | -55.2 | 0.0 | 0.0 | 0.6 | -34.9 | 0.0 | 26.0 |
| MOVE SPELL SPOT | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 2.9 | +390.5 | 0.0 | 13.3 | 3.8 | +502.3 | 0.0 | 0.0 |
| MOVES UNITS SPELL | 0.2 | +12.2 | 0.0 | 0.0 | 0.1 | +0.8 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 4.8 | +213.0 | 0.0 | 7.2 | 6.8 | +302.5 | 0.0 | 163.6 |
| NEEDED THERE | 0.1 | +52.1 | 23.3 | 0.0 | 0.1 | +51.0 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 4.8 | -184.8 | 0.0 | 20.0 | 5.7 | -291.2 | 9.0 | 56.1 |
| NEXT OBJECTIVE NEARER | 6.4 | -199.8 | 12.8 | 16.6 | 0.1 | -0.0 | 0.0 | 15.2 |
| NO DOUBLE ROUNDS | 1.4 | -47.5 | 141.3 | 0.0 | 2.6 | -55.9 | 137.2 | 79.3 |
| NOT TURNED | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NOT WORTH A CAST | 0.4 | -0.2 | 0.0 | 0.0 | 0.8 | -0.7 | 0.0 | 0.0 |
| OFF BEST | 0.3 | -1.2 | 0.0 | 0.0 | 0.1 | -12.2 | 0.0 | 0.0 |
| ONE CHARGE A CHARGER | 3.8 | +0.0 | 0.0 | 15.1 | 3.2 | +0.0 | 0.0 | 86.3 |
| ONE FIGHT FORMULA | 4.9 | -76.6 | 0.0 | 20.0 | 5.4 | -132.9 | 0.0 | 71.3 |
| ONE OBJECTIVE FORMULA | 4.8 | -16.2 | 0.0 | 7.2 | 4.8 | -53.6 | 0.0 | 50.0 |
| ONE TARGET A SHOOTER | 16.1 | +333.0 | 0.0 | 80.9 | 21.2 | +574.2 | 0.0 | 289.7 |
| OPENS A LANE | - | - | - | - | 0.2 | +3.4 | 37.8 | 0.0 |
| OPENS UP | 0.2 | +10.7 | 22.7 | 0.0 | 0.2 | +19.2 | 16.6 | 0.0 |
| PATHS CROSS | 3.9 | +153.1 | 0.0 | 9.3 | 4.8 | +229.2 | 0.0 | 17.6 |
| PERIAPT WORTH | - | - | - | - | 0.1 | +7.0 | 0.0 | 60.0 |
| PIVOT GUARDS FLANK | - | - | - | - | 0.3 | -4.7 | 0.0 | 0.0 |
| PLAN RESULT | 41.3 | +490.3 | 219.1 | 364.0 | 44.4 | +279.7 | 144.8 | 723.6 |
| QUARTER ODDS | - | - | - | - | 9.6 | +1240.1 | 106.4 | 52.0 |
| RANDOM MOVE BY FIGURES | 0.7 | +19.6 | 0.0 | 37.8 | 2.6 | +49.0 | 0.0 | 42.2 |
| REAL GROUND | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| REDIRECT BY WHAT IT STOPS | 0.4 | -8.1 | 0.0 | 0.0 | 0.1 | -5.2 | 0.0 | 0.0 |
| REDIRECT COUNTER | 2.2 | +101.7 | 0.0 | 31.2 | 3.7 | +100.0 | 0.0 | 53.4 |
| REFORMS TO MEET IT | 0.6 | -13.5 | 0.0 | 6.7 | 0.6 | -65.0 | 0.0 | 0.0 |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| RESERVE FALL BACK | 0.3 | +11.6 | 0.0 | 12.4 | 0.9 | +64.5 | 0.0 | 17.6 |
| RISK BY ARC | 1.1 | +27.0 | 141.3 | 0.0 | 2.0 | +42.2 | 74.6 | 79.3 |
| RISK BY HIS FIGURE | 13.8 | -195.1 | 0.0 | 89.4 | 13.6 | -188.6 | 0.0 | 183.9 |
| RISK ON THE WAY | - | - | - | - | 0.6 | +0.0 | 0.0 | 0.0 |
| RUN DOWN | 1.3 | -20.4 | 69.3 | 0.0 | 1.9 | -11.9 | 77.6 | 79.3 |
| SAME CHARGE LATER | 0.2 | -4.6 | 0.0 | 0.0 | - | - | - | - |
| SCOUT SPOT | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| SCOUT WAITS | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 0.1 | -7.6 | 0.0 | 0.0 |
| SEARCH SPOT | 5.1 | +210.0 | 0.0 | 26.9 | 6.8 | +251.7 | 0.0 | 114.3 |
| SELF MOVE SPELL | - | - | - | - | 0.7 | +31.7 | 0.0 | 0.0 |
| SET UP TOGETHER | - | - | - | - | 0.6 | +2.9 | 0.0 | 0.0 |
| SET-UP ANY TARGET | 0.3 | +51.3 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | 0.2 | +0.4 | 0.0 | 0.0 | 0.4 | +0.6 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 2.0 | +156.6 | 129.2 | 40.8 | 1.7 | +38.1 | 73.2 | 0.0 |
| SHORT GUN FORWARD | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SHOT OR CHARGE | - | - | - | - | 0.3 | -15.1 | 50.2 | 0.0 |
| SHOT RISK POINTS | 10.6 | +114.1 | 0.0 | 65.6 | 17.6 | +146.8 | 0.0 | 156.7 |
| SHOTS IN THE MOVE | 13.3 | +592.1 | 0.0 | 111.0 | 15.1 | +408.0 | 0.0 | 141.8 |
| SPELL OFF EDGE | 0.1 | +30.2 | 48.0 | 0.0 | - | - | - | - |
| SPELL SETS UP CHARGE | 0.8 | +169.0 | 0.0 | 0.0 | - | - | - | - |
| SPELL WORTH | 1.8 | +21.2 | 37.2 | 37.2 | 2.9 | +78.3 | 120.0 | 120.0 |
| SPELLS IN THE FIGHT | 0.2 | +1.6 | 22.7 | 0.0 | 0.1 | -2.7 | 0.0 | 0.0 |
| STAND AND SHOOT | 0.2 | -0.9 | 17.6 | 0.0 | 0.4 | -3.6 | 34.1 | 12.8 |
| STANDS FOR A REASON | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 21.1 | +0.0 | 289.4 | 169.7 | 15.6 | +0.0 | 245.1 | 66.8 |
| STAY WORTH | 14.6 | +33.9 | 112.6 | 124.4 | 17.3 | +183.0 | 147.2 | 134.6 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 18.9 |
| SUPPORT NARROWED | 0.6 | +0.0 | 70.0 | 0.0 | 0.7 | +0.0 | 39.1 | 12.8 |
| SURE REACH TOGETHER | 0.1 | +0.1 | 0.0 | 0.0 | 1.4 | +3.0 | 0.0 | 38.0 |
| THE DEARER SUM KEEPS ITS PLAN | 4.1 | +0.0 | 0.0 | 9.3 | 4.8 | +0.0 | 0.0 | 17.6 |
| THE PROMISE ADDS | 0.3 | -14.0 | 0.0 | 0.0 | - | - | - | - |
| THE PROMISED MOVE | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| TIED UP BY THE SUM | 0.2 | +14.9 | 29.1 | 0.0 | 0.8 | +66.3 | 57.9 | 12.8 |
| TIME ON OUR SIDE | 32.0 | +517.7 | 0.0 | 41.7 | 4.4 | +70.4 | 0.0 | 17.8 |
| WAITS AGAIN | 1.6 | +0.0 | 0.0 | 6.7 | 0.4 | +0.0 | 0.0 | 0.0 |
| WAR ENGINE CHARGES | 0.1 | +15.7 | 23.3 | 0.0 | - | - | - | - |
| WAR ENGINE JOBS | 0.4 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WHO HITS BACK | 0.3 | +49.7 | 0.0 | 0.0 | 0.1 | +8.7 | 0.0 | 0.0 |
| WHOLE FIGHT | 0.1 | -4.0 | 23.3 | 0.0 | 0.1 | +9.5 | 18.9 | 0.0 |
| WHOLE FIGHT GAIN | 0.2 | +20.2 | 0.0 | 0.0 | 0.1 | +34.3 | 0.0 | 0.0 |
| WIDER SPREAD | 1.4 | -5.9 | 169.8 | 0.0 | 1.9 | -2.5 | 122.9 | 12.8 |
| WOUNDS ON THE RANKS | 2.2 | +52.9 | 0.0 | 0.0 | 2.0 | +112.0 | 0.0 | 0.0 |

### Rule changes: h8-opp-6ec093a-p4

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS SHOT LIST | 401 | 401 | 132 | 14.67 | +3244 | +24.6 |
| HOLDER ASSIGNMENT | 129 | 129 | 119 | 13.22 | +5231 | +44.0 |
| SEARCH SPOT | 107 | 107 | 104 | 11.56 | +4173 | +40.1 |
| DEPLOY BY FIGURES | 153 | 153 | 93 | 10.33 | +1270 | +13.7 |
| ONE TARGET A SHOOTER | 336 | 336 | 89 | 9.89 | +1134 | +12.7 |
| LEGAL CHARGES ONLY | 84 | 84 | 84 | 9.33 | +0 | +0.0 |
| PATHS CROSS | 78 | 78 | 78 | 8.67 | +3441 | +44.1 |
| TIME ON OUR SIDE | 328 | 286 | 53 | 5.89 | +112 | +2.1 |
| SHOT RISK POINTS | 253 | 253 | 46 | 5.11 | +1817 | +39.5 |
| FIVE ACTION | 892 | 892 | 45 | 5.00 | +2092 | +46.5 |
| MOVE TO CHARGE COMPUTED | 60 | 60 | 34 | 3.78 | +3056 | +89.9 |
| MAX FOR POSITIONING | 105 | 102 | 33 | 3.67 | +104 | +3.1 |
| HARD STAY DROPPED | 31 | 31 | 31 | 3.44 | +0 | +0.0 |
| COVER ONCE | 108 | 85 | 28 | 3.11 | +529 | +18.9 |
| FOUR ROUNDS | 42 | 42 | 24 | 2.67 | +1726 | +71.9 |
| FALLS SHORT | 231 | 204 | 22 | 2.44 | +74 | +3.4 |
| RANDOM MOVE BY FIGURES | 29 | 29 | 21 | 2.33 | +617 | +29.4 |
| SHOOTS FROM THE BEST SPOT | 33 | 33 | 21 | 2.33 | +312 | +14.8 |
| SHOTS IN THE MOVE | 256 | 227 | 19 | 2.11 | +860 | +45.3 |
| QUARTER ODDS | 86 | 86 | 18 | 2.00 | +2285 | +126.9 |
| MANOEUVRE | 28 | 28 | 17 | 1.89 | +622 | +36.6 |
| REDIRECT COUNTER | 53 | 41 | 16 | 1.78 | +528 | +33.0 |
| CANNON SIGHT KEPT | 15 | 15 | 15 | 1.67 | +0 | +0.0 |
| LONE WIZARD KEPT IN | 15 | 15 | 15 | 1.67 | +991 | +66.1 |
| MARCH CHECK | 22 | 22 | 14 | 1.56 | +171 | +12.2 |
| IDLE COST | 130 | 111 | 13 | 1.44 | +127 | +9.7 |
| ARTILLERY RE-ROLL WEIGHED | 12 | 12 | 12 | 1.33 | +0 | +0.0 |
| LANE BY FIGURES | 12 | 12 | 12 | 1.33 | +389 | +32.4 |
| RISK BY HIS FIGURE | 246 | 246 | 12 | 1.33 | +587 | +48.9 |
| RESERVE FALL BACK | 11 | 11 | 11 | 1.22 | +685 | +62.3 |
| ADVANCE LANE KEPT | 10 | 10 | 10 | 1.11 | +0 | +0.0 |
| COMBAT PIVOT | 10 | 10 | 10 | 1.11 | +0 | +0.0 |
| MISSILES IN THE MOVE | 63 | 48 | 10 | 1.11 | +174 | +17.4 |
| CASTER AWAY FROM SCREEN | 9 | 9 | 9 | 1.00 | +0 | +0.0 |
| NEXT OBJECTIVE NEARER | 59 | 59 | 9 | 1.00 | +65 | +7.2 |
| RISK BY ARC | 28 | 28 | 9 | 1.00 | +58 | +6.5 |
| CHARGE LOSSES | 115 | 115 | 8 | 0.89 | +469 | +58.6 |
| FOLLOW UP WEIGHED | 8 | 8 | 8 | 0.89 | +2458 | +307.2 |
| HOLDER AT DEPLOYMENT | 14 | 14 | 8 | 0.89 | +507 | +63.4 |
| HOLDS AMBUSHERS | 8 | 8 | 8 | 0.89 | +0 | +0.0 |
| MARCH BY THE SUM | 8 | 8 | 8 | 0.89 | +281 | +35.2 |
| CANNON PLANNED TARGET | 60 | 60 | 7 | 0.78 | -2 | -0.3 |
| FEATURE BUFFS | 43 | 43 | 7 | 0.78 | +322 | +45.9 |
| WOUNDS ON THE RANKS | 38 | 38 | 7 | 0.78 | +243 | +34.7 |
| CHARGE NOT DECLARED | 6 | 6 | 6 | 0.67 | -1551 | -258.4 |
| NEXT CHARGE BY LIST | 94 | 94 | 6 | 0.67 | +83 | +13.9 |
| SHOOTERS IN TWO RANKS | 6 | 6 | 6 | 0.67 | +9 | +1.5 |
| TIED UP BY THE SUM | 9 | 9 | 6 | 0.67 | +121 | +20.2 |
| CASTING BLOCK | 8 | 8 | 5 | 0.56 | +106 | +21.2 |
| CHAFF IN THE MOVE | 7 | 6 | 5 | 0.56 | +33 | +6.6 |
| CHARGE NOW FIRST | 22 | 22 | 5 | 0.56 | -95 | -19.0 |
| SURE REACH TOGETHER | 14 | 14 | 5 | 0.56 | +0 | +0.0 |
| AFTERMATH IN POINTS | 4 | 4 | 4 | 0.44 | +909 | +227.3 |
| CHAFF PASSED | 4 | 4 | 4 | 0.44 | +0 | +0.0 |
| FRIENDS SHOTS CHECKED | 4 | 4 | 4 | 0.44 | +159 | +39.8 |
| OFF BEST | 4 | 4 | 4 | 0.44 | -121 | -30.2 |
| STUCK PIVOT | 4 | 4 | 4 | 0.44 | +0 | +0.0 |
| WHO HITS BACK | 4 | 4 | 4 | 0.44 | +423 | +105.7 |
| FIRE IN ORDER | 3 | 3 | 3 | 0.33 | +0 | +0.0 |
| GUN MASK | 9 | 9 | 3 | 0.33 | +37 | +12.2 |
| MISSILES NEXT TURN | 89 | 64 | 3 | 0.33 | +46 | +15.4 |
| MODEL FACING | 3 | 3 | 3 | 0.33 | +510 | +170.0 |
| MOVES UNITS SPELL | 3 | 3 | 3 | 0.33 | +118 | +39.2 |
| NEARER NOT NEEDED | 104 | 95 | 3 | 0.33 | +70 | +23.4 |
| ONE FIGHT FORMULA | 93 | 47 | 3 | 0.33 | +1 | +0.3 |
| ONE OBJECTIVE FORMULA | 86 | 69 | 3 | 0.33 | +108 | +35.9 |
| OPENS UP | 4 | 4 | 3 | 0.33 | +37 | +12.5 |
| PIVOT GUARDS FLANK | 3 | 3 | 3 | 0.33 | -43 | -14.2 |
| SCOUT WAITS | 3 | 3 | 3 | 0.33 | +0 | +0.0 |
| SHORT GUN FORWARD | 3 | 3 | 3 | 0.33 | +0 | +0.0 |
| STAY WORTH | 287 | 260 | 3 | 0.33 | +53 | +17.6 |
| WHOLE FIGHT GAIN | 3 | 3 | 3 | 0.33 | +53 | +17.7 |
| CAST JOB | 5 | 5 | 2 | 0.22 | +7 | +3.3 |
| FIGHT TO THE END | 16 | 16 | 2 | 0.22 | +39 | +19.4 |
| HIS TURN DENIED | 14 | 14 | 2 | 0.22 | +37 | +18.4 |
| KEEP FALLS | 2 | 2 | 2 | 0.22 | +111 | +55.5 |
| NEEDED THERE | 2 | 2 | 2 | 0.22 | +0 | +0.0 |
| OPENS A LANE | 2 | 2 | 2 | 0.22 | +0 | +0.0 |
| WIDER SPREAD | 30 | 30 | 2 | 0.22 | +10 | +5.2 |
| BEST PRIZE | 1 | 1 | 1 | 0.11 | -38 | -38.2 |
| CONTINUE AHEAD WEIGHED | 1 | 1 | 1 | 0.11 | +0 | +0.0 |
| EDGE GIVE GROUND | 4 | 4 | 1 | 0.11 | +0 | +0.0 |
| KEEPS SCOUTS OR AMBUSH | 1 | 1 | 1 | 0.11 | +0 | +0.0 |
| KILLS COUNT | 1 | 1 | 1 | 0.11 | +0 | +0.0 |
| LONG SHOT | 6 | 6 | 1 | 0.11 | +1 | +0.9 |
| NO DOUBLE ROUNDS | 36 | 36 | 1 | 0.11 | +5 | +5.3 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.11 | +63 | +63.4 |
| SET UP TOGETHER | 5 | 4 | 1 | 0.11 | +8 | +8.3 |
| SUPPORT NARROWED | 11 | 11 | 1 | 0.11 | -0 | -0.2 |
| WAR ENGINE CHARGES | 1 | 1 | 1 | 0.11 | +20 | +20.5 |
| WHOLE FIGHT | 2 | 2 | 1 | 0.11 | +50 | +49.5 |
| ALREADY CARRIED | 6 | not checked | - | - | - | - |
| BACKUP TARGETS | 2 | 2 | 0 | 0.00 | - | - |
| BLOWS WHERE AIMED | 2 | 2 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 10 | 10 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 23 | trace | - | - | - | - |
| CHARACTER GUNS | 8 | 8 | 0 | 0.00 | - | - |
| CHARGER SLAIN LOST | 2 | 2 | 0 | 0.00 | - | - |
| CHEAP HELPER | 1 | not checked | - | - | - | - |
| CHEAPEST HOLDER | 6 | 6 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 25 | not checked | - | - | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 32 | 32 | 0 | 0.00 | - | - |
| FALLBACK BY WORTH | 2 | 2 | 0 | 0.00 | - | - |
| FIGHT LIFT | 1 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 112 | not checked | - | - | - | - |
| FRIEND SHOOTS FIRST | 6 | 6 | 0 | 0.00 | - | - |
| GIVES UP | 3 | 3 | 0 | 0.00 | - | - |
| GUN FIGURES | 28 | not checked | - | - | - | - |
| HE SHOOTS OR CHARGES | 49 | 49 | 0 | 0.00 | - | - |
| HIS CHARGE DENIED | 3 | 3 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 54 | 54 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 49 | 49 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 32 | 32 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 20 | 20 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 33 | 33 | 0 | 0.00 | - | - |
| HOLD ODDS | 111 | 111 | 0 | 0.00 | - | - |
| HONEST WORTH | 40 | 40 | 0 | 0.00 | - | - |
| HUNT IN PAIRS | 2 | 1 | 0 | 0.00 | - | - |
| JOINT KNOWS CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 1 | 1 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 5 | trace | - | - | - | - |
| MARCH OVER CASTS | 10 | 10 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 8 | 4 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 16 | trace | - | - | - | - |
| MOVE SPELL SPOT | 15 | not checked | - | - | - | - |
| NOT TURNED | 1 | 1 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 11 | not checked | - | - | - | - |
| ONE CHARGE A CHARGER | 63 | 63 | 0 | 0.00 | - | - |
| PLAN RESULT | 772 | trace | - | - | - | - |
| REAL GROUND | 3 | 3 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 5 | 5 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 10 | 10 | 0 | 0.00 | - | - |
| REFUSING RETIRES | 3 | 3 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 5 | 5 | 0 | 0.00 | - | - |
| RUN DOWN | 29 | 29 | 0 | 0.00 | - | - |
| SAME CHARGE LATER | 2 | 2 | 0 | 0.00 | - | - |
| SCOUT SPOT | 3 | 3 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 1 | 1 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 6 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 3 | not checked | - | - | - | - |
| SHOT OR CHARGE | 3 | 3 | 0 | 0.00 | - | - |
| SPELL OFF EDGE | 1 | not checked | - | - | - | - |
| SPELL SETS UP CHARGE | 7 | not checked | - | - | - | - |
| SPELL WORTH | 42 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 3 | 3 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 6 | 6 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 6 | 6 | 0 | 0.00 | - | - |
| STANDS STILL | 330 | 330 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 80 | not checked | - | - | - | - |
| THE PROMISE ADDS | 3 | 3 | 0 | 0.00 | - | - |
| THE PROMISED MOVE | 9 | not checked | - | - | - | - |
| WAITS AGAIN | 18 | 18 | 0 | 0.00 | - | - |
| WAR ENGINE JOBS | 4 | 4 | 0 | 0.00 | - | - |

### Off best figure: h8-opp-6ec093a-p4

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| PATHS CROSS | rule | 0.56 | 0.89 | 19.5 |
| HOLDER ASSIGNMENT | rule | - | 1.33 | 22.3 |
| CHARGE NOT DECLARED | rule | 0.67 | - | 258.4 |
| CHARGE NOW FIRST | rule | 0.11 | 0.44 | 19.0 |
| PIVOT GUARDS FLANK | rule | - | 0.33 | 14.2 |
| CANNON PLANNED TARGET | rule | 0.22 | - | 3.7 |
| AFTERMATH BAND | gate | 0.11 | - | 2.8 |
| BEST PRIZE | rule | 0.11 | - | 38.2 |
| FIGHT ORDER BAND | gate | 0.11 | - | 0.9 |
| JOB FIRST | gate | 0.11 | - | 7.0 |
| NO REASON | gate | - | 0.11 | 110.2 |

### Plans: h8-opp-6ec093a-p4

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.2 | 82% | 289 | 221 | 77% |
| Mine | move | 31.4 | 97% | 1856 | 0 | 0% |
| Mine | shoot | 8.3 | 43% | 471 | 269 | 57% |
| Mine | support | 0.3 | 100% | 0 | 0 | - |
| Opponent | charge | 2.2 | 60% | 677 | 110 | 16% |
| Opponent | move | 36.9 | 94% | 2026 | 0 | 0% |
| Opponent | shoot | 5.0 | 49% | 317 | 170 | 53% |
| Opponent | support | 0.3 | 100% | 5 | 0 | 0% |

### Battle groups: h8-opp-6ec093a-p4

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 2.2 | 15% | 67% | 67% | 0% | 0% | 0% | 0% | 100% | 0% |
| Opponent | REDIRECT COUNTER | 3.7 | 21% | 57% | 0% | - | 0% | 0% | 0% | 71% | 29% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: h8-opp-6ec093a-p4

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 6 | 0 (6) | 0 | 0 | 0 | 100% | - | 0 (2) | 0 (3) | 0 (1) | 0 (5) | 0 (1) |
| Mine | Character | 32 | 41 (32) | 41 | 0 | 12 | 22% | 2.5 | 32 (8) | 52 (10) | 47 (10) | 39 (16) | 49 (12) |
| Mine | Clean-up | 3 | 155 (3) | 0 | 155 | 22 | 0% | 1.3 | 199 (2) | 0 (1) | - | 199 (2) | 0 (1) |
| Mine | Fast Hammer | 10 | 21 (10) | 21 | 0 | 34 | 40% | 4.5 | 0 (1) | 0 (3) | 31 (6) | 24 (9) | 0 (1) |
| Mine | Hammer | 22 | 29 (22) | 17 | 12 | 14 | 23% | 2.6 | 35 (6) | 25 (11) | 31 (5) | 40 (9) | 20 (13) |
| Mine | Holder | 12 | 79 (12) | 0 | 79 | 7 | 67% | 5.5 | 61 (2) | 102 (7) | 40 (3) | 98 (6) | 61 (6) |
| Mine | Shooter | 11 | 87 (11) | 0 | 87 | 31 | 9% | 1.6 | 84 (5) | 92 (6) | - | 81 (8) | 105 (3) |
| Mine | War machine | 14 | 28 (14) | 28 | 0 | 27 | 7% | 1.8 | 33 (12) | 0 (2) | - | 0 (4) | 38 (10) |
| Mine | Wizard | 5 | 0 (5) | 0 | 0 | 0 | 40% | 3.7 | 0 (4) | 0 (1) | - | 0 (3) | 0 (2) |
| Opponent | Chaff | 17 | 66 (17) | 16 | 49 | 43 | 29% | 3.2 | 74 (9) | 64 (6) | 0 (2) | 80 (15) | 0 (2) |
| Opponent | Character | 22 | 24 (22) | 24 | 0 | 30 | 18% | 2.2 | 18 (4) | 43 (10) | 7 (8) | 12 (10) | 34 (12) |
| Opponent | Clean-up | 8 | 42 (8) | 8 | 34 | 8 | 62% | 3.3 | 69 (3) | 12 (3) | 77 (2) | 85 (4) | 11 (4) |
| Opponent | Fast Hammer | 9 | 27 (9) | 4 | 23 | 52 | 56% | 3.2 | 13 (3) | 57 (4) | 0 (2) | 34 (6) | 8 (3) |
| Opponent | Hammer | 16 | 8 (16) | 6 | 1 | 31 | 50% | 3.1 | 17 (2) | 7 (11) | 4 (3) | 11 (7) | 5 (9) |
| Opponent | Holder | 8 | 76 (8) | 0 | 76 | 0 | 25% | 4.0 | 85 (3) | 89 (4) | 0 (1) | 72 (6) | 86 (2) |
| Opponent | Shooter | 9 | 73 (9) | 0 | 73 | 16 | 0% | 2.3 | 108 (4) | 14 (1) | 49 (4) | 97 (6) | 41 (3) |
| Opponent | Support | 2 | 0 (2) | 0 | 0 | 0 | 100% | - | 0 (1) | - | - | - | 0 (1) |
| Opponent | War machine | 7 | 62 (7) | 62 | 0 | 0 | 14% | 1.5 | 83 (5) | - | 0 (2) | - | 62 (7) |
| Opponent | Wizard | 6 | 0 (6) | 0 | 0 | 0 | 17% | 1.8 | - | 0 (4) | 0 (2) | - | 0 (6) |

### Charged fights: h8-opp-6ec093a-p4

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 88 | 84 | 1.8 | 1.1 | 48 | 0 | +48 | 2 of 7 | 5 of 7 | +0 | +56 |
| Mine | Chaos Dwarfs | 4 | 280 | 371 | 2.0 | 1.0 | 186 | 0 | +186 | 4 of 8 | 7 of 8 | - | +186 |
| Mine | Dwarfen Mountain Holds | 1 | 0 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 0 of 1 | 1 of 1 | - | +0 |
| **Mine** | all armies | 9 | 163 | 202 | 1.8 | 1.1 | 114 | 0 | +114 | 6 of 16 | 13 of 16 | +0 | +121 |
| Opponent | Empire of Man | 1 | 460 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | High Elf Realms | 1 | 0 | 1051 | 4.0 | 1.0 | 263 | 0 | +263 | 3 of 4 | 2 of 4 | - | +263 |
| Opponent | Kingdom of Bretonnia | 2 | 110 | 238 | 3.5 | 1.0 | 68 | 0 | +68 | 1 of 7 | 5 of 7 | - | +68 |
| Opponent | Skaven | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Warriors of Chaos | 2 | 0 | 208 | 3.0 | 1.0 | 69 | 128 | -59 | 2 of 6 | 3 of 6 | - | -59 |
| Opponent | Wood Elf Realms | 2 | 0 | 56 | 3.0 | 1.0 | 19 | 0 | +19 | 1 of 6 | 2 of 6 | - | +19 |
| **Opponent** | all armies | 9 | 76 | 228 | 2.6 | 1.0 | 89 | 33 | +56 | 7 of 23 | 12 of 23 | - | +56 |

### Effective charges: h8-opp-6ec093a-p4

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 7 | 1 (net +0) | 0 | 1 (net +0) | 0 | 0 | 4 (net +34) | 1 | 17% (1 of 6) |
| Mine | Chaos Dwarfs | 8 | 0 | 0 | 2 (net +156) | 1 (net +102) | 0 | 4 (net +258) | 1 | 29% (2 of 7) |
| Mine | Dwarfen Mountain Holds | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +0) | 0 | 0% (0 of 1) |
| Opponent | High Elf Realms | 4 | 2 (net +493) | 0 | 1 (net +0) | 0 | 0 | 1 (net +65) | 0 | 25% (1 of 4) |
| Opponent | Kingdom of Bretonnia | 7 | 2 (net +85) | 0 | 0 | 1 (net +0) | 4 (net +76) | 0 | 0 | 0% (0 of 7) |
| Opponent | Warriors of Chaos | 6 | 2 (net -327) | 0 | 1 (net +170) | 0 | 1 (net +65) | 2 (net +32) | 0 | 17% (1 of 6) |
| Opponent | Wood Elf Realms | 6 | 2 (net +0) | 0 | 1 (net +0) | 1 (net +0) | 0 | 1 (net +112) | 1 | 20% (1 of 5) |

### Charged fights, damage counted: h8-opp-6ec093a-p4

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 1 | 166 | 371 | +0 | 0 | 69 | -69 | -41.8 |
| Mine | Effective (55-75%) | 3 | 290 | 175 | +104 | 140 | 0 | +140 | +48.1 |
| Mine | 76-89% | 1 | 339 | 102 | +102 | 102 | 0 | +102 | +30.1 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 9 | 208 | 168 | +130 | 168 | 19 | +149 | +71.4 |
| Mine | No odds | 2 | 376 | 104 | +119 | 119 | 0 | +119 | +31.6 |
| Mine | All fights | 16 | 250 | 170 | +114 | 142 | 15 | +127 | +50.7 |
| Opponent | Long shot (under 50%) | 8 | 335 | 235 | +63 | 183 | 134 | +48 | +14.5 |
| Opponent | Effective (55-75%) | 3 | 377 | 205 | +57 | 89 | 18 | +71 | +18.8 |
| Opponent | 76-89% | 2 | 387 | 240 | +0 | 89 | 0 | +89 | +22.9 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 4 | 111 | 80 | +60 | 60 | 0 | +60 | +54.6 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 5 | 357 | 74 | +74 | 74 | 0 | +74 | +20.8 |
| Opponent | No odds | 1 | 0 | 91 | +0 | 4 | 0 | +4 | - |
| Opponent | All fights | 23 | 296 | 163 | +56 | 110 | 49 | +61 | +20.5 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| h8-opp-6ec093a-p4 | move | 74 | 12 (16%) | 11 (15%) | 8 (11%) | 54 (73%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0115, L0132 |
| Horn of the Wild Hunt | Opponent | L0333 |
| Periapt of Soul Exchange | Opponent | L0420 |
| Ring of Doom | Mine | L0216, L0232 |
| Ring of Doom | Opponent | L0115, L0333 |

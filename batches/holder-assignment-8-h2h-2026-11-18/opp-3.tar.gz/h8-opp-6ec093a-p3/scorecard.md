# Doctrine scorecard: h8-opp-6ec093a-p3

### Scorecard: h8-opp-6ec093a-p3

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0111 | 3 | 1 | Mine | yes | 4 | 3 | 3 | 1 | 0 | 0 | 0 | 225 |
| L0111 | 3 | 1 | Opponent | yes | 10 | 2 | 2 | 0 | 0 | 0 | 0 | 0 |
| L0128 | 2 | 1 | Mine | - | - | - | 0 | 5 | 0 | 0 | 0 | 0 |
| L0128 | 2 | 1 | Opponent | - | - | - | 0 | 4 | 0 | 0 | 0 | 0 |
| L0211 | 1 | 1 | Mine | no | 0 | - | 0 | 5 | 0 | 0 | 0 | 170 |
| L0211 | 1 | 1 | Opponent | yes | 13 | 2 | 1 | 0 | 0 | 0 | 0 | 0 |
| L0228 | 6 | 1 | Mine | yes | 9 | 2 | 2 | 2 | 0 | 0 | 0 | 170 |
| L0228 | 6 | 1 | Opponent | no | 8 | 3 | 1 | 0 | 0 | 0 | 0 | 0 |
| L0313 | 1 | 1 | Mine | no | 2 | - | 0 | 0 | 0 | 0 | 0 | 140 |
| L0313 | 1 | 1 | Opponent | no | 10 | 2 | 2 | 0 | 1 | 0 | 0 | 70 |
| L0330 | 6 | 1 | Mine | no | 0 | - | 0 | 0 | 0 | 0 | 0 | 195 |
| L0330 | 6 | 1 | Opponent | no | 5 | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| L0415 | 1 | 1 | Mine | no | 0 | 2 | 5 | 2 | 0 | 0 | 0 | 0 |
| L0415 | 1 | 1 | Opponent | no | 11 | 2 | 0 | 2 | 1 | 0 | 0 | 0 |
| L0432 | 6 | 1 | Mine | no | 0 | 3 | 3 | 2 | 0 | 0 | 0 | 310 |
| L0432 | 6 | 1 | Opponent | no | 0 | 2 | 1 | 2 | 2 | 0 | 0 | 340 |
| L0518 | 2 | 1 | Mine | - | - | 4 | 1 | 1 | 0 | 0 | 0 | 233 |
| L0518 | 2 | 1 | Opponent | - | - | - | 1 | 4 | 0 | 0 | 0 | 0 |
| L0534 | 6 | 1 | Mine | no | 0 | 2 | 0 | 2 | 0 | 0 | 0 | 1163 |
| L0534 | 6 | 1 | Opponent | no | 8 | 2 | 2 | 5 | 0 | 0 | 0 | 160 |
| L0621 | 3 | 1 | Mine | no | 3 | - | 0 | 1 | 1 | 0 | 0 | 461 |
| L0621 | 3 | 1 | Opponent | no | 7 | - | 2 | 3 | 0 | 0 | 0 | 145 |
| **Average** | | | Mine | 22% | 2.0 | 2.7 | 1.3 | 1.9 | 0.1 | 0.0 | 0.0 | 278.8 |
| **Average** | | | Opponent | 22% | 8.0 | 2.1 | 1.3 | 1.9 | 0.4 | 0.0 | 0.0 | 65.0 |

### KPIs: h8-opp-6ec093a-p3

Rules off - Mine only: HOLDER ASSIGNMENT, QUARTER ODDS, WALK PROMISE, REAL GROUND, RISK ON THE WAY.

Morten 2026-11-10; 11 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 44% (24 of 54) | 8% (4 of 50) | 27% (28 of 104) |
| Winner chose to follow up after the loser gave ground |  | 88% (7 of 8); on the table 88% | 92% (11 of 12); on the table 92% | 90% (18 of 20); on the table 90% |
| Winner chose to pursue after the loser fell back in good order |  | 100% (1 of 1); on the table 100% | 75% (3 of 4); on the table 75% | 80% (4 of 5); on the table 80% |
| Winner chose to pursue after the loser fled |  | 86% (6 of 7); on the table 86% | 100% (4 of 4); on the table 100% | 91% (10 of 11); on the table 91% |
| Winner chose to follow up or pursue (all three) |  | 88% (14 of 16); on the table 88% | 90% (18 of 20); on the table 90% | 89% (32 of 36); on the table 89% |
| Magic missiles tried each own turn | 50%+ | 37% (51 of 138) | 33% (22 of 66) | 36% (73 of 204) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 43% (51 of 119) | 44% (22 of 50) | 43% (73 of 169) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 30% (3 of 10) | 64% (9 of 14) | 50% (12 of 24) |
| Points that never fought | lower | 54% (11644 of 21564) | 55% (12175 of 21994) | 55% (23819 of 43558) |
|   infantry points that never fought | lower | 59% (3814 of 6480) | 83% (2690 of 3231) | 67% (6504 of 9711) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 56% (44 of 78) | 48% (40 of 83) | 52% (84 of 161) |
| Bound items with a magic missile used (at least once a game) |  | 83% (5 of 6); 1.4 uses a game | 100% (9 of 9); 2.6 uses a game | 93% (14 of 15); 2.0 uses a game |
| Bound items with another spell used |  | 100% (2 of 2); 0.5 uses a game | 0% (0 of 2); 0.0 uses a game | 50% (2 of 4); 0.3 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 88% (7 of 8); 0.6 uses a game | 40% (2 of 5); 0.2 uses a game | 69% (9 of 13); 0.4 uses a game |
|   their share of the points of units over 100 pts | lower | 51% (8238 of 16262) | 44% (8850 of 19889) | 47% (17088 of 36151) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 4.0 (51%) | 0.5 (11%) | 4.5 (37%) |
| MARCHED: its unit marched | 1.2 (15%) | 1.5 (36%) | 2.6 (22%) |
| CHARGED: its unit charged | 0.3 (3%) | 0.0 (0%) | 0.3 (2%) |
| IN COMBAT: engaged in combat | 1.0 (13%) | 1.1 (27%) | 2.1 (18%) |
| REAR RANK: in a rear rank | 0.5 (6%) | 0.2 (5%) | 0.6 (5%) |
| FLEEING: fleeing | 0.2 (2%) | 0.0 (0%) | 0.2 (2%) |
| GONE: slain | 0.5 (7%) | 0.4 (9%) | 0.9 (8%) |
| STUPIDITY: Stupidity | 0.3 (3%) | 0.1 (2%) | 0.4 (3%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.4 (9%) | 0.4 (3%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 3.7 | 1.7 | 1.3 | 6.6 | 0.4 | 1.4 |
| not cast | 2.8 | 5.2 | 2.5 | 11.9 | 1.3 | 20.5 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.4 (7%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 2.1 (40%) | 0.0 (0%) | 4.5 (37%) | 0.5 (36%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.6 (22%) | 0.3 (21%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (2%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.2 (6%) | 0.5 (11%) | 0.1 (4%) | 2.1 (18%) | 0.5 (36%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 1.1 (21%) | 0.5 (18%) | 0.6 (5%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.1 (3%) | 0.0 (0%) | 0.0 (0%) | 0.2 (2%) | 0.0 (0%) | 0.3 (1%) |
| GONE: slain | 0.4 (13%) | 0.0 (0%) | 0.6 (25%) | 0.9 (8%) | 0.0 (0%) | 1.7 (8%) |
| OFF THE TABLE: off the table or not arrived | 0.3 (10%) | 0.5 (9%) | 0.3 (11%) | 0.0 (0%) | 0.0 (0%) | 0.7 (4%) |
| STUPIDITY: Stupidity | 0.1 (3%) | 0.1 (2%) | 0.1 (4%) | 0.4 (3%) | 0.0 (0%) | 0.4 (2%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (7%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.4 (3%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.8 (65%) | 0.9 (18%) | 1.0 (39%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 16.0 (78%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.5 a game | 0.3 a game | 0.9 a game |
| stood (cast and not dispelled) | 41% (7 of 17) | 100% (1 of 1) | 44% (8 of 18) |
| the unit moved after it | 43% (3 of 7) | 100% (1 of 1) | 50% (4 of 8) |
| it charged on its next turn | 0% (0 of 7) | 0% (0 of 1) | 0% (0 of 8) |
| the enemy charged it first | 14% (1 of 7) | 0% (0 of 1) | 12% (1 of 8) |
| it fought by the end of its next turn | 14% (1 of 7) | 0% (0 of 1) | 12% (1 of 8) |
| it moved out of a charge the enemy had planned (not charged first) | 14% (1 of 7) | 0% (0 of 1) | 12% (1 of 8) |
| none of these (no charge, no fight, no charge escaped) | 71% (5 of 7) | 100% (1 of 1) | 75% (6 of 8) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 71% (209 of 294) | 49% (98 of 201) | 62% (307 of 495) |
|   cavalry | 62% (10 of 16) | 53% (10 of 19) | 57% (20 of 35) |
|   character | 82% (51 of 62) | 28% (11 of 40) | 61% (62 of 102) |
|   chariot | 56% (23 of 41) | 50% (13 of 26) | 54% (36 of 67) |
|   infantry | 61% (35 of 57) | 64% (44 of 69) | 63% (79 of 126) |
|   monster | 75% (3 of 4) | 33% (4 of 12) | 44% (7 of 16) |
|   war machine | 76% (87 of 114) | 46% (16 of 35) | 69% (103 of 149) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.7 (35%) | 2.5 (26%) | 5.2 (30%) |
| CHARGED: it charged | 0.3 (4%) | 1.5 (17%) | 1.8 (11%) |
| FLEEING: it fled or was fleeing | 0.1 (1%) | 0.1 (1%) | 0.2 (1%) |
| IN COMBAT: it fought this turn or the last | 0.7 (9%) | 0.0 (0%) | 0.7 (4%) |
| MOVED: a war machine that moved | 1.4 (18%) | 1.7 (18%) | 3.1 (18%) |
| NO TARGET IN RANGE | 1.5 (20%) | 1.5 (17%) | 3.1 (18%) |
| ONLY IN COMBAT: the only targets were in combat | 0.0 (0%) | 0.1 (1%) | 0.1 (1%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.5 (6%) | 1.5 (17%) | 2.0 (12%) |
| SHELTERED: the target was sheltered | 0.3 (4%) | 0.4 (4%) | 0.6 (4%) |
| OTHER BAR | 0.3 (4%) | 0.0 (0%) | 0.3 (2%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 2.4 | 0.3 | 88% | 3.7 pts | 9 pts |
| character | 6.0 | 4.2 | 59% | 11.6 pts | 70 pts |
| chariot | 3.3 | 3.5 | 44% | 34.4 pts | 112 pts |
| infantry | 12.3 | 5.2 | 72% | 6.6 pts | 81 pts |
| monster | 0.6 | 0.3 | 71% | 1.4 pts | 1 pts |
| war machine | 9.4 | 8.9 | 56% | 24.2 pts | 227 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 2.4 | 3.2 | 2.8 |
| Charges that made contact a game | 1.5 | 2.5 | 2.0 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.00 declared, 0.50 contact (6 units) | 0.67 declared, 0.67 contact (6 units) | 0.83 declared, 0.58 contact (12 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 1.00 declared, 1.00 contact (2 units) | 1.00 declared, 1.00 contact (2 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.27 declared, 0.19 contact (75 units) | 0.36 declared, 0.28 contact (80 units) | 0.32 declared, 0.23 contact (155 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 31% (4 of 13) | - | 43% (3 of 7) | 35% (7 of 20) |
| Character in a unit | 94% (16 of 17) | 80% (12 of 15) | 50% (1 of 2) | 85% (29 of 34) |
| Character on its own | 83% (5 of 6) | 44% (4 of 9) | 23% (3 of 13) | 43% (12 of 28) |
| Chariot | 71% (5 of 7) | 50% (4 of 8) | - | 60% (9 of 15) |
| Infantry | 30% (6 of 20) | 20% (3 of 15) | - | 26% (9 of 35) |
| Monster | 40% (2 of 5) | 67% (2 of 3) | - | 50% (4 of 8) |
| Monstrous | 100% (3 of 3) | 50% (1 of 2) | - | 80% (4 of 5) |
| War Machines | 57% (8 of 14) | 100% (2 of 2) | - | 62% (10 of 16) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 83% (5 of 6); on the table 83% | 34% (35 of 102) | 49% | 68% (15 of 22) | 83% (5 of 6); 3.8 uses a game | 100% (2 of 2); 1.5 uses a game | 83% (5 of 6); 1.2 uses a game |
| Chaos Dwarfs | 4 | 86% (6 of 7); on the table 86% | 44% (16 of 36) | 46% | 47% (15 of 32) | 0.0 uses a game | 0.0 uses a game | 100% (2 of 2); 0.5 uses a game |
| Dwarfen Mountain Holds | 3 | 100% (3 of 3); on the table 100% | - | 70% | 58% (14 of 24) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Grand Cathay | 2 | 88% (7 of 8); on the table 88% | 36% (13 of 36) | 33% | 31% (5 of 16) | 100% (4 of 4); 6.5 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |
| High Elf Realms | 2 | 100% (3 of 3); on the table 100% | 0% (0 of 6) | 64% | 40% (6 of 15) | 100% (3 of 3); 5.0 uses a game | 0% (0 of 2); 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 1 | 100% (2 of 2); on the table 100% | 0% (0 of 6) | 96% | 71% (5 of 7) | 100% (1 of 1); 4.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Skaven | 1 | - | 50% (3 of 6) | 90% | 67% (6 of 9) | 100% (1 of 1); 2.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Warriors of Chaos | 4 | 86% (6 of 7); on the table 86% | 50% (6 of 12) | 45% | 50% (14 of 28) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 0.2 uses a game |
| Wood Elf Realms | 1 | - | - | 49% | 50% (4 of 8) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (h8-opp-6ec093a-p3, 11 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 38% (6) | 38% (5) | 38% (11) |
| ...free all their last turn and able to turn (per game) | 0.36 | 0.45 | 0.82 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.18 | 0.00 | 0.18 |
| ...with the charger already in that arc before they moved (per game) | 0.27 | 0.36 | 0.64 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.18 | 0.00 | 0.18 |

### Quality by phase: h8-opp-6ec093a-p3

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.5 | 2.3 |
| Strategy | Charge objectives carried out (made contact) | 62% (16 of 26) | 59% (20 of 34) |
| Strategy | Shoot objectives carried out (shot that target) | 39% (65 of 167) | 45% (30 of 67) |
| Strategy | Support requests answered (helper made contact too) | 50% (1 of 2) | 100% (3 of 3) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (2 of 2) | - |
| Strategy | Hexes on a unit its side charged or shot that turn | - | 50% (3 of 6) |
| Strategy | Joined characters whose unit fought | 34% (10 of 29) | 38% (6 of 16) |
| Strategy | Lone characters that fought | 41% (9 of 22) | 71% (12 of 17) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 1.9 | 1.9 |
| Movement | Points that never moved of their own | 278.8 | 65.0 |
| Movement | Fights charged into per game | 1.4 | 2.2 |
| Movement | Charges with odds: long shots (under 50%) | 4 of 15, net -72 | 5 of 22, net -0 |
| Movement | Charges with odds: sweet spot (55-75%) | 3 of 15, net +116 | 2 of 22, net +148 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 15 | 4 of 22, net +331 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 5 of 15, net +87 | 4 of 22, net +280 |
| Shooting | Shots by shooting units (incl. breath weapons) | 11.5 | 8.6 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 43% (54 of 126) | 27% (26 of 95) |
| Shooting | Points destroyed by shooting units | 109.3 | 44.1 |
| Shooting | War machine shots | 7.9 | 1.5 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 56% (49 of 87) | 50% (8 of 16) |
| Shooting | Points destroyed by war machines | 79.5 | 23.4 |
| Magic | Magic missiles cast | 1.5 | 1.5 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 50% (8 of 16) | 25% (4 of 16) |
| Magic | Wounds caused by magic missiles | 3.1 | 4.4 |
| Magic | Wounds caused by other spells | 0.6 | 1.6 |
| Magic | Points destroyed by magic (all spells) | 21.8 | 28.5 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.9 / 0.0 / 0.4 / 0.2 | 0.5 / 1.1 / 0.5 / 0.0 |
| Combat | Points destroyed in combat | 43.3 | 394.5 |
| Combat | Points run down | 73.1 | 21.3 |
| Combat | Net points per charged fight, damage counted | +74 | +186 |
| Combat | Net per 100 charger points, damage counted | +26.7 | +44.9 |
| Combat | First round won (charged fights) | 80% | 83% |
| Combat | Net points per charged fight | +56 | +187 |
| Combat | Net points per supported fight / lone fight | -274 / +79 | +543 / +136 |
| Combat | Charged fights on a top-3 enemy unit | 7 of 15 | 11 of 24 |
| Game | Points lost | 599.2 | 425.5 |
| Game | VP from objectives | 558.2 | 906.4 |
| Game | Lone holders (player turns) | 2.0 | 8.0 |

- Mine won / drew / lost: 4 / 0 / 7 of 11 ended games (of 11); mean margin (Mine - Opponent) -519 VP
- The side that went first won 4 of 11 games with a winner
- Points traded per game (both sides' losses): 1025
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: h8-opp-6ec093a-p3

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.6 | +0.0 | 0.0 | 0.0 | 0.5 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.1 | +12.2 | 0.0 | 0.0 | 0.2 | +47.1 | 0.0 | 0.0 |
| ALREADY CARRIED | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARRIVAL HUNT | - | - | - | - | 0.1 | +3.4 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 2.5 | +0.0 | 0.0 | 39.5 | 0.4 | +0.0 | 0.0 | 15.0 |
| BACKUP TARGETS | 0.1 | +0.4 | 0.0 | 5.9 | 0.2 | +1.1 | 0.0 | 0.0 |
| BEST PRIZE | - | - | - | - | 0.2 | -4.2 | 15.9 | 0.0 |
| BLOWS WHERE AIMED | - | - | - | - | 0.1 | -49.3 | 21.7 | 0.0 |
| BOMBING RUN | - | - | - | - | 0.2 | +5.2 | 0.0 | 13.6 |
| CANNON PLAN MISSED | 1.5 | +0.0 | 189.0 | 46.8 | 0.1 | +0.0 | 20.9 | 0.0 |
| CANNON PLANNED TARGET | 7.2 | +101.4 | 356.2 | 98.2 | 1.4 | +31.2 | 46.1 | 30.0 |
| CANNON SIGHT KEPT | 1.0 | +0.0 | 0.0 | 0.0 | 0.5 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT COUNTER | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CAST JOB | 0.9 | +21.9 | 94.4 | 0.0 | 0.4 | +16.7 | 41.2 | 0.0 |
| CASTER AWAY FROM SCREEN | 0.5 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.7 | +60.7 | 21.1 | 0.0 | 0.2 | +3.4 | 5.9 | 0.0 |
| CASTS AFTER FRIENDS | 0.5 | +0.0 | 0.0 | 64.5 | 0.1 | +0.0 | 0.0 | 36.4 |
| CHAFF IN THE MOVE | 0.2 | +8.3 | 0.0 | 7.7 | 0.5 | +31.9 | 0.0 | 14.0 |
| CHAFF PASSED | 0.2 | -1.2 | 0.0 | 28.2 | 0.2 | -0.2 | 0.0 | 0.0 |
| CHARACTER GUNS | 0.5 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 0.0 |
| CHARGE LOSSES | 5.3 | -178.9 | 0.0 | 33.1 | 6.1 | -352.2 | 0.0 | 250.0 |
| CHARGE NOT DECLARED | 0.7 | +0.0 | 32.8 | 17.2 | 0.4 | +0.0 | 49.1 | 0.0 |
| CHARGE NOW FIRST | 1.5 | +0.0 | 188.8 | 0.0 | 1.5 | +0.0 | 236.6 | 15.7 |
| CHARGER SLAIN LOST | 0.5 | -44.4 | 17.7 | 17.2 | 0.1 | -0.3 | 10.0 | 0.0 |
| CHEAP HELPER | 0.2 | +0.0 | 0.0 | 4.7 | - | - | - | - |
| CHEAPEST HOLDER | 0.3 | -12.8 | 5.9 | 0.0 | - | - | - | - |
| COMBAT PIVOT | 0.3 | +0.0 | 0.0 | 56.4 | 0.2 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | 1.3 | +321.7 | 0.0 | 32.3 | 0.1 | +36.3 | 36.4 | 36.4 |
| COVER ONCE | 6.0 | -546.4 | 0.0 | 197.5 | 3.2 | -141.1 | 0.0 | 122.4 |
| DEFENSIVE FLOOR | 0.1 | +1.5 | 12.6 | 0.0 | - | - | - | - |
| DEPLOY BY FIGURES | 8.5 | +55.3 | 0.0 | 5.9 | 7.3 | +20.7 | 0.0 | 13.2 |
| EDGE GIVE GROUND | 0.1 | +2.7 | 35.9 | 0.0 | 0.1 | +0.2 | 10.0 | 0.0 |
| ENGINEER BY LORE | 0.4 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FALL BACK GOOD ORDER | 1.7 | +19.0 | 116.5 | 15.1 | 2.2 | +7.4 | 295.2 | 19.5 |
| FALLBACK BY WORTH | 0.1 | +3.3 | 0.0 | 2.7 | 0.2 | +0.0 | 0.0 | 0.0 |
| FALLS SHORT | 3.9 | +73.1 | 0.0 | 45.3 | 19.9 | +327.2 | 0.0 | 392.2 |
| FEATURE BUFFS | 2.1 | +60.1 | 0.0 | 7.5 | 0.5 | +15.3 | 0.0 | 12.6 |
| FIGHT LIFT | 0.1 | +0.2 | 0.0 | 0.0 | - | - | - | - |
| FIGHT TO THE END | 0.8 | +5.0 | 64.1 | 0.0 | 1.2 | +208.4 | 156.8 | 19.5 |
| FIRE IN ORDER | 0.4 | +0.0 | 10.7 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| FIVE ACTION | 46.8 | +2448.4 | 1104.6 | 528.5 | 42.2 | +3816.0 | 616.5 | 668.5 |
| FLANK NOT WEIGHED | 4.4 | +0.0 | 0.0 | 81.2 | 5.3 | +0.0 | 0.0 | 242.9 |
| FOLLOW UP WEIGHED | 0.6 | +104.8 | 0.0 | 33.8 | 0.9 | +258.4 | 0.0 | 0.0 |
| FOUR ROUNDS | 2.4 | +205.7 | 178.7 | 24.5 | 2.9 | +597.1 | 371.2 | 19.5 |
| FRIEND SHOOTS FIRST | 0.6 | -24.6 | 0.0 | 28.2 | 0.4 | -10.4 | 0.0 | 36.4 |
| FRIENDS SHOTS CHECKED | 0.1 | +1.3 | 0.0 | 9.5 | - | - | - | - |
| GIVES UP | 0.1 | -6.5 | 5.5 | 0.0 | 0.4 | -5.5 | 8.6 | 0.0 |
| GIVES UP ITS SCREEN | 0.1 | -0.1 | 0.0 | 0.0 | - | - | - | - |
| GROUND FLIERS | 0.1 | +3.8 | 0.0 | 0.0 | - | - | - | - |
| GUN FIGURES | 1.4 | +32.8 | 75.0 | 56.4 | 0.5 | +5.6 | 11.4 | 28.6 |
| GUN MASK | 0.2 | +0.8 | 0.0 | 0.0 | 0.9 | +19.7 | 0.0 | 44.1 |
| HARD STAY DROPPED | 1.7 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 0.0 |
| HE SHOOTS OR CHARGES | 3.2 | +0.0 | 0.0 | 28.9 | 2.0 | +0.0 | 0.0 | 101.3 |
| HELPER ALREADY ASKED | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HELPER UNSEEN | 0.1 | +0.0 | 0.0 | 7.4 | - | - | - | - |
| HIS CHARGE DENIED | 0.5 | +9.8 | 24.1 | 15.1 | 0.2 | +11.2 | 35.9 | 0.0 |
| HIS CHARGE LIST | 3.1 | +0.0 | 0.0 | 66.5 | 1.7 | +0.0 | 0.0 | 10.0 |
| HIS LEGAL MOVES | 2.6 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 58.7 |
| HIS MOVE AND SHOT | 1.8 | -23.8 | 0.0 | 17.6 | 1.5 | -49.8 | 0.0 | 46.1 |
| HIS ONE QUARTER | - | - | - | - | 1.3 | +0.0 | 0.0 | 24.6 |
| HIS RANDOM MOVE | 1.9 | +0.0 | 0.0 | 5.5 | 1.5 | +0.0 | 0.0 | 17.4 |
| HIS SHOT LIST | 16.5 | +437.0 | 0.0 | 197.7 | 24.3 | +1122.0 | 0.0 | 483.8 |
| HIS TURN DENIED | 0.7 | +29.4 | 110.5 | 0.0 | 1.9 | +66.4 | 241.4 | 3.7 |
| HOLD ODDS | - | - | - | - | 13.5 | +0.0 | 0.0 | 92.5 |
| HOLDER ASSIGNMENT | - | - | - | - | 17.0 | +1745.6 | 0.0 | 79.9 |
| HOLDER AT DEPLOYMENT | 1.3 | +154.2 | 0.0 | 0.0 | - | - | - | - |
| HOLDS AMBUSHERS | 0.5 | +0.0 | 0.0 | 0.0 | 0.5 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 1.8 | -67.7 | 165.1 | 0.0 | 2.5 | -150.8 | 326.7 | 15.7 |
| HUNT IN PAIRS | 0.2 | +6.8 | 0.0 | 0.0 | 0.4 | +5.0 | 0.0 | 0.0 |
| HUNT KEPT | 0.1 | +4.4 | 15.0 | 0.0 | - | - | - | - |
| HUNT RESULT | 0.1 | +15.0 | 0.0 | 0.0 | - | - | - | - |
| HUNT THE GUNS | 0.1 | +30.5 | 15.0 | 0.0 | - | - | - | - |
| IDLE COST | 1.1 | -9.8 | 0.0 | 10.6 | 11.2 | -185.5 | 0.0 | 271.3 |
| KEEP FALLS | 0.2 | +1.9 | 0.0 | 0.0 | - | - | - | - |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| LANE BY FIGURES | 0.4 | +25.2 | 0.0 | 0.0 | 0.6 | +20.4 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 4.0 | +0.0 | 70.5 | 184.8 | 2.7 | +0.0 | 203.0 | 27.9 |
| LONE CHARACTER SAFE SPOT | 0.1 | +1.0 | 26.3 | 0.0 | - | - | - | - |
| LONE WIZARD KEPT IN | 0.9 | +77.0 | 0.0 | 0.0 | 0.3 | +35.3 | 0.0 | 0.0 |
| LONG SHOT | 0.4 | -6.0 | 0.0 | 7.4 | 0.2 | +0.8 | 0.0 | 15.7 |
| LOST CHARGE | - | - | - | - | 0.1 | -0.2 | 0.0 | 15.7 |
| LURE BY WHAT IT DRAWS | 0.1 | -10.3 | 0.0 | 5.9 | - | - | - | - |
| MANOEUVRE | 0.9 | +19.1 | 0.0 | 7.4 | 1.5 | +9.2 | 0.0 | 9.5 |
| MARCH AT ESCAPER | 0.4 | +1.4 | 0.0 | 0.0 | 0.1 | +0.4 | 0.0 | 18.1 |
| MARCH BY THE SUM | - | - | - | - | 0.5 | +30.1 | 0.0 | 0.0 |
| MARCH CHECK | 0.9 | +80.6 | 0.0 | 0.0 | 1.7 | +89.1 | 0.0 | 18.1 |
| MARCH OVER CASTS | 0.4 | +116.8 | 0.0 | 0.0 | 1.1 | +46.8 | 0.0 | 18.1 |
| MAX FOR POSITIONING | 4.5 | +58.4 | 0.0 | 76.4 | 5.0 | +60.3 | 0.0 | 139.2 |
| MISSILES IN THE MOVE | 4.7 | +209.5 | 0.0 | 14.7 | 4.3 | +89.5 | 0.0 | 108.2 |
| MISSILES NEXT TURN | 5.1 | +118.1 | 0.0 | 14.7 | 5.3 | +66.6 | 0.0 | 162.6 |
| MODEL FACING | 0.4 | +103.7 | 0.0 | 5.5 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.5 | -107.5 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL SPOT | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 36.4 |
| MOVE TO CHARGE COMPUTED | 2.3 | +282.8 | 0.0 | 45.4 | 3.0 | +655.8 | 0.0 | 114.9 |
| MOVES UNITS SPELL | 0.2 | +10.0 | 0.0 | 0.0 | 0.1 | +0.7 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 5.3 | +268.5 | 0.0 | 72.2 | 6.7 | +301.7 | 0.0 | 21.7 |
| NEXT CHARGE BY LIST | 3.5 | -137.4 | 5.9 | 45.4 | 5.5 | -272.4 | 41.2 | 199.5 |
| NEXT OBJECTIVE NEARER | 7.3 | -367.5 | 52.0 | 78.8 | - | - | - | - |
| NO DOUBLE ROUNDS | 1.9 | -133.6 | 148.7 | 24.5 | 1.9 | -143.1 | 235.1 | 15.7 |
| NOT TURNED | 0.2 | +0.0 | 0.0 | 5.9 | - | - | - | - |
| NOT WORTH A CAST | 0.7 | -1.0 | 0.0 | 0.0 | 0.2 | -0.2 | 0.0 | 0.0 |
| OFF BEST | 0.3 | -6.0 | 0.0 | 2.7 | 0.5 | -8.3 | 0.0 | 0.0 |
| ONE CHARGE A CHARGER | 2.4 | +0.0 | 0.0 | 121.0 | 1.1 | +0.0 | 0.0 | 60.5 |
| ONE FIGHT FORMULA | 4.0 | -61.2 | 0.0 | 27.0 | 4.8 | -137.1 | 0.0 | 200.6 |
| ONE OBJECTIVE FORMULA | 3.9 | -73.6 | 0.0 | 87.3 | 5.8 | +30.6 | 0.0 | 63.5 |
| ONE TARGET A SHOOTER | 16.9 | +340.7 | 0.0 | 187.0 | 20.4 | +599.0 | 0.0 | 399.1 |
| OPENS A LANE | - | - | - | - | 0.1 | +0.3 | 7.7 | 0.0 |
| OPENS UP | 0.2 | +18.2 | 8.2 | 0.0 | 0.5 | +47.5 | 34.7 | 0.0 |
| OVERRUNS AWAY | 0.1 | +20.7 | 10.5 | 0.0 | 0.4 | +22.7 | 65.4 | 0.0 |
| PATHS CROSS | 2.6 | +75.6 | 0.0 | 68.4 | 4.5 | +188.5 | 0.0 | 12.5 |
| PERIAPT WORTH | - | - | - | - | 0.1 | +4.9 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | - | - | - | - | 0.1 | -0.9 | 0.0 | 0.0 |
| PLAN RESULT | 41.5 | +1256.8 | 583.8 | 907.1 | 36.6 | +551.2 | 329.1 | 637.8 |
| PURSUES BIG PREY | 0.1 | -10.9 | 0.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | - | - | - | - | 5.5 | +673.1 | 91.7 | 93.0 |
| RANDOM MOVE BY FIGURES | 0.9 | +8.0 | 0.0 | 15.5 | 1.3 | +18.0 | 0.0 | 108.6 |
| REAL GROUND | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| REDIRECT BY WHAT IT STOPS | 0.1 | -3.1 | 0.0 | 7.7 | 0.1 | -1.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | 2.2 | +144.8 | 0.0 | 58.0 | 2.7 | +90.4 | 0.0 | 86.5 |
| REDIRECT WEIGHED | 0.2 | +0.0 | 0.0 | 0.0 | 0.3 | +7.1 | 38.2 | 0.0 |
| REFORMS TO MEET IT | 0.5 | -23.8 | 0.0 | 12.5 | 0.6 | -68.2 | 0.0 | 5.5 |
| REFUSING RETIRES | 0.1 | +0.0 | 0.0 | 33.8 | 0.1 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | 0.4 | +11.2 | 0.0 | 0.0 | 0.3 | +10.6 | 0.0 | 13.6 |
| RESTRAINS TO SHOOT | 0.1 | +2.4 | 0.0 | 0.0 | 0.1 | +0.7 | 0.0 | 0.0 |
| RISK BY ARC | 1.7 | +45.8 | 71.8 | 24.5 | 1.9 | -33.5 | 263.8 | 19.5 |
| RISK BY HIS FIGURE | 11.9 | -141.1 | 0.0 | 261.7 | 9.7 | -228.0 | 0.0 | 367.7 |
| RISK ON THE WAY | - | - | - | - | 0.1 | +0.0 | 0.0 | 0.0 |
| RUN DOWN | 1.8 | -24.8 | 163.3 | 0.0 | 1.5 | -6.5 | 115.5 | 3.7 |
| SAME CHARGE LATER | - | - | - | - | 0.2 | -10.9 | 33.8 | 27.0 |
| SCOUT SPOT | 0.2 | +0.2 | 0.0 | 0.0 | 0.2 | -0.0 | 0.0 | 0.0 |
| SCOUT WAITS | 0.2 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.4 | -37.6 | 0.0 | 2.7 | 0.2 | -13.3 | 0.0 | 0.0 |
| SEARCH SPOT | 4.1 | +108.8 | 0.0 | 63.5 | 4.4 | +152.0 | 0.0 | 77.2 |
| SELF MOVE SPELL | - | - | - | - | 0.3 | +61.3 | 0.0 | 71.8 |
| SET UP TOGETHER | - | - | - | - | 0.3 | +2.6 | 0.0 | 0.0 |
| SHOOTER COUNTED ONCE | 0.1 | -0.5 | 0.0 | 2.7 | - | - | - | - |
| SHOOTERS IN TWO RANKS | 0.5 | +1.1 | 0.0 | 0.0 | 0.2 | +0.2 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.3 | +55.6 | 86.3 | 7.4 | 0.8 | +20.4 | 2.7 | 0.0 |
| SHORT GUN FORWARD | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SHOT OR CHARGE | 0.2 | -1.8 | 0.0 | 7.7 | 0.4 | -33.8 | 47.7 | 0.0 |
| SHOT RISK POINTS | 10.5 | +56.1 | 0.0 | 56.9 | 13.0 | -159.6 | 0.0 | 454.5 |
| SHOTS IN THE MOVE | 17.4 | +1004.6 | 0.0 | 287.8 | 11.0 | +368.8 | 0.0 | 237.8 |
| SPELL SETS UP CHARGE | 0.1 | +55.2 | 0.0 | 0.0 | - | - | - | - |
| SPELL WORTH | 0.5 | +24.4 | 0.0 | 0.0 | 0.7 | +33.2 | 72.7 | 72.7 |
| SPELLS IN THE FIGHT | 0.2 | +1.7 | 51.4 | 0.0 | 0.1 | +0.3 | 7.4 | 0.0 |
| STAND AND SHOOT | 0.5 | -6.4 | 61.5 | 0.0 | 0.5 | -1.9 | 57.8 | 3.7 |
| STANDS FOR A REASON | 0.1 | +0.0 | 0.0 | 7.4 | 0.5 | +0.0 | 0.0 | 35.9 |
| STANDS STILL | 24.0 | +0.0 | 925.9 | 239.7 | 10.3 | +0.0 | 219.1 | 58.5 |
| STAY WORTH | 20.3 | +115.7 | 563.7 | 139.3 | 13.7 | +177.9 | 183.5 | 238.9 |
| STOPS | 0.2 | +9.3 | 30.0 | 0.0 | - | - | - | - |
| STUCK PIVOT | - | - | - | - | 0.2 | +0.0 | 0.0 | 19.1 |
| SUPPORT NARROWED | 1.2 | +0.0 | 73.2 | 7.7 | 0.7 | +0.0 | 85.5 | 19.5 |
| SURE REACH TOGETHER | 0.1 | +0.1 | 0.0 | 0.0 | 0.1 | +0.3 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 3.4 | +0.0 | 0.0 | 82.5 | 4.5 | +0.0 | 0.0 | 36.3 |
| THE PROMISE ADDS | 0.3 | -3.0 | 0.0 | 4.7 | 0.1 | -2.9 | 21.7 | 0.0 |
| THE PROMISED MOVE | 0.2 | +0.0 | 0.0 | 0.0 | 1.2 | +0.0 | 0.0 | 38.5 |
| TIED UP BY THE SUM | 0.4 | +41.6 | 17.9 | 0.0 | 0.3 | +37.1 | 23.8 | 0.0 |
| TIME ON OUR SIDE | 32.8 | +488.1 | 18.2 | 312.5 | 3.8 | +81.8 | 0.0 | 27.3 |
| TWO OR MORE ARRIVE | - | - | - | - | 0.2 | +0.2 | 0.0 | 0.0 |
| WAITS AGAIN | 1.2 | +0.0 | 0.0 | 32.9 | 1.1 | +0.0 | 0.0 | 26.3 |
| WAR ENGINE CHARGES | 0.1 | -2.1 | 10.5 | 0.0 | - | - | - | - |
| WAR ENGINE JOBS | 0.9 | +0.0 | 95.9 | 62.3 | - | - | - | - |
| WHO HITS BACK | 0.1 | +5.9 | 0.0 | 0.0 | 0.3 | +6.0 | 0.0 | 0.0 |
| WHOLE FIGHT | 0.1 | +7.1 | 15.5 | 0.0 | 0.1 | -1.1 | 28.2 | 0.0 |
| WHOLE FIGHT GAIN | 0.3 | +11.3 | 0.0 | 9.5 | 0.1 | +23.1 | 26.3 | 0.0 |
| WIDER SPREAD | 1.8 | +7.3 | 124.1 | 17.2 | 2.3 | -7.5 | 305.4 | 19.5 |
| WOUNDS ON THE RANKS | 1.4 | +36.1 | 0.0 | 0.0 | 1.7 | +83.2 | 0.0 | 0.0 |

### Rule changes: h8-opp-6ec093a-p3

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HOLDER ASSIGNMENT | 187 | 187 | 175 | 15.91 | +9290 | +53.1 |
| HIS SHOT LIST | 448 | 448 | 133 | 12.09 | +2542 | +19.1 |
| ONE TARGET A SHOOTER | 410 | 410 | 111 | 10.09 | +1320 | +11.9 |
| DEPLOY BY FIGURES | 174 | 174 | 108 | 9.82 | +1428 | +13.2 |
| SEARCH SPOT | 93 | 93 | 83 | 7.55 | +2870 | +34.6 |
| PATHS CROSS | 79 | 79 | 79 | 7.18 | +2905 | +36.8 |
| TIME ON OUR SIDE | 403 | 358 | 76 | 6.91 | +265 | +3.5 |
| LEGAL CHARGES ONLY | 74 | 74 | 74 | 6.73 | +0 | +0.0 |
| FIVE ACTION | 979 | 979 | 58 | 5.27 | +3685 | +63.5 |
| MOVE TO CHARGE COMPUTED | 58 | 58 | 40 | 3.64 | +3321 | +83.0 |
| SHOT RISK POINTS | 259 | 259 | 37 | 3.36 | +1145 | +31.0 |
| FOUR ROUNDS | 58 | 58 | 33 | 3.00 | +3223 | +97.7 |
| ARTILLERY RE-ROLL WEIGHED | 31 | 31 | 31 | 2.82 | +0 | +0.0 |
| FALLS SHORT | 262 | 235 | 26 | 2.36 | +138 | +5.3 |
| SHOTS IN THE MOVE | 312 | 288 | 26 | 2.36 | +2127 | +81.8 |
| HARD STAY DROPPED | 23 | 23 | 23 | 2.09 | +0 | +0.0 |
| MARCH CHECK | 29 | 29 | 21 | 1.91 | +498 | +23.7 |
| CANNON PLANNED TARGET | 94 | 94 | 20 | 1.82 | -304 | -15.2 |
| IDLE COST | 135 | 113 | 20 | 1.82 | +247 | +12.3 |
| MAX FOR POSITIONING | 104 | 101 | 20 | 1.82 | +101 | +5.0 |
| COVER ONCE | 101 | 75 | 19 | 1.73 | +333 | +17.5 |
| MISSILES IN THE MOVE | 99 | 76 | 19 | 1.73 | +694 | +36.5 |
| SHOOTS FROM THE BEST SPOT | 23 | 23 | 18 | 1.64 | +211 | +11.7 |
| CHARGE LOSSES | 125 | 125 | 17 | 1.55 | +1354 | +79.6 |
| FOLLOW UP WEIGHED | 17 | 17 | 17 | 1.55 | +3996 | +235.0 |
| REDIRECT COUNTER | 54 | 45 | 17 | 1.55 | +1126 | +66.2 |
| CANNON SIGHT KEPT | 16 | 16 | 16 | 1.45 | +0 | +0.0 |
| RISK BY HIS FIGURE | 238 | 238 | 15 | 1.36 | +1786 | +119.0 |
| LONE WIZARD KEPT IN | 13 | 13 | 13 | 1.18 | +1236 | +95.0 |
| MANOEUVRE | 27 | 27 | 13 | 1.18 | +311 | +23.9 |
| ADVANCE LANE KEPT | 12 | 12 | 12 | 1.09 | +0 | +0.0 |
| CHARGE NOT DECLARED | 12 | 12 | 12 | 1.09 | -3325 | -277.1 |
| RANDOM MOVE BY FIGURES | 24 | 24 | 12 | 1.09 | +286 | +23.8 |
| STAY WORTH | 374 | 358 | 12 | 1.09 | +176 | +14.7 |
| LANE BY FIGURES | 11 | 11 | 11 | 1.00 | +502 | +45.7 |
| HOLDS AMBUSHERS | 10 | 10 | 10 | 0.91 | +0 | +0.0 |
| NEXT OBJECTIVE NEARER | 80 | 80 | 10 | 0.91 | +180 | +18.0 |
| QUARTER ODDS | 60 | 60 | 10 | 0.91 | +800 | +80.0 |
| RISK BY ARC | 40 | 40 | 10 | 0.91 | +298 | +29.8 |
| CASTING BLOCK | 10 | 10 | 9 | 0.82 | +251 | +27.8 |
| OFF BEST | 9 | 9 | 9 | 0.82 | -157 | -17.4 |
| CHARGE NOW FIRST | 32 | 32 | 8 | 0.73 | -407 | -50.9 |
| HIS TURN DENIED | 29 | 29 | 8 | 0.73 | +244 | +30.6 |
| HOLDER AT DEPLOYMENT | 14 | 14 | 8 | 0.73 | +314 | +39.2 |
| NEARER NOT NEEDED | 132 | 127 | 8 | 0.73 | +194 | +24.2 |
| OPENS UP | 8 | 8 | 8 | 0.73 | +376 | +47.1 |
| SHOOTERS IN TWO RANKS | 8 | 8 | 8 | 0.73 | +14 | +1.8 |
| RESERVE FALL BACK | 7 | 7 | 7 | 0.64 | +240 | +34.2 |
| CASTER AWAY FROM SCREEN | 6 | 6 | 6 | 0.55 | +0 | +0.0 |
| FIGHT TO THE END | 22 | 22 | 6 | 0.55 | +834 | +139.0 |
| ONE OBJECTIVE FORMULA | 107 | 91 | 6 | 0.55 | +272 | +45.4 |
| TIED UP BY THE SUM | 7 | 7 | 6 | 0.55 | +272 | +45.4 |
| WOUNDS ON THE RANKS | 34 | 34 | 6 | 0.55 | +148 | +24.7 |
| COMBAT PIVOT | 5 | 5 | 5 | 0.45 | +0 | +0.0 |
| FIRE IN ORDER | 5 | 5 | 5 | 0.45 | +0 | +0.0 |
| MARCH BY THE SUM | 5 | 5 | 5 | 0.45 | +331 | +66.2 |
| NEXT CHARGE BY LIST | 100 | 100 | 5 | 0.45 | +107 | +21.4 |
| REDIRECT WEIGHED | 5 | 5 | 5 | 0.45 | +471 | +94.3 |
| SCOUT WAITS | 5 | 5 | 5 | 0.45 | +0 | +0.0 |
| CHAFF IN THE MOVE | 7 | 7 | 4 | 0.36 | +56 | +14.1 |
| CHAFF PASSED | 4 | 4 | 4 | 0.36 | -15 | -3.8 |
| MODEL FACING | 4 | 4 | 4 | 0.36 | +1141 | +285.2 |
| ONE FIGHT FORMULA | 97 | 55 | 4 | 0.36 | +26 | +6.5 |
| WHO HITS BACK | 4 | 4 | 4 | 0.36 | +103 | +25.6 |
| AFTERMATH IN POINTS | 3 | 3 | 3 | 0.27 | +651 | +217.1 |
| CAST JOB | 14 | 14 | 3 | 0.27 | +27 | +9.2 |
| FEATURE BUFFS | 29 | 29 | 3 | 0.27 | +24 | +8.0 |
| HIS MOVE AND SHOT | 37 | 37 | 3 | 0.27 | +7 | +2.3 |
| HONEST WORTH | 48 | 48 | 3 | 0.27 | +48 | +15.9 |
| MISSILES NEXT TURN | 114 | 89 | 3 | 0.27 | +0 | +0.0 |
| MOVES UNITS SPELL | 3 | 3 | 3 | 0.27 | +118 | +39.2 |
| SHORT GUN FORWARD | 3 | 3 | 3 | 0.27 | +0 | +0.0 |
| BEST PRIZE | 2 | 2 | 2 | 0.18 | -46 | -23.1 |
| BOMBING RUN | 2 | 2 | 2 | 0.18 | +57 | +28.4 |
| FALL BACK GOOD ORDER | 43 | 43 | 2 | 0.18 | +35 | +17.3 |
| KEEP FALLS | 2 | 2 | 2 | 0.18 | +30 | +15.2 |
| OVERRUNS AWAY | 5 | 5 | 2 | 0.18 | +203 | +101.5 |
| RESTRAINS TO SHOOT | 2 | 2 | 2 | 0.18 | +33 | +16.6 |
| SET UP TOGETHER | 3 | 3 | 2 | 0.18 | +16 | +8.1 |
| STUCK PIVOT | 2 | 2 | 2 | 0.18 | +0 | +0.0 |
| SUPPORT NARROWED | 21 | 21 | 2 | 0.18 | -25 | -12.5 |
| FALLBACK BY WORTH | 3 | 3 | 1 | 0.09 | +36 | +36.1 |
| FRIEND SHOOTS FIRST | 11 | 11 | 1 | 0.09 | +20 | +19.7 |
| FRIENDS SHOTS CHECKED | 1 | 1 | 1 | 0.09 | +14 | +14.4 |
| GUN MASK | 12 | 12 | 1 | 0.09 | +33 | +33.4 |
| KEEPS SCOUTS OR AMBUSH | 1 | 1 | 1 | 0.09 | +0 | +0.0 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.09 | +54 | +54.0 |
| PIVOT GUARDS FLANK | 1 | 1 | 1 | 0.09 | -9 | -9.4 |
| PURSUES BIG PREY | 1 | 1 | 1 | 0.09 | -120 | -120.0 |
| REFORMS TO MEET IT | 13 | 13 | 1 | 0.09 | +32 | +31.8 |
| REFUSING RETIRES | 2 | 2 | 1 | 0.09 | -1 | -1.1 |
| RUN DOWN | 36 | 36 | 1 | 0.09 | +14 | +14.1 |
| SCREEN BY WHAT IT SAVES | 6 | 6 | 1 | 0.09 | +2 | +1.8 |
| SPELLS IN THE FIGHT | 3 | 3 | 1 | 0.09 | +6 | +5.7 |
| STOPS | 2 | 2 | 1 | 0.09 | +48 | +48.4 |
| SURE REACH TOGETHER | 2 | 1 | 1 | 0.09 | +2 | +1.5 |
| WHOLE FIGHT | 2 | 2 | 1 | 0.09 | +6 | +5.7 |
| WHOLE FIGHT GAIN | 4 | 4 | 1 | 0.09 | +38 | +38.2 |
| ALREADY CARRIED | 1 | not checked | - | - | - | - |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| BACKUP TARGETS | 3 | 1 | 0 | 0.00 | - | - |
| BLOWS WHERE AIMED | 1 | 1 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 18 | 18 | 0 | 0.00 | - | - |
| CARRIES OUT COUNTER | 1 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 7 | trace | - | - | - | - |
| CHARACTER GUNS | 10 | 10 | 0 | 0.00 | - | - |
| CHARGER SLAIN LOST | 7 | 7 | 0 | 0.00 | - | - |
| CHEAP HELPER | 2 | not checked | - | - | - | - |
| CHEAPEST HOLDER | 3 | 3 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 15 | not checked | - | - | - | - |
| DEFENSIVE FLOOR | 1 | 1 | 0 | 0.00 | - | - |
| EDGE GIVE GROUND | 2 | 2 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT LIFT | 1 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 106 | not checked | - | - | - | - |
| GIVES UP | 5 | 5 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 1 | 1 | 0 | 0.00 | - | - |
| GROUND FLIERS | 1 | not checked | - | - | - | - |
| GUN FIGURES | 21 | not checked | - | - | - | - |
| HE SHOOTS OR CHARGES | 57 | 57 | 0 | 0.00 | - | - |
| HELPER ALREADY ASKED | 1 | not checked | - | - | - | - |
| HELPER UNSEEN | 1 | 1 | 0 | 0.00 | - | - |
| HIS CHARGE DENIED | 7 | 7 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 53 | 53 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 62 | 62 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 14 | 14 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 38 | 38 | 0 | 0.00 | - | - |
| HOLD ODDS | 149 | 149 | 0 | 0.00 | - | - |
| HUNT IN PAIRS | 6 | not checked | - | - | - | - |
| HUNT KEPT | 1 | trace | - | - | - | - |
| HUNT RESULT | 1 | trace | - | - | - | - |
| HUNT THE GUNS | 1 | trace | - | - | - | - |
| LONE CHARACTER SAFE SPOT | 1 | not checked | - | - | - | - |
| LONG SHOT | 6 | 6 | 0 | 0.00 | - | - |
| LOST CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 1 | 1 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 5 | trace | - | - | - | - |
| MARCH OVER CASTS | 16 | 16 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 6 | trace | - | - | - | - |
| MOVE SPELL SPOT | 2 | not checked | - | - | - | - |
| NO DOUBLE ROUNDS | 42 | 42 | 0 | 0.00 | - | - |
| NOT TURNED | 2 | 2 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 10 | not checked | - | - | - | - |
| ONE CHARGE A CHARGER | 38 | 38 | 0 | 0.00 | - | - |
| OPENS A LANE | 1 | not checked | - | - | - | - |
| PLAN RESULT | 859 | trace | - | - | - | - |
| REAL GROUND | 3 | 3 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 2 | 2 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 1 | 1 | 0 | 0.00 | - | - |
| SAME CHARGE LATER | 2 | 2 | 0 | 0.00 | - | - |
| SCOUT SPOT | 4 | 4 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 3 | not checked | - | - | - | - |
| SHOOTER COUNTED ONCE | 1 | 1 | 0 | 0.00 | - | - |
| SHOT OR CHARGE | 6 | 6 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 1 | not checked | - | - | - | - |
| SPELL WORTH | 14 | not checked | - | - | - | - |
| STAND AND SHOOT | 11 | 11 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 7 | 7 | 0 | 0.00 | - | - |
| STANDS STILL | 377 | 377 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 87 | not checked | - | - | - | - |
| THE PROMISE ADDS | 4 | 4 | 0 | 0.00 | - | - |
| THE PROMISED MOVE | 15 | not checked | - | - | - | - |
| TWO OR MORE ARRIVE | 2 | not checked | - | - | - | - |
| WAITS AGAIN | 25 | 25 | 0 | 0.00 | - | - |
| WAR ENGINE CHARGES | 1 | 1 | 0 | 0.00 | - | - |
| WAR ENGINE JOBS | 10 | 10 | 0 | 0.00 | - | - |
| WIDER SPREAD | 45 | 45 | 0 | 0.00 | - | - |

### Off best figure: h8-opp-6ec093a-p3

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| HOLDER ASSIGNMENT | rule | - | 1.45 | 13.5 |
| CHARGE NOT DECLARED | rule | 0.73 | 0.36 | 277.1 |
| CANNON PLANNED TARGET | rule | 0.73 | - | 54.0 |
| CHARGE NOW FIRST | rule | 0.18 | 0.55 | 50.9 |
| PATHS CROSS | rule | 0.36 | 0.27 | 60.5 |
| AFTERMATH NEEDS NEXT CHARGE | gate | - | 0.18 | 20.6 |
| BEST PRIZE | rule | - | 0.18 | 23.1 |
| CHAFF PASSED | rule | 0.09 | 0.09 | 7.3 |
| FIGHT ORDER BAND | gate | 0.09 | 0.09 | 3.1 |
| JOB FIRST | gate | 0.18 | - | 30.8 |
| NO REASON | gate | - | 0.18 | 22.5 |
| SUPPORT NARROWED | rule | 0.09 | 0.09 | 12.5 |
| AFTERMATH BAND | gate | - | 0.09 | 2.6 |
| DEPLOY BY FIGURES | rule | - | 0.09 | 4.7 |
| PIVOT GUARDS FLANK | rule | - | 0.09 | 9.4 |
| PURSUES BIG PREY | rule | 0.09 | - | 120.0 |
| REFUSING RETIRES | rule | - | 0.09 | 1.1 |

### Plans: h8-opp-6ec093a-p3

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 2.2 | 54% | 262 | 159 | 61% |
| Mine | join | 0.2 | 100% | 6 | 0 | 0% |
| Mine | move | 25.6 | 94% | 1368 | 0 | 0% |
| Mine | shoot | 13.0 | 71% | 588 | 1098 | 187% |
| Mine | support | 0.5 | 60% | 6 | 0 | 0% |
| Opponent | charge | 2.5 | 78% | 707 | 330 | 47% |
| Opponent | move | 29.0 | 92% | 2201 | 0 | 0% |
| Opponent | shoot | 4.9 | 54% | 416 | 221 | 53% |
| Opponent | support | 0.3 | 100% | 0 | 0 | - |

### Packages: hunt the guns, h8-opp-6ec093a-p3

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.1 | 1 | 0 | 100% | 100% | 0% | 3.0 | 335 | 165 | 0% | 17 |
| Opponent | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 84 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.2 | 1 | 0 | 100% | 100% | 0% | 3.0 | 335 | 165 | 0% | 48 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 148 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 302 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 330 |
| Warriors of Chaos | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Wood Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |

### Battle groups: h8-opp-6ec093a-p3

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 2.2 | 17% | 75% | 0% | - | 0% | 0% | 0% | 75% | 25% |
| Opponent | REDIRECT COUNTER | 2.7 | 33% | 60% | 0% | - | 0% | 0% | 10% | 90% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: h8-opp-6ec093a-p3

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 9 | 14 (9) | 0 | 14 | 52 | 78% | 1.5 | 0 (3) | 35 (3) | 0 (3) | 16 (8) | 0 (1) |
| Mine | Character | 43 | 17 (43) | 17 | 0 | 18 | 26% | 2.0 | 3 (9) | 10 (29) | 77 (4) | 22 (28) | 9 (14) |
| Mine | Clean-up | 7 | 87 (7) | 87 | 0 | 72 | 29% | 2.6 | 6 (2) | 0 (2) | 202 (3) | 149 (4) | 0 (3) |
| Mine | Fast Hammer | 4 | 0 (4) | 0 | 0 | 100 | 50% | 2.0 | - | - | 0 (4) | 0 (2) | 0 (2) |
| Mine | Fragile | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Mine | Hammer | 25 | 41 (25) | 22 | 20 | 40 | 24% | 2.1 | 45 (5) | 42 (18) | 0 (2) | 43 (20) | 37 (5) |
| Mine | Holder | 14 | 92 (14) | 10 | 82 | 31 | 71% | 4.5 | 0 (2) | 100 (7) | 108 (5) | 107 (7) | 73 (7) |
| Mine | Shooter | 11 | 63 (11) | 10 | 53 | 36 | 9% | 1.8 | 28 (4) | 87 (6) | 0 (1) | 76 (7) | 41 (4) |
| Mine | War machine | 24 | 34 (24) | 34 | 0 | 42 | 8% | 1.2 | 34 (7) | 26 (11) | 53 (6) | 27 (9) | 38 (15) |
| Mine | Wizard | 8 | 0 (8) | 0 | 0 | 0 | 25% | 4.0 | 0 (1) | 0 (7) | - | 0 (3) | 0 (5) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Chaff | 21 | 92 (21) | 15 | 77 | 41 | 57% | 3.1 | 65 (6) | 124 (9) | 63 (6) | 116 (14) | 54 (7) |
| Opponent | Character | 30 | 56 (30) | 56 | 0 | 17 | 20% | 2.2 | 14 (4) | 41 (16) | 92 (10) | 42 (17) | 75 (13) |
| Opponent | Clean-up | 2 | 123 (2) | 0 | 123 | 0 | 0% | 3.0 | - | 123 (2) | - | 88 (1) | 158 (1) |
| Opponent | Fast | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | 0 (1) | - | - | 0 (1) | - |
| Opponent | Fast Hammer | 18 | 53 (18) | 9 | 44 | 15 | 50% | 2.9 | 49 (4) | 37 (9) | 86 (5) | 59 (11) | 43 (7) |
| Opponent | Fragile | 2 | 94 (2) | 94 | 0 | 45 | 0% | 2.0 | - | - | 94 (2) | 170 (1) | 0 (1) |
| Opponent | Hammer | 15 | 20 (15) | 6 | 13 | 46 | 47% | 2.1 | 24 (3) | 26 (4) | 15 (8) | 15 (10) | 26 (5) |
| Opponent | Holder | 7 | 115 (7) | 0 | 115 | 22 | 57% | 4.0 | 214 (1) | 119 (5) | 0 (1) | 125 (3) | 102 (4) |
| Opponent | Shooter | 10 | 110 (10) | 23 | 87 | 21 | 10% | 2.2 | 0 (2) | 173 (6) | 50 (2) | 100 (5) | 122 (5) |
| Opponent | War machine | 6 | 24 (6) | 24 | 0 | 21 | 0% | 2.7 | 29 (4) | 0 (2) | - | - | 24 (6) |
| Opponent | Wizard | 3 | 8 (3) | 8 | 0 | 12 | 0% | 2.0 | - | 0 (1) | 4 (1) | 2 (2) | - |

### Charged fights: h8-opp-6ec093a-p3

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 10 | 89 | 2.0 | 1.2 | 44 | 55 | -10 | 5 of 8 | 5 of 8 | -274 | +27 |
| Mine | Chaos Dwarfs | 4 | 359 | 218 | 1.2 | 1.0 | 175 | 0 | +175 | 2 of 5 | 5 of 5 | - | +175 |
| Mine | Dwarfen Mountain Holds | 3 | 280 | 15 | 0.7 | 1.0 | 22 | 0 | +22 | 0 of 2 | 2 of 2 | - | +22 |
| **Mine** | all armies | 11 | 211 | 116 | 1.4 | 1.1 | 85 | 29 | +56 | 7 of 15 | 12 of 15 | -274 | +79 |
| Opponent | Grand Cathay | 2 | 252 | 550 | 2.5 | 1.0 | 220 | 0 | +220 | 0 of 5 | 5 of 5 | - | +220 |
| Opponent | High Elf Realms | 2 | 70 | 270 | 1.5 | 1.0 | 180 | 0 | +180 | 2 of 3 | 3 of 3 | - | +180 |
| Opponent | Ogre Kingdoms | 1 | 65 | 212 | 2.0 | 1.0 | 106 | 0 | +106 | 0 of 2 | 1 of 2 | - | +106 |
| Opponent | Skaven | 1 | 165 | 0 | 2.0 | 1.0 | 0 | 20 | -20 | 1 of 2 | 0 of 2 | - | -20 |
| Opponent | Warriors of Chaos | 4 | 21 | 408 | 2.2 | 1.1 | 181 | 19 | +162 | 6 of 9 | 8 of 9 | +499 | +120 |
| Opponent | Wood Elf Realms | 1 | 95 | 1224 | 3.0 | 2.0 | 408 | 0 | +408 | 2 of 3 | 3 of 3 | +564 | +95 |
| **Opponent** | all armies | 11 | 96 | 428 | 2.2 | 1.2 | 196 | 9 | +187 | 11 of 24 | 20 of 24 | +543 | +136 |

### Effective charges: h8-opp-6ec093a-p3

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 8 | 4 (net -72) | 0 | 1 (net +165) | 0 | 0 | 3 (net +14) | 0 | 12% (1 of 8) |
| Mine | Chaos Dwarfs | 5 | 0 | 0 | 1 (net +139) | 2 (net +170) | 0 | 2 (net +198) | 0 | 20% (1 of 5) |
| Mine | Dwarfen Mountain Holds | 2 | 0 | 0 | 1 (net +45) | 1 (net +0) | 0 | 0 | 0 | 50% (1 of 2) |
| Opponent | Grand Cathay | 5 | 0 | 0 | 1 (net +65) | 1 (net +0) | 3 (net +345) | 0 | 0 | 20% (1 of 5) |
| Opponent | High Elf Realms | 3 | 0 | 0 | 1 (net +230) | 2 (net +155) | 0 | 0 | 0 | 33% (1 of 3) |
| Opponent | Ogre Kingdoms | 2 | 2 (net +106) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 2) |
| Opponent | Skaven | 2 | 2 (net -20) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 2) |
| Opponent | Warriors of Chaos | 9 | 1 (net -173) | 0 | 0 | 2 (net +210) | 0 | 4 (net +280) | 2 | 0% (0 of 7) |
| Opponent | Wood Elf Realms | 3 | 0 | 0 | 0 | 2 (net +468) | 1 (net +289) | 0 | 0 | 0% (0 of 3) |

### Charged fights, damage counted: h8-opp-6ec093a-p3

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 4 | 94 | 374 | -72 | 62 | 116 | -55 | -58.5 |
| Mine | Effective (55-75%) | 3 | 79 | 116 | +116 | 116 | 3 | +113 | +144.1 |
| Mine | 76-89% | 3 | 337 | 136 | +113 | 120 | 16 | +104 | +30.8 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 5 | 503 | 257 | +87 | 144 | 10 | +134 | +26.7 |
| Mine | All fights | 15 | 276 | 236 | +56 | 112 | 38 | +74 | +26.7 |
| Opponent | Long shot (under 50%) | 5 | 80 | 163 | -0 | 79 | 54 | +25 | +31.3 |
| Opponent | Effective (55-75%) | 2 | 288 | 148 | +148 | 148 | 0 | +148 | +51.3 |
| Opponent | 76-89% | 7 | 518 | 208 | +238 | 269 | 39 | +231 | +44.5 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 4 | 615 | 300 | +280 | 302 | 0 | +302 | +49.2 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 4 | 530 | 118 | +331 | 342 | 57 | +285 | +53.7 |
| Opponent | No odds | 2 | 392 | 115 | +46 | 46 | 0 | +46 | +11.6 |
| Opponent | All fights | 24 | 415 | 186 | +187 | 219 | 32 | +186 | +44.9 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| h8-opp-6ec093a-p3 | move | 69 | 18 (26%) | 12 (17%) | 8 (12%) | 43 (62%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0111, L0128 |
| Charmed Shield | Opponent | L0534 |
| Elixir of Power | Opponent | L0111, L0211 |
| Fistful of Laurels | Opponent | L0518 |
| Periapt of Soul Exchange | Opponent | L0621 |
| Ring of Doom | Mine | L0211, L0228 |
| Ring of Doom | Opponent | L0111, L0211, L0415 |
| Ring of Jet | Opponent | L0111, L0211 |
| Standard of the Fell Warrior | Opponent | L0313 |
| Storm Daemon (Renegade 2.0) | Opponent | L0621 |

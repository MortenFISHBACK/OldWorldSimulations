"""Fight odds 1: first round claimed v happened per brain (ON = exact round), by claimed-win band.
python3 -I fo1.py <root holding <arm>-N/<batch>/game-*.log.jsonl> <charges.pkl>"""
import sys,glob,json,re,os,pickle,collections
ROOT,PKL=sys.argv[1],sys.argv[2]
SINGLE=len(sys.argv)>3 and sys.argv[3]=='single'
JS=re.compile(r"\d+\. charge #(\d+) [^|]*?\[TAKEN\]: worth ([+-][\d.]+)[^|]*?\[reach (\d+)%, win (\d+)%, slain or flees (\d+)%")
claims={}
for f in glob.glob(ROOT+'/**/game-*.log.jsonl',recursive=True):
    fn=os.path.basename(f); arm=os.path.relpath(f,ROOT).split('/')[0]
    for l in open(f,encoding='utf-8'):
        if '"JobSplit"' not in l or '[TAKEN]' not in l: continue
        x=json.loads(l); m=JS.search(x['summary'])
        if m: claims[(arm,fn,x['turn'],x['side'],x['actor_id'])]=(int(m.group(4))/100,int(m.group(5))/100,float(m.group(2)))
C=pickle.load(open(PKL,'rb'))
R=collections.defaultdict(list); nogame=collections.Counter()
for c in C:
    b='OFF' if c['simpler'] else 'ON'
    arm=c['arm']+'-?'
    k=[v for kk,v in claims.items() if kk[1]==c['file'] and kk[2]==c['turn'] and kk[3]==c['side'] and kk[4]==c['A'] and kk[0].startswith(c['arm'])]
    if c['res']!='contact' or c.get('r1') not in ('win','loss','draw'): continue
    win=c.get('win'); sf=None
    if k: win2,sf,w=k[0]; win=win if win is not None else win2
    if win is None: nogame[b]+=1; continue
    hT=c['hT']
    broke=bool(c.get('wipe') and c['r1']=='win') or any(t in ('BreakTest',) and h==hT and (': failed' in s) for (t,a,h,sd,s) in c.get('after',[]))
    if SINGLE and c.get('nunits',2)>2: continue
    R[b].append(dict(win=win,sf=sf,r1=c['r1'],by=c.get('by'),broke=broke,net=(c.get('t_2t') or 0)-(c.get('a_2t') or 0)))
m=lambda v:sum(v)/len(v) if v else float('nan')
bands=[(0,.2),(.2,.4),(.4,.6),(.6,.8),(.8,1.01)]
print("| Claimed win | ON fights | ON claimed v won | OFF fights | OFF claimed v won |\n|---|---|---|---|---|")
for lo,hi in bands:
    row=[f"{lo:.0%}-{min(hi,1):.0%}"]
    for b in ('ON','OFF'):
        P=[p for p in R[b] if lo<=p['win']<hi]
        row+= [str(len(P)), f"{m([p['win'] for p in P]):.0%} v {m([p['r1']=='win' for p in P]):.0%}" if P else '-']
    print('| '+' | '.join(row)+' |')
for b in ('ON','OFF'):
    P=R[b]; Q=[p for p in P if p['sf'] is not None]
    gap=m([abs(m([p['win'] for p in P if lo<=p['win']<hi])-m([p['r1']=='win' for p in P if lo<=p['win']<hi]))*len([p for p in P if lo<=p['win']<hi]) for lo,hi in bands if any(lo<=p['win']<hi for p in P)])
    print(f"{b}: fights {len(P)}; claimed win {m([p['win'] for p in P]):.0%} v won {m([p['r1']=='win' for p in P]):.0%}; drawn {m([p['r1']=='draw' for p in P]):.0%}; "
          f"weighted band gap {sum(abs(m([p['win'] for p in P if lo<=p['win']<hi])-m([p['r1']=='win' for p in P if lo<=p['win']<hi]))*len([p for p in P if lo<=p['win']<hi]) for lo,hi in bands if any(lo<=p['win']<hi for p in P))/max(1,len(P)):.0%}; "
          f"target slain or flees claimed {m([p['sf'] for p in Q]):.0%} v round-1 broke or wiped {m([p['broke'] for p in Q]):.0%} (n {len(Q)}); "
          f"mean result margin {m([p['by'] for p in P if p['by'] is not None]):+.1f}; net per fight {m([p['net'] for p in P]):+.0f}; no claim found {nogame[b]}")
    for lo,hi in bands:
        P2=[p for p in Q if lo<=p['win']<hi]
        if P2: print(f"   band {lo:.0%}: margin {m([p['by'] for p in P2 if p['by'] is not None]):+.1f}, slain/flees {m([p['sf'] for p in P2]):.0%} v {m([p['broke'] for p in P2]):.0%}")

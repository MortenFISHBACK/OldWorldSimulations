#!/usr/bin/env bash
# Archive a sim batch's game logs to the private archive repository, verify, and print what may be removed
# from the shared folder. Run by the batch OWNER after merging results. Never deletes anything itself.
#
#   scripts/archive-sim-batch.sh <batch-folder> [--delete-logs]
#
# <batch-folder> = a folder under /mnt/project-files (e.g. /mnt/project-files/charge-worth-h2h-2026-11-16).
# Every sub-folder (a part: mine-1, opp-3, ...) becomes one or more bundles  <batch>/<part>.tar.gz  (split in
# 90 MB pieces .tar.gz.000 ...). Small loose files (reports, pairs, csv, md) are copied as plain files.
# Needs git push access to the archive repository (OWWT_ARCHIVE_URL, default below); no key is stored here.
# --delete-logs : after a VERIFIED push, remove from the shared folder the per-game log files
#                 (*.log.jsonl, records.db*, units.jsonl). Reports, per-game .txt and csv stay. Only with the user's word.
set -euo pipefail
SRC="${1:?usage: archive-sim-batch.sh <batch-folder> [--delete-logs]}"; DEL="${2:-}"
URL="${OWWT_ARCHIVE_URL:-https://github.com/MortenFISHBACK/OldWorldSimulations.git}"
SRC="${SRC%/}"; BATCH="$(basename "$SRC")"
W="$(mktemp -d)"; trap 'rm -rf "$W"' EXIT
git clone -q "$URL" "$W/repo"; R="$W/repo"; mkdir -p "$R/batches/$BATCH"; O="$R/batches/$BATCH"

for d in "$SRC"/*/; do
  [ -d "$d" ] || continue; p="$(basename "$d")"
  tar -C "$SRC" -czf - "$p" | split -b 90M -d -a 3 - "$O/$p.tar.gz."
  # one piece only: drop the numbering suffix for readability
  n=$(ls "$O/$p.tar.gz."* | wc -l); [ "$n" = 1 ] && mv "$O/$p.tar.gz.000" "$O/$p.tar.gz"
  echo "$p $(find "$d" -type f | wc -l)" >> "$O/FILECOUNTS.txt"
done
find "$SRC" -maxdepth 1 -type f -size -5M -exec cp {} "$O/" \;      # reports, pairs, csv ... (small)
( cd "$O" && sha256sum *.tar.gz* > SHA256SUMS 2>/dev/null || true )

SHA="$(grep -rhm1 -oE '[0-9a-f]{9,40}' "$SRC"/*/commit.txt "$SRC"/*/*/commit.txt 2>/dev/null | head -1 || true)"
GAMES="$(find "$SRC" -name '*.log.jsonl' | wc -l)"; MB="$(du -sm "$SRC" | cut -f1)"
REP="$(cd "$SRC" && ls report*.md compare*.md 2>/dev/null | head -1 || true)"
ROW="| $BATCH | $(echo "$BATCH" | grep -oE '[0-9]{4}-[0-9]{2}-[0-9]{2}' | tail -1) | ${SHA:-?} | $GAMES | $MB | batches/$BATCH/${REP:-} |"
# several owners may archive at once: serialise the commit and push (retry on a rejected push)
exec 9>"${TMPDIR:-/tmp}/owwt-archive.lock"; flock 9
for try in 1 2 3 4; do
  ( cd "$R" && git fetch -q origin main && mv "$O" "$W/mine" && git reset -q --hard origin/main && mkdir -p batches && mv "$W/mine" "$O"
    [ -f INDEX.md ] || printf '| batch | date | build sha | games with log | size in shared folder (MB) | report |\n|---|---|---|---|---|---|\n' > INDEX.md
    sed -i "/^| $BATCH |/d" INDEX.md; echo "$ROW" >> INDEX.md
    git add -A; git commit -qm "Archive $BATCH"; git push -q origin HEAD:refs/heads/claude/project-thread-vgr2sa ) && break
  [ "$try" = 4 ] && { echo "PUSH FAILED"; exit 1; }; sleep 5
done
flock -u 9

# verify: fresh clone, checksums, file counts of each bundle against the source
git clone -q -b claude/project-thread-vgr2sa "$URL" "$W/check"; C="$W/check/batches/$BATCH"; ok=1
( cd "$C" && [ ! -f SHA256SUMS ] || sha256sum -c --quiet SHA256SUMS ) || ok=0
while read -r p cnt; do
  got=$(cat "$C/$p.tar.gz"* | tar -tzf - | grep -vc '/$' || true); [ "$got" = "$cnt" ] || { echo "COUNT MISMATCH $p src=$cnt archive=$got"; ok=0; }
done < "$C/FILECOUNTS.txt"
[ "$ok" = 1 ] || { echo "VERIFY FAILED - nothing may be deleted"; exit 1; }
echo "VERIFIED $BATCH: $(ls "$C" | wc -l) entries, $(du -sm "$C" | cut -f1) MB in the archive"
find "$SRC" -type f \( -name '*.log.jsonl' -o -name 'records.db*' -o -name 'units.jsonl' \) -printf '%s\n' | awk '{s+=$1} END{printf "removable from shared folder: %.0f MB\n", s/1048576}'
if [ "$DEL" = "--delete-logs" ]; then
  find "$SRC" -type f \( -name '*.log.jsonl' -o -name 'records.db*' -o -name 'units.jsonl' \) -delete; echo "logs removed from $SRC"
fi

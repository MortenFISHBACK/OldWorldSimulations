# Doctrine scorecard: cnomg-c940641-p4

### Scorecard: cnomg-c940641-p4

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0524 | 2 | 1 | Mine | - | - | 4 | 1 | 1 | 0 | 0 | 0 | 285 |
| L0524 | 2 | 1 | Opponent | - | - | 6 | 3 | 4 | 0 | 0 | 0 | 0 |
| L0612 | 6 | 1 | Mine | no | 0 | - | 0 | 3 | 0 | 0 | 0 | 445 |
| L0612 | 6 | 1 | Opponent | no | 10 | 6 | 0 | 1 | 0 | 0 | 0 | 330 |
| L0628 | 4 | 1 | Mine | no | 0 | - | 2 | 5 | 0 | 0 | 0 | 346 |
| L0628 | 4 | 1 | Opponent | no | 9 | - | 0 | 1 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 0% | 0.0 | 4.0 | 1.0 | 3.0 | 0.0 | 0.0 | 0.0 | 358.7 |
| **Average** | | | Opponent | 0% | 9.5 | 6.0 | 1.0 | 2.0 | 0.0 | 0.0 | 0.0 | 110.0 |

### KPIs: cnomg-c940641-p4

Rules off - Mine only: NO OLD ONE-MOVE GUESS.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 100% (15 of 15) | 0% (0 of 15) | 50% (15 of 30) |
| Winner chose to follow up after the loser gave ground |  | - | - | - |
| Winner chose to pursue after the loser fell back in good order |  | - | - | - |
| Winner chose to pursue after the loser fled |  | 100% (1 of 1); on the table 100% | - | 100% (1 of 1); on the table 100% |
| Winner chose to follow up or pursue (all three) |  | 100% (1 of 1); on the table 100% | - | 100% (1 of 1); on the table 100% |
| Magic missiles tried each own turn | 50%+ | - | 47% (14 of 30) | 47% (14 of 30) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | - | 50% (14 of 28) | 50% (14 of 28) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | - | - |
| Points that never fought | lower | 81% (4889 of 6000) | 71% (4273 of 5998) | 76% (9162 of 11998) |
|   infantry points that never fought | lower | 79% (1760 of 2232) | 100% (694 of 694) | 84% (2454 of 2926) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 63% (17 of 27) | 65% (15 of 23) | 64% (32 of 50) |
| Bound items with a magic missile used (at least once a game) |  | 0.0 uses a game | 67% (2 of 3); 2.3 uses a game | 67% (2 of 3); 1.2 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
|   their share of the points of units over 100 pts | lower | 55% (2314 of 4232) | 67% (3872 of 5787) | 62% (6186 of 10019) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | - | 2.0 (38%) | 2.0 (38%) |
| MARCHED: its unit marched | - | 2.0 (38%) | 2.0 (38%) |
| CHARGED: its unit charged | - | 0.7 (12%) | 0.7 (12%) |
| IN COMBAT: engaged in combat | - | 0.7 (12%) | 0.7 (12%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 6.0 | 1.3 | 4.7 | 0.7 | 0.3 |
| not cast | 2.0 | 2.7 | 5.3 | 3.3 | 23.7 |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 2.3 (88%) | 2.0 (38%) | 1.0 (30%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 2.0 (38%) | 1.0 (30%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.7 (12%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.0 (0%) | 0.7 (12%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.3 (12%) | 0.0 (0%) | 1.3 (40%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.0 (100%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 23.7 (100%) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 61% (132 of 215) | 81% (13 of 16) | 63% (145 of 231) |
|   cavalry | 58% (11 of 19) | 25% (1 of 4) | 52% (12 of 23) |
|   character | 87% (26 of 30) | - | 87% (26 of 30) |
|   infantry | 47% (26 of 55) | - | 47% (26 of 55) |
|   monster | 67% (8 of 12) | - | 67% (8 of 12) |
|   war machine | 62% (61 of 99) | 100% (12 of 12) | 66% (73 of 111) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 4.7 (17%) | 0.7 (67%) | 5.3 (19%) |
| CHARGED: it charged | 1.0 (4%) | 0.0 (0%) | 1.0 (3%) |
| NO TARGET IN RANGE | 10.7 (39%) | 0.3 (33%) | 11.0 (38%) |
| ONLY IN COMBAT: the only targets were in combat | 1.0 (4%) | 0.0 (0%) | 1.0 (3%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 7.3 (27%) | 0.0 (0%) | 7.3 (26%) |
| SHELTERED: the target was sheltered | 2.7 (10%) | 0.0 (0%) | 2.7 (9%) |
| OTHER BAR | 0.3 (1%) | 0.0 (0%) | 0.3 (1%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 4.0 | 1.0 | 75% | 5.0 pts | 20 pts |
| character | 10.7 | 5.7 | 75% | 7.9 pts | 84 pts |
| infantry | 18.3 | 3.7 | 85% | 3.4 pts | 62 pts |
| monster | 2.7 | 0.3 | 88% | 1.7 pts | 5 pts |
| war machine | 24.3 | 11.7 | 78% | 16.4 pts | 399 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 1.3 | 3.0 | 2.2 |
| Charges that made contact a game | 1.0 | 1.0 | 1.0 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | - | 1.00 declared, 0.33 contact (3 units) | 1.00 declared, 0.33 contact (3 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 0.00 declared, 0.00 contact (1 units) | 0.00 declared, 0.00 contact (1 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.18 declared, 0.14 contact (22 units) | 0.46 declared, 0.15 contact (13 units) | 0.29 declared, 0.14 contact (35 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 75% (3 of 4) | 100% (1 of 1) | 50% (1 of 2) | 71% (5 of 7) |
| Character in a unit | 71% (5 of 7) | 50% (2 of 4) | 100% (1 of 1) | 67% (8 of 12) |
| Character on its own | 100% (1 of 1) | 67% (2 of 3) | 50% (1 of 2) | 67% (4 of 6) |
| Infantry | 14% (1 of 7) | 50% (3 of 6) | - | 31% (4 of 13) |
| Monster | 100% (2 of 2) | - | - | 100% (2 of 2) |
| War Machines | 90% (9 of 10) | - | - | 90% (9 of 10) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Dwarfen Mountain Holds | 3 | 100% (1 of 1); on the table 100% | - | 81% | 63% (17 of 27) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Grand Cathay | 1 | - | 56% (10 of 18) | 70% | 56% (5 of 9) | 67% (2 of 3); 7.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Vampire Counts | 1 | - | 33% (2 of 6) | 94% | 86% (6 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 1 | - | 33% (2 of 6) | 49% | 57% (4 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (cnomg-c940641-p4, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 0% (0) | 100% (2) | 67% (2) |
| ...free all their last turn and able to turn (per game) | 0.00 | 0.67 | 0.67 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.67 | 0.67 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.33 | 0.00 | 0.33 |

### Quality by phase: cnomg-c940641-p4

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.3 | 3.0 |
| Strategy | Charge objectives carried out (made contact) | 75% (3 of 4) | 33% (3 of 9) |
| Strategy | Shoot objectives carried out (shot that target) | 63% (43 of 68) | 50% (9 of 18) |
| Strategy | Support requests answered (helper made contact too) | - | 100% (1 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | - | 0% (0 of 1) |
| Strategy | Joined characters whose unit fought | 27% (3 of 11) | 33% (2 of 6) |
| Strategy | Lone characters that fought | 0% (0 of 2) | 50% (3 of 6) |
| Movement | Charges halted short of contact | 0.0 | 1.3 |
| Movement | Idle units | 3.0 | 2.0 |
| Movement | Points that never moved of their own | 358.7 | 110.0 |
| Movement | Fights charged into per game | 1.0 | 0.7 |
| Movement | Charges with odds: long shots (under 50%) | 1 of 3, net -60 | 0 of 1 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 3 | 0 of 1 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 3 | 1 of 1, net +233 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 of 3, net +30 | 0 of 1 |
| Shooting | Shots by shooting units (incl. breath weapons) | 28.0 | 0.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 46% (39 of 84) | 0% (0 of 1) |
| Shooting | Points destroyed by shooting units | 50.7 | 0.0 |
| Shooting | War machine shots | 20.3 | 4.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 59% (36 of 61) | 17% (2 of 12) |
| Shooting | Points destroyed by war machines | 0.0 | 40.0 |
| Magic | Magic missiles cast | - | 2.7 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | - | 75% (6 of 8) |
| Magic | Wounds caused by magic missiles | - | 1.0 |
| Magic | Wounds caused by other spells | - | 1.3 |
| Magic | Points destroyed by magic (all spells) | 0.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.0 / 0.0 / 0.0 / 0.0 | 5.0 / 0.3 / 0.3 / 0.7 |
| Combat | Points destroyed in combat | 36.7 | 97.7 |
| Combat | Points run down | 0.0 | 0.0 |
| Combat | Net points per charged fight, damage counted | +18 | +13 |
| Combat | Net per 100 charger points, damage counted | +32.6 | +4.1 |
| Combat | First round won (charged fights) | 67% | 50% |
| Combat | Net points per charged fight | +0 | +92 |
| Combat | Net points per supported fight / lone fight | - / +0 | +233 / -50 |
| Combat | Charged fights on a top-3 enemy unit | 1 of 3 | 2 of 2 |
| Game | Points lost | 160.0 | 142.3 |
| Game | VP from objectives | 716.7 | 573.3 |
| Game | Lone holders (player turns) | 0.0 | 9.5 |

- Mine won / drew / lost: 0 / 3 / 0 of 3 ended games (of 3); mean margin (Mine - Opponent) +84 VP
- Points traded per game (both sides' losses): 302
- Games not ended: 0; findings 1, warnings 0

### Opponent rules: cnomg-c940641-p4

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| ARMY TABLE | 6.0 | +93.7 | 0.0 | 0.0 | 8.0 | +150.1 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 0.7 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 55.0 |
| BACKUP TARGETS | 0.3 | +0.8 | 0.0 | 0.0 | - | - | - | - |
| BEST PRIZE | - | - | - | - | 0.3 | -35.5 | 0.0 | 0.0 |
| CANNON PLAN MISSED | 1.3 | +0.0 | 27.3 | 0.0 | - | - | - | - |
| CANNON PLANNED TARGET | 16.0 | +45.5 | 197.7 | 0.0 | 4.0 | +149.6 | 80.0 | 110.0 |
| CANNON SIGHT KEPT | 2.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT SET-UP | - | - | - | - | 0.3 | +0.0 | 77.7 | 0.0 |
| CAST JOB | - | - | - | - | 4.0 | +12.8 | 155.3 | 0.0 |
| CASTS FROM BEHIND | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | - | - | - | - | 1.7 | +99.5 | 0.0 | 60.0 |
| CHAFF PASSED | 0.3 | -0.8 | 0.0 | 0.0 | - | - | - | - |
| CHALLENGE BY POINTS | 0.3 | +1.2 | 0.0 | 0.0 | - | - | - | - |
| CHAMPION KNOWS CHALLENGE | - | - | - | - | 0.3 | -5.0 | 0.0 | 0.0 |
| CHARACTER GUNS | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHARGE LOSSES | 11.0 | -262.1 | 0.0 | 100.0 | 16.0 | -667.4 | 0.0 | 37.0 |
| CHARGE NOW FIRST | 0.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 8.3 | +0.0 | 0.0 | 0.0 | 7.7 | +0.0 | 0.0 | 0.0 |
| COVER ONCE | 11.3 | -745.7 | 0.0 | 155.7 | 5.0 | -183.9 | 0.0 | 0.0 |
| DEFENSIVE ARMY | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| DENIED BY THE FIGHT | - | - | - | - | 0.7 | -6.9 | 77.7 | 0.0 |
| DEPLOY BY FIGURES | 13.3 | -169.6 | 0.0 | 0.0 | 4.3 | +35.7 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | - | - | - | - | 0.3 | -10.8 | 77.7 | 0.0 |
| EXACT ROUND | 0.7 | +1.2 | 33.7 | 0.0 | 1.7 | +8.8 | 0.0 | 0.0 |
| FALL BACK GOOD ORDER | 0.3 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 155.3 | 33.3 |
| FALLS SHORT | - | - | - | - | 19.3 | +324.2 | 0.0 | 13.7 |
| FEATURE BUFFS | - | - | - | - | 0.7 | +2.5 | 0.0 | 0.0 |
| FIGHT TO THE END | 0.7 | +1.2 | 13.7 | 0.0 | - | - | - | - |
| FIVE ACTION | 144.7 | +3794.8 | 437.0 | 530.7 | 67.3 | +2259.5 | 390.7 | 354.7 |
| FLANK NOT WEIGHED | 4.3 | +0.0 | 0.0 | 233.3 | 2.7 | +0.0 | 0.0 | 13.7 |
| FOUR ROUNDS | 1.3 | +41.4 | 33.7 | 20.0 | 3.0 | +145.8 | 155.3 | 33.3 |
| FREED FROM HIS FIGHT | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FRIEND SHOOTS FIRST | 1.3 | -21.0 | 0.0 | 0.0 | 1.3 | -0.9 | 0.0 | 0.0 |
| FRIENDS SHOTS CHECKED | 0.3 | -0.6 | 0.0 | 0.0 | - | - | - | - |
| GOAL WALK | 3.0 | +250.4 | 0.0 | 0.0 | 1.0 | +33.7 | 0.0 | 0.0 |
| GUN FIGURES | 2.0 | +2.9 | 37.0 | 0.0 | - | - | - | - |
| GUN MASK | 1.3 | +40.7 | 0.0 | 0.0 | 1.3 | +19.5 | 0.0 | 0.0 |
| HARD STAY DROPPED | 5.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS CHARGE BY HIS RUN | 6.7 | +0.0 | 0.0 | 80.0 | 7.7 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE DENIED | 0.3 | +2.7 | 20.0 | 0.0 | - | - | - | - |
| HIS CHARGE LIST | 9.3 | +0.0 | 0.0 | 0.0 | 9.0 | +0.0 | 0.0 | 74.0 |
| HIS LEGAL MOVES | 2.0 | +0.0 | 0.0 | 0.0 | 6.7 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 4.3 | -23.3 | 0.0 | 100.0 | 5.7 | -85.4 | 0.0 | 50.7 |
| HIS MOVE AS HE DECIDES | 32.7 | +8.0 | 137.7 | 0.0 | - | - | - | - |
| HIS ONE MOVE | 18.0 | -34.5 | 0.0 | 40.0 | - | - | - | - |
| HIS ONE QUARTER | 2.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 1.3 | +0.0 | 0.0 | 0.0 | 6.7 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 48.7 | +2009.3 | 0.0 | 160.0 | 39.7 | +3852.9 | 0.0 | 101.3 |
| HIS SHOTS BY HIS RUN | 36.3 | +577.2 | 0.0 | 200.0 | 35.7 | +825.4 | 0.0 | 101.3 |
| HIS TURN DENIED | - | - | - | - | 0.7 | +13.9 | 77.7 | 0.0 |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 14.3 | +0.0 | 0.0 | 0.0 | 12.7 | +0.0 | 0.0 | 0.0 |
| HOLDER ASSIGNMENT | 10.0 | +861.9 | 0.0 | 0.0 | 8.3 | +1024.3 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 1.0 | -3.9 | 33.7 | 0.0 | 2.3 | -92.7 | 155.3 | 0.0 |
| HUNT IN PAIRS | - | - | - | - | 0.7 | +69.3 | 0.0 | 0.0 |
| IDLE COST | - | - | - | - | 15.7 | -397.0 | 0.0 | 37.0 |
| JOINT CHARGE NOW | - | - | - | - | 0.7 | -11.7 | 155.3 | 0.0 |
| JOINT KNOWS CHALLENGE | - | - | - | - | 0.3 | -2.7 | 0.0 | 0.0 |
| KEEP FALLS | - | - | - | - | 0.3 | +0.9 | 0.0 | 0.0 |
| KEEPS SCOUTS OR AMBUSH | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 3.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | - | - | - | - | 0.7 | +42.7 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| LONE CHARACTER SAFE SPOT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| LONG SHOT | 0.3 | +1.4 | 20.0 | 0.0 | - | - | - | - |
| LOST AFTER ESCAPE | 1.0 | +0.6 | 13.7 | 20.0 | 1.0 | -2.7 | 155.3 | 0.0 |
| MAKE SURE TOGETHER | - | - | - | - | 1.3 | +57.8 | 0.0 | 0.0 |
| MANOEUVRE | 2.0 | -15.7 | 0.0 | 0.0 | 1.7 | +6.6 | 0.0 | 0.0 |
| MARCH AT ESCAPER | - | - | - | - | 0.3 | +0.7 | 0.0 | 0.0 |
| MARCH BY THE SUM | - | - | - | - | 0.3 | +93.2 | 0.0 | 0.0 |
| MARCH CHECK | - | - | - | - | 0.3 | +14.8 | 0.0 | 0.0 |
| MARCH OF THE TABLE | - | - | - | - | 0.7 | +26.1 | 0.0 | 0.0 |
| MARCH OVER CASTS | - | - | - | - | 2.0 | +214.2 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MAX FOR POSITIONING | 0.3 | +0.5 | 0.0 | 0.0 | 2.7 | +41.9 | 0.0 | 0.0 |
| MEETS IN TIME | 9.3 | +185.0 | 0.0 | 0.0 | 2.3 | +331.4 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | - | - | - | - | 6.7 | +33.8 | 0.0 | 0.0 |
| MISSILES NEXT TURN | - | - | - | - | 8.7 | +46.0 | 0.0 | 0.0 |
| MODEL FACING | 4.3 | +1622.8 | 0.0 | 20.0 | - | - | - | - |
| MOVE ORDER | 0.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 6.3 | +271.7 | 0.0 | 40.0 | 1.7 | +147.5 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 5.0 | +221.1 | 0.0 | 0.0 | 4.7 | +207.8 | 0.0 | 20.0 |
| NEXT CHARGE BY LIST | 2.3 | +96.6 | 0.0 | 0.0 | 1.7 | +147.5 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 1.0 | -8.1 | 33.7 | 0.0 | 1.7 | -40.8 | 0.0 | 0.0 |
| NO LATE CUT | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NO OLD ONE-MOVE GUESS | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | 0.3 | +0.0 | 0.0 | 39.0 | - | - | - | - |
| OFF BEST | 5.7 | -102.9 | 0.0 | 0.0 | 3.0 | -67.6 | 0.0 | 13.7 |
| OGRE LOADER SECOND SHOT | - | - | - | - | 2.7 | +13.0 | 0.0 | 55.0 |
| ONE CHECK AFTER THE LAST CHANGE | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 4.0 | -20.1 | 0.0 | 0.0 | 4.0 | -90.4 | 0.0 | 0.0 |
| ONE JOINT FIGURE | - | - | - | - | 0.3 | +2.3 | 77.7 | 0.0 |
| ONE OBJECTIVE FORMULA | 5.3 | -124.6 | 0.0 | 0.0 | 2.7 | -123.3 | 0.0 | 0.0 |
| ONE ROUTE | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| OVERRUNS AWAY | 0.3 | +0.5 | 20.0 | 0.0 | - | - | - | - |
| PIVOT GUARDS FLANK | - | - | - | - | 0.3 | -14.0 | 0.0 | 0.0 |
| PLAN RESULT | 62.7 | +501.7 | 299.0 | 353.3 | 31.3 | +83.5 | 272.0 | 284.7 |
| PROMISE BELOW ZERO | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE BY ITS OWN SUM | 9.7 | -235.0 | 0.0 | 40.0 | 4.3 | +0.0 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | 1.3 | -31.6 | 0.0 | 0.0 | 1.0 | -0.8 | 0.0 | 0.0 |
| QUARTER ODDS | 17.7 | +1088.6 | 0.0 | 60.0 | 2.0 | +689.1 | 0.0 | 0.0 |
| REAL GROUND | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| REDIRECT BY WHAT IT STOPS | - | - | - | - | 1.0 | +54.8 | 0.0 | 40.0 |
| REDIRECT COUNTER | 1.3 | +148.3 | 0.0 | 0.0 | 1.3 | -3.5 | 0.0 | 33.7 |
| REDIRECT FOR A FRIEND IN REACH | 0.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 13.7 |
| REDIRECT WEIGHED | - | - | - | - | 0.3 | -35.5 | 0.0 | 0.0 |
| REFORMS TO MEET IT | 0.7 | -9.9 | 0.0 | 0.0 | - | - | - | - |
| REFUSING RETIRES | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| RISK BY ARC | 1.3 | +32.7 | 33.7 | 20.0 | 1.3 | +84.2 | 0.0 | 16.7 |
| ROUNDS AFTER TERROR | - | - | - | - | 2.0 | -12.7 | 77.7 | 33.3 |
| RUN DOWN | 0.7 | -11.9 | 13.7 | 0.0 | 1.3 | -2.9 | 155.3 | 0.0 |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 0.7 | -100.9 | 0.0 | 0.0 |
| SEARCH SPOT | 0.7 | +11.1 | 0.0 | 0.0 | - | - | - | - |
| SET CREDITED ONCE | - | - | - | - | 2.7 | -72.1 | 0.0 | 0.0 |
| SET UP BY THE SET | - | - | - | - | 4.0 | +43.6 | 0.0 | 0.0 |
| SET UP TOGETHER | - | - | - | - | 1.3 | +57.8 | 0.0 | 0.0 |
| SHOOTER COUNTED ONCE | - | - | - | - | 0.7 | -1.0 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 2.0 | +4.0 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS ON THE TABLE | 23.7 | +0.0 | 0.0 | 194.3 | 6.3 | +0.0 | 0.0 | 110.0 |
| SHOOTS FROM THE BEST SPOT | 1.0 | +19.6 | 0.0 | 0.0 | - | - | - | - |
| SHORT GUN FORWARD | 2.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SHOT OR CHARGE | 0.7 | -10.7 | 13.7 | 0.0 | - | - | - | - |
| SHOT RISK POINTS | 31.7 | +1017.8 | 0.0 | 180.0 | 22.3 | -359.8 | 0.0 | 87.7 |
| SHOTS AFTER THE MOVES | 5.7 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 37.3 | +809.1 | 0.0 | 175.3 | 4.3 | +262.1 | 0.0 | 147.0 |
| SPELL WORTH | - | - | - | - | 6.0 | +144.9 | 0.0 | 0.0 |
| SPELLS IN THE FIGHT | - | - | - | - | 0.7 | +2.2 | 0.0 | 0.0 |
| SPOT AS THE GAME MOVES | 4.3 | +0.0 | 0.0 | 0.0 | 5.0 | +0.0 | 0.0 | 0.0 |
| STANDS FOR A REASON | - | - | - | - | 3.3 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 108.3 | +0.0 | 403.3 | 470.7 | 17.3 | +0.0 | 235.3 | 220.0 |
| STAY WORTH | 56.7 | +129.3 | 293.3 | 20.0 | 14.3 | +101.9 | 235.3 | 202.0 |
| STRIKE BY THE ODDS | 0.3 | +1.9 | 0.0 | 20.0 | - | - | - | - |
| SUPPORT ADDS | 1.0 | +22.1 | 0.0 | 0.0 | 1.0 | +3.1 | 0.0 | 0.0 |
| SUPPORT NARROWED | 0.3 | +0.0 | 20.0 | 0.0 | - | - | - | - |
| SUPPORT WORKED OUT | 1.0 | +22.1 | 0.0 | 0.0 | 1.0 | +3.1 | 0.0 | 0.0 |
| SURE REACH TOGETHER | - | - | - | - | 1.3 | +4.9 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 1.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 2.3 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 0.7 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 50.7 |
| THE STEP BACK IS MADE | 0.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 56.3 | +0.0 | 0.0 | 214.3 | 33.0 | +0.0 | 0.0 | 160.7 |
| TIED UP BY THE SUM | 0.7 | +18.4 | 13.7 | 0.0 | 0.7 | +44.0 | 0.0 | 0.0 |
| TIME ON OUR SIDE | 63.7 | +626.9 | 0.0 | 233.3 | - | - | - | - |
| WAITS AGAIN | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WHO FIGHTS | 0.7 | +4.8 | 13.7 | 20.0 | 1.0 | +17.0 | 0.0 | 0.0 |
| WHO HITS BACK | - | - | - | - | 0.3 | +12.7 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | 1.0 | -65.4 | 0.0 | 40.0 | 1.0 | -56.9 | 0.0 | 0.0 |
| WHOLE FIGHT GAIN | - | - | - | - | 0.3 | +77.0 | 77.7 | 0.0 |
| WOUNDS ON THE RANKS | 2.0 | +44.0 | 0.0 | 0.0 | 2.3 | +344.6 | 0.0 | 0.0 |

### Rule changes: cnomg-c940641-p4

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS MOVE AS HE DECIDES | 98 | 98 | 74 | 24.67 | +0 | +0.0 |
| HIS SHOT LIST | 265 | 261 | 72 | 24.00 | +2019 | +28.0 |
| HIS SHOTS BY HIS RUN | 216 | 207 | 54 | 18.00 | +663 | +12.3 |
| HOLDER ASSIGNMENT | 55 | 55 | 51 | 17.00 | +2952 | +57.9 |
| SHOT RISK POINTS | 162 | 159 | 35 | 11.67 | +1177 | +33.6 |
| TIME ON OUR SIDE | 191 | 177 | 35 | 11.67 | +149 | +4.3 |
| ARMY TABLE | 42 | 42 | 33 | 11.00 | +722 | +21.9 |
| DEPLOY BY FIGURES | 53 | 53 | 32 | 10.67 | +329 | +10.3 |
| OFF BEST | 26 | 26 | 26 | 8.67 | -511 | -19.7 |
| THE TABLE AGAIN | 36 | 36 | 21 | 7.00 | +0 | +0.0 |
| FIVE ACTION | 636 | 625 | 19 | 6.33 | +520 | +27.4 |
| HIS ONE MOVE | 54 | 52 | 18 | 6.00 | +0 | +0.0 |
| HARD STAY DROPPED | 16 | 16 | 16 | 5.33 | +0 | +0.0 |
| COVER ONCE | 49 | 43 | 15 | 5.00 | +151 | +10.0 |
| MOVE TO CHARGE COMPUTED | 24 | 22 | 15 | 5.00 | +335 | +22.4 |
| MEETS IN TIME | 35 | 35 | 14 | 4.67 | +462 | +33.0 |
| PROMISE BY ITS OWN SUM | 42 | 42 | 14 | 4.67 | -705 | -50.4 |
| CHARGE LOSSES | 81 | 80 | 13 | 4.33 | +432 | +33.2 |
| MODEL FACING | 13 | 13 | 13 | 4.33 | +4868 | +374.5 |
| CANNON PLANNED TARGET | 60 | 60 | 11 | 3.67 | +0 | +0.0 |
| IDLE COST | 47 | 38 | 11 | 3.67 | +365 | +33.2 |
| CANNON SIGHT KEPT | 10 | 10 | 10 | 3.33 | +0 | +0.0 |
| FOUR ROUNDS | 13 | 13 | 10 | 3.33 | +217 | +21.7 |
| SHOTS AFTER THE MOVES | 23 | 23 | 9 | 3.00 | +0 | +0.0 |
| OGRE LOADER SECOND SHOT | 8 | 8 | 8 | 2.67 | +39 | +4.9 |
| QUARTER ODDS | 59 | 57 | 8 | 2.67 | +659 | +82.4 |
| ARTILLERY RE-ROLL WEIGHED | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| SHOTS IN THE MOVE | 125 | 113 | 7 | 2.33 | +76 | +10.9 |
| CAST JOB | 12 | 12 | 6 | 2.00 | +15 | +2.5 |
| REDIRECT FOR A FRIEND IN REACH | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| RISK BY ARC | 8 | 8 | 6 | 2.00 | +58 | +9.7 |
| SHOOTERS IN TWO RANKS | 6 | 6 | 6 | 2.00 | +12 | +2.0 |
| SHORT GUN FORWARD | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| MOVE ORDER | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| WOUNDS ON THE RANKS | 13 | 13 | 5 | 1.67 | +107 | +21.3 |
| NEXT CHARGE BY LIST | 12 | 12 | 4 | 1.33 | +72 | +18.0 |
| TIED UP BY THE SUM | 4 | 4 | 4 | 1.33 | +57 | +14.3 |
| ADVANCE LANE KEPT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| EXACT ROUND | 7 | 7 | 3 | 1.00 | +1 | +0.3 |
| FALLS SHORT | 58 | 54 | 3 | 1.00 | +67 | +22.4 |
| GOAL WALK | 12 | 12 | 3 | 1.00 | +274 | +91.5 |
| GUN MASK | 8 | 8 | 3 | 1.00 | +81 | +26.9 |
| SHOOTS FROM THE BEST SPOT | 3 | 3 | 3 | 1.00 | +48 | +15.9 |
| STAY WORTH | 213 | 203 | 3 | 1.00 | +25 | +8.4 |
| WHO FIGHTS | 5 | 5 | 3 | 1.00 | +5 | +1.5 |
| HOLDS AMBUSHERS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| JOINT CHARGE NOW | 2 | 2 | 2 | 0.67 | -35 | -17.5 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| LANE BY FIGURES | 2 | 2 | 2 | 0.67 | +128 | +64.0 |
| MANOEUVRE | 11 | 11 | 2 | 0.67 | +20 | +9.8 |
| MARCH OF THE TABLE | 2 | 2 | 2 | 0.67 | -78 | -39.1 |
| MAX FOR POSITIONING | 9 | 7 | 2 | 0.67 | +4 | +2.0 |
| MISSILES IN THE MOVE | 20 | 18 | 2 | 0.67 | +7 | +3.3 |
| ONE FIGHT FORMULA | 24 | 17 | 2 | 0.67 | +7 | +3.4 |
| PROMISE READS THE TABLE | 7 | 7 | 2 | 0.67 | -71 | -35.6 |
| SET UP BY THE SET | 12 | 10 | 2 | 0.67 | +155 | +77.7 |
| SET UP TOGETHER | 4 | 4 | 2 | 0.67 | +48 | +24.1 |
| BEST PRIZE | 1 | 1 | 1 | 0.33 | -107 | -106.6 |
| CASTS FROM BEHIND | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CHAFF IN THE MOVE | 5 | 3 | 1 | 0.33 | +0 | +0.0 |
| CHAFF PASSED | 1 | 1 | 1 | 0.33 | -2 | -2.5 |
| CHALLENGE BY POINTS | 1 | 1 | 1 | 0.33 | +3 | +3.4 |
| FRIENDS SHOTS CHECKED | 1 | 1 | 1 | 0.33 | -2 | -1.8 |
| HIS CHARGE DENIED | 1 | 1 | 1 | 0.33 | +1 | +1.0 |
| HIS MOVE AND SHOT | 30 | 29 | 1 | 0.33 | +0 | +0.0 |
| KEEP FALLS | 1 | 1 | 1 | 0.33 | +5 | +5.2 |
| LEGAL CHARGES ONLY | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| LONG SHOT | 1 | 1 | 1 | 0.33 | +1 | +1.0 |
| MARCH BY THE SUM | 1 | 1 | 1 | 0.33 | +280 | +279.7 |
| MARCH CHECK | 1 | 1 | 1 | 0.33 | +32 | +32.4 |
| OVERRUNS AWAY | 1 | 1 | 1 | 0.33 | +1 | +1.0 |
| PIVOT GUARDS FLANK | 1 | 1 | 1 | 0.33 | -42 | -42.0 |
| REDIRECT BY WHAT IT STOPS | 3 | 3 | 1 | 0.33 | +0 | +0.0 |
| REDIRECT COUNTER | 8 | 6 | 1 | 0.33 | +68 | +68.2 |
| REDIRECT WEIGHED | 1 | 1 | 1 | 0.33 | +153 | +153.3 |
| SEARCH SPOT | 2 | 2 | 1 | 0.33 | +33 | +33.3 |
| SET CREDITED ONCE | 8 | 6 | 1 | 0.33 | +6 | +6.2 |
| STRIKE BY THE ODDS | 1 | 1 | 1 | 0.33 | +6 | +5.9 |
| SUPPORT NARROWED | 1 | 1 | 1 | 0.33 | -11 | -10.8 |
| SURE REACH TOGETHER | 4 | 4 | 1 | 0.33 | +0 | +0.0 |
| THE ROW IN ITS ORDER | 14 | 1 | 1 | 0.33 | +0 | +0.0 |
| WHO HITS BACK | 1 | 1 | 1 | 0.33 | +37 | +36.7 |
| WHOLE FIGHT GAIN | 1 | 1 | 1 | 0.33 | +51 | +51.2 |
| BACKUP TARGETS | 1 | not checked | - | - | - | - |
| CANNON PLAN MISSED | 4 | 4 | 0 | 0.00 | - | - |
| CARRIES OUT SET-UP | 1 | 1 | 0 | 0.00 | - | - |
| CHAMPION KNOWS CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| CHARACTER GUNS | 18 | 18 | 0 | 0.00 | - | - |
| CHARGE NOW FIRST | 4 | 4 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 48 | 48 | 0 | 0.00 | - | - |
| DEFENSIVE ARMY | 3 | 3 | 0 | 0.00 | - | - |
| DENIED BY THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 1 | 1 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 8 | 8 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 2 | 2 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 2 | 2 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 21 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 8 | 6 | 0 | 0.00 | - | - |
| GUN FIGURES | 6 | not checked | - | - | - | - |
| HE REFORMS ONCE FREED | 1 | 1 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 43 | 43 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 55 | 55 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 26 | 26 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 8 | 6 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 24 | 24 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 2 | 2 | 0 | 0.00 | - | - |
| HIS TURN RUN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 81 | 81 | 0 | 0.00 | - | - |
| HONEST WORTH | 10 | 10 | 0 | 0.00 | - | - |
| HUNT IN PAIRS | 2 | 2 | 0 | 0.00 | - | - |
| JOINT KNOWS CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 11 | 11 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 1 | not checked | - | - | - | - |
| LOST AFTER ESCAPE | 6 | 6 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 4 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 6 | 6 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 5 | 5 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 26 | 23 | 0 | 0.00 | - | - |
| NEARER NOT NEEDED | 29 | 25 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 8 | 8 | 0 | 0.00 | - | - |
| NO LATE CUT | 2 | 2 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 18 | 18 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT TURNED | 1 | 1 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 3 | not checked | - | - | - | - |
| ONE JOINT FIGURE | 1 | 1 | 0 | 0.00 | - | - |
| ONE OBJECTIVE FORMULA | 24 | 22 | 0 | 0.00 | - | - |
| ONE ROUTE | 5 | 5 | 0 | 0.00 | - | - |
| PLAN RESULT | 282 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 1 | 1 | 0 | 0.00 | - | - |
| REAL GROUND | 5 | 5 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 2 | 2 | 0 | 0.00 | - | - |
| REFUSING RETIRES | 1 | 1 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 6 | 6 | 0 | 0.00 | - | - |
| RUN DOWN | 6 | 6 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 2 | 2 | 0 | 0.00 | - | - |
| SHOOTER COUNTED ONCE | 2 | 2 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 90 | not checked | - | - | - | - |
| SHOT OR CHARGE | 2 | 2 | 0 | 0.00 | - | - |
| SPELL WORTH | 18 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 28 | 22 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 10 | 10 | 0 | 0.00 | - | - |
| STANDS STILL | 377 | 372 | 0 | 0.00 | - | - |
| SUPPORT ADDS | 6 | 6 | 0 | 0.00 | - | - |
| SUPPORT WORKED OUT | 6 | 6 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 6 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 15 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 4 | not checked | - | - | - | - |
| THE TABLE BINDS | 268 | not checked | - | - | - | - |
| WAITS AGAIN | 4 | 4 | 0 | 0.00 | - | - |
| WHOLE FIGHT DANGER | 6 | 6 | 0 | 0.00 | - | - |

### Off best figure: cnomg-c940641-p4

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 4.67 | 2.67 | 22.7 |
| PROMISE BY ITS OWN SUM | rule | 4.67 | - | 50.4 |
| HOLDER ASSIGNMENT | rule | 1.33 | 0.33 | 8.3 |
| ARMY TABLE | rule | 0.33 | 1.00 | 28.1 |
| MARCH OF THE TABLE | rule | - | 0.67 | 39.1 |
| AFTERMATH BAND | gate | 0.33 | - | 1.8 |
| BEST PRIZE | rule | - | 0.33 | 106.6 |
| CHAFF PASSED | rule | 0.33 | - | 2.5 |
| DEPLOY BY FIGURES | rule | 0.33 | - | 6.9 |
| FRIENDS SHOTS CHECKED | rule | 0.33 | - | 1.8 |
| JOINT CHARGE NOW | rule | - | 0.33 | 95.6 |
| LONE CHARACTER SAFE SPOT | gate | 0.33 | - | 7.5 |
| NO REASON | gate | - | 0.33 | 0.5 |
| PIVOT GUARDS FLANK | rule | - | 0.33 | 42.0 |
| PROMISE READS THE TABLE | rule | 0.33 | - | 80.3 |
| RULE SWITCHED OFF | gate | 0.33 | - | 1.9 |
| SUPPORT NARROWED | rule | 0.33 | - | 10.8 |

### Plans: cnomg-c940641-p4

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.0 | 33% | 33 | 36 | 109% |
| Mine | join | 1.7 | 80% | 84 | 0 | 0% |
| Mine | move | 40.7 | 99% | 1130 | 0 | 0% |
| Mine | shoot | 19.3 | 48% | 424 | 466 | 110% |
| Opponent | charge | 1.7 | 0% | 107 | 0 | 0% |
| Opponent | join | 1.0 | 100% | 54 | 0 | 0% |
| Opponent | move | 22.7 | 97% | 645 | 0 | 0% |
| Opponent | shoot | 5.3 | 44% | 231 | 84 | 36% |
| Opponent | support | 0.7 | 50% | 29 | 0 | 0% |

### Battle groups: cnomg-c940641-p4

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 1.3 | 25% | 100% | 0% | - | 0% | 0% | 0% | 100% | 0% |
| Opponent | REDIRECT COUNTER | 1.3 | 50% | 50% | 0% | - | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: cnomg-c940641-p4

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | 0 (1) | - | - | 0 (1) | - |
| Mine | Character | 13 | 2 (13) | 2 | 0 | 8 | 31% | 3.2 | 4 (6) | 0 (6) | 0 (1) | 3 (11) | 0 (2) |
| Mine | Clean-up | 4 | 18 (4) | 18 | 0 | 0 | 75% | 1.0 | 0 (1) | 0 (1) | 36 (2) | 18 (4) | - |
| Mine | Fast | 3 | 0 (3) | 0 | 0 | 0 | 0% | 1.7 | - | 0 (1) | 0 (2) | 0 (3) | - |
| Mine | Hammer | 4 | 134 (4) | 12 | 121 | 0 | 25% | 2.7 | 5 (1) | 224 (3) | - | 134 (4) | - |
| Mine | Shooter | 8 | 62 (8) | 3 | 59 | 23 | 12% | 2.1 | 16 (1) | 118 (4) | 9 (3) | 48 (6) | 98 (2) |
| Mine | War machine | 17 | 0 (17) | 0 | 0 | 7 | 18% | 1.4 | 0 (4) | 0 (9) | 0 (4) | 0 (3) | 0 (14) |
| Opponent | Chaff | 3 | 0 (3) | 0 | 0 | 63 | 67% | 4.0 | 0 (2) | - | 0 (1) | 0 (3) | - |
| Opponent | Character | 10 | 12 (10) | 12 | 0 | 2 | 30% | 3.9 | 0 (3) | 22 (5) | 14 (2) | 15 (9) | 0 (1) |
| Opponent | Clean-up | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Fast Hammer | 3 | 25 (3) | 0 | 25 | 0 | 67% | 6.0 | 0 (1) | 84 (1) | 0 (1) | 35 (2) | 0 (1) |
| Opponent | Holder | 6 | 76 (6) | 0 | 76 | 10 | 67% | 2.0 | 0 (1) | 89 (5) | - | 161 (3) | 0 (3) |
| Opponent | War machine | 2 | 36 (2) | 36 | 0 | 50 | 0% | 1.0 | - | 73 (1) | 0 (1) | - | 36 (2) |
| Opponent | Wizard | 2 | 0 (2) | 0 | 0 | 0 | 50% | 1.0 | 0 (1) | 0 (1) | - | 0 (2) | - |

### Charged fights: cnomg-c940641-p4

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Dwarfen Mountain Holds | 3 | 51 | 20 | 1.0 | 1.0 | 20 | 20 | +0 | 1 of 3 | 2 of 3 | - | +0 |
| Opponent | Grand Cathay | 1 | 120 | 233 | 1.0 | 2.0 | 233 | 0 | +233 | 1 of 1 | 1 of 1 | +233 | - |
| Opponent | Vampire Counts | 1 | 0 | 0 | 1.0 | 1.0 | 0 | 50 | -50 | 1 of 1 | 0 of 1 | - | -50 |
| Opponent | Warriors of Chaos | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| **Opponent** | all armies | 3 | 40 | 78 | 0.7 | 1.5 | 116 | 25 | +92 | 2 of 2 | 1 of 2 | +233 | -50 |

### Effective charges: cnomg-c940641-p4

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Dwarfen Mountain Holds | 3 | 1 (net -60) | 0 | 0 | 0 | 0 | 2 (net +30) | 0 | 0% (0 of 3) |
| Opponent | Grand Cathay | 1 | 0 | 0 | 0 | 0 | 1 (net +233) | 0 | 0 | 0% (0 of 1) |

### Charged fights, damage counted: cnomg-c940641-p4

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 1 | 60 | 494 | -60 | 0 | 60 | -60 | -100.0 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 55 | 86 | +30 | 58 | 0 | +58 | +105.0 |
| Mine | All fights | 3 | 57 | 222 | +0 | 38 | 20 | +18 | +32.6 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 596 | 183 | +233 | 233 | 98 | +135 | +22.7 |
| Opponent | No odds | 1 | 50 | 239 | -50 | 0 | 109 | -109 | -217.5 |
| Opponent | All fights | 2 | 323 | 211 | +92 | 116 | 103 | +13 | +4.1 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| cnomg-c940641-p4 | move | 17 | 4 (24%) | 1 (6%) | 0 (0%) | 13 (76%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L0524 |
| Clockwork Compass | Opponent | L0612 |
| Invocation of Nehek | Opponent | L0524 |
| Ring of Doom | Opponent | L0612 |
| Ring of Jet | Opponent | L0612 |

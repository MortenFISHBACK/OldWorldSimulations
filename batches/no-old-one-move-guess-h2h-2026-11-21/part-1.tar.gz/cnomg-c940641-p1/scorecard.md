# Doctrine scorecard: cnomg-c940641-p1

### Scorecard: cnomg-c940641-p1

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0102 | 6 | 1 | Mine | no | 2 | - | 0 | 0 | 0 | 0 | 0 | 55 |
| L0102 | 6 | 1 | Opponent | no | 0 | 2 | 0 | 6 | 0 | 0 | 0 | 170 |
| L0118 | 4 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 0 |
| L0118 | 4 | 1 | Opponent | no | 0 | 4 | 2 | 5 | 0 | 0 | 0 | 0 |
| L0135 | 3 | 1 | Mine | no | 12 | - | 0 | 3 | 0 | 0 | 0 | 0 |
| L0135 | 3 | 1 | Opponent | no | 4 | 2 | 1 | 7 | 0 | 0 | 0 | 224 |
| **Average** | | | Mine | 0% | 4.7 | - | 0.0 | 1.3 | 0.0 | 0.0 | 0.0 | 18.3 |
| **Average** | | | Opponent | 0% | 1.3 | 2.7 | 1.0 | 6.0 | 0.0 | 0.0 | 0.0 | 131.3 |

### KPIs: cnomg-c940641-p1

Rules off - Mine only: NO OLD ONE-MOVE GUESS.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 5) | 0% (0 of 14) | 0% (0 of 19) |
| Winner chose to follow up after the loser gave ground |  | - | - | - |
| Winner chose to pursue after the loser fell back in good order |  | - | - | - |
| Winner chose to pursue after the loser fled |  | - | 67% (2 of 3); on the table 67% | 67% (2 of 3); on the table 67% |
| Winner chose to follow up or pursue (all three) |  | - | 67% (2 of 3); on the table 67% | 67% (2 of 3); on the table 67% |
| Magic missiles tried each own turn | 50%+ | 33% (30 of 90) | 12% (3 of 24) | 29% (33 of 114) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 37% (30 of 81) | 12% (3 of 24) | 31% (33 of 105) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 100% (6 of 6) | 100% (6 of 6) |
| Points that never fought | lower | 53% (3041 of 5700) | 82% (4860 of 5899) | 68% (7901 of 11599) |
|   infantry points that never fought | lower | 58% (1562 of 2703) | 100% (1219 of 1219) | 71% (2781 of 3922) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 47% (7 of 15) | 76% (19 of 25) | 65% (26 of 40) |
| Bound items with a magic missile used (at least once a game) |  | 100% (3 of 3); 3.0 uses a game | 75% (3 of 4); 2.0 uses a game | 86% (6 of 7); 2.5 uses a game |
| Bound items with another spell used |  | 100% (3 of 3); 1.0 uses a game | 0.0 uses a game | 100% (3 of 3); 0.5 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 100% (3 of 3); 1.0 uses a game | 50% (1 of 2); 0.3 uses a game | 80% (4 of 5); 0.7 uses a game |
|   their share of the points of units over 100 pts | lower | 50% (2029 of 4077) | 69% (3393 of 4883) | 61% (5422 of 8960) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 12.0 (60%) | 3.7 (52%) | 15.7 (58%) |
| MARCHED: its unit marched | 1.7 (8%) | 3.3 (48%) | 5.0 (19%) |
| REAR RANK: in a rear rank | 0.7 (3%) | 0.0 (0%) | 0.7 (2%) |
| OFF THE TABLE: off the table or not arrived | 3.0 (15%) | 0.0 (0%) | 3.0 (11%) |
| STUPIDITY: Stupidity | 2.0 (10%) | 0.0 (0%) | 2.0 (7%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.7 (3%) | 0.0 (0%) | 0.7 (2%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 9.0 | 2.7 | 7.3 | 11.0 | 0.3 |
| not cast | 9.0 | 7.3 | 8.7 | 27.0 | 43.7 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.3 (3%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 4.7 (64%) | 1.0 (12%) | 15.7 (58%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 5.0 (19%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (2%) | 0.0 (0%) |
| OFF THE TABLE: off the table or not arrived | 1.0 (11%) | 1.0 (14%) | 1.0 (12%) | 3.0 (11%) | 3.7 (8%) |
| STUPIDITY: Stupidity | 1.0 (11%) | 0.0 (0%) | 2.0 (23%) | 2.0 (7%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (2%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 7.0 (78%) | 1.7 (23%) | 4.7 (54%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 38.7 (89%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 7.0 a game | 1.3 a game | 4.2 a game |
| stood (cast and not dispelled) | 67% (14 of 21) | 100% (4 of 4) | 72% (18 of 25) |
| the unit moved after it | 71% (10 of 14) | 50% (2 of 4) | 67% (12 of 18) |
| it charged on its next turn | 0% (0 of 14) | 0% (0 of 4) | 0% (0 of 18) |
| the enemy charged it first | 0% (0 of 14) | 0% (0 of 4) | 0% (0 of 18) |
| it fought by the end of its next turn | 0% (0 of 14) | 0% (0 of 4) | 0% (0 of 18) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 14) | 0% (0 of 4) | 0% (0 of 18) |
| none of these (no charge, no fight, no charge escaped) | 100% (14 of 14) | 100% (4 of 4) | 100% (18 of 18) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 52% (15 of 29) | 45% (32 of 71) | 47% (47 of 100) |
|   cavalry | - | 42% (5 of 12) | 42% (5 of 12) |
|   character | - | 73% (8 of 11) | 73% (8 of 11) |
|   chariot | - | 42% (5 of 12) | 42% (5 of 12) |
|   infantry | 52% (15 of 29) | 25% (6 of 24) | 40% (21 of 53) |
|   monster | - | 67% (8 of 12) | 67% (8 of 12) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.7 (36%) | 2.0 (15%) | 3.7 (21%) |
| CHARGED: it charged | 0.0 (0%) | 1.0 (8%) | 1.0 (6%) |
| FLEEING: it fled or was fleeing | 1.0 (21%) | 0.0 (0%) | 1.0 (6%) |
| IN COMBAT: it fought this turn or the last | 0.3 (7%) | 0.0 (0%) | 0.3 (2%) |
| NO TARGET IN RANGE | 0.3 (7%) | 6.3 (49%) | 6.7 (38%) |
| ONLY IN COMBAT: the only targets were in combat | 0.0 (0%) | 0.3 (3%) | 0.3 (2%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.7 (14%) | 1.3 (10%) | 2.0 (11%) |
| SHELTERED: the target was sheltered | 0.7 (14%) | 1.3 (10%) | 2.0 (11%) |
| OTHER BAR | 0.0 (0%) | 0.7 (5%) | 0.7 (4%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 3.0 | 1.0 | 67% | 2.6 pts | 8 pts |
| character | 2.7 | 1.7 | 62% | 4.9 pts | 13 pts |
| chariot | 1.7 | 1.0 | 80% | 4.6 pts | 8 pts |
| infantry | 7.0 | 2.3 | 76% | 4.8 pts | 34 pts |
| monster | 2.7 | 0.3 | 88% | 1.0 pts | 3 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 0.0 | 1.7 | 0.8 |
| Charges that made contact a game | 0.0 | 1.3 | 0.7 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | - | - | - |
|   per unit a game, units carrying another wizard (or one alone) | - | - | - |
|   per unit a game, the other units (no war machines, no joined characters) | 0.00 declared, 0.00 contact (15 units) | 0.16 declared, 0.12 contact (32 units) | 0.11 declared, 0.09 contact (47 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 67% (2 of 3) | - | - | 67% (2 of 3) |
| Character in a unit | 50% (2 of 4) | 78% (7 of 9) | - | 69% (9 of 13) |
| Character on its own | 100% (1 of 1) | 100% (2 of 2) | 0% (0 of 1) | 75% (3 of 4) |
| Chariot | 100% (2 of 2) | - | - | 100% (2 of 2) |
| Infantry | 80% (4 of 5) | 29% (2 of 7) | - | 50% (6 of 12) |
| Monster | 0% (0 of 1) | 100% (1 of 1) | - | 50% (1 of 2) |
| Monstrous | 100% (2 of 2) | 50% (1 of 2) | - | 75% (3 of 4) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 100% (2 of 2); on the table 100% | 29% (31 of 108) | 62% | 52% (11 of 21) | 100% (5 of 5); 3.5 uses a game | 100% (3 of 3); 0.8 uses a game | 80% (4 of 5); 1.0 uses a game |
| Ogre Kingdoms | 1 | - | - | 86% | 86% (6 of 7) | 100% (1 of 1); 1.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 1 | 0% (0 of 1); on the table 0% | 33% (2 of 6) | 75% | 75% (9 of 12) | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (cnomg-c940641-p1, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 33% (1) | - | 33% (1) |
| ...free all their last turn and able to turn (per game) | 0.33 | 0.00 | 0.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.33 | 0.00 | 0.33 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: cnomg-c940641-p1

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 0.0 | 1.7 |
| Strategy | Charge objectives carried out (made contact) | - | 67% (2 of 3) |
| Strategy | Shoot objectives carried out (shot that target) | 26% (5 of 19) | 30% (6 of 20) |
| Strategy | Hexes on a unit its side charged or shot that turn | 0% (0 of 2) | 80% (4 of 5) |
| Strategy | Joined characters whose unit fought | 40% (6 of 15) | 0% (0 of 7) |
| Strategy | Lone characters that fought | 100% (3 of 3) | 33% (1 of 3) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 1.3 | 6.0 |
| Movement | Points that never moved of their own | 18.3 | 131.3 |
| Movement | Fights charged into per game | 0.0 | 1.3 |
| Movement | Charges with odds: long shots (under 50%) | - | 0 of 3 |
| Movement | Charges with odds: sweet spot (55-75%) | - | 0 of 3 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | - | 1 of 3, net +55 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | - | 2 of 3, net +431 |
| Shooting | Shots by shooting units (incl. breath weapons) | 5.0 | 11.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 73% (11 of 15) | 58% (19 of 33) |
| Shooting | Points destroyed by shooting units | 0.0 | 0.0 |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | 8.0 | 1.0 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 8% (2 of 24) | 0% (0 of 3) |
| Magic | Wounds caused by magic missiles | 20.7 | 3.0 |
| Magic | Points destroyed by magic (all spells) | 239.3 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 6.3 / 0.7 / 0.0 / 0.0 | 2.0 / 1.7 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 11.3 | 0.0 |
| Combat | Points run down | 0.0 | 40.0 |
| Combat | Net points per charged fight, damage counted | - | +210 |
| Combat | Net per 100 charger points, damage counted | - | +96.5 |
| Combat | First round won (charged fights) | - | 75% |
| Combat | Net points per charged fight | - | +221 |
| Combat | Net points per supported fight / lone fight | - / - | - / +221 |
| Combat | Charged fights on a top-3 enemy unit | - | 2 of 4 |
| Game | Points lost | 369.0 | 287.3 |
| Game | VP from objectives | 790.0 | 820.0 |
| Game | Lone holders (player turns) | 4.7 | 1.3 |

- Mine won / drew / lost: 1 / 1 / 1 of 3 ended games (of 3); mean margin (Mine - Opponent) -139 VP
- The side that went first won 2 of 2 games with a winner
- Points traded per game (both sides' losses): 656
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: cnomg-c940641-p1

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 36.7 |
| ARMY TABLE | 9.0 | +197.5 | 0.0 | 61.7 | 21.7 | -38.5 | 0.0 | 0.0 |
| CAST JOB | - | - | - | - | 3.3 | +41.1 | 429.3 | 0.0 |
| CASTER AWAY FROM SCREEN | 1.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 6.0 | +568.9 | 70.0 | 214.7 | 1.3 | +25.8 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 4.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | 2.3 | +33.2 | 0.0 | 55.0 | 0.7 | +16.0 | 0.0 | 20.0 |
| CHAFF PASSED | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| CHARGE LOSSES | 11.7 | -276.4 | 0.0 | 86.7 | 9.3 | -524.7 | 0.0 | 193.0 |
| CHARGE NOW FIRST | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 125.7 | 0.0 |
| CLOSES ON WHAT IT BEATS | 1.3 | +0.0 | 0.0 | 0.0 | 12.0 | +0.0 | 0.0 | 117.3 |
| CONVEYANCE SEARCH | 5.3 | +746.6 | 107.3 | 118.3 | 1.3 | +43.1 | 0.0 | 0.0 |
| COVER ONCE | 2.3 | -85.9 | 0.0 | 129.0 | 4.7 | -228.6 | 0.0 | 34.0 |
| DENIED BY THE FIGHT | - | - | - | - | 0.3 | -63.5 | 107.3 | 0.0 |
| DEPLOY BY FIGURES | 5.0 | +41.5 | 0.0 | 0.0 | 10.0 | -145.9 | 0.0 | 74.7 |
| EVASIVE BY THE ODDS | - | - | - | - | 0.7 | +8.8 | 0.0 | 0.0 |
| EXACT ROUND | - | - | - | - | 0.7 | +5.0 | 36.7 | 0.0 |
| FALL BACK GOOD ORDER | - | - | - | - | 1.0 | +2.8 | 125.7 | 0.0 |
| FALLS SHORT | 4.7 | +128.2 | 0.0 | 107.3 | 13.0 | +234.3 | 0.0 | 0.0 |
| FEATURE BUFFS | 13.0 | +588.0 | 0.0 | 123.3 | - | - | - | - |
| FIGHT TO THE END | - | - | - | - | 0.3 | +0.6 | 107.3 | 0.0 |
| FIVE ACTION | 49.7 | +7600.6 | 87.3 | 411.3 | 100.3 | +4305.5 | 1128.3 | 416.7 |
| FLANK NOT WEIGHED | 2.0 | +0.0 | 0.0 | 107.3 | 3.7 | +0.0 | 0.0 | 10.0 |
| FOUR ROUNDS | - | - | - | - | 1.3 | +44.0 | 144.0 | 0.0 |
| FRIEND SHOOTS FIRST | - | - | - | - | 0.7 | -3.1 | 0.0 | 0.0 |
| GIVES UP | - | - | - | - | 0.3 | -2.8 | 0.0 | 0.0 |
| GOAL WALK | 4.7 | +622.0 | 0.0 | 0.0 | 0.3 | +3.8 | 0.0 | 0.0 |
| GROUND FLIERS | - | - | - | - | 0.3 | +6.1 | 0.0 | 0.0 |
| GUN FIGURES | - | - | - | - | 1.7 | +0.0 | 107.3 | 0.0 |
| HARD STAY DROPPED | 0.3 | +0.0 | 0.0 | 107.3 | 5.7 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 5.0 | +0.0 | 0.0 | 86.7 | 5.7 | +0.0 | 0.0 | 159.0 |
| HIS CHARGE LIST | - | - | - | - | 3.7 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 2.7 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 3.7 | -31.1 | 0.0 | 0.0 | 2.3 | -71.8 | 0.0 | 56.7 |
| HIS MOVE AS HE DECIDES | 48.0 | +16.7 | 322.7 | 0.0 | - | - | - | - |
| HIS MOVE WHY | - | - | - | - | 21.3 | +0.0 | 0.0 | 22.7 |
| HIS ONE MOVE | 13.7 | -27.9 | 0.0 | 0.0 | - | - | - | - |
| HIS ONE QUARTER | 3.0 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 1.7 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVE | 6.0 | +0.0 | 0.0 | 86.7 | - | - | - | - |
| HIS RANDOM MOVER COMES | 2.7 | +0.0 | 0.0 | 86.7 | - | - | - | - |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 27.0 | +391.5 | 0.0 | 55.0 | 47.3 | +2124.0 | 0.0 | 208.7 |
| HIS SHOTS BY HIS RUN | 30.7 | +334.3 | 0.0 | 178.3 | 34.0 | +860.5 | 0.0 | 394.0 |
| HIS TURN DENIED | - | - | - | - | 0.3 | +14.7 | 107.3 | 0.0 |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 36.0 | +0.0 | 0.0 | 225.0 | 12.3 | +0.0 | 0.0 | 0.0 |
| HOLDER ASSIGNMENT | 16.3 | +1684.9 | 0.0 | 43.3 | 10.0 | +1299.2 | 0.0 | 38.0 |
| HOLDS AMBUSHERS | 1.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | - | - | - | - | 1.0 | -37.4 | 36.7 | 0.0 |
| IDLE COST | 1.3 | -6.3 | 0.0 | 0.0 | 22.0 | -216.5 | 0.0 | 202.7 |
| KEPT FROM ITS LAST STOP | 2.7 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | - | - | - | - | 0.3 | +0.6 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 12.7 | +0.0 | 87.0 | 281.7 | - | - | - | - |
| LONE WIZARD KEPT IN | 3.0 | +270.0 | 0.0 | 0.0 | 0.7 | +87.5 | 0.0 | 0.0 |
| LONG SHOT | - | - | - | - | 0.3 | -3.6 | 107.3 | 0.0 |
| LOST AFTER ESCAPE | - | - | - | - | 0.7 | +0.3 | 107.3 | 0.0 |
| MANOEUVRE | 1.0 | -0.2 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MARCH BY THE SUM | 0.7 | +63.8 | 0.0 | 0.0 | 0.7 | +113.4 | 0.0 | 0.0 |
| MARCH CHECK | 0.3 | +14.8 | 0.0 | 0.0 | 1.3 | +114.9 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MAX FOR POSITIONING | 1.3 | +40.0 | 0.0 | 18.3 | 0.3 | +0.5 | 0.0 | 0.0 |
| MEETS IN TIME | 1.7 | +224.8 | 0.0 | 0.0 | 7.7 | +309.7 | 0.0 | 74.7 |
| MISSILES IN THE MOVE | 8.7 | +585.3 | 0.0 | 107.3 | 6.3 | +89.0 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 8.0 | +420.6 | 0.0 | 107.3 | 6.3 | +56.6 | 0.0 | 0.0 |
| MISSILES ON ONE TARGET | 2.3 | -76.2 | 0.0 | 107.3 | - | - | - | - |
| MOVE ORDER | 0.7 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 11.3 |
| MOVE SPELL OUT OF RANGE | 1.3 | -61.7 | 0.0 | 118.3 | - | - | - | - |
| MOVE SPELL SPOT | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | - | - | - | - | 3.0 | +137.6 | 0.0 | 0.0 |
| MOVES UNITS SPELL | - | - | - | - | 0.3 | +18.4 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 6.0 | +275.6 | 0.0 | 43.3 | 2.7 | +143.7 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | - | - | - | - | 2.0 | +95.3 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | - | - | - | - | 1.3 | -39.1 | 144.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 2.0 | -3.4 | 0.0 | 118.3 | 2.0 | -3.1 | 0.0 | 0.0 |
| OFF BEST | 2.0 | -40.9 | 0.0 | 18.3 | 2.7 | -43.8 | 0.0 | 0.0 |
| ONE CHECK AFTER THE LAST CHANGE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ONE FIGHT FORMULA | 2.7 | -37.4 | 0.0 | 36.7 | 3.0 | -47.5 | 0.0 | 0.0 |
| ONE OBJECTIVE FORMULA | 8.3 | +156.8 | 0.0 | 43.3 | 1.7 | +95.0 | 0.0 | 0.0 |
| ONE PROMISE A TARGET | - | - | - | - | 0.3 | -9.1 | 0.0 | 0.0 |
| ONE ROUTE | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| OPENS A LANE | 0.3 | +0.3 | 41.7 | 0.0 | - | - | - | - |
| OPENS UP | - | - | - | - | 0.7 | +113.6 | 18.3 | 0.0 |
| OVERRUNS AWAY | - | - | - | - | 0.3 | +21.1 | 18.3 | 0.0 |
| PLAN RESULT | 22.0 | +136.9 | 0.0 | 356.3 | 44.3 | +411.8 | 451.0 | 334.0 |
| PROMISE BY ITS OWN SUM | - | - | - | - | 3.3 | -33.7 | 0.0 | 0.0 |
| PROMISE IN STEPS | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | - | - | - | - | 0.3 | -1.0 | 0.0 | 0.0 |
| QUARTER ODDS | 12.0 | +1925.2 | 0.0 | 0.0 | 22.7 | +2186.3 | 0.0 | 0.0 |
| RANDOM MOVE BY FIGURES | - | - | - | - | 2.0 | +184.7 | 0.0 | 0.0 |
| REAL GROUND | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| REDIRECT COUNTER | 1.3 | +108.0 | 0.0 | 0.0 | 3.0 | +53.6 | 0.0 | 11.3 |
| REDIRECT FOR A FRIEND IN REACH | 3.0 | +0.0 | 0.0 | 73.3 | 3.3 | +0.0 | 0.0 | 79.3 |
| REDIRECT WEIGHED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| REFORMS TO MEET IT | - | - | - | - | 1.3 | -27.5 | 0.0 | 0.0 |
| RESERVE FALL BACK | - | - | - | - | 0.3 | +13.2 | 0.0 | 0.0 |
| RESERVE MOVE SPELL | 1.0 | +26.2 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | - | - | - | - | 1.3 | -33.5 | 144.0 | 0.0 |
| ROUNDS AFTER TERROR | - | - | - | - | 0.3 | -2.3 | 0.0 | 0.0 |
| RUN DOWN | - | - | - | - | 1.0 | -12.1 | 125.7 | 0.0 |
| SCOUT SPOT | 1.0 | +1.2 | 0.0 | 0.0 | 0.7 | +2.1 | 0.0 | 0.0 |
| SCOUT WAITS | 1.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 1.3 | -220.6 | 0.0 | 36.7 | 0.7 | -0.7 | 0.0 | 20.0 |
| SEARCH SPOT | 0.3 | +5.8 | 0.0 | 0.0 | 0.3 | +1.9 | 0.0 | 0.0 |
| SET CREDITED ONCE | - | - | - | - | 0.7 | -88.3 | 0.0 | 0.0 |
| SET UP BY THE SET | - | - | - | - | 1.0 | +35.3 | 18.3 | 0.0 |
| SET-UP ANY TARGET | 0.7 | +50.4 | 0.0 | 0.0 | 0.3 | +45.9 | 0.0 | 0.0 |
| SHOOTER COUNTED ONCE | 0.7 | -2.1 | 0.0 | 36.7 | 0.7 | -1.3 | 0.0 | 20.0 |
| SHOOTERS IN TWO RANKS | - | - | - | - | 0.3 | +0.3 | 0.0 | 36.7 |
| SHOOTERS ON THE TABLE | 6.0 | +0.0 | 0.0 | 125.7 | 6.3 | +0.0 | 0.0 | 10.0 |
| SHOOTS FROM THE BEST SPOT | 2.3 | +72.5 | 17.3 | 0.0 | - | - | - | - |
| SHOT OR CHARGE | - | - | - | - | 0.7 | -11.4 | 125.7 | 0.0 |
| SHOT RISK POINTS | 17.0 | -174.6 | 0.0 | 120.0 | 42.3 | +255.7 | 0.0 | 416.7 |
| SHOTS AFTER THE MOVES | 2.0 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 5.7 | +137.9 | 0.0 | 43.3 | 13.0 | +121.9 | 0.0 | 0.0 |
| SPELL SETS UP CHARGE | 0.7 | +50.4 | 0.0 | 0.0 | 0.3 | +45.9 | 0.0 | 0.0 |
| SPELL WORTH | 2.0 | +4.9 | 68.0 | 0.0 | 2.0 | +9.1 | 0.0 | 0.0 |
| SPOT AS THE GAME MOVES | 4.7 | +0.0 | 0.0 | 36.7 | 3.7 | +0.0 | 0.0 | 62.3 |
| STANDS FOR A REASON | - | - | - | - | 5.0 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 17.3 | +0.0 | 87.3 | 288.0 | 40.0 | +0.0 | 984.3 | 11.3 |
| STAY WORTH | 9.0 | +98.6 | 0.0 | 0.0 | 17.7 | +79.5 | 984.3 | 0.0 |
| SUPPORT ADDS | 3.3 | +236.9 | 0.0 | 0.0 | - | - | - | - |
| SUPPORT WORKED OUT | 3.3 | +236.9 | 0.0 | 0.0 | - | - | - | - |
| THE DEARER SUM KEEPS ITS PLAN | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| THE PROMISE ADDS | - | - | - | - | 0.3 | -2.1 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 0.7 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 34.0 |
| THE ROW KEEPS ITS WAY | 1.3 | +0.0 | 0.0 | 0.0 | 6.3 | +0.0 | 0.0 | 87.3 |
| THE STEP BACK IS MADE | 1.3 | +0.0 | 0.0 | 0.0 | 5.0 | +0.0 | 0.0 | 45.7 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 24.7 | +0.0 | 0.0 | 224.0 | 48.3 | +0.0 | 0.0 | 212.7 |
| TIED UP BY THE SUM | - | - | - | - | 1.0 | +94.6 | 36.7 | 0.0 |
| TIME ON OUR SIDE | 17.3 | +472.9 | 0.0 | 171.7 | 21.7 | +151.7 | 966.0 | 11.3 |
| WAITS AGAIN | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | 3.3 | -143.3 | 0.0 | 86.7 | - | - | - | - |
| WOUNDS ON THE RANKS | 6.0 | +118.3 | 0.0 | 0.0 | 0.3 | +46.0 | 0.0 | 0.0 |

### Rule changes: cnomg-c940641-p1

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS MOVE AS HE DECIDES | 144 | 144 | 94 | 31.33 | +0 | +0.0 |
| HOLDER ASSIGNMENT | 79 | 79 | 71 | 23.67 | +4405 | +62.0 |
| HIS SHOT LIST | 223 | 221 | 67 | 22.33 | +727 | +10.8 |
| HIS SHOTS BY HIS RUN | 194 | 190 | 49 | 16.33 | +427 | +8.7 |
| ARMY TABLE | 92 | 92 | 47 | 15.67 | +22 | +0.5 |
| LEGAL CHARGES ONLY | 38 | 38 | 38 | 12.67 | +0 | +0.0 |
| SHOT RISK POINTS | 178 | 177 | 36 | 12.00 | +538 | +14.9 |
| DEPLOY BY FIGURES | 45 | 45 | 30 | 10.00 | +432 | +14.4 |
| HIS MOVE WHY | 64 | 64 | 29 | 9.67 | +0 | +0.0 |
| CASTING BLOCK | 22 | 22 | 22 | 7.33 | +729 | +33.1 |
| THE TABLE AGAIN | 36 | 36 | 21 | 7.00 | +0 | +0.0 |
| REDIRECT FOR A FRIEND IN REACH | 19 | 19 | 19 | 6.33 | +0 | +0.0 |
| TIME ON OUR SIDE | 117 | 108 | 19 | 6.33 | +114 | +6.0 |
| HARD STAY DROPPED | 18 | 18 | 18 | 6.00 | +0 | +0.0 |
| HIS ONE MOVE | 41 | 41 | 18 | 6.00 | +0 | +0.0 |
| QUARTER ODDS | 104 | 101 | 16 | 5.33 | +1654 | +103.4 |
| MEETS IN TIME | 28 | 28 | 14 | 4.67 | +257 | +18.3 |
| OFF BEST | 14 | 14 | 14 | 4.67 | -254 | -18.1 |
| FEATURE BUFFS | 39 | 39 | 12 | 4.00 | +284 | +23.7 |
| LONE WIZARD KEPT IN | 11 | 11 | 11 | 3.67 | +1073 | +97.5 |
| FIVE ACTION | 450 | 446 | 10 | 3.33 | +854 | +85.3 |
| CASTER AWAY FROM SCREEN | 8 | 8 | 8 | 2.67 | +0 | +0.0 |
| FALLS SHORT | 53 | 44 | 8 | 2.67 | +170 | +21.3 |
| IDLE COST | 70 | 58 | 8 | 2.67 | +82 | +10.3 |
| MOVE ORDER | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| SUPPORT ADDS | 10 | 10 | 7 | 2.33 | +157 | +22.4 |
| SUPPORT WORKED OUT | 10 | 10 | 7 | 2.33 | +157 | +22.4 |
| WOUNDS ON THE RANKS | 19 | 19 | 7 | 2.33 | +150 | +21.4 |
| CAST JOB | 10 | 10 | 6 | 2.00 | +35 | +5.8 |
| CHAFF IN THE MOVE | 9 | 7 | 6 | 2.00 | +19 | +3.2 |
| GOAL WALK | 15 | 15 | 6 | 2.00 | +1220 | +203.2 |
| RANDOM MOVE BY FIGURES | 6 | 6 | 6 | 2.00 | +554 | +92.3 |
| SCOUT WAITS | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| ADVANCE LANE KEPT | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| HOLDS AMBUSHERS | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| MOVE TO CHARGE COMPUTED | 9 | 7 | 5 | 1.67 | +183 | +36.7 |
| SHOOTS FROM THE BEST SPOT | 7 | 7 | 5 | 1.67 | +37 | +7.4 |
| STAY WORTH | 80 | 68 | 5 | 1.67 | +56 | +11.2 |
| MARCH BY THE SUM | 4 | 4 | 4 | 1.33 | +532 | +132.9 |
| MARCH CHECK | 5 | 5 | 4 | 1.33 | +64 | +15.9 |
| NEXT CHARGE BY LIST | 6 | 5 | 4 | 1.33 | +98 | +24.4 |
| REDIRECT COUNTER | 13 | 11 | 4 | 1.33 | +110 | +27.4 |
| CHAFF PASSED | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| CHARGE LOSSES | 63 | 62 | 3 | 1.00 | +87 | +28.9 |
| MISSILES IN THE MOVE | 45 | 31 | 3 | 1.00 | +188 | +62.8 |
| RESERVE MOVE SPELL | 3 | 3 | 3 | 1.00 | +78 | +26.2 |
| COVER ONCE | 21 | 14 | 2 | 0.67 | +0 | +0.0 |
| MAX FOR POSITIONING | 5 | 5 | 2 | 0.67 | +4 | +1.8 |
| MISSILES NEXT TURN | 43 | 30 | 2 | 0.67 | +74 | +37.1 |
| PROMISE BY ITS OWN SUM | 10 | 10 | 2 | 0.67 | -101 | -50.4 |
| SEARCH SPOT | 2 | 2 | 2 | 0.67 | +23 | +11.6 |
| SHOTS AFTER THE MOVES | 14 | 14 | 2 | 0.67 | +0 | +0.0 |
| SHOTS IN THE MOVE | 56 | 33 | 2 | 0.67 | +20 | +10.2 |
| LANE BY FIGURES | 1 | 1 | 1 | 0.33 | +2 | +1.7 |
| MOVES UNITS SPELL | 1 | 1 | 1 | 0.33 | +55 | +55.1 |
| NEARER NOT NEEDED | 26 | 22 | 1 | 0.33 | +22 | +22.2 |
| ONE OBJECTIVE FORMULA | 30 | 16 | 1 | 0.33 | +58 | +57.7 |
| ONE PROMISE A TARGET | 1 | 1 | 1 | 0.33 | -27 | -27.3 |
| OPENS UP | 2 | 2 | 1 | 0.33 | +182 | +181.9 |
| OVERRUNS AWAY | 1 | 1 | 1 | 0.33 | +32 | +32.3 |
| REDIRECT WEIGHED | 1 | 1 | 1 | 0.33 | +237 | +236.8 |
| RESERVE FALL BACK | 1 | 1 | 1 | 0.33 | +40 | +39.5 |
| SHOOTERS IN TWO RANKS | 1 | 1 | 1 | 0.33 | +1 | +1.0 |
| TIED UP BY THE SUM | 3 | 3 | 1 | 0.33 | +41 | +41.4 |
| WHOLE FIGHT DANGER | 10 | 10 | 1 | 0.33 | +22 | +22.1 |
| CASTS AFTER FRIENDS | 17 | trace | - | - | - | - |
| CHARGE NOW FIRST | 4 | 4 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 40 | 40 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 20 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| EVASIVE BY THE ODDS | 2 | 2 | 0 | 0.00 | - | - |
| EXACT ROUND | 2 | 2 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 3 | 3 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 1 | 1 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 17 | not checked | - | - | - | - |
| FOUR ROUNDS | 4 | 4 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 2 | 2 | 0 | 0.00 | - | - |
| GIVES UP | 1 | 1 | 0 | 0.00 | - | - |
| GROUND FLIERS | 1 | not checked | - | - | - | - |
| GUN FIGURES | 5 | not checked | - | - | - | - |
| HIS CHARGE BY HIS RUN | 32 | 31 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 11 | 11 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 21 | 20 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 18 | 18 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 17 | 15 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 23 | 21 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 18 | 18 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 8 | 8 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 1 | 1 | 0 | 0.00 | - | - |
| HIS TURN RUN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 145 | 145 | 0 | 0.00 | - | - |
| HONEST WORTH | 3 | 3 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 14 | 14 | 0 | 0.00 | - | - |
| LONG SHOT | 1 | 1 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 2 | 2 | 0 | 0.00 | - | - |
| MANOEUVRE | 4 | 4 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 2 | trace | - | - | - | - |
| MARCH WHEELS ONLY | 2 | 2 | 0 | 0.00 | - | - |
| MISSILES ON ONE TARGET | 7 | not checked | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 4 | trace | - | - | - | - |
| MOVE SPELL SPOT | 4 | not checked | - | - | - | - |
| NO DOUBLE ROUNDS | 4 | 4 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 18 | 18 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 12 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 1 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 17 | 12 | 0 | 0.00 | - | - |
| ONE ROUTE | 2 | 2 | 0 | 0.00 | - | - |
| OPENS A LANE | 1 | 1 | 0 | 0.00 | - | - |
| PLAN RESULT | 199 | trace | - | - | - | - |
| PROMISE IN STEPS | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE READS THE TABLE | 1 | 1 | 0 | 0.00 | - | - |
| REAL GROUND | 2 | 2 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 4 | 3 | 0 | 0.00 | - | - |
| RISK BY ARC | 4 | 4 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 1 | 1 | 0 | 0.00 | - | - |
| RUN DOWN | 3 | 3 | 0 | 0.00 | - | - |
| SCOUT SPOT | 5 | 5 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 6 | 6 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 2 | 2 | 0 | 0.00 | - | - |
| SET UP BY THE SET | 3 | 3 | 0 | 0.00 | - | - |
| SET-UP ANY TARGET | 3 | not checked | - | - | - | - |
| SHOOTER COUNTED ONCE | 4 | 4 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 37 | not checked | - | - | - | - |
| SHOT OR CHARGE | 2 | 2 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 3 | not checked | - | - | - | - |
| SPELL WORTH | 12 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 25 | 25 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 15 | 15 | 0 | 0.00 | - | - |
| STANDS STILL | 172 | 171 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 2 | not checked | - | - | - | - |
| THE PROMISE ADDS | 1 | 1 | 0 | 0.00 | - | - |
| THE ROW IN ITS ORDER | 10 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 23 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 19 | not checked | - | - | - | - |
| THE TABLE BINDS | 219 | not checked | - | - | - | - |
| WAITS AGAIN | 2 | 2 | 0 | 0.00 | - | - |

### Off best figure: cnomg-c940641-p1

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 1.33 | 2.67 | 18.7 |
| ARMY TABLE | rule | 1.33 | 2.00 | 59.3 |
| HOLDER ASSIGNMENT | rule | 0.67 | 1.00 | 10.4 |
| PROMISE BY ITS OWN SUM | rule | - | 0.67 | 50.4 |
| AFTERMATH BAND | gate | 0.33 | - | 1.9 |
| ONE PROMISE A TARGET | rule | - | 0.33 | 27.3 |
| RULE SWITCHED OFF | gate | 0.33 | - | 28.0 |

### Plans: cnomg-c940641-p1

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | move | 17.0 | 94% | 2362 | 0 | 0% |
| Mine | shoot | 4.3 | 46% | 659 | 137 | 21% |
| Mine | support | 0.7 | 50% | 1 | 0 | 0% |
| Opponent | charge | 1.3 | 100% | 206 | 155 | 75% |
| Opponent | move | 38.0 | 94% | 985 | 0 | 0% |
| Opponent | shoot | 4.7 | 57% | 361 | 257 | 71% |
| Opponent | support | 0.3 | 0% | 3 | 0 | 0% |

### Battle groups: cnomg-c940641-p1

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 1.3 | 0% | - | - | - | - | - | - | - | - |
| Opponent | REDIRECT COUNTER | 3.0 | 0% | - | - | - | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: cnomg-c940641-p1

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 3 | 0 (3) | 0 | 0 | 67 | 67% | 2.0 | 0 (1) | 0 (1) | 0 (1) | 0 (2) | 0 (1) |
| Mine | Character | 18 | 24 (18) | 24 | 0 | 19 | 11% | 1.9 | 97 (3) | 17 (9) | 0 (3) | 47 (9) | 3 (6) |
| Mine | Hammer | 6 | 38 (6) | 2 | 36 | 17 | 50% | 4.0 | 112 (1) | 26 (4) | 11 (1) | 49 (4) | 14 (2) |
| Mine | Holder | 3 | 91 (3) | 0 | 91 | 0 | 100% | - | - | 136 (2) | - | 273 (1) | 0 (1) |
| Mine | Shooter | 6 | 69 (6) | 0 | 69 | 50 | 0% | 1.7 | - | 83 (5) | 0 (1) | 69 (4) | 69 (2) |
| Opponent | Chaff | 6 | 141 (6) | 0 | 141 | 25 | 67% | 4.0 | 0 (3) | 514 (2) | 0 (1) | 141 (6) | - |
| Opponent | Character | 8 | 3 (8) | 3 | 0 | 0 | 38% | 1.0 | 5 (4) | 0 (4) | - | 5 (4) | 0 (4) |
| Opponent | Early | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Fast Hammer | 7 | 29 (7) | 9 | 20 | 36 | 57% | 3.0 | 76 (1) | 0 (3) | 25 (3) | 29 (3) | 29 (4) |
| Opponent | Hammer | 13 | 51 (13) | 43 | 8 | 16 | 54% | 2.2 | - | 73 (8) | 0 (5) | 11 (3) | 65 (10) |
| Opponent | Holder | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | - | 0 (1) | - | 0 (1) |
| Opponent | Shooter | 3 | 82 (3) | 0 | 82 | 62 | 67% | 1.0 | 214 (1) | 0 (2) | - | 214 (1) | 0 (2) |
| Opponent | Wizard | 2 | 0 (2) | 0 | 0 | 0 | 100% | - | - | 0 (2) | - | 0 (2) | - |

### Charged fights: cnomg-c940641-p1

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 3 | 239 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Beastmen Brayherds | 1 | 0 | 55 | 1.0 | 1.0 | 55 | 0 | +55 | 0 of 1 | 1 of 1 | - | +55 |
| Opponent | Ogre Kingdoms | 1 | 0 | 807 | 2.0 | 1.0 | 404 | 17 | +386 | 2 of 2 | 1 of 2 | - | +386 |
| Opponent | Wood Elf Realms | 1 | 0 | 55 | 1.0 | 1.0 | 55 | 0 | +55 | 0 of 1 | 1 of 1 | - | +55 |
| **Opponent** | all armies | 3 | 0 | 306 | 1.3 | 1.0 | 229 | 8 | +221 | 2 of 4 | 3 of 4 | - | +221 |

### Effective charges: cnomg-c940641-p1

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | Beastmen Brayherds | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +55) | 0 | 0% (0 of 1) |
| Opponent | Ogre Kingdoms | 2 | 0 | 0 | 0 | 0 | 0 | 1 (net +807) | 1 | 0% (0 of 1) |
| Opponent | Wood Elf Realms | 1 | 0 | 0 | 0 | 0 | 1 (net +55) | 0 | 0 | 0% (0 of 1) |

### Charged fights, damage counted: cnomg-c940641-p1

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 168 | 188 | +431 | 447 | 65 | +382 | +227.2 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 499 | 65 | +55 | 109 | 0 | +109 | +21.9 |
| Opponent | No odds | 1 | 34 | 836 | -34 | 0 | 34 | -34 | -100.0 |
| Opponent | All fights | 4 | 217 | 320 | +221 | 251 | 41 | +210 | +96.5 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| cnomg-c940641-p1 | move | 7 | 1 (14%) | 1 (14%) | 0 (0%) | 6 (86%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0102, L0118, L0135 |
| Fistful of Laurels | Opponent | L0118 |
| Ring of Doom | Opponent | L0102 |

# Doctrine scorecard: cnomg-c940641-p7

### Scorecard: cnomg-c940641-p7

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L1114 | 4 | 1 | Mine | no | 0 | 2 | 2 | 0 | 0 | 0 | 0 | 330 |
| L1114 | 4 | 1 | Opponent | yes | 3 | 2 | 1 | 1 | 1 | 0 | 0 | 0 |
| L1131 | 3 | 1 | Mine | no | 0 | 3 | 2 | 0 | 0 | 0 | 0 | 330 |
| L1131 | 3 | 1 | Opponent | no | 2 | 3 | 3 | 0 | 1 | 0 | 0 | 340 |
| L1224 | 6 | 1 | Mine | no | 9 | 1 | 1 | 0 | 0 | 0 | 0 | 330 |
| L1224 | 6 | 1 | Opponent | no | 4 | 4 | 4 | 1 | 1 | 0 | 0 | 0 |
| **Average** | | | Mine | 0% | 3.0 | 2.0 | 1.7 | 0.0 | 0.0 | 0.0 | 0.0 | 330.0 |
| **Average** | | | Opponent | 33% | 3.0 | 3.0 | 2.7 | 0.7 | 1.0 | 0.0 | 0.0 | 113.3 |

### KPIs: cnomg-c940641-p7

Rules off - Mine only: NO OLD ONE-MOVE GUESS.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 62% (10 of 16) | 0% (0 of 16) | 31% (10 of 32) |
| Winner chose to follow up after the loser gave ground |  | 100% (3 of 3); on the table 100% | - | 100% (3 of 3); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | - | 0% (0 of 2); on the table 0% | 0% (0 of 2); on the table 0% |
| Winner chose to pursue after the loser fled |  | 100% (2 of 2); on the table 100% | 100% (1 of 1); on the table 100% | 100% (3 of 3); on the table 100% |
| Winner chose to follow up or pursue (all three) |  | 100% (5 of 5); on the table 100% | 33% (1 of 3); on the table 33% | 75% (6 of 8); on the table 75% |
| Magic missiles tried each own turn | 50%+ | 38% (25 of 66) | 11% (2 of 18) | 32% (27 of 84) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 50% (25 of 50) | 15% (2 of 13) | 43% (27 of 63) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 83% (10 of 12) | 83% (10 of 12) |
| Points that never fought | lower | 64% (3843 of 5998) | 61% (3679 of 5998) | 63% (7522 of 11996) |
|   infantry points that never fought | lower | 73% (536 of 730) | 100% (913 of 913) | 88% (1449 of 1643) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 64% (16 of 25) | 61% (17 of 28) | 62% (33 of 53) |
| Bound items with a magic missile used (at least once a game) |  | 86% (6 of 7); 6.7 uses a game | 100% (1 of 1); 1.0 uses a game | 88% (7 of 8); 3.8 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 33% (2 of 6); 1.0 uses a game | 33% (2 of 6); 0.5 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0% (0 of 3); 0.0 uses a game | 0.0 uses a game | 0% (0 of 3); 0.0 uses a game |
|   their share of the points of units over 100 pts | lower | 60% (3382 of 5614) | 61% (3528 of 5828) | 60% (6910 of 11442) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 4.0 (29%) | 0.7 (12%) | 4.7 (25%) |
| MARCHED: its unit marched | 4.3 (32%) | 3.0 (56%) | 7.3 (39%) |
| IN COMBAT: engaged in combat | 4.7 (34%) | 0.3 (6%) | 5.0 (26%) |
| GONE: slain | 0.0 (0%) | 1.3 (25%) | 1.3 (7%) |
| OFF THE TABLE: off the table or not arrived | 0.7 (5%) | 0.0 (0%) | 0.7 (4%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 2.7 | 4.0 | 2.3 | 9.0 | 2.7 | 2.7 |
| not cast | 1.3 | 8.0 | 1.7 | 19.0 | 5.3 | 33.3 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (2%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 5.7 (71%) | 0.0 (0%) | 4.7 (25%) | 1.7 (31%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 7.3 (39%) | 2.0 (38%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.7 (8%) | 0.3 (20%) | 5.0 (26%) | 0.7 (12%) | 0.0 (0%) |
| NO CASTS LEFT: every cast used on other spells | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (6%) | 0.0 (0%) |
| GONE: slain | 0.0 (0%) | 0.3 (4%) | 0.3 (20%) | 1.3 (7%) | 0.0 (0%) | 1.7 (5%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (4%) | 0.7 (12%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 1.3 (17%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.3 (100%) | 0.0 (0%) | 1.0 (60%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 31.0 (93%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.0 a game | 2.3 a game | 1.2 a game |
| stood (cast and not dispelled) | - | 86% (6 of 7) | 86% (6 of 7) |
| the unit moved after it | - | 67% (4 of 6) | 67% (4 of 6) |
| it charged on its next turn | - | 0% (0 of 6) | 0% (0 of 6) |
| the enemy charged it first | - | 17% (1 of 6) | 17% (1 of 6) |
| it fought by the end of its next turn | - | 0% (0 of 6) | 0% (0 of 6) |
| it moved out of a charge the enemy had planned (not charged first) | - | 0% (0 of 6) | 0% (0 of 6) |
| none of these (no charge, no fight, no charge escaped) | - | 83% (5 of 6) | 83% (5 of 6) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 78% (52 of 67) | 50% (11 of 22) | 71% (63 of 89) |
|   cavalry | 0% (0 of 12) | 56% (5 of 9) | 24% (5 of 21) |
|   character | - | 0% (0 of 7) | 0% (0 of 7) |
|   chariot | 83% (10 of 12) | - | 83% (10 of 12) |
|   infantry | 100% (12 of 12) | 100% (6 of 6) | 100% (18 of 18) |
|   war machine | 97% (30 of 31) | - | 97% (30 of 31) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 0.7 (13%) | 0.3 (9%) | 1.0 (12%) |
| CHARGED: it charged | 0.7 (13%) | 0.3 (9%) | 1.0 (12%) |
| IN COMBAT: it fought this turn or the last | 0.0 (0%) | 0.3 (9%) | 0.3 (4%) |
| FREE: none of these - no target in range or sight, or held its fire | 3.7 (73%) | 0.0 (0%) | 3.7 (42%) |
| NO TARGET IN RANGE | 0.0 (0%) | 2.0 (55%) | 2.0 (23%) |
| ONLY IN COMBAT: the only targets were in combat | 0.0 (0%) | 0.3 (9%) | 0.3 (4%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.0 (0%) | 0.3 (9%) | 0.3 (4%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 3.3 | 0.3 | 90% | 3.9 pts | 13 pts |
| chariot | 3.3 | 0.3 | 90% | 2.5 pts | 8 pts |
| infantry | 12.0 | 1.7 | 86% | 7.0 pts | 84 pts |
| war machine | 11.0 | 5.7 | 76% | 19.2 pts | 211 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 2.0 | 3.3 | 2.7 |
| Charges that made contact a game | 1.7 | 2.0 | 1.8 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.43 declared, 0.43 contact (7 units) | 0.33 declared, 0.00 contact (3 units) | 0.40 declared, 0.30 contact (10 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | - | - |
|   per unit a game, the other units (no war machines, no joined characters) | 0.30 declared, 0.20 contact (10 units) | 0.45 declared, 0.30 contact (20 units) | 0.40 declared, 0.27 contact (30 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 64% (7 of 11) | 0% (0 of 2) | 50% (1 of 2) | 53% (8 of 15) |
| Character in a unit | 100% (1 of 1) | - | - | 100% (1 of 1) |
| Character on its own | 100% (6 of 6) | 67% (4 of 6) | 57% (4 of 7) | 74% (14 of 19) |
| Chariot | 50% (1 of 2) | - | - | 50% (1 of 2) |
| Infantry | 33% (2 of 6) | 50% (1 of 2) | - | 38% (3 of 8) |
| Monster | 0% (0 of 2) | - | - | 0% (0 of 2) |
| War Machines | 100% (6 of 6) | - | - | 100% (6 of 6) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Grand Cathay | 3 | 100% (5 of 5); on the table 100% | 38% (25 of 66) | 64% | 64% (16 of 25) | 86% (6 of 7); 6.7 uses a game | 0.0 uses a game | 0% (0 of 3); 0.0 uses a game |
| High Elf Realms | 1 | - | 0% (0 of 6) | 62% | 44% (4 of 9) | 0.0 uses a game | 33% (2 of 6); 3.0 uses a game | 0.0 uses a game |
| Vampire Counts | 1 | 100% (1 of 1); on the table 100% | 0% (0 of 6) | 69% | 71% (5 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 1 | 0% (0 of 2); on the table 0% | 33% (2 of 6) | 53% | 67% (8 of 12) | 100% (1 of 1); 3.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (cnomg-c940641-p7, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 83% (5) | 75% (3) | 80% (8) |
| ...free all their last turn and able to turn (per game) | 1.33 | 1.00 | 2.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.33 | 0.33 | 0.67 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.33 | 0.33 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.67 | 0.67 |

### Quality by phase: cnomg-c940641-p7

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 4.3 | 3.7 |
| Strategy | Charge objectives carried out (made contact) | 80% (4 of 5) | 67% (6 of 9) |
| Strategy | Shoot objectives carried out (shot that target) | 36% (16 of 45) | 80% (4 of 5) |
| Strategy | Hexes on a unit its side charged or shot that turn | 50% (2 of 4) | 0% (0 of 1) |
| Strategy | Joined characters whose unit fought | 0% (0 of 2) | 0% (0 of 1) |
| Strategy | Lone characters that fought | 60% (6 of 10) | 40% (4 of 10) |
| Movement | Charges halted short of contact | 0.3 | 0.3 |
| Movement | Idle units | 0.0 | 0.7 |
| Movement | Points that never moved of their own | 330.0 | 113.3 |
| Movement | Fights charged into per game | 1.7 | 2.0 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 4 | 1 of 6, net -60 |
| Movement | Charges with odds: sweet spot (55-75%) | 2 of 4, net +20 | 0 of 6 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 4 | 0 of 6 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 of 4, net +206 | 3 of 6, net +65 |
| Shooting | Shots by shooting units (incl. breath weapons) | 7.3 | 4.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 27% (6 of 22) | 21% (3 of 14) |
| Shooting | Points destroyed by shooting units | 0.0 | 55.0 |
| Shooting | War machine shots | 10.0 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 57% (17 of 30) | - |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | 7.0 | 0.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 62% (13 of 21) | 0% (0 of 1) |
| Magic | Wounds caused by magic missiles | 8.0 | 1.3 |
| Magic | Wounds caused by other spells | - | 0.7 |
| Magic | Points destroyed by magic (all spells) | 223.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.7 / 1.3 / 0.3 / 0.7 | 1.7 / 0.3 / 0.7 / 0.0 |
| Combat | Points destroyed in combat | 340.3 | 0.0 |
| Combat | Points run down | 0.0 | 0.0 |
| Combat | Net points per charged fight, damage counted | +87 | +46 |
| Combat | Net per 100 charger points, damage counted | +38.4 | +32.9 |
| Combat | First round won (charged fights) | 100% | 83% |
| Combat | Net points per charged fight | +119 | +61 |
| Combat | Net points per supported fight / lone fight | - / +119 | - / +61 |
| Combat | Charged fights on a top-3 enemy unit | 2 of 5 | 3 of 6 |
| Game | Points lost | 676.7 | 626.0 |
| Game | VP from objectives | 430.0 | 693.3 |
| Game | Lone holders (player turns) | 3.0 | 3.0 |

- Mine won / drew / lost: 0 / 1 / 2 of 3 ended games (of 3); mean margin (Mine - Opponent) -328 VP
- The side that went first won 1 of 2 games with a winner
- Points traded per game (both sides' losses): 1303
- Games not ended: 0; findings 1, warnings 0

### Opponent rules: cnomg-c940641-p7

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| ARMY TABLE | 15.7 | +1335.2 | 0.0 | 77.7 | 26.0 | -327.7 | 0.0 | 636.3 |
| ARTILLERY RE-ROLL WEIGHED | 6.7 | +0.0 | 0.0 | 110.0 | - | - | - | - |
| ASSAILMENT BY POINTS | - | - | - | - | 0.7 | +6.3 | 0.0 | 333.3 |
| BACKUP TARGETS | - | - | - | - | 0.7 | +1.7 | 0.0 | 0.0 |
| BOMBING RUN | 1.0 | +41.8 | 41.0 | 0.0 | - | - | - | - |
| CANNON PLANNED TARGET | 10.0 | +475.3 | 0.0 | 275.0 | - | - | - | - |
| CANNON SIGHT KEPT | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CAST JOB | 4.7 | +76.3 | 202.0 | 0.0 | 0.3 | +0.7 | 119.3 | 0.0 |
| CASTS AFTER FRIENDS | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | - | - | - | - | 1.7 | +105.4 | 0.0 | 60.0 |
| CHALLENGE BY POINTS | 1.0 | +8.8 | 0.0 | 77.7 | 0.7 | +9.4 | 0.0 | 41.0 |
| CHAMPION KNOWS CHALLENGE | - | - | - | - | 0.3 | -1.6 | 64.7 | 0.0 |
| CHARGE LOSSES | 13.3 | -347.0 | 0.0 | 394.0 | 30.7 | -1600.9 | 0.0 | 638.0 |
| CHARGE NOW FIRST | 2.3 | +0.0 | 428.0 | 0.0 | 1.7 | +0.0 | 220.0 | 53.7 |
| CLOSES ON WHAT IT BEATS | 6.7 | +0.0 | 0.0 | 238.7 | 6.7 | +0.0 | 0.0 | 53.7 |
| COMBAT PIVOT | 0.3 | +0.0 | 48.0 | 0.0 | - | - | - | - |
| CONVEYANCE SEARCH | - | - | - | - | 2.3 | +375.5 | 0.0 | 0.0 |
| COVER ONCE | 11.3 | -797.2 | 0.0 | 197.0 | 7.7 | -508.8 | 0.0 | 65.0 |
| DEFENSIVE ARMY | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| DENIED BY THE FIGHT | - | - | - | - | 1.0 | -6.0 | 64.7 | 20.0 |
| DEPLOY BY FIGURES | 6.0 | +5.5 | 0.0 | 0.0 | 6.7 | +127.1 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | - | - | - | - | 0.3 | -21.8 | 119.3 | 0.0 |
| EDGE GIVE GROUND | 0.7 | +6.9 | 113.0 | 0.0 | 0.3 | +18.2 | 0.0 | 0.0 |
| EXACT ROUND | 1.3 | +23.4 | 320.7 | 0.0 | 1.3 | +18.4 | 210.3 | 20.0 |
| FALL BACK GOOD ORDER | 1.7 | +3.7 | 279.7 | 0.0 | 2.7 | +15.3 | 339.3 | 73.7 |
| FALLS SHORT | - | - | - | - | 21.0 | +275.3 | 0.0 | 449.0 |
| FEATURE BUFFS | 0.7 | +10.5 | 0.0 | 0.0 | - | - | - | - |
| FIGHT TO THE END | 1.0 | +30.9 | 166.7 | 0.0 | 1.7 | +16.3 | 220.0 | 53.7 |
| FIVE ACTION | 76.0 | +6296.1 | 799.7 | 1421.3 | 81.3 | +3673.7 | 623.7 | 1053.3 |
| FLANK NOT WEIGHED | 6.7 | +0.0 | 0.0 | 119.3 | 6.0 | +0.0 | 0.0 | 65.0 |
| FOLLOW UP WEIGHED | 1.0 | +114.6 | 0.0 | 0.0 | 0.3 | -1.1 | 0.0 | 0.0 |
| FOUR ROUNDS | 2.0 | +184.1 | 320.7 | 0.0 | 3.3 | +211.1 | 394.3 | 73.7 |
| FREED FROM HIS FIGHT | 3.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 82.0 |
| FRIEND SHOOTS FIRST | 0.7 | -17.2 | 0.0 | 0.0 | 1.3 | -6.1 | 0.0 | 0.0 |
| GOAL WALK | 0.3 | +36.0 | 0.0 | 0.0 | 10.7 | +1272.9 | 0.0 | 107.3 |
| GUN MASK | 4.0 | +62.4 | 0.0 | 119.3 | - | - | - | - |
| HARD STAY DROPPED | 1.0 | +0.0 | 0.0 | 119.3 | 1.0 | +0.0 | 0.0 | 41.0 |
| HE REFORMS ONCE FREED | 1.0 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 82.0 |
| HIS CHARGE BY HIS RUN | 9.7 | +0.0 | 0.0 | 394.0 | 12.7 | +0.0 | 0.0 | 299.3 |
| HIS CHARGE DENIED | - | - | - | - | 0.7 | +127.3 | 0.0 | 20.0 |
| HIS CHARGE LIST | 3.3 | +0.0 | 0.0 | 238.7 | 5.0 | +0.0 | 0.0 | 65.0 |
| HIS LEGAL MOVES | 7.0 | +0.0 | 0.0 | 77.7 | 5.7 | +0.0 | 0.0 | 385.0 |
| HIS MOVE AND SHOT | 6.3 | -17.3 | 0.0 | 0.0 | 17.3 | -328.0 | 0.0 | 556.0 |
| HIS MOVE AS HE DECIDES | 41.7 | +8.3 | 864.7 | 0.0 | - | - | - | - |
| HIS MOVE WHY | - | - | - | - | 28.7 | +0.0 | 0.0 | 514.0 |
| HIS ONE MOVE | 23.3 | -26.1 | 0.0 | 119.3 | - | - | - | - |
| HIS ONE QUARTER | 1.7 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 2.0 | +0.0 | 0.0 | 77.7 | 6.0 | +0.0 | 0.0 | 385.0 |
| HIS RANDOM MOVE | 9.7 | +0.0 | 0.0 | 394.0 | - | - | - | - |
| HIS RANDOM MOVER COMES | 0.7 | +0.0 | 0.0 | 238.7 | - | - | - | - |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 11.3 | +98.0 | 0.0 | 238.7 | 65.0 | +4629.5 | 0.0 | 914.7 |
| HIS SHOTS BY HIS RUN | 24.7 | +166.4 | 0.0 | 871.3 | 62.3 | +2463.3 | 0.0 | 807.3 |
| HIS TURN DENIED | 0.3 | +1.6 | 41.0 | 0.0 | 0.3 | +4.4 | 0.0 | 0.0 |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 10.0 | +0.0 | 0.0 | 238.7 | 17.3 | +0.0 | 0.0 | 0.0 |
| HOLDER ASSIGNMENT | 7.3 | +708.5 | 0.0 | 119.3 | 10.7 | +1036.3 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 1.0 | -22.3 | 41.0 | 0.0 | 2.3 | -98.4 | 394.3 | 53.7 |
| HUNT IN PAIRS | 2.3 | +45.2 | 0.0 | 0.0 | - | - | - | - |
| HUNT KEPT | - | - | - | - | 0.3 | +0.9 | 77.7 | 0.0 |
| HUNT RESULT | - | - | - | - | 0.7 | +80.3 | 0.0 | 0.0 |
| HUNT THE GUNS | - | - | - | - | 1.0 | +311.7 | 77.7 | 20.0 |
| IDLE COST | - | - | - | - | 18.7 | -328.2 | 0.0 | 169.3 |
| KEPT FROM ITS LAST STOP | - | - | - | - | 3.7 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 1.0 | +5.5 | 0.0 | 0.0 | 0.7 | +40.1 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 4.7 | +0.0 | 570.0 | 64.7 | 8.7 | +0.0 | 64.7 | 474.0 |
| LONE WIZARD KEPT IN | 0.7 | +41.6 | 0.0 | 0.0 | - | - | - | - |
| LOST AFTER ESCAPE | 1.0 | -0.9 | 166.7 | 0.0 | 2.7 | +11.3 | 220.0 | 73.7 |
| MANOEUVRE | 0.3 | -2.0 | 0.0 | 0.0 | 1.7 | +3.0 | 0.0 | 48.0 |
| MARCH BY THE SUM | 1.7 | +95.6 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | 1.3 | +58.5 | 0.0 | 0.0 | - | - | - | - |
| MARCH OF THE TABLE | 2.0 | +143.3 | 0.0 | 0.0 | 0.7 | +9.1 | 0.0 | 0.0 |
| MARCH OVER CASTS | 3.3 | +70.9 | 0.0 | 0.0 | 2.3 | +543.8 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 7.7 | +248.2 | 0.0 | 77.7 | 2.7 | +43.0 | 0.0 | 193.3 |
| MEETS IN TIME | 3.7 | +420.3 | 0.0 | 0.0 | 3.7 | +347.5 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 13.7 | +331.3 | 0.0 | 77.7 | 2.0 | +10.0 | 0.0 | 130.0 |
| MISSILES NEXT TURN | 16.0 | +302.0 | 0.0 | 77.7 | 5.7 | +28.9 | 0.0 | 130.0 |
| MOVE ORDER | 0.7 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| MOVE SPELL SPOT | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 11.7 | +1571.7 | 0.0 | 0.0 | 7.7 | +570.5 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 4.7 | +195.3 | 0.0 | 119.3 | 5.0 | +179.2 | 0.0 | 48.0 |
| NEXT CHARGE BY LIST | 8.0 | +1399.3 | 94.7 | 0.0 | 5.7 | +403.3 | 0.0 | 0.0 |
| NEXT OBJECTIVE NEARER | - | - | - | - | 0.3 | -0.1 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 2.0 | -82.1 | 320.7 | 0.0 | 3.3 | -175.6 | 394.3 | 73.7 |
| NO LATE CUT | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | - | - | - | - | 0.7 | +0.0 | 0.0 | 65.0 |
| NOT WORTH A CAST | 1.3 | -0.1 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 7.7 | -247.2 | 0.0 | 220.0 | 5.7 | -404.0 | 0.0 | 126.0 |
| OGRE LOADER SECOND SHOT | 10.7 | +116.3 | 0.0 | 110.0 | - | - | - | - |
| ONE CHALLENGE TEST | 0.3 | +0.7 | 41.0 | 0.0 | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 8.3 | -168.7 | 0.0 | 0.0 | 8.3 | -206.3 | 0.0 | 234.3 |
| ONE OBJECTIVE FORMULA | 3.7 | -52.7 | 0.0 | 119.3 | 4.0 | -20.0 | 0.0 | 0.0 |
| ONE PROMISE A TARGET | - | - | - | - | 0.3 | -17.1 | 0.0 | 0.0 |
| OPENS A LANE | 0.3 | +1.1 | 65.0 | 0.0 | - | - | - | - |
| OVERRUNS AWAY | 0.3 | +0.5 | 0.0 | 0.0 | 0.7 | +0.8 | 119.3 | 0.0 |
| PATHS CROSS | - | - | - | - | 0.7 | -4.6 | 0.0 | 48.0 |
| PIVOT GUARDS FLANK | 1.0 | -53.8 | 0.0 | 77.7 | - | - | - | - |
| PLAN RESULT | 33.3 | +810.8 | 553.3 | 853.0 | 41.3 | +473.2 | 197.3 | 864.7 |
| PROMISE BELOW ZERO | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE BY ITS OWN SUM | 13.0 | -295.3 | 0.0 | 0.0 | 7.7 | -137.7 | 0.0 | 0.0 |
| PROMISE IN STEPS | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE KNOWS THE FIGHT | 1.3 | -6.4 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | 1.0 | -34.7 | 0.0 | 0.0 | 0.7 | -2.7 | 0.0 | 0.0 |
| PROMISE SHOT AWAY | 1.0 | -7.8 | 65.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | 12.3 | +1735.1 | 248.7 | 220.0 | 13.3 | +1775.8 | 242.7 | 82.0 |
| RANDOM MOVE BY FIGURES | - | - | - | - | 4.0 | +108.3 | 0.0 | 0.0 |
| REDIRECT COUNTER | - | - | - | - | 0.3 | +11.8 | 0.0 | 20.0 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 0.3 | +0.0 | 0.0 | 20.0 |
| REFORMS TO MEET IT | 4.3 | -247.6 | 0.0 | 0.0 | 1.3 | -34.0 | 0.0 | 0.0 |
| REFUSING RETIRES | - | - | - | - | 0.7 | +0.0 | 0.0 | 53.7 |
| RISK BY ARC | 1.3 | +50.6 | 231.7 | 0.0 | 2.7 | +31.6 | 339.3 | 53.7 |
| ROUNDS AFTER TERROR | - | - | - | - | 1.0 | -35.0 | 174.3 | 53.7 |
| RUN DOWN | 1.7 | -12.9 | 320.7 | 0.0 | 3.0 | -58.8 | 339.3 | 73.7 |
| SAFER THAN THE JOB | - | - | - | - | 0.3 | +5.6 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 1.3 | +49.2 | 0.0 | 40.0 |
| SEARCH SPOT | 0.7 | +2.7 | 0.0 | 0.0 | 0.3 | +7.0 | 0.0 | 53.7 |
| SECOND LOOK | 0.3 | +19.0 | 0.0 | 0.0 | - | - | - | - |
| SET CREDITED ONCE | - | - | - | - | 1.7 | -20.1 | 0.0 | 0.0 |
| SET UP BY THE SET | 2.3 | +176.0 | 0.0 | 0.0 | 2.0 | +24.7 | 119.3 | 0.0 |
| SET-UP ANY TARGET | - | - | - | - | 0.7 | +139.3 | 0.0 | 0.0 |
| SHOOTER COUNTED ONCE | - | - | - | - | 0.7 | -1.9 | 0.0 | 40.0 |
| SHOOTERS ON THE TABLE | 15.7 | +0.0 | 0.0 | 275.0 | 3.3 | +0.0 | 0.0 | 85.0 |
| SHOOTS FROM THE BEST SPOT | 3.3 | +65.3 | 41.0 | 0.0 | 1.3 | +55.6 | 0.0 | 65.0 |
| SHOT RISK POINTS | 13.7 | -63.4 | 0.0 | 316.3 | 50.0 | +1155.4 | 0.0 | 849.7 |
| SHOTS AFTER THE MOVES | 6.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 16.3 | +945.3 | 0.0 | 275.0 | 4.0 | +110.8 | 0.0 | 41.0 |
| SPELL SETS UP CHARGE | - | - | - | - | 0.7 | +139.3 | 0.0 | 0.0 |
| SPELL WORTH | 0.7 | +4.0 | 0.0 | 0.0 | 2.0 | +42.4 | 0.0 | 0.0 |
| SPELLS IN THE FIGHT | 0.7 | -9.4 | 166.7 | 0.0 | - | - | - | - |
| SPOT AS THE GAME MOVES | 3.7 | +0.0 | 0.0 | 119.3 | 8.3 | +0.0 | 0.0 | 94.7 |
| STAND AND SHOOT | 0.3 | -0.6 | 41.0 | 0.0 | 0.3 | -3.0 | 0.0 | 0.0 |
| STANDS FOR A REASON | - | - | - | - | 2.0 | +0.0 | 119.3 | 82.0 |
| STANDS STILL | 35.0 | +0.0 | 479.0 | 788.7 | 16.3 | +0.0 | 229.3 | 147.0 |
| STAY WORTH | 28.3 | -301.6 | 202.0 | 165.0 | 4.3 | +38.2 | 110.0 | 41.0 |
| STOPS | - | - | - | - | 1.3 | +3.2 | 155.3 | 20.0 |
| STRIKE BY THE ODDS | - | - | - | - | 0.7 | +7.4 | 119.3 | 0.0 |
| SUPPORT ADDS | 2.0 | +62.9 | 0.0 | 0.0 | 2.7 | +122.2 | 0.0 | 0.0 |
| SUPPORT NARROWED | 0.3 | +0.0 | 65.0 | 0.0 | 0.3 | +0.0 | 64.7 | 0.0 |
| SUPPORT WORKED OUT | 2.0 | +62.9 | 0.0 | 0.0 | 2.7 | +122.2 | 0.0 | 0.0 |
| SURE REACH TOGETHER | 0.7 | +0.5 | 0.0 | 0.0 | - | - | - | - |
| SWIFTSTRIDE BY POINTS | 0.3 | -10.2 | 0.0 | 119.3 | - | - | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 1.0 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 48.0 |
| THE PROMISE ADDS | 1.0 | -109.5 | 0.0 | 0.0 | - | - | - | - |
| THE PROMISED MOVE | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 3.0 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 128.3 | 53.7 |
| THE ROW KEEPS ITS WAY | 1.7 | +0.0 | 0.0 | 119.3 | 2.7 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 1.0 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 48.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 35.7 | +0.0 | 0.0 | 710.7 | 40.0 | +0.0 | 0.0 | 542.3 |
| TIED UP BY THE SUM | 0.3 | +16.3 | 48.0 | 0.0 | 1.3 | +117.8 | 64.7 | 53.7 |
| TIME ON OUR SIDE | 27.3 | +509.9 | 0.0 | 913.0 | - | - | - | - |
| WAITS AGAIN | 5.3 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| WAR ENGINE CHARGES | 0.3 | +25.9 | 65.0 | 0.0 | - | - | - | - |
| WAR ENGINE JOBS | 1.0 | +0.0 | 41.0 | 0.0 | - | - | - | - |
| WEAPON BY POINTS | - | - | - | - | 0.3 | +0.0 | 0.0 | 48.0 |
| WHO FIGHTS | 0.3 | -2.2 | 48.0 | 0.0 | - | - | - | - |
| WHO HITS BACK | 0.3 | +36.1 | 0.0 | 0.0 | 1.0 | +93.8 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | 1.7 | -278.4 | 0.0 | 316.3 | 3.0 | -236.7 | 0.0 | 381.3 |
| WOUNDS ON THE RANKS | 2.0 | +5.2 | 0.0 | 238.7 | 2.0 | +21.5 | 0.0 | 0.0 |

### Rule changes: cnomg-c940641-p7

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS MOVE AS HE DECIDES | 125 | 125 | 100 | 33.33 | +0 | +0.0 |
| ARMY TABLE | 125 | 125 | 93 | 31.00 | +3459 | +37.2 |
| HIS MOVE WHY | 86 | 86 | 69 | 23.00 | +0 | +0.0 |
| HIS SHOT LIST | 229 | 219 | 66 | 22.00 | +2629 | +39.8 |
| HIS SHOTS BY HIS RUN | 261 | 245 | 49 | 16.33 | +1183 | +24.1 |
| HOLDER ASSIGNMENT | 54 | 54 | 48 | 16.00 | +3490 | +72.7 |
| FIVE ACTION | 472 | 452 | 44 | 14.67 | +2785 | +63.3 |
| LEGAL CHARGES ONLY | 40 | 40 | 40 | 13.33 | +0 | +0.0 |
| OFF BEST | 40 | 40 | 40 | 13.33 | -1954 | -48.8 |
| THE TABLE AGAIN | 36 | 36 | 33 | 11.00 | +0 | +0.0 |
| OGRE LOADER SECOND SHOT | 32 | 32 | 32 | 10.67 | +349 | +10.9 |
| SHOT RISK POINTS | 191 | 177 | 30 | 10.00 | +1449 | +48.3 |
| MOVE TO CHARGE COMPUTED | 58 | 51 | 26 | 8.67 | +1463 | +56.3 |
| PROMISE BY ITS OWN SUM | 62 | 62 | 22 | 7.33 | -1299 | -59.0 |
| ARTILLERY RE-ROLL WEIGHED | 20 | 20 | 20 | 6.67 | +0 | +0.0 |
| NEXT CHARGE BY LIST | 41 | 39 | 19 | 6.33 | +1324 | +69.7 |
| QUARTER ODDS | 77 | 74 | 19 | 6.33 | +1758 | +92.5 |
| DEPLOY BY FIGURES | 38 | 38 | 18 | 6.00 | +443 | +24.6 |
| HIS ONE MOVE | 70 | 64 | 18 | 6.00 | +0 | +0.0 |
| CHARGE LOSSES | 132 | 119 | 14 | 4.67 | +2215 | +158.2 |
| MEETS IN TIME | 22 | 22 | 12 | 4.00 | +535 | +44.6 |
| RANDOM MOVE BY FIGURES | 12 | 12 | 10 | 3.33 | +325 | +32.5 |
| IDLE COST | 56 | 42 | 9 | 3.00 | +141 | +15.7 |
| COVER ONCE | 57 | 36 | 8 | 2.67 | +155 | +19.4 |
| FOUR ROUNDS | 16 | 15 | 8 | 2.67 | +356 | +44.5 |
| MARCH OF THE TABLE | 8 | 8 | 8 | 2.67 | -457 | -57.1 |
| MOVE ORDER | 8 | 8 | 8 | 2.67 | +0 | +0.0 |
| SHOOTS FROM THE BEST SPOT | 14 | 14 | 8 | 2.67 | +26 | +3.2 |
| CAST JOB | 15 | 15 | 7 | 2.33 | +15 | +2.2 |
| GOAL WALK | 33 | 33 | 7 | 2.33 | +1106 | +158.0 |
| TIME ON OUR SIDE | 82 | 67 | 7 | 2.33 | +72 | +10.3 |
| ADVANCE LANE KEPT | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| HARD STAY DROPPED | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| MAX FOR POSITIONING | 31 | 26 | 6 | 2.00 | +6 | +1.0 |
| MISSILES IN THE MOVE | 47 | 32 | 6 | 2.00 | +73 | +12.1 |
| SET UP BY THE SET | 13 | 13 | 6 | 2.00 | +309 | +51.5 |
| SHOTS AFTER THE MOVES | 21 | 21 | 6 | 2.00 | +0 | +0.0 |
| CANNON SIGHT KEPT | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| CHALLENGE BY POINTS | 5 | 5 | 5 | 1.67 | +55 | +10.9 |
| FALLS SHORT | 63 | 51 | 5 | 1.67 | +28 | +5.5 |
| HOLDS AMBUSHERS | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| LANE BY FIGURES | 5 | 5 | 5 | 1.67 | +137 | +27.3 |
| MARCH BY THE SUM | 5 | 5 | 5 | 1.67 | +287 | +57.3 |
| SUPPORT ADDS | 14 | 14 | 5 | 1.67 | +84 | +16.9 |
| SUPPORT WORKED OUT | 14 | 14 | 5 | 1.67 | +84 | +16.9 |
| CHARGE NOW FIRST | 12 | 12 | 4 | 1.33 | -169 | -42.2 |
| FOLLOW UP WEIGHED | 4 | 4 | 4 | 1.33 | +340 | +85.1 |
| MARCH CHECK | 4 | 4 | 4 | 1.33 | +108 | +26.9 |
| RISK BY ARC | 12 | 11 | 4 | 1.33 | +73 | +18.2 |
| SCREEN BY WHAT IT SAVES | 4 | 4 | 4 | 1.33 | +19 | +4.7 |
| WHO HITS BACK | 4 | 4 | 4 | 1.33 | +233 | +58.2 |
| WHOLE FIGHT DANGER | 14 | 13 | 4 | 1.33 | +1055 | +263.8 |
| BOMBING RUN | 3 | 3 | 3 | 1.00 | +125 | +41.8 |
| CHAFF IN THE MOVE | 5 | 5 | 3 | 1.00 | +19 | +6.3 |
| GUN MASK | 12 | 11 | 3 | 1.00 | +50 | +16.7 |
| PIVOT GUARDS FLANK | 3 | 3 | 3 | 1.00 | -161 | -53.8 |
| PROMISE SHOT AWAY | 3 | 3 | 3 | 1.00 | -23 | -7.7 |
| SEARCH SPOT | 3 | 3 | 3 | 1.00 | +29 | +9.7 |
| TIED UP BY THE SUM | 5 | 5 | 3 | 1.00 | +48 | +16.1 |
| ASSAILMENT BY POINTS | 2 | 2 | 2 | 0.67 | +19 | +9.5 |
| LONE WIZARD KEPT IN | 2 | 2 | 2 | 0.67 | +125 | +62.4 |
| MANOEUVRE | 6 | 6 | 2 | 0.67 | +44 | +22.0 |
| MISSILES NEXT TURN | 65 | 46 | 2 | 0.67 | +0 | +0.0 |
| NEARER NOT NEEDED | 29 | 26 | 2 | 0.67 | +58 | +28.9 |
| NO DOUBLE ROUNDS | 16 | 15 | 2 | 0.67 | +63 | +31.5 |
| PATHS CROSS | 2 | 2 | 2 | 0.67 | -14 | -6.8 |
| PROMISE READS THE TABLE | 5 | 5 | 2 | 0.67 | -30 | -14.9 |
| STAY WORTH | 98 | 86 | 2 | 0.67 | +50 | +25.2 |
| THE ROW IN ITS ORDER | 19 | 2 | 2 | 0.67 | +0 | +0.0 |
| WAR ENGINE JOBS | 3 | 3 | 2 | 0.67 | -119 | -59.7 |
| CASTS FROM BEHIND | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| COMBAT PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| EXACT ROUND | 8 | 8 | 1 | 0.33 | +7 | +7.0 |
| HIS CHARGE DENIED | 2 | 2 | 1 | 0.33 | +11 | +11.0 |
| HIS TURN DENIED | 2 | 2 | 1 | 0.33 | +8 | +8.0 |
| ONE OBJECTIVE FORMULA | 23 | 16 | 1 | 0.33 | +33 | +33.4 |
| ONE PROMISE A TARGET | 1 | 1 | 1 | 0.33 | -51 | -51.2 |
| PROMISE KNOWS THE FIGHT | 9 | 8 | 1 | 0.33 | -19 | -19.1 |
| REDIRECT FOR A FRIEND IN REACH | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| REFUSING RETIRES | 2 | 2 | 1 | 0.33 | -5 | -5.2 |
| SAFER THAN THE JOB | 1 | 1 | 1 | 0.33 | +17 | +16.7 |
| SECOND LOOK | 1 | 1 | 1 | 0.33 | +57 | +57.1 |
| SHOTS IN THE MOVE | 61 | 39 | 1 | 0.33 | +68 | +68.0 |
| STRIKE BY THE ODDS | 2 | 2 | 1 | 0.33 | +24 | +23.9 |
| SUPPORT NARROWED | 2 | 2 | 1 | 0.33 | -20 | -19.8 |
| SWIFTSTRIDE BY POINTS | 1 | 1 | 1 | 0.33 | -30 | -30.5 |
| WAR ENGINE CHARGES | 1 | 1 | 1 | 0.33 | +24 | +24.5 |
| WEAPON BY POINTS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| BACKUP TARGETS | 2 | 2 | 0 | 0.00 | - | - |
| CANNON PLANNED TARGET | 30 | 30 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 3 | trace | - | - | - | - |
| CHAMPION KNOWS CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 40 | 35 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 7 | not checked | - | - | - | - |
| DEFENSIVE ARMY | 2 | 2 | 0 | 0.00 | - | - |
| DENIED BY THE FIGHT | 3 | 3 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 1 | 1 | 0 | 0.00 | - | - |
| EDGE GIVE GROUND | 3 | 3 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 13 | 12 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 2 | 2 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 8 | 7 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 38 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 27 | 22 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 6 | 6 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 16 | 15 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 67 | 54 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 25 | 24 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 38 | 31 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 71 | 69 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 13 | 13 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 24 | 24 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 29 | 29 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 2 | 2 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN RUN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 82 | 82 | 0 | 0.00 | - | - |
| HONEST WORTH | 10 | 9 | 0 | 0.00 | - | - |
| HUNT IN PAIRS | 7 | 4 | 0 | 0.00 | - | - |
| HUNT KEPT | 1 | trace | - | - | - | - |
| HUNT RESULT | 2 | trace | - | - | - | - |
| HUNT THE GUNS | 3 | trace | - | - | - | - |
| KEPT FROM ITS LAST STOP | 11 | 11 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 11 | 10 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 17 | 17 | 0 | 0.00 | - | - |
| MOVE SPELL SPOT | 3 | not checked | - | - | - | - |
| NEXT OBJECTIVE NEARER | 1 | 1 | 0 | 0.00 | - | - |
| NO LATE CUT | 3 | 3 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 18 | 18 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT TURNED | 2 | 2 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 4 | not checked | - | - | - | - |
| ONE CHALLENGE TEST | 1 | 1 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 1 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 50 | 32 | 0 | 0.00 | - | - |
| OPENS A LANE | 1 | 1 | 0 | 0.00 | - | - |
| OVERRUNS AWAY | 3 | 2 | 0 | 0.00 | - | - |
| PLAN RESULT | 224 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE IN STEPS | 1 | 1 | 0 | 0.00 | - | - |
| REDIRECT COUNTER | 1 | 1 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 17 | 15 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 3 | 3 | 0 | 0.00 | - | - |
| RUN DOWN | 14 | 13 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 5 | 5 | 0 | 0.00 | - | - |
| SET-UP ANY TARGET | 2 | not checked | - | - | - | - |
| SHOOTER COUNTED ONCE | 2 | 2 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 57 | not checked | - | - | - | - |
| SPELL SETS UP CHARGE | 2 | not checked | - | - | - | - |
| SPELL WORTH | 8 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 36 | 34 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 2 | 2 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 6 | 5 | 0 | 0.00 | - | - |
| STANDS STILL | 154 | 149 | 0 | 0.00 | - | - |
| STOPS | 4 | 4 | 0 | 0.00 | - | - |
| SURE REACH TOGETHER | 2 | 2 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 8 | not checked | - | - | - | - |
| THE PROMISE ADDS | 3 | 3 | 0 | 0.00 | - | - |
| THE PROMISED MOVE | 3 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 13 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 9 | not checked | - | - | - | - |
| THE TABLE BINDS | 227 | not checked | - | - | - | - |
| WAITS AGAIN | 22 | 21 | 0 | 0.00 | - | - |
| WHO FIGHTS | 1 | 1 | 0 | 0.00 | - | - |
| WOUNDS ON THE RANKS | 12 | 12 | 0 | 0.00 | - | - |

### Off best figure: cnomg-c940641-p7

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 6.00 | 5.33 | 52.8 |
| PROMISE BY ITS OWN SUM | rule | 5.67 | 1.67 | 59.0 |
| ARMY TABLE | rule | 1.00 | 5.67 | 114.7 |
| MARCH OF THE TABLE | rule | 2.00 | 0.67 | 57.1 |
| RULE SWITCHED OFF | gate | 1.33 | - | 38.3 |
| CHARGE NOW FIRST | rule | 1.00 | - | 56.2 |
| PIVOT GUARDS FLANK | rule | 1.00 | - | 53.8 |
| PROMISE SHOT AWAY | rule | 1.00 | - | 7.7 |
| AFTERMATH BAND | gate | 0.33 | 0.33 | 2.6 |
| PROMISE READS THE TABLE | rule | 0.67 | - | 14.9 |
| WAR ENGINE JOBS | rule | 0.67 | - | 59.7 |
| FOLLOW UP WEIGHED | rule | - | 0.33 | 3.4 |
| ONE PROMISE A TARGET | rule | - | 0.33 | 51.2 |
| PATHS CROSS | rule | - | 0.33 | 13.7 |
| PROMISE KNOWS THE FIGHT | rule | 0.33 | - | 19.1 |
| REFUSING RETIRES | rule | - | 0.33 | 5.2 |
| SUPPORT NARROWED | rule | - | 0.33 | 19.8 |
| SWIFTSTRIDE BY POINTS | rule | 0.33 | - | 30.5 |

### Plans: cnomg-c940641-p7

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.7 | 80% | 205 | 233 | 114% |
| Mine | move | 19.3 | 95% | 1642 | 0 | 0% |
| Mine | shoot | 12.3 | 35% | 683 | 578 | 85% |
| Opponent | charge | 2.7 | 50% | 236 | 299 | 127% |
| Opponent | join | 2.0 | 100% | 125 | 0 | 0% |
| Opponent | move | 34.7 | 97% | 1654 | 0 | 0% |
| Opponent | shoot | 1.3 | 50% | 73 | 174 | 240% |
| Opponent | support | 0.7 | 100% | 63 | 0 | 0% |

### Packages: hunt the guns, cnomg-c940641-p7

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Opponent | 1.0 | 3 | 1 | 50% | 50% | 0% | 3.0 | 277 | 120 | 50% | 0 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Vampire Counts | 1.0 | 1 | 0 | 0% | 0% | 0% | - | 298 | 0 | 0% | 0 |
| Warriors of Chaos | 2.0 | 2 | 1 | 100% | 100% | 0% | 3.0 | 257 | 241 | 100% | 0 |

### Battle groups: cnomg-c940641-p7

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | REDIRECT COUNTER | 0.3 | 0% | - | - | - | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: cnomg-c940641-p7

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Character | 9 | 60 (9) | 60 | 0 | 27 | 22% | 2.3 | 81 (2) | 71 (5) | - | 77 (4) | 69 (3) |
| Mine | Clean-up | 2 | 74 (2) | 0 | 74 | 53 | 0% | 2.0 | 0 (1) | 139 (1) | - | 74 (2) | - |
| Mine | Fast Hammer | 4 | 56 (4) | 48 | 9 | 70 | 25% | 2.0 | 161 (2) | 13 (2) | - | 87 (3) | 0 (1) |
| Mine | Holder | 1 | 158 (1) | 0 | 158 | 0 | 100% | - | 158 (1) | - | - | 158 (1) | - |
| Mine | Shooter | 4 | 41 (4) | 30 | 11 | 0 | 0% | 2.5 | 37 (3) | 62 (1) | - | 41 (4) | - |
| Mine | War machine | 6 | 0 (6) | 0 | 0 | 50 | 0% | 1.0 | 0 (2) | 0 (2) | 0 (2) | 0 (1) | 0 (5) |
| Mine | Wizard | 3 | 0 (3) | 0 | 0 | 33 | 0% | 2.3 | 0 (2) | 0 (1) | - | 0 (3) | - |
| Opponent | Chaff | 2 | 300 (2) | 0 | 300 | 50 | 50% | 3.0 | - | 600 (1) | 0 (1) | 300 (2) | - |
| Opponent | Character | 10 | 31 (10) | 31 | 0 | 33 | 50% | 2.6 | 0 (3) | 66 (5) | 0 (2) | 58 (5) | 0 (5) |
| Opponent | Fast Hammer | 9 | 54 (9) | 13 | 41 | 36 | 44% | 3.2 | 70 (2) | 50 (7) | - | 39 (5) | 73 (4) |
| Opponent | Hammer | 3 | 143 (3) | 143 | 0 | 0 | 0% | 3.0 | 65 (2) | 275 (1) | - | 65 (2) | 275 (1) |
| Opponent | Holder | 5 | 28 (5) | 0 | 28 | 34 | 60% | 4.0 | 0 (1) | 50 (1) | 37 (3) | 31 (3) | 23 (2) |
| Opponent | Shooter | 1 | 93 (1) | 93 | 0 | 0 | 0% | 1.0 | - | 93 (1) | - | 93 (1) | - |
| Opponent | Wizard | 1 | 0 (1) | 0 | 0 | 100 | 0% | 2.0 | - | - | 0 (1) | - | 0 (1) |

### Charged fights: cnomg-c940641-p7

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Grand Cathay | 3 | 223 | 416 | 1.7 | 1.0 | 250 | 131 | +119 | 2 of 5 | 5 of 5 | - | +119 |
| Opponent | High Elf Realms | 1 | 165 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Vampire Counts | 1 | 0 | 194 | 4.0 | 1.0 | 48 | 15 | +34 | 1 of 4 | 3 of 4 | - | +34 |
| Opponent | Warriors of Chaos | 1 | 0 | 233 | 2.0 | 1.0 | 116 | 0 | +116 | 2 of 2 | 2 of 2 | - | +116 |
| **Opponent** | all armies | 3 | 55 | 142 | 2.0 | 1.0 | 71 | 10 | +61 | 3 of 6 | 5 of 6 | - | +61 |

### Effective charges: cnomg-c940641-p7

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Grand Cathay | 5 | 0 | 0 | 2 (net +20) | 0 | 0 | 2 (net +206) | 1 | 50% (2 of 4) |
| Opponent | Vampire Counts | 4 | 1 (net -60) | 0 | 0 | 0 | 0 | 3 (net +65) | 0 | 0% (0 of 4) |
| Opponent | Warriors of Chaos | 2 | 0 | 0 | 0 | 2 (net +116) | 0 | 0 | 0 | 0% (0 of 2) |

### Charged fights, damage counted: cnomg-c940641-p7

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Effective (55-75%) | 2 | 260 | 348 | +20 | 362 | 380 | -18 | -7.0 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 192 | 134 | +206 | 206 | 41 | +165 | +86.0 |
| Mine | No odds | 1 | 233 | 143 | +143 | 143 | 0 | +143 | +61.4 |
| Mine | All fights | 5 | 227 | 221 | +119 | 255 | 168 | +87 | +38.4 |
| Opponent | Long shot (under 50%) | 1 | 60 | 205 | -60 | 0 | 60 | -60 | -100.0 |
| Opponent | 76-89% | 2 | 116 | 233 | +116 | 116 | 0 | +116 | +100.4 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 | 185 | 205 | +65 | 99 | 64 | +35 | +19.0 |
| Opponent | All fights | 6 | 141 | 214 | +61 | 88 | 42 | +46 | +32.9 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| cnomg-c940641-p7 | move | 32 | 3 (9%) | 2 (6%) | 0 (0%) | 29 (91%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L1224 |
| Clockwork Compass | Mine | L1224 |
| Elixir of Power | Mine | L1114, L1131 |
| Invocation of Nehek | Opponent | L1224 |
| Opal Amulet | Opponent | L1114 |
| Ring of Doom | Mine | L1114, L1131, L1224 |
| Ring of Doom | Opponent | L1131 |
| Ring of Jet | Mine | L1114, L1131, L1224 |

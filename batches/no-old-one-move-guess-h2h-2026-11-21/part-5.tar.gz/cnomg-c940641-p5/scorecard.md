# Doctrine scorecard: cnomg-c940641-p5

### Scorecard: cnomg-c940641-p5

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0717 | 3 | 1 | Mine | no | 0 | 4 | 3 | 1 | 0 | 0 | 0 | 375 |
| L0717 | 3 | 1 | Opponent | yes | 7 | 4 | 1 | 1 | 1 | 0 | 0 | 141 |
| L0733 | 1 | 1 | Mine | no | 7 | 4 | 2 | 1 | 0 | 0 | 0 | 125 |
| L0733 | 1 | 1 | Opponent | no | 0 | 3 | 1 | 4 | 0 | 0 | 0 | 0 |
| L0823 | 1 | 1 | Mine | no | 19 | - | 0 | 1 | 0 | 0 | 0 | 515 |
| L0823 | 1 | 1 | Opponent | no | 0 | 2 | 3 | 2 | 0 | 0 | 0 | 195 |
| **Average** | | | Mine | 0% | 8.7 | 4.0 | 1.7 | 1.0 | 0.0 | 0.0 | 0.0 | 338.3 |
| **Average** | | | Opponent | 33% | 2.3 | 3.0 | 1.7 | 2.3 | 0.3 | 0.0 | 0.0 | 112.0 |

### KPIs: cnomg-c940641-p5

Rules off - Mine only: NO OLD ONE-MOVE GUESS.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 87% (13 of 15) | 0% (0 of 11) | 50% (13 of 26) |
| Winner chose to follow up after the loser gave ground |  | 100% (3 of 3); on the table 100% | 100% (4 of 4); on the table 100% | 100% (7 of 7); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | 100% (1 of 1); on the table 100% | - | 100% (1 of 1); on the table 100% |
| Winner chose to pursue after the loser fled |  | - | 67% (2 of 3); on the table 67% | 67% (2 of 3); on the table 67% |
| Winner chose to follow up or pursue (all three) |  | 100% (4 of 4); on the table 100% | 86% (6 of 7); on the table 86% | 91% (10 of 11); on the table 91% |
| Magic missiles tried each own turn | 50%+ | 67% (8 of 12) | 25% (3 of 12) | 46% (11 of 24) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 73% (8 of 11) | 38% (3 of 8) | 58% (11 of 19) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | - | - |
| Points that never fought | lower | 66% (3966 of 5998) | 57% (3435 of 6000) | 62% (7401 of 11998) |
|   infantry points that never fought | lower | 37% (267 of 715) | 55% (779 of 1418) | 49% (1046 of 2133) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 63% (19 of 30) | 68% (15 of 22) | 65% (34 of 52) |
| Bound items with a magic missile used (at least once a game) |  | 0.0 uses a game | 100% (2 of 2); 2.0 uses a game | 100% (2 of 2); 1.0 uses a game |
| Bound items with another spell used |  | 50% (1 of 2); 0.7 uses a game | 0.0 uses a game | 50% (1 of 2); 0.3 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 33% (1 of 3); 0.3 uses a game | 0% (0 of 1); 0.0 uses a game | 25% (1 of 4); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 60% (3213 of 5389) | 59% (2979 of 5023) | 59% (6192 of 10412) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 0.7 (50%) | 1.3 (44%) | 2.0 (46%) |
| MARCHED: its unit marched | 0.3 (25%) | 0.3 (11%) | 0.7 (15%) |
| IN COMBAT: engaged in combat | 0.3 (25%) | 0.0 (0%) | 0.3 (8%) |
| GONE: slain | 0.0 (0%) | 1.3 (44%) | 1.3 (31%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 3.0 | 1.3 | 3.7 | 0.3 | 0.7 |
| not cast | 5.0 | 0.7 | 4.3 | 1.7 | 11.3 |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.3 (50%) | 2.0 (46%) | 0.0 (0%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.7 (15%) | 0.3 (20%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.3 (50%) | 0.3 (8%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | 2.7 (53%) | 0.0 (0%) | 1.3 (31%) | 1.3 (80%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.3 (47%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 11.3 (100%) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 74% (70 of 95) | 60% (55 of 92) | 67% (125 of 187) |
|   cavalry | 75% (9 of 12) | 64% (9 of 14) | 69% (18 of 26) |
|   character | - | 53% (10 of 19) | 53% (10 of 19) |
|   chariot | 100% (2 of 2) | - | 100% (2 of 2) |
|   infantry | 65% (15 of 23) | 66% (35 of 53) | 66% (50 of 76) |
|   monster | - | 17% (1 of 6) | 17% (1 of 6) |
|   war machine | 76% (44 of 58) | - | 76% (44 of 58) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.7 (32%) | 1.0 (8%) | 3.7 (18%) |
| CHARGED: it charged | 0.0 (0%) | 2.0 (16%) | 2.0 (10%) |
| FLEEING: it fled or was fleeing | 0.0 (0%) | 0.7 (5%) | 0.7 (3%) |
| IN COMBAT: it fought this turn or the last | 0.3 (4%) | 1.0 (8%) | 1.3 (6%) |
| MOVED: a war machine that moved | 1.3 (16%) | 0.0 (0%) | 1.3 (6%) |
| NO TARGET IN RANGE | 0.3 (4%) | 4.3 (35%) | 4.7 (23%) |
| ONLY IN COMBAT: the only targets were in combat | 0.0 (0%) | 1.7 (14%) | 1.7 (8%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.7 (20%) | 1.7 (14%) | 3.3 (16%) |
| SHELTERED: the target was sheltered | 1.7 (20%) | 0.0 (0%) | 1.7 (8%) |
| OTHER BAR | 0.3 (4%) | 0.0 (0%) | 0.3 (2%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 9.0 | 3.3 | 74% | 9.3 pts | 83 pts |
| character | 3.3 | 0.3 | 90% | 2.1 pts | 7 pts |
| chariot | 0.7 | 0.7 | 50% | 48.9 pts | 33 pts |
| infantry | 24.3 | 5.7 | 84% | 5.3 pts | 128 pts |
| monster | 0.3 | 0.0 | 100% | 0.0 pts | 0 pts |
| war machine | 14.7 | 9.7 | 68% | 24.9 pts | 365 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 1.7 | 3.7 | 2.7 |
| Charges that made contact a game | 1.0 | 2.7 | 1.8 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.00 declared, 0.00 contact (2 units) | - | 0.00 declared, 0.00 contact (2 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 0.00 declared, 0.00 contact (1 units) | 0.00 declared, 0.00 contact (1 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.22 declared, 0.13 contact (23 units) | 0.38 declared, 0.28 contact (29 units) | 0.31 declared, 0.21 contact (52 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 67% (6 of 9) | 33% (1 of 3) | - | 58% (7 of 12) |
| Character in a unit | 83% (5 of 6) | - | 100% (1 of 1) | 86% (6 of 7) |
| Character on its own | 67% (2 of 3) | 100% (1 of 1) | 33% (2 of 6) | 50% (5 of 10) |
| Chariot | - | 100% (1 of 1) | - | 100% (1 of 1) |
| Infantry | 50% (1 of 2) | 33% (1 of 3) | 0% (0 of 1) | 33% (2 of 6) |
| Monster | 80% (4 of 5) | - | - | 80% (4 of 5) |
| Monstrous | 100% (1 of 1) | - | - | 100% (1 of 1) |
| War Machines | 80% (8 of 10) | - | - | 80% (8 of 10) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Empire of Man | 3 | 100% (4 of 4); on the table 100% | 67% (8 of 12) | 66% | 63% (19 of 30) | 0.0 uses a game | 50% (1 of 2); 0.7 uses a game | 33% (1 of 3); 0.3 uses a game |
| Lizardmen | 1 | 100% (1 of 1); on the table 100% | - | 66% | 71% (5 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Tomb Kings of Khemri | 1 | 100% (4 of 4); on the table 100% | 33% (2 of 6) | 59% | 40% (2 of 5) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 1 | 50% (1 of 2); on the table 50% | 17% (1 of 6) | 47% | 80% (8 of 10) | 100% (2 of 2); 6.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (cnomg-c940641-p5, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 33% (2) | - | 33% (2) |
| ...free all their last turn and able to turn (per game) | 0.33 | 0.00 | 0.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.33 | 0.00 | 0.33 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.33 | 0.33 |

### Quality by phase: cnomg-c940641-p5

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.3 | 2.0 |
| Strategy | Charge objectives carried out (made contact) | 75% (3 of 4) | 56% (5 of 9) |
| Strategy | Shoot objectives carried out (shot that target) | 14% (8 of 57) | 70% (7 of 10) |
| Strategy | Hexes on a unit its side charged or shot that turn | 0% (0 of 3) | - |
| Strategy | Joined characters whose unit fought | 25% (1 of 4) | 25% (1 of 4) |
| Strategy | Lone characters that fought | 33% (3 of 9) | 33% (2 of 6) |
| Movement | Charges halted short of contact | 0.0 | 0.7 |
| Movement | Idle units | 1.0 | 2.3 |
| Movement | Points that never moved of their own | 338.3 | 112.0 |
| Movement | Fights charged into per game | 1.0 | 2.7 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 3 | 3 of 5, net -102 |
| Movement | Charges with odds: sweet spot (55-75%) | 1 of 3, net +236 | 0 of 5 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 3 | 1 of 5, net +0 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 0 of 3 | 1 of 5, net +265 |
| Shooting | Shots by shooting units (incl. breath weapons) | 9.7 | 21.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 66% (19 of 29) | 48% (30 of 63) |
| Shooting | Points destroyed by shooting units | 65.0 | 15.0 |
| Shooting | War machine shots | 14.7 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 70% (31 of 44) | - |
| Shooting | Points destroyed by war machines | 163.7 | 0.0 |
| Magic | Magic missiles cast | 2.3 | 1.0 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 14% (1 of 7) | 67% (2 of 3) |
| Magic | Wounds caused by magic missiles | 6.3 | 2.0 |
| Magic | Wounds caused by other spells | 2.3 | - |
| Magic | Points destroyed by magic (all spells) | 224.3 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.0 / 1.0 / 0.3 / 0.0 | 2.0 / 0.0 / 0.0 / 0.3 |
| Combat | Points destroyed in combat | 130.3 | 184.0 |
| Combat | Points run down | 0.0 | 63.0 |
| Combat | Net points per charged fight, damage counted | +119 | +53 |
| Combat | Net per 100 charger points, damage counted | +64.1 | +25.6 |
| Combat | First round won (charged fights) | 67% | 38% |
| Combat | Net points per charged fight | +79 | +59 |
| Combat | Net points per supported fight / lone fight | - / +79 | - / +59 |
| Combat | Charged fights on a top-3 enemy unit | 1 of 3 | 6 of 8 |
| Game | Points lost | 392.0 | 662.0 |
| Game | VP from objectives | 870.0 | 773.3 |
| Game | Lone holders (player turns) | 8.7 | 2.3 |

- Mine won / drew / lost: 1 / 2 / 0 of 3 ended games (of 3); mean margin (Mine - Opponent) +456 VP
- The side that went first won 0 of 1 games with a winner
- Points traded per game (both sides' losses): 1054
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: cnomg-c940641-p5

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 36.0 |
| AFTERMATH WITH FRIENDS | 0.3 | +9.1 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | 14.3 | +143.3 | 0.0 | 0.0 | 25.0 | +750.2 | 0.0 | 502.3 |
| ARRIVAL HUNT | - | - | - | - | 0.3 | +0.2 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 4.7 | +0.0 | 0.0 | 126.7 | - | - | - | - |
| BEST PRIZE | - | - | - | - | 0.3 | -104.3 | 0.0 | 0.0 |
| CANNON PLAN MISSED | 1.7 | +0.0 | 280.3 | 0.0 | - | - | - | - |
| CANNON PLANNED TARGET | 13.7 | +1107.3 | 686.0 | 343.3 | - | - | - | - |
| CANNON SIGHT KEPT | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CAST JOB | 2.7 | +196.1 | 289.3 | 0.0 | 0.3 | +6.3 | 0.0 | 0.0 |
| CASTER AWAY FROM SCREEN | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | - | - | - | - | 2.0 | +149.4 | 0.0 | 12.7 |
| CHALLENGE BY POINTS | - | - | - | - | 0.3 | +3.0 | 0.0 | 0.0 |
| CHARACTER GUNS | - | - | - | - | 6.7 | +0.0 | 0.0 | 0.0 |
| CHARGE LOSSES | 23.3 | -917.1 | 0.0 | 0.0 | 17.0 | -1315.3 | 0.0 | 338.7 |
| CHARGE NOW FIRST | 0.7 | +0.0 | 78.7 | 0.0 | 1.7 | +0.0 | 67.3 | 0.0 |
| CLOSES ON WHAT IT BEATS | 6.3 | +0.0 | 0.0 | 0.0 | 14.3 | +0.0 | 0.0 | 197.3 |
| COMBAT PIVOT | 0.7 | +0.0 | 0.0 | 88.3 | 0.3 | +0.0 | 41.7 | 0.0 |
| COVER ONCE | 10.7 | -488.7 | 0.0 | 25.7 | 9.0 | -383.2 | 0.0 | 136.0 |
| DENIED BY THE FIGHT | 1.0 | -13.2 | 0.0 | 63.0 | - | - | - | - |
| DEPLOY BY FIGURES | 8.7 | -71.5 | 0.0 | 0.0 | 8.7 | +28.7 | 0.0 | 101.0 |
| DUEL STOPS AT THE KILL | 0.3 | -12.4 | 78.7 | 0.0 | - | - | - | - |
| EDGE GIVE GROUND | 0.3 | +21.5 | 78.7 | 0.0 | - | - | - | - |
| EXACT ROUND | 1.0 | -23.4 | 0.0 | 63.0 | 2.7 | +69.3 | 130.0 | 110.3 |
| FALL BACK GOOD ORDER | 1.7 | +0.0 | 78.7 | 63.0 | 2.0 | +6.2 | 155.7 | 65.0 |
| FALLBACK BY WORTH | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FALLS SHORT | - | - | - | - | 17.0 | +267.8 | 0.0 | 241.0 |
| FEATURE BUFFS | 0.7 | +2.1 | 0.0 | 0.0 | - | - | - | - |
| FIGHT TO THE END | 1.0 | +1.0 | 78.7 | 63.0 | 0.7 | +28.4 | 0.0 | 65.0 |
| FIRE IN ORDER | 1.3 | +0.0 | 116.7 | 0.0 | - | - | - | - |
| FIVE ACTION | 113.3 | +9927.5 | 2223.3 | 801.0 | 81.7 | +5564.6 | 185.7 | 1336.3 |
| FLANK NOT WEIGHED | 8.0 | +0.0 | 0.0 | 15.0 | 6.7 | +0.0 | 0.0 | 0.0 |
| FOLLOW UP WEIGHED | 0.7 | +149.0 | 0.0 | 63.0 | 0.7 | +227.4 | 0.0 | 0.0 |
| FOUR ROUNDS | 1.7 | +88.5 | 78.7 | 63.0 | 3.0 | +301.0 | 155.7 | 110.3 |
| FREED FROM HIS FIGHT | 2.0 | +0.0 | 0.0 | 0.0 | 5.7 | +0.0 | 0.0 | 6.3 |
| FRIEND SHOOTS FIRST | 2.3 | -129.0 | 0.0 | 0.0 | - | - | - | - |
| GIVES UP | 0.3 | -5.5 | 0.0 | 0.0 | 0.3 | -2.4 | 0.0 | 65.0 |
| GOAL WALK | 5.3 | +292.5 | 0.0 | 0.0 | 18.7 | +1407.7 | 0.0 | 188.7 |
| GUN FIGURES | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| GUN MASK | 4.7 | +111.6 | 0.0 | 0.0 | - | - | - | - |
| HARD STAY DROPPED | 1.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 0.7 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 14.7 | +0.0 | 0.0 | 0.0 | 10.3 | +0.0 | 0.0 | 69.3 |
| HIS CHARGE LIST | 1.7 | +0.0 | 0.0 | 0.0 | 6.3 | +0.0 | 0.0 | 238.0 |
| HIS LEGAL MOVES | 3.7 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 3.0 | -45.8 | 0.0 | 0.0 | 0.7 | -16.8 | 0.0 | 0.0 |
| HIS MOVE AS HE DECIDES | 40.0 | +10.7 | 566.0 | 0.0 | - | - | - | - |
| HIS MOVE WHY | - | - | - | - | 13.0 | +0.0 | 0.0 | 230.7 |
| HIS ONE MOVE | 21.0 | -106.1 | 0.0 | 0.0 | - | - | - | - |
| HIS ONE QUARTER | 8.3 | +0.0 | 0.0 | 0.0 | 5.7 | +0.0 | 0.0 | 217.3 |
| HIS OWN BEST MOVE | 2.0 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 47.0 | +1452.6 | 0.0 | 51.3 | 57.0 | +2909.1 | 0.0 | 1068.7 |
| HIS SHOTS BY HIS RUN | 42.3 | +1010.9 | 0.0 | 51.3 | 40.7 | +1821.6 | 0.0 | 620.3 |
| HIS TURN DENIED | 1.3 | +36.9 | 0.0 | 63.0 | 0.7 | +31.1 | 41.7 | 0.0 |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 26.3 | +0.0 | 0.0 | 51.3 | 18.3 | +0.0 | 0.0 | 116.0 |
| HOLDER ASSIGNMENT | 16.0 | +1439.3 | 0.0 | 25.7 | 14.7 | +1205.8 | 0.0 | 194.7 |
| HOLDS AMBUSHERS | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 1.7 | -56.6 | 78.7 | 63.0 | 2.3 | -126.9 | 155.7 | 65.0 |
| HUNT IN PAIRS | - | - | - | - | 1.3 | +32.7 | 0.0 | 0.0 |
| IDLE COST | - | - | - | - | 13.7 | -213.3 | 0.0 | 222.7 |
| JOINT CHARGE NOW | 0.3 | +20.3 | 0.0 | 0.0 | - | - | - | - |
| KEEP FALLS | 0.3 | +3.5 | 0.0 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 5.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 44.0 |
| LANE BY FIGURES | 0.3 | +17.2 | 0.0 | 0.0 | 1.3 | +85.6 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| LEGAL CHARGES ONLY | 6.7 | +0.0 | 26.3 | 279.3 | 11.3 | +0.0 | 88.7 | 108.3 |
| LONE CHARACTER SAFE SPOT | 0.3 | +0.0 | 0.0 | 15.0 | - | - | - | - |
| LONE WIZARD KEPT IN | 0.3 | +19.8 | 0.0 | 0.0 | 0.3 | +37.5 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | 1.0 | -1.0 | 0.0 | 63.0 | 1.3 | +0.4 | 25.7 | 110.3 |
| MANOEUVRE | - | - | - | - | 0.7 | -4.2 | 0.0 | 0.0 |
| MARCH AT ESCAPER | - | - | - | - | 0.3 | +4.3 | 0.0 | 36.0 |
| MARCH BY THE SUM | 0.3 | +2.9 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | 0.3 | +26.6 | 0.0 | 0.0 | 0.3 | +6.0 | 0.0 | 36.0 |
| MARCH OVER CASTS | 0.3 | -6.4 | 0.0 | 0.0 | 0.3 | +9.9 | 0.0 | 36.0 |
| MARCH WHEELS ONLY | 1.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 44.0 |
| MAX FOR POSITIONING | 2.0 | +76.1 | 0.0 | 0.0 | 1.3 | +46.1 | 0.0 | 0.0 |
| MEETS IN TIME | 4.3 | +404.6 | 0.0 | 0.0 | 4.0 | +319.6 | 0.0 | 36.0 |
| MISSILES IN THE MOVE | 2.7 | +200.5 | 0.0 | 0.0 | 3.7 | +39.7 | 0.0 | 147.3 |
| MISSILES NEXT TURN | 3.0 | +100.1 | 0.0 | 0.0 | 3.3 | +27.1 | 0.0 | 114.0 |
| MOVE ORDER | 1.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 6.3 | 215.0 |
| MOVE TO CHARGE COMPUTED | 6.3 | +556.1 | 0.0 | 0.0 | 2.7 | +228.5 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 6.3 | +265.4 | 0.0 | 0.0 | 9.7 | +477.5 | 0.0 | 98.7 |
| NEXT CHARGE BY LIST | 3.7 | +281.5 | 0.0 | 0.0 | 1.3 | +131.5 | 0.0 | 0.0 |
| NEXT OBJECTIVE NEARER | - | - | - | - | 0.3 | -10.1 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 1.7 | -38.5 | 78.7 | 63.0 | 3.0 | -127.1 | 155.7 | 110.3 |
| NO LATE CUT | 1.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | - | - | - | - | 0.3 | +3.3 | 0.0 | 0.0 |
| NOT WORTH A CAST | 2.3 | -1.0 | 0.0 | 28.3 | - | - | - | - |
| OFF BEST | 6.7 | -307.9 | 0.0 | 69.0 | 4.7 | -90.3 | 0.0 | 78.0 |
| ONE CHECK AFTER THE LAST CHANGE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ONE FIGHT FORMULA | 6.0 | -127.4 | 0.0 | 0.0 | 3.7 | -93.3 | 0.0 | 0.0 |
| ONE OBJECTIVE FORMULA | 5.0 | -12.6 | 0.0 | 25.7 | 5.3 | -38.5 | 0.0 | 36.0 |
| ONE PROMISE A TARGET | - | - | - | - | 0.7 | -66.5 | 0.0 | 0.0 |
| ONE ROUTE | 1.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 44.0 |
| OPENS A LANE | 0.3 | +1.5 | 6.3 | 0.0 | - | - | - | - |
| OPENS UP | - | - | - | - | 0.3 | +12.3 | 25.7 | 0.0 |
| OVERRUNS AWAY | - | - | - | - | 1.0 | +67.4 | 43.3 | 65.0 |
| PLAN RESULT | 52.3 | +1549.3 | 243.0 | 550.7 | 38.3 | +151.8 | 99.0 | 679.3 |
| PROMISE BELOW ZERO | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE BY ITS OWN SUM | 9.0 | -155.7 | 0.0 | 0.0 | 6.3 | -108.8 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | 1.3 | -79.1 | 0.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | 31.7 | +3033.4 | 277.3 | 520.0 | 19.0 | +2514.3 | 130.0 | 309.3 |
| REAL GROUND | 1.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 44.0 |
| REDIRECT BY WHAT IT STOPS | - | - | - | - | 2.7 | +113.5 | 0.0 | 0.0 |
| REDIRECT COUNTER | - | - | - | - | 2.7 | +56.0 | 0.0 | 6.3 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 4.0 | +146.1 | 0.0 | 22.0 |
| REDIRECT WEIGHED | - | - | - | - | 0.3 | +10.0 | 41.7 | 0.0 |
| REFORMS TO MEET IT | 0.7 | -3.1 | 0.0 | 0.0 | 0.3 | -2.4 | 0.0 | 0.0 |
| RESERVE FALL BACK | - | - | - | - | 0.3 | +20.1 | 0.0 | 0.0 |
| RISK BY ARC | 1.7 | +65.7 | 78.7 | 63.0 | 2.3 | -232.6 | 110.7 | 87.0 |
| RISK ON THE WAY | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ROUNDS AFTER TERROR | - | - | - | - | 1.0 | -24.0 | 69.0 | 65.0 |
| RUN DOWN | 1.7 | -9.7 | 78.7 | 63.0 | 2.0 | -4.3 | 114.0 | 87.0 |
| SCOUT SPOT | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +1.8 | 0.0 | 0.0 |
| SCOUT WAITS | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| SEARCH SPOT | 1.0 | +39.8 | 0.0 | 0.0 | 0.7 | -5.5 | 0.0 | 0.0 |
| SET CREDITED ONCE | 2.7 | -107.0 | 0.0 | 0.0 | 0.3 | -0.3 | 0.0 | 0.0 |
| SET UP BY THE SET | 4.0 | +47.3 | 0.0 | 0.0 | 0.3 | +0.3 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | - | - | - | - | 0.7 | +3.0 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 22.7 | +0.0 | 0.0 | 373.3 | 3.3 | +0.0 | 0.0 | 78.7 |
| SHOOTS FROM THE BEST SPOT | 1.3 | +187.4 | 294.7 | 0.0 | 1.0 | +13.4 | 0.0 | 0.0 |
| SHORT GUN FORWARD | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SHOT OR CHARGE | - | - | - | - | 0.3 | -5.2 | 0.0 | 65.0 |
| SHOT RISK POINTS | 33.0 | -521.7 | 0.0 | 0.0 | 34.3 | +550.6 | 0.0 | 776.0 |
| SHOTS AFTER THE MOVES | 5.7 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 25.3 | +1903.9 | 0.0 | 369.0 | 17.0 | +279.0 | 0.0 | 111.3 |
| SPELL WORTH | 0.3 | +3.1 | 28.3 | 28.3 | 2.7 | +33.8 | 78.0 | 156.0 |
| SPELLS IN THE FIGHT | 0.3 | +0.8 | 0.0 | 0.0 | - | - | - | - |
| SPOT AS THE GAME MOVES | 7.0 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 70.7 |
| STAND AND SHOOT | 1.0 | -20.3 | 78.7 | 63.0 | - | - | - | - |
| STANDS FOR A REASON | - | - | - | - | 4.3 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 65.3 | +0.0 | 2144.7 | 686.7 | 13.0 | +0.0 | 30.0 | 279.3 |
| STAY WORTH | 46.0 | +555.7 | 1594.7 | 630.0 | 14.0 | +61.6 | 30.0 | 215.0 |
| STRIKE BY THE ODDS | - | - | - | - | 1.0 | +23.5 | 28.3 | 150.0 |
| SUPPORT ADDS | 2.0 | +284.3 | 0.0 | 0.0 | 2.0 | +139.6 | 0.0 | 0.0 |
| SUPPORT NARROWED | 0.7 | +0.0 | 78.7 | 0.0 | - | - | - | - |
| SUPPORT WORKED OUT | 2.0 | +284.3 | 0.0 | 0.0 | 2.0 | +139.6 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 1.7 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 36.0 |
| THE ROW IN ITS ORDER | 3.3 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 65.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 1.0 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 69.3 |
| THE ROW READS HIS LAST RUN | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 1.0 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 54.0 | +0.0 | 0.0 | 399.0 | 38.7 | +0.0 | 0.0 | 556.3 |
| TIED UP BY THE SUM | 0.3 | +35.6 | 0.0 | 0.0 | 1.3 | +152.2 | 110.7 | 0.0 |
| TIME ON OUR SIDE | 45.3 | +460.7 | 0.0 | 40.7 | - | - | - | - |
| WAITS AGAIN | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| WEAPON BY POINTS | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WHO FIGHTS | 0.7 | -4.5 | 0.0 | 63.0 | 1.0 | +37.9 | 0.0 | 110.3 |
| WHO HITS BACK | 0.7 | +105.2 | 0.0 | 0.0 | 0.3 | +32.6 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | 2.3 | -331.3 | 0.0 | 0.0 | 2.3 | -153.9 | 0.0 | 69.3 |
| WOUNDS ON THE RANKS | 9.0 | +209.9 | 0.0 | 0.0 | 2.3 | +63.6 | 0.0 | 36.0 |

### Rule changes: cnomg-c940641-p5

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS MOVE AS HE DECIDES | 120 | 120 | 88 | 29.33 | +0 | +0.0 |
| HOLDER ASSIGNMENT | 92 | 92 | 81 | 27.00 | +4059 | +50.1 |
| ARMY TABLE | 118 | 118 | 75 | 25.00 | +2192 | +29.2 |
| HIS SHOT LIST | 312 | 305 | 70 | 23.33 | +1353 | +19.3 |
| LEGAL CHARGES ONLY | 54 | 54 | 54 | 18.00 | +0 | +0.0 |
| HIS SHOTS BY HIS RUN | 249 | 238 | 45 | 15.00 | +1209 | +26.9 |
| OFF BEST | 34 | 34 | 34 | 11.33 | -1194 | -35.1 |
| DEPLOY BY FIGURES | 52 | 52 | 33 | 11.00 | +478 | +14.5 |
| QUARTER ODDS | 152 | 148 | 28 | 9.33 | +2297 | +82.0 |
| FIVE ACTION | 585 | 569 | 27 | 9.00 | +1568 | +58.1 |
| HIS MOVE WHY | 39 | 39 | 27 | 9.00 | +0 | +0.0 |
| SHOT RISK POINTS | 202 | 194 | 26 | 8.67 | +703 | +27.0 |
| THE TABLE AGAIN | 36 | 36 | 25 | 8.33 | +0 | +0.0 |
| HIS ONE MOVE | 63 | 62 | 18 | 6.00 | +0 | +0.0 |
| PROMISE BY ITS OWN SUM | 46 | 46 | 17 | 5.67 | -794 | -46.7 |
| TIME ON OUR SIDE | 136 | 109 | 17 | 5.67 | +32 | +1.9 |
| GOAL WALK | 72 | 72 | 16 | 5.33 | +506 | +31.6 |
| ARTILLERY RE-ROLL WEIGHED | 14 | 14 | 14 | 4.67 | +0 | +0.0 |
| MOVE TO CHARGE COMPUTED | 27 | 26 | 14 | 4.67 | +925 | +66.0 |
| REDIRECT FOR A FRIEND IN REACH | 12 | 12 | 12 | 4.00 | +190 | +15.9 |
| CHARGE LOSSES | 121 | 118 | 11 | 3.67 | +850 | +77.3 |
| FOUR ROUNDS | 14 | 14 | 10 | 3.33 | +366 | +36.6 |
| MEETS IN TIME | 25 | 25 | 9 | 3.00 | +266 | +29.5 |
| MOVE ORDER | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| CAST JOB | 9 | 9 | 8 | 2.67 | +63 | +7.9 |
| COVER ONCE | 59 | 40 | 8 | 2.67 | +512 | +63.9 |
| HARD STAY DROPPED | 8 | 8 | 8 | 2.67 | +0 | +0.0 |
| NEXT CHARGE BY LIST | 15 | 14 | 8 | 2.67 | +478 | +59.7 |
| STAY WORTH | 180 | 159 | 8 | 2.67 | +38 | +4.8 |
| SET UP BY THE SET | 13 | 12 | 7 | 2.33 | +332 | +47.4 |
| ADVANCE LANE KEPT | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| RISK BY ARC | 12 | 12 | 6 | 2.00 | +182 | +30.3 |
| SUPPORT ADDS | 12 | 12 | 6 | 2.00 | +257 | +42.8 |
| SUPPORT WORKED OUT | 12 | 12 | 6 | 2.00 | +257 | +42.8 |
| CANNON SIGHT KEPT | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| LANE BY FIGURES | 5 | 5 | 5 | 1.67 | +308 | +61.7 |
| SHOTS IN THE MOVE | 127 | 90 | 5 | 1.67 | +256 | +51.2 |
| FIRE IN ORDER | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 4 | 4 | 4 | 1.33 | +1129 | +282.4 |
| GUN MASK | 14 | 14 | 4 | 1.33 | +125 | +31.3 |
| SCOUT WAITS | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| CHAFF IN THE MOVE | 6 | 3 | 3 | 1.00 | +72 | +24.0 |
| COMBAT PIVOT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| EXACT ROUND | 11 | 11 | 3 | 1.00 | +38 | +12.7 |
| HIS TURN DENIED | 6 | 6 | 3 | 1.00 | +72 | +24.0 |
| MAX FOR POSITIONING | 10 | 9 | 3 | 1.00 | +19 | +6.2 |
| SEARCH SPOT | 5 | 5 | 3 | 1.00 | +120 | +39.8 |
| SHOOTS FROM THE BEST SPOT | 7 | 7 | 3 | 1.00 | +58 | +19.4 |
| STRIKE BY THE ODDS | 3 | 3 | 3 | 1.00 | +70 | +23.4 |
| THE ROW IN ITS ORDER | 17 | 3 | 3 | 1.00 | +0 | +0.0 |
| TIED UP BY THE SUM | 5 | 5 | 3 | 1.00 | +133 | +44.5 |
| WHO HITS BACK | 3 | 3 | 3 | 1.00 | +389 | +129.7 |
| CHARGE NOW FIRST | 7 | 7 | 2 | 0.67 | -75 | -37.3 |
| IDLE COST | 41 | 22 | 2 | 0.67 | +18 | +9.1 |
| LONE WIZARD KEPT IN | 2 | 2 | 2 | 0.67 | +172 | +86.0 |
| ONE PROMISE A TARGET | 2 | 2 | 2 | 0.67 | -200 | -99.8 |
| REDIRECT BY WHAT IT STOPS | 8 | 8 | 2 | 0.67 | +0 | +0.0 |
| SHOOTERS IN TWO RANKS | 2 | 2 | 2 | 0.67 | +9 | +4.5 |
| SUPPORT NARROWED | 2 | 2 | 2 | 0.67 | -255 | -127.4 |
| WHOLE FIGHT DANGER | 14 | 14 | 2 | 0.67 | +384 | +192.0 |
| AFTERMATH WITH FRIENDS | 1 | 1 | 1 | 0.33 | +27 | +27.3 |
| BEST PRIZE | 1 | 1 | 1 | 0.33 | -313 | -312.8 |
| CASTER AWAY FROM SCREEN | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CHALLENGE BY POINTS | 1 | 1 | 1 | 0.33 | +9 | +9.1 |
| EDGE GIVE GROUND | 1 | 1 | 1 | 0.33 | +6 | +5.6 |
| FALL BACK GOOD ORDER | 11 | 11 | 1 | 0.33 | +17 | +17.1 |
| HOLDS AMBUSHERS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| JOINT CHARGE NOW | 1 | 1 | 1 | 0.33 | +61 | +60.8 |
| KEEP FALLS | 1 | 1 | 1 | 0.33 | +50 | +50.0 |
| MARCH BY THE SUM | 1 | 1 | 1 | 0.33 | +9 | +8.7 |
| MARCH CHECK | 2 | 2 | 1 | 0.33 | +80 | +79.8 |
| MISSILES IN THE MOVE | 19 | 14 | 1 | 0.33 | +47 | +46.7 |
| NEARER NOT NEEDED | 48 | 45 | 1 | 0.33 | +41 | +40.9 |
| OPENS UP | 1 | 1 | 1 | 0.33 | +17 | +17.1 |
| OVERRUNS AWAY | 3 | 3 | 1 | 0.33 | +28 | +28.0 |
| REDIRECT WEIGHED | 1 | 1 | 1 | 0.33 | +76 | +75.8 |
| RESERVE FALL BACK | 1 | 1 | 1 | 0.33 | +60 | +60.4 |
| SHORT GUN FORWARD | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| SHOTS AFTER THE MOVES | 24 | 24 | 1 | 0.33 | +0 | +0.0 |
| WEAPON BY POINTS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| WHO FIGHTS | 5 | 5 | 1 | 0.33 | +4 | +4.0 |
| WOUNDS ON THE RANKS | 34 | 33 | 1 | 0.33 | +24 | +23.8 |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 5 | 5 | 0 | 0.00 | - | - |
| CANNON PLANNED TARGET | 41 | 41 | 0 | 0.00 | - | - |
| CHARACTER GUNS | 20 | 14 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 62 | 60 | 0 | 0.00 | - | - |
| DENIED BY THE FIGHT | 3 | 3 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 1 | 1 | 0 | 0.00 | - | - |
| FALLBACK BY WORTH | 1 | 1 | 0 | 0.00 | - | - |
| FALLS SHORT | 51 | 43 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 2 | 2 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 5 | 5 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 44 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 23 | 21 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 7 | 7 | 0 | 0.00 | - | - |
| GIVES UP | 2 | 2 | 0 | 0.00 | - | - |
| GUN FIGURES | 2 | not checked | - | - | - | - |
| HE REFORMS ONCE FREED | 14 | 13 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 75 | 74 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 24 | 24 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 22 | 18 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 11 | 11 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 42 | 39 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 18 | 16 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN RUN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 134 | 134 | 0 | 0.00 | - | - |
| HONEST WORTH | 12 | 12 | 0 | 0.00 | - | - |
| HUNT IN PAIRS | 4 | 3 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 21 | 21 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 2 | 2 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 1 | not checked | - | - | - | - |
| LOST AFTER ESCAPE | 7 | 7 | 0 | 0.00 | - | - |
| MANOEUVRE | 2 | 2 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 2 | 2 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 5 | 5 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 19 | 13 | 0 | 0.00 | - | - |
| NEXT OBJECTIVE NEARER | 1 | 1 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 14 | 14 | 0 | 0.00 | - | - |
| NO LATE CUT | 5 | 5 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 18 | 18 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT TURNED | 1 | 1 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 7 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 1 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 29 | 17 | 0 | 0.00 | - | - |
| ONE OBJECTIVE FORMULA | 31 | 26 | 0 | 0.00 | - | - |
| ONE ROUTE | 5 | 5 | 0 | 0.00 | - | - |
| OPENS A LANE | 1 | not checked | - | - | - | - |
| PLAN RESULT | 272 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 2 | 2 | 0 | 0.00 | - | - |
| PROMISE KNOWS THE FIGHT | 3 | 3 | 0 | 0.00 | - | - |
| PROMISE READS THE TABLE | 4 | 4 | 0 | 0.00 | - | - |
| REAL GROUND | 5 | 5 | 0 | 0.00 | - | - |
| REDIRECT COUNTER | 8 | 4 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 3 | 3 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 2 | 2 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 3 | 3 | 0 | 0.00 | - | - |
| RUN DOWN | 11 | 11 | 0 | 0.00 | - | - |
| SCOUT SPOT | 4 | 4 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 9 | 8 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 78 | not checked | - | - | - | - |
| SHOT OR CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| SPELL WORTH | 9 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 32 | 29 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 3 | 3 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 13 | 13 | 0 | 0.00 | - | - |
| STANDS STILL | 235 | 229 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 12 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 12 | not checked | - | - | - | - |
| THE ROW READS HIS LAST RUN | 1 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 8 | not checked | - | - | - | - |
| THE TABLE BINDS | 278 | not checked | - | - | - | - |
| WAITS AGAIN | 4 | 4 | 0 | 0.00 | - | - |

### Off best figure: cnomg-c940641-p5

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 6.33 | 4.67 | 33.3 |
| PROMISE BY ITS OWN SUM | rule | 3.00 | 2.67 | 46.7 |
| ARMY TABLE | rule | 1.33 | 3.67 | 38.3 |
| HOLDER ASSIGNMENT | rule | 0.67 | 2.00 | 15.0 |
| CHARGE NOW FIRST | rule | 0.33 | 0.33 | 37.3 |
| ONE PROMISE A TARGET | rule | - | 0.67 | 99.8 |
| SUPPORT NARROWED | rule | 0.67 | - | 127.4 |
| BEST PRIZE | rule | - | 0.33 | 312.8 |
| RULE SWITCHED OFF | gate | 0.33 | - | 94.1 |

### Plans: cnomg-c940641-p5

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.3 | 75% | 194 | 124 | 64% |
| Mine | join | 3.0 | 89% | 40 | 0 | 0% |
| Mine | move | 32.0 | 100% | 2055 | 0 | 0% |
| Mine | shoot | 16.0 | 65% | 1544 | 1425 | 92% |
| Opponent | charge | 2.3 | 43% | 298 | 94 | 31% |
| Opponent | move | 32.0 | 90% | 2317 | 0 | 0% |
| Opponent | shoot | 2.7 | 50% | 187 | 58 | 31% |
| Opponent | support | 1.3 | 100% | 86 | 0 | 0% |

### Battle groups: cnomg-c940641-p5

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | REDIRECT COUNTER | 2.7 | 0% | - | - | - | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: cnomg-c940641-p5

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | - | 0 (1) | 0 (1) | - |
| Mine | Character | 12 | 55 (12) | 55 | 0 | 2 | 67% | 2.5 | 72 (7) | 0 (2) | 72 (3) | 86 (7) | 0 (5) |
| Mine | Clean-up | 1 | 55 (1) | 0 | 55 | 0 | 100% | - | - | 55 (1) | - | 55 (1) | - |
| Mine | Fast Hammer | 8 | 50 (8) | 13 | 37 | 12 | 62% | 3.3 | 61 (4) | 43 (3) | 25 (1) | 68 (4) | 29 (4) |
| Mine | Hammer | 2 | 81 (2) | 43 | 38 | 42 | 0% | 1.5 | - | 0 (1) | 139 (1) | 81 (2) | - |
| Mine | Shooter | 5 | 146 (5) | 0 | 146 | 16 | 0% | 1.4 | 117 (2) | 201 (1) | 117 (2) | 160 (3) | 117 (2) |
| Mine | War machine | 10 | 39 (10) | 39 | 0 | 41 | 0% | 1.7 | 0 (8) | 196 (2) | - | 0 (1) | 43 (9) |
| Mine | Wizard | 1 | 0 (1) | 0 | 0 | 100 | 0% | 2.0 | - | - | - | - | - |
| Opponent | Chaff | 4 | 0 (4) | 0 | 0 | 50 | 50% | 1.0 | 0 (3) | 0 (1) | - | 0 (4) | - |
| Opponent | Character | 9 | 32 (9) | 32 | 0 | 14 | 22% | 1.9 | 0 (1) | 46 (5) | 27 (3) | 32 (5) | 32 (4) |
| Opponent | Clean-up | 3 | 0 (3) | 0 | 0 | 28 | 33% | 4.5 | 0 (2) | 0 (1) | - | 0 (1) | 0 (2) |
| Opponent | Fast Hammer | 5 | 11 (5) | 11 | 0 | 76 | 40% | 3.0 | 44 (1) | 0 (2) | 0 (2) | 17 (3) | 0 (2) |
| Opponent | Fragile | 3 | 0 (3) | 0 | 0 | 0 | 0% | 5.0 | 0 (3) | - | - | - | 0 (3) |
| Opponent | Hammer | 3 | 0 (3) | 0 | 0 | 61 | 67% | 2.0 | - | 0 (1) | 0 (2) | - | 0 (3) |
| Opponent | Holder | 3 | 211 (3) | 23 | 188 | 31 | 0% | 2.7 | 0 (1) | 307 (2) | - | 338 (2) | 0 (1) |
| Opponent | Shooter | 7 | 81 (7) | 0 | 81 | 44 | 0% | 1.6 | 96 (2) | 54 (3) | 118 (2) | 80 (3) | 82 (4) |
| Opponent | Wizard | 1 | 0 (1) | 0 | 0 | 0 | 0% | 1.0 | - | - | 0 (1) | - | 0 (1) |

### Charged fights: cnomg-c940641-p5

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Empire of Man | 3 | 453 | 79 | 1.0 | 1.0 | 79 | 0 | +79 | 1 of 3 | 2 of 3 | - | +79 |
| Opponent | Lizardmen | 1 | 0 | 327 | 2.0 | 1.0 | 164 | 0 | +164 | 0 of 2 | 2 of 2 | - | +164 |
| Opponent | Tomb Kings of Khemri | 1 | 45 | 350 | 4.0 | 1.0 | 88 | 98 | -10 | 4 of 4 | 0 of 4 | - | -10 |
| Opponent | Wood Elf Realms | 1 | 0 | 189 | 2.0 | 1.0 | 94 | 0 | +94 | 2 of 2 | 1 of 2 | - | +94 |
| **Opponent** | all armies | 3 | 15 | 289 | 2.7 | 1.0 | 108 | 49 | +59 | 6 of 8 | 3 of 8 | - | +59 |

### Effective charges: cnomg-c940641-p5

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Empire of Man | 3 | 0 | 1 (net +0) | 1 (net +236) | 1 (net +0) | 0 | 0 | 0 | 33% (1 of 3) |
| Opponent | Lizardmen | 2 | 0 | 0 | 0 | 0 | 1 (net +0) | 0 | 1 | 0% (0 of 1) |
| Opponent | Tomb Kings of Khemri | 4 | 3 (net -102) | 0 | 0 | 0 | 0 | 1 (net +265) | 0 | 0% (0 of 4) |

### Charged fights, damage counted: cnomg-c940641-p5

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 50-54% | 1 | 189 | 208 | +0 | 0 | 0 | +0 | +0.0 |
| Mine | Effective (55-75%) | 1 | 181 | 236 | +236 | 236 | 0 | +236 | +130.4 |
| Mine | 76-89% | 1 | 189 | 135 | +0 | 143 | 21 | +122 | +64.7 |
| Mine | All fights | 3 | 186 | 193 | +79 | 126 | 7 | +119 | +64.1 |
| Opponent | Long shot (under 50%) | 3 | 110 | 371 | -102 | 36 | 130 | -95 | -85.9 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 431 | 265 | +265 | 265 | 96 | +169 | +39.3 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 399 | 77 | +0 | 0 | 0 | +0 | +0.0 |
| Opponent | No odds | 3 | 168 | 231 | +172 | 204 | 24 | +180 | +107.6 |
| Opponent | All fights | 8 | 208 | 269 | +59 | 123 | 70 | +53 | +25.6 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| cnomg-c940641-p5 | move | 18 | 3 (17%) | 3 (17%) | 1 (6%) | 14 (78%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Horn of the Wild Hunt | Opponent | L0733 |
| Ring of Doom | Opponent | L0733 |
| Twice-Blessed Armour | Mine | L0717, L0733 |
| Witch Hunter's Ward | Mine | L0717, L0733, L0823 |

# Doctrine scorecard: cnomg-c940641-p17

### Scorecard: cnomg-c940641-p17

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0721 | 1 | 1 | Mine | no | 1 | 1 | 3 | 1 | 0 | 0 | 0 | 420 |
| L0721 | 1 | 1 | Opponent | yes | 1 | - | 3 | 5 | 1 | 0 | 0 | 410 |
| L0810 | 6 | 1 | Mine | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 596 |
| L0810 | 6 | 1 | Opponent | no | 20 | 2 | 0 | 0 | 0 | 0 | 0 | 330 |
| L0827 | 5 | 1 | Mine | no | - | - | 1 | 2 | 0 | 0 | 0 | 255 |
| L0827 | 5 | 1 | Opponent | yes | - | 2 | 1 | 6 | 0 | 0 | 0 | 60 |
| **Average** | | | Mine | 0% | 0.5 | 1.0 | 1.3 | 1.7 | 0.0 | 0.0 | 0.0 | 423.7 |
| **Average** | | | Opponent | 67% | 10.5 | 2.0 | 1.3 | 3.7 | 0.3 | 0.0 | 0.0 | 266.7 |

### KPIs: cnomg-c940641-p17

Rules off - Mine only: NO OLD ONE-MOVE GUESS.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 100% (16 of 16) | 0% (0 of 16) | 50% (16 of 32) |
| Winner chose to follow up after the loser gave ground |  | 33% (1 of 3); on the table 33% | 89% (8 of 9); on the table 89% | 75% (9 of 12); on the table 75% |
| Winner chose to pursue after the loser fell back in good order |  | 0% (0 of 1); on the table 0% | 0% (0 of 1); on the table 0% | 0% (0 of 2); on the table 0% |
| Winner chose to pursue after the loser fled |  | - | - | - |
| Winner chose to follow up or pursue (all three) |  | 25% (1 of 4); on the table 25% | 80% (8 of 10); on the table 80% | 64% (9 of 14); on the table 64% |
| Magic missiles tried each own turn | 50%+ | 83% (5 of 6) | 42% (15 of 36) | 48% (20 of 42) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 83% (5 of 6) | 44% (15 of 34) | 50% (20 of 40) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 60% (6 of 10) | 60% (6 of 10) |
| Points that never fought | lower | 66% (3938 of 5999) | 74% (4443 of 5998) | 70% (8381 of 11997) |
|   infantry points that never fought | lower | 92% (891 of 968) | 92% (1021 of 1113) | 92% (1912 of 2081) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 70% (21 of 30) | 68% (17 of 25) | 69% (38 of 55) |
| Bound items with a magic missile used (at least once a game) |  | 0.0 uses a game | 67% (2 of 3); 2.3 uses a game | 67% (2 of 3); 1.2 uses a game |
| Bound items with another spell used |  | 100% (1 of 1); 1.0 uses a game | 0% (0 of 1); 0.0 uses a game | 50% (1 of 2); 0.5 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 33% (1 of 3); 0.3 uses a game | 50% (1 of 2); 0.3 uses a game | 40% (2 of 5); 0.3 uses a game |
|   their share of the points of units over 100 pts | lower | 65% (3521 of 5378) | 69% (3581 of 5181) | 67% (7102 of 10559) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 3.7 (52%) | 3.7 (50%) |
| MARCHED: its unit marched | 0.3 (100%) | 2.7 (38%) | 3.0 (41%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.3 (5%) | 0.3 (5%) |
| GONE: slain | 0.0 (0%) | 0.3 (5%) | 0.3 (5%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 7.3 | 1.7 | 5.0 | 6.7 | 1.3 | 0.7 |
| not cast | 2.7 | 0.3 | 1.0 | 7.3 | 2.7 | 27.3 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (1%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.3 (100%) | 0.3 (33%) | 3.7 (50%) | 1.0 (38%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 3.0 (41%) | 1.0 (38%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (5%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | 0.3 (12%) | 0.0 (0%) | 0.0 (0%) | 0.3 (5%) | 0.0 (0%) | 1.0 (4%) |
| STUPIDITY: Stupidity | 0.3 (12%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (25%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.0 (75%) | 0.0 (0%) | 0.7 (67%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 26.0 (95%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.0 a game | 5.0 a game | 2.5 a game |
| stood (cast and not dispelled) | - | 67% (10 of 15) | 67% (10 of 15) |
| the unit moved after it | - | 40% (4 of 10) | 40% (4 of 10) |
| it charged on its next turn | - | 0% (0 of 10) | 0% (0 of 10) |
| the enemy charged it first | - | 0% (0 of 10) | 0% (0 of 10) |
| it fought by the end of its next turn | - | 0% (0 of 10) | 0% (0 of 10) |
| it moved out of a charge the enemy had planned (not charged first) | - | 0% (0 of 10) | 0% (0 of 10) |
| none of these (no charge, no fight, no charge escaped) | - | 100% (10 of 10) | 100% (10 of 10) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 81% (76 of 94) | 73% (19 of 26) | 79% (95 of 120) |
|   cavalry | 83% (15 of 18) | - | 83% (15 of 18) |
|   chariot | 89% (8 of 9) | 86% (12 of 14) | 87% (20 of 23) |
|   infantry | 75% (9 of 12) | 44% (4 of 9) | 62% (13 of 21) |
|   war machine | 80% (44 of 55) | 100% (3 of 3) | 81% (47 of 58) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.0 (17%) | 0.0 (0%) | 1.0 (12%) |
| CHARGED: it charged | 0.3 (6%) | 0.0 (0%) | 0.3 (4%) |
| IN COMBAT: it fought this turn or the last | 0.3 (6%) | 0.3 (14%) | 0.7 (8%) |
| MOVED: a war machine that moved | 1.0 (17%) | 0.0 (0%) | 1.0 (12%) |
| NO TARGET IN RANGE | 0.3 (6%) | 2.0 (86%) | 2.3 (28%) |
| ONLY IN COMBAT: the only targets were in combat | 1.0 (17%) | 0.0 (0%) | 1.0 (12%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.0 (17%) | 0.0 (0%) | 1.0 (12%) |
| OTHER BAR | 1.0 (17%) | 0.0 (0%) | 1.0 (12%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 10.7 | 3.0 | 78% | 6.8 pts | 73 pts |
| chariot | 7.0 | 0.3 | 95% | 1.3 pts | 9 pts |
| infantry | 4.3 | 1.3 | 77% | 2.7 pts | 12 pts |
| war machine | 16.0 | 11.7 | 67% | 30.1 pts | 482 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 1.7 | 3.0 | 2.3 |
| Charges that made contact a game | 1.7 | 2.3 | 2.0 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.00 declared, 0.00 contact (1 units) | 0.20 declared, 0.20 contact (5 units) | 0.17 declared, 0.17 contact (6 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 0.00 declared, 0.00 contact (2 units) | 0.00 declared, 0.00 contact (2 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.23 declared, 0.23 contact (22 units) | 0.36 declared, 0.27 contact (22 units) | 0.30 declared, 0.25 contact (44 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 56% (5 of 9) | 33% (1 of 3) | 100% (1 of 1) | 54% (7 of 13) |
| Character in a unit | 100% (9 of 9) | - | - | 100% (9 of 9) |
| Character on its own | 50% (1 of 2) | 0% (0 of 2) | 75% (3 of 4) | 50% (4 of 8) |
| Chariot | 100% (3 of 3) | 100% (2 of 2) | - | 100% (5 of 5) |
| Infantry | 67% (2 of 3) | 100% (1 of 1) | 50% (1 of 2) | 67% (4 of 6) |
| Monster | - | 0% (0 of 1) | - | 0% (0 of 1) |
| War Machines | 69% (9 of 13) | - | - | 69% (9 of 13) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Empire of Man | 3 | 25% (1 of 4); on the table 25% | 83% (5 of 6) | 66% | 70% (21 of 30) | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game | 33% (1 of 3); 0.3 uses a game |
| Grand Cathay | 1 | - | 42% (10 of 24) | 90% | 40% (4 of 10) | 50% (1 of 2); 5.0 uses a game | 0% (0 of 1); 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Skaven | 1 | 0% (0 of 1); on the table 0% | 33% (2 of 6) | 54% | 89% (8 of 9) | 100% (1 of 1); 2.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Vampire Counts | 1 | 89% (8 of 9); on the table 89% | 50% (3 of 6) | 79% | 83% (5 of 6) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (cnomg-c940641-p17, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 0% (0) | 75% (3) | 38% (3) |
| ...free all their last turn and able to turn (per game) | 0.00 | 1.00 | 1.00 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.33 | 0.33 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.67 | 0.67 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.33 | 0.00 | 0.33 |

### Quality by phase: cnomg-c940641-p17

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.0 | 3.7 |
| Strategy | Charge objectives carried out (made contact) | 60% (3 of 5) | 75% (6 of 8) |
| Strategy | Shoot objectives carried out (shot that target) | 28% (15 of 54) | 46% (6 of 13) |
| Strategy | Support requests answered (helper made contact too) | - | 100% (1 of 1) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | - | 100% (1 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | 60% (3 of 5) | - |
| Strategy | Joined characters whose unit fought | 33% (2 of 6) | 0% (0 of 5) |
| Strategy | Lone characters that fought | 25% (2 of 8) | 38% (3 of 8) |
| Movement | Charges halted short of contact | 0.0 | 0.3 |
| Movement | Idle units | 1.7 | 3.7 |
| Movement | Points that never moved of their own | 423.7 | 266.7 |
| Movement | Fights charged into per game | 1.7 | 1.7 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 5 | 1 of 5, net +0 |
| Movement | Charges with odds: sweet spot (55-75%) | 1 of 5, net -71 | 0 of 5 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 5 | 0 of 5 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 4 of 5, net +0 | 1 of 5, net +0 |
| Shooting | Shots by shooting units (incl. breath weapons) | 12.0 | 5.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 42% (15 of 36) | 62% (10 of 16) |
| Shooting | Points destroyed by shooting units | 55.0 | 0.0 |
| Shooting | War machine shots | 14.7 | 1.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 52% (23 of 44) | 0% (0 of 4) |
| Shooting | Points destroyed by war machines | 285.0 | 43.3 |
| Magic | Magic missiles cast | 1.3 | 3.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 50% (2 of 4) | 40% (4 of 10) |
| Magic | Wounds caused by magic missiles | 4.0 | 9.0 |
| Magic | Wounds caused by other spells | 1.0 | 1.3 |
| Magic | Points destroyed by magic (all spells) | 48.3 | 171.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.7 / 1.7 / 0.3 / 0.0 | 3.7 / 0.0 / 0.3 / 0.3 |
| Combat | Points destroyed in combat | 70.0 | 135.3 |
| Combat | Points run down | 0.0 | 0.0 |
| Combat | Net points per charged fight, damage counted | -8 | +39 |
| Combat | Net per 100 charger points, damage counted | -4.1 | +23.1 |
| Combat | First round won (charged fights) | 80% | 60% |
| Combat | Net points per charged fight | -14 | +25 |
| Combat | Net points per supported fight / lone fight | - / -14 | +0 / +31 |
| Combat | Charged fights on a top-3 enemy unit | 1 of 5 | 3 of 5 |
| Game | Points lost | 331.3 | 498.3 |
| Game | VP from objectives | 576.7 | 746.7 |
| Game | Lone holders (player turns) | 0.5 | 10.5 |

- Mine won / drew / lost: 1 / 0 / 2 of 3 ended games (of 3); mean margin (Mine - Opponent) -12 VP
- The side that went first won 1 of 3 games with a winner
- Points traded per game (both sides' losses): 830
- Games not ended: 0; findings 1, warnings 0

### Opponent rules: cnomg-c940641-p17

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 1.0 | +154.6 | 0.0 | 0.0 | - | - | - | - |
| AFTERMATH WITH FRIENDS | - | - | - | - | 0.3 | +9.0 | 0.0 | 0.0 |
| ARMY TABLE | 12.0 | -17.0 | 0.0 | 101.3 | 26.7 | +1013.8 | 0.0 | 285.0 |
| ARTILLERY RE-ROLL WEIGHED | 3.7 | +0.0 | 0.0 | 41.7 | 0.3 | +0.0 | 0.0 | 55.0 |
| BACKUP TARGETS | 0.3 | +3.4 | 0.0 | 0.0 | 0.3 | +2.8 | 0.0 | 0.0 |
| CANNON PLAN MISSED | 1.3 | +0.0 | 201.7 | 0.0 | 0.3 | +0.0 | 43.3 | 55.0 |
| CANNON PLANNED TARGET | 13.0 | +418.3 | 610.0 | 41.7 | 1.0 | +107.3 | 86.7 | 165.0 |
| CANNON SIGHT KEPT | 2.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 55.0 |
| CAST JOB | 1.7 | +250.8 | 540.0 | 0.0 | 2.3 | +52.0 | 270.0 | 0.0 |
| CASTS AFTER FRIENDS | - | - | - | - | 3.0 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | - | - | - | - | 2.7 | +52.9 | 0.0 | 18.3 |
| CHAFF PASSED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHARACTER GUNS | - | - | - | - | 4.0 | +0.0 | 0.0 | 0.0 |
| CHARGE LOSSES | 11.3 | -476.2 | 0.0 | 101.3 | 20.7 | -2101.4 | 0.0 | 996.7 |
| CHARGE NOT DECLARED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CHARGE NOW FIRST | 2.0 | +0.0 | 588.3 | 93.7 | 2.3 | +0.0 | 176.3 | 0.0 |
| CLOSES ON WHAT IT BEATS | 5.7 | +0.0 | 0.0 | 0.0 | 14.3 | +0.0 | 0.0 | 83.3 |
| COMBAT PIVOT | - | - | - | - | 0.3 | +0.0 | 0.0 | 48.3 |
| CONVEYANCE SEARCH | - | - | - | - | 5.3 | +385.4 | 0.0 | 0.0 |
| COVER ONCE | 7.7 | -374.5 | 0.0 | 49.0 | 9.3 | -708.2 | 0.0 | 248.3 |
| DEFENSIVE ARMY | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| DENIED BY THE FIGHT | 0.3 | -1.5 | 0.0 | 0.0 | 0.7 | -8.2 | 41.7 | 0.0 |
| DEPLOY BY FIGURES | 7.0 | -106.9 | 0.0 | 0.0 | 7.3 | -20.3 | 0.0 | 55.0 |
| EDGE GIVE GROUND | - | - | - | - | 0.3 | +42.1 | 0.0 | 0.0 |
| EXACT ROUND | 1.3 | +49.4 | 228.3 | 93.7 | 2.0 | +7.5 | 41.7 | 0.0 |
| FALL BACK GOOD ORDER | 1.3 | +13.0 | 228.3 | 93.7 | 3.0 | +0.9 | 41.7 | 0.0 |
| FALLS SHORT | - | - | - | - | 25.3 | +380.9 | 0.0 | 360.0 |
| FEATURE BUFFS | - | - | - | - | 2.7 | +20.3 | 0.0 | 0.0 |
| FIGHT TO THE END | 1.0 | +9.6 | 48.3 | 93.7 | 1.7 | +136.8 | 0.0 | 0.0 |
| FIRE IN ORDER | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FIVE ACTION | 96.7 | +7252.2 | 3031.7 | 489.0 | 97.3 | +4859.6 | 919.7 | 1628.3 |
| FLANK NOT WEIGHED | 4.7 | +0.0 | 0.0 | 30.0 | 9.3 | +0.0 | 0.0 | 360.0 |
| FOLLOW UP WEIGHED | 1.0 | +118.5 | 0.0 | 93.7 | 1.3 | +329.9 | 0.0 | 0.0 |
| FOUR ROUNDS | 1.7 | +114.8 | 228.3 | 93.7 | 3.0 | +325.9 | 41.7 | 0.0 |
| FREED FROM HIS FIGHT | 2.3 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 70.0 |
| FRIEND SHOOTS FIRST | 0.7 | -13.6 | 0.0 | 0.0 | - | - | - | - |
| GOAL WALK | 7.3 | +401.3 | 0.0 | 0.0 | 16.3 | +1210.9 | 0.0 | 0.0 |
| GUN FIGURES | 3.0 | +0.0 | 0.0 | 0.0 | 1.3 | +4.2 | 0.0 | 43.3 |
| GUN MASK | 0.7 | +6.2 | 0.0 | 0.0 | - | - | - | - |
| HARD STAY DROPPED | 2.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS CHARGE BY HIS RUN | 7.0 | +0.0 | 0.0 | 101.3 | 11.7 | +0.0 | 0.0 | 746.7 |
| HIS CHARGE DENIED | 0.3 | +0.6 | 0.0 | 0.0 | - | - | - | - |
| HIS CHARGE LIST | 4.7 | +0.0 | 0.0 | 0.0 | 5.0 | +0.0 | 0.0 | 610.0 |
| HIS LEGAL MOVES | 3.0 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 4.0 | -33.8 | 0.0 | 0.0 | 2.7 | -84.6 | 0.0 | 70.0 |
| HIS MOVE AS HE DECIDES | 47.3 | +14.0 | 375.0 | 0.0 | - | - | - | - |
| HIS MOVE WHY | - | - | - | - | 27.7 | +0.0 | 0.0 | 393.3 |
| HIS ONE MOVE | 16.3 | -69.2 | 0.0 | 34.0 | - | - | - | - |
| HIS ONE QUARTER | 2.0 | +0.0 | 0.0 | 0.0 | 6.7 | +0.0 | 0.0 | 180.0 |
| HIS OWN BEST MOVE | 1.3 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVE | 9.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS RANDOM MOVER COMES | 2.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 31.7 | +867.6 | 0.0 | 135.3 | 63.7 | +4606.1 | 0.0 | 1096.7 |
| HIS SHOTS BY HIS RUN | 24.7 | +548.6 | 0.0 | 135.3 | 58.7 | +2104.8 | 0.0 | 1086.7 |
| HIS TURN DENIED | - | - | - | - | 2.0 | +106.3 | 41.7 | 0.0 |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 10.0 | +0.0 | 0.0 | 0.0 | 22.7 | +0.0 | 0.0 | 0.0 |
| HOLDER ASSIGNMENT | 6.7 | +700.2 | 0.0 | 0.0 | 13.0 | +1126.0 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 1.3 | -19.8 | 48.3 | 93.7 | 2.0 | -60.1 | 41.7 | 0.0 |
| HUNT IN PAIRS | - | - | - | - | 1.0 | +35.9 | 0.0 | 68.3 |
| IDLE COST | - | - | - | - | 17.7 | -223.8 | 0.0 | 278.3 |
| JOINT CHARGE NOW | - | - | - | - | 1.0 | -75.9 | 0.0 | 0.0 |
| KEEP FALLS | 0.3 | +10.4 | 0.0 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 1.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 0.3 | +1.4 | 0.0 | 0.0 | 1.0 | +51.5 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 4.3 | +0.0 | 70.0 | 374.7 | 2.0 | +0.0 | 0.0 | 0.0 |
| LONE WIZARD KEPT IN | 0.7 | +46.6 | 0.0 | 0.0 | 0.3 | +58.3 | 0.0 | 0.0 |
| LONG SHOT | - | - | - | - | 0.3 | +1.1 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | 1.0 | +0.0 | 228.3 | 93.7 | 0.7 | +1.0 | 41.7 | 0.0 |
| MAKE SURE TOGETHER | - | - | - | - | 0.3 | +4.8 | 0.0 | 0.0 |
| MANOEUVRE | 2.3 | -7.4 | 0.0 | 0.0 | 1.0 | +29.3 | 0.0 | 0.0 |
| MARCH BY THE SUM | - | - | - | - | 0.3 | +53.3 | 0.0 | 0.0 |
| MARCH CHECK | - | - | - | - | 1.0 | +12.8 | 0.0 | 0.0 |
| MARCH OF THE TABLE | - | - | - | - | 1.3 | +90.2 | 0.0 | 0.0 |
| MARCH OVER CASTS | - | - | - | - | 1.3 | +247.7 | 0.0 | 68.3 |
| MARCH WHEELS ONLY | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 3.0 | +154.2 | 0.0 | 0.0 | 4.0 | +75.8 | 0.0 | 248.3 |
| MEETS IN TIME | 4.0 | +342.3 | 0.0 | 0.0 | 4.3 | +157.8 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 1.7 | +235.0 | 0.0 | 0.0 | 7.0 | +101.0 | 0.0 | 428.3 |
| MISSILES NEXT TURN | 1.7 | +124.8 | 0.0 | 0.0 | 11.7 | +136.7 | 0.0 | 428.3 |
| MOVE ORDER | 0.3 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 21.7 | 30.0 |
| MOVE SPELL SPOT | - | - | - | - | 2.3 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 2.0 | +272.2 | 0.0 | 0.0 | 5.7 | +714.7 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 7.7 | +316.3 | 0.0 | 54.7 | 8.3 | +399.5 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 2.0 | +333.0 | 180.0 | 0.0 | 5.0 | +674.0 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 1.3 | -67.7 | 228.3 | 93.7 | 1.7 | -67.2 | 41.7 | 0.0 |
| NO LATE CUT | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NO OLD ONE-MOVE GUESS | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | 0.3 | +0.0 | 0.0 | 15.0 | - | - | - | - |
| NOT WORTH A CAST | 0.3 | -0.4 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 5.3 | -233.1 | 0.0 | 34.0 | 4.0 | -87.8 | 0.0 | 235.0 |
| OGRE LOADER SECOND SHOT | - | - | - | - | 0.3 | +36.0 | 0.0 | 0.0 |
| ONE CHECK AFTER THE LAST CHANGE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ONE FIGHT FORMULA | 4.3 | -84.9 | 0.0 | 0.0 | 6.3 | -134.4 | 0.0 | 248.3 |
| ONE JOINT FIGURE | - | - | - | - | 0.3 | +10.8 | 0.0 | 0.0 |
| ONE OBJECTIVE FORMULA | 2.3 | -25.7 | 0.0 | 0.0 | 8.3 | +88.1 | 0.0 | 0.0 |
| ONE PROMISE A TARGET | - | - | - | - | 0.7 | -72.6 | 0.0 | 0.0 |
| ONE ROUTE | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| OVERRUNS AWAY | 0.3 | +25.8 | 180.0 | 0.0 | - | - | - | - |
| PATHS CROSS | - | - | - | - | 0.7 | +2.1 | 0.0 | 0.0 |
| PERIAPT WORTH | - | - | - | - | 0.3 | +24.8 | 0.0 | 0.0 |
| PLAN RESULT | 43.0 | +1634.1 | 1646.7 | 443.3 | 48.3 | +599.5 | 67.3 | 801.7 |
| PROMISE BELOW ZERO | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE BY ITS OWN SUM | 4.0 | -139.5 | 0.0 | 0.0 | 4.7 | -9.5 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | - | - | - | - | 2.7 | -1.4 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | 0.3 | -2.9 | 0.0 | 0.0 | 0.3 | -28.2 | 0.0 | 0.0 |
| PROMISE SHOT AWAY | 0.3 | -0.3 | 0.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | 21.3 | +1481.6 | 1800.0 | 0.0 | 18.7 | +1480.3 | 0.0 | 180.0 |
| RANDOM MOVE BY FIGURES | - | - | - | - | 3.3 | +65.8 | 0.0 | 188.3 |
| REAL GROUND | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| REDIRECT BY WHAT IT STOPS | - | - | - | - | 0.3 | -7.3 | 0.0 | 0.0 |
| REDIRECT COUNTER | 0.7 | +105.4 | 0.0 | 0.0 | 1.7 | +106.7 | 0.0 | 0.0 |
| REDIRECT FOR A FRIEND IN REACH | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.2 | 0.0 | 0.0 |
| REFORMS TO MEET IT | 0.7 | -60.7 | 0.0 | 0.0 | - | - | - | - |
| RESERVE FALL BACK | - | - | - | - | 0.3 | +3.3 | 0.0 | 0.0 |
| RISK BY ARC | 1.7 | -31.5 | 228.3 | 93.7 | 2.3 | +26.7 | 41.7 | 0.0 |
| RISK ON THE WAY | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| ROUNDS AFTER TERROR | - | - | - | - | 0.3 | -4.0 | 0.0 | 0.0 |
| RUN DOWN | 1.0 | -3.1 | 48.3 | 93.7 | 1.0 | -14.1 | 41.7 | 0.0 |
| SAFER THAN THE JOB | - | - | - | - | 0.7 | +37.1 | 0.0 | 0.0 |
| SCOUT SPOT | 0.7 | +4.7 | 0.0 | 0.0 | - | - | - | - |
| SCOUT WAITS | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 1.3 | -100.7 | 0.0 | 55.0 |
| SECOND LOOK | - | - | - | - | 0.3 | +65.4 | 0.0 | 0.0 |
| SET CREDITED ONCE | 0.3 | -0.9 | 0.0 | 0.0 | 0.7 | -108.2 | 0.0 | 0.0 |
| SET UP BY THE SET | 1.0 | -3.6 | 0.0 | 0.0 | 1.3 | +52.2 | 0.0 | 0.0 |
| SET UP TOGETHER | - | - | - | - | 0.3 | +4.8 | 0.0 | 0.0 |
| SET-UP ANY TARGET | - | - | - | - | 0.7 | +79.0 | 0.0 | 0.0 |
| SET-UP MISSED | - | - | - | - | 0.7 | +70.9 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 18.3 | +0.0 | 0.0 | 163.7 | 3.7 | +0.0 | 0.0 | 165.0 |
| SHOOTS FROM THE BEST SPOT | 0.7 | +154.5 | 360.0 | 0.0 | 1.7 | +52.9 | 232.0 | 0.0 |
| SHORT GUN FORWARD | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SHOT OR CHARGE | 1.0 | -332.5 | 540.0 | 0.0 | - | - | - | - |
| SHOT REPLANNED | - | - | - | - | 0.3 | +0.0 | 43.3 | 55.0 |
| SHOT RISK POINTS | 13.0 | +114.8 | 0.0 | 135.3 | 40.7 | -324.1 | 0.0 | 938.3 |
| SHOTS AFTER THE MOVES | 6.0 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 24.0 | +1962.5 | 0.0 | 163.7 | 6.0 | +289.0 | 0.0 | 208.3 |
| SPELL SETS UP CHARGE | - | - | - | - | 0.7 | +79.0 | 0.0 | 0.0 |
| SPELL WORTH | 1.7 | +2.7 | 0.0 | 0.0 | 5.3 | +104.9 | 360.0 | 360.0 |
| SPELLS IN THE FIGHT | 0.7 | +3.0 | 228.3 | 93.7 | - | - | - | - |
| SPOT AS THE GAME MOVES | 4.7 | +0.0 | 0.0 | 0.0 | 11.3 | +0.0 | 0.0 | 105.0 |
| STANDS FOR A REASON | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 65.3 | +0.0 | 2803.3 | 327.3 | 26.0 | +0.0 | 878.0 | 698.3 |
| STAY WORTH | 34.7 | +1153.3 | 1630.0 | 134.7 | 7.0 | +164.1 | 376.0 | 538.3 |
| STRIKE BY THE ODDS | - | - | - | - | 0.3 | +2.7 | 0.0 | 0.0 |
| STUCK PIVOT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| STUPIDITY NEXT TURN | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 5.3 | +266.5 | 0.0 | 0.0 | 4.3 | +139.3 | 0.0 | 36.7 |
| SUPPORT WORKED OUT | 5.3 | +266.5 | 0.0 | 0.0 | 4.3 | +139.3 | 0.0 | 36.7 |
| THE DEARER SUM KEEPS ITS PLAN | 1.7 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| THE PROMISE ADDS | - | - | - | - | 0.3 | -28.2 | 0.0 | 0.0 |
| THE PROMISED MOVE | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 2.7 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 105.0 |
| THE ROW KEEPS ITS WAY | 1.7 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 0.3 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 43.0 | +0.0 | 0.0 | 197.7 | 47.7 | +0.0 | 0.0 | 720.0 |
| TIED UP BY THE SUM | 1.0 | +87.0 | 0.0 | 0.0 | - | - | - | - |
| TIME ON OUR SIDE | 43.7 | +501.0 | 0.0 | 171.0 | - | - | - | - |
| WAITS AGAIN | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| WHAT THE JOINER ADDS | - | - | - | - | 0.7 | -18.7 | 0.0 | 0.0 |
| WHO FIGHTS | - | - | - | - | 1.0 | +36.8 | 0.0 | 0.0 |
| WHOLE FIGHT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | 4.0 | -355.3 | 0.0 | 0.0 | 3.0 | -571.0 | 0.0 | 540.0 |
| WHOLE FIGHT GAIN | - | - | - | - | 0.3 | +1.0 | 0.0 | 0.0 |
| WOUNDS ON THE RANKS | 3.3 | +34.8 | 0.0 | 67.3 | 3.3 | +115.1 | 0.0 | 0.0 |

### Rule changes: cnomg-c940641-p17

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS MOVE AS HE DECIDES | 142 | 142 | 100 | 33.33 | +0 | +0.0 |
| ARMY TABLE | 116 | 116 | 83 | 27.67 | +2270 | +27.3 |
| HIS SHOT LIST | 286 | 272 | 73 | 24.33 | +1680 | +23.0 |
| HIS SHOTS BY HIS RUN | 250 | 239 | 71 | 23.67 | +1287 | +18.1 |
| HIS MOVE WHY | 83 | 83 | 64 | 21.33 | +0 | +0.0 |
| HOLDER ASSIGNMENT | 59 | 59 | 54 | 18.00 | +5014 | +92.9 |
| SHOT RISK POINTS | 161 | 152 | 42 | 14.00 | +1243 | +29.6 |
| FIVE ACTION | 582 | 565 | 32 | 10.67 | +1949 | +60.9 |
| TIME ON OUR SIDE | 131 | 121 | 32 | 10.67 | +116 | +3.6 |
| OFF BEST | 28 | 28 | 28 | 9.33 | -963 | -34.4 |
| THE TABLE AGAIN | 36 | 36 | 28 | 9.33 | +0 | +0.0 |
| DEPLOY BY FIGURES | 43 | 43 | 25 | 8.33 | +379 | +15.2 |
| GOAL WALK | 71 | 70 | 23 | 7.67 | +1022 | +44.4 |
| LEGAL CHARGES ONLY | 19 | 19 | 19 | 6.33 | +0 | +0.0 |
| HIS ONE MOVE | 49 | 48 | 18 | 6.00 | +0 | +0.0 |
| MOVE TO CHARGE COMPUTED | 23 | 18 | 13 | 4.33 | +780 | +60.0 |
| ARTILLERY RE-ROLL WEIGHED | 12 | 12 | 12 | 4.00 | +0 | +0.0 |
| MEETS IN TIME | 25 | 25 | 12 | 4.00 | +880 | +73.3 |
| MOVE ORDER | 12 | 12 | 12 | 4.00 | +0 | +0.0 |
| NEXT CHARGE BY LIST | 21 | 18 | 11 | 3.67 | +914 | +83.1 |
| CAST JOB | 12 | 12 | 10 | 3.33 | +172 | +17.2 |
| CANNON SIGHT KEPT | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| QUARTER ODDS | 120 | 112 | 9 | 3.00 | +328 | +36.4 |
| CHARGE LOSSES | 96 | 86 | 8 | 2.67 | +783 | +97.8 |
| COVER ONCE | 51 | 41 | 8 | 2.67 | +165 | +20.6 |
| HARD STAY DROPPED | 8 | 8 | 8 | 2.67 | +0 | +0.0 |
| ADVANCE LANE KEPT | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 7 | 7 | 7 | 2.33 | +1345 | +192.2 |
| FOUR ROUNDS | 14 | 13 | 7 | 2.33 | +366 | +52.2 |
| SUPPORT ADDS | 29 | 25 | 7 | 2.33 | +233 | +33.3 |
| SUPPORT WORKED OUT | 29 | 25 | 7 | 2.33 | +233 | +33.3 |
| IDLE COST | 53 | 43 | 6 | 2.00 | +28 | +4.6 |
| PROMISE BY ITS OWN SUM | 26 | 26 | 6 | 2.00 | -447 | -74.5 |
| RANDOM MOVE BY FIGURES | 10 | 10 | 6 | 2.00 | +198 | +32.9 |
| SHOTS IN THE MOVE | 90 | 66 | 6 | 2.00 | +292 | +48.6 |
| CHARGE NOW FIRST | 13 | 13 | 5 | 1.67 | -393 | -78.6 |
| SHOOTS FROM THE BEST SPOT | 7 | 7 | 5 | 1.67 | +46 | +9.3 |
| CANNON PLANNED TARGET | 42 | 42 | 4 | 1.33 | +175 | +43.7 |
| LANE BY FIGURES | 4 | 4 | 4 | 1.33 | +159 | +39.7 |
| MARCH OF THE TABLE | 4 | 4 | 4 | 1.33 | -271 | -67.6 |
| MAX FOR POSITIONING | 21 | 19 | 4 | 1.33 | +29 | +7.3 |
| REDIRECT FOR A FRIEND IN REACH | 5 | 5 | 4 | 1.33 | +0 | +0.0 |
| WOUNDS ON THE RANKS | 20 | 19 | 4 | 1.33 | +111 | +27.6 |
| AFTERMATH IN POINTS | 3 | 3 | 3 | 1.00 | +464 | +154.6 |
| CHAFF IN THE MOVE | 8 | 6 | 3 | 1.00 | +4 | +1.3 |
| HOLDS AMBUSHERS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| JOINT CHARGE NOW | 3 | 3 | 3 | 1.00 | -228 | -75.9 |
| LONE WIZARD KEPT IN | 3 | 3 | 3 | 1.00 | +315 | +104.9 |
| MARCH CHECK | 3 | 3 | 3 | 1.00 | +34 | +11.2 |
| PROMISE KNOWS THE FIGHT | 8 | 6 | 3 | 1.00 | -4 | -1.4 |
| SET UP BY THE SET | 7 | 7 | 3 | 1.00 | +206 | +68.8 |
| CASTS FROM BEHIND | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| FIGHT TO THE END | 8 | 7 | 2 | 0.67 | +179 | +89.4 |
| ONE PROMISE A TARGET | 2 | 2 | 2 | 0.67 | -218 | -109.0 |
| PATHS CROSS | 2 | 2 | 2 | 0.67 | +6 | +3.1 |
| REDIRECT COUNTER | 7 | 6 | 2 | 0.67 | +206 | +103.0 |
| RISK BY ARC | 12 | 11 | 2 | 0.67 | +20 | +9.8 |
| SAFER THAN THE JOB | 2 | 2 | 2 | 0.67 | +111 | +55.6 |
| SCOUT WAITS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| SHORT GUN FORWARD | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| THE ROW IN ITS ORDER | 26 | 2 | 2 | 0.67 | +0 | +0.0 |
| TIED UP BY THE SUM | 3 | 3 | 2 | 0.67 | +68 | +34.0 |
| WHOLE FIGHT DANGER | 21 | 19 | 2 | 0.67 | +53 | +26.7 |
| AFTERMATH WITH FRIENDS | 1 | 1 | 1 | 0.33 | +27 | +27.1 |
| CHAFF PASSED | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CHARGE NOT DECLARED | 1 | 1 | 1 | 0.33 | -14 | -14.3 |
| COMBAT PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| EDGE GIVE GROUND | 1 | 1 | 1 | 0.33 | +31 | +30.9 |
| FALL BACK GOOD ORDER | 13 | 12 | 1 | 0.33 | +25 | +24.6 |
| FALLS SHORT | 76 | 62 | 1 | 0.33 | +0 | +0.0 |
| FIRE IN ORDER | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| HIS TURN DENIED | 6 | 6 | 1 | 0.33 | +14 | +14.3 |
| HUNT IN PAIRS | 3 | 3 | 1 | 0.33 | +25 | +25.0 |
| KEEP FALLS | 1 | 1 | 1 | 0.33 | +35 | +34.8 |
| MANOEUVRE | 10 | 10 | 1 | 0.33 | +88 | +87.8 |
| MARCH BY THE SUM | 1 | 1 | 1 | 0.33 | +160 | +160.0 |
| NEARER NOT NEEDED | 48 | 47 | 1 | 0.33 | +11 | +11.1 |
| OGRE LOADER SECOND SHOT | 1 | 1 | 1 | 0.33 | +108 | +108.0 |
| ONE FIGHT FORMULA | 32 | 18 | 1 | 0.33 | +2 | +2.1 |
| ONE JOINT FIGURE | 1 | 1 | 1 | 0.33 | +14 | +14.3 |
| ONE OBJECTIVE FORMULA | 32 | 25 | 1 | 0.33 | +2 | +2.0 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.33 | +74 | +74.4 |
| PROMISE SHOT AWAY | 1 | 1 | 1 | 0.33 | -1 | -0.9 |
| RESERVE FALL BACK | 1 | 1 | 1 | 0.33 | +10 | +9.8 |
| SECOND LOOK | 1 | 1 | 1 | 0.33 | +196 | +196.3 |
| SHOT REPLANNED | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| SHOTS AFTER THE MOVES | 25 | 25 | 1 | 0.33 | +0 | +0.0 |
| SPELLS IN THE FIGHT | 2 | 2 | 1 | 0.33 | +5 | +5.4 |
| STRIKE BY THE ODDS | 1 | 1 | 1 | 0.33 | +8 | +8.1 |
| STUCK PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| BACKUP TARGETS | 2 | not checked | - | - | - | - |
| CANNON PLAN MISSED | 5 | 5 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 9 | trace | - | - | - | - |
| CHARACTER GUNS | 12 | 12 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 60 | 58 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 16 | not checked | - | - | - | - |
| DEFENSIVE ARMY | 2 | 2 | 0 | 0.00 | - | - |
| DENIED BY THE FIGHT | 3 | 3 | 0 | 0.00 | - | - |
| EXACT ROUND | 10 | 9 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 8 | 8 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 42 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 18 | 17 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 2 | 2 | 0 | 0.00 | - | - |
| GUN FIGURES | 13 | not checked | - | - | - | - |
| GUN MASK | 2 | 2 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 4 | 3 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 56 | 47 | 0 | 0.00 | - | - |
| HIS CHARGE DENIED | 1 | 1 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 29 | 27 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 16 | 14 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 20 | 18 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 26 | 24 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 14 | 13 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 29 | 27 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 7 | 7 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN RUN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 98 | 98 | 0 | 0.00 | - | - |
| HONEST WORTH | 10 | 9 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 8 | 8 | 0 | 0.00 | - | - |
| LONG SHOT | 1 | 1 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 5 | 5 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 1 | not checked | - | - | - | - |
| MARCH OVER CASTS | 4 | 4 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 4 | 4 | 0 | 0.00 | - | - |
| MISSILES IN THE MOVE | 26 | 16 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 40 | 27 | 0 | 0.00 | - | - |
| MOVE SPELL SPOT | 7 | not checked | - | - | - | - |
| NO DOUBLE ROUNDS | 9 | 9 | 0 | 0.00 | - | - |
| NO LATE CUT | 2 | 2 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 18 | 18 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT TURNED | 1 | 1 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 1 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 1 | not checked | - | - | - | - |
| ONE ROUTE | 4 | 4 | 0 | 0.00 | - | - |
| OVERRUNS AWAY | 1 | 1 | 0 | 0.00 | - | - |
| PLAN RESULT | 274 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 2 | 2 | 0 | 0.00 | - | - |
| PROMISE READS THE TABLE | 2 | 2 | 0 | 0.00 | - | - |
| REAL GROUND | 4 | 4 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 1 | 1 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 2 | 1 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 4 | 4 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 1 | 1 | 0 | 0.00 | - | - |
| RUN DOWN | 6 | 6 | 0 | 0.00 | - | - |
| SCOUT SPOT | 2 | 2 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 4 | 4 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 3 | 3 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 1 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 2 | not checked | - | - | - | - |
| SET-UP MISSED | 2 | trace | - | - | - | - |
| SHOOTERS ON THE TABLE | 66 | not checked | - | - | - | - |
| SHOT OR CHARGE | 3 | 3 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 2 | not checked | - | - | - | - |
| SPELL WORTH | 21 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 48 | 44 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 1 | 1 | 0 | 0.00 | - | - |
| STANDS STILL | 274 | 266 | 0 | 0.00 | - | - |
| STAY WORTH | 125 | 117 | 0 | 0.00 | - | - |
| STUPIDITY NEXT TURN | 4 | 2 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 11 | not checked | - | - | - | - |
| THE PROMISE ADDS | 1 | 1 | 0 | 0.00 | - | - |
| THE PROMISED MOVE | 3 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 15 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 7 | not checked | - | - | - | - |
| THE TABLE BINDS | 272 | not checked | - | - | - | - |
| WAITS AGAIN | 3 | 2 | 0 | 0.00 | - | - |
| WHAT THE JOINER ADDS | 2 | not checked | - | - | - | - |
| WHO FIGHTS | 3 | 3 | 0 | 0.00 | - | - |
| WHOLE FIGHT | 1 | not checked | - | - | - | - |
| WHOLE FIGHT GAIN | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: cnomg-c940641-p17

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 4.67 | 3.67 | 35.3 |
| ARMY TABLE | rule | 4.00 | 2.33 | 57.6 |
| PROMISE BY ITS OWN SUM | rule | 1.33 | 0.67 | 74.5 |
| CHARGE NOW FIRST | rule | 0.67 | 1.00 | 78.6 |
| MARCH OF THE TABLE | rule | - | 1.00 | 90.2 |
| PROMISE KNOWS THE FIGHT | rule | - | 1.00 | 1.4 |
| JOINT CHARGE NOW | rule | - | 0.67 | 120.9 |
| ONE PROMISE A TARGET | rule | - | 0.67 | 109.0 |
| RULE SWITCHED OFF | gate | 0.67 | - | 17.7 |
| CHARGE NOT DECLARED | rule | - | 0.33 | 14.3 |
| HOLDER ASSIGNMENT | rule | 0.33 | - | 4.5 |
| NO REASON | gate | - | 0.33 | 45.1 |
| PROMISE SHOT AWAY | rule | 0.33 | - | 0.9 |

### Plans: cnomg-c940641-p17

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.7 | 20% | 106 | 104 | 98% |
| Mine | join | 1.0 | 100% | 14 | 0 | 0% |
| Mine | move | 25.7 | 97% | 1181 | 0 | 0% |
| Mine | shoot | 14.7 | 57% | 2239 | 1530 | 68% |
| Opponent | charge | 3.0 | 44% | 443 | 211 | 48% |
| Opponent | join | 3.0 | 100% | 119 | 0 | 0% |
| Opponent | move | 37.3 | 96% | 2070 | 0 | 0% |
| Opponent | shoot | 3.7 | 73% | 304 | 388 | 128% |
| Opponent | support | 1.3 | 50% | 0 | 0 | 0% |

### Battle groups: cnomg-c940641-p17

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 0.7 | 0% | - | - | - | - | - | - | - | - |
| Opponent | REDIRECT COUNTER | 1.7 | 0% | - | - | - | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: cnomg-c940641-p17

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 2 | 0 (2) | 0 | 0 | 0 | 100% | - | 0 (1) | - | 0 (1) | 0 (1) | 0 (1) |
| Mine | Character | 12 | 24 (12) | 24 | 0 | 32 | 67% | 2.8 | 0 (4) | 0 (4) | 44 (4) | 33 (7) | 0 (5) |
| Mine | Fast Hammer | 5 | 10 (5) | 0 | 10 | 0 | 40% | 2.7 | 6 (3) | 0 (1) | 25 (1) | 17 (3) | 0 (2) |
| Mine | Hammer | 4 | 28 (4) | 0 | 28 | 0 | 50% | 1.0 | 0 (1) | 40 (3) | - | 0 (3) | 97 (1) |
| Mine | Shooter | 5 | 29 (5) | 24 | 4 | 54 | 0% | 1.2 | 0 (1) | 0 (2) | 70 (2) | 29 (5) | - |
| Mine | War machine | 11 | 61 (11) | 61 | 0 | 18 | 9% | 1.4 | 10 (5) | 103 (6) | - | 0 (2) | 74 (9) |
| Mine | Wizard | 2 | 0 (2) | 0 | 0 | 0 | 50% | 5.0 | 0 (1) | 0 (1) | - | 0 (1) | 0 (1) |
| Opponent | Chaff | 5 | 0 (5) | 0 | 0 | 19 | 100% | - | 0 (3) | 0 (2) | - | 0 (5) | - |
| Opponent | Character | 11 | 14 (11) | 14 | 0 | 31 | 36% | 2.0 | 0 (3) | 0 (5) | 37 (3) | 11 (7) | 16 (4) |
| Opponent | Clean-up | 1 | 146 (1) | 0 | 146 | 0 | 0% | 3.0 | - | 146 (1) | - | 146 (1) | - |
| Opponent | Fast Hammer | 6 | 81 (6) | 29 | 52 | 0 | 33% | 1.5 | 86 (3) | 71 (3) | - | 144 (4) | 8 (2) |
| Opponent | Fragile | 2 | 0 (2) | 0 | 0 | 45 | 100% | - | - | 0 (1) | 0 (1) | - | 0 (2) |
| Opponent | Hammer | 4 | 39 (4) | 39 | 0 | 49 | 25% | 1.7 | 0 (2) | 134 (1) | 0 (1) | 56 (3) | 0 (1) |
| Opponent | Holder | 4 | 92 (4) | 0 | 92 | 0 | 75% | 2.0 | - | 0 (2) | 171 (2) | 92 (4) | - |
| Opponent | Shooter | 2 | 0 (2) | 0 | 0 | 50 | 0% | 2.5 | - | - | 0 (2) | 0 (1) | 0 (1) |
| Opponent | War machine | 2 | 39 (2) | 39 | 0 | 100 | 0% | 1.0 | - | 39 (2) | - | 79 (1) | 0 (1) |
| Opponent | Wizard | 2 | 0 (2) | 0 | 0 | 0 | 0% | 1.0 | 0 (2) | - | - | 0 (2) | - |

### Charged fights: cnomg-c940641-p17

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Empire of Man | 3 | 388 | 70 | 1.7 | 1.0 | 42 | 56 | -14 | 1 of 5 | 4 of 5 | - | -14 |
| Opponent | Grand Cathay | 1 | 643 | 125 | 1.0 | 1.0 | 125 | 0 | +125 | 0 of 1 | 1 of 1 | - | +125 |
| Opponent | Skaven | 1 | 0 | 0 | 2.0 | 1.0 | 0 | 0 | +0 | 1 of 2 | 0 of 2 | - | +0 |
| Opponent | Vampire Counts | 1 | 0 | 0 | 2.0 | 2.0 | 0 | 0 | +0 | 2 of 2 | 2 of 2 | +0 | +0 |
| **Opponent** | all armies | 3 | 214 | 42 | 1.7 | 1.4 | 25 | 0 | +25 | 3 of 5 | 3 of 5 | +0 | +31 |

### Effective charges: cnomg-c940641-p17

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Empire of Man | 5 | 0 | 0 | 1 (net -71) | 0 | 0 | 4 (net +0) | 0 | 20% (1 of 5) |
| Opponent | Grand Cathay | 1 | 0 | 0 | 0 | 1 (net +125) | 0 | 0 | 0 | 0% (0 of 1) |
| Opponent | Skaven | 2 | 1 (net +0) | 0 | 0 | 1 (net +0) | 0 | 0 | 0 | 0% (0 of 2) |
| Opponent | Vampire Counts | 2 | 0 | 0 | 0 | 1 (net +0) | 0 | 1 (net +0) | 0 | 0% (0 of 2) |

### Charged fights, damage counted: cnomg-c940641-p17

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Effective (55-75%) | 1 | 181 | 145 | -71 | 297 | 281 | +16 | +8.8 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 4 | 183 | 202 | +0 | 34 | 47 | -13 | -7.3 |
| Mine | All fights | 5 | 182 | 191 | -14 | 86 | 94 | -8 | -4.1 |
| Opponent | Long shot (under 50%) | 1 | 0 | 238 | +0 | 0 | 0 | +0 | - |
| Opponent | 76-89% | 3 | 144 | 135 | +42 | 62 | 67 | -5 | -3.4 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 422 | 265 | +0 | 220 | 9 | +212 | +50.1 |
| Opponent | All fights | 5 | 171 | 181 | +25 | 81 | 42 | +39 | +23.1 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| cnomg-c940641-p17 | move | 19 | 2 (11%) | 2 (11%) | 2 (11%) | 15 (79%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L0827 |
| Invocation of Nehek | Opponent | L0827 |
| Periapt of Soul Exchange | Opponent | L0721 |
| Ring of Jet | Opponent | L0810 |
| Storm Daemon (Renegade 2.0) | Opponent | L0721 |
| Twice-Blessed Armour | Mine | L0721 |
| Twice-Blessed Armour | Opponent | L0810 |
| Witch Hunter's Ward | Mine | L0721, L0810, L0827 |

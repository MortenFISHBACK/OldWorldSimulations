# Doctrine scorecard: cnomg-c940641-p43

### Scorecard: cnomg-c940641-p43

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L1118 | 2 | 1 | Mine | - | - | 2 | 2 | 1 | 0 | 0 | 0 | 330 |
| L1118 | 2 | 1 | Opponent | - | - | - | 2 | 4 | 0 | 0 | 0 | 413 |
| L1135 | 1 | 1 | Mine | yes | 0 | 2 | 2 | 0 | 0 | 0 | 0 | 0 |
| L1135 | 1 | 1 | Opponent | no | 0 | 2 | 2 | 3 | 0 | 0 | 0 | 140 |
| L1228 | 4 | 1 | Mine | no | 4 | 2 | 2 | 1 | 0 | 0 | 0 | 165 |
| L1228 | 4 | 1 | Opponent | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 414 |
| **Average** | | | Mine | 50% | 2.0 | 2.0 | 2.0 | 0.7 | 0.0 | 0.0 | 0.0 | 165.0 |
| **Average** | | | Opponent | 0% | 0.0 | 2.0 | 1.3 | 2.7 | 0.0 | 0.0 | 0.0 | 322.3 |

### KPIs: cnomg-c940641-p43

Rules off - Opponent only: NO OLD ONE-MOVE GUESS.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 43% (6 of 14) | 0% (0 of 17) | 19% (6 of 31) |
| Winner chose to follow up after the loser gave ground |  | 100% (2 of 2); on the table 100% | 0% (0 of 1); on the table 0% | 67% (2 of 3); on the table 67% |
| Winner chose to pursue after the loser fell back in good order |  | 83% (5 of 6); on the table 100% | - | 83% (5 of 6); on the table 100% |
| Winner chose to pursue after the loser fled |  | 86% (6 of 7); on the table 86% | 100% (1 of 1); on the table 100% | 88% (7 of 8); on the table 88% |
| Winner chose to follow up or pursue (all three) |  | 87% (13 of 15); on the table 93% | 50% (1 of 2); on the table 50% | 82% (14 of 17); on the table 88% |
| Magic missiles tried each own turn | 50%+ | 28% (20 of 72) | 17% (3 of 18) | 26% (23 of 90) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 34% (20 of 58) | 30% (3 of 10) | 34% (23 of 68) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | - | - |
| Points that never fought | lower | 51% (3056 of 5998) | 37% (2207 of 6000) | 44% (5263 of 11998) |
|   infantry points that never fought | lower | 77% (559 of 730) | 77% (602 of 782) | 77% (1161 of 1512) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 48% (12 of 25) | 85% (22 of 26) | 67% (34 of 51) |
| Bound items with a magic missile used (at least once a game) |  | 57% (4 of 7); 4.3 uses a game | 50% (1 of 2); 1.3 uses a game | 56% (5 of 9); 2.8 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0% (0 of 3); 0.0 uses a game | 0.0 uses a game | 0% (0 of 3); 0.0 uses a game |
|   their share of the points of units over 100 pts | lower | 44% (2469 of 5614) | 82% (4651 of 5644) | 63% (7120 of 11258) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 5.3 (31%) | 0.3 (7%) | 5.7 (25%) |
| MARCHED: its unit marched | 6.3 (37%) | 0.0 (0%) | 6.3 (28%) |
| CHARGED: its unit charged | 1.0 (6%) | 0.0 (0%) | 1.0 (4%) |
| IN COMBAT: engaged in combat | 4.7 (27%) | 0.0 (0%) | 4.7 (21%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.7 (13%) | 0.7 (3%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (0%) | 2.7 (53%) | 2.7 (12%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 1.3 (27%) | 1.3 (6%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 1.7 | 4.7 | 0.3 | 7.7 | 1.0 | 2.0 |
| not cast | 2.3 | 11.3 | 5.7 | 22.3 | 3.0 | 26.0 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.0 (8%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 7.7 (68%) | 0.0 (0%) | 5.7 (25%) | 0.0 (0%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 6.3 (28%) | 1.0 (33%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.0 (4%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 4.7 (21%) | 1.0 (33%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 2.0 (18%) | 2.0 (35%) | 0.7 (3%) | 0.0 (0%) | 0.0 (0%) |
| OFF THE TABLE: off the table or not arrived | 1.7 (71%) | 1.0 (9%) | 2.7 (47%) | 2.7 (12%) | 0.0 (0%) | 6.0 (23%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.3 (3%) | 0.0 (0%) | 0.0 (0%) | 0.7 (22%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.3 (6%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 0.7 (29%) | 0.3 (3%) | 1.0 (18%) | 0.0 (0%) | 0.3 (11%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 18.0 (69%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.0 a game | 0.3 a game | 0.2 a game |
| stood (cast and not dispelled) | - | 100% (1 of 1) | 100% (1 of 1) |
| the unit moved after it | - | 0% (0 of 1) | 0% (0 of 1) |
| it charged on its next turn | - | 0% (0 of 1) | 0% (0 of 1) |
| the enemy charged it first | - | 0% (0 of 1) | 0% (0 of 1) |
| it fought by the end of its next turn | - | 0% (0 of 1) | 0% (0 of 1) |
| it moved out of a charge the enemy had planned (not charged first) | - | 0% (0 of 1) | 0% (0 of 1) |
| none of these (no charge, no fight, no charge escaped) | - | 100% (1 of 1) | 100% (1 of 1) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 68% (40 of 59) | 63% (41 of 65) | 65% (81 of 124) |
|   cavalry | - | 80% (12 of 15) | 80% (12 of 15) |
|   character | - | 73% (8 of 11) | 73% (8 of 11) |
|   chariot | 67% (8 of 12) | 100% (4 of 4) | 75% (12 of 16) |
|   infantry | 75% (9 of 12) | 41% (11 of 27) | 51% (20 of 39) |
|   monster | - | 75% (6 of 8) | 75% (6 of 8) |
|   war machine | 66% (23 of 35) | - | 66% (23 of 35) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.7 (26%) | 2.3 (29%) | 4.0 (28%) |
| CHARGED: it charged | 0.0 (0%) | 0.7 (8%) | 0.7 (5%) |
| FLEEING: it fled or was fleeing | 0.0 (0%) | 0.3 (4%) | 0.3 (2%) |
| IN COMBAT: it fought this turn or the last | 0.0 (0%) | 0.7 (8%) | 0.7 (5%) |
| MOVED: a war machine that moved | 1.0 (16%) | 0.0 (0%) | 1.0 (7%) |
| NO TARGET IN RANGE | 0.0 (0%) | 3.0 (38%) | 3.0 (21%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 2.7 (42%) | 1.0 (12%) | 3.7 (26%) |
| SHELTERED: the target was sheltered | 0.7 (11%) | 0.0 (0%) | 0.7 (5%) |
| OTHER BAR | 0.3 (5%) | 0.0 (0%) | 0.3 (2%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 4.7 | 1.3 | 79% | 6.1 pts | 29 pts |
| character | 2.7 | 1.7 | 62% | 28.3 pts | 75 pts |
| chariot | 4.0 | 0.3 | 92% | 3.2 pts | 13 pts |
| infantry | 8.3 | 0.7 | 92% | 3.1 pts | 26 pts |
| monster | 2.0 | 0.0 | 100% | 0.0 pts | 0 pts |
| war machine | 8.3 | 12.7 | 36% | 42.2 pts | 351 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.7 | 1.3 | 3.0 |
| Charges that made contact a game | 3.3 | 1.3 | 2.3 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.83 declared, 1.50 contact (6 units) | - | 1.83 declared, 1.50 contact (6 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | - | - |
|   per unit a game, the other units (no war machines, no joined characters) | 0.30 declared, 0.10 contact (10 units) | 0.15 declared, 0.15 contact (26 units) | 0.19 declared, 0.14 contact (36 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 67% (4 of 6) | - | 50% (2 of 4) | 60% (6 of 10) |
| Character in a unit | 100% (2 of 2) | 100% (1 of 1) | - | 100% (3 of 3) |
| Character on its own | 100% (1 of 1) | 44% (4 of 9) | 60% (3 of 5) | 53% (8 of 15) |
| Chariot | 100% (4 of 4) | - | - | 100% (4 of 4) |
| Infantry | 62% (5 of 8) | - | - | 62% (5 of 8) |
| Monster | - | 100% (1 of 1) | - | 100% (1 of 1) |
| Monstrous | 100% (2 of 2) | 50% (1 of 2) | - | 75% (3 of 4) |
| War Machines | 67% (4 of 6) | - | - | 67% (4 of 6) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Grand Cathay | 3 | 87% (13 of 15); on the table 93% | 28% (20 of 72) | 51% | 48% (12 of 25) | 57% (4 of 7); 4.3 uses a game | 0.0 uses a game | 0% (0 of 3); 0.0 uses a game |
| Ogre Kingdoms | 1 | - | 0% (0 of 6) | 72% | 71% (5 of 7) | 100% (1 of 1); 4.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 1 | 0% (0 of 1); on the table 0% | 33% (2 of 6) | 2% | 71% (5 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 1 | 100% (1 of 1); on the table 100% | 17% (1 of 6) | 36% | 100% (12 of 12) | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (cnomg-c940641-p43, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 100% (4) | 80% (4) | 89% (8) |
| ...free all their last turn and able to turn (per game) | 1.33 | 1.33 | 2.67 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.33 | 0.67 | 1.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.67 | 0.67 |

### Quality by phase: cnomg-c940641-p43

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.7 | 1.0 |
| Strategy | Charge objectives carried out (made contact) | 64% (9 of 14) | 100% (3 of 3) |
| Strategy | Shoot objectives carried out (shot that target) | 25% (12 of 48) | 50% (10 of 20) |
| Strategy | Support requests answered (helper made contact too) | 67% (2 of 3) | - |
| Strategy | Hexes on a unit its side charged or shot that turn | 100% (5 of 5) | 100% (1 of 1) |
| Strategy | Joined characters whose unit fought | 50% (2 of 4) | 0% (0 of 1) |
| Strategy | Lone characters that fought | 88% (7 of 8) | 86% (6 of 7) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 0.7 | 2.7 |
| Movement | Points that never moved of their own | 165.0 | 322.3 |
| Movement | Fights charged into per game | 2.7 | 1.3 |
| Movement | Charges with odds: long shots (under 50%) | 3 of 8, net +274 | 1 of 3, net +0 |
| Movement | Charges with odds: sweet spot (55-75%) | 1 of 8, net +564 | 0 of 3 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 8 | 0 of 3 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 4 of 8, net +67 | 1 of 3, net +0 |
| Shooting | Shots by shooting units (incl. breath weapons) | 5.7 | 14.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 35% (6 of 17) | 57% (24 of 42) |
| Shooting | Points destroyed by shooting units | 0.0 | 55.0 |
| Shooting | War machine shots | 7.7 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 43% (10 of 23) | - |
| Shooting | Points destroyed by war machines | 103.7 | 0.0 |
| Magic | Magic missiles cast | 5.0 | 0.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 27% (4 of 15) | 100% (1 of 1) |
| Magic | Wounds caused by magic missiles | 7.3 | 0.3 |
| Magic | Wounds caused by other spells | 4.7 | - |
| Magic | Points destroyed by magic (all spells) | 308.3 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.7 / 1.7 / 1.0 / 0.3 | 0.3 / 0.3 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 155.3 | 0.0 |
| Combat | Points run down | 199.3 | 0.0 |
| Combat | Net points per charged fight, damage counted | +209 | -80 |
| Combat | Net per 100 charger points, damage counted | +54.3 | -47.6 |
| Combat | First round won (charged fights) | 75% | 25% |
| Combat | Net points per charged fight | +207 | -8 |
| Combat | Net points per supported fight / lone fight | +282 / +182 | - / -8 |
| Combat | Charged fights on a top-3 enemy unit | 5 of 8 | 2 of 4 |
| Game | Points lost | 55.0 | 1206.7 |
| Game | VP from objectives | 1080.0 | 300.0 |
| Game | Lone holders (player turns) | 2.0 | 0.0 |

- Mine won / drew / lost: 3 / 0 / 0 of 3 ended games (of 3); mean margin (Mine - Opponent) +2065 VP
- The side that went first won 3 of 3 games with a winner
- Points traded per game (both sides' losses): 1262
- Games not ended: 0; findings 1, warnings 0

### Opponent rules: cnomg-c940641-p43

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | - | - | - | - | 0.3 | +98.6 | 0.0 | 164.7 |
| ARMY TABLE | 10.0 | +54.5 | 0.0 | 0.0 | 25.0 | +573.7 | 0.0 | 569.3 |
| ARRIVAL HUNT | - | - | - | - | 0.3 | +24.9 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 2.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ASSAILMENT BY POINTS | 0.3 | +2.7 | 0.0 | 0.0 | - | - | - | - |
| BACKUP TARGETS | 0.3 | +1.1 | 0.0 | 0.0 | - | - | - | - |
| BEST PRIZE | 0.3 | -13.7 | 11.3 | 0.0 | - | - | - | - |
| BOMBING RUN | 0.7 | +21.7 | 0.0 | 0.0 | - | - | - | - |
| CANNON PLAN MISSED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CANNON PLANNED TARGET | 7.3 | +237.6 | 388.0 | 110.0 | - | - | - | - |
| CANNON SIGHT KEPT | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CAST JOB | 4.3 | +160.6 | 22.7 | 0.0 | - | - | - | - |
| CASTER AWAY FROM SCREEN | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 2.7 | +63.5 | 0.0 | 0.0 | 2.0 | +35.9 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | - | - | - | - | 0.3 | +0.0 | 0.0 | 91.3 |
| CHAFF IN THE MOVE | - | - | - | - | 2.0 | +22.3 | 0.0 | 0.0 |
| CHALLENGE BY POINTS | - | - | - | - | 0.7 | +42.4 | 0.0 | 37.0 |
| CHARGE LOSSES | 15.0 | -283.4 | 0.0 | 0.0 | 18.7 | -968.2 | 0.0 | 850.7 |
| CHARGE NOW FIRST | 2.3 | +0.0 | 709.3 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 8.0 | +0.0 | 0.0 | 0.0 | 5.7 | +0.0 | 0.0 | 0.0 |
| COMBAT PIVOT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CONVEYANCE SEARCH | - | - | - | - | 0.3 | +41.9 | 0.0 | 91.3 |
| COVER ONCE | 7.3 | -415.1 | 0.0 | 0.0 | 8.0 | -1115.3 | 0.0 | 379.0 |
| DEFENSIVE ARMY | 0.7 | +0.0 | 156.0 | 0.0 | - | - | - | - |
| DENIED BY THE FIGHT | 0.7 | -3.5 | 136.3 | 0.0 | - | - | - | - |
| DEPLOY BY FIGURES | 6.0 | -45.0 | 0.0 | 0.0 | 8.3 | -61.2 | 0.0 | 0.0 |
| EDGE GIVE GROUND | 0.7 | +130.8 | 171.7 | 0.0 | - | - | - | - |
| EVASIVE BY THE ODDS | - | - | - | - | 2.0 | +34.0 | 0.0 | 0.0 |
| EXACT ROUND | 1.7 | -0.8 | 214.3 | 0.0 | 0.7 | -3.6 | 0.0 | 0.0 |
| FALL BACK GOOD ORDER | 3.0 | +17.5 | 878.7 | 0.0 | 1.0 | +0.4 | 0.0 | 0.0 |
| FALLS SHORT | - | - | - | - | 26.3 | +305.6 | 0.0 | 725.0 |
| FEATURE BUFFS | 0.7 | +53.4 | 0.0 | 0.0 | - | - | - | - |
| FIGHT TO THE END | 2.3 | +43.5 | 908.3 | 0.0 | 0.7 | +16.1 | 0.0 | 0.0 |
| FIRE IN ORDER | 0.7 | +0.0 | 13.3 | 0.0 | - | - | - | - |
| FIVE ACTION | 87.3 | +8113.6 | 2429.0 | 220.0 | 72.7 | +3809.4 | 165.0 | 1450.0 |
| FLANK NOT WEIGHED | 5.0 | +0.0 | 0.0 | 0.0 | 6.7 | +0.0 | 0.0 | 495.7 |
| FOLLOW UP WEIGHED | 0.3 | +116.9 | 0.0 | 0.0 | - | - | - | - |
| FOUR ROUNDS | 4.7 | +669.4 | 1240.3 | 0.0 | 1.0 | +139.4 | 0.0 | 0.0 |
| FREED FROM HIS FIGHT | 1.3 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 26.7 |
| FRIEND SHOOTS FIRST | 1.0 | -1.7 | 0.0 | 0.0 | - | - | - | - |
| FRIENDS SHOTS CHECKED | 1.0 | +54.7 | 0.0 | 0.0 | - | - | - | - |
| GIVES UP | 0.7 | -3.4 | 164.7 | 0.0 | - | - | - | - |
| GOAL WALK | 3.3 | +242.3 | 0.0 | 0.0 | 11.7 | +1116.9 | 0.0 | 119.0 |
| GUN MASK | 2.0 | +59.3 | 0.0 | 0.0 | - | - | - | - |
| HARD STAY DROPPED | 1.0 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 0.7 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 26.7 |
| HIS CHARGE BY HIS RUN | 10.0 | +0.0 | 0.0 | 0.0 | 9.0 | +0.0 | 0.0 | 808.7 |
| HIS CHARGE LIST | 1.7 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 83.7 |
| HIS LEGAL MOVES | 3.7 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 103.7 |
| HIS MOVE AND SHOT | 2.7 | -14.7 | 0.0 | 0.0 | 12.3 | -125.3 | 0.0 | 75.0 |
| HIS MOVE AS HE DECIDES | - | - | - | - | 33.3 | +14.0 | 0.0 | 0.0 |
| HIS MOVE WHY | 33.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS ONE MOVE | - | - | - | - | 19.7 | -31.2 | 0.0 | 0.0 |
| HIS ONE QUARTER | 2.0 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 5.7 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 61.7 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 32.3 | +966.1 | 0.0 | 0.0 | 46.3 | +3268.9 | 0.0 | 699.7 |
| HIS SHOTS BY HIS RUN | 31.7 | +781.2 | 0.0 | 0.0 | 46.7 | +1451.6 | 0.0 | 1109.0 |
| HIS TURN DENIED | 0.7 | +6.5 | 136.3 | 0.0 | 0.3 | +2.4 | 0.0 | 0.0 |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 15.7 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 0.0 |
| HOLDER ASSIGNMENT | 11.0 | +972.9 | 0.0 | 0.0 | 4.3 | +727.3 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 4.0 | -95.0 | 911.0 | 0.0 | 1.0 | -28.1 | 0.0 | 0.0 |
| HUNT IN PAIRS | 0.7 | +40.5 | 0.0 | 0.0 | - | - | - | - |
| IDLE COST | - | - | - | - | 11.0 | -169.8 | 0.0 | 404.3 |
| JOINT CHARGE NOW | 2.3 | +102.5 | 901.3 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 2.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 1.3 | +33.7 | 0.0 | 0.0 | 0.3 | +15.7 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 0.3 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 78.0 |
| LONE WIZARD KEPT IN | 0.7 | +52.8 | 0.0 | 0.0 | - | - | - | - |
| LONG SHOT | - | - | - | - | 0.3 | -2.2 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | 3.0 | -7.1 | 1156.7 | 0.0 | 0.7 | +1.6 | 0.0 | 0.0 |
| LOST CHARGE | 0.3 | -0.8 | 52.7 | 0.0 | - | - | - | - |
| LURE BY WHAT IT DRAWS | - | - | - | - | 1.3 | -46.9 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | - | - | - | - | 0.7 | +2.7 | 0.0 | 0.0 |
| MANOEUVRE | 1.0 | +0.0 | 0.0 | 0.0 | 1.3 | -69.5 | 0.0 | 0.0 |
| MARCH BY THE SUM | 1.3 | +44.2 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | 2.0 | +61.1 | 0.0 | 0.0 | 0.3 | +20.5 | 0.0 | 0.0 |
| MARCH OF THE TABLE | 2.3 | +203.4 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 3.0 | +143.3 | 0.0 | 0.0 | 0.3 | +70.2 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 3.7 | +57.8 | 0.0 | 0.0 | 1.7 | +149.9 | 0.0 | 61.7 |
| MEETS IN TIME | 1.7 | +155.5 | 0.0 | 0.0 | 4.0 | +307.2 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 6.3 | +207.0 | 0.0 | 0.0 | 2.7 | +34.4 | 0.0 | 52.7 |
| MISSILES NEXT TURN | 12.3 | +245.6 | 0.0 | 0.0 | 3.0 | +23.7 | 0.0 | 171.7 |
| MISSILES ON ONE TARGET | 0.3 | -49.5 | 0.0 | 0.0 | - | - | - | - |
| MOVE ORDER | 0.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 52.7 | 52.7 |
| MOVE SPELL OUT OF RANGE | - | - | - | - | 0.3 | -8.6 | 78.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 2.7 | +251.7 | 0.0 | 0.0 | 1.0 | +87.3 | 0.0 | 42.0 |
| NEARER NOT NEEDED | 6.7 | +299.8 | 0.0 | 0.0 | 4.7 | +225.6 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 2.7 | +260.6 | 0.0 | 0.0 | 0.7 | +74.1 | 0.0 | 42.0 |
| NEXT OBJECTIVE NEARER | - | - | - | - | 1.0 | -53.3 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 3.3 | -114.6 | 581.7 | 0.0 | 1.0 | -99.5 | 0.0 | 0.0 |
| NO LATE CUT | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | - | - | - | - | 0.7 | +47.4 | 0.0 | 0.0 |
| NOT WORTH A CAST | 0.7 | -0.2 | 0.0 | 0.0 | 0.3 | -0.3 | 0.0 | 117.0 |
| OFF BEST | 4.0 | -177.3 | 0.0 | 55.0 | 7.0 | -248.2 | 0.0 | 292.3 |
| OGRE LOADER SECOND SHOT | 4.0 | +44.6 | 0.0 | 0.0 | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 5.0 | -75.1 | 0.0 | 0.0 | 5.0 | -78.3 | 0.0 | 181.7 |
| ONE JOINT FIGURE | 1.3 | +278.4 | 572.0 | 0.0 | 0.3 | +11.6 | 0.0 | 0.0 |
| ONE OBJECTIVE FORMULA | 6.7 | -45.8 | 0.0 | 0.0 | 1.7 | -35.2 | 0.0 | 0.0 |
| ONE ROUTE | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| OPENS UP | 0.3 | +8.2 | 0.0 | 0.0 | - | - | - | - |
| OVERRUNS AWAY | 1.0 | +1.7 | 280.7 | 0.0 | - | - | - | - |
| PATHS CROSS | 0.3 | +1.2 | 0.0 | 0.0 | - | - | - | - |
| PLAN RESULT | 38.3 | +1893.9 | 717.0 | 110.0 | 33.7 | +69.5 | 110.0 | 1444.0 |
| PROMISE BELOW ZERO | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE BY ITS OWN SUM | 2.3 | -20.2 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| PROMISE IN STEPS | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE KNOWS THE FIGHT | 0.3 | -0.8 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | 0.7 | -100.7 | 0.0 | 0.0 | - | - | - | - |
| PROMISE SHOT AWAY | 0.3 | -1.4 | 0.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | 20.0 | +2711.7 | 168.0 | 0.0 | 11.3 | +917.3 | 0.0 | 0.0 |
| REAL GROUND | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| REDIRECT BY WHAT IT STOPS | - | - | - | - | 0.7 | +1.7 | 0.0 | 11.3 |
| REDIRECT COUNTER | - | - | - | - | 2.3 | +422.3 | 0.0 | 13.3 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 1.0 | +0.0 | 0.0 | 11.3 |
| REFORMS TO MEET IT | 0.3 | -2.8 | 0.0 | 0.0 | - | - | - | - |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| RESERVE FALL BACK | 1.0 | +64.8 | 0.0 | 0.0 | 0.3 | +21.9 | 0.0 | 0.0 |
| RISK BY ARC | 4.0 | +194.2 | 1240.3 | 0.0 | 1.0 | -51.5 | 0.0 | 0.0 |
| ROUNDS AFTER TERROR | - | - | - | - | 0.3 | -15.2 | 0.0 | 0.0 |
| RUN DOWN | 3.0 | -20.2 | 417.0 | 0.0 | 1.0 | -15.1 | 0.0 | 0.0 |
| SCOUT SPOT | - | - | - | - | 0.7 | +2.9 | 0.0 | 0.0 |
| SCOUT WAITS | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| SEARCH SPOT | - | - | - | - | 0.7 | +36.0 | 0.0 | 61.7 |
| SET CREDITED ONCE | - | - | - | - | 1.0 | -69.7 | 0.0 | 0.0 |
| SET UP BY THE SET | 0.3 | +1.2 | 0.0 | 0.0 | 2.3 | +133.6 | 0.0 | 0.0 |
| SET UP TOGETHER | - | - | - | - | 1.0 | +3.0 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | - | - | - | - | 0.3 | +0.3 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 14.7 | +0.0 | 0.0 | 110.0 | 7.7 | +0.0 | 0.0 | 201.3 |
| SHOOTS FROM THE BEST SPOT | 3.7 | +126.9 | 0.0 | 0.0 | 1.3 | +3.3 | 0.0 | 0.0 |
| SHOT OR CHARGE | 0.7 | -69.0 | 78.0 | 0.0 | 0.3 | -3.3 | 0.0 | 0.0 |
| SHOT RISK POINTS | 17.7 | -51.1 | 0.0 | 0.0 | 32.0 | +483.0 | 0.0 | 507.0 |
| SHOTS AFTER THE MOVES | 4.3 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 15.7 | +1215.0 | 0.0 | 110.0 | 12.3 | +432.5 | 0.0 | 351.0 |
| SPELL WORTH | 1.3 | +21.7 | 0.0 | 0.0 | 1.0 | +7.2 | 91.3 | 91.3 |
| SPELLS IN THE FIGHT | 0.7 | -1.3 | 136.3 | 0.0 | - | - | - | - |
| SPOT AS THE GAME MOVES | 2.0 | +0.0 | 0.0 | 0.0 | 5.0 | +0.0 | 0.0 | 218.0 |
| STAND AND SHOOT | 1.0 | -8.0 | 214.3 | 0.0 | - | - | - | - |
| STANDS FOR A REASON | - | - | - | - | 9.7 | +0.0 | 0.0 | 281.7 |
| STANDS STILL | 47.7 | +0.0 | 1188.7 | 220.0 | 29.7 | +0.0 | 165.0 | 695.3 |
| STAY WORTH | 32.3 | +376.6 | 926.0 | 330.0 | 20.3 | +192.8 | 165.0 | 354.7 |
| STRIKE BY THE ODDS | 0.7 | +20.3 | 329.3 | 0.0 | 0.3 | +3.3 | 0.0 | 0.0 |
| SUPPORT ADDS | 3.0 | +171.7 | 0.0 | 0.0 | 5.7 | +664.0 | 0.0 | 110.0 |
| SUPPORT NARROWED | 0.3 | +0.0 | 46.7 | 0.0 | - | - | - | - |
| SUPPORT WORKED OUT | 3.0 | +171.7 | 0.0 | 0.0 | 5.7 | +664.0 | 0.0 | 110.0 |
| SWIFTSTRIDE BY POINTS | - | - | - | - | 1.3 | +9.9 | 0.0 | 236.3 |
| THE DEARER SUM KEEPS ITS PLAN | 2.7 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 52.7 |
| THE PROMISE ADDS | 0.7 | -31.0 | 0.0 | 0.0 | - | - | - | - |
| THE ROW IN ITS ORDER | 1.3 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 2.0 | +0.0 | 0.0 | 0.0 | 7.0 | +0.0 | 0.0 | 334.0 |
| THE STEP BACK IS MADE | 0.7 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 38.0 | +0.0 | 0.0 | 110.0 | 35.7 | +0.0 | 0.0 | 725.0 |
| TIED UP BY THE SUM | 1.7 | +142.5 | 83.7 | 0.0 | - | - | - | - |
| TIME ON OUR SIDE | 32.0 | +497.8 | 22.7 | 0.0 | - | - | - | - |
| WAITS AGAIN | 2.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WALKS ON ITS ROUTE | - | - | - | - | 0.3 | -40.4 | 0.0 | 0.0 |
| WHO FIGHTS | - | - | - | - | 0.3 | -33.9 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | 0.7 | -42.1 | 0.0 | 0.0 | 2.0 | -450.0 | 0.0 | 533.7 |
| WHOLE FIGHT GAIN | 1.3 | +81.6 | 572.0 | 0.0 | - | - | - | - |
| WOUNDED STAYS OUT | - | - | - | - | 0.3 | +0.0 | 55.0 | 0.0 |
| WOUNDS ON THE RANKS | 2.0 | +25.5 | 0.0 | 0.0 | 3.0 | +81.5 | 0.0 | 402.7 |

### Rule changes: cnomg-c940641-p43

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 105 | 105 | 80 | 26.67 | +2336 | +29.2 |
| HIS SHOT LIST | 236 | 224 | 60 | 20.00 | +1527 | +25.4 |
| HIS MOVE WHY | 100 | 100 | 59 | 19.67 | +0 | +0.0 |
| HIS MOVE AS HE DECIDES | 100 | 100 | 58 | 19.33 | +0 | +0.0 |
| HIS SHOTS BY HIS RUN | 235 | 222 | 52 | 17.33 | +1219 | +23.4 |
| HOLDER ASSIGNMENT | 46 | 46 | 40 | 13.33 | +3220 | +80.5 |
| OFF BEST | 33 | 33 | 33 | 11.00 | -1277 | -38.7 |
| THE TABLE AGAIN | 36 | 36 | 26 | 8.67 | +0 | +0.0 |
| DEPLOY BY FIGURES | 43 | 43 | 22 | 7.33 | +408 | +18.6 |
| SHOT RISK POINTS | 149 | 141 | 22 | 7.33 | +855 | +38.9 |
| FIVE ACTION | 480 | 459 | 20 | 6.67 | +1355 | +67.8 |
| HIS ONE MOVE | 59 | 59 | 18 | 6.00 | +0 | +0.0 |
| GOAL WALK | 45 | 44 | 14 | 4.67 | +754 | +53.8 |
| QUARTER ODDS | 94 | 83 | 14 | 4.67 | +921 | +65.8 |
| CAST JOB | 13 | 13 | 13 | 4.33 | +230 | +17.7 |
| FOUR ROUNDS | 17 | 17 | 12 | 4.00 | +696 | +58.0 |
| OGRE LOADER SECOND SHOT | 12 | 12 | 12 | 4.00 | +134 | +11.1 |
| HARD STAY DROPPED | 11 | 11 | 11 | 3.67 | +0 | +0.0 |
| CHARGE LOSSES | 101 | 97 | 10 | 3.33 | +674 | +67.4 |
| LEGAL CHARGES ONLY | 10 | 10 | 10 | 3.33 | +0 | +0.0 |
| MEETS IN TIME | 17 | 17 | 10 | 3.33 | +481 | +48.1 |
| MOVE TO CHARGE COMPUTED | 11 | 10 | 9 | 3.00 | +507 | +56.3 |
| ARTILLERY RE-ROLL WEIGHED | 8 | 8 | 8 | 2.67 | +0 | +0.0 |
| NEXT CHARGE BY LIST | 10 | 10 | 8 | 2.67 | +478 | +59.7 |
| SHOTS AFTER THE MOVES | 24 | 24 | 8 | 2.67 | +0 | +0.0 |
| COVER ONCE | 46 | 33 | 7 | 2.33 | +149 | +21.2 |
| JOINT CHARGE NOW | 7 | 7 | 7 | 2.33 | +308 | +43.9 |
| MARCH OF THE TABLE | 7 | 7 | 7 | 2.33 | -610 | -87.2 |
| SHOOTS FROM THE BEST SPOT | 15 | 15 | 7 | 2.33 | +13 | +1.9 |
| ADVANCE LANE KEPT | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| MISSILES IN THE MOVE | 27 | 22 | 6 | 2.00 | +201 | +33.5 |
| MOVE ORDER | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| STAY WORTH | 158 | 148 | 6 | 2.00 | +65 | +10.9 |
| TIME ON OUR SIDE | 96 | 82 | 6 | 2.00 | +27 | +4.5 |
| CANNON SIGHT KEPT | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| CHAFF IN THE MOVE | 6 | 6 | 5 | 1.67 | +4 | +0.7 |
| FALLS SHORT | 79 | 64 | 5 | 1.67 | +34 | +6.9 |
| LANE BY FIGURES | 5 | 5 | 5 | 1.67 | +148 | +29.7 |
| RISK BY ARC | 15 | 15 | 5 | 1.67 | +183 | +36.6 |
| SET UP BY THE SET | 8 | 8 | 5 | 1.67 | +236 | +47.3 |
| SUPPORT ADDS | 26 | 22 | 5 | 1.67 | +188 | +37.6 |
| SUPPORT WORKED OUT | 26 | 22 | 5 | 1.67 | +188 | +37.6 |
| TIED UP BY THE SUM | 5 | 5 | 5 | 1.67 | +55 | +11.0 |
| HOLDS AMBUSHERS | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| MARCH BY THE SUM | 4 | 4 | 4 | 1.33 | +133 | +33.2 |
| MARCH CHECK | 7 | 7 | 4 | 1.33 | +114 | +28.4 |
| RESERVE FALL BACK | 4 | 4 | 4 | 1.33 | +260 | +65.0 |
| SWIFTSTRIDE BY POINTS | 4 | 4 | 4 | 1.33 | +30 | +7.4 |
| CASTING BLOCK | 14 | 14 | 3 | 1.00 | +30 | +9.9 |
| CHARGE NOW FIRST | 8 | 8 | 3 | 1.00 | -341 | -113.6 |
| FRIENDS SHOTS CHECKED | 3 | 3 | 3 | 1.00 | +164 | +54.6 |
| HIS MOVE AND SHOT | 45 | 44 | 3 | 1.00 | +19 | +6.5 |
| IDLE COST | 33 | 23 | 3 | 1.00 | +81 | +27.1 |
| ONE FIGHT FORMULA | 30 | 18 | 3 | 1.00 | +41 | +13.6 |
| ONE JOINT FIGURE | 5 | 5 | 3 | 1.00 | +145 | +48.4 |
| REDIRECT FOR A FRIEND IN REACH | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| SCOUT WAITS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| SHOTS IN THE MOVE | 84 | 72 | 3 | 1.00 | +557 | +185.6 |
| STRIKE BY THE ODDS | 3 | 3 | 3 | 1.00 | +71 | +23.6 |
| THE ROW IN ITS ORDER | 12 | 3 | 3 | 1.00 | +0 | +0.0 |
| WOUNDS ON THE RANKS | 15 | 15 | 3 | 1.00 | +25 | +8.2 |
| BOMBING RUN | 2 | 2 | 2 | 0.67 | +65 | +32.6 |
| CHALLENGE BY POINTS | 2 | 2 | 2 | 0.67 | +127 | +63.6 |
| FIRE IN ORDER | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| LONE WIZARD KEPT IN | 2 | 2 | 2 | 0.67 | +158 | +79.2 |
| MAX FOR POSITIONING | 16 | 16 | 2 | 0.67 | +14 | +7.0 |
| NEARER NOT NEEDED | 34 | 31 | 2 | 0.67 | +94 | +46.9 |
| WHOLE FIGHT DANGER | 8 | 8 | 2 | 0.67 | +38 | +19.1 |
| WHOLE FIGHT GAIN | 4 | 4 | 2 | 0.67 | +52 | +26.0 |
| AFTERMATH IN POINTS | 1 | 1 | 1 | 0.33 | +296 | +295.8 |
| ASSAILMENT BY POINTS | 1 | 1 | 1 | 0.33 | +8 | +8.0 |
| BEST PRIZE | 1 | 1 | 1 | 0.33 | -41 | -41.0 |
| CANNON PLANNED TARGET | 22 | 22 | 1 | 0.33 | -2 | -2.0 |
| CASTER AWAY FROM SCREEN | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| COMBAT PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FALL BACK GOOD ORDER | 12 | 12 | 1 | 0.33 | +10 | +9.6 |
| FIGHT TO THE END | 9 | 9 | 1 | 0.33 | +10 | +9.6 |
| FOLLOW UP WEIGHED | 1 | 1 | 1 | 0.33 | +351 | +350.6 |
| GUN MASK | 6 | 6 | 1 | 0.33 | +1 | +1.0 |
| HUNT IN PAIRS | 2 | 1 | 1 | 0.33 | +64 | +63.9 |
| MISSILES NEXT TURN | 46 | 32 | 1 | 0.33 | +0 | +0.2 |
| OPENS UP | 1 | 1 | 1 | 0.33 | +20 | +19.9 |
| PATHS CROSS | 1 | 1 | 1 | 0.33 | +4 | +3.7 |
| PROMISE BY ITS OWN SUM | 11 | 11 | 1 | 0.33 | -60 | -60.5 |
| PROMISE KNOWS THE FIGHT | 2 | 2 | 1 | 0.33 | -2 | -2.5 |
| PROMISE READS THE TABLE | 2 | 2 | 1 | 0.33 | -231 | -231.3 |
| PROMISE SHOT AWAY | 1 | 1 | 1 | 0.33 | -4 | -4.1 |
| REDIRECT COUNTER | 7 | 7 | 1 | 0.33 | +27 | +26.8 |
| SEARCH SPOT | 2 | 2 | 1 | 0.33 | +139 | +139.3 |
| SHOOTERS IN TWO RANKS | 1 | 1 | 1 | 0.33 | +1 | +1.0 |
| WALKS ON ITS ROUTE | 1 | 1 | 1 | 0.33 | -121 | -121.3 |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| BACKUP TARGETS | 1 | not checked | - | - | - | - |
| CANNON PLAN MISSED | 1 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 1 | trace | - | - | - | - |
| CLOSES ON WHAT IT BEATS | 41 | 41 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 1 | not checked | - | - | - | - |
| DEFENSIVE ARMY | 2 | 2 | 0 | 0.00 | - | - |
| DENIED BY THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| EDGE GIVE GROUND | 2 | 2 | 0 | 0.00 | - | - |
| EVASIVE BY THE ODDS | 6 | 6 | 0 | 0.00 | - | - |
| EXACT ROUND | 7 | 7 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 2 | 2 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 35 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 10 | 10 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 3 | 3 | 0 | 0.00 | - | - |
| GIVES UP | 2 | 2 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 8 | 8 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 57 | 54 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 14 | 13 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 24 | 23 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 14 | 11 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 24 | 22 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 3 | 3 | 0 | 0.00 | - | - |
| HIS TURN RUN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 59 | 59 | 0 | 0.00 | - | - |
| HONEST WORTH | 15 | 15 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 8 | 8 | 0 | 0.00 | - | - |
| LONG SHOT | 1 | 1 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 11 | 11 | 0 | 0.00 | - | - |
| LOST CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 4 | 4 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 2 | not checked | - | - | - | - |
| MANOEUVRE | 7 | 7 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 10 | 10 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 3 | 3 | 0 | 0.00 | - | - |
| MISSILES ON ONE TARGET | 1 | not checked | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 1 | trace | - | - | - | - |
| NEXT OBJECTIVE NEARER | 3 | 2 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 13 | 13 | 0 | 0.00 | - | - |
| NO LATE CUT | 5 | 5 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 18 | 18 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT TURNED | 2 | 2 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 3 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 4 | not checked | - | - | - | - |
| ONE OBJECTIVE FORMULA | 25 | 19 | 0 | 0.00 | - | - |
| ONE ROUTE | 3 | 3 | 0 | 0.00 | - | - |
| OVERRUNS AWAY | 3 | 3 | 0 | 0.00 | - | - |
| PLAN RESULT | 216 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 2 | 2 | 0 | 0.00 | - | - |
| PROMISE IN STEPS | 1 | 1 | 0 | 0.00 | - | - |
| REAL GROUND | 3 | 3 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 2 | 2 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 1 | not checked | - | - | - | - |
| REFUSING RETIRES | 1 | 1 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 1 | 1 | 0 | 0.00 | - | - |
| RUN DOWN | 12 | 12 | 0 | 0.00 | - | - |
| SCOUT SPOT | 2 | 2 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 3 | 3 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 3 | 2 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 67 | not checked | - | - | - | - |
| SHOT OR CHARGE | 3 | 3 | 0 | 0.00 | - | - |
| SPELL WORTH | 7 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 21 | 19 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 3 | 3 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 29 | 28 | 0 | 0.00 | - | - |
| STANDS STILL | 232 | 220 | 0 | 0.00 | - | - |
| SUPPORT NARROWED | 1 | 1 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 14 | not checked | - | - | - | - |
| THE PROMISE ADDS | 2 | 1 | 0 | 0.00 | - | - |
| THE ROW KEEPS ITS WAY | 27 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 14 | not checked | - | - | - | - |
| THE TABLE BINDS | 221 | not checked | - | - | - | - |
| WAITS AGAIN | 6 | 5 | 0 | 0.00 | - | - |
| WHO FIGHTS | 1 | 1 | 0 | 0.00 | - | - |
| WOUNDED STAYS OUT | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: cnomg-c940641-p43

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 3.33 | 3.67 | 41.9 |
| RULE SWITCHED OFF | gate | - | 3.33 | 37.9 |
| ARMY TABLE | rule | 0.33 | 2.33 | 79.0 |
| MARCH OF THE TABLE | rule | 2.33 | - | 87.2 |
| JOINT CHARGE NOW | rule | 1.33 | - | 69.8 |
| CHARGE NOW FIRST | rule | 1.00 | - | 113.6 |
| AFTERMATH BAND | gate | 0.33 | - | 2.5 |
| BEST PRIZE | rule | 0.33 | - | 41.0 |
| CANNON PLANNED TARGET | rule | 0.33 | - | 2.0 |
| FRIENDS SHOTS CHECKED | rule | 0.33 | - | 2.5 |
| NO REASON | gate | 0.33 | - | 14.3 |
| PROMISE BY ITS OWN SUM | rule | 0.33 | - | 60.5 |
| PROMISE KNOWS THE FIGHT | rule | 0.33 | - | 2.5 |
| PROMISE READS THE TABLE | rule | 0.33 | - | 231.3 |
| PROMISE SHOT AWAY | rule | 0.33 | - | 4.1 |
| WALKS ON ITS ROUTE | rule | - | 0.33 | 121.3 |

### Plans: cnomg-c940641-p43

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 4.7 | 71% | 761 | 992 | 130% |
| Mine | move | 19.7 | 100% | 1553 | 0 | 0% |
| Mine | shoot | 14.0 | 45% | 1172 | 902 | 77% |
| Opponent | charge | 1.0 | 33% | 107 | 18 | 16% |
| Opponent | move | 25.3 | 87% | 1360 | 0 | 0% |
| Opponent | shoot | 6.3 | 16% | 519 | 52 | 10% |
| Opponent | support | 1.0 | 100% | 22 | 0 | 0% |

### Battle groups: cnomg-c940641-p43

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | REDIRECT COUNTER | 2.3 | 29% | 100% | 0% | - | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: cnomg-c940641-p43

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Character | 12 | 105 (12) | 105 | 0 | 0 | 25% | 2.2 | - | 143 (7) | 56 (5) | 61 (7) | 139 (5) |
| Mine | Fast Hammer | 4 | 10 (4) | 0 | 10 | 0 | 25% | 2.0 | 0 (2) | 14 (2) | - | 0 (3) | 28 (1) |
| Mine | Holder | 5 | 93 (5) | 20 | 73 | 0 | 40% | 2.3 | - | 95 (4) | 82 (1) | 107 (3) | 70 (2) |
| Mine | Shooter | 2 | 412 (2) | 0 | 412 | 0 | 0% | 1.0 | 309 (1) | 515 (1) | - | 412 (2) | - |
| Mine | War machine | 6 | 31 (6) | 31 | 0 | 17 | 0% | 1.3 | 38 (2) | 0 (2) | 56 (2) | 0 (1) | 38 (5) |
| Opponent | Chaff | 6 | 0 (6) | 0 | 0 | 41 | 50% | 3.7 | 0 (5) | 0 (1) | - | 0 (5) | 0 (1) |
| Opponent | Character | 7 | 8 (7) | 8 | 0 | 55 | 0% | 1.9 | 72 (1) | 0 (4) | - | 20 (3) | 0 (2) |
| Opponent | Clean-up | 3 | 0 (3) | 0 | 0 | 0 | 0% | 2.0 | - | 0 (3) | - | 0 (2) | 0 (1) |
| Opponent | Early | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Fast Hammer | 4 | 8 (4) | 0 | 8 | 100 | 0% | 2.0 | - | 9 (3) | 0 (1) | 9 (3) | 0 (1) |
| Opponent | Hammer | 8 | 20 (8) | 0 | 20 | 56 | 50% | 1.2 | 0 (2) | 55 (2) | 0 (4) | 31 (5) | 0 (3) |
| Opponent | Holder | 1 | 54 (1) | 0 | 54 | 100 | 0% | 2.0 | - | 54 (1) | - | 54 (1) | - |
| Opponent | Shooter | 2 | 0 (2) | 0 | 0 | 56 | 0% | 1.0 | 0 (1) | 0 (1) | - | 0 (2) | - |
| Opponent | Wizard | 1 | 0 (1) | 0 | 0 | 100 | 0% | 2.0 | - | - | - | - | - |

### Charged fights: cnomg-c940641-p43

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Grand Cathay | 3 | 412 | 552 | 2.7 | 1.2 | 207 | 0 | +207 | 5 of 8 | 6 of 8 | +282 | +182 |
| Opponent | Ogre Kingdoms | 1 | 165 | 0 | 2.0 | 1.0 | 0 | 17 | -17 | 0 of 2 | 0 of 2 | - | -17 |
| Opponent | Warriors of Chaos | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Wood Elf Realms | 1 | 0 | 0 | 2.0 | 1.0 | 0 | 0 | +0 | 2 of 2 | 1 of 2 | - | +0 |
| **Opponent** | all armies | 3 | 55 | 0 | 1.3 | 1.0 | 0 | 8 | -8 | 2 of 4 | 1 of 4 | - | -8 |

### Effective charges: cnomg-c940641-p43

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Grand Cathay | 8 | 3 (net +274) | 0 | 1 (net +564) | 0 | 0 | 4 (net +67) | 0 | 12% (1 of 8) |
| Opponent | Ogre Kingdoms | 2 | 0 | 1 (net +0) | 0 | 0 | 0 | 0 | 1 | 0% (0 of 1) |
| Opponent | Wood Elf Realms | 2 | 1 (net +0) | 0 | 0 | 0 | 0 | 1 (net +0) | 0 | 0% (0 of 2) |

### Charged fights, damage counted: cnomg-c940641-p43

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 3 | 442 | 362 | +274 | 274 | 49 | +225 | +51.0 |
| Mine | Effective (55-75%) | 1 | 713 | 494 | +564 | 584 | 0 | +584 | +82.0 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 4 | 260 | 165 | +67 | 129 | 26 | +103 | +39.5 |
| Mine | All fights | 8 | 385 | 280 | +207 | 240 | 32 | +209 | +54.3 |
| Opponent | Long shot (under 50%) | 1 | 102 | 358 | +0 | 119 | 119 | +0 | +0.3 |
| Opponent | 50-54% | 1 | 40 | 171 | +0 | 11 | 10 | +1 | +1.7 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 499 | 369 | +0 | 227 | 516 | -289 | -57.8 |
| Opponent | No odds | 1 | 34 | 171 | -34 | 0 | 34 | -34 | -100.0 |
| Opponent | All fights | 4 | 169 | 267 | -8 | 89 | 170 | -80 | -47.6 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| cnomg-c940641-p43 | move | 17 | 0 (0%) | 0 (0%) | 4 (24%) | 13 (76%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Clockwork Compass | Mine | L1228 |
| Elixir of Power | Mine | L1118, L1135 |
| Fistful of Laurels | Opponent | L1118 |
| Ring of Doom | Mine | L1118, L1135, L1228 |
| Ring of Jet | Mine | L1118, L1135, L1228 |

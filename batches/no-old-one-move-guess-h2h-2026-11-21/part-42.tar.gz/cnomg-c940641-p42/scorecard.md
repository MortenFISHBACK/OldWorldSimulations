# Doctrine scorecard: cnomg-c940641-p42

### Scorecard: cnomg-c940641-p42

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0918 | 6 | 1 | Mine | no | 1 | 5 | 2 | 1 | 0 | 0 | 0 | 250 |
| L0918 | 6 | 1 | Opponent | no | 3 | 6 | 1 | 3 | 1 | 0 | 0 | 185 |
| L0934 | 4 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 503 |
| L0934 | 4 | 1 | Opponent | no | 0 | 3 | 5 | 5 | 0 | 0 | 0 | 500 |
| L1026 | 6 | 1 | Mine | no | 6 | 2 | 1 | 0 | 0 | 0 | 0 | 0 |
| L1026 | 6 | 1 | Opponent | no | 0 | 5 | 1 | 2 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 0% | 2.3 | 3.5 | 1.0 | 0.7 | 0.0 | 0.0 | 0.0 | 251.0 |
| **Average** | | | Opponent | 0% | 1.0 | 4.7 | 2.3 | 3.3 | 0.3 | 0.0 | 0.0 | 228.3 |

### KPIs: cnomg-c940641-p42

Rules off - Opponent only: NO OLD ONE-MOVE GUESS.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 62% (8 of 13) | 0% (0 of 13) | 31% (8 of 26) |
| Winner chose to follow up after the loser gave ground |  | 75% (3 of 4); on the table 75% | 100% (2 of 2); on the table 100% | 83% (5 of 6); on the table 83% |
| Winner chose to pursue after the loser fell back in good order |  | 100% (1 of 1); on the table 100% | 100% (1 of 1); on the table 100% | 100% (2 of 2); on the table 100% |
| Winner chose to pursue after the loser fled |  | - | - | - |
| Winner chose to follow up or pursue (all three) |  | 80% (4 of 5); on the table 80% | 100% (3 of 3); on the table 100% | 88% (7 of 8); on the table 88% |
| Magic missiles tried each own turn | 50%+ | 40% (19 of 48) | 8% (1 of 12) | 33% (20 of 60) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 48% (19 of 40) | 10% (1 of 10) | 40% (20 of 50) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | - | - |
| Points that never fought | lower | 59% (3544 of 5997) | 71% (4235 of 5998) | 65% (7779 of 11995) |
|   infantry points that never fought | lower | 62% (985 of 1591) | 88% (1010 of 1147) | 73% (1995 of 2738) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 71% (24 of 34) | 75% (15 of 20) | 72% (39 of 54) |
| Bound items with a magic missile used (at least once a game) |  | 100% (2 of 2); 2.3 uses a game | 100% (1 of 1); 1.3 uses a game | 100% (3 of 3); 1.8 uses a game |
| Bound items with another spell used |  | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 100% (1 of 1); 0.3 uses a game | 0% (0 of 1); 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 68% (3869 of 5667) | 69% (3563 of 5186) | 68% (7432 of 10853) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 5.0 (52%) | 0.0 (0%) | 5.0 (38%) |
| MARCHED: its unit marched | 2.0 (21%) | 1.0 (27%) | 3.0 (22%) |
| IN COMBAT: engaged in combat | 2.0 (21%) | 0.7 (18%) | 2.7 (20%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.7 (18%) | 0.7 (5%) |
| GONE: slain | 0.7 (7%) | 0.0 (0%) | 0.7 (5%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 1.3 (36%) | 1.3 (10%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 4.0 | 1.0 | 6.7 | 1.3 | 1.7 |
| not cast | 2.0 | 5.0 | 13.3 | 2.7 | 14.3 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (2%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 2.0 (40%) | 5.0 (38%) | 0.7 (25%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 3.0 (22%) | 1.0 (38%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.3 (7%) | 2.7 (20%) | 0.0 (0%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 2.0 (100%) | 2.0 (40%) | 0.7 (5%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | 0.0 (0%) | 0.3 (7%) | 0.7 (5%) | 0.3 (12%) | 1.0 (7%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.3 (7%) | 0.0 (0%) | 0.7 (25%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 1.3 (10%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 13.0 (91%) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 61% (80 of 131) | 75% (54 of 72) | 66% (134 of 203) |
|   cavalry | - | 67% (8 of 12) | 67% (8 of 12) |
|   character | 100% (7 of 7) | 78% (14 of 18) | 84% (21 of 25) |
|   chariot | 76% (13 of 17) | 100% (5 of 5) | 82% (18 of 22) |
|   infantry | 45% (21 of 47) | 68% (17 of 25) | 53% (38 of 72) |
|   monster | 83% (10 of 12) | 83% (10 of 12) | 83% (20 of 24) |
|   war machine | 60% (29 of 48) | - | 60% (29 of 48) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 3.7 (22%) | 4.0 (67%) | 7.7 (33%) |
| CHARGED: it charged | 0.0 (0%) | 1.0 (17%) | 1.0 (4%) |
| IN COMBAT: it fought this turn or the last | 1.0 (6%) | 0.0 (0%) | 1.0 (4%) |
| MOVED: a war machine that moved | 1.7 (10%) | 0.0 (0%) | 1.7 (7%) |
| NO TARGET IN RANGE | 3.0 (18%) | 0.3 (6%) | 3.3 (14%) |
| ONLY IN COMBAT: the only targets were in combat | 0.3 (2%) | 0.0 (0%) | 0.3 (1%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 3.3 (20%) | 0.7 (11%) | 4.0 (17%) |
| SHELTERED: the target was sheltered | 3.3 (20%) | 0.0 (0%) | 3.3 (14%) |
| OTHER BAR | 0.7 (4%) | 0.0 (0%) | 0.7 (3%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 4.0 | 0.3 | 92% | 1.1 pts | 4 pts |
| character | 7.0 | 1.3 | 81% | 1.5 pts | 11 pts |
| chariot | 6.0 | 4.7 | 67% | 13.0 pts | 78 pts |
| infantry | 13.3 | 7.3 | 68% | 7.4 pts | 99 pts |
| monster | 10.0 | 1.3 | 90% | 3.0 pts | 30 pts |
| war machine | 10.0 | 7.3 | 70% | 17.9 pts | 179 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 1.3 | 4.7 | 3.0 |
| Charges that made contact a game | 1.0 | 2.7 | 1.8 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.67 declared, 0.67 contact (3 units) | 2.00 declared, 2.00 contact (1 units) | 1.00 declared, 1.00 contact (4 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 2.00 declared, 1.00 contact (1 units) | 2.00 declared, 1.00 contact (1 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.10 declared, 0.05 contact (20 units) | 0.32 declared, 0.16 contact (31 units) | 0.24 declared, 0.12 contact (51 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 50% (2 of 4) | - | - | 50% (2 of 4) |
| Character in a unit | 100% (5 of 5) | 100% (1 of 1) | - | 100% (6 of 6) |
| Character on its own | - | 67% (2 of 3) | 40% (2 of 5) | 50% (4 of 8) |
| Chariot | 100% (3 of 3) | 50% (1 of 2) | - | 80% (4 of 5) |
| Infantry | 45% (5 of 11) | 100% (2 of 2) | 0% (0 of 1) | 50% (7 of 14) |
| Monster | 100% (1 of 1) | 100% (1 of 1) | - | 100% (2 of 2) |
| Monstrous | 100% (2 of 2) | 100% (5 of 5) | - | 100% (7 of 7) |
| War Machines | 88% (7 of 8) | - | - | 88% (7 of 8) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Empire of Man | 2 | 50% (1 of 2); on the table 50% | 54% (13 of 24) | 69% | 75% (18 of 24) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Grand Cathay | 1 | 100% (3 of 3); on the table 100% | 25% (6 of 24) | 40% | 60% (6 of 10) | 100% (2 of 2); 7.0 uses a game | 0% (0 of 1); 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Ogre Kingdoms | 1 | - | 0% (0 of 6) | 94% | 100% (7 of 7) | 100% (1 of 1); 4.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 1 | 100% (1 of 1); on the table 100% | 17% (1 of 6) | 23% | 60% (3 of 5) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 1 | 100% (2 of 2); on the table 100% | - | 95% | 62% (5 of 8) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (cnomg-c940641-p42, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 50% (2) | 0% (0) | 40% (2) |
| ...free all their last turn and able to turn (per game) | 0.33 | 0.00 | 0.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.33 | 0.00 | 0.33 |
| ...with the charger already in that arc before they moved (per game) | 0.33 | 0.00 | 0.33 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: cnomg-c940641-p42

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.3 | 2.0 |
| Strategy | Charge objectives carried out (made contact) | 50% (1 of 2) | 18% (2 of 11) |
| Strategy | Shoot objectives carried out (shot that target) | 31% (16 of 52) | 61% (11 of 18) |
| Strategy | Support requests answered (helper made contact too) | - | 33% (1 of 3) |
| Strategy | Hexes on a unit its side charged or shot that turn | 0% (0 of 2) | - |
| Strategy | Joined characters whose unit fought | 44% (4 of 9) | 0% (0 of 1) |
| Strategy | Lone characters that fought | 60% (3 of 5) | 40% (2 of 5) |
| Movement | Charges halted short of contact | 0.0 | 0.3 |
| Movement | Idle units | 0.7 | 3.3 |
| Movement | Points that never moved of their own | 251.0 | 228.3 |
| Movement | Fights charged into per game | 1.0 | 2.3 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 1 | 0 of 4 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 1 | 1 of 4, net +0 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 1 of 1, net +45 | 0 of 4 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 0 of 1 | 1 of 4, net +0 |
| Shooting | Shots by shooting units (incl. breath weapons) | 17.3 | 18.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 31% (16 of 52) | 52% (28 of 54) |
| Shooting | Points destroyed by shooting units | 0.0 | 0.0 |
| Shooting | War machine shots | 9.7 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 62% (18 of 29) | - |
| Shooting | Points destroyed by war machines | 41.3 | 0.0 |
| Magic | Magic missiles cast | 3.0 | 0.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 33% (3 of 9) | 0% (0 of 1) |
| Magic | Wounds caused by magic missiles | 6.0 | - |
| Magic | Wounds caused by other spells | 1.0 | - |
| Magic | Points destroyed by magic (all spells) | 18.7 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.0 / 0.7 / 0.7 / 1.0 | 2.3 / 0.0 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 46.3 | 123.0 |
| Combat | Points run down | 25.7 | 0.0 |
| Combat | Net points per charged fight, damage counted | +75 | +103 |
| Combat | Net per 100 charger points, damage counted | +26.7 | +36.5 |
| Combat | First round won (charged fights) | 100% | 71% |
| Combat | Net points per charged fight | +61 | +63 |
| Combat | Net points per supported fight / lone fight | - / +61 | +0 / +73 |
| Combat | Charged fights on a top-3 enemy unit | 0 of 3 | 2 of 7 |
| Game | Points lost | 192.3 | 255.3 |
| Game | VP from objectives | 550.0 | 610.0 |
| Game | Lone holders (player turns) | 2.3 | 1.0 |

- Mine won / drew / lost: 1 / 1 / 1 of 3 ended games (of 3); mean margin (Mine - Opponent) -12 VP
- The side that went first won 2 of 2 games with a winner
- Points traded per game (both sides' losses): 448
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: cnomg-c940641-p42

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.3 | +8.4 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | 14.3 | +249.2 | 0.0 | 34.7 | 32.0 | +214.8 | 0.0 | 160.3 |
| ARRIVAL HUNT | - | - | - | - | 0.3 | +15.6 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 6.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ASSAILMENT BY POINTS | 0.3 | +2.3 | 0.0 | 0.0 | - | - | - | - |
| BACKUP TARGETS | - | - | - | - | 0.7 | +8.4 | 0.0 | 0.0 |
| BEST PRIZE | - | - | - | - | 0.3 | -24.0 | 0.0 | 0.0 |
| CANNON PLANNED TARGET | 8.0 | +91.7 | 64.0 | 0.0 | - | - | - | - |
| CANNON SIGHT KEPT | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CAST JOB | 4.3 | +64.3 | 51.3 | 0.0 | - | - | - | - |
| CASTER AWAY FROM SCREEN | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | - | - | - | - | 1.3 | +29.1 | 0.0 | 0.0 |
| CATCH FLIERS | 0.3 | +5.6 | 0.0 | 0.0 | - | - | - | - |
| CHALLENGE BY POINTS | 0.3 | +0.3 | 0.0 | 0.0 | 0.3 | +0.8 | 0.0 | 0.0 |
| CHARACTER GUNS | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHARGE LOSSES | 18.7 | -495.6 | 0.0 | 34.7 | 19.7 | -683.1 | 0.0 | 60.0 |
| CHARGE NOT DECLARED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CHARGE NOW FIRST | 0.3 | +0.0 | 15.0 | 123.0 | 0.7 | +0.0 | 123.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 9.0 | +0.0 | 0.0 | 0.0 | 17.0 | +0.0 | 0.0 | 37.0 |
| COMBAT PIVOT | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| COVER ONCE | 7.3 | -222.9 | 0.0 | 0.0 | 3.7 | -356.6 | 0.0 | 0.0 |
| DENIED BY THE FIGHT | 0.3 | -0.3 | 25.7 | 0.0 | 1.3 | -18.7 | 69.3 | 0.0 |
| DEPLOY BY FIGURES | 9.0 | -55.1 | 0.0 | 0.0 | 9.0 | +40.5 | 0.0 | 0.0 |
| EVASIVE BY THE ODDS | - | - | - | - | 1.0 | +2.3 | 0.0 | 0.0 |
| EXACT ROUND | 1.3 | +11.2 | 86.3 | 123.0 | 2.7 | +20.9 | 280.7 | 0.0 |
| FALL BACK GOOD ORDER | 1.0 | +0.5 | 66.3 | 123.0 | 3.3 | +3.8 | 315.3 | 0.0 |
| FALLS SHORT | - | - | - | - | 32.3 | +342.6 | 0.0 | 336.0 |
| FEATURE BUFFS | - | - | - | - | 0.7 | +10.0 | 0.0 | 0.0 |
| FIGHT TO THE END | 0.3 | -0.5 | 25.7 | 0.0 | 0.7 | +1.4 | 34.7 | 0.0 |
| FIRE IN ORDER | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FIVE ACTION | 106.7 | +5466.6 | 643.7 | 192.3 | 104.7 | +5098.2 | 315.3 | 766.0 |
| FLANK NOT WEIGHED | 5.7 | +0.0 | 0.0 | 0.0 | 5.0 | +0.0 | 0.0 | 0.0 |
| FOLLOW UP WEIGHED | 0.3 | +17.9 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| FOUR ROUNDS | 1.3 | +18.8 | 86.3 | 123.0 | 4.3 | +211.9 | 315.3 | 0.0 |
| FREED FROM HIS FIGHT | 2.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 0.3 | -0.2 | 0.0 | 0.0 | 0.7 | -4.1 | 0.0 | 0.0 |
| FRIENDS SHOTS CHECKED | - | - | - | - | 0.3 | -0.3 | 0.0 | 0.0 |
| GIVES UP | 0.3 | -4.3 | 20.0 | 0.0 | - | - | - | - |
| GOAL WALK | 9.0 | +446.3 | 0.0 | 0.0 | 24.0 | +2218.4 | 0.0 | 97.3 |
| GUN FIGURES | 2.3 | +33.1 | 61.7 | 0.0 | 0.3 | +7.7 | 0.0 | 0.0 |
| GUN MASK | 6.0 | +452.6 | 0.0 | 0.0 | - | - | - | - |
| HARD STAY DROPPED | 2.7 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 246.7 |
| HE REFORMS ONCE FREED | 1.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 11.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE LIST | 5.3 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 1.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 37.0 |
| HIS MOVE AND SHOT | 2.7 | -7.6 | 0.0 | 0.0 | 7.7 | -100.4 | 0.0 | 49.0 |
| HIS MOVE AS HE DECIDES | - | - | - | - | 36.7 | +9.7 | 227.0 | 0.0 |
| HIS MOVE WHY | 27.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS ONE MOVE | - | - | - | - | 22.0 | +68.4 | 0.0 | 0.0 |
| HIS ONE QUARTER | 1.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 3.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 11.3 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 42.0 | +1217.8 | 0.0 | 69.3 | 81.3 | +6145.4 | 0.0 | 220.3 |
| HIS SHOTS BY HIS RUN | 39.0 | +574.5 | 0.0 | 69.3 | 63.7 | +1572.0 | 0.0 | 198.0 |
| HIS TURN DENIED | 0.3 | +3.2 | 25.7 | 0.0 | 2.0 | +96.6 | 69.3 | 0.0 |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 18.3 | +0.0 | 0.0 | 0.0 | 18.7 | +0.0 | 0.0 | 51.3 |
| HOLDER ASSIGNMENT | 13.0 | +1312.3 | 0.0 | 0.0 | 13.3 | +1217.7 | 0.0 | 25.7 |
| HOLDS AMBUSHERS | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 1.3 | -41.2 | 86.3 | 123.0 | 4.0 | -146.6 | 315.3 | 0.0 |
| HUNT IN PAIRS | 1.3 | +58.1 | 0.0 | 0.0 | - | - | - | - |
| IDLE COST | - | - | - | - | 23.0 | -321.5 | 0.0 | 41.3 |
| JOINT CHARGE NOW | - | - | - | - | 1.3 | +83.9 | 0.0 | 0.0 |
| JOINT ON THE TABLE | - | - | - | - | 0.3 | +25.0 | 0.0 | 0.0 |
| KEPT FROM ITS LAST STOP | 6.3 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 0.7 | +15.4 | 0.0 | 0.0 | 1.3 | +93.2 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| LEGAL CHARGES ONLY | 1.0 | +0.0 | 20.0 | 157.7 | 5.0 | +0.0 | 104.0 | 54.0 |
| LONE WIZARD KEPT IN | 1.3 | +43.3 | 0.0 | 0.0 | - | - | - | - |
| LONG SHOT | - | - | - | - | 1.0 | +10.8 | 34.7 | 0.0 |
| LOST AFTER ESCAPE | 1.0 | +7.5 | 71.3 | 0.0 | 3.7 | +34.0 | 280.7 | 0.0 |
| MAKE SURE TOGETHER | 0.3 | +0.5 | 0.0 | 0.0 | - | - | - | - |
| MANOEUVRE | 2.3 | -12.7 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.3 | +5.4 | 0.0 | 0.0 | - | - | - | - |
| MARCH BY THE SUM | 1.0 | +55.5 | 0.0 | 0.0 | 0.3 | +0.7 | 0.0 | 0.0 |
| MARCH CHECK | 2.0 | +120.9 | 0.0 | 0.0 | 0.3 | +17.4 | 0.0 | 0.0 |
| MARCH OF THE TABLE | 0.7 | +7.2 | 0.0 | 0.0 | 0.3 | +42.8 | 0.0 | 0.0 |
| MARCH OVER CASTS | 2.7 | +60.0 | 0.0 | 0.0 | 0.7 | -94.4 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 4.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 3.7 | +67.8 | 0.0 | 0.0 | 3.0 | +33.7 | 0.0 | 63.3 |
| MEETS IN TIME | 3.7 | +414.2 | 0.0 | 0.0 | 3.7 | +549.1 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 9.7 | +155.1 | 0.0 | 0.0 | 2.0 | +31.5 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 12.3 | +119.7 | 0.0 | 0.0 | 2.7 | +24.4 | 0.0 | 0.0 |
| MOVE ORDER | 0.7 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 41.3 | 11.3 |
| MOVE TO CHARGE COMPUTED | 4.7 | +394.4 | 0.0 | 0.0 | 5.0 | +416.9 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 5.7 | +264.3 | 0.0 | 0.0 | 5.7 | +255.2 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 2.3 | +338.0 | 0.0 | 0.0 | 3.7 | +273.6 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 1.3 | -16.8 | 86.3 | 123.0 | 3.0 | -75.6 | 69.3 | 0.0 |
| NO LATE CUT | 4.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OFF BEST | 4.3 | -127.2 | 20.0 | 0.0 | 7.7 | -248.3 | 0.0 | 25.7 |
| OGRE LOADER SECOND SHOT | 4.0 | +11.4 | 0.0 | 0.0 | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ONE FIGHT FORMULA | 5.0 | -88.2 | 0.0 | 0.0 | 4.0 | -61.7 | 0.0 | 11.3 |
| ONE JOINT FIGURE | 0.3 | +5.5 | 25.7 | 0.0 | - | - | - | - |
| ONE OBJECTIVE FORMULA | 4.3 | +65.9 | 0.0 | 0.0 | 5.7 | -46.9 | 0.0 | 25.7 |
| ONE PROMISE A TARGET | 0.7 | -12.8 | 0.0 | 0.0 | 0.3 | -14.3 | 0.0 | 0.0 |
| ONE ROUTE | 4.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| OPENS UP | 0.3 | +9.1 | 15.0 | 123.0 | 0.3 | +17.2 | 34.7 | 0.0 |
| OVERRUNS AWAY | 1.0 | +5.5 | 66.3 | 123.0 | 1.7 | +46.5 | 246.0 | 0.0 |
| PLAN RESULT | 45.3 | +794.5 | 175.7 | 350.0 | 47.7 | +402.4 | 34.7 | 419.3 |
| PROMISE BELOW ZERO | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE BY ITS OWN SUM | 8.0 | -189.4 | 0.0 | 0.0 | 5.3 | -301.9 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | 2.7 | -2.1 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | 0.3 | -0.2 | 0.0 | 0.0 | 0.3 | -2.8 | 0.0 | 0.0 |
| QUARTER ODDS | 10.0 | +818.1 | 0.0 | 0.0 | 15.0 | +921.1 | 0.0 | 0.0 |
| REAL GROUND | 4.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | - | - | - | - | 4.7 | +330.4 | 0.0 | 40.7 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 5.0 | +0.0 | 0.0 | 48.3 |
| REFORMS TO MEET IT | 1.0 | -77.6 | 0.0 | 0.0 | 0.7 | -34.0 | 0.0 | 0.0 |
| REFUSING RETIRES | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | - | - | - | - | 0.7 | +26.2 | 0.0 | 0.0 |
| RISK BY ARC | 1.3 | +17.1 | 86.3 | 123.0 | 2.3 | -174.5 | 315.3 | 0.0 |
| RISK ON THE WAY | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| ROUNDS AFTER TERROR | 0.7 | +15.8 | 51.3 | 0.0 | 2.3 | -43.2 | 280.7 | 0.0 |
| RUN DOWN | 0.7 | -15.1 | 51.3 | 0.0 | 4.3 | -52.3 | 315.3 | 0.0 |
| SCOUT SPOT | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +7.2 | 0.0 | 0.0 |
| SCOUT WAITS | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 2.7 | -266.7 | 0.0 | 0.0 |
| SEARCH SPOT | 1.0 | +5.2 | 0.0 | 34.7 | 0.7 | +29.7 | 0.0 | 0.0 |
| SECOND LOOK | 0.7 | +8.4 | 45.7 | 0.0 | 0.7 | +31.7 | 123.0 | 0.0 |
| SET CREDITED ONCE | 0.3 | -0.4 | 0.0 | 0.0 | - | - | - | - |
| SET UP BY THE SET | 1.3 | +20.7 | 0.0 | 0.0 | - | - | - | - |
| SET UP TOGETHER | 0.3 | +0.5 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | 0.7 | +1.3 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS ON THE TABLE | 16.7 | +0.0 | 0.0 | 0.0 | 8.0 | +0.0 | 0.0 | 265.3 |
| SHOOTS FROM THE BEST SPOT | 2.3 | +13.8 | 37.3 | 0.0 | - | - | - | - |
| SHOT OR CHARGE | 0.3 | -1.0 | 25.7 | 0.0 | 0.7 | -16.0 | 0.0 | 0.0 |
| SHOT RISK POINTS | 26.7 | -297.9 | 0.0 | 34.7 | 50.7 | +100.9 | 0.0 | 131.7 |
| SHOTS AFTER THE MOVES | 5.0 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 28.7 | +927.5 | 0.0 | 34.7 | 18.0 | +282.8 | 0.0 | 291.0 |
| SPELL WORTH | - | - | - | - | 4.0 | +67.1 | 0.0 | 0.0 |
| SPELLS IN THE FIGHT | - | - | - | - | 0.3 | -6.0 | 0.0 | 0.0 |
| SPOT AS THE GAME MOVES | 4.0 | +0.0 | 0.0 | 0.0 | 7.7 | +0.0 | 0.0 | 80.0 |
| STAND AND SHOOT | 0.3 | -2.9 | 25.7 | 0.0 | 1.3 | -8.5 | 34.7 | 0.0 |
| STANDS FOR A REASON | - | - | - | - | 10.7 | +0.0 | 0.0 | 37.3 |
| STANDS STILL | 54.7 | +0.0 | 557.3 | 0.0 | 30.0 | +0.0 | 0.0 | 530.7 |
| STAY WORTH | 45.3 | +345.0 | 520.0 | 34.7 | 26.3 | +239.4 | 0.0 | 814.7 |
| STRIKE BY THE ODDS | - | - | - | - | 0.3 | +0.2 | 0.0 | 11.3 |
| SUPPORT ADDS | 2.7 | +100.7 | 0.0 | 0.0 | 2.3 | +19.0 | 0.0 | 15.0 |
| SUPPORT WORKED OUT | 2.7 | +100.7 | 0.0 | 0.0 | 2.3 | +19.0 | 0.0 | 15.0 |
| THE DEARER SUM KEEPS ITS PLAN | 2.0 | +0.0 | 0.0 | 34.7 | 1.7 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 3.3 | +0.0 | 0.0 | 0.0 | 4.7 | +0.0 | 0.0 | 48.7 |
| THE ROW KEEPS ITS WAY | 3.3 | +0.0 | 0.0 | 0.0 | 6.3 | +0.0 | 0.0 | 25.7 |
| THE STEP BACK IS MADE | 2.7 | +0.0 | 0.0 | 0.0 | 4.7 | +0.0 | 0.0 | 25.7 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 45.0 | +0.0 | 0.0 | 34.7 | 51.0 | +0.0 | 0.0 | 377.3 |
| TIED UP BY THE SUM | 0.3 | +32.6 | 15.0 | 123.0 | 0.3 | +53.6 | 34.7 | 0.0 |
| TIME ON OUR SIDE | 51.3 | +661.1 | 212.0 | 34.7 | - | - | - | - |
| WAITS AGAIN | 1.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| WAR ENGINE JOBS | - | - | - | - | 2.7 | +0.0 | 0.0 | 493.3 |
| WHAT THE JOINER ADDS | - | - | - | - | 1.3 | -39.7 | 492.0 | 0.0 |
| WHO FIGHTS | 0.7 | -9.6 | 51.3 | 0.0 | 0.7 | -3.0 | 0.0 | 0.0 |
| WHO GETS IN | - | - | - | - | 1.0 | +71.9 | 0.0 | 0.0 |
| WHO HITS BACK | 0.3 | +2.5 | 0.0 | 0.0 | 0.3 | +20.8 | 0.0 | 0.0 |
| WHOLE FIGHT | - | - | - | - | 0.7 | +41.4 | 246.0 | 0.0 |
| WHOLE FIGHT DANGER | 1.7 | -115.5 | 0.0 | 0.0 | 0.3 | -19.2 | 0.0 | 0.0 |
| WOUNDS ON THE RANKS | 5.0 | +54.9 | 0.0 | 0.0 | 0.7 | +10.5 | 0.0 | 0.0 |

### Rule changes: cnomg-c940641-p42

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS SHOT LIST | 370 | 360 | 133 | 44.33 | +2102 | +15.8 |
| ARMY TABLE | 139 | 139 | 104 | 34.67 | +1298 | +12.5 |
| HIS SHOTS BY HIS RUN | 308 | 296 | 87 | 29.00 | +1209 | +13.9 |
| HIS MOVE AS HE DECIDES | 110 | 110 | 81 | 27.00 | +0 | +0.0 |
| HOLDER ASSIGNMENT | 79 | 79 | 73 | 24.33 | +4251 | +58.2 |
| HIS MOVE WHY | 82 | 82 | 49 | 16.33 | +0 | +0.0 |
| SHOT RISK POINTS | 232 | 222 | 47 | 15.67 | +1610 | +34.3 |
| OFF BEST | 36 | 36 | 36 | 12.00 | -1126 | -31.3 |
| GOAL WALK | 99 | 97 | 34 | 11.33 | +1326 | +39.0 |
| DEPLOY BY FIGURES | 54 | 54 | 32 | 10.67 | +492 | +15.4 |
| THE TABLE AGAIN | 36 | 36 | 28 | 9.33 | +0 | +0.0 |
| HARD STAY DROPPED | 21 | 21 | 21 | 7.00 | +0 | +0.0 |
| HIS ONE MOVE | 66 | 64 | 21 | 7.00 | +0 | +0.0 |
| ARTILLERY RE-ROLL WEIGHED | 19 | 19 | 19 | 6.33 | +0 | +0.0 |
| LEGAL CHARGES ONLY | 18 | 18 | 18 | 6.00 | +0 | +0.0 |
| MEETS IN TIME | 22 | 22 | 18 | 6.00 | +1382 | +76.8 |
| PROMISE BY ITS OWN SUM | 40 | 40 | 18 | 6.00 | -1474 | -81.9 |
| TIME ON OUR SIDE | 154 | 127 | 17 | 5.67 | +110 | +6.5 |
| STAY WORTH | 215 | 192 | 16 | 5.33 | +142 | +8.9 |
| REDIRECT FOR A FRIEND IN REACH | 15 | 15 | 15 | 5.00 | +0 | +0.0 |
| MOVE TO CHARGE COMPUTED | 29 | 19 | 14 | 4.67 | +763 | +54.5 |
| IDLE COST | 69 | 43 | 13 | 4.33 | +129 | +9.9 |
| MOVE ORDER | 13 | 13 | 13 | 4.33 | +0 | +0.0 |
| FIVE ACTION | 634 | 613 | 12 | 4.00 | +579 | +48.3 |
| OGRE LOADER SECOND SHOT | 12 | 12 | 12 | 4.00 | +34 | +2.9 |
| CAST JOB | 13 | 13 | 9 | 3.00 | +105 | +11.6 |
| GUN MASK | 18 | 18 | 7 | 2.33 | +282 | +40.3 |
| MAX FOR POSITIONING | 20 | 16 | 7 | 2.33 | +18 | +2.6 |
| NEXT CHARGE BY LIST | 18 | 16 | 7 | 2.33 | +326 | +46.5 |
| CHARGE LOSSES | 115 | 106 | 6 | 2.00 | +1010 | +168.3 |
| LANE BY FIGURES | 6 | 6 | 6 | 2.00 | +326 | +54.3 |
| MARCH CHECK | 7 | 7 | 5 | 1.67 | +55 | +11.0 |
| SCOUT WAITS | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| SHOTS IN THE MOVE | 140 | 112 | 5 | 1.67 | +140 | +28.0 |
| WOUNDS ON THE RANKS | 17 | 17 | 5 | 1.67 | +28 | +5.7 |
| ADVANCE LANE KEPT | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| CASTING BLOCK | 4 | 4 | 4 | 1.33 | +37 | +9.2 |
| FALLS SHORT | 97 | 76 | 4 | 1.33 | +51 | +12.8 |
| FOUR ROUNDS | 17 | 14 | 4 | 1.33 | +154 | +38.6 |
| JOINT CHARGE NOW | 4 | 4 | 4 | 1.33 | +252 | +63.0 |
| LONE WIZARD KEPT IN | 4 | 4 | 4 | 1.33 | +130 | +32.5 |
| MARCH BY THE SUM | 4 | 4 | 4 | 1.33 | +168 | +42.1 |
| NEARER NOT NEEDED | 34 | 32 | 4 | 1.33 | +90 | +22.6 |
| QUARTER ODDS | 75 | 73 | 4 | 1.33 | +171 | +42.6 |
| SECOND LOOK | 4 | 4 | 4 | 1.33 | +120 | +30.1 |
| CANNON SIGHT KEPT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| COVER ONCE | 33 | 24 | 3 | 1.00 | +452 | +150.6 |
| MARCH OF THE TABLE | 3 | 3 | 3 | 1.00 | -150 | -49.9 |
| MISSILES IN THE MOVE | 35 | 24 | 3 | 1.00 | +53 | +17.7 |
| ONE PROMISE A TARGET | 3 | 3 | 3 | 1.00 | -81 | -27.1 |
| SHOOTS FROM THE BEST SPOT | 7 | 7 | 3 | 1.00 | +10 | +3.4 |
| SHOTS AFTER THE MOVES | 24 | 24 | 3 | 1.00 | +0 | +0.0 |
| SUPPORT ADDS | 15 | 13 | 3 | 1.00 | +123 | +40.9 |
| SUPPORT WORKED OUT | 15 | 13 | 3 | 1.00 | +123 | +40.9 |
| THE ROW IN ITS ORDER | 24 | 3 | 3 | 1.00 | +0 | +0.0 |
| WHO GETS IN | 3 | 3 | 3 | 1.00 | +216 | +71.9 |
| CASTER AWAY FROM SCREEN | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| CHALLENGE BY POINTS | 2 | 2 | 2 | 0.67 | +3 | +1.6 |
| CHARGE NOW FIRST | 3 | 3 | 2 | 0.67 | -25 | -12.6 |
| COMBAT PIVOT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| EXACT ROUND | 12 | 10 | 2 | 0.67 | +8 | +4.2 |
| FOLLOW UP WEIGHED | 2 | 2 | 2 | 0.67 | +54 | +26.8 |
| HIS MOVE AND SHOT | 31 | 29 | 2 | 0.67 | +6 | +3.0 |
| HIS TURN DENIED | 7 | 7 | 2 | 0.67 | +64 | +31.9 |
| HUNT IN PAIRS | 4 | 2 | 2 | 0.67 | +153 | +76.3 |
| MISSILES NEXT TURN | 45 | 30 | 2 | 0.67 | +1 | +0.5 |
| OVERRUNS AWAY | 8 | 6 | 2 | 0.67 | +8 | +4.2 |
| PROMISE KNOWS THE FIGHT | 14 | 9 | 2 | 0.67 | -6 | -3.0 |
| RESERVE FALL BACK | 2 | 2 | 2 | 0.67 | +78 | +39.2 |
| SEARCH SPOT | 5 | 5 | 2 | 0.67 | +133 | +66.7 |
| SHOOTERS IN TWO RANKS | 2 | 2 | 2 | 0.67 | +4 | +2.0 |
| TIED UP BY THE SUM | 2 | 2 | 2 | 0.67 | +149 | +74.3 |
| WHO HITS BACK | 2 | 2 | 2 | 0.67 | +16 | +8.2 |
| AFTERMATH IN POINTS | 1 | 1 | 1 | 0.33 | +25 | +25.3 |
| ASSAILMENT BY POINTS | 1 | 1 | 1 | 0.33 | +7 | +6.9 |
| BEST PRIZE | 1 | 1 | 1 | 0.33 | -72 | -71.9 |
| CANNON PLANNED TARGET | 24 | 24 | 1 | 0.33 | -30 | -29.8 |
| CHARGE NOT DECLARED | 1 | 1 | 1 | 0.33 | -92 | -92.0 |
| EVASIVE BY THE ODDS | 3 | 3 | 1 | 0.33 | +0 | +0.0 |
| FIRE IN ORDER | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FRIENDS SHOTS CHECKED | 1 | 1 | 1 | 0.33 | -1 | -0.9 |
| HOLDS AMBUSHERS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| JOINT ON THE TABLE | 1 | 1 | 1 | 0.33 | +75 | +75.2 |
| LONG SHOT | 3 | 3 | 1 | 0.33 | +6 | +5.9 |
| LOST AFTER ESCAPE | 14 | 11 | 1 | 0.33 | +2 | +1.8 |
| MANOEUVRE | 11 | 11 | 1 | 0.33 | +1 | +0.6 |
| ONE JOINT FIGURE | 1 | 1 | 1 | 0.33 | +2 | +1.8 |
| REDIRECT COUNTER | 14 | 14 | 1 | 0.33 | +168 | +168.3 |
| REFUSING RETIRES | 1 | 1 | 1 | 0.33 | -37 | -37.2 |
| RISK BY ARC | 11 | 8 | 1 | 0.33 | +50 | +49.7 |
| ROUNDS AFTER TERROR | 9 | 7 | 1 | 0.33 | +2 | +1.8 |
| STRIKE BY THE ODDS | 1 | 1 | 1 | 0.33 | +1 | +0.6 |
| WHOLE FIGHT | 2 | 1 | 1 | 0.33 | +7 | +6.7 |
| WHOLE FIGHT DANGER | 6 | 6 | 1 | 0.33 | +210 | +210.1 |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| BACKUP TARGETS | 2 | 2 | 0 | 0.00 | - | - |
| CATCH FLIERS | 1 | not checked | - | - | - | - |
| CHARACTER GUNS | 18 | 17 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 78 | 75 | 0 | 0.00 | - | - |
| DENIED BY THE FIGHT | 5 | 5 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 13 | 11 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 2 | 2 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 3 | 3 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 32 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 9 | 8 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 3 | 3 | 0 | 0.00 | - | - |
| GIVES UP | 1 | not checked | - | - | - | - |
| GUN FIGURES | 8 | not checked | - | - | - | - |
| HE REFORMS ONCE FREED | 7 | 6 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 51 | 46 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 27 | 24 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 6 | 5 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 7 | 6 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 13 | 10 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN RUN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 111 | 111 | 0 | 0.00 | - | - |
| HONEST WORTH | 16 | 13 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 25 | 25 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 1 | 1 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 1 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 10 | 10 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 14 | 14 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 13 | 11 | 0 | 0.00 | - | - |
| NO LATE CUT | 14 | 14 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 18 | 18 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 3 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 27 | 16 | 0 | 0.00 | - | - |
| ONE OBJECTIVE FORMULA | 30 | 26 | 0 | 0.00 | - | - |
| ONE ROUTE | 14 | 14 | 0 | 0.00 | - | - |
| OPENS UP | 2 | 2 | 0 | 0.00 | - | - |
| PLAN RESULT | 279 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 3 | 3 | 0 | 0.00 | - | - |
| PROMISE READS THE TABLE | 2 | 2 | 0 | 0.00 | - | - |
| REAL GROUND | 14 | 14 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 5 | 4 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 2 | 2 | 0 | 0.00 | - | - |
| RUN DOWN | 15 | 13 | 0 | 0.00 | - | - |
| SCOUT SPOT | 4 | 4 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 8 | 8 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 1 | 1 | 0 | 0.00 | - | - |
| SET UP BY THE SET | 4 | 4 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 1 | 1 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 74 | not checked | - | - | - | - |
| SHOT OR CHARGE | 3 | 3 | 0 | 0.00 | - | - |
| SPELL WORTH | 12 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 35 | 32 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 5 | 5 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 32 | 30 | 0 | 0.00 | - | - |
| STANDS STILL | 254 | 251 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 11 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 29 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 22 | not checked | - | - | - | - |
| THE TABLE BINDS | 288 | not checked | - | - | - | - |
| WAITS AGAIN | 7 | 7 | 0 | 0.00 | - | - |
| WAR ENGINE JOBS | 8 | 8 | 0 | 0.00 | - | - |
| WHAT THE JOINER ADDS | 4 | 2 | 0 | 0.00 | - | - |
| WHO FIGHTS | 4 | 4 | 0 | 0.00 | - | - |

### Off best figure: cnomg-c940641-p42

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 4.00 | 6.00 | 31.6 |
| PROMISE BY ITS OWN SUM | rule | 3.67 | 2.33 | 81.9 |
| ARMY TABLE | rule | 1.00 | 4.33 | 59.2 |
| HOLDER ASSIGNMENT | rule | 1.00 | 0.67 | 27.8 |
| RULE SWITCHED OFF | gate | - | 1.33 | 41.0 |
| MARCH OF THE TABLE | rule | 0.67 | 0.33 | 49.9 |
| ONE PROMISE A TARGET | rule | 0.67 | 0.33 | 27.1 |
| CHARGE NOW FIRST | rule | 0.33 | 0.33 | 12.6 |
| PROMISE KNOWS THE FIGHT | rule | 0.67 | - | 3.0 |
| AFTERMATH BAND | gate | - | 0.33 | 0.9 |
| BEST PRIZE | rule | - | 0.33 | 71.9 |
| CANNON PLANNED TARGET | rule | 0.33 | - | 29.8 |
| CHARGE NOT DECLARED | rule | - | 0.33 | 92.0 |
| FRIENDS SHOTS CHECKED | rule | - | 0.33 | 0.9 |
| NO REASON | gate | 0.33 | - | 13.0 |
| REFUSING RETIRES | rule | - | 0.33 | 37.2 |

### Plans: cnomg-c940641-p42

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.0 | 67% | 46 | 35 | 75% |
| Mine | move | 29.3 | 99% | 1476 | 0 | 0% |
| Mine | shoot | 15.0 | 60% | 768 | 760 | 99% |
| Opponent | charge | 2.0 | 67% | 97 | 331 | 342% |
| Opponent | move | 39.3 | 96% | 1905 | 0 | 0% |
| Opponent | shoot | 5.0 | 33% | 252 | 72 | 28% |
| Opponent | support | 1.3 | 100% | 0 | 0 | - |

### Battle groups: cnomg-c940641-p42

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | REDIRECT COUNTER | 4.7 | 29% | 50% | 25% | 0% | 0% | 0% | 67% | 33% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: cnomg-c940641-p42

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Character | 12 | 9 (12) | 9 | 0 | 21 | 33% | 3.0 | 5 (5) | 9 (5) | 32 (2) | 12 (8) | 6 (4) |
| Mine | Clean-up | 2 | 83 (2) | 0 | 83 | 0 | 100% | - | - | - | 83 (2) | 83 (2) | - |
| Mine | Fast Hammer | 3 | 13 (3) | 0 | 13 | 0 | 0% | 2.3 | 0 (1) | 20 (2) | - | 18 (2) | 0 (1) |
| Mine | Hammer | 7 | 13 (7) | 13 | 0 | 0 | 14% | 1.8 | 0 (1) | 5 (3) | 23 (3) | 18 (5) | 0 (2) |
| Mine | Shooter | 6 | 111 (6) | 0 | 111 | 33 | 0% | 2.0 | 0 (1) | 231 (2) | 67 (3) | 133 (5) | 0 (1) |
| Mine | War machine | 8 | 3 (8) | 3 | 0 | 0 | 0% | 1.1 | 0 (1) | 7 (4) | 0 (3) | - | 3 (8) |
| Mine | Wizard | 2 | 0 (2) | 0 | 0 | 0 | 50% | 2.0 | - | 0 (2) | - | 0 (2) | - |
| Opponent | Chaff | 11 | 112 (11) | 0 | 112 | 52 | 45% | 2.8 | 94 (3) | 117 (1) | 118 (7) | 112 (11) | - |
| Opponent | Character | 6 | 19 (6) | 19 | 0 | 0 | 0% | 1.7 | 37 (2) | 14 (2) | 0 (2) | 10 (2) | 24 (4) |
| Opponent | Clean-up | 4 | 27 (4) | 0 | 27 | 0 | 25% | 2.3 | - | 56 (2) | 0 (2) | 36 (3) | 0 (1) |
| Opponent | Early | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Fragile | 1 | 0 (1) | 0 | 0 | 100 | 0% | 2.0 | 0 (1) | - | - | 0 (1) | - |
| Opponent | Hammer | 10 | 0 (10) | 0 | 0 | 20 | 40% | 1.8 | 0 (4) | 0 (4) | 0 (2) | 0 (2) | 0 (8) |
| Opponent | Holder | 1 | 92 (1) | 0 | 92 | 0 | 100% | - | - | 92 (1) | - | - | 92 (1) |
| Opponent | Shooter | 1 | 150 (1) | 0 | 150 | 0 | 0% | 1.0 | - | 150 (1) | - | 150 (1) | - |

### Charged fights: cnomg-c940641-p42

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Empire of Man | 2 | 90 | 38 | 0.5 | 1.0 | 77 | 0 | +77 | 0 of 1 | 1 of 1 | - | +77 |
| Mine | Grand Cathay | 1 | 0 | 105 | 2.0 | 1.0 | 52 | 0 | +52 | 0 of 2 | 2 of 2 | - | +52 |
| **Mine** | all armies | 3 | 60 | 61 | 1.0 | 1.0 | 61 | 0 | +61 | 0 of 3 | 3 of 3 | - | +61 |
| Opponent | Ogre Kingdoms | 1 | 0 | 0 | 1.0 | 1.0 | 0 | 34 | -34 | 0 of 1 | 0 of 1 | - | -34 |
| Opponent | Vampire Counts | 1 | 0 | 369 | 4.0 | 1.2 | 92 | 0 | +92 | 2 of 4 | 3 of 4 | +0 | +123 |
| Opponent | Wood Elf Realms | 1 | 0 | 104 | 2.0 | 1.0 | 52 | 0 | +52 | 0 of 2 | 2 of 2 | - | +52 |
| **Opponent** | all armies | 3 | 0 | 158 | 2.3 | 1.1 | 68 | 5 | +63 | 2 of 7 | 5 of 7 | +0 | +73 |

### Effective charges: cnomg-c940641-p42

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Grand Cathay | 2 | 0 | 0 | 0 | 0 | 1 (net +45) | 0 | 1 | 0% (0 of 1) |
| Opponent | Vampire Counts | 4 | 0 | 0 | 1 (net +0) | 1 (net +0) | 0 | 0 | 2 | 50% (1 of 2) |
| Opponent | Wood Elf Realms | 2 | 0 | 0 | 0 | 1 (net +104) | 0 | 1 (net +0) | 0 | 0% (0 of 2) |

### Charged fights, damage counted: cnomg-c940641-p42

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 369 | 45 | +45 | 45 | 0 | +45 | +12.2 |
| Mine | No odds | 2 | 235 | 68 | +68 | 89 | 0 | +89 | +38.0 |
| Mine | All fights | 3 | 280 | 61 | +61 | 75 | 0 | +75 | +26.7 |
| Opponent | Effective (55-75%) | 1 | 110 | 162 | +0 | 27 | 28 | -0 | -0.5 |
| Opponent | 76-89% | 2 | 554 | 236 | +52 | 88 | 0 | +88 | +15.9 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 109 | 104 | +0 | 74 | 0 | +74 | +68.3 |
| Opponent | No odds | 3 | 214 | 219 | +112 | 193 | 37 | +156 | +72.9 |
| Opponent | All fights | 7 | 281 | 200 | +63 | 122 | 20 | +103 | +36.5 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| cnomg-c940641-p42 | move | 19 | 2 (11%) | 2 (11%) | 3 (16%) | 14 (74%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L0934, L1026 |
| Fistful of Laurels | Opponent | L0918 |
| Ring of Jet | Mine | L1026 |
| Twice-Blessed Armour | Mine | L1026 |

# Doctrine scorecard: cnomg-c940641-p30

### Scorecard: cnomg-c940641-p30

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0913 | 1 | 1 | Mine | no | 5 | 4 | 1 | 1 | 0 | 0 | 0 | 420 |
| L0913 | 1 | 1 | Opponent | no | 15 | 3 | 1 | 0 | 2 | 0 | 0 | 140 |
| L0930 | 6 | 1 | Mine | no | 0 | 3 | 1 | 2 | 0 | 0 | 0 | 125 |
| L0930 | 6 | 1 | Opponent | no | 6 | - | 0 | 3 | 0 | 0 | 0 | 0 |
| L1021 | 1 | 1 | Mine | no | 5 | 3 | 1 | 0 | 0 | 0 | 0 | 330 |
| L1021 | 1 | 1 | Opponent | no | 0 | - | 0 | 5 | 1 | 0 | 0 | 290 |
| **Average** | | | Mine | 0% | 3.3 | 3.3 | 1.0 | 1.0 | 0.0 | 0.0 | 0.0 | 291.7 |
| **Average** | | | Opponent | 0% | 7.0 | 3.0 | 0.3 | 2.7 | 1.0 | 0.0 | 0.0 | 143.3 |

### KPIs: cnomg-c940641-p30

Rules off - Opponent only: NO OLD ONE-MOVE GUESS.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 64% (9 of 14) | 0% (0 of 13) | 33% (9 of 27) |
| Winner chose to follow up after the loser gave ground |  | - | 100% (3 of 3); on the table 100% | 100% (3 of 3); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | - | - | - |
| Winner chose to pursue after the loser fled |  | - | - | - |
| Winner chose to follow up or pursue (all three) |  | - | 100% (3 of 3); on the table 100% | 100% (3 of 3); on the table 100% |
| Magic missiles tried each own turn | 50%+ | 48% (23 of 48) | 8% (1 of 12) | 40% (24 of 60) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 50% (23 of 46) | 14% (1 of 7) | 45% (24 of 53) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 57% (8 of 14) | 57% (8 of 14) |
| Points that never fought | lower | 78% (4703 of 5997) | 79% (4714 of 5999) | 79% (9417 of 11996) |
|   infantry points that never fought | lower | 83% (1316 of 1591) | 88% (1456 of 1660) | 85% (2772 of 3251) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 62% (21 of 34) | 70% (16 of 23) | 65% (37 of 57) |
| Bound items with a magic missile used (at least once a game) |  | 100% (2 of 2); 3.0 uses a game | 50% (1 of 2); 1.7 uses a game | 75% (3 of 4); 2.3 uses a game |
| Bound items with another spell used |  | 0% (0 of 1); 0.0 uses a game | 0% (0 of 2); 0.0 uses a game | 0% (0 of 3); 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0% (0 of 1); 0.0 uses a game | 100% (2 of 2); 0.7 uses a game | 67% (2 of 3); 0.3 uses a game |
|   their share of the points of units over 100 pts | lower | 59% (3341 of 5667) | 65% (3360 of 5150) | 62% (6701 of 10817) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 5.0 (60%) | 1.0 (27%) | 6.0 (50%) |
| MARCHED: its unit marched | 2.7 (32%) | 0.7 (18%) | 3.3 (28%) |
| IN COMBAT: engaged in combat | 0.7 (8%) | 0.0 (0%) | 0.7 (6%) |
| GONE: slain | 0.0 (0%) | 1.7 (45%) | 1.7 (14%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.3 (9%) | 0.3 (3%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 2.3 | 3.3 | 1.0 | 8.0 | 0.3 | 0.3 |
| not cast | 1.7 | 4.7 | 1.0 | 12.0 | 1.7 | 19.7 |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 3.7 (79%) | 0.0 (0%) | 6.0 (50%) | 0.0 (0%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 3.3 (28%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (6%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | 1.7 (100%) | 0.0 (0%) | 1.0 (100%) | 1.7 (14%) | 0.0 (0%) | 3.7 (19%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 1.0 (21%) | 0.0 (0%) | 0.3 (3%) | 1.7 (100%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 16.0 (81%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.0 a game | 1.0 a game | 0.5 a game |
| stood (cast and not dispelled) | - | 67% (2 of 3) | 67% (2 of 3) |
| the unit moved after it | - | 50% (1 of 2) | 50% (1 of 2) |
| it charged on its next turn | - | 0% (0 of 2) | 0% (0 of 2) |
| the enemy charged it first | - | 0% (0 of 2) | 0% (0 of 2) |
| it fought by the end of its next turn | - | 0% (0 of 2) | 0% (0 of 2) |
| it moved out of a charge the enemy had planned (not charged first) | - | 0% (0 of 2) | 0% (0 of 2) |
| none of these (no charge, no fight, no charge escaped) | - | 100% (2 of 2) | 100% (2 of 2) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 64% (76 of 119) | 80% (36 of 45) | 68% (112 of 164) |
|   character | 100% (7 of 7) | 50% (4 of 8) | 73% (11 of 15) |
|   chariot | 75% (9 of 12) | 78% (7 of 9) | 76% (16 of 21) |
|   infantry | 50% (25 of 50) | 83% (15 of 18) | 59% (40 of 68) |
|   monster | 33% (4 of 12) | - | 33% (4 of 12) |
|   war machine | 82% (31 of 38) | 100% (10 of 10) | 85% (41 of 48) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 3.3 (23%) | 1.3 (44%) | 4.7 (27%) |
| CHARGED: it charged | 0.3 (2%) | 0.3 (11%) | 0.7 (4%) |
| IN COMBAT: it fought this turn or the last | 0.7 (5%) | 0.0 (0%) | 0.7 (4%) |
| MOVED: a war machine that moved | 1.0 (7%) | 0.0 (0%) | 1.0 (6%) |
| NO TARGET IN RANGE | 4.3 (30%) | 1.0 (33%) | 5.3 (31%) |
| ONLY IN COMBAT: the only targets were in combat | 1.0 (7%) | 0.0 (0%) | 1.0 (6%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 2.7 (19%) | 0.3 (11%) | 3.0 (17%) |
| SHELTERED: the target was sheltered | 0.7 (5%) | 0.0 (0%) | 0.7 (4%) |
| OTHER BAR | 0.3 (2%) | 0.0 (0%) | 0.3 (2%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| character | 4.3 | 1.3 | 69% | 5.0 pts | 22 pts |
| chariot | 5.3 | 2.0 | 69% | 18.7 pts | 100 pts |
| infantry | 17.0 | 6.0 | 69% | 9.0 pts | 152 pts |
| monster | 2.7 | 0.3 | 88% | 3.8 pts | 10 pts |
| war machine | 14.0 | 12.7 | 57% | 28.7 pts | 401 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 1.3 | 0.7 | 1.0 |
| Charges that made contact a game | 1.0 | 0.7 | 0.8 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.33 declared, 0.33 contact (3 units) | 0.00 declared, 0.00 contact (2 units) | 0.20 declared, 0.20 contact (5 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 0.00 declared, 0.00 contact (1 units) | 0.00 declared, 0.00 contact (1 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.16 declared, 0.11 contact (19 units) | 0.09 declared, 0.09 contact (23 units) | 0.12 declared, 0.10 contact (42 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 40% (2 of 5) | - | - | 40% (2 of 5) |
| Character in a unit | 100% (7 of 7) | 100% (2 of 2) | - | 100% (9 of 9) |
| Character on its own | - | 75% (3 of 4) | 25% (1 of 4) | 50% (4 of 8) |
| Chariot | 100% (3 of 3) | 50% (1 of 2) | - | 80% (4 of 5) |
| Infantry | 43% (6 of 14) | 75% (3 of 4) | - | 50% (9 of 18) |
| Monster | - | 100% (2 of 2) | - | 100% (2 of 2) |
| Monstrous | - | 100% (2 of 2) | - | 100% (2 of 2) |
| War Machines | 62% (5 of 8) | - | - | 62% (5 of 8) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Empire of Man | 2 | - | 50% (12 of 24) | 85% | 67% (16 of 24) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Grand Cathay | 1 | - | 46% (11 of 24) | 66% | 50% (5 of 10) | 100% (2 of 2); 9.0 uses a game | 0% (0 of 1); 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| High Elf Realms | 1 | - | 17% (1 of 6) | 88% | 38% (3 of 8) | 100% (1 of 1); 5.0 uses a game | 0% (0 of 2); 0.0 uses a game | 0.0 uses a game |
| Skaven | 1 | 100% (2 of 2); on the table 100% | 0% (0 of 6) | 72% | 89% (8 of 9) | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Warriors of Chaos | 1 | 100% (1 of 1); on the table 100% | - | 76% | 83% (5 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |

Flank and rear charges a unit could have turned to face (cnomg-c940641-p30, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 100% (2) | 67% (2) | 80% (4) |
| ...free all their last turn and able to turn (per game) | 0.33 | 0.67 | 1.00 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.33 | 0.00 | 0.33 |
| ...with the charger already in that arc before they moved (per game) | 0.33 | 0.67 | 1.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.33 | 0.00 | 0.33 |

### Quality by phase: cnomg-c940641-p30

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.3 | 2.7 |
| Strategy | Charge objectives carried out (made contact) | 25% (1 of 4) | 100% (2 of 2) |
| Strategy | Shoot objectives carried out (shot that target) | 19% (10 of 53) | 43% (9 of 21) |
| Strategy | Hexes on a unit its side charged or shot that turn | 100% (2 of 2) | - |
| Strategy | Joined characters whose unit fought | 0% (0 of 10) | 0% (0 of 4) |
| Strategy | Lone characters that fought | 25% (1 of 4) | 40% (2 of 5) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 1.0 | 2.7 |
| Movement | Points that never moved of their own | 291.7 | 143.3 |
| Movement | Fights charged into per game | 1.0 | 0.7 |
| Movement | Charges with odds: long shots (under 50%) | 1 of 3, net -515 | 0 of 2 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 3 | 0 of 2 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 3 | 0 of 2 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 of 3, net +72 | 1 of 2, net +0 |
| Shooting | Shots by shooting units (incl. breath weapons) | 15.0 | 10.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 64% (29 of 45) | 58% (18 of 31) |
| Shooting | Points destroyed by shooting units | 0.0 | 56.7 |
| Shooting | War machine shots | 10.3 | 3.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 39% (12 of 31) | 30% (3 of 10) |
| Shooting | Points destroyed by war machines | 277.3 | 0.0 |
| Magic | Magic missiles cast | 4.3 | 0.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 38% (5 of 13) | 0% (0 of 1) |
| Magic | Wounds caused by magic missiles | 13.0 | 8.0 |
| Magic | Points destroyed by magic (all spells) | 55.0 | 118.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.0 / 0.7 / 0.0 / 0.3 | 1.7 / 1.0 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 48.3 | 171.7 |
| Combat | Points run down | 0.0 | 45.0 |
| Combat | Net points per charged fight, damage counted | -118 | -48 |
| Combat | Net per 100 charger points, damage counted | -46.2 | -26.6 |
| Combat | First round won (charged fights) | 67% | 100% |
| Combat | Net points per charged fight | -123 | +68 |
| Combat | Net points per supported fight / lone fight | - / -123 | - / +68 |
| Combat | Charged fights on a top-3 enemy unit | 1 of 3 | 0 of 2 |
| Game | Points lost | 391.3 | 510.7 |
| Game | VP from objectives | 573.3 | 953.3 |
| Game | Lone holders (player turns) | 3.3 | 7.0 |

- Mine won / drew / lost: 1 / 0 / 2 of 3 ended games (of 3); mean margin (Mine - Opponent) -58 VP
- The side that went first won 2 of 3 games with a winner
- Points traded per game (both sides' losses): 902
- Games not ended: 0; findings 2, warnings 0

### Opponent rules: cnomg-c940641-p30

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | 17.0 | +557.7 | 0.0 | 34.7 | 18.7 | +75.4 | 0.0 | 125.0 |
| ARTILLERY RE-ROLL WEIGHED | 3.3 | +0.0 | 0.0 | 41.7 | - | - | - | - |
| BACKUP TARGETS | 0.3 | +0.4 | 0.0 | 0.0 | 0.3 | +0.2 | 0.0 | 0.0 |
| CANNON PLAN MISSED | 0.3 | +0.0 | 133.3 | 41.7 | 0.7 | +0.0 | 83.3 | 23.3 |
| CANNON PLANNED TARGET | 10.3 | +455.2 | 690.0 | 166.7 | 3.3 | +97.7 | 181.7 | 46.7 |
| CANNON SIGHT KEPT | 2.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| CAST JOB | 3.0 | +127.3 | 266.7 | 0.0 | 0.7 | +11.1 | 0.0 | 0.0 |
| CASTER AWAY FROM SCREEN | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | - | - | - | - | 0.7 | +0.0 | 0.0 | 133.3 |
| CHAFF IN THE MOVE | - | - | - | - | 1.0 | +13.0 | 0.0 | 0.0 |
| CHAFF PASSED | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | -6.3 | 0.0 | 0.0 |
| CHARACTER GUNS | 5.7 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| CHARGE LOSSES | 15.0 | -603.0 | 0.0 | 0.0 | 29.7 | -2025.7 | 0.0 | 990.0 |
| CHARGE NOW FIRST | 0.7 | +0.0 | 48.3 | 45.0 | 0.7 | +0.0 | 79.7 | 99.0 |
| CLOSES ON WHAT IT BEATS | 5.0 | +0.0 | 0.0 | 0.0 | 9.0 | +0.0 | 0.0 | 0.0 |
| COMBAT PIVOT | 0.3 | +0.0 | 0.0 | 88.3 | - | - | - | - |
| CONVEYANCE SEARCH | - | - | - | - | 1.0 | +197.2 | 266.7 | 266.7 |
| COVER ONCE | 9.3 | -1105.0 | 0.0 | 76.3 | 4.3 | -157.6 | 0.0 | 133.3 |
| DEFENSIVE ARMY | 4.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| DENIED BY THE FIGHT | - | - | - | - | 0.3 | -67.3 | 34.7 | 99.0 |
| DEPLOY BY FIGURES | 8.7 | -63.5 | 0.0 | 0.0 | 7.0 | +37.9 | 0.0 | 0.0 |
| EXACT ROUND | 1.3 | +23.3 | 147.3 | 133.3 | 0.3 | -1.1 | 45.0 | 0.0 |
| FALL BACK GOOD ORDER | 0.7 | +4.0 | 0.0 | 133.3 | 0.7 | +0.0 | 79.7 | 99.0 |
| FALLS SHORT | - | - | - | - | 27.0 | +329.4 | 0.0 | 545.7 |
| FEATURE BUFFS | 1.7 | +28.4 | 0.0 | 0.0 | 2.0 | +28.1 | 0.0 | 0.0 |
| FIGHT TO THE END | - | - | - | - | 0.3 | -0.4 | 45.0 | 0.0 |
| FIRE IN ORDER | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| FIVE ACTION | 100.0 | +7844.9 | 1660.7 | 619.3 | 96.0 | +5883.5 | 806.3 | 1643.7 |
| FLANK NOT WEIGHED | 5.3 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 99.0 |
| FOLLOW UP WEIGHED | - | - | - | - | 1.0 | +343.0 | 0.0 | 0.0 |
| FOUR ROUNDS | 1.3 | +87.7 | 147.3 | 133.3 | 0.7 | +29.7 | 79.7 | 99.0 |
| FREED FROM HIS FIGHT | 3.7 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 40.0 |
| FRIEND SHOOTS FIRST | 0.7 | -18.1 | 0.0 | 0.0 | - | - | - | - |
| GOAL WALK | 9.0 | +1421.9 | 0.0 | 0.0 | 15.0 | +1756.8 | 0.0 | 0.0 |
| GUN FIGURES | 1.7 | +37.0 | 133.3 | 0.0 | 1.3 | +0.0 | 41.7 | 45.0 |
| GUN MASK | 3.0 | +34.0 | 0.0 | 0.0 | 1.0 | -10.3 | 0.0 | 266.7 |
| HARD STAY DROPPED | 2.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 2.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 7.0 | +0.0 | 0.0 | 0.0 | 11.0 | +0.0 | 0.0 | 315.0 |
| HIS CHARGE DENIED | 0.3 | +22.2 | 0.0 | 88.3 | - | - | - | - |
| HIS CHARGE LIST | 9.0 | +0.0 | 0.0 | 34.7 | 6.0 | +0.0 | 0.0 | 48.3 |
| HIS LEGAL MOVES | 4.0 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 266.7 |
| HIS MOVE AND SHOT | 2.7 | -26.3 | 0.0 | 0.0 | 6.0 | -153.2 | 0.0 | 266.7 |
| HIS MOVE AS HE DECIDES | - | - | - | - | 38.3 | +12.3 | 301.3 | 0.0 |
| HIS ONE MOVE | - | - | - | - | 18.3 | +30.4 | 30.0 | 285.0 |
| HIS ONE QUARTER | 4.0 | +0.0 | 0.0 | 0.0 | 5.7 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 4.7 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 133.3 |
| HIS RANDOM MOVE | 14.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS RANDOM MOVER COMES | 4.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 38.3 | +1482.6 | 0.0 | 118.0 | 75.7 | +4847.1 | 0.0 | 1166.7 |
| HIS SHOTS BY HIS RUN | 31.0 | +677.7 | 0.0 | 34.7 | 74.7 | +2819.1 | 0.0 | 1191.7 |
| HIS TURN DENIED | - | - | - | - | 0.3 | +11.7 | 34.7 | 99.0 |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 16.3 | +0.0 | 0.0 | 0.0 | 32.3 | +0.0 | 0.0 | 0.0 |
| HOLDER ASSIGNMENT | 10.3 | +913.9 | 0.0 | 0.0 | 17.3 | +1800.9 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 1.3 | -15.2 | 147.3 | 133.3 | 0.3 | -10.0 | 34.7 | 99.0 |
| IDLE COST | - | - | - | - | 13.0 | -262.0 | 0.0 | 405.0 |
| KEPT FROM ITS LAST STOP | 1.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 0.7 | +11.3 | 0.0 | 0.0 | 0.7 | +40.1 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | - | - | - | - | 3.3 | +0.0 | 213.3 | 0.0 |
| LONE WIZARD KEPT IN | 1.3 | +60.0 | 0.0 | 0.0 | 0.3 | +58.3 | 0.0 | 0.0 |
| LONG SHOT | - | - | - | - | 0.7 | +0.0 | 0.0 | 43.3 |
| LOST AFTER ESCAPE | 0.7 | +1.1 | 0.0 | 133.3 | 0.3 | +1.0 | 45.0 | 0.0 |
| LOST CHARGE | 0.3 | -1.8 | 99.0 | 0.0 | - | - | - | - |
| MANOEUVRE | 2.0 | +100.6 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| MARCH BY THE SUM | 1.3 | +74.6 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | 0.3 | +14.5 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 2.0 | -209.8 | 0.0 | 0.0 | 0.3 | +29.6 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 4.3 | +48.7 | 0.0 | 0.0 | 0.7 | +11.8 | 0.0 | 266.7 |
| MEETS IN TIME | 4.3 | +509.9 | 0.0 | 0.0 | 3.3 | +324.0 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 14.0 | +401.2 | 0.0 | 0.0 | 2.7 | +72.7 | 0.0 | 133.3 |
| MISSILES NEXT TURN | 14.7 | +270.4 | 0.0 | 0.0 | 4.3 | +51.0 | 0.0 | 446.7 |
| MOVE ORDER | 2.0 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| MOVE SPELL SPOT | - | - | - | - | 0.7 | +0.0 | 0.0 | 133.3 |
| MOVE TO CHARGE COMPUTED | 4.3 | +166.8 | 0.0 | 0.0 | 2.7 | +284.0 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 13.0 | +614.0 | 0.0 | 0.0 | 7.7 | +359.2 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 3.0 | +112.5 | 0.0 | 0.0 | 2.0 | +240.0 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 1.3 | -55.2 | 147.3 | 133.3 | 0.3 | -25.6 | 34.7 | 99.0 |
| NO LATE CUT | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 5.3 | -110.6 | 0.0 | 41.7 | 2.0 | -52.5 | 0.0 | 0.0 |
| OGRE LOADER SECOND SHOT | 3.7 | +43.2 | 0.0 | 0.0 | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ONE FIGHT FORMULA | 5.7 | -117.0 | 0.0 | 0.0 | 5.0 | -123.8 | 0.0 | 365.7 |
| ONE OBJECTIVE FORMULA | 5.0 | -116.0 | 0.0 | 0.0 | 9.0 | +235.3 | 0.0 | 0.0 |
| ONE PROMISE A TARGET | 0.3 | -4.3 | 0.0 | 0.0 | - | - | - | - |
| ONE ROUTE | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| OVERRUNS AWAY | 0.3 | +12.3 | 0.0 | 45.0 | 0.7 | +2.9 | 79.7 | 99.0 |
| OWN CAST FIRST | 1.0 | -8.7 | 0.0 | 0.0 | - | - | - | - |
| PERIAPT WORTH | - | - | - | - | 0.3 | +18.0 | 0.0 | 0.0 |
| PLAN RESULT | 44.3 | +1399.1 | 825.0 | 752.7 | 44.7 | +280.0 | 216.3 | 1063.0 |
| PROMISE BELOW ZERO | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE BY ITS OWN SUM | 6.7 | -130.1 | 0.0 | 0.0 | 3.0 | -43.9 | 0.0 | 0.0 |
| PROMISE IN STEPS | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE KNOWS THE FIGHT | 1.0 | -0.9 | 0.0 | 0.0 | - | - | - | - |
| PROMISE SHOT AWAY | 0.3 | -0.0 | 0.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | 18.0 | +1742.7 | 43.3 | 83.3 | 15.7 | +1740.1 | 310.0 | 80.0 |
| RANDOM MOVE BY FIGURES | - | - | - | - | 4.7 | +105.9 | 0.0 | 96.7 |
| REAL GROUND | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | - | - | - | - | 0.3 | -15.2 | 0.0 | 0.0 |
| REFORMS TO MEET IT | 0.7 | -13.9 | 0.0 | 0.0 | 0.7 | -13.1 | 0.0 | 0.0 |
| RISK BY ARC | 0.7 | -18.8 | 48.3 | 45.0 | 0.7 | -10.1 | 79.7 | 99.0 |
| ROUNDS AFTER TERROR | 0.3 | -2.1 | 99.0 | 0.0 | - | - | - | - |
| RUN DOWN | 0.7 | -10.7 | 48.3 | 45.0 | 0.7 | -10.8 | 79.7 | 99.0 |
| SCOUT SPOT | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SCOUT WAITS | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 2.0 | -114.0 | 0.0 | 0.0 |
| SEARCH SPOT | 0.3 | +0.5 | 0.0 | 0.0 | 0.7 | +28.5 | 0.0 | 0.0 |
| SET CREDITED ONCE | 0.7 | -55.2 | 0.0 | 0.0 | - | - | - | - |
| SET UP BY THE SET | 0.7 | +55.2 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | 0.7 | +1.3 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS ON THE TABLE | 17.0 | +0.0 | 0.0 | 166.7 | 7.3 | +0.0 | 0.0 | 167.3 |
| SHOOTS FROM THE BEST SPOT | 4.0 | +326.6 | 0.0 | 0.0 | 2.7 | +114.7 | 166.7 | 0.0 |
| SHOT OR CHARGE | 0.7 | -43.5 | 0.0 | 88.3 | - | - | - | - |
| SHOT RISK POINTS | 15.3 | +138.6 | 0.0 | 0.0 | 46.0 | -731.5 | 0.0 | 943.3 |
| SHOTS AFTER THE MOVES | 5.7 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 27.7 | +1618.4 | 0.0 | 243.0 | 11.3 | +430.0 | 0.0 | 322.3 |
| SPELL WORTH | - | - | - | - | 2.3 | +77.7 | 446.7 | 446.7 |
| SPELLS IN THE FIGHT | 0.3 | +1.3 | 48.3 | 0.0 | - | - | - | - |
| SPOT AS THE GAME MOVES | 4.3 | +0.0 | 0.0 | 0.0 | 7.3 | +0.0 | 0.0 | 221.7 |
| STAND AND SHOOT | 0.3 | -0.2 | 99.0 | 0.0 | - | - | - | - |
| STANDS FOR A REASON | - | - | - | - | 3.7 | +0.0 | 0.0 | 378.0 |
| STANDS STILL | 46.0 | +0.0 | 1513.3 | 451.3 | 36.0 | +0.0 | 726.7 | 419.7 |
| STAY WORTH | 42.0 | +201.8 | 1380.0 | 500.0 | 18.0 | +343.9 | 446.7 | 360.0 |
| STUCK PIVOT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 3.0 | +96.0 | 0.0 | 0.0 | 4.0 | +193.6 | 0.0 | 0.0 |
| SUPPORT NARROWED | 0.3 | +0.0 | 0.0 | 45.0 | - | - | - | - |
| SUPPORT WORKED OUT | 3.0 | +96.0 | 0.0 | 0.0 | 4.0 | +193.6 | 0.0 | 0.0 |
| SWIFTSTRIDE BY POINTS | 0.3 | +0.3 | 0.0 | 0.0 | - | - | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 2.3 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 21.7 |
| THE ROW IN ITS ORDER | 2.7 | +0.0 | 0.0 | 0.0 | 6.3 | +0.0 | 0.0 | 40.0 |
| THE ROW KEEPS ITS WAY | 4.0 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 21.7 |
| THE STEP BACK IS MADE | 2.7 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 21.7 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 47.0 | +0.0 | 0.0 | 166.7 | 46.3 | +0.0 | 0.0 | 724.0 |
| TIED UP BY THE SUM | 0.7 | +58.5 | 48.3 | 45.0 | 0.3 | +39.4 | 34.7 | 99.0 |
| TIME ON OUR SIDE | 39.7 | +579.5 | 0.0 | 34.7 | - | - | - | - |
| WAITS AGAIN | 1.3 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| WAR ENGINE JOBS | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WHAT THE JOINER ADDS | - | - | - | - | 0.7 | +0.6 | 90.0 | 0.0 |
| WHO HITS BACK | - | - | - | - | 0.3 | +52.9 | 0.0 | 0.0 |
| WHOLE FIGHT | - | - | - | - | 0.3 | +1.7 | 45.0 | 0.0 |
| WHOLE FIGHT DANGER | 5.3 | -423.4 | 0.0 | 0.0 | 3.0 | -305.3 | 0.0 | 266.7 |
| WOUNDS ON THE RANKS | 0.7 | +10.4 | 0.0 | 0.0 | 2.3 | +132.8 | 0.0 | 0.0 |

### Rule changes: cnomg-c940641-p30

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS SHOT LIST | 342 | 340 | 89 | 29.67 | +2496 | +28.1 |
| HIS SHOTS BY HIS RUN | 317 | 315 | 79 | 26.33 | +1498 | +19.0 |
| HIS MOVE AS HE DECIDES | 115 | 115 | 78 | 26.00 | +0 | +0.0 |
| HOLDER ASSIGNMENT | 83 | 83 | 78 | 26.00 | +5013 | +64.3 |
| ARMY TABLE | 107 | 107 | 63 | 21.00 | +1458 | +23.1 |
| SHOT RISK POINTS | 184 | 182 | 46 | 15.33 | +2397 | +52.1 |
| DEPLOY BY FIGURES | 47 | 47 | 33 | 11.00 | +783 | +23.7 |
| THE TABLE AGAIN | 36 | 36 | 26 | 8.67 | +0 | +0.0 |
| OFF BEST | 22 | 22 | 22 | 7.33 | -489 | -22.2 |
| HIS ONE MOVE | 55 | 55 | 21 | 7.00 | +0 | +0.0 |
| CHARGE LOSSES | 134 | 132 | 17 | 5.67 | +1666 | +98.0 |
| GOAL WALK | 72 | 70 | 17 | 5.67 | +3079 | +181.1 |
| FIVE ACTION | 588 | 583 | 16 | 5.33 | +698 | +43.6 |
| QUARTER ODDS | 101 | 100 | 15 | 5.00 | +1279 | +85.3 |
| SHOOTS FROM THE BEST SPOT | 20 | 20 | 14 | 4.67 | +220 | +15.7 |
| HARD STAY DROPPED | 12 | 12 | 12 | 4.00 | +0 | +0.0 |
| MOVE ORDER | 12 | 12 | 12 | 4.00 | +0 | +0.0 |
| CAST JOB | 11 | 11 | 11 | 3.67 | +139 | +12.7 |
| MEETS IN TIME | 23 | 23 | 11 | 3.67 | +1042 | +94.7 |
| OGRE LOADER SECOND SHOT | 11 | 11 | 11 | 3.67 | +129 | +11.8 |
| PROMISE BY ITS OWN SUM | 29 | 29 | 11 | 3.67 | -522 | -47.5 |
| ARTILLERY RE-ROLL WEIGHED | 10 | 10 | 10 | 3.33 | +0 | +0.0 |
| LEGAL CHARGES ONLY | 10 | 10 | 10 | 3.33 | +0 | +0.0 |
| MOVE TO CHARGE COMPUTED | 21 | 21 | 10 | 3.33 | +276 | +27.6 |
| TIME ON OUR SIDE | 119 | 108 | 10 | 3.33 | +12 | +1.2 |
| CANNON SIGHT KEPT | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| RANDOM MOVE BY FIGURES | 14 | 14 | 8 | 2.67 | +317 | +39.7 |
| SHOTS AFTER THE MOVES | 24 | 24 | 7 | 2.33 | +0 | +0.0 |
| SUPPORT ADDS | 21 | 21 | 7 | 2.33 | +89 | +12.7 |
| SUPPORT WORKED OUT | 21 | 21 | 7 | 2.33 | +89 | +12.7 |
| COVER ONCE | 41 | 31 | 6 | 2.00 | +184 | +30.7 |
| STAY WORTH | 180 | 167 | 6 | 2.00 | +40 | +6.7 |
| CANNON PLANNED TARGET | 41 | 41 | 5 | 1.67 | +176 | +35.2 |
| FOUR ROUNDS | 6 | 6 | 5 | 1.67 | +44 | +8.9 |
| LONE WIZARD KEPT IN | 5 | 5 | 5 | 1.67 | +355 | +71.0 |
| NEXT CHARGE BY LIST | 15 | 15 | 5 | 1.67 | +174 | +34.9 |
| ONE OBJECTIVE FORMULA | 42 | 32 | 5 | 1.67 | +232 | +46.5 |
| CASTER AWAY FROM SCREEN | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| CHARGE NOW FIRST | 4 | 4 | 4 | 1.33 | -100 | -25.1 |
| FALLS SHORT | 81 | 64 | 4 | 1.33 | +33 | +8.1 |
| IDLE COST | 39 | 30 | 4 | 1.33 | +77 | +19.3 |
| LANE BY FIGURES | 4 | 4 | 4 | 1.33 | +154 | +38.5 |
| MARCH BY THE SUM | 4 | 4 | 4 | 1.33 | +224 | +55.9 |
| CHAFF IN THE MOVE | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| CHAFF PASSED | 3 | 3 | 3 | 1.00 | -19 | -6.3 |
| FOLLOW UP WEIGHED | 3 | 3 | 3 | 1.00 | +1029 | +343.0 |
| HOLDS AMBUSHERS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| NEARER NOT NEEDED | 62 | 56 | 3 | 1.00 | +112 | +37.2 |
| OWN CAST FIRST | 3 | 3 | 3 | 1.00 | -26 | -8.7 |
| SEARCH SPOT | 3 | 3 | 3 | 1.00 | +87 | +28.9 |
| SHOTS IN THE MOVE | 117 | 98 | 3 | 1.00 | +673 | +224.2 |
| TIED UP BY THE SUM | 3 | 3 | 3 | 1.00 | +43 | +14.4 |
| WOUNDS ON THE RANKS | 9 | 9 | 3 | 1.00 | +75 | +25.0 |
| EXACT ROUND | 5 | 5 | 2 | 0.67 | +6 | +2.8 |
| FEATURE BUFFS | 11 | 11 | 2 | 0.67 | +21 | +10.5 |
| HIS MOVE AND SHOT | 26 | 25 | 2 | 0.67 | +0 | +0.0 |
| OVERRUNS AWAY | 3 | 3 | 2 | 0.67 | +8 | +3.9 |
| SCOUT WAITS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| SHOOTERS IN TWO RANKS | 2 | 2 | 2 | 0.67 | +4 | +2.0 |
| THE ROW IN ITS ORDER | 27 | 2 | 2 | 0.67 | +0 | +0.0 |
| WAR ENGINE JOBS | 2 | 2 | 2 | 0.67 | -4 | -2.1 |
| WHAT THE JOINER ADDS | 2 | 2 | 2 | 0.67 | +1 | +0.4 |
| ADVANCE LANE KEPT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| COMBAT PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FALL BACK GOOD ORDER | 4 | 4 | 1 | 0.33 | +8 | +7.5 |
| FIRE IN ORDER | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| GUN MASK | 12 | 12 | 1 | 0.33 | +8 | +8.3 |
| HIS CHARGE DENIED | 1 | 1 | 1 | 0.33 | +1 | +0.6 |
| HIS TURN DENIED | 1 | 1 | 1 | 0.33 | +31 | +30.7 |
| LOST AFTER ESCAPE | 3 | 3 | 1 | 0.33 | +0 | +0.4 |
| MANOEUVRE | 12 | 12 | 1 | 0.33 | +318 | +318.1 |
| ONE PROMISE A TARGET | 1 | 1 | 1 | 0.33 | -13 | -12.9 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.33 | +54 | +54.0 |
| PROMISE KNOWS THE FIGHT | 3 | 3 | 1 | 0.33 | -3 | -2.6 |
| PROMISE SHOT AWAY | 1 | 1 | 1 | 0.33 | -0 | -0.1 |
| REFORMS TO MEET IT | 4 | 4 | 1 | 0.33 | +7 | +7.4 |
| STUCK PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| SWIFTSTRIDE BY POINTS | 1 | 1 | 1 | 0.33 | +1 | +0.8 |
| WHO HITS BACK | 1 | 1 | 1 | 0.33 | +124 | +124.3 |
| WHOLE FIGHT | 1 | 1 | 1 | 0.33 | +0 | +0.4 |
| WHOLE FIGHT DANGER | 25 | 24 | 1 | 0.33 | +0 | +0.1 |
| BACKUP TARGETS | 2 | not checked | - | - | - | - |
| CANNON PLAN MISSED | 3 | 3 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 2 | trace | - | - | - | - |
| CHARACTER GUNS | 25 | 25 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 42 | 42 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 3 | not checked | - | - | - | - |
| DEFENSIVE ARMY | 12 | 12 | 0 | 0.00 | - | - |
| DENIED BY THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 1 | 1 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 29 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 16 | 15 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 2 | 2 | 0 | 0.00 | - | - |
| GUN FIGURES | 9 | not checked | - | - | - | - |
| HE REFORMS ONCE FREED | 8 | 8 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 54 | 53 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 45 | 45 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 21 | 21 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 29 | 29 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 21 | 21 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 42 | 41 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 13 | 12 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN RUN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 146 | 146 | 0 | 0.00 | - | - |
| HONEST WORTH | 5 | 5 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 9 | 9 | 0 | 0.00 | - | - |
| LONG SHOT | 2 | 2 | 0 | 0.00 | - | - |
| LOST CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| MARCH CHECK | 1 | 1 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 7 | 7 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 4 | 4 | 0 | 0.00 | - | - |
| MAX FOR POSITIONING | 15 | 15 | 0 | 0.00 | - | - |
| MISSILES IN THE MOVE | 50 | 33 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 57 | 44 | 0 | 0.00 | - | - |
| MOVE SPELL SPOT | 2 | not checked | - | - | - | - |
| NO DOUBLE ROUNDS | 5 | 5 | 0 | 0.00 | - | - |
| NO LATE CUT | 3 | 3 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 18 | 18 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT TURNED | 1 | 1 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 4 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 32 | 23 | 0 | 0.00 | - | - |
| ONE ROUTE | 4 | 4 | 0 | 0.00 | - | - |
| PLAN RESULT | 267 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE IN STEPS | 1 | 1 | 0 | 0.00 | - | - |
| REAL GROUND | 4 | 4 | 0 | 0.00 | - | - |
| REDIRECT COUNTER | 1 | not checked | - | - | - | - |
| RISK BY ARC | 4 | 4 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 1 | 1 | 0 | 0.00 | - | - |
| RUN DOWN | 4 | 4 | 0 | 0.00 | - | - |
| SCOUT SPOT | 2 | 2 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 6 | 6 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 2 | 2 | 0 | 0.00 | - | - |
| SET UP BY THE SET | 2 | 2 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 73 | not checked | - | - | - | - |
| SHOT OR CHARGE | 2 | 2 | 0 | 0.00 | - | - |
| SPELL WORTH | 7 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 35 | 31 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 1 | 1 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 11 | 11 | 0 | 0.00 | - | - |
| STANDS STILL | 246 | 245 | 0 | 0.00 | - | - |
| SUPPORT NARROWED | 1 | 1 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 15 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 23 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 14 | not checked | - | - | - | - |
| THE TABLE BINDS | 280 | not checked | - | - | - | - |
| WAITS AGAIN | 11 | 11 | 0 | 0.00 | - | - |

### Off best figure: cnomg-c940641-p30

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 5.33 | 2.00 | 22.2 |
| ARMY TABLE | rule | 1.67 | 2.67 | 80.2 |
| PROMISE BY ITS OWN SUM | rule | 3.00 | 0.67 | 47.5 |
| CHARGE NOW FIRST | rule | 0.67 | 0.67 | 25.1 |
| HOLDER ASSIGNMENT | rule | - | 1.00 | 20.7 |
| OWN CAST FIRST | rule | 1.00 | - | 8.7 |
| CHAFF PASSED | rule | - | 0.67 | 9.4 |
| WAR ENGINE JOBS | rule | 0.67 | - | 2.1 |
| ONE PROMISE A TARGET | rule | 0.33 | - | 12.9 |
| PROMISE KNOWS THE FIGHT | rule | 0.33 | - | 2.6 |

### Plans: cnomg-c940641-p30

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.3 | 50% | 112 | 147 | 132% |
| Mine | join | 0.3 | 100% | 4 | 0 | 0% |
| Mine | move | 28.0 | 99% | 2188 | 0 | 0% |
| Mine | shoot | 14.7 | 59% | 906 | 1252 | 138% |
| Opponent | charge | 0.7 | 50% | 20 | 56 | 278% |
| Opponent | move | 36.7 | 95% | 2374 | 0 | 0% |
| Opponent | shoot | 6.3 | 53% | 437 | 224 | 51% |
| Opponent | support | 1.0 | 100% | 0 | 0 | - |

### Battle groups: cnomg-c940641-p30

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | REDIRECT COUNTER | 0.3 | 0% | - | - | - | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: cnomg-c940641-p30

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Character | 10 | 16 (10) | 16 | 0 | 3 | 40% | 2.7 | 27 (5) | 0 (5) | - | 17 (7) | 13 (3) |
| Mine | Clean-up | 3 | 66 (3) | 0 | 66 | 0 | 67% | 5.0 | 0 (1) | 100 (2) | - | 66 (3) | - |
| Mine | Fast Hammer | 3 | 10 (3) | 10 | 0 | 29 | 0% | 2.7 | 14 (2) | - | 0 (1) | 10 (3) | - |
| Mine | Hammer | 6 | 21 (6) | 21 | 0 | 19 | 33% | 1.5 | 0 (2) | 31 (4) | - | 25 (5) | 0 (1) |
| Mine | Shooter | 6 | 106 (6) | 0 | 106 | 17 | 0% | 1.5 | 0 (1) | 163 (3) | 72 (2) | 106 (6) | - |
| Mine | War machine | 8 | 50 (8) | 50 | 0 | 58 | 0% | 1.4 | 125 (3) | 0 (3) | 20 (2) | 0 (1) | 56 (7) |
| Mine | Wizard | 4 | 0 (4) | 0 | 0 | 0 | 25% | 2.7 | 0 (1) | 0 (3) | - | 0 (3) | 0 (1) |
| Opponent | Chaff | 2 | 288 (2) | 0 | 288 | 44 | 100% | - | 514 (1) | 0 (1) | - | 514 (1) | 0 (1) |
| Opponent | Character | 9 | 39 (9) | 39 | 0 | 46 | 56% | 1.5 | 123 (1) | 27 (7) | 0 (1) | 0 (5) | 90 (4) |
| Opponent | Clean-up | 3 | 110 (3) | 0 | 110 | 0 | 100% | - | 0 (1) | 199 (2) | - | 199 (2) | 0 (1) |
| Opponent | Fast Hammer | 6 | 67 (6) | 0 | 67 | 0 | 83% | 1.0 | - | 70 (4) | 63 (2) | 67 (6) | - |
| Opponent | Fragile | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | - | 0 (1) | - | 0 (1) |
| Opponent | Hammer | 4 | 0 (4) | 0 | 0 | 22 | 25% | 2.3 | - | 0 (2) | 0 (2) | 0 (4) | - |
| Opponent | Holder | 4 | 34 (4) | 34 | 0 | 0 | 50% | 3.5 | - | 34 (4) | - | 147 (1) | 0 (3) |
| Opponent | Shooter | 4 | 102 (4) | 102 | 0 | 28 | 25% | 1.7 | 0 (1) | 0 (1) | 141 (2) | 119 (3) | 0 (1) |
| Opponent | War machine | 2 | 32 (2) | 32 | 0 | 50 | 0% | 1.0 | - | - | 32 (2) | 64 (1) | 0 (1) |

### Charged fights: cnomg-c940641-p30

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Empire of Man | 2 | 384 | 0 | 0.5 | 1.0 | 0 | 515 | -515 | 1 of 1 | 0 of 1 | - | -515 |
| Mine | Grand Cathay | 1 | 230 | 145 | 2.0 | 1.0 | 72 | 0 | +72 | 0 of 2 | 2 of 2 | - | +72 |
| **Mine** | all armies | 3 | 332 | 48 | 1.0 | 1.0 | 48 | 172 | -123 | 1 of 3 | 2 of 3 | - | -123 |
| Opponent | High Elf Realms | 1 | 524 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 0 of 1 | 1 of 1 | - | +0 |
| Opponent | Skaven | 1 | 0 | 135 | 1.0 | 1.0 | 135 | 0 | +135 | 0 of 1 | 1 of 1 | - | +135 |
| Opponent | Warriors of Chaos | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| **Opponent** | all armies | 3 | 175 | 45 | 0.7 | 1.0 | 68 | 0 | +68 | 0 of 2 | 2 of 2 | - | +68 |

### Effective charges: cnomg-c940641-p30

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Empire of Man | 1 | 1 (net -515) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 1) |
| Mine | Grand Cathay | 2 | 0 | 0 | 0 | 0 | 0 | 2 (net +72) | 0 | 0% (0 of 2) |
| Opponent | High Elf Realms | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +0) | 0 | 0% (0 of 1) |
| Opponent | Skaven | 1 | 0 | 0 | 0 | 1 (net +135) | 0 | 0 | 0 | 0% (0 of 1) |

### Charged fights, damage counted: cnomg-c940641-p30

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 1 | 265 | 479 | -515 | 106 | 606 | -500 | -188.7 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 252 | 118 | +72 | 72 | 0 | +72 | +28.8 |
| Mine | All fights | 3 | 256 | 239 | -123 | 84 | 202 | -118 | -46.2 |
| Opponent | 76-89% | 1 | 112 | 135 | +135 | 218 | 124 | +94 | +84.0 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 247 | 104 | +0 | 107 | 296 | -190 | -76.8 |
| Opponent | All fights | 2 | 180 | 120 | +68 | 163 | 210 | -48 | -26.6 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| cnomg-c940641-p30 | move | 17 | 3 (18%) | 3 (18%) | 0 (0%) | 14 (82%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Periapt of Soul Exchange | Opponent | L1021 |
| Ring of Jet | Mine | L1021 |
| Standard of the Fell Warrior | Opponent | L0913 |
| Storm Daemon (Renegade 2.0) | Opponent | L1021 |
| Twice-Blessed Armour | Mine | L1021 |

# Doctrine scorecard: cnomg-c940641-p20

### Scorecard: cnomg-c940641-p20

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L1323 | 3 | 1 | Mine | no | 0 | 2 | 2 | 0 | 0 | 0 | 0 | 140 |
| L1323 | 3 | 1 | Opponent | yes | 0 | 2 | 6 | 2 | 0 | 0 | 0 | 66 |
| L1418 | 2 | 1 | Mine | - | - | 2 | 4 | 3 | 0 | 0 | 0 | 0 |
| L1418 | 2 | 1 | Opponent | - | - | - | 4 | 2 | 0 | 0 | 0 | 305 |
| L1435 | 1 | 1 | Mine | no | 4 | 3 | 2 | 3 | 0 | 0 | 0 | 123 |
| L1435 | 1 | 1 | Opponent | no | 0 | 6 | 2 | 4 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 0% | 2.0 | 2.3 | 2.7 | 2.0 | 0.0 | 0.0 | 0.0 | 87.7 |
| **Average** | | | Opponent | 50% | 0.0 | 4.0 | 4.0 | 2.7 | 0.0 | 0.0 | 0.0 | 123.7 |

### KPIs: cnomg-c940641-p20

Rules off - Mine only: NO OLD ONE-MOVE GUESS.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 16) | 0% (0 of 17) | 0% (0 of 33) |
| Winner chose to follow up after the loser gave ground |  | 50% (1 of 2); on the table 50% | 100% (1 of 1); on the table 100% | 67% (2 of 3); on the table 67% |
| Winner chose to pursue after the loser fell back in good order |  | 100% (1 of 1); on the table 100% | - | 100% (1 of 1); on the table 100% |
| Winner chose to pursue after the loser fled |  | 100% (1 of 1); on the table 100% | 100% (1 of 1); on the table 100% | 100% (2 of 2); on the table 100% |
| Winner chose to follow up or pursue (all three) |  | 75% (3 of 4); on the table 75% | 100% (2 of 2); on the table 100% | 83% (5 of 6); on the table 83% |
| Magic missiles tried each own turn | 50%+ | 33% (6 of 18) | - | 33% (6 of 18) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 46% (6 of 13) | - | 46% (6 of 13) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | - | - |
| Points that never fought | lower | 54% (3232 of 6000) | 55% (3321 of 6000) | 55% (6553 of 12000) |
|   infantry points that never fought | lower | 75% (693 of 923) | 90% (1042 of 1159) | 83% (1735 of 2082) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 58% (15 of 26) | 79% (19 of 24) | 68% (34 of 50) |
| Bound items with a magic missile used (at least once a game) |  | 100% (1 of 1); 1.7 uses a game | 100% (2 of 2); 1.3 uses a game | 100% (3 of 3); 1.5 uses a game |
| Bound items with another spell used |  | 14% (2 of 14); 1.0 uses a game | 0.0 uses a game | 14% (2 of 14); 0.5 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
|   their share of the points of units over 100 pts | lower | 51% (3012 of 5860) | 74% (3811 of 5131) | 62% (6823 of 10991) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.0 (25%) | - | 1.0 (25%) |
| MARCHED: its unit marched | 1.0 (25%) | - | 1.0 (25%) |
| CHARGED: its unit charged | 0.3 (8%) | - | 0.3 (8%) |
| IN COMBAT: engaged in combat | 0.3 (8%) | - | 0.3 (8%) |
| GONE: slain | 1.3 (33%) | - | 1.3 (33%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 4.0 | 5.0 | 3.3 | 2.0 | 2.7 |
| not cast | 4.0 | 5.0 | 4.7 | 4.0 | 25.3 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (1%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 3.0 (60%) | 0.3 (7%) | 1.0 (25%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.0 (25%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (8%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.0 (0%) | 0.3 (7%) | 0.3 (8%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 2.0 (50%) | 2.0 (40%) | 2.0 (43%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | 1.3 (33%) | 0.0 (0%) | 1.3 (29%) | 1.3 (33%) | 2.7 (11%) |
| HELD BACK: the computer weighed it and chose not to cast it | 0.7 (17%) | 0.0 (0%) | 0.7 (14%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 22.3 (88%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 3.3 a game | 0.0 a game | 1.7 a game |
| stood (cast and not dispelled) | 70% (7 of 10) | - | 70% (7 of 10) |
| the unit moved after it | 29% (2 of 7) | - | 29% (2 of 7) |
| it charged on its next turn | 14% (1 of 7) | - | 14% (1 of 7) |
| the enemy charged it first | 43% (3 of 7) | - | 43% (3 of 7) |
| it fought by the end of its next turn | 29% (2 of 7) | - | 29% (2 of 7) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 7) | - | 0% (0 of 7) |
| none of these (no charge, no fight, no charge escaped) | 43% (3 of 7) | - | 43% (3 of 7) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 56% (45 of 80) | 60% (58 of 97) | 58% (103 of 177) |
|   cavalry | 46% (11 of 24) | 70% (14 of 20) | 57% (25 of 44) |
|   character | 10% (2 of 20) | 46% (6 of 13) | 24% (8 of 33) |
|   chariot | - | 78% (7 of 9) | 78% (7 of 9) |
|   infantry | 83% (20 of 24) | 58% (25 of 43) | 67% (45 of 67) |
|   monster | - | 50% (6 of 12) | 50% (6 of 12) |
|   war machine | 100% (12 of 12) | - | 100% (12 of 12) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.0 (17%) | 2.3 (18%) | 4.3 (18%) |
| CHARGED: it charged | 2.3 (20%) | 1.7 (13%) | 4.0 (16%) |
| IN COMBAT: it fought this turn or the last | 0.0 (0%) | 0.3 (3%) | 0.3 (1%) |
| NO TARGET IN RANGE | 6.7 (57%) | 4.7 (36%) | 11.3 (46%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.7 (6%) | 3.3 (26%) | 4.0 (16%) |
| OTHER BAR | 0.0 (0%) | 0.7 (5%) | 0.7 (3%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 14.0 | 2.3 | 83% | 3.9 pts | 55 pts |
| character | 4.0 | 1.3 | 75% | 12.2 pts | 49 pts |
| chariot | 2.3 | 1.3 | 71% | 35.7 pts | 83 pts |
| infantry | 21.0 | 3.3 | 84% | 7.1 pts | 150 pts |
| monster | 2.0 | 0.0 | 100% | 0.0 pts | 0 pts |
| war machine | 4.0 | 1.7 | 67% | 12.8 pts | 51 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.7 | 4.0 | 3.8 |
| Charges that made contact a game | 2.3 | 2.3 | 2.3 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.67 declared, 0.33 contact (3 units) | - | 0.67 declared, 0.33 contact (3 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | - | - |
|   per unit a game, the other units (no war machines, no joined characters) | 0.39 declared, 0.26 contact (23 units) | 0.36 declared, 0.21 contact (33 units) | 0.38 declared, 0.23 contact (56 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 59% (10 of 17) | - | - | 59% (10 of 17) |
| Character in a unit | - | 100% (2 of 2) | - | 100% (2 of 2) |
| Character on its own | - | 33% (1 of 3) | 38% (3 of 8) | 36% (4 of 11) |
| Chariot | 100% (2 of 2) | - | - | 100% (2 of 2) |
| Infantry | 90% (9 of 10) | 100% (1 of 1) | - | 91% (10 of 11) |
| Monster | 50% (1 of 2) | 100% (1 of 1) | - | 67% (2 of 3) |
| Monstrous | 100% (2 of 2) | 100% (2 of 2) | - | 100% (4 of 4) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| High Elf Realms | 3 | 75% (3 of 4); on the table 75% | 33% (6 of 18) | 54% | 58% (15 of 26) | 100% (1 of 1); 1.7 uses a game | 14% (2 of 14); 1.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 1 | - | - | 72% | 100% (7 of 7) | 100% (1 of 1); 1.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Tomb Kings of Khemri | 1 | 100% (2 of 2); on the table 100% | - | 52% | 40% (2 of 5) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 1 | - | - | 43% | 83% (10 of 12) | 100% (1 of 1); 3.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (cnomg-c940641-p20, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 75% (3) | 67% (2) | 71% (5) |
| ...free all their last turn and able to turn (per game) | 1.00 | 0.67 | 1.67 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 1.00 | 0.67 | 1.67 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: cnomg-c940641-p20

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.0 | 1.7 |
| Strategy | Charge objectives carried out (made contact) | 60% (6 of 10) | 71% (5 of 7) |
| Strategy | Shoot objectives carried out (shot that target) | 32% (10 of 31) | 50% (8 of 16) |
| Strategy | Hexes on a unit its side charged or shot that turn | 0% (0 of 3) | 62% (5 of 8) |
| Strategy | Joined characters whose unit fought | - | 33% (1 of 3) |
| Strategy | Lone characters that fought | 71% (5 of 7) | 50% (2 of 4) |
| Movement | Charges halted short of contact | 0.7 | 0.0 |
| Movement | Idle units | 2.0 | 2.7 |
| Movement | Points that never moved of their own | 87.7 | 123.7 |
| Movement | Fights charged into per game | 2.3 | 2.3 |
| Movement | Charges with odds: long shots (under 50%) | 1 of 7, net +0 | 1 of 6, net -216 |
| Movement | Charges with odds: sweet spot (55-75%) | 1 of 7, net +0 | 2 of 6, net +191 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 4 of 7, net +62 | 0 of 6 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 of 7, net +185 | 3 of 6, net +50 |
| Shooting | Shots by shooting units (incl. breath weapons) | 14.7 | 23.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 30% (13 of 44) | 67% (46 of 69) |
| Shooting | Points destroyed by shooting units | 65.0 | 0.0 |
| Shooting | War machine shots | 4.0 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 75% (9 of 12) | - |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | 1.7 | - |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 0% (0 of 5) | - |
| Magic | Wounds caused by magic missiles | 0.7 | 1.0 |
| Magic | Wounds caused by other spells | 1.7 | - |
| Magic | Points destroyed by magic (all spells) | 0.0 | 133.3 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.3 / 1.0 / 1.7 / 0.0 | 2.7 / 2.7 / 0.3 / 0.0 |
| Combat | Points destroyed in combat | 254.0 | 0.0 |
| Combat | Points run down | 0.0 | 242.7 |
| Combat | Net points per charged fight, damage counted | +86 | +96 |
| Combat | Net per 100 charger points, damage counted | +30.1 | +35.4 |
| Combat | First round won (charged fights) | 100% | 71% |
| Combat | Net points per charged fight | +62 | +40 |
| Combat | Net points per supported fight / lone fight | - / +62 | - / +40 |
| Combat | Charged fights on a top-3 enemy unit | 1 of 7 | 4 of 7 |
| Game | Points lost | 342.7 | 358.0 |
| Game | VP from objectives | 513.3 | 783.3 |
| Game | Lone holders (player turns) | 2.0 | 0.0 |

- Mine won / drew / lost: 0 / 2 / 1 of 3 ended games (of 3); mean margin (Mine - Opponent) -416 VP
- The side that went first won 0 of 1 games with a winner
- Points traded per game (both sides' losses): 701
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: cnomg-c940641-p20

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.7 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.3 | +22.2 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | 28.3 | +176.8 | 0.0 | 293.0 | 40.3 | +668.4 | 0.0 | 265.3 |
| ASSAILMENT BY POINTS | 1.0 | +5.2 | 0.0 | 133.3 | - | - | - | - |
| BACKUP TARGETS | 0.3 | +0.8 | 0.0 | 0.0 | 0.7 | +3.4 | 0.0 | 0.0 |
| BOUND ASSAILMENT | 0.3 | +0.0 | 0.0 | 50.3 | - | - | - | - |
| CANNON PLAN MISSED | 0.3 | +0.0 | 65.0 | 0.0 | - | - | - | - |
| CANNON PLANNED TARGET | 4.0 | +21.8 | 260.0 | 0.0 | - | - | - | - |
| CANNON SIGHT KEPT | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CARRIES OUT SET-UP | - | - | - | - | 0.3 | -19.1 | 93.3 | 0.0 |
| CAST JOB | 1.0 | +19.2 | 66.0 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | 2.3 | +0.0 | 0.0 | 133.3 | - | - | - | - |
| CHAFF IN THE MOVE | - | - | - | - | 0.3 | +10.5 | 0.0 | 11.3 |
| CHAFF PASSED | 0.7 | -3.3 | 0.0 | 0.0 | - | - | - | - |
| CHALLENGE BY POINTS | 0.3 | +26.8 | 0.0 | 50.3 | - | - | - | - |
| CHAMPION KNOWS CHALLENGE | 0.3 | -102.1 | 0.0 | 0.0 | - | - | - | - |
| CHARGE LIST READ AGAIN | 0.3 | +5.2 | 22.0 | 99.0 | - | - | - | - |
| CHARGE LOSSES | 23.3 | -1118.0 | 0.0 | 746.3 | 16.7 | -746.9 | 0.0 | 191.7 |
| CHARGE NOW FIRST | 2.7 | +0.0 | 135.0 | 0.0 | 2.7 | +0.0 | 226.7 | 65.0 |
| CHARGER SLAIN LOST | 0.3 | -123.0 | 0.0 | 0.0 | - | - | - | - |
| CLOSES ON WHAT IT BEATS | 8.0 | +0.0 | 0.0 | 0.0 | 10.7 | +0.0 | 0.0 | 11.3 |
| COMBAT PIVOT | - | - | - | - | 0.3 | +0.0 | 0.0 | 65.0 |
| CONTINUE AHEAD WEIGHED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CONVEYANCE SEARCH | 3.3 | +490.0 | 266.7 | 266.7 | - | - | - | - |
| COVER ONCE | 8.7 | -456.3 | 0.0 | 277.0 | 11.0 | -1059.8 | 0.0 | 222.3 |
| DENIED BY THE FIGHT | 0.7 | -6.3 | 61.7 | 0.0 | 0.3 | -0.2 | 0.0 | 34.0 |
| DEPLOY BY FIGURES | 8.0 | -26.8 | 0.0 | 0.0 | 9.3 | +8.3 | 0.0 | 0.0 |
| EDGE GIVE GROUND | 0.3 | +17.4 | 0.0 | 0.0 | - | - | - | - |
| EVASIVE BY THE ODDS | 0.7 | +5.1 | 0.0 | 0.0 | 2.3 | +33.7 | 0.0 | 0.0 |
| EXACT ROUND | 2.3 | +12.2 | 169.0 | 99.0 | 2.7 | +30.5 | 376.0 | 99.0 |
| FALL BACK GOOD ORDER | 3.3 | +67.2 | 191.0 | 99.0 | 1.3 | +29.1 | 226.7 | 65.0 |
| FALLS SHORT | 6.0 | +95.8 | 0.0 | 0.0 | 22.3 | +304.1 | 0.0 | 125.0 |
| FEATURE BUFFS | 2.3 | +17.5 | 0.0 | 0.0 | - | - | - | - |
| FIGHT TO THE END | - | - | - | - | 0.7 | +6.1 | 93.3 | 65.0 |
| FIVE ACTION | 99.7 | +4807.3 | 821.0 | 1405.0 | 106.7 | +7621.2 | 610.0 | 797.0 |
| FLANK NOT WEIGHED | 6.3 | +0.0 | 0.0 | 386.3 | 11.3 | +0.0 | 0.0 | 222.3 |
| FOLLOW UP WEIGHED | - | - | - | - | 1.0 | +169.4 | 0.0 | 65.0 |
| FOUR ROUNDS | 3.7 | +253.1 | 191.0 | 99.0 | 2.7 | +268.7 | 376.0 | 99.0 |
| FREED FROM HIS FIGHT | 2.0 | +0.0 | 0.0 | 100.7 | 2.0 | +0.0 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | - | - | - | - | 0.7 | -4.2 | 0.0 | 0.0 |
| GIVES UP | 0.3 | -4.1 | 34.0 | 0.0 | 0.7 | -9.4 | 99.0 | 34.0 |
| GOAL WALK | 5.7 | +375.5 | 0.0 | 266.7 | 7.3 | +434.7 | 0.0 | 0.0 |
| GUN FIGURES | 0.3 | +0.0 | 65.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HARD STAY DROPPED | 2.0 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 87.3 |
| HE REFORMS ONCE FREED | 2.0 | +0.0 | 0.0 | 100.7 | 2.0 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 14.0 | +0.0 | 0.0 | 746.3 | 10.0 | +0.0 | 0.0 | 191.7 |
| HIS CHARGE LIST | 7.7 | +0.0 | 0.0 | 0.0 | 13.7 | +0.0 | 0.0 | 22.0 |
| HIS LEGAL MOVES | 5.3 | +0.0 | 0.0 | 99.0 | 8.0 | +0.0 | 0.0 | 130.0 |
| HIS MOVE AND SHOT | 7.7 | -146.2 | 0.0 | 93.3 | 3.7 | -75.4 | 0.0 | 126.7 |
| HIS MOVE AS HE DECIDES | 51.7 | +14.0 | 621.7 | 0.0 | - | - | - | - |
| HIS MOVE WHY | - | - | - | - | 16.0 | +0.0 | 0.0 | 112.0 |
| HIS ONE MOVE | 22.3 | -214.6 | 0.0 | 199.7 | - | - | - | - |
| HIS ONE QUARTER | 12.7 | +0.0 | 0.0 | 201.3 | 4.7 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 2.0 | +0.0 | 0.0 | 0.0 | 9.7 | +0.0 | 0.0 | 130.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 68.7 | +4479.7 | 0.0 | 1039.3 | 63.0 | +1823.9 | 0.0 | 415.0 |
| HIS SHOTS BY HIS RUN | 60.3 | +2022.6 | 0.0 | 1306.0 | 47.3 | +901.3 | 0.0 | 363.7 |
| HIS TURN DENIED | 1.0 | +86.2 | 83.7 | 0.0 | 0.3 | +11.5 | 0.0 | 34.0 |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 19.3 | +0.0 | 0.0 | 186.7 | 16.3 | +0.0 | 0.0 | 44.0 |
| HOLDER ASSIGNMENT | 9.7 | +863.9 | 0.0 | 93.3 | 10.7 | +865.2 | 0.0 | 22.0 |
| HOLDS AMBUSHERS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 3.3 | -111.7 | 191.0 | 99.0 | 1.7 | -63.7 | 376.0 | 0.0 |
| HUNT IN PAIRS | - | - | - | - | 0.7 | +26.5 | 0.0 | 65.0 |
| IDLE COST | 3.3 | -53.4 | 0.0 | 0.0 | 15.3 | -194.9 | 0.0 | 56.0 |
| KEPT FROM ITS LAST STOP | 3.0 | +0.0 | 0.0 | 186.7 | 3.0 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 1.7 | +82.5 | 0.0 | 0.0 | 1.0 | +20.0 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| LEGAL CHARGES ONLY | 5.0 | +0.0 | 61.7 | 0.0 | 4.0 | +0.0 | 325.7 | 178.7 |
| LONE WIZARD KEPT IN | - | - | - | - | 0.3 | +37.5 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | 1.3 | +0.1 | 13.3 | 0.0 | 1.7 | +1.3 | 93.3 | 99.0 |
| LURE BY WHAT IT DRAWS | - | - | - | - | 1.0 | -202.8 | 0.0 | 11.3 |
| MAKE SURE TOGETHER | - | - | - | - | 0.7 | +0.5 | 0.0 | 0.0 |
| MANOEUVRE | 1.7 | +0.0 | 0.0 | 93.3 | 3.3 | -12.4 | 0.0 | 140.0 |
| MARCH AT ESCAPER | 0.3 | +3.5 | 0.0 | 0.0 | - | - | - | - |
| MARCH BY THE SUM | 0.7 | +38.9 | 0.0 | 133.3 | 0.3 | +7.9 | 0.0 | 0.0 |
| MARCH CHECK | - | - | - | - | 0.7 | +24.8 | 0.0 | 0.0 |
| MARCH OF THE TABLE | 0.7 | +22.1 | 0.0 | 133.3 | - | - | - | - |
| MARCH OVER CASTS | 1.3 | +311.0 | 0.0 | 0.0 | 0.7 | +185.5 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 1.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 2.0 | +17.4 | 0.0 | 0.0 | 3.3 | +158.1 | 0.0 | 0.0 |
| MEETS IN TIME | 3.3 | +208.6 | 0.0 | 0.0 | 6.0 | +79.8 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 3.0 | +30.7 | 0.0 | 133.3 | 2.0 | +45.4 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 5.0 | +25.3 | 0.0 | 266.7 | 3.3 | +69.6 | 0.0 | 0.0 |
| MOVE ORDER | 2.7 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 22.0 | 0.0 |
| MOVE SPELL SPOT | 2.3 | +0.0 | 0.0 | 133.3 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 5.3 | +709.1 | 0.0 | 0.0 | 8.0 | +563.1 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 7.7 | +297.8 | 0.0 | 93.3 | 8.7 | +340.8 | 0.0 | 77.0 |
| NEXT CHARGE BY LIST | 3.7 | +576.2 | 0.0 | 0.0 | 6.7 | +466.7 | 0.0 | 0.0 |
| NEXT OBJECTIVE NEARER | - | - | - | - | 0.3 | -4.3 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 3.3 | -135.7 | 169.0 | 0.0 | 2.3 | -190.8 | 376.0 | 99.0 |
| NO LATE CUT | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NO OLD ONE-MOVE GUESS | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | - | - | - | - | 0.7 | -1.2 | 0.0 | 0.0 |
| OFF BEST | 3.7 | -230.3 | 0.0 | 0.0 | 7.7 | -209.8 | 99.0 | 0.0 |
| ONE CHECK AFTER THE LAST CHANGE | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 3.7 | -96.1 | 0.0 | 0.0 | 5.0 | -134.6 | 0.0 | 0.0 |
| ONE OBJECTIVE FORMULA | 5.7 | -43.3 | 0.0 | 0.0 | 4.3 | -223.5 | 0.0 | 22.0 |
| ONE ROUTE | 1.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| OPENS A LANE | 0.3 | +0.3 | 11.3 | 0.0 | - | - | - | - |
| OPENS UP | 0.3 | +15.2 | 38.0 | 0.0 | - | - | - | - |
| OVERRUNS AWAY | 0.7 | +64.0 | 99.7 | 0.0 | 0.3 | +5.0 | 0.0 | 0.0 |
| PATHS CROSS | - | - | - | - | 0.3 | +7.3 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.3 | -25.3 | 0.0 | 133.3 | - | - | - | - |
| PLAN RESULT | 43.3 | +533.4 | 351.3 | 525.3 | 48.0 | +654.5 | 0.0 | 672.0 |
| PROMISE BELOW ZERO | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE BY ITS OWN SUM | 10.3 | -369.7 | 0.0 | 0.0 | 10.0 | -230.6 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | 0.3 | +0.0 | 0.0 | 0.0 | 1.0 | -2.2 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | - | - | - | - | 1.0 | -3.7 | 0.0 | 0.0 |
| PROMISE SHOT AWAY | 0.3 | -0.7 | 0.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | 18.3 | +1675.0 | 0.0 | 201.3 | 19.7 | +2537.1 | 151.0 | 0.0 |
| REAL GROUND | 1.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | - | - | - | - | 3.0 | +345.0 | 0.0 | 57.3 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 5.0 | +0.0 | 0.0 | 80.0 |
| REFORMS TO MEET IT | 2.0 | -42.4 | 0.0 | 0.0 | 2.7 | -98.8 | 0.0 | 0.0 |
| REFUSING RETIRES | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | 3.0 | -17.2 | 191.0 | 99.0 | 2.0 | -55.7 | 325.7 | 99.0 |
| RISK ON THE WAY | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| ROUNDS AFTER TERROR | 1.3 | -50.8 | 99.7 | 0.0 | 1.3 | -15.1 | 376.0 | 0.0 |
| RUN DOWN | 2.7 | -27.1 | 113.0 | 0.0 | 2.3 | -10.1 | 277.0 | 99.0 |
| SCOUT SPOT | - | - | - | - | 1.3 | -0.1 | 0.0 | 0.0 |
| SCOUT WAITS | - | - | - | - | 1.7 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 1.0 | -41.4 | 0.0 | 0.0 |
| SEARCH SPOT | 0.3 | +1.8 | 0.0 | 0.0 | 1.0 | -26.2 | 0.0 | 0.0 |
| SECOND LOOK | 0.3 | +10.8 | 0.0 | 0.0 | 0.3 | +32.1 | 99.0 | 0.0 |
| SET CREDITED ONCE | - | - | - | - | 2.0 | -198.8 | 0.0 | 0.0 |
| SET UP BY THE SET | 0.7 | +31.6 | 0.0 | 0.0 | 3.3 | +195.2 | 0.0 | 0.0 |
| SET UP TOGETHER | - | - | - | - | 0.7 | +0.5 | 0.0 | 0.0 |
| SET-UP ANY TARGET | 0.7 | +99.6 | 133.3 | 133.3 | - | - | - | - |
| SET-UP MISSED | 0.3 | +191.2 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | - | - | - | - | 0.7 | +2.0 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 9.0 | +0.0 | 0.0 | 0.0 | 5.7 | +0.0 | 0.0 | 183.3 |
| SHOOTS FROM THE BEST SPOT | 0.3 | +2.7 | 0.0 | 0.0 | 1.7 | +41.8 | 50.3 | 0.0 |
| SHOT OR CHARGE | 0.7 | -15.3 | 0.0 | 0.0 | 0.3 | -5.1 | 50.3 | 0.0 |
| SHOT RISK POINTS | 45.7 | -56.5 | 0.0 | 946.0 | 24.7 | -90.9 | 0.0 | 238.3 |
| SHOTS AFTER THE MOVES | 3.7 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 16.7 | +422.1 | 0.0 | 133.3 | 21.3 | +796.4 | 0.0 | 218.7 |
| SPELL SETS UP CHARGE | 0.7 | +99.6 | 133.3 | 133.3 | - | - | - | - |
| SPELL WORTH | 0.7 | +16.7 | 266.7 | 266.7 | 1.3 | +11.2 | 0.0 | 0.0 |
| SPELLS IN THE FIGHT | 0.3 | +1.0 | 0.0 | 0.0 | 0.3 | -2.8 | 0.0 | 34.0 |
| SPOT AS THE GAME MOVES | 4.7 | +0.0 | 0.0 | 133.3 | 7.7 | +0.0 | 0.0 | 11.3 |
| STAND AND SHOOT | 0.7 | -6.5 | 60.0 | 99.0 | 0.3 | -0.1 | 99.0 | 0.0 |
| STANDS FOR A REASON | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 49.0 | +0.0 | 630.0 | 100.7 | 36.0 | +0.0 | 234.0 | 383.0 |
| STAY WORTH | 25.0 | +51.0 | 630.0 | 0.0 | 16.7 | +127.8 | 0.0 | 38.0 |
| STRIKE BY THE ODDS | 0.3 | +7.3 | 0.0 | 0.0 | - | - | - | - |
| SUPPORT ADDS | 7.0 | +362.7 | 0.0 | 194.0 | 8.7 | +603.9 | 0.0 | 11.3 |
| SUPPORT NARROWED | 0.3 | +0.0 | 22.0 | 99.0 | - | - | - | - |
| SUPPORT WORKED OUT | 7.0 | +362.7 | 0.0 | 194.0 | 8.7 | +603.9 | 0.0 | 11.3 |
| SURE REACH TOGETHER | 0.3 | +7.0 | 0.0 | 0.0 | 2.3 | +33.6 | 0.0 | 44.0 |
| SWIFTSTRIDE BY POINTS | 0.3 | +2.5 | 0.0 | 133.3 | - | - | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 1.7 | +0.0 | 0.0 | 133.3 | 2.3 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 2.0 | +0.0 | 0.0 | 99.0 | 4.7 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 3.3 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 99.0 |
| THE STEP BACK IS MADE | 1.0 | +0.0 | 0.0 | 0.0 | 4.7 | +0.0 | 0.0 | 160.7 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 47.7 | +0.0 | 0.0 | 653.0 | 51.0 | +0.0 | 0.0 | 343.3 |
| TIED UP BY THE SUM | 2.3 | +274.6 | 191.0 | 99.0 | 0.3 | +44.4 | 99.0 | 0.0 |
| TIME ON OUR SIDE | 49.0 | +478.6 | 44.0 | 1011.3 | 14.3 | +156.1 | 0.0 | 213.7 |
| WAITS AGAIN | 0.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| WAR ENGINE JOBS | - | - | - | - | 2.3 | +0.0 | 0.0 | 185.0 |
| WEAPON BY POINTS | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WHAT THE JOINER ADDS | - | - | - | - | 0.7 | -116.1 | 0.0 | 0.0 |
| WHO FIGHTS | - | - | - | - | 0.3 | -4.4 | 93.3 | 0.0 |
| WHO HITS BACK | 1.0 | +261.0 | 0.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT | - | - | - | - | 0.3 | +59.2 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | 1.7 | -104.9 | 0.0 | 93.3 | 2.0 | -308.1 | 0.0 | 61.7 |

### Rule changes: cnomg-c940641-p20

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 206 | 206 | 143 | 47.67 | +3084 | +21.6 |
| HIS MOVE AS HE DECIDES | 155 | 155 | 113 | 37.67 | +0 | +0.0 |
| HIS SHOT LIST | 395 | 377 | 105 | 35.00 | +2481 | +23.6 |
| HIS SHOTS BY HIS RUN | 323 | 305 | 69 | 23.00 | +1324 | +19.2 |
| HOLDER ASSIGNMENT | 61 | 61 | 57 | 19.00 | +3437 | +60.3 |
| SHOT RISK POINTS | 211 | 204 | 43 | 14.33 | +1981 | +46.1 |
| OFF BEST | 34 | 34 | 34 | 11.33 | -1320 | -38.8 |
| THE TABLE AGAIN | 36 | 36 | 34 | 11.33 | +0 | +0.0 |
| DEPLOY BY FIGURES | 52 | 52 | 32 | 10.67 | +353 | +11.0 |
| LEGAL CHARGES ONLY | 27 | 27 | 27 | 9.00 | +0 | +0.0 |
| HIS MOVE WHY | 48 | 48 | 25 | 8.33 | +0 | +0.0 |
| PROMISE BY ITS OWN SUM | 61 | 61 | 24 | 8.00 | -1801 | -75.0 |
| QUARTER ODDS | 114 | 112 | 23 | 7.67 | +1624 | +70.6 |
| MOVE TO CHARGE COMPUTED | 40 | 33 | 20 | 6.67 | +1372 | +68.6 |
| TIME ON OUR SIDE | 190 | 168 | 20 | 6.67 | +100 | +5.0 |
| HIS ONE MOVE | 67 | 66 | 18 | 6.00 | +0 | +0.0 |
| NEXT CHARGE BY LIST | 31 | 27 | 16 | 5.33 | +1262 | +78.9 |
| MOVE ORDER | 15 | 15 | 15 | 5.00 | +0 | +0.0 |
| REDIRECT FOR A FRIEND IN REACH | 15 | 15 | 15 | 5.00 | +0 | +0.0 |
| FIVE ACTION | 619 | 595 | 14 | 4.67 | +935 | +66.8 |
| SUPPORT ADDS | 47 | 46 | 14 | 4.67 | +237 | +16.9 |
| SUPPORT WORKED OUT | 47 | 46 | 14 | 4.67 | +237 | +16.9 |
| MEETS IN TIME | 28 | 28 | 13 | 4.33 | +486 | +37.4 |
| ADVANCE LANE KEPT | 12 | 12 | 12 | 4.00 | +0 | +0.0 |
| COVER ONCE | 59 | 41 | 12 | 4.00 | +202 | +16.8 |
| GOAL WALK | 39 | 39 | 11 | 3.67 | +439 | +39.9 |
| HARD STAY DROPPED | 11 | 11 | 11 | 3.67 | +0 | +0.0 |
| SHOTS IN THE MOVE | 114 | 90 | 9 | 3.00 | +363 | +40.4 |
| LANE BY FIGURES | 8 | 8 | 8 | 2.67 | +308 | +38.5 |
| CHARGE LOSSES | 120 | 115 | 7 | 2.33 | +196 | +28.0 |
| FALLS SHORT | 85 | 75 | 7 | 2.33 | +7 | +1.1 |
| SET UP BY THE SET | 12 | 12 | 7 | 2.33 | +1244 | +177.7 |
| FOUR ROUNDS | 19 | 17 | 6 | 2.00 | +282 | +47.0 |
| TIED UP BY THE SUM | 8 | 7 | 6 | 2.00 | +234 | +39.0 |
| SCOUT WAITS | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| SHOOTS FROM THE BEST SPOT | 6 | 6 | 4 | 1.33 | +24 | +6.1 |
| SHOTS AFTER THE MOVES | 20 | 20 | 4 | 1.33 | +0 | +0.0 |
| ASSAILMENT BY POINTS | 3 | 3 | 3 | 1.00 | +16 | +5.2 |
| CANNON SIGHT KEPT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| CAST JOB | 3 | 3 | 3 | 1.00 | +27 | +8.9 |
| CHARGE NOW FIRST | 16 | 16 | 3 | 1.00 | -136 | -45.2 |
| FOLLOW UP WEIGHED | 3 | 3 | 3 | 1.00 | +508 | +169.4 |
| HIS MOVE AND SHOT | 34 | 33 | 3 | 1.00 | +88 | +29.4 |
| MARCH BY THE SUM | 3 | 3 | 3 | 1.00 | +140 | +46.8 |
| MAX FOR POSITIONING | 16 | 15 | 3 | 1.00 | +16 | +5.4 |
| SEARCH SPOT | 4 | 4 | 3 | 1.00 | +24 | +8.1 |
| STAY WORTH | 125 | 110 | 3 | 1.00 | +5 | +1.8 |
| WHO HITS BACK | 3 | 3 | 3 | 1.00 | +552 | +184.1 |
| CANNON PLANNED TARGET | 12 | 12 | 2 | 0.67 | +0 | +0.0 |
| CHAFF PASSED | 2 | 2 | 2 | 0.67 | -10 | -5.0 |
| EVASIVE BY THE ODDS | 9 | 9 | 2 | 0.67 | +0 | +0.0 |
| HIS TURN DENIED | 4 | 4 | 2 | 0.67 | +208 | +104.2 |
| HOLDS AMBUSHERS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| MANOEUVRE | 15 | 15 | 2 | 0.67 | +33 | +16.5 |
| MARCH OF THE TABLE | 2 | 2 | 2 | 0.67 | -66 | -33.1 |
| NEARER NOT NEEDED | 49 | 47 | 2 | 0.67 | +88 | +44.1 |
| PROMISE READS THE TABLE | 3 | 3 | 2 | 0.67 | +93 | +46.6 |
| SECOND LOOK | 2 | 2 | 2 | 0.67 | +129 | +64.4 |
| SHOOTERS IN TWO RANKS | 2 | 2 | 2 | 0.67 | +6 | +3.0 |
| SURE REACH TOGETHER | 8 | 7 | 2 | 0.67 | +7 | +3.4 |
| AFTERMATH IN POINTS | 1 | 1 | 1 | 0.33 | +66 | +66.4 |
| BOUND ASSAILMENT | 1 | 1 | 1 | 0.33 | +0 | +0.1 |
| CARRIES OUT SET-UP | 1 | 1 | 1 | 0.33 | -57 | -57.2 |
| CHAFF IN THE MOVE | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CHALLENGE BY POINTS | 1 | 1 | 1 | 0.33 | +81 | +80.6 |
| CHARGE LIST READ AGAIN | 1 | 1 | 1 | 0.33 | +16 | +15.7 |
| COMBAT PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CONTINUE AHEAD WEIGHED | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FALL BACK GOOD ORDER | 14 | 13 | 1 | 0.33 | +14 | +14.1 |
| HUNT IN PAIRS | 2 | 2 | 1 | 0.33 | +16 | +16.1 |
| LONE WIZARD KEPT IN | 1 | 1 | 1 | 0.33 | +112 | +112.5 |
| ONE OBJECTIVE FORMULA | 30 | 24 | 1 | 0.33 | +38 | +37.7 |
| OVERRUNS AWAY | 3 | 3 | 1 | 0.33 | +127 | +127.0 |
| PATHS CROSS | 1 | 1 | 1 | 0.33 | +22 | +21.9 |
| PIVOT GUARDS FLANK | 1 | 1 | 1 | 0.33 | -76 | -75.8 |
| PROMISE KNOWS THE FIGHT | 4 | 3 | 1 | 0.33 | -7 | -6.7 |
| PROMISE SHOT AWAY | 1 | 1 | 1 | 0.33 | -2 | -2.1 |
| REDIRECT COUNTER | 9 | 8 | 1 | 0.33 | +148 | +147.8 |
| REFUSING RETIRES | 2 | 2 | 1 | 0.33 | -74 | -73.8 |
| RISK BY ARC | 15 | 13 | 1 | 0.33 | +19 | +18.6 |
| SWIFTSTRIDE BY POINTS | 1 | 1 | 1 | 0.33 | +7 | +7.4 |
| THE ROW IN ITS ORDER | 20 | 1 | 1 | 0.33 | +0 | +0.0 |
| WEAPON BY POINTS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| WHOLE FIGHT | 1 | 1 | 1 | 0.33 | +58 | +57.8 |
| WHOLE FIGHT DANGER | 11 | 11 | 1 | 0.33 | +8 | +8.5 |
| BACKUP TARGETS | 3 | 2 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 1 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 7 | trace | - | - | - | - |
| CHAMPION KNOWS CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| CHARGER SLAIN LOST | 1 | 1 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 56 | 56 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 10 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 3 | 3 | 0 | 0.00 | - | - |
| EDGE GIVE GROUND | 1 | 1 | 0 | 0.00 | - | - |
| EXACT ROUND | 15 | 13 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 7 | 7 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 2 | 1 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 53 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 12 | 11 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 2 | 2 | 0 | 0.00 | - | - |
| GIVES UP | 3 | 2 | 0 | 0.00 | - | - |
| GUN FIGURES | 3 | not checked | - | - | - | - |
| HE REFORMS ONCE FREED | 12 | 11 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 72 | 68 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 64 | 61 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 40 | 35 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 52 | 51 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 35 | 30 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN RUN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 107 | 107 | 0 | 0.00 | - | - |
| HONEST WORTH | 15 | 13 | 0 | 0.00 | - | - |
| IDLE COST | 56 | 40 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 18 | 18 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 2 | 2 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 9 | 8 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 3 | 3 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 2 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH CHECK | 2 | 2 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 6 | 6 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 7 | 7 | 0 | 0.00 | - | - |
| MISSILES IN THE MOVE | 15 | 12 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 25 | 21 | 0 | 0.00 | - | - |
| MOVE SPELL SPOT | 7 | not checked | - | - | - | - |
| NEXT OBJECTIVE NEARER | 1 | not checked | - | - | - | - |
| NO DOUBLE ROUNDS | 17 | 15 | 0 | 0.00 | - | - |
| NO LATE CUT | 3 | 3 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 18 | 18 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 2 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 1 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 26 | 15 | 0 | 0.00 | - | - |
| ONE ROUTE | 7 | 7 | 0 | 0.00 | - | - |
| OPENS A LANE | 1 | not checked | - | - | - | - |
| OPENS UP | 1 | 1 | 0 | 0.00 | - | - |
| PLAN RESULT | 274 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 2 | 2 | 0 | 0.00 | - | - |
| REAL GROUND | 7 | 7 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 14 | 13 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 2 | 2 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 8 | 6 | 0 | 0.00 | - | - |
| RUN DOWN | 15 | 14 | 0 | 0.00 | - | - |
| SCOUT SPOT | 4 | 4 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 3 | 3 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 6 | 6 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 2 | 1 | 0 | 0.00 | - | - |
| SET-UP ANY TARGET | 2 | not checked | - | - | - | - |
| SET-UP MISSED | 1 | trace | - | - | - | - |
| SHOOTERS ON THE TABLE | 44 | not checked | - | - | - | - |
| SHOT OR CHARGE | 3 | 3 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 2 | not checked | - | - | - | - |
| SPELL WORTH | 6 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 37 | 32 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 3 | 2 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 4 | 3 | 0 | 0.00 | - | - |
| STANDS STILL | 255 | 243 | 0 | 0.00 | - | - |
| STRIKE BY THE ODDS | 1 | 1 | 0 | 0.00 | - | - |
| SUPPORT NARROWED | 1 | 1 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 12 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 28 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 17 | not checked | - | - | - | - |
| THE TABLE BINDS | 296 | not checked | - | - | - | - |
| WAITS AGAIN | 6 | 4 | 0 | 0.00 | - | - |
| WAR ENGINE JOBS | 7 | 7 | 0 | 0.00 | - | - |
| WHAT THE JOINER ADDS | 2 | 2 | 0 | 0.00 | - | - |
| WHO FIGHTS | 1 | not checked | - | - | - | - |

### Off best figure: cnomg-c940641-p20

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 3.67 | 6.33 | 35.6 |
| PROMISE BY ITS OWN SUM | rule | 4.33 | 3.67 | 75.0 |
| ARMY TABLE | rule | 3.33 | 2.67 | 24.1 |
| HOLDER ASSIGNMENT | rule | 0.67 | 1.00 | 10.3 |
| NO REASON | gate | - | 1.33 | 62.8 |
| CHARGE NOW FIRST | rule | 0.67 | 0.33 | 45.2 |
| CHAFF PASSED | rule | 0.67 | - | 5.0 |
| DEPLOY BY FIGURES | rule | - | 0.67 | 6.2 |
| MARCH OF THE TABLE | rule | 0.67 | - | 33.1 |
| CARRIES OUT SET-UP | rule | - | 0.33 | 57.2 |
| PIVOT GUARDS FLANK | rule | 0.33 | - | 75.8 |
| PROMISE KNOWS THE FIGHT | rule | - | 0.33 | 6.7 |
| PROMISE SHOT AWAY | rule | 0.33 | - | 2.1 |
| REFUSING RETIRES | rule | 0.33 | - | 73.8 |

### Plans: cnomg-c940641-p20

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 3.3 | 50% | 461 | 190 | 41% |
| Mine | move | 31.7 | 97% | 1676 | 0 | 0% |
| Mine | shoot | 8.3 | 64% | 207 | 344 | 166% |
| Opponent | charge | 2.0 | 67% | 316 | 383 | 121% |
| Opponent | move | 40.7 | 97% | 2279 | 0 | 0% |
| Opponent | shoot | 4.3 | 62% | 644 | 272 | 42% |
| Opponent | support | 1.0 | 67% | 0 | 0 | - |

### Battle groups: cnomg-c940641-p20

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | REDIRECT COUNTER | 3.0 | 33% | 67% | 33% | 0% | 0% | 0% | 0% | 50% | 50% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: cnomg-c940641-p20

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Character | 7 | 38 (7) | 38 | 0 | 23 | 0% | 1.6 | 48 (5) | 38 (1) | 0 (1) | 47 (5) | 19 (2) |
| Mine | Clean-up | 1 | 0 (1) | 0 | 0 | 122 | 0% | 2.0 | 0 (1) | - | - | 0 (1) | - |
| Mine | Fast Hammer | 14 | 53 (14) | 6 | 48 | 8 | 57% | 3.2 | 23 (8) | 95 (6) | - | 52 (9) | 56 (5) |
| Mine | Shooter | 4 | 0 (4) | 0 | 0 | 0 | 0% | 1.0 | 0 (3) | 0 (1) | - | 0 (3) | 0 (1) |
| Mine | War machine | 2 | 139 (2) | 139 | 0 | 0 | 0% | 1.0 | 139 (2) | - | - | - | 139 (2) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Chaff | 7 | 176 (7) | 0 | 176 | 79 | 14% | 2.3 | - | 345 (4) | 16 (3) | 405 (4) | 14 (3) |
| Opponent | Character | 4 | 28 (4) | 28 | 0 | 0 | 0% | 1.2 | - | 28 (4) | - | 0 (2) | 51 (2) |
| Opponent | Clean-up | 4 | 0 (4) | 0 | 0 | 30 | 75% | 4.0 | 0 (1) | 0 (2) | 0 (1) | 0 (3) | 0 (1) |
| Opponent | Fast Hammer | 4 | 42 (4) | 42 | 0 | 58 | 0% | 2.2 | 0 (2) | 87 (2) | - | 0 (3) | 144 (1) |
| Opponent | Hammer | 8 | 0 (8) | 0 | 0 | 12 | 50% | 1.8 | 0 (2) | 0 (3) | 0 (3) | 0 (4) | 0 (4) |
| Opponent | Holder | 3 | 109 (3) | 0 | 109 | 0 | 0% | 2.7 | 350 (1) | 0 (1) | 0 (1) | 350 (1) | 0 (2) |
| Opponent | Shooter | 4 | 66 (4) | 0 | 66 | 21 | 0% | 2.5 | 0 (1) | 142 (2) | 0 (1) | 80 (2) | 55 (2) |
| Opponent | Wizard | 3 | 0 (3) | 0 | 0 | 0 | 33% | 1.5 | 0 (2) | 0 (1) | - | 0 (1) | 0 (2) |

### Charged fights: cnomg-c940641-p20

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | High Elf Realms | 3 | 65 | 145 | 2.3 | 1.0 | 62 | 0 | +62 | 1 of 7 | 7 of 7 | - | +62 |
| Opponent | Ogre Kingdoms | 1 | 0 | 0 | 1.0 | 1.0 | 0 | 34 | -34 | 0 of 1 | 0 of 1 | - | -34 |
| Opponent | Tomb Kings of Khemri | 1 | 400 | 728 | 4.0 | 1.0 | 182 | 49 | +133 | 2 of 4 | 4 of 4 | - | +133 |
| Opponent | Wood Elf Realms | 1 | 0 | 0 | 2.0 | 1.0 | 0 | 108 | -108 | 2 of 2 | 1 of 2 | - | -108 |
| **Opponent** | all armies | 3 | 133 | 243 | 2.3 | 1.0 | 104 | 64 | +40 | 4 of 7 | 5 of 7 | - | +40 |

### Effective charges: cnomg-c940641-p20

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | High Elf Realms | 7 | 1 (net +0) | 0 | 1 (net +0) | 0 | 4 (net +62) | 1 (net +185) | 0 | 14% (1 of 7) |
| Opponent | Tomb Kings of Khemri | 4 | 0 | 0 | 2 (net +191) | 0 | 0 | 2 (net +76) | 0 | 50% (2 of 4) |
| Opponent | Wood Elf Realms | 2 | 1 (net -216) | 0 | 0 | 0 | 0 | 1 (net +0) | 0 | 0% (0 of 2) |

### Charged fights, damage counted: cnomg-c940641-p20

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 1 | 143 | 158 | +0 | 242 | 0 | +242 | +169.2 |
| Mine | Effective (55-75%) | 1 | 143 | 234 | +0 | 78 | 95 | -17 | -12.1 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 489 | 185 | +185 | 185 | 54 | +131 | +26.7 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 4 | 308 | 72 | +62 | 62 | 0 | +62 | +20.2 |
| Mine | All fights | 7 | 287 | 123 | +62 | 108 | 21 | +86 | +30.1 |
| Opponent | Long shot (under 50%) | 1 | 102 | 500 | -216 | 0 | 216 | -216 | -211.8 |
| Opponent | Effective (55-75%) | 2 | 195 | 286 | +191 | 396 | 174 | +222 | +113.8 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 | 460 | 350 | +50 | 189 | 37 | +152 | +33.1 |
| Opponent | No odds | 1 | 34 | 123 | -34 | 25 | 34 | -9 | -27.6 |
| Opponent | All fights | 7 | 272 | 321 | +40 | 198 | 101 | +96 | +35.4 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| cnomg-c940641-p20 | move | 19 | 7 (37%) | 5 (26%) | 2 (11%) | 10 (53%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Fistful of Laurels | Opponent | L1418 |
| Opal Amulet | Mine | L1418, L1435 |
| Standard of the Fell Warrior | Mine | L1323 |

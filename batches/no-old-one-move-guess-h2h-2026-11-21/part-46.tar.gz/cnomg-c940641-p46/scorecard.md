# Doctrine scorecard: cnomg-c940641-p46

### Scorecard: cnomg-c940641-p46

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L1827 | 3 | 1 | Mine | no | 2 | 2 | 0 | 2 | 0 | 0 | 0 | 0 |
| L1827 | 3 | 1 | Opponent | no | 6 | 2 | 5 | 2 | 0 | 0 | 0 | 0 |
| L1927 | 1 | 1 | Mine | no | 3 | 1 | 5 | 1 | 1 | 0 | 0 | 255 |
| L1927 | 1 | 1 | Opponent | no | 2 | 2 | 2 | 4 | 0 | 0 | 0 | 0 |
| L2029 | 1 | 1 | Mine | no | 0 | - | 0 | 3 | 1 | 0 | 0 | 420 |
| L2029 | 1 | 1 | Opponent | no | 6 | 2 | 2 | 1 | 1 | 0 | 0 | 170 |
| **Average** | | | Mine | 0% | 1.7 | 1.5 | 1.7 | 2.0 | 0.7 | 0.0 | 0.0 | 225.0 |
| **Average** | | | Opponent | 0% | 4.7 | 2.0 | 3.0 | 2.3 | 0.3 | 0.0 | 0.0 | 56.7 |

### KPIs: cnomg-c940641-p46

Rules off - Opponent only: NO OLD ONE-MOVE GUESS.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 15) | 0% (0 of 15) | 0% (0 of 30) |
| Winner chose to follow up after the loser gave ground |  | 100% (7 of 7); on the table 100% | 67% (2 of 3); on the table 67% | 90% (9 of 10); on the table 90% |
| Winner chose to pursue after the loser fell back in good order |  | - | 67% (4 of 6); on the table 67% | 67% (4 of 6); on the table 67% |
| Winner chose to pursue after the loser fled |  | 0% (0 of 1); on the table 0% | 71% (5 of 7); on the table 86% | 62% (5 of 8); on the table 75% |
| Winner chose to follow up or pursue (all three) |  | 88% (7 of 8); on the table 88% | 69% (11 of 16); on the table 75% | 75% (18 of 24); on the table 79% |
| Magic missiles tried each own turn | 50%+ | 12% (3 of 24) | 33% (4 of 12) | 19% (7 of 36) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 18% (3 of 17) | 33% (4 of 12) | 24% (7 of 29) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 100% (6 of 6) | 33% (2 of 6) | 67% (8 of 12) |
| Points that never fought | lower | 35% (2081 of 5999) | 39% (2346 of 5999) | 37% (4427 of 11998) |
|   infantry points that never fought | lower | 64% (636 of 993) | 92% (733 of 793) | 77% (1369 of 1786) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 64% (14 of 22) | 42% (8 of 19) | 54% (22 of 41) |
| Bound items with a magic missile used (at least once a game) |  | 100% (1 of 1); 0.3 uses a game | 0.0 uses a game | 100% (1 of 1); 0.2 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 50% (1 of 2); 0.3 uses a game | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 66% (3385 of 5151) | 31% (1554 of 4976) | 49% (4939 of 10127) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.3 (19%) | 2.7 (100%) | 4.0 (41%) |
| MARCHED: its unit marched | 1.3 (19%) | 0.0 (0%) | 1.3 (14%) |
| IN COMBAT: engaged in combat | 1.3 (19%) | 0.0 (0%) | 1.3 (14%) |
| REAR RANK: in a rear rank | 1.7 (24%) | 0.0 (0%) | 1.7 (17%) |
| GONE: slain | 1.0 (14%) | 0.0 (0%) | 1.0 (10%) |
| NOT OFFERED: not in the cast list | 0.3 (5%) | 0.0 (0%) | 0.3 (3%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 2.3 | 1.7 | 2.3 | 0.7 | 3.3 |
| not cast | 9.7 | 8.3 | 9.7 | 3.3 | 28.7 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 3.3 (12%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.0 (0%) | 4.0 (41%) | 1.0 (30%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 1.3 (14%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.0 (0%) | 1.3 (14%) | 0.0 (0%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 2.0 (21%) | 2.0 (24%) | 1.7 (17%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | 1.7 (17%) | 0.0 (0%) | 1.0 (10%) | 0.0 (0%) | 1.7 (6%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (0%) | 1.0 (12%) | 0.0 (0%) | 1.0 (30%) | 0.0 (0%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.3 (5%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.3 (40%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.3 (3%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 6.0 (62%) | 5.3 (64%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 22.3 (78%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.0 a game | 0.7 a game | 0.8 a game |
| stood (cast and not dispelled) | 0% (0 of 3) | 0% (0 of 2) | 0% (0 of 5) |
| the unit moved after it | - | - | - |
| it charged on its next turn | - | - | - |
| the enemy charged it first | - | - | - |
| it fought by the end of its next turn | - | - | - |
| it moved out of a charge the enemy had planned (not charged first) | - | - | - |
| none of these (no charge, no fight, no charge escaped) | - | - | - |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 65% (43 of 66) | 12% (1 of 8) | 59% (44 of 74) |
|   cavalry | - | 33% (1 of 3) | 33% (1 of 3) |
|   character | 100% (6 of 6) | 0% (0 of 5) | 55% (6 of 11) |
|   chariot | 92% (11 of 12) | - | 92% (11 of 12) |
|   infantry | 44% (16 of 36) | - | 44% (16 of 36) |
|   monster | 83% (10 of 12) | - | 83% (10 of 12) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 3.3 (43%) | 0.3 (14%) | 3.7 (37%) |
| CHARGED: it charged | 0.7 (9%) | 1.3 (57%) | 2.0 (20%) |
| NO TARGET IN RANGE | 2.3 (30%) | 0.3 (14%) | 2.7 (27%) |
| ONLY IN COMBAT: the only targets were in combat | 0.0 (0%) | 0.3 (14%) | 0.3 (3%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.0 (13%) | 0.0 (0%) | 1.0 (10%) |
| OTHER BAR | 0.3 (4%) | 0.0 (0%) | 0.3 (3%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 0.3 | 0.0 | 100% | 0.0 pts | 0 pts |
| character | 2.3 | 0.0 | 100% | 0.0 pts | 0 pts |
| chariot | 3.7 | 2.0 | 73% | 24.8 pts | 91 pts |
| infantry | 5.7 | 3.0 | 65% | 23.7 pts | 134 pts |
| monster | 3.3 | 0.3 | 90% | 0.3 pts | 1 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 5.7 | 6.7 | 6.2 |
| Charges that made contact a game | 3.3 | 4.3 | 3.8 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.00 declared, 0.00 contact (1 units) | 0.00 declared, 0.00 contact (2 units) | 0.00 declared, 0.00 contact (3 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 0.33 declared, 0.33 contact (3 units) | 0.33 declared, 0.33 contact (3 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.61 declared, 0.36 contact (28 units) | 0.79 declared, 0.50 contact (24 units) | 0.69 declared, 0.42 contact (52 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 100% (4 of 4) | 33% (1 of 3) | 0% (0 of 2) | 56% (5 of 9) |
| Character in a unit | 60% (3 of 5) | 50% (1 of 2) | - | 57% (4 of 7) |
| Character on its own | 67% (2 of 3) | 100% (1 of 1) | 50% (3 of 6) | 60% (6 of 10) |
| Chariot | 50% (1 of 2) | - | - | 50% (1 of 2) |
| Infantry | 50% (2 of 4) | 0% (0 of 1) | - | 40% (2 of 5) |
| Monster | 0% (0 of 1) | 100% (3 of 3) | - | 75% (3 of 4) |
| Monstrous | - | 25% (1 of 4) | - | 25% (1 of 4) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Ogre Kingdoms | 1 | 100% (4 of 4); on the table 100% | 0% (0 of 6) | 42% | 43% (3 of 7) | 100% (1 of 1); 1.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 1 | 100% (2 of 2); on the table 100% | 25% (3 of 12) | 24% | 75% (6 of 8) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Skaven | 1 | 50% (1 of 2); on the table 50% | 0% (0 of 6) | 38% | 71% (5 of 7) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Vampire Counts | 2 | 67% (10 of 15); on the table 73% | 33% (4 of 12) | 36% | 50% (6 of 12) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 1 | 100% (1 of 1); on the table 100% | - | 45% | 29% (2 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (cnomg-c940641-p46, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 78% (7) | 43% (3) | 62% (10) |
| ...free all their last turn and able to turn (per game) | 0.67 | 0.33 | 1.00 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.33 | 0.33 | 0.67 |
| ...with the charger already in that arc before they moved (per game) | 0.67 | 0.33 | 1.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: cnomg-c940641-p46

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.7 | 4.0 |
| Strategy | Charge objectives carried out (made contact) | 50% (3 of 6) | 42% (8 of 19) |
| Strategy | Shoot objectives carried out (shot that target) | 42% (5 of 12) | 0% (0 of 4) |
| Strategy | Support requests answered (helper made contact too) | 100% (1 of 1) | 50% (1 of 2) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (1 of 1) | - |
| Strategy | Joined characters whose unit fought | 100% (3 of 3) | 20% (1 of 5) |
| Strategy | Lone characters that fought | 71% (5 of 7) | 78% (7 of 9) |
| Movement | Charges halted short of contact | 0.0 | 0.7 |
| Movement | Idle units | 2.0 | 2.3 |
| Movement | Points that never moved of their own | 225.0 | 56.7 |
| Movement | Fights charged into per game | 3.0 | 3.7 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 4 | 1 of 10, net -110 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 4 | 2 of 10, net +38 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 1 of 4, net +45 | 1 of 10, net +65 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 of 4, net -11 | 5 of 10, net +244 |
| Shooting | Shots by shooting units (incl. breath weapons) | 14.7 | 0.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 64% (28 of 44) | 0% (0 of 1) |
| Shooting | Points destroyed by shooting units | 0.0 | 0.0 |
| Shooting | Points destroyed by war machines | 20.0 | 0.0 |
| Magic | Magic missiles cast | 0.3 | 1.0 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 100% (1 of 1) | 0% (0 of 3) |
| Magic | Wounds caused by magic missiles | 0.3 | - |
| Magic | Wounds caused by other spells | 0.3 | - |
| Magic | Points destroyed by magic (all spells) | 0.0 | 11.3 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.0 / 0.0 / 1.7 / 0.0 | 0.7 / 0.0 / 0.3 / 0.3 |
| Combat | Points destroyed in combat | 207.3 | 658.0 |
| Combat | Points run down | 0.0 | 11.3 |
| Combat | Net points per charged fight, damage counted | -13 | +102 |
| Combat | Net per 100 charger points, damage counted | -7.5 | +43.6 |
| Combat | First round won (charged fights) | 86% | 82% |
| Combat | Net points per charged fight | -52 | +109 |
| Combat | Net points per supported fight / lone fight | +0 / -58 | +130 / +104 |
| Combat | Charged fights on a top-3 enemy unit | 1 of 9 | 6 of 11 |
| Game | Points lost | 969.7 | 442.7 |
| Game | VP from objectives | 703.3 | 846.7 |
| Game | Lone holders (player turns) | 1.7 | 4.7 |

- Mine won / drew / lost: 1 / 0 / 2 of 3 ended games (of 3); mean margin (Mine - Opponent) -668 VP
- The side that went first won 2 of 3 games with a winner
- Points traded per game (both sides' losses): 1412
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: cnomg-c940641-p46

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | - | - | - | - | 0.3 | +6.4 | 0.0 | 0.0 |
| AFTERMATH WITH FRIENDS | - | - | - | - | 0.3 | +140.0 | 0.0 | 0.0 |
| ARMY TABLE | 36.7 | +531.2 | 0.0 | 336.7 | 20.3 | +509.4 | 0.0 | 326.0 |
| ASSAILMENT BY POINTS | 0.3 | +0.4 | 0.0 | 0.0 | 1.0 | +14.6 | 0.0 | 0.0 |
| CAST JOB | - | - | - | - | 2.7 | +14.0 | 100.7 | 0.0 |
| CASTER AWAY FROM SCREEN | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CASTS FROM BEHIND | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | 0.3 | +16.3 | 0.0 | 0.0 | 0.7 | +16.6 | 0.0 | 0.0 |
| CHAFF PASSED | 1.3 | -13.0 | 0.0 | 0.0 | - | - | - | - |
| CHALLENGE BY POINTS | 0.3 | +10.2 | 0.0 | 0.0 | 1.0 | +34.9 | 0.0 | 33.3 |
| CHARGE LOSSES | 6.7 | -417.1 | 0.0 | 485.7 | 12.3 | -451.2 | 0.0 | 288.7 |
| CHARGE NOW FIRST | 1.3 | +0.0 | 77.0 | 11.3 | 1.7 | +0.0 | 261.3 | 77.0 |
| CLOSES ON WHAT IT BEATS | 9.0 | +0.0 | 0.0 | 0.0 | 17.7 | +0.0 | 0.0 | 55.7 |
| COMBAT PIVOT | 0.3 | +0.0 | 0.0 | 116.7 | 0.3 | +0.0 | 0.0 | 0.0 |
| CONTINUE AHEAD WEIGHED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CONVEYANCE SEARCH | 0.7 | +83.8 | 64.0 | 31.7 | 0.7 | +10.2 | 0.0 | 0.0 |
| COVER ONCE | 7.3 | -274.0 | 0.0 | 0.0 | 3.7 | -174.0 | 0.0 | 62.0 |
| DENIED BY THE FIGHT | 0.3 | -0.2 | 62.0 | 0.0 | - | - | - | - |
| DEPLOY BY FIGURES | 8.0 | -112.9 | 0.0 | 0.0 | 7.0 | +58.5 | 0.0 | 62.0 |
| EDGE GIVE GROUND | - | - | - | - | 0.3 | +33.4 | 70.0 | 0.0 |
| ELIXIR WORTH | 0.3 | +20.6 | 0.0 | 116.7 | - | - | - | - |
| EXACT ROUND | 2.0 | +10.6 | 139.0 | 11.3 | 5.0 | +11.1 | 335.3 | 275.0 |
| FALL BACK GOOD ORDER | 1.0 | +0.0 | 15.0 | 11.3 | 4.7 | +6.2 | 235.7 | 127.0 |
| FALLBACK BY WORTH | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| FALLS SHORT | - | - | - | - | 18.0 | +200.7 | 0.0 | 152.7 |
| FEATURE BUFFS | 2.0 | +52.8 | 0.0 | 0.0 | - | - | - | - |
| FIGHT TO THE END | 0.7 | -1.0 | 62.0 | 0.0 | 2.0 | +17.8 | 22.7 | 110.3 |
| FIVE ACTION | 84.3 | +7375.9 | 797.7 | 1251.3 | 90.0 | +7652.9 | 517.3 | 1037.0 |
| FLANK NOT WEIGHED | 8.0 | +0.0 | 0.0 | 213.0 | 3.0 | +0.0 | 0.0 | 184.7 |
| FOLLOW UP WEIGHED | 1.0 | +220.4 | 0.0 | 0.0 | 1.0 | +97.1 | 0.0 | 62.0 |
| FOUR ROUNDS | 2.0 | +65.6 | 139.0 | 11.3 | 6.7 | +328.7 | 416.7 | 291.7 |
| FREED FROM HIS FIGHT | 1.0 | +0.0 | 0.0 | 85.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | - | - | - | - | 0.3 | -3.5 | 0.0 | 0.0 |
| GIVES UP | 0.3 | -0.8 | 0.0 | 0.0 | 0.7 | -16.1 | 11.3 | 0.0 |
| GOAL WALK | 14.3 | +1624.2 | 0.0 | 85.0 | 8.7 | +1227.5 | 0.0 | 0.0 |
| GUN FIGURES | 6.0 | +28.9 | 0.0 | 21.7 | - | - | - | - |
| HARD STAY DROPPED | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HE REFORMS ONCE FREED | 0.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 5.0 | +0.0 | 0.0 | 357.7 | 4.7 | +0.0 | 0.0 | 124.0 |
| HIS CHARGE DENIED | 0.7 | +26.0 | 62.0 | 0.0 | 1.0 | +22.5 | 22.7 | 15.0 |
| HIS CHARGE LIST | 6.3 | +0.0 | 0.0 | 156.7 | 0.7 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 3.0 | +0.0 | 0.0 | 0.0 | 6.3 | +0.0 | 0.0 | 55.0 |
| HIS MOVE AND SHOT | 1.7 | -0.8 | 0.0 | 0.0 | 4.0 | -95.1 | 0.0 | 164.7 |
| HIS MOVE AS HE DECIDES | - | - | - | - | 42.7 | +12.0 | 1174.7 | 0.0 |
| HIS ONE MOVE | - | - | - | - | 29.0 | -85.5 | 0.0 | 263.0 |
| HIS ONE QUARTER | 3.3 | +0.0 | 0.0 | 0.0 | 9.0 | +0.0 | 0.0 | 30.0 |
| HIS OWN BEST MOVE | 3.3 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 35.0 |
| HIS RANDOM MOVE | 11.0 | +0.0 | 0.0 | 351.3 | 4.7 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVER COMES | 3.7 | +0.0 | 0.0 | 128.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 9.7 | +111.7 | 0.0 | 341.7 | 43.3 | +1243.2 | 0.0 | 464.3 |
| HIS SHOTS BY HIS RUN | 15.7 | +86.9 | 0.0 | 200.3 | 32.7 | +675.1 | 0.0 | 413.7 |
| HIS TURN DENIED | - | - | - | - | 1.7 | +95.9 | 43.3 | 243.3 |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 22.7 | +0.0 | 0.0 | 363.0 | 11.7 | +0.0 | 0.0 | 40.0 |
| HOLDER ASSIGNMENT | 14.3 | +1377.4 | 0.0 | 220.7 | 8.7 | +921.4 | 0.0 | 20.0 |
| HOLDS AMBUSHERS | 0.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 1.7 | -18.4 | 77.0 | 11.3 | 5.0 | -113.4 | 236.7 | 258.3 |
| IDLE COST | - | - | - | - | 18.3 | -217.6 | 0.0 | 55.0 |
| JOINT CHARGE NOW | 0.7 | +40.2 | 124.0 | 0.0 | 1.3 | +358.5 | 22.7 | 16.7 |
| KEPT FROM ITS LAST STOP | 4.3 | +0.0 | 0.0 | 156.7 | 1.7 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 0.3 | +9.3 | 0.0 | 0.0 | 1.3 | +47.7 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| LEGAL CHARGES ONLY | 3.0 | +0.0 | 95.3 | 116.7 | 4.0 | +0.0 | 403.3 | 324.7 |
| LONE WIZARD KEPT IN | 0.3 | +7.9 | 0.0 | 0.0 | - | - | - | - |
| LONG SHOT | 1.7 | -25.2 | 139.0 | 0.0 | 0.3 | +0.6 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | 0.7 | -0.6 | 62.0 | 0.0 | 3.0 | +3.1 | 170.7 | 110.3 |
| MANOEUVRE | 3.3 | +15.6 | 0.0 | 75.3 | 1.7 | +1.7 | 0.0 | 20.0 |
| MARCH AT ESCAPER | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MARCH BY THE SUM | 0.3 | +13.0 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 1.3 | +175.4 | 0.0 | 180.0 | - | - | - | - |
| MARCH WHEELS ONLY | 2.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 0.7 | +12.0 | 0.0 | 0.0 | 4.0 | +104.9 | 0.0 | 45.0 |
| MEETS IN TIME | 5.0 | +381.2 | 0.0 | 0.0 | 3.3 | +411.4 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 1.0 | +25.3 | 0.0 | 0.0 | 2.7 | +10.0 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 2.3 | +115.6 | 0.0 | 180.0 | 2.7 | +5.0 | 0.0 | 0.0 |
| MISSILES ON ONE TARGET | 1.0 | -127.6 | 0.0 | 0.0 | - | - | - | - |
| MOVE ORDER | 2.0 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 20.0 | 0.0 |
| MOVE SPELL OUT OF RANGE | 0.3 | -2.2 | 0.0 | 31.7 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 3.0 | +160.4 | 0.0 | 0.0 | 11.3 | +1609.0 | 0.0 | 139.0 |
| MOVES UNITS SPELL | 0.3 | +1.4 | 0.0 | 0.0 | - | - | - | - |
| NEARER NOT NEEDED | 8.3 | +435.9 | 0.0 | 142.3 | 4.7 | +186.9 | 0.0 | 60.7 |
| NEXT CHARGE BY LIST | 2.7 | +143.7 | 0.0 | 0.0 | 6.7 | +1126.8 | 0.0 | 15.0 |
| NEXT OBJECTIVE NEARER | - | - | - | - | 0.3 | -10.0 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 1.0 | -59.2 | 62.0 | 11.3 | 4.7 | -261.8 | 416.7 | 258.3 |
| NO LATE CUT | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NO RALLY LEFT | 0.3 | +1.7 | 0.0 | 0.0 | - | - | - | - |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 0.3 | -0.2 | 0.0 | 0.0 | 2.0 | -0.6 | 0.0 | 0.0 |
| OFF BEST | 4.3 | -101.0 | 0.0 | 0.0 | 5.3 | -130.0 | 0.0 | 62.0 |
| ONE CHECK AFTER THE LAST CHANGE | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ONE FIGHT FORMULA | 2.7 | -15.9 | 0.0 | 0.0 | 6.3 | -204.1 | 0.0 | 77.0 |
| ONE JOINT FIGURE | 0.7 | +34.5 | 62.0 | 0.0 | 0.7 | -34.7 | 0.0 | 0.0 |
| ONE OBJECTIVE FORMULA | 4.3 | +62.2 | 0.0 | 64.0 | 3.0 | -83.5 | 0.0 | 20.0 |
| ONE PROMISE A TARGET | 0.7 | -32.5 | 0.0 | 0.0 | - | - | - | - |
| ONE ROUTE | 2.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| OPENS A LANE | 0.3 | +0.7 | 0.0 | 0.0 | - | - | - | - |
| OPENS UP | - | - | - | - | 0.7 | +17.6 | 21.7 | 164.7 |
| OVERRUNS AWAY | - | - | - | - | 3.3 | +47.5 | 324.0 | 196.3 |
| PATHS CROSS | - | - | - | - | 1.0 | +29.3 | 0.0 | 20.0 |
| PIVOT GUARDS FLANK | 0.3 | -1.2 | 0.0 | 0.0 | - | - | - | - |
| PLAN RESULT | 40.7 | +532.6 | 618.0 | 1487.7 | 45.7 | +399.1 | 104.3 | 741.3 |
| PROMISE BELOW ZERO | - | - | - | - | 0.7 | +0.0 | 0.0 | 164.7 |
| PROMISE BY ITS OWN SUM | 4.0 | -38.7 | 0.0 | 0.0 | 12.0 | -356.4 | 0.0 | 15.0 |
| QUARTER ODDS | 19.3 | +2078.8 | 329.3 | 234.3 | 27.3 | +3351.3 | 177.7 | 376.0 |
| RANDOM MOVE BY FIGURES | 2.0 | +214.2 | 0.0 | 210.0 | 2.0 | +30.3 | 0.0 | 0.0 |
| REAL GROUND | 2.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| REDIRECT BY WHAT IT STOPS | - | - | - | - | 0.3 | +12.4 | 0.0 | 0.0 |
| REDIRECT COUNTER | 2.7 | +40.4 | 0.0 | 0.0 | 2.7 | +247.5 | 0.0 | 50.0 |
| REDIRECT FOR A FRIEND IN REACH | 3.7 | +0.0 | 0.0 | 22.7 | 2.7 | +15.7 | 0.0 | 80.0 |
| REDIRECT WEIGHED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| REFORMS TO MEET IT | 2.0 | -38.6 | 0.0 | 0.0 | 2.7 | -56.5 | 0.0 | 15.0 |
| REFUSING RETIRES | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | - | - | - | - | 0.3 | +0.3 | 0.0 | 0.0 |
| RESTRAINS TO SHOOT | 0.3 | +4.7 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | 2.0 | +108.3 | 139.0 | 11.3 | 6.0 | -116.8 | 405.3 | 275.0 |
| RISK ON THE WAY | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ROUNDS AFTER TERROR | - | - | - | - | 2.7 | -30.9 | 44.3 | 260.0 |
| RUN DOWN | - | - | - | - | 3.3 | -17.6 | 145.0 | 93.7 |
| SCOUT SPOT | 0.7 | +1.8 | 0.0 | 0.0 | - | - | - | - |
| SCOUT WAITS | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 0.7 | -68.4 | 0.0 | 0.0 |
| SEARCH SPOT | 1.0 | +22.2 | 0.0 | 0.0 | 0.7 | +15.2 | 0.0 | 0.0 |
| SECOND LOOK | - | - | - | - | 0.3 | +4.2 | 11.3 | 0.0 |
| SELF MOVE SPELL | 2.0 | -3.8 | 0.0 | 0.0 | - | - | - | - |
| SET CREDITED ONCE | - | - | - | - | 2.0 | -82.2 | 0.0 | 15.0 |
| SET UP BY THE SET | 0.7 | +45.2 | 0.0 | 0.0 | 3.3 | +130.9 | 0.0 | 35.0 |
| SHOOTERS ON THE TABLE | 4.0 | +0.0 | 0.0 | 180.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 4.3 | +215.7 | 658.7 | 180.0 | - | - | - | - |
| SHOT OR CHARGE | 0.3 | -8.6 | 0.0 | 11.3 | 0.3 | -0.1 | 0.0 | 16.7 |
| SHOT RISK POINTS | 7.3 | -7.9 | 0.0 | 170.7 | 26.7 | -36.6 | 0.0 | 523.3 |
| SHOTS AFTER THE MOVES | 2.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SHOTS IN THE MOVE | 13.3 | +504.3 | 0.0 | 99.7 | 0.3 | +2.4 | 0.0 | 0.0 |
| SPELL WORTH | 0.7 | +15.7 | 180.0 | 180.0 | 1.3 | +14.7 | 40.0 | 40.0 |
| SPELLS IN THE FIGHT | 0.3 | +2.7 | 62.0 | 0.0 | 0.3 | +1.4 | 78.0 | 0.0 |
| SPOT AS THE GAME MOVES | 11.0 | +0.0 | 0.0 | 350.0 | 12.3 | +0.0 | 0.0 | 62.0 |
| STAND AND SHOOT | - | - | - | - | 1.7 | -31.5 | 121.3 | 164.7 |
| STANDS STILL | 22.0 | +0.0 | 658.7 | 342.7 | 23.0 | +0.0 | 100.7 | 70.0 |
| STAY WORTH | 10.3 | +88.5 | 0.0 | 0.0 | 2.0 | +11.4 | 22.7 | 0.0 |
| STRIKE BY THE ODDS | - | - | - | - | 0.3 | +0.5 | 0.0 | 62.0 |
| STUPIDITY NEXT TURN | - | - | - | - | 2.3 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 15.7 | +594.8 | 0.0 | 128.0 | 8.3 | +305.0 | 0.0 | 0.0 |
| SUPPORT NARROWED | - | - | - | - | 1.0 | +0.0 | 11.3 | 15.0 |
| SUPPORT WORKED OUT | 15.7 | +594.8 | 0.0 | 128.0 | 8.3 | +305.0 | 0.0 | 0.0 |
| SURE REACH TOGETHER | - | - | - | - | 0.7 | +1.7 | 0.0 | 0.0 |
| SWIFTSTRIDE BY POINTS | 0.3 | +0.1 | 0.0 | 0.0 | - | - | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 2.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 20.0 |
| THE PROMISED MOVE | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE ROW IN ITS ORDER | 6.0 | +0.0 | 0.0 | 180.0 | 4.0 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 5.3 | +0.0 | 0.0 | 78.0 | 5.0 | +0.0 | 0.0 | 40.7 |
| THE STEP BACK IS MADE | 3.3 | +0.0 | 0.0 | 78.0 | 3.7 | +0.0 | 0.0 | 40.7 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 37.0 | +0.0 | 0.0 | 433.3 | 43.3 | +0.0 | 0.0 | 372.3 |
| TIED UP BY THE SUM | 0.7 | +9.9 | 0.0 | 11.3 | 1.3 | +150.9 | 103.0 | 164.7 |
| TIME ON OUR SIDE | 33.3 | +362.9 | 0.0 | 278.0 | - | - | - | - |
| WAITS AGAIN | 2.0 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 15.0 |
| WAR ENGINE JOBS | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WHAT THE JOINER ADDS | - | - | - | - | 1.3 | -82.1 | 0.0 | 16.7 |
| WHO FIGHTS | 0.3 | -1.2 | 62.0 | 0.0 | 1.0 | +11.3 | 11.3 | 62.0 |
| WHO HITS BACK | 0.7 | +118.1 | 0.0 | 70.0 | - | - | - | - |
| WHOLE FIGHT | - | - | - | - | 1.0 | +40.1 | 0.0 | 16.7 |
| WHOLE FIGHT DANGER | 4.3 | -334.9 | 0.0 | 407.7 | 0.7 | -17.9 | 0.0 | 0.0 |
| WHOLE FIGHT GAIN | 0.3 | +4.2 | 62.0 | 0.0 | - | - | - | - |
| WOUNDS ON THE RANKS | - | - | - | - | 3.3 | +40.9 | 0.0 | 0.0 |

### Rule changes: cnomg-c940641-p46

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 171 | 171 | 100 | 33.33 | +3135 | +31.4 |
| HIS MOVE AS HE DECIDES | 128 | 128 | 92 | 30.67 | +0 | +0.0 |
| HOLDER ASSIGNMENT | 69 | 69 | 63 | 21.00 | +4401 | +69.9 |
| OFF BEST | 29 | 29 | 29 | 9.67 | -693 | -23.9 |
| THE TABLE AGAIN | 36 | 36 | 29 | 9.67 | +0 | +0.0 |
| HIS SHOT LIST | 159 | 152 | 28 | 9.33 | +232 | +8.3 |
| DEPLOY BY FIGURES | 45 | 45 | 26 | 8.67 | +294 | +11.3 |
| SUPPORT ADDS | 72 | 71 | 24 | 8.00 | +499 | +20.8 |
| SUPPORT WORKED OUT | 72 | 71 | 24 | 8.00 | +499 | +20.8 |
| HIS SHOTS BY HIS RUN | 145 | 137 | 23 | 7.67 | +150 | +6.5 |
| LEGAL CHARGES ONLY | 21 | 21 | 21 | 7.00 | +0 | +0.0 |
| QUARTER ODDS | 140 | 132 | 19 | 6.33 | +1363 | +71.7 |
| FIVE ACTION | 523 | 507 | 18 | 6.00 | +407 | +22.6 |
| HIS ONE MOVE | 87 | 85 | 18 | 6.00 | +0 | +0.0 |
| MOVE TO CHARGE COMPUTED | 43 | 40 | 18 | 6.00 | +1214 | +67.5 |
| REDIRECT FOR A FRIEND IN REACH | 19 | 19 | 18 | 6.00 | +0 | +0.0 |
| GOAL WALK | 69 | 69 | 17 | 5.67 | +1653 | +97.2 |
| PROMISE BY ITS OWN SUM | 48 | 48 | 16 | 5.33 | -1185 | -74.1 |
| MOVE ORDER | 15 | 15 | 15 | 5.00 | +0 | +0.0 |
| SHOOTS FROM THE BEST SPOT | 13 | 13 | 13 | 4.33 | +204 | +15.7 |
| IDLE COST | 55 | 38 | 11 | 3.67 | +49 | +4.5 |
| FOUR ROUNDS | 26 | 26 | 9 | 3.00 | +567 | +63.0 |
| MAX FOR POSITIONING | 14 | 14 | 9 | 3.00 | +116 | +12.9 |
| NEXT CHARGE BY LIST | 28 | 27 | 9 | 3.00 | +752 | +83.5 |
| SHOT RISK POINTS | 102 | 92 | 9 | 3.00 | +136 | +15.1 |
| RANDOM MOVE BY FIGURES | 12 | 12 | 8 | 2.67 | +733 | +91.7 |
| TIME ON OUR SIDE | 100 | 83 | 8 | 2.67 | +40 | +5.0 |
| MEETS IN TIME | 25 | 25 | 7 | 2.33 | +441 | +63.0 |
| SHOTS IN THE MOVE | 41 | 29 | 7 | 2.33 | +185 | +26.4 |
| FOLLOW UP WEIGHED | 6 | 6 | 6 | 2.00 | +953 | +158.8 |
| JOINT CHARGE NOW | 6 | 6 | 6 | 2.00 | +1196 | +199.3 |
| SET UP BY THE SET | 12 | 12 | 6 | 2.00 | +210 | +35.0 |
| COVER ONCE | 33 | 18 | 5 | 1.67 | +43 | +8.6 |
| LANE BY FIGURES | 5 | 5 | 5 | 1.67 | +171 | +34.2 |
| RISK BY ARC | 24 | 24 | 5 | 1.67 | +137 | +27.5 |
| STAY WORTH | 37 | 32 | 5 | 1.67 | +35 | +7.0 |
| THE ROW IN ITS ORDER | 30 | 5 | 5 | 1.67 | +0 | +0.0 |
| TIED UP BY THE SUM | 6 | 6 | 5 | 1.67 | +183 | +36.6 |
| ADVANCE LANE KEPT | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| ASSAILMENT BY POINTS | 4 | 4 | 4 | 1.33 | +45 | +11.2 |
| CAST JOB | 8 | 8 | 4 | 1.33 | +1 | +0.3 |
| CASTS FROM BEHIND | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| CHAFF PASSED | 4 | 4 | 4 | 1.33 | -39 | -9.7 |
| CHALLENGE BY POINTS | 4 | 4 | 4 | 1.33 | +136 | +33.9 |
| CHARGE LOSSES | 57 | 51 | 4 | 1.33 | +254 | +63.6 |
| HIS CHARGE DENIED | 5 | 5 | 4 | 1.33 | +82 | +20.5 |
| HOLDS AMBUSHERS | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| WHOLE FIGHT DANGER | 15 | 15 | 4 | 1.33 | +380 | +95.1 |
| CHARGE NOW FIRST | 9 | 9 | 3 | 1.00 | -80 | -26.5 |
| MANOEUVRE | 15 | 15 | 3 | 1.00 | +52 | +17.3 |
| NEARER NOT NEEDED | 39 | 37 | 3 | 1.00 | +82 | +27.3 |
| PATHS CROSS | 3 | 3 | 3 | 1.00 | +88 | +29.3 |
| REDIRECT COUNTER | 16 | 9 | 3 | 1.00 | +72 | +23.9 |
| SCOUT WAITS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| SEARCH SPOT | 5 | 5 | 3 | 1.00 | +112 | +37.4 |
| CASTER AWAY FROM SCREEN | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| CHAFF IN THE MOVE | 3 | 2 | 2 | 0.67 | +0 | +0.0 |
| COMBAT PIVOT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| HARD STAY DROPPED | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| ONE PROMISE A TARGET | 2 | 2 | 2 | 0.67 | -98 | -48.8 |
| OVERRUNS AWAY | 10 | 10 | 2 | 0.67 | +19 | +9.6 |
| WAR ENGINE JOBS | 5 | 5 | 2 | 0.67 | -35 | -17.4 |
| WHO HITS BACK | 2 | 2 | 2 | 0.67 | +227 | +113.3 |
| AFTERMATH IN POINTS | 1 | 1 | 1 | 0.33 | +19 | +19.3 |
| AFTERMATH WITH FRIENDS | 1 | 1 | 1 | 0.33 | +420 | +420.1 |
| CONTINUE AHEAD WEIGHED | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| EDGE GIVE GROUND | 1 | 1 | 1 | 0.33 | +24 | +24.0 |
| ELIXIR WORTH | 1 | 1 | 1 | 0.33 | +62 | +61.7 |
| EXACT ROUND | 21 | 21 | 1 | 0.33 | +4 | +4.0 |
| FALLS SHORT | 54 | 42 | 1 | 0.33 | +0 | +0.0 |
| HIS TURN DENIED | 5 | 5 | 1 | 0.33 | +107 | +107.2 |
| LONE WIZARD KEPT IN | 1 | 1 | 1 | 0.33 | +24 | +23.8 |
| MARCH BY THE SUM | 1 | 1 | 1 | 0.33 | +39 | +39.0 |
| MOVES UNITS SPELL | 1 | 1 | 1 | 0.33 | +4 | +4.3 |
| NO DOUBLE ROUNDS | 17 | 17 | 1 | 0.33 | +4 | +4.0 |
| NO RALLY LEFT | 1 | 1 | 1 | 0.33 | +1 | +0.9 |
| ONE JOINT FIGURE | 4 | 4 | 1 | 0.33 | +60 | +60.0 |
| ONE OBJECTIVE FORMULA | 22 | 15 | 1 | 0.33 | +37 | +36.8 |
| OPENS UP | 2 | 2 | 1 | 0.33 | +4 | +4.0 |
| PIVOT GUARDS FLANK | 1 | 1 | 1 | 0.33 | -4 | -3.7 |
| REDIRECT WEIGHED | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| REFORMS TO MEET IT | 14 | 13 | 1 | 0.33 | +0 | +0.0 |
| RESERVE FALL BACK | 1 | 1 | 1 | 0.33 | +1 | +1.1 |
| RESTRAINS TO SHOOT | 1 | 1 | 1 | 0.33 | +14 | +14.1 |
| SECOND LOOK | 1 | 1 | 1 | 0.33 | +13 | +12.6 |
| STRIKE BY THE ODDS | 1 | 1 | 1 | 0.33 | +1 | +1.4 |
| SUPPORT NARROWED | 3 | 3 | 1 | 0.33 | -16 | -15.5 |
| SURE REACH TOGETHER | 2 | 2 | 1 | 0.33 | +0 | +0.0 |
| SWIFTSTRIDE BY POINTS | 1 | 1 | 1 | 0.33 | +0 | +0.3 |
| WHOLE FIGHT | 3 | 3 | 1 | 0.33 | +44 | +43.7 |
| WOUNDS ON THE RANKS | 10 | 8 | 1 | 0.33 | +21 | +20.8 |
| CLOSES ON WHAT IT BEATS | 80 | 80 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 4 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 17 | 17 | 0 | 0.00 | - | - |
| FALLBACK BY WORTH | 1 | 1 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 6 | 6 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 8 | 8 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 33 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 12 | 12 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 1 | 1 | 0 | 0.00 | - | - |
| GIVES UP | 3 | 3 | 0 | 0.00 | - | - |
| GUN FIGURES | 18 | not checked | - | - | - | - |
| HE REFORMS ONCE FREED | 4 | 4 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 29 | 24 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 21 | 21 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 28 | 25 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 17 | 17 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 37 | 37 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 19 | 18 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 47 | 47 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 15 | 15 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN RUN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 103 | 102 | 0 | 0.00 | - | - |
| HONEST WORTH | 20 | 20 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 18 | 17 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 1 | 1 | 0 | 0.00 | - | - |
| LONG SHOT | 6 | 6 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 11 | 11 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 4 | 4 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 10 | 9 | 0 | 0.00 | - | - |
| MISSILES IN THE MOVE | 11 | 6 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 15 | 11 | 0 | 0.00 | - | - |
| MISSILES ON ONE TARGET | 3 | not checked | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 1 | trace | - | - | - | - |
| NEXT OBJECTIVE NEARER | 1 | 1 | 0 | 0.00 | - | - |
| NO LATE CUT | 4 | 4 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 18 | 18 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 7 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 2 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 27 | 12 | 0 | 0.00 | - | - |
| ONE ROUTE | 10 | 9 | 0 | 0.00 | - | - |
| OPENS A LANE | 1 | 1 | 0 | 0.00 | - | - |
| PLAN RESULT | 259 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 2 | 2 | 0 | 0.00 | - | - |
| REAL GROUND | 10 | 9 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 1 | 1 | 0 | 0.00 | - | - |
| REFUSING RETIRES | 4 | 4 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 4 | 3 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 8 | 8 | 0 | 0.00 | - | - |
| RUN DOWN | 10 | 10 | 0 | 0.00 | - | - |
| SCOUT SPOT | 2 | 2 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 2 | 2 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 6 | not checked | - | - | - | - |
| SET CREDITED ONCE | 6 | 6 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 18 | not checked | - | - | - | - |
| SHOT OR CHARGE | 2 | 2 | 0 | 0.00 | - | - |
| SHOTS AFTER THE MOVES | 8 | 8 | 0 | 0.00 | - | - |
| SPELL WORTH | 6 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 70 | 62 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 5 | 5 | 0 | 0.00 | - | - |
| STANDS STILL | 135 | 127 | 0 | 0.00 | - | - |
| STUPIDITY NEXT TURN | 7 | 7 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 12 | not checked | - | - | - | - |
| THE PROMISED MOVE | 2 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 31 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 21 | not checked | - | - | - | - |
| THE TABLE BINDS | 241 | not checked | - | - | - | - |
| WAITS AGAIN | 13 | 12 | 0 | 0.00 | - | - |
| WHAT THE JOINER ADDS | 4 | 4 | 0 | 0.00 | - | - |
| WHO FIGHTS | 4 | 4 | 0 | 0.00 | - | - |
| WHOLE FIGHT GAIN | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: cnomg-c940641-p46

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| ARMY TABLE | rule | 5.67 | 2.00 | 52.7 |
| JOB FIRST | gate | 3.67 | 3.67 | 22.0 |
| PROMISE BY ITS OWN SUM | rule | 1.00 | 4.33 | 74.1 |
| HOLDER ASSIGNMENT | rule | 1.33 | 0.33 | 27.3 |
| CHAFF PASSED | rule | 1.33 | - | 9.7 |
| RULE SWITCHED OFF | gate | - | 1.33 | 37.4 |
| CHARGE NOW FIRST | rule | 0.33 | 0.67 | 26.5 |
| NO REASON | gate | 0.67 | - | 28.0 |
| ONE PROMISE A TARGET | rule | 0.67 | - | 48.8 |
| WAR ENGINE JOBS | rule | 0.67 | - | 17.4 |
| AFTERMATH BAND | gate | - | 0.33 | 2.4 |
| FOLLOW UP WEIGHED | rule | - | 0.33 | 2.4 |
| PIVOT GUARDS FLANK | rule | 0.33 | - | 3.7 |
| SET UP BY THE SET | rule | - | 0.33 | 12.4 |
| SUPPORT NARROWED | rule | - | 0.33 | 15.5 |

### Plans: cnomg-c940641-p46

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 2.0 | 33% | 99 | 125 | 126% |
| Mine | move | 35.7 | 90% | 2775 | 0 | 0% |
| Mine | shoot | 3.0 | 44% | 291 | 408 | 140% |
| Opponent | charge | 5.3 | 44% | 819 | 374 | 46% |
| Opponent | join | 3.0 | 89% | 100 | 0 | 0% |
| Opponent | move | 35.7 | 95% | 2605 | 0 | 0% |
| Opponent | shoot | 1.0 | 67% | 185 | 25 | 14% |
| Opponent | support | 0.7 | 100% | 16 | 0 | 0% |

### Battle groups: cnomg-c940641-p46

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 2.7 | 12% | 100% | 100% | 0% | - | - | - | - | - |
| Opponent | REDIRECT COUNTER | 2.7 | 50% | 100% | 75% | 0% | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: cnomg-c940641-p46

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Mine | Chaff | 7 | 148 (7) | 32 | 116 | 20 | 29% | 4.4 | 137 (6) | 230 (1) | - | 137 (6) | 230 (1) |
| Mine | Character | 7 | 15 (7) | 15 | 0 | 81 | 14% | 1.3 | 0 (1) | 16 (2) | 0 (1) | 0 (1) | 9 (3) |
| Mine | Clean-up | 2 | 13 (2) | 0 | 13 | 0 | 100% | - | 13 (2) | - | - | 0 (1) | 15 (1) |
| Mine | Fast Hammer | 1 | 0 (1) | 0 | 0 | 0 | 0% | 1.0 | - | 0 (1) | - | 0 (1) | - |
| Mine | Hammer | 10 | 33 (10) | 14 | 18 | 57 | 20% | 1.9 | 0 (2) | 59 (5) | 10 (3) | 36 (4) | 31 (6) |
| Mine | Holder | 3 | 36 (3) | 0 | 36 | 54 | 33% | 3.5 | 0 (1) | 66 (2) | - | 36 (3) | - |
| Mine | Shooter | 3 | 0 (3) | 0 | 0 | 33 | 0% | 1.3 | 0 (1) | 0 (2) | - | 0 (2) | 0 (1) |
| Mine | Wizard | 3 | 0 (3) | 0 | 0 | 20 | 0% | 2.0 | - | 0 (2) | - | 0 (2) | - |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Chaff | 9 | 29 (9) | 0 | 29 | 35 | 56% | 2.8 | 0 (4) | 167 (2) | 0 (3) | 83 (4) | 0 (5) |
| Opponent | Character | 10 | 73 (10) | 73 | 0 | 26 | 20% | 3.6 | 50 (4) | 51 (5) | 152 (1) | 115 (5) | 25 (5) |
| Opponent | Clean-up | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Fast Hammer | 8 | 28 (8) | 19 | 9 | 19 | 12% | 2.7 | 21 (2) | 37 (4) | 17 (2) | 36 (5) | 16 (3) |
| Opponent | Hammer | 2 | 131 (2) | 58 | 73 | 0 | 50% | 3.0 | - | 131 (2) | - | 169 (1) | 111 (1) |
| Opponent | Holder | 1 | 0 (1) | 0 | 0 | 0 | 0% | 6.0 | - | 0 (1) | - | 0 (1) | - |
| Opponent | Support | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Wizard | 4 | 7 (4) | 7 | 0 | 12 | 25% | 1.3 | 0 (1) | 0 (1) | 9 (2) | - | 7 (4) |

### Charged fights: cnomg-c940641-p46

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Ogre Kingdoms | 1 | 60 | 45 | 4.0 | 1.2 | 11 | 8 | +3 | 0 of 4 | 2 of 2 | +0 | +4 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 231 | 5.0 | 1.0 | 46 | 142 | -96 | 1 of 5 | 4 of 5 | - | -96 |
| Mine | Skaven | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| **Mine** | all armies | 3 | 20 | 92 | 3.0 | 1.1 | 31 | 83 | -52 | 1 of 9 | 6 of 7 | +0 | -58 |
| Opponent | Vampire Counts | 2 | 17 | 365 | 4.0 | 1.2 | 91 | 43 | +48 | 4 of 8 | 6 of 8 | +130 | +20 |
| Opponent | Warriors of Chaos | 1 | 0 | 815 | 3.0 | 1.0 | 272 | 0 | +272 | 2 of 3 | 3 of 3 | - | +272 |
| **Opponent** | all armies | 3 | 11 | 515 | 3.7 | 1.2 | 140 | 31 | +109 | 6 of 11 | 9 of 11 | +130 | +104 |

### Effective charges: cnomg-c940641-p46

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Ogre Kingdoms | 4 | 0 | 0 | 0 | 0 | 1 (net +45) | 3 (net -11) | 0 | 0% (0 of 4) |
| Opponent | Vampire Counts | 8 | 1 (net -110) | 0 | 2 (net +38) | 1 (net +0) | 0 | 3 (net +156) | 1 | 29% (2 of 7) |
| Opponent | Warriors of Chaos | 3 | 0 | 0 | 0 | 0 | 1 (net +65) | 2 (net +375) | 0 | 0% (0 of 3) |

### Charged fights, damage counted: cnomg-c940641-p46

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 | 135 | 112 | -11 | 0 | 14 | -14 | -10.5 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 251 | 45 | +45 | 45 | 0 | +45 | +17.9 |
| Mine | No odds | 5 | 173 | 188 | -96 | 132 | 155 | -23 | -13.5 |
| Mine | All fights | 9 | 169 | 147 | -52 | 78 | 91 | -13 | -7.5 |
| Opponent | Long shot (under 50%) | 1 | 50 | 251 | -110 | 42 | 110 | -68 | -136.3 |
| Opponent | Effective (55-75%) | 2 | 245 | 192 | +38 | 132 | 93 | +38 | +15.7 |
| Opponent | 76-89% | 1 | 231 | 34 | +0 | 17 | 0 | +17 | +7.4 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 5 | 311 | 256 | +244 | 260 | 39 | +220 | +70.9 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 205 | 65 | +65 | 65 | 17 | +48 | +23.4 |
| Opponent | No odds | 1 | 50 | 297 | -50 | 0 | 50 | -50 | -100.0 |
| Opponent | All fights | 11 | 235 | 210 | +109 | 153 | 51 | +102 | +43.6 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| cnomg-c940641-p46 | move | 18 | 1 (6%) | 1 (6%) | 3 (17%) | 14 (78%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L1827, L1927 |
| Elixir of Power | Mine | L1927 |
| Fistful of Laurels | Mine | L1827 |
| Invocation of Nehek | Opponent | L1827, L1927 |
| Periapt of Soul Exchange | Mine | L2029 |

# Doctrine scorecard: cnomg-c940641-p33

### Scorecard: cnomg-c940641-p33

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L1527 | 3 | 1 | Mine | no | 6 | 3 | 4 | 0 | 0 | 0 | 0 | 0 |
| L1527 | 3 | 1 | Opponent | no | 4 | 2 | 4 | 3 | 0 | 0 | 0 | 0 |
| L1625 | 5 | 1 | Mine | no | - | 3 | 1 | 2 | 0 | 0 | 0 | 100 |
| L1625 | 5 | 1 | Opponent | no | - | - | 4 | 3 | 0 | 0 | 0 | 0 |
| L1723 | 1 | 1 | Mine | no | 0 | 2 | 5 | 0 | 1 | 0 | 0 | 83 |
| L1723 | 1 | 1 | Opponent | yes | 2 | 2 | 4 | 1 | 1 | 0 | 0 | 72 |
| **Average** | | | Mine | 0% | 3.0 | 2.7 | 3.3 | 0.7 | 0.3 | 0.0 | 0.0 | 61.0 |
| **Average** | | | Opponent | 33% | 3.0 | 2.0 | 4.0 | 2.3 | 0.3 | 0.0 | 0.0 | 24.0 |

### KPIs: cnomg-c940641-p33

Rules off - Opponent only: NO OLD ONE-MOVE GUESS.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 16) | 0% (0 of 16) | 0% (0 of 32) |
| Winner chose to follow up after the loser gave ground |  | 67% (4 of 6); on the table 67% | 67% (2 of 3); on the table 100% | 67% (6 of 9); on the table 78% |
| Winner chose to pursue after the loser fell back in good order |  | - | 50% (1 of 2); on the table 50% | 50% (1 of 2); on the table 50% |
| Winner chose to pursue after the loser fled |  | - | 100% (2 of 2); on the table 100% | 100% (2 of 2); on the table 100% |
| Winner chose to follow up or pursue (all three) |  | 67% (4 of 6); on the table 67% | 71% (5 of 7); on the table 86% | 69% (9 of 13); on the table 77% |
| Magic missiles tried each own turn | 50%+ | - | 67% (12 of 18) | 67% (12 of 18) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | - | 75% (12 of 16) | 75% (12 of 16) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | - | - |
| Points that never fought | lower | 28% (1677 of 6000) | 33% (1998 of 5999) | 31% (3675 of 11999) |
|   infantry points that never fought | lower | 77% (1021 of 1332) | 30% (254 of 834) | 59% (1275 of 2166) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 55% (11 of 20) | 53% (9 of 17) | 54% (20 of 37) |
| Bound items with a magic missile used (at least once a game) |  | 100% (2 of 2); 3.0 uses a game | 0.0 uses a game | 100% (2 of 2); 1.5 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 100% (1 of 1); 0.3 uses a game | 0.0 uses a game | 100% (1 of 1); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 47% (2418 of 5135) | 53% (2455 of 4600) | 50% (4873 of 9735) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | - | 1.3 (67%) | 1.3 (67%) |
| OFF THE TABLE: off the table or not arrived | - | 0.7 (33%) | 0.7 (33%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.3 | 2.3 | 0.3 | 4.0 | 0.3 | 2.7 |
| not cast | 5.7 | 1.7 | 1.7 | 2.0 | 1.7 | 25.3 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.0 (4%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.7 (40%) | 0.0 (0%) | 1.3 (67%) | 1.7 (100%) | 0.0 (0%) |
| GONE: slain | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (3%) |
| OFF THE TABLE: off the table or not arrived | 0.7 (12%) | 0.0 (0%) | 0.0 (0%) | 0.7 (33%) | 0.0 (0%) | 2.0 (8%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.7 (40%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (3%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.7 (12%) | 0.3 (20%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 4.3 (76%) | 0.0 (0%) | 1.7 (100%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 21.0 (83%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.3 a game | 0.0 a game | 0.2 a game |
| stood (cast and not dispelled) | - | - | - |
| the unit moved after it | - | - | - |
| it charged on its next turn | - | - | - |
| the enemy charged it first | - | - | - |
| it fought by the end of its next turn | - | - | - |
| it moved out of a charge the enemy had planned (not charged first) | - | - | - |
| none of these (no charge, no fight, no charge escaped) | - | - | - |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 52% (37 of 71) | 60% (24 of 40) | 55% (61 of 111) |
|   cavalry | 67% (6 of 9) | 92% (11 of 12) | 81% (17 of 21) |
|   character | 33% (3 of 9) | 0% (0 of 11) | 15% (3 of 20) |
|   chariot | 57% (4 of 7) | - | 57% (4 of 7) |
|   infantry | 46% (11 of 24) | 76% (13 of 17) | 59% (24 of 41) |
|   monster | 30% (3 of 10) | - | 30% (3 of 10) |
|   war machine | 83% (10 of 12) | - | 83% (10 of 12) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.3 (21%) | 0.0 (0%) | 2.3 (14%) |
| CHARGED: it charged | 1.7 (15%) | 1.0 (19%) | 2.7 (16%) |
| IN COMBAT: it fought this turn or the last | 1.0 (9%) | 0.3 (6%) | 1.3 (8%) |
| MOVED: a war machine that moved | 0.7 (6%) | 0.0 (0%) | 0.7 (4%) |
| NO TARGET IN RANGE | 3.3 (29%) | 1.7 (31%) | 5.0 (30%) |
| ONLY IN COMBAT: the only targets were in combat | 2.0 (18%) | 2.3 (44%) | 4.3 (26%) |
| STUPIDITY | 0.3 (3%) | 0.0 (0%) | 0.3 (2%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 5.7 | 0.7 | 88% | 0.5 pts | 3 pts |
| character | 1.3 | 0.0 | 100% | 0.0 pts | 0 pts |
| chariot | 1.3 | 0.0 | 100% | 0.0 pts | 0 pts |
| infantry | 12.0 | 4.0 | 75% | 8.8 pts | 106 pts |
| monster | 1.0 | 0.0 | 100% | 0.0 pts | 0 pts |
| war machine | 3.3 | 3.0 | 70% | 13.1 pts | 44 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 5.7 | 5.0 | 5.3 |
| Charges that made contact a game | 4.7 | 3.0 | 3.8 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | - | 0.00 declared, 0.00 contact (3 units) | 0.00 declared, 0.00 contact (3 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.33 declared, 0.33 contact (3 units) | 0.50 declared, 0.00 contact (2 units) | 0.40 declared, 0.20 contact (5 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.76 declared, 0.62 contact (21 units) | 0.56 declared, 0.36 contact (25 units) | 0.65 declared, 0.48 contact (46 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 33% (1 of 3) | 100% (2 of 2) | 0% (0 of 2) | 43% (3 of 7) |
| Character in a unit | 50% (1 of 2) | 100% (1 of 1) | - | 67% (2 of 3) |
| Character on its own | 100% (2 of 2) | 0% (0 of 2) | 44% (4 of 9) | 46% (6 of 13) |
| Chariot | 100% (1 of 1) | - | - | 100% (1 of 1) |
| Infantry | 50% (3 of 6) | 100% (2 of 2) | - | 62% (5 of 8) |
| Monster | 60% (3 of 5) | - | - | 60% (3 of 5) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| High Elf Realms | 1 | 33% (1 of 3); on the table 33% | - | 6% | 43% (3 of 7) | 100% (2 of 2); 9.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | - | - | 50% | 50% (3 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Lizardmen | 1 | 100% (3 of 3); on the table 100% | - | 28% | 71% (5 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Tomb Kings of Khemri | 1 | 67% (2 of 3); on the table 67% | - | 14% | 0% (0 of 5) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 2 | 75% (3 of 4); on the table 100% | 67% (12 of 18) | 43% | 75% (9 of 12) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (cnomg-c940641-p33, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 40% (2) | 36% (4) | 38% (6) |
| ...free all their last turn and able to turn (per game) | 0.67 | 1.00 | 1.67 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.33 | 0.33 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: cnomg-c940641-p33

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.3 | 3.3 |
| Strategy | Charge objectives carried out (made contact) | 73% (8 of 11) | 33% (5 of 15) |
| Strategy | Shoot objectives carried out (shot that target) | 11% (2 of 18) | 11% (1 of 9) |
| Strategy | Support requests answered (helper made contact too) | 100% (2 of 2) | 0% (0 of 2) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (1 of 1) | 100% (1 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | - | 0% (0 of 1) |
| Strategy | Joined characters whose unit fought | 0% (0 of 1) | 20% (1 of 5) |
| Strategy | Lone characters that fought | 88% (7 of 8) | 67% (6 of 9) |
| Movement | Charges halted short of contact | 0.0 | 0.3 |
| Movement | Idle units | 0.7 | 2.3 |
| Movement | Points that never moved of their own | 61.0 | 24.0 |
| Movement | Fights charged into per game | 4.0 | 3.0 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 8 | 1 of 8, net +326 |
| Movement | Charges with odds: sweet spot (55-75%) | 1 of 8, net -60 | 1 of 8, net +0 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 3 of 8, net +88 | 1 of 8, net +115 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 of 8, net +220 | 3 of 8, net +121 |
| Shooting | Shots by shooting units (incl. breath weapons) | 10.3 | 8.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 55% (17 of 31) | 20% (5 of 25) |
| Shooting | Points destroyed by shooting units | 15.0 | 58.3 |
| Shooting | War machine shots | 3.3 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 70% (7 of 10) | - |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | - | 3.0 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | - | 56% (5 of 9) |
| Magic | Wounds caused by magic missiles | 1.3 | 1.0 |
| Magic | Points destroyed by magic (all spells) | 0.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.7 / 1.0 / 1.3 / 0.0 | 1.7 / 0.3 / 0.3 / 0.0 |
| Combat | Points destroyed in combat | 408.7 | 286.3 |
| Combat | Points run down | 0.0 | 68.7 |
| Combat | Net points per charged fight, damage counted | +61 | +107 |
| Combat | Net per 100 charger points, damage counted | +15.0 | +43.1 |
| Combat | First round won (charged fights) | 67% | 78% |
| Combat | Net points per charged fight | +76 | +109 |
| Combat | Net points per supported fight / lone fight | +127 / +66 | - / +109 |
| Combat | Charged fights on a top-3 enemy unit | 4 of 12 | 3 of 9 |
| Game | Points lost | 657.7 | 507.0 |
| Game | VP from objectives | 340.0 | 983.3 |
| Game | Lone holders (player turns) | 3.0 | 3.0 |

- Mine won / drew / lost: 0 / 2 / 1 of 3 ended games (of 3); mean margin (Mine - Opponent) -862 VP
- The side that went first won 1 of 1 games with a winner
- Points traded per game (both sides' losses): 1165
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: cnomg-c940641-p33

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| AFTERMATH IN POINTS | 0.3 | +18.0 | 0.0 | 38.3 | 0.3 | +15.3 | 0.0 | 0.0 |
| AFTERMATH WITH FRIENDS | - | - | - | - | 0.7 | +17.7 | 0.0 | 0.0 |
| ARMY TABLE | 15.3 | +61.1 | 0.0 | 160.7 | 22.0 | +670.1 | 0.0 | 55.0 |
| ASSAILMENT BY POINTS | - | - | - | - | 0.7 | +1.9 | 0.0 | 0.0 |
| BACKUP TARGETS | 0.3 | +0.7 | 0.0 | 0.0 | 0.3 | +1.0 | 0.0 | 0.0 |
| CANNON PLANNED TARGET | 3.3 | +8.8 | 15.0 | 0.0 | - | - | - | - |
| CAST JOB | - | - | - | - | 1.0 | +2.9 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CASTS FROM BEHIND | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | - | - | - | - | 3.3 | +132.5 | 0.0 | 0.0 |
| CHAMPION KNOWS CHALLENGE | 0.3 | -9.1 | 20.0 | 0.0 | - | - | - | - |
| CHARGE LIST READ AGAIN | - | - | - | - | 0.3 | +15.7 | 24.0 | 0.0 |
| CHARGE LOSSES | 16.3 | -511.0 | 0.0 | 309.0 | 14.0 | -519.6 | 0.0 | 316.0 |
| CHARGE NOT DECLARED | - | - | - | - | 0.3 | +0.0 | 26.7 | 0.0 |
| CHARGE NOW FIRST | 1.7 | +0.0 | 107.0 | 20.0 | 2.3 | +0.0 | 250.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 9.3 | +0.0 | 0.0 | 84.0 | 18.7 | +0.0 | 0.0 | 153.3 |
| COMBAT PIVOT | 0.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 92.0 | 0.0 |
| COVER ONCE | 14.7 | -717.7 | 0.0 | 213.3 | 13.3 | -1279.0 | 0.0 | 252.7 |
| DENIED BY THE FIGHT | - | - | - | - | 1.0 | -2.4 | 48.0 | 0.0 |
| DEPLOY BY FIGURES | 7.3 | +4.0 | 0.0 | 0.0 | 7.7 | +7.5 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | 0.3 | +5.7 | 0.0 | 0.0 | 0.3 | -33.1 | 45.0 | 0.0 |
| EDGE GIVE GROUND | 0.3 | +75.7 | 20.0 | 0.0 | 0.3 | +2.7 | 45.0 | 0.0 |
| EXACT ROUND | 2.7 | -3.4 | 195.0 | 58.3 | 4.3 | -17.8 | 276.7 | 0.0 |
| FALL BACK GOOD ORDER | 2.0 | +0.0 | 68.3 | 20.0 | 4.7 | +10.0 | 292.3 | 0.0 |
| FALLS SHORT | - | - | - | - | 23.0 | +292.5 | 0.0 | 289.3 |
| FEATURE BUFFS | 1.7 | +24.2 | 0.0 | 26.7 | 0.3 | +2.5 | 0.0 | 0.0 |
| FIGHT LIFT | 0.7 | +3.0 | 38.3 | 0.0 | - | - | - | - |
| FIGHT TO THE END | 1.3 | +6.8 | 84.7 | 20.0 | 2.7 | +14.3 | 175.3 | 0.0 |
| FIVE ACTION | 73.3 | +4730.3 | 436.7 | 1212.3 | 95.3 | +7226.4 | 792.3 | 896.0 |
| FLANK NOT WEIGHED | 8.0 | +0.0 | 0.0 | 83.3 | 8.3 | +0.0 | 0.0 | 192.7 |
| FOLLOW UP WEIGHED | 0.3 | +67.6 | 0.0 | 0.0 | 1.3 | +67.0 | 0.0 | 0.0 |
| FOUR ROUNDS | 4.7 | +380.1 | 381.7 | 58.3 | 5.7 | +272.8 | 384.0 | 0.0 |
| FREED FROM HIS FIGHT | 7.0 | +0.0 | 0.0 | 261.3 | 4.3 | +0.0 | 0.0 | 0.0 |
| FRIEND CHARGES FIRST | - | - | - | - | 0.3 | -5.1 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 0.7 | -1.4 | 0.0 | 0.0 | 1.3 | -64.2 | 0.0 | 15.0 |
| GIVES UP | 0.3 | -5.0 | 0.0 | 0.0 | 1.7 | -28.3 | 69.0 | 0.0 |
| GOAL WALK | 10.7 | +842.9 | 0.0 | 200.7 | 4.3 | +380.9 | 0.0 | 0.0 |
| GUN MASK | 1.7 | +11.0 | 0.0 | 0.0 | - | - | - | - |
| HARD STAY DROPPED | 1.0 | +0.0 | 0.0 | 66.0 | - | - | - | - |
| HE REFORMS ONCE FREED | 2.3 | +0.0 | 0.0 | 74.7 | 3.3 | +0.0 | 0.0 | 0.0 |
| HELPER UNSEEN | 0.7 | +0.0 | 84.7 | 0.0 | - | - | - | - |
| HIS CHARGE BY HIS RUN | 13.3 | +0.0 | 0.0 | 309.0 | 11.7 | +0.0 | 0.0 | 316.0 |
| HIS CHARGE DENIED | 1.7 | +98.4 | 108.0 | 38.3 | 0.3 | +2.6 | 0.0 | 0.0 |
| HIS CHARGE LIST | 6.3 | +0.0 | 0.0 | 329.7 | 9.3 | +0.0 | 0.0 | 15.0 |
| HIS LEGAL MOVES | 7.3 | +0.0 | 0.0 | 87.0 | 9.0 | +0.0 | 0.0 | 46.7 |
| HIS MOVE AND SHOT | 5.0 | -25.9 | 0.0 | 0.0 | 7.0 | -88.6 | 0.0 | 90.0 |
| HIS MOVE AS HE DECIDES | - | - | - | - | 35.7 | +8.0 | 1050.3 | 0.0 |
| HIS MOVE WHY | 10.7 | +0.0 | 0.0 | 100.3 | - | - | - | - |
| HIS ONE MOVE | - | - | - | - | 31.3 | +10.8 | 0.0 | 25.0 |
| HIS ONE QUARTER | 3.3 | +0.0 | 0.0 | 65.0 | 3.7 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 10.3 | +0.0 | 0.0 | 87.0 | 3.0 | +0.0 | 0.0 | 23.3 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 26.3 | +202.7 | 0.0 | 536.3 | 44.7 | +1165.8 | 0.0 | 205.0 |
| HIS SHOTS BY HIS RUN | 19.0 | +71.4 | 0.0 | 675.7 | 39.0 | +466.2 | 0.0 | 296.7 |
| HIS TURN DENIED | 0.7 | +5.2 | 40.0 | 0.0 | 2.7 | +23.8 | 146.3 | 0.0 |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 10.7 | +0.0 | 0.0 | 206.0 | 15.3 | +0.0 | 0.0 | 224.0 |
| HOLDER ASSIGNMENT | 7.0 | +561.0 | 0.0 | 110.7 | 10.0 | +935.5 | 0.0 | 142.0 |
| HOLDS AMBUSHERS | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 4.3 | -260.6 | 381.7 | 20.0 | 5.7 | -137.4 | 384.0 | 0.0 |
| HUNT IN PAIRS | - | - | - | - | 1.7 | +40.0 | 0.0 | 0.0 |
| IDLE COST | - | - | - | - | 17.7 | -208.1 | 0.0 | 156.3 |
| JOINT CHARGE NOW | 1.7 | +332.1 | 169.3 | 38.3 | 1.0 | +21.7 | 72.0 | 0.0 |
| JOINT ON THE TABLE | - | - | - | - | 0.3 | +30.7 | 24.0 | 0.0 |
| KEPT FROM ITS LAST STOP | - | - | - | - | 4.0 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 1.3 | +33.0 | 0.0 | 0.0 | 1.3 | +56.1 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 13.3 | +0.0 | 248.3 | 367.7 | 8.0 | +0.0 | 340.7 | 634.7 |
| LONE WIZARD KEPT IN | 0.3 | +7.9 | 0.0 | 0.0 | 0.3 | +7.5 | 0.0 | 0.0 |
| LONG SHOT | - | - | - | - | 0.3 | +1.1 | 26.7 | 0.0 |
| LOST AFTER ESCAPE | 1.7 | -12.2 | 84.7 | 38.3 | 4.7 | +19.6 | 232.3 | 0.0 |
| LURE BY WHAT IT DRAWS | - | - | - | - | 1.3 | -99.5 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | - | - | - | - | 1.7 | +18.6 | 0.0 | 0.0 |
| MANOEUVRE | 0.7 | +1.0 | 0.0 | 0.0 | 2.3 | -1.0 | 0.0 | 0.0 |
| MARCH CHECK | 0.7 | +17.5 | 0.0 | 0.0 | - | - | - | - |
| MARCH OF THE TABLE | 0.3 | +6.9 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 0.7 | +5.3 | 0.0 | 0.0 | - | - | - | - |
| MARCH WHEELS ONLY | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 1.7 | +25.2 | 0.0 | 0.0 | 6.0 | +112.3 | 0.0 | 0.0 |
| MEETS IN TIME | 4.0 | +232.5 | 0.0 | 0.0 | 4.3 | +194.0 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 3.0 | +55.2 | 0.0 | 0.0 | 4.3 | +25.5 | 0.0 | 20.0 |
| MISSILES NEXT TURN | 3.3 | +42.3 | 0.0 | 0.0 | 4.7 | +23.1 | 0.0 | 20.0 |
| MOVE ORDER | 0.7 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 20.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 7.7 | +594.3 | 0.0 | 206.3 | 13.7 | +1385.9 | 0.0 | 84.7 |
| MOVES UNITS SPELL | 0.3 | +2.4 | 0.0 | 0.0 | - | - | - | - |
| NEARER NOT NEEDED | 7.7 | +286.4 | 0.0 | 142.3 | 9.3 | +313.3 | 0.0 | 60.0 |
| NEXT CHARGE BY LIST | 6.3 | +556.7 | 0.0 | 206.3 | 6.7 | +650.5 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 3.3 | -196.7 | 277.0 | 58.3 | 5.0 | -147.1 | 384.0 | 0.0 |
| NO LATE CUT | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 1.0 | -1.0 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 4.7 | -138.4 | 0.0 | 100.0 | 6.3 | -185.8 | 0.0 | 70.0 |
| ONE CHECK AFTER THE LAST CHANGE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ONE FIGHT FORMULA | 5.3 | -137.0 | 0.0 | 20.0 | 9.0 | -159.3 | 0.0 | 169.3 |
| ONE JOINT FIGURE | 0.7 | +78.2 | 0.0 | 38.3 | 0.3 | -2.7 | 0.0 | 0.0 |
| ONE OBJECTIVE FORMULA | 3.7 | +2.5 | 0.0 | 68.7 | 5.0 | +41.8 | 0.0 | 122.0 |
| ONE PROMISE A TARGET | 0.7 | -42.0 | 0.0 | 40.0 | - | - | - | - |
| ONE ROUTE | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| OPENS UP | 0.7 | +11.5 | 43.3 | 0.0 | 1.0 | +39.7 | 72.0 | 0.0 |
| OVERRUNS AWAY | 1.3 | +120.1 | 167.3 | 0.0 | - | - | - | - |
| OWN CAST FIRST | - | - | - | - | 0.3 | -0.8 | 0.0 | 0.0 |
| PATHS CROSS | 0.3 | +6.0 | 0.0 | 26.7 | 0.7 | +7.0 | 0.0 | 0.0 |
| PLAN RESULT | 34.7 | +291.4 | 87.0 | 1050.3 | 48.0 | +502.5 | 146.7 | 516.7 |
| PROMISE BELOW ZERO | - | - | - | - | 0.3 | +0.0 | 0.0 | 84.7 |
| PROMISE BY ITS OWN SUM | 10.7 | -263.0 | 0.0 | 204.7 | 14.3 | -364.6 | 0.0 | 84.7 |
| PROMISE KNOWS THE FIGHT | 0.7 | +0.0 | 0.0 | 166.3 | 1.0 | +0.0 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | - | - | - | - | 1.0 | -95.1 | 0.0 | 0.0 |
| PROMISE SHOT AWAY | - | - | - | - | 1.3 | -6.7 | 233.3 | 0.0 |
| PURSUES BIG PREY | - | - | - | - | 0.3 | -3.2 | 0.0 | 0.0 |
| QUARTER ODDS | 15.7 | +1671.9 | 159.0 | 188.7 | 21.7 | +3313.3 | 208.3 | 154.0 |
| REAL GROUND | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| REDIRECT BY WHAT IT STOPS | - | - | - | - | 0.7 | +30.3 | 0.0 | 0.0 |
| REDIRECT COUNTER | 0.7 | +15.0 | 0.0 | 26.7 | 4.7 | +496.8 | 0.0 | 25.0 |
| REDIRECT FOR A FRIEND IN REACH | 2.0 | +0.0 | 0.0 | 53.3 | 5.0 | +63.7 | 0.0 | 40.0 |
| REDIRECT WEIGHED | - | - | - | - | 0.7 | +20.8 | 58.3 | 0.0 |
| REFORMS TO MEET IT | 2.0 | -103.0 | 0.0 | 0.0 | 2.7 | -69.5 | 0.0 | 0.0 |
| REFUSING RETIRES | 1.0 | +0.0 | 0.0 | 166.3 | 0.3 | +0.0 | 0.0 | 84.7 |
| RESERVE FALL BACK | 0.7 | +24.1 | 0.0 | 0.0 | 0.7 | +29.6 | 0.0 | 0.0 |
| RESTRAINS TO SHOOT | 0.3 | +6.6 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | 4.7 | +183.6 | 381.7 | 58.3 | 4.3 | +14.0 | 345.7 | 0.0 |
| RISK ON THE WAY | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| ROUNDS AFTER TERROR | - | - | - | - | 3.7 | -80.6 | 230.7 | 0.0 |
| RUN DOWN | - | - | - | - | 5.3 | -55.1 | 322.3 | 0.0 |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 1.7 | -44.6 | 0.0 | 0.0 |
| SEARCH SPOT | 0.7 | -1.5 | 0.0 | 42.0 | 1.0 | +18.2 | 0.0 | 0.0 |
| SECOND LOOK | 0.3 | +40.4 | 62.0 | 0.0 | 0.7 | +37.5 | 45.0 | 0.0 |
| SELF MOVE SPELL | 2.0 | +9.9 | 0.0 | 0.0 | - | - | - | - |
| SET CREDITED ONCE | 0.7 | -32.8 | 0.0 | 0.0 | 6.7 | -221.4 | 0.0 | 219.7 |
| SET UP BY THE SET | 1.3 | +24.2 | 0.0 | 0.0 | 9.3 | +109.9 | 0.0 | 239.7 |
| SET UP TOGETHER | - | - | - | - | 1.7 | +18.6 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 1.0 | +2.0 | 0.0 | 0.0 | 0.3 | +1.7 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 6.0 | +0.0 | 0.0 | 69.7 | 4.3 | +0.0 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 3.7 | +176.1 | 15.0 | 138.7 | 1.0 | +5.6 | 0.0 | 0.0 |
| SHOT OR CHARGE | 0.3 | -6.4 | 0.0 | 20.0 | 0.3 | -1.2 | 0.0 | 0.0 |
| SHOT RISK POINTS | 14.0 | -116.5 | 0.0 | 105.3 | 28.7 | -77.5 | 0.0 | 180.0 |
| SHOTS AFTER THE MOVES | 4.0 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 11.3 | +251.1 | 0.0 | 217.0 | 8.3 | +44.6 | 0.0 | 60.0 |
| SPELL WORTH | 1.3 | +6.3 | 58.3 | 0.0 | - | - | - | - |
| SPELLS IN THE FIGHT | 0.3 | -3.7 | 0.0 | 0.0 | 0.3 | -4.0 | 61.7 | 0.0 |
| SPOT AS THE GAME MOVES | 5.0 | +0.0 | 0.0 | 73.7 | 10.0 | +0.0 | 0.0 | 219.3 |
| STAND AND SHOOT | - | - | - | - | 1.7 | -13.4 | 160.7 | 0.0 |
| STANDS FOR A REASON | - | - | - | - | 7.0 | +0.0 | 0.0 | 40.0 |
| STANDS STILL | 23.3 | +0.0 | 55.0 | 520.3 | 19.0 | +0.0 | 408.3 | 40.0 |
| STAY WORTH | 11.7 | +49.0 | 40.0 | 0.0 | 9.7 | +28.3 | 408.3 | 20.0 |
| STUBBORN BY POINTS | 0.3 | +5.7 | 0.0 | 0.0 | - | - | - | - |
| STUPIDITY NEXT TURN | 0.7 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 1.3 | +215.9 | 0.0 | 0.0 | 6.7 | +521.8 | 0.0 | 0.0 |
| SUPPORT NARROWED | 0.7 | +0.0 | 0.0 | 58.3 | 1.0 | +0.0 | 88.3 | 0.0 |
| SUPPORT WORKED OUT | 1.3 | +215.9 | 0.0 | 0.0 | 6.7 | +521.8 | 0.0 | 0.0 |
| SURE REACH TOGETHER | - | - | - | - | 1.7 | +12.9 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 1.3 | +0.0 | 0.0 | 50.7 | 1.7 | +0.0 | 0.0 | 40.0 |
| THE PROMISE ADDS | - | - | - | - | 0.7 | -69.1 | 0.0 | 0.0 |
| THE PROMISED MOVE | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 2.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 84.7 | 62.0 |
| THE ROW KEEPS ITS WAY | 2.3 | +0.0 | 0.0 | 45.0 | 1.7 | +0.0 | 0.0 | 25.0 |
| THE STEP BACK IS MADE | 1.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 50.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 32.3 | +0.0 | 0.0 | 398.7 | 48.3 | +0.0 | 0.0 | 438.0 |
| TIED UP BY THE SUM | 1.7 | +198.1 | 130.3 | 0.0 | 1.0 | +77.6 | 72.0 | 0.0 |
| TIME ON OUR SIDE | 31.3 | +459.8 | 0.0 | 684.7 | - | - | - | - |
| WAITS AGAIN | 1.3 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| WAR ENGINE JOBS | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| WHAT THE JOINER ADDS | - | - | - | - | 0.7 | -10.9 | 0.0 | 0.0 |
| WHO FIGHTS | 0.3 | -1.1 | 62.0 | 0.0 | 0.3 | +6.8 | 0.0 | 0.0 |
| WHO GETS IN | 0.7 | +52.8 | 0.0 | 38.3 | - | - | - | - |
| WHO HITS BACK | - | - | - | - | 0.7 | +57.1 | 0.0 | 0.0 |
| WHOLE FIGHT | - | - | - | - | 0.3 | +1.9 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | 4.0 | -389.7 | 0.0 | 262.0 | 3.7 | -257.3 | 0.0 | 216.0 |
| WHOLE FIGHT GAIN | 0.3 | +16.5 | 0.0 | 0.0 | - | - | - | - |
| WOUNDS ON THE RANKS | 1.7 | +2.6 | 0.0 | 0.0 | 3.0 | +55.2 | 0.0 | 40.0 |

### Rule changes: cnomg-c940641-p33

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS MOVE AS HE DECIDES | 107 | 107 | 83 | 27.67 | +0 | +0.0 |
| ARMY TABLE | 112 | 112 | 78 | 26.00 | +2260 | +29.0 |
| LEGAL CHARGES ONLY | 64 | 64 | 64 | 21.33 | +0 | +0.0 |
| HOLDER ASSIGNMENT | 51 | 51 | 47 | 15.67 | +3434 | +73.1 |
| HIS SHOT LIST | 213 | 204 | 44 | 14.67 | +379 | +8.6 |
| FIVE ACTION | 506 | 490 | 36 | 12.00 | +1598 | +44.4 |
| OFF BEST | 33 | 33 | 33 | 11.00 | -973 | -29.5 |
| THE TABLE AGAIN | 36 | 36 | 30 | 10.00 | +0 | +0.0 |
| MOVE TO CHARGE COMPUTED | 64 | 60 | 28 | 9.33 | +822 | +29.3 |
| HIS MOVE WHY | 32 | 32 | 26 | 8.67 | +0 | +0.0 |
| DEPLOY BY FIGURES | 45 | 45 | 25 | 8.33 | +242 | +9.7 |
| PROMISE BY ITS OWN SUM | 75 | 75 | 25 | 8.33 | -1883 | -75.3 |
| HIS SHOTS BY HIS RUN | 174 | 166 | 23 | 7.67 | +108 | +4.7 |
| REDIRECT FOR A FRIEND IN REACH | 21 | 21 | 20 | 6.67 | +89 | +4.5 |
| MEETS IN TIME | 25 | 25 | 19 | 6.33 | +1217 | +64.0 |
| NEXT CHARGE BY LIST | 39 | 38 | 19 | 6.33 | +824 | +43.3 |
| QUARTER ODDS | 112 | 108 | 19 | 6.33 | +1554 | +81.8 |
| HIS ONE MOVE | 94 | 92 | 18 | 6.00 | +0 | +0.0 |
| COVER ONCE | 84 | 57 | 12 | 4.00 | +560 | +46.7 |
| FOUR ROUNDS | 31 | 29 | 12 | 4.00 | +481 | +40.1 |
| GOAL WALK | 45 | 45 | 12 | 4.00 | +613 | +51.1 |
| MOVE ORDER | 11 | 11 | 11 | 3.67 | +0 | +0.0 |
| SHOOTS FROM THE BEST SPOT | 14 | 14 | 11 | 3.67 | +277 | +25.2 |
| SUPPORT ADDS | 24 | 24 | 10 | 3.33 | +309 | +30.9 |
| SUPPORT WORKED OUT | 24 | 24 | 10 | 3.33 | +309 | +30.9 |
| JOINT CHARGE NOW | 8 | 8 | 8 | 2.67 | +1061 | +132.7 |
| LANE BY FIGURES | 8 | 8 | 8 | 2.67 | +267 | +33.4 |
| RISK BY ARC | 27 | 25 | 8 | 2.67 | +284 | +35.4 |
| SHOT RISK POINTS | 128 | 123 | 8 | 2.67 | +194 | +24.2 |
| TIED UP BY THE SUM | 8 | 8 | 8 | 2.67 | +378 | +47.3 |
| IDLE COST | 53 | 43 | 7 | 2.33 | +61 | +8.7 |
| CHARGE LOSSES | 91 | 88 | 6 | 2.00 | +527 | +87.9 |
| MAX FOR POSITIONING | 23 | 18 | 6 | 2.00 | +10 | +1.7 |
| ADVANCE LANE KEPT | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| CHAFF IN THE MOVE | 10 | 10 | 5 | 1.67 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 5 | 5 | 5 | 1.67 | +404 | +80.8 |
| SET UP BY THE SET | 32 | 30 | 5 | 1.67 | +240 | +48.0 |
| CASTS FROM BEHIND | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| COMBAT PIVOT | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| FALLS SHORT | 69 | 55 | 4 | 1.33 | +47 | +11.7 |
| PROMISE SHOT AWAY | 4 | 4 | 4 | 1.33 | -20 | -5.0 |
| RESERVE FALL BACK | 4 | 4 | 4 | 1.33 | +161 | +40.3 |
| SEARCH SPOT | 5 | 5 | 4 | 1.33 | +57 | +14.3 |
| SHOOTERS IN TWO RANKS | 4 | 4 | 4 | 1.33 | +11 | +2.8 |
| SUPPORT NARROWED | 5 | 5 | 4 | 1.33 | -170 | -42.6 |
| TIME ON OUR SIDE | 94 | 76 | 4 | 1.33 | +72 | +17.9 |
| CAST JOB | 3 | 3 | 3 | 1.00 | +1 | +0.3 |
| CHARGE NOW FIRST | 12 | 12 | 3 | 1.00 | -146 | -48.5 |
| HARD STAY DROPPED | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| HOLDS AMBUSHERS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| NO DOUBLE ROUNDS | 25 | 24 | 3 | 1.00 | +78 | +25.9 |
| PATHS CROSS | 3 | 3 | 3 | 1.00 | +39 | +13.1 |
| SECOND LOOK | 3 | 3 | 3 | 1.00 | +234 | +77.9 |
| SHOTS IN THE MOVE | 59 | 42 | 3 | 1.00 | +35 | +11.8 |
| AFTERMATH IN POINTS | 2 | 2 | 2 | 0.67 | +100 | +50.0 |
| AFTERMATH WITH FRIENDS | 2 | 2 | 2 | 0.67 | +53 | +26.6 |
| ASSAILMENT BY POINTS | 2 | 2 | 2 | 0.67 | +6 | +2.8 |
| CANNON PLANNED TARGET | 10 | 10 | 2 | 0.67 | +0 | +0.0 |
| FIGHT TO THE END | 12 | 11 | 2 | 0.67 | +1 | +0.5 |
| HUNT IN PAIRS | 5 | 4 | 2 | 0.67 | +18 | +8.9 |
| LONE WIZARD KEPT IN | 2 | 2 | 2 | 0.67 | +46 | +23.1 |
| MARCH CHECK | 2 | 2 | 2 | 0.67 | +32 | +16.0 |
| NEARER NOT NEEDED | 51 | 47 | 2 | 0.67 | +57 | +28.4 |
| ONE PROMISE A TARGET | 2 | 2 | 2 | 0.67 | -126 | -63.0 |
| OPENS UP | 5 | 5 | 2 | 0.67 | +29 | +14.5 |
| OVERRUNS AWAY | 4 | 4 | 2 | 0.67 | +35 | +17.3 |
| REDIRECT WEIGHED | 2 | 2 | 2 | 0.67 | +261 | +130.4 |
| SURE REACH TOGETHER | 5 | 5 | 2 | 0.67 | +1 | +0.5 |
| THE ROW IN ITS ORDER | 12 | 2 | 2 | 0.67 | +0 | +0.0 |
| WHO GETS IN | 2 | 2 | 2 | 0.67 | +158 | +79.2 |
| WHO HITS BACK | 2 | 2 | 2 | 0.67 | +106 | +53.2 |
| WHOLE FIGHT DANGER | 23 | 23 | 2 | 0.67 | +127 | +63.3 |
| WOUNDS ON THE RANKS | 14 | 14 | 2 | 0.67 | +34 | +17.1 |
| CHARGE LIST READ AGAIN | 1 | 1 | 1 | 0.33 | +47 | +47.1 |
| CHARGE NOT DECLARED | 1 | 1 | 1 | 0.33 | -188 | -187.8 |
| FALL BACK GOOD ORDER | 20 | 18 | 1 | 0.33 | +12 | +11.9 |
| FEATURE BUFFS | 6 | 6 | 1 | 0.33 | +7 | +6.5 |
| HIS CHARGE DENIED | 6 | 6 | 1 | 0.33 | +8 | +7.8 |
| HIS MOVE AND SHOT | 36 | 34 | 1 | 0.33 | +0 | +0.0 |
| HONEST WORTH | 30 | 28 | 1 | 0.33 | +8 | +7.8 |
| JOINT ON THE TABLE | 1 | 1 | 1 | 0.33 | +92 | +92.1 |
| LOST AFTER ESCAPE | 19 | 18 | 1 | 0.33 | +0 | +0.0 |
| MANOEUVRE | 9 | 9 | 1 | 0.33 | +3 | +3.1 |
| MARCH OF THE TABLE | 1 | 1 | 1 | 0.33 | -21 | -20.6 |
| MISSILES IN THE MOVE | 22 | 17 | 1 | 0.33 | +38 | +37.5 |
| MOVES UNITS SPELL | 1 | 1 | 1 | 0.33 | +7 | +7.3 |
| ONE FIGHT FORMULA | 43 | 22 | 1 | 0.33 | +17 | +17.4 |
| ONE JOINT FIGURE | 3 | 2 | 1 | 0.33 | +100 | +99.5 |
| ONE OBJECTIVE FORMULA | 26 | 21 | 1 | 0.33 | +50 | +49.9 |
| OWN CAST FIRST | 1 | 1 | 1 | 0.33 | -2 | -2.4 |
| PROMISE READS THE TABLE | 3 | 3 | 1 | 0.33 | -98 | -97.7 |
| PURSUES BIG PREY | 1 | 1 | 1 | 0.33 | -10 | -9.6 |
| REDIRECT COUNTER | 16 | 15 | 1 | 0.33 | +13 | +12.6 |
| REFORMS TO MEET IT | 14 | 14 | 1 | 0.33 | +54 | +54.1 |
| RESTRAINS TO SHOOT | 1 | 1 | 1 | 0.33 | +20 | +19.8 |
| SHOTS AFTER THE MOVES | 17 | 17 | 1 | 0.33 | +0 | +0.0 |
| STAY WORTH | 64 | 52 | 1 | 0.33 | +6 | +6.4 |
| STUBBORN BY POINTS | 1 | 1 | 1 | 0.33 | +17 | +17.1 |
| BACKUP TARGETS | 2 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 1 | trace | - | - | - | - |
| CHAMPION KNOWS CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 84 | 81 | 0 | 0.00 | - | - |
| DENIED BY THE FIGHT | 3 | 3 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 2 | 1 | 0 | 0.00 | - | - |
| EDGE GIVE GROUND | 2 | 2 | 0 | 0.00 | - | - |
| EXACT ROUND | 21 | 20 | 0 | 0.00 | - | - |
| FIGHT LIFT | 2 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 49 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 34 | 32 | 0 | 0.00 | - | - |
| FRIEND CHARGES FIRST | 1 | 1 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 6 | 5 | 0 | 0.00 | - | - |
| GIVES UP | 6 | 6 | 0 | 0.00 | - | - |
| GUN MASK | 5 | 5 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 17 | 16 | 0 | 0.00 | - | - |
| HELPER UNSEEN | 2 | 2 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 75 | 72 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 47 | 44 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 49 | 46 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 21 | 19 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 40 | 38 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 10 | 9 | 0 | 0.00 | - | - |
| HIS TURN RUN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 78 | 78 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 12 | 12 | 0 | 0.00 | - | - |
| LONG SHOT | 1 | 1 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 4 | 4 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 5 | not checked | - | - | - | - |
| MARCH OVER CASTS | 2 | 2 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 2 | 2 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 24 | 19 | 0 | 0.00 | - | - |
| NO LATE CUT | 2 | 2 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 18 | 18 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 3 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 1 | not checked | - | - | - | - |
| ONE ROUTE | 2 | 2 | 0 | 0.00 | - | - |
| PLAN RESULT | 248 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE KNOWS THE FIGHT | 5 | 4 | 0 | 0.00 | - | - |
| REAL GROUND | 2 | 2 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 2 | 2 | 0 | 0.00 | - | - |
| REFUSING RETIRES | 4 | 4 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 2 | 2 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 11 | 9 | 0 | 0.00 | - | - |
| RUN DOWN | 16 | 14 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 5 | 5 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 6 | not checked | - | - | - | - |
| SET CREDITED ONCE | 22 | 20 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 5 | 4 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 31 | not checked | - | - | - | - |
| SHOT OR CHARGE | 2 | 2 | 0 | 0.00 | - | - |
| SPELL WORTH | 4 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 45 | 39 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 5 | 4 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 21 | 21 | 0 | 0.00 | - | - |
| STANDS STILL | 127 | 122 | 0 | 0.00 | - | - |
| STUPIDITY NEXT TURN | 11 | 10 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 9 | not checked | - | - | - | - |
| THE PROMISE ADDS | 2 | 2 | 0 | 0.00 | - | - |
| THE PROMISED MOVE | 1 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 12 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 9 | not checked | - | - | - | - |
| THE TABLE BINDS | 242 | not checked | - | - | - | - |
| WAITS AGAIN | 14 | 14 | 0 | 0.00 | - | - |
| WAR ENGINE JOBS | 4 | 4 | 0 | 0.00 | - | - |
| WHAT THE JOINER ADDS | 2 | 2 | 0 | 0.00 | - | - |
| WHO FIGHTS | 2 | 2 | 0 | 0.00 | - | - |
| WHOLE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| WHOLE FIGHT GAIN | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: cnomg-c940641-p33

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 4.33 | 4.67 | 29.8 |
| PROMISE BY ITS OWN SUM | rule | 3.67 | 4.67 | 75.3 |
| ARMY TABLE | rule | 2.33 | 2.67 | 48.5 |
| PROMISE SHOT AWAY | rule | - | 1.33 | 5.0 |
| SUPPORT NARROWED | rule | 0.33 | 1.00 | 42.6 |
| CHARGE NOW FIRST | rule | 0.33 | 0.67 | 48.5 |
| HOLDER ASSIGNMENT | rule | 0.33 | 0.33 | 11.7 |
| JOINT CHARGE NOW | rule | - | 0.67 | 13.6 |
| ONE PROMISE A TARGET | rule | 0.67 | - | 63.0 |
| RULE SWITCHED OFF | gate | - | 0.67 | 14.5 |
| AFTERMATH BAND | gate | - | 0.33 | 3.0 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.33 | - | 39.1 |
| CHARGE NOT DECLARED | rule | - | 0.33 | 187.8 |
| FALLBACK | gate | - | 0.33 | 95.5 |
| FIGHT ORDER BAND | gate | - | 0.33 | 1.3 |
| MARCH OF THE TABLE | rule | 0.33 | - | 20.6 |
| OWN CAST FIRST | rule | - | 0.33 | 2.4 |
| PROMISE READS THE TABLE | rule | - | 0.33 | 97.7 |
| PURSUES BIG PREY | rule | - | 0.33 | 9.6 |

### Plans: cnomg-c940641-p33

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 3.7 | 73% | 672 | 258 | 38% |
| Mine | move | 26.3 | 90% | 1510 | 0 | 0% |
| Mine | shoot | 4.7 | 14% | 253 | 34 | 13% |
| Opponent | charge | 4.3 | 69% | 465 | 313 | 67% |
| Opponent | join | 2.3 | 100% | 91 | 0 | 0% |
| Opponent | move | 36.7 | 93% | 2346 | 0 | 0% |
| Opponent | shoot | 2.7 | 50% | 137 | 190 | 138% |
| Opponent | support | 2.0 | 100% | 32 | 0 | 0% |

### Battle groups: cnomg-c940641-p33

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 0.7 | 50% | 100% | 100% | 0% | - | - | - | - | - |
| Opponent | REDIRECT COUNTER | 4.7 | 14% | 100% | 0% | - | 50% | 0% | 0% | 50% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: cnomg-c940641-p33

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 1 | 42 (1) | 42 | 0 | 0 | 0% | 5.0 | 42 (1) | - | - | - | 42 (1) |
| Mine | Chaff | 2 | 0 (2) | 0 | 0 | 100 | 0% | 1.0 | - | 0 (2) | - | 0 (1) | 0 (1) |
| Mine | Character | 8 | 44 (8) | 44 | 0 | 23 | 12% | 2.4 | 32 (3) | 50 (4) | 48 (1) | 28 (5) | 66 (3) |
| Mine | Clean-up | 1 | 0 (1) | 0 | 0 | 100 | 0% | 2.0 | 0 (1) | - | - | 0 (1) | - |
| Mine | Fast Hammer | 4 | 49 (4) | 27 | 23 | 32 | 0% | 2.8 | 0 (1) | 62 (3) | - | 106 (1) | 34 (3) |
| Mine | Hammer | 4 | 0 (4) | 0 | 0 | 39 | 50% | 1.5 | 0 (3) | 0 (1) | - | 0 (4) | - |
| Mine | Shooter | 6 | 31 (6) | 0 | 31 | 62 | 0% | 1.7 | 45 (2) | 0 (3) | 145 (1) | 50 (4) | 0 (2) |
| Mine | Support | 3 | 0 (3) | 0 | 0 | 100 | 0% | 3.0 | - | - | - | - | - |
| Mine | War machine | 2 | 0 (2) | 0 | 0 | 0 | 0% | 1.0 | 0 (1) | 0 (1) | - | 0 (2) | - |
| Mine | Wizard | 1 | 0 (1) | 0 | 0 | 0 | 0% | 2.0 | 0 (1) | - | - | 0 (1) | - |
| Opponent | Chaff | 10 | 51 (10) | 22 | 29 | 29 | 40% | 3.2 | 21 (6) | 33 (3) | 273 (1) | 58 (7) | 33 (3) |
| Opponent | Character | 9 | 31 (9) | 31 | 0 | 19 | 33% | 3.8 | 5 (2) | 0 (4) | 73 (3) | 0 (3) | 44 (6) |
| Opponent | Clean-up | 3 | 7 (3) | 0 | 7 | 68 | 0% | 3.3 | 50 (1) | 0 (2) | - | 14 (2) | 0 (1) |
| Opponent | Fast Hammer | 8 | 72 (8) | 42 | 30 | 16 | 25% | 4.2 | 86 (1) | 82 (5) | 34 (2) | 0 (3) | 102 (5) |
| Opponent | Hammer | 1 | 95 (1) | 95 | 0 | 0 | 0% | 2.0 | - | 95 (1) | - | - | 95 (1) |
| Opponent | Holder | 2 | 0 (2) | 0 | 0 | 45 | 0% | 1.5 | - | 0 (2) | - | 0 (1) | 0 (1) |
| Opponent | Support | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | 0 (1) | - | - | - | 0 (1) |
| Opponent | Wizard | 5 | 0 (5) | 0 | 0 | 44 | 20% | 2.0 | 0 (3) | 0 (1) | - | 0 (2) | 0 (2) |

### Charged fights: cnomg-c940641-p33

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | High Elf Realms | 1 | 0 | 436 | 5.0 | 1.2 | 87 | 12 | +75 | 2 of 5 | 3 of 5 | +0 | +94 |
| Mine | Kingdom of Bretonnia | 1 | 45 | 329 | 3.0 | 1.3 | 110 | 0 | +110 | 1 of 3 | 2 of 3 | +254 | +38 |
| Mine | Lizardmen | 1 | 0 | 711 | 4.0 | 1.0 | 178 | 125 | +53 | 1 of 4 | 3 of 4 | - | +53 |
| **Mine** | all armies | 3 | 15 | 492 | 4.0 | 1.2 | 123 | 47 | +76 | 4 of 12 | 8 of 12 | +127 | +66 |
| Opponent | Tomb Kings of Khemri | 1 | 175 | 783 | 4.0 | 1.0 | 196 | 0 | +196 | 2 of 4 | 2 of 4 | - | +196 |
| Opponent | Vampire Counts | 2 | 0 | 98 | 2.5 | 1.0 | 39 | 0 | +39 | 1 of 5 | 5 of 5 | - | +39 |
| **Opponent** | all armies | 3 | 58 | 326 | 3.0 | 1.0 | 109 | 0 | +109 | 3 of 9 | 7 of 9 | - | +109 |

### Effective charges: cnomg-c940641-p33

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | High Elf Realms | 5 | 0 | 0 | 1 (net -60) | 2 (net +125) | 0 | 1 (net +186) | 1 | 25% (1 of 4) |
| Mine | Kingdom of Bretonnia | 3 | 0 | 0 | 0 | 0 | 1 (net +75) | 1 (net +254) | 1 | 0% (0 of 2) |
| Mine | Lizardmen | 4 | 0 | 0 | 0 | 0 | 2 (net +95) | 0 | 2 | 0% (0 of 2) |
| Opponent | Tomb Kings of Khemri | 4 | 1 (net +326) | 0 | 0 | 1 (net +0) | 0 | 1 (net +282) | 1 | 0% (0 of 3) |
| Opponent | Vampire Counts | 5 | 0 | 0 | 1 (net +0) | 1 (net +0) | 1 (net +115) | 2 (net +40) | 0 | 20% (1 of 5) |

### Charged fights, damage counted: cnomg-c940641-p33

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Effective (55-75%) | 1 | 60 | 75 | -60 | 0 | 60 | -60 | -100.0 |
| Mine | 76-89% | 2 | 471 | 220 | +125 | 125 | 24 | +101 | +21.4 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 572 | 220 | +220 | 220 | 0 | +220 | +38.5 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 3 | 358 | 68 | +88 | 132 | 22 | +110 | +30.7 |
| Mine | No odds | 4 | 418 | 284 | +6 | 130 | 175 | -45 | -10.8 |
| Mine | All fights | 12 | 408 | 191 | +76 | 134 | 73 | +61 | +15.0 |
| Opponent | Long shot (under 50%) | 1 | 195 | 185 | +326 | 326 | 130 | +196 | +100.5 |
| Opponent | Effective (55-75%) | 1 | 186 | 199 | +0 | 93 | 0 | +93 | +49.8 |
| Opponent | 76-89% | 2 | 289 | 388 | +0 | 0 | 0 | +0 | +0.0 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 | 150 | 138 | +121 | 130 | 3 | +127 | +85.1 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 380 | 115 | +115 | 115 | 0 | +115 | +30.3 |
| Opponent | No odds | 1 | 440 | 175 | +175 | 175 | 0 | +175 | +39.8 |
| Opponent | All fights | 9 | 248 | 207 | +109 | 122 | 15 | +107 | +43.1 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| cnomg-c940641-p33 | move | 35 | 8 (23%) | 7 (20%) | 5 (14%) | 22 (63%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L1527, L1625 |
| Invocation of Nehek | Opponent | L1527, L1625 |
| Ring of Doom | Mine | L1527 |

# Doctrine scorecard: cnomg-c940641-p44

### Scorecard: cnomg-c940641-p44

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L1323 | 3 | 1 | Mine | no | 5 | 2 | 2 | 1 | 1 | 0 | 0 | 140 |
| L1323 | 3 | 1 | Opponent | yes | 0 | 2 | 5 | 2 | 1 | 0 | 0 | 126 |
| L1418 | 2 | 1 | Mine | - | - | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L1418 | 2 | 1 | Opponent | - | - | - | 3 | 1 | 0 | 0 | 0 | 305 |
| L1435 | 1 | 1 | Mine | - | - | - | - | - | - | - | - | - |
| L1435 | 1 | 1 | Opponent | - | - | - | - | - | - | - | - | - |
| **Average** | | | Mine | 0% | 5.0 | 2.0 | 3.0 | 1.0 | 0.5 | 0.0 | 0.0 | 70.0 |
| **Average** | | | Opponent | 100% | 0.0 | 2.0 | 4.0 | 1.5 | 0.5 | 0.0 | 0.0 | 215.5 |

### KPIs: cnomg-c940641-p44

Rules off - Opponent only: NO OLD ONE-MOVE GUESS.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 14) | 0% (0 of 15) | 0% (0 of 29) |
| Winner chose to follow up after the loser gave ground |  | 100% (2 of 2); on the table 100% | - | 100% (2 of 2); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | 100% (1 of 1); on the table 100% | - | 100% (1 of 1); on the table 100% |
| Winner chose to pursue after the loser fled |  | 100% (2 of 2); on the table 100% | 100% (2 of 2); on the table 100% | 100% (4 of 4); on the table 100% |
| Winner chose to follow up or pursue (all three) |  | 100% (5 of 5); on the table 100% | 100% (2 of 2); on the table 100% | 100% (7 of 7); on the table 100% |
| Magic missiles tried each own turn | 50%+ | 25% (4 of 16) | - | 25% (4 of 16) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 40% (4 of 10) | - | 40% (4 of 10) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | - | - |
| Points that never fought | lower | 26% (1042 of 4000) | 43% (1711 of 4000) | 34% (2753 of 8000) |
|   infantry points that never fought | lower | 24% (177 of 746) | 59% (317 of 534) | 39% (494 of 1280) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 47% (8 of 17) | 83% (10 of 12) | 62% (18 of 29) |
| Bound items with a magic missile used (at least once a game) |  | 100% (1 of 1); 1.0 uses a game | 50% (1 of 2); 0.3 uses a game | 67% (2 of 3); 0.7 uses a game |
| Bound items with another spell used |  | 36% (5 of 14); 2.0 uses a game | 0.0 uses a game | 36% (5 of 14); 1.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
|   their share of the points of units over 100 pts | lower | 40% (1526 of 3860) | 72% (2260 of 3131) | 54% (3786 of 6991) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.0 (25%) | - | 1.0 (25%) |
| MARCHED: its unit marched | 0.7 (17%) | - | 0.7 (17%) |
| IN COMBAT: engaged in combat | 1.0 (25%) | - | 1.0 (25%) |
| GONE: slain | 1.0 (25%) | - | 1.0 (25%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.3 (8%) | - | 0.3 (8%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 4.0 | 2.7 | 2.7 | 1.3 | 2.7 |
| not cast | 3.3 | 5.7 | 4.7 | 4.0 | 21.3 |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 3.3 (59%) | 0.0 (0%) | 1.0 (25%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (17%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.0 (0%) | 1.0 (21%) | 1.0 (25%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 2.0 (60%) | 2.0 (35%) | 2.0 (43%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | 1.0 (30%) | 0.0 (0%) | 1.0 (21%) | 1.0 (25%) | 2.3 (11%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (0%) | 0.3 (6%) | 0.0 (0%) | 0.0 (0%) | 0.3 (2%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (8%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 0.3 (10%) | 0.0 (0%) | 0.7 (14%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 18.7 (88%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 2.7 a game | 0.0 a game | 1.3 a game |
| stood (cast and not dispelled) | 50% (4 of 8) | - | 50% (4 of 8) |
| the unit moved after it | 50% (2 of 4) | - | 50% (2 of 4) |
| it charged on its next turn | 0% (0 of 4) | - | 0% (0 of 4) |
| the enemy charged it first | 0% (0 of 4) | - | 0% (0 of 4) |
| it fought by the end of its next turn | 0% (0 of 4) | - | 0% (0 of 4) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 4) | - | 0% (0 of 4) |
| none of these (no charge, no fight, no charge escaped) | 100% (4 of 4) | - | 100% (4 of 4) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 70% (35 of 50) | 54% (35 of 65) | 61% (70 of 115) |
|   cavalry | 92% (11 of 12) | 100% (2 of 2) | 93% (13 of 14) |
|   character | 27% (4 of 15) | 25% (3 of 12) | 26% (7 of 27) |
|   chariot | - | 100% (9 of 9) | 100% (9 of 9) |
|   infantry | 79% (11 of 14) | 40% (12 of 30) | 52% (23 of 44) |
|   monster | - | 75% (9 of 12) | 75% (9 of 12) |
|   war machine | 100% (9 of 9) | - | 100% (9 of 9) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.7 (33%) | 0.3 (3%) | 2.0 (13%) |
| CHARGED: it charged | 1.0 (20%) | 1.0 (10%) | 2.0 (13%) |
| FLEEING: it fled or was fleeing | 0.0 (0%) | 0.7 (7%) | 0.7 (4%) |
| IN COMBAT: it fought this turn or the last | 1.0 (20%) | 0.7 (7%) | 1.7 (11%) |
| NO TARGET IN RANGE | 1.0 (20%) | 5.0 (50%) | 6.0 (40%) |
| ONLY IN COMBAT: the only targets were in combat | 0.0 (0%) | 0.3 (3%) | 0.3 (2%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.3 (7%) | 1.7 (17%) | 2.0 (13%) |
| OTHER BAR | 0.0 (0%) | 0.3 (3%) | 0.3 (2%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 8.0 | 0.7 | 92% | 2.0 pts | 16 pts |
| character | 4.3 | 1.3 | 77% | 11.3 pts | 49 pts |
| chariot | 3.0 | 1.3 | 78% | 27.8 pts | 83 pts |
| infantry | 12.3 | 4.0 | 73% | 7.7 pts | 96 pts |
| monster | 3.3 | 0.7 | 80% | 5.5 pts | 18 pts |
| war machine | 3.0 | 0.3 | 89% | 3.6 pts | 11 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.0 | 3.7 | 3.8 |
| Charges that made contact a game | 3.7 | 1.3 | 2.5 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.67 declared, 0.67 contact (3 units) | - | 0.67 declared, 0.67 contact (3 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | - | - |
|   per unit a game, the other units (no war machines, no joined characters) | 0.43 declared, 0.39 contact (23 units) | 0.33 declared, 0.12 contact (33 units) | 0.38 declared, 0.23 contact (56 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 50% (4 of 8) | - | - | 50% (4 of 8) |
| Character on its own | - | 75% (3 of 4) | 20% (1 of 5) | 44% (4 of 9) |
| Chariot | 100% (2 of 2) | - | - | 100% (2 of 2) |
| Infantry | 75% (3 of 4) | 0% (0 of 1) | - | 60% (3 of 5) |
| Monster | 100% (2 of 2) | 100% (1 of 1) | - | 100% (3 of 3) |
| Monstrous | - | 100% (2 of 2) | - | 100% (2 of 2) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| High Elf Realms | 2 | 100% (5 of 5); on the table 100% | 17% (2 of 12) | 26% | 47% (8 of 17) | 100% (1 of 1); 1.5 uses a game | 38% (3 of 8); 2.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 1 | - | - | 49% | 100% (7 of 7) | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Tomb Kings of Khemri | 1 | 100% (2 of 2); on the table 100% | - | 37% | 60% (3 of 5) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (cnomg-c940641-p44, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 33% (1) | 40% (2) | 38% (3) |
| ...free all their last turn and able to turn (per game) | 0.33 | 0.67 | 1.00 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.33 | 0.33 | 0.67 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.33 | 0.33 |

### Quality by phase: cnomg-c940641-p44

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.0 | 1.7 |
| Strategy | Charge objectives carried out (made contact) | 73% (8 of 11) | 20% (1 of 5) |
| Strategy | Shoot objectives carried out (shot that target) | 29% (7 of 24) | 60% (9 of 15) |
| Strategy | Support requests answered (helper made contact too) | 100% (1 of 1) | - |
| Strategy | Hexes on a unit its side charged or shot that turn | 50% (1 of 2) | - |
| Strategy | Joined characters whose unit fought | - | 0% (0 of 1) |
| Strategy | Lone characters that fought | 80% (4 of 5) | 75% (3 of 4) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 1.0 | 1.5 |
| Movement | Points that never moved of their own | 70.0 | 215.5 |
| Movement | Fights charged into per game | 3.5 | 1.5 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 7 | 1 of 1, net +0 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 7 | 0 of 1 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 5 of 7, net +32 | 0 of 1 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 of 7, net +266 | 0 of 1 |
| Shooting | Shots by shooting units (incl. breath weapons) | 10.7 | 12.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 25% (8 of 32) | 61% (23 of 38) |
| Shooting | Points destroyed by shooting units | 22.0 | 0.0 |
| Shooting | War machine shots | 3.0 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 89% (8 of 9) | - |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | 1.3 | - |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 25% (1 of 4) | - |
| Magic | Wounds caused by magic missiles | 2.3 | 0.3 |
| Magic | Wounds caused by other spells | 2.7 | - |
| Magic | Points destroyed by magic (all spells) | 0.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.7 / 1.0 / 2.0 / 0.0 | 3.0 / 1.0 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 143.3 | 320.0 |
| Combat | Points run down | 0.0 | 0.0 |
| Combat | Net points per charged fight, damage counted | +97 | +297 |
| Combat | Net per 100 charger points, damage counted | +30.2 | +83.6 |
| Combat | First round won (charged fights) | 100% | 67% |
| Combat | Net points per charged fight | +99 | +293 |
| Combat | Net points per supported fight / lone fight | +234 / +76 | - / +293 |
| Combat | Charged fights on a top-3 enemy unit | 1 of 7 | 1 of 3 |
| Game | Points lost | 590.5 | 814.0 |
| Game | VP from objectives | 390.0 | 700.0 |
| Game | Lone holders (player turns) | 5.0 | 0.0 |

- Mine won / drew / lost: 1 / 0 / 1 of 2 ended games (of 3); mean margin (Mine - Opponent) +14 VP
- The side that went first won 0 of 2 games with a winner
- Points traded per game (both sides' losses): 1404
- Games not ended: 1 (L1435-1); findings 2, warnings 0

### Opponent rules: cnomg-c940641-p44

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.7 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| ARMY TABLE | 18.7 | +429.0 | 0.0 | 50.3 | 29.3 | +673.4 | 0.0 | 523.3 |
| ASSAILMENT BY POINTS | 1.0 | +5.5 | 0.0 | 266.7 | - | - | - | - |
| BACKUP TARGETS | 0.3 | +0.8 | 0.0 | 0.0 | - | - | - | - |
| BEST PRIZE | 0.3 | -23.5 | 76.0 | 0.0 | 0.3 | -4.3 | 23.3 | 0.0 |
| BOUND ASSAILMENT | 1.0 | +0.1 | 0.0 | 50.3 | - | - | - | - |
| CANNON PLANNED TARGET | 3.0 | +0.0 | 0.0 | 93.3 | - | - | - | - |
| CANNON SIGHT KEPT | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CAST JOB | 1.0 | +19.2 | 66.0 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | - | - | - | - | 0.7 | +10.2 | 0.0 | 0.0 |
| CHAFF PASSED | 1.0 | -3.6 | 139.7 | 0.0 | - | - | - | - |
| CHALLENGE BY POINTS | 1.3 | +78.8 | 0.0 | 163.3 | 0.3 | +19.8 | 0.0 | 0.0 |
| CHARGE LOSSES | 18.0 | -1053.1 | 0.0 | 133.3 | 12.3 | -341.7 | 0.0 | 362.3 |
| CHARGE NOW FIRST | 1.7 | +0.0 | 35.3 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 8.0 | +0.0 | 0.0 | 50.3 | 13.7 | +0.0 | 0.0 | 20.0 |
| COMBAT PIVOT | 0.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 50.3 | 0.0 |
| CONVEYANCE SEARCH | 2.3 | +284.8 | 133.3 | 133.3 | - | - | - | - |
| COVER ONCE | 7.7 | -423.6 | 0.0 | 133.3 | 6.7 | -675.4 | 0.0 | 277.3 |
| DENIED BY THE FIGHT | 0.7 | -7.3 | 0.0 | 0.0 | - | - | - | - |
| DEPLOY BY FIGURES | 8.0 | -26.8 | 0.0 | 0.0 | 9.3 | +8.3 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | - | - | - | - | 0.3 | -0.2 | 0.0 | 0.0 |
| EDGE GIVE GROUND | 0.3 | +0.7 | 0.0 | 0.0 | - | - | - | - |
| EVASIVE BY THE ODDS | 0.3 | +44.7 | 0.0 | 0.0 | 1.3 | +22.4 | 0.0 | 0.0 |
| EXACT ROUND | 3.0 | -8.0 | 192.7 | 0.0 | 1.7 | +18.6 | 46.7 | 0.0 |
| FALL BACK GOOD ORDER | 2.3 | +13.0 | 134.3 | 0.0 | 2.3 | +4.6 | 23.3 | 0.0 |
| FALLS SHORT | 5.7 | +82.5 | 0.0 | 0.0 | 14.3 | +191.5 | 0.0 | 297.0 |
| FEATURE BUFFS | 1.7 | +10.9 | 0.0 | 0.0 | 0.7 | +2.7 | 0.0 | 0.0 |
| FIRE IN ORDER | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FIVE ACTION | 84.3 | +3486.2 | 835.7 | 981.3 | 89.3 | +5424.8 | 46.7 | 1511.3 |
| FLANK NOT WEIGHED | 5.0 | +0.0 | 0.0 | 50.3 | 8.0 | +0.0 | 0.0 | 279.3 |
| FOCUS FIRE | 0.3 | +12.1 | 22.0 | 0.0 | - | - | - | - |
| FOLLOW UP WEIGHED | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +230.5 | 0.0 | 0.0 |
| FOUR ROUNDS | 3.7 | +95.6 | 313.7 | 0.0 | 2.7 | +166.1 | 46.7 | 0.0 |
| FREED FROM HIS FIGHT | 6.7 | +0.0 | 0.0 | 208.7 | 5.0 | +0.0 | 0.0 | 0.0 |
| FRIEND CHARGES FIRST | - | - | - | - | 0.3 | -33.7 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 2.3 | -33.5 | 0.0 | 0.0 | - | - | - | - |
| GIVES UP | - | - | - | - | 0.7 | -5.9 | 46.7 | 0.0 |
| GOAL WALK | 7.0 | +478.7 | 0.0 | 100.7 | 8.0 | +504.3 | 0.0 | 0.0 |
| GUN FIGURES | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| GUN MASK | 1.0 | +4.5 | 0.0 | 0.0 | - | - | - | - |
| HARD STAY DROPPED | 1.3 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 87.3 |
| HE REFORMS ONCE FREED | 5.0 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 13.3 | +0.0 | 0.0 | 133.3 | 7.3 | +0.0 | 0.0 | 342.3 |
| HIS CHARGE LIST | 4.7 | +0.0 | 0.0 | 0.0 | 9.7 | +0.0 | 0.0 | 448.0 |
| HIS LEGAL MOVES | 8.3 | +0.0 | 0.0 | 133.3 | 2.0 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 4.3 | -54.4 | 0.0 | 0.0 | 3.3 | -25.6 | 0.0 | 61.7 |
| HIS MOVE AS HE DECIDES | - | - | - | - | 34.7 | +9.3 | 347.0 | 0.0 |
| HIS MOVE WHY | 20.3 | +0.0 | 0.0 | 397.3 | - | - | - | - |
| HIS ONE MOVE | - | - | - | - | 17.7 | -28.5 | 0.0 | 0.0 |
| HIS ONE QUARTER | 3.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 10.7 | +0.0 | 0.0 | 133.3 | 1.3 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER OUR TURN | 5.3 | +0.0 | 0.0 | 0.0 | 5.3 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 58.3 | +3733.4 | 0.0 | 543.3 | 58.3 | +1506.2 | 0.0 | 1174.3 |
| HIS SHOTS BY HIS RUN | 47.3 | +1450.8 | 0.0 | 133.3 | 39.3 | +546.7 | 0.0 | 971.0 |
| HIS TURN DENIED | 1.3 | +157.2 | 100.0 | 0.0 | 0.3 | +3.4 | 23.3 | 0.0 |
| HIS TURN RUN | 5.7 | +0.0 | 0.0 | 0.0 | 5.3 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 16.0 | +0.0 | 0.0 | 100.7 | 10.7 | +0.0 | 0.0 | 44.0 |
| HOLDER ASSIGNMENT | 9.0 | +975.8 | 0.0 | 50.3 | 8.0 | +647.2 | 0.0 | 44.0 |
| HOLDS AMBUSHERS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 3.0 | -136.5 | 157.7 | 0.0 | 2.7 | -121.1 | 46.7 | 0.0 |
| HUNT IN PAIRS | - | - | - | - | 1.3 | +15.6 | 0.0 | 23.3 |
| IDLE COST | 3.0 | -62.3 | 0.0 | 0.0 | 12.0 | -155.4 | 0.0 | 199.0 |
| JOINT CHARGE NOW | 0.7 | +139.6 | 156.0 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 2.7 | +0.0 | 0.0 | 100.7 | 1.3 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 1.7 | +82.5 | 0.0 | 0.0 | 1.0 | +20.0 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| LEGAL CHARGES ONLY | 4.3 | +0.0 | 156.0 | 305.3 | 4.7 | +0.0 | 174.3 | 113.7 |
| LONE WIZARD KEPT IN | - | - | - | - | 0.3 | +37.5 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | 2.0 | +5.8 | 268.3 | 0.0 | 0.3 | +1.9 | 0.0 | 0.0 |
| LURE BY WHAT IT DRAWS | - | - | - | - | 0.3 | -69.3 | 0.0 | 0.0 |
| MANOEUVRE | 1.0 | +0.0 | 0.0 | 0.0 | 2.7 | -6.9 | 0.0 | 75.0 |
| MARCH BY THE SUM | 0.3 | +13.3 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | - | - | - | - | 0.3 | +6.0 | 0.0 | 0.0 |
| MARCH OF THE TABLE | 0.3 | +11.9 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 0.3 | +60.8 | 0.0 | 0.0 | - | - | - | - |
| MARCH WHEELS ONLY | 1.0 | +0.0 | 0.0 | 50.3 | 0.7 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 2.0 | +10.1 | 0.0 | 133.3 | 1.3 | +40.2 | 0.0 | 0.0 |
| MEETS IN TIME | 3.3 | +208.6 | 0.0 | 0.0 | 6.0 | +79.8 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 2.7 | +35.7 | 0.0 | 187.3 | 2.3 | +54.5 | 0.0 | 99.0 |
| MISSILES NEXT TURN | 4.3 | +24.4 | 0.0 | 187.3 | 3.0 | +81.7 | 0.0 | 99.0 |
| MOVE ORDER | 2.0 | +0.0 | 50.3 | 0.0 | 1.7 | +0.0 | 78.0 | 99.0 |
| MOVE SPELL SPOT | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 5.3 | +693.4 | 0.0 | 0.0 | 5.7 | +917.3 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 8.3 | +313.8 | 0.0 | 50.3 | 9.7 | +365.1 | 0.0 | 59.0 |
| NEXT CHARGE BY LIST | 3.0 | +399.9 | 0.0 | 0.0 | 4.3 | +714.5 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 3.3 | -77.3 | 235.7 | 0.0 | 2.7 | -120.3 | 46.7 | 0.0 |
| NO LATE CUT | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NO OLD ONE-MOVE GUESS | 5.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NO RALLY LEFT | - | - | - | - | 0.3 | +22.8 | 0.0 | 78.0 |
| NO SECOND RUN | 5.3 | +0.0 | 0.0 | 0.0 | 5.3 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | - | - | - | - | 0.3 | -0.7 | 0.0 | 0.0 |
| OFF BEST | 4.0 | -150.0 | 0.0 | 50.3 | 3.7 | -84.5 | 0.0 | 20.0 |
| ONE CHECK AFTER THE LAST CHANGE | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ONE FIGHT FORMULA | 6.0 | -159.5 | 0.0 | 133.3 | 3.3 | -86.6 | 0.0 | 78.0 |
| ONE JOINT FIGURE | 0.7 | +16.5 | 156.0 | 0.0 | - | - | - | - |
| ONE OBJECTIVE FORMULA | 5.0 | +56.4 | 0.0 | 0.0 | 3.3 | -152.0 | 0.0 | 22.0 |
| ONE ROUTE | 1.0 | +0.0 | 0.0 | 50.3 | 0.7 | +0.0 | 0.0 | 0.0 |
| OPENS UP | 0.3 | +15.4 | 0.0 | 0.0 | 0.3 | +11.9 | 23.3 | 0.0 |
| OVERRUNS AWAY | 1.0 | +132.0 | 45.3 | 0.0 | 1.0 | +2.4 | 46.7 | 0.0 |
| PATHS CROSS | - | - | - | - | 0.3 | +9.5 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | - | - | - | - | 0.3 | -5.7 | 0.0 | 0.0 |
| PLAN RESULT | 39.3 | +354.0 | 369.3 | 737.0 | 40.0 | +369.9 | 0.0 | 818.0 |
| PROMISE BY ITS OWN SUM | 9.0 | -207.8 | 0.0 | 0.0 | 7.0 | -117.2 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | 1.3 | -15.5 | 0.0 | 0.0 | - | - | - | - |
| PROMISE SHOT AWAY | 0.7 | -0.2 | 156.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | 5.3 | +524.1 | 0.0 | 0.0 | 8.7 | +1099.5 | 23.3 | 0.0 |
| REAL GROUND | 1.0 | +0.0 | 0.0 | 50.3 | 0.7 | +0.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | - | - | - | - | 3.7 | +161.5 | 0.0 | 57.3 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 4.0 | +0.0 | 0.0 | 57.3 |
| REDIRECT WEIGHED | - | - | - | - | 0.3 | -4.3 | 23.3 | 0.0 |
| REFORMS TO MEET IT | 2.3 | -124.2 | 0.0 | 0.0 | 2.0 | -61.1 | 0.0 | 0.0 |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| RESERVE FALL BACK | - | - | - | - | 0.3 | +23.3 | 0.0 | 0.0 |
| RISK BY ARC | 2.3 | -78.4 | 58.7 | 0.0 | 2.7 | -42.4 | 46.7 | 0.0 |
| RISK ON THE WAY | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| ROUNDS AFTER TERROR | 0.7 | -16.2 | 99.0 | 0.0 | 2.3 | -47.4 | 46.7 | 0.0 |
| RUN DOWN | 2.7 | -13.6 | 268.3 | 0.0 | 2.0 | -9.7 | 0.0 | 0.0 |
| SCOUT SPOT | - | - | - | - | 1.3 | -0.1 | 0.0 | 0.0 |
| SCOUT WAITS | - | - | - | - | 1.7 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 1.3 | -58.1 | 0.0 | 0.0 |
| SEARCH SPOT | 0.3 | +14.6 | 0.0 | 0.0 | - | - | - | - |
| SET CREDITED ONCE | 2.3 | -39.4 | 0.0 | 0.0 | 2.3 | -79.4 | 0.0 | 0.0 |
| SET UP BY THE SET | 2.3 | +62.0 | 0.0 | 0.0 | 4.7 | +36.0 | 23.3 | 0.0 |
| SET-UP ANY TARGET | 0.7 | +90.8 | 133.3 | 133.3 | - | - | - | - |
| SHOOTERS IN TWO RANKS | - | - | - | - | 0.7 | +2.0 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 7.7 | +0.0 | 0.0 | 285.7 | 6.7 | +0.0 | 0.0 | 199.3 |
| SHOOTS FROM THE BEST SPOT | 0.3 | +2.6 | 0.0 | 0.0 | 1.0 | +6.9 | 0.0 | 0.0 |
| SHOT OR CHARGE | 0.3 | -0.7 | 0.0 | 0.0 | - | - | - | - |
| SHOT RISK POINTS | 38.3 | +12.5 | 0.0 | 334.7 | 20.3 | +35.0 | 0.0 | 359.7 |
| SHOTS AFTER THE MOVES | 3.3 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 15.0 | +285.0 | 0.0 | 339.7 | 17.0 | +626.4 | 0.0 | 410.7 |
| SPELL SETS UP CHARGE | 0.7 | +90.8 | 133.3 | 133.3 | - | - | - | - |
| SPELL WORTH | 1.0 | +25.1 | 266.7 | 266.7 | 1.0 | +4.4 | 0.0 | 0.0 |
| SPELLS IN THE FIGHT | 0.3 | +3.8 | 78.0 | 0.0 | - | - | - | - |
| SPOT AS THE GAME MOVES | 4.7 | +0.0 | 0.0 | 0.0 | 7.7 | +0.0 | 0.0 | 0.0 |
| STAND AND SHOOT | 1.3 | -41.0 | 156.0 | 0.0 | 0.3 | -0.8 | 23.3 | 0.0 |
| STANDS FOR A REASON | 0.3 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 177.0 |
| STANDS STILL | 34.3 | +0.0 | 522.0 | 538.7 | 31.7 | +0.0 | 0.0 | 677.7 |
| STAY WORTH | 23.7 | +74.2 | 522.0 | 210.0 | 14.3 | +127.6 | 0.0 | 76.0 |
| SUPPORT ADDS | 3.7 | +181.5 | 0.0 | 0.0 | 3.0 | +158.8 | 0.0 | 0.0 |
| SUPPORT WORKED OUT | 3.7 | +181.5 | 0.0 | 0.0 | 3.0 | +158.8 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 1.0 | +0.0 | 0.0 | 50.3 | 1.3 | +0.0 | 0.0 | 0.0 |
| THE PROMISE ADDS | - | - | - | - | 0.3 | -4.2 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 1.7 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 1.7 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 99.0 |
| THE STEP BACK IS MADE | 0.3 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 61.7 |
| THE TABLE AGAIN | 5.3 | +0.0 | 0.0 | 0.0 | 5.3 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 39.3 | +0.0 | 0.0 | 490.7 | 43.3 | +0.0 | 0.0 | 755.7 |
| TIED UP BY THE SUM | 2.3 | +262.6 | 58.7 | 0.0 | 1.7 | +255.5 | 46.7 | 0.0 |
| TIME ON OUR SIDE | 43.3 | +479.3 | 44.0 | 882.7 | 26.3 | +243.3 | 0.0 | 435.7 |
| WAITS AGAIN | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WAR ENGINE JOBS | - | - | - | - | 3.7 | +0.0 | 0.0 | 185.0 |
| WEAPON BY POINTS | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| WHO FIGHTS | - | - | - | - | 0.7 | -5.2 | 0.0 | 0.0 |
| WHO HITS BACK | 0.3 | +26.9 | 0.0 | 0.0 | 0.7 | +157.9 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | 1.3 | -204.2 | 0.0 | 0.0 | 2.0 | -134.4 | 0.0 | 186.3 |
| WHOLE FIGHT GAIN | 0.7 | +53.6 | 156.0 | 0.0 | - | - | - | - |
| WOUNDS ON THE RANKS | - | - | - | - | 0.7 | +20.9 | 0.0 | 0.0 |

### Rule changes: cnomg-c940641-p44

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 144 | 144 | 118 | 39.33 | +3144 | +26.6 |
| HIS SHOT LIST | 350 | 336 | 83 | 27.67 | +2963 | +35.7 |
| HIS SHOTS BY HIS RUN | 260 | 252 | 81 | 27.00 | +829 | +10.2 |
| HIS MOVE AS HE DECIDES | 104 | 104 | 76 | 25.33 | +0 | +0.0 |
| HIS MOVE WHY | 61 | 61 | 47 | 15.67 | +0 | +0.0 |
| HOLDER ASSIGNMENT | 51 | 51 | 47 | 15.67 | +2882 | +61.3 |
| SHOT RISK POINTS | 176 | 171 | 41 | 13.67 | +1174 | +28.6 |
| DEPLOY BY FIGURES | 52 | 52 | 32 | 10.67 | +353 | +11.0 |
| THE TABLE AGAIN | 32 | 32 | 31 | 10.33 | +0 | +0.0 |
| LEGAL CHARGES ONLY | 27 | 27 | 27 | 9.00 | +0 | +0.0 |
| OFF BEST | 23 | 23 | 23 | 7.67 | -703 | -30.6 |
| TIME ON OUR SIDE | 209 | 185 | 21 | 7.00 | +75 | +3.6 |
| FIVE ACTION | 521 | 505 | 18 | 6.00 | +862 | +47.9 |
| MOVE TO CHARGE COMPUTED | 33 | 32 | 17 | 5.67 | +1445 | +85.0 |
| HIS ONE MOVE | 53 | 53 | 16 | 5.33 | +0 | +0.0 |
| PROMISE BY ITS OWN SUM | 48 | 48 | 15 | 5.00 | -975 | -65.0 |
| HARD STAY DROPPED | 13 | 13 | 13 | 4.33 | +0 | +0.0 |
| MEETS IN TIME | 28 | 28 | 13 | 4.33 | +486 | +37.4 |
| SET UP BY THE SET | 21 | 21 | 13 | 4.33 | +870 | +66.9 |
| ADVANCE LANE KEPT | 12 | 12 | 12 | 4.00 | +0 | +0.0 |
| REDIRECT FOR A FRIEND IN REACH | 12 | 12 | 12 | 4.00 | +0 | +0.0 |
| MOVE ORDER | 11 | 11 | 11 | 3.67 | +0 | +0.0 |
| TIED UP BY THE SUM | 12 | 12 | 11 | 3.67 | +465 | +42.3 |
| GOAL WALK | 45 | 45 | 10 | 3.33 | +417 | +41.7 |
| NEXT CHARGE BY LIST | 22 | 22 | 10 | 3.33 | +994 | +99.4 |
| COVER ONCE | 43 | 31 | 9 | 3.00 | +140 | +15.6 |
| FOUR ROUNDS | 19 | 19 | 9 | 3.00 | +348 | +38.6 |
| CHARGE LOSSES | 91 | 89 | 8 | 2.67 | +306 | +38.2 |
| LANE BY FIGURES | 8 | 8 | 8 | 2.67 | +308 | +38.5 |
| SHOTS IN THE MOVE | 96 | 85 | 7 | 2.33 | +250 | +35.8 |
| CHARGE NOW FIRST | 12 | 12 | 6 | 2.00 | -286 | -47.6 |
| SUPPORT ADDS | 20 | 18 | 6 | 2.00 | +253 | +42.1 |
| SUPPORT WORKED OUT | 20 | 18 | 6 | 2.00 | +253 | +42.1 |
| CHALLENGE BY POINTS | 5 | 5 | 5 | 1.67 | +296 | +59.1 |
| SCOUT WAITS | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| STAY WORTH | 114 | 108 | 5 | 1.67 | +73 | +14.7 |
| COMBAT PIVOT | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| ASSAILMENT BY POINTS | 3 | 3 | 3 | 1.00 | +17 | +5.5 |
| BOUND ASSAILMENT | 3 | 3 | 3 | 1.00 | +0 | +0.1 |
| CANNON SIGHT KEPT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| CAST JOB | 3 | 3 | 3 | 1.00 | +27 | +8.9 |
| CHAFF PASSED | 3 | 3 | 3 | 1.00 | -11 | -3.6 |
| EVASIVE BY THE ODDS | 5 | 5 | 3 | 1.00 | +150 | +50.0 |
| FALLS SHORT | 60 | 52 | 3 | 1.00 | +19 | +6.2 |
| FOLLOW UP WEIGHED | 3 | 3 | 3 | 1.00 | +691 | +230.5 |
| HIS TURN DENIED | 5 | 5 | 3 | 1.00 | +239 | +79.7 |
| IDLE COST | 45 | 32 | 3 | 1.00 | +11 | +3.6 |
| QUARTER ODDS | 42 | 41 | 3 | 1.00 | +478 | +159.3 |
| SHOOTS FROM THE BEST SPOT | 4 | 4 | 3 | 1.00 | +8 | +2.5 |
| SHOTS AFTER THE MOVES | 18 | 18 | 3 | 1.00 | +0 | +0.0 |
| WHO HITS BACK | 3 | 3 | 3 | 1.00 | +265 | +88.3 |
| WHOLE FIGHT DANGER | 10 | 10 | 3 | 1.00 | +133 | +44.3 |
| BEST PRIZE | 2 | 2 | 2 | 0.67 | -192 | -96.2 |
| HOLDS AMBUSHERS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| JOINT CHARGE NOW | 2 | 2 | 2 | 0.67 | +419 | +209.3 |
| MANOEUVRE | 11 | 11 | 2 | 0.67 | +6 | +3.2 |
| NEARER NOT NEEDED | 54 | 52 | 2 | 0.67 | +30 | +14.8 |
| PROMISE SHOT AWAY | 2 | 2 | 2 | 0.67 | -1 | -0.4 |
| SHOOTERS IN TWO RANKS | 2 | 2 | 2 | 0.67 | +6 | +3.0 |
| CHAFF IN THE MOVE | 2 | 1 | 1 | 0.33 | +0 | +0.0 |
| EXACT ROUND | 14 | 14 | 1 | 0.33 | +4 | +3.8 |
| FIRE IN ORDER | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FOCUS FIRE | 1 | 1 | 1 | 0.33 | +36 | +36.4 |
| LONE WIZARD KEPT IN | 1 | 1 | 1 | 0.33 | +112 | +112.5 |
| MARCH BY THE SUM | 1 | 1 | 1 | 0.33 | +40 | +39.8 |
| MARCH OF THE TABLE | 1 | 1 | 1 | 0.33 | -36 | -35.8 |
| MISSILES IN THE MOVE | 15 | 14 | 1 | 0.33 | +22 | +22.2 |
| NO DOUBLE ROUNDS | 18 | 18 | 1 | 0.33 | +114 | +113.8 |
| NO RALLY LEFT | 1 | 1 | 1 | 0.33 | +8 | +7.8 |
| OPENS UP | 2 | 2 | 1 | 0.33 | +18 | +18.5 |
| OVERRUNS AWAY | 6 | 6 | 1 | 0.33 | +91 | +90.6 |
| PATHS CROSS | 1 | 1 | 1 | 0.33 | +28 | +28.5 |
| PIVOT GUARDS FLANK | 1 | 1 | 1 | 0.33 | -17 | -17.1 |
| PROMISE READS THE TABLE | 4 | 4 | 1 | 0.33 | +4 | +4.1 |
| REDIRECT WEIGHED | 1 | 1 | 1 | 0.33 | -13 | -12.8 |
| RESERVE FALL BACK | 1 | 1 | 1 | 0.33 | +70 | +69.9 |
| RISK BY ARC | 15 | 15 | 1 | 0.33 | +24 | +24.1 |
| SEARCH SPOT | 1 | 1 | 1 | 0.33 | +44 | +43.7 |
| SET CREDITED ONCE | 14 | 14 | 1 | 0.33 | +8 | +8.5 |
| THE ROW IN ITS ORDER | 14 | 1 | 1 | 0.33 | +0 | +0.0 |
| WEAPON BY POINTS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| WHOLE FIGHT GAIN | 2 | 2 | 1 | 0.33 | +34 | +34.1 |
| BACKUP TARGETS | 1 | not checked | - | - | - | - |
| CANNON PLANNED TARGET | 9 | 9 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 4 | trace | - | - | - | - |
| CLOSES ON WHAT IT BEATS | 65 | 65 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 7 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 1 | 1 | 0 | 0.00 | - | - |
| EDGE GIVE GROUND | 1 | 1 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 14 | 14 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 7 | 7 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 39 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 35 | 34 | 0 | 0.00 | - | - |
| FRIEND CHARGES FIRST | 1 | 1 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 7 | 7 | 0 | 0.00 | - | - |
| GIVES UP | 2 | 2 | 0 | 0.00 | - | - |
| GUN FIGURES | 2 | not checked | - | - | - | - |
| GUN MASK | 3 | 3 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 28 | 27 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 62 | 61 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 43 | 42 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 31 | 31 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 23 | 22 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 11 | 11 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 36 | 36 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 32 | 32 | 0 | 0.00 | - | - |
| HIS TURN RUN | 33 | 33 | 0 | 0.00 | - | - |
| HOLD ODDS | 80 | 78 | 0 | 0.00 | - | - |
| HONEST WORTH | 17 | 17 | 0 | 0.00 | - | - |
| HUNT IN PAIRS | 4 | 4 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 12 | 12 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 2 | 2 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 7 | 7 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 1 | 1 | 0 | 0.00 | - | - |
| MARCH CHECK | 1 | 1 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 1 | 1 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 5 | 5 | 0 | 0.00 | - | - |
| MAX FOR POSITIONING | 10 | 8 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 22 | 20 | 0 | 0.00 | - | - |
| MOVE SPELL SPOT | 4 | not checked | - | - | - | - |
| NO LATE CUT | 2 | 2 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 17 | 17 | 0 | 0.00 | - | - |
| NO SECOND RUN | 32 | 32 | 0 | 0.00 | - | - |
| NOT TURNED | 1 | 1 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 1 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 2 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 28 | 18 | 0 | 0.00 | - | - |
| ONE JOINT FIGURE | 2 | 2 | 0 | 0.00 | - | - |
| ONE OBJECTIVE FORMULA | 25 | 21 | 0 | 0.00 | - | - |
| ONE ROUTE | 5 | 5 | 0 | 0.00 | - | - |
| PLAN RESULT | 238 | trace | - | - | - | - |
| PROMISE KNOWS THE FIGHT | 2 | 1 | 0 | 0.00 | - | - |
| REAL GROUND | 5 | 5 | 0 | 0.00 | - | - |
| REDIRECT COUNTER | 11 | 8 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 13 | 13 | 0 | 0.00 | - | - |
| REFUSING RETIRES | 1 | 1 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 2 | 2 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 9 | 9 | 0 | 0.00 | - | - |
| RUN DOWN | 14 | 14 | 0 | 0.00 | - | - |
| SCOUT SPOT | 4 | 4 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 4 | 4 | 0 | 0.00 | - | - |
| SET-UP ANY TARGET | 2 | not checked | - | - | - | - |
| SHOOTERS ON THE TABLE | 43 | not checked | - | - | - | - |
| SHOT OR CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 2 | not checked | - | - | - | - |
| SPELL WORTH | 6 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 37 | 31 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 5 | 5 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 10 | 7 | 0 | 0.00 | - | - |
| STANDS STILL | 198 | 188 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 7 | not checked | - | - | - | - |
| THE PROMISE ADDS | 1 | 1 | 0 | 0.00 | - | - |
| THE ROW KEEPS ITS WAY | 16 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 10 | not checked | - | - | - | - |
| THE TABLE BINDS | 248 | not checked | - | - | - | - |
| WAITS AGAIN | 2 | 2 | 0 | 0.00 | - | - |
| WAR ENGINE JOBS | 11 | 11 | 0 | 0.00 | - | - |
| WHO FIGHTS | 2 | 2 | 0 | 0.00 | - | - |
| WOUNDS ON THE RANKS | 2 | 2 | 0 | 0.00 | - | - |

### Off best figure: cnomg-c940641-p44

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| ARMY TABLE | rule | 3.00 | 3.33 | 32.6 |
| JOB FIRST | gate | 3.33 | 3.00 | 24.8 |
| PROMISE BY ITS OWN SUM | rule | 3.33 | 1.67 | 65.0 |
| CHARGE NOW FIRST | rule | 0.67 | 1.33 | 47.6 |
| HOLDER ASSIGNMENT | rule | 0.33 | 1.00 | 9.7 |
| CHAFF PASSED | rule | 1.00 | - | 3.6 |
| BEST PRIZE | rule | 0.33 | 0.33 | 96.2 |
| DEPLOY BY FIGURES | rule | - | 0.67 | 6.2 |
| RULE SWITCHED OFF | gate | - | 0.67 | 40.8 |
| FIGHT ORDER BAND | gate | 0.33 | - | 0.8 |
| MARCH OF THE TABLE | rule | 0.33 | - | 35.8 |
| NO REASON | gate | 0.33 | - | 150.0 |
| PIVOT GUARDS FLANK | rule | - | 0.33 | 17.1 |
| REDIRECT WEIGHED | rule | - | 0.33 | 12.8 |

### Plans: cnomg-c940641-p44

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 2.0 | 83% | 250 | 103 | 41% |
| Mine | move | 30.0 | 98% | 1346 | 0 | 0% |
| Mine | shoot | 7.3 | 50% | 209 | 251 | 120% |
| Opponent | charge | 2.3 | 43% | 261 | 68 | 26% |
| Opponent | move | 33.3 | 93% | 1822 | 0 | 0% |
| Opponent | shoot | 3.3 | 80% | 528 | 302 | 57% |
| Opponent | support | 1.0 | 100% | 0 | 0 | - |

### Battle groups: cnomg-c940641-p44

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | REDIRECT COUNTER | 3.7 | 45% | 60% | 0% | - | 0% | 0% | 0% | 80% | 20% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: cnomg-c940641-p44

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Character | 5 | 69 (5) | 69 | 0 | 20 | 0% | 1.2 | 20 (3) | 190 (1) | 47 (1) | 29 (4) | 190 (1) |
| Mine | Clean-up | 1 | 65 (1) | 0 | 65 | 0 | 0% | 5.0 | 65 (1) | - | - | 65 (1) | - |
| Mine | Fast Hammer | 8 | 36 (8) | 7 | 29 | 27 | 25% | 3.2 | 28 (5) | 50 (3) | - | 25 (6) | 68 (2) |
| Mine | Shooter | 3 | 13 (3) | 13 | 0 | 66 | 0% | 1.0 | 19 (2) | 0 (1) | - | 13 (3) | - |
| Mine | War machine | 2 | 0 (2) | 0 | 0 | 100 | 0% | 1.0 | 0 (2) | - | - | - | 0 (2) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Chaff | 7 | 176 (7) | 0 | 176 | 70 | 14% | 2.7 | - | 345 (4) | 16 (3) | 405 (4) | 14 (3) |
| Opponent | Character | 3 | 94 (3) | 94 | 0 | 21 | 0% | 1.3 | - | 94 (3) | - | 0 (1) | 118 (2) |
| Opponent | Clean-up | 2 | 0 (2) | 0 | 0 | 50 | 50% | 4.0 | 0 (1) | - | 0 (1) | 0 (1) | 0 (1) |
| Opponent | Fast Hammer | 2 | 0 (2) | 0 | 0 | 0 | 50% | 5.0 | 0 (1) | 0 (1) | - | 0 (1) | 0 (1) |
| Opponent | Hammer | 5 | 0 (5) | 0 | 0 | 62 | 0% | 2.6 | 0 (2) | 0 (3) | - | 0 (2) | 0 (3) |
| Opponent | Holder | 3 | 141 (3) | 0 | 141 | 31 | 0% | 3.0 | 450 (1) | 0 (1) | 0 (1) | 450 (1) | 0 (2) |
| Opponent | Shooter | 1 | 0 (1) | 0 | 0 | 0 | 0% | 2.0 | 0 (1) | - | - | - | 0 (1) |
| Opponent | Wizard | 2 | 0 (2) | 0 | 0 | 103 | 0% | 3.5 | 0 (1) | - | - | - | 0 (1) |

### Charged fights: cnomg-c940641-p44

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | High Elf Realms | 2 | 33 | 422 | 3.5 | 1.1 | 121 | 22 | +99 | 1 of 7 | 7 of 7 | +234 | +76 |
| Opponent | Ogre Kingdoms | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Tomb Kings of Khemri | 1 | 0 | 879 | 3.0 | 1.0 | 293 | 0 | +293 | 1 of 3 | 2 of 3 | - | +293 |
| **Opponent** | all armies | 2 | 0 | 440 | 1.5 | 1.0 | 293 | 0 | +293 | 1 of 3 | 2 of 3 | - | +293 |

### Effective charges: cnomg-c940641-p44

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | High Elf Realms | 7 | 0 | 0 | 0 | 0 | 5 (net +32) | 2 (net +266) | 0 | 0% (0 of 7) |
| Opponent | Tomb Kings of Khemri | 3 | 1 (net +0) | 0 | 0 | 0 | 0 | 0 | 2 | 0% (0 of 1) |

### Charged fights, damage counted: cnomg-c940641-p44

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 566 | 266 | +266 | 266 | 0 | +266 | +46.9 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 5 | 226 | 50 | +32 | 70 | 40 | +30 | +13.4 |
| Mine | All fights | 7 | 323 | 112 | +99 | 126 | 28 | +97 | +30.2 |
| Opponent | Long shot (under 50%) | 1 | 195 | 230 | +0 | 101 | 130 | -29 | -14.8 |
| Opponent | No odds | 2 | 436 | 235 | +440 | 460 | 0 | +460 | +105.6 |
| Opponent | All fights | 3 | 355 | 233 | +293 | 340 | 43 | +297 | +83.6 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| cnomg-c940641-p44 | move | 20 | 4 (20%) | 3 (15%) | 6 (30%) | 10 (50%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Fistful of Laurels | Opponent | L1418 |
| Opal Amulet | Mine | L1418, L1435 |
| Standard of the Fell Warrior | Mine | L1323 |

# Doctrine scorecard: cnomg-c940641-p27

### Scorecard: cnomg-c940641-p27

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0405 | 3 | 1 | Mine | no | 2 | 3 | 4 | 3 | 1 | 0 | 0 | 139 |
| L0405 | 3 | 1 | Opponent | no | 4 | - | 1 | 1 | 0 | 0 | 0 | 1193 |
| L0421 | 1 | 1 | Mine | no | 7 | 5 | 2 | 0 | 0 | 0 | 0 | 0 |
| L0421 | 1 | 1 | Opponent | no | 0 | - | 0 | 5 | 1 | 0 | 0 | 210 |
| L0508 | 4 | 1 | Mine | no | 7 | - | 0 | 2 | 0 | 0 | 0 | 380 |
| L0508 | 4 | 1 | Opponent | no | 0 | - | 0 | 3 | 0 | 0 | 0 | 560 |
| **Average** | | | Mine | 0% | 5.3 | 4.0 | 2.0 | 1.7 | 0.3 | 0.0 | 0.0 | 173.0 |
| **Average** | | | Opponent | 0% | 1.3 | - | 0.3 | 3.0 | 0.3 | 0.0 | 0.0 | 654.3 |

### KPIs: cnomg-c940641-p27

Rules off - Opponent only: NO OLD ONE-MOVE GUESS.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 11) | 62% (5 of 8) | 26% (5 of 19) |
| Winner chose to follow up after the loser gave ground |  | 50% (2 of 4); on the table 100% | 100% (2 of 2); on the table 100% | 67% (4 of 6); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | - | - | - |
| Winner chose to pursue after the loser fled |  | - | 0% (0 of 1); on the table 0% | 0% (0 of 1); on the table 0% |
| Winner chose to follow up or pursue (all three) |  | 50% (2 of 4); on the table 100% | 67% (2 of 3); on the table 67% | 57% (4 of 7); on the table 86% |
| Magic missiles tried each own turn | 50%+ | 42% (5 of 12) | 0% (0 of 6) | 28% (5 of 18) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 56% (5 of 9) | 0% (0 of 5) | 36% (5 of 14) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 38% (3 of 8) | 38% (3 of 8) |
| Points that never fought | lower | 80% (4821 of 5998) | 67% (4012 of 5999) | 74% (8833 of 11997) |
|   infantry points that never fought | lower | 87% (1235 of 1424) | 72% (1225 of 1703) | 79% (2460 of 3127) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 48% (11 of 23) | 65% (17 of 26) | 57% (28 of 49) |
| Bound items with a magic missile used (at least once a game) |  | 0.0 uses a game | 100% (1 of 1); 0.7 uses a game | 100% (1 of 1); 0.3 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0.0 uses a game | 50% (1 of 2); 0.3 uses a game | 50% (1 of 2); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 46% (2378 of 5120) | 60% (2819 of 4677) | 53% (5197 of 9797) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 0.7 (29%) | 0.3 (17%) | 1.0 (23%) |
| MARCHED: its unit marched | 0.7 (29%) | 1.3 (67%) | 2.0 (46%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.3 (17%) | 0.3 (8%) |
| GONE: slain | 1.0 (43%) | 0.0 (0%) | 1.0 (23%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 3.7 | 0.7 | 1.7 | 1.3 | 1.0 |
| not cast | 2.3 | 3.3 | 4.3 | 2.7 | 11.0 |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 2.0 (60%) | 1.0 (23%) | 0.0 (0%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 2.0 (46%) | 0.3 (12%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.0 (0%) | 0.3 (8%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | 1.0 (43%) | 1.0 (30%) | 1.0 (23%) | 1.0 (38%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.3 (50%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.3 (57%) | 0.3 (10%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 11.0 (100%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.7 a game | 0.0 a game | 0.3 a game |
| stood (cast and not dispelled) | 100% (2 of 2) | - | 100% (2 of 2) |
| the unit moved after it | 50% (1 of 2) | - | 50% (1 of 2) |
| it charged on its next turn | 0% (0 of 2) | - | 0% (0 of 2) |
| the enemy charged it first | 0% (0 of 2) | - | 0% (0 of 2) |
| it fought by the end of its next turn | 0% (0 of 2) | - | 0% (0 of 2) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 2) | - | 0% (0 of 2) |
| none of these (no charge, no fight, no charge escaped) | 100% (2 of 2) | - | 100% (2 of 2) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 65% (52 of 80) | 72% (76 of 105) | 69% (128 of 185) |
|   cavalry | 80% (8 of 10) | 0% (0 of 7) | 47% (8 of 17) |
|   character | 50% (5 of 10) | 86% (25 of 29) | 77% (30 of 39) |
|   chariot | 68% (15 of 22) | 50% (6 of 12) | 62% (21 of 34) |
|   infantry | 17% (2 of 12) | 52% (11 of 21) | 39% (13 of 33) |
|   war machine | 85% (22 of 26) | 94% (34 of 36) | 90% (56 of 62) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.3 (25%) | 1.7 (17%) | 4.0 (21%) |
| CHARGED: it charged | 0.3 (4%) | 0.0 (0%) | 0.3 (2%) |
| NO TARGET IN RANGE | 4.3 (46%) | 5.0 (52%) | 9.3 (49%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 2.3 (25%) | 2.3 (24%) | 4.7 (25%) |
| OTHER BAR | 0.0 (0%) | 0.7 (7%) | 0.7 (4%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 2.7 | 0.0 | 100% | 0.0 pts | 0 pts |
| character | 11.0 | 8.3 | 55% | 22.9 pts | 251 pts |
| chariot | 7.0 | 9.0 | 48% | 26.4 pts | 185 pts |
| infantry | 8.7 | 4.3 | 62% | 19.8 pts | 172 pts |
| war machine | 18.7 | 18.0 | 64% | 17.5 pts | 326 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 2.0 | 0.3 | 1.2 |
| Charges that made contact a game | 1.0 | 0.0 | 0.5 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.00 declared, 0.00 contact (2 units) | 0.00 declared, 0.00 contact (1 units) | 0.00 declared, 0.00 contact (3 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | - | - |
|   per unit a game, the other units (no war machines, no joined characters) | 0.27 declared, 0.14 contact (22 units) | 0.05 declared, 0.00 contact (22 units) | 0.16 declared, 0.07 contact (44 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 0% (0 of 3) | 100% (1 of 1) | - | 25% (1 of 4) |
| Character in a unit | 90% (9 of 10) | 50% (1 of 2) | - | 83% (10 of 12) |
| Character on its own | 100% (2 of 2) | 0% (0 of 2) | 100% (3 of 3) | 71% (5 of 7) |
| Chariot | 50% (1 of 2) | 40% (2 of 5) | - | 43% (3 of 7) |
| Infantry | 62% (5 of 8) | 20% (1 of 5) | 0% (0 of 1) | 43% (6 of 14) |
| Monster | - | 0% (0 of 1) | - | 0% (0 of 1) |
| War Machines | 75% (3 of 4) | - | - | 75% (3 of 4) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Chaos Dwarfs | 2 | 50% (2 of 4); on the table 100% | 42% (5 of 12) | 71% | 38% (6 of 16) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Dwarfen Mountain Holds | 2 | 50% (1 of 2); on the table 50% | - | 67% | 64% (9 of 14) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 1 | - | - | 100% | 70% (7 of 10) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Skaven | 1 | 100% (1 of 1); on the table 100% | 0% (0 of 6) | 67% | 67% (6 of 9) | 100% (1 of 1); 2.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |

Flank and rear charges a unit could have turned to face (cnomg-c940641-p27, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | - | 100% (1) | 100% (1) |
| ...free all their last turn and able to turn (per game) | 0.00 | 0.33 | 0.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.33 | 0.33 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.33 | 0.33 |

### Quality by phase: cnomg-c940641-p27

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.7 | 2.0 |
| Strategy | Charge objectives carried out (made contact) | 20% (1 of 5) | 0% (0 of 1) |
| Strategy | Shoot objectives carried out (shot that target) | 58% (18 of 31) | 66% (27 of 41) |
| Strategy | Support requests answered (helper made contact too) | 0% (0 of 1) | - |
| Strategy | Joined characters whose unit fought | 0% (0 of 5) | 60% (6 of 10) |
| Strategy | Lone characters that fought | 33% (2 of 6) | 20% (1 of 5) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 1.7 | 3.0 |
| Movement | Points that never moved of their own | 173.0 | 654.3 |
| Movement | Fights charged into per game | 1.0 | 0.0 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 2 | - |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 2 | - |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 2 | - |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 of 2, net +270 | - |
| Shooting | Shots by shooting units (incl. breath weapons) | 10.0 | 15.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 43% (13 of 30) | 69% (31 of 45) |
| Shooting | Points destroyed by shooting units | 195.7 | 334.0 |
| Shooting | War machine shots | 7.3 | 11.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 23% (5 of 22) | 50% (17 of 34) |
| Shooting | Points destroyed by war machines | 176.0 | 68.0 |
| Magic | Magic missiles cast | 1.0 | - |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 0% (0 of 3) | - |
| Magic | Wounds caused by magic missiles | 3.3 | - |
| Magic | Wounds caused by other spells | - | 1.7 |
| Magic | Points destroyed by magic (all spells) | 0.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.0 / 0.0 / 0.0 / 1.3 | 1.3 / 0.0 / 1.0 / 0.0 |
| Combat | Points destroyed in combat | 180.0 | 21.7 |
| Combat | Points run down | 0.0 | 0.0 |
| Combat | Net points per charged fight, damage counted | +96 | - |
| Combat | Net per 100 charger points, damage counted | +29.1 | - |
| Combat | First round won (charged fights) | 33% | - |
| Combat | Net points per charged fight | +180 | - |
| Combat | Net points per supported fight / lone fight | - / +180 | - / - |
| Combat | Charged fights on a top-3 enemy unit | 3 of 3 | - |
| Game | Points lost | 453.7 | 765.7 |
| Game | VP from objectives | 970.0 | 790.0 |
| Game | Lone holders (player turns) | 5.3 | 1.3 |

- Mine won / drew / lost: 2 / 0 / 1 of 3 ended games (of 3); mean margin (Mine - Opponent) +492 VP
- The side that went first won 2 of 3 games with a winner
- Points traded per game (both sides' losses): 1219
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: cnomg-c940641-p27

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.3 | +6.9 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | 13.0 | +446.2 | 0.0 | 196.0 | 10.7 | +24.4 | 0.0 | 322.7 |
| ARTILLERY RE-ROLL WEIGHED | 1.7 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 43.3 |
| ASSAILMENT BY POINTS | - | - | - | - | 0.7 | +3.8 | 0.0 | 360.0 |
| CANNON PLAN MISSED | 1.7 | +0.0 | 233.3 | 31.7 | 2.0 | +0.0 | 661.3 | 0.0 |
| CANNON PLANNED TARGET | 6.7 | +26.8 | 565.3 | 95.0 | 11.3 | +346.3 | 1252.0 | 190.0 |
| CANNON SIGHT KEPT | 1.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | - | - | - | - | 1.3 | +10.2 | 0.0 | 30.3 |
| CHAFF PASSED | 0.3 | -5.4 | 0.0 | 0.0 | - | - | - | - |
| CHALLENGE BY POINTS | 0.3 | +5.7 | 0.0 | 0.0 | - | - | - | - |
| CHARACTER GUNS | 3.3 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| CHARGE LOSSES | 18.7 | -838.9 | 0.0 | 244.0 | 9.7 | -974.0 | 0.0 | 553.7 |
| CHARGE NOW FIRST | 1.7 | +0.0 | 211.7 | 0.0 | - | - | - | - |
| CLOSES ON WHAT IT BEATS | 12.7 | +0.0 | 0.0 | 43.3 | 4.3 | +0.0 | 0.0 | 37.3 |
| COMBAT PIVOT | 0.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 430.0 |
| CONVEYANCE SEARCH | 0.7 | +37.8 | 46.3 | 0.0 | - | - | - | - |
| COVER ONCE | 4.7 | -109.5 | 0.0 | 262.3 | 4.0 | -307.0 | 0.0 | 180.0 |
| DENIED BY THE FIGHT | 0.3 | -0.2 | 0.0 | 0.0 | 0.3 | -0.4 | 37.3 | 0.0 |
| DEPLOY BY FIGURES | 8.7 | +40.3 | 0.0 | 0.0 | 9.0 | -53.5 | 0.0 | 135.0 |
| DUEL STOPS AT THE KILL | 0.3 | -100.0 | 0.0 | 0.0 | - | - | - | - |
| EXACT ROUND | 1.3 | +27.2 | 211.7 | 0.0 | 0.3 | +0.5 | 37.3 | 0.0 |
| FALL BACK GOOD ORDER | 1.0 | +0.0 | 180.0 | 0.0 | 0.3 | +0.0 | 37.3 | 0.0 |
| FALLS SHORT | 8.3 | +125.2 | 0.0 | 426.7 | 8.0 | +127.8 | 0.0 | 74.7 |
| FEATURE BUFFS | - | - | - | - | 1.3 | +17.5 | 0.0 | 0.0 |
| FIRE IN ORDER | 1.3 | +0.0 | 41.7 | 31.7 | 0.7 | +0.0 | 0.0 | 0.0 |
| FIVE ACTION | 92.0 | +8146.8 | 1708.3 | 1181.3 | 84.0 | +4072.7 | 3913.3 | 1578.0 |
| FLANK NOT WEIGHED | 1.7 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 260.7 |
| FOLLOW UP WEIGHED | 0.7 | +160.3 | 0.0 | 0.0 | 0.7 | +87.9 | 0.0 | 70.0 |
| FOUR ROUNDS | 2.0 | +330.7 | 211.7 | 37.3 | 0.3 | +4.6 | 37.3 | 0.0 |
| FRIEND SHOOTS FIRST | 0.3 | -1.8 | 0.0 | 0.0 | - | - | - | - |
| GOAL WALK | 14.0 | +2054.3 | 0.0 | 43.3 | 3.0 | +87.8 | 0.0 | 0.0 |
| GUN FIGURES | 4.3 | +39.8 | 91.7 | 103.3 | 1.3 | +0.9 | 0.0 | 0.0 |
| HARD STAY DROPPED | 2.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 4.7 | +0.0 | 0.0 | 37.3 | 6.0 | +0.0 | 0.0 | 419.0 |
| HIS CHARGE LIST | 0.7 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 155.7 |
| HIS LEGAL MOVES | 3.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 21.7 |
| HIS MOVE AND SHOT | 1.7 | -29.9 | 0.0 | 0.0 | 2.7 | -175.6 | 0.0 | 43.3 |
| HIS MOVE AS HE DECIDES | - | - | - | - | 38.3 | +11.7 | 757.7 | 0.0 |
| HIS MOVE WHY | 11.0 | +0.0 | 0.0 | 43.3 | - | - | - | - |
| HIS ONE MOVE | - | - | - | - | 15.7 | +25.5 | 0.0 | 360.0 |
| HIS ONE QUARTER | 4.0 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 48.3 |
| HIS OWN BEST MOVE | 6.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS RANDOM MOVE | 5.7 | +0.0 | 0.0 | 43.3 | - | - | - | - |
| HIS RANDOM MOVER COMES | 1.3 | +0.0 | 0.0 | 43.3 | - | - | - | - |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 47.0 | +1975.1 | 0.0 | 274.0 | 33.3 | +1340.4 | 0.0 | 444.3 |
| HIS SHOTS BY HIS RUN | 34.3 | +846.8 | 0.0 | 460.7 | 26.0 | +535.3 | 0.0 | 441.0 |
| HIS TURN DENIED | 1.0 | +59.3 | 31.7 | 37.3 | 0.3 | +1.0 | 37.3 | 0.0 |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 15.0 | +0.0 | 0.0 | 74.7 | 15.3 | +0.0 | 0.0 | 0.0 |
| HOLDER ASSIGNMENT | 9.7 | +1142.2 | 0.0 | 74.7 | 9.7 | +822.2 | 0.0 | 67.3 |
| HOLDS AMBUSHERS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 1.3 | -34.1 | 211.7 | 0.0 | 0.3 | -0.6 | 37.3 | 0.0 |
| HUNT IN PAIRS | 0.7 | +127.3 | 0.0 | 0.0 | - | - | - | - |
| IDLE COST | 6.3 | -93.9 | 0.0 | 261.3 | 9.0 | -119.0 | 0.0 | 110.3 |
| JOINT CHARGE NOW | 0.7 | -140.1 | 0.0 | 37.3 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 1.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 1.3 | +36.6 | 0.0 | 0.0 | - | - | - | - |
| LEGAL CHARGES ONLY | 1.0 | +0.0 | 320.0 | 21.7 | 0.3 | +0.0 | 0.0 | 180.0 |
| LONE WIZARD KEPT IN | - | - | - | - | 0.7 | +63.4 | 0.0 | 0.0 |
| LONG SHOT | 0.3 | +2.1 | 0.0 | 0.0 | 0.3 | +3.7 | 37.3 | 0.0 |
| LOST AFTER ESCAPE | 0.7 | +8.6 | 0.0 | 0.0 | 0.3 | +1.5 | 37.3 | 0.0 |
| LURE BY WHAT IT DRAWS | - | - | - | - | 0.3 | -17.3 | 0.0 | 18.3 |
| MAKE SURE TOGETHER | 0.7 | +56.0 | 0.0 | 37.3 | - | - | - | - |
| MANOEUVRE | 2.0 | -2.4 | 0.0 | 103.3 | 1.0 | +3.1 | 0.0 | 0.0 |
| MARCH AT ESCAPER | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| MARCH BY THE SUM | - | - | - | - | 0.3 | +32.4 | 0.0 | 180.0 |
| MARCH CHECK | 1.0 | +93.0 | 0.0 | 0.0 | - | - | - | - |
| MARCH OF THE TABLE | 0.3 | +17.4 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 0.7 | +3.5 | 0.0 | 0.0 | 0.7 | +134.0 | 0.0 | 180.0 |
| MARCH WHEELS ONLY | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 2.0 | +123.4 | 0.0 | 0.0 | 0.7 | +0.8 | 0.0 | 0.0 |
| MEETS IN TIME | 2.7 | +300.6 | 0.0 | 0.0 | 3.7 | +178.8 | 0.0 | 41.7 |
| MISSILES IN THE MOVE | 1.7 | +20.2 | 0.0 | 193.3 | 1.0 | +9.9 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 2.7 | +32.1 | 0.0 | 193.3 | 3.0 | +9.9 | 0.0 | 180.0 |
| MOVE ORDER | 3.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| MOVE SPELL IN RANGE | 2.3 | +109.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 2.3 | -96.8 | 0.0 | 193.3 | - | - | - | - |
| MOVE SPELL SPOT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 5.3 | +995.8 | 0.0 | 0.0 | - | - | - | - |
| NEARER NOT NEEDED | 5.0 | +210.7 | 0.0 | 37.3 | 5.7 | +230.8 | 0.0 | 37.3 |
| NEXT CHARGE BY LIST | 4.7 | +997.3 | 0.0 | 0.0 | - | - | - | - |
| NO DOUBLE ROUNDS | 2.0 | -87.7 | 211.7 | 37.3 | 0.3 | -4.1 | 37.3 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | - | - | - | - | 0.3 | -0.2 | 0.0 | 0.0 |
| OFF BEST | 5.0 | -200.0 | 0.0 | 31.7 | 3.0 | -82.2 | 0.0 | 41.7 |
| ONE FIGHT FORMULA | 4.7 | -114.8 | 0.0 | 103.3 | 0.7 | -5.6 | 0.0 | 0.0 |
| ONE JOINT FIGURE | 0.7 | +43.4 | 0.0 | 37.3 | - | - | - | - |
| ONE OBJECTIVE FORMULA | 2.3 | +83.4 | 0.0 | 37.3 | 4.0 | -36.4 | 0.0 | 0.0 |
| ONE PROMISE A TARGET | 0.3 | -118.0 | 0.0 | 0.0 | - | - | - | - |
| ONE ROUTE | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| OVERRUNS AWAY | 1.0 | +11.6 | 211.7 | 0.0 | 0.3 | +2.2 | 37.3 | 0.0 |
| PATHS CROSS | 0.7 | -18.9 | 0.0 | 0.0 | 0.3 | +1.8 | 0.0 | 21.7 |
| PERIAPT WORTH | - | - | - | - | 0.3 | +40.5 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.3 | -83.0 | 0.0 | 193.3 | - | - | - | - |
| PLAN RESULT | 41.0 | +667.2 | 498.3 | 884.3 | 40.0 | +1872.4 | 819.3 | 1162.7 |
| PROMISE BELOW ZERO | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE BY ITS OWN SUM | 9.7 | -401.0 | 0.0 | 0.0 | 1.0 | -20.8 | 0.0 | 0.0 |
| PROMISE SHOT AWAY | 0.7 | -6.1 | 96.7 | 0.0 | - | - | - | - |
| QUARTER ODDS | 24.3 | +2803.9 | 491.3 | 63.3 | 21.3 | +2184.6 | 826.7 | 578.3 |
| RANDOM MOVE BY FIGURES | - | - | - | - | 2.7 | +27.8 | 0.0 | 215.0 |
| REAL GROUND | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | 0.3 | +36.3 | 0.0 | 21.7 | 1.0 | +42.2 | 0.0 | 40.0 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 1.0 | +0.0 | 0.0 | 43.3 |
| REDIRECT WEIGHED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| REFUSING RETIRES | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| RISK BY ARC | 1.7 | -19.9 | 211.7 | 37.3 | 0.3 | -2.0 | 37.3 | 0.0 |
| ROUNDS AFTER TERROR | 0.7 | -12.8 | 31.7 | 0.0 | - | - | - | - |
| RUN DOWN | 1.0 | -24.0 | 0.0 | 0.0 | 0.3 | -3.0 | 37.3 | 0.0 |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 1.3 | -166.9 | 0.0 | 0.0 |
| SECOND LOOK | 0.3 | +0.6 | 0.0 | 0.0 | - | - | - | - |
| SET CREDITED ONCE | 2.3 | -387.7 | 0.0 | 0.0 | 0.7 | -2.0 | 0.0 | 21.7 |
| SET UP BY THE SET | 3.0 | +283.0 | 0.0 | 0.0 | 1.0 | +7.7 | 0.0 | 21.7 |
| SET UP TOGETHER | 0.7 | +56.0 | 0.0 | 37.3 | - | - | - | - |
| SET-UP ANY TARGET | 0.3 | +45.2 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | 0.7 | +1.3 | 0.0 | 0.0 | 0.7 | +1.3 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 8.7 | +0.0 | 0.0 | 288.3 | 14.3 | +0.0 | 0.0 | 230.0 |
| SHOOTS FROM THE BEST SPOT | 1.0 | +234.1 | 0.0 | 386.7 | - | - | - | - |
| SHORT GUN FORWARD | - | - | - | - | 0.3 | +0.0 | 0.0 | 45.0 |
| SHOT OR CHARGE | 0.3 | -0.7 | 0.0 | 0.0 | - | - | - | - |
| SHOT RISK POINTS | 30.0 | +353.0 | 0.0 | 394.0 | 16.7 | -89.4 | 0.0 | 527.7 |
| SHOTS AFTER THE MOVES | 2.7 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 17.3 | +388.3 | 0.0 | 267.3 | 20.7 | +904.5 | 0.0 | 233.3 |
| SPELL SETS UP CHARGE | 0.3 | +45.2 | 0.0 | 0.0 | - | - | - | - |
| SPELL WORTH | - | - | - | - | 3.7 | +84.7 | 360.0 | 360.0 |
| SPOT AS THE GAME MOVES | 5.7 | +0.0 | 0.0 | 0.0 | 5.0 | +0.0 | 0.0 | 188.3 |
| STAND AND SHOOT | 0.3 | -3.6 | 0.0 | 37.3 | 0.3 | -0.4 | 37.3 | 0.0 |
| STANDS FOR A REASON | 0.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 44.0 | +0.0 | 1496.7 | 879.3 | 48.3 | +0.0 | 3876.0 | 676.3 |
| STAY WORTH | 28.7 | +283.6 | 1060.7 | 362.3 | 37.3 | +87.4 | 2983.3 | 702.3 |
| STRIKE BY THE ODDS | 0.3 | +15.1 | 0.0 | 0.0 | - | - | - | - |
| STUCK PIVOT | - | - | - | - | 1.0 | +0.0 | 0.0 | 48.3 |
| SUPPORT ADDS | - | - | - | - | 2.7 | +206.8 | 0.0 | 43.3 |
| SUPPORT WORKED OUT | - | - | - | - | 2.7 | +206.8 | 0.0 | 43.3 |
| SURE REACH TOGETHER | 0.7 | +58.6 | 0.0 | 37.3 | - | - | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 1.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| THE PROMISE ADDS | 0.7 | -134.8 | 0.0 | 0.0 | - | - | - | - |
| THE PROMISED MOVE | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 3.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 21.7 |
| THE ROW KEEPS ITS WAY | 4.3 | +0.0 | 0.0 | 21.7 | 4.3 | +0.0 | 0.0 | 80.7 |
| THE STEP BACK IS MADE | 3.7 | +0.0 | 0.0 | 21.7 | 3.0 | +0.0 | 0.0 | 80.7 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 43.3 | +0.0 | 0.0 | 540.3 | 40.0 | +0.0 | 0.0 | 623.3 |
| TIED UP BY THE SUM | 0.3 | +29.8 | 31.7 | 0.0 | - | - | - | - |
| TIME ON OUR SIDE | 23.7 | +333.3 | 269.3 | 86.7 | 14.3 | +209.4 | 0.0 | 110.7 |
| WAITS AGAIN | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| WALKS ON ITS ROUTE | - | - | - | - | 0.3 | -20.0 | 0.0 | 67.3 |
| WAR ENGINE JOBS | 1.7 | +0.0 | 96.7 | 0.0 | - | - | - | - |
| WHO FIGHTS | 0.7 | +4.6 | 0.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT DANGER | 1.0 | -66.2 | 0.0 | 0.0 | 2.0 | -648.1 | 0.0 | 360.0 |
| WHOLE FIGHT GAIN | 0.7 | +184.0 | 0.0 | 37.3 | - | - | - | - |
| WOUNDS ON THE RANKS | 2.7 | +199.1 | 0.0 | 0.0 | 0.7 | +9.1 | 0.0 | 134.7 |

### Rule changes: cnomg-c940641-p27

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS MOVE AS HE DECIDES | 115 | 115 | 80 | 26.67 | +0 | +0.0 |
| ARMY TABLE | 71 | 71 | 58 | 19.33 | +1498 | +25.8 |
| HOLDER ASSIGNMENT | 58 | 58 | 54 | 18.00 | +3222 | +59.7 |
| HIS SHOTS BY HIS RUN | 181 | 173 | 48 | 16.00 | +778 | +16.2 |
| HIS SHOT LIST | 241 | 231 | 42 | 14.00 | +514 | +12.2 |
| DEPLOY BY FIGURES | 53 | 53 | 38 | 12.67 | +613 | +16.1 |
| OFF BEST | 24 | 24 | 24 | 8.00 | -846 | -35.3 |
| GOAL WALK | 51 | 43 | 22 | 7.33 | +2782 | +126.4 |
| THE TABLE AGAIN | 36 | 36 | 19 | 6.33 | +0 | +0.0 |
| HIS ONE MOVE | 47 | 47 | 18 | 6.00 | +0 | +0.0 |
| SHOT RISK POINTS | 140 | 133 | 18 | 6.00 | +396 | +22.0 |
| MOVE ORDER | 15 | 15 | 15 | 5.00 | +0 | +0.0 |
| ARTILLERY RE-ROLL WEIGHED | 14 | 14 | 14 | 4.67 | +0 | +0.0 |
| PROMISE BY ITS OWN SUM | 32 | 32 | 14 | 4.67 | -1265 | -90.4 |
| QUARTER ODDS | 137 | 137 | 14 | 4.67 | +1586 | +113.3 |
| TIME ON OUR SIDE | 114 | 95 | 14 | 4.67 | +10 | +0.7 |
| IDLE COST | 46 | 38 | 12 | 4.00 | +49 | +4.0 |
| FIVE ACTION | 528 | 515 | 10 | 3.33 | +710 | +71.0 |
| ADVANCE LANE KEPT | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| HARD STAY DROPPED | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| SET UP BY THE SET | 12 | 12 | 9 | 3.00 | +1049 | +116.5 |
| CANNON PLANNED TARGET | 54 | 54 | 8 | 2.67 | -59 | -7.4 |
| HIS MOVE WHY | 33 | 33 | 8 | 2.67 | +0 | +0.0 |
| MOVE TO CHARGE COMPUTED | 16 | 16 | 8 | 2.67 | +940 | +117.5 |
| FIRE IN ORDER | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| STAY WORTH | 198 | 173 | 6 | 2.00 | +131 | +21.9 |
| CANNON SIGHT KEPT | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| MEETS IN TIME | 19 | 19 | 5 | 1.67 | +199 | +39.8 |
| NEXT CHARGE BY LIST | 14 | 14 | 5 | 1.67 | +935 | +187.0 |
| COMBAT PIVOT | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 4 | 4 | 4 | 1.33 | +744 | +186.1 |
| FOUR ROUNDS | 7 | 6 | 4 | 1.33 | +380 | +94.9 |
| LANE BY FIGURES | 4 | 4 | 4 | 1.33 | +110 | +27.4 |
| LEGAL CHARGES ONLY | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| SHOOTERS IN TWO RANKS | 4 | 4 | 4 | 1.33 | +8 | +2.0 |
| CHAFF IN THE MOVE | 4 | 4 | 3 | 1.00 | +0 | +0.0 |
| PATHS CROSS | 3 | 3 | 3 | 1.00 | -51 | -17.1 |
| RANDOM MOVE BY FIGURES | 8 | 8 | 3 | 1.00 | +83 | +27.8 |
| REDIRECT FOR A FRIEND IN REACH | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| STUCK PIVOT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| SUPPORT ADDS | 8 | 8 | 3 | 1.00 | +210 | +69.9 |
| SUPPORT WORKED OUT | 8 | 8 | 3 | 1.00 | +210 | +69.9 |
| ASSAILMENT BY POINTS | 2 | 2 | 2 | 0.67 | +12 | +5.8 |
| CHARGE LOSSES | 85 | 78 | 2 | 0.67 | +487 | +243.7 |
| FALLS SHORT | 49 | 42 | 2 | 0.67 | +22 | +10.8 |
| HIS TURN DENIED | 4 | 4 | 2 | 0.67 | +25 | +12.4 |
| HOLDS AMBUSHERS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| JOINT CHARGE NOW | 2 | 2 | 2 | 0.67 | -420 | -210.1 |
| LONE WIZARD KEPT IN | 2 | 2 | 2 | 0.67 | +190 | +95.2 |
| MANOEUVRE | 9 | 9 | 2 | 0.67 | +14 | +6.9 |
| MAX FOR POSITIONING | 8 | 5 | 2 | 0.67 | +59 | +29.4 |
| OVERRUNS AWAY | 4 | 4 | 2 | 0.67 | +25 | +12.4 |
| PROMISE SHOT AWAY | 2 | 2 | 2 | 0.67 | -19 | -9.3 |
| SHOOTS FROM THE BEST SPOT | 3 | 3 | 2 | 0.67 | +115 | +57.6 |
| SHOTS IN THE MOVE | 114 | 76 | 2 | 0.67 | +9 | +4.6 |
| SURE REACH TOGETHER | 2 | 2 | 2 | 0.67 | +27 | +13.3 |
| WHOLE FIGHT GAIN | 2 | 2 | 2 | 0.67 | +264 | +132.2 |
| AFTERMATH IN POINTS | 1 | 1 | 1 | 0.33 | +21 | +20.7 |
| CHAFF PASSED | 1 | 1 | 1 | 0.33 | -16 | -16.1 |
| CHALLENGE BY POINTS | 1 | 1 | 1 | 0.33 | +17 | +17.0 |
| CHARGE NOW FIRST | 5 | 5 | 1 | 0.33 | -25 | -25.1 |
| EXACT ROUND | 5 | 4 | 1 | 0.33 | +1 | +1.3 |
| HONEST WORTH | 5 | 4 | 1 | 0.33 | +24 | +23.5 |
| HUNT IN PAIRS | 2 | 1 | 1 | 0.33 | +185 | +185.4 |
| LONG SHOT | 2 | 1 | 1 | 0.33 | +1 | +1.3 |
| LOST AFTER ESCAPE | 3 | 3 | 1 | 0.33 | +1 | +1.3 |
| MARCH BY THE SUM | 1 | 1 | 1 | 0.33 | +97 | +97.3 |
| MARCH CHECK | 3 | 2 | 1 | 0.33 | +7 | +6.6 |
| MARCH OF THE TABLE | 1 | 1 | 1 | 0.33 | -52 | -52.3 |
| ONE FIGHT FORMULA | 16 | 6 | 1 | 0.33 | +42 | +42.3 |
| ONE JOINT FIGURE | 2 | 2 | 1 | 0.33 | +26 | +25.9 |
| ONE OBJECTIVE FORMULA | 19 | 10 | 1 | 0.33 | +28 | +28.1 |
| ONE PROMISE A TARGET | 1 | 1 | 1 | 0.33 | -354 | -354.0 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.33 | +122 | +121.5 |
| PIVOT GUARDS FLANK | 1 | 1 | 1 | 0.33 | -249 | -249.0 |
| REDIRECT COUNTER | 4 | 3 | 1 | 0.33 | +56 | +56.4 |
| REDIRECT WEIGHED | 1 | 1 | 1 | 0.33 | +106 | +106.4 |
| REFUSING RETIRES | 1 | 1 | 1 | 0.33 | -13 | -13.1 |
| SECOND LOOK | 1 | 1 | 1 | 0.33 | +2 | +1.9 |
| SHORT GUN FORWARD | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| SHOTS AFTER THE MOVES | 20 | 20 | 1 | 0.33 | +0 | +0.0 |
| STRIKE BY THE ODDS | 1 | 1 | 1 | 0.33 | +45 | +45.2 |
| TIED UP BY THE SUM | 1 | 1 | 1 | 0.33 | +24 | +23.5 |
| WALKS ON ITS ROUTE | 1 | 1 | 1 | 0.33 | -60 | -60.0 |
| WAR ENGINE JOBS | 5 | 5 | 1 | 0.33 | -4 | -3.7 |
| CANNON PLAN MISSED | 11 | 11 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 1 | trace | - | - | - | - |
| CHARACTER GUNS | 28 | 28 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 51 | 48 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 2 | not checked | - | - | - | - |
| COVER ONCE | 26 | 15 | 0 | 0.00 | - | - |
| DENIED BY THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 1 | 1 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 4 | 4 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 4 | 4 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 17 | not checked | - | - | - | - |
| FRIEND SHOOTS FIRST | 1 | 1 | 0 | 0.00 | - | - |
| GUN FIGURES | 17 | not checked | - | - | - | - |
| HIS CHARGE BY HIS RUN | 32 | 31 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 10 | 10 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 10 | 8 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 13 | 12 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 17 | 17 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 19 | 17 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 17 | 15 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 4 | 4 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN RUN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 91 | 90 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 6 | 5 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 1 | 1 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 2 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 4 | 4 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 2 | 2 | 0 | 0.00 | - | - |
| MISSILES IN THE MOVE | 8 | 2 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 17 | 9 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 7 | 1 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 7 | trace | - | - | - | - |
| MOVE SPELL SPOT | 1 | not checked | - | - | - | - |
| NEARER NOT NEEDED | 32 | 30 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 7 | 6 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 18 | 18 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT TURNED | 1 | 1 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 1 | not checked | - | - | - | - |
| ONE ROUTE | 2 | 2 | 0 | 0.00 | - | - |
| PLAN RESULT | 243 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 1 | 1 | 0 | 0.00 | - | - |
| REAL GROUND | 2 | 2 | 0 | 0.00 | - | - |
| RISK BY ARC | 6 | 5 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 2 | 2 | 0 | 0.00 | - | - |
| RUN DOWN | 4 | 3 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 4 | 4 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 9 | 9 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 2 | 2 | 0 | 0.00 | - | - |
| SET-UP ANY TARGET | 1 | not checked | - | - | - | - |
| SHOOTERS ON THE TABLE | 69 | not checked | - | - | - | - |
| SHOT OR CHARGE | 1 | not checked | - | - | - | - |
| SPELL SETS UP CHARGE | 1 | not checked | - | - | - | - |
| SPELL WORTH | 11 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 32 | 22 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 2 | 2 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 6 | 6 | 0 | 0.00 | - | - |
| STANDS STILL | 277 | 276 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 5 | not checked | - | - | - | - |
| THE PROMISE ADDS | 2 | 2 | 0 | 0.00 | - | - |
| THE PROMISED MOVE | 1 | not checked | - | - | - | - |
| THE ROW IN ITS ORDER | 12 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 26 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 20 | not checked | - | - | - | - |
| THE TABLE BINDS | 250 | not checked | - | - | - | - |
| WAITS AGAIN | 4 | 3 | 0 | 0.00 | - | - |
| WHO FIGHTS | 2 | 1 | 0 | 0.00 | - | - |
| WHOLE FIGHT DANGER | 9 | 9 | 0 | 0.00 | - | - |
| WOUNDS ON THE RANKS | 10 | 10 | 0 | 0.00 | - | - |

### Off best figure: cnomg-c940641-p27

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 4.00 | 3.00 | 36.3 |
| PROMISE BY ITS OWN SUM | rule | 4.33 | 0.33 | 90.4 |
| ARMY TABLE | rule | 1.00 | 1.00 | 72.8 |
| CANNON PLANNED TARGET | rule | - | 1.33 | 14.8 |
| NO REASON | gate | 1.00 | - | 27.7 |
| PATHS CROSS | rule | 0.67 | - | 28.3 |
| PROMISE SHOT AWAY | rule | 0.67 | - | 9.3 |
| CHAFF PASSED | rule | 0.33 | - | 16.1 |
| CHARGE NOW FIRST | rule | 0.33 | - | 25.1 |
| HOLDER ASSIGNMENT | rule | 0.33 | - | 15.6 |
| JOINT CHARGE NOW | rule | 0.33 | - | 461.7 |
| MARCH OF THE TABLE | rule | 0.33 | - | 52.3 |
| ONE PROMISE A TARGET | rule | 0.33 | - | 354.0 |
| PIVOT GUARDS FLANK | rule | 0.33 | - | 249.0 |
| REFUSING RETIRES | rule | - | 0.33 | 13.1 |
| WALKS ON ITS ROUTE | rule | - | 0.33 | 60.0 |
| WAR ENGINE JOBS | rule | 0.33 | - | 3.7 |

### Plans: cnomg-c940641-p27

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.7 | 40% | 411 | 128 | 31% |
| Mine | join | 0.3 | 100% | 11 | 0 | 0% |
| Mine | move | 29.7 | 96% | 2667 | 0 | 0% |
| Mine | shoot | 9.3 | 57% | 312 | 539 | 173% |
| Opponent | charge | 0.3 | 100% | 11 | 37 | 340% |
| Opponent | join | 1.0 | 100% | 35 | 0 | 0% |
| Opponent | move | 25.3 | 88% | 1069 | 0 | 0% |
| Opponent | shoot | 12.7 | 74% | 849 | 1835 | 216% |
| Opponent | support | 0.7 | 100% | 0 | 0 | - |

### Battle groups: cnomg-c940641-p27

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 0.3 | 0% | - | - | - | - | - | - | - | - |
| Opponent | REDIRECT COUNTER | 1.0 | 0% | - | - | - | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: cnomg-c940641-p27

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 2 | 0 (2) | 0 | 0 | 50 | 100% | - | 0 (1) | - | 0 (1) | 0 (2) | - |
| Mine | Character | 11 | 33 (11) | 33 | 0 | 23 | 18% | 2.4 | 19 (5) | 70 (4) | 0 (2) | 15 (7) | 52 (4) |
| Mine | Clean-up | 3 | 157 (3) | 58 | 99 | 0 | 67% | 3.0 | 157 (3) | - | - | 150 (2) | 169 (1) |
| Mine | Hammer | 8 | 30 (8) | 15 | 15 | 20 | 12% | 1.7 | 0 (2) | 36 (6) | - | 46 (5) | 14 (3) |
| Mine | Holder | 4 | 70 (4) | 0 | 70 | 49 | 75% | 2.0 | 0 (1) | 92 (3) | - | 173 (1) | 32 (3) |
| Mine | Shooter | 1 | 107 (1) | 0 | 107 | 0 | 0% | 2.0 | 107 (1) | - | - | - | 107 (1) |
| Mine | War machine | 5 | 111 (5) | 111 | 0 | 40 | 0% | 1.0 | 111 (5) | - | - | 278 (2) | 0 (3) |
| Opponent | Chaff | 3 | 0 (3) | 0 | 0 | 100 | 100% | - | 0 (1) | 0 (1) | 0 (1) | 0 (1) | 0 (2) |
| Opponent | Character | 14 | 35 (14) | 35 | 0 | 32 | 36% | 3.2 | 47 (10) | 0 (1) | - | 46 (9) | 0 (2) |
| Opponent | Clean-up | 4 | 79 (4) | 0 | 79 | 0 | 100% | - | - | 79 (4) | - | 79 (4) | - |
| Opponent | Fragile | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Hammer | 6 | 75 (6) | 51 | 24 | 40 | 17% | 2.6 | 128 (2) | 0 (1) | 64 (3) | 75 (6) | - |
| Opponent | Holder | 3 | 38 (3) | 0 | 38 | 35 | 100% | - | - | 130 (1) | 0 (1) | 130 (1) | 0 (1) |
| Opponent | Shooter | 4 | 12 (4) | 0 | 12 | 67 | 75% | 5.0 | - | 20 (3) | 0 (1) | 12 (4) | - |
| Opponent | War machine | 9 | 21 (9) | 21 | 0 | 62 | 11% | 1.0 | 21 (9) | - | - | 0 (1) | 24 (8) |
| Opponent | Wizard | 1 | 0 (1) | 0 | 0 | 0 | 0% | 6.0 | - | 0 (1) | - | 0 (1) | - |

### Charged fights: cnomg-c940641-p27

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaos Dwarfs | 2 | 192 | 270 | 1.5 | 1.0 | 180 | 0 | +180 | 3 of 3 | 1 of 3 | - | +180 |
| Mine | Dwarfen Mountain Holds | 1 | 730 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| **Mine** | all armies | 3 | 372 | 180 | 1.0 | 1.0 | 180 | 0 | +180 | 3 of 3 | 1 of 3 | - | +180 |
| Opponent | Dwarfen Mountain Holds | 1 | 1141 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Empire of Man | 1 | 65 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Skaven | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| **Opponent** | all armies | 3 | 402 | 0 | 0.0 | - | - | - | - | - | - | - | - |

### Effective charges: cnomg-c940641-p27

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaos Dwarfs | 3 | 0 | 0 | 0 | 0 | 0 | 2 (net +270) | 1 | 0% (0 of 2) |

### Charged fights, damage counted: cnomg-c940641-p27

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 324 | 340 | +270 | 277 | 121 | +156 | +48.2 |
| Mine | No odds | 1 | 339 | 239 | +0 | 144 | 170 | -26 | -7.5 |
| Mine | All fights | 3 | 329 | 306 | +180 | 233 | 137 | +96 | +29.1 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| cnomg-c940641-p27 | move | 12 | 2 (17%) | 1 (8%) | 2 (17%) | 8 (67%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Periapt of Soul Exchange | Opponent | L0421 |
| Storm Daemon (Renegade 2.0) | Opponent | L0421 |
| Witch Hunter's Ward | Opponent | L0508 |

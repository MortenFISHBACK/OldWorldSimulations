# Doctrine scorecard: cnomg-c940641-p22

### Scorecard: cnomg-c940641-p22

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L1827 | 3 | 1 | Mine | no | 1 | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| L1827 | 3 | 1 | Opponent | no | 2 | 2 | 6 | 2 | 0 | 0 | 0 | 0 |
| L1927 | 1 | 1 | Mine | no | 2 | 1 | 4 | 0 | 1 | 0 | 0 | 255 |
| L1927 | 1 | 1 | Opponent | no | 2 | 2 | 3 | 3 | 0 | 0 | 0 | 0 |
| L2029 | 1 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 420 |
| L2029 | 1 | 1 | Opponent | no | 6 | 2 | 3 | 5 | 0 | 0 | 0 | 170 |
| **Average** | | | Mine | 0% | 1.0 | 1.5 | 2.0 | 0.7 | 0.3 | 0.0 | 0.0 | 225.0 |
| **Average** | | | Opponent | 0% | 3.3 | 2.0 | 4.0 | 3.3 | 0.0 | 0.0 | 0.0 | 56.7 |

### KPIs: cnomg-c940641-p22

Rules off - Mine only: NO OLD ONE-MOVE GUESS.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 13) | 0% (0 of 15) | 0% (0 of 28) |
| Winner chose to follow up after the loser gave ground |  | 75% (3 of 4); on the table 75% | 100% (7 of 7); on the table 100% | 91% (10 of 11); on the table 91% |
| Winner chose to pursue after the loser fell back in good order |  | - | 100% (1 of 1); on the table 100% | 100% (1 of 1); on the table 100% |
| Winner chose to pursue after the loser fled |  | - | 75% (3 of 4); on the table 75% | 75% (3 of 4); on the table 75% |
| Winner chose to follow up or pursue (all three) |  | 75% (3 of 4); on the table 75% | 92% (11 of 12); on the table 92% | 88% (14 of 16); on the table 88% |
| Magic missiles tried each own turn | 50%+ | 25% (6 of 24) | 33% (4 of 12) | 28% (10 of 36) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 33% (6 of 18) | 33% (4 of 12) | 33% (10 of 30) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 33% (2 of 6) | 0% (0 of 6) | 17% (2 of 12) |
| Points that never fought | lower | 27% (1648 of 5999) | 55% (3279 of 5999) | 41% (4927 of 11998) |
|   infantry points that never fought | lower | 38% (374 of 993) | 86% (685 of 793) | 59% (1059 of 1786) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 68% (15 of 22) | 58% (11 of 19) | 63% (26 of 41) |
| Bound items with a magic missile used (at least once a game) |  | 100% (1 of 1); 1.0 uses a game | 0.0 uses a game | 100% (1 of 1); 0.5 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 50% (1 of 2); 0.3 uses a game | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 67% (3455 of 5151) | 48% (2386 of 4976) | 58% (5841 of 10127) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 0.7 (11%) | 2.7 (100%) | 3.3 (38%) |
| MARCHED: its unit marched | 1.3 (22%) | 0.0 (0%) | 1.3 (15%) |
| IN COMBAT: engaged in combat | 2.0 (33%) | 0.0 (0%) | 2.0 (23%) |
| REAR RANK: in a rear rank | 1.0 (17%) | 0.0 (0%) | 1.0 (12%) |
| NOT OFFERED: not in the cast list | 1.0 (17%) | 0.0 (0%) | 1.0 (12%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 4.7 | 1.7 | 3.3 | 0.7 | 2.7 |
| not cast | 7.3 | 8.3 | 8.7 | 3.3 | 29.3 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.3 (4%) | 0.0 (0%) | 0.0 (0%) | 2.7 (9%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.0 (0%) | 3.3 (38%) | 1.0 (30%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 1.3 (15%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.0 (0%) | 2.0 (23%) | 0.0 (0%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 2.0 (27%) | 2.0 (24%) | 1.0 (12%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.0 (7%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (0%) | 1.0 (12%) | 0.0 (0%) | 1.0 (30%) | 0.0 (0%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (2%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.3 (40%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 1.0 (12%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 5.3 (73%) | 5.0 (60%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 24.0 (82%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.0 a game | 0.7 a game | 0.8 a game |
| stood (cast and not dispelled) | 0% (0 of 3) | 0% (0 of 2) | 0% (0 of 5) |
| the unit moved after it | - | - | - |
| it charged on its next turn | - | - | - |
| the enemy charged it first | - | - | - |
| it fought by the end of its next turn | - | - | - |
| it moved out of a charge the enemy had planned (not charged first) | - | - | - |
| none of these (no charge, no fight, no charge escaped) | - | - | - |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 54% (33 of 61) | 0% (0 of 7) | 49% (33 of 68) |
|   cavalry | - | 0% (0 of 3) | 0% (0 of 3) |
|   character | 62% (5 of 8) | 0% (0 of 4) | 42% (5 of 12) |
|   chariot | 75% (9 of 12) | - | 75% (9 of 12) |
|   infantry | 36% (10 of 28) | - | 36% (10 of 28) |
|   monster | 69% (9 of 13) | - | 69% (9 of 13) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.7 (29%) | 0.0 (0%) | 2.7 (23%) |
| CHARGED: it charged | 0.7 (7%) | 1.0 (43%) | 1.7 (14%) |
| FLEEING: it fled or was fleeing | 0.3 (4%) | 0.0 (0%) | 0.3 (3%) |
| IN COMBAT: it fought this turn or the last | 1.0 (11%) | 0.0 (0%) | 1.0 (9%) |
| NO TARGET IN RANGE | 2.3 (25%) | 1.3 (57%) | 3.7 (31%) |
| ONLY IN COMBAT: the only targets were in combat | 0.7 (7%) | 0.0 (0%) | 0.7 (6%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.7 (7%) | 0.0 (0%) | 0.7 (6%) |
| OTHER BAR | 1.0 (11%) | 0.0 (0%) | 1.0 (9%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| character | 1.7 | 0.3 | 80% | 1.8 pts | 3 pts |
| chariot | 3.3 | 1.3 | 80% | 11.4 pts | 38 pts |
| infantry | 3.3 | 1.0 | 80% | 4.0 pts | 13 pts |
| monster | 3.0 | 2.3 | 67% | 14.2 pts | 43 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.0 | 5.3 | 4.7 |
| Charges that made contact a game | 3.0 | 3.0 | 3.0 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.00 declared, 0.00 contact (1 units) | 0.00 declared, 0.00 contact (2 units) | 0.00 declared, 0.00 contact (3 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 1.00 declared, 1.00 contact (2 units) | 1.00 declared, 1.00 contact (2 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.43 declared, 0.32 contact (28 units) | 0.58 declared, 0.29 contact (24 units) | 0.50 declared, 0.31 contact (52 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 50% (2 of 4) | 67% (2 of 3) | 0% (0 of 2) | 44% (4 of 9) |
| Character in a unit | 83% (5 of 6) | 100% (2 of 2) | - | 88% (7 of 8) |
| Character on its own | 100% (2 of 2) | 100% (1 of 1) | 50% (3 of 6) | 67% (6 of 9) |
| Chariot | 50% (1 of 2) | - | - | 50% (1 of 2) |
| Infantry | 50% (2 of 4) | 0% (0 of 1) | - | 40% (2 of 5) |
| Monster | 0% (0 of 1) | 100% (3 of 3) | - | 75% (3 of 4) |
| Monstrous | - | 75% (3 of 4) | - | 75% (3 of 4) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Ogre Kingdoms | 1 | 67% (2 of 3); on the table 67% | 0% (0 of 6) | 36% | 86% (6 of 7) | 100% (1 of 1); 3.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 1 | 100% (1 of 1); on the table 100% | 25% (3 of 12) | 0% | 62% (5 of 8) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Skaven | 1 | - | 50% (3 of 6) | 46% | 57% (4 of 7) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Vampire Counts | 2 | 89% (8 of 9); on the table 89% | 33% (4 of 12) | 49% | 58% (7 of 12) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 1 | 100% (3 of 3); on the table 100% | - | 67% | 57% (4 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (cnomg-c940641-p22, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 50% (2) | 50% (3) | 50% (5) |
| ...free all their last turn and able to turn (per game) | 0.33 | 0.67 | 1.00 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.33 | 0.33 |
| ...with the charger already in that arc before they moved (per game) | 0.33 | 0.67 | 1.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: cnomg-c940641-p22

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.7 | 4.0 |
| Strategy | Charge objectives carried out (made contact) | 60% (3 of 5) | 44% (7 of 16) |
| Strategy | Shoot objectives carried out (shot that target) | 11% (1 of 9) | 0% (0 of 4) |
| Strategy | Support requests answered (helper made contact too) | 100% (2 of 2) | 50% (1 of 2) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 0% (0 of 2) | - |
| Strategy | Joined characters whose unit fought | 100% (5 of 5) | 0% (0 of 5) |
| Strategy | Lone characters that fought | 60% (3 of 5) | 56% (5 of 9) |
| Movement | Charges halted short of contact | 0.3 | 1.0 |
| Movement | Idle units | 0.7 | 3.3 |
| Movement | Points that never moved of their own | 225.0 | 56.7 |
| Movement | Fights charged into per game | 2.3 | 3.0 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 3 | 4 of 8, net -248 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 3 | 1 of 8, net +0 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 3 | 0 of 8 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 of 3, net +0 | 3 of 8, net +163 |
| Shooting | Shots by shooting units (incl. breath weapons) | 11.3 | 0.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 53% (18 of 34) | 0% (0 of 2) |
| Shooting | Points destroyed by shooting units | 0.0 | 0.0 |
| Shooting | Points destroyed by war machines | 25.0 | 0.0 |
| Magic | Magic missiles cast | 2.0 | 0.7 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 0% (0 of 6) | 0% (0 of 2) |
| Magic | Wounds caused by magic missiles | 1.0 | - |
| Magic | Points destroyed by magic (all spells) | 10.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 2.0 / 0.0 / 0.7 / 0.0 | 1.0 / 0.0 / 0.7 / 0.3 |
| Combat | Points destroyed in combat | 570.0 | 364.3 |
| Combat | Points run down | 0.0 | 78.3 |
| Combat | Net points per charged fight, damage counted | +31 | -32 |
| Combat | Net per 100 charger points, damage counted | +17.8 | -11.9 |
| Combat | First round won (charged fights) | 43% | 56% |
| Combat | Net points per charged fight | +45 | -52 |
| Combat | Net points per supported fight / lone fight | +0 / +62 | - / -52 |
| Combat | Charged fights on a top-3 enemy unit | 2 of 7 | 5 of 9 |
| Game | Points lost | 737.7 | 521.7 |
| Game | VP from objectives | 490.0 | 1023.3 |
| Game | Lone holders (player turns) | 1.0 | 3.3 |

- Mine won / drew / lost: 0 / 2 / 1 of 3 ended games (of 3); mean margin (Mine - Opponent) -683 VP
- The side that went first won 1 of 1 games with a winner
- Points traded per game (both sides' losses): 1259
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: cnomg-c940641-p22

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.3 | +11.7 | 0.0 | 0.0 | - | - | - | - |
| AFTERMATH WITH FRIENDS | - | - | - | - | 0.7 | +68.2 | 0.0 | 0.0 |
| ARMY TABLE | 25.7 | +470.3 | 0.0 | 454.0 | 16.3 | +335.8 | 0.0 | 52.7 |
| ASSAILMENT BY POINTS | 0.3 | +0.4 | 0.0 | 0.0 | 0.7 | +9.7 | 0.0 | 0.0 |
| BEST PRIZE | - | - | - | - | 0.3 | -7.9 | 12.7 | 0.0 |
| CAST JOB | - | - | - | - | 1.7 | +5.4 | 0.0 | 0.0 |
| CASTER AWAY FROM SCREEN | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CASTING BLOCK | 1.0 | +58.9 | 18.0 | 0.0 | - | - | - | - |
| CASTS FROM BEHIND | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | - | - | - | - | 1.0 | +29.0 | 0.0 | 0.0 |
| CHAFF PASSED | 3.0 | -11.1 | 0.0 | 43.3 | - | - | - | - |
| CHALLENGE BY POINTS | 0.7 | +45.1 | 0.0 | 0.0 | 0.3 | +15.9 | 0.0 | 16.7 |
| CHARGE LOSSES | 9.7 | -691.3 | 0.0 | 291.3 | 11.3 | -784.8 | 0.0 | 410.7 |
| CHARGE NOW FIRST | 1.0 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 253.0 | 339.3 |
| CLOSES ON WHAT IT BEATS | 7.0 | +0.0 | 0.0 | 145.7 | 22.3 | +0.0 | 0.0 | 60.0 |
| COMBAT PIVOT | 0.3 | +0.0 | 0.0 | 116.7 | 0.7 | +0.0 | 0.0 | 190.3 |
| CONTINUE AHEAD WEIGHED | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | 0.7 | +56.5 | 64.0 | 31.7 | 0.7 | +10.2 | 0.0 | 0.0 |
| COVER ONCE | 7.0 | -411.6 | 0.0 | 78.3 | 2.7 | -65.1 | 0.0 | 62.0 |
| DENIED BY THE FIGHT | 0.3 | -0.2 | 0.0 | 0.0 | 1.3 | -5.9 | 0.0 | 0.0 |
| DEPLOY BY FIGURES | 8.0 | -112.9 | 0.0 | 0.0 | 7.0 | +58.5 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | - | - | - | - | 0.3 | -119.5 | 0.0 | 190.3 |
| EDGE GIVE GROUND | - | - | - | - | 0.3 | +27.0 | 70.0 | 0.0 |
| EXACT ROUND | 2.0 | +12.0 | 0.0 | 0.0 | 5.0 | -17.5 | 286.0 | 339.3 |
| FALL BACK GOOD ORDER | 1.3 | +0.0 | 0.0 | 0.0 | 4.0 | +7.9 | 263.3 | 442.7 |
| FALLBACK BY WORTH | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| FALLS SHORT | - | - | - | - | 18.7 | +219.0 | 0.0 | 225.3 |
| FEATURE BUFFS | 1.0 | +4.4 | 0.0 | 0.0 | - | - | - | - |
| FIGHT TO THE END | 0.7 | -3.5 | 0.0 | 0.0 | 4.0 | +227.5 | 241.7 | 504.7 |
| FIVE ACTION | 73.3 | +6459.5 | 28.0 | 1025.3 | 94.0 | +7123.6 | 356.0 | 1394.7 |
| FLANK NOT WEIGHED | 14.3 | +0.0 | 0.0 | 224.7 | 2.3 | +0.0 | 0.0 | 10.0 |
| FOLLOW UP WEIGHED | 0.7 | +91.9 | 0.0 | 0.0 | 2.0 | +376.0 | 0.0 | 62.0 |
| FOUR ROUNDS | 2.0 | +38.8 | 0.0 | 0.0 | 5.7 | +658.5 | 356.0 | 529.7 |
| FREED FROM HIS FIGHT | 12.0 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | - | - | - | - | 0.3 | -0.7 | 0.0 | 0.0 |
| GIVES UP | - | - | - | - | 1.0 | -9.9 | 70.0 | 0.0 |
| GOAL WALK | 15.0 | +1674.9 | 0.0 | 315.0 | 8.3 | +1162.2 | 0.0 | 0.0 |
| GUN FIGURES | 6.0 | +21.9 | 35.0 | 65.0 | - | - | - | - |
| HARD STAY DROPPED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HE REFORMS ONCE FREED | 7.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 5.3 | +0.0 | 0.0 | 163.3 | 3.7 | +0.0 | 0.0 | 410.7 |
| HIS CHARGE DENIED | 1.0 | +86.4 | 0.0 | 0.0 | 0.3 | +8.5 | 0.0 | 0.0 |
| HIS CHARGE LIST | 3.3 | +0.0 | 0.0 | 156.7 | 0.3 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 3.0 | +0.0 | 0.0 | 135.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 3.7 | -33.3 | 0.0 | 22.7 | 7.3 | -105.0 | 0.0 | 40.0 |
| HIS MOVE AS HE DECIDES | 46.0 | +12.0 | 635.3 | 0.0 | - | - | - | - |
| HIS MOVE WHY | - | - | - | - | 51.7 | +0.0 | 0.0 | 949.7 |
| HIS ONE MOVE | 17.3 | +18.5 | 0.0 | 149.7 | - | - | - | - |
| HIS ONE QUARTER | 4.3 | +0.0 | 0.0 | 0.0 | 9.0 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 1.7 | +0.0 | 0.0 | 29.7 | 11.0 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVE | 15.0 | +0.0 | 0.0 | 214.7 | 3.0 | +0.0 | 0.0 | 20.0 |
| HIS RANDOM MOVER COMES | 4.3 | +0.0 | 0.0 | 128.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 9.3 | +104.2 | 0.0 | 56.0 | 41.7 | +777.6 | 0.0 | 480.3 |
| HIS SHOTS BY HIS RUN | 14.7 | +96.1 | 0.0 | 268.0 | 35.3 | +643.9 | 0.0 | 449.7 |
| HIS TURN DENIED | - | - | - | - | 1.3 | +47.1 | 0.0 | 0.0 |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 17.3 | +0.0 | 0.0 | 55.0 | 16.0 | +0.0 | 0.0 | 573.3 |
| HOLDER ASSIGNMENT | 10.7 | +1016.7 | 0.0 | 36.7 | 10.3 | +1021.0 | 0.0 | 286.7 |
| HOLDS AMBUSHERS | 0.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 1.3 | -11.1 | 0.0 | 0.0 | 5.3 | -203.3 | 356.0 | 529.7 |
| IDLE COST | - | - | - | - | 19.3 | -233.5 | 0.0 | 58.3 |
| JOINT CHARGE NOW | 1.3 | +72.8 | 0.0 | 0.0 | 1.0 | -39.1 | 78.3 | 0.0 |
| JOINT LOOK BACK | 0.3 | +0.2 | 0.0 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 3.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 0.3 | +9.3 | 0.0 | 0.0 | 1.3 | +47.7 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 5.0 | +0.0 | 331.0 | 296.3 | 7.7 | +0.0 | 254.3 | 105.0 |
| LONE WIZARD KEPT IN | 0.3 | +7.9 | 0.0 | 0.0 | - | - | - | - |
| LONG SHOT | 1.0 | -23.9 | 0.0 | 0.0 | 0.7 | +2.6 | 11.3 | 0.0 |
| LOST AFTER ESCAPE | 0.7 | -0.4 | 0.0 | 0.0 | 3.3 | +8.0 | 166.3 | 190.3 |
| MANOEUVRE | 0.7 | +0.0 | 0.0 | 0.0 | 1.7 | +1.1 | 0.0 | 0.0 |
| MARCH BY THE SUM | 0.7 | +180.5 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | 0.3 | +7.1 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 1.0 | +6.7 | 0.0 | 0.0 | - | - | - | - |
| MARCH WHEELS ONLY | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 2.0 | +135.7 | 0.0 | 36.7 | 2.3 | +76.2 | 0.0 | 10.0 |
| MEETS IN TIME | 5.0 | +381.2 | 0.0 | 0.0 | 3.3 | +411.4 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 3.0 | +117.2 | 0.0 | 0.0 | 2.7 | +10.0 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 3.3 | +45.6 | 0.0 | 0.0 | 2.7 | +4.6 | 0.0 | 0.0 |
| MOVE ORDER | 1.0 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| MOVE SPELL OUT OF RANGE | 0.3 | -3.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 2.7 | +90.9 | 0.0 | 139.3 | 11.0 | +764.7 | 0.0 | 62.0 |
| MOVES UNITS SPELL | 0.3 | +1.4 | 0.0 | 0.0 | - | - | - | - |
| NEARER NOT NEEDED | 8.7 | +423.2 | 0.0 | 155.0 | 5.7 | +225.6 | 0.0 | 143.3 |
| NEXT CHARGE BY LIST | 2.0 | +256.5 | 18.0 | 22.7 | 4.0 | +332.8 | 0.0 | 0.0 |
| NEXT OBJECTIVE NEARER | - | - | - | - | 0.3 | -10.0 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 1.0 | -63.8 | 0.0 | 0.0 | 5.0 | -127.5 | 356.0 | 339.3 |
| NO LATE CUT | 1.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 5.3 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 0.3 | -0.2 | 0.0 | 0.0 | 2.0 | -0.7 | 0.0 | 0.0 |
| OFF BEST | 5.0 | -184.1 | 0.0 | 0.0 | 2.7 | -35.4 | 0.0 | 0.0 |
| ONE CHECK AFTER THE LAST CHANGE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ONE FIGHT FORMULA | 1.0 | -2.6 | 0.0 | 11.3 | 6.3 | -143.5 | 0.0 | 143.3 |
| ONE JOINT FIGURE | 0.7 | +56.5 | 0.0 | 0.0 | 0.7 | +9.1 | 0.0 | 0.0 |
| ONE OBJECTIVE FORMULA | 3.0 | +85.2 | 0.0 | 0.0 | 4.7 | -68.8 | 0.0 | 143.3 |
| ONE PROMISE A TARGET | - | - | - | - | 0.7 | -11.3 | 0.0 | 0.0 |
| ONE ROUTE | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| OPENS A LANE | 1.0 | +1.3 | 0.0 | 0.0 | - | - | - | - |
| OPENS UP | - | - | - | - | 0.7 | +53.3 | 21.7 | 0.0 |
| OVERRUNS AWAY | - | - | - | - | 1.0 | +11.7 | 11.3 | 215.3 |
| PATHS CROSS | - | - | - | - | 1.3 | +52.5 | 0.0 | 0.0 |
| PERIAPT WORTH | 0.3 | +18.1 | 0.0 | 0.0 | - | - | - | - |
| PLAN RESULT | 35.3 | +117.0 | 78.0 | 1024.3 | 47.3 | +361.3 | 103.0 | 839.3 |
| PROMISE BELOW ZERO | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| PROMISE BY ITS OWN SUM | 8.7 | -346.7 | 0.0 | 116.7 | 13.7 | -385.0 | 0.0 | 62.0 |
| PROMISE KNOWS THE FIGHT | 0.3 | +0.0 | 0.0 | 0.0 | 2.7 | -0.5 | 0.0 | 62.0 |
| PROMISE READS THE TABLE | - | - | - | - | 1.0 | -2.5 | 0.0 | 0.0 |
| QUARTER ODDS | 15.3 | +1947.8 | 0.0 | 0.0 | 28.7 | +3577.4 | 21.7 | 322.7 |
| RANDOM MOVE BY FIGURES | 2.0 | +85.0 | 0.0 | 210.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| REAL GROUND | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | 3.3 | +153.8 | 0.0 | 36.7 | 2.3 | +61.8 | 0.0 | 20.0 |
| REDIRECT FOR A FRIEND IN REACH | 3.7 | +0.0 | 0.0 | 22.7 | 3.0 | +0.0 | 0.0 | 10.0 |
| REDIRECT WEIGHED | - | - | - | - | 0.7 | -2.2 | 82.7 | 0.0 |
| REFORMS TO MEET IT | 0.7 | -13.4 | 0.0 | 0.0 | 0.7 | -21.9 | 0.0 | 0.0 |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 62.0 |
| RISK BY ARC | 1.7 | +110.4 | 0.0 | 0.0 | 5.3 | +44.3 | 356.0 | 529.7 |
| RISK ON THE WAY | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ROUNDS AFTER TERROR | - | - | - | - | 4.0 | -153.5 | 241.7 | 504.7 |
| RUN DOWN | - | - | - | - | 4.7 | -31.6 | 264.3 | 529.7 |
| SCOUT SPOT | 0.7 | +1.8 | 0.0 | 0.0 | - | - | - | - |
| SCOUT WAITS | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 1.0 | -102.6 | 0.0 | 0.0 |
| SEARCH SPOT | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| SECOND LOOK | - | - | - | - | 0.3 | +17.0 | 70.0 | 0.0 |
| SELF MOVE SPELL | 2.0 | -4.2 | 0.0 | 0.0 | - | - | - | - |
| SET CREDITED ONCE | 0.7 | -31.5 | 0.0 | 0.0 | 1.7 | -6.5 | 0.0 | 20.0 |
| SET UP BY THE SET | 1.3 | +42.4 | 0.0 | 0.0 | 3.3 | -14.3 | 0.0 | 20.0 |
| SET-UP ANY TARGET | 0.3 | +9.6 | 64.0 | 31.7 | - | - | - | - |
| SHOOTERS ON THE TABLE | 0.7 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 2.3 | +32.2 | 10.0 | 0.0 | 0.3 | +1.4 | 0.0 | 0.0 |
| SHOT RISK POINTS | 5.7 | -34.3 | 0.0 | 0.0 | 26.3 | -146.5 | 0.0 | 145.0 |
| SHOTS AFTER THE MOVES | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SHOTS IN THE MOVE | 9.3 | +194.3 | 0.0 | 65.0 | 0.3 | +5.1 | 0.0 | 0.0 |
| SPELL SETS UP CHARGE | 0.3 | +9.6 | 64.0 | 31.7 | - | - | - | - |
| SPELL WORTH | 1.7 | +28.0 | 0.0 | 0.0 | 2.0 | +13.6 | 0.0 | 0.0 |
| SPELLS IN THE FIGHT | 0.3 | +2.7 | 0.0 | 0.0 | 0.3 | +2.7 | 85.0 | 190.3 |
| SPOT AS THE GAME MOVES | 7.3 | +0.0 | 0.0 | 325.0 | 9.3 | +0.0 | 0.0 | 35.0 |
| STAND AND SHOOT | - | - | - | - | 0.7 | -10.2 | 21.7 | 0.0 |
| STANDS STILL | 20.0 | +0.0 | 28.0 | 232.7 | 23.3 | +0.0 | 0.0 | 286.7 |
| STAY WORTH | 6.7 | +64.4 | 0.0 | 65.0 | 0.3 | +0.4 | 0.0 | 0.0 |
| STRIKE BY THE ODDS | 1.0 | +5.2 | 430.0 | 0.0 | 1.0 | +4.4 | 0.0 | 124.0 |
| STUPIDITY NEXT TURN | - | - | - | - | 1.7 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 14.7 | +963.2 | 0.0 | 56.0 | 5.3 | +266.4 | 0.0 | 20.0 |
| SUPPORT NARROWED | - | - | - | - | 0.7 | +0.0 | 0.0 | 62.0 |
| SUPPORT WORKED OUT | 14.7 | +963.2 | 0.0 | 56.0 | 5.3 | +266.4 | 0.0 | 20.0 |
| SURE REACH TOGETHER | - | - | - | - | 0.3 | +0.7 | 0.0 | 0.0 |
| SWIFTSTRIDE BY POINTS | 0.3 | +0.3 | 0.0 | 11.3 | - | - | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 1.3 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| THE PROMISE ADDS | - | - | - | - | 1.3 | -10.1 | 0.0 | 0.0 |
| THE PROMISED MOVE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE ROW IN ITS ORDER | 4.3 | +0.0 | 0.0 | 78.3 | 3.3 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 5.7 | +0.0 | 0.0 | 76.7 | 3.0 | +0.0 | 0.0 | 62.0 |
| THE STEP BACK IS MADE | 3.7 | +0.0 | 0.0 | 12.7 | 2.3 | +0.0 | 0.0 | 62.0 |
| THE TABLE AGAIN | 5.3 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 32.7 | +0.0 | 0.0 | 297.7 | 46.3 | +0.0 | 0.0 | 445.0 |
| TIED UP BY THE SUM | 0.7 | +10.7 | 0.0 | 0.0 | 1.7 | +159.4 | 181.3 | 87.0 |
| TIME ON OUR SIDE | 31.7 | +397.3 | 10.0 | 320.3 | - | - | - | - |
| WAITS AGAIN | 2.0 | +0.0 | 0.0 | 153.3 | 1.3 | +0.0 | 0.0 | 0.0 |
| WAR ENGINE JOBS | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WHAT THE JOINER ADDS | - | - | - | - | 0.7 | -55.7 | 0.0 | 380.7 |
| WHO FIGHTS | 0.3 | -1.2 | 0.0 | 0.0 | 2.0 | +157.4 | 78.3 | 124.0 |
| WHO GETS IN | - | - | - | - | 0.3 | -6.3 | 78.3 | 0.0 |
| WHO HITS BACK | - | - | - | - | 0.7 | +66.8 | 0.0 | 25.0 |
| WHOLE FIGHT | - | - | - | - | 0.3 | -0.5 | 0.0 | 190.3 |
| WHOLE FIGHT DANGER | 8.0 | -641.1 | 0.0 | 291.3 | 1.3 | -420.9 | 0.0 | 348.7 |
| WHOLE FIGHT GAIN | 0.7 | +17.8 | 0.0 | 0.0 | 0.7 | +52.8 | 0.0 | 0.0 |
| WOUNDS ON THE RANKS | 0.3 | +6.0 | 0.0 | 0.0 | 3.7 | +95.7 | 0.0 | 0.0 |

### Rule changes: cnomg-c940641-p22

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS MOVE WHY | 155 | 155 | 105 | 35.00 | +0 | +0.0 |
| HIS MOVE AS HE DECIDES | 138 | 138 | 102 | 34.00 | +0 | +0.0 |
| ARMY TABLE | 126 | 126 | 75 | 25.00 | +2708 | +36.1 |
| HOLDER ASSIGNMENT | 63 | 63 | 57 | 19.00 | +3364 | +59.0 |
| LEGAL CHARGES ONLY | 38 | 38 | 38 | 12.67 | +0 | +0.0 |
| FIVE ACTION | 502 | 481 | 37 | 12.33 | +3324 | +89.8 |
| PROMISE BY ITS OWN SUM | 67 | 67 | 32 | 10.67 | -2195 | -68.6 |
| HIS SHOT LIST | 153 | 150 | 28 | 9.33 | +235 | +8.4 |
| THE TABLE AGAIN | 34 | 34 | 27 | 9.00 | +0 | +0.0 |
| DEPLOY BY FIGURES | 45 | 45 | 26 | 8.67 | +294 | +11.3 |
| MOVE TO CHARGE COMPUTED | 41 | 36 | 23 | 7.67 | +626 | +27.2 |
| OFF BEST | 23 | 23 | 23 | 7.67 | -659 | -28.6 |
| HIS SHOTS BY HIS RUN | 150 | 145 | 22 | 7.33 | +96 | +4.4 |
| SUPPORT ADDS | 60 | 54 | 21 | 7.00 | +457 | +21.8 |
| SUPPORT WORKED OUT | 60 | 54 | 21 | 7.00 | +457 | +21.8 |
| REDIRECT FOR A FRIEND IN REACH | 20 | 20 | 20 | 6.67 | +0 | +0.0 |
| HIS ONE MOVE | 52 | 52 | 18 | 6.00 | +0 | +0.0 |
| QUARTER ODDS | 132 | 125 | 18 | 6.00 | +2175 | +120.8 |
| GOAL WALK | 70 | 69 | 17 | 5.67 | +1696 | +99.7 |
| IDLE COST | 58 | 42 | 15 | 5.00 | +50 | +3.4 |
| MOVE ORDER | 12 | 12 | 12 | 4.00 | +0 | +0.0 |
| SHOT RISK POINTS | 96 | 92 | 10 | 3.33 | +94 | +9.4 |
| CHAFF PASSED | 9 | 9 | 9 | 3.00 | -33 | -3.7 |
| FOLLOW UP WEIGHED | 8 | 8 | 8 | 2.67 | +1404 | +175.5 |
| JOINT CHARGE NOW | 7 | 7 | 7 | 2.33 | +101 | +14.5 |
| MEETS IN TIME | 25 | 25 | 7 | 2.33 | +441 | +63.0 |
| NEXT CHARGE BY LIST | 18 | 18 | 7 | 2.33 | +488 | +69.7 |
| TIME ON OUR SIDE | 95 | 72 | 7 | 2.33 | +24 | +3.4 |
| FOUR ROUNDS | 23 | 22 | 6 | 2.00 | +746 | +124.4 |
| STRIKE BY THE ODDS | 6 | 6 | 6 | 2.00 | +29 | +4.8 |
| LANE BY FIGURES | 5 | 5 | 5 | 1.67 | +171 | +34.2 |
| RISK BY ARC | 21 | 20 | 5 | 1.67 | +381 | +76.2 |
| SHOOTS FROM THE BEST SPOT | 8 | 8 | 5 | 1.67 | +7 | +1.5 |
| ADVANCE LANE KEPT | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| CASTS FROM BEHIND | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| CHARGE NOW FIRST | 13 | 13 | 4 | 1.33 | -292 | -73.0 |
| HOLDS AMBUSHERS | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| PATHS CROSS | 4 | 4 | 4 | 1.33 | +157 | +39.3 |
| SET UP BY THE SET | 14 | 14 | 4 | 1.33 | +56 | +14.1 |
| WHOLE FIGHT DANGER | 28 | 23 | 4 | 1.33 | +108 | +26.9 |
| ASSAILMENT BY POINTS | 3 | 3 | 3 | 1.00 | +30 | +10.1 |
| CAST JOB | 5 | 5 | 3 | 1.00 | +7 | +2.2 |
| CASTING BLOCK | 3 | 3 | 3 | 1.00 | +142 | +47.3 |
| CHAFF IN THE MOVE | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| CHALLENGE BY POINTS | 3 | 3 | 3 | 1.00 | +183 | +60.9 |
| COMBAT PIVOT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| COVER ONCE | 29 | 14 | 3 | 1.00 | +0 | +0.0 |
| MAX FOR POSITIONING | 13 | 12 | 3 | 1.00 | +27 | +9.1 |
| NEARER NOT NEEDED | 43 | 39 | 3 | 1.00 | +128 | +42.8 |
| REDIRECT COUNTER | 17 | 13 | 3 | 1.00 | +84 | +28.0 |
| SCOUT WAITS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| THE ROW IN ITS ORDER | 23 | 3 | 3 | 1.00 | +0 | +0.0 |
| TIED UP BY THE SUM | 7 | 6 | 3 | 1.00 | +262 | +87.5 |
| WOUNDS ON THE RANKS | 12 | 12 | 3 | 1.00 | +45 | +15.1 |
| AFTERMATH WITH FRIENDS | 2 | 2 | 2 | 0.67 | +204 | +102.2 |
| CASTER AWAY FROM SCREEN | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| CONTINUE AHEAD WEIGHED | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| MARCH BY THE SUM | 2 | 2 | 2 | 0.67 | +542 | +270.8 |
| ONE JOINT FIGURE | 4 | 4 | 2 | 0.67 | +79 | +39.3 |
| ONE OBJECTIVE FORMULA | 23 | 16 | 2 | 0.67 | +185 | +92.6 |
| ONE PROMISE A TARGET | 2 | 2 | 2 | 0.67 | -34 | -16.9 |
| RANDOM MOVE BY FIGURES | 12 | 12 | 2 | 0.67 | +255 | +127.5 |
| REDIRECT WEIGHED | 2 | 2 | 2 | 0.67 | +483 | +241.3 |
| WHO FIGHTS | 7 | 7 | 2 | 0.67 | +188 | +94.1 |
| WHO HITS BACK | 2 | 2 | 2 | 0.67 | +122 | +60.9 |
| AFTERMATH IN POINTS | 1 | 1 | 1 | 0.33 | +35 | +35.0 |
| BEST PRIZE | 1 | 1 | 1 | 0.33 | -24 | -23.6 |
| CHARGE LOSSES | 63 | 56 | 1 | 0.33 | +78 | +77.5 |
| EDGE GIVE GROUND | 1 | 1 | 1 | 0.33 | +40 | +39.6 |
| FIGHT TO THE END | 14 | 14 | 1 | 0.33 | +406 | +405.9 |
| HARD STAY DROPPED | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| HIS CHARGE DENIED | 4 | 4 | 1 | 0.33 | +14 | +13.9 |
| HIS MOVE AND SHOT | 33 | 33 | 1 | 0.33 | +0 | +0.0 |
| JOINT LOOK BACK | 1 | 1 | 1 | 0.33 | +1 | +0.7 |
| LONE WIZARD KEPT IN | 1 | 1 | 1 | 0.33 | +24 | +23.8 |
| MANOEUVRE | 7 | 7 | 1 | 0.33 | +5 | +5.0 |
| MISSILES IN THE MOVE | 17 | 10 | 1 | 0.33 | +22 | +22.3 |
| MOVES UNITS SPELL | 1 | 1 | 1 | 0.33 | +4 | +4.3 |
| ONE FIGHT FORMULA | 22 | 12 | 1 | 0.33 | +41 | +41.2 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.33 | +54 | +54.4 |
| PROMISE KNOWS THE FIGHT | 9 | 6 | 1 | 0.33 | -2 | -1.5 |
| REFUSING RETIRES | 3 | 3 | 1 | 0.33 | -3 | -3.3 |
| SECOND LOOK | 1 | 1 | 1 | 0.33 | +51 | +51.1 |
| SHOTS IN THE MOVE | 29 | 15 | 1 | 0.33 | +15 | +14.9 |
| SUPPORT NARROWED | 2 | 2 | 1 | 0.33 | -3 | -2.9 |
| SURE REACH TOGETHER | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| SWIFTSTRIDE BY POINTS | 1 | 1 | 1 | 0.33 | +1 | +0.9 |
| WHO GETS IN | 1 | 1 | 1 | 0.33 | -19 | -18.8 |
| WHOLE FIGHT GAIN | 4 | 4 | 1 | 0.33 | +14 | +13.9 |
| CLOSES ON WHAT IT BEATS | 88 | 87 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 4 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 5 | 5 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 1 | 1 | 0 | 0.00 | - | - |
| EXACT ROUND | 21 | 20 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 16 | 15 | 0 | 0.00 | - | - |
| FALLBACK BY WORTH | 1 | 1 | 0 | 0.00 | - | - |
| FALLS SHORT | 56 | 48 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 3 | 3 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 50 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 45 | 34 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 1 | 1 | 0 | 0.00 | - | - |
| GIVES UP | 3 | 3 | 0 | 0.00 | - | - |
| GUN FIGURES | 18 | not checked | - | - | - | - |
| HE REFORMS ONCE FREED | 25 | 19 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 27 | 23 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 11 | 11 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 27 | 25 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 40 | 37 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 38 | 36 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 54 | 54 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 15 | 15 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 4 | 4 | 0 | 0.00 | - | - |
| HIS TURN RUN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 100 | 100 | 0 | 0.00 | - | - |
| HONEST WORTH | 20 | 19 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 14 | 14 | 0 | 0.00 | - | - |
| LONG SHOT | 5 | 5 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 12 | 12 | 0 | 0.00 | - | - |
| MARCH CHECK | 1 | 1 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 3 | 3 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 3 | 3 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 18 | 12 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 1 | trace | - | - | - | - |
| NEXT OBJECTIVE NEARER | 1 | 1 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 18 | 17 | 0 | 0.00 | - | - |
| NO LATE CUT | 6 | 6 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 18 | 18 | 0 | 0.00 | - | - |
| NO SECOND RUN | 34 | 34 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 7 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 1 | not checked | - | - | - | - |
| ONE ROUTE | 3 | 3 | 0 | 0.00 | - | - |
| OPENS A LANE | 3 | 2 | 0 | 0.00 | - | - |
| OPENS UP | 2 | 2 | 0 | 0.00 | - | - |
| OVERRUNS AWAY | 3 | 3 | 0 | 0.00 | - | - |
| PLAN RESULT | 248 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 3 | 3 | 0 | 0.00 | - | - |
| PROMISE READS THE TABLE | 3 | 3 | 0 | 0.00 | - | - |
| REAL GROUND | 3 | 3 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 4 | 4 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 2 | 2 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 12 | 12 | 0 | 0.00 | - | - |
| RUN DOWN | 14 | 14 | 0 | 0.00 | - | - |
| SCOUT SPOT | 2 | 2 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 3 | 3 | 0 | 0.00 | - | - |
| SEARCH SPOT | 2 | 2 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 6 | not checked | - | - | - | - |
| SET CREDITED ONCE | 7 | 7 | 0 | 0.00 | - | - |
| SET-UP ANY TARGET | 1 | not checked | - | - | - | - |
| SHOOTERS ON THE TABLE | 7 | not checked | - | - | - | - |
| SHOTS AFTER THE MOVES | 1 | 1 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 1 | not checked | - | - | - | - |
| SPELL WORTH | 11 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 50 | 41 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 2 | 2 | 0 | 0.00 | - | - |
| STANDS STILL | 130 | 120 | 0 | 0.00 | - | - |
| STAY WORTH | 21 | 16 | 0 | 0.00 | - | - |
| STUPIDITY NEXT TURN | 5 | 5 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 11 | not checked | - | - | - | - |
| THE PROMISE ADDS | 4 | 4 | 0 | 0.00 | - | - |
| THE PROMISED MOVE | 1 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 26 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 18 | not checked | - | - | - | - |
| THE TABLE BINDS | 237 | not checked | - | - | - | - |
| WAITS AGAIN | 10 | 9 | 0 | 0.00 | - | - |
| WAR ENGINE JOBS | 3 | 3 | 0 | 0.00 | - | - |
| WHAT THE JOINER ADDS | 2 | 2 | 0 | 0.00 | - | - |
| WHOLE FIGHT | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: cnomg-c940641-p22

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| PROMISE BY ITS OWN SUM | rule | 4.33 | 6.33 | 68.6 |
| JOB FIRST | gate | 4.33 | 2.33 | 32.2 |
| ARMY TABLE | rule | 3.33 | 1.33 | 80.3 |
| CHARGE NOW FIRST | rule | - | 1.33 | 73.0 |
| CHAFF PASSED | rule | 1.00 | - | 11.1 |
| HOLDER ASSIGNMENT | rule | 1.00 | - | 21.1 |
| JOINT CHARGE NOW | rule | 0.33 | 0.67 | 63.0 |
| FIGHT ORDER BAND | gate | 0.33 | 0.33 | 1.3 |
| BEST PRIZE | rule | - | 0.33 | 23.6 |
| ONE PROMISE A TARGET | rule | - | 0.33 | 37.6 |
| PROMISE KNOWS THE FIGHT | rule | - | 0.33 | 1.5 |
| REFUSING RETIRES | rule | 0.33 | - | 3.3 |
| RULE SWITCHED OFF | gate | 0.33 | - | 12.6 |
| SUPPORT NARROWED | rule | - | 0.33 | 2.9 |
| WHO GETS IN | rule | - | 0.33 | 18.8 |

### Plans: cnomg-c940641-p22

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.7 | 20% | 114 | 93 | 82% |
| Mine | move | 31.3 | 89% | 2350 | 0 | 0% |
| Mine | shoot | 2.3 | 29% | 355 | 24 | 7% |
| Opponent | charge | 5.7 | 47% | 1100 | 361 | 33% |
| Opponent | join | 3.0 | 100% | 119 | 0 | 0% |
| Opponent | move | 37.7 | 97% | 2094 | 0 | 0% |
| Opponent | shoot | 0.7 | 0% | 90 | 0 | 0% |
| Opponent | support | 0.3 | 100% | 0 | 0 | - |

### Battle groups: cnomg-c940641-p22

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 3.3 | 10% | 100% | 0% | - | 100% | 0% | 0% | 0% | 0% |
| Opponent | REDIRECT COUNTER | 2.3 | 29% | 100% | 50% | 0% | 100% | 0% | 0% | 0% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: cnomg-c940641-p22

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 0% | 6.0 | - | 0 (1) | - | - | 0 (1) |
| Mine | Chaff | 7 | 116 (7) | 0 | 116 | 53 | 29% | 2.6 | 132 (6) | 0 (1) | - | 132 (6) | 0 (1) |
| Mine | Character | 7 | 62 (7) | 62 | 0 | 31 | 14% | 2.7 | 7 (1) | 134 (4) | 0 (1) | 173 (3) | 3 (3) |
| Mine | Clean-up | 2 | 51 (2) | 0 | 51 | 16 | 0% | 5.5 | 51 (2) | - | - | 0 (1) | 61 (1) |
| Mine | Fast Hammer | 1 | 187 (1) | 187 | 0 | 0 | 0% | 3.0 | - | 187 (1) | - | 187 (1) | - |
| Mine | Hammer | 10 | 5 (10) | 4 | 1 | 48 | 0% | 2.2 | 0 (2) | 3 (5) | 12 (3) | 4 (4) | 6 (6) |
| Mine | Holder | 3 | 43 (3) | 0 | 43 | 46 | 67% | 4.0 | 0 (1) | 79 (2) | - | 43 (3) | - |
| Mine | Shooter | 3 | 0 (3) | 0 | 0 | 100 | 0% | 1.3 | 0 (1) | 0 (2) | - | 0 (2) | 0 (1) |
| Mine | Wizard | 3 | 0 (3) | 0 | 0 | 20 | 0% | 2.0 | - | 0 (2) | - | 0 (2) | - |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 100 | 0% | 6.0 | - | 0 (1) | - | - | 0 (1) |
| Opponent | Chaff | 9 | 70 (9) | 11 | 59 | 21 | 78% | 3.0 | 24 (4) | 333 (2) | 0 (3) | 197 (4) | 0 (5) |
| Opponent | Character | 10 | 50 (10) | 50 | 0 | 38 | 50% | 3.0 | 86 (4) | 0 (4) | 106 (1) | 106 (4) | 0 (5) |
| Opponent | Clean-up | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Fast Hammer | 8 | 37 (8) | 18 | 19 | 42 | 38% | 3.2 | 21 (2) | 50 (4) | 28 (2) | 50 (5) | 16 (3) |
| Opponent | Hammer | 2 | 158 (2) | 85 | 73 | 0 | 50% | 3.0 | - | 158 (2) | - | 245 (1) | 111 (1) |
| Opponent | Holder | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | - | 0 (1) | 0 (1) | - |
| Opponent | Support | 1 | 0 (1) | 0 | 0 | 0 | 0% | 3.0 | - | 0 (1) | - | - | 0 (1) |
| Opponent | Wizard | 4 | 0 (4) | 0 | 0 | 0 | 25% | 1.3 | 0 (1) | 0 (1) | 0 (2) | - | 0 (4) |

### Charged fights: cnomg-c940641-p22

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Ogre Kingdoms | 1 | 75 | 0 | 3.0 | 1.7 | 0 | 0 | +0 | 0 of 3 | 2 of 3 | +0 | +0 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 717 | 4.0 | 1.0 | 179 | 101 | +78 | 2 of 4 | 1 of 4 | - | +78 |
| Mine | Skaven | 1 | 30 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| **Mine** | all armies | 3 | 35 | 239 | 2.3 | 1.3 | 102 | 58 | +45 | 2 of 7 | 3 of 7 | +0 | +62 |
| Opponent | Vampire Counts | 2 | 0 | 245 | 4.0 | 1.0 | 61 | 124 | -63 | 5 of 8 | 4 of 8 | - | -63 |
| Opponent | Warriors of Chaos | 1 | 0 | 38 | 1.0 | 1.0 | 38 | 0 | +38 | 0 of 1 | 1 of 1 | - | +38 |
| **Opponent** | all armies | 3 | 0 | 176 | 3.0 | 1.0 | 59 | 110 | -52 | 5 of 9 | 5 of 9 | - | -52 |

### Effective charges: cnomg-c940641-p22

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Ogre Kingdoms | 3 | 0 | 0 | 0 | 1 (net +0) | 0 | 2 (net +0) | 0 | 0% (0 of 3) |
| Opponent | Vampire Counts | 8 | 4 (net -248) | 0 | 1 (net +0) | 0 | 0 | 3 (net +163) | 0 | 12% (1 of 8) |

### Charged fights, damage counted: cnomg-c940641-p22

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 76-89% | 1 | 90 | 186 | +0 | 0 | 54 | -54 | -60.0 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 168 | 130 | +0 | 0 | 10 | -10 | -5.7 |
| Mine | No odds | 4 | 201 | 236 | +78 | 181 | 108 | +73 | +36.4 |
| Mine | All fights | 7 | 176 | 199 | +45 | 104 | 72 | +31 | +17.8 |
| Opponent | Long shot (under 50%) | 4 | 257 | 291 | -248 | 55 | 256 | -201 | -78.3 |
| Opponent | Effective (55-75%) | 1 | 186 | 297 | +0 | 0 | 0 | +0 | +0.0 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 | 237 | 175 | +163 | 169 | 9 | +160 | +67.5 |
| Opponent | No odds | 1 | 494 | 38 | +38 | 38 | 0 | +38 | +7.7 |
| Opponent | All fights | 9 | 269 | 225 | -52 | 85 | 117 | -32 | -11.9 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| cnomg-c940641-p22 | move | 16 | 5 (31%) | 3 (19%) | 0 (0%) | 11 (69%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L1827, L1927 |
| Elixir of Power | Mine | L1927 |
| Fistful of Laurels | Mine | L1827 |
| Invocation of Nehek | Opponent | L1827, L1927 |
| Periapt of Soul Exchange | Mine | L2029 |

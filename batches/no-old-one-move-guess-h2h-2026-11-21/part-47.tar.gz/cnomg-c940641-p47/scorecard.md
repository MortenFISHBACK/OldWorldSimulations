# Doctrine scorecard: cnomg-c940641-p47

### Scorecard: cnomg-c940641-p47

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L2131 | 1 | 1 | Mine | yes | 6 | - | 0 | 2 | 0 | 0 | 0 | 290 |
| L2131 | 1 | 1 | Opponent | no | 0 | 3 | 2 | 2 | 0 | 0 | 0 | 0 |
| L2235 | 3 | 1 | Mine | no | 4 | 2 | 3 | 0 | 0 | 0 | 0 | 72 |
| L2235 | 3 | 1 | Opponent | no | 4 | 2 | 6 | 1 | 0 | 0 | 0 | 0 |
| L2429 | 5 | 1 | Mine | yes | - | - | 2 | 3 | 0 | 0 | 0 | 0 |
| L2429 | 5 | 1 | Opponent | yes | - | 3 | 2 | 4 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 67% | 5.0 | 2.0 | 1.7 | 1.7 | 0.0 | 0.0 | 0.0 | 120.7 |
| **Average** | | | Opponent | 33% | 2.0 | 2.7 | 3.3 | 2.3 | 0.0 | 0.0 | 0.0 | 0.0 |

### KPIs: cnomg-c940641-p47

Rules off - Opponent only: NO OLD ONE-MOVE GUESS.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 14% (2 of 14) | 0% (0 of 16) | 7% (2 of 30) |
| Winner chose to follow up after the loser gave ground |  | 57% (4 of 7); on the table 71% | 100% (8 of 8); on the table 100% | 80% (12 of 15); on the table 87% |
| Winner chose to pursue after the loser fell back in good order |  | 0% (0 of 1); on the table 0% | - | 0% (0 of 1); on the table 0% |
| Winner chose to pursue after the loser fled |  | 0% (0 of 2); on the table 0% | - | 0% (0 of 2); on the table 0% |
| Winner chose to follow up or pursue (all three) |  | 40% (4 of 10); on the table 50% | 100% (8 of 8); on the table 100% | 67% (12 of 18); on the table 72% |
| Magic missiles tried each own turn | 50%+ | 17% (2 of 12) | - | 17% (2 of 12) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 22% (2 of 9) | - | 22% (2 of 9) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 67% (8 of 12) | 41% (7 of 17) | 52% (15 of 29) |
| Points that never fought | lower | 41% (2438 of 5997) | 47% (2844 of 5999) | 44% (5282 of 11996) |
|   infantry points that never fought | lower | 42% (696 of 1675) | 61% (794 of 1306) | 50% (1490 of 2981) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 76% (16 of 21) | 55% (17 of 31) | 63% (33 of 52) |
| Bound items with a magic missile used (at least once a game) |  | 100% (1 of 1); 1.3 uses a game | 100% (2 of 2); 2.3 uses a game | 100% (3 of 3); 1.8 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 100% (1 of 1); 0.3 uses a game | 0.0 uses a game | 100% (1 of 1); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 74% (3597 of 4866) | 56% (3320 of 5884) | 64% (6917 of 10750) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.0 (30%) | - | 1.0 (30%) |
| MARCHED: its unit marched | 1.3 (40%) | - | 1.3 (40%) |
| FLEEING: fleeing | 1.0 (30%) | - | 1.0 (30%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 5.7 | 2.7 | 0.7 | 0.7 | 2.3 |
| not cast | 4.3 | 5.3 | 1.3 | 3.3 | 21.7 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (2%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 5.3 (100%) | 0.3 (25%) | 1.0 (30%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.3 (40%) | 0.0 (0%) |
| FLEEING: fleeing | 1.0 (23%) | 0.0 (0%) | 0.0 (0%) | 1.0 (30%) | 1.7 (8%) |
| GONE: slain | 0.7 (15%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.7 (62%) | 0.0 (0%) | 1.0 (75%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 19.7 (91%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.0 a game | 0.7 a game | 0.3 a game |
| stood (cast and not dispelled) | - | 50% (1 of 2) | 50% (1 of 2) |
| the unit moved after it | - | 0% (0 of 1) | 0% (0 of 1) |
| it charged on its next turn | - | 0% (0 of 1) | 0% (0 of 1) |
| the enemy charged it first | - | 0% (0 of 1) | 0% (0 of 1) |
| it fought by the end of its next turn | - | 0% (0 of 1) | 0% (0 of 1) |
| it moved out of a charge the enemy had planned (not charged first) | - | 0% (0 of 1) | 0% (0 of 1) |
| none of these (no charge, no fight, no charge escaped) | - | 100% (1 of 1) | 100% (1 of 1) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 74% (49 of 66) | 55% (21 of 38) | 67% (70 of 104) |
|   cavalry | 90% (9 of 10) | 69% (11 of 16) | 77% (20 of 26) |
|   character | 0% (0 of 10) | 20% (2 of 10) | 10% (2 of 20) |
|   chariot | 82% (9 of 11) | - | 82% (9 of 11) |
|   infantry | 89% (31 of 35) | 67% (8 of 12) | 83% (39 of 47) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 0.3 (6%) | 1.7 (29%) | 2.0 (18%) |
| CHARGED: it charged | 2.0 (35%) | 1.7 (29%) | 3.7 (32%) |
| IN COMBAT: it fought this turn or the last | 1.3 (24%) | 0.0 (0%) | 1.3 (12%) |
| NO TARGET IN RANGE | 1.0 (18%) | 2.0 (35%) | 3.0 (26%) |
| ONLY IN COMBAT: the only targets were in combat | 0.3 (6%) | 0.3 (6%) | 0.7 (6%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.7 (12%) | 0.0 (0%) | 0.7 (6%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 12.0 | 1.0 | 92% | 1.8 pts | 22 pts |
| character | 0.7 | 0.3 | 50% | 2.5 pts | 2 pts |
| chariot | 3.3 | 1.3 | 80% | 13.7 pts | 46 pts |
| infantry | 15.0 | 7.0 | 62% | 7.9 pts | 119 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 2.7 | 5.0 | 3.8 |
| Charges that made contact a game | 2.0 | 3.7 | 2.8 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.00 declared, 0.00 contact (2 units) | - | 0.00 declared, 0.00 contact (2 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.00 declared, 0.00 contact (1 units) | 2.00 declared, 2.00 contact (1 units) | 1.00 declared, 1.00 contact (2 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.30 declared, 0.22 contact (27 units) | 0.52 declared, 0.36 contact (25 units) | 0.40 declared, 0.29 contact (52 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 83% (5 of 6) | 100% (4 of 4) | - | 90% (9 of 10) |
| Character in a unit | 100% (4 of 4) | 50% (1 of 2) | - | 83% (5 of 6) |
| Character on its own | 33% (1 of 3) | - | 50% (4 of 8) | 45% (5 of 11) |
| Chariot | 50% (1 of 2) | - | - | 50% (1 of 2) |
| Infantry | 45% (5 of 11) | 100% (4 of 4) | - | 60% (9 of 15) |
| Monster | 60% (3 of 5) | 100% (1 of 1) | - | 67% (4 of 6) |
| Monstrous | 0% (0 of 2) | - | - | 0% (0 of 2) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Skaven | 1 | 100% (3 of 3); on the table 100% | 17% (1 of 6) | 27% | 78% (7 of 9) | 100% (1 of 1); 4.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Tomb Kings of Khemri | 1 | 25% (1 of 4); on the table 25% | - | 14% | 40% (2 of 5) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 1 | 0% (0 of 3); on the table 33% | 17% (1 of 6) | 81% | 100% (7 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 2 | 100% (6 of 6); on the table 100% | - | 54% | 63% (12 of 19) | 100% (1 of 1); 2.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 1 | 100% (2 of 2); on the table 100% | - | 33% | 42% (5 of 12) | 100% (1 of 1); 3.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (cnomg-c940641-p47, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 40% (2) | 50% (1) | 43% (3) |
| ...free all their last turn and able to turn (per game) | 0.67 | 0.33 | 1.00 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.67 | 0.33 | 1.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.33 | 0.33 | 0.67 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.33 | 0.67 | 1.00 |

### Quality by phase: cnomg-c940641-p47

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.7 | 3.7 |
| Strategy | Charge objectives carried out (made contact) | 50% (4 of 8) | 71% (10 of 14) |
| Strategy | Shoot objectives carried out (shot that target) | 44% (8 of 18) | 25% (2 of 8) |
| Strategy | Support requests answered (helper made contact too) | - | 100% (2 of 2) |
| Strategy | Hexes on a unit its side charged or shot that turn | 0% (0 of 1) | 100% (3 of 3) |
| Strategy | Joined characters whose unit fought | 60% (3 of 5) | 0% (0 of 2) |
| Strategy | Lone characters that fought | 83% (5 of 6) | 71% (5 of 7) |
| Movement | Charges halted short of contact | 0.3 | 0.3 |
| Movement | Idle units | 1.7 | 2.3 |
| Movement | Points that never moved of their own | 120.7 | 0.0 |
| Movement | Fights charged into per game | 2.0 | 3.7 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 5 | 1 of 11, net +90 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 5 | 0 of 11 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 4 of 5, net +95 | 3 of 11, net +55 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 0 of 5 | 6 of 11, net +184 |
| Shooting | Shots by shooting units (incl. breath weapons) | 17.3 | 8.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 25% (13 of 52) | 24% (6 of 25) |
| Shooting | Points destroyed by shooting units | 223.7 | 0.0 |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | 0.3 | - |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 0% (0 of 1) | - |
| Magic | Wounds caused by magic missiles | 0.3 | 1.0 |
| Magic | Wounds caused by other spells | 0.7 | 0.7 |
| Magic | Points destroyed by magic (all spells) | 0.0 | 24.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 5.0 / 0.3 / 0.7 / 0.0 | 0.0 / 1.0 / 1.0 / 0.0 |
| Combat | Points destroyed in combat | 193.7 | 379.3 |
| Combat | Points run down | 0.0 | 180.0 |
| Combat | Net points per charged fight, damage counted | +66 | +115 |
| Combat | Net per 100 charger points, damage counted | +17.1 | +43.7 |
| Combat | First round won (charged fights) | 83% | 100% |
| Combat | Net points per charged fight | +63 | +128 |
| Combat | Net points per supported fight / lone fight | - / +63 | - / +128 |
| Combat | Charged fights on a top-3 enemy unit | 1 of 6 | 3 of 11 |
| Game | Points lost | 580.7 | 417.3 |
| Game | VP from objectives | 603.3 | 553.3 |
| Game | Lone holders (player turns) | 5.0 | 2.0 |

- Mine won / drew / lost: 0 / 2 / 1 of 3 ended games (of 3); mean margin (Mine - Opponent) -159 VP
- The side that went first won 1 of 1 games with a winner
- Points traded per game (both sides' losses): 998
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: cnomg-c940641-p47

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 2.0 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.7 | +25.2 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | 29.0 | -231.7 | 0.0 | 233.0 | 26.0 | +514.5 | 0.0 | 654.0 |
| BACKUP TARGETS | 0.3 | +0.8 | 0.0 | 0.0 | 2.0 | +4.4 | 0.0 | 80.0 |
| BLOCKED CHARGE SKIPPED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CAST JOB | 0.7 | +5.1 | 0.0 | 0.0 | 2.0 | +14.3 | 65.0 | 0.0 |
| CASTS AFTER FRIENDS | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | 0.3 | +13.5 | 0.0 | 0.0 | - | - | - | - |
| CHAFF PASSED | - | - | - | - | 0.3 | -0.5 | 65.0 | 0.0 |
| CHALLENGE BY POINTS | - | - | - | - | 0.7 | +44.3 | 0.0 | 41.7 |
| CHARACTER GUNS | 3.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHARGE LIST READ AGAIN | 0.3 | +48.8 | 0.0 | 0.0 | - | - | - | - |
| CHARGE LOSSES | 13.7 | -708.3 | 0.0 | 299.7 | 22.3 | -577.8 | 0.0 | 849.3 |
| CHARGE NOW FIRST | 1.7 | +0.0 | 168.3 | 0.0 | 3.0 | +0.0 | 224.3 | 72.7 |
| CLOSES ON WHAT IT BEATS | 11.3 | +0.0 | 0.0 | 143.7 | 7.0 | +0.0 | 0.0 | 0.0 |
| COMBAT PIVOT | - | - | - | - | 1.0 | +0.0 | 18.3 | 0.0 |
| CONVEYANCE SEARCH | - | - | - | - | 0.7 | +57.2 | 0.0 | 0.0 |
| COVER ONCE | 8.0 | -429.2 | 0.0 | 247.3 | 8.0 | -404.5 | 0.0 | 201.0 |
| DEFENSIVE FLOOR | - | - | - | - | 0.3 | -1.7 | 0.0 | 0.0 |
| DENIED BY THE FIGHT | 0.3 | -0.3 | 41.7 | 0.0 | 0.7 | -1.4 | 0.0 | 72.7 |
| DEPLOY BY FIGURES | 7.7 | +9.0 | 0.0 | 0.0 | 7.7 | +16.7 | 0.0 | 0.0 |
| EVASIVE BY THE ODDS | - | - | - | - | 3.0 | +172.5 | 48.0 | 0.0 |
| EXACT ROUND | 1.3 | +9.0 | 80.0 | 0.0 | 2.3 | +2.7 | 255.7 | 111.3 |
| FACES THE THREAT | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| FALL BACK GOOD ORDER | 1.3 | +9.5 | 88.3 | 0.0 | 3.7 | +32.7 | 309.3 | 111.3 |
| FALLS SHORT | 9.7 | +130.4 | 0.0 | 20.0 | 14.0 | +179.9 | 0.0 | 235.3 |
| FEATURE BUFFS | 1.3 | +19.8 | 0.0 | 61.3 | 0.7 | +12.4 | 0.0 | 0.0 |
| FIGHT TO THE END | 0.7 | +42.9 | 0.0 | 0.0 | 1.3 | +1.3 | 13.7 | 72.7 |
| FIRE IN ORDER | 1.0 | +0.0 | 34.0 | 0.0 | - | - | - | - |
| FIVE ACTION | 92.3 | +5845.3 | 667.0 | 1109.0 | 89.0 | +5449.3 | 811.7 | 1302.0 |
| FLANK NOT WEIGHED | 7.3 | +0.0 | 0.0 | 421.3 | 8.0 | +0.0 | 0.0 | 183.0 |
| FOCUS FIRE | 1.0 | +73.4 | 0.0 | 0.0 | - | - | - | - |
| FOLLOW UP WEIGHED | 1.3 | +71.5 | 0.0 | 0.0 | 1.7 | +527.8 | 0.0 | 67.0 |
| FOUR ROUNDS | 3.0 | +282.4 | 215.0 | 16.7 | 5.0 | +265.3 | 477.7 | 111.3 |
| FREED FROM HIS FIGHT | 2.7 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 204.0 |
| FRIEND SHOOTS FIRST | 0.3 | -1.8 | 0.0 | 0.0 | 0.3 | -0.3 | 0.0 | 38.7 |
| FRIENDS SHOTS CHECKED | 0.3 | +4.0 | 0.0 | 0.0 | - | - | - | - |
| GIVES UP | 0.3 | -4.8 | 0.0 | 0.0 | - | - | - | - |
| GOAL WALK | 3.0 | +125.7 | 0.0 | 0.0 | 14.3 | +1349.7 | 0.0 | 122.0 |
| GUN FIGURES | 2.7 | +36.1 | 116.0 | 21.7 | - | - | - | - |
| HARD STAY DROPPED | 1.0 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 38.0 |
| HE REFORMS ONCE FREED | 1.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 42.0 |
| HELPER UNSEEN | - | - | - | - | 0.3 | +0.0 | 0.0 | 38.7 |
| HIS CHARGE BY HIS RUN | 9.7 | +0.0 | 0.0 | 299.7 | 12.7 | +0.0 | 0.0 | 733.3 |
| HIS CHARGE DENIED | 1.3 | +30.8 | 83.7 | 0.0 | 0.7 | +41.6 | 130.0 | 0.0 |
| HIS CHARGE LIST | 6.7 | +0.0 | 0.0 | 58.3 | 7.3 | +0.0 | 0.0 | 172.0 |
| HIS LEGAL MOVES | 5.0 | +0.0 | 0.0 | 150.0 | 7.7 | +0.0 | 0.0 | 114.7 |
| HIS MOVE AND SHOT | 4.7 | -21.6 | 0.0 | 130.0 | 5.0 | -88.9 | 0.0 | 68.0 |
| HIS MOVE AS HE DECIDES | - | - | - | - | 45.3 | +12.3 | 952.7 | 0.0 |
| HIS MOVE WHY | 15.7 | +0.0 | 0.0 | 53.3 | - | - | - | - |
| HIS ONE MOVE | - | - | - | - | 28.0 | -205.0 | 0.0 | 497.3 |
| HIS ONE QUARTER | 3.3 | +0.0 | 0.0 | 18.3 | 7.3 | +0.0 | 0.0 | 248.7 |
| HIS OWN BEST MOVE | 8.7 | +0.0 | 0.0 | 263.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVE | 36.0 | +0.0 | 0.0 | 263.0 | 18.0 | +0.0 | 0.0 | 250.0 |
| HIS RANDOM MOVER COMES | 9.0 | +0.0 | 0.0 | 156.3 | 1.3 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 21.3 | +297.5 | 0.0 | 326.3 | 49.0 | +1336.4 | 0.0 | 954.7 |
| HIS SHOTS BY HIS RUN | 24.0 | +226.8 | 0.0 | 436.0 | 42.3 | +633.2 | 0.0 | 930.0 |
| HIS TURN DENIED | - | - | - | - | 1.7 | +55.5 | 60.7 | 72.7 |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 21.7 | +0.0 | 0.0 | 207.3 | 12.7 | +0.0 | 0.0 | 227.3 |
| HOLDER ASSIGNMENT | 12.7 | +788.7 | 0.0 | 73.0 | 7.7 | +501.3 | 0.0 | 113.7 |
| HOLDS AMBUSHERS | 1.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 2.7 | -108.3 | 215.0 | 0.0 | 4.7 | -124.6 | 297.7 | 72.7 |
| IDLE COST | 3.7 | -74.9 | 0.0 | 0.0 | 11.7 | -138.0 | 0.0 | 164.3 |
| JOINT CHARGE NOW | - | - | - | - | 1.3 | +40.0 | 73.3 | 0.0 |
| KEPT FROM ITS LAST STOP | 6.0 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 0.3 | +16.4 | 0.0 | 0.0 | 0.3 | +0.7 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 10.3 | +0.0 | 366.3 | 202.3 | 5.0 | +0.0 | 102.7 | 378.0 |
| LONE WIZARD KEPT IN | 1.0 | +52.2 | 0.0 | 0.0 | - | - | - | - |
| LONG SHOT | - | - | - | - | 0.3 | +1.8 | 20.0 | 0.0 |
| LOST AFTER ESCAPE | 1.0 | +0.4 | 135.0 | 0.0 | 0.7 | -0.4 | 0.0 | 38.7 |
| MANOEUVRE | 0.7 | -7.3 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| MARCH CHECK | - | - | - | - | 0.3 | +20.5 | 0.0 | 0.0 |
| MARCH OVER CASTS | 0.7 | +154.4 | 0.0 | 0.0 | - | - | - | - |
| MARCH WHEELS ONLY | 1.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 2.0 | +42.6 | 0.0 | 64.0 | 1.3 | +9.6 | 0.0 | 0.0 |
| MEETS IN TIME | 5.3 | +188.6 | 0.0 | 0.0 | 3.7 | +115.9 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 2.7 | +52.1 | 0.0 | 0.0 | 3.3 | +29.5 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 4.0 | +32.8 | 0.0 | 180.0 | 3.0 | +20.6 | 0.0 | 0.0 |
| MOVE ORDER | 0.7 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 38.7 |
| MOVE SPELL OUT OF RANGE | - | - | - | - | 0.7 | -4.6 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 7.0 | +618.9 | 0.0 | 178.0 | 8.3 | +696.8 | 0.0 | 237.3 |
| NEARER NOT NEEDED | 10.0 | +364.6 | 0.0 | 38.3 | 5.7 | +232.9 | 0.0 | 76.0 |
| NEXT CHARGE BY LIST | 4.3 | +402.5 | 0.0 | 130.0 | 5.0 | +491.9 | 0.0 | 114.7 |
| NEXT OBJECTIVE NEARER | 0.7 | -0.1 | 0.0 | 0.0 | - | - | - | - |
| NO DOUBLE ROUNDS | 2.3 | -102.3 | 215.0 | 0.0 | 4.0 | -128.2 | 424.3 | 111.3 |
| NO LATE CUT | 1.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | 0.3 | +0.1 | 0.0 | 0.0 | 0.7 | +7.1 | 0.0 | 0.0 |
| NOT WORTH A CAST | 2.7 | -2.8 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 4.7 | -150.1 | 0.0 | 40.7 | 6.7 | -115.5 | 0.0 | 164.0 |
| ONE CHECK AFTER THE LAST CHANGE | 1.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 4.0 | -59.1 | 0.0 | 89.0 | 7.7 | -225.5 | 0.0 | 271.0 |
| ONE OBJECTIVE FORMULA | 6.7 | -61.6 | 0.0 | 73.0 | 3.0 | -13.5 | 0.0 | 67.0 |
| ONE ROUTE | 1.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| OPENS UP | 0.3 | +15.3 | 38.0 | 0.0 | 0.7 | +7.5 | 36.7 | 0.0 |
| OVERRUNS AWAY | 0.7 | +2.9 | 79.7 | 0.0 | 1.0 | +24.2 | 154.0 | 0.0 |
| PATHS CROSS | 0.3 | +4.4 | 0.0 | 0.0 | - | - | - | - |
| PERIAPT WORTH | 0.3 | +40.5 | 0.0 | 0.0 | - | - | - | - |
| PIVOT GUARDS FLANK | - | - | - | - | 0.3 | -2.7 | 0.0 | 0.0 |
| PLAN RESULT | 46.0 | +399.6 | 198.3 | 1041.0 | 44.0 | +573.3 | 299.3 | 796.7 |
| PROMISE BELOW ZERO | 1.0 | +0.0 | 0.0 | 65.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE BY ITS OWN SUM | 7.7 | -245.9 | 0.0 | 48.0 | 10.7 | -263.3 | 0.0 | 84.0 |
| PROMISE HOLDS THE SPOT | 0.3 | +46.9 | 0.0 | 0.0 | - | - | - | - |
| PROMISE KNOWS THE FIGHT | 0.3 | -0.5 | 0.0 | 0.0 | - | - | - | - |
| PROMISE READS THE TABLE | - | - | - | - | 0.3 | -0.3 | 0.0 | 38.7 |
| QUARTER ODDS | 19.7 | +2251.6 | 195.3 | 126.7 | 24.3 | +2321.4 | 117.3 | 632.0 |
| RANDOM MOVE BY FIGURES | 4.0 | +103.3 | 0.0 | 48.3 | 5.7 | +12.4 | 0.0 | 0.0 |
| REAL GROUND | 1.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| REDIRECT BY WHAT IT STOPS | 0.7 | +9.8 | 0.0 | 0.0 | - | - | - | - |
| REDIRECT COUNTER | 3.7 | +148.0 | 0.0 | 88.0 | 0.7 | +29.7 | 0.0 | 0.0 |
| REDIRECT FOR A FRIEND IN REACH | 3.7 | +19.6 | 0.0 | 40.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| REFORMS TO MEET IT | 1.7 | -15.8 | 0.0 | 0.0 | 1.0 | -33.8 | 0.0 | 0.0 |
| REFUSING RETIRES | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | 1.7 | +20.8 | 0.0 | 24.0 | 0.3 | +5.8 | 0.0 | 38.0 |
| RISK BY ARC | 2.3 | -19.5 | 168.3 | 0.0 | 3.3 | +35.8 | 341.0 | 111.3 |
| RISK ON THE WAY | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| ROUNDS AFTER TERROR | 1.3 | -22.0 | 173.3 | 0.0 | - | - | - | - |
| RUN DOWN | 2.0 | -13.2 | 215.0 | 0.0 | 0.7 | -1.9 | 13.7 | 38.7 |
| SCOUT SPOT | 0.7 | +0.4 | 0.0 | 0.0 | - | - | - | - |
| SCOUT WAITS | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SEARCH SPOT | 0.3 | -0.3 | 0.0 | 20.0 | 0.7 | +7.9 | 0.0 | 0.0 |
| SECOND LOOK | 0.3 | +7.6 | 0.0 | 0.0 | 0.3 | +1.1 | 0.0 | 0.0 |
| SET CREDITED ONCE | - | - | - | - | 0.3 | -5.6 | 0.0 | 0.0 |
| SET UP BY THE SET | - | - | - | - | 0.7 | -88.8 | 0.0 | 0.0 |
| SET-UP ANY TARGET | - | - | - | - | 0.3 | +12.1 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.3 | +1.3 | 0.0 | 0.0 | 0.3 | +0.3 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 4.7 | +0.0 | 0.0 | 18.3 | 2.3 | +0.0 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 3.0 | +239.7 | 34.0 | 360.0 | 0.7 | +6.5 | 204.0 | 46.7 |
| SHOT OR CHARGE | 0.3 | -2.6 | 0.0 | 0.0 | 0.3 | -0.1 | 65.0 | 0.0 |
| SHOT RISK POINTS | 13.0 | -173.0 | 0.0 | 91.3 | 21.0 | -165.9 | 0.0 | 731.7 |
| SHOTS AFTER THE MOVES | 2.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 16.0 | +356.0 | 0.0 | 106.3 | 7.0 | +91.8 | 0.0 | 164.7 |
| SPELL SETS UP CHARGE | - | - | - | - | 0.3 | +12.1 | 0.0 | 0.0 |
| SPELL WORTH | 2.3 | +33.8 | 180.0 | 180.0 | - | - | - | - |
| SPELLS IN THE FIGHT | 0.3 | -32.6 | 0.0 | 0.0 | 0.7 | -1.7 | 200.0 | 38.7 |
| SPOT AS THE GAME MOVES | 6.7 | +0.0 | 0.0 | 115.7 | 10.7 | +0.0 | 0.0 | 291.7 |
| STAND AND SHOOT | 0.3 | -1.3 | 38.0 | 0.0 | 1.0 | -6.9 | 18.3 | 72.7 |
| STANDS FOR A REASON | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 28.0 | +0.0 | 452.0 | 485.0 | 27.7 | +0.0 | 334.0 | 84.7 |
| STAY WORTH | 11.3 | +62.1 | 36.7 | 0.0 | 8.0 | +38.1 | 130.0 | 121.3 |
| STUCK PIVOT | 0.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 18.0 | +1380.3 | 0.0 | 162.3 | 5.0 | +197.6 | 0.0 | 83.3 |
| SUPPORT NARROWED | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 180.0 | 77.3 |
| SUPPORT WORKED OUT | 18.0 | +1380.3 | 0.0 | 162.3 | 5.0 | +197.6 | 0.0 | 83.3 |
| SURE REACH TOGETHER | - | - | - | - | 2.0 | +31.7 | 0.0 | 77.3 |
| THE DEARER SUM KEEPS ITS PLAN | 1.7 | +0.0 | 0.0 | 24.0 | 2.0 | +0.0 | 0.0 | 38.7 |
| THE PROMISED MOVE | 0.3 | +0.0 | 0.0 | 30.7 | - | - | - | - |
| THE ROW IN ITS ORDER | 3.0 | +0.0 | 65.0 | 30.7 | 7.3 | +0.0 | 0.0 | 41.7 |
| THE ROW KEEPS ITS WAY | 4.7 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 67.0 |
| THE STEP BACK IS MADE | 3.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 67.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 44.0 | +0.0 | 0.0 | 342.0 | 40.0 | +0.0 | 0.0 | 614.7 |
| TIED UP BY THE SUM | 2.0 | +257.6 | 168.3 | 0.0 | 2.0 | +281.9 | 202.0 | 0.0 |
| TIME ON OUR SIDE | 28.7 | +286.9 | 0.0 | 512.0 | 16.3 | +167.9 | 0.0 | 0.0 |
| WAITS AGAIN | 0.3 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| WALKS ON ITS ROUTE | 0.3 | -4.7 | 0.0 | 0.0 | - | - | - | - |
| WEAPON BY POINTS | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| WHAT THE JOINER ADDS | 0.7 | +10.7 | 0.0 | 33.3 | - | - | - | - |
| WHO FIGHTS | 0.3 | +2.4 | 0.0 | 0.0 | 1.3 | -3.2 | 42.3 | 34.0 |
| WHO HITS BACK | - | - | - | - | 1.3 | +58.2 | 0.0 | 0.0 |
| WHOLE FIGHT | 0.3 | +0.0 | 0.0 | 16.7 | - | - | - | - |
| WHOLE FIGHT DANGER | 8.7 | -648.2 | 0.0 | 299.7 | 3.0 | -152.4 | 0.0 | 115.0 |
| WOUNDS ON THE RANKS | 1.3 | +0.8 | 0.0 | 0.0 | 1.7 | +34.5 | 0.0 | 0.0 |

### Rule changes: cnomg-c940641-p47

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 165 | 165 | 118 | 39.33 | +1987 | +16.8 |
| HIS MOVE AS HE DECIDES | 136 | 136 | 99 | 33.00 | +0 | +0.0 |
| HOLDER ASSIGNMENT | 61 | 61 | 57 | 19.00 | +4763 | +83.6 |
| LEGAL CHARGES ONLY | 46 | 46 | 46 | 15.33 | +0 | +0.0 |
| OFF BEST | 34 | 34 | 34 | 11.33 | -797 | -23.4 |
| FIVE ACTION | 544 | 518 | 33 | 11.00 | +2000 | +60.6 |
| HIS MOVE WHY | 47 | 47 | 32 | 10.67 | +0 | +0.0 |
| THE TABLE AGAIN | 36 | 36 | 31 | 10.33 | +0 | +0.0 |
| HIS SHOT LIST | 211 | 195 | 29 | 9.67 | +308 | +10.6 |
| HIS SHOTS BY HIS RUN | 199 | 186 | 29 | 9.67 | +284 | +9.8 |
| SUPPORT ADDS | 69 | 66 | 24 | 8.00 | +864 | +36.0 |
| SUPPORT WORKED OUT | 69 | 66 | 24 | 8.00 | +864 | +36.0 |
| DEPLOY BY FIGURES | 46 | 46 | 23 | 7.67 | +275 | +12.0 |
| PROMISE BY ITS OWN SUM | 55 | 55 | 21 | 7.00 | -1528 | -72.7 |
| QUARTER ODDS | 132 | 123 | 19 | 6.33 | +905 | +47.6 |
| HIS ONE MOVE | 84 | 81 | 18 | 6.00 | +0 | +0.0 |
| MOVE TO CHARGE COMPUTED | 46 | 38 | 18 | 6.00 | +1426 | +79.2 |
| FOUR ROUNDS | 24 | 23 | 15 | 5.00 | +554 | +37.0 |
| RANDOM MOVE BY FIGURES | 29 | 29 | 15 | 5.00 | +347 | +23.2 |
| NEXT CHARGE BY LIST | 28 | 26 | 14 | 4.67 | +1351 | +96.5 |
| ADVANCE LANE KEPT | 13 | 13 | 13 | 4.33 | +0 | +0.0 |
| TIME ON OUR SIDE | 135 | 115 | 13 | 4.33 | +17 | +1.3 |
| GOAL WALK | 52 | 48 | 12 | 4.00 | +542 | +45.2 |
| REDIRECT FOR A FRIEND IN REACH | 12 | 12 | 12 | 4.00 | +21 | +1.8 |
| HARD STAY DROPPED | 11 | 11 | 11 | 3.67 | +0 | +0.0 |
| MEETS IN TIME | 27 | 27 | 11 | 3.67 | +349 | +31.8 |
| TIED UP BY THE SUM | 12 | 12 | 11 | 3.67 | +445 | +40.4 |
| CHARGE LOSSES | 108 | 101 | 10 | 3.33 | +690 | +69.0 |
| FOLLOW UP WEIGHED | 9 | 9 | 9 | 3.00 | +1798 | +199.8 |
| MOVE ORDER | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| SHOOTS FROM THE BEST SPOT | 11 | 11 | 9 | 3.00 | +229 | +25.5 |
| HOLDS AMBUSHERS | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| COVER ONCE | 48 | 32 | 6 | 2.00 | +65 | +10.9 |
| EVASIVE BY THE ODDS | 9 | 9 | 6 | 2.00 | +513 | +85.5 |
| RESERVE FALL BACK | 6 | 6 | 6 | 2.00 | +80 | +13.3 |
| JOINT CHARGE NOW | 4 | 4 | 4 | 1.33 | +120 | +30.0 |
| STUCK PIVOT | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| WHO HITS BACK | 4 | 4 | 4 | 1.33 | +120 | +29.9 |
| COMBAT PIVOT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| FIRE IN ORDER | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| FOCUS FIRE | 3 | 3 | 3 | 1.00 | +220 | +73.4 |
| IDLE COST | 46 | 22 | 3 | 1.00 | +18 | +6.0 |
| LONE WIZARD KEPT IN | 3 | 3 | 3 | 1.00 | +157 | +52.2 |
| MAX FOR POSITIONING | 10 | 10 | 3 | 1.00 | +13 | +4.2 |
| RISK BY ARC | 17 | 16 | 3 | 1.00 | +116 | +38.7 |
| SHOT RISK POINTS | 102 | 94 | 3 | 1.00 | +11 | +3.8 |
| SHOTS IN THE MOVE | 69 | 49 | 3 | 1.00 | +146 | +48.7 |
| WHOLE FIGHT DANGER | 35 | 34 | 3 | 1.00 | +291 | +97.0 |
| AFTERMATH IN POINTS | 2 | 2 | 2 | 0.67 | +76 | +37.9 |
| CHALLENGE BY POINTS | 2 | 2 | 2 | 0.67 | +133 | +66.4 |
| FACES THE THREAT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| FALLS SHORT | 71 | 58 | 2 | 0.67 | +0 | +0.0 |
| HIS CHARGE DENIED | 6 | 6 | 2 | 0.67 | +30 | +15.1 |
| HIS TURN DENIED | 5 | 5 | 2 | 0.67 | +117 | +58.7 |
| LANE BY FIGURES | 2 | 2 | 2 | 0.67 | +51 | +25.7 |
| SCOUT WAITS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| SECOND LOOK | 2 | 2 | 2 | 0.67 | +26 | +13.1 |
| SHOOTERS IN TWO RANKS | 2 | 2 | 2 | 0.67 | +5 | +2.5 |
| STAY WORTH | 58 | 49 | 2 | 0.67 | +23 | +11.3 |
| THE ROW IN ITS ORDER | 31 | 2 | 2 | 0.67 | +0 | +0.0 |
| WEAPON BY POINTS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| WHAT THE JOINER ADDS | 2 | 2 | 2 | 0.67 | +59 | +29.5 |
| BLOCKED CHARGE SKIPPED | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CAST JOB | 8 | 8 | 1 | 0.33 | +1 | +1.0 |
| CASTS FROM BEHIND | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CHAFF IN THE MOVE | 1 | 1 | 1 | 0.33 | +21 | +21.4 |
| CHAFF PASSED | 1 | 1 | 1 | 0.33 | -2 | -1.5 |
| CHARGE LIST READ AGAIN | 1 | 1 | 1 | 0.33 | +146 | +146.4 |
| CHARGE NOW FIRST | 14 | 14 | 1 | 0.33 | -25 | -25.0 |
| EXACT ROUND | 11 | 11 | 1 | 0.33 | +4 | +4.2 |
| FALL BACK GOOD ORDER | 15 | 14 | 1 | 0.33 | +15 | +14.8 |
| FIGHT TO THE END | 6 | 5 | 1 | 0.33 | +73 | +72.7 |
| FRIENDS SHOTS CHECKED | 1 | 1 | 1 | 0.33 | +12 | +12.1 |
| HIS MOVE AND SHOT | 29 | 28 | 1 | 0.33 | +10 | +9.8 |
| MANOEUVRE | 5 | 5 | 1 | 0.33 | +6 | +6.2 |
| MARCH CHECK | 1 | 1 | 1 | 0.33 | +26 | +26.1 |
| MISSILES IN THE MOVE | 18 | 13 | 1 | 0.33 | +3 | +2.8 |
| NEARER NOT NEEDED | 47 | 45 | 1 | 0.33 | +7 | +6.7 |
| NO DOUBLE ROUNDS | 19 | 18 | 1 | 0.33 | +19 | +19.2 |
| ONE OBJECTIVE FORMULA | 29 | 20 | 1 | 0.33 | +37 | +36.5 |
| OPENS UP | 3 | 3 | 1 | 0.33 | +8 | +8.3 |
| PATHS CROSS | 1 | 1 | 1 | 0.33 | +13 | +13.2 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.33 | +122 | +121.5 |
| PIVOT GUARDS FLANK | 1 | 1 | 1 | 0.33 | -8 | -8.2 |
| PROMISE HOLDS THE SPOT | 1 | 1 | 1 | 0.33 | +141 | +140.6 |
| PROMISE KNOWS THE FIGHT | 1 | 1 | 1 | 0.33 | -2 | -1.6 |
| REDIRECT BY WHAT IT STOPS | 2 | 2 | 1 | 0.33 | +0 | +0.0 |
| REDIRECT COUNTER | 13 | 8 | 1 | 0.33 | +39 | +38.6 |
| REFUSING RETIRES | 1 | 1 | 1 | 0.33 | +4 | +4.1 |
| RUN DOWN | 8 | 8 | 1 | 0.33 | +32 | +32.3 |
| SEARCH SPOT | 3 | 3 | 1 | 0.33 | +24 | +23.7 |
| SET UP BY THE SET | 2 | 2 | 1 | 0.33 | +0 | +0.0 |
| SURE REACH TOGETHER | 6 | 5 | 1 | 0.33 | +2 | +2.5 |
| WALKS ON ITS ROUTE | 1 | 1 | 1 | 0.33 | -14 | -14.2 |
| BACKUP TARGETS | 7 | 6 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 1 | trace | - | - | - | - |
| CHARACTER GUNS | 10 | 10 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 55 | 55 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 2 | not checked | - | - | - | - |
| DEFENSIVE FLOOR | 1 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 3 | 3 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 6 | 6 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 46 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 17 | 15 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 2 | 2 | 0 | 0.00 | - | - |
| GIVES UP | 1 | 1 | 0 | 0.00 | - | - |
| GUN FIGURES | 8 | not checked | - | - | - | - |
| HE REFORMS ONCE FREED | 9 | 7 | 0 | 0.00 | - | - |
| HELPER UNSEEN | 1 | 1 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 67 | 66 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 42 | 40 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 38 | 37 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 32 | 30 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 35 | 33 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 162 | 152 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 31 | 28 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN RUN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 103 | 102 | 0 | 0.00 | - | - |
| HONEST WORTH | 22 | 21 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 23 | 22 | 0 | 0.00 | - | - |
| LONG SHOT | 1 | 1 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 5 | 4 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 2 | 2 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 6 | 5 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 21 | 19 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 2 | trace | - | - | - | - |
| NEXT OBJECTIVE NEARER | 2 | 2 | 0 | 0.00 | - | - |
| NO LATE CUT | 7 | 7 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 18 | 18 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT TURNED | 3 | 3 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 8 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 5 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 35 | 15 | 0 | 0.00 | - | - |
| ONE ROUTE | 6 | 5 | 0 | 0.00 | - | - |
| OVERRUNS AWAY | 5 | 5 | 0 | 0.00 | - | - |
| PLAN RESULT | 270 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 4 | 4 | 0 | 0.00 | - | - |
| PROMISE READS THE TABLE | 1 | 1 | 0 | 0.00 | - | - |
| REAL GROUND | 6 | 5 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 8 | 8 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 2 | 1 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 4 | 4 | 0 | 0.00 | - | - |
| SCOUT SPOT | 2 | 2 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 1 | 1 | 0 | 0.00 | - | - |
| SET-UP ANY TARGET | 1 | not checked | - | - | - | - |
| SHOOTERS ON THE TABLE | 21 | not checked | - | - | - | - |
| SHOT OR CHARGE | 2 | 2 | 0 | 0.00 | - | - |
| SHOTS AFTER THE MOVES | 8 | 8 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 1 | not checked | - | - | - | - |
| SPELL WORTH | 7 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 3 | 3 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 52 | 49 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 4 | 4 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 4 | 4 | 0 | 0.00 | - | - |
| STANDS STILL | 167 | 162 | 0 | 0.00 | - | - |
| SUPPORT NARROWED | 3 | 3 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 11 | not checked | - | - | - | - |
| THE PROMISED MOVE | 1 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 19 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 15 | not checked | - | - | - | - |
| THE TABLE BINDS | 252 | not checked | - | - | - | - |
| WAITS AGAIN | 7 | 6 | 0 | 0.00 | - | - |
| WHO FIGHTS | 5 | 4 | 0 | 0.00 | - | - |
| WHOLE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| WOUNDS ON THE RANKS | 9 | 9 | 0 | 0.00 | - | - |

### Off best figure: cnomg-c940641-p47

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 4.33 | 5.00 | 23.9 |
| PROMISE BY ITS OWN SUM | rule | 3.00 | 4.00 | 72.7 |
| ARMY TABLE | rule | 4.00 | 2.33 | 48.7 |
| RULE SWITCHED OFF | gate | - | 1.67 | 18.2 |
| CHAFF PASSED | rule | - | 0.33 | 1.5 |
| CHARGE NOW FIRST | rule | - | 0.33 | 25.0 |
| FALLBACK | gate | 0.33 | - | 35.6 |
| JOINT CHARGE NOW | rule | - | 0.33 | 3.0 |
| PIVOT GUARDS FLANK | rule | - | 0.33 | 8.2 |
| PROMISE KNOWS THE FIGHT | rule | 0.33 | - | 1.6 |
| WALKS ON ITS ROUTE | rule | 0.33 | - | 14.2 |

### Plans: cnomg-c940641-p47

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 2.3 | 57% | 330 | 153 | 46% |
| Mine | join | 1.3 | 100% | 83 | 0 | 0% |
| Mine | move | 37.3 | 93% | 1959 | 0 | 0% |
| Mine | shoot | 4.7 | 79% | 200 | 247 | 123% |
| Mine | support | 0.3 | 100% | 8 | 0 | 0% |
| Opponent | charge | 4.3 | 77% | 404 | 452 | 112% |
| Opponent | join | 1.3 | 100% | 70 | 0 | 0% |
| Opponent | move | 36.3 | 97% | 1822 | 0 | 0% |
| Opponent | shoot | 2.0 | 67% | 133 | 122 | 92% |

### Battle groups: cnomg-c940641-p47

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 3.7 | 27% | 100% | 33% | 0% | 0% | 0% | 0% | 100% | 0% |
| Opponent | REDIRECT COUNTER | 0.7 | 0% | - | - | - | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: cnomg-c940641-p47

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | - | - | - | - |
| Mine | Chaff | 5 | 145 (5) | 32 | 113 | 77 | 0% | 3.2 | 178 (4) | 0 (1) | - | 178 (4) | 0 (1) |
| Mine | Character | 9 | 15 (9) | 15 | 0 | 24 | 11% | 3.4 | 22 (5) | 0 (4) | - | 15 (2) | 16 (7) |
| Mine | Clean-up | 2 | 0 (2) | 0 | 0 | 0 | 50% | 6.0 | - | 0 (1) | 0 (1) | 0 (1) | 0 (1) |
| Mine | Fast Hammer | 4 | 0 (4) | 0 | 0 | 57 | 25% | 2.0 | 0 (2) | 0 (2) | - | 0 (1) | 0 (3) |
| Mine | Hammer | 4 | 63 (4) | 63 | 0 | 22 | 25% | 1.0 | 60 (1) | 89 (2) | 0 (1) | 63 (3) | 60 (1) |
| Mine | Holder | 7 | 44 (7) | 13 | 31 | 15 | 43% | 3.5 | 85 (2) | 22 (4) | 0 (1) | 39 (5) | 60 (2) |
| Mine | Shooter | 5 | 92 (5) | 82 | 10 | 59 | 0% | 1.2 | 227 (1) | 97 (2) | 25 (2) | 130 (3) | 27 (2) |
| Mine | Wizard | 2 | 0 (2) | 0 | 0 | 62 | 0% | 1.0 | 0 (1) | - | - | - | 0 (1) |
| Opponent | Chaff | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Character | 9 | 47 (9) | 47 | 0 | 9 | 22% | 2.9 | 65 (6) | 0 (2) | - | 98 (5) | 16 (3) |
| Opponent | Clean-up | 1 | 49 (1) | 49 | 0 | 0 | 0% | 3.0 | - | 49 (1) | - | - | 49 (1) |
| Opponent | Fast Hammer | 5 | 13 (5) | 0 | 13 | 37 | 40% | 2.3 | 21 (3) | - | 0 (2) | 0 (2) | 25 (3) |
| Opponent | Hammer | 10 | 32 (10) | 32 | 0 | 22 | 20% | 3.0 | 34 (4) | 35 (5) | 0 (1) | 67 (4) | 8 (6) |
| Opponent | Holder | 4 | 24 (4) | 0 | 24 | 0 | 100% | - | 100 (1) | 0 (2) | - | - | 29 (3) |
| Opponent | Shooter | 3 | 33 (3) | 0 | 33 | 100 | 0% | 1.0 | 64 (1) | 13 (2) | - | - | 33 (3) |

### Charged fights: cnomg-c940641-p47

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Skaven | 1 | 232 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Mine | Tomb Kings of Khemri | 1 | 439 | 380 | 5.0 | 1.0 | 76 | 0 | +76 | 0 of 5 | 5 of 5 | - | +76 |
| Mine | Vampire Counts | 1 | 0 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 1 of 1 | 0 of 1 | - | +0 |
| **Mine** | all armies | 3 | 224 | 127 | 2.0 | 1.0 | 63 | 0 | +63 | 1 of 6 | 5 of 6 | - | +63 |
| Opponent | Warriors of Chaos | 2 | 0 | 376 | 2.5 | 1.0 | 150 | 0 | +150 | 1 of 5 | 5 of 5 | - | +150 |
| Opponent | Wood Elf Realms | 1 | 72 | 662 | 6.0 | 1.0 | 110 | 0 | +110 | 2 of 6 | 6 of 6 | - | +110 |
| **Opponent** | all armies | 3 | 24 | 471 | 3.7 | 1.0 | 128 | 0 | +128 | 3 of 11 | 11 of 11 | - | +128 |

### Effective charges: cnomg-c940641-p47

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Tomb Kings of Khemri | 5 | 0 | 0 | 0 | 0 | 4 (net +95) | 0 | 1 | 0% (0 of 4) |
| Mine | Vampire Counts | 1 | 0 | 1 (net +0) | 0 | 0 | 0 | 0 | 0 | 0% (0 of 1) |
| Opponent | Warriors of Chaos | 5 | 0 | 0 | 0 | 0 | 2 (net +55) | 3 (net +214) | 0 | 0% (0 of 5) |
| Opponent | Wood Elf Realms | 6 | 1 (net +90) | 0 | 0 | 1 (net +55) | 1 (net +55) | 3 (net +154) | 0 | 0% (0 of 6) |

### Charged fights, damage counted: cnomg-c940641-p47

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 50-54% | 1 | 205 | 365 | +0 | 0 | 89 | -89 | -43.6 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 4 | 421 | 126 | +95 | 95 | 0 | +95 | +22.6 |
| Mine | No odds | 1 | 431 | 125 | +0 | 107 | 0 | +107 | +24.9 |
| Mine | All fights | 6 | 387 | 166 | +63 | 81 | 15 | +66 | +17.1 |
| Opponent | Long shot (under 50%) | 1 | 102 | 170 | +90 | 122 | 68 | +54 | +52.8 |
| Opponent | 76-89% | 1 | 102 | 55 | +55 | 55 | 0 | +55 | +53.9 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 6 | 242 | 167 | +184 | 184 | 27 | +156 | +64.6 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 3 | 410 | 55 | +55 | 72 | 0 | +72 | +17.5 |
| Opponent | All fights | 11 | 262 | 127 | +128 | 136 | 21 | +115 | +43.7 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| cnomg-c940641-p47 | move | 24 | 2 (8%) | 1 (4%) | 6 (25%) | 16 (67%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L2429 |
| Invocation of Nehek | Mine | L2429 |
| Periapt of Soul Exchange | Mine | L2131 |
| Ring of Doom | Opponent | L2131 |
| Storm Daemon (Renegade 2.0) | Mine | L2131 |

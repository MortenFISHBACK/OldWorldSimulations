# Doctrine scorecard: cnomg-c940641-p35

### Scorecard: cnomg-c940641-p35

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L2127 | 3 | 1 | Mine | yes | 17 | 5 | 1 | 1 | 0 | 0 | 0 | 555 |
| L2127 | 3 | 1 | Opponent | no | 0 | 2 | 5 | 1 | 1 | 0 | 0 | 0 |
| L2231 | 5 | 1 | Mine | yes | - | 4 | 6 | 0 | 0 | 0 | 0 | 242 |
| L2231 | 5 | 1 | Opponent | no | - | - | 1 | 2 | 2 | 0 | 0 | 170 |
| L2335 | 1 | 1 | Mine | no | 8 | 3 | 4 | 1 | 0 | 0 | 0 | 0 |
| L2335 | 1 | 1 | Opponent | no | 1 | 1 | 3 | 2 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 67% | 12.5 | 4.0 | 3.7 | 0.7 | 0.0 | 0.0 | 0.0 | 265.7 |
| **Average** | | | Opponent | 0% | 0.5 | 1.5 | 3.0 | 1.7 | 1.0 | 0.0 | 0.0 | 56.7 |

### KPIs: cnomg-c940641-p35

Rules off - Opponent only: NO OLD ONE-MOVE GUESS.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 13) | 0% (0 of 14) | 0% (0 of 27) |
| Winner chose to follow up after the loser gave ground |  | 92% (11 of 12); on the table 92% | 100% (2 of 2); on the table 100% | 93% (13 of 14); on the table 93% |
| Winner chose to pursue after the loser fell back in good order |  | 0% (0 of 1); on the table 0% | - | 0% (0 of 1); on the table 0% |
| Winner chose to pursue after the loser fled |  | 0% (0 of 1); on the table 0% | 100% (2 of 2); on the table 100% | 67% (2 of 3); on the table 67% |
| Winner chose to follow up or pursue (all three) |  | 79% (11 of 14); on the table 79% | 100% (4 of 4); on the table 100% | 83% (15 of 18); on the table 83% |
| Magic missiles tried each own turn | 50%+ | 17% (1 of 6) | 22% (4 of 18) | 21% (5 of 24) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 25% (1 of 4) | 29% (4 of 14) | 28% (5 of 18) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 50% (3 of 6) | 50% (4 of 8) | 50% (7 of 14) |
| Points that never fought | lower | 34% (2041 of 5999) | 29% (1738 of 6000) | 31% (3779 of 11999) |
|   infantry points that never fought | lower | 64% (991 of 1552) | 48% (495 of 1035) | 57% (1486 of 2587) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 47% (9 of 19) | 73% (22 of 30) | 63% (31 of 49) |
| Bound items with a magic missile used (at least once a game) |  | 0% (0 of 1); 0.0 uses a game | 50% (1 of 2); 0.7 uses a game | 33% (1 of 3); 0.3 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 100% (1 of 1); 0.3 uses a game | 0.0 uses a game | 100% (1 of 1); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 35% (1582 of 4484) | 62% (3460 of 5546) | 50% (5042 of 10030) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 2.3 (50%) | 2.3 (37%) |
| MARCHED: its unit marched | 1.0 (60%) | 1.0 (21%) | 2.0 (32%) |
| IN COMBAT: engaged in combat | 0.7 (40%) | 1.0 (21%) | 1.7 (26%) |
| GONE: slain | 0.0 (0%) | 0.3 (7%) | 0.3 (5%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 11.3 | 1.0 | 1.0 | 1.7 | 0.7 | 3.0 |
| not cast | 2.7 | 1.0 | 1.0 | 6.3 | 1.3 | 13.0 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (3%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.3 (33%) | 0.0 (0%) | 2.3 (37%) | 0.0 (0%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.0 (32%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.3 (12%) | 0.3 (33%) | 0.3 (33%) | 1.7 (26%) | 0.7 (50%) | 0.0 (0%) |
| GONE: slain | 0.0 (0%) | 0.3 (33%) | 0.3 (33%) | 0.3 (5%) | 0.0 (0%) | 2.0 (15%) |
| STUPIDITY: Stupidity | 0.7 (25%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (50%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.7 (62%) | 0.0 (0%) | 0.3 (33%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 10.7 (82%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.0 a game | 1.0 a game | 0.5 a game |
| stood (cast and not dispelled) | - | 33% (1 of 3) | 33% (1 of 3) |
| the unit moved after it | - | 0% (0 of 1) | 0% (0 of 1) |
| it charged on its next turn | - | 0% (0 of 1) | 0% (0 of 1) |
| the enemy charged it first | - | 0% (0 of 1) | 0% (0 of 1) |
| it fought by the end of its next turn | - | 0% (0 of 1) | 0% (0 of 1) |
| it moved out of a charge the enemy had planned (not charged first) | - | 0% (0 of 1) | 0% (0 of 1) |
| none of these (no charge, no fight, no charge escaped) | - | 100% (1 of 1) | 100% (1 of 1) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 63% (66 of 104) | 55% (18 of 33) | 61% (84 of 137) |
|   cavalry | 100% (15 of 15) | 50% (9 of 18) | 73% (24 of 33) |
|   character | 0% (0 of 20) | 17% (1 of 6) | 4% (1 of 26) |
|   chariot | 90% (9 of 10) | - | 90% (9 of 10) |
|   infantry | 71% (42 of 59) | 89% (8 of 9) | 74% (50 of 68) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 0.3 (3%) | 1.7 (33%) | 2.0 (11%) |
| CHARGED: it charged | 2.7 (21%) | 1.3 (27%) | 4.0 (23%) |
| FLEEING: it fled or was fleeing | 0.0 (0%) | 0.3 (7%) | 0.3 (2%) |
| IN COMBAT: it fought this turn or the last | 0.3 (3%) | 0.7 (13%) | 1.0 (6%) |
| NO TARGET IN RANGE | 5.0 (39%) | 0.0 (0%) | 5.0 (28%) |
| ONLY IN COMBAT: the only targets were in combat | 1.3 (11%) | 0.0 (0%) | 1.3 (8%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 2.3 (18%) | 1.0 (20%) | 3.3 (19%) |
| OTHER BAR | 0.7 (5%) | 0.0 (0%) | 0.7 (4%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 13.3 | 2.0 | 88% | 4.0 pts | 54 pts |
| character | 0.3 | 0.0 | 100% | 0.0 pts | 0 pts |
| chariot | 3.0 | 0.7 | 78% | 3.5 pts | 10 pts |
| infantry | 19.0 | 3.3 | 84% | 5.3 pts | 101 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 6.0 | 4.3 | 5.2 |
| Charges that made contact a game | 3.7 | 3.7 | 3.7 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.00 declared, 1.00 contact (1 units) | 0.50 declared, 0.50 contact (2 units) | 0.67 declared, 0.67 contact (3 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 1.00 declared, 0.50 contact (2 units) | 1.00 declared, 0.50 contact (2 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.53 declared, 0.31 contact (32 units) | 0.45 declared, 0.41 contact (22 units) | 0.50 declared, 0.35 contact (54 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 57% (4 of 7) | 100% (1 of 1) | 0% (0 of 1) | 56% (5 of 9) |
| Character in a unit | 100% (4 of 4) | - | 100% (1 of 1) | 100% (5 of 5) |
| Character on its own | 100% (4 of 4) | 100% (1 of 1) | 0% (0 of 7) | 42% (5 of 12) |
| Chariot | 50% (1 of 2) | - | - | 50% (1 of 2) |
| Infantry | 64% (7 of 11) | 100% (1 of 1) | - | 67% (8 of 12) |
| Monster | 67% (4 of 6) | 100% (1 of 1) | - | 71% (5 of 7) |
| Monstrous | 100% (2 of 2) | - | - | 100% (2 of 2) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Skaven | 1 | 90% (9 of 10); on the table 90% | 17% (1 of 6) | 21% | 56% (5 of 9) | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Tomb Kings of Khemri | 2 | 50% (2 of 4); on the table 50% | - | 41% | 40% (4 of 10) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 1 | 100% (2 of 2); on the table 100% | 17% (1 of 6) | 37% | 50% (3 of 6) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 1 | - | 0% (0 of 6) | 26% | 92% (11 of 12) | 100% (1 of 1); 2.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 1 | 100% (2 of 2); on the table 100% | 50% (3 of 6) | 24% | 67% (8 of 12) | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (cnomg-c940641-p35, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 44% (4) | 57% (4) | 50% (8) |
| ...free all their last turn and able to turn (per game) | 0.67 | 1.00 | 1.67 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.33 | 0.33 | 0.67 |
| ...with the charger already in that arc before they moved (per game) | 0.67 | 1.00 | 1.67 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.33 | 0.33 |

### Quality by phase: cnomg-c940641-p35

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.0 | 4.0 |
| Strategy | Charge objectives carried out (made contact) | 44% (7 of 16) | 33% (3 of 9) |
| Strategy | Shoot objectives carried out (shot that target) | 55% (11 of 20) | 43% (3 of 7) |
| Strategy | Support requests answered (helper made contact too) | 0% (0 of 1) | - |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | - | 100% (1 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | - | 100% (2 of 2) |
| Strategy | Joined characters whose unit fought | 0% (0 of 3) | 67% (4 of 6) |
| Strategy | Lone characters that fought | 100% (7 of 7) | 71% (5 of 7) |
| Movement | Charges halted short of contact | 0.7 | 0.0 |
| Movement | Idle units | 0.7 | 1.7 |
| Movement | Points that never moved of their own | 265.7 | 56.7 |
| Movement | Fights charged into per game | 3.7 | 3.7 |
| Movement | Charges with odds: long shots (under 50%) | 1 of 9, net +0 | 2 of 7, net +0 |
| Movement | Charges with odds: sweet spot (55-75%) | 1 of 9, net +0 | 0 of 7 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 2 of 9, net +118 | 1 of 7, net +66 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 4 of 9, net +167 | 2 of 7, net +275 |
| Shooting | Shots by shooting units (incl. breath weapons) | 23.7 | 6.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 23% (16 of 71) | 56% (10 of 18) |
| Shooting | Points destroyed by shooting units | 0.0 | 48.3 |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | 0.3 | 0.7 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 0% (0 of 1) | 0% (0 of 2) |
| Magic | Wounds caused by other spells | 2.3 | 0.3 |
| Magic | Points destroyed by magic (all spells) | 0.0 | 21.7 |
| Magic | Augments / hexes / assailments / vortexes cast | 6.7 / 0.0 / 1.3 / 0.0 | 2.7 / 0.7 / 1.3 / 0.3 |
| Combat | Points destroyed in combat | 526.3 | 289.3 |
| Combat | Points run down | 0.0 | 120.7 |
| Combat | Net points per charged fight, damage counted | +67 | +42 |
| Combat | Net per 100 charger points, damage counted | +20.9 | +19.7 |
| Combat | First round won (charged fights) | 91% | 36% |
| Combat | Net points per charged fight | +82 | +47 |
| Combat | Net points per supported fight / lone fight | - / +82 | - / +47 |
| Combat | Charged fights on a top-3 enemy unit | 2 of 11 | 5 of 11 |
| Game | Points lost | 495.0 | 609.7 |
| Game | VP from objectives | 1193.3 | 353.3 |
| Game | Lone holders (player turns) | 12.5 | 0.5 |

- Mine won / drew / lost: 2 / 1 / 0 of 3 ended games (of 3); mean margin (Mine - Opponent) +992 VP
- The side that went first won 1 of 2 games with a winner
- Points traded per game (both sides' losses): 1105
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: cnomg-c940641-p35

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.3 | +9.5 | 0.0 | 70.0 | - | - | - | - |
| ARMY TABLE | 28.7 | +417.9 | 0.0 | 118.0 | 21.3 | +232.9 | 0.0 | 0.0 |
| ASSAILMENT BY POINTS | 0.3 | +0.8 | 0.0 | 46.7 | 0.7 | +3.7 | 0.0 | 126.7 |
| BACKUP TARGETS | - | - | - | - | 0.3 | +0.3 | 0.0 | 0.0 |
| BLOWS WHERE AIMED | - | - | - | - | 0.3 | -160.9 | 74.0 | 0.0 |
| CAST JOB | - | - | - | - | 2.0 | +5.4 | 24.0 | 0.0 |
| CASTER AWAY FROM SCREEN | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | - | - | - | - | 0.7 | +17.5 | 0.0 | 0.0 |
| CHAFF PASSED | 0.3 | +0.0 | 0.0 | 48.3 | - | - | - | - |
| CHALLENGE BY POINTS | - | - | - | - | 0.7 | +31.4 | 0.0 | 41.7 |
| CHARACTER GUNS | 2.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHARGE LOSSES | 12.3 | -360.6 | 0.0 | 280.0 | 22.0 | -1274.6 | 0.0 | 170.0 |
| CHARGE NOT DECLARED | - | - | - | - | 0.3 | +0.0 | 0.0 | 20.0 |
| CHARGE NOW FIRST | 3.3 | +0.0 | 302.0 | 0.0 | 2.0 | +0.0 | 281.3 | 0.0 |
| CLOSES ON WHAT IT BEATS | 11.0 | +0.0 | 0.0 | 70.0 | 13.3 | +0.0 | 0.0 | 0.0 |
| COMBAT PIVOT | 1.0 | +0.0 | 61.7 | 0.0 | 0.7 | +0.0 | 0.0 | 25.0 |
| CONVEYANCE SEARCH | - | - | - | - | 1.0 | +76.8 | 0.0 | 91.3 |
| COVER ONCE | 8.3 | -392.9 | 0.0 | 20.0 | 10.0 | -495.8 | 0.0 | 46.7 |
| DEPLOY BY FIGURES | 8.0 | +21.9 | 0.0 | 48.3 | 7.7 | +21.5 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | - | - | - | - | 0.3 | -28.2 | 74.0 | 0.0 |
| EDGE GIVE GROUND | 0.3 | +1.4 | 41.7 | 0.0 | 0.3 | +10.7 | 48.3 | 0.0 |
| EVASIVE BY THE ODDS | - | - | - | - | 2.3 | +166.5 | 0.0 | 42.0 |
| EXACT ROUND | 3.0 | +202.2 | 197.0 | 0.0 | 3.3 | -31.8 | 272.7 | 77.0 |
| FALL BACK GOOD ORDER | 5.0 | +9.0 | 344.0 | 0.0 | 3.0 | +0.3 | 326.7 | 35.0 |
| FALLBACK BY WORTH | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| FALLS SHORT | 1.7 | +14.6 | 0.0 | 22.0 | 21.7 | +261.1 | 0.0 | 223.3 |
| FEATURE BUFFS | 1.0 | +41.0 | 0.0 | 0.0 | 1.7 | +81.6 | 0.0 | 0.0 |
| FIGHT TO THE END | - | - | - | - | 1.0 | +43.9 | 192.3 | 0.0 |
| FIVE ACTION | 107.0 | +10088.7 | 924.3 | 853.3 | 82.3 | +2922.4 | 630.7 | 653.0 |
| FLANK NOT WEIGHED | 8.3 | +0.0 | 0.0 | 225.7 | 11.3 | +0.0 | 0.0 | 0.0 |
| FOLLOW UP WEIGHED | 1.3 | +269.2 | 0.0 | 0.0 | - | - | - | - |
| FOUR ROUNDS | 6.0 | +877.1 | 405.7 | 0.0 | 4.0 | +256.9 | 411.7 | 77.0 |
| FREED FROM HIS FIGHT | 2.7 | +0.0 | 0.0 | 18.3 | 12.0 | +0.0 | 0.0 | 93.3 |
| FRIEND CHARGES FIRST | - | - | - | - | 0.3 | -13.4 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 0.3 | -0.4 | 0.0 | 0.0 | - | - | - | - |
| FRIENDS SHOTS CHECKED | 0.3 | +25.2 | 0.0 | 0.0 | - | - | - | - |
| GIVES UP | 1.0 | -23.4 | 41.7 | 0.0 | 0.3 | -15.1 | 70.0 | 0.0 |
| GOAL WALK | 14.3 | +1643.9 | 0.0 | 130.0 | 5.7 | +252.1 | 0.0 | 0.0 |
| GUN FIGURES | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HARD STAY DROPPED | 3.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 1.7 | +0.0 | 0.0 | 18.3 | 7.7 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 9.3 | +0.0 | 0.0 | 280.0 | 16.0 | +0.0 | 0.0 | 113.3 |
| HIS CHARGE DENIED | - | - | - | - | 0.3 | +31.3 | 65.0 | 0.0 |
| HIS CHARGE LIST | 4.3 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 6.0 | +0.0 | 0.0 | 130.0 | 4.0 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 4.3 | -31.5 | 0.0 | 65.0 | 8.7 | -187.8 | 0.0 | 0.0 |
| HIS MOVE AS HE DECIDES | - | - | - | - | 50.3 | +18.7 | 267.0 | 0.0 |
| HIS MOVE WHY | 31.0 | +0.0 | 0.0 | 225.7 | - | - | - | - |
| HIS ONE MOVE | - | - | - | - | 27.0 | +261.5 | 0.0 | 0.0 |
| HIS ONE QUARTER | 6.3 | +0.0 | 0.0 | 18.3 | 2.7 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 8.7 | +0.0 | 0.0 | 260.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVE | 17.0 | +0.0 | 0.0 | 48.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVER COMES | 3.7 | +0.0 | 0.0 | 48.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 44.3 | +612.4 | 0.0 | 388.7 | 45.3 | +1458.0 | 0.0 | 268.7 |
| HIS SHOTS BY HIS RUN | 33.0 | +290.3 | 0.0 | 372.0 | 52.0 | +722.3 | 0.0 | 470.7 |
| HIS TURN DENIED | 0.3 | +2.0 | 46.7 | 0.0 | 0.7 | +11.0 | 40.0 | 0.0 |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 22.7 | +0.0 | 0.0 | 64.0 | 12.0 | +0.0 | 0.0 | 93.3 |
| HOLDER ASSIGNMENT | 15.0 | +1239.5 | 0.0 | 42.0 | 7.0 | +717.7 | 0.0 | 46.7 |
| HOLDS AMBUSHERS | 1.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 5.3 | -136.5 | 405.7 | 0.0 | 3.3 | -186.3 | 411.7 | 15.0 |
| IDLE COST | 2.0 | -38.9 | 0.0 | 65.0 | 16.7 | -153.6 | 0.0 | 41.7 |
| JOINT CHARGE NOW | 0.7 | -72.0 | 0.0 | 0.0 | 0.3 | -10.9 | 20.0 | 0.0 |
| KEPT FROM ITS LAST STOP | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| LANE BY FIGURES | 1.3 | +48.6 | 0.0 | 0.0 | 0.7 | +0.4 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 11.0 | +0.0 | 178.7 | 216.3 | 12.7 | +0.0 | 41.7 | 419.7 |
| LONE WIZARD KEPT IN | 1.3 | +77.2 | 0.0 | 0.0 | - | - | - | - |
| LONG SHOT | - | - | - | - | 1.3 | +0.2 | 38.3 | 35.0 |
| LOST AFTER ESCAPE | 1.3 | +12.9 | 41.7 | 0.0 | 1.3 | +3.6 | 92.3 | 57.0 |
| MANOEUVRE | 1.3 | +4.7 | 0.0 | 0.0 | 2.0 | -25.4 | 0.0 | 0.0 |
| MARCH AT ESCAPER | - | - | - | - | 1.0 | +1.1 | 0.0 | 0.0 |
| MARCH BY THE SUM | 0.3 | +0.2 | 0.0 | 0.0 | - | - | - | - |
| MARCH OF THE TABLE | 0.3 | +0.6 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| MARCH OVER CASTS | 0.7 | +18.9 | 0.0 | 0.0 | 0.3 | +172.3 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 0.7 | +10.1 | 0.0 | 0.0 | 1.3 | +19.1 | 0.0 | 0.0 |
| MEETS IN TIME | 4.3 | +147.4 | 0.0 | 48.3 | 4.3 | +410.5 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 1.0 | +46.4 | 0.0 | 74.0 | 3.0 | +22.9 | 0.0 | 52.7 |
| MISSILES NEXT TURN | 2.7 | +41.4 | 0.0 | 74.0 | 6.0 | +33.2 | 0.0 | 52.7 |
| MOVE ORDER | 3.3 | +0.0 | 65.0 | 0.0 | 3.7 | +0.0 | 0.0 | 0.0 |
| MOVE SPELL OUT OF RANGE | - | - | - | - | 0.3 | -12.5 | 0.0 | 91.3 |
| MOVE TO CHARGE COMPUTED | 8.0 | +1302.4 | 0.0 | 130.0 | 9.7 | +641.0 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 16.3 | +656.6 | 0.0 | 140.0 | 9.0 | +374.1 | 0.0 | 99.3 |
| NEXT CHARGE BY LIST | 5.7 | +958.2 | 0.0 | 130.0 | 6.0 | +328.3 | 65.0 | 0.0 |
| NO DOUBLE ROUNDS | 6.0 | -352.6 | 405.7 | 0.0 | 3.3 | -78.9 | 389.7 | 35.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 0.3 | -0.2 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 3.7 | -102.6 | 41.7 | 22.0 | 8.3 | -135.2 | 0.0 | 42.0 |
| ONE CHALLENGE TEST | - | - | - | - | 0.3 | -14.1 | 74.0 | 0.0 |
| ONE CHECK AFTER THE LAST CHANGE | 0.3 | +0.0 | 0.0 | 74.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 3.3 | -67.4 | 0.0 | 0.0 | 7.0 | -104.8 | 0.0 | 0.0 |
| ONE JOINT FIGURE | - | - | - | - | 0.3 | -3.9 | 0.0 | 0.0 |
| ONE OBJECTIVE FORMULA | 8.7 | +29.9 | 0.0 | 42.0 | 4.3 | -19.5 | 0.0 | 46.7 |
| OPENS UP | 0.3 | +30.0 | 0.0 | 0.0 | 0.3 | +13.5 | 22.0 | 0.0 |
| OVERRUNS AWAY | 1.3 | +14.6 | 136.0 | 0.0 | 1.0 | +45.4 | 131.7 | 15.0 |
| PATHS CROSS | 0.7 | +2.1 | 0.0 | 0.0 | 0.3 | +3.2 | 0.0 | 0.0 |
| PERIAPT WORTH | 0.3 | +19.4 | 0.0 | 0.0 | - | - | - | - |
| PLAN RESULT | 49.7 | +501.3 | 388.0 | 617.7 | 45.3 | +379.3 | 356.3 | 781.3 |
| PROMISE BELOW ZERO | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE BY ITS OWN SUM | 10.0 | -404.2 | 0.0 | 0.0 | 7.3 | -105.3 | 0.0 | 0.0 |
| PROMISE IN STEPS | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE KNOWS THE FIGHT | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | -0.9 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | - | - | - | - | 0.3 | -9.7 | 0.0 | 0.0 |
| PROMISE SHOT AWAY | 0.3 | -0.8 | 0.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | 24.0 | +2870.6 | 292.0 | 18.3 | 19.3 | +1806.8 | 74.0 | 62.0 |
| RANDOM MOVE BY FIGURES | 2.0 | +95.9 | 0.0 | 215.0 | 2.7 | +26.6 | 0.0 | 170.0 |
| REDIRECT COUNTER | 3.0 | +167.5 | 0.0 | 64.3 | 2.0 | +89.9 | 0.0 | 0.0 |
| REDIRECT FOR A FRIEND IN REACH | 6.3 | +0.0 | 0.0 | 64.3 | 2.3 | +0.0 | 0.0 | 15.0 |
| REDIRECT WEIGHED | 1.3 | +51.2 | 0.0 | 0.0 | - | - | - | - |
| REFORMS TO MEET IT | 3.0 | -91.2 | 0.0 | 0.0 | 3.3 | -20.6 | 0.0 | 0.0 |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| RESERVE FALL BACK | 1.3 | +24.5 | 0.0 | 24.0 | 0.3 | +101.9 | 0.0 | 0.0 |
| RISK BY ARC | 5.0 | +33.1 | 390.7 | 0.0 | 3.0 | -33.8 | 393.3 | 0.0 |
| ROUNDS AFTER TERROR | 2.7 | -69.1 | 188.7 | 0.0 | 1.0 | -41.7 | 148.0 | 0.0 |
| RUN DOWN | 4.3 | -188.5 | 272.0 | 0.0 | 1.3 | -19.5 | 140.7 | 15.0 |
| SCOUT SPOT | 1.3 | +1.1 | 0.0 | 22.0 | - | - | - | - |
| SCOUT WAITS | 1.3 | +0.0 | 0.0 | 22.0 | - | - | - | - |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 0.7 | -23.5 | 0.0 | 0.0 |
| SEARCH SPOT | 0.7 | +2.5 | 0.0 | 0.0 | 0.3 | +15.9 | 0.0 | 0.0 |
| SECOND LOOK | 0.7 | +23.5 | 41.7 | 0.0 | 0.7 | +8.6 | 0.0 | 42.0 |
| SET CREDITED ONCE | 0.3 | -8.0 | 0.0 | 21.7 | 2.3 | -72.8 | 0.0 | 0.0 |
| SET UP BY THE SET | 0.3 | +8.0 | 0.0 | 21.7 | 5.3 | +83.2 | 74.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.7 | +3.0 | 0.0 | 0.0 | 0.3 | +0.3 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 6.7 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 52.7 |
| SHOOTS FROM THE BEST SPOT | 3.3 | +128.1 | 208.0 | 148.0 | 0.3 | +0.8 | 0.0 | 0.0 |
| SHOT OR CHARGE | 1.3 | -6.8 | 0.0 | 0.0 | - | - | - | - |
| SHOT RISK POINTS | 24.7 | -210.4 | 0.0 | 282.0 | 29.0 | -194.2 | 0.0 | 170.0 |
| SHOTS AFTER THE MOVES | 3.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 23.0 | +341.9 | 0.0 | 140.0 | 5.7 | +67.6 | 0.0 | 99.3 |
| SPELL WORTH | 1.7 | +38.1 | 0.0 | 0.0 | 3.3 | +3.7 | 0.0 | 0.0 |
| SPELLS IN THE FIGHT | 0.3 | +16.6 | 62.0 | 0.0 | 0.3 | -69.8 | 0.0 | 20.0 |
| SPOT AS THE GAME MOVES | 6.0 | +0.0 | 0.0 | 140.0 | 11.3 | +0.0 | 0.0 | 185.0 |
| STAND AND SHOOT | 0.3 | -0.7 | 46.7 | 0.0 | 0.7 | -1.2 | 42.0 | 0.0 |
| STANDS FOR A REASON | - | - | - | - | 4.0 | +0.0 | 0.0 | 105.3 |
| STANDS STILL | 43.7 | +0.0 | 518.7 | 367.7 | 19.7 | +0.0 | 219.0 | 167.3 |
| STAY WORTH | 22.3 | +129.2 | 170.0 | 0.0 | 5.3 | +41.6 | 89.0 | 46.7 |
| STRIKE BY THE ODDS | 1.3 | +352.5 | 52.7 | 0.0 | 0.7 | -43.8 | 18.3 | 35.0 |
| STUBBORN BY POINTS | - | - | - | - | 0.3 | +1.9 | 0.0 | 0.0 |
| STUCK PIVOT | - | - | - | - | 0.7 | +0.0 | 0.0 | 56.7 |
| STUPIDITY NEXT TURN | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 6.3 | +344.4 | 0.0 | 0.0 | 2.7 | +573.8 | 0.0 | 0.0 |
| SUPPORT NARROWED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SUPPORT WORKED OUT | 6.3 | +344.4 | 0.0 | 0.0 | 2.7 | +573.8 | 0.0 | 0.0 |
| SURE REACH TOGETHER | - | - | - | - | 0.3 | +1.8 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 1.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| THE PROMISE ADDS | - | - | - | - | 0.7 | -13.8 | 65.0 | 0.0 |
| THE PROMISED MOVE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE ROW IN ITS ORDER | 2.3 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 2.3 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 41.7 |
| THE STEP BACK IS MADE | 2.0 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 41.7 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 48.7 | +0.0 | 0.0 | 236.0 | 42.0 | +0.0 | 0.0 | 203.0 |
| TIED UP BY THE SUM | 2.7 | +381.4 | 223.3 | 0.0 | 1.0 | +118.4 | 135.3 | 0.0 |
| TIME ON OUR SIDE | 53.0 | +452.4 | 226.7 | 307.7 | 6.0 | +41.7 | 130.0 | 0.0 |
| WAITS AGAIN | 2.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| WHO FIGHTS | 1.0 | +110.5 | 62.0 | 0.0 | 0.3 | -4.4 | 20.0 | 0.0 |
| WHO HITS BACK | 1.3 | +103.3 | 0.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT DANGER | 3.3 | -220.8 | 0.0 | 20.0 | 2.7 | -752.2 | 0.0 | 56.7 |
| WOUNDED STAYS OUT | 0.3 | +0.0 | 36.7 | 0.0 | - | - | - | - |
| WOUNDS ON THE RANKS | - | - | - | - | 6.3 | +101.5 | 0.0 | 0.0 |

### Rule changes: cnomg-c940641-p35

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 150 | 150 | 118 | 39.33 | +1679 | +14.2 |
| HIS MOVE AS HE DECIDES | 151 | 151 | 95 | 31.67 | +0 | +0.0 |
| LEGAL CHARGES ONLY | 71 | 71 | 71 | 23.67 | +0 | +0.0 |
| HIS SHOT LIST | 269 | 258 | 70 | 23.33 | +907 | +13.0 |
| HIS MOVE WHY | 93 | 93 | 65 | 21.67 | +0 | +0.0 |
| HOLDER ASSIGNMENT | 66 | 66 | 60 | 20.00 | +4489 | +74.8 |
| HIS SHOTS BY HIS RUN | 255 | 243 | 44 | 14.67 | +297 | +6.8 |
| OFF BEST | 36 | 36 | 36 | 12.00 | -713 | -19.8 |
| THE TABLE AGAIN | 36 | 36 | 32 | 10.67 | +0 | +0.0 |
| DEPLOY BY FIGURES | 47 | 47 | 26 | 8.67 | +299 | +11.5 |
| REDIRECT FOR A FRIEND IN REACH | 26 | 26 | 26 | 8.67 | +0 | +0.0 |
| MOVE TO CHARGE COMPUTED | 53 | 47 | 25 | 8.33 | +2170 | +86.8 |
| FIVE ACTION | 568 | 545 | 21 | 7.00 | +1297 | +61.8 |
| MOVE ORDER | 21 | 21 | 21 | 7.00 | +0 | +0.0 |
| NEXT CHARGE BY LIST | 35 | 34 | 19 | 6.33 | +2037 | +107.2 |
| HIS ONE MOVE | 81 | 79 | 18 | 6.00 | +0 | +0.0 |
| PROMISE BY ITS OWN SUM | 52 | 52 | 17 | 5.67 | -1528 | -89.9 |
| FOUR ROUNDS | 30 | 26 | 15 | 5.00 | +708 | +47.2 |
| GOAL WALK | 60 | 60 | 13 | 4.33 | +1212 | +93.2 |
| HARD STAY DROPPED | 13 | 13 | 13 | 4.33 | +0 | +0.0 |
| MEETS IN TIME | 26 | 26 | 13 | 4.33 | +1082 | +83.3 |
| TIME ON OUR SIDE | 177 | 150 | 13 | 4.33 | +58 | +4.4 |
| CHARGE LOSSES | 103 | 96 | 10 | 3.33 | +939 | +93.9 |
| SHOT RISK POINTS | 161 | 153 | 10 | 3.33 | +64 | +6.4 |
| SUPPORT ADDS | 27 | 27 | 10 | 3.33 | +879 | +87.9 |
| SUPPORT WORKED OUT | 27 | 27 | 10 | 3.33 | +879 | +87.9 |
| ADVANCE LANE KEPT | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| QUARTER ODDS | 130 | 122 | 9 | 3.00 | +410 | +45.5 |
| TIED UP BY THE SUM | 11 | 9 | 9 | 3.00 | +410 | +45.6 |
| HOLDS AMBUSHERS | 8 | 8 | 8 | 2.67 | +0 | +0.0 |
| SHOOTS FROM THE BEST SPOT | 11 | 11 | 8 | 2.67 | +10 | +1.2 |
| RANDOM MOVE BY FIGURES | 14 | 14 | 7 | 2.33 | +367 | +52.5 |
| STAY WORTH | 83 | 79 | 7 | 2.33 | +149 | +21.3 |
| LANE BY FIGURES | 6 | 6 | 6 | 2.00 | +147 | +24.5 |
| SET UP BY THE SET | 17 | 17 | 6 | 2.00 | +40 | +6.7 |
| WHOLE FIGHT DANGER | 18 | 17 | 6 | 2.00 | +696 | +115.9 |
| CHARGE NOW FIRST | 16 | 16 | 5 | 1.67 | -209 | -41.7 |
| COMBAT PIVOT | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| RESERVE FALL BACK | 5 | 5 | 5 | 1.67 | +379 | +75.8 |
| FOLLOW UP WEIGHED | 4 | 4 | 4 | 1.33 | +808 | +201.9 |
| LONE WIZARD KEPT IN | 4 | 4 | 4 | 1.33 | +232 | +57.9 |
| REDIRECT WEIGHED | 4 | 4 | 4 | 1.33 | +154 | +38.4 |
| RISK BY ARC | 24 | 21 | 4 | 1.33 | +118 | +29.6 |
| SCOUT WAITS | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| SECOND LOOK | 4 | 4 | 4 | 1.33 | +96 | +24.1 |
| STRIKE BY THE ODDS | 6 | 6 | 4 | 1.33 | +376 | +93.9 |
| WHO HITS BACK | 4 | 4 | 4 | 1.33 | +132 | +32.9 |
| ASSAILMENT BY POINTS | 3 | 3 | 3 | 1.00 | +13 | +4.5 |
| EXACT ROUND | 19 | 17 | 3 | 1.00 | +317 | +105.5 |
| JOINT CHARGE NOW | 3 | 3 | 3 | 1.00 | -249 | -82.9 |
| PATHS CROSS | 3 | 3 | 3 | 1.00 | +16 | +5.4 |
| SEARCH SPOT | 3 | 3 | 3 | 1.00 | +55 | +18.3 |
| SHOOTERS IN TWO RANKS | 3 | 3 | 3 | 1.00 | +10 | +3.3 |
| CAST JOB | 6 | 6 | 2 | 0.67 | +3 | +1.3 |
| CASTS FROM BEHIND | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| CHAFF IN THE MOVE | 2 | 2 | 2 | 0.67 | +6 | +2.8 |
| CHALLENGE BY POINTS | 2 | 2 | 2 | 0.67 | +94 | +47.2 |
| COVER ONCE | 55 | 31 | 2 | 0.67 | +0 | +0.0 |
| FIGHT TO THE END | 3 | 3 | 2 | 0.67 | +23 | +11.5 |
| IDLE COST | 56 | 31 | 2 | 0.67 | +12 | +6.2 |
| MANOEUVRE | 10 | 10 | 2 | 0.67 | +34 | +16.8 |
| MARCH OF THE TABLE | 2 | 2 | 2 | 0.67 | -2 | -0.8 |
| NO DOUBLE ROUNDS | 28 | 25 | 2 | 0.67 | +81 | +40.7 |
| OPENS UP | 2 | 2 | 2 | 0.67 | +61 | +30.6 |
| OVERRUNS AWAY | 7 | 7 | 2 | 0.67 | +43 | +21.3 |
| REDIRECT COUNTER | 15 | 12 | 2 | 0.67 | +21 | +10.5 |
| STUCK PIVOT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| WOUNDS ON THE RANKS | 19 | 18 | 2 | 0.67 | +11 | +5.7 |
| AFTERMATH IN POINTS | 1 | 1 | 1 | 0.33 | +29 | +28.6 |
| CASTER AWAY FROM SCREEN | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CHAFF PASSED | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CHARGE NOT DECLARED | 1 | 1 | 1 | 0.33 | -135 | -134.7 |
| EVASIVE BY THE ODDS | 7 | 7 | 1 | 0.33 | +446 | +446.5 |
| FALL BACK GOOD ORDER | 24 | 21 | 1 | 0.33 | +1 | +0.8 |
| FALLS SHORT | 70 | 57 | 1 | 0.33 | +24 | +24.3 |
| FEATURE BUFFS | 8 | 8 | 1 | 0.33 | +69 | +69.4 |
| FRIENDS SHOTS CHECKED | 1 | 1 | 1 | 0.33 | +76 | +75.7 |
| HIS MOVE AND SHOT | 39 | 37 | 1 | 0.33 | +4 | +3.5 |
| HIS TURN DENIED | 3 | 3 | 1 | 0.33 | +17 | +17.4 |
| MARCH BY THE SUM | 1 | 1 | 1 | 0.33 | +0 | +0.5 |
| MAX FOR POSITIONING | 6 | 5 | 1 | 0.33 | +0 | +0.5 |
| NEARER NOT NEEDED | 76 | 72 | 1 | 0.33 | +55 | +55.1 |
| ONE OBJECTIVE FORMULA | 39 | 26 | 1 | 0.33 | +40 | +39.7 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.33 | +58 | +58.3 |
| PROMISE KNOWS THE FIGHT | 4 | 4 | 1 | 0.33 | -3 | -2.7 |
| PROMISE SHOT AWAY | 1 | 1 | 1 | 0.33 | -2 | -2.4 |
| REFUSING RETIRES | 1 | 1 | 1 | 0.33 | -10 | -9.7 |
| SHOTS AFTER THE MOVES | 13 | 13 | 1 | 0.33 | +0 | +0.0 |
| SPELLS IN THE FIGHT | 2 | 2 | 1 | 0.33 | +25 | +25.4 |
| STUBBORN BY POINTS | 1 | 1 | 1 | 0.33 | +6 | +5.7 |
| SUPPORT NARROWED | 1 | 1 | 1 | 0.33 | -25 | -25.1 |
| SURE REACH TOGETHER | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| BACKUP TARGETS | 1 | 1 | 0 | 0.00 | - | - |
| BLOWS WHERE AIMED | 1 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 1 | trace | - | - | - | - |
| CHARACTER GUNS | 6 | 6 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 73 | 71 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 3 | not checked | - | - | - | - |
| DUEL STOPS AT THE KILL | 1 | 1 | 0 | 0.00 | - | - |
| EDGE GIVE GROUND | 2 | 2 | 0 | 0.00 | - | - |
| FALLBACK BY WORTH | 1 | 1 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 59 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 44 | 43 | 0 | 0.00 | - | - |
| FRIEND CHARGES FIRST | 1 | 1 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 1 | 1 | 0 | 0.00 | - | - |
| GIVES UP | 4 | 2 | 0 | 0.00 | - | - |
| GUN FIGURES | 2 | not checked | - | - | - | - |
| HE REFORMS ONCE FREED | 28 | 28 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 76 | 71 | 0 | 0.00 | - | - |
| HIS CHARGE DENIED | 1 | 1 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 31 | 30 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 30 | 29 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 27 | 27 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 36 | 32 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 69 | 68 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 15 | 15 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN RUN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 104 | 104 | 0 | 0.00 | - | - |
| HONEST WORTH | 26 | 23 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 2 | 2 | 0 | 0.00 | - | - |
| LONG SHOT | 4 | 3 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 8 | 5 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 3 | trace | - | - | - | - |
| MARCH OVER CASTS | 3 | 3 | 0 | 0.00 | - | - |
| MISSILES IN THE MOVE | 12 | 8 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 26 | 15 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 1 | trace | - | - | - | - |
| NO OLD ONE-MOVE GUESS | 18 | 18 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT TURNED | 1 | 1 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 1 | not checked | - | - | - | - |
| ONE CHALLENGE TEST | 1 | 1 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 3 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 31 | 13 | 0 | 0.00 | - | - |
| ONE JOINT FIGURE | 1 | not checked | - | - | - | - |
| PLAN RESULT | 285 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 2 | 2 | 0 | 0.00 | - | - |
| PROMISE IN STEPS | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE READS THE TABLE | 1 | 1 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 19 | 16 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 11 | 10 | 0 | 0.00 | - | - |
| RUN DOWN | 17 | 14 | 0 | 0.00 | - | - |
| SCOUT SPOT | 4 | 4 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 2 | 2 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 8 | 8 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 30 | not checked | - | - | - | - |
| SHOT OR CHARGE | 4 | 4 | 0 | 0.00 | - | - |
| SHOTS IN THE MOVE | 86 | 71 | 0 | 0.00 | - | - |
| SPELL WORTH | 15 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 52 | 45 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 3 | 3 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 12 | 11 | 0 | 0.00 | - | - |
| STANDS STILL | 190 | 185 | 0 | 0.00 | - | - |
| STUPIDITY NEXT TURN | 4 | 4 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 7 | not checked | - | - | - | - |
| THE PROMISE ADDS | 2 | 2 | 0 | 0.00 | - | - |
| THE PROMISED MOVE | 1 | not checked | - | - | - | - |
| THE ROW IN ITS ORDER | 20 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 19 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 16 | not checked | - | - | - | - |
| THE TABLE BINDS | 272 | not checked | - | - | - | - |
| WAITS AGAIN | 9 | 9 | 0 | 0.00 | - | - |
| WHO FIGHTS | 4 | 4 | 0 | 0.00 | - | - |
| WOUNDED STAYS OUT | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: cnomg-c940641-p35

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 3.00 | 6.33 | 20.6 |
| ARMY TABLE | rule | 3.00 | 3.67 | 104.8 |
| PROMISE BY ITS OWN SUM | rule | 3.67 | 2.00 | 89.9 |
| RULE SWITCHED OFF | gate | - | 2.00 | 17.1 |
| CHARGE NOW FIRST | rule | 1.33 | 0.33 | 41.7 |
| JOINT CHARGE NOW | rule | 0.33 | 0.33 | 145.8 |
| NO REASON | gate | 0.67 | - | 17.6 |
| SET UP BY THE SET | rule | - | 0.67 | 20.2 |
| CHARGE NOT DECLARED | rule | - | 0.33 | 134.7 |
| HOLDER ASSIGNMENT | rule | - | 0.33 | 28.8 |
| MARCH OF THE TABLE | rule | 0.33 | - | 1.6 |
| PROMISE KNOWS THE FIGHT | rule | - | 0.33 | 2.7 |
| PROMISE SHOT AWAY | rule | 0.33 | - | 2.4 |
| REFUSING RETIRES | rule | 0.33 | - | 9.7 |
| SUPPORT NARROWED | rule | 0.33 | - | 25.1 |

### Plans: cnomg-c940641-p35

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 5.0 | 73% | 1228 | 372 | 30% |
| Mine | move | 39.3 | 94% | 2560 | 0 | 0% |
| Mine | shoot | 5.3 | 44% | 512 | 130 | 25% |
| Opponent | charge | 3.7 | 73% | 373 | 347 | 93% |
| Opponent | join | 5.3 | 94% | 226 | 0 | 0% |
| Opponent | move | 33.7 | 94% | 1225 | 0 | 0% |
| Opponent | shoot | 2.3 | 29% | 56 | 32 | 58% |
| Opponent | support | 0.3 | 100% | 1 | 0 | 0% |

### Battle groups: cnomg-c940641-p35

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 3.0 | 22% | 50% | 50% | 0% | 0% | 100% | 0% | 0% | 0% |
| Opponent | REDIRECT COUNTER | 2.0 | 17% | 100% | 0% | - | 0% | 0% | 100% | 0% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: cnomg-c940641-p35

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | - | - | - | - |
| Mine | Chaff | 6 | 52 (6) | 0 | 52 | 48 | 0% | 1.5 | - | 60 (5) | 0 (1) | 60 (5) | 0 (1) |
| Mine | Character | 7 | 46 (7) | 46 | 0 | 15 | 0% | 3.1 | 40 (2) | 114 (1) | 30 (2) | 35 (4) | 114 (1) |
| Mine | Clean-up | 1 | 805 (1) | 0 | 805 | 0 | 0% | 5.0 | - | 805 (1) | - | - | 805 (1) |
| Mine | Fast Hammer | 6 | 61 (6) | 61 | 0 | 21 | 50% | 4.3 | 85 (4) | 0 (2) | - | - | 61 (6) |
| Mine | Hammer | 5 | 36 (5) | 16 | 20 | 80 | 0% | 2.0 | 29 (3) | 44 (2) | - | 50 (2) | 29 (3) |
| Mine | Holder | 8 | 120 (8) | 19 | 101 | 0 | 12% | 2.4 | 245 (2) | 78 (5) | 94 (1) | 245 (2) | 82 (6) |
| Mine | Shooter | 5 | 79 (5) | 0 | 79 | 30 | 20% | 1.2 | 0 (2) | 178 (3) | - | 93 (4) | 0 (1) |
| Mine | Wizard | 3 | 0 (3) | 0 | 0 | 0 | 0% | 1.0 | 0 (2) | 0 (1) | - | 0 (2) | 0 (1) |
| Opponent | Chaff | 4 | 48 (4) | 23 | 25 | 75 | 25% | 4.3 | 64 (3) | - | 0 (1) | 64 (3) | 0 (1) |
| Opponent | Character | 11 | 35 (11) | 35 | 0 | 11 | 27% | 4.5 | 86 (2) | 18 (8) | - | 18 (6) | 81 (4) |
| Opponent | Fast Hammer | 6 | 36 (6) | 34 | 2 | 38 | 17% | 3.0 | - | 41 (5) | 0 (1) | 12 (3) | 51 (3) |
| Opponent | Hammer | 8 | 7 (8) | 7 | 0 | 45 | 25% | 4.2 | 0 (3) | 11 (5) | - | 9 (6) | 0 (2) |
| Opponent | Holder | 3 | 0 (3) | 0 | 0 | 0 | 67% | 4.0 | 0 (1) | 0 (2) | - | 0 (1) | 0 (2) |
| Opponent | Shooter | 3 | 74 (3) | 0 | 74 | 69 | 0% | 1.7 | - | 106 (2) | 0 (1) | 72 (2) | 79 (1) |
| Opponent | Support | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Wizard | 2 | 0 (2) | 0 | 0 | 76 | 0% | 1.0 | 0 (1) | - | 0 (1) | 0 (1) | 0 (1) |

### Charged fights: cnomg-c940641-p35

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Skaven | 1 | 0 | 120 | 3.0 | 1.0 | 40 | 18 | +22 | 0 of 3 | 3 of 3 | - | +22 |
| Mine | Tomb Kings of Khemri | 2 | 0 | 418 | 4.0 | 1.0 | 105 | 0 | +105 | 2 of 8 | 7 of 8 | - | +105 |
| **Mine** | all armies | 3 | 0 | 319 | 3.7 | 1.0 | 87 | 5 | +82 | 2 of 11 | 10 of 11 | - | +82 |
| Opponent | Vampire Counts | 1 | 210 | 927 | 6.0 | 1.0 | 154 | 73 | +82 | 3 of 6 | 1 of 6 | - | +82 |
| Opponent | Warriors of Chaos | 1 | 0 | 0 | 1.0 | 1.0 | 0 | 170 | -170 | 1 of 1 | 0 of 1 | - | -170 |
| Opponent | Wood Elf Realms | 1 | 0 | 321 | 4.0 | 1.0 | 80 | 32 | +49 | 1 of 4 | 3 of 4 | - | +49 |
| **Opponent** | all armies | 3 | 70 | 416 | 3.7 | 1.0 | 113 | 67 | +47 | 5 of 11 | 4 of 11 | - | +47 |

### Effective charges: cnomg-c940641-p35

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Skaven | 3 | 1 (net +0) | 0 | 0 | 0 | 0 | 2 (net +32) | 0 | 0% (0 of 3) |
| Mine | Tomb Kings of Khemri | 8 | 0 | 0 | 1 (net +0) | 1 (net +0) | 2 (net +118) | 2 (net +301) | 2 | 17% (1 of 6) |
| Opponent | Vampire Counts | 6 | 2 (net +0) | 1 (net -436) | 0 | 0 | 0 | 1 (net +355) | 2 | 0% (0 of 4) |
| Opponent | Wood Elf Realms | 4 | 0 | 0 | 0 | 1 (net +60) | 1 (net +66) | 1 (net +195) | 1 | 0% (0 of 3) |

### Charged fights, damage counted: cnomg-c940641-p35

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 1 | 440 | 186 | +0 | 0 | 0 | +0 | +0.0 |
| Mine | Effective (55-75%) | 1 | 70 | 102 | +0 | 0 | 0 | +0 | +0.0 |
| Mine | 76-89% | 1 | 431 | 201 | +0 | 78 | 144 | -65 | -15.1 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 4 | 212 | 112 | +167 | 196 | 36 | +160 | +75.1 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 2 | 436 | 118 | +118 | 118 | 35 | +82 | +18.8 |
| Mine | No odds | 2 | 436 | 125 | +0 | 0 | 0 | +0 | +0.0 |
| Mine | All fights | 11 | 321 | 129 | +82 | 100 | 33 | +67 | +20.9 |
| Opponent | Long shot (under 50%) | 2 | 116 | 132 | +0 | 0 | 0 | +0 | +0.0 |
| Opponent | 50-54% | 1 | 60 | 440 | -436 | 55 | 436 | -381 | -635.0 |
| Opponent | 76-89% | 1 | 126 | 60 | +60 | 60 | 0 | +60 | +47.6 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 342 | 170 | +275 | 275 | 0 | +275 | +80.3 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 499 | 66 | +66 | 66 | 0 | +66 | +13.2 |
| Opponent | No odds | 4 | 192 | 186 | +69 | 154 | 111 | +43 | +22.2 |
| Opponent | All fights | 11 | 215 | 174 | +47 | 122 | 80 | +42 | +19.7 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| cnomg-c940641-p35 | move | 21 | 8 (38%) | 6 (29%) | 1 (5%) | 12 (57%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L2127 |
| Invocation of Nehek | Opponent | L2127 |
| Periapt of Soul Exchange | Mine | L2127 |
| Ring of Doom | Opponent | L2231 |
| Storm Daemon (Renegade 2.0) | Mine | L2127 |

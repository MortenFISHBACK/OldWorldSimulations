# Doctrine scorecard: cnomg-c940641-p9

### Scorecard: cnomg-c940641-p9

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L1527 | 3 | 1 | Mine | no | 8 | 2 | 3 | 1 | 1 | 0 | 0 | 0 |
| L1527 | 3 | 1 | Opponent | no | 4 | 3 | 4 | 3 | 2 | 0 | 0 | 0 |
| L1625 | 5 | 1 | Mine | yes | - | 3 | 1 | 2 | 0 | 0 | 0 | 200 |
| L1625 | 5 | 1 | Opponent | yes | - | 4 | 3 | 2 | 0 | 0 | 0 | 0 |
| L1723 | 1 | 1 | Mine | no | 4 | 2 | 5 | 0 | 1 | 0 | 0 | 98 |
| L1723 | 1 | 1 | Opponent | yes | 8 | 3 | 4 | 1 | 2 | 0 | 0 | 0 |
| **Average** | | | Mine | 33% | 6.0 | 2.3 | 3.0 | 1.0 | 0.7 | 0.0 | 0.0 | 99.3 |
| **Average** | | | Opponent | 67% | 6.0 | 3.3 | 3.7 | 2.0 | 1.3 | 0.0 | 0.0 | 0.0 |

### KPIs: cnomg-c940641-p9

Rules off - Mine only: NO OLD ONE-MOVE GUESS.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 17) | 0% (0 of 15) | 0% (0 of 32) |
| Winner chose to follow up after the loser gave ground |  | 70% (7 of 10); on the table 80% | 50% (3 of 6); on the table 67% | 62% (10 of 16); on the table 75% |
| Winner chose to pursue after the loser fell back in good order |  | - | 60% (3 of 5); on the table 60% | 60% (3 of 5); on the table 60% |
| Winner chose to pursue after the loser fled |  | - | 100% (3 of 3); on the table 100% | 100% (3 of 3); on the table 100% |
| Winner chose to follow up or pursue (all three) |  | 70% (7 of 10); on the table 80% | 64% (9 of 14); on the table 71% | 67% (16 of 24); on the table 75% |
| Magic missiles tried each own turn | 50%+ | - | 44% (8 of 18) | 44% (8 of 18) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | - | 57% (8 of 14) | 57% (8 of 14) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | - | - |
| Points that never fought | lower | 31% (1889 of 6000) | 16% (959 of 5999) | 24% (2848 of 11999) |
|   infantry points that never fought | lower | 64% (857 of 1332) | 53% (442 of 834) | 60% (1299 of 2166) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 50% (10 of 20) | 47% (8 of 17) | 49% (18 of 37) |
| Bound items with a magic missile used (at least once a game) |  | 100% (2 of 2); 1.7 uses a game | 0.0 uses a game | 100% (2 of 2); 0.8 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 100% (1 of 1); 0.3 uses a game | 0.0 uses a game | 100% (1 of 1); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 49% (2493 of 5135) | 34% (1568 of 4600) | 42% (4061 of 9735) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | - | 2.0 (60%) | 2.0 (60%) |
| IN COMBAT: engaged in combat | - | 0.3 (10%) | 0.3 (10%) |
| GONE: slain | - | 1.0 (30%) | 1.0 (30%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 3.3 | 2.7 | 1.0 | 2.7 | 0.3 | 1.7 |
| not cast | 6.7 | 1.3 | 1.0 | 3.3 | 1.7 | 26.3 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (3%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.3 (25%) | 0.0 (0%) | 2.0 (60%) | 1.3 (80%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (10%) | 0.3 (20%) | 0.0 (0%) |
| GONE: slain | 1.7 (25%) | 0.0 (0%) | 0.0 (0%) | 1.0 (30%) | 0.0 (0%) | 4.0 (15%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.3 (25%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (3%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.7 (10%) | 0.7 (50%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 4.3 (65%) | 0.0 (0%) | 1.0 (100%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 21.0 (80%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.0 a game | 0.0 a game | 0.5 a game |
| stood (cast and not dispelled) | - | - | - |
| the unit moved after it | - | - | - |
| it charged on its next turn | - | - | - |
| the enemy charged it first | - | - | - |
| it fought by the end of its next turn | - | - | - |
| it moved out of a charge the enemy had planned (not charged first) | - | - | - |
| none of these (no charge, no fight, no charge escaped) | - | - | - |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 61% (53 of 87) | 68% (27 of 40) | 63% (80 of 127) |
|   cavalry | 77% (10 of 13) | 100% (8 of 8) | 86% (18 of 21) |
|   character | 9% (1 of 11) | 0% (0 of 9) | 5% (1 of 20) |
|   chariot | 50% (3 of 6) | - | 50% (3 of 6) |
|   infantry | 66% (25 of 38) | 83% (19 of 23) | 72% (44 of 61) |
|   monster | 58% (7 of 12) | - | 58% (7 of 12) |
|   war machine | 100% (7 of 7) | - | 100% (7 of 7) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.7 (24%) | 0.0 (0%) | 2.7 (17%) |
| CHARGED: it charged | 1.7 (15%) | 1.0 (23%) | 2.7 (17%) |
| IN COMBAT: it fought this turn or the last | 2.0 (18%) | 0.3 (8%) | 2.3 (15%) |
| NO TARGET IN RANGE | 4.0 (35%) | 1.7 (38%) | 5.7 (36%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.0 (9%) | 1.3 (31%) | 2.3 (15%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 6.0 | 2.3 | 83% | 3.3 pts | 20 pts |
| character | 0.3 | 0.0 | 100% | 0.0 pts | 0 pts |
| chariot | 1.0 | 0.0 | 100% | 0.0 pts | 0 pts |
| infantry | 21.7 | 6.3 | 80% | 8.7 pts | 188 pts |
| monster | 2.3 | 0.3 | 86% | 4.6 pts | 11 pts |
| war machine | 2.3 | 1.0 | 57% | 13.6 pts | 32 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 5.7 | 4.7 | 5.2 |
| Charges that made contact a game | 5.3 | 4.3 | 4.8 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | - | 0.33 declared, 0.33 contact (3 units) | 0.33 declared, 0.33 contact (3 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.33 declared, 0.33 contact (3 units) | 1.00 declared, 1.00 contact (2 units) | 0.60 declared, 0.60 contact (5 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.76 declared, 0.71 contact (21 units) | 0.44 declared, 0.40 contact (25 units) | 0.59 declared, 0.54 contact (46 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 33% (1 of 3) | 50% (1 of 2) | 50% (1 of 2) | 43% (3 of 7) |
| Character in a unit | 100% (2 of 2) | 100% (1 of 1) | - | 100% (3 of 3) |
| Character on its own | 100% (2 of 2) | 0% (0 of 2) | 22% (2 of 9) | 31% (4 of 13) |
| Chariot | 0% (0 of 1) | - | - | 0% (0 of 1) |
| Infantry | 67% (4 of 6) | 50% (1 of 2) | - | 62% (5 of 8) |
| Monster | 60% (3 of 5) | - | - | 60% (3 of 5) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| High Elf Realms | 1 | 67% (2 of 3); on the table 67% | - | 30% | 43% (3 of 7) | 100% (2 of 2); 5.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | 100% (2 of 2); on the table 100% | - | 34% | 50% (3 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Lizardmen | 1 | 60% (3 of 5); on the table 80% | - | 30% | 57% (4 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Tomb Kings of Khemri | 1 | 33% (1 of 3); on the table 33% | - | 16% | 20% (1 of 5) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 2 | 73% (8 of 11); on the table 82% | 44% (8 of 18) | 16% | 58% (7 of 12) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (cnomg-c940641-p9, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 43% (3) | 55% (6) | 50% (9) |
| ...free all their last turn and able to turn (per game) | 0.00 | 2.00 | 2.00 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.67 | 0.00 | 0.67 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 2.00 | 2.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: cnomg-c940641-p9

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.3 | 3.3 |
| Strategy | Charge objectives carried out (made contact) | 50% (7 of 14) | 67% (8 of 12) |
| Strategy | Shoot objectives carried out (shot that target) | 38% (5 of 13) | 0% (0 of 14) |
| Strategy | Support requests answered (helper made contact too) | 50% (1 of 2) | - |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | - | 100% (3 of 3) |
| Strategy | Hexes on a unit its side charged or shot that turn | - | 0% (0 of 1) |
| Strategy | Joined characters whose unit fought | 0% (0 of 1) | 60% (3 of 5) |
| Strategy | Lone characters that fought | 100% (8 of 8) | 89% (8 of 9) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 1.0 | 2.0 |
| Movement | Points that never moved of their own | 99.3 | 0.0 |
| Movement | Fights charged into per game | 5.0 | 4.0 |
| Movement | Charges with odds: long shots (under 50%) | 1 of 12, net +0 | 1 of 11, net +0 |
| Movement | Charges with odds: sweet spot (55-75%) | 3 of 12, net +15 | 1 of 11, net -154 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 4 of 12, net +65 | 1 of 11, net +0 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 of 12, net +191 | 3 of 11, net +146 |
| Shooting | Shots by shooting units (incl. breath weapons) | 16.3 | 10.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 67% (33 of 49) | 20% (6 of 30) |
| Shooting | Points destroyed by shooting units | 22.0 | 58.3 |
| Shooting | War machine shots | 2.3 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 57% (4 of 7) | - |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | - | 2.0 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | - | 67% (4 of 6) |
| Magic | Wounds caused by magic missiles | 1.3 | 0.3 |
| Magic | Wounds caused by other spells | - | 1.0 |
| Magic | Points destroyed by magic (all spells) | 0.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.3 / 1.0 / 0.7 / 0.0 | 2.3 / 0.3 / 0.7 / 0.0 |
| Combat | Points destroyed in combat | 652.3 | 454.3 |
| Combat | Points run down | 0.0 | 130.0 |
| Combat | Net points per charged fight, damage counted | +46 | +60 |
| Combat | Net per 100 charger points, damage counted | +13.0 | +19.2 |
| Combat | First round won (charged fights) | 67% | 83% |
| Combat | Net points per charged fight | +59 | +52 |
| Combat | Net points per supported fight / lone fight | +75 / +58 | +39 / +53 |
| Combat | Charged fights on a top-3 enemy unit | 4 of 15 | 2 of 12 |
| Game | Points lost | 609.3 | 684.3 |
| Game | VP from objectives | 556.7 | 573.3 |
| Game | Lone holders (player turns) | 6.0 | 6.0 |

- Mine won / drew / lost: 0 / 3 / 0 of 3 ended games (of 3); mean margin (Mine - Opponent) +75 VP
- Points traded per game (both sides' losses): 1294
- Games not ended: 0; findings 1, warnings 0

### Opponent rules: cnomg-c940641-p9

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| AFTERMATH IN POINTS | 0.7 | +64.3 | 0.0 | 123.3 | 1.0 | +195.1 | 0.0 | 0.0 |
| ARMY TABLE | 18.0 | +373.7 | 0.0 | 0.0 | 20.7 | +334.2 | 0.0 | 360.7 |
| ASSAILMENT BY POINTS | - | - | - | - | 0.3 | +0.2 | 0.0 | 0.0 |
| BACKUP TARGETS | 0.3 | +1.2 | 0.0 | 0.0 | 0.7 | +2.7 | 0.0 | 0.0 |
| BEST PRIZE | - | - | - | - | 0.3 | +10.8 | 135.0 | 0.0 |
| BLOWS WHERE AIMED | 0.3 | -7.6 | 20.0 | 0.0 | - | - | - | - |
| CANNON PLANNED TARGET | 1.3 | +8.8 | 0.0 | 33.3 | - | - | - | - |
| CAST JOB | 0.7 | +4.3 | 0.0 | 132.7 | 0.7 | +7.2 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CASTS FROM BEHIND | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | - | - | - | - | 1.0 | +61.9 | 0.0 | 0.0 |
| CHAFF PASSED | 1.7 | -0.1 | 0.0 | 0.0 | - | - | - | - |
| CHALLENGE BY POINTS | 0.3 | +1.0 | 0.0 | 0.0 | 0.7 | +4.4 | 0.0 | 180.0 |
| CHARGE LOSSES | 14.3 | -616.8 | 0.0 | 89.0 | 18.0 | -575.1 | 0.0 | 454.7 |
| CHARGE NOT DECLARED | 0.3 | +0.0 | 78.3 | 0.0 | - | - | - | - |
| CHARGE NOW FIRST | 3.3 | +0.0 | 262.0 | 271.7 | 3.3 | +0.0 | 473.0 | 214.7 |
| CLOSES ON WHAT IT BEATS | 10.3 | +0.0 | 0.0 | 0.0 | 18.3 | +0.0 | 0.0 | 94.0 |
| COMBAT PIVOT | 0.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 40.0 | 180.0 |
| COVER ONCE | 9.0 | -324.6 | 0.0 | 91.7 | 10.3 | -985.7 | 0.0 | 245.7 |
| DENIED BY THE FIGHT | - | - | - | - | 0.7 | -5.1 | 123.3 | 65.0 |
| DEPLOY BY FIGURES | 7.3 | +4.0 | 0.0 | 0.0 | 7.7 | +7.5 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | 0.3 | -34.9 | 0.0 | 0.0 | 1.0 | -90.9 | 128.0 | 0.0 |
| EDGE GIVE GROUND | 0.3 | +63.9 | 20.0 | 0.0 | - | - | - | - |
| EXACT ROUND | 4.0 | +25.4 | 457.3 | 155.0 | 3.0 | +11.4 | 323.3 | 164.7 |
| FALL BACK GOOD ORDER | 3.3 | +0.0 | 326.0 | 155.0 | 4.0 | +2.3 | 529.3 | 229.7 |
| FALLS SHORT | 2.0 | +15.5 | 0.0 | 0.0 | 19.0 | +215.7 | 0.0 | 89.0 |
| FEATURE BUFFS | 1.7 | +18.2 | 0.0 | 0.0 | 1.0 | +9.8 | 0.0 | 0.0 |
| FIGHT TO THE END | 1.3 | +12.8 | 200.0 | 155.0 | 2.7 | +10.7 | 265.0 | 164.7 |
| FIRE IN ORDER | - | - | - | - | 0.3 | +0.0 | 0.0 | 78.3 |
| FIVE ACTION | 80.0 | +6563.8 | 541.0 | 718.7 | 94.3 | +7132.3 | 1352.7 | 1590.0 |
| FLANK NOT WEIGHED | 7.7 | +0.0 | 0.0 | 124.7 | 9.0 | +0.0 | 0.0 | 357.3 |
| FOLLOW UP WEIGHED | 1.0 | +285.6 | 0.0 | 223.0 | 1.7 | +354.2 | 0.0 | 65.0 |
| FOUR ROUNDS | 5.0 | +435.8 | 479.3 | 155.0 | 4.7 | +187.3 | 529.3 | 229.7 |
| FREED FROM HIS FIGHT | 7.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| FRIEND CHARGES FIRST | - | - | - | - | 0.3 | -4.4 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | - | - | - | - | 2.3 | -153.4 | 0.0 | 360.0 |
| GIVES UP | 0.7 | -5.6 | 25.0 | 0.0 | - | - | - | - |
| GOAL WALK | 12.3 | +914.3 | 0.0 | 0.0 | 5.3 | +417.1 | 0.0 | 0.0 |
| HARD STAY DROPPED | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HE REFORMS ONCE FREED | 4.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| HELPER UNSEEN | 0.3 | +0.0 | 15.0 | 0.0 | - | - | - | - |
| HIS CHARGE BY HIS RUN | 11.0 | +0.0 | 0.0 | 89.0 | 12.0 | +0.0 | 0.0 | 454.7 |
| HIS CHARGE DENIED | 0.3 | +32.6 | 180.0 | 135.0 | - | - | - | - |
| HIS CHARGE LIST | 7.0 | +0.0 | 0.0 | 0.0 | 7.0 | +0.0 | 0.0 | 50.0 |
| HIS LEGAL MOVES | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 4.7 | -26.3 | 0.0 | 0.0 | 6.3 | -96.2 | 0.0 | 200.0 |
| HIS MOVE AS HE DECIDES | 46.3 | +11.0 | 803.7 | 0.0 | - | - | - | - |
| HIS MOVE WHY | - | - | - | - | 33.7 | +0.0 | 0.0 | 713.3 |
| HIS ONE MOVE | 20.7 | -108.4 | 0.0 | 94.0 | - | - | - | - |
| HIS ONE QUARTER | 3.3 | +0.0 | 0.0 | 0.0 | 5.7 | +0.0 | 0.0 | 122.3 |
| HIS OWN BEST MOVE | 2.7 | +0.0 | 0.0 | 0.0 | 12.3 | +0.0 | 0.0 | 360.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 31.3 | +257.7 | 0.0 | 47.0 | 48.0 | +1112.2 | 0.0 | 644.7 |
| HIS SHOTS BY HIS RUN | 20.0 | +119.0 | 0.0 | 47.0 | 43.7 | +570.3 | 0.0 | 633.0 |
| HIS TURN DENIED | 1.0 | +1.7 | 120.3 | 0.0 | 2.3 | +54.1 | 323.3 | 149.7 |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 15.7 | +0.0 | 0.0 | 42.0 | 13.3 | +0.0 | 0.0 | 132.0 |
| HOLDER ASSIGNMENT | 9.7 | +700.9 | 0.0 | 108.3 | 10.0 | +707.5 | 0.0 | 66.0 |
| HOLDS AMBUSHERS | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 4.7 | -166.9 | 479.3 | 155.0 | 4.0 | -143.4 | 513.0 | 229.7 |
| HUNT IN PAIRS | - | - | - | - | 1.3 | +6.3 | 0.0 | 180.0 |
| IDLE COST | 1.0 | -12.4 | 0.0 | 0.0 | 17.7 | -206.6 | 0.0 | 75.0 |
| JOINT CHARGE NOW | 1.0 | -130.7 | 50.0 | 0.0 | 0.3 | -61.1 | 61.7 | 0.0 |
| KEPT FROM ITS LAST STOP | 0.7 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 44.0 |
| LANE BY FIGURES | 1.3 | +33.0 | 0.0 | 0.0 | 1.3 | +56.1 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 13.3 | +0.0 | 559.3 | 486.0 | 9.3 | +0.0 | 617.7 | 848.7 |
| LONE WIZARD KEPT IN | 0.3 | +7.9 | 0.0 | 0.0 | 0.3 | +7.5 | 0.0 | 0.0 |
| LONG SHOT | - | - | - | - | 0.3 | +0.7 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | 1.3 | -1.5 | 200.0 | 135.0 | 3.0 | +7.1 | 346.7 | 214.7 |
| LURE BY WHAT IT DRAWS | - | - | - | - | 0.7 | -49.5 | 0.0 | 0.0 |
| MANOEUVRE | 0.3 | +0.0 | 0.0 | 0.0 | 2.0 | -1.0 | 0.0 | 69.0 |
| MARCH CHECK | 0.7 | +26.1 | 0.0 | 66.3 | - | - | - | - |
| MARCH OF THE TABLE | 0.3 | +3.4 | 0.0 | 66.3 | - | - | - | - |
| MARCH OVER CASTS | 1.7 | +405.4 | 0.0 | 66.3 | - | - | - | - |
| MARCH WHEELS ONLY | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 0.3 | +5.2 | 0.0 | 0.0 | 2.0 | +46.4 | 0.0 | 200.0 |
| MEETS IN TIME | 4.0 | +232.5 | 0.0 | 0.0 | 4.3 | +194.0 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 1.7 | +23.9 | 0.0 | 66.3 | 3.3 | +20.7 | 0.0 | 20.0 |
| MISSILES NEXT TURN | 2.7 | +41.9 | 0.0 | 66.3 | 4.0 | +18.0 | 0.0 | 20.0 |
| MOVE ORDER | 2.0 | +0.0 | 58.3 | 0.0 | 3.0 | +0.0 | 0.0 | 50.0 |
| MOVE TO CHARGE COMPUTED | 8.0 | +514.3 | 0.0 | 47.0 | 14.3 | +1405.8 | 0.0 | 409.0 |
| MOVES UNITS SPELL | 0.3 | +2.4 | 0.0 | 0.0 | - | - | - | - |
| NEARER NOT NEEDED | 9.3 | +334.1 | 0.0 | 108.3 | 8.7 | +360.3 | 0.0 | 20.0 |
| NEXT CHARGE BY LIST | 3.7 | +263.8 | 0.0 | 0.0 | 11.7 | +1125.3 | 0.0 | 360.0 |
| NO DOUBLE ROUNDS | 3.3 | -94.4 | 312.0 | 155.0 | 3.7 | -203.4 | 427.7 | 214.7 |
| NO LATE CUT | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 1.3 | -12.5 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 2.7 | -28.9 | 0.0 | 0.0 | 1.7 | -8.3 | 0.0 | 0.0 |
| ONE CHALLENGE TEST | - | - | - | - | 0.3 | -2.1 | 0.0 | 0.0 |
| ONE CHECK AFTER THE LAST CHANGE | 1.0 | +0.0 | 0.0 | 66.3 | 0.3 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 5.0 | -85.4 | 0.0 | 0.0 | 8.7 | -167.6 | 0.0 | 251.0 |
| ONE JOINT FIGURE | 0.3 | +44.9 | 0.0 | 0.0 | 0.3 | +2.4 | 61.7 | 0.0 |
| ONE OBJECTIVE FORMULA | 5.3 | -70.5 | 0.0 | 108.3 | 5.0 | +48.3 | 0.0 | 44.0 |
| ONE PROMISE A TARGET | 0.3 | -34.7 | 0.0 | 0.0 | 1.0 | -29.2 | 0.0 | 0.0 |
| ONE ROUTE | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| OPENS UP | 1.0 | +46.5 | 65.0 | 0.0 | - | - | - | - |
| OVERRUNS AWAY | 1.0 | +3.5 | 65.0 | 0.0 | 2.7 | +65.2 | 417.7 | 130.0 |
| PATHS CROSS | - | - | - | - | 0.7 | -1.3 | 0.0 | 0.0 |
| PLAN RESULT | 36.7 | +540.8 | 293.3 | 855.0 | 46.3 | +581.5 | 501.7 | 1220.0 |
| PROMISE BELOW ZERO | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| PROMISE BY ITS OWN SUM | 12.3 | -177.5 | 0.0 | 0.0 | 10.0 | -184.0 | 0.0 | 72.3 |
| PROMISE KNOWS THE FIGHT | 1.7 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 49.0 |
| PROMISE READS THE TABLE | - | - | - | - | 0.7 | -13.9 | 0.0 | 0.0 |
| PROMISE SHOT AWAY | - | - | - | - | 0.3 | -0.7 | 0.0 | 0.0 |
| PURSUES BIG PREY | - | - | - | - | 0.3 | -2.1 | 0.0 | 0.0 |
| QUARTER ODDS | 23.7 | +3198.4 | 249.0 | 116.7 | 21.7 | +2990.9 | 716.3 | 487.3 |
| REAL GROUND | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | 0.7 | +21.0 | 0.0 | 0.0 | 3.3 | +669.0 | 0.0 | 87.0 |
| REDIRECT FOR A FRIEND IN REACH | 3.3 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 106.0 |
| REFORMS TO MEET IT | 1.0 | -3.9 | 0.0 | 0.0 | 2.7 | -19.5 | 0.0 | 0.0 |
| REFUSING RETIRES | - | - | - | - | 1.0 | +0.0 | 0.0 | 169.3 |
| RESERVE FALL BACK | 0.7 | +3.1 | 0.0 | 0.0 | 1.3 | +16.3 | 0.0 | 22.0 |
| RESTRAINS TO SHOOT | 0.3 | +5.7 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | 4.0 | +189.2 | 337.0 | 155.0 | 4.7 | -4.0 | 529.3 | 229.7 |
| RISK ON THE WAY | - | - | - | - | 0.7 | +0.0 | 0.0 | 44.0 |
| ROUNDS AFTER TERROR | - | - | - | - | 3.3 | -54.8 | 451.0 | 214.7 |
| RUN DOWN | - | - | - | - | 4.3 | -82.6 | 471.0 | 229.7 |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 1.7 | -45.1 | 0.0 | 15.0 |
| SEARCH SPOT | 0.3 | +3.4 | 0.0 | 58.3 | 1.7 | +16.1 | 0.0 | 22.0 |
| SECOND LOOK | - | - | - | - | 0.7 | +46.4 | 61.7 | 0.0 |
| SELF MOVE SPELL | 2.0 | +53.3 | 0.0 | 0.0 | - | - | - | - |
| SET CREDITED ONCE | - | - | - | - | 0.7 | -6.1 | 0.0 | 15.0 |
| SET UP BY THE SET | 2.0 | +2.0 | 0.0 | 0.0 | 2.0 | +10.3 | 0.0 | 15.0 |
| SHOOTERS IN TWO RANKS | 1.0 | +2.0 | 0.0 | 0.0 | 0.3 | +1.7 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 5.0 | +0.0 | 0.0 | 258.3 | 5.7 | +0.0 | 0.0 | 78.3 |
| SHOOTS FROM THE BEST SPOT | - | - | - | - | 1.0 | +11.3 | 0.0 | 0.0 |
| SHOT OR CHARGE | 0.3 | -6.4 | 0.0 | 20.0 | - | - | - | - |
| SHOT RISK POINTS | 12.0 | -58.5 | 0.0 | 47.0 | 41.7 | -143.7 | 0.0 | 431.7 |
| SHOTS AFTER THE MOVES | 3.0 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 12.7 | +193.2 | 0.0 | 192.0 | 10.0 | +476.0 | 0.0 | 424.7 |
| SPELL WORTH | 0.7 | +0.1 | 20.0 | 0.0 | - | - | - | - |
| SPOT AS THE GAME MOVES | 6.3 | +0.0 | 0.0 | 47.0 | 9.7 | +0.0 | 0.0 | 129.7 |
| STAND AND SHOOT | - | - | - | - | 1.3 | -19.9 | 243.3 | 130.0 |
| STANDS FOR A REASON | - | - | - | - | 1.7 | +0.0 | 61.7 | 20.0 |
| STANDS STILL | 27.0 | +0.0 | 61.7 | 474.7 | 29.0 | +0.0 | 823.3 | 846.3 |
| STAY WORTH | 10.7 | +78.3 | 0.0 | 0.0 | 11.7 | +204.6 | 473.3 | 279.0 |
| STRIKE BY THE ODDS | 0.7 | +3.8 | 0.0 | 0.0 | - | - | - | - |
| STUPIDITY NEXT TURN | 0.3 | +0.0 | 0.0 | 47.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 2.7 | +150.8 | 0.0 | 0.0 | 4.3 | +442.8 | 0.0 | 119.0 |
| SUPPORT NARROWED | 1.3 | +0.0 | 20.0 | 136.7 | 0.7 | +0.0 | 66.3 | 0.0 |
| SUPPORT WORKED OUT | 2.7 | +150.8 | 0.0 | 0.0 | 4.3 | +442.8 | 0.0 | 119.0 |
| SWIFTSTRIDE BY POINTS | 0.3 | +0.3 | 0.0 | 66.3 | - | - | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 1.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| THE PROMISE ADDS | - | - | - | - | 0.7 | -90.5 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 3.0 | +0.0 | 0.0 | 66.3 | 3.3 | +0.0 | 0.0 | 25.0 |
| THE ROW KEEPS ITS WAY | 0.3 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 0.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 36.0 | +0.0 | 0.0 | 258.3 | 47.7 | +0.0 | 0.0 | 687.7 |
| TIED UP BY THE SUM | 1.7 | +181.4 | 112.0 | 0.0 | 1.0 | +142.0 | 162.7 | 0.0 |
| TIME ON OUR SIDE | 28.3 | +427.3 | 0.0 | 166.7 | 3.3 | +28.7 | 0.0 | 180.0 |
| WAITS AGAIN | 1.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 180.0 |
| WAR ENGINE JOBS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| WEAPON BY POINTS | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| WHAT THE JOINER ADDS | - | - | - | - | 1.0 | +2.6 | 60.0 | 30.0 |
| WHO FIGHTS | 0.3 | -2.1 | 20.0 | 0.0 | 1.0 | -2.6 | 211.3 | 130.0 |
| WHO HITS BACK | - | - | - | - | 1.0 | +73.3 | 0.0 | 0.0 |
| WHOLE FIGHT | - | - | - | - | 0.7 | +3.0 | 40.0 | 15.0 |
| WHOLE FIGHT DANGER | 3.7 | -489.9 | 0.0 | 42.0 | 2.0 | -249.5 | 0.0 | 254.7 |
| WHOLE FIGHT GAIN | 0.3 | +119.3 | 0.0 | 0.0 | 0.3 | +94.6 | 61.7 | 0.0 |
| WOUNDED STAYS OUT | - | - | - | - | 0.3 | +0.0 | 16.3 | 0.0 |
| WOUNDS ON THE RANKS | 0.7 | +0.2 | 0.0 | 0.0 | 3.7 | +79.0 | 0.0 | 20.0 |

### Rule changes: cnomg-c940641-p9

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS MOVE AS HE DECIDES | 139 | 139 | 106 | 35.33 | +0 | +0.0 |
| HIS MOVE WHY | 101 | 101 | 79 | 26.33 | +0 | +0.0 |
| ARMY TABLE | 116 | 116 | 77 | 25.67 | +1183 | +15.4 |
| LEGAL CHARGES ONLY | 68 | 68 | 68 | 22.67 | +0 | +0.0 |
| HOLDER ASSIGNMENT | 59 | 59 | 55 | 18.33 | +3201 | +58.2 |
| HIS SHOT LIST | 238 | 233 | 38 | 12.67 | +311 | +8.2 |
| MOVE TO CHARGE COMPUTED | 67 | 63 | 32 | 10.67 | +731 | +22.8 |
| THE TABLE AGAIN | 36 | 36 | 31 | 10.33 | +0 | +0.0 |
| FIVE ACTION | 523 | 510 | 27 | 9.00 | +746 | +27.6 |
| DEPLOY BY FIGURES | 45 | 45 | 25 | 8.33 | +242 | +9.7 |
| HIS SHOTS BY HIS RUN | 191 | 189 | 25 | 8.33 | +293 | +11.7 |
| REDIRECT FOR A FRIEND IN REACH | 22 | 22 | 22 | 7.33 | +0 | +0.0 |
| PROMISE BY ITS OWN SUM | 67 | 67 | 21 | 7.00 | -1085 | -51.7 |
| MEETS IN TIME | 25 | 25 | 19 | 6.33 | +1217 | +64.0 |
| NEXT CHARGE BY LIST | 46 | 43 | 19 | 6.33 | +637 | +33.5 |
| HIS ONE MOVE | 62 | 60 | 18 | 6.00 | +0 | +0.0 |
| SHOT RISK POINTS | 161 | 158 | 18 | 6.00 | +368 | +20.5 |
| FOUR ROUNDS | 29 | 27 | 17 | 5.67 | +592 | +34.8 |
| GOAL WALK | 53 | 53 | 15 | 5.00 | +704 | +46.9 |
| MOVE ORDER | 15 | 15 | 15 | 5.00 | +0 | +0.0 |
| OFF BEST | 13 | 13 | 13 | 4.33 | -111 | -8.5 |
| QUARTER ODDS | 136 | 129 | 13 | 4.33 | +761 | +58.6 |
| SUPPORT ADDS | 21 | 21 | 11 | 3.67 | +449 | +40.8 |
| SUPPORT WORKED OUT | 21 | 21 | 11 | 3.67 | +449 | +40.8 |
| COVER ONCE | 58 | 39 | 10 | 3.33 | +153 | +15.3 |
| RISK BY ARC | 26 | 24 | 9 | 3.00 | +219 | +24.3 |
| FOLLOW UP WEIGHED | 8 | 8 | 8 | 2.67 | +1919 | +239.9 |
| LANE BY FIGURES | 8 | 8 | 8 | 2.67 | +267 | +33.4 |
| TIED UP BY THE SUM | 8 | 8 | 8 | 2.67 | +315 | +39.3 |
| CHARGE NOW FIRST | 20 | 20 | 6 | 2.00 | -303 | -50.6 |
| IDLE COST | 56 | 47 | 6 | 2.00 | +61 | +10.2 |
| RESERVE FALL BACK | 6 | 6 | 6 | 2.00 | +58 | +9.7 |
| ADVANCE LANE KEPT | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| AFTERMATH IN POINTS | 5 | 5 | 5 | 1.67 | +778 | +155.7 |
| CHAFF PASSED | 5 | 5 | 5 | 1.67 | -0 | -0.1 |
| COMBAT PIVOT | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| OVERRUNS AWAY | 11 | 10 | 5 | 1.67 | +118 | +23.6 |
| CASTS FROM BEHIND | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| CHARGE LOSSES | 97 | 94 | 4 | 1.33 | +430 | +107.5 |
| EXACT ROUND | 21 | 21 | 4 | 1.33 | +13 | +3.2 |
| HARD STAY DROPPED | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| JOINT CHARGE NOW | 4 | 4 | 4 | 1.33 | -576 | -143.9 |
| ONE PROMISE A TARGET | 4 | 4 | 4 | 1.33 | -192 | -47.9 |
| SEARCH SPOT | 6 | 6 | 4 | 1.33 | +64 | +16.0 |
| SHOOTERS IN TWO RANKS | 4 | 4 | 4 | 1.33 | +11 | +2.8 |
| CHAFF IN THE MOVE | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| CHALLENGE BY POINTS | 3 | 3 | 3 | 1.00 | +16 | +5.3 |
| HOLDS AMBUSHERS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| STAY WORTH | 67 | 54 | 3 | 1.00 | +13 | +4.2 |
| SUPPORT NARROWED | 6 | 6 | 3 | 1.00 | -342 | -114.1 |
| TIME ON OUR SIDE | 95 | 77 | 3 | 1.00 | +2 | +0.8 |
| WHO HITS BACK | 3 | 3 | 3 | 1.00 | +92 | +30.7 |
| CANNON PLANNED TARGET | 4 | 4 | 2 | 0.67 | +0 | +0.0 |
| CAST JOB | 4 | 4 | 2 | 0.67 | +10 | +5.0 |
| FALLS SHORT | 63 | 51 | 2 | 0.67 | +36 | +18.1 |
| LONE WIZARD KEPT IN | 2 | 2 | 2 | 0.67 | +46 | +23.1 |
| MAX FOR POSITIONING | 7 | 6 | 2 | 0.67 | +0 | +0.0 |
| PATHS CROSS | 2 | 2 | 2 | 0.67 | -4 | -2.0 |
| SECOND LOOK | 2 | 2 | 2 | 0.67 | +139 | +69.7 |
| SET UP BY THE SET | 12 | 12 | 2 | 0.67 | +23 | +11.6 |
| STRIKE BY THE ODDS | 2 | 2 | 2 | 0.67 | +11 | +5.7 |
| THE ROW IN ITS ORDER | 19 | 2 | 2 | 0.67 | +0 | +0.0 |
| WHAT THE JOINER ADDS | 3 | 3 | 2 | 0.67 | +0 | +0.1 |
| WHOLE FIGHT | 2 | 2 | 2 | 0.67 | +5 | +2.4 |
| WHOLE FIGHT DANGER | 17 | 17 | 2 | 0.67 | +26 | +13.0 |
| WOUNDS ON THE RANKS | 13 | 13 | 2 | 0.67 | +39 | +19.5 |
| ASSAILMENT BY POINTS | 1 | 1 | 1 | 0.33 | +0 | +0.5 |
| BEST PRIZE | 1 | 1 | 1 | 0.33 | -89 | -89.1 |
| CHARGE NOT DECLARED | 1 | 1 | 1 | 0.33 | -386 | -385.7 |
| EDGE GIVE GROUND | 1 | 1 | 1 | 0.33 | +5 | +5.4 |
| FEATURE BUFFS | 8 | 8 | 1 | 0.33 | +0 | +0.0 |
| FIGHT TO THE END | 12 | 12 | 1 | 0.33 | +5 | +4.8 |
| FIRE IN ORDER | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FRIEND SHOOTS FIRST | 7 | 7 | 1 | 0.33 | +38 | +37.8 |
| HIS TURN DENIED | 10 | 8 | 1 | 0.33 | +30 | +30.4 |
| HONEST WORTH | 26 | 24 | 1 | 0.33 | +12 | +12.4 |
| MANOEUVRE | 7 | 7 | 1 | 0.33 | +12 | +12.5 |
| MARCH CHECK | 2 | 2 | 1 | 0.33 | +9 | +8.7 |
| MARCH OF THE TABLE | 1 | 1 | 1 | 0.33 | -10 | -10.1 |
| MISSILES IN THE MOVE | 15 | 12 | 1 | 0.33 | +26 | +25.7 |
| MOVES UNITS SPELL | 1 | 1 | 1 | 0.33 | +7 | +7.3 |
| NEARER NOT NEEDED | 54 | 52 | 1 | 0.33 | +145 | +145.0 |
| NO DOUBLE ROUNDS | 21 | 20 | 1 | 0.33 | +30 | +30.4 |
| ONE JOINT FIGURE | 2 | 1 | 1 | 0.33 | +44 | +44.2 |
| OPENS UP | 3 | 3 | 1 | 0.33 | +0 | +0.0 |
| PROMISE READS THE TABLE | 2 | 2 | 1 | 0.33 | -28 | -28.2 |
| PROMISE SHOT AWAY | 1 | 1 | 1 | 0.33 | -2 | -2.0 |
| PURSUES BIG PREY | 1 | 1 | 1 | 0.33 | -6 | -6.2 |
| REFUSING RETIRES | 3 | 3 | 1 | 0.33 | -28 | -28.2 |
| RESTRAINS TO SHOOT | 1 | 1 | 1 | 0.33 | +17 | +17.0 |
| SWIFTSTRIDE BY POINTS | 1 | 1 | 1 | 0.33 | +1 | +0.9 |
| WEAPON BY POINTS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| WHOLE FIGHT GAIN | 2 | 1 | 1 | 0.33 | +44 | +44.2 |
| BACKUP TARGETS | 3 | 1 | 0 | 0.00 | - | - |
| BLOWS WHERE AIMED | 1 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 1 | trace | - | - | - | - |
| CLOSES ON WHAT IT BEATS | 86 | 84 | 0 | 0.00 | - | - |
| DENIED BY THE FIGHT | 2 | 1 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 4 | 2 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 22 | 21 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 50 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 23 | 22 | 0 | 0.00 | - | - |
| FRIEND CHARGES FIRST | 1 | 1 | 0 | 0.00 | - | - |
| GIVES UP | 2 | 2 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 14 | 14 | 0 | 0.00 | - | - |
| HELPER UNSEEN | 1 | 1 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 69 | 67 | 0 | 0.00 | - | - |
| HIS CHARGE DENIED | 1 | 1 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 42 | 41 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 36 | 34 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 33 | 31 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 27 | 26 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 45 | 44 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN RUN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 87 | 87 | 0 | 0.00 | - | - |
| HUNT IN PAIRS | 4 | 1 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 12 | 12 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 2 | 2 | 0 | 0.00 | - | - |
| LONG SHOT | 1 | 1 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 13 | 12 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 2 | 2 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 5 | 5 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 2 | 2 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 20 | 16 | 0 | 0.00 | - | - |
| NO LATE CUT | 2 | 2 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 18 | 18 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 4 | not checked | - | - | - | - |
| ONE CHALLENGE TEST | 1 | 1 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 4 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 41 | 21 | 0 | 0.00 | - | - |
| ONE OBJECTIVE FORMULA | 31 | 22 | 0 | 0.00 | - | - |
| ONE ROUTE | 2 | 2 | 0 | 0.00 | - | - |
| PLAN RESULT | 249 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 3 | 3 | 0 | 0.00 | - | - |
| PROMISE KNOWS THE FIGHT | 10 | 9 | 0 | 0.00 | - | - |
| REAL GROUND | 2 | 2 | 0 | 0.00 | - | - |
| REDIRECT COUNTER | 12 | 12 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 11 | 11 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 2 | 2 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 10 | 9 | 0 | 0.00 | - | - |
| RUN DOWN | 13 | 11 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 5 | 5 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 6 | not checked | - | - | - | - |
| SET CREDITED ONCE | 2 | 2 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 32 | not checked | - | - | - | - |
| SHOOTS FROM THE BEST SPOT | 3 | 3 | 0 | 0.00 | - | - |
| SHOT OR CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| SHOTS AFTER THE MOVES | 14 | 14 | 0 | 0.00 | - | - |
| SHOTS IN THE MOVE | 68 | 42 | 0 | 0.00 | - | - |
| SPELL WORTH | 2 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 48 | 40 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 4 | 3 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 5 | 5 | 0 | 0.00 | - | - |
| STANDS STILL | 168 | 163 | 0 | 0.00 | - | - |
| STUPIDITY NEXT TURN | 6 | 6 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 5 | not checked | - | - | - | - |
| THE PROMISE ADDS | 2 | 2 | 0 | 0.00 | - | - |
| THE ROW KEEPS ITS WAY | 11 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 6 | not checked | - | - | - | - |
| THE TABLE BINDS | 251 | not checked | - | - | - | - |
| WAITS AGAIN | 8 | 6 | 0 | 0.00 | - | - |
| WAR ENGINE JOBS | 2 | 2 | 0 | 0.00 | - | - |
| WHO FIGHTS | 4 | 4 | 0 | 0.00 | - | - |
| WOUNDED STAYS OUT | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: cnomg-c940641-p9

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| PROMISE BY ITS OWN SUM | rule | 4.33 | 2.67 | 51.7 |
| ARMY TABLE | rule | 1.00 | 3.33 | 83.6 |
| JOB FIRST | gate | 2.00 | 1.33 | 6.3 |
| CHARGE NOW FIRST | rule | 1.00 | 1.00 | 50.6 |
| ONE PROMISE A TARGET | rule | 0.33 | 1.00 | 47.9 |
| JOINT CHARGE NOW | rule | 0.67 | 0.33 | 191.8 |
| SUPPORT NARROWED | rule | 0.67 | 0.33 | 114.1 |
| HOLDER ASSIGNMENT | rule | - | 0.67 | 2.0 |
| RULE SWITCHED OFF | gate | 0.67 | - | 22.0 |
| AFTERMATH BAND | gate | - | 0.33 | 4.2 |
| AFTERMATH IN POINTS | rule | - | 0.33 | 4.2 |
| BEST PRIZE | rule | - | 0.33 | 89.1 |
| CHARGE NOT DECLARED | rule | 0.33 | - | 385.7 |
| MARCH OF THE TABLE | rule | 0.33 | - | 10.1 |
| PATHS CROSS | rule | - | 0.33 | 11.0 |
| PROMISE READS THE TABLE | rule | - | 0.33 | 28.2 |
| PROMISE SHOT AWAY | rule | - | 0.33 | 2.0 |
| PURSUES BIG PREY | rule | - | 0.33 | 6.2 |
| REFUSING RETIRES | rule | - | 0.33 | 28.2 |

### Plans: cnomg-c940641-p9

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 4.3 | 69% | 498 | 386 | 78% |
| Mine | move | 28.3 | 99% | 1820 | 0 | 0% |
| Mine | shoot | 4.0 | 67% | 278 | 155 | 56% |
| Opponent | charge | 4.7 | 71% | 541 | 464 | 86% |
| Opponent | join | 2.3 | 100% | 91 | 0 | 0% |
| Opponent | move | 34.7 | 94% | 1825 | 0 | 0% |
| Opponent | shoot | 3.3 | 40% | 443 | 118 | 27% |
| Opponent | support | 1.3 | 75% | 0 | 0 | - |

### Battle groups: cnomg-c940641-p9

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 0.7 | 50% | 100% | 0% | - | 0% | 0% | 0% | 100% | 0% |
| Opponent | REDIRECT COUNTER | 3.3 | 50% | 60% | 40% | 50% | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: cnomg-c940641-p9

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | 0 (1) | - | - | - | 0 (1) |
| Mine | Chaff | 2 | 0 (2) | 0 | 0 | 0 | 0% | 1.0 | - | 0 (2) | - | 0 (1) | 0 (1) |
| Mine | Character | 8 | 48 (8) | 48 | 0 | 20 | 0% | 2.5 | 8 (3) | 55 (4) | 98 (1) | 29 (5) | 74 (3) |
| Mine | Clean-up | 1 | 0 (1) | 0 | 0 | 100 | 0% | 2.0 | 0 (1) | - | - | 0 (1) | - |
| Mine | Fast Hammer | 4 | 49 (4) | 27 | 23 | 21 | 25% | 2.0 | 0 (1) | 62 (3) | - | 106 (1) | 34 (3) |
| Mine | Hammer | 4 | 28 (4) | 28 | 0 | 68 | 25% | 1.7 | 35 (3) | 0 (1) | - | 28 (4) | - |
| Mine | Shooter | 6 | 95 (6) | 19 | 76 | 46 | 0% | 1.3 | 109 (2) | 47 (3) | 289 (1) | 154 (4) | 0 (2) |
| Mine | Support | 3 | 88 (3) | 88 | 0 | 67 | 0% | 3.0 | - | 66 (2) | - | 66 (2) | - |
| Mine | War machine | 2 | 0 (2) | 0 | 0 | 50 | 0% | 1.0 | 0 (1) | 0 (1) | - | 0 (2) | - |
| Mine | Wizard | 1 | 0 (1) | 0 | 0 | 0 | 0% | 3.0 | 0 (1) | - | - | 0 (1) | - |
| Opponent | Chaff | 10 | 53 (10) | 10 | 43 | 69 | 30% | 2.7 | 8 (6) | 33 (3) | 364 (1) | 60 (7) | 33 (3) |
| Opponent | Character | 9 | 54 (9) | 54 | 0 | 26 | 11% | 3.2 | 43 (2) | 27 (4) | 82 (3) | 29 (3) | 64 (6) |
| Opponent | Clean-up | 3 | 60 (3) | 60 | 0 | 87 | 0% | 3.0 | 292 (1) | 25 (2) | - | 85 (2) | 39 (1) |
| Opponent | Fast Hammer | 8 | 32 (8) | 23 | 9 | 16 | 25% | 3.2 | 39 (1) | 28 (5) | 34 (2) | 29 (3) | 33 (5) |
| Opponent | Hammer | 1 | 0 (1) | 0 | 0 | 127 | 0% | 2.0 | - | 0 (1) | - | - | 0 (1) |
| Opponent | Holder | 2 | 0 (2) | 0 | 0 | 0 | 0% | 2.0 | - | 0 (1) | 0 (1) | 0 (1) | 0 (1) |
| Opponent | Support | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Wizard | 5 | 0 (5) | 0 | 0 | 44 | 20% | 2.8 | 0 (3) | 0 (1) | - | 0 (2) | 0 (2) |

### Charged fights: cnomg-c940641-p9

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | High Elf Realms | 1 | 0 | 370 | 6.0 | 1.0 | 62 | 0 | +62 | 2 of 6 | 4 of 6 | - | +62 |
| Mine | Kingdom of Bretonnia | 1 | 0 | 267 | 4.0 | 1.2 | 67 | 0 | +67 | 1 of 4 | 3 of 4 | +75 | +64 |
| Mine | Lizardmen | 1 | 66 | 391 | 5.0 | 1.0 | 78 | 28 | +50 | 1 of 5 | 3 of 5 | - | +50 |
| **Mine** | all armies | 3 | 22 | 343 | 5.0 | 1.1 | 69 | 9 | +59 | 4 of 15 | 10 of 15 | +75 | +58 |
| Opponent | Tomb Kings of Khemri | 1 | 175 | 863 | 5.0 | 1.2 | 173 | 147 | +26 | 1 of 5 | 4 of 5 | +39 | +22 |
| Opponent | Vampire Counts | 2 | 0 | 374 | 3.5 | 1.0 | 107 | 36 | +71 | 1 of 7 | 6 of 7 | - | +71 |
| **Opponent** | all armies | 3 | 58 | 537 | 4.0 | 1.1 | 134 | 82 | +52 | 2 of 12 | 10 of 12 | +39 | +53 |

### Effective charges: cnomg-c940641-p9

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | High Elf Realms | 6 | 1 (net +0) | 0 | 1 (net +0) | 1 (net +250) | 2 (net +60) | 0 | 1 | 20% (1 of 5) |
| Mine | Kingdom of Bretonnia | 4 | 0 | 0 | 1 (net +45) | 1 (net +0) | 1 (net +75) | 1 (net +147) | 0 | 25% (1 of 4) |
| Mine | Lizardmen | 5 | 0 | 0 | 1 (net +0) | 0 | 1 (net +66) | 1 (net +235) | 2 | 33% (1 of 3) |
| Opponent | Tomb Kings of Khemri | 5 | 0 | 0 | 0 | 2 (net +20) | 1 (net +0) | 1 (net +175) | 1 | 0% (0 of 4) |
| Opponent | Vampire Counts | 7 | 1 (net +0) | 0 | 1 (net -154) | 3 (net +128) | 0 | 2 (net +132) | 0 | 14% (1 of 7) |

### Charged fights, damage counted: cnomg-c940641-p9

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 1 | 395 | 380 | +0 | 66 | 198 | -131 | -33.2 |
| Mine | Effective (55-75%) | 3 | 247 | 187 | +15 | 25 | 0 | +25 | +10.1 |
| Mine | 76-89% | 2 | 243 | 270 | +125 | 125 | 22 | +103 | +42.4 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 338 | 166 | +191 | 191 | 0 | +191 | +56.5 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 4 | 486 | 65 | +65 | 65 | 14 | +51 | +10.6 |
| Mine | No odds | 3 | 346 | 212 | -17 | 30 | 47 | -17 | -4.9 |
| Mine | All fights | 15 | 352 | 181 | +59 | 75 | 29 | +46 | +13.0 |
| Opponent | Long shot (under 50%) | 1 | 50 | 80 | +0 | 40 | 0 | +40 | +80.0 |
| Opponent | Effective (55-75%) | 1 | 254 | 100 | -154 | 100 | 254 | -154 | -60.6 |
| Opponent | 76-89% | 5 | 306 | 131 | +85 | 132 | 58 | +74 | +24.2 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 | 420 | 253 | +146 | 208 | 11 | +198 | +47.1 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 195 | 49 | +0 | 0 | 0 | +0 | +0.0 |
| Opponent | No odds | 1 | 431 | 405 | -86 | 454 | 588 | -134 | -31.1 |
| Opponent | All fights | 12 | 310 | 171 | +52 | 157 | 97 | +60 | +19.2 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| cnomg-c940641-p9 | move | 31 | 7 (23%) | 7 (23%) | 7 (23%) | 17 (55%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L1527, L1625 |
| Invocation of Nehek | Opponent | L1527, L1625 |
| Ring of Doom | Mine | L1527 |

# Doctrine scorecard: cnomg-c940641-p32

### Scorecard: cnomg-c940641-p32

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L1319 | 5 | 1 | Mine | yes | - | 3 | 2 | 3 | 0 | 0 | 0 | 140 |
| L1319 | 5 | 1 | Opponent | no | - | 2 | 2 | 5 | 0 | 0 | 0 | 0 |
| L1335 | 3 | 1 | Mine | - | - | - | - | - | - | - | - | - |
| L1335 | 3 | 1 | Opponent | - | - | - | - | - | - | - | - | - |
| L1431 | 3 | 1 | Mine | yes | 4 | 2 | 6 | 1 | 0 | 0 | 0 | 0 |
| L1431 | 3 | 1 | Opponent | no | 1 | - | 0 | 2 | 0 | 0 | 0 | 286 |
| **Average** | | | Mine | 100% | 4.0 | 2.5 | 4.0 | 2.0 | 0.0 | 0.0 | 0.0 | 70.0 |
| **Average** | | | Opponent | 0% | 1.0 | 2.0 | 1.0 | 3.5 | 0.0 | 0.0 | 0.0 | 143.0 |

### KPIs: cnomg-c940641-p32

Rules off - Opponent only: NO OLD ONE-MOVE GUESS.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 23% (3 of 13) | 0% (0 of 10) | 13% (3 of 23) |
| Winner chose to follow up after the loser gave ground |  | - | - | - |
| Winner chose to pursue after the loser fell back in good order |  | 100% (2 of 2); on the table 100% | - | 100% (2 of 2); on the table 100% |
| Winner chose to pursue after the loser fled |  | 0% (0 of 1); on the table 0% | 50% (1 of 2); on the table 100% | 33% (1 of 3); on the table 67% |
| Winner chose to follow up or pursue (all three) |  | 67% (2 of 3); on the table 67% | 50% (1 of 2); on the table 100% | 60% (3 of 5); on the table 80% |
| Magic missiles tried each own turn | 50%+ | 20% (3 of 15) | 48% (10 of 21) | 36% (13 of 36) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 25% (3 of 12) | 59% (10 of 17) | 45% (13 of 29) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 50% (6 of 12) | 50% (6 of 12) |
| Points that never fought | lower | 51% (2058 of 4000) | 28% (1116 of 4000) | 40% (3174 of 8000) |
|   infantry points that never fought | lower | 100% (746 of 746) | 20% (60 of 296) | 77% (806 of 1042) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 59% (10 of 17) | 80% (16 of 20) | 70% (26 of 37) |
| Bound items with a magic missile used (at least once a game) |  | 100% (2 of 2); 2.7 uses a game | 50% (1 of 2); 2.0 uses a game | 75% (3 of 4); 2.3 uses a game |
| Bound items with another spell used |  | 0% (0 of 10); 0.0 uses a game | 0.0 uses a game | 0% (0 of 10); 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
|   their share of the points of units over 100 pts | lower | 51% (1970 of 3860) | 75% (2877 of 3830) | 63% (4847 of 7690) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.3 (33%) | 1.0 (27%) | 2.3 (30%) |
| MARCHED: its unit marched | 1.3 (33%) | 0.7 (18%) | 2.0 (26%) |
| CHARGED: its unit charged | 0.3 (8%) | 0.7 (18%) | 1.0 (13%) |
| IN COMBAT: engaged in combat | 1.0 (25%) | 0.3 (9%) | 1.3 (17%) |
| GONE: slain | 0.0 (0%) | 1.0 (27%) | 1.0 (13%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 3.3 | 0.7 | 2.7 | 4.3 | 0.3 | 2.3 |
| not cast | 3.0 | 2.3 | 2.7 | 7.7 | 1.7 | 17.7 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.3 (8%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 2.3 (100%) | 0.3 (12%) | 2.3 (30%) | 0.0 (0%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.0 (26%) | 0.3 (20%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.0 (13%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.3 (17%) | 1.0 (60%) | 0.0 (0%) |
| GONE: slain | 0.3 (11%) | 0.0 (0%) | 0.3 (12%) | 1.0 (13%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (20%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.7 (89%) | 0.0 (0%) | 2.0 (75%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 16.3 (92%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 2.3 a game | 0.3 a game | 1.3 a game |
| stood (cast and not dispelled) | 71% (5 of 7) | - | 71% (5 of 7) |
| the unit moved after it | 40% (2 of 5) | - | 40% (2 of 5) |
| it charged on its next turn | 0% (0 of 5) | - | 0% (0 of 5) |
| the enemy charged it first | 20% (1 of 5) | - | 20% (1 of 5) |
| it fought by the end of its next turn | 20% (1 of 5) | - | 20% (1 of 5) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 5) | - | 0% (0 of 5) |
| none of these (no charge, no fight, no charge escaped) | 80% (4 of 5) | - | 80% (4 of 5) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 56% (32 of 57) | - | 56% (32 of 57) |
|   cavalry | 67% (8 of 12) | - | 67% (8 of 12) |
|   character | 21% (4 of 19) | - | 21% (4 of 19) |
|   infantry | 67% (12 of 18) | - | 67% (12 of 18) |
|   war machine | 100% (8 of 8) | - | 100% (8 of 8) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 3.3 (40%) | - | 3.3 (40%) |
| CHARGED: it charged | 2.0 (24%) | - | 2.0 (24%) |
| IN COMBAT: it fought this turn or the last | 0.7 (8%) | - | 0.7 (8%) |
| NO TARGET IN RANGE | 1.7 (20%) | - | 1.7 (20%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.7 (8%) | - | 0.7 (8%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 5.0 | 0.3 | 93% | 1.4 pts | 7 pts |
| character | 2.3 | 0.7 | 86% | 14.3 pts | 33 pts |
| infantry | 8.0 | 1.3 | 83% | 5.2 pts | 42 pts |
| war machine | 2.7 | 0.0 | 100% | 0.0 pts | 0 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.0 | 2.0 | 2.5 |
| Charges that made contact a game | 2.7 | 1.7 | 2.2 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.33 declared, 1.00 contact (3 units) | 0.00 declared, 0.00 contact (1 units) | 1.00 declared, 0.75 contact (4 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | - | - |
|   per unit a game, the other units (no war machines, no joined characters) | 0.21 declared, 0.21 contact (24 units) | 0.26 declared, 0.22 contact (23 units) | 0.23 declared, 0.21 contact (47 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 60% (6 of 10) | 50% (1 of 2) | - | 58% (7 of 12) |
| Character in a unit | 100% (3 of 3) | 100% (1 of 1) | - | 100% (4 of 4) |
| Character on its own | 100% (4 of 4) | 50% (1 of 2) | 40% (2 of 5) | 64% (7 of 11) |
| Infantry | 60% (3 of 5) | 100% (1 of 1) | - | 67% (4 of 6) |
| Monster | 100% (2 of 2) | - | - | 100% (2 of 2) |
| Monstrous | - | 100% (2 of 2) | - | 100% (2 of 2) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| High Elf Realms | 2 | 67% (2 of 3); on the table 67% | 17% (2 of 12) | 51% | 59% (10 of 17) | 100% (1 of 1); 3.0 uses a game | 0% (0 of 8); 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 1 | 100% (1 of 1); on the table 100% | 67% (8 of 12) | 33% | 75% (6 of 8) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Warriors of Chaos | 1 | 0% (0 of 1); on the table 100% | 17% (1 of 6) | 23% | 83% (10 of 12) | 100% (1 of 1); 6.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (cnomg-c940641-p32, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 33% (1) | 38% (3) | 36% (4) |
| ...free all their last turn and able to turn (per game) | 0.33 | 1.00 | 1.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.33 | 1.00 | 1.33 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: cnomg-c940641-p32

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 4.0 | 3.0 |
| Strategy | Charge objectives carried out (made contact) | 75% (6 of 8) | 100% (4 of 4) |
| Strategy | Shoot objectives carried out (shot that target) | 68% (13 of 19) | 0% (0 of 7) |
| Strategy | Hexes on a unit its side charged or shot that turn | 0% (0 of 1) | - |
| Strategy | Joined characters whose unit fought | - | 100% (4 of 4) |
| Strategy | Lone characters that fought | 80% (4 of 5) | 83% (5 of 6) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 2.0 | 3.5 |
| Movement | Points that never moved of their own | 70.0 | 143.0 |
| Movement | Fights charged into per game | 4.0 | 1.0 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 6 | 0 of 1 |
| Movement | Charges with odds: sweet spot (55-75%) | 1 of 6, net +492 | 0 of 1 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 2 of 6, net +72 | 1 of 1, net +70 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 of 6, net +0 | 0 of 1 |
| Shooting | Shots by shooting units (incl. breath weapons) | 9.3 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 39% (11 of 28) | - |
| Shooting | Points destroyed by shooting units | 0.0 | 0.0 |
| Shooting | War machine shots | 2.7 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 75% (6 of 8) | - |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | 1.0 | 2.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 33% (1 of 3) | 57% (4 of 7) |
| Magic | Wounds caused by magic missiles | 5.0 | 2.3 |
| Magic | Wounds caused by other spells | 1.0 | - |
| Magic | Points destroyed by magic (all spells) | 101.7 | 47.7 |
| Magic | Augments / hexes / assailments / vortexes cast | 2.0 / 0.3 / 1.0 / 0.0 | 0.3 / 0.3 / 0.3 / 0.0 |
| Combat | Points destroyed in combat | 289.7 | 139.0 |
| Combat | Points run down | 0.0 | 197.7 |
| Combat | Net points per charged fight, damage counted | +38 | +158 |
| Combat | Net per 100 charger points, damage counted | +9.8 | +45.3 |
| Combat | First round won (charged fights) | 50% | 50% |
| Combat | Net points per charged fight | +52 | +208 |
| Combat | Net points per supported fight / lone fight | - / +52 | - / +208 |
| Combat | Charged fights on a top-3 enemy unit | 3 of 8 | 1 of 2 |
| Game | Points lost | 476.5 | 559.0 |
| Game | VP from objectives | 855.0 | 340.0 |
| Game | Lone holders (player turns) | 4.0 | 1.0 |

- Mine won / drew / lost: 1 / 1 / 0 of 2 ended games (of 3); mean margin (Mine - Opponent) +423 VP
- The side that went first won 0 of 1 games with a winner
- Points traded per game (both sides' losses): 1036
- Games not ended: 1 (L1335-1); findings 1, warnings 0

### Opponent rules: cnomg-c940641-p32

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 2.0 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| ARMY TABLE | 30.7 | +590.5 | 0.0 | 47.7 | 25.7 | +156.4 | 0.0 | 65.0 |
| ASSAILMENT BY POINTS | 0.3 | +3.1 | 0.0 | 0.0 | 0.3 | +0.7 | 0.0 | 0.0 |
| CANNON PLANNED TARGET | 4.7 | +23.9 | 0.0 | 46.7 | - | - | - | - |
| CARRIES OUT SET-UP | 0.3 | -3.5 | 18.3 | 0.0 | - | - | - | - |
| CAST JOB | 0.3 | +17.5 | 0.0 | 0.0 | - | - | - | - |
| CASTING BLOCK | - | - | - | - | 2.0 | +25.9 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 1.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CHALLENGE BY POINTS | - | - | - | - | 1.0 | +14.9 | 0.0 | 113.0 |
| CHAMPION KNOWS CHALLENGE | 0.7 | -5.5 | 0.0 | 50.3 | - | - | - | - |
| CHARGE LOSSES | 16.0 | -538.1 | 0.0 | 295.7 | 20.7 | -1402.9 | 0.0 | 103.7 |
| CHARGE NOW FIRST | 1.0 | +0.0 | 48.0 | 0.0 | 1.3 | +0.0 | 23.3 | 0.0 |
| CHARGER SLAIN LOST | 0.3 | -1.3 | 0.0 | 0.0 | - | - | - | - |
| CLOSES ON WHAT IT BEATS | 6.3 | +0.0 | 0.0 | 147.3 | 4.0 | +0.0 | 0.0 | 36.7 |
| COMBAT PIVOT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CONVEYANCE SEARCH | 1.7 | +199.4 | 0.0 | 0.0 | - | - | - | - |
| COVER ONCE | 8.0 | -486.9 | 0.0 | 50.3 | 6.3 | -614.7 | 0.0 | 103.7 |
| DEPLOY BY FIGURES | 7.3 | -21.6 | 0.0 | 0.0 | 7.7 | +43.4 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | 0.7 | -29.6 | 0.0 | 147.3 | - | - | - | - |
| EVASIVE BY THE ODDS | 0.3 | +53.0 | 0.0 | 0.0 | 1.7 | +1.9 | 0.0 | 0.0 |
| EXACT ROUND | 1.0 | +3.3 | 57.0 | 50.3 | 1.3 | +26.4 | 23.3 | 0.0 |
| FALL BACK GOOD ORDER | 1.7 | +1.4 | 18.3 | 147.3 | 0.3 | +0.0 | 23.3 | 0.0 |
| FALLS SHORT | 1.7 | +23.6 | 0.0 | 0.0 | 20.0 | +243.9 | 0.0 | 265.7 |
| FEATURE BUFFS | 0.7 | +7.3 | 0.0 | 0.0 | 1.7 | +11.6 | 0.0 | 55.0 |
| FIGHT TO THE END | 0.3 | +23.7 | 0.0 | 147.3 | - | - | - | - |
| FIVE ACTION | 88.3 | +6458.0 | 105.0 | 781.7 | 63.3 | +3355.9 | 23.3 | 280.7 |
| FLANK NOT WEIGHED | 4.3 | +0.0 | 0.0 | 0.0 | 6.3 | +0.0 | 0.0 | 18.3 |
| FOLLOW UP WEIGHED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FOUR ROUNDS | 2.7 | +355.6 | 105.0 | 197.7 | 1.3 | +54.7 | 23.3 | 0.0 |
| FREED FROM HIS FIGHT | 2.0 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 55.0 |
| FRIEND CHARGES FIRST | 0.3 | -6.4 | 0.0 | 0.0 | - | - | - | - |
| FRIEND SHOOTS FIRST | 2.3 | -15.0 | 0.0 | 0.0 | - | - | - | - |
| GIVES UP | 0.7 | -15.8 | 38.7 | 147.3 | - | - | - | - |
| GOAL WALK | 6.3 | +262.5 | 0.0 | 0.0 | 9.0 | +332.9 | 0.0 | 0.0 |
| GUN MASK | 1.0 | +3.4 | 0.0 | 0.0 | - | - | - | - |
| HARD STAY DROPPED | 3.0 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 77.3 |
| HE REFORMS ONCE FREED | 1.3 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 9.3 | +0.0 | 0.0 | 100.7 | 11.3 | +0.0 | 0.0 | 103.7 |
| HIS CHARGE DENIED | - | - | - | - | 0.7 | +32.8 | 0.0 | 0.0 |
| HIS CHARGE LIST | 3.0 | +0.0 | 0.0 | 0.0 | 7.3 | +0.0 | 0.0 | 38.7 |
| HIS LEGAL MOVES | 5.0 | +0.0 | 0.0 | 294.7 | 3.3 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 2.0 | -32.4 | 0.0 | 0.0 | 5.0 | -20.0 | 0.0 | 38.7 |
| HIS MOVE AS HE DECIDES | - | - | - | - | 34.7 | +7.3 | 490.7 | 0.0 |
| HIS MOVE WHY | 23.0 | +0.0 | 0.0 | 294.7 | - | - | - | - |
| HIS ONE MOVE | - | - | - | - | 21.3 | -86.7 | 0.0 | 0.0 |
| HIS ONE QUARTER | 2.3 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 7.0 | +0.0 | 0.0 | 294.7 | 1.0 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVE | 15.3 | +0.0 | 0.0 | 196.0 | - | - | - | - |
| HIS RANDOM MOVER COMES | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS RUN AFTER OUR TURN | 5.0 | +0.0 | 0.0 | 0.0 | 5.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 35.0 | +1271.7 | 0.0 | 47.7 | 43.7 | +1071.8 | 0.0 | 223.7 |
| HIS SHOTS BY HIS RUN | 33.0 | +624.0 | 0.0 | 443.0 | 47.7 | +1074.8 | 0.0 | 280.7 |
| HIS TURN DENIED | 0.3 | +1.9 | 0.0 | 147.3 | 0.7 | +4.2 | 23.3 | 0.0 |
| HIS TURN RUN | 5.3 | +0.0 | 0.0 | 0.0 | 5.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 16.0 | +0.0 | 0.0 | 0.0 | 10.0 | +0.0 | 0.0 | 110.0 |
| HOLDER ASSIGNMENT | 9.3 | +755.3 | 0.0 | 0.0 | 5.3 | +348.1 | 0.0 | 36.7 |
| HOLDS AMBUSHERS | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 2.7 | -115.7 | 105.0 | 197.7 | 1.0 | -29.6 | 23.3 | 0.0 |
| HUNT IN PAIRS | 0.3 | +0.8 | 0.0 | 0.0 | - | - | - | - |
| IDLE COST | 0.7 | -12.8 | 0.0 | 0.0 | 10.3 | -134.7 | 0.0 | 38.7 |
| JOINT CHARGE NOW | - | - | - | - | 0.3 | +14.7 | 0.0 | 0.0 |
| KEPT FROM ITS LAST STOP | 1.7 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 1.3 | +97.5 | 0.0 | 0.0 | 0.3 | +7.0 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| LEGAL CHARGES ONLY | 6.7 | +0.0 | 18.3 | 231.3 | 2.3 | +0.0 | 115.7 | 65.0 |
| LONE CHARACTER SAFE SPOT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | 2.0 | -1.6 | 38.7 | 197.7 | - | - | - | - |
| MAKE SURE TOGETHER | - | - | - | - | 0.3 | +1.7 | 0.0 | 0.0 |
| MANOEUVRE | 0.7 | +0.7 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| MARCH AT ESCAPER | - | - | - | - | 0.3 | +30.0 | 0.0 | 0.0 |
| MARCH BY THE SUM | 0.7 | +29.0 | 0.0 | 0.0 | 0.3 | +13.6 | 0.0 | 0.0 |
| MARCH CHECK | - | - | - | - | 1.0 | +33.6 | 0.0 | 0.0 |
| MARCH OF THE TABLE | 0.3 | +25.7 | 0.0 | 0.0 | 0.3 | +1.2 | 0.0 | 0.0 |
| MARCH OVER CASTS | 1.0 | +14.9 | 0.0 | 0.0 | 1.0 | +56.1 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 2.0 | +104.2 | 0.0 | 0.0 | 2.3 | +99.0 | 0.0 | 65.0 |
| MEETS IN TIME | 3.3 | +197.2 | 0.0 | 0.0 | 4.3 | +88.5 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 4.0 | +64.0 | 0.0 | 0.0 | 4.7 | +56.6 | 0.0 | 65.0 |
| MISSILES NEXT TURN | 6.0 | +45.9 | 0.0 | 0.0 | 4.7 | +75.7 | 0.0 | 65.0 |
| MOVE ORDER | 2.0 | +0.0 | 47.7 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| MOVE SPELL SPOT | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 9.3 | +1233.1 | 0.0 | 100.7 | 3.7 | +578.3 | 0.0 | 0.0 |
| MOVES UNITS SPELL | - | - | - | - | 0.3 | +1.4 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 5.7 | +258.8 | 0.0 | 0.0 | 7.0 | +270.7 | 0.0 | 66.3 |
| NEXT CHARGE BY LIST | 4.0 | +594.2 | 0.0 | 0.0 | 2.7 | +500.8 | 0.0 | 0.0 |
| NEXT OBJECTIVE NEARER | 0.3 | -3.3 | 0.0 | 0.0 | - | - | - | - |
| NO DOUBLE ROUNDS | 2.0 | -87.5 | 105.0 | 0.0 | 1.3 | -97.1 | 23.3 | 0.0 |
| NO LATE CUT | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 5.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NO RALLY LEFT | - | - | - | - | 0.3 | +12.2 | 0.0 | 0.0 |
| NO SECOND RUN | 5.3 | +0.0 | 0.0 | 0.0 | 5.0 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 0.3 | -0.2 | 0.0 | 0.0 | 0.3 | -0.4 | 0.0 | 0.0 |
| OFF BEST | 6.3 | -232.2 | 0.0 | 121.3 | 4.7 | -128.7 | 0.0 | 77.3 |
| ONE CHALLENGE TEST | 0.3 | -1.3 | 0.0 | 0.0 | 0.3 | +1.2 | 0.0 | 0.0 |
| ONE CHECK AFTER THE LAST CHANGE | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 6.7 | -167.0 | 0.0 | 245.3 | 3.0 | -27.8 | 0.0 | 0.0 |
| ONE OBJECTIVE FORMULA | 4.3 | -15.9 | 0.0 | 0.0 | 1.3 | +36.2 | 0.0 | 0.0 |
| ONE ROUTE | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| OPENS UP | - | - | - | - | 0.3 | +14.6 | 23.3 | 0.0 |
| OVERRUNS AWAY | - | - | - | - | 0.7 | +7.1 | 23.3 | 0.0 |
| PIVOT GUARDS FLANK | - | - | - | - | 0.3 | -0.4 | 0.0 | 0.0 |
| PLAN RESULT | 38.0 | +246.7 | 18.3 | 629.7 | 29.3 | +184.2 | 0.0 | 242.0 |
| PROMISE BY ITS OWN SUM | 11.0 | -770.3 | 0.0 | 100.7 | 5.3 | -59.2 | 0.0 | 77.3 |
| PROMISE IN STEPS | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE READS THE TABLE | 0.7 | -6.2 | 0.0 | 0.0 | 0.3 | -75.9 | 0.0 | 0.0 |
| PROMISE SHOT AWAY | 0.3 | -1.1 | 0.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | 18.7 | +2516.9 | 0.0 | 151.0 | 14.0 | +1639.6 | 0.0 | 0.0 |
| RANDOM MOVE BY FIGURES | - | - | - | - | 4.0 | +3.2 | 0.0 | 0.0 |
| REAL GROUND | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | - | - | - | - | 1.7 | +367.2 | 0.0 | 36.7 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 1.3 | +0.0 | 0.0 | 36.7 |
| REFORMS TO MEET IT | 2.0 | -39.0 | 0.0 | 0.0 | 0.3 | -7.8 | 0.0 | 0.0 |
| REFUSING RETIRES | 1.0 | +0.0 | 0.0 | 50.3 | - | - | - | - |
| RESERVE FALL BACK | - | - | - | - | 0.3 | +21.8 | 0.0 | 0.0 |
| RISK BY ARC | 1.3 | +34.6 | 57.0 | 147.3 | 1.3 | +42.3 | 23.3 | 0.0 |
| RISK ON THE WAY | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| ROUNDS AFTER TERROR | 1.3 | -46.3 | 86.7 | 147.3 | 0.7 | -7.6 | 23.3 | 0.0 |
| RUN DOWN | 2.3 | -86.7 | 105.0 | 50.3 | 1.3 | -10.9 | 23.3 | 0.0 |
| SEARCH SPOT | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +41.4 | 0.0 | 0.0 |
| SELF MOVE SPELL | - | - | - | - | 2.0 | +2.3 | 0.0 | 0.0 |
| SET CREDITED ONCE | 3.0 | -267.7 | 0.0 | 0.0 | - | - | - | - |
| SET UP BY THE SET | 4.7 | +209.6 | 0.0 | 195.0 | - | - | - | - |
| SET UP TOGETHER | - | - | - | - | 0.3 | +1.7 | 0.0 | 0.0 |
| SET-UP ANY TARGET | 0.3 | +18.5 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | - | - | - | - | 0.3 | +0.3 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 6.3 | +0.0 | 0.0 | 46.7 | 3.0 | +0.0 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.0 | +13.8 | 0.0 | 0.0 | 0.3 | +86.6 | 0.0 | 0.0 |
| SHOT OR CHARGE | 0.3 | -16.6 | 0.0 | 50.3 | - | - | - | - |
| SHOT RISK POINTS | 18.0 | -319.9 | 0.0 | 245.3 | 28.0 | -284.0 | 0.0 | 262.3 |
| SHOTS AFTER THE MOVES | 3.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 17.0 | +462.3 | 0.0 | 46.7 | 3.7 | +64.0 | 0.0 | 0.0 |
| SPELL SETS UP CHARGE | 0.3 | +18.5 | 0.0 | 0.0 | - | - | - | - |
| SPELL WORTH | 2.7 | +79.2 | 0.0 | 0.0 | 0.7 | +8.0 | 0.0 | 0.0 |
| SPELLS IN THE FIGHT | 1.0 | +9.4 | 38.7 | 50.3 | 0.7 | -13.3 | 0.0 | 0.0 |
| SPOT AS THE GAME MOVES | 6.7 | +0.0 | 0.0 | 47.7 | 9.0 | +0.0 | 0.0 | 83.3 |
| STANDS FOR A REASON | - | - | - | - | 4.0 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 38.0 | +0.0 | 0.0 | 93.3 | 16.7 | +0.0 | 0.0 | 114.0 |
| STAY WORTH | 21.7 | -57.3 | 0.0 | 70.0 | 5.7 | +39.5 | 0.0 | 0.0 |
| STRIKE BY THE ODDS | 0.3 | +10.3 | 0.0 | 147.3 | - | - | - | - |
| STUCK PIVOT | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 6.3 | +443.9 | 0.0 | 0.0 | 8.0 | +1315.1 | 0.0 | 57.0 |
| SUPPORT NARROWED | - | - | - | - | 1.0 | +0.0 | 23.3 | 0.0 |
| SUPPORT WORKED OUT | 6.3 | +443.9 | 0.0 | 0.0 | 8.0 | +1315.1 | 0.0 | 57.0 |
| SURE REACH TOGETHER | 0.7 | +1.9 | 0.0 | 0.0 | 0.3 | +1.2 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 1.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| THE PROMISED MOVE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE ROW IN ITS ORDER | 2.7 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 3.0 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 1.3 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 5.3 | +0.0 | 0.0 | 0.0 | 5.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 42.3 | +0.0 | 0.0 | 292.0 | 30.0 | +0.0 | 0.0 | 179.0 |
| TIED UP BY THE SUM | 1.0 | +143.7 | 66.3 | 0.0 | 0.3 | +32.0 | 23.3 | 0.0 |
| TIME ON OUR SIDE | 39.7 | +470.1 | 0.0 | 195.0 | - | - | - | - |
| WAITS AGAIN | 3.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WHO FIGHTS | 0.3 | +3.9 | 0.0 | 50.3 | - | - | - | - |
| WHO HITS BACK | 0.3 | +34.5 | 0.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT DANGER | 2.0 | -162.8 | 0.0 | 50.3 | 3.7 | -923.1 | 0.0 | 0.0 |
| WOUNDS ON THE RANKS | - | - | - | - | 4.3 | +84.2 | 0.0 | 0.0 |

### Rule changes: cnomg-c940641-p32

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 169 | 169 | 121 | 40.33 | +2250 | +18.6 |
| HIS MOVE AS HE DECIDES | 104 | 104 | 82 | 27.33 | +0 | +0.0 |
| HIS MOVE WHY | 69 | 69 | 45 | 15.00 | +0 | +0.0 |
| HIS SHOT LIST | 236 | 220 | 44 | 14.67 | +1717 | +39.0 |
| HOLDER ASSIGNMENT | 44 | 44 | 37 | 12.33 | +2463 | +66.6 |
| HIS SHOTS BY HIS RUN | 242 | 232 | 36 | 12.00 | +425 | +11.8 |
| OFF BEST | 33 | 33 | 33 | 11.00 | -1082 | -32.8 |
| LEGAL CHARGES ONLY | 27 | 27 | 27 | 9.00 | +0 | +0.0 |
| THE TABLE AGAIN | 31 | 31 | 27 | 9.00 | +0 | +0.0 |
| DEPLOY BY FIGURES | 45 | 45 | 26 | 8.67 | +294 | +11.3 |
| FIVE ACTION | 455 | 431 | 24 | 8.00 | +1248 | +52.0 |
| MOVE TO CHARGE COMPUTED | 39 | 35 | 22 | 7.33 | +1634 | +74.3 |
| PROMISE BY ITS OWN SUM | 49 | 49 | 20 | 6.67 | -2489 | -124.4 |
| QUARTER ODDS | 98 | 91 | 17 | 5.67 | +1326 | +78.0 |
| SHOT RISK POINTS | 138 | 131 | 16 | 5.33 | +349 | +21.8 |
| HARD STAY DROPPED | 15 | 15 | 15 | 5.00 | +0 | +0.0 |
| HIS ONE MOVE | 64 | 64 | 15 | 5.00 | +0 | +0.0 |
| MOVE ORDER | 13 | 13 | 13 | 4.33 | +0 | +0.0 |
| ADVANCE LANE KEPT | 12 | 12 | 12 | 4.00 | +0 | +0.0 |
| NEXT CHARGE BY LIST | 20 | 17 | 12 | 4.00 | +1345 | +112.1 |
| CHARGE LOSSES | 110 | 107 | 11 | 3.67 | +1395 | +126.9 |
| MEETS IN TIME | 23 | 23 | 8 | 2.67 | +188 | +23.5 |
| FOUR ROUNDS | 12 | 11 | 7 | 2.33 | +627 | +89.6 |
| SUPPORT ADDS | 43 | 37 | 7 | 2.33 | +308 | +44.1 |
| SUPPORT WORKED OUT | 43 | 37 | 7 | 2.33 | +308 | +44.1 |
| RANDOM MOVE BY FIGURES | 12 | 12 | 6 | 2.00 | +10 | +1.6 |
| TIME ON OUR SIDE | 119 | 102 | 6 | 2.00 | +29 | +4.8 |
| WHOLE FIGHT DANGER | 17 | 17 | 6 | 2.00 | +584 | +97.3 |
| LANE BY FIGURES | 5 | 5 | 5 | 1.67 | +314 | +62.7 |
| COVER ONCE | 43 | 23 | 4 | 1.33 | +216 | +54.1 |
| GOAL WALK | 46 | 45 | 4 | 1.33 | +116 | +29.0 |
| IDLE COST | 33 | 21 | 4 | 1.33 | +37 | +9.3 |
| REDIRECT FOR A FRIEND IN REACH | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| SET UP BY THE SET | 14 | 11 | 4 | 1.33 | +253 | +63.2 |
| CHALLENGE BY POINTS | 3 | 3 | 3 | 1.00 | +45 | +15.0 |
| EVASIVE BY THE ODDS | 6 | 6 | 3 | 1.00 | +162 | +54.1 |
| HOLDS AMBUSHERS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| MARCH BY THE SUM | 3 | 3 | 3 | 1.00 | +128 | +42.6 |
| MAX FOR POSITIONING | 13 | 12 | 3 | 1.00 | +9 | +3.1 |
| STUCK PIVOT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| THE ROW IN ITS ORDER | 21 | 3 | 3 | 1.00 | +0 | +0.0 |
| TIED UP BY THE SUM | 4 | 3 | 3 | 1.00 | +71 | +23.6 |
| ASSAILMENT BY POINTS | 2 | 2 | 2 | 0.67 | +11 | +5.7 |
| CANNON PLANNED TARGET | 14 | 14 | 2 | 0.67 | -7 | -3.5 |
| CASTING BLOCK | 6 | 6 | 2 | 0.67 | +0 | +0.0 |
| CHARGE NOW FIRST | 7 | 7 | 2 | 0.67 | -28 | -14.2 |
| MARCH OF THE TABLE | 2 | 2 | 2 | 0.67 | -81 | -40.3 |
| NEARER NOT NEEDED | 38 | 36 | 2 | 0.67 | +94 | +47.2 |
| REDIRECT COUNTER | 5 | 5 | 2 | 0.67 | +49 | +24.3 |
| RISK BY ARC | 8 | 7 | 2 | 0.67 | +19 | +9.7 |
| SHOOTS FROM THE BEST SPOT | 4 | 4 | 2 | 0.67 | +92 | +45.8 |
| SHOTS IN THE MOVE | 62 | 47 | 2 | 0.67 | +33 | +16.4 |
| SUPPORT NARROWED | 3 | 3 | 2 | 0.67 | -363 | -181.5 |
| CARRIES OUT SET-UP | 1 | 1 | 1 | 0.33 | -10 | -10.5 |
| CAST JOB | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| COMBAT PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| EXACT ROUND | 7 | 6 | 1 | 0.33 | +16 | +16.0 |
| FALLS SHORT | 65 | 50 | 1 | 0.33 | +37 | +36.8 |
| FOLLOW UP WEIGHED | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| HIS CHARGE DENIED | 2 | 2 | 1 | 0.33 | +16 | +16.0 |
| HIS MOVE AND SHOT | 21 | 20 | 1 | 0.33 | +2 | +2.1 |
| JOINT CHARGE NOW | 1 | 1 | 1 | 0.33 | +44 | +44.1 |
| MANOEUVRE | 4 | 4 | 1 | 0.33 | +2 | +2.2 |
| MARCH CHECK | 3 | 3 | 1 | 0.33 | +32 | +31.9 |
| MOVES UNITS SPELL | 1 | 1 | 1 | 0.33 | +4 | +4.3 |
| NO DOUBLE ROUNDS | 10 | 9 | 1 | 0.33 | +52 | +51.7 |
| NO RALLY LEFT | 1 | 1 | 1 | 0.33 | +16 | +16.0 |
| ONE FIGHT FORMULA | 29 | 13 | 1 | 0.33 | +5 | +5.3 |
| OPENS UP | 1 | 1 | 1 | 0.33 | +29 | +29.2 |
| PIVOT GUARDS FLANK | 1 | 1 | 1 | 0.33 | -1 | -1.2 |
| PROMISE READS THE TABLE | 3 | 3 | 1 | 0.33 | -202 | -202.0 |
| PROMISE SHOT AWAY | 1 | 1 | 1 | 0.33 | -3 | -3.4 |
| REFUSING RETIRES | 3 | 3 | 1 | 0.33 | -3 | -2.9 |
| RESERVE FALL BACK | 1 | 1 | 1 | 0.33 | +65 | +65.3 |
| SEARCH SPOT | 2 | 2 | 1 | 0.33 | +124 | +124.1 |
| SHOOTERS IN TWO RANKS | 1 | 1 | 1 | 0.33 | +1 | +1.0 |
| SHOTS AFTER THE MOVES | 12 | 12 | 1 | 0.33 | +0 | +0.0 |
| SPELLS IN THE FIGHT | 5 | 5 | 1 | 0.33 | +3 | +3.4 |
| STRIKE BY THE ODDS | 1 | 1 | 1 | 0.33 | +31 | +31.0 |
| SURE REACH TOGETHER | 3 | 3 | 1 | 0.33 | +0 | +0.0 |
| WHO HITS BACK | 1 | 1 | 1 | 0.33 | +82 | +82.0 |
| CASTS AFTER FRIENDS | 6 | trace | - | - | - | - |
| CHAMPION KNOWS CHALLENGE | 2 | 2 | 0 | 0.00 | - | - |
| CHARGER SLAIN LOST | 1 | 1 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 31 | 30 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 5 | not checked | - | - | - | - |
| DUEL STOPS AT THE KILL | 2 | 2 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 6 | 5 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 7 | 7 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 1 | 1 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 32 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 18 | 17 | 0 | 0.00 | - | - |
| FRIEND CHARGES FIRST | 1 | 1 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 7 | 6 | 0 | 0.00 | - | - |
| GIVES UP | 2 | 2 | 0 | 0.00 | - | - |
| GUN MASK | 3 | 3 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 11 | 11 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 62 | 59 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 31 | 27 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 25 | 22 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 13 | 11 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 24 | 20 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 46 | 39 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 2 | 2 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 30 | 30 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 3 | 3 | 0 | 0.00 | - | - |
| HIS TURN RUN | 31 | 31 | 0 | 0.00 | - | - |
| HOLD ODDS | 78 | 77 | 0 | 0.00 | - | - |
| HONEST WORTH | 11 | 10 | 0 | 0.00 | - | - |
| HUNT IN PAIRS | 1 | not checked | - | - | - | - |
| KEPT FROM ITS LAST STOP | 11 | 10 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 2 | 2 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 1 | not checked | - | - | - | - |
| LOST AFTER ESCAPE | 6 | 6 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 1 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 6 | 6 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 3 | 3 | 0 | 0.00 | - | - |
| MISSILES IN THE MOVE | 26 | 16 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 32 | 21 | 0 | 0.00 | - | - |
| MOVE SPELL SPOT | 5 | not checked | - | - | - | - |
| NEXT OBJECTIVE NEARER | 1 | not checked | - | - | - | - |
| NO LATE CUT | 4 | 4 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 16 | 16 | 0 | 0.00 | - | - |
| NO SECOND RUN | 31 | 31 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 2 | not checked | - | - | - | - |
| ONE CHALLENGE TEST | 2 | 2 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 1 | not checked | - | - | - | - |
| ONE OBJECTIVE FORMULA | 17 | 12 | 0 | 0.00 | - | - |
| ONE ROUTE | 3 | 3 | 0 | 0.00 | - | - |
| OVERRUNS AWAY | 2 | 2 | 0 | 0.00 | - | - |
| PLAN RESULT | 202 | trace | - | - | - | - |
| PROMISE IN STEPS | 2 | 2 | 0 | 0.00 | - | - |
| REAL GROUND | 3 | 3 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 7 | 7 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 3 | 2 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 6 | 6 | 0 | 0.00 | - | - |
| RUN DOWN | 11 | 10 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 6 | not checked | - | - | - | - |
| SET CREDITED ONCE | 9 | 6 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 1 | 1 | 0 | 0.00 | - | - |
| SET-UP ANY TARGET | 1 | not checked | - | - | - | - |
| SHOOTERS ON THE TABLE | 28 | not checked | - | - | - | - |
| SHOT OR CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 1 | not checked | - | - | - | - |
| SPELL WORTH | 10 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 47 | 46 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 12 | 12 | 0 | 0.00 | - | - |
| STANDS STILL | 164 | 153 | 0 | 0.00 | - | - |
| STAY WORTH | 82 | 72 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 5 | not checked | - | - | - | - |
| THE PROMISED MOVE | 1 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 21 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 12 | not checked | - | - | - | - |
| THE TABLE BINDS | 217 | not checked | - | - | - | - |
| WAITS AGAIN | 10 | 8 | 0 | 0.00 | - | - |
| WHO FIGHTS | 1 | 1 | 0 | 0.00 | - | - |
| WOUNDS ON THE RANKS | 13 | 13 | 0 | 0.00 | - | - |

### Off best figure: cnomg-c940641-p32

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 5.00 | 3.00 | 33.3 |
| ARMY TABLE | rule | 2.33 | 5.00 | 90.7 |
| PROMISE BY ITS OWN SUM | rule | 5.33 | 1.33 | 124.4 |
| NO REASON | gate | 1.00 | - | 34.3 |
| RULE SWITCHED OFF | gate | - | 1.00 | 45.4 |
| CANNON PLANNED TARGET | rule | 0.67 | - | 3.5 |
| CHARGE NOW FIRST | rule | 0.33 | 0.33 | 14.2 |
| FALLBACK | gate | - | 0.67 | 20.5 |
| MARCH OF THE TABLE | rule | 0.33 | 0.33 | 40.3 |
| SUPPORT NARROWED | rule | - | 0.67 | 181.5 |
| CARRIES OUT SET-UP | rule | 0.33 | - | 10.5 |
| DEPLOY BY FIGURES | rule | - | 0.33 | 6.7 |
| FIGHT ORDER BAND | gate | 0.33 | - | 3.5 |
| PIVOT GUARDS FLANK | rule | - | 0.33 | 1.2 |
| PROMISE READS THE TABLE | rule | - | 0.33 | 202.0 |
| PROMISE SHOT AWAY | rule | 0.33 | - | 3.4 |
| REFUSING RETIRES | rule | 0.33 | - | 2.9 |
| SET UP BY THE SET | rule | 0.33 | - | 11.6 |

### Plans: cnomg-c940641-p32

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.7 | 40% | 152 | 115 | 76% |
| Mine | move | 31.3 | 97% | 2206 | 0 | 0% |
| Mine | shoot | 5.0 | 33% | 74 | 132 | 178% |
| Opponent | charge | 1.0 | 100% | 76 | 124 | 164% |
| Opponent | join | 2.0 | 83% | 77 | 0 | 0% |
| Opponent | move | 24.7 | 97% | 2068 | 0 | 0% |
| Opponent | shoot | 1.7 | 40% | 90 | 60 | 67% |

### Battle groups: cnomg-c940641-p32

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | REDIRECT COUNTER | 1.7 | 20% | 100% | 0% | - | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: cnomg-c940641-p32

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Character | 5 | 61 (5) | 61 | 0 | 40 | 0% | 2.2 | 58 (4) | 76 (1) | - | 0 (1) | 77 (4) |
| Mine | Clean-up | 3 | 23 (3) | 0 | 23 | 0 | 0% | 2.7 | 37 (2) | 0 (1) | - | 37 (2) | 0 (1) |
| Mine | Fast Hammer | 5 | 16 (5) | 0 | 16 | 39 | 80% | 6.0 | 0 (2) | 0 (2) | 79 (1) | 0 (1) | 20 (4) |
| Mine | Holder | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | 0 (1) | - | - | 0 (1) | - |
| Mine | Shooter | 3 | 21 (3) | 21 | 0 | 0 | 0% | 1.7 | 0 (2) | 68 (1) | - | 0 (2) | 68 (1) |
| Mine | War machine | 2 | 0 (2) | 0 | 0 | 50 | 0% | 1.0 | - | 0 (2) | - | 0 (1) | 0 (1) |
| Opponent | Chaff | 3 | 0 (3) | 0 | 0 | 65 | 100% | - | 0 (3) | - | - | 0 (3) | - |
| Opponent | Character | 7 | 31 (7) | 31 | 0 | 64 | 14% | 2.7 | 119 (1) | 0 (4) | - | 73 (3) | 0 (2) |
| Opponent | Fast Hammer | 2 | 81 (2) | 81 | 0 | 0 | 0% | 3.0 | - | 81 (2) | - | 129 (1) | 0 (1) |
| Opponent | Hammer | 5 | 31 (5) | 31 | 0 | 0 | 80% | 1.0 | 49 (3) | 0 (2) | - | 38 (4) | 0 (1) |
| Opponent | Holder | 3 | 7 (3) | 0 | 7 | 35 | 0% | 4.3 | 0 (1) | 0 (1) | 21 (1) | - | 7 (3) |
| Opponent | Wizard | 3 | 0 (3) | 0 | 0 | 34 | 0% | 1.3 | 0 (1) | 0 (2) | - | 0 (2) | 0 (1) |

### Charged fights: cnomg-c940641-p32

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | High Elf Realms | 2 | 152 | 506 | 4.0 | 1.0 | 127 | 74 | +52 | 3 of 8 | 4 of 8 | - | +52 |
| Opponent | Orc & Goblin Tribes | 1 | 0 | 417 | 2.0 | 1.0 | 208 | 0 | +208 | 1 of 2 | 1 of 2 | - | +208 |
| Opponent | Warriors of Chaos | 1 | 143 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| **Opponent** | all armies | 2 | 72 | 208 | 1.0 | 1.0 | 208 | 0 | +208 | 1 of 2 | 1 of 2 | - | +208 |

### Effective charges: cnomg-c940641-p32

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | High Elf Realms | 8 | 0 | 0 | 1 (net +492) | 2 (net -18) | 2 (net +72) | 1 (net +0) | 2 | 17% (1 of 6) |
| Opponent | Orc & Goblin Tribes | 2 | 0 | 0 | 0 | 0 | 1 (net +70) | 0 | 1 | 0% (0 of 1) |

### Charged fights, damage counted: cnomg-c940641-p32

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Effective (55-75%) | 1 | 489 | 201 | +492 | 492 | 244 | +248 | +50.6 |
| Mine | 76-89% | 2 | 326 | 116 | -18 | 58 | 76 | -18 | -5.4 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 143 | 144 | +0 | 21 | 0 | +21 | +14.4 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 2 | 500 | 132 | +72 | 114 | 0 | +114 | +22.8 |
| Mine | No odds | 2 | 416 | 272 | -90 | 144 | 221 | -77 | -18.6 |
| Mine | All fights | 8 | 389 | 173 | +52 | 143 | 105 | +38 | +9.8 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 350 | 70 | +70 | 70 | 0 | +70 | +20.0 |
| Opponent | No odds | 1 | 350 | 247 | +347 | 347 | 100 | +247 | +70.6 |
| Opponent | All fights | 2 | 350 | 158 | +208 | 208 | 50 | +158 | +45.3 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| cnomg-c940641-p32 | move | 23 | 5 (22%) | 5 (22%) | 2 (9%) | 16 (70%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Elixir of Power | Opponent | L1319 |
| Opal Amulet | Mine | L1431 |
| Ring of Doom | Opponent | L1431 |
| Standard of the Fell Warrior | Mine | L1319, L1335 |

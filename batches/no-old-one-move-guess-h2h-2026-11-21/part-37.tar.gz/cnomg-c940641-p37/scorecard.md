# Doctrine scorecard: cnomg-c940641-p37

### Scorecard: cnomg-c940641-p37

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0106 | 4 | 1 | Mine | no | 1 | 6 | 1 | 2 | 0 | 0 | 0 | 0 |
| L0106 | 4 | 1 | Opponent | no | 0 | - | 1 | 3 | 0 | 0 | 0 | 937 |
| L0122 | 2 | 1 | Mine | - | - | - | 0 | 3 | 1 | 0 | 0 | 0 |
| L0122 | 2 | 1 | Opponent | - | - | 3 | 2 | 3 | 1 | 0 | 0 | 72 |
| L0206 | 2 | 1 | Mine | - | - | - | 1 | 6 | 0 | 0 | 0 | 591 |
| L0206 | 2 | 1 | Opponent | - | - | 3 | 0 | 1 | 0 | 0 | 0 | 1261 |
| **Average** | | | Mine | 0% | 1.0 | 6.0 | 0.7 | 3.7 | 0.3 | 0.0 | 0.0 | 197.0 |
| **Average** | | | Opponent | 0% | 0.0 | 3.0 | 1.0 | 2.3 | 0.3 | 0.0 | 0.0 | 756.7 |

### KPIs: cnomg-c940641-p37

Rules off - Opponent only: NO OLD ONE-MOVE GUESS.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 9) | 65% (11 of 17) | 42% (11 of 26) |
| Winner chose to follow up after the loser gave ground |  | 50% (2 of 4); on the table 100% | 100% (1 of 1); on the table 100% | 60% (3 of 5); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | - | - | - |
| Winner chose to pursue after the loser fled |  | - | 80% (4 of 5); on the table 80% | 80% (4 of 5); on the table 80% |
| Winner chose to follow up or pursue (all three) |  | 50% (2 of 4); on the table 100% | 83% (5 of 6); on the table 83% | 70% (7 of 10); on the table 90% |
| Magic missiles tried each own turn | 50%+ | 38% (34 of 90) | - | 38% (34 of 90) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 47% (34 of 73) | - | 47% (34 of 73) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 100% (6 of 6) | - | 100% (6 of 6) |
| Points that never fought | lower | 67% (3841 of 5699) | 78% (4697 of 6000) | 73% (8538 of 11699) |
|   infantry points that never fought | lower | 66% (1475 of 2239) | 89% (1875 of 2111) | 77% (3350 of 4350) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 69% (11 of 16) | 68% (17 of 25) | 68% (28 of 41) |
| Bound items with a magic missile used (at least once a game) |  | 100% (4 of 4); 2.3 uses a game | 0.0 uses a game | 100% (4 of 4); 1.2 uses a game |
| Bound items with another spell used |  | 50% (1 of 2); 1.3 uses a game | 0.0 uses a game | 50% (1 of 2); 0.7 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 100% (4 of 4); 1.3 uses a game | 0.0 uses a game | 100% (4 of 4); 0.7 uses a game |
|   their share of the points of units over 100 pts | lower | 62% (2410 of 3916) | 60% (2640 of 4382) | 61% (5050 of 8298) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 6.7 (36%) | - | 6.7 (36%) |
| MARCHED: its unit marched | 5.3 (29%) | - | 5.3 (29%) |
| IN COMBAT: engaged in combat | 5.3 (29%) | - | 5.3 (29%) |
| GONE: slain | 0.3 (2%) | - | 0.3 (2%) |
| STUPIDITY: Stupidity | 1.0 (5%) | - | 1.0 (5%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.0 | 1.3 | 6.0 | 11.3 | 0.0 | 3.0 |
| not cast | 2.0 | 2.7 | 4.0 | 18.7 | 2.0 | 25.0 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (1%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.7 (62%) | 0.7 (17%) | 6.7 (36%) | 2.0 (100%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 5.3 (29%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 1.0 (38%) | 2.3 (58%) | 5.3 (29%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (2%) | 0.0 (0%) | 0.3 (1%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.0 (0%) | 0.3 (8%) | 1.0 (5%) | 0.0 (0%) | 0.7 (3%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.0 (100%) | 0.0 (0%) | 0.7 (17%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 23.7 (95%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 7.3 a game | 0.0 a game | 3.7 a game |
| stood (cast and not dispelled) | 41% (9 of 22) | - | 41% (9 of 22) |
| the unit moved after it | 44% (4 of 9) | - | 44% (4 of 9) |
| it charged on its next turn | 0% (0 of 9) | - | 0% (0 of 9) |
| the enemy charged it first | 0% (0 of 9) | - | 0% (0 of 9) |
| it fought by the end of its next turn | 0% (0 of 9) | - | 0% (0 of 9) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 9) | - | 0% (0 of 9) |
| none of these (no charge, no fight, no charge escaped) | 100% (9 of 9) | - | 100% (9 of 9) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 70% (16 of 23) | 62% (126 of 203) | 63% (142 of 226) |
|   cavalry | - | 53% (17 of 32) | 53% (17 of 32) |
|   character | - | 62% (10 of 16) | 62% (10 of 16) |
|   chariot | - | 83% (5 of 6) | 83% (5 of 6) |
|   infantry | 70% (16 of 23) | 57% (39 of 69) | 60% (55 of 92) |
|   monster | - | 83% (10 of 12) | 83% (10 of 12) |
|   war machine | - | 66% (45 of 68) | 66% (45 of 68) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.7 (71%) | 1.0 (4%) | 2.7 (10%) |
| CHARGED: it charged | 0.0 (0%) | 2.0 (8%) | 2.0 (7%) |
| NO TARGET IN RANGE | 0.7 (29%) | 11.3 (44%) | 12.0 (43%) |
| ONLY IN COMBAT: the only targets were in combat | 0.0 (0%) | 0.7 (3%) | 0.7 (2%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.0 (0%) | 5.3 (21%) | 5.3 (19%) |
| SHELTERED: the target was sheltered | 0.0 (0%) | 1.0 (4%) | 1.0 (4%) |
| OTHER BAR | 0.0 (0%) | 4.3 (17%) | 4.3 (15%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 8.7 | 2.3 | 81% | 2.7 pts | 23 pts |
| character | 3.3 | 3.7 | 70% | 10.0 pts | 33 pts |
| chariot | 1.7 | 0.3 | 80% | 2.2 pts | 4 pts |
| infantry | 26.7 | 11.7 | 65% | 5.1 pts | 135 pts |
| monster | 3.3 | 2.0 | 70% | 7.6 pts | 25 pts |
| war machine | 15.0 | 11.0 | 64% | 7.4 pts | 111 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 0.7 | 2.7 | 1.7 |
| Charges that made contact a game | 0.7 | 2.3 | 1.5 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | - | - | - |
|   per unit a game, units carrying another wizard (or one alone) | - | - | - |
|   per unit a game, the other units (no war machines, no joined characters) | 0.10 declared, 0.10 contact (20 units) | 0.30 declared, 0.26 contact (27 units) | 0.21 declared, 0.19 contact (47 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Character in a unit | 67% (2 of 3) | 67% (2 of 3) | - | 67% (4 of 6) |
| Character on its own | 100% (3 of 3) | 67% (2 of 3) | 0% (0 of 2) | 62% (5 of 8) |
| Infantry | 57% (4 of 7) | 57% (4 of 7) | - | 57% (8 of 14) |
| Monster | 80% (4 of 5) | - | - | 80% (4 of 5) |
| War Machines | 88% (7 of 8) | - | - | 88% (7 of 8) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 3 | 50% (2 of 4); on the table 100% | 38% (34 of 90) | 67% | 69% (11 of 16) | 100% (4 of 4); 2.3 uses a game | 50% (1 of 2); 1.3 uses a game | 100% (4 of 4); 1.3 uses a game |
| Dwarfen Mountain Holds | 2 | 100% (3 of 3); on the table 100% | - | 88% | 70% (14 of 20) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Tomb Kings of Khemri | 1 | 67% (2 of 3); on the table 67% | - | 58% | 60% (3 of 5) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (cnomg-c940641-p37, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 40% (2) | 100% (1) | 50% (3) |
| ...free all their last turn and able to turn (per game) | 0.33 | 0.33 | 0.67 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.33 | 0.33 | 0.67 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: cnomg-c940641-p37

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 0.7 | 0.7 |
| Strategy | Charge objectives carried out (made contact) | 100% (2 of 2) | 80% (4 of 5) |
| Strategy | Shoot objectives carried out (shot that target) | 43% (6 of 14) | 44% (39 of 88) |
| Strategy | Hexes on a unit its side charged or shot that turn | 50% (1 of 2) | - |
| Strategy | Joined characters whose unit fought | 38% (3 of 8) | 0% (0 of 8) |
| Strategy | Lone characters that fought | 30% (3 of 10) | 100% (2 of 2) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 3.7 | 2.3 |
| Movement | Points that never moved of their own | 197.0 | 756.7 |
| Movement | Fights charged into per game | 0.7 | 2.3 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 2 | 1 of 5, net +952 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 2 | 1 of 5, net +0 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 2 | 1 of 5, net +65 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 of 2, net +186 | 1 of 5, net +52 |
| Shooting | Shots by shooting units (incl. breath weapons) | 5.7 | 30.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 29% (5 of 17) | 60% (54 of 90) |
| Shooting | Points destroyed by shooting units | 0.0 | 238.3 |
| Shooting | War machine shots | - | 15.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | - | 78% (35 of 45) |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | 5.7 | - |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 76% (13 of 17) | - |
| Magic | Wounds caused by magic missiles | 9.0 | - |
| Magic | Wounds caused by other spells | 2.0 | - |
| Magic | Points destroyed by magic (all spells) | 109.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.0 / 0.7 / 1.7 / 0.0 | 4.0 / 0.0 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 62.0 | 39.0 |
| Combat | Points run down | 0.0 | 334.7 |
| Combat | Net points per charged fight, damage counted | +93 | +177 |
| Combat | Net per 100 charger points, damage counted | +49.7 | +110.5 |
| Combat | First round won (charged fights) | 100% | 43% |
| Combat | Net points per charged fight | +93 | +160 |
| Combat | Net points per supported fight / lone fight | - / +93 | - / +160 |
| Combat | Charged fights on a top-3 enemy unit | 1 of 2 | 2 of 7 |
| Game | Points lost | 593.7 | 209.3 |
| Game | VP from objectives | 686.7 | 616.7 |
| Game | Lone holders (player turns) | 1.0 | 0.0 |

- Mine won / drew / lost: 1 / 0 / 2 of 3 ended games (of 3); mean margin (Mine - Opponent) -384 VP
- The side that went first won 0 of 3 games with a winner
- Points traded per game (both sides' losses): 803
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: cnomg-c940641-p37

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.7 | +361.4 | 0.0 | 124.0 | - | - | - | - |
| ARMY TABLE | 16.3 | +38.1 | 0.0 | 327.7 | 18.0 | +198.9 | 0.0 | 48.0 |
| CANNON PLAN MISSED | - | - | - | - | 0.7 | +0.0 | 55.3 | 38.3 |
| CANNON PLANNED TARGET | - | - | - | - | 15.3 | +36.9 | 792.3 | 76.7 |
| CANNON SIGHT KEPT | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| CASTER AWAY FROM SCREEN | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CASTING BLOCK | 4.3 | +335.6 | 96.0 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | 3.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CATCH FLIERS | 0.3 | +8.0 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | 1.0 | +41.9 | 0.0 | 27.0 | - | - | - | - |
| CHAFF PASSED | - | - | - | - | 3.0 | +0.0 | 0.0 | 24.0 |
| CHALLENGE BY POINTS | 0.7 | +6.1 | 0.0 | 0.0 | - | - | - | - |
| CHARACTER GUNS | - | - | - | - | 4.7 | +0.0 | 0.0 | 0.0 |
| CHARGE LOSSES | 16.3 | -953.1 | 0.0 | 492.7 | 10.3 | -830.4 | 0.0 | 20.0 |
| CHARGE NOW FIRST | 0.3 | +0.0 | 0.0 | 17.3 | 1.7 | +0.0 | 59.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 10.3 | +0.0 | 0.0 | 101.0 | 6.0 | +0.0 | 0.0 | 130.0 |
| COMBAT PIVOT | - | - | - | - | 0.3 | +0.0 | 17.3 | 0.0 |
| CONVEYANCE SEARCH | 5.3 | +722.5 | 181.3 | 0.0 | - | - | - | - |
| COVER ONCE | 6.7 | -326.5 | 0.0 | 78.0 | 7.7 | -208.6 | 0.0 | 185.3 |
| DENIED BY THE FIGHT | - | - | - | - | 0.7 | -1.3 | 21.7 | 0.0 |
| DEPLOY BY FIGURES | 6.7 | +87.5 | 0.0 | 0.0 | 12.3 | -197.3 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | - | - | - | - | 0.3 | -245.9 | 0.0 | 0.0 |
| EXACT ROUND | 0.3 | -0.6 | 0.0 | 17.3 | 2.0 | -6.8 | 62.0 | 20.0 |
| FALL BACK GOOD ORDER | 0.7 | +0.0 | 62.0 | 17.3 | 2.0 | +7.0 | 56.3 | 20.0 |
| FALLS SHORT | 13.7 | +349.3 | 0.0 | 308.3 | 15.3 | +55.4 | 0.0 | 219.0 |
| FEATURE BUFFS | 15.3 | +425.6 | 0.0 | 194.3 | 1.0 | +5.0 | 0.0 | 0.0 |
| FIGHT TO THE END | 0.3 | +2.1 | 0.0 | 17.3 | 1.0 | +48.2 | 17.3 | 0.0 |
| FIRE IN ORDER | - | - | - | - | 1.0 | +0.0 | 28.3 | 0.0 |
| FIVE ACTION | 64.7 | +7306.1 | 254.0 | 1114.7 | 146.7 | +2930.3 | 2490.7 | 639.3 |
| FLANK NOT WEIGHED | 3.0 | +0.0 | 0.0 | 84.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| FOCUS FIRE | - | - | - | - | 0.3 | +3.3 | 18.3 | 0.0 |
| FOUR ROUNDS | 0.7 | +46.3 | 62.0 | 17.3 | 2.7 | +136.5 | 83.7 | 20.0 |
| FREED FROM HIS FIGHT | 0.3 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 0.3 | -4.0 | 0.0 | 21.7 | 0.7 | -0.4 | 0.0 | 0.0 |
| FRIENDS SHOTS CHECKED | - | - | - | - | 0.7 | -0.2 | 0.0 | 0.0 |
| GOAL WALK | 13.3 | +2338.1 | 0.0 | 365.3 | - | - | - | - |
| GUN FIGURES | - | - | - | - | 1.0 | +0.0 | 0.0 | 38.3 |
| GUN MASK | - | - | - | - | 1.7 | +3.3 | 0.0 | 0.0 |
| HARD STAY DROPPED | 0.7 | +0.0 | 0.0 | 0.0 | 7.3 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 12.7 | +0.0 | 0.0 | 475.3 | 7.0 | +0.0 | 0.0 | 20.0 |
| HIS CHARGE DENIED | - | - | - | - | 0.3 | +1.1 | 17.3 | 0.0 |
| HIS CHARGE LIST | 12.3 | +0.0 | 0.0 | 281.3 | 5.3 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 2.0 | +0.0 | 0.0 | 238.0 | 2.7 | +0.0 | 0.0 | 20.0 |
| HIS MOVE AND SHOT | 5.7 | -24.5 | 0.0 | 392.0 | 1.7 | -91.9 | 0.0 | 20.0 |
| HIS MOVE AS HE DECIDES | - | - | - | - | 31.7 | +9.7 | 525.3 | 0.0 |
| HIS MOVE WHY | 19.3 | +0.0 | 0.0 | 475.3 | - | - | - | - |
| HIS ONE MOVE | - | - | - | - | 19.0 | +94.1 | 0.0 | 0.0 |
| HIS ONE QUARTER | 2.0 | +0.0 | 0.0 | 0.0 | 4.7 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 3.0 | +0.0 | 0.0 | 259.7 | 2.0 | +0.0 | 0.0 | 20.0 |
| HIS RANDOM MOVE | - | - | - | - | 8.3 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 48.3 | +1307.5 | 0.0 | 1054.0 | 56.3 | +2451.2 | 0.0 | 88.0 |
| HIS SHOTS BY HIS RUN | 43.3 | +737.6 | 0.0 | 962.7 | 36.0 | +1029.3 | 0.0 | 218.0 |
| HIS TURN DENIED | 0.3 | +30.8 | 62.0 | 0.0 | 1.0 | +17.9 | 21.7 | 20.0 |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 40.3 | +0.0 | 0.0 | 781.3 | 10.3 | +0.0 | 0.0 | 0.0 |
| HOLDER ASSIGNMENT | 13.7 | +1481.5 | 0.0 | 201.3 | 7.3 | +971.8 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 0.7 | -15.7 | 62.0 | 17.3 | 1.7 | -38.6 | 31.7 | 20.0 |
| HUNT IN PAIRS | - | - | - | - | 2.0 | +277.3 | 0.0 | 65.0 |
| IDLE COST | 8.7 | -60.1 | 0.0 | 209.3 | 5.0 | -97.8 | 0.0 | 0.0 |
| JOINT CHARGE NOW | - | - | - | - | 0.3 | -19.4 | 0.0 | 0.0 |
| KEEPS SCOUTS OR AMBUSH | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| KEPT FROM ITS LAST STOP | 4.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | - | - | - | - | 0.7 | +18.2 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| LEGAL CHARGES ONLY | 6.3 | +0.0 | 178.0 | 378.0 | 7.0 | +0.0 | 387.7 | 48.0 |
| LONE WIZARD KEPT IN | 2.7 | +247.6 | 0.0 | 0.0 | 0.7 | +60.4 | 0.0 | 0.0 |
| LONG SHOT | 0.3 | -16.6 | 62.0 | 0.0 | - | - | - | - |
| LOST AFTER ESCAPE | 0.7 | +0.2 | 62.0 | 17.3 | 2.3 | -4.6 | 62.0 | 20.0 |
| MAKE SURE TOGETHER | - | - | - | - | 0.3 | +2.4 | 0.0 | 0.0 |
| MANOEUVRE | - | - | - | - | 1.7 | -9.1 | 0.0 | 65.0 |
| MARCH BY THE SUM | 1.3 | +171.3 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | 0.7 | +14.4 | 0.0 | 0.0 | - | - | - | - |
| MARCH OF THE TABLE | 0.3 | +0.4 | 0.0 | 27.0 | - | - | - | - |
| MARCH OVER CASTS | 1.7 | -121.4 | 0.0 | 54.0 | - | - | - | - |
| MARCH WHEELS ONLY | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 3.0 | +49.4 | 0.0 | 90.7 | 1.3 | +39.6 | 0.0 | 0.0 |
| MEETS IN TIME | 3.0 | +105.1 | 0.0 | 0.0 | 7.7 | +68.6 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 6.7 | +370.5 | 0.0 | 181.3 | - | - | - | - |
| MISSILES NEXT TURN | 8.7 | +294.2 | 0.0 | 144.7 | - | - | - | - |
| MISSILES ON ONE TARGET | 3.7 | -105.2 | 0.0 | 0.0 | - | - | - | - |
| MODEL FACING | - | - | - | - | 4.3 | +890.6 | 0.0 | 20.0 |
| MOVE ORDER | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 1.7 | -65.9 | 0.0 | 236.7 | - | - | - | - |
| MOVE SPELL SPOT | 2.3 | +0.0 | 0.0 | 90.7 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 1.0 | +96.5 | 0.0 | 21.7 | 4.0 | +84.1 | 0.0 | 0.0 |
| MOVES UNITS SPELL | 0.3 | +18.4 | 0.0 | 0.0 | - | - | - | - |
| NEARER NOT NEEDED | 5.0 | +206.8 | 0.0 | 21.7 | 11.3 | +506.7 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 1.0 | +114.5 | 0.0 | 0.0 | 1.7 | +46.7 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 0.7 | -19.6 | 62.0 | 17.3 | 2.3 | -34.2 | 66.3 | 20.0 |
| NO LATE CUT | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OFF BEST | 2.3 | -101.5 | 0.0 | 44.3 | 6.7 | -88.0 | 17.3 | 20.0 |
| ONE CHECK AFTER THE LAST CHANGE | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 3.7 | -95.0 | 0.0 | 192.7 | 4.7 | -52.5 | 0.0 | 0.0 |
| ONE JOINT FIGURE | - | - | - | - | 1.0 | +107.0 | 17.3 | 0.0 |
| ONE OBJECTIVE FORMULA | 7.7 | -65.7 | 0.0 | 191.3 | 3.3 | -81.1 | 0.0 | 0.0 |
| ONE ROUTE | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| OVERRUNS AWAY | - | - | - | - | 1.0 | +14.0 | 49.0 | 0.0 |
| PATHS CROSS | - | - | - | - | 0.3 | +8.7 | 0.0 | 0.0 |
| PLAN RESULT | 29.7 | +84.0 | 48.0 | 525.3 | 62.3 | +1011.5 | 946.3 | 418.7 |
| PROMISE BELOW ZERO | 0.3 | +0.0 | 0.0 | 27.0 | - | - | - | - |
| PROMISE BY ITS OWN SUM | 2.0 | +0.0 | 0.0 | 0.0 | 4.7 | -23.2 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | 0.3 | -4.0 | 0.0 | 21.7 | 0.3 | -0.1 | 0.0 | 0.0 |
| PROMISE SHOT AWAY | - | - | - | - | 0.3 | -1.4 | 0.0 | 0.0 |
| QUARTER ODDS | 5.3 | +1010.9 | 0.0 | 0.0 | 18.3 | +799.7 | 73.3 | 308.0 |
| RANDOM MOVE BY FIGURES | 2.0 | +15.6 | 0.0 | 0.0 | - | - | - | - |
| REAL GROUND | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | 2.3 | +85.8 | 0.0 | 56.7 | 2.0 | +43.9 | 0.0 | 24.0 |
| REDIRECT FOR A FRIEND IN REACH | 3.3 | +0.0 | 0.0 | 139.0 | 1.3 | +0.0 | 0.0 | 24.0 |
| REFORMS TO MEET IT | 0.3 | -1.3 | 0.0 | 21.7 | 0.7 | +0.0 | 0.0 | 0.0 |
| REFUSING RETIRES | - | - | - | - | 0.3 | +0.0 | 0.0 | 62.0 |
| RESERVE FALL BACK | - | - | - | - | 0.7 | -2.1 | 0.0 | 0.0 |
| RESERVE MOVE SPELL | 1.3 | +30.9 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | 0.3 | +7.1 | 0.0 | 17.3 | 2.7 | +14.1 | 83.7 | 20.0 |
| RISK ON THE WAY | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ROUNDS AFTER TERROR | - | - | - | - | 0.7 | -11.5 | 21.7 | 0.0 |
| RUN DOWN | 0.7 | -10.3 | 62.0 | 17.3 | 2.3 | -8.5 | 83.7 | 0.0 |
| SCOUT SPOT | 0.7 | +0.4 | 0.0 | 0.0 | 0.7 | -0.1 | 0.0 | 0.0 |
| SCOUT WAITS | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| SEARCH SPOT | - | - | - | - | 0.3 | +8.4 | 0.0 | 0.0 |
| SECOND LOOK | - | - | - | - | 1.0 | +6.3 | 34.7 | 20.0 |
| SET CREDITED ONCE | 3.0 | -56.3 | 0.0 | 142.7 | 4.3 | -407.9 | 0.0 | 0.0 |
| SET UP BY THE SET | 3.0 | +39.6 | 0.0 | 142.7 | 6.0 | +743.0 | 0.0 | 130.0 |
| SET UP TOGETHER | - | - | - | - | 0.3 | +2.4 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | - | - | - | - | 1.7 | +4.0 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 4.0 | +0.0 | 0.0 | 21.7 | 29.0 | +0.0 | 0.0 | 200.7 |
| SHOOTS FROM THE BEST SPOT | 2.0 | +37.4 | 0.0 | 0.0 | 1.7 | +10.5 | 10.0 | 0.0 |
| SHORT GUN FORWARD | - | - | - | - | 2.0 | +0.0 | 0.0 | 0.0 |
| SHOT OR CHARGE | - | - | - | - | 0.3 | -1.1 | 0.0 | 0.0 |
| SHOT RISK POINTS | 31.3 | -485.4 | 0.0 | 750.0 | 41.3 | +605.6 | 0.0 | 170.0 |
| SHOTS AFTER THE MOVES | 1.7 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 5.3 | +140.4 | 0.0 | 43.3 | 49.0 | +698.1 | 0.0 | 224.7 |
| SPELL SETS UP CHARGE | 1.0 | +485.5 | 0.0 | 0.0 | - | - | - | - |
| SPELL WORTH | 1.3 | +3.8 | 130.0 | 0.0 | - | - | - | - |
| SPOT AS THE GAME MOVES | 5.0 | +0.0 | 0.0 | 253.0 | 5.0 | +0.0 | 0.0 | 85.0 |
| STAND AND SHOOT | 0.7 | -15.4 | 62.0 | 17.3 | 0.3 | -1.1 | 21.7 | 0.0 |
| STANDS FOR A REASON | 0.3 | +0.0 | 0.0 | 27.0 | 7.7 | +0.0 | 0.0 | 48.0 |
| STANDS STILL | 20.0 | +0.0 | 192.0 | 183.0 | 104.0 | +0.0 | 2407.0 | 449.3 |
| STAY WORTH | 6.3 | +48.3 | 96.0 | 0.0 | 65.0 | +2.2 | 790.7 | 135.0 |
| SUPPORT ADDS | 7.0 | +424.3 | 0.0 | 115.0 | 2.0 | +25.6 | 0.0 | 0.0 |
| SUPPORT NARROWED | - | - | - | - | 0.3 | +0.0 | 17.3 | 0.0 |
| SUPPORT WORKED OUT | 7.0 | +424.3 | 0.0 | 115.0 | 2.0 | +25.6 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 1.0 | +0.0 | 0.0 | 28.3 | 0.7 | +0.0 | 0.0 | 0.0 |
| THE PROMISE ADDS | - | - | - | - | 0.3 | -12.3 | 0.0 | 0.0 |
| THE PROMISED MOVE | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 1.7 | +0.0 | 0.0 | 45.7 | 1.7 | +0.0 | 0.0 | 20.0 |
| THE ROW KEEPS ITS WAY | 1.3 | +0.0 | 0.0 | 181.3 | 2.0 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 1.3 | +0.0 | 0.0 | 181.3 | 1.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 30.0 | +0.0 | 0.0 | 543.7 | 66.7 | +0.0 | 0.0 | 309.7 |
| TIED UP BY THE SUM | - | - | - | - | 0.3 | +49.1 | 21.7 | 0.0 |
| TIME ON OUR SIDE | 12.3 | +242.2 | 0.0 | 153.3 | 53.7 | +422.4 | 362.7 | 0.0 |
| WAITS AGAIN | 2.0 | +0.0 | 0.0 | 43.3 | 1.0 | +0.0 | 0.0 | 0.0 |
| WHAT THE JOINER ADDS | - | - | - | - | 1.3 | +3.8 | 69.3 | 0.0 |
| WHO FIGHTS | - | - | - | - | 0.3 | -1.5 | 10.0 | 0.0 |
| WHO HITS BACK | 0.3 | +15.5 | 0.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT | - | - | - | - | 0.7 | +3.5 | 34.7 | 0.0 |
| WHOLE FIGHT DANGER | 3.0 | -340.2 | 0.0 | 108.0 | 1.7 | -608.0 | 0.0 | 0.0 |
| WHOLE FIGHT GAIN | - | - | - | - | 0.3 | +28.8 | 0.0 | 0.0 |
| WOUNDS ON THE RANKS | 8.0 | +1393.8 | 0.0 | 362.7 | 0.3 | +0.2 | 0.0 | 0.0 |

### Rule changes: cnomg-c940641-p37

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS SHOT LIST | 314 | 307 | 89 | 29.67 | +896 | +10.1 |
| ARMY TABLE | 103 | 103 | 79 | 26.33 | +605 | +7.7 |
| HIS SHOTS BY HIS RUN | 238 | 233 | 70 | 23.33 | +934 | +13.3 |
| HIS MOVE AS HE DECIDES | 95 | 95 | 66 | 22.00 | +0 | +0.0 |
| HOLDER ASSIGNMENT | 63 | 63 | 61 | 20.33 | +3821 | +62.6 |
| SHOT RISK POINTS | 218 | 211 | 52 | 17.33 | +615 | +11.8 |
| LEGAL CHARGES ONLY | 40 | 40 | 40 | 13.33 | +0 | +0.0 |
| HIS MOVE WHY | 58 | 58 | 39 | 13.00 | +0 | +0.0 |
| DEPLOY BY FIGURES | 57 | 57 | 34 | 11.33 | +500 | +14.7 |
| OFF BEST | 27 | 27 | 27 | 9.00 | -568 | -21.1 |
| GOAL WALK | 40 | 40 | 24 | 8.00 | +4222 | +175.9 |
| HARD STAY DROPPED | 24 | 24 | 24 | 8.00 | +0 | +0.0 |
| TIME ON OUR SIDE | 198 | 188 | 24 | 8.00 | +133 | +5.6 |
| THE TABLE AGAIN | 36 | 36 | 20 | 6.67 | +0 | +0.0 |
| HIS ONE MOVE | 57 | 55 | 18 | 6.00 | +0 | +0.0 |
| FIVE ACTION | 634 | 623 | 16 | 5.33 | +773 | +48.3 |
| WOUNDS ON THE RANKS | 25 | 25 | 15 | 5.00 | +1223 | +81.5 |
| REDIRECT FOR A FRIEND IN REACH | 14 | 14 | 14 | 4.67 | +0 | +0.0 |
| CANNON PLANNED TARGET | 46 | 46 | 13 | 4.33 | -22 | -1.7 |
| CASTING BLOCK | 13 | 13 | 13 | 4.33 | +392 | +30.2 |
| MODEL FACING | 13 | 13 | 13 | 4.33 | +2672 | +205.5 |
| MEETS IN TIME | 32 | 32 | 12 | 4.00 | +122 | +10.1 |
| LONE WIZARD KEPT IN | 10 | 10 | 10 | 3.33 | +924 | +92.4 |
| SUPPORT ADDS | 27 | 27 | 10 | 3.33 | +207 | +20.7 |
| SUPPORT WORKED OUT | 27 | 27 | 10 | 3.33 | +207 | +20.7 |
| CHAFF PASSED | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| SHOOTS FROM THE BEST SPOT | 11 | 11 | 8 | 2.67 | +26 | +3.3 |
| ADVANCE LANE KEPT | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| MOVE TO CHARGE COMPUTED | 15 | 11 | 7 | 2.33 | +159 | +22.7 |
| SET UP BY THE SET | 27 | 26 | 7 | 2.33 | +344 | +49.1 |
| CHARGE LOSSES | 80 | 77 | 6 | 2.00 | +233 | +38.9 |
| FEATURE BUFFS | 49 | 49 | 6 | 2.00 | +39 | +6.5 |
| RANDOM MOVE BY FIGURES | 6 | 6 | 6 | 2.00 | +46 | +7.8 |
| SHORT GUN FORWARD | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| CASTER AWAY FROM SCREEN | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| QUARTER ODDS | 71 | 69 | 5 | 1.67 | +73 | +14.5 |
| SHOOTERS IN TWO RANKS | 5 | 5 | 5 | 1.67 | +12 | +2.4 |
| FALLS SHORT | 87 | 64 | 4 | 1.33 | +93 | +23.2 |
| FOUR ROUNDS | 10 | 7 | 4 | 1.33 | +224 | +55.9 |
| HOLDS AMBUSHERS | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| MARCH BY THE SUM | 4 | 4 | 4 | 1.33 | +514 | +128.5 |
| MAX FOR POSITIONING | 13 | 12 | 4 | 1.33 | +0 | +0.0 |
| NEXT CHARGE BY LIST | 8 | 8 | 4 | 1.33 | +114 | +28.6 |
| PROMISE BY ITS OWN SUM | 20 | 20 | 4 | 1.33 | -70 | -17.4 |
| RESERVE MOVE SPELL | 4 | 4 | 4 | 1.33 | +93 | +23.2 |
| SCOUT WAITS | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| CANNON SIGHT KEPT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| COVER ONCE | 43 | 27 | 3 | 1.00 | +45 | +14.9 |
| FIRE IN ORDER | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| IDLE COST | 41 | 25 | 3 | 1.00 | +38 | +12.7 |
| RISK BY ARC | 9 | 6 | 3 | 1.00 | +29 | +9.6 |
| SECOND LOOK | 3 | 3 | 3 | 1.00 | +19 | +6.3 |
| SHOTS IN THE MOVE | 163 | 133 | 3 | 1.00 | +32 | +10.6 |
| AFTERMATH IN POINTS | 2 | 2 | 2 | 0.67 | +1084 | +542.0 |
| CHALLENGE BY POINTS | 2 | 2 | 2 | 0.67 | +19 | +9.3 |
| CHARGE NOW FIRST | 6 | 6 | 2 | 0.67 | -51 | -25.4 |
| FRIENDS SHOTS CHECKED | 2 | 2 | 2 | 0.67 | -1 | -0.3 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| LANE BY FIGURES | 2 | 2 | 2 | 0.67 | +55 | +27.4 |
| MOVE ORDER | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| NEARER NOT NEEDED | 49 | 48 | 2 | 0.67 | +92 | +46.0 |
| OVERRUNS AWAY | 3 | 2 | 2 | 0.67 | +20 | +10.1 |
| RESERVE FALL BACK | 2 | 2 | 2 | 0.67 | -6 | -3.2 |
| SHOTS AFTER THE MOVES | 18 | 18 | 2 | 0.67 | +0 | +0.0 |
| STAY WORTH | 214 | 204 | 2 | 0.67 | +13 | +6.4 |
| CHAFF IN THE MOVE | 3 | 3 | 1 | 0.33 | +81 | +81.3 |
| COMBAT PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| EXACT ROUND | 7 | 4 | 1 | 0.33 | +2 | +2.5 |
| FALL BACK GOOD ORDER | 8 | 6 | 1 | 0.33 | +18 | +17.6 |
| FOCUS FIRE | 1 | 1 | 1 | 0.33 | +10 | +9.8 |
| HIS MOVE AND SHOT | 22 | 22 | 1 | 0.33 | +0 | +0.0 |
| JOINT CHARGE NOW | 1 | 1 | 1 | 0.33 | -58 | -58.2 |
| MARCH OF THE TABLE | 1 | 1 | 1 | 0.33 | -1 | -1.3 |
| MISSILES IN THE MOVE | 20 | 16 | 1 | 0.33 | +20 | +19.5 |
| MOVES UNITS SPELL | 1 | 1 | 1 | 0.33 | +55 | +55.1 |
| ONE JOINT FIGURE | 3 | 2 | 1 | 0.33 | +144 | +143.5 |
| PATHS CROSS | 1 | 1 | 1 | 0.33 | +26 | +26.2 |
| PROMISE SHOT AWAY | 1 | 1 | 1 | 0.33 | -4 | -4.1 |
| REFUSING RETIRES | 1 | 1 | 1 | 0.33 | -1 | -1.0 |
| SEARCH SPOT | 1 | 1 | 1 | 0.33 | +25 | +25.2 |
| SET CREDITED ONCE | 22 | 21 | 1 | 0.33 | +20 | +20.2 |
| SET UP TOGETHER | 1 | 1 | 1 | 0.33 | +7 | +7.3 |
| SUPPORT NARROWED | 1 | 1 | 1 | 0.33 | -30 | -29.5 |
| THE ROW IN ITS ORDER | 10 | 1 | 1 | 0.33 | +0 | +0.0 |
| TIED UP BY THE SUM | 1 | 1 | 1 | 0.33 | +18 | +17.6 |
| WHO HITS BACK | 1 | 1 | 1 | 0.33 | +29 | +29.0 |
| WHOLE FIGHT | 2 | 1 | 1 | 0.33 | +5 | +5.3 |
| WHOLE FIGHT DANGER | 14 | 14 | 1 | 0.33 | +11 | +11.2 |
| CANNON PLAN MISSED | 2 | 2 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 9 | trace | - | - | - | - |
| CATCH FLIERS | 1 | not checked | - | - | - | - |
| CHARACTER GUNS | 14 | 14 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 49 | 49 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 16 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 1 | 1 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 4 | 3 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 18 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 8 | 8 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 3 | 3 | 0 | 0.00 | - | - |
| GUN FIGURES | 3 | not checked | - | - | - | - |
| GUN MASK | 5 | 5 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 3 | 3 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 59 | 56 | 0 | 0.00 | - | - |
| HIS CHARGE DENIED | 1 | not checked | - | - | - | - |
| HIS CHARGE LIST | 53 | 53 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 14 | 14 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 20 | 19 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 15 | 15 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 25 | 25 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 4 | 3 | 0 | 0.00 | - | - |
| HIS TURN RUN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 152 | 152 | 0 | 0.00 | - | - |
| HONEST WORTH | 7 | 6 | 0 | 0.00 | - | - |
| HUNT IN PAIRS | 6 | 6 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 17 | 17 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 4 | 4 | 0 | 0.00 | - | - |
| LONG SHOT | 1 | 1 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 9 | 6 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 1 | not checked | - | - | - | - |
| MANOEUVRE | 5 | 5 | 0 | 0.00 | - | - |
| MARCH CHECK | 2 | 2 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 5 | 5 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 2 | 2 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 26 | 18 | 0 | 0.00 | - | - |
| MISSILES ON ONE TARGET | 11 | not checked | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 5 | trace | - | - | - | - |
| MOVE SPELL SPOT | 7 | not checked | - | - | - | - |
| NO DOUBLE ROUNDS | 9 | 7 | 0 | 0.00 | - | - |
| NO LATE CUT | 2 | 2 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 18 | 18 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 2 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 25 | 17 | 0 | 0.00 | - | - |
| ONE OBJECTIVE FORMULA | 33 | 23 | 0 | 0.00 | - | - |
| ONE ROUTE | 2 | 2 | 0 | 0.00 | - | - |
| PLAN RESULT | 276 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE KNOWS THE FIGHT | 3 | 1 | 0 | 0.00 | - | - |
| PROMISE READS THE TABLE | 2 | 2 | 0 | 0.00 | - | - |
| REAL GROUND | 2 | 2 | 0 | 0.00 | - | - |
| REDIRECT COUNTER | 13 | 9 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 3 | 2 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 4 | 4 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 2 | 2 | 0 | 0.00 | - | - |
| RUN DOWN | 9 | 7 | 0 | 0.00 | - | - |
| SCOUT SPOT | 4 | 4 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 99 | not checked | - | - | - | - |
| SHOT OR CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 3 | not checked | - | - | - | - |
| SPELL WORTH | 4 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 30 | 28 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 3 | 3 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 24 | 22 | 0 | 0.00 | - | - |
| STANDS STILL | 372 | 369 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 5 | not checked | - | - | - | - |
| THE PROMISE ADDS | 1 | 1 | 0 | 0.00 | - | - |
| THE PROMISED MOVE | 1 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 10 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 7 | not checked | - | - | - | - |
| THE TABLE BINDS | 290 | not checked | - | - | - | - |
| WAITS AGAIN | 9 | 9 | 0 | 0.00 | - | - |
| WHAT THE JOINER ADDS | 4 | 2 | 0 | 0.00 | - | - |
| WHO FIGHTS | 1 | 1 | 0 | 0.00 | - | - |
| WHOLE FIGHT GAIN | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: cnomg-c940641-p37

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 2.00 | 5.33 | 21.1 |
| ARMY TABLE | rule | 1.67 | 1.67 | 78.1 |
| HOLDER ASSIGNMENT | rule | 2.00 | 0.33 | 10.4 |
| PROMISE BY ITS OWN SUM | rule | - | 1.33 | 17.4 |
| CANNON PLANNED TARGET | rule | - | 1.00 | 7.3 |
| RULE SWITCHED OFF | gate | - | 1.00 | 24.3 |
| CHARGE NOW FIRST | rule | - | 0.67 | 25.4 |
| FIGHT ORDER BAND | gate | - | 0.33 | 2.1 |
| JOINT CHARGE NOW | rule | - | 0.33 | 58.2 |
| MARCH OF THE TABLE | rule | 0.33 | - | 1.3 |
| NO REASON | gate | 0.33 | - | 29.1 |
| PROMISE SHOT AWAY | rule | - | 0.33 | 4.1 |
| REFUSING RETIRES | rule | - | 0.33 | 1.0 |
| RESERVE FALL BACK | rule | - | 0.33 | 22.1 |
| SUPPORT NARROWED | rule | - | 0.33 | 29.5 |

### Plans: cnomg-c940641-p37

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 0.3 | 0% | 13 | 0 | 0% |
| Mine | move | 26.0 | 91% | 2833 | 0 | 0% |
| Mine | shoot | 3.3 | 40% | 472 | 84 | 18% |
| Opponent | charge | 2.3 | 86% | 105 | 97 | 92% |
| Opponent | move | 36.7 | 98% | 891 | 0 | 0% |
| Opponent | shoot | 23.3 | 83% | 572 | 915 | 160% |

### Battle groups: cnomg-c940641-p37

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 2.3 | 43% | 33% | 0% | - | 33% | 0% | 0% | 67% | 0% |
| Opponent | REDIRECT COUNTER | 2.0 | 0% | - | - | - | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: cnomg-c940641-p37

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 4 | 0 (4) | 0 | 0 | 100 | 25% | 3.3 | 0 (2) | - | 0 (2) | 0 (3) | 0 (1) |
| Mine | Character | 15 | 13 (15) | 13 | 0 | 23 | 33% | 3.3 | - | 9 (9) | 0 (2) | 4 (8) | 14 (3) |
| Mine | Clean-up | 3 | 0 (3) | 0 | 0 | 100 | 33% | 3.5 | 0 (1) | 0 (2) | - | 0 (3) | - |
| Mine | Fast Hammer | 2 | 0 (2) | 0 | 0 | 100 | 100% | - | 0 (2) | - | - | 0 (1) | 0 (1) |
| Mine | Hammer | 6 | 72 (6) | 11 | 62 | 37 | 67% | 4.5 | 0 (1) | 109 (3) | 34 (2) | 69 (4) | 78 (2) |
| Mine | Holder | 5 | 0 (5) | 0 | 0 | 0 | 60% | 3.5 | 0 (4) | - | 0 (1) | 0 (2) | 0 (3) |
| Mine | Shooter | 2 | 77 (2) | 0 | 77 | 50 | 0% | 1.0 | - | 154 (1) | 0 (1) | 77 (2) | - |
| Mine | Wizard | 3 | 0 (3) | 0 | 0 | 22 | 33% | 2.0 | - | - | - | - | - |
| Opponent | Chaff | 2 | 0 (2) | 0 | 0 | 50 | 0% | 1.5 | 0 (1) | 0 (1) | - | 0 (2) | - |
| Opponent | Character | 8 | 88 (8) | 88 | 0 | 0 | 50% | 2.2 | 212 (1) | 91 (5) | 0 (2) | 88 (3) | 88 (5) |
| Opponent | Clean-up | 6 | 7 (6) | 7 | 0 | 0 | 17% | 2.6 | 0 (1) | 11 (5) | - | 10 (5) | 0 (1) |
| Opponent | Fast Hammer | 4 | 10 (4) | 10 | 0 | 34 | 50% | 1.5 | 0 (1) | 0 (1) | 21 (2) | 12 (3) | 0 (1) |
| Opponent | Hammer | 3 | 30 (3) | 30 | 0 | 0 | 67% | 3.0 | 0 (1) | 208 (1) | 0 (1) | 104 (2) | 0 (1) |
| Opponent | Holder | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | - | - | - | - |
| Opponent | Shooter | 10 | 103 (10) | 19 | 84 | 19 | 10% | 2.1 | 174 (2) | 96 (8) | - | 141 (8) | 0 (2) |
| Opponent | War machine | 12 | 7 (12) | 7 | 0 | 9 | 8% | 2.0 | 8 (10) | - | 0 (2) | 0 (2) | 8 (10) |
| Opponent | Wizard | 2 | 0 (2) | 0 | 0 | 0 | 0% | 1.0 | - | 0 (2) | - | - | 0 (2) |

### Charged fights: cnomg-c940641-p37

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 3 | 109 | 62 | 0.7 | 1.0 | 93 | 0 | +93 | 1 of 2 | 2 of 2 | - | +93 |
| Opponent | Dwarfen Mountain Holds | 2 | 330 | 52 | 2.5 | 1.0 | 21 | 0 | +21 | 1 of 5 | 2 of 5 | - | +21 |
| Opponent | Tomb Kings of Khemri | 1 | 55 | 1017 | 2.0 | 1.0 | 508 | 0 | +508 | 1 of 2 | 1 of 2 | - | +508 |
| **Opponent** | all armies | 3 | 238 | 374 | 2.3 | 1.0 | 160 | 0 | +160 | 2 of 7 | 3 of 7 | - | +160 |

### Effective charges: cnomg-c940641-p37

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 2 | 0 | 0 | 0 | 1 (net +0) | 0 | 1 (net +186) | 0 | 0% (0 of 2) |
| Opponent | Dwarfen Mountain Holds | 5 | 0 | 0 | 1 (net +0) | 1 (net +0) | 0 | 1 (net +52) | 2 | 33% (1 of 3) |
| Opponent | Tomb Kings of Khemri | 2 | 1 (net +952) | 0 | 0 | 0 | 1 (net +65) | 0 | 0 | 0% (0 of 2) |

### Charged fights, damage counted: cnomg-c940641-p37

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 76-89% | 1 | 52 | 105 | +0 | 0 | 0 | +0 | +0.0 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 322 | 186 | +186 | 186 | 0 | +186 | +57.8 |
| Mine | All fights | 2 | 187 | 146 | +93 | 93 | 0 | +93 | +49.7 |
| Opponent | Long shot (under 50%) | 1 | 411 | 322 | +952 | 952 | 91 | +861 | +209.4 |
| Opponent | Effective (55-75%) | 1 | 60 | 55 | +0 | 282 | 0 | +282 | +469.6 |
| Opponent | 76-89% | 1 | 60 | 30 | +0 | 24 | 0 | +24 | +40.0 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 50 | 52 | +52 | 52 | 0 | +52 | +104.0 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 431 | 65 | +65 | 65 | 96 | -31 | -7.1 |
| Opponent | No odds | 2 | 55 | 187 | +26 | 26 | 0 | +26 | +47.3 |
| Opponent | All fights | 7 | 160 | 128 | +160 | 204 | 27 | +177 | +110.5 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| cnomg-c940641-p37 | move | 14 | 0 (0%) | 0 (0%) | 2 (14%) | 12 (86%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0106, L0122 |
| Ring of Doom | Mine | L0206 |

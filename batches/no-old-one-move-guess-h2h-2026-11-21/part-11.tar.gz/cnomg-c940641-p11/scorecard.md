# Doctrine scorecard: cnomg-c940641-p11

### Scorecard: cnomg-c940641-p11

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L2127 | 3 | 1 | Mine | yes | 1 | - | 0 | 3 | 0 | 0 | 0 | 555 |
| L2127 | 3 | 1 | Opponent | no | 0 | 2 | 4 | 2 | 0 | 0 | 0 | 0 |
| L2231 | 5 | 1 | Mine | yes | - | 4 | 6 | 0 | 0 | 0 | 0 | 242 |
| L2231 | 5 | 1 | Opponent | no | - | - | 1 | 2 | 2 | 0 | 0 | 170 |
| L2335 | 1 | 1 | Mine | no | 0 | 2 | 3 | 3 | 1 | 0 | 0 | 72 |
| L2335 | 1 | 1 | Opponent | no | 1 | 1 | 1 | 3 | 1 | 0 | 0 | 0 |
| **Average** | | | Mine | 67% | 0.5 | 3.0 | 3.0 | 2.0 | 0.3 | 0.0 | 0.0 | 289.7 |
| **Average** | | | Opponent | 0% | 0.5 | 1.5 | 2.0 | 2.3 | 1.0 | 0.0 | 0.0 | 56.7 |

### KPIs: cnomg-c940641-p11

Rules off - Mine only: NO OLD ONE-MOVE GUESS.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 8% (1 of 13) | 0% (0 of 14) | 4% (1 of 27) |
| Winner chose to follow up after the loser gave ground |  | 100% (4 of 4); on the table 100% | 100% (3 of 3); on the table 100% | 100% (7 of 7); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | 0% (0 of 1); on the table 0% | - | 0% (0 of 1); on the table 0% |
| Winner chose to pursue after the loser fled |  | 0% (0 of 1); on the table 0% | - | 0% (0 of 1); on the table 0% |
| Winner chose to follow up or pursue (all three) |  | 67% (4 of 6); on the table 67% | 100% (3 of 3); on the table 100% | 78% (7 of 9); on the table 78% |
| Magic missiles tried each own turn | 50%+ | 33% (2 of 6) | 33% (6 of 18) | 33% (8 of 24) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 40% (2 of 5) | 33% (6 of 18) | 35% (8 of 23) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 50% (3 of 6) | 50% (4 of 8) | 50% (7 of 14) |
| Points that never fought | lower | 53% (3150 of 5999) | 44% (2652 of 6000) | 48% (5802 of 11999) |
|   infantry points that never fought | lower | 94% (1460 of 1552) | 66% (680 of 1035) | 83% (2140 of 2587) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 63% (12 of 19) | 63% (19 of 30) | 63% (31 of 49) |
| Bound items with a magic missile used (at least once a game) |  | 100% (1 of 1); 1.0 uses a game | 50% (1 of 2); 0.7 uses a game | 67% (2 of 3); 0.8 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
|   their share of the points of units over 100 pts | lower | 57% (2547 of 4484) | 52% (2858 of 5546) | 54% (5405 of 10030) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 0.3 (25%) | 3.0 (75%) | 3.3 (62%) |
| MARCHED: its unit marched | 0.7 (50%) | 1.0 (25%) | 1.7 (31%) |
| GONE: slain | 0.3 (25%) | 0.0 (0%) | 0.3 (6%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 11.7 | 1.3 | 1.3 | 2.7 | 0.3 | 0.0 |
| not cast | 2.3 | 0.7 | 0.7 | 5.3 | 1.7 | 16.0 |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.7 (100%) | 0.0 (0%) | 3.3 (62%) | 0.0 (0%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.7 (31%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (2%) |
| GONE: slain | 0.3 (14%) | 0.0 (0%) | 0.0 (0%) | 0.3 (6%) | 0.0 (0%) | 1.0 (6%) |
| STUPIDITY: Stupidity | 0.3 (14%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.7 (100%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.7 (71%) | 0.0 (0%) | 0.7 (100%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 14.7 (92%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.0 a game | 1.3 a game | 0.7 a game |
| stood (cast and not dispelled) | - | 0% (0 of 4) | 0% (0 of 4) |
| the unit moved after it | - | - | - |
| it charged on its next turn | - | - | - |
| the enemy charged it first | - | - | - |
| it fought by the end of its next turn | - | - | - |
| it moved out of a charge the enemy had planned (not charged first) | - | - | - |
| none of these (no charge, no fight, no charge escaped) | - | - | - |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 69% (73 of 106) | 80% (24 of 30) | 71% (97 of 136) |
|   cavalry | 100% (15 of 15) | 82% (14 of 17) | 91% (29 of 32) |
|   character | 0% (0 of 17) | 0% (0 of 1) | 0% (0 of 18) |
|   chariot | 90% (9 of 10) | - | 90% (9 of 10) |
|   infantry | 77% (49 of 64) | 83% (10 of 12) | 78% (59 of 76) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 0.3 (3%) | 1.3 (67%) | 1.7 (13%) |
| CHARGED: it charged | 3.0 (27%) | 0.3 (17%) | 3.3 (26%) |
| IN COMBAT: it fought this turn or the last | 0.0 (0%) | 0.3 (17%) | 0.3 (3%) |
| NO TARGET IN RANGE | 5.3 (48%) | 0.0 (0%) | 5.3 (41%) |
| ONLY IN COMBAT: the only targets were in combat | 0.3 (3%) | 0.0 (0%) | 0.3 (3%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 2.0 (18%) | 0.0 (0%) | 2.0 (15%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 14.3 | 2.3 | 84% | 5.2 pts | 75 pts |
| chariot | 3.0 | 0.7 | 78% | 3.5 pts | 10 pts |
| infantry | 21.7 | 9.7 | 72% | 9.9 pts | 215 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.7 | 3.3 | 4.0 |
| Charges that made contact a game | 3.0 | 2.0 | 2.5 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.00 declared, 0.00 contact (1 units) | 0.00 declared, 0.00 contact (2 units) | 0.00 declared, 0.00 contact (3 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 1.00 declared, 0.50 contact (2 units) | 1.00 declared, 0.50 contact (2 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.44 declared, 0.28 contact (32 units) | 0.35 declared, 0.22 contact (23 units) | 0.40 declared, 0.25 contact (55 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 43% (3 of 7) | 100% (1 of 1) | 0% (0 of 1) | 44% (4 of 9) |
| Character in a unit | 100% (6 of 6) | 0% (0 of 1) | 100% (1 of 1) | 88% (7 of 8) |
| Character on its own | 100% (2 of 2) | - | 29% (2 of 7) | 44% (4 of 9) |
| Chariot | 50% (1 of 2) | - | - | 50% (1 of 2) |
| Infantry | 64% (7 of 11) | 0% (0 of 1) | - | 58% (7 of 12) |
| Monster | 83% (5 of 6) | 100% (1 of 1) | - | 86% (6 of 7) |
| Monstrous | 100% (2 of 2) | - | - | 100% (2 of 2) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Skaven | 1 | 100% (1 of 1); on the table 100% | 33% (2 of 6) | 54% | 67% (6 of 9) | 100% (1 of 1); 3.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Tomb Kings of Khemri | 2 | 60% (3 of 5); on the table 60% | - | 52% | 60% (6 of 10) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 1 | - | 67% (4 of 6) | 54% | 33% (2 of 6) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 1 | - | 0% (0 of 6) | 26% | 92% (11 of 12) | 100% (1 of 1); 2.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 1 | 100% (3 of 3); on the table 100% | 33% (2 of 6) | 52% | 50% (6 of 12) | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (cnomg-c940641-p11, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 0% (0) | 50% (4) | 31% (4) |
| ...free all their last turn and able to turn (per game) | 0.00 | 0.67 | 0.67 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.67 | 0.67 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.67 | 0.67 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.33 | 0.33 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.33 | 0.33 |

### Quality by phase: cnomg-c940641-p11

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.0 | 4.0 |
| Strategy | Charge objectives carried out (made contact) | 43% (6 of 14) | 18% (2 of 11) |
| Strategy | Shoot objectives carried out (shot that target) | 27% (6 of 22) | 10% (1 of 10) |
| Strategy | Support requests answered (helper made contact too) | 0% (0 of 2) | 0% (0 of 3) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | - | 100% (1 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | - | 100% (3 of 3) |
| Strategy | Joined characters whose unit fought | 0% (0 of 5) | 57% (4 of 7) |
| Strategy | Lone characters that fought | 100% (5 of 5) | 33% (2 of 6) |
| Movement | Charges halted short of contact | 0.3 | 0.0 |
| Movement | Idle units | 2.0 | 2.3 |
| Movement | Points that never moved of their own | 289.7 | 56.7 |
| Movement | Fights charged into per game | 3.0 | 2.0 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 9 | 1 of 5, net +0 |
| Movement | Charges with odds: sweet spot (55-75%) | 1 of 9, net -41 | 1 of 5, net +210 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 4 of 9, net +54 | 1 of 5, net +66 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 of 9, net +85 | 1 of 5, net +540 |
| Shooting | Shots by shooting units (incl. breath weapons) | 25.7 | 9.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 21% (16 of 77) | 56% (15 of 27) |
| Shooting | Points destroyed by shooting units | 239.7 | 113.3 |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | 0.3 | 1.7 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 0% (0 of 1) | 40% (2 of 5) |
| Magic | Wounds caused by magic missiles | 0.3 | 1.3 |
| Magic | Points destroyed by magic (all spells) | 0.0 | 65.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 6.7 / 0.0 / 0.0 / 0.0 | 2.3 / 1.0 / 0.0 / 0.3 |
| Combat | Points destroyed in combat | 185.3 | 524.3 |
| Combat | Points run down | 0.0 | 0.0 |
| Combat | Net points per charged fight, damage counted | +20 | +95 |
| Combat | Net per 100 charger points, damage counted | +5.8 | +34.4 |
| Combat | First round won (charged fights) | 78% | 50% |
| Combat | Net points per charged fight | -22 | +132 |
| Combat | Net points per supported fight / lone fight | - / -22 | - / +132 |
| Combat | Charged fights on a top-3 enemy unit | 2 of 9 | 3 of 6 |
| Game | Points lost | 649.7 | 391.7 |
| Game | VP from objectives | 1073.3 | 613.3 |
| Game | Lone holders (player turns) | 0.5 | 0.5 |

- Mine won / drew / lost: 2 / 0 / 1 of 3 ended games (of 3); mean margin (Mine - Opponent) +198 VP
- The side that went first won 1 of 3 games with a winner
- Points traded per game (both sides' losses): 1041
- Games not ended: 0; findings 1, warnings 0

### Opponent rules: cnomg-c940641-p11

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| ARMY TABLE | 36.7 | +956.1 | 0.0 | 513.7 | 24.7 | +483.9 | 0.0 | 0.0 |
| BACKUP TARGETS | 0.3 | +10.2 | 0.0 | 65.0 | - | - | - | - |
| BEST OVERALL | - | - | - | - | 0.3 | +2.0 | 0.0 | 0.0 |
| CAST JOB | - | - | - | - | 2.0 | +5.4 | 24.0 | 0.0 |
| CASTER AWAY FROM SCREEN | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| CHAFF PASSED | - | - | - | - | 0.3 | -0.1 | 0.0 | 0.0 |
| CHALLENGE BY POINTS | - | - | - | - | 0.7 | +6.1 | 0.0 | 0.0 |
| CHARACTER GUNS | 4.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHARGE LOSSES | 14.7 | -744.6 | 0.0 | 1060.0 | 23.7 | -1412.6 | 0.0 | 569.3 |
| CHARGE NOW FIRST | 3.3 | +0.0 | 562.0 | 180.0 | 1.7 | +0.0 | 298.3 | 0.0 |
| CLOSES ON WHAT IT BEATS | 9.7 | +0.0 | 0.0 | 13.7 | 13.3 | +0.0 | 0.0 | 0.0 |
| COMBAT PIVOT | 1.0 | +0.0 | 0.0 | 250.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | - | - | - | - | 1.3 | +73.5 | 0.0 | 0.0 |
| COVER ONCE | 9.7 | -498.1 | 0.0 | 310.0 | 11.0 | -474.4 | 0.0 | 0.0 |
| DENIED BY THE FIGHT | 0.3 | -0.2 | 0.0 | 0.0 | 1.0 | -5.0 | 180.0 | 15.0 |
| DEPLOY BY FIGURES | 8.0 | +21.9 | 0.0 | 48.3 | 7.7 | +21.5 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | 0.3 | -0.8 | 0.0 | 0.0 | - | - | - | - |
| EVASIVE BY THE ODDS | - | - | - | - | 3.0 | +89.5 | 0.0 | 399.3 |
| EXACT ROUND | 3.7 | +221.0 | 162.7 | 180.0 | 3.3 | +11.6 | 320.3 | 15.0 |
| FALL BACK GOOD ORDER | 3.7 | +29.1 | 124.7 | 180.0 | 3.7 | +0.3 | 320.3 | 15.0 |
| FALLBACK BY WORTH | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| FALLS SHORT | 4.0 | +25.6 | 0.0 | 22.0 | 22.3 | +259.3 | 0.0 | 237.7 |
| FEATURE BUFFS | 0.7 | +38.9 | 0.0 | 0.0 | 1.7 | +81.6 | 0.0 | 0.0 |
| FIGHT TO THE END | 0.7 | +3.7 | 0.0 | 180.0 | 0.3 | +0.0 | 48.3 | 0.0 |
| FIRE IN ORDER | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FIVE ACTION | 112.0 | +10204.6 | 2491.0 | 1781.7 | 91.3 | +4678.2 | 409.3 | 778.3 |
| FLANK NOT WEIGHED | 8.3 | +0.0 | 0.0 | 582.3 | 7.7 | +0.0 | 0.0 | 0.0 |
| FOCUS FIRE | 0.3 | +35.1 | 0.0 | 0.0 | - | - | - | - |
| FOLLOW UP WEIGHED | 1.3 | +101.4 | 0.0 | 180.0 | 0.3 | +127.7 | 0.0 | 0.0 |
| FOUR ROUNDS | 4.7 | +740.7 | 162.7 | 180.0 | 3.7 | +217.3 | 320.3 | 15.0 |
| FREED FROM HIS FIGHT | 2.7 | +0.0 | 0.0 | 48.3 | 4.7 | +0.0 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | - | - | - | - | 1.0 | -8.2 | 0.0 | 0.0 |
| FRIENDS SHOTS CHECKED | 0.3 | +25.2 | 0.0 | 0.0 | 0.7 | +63.8 | 0.0 | 0.0 |
| GIVES UP | 0.3 | -3.3 | 0.0 | 0.0 | - | - | - | - |
| GOAL WALK | 14.3 | +1623.9 | 0.0 | 0.0 | 6.3 | +272.3 | 0.0 | 0.0 |
| GUN FIGURES | 2.0 | +12.6 | 40.0 | 0.0 | - | - | - | - |
| HARD STAY DROPPED | 4.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 2.0 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 8.7 | +0.0 | 0.0 | 1060.0 | 13.3 | +0.0 | 0.0 | 512.7 |
| HIS CHARGE DENIED | - | - | - | - | 0.3 | +14.0 | 0.0 | 0.0 |
| HIS CHARGE LIST | 4.7 | +0.0 | 0.0 | 27.3 | 3.7 | +0.0 | 0.0 | 68.0 |
| HIS LEGAL MOVES | 5.3 | +0.0 | 0.0 | 245.0 | 5.0 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 4.0 | -36.8 | 0.0 | 260.0 | 6.0 | -121.6 | 0.0 | 399.3 |
| HIS MOVE AS HE DECIDES | 47.3 | +13.0 | 389.7 | 0.0 | - | - | - | - |
| HIS MOVE WHY | - | - | - | - | 10.0 | +0.0 | 0.0 | 0.0 |
| HIS ONE MOVE | 24.3 | -14.8 | 0.0 | 585.0 | - | - | - | - |
| HIS ONE QUARTER | 9.0 | +0.0 | 0.0 | 27.3 | 6.0 | +0.0 | 0.0 | 50.0 |
| HIS OWN BEST MOVE | 3.3 | +0.0 | 0.0 | 245.0 | 11.0 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVE | 17.0 | +0.0 | 0.0 | 48.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVER COMES | 4.0 | +0.0 | 0.0 | 48.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 48.0 | +736.0 | 0.0 | 713.7 | 52.0 | +1266.2 | 0.0 | 630.7 |
| HIS SHOTS BY HIS RUN | 33.0 | +386.3 | 0.0 | 612.0 | 64.3 | +1140.2 | 0.0 | 687.3 |
| HIS TURN DENIED | 0.7 | +5.7 | 38.0 | 0.0 | 1.3 | +7.0 | 0.0 | 15.0 |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 20.3 | +0.0 | 0.0 | 44.0 | 14.7 | +0.0 | 0.0 | 0.0 |
| HOLDER ASSIGNMENT | 14.0 | +1053.5 | 0.0 | 22.0 | 9.0 | +815.6 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 1.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 4.0 | -136.0 | 162.7 | 180.0 | 2.7 | -95.7 | 320.3 | 0.0 |
| HUNT IN PAIRS | 0.7 | +0.9 | 0.0 | 65.0 | - | - | - | - |
| IDLE COST | 3.0 | -48.1 | 0.0 | 65.0 | 18.3 | -171.0 | 0.0 | 233.7 |
| JOINT CHARGE NOW | 1.0 | -54.0 | 0.0 | 180.0 | 2.0 | +212.8 | 0.0 | 15.0 |
| KEPT FROM ITS LAST STOP | 1.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 1.3 | +48.6 | 0.0 | 0.0 | 0.7 | +0.4 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 10.0 | +0.0 | 655.7 | 204.0 | 6.7 | +0.0 | 687.0 | 38.0 |
| LONE WIZARD KEPT IN | 1.3 | +77.2 | 0.0 | 0.0 | - | - | - | - |
| LONG SHOT | - | - | - | - | 0.7 | +1.4 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | 2.0 | +13.0 | 0.0 | 180.0 | 1.3 | +4.0 | 48.3 | 0.0 |
| MAKE SURE TOGETHER | - | - | - | - | 0.7 | +1.4 | 0.0 | 0.0 |
| MANOEUVRE | 1.3 | -2.5 | 0.0 | 0.0 | 2.3 | +16.9 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.3 | +1.1 | 0.0 | 0.0 | 1.0 | +1.1 | 0.0 | 0.0 |
| MARCH OF THE TABLE | 0.3 | +0.0 | 0.0 | 180.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| MARCH OVER CASTS | 0.7 | +10.5 | 0.0 | 180.0 | 0.3 | +172.3 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MAX FOR POSITIONING | 1.0 | +3.1 | 0.0 | 65.0 | 2.3 | +38.4 | 0.0 | 0.0 |
| MEETS IN TIME | 4.3 | +147.4 | 0.0 | 48.3 | 4.3 | +410.5 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 2.7 | +53.1 | 0.0 | 360.0 | 4.3 | +72.5 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 3.3 | +32.8 | 0.0 | 360.0 | 6.7 | +77.7 | 0.0 | 0.0 |
| MOVE ORDER | 3.0 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 0.0 |
| MOVE SPELL OUT OF RANGE | - | - | - | - | 1.3 | -34.5 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 9.7 | +1269.8 | 0.0 | 520.0 | 8.7 | +721.1 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 15.3 | +611.5 | 0.0 | 46.0 | 8.0 | +342.3 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 7.3 | +1112.4 | 0.0 | 390.0 | 7.3 | +651.5 | 0.0 | 0.0 |
| NEXT OBJECTIVE NEARER | 0.3 | -4.8 | 0.0 | 0.0 | - | - | - | - |
| NO DOUBLE ROUNDS | 4.3 | -284.7 | 128.7 | 180.0 | 1.3 | -293.8 | 228.3 | 0.0 |
| NO LATE CUT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NO OLD ONE-MOVE GUESS | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 0.3 | -0.2 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 3.3 | -64.1 | 0.0 | 87.0 | 6.0 | -145.0 | 0.0 | 0.0 |
| ONE CHECK AFTER THE LAST CHANGE | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 3.3 | -67.4 | 0.0 | 130.0 | 7.0 | -120.3 | 0.0 | 199.7 |
| ONE JOINT FIGURE | - | - | - | - | 1.0 | +20.6 | 0.0 | 15.0 |
| ONE OBJECTIVE FORMULA | 8.0 | +29.8 | 0.0 | 22.0 | 4.3 | -39.3 | 0.0 | 0.0 |
| ONE ROUTE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| OPENS UP | 1.0 | +78.5 | 72.0 | 0.0 | 0.3 | +15.7 | 22.0 | 0.0 |
| OVERRUNS AWAY | 1.0 | +11.4 | 38.0 | 0.0 | 0.7 | +53.1 | 118.3 | 0.0 |
| PATHS CROSS | 0.7 | +2.1 | 0.0 | 0.0 | 0.3 | +3.2 | 0.0 | 0.0 |
| PLAN RESULT | 50.3 | +370.0 | 1252.3 | 1292.0 | 47.7 | +288.0 | 584.0 | 650.3 |
| PROMISE BELOW ZERO | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE BY ITS OWN SUM | 9.7 | -233.3 | 0.0 | 0.0 | 8.7 | -87.5 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | - | - | - | - | 0.7 | -6.3 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | - | - | - | - | 0.7 | -35.3 | 0.0 | 0.0 |
| PROMISE SHOT AWAY | 0.3 | -0.8 | 0.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | 27.3 | +2185.1 | 113.0 | 517.3 | 25.7 | +2585.3 | 245.0 | 50.0 |
| RANDOM MOVE BY FIGURES | 2.0 | +53.5 | 0.0 | 215.0 | 2.7 | +47.1 | 0.0 | 170.0 |
| REAL GROUND | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| REDIRECT COUNTER | 3.0 | +67.8 | 0.0 | 59.7 | 0.7 | +19.4 | 0.0 | 0.0 |
| REDIRECT FOR A FRIEND IN REACH | 6.3 | +0.0 | 0.0 | 59.7 | 2.7 | +0.0 | 0.0 | 40.0 |
| REDIRECT WEIGHED | 1.0 | +30.5 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| REFORMS TO MEET IT | 2.3 | -57.1 | 0.0 | 130.0 | 0.7 | -2.4 | 0.0 | 0.0 |
| RESERVE FALL BACK | 1.0 | -2.0 | 0.0 | 24.0 | 0.3 | +117.4 | 0.0 | 0.0 |
| RISK BY ARC | 4.0 | -19.5 | 162.7 | 180.0 | 2.0 | -78.7 | 298.3 | 15.0 |
| ROUNDS AFTER TERROR | 1.7 | -56.1 | 38.0 | 0.0 | 1.3 | -20.4 | 0.0 | 0.0 |
| RUN DOWN | 3.3 | -129.5 | 38.0 | 180.0 | 1.7 | -10.0 | 48.3 | 0.0 |
| SAFER THAN THE JOB | - | - | - | - | 0.3 | +2.0 | 0.0 | 0.0 |
| SCOUT SPOT | 1.3 | +1.1 | 0.0 | 22.0 | - | - | - | - |
| SCOUT WAITS | 1.3 | +0.0 | 0.0 | 22.0 | - | - | - | - |
| SEARCH SPOT | 0.7 | +0.6 | 0.0 | 0.0 | - | - | - | - |
| SET CREDITED ONCE | 0.7 | -17.4 | 0.0 | 0.0 | 2.3 | -95.0 | 0.0 | 0.0 |
| SET UP BY THE SET | 1.3 | +44.1 | 0.0 | 0.0 | 4.3 | +42.3 | 0.0 | 0.0 |
| SET UP TOGETHER | - | - | - | - | 0.7 | +1.4 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.7 | +3.0 | 0.0 | 0.0 | 0.3 | +0.3 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 8.3 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 38.0 |
| SHOOTS FROM THE BEST SPOT | 3.0 | +54.7 | 25.0 | 180.0 | 1.0 | +46.4 | 0.0 | 38.0 |
| SHOT OR CHARGE | 1.3 | -6.8 | 0.0 | 0.0 | - | - | - | - |
| SHOT RISK POINTS | 24.3 | -247.8 | 0.0 | 542.0 | 34.3 | -224.4 | 0.0 | 687.3 |
| SHOTS AFTER THE MOVES | 4.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 22.3 | +1127.8 | 0.0 | 46.0 | 7.7 | +114.0 | 0.0 | 38.0 |
| SPELL WORTH | 1.3 | +32.6 | 360.0 | 360.0 | 3.7 | +6.8 | 0.0 | 0.0 |
| SPELLS IN THE FIGHT | - | - | - | - | 0.3 | -20.1 | 0.0 | 15.0 |
| SPOT AS THE GAME MOVES | 6.3 | +0.0 | 0.0 | 228.3 | 11.3 | +0.0 | 0.0 | 185.0 |
| STAND AND SHOOT | 0.7 | -2.0 | 0.0 | 180.0 | 0.3 | -0.5 | 22.0 | 0.0 |
| STANDS FOR A REASON | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 49.7 | +0.0 | 2328.3 | 500.7 | 29.0 | +0.0 | 89.0 | 126.0 |
| STAY WORTH | 22.7 | +595.6 | 1767.3 | 0.0 | 8.3 | +28.8 | 24.0 | 0.0 |
| STRIKE BY THE ODDS | 0.7 | +335.6 | 0.0 | 0.0 | - | - | - | - |
| STUCK PIVOT | - | - | - | - | 0.7 | +0.0 | 0.0 | 56.7 |
| STUPIDITY NEXT TURN | - | - | - | - | 1.7 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 6.7 | +295.0 | 0.0 | 41.0 | 6.0 | +749.7 | 0.0 | 0.0 |
| SUPPORT NARROWED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| SUPPORT WORKED OUT | 6.7 | +295.0 | 0.0 | 41.0 | 6.0 | +749.7 | 0.0 | 0.0 |
| SURE REACH TOGETHER | - | - | - | - | 0.7 | +1.5 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 2.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| THE PROMISE ADDS | - | - | - | - | 1.3 | -57.2 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 2.7 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 2.7 | +0.0 | 0.0 | 0.0 | 5.0 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 1.7 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 52.3 | +0.0 | 0.0 | 693.3 | 46.7 | +0.0 | 0.0 | 296.7 |
| TIED UP BY THE SUM | 2.0 | +283.3 | 162.7 | 0.0 | 0.3 | +41.7 | 22.0 | 0.0 |
| TIME ON OUR SIDE | 51.0 | +415.8 | 226.7 | 755.7 | 5.3 | +41.7 | 0.0 | 0.0 |
| WAITS AGAIN | 2.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| WHO FIGHTS | 1.3 | +117.5 | 0.0 | 0.0 | 0.7 | +28.1 | 118.3 | 0.0 |
| WHO HITS BACK | - | - | - | - | 0.3 | +10.8 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | 3.7 | -433.6 | 0.0 | 540.0 | 3.3 | -762.5 | 0.0 | 56.7 |
| WHOLE FIGHT GAIN | - | - | - | - | 1.0 | +11.0 | 0.0 | 0.0 |
| WOUNDS ON THE RANKS | - | - | - | - | 6.3 | +145.4 | 0.0 | 0.0 |

### Rule changes: cnomg-c940641-p11

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 184 | 184 | 134 | 44.67 | +4146 | +30.9 |
| HIS MOVE AS HE DECIDES | 142 | 142 | 103 | 34.33 | +0 | +0.0 |
| HOLDER ASSIGNMENT | 69 | 69 | 63 | 21.00 | +4160 | +66.0 |
| HIS SHOT LIST | 300 | 288 | 56 | 18.67 | +484 | +8.6 |
| HIS SHOTS BY HIS RUN | 292 | 281 | 54 | 18.00 | +442 | +8.2 |
| LEGAL CHARGES ONLY | 50 | 50 | 50 | 16.67 | +0 | +0.0 |
| THE TABLE AGAIN | 36 | 36 | 32 | 10.67 | +0 | +0.0 |
| FIVE ACTION | 610 | 589 | 31 | 10.33 | +1766 | +57.0 |
| MOVE TO CHARGE COMPUTED | 55 | 50 | 29 | 9.67 | +1870 | +64.5 |
| OFF BEST | 28 | 28 | 28 | 9.33 | -627 | -22.4 |
| REDIRECT FOR A FRIEND IN REACH | 27 | 27 | 27 | 9.00 | +0 | +0.0 |
| DEPLOY BY FIGURES | 47 | 47 | 26 | 8.67 | +299 | +11.5 |
| HIS MOVE WHY | 30 | 30 | 21 | 7.00 | +0 | +0.0 |
| MOVE ORDER | 20 | 20 | 20 | 6.67 | +0 | +0.0 |
| NEXT CHARGE BY LIST | 44 | 41 | 20 | 6.67 | +1635 | +81.8 |
| HIS ONE MOVE | 73 | 69 | 18 | 6.00 | +0 | +0.0 |
| GOAL WALK | 62 | 58 | 17 | 5.67 | +1254 | +73.8 |
| PROMISE BY ITS OWN SUM | 55 | 55 | 17 | 5.67 | -963 | -56.6 |
| SHOT RISK POINTS | 176 | 170 | 17 | 5.67 | +121 | +7.1 |
| TIME ON OUR SIDE | 169 | 148 | 16 | 5.33 | +25 | +1.6 |
| HARD STAY DROPPED | 15 | 15 | 15 | 5.00 | +0 | +0.0 |
| QUARTER ODDS | 159 | 154 | 14 | 4.67 | +524 | +37.5 |
| FOUR ROUNDS | 25 | 25 | 13 | 4.33 | +820 | +63.0 |
| MEETS IN TIME | 26 | 26 | 13 | 4.33 | +1082 | +83.3 |
| SUPPORT ADDS | 38 | 38 | 13 | 4.33 | +865 | +66.5 |
| SUPPORT WORKED OUT | 38 | 38 | 13 | 4.33 | +865 | +66.5 |
| CHARGE LOSSES | 115 | 111 | 11 | 3.67 | +1834 | +166.7 |
| COVER ONCE | 62 | 41 | 10 | 3.33 | +88 | +8.8 |
| ADVANCE LANE KEPT | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| JOINT CHARGE NOW | 9 | 9 | 9 | 3.00 | +477 | +53.0 |
| SHOOTS FROM THE BEST SPOT | 12 | 12 | 9 | 3.00 | +52 | +5.8 |
| HOLDS AMBUSHERS | 8 | 8 | 8 | 2.67 | +0 | +0.0 |
| RANDOM MOVE BY FIGURES | 14 | 14 | 7 | 2.33 | +302 | +43.1 |
| TIED UP BY THE SUM | 7 | 7 | 7 | 2.33 | +291 | +41.5 |
| LANE BY FIGURES | 6 | 6 | 6 | 2.00 | +147 | +24.5 |
| COMBAT PIVOT | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| EVASIVE BY THE ODDS | 9 | 9 | 5 | 1.67 | +237 | +47.4 |
| FOLLOW UP WEIGHED | 5 | 5 | 5 | 1.67 | +687 | +137.4 |
| REDIRECT WEIGHED | 5 | 5 | 5 | 1.67 | +188 | +37.6 |
| SHOTS IN THE MOVE | 90 | 75 | 5 | 1.67 | +57 | +11.4 |
| IDLE COST | 64 | 40 | 4 | 1.33 | +13 | +3.2 |
| LONE WIZARD KEPT IN | 4 | 4 | 4 | 1.33 | +232 | +57.9 |
| MAX FOR POSITIONING | 10 | 9 | 4 | 1.33 | +2 | +0.6 |
| OPENS UP | 4 | 4 | 4 | 1.33 | +147 | +36.7 |
| RESERVE FALL BACK | 4 | 4 | 4 | 1.33 | +346 | +86.6 |
| SCOUT WAITS | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| WHOLE FIGHT DANGER | 21 | 21 | 4 | 1.33 | +630 | +157.6 |
| CHARGE NOW FIRST | 15 | 15 | 3 | 1.00 | -221 | -73.6 |
| FALLS SHORT | 79 | 67 | 3 | 1.00 | +27 | +9.1 |
| FRIENDS SHOTS CHECKED | 3 | 3 | 3 | 1.00 | +267 | +89.1 |
| PATHS CROSS | 3 | 3 | 3 | 1.00 | +16 | +5.4 |
| SHOOTERS IN TWO RANKS | 3 | 3 | 3 | 1.00 | +10 | +3.3 |
| WOUNDS ON THE RANKS | 19 | 19 | 3 | 1.00 | +11 | +3.6 |
| CAST JOB | 6 | 6 | 2 | 0.67 | +3 | +1.3 |
| CASTS FROM BEHIND | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| CHALLENGE BY POINTS | 2 | 2 | 2 | 0.67 | +18 | +9.2 |
| EXACT ROUND | 21 | 21 | 2 | 0.67 | +312 | +156.0 |
| FALL BACK GOOD ORDER | 22 | 22 | 2 | 0.67 | +7 | +3.5 |
| FIRE IN ORDER | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| MANOEUVRE | 11 | 11 | 2 | 0.67 | +51 | +25.4 |
| MARCH OF THE TABLE | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| MISSILES IN THE MOVE | 21 | 14 | 2 | 0.67 | +15 | +7.7 |
| OVERRUNS AWAY | 5 | 5 | 2 | 0.67 | +35 | +17.4 |
| PROMISE KNOWS THE FIGHT | 2 | 2 | 2 | 0.67 | -19 | -9.5 |
| SET UP BY THE SET | 17 | 17 | 2 | 0.67 | -29 | -14.6 |
| STAY WORTH | 93 | 88 | 2 | 0.67 | +18 | +8.9 |
| STUCK PIVOT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| THE ROW IN ITS ORDER | 15 | 2 | 2 | 0.67 | +0 | +0.0 |
| BEST OVERALL | 1 | 1 | 1 | 0.33 | +6 | +5.9 |
| CASTER AWAY FROM SCREEN | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CHAFF PASSED | 1 | 1 | 1 | 0.33 | -0 | -0.2 |
| FEATURE BUFFS | 7 | 7 | 1 | 0.33 | +69 | +69.4 |
| FOCUS FIRE | 1 | 1 | 1 | 0.33 | +105 | +105.2 |
| HIS CHARGE DENIED | 1 | 1 | 1 | 0.33 | +41 | +40.7 |
| HIS TURN DENIED | 6 | 6 | 1 | 0.33 | +15 | +15.4 |
| HONEST WORTH | 20 | 20 | 1 | 0.33 | +5 | +5.0 |
| NEARER NOT NEEDED | 70 | 66 | 1 | 0.33 | +21 | +20.6 |
| ONE OBJECTIVE FORMULA | 37 | 26 | 1 | 0.33 | +18 | +17.8 |
| PROMISE SHOT AWAY | 1 | 1 | 1 | 0.33 | -2 | -2.4 |
| RISK BY ARC | 18 | 18 | 1 | 0.33 | +30 | +30.2 |
| SAFER THAN THE JOB | 1 | 1 | 1 | 0.33 | +6 | +5.9 |
| SEARCH SPOT | 2 | 2 | 1 | 0.33 | +2 | +1.9 |
| SHOTS AFTER THE MOVES | 18 | 18 | 1 | 0.33 | +0 | +0.0 |
| STRIKE BY THE ODDS | 2 | 2 | 1 | 0.33 | +309 | +308.6 |
| SUPPORT NARROWED | 1 | 1 | 1 | 0.33 | -13 | -12.9 |
| SURE REACH TOGETHER | 2 | 2 | 1 | 0.33 | +0 | +0.0 |
| WHO FIGHTS | 6 | 6 | 1 | 0.33 | +11 | +10.7 |
| WHO HITS BACK | 1 | 1 | 1 | 0.33 | +32 | +32.3 |
| WHOLE FIGHT GAIN | 3 | 3 | 1 | 0.33 | +7 | +7.4 |
| BACKUP TARGETS | 1 | 1 | 0 | 0.00 | - | - |
| CHARACTER GUNS | 12 | 10 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 69 | 68 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 4 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 4 | 4 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 1 | 1 | 0 | 0.00 | - | - |
| FALLBACK BY WORTH | 1 | 1 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 3 | 3 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 48 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 22 | 22 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 3 | 3 | 0 | 0.00 | - | - |
| GIVES UP | 1 | 1 | 0 | 0.00 | - | - |
| GUN FIGURES | 6 | not checked | - | - | - | - |
| HE REFORMS ONCE FREED | 12 | 12 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 66 | 64 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 25 | 25 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 31 | 29 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 30 | 28 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 45 | 45 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 43 | 42 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 69 | 69 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 17 | 17 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN RUN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 105 | 105 | 0 | 0.00 | - | - |
| HUNT IN PAIRS | 2 | not checked | - | - | - | - |
| KEPT FROM ITS LAST STOP | 5 | 5 | 0 | 0.00 | - | - |
| LONG SHOT | 2 | 2 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 10 | 10 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 2 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 4 | trace | - | - | - | - |
| MARCH OVER CASTS | 3 | 3 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 1 | 1 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 30 | 19 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 4 | trace | - | - | - | - |
| NEXT OBJECTIVE NEARER | 1 | 1 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 17 | 17 | 0 | 0.00 | - | - |
| NO LATE CUT | 1 | 1 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 18 | 18 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT TURNED | 1 | 1 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 1 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 3 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 31 | 17 | 0 | 0.00 | - | - |
| ONE JOINT FIGURE | 3 | 3 | 0 | 0.00 | - | - |
| ONE ROUTE | 1 | 1 | 0 | 0.00 | - | - |
| PLAN RESULT | 294 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 2 | 2 | 0 | 0.00 | - | - |
| PROMISE READS THE TABLE | 2 | 2 | 0 | 0.00 | - | - |
| REAL GROUND | 1 | 1 | 0 | 0.00 | - | - |
| REDIRECT COUNTER | 11 | 10 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 9 | 9 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 9 | 9 | 0 | 0.00 | - | - |
| RUN DOWN | 15 | 15 | 0 | 0.00 | - | - |
| SCOUT SPOT | 4 | 4 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 9 | 9 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 2 | 1 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 37 | not checked | - | - | - | - |
| SHOT OR CHARGE | 4 | 4 | 0 | 0.00 | - | - |
| SPELL WORTH | 15 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 53 | 47 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 3 | 3 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 4 | 2 | 0 | 0.00 | - | - |
| STANDS STILL | 236 | 229 | 0 | 0.00 | - | - |
| STUPIDITY NEXT TURN | 5 | 5 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 8 | not checked | - | - | - | - |
| THE PROMISE ADDS | 4 | 4 | 0 | 0.00 | - | - |
| THE ROW KEEPS ITS WAY | 23 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 16 | not checked | - | - | - | - |
| THE TABLE BINDS | 297 | not checked | - | - | - | - |
| WAITS AGAIN | 11 | 11 | 0 | 0.00 | - | - |

### Off best figure: cnomg-c940641-p11

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 2.00 | 4.67 | 16.4 |
| ARMY TABLE | rule | 3.67 | 2.33 | 74.5 |
| PROMISE BY ITS OWN SUM | rule | 3.33 | 2.33 | 56.6 |
| HOLDER ASSIGNMENT | rule | 1.33 | 0.33 | 17.8 |
| JOINT CHARGE NOW | rule | 0.33 | 1.00 | 79.1 |
| RULE SWITCHED OFF | gate | 1.33 | - | 23.8 |
| CHARGE NOW FIRST | rule | 1.00 | - | 73.6 |
| NO REASON | gate | - | 1.00 | 66.1 |
| PROMISE KNOWS THE FIGHT | rule | - | 0.67 | 9.5 |
| AFTERMATH BAND | gate | - | 0.33 | 4.8 |
| PROMISE SHOT AWAY | rule | 0.33 | - | 2.4 |
| RESERVE FALL BACK | rule | 0.33 | - | 24.5 |
| SET UP BY THE SET | rule | - | 0.33 | 38.3 |
| SUPPORT NARROWED | rule | - | 0.33 | 12.9 |

### Plans: cnomg-c940641-p11

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 3.3 | 60% | 873 | 286 | 33% |
| Mine | move | 40.7 | 94% | 2547 | 0 | 0% |
| Mine | shoot | 6.3 | 32% | 997 | 84 | 8% |
| Opponent | charge | 2.3 | 57% | 494 | 250 | 51% |
| Opponent | join | 5.3 | 94% | 226 | 0 | 0% |
| Opponent | move | 37.0 | 95% | 1777 | 0 | 0% |
| Opponent | shoot | 3.0 | 33% | 93 | 38 | 40% |

### Battle groups: cnomg-c940641-p11

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 3.0 | 33% | 67% | 33% | 0% | 100% | 0% | 0% | 0% | 0% |
| Opponent | REDIRECT COUNTER | 0.7 | 50% | 100% | 0% | - | 100% | 0% | 0% | 0% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: cnomg-c940641-p11

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | 0 (1) | - | - | - | 0 (1) |
| Mine | Chaff | 6 | 60 (6) | 0 | 60 | 34 | 17% | 1.0 | - | 69 (5) | 0 (1) | 69 (5) | 0 (1) |
| Mine | Character | 7 | 23 (7) | 23 | 0 | 45 | 14% | 2.7 | 40 (2) | 0 (3) | 25 (2) | 32 (4) | 0 (3) |
| Mine | Clean-up | 1 | 293 (1) | 0 | 293 | 100 | 0% | 3.0 | - | 293 (1) | - | - | 293 (1) |
| Mine | Fast Hammer | 6 | 0 (6) | 0 | 0 | 42 | 83% | 6.0 | 0 (4) | 0 (2) | - | - | 0 (6) |
| Mine | Hammer | 5 | 122 (5) | 82 | 40 | 55 | 20% | 1.5 | 29 (3) | 236 (2) | - | 50 (2) | 155 (3) |
| Mine | Holder | 8 | 67 (8) | 0 | 67 | 0 | 25% | 2.5 | 245 (2) | 13 (6) | - | 245 (2) | 13 (6) |
| Mine | Shooter | 5 | 71 (5) | 29 | 43 | 0 | 0% | 1.6 | 0 (2) | 162 (3) | - | 51 (4) | 185 (1) |
| Mine | Wizard | 3 | 0 (3) | 0 | 0 | 0 | 0% | 1.0 | 0 (2) | 0 (1) | - | 0 (2) | 0 (1) |
| Opponent | Chaff | 4 | 75 (4) | 0 | 75 | 50 | 75% | 3.0 | 100 (3) | - | 0 (1) | 100 (3) | 0 (1) |
| Opponent | Character | 11 | 56 (11) | 56 | 0 | 25 | 36% | 4.1 | 81 (2) | 41 (8) | 71 (1) | 47 (7) | 77 (4) |
| Opponent | Fast Hammer | 6 | 54 (6) | 44 | 10 | 0 | 17% | 2.8 | - | 41 (5) | 142 (1) | 46 (3) | 59 (3) |
| Opponent | Hammer | 8 | 7 (8) | 7 | 0 | 43 | 38% | 4.2 | 0 (3) | 11 (5) | - | 9 (6) | 0 (2) |
| Opponent | Holder | 3 | 0 (3) | 0 | 0 | 0 | 67% | 4.0 | 0 (1) | 0 (2) | - | 0 (1) | 0 (2) |
| Opponent | Shooter | 3 | 66 (3) | 0 | 66 | 31 | 0% | 1.0 | - | 47 (2) | 109 (1) | 72 (2) | 53 (1) |
| Opponent | Support | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | - | 0 (1) | - | 0 (1) |
| Opponent | Wizard | 2 | 0 (2) | 0 | 0 | 0 | 0% | 1.0 | 0 (1) | - | 0 (1) | 0 (1) | 0 (1) |

### Charged fights: cnomg-c940641-p11

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Skaven | 1 | 120 | 0 | 1.0 | 1.0 | 0 | 41 | -41 | 0 of 1 | 0 of 1 | - | -41 |
| Mine | Tomb Kings of Khemri | 2 | 300 | 193 | 4.0 | 1.0 | 48 | 68 | -19 | 2 of 8 | 7 of 8 | - | -19 |
| **Mine** | all armies | 3 | 240 | 129 | 3.0 | 1.0 | 43 | 65 | -22 | 2 of 9 | 7 of 9 | - | -22 |
| Opponent | Vampire Counts | 1 | 145 | 895 | 4.0 | 1.0 | 224 | 0 | +224 | 2 of 4 | 2 of 4 | - | +224 |
| Opponent | Warriors of Chaos | 1 | 0 | 0 | 1.0 | 1.0 | 0 | 170 | -170 | 1 of 1 | 0 of 1 | - | -170 |
| Opponent | Wood Elf Realms | 1 | 390 | 66 | 1.0 | 1.0 | 66 | 0 | +66 | 0 of 1 | 1 of 1 | - | +66 |
| **Opponent** | all armies | 3 | 178 | 320 | 2.0 | 1.0 | 160 | 28 | +132 | 3 of 6 | 3 of 6 | - | +132 |

### Effective charges: cnomg-c940641-p11

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Skaven | 1 | 0 | 0 | 1 (net -41) | 0 | 0 | 0 | 0 | 100% (1 of 1) |
| Mine | Tomb Kings of Khemri | 8 | 0 | 1 (net -540) | 0 | 1 (net +0) | 4 (net +54) | 2 (net +85) | 0 | 0% (0 of 8) |
| Opponent | Vampire Counts | 4 | 1 (net +0) | 0 | 1 (net +210) | 1 (net +145) | 0 | 1 (net +540) | 0 | 25% (1 of 4) |
| Opponent | Wood Elf Realms | 1 | 0 | 0 | 0 | 0 | 1 (net +66) | 0 | 0 | 0% (0 of 1) |

### Charged fights, damage counted: cnomg-c940641-p11

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 50-54% | 1 | 440 | 499 | -540 | 480 | 702 | -222 | -50.5 |
| Mine | Effective (55-75%) | 1 | 41 | 75 | -41 | 52 | 41 | +12 | +28.0 |
| Mine | 76-89% | 1 | 431 | 201 | +0 | 78 | 144 | -65 | -15.1 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 250 | 140 | +85 | 137 | 23 | +114 | +45.4 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 4 | 431 | 111 | +54 | 70 | 12 | +58 | +13.4 |
| Mine | All fights | 9 | 349 | 166 | -22 | 129 | 109 | +20 | +5.8 |
| Opponent | Long shot (under 50%) | 1 | 186 | 92 | +0 | 18 | 31 | -13 | -6.8 |
| Opponent | Effective (55-75%) | 1 | 186 | 210 | +210 | 210 | 62 | +148 | +79.6 |
| Opponent | 76-89% | 1 | 186 | 145 | +145 | 145 | 0 | +145 | +78.0 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 471 | 440 | +540 | 540 | 0 | +540 | +114.6 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 499 | 66 | +66 | 66 | 0 | +66 | +13.2 |
| Opponent | No odds | 1 | 120 | 411 | -170 | 0 | 319 | -319 | -266.1 |
| Opponent | All fights | 6 | 275 | 227 | +132 | 163 | 69 | +95 | +34.4 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| cnomg-c940641-p11 | move | 22 | 4 (18%) | 3 (14%) | 3 (14%) | 15 (68%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L2127 |
| Invocation of Nehek | Opponent | L2127 |
| Periapt of Soul Exchange | Mine | L2127 |
| Ring of Doom | Opponent | L2231 |
| Storm Daemon (Renegade 2.0) | Mine | L2127 |

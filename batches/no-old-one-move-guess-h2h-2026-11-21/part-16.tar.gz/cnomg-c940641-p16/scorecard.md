# Doctrine scorecard: cnomg-c940641-p16

### Scorecard: cnomg-c940641-p16

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0528 | 6 | 1 | Mine | no | 2 | - | 0 | 2 | 0 | 0 | 0 | 335 |
| L0528 | 6 | 1 | Opponent | no | 9 | - | 0 | 2 | 0 | 0 | 0 | 0 |
| L0616 | 4 | 1 | Mine | no | 0 | - | 1 | 3 | 0 | 0 | 0 | 848 |
| L0616 | 4 | 1 | Opponent | no | 4 | - | 0 | 0 | 1 | 0 | 0 | 200 |
| L0632 | 2 | 1 | Mine | - | - | 4 | 3 | 2 | 0 | 0 | 0 | 500 |
| L0632 | 2 | 1 | Opponent | - | - | 3 | 1 | 5 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 0% | 1.0 | 4.0 | 1.3 | 2.3 | 0.0 | 0.0 | 0.0 | 561.0 |
| **Average** | | | Opponent | 0% | 6.5 | 3.0 | 0.3 | 2.3 | 0.3 | 0.0 | 0.0 | 66.7 |

### KPIs: cnomg-c940641-p16

Rules off - Mine only: NO OLD ONE-MOVE GUESS.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 100% (13 of 13) | 0% (0 of 10) | 57% (13 of 23) |
| Winner chose to follow up after the loser gave ground |  | 100% (1 of 1); on the table 100% | 100% (2 of 2); on the table 100% | 100% (3 of 3); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | - | 100% (1 of 1); on the table 100% | 100% (1 of 1); on the table 100% |
| Winner chose to pursue after the loser fled |  | - | 100% (2 of 2); on the table 100% | 100% (2 of 2); on the table 100% |
| Winner chose to follow up or pursue (all three) |  | 100% (1 of 1); on the table 100% | 100% (5 of 5); on the table 100% | 100% (6 of 6); on the table 100% |
| Magic missiles tried each own turn | 50%+ | - | 0% (0 of 6) | 0% (0 of 6) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | - | 0% (0 of 6) | 0% (0 of 6) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 67% (8 of 12) | 67% (8 of 12) |
| Points that never fought | lower | 86% (5156 of 6000) | 78% (4668 of 5999) | 82% (9824 of 11999) |
|   infantry points that never fought | lower | 81% (1813 of 2232) | 70% (506 of 720) | 79% (2319 of 2952) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 78% (21 of 27) | 76% (16 of 21) | 77% (37 of 48) |
| Bound items with a magic missile used (at least once a game) |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0.0 uses a game | 100% (1 of 1); 0.3 uses a game | 100% (1 of 1); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 71% (2989 of 4232) | 69% (3744 of 5415) | 70% (6733 of 9647) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | - | 1.7 (83%) | 1.7 (83%) |
| MARCHED: its unit marched | - | 0.3 (17%) | 0.3 (17%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Magic missiles | Assailments |
| --- | --- | --- | --- | --- |
| tried | 0.3 | 0.0 | 0.0 | 0.0 |
| not cast | 3.7 | 2.0 | 2.0 | 4.0 |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 2.0 (100%) | 1.7 (83%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.3 (17%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 1.7 (45%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.0 (55%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 4.0 (100%) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 61% (120 of 198) | 61% (20 of 33) | 61% (140 of 231) |
|   cavalry | 47% (9 of 19) | 70% (7 of 10) | 55% (16 of 29) |
|   character | 64% (16 of 25) | 0% (0 of 6) | 52% (16 of 31) |
|   infantry | 46% (22 of 48) | 20% (1 of 5) | 43% (23 of 53) |
|   monster | 75% (9 of 12) | - | 75% (9 of 12) |
|   war machine | 68% (64 of 94) | 100% (12 of 12) | 72% (76 of 106) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 6.3 (24%) | 1.0 (23%) | 7.3 (24%) |
| CHARGED: it charged | 1.7 (6%) | 0.3 (8%) | 2.0 (7%) |
| IN COMBAT: it fought this turn or the last | 0.7 (3%) | 0.0 (0%) | 0.7 (2%) |
| NO TARGET IN RANGE | 7.3 (28%) | 1.7 (38%) | 9.0 (30%) |
| ONLY IN COMBAT: the only targets were in combat | 0.3 (1%) | 0.0 (0%) | 0.3 (1%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 6.3 (24%) | 1.3 (31%) | 7.7 (25%) |
| SHELTERED: the target was sheltered | 2.0 (8%) | 0.0 (0%) | 2.0 (7%) |
| OTHER BAR | 1.3 (5%) | 0.0 (0%) | 1.3 (4%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 6.0 | 1.0 | 83% | 5.7 pts | 34 pts |
| character | 5.3 | 4.7 | 62% | 16.7 pts | 89 pts |
| infantry | 15.3 | 2.7 | 85% | 3.9 pts | 59 pts |
| monster | 3.0 | 0.0 | 100% | 0.0 pts | 0 pts |
| war machine | 25.3 | 14.0 | 62% | 20.8 pts | 527 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 2.7 | 1.7 | 2.2 |
| Charges that made contact a game | 2.7 | 0.7 | 1.7 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | - | - | - |
|   per unit a game, units carrying another wizard (or one alone) | - | - | - |
|   per unit a game, the other units (no war machines, no joined characters) | 0.38 declared, 0.38 contact (21 units) | 0.25 declared, 0.10 contact (20 units) | 0.32 declared, 0.24 contact (41 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 100% (4 of 4) | - | 50% (1 of 2) | 83% (5 of 6) |
| Character in a unit | 100% (7 of 7) | 67% (2 of 3) | 100% (1 of 1) | 91% (10 of 11) |
| Character on its own | - | 50% (1 of 2) | 67% (2 of 3) | 60% (3 of 5) |
| Infantry | 71% (5 of 7) | 33% (2 of 6) | - | 54% (7 of 13) |
| Monster | 75% (3 of 4) | - | - | 75% (3 of 4) |
| Monstrous | 100% (1 of 1) | - | - | 100% (1 of 1) |
| War Machines | 100% (8 of 8) | - | - | 100% (8 of 8) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Dwarfen Mountain Holds | 3 | 100% (1 of 1); on the table 100% | - | 86% | 78% (21 of 27) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | 100% (2 of 2); on the table 100% | - | 85% | 50% (3 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Warriors of Chaos | 2 | 100% (3 of 3); on the table 100% | 0% (0 of 6) | 74% | 87% (13 of 15) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (cnomg-c940641-p16, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | - | 100% (6) | 100% (6) |
| ...free all their last turn and able to turn (per game) | 0.00 | 1.67 | 1.67 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.33 | 0.33 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 1.00 | 1.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.33 | 0.33 |

### Quality by phase: cnomg-c940641-p16

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.3 | 1.3 |
| Strategy | Charge objectives carried out (made contact) | 100% (8 of 8) | 20% (1 of 5) |
| Strategy | Shoot objectives carried out (shot that target) | 58% (51 of 88) | 40% (6 of 15) |
| Strategy | Support requests answered (helper made contact too) | - | 0% (0 of 1) |
| Strategy | Joined characters whose unit fought | 0% (0 of 11) | 0% (0 of 5) |
| Strategy | Lone characters that fought | 50% (1 of 2) | 20% (1 of 5) |
| Movement | Charges halted short of contact | 0.0 | 0.3 |
| Movement | Idle units | 2.3 | 2.3 |
| Movement | Points that never moved of their own | 561.0 | 66.7 |
| Movement | Fights charged into per game | 2.3 | 0.7 |
| Movement | Charges with odds: long shots (under 50%) | 1 of 7, net +0 | - |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 7 | - |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 7 | - |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 of 7, net +46 | - |
| Shooting | Shots by shooting units (incl. breath weapons) | 20.7 | 5.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 65% (40 of 62) | 7% (1 of 15) |
| Shooting | Points destroyed by shooting units | 207.7 | 0.0 |
| Shooting | War machine shots | 21.3 | 4.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 75% (48 of 64) | 42% (5 of 12) |
| Shooting | Points destroyed by war machines | 46.3 | 71.7 |
| Magic | Points destroyed by magic (all spells) | 0.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.0 / 0.0 / 0.0 / 0.0 | 0.3 / 0.0 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 45.7 | 31.7 |
| Combat | Points run down | 0.0 | 77.7 |
| Combat | Net points per charged fight, damage counted | +91 | +190 |
| Combat | Net per 100 charger points, damage counted | +118.5 | +54.1 |
| Combat | First round won (charged fights) | 86% | 100% |
| Combat | Net points per charged fight | +31 | +139 |
| Combat | Net points per supported fight / lone fight | +137 / +13 | - / +139 |
| Combat | Charged fights on a top-3 enemy unit | 0 of 7 | 2 of 2 |
| Game | Points lost | 242.0 | 329.7 |
| Game | VP from objectives | 530.0 | 416.7 |
| Game | Lone holders (player turns) | 1.0 | 6.5 |

- Mine won / drew / lost: 1 / 2 / 0 of 3 ended games (of 3); mean margin (Mine - Opponent) +292 VP
- The side that went first won 0 of 1 games with a winner
- Points traded per game (both sides' losses): 572
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: cnomg-c940641-p16

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.7 | +16.8 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | 7.3 | -79.3 | 0.0 | 0.0 | 20.0 | +418.3 | 0.0 | 283.0 |
| ARTILLERY RE-ROLL WEIGHED | 4.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| BACKUP TARGETS | 0.3 | +3.9 | 0.0 | 0.0 | - | - | - | - |
| BLOWS WHERE AIMED | - | - | - | - | 0.3 | -68.5 | 61.0 | 0.0 |
| CANNON PLAN MISSED | 2.3 | +0.0 | 508.3 | 0.0 | - | - | - | - |
| CANNON PLANNED TARGET | 21.3 | +593.4 | 1680.3 | 33.3 | 4.0 | +184.1 | 110.0 | 0.0 |
| CANNON SIGHT KEPT | 3.0 | +0.0 | 0.0 | 38.3 | - | - | - | - |
| CHAFF IN THE MOVE | - | - | - | - | 3.0 | +57.2 | 0.0 | 36.7 |
| CHAFF PASSED | 1.3 | -1.5 | 0.0 | 0.0 | - | - | - | - |
| CHALLENGE BY POINTS | 0.7 | +32.6 | 0.0 | 61.0 | - | - | - | - |
| CHARACTER GUNS | 4.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHARGE LOSSES | 6.7 | -107.0 | 0.0 | 0.0 | 21.7 | -1178.0 | 0.0 | 960.0 |
| CHARGE NOW FIRST | 1.0 | +0.0 | 72.3 | 0.0 | 0.3 | +0.0 | 77.7 | 0.0 |
| CLOSES ON WHAT IT BEATS | 8.7 | +0.0 | 0.0 | 0.0 | 7.3 | +0.0 | 0.0 | 45.7 |
| COMBAT PIVOT | - | - | - | - | 0.3 | +0.0 | 61.0 | 0.0 |
| COVER ONCE | 5.7 | -566.1 | 0.0 | 0.0 | 5.3 | -219.9 | 0.0 | 45.7 |
| DEFENSIVE ARMY | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| DENIED BY THE FIGHT | 0.3 | -0.7 | 26.7 | 0.0 | - | - | - | - |
| DEPLOY BY FIGURES | 13.0 | -157.2 | 0.0 | 38.3 | 6.0 | +73.0 | 0.0 | 0.0 |
| EXACT ROUND | 2.3 | +23.9 | 91.3 | 0.0 | 1.0 | -9.6 | 138.7 | 0.0 |
| FALL BACK GOOD ORDER | 2.7 | +15.5 | 118.0 | 0.0 | - | - | - | - |
| FALLS SHORT | - | - | - | - | 20.3 | +145.8 | 0.0 | 404.7 |
| FEATURE BUFFS | 1.3 | +18.3 | 0.0 | 0.0 | - | - | - | - |
| FIGHT TO THE END | 1.0 | +0.8 | 26.7 | 0.0 | 0.3 | +14.1 | 61.0 | 0.0 |
| FIRE AND FLEE | 0.3 | +2.5 | 0.0 | 0.0 | - | - | - | - |
| FIRE IN ORDER | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FIVE ACTION | 135.3 | +6443.3 | 4209.7 | 222.0 | 73.7 | +2198.2 | 436.3 | 1259.0 |
| FLANK NOT WEIGHED | 1.7 | +0.0 | 0.0 | 77.7 | 6.3 | +0.0 | 0.0 | 45.7 |
| FOLLOW UP WEIGHED | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +107.7 | 0.0 | 0.0 |
| FOUR ROUNDS | 2.7 | +86.8 | 118.0 | 0.0 | 1.7 | +36.0 | 216.3 | 0.0 |
| FREED FROM HIS FIGHT | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FRIEND SHOOTS FIRST | 0.7 | -36.5 | 0.0 | 0.0 | - | - | - | - |
| GIVES UP | - | - | - | - | 0.7 | -1.3 | 61.0 | 0.0 |
| GOAL WALK | 3.7 | +132.9 | 0.0 | 0.0 | 13.3 | +944.8 | 0.0 | 0.0 |
| GUN FIGURES | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| GUN MASK | 3.0 | +212.2 | 0.0 | 0.0 | 2.0 | +75.9 | 0.0 | 0.0 |
| HARD STAY DROPPED | 5.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HELPER UNSEEN | - | - | - | - | 0.3 | +0.0 | 77.7 | 0.0 |
| HIS CHARGE BY HIS RUN | 3.7 | +0.0 | 0.0 | 0.0 | 13.0 | +0.0 | 0.0 | 886.0 |
| HIS CHARGE DENIED | - | - | - | - | 0.7 | +43.8 | 77.7 | 0.0 |
| HIS CHARGE LIST | 6.3 | +0.0 | 0.0 | 0.0 | 18.7 | +0.0 | 0.0 | 589.3 |
| HIS LEGAL MOVES | 4.0 | +0.0 | 0.0 | 77.7 | 3.7 | +0.0 | 0.0 | 157.0 |
| HIS MOVE AND SHOT | 2.0 | -22.7 | 0.0 | 0.0 | 5.3 | -49.0 | 0.0 | 700.3 |
| HIS MOVE AS HE DECIDES | 33.7 | +6.3 | 652.3 | 0.0 | - | - | - | - |
| HIS MOVE WHY | - | - | - | - | 31.7 | +0.0 | 0.0 | 596.7 |
| HIS ONE MOVE | 17.7 | -41.1 | 0.0 | 0.0 | - | - | - | - |
| HIS ONE QUARTER | 2.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 2.7 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 157.0 |
| HIS RANDOM MOVE | 17.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 26.7 | +686.6 | 0.0 | 0.0 | 56.7 | +4641.0 | 0.0 | 1205.7 |
| HIS SHOTS BY HIS RUN | 20.0 | +276.2 | 0.0 | 155.3 | 49.0 | +1459.4 | 0.0 | 1114.3 |
| HIS TURN DENIED | 0.3 | +2.9 | 26.7 | 0.0 | - | - | - | - |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 14.0 | +0.0 | 0.0 | 155.3 | 12.3 | +0.0 | 0.0 | 258.0 |
| HOLDER ASSIGNMENT | 10.0 | +1155.2 | 0.0 | 77.7 | 7.7 | +718.6 | 0.0 | 175.3 |
| HOLDS AMBUSHERS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 1.7 | -17.9 | 72.3 | 0.0 | 1.3 | -72.5 | 138.7 | 0.0 |
| IDLE COST | - | - | - | - | 17.0 | -334.9 | 0.0 | 221.3 |
| JOINT CHARGE NOW | 0.3 | -21.2 | 45.7 | 0.0 | 0.7 | +222.1 | 155.3 | 0.0 |
| KEEPS SCOUTS OR AMBUSH | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 5.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 46.3 |
| LANE BY FIGURES | - | - | - | - | 1.3 | +77.7 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 2.3 | +0.0 | 0.0 | 61.0 | 2.7 | +0.0 | 61.0 | 99.7 |
| LONE WIZARD KEPT IN | - | - | - | - | 0.3 | +25.0 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | 2.0 | +1.0 | 26.7 | 0.0 | 0.3 | -5.1 | 61.0 | 0.0 |
| MAKE SURE TOGETHER | - | - | - | - | 0.3 | +0.2 | 0.0 | 0.0 |
| MANOEUVRE | 1.3 | -25.9 | 0.0 | 77.7 | 2.0 | +19.8 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 2.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 0.3 | +4.9 | 0.0 | 0.0 | 1.3 | +10.2 | 0.0 | 0.0 |
| MEETS IN TIME | 6.0 | +54.8 | 0.0 | 0.0 | 3.0 | +184.7 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | - | - | - | - | 0.3 | +0.5 | 0.0 | 0.0 |
| MISSILES NEXT TURN | - | - | - | - | 1.7 | +4.3 | 0.0 | 0.0 |
| MODEL FACING | 4.7 | +1570.7 | 0.0 | 0.0 | - | - | - | - |
| MOVE ORDER | 2.7 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 46.3 | 45.7 |
| MOVE TO CHARGE COMPUTED | 5.3 | +181.8 | 0.0 | 0.0 | 1.3 | +68.3 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 3.7 | +185.7 | 0.0 | 0.0 | 4.0 | +278.1 | 0.0 | 91.3 |
| NEXT CHARGE BY LIST | 1.0 | +50.9 | 0.0 | 0.0 | 1.3 | +68.3 | 0.0 | 0.0 |
| NEXT OBJECTIVE NEARER | - | - | - | - | 0.3 | -38.9 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 2.7 | -44.7 | 118.0 | 0.0 | 1.0 | -43.1 | 77.7 | 0.0 |
| NO LATE CUT | 1.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| OFF BEST | 5.3 | -141.9 | 0.0 | 33.3 | 4.0 | -158.8 | 0.0 | 0.0 |
| ONE CHALLENGE TEST | - | - | - | - | 0.3 | +1.2 | 77.7 | 0.0 |
| ONE CHECK AFTER THE LAST CHANGE | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 5.3 | -52.4 | 0.0 | 77.7 | 3.3 | -72.7 | 0.0 | 314.0 |
| ONE JOINT FIGURE | 0.3 | +1.0 | 0.0 | 0.0 | - | - | - | - |
| ONE OBJECTIVE FORMULA | 3.0 | -22.3 | 0.0 | 77.7 | 3.0 | -42.6 | 0.0 | 129.0 |
| ONE ROUTE | 2.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| OVERRUNS AWAY | 0.3 | +8.7 | 26.7 | 0.0 | 1.0 | +6.5 | 77.7 | 0.0 |
| PATHS CROSS | 0.3 | +1.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 10.0 |
| PIVOT GUARDS FLANK | 0.3 | -1.1 | 0.0 | 0.0 | 0.3 | -2.7 | 0.0 | 0.0 |
| PLAN RESULT | 61.3 | +2407.8 | 1223.3 | 283.0 | 36.3 | +265.6 | 61.0 | 689.0 |
| PROMISE BELOW ZERO | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE BY ITS OWN SUM | 8.3 | -141.8 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | 14.0 | +1050.7 | 0.0 | 66.7 | 8.7 | +803.6 | 66.7 | 53.3 |
| RANDOM MOVE BY FIGURES | - | - | - | - | 4.0 | +83.4 | 0.0 | 0.0 |
| REAL GROUND | 2.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| REDIRECT BY WHAT IT STOPS | - | - | - | - | 3.0 | -14.6 | 0.0 | 53.3 |
| REDIRECT COUNTER | - | - | - | - | 3.3 | +175.6 | 0.0 | 53.3 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 2.0 | +0.0 | 0.0 | 0.0 |
| REDIRECT WEIGHED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| REFORMS TO MEET IT | 1.3 | -13.9 | 0.0 | 0.0 | - | - | - | - |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | - | - | - | - | 1.3 | +33.4 | 0.0 | 0.0 |
| RESTRAINS TO SHOOT | 0.3 | +2.4 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | 2.0 | +83.3 | 118.0 | 0.0 | 1.3 | -55.5 | 138.7 | 0.0 |
| ROUNDS AFTER TERROR | - | - | - | - | 0.7 | -6.5 | 138.7 | 0.0 |
| RUN DOWN | 2.7 | -18.8 | 118.0 | 0.0 | 1.0 | -19.8 | 77.7 | 0.0 |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 2.0 | -89.0 | 0.0 | 20.0 |
| SET UP BY THE SET | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | -14.8 | 0.0 | 0.0 |
| SET UP TOGETHER | - | - | - | - | 1.0 | +14.8 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 2.0 | +4.0 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS ON THE TABLE | 29.7 | +0.0 | 0.0 | 33.3 | 6.0 | +0.0 | 0.0 | 53.3 |
| SHOOTS FROM THE BEST SPOT | - | - | - | - | 0.3 | +34.0 | 0.0 | 0.0 |
| SHORT GUN FORWARD | 2.0 | +0.0 | 0.0 | 38.3 | - | - | - | - |
| SHOT OR CHARGE | 0.7 | -9.0 | 0.0 | 0.0 | - | - | - | - |
| SHOT RISK POINTS | 10.7 | +276.5 | 0.0 | 0.0 | 33.0 | -612.7 | 0.0 | 459.0 |
| SHOTS AFTER THE MOVES | 6.0 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 36.3 | +1387.4 | 0.0 | 33.3 | 8.3 | +313.4 | 0.0 | 117.0 |
| SPELL WORTH | - | - | - | - | 0.3 | +3.6 | 0.0 | 0.0 |
| SPOT AS THE GAME MOVES | 2.0 | +0.0 | 0.0 | 0.0 | 9.0 | +0.0 | 0.0 | 313.0 |
| STAND AND SHOOT | 0.3 | -1.2 | 26.7 | 0.0 | 0.7 | -6.3 | 61.0 | 0.0 |
| STANDS FOR A REASON | - | - | - | - | 3.0 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 96.0 | +0.0 | 4091.7 | 66.7 | 21.0 | +0.0 | 220.0 | 53.3 |
| STAY WORTH | 80.0 | +584.8 | 3436.3 | 100.0 | 11.7 | +356.3 | 153.3 | 26.7 |
| STUCK PIVOT | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 1.3 | +46.1 | 0.0 | 0.0 | 2.3 | +45.5 | 0.0 | 72.3 |
| SUPPORT NARROWED | 1.0 | +0.0 | 72.3 | 0.0 | 0.3 | +0.0 | 77.7 | 0.0 |
| SUPPORT WORKED OUT | 1.3 | +46.1 | 0.0 | 0.0 | 2.3 | +45.5 | 0.0 | 72.3 |
| SURE REACH TOGETHER | 0.3 | +0.5 | 0.0 | 0.0 | 0.7 | +5.7 | 0.0 | 0.0 |
| SWIFTSTRIDE BY POINTS | - | - | - | - | 1.0 | +10.4 | 0.0 | 36.7 |
| THE DEARER SUM KEEPS ITS PLAN | 2.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 10.0 |
| THE ROW IN ITS ORDER | 0.7 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 92.0 |
| THE ROW KEEPS ITS WAY | 1.7 | +0.0 | 0.0 | 0.0 | 4.7 | +0.0 | 0.0 | 13.7 |
| THE STEP BACK IS MADE | 0.7 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 13.7 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 61.0 | +0.0 | 0.0 | 111.0 | 35.0 | +0.0 | 0.0 | 643.0 |
| TIED UP BY THE SUM | 0.7 | +17.2 | 45.7 | 0.0 | 0.3 | +15.1 | 0.0 | 0.0 |
| TIME ON OUR SIDE | 54.7 | +588.3 | 27.3 | 77.7 | - | - | - | - |
| WAITS AGAIN | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WEAPON BY POINTS | - | - | - | - | 0.3 | +0.0 | 0.0 | 45.7 |
| WHO FIGHTS | 1.0 | -1.6 | 72.3 | 0.0 | 0.3 | +1.8 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | - | - | - | - | 3.7 | -412.4 | 0.0 | 802.7 |
| WHOLE FIGHT GAIN | - | - | - | - | 0.3 | +24.9 | 77.7 | 0.0 |
| WOUNDS ON THE RANKS | 2.0 | +60.9 | 0.0 | 0.0 | 5.0 | +265.3 | 0.0 | 0.0 |

### Rule changes: cnomg-c940641-p16

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS MOVE AS HE DECIDES | 101 | 101 | 82 | 27.33 | +0 | +0.0 |
| HIS MOVE WHY | 95 | 95 | 78 | 26.00 | +0 | +0.0 |
| HIS SHOT LIST | 250 | 243 | 65 | 21.67 | +1988 | +30.6 |
| ARMY TABLE | 82 | 82 | 57 | 19.00 | +1055 | +18.5 |
| HOLDER ASSIGNMENT | 53 | 53 | 50 | 16.67 | +3002 | +60.0 |
| HIS SHOTS BY HIS RUN | 207 | 205 | 40 | 13.33 | +587 | +14.7 |
| DEPLOY BY FIGURES | 57 | 57 | 39 | 13.00 | +580 | +14.9 |
| SHOT RISK POINTS | 131 | 128 | 30 | 10.00 | +677 | +22.6 |
| OFF BEST | 28 | 28 | 28 | 9.33 | -902 | -32.2 |
| TIME ON OUR SIDE | 164 | 149 | 28 | 9.33 | +82 | +2.9 |
| THE TABLE AGAIN | 36 | 36 | 25 | 8.33 | +0 | +0.0 |
| HARD STAY DROPPED | 20 | 20 | 20 | 6.67 | +0 | +0.0 |
| FIVE ACTION | 627 | 619 | 19 | 6.33 | +351 | +18.5 |
| HIS ONE MOVE | 53 | 52 | 18 | 6.00 | +0 | +0.0 |
| CANNON PLANNED TARGET | 76 | 76 | 15 | 5.00 | -60 | -4.0 |
| LEGAL CHARGES ONLY | 15 | 15 | 15 | 5.00 | +0 | +0.0 |
| MOVE TO CHARGE COMPUTED | 20 | 18 | 15 | 5.00 | +276 | +18.4 |
| MODEL FACING | 14 | 14 | 14 | 4.67 | +4712 | +336.6 |
| MOVE ORDER | 14 | 14 | 14 | 4.67 | +0 | +0.0 |
| PROMISE BY ITS OWN SUM | 29 | 29 | 14 | 4.67 | -425 | -30.4 |
| ARTILLERY RE-ROLL WEIGHED | 13 | 13 | 13 | 4.33 | +0 | +0.0 |
| GOAL WALK | 51 | 51 | 10 | 3.33 | +556 | +55.6 |
| CANNON SIGHT KEPT | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| CHARGE LOSSES | 85 | 84 | 9 | 3.00 | +360 | +40.0 |
| CHAFF IN THE MOVE | 9 | 8 | 8 | 2.67 | +52 | +6.6 |
| RANDOM MOVE BY FIGURES | 12 | 12 | 8 | 2.67 | +250 | +31.3 |
| FOUR ROUNDS | 13 | 13 | 7 | 2.33 | +94 | +13.5 |
| GUN MASK | 15 | 15 | 6 | 2.00 | +203 | +33.9 |
| IDLE COST | 51 | 41 | 6 | 2.00 | +30 | +4.9 |
| MEETS IN TIME | 27 | 27 | 6 | 2.00 | +34 | +5.6 |
| REDIRECT FOR A FRIEND IN REACH | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| SHOOTERS IN TWO RANKS | 6 | 6 | 6 | 2.00 | +12 | +2.0 |
| SHORT GUN FORWARD | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| SHOTS AFTER THE MOVES | 25 | 25 | 6 | 2.00 | +0 | +0.0 |
| SHOTS IN THE MOVE | 134 | 114 | 6 | 2.00 | +91 | +15.1 |
| COVER ONCE | 33 | 25 | 5 | 1.67 | +76 | +15.2 |
| EXACT ROUND | 10 | 10 | 5 | 1.67 | +8 | +1.6 |
| NEXT CHARGE BY LIST | 7 | 7 | 5 | 1.67 | +163 | +32.6 |
| QUARTER ODDS | 68 | 67 | 5 | 1.67 | +193 | +38.6 |
| RISK BY ARC | 10 | 10 | 5 | 1.67 | +106 | +21.2 |
| WOUNDS ON THE RANKS | 21 | 21 | 5 | 1.67 | +193 | +38.7 |
| CHAFF PASSED | 4 | 4 | 4 | 1.33 | -4 | -1.1 |
| LANE BY FIGURES | 4 | 4 | 4 | 1.33 | +233 | +58.2 |
| MANOEUVRE | 10 | 10 | 4 | 1.33 | +59 | +14.8 |
| RESERVE FALL BACK | 4 | 4 | 4 | 1.33 | +100 | +25.1 |
| STAY WORTH | 275 | 261 | 4 | 1.33 | +69 | +17.3 |
| ADVANCE LANE KEPT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| JOINT CHARGE NOW | 3 | 3 | 3 | 1.00 | +602 | +200.8 |
| STUCK PIVOT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| SWIFTSTRIDE BY POINTS | 3 | 3 | 3 | 1.00 | +31 | +10.4 |
| AFTERMATH IN POINTS | 2 | 2 | 2 | 0.67 | +50 | +25.2 |
| CHALLENGE BY POINTS | 2 | 2 | 2 | 0.67 | +98 | +48.9 |
| FALLS SHORT | 61 | 53 | 2 | 0.67 | +21 | +10.5 |
| FEATURE BUFFS | 4 | 4 | 2 | 0.67 | +4 | +2.2 |
| FIGHT TO THE END | 4 | 4 | 2 | 0.67 | +16 | +7.8 |
| FIRE IN ORDER | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 2 | 2 | 2 | 0.67 | +323 | +161.6 |
| HOLDS AMBUSHERS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| OVERRUNS AWAY | 4 | 4 | 2 | 0.67 | +8 | +3.9 |
| PATHS CROSS | 2 | 2 | 2 | 0.67 | +3 | +1.6 |
| PIVOT GUARDS FLANK | 2 | 2 | 2 | 0.67 | -11 | -5.7 |
| REDIRECT BY WHAT IT STOPS | 9 | 9 | 2 | 0.67 | +25 | +12.3 |
| SUPPORT ADDS | 11 | 11 | 2 | 0.67 | +29 | +14.7 |
| SUPPORT WORKED OUT | 11 | 11 | 2 | 0.67 | +29 | +14.7 |
| TIED UP BY THE SUM | 3 | 3 | 2 | 0.67 | +2 | +0.8 |
| WHO FIGHTS | 4 | 4 | 2 | 0.67 | +3 | +1.3 |
| COMBAT PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FIRE AND FLEE | 1 | 1 | 1 | 0.33 | +8 | +7.5 |
| FRIEND SHOOTS FIRST | 2 | 2 | 1 | 0.33 | +12 | +12.3 |
| HIS CHARGE DENIED | 2 | 2 | 1 | 0.33 | +1 | +0.6 |
| HIS TURN DENIED | 1 | 1 | 1 | 0.33 | +1 | +0.6 |
| LONE WIZARD KEPT IN | 1 | 1 | 1 | 0.33 | +75 | +75.0 |
| LOST AFTER ESCAPE | 7 | 7 | 1 | 0.33 | +1 | +1.0 |
| ONE FIGHT FORMULA | 26 | 21 | 1 | 0.33 | +0 | +0.0 |
| ONE JOINT FIGURE | 1 | 1 | 1 | 0.33 | +1 | +1.0 |
| REDIRECT COUNTER | 10 | 8 | 1 | 0.33 | +45 | +44.7 |
| REDIRECT WEIGHED | 1 | 1 | 1 | 0.33 | +64 | +63.7 |
| REFUSING RETIRES | 2 | 2 | 1 | 0.33 | -11 | -10.7 |
| RESTRAINS TO SHOOT | 1 | 1 | 1 | 0.33 | +7 | +7.1 |
| SHOOTS FROM THE BEST SPOT | 1 | 1 | 1 | 0.33 | +57 | +57.0 |
| THE ROW IN ITS ORDER | 13 | 1 | 1 | 0.33 | +0 | +0.0 |
| WEAPON BY POINTS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| WHOLE FIGHT DANGER | 11 | 10 | 1 | 0.33 | +4 | +4.1 |
| BACKUP TARGETS | 1 | 1 | 0 | 0.00 | - | - |
| BLOWS WHERE AIMED | 1 | 1 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 7 | 7 | 0 | 0.00 | - | - |
| CHARACTER GUNS | 14 | 14 | 0 | 0.00 | - | - |
| CHARGE NOW FIRST | 4 | 4 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 48 | 48 | 0 | 0.00 | - | - |
| DEFENSIVE ARMY | 1 | 1 | 0 | 0.00 | - | - |
| DENIED BY THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 8 | 8 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 24 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 4 | 4 | 0 | 0.00 | - | - |
| GIVES UP | 2 | 2 | 0 | 0.00 | - | - |
| GUN FIGURES | 1 | not checked | - | - | - | - |
| HE REFORMS ONCE FREED | 2 | 2 | 0 | 0.00 | - | - |
| HELPER UNSEEN | 1 | 1 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 50 | 49 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 75 | 72 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 23 | 22 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 22 | 22 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 10 | 10 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 20 | 20 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 52 | 52 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN RUN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 79 | 78 | 0 | 0.00 | - | - |
| HONEST WORTH | 9 | 9 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 18 | 18 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 1 | not checked | - | - | - | - |
| MARCH WHEELS ONLY | 10 | 10 | 0 | 0.00 | - | - |
| MAX FOR POSITIONING | 5 | 5 | 0 | 0.00 | - | - |
| MISSILES IN THE MOVE | 1 | 1 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 5 | 5 | 0 | 0.00 | - | - |
| NEARER NOT NEEDED | 23 | 21 | 0 | 0.00 | - | - |
| NEXT OBJECTIVE NEARER | 1 | 1 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 11 | 11 | 0 | 0.00 | - | - |
| NO LATE CUT | 6 | 6 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 18 | 18 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT TURNED | 1 | 1 | 0 | 0.00 | - | - |
| ONE CHALLENGE TEST | 1 | 1 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 3 | not checked | - | - | - | - |
| ONE OBJECTIVE FORMULA | 18 | 12 | 0 | 0.00 | - | - |
| ONE ROUTE | 10 | 10 | 0 | 0.00 | - | - |
| PLAN RESULT | 293 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 2 | 2 | 0 | 0.00 | - | - |
| PROMISE KNOWS THE FIGHT | 2 | 1 | 0 | 0.00 | - | - |
| REAL GROUND | 10 | 10 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 4 | 4 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 2 | 2 | 0 | 0.00 | - | - |
| RUN DOWN | 11 | 11 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 6 | 6 | 0 | 0.00 | - | - |
| SET UP BY THE SET | 4 | 4 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 3 | 2 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 107 | not checked | - | - | - | - |
| SHOT OR CHARGE | 2 | 2 | 0 | 0.00 | - | - |
| SPELL WORTH | 1 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 33 | 20 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 3 | 3 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 9 | 9 | 0 | 0.00 | - | - |
| STANDS STILL | 351 | 347 | 0 | 0.00 | - | - |
| SUPPORT NARROWED | 4 | 4 | 0 | 0.00 | - | - |
| SURE REACH TOGETHER | 3 | 3 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 12 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 19 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 11 | not checked | - | - | - | - |
| THE TABLE BINDS | 288 | not checked | - | - | - | - |
| WAITS AGAIN | 2 | 2 | 0 | 0.00 | - | - |
| WHOLE FIGHT GAIN | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: cnomg-c940641-p16

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 5.00 | 4.00 | 33.1 |
| PROMISE BY ITS OWN SUM | rule | 4.67 | - | 30.4 |
| ARMY TABLE | rule | 1.67 | 2.33 | 34.2 |
| CANNON PLANNED TARGET | rule | 2.33 | - | 9.6 |
| CHAFF PASSED | rule | 0.67 | - | 2.2 |
| PIVOT GUARDS FLANK | rule | 0.33 | 0.33 | 5.7 |
| DEPLOY BY FIGURES | rule | - | 0.33 | 5.8 |
| FALLBACK | gate | 0.33 | - | 7.6 |
| HOLDER ASSIGNMENT | rule | 0.33 | - | 29.1 |
| JOINT CHARGE NOW | rule | 0.33 | - | 63.7 |
| REFUSING RETIRES | rule | 0.33 | - | 10.7 |

### Plans: cnomg-c940641-p16

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 2.0 | 50% | 63 | 166 | 262% |
| Mine | join | 2.7 | 100% | 88 | 0 | 0% |
| Mine | move | 31.7 | 99% | 1058 | 0 | 0% |
| Mine | shoot | 25.0 | 76% | 1435 | 2242 | 156% |
| Opponent | charge | 1.3 | 75% | 222 | 166 | 75% |
| Opponent | move | 29.0 | 94% | 918 | 0 | 0% |
| Opponent | shoot | 4.0 | 25% | 270 | 100 | 37% |
| Opponent | support | 2.0 | 67% | 29 | 0 | 0% |

### Battle groups: cnomg-c940641-p16

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | REDIRECT COUNTER | 3.3 | 10% | 0% | 0% | - | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: cnomg-c940641-p16

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | - | 0 (1) | 0 (1) | - |
| Mine | Character | 13 | 3 (13) | 3 | 0 | 6 | 38% | 3.0 | 0 (3) | 0 (5) | 7 (4) | 4 (7) | 0 (5) |
| Mine | Clean-up | 3 | 0 (3) | 0 | 0 | 0 | 33% | 1.0 | 0 (1) | 0 (1) | 0 (1) | 0 (2) | 0 (1) |
| Mine | Hammer | 6 | 90 (6) | 25 | 65 | 0 | 50% | 3.0 | - | 99 (4) | 73 (2) | 91 (5) | 88 (1) |
| Mine | Shooter | 10 | 47 (10) | 7 | 40 | 29 | 0% | 2.6 | - | 37 (4) | 58 (6) | 37 (5) | 59 (5) |
| Mine | War machine | 17 | 36 (17) | 36 | 0 | 13 | 18% | 1.1 | 15 (9) | 0 (2) | 83 (6) | 157 (3) | 10 (14) |
| Opponent | Chaff | 5 | 0 (5) | 0 | 0 | 89 | 60% | 2.0 | 0 (4) | - | 0 (1) | 0 (4) | 0 (1) |
| Opponent | Character | 8 | 20 (8) | 20 | 0 | 18 | 75% | 2.0 | 0 (3) | 0 (1) | 43 (4) | 31 (5) | 0 (3) |
| Opponent | Clean-up | 3 | 66 (3) | 0 | 66 | 0 | 33% | 5.0 | 71 (1) | 60 (2) | - | 66 (3) | - |
| Opponent | Fast Hammer | 4 | 27 (4) | 0 | 27 | 12 | 50% | 2.5 | - | 48 (3) | 0 (1) | 61 (2) | 0 (2) |
| Opponent | Hammer | 3 | 0 (3) | 0 | 0 | 0 | 100% | - | 0 (1) | 0 (2) | - | 0 (3) | - |
| Opponent | Holder | 2 | 0 (2) | 0 | 0 | 100 | 0% | 3.5 | - | 0 (2) | - | 0 (1) | 0 (1) |
| Opponent | Support | 1 | 0 (1) | 0 | 0 | 0 | 0% | 6.0 | - | 0 (1) | - | - | 0 (1) |
| Opponent | War machine | 2 | 108 (2) | 108 | 0 | 0 | 0% | 1.0 | - | - | 108 (2) | - | 108 (2) |
| Opponent | Wizard | 2 | 0 (2) | 0 | 0 | 0 | 50% | 1.0 | 0 (1) | 0 (1) | - | 0 (2) | - |

### Charged fights: cnomg-c940641-p16

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Dwarfen Mountain Holds | 3 | 254 | 72 | 2.3 | 1.1 | 31 | 0 | +31 | 0 of 7 | 6 of 7 | +137 | +13 |
| Opponent | Kingdom of Bretonnia | 1 | 215 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 1 of 1 | 1 of 1 | - | +0 |
| Opponent | Warriors of Chaos | 2 | 0 | 139 | 0.5 | 1.0 | 278 | 0 | +278 | 1 of 1 | 1 of 1 | - | +278 |
| **Opponent** | all armies | 3 | 72 | 93 | 0.7 | 1.0 | 139 | 0 | +139 | 2 of 2 | 2 of 2 | - | +139 |

### Effective charges: cnomg-c940641-p16

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Dwarfen Mountain Holds | 7 | 1 (net +0) | 0 | 0 | 3 (net +27) | 0 | 3 (net +46) | 0 | 0% (0 of 7) |

### Charged fights, damage counted: cnomg-c940641-p16

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 1 | 50 | 135 | +0 | 45 | 0 | +45 | +90.0 |
| Mine | 76-89% | 3 | 72 | 117 | +27 | 145 | 5 | +140 | +194.8 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 | 92 | 137 | +46 | 59 | 0 | +59 | +64.1 |
| Mine | All fights | 7 | 77 | 128 | +31 | 94 | 2 | +91 | +118.5 |
| Opponent | No odds | 2 | 352 | 184 | +139 | 209 | 18 | +190 | +54.1 |
| Opponent | All fights | 2 | 352 | 184 | +139 | 209 | 18 | +190 | +54.1 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| cnomg-c940641-p16 | move | 22 | 5 (23%) | 5 (23%) | 0 (0%) | 17 (77%) |

## Decision items and abilities without guidance

None: every decision item and ability on these lists has its guidance line.

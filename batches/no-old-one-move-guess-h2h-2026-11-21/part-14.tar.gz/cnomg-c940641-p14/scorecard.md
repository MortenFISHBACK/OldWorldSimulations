# Doctrine scorecard: cnomg-c940641-p14

### Scorecard: cnomg-c940641-p14

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0222 | 6 | 1 | Mine | no | 0 | 1 | 3 | 5 | 1 | 0 | 0 | 170 |
| L0222 | 6 | 1 | Opponent | no | 6 | 1 | 6 | 1 | 0 | 0 | 0 | 216 |
| L0307 | 1 | 1 | Mine | yes | 2 | - | 0 | 1 | 0 | 0 | 0 | 675 |
| L0307 | 1 | 1 | Opponent | no | 7 | 4 | 1 | 4 | 0 | 0 | 0 | 250 |
| L0323 | 5 | 1 | Mine | no | - | 2 | 2 | 1 | 0 | 0 | 0 | 340 |
| L0323 | 5 | 1 | Opponent | yes | - | 4 | 1 | 2 | 0 | 0 | 0 | 245 |
| **Average** | | | Mine | 33% | 1.0 | 1.5 | 1.7 | 2.3 | 0.3 | 0.0 | 0.0 | 395.0 |
| **Average** | | | Opponent | 33% | 6.5 | 3.0 | 2.7 | 2.3 | 0.0 | 0.0 | 0.0 | 237.0 |

### KPIs: cnomg-c940641-p14

Rules off - Mine only: NO OLD ONE-MOVE GUESS.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 42% (5 of 12) | 0% (0 of 15) | 19% (5 of 27) |
| Winner chose to follow up after the loser gave ground |  | 86% (6 of 7); on the table 86% | 100% (4 of 4); on the table 100% | 91% (10 of 11); on the table 91% |
| Winner chose to pursue after the loser fell back in good order |  | - | - | - |
| Winner chose to pursue after the loser fled |  | 100% (1 of 1); on the table 100% | 100% (3 of 3); on the table 100% | 100% (4 of 4); on the table 100% |
| Winner chose to follow up or pursue (all three) |  | 88% (7 of 8); on the table 88% | 100% (7 of 7); on the table 100% | 93% (14 of 15); on the table 93% |
| Magic missiles tried each own turn | 50%+ | 19% (7 of 36) | 50% (3 of 6) | 24% (10 of 42) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 23% (7 of 30) | 75% (3 of 4) | 29% (10 of 34) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 0% (0 of 2) | - | 0% (0 of 2) |
| Points that never fought | lower | 53% (3144 of 5897) | 57% (3438 of 5999) | 55% (6582 of 11896) |
|   infantry points that never fought | lower | 40% (581 of 1437) | 88% (828 of 938) | 59% (1409 of 2375) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 55% (12 of 22) | 65% (13 of 20) | 60% (25 of 42) |
| Bound items with a magic missile used (at least once a game) |  | 100% (2 of 2); 2.7 uses a game | 0.0 uses a game | 100% (2 of 2); 1.3 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 100% (4 of 4); 1.3 uses a game | 0% (0 of 1); 0.0 uses a game | 80% (4 of 5); 0.7 uses a game |
|   their share of the points of units over 100 pts | lower | 49% (2182 of 4484) | 62% (2864 of 4648) | 55% (5046 of 9132) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 7.0 (72%) | 0.0 (0%) | 7.0 (66%) |
| MARCHED: its unit marched | 0.7 (7%) | 0.3 (33%) | 1.0 (9%) |
| IN COMBAT: engaged in combat | 2.0 (21%) | 0.3 (33%) | 2.3 (22%) |
| FLEEING: fleeing | 0.0 (0%) | 0.3 (33%) | 0.3 (3%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 6.0 | 1.0 | 3.3 | 0.7 | 0.7 |
| not cast | 0.0 | 3.0 | 10.7 | 1.3 | 7.3 |
| NOT CHOSEN: could have been cast at a target | - | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.3 (32%) |
| NO TARGET: no enemy in range, sight and arc it may target | - | 0.0 (0%) | 7.0 (66%) | 0.3 (25%) | 0.0 (0%) |
| MARCHED: its unit marched | - | 0.0 (0%) | 1.0 (9%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | - | 2.0 (67%) | 2.3 (22%) | 0.3 (25%) | 0.0 (0%) |
| FLEEING: fleeing | - | 0.0 (0%) | 0.3 (3%) | 0.3 (25%) | 1.0 (14%) |
| OTHER BAR: another bar (miscast, baggage ...) | - | 0.0 (0%) | 0.0 (0%) | 0.3 (25%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | - | 1.0 (33%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | - | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 4.0 (55%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.0 a game | 0.0 a game | 0.5 a game |
| stood (cast and not dispelled) | 67% (2 of 3) | - | 67% (2 of 3) |
| the unit moved after it | 100% (2 of 2) | - | 100% (2 of 2) |
| it charged on its next turn | 0% (0 of 2) | - | 0% (0 of 2) |
| the enemy charged it first | 50% (1 of 2) | - | 50% (1 of 2) |
| it fought by the end of its next turn | 50% (1 of 2) | - | 50% (1 of 2) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 2) | - | 0% (0 of 2) |
| none of these (no charge, no fight, no charge escaped) | 50% (1 of 2) | - | 50% (1 of 2) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 77% (41 of 53) | 58% (57 of 98) | 65% (98 of 151) |
|   cavalry | - | 88% (7 of 8) | 88% (7 of 8) |
|   character | - | 0% (0 of 17) | 0% (0 of 17) |
|   chariot | 64% (14 of 22) | 50% (1 of 2) | 62% (15 of 24) |
|   infantry | - | 64% (38 of 59) | 64% (38 of 59) |
|   war machine | 87% (27 of 31) | 92% (11 of 12) | 88% (38 of 43) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 0.7 (17%) | 1.0 (7%) | 1.7 (9%) |
| CHARGED: it charged | 0.3 (8%) | 2.0 (15%) | 2.3 (13%) |
| IN COMBAT: it fought this turn or the last | 1.0 (25%) | 1.0 (7%) | 2.0 (11%) |
| MOVED: a war machine that moved | 1.0 (25%) | 0.3 (2%) | 1.3 (8%) |
| NO TARGET IN RANGE | 0.3 (8%) | 4.0 (29%) | 4.3 (25%) |
| ONLY IN COMBAT: the only targets were in combat | 0.0 (0%) | 2.3 (17%) | 2.3 (13%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.7 (17%) | 2.3 (17%) | 3.0 (17%) |
| SHELTERED: the target was sheltered | 0.0 (0%) | 0.7 (5%) | 0.7 (4%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 2.7 | 0.3 | 88% | 0.5 pts | 1 pts |
| chariot | 5.0 | 5.7 | 47% | 26.2 pts | 131 pts |
| infantry | 15.0 | 5.3 | 71% | 7.4 pts | 111 pts |
| war machine | 12.7 | 17.3 | 58% | 46.8 pts | 593 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 1.7 | 3.7 | 2.7 |
| Charges that made contact a game | 1.7 | 2.7 | 2.2 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.00 declared, 0.00 contact (4 units) | 1.00 declared, 1.00 contact (1 units) | 0.20 declared, 0.20 contact (5 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | - | - |
|   per unit a game, the other units (no war machines, no joined characters) | 0.25 declared, 0.25 contact (20 units) | 0.33 declared, 0.23 contact (30 units) | 0.30 declared, 0.24 contact (50 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 100% (3 of 3) | 0% (0 of 1) | - | 75% (3 of 4) |
| Character in a unit | 60% (3 of 5) | 0% (0 of 2) | - | 43% (3 of 7) |
| Character on its own | 100% (1 of 1) | - | 60% (3 of 5) | 67% (4 of 6) |
| Chariot | - | 50% (2 of 4) | - | 50% (2 of 4) |
| Infantry | 0% (0 of 2) | 33% (1 of 3) | - | 20% (1 of 5) |
| Monster | 80% (4 of 5) | - | - | 80% (4 of 5) |
| War Machines | 78% (7 of 9) | 50% (1 of 2) | - | 73% (8 of 11) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 1 | 83% (5 of 6); on the table 83% | 42% (5 of 12) | 20% | 17% (1 of 6) | 100% (2 of 2); 8.0 uses a game | 0.0 uses a game | 100% (2 of 2); 2.0 uses a game |
| Chaos Dwarfs | 2 | 100% (2 of 2); on the table 100% | 8% (2 of 24) | 69% | 69% (11 of 16) | 0.0 uses a game | 0.0 uses a game | 100% (2 of 2); 1.0 uses a game |
| Empire of Man | 1 | - | 50% (3 of 6) | 81% | 80% (8 of 10) | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Tomb Kings of Khemri | 2 | 100% (7 of 7); on the table 100% | - | 45% | 50% (5 of 10) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (cnomg-c940641-p14, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 38% (3) | 0% (0) | 33% (3) |
| ...free all their last turn and able to turn (per game) | 0.67 | 0.00 | 0.67 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.33 | 0.00 | 0.33 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: cnomg-c940641-p14

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 0.7 | 2.7 |
| Strategy | Charge objectives carried out (made contact) | 100% (3 of 3) | 44% (4 of 9) |
| Strategy | Shoot objectives carried out (shot that target) | 49% (21 of 43) | 34% (12 of 35) |
| Strategy | Joined characters whose unit fought | 86% (6 of 7) | 0% (0 of 4) |
| Strategy | Lone characters that fought | 20% (1 of 5) | 57% (4 of 7) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 2.3 | 2.3 |
| Movement | Points that never moved of their own | 395.0 | 237.0 |
| Movement | Fights charged into per game | 1.7 | 2.7 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 3 | 3 of 7, net -257 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 3 | 0 of 7 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 1 of 3, net +66 | 0 of 7 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 of 3, net -25 | 2 of 7, net +0 |
| Shooting | Shots by shooting units (incl. breath weapons) | 4.7 | 16.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 57% (8 of 14) | 38% (18 of 48) |
| Shooting | Points destroyed by shooting units | 63.0 | 54.0 |
| Shooting | War machine shots | 9.0 | 3.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 22% (6 of 27) | 55% (6 of 11) |
| Shooting | Points destroyed by war machines | 65.0 | 120.0 |
| Magic | Magic missiles cast | 1.3 | 0.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 25% (1 of 4) | 100% (1 of 1) |
| Magic | Wounds caused by magic missiles | 3.7 | - |
| Magic | Wounds caused by other spells | - | 0.3 |
| Magic | Points destroyed by magic (all spells) | 48.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.0 / 0.0 / 0.3 / 0.0 | 5.3 / 0.0 / 0.3 / 0.7 |
| Combat | Points destroyed in combat | 483.7 | 160.0 |
| Combat | Points run down | 0.0 | 30.3 |
| Combat | Net points per charged fight, damage counted | +80 | -71 |
| Combat | Net per 100 charger points, damage counted | +49.5 | -19.7 |
| Combat | First round won (charged fights) | 100% | 50% |
| Combat | Net points per charged fight | +84 | -58 |
| Combat | Net points per supported fight / lone fight | - / +84 | - / -58 |
| Combat | Charged fights on a top-3 enemy unit | 1 of 5 | 5 of 8 |
| Game | Points lost | 545.7 | 689.3 |
| Game | VP from objectives | 420.0 | 850.0 |
| Game | Lone holders (player turns) | 1.0 | 6.5 |

- Mine won / drew / lost: 1 / 0 / 2 of 3 ended games (of 3); mean margin (Mine - Opponent) -229 VP
- The side that went first won 2 of 3 games with a winner
- Points traded per game (both sides' losses): 1235
- Games not ended: 0; findings 1, warnings 0

### Opponent rules: cnomg-c940641-p14

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.3 | +198.1 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | 16.7 | +19.4 | 0.0 | 0.0 | 25.7 | +503.0 | 0.0 | 175.0 |
| ARTILLERY RE-ROLL WEIGHED | 3.3 | +0.0 | 0.0 | 320.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| BEST PRIZE | - | - | - | - | 0.3 | +9.5 | 0.0 | 0.0 |
| CANNON PLAN MISSED | 0.7 | +0.0 | 23.3 | 0.0 | 0.3 | +0.0 | 36.7 | 0.0 |
| CANNON PLANNED TARGET | 8.3 | +12.6 | 86.3 | 583.3 | 3.7 | +225.1 | 240.0 | 0.0 |
| CANNON SIGHT KEPT | 1.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 41.7 |
| CAST JOB | 2.7 | +31.8 | 36.7 | 0.0 | 0.7 | +9.1 | 0.0 | 0.0 |
| CASTER AWAY FROM SCREEN | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CASTING BLOCK | 1.0 | +71.2 | 113.0 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | 0.7 | +4.2 | 0.0 | 0.0 | 0.3 | +3.9 | 0.0 | 22.0 |
| CHAFF PASSED | 0.3 | -0.7 | 0.0 | 103.3 | - | - | - | - |
| CHALLENGE BY POINTS | 0.7 | +12.0 | 0.0 | 0.0 | 0.3 | +5.1 | 0.0 | 0.0 |
| CHARGE LOSSES | 14.3 | -787.4 | 0.0 | 160.0 | 18.7 | -324.5 | 0.0 | 279.3 |
| CHARGE NOW FIRST | 0.3 | +0.0 | 22.0 | 0.0 | 2.0 | +0.0 | 56.7 | 314.0 |
| CLOSES ON WHAT IT BEATS | 10.7 | +0.0 | 0.0 | 0.0 | 10.0 | +0.0 | 0.0 | 0.0 |
| COMBAT PIVOT | 0.3 | +0.0 | 0.0 | 56.7 | 1.0 | +0.0 | 56.7 | 170.3 |
| CONVEYANCE SEARCH | 1.0 | +277.8 | 0.0 | 0.0 | - | - | - | - |
| COVER ONCE | 10.0 | -742.9 | 0.0 | 140.0 | 5.0 | -113.9 | 0.0 | 0.0 |
| DENIED BY THE FIGHT | - | - | - | - | 1.0 | -4.7 | 0.0 | 314.0 |
| DEPLOY BY FIGURES | 9.0 | -61.4 | 0.0 | 0.0 | 7.3 | -45.6 | 0.0 | 41.7 |
| DUEL STOPS AT THE KILL | - | - | - | - | 0.3 | -30.0 | 0.0 | 143.7 |
| ENGINEER BY LORE | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| EXACT ROUND | 0.7 | +1.2 | 46.0 | 0.0 | 2.0 | +15.9 | 160.0 | 0.0 |
| FALL BACK GOOD ORDER | 1.3 | +0.0 | 86.3 | 30.3 | 2.7 | +5.1 | 160.0 | 314.0 |
| FALLS SHORT | 7.3 | +122.4 | 0.0 | 0.0 | 15.3 | +123.1 | 0.0 | 151.0 |
| FEATURE BUFFS | 6.3 | +134.7 | 0.0 | 0.0 | 3.7 | +83.2 | 0.0 | 88.0 |
| FIGHT TO THE END | 0.3 | +1.5 | 18.3 | 0.0 | 1.7 | +154.1 | 103.3 | 314.0 |
| FIVE ACTION | 89.7 | +2598.7 | 578.7 | 1460.3 | 98.3 | +7248.9 | 1451.3 | 1013.3 |
| FLANK NOT WEIGHED | 8.0 | +0.0 | 0.0 | 103.3 | 2.7 | +0.0 | 0.0 | 65.0 |
| FOLLOW UP WEIGHED | 0.7 | +164.0 | 0.0 | 0.0 | 1.3 | +265.6 | 0.0 | 0.0 |
| FOUR ROUNDS | 1.3 | +37.9 | 86.3 | 30.3 | 3.7 | +510.1 | 160.0 | 314.0 |
| FREED FROM HIS FIGHT | 5.7 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 63.0 |
| FRIEND SHOOTS FIRST | 0.7 | -20.4 | 0.0 | 0.0 | 0.7 | -0.9 | 0.0 | 0.0 |
| GIVES UP | 0.3 | -1.1 | 24.0 | 0.0 | 1.3 | -21.9 | 103.3 | 0.0 |
| GOAL WALK | 13.0 | +693.5 | 0.0 | 0.0 | 18.0 | +2032.9 | 0.0 | 0.0 |
| GROUND FLIERS | 0.3 | +9.7 | 0.0 | 0.0 | - | - | - | - |
| GUN FIGURES | 3.0 | +46.1 | 148.0 | 103.3 | - | - | - | - |
| HARD STAY DROPPED | 0.7 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 22.0 |
| HE REFORMS ONCE FREED | 2.3 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 10.3 | +0.0 | 0.0 | 160.0 | 3.7 | +0.0 | 0.0 | 193.0 |
| HIS CHARGE LIST | 9.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS LEGAL MOVES | 3.7 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 1.3 | -1.3 | 0.0 | 0.0 | 2.7 | -112.0 | 0.0 | 109.0 |
| HIS MOVE AS HE DECIDES | 46.7 | +13.3 | 1082.0 | 0.0 | - | - | - | - |
| HIS MOVE WHY | - | - | - | - | 19.3 | +0.0 | 0.0 | 134.7 |
| HIS ONE MOVE | 17.7 | +83.2 | 0.0 | 206.7 | - | - | - | - |
| HIS ONE QUARTER | 5.0 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 3.0 | +0.0 | 0.0 | 0.0 | 5.3 | +0.0 | 0.0 | 126.0 |
| HIS RANDOM MOVE | - | - | - | - | 3.3 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 53.3 | +1302.0 | 0.0 | 56.7 | 60.0 | +2229.0 | 0.0 | 484.3 |
| HIS SHOTS BY HIS RUN | 38.3 | +469.5 | 0.0 | 160.0 | 45.0 | +756.4 | 0.0 | 591.0 |
| HIS TURN DENIED | 0.7 | +4.8 | 40.3 | 30.3 | 1.7 | +58.2 | 103.3 | 314.0 |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 14.3 | +0.0 | 0.0 | 0.0 | 20.7 | +0.0 | 0.0 | 176.0 |
| HOLDER ASSIGNMENT | 6.7 | +716.6 | 0.0 | 0.0 | 12.7 | +1178.9 | 0.0 | 44.0 |
| HOLDS AMBUSHERS | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 1.3 | -22.5 | 86.3 | 30.3 | 3.3 | -130.3 | 160.0 | 314.0 |
| IDLE COST | 9.0 | -49.5 | 0.0 | 0.0 | 14.0 | -212.9 | 0.0 | 172.7 |
| KEEP FALLS | 0.7 | +17.0 | 0.0 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | - | - | - | - | 5.7 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | - | - | - | - | 1.3 | +45.8 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 2.0 | +0.0 | 225.3 | 34.7 | 9.7 | +0.0 | 361.7 | 192.7 |
| LONE WIZARD KEPT IN | 0.7 | +17.5 | 0.0 | 0.0 | 1.0 | +78.3 | 0.0 | 0.0 |
| LONG SHOT | 0.3 | +0.2 | 18.3 | 0.0 | - | - | - | - |
| LOST AFTER ESCAPE | 0.3 | -0.0 | 18.3 | 0.0 | 1.0 | +0.9 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | - | - | - | - | 1.0 | +4.0 | 0.0 | 0.0 |
| MANOEUVRE | 2.3 | +13.5 | 0.0 | 0.0 | 1.7 | -8.0 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.7 | +1.1 | 0.0 | 0.0 | - | - | - | - |
| MARCH BY THE SUM | 0.3 | +3.8 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | 1.0 | +30.6 | 0.0 | 0.0 | - | - | - | - |
| MARCH OF THE TABLE | - | - | - | - | 0.3 | +10.0 | 0.0 | 0.0 |
| MARCH OVER CASTS | 0.3 | -1.1 | 0.0 | 0.0 | 0.3 | +30.9 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | - | - | - | - | 2.3 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 3.3 | +109.4 | 0.0 | 0.0 | 1.7 | +31.6 | 0.0 | 24.0 |
| MEETS IN TIME | 3.3 | +203.8 | 0.0 | 0.0 | 1.7 | +142.6 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 4.3 | +97.5 | 0.0 | 0.0 | 1.0 | +17.6 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 7.0 | +94.7 | 0.0 | 0.0 | 1.0 | +23.8 | 0.0 | 0.0 |
| MOVE ORDER | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL SPOT | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 4.0 | +166.8 | 0.0 | 103.3 | 3.3 | +183.5 | 0.0 | 191.0 |
| MOVES UNITS SPELL | 0.3 | +18.4 | 0.0 | 0.0 | - | - | - | - |
| NEARER NOT NEEDED | 6.3 | +327.4 | 0.0 | 0.0 | 9.7 | +406.5 | 0.0 | 44.0 |
| NEXT CHARGE BY LIST | 2.3 | +119.4 | 0.0 | 0.0 | 2.3 | +110.4 | 0.0 | 126.0 |
| NEXT OBJECTIVE NEARER | - | - | - | - | 0.7 | -5.1 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 1.0 | -9.3 | 64.3 | 30.3 | 3.7 | -170.6 | 160.0 | 314.0 |
| NO LATE CUT | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OFF BEST | 7.0 | -151.2 | 24.0 | 257.0 | 5.3 | -190.2 | 0.0 | 23.3 |
| OGRE LOADER SECOND SHOT | 1.0 | +0.2 | 0.0 | 76.7 | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ONE FIGHT FORMULA | 2.3 | -22.6 | 0.0 | 0.0 | 5.3 | -113.8 | 0.0 | 65.0 |
| ONE JOINT FIGURE | - | - | - | - | 0.3 | +246.4 | 0.0 | 0.0 |
| ONE OBJECTIVE FORMULA | 4.0 | +128.5 | 0.0 | 0.0 | 5.0 | +77.1 | 0.0 | 22.0 |
| ONE ROUTE | - | - | - | - | 2.3 | +0.0 | 0.0 | 0.0 |
| OPENS A LANE | 0.3 | +1.1 | 22.0 | 103.3 | - | - | - | - |
| OVERRUNS AWAY | 0.3 | +3.2 | 22.0 | 30.3 | 0.3 | +10.3 | 0.0 | 0.0 |
| PATHS CROSS | 0.3 | +25.1 | 0.0 | 0.0 | - | - | - | - |
| PLAN RESULT | 40.3 | +561.4 | 103.3 | 886.0 | 44.3 | +822.5 | 318.0 | 1063.7 |
| PROMISE BELOW ZERO | - | - | - | - | 0.3 | +0.0 | 0.0 | 65.0 |
| PROMISE BY ITS OWN SUM | 7.0 | -190.6 | 0.0 | 0.0 | 8.7 | -215.9 | 0.0 | 65.0 |
| PROMISE KNOWS THE FIGHT | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 65.0 |
| PROMISE READS THE TABLE | - | - | - | - | 0.7 | -0.9 | 0.0 | 0.0 |
| PROMISE SHOT AWAY | 0.3 | -0.8 | 63.0 | 36.7 | 0.7 | -4.1 | 0.0 | 0.0 |
| QUARTER ODDS | 15.3 | +1037.1 | 252.0 | 380.0 | 17.0 | +1905.3 | 73.3 | 0.0 |
| RANDOM MOVE BY FIGURES | 0.7 | +0.0 | 0.0 | 56.7 | - | - | - | - |
| REAL GROUND | - | - | - | - | 2.3 | +0.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | 2.3 | +31.3 | 0.0 | 0.0 | 1.0 | +21.6 | 0.0 | 66.0 |
| REDIRECT FOR A FRIEND IN REACH | 1.3 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 90.0 |
| REDIRECT WEIGHED | - | - | - | - | 0.3 | +9.5 | 0.0 | 0.0 |
| REFORMS TO MEET IT | - | - | - | - | 0.7 | -10.7 | 0.0 | 126.0 |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | 1.3 | +5.2 | 86.3 | 30.3 | 2.0 | +33.3 | 0.0 | 170.3 |
| ROUNDS AFTER TERROR | - | - | - | - | 2.0 | -60.9 | 0.0 | 314.0 |
| RUN DOWN | - | - | - | - | 2.0 | -8.6 | 0.0 | 314.0 |
| SCOUT SPOT | - | - | - | - | 2.0 | +1.8 | 0.0 | 48.0 |
| SCOUT WAITS | - | - | - | - | 2.0 | +0.0 | 0.0 | 48.0 |
| SCREEN BY WHAT IT SAVES | 0.7 | -149.3 | 0.0 | 0.0 | - | - | - | - |
| SEARCH SPOT | - | - | - | - | 0.7 | -1.3 | 0.0 | 0.0 |
| SECOND LOOK | 0.3 | +3.9 | 24.0 | 0.0 | 0.3 | +10.6 | 0.0 | 0.0 |
| SET CREDITED ONCE | - | - | - | - | 2.3 | -54.8 | 0.0 | 45.3 |
| SET UP BY THE SET | - | - | - | - | 4.0 | +5.7 | 0.0 | 69.3 |
| SET UP TOGETHER | - | - | - | - | 1.7 | +15.1 | 0.0 | 23.3 |
| SHOOTERS IN TWO RANKS | - | - | - | - | 0.3 | +1.3 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 12.3 | +0.0 | 0.0 | 583.3 | 12.0 | +0.0 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 4.0 | +131.3 | 148.0 | 0.0 | 1.7 | +19.9 | 0.0 | 0.0 |
| SHOT OR CHARGE | - | - | - | - | 2.0 | -12.4 | 310.0 | 0.0 |
| SHOT RISK POINTS | 26.7 | -178.8 | 0.0 | 103.3 | 33.7 | -26.1 | 0.0 | 636.3 |
| SHOTS AFTER THE MOVES | 4.0 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 14.7 | +328.7 | 0.0 | 686.7 | 21.0 | +380.0 | 0.0 | 112.0 |
| SPELLS IN THE FIGHT | - | - | - | - | 0.3 | +28.8 | 0.0 | 0.0 |
| SPOT AS THE GAME MOVES | 7.0 | +0.0 | 0.0 | 56.7 | 5.7 | +0.0 | 0.0 | 126.7 |
| STAND AND SHOOT | 0.7 | -1.4 | 42.3 | 0.0 | 0.7 | -3.7 | 103.3 | 0.0 |
| STANDS FOR A REASON | 0.7 | +0.0 | 0.0 | 0.0 | 6.3 | +0.0 | 310.0 | 88.0 |
| STANDS STILL | 44.0 | +0.0 | 492.3 | 1326.7 | 37.3 | +0.0 | 1291.3 | 175.0 |
| STANDS TO CAST | 0.3 | +0.2 | 0.0 | 0.0 | - | - | - | - |
| STAY WORTH | 29.3 | -568.5 | 172.7 | 1410.0 | 34.7 | +407.2 | 1256.7 | 22.0 |
| STRIKE BY THE ODDS | - | - | - | - | 0.3 | +33.8 | 0.0 | 0.0 |
| SUPPORT ADDS | 11.3 | +851.7 | 0.0 | 0.0 | 2.7 | +47.0 | 0.0 | 0.0 |
| SUPPORT WORKED OUT | 11.3 | +851.7 | 0.0 | 0.0 | 2.7 | +47.0 | 0.0 | 0.0 |
| SURE REACH TOGETHER | - | - | - | - | 1.7 | +8.3 | 0.0 | 22.0 |
| THE DEARER SUM KEEPS ITS PLAN | 0.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 22.0 |
| THE PROMISE ADDS | 0.7 | -21.5 | 0.0 | 0.0 | - | - | - | - |
| THE ROW IN ITS ORDER | 5.0 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 2.7 | +0.0 | 0.0 | 103.3 | 3.3 | +0.0 | 0.0 | 23.3 |
| THE STEP BACK IS MADE | 1.3 | +0.0 | 0.0 | 103.3 | 2.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 41.0 | +0.0 | 0.0 | 686.7 | 46.7 | +0.0 | 0.0 | 349.7 |
| TIED UP BY THE SUM | 0.7 | +31.4 | 46.0 | 0.0 | 0.7 | +36.8 | 0.0 | 0.0 |
| TIME ON OUR SIDE | 22.0 | +293.3 | 0.0 | 103.3 | 13.7 | +143.8 | 0.0 | 113.0 |
| TWO OR MORE ARRIVE | - | - | - | - | 0.7 | +0.8 | 0.0 | 23.3 |
| WAITS AGAIN | 0.7 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| WAR ENGINE JOBS | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WEAPON BY POINTS | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| WHO FIGHTS | 0.3 | -0.2 | 24.0 | 0.0 | 0.3 | +8.6 | 0.0 | 0.0 |
| WHO HITS BACK | 0.7 | +67.5 | 0.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT DANGER | 2.3 | -481.7 | 0.0 | 160.0 | - | - | - | - |
| WOUNDED STAYS OUT | - | - | - | - | 0.3 | +0.0 | 0.0 | 170.3 |
| WOUNDS ON THE RANKS | 3.0 | +116.3 | 0.0 | 0.0 | 1.3 | +50.9 | 0.0 | 0.0 |

### Rule changes: cnomg-c940641-p14

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS MOVE AS HE DECIDES | 140 | 140 | 100 | 33.33 | +0 | +0.0 |
| HIS SHOT LIST | 340 | 327 | 86 | 28.67 | +1029 | +12.0 |
| ARMY TABLE | 127 | 127 | 82 | 27.33 | +1992 | +24.3 |
| HOLDER ASSIGNMENT | 58 | 58 | 54 | 18.00 | +3767 | +69.8 |
| HIS SHOTS BY HIS RUN | 250 | 236 | 44 | 14.67 | +432 | +9.8 |
| OFF BEST | 37 | 37 | 37 | 12.33 | -1024 | -27.7 |
| HIS MOVE WHY | 58 | 58 | 36 | 12.00 | +0 | +0.0 |
| LEGAL CHARGES ONLY | 35 | 35 | 35 | 11.67 | +0 | +0.0 |
| SHOT RISK POINTS | 181 | 168 | 35 | 11.67 | +632 | +18.0 |
| DEPLOY BY FIGURES | 49 | 49 | 32 | 10.67 | +405 | +12.6 |
| THE TABLE AGAIN | 36 | 36 | 28 | 9.33 | +0 | +0.0 |
| FIVE ACTION | 564 | 545 | 22 | 7.33 | +1190 | +54.1 |
| SUPPORT ADDS | 42 | 42 | 21 | 7.00 | +647 | +30.8 |
| SUPPORT WORKED OUT | 42 | 42 | 21 | 7.00 | +647 | +30.8 |
| HIS ONE MOVE | 53 | 50 | 20 | 6.67 | +0 | +0.0 |
| GOAL WALK | 93 | 91 | 19 | 6.33 | +1309 | +68.9 |
| TIME ON OUR SIDE | 107 | 89 | 19 | 6.33 | +51 | +2.7 |
| PROMISE BY ITS OWN SUM | 47 | 47 | 17 | 5.67 | -1220 | -71.7 |
| ARTILLERY RE-ROLL WEIGHED | 15 | 15 | 15 | 5.00 | +0 | +0.0 |
| REDIRECT FOR A FRIEND IN REACH | 11 | 11 | 11 | 3.67 | +0 | +0.0 |
| SHOOTS FROM THE BEST SPOT | 17 | 17 | 11 | 3.67 | +66 | +6.0 |
| COVER ONCE | 45 | 33 | 10 | 3.33 | +126 | +12.6 |
| HARD STAY DROPPED | 10 | 10 | 10 | 3.33 | +0 | +0.0 |
| MOVE TO CHARGE COMPUTED | 22 | 15 | 10 | 3.33 | +133 | +13.3 |
| QUARTER ODDS | 97 | 95 | 10 | 3.33 | +743 | +74.3 |
| FOUR ROUNDS | 15 | 13 | 8 | 2.67 | +659 | +82.3 |
| MAX FOR POSITIONING | 15 | 15 | 8 | 2.67 | +33 | +4.2 |
| CANNON PLANNED TARGET | 36 | 36 | 7 | 2.33 | +0 | +0.0 |
| CHARGE LOSSES | 99 | 89 | 7 | 2.33 | +355 | +50.7 |
| NEXT CHARGE BY LIST | 14 | 11 | 7 | 2.33 | +119 | +17.0 |
| CANNON SIGHT KEPT | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| FALLS SHORT | 68 | 56 | 6 | 2.00 | +71 | +11.8 |
| FOLLOW UP WEIGHED | 6 | 6 | 6 | 2.00 | +1288 | +214.7 |
| MEETS IN TIME | 15 | 15 | 6 | 2.00 | +516 | +86.1 |
| SCOUT WAITS | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| STAY WORTH | 192 | 169 | 6 | 2.00 | +60 | +10.0 |
| ADVANCE LANE KEPT | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| LONE WIZARD KEPT IN | 5 | 5 | 5 | 1.67 | +288 | +57.5 |
| MOVE ORDER | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| CHARGE NOW FIRST | 7 | 7 | 4 | 1.33 | -276 | -69.0 |
| COMBAT PIVOT | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| IDLE COST | 69 | 39 | 4 | 1.33 | +51 | +12.7 |
| LANE BY FIGURES | 4 | 4 | 4 | 1.33 | +137 | +34.3 |
| MANOEUVRE | 12 | 12 | 4 | 1.33 | +53 | +13.3 |
| REDIRECT COUNTER | 10 | 6 | 4 | 1.33 | +97 | +24.2 |
| SET UP BY THE SET | 12 | 12 | 4 | 1.33 | +70 | +17.6 |
| CASTING BLOCK | 3 | 3 | 3 | 1.00 | +69 | +23.1 |
| CHALLENGE BY POINTS | 3 | 3 | 3 | 1.00 | +51 | +17.1 |
| HOLDS AMBUSHERS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| MARCH CHECK | 3 | 3 | 3 | 1.00 | +29 | +9.8 |
| NEARER NOT NEEDED | 48 | 44 | 3 | 1.00 | +130 | +43.3 |
| OGRE LOADER SECOND SHOT | 3 | 3 | 3 | 1.00 | +1 | +0.2 |
| ONE OBJECTIVE FORMULA | 27 | 23 | 3 | 1.00 | +53 | +17.7 |
| PROMISE SHOT AWAY | 3 | 3 | 3 | 1.00 | -15 | -4.9 |
| SHOTS AFTER THE MOVES | 25 | 25 | 3 | 1.00 | +0 | +0.0 |
| CAST JOB | 10 | 10 | 2 | 0.67 | +0 | +0.0 |
| CASTER AWAY FROM SCREEN | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| CHAFF IN THE MOVE | 3 | 3 | 2 | 0.67 | +1 | +0.3 |
| KEEP FALLS | 2 | 2 | 2 | 0.67 | +89 | +44.6 |
| MISSILES IN THE MOVE | 16 | 7 | 2 | 0.67 | +13 | +6.4 |
| RISK BY ARC | 10 | 8 | 2 | 0.67 | +25 | +12.5 |
| SECOND LOOK | 2 | 2 | 2 | 0.67 | +43 | +21.6 |
| SURE REACH TOGETHER | 5 | 5 | 2 | 0.67 | +3 | +1.5 |
| THE ROW IN ITS ORDER | 21 | 2 | 2 | 0.67 | +0 | +0.0 |
| TIED UP BY THE SUM | 4 | 2 | 2 | 0.67 | +38 | +18.9 |
| WEAPON BY POINTS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| WHO HITS BACK | 2 | 2 | 2 | 0.67 | +91 | +45.3 |
| AFTERMATH IN POINTS | 1 | 1 | 1 | 0.33 | +594 | +594.3 |
| BEST PRIZE | 1 | 1 | 1 | 0.33 | -30 | -29.6 |
| CHAFF PASSED | 1 | 1 | 1 | 0.33 | -2 | -2.2 |
| EXACT ROUND | 8 | 7 | 1 | 0.33 | +18 | +17.6 |
| FEATURE BUFFS | 30 | 30 | 1 | 0.33 | +34 | +33.9 |
| FIGHT TO THE END | 6 | 6 | 1 | 0.33 | +64 | +64.3 |
| HIS TURN DENIED | 7 | 7 | 1 | 0.33 | +5 | +5.0 |
| MARCH BY THE SUM | 1 | 1 | 1 | 0.33 | +11 | +11.4 |
| MARCH OF THE TABLE | 1 | 1 | 1 | 0.33 | -30 | -30.0 |
| MOVES UNITS SPELL | 1 | 1 | 1 | 0.33 | +55 | +55.1 |
| ONE JOINT FIGURE | 1 | 1 | 1 | 0.33 | +298 | +298.1 |
| PATHS CROSS | 1 | 1 | 1 | 0.33 | +75 | +75.2 |
| REDIRECT WEIGHED | 1 | 1 | 1 | 0.33 | -30 | -29.6 |
| SET UP TOGETHER | 5 | 3 | 1 | 0.33 | +14 | +13.8 |
| SHOOTERS IN TWO RANKS | 1 | 1 | 1 | 0.33 | +4 | +4.0 |
| SHOTS IN THE MOVE | 107 | 74 | 1 | 0.33 | +32 | +31.5 |
| SPELLS IN THE FIGHT | 1 | 1 | 1 | 0.33 | +18 | +17.6 |
| STANDS TO CAST | 1 | 1 | 1 | 0.33 | -0 | -0.2 |
| STRIKE BY THE ODDS | 1 | 1 | 1 | 0.33 | +18 | +17.6 |
| WHO FIGHTS | 2 | 1 | 1 | 0.33 | +18 | +17.6 |
| WOUNDED STAYS OUT | 1 | 1 | 1 | 0.33 | -3 | -2.8 |
| WOUNDS ON THE RANKS | 13 | 11 | 1 | 0.33 | +5 | +5.1 |
| CANNON PLAN MISSED | 3 | 3 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 2 | trace | - | - | - | - |
| CLOSES ON WHAT IT BEATS | 62 | 61 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 3 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 3 | 3 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 1 | 1 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 12 | 11 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 32 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 30 | 29 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 4 | 4 | 0 | 0.00 | - | - |
| GIVES UP | 5 | 4 | 0 | 0.00 | - | - |
| GROUND FLIERS | 1 | not checked | - | - | - | - |
| GUN FIGURES | 9 | not checked | - | - | - | - |
| HE REFORMS ONCE FREED | 14 | 14 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 42 | 35 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 28 | 26 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 20 | 20 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 12 | 12 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 21 | 19 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 25 | 22 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 10 | 10 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN RUN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 105 | 105 | 0 | 0.00 | - | - |
| HONEST WORTH | 14 | 12 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 17 | 17 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 1 | 1 | 0 | 0.00 | - | - |
| LONG SHOT | 1 | 1 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 4 | 4 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 3 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 2 | trace | - | - | - | - |
| MARCH OVER CASTS | 2 | 2 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 7 | 7 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 24 | 14 | 0 | 0.00 | - | - |
| MOVE SPELL SPOT | 2 | not checked | - | - | - | - |
| NEXT OBJECTIVE NEARER | 2 | 2 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 14 | 12 | 0 | 0.00 | - | - |
| NO LATE CUT | 2 | 2 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 18 | 18 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 1 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 23 | 13 | 0 | 0.00 | - | - |
| ONE ROUTE | 7 | 7 | 0 | 0.00 | - | - |
| OPENS A LANE | 1 | 1 | 0 | 0.00 | - | - |
| OVERRUNS AWAY | 2 | 2 | 0 | 0.00 | - | - |
| PLAN RESULT | 254 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE KNOWS THE FIGHT | 2 | 1 | 0 | 0.00 | - | - |
| PROMISE READS THE TABLE | 2 | 2 | 0 | 0.00 | - | - |
| RANDOM MOVE BY FIGURES | 2 | 2 | 0 | 0.00 | - | - |
| REAL GROUND | 7 | 7 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 2 | 2 | 0 | 0.00 | - | - |
| REFUSING RETIRES | 1 | 1 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 6 | 6 | 0 | 0.00 | - | - |
| RUN DOWN | 6 | 5 | 0 | 0.00 | - | - |
| SCOUT SPOT | 6 | 6 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 2 | 2 | 0 | 0.00 | - | - |
| SEARCH SPOT | 2 | 2 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 7 | 7 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 73 | not checked | - | - | - | - |
| SHOT OR CHARGE | 6 | 6 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 38 | 30 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 4 | 3 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 21 | 20 | 0 | 0.00 | - | - |
| STANDS STILL | 244 | 238 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 6 | not checked | - | - | - | - |
| THE PROMISE ADDS | 2 | 2 | 0 | 0.00 | - | - |
| THE ROW KEEPS ITS WAY | 18 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 10 | not checked | - | - | - | - |
| THE TABLE BINDS | 263 | not checked | - | - | - | - |
| TWO OR MORE ARRIVE | 2 | not checked | - | - | - | - |
| WAITS AGAIN | 10 | 10 | 0 | 0.00 | - | - |
| WAR ENGINE JOBS | 5 | 5 | 0 | 0.00 | - | - |
| WHOLE FIGHT DANGER | 7 | 7 | 0 | 0.00 | - | - |

### Off best figure: cnomg-c940641-p14

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 5.00 | 5.00 | 33.6 |
| PROMISE BY ITS OWN SUM | rule | 2.67 | 3.00 | 71.7 |
| ARMY TABLE | rule | 1.33 | 1.00 | 62.3 |
| AFTERMATH BAND | gate | 1.33 | - | 0.9 |
| CHARGE NOW FIRST | rule | - | 1.33 | 69.0 |
| HOLDER ASSIGNMENT | rule | - | 1.00 | 11.6 |
| PROMISE SHOT AWAY | rule | 0.33 | 0.67 | 4.9 |
| FIGHT ORDER BAND | gate | 0.33 | 0.33 | 2.5 |
| BEST PRIZE | rule | - | 0.33 | 29.6 |
| CHAFF PASSED | rule | 0.33 | - | 2.2 |
| FOLLOW UP WEIGHED | rule | 0.33 | - | 0.7 |
| MARCH OF THE TABLE | rule | - | 0.33 | 30.0 |
| REDIRECT WEIGHED | rule | - | 0.33 | 29.6 |
| RULE SWITCHED OFF | gate | 0.33 | - | 6.8 |
| WOUNDED STAYS OUT | rule | - | 0.33 | 2.8 |

### Plans: cnomg-c940641-p14

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.3 | 100% | 43 | 81 | 189% |
| Mine | move | 26.3 | 96% | 1288 | 0 | 0% |
| Mine | shoot | 12.3 | 41% | 222 | 480 | 216% |
| Mine | support | 0.3 | 100% | 0 | 0 | 0% |
| Opponent | charge | 3.3 | 30% | 452 | 176 | 39% |
| Opponent | move | 32.3 | 93% | 2138 | 0 | 0% |
| Opponent | shoot | 8.7 | 58% | 528 | 646 | 122% |

### Battle groups: cnomg-c940641-p14

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 2.3 | 29% | 100% | 0% | - | 0% | 0% | 0% | 50% | 50% |
| Opponent | REDIRECT COUNTER | 1.0 | 100% | 100% | 0% | - | 67% | 0% | 0% | 33% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: cnomg-c940641-p14

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Mine | Character | 7 | 101 (7) | 101 | 0 | 0 | 14% | 2.5 | 0 (1) | 65 (1) | 118 (5) | 113 (6) | 0 (1) |
| Mine | Clean-up | 4 | 42 (4) | 18 | 24 | 24 | 50% | 5.0 | 0 (1) | 56 (3) | - | 32 (3) | 73 (1) |
| Mine | Fast Hammer | 5 | 39 (5) | 39 | 0 | 16 | 80% | 1.0 | - | 81 (3) | 0 (2) | 46 (4) | 0 (1) |
| Mine | Hammer | 9 | 23 (9) | 17 | 5 | 20 | 11% | 2.2 | 0 (1) | 6 (4) | 48 (4) | 30 (7) | 0 (2) |
| Mine | Holder | 1 | 0 (1) | 0 | 0 | 100 | 0% | 4.0 | 0 (1) | - | - | - | 0 (1) |
| Mine | War machine | 8 | 17 (8) | 17 | 0 | 79 | 0% | 1.0 | 21 (2) | 20 (5) | 0 (1) | 16 (3) | 17 (5) |
| Mine | Wizard | 5 | 20 (5) | 20 | 0 | 0 | 80% | 2.0 | 0 (1) | 0 (2) | 47 (2) | 47 (2) | 0 (3) |
| Opponent | Chaff | 5 | 0 (5) | 0 | 0 | 100 | 20% | 1.2 | 0 (1) | 0 (4) | - | 0 (5) | - |
| Opponent | Character | 8 | 20 (8) | 20 | 0 | 38 | 50% | 2.0 | 34 (3) | 0 (2) | 23 (3) | 24 (6) | 0 (2) |
| Opponent | Clean-up | 4 | 49 (4) | 0 | 49 | 14 | 100% | - | 0 (2) | 0 (1) | 101 (1) | 57 (3) | 0 (1) |
| Opponent | Fast Hammer | 6 | 8 (6) | 8 | 0 | 49 | 50% | 5.0 | 16 (3) | 0 (3) | - | 0 (2) | 12 (4) |
| Opponent | Holder | 9 | 66 (9) | 9 | 57 | 19 | 0% | 2.0 | 0 (2) | 57 (4) | 114 (3) | 145 (4) | 0 (5) |
| Opponent | Shooter | 2 | 124 (2) | 31 | 93 | 0 | 0% | 2.5 | 59 (1) | 194 (1) | - | 59 (1) | 194 (1) |
| Opponent | War machine | 3 | 96 (3) | 96 | 0 | 33 | 33% | 1.0 | 96 (3) | - | - | 0 (2) | 288 (1) |
| Opponent | Wizard | 3 | 0 (3) | 0 | 0 | 0 | 0% | 1.0 | 0 (1) | 0 (2) | - | 0 (1) | 0 (2) |

### Charged fights: cnomg-c940641-p14

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 1 | 144 | 377 | 3.0 | 1.0 | 126 | 0 | +126 | 1 of 3 | 3 of 3 | - | +126 |
| Mine | Chaos Dwarfs | 2 | 192 | 66 | 1.0 | 1.0 | 66 | 46 | +20 | 0 of 2 | 2 of 2 | - | +20 |
| **Mine** | all armies | 3 | 176 | 170 | 1.7 | 1.0 | 102 | 18 | +84 | 1 of 5 | 5 of 5 | - | +84 |
| Opponent | Empire of Man | 1 | 360 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 1 of 1 | 0 of 1 | - | +0 |
| Opponent | Tomb Kings of Khemri | 2 | 81 | 240 | 3.5 | 1.0 | 69 | 135 | -66 | 4 of 7 | 4 of 7 | - | -66 |
| **Opponent** | all armies | 3 | 174 | 160 | 2.7 | 1.0 | 60 | 118 | -58 | 5 of 8 | 4 of 8 | - | -58 |

### Effective charges: cnomg-c940641-p14

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 3 | 0 | 1 (net +55) | 0 | 0 | 0 | 0 | 2 | 0% (0 of 1) |
| Mine | Chaos Dwarfs | 2 | 0 | 0 | 0 | 0 | 1 (net +66) | 1 (net -25) | 0 | 0% (0 of 2) |
| Opponent | Tomb Kings of Khemri | 7 | 3 (net -257) | 0 | 0 | 2 (net +155) | 0 | 2 (net +0) | 0 | 0% (0 of 7) |

### Charged fights, damage counted: cnomg-c940641-p14

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 50-54% | 1 | 85 | 55 | +55 | 55 | 0 | +55 | +64.7 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 91 | 66 | -25 | 66 | 91 | -25 | -27.5 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 310 | 66 | +66 | 66 | 0 | +66 | +21.3 |
| Mine | No odds | 2 | 162 | 134 | +161 | 161 | 9 | +152 | +94.0 |
| Mine | All fights | 5 | 162 | 91 | +84 | 102 | 22 | +80 | +49.5 |
| Opponent | Long shot (under 50%) | 3 | 418 | 272 | -257 | 57 | 314 | -257 | -61.6 |
| Opponent | 76-89% | 2 | 436 | 240 | +155 | 288 | 147 | +141 | +32.4 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 195 | 90 | +0 | 45 | 16 | +28 | +14.6 |
| Opponent | No odds | 1 | 380 | 314 | +0 | 52 | 190 | -138 | -36.2 |
| Opponent | All fights | 8 | 362 | 224 | -58 | 111 | 182 | -71 | -19.7 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| cnomg-c940641-p14 | move | 12 | 2 (17%) | 2 (17%) | 2 (17%) | 8 (67%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Ring of Doom | Mine | L0222 |
| Twice-Blessed Armour | Opponent | L0307 |
| Witch Hunter's Ward | Opponent | L0307 |

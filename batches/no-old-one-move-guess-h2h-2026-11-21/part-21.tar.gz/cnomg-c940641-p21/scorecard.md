# Doctrine scorecard: cnomg-c940641-p21

### Scorecard: cnomg-c940641-p21

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L1531 | 1 | 1 | Mine | no | 0 | 4 | 3 | 1 | 0 | 0 | 0 | 0 |
| L1531 | 1 | 1 | Opponent | no | 0 | - | 0 | 2 | 1 | 0 | 0 | 340 |
| L1629 | 3 | 1 | Mine | no | 10 | 2 | 2 | 0 | 0 | 0 | 0 | 200 |
| L1629 | 3 | 1 | Opponent | no | 2 | 3 | 4 | 2 | 0 | 0 | 0 | 0 |
| L1727 | 5 | 1 | Mine | yes | - | 3 | 5 | 1 | 0 | 0 | 0 | 83 |
| L1727 | 5 | 1 | Opponent | yes | - | 3 | 3 | 3 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 33% | 5.0 | 3.0 | 3.3 | 0.7 | 0.0 | 0.0 | 0.0 | 94.3 |
| **Average** | | | Opponent | 33% | 1.0 | 3.0 | 2.3 | 2.3 | 0.3 | 0.0 | 0.0 | 113.3 |

### KPIs: cnomg-c940641-p21

Rules off - Mine only: NO OLD ONE-MOVE GUESS.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 17) | 0% (0 of 15) | 0% (0 of 32) |
| Winner chose to follow up after the loser gave ground |  | 85% (11 of 13); on the table 92% | 75% (3 of 4); on the table 75% | 82% (14 of 17); on the table 88% |
| Winner chose to pursue after the loser fell back in good order |  | - | 50% (1 of 2); on the table 50% | 50% (1 of 2); on the table 50% |
| Winner chose to pursue after the loser fled |  | 100% (1 of 1); on the table 100% | 0% (0 of 2); on the table 50% | 33% (1 of 3); on the table 67% |
| Winner chose to follow up or pursue (all three) |  | 86% (12 of 14); on the table 93% | 50% (4 of 8); on the table 62% | 73% (16 of 22); on the table 82% |
| Magic missiles tried each own turn | 50%+ | - | 25% (3 of 12) | 25% (3 of 12) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | - | 27% (3 of 11) | 27% (3 of 11) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 46% (6 of 13) | 46% (6 of 13) |
| Points that never fought | lower | 36% (2132 of 6000) | 36% (2187 of 5999) | 36% (4319 of 11999) |
|   infantry points that never fought | lower | 44% (584 of 1332) | 55% (472 of 855) | 48% (1056 of 2187) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 55% (11 of 20) | 72% (18 of 25) | 64% (29 of 45) |
| Bound items with a magic missile used (at least once a game) |  | 100% (2 of 2); 2.0 uses a game | 100% (1 of 1); 0.7 uses a game | 100% (3 of 3); 1.3 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 100% (1 of 1); 0.3 uses a game | 0.0 uses a game | 100% (1 of 1); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 48% (2471 of 5135) | 61% (3315 of 5430) | 55% (5786 of 10565) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | - | 2.0 (67%) | 2.0 (67%) |
| MARCHED: its unit marched | - | 0.7 (22%) | 0.7 (22%) |
| GONE: slain | - | 0.3 (11%) | 0.3 (11%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 3.7 | 1.7 | 0.0 | 1.0 | 2.3 |
| not cast | 6.3 | 0.3 | 2.0 | 3.0 | 17.7 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (4%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.0 (67%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (22%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.3 (5%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | 0.7 (11%) | 0.0 (0%) | 0.0 (0%) | 0.3 (11%) | 0.7 (4%) |
| STUPIDITY: Stupidity | 0.7 (11%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.3 (100%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 4.7 (74%) | 0.0 (0%) | 2.0 (100%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 16.3 (92%) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 51% (41 of 80) | 38% (3 of 8) | 50% (44 of 88) |
|   cavalry | 78% (7 of 9) | 60% (3 of 5) | 71% (10 of 14) |
|   character | 40% (4 of 10) | 0% (0 of 3) | 31% (4 of 13) |
|   chariot | 33% (2 of 6) | - | 33% (2 of 6) |
|   infantry | 50% (19 of 38) | - | 50% (19 of 38) |
|   monster | 43% (6 of 14) | - | 43% (6 of 14) |
|   war machine | 100% (3 of 3) | - | 100% (3 of 3) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.7 (13%) | 0.3 (20%) | 2.0 (14%) |
| CHARGED: it charged | 1.7 (13%) | 0.0 (0%) | 1.7 (11%) |
| IN COMBAT: it fought this turn or the last | 1.3 (10%) | 0.0 (0%) | 1.3 (9%) |
| NO TARGET IN RANGE | 3.0 (23%) | 0.3 (20%) | 3.3 (23%) |
| ONLY IN COMBAT: the only targets were in combat | 3.3 (26%) | 0.0 (0%) | 3.3 (23%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 2.0 (15%) | 0.3 (20%) | 2.3 (16%) |
| STUPIDITY | 0.0 (0%) | 0.7 (40%) | 0.7 (5%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 3.3 | 0.0 | 100% | 0.0 pts | 0 pts |
| character | 2.0 | 0.3 | 83% | 6.4 pts | 13 pts |
| chariot | 0.7 | 0.0 | 100% | 0.0 pts | 0 pts |
| infantry | 11.3 | 2.0 | 85% | 5.4 pts | 61 pts |
| monster | 2.0 | 0.3 | 83% | 1.5 pts | 3 pts |
| war machine | 1.0 | 0.0 | 100% | 0.0 pts | 0 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.3 | 3.3 | 3.8 |
| Charges that made contact a game | 3.7 | 2.3 | 3.0 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | - | 0.00 declared, 0.00 contact (2 units) | 0.00 declared, 0.00 contact (2 units) |
|   per unit a game, units carrying another wizard (or one alone) | 1.00 declared, 0.33 contact (3 units) | 1.33 declared, 1.33 contact (3 units) | 1.17 declared, 0.83 contact (6 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.48 declared, 0.48 contact (21 units) | 0.33 declared, 0.17 contact (18 units) | 0.41 declared, 0.33 contact (39 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 100% (5 of 5) | 33% (1 of 3) | 50% (1 of 2) | 70% (7 of 10) |
| Character in a unit | 100% (3 of 3) | - | 100% (1 of 1) | 100% (4 of 4) |
| Character on its own | 75% (3 of 4) | 100% (2 of 2) | 25% (2 of 8) | 50% (7 of 14) |
| Chariot | 100% (1 of 1) | - | - | 100% (1 of 1) |
| Infantry | 86% (6 of 7) | 0% (0 of 3) | - | 60% (6 of 10) |
| Monster | 67% (4 of 6) | - | - | 67% (4 of 6) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| High Elf Realms | 1 | 50% (1 of 2); on the table 50% | - | 47% | 71% (5 of 7) | 100% (2 of 2); 6.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | 86% (6 of 7); on the table 100% | - | 28% | 50% (3 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Lizardmen | 1 | 100% (5 of 5); on the table 100% | - | 31% | 43% (3 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 1 | 100% (2 of 2); on the table 100% | 0% (0 of 6) | 27% | 67% (4 of 6) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 2 | 33% (2 of 6); on the table 50% | 50% (3 of 6) | 41% | 74% (14 of 19) | 100% (1 of 1); 1.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (cnomg-c940641-p21, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 67% (2) | 75% (6) | 73% (8) |
| ...free all their last turn and able to turn (per game) | 0.67 | 1.33 | 2.00 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.33 | 0.33 |
| ...with the charger already in that arc before they moved (per game) | 0.67 | 1.00 | 1.67 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 1.67 | 1.67 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.33 | 0.33 |

### Quality by phase: cnomg-c940641-p21

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.3 | 4.3 |
| Strategy | Charge objectives carried out (made contact) | 70% (7 of 10) | 62% (5 of 8) |
| Strategy | Shoot objectives carried out (shot that target) | 58% (7 of 12) | 0% (0 of 4) |
| Strategy | Support requests answered (helper made contact too) | 100% (1 of 1) | 0% (0 of 1) |
| Strategy | Joined characters whose unit fought | - | 25% (1 of 4) |
| Strategy | Lone characters that fought | 78% (7 of 9) | 78% (7 of 9) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 0.7 | 2.3 |
| Movement | Points that never moved of their own | 94.3 | 113.3 |
| Movement | Fights charged into per game | 3.3 | 2.3 |
| Movement | Charges with odds: long shots (under 50%) | 2 of 6, net -92 | 2 of 5, net +30 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 6 | 0 of 5 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 1 of 6, net +120 | 2 of 5, net +90 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 of 6, net +184 | 1 of 5, net +0 |
| Shooting | Shots by shooting units (incl. breath weapons) | 14.0 | 2.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 36% (15 of 42) | 50% (3 of 6) |
| Shooting | Points destroyed by shooting units | 0.0 | 0.0 |
| Shooting | War machine shots | 1.0 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 100% (3 of 3) | - |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | - | 0.7 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | - | 50% (1 of 2) |
| Magic | Wounds caused by magic missiles | 2.7 | 0.7 |
| Magic | Wounds caused by other spells | - | 0.7 |
| Magic | Points destroyed by magic (all spells) | 16.7 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.3 / 1.0 / 0.3 / 0.0 | 1.7 / 0.0 / 0.7 / 0.0 |
| Combat | Points destroyed in combat | 263.7 | 242.0 |
| Combat | Points run down | 0.0 | 0.0 |
| Combat | Net points per charged fight, damage counted | +59 | +17 |
| Combat | Net per 100 charger points, damage counted | +15.8 | +5.5 |
| Combat | First round won (charged fights) | 90% | 71% |
| Combat | Net points per charged fight | +75 | +59 |
| Combat | Net points per supported fight / lone fight | +120 / +70 | - / +59 |
| Combat | Charged fights on a top-3 enemy unit | 3 of 10 | 2 of 7 |
| Game | Points lost | 446.0 | 367.0 |
| Game | VP from objectives | 603.3 | 693.3 |
| Game | Lone holders (player turns) | 5.0 | 1.0 |

- Mine won / drew / lost: 1 / 1 / 1 of 3 ended games (of 3); mean margin (Mine - Opponent) -108 VP
- The side that went first won 0 of 2 games with a winner
- Points traded per game (both sides' losses): 813
- Games not ended: 0; findings 1, warnings 0

### Opponent rules: cnomg-c940641-p21

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.7 | +103.8 | 0.0 | 0.0 | 0.3 | +23.6 | 0.0 | 0.0 |
| ARMY TABLE | 19.7 | +355.7 | 0.0 | 80.0 | 29.7 | -287.4 | 0.0 | 304.7 |
| ARRIVAL HUNT | - | - | - | - | 0.3 | +1.1 | 0.0 | 0.0 |
| BACKUP TARGETS | 0.7 | +3.0 | 0.0 | 0.0 | - | - | - | - |
| BLOWS WHERE AIMED | 0.7 | -27.9 | 40.0 | 0.0 | - | - | - | - |
| CANNON PLANNED TARGET | 1.0 | +0.0 | 0.0 | 66.7 | - | - | - | - |
| CANNON SIGHT KEPT | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CAST JOB | 0.3 | +1.4 | 0.0 | 0.0 | 0.7 | +89.1 | 288.0 | 0.0 |
| CASTS FROM BEHIND | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | 1.0 | +176.1 | 0.0 | 0.0 | 2.7 | +119.0 | 0.0 | 0.0 |
| CHALLENGE BY POINTS | 0.3 | +18.2 | 0.0 | 0.0 | 1.0 | +37.8 | 0.0 | 0.0 |
| CHAMPION KNOWS CHALLENGE | - | - | - | - | 0.3 | -15.0 | 0.0 | 0.0 |
| CHARGE LIST READ AGAIN | - | - | - | - | 0.3 | +57.0 | 26.7 | 0.0 |
| CHARGE LOSSES | 6.0 | -425.3 | 0.0 | 42.0 | 13.7 | -697.9 | 0.0 | 141.7 |
| CHARGE NOW FIRST | 1.7 | +0.0 | 158.7 | 0.0 | 2.0 | +0.0 | 118.3 | 62.0 |
| CLOSES ON WHAT IT BEATS | 6.0 | +0.0 | 0.0 | 0.0 | 8.0 | +0.0 | 0.0 | 33.3 |
| COMBAT PIVOT | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| COVER ONCE | 9.7 | -539.0 | 0.0 | 42.0 | 8.0 | -989.2 | 0.0 | 98.7 |
| DENIED BY THE FIGHT | 0.3 | -0.2 | 0.0 | 0.0 | - | - | - | - |
| DEPLOY BY FIGURES | 7.3 | -26.0 | 0.0 | 33.3 | 6.3 | +63.8 | 0.0 | 15.0 |
| DUEL STOPS AT THE KILL | - | - | - | - | 0.3 | -6.2 | 0.0 | 0.0 |
| EXACT ROUND | 2.3 | +33.1 | 192.0 | 0.0 | 2.3 | +18.6 | 145.0 | 62.0 |
| FACES THE THREAT | - | - | - | - | 0.7 | +38.7 | 0.0 | 0.0 |
| FALL BACK GOOD ORDER | 3.0 | +0.0 | 158.7 | 61.7 | 3.3 | +5.0 | 171.7 | 62.0 |
| FALLBACK BY WORTH | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| FALLS SHORT | 4.3 | +81.4 | 0.0 | 26.7 | 18.7 | +315.8 | 0.0 | 126.7 |
| FEATURE BUFFS | 1.0 | +15.2 | 0.0 | 0.0 | 1.3 | +112.2 | 0.0 | 0.0 |
| FIGHT TO THE END | 1.0 | +43.1 | 0.0 | 0.0 | 1.7 | +20.0 | 0.0 | 62.0 |
| FIRE AND FLEE | 0.3 | +1.1 | 0.0 | 26.7 | - | - | - | - |
| FIVE ACTION | 80.7 | +6779.4 | 278.7 | 502.3 | 76.3 | +6102.1 | 583.0 | 697.0 |
| FLANK NOT WEIGHED | 7.3 | +0.0 | 0.0 | 58.3 | 10.7 | +0.0 | 0.0 | 107.0 |
| FOLLOW UP WEIGHED | 0.7 | +204.6 | 0.0 | 0.0 | 1.0 | +232.1 | 0.0 | 0.0 |
| FOUR ROUNDS | 3.7 | +277.3 | 248.7 | 61.7 | 3.3 | +185.7 | 171.7 | 62.0 |
| FREED FROM HIS FIGHT | 4.0 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 25.0 |
| FRIEND CHARGES FIRST | - | - | - | - | 0.3 | -35.7 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 1.7 | -16.2 | 0.0 | 0.0 | - | - | - | - |
| GIVES UP | 1.0 | -9.2 | 0.0 | 61.7 | - | - | - | - |
| GOAL WALK | 9.0 | +748.1 | 0.0 | 0.0 | 8.7 | +715.9 | 0.0 | 96.0 |
| HARD STAY DROPPED | 2.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS CHARGE BY HIS RUN | 4.0 | +0.0 | 0.0 | 42.0 | 9.3 | +0.0 | 0.0 | 96.7 |
| HIS CHARGE LIST | 3.0 | +0.0 | 0.0 | 0.0 | 7.3 | +0.0 | 0.0 | 95.3 |
| HIS LEGAL MOVES | 7.0 | +0.0 | 0.0 | 26.7 | 6.3 | +0.0 | 0.0 | 65.0 |
| HIS MOVE AND SHOT | 0.3 | -10.8 | 0.0 | 0.0 | 3.0 | -10.3 | 0.0 | 0.0 |
| HIS MOVE AS HE DECIDES | 39.3 | +9.0 | 340.3 | 0.0 | - | - | - | - |
| HIS MOVE WHY | - | - | - | - | 28.3 | +0.0 | 0.0 | 180.3 |
| HIS ONE MOVE | 27.7 | -107.9 | 0.0 | 0.0 | - | - | - | - |
| HIS ONE QUARTER | 5.7 | +0.0 | 0.0 | 26.7 | 7.0 | +0.0 | 0.0 | 65.0 |
| HIS OWN BEST MOVE | 3.7 | +0.0 | 0.0 | 26.7 | 7.3 | +0.0 | 0.0 | 95.0 |
| HIS RANDOM MOVE | 12.3 | +0.0 | 0.0 | 68.7 | - | - | - | - |
| HIS RANDOM MOVER COMES | 1.7 | +0.0 | 0.0 | 42.0 | - | - | - | - |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 14.7 | +345.4 | 0.0 | 26.7 | 34.7 | +570.4 | 0.0 | 307.7 |
| HIS SHOTS BY HIS RUN | 12.0 | +156.2 | 0.0 | 26.7 | 32.0 | +491.6 | 0.0 | 266.3 |
| HIS TURN DENIED | 0.7 | +50.2 | 65.0 | 0.0 | 1.0 | +3.6 | 80.0 | 0.0 |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 10.7 | +0.0 | 0.0 | 95.3 | 16.7 | +0.0 | 0.0 | 136.0 |
| HOLDER ASSIGNMENT | 7.3 | +622.1 | 0.0 | 95.3 | 9.0 | +723.4 | 0.0 | 68.0 |
| HOLDS AMBUSHERS | 0.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 3.7 | -195.5 | 248.7 | 61.7 | 2.7 | -80.0 | 171.7 | 62.0 |
| HUNT IN PAIRS | 0.7 | +20.9 | 0.0 | 0.0 | - | - | - | - |
| IDLE COST | 0.3 | -1.1 | 0.0 | 0.0 | 12.3 | -141.9 | 0.0 | 48.3 |
| JOINT CHARGE NOW | 0.7 | +63.2 | 40.0 | 0.0 | 1.3 | +64.5 | 53.3 | 0.0 |
| JOINT KNOWS CHALLENGE | - | - | - | - | 0.3 | -10.2 | 0.0 | 0.0 |
| JOINT ON THE TABLE | - | - | - | - | 0.3 | +33.7 | 26.7 | 0.0 |
| KEPT FROM ITS LAST STOP | 1.7 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 1.3 | +91.8 | 0.0 | 0.0 | 1.0 | +8.0 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 12.0 | +0.0 | 195.3 | 228.7 | 9.0 | +0.0 | 0.0 | 0.0 |
| LONE CHARACTER SAFE SPOT | - | - | - | - | 0.7 | +6.6 | 0.0 | 0.0 |
| LONE WIZARD KEPT IN | 0.3 | +5.0 | 0.0 | 0.0 | - | - | - | - |
| LONG SHOT | - | - | - | - | 0.7 | +13.3 | 26.7 | 0.0 |
| LOST AFTER ESCAPE | 1.0 | -4.2 | 40.0 | 0.0 | 1.0 | -0.9 | 0.0 | 0.0 |
| MANOEUVRE | 0.7 | -0.6 | 0.0 | 0.0 | 2.0 | +6.5 | 0.0 | 0.0 |
| MARCH AT ESCAPER | - | - | - | - | 1.0 | +11.9 | 0.0 | 65.0 |
| MARCH BY THE SUM | 0.7 | +54.6 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | 1.0 | +57.6 | 0.0 | 0.0 | 0.3 | +9.8 | 0.0 | 0.0 |
| MARCH OF THE TABLE | 0.3 | +30.4 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 0.7 | -55.7 | 0.0 | 0.0 | 1.0 | +101.9 | 0.0 | 65.0 |
| MARCH WHEELS ONLY | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MAX FOR POSITIONING | 3.0 | +97.9 | 0.0 | 0.0 | 4.0 | +118.1 | 0.0 | 15.0 |
| MEETS IN TIME | 3.7 | +211.0 | 0.0 | 0.0 | 3.3 | +109.0 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 2.3 | +17.0 | 0.0 | 0.0 | 1.7 | +18.8 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 3.3 | +25.7 | 0.0 | 0.0 | 3.0 | +44.0 | 0.0 | 65.0 |
| MOVE ORDER | 3.0 | +0.0 | 53.3 | 0.0 | 2.3 | +0.0 | 16.7 | 0.0 |
| MOVE TO CHARGE COMPUTED | 10.0 | +1004.7 | 0.0 | 0.0 | 7.7 | +1126.1 | 0.0 | 154.0 |
| MOVES UNITS SPELL | 0.3 | +2.4 | 0.0 | 0.0 | - | - | - | - |
| NEARER NOT NEEDED | 8.3 | +357.7 | 0.0 | 68.7 | 6.3 | +275.8 | 0.0 | 48.0 |
| NEXT CHARGE BY LIST | 4.3 | +544.9 | 0.0 | 0.0 | 6.3 | +1022.7 | 0.0 | 154.0 |
| NO DOUBLE ROUNDS | 3.3 | -103.5 | 223.7 | 61.7 | 2.7 | -120.7 | 145.0 | 62.0 |
| NO LATE CUT | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NO OLD ONE-MOVE GUESS | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | - | - | - | - | 0.7 | -0.2 | 0.0 | 0.0 |
| OFF BEST | 8.3 | -437.1 | 25.0 | 60.0 | 6.0 | -283.3 | 0.0 | 25.0 |
| ONE CHALLENGE TEST | - | - | - | - | 0.3 | +65.0 | 0.0 | 0.0 |
| ONE CHECK AFTER THE LAST CHANGE | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 5.7 | -170.1 | 0.0 | 0.0 | 5.3 | -105.7 | 0.0 | 77.0 |
| ONE OBJECTIVE FORMULA | 3.3 | -17.8 | 0.0 | 68.7 | 3.3 | +0.2 | 0.0 | 68.0 |
| ONE ROUTE | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| OPENS UP | - | - | - | - | 0.3 | +2.4 | 33.3 | 0.0 |
| OVERRUNS AWAY | 0.7 | +23.6 | 56.7 | 0.0 | 0.7 | +29.7 | 85.0 | 0.0 |
| PATHS CROSS | - | - | - | - | 1.7 | +32.0 | 0.0 | 0.0 |
| PLAN RESULT | 37.0 | +336.4 | 125.0 | 497.3 | 40.7 | +359.5 | 264.0 | 520.7 |
| PROMISE BY ITS OWN SUM | 13.0 | -438.5 | 0.0 | 0.0 | 8.0 | -169.2 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | 1.3 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | 0.7 | -7.2 | 0.0 | 0.0 | - | - | - | - |
| PROMISE SHOT AWAY | 0.3 | -0.0 | 0.0 | 0.0 | - | - | - | - |
| PURSUES BIG PREY | 0.3 | -5.6 | 0.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | 20.7 | +2701.0 | 130.0 | 115.0 | 21.0 | +2723.3 | 523.0 | 165.0 |
| RANDOM MOVE BY FIGURES | - | - | - | - | 4.3 | +57.3 | 0.0 | 113.3 |
| REAL GROUND | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| REDIRECT BY WHAT IT STOPS | 0.3 | -4.1 | 0.0 | 0.0 | 1.3 | +38.9 | 0.0 | 0.0 |
| REDIRECT COUNTER | 2.3 | -153.3 | 0.0 | 53.3 | 3.0 | +282.3 | 0.0 | 15.0 |
| REDIRECT FOR A FRIEND IN REACH | 1.3 | +14.3 | 0.0 | 26.7 | 2.7 | +71.5 | 0.0 | 25.0 |
| REDIRECT WEIGHED | 0.3 | +35.2 | 48.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| REFORMS TO MEET IT | 4.0 | -163.4 | 0.0 | 0.0 | 0.7 | -6.4 | 0.0 | 0.0 |
| REFUSING RETIRES | 1.0 | +0.0 | 0.0 | 61.7 | 0.3 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | 0.7 | +24.6 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | 2.7 | +174.7 | 158.7 | 0.0 | 2.7 | +144.6 | 145.0 | 0.0 |
| RISK ON THE WAY | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ROUNDS AFTER TERROR | 0.3 | -6.0 | 65.0 | 0.0 | 0.3 | -3.5 | 0.0 | 0.0 |
| RUN DOWN | 1.0 | -2.7 | 65.0 | 0.0 | 2.3 | -13.5 | 86.7 | 0.0 |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 0.7 | -65.9 | 0.0 | 0.0 |
| SEARCH SPOT | 0.3 | +5.1 | 0.0 | 0.0 | 1.0 | +2.1 | 0.0 | 0.0 |
| SECOND LOOK | 0.3 | +5.6 | 25.0 | 0.0 | 0.7 | +24.6 | 58.3 | 0.0 |
| SELF MOVE SPELL | 2.0 | -1.0 | 0.0 | 0.0 | - | - | - | - |
| SET CREDITED ONCE | 1.0 | -9.8 | 0.0 | 0.0 | 0.3 | -8.9 | 0.0 | 0.0 |
| SET UP BY THE SET | 2.3 | +4.7 | 0.0 | 0.0 | 1.0 | -7.9 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 1.0 | +2.0 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS ON THE TABLE | 4.0 | +0.0 | 0.0 | 135.3 | 2.3 | +0.0 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 2.7 | +26.5 | 30.0 | 58.3 | 2.0 | +3.9 | 123.3 | 0.0 |
| SHOT OR CHARGE | 0.3 | -11.8 | 0.0 | 33.3 | - | - | - | - |
| SHOT RISK POINTS | 7.7 | +29.9 | 0.0 | 0.0 | 17.3 | -188.1 | 0.0 | 161.7 |
| SHOTS AFTER THE MOVES | 3.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SHOTS IN THE MOVE | 8.3 | +142.2 | 0.0 | 162.0 | 1.3 | +23.0 | 0.0 | 0.0 |
| SPELL WORTH | 1.3 | +9.1 | 26.7 | 20.0 | 2.3 | +5.2 | 40.0 | 40.0 |
| SPELLS IN THE FIGHT | - | - | - | - | 0.3 | +16.8 | 0.0 | 0.0 |
| SPOT AS THE GAME MOVES | 4.7 | +0.0 | 0.0 | 26.7 | 10.7 | +0.0 | 0.0 | 87.0 |
| STAND AND SHOOT | - | - | - | - | 1.3 | -1.8 | 138.3 | 0.0 |
| STANDS FOR A REASON | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 30.3 | +0.0 | 30.0 | 260.3 | 17.7 | +0.0 | 411.3 | 178.3 |
| STAY WORTH | 9.3 | +18.9 | 0.0 | 168.7 | - | - | - | - |
| STRIKE BY THE ODDS | - | - | - | - | 0.3 | +1.5 | 0.0 | 0.0 |
| STUCK PIVOT | - | - | - | - | 0.3 | +0.0 | 0.0 | 56.7 |
| STUPIDITY NEXT TURN | 0.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 7.7 | +648.6 | 0.0 | 42.0 | 10.3 | +449.4 | 0.0 | 36.7 |
| SUPPORT NARROWED | - | - | - | - | 0.3 | +0.0 | 58.3 | 0.0 |
| SUPPORT WORKED OUT | 7.7 | +648.6 | 0.0 | 42.0 | 10.3 | +449.4 | 0.0 | 36.7 |
| SWIFTSTRIDE BY POINTS | 0.3 | +11.3 | 0.0 | 144.0 | - | - | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 1.3 | +0.0 | 0.0 | 26.7 | 3.0 | +0.0 | 0.0 | 0.0 |
| THE PROMISED MOVE | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 1.0 | +0.0 | 0.0 | 0.0 | 6.3 | +0.0 | 0.0 | 113.0 |
| THE ROW KEEPS ITS WAY | 3.0 | +0.0 | 0.0 | 0.0 | 5.0 | +0.0 | 0.0 | 0.0 |
| THE ROW READS HIS LAST RUN | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 2.0 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 37.3 | +0.0 | 0.0 | 162.0 | 37.0 | +0.0 | 0.0 | 231.3 |
| TIED UP BY THE SUM | 1.0 | +132.4 | 118.7 | 0.0 | 1.7 | +199.4 | 118.3 | 62.0 |
| TIME ON OUR SIDE | 39.3 | +436.5 | 0.0 | 185.3 | 3.0 | +24.6 | 0.0 | 0.0 |
| WAITS AGAIN | 3.0 | +0.0 | 0.0 | 26.7 | 2.0 | +0.0 | 0.0 | 30.0 |
| WALKS ON ITS ROUTE | 0.3 | +44.0 | 0.0 | 0.0 | - | - | - | - |
| WHO FIGHTS | 0.7 | -5.0 | 40.0 | 0.0 | 0.3 | -20.3 | 0.0 | 0.0 |
| WHO HITS BACK | 0.7 | +48.8 | 0.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT DANGER | 3.7 | -356.1 | 0.0 | 42.0 | 1.7 | -453.3 | 0.0 | 0.0 |
| WHOLE FIGHT GAIN | - | - | - | - | 0.3 | +5.6 | 0.0 | 0.0 |
| WOUNDS ON THE RANKS | 0.3 | +1.9 | 0.0 | 0.0 | 3.3 | +80.2 | 0.0 | 40.0 |

### Rule changes: cnomg-c940641-p21

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS MOVE AS HE DECIDES | 118 | 118 | 91 | 30.33 | +0 | +0.0 |
| ARMY TABLE | 148 | 148 | 78 | 26.00 | +1506 | +19.3 |
| HIS MOVE WHY | 85 | 85 | 68 | 22.67 | +0 | +0.0 |
| LEGAL CHARGES ONLY | 63 | 63 | 63 | 21.00 | +0 | +0.0 |
| HOLDER ASSIGNMENT | 49 | 49 | 46 | 15.33 | +3569 | +77.6 |
| FIVE ACTION | 471 | 445 | 45 | 15.00 | +2374 | +52.7 |
| OFF BEST | 43 | 43 | 43 | 14.33 | -2161 | -50.3 |
| THE TABLE AGAIN | 36 | 36 | 32 | 10.67 | +0 | +0.0 |
| MOVE TO CHARGE COMPUTED | 53 | 45 | 26 | 8.67 | +2247 | +86.4 |
| QUARTER ODDS | 125 | 113 | 26 | 8.67 | +2552 | +98.2 |
| DEPLOY BY FIGURES | 41 | 41 | 25 | 8.33 | +230 | +9.2 |
| HIS SHOTS BY HIS RUN | 132 | 126 | 21 | 7.00 | +76 | +3.6 |
| NEXT CHARGE BY LIST | 32 | 31 | 21 | 7.00 | +2266 | +107.9 |
| PROMISE BY ITS OWN SUM | 63 | 63 | 21 | 7.00 | -1823 | -86.8 |
| HIS SHOT LIST | 148 | 140 | 20 | 6.67 | +294 | +14.7 |
| HIS ONE MOVE | 83 | 83 | 18 | 6.00 | +0 | +0.0 |
| MOVE ORDER | 16 | 16 | 16 | 5.33 | +0 | +0.0 |
| SUPPORT ADDS | 54 | 51 | 16 | 5.33 | +585 | +36.6 |
| SUPPORT WORKED OUT | 54 | 51 | 16 | 5.33 | +585 | +36.6 |
| REDIRECT FOR A FRIEND IN REACH | 12 | 12 | 12 | 4.00 | +145 | +12.1 |
| GOAL WALK | 53 | 53 | 11 | 3.67 | +734 | +66.7 |
| HARD STAY DROPPED | 10 | 10 | 10 | 3.33 | +0 | +0.0 |
| SHOT RISK POINTS | 75 | 73 | 10 | 3.33 | +86 | +8.6 |
| FOUR ROUNDS | 21 | 19 | 9 | 3.00 | +336 | +37.3 |
| TIME ON OUR SIDE | 127 | 99 | 9 | 3.00 | +0 | +0.0 |
| MEETS IN TIME | 21 | 21 | 8 | 2.67 | +429 | +53.6 |
| RISK BY ARC | 16 | 15 | 8 | 2.67 | +345 | +43.1 |
| ADVANCE LANE KEPT | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| COVER ONCE | 53 | 33 | 7 | 2.33 | +194 | +27.7 |
| LANE BY FIGURES | 7 | 7 | 7 | 2.33 | +300 | +42.8 |
| HOLDS AMBUSHERS | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| JOINT CHARGE NOW | 6 | 6 | 6 | 2.00 | +383 | +63.9 |
| RANDOM MOVE BY FIGURES | 13 | 13 | 6 | 2.00 | +172 | +28.7 |
| TIED UP BY THE SUM | 8 | 7 | 6 | 2.00 | +193 | +32.2 |
| FOLLOW UP WEIGHED | 5 | 5 | 5 | 1.67 | +1310 | +262.1 |
| IDLE COST | 38 | 24 | 5 | 1.67 | +28 | +5.7 |
| PATHS CROSS | 5 | 5 | 5 | 1.67 | +96 | +19.2 |
| SHOOTS FROM THE BEST SPOT | 14 | 14 | 5 | 1.67 | +15 | +3.1 |
| CHAFF IN THE MOVE | 11 | 7 | 4 | 1.33 | +65 | +16.3 |
| CHALLENGE BY POINTS | 4 | 4 | 4 | 1.33 | +168 | +42.0 |
| COMBAT PIVOT | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| WHOLE FIGHT DANGER | 16 | 14 | 4 | 1.33 | +386 | +96.4 |
| AFTERMATH IN POINTS | 3 | 3 | 3 | 1.00 | +382 | +127.3 |
| CANNON SIGHT KEPT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| CHARGE NOW FIRST | 11 | 11 | 3 | 1.00 | -36 | -12.2 |
| MARCH CHECK | 4 | 4 | 3 | 1.00 | +60 | +20.0 |
| MAX FOR POSITIONING | 21 | 15 | 3 | 1.00 | +31 | +10.3 |
| SECOND LOOK | 3 | 3 | 3 | 1.00 | +91 | +30.2 |
| SHOOTERS IN TWO RANKS | 3 | 3 | 3 | 1.00 | +6 | +2.0 |
| STAY WORTH | 28 | 23 | 3 | 1.00 | +25 | +8.3 |
| CAST JOB | 3 | 3 | 2 | 0.67 | +267 | +133.6 |
| CASTS FROM BEHIND | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| FACES THE THREAT | 2 | 2 | 2 | 0.67 | +116 | +58.0 |
| FALLS SHORT | 69 | 54 | 2 | 0.67 | +2 | +0.8 |
| MANOEUVRE | 8 | 8 | 2 | 0.67 | +20 | +9.8 |
| MARCH BY THE SUM | 2 | 2 | 2 | 0.67 | +164 | +81.8 |
| NEARER NOT NEEDED | 44 | 40 | 2 | 0.67 | +78 | +39.0 |
| OVERRUNS AWAY | 4 | 3 | 2 | 0.67 | +35 | +17.7 |
| REDIRECT COUNTER | 16 | 10 | 2 | 0.67 | +99 | +49.4 |
| REDIRECT WEIGHED | 2 | 2 | 2 | 0.67 | +164 | +82.0 |
| RESERVE FALL BACK | 2 | 2 | 2 | 0.67 | +74 | +36.9 |
| SEARCH SPOT | 4 | 4 | 2 | 0.67 | +22 | +10.9 |
| THE ROW IN ITS ORDER | 22 | 2 | 2 | 0.67 | +0 | +0.0 |
| WHO HITS BACK | 2 | 2 | 2 | 0.67 | +58 | +28.9 |
| CHARGE LIST READ AGAIN | 1 | 1 | 1 | 0.33 | +171 | +171.0 |
| CHARGE LOSSES | 59 | 55 | 1 | 0.33 | +54 | +53.7 |
| EXACT ROUND | 14 | 12 | 1 | 0.33 | +9 | +9.3 |
| FEATURE BUFFS | 7 | 7 | 1 | 0.33 | +3 | +2.7 |
| FIGHT TO THE END | 8 | 8 | 1 | 0.33 | +8 | +7.9 |
| FIRE AND FLEE | 1 | 1 | 1 | 0.33 | +3 | +3.2 |
| JOINT ON THE TABLE | 1 | 1 | 1 | 0.33 | +101 | +101.0 |
| LONE WIZARD KEPT IN | 1 | 1 | 1 | 0.33 | +15 | +15.0 |
| MARCH OF THE TABLE | 1 | 1 | 1 | 0.33 | -91 | -91.1 |
| MISSILES IN THE MOVE | 12 | 6 | 1 | 0.33 | +25 | +25.2 |
| MOVES UNITS SPELL | 1 | 1 | 1 | 0.33 | +7 | +7.3 |
| NO DOUBLE ROUNDS | 18 | 17 | 1 | 0.33 | +15 | +15.2 |
| ONE CHALLENGE TEST | 1 | 1 | 1 | 0.33 | +21 | +21.0 |
| ONE FIGHT FORMULA | 33 | 12 | 1 | 0.33 | +0 | +0.0 |
| PROMISE SHOT AWAY | 1 | 1 | 1 | 0.33 | -0 | -0.1 |
| PURSUES BIG PREY | 1 | 1 | 1 | 0.33 | -17 | -16.7 |
| REDIRECT BY WHAT IT STOPS | 5 | 5 | 1 | 0.33 | +12 | +11.9 |
| REFUSING RETIRES | 4 | 4 | 1 | 0.33 | -37 | -36.6 |
| RUN DOWN | 10 | 10 | 1 | 0.33 | +90 | +89.6 |
| SET UP BY THE SET | 10 | 10 | 1 | 0.33 | +65 | +65.1 |
| SHOTS IN THE MOVE | 29 | 17 | 1 | 0.33 | +19 | +19.0 |
| SPELLS IN THE FIGHT | 1 | 1 | 1 | 0.33 | +21 | +21.0 |
| STRIKE BY THE ODDS | 1 | 1 | 1 | 0.33 | +4 | +4.4 |
| STUCK PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| SUPPORT NARROWED | 1 | 1 | 1 | 0.33 | -5 | -5.4 |
| SWIFTSTRIDE BY POINTS | 1 | 1 | 1 | 0.33 | +34 | +34.0 |
| WALKS ON ITS ROUTE | 1 | 1 | 1 | 0.33 | +132 | +131.9 |
| WOUNDS ON THE RANKS | 11 | 11 | 1 | 0.33 | +35 | +34.8 |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| BACKUP TARGETS | 2 | 1 | 0 | 0.00 | - | - |
| BLOWS WHERE AIMED | 2 | 2 | 0 | 0.00 | - | - |
| CANNON PLANNED TARGET | 3 | 3 | 0 | 0.00 | - | - |
| CHAMPION KNOWS CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 42 | 42 | 0 | 0.00 | - | - |
| DENIED BY THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 1 | 1 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 19 | 18 | 0 | 0.00 | - | - |
| FALLBACK BY WORTH | 2 | 2 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 54 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 25 | 22 | 0 | 0.00 | - | - |
| FRIEND CHARGES FIRST | 1 | 1 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 5 | 3 | 0 | 0.00 | - | - |
| GIVES UP | 3 | 3 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 5 | 4 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 40 | 39 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 31 | 30 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 40 | 36 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 10 | 9 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 38 | 36 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 33 | 30 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 37 | 33 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 5 | 3 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 5 | 5 | 0 | 0.00 | - | - |
| HIS TURN RUN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 82 | 82 | 0 | 0.00 | - | - |
| HONEST WORTH | 19 | 17 | 0 | 0.00 | - | - |
| HUNT IN PAIRS | 2 | 1 | 0 | 0.00 | - | - |
| JOINT KNOWS CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 10 | 10 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 2 | not checked | - | - | - | - |
| LONG SHOT | 2 | 2 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 6 | 6 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 3 | trace | - | - | - | - |
| MARCH OVER CASTS | 5 | 5 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 2 | 2 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 19 | 12 | 0 | 0.00 | - | - |
| NO LATE CUT | 3 | 3 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 18 | 18 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT TURNED | 1 | 1 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 2 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 2 | not checked | - | - | - | - |
| ONE OBJECTIVE FORMULA | 20 | 14 | 0 | 0.00 | - | - |
| ONE ROUTE | 2 | 2 | 0 | 0.00 | - | - |
| OPENS UP | 1 | 1 | 0 | 0.00 | - | - |
| PLAN RESULT | 233 | trace | - | - | - | - |
| PROMISE KNOWS THE FIGHT | 10 | 8 | 0 | 0.00 | - | - |
| PROMISE READS THE TABLE | 2 | 2 | 0 | 0.00 | - | - |
| REAL GROUND | 2 | 2 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 14 | 14 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 2 | 2 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 2 | 2 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 2 | 2 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 6 | not checked | - | - | - | - |
| SET CREDITED ONCE | 4 | 4 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 19 | not checked | - | - | - | - |
| SHOT OR CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| SHOTS AFTER THE MOVES | 9 | 9 | 0 | 0.00 | - | - |
| SPELL WORTH | 11 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 46 | 40 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 4 | 3 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 1 | 1 | 0 | 0.00 | - | - |
| STANDS STILL | 144 | 132 | 0 | 0.00 | - | - |
| STUPIDITY NEXT TURN | 5 | 5 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 13 | not checked | - | - | - | - |
| THE PROMISED MOVE | 1 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 24 | not checked | - | - | - | - |
| THE ROW READS HIS LAST RUN | 1 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 18 | not checked | - | - | - | - |
| THE TABLE BINDS | 223 | not checked | - | - | - | - |
| WAITS AGAIN | 15 | 14 | 0 | 0.00 | - | - |
| WHO FIGHTS | 3 | 3 | 0 | 0.00 | - | - |
| WHOLE FIGHT GAIN | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: cnomg-c940641-p21

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 6.00 | 5.67 | 51.4 |
| PROMISE BY ITS OWN SUM | rule | 5.33 | 1.67 | 86.8 |
| ARMY TABLE | rule | 2.33 | 3.00 | 86.0 |
| RULE SWITCHED OFF | gate | 1.67 | - | 68.6 |
| CHARGE NOW FIRST | rule | - | 1.00 | 12.2 |
| JOINT CHARGE NOW | rule | - | 0.67 | 17.6 |
| AFTERMATH BAND | gate | 0.33 | - | 2.2 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.33 | - | 10.5 |
| LONE CHARACTER SAFE SPOT | gate | - | 0.33 | 6.7 |
| MARCH OF THE TABLE | rule | 0.33 | - | 91.1 |
| PATHS CROSS | rule | - | 0.33 | 18.3 |
| PURSUES BIG PREY | rule | 0.33 | - | 16.7 |
| REFUSING RETIRES | rule | - | 0.33 | 36.6 |
| SUPPORT NARROWED | rule | - | 0.33 | 5.4 |

### Plans: cnomg-c940641-p21

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 3.0 | 56% | 589 | 195 | 33% |
| Mine | move | 30.3 | 97% | 2142 | 0 | 0% |
| Mine | shoot | 3.3 | 70% | 167 | 141 | 85% |
| Mine | support | 0.3 | 100% | 14 | 0 | 0% |
| Opponent | charge | 2.7 | 62% | 271 | 191 | 70% |
| Opponent | join | 3.7 | 91% | 175 | 0 | 0% |
| Opponent | move | 32.7 | 96% | 2196 | 0 | 0% |
| Opponent | shoot | 0.7 | 100% | 96 | 169 | 176% |
| Opponent | support | 1.0 | 100% | 36 | 0 | 0% |

### Battle groups: cnomg-c940641-p21

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 2.3 | 29% | 100% | 0% | - | 0% | 0% | 0% | 50% | 50% |
| Opponent | REDIRECT COUNTER | 3.0 | 11% | 100% | 0% | - | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: cnomg-c940641-p21

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 3 | 0 (3) | 0 | 0 | 0 | 100% | - | 0 (3) | - | - | 0 (3) | - |
| Mine | Chaff | 2 | 38 (2) | 0 | 38 | 100 | 0% | 1.5 | 75 (1) | 0 (1) | - | 75 (1) | 0 (1) |
| Mine | Character | 8 | 38 (8) | 38 | 0 | 0 | 12% | 2.4 | 35 (4) | 55 (3) | 0 (1) | 49 (5) | 6 (3) |
| Mine | Clean-up | 1 | 140 (1) | 0 | 140 | 0 | 0% | 5.0 | 140 (1) | - | - | 140 (1) | - |
| Mine | Fast | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | 0 (1) | - | - | 0 (1) | - |
| Mine | Fast Hammer | 4 | 0 (4) | 0 | 0 | 66 | 0% | 1.8 | 0 (3) | 0 (1) | - | 0 (3) | 0 (1) |
| Mine | Hammer | 3 | 12 (3) | 7 | 4 | 26 | 0% | 3.0 | 29 (1) | 6 (2) | - | 29 (1) | 6 (2) |
| Mine | Shooter | 6 | 18 (6) | 0 | 18 | 19 | 17% | 1.0 | 0 (3) | 43 (3) | - | 36 (3) | 0 (3) |
| Mine | Support | 1 | 0 (1) | 0 | 0 | 0 | 0% | 3.0 | - | 0 (1) | - | - | 0 (1) |
| Mine | War machine | 2 | 0 (2) | 0 | 0 | 100 | 0% | 1.0 | 0 (2) | - | - | 0 (1) | 0 (1) |
| Mine | Wizard | 1 | 0 (1) | 0 | 0 | 100 | 0% | 1.0 | - | - | - | - | - |
| Opponent | Chaff | 5 | 0 (5) | 0 | 0 | 67 | 40% | 4.0 | 0 (2) | 0 (3) | - | 0 (1) | 0 (4) |
| Opponent | Character | 10 | 12 (10) | 12 | 0 | 7 | 40% | 3.2 | 23 (4) | 0 (5) | 27 (1) | 13 (7) | 10 (3) |
| Opponent | Clean-up | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Fast Hammer | 6 | 38 (6) | 18 | 20 | 14 | 50% | 4.3 | 24 (3) | 56 (3) | - | 35 (4) | 42 (2) |
| Opponent | Hammer | 5 | 53 (5) | 22 | 32 | 18 | 20% | 3.0 | 62 (3) | 37 (2) | - | 65 (4) | 0 (1) |
| Opponent | Holder | 4 | 12 (4) | 0 | 12 | 29 | 50% | 3.5 | 0 (1) | 17 (3) | - | - | 12 (4) |
| Opponent | Support | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Wizard | 3 | 0 (3) | 0 | 0 | 57 | 33% | 2.5 | 0 (1) | 0 (1) | 0 (1) | 0 (1) | 0 (2) |

### Charged fights: cnomg-c940641-p21

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | High Elf Realms | 1 | 0 | 339 | 2.0 | 1.0 | 170 | 0 | +170 | 1 of 2 | 2 of 2 | - | +170 |
| Mine | Kingdom of Bretonnia | 1 | 0 | 170 | 2.0 | 1.0 | 85 | 0 | +85 | 1 of 2 | 2 of 2 | - | +85 |
| Mine | Lizardmen | 1 | 50 | 426 | 6.0 | 1.2 | 71 | 31 | +40 | 1 of 6 | 5 of 6 | +120 | +24 |
| **Mine** | all armies | 3 | 17 | 312 | 3.3 | 1.1 | 94 | 18 | +75 | 3 of 10 | 9 of 10 | +120 | +70 |
| Opponent | Vampire Counts | 1 | 0 | 175 | 2.0 | 1.0 | 88 | 0 | +88 | 0 of 2 | 1 of 2 | - | +88 |
| Opponent | Warriors of Chaos | 2 | 0 | 120 | 2.5 | 1.0 | 48 | 0 | +48 | 2 of 5 | 4 of 5 | - | +48 |
| **Opponent** | all armies | 3 | 0 | 138 | 2.3 | 1.0 | 59 | 0 | +59 | 2 of 7 | 5 of 7 | - | +59 |

### Effective charges: cnomg-c940641-p21

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | High Elf Realms | 2 | 0 | 0 | 0 | 0 | 0 | 1 (net +195) | 1 | 0% (0 of 1) |
| Mine | Kingdom of Bretonnia | 2 | 1 (net +0) | 0 | 0 | 0 | 0 | 1 (net +170) | 0 | 0% (0 of 2) |
| Mine | Lizardmen | 6 | 1 (net -185) | 0 | 0 | 0 | 1 (net +120) | 1 (net +186) | 3 | 0% (0 of 3) |
| Opponent | Vampire Counts | 2 | 1 (net +0) | 0 | 0 | 0 | 0 | 0 | 1 | 0% (0 of 1) |
| Opponent | Warriors of Chaos | 5 | 1 (net +60) | 0 | 0 | 0 | 2 (net +90) | 1 (net +0) | 1 | 0% (0 of 4) |

### Charged fights, damage counted: cnomg-c940641-p21

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 2 | 230 | 437 | -92 | 16 | 92 | -77 | -33.3 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 | 424 | 184 | +184 | 184 | 0 | +184 | +43.3 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 804 | 60 | +120 | 129 | 202 | -74 | -9.1 |
| Mine | No odds | 4 | 294 | 78 | +66 | 66 | 0 | +66 | +22.4 |
| Mine | All fights | 10 | 372 | 180 | +75 | 98 | 39 | +59 | +15.8 |
| Opponent | Long shot (under 50%) | 2 | 128 | 204 | +30 | 59 | 87 | -28 | -22.0 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 365 | 214 | +0 | 111 | 292 | -181 | -49.7 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 2 | 344 | 90 | +90 | 90 | 0 | +90 | +26.2 |
| Opponent | No odds | 2 | 418 | 256 | +88 | 88 | 0 | +88 | +20.9 |
| Opponent | All fights | 7 | 306 | 188 | +59 | 83 | 67 | +17 | +5.5 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| cnomg-c940641-p21 | move | 23 | 4 (17%) | 4 (17%) | 5 (22%) | 14 (61%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L1727 |
| Invocation of Nehek | Opponent | L1727 |
| Ring of Doom | Mine | L1531 |
| Ring of Doom | Opponent | L1531 |

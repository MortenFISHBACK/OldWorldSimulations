# Doctrine scorecard: cnomg-c940641-p40

### Scorecard: cnomg-c940641-p40

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0528 | 6 | 1 | Mine | no | 2 | - | 0 | 2 | 0 | 0 | 0 | 335 |
| L0528 | 6 | 1 | Opponent | no | 9 | - | 0 | 2 | 0 | 0 | 0 | 0 |
| L0616 | 4 | 1 | Mine | no | 0 | - | 2 | 5 | 0 | 0 | 0 | 683 |
| L0616 | 4 | 1 | Opponent | no | 0 | - | 0 | 1 | 1 | 0 | 0 | 200 |
| L0632 | 2 | 1 | Mine | - | - | - | 3 | 2 | 0 | 0 | 0 | 180 |
| L0632 | 2 | 1 | Opponent | - | - | 3 | 1 | 7 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 0% | 1.0 | - | 1.7 | 3.0 | 0.0 | 0.0 | 0.0 | 399.3 |
| **Average** | | | Opponent | 0% | 4.5 | 3.0 | 0.3 | 3.3 | 0.3 | 0.0 | 0.0 | 66.7 |

### KPIs: cnomg-c940641-p40

Rules off - Opponent only: NO OLD ONE-MOVE GUESS.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 100% (12 of 12) | 0% (0 of 10) | 55% (12 of 22) |
| Winner chose to follow up after the loser gave ground |  | 100% (1 of 1); on the table 100% | 100% (2 of 2); on the table 100% | 100% (3 of 3); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | - | 100% (1 of 1); on the table 100% | 100% (1 of 1); on the table 100% |
| Winner chose to pursue after the loser fled |  | - | 100% (1 of 1); on the table 100% | 100% (1 of 1); on the table 100% |
| Winner chose to follow up or pursue (all three) |  | 100% (1 of 1); on the table 100% | 100% (4 of 4); on the table 100% | 100% (5 of 5); on the table 100% |
| Magic missiles tried each own turn | 50%+ | - | 0% (0 of 6) | 0% (0 of 6) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | - | 0% (0 of 6) | 0% (0 of 6) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 75% (9 of 12) | 75% (9 of 12) |
| Points that never fought | lower | 92% (5497 of 6000) | 85% (5076 of 5999) | 88% (10573 of 11999) |
|   infantry points that never fought | lower | 92% (2049 of 2232) | 100% (720 of 720) | 94% (2769 of 2952) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 74% (20 of 27) | 76% (16 of 21) | 75% (36 of 48) |
| Bound items with a magic missile used (at least once a game) |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0.0 uses a game | 100% (1 of 1); 0.3 uses a game | 100% (1 of 1); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 68% (2884 of 4232) | 69% (3744 of 5415) | 69% (6628 of 9647) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | - | 1.7 (83%) | 1.7 (83%) |
| MARCHED: its unit marched | - | 0.3 (17%) | 0.3 (17%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Magic missiles | Assailments |
| --- | --- | --- | --- | --- |
| tried | 1.0 | 0.0 | 0.0 | 0.0 |
| not cast | 3.0 | 2.0 | 2.0 | 4.0 |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 2.0 (100%) | 1.7 (83%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.3 (17%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 1.0 (33%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.0 (67%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 4.0 (100%) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 61% (120 of 198) | 44% (15 of 34) | 58% (135 of 232) |
|   cavalry | 40% (8 of 20) | 43% (6 of 14) | 41% (14 of 34) |
|   character | 65% (17 of 26) | 0% (0 of 6) | 53% (17 of 32) |
|   infantry | 45% (21 of 47) | 0% (0 of 5) | 40% (21 of 52) |
|   monster | 67% (8 of 12) | - | 67% (8 of 12) |
|   war machine | 71% (66 of 93) | 100% (9 of 9) | 74% (75 of 102) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 6.0 (23%) | 0.7 (11%) | 6.7 (21%) |
| CHARGED: it charged | 2.0 (8%) | 0.3 (5%) | 2.3 (7%) |
| IN COMBAT: it fought this turn or the last | 0.3 (1%) | 1.0 (16%) | 1.3 (4%) |
| NO TARGET IN RANGE | 7.3 (28%) | 1.7 (26%) | 9.0 (28%) |
| ONLY IN COMBAT: the only targets were in combat | 0.3 (1%) | 1.0 (16%) | 1.3 (4%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 6.7 (26%) | 1.7 (26%) | 8.3 (26%) |
| SHELTERED: the target was sheltered | 2.0 (8%) | 0.0 (0%) | 2.0 (6%) |
| OTHER BAR | 1.3 (5%) | 0.0 (0%) | 1.3 (4%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 5.3 | 0.3 | 94% | 4.3 pts | 23 pts |
| character | 5.7 | 5.7 | 59% | 12.3 pts | 69 pts |
| infantry | 14.0 | 4.3 | 74% | 5.6 pts | 79 pts |
| monster | 2.7 | 0.7 | 75% | 8.7 pts | 23 pts |
| war machine | 25.0 | 12.3 | 64% | 16.7 pts | 418 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 2.0 | 1.3 | 1.7 |
| Charges that made contact a game | 1.7 | 0.3 | 1.0 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | - | - | - |
|   per unit a game, units carrying another wizard (or one alone) | - | - | - |
|   per unit a game, the other units (no war machines, no joined characters) | 0.29 declared, 0.24 contact (21 units) | 0.20 declared, 0.05 contact (20 units) | 0.24 declared, 0.15 contact (41 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 100% (4 of 4) | - | 50% (1 of 2) | 83% (5 of 6) |
| Character in a unit | 100% (7 of 7) | 67% (2 of 3) | 100% (1 of 1) | 91% (10 of 11) |
| Character on its own | - | 50% (1 of 2) | 67% (2 of 3) | 60% (3 of 5) |
| Infantry | 71% (5 of 7) | 33% (2 of 6) | - | 54% (7 of 13) |
| Monster | 75% (3 of 4) | - | - | 75% (3 of 4) |
| Monstrous | 100% (1 of 1) | - | - | 100% (1 of 1) |
| War Machines | 88% (7 of 8) | - | - | 88% (7 of 8) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Dwarfen Mountain Holds | 3 | 100% (1 of 1); on the table 100% | - | 92% | 74% (20 of 27) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | 100% (1 of 1); on the table 100% | - | 92% | 50% (3 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Warriors of Chaos | 2 | 100% (3 of 3); on the table 100% | 0% (0 of 6) | 81% | 87% (13 of 15) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (cnomg-c940641-p40, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | - | 100% (3) | 100% (3) |
| ...free all their last turn and able to turn (per game) | 0.00 | 0.67 | 0.67 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.33 | 0.33 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.33 | 0.33 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: cnomg-c940641-p40

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.3 | 1.3 |
| Strategy | Charge objectives carried out (made contact) | 83% (5 of 6) | 25% (1 of 4) |
| Strategy | Shoot objectives carried out (shot that target) | 65% (53 of 82) | 55% (6 of 11) |
| Strategy | Support requests answered (helper made contact too) | - | 0% (0 of 1) |
| Strategy | Joined characters whose unit fought | 0% (0 of 11) | 0% (0 of 5) |
| Strategy | Lone characters that fought | 50% (1 of 2) | 20% (1 of 5) |
| Movement | Charges halted short of contact | 0.0 | 0.3 |
| Movement | Idle units | 3.0 | 3.3 |
| Movement | Points that never moved of their own | 399.3 | 66.7 |
| Movement | Fights charged into per game | 1.7 | 0.3 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 5 | - |
| Movement | Charges with odds: sweet spot (55-75%) | 1 of 5, net +0 | - |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 5 | - |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 of 5, net +68 | - |
| Shooting | Shots by shooting units (incl. breath weapons) | 19.3 | 4.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 52% (30 of 58) | 0% (0 of 13) |
| Shooting | Points destroyed by shooting units | 50.7 | 0.0 |
| Shooting | War machine shots | 22.0 | 3.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 67% (44 of 66) | 67% (6 of 9) |
| Shooting | Points destroyed by war machines | 190.3 | 38.3 |
| Magic | Points destroyed by magic (all spells) | 0.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.0 / 0.0 / 0.0 / 0.0 | 1.0 / 0.0 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 0.0 | 31.7 |
| Combat | Points run down | 26.7 | 77.7 |
| Combat | Net points per charged fight, damage counted | +60 | +157 |
| Combat | Net per 100 charger points, damage counted | +86.2 | +32.1 |
| Combat | First round won (charged fights) | 80% | 100% |
| Combat | Net points per charged fight | +43 | +278 |
| Combat | Net points per supported fight / lone fight | - / +43 | - / +278 |
| Combat | Charged fights on a top-3 enemy unit | 0 of 5 | 1 of 1 |
| Game | Points lost | 192.0 | 290.0 |
| Game | VP from objectives | 676.7 | 420.0 |
| Game | Lone holders (player turns) | 1.0 | 4.5 |

- Mine won / drew / lost: 1 / 2 / 0 of 3 ended games (of 3); mean margin (Mine - Opponent) +327 VP
- The side that went first won 0 of 1 games with a winner
- Points traded per game (both sides' losses): 482
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: cnomg-c940641-p40

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.3 | +5.2 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | 9.0 | +47.1 | 0.0 | 0.0 | 17.0 | +227.2 | 0.0 | 294.0 |
| ARTILLERY RE-ROLL WEIGHED | 4.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| BACKUP TARGETS | 0.3 | +3.9 | 0.0 | 0.0 | - | - | - | - |
| BLOWS WHERE AIMED | - | - | - | - | 0.3 | -68.5 | 61.0 | 0.0 |
| CANNON PLAN MISSED | 1.7 | +0.0 | 305.0 | 0.0 | - | - | - | - |
| CANNON PLANNED TARGET | 20.7 | +343.0 | 1187.7 | 0.0 | 3.0 | +93.4 | 76.7 | 66.7 |
| CANNON SIGHT KEPT | 3.0 | +0.0 | 0.0 | 38.3 | - | - | - | - |
| CHAFF IN THE MOVE | - | - | - | - | 1.7 | +22.1 | 0.0 | 10.0 |
| CHAFF PASSED | 1.0 | -1.5 | 0.0 | 0.0 | - | - | - | - |
| CHALLENGE BY POINTS | 0.3 | +41.0 | 0.0 | 61.0 | - | - | - | - |
| CHARACTER GUNS | 4.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHARGE LOSSES | 4.7 | -72.7 | 0.0 | 0.0 | 21.3 | -851.9 | 0.0 | 776.0 |
| CHARGE NOW FIRST | 1.0 | +0.0 | 45.7 | 0.0 | 0.3 | +0.0 | 77.7 | 0.0 |
| CLOSES ON WHAT IT BEATS | 9.3 | +0.0 | 0.0 | 0.0 | 8.3 | +0.0 | 0.0 | 314.0 |
| COMBAT PIVOT | - | - | - | - | 0.3 | +0.0 | 61.0 | 0.0 |
| COVER ONCE | 4.0 | -369.9 | 0.0 | 0.0 | 5.3 | -260.0 | 0.0 | 202.7 |
| DEFENSIVE ARMY | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| DENIED BY THE FIGHT | 0.7 | -1.8 | 0.0 | 0.0 | - | - | - | - |
| DEPLOY BY FIGURES | 13.0 | -157.2 | 0.0 | 38.3 | 6.0 | +73.0 | 0.0 | 0.0 |
| EDGE GIVE GROUND | 0.3 | +6.8 | 0.0 | 0.0 | - | - | - | - |
| EXACT ROUND | 1.7 | +8.0 | 45.7 | 0.0 | 1.0 | -9.6 | 138.7 | 45.7 |
| FALL BACK GOOD ORDER | 2.0 | +1.1 | 45.7 | 0.0 | - | - | - | - |
| FALLS SHORT | - | - | - | - | 18.3 | +140.8 | 0.0 | 82.7 |
| FEATURE BUFFS | 1.3 | +18.3 | 0.0 | 0.0 | - | - | - | - |
| FIGHT TO THE END | 1.0 | +0.9 | 45.7 | 0.0 | 0.3 | +14.1 | 61.0 | 0.0 |
| FIRE IN ORDER | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FIVE ACTION | 136.7 | +5207.6 | 2871.0 | 155.3 | 74.3 | +2324.0 | 369.7 | 1101.0 |
| FLANK NOT WEIGHED | 1.7 | +0.0 | 0.0 | 77.7 | 4.0 | +0.0 | 0.0 | 0.0 |
| FOLLOW UP WEIGHED | - | - | - | - | 0.3 | +107.7 | 0.0 | 0.0 |
| FOUR ROUNDS | 2.0 | +50.1 | 45.7 | 0.0 | 1.3 | +35.8 | 216.3 | 45.7 |
| FRIEND SHOOTS FIRST | 0.7 | -42.5 | 0.0 | 0.0 | - | - | - | - |
| GIVES UP | - | - | - | - | 0.3 | -0.5 | 61.0 | 0.0 |
| GOAL WALK | 4.0 | +133.5 | 0.0 | 0.0 | 13.3 | +942.9 | 0.0 | 91.3 |
| GUN FIGURES | 2.0 | +7.9 | 0.0 | 0.0 | - | - | - | - |
| GUN MASK | 2.0 | +61.2 | 0.0 | 0.0 | - | - | - | - |
| HARD STAY DROPPED | 6.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| HELPER UNSEEN | - | - | - | - | 0.3 | +0.0 | 77.7 | 0.0 |
| HIS CHARGE BY HIS RUN | 2.0 | +0.0 | 0.0 | 0.0 | 6.7 | +0.0 | 0.0 | 702.0 |
| HIS CHARGE DENIED | - | - | - | - | 0.7 | +43.8 | 77.7 | 45.7 |
| HIS CHARGE LIST | 3.7 | +0.0 | 0.0 | 0.0 | 17.3 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 3.0 | +0.0 | 0.0 | 77.7 | 3.3 | +0.0 | 0.0 | 628.0 |
| HIS MOVE AND SHOT | 1.0 | -11.0 | 0.0 | 0.0 | 5.3 | -43.4 | 0.0 | 314.0 |
| HIS MOVE AS HE DECIDES | - | - | - | - | 39.0 | +15.7 | 216.3 | 0.0 |
| HIS ONE MOVE | - | - | - | - | 15.0 | +5.2 | 0.0 | 0.0 |
| HIS ONE QUARTER | 2.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS OWN BEST MOVE | 4.7 | +0.0 | 0.0 | 77.7 | 2.3 | +0.0 | 0.0 | 314.0 |
| HIS RANDOM MOVE | 21.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS RANDOM MOVER COMES | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 26.7 | +441.0 | 0.0 | 0.0 | 61.0 | +5123.7 | 0.0 | 922.0 |
| HIS SHOTS BY HIS RUN | 18.3 | +231.3 | 0.0 | 155.3 | 53.3 | +1364.4 | 0.0 | 876.3 |
| HIS TURN DENIED | 0.7 | +8.2 | 0.0 | 0.0 | - | - | - | - |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 14.0 | +0.0 | 0.0 | 155.3 | 11.0 | +0.0 | 0.0 | 74.0 |
| HOLDER ASSIGNMENT | 10.3 | +1261.8 | 0.0 | 77.7 | 6.7 | +695.9 | 0.0 | 37.0 |
| HOLDS AMBUSHERS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 1.7 | -13.0 | 45.7 | 0.0 | 1.0 | -65.2 | 138.7 | 45.7 |
| IDLE COST | - | - | - | - | 18.0 | -346.7 | 0.0 | 378.3 |
| JOINT CHARGE NOW | - | - | - | - | 0.7 | +220.8 | 155.3 | 0.0 |
| KEEPS SCOUTS OR AMBUSH | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 4.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | - | - | - | - | 1.3 | +77.7 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 2.0 | +0.0 | 26.7 | 61.0 | 2.3 | +0.0 | 61.0 | 53.3 |
| LONE WIZARD KEPT IN | - | - | - | - | 0.3 | +25.0 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | 2.0 | +6.3 | 45.7 | 0.0 | 0.3 | -5.1 | 61.0 | 0.0 |
| MANOEUVRE | 1.0 | -18.7 | 0.0 | 77.7 | 2.0 | +4.8 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 2.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 0.7 | +1.8 | 0.0 | 0.0 | 0.7 | +3.8 | 0.0 | 0.0 |
| MEETS IN TIME | 6.0 | +54.8 | 0.0 | 0.0 | 3.0 | +184.7 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | - | - | - | - | 0.3 | +0.5 | 0.0 | 0.0 |
| MISSILES NEXT TURN | - | - | - | - | 1.7 | +4.3 | 0.0 | 0.0 |
| MODEL FACING | 4.0 | +1058.5 | 0.0 | 0.0 | - | - | - | - |
| MOVE ORDER | 3.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 5.7 | +180.4 | 0.0 | 0.0 | 3.3 | +185.9 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 3.7 | +185.7 | 0.0 | 0.0 | 3.7 | +213.1 | 0.0 | 45.7 |
| NEXT CHARGE BY LIST | 2.7 | +109.9 | 0.0 | 0.0 | 2.7 | +148.3 | 0.0 | 0.0 |
| NEXT OBJECTIVE NEARER | - | - | - | - | 0.3 | -33.3 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 2.0 | -45.1 | 45.7 | 0.0 | 0.7 | -35.3 | 77.7 | 45.7 |
| NO LATE CUT | 1.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OFF BEST | 5.3 | -112.1 | 0.0 | 0.0 | 2.7 | -94.3 | 0.0 | 33.3 |
| ONE CHALLENGE TEST | - | - | - | - | 0.3 | +1.2 | 77.7 | 0.0 |
| ONE CHECK AFTER THE LAST CHANGE | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 6.7 | -48.4 | 0.0 | 77.7 | 2.7 | -54.5 | 0.0 | 314.0 |
| ONE JOINT FIGURE | 0.3 | -0.4 | 0.0 | 0.0 | - | - | - | - |
| ONE OBJECTIVE FORMULA | 3.3 | -25.1 | 0.0 | 77.7 | 2.3 | +78.8 | 0.0 | 37.0 |
| ONE ROUTE | 2.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| OVERRUNS AWAY | 0.3 | +8.7 | 0.0 | 0.0 | 0.7 | +9.1 | 77.7 | 45.7 |
| PATHS CROSS | 0.3 | +1.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 10.0 |
| PIVOT GUARDS FLANK | - | - | - | - | 0.3 | -2.7 | 0.0 | 0.0 |
| PLAN RESULT | 60.7 | +2162.2 | 706.0 | 216.3 | 35.0 | +247.4 | 61.0 | 556.3 |
| PROMISE BY ITS OWN SUM | 11.7 | -153.9 | 0.0 | 0.0 | 5.0 | -140.1 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | 0.7 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| QUARTER ODDS | 15.0 | +995.9 | 0.0 | 0.0 | 8.0 | +798.9 | 0.0 | 0.0 |
| RANDOM MOVE BY FIGURES | - | - | - | - | 4.0 | +86.4 | 0.0 | 0.0 |
| REAL GROUND | 2.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| REDIRECT BY WHAT IT STOPS | - | - | - | - | 1.7 | +2.8 | 0.0 | 0.0 |
| REDIRECT COUNTER | - | - | - | - | 3.0 | +166.0 | 0.0 | 0.0 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 2.7 | +0.0 | 0.0 | 0.0 |
| REFORMS TO MEET IT | 1.7 | -57.4 | 0.0 | 0.0 | - | - | - | - |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| RESERVE FALL BACK | - | - | - | - | 1.3 | +25.5 | 0.0 | 0.0 |
| RESTRAINS TO SHOOT | 0.3 | +2.4 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | 1.3 | +37.3 | 45.7 | 0.0 | 1.0 | -50.7 | 138.7 | 45.7 |
| ROUNDS AFTER TERROR | - | - | - | - | 0.7 | -6.5 | 138.7 | 0.0 |
| RUN DOWN | 2.0 | -30.2 | 45.7 | 0.0 | 0.7 | -18.8 | 77.7 | 45.7 |
| SAME CHARGE LATER | 0.3 | -0.2 | 0.0 | 0.0 | - | - | - | - |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 1.3 | -82.0 | 0.0 | 20.0 |
| SET UP BY THE SET | 0.7 | +15.0 | 0.0 | 0.0 | 0.7 | -6.0 | 0.0 | 0.0 |
| SET UP TOGETHER | - | - | - | - | 0.7 | +14.6 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 2.0 | +4.0 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS ON THE TABLE | 28.3 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 66.7 |
| SHOOTS FROM THE BEST SPOT | - | - | - | - | 0.3 | +34.0 | 0.0 | 0.0 |
| SHORT GUN FORWARD | 2.0 | +0.0 | 0.0 | 38.3 | - | - | - | - |
| SHOT RISK POINTS | 6.0 | +46.2 | 0.0 | 0.0 | 33.0 | -598.4 | 0.0 | 516.7 |
| SHOTS AFTER THE MOVES | 6.0 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 37.0 | +1149.1 | 0.0 | 0.0 | 7.0 | +255.5 | 0.0 | 103.7 |
| SPELL WORTH | - | - | - | - | 1.0 | +14.5 | 0.0 | 0.0 |
| SPOT AS THE GAME MOVES | 3.0 | +0.0 | 0.0 | 0.0 | 5.7 | +0.0 | 0.0 | 37.0 |
| STAND AND SHOOT | 0.7 | -2.4 | 0.0 | 0.0 | 0.3 | -4.5 | 61.0 | 0.0 |
| STANDS FOR A REASON | - | - | - | - | 2.3 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 101.0 | +0.0 | 2825.3 | 0.0 | 21.7 | +0.0 | 153.3 | 133.3 |
| STAY WORTH | 76.0 | +286.7 | 2484.0 | 0.0 | 9.7 | +300.6 | 153.3 | 200.0 |
| STUCK PIVOT | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 2.3 | +23.9 | 0.0 | 0.0 | 1.7 | +47.3 | 0.0 | 0.0 |
| SUPPORT NARROWED | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 77.7 | 0.0 |
| SUPPORT WORKED OUT | 2.3 | +23.9 | 0.0 | 0.0 | 1.7 | +47.3 | 0.0 | 0.0 |
| SURE REACH TOGETHER | 0.3 | +0.5 | 0.0 | 0.0 | - | - | - | - |
| SWIFTSTRIDE BY POINTS | - | - | - | - | 0.3 | +0.3 | 0.0 | 10.0 |
| THE DEARER SUM KEEPS ITS PLAN | 2.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 10.0 |
| THE ROW IN ITS ORDER | 1.0 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 1.3 | +0.0 | 0.0 | 0.0 | 6.3 | +0.0 | 0.0 | 13.7 |
| THE STEP BACK IS MADE | 0.3 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 13.7 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 60.3 | +0.0 | 0.0 | 77.7 | 35.3 | +0.0 | 0.0 | 537.7 |
| TIED UP BY THE SUM | 0.3 | +9.1 | 45.7 | 0.0 | 0.3 | +15.1 | 0.0 | 45.7 |
| TIME ON OUR SIDE | 56.0 | +590.8 | 27.3 | 77.7 | - | - | - | - |
| WAITS AGAIN | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WHO FIGHTS | 0.7 | -2.8 | 0.0 | 0.0 | 0.3 | +1.8 | 0.0 | 45.7 |
| WHOLE FIGHT DANGER | 0.7 | -7.3 | 0.0 | 0.0 | 3.0 | -262.2 | 0.0 | 351.0 |
| WHOLE FIGHT GAIN | - | - | - | - | 0.3 | +24.9 | 77.7 | 0.0 |
| WOUNDS ON THE RANKS | 1.0 | +31.3 | 0.0 | 0.0 | 5.3 | +261.5 | 0.0 | 0.0 |

### Rule changes: cnomg-c940641-p40

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS MOVE AS HE DECIDES | 117 | 117 | 70 | 23.33 | +0 | +0.0 |
| ARMY TABLE | 78 | 78 | 63 | 21.00 | +737 | +11.7 |
| HIS SHOT LIST | 263 | 250 | 62 | 20.67 | +1638 | +26.4 |
| HOLDER ASSIGNMENT | 51 | 51 | 48 | 16.00 | +3018 | +62.9 |
| HIS SHOTS BY HIS RUN | 215 | 204 | 40 | 13.33 | +676 | +16.9 |
| DEPLOY BY FIGURES | 57 | 57 | 39 | 13.00 | +580 | +14.9 |
| SHOT RISK POINTS | 117 | 111 | 32 | 10.67 | +1115 | +34.9 |
| PROMISE BY ITS OWN SUM | 50 | 50 | 27 | 9.00 | -882 | -32.7 |
| TIME ON OUR SIDE | 168 | 147 | 26 | 8.67 | +75 | +2.9 |
| OFF BEST | 24 | 24 | 24 | 8.00 | -619 | -25.8 |
| HARD STAY DROPPED | 22 | 22 | 22 | 7.33 | +0 | +0.0 |
| THE TABLE AGAIN | 36 | 36 | 21 | 7.00 | +0 | +0.0 |
| FIVE ACTION | 633 | 614 | 18 | 6.00 | +391 | +21.7 |
| CANNON PLANNED TARGET | 71 | 71 | 17 | 5.67 | -60 | -3.5 |
| HIS ONE MOVE | 45 | 45 | 17 | 5.67 | +0 | +0.0 |
| ARTILLERY RE-ROLL WEIGHED | 14 | 14 | 14 | 4.67 | +0 | +0.0 |
| MOVE TO CHARGE COMPUTED | 27 | 19 | 14 | 4.67 | +246 | +17.5 |
| LEGAL CHARGES ONLY | 13 | 13 | 13 | 4.33 | +0 | +0.0 |
| MOVE ORDER | 13 | 13 | 13 | 4.33 | +0 | +0.0 |
| MODEL FACING | 12 | 12 | 12 | 4.00 | +3175 | +264.6 |
| GOAL WALK | 52 | 51 | 11 | 3.67 | +634 | +57.7 |
| CANNON SIGHT KEPT | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| RANDOM MOVE BY FIGURES | 12 | 12 | 9 | 3.00 | +259 | +28.8 |
| CHARGE LOSSES | 78 | 77 | 8 | 2.67 | +546 | +68.2 |
| IDLE COST | 54 | 46 | 8 | 2.67 | +36 | +4.5 |
| REDIRECT FOR A FRIEND IN REACH | 8 | 8 | 8 | 2.67 | +0 | +0.0 |
| COVER ONCE | 28 | 23 | 7 | 2.33 | +108 | +15.5 |
| NEXT CHARGE BY LIST | 16 | 10 | 7 | 2.33 | +195 | +27.9 |
| MEETS IN TIME | 27 | 27 | 6 | 2.00 | +34 | +5.6 |
| SHOOTERS IN TWO RANKS | 6 | 6 | 6 | 2.00 | +12 | +2.0 |
| SHORT GUN FORWARD | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| SHOTS IN THE MOVE | 132 | 109 | 6 | 2.00 | +78 | +13.0 |
| CHAFF IN THE MOVE | 5 | 5 | 5 | 1.67 | +12 | +2.3 |
| FOUR ROUNDS | 10 | 10 | 5 | 1.67 | +62 | +12.5 |
| SHOTS AFTER THE MOVES | 25 | 25 | 5 | 1.67 | +0 | +0.0 |
| STAY WORTH | 257 | 240 | 5 | 1.67 | +71 | +14.2 |
| SUPPORT ADDS | 12 | 12 | 5 | 1.67 | +38 | +7.7 |
| SUPPORT WORKED OUT | 12 | 12 | 5 | 1.67 | +38 | +7.7 |
| LANE BY FIGURES | 4 | 4 | 4 | 1.33 | +233 | +58.2 |
| MANOEUVRE | 9 | 9 | 4 | 1.33 | +14 | +3.6 |
| RESERVE FALL BACK | 4 | 4 | 4 | 1.33 | +77 | +19.1 |
| WHOLE FIGHT DANGER | 11 | 11 | 4 | 1.33 | +208 | +51.9 |
| WOUNDS ON THE RANKS | 19 | 18 | 4 | 1.33 | +191 | +47.8 |
| ADVANCE LANE KEPT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| CHAFF PASSED | 3 | 3 | 3 | 1.00 | -4 | -1.5 |
| GUN MASK | 6 | 5 | 3 | 1.00 | +132 | +43.9 |
| RISK BY ARC | 7 | 7 | 3 | 1.00 | +35 | +11.6 |
| EXACT ROUND | 8 | 8 | 2 | 0.67 | +8 | +4.1 |
| FALLS SHORT | 55 | 46 | 2 | 0.67 | +19 | +9.5 |
| FEATURE BUFFS | 4 | 4 | 2 | 0.67 | +4 | +2.2 |
| FIGHT TO THE END | 4 | 4 | 2 | 0.67 | +16 | +7.8 |
| FIRE IN ORDER | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| HOLDS AMBUSHERS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| JOINT CHARGE NOW | 2 | 2 | 2 | 0.67 | +662 | +331.2 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| OVERRUNS AWAY | 3 | 3 | 2 | 0.67 | +13 | +6.4 |
| PATHS CROSS | 2 | 2 | 2 | 0.67 | +3 | +1.6 |
| REDIRECT BY WHAT IT STOPS | 5 | 5 | 2 | 0.67 | +25 | +12.3 |
| SET UP BY THE SET | 4 | 4 | 2 | 0.67 | +46 | +23.1 |
| STUCK PIVOT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| TIED UP BY THE SUM | 2 | 2 | 2 | 0.67 | +32 | +16.1 |
| AFTERMATH IN POINTS | 1 | 1 | 1 | 0.33 | +16 | +15.7 |
| CHALLENGE BY POINTS | 1 | 1 | 1 | 0.33 | +123 | +122.9 |
| COMBAT PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 1 | 1 | 1 | 0.33 | +323 | +323.1 |
| HIS CHARGE DENIED | 2 | 2 | 1 | 0.33 | +6 | +5.5 |
| HIS TURN DENIED | 2 | 2 | 1 | 0.33 | +1 | +0.6 |
| LONE WIZARD KEPT IN | 1 | 1 | 1 | 0.33 | +75 | +75.0 |
| LOST AFTER ESCAPE | 7 | 7 | 1 | 0.33 | +5 | +5.0 |
| MAX FOR POSITIONING | 4 | 2 | 1 | 0.33 | +1 | +0.9 |
| ONE FIGHT FORMULA | 28 | 20 | 1 | 0.33 | +0 | +0.0 |
| ONE OBJECTIVE FORMULA | 17 | 12 | 1 | 0.33 | +42 | +42.5 |
| PIVOT GUARDS FLANK | 1 | 1 | 1 | 0.33 | -8 | -8.2 |
| REFORMS TO MEET IT | 5 | 5 | 1 | 0.33 | +4 | +4.5 |
| REFUSING RETIRES | 1 | 1 | 1 | 0.33 | -11 | -10.7 |
| RESTRAINS TO SHOOT | 1 | 1 | 1 | 0.33 | +7 | +7.1 |
| SHOOTS FROM THE BEST SPOT | 1 | 1 | 1 | 0.33 | +57 | +57.0 |
| SWIFTSTRIDE BY POINTS | 1 | 1 | 1 | 0.33 | +1 | +0.8 |
| THE ROW IN ITS ORDER | 12 | 1 | 1 | 0.33 | +0 | +0.0 |
| BACKUP TARGETS | 1 | 1 | 0 | 0.00 | - | - |
| BLOWS WHERE AIMED | 1 | 1 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 5 | 5 | 0 | 0.00 | - | - |
| CHARACTER GUNS | 13 | 13 | 0 | 0.00 | - | - |
| CHARGE NOW FIRST | 4 | 4 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 53 | 52 | 0 | 0.00 | - | - |
| DEFENSIVE ARMY | 3 | 3 | 0 | 0.00 | - | - |
| DENIED BY THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| EDGE GIVE GROUND | 1 | 1 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 6 | 6 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 17 | not checked | - | - | - | - |
| FRIEND SHOOTS FIRST | 2 | 2 | 0 | 0.00 | - | - |
| GIVES UP | 1 | 1 | 0 | 0.00 | - | - |
| GUN FIGURES | 6 | not checked | - | - | - | - |
| HELPER UNSEEN | 1 | 1 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 26 | 25 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 63 | 60 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 19 | 17 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 19 | 19 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 8 | 8 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 21 | 19 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 64 | 63 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 2 | 2 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN RUN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 75 | 75 | 0 | 0.00 | - | - |
| HONEST WORTH | 8 | 8 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 16 | 16 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 9 | 9 | 0 | 0.00 | - | - |
| MISSILES IN THE MOVE | 1 | 1 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 5 | 5 | 0 | 0.00 | - | - |
| NEARER NOT NEEDED | 22 | 20 | 0 | 0.00 | - | - |
| NEXT OBJECTIVE NEARER | 1 | 1 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 8 | 8 | 0 | 0.00 | - | - |
| NO LATE CUT | 5 | 5 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 18 | 18 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| ONE CHALLENGE TEST | 1 | 1 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 1 | not checked | - | - | - | - |
| ONE JOINT FIGURE | 1 | 1 | 0 | 0.00 | - | - |
| ONE ROUTE | 9 | 9 | 0 | 0.00 | - | - |
| PLAN RESULT | 287 | trace | - | - | - | - |
| PROMISE KNOWS THE FIGHT | 10 | 4 | 0 | 0.00 | - | - |
| QUARTER ODDS | 69 | 67 | 0 | 0.00 | - | - |
| REAL GROUND | 9 | 9 | 0 | 0.00 | - | - |
| REDIRECT COUNTER | 9 | 7 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 2 | 2 | 0 | 0.00 | - | - |
| RUN DOWN | 8 | 8 | 0 | 0.00 | - | - |
| SAME CHARGE LATER | 1 | 1 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 4 | 4 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 2 | 2 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 98 | not checked | - | - | - | - |
| SPELL WORTH | 3 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 26 | 17 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 3 | 3 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 7 | 7 | 0 | 0.00 | - | - |
| STANDS STILL | 368 | 354 | 0 | 0.00 | - | - |
| SUPPORT NARROWED | 3 | 3 | 0 | 0.00 | - | - |
| SURE REACH TOGETHER | 1 | 1 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 10 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 23 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 12 | not checked | - | - | - | - |
| THE TABLE BINDS | 287 | not checked | - | - | - | - |
| WAITS AGAIN | 3 | 2 | 0 | 0.00 | - | - |
| WHO FIGHTS | 3 | 3 | 0 | 0.00 | - | - |
| WHOLE FIGHT GAIN | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: cnomg-c940641-p40

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| PROMISE BY ITS OWN SUM | rule | 6.33 | 2.67 | 32.7 |
| JOB FIRST | gate | 5.00 | 2.67 | 26.6 |
| ARMY TABLE | rule | 2.33 | 3.67 | 19.6 |
| CANNON PLANNED TARGET | rule | 2.33 | - | 9.6 |
| CHAFF PASSED | rule | 0.67 | - | 2.2 |
| HOLDER ASSIGNMENT | rule | 0.67 | - | 16.8 |
| DEPLOY BY FIGURES | rule | - | 0.33 | 5.8 |
| FALLBACK | gate | 0.33 | - | 7.6 |
| PIVOT GUARDS FLANK | rule | - | 0.33 | 8.2 |
| REFUSING RETIRES | rule | 0.33 | - | 10.7 |

### Plans: cnomg-c940641-p40

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.3 | 50% | 44 | 64 | 147% |
| Mine | join | 2.7 | 100% | 88 | 0 | 0% |
| Mine | move | 34.0 | 99% | 1033 | 0 | 0% |
| Mine | shoot | 22.7 | 79% | 1059 | 2098 | 198% |
| Opponent | charge | 1.3 | 75% | 207 | 166 | 80% |
| Opponent | move | 28.7 | 98% | 961 | 0 | 0% |
| Opponent | shoot | 3.3 | 30% | 209 | 82 | 39% |
| Opponent | support | 1.7 | 80% | 26 | 0 | 0% |

### Battle groups: cnomg-c940641-p40

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | REDIRECT COUNTER | 3.0 | 22% | 50% | 0% | - | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: cnomg-c940641-p40

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | - | 0 (1) | 0 (1) | - |
| Mine | Character | 13 | 3 (13) | 3 | 0 | 6 | 38% | 2.9 | 0 (3) | 0 (5) | 7 (4) | 4 (7) | 0 (5) |
| Mine | Clean-up | 3 | 37 (3) | 37 | 0 | 0 | 33% | 1.0 | 0 (1) | 228 (1) | 0 (1) | 114 (2) | 0 (1) |
| Mine | Hammer | 6 | 78 (6) | 13 | 65 | 0 | 67% | 2.5 | - | 80 (4) | 73 (2) | 74 (5) | 88 (1) |
| Mine | Shooter | 10 | 66 (10) | 6 | 60 | 29 | 20% | 2.1 | - | 49 (4) | 83 (6) | 45 (5) | 91 (5) |
| Mine | War machine | 17 | 33 (17) | 33 | 0 | 7 | 18% | 1.1 | 0 (9) | 279 (2) | 0 (6) | 0 (3) | 41 (14) |
| Opponent | Chaff | 5 | 0 (5) | 0 | 0 | 58 | 60% | 2.0 | 0 (4) | - | 0 (1) | 0 (4) | 0 (1) |
| Opponent | Character | 8 | 20 (8) | 20 | 0 | 18 | 75% | 2.0 | 0 (3) | 0 (1) | 43 (4) | 31 (5) | 0 (3) |
| Opponent | Clean-up | 3 | 53 (3) | 0 | 53 | 0 | 100% | - | 71 (1) | 34 (2) | - | 53 (3) | - |
| Opponent | Fast Hammer | 4 | 27 (4) | 0 | 27 | 12 | 50% | 2.5 | - | 48 (3) | 0 (1) | 61 (2) | 0 (2) |
| Opponent | Hammer | 3 | 0 (3) | 0 | 0 | 0 | 100% | - | 0 (1) | 0 (2) | - | 0 (3) | - |
| Opponent | Holder | 2 | 0 (2) | 0 | 0 | 44 | 50% | 2.0 | - | 0 (2) | - | 0 (1) | 0 (1) |
| Opponent | Support | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | War machine | 2 | 58 (2) | 58 | 0 | 50 | 0% | 1.0 | - | - | 58 (2) | - | 58 (2) |
| Opponent | Wizard | 2 | 0 (2) | 0 | 0 | 0 | 50% | 1.0 | 0 (1) | 0 (1) | - | 0 (2) | - |

### Charged fights: cnomg-c940641-p40

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Dwarfen Mountain Holds | 3 | 241 | 72 | 1.7 | 1.0 | 43 | 0 | +43 | 0 of 5 | 4 of 5 | - | +43 |
| Opponent | Kingdom of Bretonnia | 1 | 115 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Warriors of Chaos | 2 | 0 | 139 | 0.5 | 1.0 | 278 | 0 | +278 | 1 of 1 | 1 of 1 | - | +278 |
| **Opponent** | all armies | 3 | 38 | 93 | 0.3 | 1.0 | 278 | 0 | +278 | 1 of 1 | 1 of 1 | - | +278 |

### Effective charges: cnomg-c940641-p40

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Dwarfen Mountain Holds | 5 | 0 | 0 | 1 (net +0) | 2 (net +40) | 0 | 2 (net +68) | 0 | 20% (1 of 5) |

### Charged fights, damage counted: cnomg-c940641-p40

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Effective (55-75%) | 1 | 60 | 80 | +0 | 32 | 20 | +12 | +20.0 |
| Mine | 76-89% | 2 | 82 | 108 | +40 | 40 | 0 | +40 | +48.5 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 60 | 137 | +68 | 103 | 0 | +103 | +171.2 |
| Mine | All fights | 5 | 69 | 114 | +43 | 64 | 4 | +60 | +86.2 |
| Opponent | No odds | 1 | 489 | 183 | +278 | 318 | 161 | +157 | +32.1 |
| Opponent | All fights | 1 | 489 | 183 | +278 | 318 | 161 | +157 | +32.1 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| cnomg-c940641-p40 | move | 19 | 3 (16%) | 3 (16%) | 1 (5%) | 15 (79%) |

## Decision items and abilities without guidance

None: every decision item and ability on these lists has its guidance line.

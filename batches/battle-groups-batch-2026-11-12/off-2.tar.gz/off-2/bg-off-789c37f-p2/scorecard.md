# Doctrine scorecard: bg-off-789c37f-p2

### Scorecard: bg-off-789c37f-p2

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0106 | 4 | 1 | Mine | no | 2 | 2 | 2 | 3 | 0 | 0 | 0 | 387 |
| L0106 | 4 | 1 | Opponent | no | 0 | 2 | 3 | 0 | 0 | 0 | 0 | 798 |
| L0122 | 2 | 1 | Mine | - | - | 5 | 0 | 2 | 0 | 0 | 0 | 0 |
| L0122 | 2 | 1 | Opponent | - | - | 2 | 3 | 0 | 0 | 0 | 0 | 0 |
| L0206 | 2 | 1 | Mine | - | - | 5 | 1 | 5 | 1 | 0 | 0 | 0 |
| L0206 | 2 | 1 | Opponent | - | - | 1 | 1 | 2 | 0 | 0 | 0 | 615 |
| L0222 | 6 | 1 | Mine | no | 2 | 3 | 2 | 5 | 1 | 0 | 0 | 170 |
| L0222 | 6 | 1 | Opponent | no | 1 | 1 | 3 | 1 | 0 | 0 | 0 | 0 |
| L0307 | 1 | 1 | Mine | yes | 1 | 3 | 1 | 1 | 0 | 0 | 0 | 760 |
| L0307 | 1 | 1 | Opponent | yes | 1 | 2 | 4 | 0 | 0 | 0 | 0 | 420 |
| L0323 | 5 | 1 | Mine | yes | - | 6 | 1 | 2 | 1 | 0 | 0 | 590 |
| L0323 | 5 | 1 | Opponent | yes | - | 2 | 2 | 4 | 2 | 0 | 0 | 140 |
| L0409 | 1 | 1 | Mine | no | 2 | 2 | 2 | 2 | 0 | 0 | 0 | 0 |
| L0409 | 1 | 1 | Opponent | no | 8 | 6 | 0 | 0 | 0 | 0 | 0 | 913 |
| L0425 | 5 | 1 | Mine | yes | - | 2 | 5 | 2 | 0 | 0 | 0 | 0 |
| L0425 | 5 | 1 | Opponent | no | - | 2 | 2 | 6 | 0 | 0 | 0 | 0 |
| L0512 | 2 | 1 | Mine | - | - | 3 | 4 | 2 | 0 | 0 | 0 | 709 |
| L0512 | 2 | 1 | Opponent | - | - | 2 | 5 | 0 | 1 | 0 | 0 | 330 |
| L0528 | 6 | 1 | Mine | no | 0 | 3 | 1 | 2 | 0 | 0 | 0 | 901 |
| L0528 | 6 | 1 | Opponent | no | 4 | 3 | 0 | 2 | 0 | 0 | 0 | 0 |
| L0616 | 4 | 1 | Mine | no | 0 | 4 | 2 | 1 | 0 | 0 | 0 | 750 |
| L0616 | 4 | 1 | Opponent | no | 0 | 2 | 1 | 2 | 2 | 0 | 0 | 200 |
| L0632 | 2 | 1 | Mine | - | - | 3 | 3 | 0 | 0 | 0 | 0 | 801 |
| L0632 | 2 | 1 | Opponent | - | - | 2 | 3 | 4 | 0 | 0 | 0 | 139 |
| L0721 | 1 | 1 | Mine | yes | 1 | 3 | 1 | 0 | 0 | 0 | 0 | 420 |
| L0721 | 1 | 1 | Opponent | no | 0 | 6 | 1 | 3 | 1 | 0 | 0 | 500 |
| L0810 | 6 | 1 | Mine | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 515 |
| L0810 | 6 | 1 | Opponent | no | 8 | 3 | 1 | 1 | 1 | 0 | 0 | 501 |
| L0827 | 5 | 1 | Mine | no | - | 5 | 1 | 1 | 0 | 0 | 0 | 753 |
| L0827 | 5 | 1 | Opponent | yes | - | 3 | 4 | 4 | 0 | 0 | 0 | 0 |
| L0918 | 6 | 1 | Mine | no | 0 | 3 | 4 | 1 | 0 | 0 | 0 | 420 |
| L0918 | 6 | 1 | Opponent | no | 5 | 5 | 2 | 2 | 0 | 0 | 0 | 234 |
| L0934 | 4 | 1 | Mine | no | 1 | 1 | 2 | 0 | 0 | 0 | 0 | 1001 |
| L0934 | 4 | 1 | Opponent | no | 0 | 2 | 5 | 3 | 0 | 0 | 0 | 160 |
| L1026 | 6 | 1 | Mine | no | 0 | 2 | 4 | 1 | 1 | 0 | 0 | 497 |
| L1026 | 6 | 1 | Opponent | no | 2 | 2 | 6 | 0 | 1 | 0 | 0 | 0 |
| L1118 | 2 | 1 | Mine | - | - | 3 | 1 | 0 | 0 | 0 | 0 | 330 |
| L1118 | 2 | 1 | Opponent | - | - | 2 | 5 | 0 | 1 | 0 | 0 | 0 |
| L1135 | 1 | 1 | Mine | yes | 0 | 2 | 5 | 0 | 0 | 0 | 0 | 330 |
| L1135 | 1 | 1 | Opponent | yes | 0 | 2 | 3 | 2 | 0 | 0 | 0 | 158 |
| L1228 | 4 | 1 | Mine | no | 4 | 2 | 1 | 0 | 0 | 0 | 0 | 524 |
| L1228 | 4 | 1 | Opponent | no | 4 | 5 | 2 | 2 | 0 | 0 | 0 | 0 |
| L1323 | 3 | 1 | Mine | yes | 10 | 3 | 2 | 0 | 1 | 0 | 0 | 479 |
| L1323 | 3 | 1 | Opponent | no | 3 | 2 | 2 | 2 | 0 | 0 | 0 | 264 |
| L1418 | 2 | 1 | Mine | - | - | 2 | 5 | 2 | 1 | 0 | 0 | 123 |
| L1418 | 2 | 1 | Opponent | - | - | 2 | 2 | 2 | 1 | 0 | 0 | 836 |
| L1435 | 1 | 1 | Mine | no | 2 | 2 | 0 | 1 | 0 | 0 | 0 | 0 |
| L1435 | 1 | 1 | Opponent | no | 1 | 2 | 6 | 1 | 0 | 0 | 0 | 572 |
| L1531 | 1 | 1 | Mine | no | 4 | 2 | 3 | 0 | 1 | 0 | 0 | 126 |
| L1531 | 1 | 1 | Opponent | no | 3 | 4 | 3 | 0 | 2 | 0 | 0 | 484 |
| L1629 | 3 | 1 | Mine | no | 3 | 3 | 1 | 0 | 1 | 0 | 0 | 536 |
| L1629 | 3 | 1 | Opponent | no | 0 | 2 | 3 | 1 | 0 | 0 | 0 | 170 |
| L1727 | 5 | 1 | Mine | yes | - | 4 | 4 | 0 | 1 | 0 | 0 | 0 |
| L1727 | 5 | 1 | Opponent | yes | - | 2 | 5 | 4 | 2 | 0 | 0 | 0 |
| L1827 | 3 | 1 | Mine | no | 1 | - | 2 | 0 | 0 | 0 | 0 | 482 |
| L1827 | 3 | 1 | Opponent | no | 2 | 2 | 10 | 0 | 0 | 0 | 0 | 0 |
| L1927 | 1 | 1 | Mine | no | 1 | 1 | 4 | 0 | 0 | 0 | 0 | 156 |
| L1927 | 1 | 1 | Opponent | no | 3 | 2 | 2 | 3 | 0 | 0 | 0 | 60 |
| L2029 | 1 | 1 | Mine | no | 0 | - | 1 | 2 | 2 | 0 | 0 | 650 |
| L2029 | 1 | 1 | Opponent | no | 4 | 2 | 1 | 1 | 0 | 0 | 0 | 292 |
| L2131 | 1 | 1 | Mine | yes | 1 | - | 2 | 3 | 0 | 0 | 0 | 850 |
| L2131 | 1 | 1 | Opponent | no | 3 | 2 | 2 | 0 | 1 | 0 | 0 | 170 |
| L2235 | 3 | 1 | Mine | no | 0 | 1 | 5 | 1 | 0 | 0 | 0 | 55 |
| L2235 | 3 | 1 | Opponent | no | 0 | 3 | 2 | 2 | 1 | 0 | 0 | 0 |
| L2429 | 5 | 1 | Mine | yes | - | 4 | 4 | 1 | 0 | 0 | 0 | 0 |
| L2429 | 5 | 1 | Opponent | yes | - | 3 | 5 | 4 | 1 | 0 | 0 | 170 |
| L2535 | 3 | 1 | Mine | no | 2 | 2 | 2 | 0 | 0 | 0 | 0 | 0 |
| L2535 | 3 | 1 | Opponent | yes | 0 | 1 | 2 | 0 | 0 | 0 | 0 | 158 |
| L2735 | 5 | 1 | Mine | yes | - | - | 2 | 1 | 1 | 0 | 0 | 60 |
| L2735 | 5 | 1 | Opponent | yes | - | 2 | 4 | 3 | 0 | 0 | 0 | 0 |
| L3033 | 3 | 1 | Mine | yes | 5 | 3 | 6 | 0 | 1 | 0 | 0 | 0 |
| L3033 | 3 | 1 | Opponent | no | 2 | 1 | 2 | 1 | 0 | 0 | 0 | 236 |
| **Average** | | | Mine | 37% | 1.8 | 2.9 | 2.4 | 1.2 | 0.4 | 0.0 | 0.0 | 371.5 |
| **Average** | | | Opponent | 27% | 2.2 | 2.5 | 3.0 | 1.7 | 0.5 | 0.0 | 0.0 | 236.7 |

### KPIs: bg-off-789c37f-p2

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Winner chose to follow up after the loser gave ground |  | 99% (92 of 93); on the table 99% | 96% (48 of 50); on the table 96% | 98% (140 of 143); on the table 98% |
| Winner chose to pursue after the loser fell back in good order |  | 75% (6 of 8); on the table 75% | 80% (12 of 15); on the table 87% | 78% (18 of 23); on the table 83% |
| Winner chose to pursue after the loser fled |  | 63% (19 of 30); on the table 70% | 81% (30 of 37); on the table 86% | 73% (49 of 67); on the table 79% |
| Winner chose to follow up or pursue (all three) |  | 89% (117 of 131); on the table 91% | 88% (90 of 102); on the table 91% | 89% (207 of 233); on the table 91% |
| Magic missiles tried each own turn | 50%+ | 28% (95 of 342) | 30% (47 of 156) | 29% (142 of 498) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 36% (83 of 232) | 44% (47 of 107) | 38% (130 of 339) |
| Points that never fought | lower | 36% (25496 of 71583) | 37% (26990 of 71989) | 37% (52486 of 143572) |
|   infantry points that never fought | lower | 41% (6682 of 16324) | 51% (7119 of 14029) | 45% (13801 of 30353) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 59% (167 of 284) | 58% (173 of 297) | 59% (340 of 581) |
| Bound items with a magic missile used (at least once a game) |  | 95% (19 of 20); 1.3 uses a game | 67% (12 of 18); 0.8 uses a game | 82% (31 of 38); 1.1 uses a game |
| Bound items with another spell used |  | 44% (8 of 18); 0.3 uses a game | 50% (1 of 2); 0.0 uses a game | 45% (9 of 20); 0.2 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 45% (9 of 20); 0.2 uses a game | 29% (2 of 7); 0.1 uses a game | 41% (11 of 27); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 54% (32488 of 60231) | 51% (32022 of 63281) | 52% (64510 of 123512) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.5 (22%) | 0.6 (21%) | 2.1 (22%) |
| MARCHED: its unit marched | 2.0 (30%) | 0.7 (23%) | 2.7 (28%) |
| CHARGED: its unit charged | 0.4 (6%) | 0.2 (6%) | 0.6 (6%) |
| IN COMBAT: engaged in combat | 1.3 (19%) | 0.4 (14%) | 1.7 (17%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.1 (2%) | 0.1 (1%) |
| FLEEING: fleeing | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | 1.0 (15%) | 0.6 (20%) | 1.6 (16%) |
| OFF THE TABLE: off the table or not arrived | 0.4 (6%) | 0.3 (11%) | 0.7 (7%) |
| STUPIDITY: Stupidity | 0.1 (2%) | 0.0 (0%) | 0.1 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (1%) | 0.1 (1%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.1 (2%) | 0.1 (1%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 3.4 | 1.5 | 1.4 | 3.9 | 0.3 | 1.7 |
| not cast | 4.4 | 3.4 | 3.6 | 9.9 | 2.0 | 20.0 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.1 (2%) | 0.0 (0%) | 0.0 (0%) | 1.1 (5%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (1%) | 1.5 (43%) | 0.3 (8%) | 2.1 (22%) | 0.4 (18%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.7 (28%) | 0.7 (34%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.6 (6%) | 0.1 (4%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.1 (2%) | 0.1 (3%) | 0.5 (15%) | 1.7 (17%) | 0.3 (14%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.1 (3%) | 0.2 (6%) | 0.2 (5%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) |
| NO CASTS LEFT: every cast used on other spells | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (3%) | 0.0 (0%) |
| FLEEING: fleeing | 0.2 (5%) | 0.4 (11%) | 0.1 (2%) | 0.0 (0%) | 0.0 (0%) | 0.7 (3%) |
| GONE: slain | 1.4 (31%) | 0.5 (15%) | 0.8 (23%) | 1.6 (16%) | 0.4 (21%) | 3.2 (16%) |
| OFF THE TABLE: off the table or not arrived | 0.5 (11%) | 0.2 (7%) | 0.2 (6%) | 0.7 (7%) | 0.0 (1%) | 1.1 (6%) |
| STUPIDITY: Stupidity | 0.1 (2%) | 0.0 (0%) | 0.0 (1%) | 0.1 (1%) | 0.0 (0%) | 0.4 (2%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (1%) | 0.4 (11%) | 0.1 (2%) | 0.1 (1%) | 0.1 (5%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.0 (45%) | 0.2 (5%) | 1.3 (37%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 13.6 (68%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.9 a game | 0.7 a game | 0.8 a game |
| stood (cast and not dispelled) | 64% (18 of 28) | 58% (15 of 26) | 61% (33 of 54) |
| the unit moved after it | 78% (14 of 18) | 73% (11 of 15) | 76% (25 of 33) |
| it charged on its next turn | 11% (2 of 18) | 13% (2 of 15) | 12% (4 of 33) |
| the enemy charged it first | 22% (4 of 18) | 7% (1 of 15) | 15% (5 of 33) |
| it fought by the end of its next turn | 17% (3 of 18) | 0% (0 of 15) | 9% (3 of 33) |
| it moved out of a charge the enemy had planned (not charged first) | 6% (1 of 18) | 20% (3 of 15) | 12% (4 of 33) |
| none of these (no charge, no fight, no charge escaped) | 67% (12 of 18) | 67% (10 of 15) | 67% (22 of 33) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 63% (537 of 853) | 51% (400 of 792) | 57% (937 of 1645) |
|   cavalry | 74% (55 of 74) | 48% (82 of 171) | 56% (137 of 245) |
|   character | 52% (48 of 93) | 30% (33 of 109) | 40% (81 of 202) |
|   chariot | 33% (33 of 100) | 67% (29 of 43) | 43% (62 of 143) |
|   infantry | 54% (141 of 259) | 51% (156 of 304) | 53% (297 of 563) |
|   monster | 42% (20 of 48) | 68% (25 of 37) | 53% (45 of 85) |
|   war machine | 86% (240 of 279) | 59% (75 of 128) | 77% (315 of 407) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 3.0 (34%) | 3.5 (32%) | 6.5 (33%) |
| CHARGED: it charged | 1.4 (16%) | 1.8 (16%) | 3.1 (16%) |
| FLEEING: it fled or was fleeing | 0.1 (2%) | 0.1 (1%) | 0.3 (1%) |
| IN COMBAT: it fought this turn or the last | 1.0 (12%) | 0.8 (7%) | 1.8 (9%) |
| MOVED: a war machine that moved | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NO TARGET IN RANGE | 1.2 (13%) | 1.4 (13%) | 2.6 (13%) |
| ONLY IN COMBAT: the only targets were in combat | 0.3 (3%) | 0.4 (3%) | 0.6 (3%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.1 (13%) | 2.2 (20%) | 3.4 (17%) |
| SHELTERED: the target was sheltered | 0.4 (4%) | 0.3 (3%) | 0.7 (3%) |
| STUPIDITY | 0.0 (0%) | 0.1 (1%) | 0.1 (0%) |
| OTHER BAR | 0.3 (3%) | 0.4 (4%) | 0.7 (4%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 5.8 | 1.1 | 84% | 4.0 pts | 23 pts |
| character | 2.3 | 0.8 | 72% | 11.2 pts | 26 pts |
| chariot | 1.7 | 1.5 | 61% | 26.9 pts | 46 pts |
| infantry | 11.5 | 4.5 | 73% | 9.1 pts | 104 pts |
| monster | 1.4 | 0.3 | 84% | 6.4 pts | 9 pts |
| war machine | 8.8 | 6.3 | 66% | 22.8 pts | 199 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.2 | 6.1 | 5.1 |
| Charges that made contact a game | 2.8 | 4.1 | 3.5 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.72 declared, 0.40 contact (25 units) | 0.71 declared, 0.36 contact (14 units) | 0.72 declared, 0.38 contact (39 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.33 declared, 0.33 contact (6 units) | 1.00 declared, 0.75 contact (12 units) | 0.78 declared, 0.61 contact (18 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.53 declared, 0.37 contact (244 units) | 0.68 declared, 0.46 contact (290 units) | 0.61 declared, 0.42 contact (534 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 70% (51 of 73) | 44% (8 of 18) | 50% (6 of 12) | 63% (65 of 103) |
| Character in a unit | 76% (19 of 25) | 40% (6 of 15) | 20% (1 of 5) | 58% (26 of 45) |
| Character on its own | 81% (38 of 47) | 54% (21 of 39) | 26% (16 of 61) | 51% (75 of 147) |
| Chariot | 47% (8 of 17) | 77% (10 of 13) | - | 60% (18 of 30) |
| Infantry | 56% (53 of 94) | 47% (16 of 34) | 67% (2 of 3) | 54% (71 of 131) |
| Monster | 62% (18 of 29) | 67% (6 of 9) | - | 63% (24 of 38) |
| Monstrous | 50% (7 of 14) | 71% (10 of 14) | - | 61% (17 of 28) |
| War Machines | 74% (42 of 57) | 100% (2 of 2) | - | 75% (44 of 59) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 100% (15 of 15); on the table 100% | 23% (23 of 102) | 52% | 41% (9 of 22) | 83% (5 of 6); 2.2 uses a game | 100% (2 of 2); 1.2 uses a game | 83% (5 of 6); 1.2 uses a game |
| Chaos Dwarfs | 4 | 100% (8 of 8); on the table 100% | 44% (16 of 36) | 44% | 69% (22 of 32) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |
| Dwarfen Mountain Holds | 6 | 67% (6 of 9); on the table 67% | - | 45% | 76% (41 of 54) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 7 | 87% (13 of 15); on the table 87% | 27% (13 of 48) | 38% | 61% (46 of 76) | 0.0 uses a game | 100% (2 of 2); 0.4 uses a game | 0% (0 of 4); 0.0 uses a game |
| Grand Cathay | 6 | 96% (22 of 23); on the table 96% | 33% (45 of 138) | 44% | 52% (28 of 54) | 100% (14 of 14); 7.5 uses a game | 50% (1 of 2); 0.2 uses a game | 33% (2 of 6); 0.3 uses a game |
| High Elf Realms | 4 | 80% (12 of 15); on the table 80% | 22% (4 of 18) | 38% | 48% (16 of 33) | 100% (3 of 3); 1.8 uses a game | 29% (4 of 14); 1.0 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 2 | 75% (3 of 4); on the table 100% | - | 27% | 42% (5 of 12) | 0.0 uses a game | 0.0 uses a game | 100% (2 of 2); 1.0 uses a game |
| Lizardmen | 1 | 100% (10 of 10); on the table 100% | - | 8% | 43% (3 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 4 | 100% (11 of 11); on the table 100% | 0% (0 of 18) | 44% | 82% (23 of 28) | 75% (3 of 4); 1.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 1 | 100% (4 of 4); on the table 100% | 33% (4 of 12) | 24% | 25% (2 of 8) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Skaven | 3 | 80% (8 of 10); on the table 80% | 17% (3 of 18) | 33% | 68% (17 of 25) | 100% (2 of 2); 1.3 uses a game | 0.0 uses a game | 33% (1 of 3); 0.3 uses a game |
| Tomb Kings of Khemri | 5 | 92% (11 of 12); on the table 92% | - | 41% | 48% (12 of 25) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 9 | 87% (34 of 39); on the table 92% | 30% (20 of 66) | 28% | 65% (35 of 54) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 9 | 84% (31 of 37); on the table 89% | 44% (8 of 18) | 26% | 42% (31 of 73) | 0% (0 of 2); 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 0.1 uses a game |
| Wood Elf Realms | 7 | 90% (19 of 21); on the table 90% | 25% (6 of 24) | 36% | 64% (50 of 78) | 57% (4 of 7); 1.3 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (bg-off-789c37f-p2, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 49% (45) | 58% (38) | 53% (83) |
| ...free all their last turn and able to turn (per game) | 0.83 | 0.72 | 1.56 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.14 | 0.14 | 0.28 |
| ...with the charger already in that arc before they moved (per game) | 0.64 | 0.47 | 1.11 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 1.58 | 1.14 | 2.72 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.67 | 1.03 | 1.69 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 10.56 | 8.81 | 19.36 |

### Quality by phase: bg-off-789c37f-p2

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.8 | 3.3 |
| Strategy | Charge objectives carried out (made contact) | 43% (52 of 121) | 48% (94 of 195) |
| Strategy | Shoot objectives carried out (shot that target) | 45% (151 of 334) | 50% (97 of 194) |
| Strategy | Close-in objectives charged next turn | 12% (21 of 174) | 17% (36 of 209) |
| Strategy | Support requests answered (helper made contact too) | 54% (7 of 13) | 50% (11 of 22) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 75% (3 of 4) | 100% (2 of 2) |
| Strategy | Hexes on a unit its side charged or shot that turn | 29% (4 of 14) | 58% (7 of 12) |
| Strategy | Joined characters whose unit fought | 57% (26 of 46) | 45% (13 of 29) |
| Strategy | Lone characters that fought | 77% (76 of 99) | 78% (73 of 94) |
| Movement | Charges halted short of contact | 0.1 | 0.5 |
| Movement | Idle units | 1.2 | 1.7 |
| Movement | Points that never moved of their own | 371.5 | 236.7 |
| Movement | Fights charged into per game | 2.6 | 3.5 |
| Movement | Charges with odds: long shots (under 50%) | 12 of 77, net +28 | 24 of 112, net +9 |
| Movement | Charges with odds: sweet spot (55-75%) | 8 of 77, net -86 | 17 of 112, net +86 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 10 of 77, net +168 | 6 of 112, net +120 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 38 of 77, net +101 | 35 of 112, net +120 |
| Shooting | Shots by shooting units (incl. breath weapons) | 9.3 | 10.1 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 46% (154 of 334) | 48% (175 of 365) |
| Shooting | Points destroyed by shooting units | 53.1 | 10.2 |
| Shooting | War machine shots | 6.7 | 2.1 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 58% (138 of 240) | 45% (34 of 75) |
| Shooting | Points destroyed by war machines | 76.8 | 65.5 |
| Magic | Magic missiles cast | 1.7 | 0.9 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 48% (29 of 61) | 58% (18 of 31) |
| Magic | Wounds caused by magic missiles | 2.0 | 0.9 |
| Magic | Wounds caused by other spells | 1.2 | 1.0 |
| Magic | Points destroyed by magic (all spells) | 52.1 | 26.8 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.8 / 0.4 / 0.7 / 0.0 | 1.7 / 0.3 / 0.4 / 0.1 |
| Combat | Points destroyed in combat | 395.4 | 435.8 |
| Combat | Points run down | 62.2 | 79.9 |
| Combat | Net points per charged fight, damage counted | +64 | +83 |
| Combat | Net per 100 charger points, damage counted | +25.0 | +30.2 |
| Combat | First round won (charged fights) | 66% | 54% |
| Combat | Net points per charged fight | +59 | +81 |
| Combat | Net points per supported fight / lone fight | +119 / +55 | +147 / +69 |
| Combat | Charged fights on a top-3 enemy unit | 29 of 95 | 55 of 125 |
| Game | Points lost | 816.2 | 726.6 |
| Game | VP from objectives | 503.9 | 621.4 |
| Game | Lone holders (player turns) | 1.8 | 2.2 |

- Mine won / drew / lost: 14 / 7 / 15 of 36 ended games (of 36); mean margin (Mine - Opponent) -246 VP
- The side that went first won 19 of 29 games with a winner
- Points traded per game (both sides' losses): 1543
- Games not ended: 0; findings 0, warnings 1

### Opponent rules: bg-off-789c37f-p2

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.6 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| ALREADY CARRIED | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARRIVAL HUNT | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +2.5 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.9 | +0.0 | 0.0 | 37.5 | 0.4 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | 0.6 | +3.7 | 0.0 | 0.0 | 1.0 | +12.5 | 0.0 | 23.2 |
| BEST PREY | 4.3 | +237.9 | 137.0 | 135.8 | 4.9 | +325.0 | 300.1 | 103.6 |
| BEST PRIZE | 0.0 | -6.4 | 0.0 | 0.0 | 0.1 | +3.1 | 16.6 | 13.7 |
| BLOCKED CHARGE SKIPPED | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| BLOCKED WHEEL | 0.4 | +6.4 | 0.0 | 29.1 | 0.6 | +13.1 | 0.0 | 0.0 |
| BOMBING RUN | 0.1 | +2.2 | 0.0 | 0.0 | - | - | - | - |
| BOUND ASSAILMENT | 0.0 | +0.0 | 0.0 | 3.5 | - | - | - | - |
| CANNON PLAN MISSED | 0.8 | +0.0 | 93.9 | 11.0 | 0.3 | +0.0 | 24.1 | 0.0 |
| CANNON PLANNED TARGET | 5.2 | +143.1 | 345.0 | 107.2 | 1.6 | +103.9 | 183.8 | 8.8 |
| CANNON SIGHT KEPT | 1.3 | +0.0 | 0.0 | 2.4 | 0.5 | +0.0 | 0.0 | 0.0 |
| CAST JOB | 0.9 | +28.8 | 54.2 | 32.9 | 0.3 | +5.3 | 21.7 | 7.2 |
| CASTER AWAY FROM SCREEN | 0.2 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.4 | +22.9 | 20.3 | 8.2 | 0.2 | +6.9 | 7.7 | 0.0 |
| CASTS AFTER FRIENDS | 0.5 | +0.0 | 0.0 | 21.0 | 0.5 | +0.0 | 0.0 | 17.9 |
| CASTS FROM BEHIND | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.0 | +0.2 | 0.0 | 0.0 | - | - | - | - |
| CATCH ODDS | 0.1 | +0.9 | 0.0 | 0.0 | - | - | - | - |
| CHAFF PASSED | 0.2 | -0.1 | 30.7 | 0.0 | 0.2 | -0.3 | 0.0 | 0.0 |
| CHARGE NOW WEIGHED | 0.5 | -35.8 | 22.7 | 13.8 | 0.8 | -66.5 | 30.4 | 43.1 |
| CHARIOT NO STATIC JOB | 0.9 | +0.0 | 12.4 | 15.6 | 0.6 | +0.0 | 2.4 | 4.1 |
| CHEAP HELPER | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 19.0 | 2.9 |
| CONTINUE AHEAD WEIGHED | 0.0 | +0.0 | 3.1 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | 0.5 | +57.1 | 16.4 | 23.6 | 0.6 | +38.4 | 8.4 | 34.6 |
| EDGE GIVE GROUND | 0.2 | +5.7 | 10.7 | 4.9 | 0.3 | +10.9 | 48.8 | 0.0 |
| ELIXIR WORTH | 0.0 | +0.3 | 0.0 | 0.0 | - | - | - | - |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 2.4 | - | - | - | - |
| FACES THE THREAT | 1.6 | +129.8 | 0.0 | 29.4 | 1.1 | +116.2 | 0.0 | 13.3 |
| FIGHT LIFT | 0.0 | +0.0 | 0.0 | 16.1 | 0.1 | +2.7 | 23.8 | 0.0 |
| FIRE AND FLEE | 0.0 | +0.1 | 0.0 | 0.0 | 0.1 | +1.0 | 0.0 | 3.2 |
| FOCUS FIRE | 0.0 | +0.9 | 0.0 | 0.0 | - | - | - | - |
| FOLLOW UP WEIGHED | 1.2 | +175.0 | 0.0 | 51.2 | 1.1 | +162.7 | 0.0 | 50.7 |
| FRIENDS SHOTS CHECKED | 0.2 | +11.7 | 0.0 | 6.6 | 0.1 | +6.6 | 0.0 | 0.0 |
| GATEWAY ESCAPE | - | - | - | - | 0.0 | +1.6 | 0.0 | 0.0 |
| GIVES UP | 0.9 | -25.2 | 74.6 | 8.6 | 1.5 | -43.8 | 147.1 | 63.6 |
| GIVES UP ITS SCREEN | 0.3 | -12.0 | 8.7 | 8.1 | 1.1 | -26.7 | 95.1 | 2.5 |
| GROUND FLIERS | 0.0 | +0.2 | 0.0 | 0.0 | - | - | - | - |
| HELPER ALREADY ASKED | - | - | - | - | 0.1 | +0.0 | 0.0 | 5.4 |
| HELPER UNSEEN | 0.2 | +0.0 | 9.2 | 12.1 | 0.4 | +0.0 | 11.1 | 14.2 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HORN WORTH | - | - | - | - | 0.0 | +0.6 | 0.0 | 0.0 |
| HUNT ADVANCE | 0.1 | +1.4 | 2.8 | 2.9 | 0.3 | +5.5 | 13.3 | 0.0 |
| HUNT DROPPED | 0.1 | +0.0 | 0.0 | 1.9 | 0.2 | +0.0 | 15.0 | 0.0 |
| HUNT KEPT | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +4.1 | 26.8 | 0.0 |
| HUNT RESULT | 0.1 | +7.5 | 0.0 | 3.3 | 0.3 | +32.4 | 15.0 | 0.0 |
| HUNT THE GUNS | 0.1 | +30.7 | 2.8 | 3.8 | 0.3 | +142.8 | 22.5 | 0.0 |
| JOINT CHARGE PLAN | 0.1 | +7.9 | 0.0 | 0.0 | 0.1 | +1.7 | 0.0 | 0.5 |
| KEEPS ITS PREY | 0.1 | +1.0 | 0.0 | 0.0 | 0.3 | +4.9 | 11.2 | 27.8 |
| KEEPS ITS TARGET | 1.3 | +39.2 | 84.6 | 37.6 | 2.6 | +77.5 | 201.5 | 75.1 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| KILLS COUNT | 1.5 | +72.8 | 67.9 | 61.8 | 2.0 | +75.3 | 181.8 | 8.3 |
| KILLS COUNT NEXT TURN | 7.6 | +271.3 | 275.8 | 204.0 | 10.9 | +488.9 | 571.2 | 218.7 |
| LONE CHARACTER SAFE SPOT | 0.6 | +23.5 | 20.9 | 24.6 | 0.3 | +6.8 | 0.0 | 6.3 |
| LONE WIZARD HOLDS BACK | 1.3 | +0.0 | 65.2 | 85.9 | 1.2 | +0.0 | 74.9 | 39.1 |
| LONE WIZARD KEPT IN | 0.6 | +39.4 | 0.0 | 0.0 | 0.3 | +23.5 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 0.3 | +28.0 | 8.2 | 1.4 | 1.0 | +66.0 | 64.3 | 32.1 |
| MANOEUVRE | 0.2 | +8.7 | 0.0 | 0.0 | 0.1 | +1.6 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.1 | +2.7 | 0.0 | 4.5 | 0.1 | +0.3 | 0.0 | 0.0 |
| MARCH ODDS | 0.9 | +104.0 | 48.6 | 32.2 | 0.6 | +57.9 | 14.2 | 39.6 |
| MISSILES IN THE MOVE | 2.9 | +86.6 | 0.0 | 86.1 | 2.4 | +40.7 | 0.0 | 105.6 |
| MISSILES NEXT TURN | 4.4 | +75.8 | 0.0 | 119.2 | 3.2 | +40.1 | 0.0 | 95.1 |
| MODEL FACING | 0.4 | +89.0 | 0.0 | 5.0 | 0.1 | +27.9 | 0.0 | 1.7 |
| MOVE AND CAST | 0.1 | +2.0 | 0.0 | 0.0 | 0.0 | +0.5 | 0.0 | 0.0 |
| MOVE SPELL IN RANGE | 0.1 | +5.0 | 0.0 | 32.2 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.3 | -13.8 | 6.9 | 18.8 | 0.2 | -6.0 | 0.0 | 30.1 |
| MOVE SPELL SPOT | 0.4 | +0.0 | 0.0 | 11.1 | 0.1 | +0.0 | 0.0 | 10.2 |
| MOVES UNITS SPELL | 0.1 | +3.4 | 0.0 | 0.0 | - | - | - | - |
| NEEDED THERE | 0.0 | +8.6 | 6.3 | 0.0 | 0.1 | +2.7 | 2.7 | 0.0 |
| NO RALLY LEFT | 0.0 | +0.1 | 0.0 | 0.0 | - | - | - | - |
| NOT NEEDED | 0.1 | -14.6 | 2.8 | 0.0 | 0.3 | -18.1 | 33.8 | 0.0 |
| NOT TURNED | 10.6 | +61.9 | 0.0 | 226.9 | 8.8 | +63.3 | 0.0 | 172.1 |
| NOT WORTH A CAST | 0.4 | -0.3 | 0.0 | 58.8 | 0.6 | -0.6 | 0.0 | 0.0 |
| OPENS A LANE | 0.1 | +0.2 | 5.0 | 0.0 | 0.1 | +0.1 | 8.8 | 0.0 |
| OPENS UP | 0.1 | +5.7 | 6.3 | 0.0 | 0.3 | +28.5 | 17.1 | 13.7 |
| OVERRUNS AWAY | 0.6 | +16.0 | 65.7 | 19.6 | 0.7 | +15.3 | 59.5 | 39.8 |
| PATHS CROSS | 2.2 | +85.3 | 0.0 | 45.3 | 3.1 | +187.6 | 0.0 | 30.2 |
| PERIAPT WORTH | - | - | - | - | 0.0 | +3.5 | 0.0 | 15.0 |
| PLAN LEADS | 1.3 | +139.5 | 26.3 | 9.8 | 1.1 | +63.2 | 20.3 | 11.9 |
| PLAN RESULT | 36.8 | +1232.9 | 1058.9 | 1072.9 | 40.6 | +1232.9 | 1485.5 | 948.6 |
| PURSUES BIG PREY | 0.1 | -1.7 | 0.0 | 0.0 | 0.2 | -12.2 | 0.0 | 13.1 |
| PURSUES ON | - | - | - | - | 0.0 | +0.1 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE NEXT TURN | 0.0 | +2.4 | 0.0 | 0.0 | 0.1 | +5.7 | 0.0 | 3.2 |
| REDIRECT WEIGHED | 0.3 | +3.8 | 4.0 | 1.4 | 0.3 | +19.4 | 11.0 | 0.0 |
| RESTRAINS TO SHOOT | 0.1 | +4.9 | 0.0 | 0.0 | 0.1 | +1.2 | 0.0 | 3.2 |
| RISK BY ARC | 1.8 | +47.2 | 131.8 | 67.4 | 3.0 | +69.0 | 255.1 | 100.1 |
| SAFE SURE CHARGE | 0.0 | -0.3 | 10.8 | 0.0 | 0.0 | -2.3 | 4.7 | 0.0 |
| SAFER THAN THE JOB | 0.7 | +39.8 | 0.0 | 2.5 | 1.0 | +90.6 | 0.0 | 18.0 |
| SCOUT SPOT | 0.3 | +0.6 | 0.0 | 0.0 | 0.5 | +2.1 | 0.0 | 1.8 |
| SCOUT WAITS | 0.3 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 1.8 |
| SEARCH SPOT | 0.6 | +34.4 | 0.0 | 12.8 | 0.8 | +45.2 | 0.0 | 3.2 |
| SECOND HUNTER | 0.0 | -0.0 | 0.0 | 0.0 | 0.1 | -0.3 | 4.6 | 0.0 |
| SELF MOVE SPELL | 0.3 | +9.2 | 0.0 | 0.0 | - | - | - | - |
| SET UP TOGETHER | 0.5 | +40.2 | 17.9 | 1.4 | 1.7 | +111.8 | 77.1 | 41.2 |
| SHOOTERS IN TWO RANKS | 0.4 | +0.8 | 0.0 | 0.0 | 0.3 | +0.5 | 0.0 | 0.0 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| SHOT REPLANNED | 0.7 | +0.0 | 134.1 | 1.5 | 0.2 | +0.0 | 50.3 | 4.6 |
| SHOTS IN THE MOVE | 13.0 | +542.4 | 0.0 | 225.9 | 9.8 | +350.5 | 0.0 | 107.0 |
| SPELL CATCH ODDS | 0.1 | -1.0 | 5.3 | 2.6 | - | - | - | - |
| SPELL SETS UP CHARGE | 0.1 | +45.2 | 0.0 | 0.0 | 0.1 | +46.5 | 0.0 | 0.0 |
| SPELL WORTH | 0.6 | +12.6 | 114.9 | 107.2 | 1.7 | +31.2 | 133.9 | 98.1 |
| STANDS TO CAST | 0.1 | +2.0 | 0.0 | 0.0 | - | - | - | - |
| STOPS | 0.0 | +0.1 | 0.0 | 0.9 | 0.2 | +8.1 | 36.0 | 0.0 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 4.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| SURE CHARGE BEATS ADVANCE | 0.1 | -1.9 | 0.0 | 0.0 | 0.2 | -5.9 | 28.5 | 15.0 |
| THROUGH LINE OF FIRE | 0.3 | +10.6 | 0.0 | 11.2 | 0.2 | +10.6 | 0.0 | 3.5 |
| TURN WORTH | 0.4 | -37.1 | 28.0 | 8.6 | 0.2 | -20.2 | 5.9 | 18.9 |
| TWO OR MORE ARRIVE | 0.2 | +6.3 | 17.9 | 1.4 | 0.7 | +13.2 | 43.4 | 1.5 |
| WEARS DOWN | 0.7 | +30.1 | 48.9 | 11.1 | 1.5 | +33.6 | 113.1 | 98.4 |
| WHO HITS BACK | 0.2 | +21.1 | 0.0 | 7.0 | 0.2 | +14.2 | 0.0 | 13.7 |
| WHOLE FIGHT | 0.3 | +7.1 | 47.1 | 22.0 | 0.5 | +7.3 | 31.8 | 19.8 |
| WHOLE FIGHT GAIN | 0.3 | +36.1 | 8.2 | 13.1 | 0.4 | +35.5 | 36.1 | 2.0 |

### Rule changes: bg-off-789c37f-p2

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| KILLS COUNT NEXT TURN | 667 | 658 | 208 | 5.78 | +6951 | +33.4 |
| BEST PREY | 332 | 326 | 138 | 3.83 | +4867 | +35.3 |
| ARTILLERY RE-ROLL WEIGHED | 83 | 83 | 83 | 2.31 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 81 | 81 | 81 | 2.25 | +12157 | +150.1 |
| CANNON SIGHT KEPT | 65 | 65 | 65 | 1.81 | +0 | +0.0 |
| CHARGE NOW WEIGHED | 48 | 48 | 48 | 1.33 | +2332 | +48.6 |
| SET UP TOGETHER | 79 | 79 | 45 | 1.25 | +2353 | +52.3 |
| ADVANCE LANE KEPT | 44 | 44 | 44 | 1.22 | +0 | +0.0 |
| MARCH ODDS | 55 | 41 | 41 | 1.14 | +1530 | +37.3 |
| CANNON PLANNED TARGET | 245 | 245 | 40 | 1.11 | -154 | -3.8 |
| HOLDS AMBUSHERS | 40 | 40 | 40 | 1.11 | +0 | +0.0 |
| LONE WIZARD HOLDS BACK | 88 | 88 | 37 | 1.03 | -1643 | -44.4 |
| CHARIOT NO STATIC JOB | 53 | 53 | 35 | 0.97 | -3024 | -86.4 |
| KEEPS ITS TARGET | 140 | 136 | 35 | 0.97 | +632 | +18.0 |
| PLAN LEADS | 88 | 88 | 35 | 0.97 | +1734 | +49.5 |
| LONE WIZARD KEPT IN | 33 | 33 | 33 | 0.92 | +2266 | +68.7 |
| SHOT REPLANNED | 33 | 33 | 33 | 0.92 | +0 | +0.0 |
| SCOUT WAITS | 32 | 32 | 32 | 0.89 | +0 | +0.0 |
| KILLS COUNT | 127 | 116 | 30 | 0.83 | +980 | +32.7 |
| RISK BY ARC | 173 | 161 | 29 | 0.81 | +1017 | +35.1 |
| MAKE SURE TOGETHER | 47 | 47 | 26 | 0.72 | +1431 | +55.0 |
| SHOOTERS IN TWO RANKS | 25 | 25 | 25 | 0.69 | +49 | +2.0 |
| REDIRECT WEIGHED | 22 | 22 | 22 | 0.61 | +1148 | +52.2 |
| CAST JOB | 43 | 41 | 19 | 0.53 | +415 | +21.9 |
| CASTING BLOCK | 20 | 20 | 18 | 0.50 | +590 | +32.8 |
| WHOLE FIGHT GAIN | 24 | 21 | 17 | 0.47 | +834 | +49.1 |
| MODEL FACING | 16 | 16 | 16 | 0.44 | +4211 | +263.2 |
| CASTS FROM BEHIND | 15 | 15 | 15 | 0.42 | +0 | +0.0 |
| WHO HITS BACK | 15 | 15 | 15 | 0.42 | -868 | -57.9 |
| SHORT GUN FORWARD | 14 | 14 | 14 | 0.39 | +0 | +0.0 |
| CASTER AWAY FROM SCREEN | 12 | 12 | 12 | 0.33 | +0 | +0.0 |
| CHAFF PASSED | 12 | 12 | 12 | 0.33 | -12 | -1.0 |
| SURE CHARGE BEATS ADVANCE | 11 | 11 | 11 | 0.31 | -280 | -25.5 |
| FRIENDS SHOTS CHECKED | 10 | 10 | 10 | 0.28 | +659 | +65.9 |
| PURSUES BIG PREY | 10 | 10 | 10 | 0.28 | -501 | -50.1 |
| WEARS DOWN | 79 | 75 | 8 | 0.22 | +160 | +19.9 |
| RESTRAINS TO SHOOT | 7 | 7 | 7 | 0.19 | +222 | +31.7 |
| STUCK PIVOT | 7 | 7 | 7 | 0.19 | +0 | +0.0 |
| TWO OR MORE ARRIVE | 34 | 34 | 7 | 0.19 | +150 | +21.5 |
| OPENS UP | 15 | 14 | 6 | 0.17 | +201 | +33.6 |
| OVERRUNS AWAY | 45 | 43 | 6 | 0.17 | +340 | +56.8 |
| FIRE AND FLEE | 5 | 5 | 5 | 0.14 | +41 | +8.2 |
| BLOCKED CHARGE SKIPPED | 4 | 4 | 4 | 0.11 | +0 | +0.0 |
| KEEPS SCOUTS OR AMBUSH | 4 | 4 | 4 | 0.11 | +0 | +0.0 |
| MOVES UNITS SPELL | 4 | 4 | 4 | 0.11 | +122 | +30.4 |
| WHOLE FIGHT | 29 | 27 | 4 | 0.11 | +291 | +72.7 |
| BEST PRIZE | 3 | 3 | 3 | 0.08 | -582 | -194.1 |
| HUNT ADVANCE | 13 | 13 | 3 | 0.08 | +70 | +23.3 |
| NEEDED THERE | 3 | 3 | 3 | 0.08 | +0 | +0.0 |
| RAIDS THE BAGGAGE NEXT TURN | 3 | 3 | 3 | 0.08 | +130 | +43.4 |
| BOMBING RUN | 2 | 2 | 2 | 0.06 | +78 | +38.8 |
| CONTINUE AHEAD WEIGHED | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| EDGE GIVE GROUND | 16 | 15 | 2 | 0.06 | +82 | +41.2 |
| MISSILES NEXT TURN | 277 | 121 | 2 | 0.06 | +70 | +34.8 |
| SAFE SURE CHARGE | 2 | 2 | 2 | 0.06 | -204 | -102.0 |
| STANDS TO CAST | 3 | 2 | 2 | 0.06 | +10 | +5.2 |
| BACKUP TARGETS | 57 | 25 | 1 | 0.03 | +16 | +15.7 |
| BOUND ASSAILMENT | 1 | 1 | 1 | 0.03 | +0 | +0.1 |
| ELIXIR WORTH | 1 | 1 | 1 | 0.03 | +11 | +11.3 |
| FOCUS FIRE | 1 | 1 | 1 | 0.03 | +31 | +31.4 |
| HORN WORTH | 1 | 1 | 1 | 0.03 | +20 | +20.5 |
| KEEPS ITS PREY | 16 | 15 | 1 | 0.03 | +4 | +4.3 |
| NO RALLY LEFT | 1 | 1 | 1 | 0.03 | +2 | +2.4 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.03 | +126 | +125.8 |
| PURSUES ON | 1 | 1 | 1 | 0.03 | +4 | +3.5 |
| ALREADY CARRIED | 3 | not checked | - | - | - | - |
| ARRIVAL HUNT | 4 | 4 | 0 | 0.00 | - | - |
| BLOCKED WHEEL | 37 | not checked | - | - | - | - |
| CANNON PLAN MISSED | 39 | 39 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 37 | trace | - | - | - | - |
| CATCH FLIERS | 1 | not checked | - | - | - | - |
| CATCH ODDS | 2 | not checked | - | - | - | - |
| CHEAP HELPER | 8 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 39 | not checked | - | - | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FACES THE THREAT | 98 | not checked | - | - | - | - |
| FIGHT LIFT | 5 | not checked | - | - | - | - |
| GATEWAY ESCAPE | 1 | not checked | - | - | - | - |
| GIVES UP | 86 | 81 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 51 | 48 | 0 | 0.00 | - | - |
| GROUND FLIERS | 1 | not checked | - | - | - | - |
| HELPER ALREADY ASKED | 2 | not checked | - | - | - | - |
| HELPER UNSEEN | 21 | 19 | 0 | 0.00 | - | - |
| HUNT DROPPED | 10 | trace | - | - | - | - |
| HUNT KEPT | 5 | trace | - | - | - | - |
| HUNT RESULT | 16 | trace | - | - | - | - |
| HUNT THE GUNS | 16 | trace | - | - | - | - |
| JOINT CHARGE PLAN | 7 | 7 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 30 | not checked | - | - | - | - |
| MANOEUVRE | 11 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 9 | trace | - | - | - | - |
| MISSILES IN THE MOVE | 188 | not checked | - | - | - | - |
| MOVE AND CAST | 5 | not checked | - | - | - | - |
| MOVE SPELL IN RANGE | 4 | 2 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 17 | trace | - | - | - | - |
| MOVE SPELL SPOT | 19 | not checked | - | - | - | - |
| NOT NEEDED | 17 | 17 | 0 | 0.00 | - | - |
| NOT TURNED | 697 | 697 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 39 | not checked | - | - | - | - |
| OPENS A LANE | 4 | not checked | - | - | - | - |
| PATHS CROSS | 192 | not checked | - | - | - | - |
| PLAN RESULT | 2785 | trace | - | - | - | - |
| SAFER THAN THE JOB | 61 | not checked | - | - | - | - |
| SCOUT SPOT | 28 | 28 | 0 | 0.00 | - | - |
| SEARCH SPOT | 52 | not checked | - | - | - | - |
| SECOND HUNTER | 3 | 3 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 11 | not checked | - | - | - | - |
| SHOTS IN THE MOVE | 819 | not checked | - | - | - | - |
| SPELL CATCH ODDS | 4 | not checked | - | - | - | - |
| SPELL SETS UP CHARGE | 8 | not checked | - | - | - | - |
| SPELL WORTH | 82 | not checked | - | - | - | - |
| STOPS | 7 | 7 | 0 | 0.00 | - | - |
| THROUGH LINE OF FIRE | 20 | not checked | - | - | - | - |
| TURN WORTH | 24 | 22 | 0 | 0.00 | - | - |

### Plans: bg-off-789c37f-p2

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 11.9 | 15% | 528 | 316 | 60% |
| Mine | charge | 2.7 | 55% | 251 | 188 | 75% |
| Mine | close in | 4.8 | 22% | 300 | 124 | 41% |
| Mine | hold | 3.9 | 38% | 259 | 0 | 0% |
| Mine | join | 0.8 | 93% | 30 | 0 | 0% |
| Mine | shoot | 8.0 | 65% | 268 | 605 | 225% |
| Mine | support | 4.7 | 91% | 270 | 0 | 0% |
| Opponent | advance | 14.2 | 19% | 632 | 470 | 74% |
| Opponent | charge | 4.2 | 48% | 504 | 329 | 65% |
| Opponent | close in | 5.8 | 24% | 478 | 151 | 32% |
| Opponent | hold | 4.2 | 41% | 387 | 0 | 0% |
| Opponent | join | 1.0 | 97% | 41 | 0 | 0% |
| Opponent | shoot | 4.4 | 64% | 158 | 284 | 180% |
| Opponent | support | 6.7 | 92% | 315 | 0 | 0% |

### Packages: hunt the guns, bg-off-789c37f-p2

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.1 | 4 | 0 | 0% | 25% | 0% | 2.0 | 277 | 68 | 25% | 47 |
| Opponent | 0.3 | 12 | 0 | 17% | 25% | 8% | 3.3 | 428 | 97 | 25% | 79 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.5 | 2 | 0 | 0% | 50% | 0% | 2.0 | 358 | 135 | 50% | 29 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 244 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 29 |
| Empire of Man | 0.3 | 2 | 0 | 0% | 50% | 0% | 2.0 | 242 | 115 | 50% | 60 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 159 |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Ogre Kingdoms | 1.2 | 5 | 0 | 20% | 20% | 0% | 3.0 | 393 | 100 | 20% | 160 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 320 |
| Tomb Kings of Khemri | 0.2 | 1 | 0 | 100% | 100% | 0% | 5.0 | 458 | 419 | 100% | 42 |
| Vampire Counts | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 8 |
| Warriors of Chaos | 0.3 | 3 | 0 | 0% | 0% | 33% | - | 471 | 6 | 0% | 0 |
| Wood Elf Realms | 0.4 | 3 | 0 | 0% | 0% | 0% | - | 403 | 0 | 0% | 0 |

### Deployment: positions vs output by unit type: bg-off-789c37f-p2

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 5 | 16 (5) | 16 | 0 | 52 | 20% | 3.0 | 0 (1) | 50 (1) | - | - | 33 (2) |
| Mine | Chaff | 44 | 57 (44) | 23 | 35 | 59 | 43% | 2.6 | 87 (24) | 0 (5) | 28 (15) | 74 (30) | 22 (14) |
| Mine | Character | 123 | 53 (123) | 53 | 0 | 46 | 16% | 2.4 | 65 (36) | 50 (57) | 64 (11) | 69 (61) | 40 (43) |
| Mine | Clean-up | 12 | 68 (12) | 6 | 62 | 54 | 25% | 3.6 | 60 (3) | 43 (6) | 151 (3) | 81 (7) | 52 (5) |
| Mine | Fast Hammer | 45 | 34 (45) | 22 | 12 | 51 | 24% | 2.9 | 41 (24) | 16 (10) | 37 (11) | 34 (31) | 34 (14) |
| Mine | Fragile | 5 | 0 (5) | 0 | 0 | 80 | 20% | 2.5 | - | 0 (3) | 0 (2) | 0 (5) | - |
| Mine | Hammer | 58 | 51 (58) | 36 | 15 | 36 | 22% | 2.6 | 20 (15) | 54 (33) | 94 (10) | 65 (38) | 29 (20) |
| Mine | Holder | 28 | 26 (28) | 0 | 26 | 43 | 43% | 3.7 | 12 (10) | 51 (12) | 4 (5) | 32 (18) | 19 (9) |
| Mine | Shooter | 43 | 75 (43) | 26 | 49 | 40 | 0% | 1.7 | 78 (7) | 93 (26) | 23 (10) | 102 (27) | 27 (16) |
| Mine | Support | 2 | 0 (2) | 0 | 0 | 0 | 50% | 2.0 | 0 (1) | 0 (1) | - | 0 (2) | - |
| Mine | War machine | 59 | 40 (59) | 40 | 0 | 48 | 2% | 1.3 | 10 (13) | 50 (36) | 34 (10) | 12 (10) | 45 (49) |
| Mine | Wizard | 22 | 26 (22) | 26 | 0 | 31 | 5% | 3.1 | 1 (8) | 72 (8) | 0 (3) | 49 (10) | 3 (9) |
| Opponent | Blocker | 2 | 0 (2) | 0 | 0 | 0 | 100% | - | 0 (1) | 0 (1) | - | 0 (1) | 0 (1) |
| Opponent | Chaff | 89 | 61 (89) | 30 | 31 | 38 | 39% | 2.7 | 68 (35) | 51 (20) | 62 (34) | 69 (63) | 43 (26) |
| Opponent | Character | 94 | 67 (94) | 66 | 1 | 38 | 18% | 2.3 | 90 (46) | 51 (31) | 34 (6) | 72 (59) | 75 (24) |
| Opponent | Clean-up | 10 | 28 (10) | 13 | 16 | 38 | 50% | 2.2 | 11 (6) | 75 (3) | 0 (1) | 17 (7) | 63 (3) |
| Opponent | Early | 2 | 0 (2) | 0 | 0 | 0 | 0% | 6.0 | - | 0 (2) | - | 0 (2) | - |
| Opponent | Fast Hammer | 45 | 34 (45) | 22 | 12 | 31 | 27% | 3.2 | 16 (28) | 46 (8) | 86 (9) | 27 (28) | 49 (17) |
| Opponent | Fragile | 5 | 0 (5) | 0 | 0 | 61 | 20% | 3.2 | - | 0 (3) | 0 (2) | 0 (4) | 0 (1) |
| Opponent | Hammer | 69 | 37 (69) | 31 | 6 | 52 | 22% | 2.9 | 32 (19) | 44 (37) | 12 (13) | 26 (40) | 51 (29) |
| Opponent | Holder | 33 | 58 (33) | 3 | 55 | 25 | 33% | 3.6 | 79 (7) | 55 (24) | 0 (1) | 71 (17) | 45 (15) |
| Opponent | Shooter | 35 | 60 (35) | 5 | 56 | 37 | 0% | 1.9 | 37 (11) | 84 (17) | 30 (7) | 91 (23) | 13 (12) |
| Opponent | Support | 3 | 20 (3) | 20 | 0 | 0 | 67% | 5.0 | 0 (1) | 40 (2) | - | 0 (1) | 40 (2) |
| Opponent | War machine | 24 | 59 (24) | 59 | 0 | 16 | 8% | 2.0 | 18 (6) | 81 (15) | 30 (3) | 0 (2) | 65 (22) |
| Opponent | Wizard | 29 | 19 (29) | 19 | 0 | 58 | 3% | 1.5 | 5 (10) | 38 (8) | 0 (3) | 28 (9) | 15 (12) |

### Charged fights: bg-off-789c37f-p2

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 90 | 148 | 1.5 | 1.0 | 98 | 0 | +98 | 1 of 6 | 5 of 6 | - | +98 |
| Mine | Chaos Dwarfs | 4 | 149 | 308 | 2.5 | 1.0 | 123 | 31 | +92 | 8 of 10 | 6 of 10 | - | +92 |
| Mine | Dwarfen Mountain Holds | 4 | 307 | 132 | 1.2 | 1.0 | 105 | 133 | -28 | 0 of 5 | 4 of 5 | - | -28 |
| Mine | Empire of Man | 5 | 498 | 99 | 1.2 | 1.5 | 82 | 18 | +64 | 2 of 6 | 5 of 6 | +192 | +0 |
| Mine | Grand Cathay | 4 | 191 | 324 | 2.5 | 1.0 | 130 | 0 | +130 | 1 of 10 | 7 of 10 | - | +130 |
| Mine | High Elf Realms | 4 | 147 | 622 | 4.0 | 1.1 | 155 | 16 | +139 | 4 of 16 | 11 of 16 | +228 | +133 |
| Mine | Kingdom of Bretonnia | 1 | 0 | 0 | 4.0 | 1.2 | 0 | 171 | -171 | 2 of 4 | 2 of 4 | +0 | -228 |
| Mine | Lizardmen | 1 | 0 | 761 | 5.0 | 1.0 | 152 | 100 | +52 | 3 of 5 | 3 of 5 | - | +52 |
| Mine | Ogre Kingdoms | 1 | 0 | 0 | 4.0 | 1.0 | 0 | 17 | -17 | 1 of 4 | 3 of 4 | - | -17 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 714 | 5.0 | 1.0 | 143 | 79 | +64 | 1 of 5 | 5 of 5 | - | +64 |
| Mine | Skaven | 2 | 58 | 0 | 1.5 | 1.0 | 0 | 129 | -129 | 0 of 3 | 0 of 3 | - | -129 |
| Mine | Tomb Kings of Khemri | 1 | 239 | 1258 | 6.0 | 1.0 | 210 | 9 | +200 | 2 of 6 | 3 of 6 | - | +200 |
| Mine | Vampire Counts | 3 | 57 | 117 | 3.0 | 1.1 | 39 | 160 | -121 | 3 of 9 | 5 of 9 | +102 | -148 |
| Mine | Warriors of Chaos | 1 | 0 | 953 | 6.0 | 1.2 | 159 | 29 | +130 | 1 of 6 | 4 of 6 | +0 | +156 |
| **Mine** | all armies | 36 | 182 | 296 | 2.6 | 1.1 | 112 | 53 | +59 | 29 of 95 | 63 of 95 | +119 | +55 |
| Opponent | Dwarfen Mountain Holds | 2 | 111 | 118 | 2.5 | 1.0 | 47 | 33 | +14 | 0 of 5 | 1 of 5 | - | +14 |
| Opponent | Empire of Man | 2 | 530 | 160 | 3.0 | 1.2 | 54 | 38 | +16 | 1 of 6 | 5 of 6 | +0 | +19 |
| Opponent | Grand Cathay | 2 | 342 | 656 | 2.5 | 1.2 | 262 | 87 | +175 | 5 of 5 | 2 of 5 | +776 | +25 |
| Opponent | Kingdom of Bretonnia | 1 | 175 | 663 | 4.0 | 1.8 | 166 | 187 | -21 | 2 of 4 | 4 of 4 | -132 | +90 |
| Opponent | Ogre Kingdoms | 3 | 304 | 102 | 3.7 | 1.2 | 28 | 91 | -63 | 4 of 11 | 2 of 11 | -103 | -55 |
| Opponent | Skaven | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Tomb Kings of Khemri | 4 | 20 | 577 | 2.8 | 1.0 | 210 | 185 | +25 | 8 of 11 | 5 of 11 | - | +25 |
| Opponent | Vampire Counts | 6 | 34 | 485 | 4.5 | 1.1 | 108 | 43 | +65 | 11 of 27 | 15 of 27 | -56 | +74 |
| Opponent | Warriors of Chaos | 8 | 28 | 628 | 3.1 | 1.4 | 201 | 20 | +181 | 14 of 25 | 16 of 25 | +310 | +131 |
| Opponent | Wood Elf Realms | 7 | 18 | 540 | 4.4 | 1.1 | 122 | 16 | +106 | 10 of 31 | 17 of 31 | +107 | +105 |
| **Opponent** | all armies | 36 | 102 | 468 | 3.5 | 1.2 | 135 | 54 | +81 | 55 of 125 | 67 of 125 | +147 | +69 |

### Effective charges: bg-off-789c37f-p2

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 6 | 0 | 0 | 0 | 0 | 1 (net +255) | 3 (net +92) | 2 | 0% (0 of 4) |
| Mine | Chaos Dwarfs | 10 | 4 (net +196) | 0 | 1 (net +0) | 1 (net -189) | 1 (net +60) | 3 (net +88) | 0 | 10% (1 of 10) |
| Mine | Dwarfen Mountain Holds | 5 | 0 | 0 | 0 | 0 | 0 | 5 (net -28) | 0 | 0% (0 of 5) |
| Mine | Empire of Man | 6 | 1 (net +0) | 0 | 0 | 0 | 2 (net +192) | 3 (net +0) | 0 | 0% (0 of 6) |
| Mine | Grand Cathay | 10 | 0 | 0 | 0 | 3 (net +98) | 1 (net +41) | 5 (net +192) | 1 | 0% (0 of 9) |
| Mine | High Elf Realms | 16 | 0 | 0 | 2 (net -58) | 1 (net +40) | 3 (net +280) | 6 (net +224) | 4 | 17% (2 of 12) |
| Mine | Kingdom of Bretonnia | 4 | 1 (net -471) | 0 | 0 | 0 | 0 | 2 (net -107) | 1 | 0% (0 of 3) |
| Mine | Lizardmen | 5 | 3 (net +254) | 0 | 1 (net +0) | 0 | 0 | 0 | 1 | 25% (1 of 4) |
| Mine | Ogre Kingdoms | 4 | 0 | 1 (net +0) | 0 | 0 | 0 | 1 (net +0) | 2 | 0% (0 of 2) |
| Mine | Orc & Goblin Tribes | 5 | 1 (net +250) | 0 | 0 | 0 | 0 | 0 | 4 | 0% (0 of 1) |
| Mine | Skaven | 3 | 1 (net -275) | 0 | 0 | 1 (net +0) | 0 | 1 (net -112) | 0 | 0% (0 of 3) |
| Mine | Tomb Kings of Khemri | 6 | 0 | 0 | 1 (net +102) | 1 (net +599) | 1 (net +0) | 3 (net +167) | 0 | 17% (1 of 6) |
| Mine | Vampire Counts | 9 | 1 (net -713) | 0 | 3 (net -225) | 1 (net -50) | 1 (net +102) | 2 (net +62) | 1 | 38% (3 of 8) |
| Mine | Warriors of Chaos | 6 | 0 | 0 | 0 | 0 | 0 | 4 (net +211) | 2 | 0% (0 of 4) |
| Opponent | Dwarfen Mountain Holds | 5 | 1 (net +65) | 0 | 0 | 2 (net +0) | 0 | 2 (net +2) | 0 | 0% (0 of 5) |
| Opponent | Empire of Man | 6 | 1 (net -227) | 0 | 2 (net +115) | 1 (net +91) | 1 (net +0) | 1 (net +0) | 0 | 33% (2 of 6) |
| Opponent | Grand Cathay | 5 | 3 (net -68) | 0 | 0 | 0 | 0 | 2 (net +540) | 0 | 0% (0 of 5) |
| Opponent | Kingdom of Bretonnia | 4 | 0 | 0 | 1 (net +120) | 1 (net +298) | 1 (net +60) | 1 (net -563) | 0 | 25% (1 of 4) |
| Opponent | Ogre Kingdoms | 11 | 3 (net +87) | 0 | 1 (net -702) | 1 (net -301) | 0 | 1 (net +0) | 5 | 17% (1 of 6) |
| Opponent | Tomb Kings of Khemri | 11 | 4 (net +63) | 0 | 0 | 3 (net +185) | 0 | 4 (net -134) | 0 | 0% (0 of 11) |
| Opponent | Vampire Counts | 27 | 8 (net -9) | 0 | 7 (net +169) | 3 (net -71) | 0 | 8 (net +106) | 1 | 27% (7 of 26) |
| Opponent | Warriors of Chaos | 25 | 1 (net +393) | 1 (net +392) | 2 (net +60) | 7 (net +108) | 2 (net +264) | 7 (net +311) | 5 | 10% (2 of 20) |
| Opponent | Wood Elf Realms | 31 | 3 (net -83) | 0 | 4 (net +128) | 11 (net +137) | 2 (net +64) | 9 (net +134) | 2 | 14% (4 of 29) |

### Charged fights, damage counted: bg-off-789c37f-p2

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 12 | 201 | 289 | +28 | 177 | 134 | +43 | +21.4 |
| Mine | 50-54% | 1 | 34 | 190 | +0 | 127 | 0 | +127 | +372.5 |
| Mine | Effective (55-75%) | 8 | 222 | 297 | -86 | 16 | 99 | -83 | -37.5 |
| Mine | 76-89% | 8 | 191 | 218 | +87 | 122 | 76 | +47 | +24.4 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 38 | 262 | 172 | +101 | 151 | 41 | +109 | +41.6 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 10 | 442 | 106 | +168 | 211 | 30 | +181 | +40.8 |
| Mine | No odds | 18 | 238 | 150 | -14 | 73 | 84 | -11 | -4.7 |
| Mine | All fights | 95 | 257 | 190 | +59 | 131 | 67 | +64 | +25.0 |
| Opponent | Long shot (under 50%) | 24 | 204 | 258 | +9 | 117 | 123 | -7 | -3.2 |
| Opponent | 50-54% | 1 | 494 | 197 | +392 | 392 | 0 | +392 | +79.4 |
| Opponent | Effective (55-75%) | 17 | 242 | 174 | +86 | 148 | 42 | +106 | +43.7 |
| Opponent | 76-89% | 29 | 268 | 192 | +93 | 155 | 45 | +110 | +41.0 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 35 | 314 | 208 | +120 | 216 | 96 | +120 | +38.3 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 6 | 583 | 110 | +120 | 120 | 17 | +102 | +17.5 |
| Opponent | No odds | 13 | 200 | 176 | +29 | 49 | 23 | +25 | +12.6 |
| Opponent | All fights | 125 | 275 | 201 | +81 | 153 | 70 | +83 | +30.2 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| bg-off-789c37f-p2 | move | 484 | 111 (23%) | 76 (16%) | 52 (11%) | 321 (66%) |
| bg-off-789c37f-p2 | objective | 383 | 57 (15%) | 39 (10%) | 54 (14%) | 272 (71%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0106, L0122, L2429, L2535, L2735 |
| Charmed Shield | Opponent | L0425, L0827, L0934, L1026, L1727, L1827, L1927 |
| Clockwork Compass | Mine | L1228 |
| Clockwork Compass | Opponent | L0512 |
| Elixir of Power | Mine | L1118, L1135, L1927 |
| Fistful of Laurels | Mine | L1827 |
| Fistful of Laurels | Opponent | L0918, L1118, L1418 |
| Horn of the Wild Hunt | Opponent | L3033 |
| Invocation of Nehek | Mine | L2429, L2535, L2735 |
| Invocation of Nehek | Opponent | L0425, L0827, L1727, L1827, L1927 |
| Opal Amulet | Mine | L1418, L1435 |
| Periapt of Soul Exchange | Mine | L2029, L2131 |
| Periapt of Soul Exchange | Opponent | L0721 |
| Ring of Doom | Mine | L0206, L0222, L1118, L1135, L1228, L1531 |
| Ring of Doom | Opponent | L0512, L1531, L2131, L3033 |
| Ring of Jet | Mine | L1026, L1118, L1135, L1228 |
| Ring of Jet | Opponent | L0512, L0810 |
| Standard of the Fell Warrior | Mine | L1323 |
| Storm Daemon (Renegade 2.0) | Mine | L2131 |
| Storm Daemon (Renegade 2.0) | Opponent | L0721 |
| Twice-Blessed Armour | Mine | L0721, L1026 |
| Twice-Blessed Armour | Opponent | L0307, L0810 |
| Witch Hunter's Ward | Mine | L0721, L0810, L0827 |
| Witch Hunter's Ward | Opponent | L0307 |

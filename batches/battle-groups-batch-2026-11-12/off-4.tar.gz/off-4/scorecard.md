# Doctrine scorecard: bg-off-789c37f-p4

### Scorecard: bg-off-789c37f-p4

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0114 | 6 | 1 | Mine | yes | 8 | 3 | 1 | 1 | 1 | 0 | 0 | 65 |
| L0114 | 6 | 1 | Opponent | no | 2 | 1 | 5 | 0 | 0 | 0 | 0 | 0 |
| L0130 | 4 | 1 | Mine | yes | 0 | 4 | 2 | 2 | 0 | 0 | 0 | 0 |
| L0130 | 4 | 1 | Opponent | no | 2 | 2 | 3 | 4 | 0 | 0 | 0 | 70 |
| L0214 | 4 | 1 | Mine | yes | 0 | 2 | 2 | 3 | 1 | 0 | 0 | 0 |
| L0214 | 4 | 1 | Opponent | no | 3 | 1 | 3 | 0 | 0 | 0 | 0 | 0 |
| L0230 | 2 | 1 | Mine | - | - | 2 | 4 | 3 | 0 | 0 | 0 | 0 |
| L0230 | 2 | 1 | Opponent | - | - | 3 | 3 | 0 | 0 | 0 | 0 | 0 |
| L0315 | 3 | 1 | Mine | no | 1 | 2 | 2 | 0 | 1 | 0 | 0 | 675 |
| L0315 | 3 | 1 | Opponent | yes | 1 | 2 | 4 | 0 | 1 | 0 | 0 | 0 |
| L0332 | 2 | 1 | Mine | - | - | 4 | 3 | 1 | 0 | 0 | 0 | 590 |
| L0332 | 2 | 1 | Opponent | - | - | 1 | 4 | 6 | 0 | 0 | 0 | 0 |
| L0417 | 3 | 1 | Mine | yes | 8 | 2 | 6 | 0 | 1 | 0 | 0 | 0 |
| L0417 | 3 | 1 | Opponent | yes | 6 | 2 | 2 | 0 | 1 | 0 | 0 | 0 |
| L0434 | 2 | 1 | Mine | - | - | 2 | 5 | 1 | 0 | 0 | 0 | 0 |
| L0434 | 2 | 1 | Opponent | - | - | 1 | 1 | 2 | 0 | 0 | 0 | 0 |
| L0520 | 4 | 1 | Mine | no | 0 | 3 | 2 | 0 | 0 | 0 | 0 | 1120 |
| L0520 | 4 | 1 | Opponent | no | 5 | 6 | 3 | 6 | 0 | 0 | 0 | 420 |
| L0608 | 2 | 1 | Mine | - | - | 3 | 1 | 1 | 0 | 0 | 0 | 798 |
| L0608 | 2 | 1 | Opponent | - | - | 4 | 1 | 1 | 0 | 0 | 0 | 605 |
| L0624 | 6 | 1 | Mine | no | 1 | 3 | 4 | 0 | 0 | 0 | 0 | 798 |
| L0624 | 6 | 1 | Opponent | no | 0 | 4 | 2 | 0 | 0 | 0 | 0 | 0 |
| L0713 | 5 | 1 | Mine | yes | - | 6 | 0 | 1 | 0 | 0 | 0 | 420 |
| L0713 | 5 | 1 | Opponent | no | - | 3 | 4 | 2 | 0 | 0 | 0 | 479 |
| L0729 | 3 | 1 | Mine | yes | 0 | 2 | 3 | 0 | 0 | 0 | 0 | 375 |
| L0729 | 3 | 1 | Opponent | no | 2 | 2 | 2 | 1 | 1 | 0 | 0 | 170 |
| L0819 | 3 | 1 | Mine | no | 0 | 6 | 1 | 0 | 0 | 0 | 0 | 515 |
| L0819 | 3 | 1 | Opponent | no | 4 | 2 | 2 | 2 | 0 | 0 | 0 | 0 |
| L0835 | 1 | 1 | Mine | no | 0 | 4 | 3 | 1 | 0 | 0 | 0 | 515 |
| L0835 | 1 | 1 | Opponent | no | 3 | 3 | 2 | 4 | 0 | 0 | 0 | 0 |
| L0926 | 2 | 1 | Mine | - | - | 2 | 1 | 0 | 0 | 0 | 0 | 632 |
| L0926 | 2 | 1 | Opponent | - | - | 3 | 1 | 4 | 1 | 0 | 0 | 0 |
| L1017 | 3 | 1 | Mine | yes | 10 | 2 | 5 | 1 | 0 | 0 | 0 | 330 |
| L1017 | 3 | 1 | Opponent | yes | 2 | 3 | 5 | 1 | 2 | 0 | 0 | 175 |
| L1034 | 2 | 1 | Mine | - | - | 1 | 4 | 0 | 1 | 0 | 0 | 330 |
| L1034 | 2 | 1 | Opponent | - | - | 3 | 2 | 1 | 0 | 0 | 0 | 0 |
| L1126 | 4 | 1 | Mine | no | 0 | 3 | 1 | 0 | 0 | 0 | 0 | 330 |
| L1126 | 4 | 1 | Opponent | no | 0 | 2 | 2 | 3 | 0 | 0 | 0 | 0 |
| L1220 | 2 | 1 | Mine | - | - | 2 | 6 | 0 | 2 | 0 | 0 | 330 |
| L1220 | 2 | 1 | Opponent | - | - | - | 3 | 4 | 1 | 0 | 0 | 0 |
| L1314 | 6 | 1 | Mine | yes | 4 | 6 | 2 | 1 | 0 | 0 | 0 | 140 |
| L1314 | 6 | 1 | Opponent | no | 10 | 2 | 2 | 0 | 1 | 0 | 0 | 0 |
| L1331 | 5 | 1 | Mine | no | - | 2 | 3 | 2 | 1 | 0 | 0 | 479 |
| L1331 | 5 | 1 | Opponent | yes | - | - | 1 | 2 | 2 | 0 | 0 | 456 |
| L1427 | 5 | 1 | Mine | yes | - | 3 | 4 | 1 | 0 | 0 | 0 | 0 |
| L1427 | 5 | 1 | Opponent | yes | - | 2 | 6 | 0 | 0 | 0 | 0 | 0 |
| L1523 | 5 | 1 | Mine | yes | - | 2 | 6 | 0 | 1 | 0 | 0 | 0 |
| L1523 | 5 | 1 | Opponent | yes | - | 2 | 6 | 2 | 0 | 0 | 0 | 126 |
| L1621 | 1 | 1 | Mine | no | 0 | - | 1 | 2 | 0 | 0 | 0 | 200 |
| L1621 | 1 | 1 | Opponent | no | 0 | 3 | 2 | 4 | 0 | 0 | 0 | 290 |
| L1719 | 3 | 1 | Mine | no | 5 | 2 | 5 | 0 | 0 | 0 | 0 | 0 |
| L1719 | 3 | 1 | Opponent | yes | 1 | 2 | 5 | 0 | 0 | 0 | 0 | 490 |
| L1819 | 1 | 1 | Mine | no | 0 | 5 | 2 | 1 | 0 | 0 | 0 | 0 |
| L1819 | 1 | 1 | Opponent | no | 0 | 2 | 5 | 0 | 0 | 0 | 0 | 0 |
| L1835 | 5 | 1 | Mine | yes | - | 2 | 0 | 1 | 0 | 0 | 0 | 0 |
| L1835 | 5 | 1 | Opponent | yes | - | 3 | 5 | 2 | 0 | 0 | 0 | 140 |
| L2021 | 5 | 1 | Mine | yes | - | 4 | 0 | 3 | 1 | 0 | 0 | 210 |
| L2021 | 5 | 1 | Opponent | no | - | 6 | 4 | 3 | 0 | 0 | 0 | 145 |
| L2123 | 5 | 1 | Mine | yes | - | - | 2 | 5 | 1 | 0 | 0 | 420 |
| L2123 | 5 | 1 | Opponent | yes | - | 2 | 2 | 2 | 0 | 0 | 0 | 0 |
| L2227 | 1 | 1 | Mine | yes | 3 | 3 | 1 | 1 | 1 | 0 | 0 | 72 |
| L2227 | 1 | 1 | Opponent | no | 0 | 1 | 7 | 2 | 0 | 0 | 0 | 0 |
| L2331 | 3 | 1 | Mine | no | 10 | 4 | 6 | 0 | 0 | 0 | 0 | 66 |
| L2331 | 3 | 1 | Opponent | no | 1 | - | 1 | 2 | 1 | 0 | 0 | 0 |
| L2527 | 1 | 1 | Mine | no | 0 | 4 | 4 | 2 | 0 | 0 | 0 | 0 |
| L2527 | 1 | 1 | Opponent | no | 2 | 1 | 2 | 4 | 0 | 0 | 0 | 0 |
| L2634 | 6 | 1 | Mine | no | 9 | 2 | 2 | 0 | 0 | 0 | 0 | 0 |
| L2634 | 6 | 1 | Opponent | no | 0 | 1 | 7 | 0 | 1 | 0 | 0 | 0 |
| L2930 | 2 | 1 | Mine | - | - | 2 | 8 | 2 | 0 | 0 | 0 | 0 |
| L2930 | 2 | 1 | Opponent | - | - | 3 | 3 | 1 | 0 | 0 | 0 | 0 |
| L3234 | 6 | 1 | Mine | no | 0 | 2 | 6 | 2 | 0 | 0 | 0 | 0 |
| L3234 | 6 | 1 | Opponent | no | 0 | 2 | 2 | 2 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 50% | 2.8 | 3.0 | 3.0 | 1.1 | 0.3 | 0.0 | 0.0 | 261.4 |
| **Average** | | | Opponent | 32% | 2.1 | 2.4 | 3.2 | 1.9 | 0.3 | 0.0 | 0.0 | 99.1 |

### KPIs: bg-off-789c37f-p4

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Winner chose to follow up after the loser gave ground |  | 97% (62 of 64); on the table 97% | 100% (57 of 57); on the table 100% | 98% (119 of 121); on the table 98% |
| Winner chose to pursue after the loser fell back in good order |  | 93% (14 of 15); on the table 93% | 100% (9 of 9); on the table 100% | 96% (23 of 24); on the table 96% |
| Winner chose to pursue after the loser fled |  | 72% (21 of 29); on the table 76% | 81% (35 of 43); on the table 86% | 78% (56 of 72); on the table 82% |
| Winner chose to follow up or pursue (all three) |  | 90% (97 of 108); on the table 91% | 93% (101 of 109); on the table 94% | 91% (198 of 217); on the table 93% |
| Magic missiles tried each own turn | 50%+ | 25% (69 of 271) | 29% (49 of 171) | 27% (118 of 442) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 43% (69 of 162) | 43% (49 of 114) | 43% (118 of 276) |
| Points that never fought | lower | 29% (19847 of 67942) | 28% (20509 of 71984) | 29% (40356 of 139926) |
|   infantry points that never fought | lower | 33% (5088 of 15347) | 57% (7870 of 13804) | 44% (12958 of 29151) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 59% (159 of 270) | 52% (147 of 280) | 56% (306 of 550) |
| Bound items with a magic missile used (at least once a game) |  | 82% (18 of 22); 1.5 uses a game | 89% (8 of 9); 0.6 uses a game | 84% (26 of 31); 1.1 uses a game |
| Bound items with another spell used |  | 56% (9 of 16); 0.3 uses a game | 65% (13 of 20); 0.6 uses a game | 61% (22 of 36); 0.5 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 53% (10 of 19); 0.3 uses a game | 67% (10 of 15); 0.3 uses a game | 59% (20 of 34); 0.3 uses a game |
|   their share of the points of units over 100 pts | lower | 54% (31001 of 57750) | 43% (27117 of 63347) | 48% (58118 of 121097) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.0 (17%) | 0.5 (16%) | 1.5 (17%) |
| MARCHED: its unit marched | 1.4 (26%) | 0.9 (26%) | 2.3 (26%) |
| CHARGED: its unit charged | 0.2 (3%) | 0.1 (4%) | 0.3 (3%) |
| IN COMBAT: engaged in combat | 1.6 (29%) | 0.9 (28%) | 2.6 (29%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.2 (6%) | 0.2 (2%) |
| FLEEING: fleeing | 0.0 (0%) | 0.1 (2%) | 0.1 (1%) |
| GONE: slain | 1.3 (24%) | 0.6 (17%) | 1.9 (21%) |
| OFF THE TABLE: off the table or not arrived | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.1 (2%) | 0.1 (1%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.4 | 1.6 | 1.7 | 3.3 | 0.2 | 2.5 |
| not cast | 2.7 | 2.2 | 3.2 | 9.0 | 1.8 | 20.5 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) | 0.0 (0%) | 2.0 (10%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.0 (44%) | 0.2 (5%) | 1.5 (17%) | 0.5 (27%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.3 (26%) | 0.5 (26%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (3%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.2 (6%) | 0.1 (6%) | 1.0 (32%) | 2.6 (29%) | 0.4 (23%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.2 (6%) | 0.2 (8%) | 0.3 (9%) | 0.2 (2%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.1 (3%) | 0.0 (1%) | 0.1 (4%) | 0.1 (1%) | 0.0 (0%) | 0.4 (2%) |
| GONE: slain | 0.8 (28%) | 0.6 (26%) | 0.5 (15%) | 1.9 (21%) | 0.3 (15%) | 3.5 (17%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.1 (3%) | 0.2 (1%) |
| STUPIDITY: Stupidity | 0.1 (4%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (1%) | 0.2 (8%) | 0.0 (0%) | 0.1 (1%) | 0.1 (6%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.4 (52%) | 0.2 (8%) | 1.1 (34%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 14.3 (70%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.2 a game | 0.6 a game | 0.9 a game |
| stood (cast and not dispelled) | 56% (22 of 39) | 70% (7 of 10) | 59% (29 of 49) |
| the unit moved after it | 95% (21 of 22) | 71% (5 of 7) | 90% (26 of 29) |
| it charged on its next turn | 5% (1 of 22) | 0% (0 of 7) | 3% (1 of 29) |
| the enemy charged it first | 23% (5 of 22) | 0% (0 of 7) | 17% (5 of 29) |
| it fought by the end of its next turn | 5% (1 of 22) | 14% (1 of 7) | 7% (2 of 29) |
| it moved out of a charge the enemy had planned (not charged first) | 9% (2 of 22) | 29% (2 of 7) | 14% (4 of 29) |
| none of these (no charge, no fight, no charge escaped) | 68% (15 of 22) | 57% (4 of 7) | 66% (19 of 29) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 62% (558 of 899) | 46% (255 of 552) | 56% (813 of 1451) |
|   cavalry | 63% (57 of 90) | 63% (77 of 123) | 63% (134 of 213) |
|   character | 40% (44 of 110) | 8% (11 of 133) | 23% (55 of 243) |
|   chariot | 38% (35 of 93) | 62% (13 of 21) | 42% (48 of 114) |
|   infantry | 60% (159 of 263) | 55% (125 of 227) | 58% (284 of 490) |
|   monster | 46% (22 of 48) | 15% (2 of 13) | 39% (24 of 61) |
|   war machine | 82% (241 of 295) | 77% (27 of 35) | 81% (268 of 330) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 3.1 (33%) | 2.1 (26%) | 5.2 (29%) |
| CHARGED: it charged | 1.4 (15%) | 1.9 (23%) | 3.3 (19%) |
| FLEEING: it fled or was fleeing | 0.1 (1%) | 0.4 (4%) | 0.5 (3%) |
| IN COMBAT: it fought this turn or the last | 0.7 (7%) | 0.6 (7%) | 1.2 (7%) |
| MOVED: a war machine that moved | 0.1 (1%) | 0.0 (0%) | 0.1 (0%) |
| NO TARGET IN RANGE | 1.6 (17%) | 0.9 (11%) | 2.6 (14%) |
| ONLY IN COMBAT: the only targets were in combat | 0.4 (4%) | 0.7 (8%) | 1.1 (6%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.4 (15%) | 1.5 (18%) | 2.9 (17%) |
| SHELTERED: the target was sheltered | 0.2 (3%) | 0.1 (1%) | 0.3 (2%) |
| OTHER BAR | 0.4 (4%) | 0.1 (1%) | 0.5 (3%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 5.9 | 1.2 | 85% | 3.9 pts | 23 pts |
| character | 1.8 | 0.4 | 85% | 5.8 pts | 11 pts |
| chariot | 1.4 | 0.6 | 72% | 8.3 pts | 12 pts |
| infantry | 11.8 | 4.1 | 74% | 10.2 pts | 120 pts |
| monster | 0.8 | 0.3 | 70% | 9.7 pts | 7 pts |
| war machine | 7.4 | 6.4 | 66% | 29.2 pts | 217 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.4 | 6.4 | 5.4 |
| Charges that made contact a game | 3.2 | 4.9 | 4.1 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.94 declared, 0.88 contact (17 units) | 1.22 declared, 1.06 contact (18 units) | 1.09 declared, 0.97 contact (35 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.75 declared, 0.62 contact (8 units) | 1.36 declared, 0.91 contact (11 units) | 1.11 declared, 0.79 contact (19 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.54 declared, 0.39 contact (248 units) | 0.64 declared, 0.49 contact (301 units) | 0.60 declared, 0.44 contact (549 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 48% (39 of 81) | 31% (5 of 16) | 67% (4 of 6) | 47% (48 of 103) |
| Character in a unit | 80% (20 of 25) | 62% (10 of 16) | 100% (1 of 1) | 74% (31 of 42) |
| Character on its own | 85% (34 of 40) | 58% (15 of 26) | 21% (16 of 77) | 45% (65 of 143) |
| Chariot | 87% (13 of 15) | 67% (8 of 12) | - | 78% (21 of 27) |
| Infantry | 52% (43 of 83) | 40% (10 of 25) | 33% (2 of 6) | 48% (55 of 114) |
| Monster | 62% (21 of 34) | 57% (8 of 14) | - | 60% (29 of 48) |
| Monstrous | 93% (13 of 14) | 71% (10 of 14) | - | 82% (23 of 28) |
| War Machines | 74% (32 of 43) | 100% (2 of 2) | - | 76% (34 of 45) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 94% (15 of 16); on the table 94% | 25% (26 of 102) | 13% | 64% (14 of 22) | 83% (5 of 6); 3.5 uses a game | 100% (2 of 2); 0.8 uses a game | 67% (4 of 6); 1.0 uses a game |
| Chaos Dwarfs | 4 | 88% (14 of 16); on the table 94% | 33% (8 of 24) | 26% | 59% (19 of 32) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
| Dwarfen Mountain Holds | 3 | 88% (7 of 8); on the table 88% | - | 56% | 59% (16 of 27) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 6 | 100% (15 of 15); on the table 100% | 50% (9 of 18) | 41% | 66% (41 of 62) | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game | 60% (3 of 5); 0.5 uses a game |
| Grand Cathay | 4 | 85% (11 of 13); on the table 85% | 21% (18 of 84) | 23% | 46% (17 of 37) | 89% (8 of 9); 6.0 uses a game | 50% (1 of 2); 0.2 uses a game | 25% (1 of 4); 0.2 uses a game |
| High Elf Realms | 9 | 87% (27 of 31); on the table 90% | 14% (5 of 36) | 26% | 39% (27 of 70) | 100% (7 of 7); 2.7 uses a game | 60% (18 of 30); 3.1 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | 80% (4 of 5); on the table 80% | - | 39% | 33% (2 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Lizardmen | 3 | 100% (18 of 18); on the table 100% | 33% (2 of 6) | 17% | 57% (12 of 21) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 2 | 50% (1 of 2); on the table 50% | 33% (2 of 6) | 44% | 86% (12 of 14) | 0% (0 of 2); 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 3 | 100% (6 of 6); on the table 100% | 14% (6 of 42) | 4% | 50% (12 of 24) | 0.0 uses a game | 0.0 uses a game | 100% (3 of 3); 1.0 uses a game |
| Skaven | 6 | 100% (8 of 8); on the table 100% | 29% (12 of 41) | 32% | 67% (30 of 45) | 100% (3 of 3); 0.7 uses a game | 0.0 uses a game | 67% (4 of 6); 0.7 uses a game |
| Tomb Kings of Khemri | 4 | 67% (6 of 9); on the table 67% | 0% (0 of 6) | 25% | 45% (9 of 20) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 8 | 96% (27 of 28); on the table 100% | 34% (20 of 59) | 26% | 52% (22 of 42) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 9 | 92% (24 of 26); on the table 92% | 50% (6 of 12) | 34% | 58% (42 of 72) | 100% (2 of 2); 0.7 uses a game | 0.0 uses a game | 100% (3 of 3); 0.3 uses a game |
| Wood Elf Realms | 6 | 94% (15 of 16); on the table 94% | 67% (4 of 6) | 31% | 55% (31 of 56) | 50% (1 of 2); 0.7 uses a game | 0.0 uses a game | 0% (0 of 4); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (bg-off-789c37f-p4, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 37% (40) | 58% (49) | 46% (89) |
| ...free all their last turn and able to turn (per game) | 0.61 | 0.83 | 1.44 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.19 | 0.25 | 0.44 |
| ...with the charger already in that arc before they moved (per game) | 0.44 | 0.50 | 0.94 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 1.72 | 1.17 | 2.89 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 1.31 | 0.58 | 1.89 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 9.19 | 9.92 | 19.11 |

### Quality by phase: bg-off-789c37f-p4

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.1 | 3.6 |
| Strategy | Charge objectives carried out (made contact) | 43% (63 of 147) | 46% (87 of 188) |
| Strategy | Shoot objectives carried out (shot that target) | 43% (156 of 360) | 51% (70 of 137) |
| Strategy | Close-in objectives charged next turn | 9% (16 of 169) | 18% (35 of 193) |
| Strategy | Support requests answered (helper made contact too) | 64% (9 of 14) | 56% (14 of 25) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (2 of 2) | 100% (1 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | 31% (4 of 13) | 45% (5 of 11) |
| Strategy | Joined characters whose unit fought | 78% (25 of 32) | 41% (12 of 29) |
| Strategy | Lone characters that fought | 82% (75 of 91) | 84% (73 of 87) |
| Movement | Charges halted short of contact | 0.1 | 0.2 |
| Movement | Idle units | 1.1 | 1.9 |
| Movement | Points that never moved of their own | 261.4 | 99.1 |
| Movement | Fights charged into per game | 3.2 | 4.1 |
| Movement | Charges with odds: long shots (under 50%) | 7 of 104, net -71 | 21 of 118, net +109 |
| Movement | Charges with odds: sweet spot (55-75%) | 19 of 104, net +52 | 18 of 118, net +16 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 11 of 104, net +6 | 14 of 118, net +81 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 40 of 104, net +60 | 27 of 118, net +147 |
| Shooting | Shots by shooting units (incl. breath weapons) | 9.8 | 7.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 46% (163 of 351) | 42% (116 of 277) |
| Shooting | Points destroyed by shooting units | 45.3 | 22.3 |
| Shooting | War machine shots | 6.7 | 0.8 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 57% (137 of 241) | 63% (17 of 27) |
| Shooting | Points destroyed by war machines | 59.2 | 6.1 |
| Magic | Magic missiles cast | 1.2 | 1.0 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 34% (15 of 44) | 19% (7 of 36) |
| Magic | Wounds caused by magic missiles | 3.7 | 0.8 |
| Magic | Wounds caused by other spells | 1.1 | 2.0 |
| Magic | Points destroyed by magic (all spells) | 79.0 | 55.1 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.1 / 0.4 / 0.8 / 0.0 | 2.2 / 0.6 / 0.9 / 0.1 |
| Combat | Points destroyed in combat | 320.8 | 507.7 |
| Combat | Points run down | 110.9 | 93.0 |
| Combat | Net points per charged fight, damage counted | +69 | +88 |
| Combat | Net per 100 charger points, damage counted | +24.9 | +27.2 |
| Combat | First round won (charged fights) | 70% | 60% |
| Combat | Net points per charged fight | +50 | +88 |
| Combat | Net points per supported fight / lone fight | +16 / +52 | +216 / +66 |
| Combat | Charged fights on a top-3 enemy unit | 38 of 114 | 65 of 146 |
| Game | Points lost | 764.1 | 656.8 |
| Game | VP from objectives | 550.0 | 519.4 |
| Game | Lone holders (player turns) | 2.8 | 2.1 |

- Mine won / drew / lost: 12 / 11 / 13 of 36 ended games (of 36); mean margin (Mine - Opponent) -119 VP
- The side that went first won 14 of 25 games with a winner
- Points traded per game (both sides' losses): 1421
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: bg-off-789c37f-p4

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.6 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.0 | +0.0 | 0.0 | 13.3 | 0.1 | +0.0 | 0.0 | 3.5 |
| BACKUP TARGETS | 0.9 | +5.2 | 0.0 | 25.2 | 0.9 | +9.2 | 0.0 | 4.5 |
| BEST PREY | 4.8 | +271.8 | 116.7 | 182.4 | 5.3 | +366.5 | 218.2 | 82.7 |
| BEST PRIZE | 0.0 | -0.2 | 0.0 | 0.0 | 0.1 | +0.7 | 1.8 | 0.0 |
| BLOCKED CHARGE SKIPPED | 0.1 | +0.0 | 0.0 | 3.1 | 0.0 | +0.0 | 0.0 | 0.0 |
| BLOCKED WHEEL | 0.6 | +15.8 | 0.0 | 0.8 | 0.4 | +3.0 | 0.0 | 4.0 |
| BOMBING RUN | 0.1 | +2.4 | 0.0 | 0.0 | - | - | - | - |
| BOUND ASSAILMENT | 0.0 | +0.0 | 0.0 | 4.2 | - | - | - | - |
| CANNON PLAN MISSED | 0.9 | +0.0 | 107.2 | 5.4 | 0.1 | +0.0 | 3.2 | 3.5 |
| CANNON PLANNED TARGET | 5.4 | +186.3 | 273.0 | 47.1 | 0.5 | +16.6 | 9.3 | 3.5 |
| CANNON SIGHT KEPT | 1.3 | +0.0 | 0.0 | 3.2 | 0.0 | +0.0 | 0.0 | 0.0 |
| CAST JOB | 1.0 | +26.8 | 34.6 | 27.2 | 0.4 | +4.1 | 26.6 | 0.0 |
| CASTER AWAY FROM SCREEN | 0.3 | +0.0 | 0.0 | 12.5 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.3 | +24.2 | 13.7 | 8.9 | - | - | - | - |
| CASTS AFTER FRIENDS | 0.8 | +0.0 | 0.0 | 23.8 | 0.3 | +0.0 | 0.0 | 9.1 |
| CASTS FROM BEHIND | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.0 | +0.1 | 0.0 | 0.0 | 0.0 | +0.6 | 0.0 | 0.0 |
| CATCH ODDS | 0.0 | +0.2 | 0.0 | 0.0 | - | - | - | - |
| CHAFF PASSED | 0.2 | -0.0 | 0.0 | 0.0 | 0.2 | -0.4 | 0.0 | 4.0 |
| CHARGE NOW WEIGHED | 0.4 | -35.4 | 13.8 | 19.6 | 0.7 | -64.2 | 11.9 | 28.8 |
| CHARIOT NO STATIC JOB | 0.4 | +0.0 | 3.8 | 13.1 | 0.2 | +0.0 | 6.7 | 5.3 |
| CHEAP HELPER | 0.1 | +0.0 | 0.8 | 4.0 | 0.1 | +0.0 | 9.9 | 1.2 |
| CONVEYANCE SEARCH | 0.8 | +60.4 | 16.0 | 9.3 | 0.2 | +16.4 | 4.4 | 0.0 |
| EDGE GIVE GROUND | 0.0 | +0.2 | 3.8 | 0.0 | 0.1 | +5.7 | 17.9 | 0.0 |
| ELIXIR WORTH | - | - | - | - | 0.1 | +3.1 | 0.0 | 9.7 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 1.7 | +121.0 | 0.0 | 71.9 | 1.2 | +88.3 | 0.0 | 0.0 |
| FIGHT LIFT | 0.1 | +2.7 | 11.9 | 0.0 | 0.0 | +0.3 | 0.0 | 0.0 |
| FIRE AND FLEE | 0.1 | +0.6 | 0.0 | 0.0 | 0.1 | +0.3 | 0.0 | 3.0 |
| FOCUS FIRE | 0.0 | +0.1 | 1.5 | 0.0 | 0.0 | +0.5 | 1.2 | 0.0 |
| FOLLOW UP WEIGHED | 1.1 | +160.9 | 0.0 | 75.5 | 0.8 | +129.4 | 0.0 | 25.8 |
| FRIENDS SHOTS CHECKED | 0.3 | +20.4 | 0.0 | 6.0 | 0.2 | +7.7 | 0.0 | 2.6 |
| GIVES UP | 1.3 | -37.6 | 159.9 | 99.1 | 1.6 | -63.0 | 254.6 | 36.4 |
| GIVES UP ITS SCREEN | 0.6 | -14.9 | 25.2 | 3.8 | 1.0 | -19.0 | 98.1 | 16.2 |
| GROUND FLIERS | 0.1 | +0.7 | 0.0 | 0.0 | - | - | - | - |
| HELPER ALREADY ASKED | - | - | - | - | 0.1 | +0.0 | 31.1 | 1.8 |
| HELPER UNSEEN | 0.1 | +0.0 | 5.6 | 0.0 | 0.5 | +0.0 | 59.7 | 7.9 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| HUNT ADVANCE | 0.1 | +0.2 | 13.1 | 5.0 | 0.1 | +1.2 | 11.0 | 1.7 |
| HUNT DROPPED | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |
| HUNT RESULT | 0.1 | +27.1 | 26.1 | 3.1 | 0.1 | +26.6 | 15.0 | 1.8 |
| HUNT THE GUNS | 0.1 | +45.4 | 26.1 | 6.7 | 0.1 | +38.5 | 26.0 | 3.5 |
| JOINT CHARGE PLAN | 0.1 | +0.5 | 0.0 | 0.0 | 0.1 | +1.9 | 0.0 | 0.0 |
| KEEPS ITS PREY | 0.2 | +0.7 | 4.3 | 6.3 | 0.6 | +3.7 | 12.1 | 0.0 |
| KEEPS ITS TARGET | 2.2 | +65.0 | 162.3 | 78.2 | 2.2 | +65.0 | 247.1 | 11.8 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KILLS COUNT | 2.0 | +84.6 | 130.6 | 53.5 | 2.2 | +113.5 | 246.4 | 56.8 |
| KILLS COUNT NEXT TURN | 9.7 | +341.8 | 265.7 | 253.3 | 11.5 | +574.1 | 535.9 | 164.0 |
| LONE CHARACTER SAFE SPOT | 0.5 | +22.7 | 22.4 | 22.9 | 0.2 | +7.0 | 0.0 | 0.0 |
| LONE WIZARD HOLDS BACK | 1.2 | +0.0 | 57.6 | 90.4 | 1.3 | +0.0 | 65.1 | 5.3 |
| LONE WIZARD KEPT IN | 0.6 | +26.9 | 0.0 | 3.2 | 0.2 | +20.3 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 0.5 | +32.2 | 9.6 | 0.8 | 0.7 | +35.4 | 11.0 | 9.7 |
| MANOEUVRE | 0.1 | +9.7 | 0.0 | 1.7 | 0.1 | +3.3 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.2 | +1.3 | 0.0 | 6.2 | 0.1 | +2.9 | 0.0 | 0.0 |
| MARCH ODDS | 1.3 | +79.6 | 39.8 | 79.0 | 0.6 | +55.6 | 6.8 | 35.9 |
| MISSILES IN THE MOVE | 3.3 | +103.4 | 0.0 | 91.7 | 2.1 | +34.3 | 0.0 | 15.2 |
| MISSILES NEXT TURN | 4.7 | +84.6 | 0.0 | 127.9 | 3.1 | +30.4 | 0.0 | 45.5 |
| MODEL FACING | 0.4 | +99.4 | 0.0 | 0.0 | - | - | - | - |
| MOVE AND CAST | 0.2 | +3.5 | 0.0 | 0.0 | 0.1 | +5.2 | 0.0 | 0.0 |
| MOVE SPELL IN RANGE | 0.2 | +5.6 | 0.0 | 0.0 | 0.0 | +1.5 | 0.0 | 0.0 |
| MOVE SPELL OUT OF RANGE | 0.5 | -19.2 | 13.8 | 19.7 | 0.2 | -1.1 | 16.6 | 0.0 |
| MOVE SPELL SPOT | 0.6 | +0.0 | 0.0 | 13.9 | 0.1 | +0.0 | 0.0 | 0.0 |
| MOVES UNITS SPELL | 0.1 | +3.3 | 0.0 | 0.0 | 0.1 | +0.6 | 0.0 | 0.0 |
| NEEDED THERE | 0.0 | +7.8 | 0.0 | 0.0 | 0.1 | +15.3 | 7.3 | 0.0 |
| NO RALLY LEFT | 0.0 | +0.8 | 0.0 | 0.0 | 0.0 | +0.4 | 0.0 | 0.0 |
| NOT NEEDED | 0.2 | -6.1 | 17.5 | 2.4 | 0.2 | -21.3 | 34.2 | 2.7 |
| NOT TURNED | 9.2 | +109.1 | 0.0 | 275.0 | 9.9 | +96.6 | 0.0 | 157.0 |
| NOT WORTH A CAST | 0.5 | -0.4 | 0.0 | 20.4 | 0.3 | -0.1 | 0.0 | 0.0 |
| OPENS A LANE | 0.1 | +0.7 | 3.6 | 0.0 | 0.1 | +0.6 | 17.5 | 0.0 |
| OPENS UP | 0.2 | +15.5 | 10.0 | 5.7 | 0.2 | +32.0 | 5.7 | 0.0 |
| OVERRUNS AWAY | 0.5 | +17.8 | 65.6 | 31.3 | 0.6 | +15.3 | 63.6 | 12.5 |
| PATHS CROSS | 2.4 | +145.7 | 0.0 | 49.2 | 3.2 | +230.6 | 0.0 | 46.1 |
| PERIAPT WORTH | 0.0 | +1.1 | 0.0 | 0.0 | 0.1 | +9.6 | 0.0 | 0.0 |
| PLAN LEADS | 1.1 | +104.2 | 17.6 | 17.5 | 0.9 | +73.4 | 9.7 | 3.8 |
| PLAN RESULT | 39.2 | +1421.6 | 1237.0 | 1069.9 | 39.6 | +1467.5 | 1460.5 | 901.8 |
| PURSUES BIG PREY | 0.0 | -4.7 | 0.0 | 0.0 | 0.1 | -6.3 | 0.0 | 0.0 |
| PURSUES ON | 0.0 | +2.2 | 0.0 | 0.0 | - | - | - | - |
| RAIDS THE BAGGAGE | - | - | - | - | 0.0 | +4.9 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE NEXT TURN | 0.1 | +7.1 | 0.0 | 0.0 | 0.2 | +19.6 | 0.0 | 0.0 |
| REDIRECT WEIGHED | 0.1 | +12.6 | 10.1 | 0.0 | 0.4 | +25.5 | 9.5 | 13.5 |
| RESTRAINS TO SHOOT | 0.1 | +5.6 | 0.0 | 7.4 | 0.0 | +2.4 | 0.0 | 0.0 |
| RISK BY ARC | 2.9 | +103.0 | 245.2 | 155.8 | 2.9 | +42.0 | 349.1 | 81.2 |
| SAFER THAN THE JOB | 1.3 | +58.1 | 0.0 | 1.8 | 0.6 | +32.8 | 0.0 | 11.6 |
| SCOUT SPOT | 0.4 | +0.5 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| SCOUT WAITS | 0.5 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| SEARCH SPOT | 1.0 | +52.8 | 0.0 | 20.6 | 0.9 | +66.1 | 0.0 | 8.6 |
| SECOND HUNTER | 0.0 | -0.2 | 13.1 | 1.7 | - | - | - | - |
| SELF MOVE SPELL | 0.1 | +34.5 | 0.0 | 11.0 | 0.4 | +28.9 | 0.0 | 18.1 |
| SET UP TOGETHER | 0.9 | +44.1 | 9.6 | 0.8 | 1.0 | +50.5 | 17.1 | 23.0 |
| SHOOTERS IN TWO RANKS | 0.3 | +0.7 | 0.0 | 0.0 | 0.2 | +0.3 | 0.0 | 0.0 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 3.2 | 0.0 | +0.0 | 0.0 | 0.0 |
| SHOT REPLANNED | 0.5 | +0.0 | 120.3 | 7.2 | 0.2 | +0.0 | 34.6 | 0.0 |
| SHOTS IN THE MOVE | 14.7 | +602.5 | 0.0 | 164.5 | 6.3 | +174.6 | 0.0 | 75.9 |
| SPELL CATCH ODDS | 0.1 | -0.2 | 3.3 | 0.0 | 0.0 | -0.1 | 0.0 | 0.0 |
| SPELL SETS UP CHARGE | - | - | - | - | 0.0 | +11.8 | 0.0 | 0.0 |
| SPELL WORTH | 1.5 | +39.4 | 100.8 | 84.2 | 2.5 | +46.8 | 41.1 | 41.1 |
| STANDS TO CAST | 0.1 | +2.3 | 1.2 | 6.6 | 0.1 | +7.0 | 5.4 | 0.0 |
| STOPS | 0.0 | +0.3 | 13.1 | 1.7 | 0.0 | +0.3 | 15.0 | 1.8 |
| STUCK PIVOT | 0.3 | +0.0 | 0.0 | 4.0 | 0.4 | +0.0 | 0.0 | 5.8 |
| SUPPORT JOB KEPT | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |
| SURE CHARGE BEATS ADVANCE | 0.1 | -3.7 | 10.7 | 3.1 | 0.1 | -2.9 | 9.8 | 4.2 |
| THROUGH LINE OF FIRE | 0.4 | +13.8 | 0.0 | 16.1 | 0.2 | +12.8 | 0.0 | 0.0 |
| TURN WORTH | 0.4 | -32.5 | 14.5 | 13.3 | 0.2 | -23.6 | 19.1 | 0.0 |
| TWO OR MORE ARRIVE | 0.6 | +3.5 | 0.0 | 0.0 | 0.6 | +9.6 | 6.1 | 10.6 |
| WEARS DOWN | 0.9 | +39.7 | 104.6 | 92.9 | 1.0 | +31.3 | 114.6 | 16.8 |
| WHO HITS BACK | 0.3 | +17.0 | 0.0 | 1.1 | 0.2 | +16.6 | 0.0 | 25.7 |
| WHOLE FIGHT | 0.3 | +28.5 | 88.3 | 13.6 | 0.7 | +56.1 | 120.3 | 12.4 |
| WHOLE FIGHT GAIN | 0.3 | +16.4 | 11.4 | 20.5 | 0.6 | +50.1 | 53.4 | 13.1 |

### Rule changes: bg-off-789c37f-p4

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| KILLS COUNT NEXT TURN | 763 | 753 | 202 | 5.61 | +7552 | +37.4 |
| BEST PREY | 363 | 354 | 156 | 4.33 | +6204 | +39.8 |
| FOLLOW UP WEIGHED | 69 | 69 | 69 | 1.92 | +10451 | +151.5 |
| MARCH ODDS | 67 | 51 | 50 | 1.39 | +1546 | +30.9 |
| KILLS COUNT | 152 | 141 | 49 | 1.36 | +2214 | +45.2 |
| CANNON SIGHT KEPT | 48 | 48 | 48 | 1.33 | +0 | +0.0 |
| ADVANCE LANE KEPT | 41 | 41 | 41 | 1.14 | +0 | +0.0 |
| CHARGE NOW WEIGHED | 41 | 41 | 41 | 1.14 | +2666 | +65.0 |
| RISK BY ARC | 211 | 196 | 41 | 1.14 | +795 | +19.4 |
| ARTILLERY RE-ROLL WEIGHED | 38 | 38 | 38 | 1.06 | +0 | +0.0 |
| HOLDS AMBUSHERS | 35 | 35 | 35 | 0.97 | +0 | +0.0 |
| CANNON PLANNED TARGET | 215 | 215 | 34 | 0.94 | +166 | +4.9 |
| SET UP TOGETHER | 68 | 68 | 30 | 0.83 | +1032 | +34.4 |
| LONE WIZARD KEPT IN | 28 | 28 | 28 | 0.78 | +1699 | +60.7 |
| PLAN LEADS | 71 | 71 | 28 | 0.78 | +1506 | +53.8 |
| KEEPS ITS TARGET | 156 | 156 | 27 | 0.75 | +464 | +17.2 |
| LONE WIZARD HOLDS BACK | 92 | 92 | 27 | 0.75 | -1270 | -47.1 |
| SHOT REPLANNED | 27 | 27 | 27 | 0.75 | +0 | +0.0 |
| CAST JOB | 52 | 50 | 26 | 0.72 | +286 | +11.0 |
| STUCK PIVOT | 23 | 23 | 23 | 0.64 | +0 | +0.0 |
| SCOUT WAITS | 21 | 21 | 21 | 0.58 | +0 | +0.0 |
| CHARIOT NO STATIC JOB | 22 | 22 | 19 | 0.53 | -1784 | -93.9 |
| REDIRECT WEIGHED | 19 | 19 | 19 | 0.53 | +1292 | +68.0 |
| MAKE SURE TOGETHER | 44 | 44 | 18 | 0.50 | +640 | +35.5 |
| WHO HITS BACK | 18 | 18 | 18 | 0.50 | -2224 | -123.5 |
| FRIENDS SHOTS CHECKED | 17 | 17 | 17 | 0.47 | +1010 | +59.4 |
| SHOOTERS IN TWO RANKS | 17 | 17 | 17 | 0.47 | +36 | +2.1 |
| CASTER AWAY FROM SCREEN | 16 | 16 | 16 | 0.44 | +0 | +0.0 |
| WHOLE FIGHT | 36 | 36 | 16 | 0.44 | +1514 | +94.6 |
| CHAFF PASSED | 13 | 13 | 13 | 0.36 | -13 | -1.0 |
| MODEL FACING | 13 | 13 | 13 | 0.36 | +3580 | +275.4 |
| WHOLE FIGHT GAIN | 31 | 24 | 12 | 0.33 | +506 | +42.1 |
| WEARS DOWN | 70 | 64 | 11 | 0.31 | +222 | +20.2 |
| RAIDS THE BAGGAGE NEXT TURN | 10 | 10 | 10 | 0.28 | +328 | +32.8 |
| CASTS FROM BEHIND | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| SHORT GUN FORWARD | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| SURE CHARGE BEATS ADVANCE | 9 | 9 | 9 | 0.25 | -238 | -26.5 |
| CASTING BLOCK | 11 | 11 | 7 | 0.19 | +382 | +54.5 |
| MOVES UNITS SPELL | 7 | 7 | 7 | 0.19 | +138 | +19.7 |
| OPENS UP | 18 | 14 | 6 | 0.17 | +215 | +35.8 |
| BLOCKED CHARGE SKIPPED | 5 | 5 | 5 | 0.14 | +0 | +0.0 |
| NEEDED THERE | 5 | 5 | 5 | 0.14 | +0 | +0.0 |
| BACKUP TARGETS | 66 | 27 | 4 | 0.11 | +14 | +3.5 |
| BEST PRIZE | 4 | 4 | 4 | 0.11 | -49 | -12.3 |
| FIRE AND FLEE | 4 | 4 | 4 | 0.11 | +31 | +7.8 |
| OVERRUNS AWAY | 39 | 37 | 4 | 0.11 | +43 | +10.7 |
| PERIAPT WORTH | 4 | 4 | 4 | 0.11 | +386 | +96.4 |
| PURSUES BIG PREY | 4 | 4 | 4 | 0.11 | -396 | -98.9 |
| RESTRAINS TO SHOOT | 4 | 4 | 4 | 0.11 | +288 | +71.9 |
| STANDS TO CAST | 9 | 4 | 4 | 0.11 | +40 | +10.0 |
| TWO OR MORE ARRIVE | 43 | 43 | 4 | 0.11 | +70 | +17.4 |
| ELIXIR WORTH | 3 | 3 | 3 | 0.08 | +111 | +37.0 |
| BOMBING RUN | 2 | 2 | 2 | 0.06 | +86 | +42.8 |
| FOCUS FIRE | 2 | 2 | 2 | 0.06 | +20 | +10.1 |
| GIVES UP | 104 | 99 | 2 | 0.06 | +14 | +7.2 |
| GIVES UP ITS SCREEN | 56 | 52 | 2 | 0.06 | +14 | +7.2 |
| HUNT ADVANCE | 6 | 6 | 2 | 0.06 | +4 | +2.2 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| MISSILES NEXT TURN | 281 | 139 | 2 | 0.06 | +11 | +5.6 |
| NO RALLY LEFT | 2 | 2 | 2 | 0.06 | +26 | +13.0 |
| BOUND ASSAILMENT | 1 | 1 | 1 | 0.03 | +0 | +0.1 |
| JOINT CHARGE PLAN | 6 | 6 | 1 | 0.03 | +26 | +26.0 |
| KEEPS ITS PREY | 27 | 26 | 1 | 0.03 | +18 | +17.6 |
| MOVE SPELL IN RANGE | 9 | 6 | 1 | 0.03 | +42 | +42.1 |
| OPENS A LANE | 7 | 5 | 1 | 0.03 | +1 | +0.7 |
| PURSUES ON | 1 | 1 | 1 | 0.03 | +79 | +79.1 |
| RAIDS THE BAGGAGE | 1 | 1 | 1 | 0.03 | +172 | +172.3 |
| SUPPORT JOB KEPT | 1 | 1 | 1 | 0.03 | +32 | +32.0 |
| BLOCKED WHEEL | 35 | not checked | - | - | - | - |
| CANNON PLAN MISSED | 36 | 36 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 37 | trace | - | - | - | - |
| CATCH FLIERS | 2 | not checked | - | - | - | - |
| CATCH ODDS | 1 | not checked | - | - | - | - |
| CHEAP HELPER | 6 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 33 | not checked | - | - | - | - |
| EDGE GIVE GROUND | 6 | 6 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FACES THE THREAT | 104 | not checked | - | - | - | - |
| FIGHT LIFT | 5 | not checked | - | - | - | - |
| GROUND FLIERS | 3 | not checked | - | - | - | - |
| HELPER ALREADY ASKED | 2 | not checked | - | - | - | - |
| HELPER UNSEEN | 20 | 17 | 0 | 0.00 | - | - |
| HUNT DROPPED | 1 | trace | - | - | - | - |
| HUNT RESULT | 8 | trace | - | - | - | - |
| HUNT THE GUNS | 8 | trace | - | - | - | - |
| LONE CHARACTER SAFE SPOT | 24 | not checked | - | - | - | - |
| MANOEUVRE | 7 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 12 | trace | - | - | - | - |
| MISSILES IN THE MOVE | 193 | not checked | - | - | - | - |
| MOVE AND CAST | 9 | not checked | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 25 | trace | - | - | - | - |
| MOVE SPELL SPOT | 24 | not checked | - | - | - | - |
| NOT NEEDED | 15 | 15 | 0 | 0.00 | - | - |
| NOT TURNED | 688 | 688 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 30 | not checked | - | - | - | - |
| PATHS CROSS | 202 | not checked | - | - | - | - |
| PLAN RESULT | 2836 | trace | - | - | - | - |
| SAFER THAN THE JOB | 68 | not checked | - | - | - | - |
| SCOUT SPOT | 19 | 19 | 0 | 0.00 | - | - |
| SEARCH SPOT | 68 | not checked | - | - | - | - |
| SECOND HUNTER | 1 | 1 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 20 | not checked | - | - | - | - |
| SHOTS IN THE MOVE | 756 | not checked | - | - | - | - |
| SPELL CATCH ODDS | 3 | not checked | - | - | - | - |
| SPELL SETS UP CHARGE | 1 | not checked | - | - | - | - |
| SPELL WORTH | 146 | not checked | - | - | - | - |
| STOPS | 2 | 2 | 0 | 0.00 | - | - |
| THROUGH LINE OF FIRE | 25 | not checked | - | - | - | - |
| TURN WORTH | 24 | 21 | 0 | 0.00 | - | - |

### Plans: bg-off-789c37f-p4

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 13.4 | 17% | 544 | 350 | 64% |
| Mine | charge | 3.1 | 56% | 322 | 311 | 97% |
| Mine | close in | 4.7 | 18% | 293 | 140 | 48% |
| Mine | hold | 4.1 | 40% | 317 | 0 | 0% |
| Mine | join | 0.7 | 85% | 26 | 0 | 0% |
| Mine | shoot | 8.6 | 61% | 258 | 621 | 241% |
| Mine | support | 4.7 | 92% | 252 | 0 | 0% |
| Opponent | advance | 15.4 | 17% | 777 | 559 | 72% |
| Opponent | charge | 4.3 | 63% | 549 | 490 | 89% |
| Opponent | close in | 5.3 | 24% | 401 | 180 | 45% |
| Opponent | hold | 3.9 | 29% | 313 | 0 | 0% |
| Opponent | join | 0.6 | 95% | 35 | 0 | 0% |
| Opponent | shoot | 3.4 | 58% | 88 | 238 | 271% |
| Opponent | support | 6.7 | 90% | 252 | 0 | 0% |

### Packages: hunt the guns, bg-off-789c37f-p4

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.1 | 4 | 0 | 25% | 50% | 0% | 2.0 | 409 | 244 | 50% | 6 |
| Opponent | 0.1 | 4 | 0 | 25% | 50% | 0% | 2.0 | 346 | 240 | 50% | 75 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Dwarfen Mountain Holds | 0.7 | 2 | 0 | 50% | 100% | 0% | 2.0 | 493 | 487 | 100% | 73 |
| Empire of Man | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 448 | 0 | 0% | 21 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| High Elf Realms | 0.1 | 1 | 0 | 0% | 0% | 0% | - | 118 | 0 | 0% | 13 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 164 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 117 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 87 |
| Tomb Kings of Khemri | 0.8 | 3 | 0 | 33% | 67% | 0% | 2.0 | 392 | 320 | 67% | 0 |
| Vampire Counts | 0.1 | 1 | 0 | 0% | 0% | 0% | - | 292 | 0 | 0% | 35 |
| Warriors of Chaos | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Wood Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 138 |

### Deployment: positions vs output by unit type: bg-off-789c37f-p4

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 4 | 0 (4) | 0 | 0 | 100 | 75% | 5.0 | 0 (1) | - | - | - | 0 (1) |
| Mine | Chaff | 49 | 51 (49) | 19 | 32 | 59 | 27% | 2.9 | 32 (21) | 91 (11) | 53 (17) | 76 (32) | 3 (17) |
| Mine | Character | 106 | 52 (106) | 51 | 1 | 47 | 12% | 2.3 | 53 (37) | 63 (45) | 43 (8) | 39 (51) | 80 (39) |
| Mine | Clean-up | 14 | 48 (14) | 1 | 47 | 45 | 21% | 3.2 | 28 (6) | 82 (5) | 21 (3) | 57 (7) | 41 (7) |
| Mine | Early | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Mine | Fast Hammer | 39 | 47 (39) | 21 | 26 | 43 | 18% | 3.0 | 38 (24) | 83 (9) | 25 (6) | 54 (28) | 25 (11) |
| Mine | Fragile | 4 | 0 (4) | 0 | 0 | 46 | 25% | 1.7 | 0 (3) | 0 (1) | - | 0 (1) | 0 (3) |
| Mine | Hammer | 64 | 27 (64) | 19 | 8 | 42 | 9% | 2.8 | 36 (10) | 22 (44) | 46 (10) | 29 (39) | 24 (25) |
| Mine | Holder | 30 | 74 (30) | 12 | 61 | 37 | 27% | 3.0 | 47 (6) | 106 (17) | 0 (7) | 100 (17) | 32 (13) |
| Mine | Shooter | 35 | 89 (35) | 42 | 47 | 39 | 0% | 1.7 | 46 (11) | 129 (19) | 33 (5) | 126 (23) | 23 (12) |
| Mine | Support | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | - | 0 (1) | 0 (1) | - |
| Mine | War machine | 56 | 40 (56) | 40 | 0 | 32 | 4% | 1.4 | 65 (20) | 22 (31) | 29 (5) | 12 (7) | 43 (49) |
| Mine | Wizard | 17 | 18 (17) | 18 | 0 | 46 | 6% | 2.2 | 75 (4) | 0 (3) | 0 (1) | 0 (1) | 33 (7) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | 0 (1) | - | - | - | 0 (1) |
| Opponent | Chaff | 82 | 45 (82) | 20 | 25 | 58 | 38% | 3.1 | 76 (30) | 37 (21) | 23 (31) | 41 (62) | 59 (20) |
| Opponent | Character | 97 | 63 (97) | 63 | 0 | 31 | 20% | 2.5 | 47 (40) | 87 (38) | 54 (7) | 59 (46) | 71 (39) |
| Opponent | Clean-up | 12 | 111 (12) | 17 | 94 | 38 | 25% | 2.4 | 114 (3) | 130 (6) | 65 (3) | 133 (7) | 91 (5) |
| Opponent | Fast | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Fast Hammer | 54 | 50 (54) | 40 | 10 | 32 | 22% | 2.9 | 58 (27) | 23 (17) | 85 (10) | 52 (34) | 46 (20) |
| Opponent | Fragile | 16 | 17 (16) | 17 | 0 | 70 | 44% | 1.8 | 0 (2) | 32 (8) | 0 (3) | 26 (10) | 0 (3) |
| Opponent | Hammer | 64 | 25 (64) | 17 | 8 | 35 | 33% | 3.4 | 26 (20) | 26 (38) | 6 (6) | 28 (42) | 20 (22) |
| Opponent | Holder | 27 | 48 (27) | 14 | 35 | 21 | 52% | 3.8 | 14 (10) | 65 (16) | 25 (1) | 56 (12) | 41 (15) |
| Opponent | Shooter | 34 | 45 (34) | 15 | 30 | 42 | 0% | 1.5 | 28 (9) | 55 (23) | 0 (2) | 40 (20) | 52 (14) |
| Opponent | Support | 6 | 0 (6) | 0 | 0 | 100 | 0% | 5.8 | 0 (3) | - | - | - | 0 (3) |
| Opponent | War machine | 6 | 34 (6) | 34 | 0 | 19 | 0% | 2.0 | 57 (3) | 0 (3) | - | 57 (3) | 0 (3) |
| Opponent | Wizard | 20 | 8 (20) | 8 | 0 | 35 | 5% | 2.5 | 7 (10) | 18 (5) | 0 (2) | 13 (11) | 1 (6) |

### Charged fights: bg-off-789c37f-p4

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 230 | 80 | 3.0 | 1.0 | 27 | 14 | +12 | 3 of 12 | 10 of 12 | - | +12 |
| Mine | Chaos Dwarfs | 4 | 94 | 240 | 3.8 | 1.0 | 64 | 77 | -12 | 5 of 15 | 9 of 15 | - | -12 |
| Mine | Dwarfen Mountain Holds | 3 | 263 | 227 | 2.3 | 1.1 | 97 | 0 | +97 | 4 of 7 | 4 of 7 | +0 | +113 |
| Mine | Empire of Man | 5 | 308 | 32 | 1.8 | 1.0 | 18 | 92 | -74 | 3 of 9 | 6 of 9 | - | -74 |
| Mine | Grand Cathay | 4 | 286 | 337 | 4.8 | 1.1 | 71 | 38 | +33 | 5 of 19 | 15 of 19 | -92 | +48 |
| Mine | High Elf Realms | 4 | 351 | 538 | 3.0 | 1.1 | 179 | 5 | +174 | 4 of 12 | 11 of 12 | +177 | +174 |
| Mine | Kingdom of Bretonnia | 1 | 210 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Mine | Lizardmen | 1 | 55 | 1579 | 5.0 | 1.2 | 316 | 28 | +288 | 3 of 5 | 4 of 5 | +110 | +332 |
| Mine | Ogre Kingdoms | 2 | 0 | 51 | 1.5 | 1.0 | 34 | 0 | +34 | 2 of 3 | 2 of 3 | - | +34 |
| Mine | Skaven | 2 | 72 | 89 | 2.0 | 1.0 | 44 | 0 | +44 | 0 of 4 | 2 of 4 | - | +44 |
| Mine | Tomb Kings of Khemri | 2 | 0 | 469 | 4.0 | 1.0 | 117 | 74 | +43 | 3 of 8 | 4 of 8 | - | +43 |
| Mine | Vampire Counts | 2 | 14 | 91 | 3.5 | 1.3 | 26 | 22 | +4 | 3 of 7 | 4 of 7 | -2 | +6 |
| Mine | Warriors of Chaos | 2 | 0 | 680 | 6.5 | 1.1 | 105 | 38 | +67 | 3 of 13 | 9 of 13 | +27 | +70 |
| **Mine** | all armies | 36 | 184 | 277 | 3.2 | 1.1 | 87 | 38 | +50 | 38 of 114 | 80 of 114 | +16 | +52 |
| Opponent | Empire of Man | 1 | 220 | 0 | 1.0 | 2.0 | 0 | 252 | -252 | 1 of 1 | 0 of 1 | -252 | - |
| Opponent | High Elf Realms | 5 | 69 | 888 | 6.0 | 1.2 | 148 | 38 | +110 | 13 of 30 | 18 of 30 | +399 | +65 |
| Opponent | Lizardmen | 2 | 68 | 686 | 5.0 | 1.2 | 137 | 37 | +100 | 3 of 10 | 6 of 10 | +120 | +98 |
| Opponent | Orc & Goblin Tribes | 3 | 30 | 391 | 5.0 | 1.0 | 78 | 38 | +40 | 3 of 15 | 9 of 15 | - | +40 |
| Opponent | Skaven | 4 | 216 | 52 | 3.0 | 1.1 | 18 | 29 | -12 | 5 of 12 | 8 of 12 | +210 | -32 |
| Opponent | Tomb Kings of Khemri | 2 | 58 | 1038 | 5.0 | 1.2 | 208 | 14 | +194 | 4 of 10 | 7 of 10 | +226 | +186 |
| Opponent | Vampire Counts | 6 | 65 | 489 | 4.2 | 1.3 | 117 | 32 | +85 | 15 of 25 | 17 of 25 | +236 | +38 |
| Opponent | Warriors of Chaos | 7 | 8 | 434 | 2.3 | 1.0 | 190 | 18 | +172 | 10 of 16 | 9 of 16 | - | +172 |
| Opponent | Wood Elf Realms | 6 | 132 | 534 | 4.5 | 1.2 | 119 | 63 | +55 | 11 of 27 | 14 of 27 | +167 | +24 |
| **Opponent** | all armies | 36 | 84 | 512 | 4.1 | 1.2 | 126 | 39 | +88 | 65 of 146 | 88 of 146 | +216 | +66 |

### Effective charges: bg-off-789c37f-p4

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 12 | 0 | 0 | 2 (net +49) | 3 (net +0) | 0 | 5 (net +27) | 2 | 20% (2 of 10) |
| Mine | Chaos Dwarfs | 15 | 3 (net -103) | 1 (net -339) | 1 (net -499) | 3 (net +81) | 0 | 5 (net +109) | 2 | 8% (1 of 13) |
| Mine | Dwarfen Mountain Holds | 7 | 1 (net +0) | 0 | 0 | 3 (net +227) | 0 | 3 (net +0) | 0 | 0% (0 of 7) |
| Mine | Empire of Man | 9 | 0 | 0 | 2 (net -155) | 0 | 3 (net -147) | 3 (net +0) | 1 | 25% (2 of 8) |
| Mine | Grand Cathay | 19 | 2 (net -92) | 0 | 5 (net +61) | 5 (net +75) | 0 | 6 (net +18) | 1 | 28% (5 of 18) |
| Mine | High Elf Realms | 12 | 0 | 0 | 0 | 3 (net +217) | 5 (net +86) | 4 (net +253) | 0 | 0% (0 of 12) |
| Mine | Lizardmen | 5 | 0 | 0 | 1 (net +114) | 3 (net +441) | 0 | 1 (net +0) | 0 | 20% (1 of 5) |
| Mine | Ogre Kingdoms | 3 | 0 | 0 | 1 (net +102) | 0 | 0 | 1 (net +0) | 1 | 50% (1 of 2) |
| Mine | Skaven | 4 | 0 | 0 | 0 | 0 | 0 | 4 (net +44) | 0 | 0% (0 of 4) |
| Mine | Tomb Kings of Khemri | 8 | 1 (net +0) | 0 | 1 (net +296) | 2 (net +58) | 2 (net +27) | 2 (net -60) | 0 | 12% (1 of 8) |
| Mine | Vampire Counts | 7 | 0 | 1 (net -45) | 3 (net +0) | 1 (net +0) | 0 | 2 (net +36) | 0 | 43% (3 of 7) |
| Mine | Warriors of Chaos | 13 | 0 | 1 (net -494) | 3 (net +294) | 1 (net +0) | 1 (net +27) | 4 (net +113) | 3 | 30% (3 of 10) |
| Opponent | Empire of Man | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net -252) | 0 | 0% (0 of 1) |
| Opponent | High Elf Realms | 30 | 2 (net +243) | 1 (net +0) | 4 (net +13) | 8 (net +82) | 4 (net +48) | 9 (net +228) | 2 | 14% (4 of 28) |
| Opponent | Lizardmen | 10 | 2 (net -32) | 0 | 2 (net +0) | 3 (net +302) | 0 | 1 (net +221) | 2 | 25% (2 of 8) |
| Opponent | Orc & Goblin Tribes | 15 | 0 | 0 | 0 | 0 | 1 (net +0) | 1 (net +214) | 13 | 0% (0 of 2) |
| Opponent | Skaven | 12 | 3 (net +0) | 0 | 3 (net +0) | 0 | 1 (net +0) | 2 (net +105) | 3 | 33% (3 of 9) |
| Opponent | Tomb Kings of Khemri | 10 | 2 (net +261) | 0 | 0 | 2 (net +364) | 1 (net +145) | 3 (net +140) | 2 | 0% (0 of 8) |
| Opponent | Vampire Counts | 25 | 4 (net -2) | 0 | 3 (net +35) | 11 (net +113) | 3 (net +126) | 2 (net +0) | 2 | 13% (3 of 23) |
| Opponent | Warriors of Chaos | 16 | 2 (net +358) | 0 | 2 (net +42) | 6 (net +193) | 0 | 4 (net +170) | 2 | 14% (2 of 14) |
| Opponent | Wood Elf Realms | 27 | 6 (net +106) | 2 (net -33) | 4 (net +13) | 5 (net +116) | 4 (net +105) | 4 (net +107) | 2 | 16% (4 of 25) |

### Charged fights, damage counted: bg-off-789c37f-p4

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 7 | 278 | 281 | -71 | 76 | 145 | -69 | -24.7 |
| Mine | 50-54% | 3 | 293 | 408 | -293 | 97 | 293 | -196 | -66.9 |
| Mine | Effective (55-75%) | 19 | 298 | 267 | +52 | 190 | 90 | +100 | +33.6 |
| Mine | 76-89% | 24 | 278 | 202 | +141 | 176 | 47 | +129 | +46.2 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 40 | 216 | 160 | +60 | 99 | 16 | +83 | +38.3 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 11 | 425 | 76 | +6 | 75 | 52 | +23 | +5.5 |
| Mine | No odds | 10 | 296 | 225 | +20 | 65 | 32 | +33 | +11.2 |
| Mine | All fights | 114 | 276 | 198 | +50 | 124 | 55 | +69 | +24.9 |
| Opponent | Long shot (under 50%) | 21 | 319 | 249 | +109 | 164 | 57 | +107 | +33.6 |
| Opponent | 50-54% | 3 | 381 | 357 | -22 | 145 | 190 | -46 | -12.0 |
| Opponent | Effective (55-75%) | 18 | 320 | 220 | +16 | 87 | 85 | +2 | +0.6 |
| Opponent | 76-89% | 35 | 313 | 211 | +151 | 181 | 24 | +157 | +50.2 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 27 | 315 | 206 | +147 | 207 | 50 | +158 | +50.1 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 14 | 489 | 114 | +81 | 95 | 24 | +71 | +14.6 |
| Opponent | No odds | 28 | 261 | 155 | -3 | 88 | 92 | -3 | -1.3 |
| Opponent | All fights | 146 | 323 | 200 | +88 | 145 | 57 | +88 | +27.2 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| bg-off-789c37f-p4 | move | 461 | 111 (24%) | 86 (19%) | 50 (11%) | 300 (65%) |
| bg-off-789c37f-p4 | objective | 362 | 51 (14%) | 39 (11%) | 49 (14%) | 262 (72%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0114, L0130, L2527, L2634 |
| Charmed Shield | Opponent | L0434, L0624, L0926, L1034, L1126, L1427, L2227, L2527, L2634, L3234 |
| Clockwork Compass | Mine | L1220 |
| Elixir of Power | Mine | L1126 |
| Elixir of Power | Opponent | L0819, L1719, L1819 |
| Fistful of Laurels | Mine | L1819, L1835 |
| Invocation of Nehek | Mine | L2527 |
| Invocation of Nehek | Opponent | L0624, L1427, L2227, L2527 |
| Opal Amulet | Mine | L1427 |
| Opal Amulet | Opponent | L0114, L0214, L1314 |
| Periapt of Soul Exchange | Mine | L2021, L2123 |
| Periapt of Soul Exchange | Opponent | L0520, L1220, L1621, L2021 |
| Ring of Doom | Mine | L0214, L0230, L1126, L1220, L1523 |
| Ring of Doom | Opponent | L0315, L1331, L2331 |
| Ring of Jet | Mine | L1017, L1034, L1126, L1220 |
| Standard of the Fell Warrior | Mine | L1314, L1331 |
| Standard of the Fell Warrior | Opponent | L0713 |
| Storm Daemon (Renegade 2.0) | Mine | L2123 |
| Storm Daemon (Renegade 2.0) | Opponent | L1621, L2021 |
| Twice-Blessed Armour | Mine | L0713, L0729, L1017, L1034 |
| Witch Hunter's Ward | Mine | L0713, L0729, L0819, L0835 |
| Witch Hunter's Ward | Opponent | L0608 |

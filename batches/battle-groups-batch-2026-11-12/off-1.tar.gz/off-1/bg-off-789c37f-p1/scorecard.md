# Doctrine scorecard: bg-off-789c37f-p1

### Scorecard: bg-off-789c37f-p1

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0102 | 6 | 1 | Mine | no | 4 | - | 0 | 1 | 1 | 0 | 0 | 0 |
| L0102 | 6 | 1 | Opponent | no | 1 | 1 | 3 | 4 | 0 | 0 | 0 | 0 |
| L0118 | 4 | 1 | Mine | no | 1 | - | 0 | 1 | 0 | 0 | 0 | 0 |
| L0118 | 4 | 1 | Opponent | no | 0 | 2 | 4 | 1 | 0 | 0 | 0 | 185 |
| L0135 | 3 | 1 | Mine | yes | 4 | - | 0 | 2 | 0 | 0 | 0 | 639 |
| L0135 | 3 | 1 | Opponent | no | 0 | 2 | 5 | 4 | 0 | 0 | 0 | 0 |
| L0218 | 2 | 1 | Mine | - | - | - | 0 | 6 | 0 | 0 | 0 | 170 |
| L0218 | 2 | 1 | Opponent | - | - | 3 | 0 | 1 | 0 | 0 | 0 | 0 |
| L0235 | 1 | 1 | Mine | no | 0 | 2 | 1 | 4 | 0 | 0 | 0 | 0 |
| L0235 | 1 | 1 | Opponent | no | 1 | 1 | 5 | 2 | 0 | 0 | 0 | 0 |
| L0319 | 1 | 1 | Mine | no | 2 | 3 | 0 | 1 | 0 | 0 | 0 | 675 |
| L0319 | 1 | 1 | Opponent | no | 0 | 2 | 3 | 2 | 0 | 0 | 0 | 0 |
| L0405 | 3 | 1 | Mine | yes | 2 | 2 | 4 | 2 | 1 | 0 | 0 | 0 |
| L0405 | 3 | 1 | Opponent | no | 1 | - | 0 | 0 | 0 | 0 | 0 | 1416 |
| L0421 | 1 | 1 | Mine | no | 0 | 2 | 4 | 3 | 0 | 0 | 0 | 0 |
| L0421 | 1 | 1 | Opponent | no | 1 | - | 0 | 5 | 1 | 0 | 0 | 355 |
| L0508 | 4 | 1 | Mine | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 548 |
| L0508 | 4 | 1 | Opponent | no | 0 | 4 | 1 | 4 | 0 | 0 | 0 | 605 |
| L0524 | 2 | 1 | Mine | - | - | - | 0 | 0 | 0 | 0 | 0 | 548 |
| L0524 | 2 | 1 | Opponent | - | - | 2 | 0 | 4 | 0 | 0 | 0 | 0 |
| L0612 | 6 | 1 | Mine | no | 0 | - | 2 | 2 | 0 | 0 | 0 | 798 |
| L0612 | 6 | 1 | Opponent | no | 6 | 5 | 1 | 0 | 1 | 0 | 0 | 330 |
| L0628 | 4 | 1 | Mine | no | 0 | 2 | 3 | 0 | 0 | 0 | 0 | 1069 |
| L0628 | 4 | 1 | Opponent | yes | 2 | 2 | 2 | 0 | 0 | 0 | 0 | 414 |
| L0717 | 3 | 1 | Mine | no | 3 | 2 | 1 | 0 | 0 | 0 | 0 | 513 |
| L0717 | 3 | 1 | Opponent | no | 10 | 2 | 3 | 2 | 0 | 0 | 0 | 175 |
| L0733 | 1 | 1 | Mine | no | 8 | 2 | 3 | 0 | 1 | 0 | 0 | 375 |
| L0733 | 1 | 1 | Opponent | no | 0 | 1 | 2 | 4 | 0 | 0 | 0 | 316 |
| L0823 | 1 | 1 | Mine | no | 0 | - | 0 | 0 | 1 | 0 | 0 | 515 |
| L0823 | 1 | 1 | Opponent | no | 5 | 2 | 1 | 1 | 2 | 0 | 0 | 185 |
| L0913 | 1 | 1 | Mine | no | 2 | 4 | 2 | 1 | 0 | 0 | 0 | 726 |
| L0913 | 1 | 1 | Opponent | no | 6 | 4 | 3 | 1 | 0 | 0 | 0 | 140 |
| L0930 | 6 | 1 | Mine | no | 0 | 4 | 2 | 1 | 0 | 0 | 0 | 995 |
| L0930 | 6 | 1 | Opponent | no | 4 | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| L1021 | 1 | 1 | Mine | no | 0 | 2 | 4 | 0 | 0 | 0 | 0 | 330 |
| L1021 | 1 | 1 | Opponent | no | 0 | - | 3 | 4 | 1 | 0 | 0 | 650 |
| L1114 | 4 | 1 | Mine | no | 0 | 3 | 1 | 0 | 1 | 0 | 0 | 330 |
| L1114 | 4 | 1 | Opponent | no | 0 | 2 | 3 | 4 | 1 | 0 | 0 | 123 |
| L1131 | 3 | 1 | Mine | no | 2 | 5 | 4 | 0 | 1 | 0 | 0 | 330 |
| L1131 | 3 | 1 | Opponent | no | 2 | - | 0 | 1 | 2 | 0 | 0 | 170 |
| L1224 | 6 | 1 | Mine | no | 3 | 2 | 2 | 0 | 2 | 0 | 0 | 330 |
| L1224 | 6 | 1 | Opponent | no | 10 | 2 | 1 | 3 | 0 | 0 | 0 | 205 |
| L1319 | 5 | 1 | Mine | yes | - | 3 | 1 | 2 | 1 | 0 | 0 | 302 |
| L1319 | 5 | 1 | Opponent | yes | - | 2 | 1 | 1 | 0 | 0 | 0 | 0 |
| L1335 | 3 | 1 | Mine | no | 4 | 2 | 4 | 0 | 1 | 0 | 0 | 140 |
| L1335 | 3 | 1 | Opponent | no | 2 | 2 | 4 | 3 | 1 | 0 | 0 | 140 |
| L1431 | 3 | 1 | Mine | yes | 0 | 2 | 2 | 0 | 0 | 0 | 0 | 177 |
| L1431 | 3 | 1 | Opponent | no | 5 | 2 | 2 | 1 | 2 | 0 | 0 | 170 |
| L1527 | 3 | 1 | Mine | no | 5 | 2 | 5 | 1 | 0 | 0 | 0 | 199 |
| L1527 | 3 | 1 | Opponent | no | 0 | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L1625 | 5 | 1 | Mine | yes | - | 3 | 3 | 1 | 0 | 0 | 0 | 200 |
| L1625 | 5 | 1 | Opponent | yes | - | 1 | 3 | 0 | 0 | 0 | 0 | 0 |
| L1723 | 1 | 1 | Mine | yes | 3 | 2 | 4 | 0 | 3 | 0 | 0 | 147 |
| L1723 | 1 | 1 | Opponent | no | 0 | 2 | 5 | 0 | 0 | 0 | 0 | 0 |
| L1823 | 5 | 1 | Mine | yes | - | - | 2 | 1 | 1 | 0 | 0 | 0 |
| L1823 | 5 | 1 | Opponent | yes | - | 2 | 5 | 3 | 0 | 0 | 0 | 66 |
| L1923 | 3 | 1 | Mine | yes | 2 | 2 | 6 | 1 | 1 | 0 | 0 | 0 |
| L1923 | 3 | 1 | Opponent | no | 2 | 1 | 5 | 0 | 0 | 0 | 0 | 0 |
| L2025 | 3 | 1 | Mine | yes | 5 | - | 1 | 2 | 1 | 0 | 0 | 420 |
| L2025 | 3 | 1 | Opponent | no | 1 | 2 | 2 | 0 | 0 | 0 | 0 | 0 |
| L2127 | 3 | 1 | Mine | no | 6 | - | 3 | 2 | 1 | 0 | 0 | 577 |
| L2127 | 3 | 1 | Opponent | no | 5 | 1 | 4 | 1 | 0 | 0 | 0 | 0 |
| L2231 | 5 | 1 | Mine | yes | - | 2 | 2 | 0 | 0 | 0 | 0 | 0 |
| L2231 | 5 | 1 | Opponent | no | - | 1 | 6 | 1 | 3 | 0 | 0 | 541 |
| L2335 | 1 | 1 | Mine | no | 0 | 1 | 2 | 2 | 0 | 0 | 0 | 0 |
| L2335 | 1 | 1 | Opponent | no | 0 | 3 | 3 | 1 | 0 | 0 | 0 | 158 |
| L2531 | 5 | 1 | Mine | no | - | 5 | 2 | 5 | 0 | 0 | 0 | 0 |
| L2531 | 5 | 1 | Opponent | no | - | 2 | 2 | 1 | 1 | 0 | 0 | 170 |
| L2730 | 6 | 1 | Mine | no | 0 | 4 | 6 | 2 | 0 | 0 | 0 | 0 |
| L2730 | 6 | 1 | Opponent | no | 5 | 2 | 5 | 1 | 0 | 0 | 0 | 0 |
| L2934 | 6 | 1 | Mine | no | 0 | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L2934 | 6 | 1 | Opponent | no | 0 | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 29% | 1.9 | 2.6 | 2.2 | 1.3 | 0.5 | 0.0 | 0.0 | 307.0 |
| **Average** | | | Opponent | 12% | 2.4 | 2.1 | 2.6 | 1.8 | 0.4 | 0.0 | 0.0 | 180.9 |

### KPIs: bg-off-789c37f-p1

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Winner chose to follow up after the loser gave ground |  | 98% (60 of 61); on the table 100% | 98% (54 of 55); on the table 98% | 98% (114 of 116); on the table 99% |
| Winner chose to pursue after the loser fell back in good order |  | 91% (10 of 11); on the table 91% | 95% (21 of 22); on the table 95% | 94% (31 of 33); on the table 94% |
| Winner chose to pursue after the loser fled |  | 81% (22 of 27); on the table 81% | 82% (36 of 44); on the table 86% | 82% (58 of 71); on the table 85% |
| Winner chose to follow up or pursue (all three) |  | 93% (92 of 99); on the table 94% | 92% (111 of 121); on the table 93% | 92% (203 of 220); on the table 94% |
| Magic missiles tried each own turn | 50%+ | 28% (93 of 330) | 24% (51 of 210) | 27% (144 of 540) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 40% (93 of 232) | 35% (51 of 144) | 38% (144 of 376) |
| Points that never fought | lower | 37% (26305 of 71484) | 36% (26219 of 71889) | 37% (52524 of 143373) |
|   infantry points that never fought | lower | 52% (8844 of 16863) | 52% (6929 of 13348) | 52% (15773 of 30211) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 56% (155 of 279) | 57% (169 of 295) | 56% (324 of 574) |
| Bound items with a magic missile used (at least once a game) |  | 91% (20 of 22); 1.4 uses a game | 65% (13 of 20); 0.9 uses a game | 79% (33 of 42); 1.2 uses a game |
| Bound items with another spell used |  | 50% (8 of 16); 0.5 uses a game | 25% (2 of 8); 0.1 uses a game | 42% (10 of 24); 0.3 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 58% (11 of 19); 0.3 uses a game | 58% (7 of 12); 0.2 uses a game | 58% (18 of 31); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 51% (30331 of 59666) | 51% (32208 of 62699) | 51% (62539 of 122365) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.7 (26%) | 1.1 (26%) | 2.9 (26%) |
| MARCHED: its unit marched | 1.6 (24%) | 1.0 (23%) | 2.6 (23%) |
| CHARGED: its unit charged | 0.4 (5%) | 0.2 (6%) | 0.6 (6%) |
| IN COMBAT: engaged in combat | 1.2 (19%) | 0.8 (18%) | 2.0 (18%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.1 (1%) | 0.1 (1%) |
| FLEEING: fleeing | 0.1 (1%) | 0.1 (3%) | 0.2 (2%) |
| GONE: slain | 0.8 (11%) | 0.7 (16%) | 1.4 (13%) |
| OFF THE TABLE: off the table or not arrived | 0.6 (10%) | 0.2 (6%) | 0.9 (8%) |
| STUPIDITY: Stupidity | 0.1 (2%) | 0.0 (1%) | 0.1 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.1 (3%) | 0.1 (1%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 3.9 | 1.7 | 1.2 | 4.0 | 0.3 | 2.0 |
| not cast | 4.1 | 2.6 | 3.5 | 11.0 | 2.0 | 22.0 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) | 0.0 (0%) | 1.6 (7%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (1%) | 0.9 (34%) | 0.2 (7%) | 2.9 (26%) | 0.4 (22%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.6 (23%) | 0.4 (19%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.6 (6%) | 0.1 (6%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.1 (3%) | 0.3 (11%) | 0.5 (14%) | 2.0 (18%) | 0.4 (21%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.2 (4%) | 0.3 (13%) | 0.4 (10%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) |
| NO CASTS LEFT: every cast used on other spells | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (4%) | 0.0 (0%) |
| FLEEING: fleeing | 0.2 (4%) | 0.1 (2%) | 0.0 (1%) | 0.2 (2%) | 0.0 (1%) | 0.6 (3%) |
| GONE: slain | 0.8 (20%) | 0.4 (17%) | 0.6 (16%) | 1.4 (13%) | 0.2 (8%) | 2.8 (13%) |
| OFF THE TABLE: off the table or not arrived | 0.4 (10%) | 0.1 (5%) | 0.2 (6%) | 0.9 (8%) | 0.1 (4%) | 1.4 (6%) |
| STUPIDITY: Stupidity | 0.2 (5%) | 0.1 (3%) | 0.0 (1%) | 0.1 (1%) | 0.0 (0%) | 0.3 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (1%) | 0.2 (8%) | 0.0 (0%) | 0.1 (1%) | 0.3 (14%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.2 (53%) | 0.2 (6%) | 1.5 (44%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 15.2 (69%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.9 a game | 0.5 a game | 0.7 a game |
| stood (cast and not dispelled) | 56% (14 of 25) | 57% (8 of 14) | 56% (22 of 39) |
| the unit moved after it | 50% (7 of 14) | 88% (7 of 8) | 64% (14 of 22) |
| it charged on its next turn | 0% (0 of 14) | 0% (0 of 8) | 0% (0 of 22) |
| the enemy charged it first | 29% (4 of 14) | 0% (0 of 8) | 18% (4 of 22) |
| it fought by the end of its next turn | 7% (1 of 14) | 12% (1 of 8) | 9% (2 of 22) |
| it moved out of a charge the enemy had planned (not charged first) | 29% (4 of 14) | 0% (0 of 8) | 18% (4 of 22) |
| none of these (no charge, no fight, no charge escaped) | 43% (6 of 14) | 88% (7 of 8) | 59% (13 of 22) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 63% (573 of 914) | 57% (351 of 617) | 60% (924 of 1531) |
|   cavalry | 55% (41 of 75) | 61% (74 of 121) | 59% (115 of 196) |
|   character | 47% (47 of 100) | 30% (36 of 119) | 38% (83 of 219) |
|   chariot | 48% (41 of 86) | 72% (26 of 36) | 55% (67 of 122) |
|   infantry | 54% (167 of 307) | 62% (153 of 245) | 58% (320 of 552) |
|   monster | 50% (21 of 42) | 37% (11 of 30) | 44% (32 of 72) |
|   war machine | 84% (256 of 304) | 77% (51 of 66) | 83% (307 of 370) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 3.3 (35%) | 1.9 (26%) | 5.3 (31%) |
| CHARGED: it charged | 1.1 (12%) | 1.7 (23%) | 2.8 (17%) |
| FLEEING: it fled or was fleeing | 0.3 (3%) | 0.2 (2%) | 0.4 (3%) |
| IN COMBAT: it fought this turn or the last | 0.6 (6%) | 0.4 (5%) | 0.9 (5%) |
| MOVED: a war machine that moved | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NO TARGET IN RANGE | 1.2 (13%) | 0.8 (11%) | 2.0 (12%) |
| ONLY IN COMBAT: the only targets were in combat | 0.7 (7%) | 0.6 (8%) | 1.2 (7%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.7 (18%) | 1.2 (16%) | 2.9 (17%) |
| SHELTERED: the target was sheltered | 0.3 (3%) | 0.5 (7%) | 0.8 (5%) |
| STUPIDITY | 0.0 (0%) | 0.0 (0%) | 0.1 (0%) |
| OTHER BAR | 0.2 (3%) | 0.1 (2%) | 0.4 (2%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 4.9 | 1.3 | 79% | 5.5 pts | 27 pts |
| character | 2.6 | 0.7 | 80% | 6.8 pts | 18 pts |
| chariot | 1.9 | 0.8 | 72% | 8.6 pts | 16 pts |
| infantry | 13.2 | 4.6 | 76% | 8.9 pts | 118 pts |
| monster | 1.1 | 0.3 | 82% | 10.0 pts | 11 pts |
| war machine | 8.5 | 6.8 | 61% | 26.7 pts | 228 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.9 | 6.1 | 5.0 |
| Charges that made contact a game | 2.8 | 4.5 | 3.6 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.05 declared, 0.58 contact (19 units) | 0.50 declared, 0.43 contact (14 units) | 0.82 declared, 0.52 contact (33 units) |
|   per unit a game, units carrying another wizard (or one alone) | 1.33 declared, 1.17 contact (6 units) | 1.43 declared, 1.00 contact (7 units) | 1.38 declared, 1.08 contact (13 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.45 declared, 0.33 contact (250 units) | 0.71 declared, 0.52 contact (287 units) | 0.59 declared, 0.43 contact (537 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 47% (33 of 70) | 48% (10 of 21) | 38% (3 of 8) | 46% (46 of 99) |
| Character in a unit | 72% (29 of 40) | 61% (14 of 23) | 75% (3 of 4) | 69% (46 of 67) |
| Character on its own | 77% (36 of 47) | 68% (25 of 37) | 24% (15 of 62) | 52% (76 of 146) |
| Chariot | 75% (12 of 16) | 80% (8 of 10) | - | 77% (20 of 26) |
| Infantry | 57% (51 of 89) | 50% (18 of 36) | 0% (0 of 2) | 54% (69 of 127) |
| Monster | 53% (17 of 32) | 80% (8 of 10) | - | 60% (25 of 42) |
| Monstrous | 82% (9 of 11) | 29% (4 of 14) | - | 52% (13 of 25) |
| War Machines | 68% (28 of 41) | 100% (1 of 1) | - | 69% (29 of 42) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 6 | 84% (21 of 25); on the table 84% | 33% (45 of 138) | 35% | 55% (18 of 33) | 89% (8 of 9); 2.8 uses a game | 100% (3 of 3); 1.0 uses a game | 78% (7 of 9); 1.2 uses a game |
| Chaos Dwarfs | 3 | 100% (5 of 5); on the table 100% | 29% (7 of 24) | 44% | 54% (13 of 24) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 0.3 uses a game |
| Dwarfen Mountain Holds | 5 | 100% (6 of 6); on the table 100% | - | 51% | 71% (29 of 41) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 6 | 67% (4 of 6); on the table 83% | 36% (13 of 36) | 52% | 53% (34 of 64) | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game | 25% (1 of 4); 0.2 uses a game |
| Grand Cathay | 5 | 100% (18 of 18); on the table 100% | 27% (29 of 108) | 53% | 52% (23 of 44) | 92% (11 of 12); 6.6 uses a game | 0% (0 of 1); 0.0 uses a game | 40% (2 of 5); 0.4 uses a game |
| High Elf Realms | 6 | 82% (14 of 17); on the table 82% | 17% (5 of 30) | 31% | 57% (28 of 49) | 100% (5 of 5); 2.7 uses a game | 39% (7 of 18); 2.5 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | 100% (6 of 6); on the table 100% | - | 19% | 33% (2 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Lizardmen | 2 | 100% (9 of 9); on the table 100% | - | 21% | 71% (10 of 14) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 3 | 80% (4 of 5); on the table 100% | 0% (0 of 12) | 53% | 62% (13 of 21) | 67% (2 of 3); 2.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 3 | 100% (6 of 6); on the table 100% | 19% (7 of 36) | 17% | 38% (9 of 24) | 0.0 uses a game | 0.0 uses a game | 100% (3 of 3); 1.0 uses a game |
| Skaven | 4 | 100% (8 of 8); on the table 100% | 13% (4 of 30) | 32% | 76% (26 of 34) | 100% (3 of 3); 1.2 uses a game | 0.0 uses a game | 50% (2 of 4); 0.5 uses a game |
| Tomb Kings of Khemri | 6 | 95% (35 of 37); on the table 95% | 8% (1 of 12) | 26% | 20% (6 of 30) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 8 | 93% (26 of 28); on the table 93% | 26% (14 of 54) | 35% | 66% (33 of 50) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 8 | 88% (23 of 26); on the table 92% | 23% (7 of 30) | 28% | 57% (42 of 74) | 50% (2 of 4); 0.2 uses a game | 0.0 uses a game | 50% (1 of 2); 0.1 uses a game |
| Wood Elf Realms | 6 | 100% (18 of 18); on the table 100% | 40% (12 of 30) | 37% | 58% (38 of 66) | 33% (2 of 6); 1.2 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (bg-off-789c37f-p1, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 51% (44) | 40% (25) | 46% (69) |
| ...free all their last turn and able to turn (per game) | 0.86 | 0.47 | 1.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.14 | 0.06 | 0.19 |
| ...with the charger already in that arc before they moved (per game) | 0.61 | 0.31 | 0.92 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 1.36 | 0.97 | 2.33 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.83 | 0.86 | 1.69 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 10.11 | 10.22 | 20.33 |

### Quality by phase: bg-off-789c37f-p1

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.1 | 3.4 |
| Strategy | Charge objectives carried out (made contact) | 48% (58 of 121) | 46% (81 of 175) |
| Strategy | Shoot objectives carried out (shot that target) | 58% (209 of 361) | 55% (82 of 148) |
| Strategy | Close-in objectives charged next turn | 15% (25 of 164) | 15% (35 of 227) |
| Strategy | Support requests answered (helper made contact too) | 38% (3 of 8) | 77% (23 of 30) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 33% (1 of 3) | 100% (2 of 2) |
| Strategy | Hexes on a unit its side charged or shot that turn | 21% (3 of 14) | 41% (7 of 17) |
| Strategy | Joined characters whose unit fought | 37% (18 of 49) | 51% (23 of 45) |
| Strategy | Lone characters that fought | 82% (80 of 97) | 80% (73 of 91) |
| Movement | Charges halted short of contact | 0.2 | 0.1 |
| Movement | Idle units | 1.3 | 1.8 |
| Movement | Points that never moved of their own | 307.0 | 180.9 |
| Movement | Fights charged into per game | 2.5 | 3.6 |
| Movement | Charges with odds: long shots (under 50%) | 15 of 76, net +126 | 12 of 103, net +78 |
| Movement | Charges with odds: sweet spot (55-75%) | 11 of 76, net +43 | 17 of 103, net +116 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 15 of 76, net +62 | 11 of 103, net +117 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 23 of 76, net +226 | 39 of 103, net +128 |
| Shooting | Shots by shooting units (incl. breath weapons) | 9.7 | 9.2 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 47% (163 of 350) | 48% (160 of 333) |
| Shooting | Points destroyed by shooting units | 62.9 | 14.7 |
| Shooting | War machine shots | 7.1 | 1.4 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 54% (137 of 256) | 33% (17 of 51) |
| Shooting | Points destroyed by war machines | 94.8 | 36.4 |
| Magic | Magic missiles cast | 1.4 | 0.8 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 31% (16 of 52) | 55% (16 of 29) |
| Magic | Wounds caused by magic missiles | 4.4 | 1.1 |
| Magic | Wounds caused by other spells | 2.4 | 0.5 |
| Magic | Points destroyed by magic (all spells) | 83.6 | 23.7 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.2 / 0.4 / 0.9 / 0.1 | 1.5 / 0.5 / 0.4 / 0.1 |
| Combat | Points destroyed in combat | 299.5 | 424.4 |
| Combat | Points run down | 92.6 | 82.2 |
| Combat | Net points per charged fight, damage counted | +106 | +115 |
| Combat | Net per 100 charger points, damage counted | +40.0 | +39.5 |
| Combat | First round won (charged fights) | 49% | 70% |
| Combat | Net points per charged fight | +95 | +104 |
| Combat | Net points per supported fight / lone fight | +154 / +88 | +104 / +104 |
| Combat | Charged fights on a top-3 enemy unit | 30 of 90 | 62 of 130 |
| Game | Points lost | 747.8 | 707.5 |
| Game | VP from objectives | 632.5 | 564.7 |
| Game | Lone holders (player turns) | 1.9 | 2.4 |

- Mine won / drew / lost: 16 / 5 / 15 of 36 ended games (of 36); mean margin (Mine - Opponent) +20 VP
- The side that went first won 15 of 31 games with a winner
- Points traded per game (both sides' losses): 1455
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: bg-off-789c37f-p1

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.6 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| ALREADY CARRIED | 0.0 | +0.0 | 0.0 | 3.6 | - | - | - | - |
| ARRIVAL HUNT | - | - | - | - | 0.0 | +0.2 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.5 | +0.0 | 0.0 | 28.1 | 0.4 | +0.0 | 0.0 | 2.6 |
| BACKUP TARGETS | 0.9 | +8.7 | 0.0 | 44.2 | 1.1 | +10.1 | 0.0 | 5.0 |
| BEST PREY | 4.3 | +282.3 | 108.3 | 164.2 | 5.6 | +394.1 | 224.7 | 151.0 |
| BEST PRIZE | 0.1 | +0.4 | 0.0 | 13.7 | 0.1 | +1.4 | 5.7 | 0.0 |
| BLOCKED CHARGE SKIPPED | 0.1 | +0.0 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 0.8 |
| BLOCKED WHEEL | 0.5 | +3.9 | 0.0 | 19.4 | 0.6 | +1.3 | 0.0 | 13.3 |
| BOMBING RUN | 0.1 | +3.4 | 4.9 | 0.0 | - | - | - | - |
| BOUND ASSAILMENT | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CANNON PLAN MISSED | 0.6 | +0.0 | 83.1 | 0.0 | 0.1 | +0.0 | 21.2 | 0.0 |
| CANNON PLANNED TARGET | 5.6 | +188.6 | 368.8 | 71.4 | 1.2 | +77.2 | 145.5 | 5.3 |
| CANNON SIGHT KEPT | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CAST JOB | 0.7 | +31.8 | 38.1 | 5.2 | 0.2 | +3.8 | 1.7 | 22.6 |
| CASTER AWAY FROM SCREEN | 0.3 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.6 | +55.7 | 27.8 | 0.0 | 0.2 | +17.5 | 22.5 | 0.0 |
| CASTS AFTER FRIENDS | 0.5 | +0.0 | 0.0 | 9.9 | 0.3 | +0.0 | 0.0 | 7.6 |
| CASTS FROM BEHIND | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.1 | +0.6 | 0.0 | 0.0 | 0.0 | +0.1 | 0.0 | 0.0 |
| CHAFF PASSED | 0.1 | -0.3 | 5.4 | 1.8 | 0.1 | -0.3 | 0.0 | 10.0 |
| CHARGE NOW WEIGHED | 0.3 | -24.2 | 17.9 | 9.1 | 0.4 | -49.2 | 19.9 | 6.3 |
| CHARIOT NO STATIC JOB | 0.9 | +0.0 | 0.0 | 16.9 | 0.7 | +0.0 | 3.1 | 6.5 |
| CHEAP HELPER | 0.1 | +0.0 | 3.5 | 2.6 | 0.2 | +0.0 | 8.3 | 9.3 |
| CONTINUE AHEAD WEIGHED | 0.1 | +0.0 | 8.9 | 0.0 | - | - | - | - |
| CONVEYANCE SEARCH | 0.5 | +33.1 | 15.4 | 21.1 | 0.3 | +48.2 | 21.7 | 29.1 |
| EDGE GIVE GROUND | 0.1 | +1.6 | 11.9 | 6.3 | 0.1 | +5.9 | 19.7 | 0.0 |
| ELIXIR WORTH | 0.0 | +0.3 | 0.0 | 0.0 | 0.1 | +0.1 | 0.0 | 0.0 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 1.4 | +119.8 | 0.0 | 43.3 | 1.0 | +115.0 | 0.0 | 31.5 |
| FIGHT LIFT | 0.1 | +2.5 | 0.0 | 0.0 | - | - | - | - |
| FIRE AND FLEE | - | - | - | - | 0.1 | +1.0 | 0.0 | 3.2 |
| FOCUS FIRE | 0.0 | +2.2 | 3.1 | 0.0 | 0.1 | +0.9 | 2.5 | 0.0 |
| FOLLOW UP WEIGHED | 1.1 | +123.0 | 0.0 | 24.4 | 1.1 | +179.6 | 0.0 | 14.3 |
| FRIENDS SHOTS CHECKED | 0.4 | +15.9 | 0.0 | 22.7 | 0.3 | +27.7 | 0.0 | 0.0 |
| GIVES UP | 1.0 | -22.5 | 138.1 | 10.7 | 1.5 | -45.0 | 182.6 | 39.3 |
| GIVES UP ITS SCREEN | 0.4 | -5.2 | 23.2 | 17.6 | 1.2 | -16.5 | 74.1 | 12.9 |
| GROUND FLIERS | 0.0 | +0.1 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| HELPER ALREADY ASKED | - | - | - | - | 0.1 | +0.0 | 6.5 | 1.4 |
| HELPER UNSEEN | 0.2 | +0.0 | 14.9 | 0.0 | 0.4 | +0.0 | 24.0 | 1.4 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.8 | +0.0 | 0.0 | 0.0 |
| HUNT ADVANCE | - | - | - | - | 0.2 | +15.0 | 0.0 | 8.1 |
| HUNT DROPPED | - | - | - | - | 0.1 | +0.0 | 0.0 | 4.1 |
| HUNT KEPT | - | - | - | - | 0.1 | +3.4 | 0.0 | 8.1 |
| HUNT RESULT | - | - | - | - | 0.2 | +0.0 | 3.6 | 12.5 |
| HUNT THE GUNS | - | - | - | - | 0.2 | +79.9 | 0.0 | 4.5 |
| JOINT CHARGE PLAN | 0.1 | +3.7 | 3.2 | 4.2 | 0.1 | +1.3 | 0.0 | 0.0 |
| KEEPS ITS PREY | 0.3 | +2.1 | 0.0 | 15.0 | 0.2 | +0.8 | 3.2 | 5.4 |
| KEEPS ITS TARGET | 1.6 | +48.3 | 145.4 | 25.6 | 2.4 | +73.3 | 168.8 | 41.6 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KILLS COUNT | 1.6 | +60.8 | 97.7 | 26.0 | 2.2 | +85.7 | 232.5 | 31.6 |
| KILLS COUNT NEXT TURN | 8.5 | +306.6 | 360.2 | 229.4 | 11.1 | +474.8 | 459.6 | 208.2 |
| LONE CHARACTER SAFE SPOT | 0.2 | +6.5 | 3.4 | 33.2 | 0.4 | +13.1 | 14.5 | 15.1 |
| LONE WIZARD HOLDS BACK | 0.8 | +0.0 | 21.7 | 36.1 | 1.0 | +0.0 | 33.7 | 52.9 |
| LONE WIZARD KEPT IN | 0.7 | +49.1 | 0.0 | 0.0 | 0.2 | +24.5 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 0.6 | +35.9 | 19.3 | 18.1 | 0.4 | +29.2 | 6.3 | 4.0 |
| MANOEUVRE | 0.1 | +0.8 | 0.0 | 13.2 | 0.1 | +4.8 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.1 | +2.2 | 0.0 | 0.0 | 0.2 | +1.8 | 0.0 | 1.7 |
| MARCH ODDS | 1.0 | +117.4 | 38.6 | 21.4 | 0.7 | +67.9 | 29.9 | 0.0 |
| MISSILES IN THE MOVE | 3.4 | +149.4 | 0.0 | 59.2 | 2.8 | +41.5 | 0.0 | 99.7 |
| MISSILES NEXT TURN | 4.7 | +115.2 | 0.0 | 114.6 | 3.9 | +35.8 | 0.0 | 115.0 |
| MODEL FACING | 0.3 | +150.9 | 0.0 | 6.7 | - | - | - | - |
| MOVE AND CAST | 0.2 | +10.5 | 0.0 | 0.0 | 0.1 | +0.8 | 0.0 | 0.0 |
| MOVE SPELL IN RANGE | 0.1 | +3.6 | 0.0 | 16.1 | - | - | - | - |
| MOVE SPELL NOT WORTH | 0.0 | -0.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.3 | -55.1 | 0.0 | 38.2 | 0.2 | -19.4 | 33.3 | 0.0 |
| MOVE SPELL SPOT | 0.2 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| MOVES UNITS SPELL | 0.1 | +3.4 | 0.0 | 0.0 | 0.1 | +1.8 | 0.0 | 0.0 |
| NEEDED THERE | 0.1 | +1.5 | 3.5 | 0.0 | - | - | - | - |
| NO RALLY LEFT | 0.0 | +1.0 | 0.0 | 0.0 | - | - | - | - |
| NOT NEEDED | 0.2 | -15.3 | 29.6 | 5.6 | 0.5 | -23.5 | 51.8 | 6.7 |
| NOT TURNED | 10.1 | +143.3 | 0.0 | 288.8 | 10.2 | +105.1 | 0.0 | 209.4 |
| NOT WORTH A CAST | 0.9 | -0.7 | 0.0 | 22.4 | 0.3 | -0.2 | 0.0 | 15.0 |
| OPENS A LANE | 0.1 | +0.4 | 7.4 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| OPENS UP | 0.3 | +26.2 | 23.5 | 0.0 | 0.2 | +13.5 | 10.2 | 7.9 |
| OVERRUNS AWAY | 0.3 | +9.8 | 22.8 | 13.3 | 0.6 | +16.1 | 39.2 | 9.7 |
| PATHS CROSS | 2.4 | +125.0 | 0.0 | 62.9 | 2.9 | +147.3 | 0.0 | 55.6 |
| PERIAPT WORTH | 0.0 | +3.4 | 0.0 | 15.0 | 0.0 | +3.4 | 0.0 | 0.0 |
| PLAN LEADS | 1.1 | +96.5 | 32.0 | 25.9 | 1.0 | +82.7 | 25.2 | 17.2 |
| PLAN RESULT | 37.7 | +1447.0 | 1272.1 | 955.4 | 39.4 | +1354.3 | 1523.3 | 968.5 |
| PURSUES BIG PREY | 0.1 | -4.0 | 0.0 | 0.0 | 0.1 | -3.1 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE | - | - | - | - | 0.0 | +6.6 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE NEXT TURN | 0.1 | +5.2 | 0.0 | 0.0 | 0.1 | +9.0 | 0.0 | 0.0 |
| REDIRECT WEIGHED | 0.3 | +8.7 | 5.5 | 16.7 | 0.6 | +18.8 | 19.2 | 5.4 |
| RESTRAINS TO SHOOT | 0.0 | +0.3 | 0.0 | 7.2 | 0.1 | +3.4 | 0.0 | 0.0 |
| RISK BY ARC | 2.0 | +95.4 | 184.5 | 54.3 | 3.2 | +121.3 | 278.6 | 78.2 |
| SAFER THAN THE JOB | 0.8 | +37.8 | 0.0 | 22.7 | 0.9 | +56.3 | 0.0 | 18.5 |
| SCOUT SPOT | 0.4 | +0.6 | 0.0 | 0.9 | 0.3 | +0.5 | 0.0 | 0.0 |
| SCOUT WAITS | 0.4 | +0.0 | 0.0 | 0.9 | 0.3 | +0.0 | 0.0 | 0.0 |
| SEARCH SPOT | 0.8 | +48.8 | 0.0 | 16.5 | 0.7 | +45.3 | 0.0 | 19.9 |
| SELF MOVE SPELL | 0.3 | +16.2 | 0.0 | 0.0 | 0.3 | +3.2 | 0.0 | 0.0 |
| SET UP TOGETHER | 1.0 | +54.7 | 24.9 | 29.2 | 1.1 | +72.2 | 24.0 | 25.8 |
| SHOOTERS IN TWO RANKS | 0.4 | +0.9 | 0.0 | 0.0 | 0.2 | +0.6 | 0.0 | 0.0 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 3.3 | 0.0 | +0.0 | 0.0 | 3.8 |
| SHOT REPLANNED | 0.4 | +0.0 | 66.2 | 8.8 | 0.2 | +0.0 | 40.5 | 0.0 |
| SHOTS IN THE MOVE | 14.0 | +594.1 | 0.0 | 211.4 | 8.8 | +210.7 | 0.0 | 129.6 |
| SPELL CATCH ODDS | 0.1 | -0.2 | 6.5 | 0.0 | - | - | - | - |
| SPELL SETS UP CHARGE | 0.0 | +19.2 | 8.9 | 0.0 | 0.1 | +23.8 | 13.9 | 13.9 |
| SPELL WORTH | 0.9 | +19.6 | 109.4 | 113.8 | 1.7 | +33.7 | 73.9 | 70.2 |
| STANDS TO CAST | - | - | - | - | 0.0 | +1.2 | 0.0 | 0.0 |
| STOPS | - | - | - | - | 0.0 | +1.6 | 0.0 | 1.2 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 4.0 | 0.3 | +0.0 | 0.0 | 12.8 |
| SUPPORT JOB KEPT | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |
| SURE CHARGE BEATS ADVANCE | 0.1 | -5.8 | 0.0 | 0.0 | 0.2 | -7.0 | 10.5 | 0.0 |
| THROUGH LINE OF FIRE | 0.6 | +21.6 | 0.0 | 18.2 | 0.3 | +1.6 | 0.0 | 8.0 |
| TURN WORTH | 0.5 | -42.6 | 48.2 | 15.3 | 0.5 | -26.8 | 40.9 | 10.7 |
| TWO OR MORE ARRIVE | 0.6 | +12.0 | 24.9 | 25.9 | 0.4 | +1.2 | 0.0 | 1.8 |
| WEARS DOWN | 0.9 | +41.4 | 126.2 | 22.8 | 1.3 | +44.2 | 105.1 | 35.0 |
| WHO HITS BACK | 0.2 | +11.3 | 0.0 | 0.0 | 0.2 | +33.4 | 0.0 | 26.4 |
| WHOLE FIGHT | 0.3 | +18.9 | 39.1 | 0.0 | 0.3 | +22.7 | 19.6 | 8.6 |
| WHOLE FIGHT GAIN | 0.2 | +22.0 | 10.4 | 9.5 | 0.7 | +71.0 | 83.9 | 16.8 |

### Rule changes: bg-off-789c37f-p1

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| KILLS COUNT NEXT TURN | 705 | 694 | 199 | 5.53 | +7569 | +38.0 |
| BEST PREY | 357 | 350 | 166 | 4.61 | +6684 | +40.3 |
| FOLLOW UP WEIGHED | 78 | 78 | 78 | 2.17 | +10893 | +139.7 |
| CANNON PLANNED TARGET | 248 | 248 | 70 | 1.94 | -360 | -5.1 |
| ARTILLERY RE-ROLL WEIGHED | 68 | 68 | 68 | 1.89 | +0 | +0.0 |
| RISK BY ARC | 188 | 177 | 62 | 1.72 | +2163 | +34.9 |
| ADVANCE LANE KEPT | 47 | 47 | 47 | 1.31 | +0 | +0.0 |
| CANNON SIGHT KEPT | 47 | 47 | 47 | 1.31 | +0 | +0.0 |
| MARCH ODDS | 62 | 47 | 45 | 1.25 | +1306 | +29.0 |
| HOLDS AMBUSHERS | 44 | 44 | 44 | 1.22 | +0 | +0.0 |
| KEEPS ITS TARGET | 146 | 144 | 43 | 1.19 | +678 | +15.8 |
| SET UP TOGETHER | 74 | 72 | 39 | 1.08 | +1639 | +42.0 |
| CHARIOT NO STATIC JOB | 57 | 57 | 36 | 1.00 | -2748 | -76.3 |
| REDIRECT WEIGHED | 35 | 35 | 35 | 0.97 | +2301 | +65.7 |
| LONE WIZARD KEPT IN | 34 | 34 | 34 | 0.94 | +2648 | +77.9 |
| PLAN LEADS | 74 | 74 | 33 | 0.92 | +2129 | +64.5 |
| LONE WIZARD HOLDS BACK | 67 | 67 | 30 | 0.83 | -3083 | -102.8 |
| KILLS COUNT | 135 | 125 | 29 | 0.81 | +820 | +28.3 |
| CHARGE NOW WEIGHED | 26 | 26 | 26 | 0.72 | +1926 | +74.1 |
| FRIENDS SHOTS CHECKED | 26 | 26 | 26 | 0.72 | +1566 | +60.2 |
| SCOUT WAITS | 26 | 26 | 26 | 0.72 | +0 | +0.0 |
| CASTING BLOCK | 27 | 26 | 23 | 0.64 | +1395 | +60.7 |
| SHOOTERS IN TWO RANKS | 23 | 23 | 23 | 0.64 | +53 | +2.3 |
| MAKE SURE TOGETHER | 39 | 37 | 20 | 0.56 | +703 | +35.1 |
| SHOT REPLANNED | 20 | 20 | 20 | 0.56 | +0 | +0.0 |
| CAST JOB | 35 | 33 | 19 | 0.53 | +555 | +29.2 |
| CASTER AWAY FROM SCREEN | 19 | 19 | 19 | 0.53 | +0 | +0.0 |
| WHOLE FIGHT GAIN | 32 | 27 | 18 | 0.50 | +968 | +53.8 |
| WEARS DOWN | 79 | 78 | 17 | 0.47 | +631 | +37.1 |
| CASTS FROM BEHIND | 14 | 14 | 14 | 0.39 | +0 | +0.0 |
| WHO HITS BACK | 14 | 14 | 14 | 0.39 | -615 | -44.0 |
| STUCK PIVOT | 13 | 13 | 13 | 0.36 | +0 | +0.0 |
| MODEL FACING | 11 | 11 | 11 | 0.31 | +5434 | +494.0 |
| CHAFF PASSED | 10 | 10 | 10 | 0.28 | -21 | -2.1 |
| OPENS UP | 18 | 18 | 10 | 0.28 | +376 | +37.6 |
| SURE CHARGE BEATS ADVANCE | 9 | 9 | 9 | 0.25 | -463 | -51.5 |
| OVERRUNS AWAY | 33 | 31 | 8 | 0.22 | +379 | +47.3 |
| SHORT GUN FORWARD | 8 | 8 | 8 | 0.22 | +0 | +0.0 |
| BEST PRIZE | 7 | 7 | 7 | 0.19 | -281 | -40.1 |
| HUNT ADVANCE | 9 | 9 | 7 | 0.19 | +276 | +39.4 |
| MISSILES NEXT TURN | 310 | 152 | 7 | 0.19 | +108 | +15.4 |
| MOVES UNITS SPELL | 7 | 7 | 7 | 0.19 | +186 | +26.5 |
| PURSUES BIG PREY | 7 | 7 | 7 | 0.19 | -254 | -36.3 |
| BACKUP TARGETS | 72 | 31 | 6 | 0.17 | +52 | +8.7 |
| RAIDS THE BAGGAGE NEXT TURN | 5 | 5 | 5 | 0.14 | +353 | +70.6 |
| RESTRAINS TO SHOOT | 5 | 5 | 5 | 0.14 | +136 | +27.1 |
| FIRE AND FLEE | 4 | 4 | 4 | 0.11 | +38 | +9.4 |
| JOINT CHARGE PLAN | 5 | 5 | 4 | 0.11 | +104 | +26.1 |
| BLOCKED CHARGE SKIPPED | 3 | 3 | 3 | 0.08 | +0 | +0.0 |
| BOMBING RUN | 3 | 3 | 3 | 0.08 | +122 | +40.5 |
| ELIXIR WORTH | 3 | 3 | 3 | 0.08 | +14 | +4.8 |
| FOCUS FIRE | 3 | 3 | 3 | 0.08 | +111 | +37.0 |
| WHOLE FIGHT | 20 | 19 | 3 | 0.08 | +783 | +260.9 |
| BOUND ASSAILMENT | 2 | 2 | 2 | 0.06 | +0 | +0.2 |
| CONTINUE AHEAD WEIGHED | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| NEEDED THERE | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| PERIAPT WORTH | 2 | 2 | 2 | 0.06 | +245 | +122.7 |
| TWO OR MORE ARRIVE | 33 | 33 | 2 | 0.06 | +43 | +21.4 |
| EDGE GIVE GROUND | 10 | 10 | 1 | 0.03 | +4 | +3.9 |
| NO RALLY LEFT | 1 | 1 | 1 | 0.03 | +5 | +5.1 |
| RAIDS THE BAGGAGE | 1 | 1 | 1 | 0.03 | +210 | +210.3 |
| STOPS | 1 | 1 | 1 | 0.03 | +30 | +30.4 |
| SUPPORT JOB KEPT | 1 | 1 | 1 | 0.03 | +69 | +69.3 |
| ALREADY CARRIED | 1 | not checked | - | - | - | - |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| BLOCKED WHEEL | 41 | not checked | - | - | - | - |
| CANNON PLAN MISSED | 23 | 23 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 27 | trace | - | - | - | - |
| CATCH FLIERS | 3 | not checked | - | - | - | - |
| CHEAP HELPER | 12 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 29 | not checked | - | - | - | - |
| ENGINEER BY LORE | 2 | 2 | 0 | 0.00 | - | - |
| FACES THE THREAT | 84 | not checked | - | - | - | - |
| FIGHT LIFT | 4 | not checked | - | - | - | - |
| GIVES UP | 90 | 86 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 57 | 56 | 0 | 0.00 | - | - |
| GROUND FLIERS | 2 | not checked | - | - | - | - |
| HELPER ALREADY ASKED | 4 | not checked | - | - | - | - |
| HELPER UNSEEN | 24 | 21 | 0 | 0.00 | - | - |
| HUNT DROPPED | 4 | trace | - | - | - | - |
| HUNT KEPT | 4 | trace | - | - | - | - |
| HUNT RESULT | 7 | trace | - | - | - | - |
| HUNT THE GUNS | 7 | trace | - | - | - | - |
| KEEPS ITS PREY | 18 | 17 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 24 | not checked | - | - | - | - |
| MANOEUVRE | 6 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 12 | trace | - | - | - | - |
| MISSILES IN THE MOVE | 223 | not checked | - | - | - | - |
| MOVE AND CAST | 8 | not checked | - | - | - | - |
| MOVE SPELL IN RANGE | 4 | 1 | 0 | 0.00 | - | - |
| MOVE SPELL NOT WORTH | 1 | not checked | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 17 | trace | - | - | - | - |
| MOVE SPELL SPOT | 14 | not checked | - | - | - | - |
| NOT NEEDED | 25 | 24 | 0 | 0.00 | - | - |
| NOT TURNED | 732 | 732 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 45 | not checked | - | - | - | - |
| OPENS A LANE | 6 | 3 | 0 | 0.00 | - | - |
| PATHS CROSS | 188 | not checked | - | - | - | - |
| PLAN RESULT | 2777 | trace | - | - | - | - |
| SAFER THAN THE JOB | 61 | not checked | - | - | - | - |
| SCOUT SPOT | 23 | 23 | 0 | 0.00 | - | - |
| SEARCH SPOT | 55 | not checked | - | - | - | - |
| SELF MOVE SPELL | 22 | not checked | - | - | - | - |
| SHOTS IN THE MOVE | 822 | not checked | - | - | - | - |
| SPELL CATCH ODDS | 2 | not checked | - | - | - | - |
| SPELL SETS UP CHARGE | 3 | not checked | - | - | - | - |
| SPELL WORTH | 94 | not checked | - | - | - | - |
| STANDS TO CAST | 1 | not checked | - | - | - | - |
| THROUGH LINE OF FIRE | 31 | not checked | - | - | - | - |
| TURN WORTH | 36 | 34 | 0 | 0.00 | - | - |

### Plans: bg-off-789c37f-p1

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 12.6 | 16% | 627 | 370 | 59% |
| Mine | charge | 2.6 | 61% | 320 | 237 | 74% |
| Mine | close in | 4.6 | 24% | 338 | 183 | 54% |
| Mine | hold | 4.0 | 44% | 200 | 0 | 0% |
| Mine | join | 0.5 | 94% | 15 | 0 | 0% |
| Mine | shoot | 8.5 | 61% | 366 | 657 | 179% |
| Mine | support | 4.9 | 91% | 244 | 0 | 0% |
| Opponent | advance | 13.9 | 22% | 718 | 462 | 64% |
| Opponent | charge | 4.5 | 61% | 516 | 451 | 87% |
| Opponent | close in | 6.1 | 26% | 402 | 146 | 36% |
| Opponent | hold | 3.8 | 42% | 248 | 0 | 0% |
| Opponent | join | 0.9 | 91% | 37 | 0 | 0% |
| Opponent | shoot | 3.6 | 65% | 95 | 298 | 315% |
| Opponent | support | 6.6 | 91% | 294 | 0 | 0% |

### Packages: hunt the guns, bg-off-789c37f-p1

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 40 |
| Opponent | 0.2 | 7 | 0 | 0% | 0% | 0% | - | 411 | 0 | 0% | 97 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 318 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 71 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 130 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 378 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Tomb Kings of Khemri | 0.5 | 3 | 0 | 0% | 0% | 0% | - | 232 | 0 | 0% | 55 |
| Vampire Counts | 0.1 | 1 | 0 | 0% | 0% | 0% | - | 569 | 0 | 0% | 89 |
| Warriors of Chaos | 0.2 | 2 | 0 | 0% | 0% | 0% | - | 642 | 0 | 0% | 96 |
| Wood Elf Realms | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 329 | 0 | 0% | 42 |

### Deployment: positions vs output by unit type: bg-off-789c37f-p1

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 3 | 0 (3) | 0 | 0 | 100 | 67% | 5.0 | 0 (1) | 0 (1) | - | - | 0 (2) |
| Mine | Chaff | 45 | 39 (45) | 4 | 34 | 56 | 42% | 2.9 | 63 (16) | 7 (8) | 29 (21) | 54 (30) | 9 (15) |
| Mine | Character | 124 | 53 (124) | 53 | 0 | 42 | 18% | 2.4 | 77 (30) | 56 (62) | 5 (8) | 62 (60) | 57 (40) |
| Mine | Clean-up | 20 | 58 (20) | 23 | 35 | 17 | 25% | 3.3 | 35 (10) | 94 (8) | 38 (2) | 69 (11) | 44 (9) |
| Mine | Fast | 1 | 0 (1) | 0 | 0 | 100 | 0% | 2.0 | - | 0 (1) | - | - | 0 (1) |
| Mine | Fast Hammer | 40 | 30 (40) | 22 | 8 | 61 | 25% | 2.5 | 37 (21) | 36 (6) | 15 (13) | 33 (30) | 23 (10) |
| Mine | Fragile | 5 | 14 (5) | 14 | 0 | 40 | 20% | 3.0 | - | 14 (5) | - | 0 (1) | 17 (4) |
| Mine | Hammer | 56 | 30 (56) | 17 | 13 | 44 | 20% | 2.3 | 41 (10) | 31 (36) | 15 (10) | 30 (37) | 30 (19) |
| Mine | Holder | 26 | 64 (26) | 11 | 53 | 23 | 38% | 3.6 | 56 (8) | 78 (10) | 59 (7) | 48 (11) | 82 (14) |
| Mine | Shooter | 45 | 82 (45) | 20 | 63 | 39 | 0% | 1.9 | 67 (7) | 79 (31) | 117 (7) | 88 (27) | 74 (18) |
| Mine | Support | 5 | 0 (5) | 0 | 0 | 42 | 40% | 2.0 | - | 0 (2) | 0 (3) | 0 (1) | 0 (4) |
| Mine | War machine | 56 | 53 (56) | 53 | 0 | 30 | 2% | 1.4 | 73 (13) | 43 (38) | 79 (5) | 14 (10) | 62 (46) |
| Mine | Wizard | 22 | 17 (22) | 17 | 0 | 36 | 9% | 2.5 | 17 (8) | 43 (6) | 0 (3) | 28 (4) | 20 (13) |
| Opponent | Blocker | 1 | 58 (1) | 58 | 0 | 0 | 100% | - | 58 (1) | - | - | 58 (1) | - |
| Opponent | Chaff | 81 | 46 (81) | 7 | 39 | 47 | 31% | 2.8 | 53 (29) | 50 (21) | 37 (31) | 55 (56) | 26 (25) |
| Opponent | Character | 113 | 50 (113) | 50 | 0 | 35 | 19% | 2.2 | 66 (42) | 41 (54) | 66 (8) | 57 (71) | 46 (33) |
| Opponent | Clean-up | 12 | 39 (12) | 28 | 10 | 48 | 8% | 3.0 | 13 (5) | 59 (7) | - | 32 (9) | 60 (3) |
| Opponent | Early | 1 | 0 (1) | 0 | 0 | 0 | 0% | 6.0 | - | 0 (1) | - | 0 (1) | - |
| Opponent | Fast Hammer | 53 | 60 (53) | 39 | 21 | 38 | 36% | 2.9 | 52 (23) | 53 (15) | 84 (15) | 66 (38) | 46 (15) |
| Opponent | Fragile | 9 | 25 (9) | 25 | 0 | 57 | 33% | 2.7 | - | 45 (5) | 0 (4) | 0 (6) | 86 (3) |
| Opponent | Hammer | 63 | 47 (63) | 34 | 13 | 48 | 30% | 2.7 | 13 (20) | 62 (38) | 30 (5) | 40 (37) | 57 (26) |
| Opponent | Holder | 35 | 62 (35) | 8 | 54 | 17 | 40% | 3.8 | 44 (6) | 75 (22) | 36 (7) | 77 (15) | 50 (20) |
| Opponent | Shooter | 31 | 40 (31) | 9 | 32 | 46 | 6% | 1.6 | 32 (7) | 50 (19) | 14 (5) | 50 (17) | 28 (14) |
| Opponent | Support | 2 | 0 (2) | 0 | 0 | 50 | 50% | 6.0 | 0 (2) | - | - | 0 (1) | 0 (1) |
| Opponent | War machine | 13 | 98 (13) | 98 | 0 | 33 | 23% | 1.2 | 132 (3) | 107 (7) | 41 (3) | 61 (2) | 104 (11) |
| Opponent | Wizard | 24 | 14 (24) | 14 | 0 | 28 | 12% | 2.3 | 32 (8) | 0 (7) | 8 (7) | 18 (12) | 8 (10) |

### Charged fights: bg-off-789c37f-p1

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 5 | 197 | 0 | 0.6 | 1.0 | 0 | 63 | -63 | 0 of 3 | 0 of 3 | - | -63 |
| Mine | Chaos Dwarfs | 3 | 135 | 982 | 2.7 | 1.1 | 368 | 12 | +356 | 6 of 8 | 5 of 8 | -95 | +421 |
| Mine | Dwarfen Mountain Holds | 4 | 303 | 146 | 1.0 | 1.0 | 146 | 88 | +59 | 1 of 4 | 0 of 4 | - | +59 |
| Mine | Empire of Man | 5 | 526 | 120 | 1.2 | 1.2 | 100 | 49 | +51 | 0 of 6 | 3 of 6 | -104 | +82 |
| Mine | Grand Cathay | 4 | 395 | 378 | 2.8 | 1.1 | 138 | 38 | +99 | 7 of 11 | 4 of 11 | +470 | +62 |
| Mine | High Elf Realms | 4 | 278 | 468 | 4.0 | 1.1 | 117 | 48 | +69 | 6 of 16 | 12 of 16 | +251 | +57 |
| Mine | Kingdom of Bretonnia | 1 | 147 | 1007 | 7.0 | 1.6 | 144 | 0 | +144 | 2 of 7 | 3 of 7 | +180 | +116 |
| Mine | Lizardmen | 1 | 66 | 0 | 4.0 | 1.0 | 0 | 56 | -56 | 1 of 4 | 1 of 4 | - | -56 |
| Mine | Ogre Kingdoms | 1 | 70 | 66 | 2.0 | 1.0 | 33 | 17 | +16 | 1 of 2 | 0 of 2 | - | +16 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 415 | 6.0 | 1.0 | 69 | 44 | +26 | 2 of 6 | 3 of 6 | - | +26 |
| Mine | Skaven | 2 | 70 | 259 | 2.5 | 1.0 | 104 | 0 | +104 | 1 of 5 | 3 of 5 | - | +104 |
| Mine | Tomb Kings of Khemri | 2 | 113 | 690 | 4.0 | 1.2 | 172 | 0 | +172 | 2 of 8 | 5 of 8 | +160 | +176 |
| Mine | Vampire Counts | 2 | 58 | 132 | 4.0 | 1.0 | 33 | 12 | +21 | 1 of 8 | 4 of 8 | - | +21 |
| Mine | Warriors of Chaos | 1 | 0 | 91 | 2.0 | 1.0 | 46 | 0 | +46 | 0 of 2 | 1 of 2 | - | +46 |
| **Mine** | all armies | 36 | 241 | 313 | 2.5 | 1.1 | 125 | 30 | +95 | 30 of 90 | 44 of 90 | +154 | +88 |
| Opponent | Beastmen Brayherds | 1 | 0 | 65 | 4.0 | 1.2 | 16 | 8 | +9 | 2 of 4 | 4 of 4 | +65 | -10 |
| Opponent | Dwarfen Mountain Holds | 1 | 955 | 0 | 1.0 | 2.0 | 0 | 0 | +0 | 0 of 1 | 1 of 1 | +0 | - |
| Opponent | Empire of Man | 1 | 65 | 289 | 1.0 | 1.0 | 289 | 0 | +289 | 1 of 1 | 1 of 1 | - | +289 |
| Opponent | Grand Cathay | 1 | 355 | 185 | 1.0 | 1.0 | 185 | 217 | -32 | 1 of 1 | 0 of 1 | - | -32 |
| Opponent | High Elf Realms | 2 | 62 | 748 | 2.5 | 1.2 | 299 | 0 | +299 | 2 of 5 | 5 of 5 | +416 | +270 |
| Opponent | Lizardmen | 1 | 125 | 825 | 4.0 | 1.2 | 206 | 0 | +206 | 3 of 4 | 4 of 4 | +0 | +275 |
| Opponent | Ogre Kingdoms | 2 | 28 | 457 | 4.0 | 1.1 | 114 | 4 | +110 | 2 of 8 | 5 of 8 | -34 | +131 |
| Opponent | Orc & Goblin Tribes | 2 | 148 | 406 | 4.0 | 1.0 | 102 | 7 | +95 | 4 of 8 | 5 of 8 | - | +95 |
| Opponent | Skaven | 2 | 0 | 0 | 1.0 | 1.0 | 0 | 32 | -32 | 2 of 2 | 0 of 2 | - | -32 |
| Opponent | Tomb Kings of Khemri | 4 | 40 | 964 | 5.8 | 1.3 | 168 | 9 | +159 | 12 of 23 | 16 of 23 | +96 | +176 |
| Opponent | Vampire Counts | 6 | 0 | 312 | 3.5 | 1.5 | 89 | 60 | +29 | 8 of 21 | 16 of 21 | +70 | +4 |
| Opponent | Warriors of Chaos | 7 | 7 | 425 | 3.3 | 1.1 | 129 | 18 | +112 | 10 of 23 | 17 of 23 | +127 | +110 |
| Opponent | Wood Elf Realms | 6 | 84 | 553 | 4.8 | 1.3 | 114 | 27 | +87 | 15 of 29 | 17 of 29 | +153 | +66 |
| **Opponent** | all armies | 36 | 75 | 461 | 3.6 | 1.2 | 128 | 24 | +104 | 62 of 130 | 91 of 130 | +104 | +104 |

### Effective charges: bg-off-789c37f-p1

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 3 | 0 | 0 | 0 | 2 (net -68) | 0 | 0 | 1 | 0% (0 of 2) |
| Mine | Chaos Dwarfs | 8 | 3 (net +477) | 0 | 0 | 1 (net -95) | 1 (net +0) | 2 (net +710) | 1 | 0% (0 of 7) |
| Mine | Dwarfen Mountain Holds | 4 | 1 (net +194) | 0 | 1 (net +0) | 1 (net +41) | 0 | 1 (net +0) | 0 | 25% (1 of 4) |
| Mine | Empire of Man | 6 | 2 (net -52) | 0 | 1 (net +258) | 1 (net -189) | 0 | 2 (net +171) | 0 | 17% (1 of 6) |
| Mine | Grand Cathay | 11 | 1 (net +0) | 0 | 4 (net +1) | 1 (net +540) | 1 (net -217) | 3 (net +216) | 1 | 40% (4 of 10) |
| Mine | High Elf Realms | 16 | 1 (net +0) | 0 | 3 (net +83) | 3 (net +37) | 4 (net +95) | 4 (net +247) | 1 | 20% (3 of 15) |
| Mine | Kingdom of Bretonnia | 7 | 2 (net +210) | 0 | 0 | 0 | 3 (net +63) | 2 (net +199) | 0 | 0% (0 of 7) |
| Mine | Lizardmen | 4 | 1 (net +0) | 0 | 0 | 1 (net +0) | 0 | 1 (net +0) | 1 | 0% (0 of 3) |
| Mine | Orc & Goblin Tribes | 6 | 0 | 0 | 0 | 0 | 2 (net +0) | 0 | 4 | 0% (0 of 2) |
| Mine | Skaven | 5 | 3 (net +0) | 0 | 0 | 0 | 0 | 2 (net +259) | 0 | 0% (0 of 5) |
| Mine | Tomb Kings of Khemri | 8 | 0 | 0 | 0 | 1 (net +116) | 2 (net +160) | 3 (net +268) | 2 | 0% (0 of 6) |
| Mine | Vampire Counts | 8 | 1 (net -50) | 0 | 2 (net -22) | 1 (net +0) | 2 (net +132) | 2 (net +0) | 0 | 25% (2 of 8) |
| Mine | Warriors of Chaos | 2 | 0 | 0 | 0 | 0 | 0 | 1 (net +91) | 1 | 0% (0 of 1) |
| Opponent | Beastmen Brayherds | 4 | 0 | 0 | 0 | 1 (net +65) | 0 | 3 (net -10) | 0 | 0% (0 of 4) |
| Opponent | Dwarfen Mountain Holds | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +0) | 0 | 0% (0 of 1) |
| Opponent | Empire of Man | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +289) | 0 | 0% (0 of 1) |
| Opponent | Grand Cathay | 1 | 1 (net -32) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 1) |
| Opponent | High Elf Realms | 5 | 1 (net +704) | 0 | 0 | 2 (net +322) | 1 (net +150) | 0 | 1 | 0% (0 of 4) |
| Opponent | Lizardmen | 4 | 0 | 0 | 0 | 0 | 1 (net +0) | 1 (net +0) | 2 | 0% (0 of 2) |
| Opponent | Ogre Kingdoms | 8 | 0 | 0 | 1 (net +0) | 1 (net -34) | 2 (net +71) | 2 (net +386) | 2 | 17% (1 of 6) |
| Opponent | Orc & Goblin Tribes | 8 | 0 | 0 | 1 (net +310) | 0 | 0 | 0 | 7 | 100% (1 of 1) |
| Opponent | Skaven | 2 | 1 (net +0) | 0 | 0 | 1 (net -65) | 0 | 0 | 0 | 0% (0 of 2) |
| Opponent | Tomb Kings of Khemri | 23 | 1 (net +0) | 1 (net +0) | 4 (net +181) | 7 (net +122) | 0 | 7 (net +214) | 3 | 20% (4 of 20) |
| Opponent | Vampire Counts | 21 | 2 (net -50) | 0 | 6 (net +19) | 3 (net +0) | 2 (net +320) | 6 (net -8) | 2 | 32% (6 of 19) |
| Opponent | Warriors of Chaos | 23 | 1 (net +499) | 0 | 1 (net +0) | 6 (net +174) | 3 (net +98) | 7 (net +145) | 5 | 6% (1 of 18) |
| Opponent | Wood Elf Realms | 29 | 5 (net -26) | 0 | 4 (net +207) | 2 (net +32) | 2 (net +32) | 11 (net +138) | 5 | 17% (4 of 24) |

### Charged fights, damage counted: bg-off-789c37f-p1

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 15 | 212 | 218 | +126 | 177 | 60 | +117 | +55.3 |
| Mine | Effective (55-75%) | 11 | 194 | 206 | +43 | 84 | 37 | +46 | +24.0 |
| Mine | 76-89% | 12 | 199 | 172 | +32 | 112 | 73 | +39 | +19.8 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 23 | 273 | 193 | +226 | 252 | 14 | +239 | +87.4 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 15 | 430 | 96 | +62 | 122 | 24 | +98 | +22.9 |
| Mine | No odds | 14 | 245 | 176 | -26 | 73 | 86 | -13 | -5.1 |
| Mine | All fights | 90 | 265 | 177 | +95 | 151 | 45 | +106 | +40.0 |
| Opponent | Long shot (under 50%) | 12 | 320 | 283 | +78 | 205 | 134 | +71 | +22.3 |
| Opponent | 50-54% | 1 | 195 | 251 | +0 | 126 | 0 | +126 | +64.4 |
| Opponent | Effective (55-75%) | 17 | 365 | 235 | +116 | 183 | 44 | +138 | +37.8 |
| Opponent | 76-89% | 23 | 259 | 191 | +112 | 142 | 34 | +108 | +41.8 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 39 | 245 | 200 | +128 | 165 | 30 | +135 | +54.9 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 11 | 356 | 89 | +117 | 126 | 13 | +113 | +31.7 |
| Opponent | No odds | 27 | 302 | 257 | +65 | 130 | 32 | +97 | +32.2 |
| Opponent | All fights | 130 | 291 | 214 | +104 | 156 | 41 | +115 | +39.5 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| bg-off-789c37f-p1 | move | 473 | 102 (22%) | 74 (16%) | 59 (12%) | 312 (66%) |
| bg-off-789c37f-p1 | objective | 391 | 60 (15%) | 36 (9%) | 49 (13%) | 282 (72%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0102, L0118, L0135, L2531, L2730 |
| Charmed Shield | Opponent | L0524, L1224, L1527, L1625, L2025, L2127, L2934 |
| Clockwork Compass | Mine | L1224 |
| Clockwork Compass | Opponent | L0612 |
| Elixir of Power | Mine | L1114, L1131, L1923 |
| Elixir of Power | Opponent | L0319, L1319 |
| Fistful of Laurels | Mine | L1823 |
| Fistful of Laurels | Opponent | L0118, L0218 |
| Horn of the Wild Hunt | Opponent | L0733 |
| Invocation of Nehek | Mine | L2531, L2730 |
| Invocation of Nehek | Opponent | L0524, L1224, L1527, L1625, L2025, L2127 |
| Opal Amulet | Mine | L1431 |
| Opal Amulet | Opponent | L1114 |
| Periapt of Soul Exchange | Mine | L2025, L2127 |
| Periapt of Soul Exchange | Opponent | L0421, L1021 |
| Ring of Doom | Mine | L0218, L0235, L1114, L1131, L1224, L1527 |
| Ring of Doom | Opponent | L0102, L0612, L0733, L1131, L1431, L2231, L2531 |
| Ring of Jet | Mine | L1021, L1114, L1131, L1224 |
| Ring of Jet | Opponent | L0612 |
| Standard of the Fell Warrior | Mine | L1319, L1335 |
| Standard of the Fell Warrior | Opponent | L0913 |
| Storm Daemon (Renegade 2.0) | Mine | L2127 |
| Storm Daemon (Renegade 2.0) | Opponent | L0421, L1021 |
| Twice-Blessed Armour | Mine | L0717, L0733, L1021 |
| Witch Hunter's Ward | Mine | L0717, L0733, L0823 |
| Witch Hunter's Ward | Opponent | L0508 |

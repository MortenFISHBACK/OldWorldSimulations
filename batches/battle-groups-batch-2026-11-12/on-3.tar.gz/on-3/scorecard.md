# Doctrine scorecard: bg-on-789c37f-p3

### Scorecard: bg-on-789c37f-p3

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0110 | 2 | 1 | Mine | - | - | 1 | 3 | 2 | 0 | 0 | 0 | 322 |
| L0110 | 2 | 1 | Opponent | - | - | 2 | 1 | 0 | 0 | 0 | 0 | 330 |
| L0126 | 6 | 1 | Mine | no | 6 | - | 0 | 2 | 0 | 0 | 0 | 387 |
| L0126 | 6 | 1 | Opponent | no | 9 | 2 | 2 | 3 | 1 | 0 | 0 | 0 |
| L0210 | 6 | 1 | Mine | no | 4 | - | 0 | 4 | 0 | 0 | 0 | 0 |
| L0210 | 6 | 1 | Opponent | no | 3 | 3 | 1 | 1 | 0 | 0 | 0 | 330 |
| L0226 | 4 | 1 | Mine | no | 0 | - | 0 | 2 | 1 | 0 | 0 | 306 |
| L0226 | 4 | 1 | Opponent | no | 6 | 2 | 4 | 3 | 0 | 0 | 0 | 0 |
| L0311 | 5 | 1 | Mine | no | - | 2 | 0 | 1 | 0 | 0 | 0 | 760 |
| L0311 | 5 | 1 | Opponent | yes | - | - | 1 | 1 | 1 | 0 | 0 | 330 |
| L0327 | 3 | 1 | Mine | no | 5 | 6 | 2 | 0 | 0 | 0 | 0 | 760 |
| L0327 | 3 | 1 | Opponent | no | 0 | 2 | 3 | 4 | 0 | 0 | 0 | 0 |
| L0413 | 5 | 1 | Mine | yes | - | 2 | 3 | 2 | 0 | 0 | 0 | 0 |
| L0413 | 5 | 1 | Opponent | no | - | - | 2 | 2 | 1 | 0 | 0 | 317 |
| L0429 | 3 | 1 | Mine | yes | 13 | 2 | 4 | 1 | 1 | 0 | 0 | 0 |
| L0429 | 3 | 1 | Opponent | no | 4 | 2 | 2 | 0 | 1 | 0 | 0 | 170 |
| L0516 | 6 | 1 | Mine | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 475 |
| L0516 | 6 | 1 | Opponent | no | 2 | 2 | 3 | 2 | 2 | 0 | 0 | 280 |
| L0533 | 5 | 1 | Mine | no | - | 6 | 0 | 2 | 0 | 0 | 0 | 548 |
| L0533 | 5 | 1 | Opponent | yes | - | 6 | 0 | 7 | 0 | 0 | 0 | 0 |
| L0620 | 2 | 1 | Mine | - | - | 3 | 5 | 1 | 0 | 0 | 0 | 615 |
| L0620 | 2 | 1 | Opponent | - | - | - | 1 | 4 | 0 | 0 | 0 | 95 |
| L0709 | 1 | 1 | Mine | yes | 0 | 2 | 2 | 1 | 1 | 0 | 0 | 558 |
| L0709 | 1 | 1 | Opponent | no | 0 | 3 | 1 | 0 | 0 | 0 | 0 | 420 |
| L0725 | 5 | 1 | Mine | no | - | - | 1 | 2 | 0 | 0 | 0 | 375 |
| L0725 | 5 | 1 | Opponent | yes | - | 2 | 3 | 4 | 0 | 0 | 0 | 75 |
| L0815 | 5 | 1 | Mine | no | - | 5 | 1 | 1 | 0 | 0 | 0 | 762 |
| L0815 | 5 | 1 | Opponent | yes | - | 3 | 3 | 2 | 1 | 0 | 0 | 0 |
| L0831 | 3 | 1 | Mine | yes | 3 | 2 | 0 | 1 | 0 | 0 | 0 | 605 |
| L0831 | 3 | 1 | Opponent | no | 4 | - | 1 | 3 | 2 | 0 | 0 | 340 |
| L0922 | 4 | 1 | Mine | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 596 |
| L0922 | 4 | 1 | Opponent | no | 1 | 3 | 3 | 1 | 2 | 0 | 0 | 0 |
| L1013 | 5 | 1 | Mine | yes | - | 3 | 1 | 0 | 0 | 0 | 0 | 330 |
| L1013 | 5 | 1 | Opponent | yes | - | 3 | 1 | 1 | 1 | 0 | 0 | 387 |
| L1030 | 4 | 1 | Mine | no | 5 | 5 | 1 | 1 | 0 | 0 | 0 | 330 |
| L1030 | 4 | 1 | Opponent | no | 0 | 2 | 1 | 1 | 1 | 0 | 0 | 0 |
| L1122 | 6 | 1 | Mine | no | 7 | 2 | 5 | 0 | 1 | 0 | 0 | 526 |
| L1122 | 6 | 1 | Opponent | no | 6 | 2 | 3 | 0 | 0 | 0 | 0 | 145 |
| L1216 | 4 | 1 | Mine | no | 2 | 2 | 3 | 0 | 0 | 0 | 0 | 330 |
| L1216 | 4 | 1 | Opponent | no | 5 | 5 | 3 | 2 | 0 | 0 | 0 | 260 |
| L1232 | 2 | 1 | Mine | - | - | 6 | 2 | 0 | 0 | 0 | 0 | 330 |
| L1232 | 2 | 1 | Opponent | - | - | 2 | 2 | 5 | 0 | 0 | 0 | 170 |
| L1327 | 1 | 1 | Mine | no | 4 | 3 | 2 | 0 | 0 | 0 | 0 | 140 |
| L1327 | 1 | 1 | Opponent | no | 2 | 2 | 3 | 3 | 0 | 0 | 0 | 50 |
| L1422 | 6 | 1 | Mine | no | 1 | 2 | 5 | 0 | 1 | 0 | 0 | 0 |
| L1422 | 6 | 1 | Opponent | no | 0 | 1 | 2 | 0 | 0 | 0 | 0 | 225 |
| L1519 | 1 | 1 | Mine | no | 3 | 3 | 3 | 1 | 0 | 0 | 0 | 0 |
| L1519 | 1 | 1 | Opponent | no | 0 | 2 | 10 | 0 | 1 | 0 | 0 | 543 |
| L1535 | 5 | 1 | Mine | yes | - | 2 | 0 | 0 | 1 | 0 | 0 | 0 |
| L1535 | 5 | 1 | Opponent | yes | - | 3 | 4 | 1 | 0 | 0 | 0 | 907 |
| L1633 | 1 | 1 | Mine | no | 2 | 2 | 4 | 0 | 0 | 0 | 0 | 200 |
| L1633 | 1 | 1 | Opponent | no | 0 | 1 | 5 | 4 | 0 | 0 | 0 | 144 |
| L1731 | 3 | 1 | Mine | no | 2 | 5 | 3 | 0 | 0 | 0 | 0 | 0 |
| L1731 | 3 | 1 | Opponent | no | 4 | 3 | 4 | 0 | 1 | 0 | 0 | 290 |
| L1831 | 1 | 1 | Mine | no | 0 | 3 | 6 | 1 | 1 | 0 | 0 | 0 |
| L1831 | 1 | 1 | Opponent | no | 1 | 3 | 4 | 0 | 3 | 0 | 0 | 365 |
| L1932 | 6 | 1 | Mine | no | 2 | 2 | 7 | 0 | 1 | 0 | 0 | 255 |
| L1932 | 6 | 1 | Opponent | no | 3 | 2 | 5 | 2 | 0 | 0 | 0 | 340 |
| L2033 | 5 | 1 | Mine | yes | - | - | 1 | 5 | 0 | 0 | 0 | 210 |
| L2033 | 5 | 1 | Opponent | yes | - | 2 | 1 | 4 | 0 | 0 | 0 | 0 |
| L2223 | 3 | 1 | Mine | no | 1 | 3 | 6 | 1 | 0 | 0 | 0 | 242 |
| L2223 | 3 | 1 | Opponent | no | 7 | 1 | 5 | 0 | 0 | 0 | 0 | 0 |
| L2327 | 5 | 1 | Mine | yes | - | 2 | 2 | 0 | 1 | 0 | 0 | 185 |
| L2327 | 5 | 1 | Opponent | yes | - | 2 | 9 | 3 | 0 | 0 | 0 | 0 |
| L2433 | 3 | 1 | Mine | no | 7 | 3 | 5 | 1 | 0 | 0 | 0 | 0 |
| L2433 | 3 | 1 | Opponent | no | 0 | 1 | 4 | 1 | 0 | 0 | 0 | 380 |
| L2630 | 2 | 1 | Mine | - | - | 2 | 4 | 2 | 0 | 0 | 0 | 0 |
| L2630 | 2 | 1 | Opponent | - | - | 2 | 5 | 1 | 1 | 0 | 0 | 312 |
| L2832 | 6 | 1 | Mine | no | 1 | - | 0 | 0 | 2 | 0 | 0 | 0 |
| L2832 | 6 | 1 | Opponent | no | 9 | 1 | 3 | 2 | 1 | 0 | 0 | 170 |
| L3133 | 1 | 1 | Mine | yes | 3 | 5 | 0 | 2 | 0 | 0 | 0 | 0 |
| L3133 | 1 | 1 | Opponent | no | 3 | 2 | 4 | 3 | 0 | 0 | 0 | 236 |
| **Average** | | | Mine | 28% | 3.1 | 3.1 | 2.2 | 1.1 | 0.3 | 0.0 | 0.0 | 281.9 |
| **Average** | | | Opponent | 25% | 3.0 | 2.3 | 3.0 | 1.9 | 0.6 | 0.0 | 0.0 | 211.4 |

### KPIs: bg-on-789c37f-p3

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Winner chose to follow up after the loser gave ground |  | 85% (51 of 60); on the table 88% | 100% (54 of 54); on the table 100% | 92% (105 of 114); on the table 94% |
| Winner chose to pursue after the loser fell back in good order |  | 69% (9 of 13); on the table 85% | 93% (14 of 15); on the table 93% | 82% (23 of 28); on the table 89% |
| Winner chose to pursue after the loser fled |  | 67% (28 of 42); on the table 79% | 48% (11 of 23); on the table 52% | 60% (39 of 65); on the table 69% |
| Winner chose to follow up or pursue (all three) |  | 77% (88 of 115); on the table 84% | 86% (79 of 92); on the table 87% | 81% (167 of 207); on the table 86% |
| Magic missiles tried each own turn | 50%+ | 20% (70 of 342) | 22% (42 of 192) | 21% (112 of 534) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 32% (70 of 216) | 29% (42 of 143) | 31% (112 of 359) |
| Points that never fought | lower | 37% (25124 of 68801) | 39% (28038 of 71990) | 38% (53162 of 140791) |
|   infantry points that never fought | lower | 48% (6866 of 14174) | 50% (7181 of 14220) | 49% (14047 of 28394) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 55% (150 of 272) | 60% (171 of 285) | 58% (321 of 557) |
| Bound items with a magic missile used (at least once a game) |  | 88% (22 of 25); 1.3 uses a game | 75% (18 of 24); 1.5 uses a game | 82% (40 of 49); 1.4 uses a game |
| Bound items with another spell used |  | 57% (8 of 14); 0.3 uses a game | 0% (0 of 6); 0.0 uses a game | 40% (8 of 20); 0.1 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 45% (9 of 20); 0.2 uses a game | 21% (3 of 14); 0.1 uses a game | 35% (12 of 34); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 47% (27914 of 59391) | 54% (34628 of 64043) | 51% (62542 of 123434) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 0.8 (10%) | 0.9 (22%) | 1.7 (14%) |
| MARCHED: its unit marched | 2.7 (35%) | 1.6 (39%) | 4.3 (36%) |
| CHARGED: its unit charged | 0.3 (4%) | 0.2 (6%) | 0.6 (5%) |
| IN COMBAT: engaged in combat | 1.7 (23%) | 0.8 (18%) | 2.5 (21%) |
| REAR RANK: in a rear rank | 0.1 (1%) | 0.0 (1%) | 0.1 (1%) |
| FLEEING: fleeing | 0.2 (3%) | 0.0 (0%) | 0.2 (2%) |
| GONE: slain | 1.5 (20%) | 0.6 (13%) | 2.1 (18%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (0%) | 0.1 (1%) | 0.1 (1%) |
| STUPIDITY: Stupidity | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.6 | 1.1 | 1.6 | 3.1 | 0.6 | 1.6 |
| not cast | 4.2 | 1.5 | 4.5 | 11.7 | 2.7 | 19.1 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) | 0.0 (0%) | 1.5 (8%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (1%) | 0.6 (41%) | 0.3 (6%) | 1.7 (14%) | 0.1 (5%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 4.3 (36%) | 0.9 (33%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.6 (5%) | 0.1 (4%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.2 (4%) | 0.2 (15%) | 0.7 (15%) | 2.5 (21%) | 0.6 (21%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.2 (5%) | 0.0 (2%) | 0.2 (4%) | 0.1 (1%) | 0.0 (1%) | 0.0 (0%) |
| FLEEING: fleeing | 0.1 (1%) | 0.1 (7%) | 0.1 (2%) | 0.2 (2%) | 0.1 (3%) | 0.5 (2%) |
| GONE: slain | 1.4 (33%) | 0.2 (11%) | 1.1 (23%) | 2.1 (18%) | 0.2 (9%) | 3.0 (16%) |
| OFF THE TABLE: off the table or not arrived | 0.2 (5%) | 0.2 (11%) | 0.3 (7%) | 0.1 (1%) | 0.1 (4%) | 0.8 (4%) |
| STUPIDITY: Stupidity | 0.1 (2%) | 0.0 (0%) | 0.1 (3%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (3%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.5 (20%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.0 (47%) | 0.2 (13%) | 1.8 (39%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 13.3 (70%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.1 a game | 0.6 a game | 0.8 a game |
| stood (cast and not dispelled) | 50% (14 of 28) | 56% (9 of 16) | 52% (23 of 44) |
| the unit moved after it | 93% (13 of 14) | 100% (9 of 9) | 96% (22 of 23) |
| it charged on its next turn | 0% (0 of 14) | 22% (2 of 9) | 9% (2 of 23) |
| the enemy charged it first | 21% (3 of 14) | 0% (0 of 9) | 13% (3 of 23) |
| it fought by the end of its next turn | 14% (2 of 14) | 0% (0 of 9) | 9% (2 of 23) |
| it moved out of a charge the enemy had planned (not charged first) | 29% (4 of 14) | 0% (0 of 9) | 17% (4 of 23) |
| none of these (no charge, no fight, no charge escaped) | 50% (7 of 14) | 78% (7 of 9) | 61% (14 of 23) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 61% (497 of 811) | 55% (344 of 624) | 59% (841 of 1435) |
|   cavalry | 65% (47 of 72) | 53% (59 of 112) | 58% (106 of 184) |
|   character | 40% (46 of 114) | 22% (26 of 119) | 31% (72 of 233) |
|   chariot | 36% (34 of 94) | 49% (19 of 39) | 40% (53 of 133) |
|   infantry | 55% (123 of 224) | 66% (172 of 261) | 61% (295 of 485) |
|   monster | 44% (14 of 32) | 33% (1 of 3) | 43% (15 of 35) |
|   war machine | 85% (233 of 275) | 74% (67 of 90) | 82% (300 of 365) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 3.1 (35%) | 2.1 (27%) | 5.2 (31%) |
| CHARGED: it charged | 1.0 (11%) | 1.6 (20%) | 2.6 (15%) |
| FLEEING: it fled or was fleeing | 0.1 (1%) | 0.1 (1%) | 0.2 (1%) |
| IN COMBAT: it fought this turn or the last | 0.7 (8%) | 0.8 (10%) | 1.5 (9%) |
| MOVED: a war machine that moved | 0.1 (2%) | 0.1 (1%) | 0.2 (1%) |
| NO TARGET IN RANGE | 0.9 (11%) | 0.9 (11%) | 1.8 (11%) |
| ONLY IN COMBAT: the only targets were in combat | 0.3 (4%) | 0.4 (5%) | 0.7 (4%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.9 (22%) | 1.4 (18%) | 3.3 (20%) |
| SHELTERED: the target was sheltered | 0.2 (2%) | 0.3 (4%) | 0.5 (3%) |
| OTHER BAR | 0.4 (4%) | 0.2 (2%) | 0.6 (4%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 4.3 | 1.5 | 73% | 8.4 pts | 36 pts |
| character | 2.3 | 0.7 | 81% | 4.2 pts | 10 pts |
| chariot | 1.5 | 0.8 | 62% | 18.3 pts | 27 pts |
| infantry | 12.1 | 5.0 | 70% | 10.1 pts | 122 pts |
| monster | 0.4 | 0.1 | 81% | 7.3 pts | 3 pts |
| war machine | 8.6 | 6.9 | 63% | 21.1 pts | 182 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.2 | 5.7 | 5.0 |
| Charges that made contact a game | 3.4 | 4.1 | 3.8 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.08 declared, 0.92 contact (25 units) | 0.95 declared, 0.65 contact (20 units) | 1.02 declared, 0.80 contact (45 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.67 declared, 0.33 contact (3 units) | 1.50 declared, 1.20 contact (10 units) | 1.31 declared, 1.00 contact (13 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.55 declared, 0.45 contact (221 units) | 0.65 declared, 0.46 contact (265 units) | 0.60 declared, 0.46 contact (486 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 56% (43 of 77) | 47% (7 of 15) | 0% (0 of 10) | 49% (50 of 102) |
| Character in a unit | 90% (35 of 39) | 92% (11 of 12) | 62% (5 of 8) | 86% (51 of 59) |
| Character on its own | 74% (28 of 38) | 55% (24 of 44) | 25% (17 of 67) | 46% (69 of 149) |
| Chariot | 73% (8 of 11) | 75% (9 of 12) | - | 74% (17 of 23) |
| Infantry | 61% (43 of 70) | 40% (17 of 42) | 20% (1 of 5) | 52% (61 of 117) |
| Monster | 68% (23 of 34) | 57% (4 of 7) | - | 66% (27 of 41) |
| Monstrous | 80% (8 of 10) | 73% (8 of 11) | - | 76% (16 of 21) |
| War Machines | 65% (28 of 43) | 100% (2 of 2) | - | 67% (30 of 45) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 78% (7 of 9); on the table 78% | 24% (23 of 96) | 41% | 68% (15 of 22) | 100% (6 of 6); 2.8 uses a game | 100% (2 of 2); 0.5 uses a game | 83% (5 of 6); 1.2 uses a game |
| Chaos Dwarfs | 4 | 78% (14 of 18); on the table 89% | 47% (17 of 36) | 41% | 59% (19 of 32) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
| Dwarfen Mountain Holds | 3 | 60% (3 of 5); on the table 60% | - | 73% | 62% (15 of 24) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 6 | 83% (10 of 12); on the table 83% | 27% (8 of 30) | 56% | 63% (37 of 59) | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game | 25% (1 of 4); 0.2 uses a game |
| Grand Cathay | 8 | 82% (18 of 22); on the table 91% | 17% (32 of 192) | 39% | 53% (39 of 74) | 83% (15 of 18); 4.5 uses a game | 0% (0 of 4); 0.0 uses a game | 12% (1 of 8); 0.1 uses a game |
| High Elf Realms | 7 | 67% (14 of 21); on the table 76% | 14% (6 of 42) | 25% | 43% (23 of 54) | 89% (8 of 9); 2.7 uses a game | 42% (5 of 12); 1.0 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 3 | 50% (1 of 2); on the table 50% | - | 47% | 50% (9 of 18) | 0.0 uses a game | 0.0 uses a game | 67% (2 of 3); 0.7 uses a game |
| Lizardmen | 1 | 86% (6 of 7); on the table 86% | 17% (1 of 6) | 19% | 43% (3 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 1 | 0% (0 of 5); on the table 80% | 0% (0 of 6) | 30% | 57% (4 of 7) | 100% (1 of 1); 1.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 2 | 100% (3 of 3); on the table 100% | 17% (2 of 12) | 0% | 69% (11 of 16) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |
| Skaven | 2 | 80% (4 of 5); on the table 80% | 17% (2 of 12) | 54% | 71% (10 of 14) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |
| Tomb Kings of Khemri | 6 | 85% (11 of 13); on the table 85% | 0% (0 of 6) | 24% | 54% (14 of 26) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 8 | 91% (32 of 35); on the table 91% | 20% (11 of 54) | 28% | 46% (21 of 46) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 11 | 86% (38 of 44); on the table 86% | 23% (7 of 30) | 34% | 57% (55 of 96) | 25% (1 of 4); 0.1 uses a game | 0.0 uses a game | 100% (2 of 2); 0.2 uses a game |
| Wood Elf Realms | 6 | 100% (6 of 6); on the table 100% | 25% (3 of 12) | 51% | 74% (46 of 62) | 82% (9 of 11); 5.5 uses a game | 0.0 uses a game | 0% (0 of 5); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (bg-on-789c37f-p3, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 59% (51) | 49% (40) | 54% (91) |
| ...free all their last turn and able to turn (per game) | 0.97 | 0.75 | 1.72 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.17 | 0.17 | 0.33 |
| ...with the charger already in that arc before they moved (per game) | 0.61 | 0.53 | 1.14 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 1.33 | 1.33 | 2.67 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.50 | 0.47 | 0.97 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 11.75 | 10.75 | 22.50 |

### Quality by phase: bg-on-789c37f-p3

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.2 | 3.6 |
| Strategy | Charge objectives carried out (made contact) | 58% (79 of 137) | 54% (83 of 153) |
| Strategy | Shoot objectives carried out (shot that target) | 45% (153 of 341) | 57% (98 of 172) |
| Strategy | Close-in objectives charged next turn | 15% (29 of 195) | 15% (34 of 229) |
| Strategy | Support requests answered (helper made contact too) | 31% (5 of 16) | 55% (6 of 11) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (3 of 3) | 100% (2 of 2) |
| Strategy | Hexes on a unit its side charged or shot that turn | 50% (5 of 10) | 100% (1 of 1) |
| Strategy | Joined characters whose unit fought | 33% (14 of 42) | 25% (10 of 40) |
| Strategy | Lone characters that fought | 76% (71 of 93) | 77% (72 of 94) |
| Movement | Charges halted short of contact | 0.1 | 0.2 |
| Movement | Idle units | 1.1 | 1.9 |
| Movement | Points that never moved of their own | 281.9 | 211.4 |
| Movement | Fights charged into per game | 3.1 | 3.4 |
| Movement | Charges with odds: long shots (under 50%) | 10 of 92, net +144 | 14 of 104, net -15 |
| Movement | Charges with odds: sweet spot (55-75%) | 17 of 92, net +26 | 13 of 104, net +23 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 13 of 92, net +79 | 14 of 104, net +89 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 35 of 92, net +95 | 39 of 104, net +123 |
| Shooting | Shots by shooting units (incl. breath weapons) | 7.9 | 9.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 44% (126 of 286) | 41% (131 of 323) |
| Shooting | Points destroyed by shooting units | 87.8 | 33.2 |
| Shooting | War machine shots | 6.5 | 2.2 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 50% (116 of 233) | 32% (25 of 78) |
| Shooting | Points destroyed by war machines | 43.9 | 23.1 |
| Magic | Magic missiles cast | 1.0 | 0.8 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 51% (19 of 37) | 21% (6 of 28) |
| Magic | Wounds caused by magic missiles | 2.1 | 1.9 |
| Magic | Wounds caused by other spells | 1.7 | 0.6 |
| Magic | Points destroyed by magic (all spells) | 37.0 | 27.2 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.3 / 0.3 / 0.6 / 0.1 | 2.1 / 0.1 / 0.2 / 0.3 |
| Combat | Points destroyed in combat | 379.4 | 344.1 |
| Combat | Points run down | 88.7 | 118.7 |
| Combat | Net points per charged fight, damage counted | +78 | +76 |
| Combat | Net per 100 charger points, damage counted | +26.2 | +27.3 |
| Combat | First round won (charged fights) | 71% | 52% |
| Combat | Net points per charged fight | +73 | +71 |
| Combat | Net points per supported fight / lone fight | +151 / +61 | +145 / +56 |
| Combat | Charged fights on a top-3 enemy unit | 30 of 112 | 56 of 122 |
| Game | Points lost | 633.9 | 716.3 |
| Game | VP from objectives | 587.2 | 494.4 |
| Game | Lone holders (player turns) | 3.1 | 3.0 |

- Mine won / drew / lost: 18 / 4 / 14 of 36 ended games (of 36); mean margin (Mine - Opponent) +172 VP
- The side that went first won 16 of 32 games with a winner
- Points traded per game (both sides' losses): 1350
- Games not ended: 0; findings 0, warnings 1

### Opponent rules: bg-on-789c37f-p3

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.6 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| ARRIVAL HUNT | 0.0 | +0.3 | 0.0 | 0.0 | 0.1 | +0.4 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 2.0 | +0.0 | 0.0 | 6.9 | 0.2 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | 1.0 | +8.9 | 0.0 | 32.8 | 0.5 | +4.5 | 0.0 | 7.1 |
| BEST PREY | 4.7 | +298.8 | 211.4 | 101.1 | 4.2 | +263.5 | 160.9 | 59.0 |
| BEST PRIZE | 0.1 | +0.8 | 5.0 | 21.8 | 0.1 | -2.7 | 0.0 | 0.0 |
| BLOCKED CHARGE SKIPPED | 0.1 | +0.0 | 11.9 | 0.0 | 0.3 | +0.0 | 6.5 | 7.0 |
| BLOCKED WHEEL | 0.6 | +21.6 | 0.0 | 1.7 | 0.5 | +8.2 | 0.0 | 0.0 |
| BOMBING RUN | 0.0 | +0.8 | 0.0 | 0.0 | - | - | - | - |
| CANNON PLAN MISSED | 1.1 | +0.0 | 163.9 | 4.6 | 0.2 | +0.0 | 2.4 | 0.0 |
| CANNON PLANNED TARGET | 5.6 | +146.2 | 448.9 | 66.9 | 1.2 | +60.5 | 73.2 | 30.3 |
| CANNON SIGHT KEPT | 1.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CAST JOB | 0.9 | +15.9 | 16.7 | 7.1 | 0.6 | +14.9 | 19.2 | 14.9 |
| CASTER AWAY FROM SCREEN | 0.2 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.4 | +35.6 | 0.0 | 20.7 | 0.1 | +0.6 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 0.4 | +0.0 | 0.0 | 31.4 | 0.4 | +0.0 | 0.0 | 11.1 |
| CASTS FROM BEHIND | 0.0 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.1 | +0.6 | 0.0 | 0.0 | - | - | - | - |
| CHAFF PASSED | 0.2 | -0.0 | 0.0 | 2.9 | 0.1 | -0.4 | 3.8 | 0.0 |
| CHAMPION TAKES THE CHALLENGE | 0.0 | +3.4 | 7.0 | 0.0 | - | - | - | - |
| CHARGE NOW WEIGHED | 0.8 | -106.7 | 37.7 | 36.6 | 0.3 | -31.9 | 8.2 | 33.1 |
| CHARIOT NO STATIC JOB | 0.7 | +0.0 | 10.2 | 3.4 | 0.8 | +0.0 | 13.5 | 6.2 |
| CHEAP HELPER | 0.1 | +0.0 | 4.5 | 2.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| CONTINUE AHEAD WEIGHED | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | 0.6 | +50.9 | 42.0 | 51.4 | 0.4 | +20.1 | 16.4 | 16.4 |
| COUNTER-CHARGE COVER | 10.0 | +856.5 | 0.0 | 215.5 | 8.9 | +865.4 | 0.0 | 208.1 |
| EDGE GIVE GROUND | 0.1 | +6.8 | 21.2 | 0.0 | 0.2 | +4.9 | 8.1 | 1.2 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ESCORT | 0.2 | +12.6 | 0.0 | 3.1 | 0.2 | +13.9 | 0.0 | 4.2 |
| FACES THE THREAT | 1.3 | +131.8 | 0.0 | 39.7 | 1.3 | +128.9 | 0.0 | 24.8 |
| FIGHT LIFT | 0.0 | +0.1 | 0.0 | 0.0 | 0.1 | +2.9 | 7.3 | 0.0 |
| FOCUS FIRE | - | - | - | - | 0.0 | +0.2 | 3.5 | 0.0 |
| FOLLOW UP WEIGHED | 1.0 | +188.3 | 0.0 | 47.4 | 1.1 | +142.2 | 0.0 | 3.2 |
| FRIENDS SHOTS CHECKED | 0.3 | +12.4 | 0.0 | 0.0 | 0.0 | +0.5 | 0.0 | 0.0 |
| GIVES UP | 1.1 | -29.6 | 169.1 | 21.0 | 1.4 | -45.8 | 177.8 | 15.4 |
| GIVES UP ITS SCREEN | 0.4 | -6.3 | 23.4 | 9.1 | 0.8 | -11.2 | 40.7 | 18.5 |
| GROUND FLIERS | 0.1 | +0.9 | 0.0 | 0.0 | - | - | - | - |
| GROUP AIM | 0.3 | +2.4 | 0.0 | 0.0 | 0.5 | +4.8 | 0.0 | 2.2 |
| GROUP BROKEN | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HELPER ALREADY ASKED | 0.0 | +0.0 | 0.0 | 0.0 | 0.0 | +0.0 | 4.5 | 1.2 |
| HELPER UNSEEN | 0.3 | +0.0 | 26.5 | 13.4 | 0.2 | +0.0 | 6.6 | 2.0 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HORN WORTH | - | - | - | - | 0.1 | +2.7 | 0.0 | 0.0 |
| HUNT ADVANCE | 0.2 | +10.4 | 4.6 | 1.4 | 0.1 | +7.0 | 0.0 | 3.2 |
| HUNT DROPPED | 0.1 | +0.0 | 0.0 | 1.4 | 0.1 | +0.0 | 0.0 | 0.0 |
| HUNT IN PAIRS | 0.4 | +17.7 | 0.0 | 8.5 | 0.6 | +53.4 | 0.0 | 18.3 |
| HUNT KEPT | 0.2 | +2.3 | 4.6 | 1.4 | - | - | - | - |
| HUNT RESULT | 0.1 | +0.0 | 0.0 | 1.4 | 0.2 | +8.2 | 0.0 | 4.0 |
| HUNT THE GUNS | 0.1 | +58.0 | 4.6 | 1.4 | 0.2 | +60.6 | 4.6 | 6.4 |
| JOINT CHARGE PLAN | 0.1 | +4.3 | 7.9 | 7.7 | 0.2 | +7.0 | 5.2 | 2.0 |
| KEEPS ITS PREY | 0.3 | +1.3 | 14.8 | 7.8 | 0.2 | +2.6 | 3.5 | 1.8 |
| KEEPS ITS TARGET | 1.9 | +57.5 | 224.4 | 40.4 | 2.4 | +71.7 | 144.8 | 56.3 |
| KEEPS SCOUTS OR AMBUSH | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KILLS COUNT | 1.9 | +96.3 | 158.0 | 41.9 | 1.9 | +105.8 | 161.5 | 25.8 |
| KILLS COUNT NEXT TURN | 10.0 | +380.2 | 583.2 | 230.4 | 10.9 | +432.5 | 361.5 | 243.2 |
| LONE CHARACTER SAFE SPOT | 0.6 | +23.4 | 7.4 | 27.5 | 0.2 | +13.5 | 7.6 | 22.6 |
| LONE WIZARD HOLDS BACK | 1.4 | +0.0 | 98.2 | 50.6 | 1.6 | +0.0 | 53.7 | 53.2 |
| LONE WIZARD KEPT IN | 0.6 | +37.3 | 0.0 | 0.0 | 0.3 | +22.1 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 1.5 | +88.3 | 124.9 | 26.1 | 1.9 | +102.5 | 53.2 | 38.3 |
| MANOEUVRE | 0.3 | +11.6 | 0.0 | 15.7 | 0.2 | +6.7 | 0.0 | 5.5 |
| MARCH AT ESCAPER | 0.2 | +1.4 | 0.0 | 0.0 | 0.1 | +1.1 | 0.0 | 5.3 |
| MARCH ODDS | 0.9 | +61.8 | 42.7 | 37.6 | 1.0 | +47.8 | 27.3 | 30.0 |
| MISSILES IN THE MOVE | 2.9 | +89.0 | 0.0 | 48.8 | 2.9 | +39.8 | 0.0 | 73.1 |
| MISSILES NEXT TURN | 5.1 | +78.7 | 0.0 | 100.1 | 4.9 | +46.5 | 0.0 | 139.6 |
| MODEL FACING | 0.1 | +9.4 | 0.0 | 1.7 | - | - | - | - |
| MOVE AND CAST | 0.1 | +2.6 | 0.0 | 0.0 | 0.2 | +15.3 | 0.0 | 6.5 |
| MOVE SPELL IN RANGE | 0.1 | +5.5 | 0.0 | 37.2 | 0.0 | +0.3 | 0.0 | 6.5 |
| MOVE SPELL OUT OF RANGE | 0.3 | -8.6 | 8.0 | 99.4 | 0.1 | -1.5 | 2.9 | 6.5 |
| MOVE SPELL SPOT | 0.2 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 11.1 |
| MOVES UNITS SPELL | 0.1 | +3.6 | 0.0 | 0.0 | 0.1 | +0.3 | 0.0 | 0.0 |
| NEEDED THERE | - | - | - | - | 0.1 | +0.6 | 4.5 | 0.0 |
| NOT NEEDED | 0.3 | -14.5 | 36.2 | 9.1 | 0.3 | -16.7 | 31.1 | 4.5 |
| NOT TURNED | 11.8 | +171.3 | 0.0 | 237.9 | 10.8 | +204.3 | 0.0 | 239.1 |
| NOT WORTH A CAST | 0.5 | -0.4 | 0.0 | 41.9 | 0.7 | -0.7 | 0.0 | 21.9 |
| OPENS A LANE | 0.1 | +0.9 | 15.8 | 0.0 | 0.0 | +0.3 | 0.0 | 0.0 |
| OPENS UP | 0.3 | +21.4 | 15.7 | 12.1 | 0.2 | +15.4 | 13.5 | 0.0 |
| OVERRUNS AWAY | 0.4 | +9.5 | 46.0 | 13.3 | 0.6 | +12.6 | 60.6 | 17.8 |
| PATHS CROSS | 2.4 | +172.3 | 0.0 | 51.3 | 3.1 | +221.2 | 0.0 | 27.8 |
| PLAN LEADS | 1.3 | +104.4 | 15.6 | 4.9 | 0.9 | +61.5 | 5.2 | 15.1 |
| PLAN RESULT | 38.1 | +1722.2 | 1579.7 | 880.7 | 38.1 | +1249.4 | 1111.8 | 919.2 |
| PURSUES BIG PREY | 0.1 | -9.0 | 0.0 | 0.0 | 0.1 | -1.9 | 0.0 | 0.0 |
| PURSUES ON | 0.0 | +2.4 | 0.0 | 0.0 | 0.0 | +0.2 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE NEXT TURN | 0.2 | +22.1 | 0.0 | 11.5 | 0.0 | +2.4 | 0.0 | 0.0 |
| REDIRECT COUNTER | 2.9 | +109.0 | 0.0 | 49.7 | 4.4 | +312.6 | 0.0 | 40.9 |
| REDIRECT WEIGHED | 0.4 | +19.1 | 19.7 | 32.6 | 0.4 | +7.5 | 9.4 | 13.8 |
| RESTRAINS TO SHOOT | 0.2 | +3.5 | 0.0 | 10.0 | 0.0 | +0.4 | 0.0 | 0.0 |
| RISK BY ARC | 2.5 | +106.6 | 245.6 | 58.5 | 2.5 | +51.7 | 216.8 | 53.2 |
| SAFE SURE CHARGE | 0.0 | -0.2 | 0.0 | 0.0 | - | - | - | - |
| SAFER THAN THE JOB | 0.5 | +27.0 | 0.0 | 4.5 | 0.5 | +44.7 | 0.0 | 0.0 |
| SCOUT SPOT | 0.4 | +0.3 | 0.0 | 0.9 | 0.3 | +0.8 | 0.0 | 0.0 |
| SCOUT WAITS | 0.4 | +0.0 | 0.0 | 0.9 | 0.3 | +0.0 | 0.0 | 0.0 |
| SCREEN STEPS ASIDE | 0.0 | +0.0 | 0.0 | 1.1 | 0.0 | +0.0 | 0.0 | 0.0 |
| SEARCH SPOT | 1.5 | +83.8 | 0.0 | 15.8 | 1.0 | +99.0 | 0.0 | 14.5 |
| SECOND HUNTER | 0.0 | -0.8 | 0.0 | 0.0 | - | - | - | - |
| SELF MOVE SPELL | 0.4 | +47.0 | 0.0 | 40.1 | 0.2 | +59.0 | 0.0 | 21.9 |
| SET UP TOGETHER | 2.0 | +134.6 | 124.9 | 34.6 | 2.9 | +169.1 | 53.2 | 45.5 |
| SET-UP MISSED | 0.0 | +7.0 | 10.3 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | 0.3 | +0.6 | 0.0 | 0.0 | 0.1 | +0.1 | 0.0 | 0.0 |
| SHORT GUN FORWARD | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SHOT REPLANNED | 0.9 | +0.0 | 244.7 | 1.7 | 0.1 | +0.0 | 7.1 | 0.0 |
| SHOTS IN THE MOVE | 12.9 | +581.9 | 0.0 | 170.1 | 8.6 | +291.2 | 0.0 | 135.7 |
| SPELL CATCH ODDS | 0.1 | -0.5 | 0.0 | 0.0 | - | - | - | - |
| SPELL SETS UP CHARGE | 0.1 | +44.4 | 10.6 | 10.6 | - | - | - | - |
| SPELL WORTH | 1.3 | +25.5 | 29.9 | 29.4 | 2.4 | +38.3 | 114.2 | 104.0 |
| STANDS TO CAST | 0.1 | +1.0 | 0.0 | 0.0 | - | - | - | - |
| STOPS | - | - | - | - | 0.1 | +3.6 | 4.6 | 3.2 |
| STUCK PIVOT | 0.2 | +0.0 | 0.0 | 4.7 | 0.3 | +0.0 | 0.0 | 0.0 |
| SURE CHARGE BEATS ADVANCE | 0.2 | -10.9 | 23.5 | 19.0 | 0.1 | -4.2 | 18.3 | 0.0 |
| THROUGH LINE OF FIRE | 0.6 | +23.7 | 0.0 | 0.0 | 0.2 | +17.9 | 0.0 | 0.0 |
| TURN WORTH | 0.6 | -45.2 | 58.0 | 0.0 | 0.5 | -33.7 | 40.3 | 0.0 |
| TWO OR MORE ARRIVE | 0.8 | +13.0 | 41.6 | 9.9 | 0.9 | +19.3 | 5.2 | 6.0 |
| WEARS DOWN | 1.0 | +56.5 | 140.7 | 23.6 | 1.2 | +26.3 | 138.6 | 42.1 |
| WHO HITS BACK | 0.2 | +29.9 | 0.0 | 5.2 | 0.1 | +9.2 | 0.0 | 13.0 |
| WHOLE FIGHT | 0.4 | +12.7 | 49.3 | 7.7 | 0.2 | +9.1 | 17.6 | 8.3 |
| WHOLE FIGHT GAIN | 0.2 | +18.0 | 4.7 | 8.5 | 0.3 | +34.0 | 27.8 | 6.6 |

### Rule changes: bg-on-789c37f-p3

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| KILLS COUNT NEXT TURN | 751 | 738 | 173 | 4.81 | +6682 | +38.6 |
| BEST PREY | 318 | 308 | 134 | 3.72 | +5624 | +42.0 |
| COUNTER-CHARGE COVER | 682 | 292 | 80 | 2.22 | +5193 | +64.9 |
| ARTILLERY RE-ROLL WEIGHED | 79 | 79 | 79 | 2.19 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 76 | 76 | 76 | 2.11 | +11900 | +156.6 |
| CANNON SIGHT KEPT | 56 | 56 | 56 | 1.56 | +0 | +0.0 |
| MARCH ODDS | 68 | 57 | 55 | 1.53 | +802 | +14.6 |
| CANNON PLANNED TARGET | 245 | 245 | 51 | 1.42 | -219 | -4.3 |
| RISK BY ARC | 181 | 171 | 49 | 1.36 | +1692 | +34.5 |
| SET UP TOGETHER | 176 | 141 | 48 | 1.33 | +3123 | +65.1 |
| KEEPS ITS TARGET | 155 | 155 | 46 | 1.28 | +776 | +16.9 |
| CHARGE NOW WEIGHED | 42 | 42 | 42 | 1.17 | +4468 | +106.4 |
| KILLS COUNT | 136 | 130 | 42 | 1.17 | +2077 | +49.5 |
| HOLDS AMBUSHERS | 39 | 39 | 39 | 1.08 | +0 | +0.0 |
| SHOT REPLANNED | 39 | 39 | 39 | 1.08 | +0 | +0.0 |
| PLAN LEADS | 78 | 78 | 34 | 0.94 | +1900 | +55.9 |
| CHARIOT NO STATIC JOB | 54 | 54 | 33 | 0.92 | -2115 | -64.1 |
| LONE WIZARD KEPT IN | 32 | 32 | 32 | 0.89 | +2140 | +66.9 |
| ADVANCE LANE KEPT | 31 | 31 | 31 | 0.86 | +0 | +0.0 |
| LONE WIZARD HOLDS BACK | 108 | 108 | 31 | 0.86 | -1920 | -61.9 |
| MAKE SURE TOGETHER | 125 | 81 | 29 | 0.81 | +1596 | +55.0 |
| REDIRECT WEIGHED | 28 | 28 | 28 | 0.78 | +2140 | +76.4 |
| SCOUT WAITS | 25 | 25 | 25 | 0.69 | +0 | +0.0 |
| CAST JOB | 55 | 54 | 24 | 0.67 | +315 | +13.1 |
| STUCK PIVOT | 17 | 17 | 17 | 0.47 | +0 | +0.0 |
| REDIRECT COUNTER | 260 | 80 | 16 | 0.44 | +1350 | +84.4 |
| SHOOTERS IN TWO RANKS | 16 | 16 | 16 | 0.44 | +27 | +1.7 |
| WEARS DOWN | 77 | 70 | 15 | 0.42 | +399 | +26.6 |
| CASTING BLOCK | 17 | 16 | 13 | 0.36 | +495 | +38.1 |
| WHO HITS BACK | 13 | 13 | 13 | 0.36 | -766 | -58.9 |
| BLOCKED CHARGE SKIPPED | 12 | 12 | 12 | 0.33 | +0 | +0.0 |
| FRIENDS SHOTS CHECKED | 12 | 12 | 12 | 0.33 | +462 | +38.5 |
| WHOLE FIGHT GAIN | 18 | 16 | 12 | 0.33 | +825 | +68.8 |
| CHAFF PASSED | 10 | 10 | 10 | 0.28 | -14 | -1.4 |
| SURE CHARGE BEATS ADVANCE | 10 | 10 | 10 | 0.28 | -543 | -54.3 |
| CASTER AWAY FROM SCREEN | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| CASTS FROM BEHIND | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| OPENS UP | 20 | 18 | 9 | 0.25 | +312 | +34.6 |
| RAIDS THE BAGGAGE NEXT TURN | 9 | 9 | 8 | 0.22 | +328 | +41.0 |
| MOVES UNITS SPELL | 7 | 7 | 7 | 0.19 | +141 | +20.1 |
| OVERRUNS AWAY | 37 | 36 | 7 | 0.19 | +162 | +23.1 |
| PURSUES BIG PREY | 7 | 7 | 7 | 0.19 | -393 | -56.2 |
| RESTRAINS TO SHOOT | 7 | 7 | 7 | 0.19 | +138 | +19.7 |
| WHOLE FIGHT | 22 | 20 | 7 | 0.19 | +608 | +86.9 |
| BEST PRIZE | 6 | 6 | 6 | 0.17 | -317 | -52.9 |
| EDGE GIVE GROUND | 14 | 13 | 6 | 0.17 | +114 | +19.0 |
| TWO OR MORE ARRIVE | 63 | 53 | 6 | 0.17 | +93 | +15.4 |
| HUNT ADVANCE | 10 | 10 | 5 | 0.14 | +239 | +47.8 |
| SHORT GUN FORWARD | 5 | 5 | 5 | 0.14 | +0 | +0.0 |
| HORN WORTH | 4 | 4 | 4 | 0.11 | +97 | +24.3 |
| HUNT IN PAIRS | 36 | 15 | 4 | 0.11 | +545 | +136.2 |
| GIVES UP | 91 | 87 | 2 | 0.06 | +2 | +0.9 |
| MODEL FACING | 2 | 2 | 2 | 0.06 | +338 | +169.2 |
| PURSUES ON | 2 | 2 | 2 | 0.06 | +94 | +46.8 |
| SCREEN STEPS ASIDE | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| BACKUP TARGETS | 54 | 23 | 1 | 0.03 | +1 | +1.1 |
| BOMBING RUN | 1 | 1 | 1 | 0.03 | +27 | +27.1 |
| CONTINUE AHEAD WEIGHED | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| FOCUS FIRE | 1 | 1 | 1 | 0.03 | +7 | +7.2 |
| GROUP AIM | 28 | 15 | 1 | 0.03 | +6 | +6.5 |
| JOINT CHARGE PLAN | 12 | 12 | 1 | 0.03 | +83 | +83.2 |
| KEEPS ITS PREY | 18 | 17 | 1 | 0.03 | +0 | +0.3 |
| KEEPS SCOUTS OR AMBUSH | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| MISSILES NEXT TURN | 358 | 148 | 1 | 0.03 | +2 | +2.1 |
| NEEDED THERE | 2 | 2 | 1 | 0.03 | +0 | +0.0 |
| SAFE SURE CHARGE | 1 | 1 | 1 | 0.03 | -9 | -8.7 |
| STANDS TO CAST | 2 | 2 | 1 | 0.03 | +7 | +6.8 |
| STOPS | 3 | 1 | 1 | 0.03 | +109 | +108.8 |
| TURN WORTH | 40 | 38 | 1 | 0.03 | +0 | +0.2 |
| ARRIVAL HUNT | 3 | 3 | 0 | 0.00 | - | - |
| BLOCKED WHEEL | 40 | not checked | - | - | - | - |
| CANNON PLAN MISSED | 45 | 45 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 28 | trace | - | - | - | - |
| CATCH FLIERS | 2 | not checked | - | - | - | - |
| CHAMPION TAKES THE CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| CHEAP HELPER | 4 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 34 | not checked | - | - | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| ESCORT | 15 | 7 | 0 | 0.00 | - | - |
| FACES THE THREAT | 96 | not checked | - | - | - | - |
| FIGHT LIFT | 3 | not checked | - | - | - | - |
| GIVES UP ITS SCREEN | 42 | 40 | 0 | 0.00 | - | - |
| GROUND FLIERS | 2 | not checked | - | - | - | - |
| GROUP BROKEN | 3 | not checked | - | - | - | - |
| HELPER ALREADY ASKED | 2 | not checked | - | - | - | - |
| HELPER UNSEEN | 17 | 14 | 0 | 0.00 | - | - |
| HUNT DROPPED | 5 | trace | - | - | - | - |
| HUNT KEPT | 7 | trace | - | - | - | - |
| HUNT RESULT | 9 | trace | - | - | - | - |
| HUNT THE GUNS | 11 | trace | - | - | - | - |
| LONE CHARACTER SAFE SPOT | 32 | not checked | - | - | - | - |
| MANOEUVRE | 18 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 14 | trace | - | - | - | - |
| MISSILES IN THE MOVE | 209 | not checked | - | - | - | - |
| MOVE AND CAST | 12 | not checked | - | - | - | - |
| MOVE SPELL IN RANGE | 6 | 4 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 12 | trace | - | - | - | - |
| MOVE SPELL SPOT | 15 | not checked | - | - | - | - |
| NOT NEEDED | 23 | 22 | 0 | 0.00 | - | - |
| NOT TURNED | 810 | 810 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 42 | not checked | - | - | - | - |
| OPENS A LANE | 6 | 4 | 0 | 0.00 | - | - |
| PATHS CROSS | 198 | not checked | - | - | - | - |
| PLAN RESULT | 2743 | trace | - | - | - | - |
| SAFER THAN THE JOB | 35 | not checked | - | - | - | - |
| SCOUT SPOT | 24 | 24 | 0 | 0.00 | - | - |
| SEARCH SPOT | 90 | not checked | - | - | - | - |
| SECOND HUNTER | 1 | 1 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 23 | not checked | - | - | - | - |
| SET-UP MISSED | 1 | trace | - | - | - | - |
| SHOTS IN THE MOVE | 773 | not checked | - | - | - | - |
| SPELL CATCH ODDS | 2 | not checked | - | - | - | - |
| SPELL SETS UP CHARGE | 5 | not checked | - | - | - | - |
| SPELL WORTH | 135 | not checked | - | - | - | - |
| THROUGH LINE OF FIRE | 29 | not checked | - | - | - | - |

### Plans: bg-on-789c37f-p3

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 12.8 | 18% | 562 | 521 | 93% |
| Mine | charge | 3.1 | 57% | 293 | 306 | 105% |
| Mine | close in | 5.3 | 29% | 385 | 227 | 59% |
| Mine | hold | 4.2 | 40% | 275 | 0 | 0% |
| Mine | join | 0.7 | 92% | 24 | 0 | 0% |
| Mine | shoot | 8.3 | 61% | 302 | 668 | 221% |
| Mine | support | 3.7 | 89% | 209 | 0 | 0% |
| Opponent | advance | 13.4 | 16% | 680 | 422 | 62% |
| Opponent | charge | 3.4 | 54% | 421 | 336 | 80% |
| Opponent | close in | 6.3 | 21% | 477 | 192 | 40% |
| Opponent | hold | 3.6 | 27% | 343 | 0 | 0% |
| Opponent | join | 1.0 | 97% | 52 | 0 | 0% |
| Opponent | shoot | 4.3 | 62% | 108 | 299 | 277% |
| Opponent | support | 6.0 | 93% | 239 | 0 | 0% |

### Packages: hunt the guns, bg-on-789c37f-p3

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.1 | 5 | 2 | 0% | 0% | 0% | - | 452 | 0 | 0% | 30 |
| Opponent | 0.2 | 6 | 0 | 17% | 17% | 0% | 2.0 | 363 | 49 | 17% | 60 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 1.0 | 4 | 2 | 0% | 0% | 0% | - | 448 | 0 | 0% | 34 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 55 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 32 |
| Empire of Man | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 458 | 0 | 0% | 84 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 17 |
| High Elf Realms | 0.1 | 1 | 0 | 0% | 0% | 0% | - | 581 | 0 | 0% | 67 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 60 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 302 |
| Tomb Kings of Khemri | 0.3 | 2 | 0 | 50% | 50% | 0% | 2.0 | 320 | 148 | 50% | 24 |
| Vampire Counts | 0.1 | 1 | 0 | 0% | 0% | 0% | - | 213 | 0 | 0% | 24 |
| Warriors of Chaos | 0.1 | 1 | 0 | 0% | 0% | 0% | - | 494 | 0 | 0% | 39 |
| Wood Elf Realms | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 253 | 0 | 0% | 21 |

### Battle groups: bg-on-789c37f-p3

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 10.0 | 23% | 60% | 17% | 36% | 35% | 7% | 12% | 46% | 0% |
| Mine | REDIRECT COUNTER | 2.9 | 29% | 60% | 7% | 50% | 14% | 4% | 4% | 71% | 7% |
| Opponent | COUNTER-CHARGE COVER | 8.9 | 17% | 62% | 23% | 46% | 23% | 9% | 28% | 40% | 0% |
| Opponent | REDIRECT COUNTER | 4.4 | 17% | 78% | 4% | 0% | 15% | 4% | 8% | 62% | 12% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.3 | 7 | 0% | - |
| Opponent | 0.4 | 11 | 0% | - |

### Deployment: positions vs output by unit type: bg-on-789c37f-p3

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 1 | 0 (1) | 0 | 0 | 100 | 0% | 4.0 | - | 0 (1) | - | 0 (1) | - |
| Mine | Chaff | 40 | 73 (40) | 50 | 23 | 55 | 40% | 2.6 | 64 (20) | 84 (8) | 82 (12) | 94 (32) | 0 (8) |
| Mine | Character | 120 | 46 (120) | 46 | 0 | 29 | 22% | 2.5 | 60 (41) | 45 (58) | 30 (7) | 47 (58) | 53 (48) |
| Mine | Clean-up | 15 | 51 (15) | 9 | 42 | 35 | 33% | 2.9 | 50 (7) | 35 (6) | 133 (2) | 60 (8) | 39 (7) |
| Mine | Fast Hammer | 43 | 34 (43) | 25 | 9 | 47 | 16% | 3.0 | 38 (24) | 38 (13) | 0 (6) | 42 (31) | 12 (12) |
| Mine | Fragile | 3 | 0 (3) | 0 | 0 | 33 | 67% | 6.0 | 0 (3) | - | - | 0 (1) | 0 (2) |
| Mine | Hammer | 50 | 37 (50) | 23 | 14 | 37 | 24% | 2.4 | 10 (13) | 39 (32) | 96 (5) | 34 (34) | 43 (16) |
| Mine | Holder | 25 | 54 (25) | 14 | 41 | 11 | 36% | 3.1 | 14 (8) | 77 (10) | 50 (7) | 56 (13) | 52 (12) |
| Mine | Shooter | 38 | 89 (38) | 42 | 47 | 36 | 5% | 1.8 | 102 (10) | 87 (26) | 57 (2) | 122 (22) | 51 (16) |
| Mine | Support | 4 | 46 (4) | 46 | 0 | 0 | 0% | 3.8 | 0 (1) | - | 79 (3) | - | 46 (4) |
| Mine | War machine | 52 | 33 (52) | 33 | 0 | 29 | 4% | 1.0 | 36 (14) | 31 (34) | 36 (4) | 34 (14) | 33 (38) |
| Mine | Wizard | 15 | 7 (15) | 7 | 0 | 44 | 27% | 1.7 | 0 (2) | 11 (9) | 0 (1) | 11 (7) | 0 (5) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Chaff | 73 | 60 (73) | 18 | 42 | 46 | 49% | 2.5 | 60 (31) | 87 (13) | 46 (29) | 70 (52) | 37 (21) |
| Opponent | Character | 101 | 45 (101) | 45 | 0 | 30 | 23% | 2.4 | 45 (39) | 52 (48) | 8 (8) | 49 (51) | 43 (44) |
| Opponent | Clean-up | 9 | 45 (9) | 28 | 17 | 38 | 33% | 2.5 | 53 (3) | 22 (4) | 111 (2) | 70 (5) | 23 (4) |
| Opponent | Fast Hammer | 60 | 47 (60) | 23 | 24 | 46 | 28% | 3.0 | 47 (31) | 44 (17) | 53 (12) | 47 (32) | 47 (28) |
| Opponent | Fragile | 3 | 0 (3) | 0 | 0 | 100 | 33% | 3.0 | - | 0 (2) | 0 (1) | 0 (2) | 0 (1) |
| Opponent | Hammer | 47 | 32 (47) | 27 | 5 | 37 | 28% | 3.3 | 5 (15) | 40 (28) | 39 (4) | 34 (25) | 29 (22) |
| Opponent | Holder | 40 | 74 (40) | 23 | 51 | 36 | 30% | 2.7 | 11 (10) | 105 (21) | 77 (9) | 77 (29) | 65 (11) |
| Opponent | Shooter | 28 | 28 (28) | 20 | 8 | 56 | 7% | 1.2 | 9 (7) | 34 (20) | 35 (1) | 44 (17) | 7 (11) |
| Opponent | Support | 4 | 0 (4) | 0 | 0 | 17 | 50% | 5.0 | 0 (2) | 0 (1) | 0 (1) | 0 (2) | 0 (2) |
| Opponent | War machine | 17 | 53 (17) | 53 | 0 | 45 | 12% | 1.5 | 0 (3) | 84 (10) | 17 (4) | 72 (3) | 50 (14) |
| Opponent | Wizard | 33 | 12 (33) | 12 | 0 | 49 | 15% | 2.0 | 4 (15) | 45 (8) | 0 (4) | 21 (16) | 6 (11) |

### Charged fights: bg-on-789c37f-p3

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 21 | 81 | 0.8 | 1.3 | 108 | 0 | +108 | 0 of 3 | 3 of 3 | +162 | +81 |
| Mine | Chaos Dwarfs | 4 | 156 | 256 | 3.0 | 1.2 | 85 | 0 | +85 | 5 of 12 | 7 of 12 | +184 | +66 |
| Mine | Dwarfen Mountain Holds | 3 | 661 | 44 | 2.0 | 1.0 | 22 | 41 | -19 | 2 of 6 | 5 of 6 | - | -19 |
| Mine | Empire of Man | 5 | 296 | 31 | 1.0 | 1.0 | 31 | 53 | -22 | 1 of 5 | 4 of 5 | - | -22 |
| Mine | Grand Cathay | 5 | 241 | 352 | 3.8 | 1.3 | 93 | 25 | +68 | 5 of 19 | 17 of 19 | +186 | +26 |
| Mine | High Elf Realms | 4 | 174 | 560 | 4.5 | 1.1 | 125 | 0 | +125 | 6 of 18 | 13 of 18 | +106 | +127 |
| Mine | Kingdom of Bretonnia | 1 | 0 | 696 | 5.0 | 1.0 | 139 | 55 | +84 | 0 of 5 | 2 of 5 | - | +84 |
| Mine | Lizardmen | 1 | 0 | 887 | 3.0 | 1.0 | 296 | 62 | +234 | 1 of 3 | 2 of 3 | - | +234 |
| Mine | Ogre Kingdoms | 1 | 0 | 509 | 6.0 | 1.0 | 85 | 90 | -6 | 2 of 6 | 4 of 6 | - | -6 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 507 | 9.0 | 1.0 | 56 | 95 | -38 | 3 of 9 | 6 of 9 | - | -38 |
| Mine | Skaven | 1 | 0 | 19 | 2.0 | 1.0 | 10 | 0 | +10 | 0 of 2 | 1 of 2 | - | +10 |
| Mine | Tomb Kings of Khemri | 2 | 0 | 662 | 5.0 | 1.2 | 132 | 6 | +126 | 2 of 10 | 8 of 10 | +419 | +53 |
| Mine | Vampire Counts | 2 | 0 | 1103 | 6.0 | 1.2 | 184 | 7 | +177 | 2 of 12 | 6 of 12 | +206 | +171 |
| Mine | Warriors of Chaos | 2 | 0 | 0 | 1.0 | 1.5 | 0 | 331 | -331 | 1 of 2 | 2 of 2 | -662 | +0 |
| **Mine** | all armies | 36 | 169 | 327 | 3.1 | 1.1 | 105 | 33 | +73 | 30 of 112 | 80 of 112 | +151 | +61 |
| Opponent | Empire of Man | 1 | 380 | 398 | 3.0 | 1.3 | 133 | 35 | +98 | 2 of 3 | 0 of 3 | +288 | +3 |
| Opponent | Grand Cathay | 3 | 263 | 335 | 1.7 | 1.6 | 201 | 0 | +201 | 1 of 5 | 1 of 5 | +307 | +42 |
| Opponent | High Elf Realms | 3 | 139 | 435 | 3.0 | 1.1 | 145 | 116 | +29 | 6 of 9 | 4 of 9 | -162 | +53 |
| Opponent | Kingdom of Bretonnia | 2 | 48 | 0 | 2.0 | 1.0 | 0 | 0 | +0 | 4 of 4 | 0 of 4 | - | +0 |
| Opponent | Orc & Goblin Tribes | 1 | 0 | 241 | 7.0 | 1.1 | 34 | 31 | +4 | 4 of 7 | 2 of 7 | +0 | +4 |
| Opponent | Skaven | 1 | 0 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 0 of 1 | 0 of 1 | - | +0 |
| Opponent | Tomb Kings of Khemri | 4 | 157 | 409 | 3.8 | 1.3 | 109 | 31 | +78 | 6 of 15 | 8 of 15 | +287 | +3 |
| Opponent | Vampire Counts | 6 | 0 | 601 | 5.5 | 1.2 | 109 | 24 | +85 | 14 of 33 | 23 of 33 | +163 | +74 |
| Opponent | Warriors of Chaos | 9 | 19 | 434 | 3.7 | 1.2 | 118 | 41 | +77 | 13 of 33 | 19 of 33 | +8 | +93 |
| Opponent | Wood Elf Realms | 6 | 87 | 127 | 2.0 | 1.0 | 64 | 20 | +43 | 6 of 12 | 6 of 12 | - | +43 |
| **Opponent** | all armies | 36 | 84 | 357 | 3.4 | 1.2 | 105 | 35 | +71 | 56 of 122 | 63 of 122 | +145 | +56 |

### Effective charges: bg-on-789c37f-p3

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 3 | 0 | 0 | 0 | 1 (net +162) | 1 (net +0) | 0 | 1 | 0% (0 of 2) |
| Mine | Chaos Dwarfs | 12 | 0 | 0 | 2 (net +0) | 4 (net +120) | 1 (net +0) | 4 (net +92) | 1 | 18% (2 of 11) |
| Mine | Dwarfen Mountain Holds | 6 | 2 (net -122) | 0 | 1 (net +0) | 1 (net +0) | 0 | 1 (net +133) | 1 | 20% (1 of 5) |
| Mine | Empire of Man | 5 | 1 (net +153) | 0 | 1 (net -265) | 0 | 0 | 2 (net +0) | 1 | 25% (1 of 4) |
| Mine | Grand Cathay | 19 | 0 | 0 | 3 (net +0) | 4 (net +145) | 5 (net +80) | 5 (net +62) | 2 | 18% (3 of 17) |
| Mine | High Elf Realms | 18 | 1 (net +233) | 0 | 2 (net +0) | 3 (net +122) | 3 (net +112) | 8 (net +151) | 1 | 12% (2 of 17) |
| Mine | Kingdom of Bretonnia | 5 | 2 (net +167) | 0 | 1 (net -277) | 0 | 0 | 1 (net +258) | 1 | 25% (1 of 4) |
| Mine | Lizardmen | 3 | 1 (net +743) | 0 | 1 (net -185) | 1 (net +144) | 0 | 0 | 0 | 33% (1 of 3) |
| Mine | Ogre Kingdoms | 6 | 1 (net -185) | 0 | 0 | 0 | 0 | 2 (net -45) | 3 | 0% (0 of 3) |
| Mine | Orc & Goblin Tribes | 9 | 0 | 0 | 1 (net +340) | 1 (net +0) | 0 | 0 | 7 | 50% (1 of 2) |
| Mine | Skaven | 2 | 1 (net +0) | 0 | 0 | 0 | 0 | 0 | 1 | 0% (0 of 1) |
| Mine | Tomb Kings of Khemri | 10 | 0 | 0 | 1 (net +70) | 1 (net +0) | 2 (net +144) | 5 (net +181) | 1 | 11% (1 of 9) |
| Mine | Vampire Counts | 12 | 1 (net +412) | 0 | 4 (net +192) | 1 (net +53) | 1 (net +0) | 5 (net +178) | 0 | 33% (4 of 12) |
| Mine | Warriors of Chaos | 2 | 0 | 0 | 0 | 0 | 0 | 2 (net -331) | 0 | 0% (0 of 2) |
| Opponent | Empire of Man | 3 | 0 | 0 | 0 | 1 (net +6) | 0 | 2 (net +144) | 0 | 0% (0 of 3) |
| Opponent | Grand Cathay | 5 | 0 | 0 | 0 | 2 (net +428) | 2 (net +32) | 1 (net +84) | 0 | 0% (0 of 5) |
| Opponent | High Elf Realms | 9 | 2 (net -86) | 0 | 0 | 2 (net -81) | 0 | 4 (net +114) | 1 | 0% (0 of 8) |
| Opponent | Kingdom of Bretonnia | 4 | 3 (net +0) | 0 | 1 (net +0) | 0 | 0 | 0 | 0 | 25% (1 of 4) |
| Opponent | Orc & Goblin Tribes | 7 | 0 | 0 | 0 | 0 | 1 (net +115) | 1 (net +0) | 5 | 0% (0 of 2) |
| Opponent | Skaven | 1 | 1 (net +0) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 1) |
| Opponent | Tomb Kings of Khemri | 15 | 1 (net -144) | 1 (net +0) | 0 | 3 (net +191) | 4 (net +169) | 6 (net +12) | 0 | 0% (0 of 15) |
| Opponent | Vampire Counts | 33 | 3 (net +41) | 0 | 5 (net +105) | 10 (net +35) | 5 (net +59) | 7 (net +192) | 3 | 17% (5 of 30) |
| Opponent | Warriors of Chaos | 33 | 3 (net +0) | 0 | 6 (net -38) | 5 (net +124) | 2 (net +48) | 14 (net +149) | 3 | 20% (6 of 30) |
| Opponent | Wood Elf Realms | 12 | 1 (net -19) | 0 | 1 (net +0) | 0 | 0 | 4 (net +114) | 6 | 17% (1 of 6) |

### Charged fights, damage counted: bg-on-789c37f-p3

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 10 | 261 | 190 | +144 | 207 | 61 | +146 | +56.0 |
| Mine | Effective (55-75%) | 17 | 335 | 245 | +26 | 82 | 52 | +30 | +9.0 |
| Mine | 76-89% | 17 | 258 | 171 | +105 | 110 | 11 | +99 | +38.4 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 35 | 290 | 183 | +95 | 159 | 46 | +113 | +38.9 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 13 | 448 | 102 | +79 | 114 | 26 | +88 | +19.6 |
| Mine | No odds | 20 | 229 | 162 | +6 | 59 | 61 | -2 | -0.7 |
| Mine | All fights | 112 | 297 | 178 | +73 | 121 | 43 | +78 | +26.2 |
| Opponent | Long shot (under 50%) | 14 | 217 | 278 | -15 | 62 | 85 | -23 | -10.5 |
| Opponent | 50-54% | 1 | 195 | 189 | +0 | 0 | 0 | +0 | +0.0 |
| Opponent | Effective (55-75%) | 13 | 347 | 273 | +23 | 160 | 90 | +70 | +20.2 |
| Opponent | 76-89% | 23 | 295 | 199 | +98 | 143 | 31 | +112 | +38.1 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 39 | 272 | 216 | +123 | 177 | 55 | +122 | +44.8 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 14 | 412 | 88 | +89 | 104 | 13 | +91 | +22.1 |
| Opponent | No odds | 18 | 179 | 274 | +15 | 69 | 64 | +6 | +3.3 |
| Opponent | All fights | 122 | 280 | 220 | +71 | 130 | 53 | +76 | +27.3 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| bg-on-789c37f-p3 | move | 489 | 101 (21%) | 74 (15%) | 54 (11%) | 334 (68%) |
| bg-on-789c37f-p3 | objective | 424 | 63 (15%) | 49 (12%) | 57 (13%) | 304 (72%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0110, L0126, L2433, L2630 |
| Charmed Shield | Opponent | L0126, L0226, L0327, L0725, L1327, L2327 |
| Clockwork Compass | Mine | L1216, L1232 |
| Elixir of Power | Mine | L1122, L1932 |
| Elixir of Power | Opponent | L0311, L1519 |
| Fistful of Laurels | Mine | L1831 |
| Horn of the Wild Hunt | Opponent | L0533, L1633, L2033, L2433, L3133 |
| Invocation of Nehek | Mine | L2433 |
| Invocation of Nehek | Opponent | L0327, L0725, L1327, L2327 |
| Opal Amulet | Mine | L1422 |
| Periapt of Soul Exchange | Mine | L2033 |
| Periapt of Soul Exchange | Opponent | L0620 |
| Ring of Doom | Mine | L0210, L0226, L1122, L1216, L1232, L1519, L1535, L3133 |
| Ring of Doom | Opponent | L0311, L0533, L0815, L0831, L1633, L1731, L1831, L2033, L2433, L3133 |
| Ring of Jet | Mine | L1013, L1030, L1122, L1216, L1232 |
| Ring of Jet | Opponent | L0110, L0210, L0311 |
| Standard of the Fell Warrior | Mine | L1327 |
| Standard of the Fell Warrior | Opponent | L0413, L1013 |
| Twice-Blessed Armour | Mine | L0709, L0725, L1013, L1030 |
| Twice-Blessed Armour | Opponent | L0110, L0210 |
| Witch Hunter's Ward | Mine | L0709, L0725, L0815, L0831 |

# groups on vs groups off

A = groups on: on-4, 36 of 36 games ended
B = groups off: off-4, 36 of 36 games ended

## Game by game (Victory Points Mine-Opponent; margin = Mine minus Opponent)

| Match-up | Scenario | Seed | A | B | Margin A | Margin B | A minus B | Cost A | Cost B |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0114 | 6 | 1 | draw 2176-2016 | Opponent 1216-2361 | +160 | -1145 | +1305 | 0.00 | 0.00 |
| L0130 | 4 | 1 | Mine 2340-210 | Mine 1894-609 | +2130 | +1285 | +845 | 0.00 | 0.00 |
| L0214 | 4 | 1 | Opponent 828-2451 | Opponent 697-2359 | -1623 | -1662 | +39 | 0.00 | 0.00 |
| L0230 | 2 | 1 | draw 766-482 | draw 766-1031 | +284 | -265 | +549 | 0.00 | 0.00 |
| L0315 | 3 | 1 | draw 1356-1274 | Opponent 923-1639 | +82 | -716 | +798 | 0.00 | 0.00 |
| L0332 | 2 | 1 | Opponent 506-2434 | Opponent 300-2522 | -1928 | -2222 | +294 | 0.00 | 0.00 |
| L0417 | 3 | 1 | Opponent 1667-2756 | Opponent 1380-2115 | -1089 | -735 | -354 | 0.00 | 0.00 |
| L0434 | 2 | 1 | draw 1329-1067 | Mine 1539-1021 | +262 | +518 | -256 | 0.00 | 0.00 |
| L0520 | 4 | 1 | Opponent 1095-1509 | Mine 1474-1127 | -414 | +347 | -761 | 0.00 | 0.00 |
| L0608 | 2 | 1 | Opponent 661-2203 | draw 927-945 | -1542 | -18 | -1524 | 0.00 | 0.00 |
| L0624 | 6 | 1 | draw 1522-1455 | draw 1212-1495 | +67 | -283 | +350 | 0.00 | 0.00 |
| L0713 | 5 | 1 | draw 1324-1174 | Opponent 847-1195 | +150 | -348 | +498 | 0.00 | 0.00 |
| L0729 | 3 | 1 | Opponent 745-2198 | draw 1264-1384 | -1453 | -120 | -1333 | 0.00 | 0.00 |
| L0819 | 3 | 1 | Opponent 916-1370 | draw 1698-1440 | -454 | +258 | -712 | 0.00 | 0.00 |
| L0835 | 1 | 1 | draw 1287-1194 | Opponent 1445-2114 | +93 | -669 | +762 | 0.00 | 0.00 |
| L0926 | 2 | 1 | Opponent 669-2591 | Opponent 595-2219 | -1922 | -1624 | -298 | 0.00 | 0.00 |
| L1017 | 3 | 1 | Mine 2257-1214 | Mine 1605-1292 | +1043 | +313 | +730 | 0.00 | 0.00 |
| L1034 | 2 | 1 | Mine 1282-935 | draw 969-1219 | +347 | -250 | +597 | 0.00 | 0.00 |
| L1126 | 4 | 1 | Opponent 1265-1735 | Opponent 620-2228 | -470 | -1608 | +1138 | 0.00 | 0.00 |
| L1220 | 2 | 1 | Mine 1815-200 | draw 1874-1922 | +1615 | -48 | +1663 | 0.00 | 0.00 |
| L1314 | 6 | 1 | Mine 1420-922 | Mine 1627-1029 | +498 | +598 | -100 | 0.00 | 0.00 |
| L1331 | 5 | 1 | Mine 1604-924 | draw 966-950 | +680 | +16 | +664 | 0.00 | 0.00 |
| L1427 | 5 | 1 | Mine 1500-516 | Mine 1807-808 | +984 | +999 | -15 | 0.00 | 0.00 |
| L1523 | 5 | 1 | Opponent 742-2008 | draw 1438-1512 | -1266 | -74 | -1192 | 0.00 | 0.00 |
| L1621 | 1 | 1 | draw 1719-1588 | draw 1335-1471 | +131 | -136 | +267 | 0.00 | 0.00 |
| L1719 | 3 | 1 | Mine 2200-1286 | Mine 2970-1191 | +914 | +1779 | -865 | 0.00 | 0.00 |
| L1819 | 1 | 1 | Opponent 646-1782 | Opponent 745-1272 | -1136 | -527 | -609 | 0.00 | 0.00 |
| L1835 | 5 | 1 | draw 1071-1334 | Opponent 502-843 | -263 | -341 | +78 | 0.00 | 0.00 |
| L2021 | 5 | 1 | Mine 1088-676 | Mine 1309-712 | +412 | +597 | -185 | 0.00 | 0.00 |
| L2123 | 5 | 1 | Opponent 731-2569 | Opponent 652-2576 | -1838 | -1924 | +86 | 0.00 | 0.00 |
| L2227 | 1 | 1 | Mine 2359-1014 | Mine 1757-1330 | +1345 | +427 | +918 | 0.00 | 0.00 |
| L2331 | 3 | 1 | Mine 2758-952 | Mine 2211-832 | +1806 | +1379 | +427 | 0.00 | 0.00 |
| L2527 | 1 | 1 | draw 936-1164 | Mine 1329-573 | -228 | +756 | -984 | 0.00 | 0.00 |
| L2634 | 6 | 1 | Opponent 622-1920 | draw 1730-1504 | -1298 | +226 | -1524 | 0.00 | 0.00 |
| L2930 | 2 | 1 | draw 1215-1122 | Opponent 726-1594 | +93 | -868 | +961 | 0.00 | 0.00 |
| L3234 | 6 | 1 | Mine 1254-412 | Mine 2447-644 | +842 | +1803 | -961 | 0.00 | 0.00 |

## Totals

| | A: groups on | B: groups off |
| --- | --- | --- |
| Mine won / drew / lost | 12 / 11 / 13 | 12 / 11 / 13 |
| Mean margin (Mine - Opponent) | -83 | -119 |
| Cost per game | $0.000 | $0.000 |
| Mine side per game | $0.000 | $0.000 |
| Opponent side per game | $0.000 | $0.000 |
| Cost of the batch | $0.00 | $0.00 |
| Failed calls per game | 0.0 | 0.0 |
| VP from objectives, Mine | 538 | 550 |
| VP from objectives, Opponent | 531 | 519 |
| VP from kills, Mine | 746 | 704 |
| VP from kills, Opponent | 811 | 823 |
| VP from leaders, Mine | 40 | 46 |
| VP from leaders, Opponent | 64 | 75 |
| VP from other, Mine | 0 | 0 |
| VP from other, Opponent | 1 | 1 |
| Units lost, Mine | 5.4 | 5.0 |
| Units lost, Opponent | 5.0 | 4.8 |
| Scorecard: Far marker / quarter contested by round 3 (both sides) | 43% | 41% |
| Scorecard: Lone holders (player turns) (both sides) | 2.6 | 2.5 |
| Scorecard: Round of the first Hammer charge (both sides) | 2.6 | 2.7 |
| Scorecard: Lone charges into a block / monster / character (both sides) | 3.1 | 3.1 |
| Scorecard: Idle units (both sides) | 1.5 | 1.5 |
| Scorecard: Wounded Lords / monsters lost (both sides) | 0.4 | 0.3 |
| Scorecard: Doctrine flags raised (both sides) | 0.0 | 0.0 |
| Scorecard: Answers changed after a flag (both sides) | 0.0 | 0.0 |
| Scorecard: Points that never moved of their own (both sides) | 184.0 | 180.2 |

## Is the difference more than noise?

36 pairs of games: A's margin is +36 VP a game against B's, give or take 276 VP (two standard errors). Verdict: within noise (could be chance).

## KPIs (Morten 2026-11-10)

A = groups on (36 games), B = groups off (36 games).

| KPI | Target | A Mine | A Opponent | A both | B Mine | B Opponent | B both |
| --- | --- | --- | --- | --- | --- | --- | --- |
| Winner chose to follow up after the loser gave ground |  | 96%; on the table 96% | 100%; on the table 100% | 98%; on the table 98% | 97%; on the table 97% | 100%; on the table 100% | 98%; on the table 98% |
| Winner chose to pursue after the loser fell back in good order |  | 93%; on the table 93% | 83%; on the table 83% | 88%; on the table 88% | 93%; on the table 93% | 100%; on the table 100% | 96%; on the table 96% |
| Winner chose to pursue after the loser fled |  | 86%; on the table 86% | 77%; on the table 83% | 80%; on the table 84% | 72%; on the table 76% | 81%; on the table 86% | 78%; on the table 82% |
| Winner chose to follow up or pursue (all three) |  | 94%; on the table 94% | 90%; on the table 92% | 92%; on the table 93% | 90%; on the table 91% | 93%; on the table 94% | 91%; on the table 93% |
| Magic missiles tried each own turn | 50%+ | 21% | 20% | 20% | 25% | 29% | 27% |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 32% | 30% | 31% | 43% | 43% | 43% |
| Points that never fought | lower | 34% | 32% | 33% | 29% | 28% | 29% |
|   infantry points that never fought | lower | 41% | 60% | 50% | 33% | 57% | 44% |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 56% | 52% | 54% | 59% | 52% | 56% |
| Bound items with a magic missile used (at least once a game) |  | 91% | 44% | 77% | 82% | 89% | 84% |
| Bound items with another spell used |  | 62% | 35% | 47% | 56% | 65% | 61% |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 53% | 73% | 62% | 53% | 67% | 59% |
|   their share of the points of units over 100 pts | lower | 50% | 45% | 47% | 54% | 43% | 48% |

Flank and rear charges a unit could have turned to face (the side is the charged unit's):

| Measure | groups on Mine | groups on Opponent | groups off Mine | groups off Opponent |
| --- | --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 50% (55) | 46% (32) | 37% (40) | 58% (49) |
| ...free all their last turn and able to turn (per game) | 0.89 | 0.64 | 0.61 | 0.83 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.22 | 0.06 | 0.19 | 0.25 |
| ...with the charger already in that arc before they moved (per game) | 0.56 | 0.44 | 0.44 | 0.50 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 1.36 | 0.97 | 1.72 | 1.17 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.89 | 0.67 | 1.31 | 0.58 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 9.97 | 10.72 | 9.19 | 9.92 |

### Charges a game and per unit by the wizard it carries

| Charges | A Mine | A Opponent | A both | B Mine | B Opponent | B both |
| --- | --- | --- | --- | --- | --- | --- |
| Charges declared a game | 4.4 | 6.9 | 5.7 | 4.4 | 6.4 | 5.4 |
| Charges that made contact a game | 3.3 | 5.0 | 4.2 | 3.2 | 4.9 | 4.1 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.00 declared, 0.94 contact (17 units) | 0.89 declared, 0.78 contact (18 units) | 0.94 declared, 0.86 contact (35 units) | 0.94 declared, 0.88 contact (17 units) | 1.22 declared, 1.06 contact (18 units) | 1.09 declared, 0.97 contact (35 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.67 declared, 0.67 contact (9 units) | 1.55 declared, 1.09 contact (11 units) | 1.15 declared, 0.90 contact (20 units) | 0.75 declared, 0.62 contact (8 units) | 1.36 declared, 0.91 contact (11 units) | 1.11 declared, 0.79 contact (19 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.54 declared, 0.39 contact (249 units) | 0.72 declared, 0.52 contact (300 units) | 0.64 declared, 0.46 contact (549 units) | 0.54 declared, 0.39 contact (248 units) | 0.64 declared, 0.49 contact (301 units) | 0.60 declared, 0.44 contact (549 units) |

## Movement (Morten 2026-11-11)

A = groups on (36 games), B = groups off (36 games); per side and game.

| Measure | A Mine | A Opponent | A both | B Mine | B Opponent | B both |
| --- | --- | --- | --- | --- | --- | --- |
| Games where this side made the first charge contact | 47% (17 of 36) | 53% (19 of 36) | 50% (36 of 72) | 42% (15 of 36) | 58% (21 of 36) | 50% (36 of 72) |
| Round of a side's first charge contact (sides that made one) | 2.6 | 2.6 | 2.6 | 3.0 | 2.7 | 2.8 |
| Sides that never declared a charge | 6% (2 of 36) | 0% (0 of 36) | 3% (2 of 72) | 0% (0 of 36) | 0% (0 of 36) | 0% (0 of 72) |
| Sides that never made charge contact | 6% (2 of 36) | 0% (0 of 36) | 3% (2 of 72) | 3% (1 of 36) | 0% (0 of 36) | 1% (1 of 72) |
| Charges declared a game | 4.5 | 6.8 | 5.7 | 4.6 | 6.1 | 5.4 |
| Charge contacts made a game | 3.4 | 4.9 | 4.2 | 3.4 | 4.7 | 4.1 |
| Charge contacts received a game | 4.9 | 3.4 | 4.2 | 4.7 | 3.4 | 4.1 |
| Joint charges a game (2+ units on one target in one turn) | 0.2 | 0.7 | 0.5 | 0.2 | 0.6 | 0.4 |
|   share of charged targets hit by 2+ units | 7% (8 of 115) | 18% (26 of 146) | 13% (34 of 261) | 7% (8 of 114) | 14% (21 of 146) | 11% (29 of 260) |
| Lone charges that a friend follows on the same target next turn | 5% (5 of 107) | 6% (7 of 120) | 5% (12 of 227) | 5% (5 of 106) | 8% (10 of 125) | 6% (15 of 231) |
| Set-ups (close in to charge next turn) that charged that target next turn | 15% (27 of 175) | 17% (33 of 193) | 16% (60 of 368) | 9% (16 of 169) | 18% (34 of 193) | 14% (50 of 362) |
|   ... and made contact | 13% (22 of 175) | 12% (24 of 193) | 12% (46 of 368) | 7% (12 of 169) | 14% (27 of 193) | 11% (39 of 362) |
|   ... with a friend on it too | 1% (1 of 175) | 3% (5 of 193) | 2% (6 of 368) | 0% (0 of 169) | 2% (4 of 193) | 1% (4 of 362) |
| Set-ups missed (no charge on that target next turn) | 85% (148 of 175) | 83% (160 of 193) | 84% (308 of 368) | 91% (153 of 169) | 82% (159 of 193) | 86% (312 of 362) |
| Charge contacts in the flank or rear (arc known) | 49% (60 of 123) | 51% (90 of 177) | 50% (150 of 300) | 56% (68 of 122) | 40% (68 of 170) | 47% (136 of 292) |
|   in the rear | 11% (14 of 123) | 10% (17 of 177) | 10% (31 of 300) | 6% (7 of 122) | 11% (18 of 170) | 9% (25 of 292) |
| Declared charges in the flank or rear (arc known) | 46% (74 of 162) | 51% (125 of 245) | 49% (199 of 407) | 54% (89 of 165) | 42% (93 of 221) | 47% (182 of 386) |

## Doctrine scorecard (per game and side; far = share of games contested)

### Scorecard: groups on

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0114 | 6 | 1 | Mine | yes | 10 | 3 | 2 | 1 | 0 | 0 | 0 | 0 |
| L0114 | 6 | 1 | Opponent | no | 1 | 1 | 4 | 2 | 0 | 0 | 0 | 0 |
| L0130 | 4 | 1 | Mine | yes | 0 | 6 | 1 | 3 | 0 | 0 | 0 | 0 |
| L0130 | 4 | 1 | Opponent | no | 0 | 2 | 2 | 4 | 1 | 0 | 0 | 70 |
| L0214 | 4 | 1 | Mine | no | 0 | 6 | 2 | 3 | 1 | 0 | 0 | 170 |
| L0214 | 4 | 1 | Opponent | no | 1 | 1 | 5 | 0 | 0 | 0 | 0 | 177 |
| L0230 | 2 | 1 | Mine | - | - | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L0230 | 2 | 1 | Opponent | - | - | 3 | 2 | 1 | 0 | 0 | 0 | 0 |
| L0315 | 3 | 1 | Mine | yes | 5 | 3 | 4 | 0 | 0 | 0 | 0 | 760 |
| L0315 | 3 | 1 | Opponent | yes | 1 | 2 | 3 | 1 | 1 | 0 | 0 | 0 |
| L0332 | 2 | 1 | Mine | - | - | 3 | 1 | 0 | 1 | 0 | 0 | 590 |
| L0332 | 2 | 1 | Opponent | - | - | 1 | 5 | 3 | 0 | 0 | 0 | 170 |
| L0417 | 3 | 1 | Mine | yes | 4 | 2 | 7 | 1 | 1 | 0 | 0 | 0 |
| L0417 | 3 | 1 | Opponent | yes | 8 | 2 | 5 | 0 | 0 | 0 | 0 | 135 |
| L0434 | 2 | 1 | Mine | - | - | 3 | 5 | 0 | 0 | 0 | 0 | 0 |
| L0434 | 2 | 1 | Opponent | - | - | 1 | 5 | 1 | 0 | 0 | 0 | 0 |
| L0520 | 4 | 1 | Mine | no | 0 | 3 | 2 | 0 | 0 | 0 | 0 | 698 |
| L0520 | 4 | 1 | Opponent | no | 0 | 6 | 2 | 4 | 1 | 0 | 0 | 420 |
| L0608 | 2 | 1 | Mine | - | - | 3 | 1 | 2 | 0 | 0 | 0 | 926 |
| L0608 | 2 | 1 | Opponent | - | - | 5 | 2 | 2 | 0 | 0 | 0 | 605 |
| L0624 | 6 | 1 | Mine | no | 0 | 3 | 2 | 0 | 0 | 0 | 0 | 700 |
| L0624 | 6 | 1 | Opponent | no | 7 | 3 | 1 | 3 | 1 | 0 | 0 | 0 |
| L0713 | 5 | 1 | Mine | yes | - | 5 | 2 | 2 | 2 | 0 | 0 | 420 |
| L0713 | 5 | 1 | Opponent | yes | - | 3 | 2 | 3 | 0 | 0 | 0 | 317 |
| L0729 | 3 | 1 | Mine | no | 0 | 1 | 1 | 0 | 0 | 0 | 0 | 375 |
| L0729 | 3 | 1 | Opponent | no | 3 | 2 | 3 | 0 | 0 | 0 | 0 | 170 |
| L0819 | 3 | 1 | Mine | no | 0 | - | 0 | 0 | 0 | 0 | 0 | 515 |
| L0819 | 3 | 1 | Opponent | no | 6 | 2 | 1 | 3 | 0 | 0 | 0 | 0 |
| L0835 | 1 | 1 | Mine | no | 1 | 4 | 2 | 0 | 0 | 0 | 0 | 515 |
| L0835 | 1 | 1 | Opponent | no | 0 | 3 | 4 | 2 | 0 | 0 | 0 | 0 |
| L0926 | 2 | 1 | Mine | - | - | 2 | 1 | 1 | 0 | 0 | 0 | 677 |
| L0926 | 2 | 1 | Opponent | - | - | 2 | 3 | 3 | 0 | 0 | 0 | 0 |
| L1017 | 3 | 1 | Mine | yes | 11 | 2 | 3 | 0 | 0 | 0 | 0 | 497 |
| L1017 | 3 | 1 | Opponent | yes | 4 | 2 | 4 | 2 | 2 | 0 | 0 | 175 |
| L1034 | 2 | 1 | Mine | - | - | 1 | 1 | 0 | 0 | 0 | 0 | 330 |
| L1034 | 2 | 1 | Opponent | - | - | 3 | 0 | 2 | 0 | 0 | 0 | 0 |
| L1126 | 4 | 1 | Mine | yes | 11 | 2 | 4 | 0 | 1 | 0 | 0 | 330 |
| L1126 | 4 | 1 | Opponent | no | 7 | 2 | 2 | 2 | 1 | 0 | 0 | 0 |
| L1220 | 2 | 1 | Mine | - | - | 2 | 4 | 0 | 0 | 0 | 0 | 330 |
| L1220 | 2 | 1 | Opponent | - | - | - | 4 | 3 | 1 | 0 | 0 | 0 |
| L1314 | 6 | 1 | Mine | no | 0 | 2 | 1 | 0 | 1 | 0 | 0 | 140 |
| L1314 | 6 | 1 | Opponent | no | 0 | 2 | 5 | 0 | 0 | 0 | 0 | 0 |
| L1331 | 5 | 1 | Mine | yes | - | 2 | 3 | 3 | 0 | 0 | 0 | 302 |
| L1331 | 5 | 1 | Opponent | yes | - | 4 | 1 | 1 | 2 | 0 | 0 | 456 |
| L1427 | 5 | 1 | Mine | yes | - | 3 | 3 | 1 | 0 | 0 | 0 | 0 |
| L1427 | 5 | 1 | Opponent | no | - | 2 | 4 | 3 | 0 | 0 | 0 | 0 |
| L1523 | 5 | 1 | Mine | yes | - | - | 1 | 0 | 1 | 0 | 0 | 176 |
| L1523 | 5 | 1 | Opponent | yes | - | 2 | 9 | 1 | 1 | 0 | 0 | 192 |
| L1621 | 1 | 1 | Mine | no | 0 | 3 | 5 | 1 | 1 | 0 | 0 | 200 |
| L1621 | 1 | 1 | Opponent | no | 0 | 4 | 2 | 3 | 0 | 0 | 0 | 290 |
| L1719 | 3 | 1 | Mine | no | 0 | 2 | 4 | 0 | 1 | 0 | 0 | 0 |
| L1719 | 3 | 1 | Opponent | yes | 2 | 2 | 6 | 0 | 1 | 0 | 0 | 0 |
| L1819 | 1 | 1 | Mine | no | 0 | 3 | 5 | 1 | 0 | 0 | 0 | 0 |
| L1819 | 1 | 1 | Opponent | no | 0 | 2 | 2 | 0 | 0 | 0 | 0 | 0 |
| L1835 | 5 | 1 | Mine | no | - | 4 | 4 | 3 | 1 | 0 | 0 | 0 |
| L1835 | 5 | 1 | Opponent | yes | - | 2 | 1 | 3 | 1 | 0 | 0 | 140 |
| L2021 | 5 | 1 | Mine | yes | - | - | 1 | 4 | 0 | 0 | 0 | 210 |
| L2021 | 5 | 1 | Opponent | yes | - | 4 | 4 | 4 | 0 | 0 | 0 | 145 |
| L2123 | 5 | 1 | Mine | yes | - | - | 0 | 7 | 0 | 0 | 0 | 210 |
| L2123 | 5 | 1 | Opponent | yes | - | 3 | 2 | 2 | 0 | 0 | 0 | 126 |
| L2227 | 1 | 1 | Mine | yes | 2 | 2 | 2 | 0 | 0 | 0 | 0 | 0 |
| L2227 | 1 | 1 | Opponent | no | 0 | 1 | 5 | 2 | 1 | 0 | 0 | 60 |
| L2331 | 3 | 1 | Mine | yes | 11 | 3 | 5 | 0 | 2 | 0 | 0 | 0 |
| L2331 | 3 | 1 | Opponent | no | 3 | 3 | 4 | 2 | 2 | 0 | 0 | 170 |
| L2527 | 1 | 1 | Mine | no | 0 | 2 | 2 | 2 | 0 | 0 | 0 | 0 |
| L2527 | 1 | 1 | Opponent | no | 0 | 1 | 4 | 3 | 0 | 0 | 0 | 250 |
| L2634 | 6 | 1 | Mine | no | 3 | 2 | 4 | 1 | 1 | 0 | 0 | 0 |
| L2634 | 6 | 1 | Opponent | no | 2 | 2 | 4 | 1 | 0 | 0 | 0 | 107 |
| L2930 | 2 | 1 | Mine | - | - | 2 | 8 | 2 | 0 | 0 | 0 | 0 |
| L2930 | 2 | 1 | Opponent | - | - | 2 | 4 | 2 | 0 | 0 | 0 | 0 |
| L3234 | 6 | 1 | Mine | no | 6 | 2 | 4 | 2 | 0 | 0 | 0 | 0 |
| L3234 | 6 | 1 | Opponent | no | 0 | 4 | 3 | 1 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 50% | 3.0 | 2.8 | 2.8 | 1.1 | 0.4 | 0.0 | 0.0 | 252.0 |
| **Average** | | | Opponent | 36% | 2.1 | 2.5 | 3.3 | 1.9 | 0.4 | 0.0 | 0.0 | 116.0 |

### Scorecard: groups off

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0114 | 6 | 1 | Mine | yes | 8 | 3 | 1 | 1 | 1 | 0 | 0 | 65 |
| L0114 | 6 | 1 | Opponent | no | 2 | 1 | 5 | 0 | 0 | 0 | 0 | 0 |
| L0130 | 4 | 1 | Mine | yes | 0 | 4 | 2 | 2 | 0 | 0 | 0 | 0 |
| L0130 | 4 | 1 | Opponent | no | 2 | 2 | 3 | 4 | 0 | 0 | 0 | 70 |
| L0214 | 4 | 1 | Mine | yes | 0 | 2 | 2 | 3 | 1 | 0 | 0 | 0 |
| L0214 | 4 | 1 | Opponent | no | 3 | 1 | 3 | 0 | 0 | 0 | 0 | 0 |
| L0230 | 2 | 1 | Mine | - | - | 2 | 4 | 3 | 0 | 0 | 0 | 0 |
| L0230 | 2 | 1 | Opponent | - | - | 3 | 3 | 0 | 0 | 0 | 0 | 0 |
| L0315 | 3 | 1 | Mine | no | 1 | 2 | 2 | 0 | 1 | 0 | 0 | 675 |
| L0315 | 3 | 1 | Opponent | yes | 1 | 2 | 4 | 0 | 1 | 0 | 0 | 0 |
| L0332 | 2 | 1 | Mine | - | - | 4 | 3 | 1 | 0 | 0 | 0 | 590 |
| L0332 | 2 | 1 | Opponent | - | - | 1 | 4 | 6 | 0 | 0 | 0 | 0 |
| L0417 | 3 | 1 | Mine | yes | 8 | 2 | 6 | 0 | 1 | 0 | 0 | 0 |
| L0417 | 3 | 1 | Opponent | yes | 6 | 2 | 2 | 0 | 1 | 0 | 0 | 0 |
| L0434 | 2 | 1 | Mine | - | - | 2 | 5 | 1 | 0 | 0 | 0 | 0 |
| L0434 | 2 | 1 | Opponent | - | - | 1 | 1 | 2 | 0 | 0 | 0 | 0 |
| L0520 | 4 | 1 | Mine | no | 0 | 3 | 2 | 0 | 0 | 0 | 0 | 1120 |
| L0520 | 4 | 1 | Opponent | no | 5 | 6 | 3 | 6 | 0 | 0 | 0 | 420 |
| L0608 | 2 | 1 | Mine | - | - | 3 | 1 | 1 | 0 | 0 | 0 | 798 |
| L0608 | 2 | 1 | Opponent | - | - | 4 | 1 | 1 | 0 | 0 | 0 | 605 |
| L0624 | 6 | 1 | Mine | no | 1 | 3 | 4 | 0 | 0 | 0 | 0 | 798 |
| L0624 | 6 | 1 | Opponent | no | 0 | 4 | 2 | 0 | 0 | 0 | 0 | 0 |
| L0713 | 5 | 1 | Mine | yes | - | 6 | 0 | 1 | 0 | 0 | 0 | 420 |
| L0713 | 5 | 1 | Opponent | no | - | 3 | 4 | 2 | 0 | 0 | 0 | 479 |
| L0729 | 3 | 1 | Mine | yes | 0 | 2 | 3 | 0 | 0 | 0 | 0 | 375 |
| L0729 | 3 | 1 | Opponent | no | 2 | 2 | 2 | 1 | 1 | 0 | 0 | 170 |
| L0819 | 3 | 1 | Mine | no | 0 | 6 | 1 | 0 | 0 | 0 | 0 | 515 |
| L0819 | 3 | 1 | Opponent | no | 4 | 2 | 2 | 2 | 0 | 0 | 0 | 0 |
| L0835 | 1 | 1 | Mine | no | 0 | 4 | 3 | 1 | 0 | 0 | 0 | 515 |
| L0835 | 1 | 1 | Opponent | no | 3 | 3 | 2 | 4 | 0 | 0 | 0 | 0 |
| L0926 | 2 | 1 | Mine | - | - | 2 | 1 | 0 | 0 | 0 | 0 | 632 |
| L0926 | 2 | 1 | Opponent | - | - | 3 | 1 | 4 | 1 | 0 | 0 | 0 |
| L1017 | 3 | 1 | Mine | yes | 10 | 2 | 5 | 1 | 0 | 0 | 0 | 330 |
| L1017 | 3 | 1 | Opponent | yes | 2 | 3 | 5 | 1 | 2 | 0 | 0 | 175 |
| L1034 | 2 | 1 | Mine | - | - | 1 | 4 | 0 | 1 | 0 | 0 | 330 |
| L1034 | 2 | 1 | Opponent | - | - | 3 | 2 | 1 | 0 | 0 | 0 | 0 |
| L1126 | 4 | 1 | Mine | no | 0 | 3 | 1 | 0 | 0 | 0 | 0 | 330 |
| L1126 | 4 | 1 | Opponent | no | 0 | 2 | 2 | 3 | 0 | 0 | 0 | 0 |
| L1220 | 2 | 1 | Mine | - | - | 2 | 6 | 0 | 2 | 0 | 0 | 330 |
| L1220 | 2 | 1 | Opponent | - | - | - | 3 | 4 | 1 | 0 | 0 | 0 |
| L1314 | 6 | 1 | Mine | yes | 4 | 6 | 2 | 1 | 0 | 0 | 0 | 140 |
| L1314 | 6 | 1 | Opponent | no | 10 | 2 | 2 | 0 | 1 | 0 | 0 | 0 |
| L1331 | 5 | 1 | Mine | no | - | 2 | 3 | 2 | 1 | 0 | 0 | 479 |
| L1331 | 5 | 1 | Opponent | yes | - | - | 1 | 2 | 2 | 0 | 0 | 456 |
| L1427 | 5 | 1 | Mine | yes | - | 3 | 4 | 1 | 0 | 0 | 0 | 0 |
| L1427 | 5 | 1 | Opponent | yes | - | 2 | 6 | 0 | 0 | 0 | 0 | 0 |
| L1523 | 5 | 1 | Mine | yes | - | 2 | 6 | 0 | 1 | 0 | 0 | 0 |
| L1523 | 5 | 1 | Opponent | yes | - | 2 | 6 | 2 | 0 | 0 | 0 | 126 |
| L1621 | 1 | 1 | Mine | no | 0 | - | 1 | 2 | 0 | 0 | 0 | 200 |
| L1621 | 1 | 1 | Opponent | no | 0 | 3 | 2 | 4 | 0 | 0 | 0 | 290 |
| L1719 | 3 | 1 | Mine | no | 5 | 2 | 5 | 0 | 0 | 0 | 0 | 0 |
| L1719 | 3 | 1 | Opponent | yes | 1 | 2 | 5 | 0 | 0 | 0 | 0 | 490 |
| L1819 | 1 | 1 | Mine | no | 0 | 5 | 2 | 1 | 0 | 0 | 0 | 0 |
| L1819 | 1 | 1 | Opponent | no | 0 | 2 | 5 | 0 | 0 | 0 | 0 | 0 |
| L1835 | 5 | 1 | Mine | yes | - | 2 | 0 | 1 | 0 | 0 | 0 | 0 |
| L1835 | 5 | 1 | Opponent | yes | - | 3 | 5 | 2 | 0 | 0 | 0 | 140 |
| L2021 | 5 | 1 | Mine | yes | - | 4 | 0 | 3 | 1 | 0 | 0 | 210 |
| L2021 | 5 | 1 | Opponent | no | - | 6 | 4 | 3 | 0 | 0 | 0 | 145 |
| L2123 | 5 | 1 | Mine | yes | - | - | 2 | 5 | 1 | 0 | 0 | 420 |
| L2123 | 5 | 1 | Opponent | yes | - | 2 | 2 | 2 | 0 | 0 | 0 | 0 |
| L2227 | 1 | 1 | Mine | yes | 3 | 3 | 1 | 1 | 1 | 0 | 0 | 72 |
| L2227 | 1 | 1 | Opponent | no | 0 | 1 | 7 | 2 | 0 | 0 | 0 | 0 |
| L2331 | 3 | 1 | Mine | no | 10 | 4 | 6 | 0 | 0 | 0 | 0 | 66 |
| L2331 | 3 | 1 | Opponent | no | 1 | - | 1 | 2 | 1 | 0 | 0 | 0 |
| L2527 | 1 | 1 | Mine | no | 0 | 4 | 4 | 2 | 0 | 0 | 0 | 0 |
| L2527 | 1 | 1 | Opponent | no | 2 | 1 | 2 | 4 | 0 | 0 | 0 | 0 |
| L2634 | 6 | 1 | Mine | no | 9 | 2 | 2 | 0 | 0 | 0 | 0 | 0 |
| L2634 | 6 | 1 | Opponent | no | 0 | 1 | 7 | 0 | 1 | 0 | 0 | 0 |
| L2930 | 2 | 1 | Mine | - | - | 2 | 8 | 2 | 0 | 0 | 0 | 0 |
| L2930 | 2 | 1 | Opponent | - | - | 3 | 3 | 1 | 0 | 0 | 0 | 0 |
| L3234 | 6 | 1 | Mine | no | 0 | 2 | 6 | 2 | 0 | 0 | 0 | 0 |
| L3234 | 6 | 1 | Opponent | no | 0 | 2 | 2 | 2 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 50% | 2.8 | 3.0 | 3.0 | 1.1 | 0.3 | 0.0 | 0.0 | 261.4 |
| **Average** | | | Opponent | 32% | 2.1 | 2.4 | 3.2 | 1.9 | 0.3 | 0.0 | 0.0 | 99.1 |


## Charged fights (points per fight a side charged into; a combined charge is one fight)

### Charged fights: groups on

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 195 | 69 | 2.2 | 1.0 | 31 | 6 | +25 | 2 of 9 | 8 of 9 | - | +25 |
| Mine | Chaos Dwarfs | 4 | 204 | 144 | 4.5 | 1.1 | 32 | 108 | -76 | 7 of 18 | 14 of 18 | +0 | -80 |
| Mine | Dwarfen Mountain Holds | 3 | 578 | 71 | 1.7 | 1.0 | 43 | 0 | +43 | 3 of 5 | 4 of 5 | - | +43 |
| Mine | Empire of Man | 5 | 292 | 176 | 1.4 | 1.1 | 126 | 0 | +126 | 3 of 7 | 6 of 7 | +177 | +117 |
| Mine | Grand Cathay | 4 | 412 | 226 | 4.2 | 1.2 | 53 | 17 | +36 | 4 of 17 | 14 of 17 | +37 | +35 |
| Mine | High Elf Realms | 4 | 426 | 164 | 2.8 | 1.0 | 60 | 32 | +28 | 3 of 11 | 7 of 11 | - | +28 |
| Mine | Kingdom of Bretonnia | 1 | 120 | 0 | 3.0 | 1.0 | 0 | 92 | -92 | 2 of 3 | 1 of 3 | - | -92 |
| Mine | Lizardmen | 1 | 55 | 1419 | 4.0 | 1.2 | 355 | 0 | +355 | 3 of 4 | 3 of 4 | +0 | +473 |
| Mine | Ogre Kingdoms | 2 | 57 | 412 | 6.5 | 1.0 | 63 | 49 | +15 | 8 of 13 | 7 of 13 | - | +15 |
| Mine | Skaven | 2 | 233 | 56 | 0.5 | 1.0 | 112 | 0 | +112 | 0 of 1 | 0 of 1 | - | +112 |
| Mine | Tomb Kings of Khemri | 2 | 173 | 666 | 4.5 | 1.1 | 148 | 43 | +105 | 3 of 9 | 6 of 9 | +75 | +108 |
| Mine | Vampire Counts | 2 | 25 | 206 | 4.0 | 1.0 | 52 | 25 | +27 | 2 of 8 | 7 of 8 | - | +27 |
| Mine | Warriors of Chaos | 2 | 0 | 314 | 5.0 | 1.1 | 63 | 0 | +63 | 4 of 10 | 8 of 10 | +91 | +60 |
| **Mine** | all armies | 36 | 258 | 229 | 3.2 | 1.1 | 72 | 36 | +36 | 44 of 115 | 85 of 115 | +57 | +34 |
| Opponent | Empire of Man | 1 | 903 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 0 of 1 | 1 of 1 | - | +0 |
| Opponent | High Elf Realms | 5 | 249 | 453 | 3.6 | 1.2 | 126 | 92 | +34 | 8 of 18 | 7 of 18 | +113 | +18 |
| Opponent | Lizardmen | 2 | 138 | 384 | 4.5 | 1.3 | 85 | 120 | -35 | 4 of 9 | 4 of 9 | +90 | -97 |
| Opponent | Orc & Goblin Tribes | 3 | 0 | 561 | 3.3 | 1.1 | 168 | 43 | +126 | 3 of 10 | 5 of 10 | +175 | +120 |
| Opponent | Skaven | 4 | 0 | 190 | 2.5 | 1.0 | 76 | 24 | +52 | 5 of 10 | 7 of 10 | - | +52 |
| Opponent | Tomb Kings of Khemri | 2 | 90 | 862 | 4.0 | 1.0 | 216 | 101 | +115 | 4 of 8 | 4 of 8 | - | +115 |
| Opponent | Vampire Counts | 6 | 38 | 566 | 5.2 | 1.3 | 110 | 35 | +75 | 18 of 31 | 14 of 31 | +198 | +39 |
| Opponent | Warriors of Chaos | 7 | 12 | 439 | 3.6 | 1.1 | 123 | 23 | +100 | 9 of 25 | 17 of 25 | +181 | +89 |
| Opponent | Wood Elf Realms | 6 | 71 | 395 | 5.7 | 1.3 | 70 | 14 | +56 | 10 of 34 | 17 of 34 | +97 | +41 |
| **Opponent** | all armies | 36 | 93 | 446 | 4.1 | 1.2 | 110 | 43 | +67 | 61 of 146 | 76 of 146 | +138 | +51 |

### Charged fights: groups off

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 230 | 80 | 3.0 | 1.0 | 27 | 14 | +12 | 3 of 12 | 10 of 12 | - | +12 |
| Mine | Chaos Dwarfs | 4 | 94 | 240 | 3.8 | 1.0 | 64 | 77 | -12 | 5 of 15 | 9 of 15 | - | -12 |
| Mine | Dwarfen Mountain Holds | 3 | 263 | 227 | 2.3 | 1.1 | 97 | 0 | +97 | 4 of 7 | 4 of 7 | +0 | +113 |
| Mine | Empire of Man | 5 | 308 | 32 | 1.8 | 1.0 | 18 | 92 | -74 | 3 of 9 | 6 of 9 | - | -74 |
| Mine | Grand Cathay | 4 | 286 | 337 | 4.8 | 1.1 | 71 | 38 | +33 | 5 of 19 | 15 of 19 | -92 | +48 |
| Mine | High Elf Realms | 4 | 351 | 538 | 3.0 | 1.1 | 179 | 5 | +174 | 4 of 12 | 11 of 12 | +177 | +174 |
| Mine | Kingdom of Bretonnia | 1 | 210 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Mine | Lizardmen | 1 | 55 | 1579 | 5.0 | 1.2 | 316 | 28 | +288 | 3 of 5 | 4 of 5 | +110 | +332 |
| Mine | Ogre Kingdoms | 2 | 0 | 51 | 1.5 | 1.0 | 34 | 0 | +34 | 2 of 3 | 2 of 3 | - | +34 |
| Mine | Skaven | 2 | 72 | 89 | 2.0 | 1.0 | 44 | 0 | +44 | 0 of 4 | 2 of 4 | - | +44 |
| Mine | Tomb Kings of Khemri | 2 | 0 | 469 | 4.0 | 1.0 | 117 | 74 | +43 | 3 of 8 | 4 of 8 | - | +43 |
| Mine | Vampire Counts | 2 | 14 | 91 | 3.5 | 1.3 | 26 | 22 | +4 | 3 of 7 | 4 of 7 | -2 | +6 |
| Mine | Warriors of Chaos | 2 | 0 | 680 | 6.5 | 1.1 | 105 | 38 | +67 | 3 of 13 | 9 of 13 | +27 | +70 |
| **Mine** | all armies | 36 | 184 | 277 | 3.2 | 1.1 | 87 | 38 | +50 | 38 of 114 | 80 of 114 | +16 | +52 |
| Opponent | Empire of Man | 1 | 220 | 0 | 1.0 | 2.0 | 0 | 252 | -252 | 1 of 1 | 0 of 1 | -252 | - |
| Opponent | High Elf Realms | 5 | 69 | 888 | 6.0 | 1.2 | 148 | 38 | +110 | 13 of 30 | 18 of 30 | +399 | +65 |
| Opponent | Lizardmen | 2 | 68 | 686 | 5.0 | 1.2 | 137 | 37 | +100 | 3 of 10 | 6 of 10 | +120 | +98 |
| Opponent | Orc & Goblin Tribes | 3 | 30 | 391 | 5.0 | 1.0 | 78 | 38 | +40 | 3 of 15 | 9 of 15 | - | +40 |
| Opponent | Skaven | 4 | 216 | 52 | 3.0 | 1.1 | 18 | 29 | -12 | 5 of 12 | 8 of 12 | +210 | -32 |
| Opponent | Tomb Kings of Khemri | 2 | 58 | 1038 | 5.0 | 1.2 | 208 | 14 | +194 | 4 of 10 | 7 of 10 | +226 | +186 |
| Opponent | Vampire Counts | 6 | 65 | 489 | 4.2 | 1.3 | 117 | 32 | +85 | 15 of 25 | 17 of 25 | +236 | +38 |
| Opponent | Warriors of Chaos | 7 | 8 | 434 | 2.3 | 1.0 | 190 | 18 | +172 | 10 of 16 | 9 of 16 | - | +172 |
| Opponent | Wood Elf Realms | 6 | 132 | 534 | 4.5 | 1.2 | 119 | 63 | +55 | 11 of 27 | 14 of 27 | +167 | +24 |
| **Opponent** | all armies | 36 | 84 | 512 | 4.1 | 1.2 | 126 | 39 | +88 | 65 of 146 | 88 of 146 | +216 | +66 |


## Effective charges (55-75% to win the first round: just enough force)

### Effective charges: groups on

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 9 | 0 | 0 | 0 | 1 (net +0) | 0 | 4 (net +12) | 4 | 0% (0 of 5) |
| Mine | Chaos Dwarfs | 18 | 3 (net -145) | 0 | 4 (net -254) | 1 (net +0) | 3 (net +30) | 4 (net +44) | 3 | 27% (4 of 15) |
| Mine | Dwarfen Mountain Holds | 5 | 0 | 0 | 1 (net +0) | 2 (net +0) | 0 | 2 (net +107) | 0 | 20% (1 of 5) |
| Mine | Empire of Man | 7 | 2 (net +0) | 0 | 0 | 0 | 0 | 3 (net +203) | 2 | 0% (0 of 5) |
| Mine | Grand Cathay | 17 | 0 | 1 (net +109) | 3 (net +54) | 2 (net +70) | 3 (net +68) | 8 (net -1) | 0 | 18% (3 of 17) |
| Mine | High Elf Realms | 11 | 1 (net +233) | 0 | 3 (net -116) | 4 (net +16) | 1 (net +0) | 1 (net +314) | 1 | 30% (3 of 10) |
| Mine | Kingdom of Bretonnia | 3 | 0 | 0 | 0 | 0 | 0 | 2 (net -138) | 1 | 0% (0 of 2) |
| Mine | Lizardmen | 4 | 0 | 0 | 1 (net +0) | 2 (net +582) | 0 | 1 (net +255) | 0 | 25% (1 of 4) |
| Mine | Ogre Kingdoms | 13 | 2 (net -56) | 1 (net +0) | 3 (net -25) | 1 (net +274) | 1 (net +0) | 2 (net +79) | 3 | 30% (3 of 10) |
| Mine | Skaven | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +112) | 0 | 0% (0 of 1) |
| Mine | Tomb Kings of Khemri | 9 | 1 (net +0) | 0 | 3 (net -8) | 2 (net +197) | 1 (net +75) | 1 (net +693) | 1 | 38% (3 of 8) |
| Mine | Vampire Counts | 8 | 1 (net -197) | 0 | 0 | 3 (net +9) | 2 (net +111) | 2 (net +82) | 0 | 0% (0 of 8) |
| Mine | Warriors of Chaos | 10 | 0 | 0 | 1 (net +0) | 1 (net +27) | 2 (net +134) | 4 (net +61) | 2 | 12% (1 of 8) |
| Opponent | High Elf Realms | 18 | 1 (net -123) | 2 (net -322) | 3 (net -183) | 1 (net +115) | 1 (net +55) | 6 (net +244) | 4 | 21% (3 of 14) |
| Opponent | Lizardmen | 9 | 3 (net -58) | 0 | 0 | 2 (net -202) | 2 (net -20) | 2 (net +155) | 0 | 0% (0 of 9) |
| Opponent | Orc & Goblin Tribes | 10 | 0 | 0 | 1 (net +347) | 2 (net +250) | 0 | 0 | 7 | 33% (1 of 3) |
| Opponent | Skaven | 10 | 1 (net +0) | 1 (net +0) | 2 (net +380) | 1 (net +0) | 1 (net +0) | 3 (net -81) | 1 | 22% (2 of 9) |
| Opponent | Tomb Kings of Khemri | 8 | 0 | 0 | 2 (net +206) | 1 (net +45) | 0 | 2 (net +358) | 3 | 40% (2 of 5) |
| Opponent | Vampire Counts | 31 | 7 (net -80) | 0 | 3 (net +105) | 10 (net +21) | 2 (net +0) | 6 (net +339) | 3 | 11% (3 of 28) |
| Opponent | Warriors of Chaos | 25 | 2 (net +276) | 0 | 3 (net -33) | 2 (net +252) | 4 (net +44) | 11 (net +100) | 3 | 14% (3 of 22) |
| Opponent | Wood Elf Realms | 34 | 7 (net +75) | 1 (net +0) | 6 (net +51) | 4 (net +10) | 6 (net +58) | 9 (net +78) | 1 | 18% (6 of 33) |

### Effective charges: groups off

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 12 | 0 | 0 | 2 (net +49) | 3 (net +0) | 0 | 5 (net +27) | 2 | 20% (2 of 10) |
| Mine | Chaos Dwarfs | 15 | 3 (net -103) | 1 (net -339) | 1 (net -499) | 3 (net +81) | 0 | 5 (net +109) | 2 | 8% (1 of 13) |
| Mine | Dwarfen Mountain Holds | 7 | 1 (net +0) | 0 | 0 | 3 (net +227) | 0 | 3 (net +0) | 0 | 0% (0 of 7) |
| Mine | Empire of Man | 9 | 0 | 0 | 2 (net -155) | 0 | 3 (net -147) | 3 (net +0) | 1 | 25% (2 of 8) |
| Mine | Grand Cathay | 19 | 2 (net -92) | 0 | 5 (net +61) | 5 (net +75) | 0 | 6 (net +18) | 1 | 28% (5 of 18) |
| Mine | High Elf Realms | 12 | 0 | 0 | 0 | 3 (net +217) | 5 (net +86) | 4 (net +253) | 0 | 0% (0 of 12) |
| Mine | Lizardmen | 5 | 0 | 0 | 1 (net +114) | 3 (net +441) | 0 | 1 (net +0) | 0 | 20% (1 of 5) |
| Mine | Ogre Kingdoms | 3 | 0 | 0 | 1 (net +102) | 0 | 0 | 1 (net +0) | 1 | 50% (1 of 2) |
| Mine | Skaven | 4 | 0 | 0 | 0 | 0 | 0 | 4 (net +44) | 0 | 0% (0 of 4) |
| Mine | Tomb Kings of Khemri | 8 | 1 (net +0) | 0 | 1 (net +296) | 2 (net +58) | 2 (net +27) | 2 (net -60) | 0 | 12% (1 of 8) |
| Mine | Vampire Counts | 7 | 0 | 1 (net -45) | 3 (net +0) | 1 (net +0) | 0 | 2 (net +36) | 0 | 43% (3 of 7) |
| Mine | Warriors of Chaos | 13 | 0 | 1 (net -494) | 3 (net +294) | 1 (net +0) | 1 (net +27) | 4 (net +113) | 3 | 30% (3 of 10) |
| Opponent | Empire of Man | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net -252) | 0 | 0% (0 of 1) |
| Opponent | High Elf Realms | 30 | 2 (net +243) | 1 (net +0) | 4 (net +13) | 8 (net +82) | 4 (net +48) | 9 (net +228) | 2 | 14% (4 of 28) |
| Opponent | Lizardmen | 10 | 2 (net -32) | 0 | 2 (net +0) | 3 (net +302) | 0 | 1 (net +221) | 2 | 25% (2 of 8) |
| Opponent | Orc & Goblin Tribes | 15 | 0 | 0 | 0 | 0 | 1 (net +0) | 1 (net +214) | 13 | 0% (0 of 2) |
| Opponent | Skaven | 12 | 3 (net +0) | 0 | 3 (net +0) | 0 | 1 (net +0) | 2 (net +105) | 3 | 33% (3 of 9) |
| Opponent | Tomb Kings of Khemri | 10 | 2 (net +261) | 0 | 0 | 2 (net +364) | 1 (net +145) | 3 (net +140) | 2 | 0% (0 of 8) |
| Opponent | Vampire Counts | 25 | 4 (net -2) | 0 | 3 (net +35) | 11 (net +113) | 3 (net +126) | 2 (net +0) | 2 | 13% (3 of 23) |
| Opponent | Warriors of Chaos | 16 | 2 (net +358) | 0 | 2 (net +42) | 6 (net +193) | 0 | 4 (net +170) | 2 | 14% (2 of 14) |
| Opponent | Wood Elf Realms | 27 | 6 (net +106) | 2 (net -33) | 4 (net +13) | 5 (net +116) | 4 (net +105) | 4 (net +107) | 2 | 16% (4 of 25) |


## Charged fights by odds band, damage counted (Morten 2026-11-10)

### Charged fights, damage counted: groups on

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 10 | 288 | 362 | -51 | 117 | 121 | -4 | -1.3 |
| Mine | 50-54% | 2 | 80 | 82 | +54 | 68 | 0 | +68 | +85.3 |
| Mine | Effective (55-75%) | 19 | 314 | 238 | -68 | 66 | 104 | -39 | -12.3 |
| Mine | 76-89% | 19 | 247 | 178 | +110 | 120 | 16 | +104 | +42.0 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 35 | 208 | 176 | +77 | 122 | 38 | +84 | +40.6 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 13 | 437 | 97 | +66 | 77 | 0 | +77 | +17.7 |
| Mine | No odds | 17 | 336 | 213 | +9 | 64 | 59 | +4 | +1.3 |
| Mine | All fights | 115 | 281 | 198 | +36 | 97 | 51 | +47 | +16.6 |
| Opponent | Long shot (under 50%) | 21 | 173 | 285 | +11 | 71 | 72 | -2 | -0.9 |
| Opponent | 50-54% | 4 | 236 | 187 | -161 | 35 | 161 | -126 | -53.4 |
| Opponent | Effective (55-75%) | 20 | 436 | 314 | +75 | 162 | 105 | +58 | +13.3 |
| Opponent | 76-89% | 23 | 236 | 163 | +44 | 104 | 66 | +38 | +16.2 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 39 | 315 | 193 | +156 | 182 | 23 | +159 | +50.5 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 16 | 412 | 84 | +34 | 73 | 33 | +40 | +9.8 |
| Opponent | No odds | 23 | 279 | 201 | +44 | 127 | 76 | +51 | +18.2 |
| Opponent | All fights | 146 | 302 | 207 | +67 | 127 | 61 | +65 | +21.6 |

### Charged fights, damage counted: groups off

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 7 | 278 | 281 | -71 | 76 | 145 | -69 | -24.7 |
| Mine | 50-54% | 3 | 293 | 408 | -293 | 97 | 293 | -196 | -66.9 |
| Mine | Effective (55-75%) | 19 | 298 | 267 | +52 | 190 | 90 | +100 | +33.6 |
| Mine | 76-89% | 24 | 278 | 202 | +141 | 176 | 47 | +129 | +46.2 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 40 | 216 | 160 | +60 | 99 | 16 | +83 | +38.3 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 11 | 425 | 76 | +6 | 75 | 52 | +23 | +5.5 |
| Mine | No odds | 10 | 296 | 225 | +20 | 65 | 32 | +33 | +11.2 |
| Mine | All fights | 114 | 276 | 198 | +50 | 124 | 55 | +69 | +24.9 |
| Opponent | Long shot (under 50%) | 21 | 319 | 249 | +109 | 164 | 57 | +107 | +33.6 |
| Opponent | 50-54% | 3 | 381 | 357 | -22 | 145 | 190 | -46 | -12.0 |
| Opponent | Effective (55-75%) | 18 | 320 | 220 | +16 | 87 | 85 | +2 | +0.6 |
| Opponent | 76-89% | 35 | 313 | 211 | +151 | 181 | 24 | +157 | +50.2 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 27 | 315 | 206 | +147 | 207 | 50 | +158 | +50.1 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 14 | 489 | 114 | +81 | 95 | 24 | +71 | +14.6 |
| Opponent | No odds | 28 | 261 | 155 | -3 | 88 | 92 | -3 | -1.3 |
| Opponent | All fights | 146 | 323 | 200 | +88 | 145 | 57 | +88 | +27.2 |


## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| groups on | move | 461 | 121 (26%) | 87 (19%) | 53 (11%) | 287 (62%) |
| groups on | objective | 368 | 61 (17%) | 46 (12%) | 47 (13%) | 260 (71%) |
| groups off | move | 461 | 111 (24%) | 86 (19%) | 50 (11%) | 300 (65%) |
| groups off | objective | 362 | 51 (14%) | 39 (11%) | 49 (14%) | 262 (72%) |

## Combined arms (paper 2026-11-09, item 8)

### Combined arms: groups on (36 games)

| Side | Fights with 2+ chargers | Enemy charges answered by a counter-charge | Blocks with an escort in reach (end of Movement) | Screens that took the charge | Lanes opened (rule rows) / blocker gone that round |
| --- | --- | --- | --- | --- | --- |
| Mine | 8 of 115 (7%) | 12 of 165 (7%) | 185 of 317 (58%) | 0.44 per game | 0.14 / 0.08 per game |
| Opponent | 26 of 146 (18%) | 19 of 123 (15%) | 179 of 340 (53%) | 0.39 per game | 0.11 / 0.08 per game |

### Combined arms: groups off (36 games)

| Side | Fights with 2+ chargers | Enemy charges answered by a counter-charge | Blocks with an escort in reach (end of Movement) | Screens that took the charge | Lanes opened (rule rows) / blocker gone that round |
| --- | --- | --- | --- | --- | --- |
| Mine | 8 of 114 (7%) | 9 of 162 (6%) | 168 of 351 (48%) | 0.53 per game | 0.08 / 0.06 per game |
| Opponent | 21 of 146 (14%) | 12 of 122 (10%) | 141 of 339 (42%) | 0.56 per game | 0.11 / 0.00 per game |


## Quality by phase (per game and side)

| Phase | Number | A Mine | A Opponent | B Mine | B Opponent |
| --- | --- | --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.1 | 3.6 | 3.1 | 3.6 |
| Strategy | Charge objectives carried out (made contact) | 44% (65 of 148) | 43% (92 of 216) | 43% (63 of 147) | 46% (87 of 188) |
| Strategy | Shoot objectives carried out (shot that target) | 44% (154 of 353) | 40% (56 of 139) | 43% (156 of 360) | 51% (70 of 137) |
| Strategy | Close-in objectives charged next turn | 16% (28 of 175) | 17% (33 of 193) | 9% (16 of 169) | 18% (35 of 193) |
| Strategy | Support requests answered (helper made contact too) | 41% (7 of 17) | 40% (16 of 40) | 64% (9 of 14) | 56% (14 of 25) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (4 of 4) | 100% (2 of 2) | 100% (2 of 2) | 100% (1 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | 64% (9 of 14) | 57% (4 of 7) | 31% (4 of 13) | 45% (5 of 11) |
| Strategy | Joined characters whose unit fought | 63% (19 of 30) | 41% (12 of 29) | 78% (25 of 32) | 41% (12 of 29) |
| Strategy | Lone characters that fought | 74% (69 of 93) | 82% (71 of 87) | 82% (75 of 91) | 84% (73 of 87) |
| Movement | Charges halted short of contact | 0.2 | 0.4 | 0.1 | 0.2 |
| Movement | Idle units | 1.1 | 1.9 | 1.1 | 1.9 |
| Movement | Points that never moved of their own | 252.0 | 116.0 | 261.4 | 99.1 |
| Movement | Fights charged into per game | 3.2 | 4.1 | 3.2 | 4.1 |
| Movement | Charges with odds: long shots (under 50%) | 10 of 98, net -51 | 21 of 123, net +11 | 7 of 104, net -71 | 21 of 118, net +109 |
| Movement | Charges with odds: sweet spot (55-75%) | 19 of 98, net -68 | 20 of 123, net +75 | 19 of 104, net +52 | 18 of 118, net +16 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 13 of 98, net +66 | 16 of 123, net +34 | 11 of 104, net +6 | 14 of 118, net +81 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 35 of 98, net +77 | 39 of 123, net +156 | 40 of 104, net +60 | 27 of 118, net +147 |
| Shooting | Shots by shooting units (incl. breath weapons) | 9.1 | 7.8 | 9.8 | 7.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 57% (144 of 252) | 46% (12 of 26) | 57% (137 of 241) | 63% (17 of 27) |
| Shooting | Points destroyed by shooting units | 104.7 | 71.0 | 45.3 | 22.3 |
| Shooting | War machine shots | 7.0 | 0.7 | 6.7 | 0.8 |
| Shooting | Points destroyed by war machines | 33.9 | 8.3 | 59.2 | 6.1 |
| Magic | Magic missiles cast | 1.2 | 0.7 | 1.2 | 1.0 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 33% (14 of 43) | 20% (5 of 25) | 34% (15 of 44) | 19% (7 of 36) |
| Magic | Wounds caused by magic missiles | 3.4 | 0.4 | 3.7 | 0.8 |
| Magic | Wounds caused by other spells | 1.7 | 1.2 | 1.1 | 2.0 |
| Magic | Points destroyed by magic (all spells) | 119.5 | 13.4 | 79.0 | 55.1 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.2 / 0.4 / 0.7 / 0.1 | 1.8 / 0.4 / 0.6 / 0.1 | 1.1 / 0.4 / 0.8 / 0.0 | 2.2 / 0.6 / 0.9 / 0.1 |
| Combat | Points destroyed in combat | 300.6 | 425.8 | 320.8 | 507.7 |
| Combat | Points run down | 72.9 | 161.1 | 110.9 | 93.0 |
| Combat | Net points per charged fight, damage counted | +47 | +65 | +69 | +88 |
| Combat | Net per 100 charger points, damage counted | +16.6 | +21.6 | +24.9 | +27.2 |
| Combat | First round won (charged fights) | 74% | 52% | 70% | 60% |
| Combat | Net points per charged fight | +36 | +67 | +50 | +88 |
| Combat | Net points per supported fight / lone fight | +57 / +34 | +138 / +51 | +16 / +52 | +216 / +66 |
| Combat | Charged fights on a top-3 enemy unit | 44 of 115 | 61 of 146 | 38 of 114 | 65 of 146 |
| Game | Points lost | 782.9 | 704.3 | 764.1 | 656.8 |
| Game | VP from objectives | 538.3 | 530.6 | 550.0 | 519.4 |
| Game | Lone holders (player turns) | 3.0 | 2.1 | 2.8 | 2.1 |

A = groups on:
- Mine won / drew / lost: 12 / 11 / 13 of 36 ended games (of 36); mean margin (Mine - Opponent) -83 VP
- The side that went first won 13 of 25 games with a winner
- Points traded per game (both sides' losses): 1487
- Games not ended: 0; findings 0, warnings 1

B = groups off:
- Mine won / drew / lost: 12 / 11 / 13 of 36 ended games (of 36); mean margin (Mine - Opponent) -119 VP
- The side that went first won 14 of 25 games with a winner
- Points traded per game (both sides' losses): 1421
- Games not ended: 0; findings 0, warnings 0

## Opponent rules (fired a game, figure / won / lost VP a game)

| Rule | A Mine | A Opponent | B Mine | B Opponent |
| --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.6 (+0 / 0 / 0) | 0.6 (+0 / 0 / 0) | 0.6 (+0 / 0 / 0) | 0.6 (+0 / 0 / 0) |
| ARTILLERY RE-ROLL WEIGHED | 1.1 (+0 / 0 / 21) | 0.1 (+0 / 0 / 3) | 1.0 (+0 / 0 / 13) | 0.1 (+0 / 0 / 3) |
| BACKUP TARGETS | 0.8 (+5 / 0 / 21) | 0.9 (+10 / 0 / 42) | 0.9 (+5 / 0 / 25) | 0.9 (+9 / 0 / 4) |
| BEST PREY | 4.6 (+320 / 236 / 162) | 4.6 (+297 / 154 / 137) | 4.8 (+272 / 117 / 182) | 5.3 (+366 / 218 / 83) |
| BEST PRIZE | 0.1 (+2 / 3 / 13) | 0.1 (-1 / 3 / 0) | 0.0 (-0 / 0 / 0) | 0.1 (+1 / 2 / 0) |
| BLOCKED CHARGE SKIPPED | 0.0 (+0 / 0 / 0) | 0.1 (+0 / 0 / 0) | 0.1 (+0 / 0 / 3) | 0.0 (+0 / 0 / 0) |
| BLOCKED WHEEL | 0.8 (+1 / 0 / 9) | 0.4 (-8 / 0 / 0) | 0.6 (+16 / 0 / 1) | 0.4 (+3 / 0 / 4) |
| BOMBING RUN | 0.0 (+0 / 1 / 0) | - | 0.1 (+2 / 0 / 0) | - |
| BOUND ASSAILMENT | 0.0 (+0 / 0 / 4) | 0.1 (+0 / 0 / 0) | 0.0 (+0 / 0 / 4) | - |
| CANNON PLAN MISSED | 0.9 (+0 / 78 / 8) | 0.2 (+0 / 22 / 0) | 0.9 (+0 / 107 / 5) | 0.1 (+0 / 3 / 3) |
| CANNON PLANNED TARGET | 5.4 (+206 / 357 / 62) | 0.5 (+16 / 46 / 7) | 5.4 (+186 / 273 / 47) | 0.5 (+17 / 9 / 3) |
| CANNON SIGHT KEPT | 1.3 (+0 / 0 / 3) | 0.0 (+0 / 0 / 0) | 1.3 (+0 / 0 / 3) | 0.0 (+0 / 0 / 0) |
| CAST JOB | 0.8 (+19 / 37 / 2) | 0.4 (+6 / 13 / 0) | 1.0 (+27 / 35 / 27) | 0.4 (+4 / 27 / 0) |
| CASTER AWAY FROM SCREEN | 0.3 (+0 / 0 / 9) | 0.1 (+0 / 0 / 0) | 0.3 (+0 / 0 / 12) | 0.1 (+0 / 0 / 0) |
| CASTING BLOCK | 0.3 (+52 / 42 / 10) | - | 0.3 (+24 / 14 / 9) | - |
| CASTS AFTER FRIENDS | 0.9 (+0 / 0 / 30) | 0.3 (+0 / 0 / 11) | 0.8 (+0 / 0 / 24) | 0.3 (+0 / 0 / 9) |
| CASTS FROM BEHIND | 0.1 (+0 / 0 / 0) | 0.2 (+0 / 0 / 0) | 0.1 (+0 / 0 / 0) | 0.2 (+0 / 0 / 0) |
| CATCH FLIERS | 0.1 (+0 / 0 / 0) | 0.0 (+1 / 0 / 0) | 0.0 (+0 / 0 / 0) | 0.0 (+1 / 0 / 0) |
| CATCH ODDS | - | - | 0.0 (+0 / 0 / 0) | - |
| CHAFF PASSED | 0.2 (-0 / 15 / 8) | 0.1 (-0 / 7 / 2) | 0.2 (-0 / 0 / 0) | 0.2 (-0 / 0 / 4) |
| CHAMPION TAKES THE CHALLENGE | - | 0.0 (+1 / 11 / 0) | - | - |
| CHARGE NOW WEIGHED | 0.6 (-46 / 13 / 20) | 0.4 (-44 / 18 / 33) | 0.4 (-35 / 14 / 20) | 0.7 (-64 / 12 / 29) |
| CHARIOT NO STATIC JOB | 0.6 (+0 / 6 / 12) | 0.3 (+0 / 0 / 2) | 0.4 (+0 / 4 / 13) | 0.2 (+0 / 7 / 5) |
| CHEAP HELPER | 0.2 (+0 / 8 / 2) | 0.2 (+0 / 18 / 0) | 0.1 (+0 / 1 / 4) | 0.1 (+0 / 10 / 1) |
| CONVEYANCE SEARCH | 0.6 (+60 / 15 / 24) | 0.1 (+22 / 0 / 8) | 0.8 (+60 / 16 / 9) | 0.2 (+16 / 4 / 0) |
| COUNTER-CHARGE COVER | 8.8 (+619 / 0 / 241) | 8.6 (+676 / 0 / 213) | - | - |
| EDGE GIVE GROUND | - | 0.2 (+10 / 14 / 4) | 0.0 (+0 / 4 / 0) | 0.1 (+6 / 18 / 0) |
| ELIXIR WORTH | - | 0.1 (+4 / 0 / 10) | - | 0.1 (+3 / 0 / 10) |
| ENGINEER BY LORE | 0.1 (+0 / 0 / 0) | - | 0.1 (+0 / 0 / 0) | - |
| ESCORT | 0.6 (+33 / 0 / 4) | 0.1 (+5 / 0 / 0) | - | - |
| FACES THE THREAT | 1.4 (+98 / 0 / 52) | 1.0 (+85 / 0 / 26) | 1.7 (+121 / 0 / 72) | 1.2 (+88 / 0 / 0) |
| FIGHT LIFT | 0.1 (+1 / 4 / 0) | - | 0.1 (+3 / 12 / 0) | 0.0 (+0 / 0 / 0) |
| FIRE AND FLEE | 0.0 (+0 / 0 / 0) | 0.0 (+1 / 0 / 0) | 0.1 (+1 / 0 / 0) | 0.1 (+0 / 0 / 3) |
| FOCUS FIRE | 0.0 (+0 / 2 / 2) | 0.1 (+1 / 2 / 0) | 0.0 (+0 / 2 / 0) | 0.0 (+0 / 1 / 0) |
| FOLLOW UP WEIGHED | 1.2 (+149 / 0 / 46) | 1.2 (+142 / 0 / 21) | 1.1 (+161 / 0 / 76) | 0.8 (+129 / 0 / 26) |
| FRIENDS SHOTS CHECKED | 0.4 (+29 / 0 / 0) | 0.2 (+6 / 0 / 3) | 0.3 (+20 / 0 / 6) | 0.2 (+8 / 0 / 3) |
| GIVES UP | 1.1 (-28 / 124 / 19) | 1.6 (-54 / 206 / 40) | 1.3 (-38 / 160 / 99) | 1.6 (-63 / 255 / 36) |
| GIVES UP ITS SCREEN | 0.8 (-15 / 38 / 18) | 1.2 (-26 / 104 / 14) | 0.6 (-15 / 25 / 4) | 1.0 (-19 / 98 / 16) |
| GROUND FLIERS | 0.1 (+0 / 0 / 0) | 0.0 (+0 / 0 / 0) | 0.1 (+1 / 0 / 0) | - |
| GROUP AIM | 0.2 (+1 / 0 / 4) | 0.2 (+2 / 0 / 6) | - | - |
| GROUP BROKEN | 0.0 (+0 / 0 / 0) | - | - | - |
| HELPER ALREADY ASKED | 0.0 (+0 / 6 / 0) | 0.1 (+0 / 0 / 2) | - | 0.1 (+0 / 31 / 2) |
| HELPER UNSEEN | 0.2 (+0 / 7 / 26) | 0.6 (+0 / 40 / 21) | 0.1 (+0 / 6 / 0) | 0.5 (+0 / 60 / 8) |
| HOLDS AMBUSHERS | 0.4 (+0 / 0 / 0) | 0.6 (+0 / 0 / 0) | 0.4 (+0 / 0 / 0) | 0.6 (+0 / 0 / 0) |
| HUNT ADVANCE | 0.1 (+2 / 5 / 0) | 0.2 (+5 / 7 / 3) | 0.1 (+0 / 13 / 5) | 0.1 (+1 / 11 / 2) |
| HUNT DROPPED | 0.0 (+0 / 13 / 0) | 0.1 (+0 / 20 / 3) | - | 0.0 (+0 / 0 / 0) |
| HUNT IN PAIRS | 0.3 (+16 / 0 / 0) | 0.3 (+14 / 0 / 5) | - | - |
| HUNT KEPT | 0.0 (+0 / 0 / 0) | 0.0 (+2 / 3 / 0) | - | - |
| HUNT RESULT | 0.1 (+5 / 26 / 0) | 0.2 (+10 / 26 / 6) | 0.1 (+27 / 26 / 3) | 0.1 (+27 / 15 / 2) |
| HUNT THE GUNS | 0.1 (+58 / 5 / 0) | 0.2 (+76 / 30 / 3) | 0.1 (+45 / 26 / 7) | 0.1 (+38 / 26 / 4) |
| JOINT CHARGE PLAN | 0.1 (+4 / 0 / 0) | 0.1 (+4 / 0 / 3) | 0.1 (+0 / 0 / 0) | 0.1 (+2 / 0 / 0) |
| KEEPS ITS PREY | 0.1 (+0 / 3 / 4) | 0.4 (+1 / 11 / 7) | 0.2 (+1 / 4 / 6) | 0.6 (+4 / 12 / 0) |
| KEEPS ITS TARGET | 2.1 (+62 / 184 / 35) | 2.1 (+63 / 199 / 29) | 2.2 (+65 / 162 / 78) | 2.2 (+65 / 247 / 12) |
| KEEPS SCOUTS OR AMBUSH | 0.1 (+0 / 0 / 0) | - | 0.1 (+0 / 0 / 0) | - |
| KILLS COUNT | 1.9 (+55 / 136 / 41) | 2.4 (+107 / 149 / 16) | 2.0 (+85 / 131 / 54) | 2.2 (+113 / 246 / 57) |
| KILLS COUNT NEXT TURN | 9.1 (+367 / 379 / 231) | 10.1 (+513 / 420 / 245) | 9.7 (+342 / 266 / 253) | 11.5 (+574 / 536 / 164) |
| LONE CHARACTER SAFE SPOT | 0.4 (+17 / 22 / 4) | 0.4 (+6 / 1 / 19) | 0.5 (+23 / 22 / 23) | 0.2 (+7 / 0 / 0) |
| LONE WIZARD HOLDS BACK | 1.4 (+0 / 102 / 24) | 1.0 (+0 / 30 / 50) | 1.2 (+0 / 58 / 90) | 1.3 (+0 / 65 / 5) |
| LONE WIZARD KEPT IN | 0.6 (+27 / 0 / 0) | 0.2 (+20 / 0 / 0) | 0.6 (+27 / 0 / 3) | 0.2 (+20 / 0 / 0) |
| MAKE SURE TOGETHER | 0.8 (+30 / 5 / 15) | 1.1 (+48 / 18 / 38) | 0.5 (+32 / 10 / 1) | 0.7 (+35 / 11 / 10) |
| MANOEUVRE | 0.2 (+10 / 0 / 2) | 0.1 (+2 / 0 / 0) | 0.1 (+10 / 0 / 2) | 0.1 (+3 / 0 / 0) |
| MARCH AT ESCAPER | 0.2 (+1 / 0 / 15) | 0.2 (+2 / 0 / 18) | 0.2 (+1 / 0 / 6) | 0.1 (+3 / 0 / 0) |
| MARCH ODDS | 1.2 (+67 / 15 / 22) | 0.7 (+77 / 35 / 32) | 1.3 (+80 / 40 / 79) | 0.6 (+56 / 7 / 36) |
| MISSILES IN THE MOVE | 2.8 (+91 / 0 / 64) | 1.6 (+22 / 0 / 26) | 3.3 (+103 / 0 / 92) | 2.1 (+34 / 0 / 15) |
| MISSILES NEXT TURN | 4.6 (+83 / 0 / 128) | 2.7 (+22 / 0 / 99) | 4.7 (+85 / 0 / 128) | 3.1 (+30 / 0 / 46) |
| MODEL FACING | 0.4 (+91 / 0 / 3) | - | 0.4 (+99 / 0 / 0) | - |
| MOVE AND CAST | 0.1 (+5 / 0 / 0) | 0.1 (+3 / 0 / 0) | 0.2 (+3 / 0 / 0) | 0.1 (+5 / 0 / 0) |
| MOVE SPELL IN RANGE | 0.2 (+5 / 0 / 0) | - | 0.2 (+6 / 0 / 0) | 0.0 (+2 / 0 / 0) |
| MOVE SPELL OUT OF RANGE | 0.6 (-21 / 50 / 51) | 0.1 (-0 / 7 / 0) | 0.5 (-19 / 14 / 20) | 0.2 (-1 / 17 / 0) |
| MOVE SPELL SPOT | 0.6 (+0 / 0 / 10) | 0.1 (+0 / 0 / 11) | 0.6 (+0 / 0 / 14) | 0.1 (+0 / 0 / 0) |
| MOVES UNITS SPELL | 0.1 (+3 / 0 / 0) | 0.1 (+1 / 0 / 0) | 0.1 (+3 / 0 / 0) | 0.1 (+1 / 0 / 0) |
| NEEDED THERE | 0.1 (+2 / 8 / 0) | 0.1 (+7 / 4 / 0) | 0.0 (+8 / 0 / 0) | 0.1 (+15 / 7 / 0) |
| NO RALLY LEFT | 0.1 (+1 / 0 / 2) | 0.0 (+0 / 0 / 0) | 0.0 (+1 / 0 / 0) | 0.0 (+0 / 0 / 0) |
| NOT NEEDED | 0.2 (-9 / 22 / 9) | 0.4 (-17 / 28 / 9) | 0.2 (-6 / 18 / 2) | 0.2 (-21 / 34 / 3) |
| NOT TURNED | 10.0 (+201 / 0 / 278) | 10.7 (+110 / 0 / 242) | 9.2 (+109 / 0 / 275) | 9.9 (+97 / 0 / 157) |
| NOT WORTH A CAST | 0.5 (-0 / 0 / 11) | 0.4 (-3 / 0 / 0) | 0.5 (-0 / 0 / 20) | 0.3 (-0 / 0 / 0) |
| OPENS A LANE | 0.1 (+0 / 12 / 2) | 0.1 (+1 / 5 / 0) | 0.1 (+1 / 4 / 0) | 0.1 (+1 / 18 / 0) |
| OPENS UP | 0.4 (+26 / 15 / 13) | 0.3 (+32 / 11 / 0) | 0.2 (+15 / 10 / 6) | 0.2 (+32 / 6 / 0) |
| OVERRUNS AWAY | 0.5 (+4 / 25 / 29) | 0.8 (+10 / 75 / 7) | 0.5 (+18 / 66 / 31) | 0.6 (+15 / 64 / 12) |
| PATHS CROSS | 2.2 (+141 / 0 / 50) | 3.1 (+256 / 0 / 62) | 2.4 (+146 / 0 / 49) | 3.2 (+231 / 0 / 46) |
| PERIAPT WORTH | 0.0 (+1 / 0 / 0) | 0.1 (+8 / 0 / 0) | 0.0 (+1 / 0 / 0) | 0.1 (+10 / 0 / 0) |
| PLAN LEADS | 1.2 (+115 / 23 / 35) | 1.0 (+86 / 15 / 7) | 1.1 (+104 / 18 / 18) | 0.9 (+73 / 10 / 4) |
| PLAN RESULT | 39.1 (+1446 / 1342 / 1142) | 39.0 (+1397 / 1475 / 986) | 39.2 (+1422 / 1237 / 1070) | 39.6 (+1468 / 1460 / 902) |
| PURSUES BIG PREY | 0.0 (-1 / 0 / 0) | 0.1 (-2 / 0 / 0) | 0.0 (-5 / 0 / 0) | 0.1 (-6 / 0 / 0) |
| PURSUES ON | - | - | 0.0 (+2 / 0 / 0) | - |
| RAIDS THE BAGGAGE | - | - | - | 0.0 (+5 / 0 / 0) |
| RAIDS THE BAGGAGE NEXT TURN | 0.1 (+6 / 0 / 0) | 0.1 (+11 / 0 / 9) | 0.1 (+7 / 0 / 0) | 0.2 (+20 / 0 / 0) |
| REDIRECT COUNTER | 3.5 (+149 / 0 / 58) | 5.3 (+306 / 0 / 87) | - | - |
| REDIRECT WEIGHED | 0.1 (+2 / 3 / 1) | 0.4 (+15 / 13 / 10) | 0.1 (+13 / 10 / 0) | 0.4 (+26 / 10 / 13) |
| RESTRAINS TO SHOOT | 0.2 (+10 / 0 / 4) | 0.1 (+3 / 0 / 7) | 0.1 (+6 / 0 / 7) | 0.0 (+2 / 0 / 0) |
| RISK BY ARC | 2.9 (+126 / 216 / 107) | 3.3 (+61 / 267 / 64) | 2.9 (+103 / 245 / 156) | 2.9 (+42 / 349 / 81) |
| SAFER THAN THE JOB | 0.9 (+46 / 0 / 20) | 0.7 (+42 / 0 / 19) | 1.3 (+58 / 0 / 2) | 0.6 (+33 / 0 / 12) |
| SCOUT SPOT | 0.4 (+0 / 0 / 0) | 0.1 (+0 / 0 / 2) | 0.4 (+0 / 0 / 0) | 0.1 (+0 / 0 / 0) |
| SCOUT WAITS | 0.5 (+0 / 0 / 0) | 0.1 (+0 / 0 / 2) | 0.5 (+0 / 0 / 0) | 0.1 (+0 / 0 / 0) |
| SEARCH SPOT | 1.3 (+91 / 0 / 37) | 1.5 (+112 / 0 / 42) | 1.0 (+53 / 0 / 21) | 0.9 (+66 / 0 / 9) |
| SECOND HUNTER | 0.0 (-0 / 0 / 0) | - | 0.0 (-0 / 13 / 2) | - |
| SELF MOVE SPELL | 0.2 (+48 / 0 / 0) | 0.4 (+21 / 0 / 18) | 0.1 (+34 / 0 / 11) | 0.4 (+29 / 0 / 18) |
| SET UP TOGETHER | 1.2 (+45 / 5 / 25) | 1.8 (+62 / 18 / 46) | 0.9 (+44 / 10 / 1) | 1.0 (+51 / 17 / 23) |
| SET-UP MISSED | - | 0.0 (+8 / 0 / 0) | - | - |
| SHOOTERS IN TWO RANKS | 0.3 (+1 / 0 / 0) | 0.2 (+0 / 0 / 0) | 0.3 (+1 / 0 / 0) | 0.2 (+0 / 0 / 0) |
| SHORT GUN FORWARD | 0.2 (+0 / 0 / 3) | 0.0 (+0 / 0 / 0) | 0.2 (+0 / 0 / 3) | 0.0 (+0 / 0 / 0) |
| SHOT REPLANNED | 0.5 (+0 / 124 / 5) | 0.3 (+0 / 40 / 7) | 0.5 (+0 / 120 / 7) | 0.2 (+0 / 35 / 0) |
| SHOTS IN THE MOVE | 13.9 (+644 / 0 / 161) | 6.2 (+137 / 0 / 79) | 14.7 (+602 / 0 / 164) | 6.3 (+175 / 0 / 76) |
| SPELL CATCH ODDS | 0.0 (-0 / 0 / 0) | - | 0.1 (-0 / 3 / 0) | 0.0 (-0 / 0 / 0) |
| SPELL SETS UP CHARGE | 0.1 (+22 / 0 / 0) | 0.1 (+17 / 0 / 0) | - | 0.0 (+12 / 0 / 0) |
| SPELL WORTH | 1.5 (+25 / 130 / 126) | 2.3 (+48 / 86 / 89) | 1.5 (+39 / 101 / 84) | 2.5 (+47 / 41 / 41) |
| STANDS TO CAST | 0.1 (+2 / 0 / 0) | - | 0.1 (+2 / 1 / 7) | 0.1 (+7 / 5 / 0) |
| STOPS | 0.1 (+0 / 0 / 0) | 0.1 (+2 / 26 / 0) | 0.0 (+0 / 13 / 2) | 0.0 (+0 / 15 / 2) |
| STUCK PIVOT | 0.3 (+0 / 0 / 6) | 0.3 (+0 / 0 / 0) | 0.3 (+0 / 0 / 4) | 0.4 (+0 / 0 / 6) |
| SUPPORT JOB KEPT | - | - | - | 0.0 (+0 / 0 / 0) |
| SURE CHARGE BEATS ADVANCE | 0.1 (-10 / 9 / 0) | 0.1 (-2 / 8 / 0) | 0.1 (-4 / 11 / 3) | 0.1 (-3 / 10 / 4) |
| THROUGH LINE OF FIRE | 0.5 (+23 / 0 / 0) | 0.4 (+18 / 0 / 2) | 0.4 (+14 / 0 / 16) | 0.2 (+13 / 0 / 0) |
| TURN WORTH | 0.7 (-52 / 43 / 28) | 0.4 (-38 / 27 / 0) | 0.4 (-33 / 15 / 13) | 0.2 (-24 / 19 / 0) |
| TWO OR MORE ARRIVE | 0.5 (+5 / 5 / 14) | 0.6 (+9 / 0 / 5) | 0.6 (+4 / 0 / 0) | 0.6 (+10 / 6 / 11) |
| WEARS DOWN | 1.2 (+62 / 90 / 70) | 1.3 (+49 / 137 / 79) | 0.9 (+40 / 105 / 93) | 1.0 (+31 / 115 / 17) |
| WHO HITS BACK | 0.2 (+22 / 0 / 17) | 0.3 (+16 / 0 / 7) | 0.3 (+17 / 0 / 1) | 0.2 (+17 / 0 / 26) |
| WHOLE FIGHT | 0.4 (+10 / 25 / 3) | 0.6 (+22 / 137 / 19) | 0.3 (+29 / 88 / 14) | 0.7 (+56 / 120 / 12) |
| WHOLE FIGHT GAIN | 0.3 (+28 / 25 / 3) | 0.8 (+54 / 46 / 13) | 0.3 (+16 / 11 / 21) | 0.6 (+50 / 53 / 13) |

A = groups on, B = groups off.

## Rule changes (changed a game, VP a change)

| Rule | A | B |
| --- | --- | --- |
| ADVANCE LANE KEPT | 1.14 (+0.0) | 1.14 (+0.0) |
| ARTILLERY RE-ROLL WEIGHED | 1.28 (+0.0) | 1.06 (+0.0) |
| BACKUP TARGETS | 0.03 (+2.3) | 0.11 (+3.5) |
| BEST PREY | 4.25 (+31.3) | 4.33 (+39.8) |
| BEST PRIZE | 0.17 (-63.5) | 0.11 (-12.3) |
| BLOCKED CHARGE SKIPPED | 0.14 (+0.0) | 0.14 (+0.0) |
| BLOCKED WHEEL | - | - |
| BOMBING RUN | 0.03 (+13.8) | 0.06 (+42.8) |
| BOUND ASSAILMENT | 0.08 (+0.2) | 0.03 (+0.1) |
| CANNON PLAN MISSED | 0.00 (-) | 0.00 (-) |
| CANNON PLANNED TARGET | 0.78 (-28.8) | 0.94 (+4.9) |
| CANNON SIGHT KEPT | 1.33 (+0.0) | 1.33 (+0.0) |
| CAST JOB | 0.61 (+16.8) | 0.72 (+11.0) |
| CASTER AWAY FROM SCREEN | 0.44 (+0.0) | 0.44 (+0.0) |
| CASTING BLOCK | 0.28 (+132.5) | 0.19 (+54.5) |
| CASTS AFTER FRIENDS | - | - |
| CASTS FROM BEHIND | 0.25 (+0.0) | 0.25 (+0.0) |
| CATCH FLIERS | - | - |
| CATCH ODDS | - | - |
| CHAFF PASSED | 0.39 (-1.3) | 0.36 (-1.0) |
| CHAMPION TAKES THE CHALLENGE | 0.00 (-) | - |
| CHARGE NOW WEIGHED | 1.00 (+55.9) | 1.14 (+65.0) |
| CHARIOT NO STATIC JOB | 0.58 (-83.9) | 0.53 (-93.9) |
| CHEAP HELPER | - | - |
| CONVEYANCE SEARCH | - | - |
| COUNTER-CHARGE COVER | 2.25 (+57.4) | - |
| EDGE GIVE GROUND | 0.03 (+47.7) | 0.00 (-) |
| ELIXIR WORTH | 0.08 (+52.7) | 0.08 (+37.0) |
| ENGINEER BY LORE | 0.00 (-) | 0.00 (-) |
| ESCORT | 0.03 (+34.5) | - |
| FACES THE THREAT | - | - |
| FIGHT LIFT | - | - |
| FIRE AND FLEE | 0.06 (+23.1) | 0.11 (+7.8) |
| FOCUS FIRE | 0.08 (+10.4) | 0.06 (+10.1) |
| FOLLOW UP WEIGHED | 2.44 (+119.2) | 1.92 (+151.5) |
| FRIENDS SHOTS CHECKED | 0.61 (+56.9) | 0.47 (+59.4) |
| GIVES UP | 0.03 (+4.4) | 0.06 (+7.2) |
| GIVES UP ITS SCREEN | 0.03 (+1.7) | 0.06 (+7.2) |
| GROUND FLIERS | - | - |
| GROUP AIM | 0.00 (-) | - |
| GROUP BROKEN | - | - |
| HELPER ALREADY ASKED | - | - |
| HELPER UNSEEN | 0.00 (-) | 0.00 (-) |
| HOLDS AMBUSHERS | 0.97 (+0.0) | 0.97 (+0.0) |
| HUNT ADVANCE | 0.14 (+23.3) | 0.06 (+2.2) |
| HUNT DROPPED | - | - |
| HUNT IN PAIRS | 0.03 (+34.8) | - |
| HUNT KEPT | - | - |
| HUNT RESULT | - | - |
| HUNT THE GUNS | - | - |
| JOINT CHARGE PLAN | 0.06 (+46.1) | 0.03 (+26.0) |
| KEEPS ITS PREY | 0.00 (-) | 0.03 (+17.6) |
| KEEPS ITS TARGET | 1.03 (+17.0) | 0.75 (+17.2) |
| KEEPS SCOUTS OR AMBUSH | 0.06 (+0.0) | 0.06 (+0.0) |
| KILLS COUNT | 1.22 (+33.5) | 1.36 (+45.2) |
| KILLS COUNT NEXT TURN | 5.69 (+39.2) | 5.61 (+37.4) |
| LONE CHARACTER SAFE SPOT | - | - |
| LONE WIZARD HOLDS BACK | 0.67 (-36.3) | 0.75 (-47.1) |
| LONE WIZARD KEPT IN | 0.78 (+60.7) | 0.78 (+60.7) |
| MAKE SURE TOGETHER | 0.44 (+34.6) | 0.50 (+35.5) |
| MANOEUVRE | - | - |
| MARCH AT ESCAPER | - | - |
| MARCH ODDS | 1.36 (+23.2) | 1.39 (+30.9) |
| MISSILES IN THE MOVE | - | - |
| MISSILES NEXT TURN | 0.06 (+0.5) | 0.06 (+5.6) |
| MODEL FACING | 0.44 (+204.8) | 0.36 (+275.4) |
| MOVE AND CAST | - | - |
| MOVE SPELL IN RANGE | 0.00 (-) | 0.03 (+42.1) |
| MOVE SPELL OUT OF RANGE | - | - |
| MOVE SPELL SPOT | - | - |
| MOVES UNITS SPELL | 0.19 (+19.7) | 0.19 (+19.7) |
| NEEDED THERE | 0.11 (+0.0) | 0.14 (+0.0) |
| NO RALLY LEFT | 0.08 (+5.8) | 0.06 (+13.0) |
| NOT NEEDED | 0.00 (-) | 0.00 (-) |
| NOT TURNED | 0.00 (-) | 0.00 (-) |
| NOT WORTH A CAST | - | - |
| OPENS A LANE | 0.00 (-) | 0.03 (+0.7) |
| OPENS UP | 0.33 (+37.3) | 0.17 (+35.8) |
| OVERRUNS AWAY | 0.11 (+30.3) | 0.11 (+10.7) |
| PATHS CROSS | - | - |
| PERIAPT WORTH | 0.14 (+64.1) | 0.11 (+96.4) |
| PLAN LEADS | 0.81 (+44.9) | 0.78 (+53.8) |
| PLAN RESULT | - | - |
| PURSUES BIG PREY | 0.08 (-38.7) | 0.11 (-98.9) |
| PURSUES ON | - | 0.03 (+79.1) |
| RAIDS THE BAGGAGE | - | 0.03 (+172.3) |
| RAIDS THE BAGGAGE NEXT TURN | 0.17 (+19.6) | 0.28 (+32.8) |
| REDIRECT COUNTER | 0.47 (+69.0) | - |
| REDIRECT WEIGHED | 0.53 (+33.4) | 0.53 (+68.0) |
| RESTRAINS TO SHOOT | 0.31 (+42.4) | 0.11 (+71.9) |
| RISK BY ARC | 1.44 (+32.1) | 1.14 (+19.4) |
| SAFER THAN THE JOB | - | - |
| SCOUT SPOT | 0.00 (-) | 0.00 (-) |
| SCOUT WAITS | 0.58 (+0.0) | 0.58 (+0.0) |
| SEARCH SPOT | - | - |
| SECOND HUNTER | 0.00 (-) | 0.00 (-) |
| SELF MOVE SPELL | - | - |
| SET UP TOGETHER | 0.83 (+30.3) | 0.83 (+34.4) |
| SET-UP MISSED | - | - |
| SHOOTERS IN TWO RANKS | 0.47 (+2.1) | 0.47 (+2.1) |
| SHORT GUN FORWARD | 0.25 (+0.0) | 0.25 (+0.0) |
| SHOT REPLANNED | 0.83 (+0.0) | 0.75 (+0.0) |
| SHOTS IN THE MOVE | - | - |
| SPELL CATCH ODDS | - | - |
| SPELL SETS UP CHARGE | - | - |
| SPELL WORTH | - | - |
| STANDS TO CAST | 0.06 (+2.9) | 0.11 (+10.0) |
| STOPS | 0.00 (-) | 0.00 (-) |
| STUCK PIVOT | 0.61 (+0.0) | 0.64 (+0.0) |
| SUPPORT JOB KEPT | - | 0.03 (+32.0) |
| SURE CHARGE BEATS ADVANCE | 0.25 (-51.1) | 0.25 (-26.5) |
| THROUGH LINE OF FIRE | - | - |
| TURN WORTH | 0.03 (+11.0) | 0.00 (-) |
| TWO OR MORE ARRIVE | 0.19 (+7.1) | 0.11 (+17.4) |
| WEARS DOWN | 0.42 (+34.4) | 0.31 (+20.2) |
| WHO HITS BACK | 0.56 (-62.3) | 0.50 (-123.5) |
| WHOLE FIGHT | 0.33 (+43.3) | 0.44 (+94.6) |
| WHOLE FIGHT GAIN | 0.58 (+42.4) | 0.33 (+42.1) |

A = groups on, B = groups off.

## Plans (happened, won of planned)

| Side | Plan | A | B |
| --- | --- | --- | --- |
| Mine | advance | 19% (73%) | 17% (64%) |
| Mine | charge | 50% (84%) | 56% (97%) |
| Mine | close in | 24% (24%) | 18% (48%) |
| Mine | hold | 40% (0%) | 40% (0%) |
| Mine | join | 92% (0%) | 85% (0%) |
| Mine | shoot | 62% (201%) | 61% (241%) |
| Mine | support | 88% (0%) | 92% (0%) |
| Opponent | advance | 21% (63%) | 17% (72%) |
| Opponent | charge | 63% (92%) | 63% (89%) |
| Opponent | close in | 32% (49%) | 24% (45%) |
| Opponent | hold | 29% (0%) | 29% (0%) |
| Opponent | join | 95% (0%) | 95% (0%) |
| Opponent | shoot | 59% (290%) | 58% (271%) |
| Opponent | support | 86% (0%) | 90% (0%) |

A = groups on, B = groups off.

## Packages: hunt the guns (per side)

| Batch | Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| A | Mine | 0.1 | 5 | 1 | 0% | 25% | 0% | 2.0 | 386 | 48 | 25% | 23 |
| A | Opponent | 0.2 | 8 | 0 | 25% | 25% | 0% | 2.5 | 344 | 44 | 12% | 70 |
| B | Mine | 0.1 | 4 | 0 | 25% | 50% | 0% | 2.0 | 409 | 244 | 50% | 6 |
| B | Opponent | 0.1 | 4 | 0 | 25% | 50% | 0% | 2.0 | 346 | 240 | 50% | 75 |

A = groups on, B = groups off.

### Battle groups: groups on

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 8.8 | 30% | 46% | 16% | 27% | 37% | 14% | 5% | 44% | 0% |
| Mine | REDIRECT COUNTER | 3.5 | 35% | 68% | 14% | 17% | 13% | 0% | 8% | 66% | 13% |
| Opponent | COUNTER-CHARGE COVER | 8.6 | 17% | 53% | 16% | 25% | 42% | 2% | 12% | 44% | 0% |
| Opponent | REDIRECT COUNTER | 5.3 | 19% | 81% | 22% | 25% | 14% | 3% | 21% | 52% | 10% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.1 | 5 | 0% | - |
| Opponent | 0.2 | 6 | 0% | - |

### Deployment: positions vs output by unit type: groups on

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 4 | 0 (4) | 0 | 0 | 100 | 75% | 5.0 | - | 0 (1) | - | 0 (1) | - |
| Mine | Chaff | 49 | 49 (49) | 22 | 26 | 63 | 24% | 2.8 | 35 (21) | 51 (11) | 66 (17) | 65 (32) | 17 (17) |
| Mine | Character | 106 | 55 (106) | 55 | 0 | 32 | 16% | 2.3 | 51 (35) | 65 (48) | 7 (9) | 55 (50) | 57 (42) |
| Mine | Clean-up | 14 | 34 (14) | 1 | 33 | 66 | 14% | 3.7 | 35 (6) | 41 (5) | 21 (3) | 26 (7) | 41 (7) |
| Mine | Early | 1 | 0 (1) | 0 | 0 | 100 | 0% | 3.0 | - | 0 (1) | - | - | 0 (1) |
| Mine | Fast Hammer | 39 | 37 (39) | 19 | 19 | 64 | 15% | 2.6 | 20 (24) | 83 (9) | 41 (6) | 41 (28) | 27 (11) |
| Mine | Fragile | 4 | 0 (4) | 0 | 0 | 73 | 25% | 2.3 | 0 (3) | 0 (1) | - | 0 (1) | 0 (3) |
| Mine | Hammer | 64 | 38 (64) | 29 | 9 | 53 | 16% | 2.5 | 56 (10) | 26 (44) | 87 (10) | 42 (39) | 33 (25) |
| Mine | Holder | 30 | 90 (30) | 6 | 84 | 23 | 40% | 2.7 | 10 (7) | 139 (18) | 33 (5) | 99 (18) | 76 (12) |
| Mine | Shooter | 35 | 81 (35) | 37 | 45 | 38 | 3% | 1.6 | 67 (11) | 96 (19) | 58 (5) | 106 (23) | 37 (12) |
| Mine | Support | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Mine | War machine | 56 | 37 (56) | 37 | 0 | 31 | 5% | 1.2 | 35 (20) | 39 (31) | 32 (5) | 0 (7) | 42 (49) |
| Mine | Wizard | 17 | 25 (17) | 25 | 0 | 64 | 6% | 2.0 | 58 (4) | 29 (4) | 29 (1) | 29 (1) | 44 (8) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Chaff | 82 | 63 (82) | 34 | 29 | 61 | 39% | 2.5 | 59 (30) | 60 (21) | 69 (31) | 64 (62) | 59 (20) |
| Opponent | Character | 97 | 58 (97) | 57 | 1 | 27 | 21% | 2.3 | 58 (42) | 56 (40) | 91 (7) | 54 (49) | 66 (40) |
| Opponent | Clean-up | 12 | 88 (12) | 10 | 78 | 24 | 50% | 2.8 | 0 (3) | 128 (6) | 39 (3) | 84 (7) | 92 (5) |
| Opponent | Fast | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Fast Hammer | 54 | 37 (54) | 32 | 5 | 46 | 31% | 2.6 | 42 (27) | 27 (17) | 40 (10) | 34 (34) | 41 (20) |
| Opponent | Fragile | 16 | 0 (16) | 0 | 0 | 63 | 25% | 1.8 | 0 (2) | 0 (8) | 0 (3) | 0 (9) | 0 (4) |
| Opponent | Hammer | 64 | 21 (64) | 13 | 7 | 42 | 31% | 3.4 | 9 (20) | 22 (38) | 43 (6) | 20 (42) | 21 (22) |
| Opponent | Holder | 27 | 44 (27) | 9 | 35 | 29 | 44% | 4.2 | 22 (9) | 58 (15) | 24 (3) | 48 (13) | 40 (14) |
| Opponent | Shooter | 34 | 103 (34) | 49 | 55 | 41 | 0% | 1.5 | 79 (9) | 101 (23) | 219 (2) | 120 (20) | 79 (14) |
| Opponent | Support | 6 | 0 (6) | 0 | 0 | 49 | 50% | 2.0 | 0 (2) | 0 (1) | - | - | 0 (3) |
| Opponent | War machine | 6 | 125 (6) | 125 | 0 | 19 | 0% | 1.7 | 78 (3) | 192 (3) | - | 78 (3) | 192 (3) |
| Opponent | Wizard | 20 | 8 (20) | 8 | 0 | 51 | 10% | 2.7 | 17 (10) | 0 (3) | 0 (2) | 19 (8) | 1 (7) |

### Deployment: positions vs output by unit type: groups off

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 4 | 0 (4) | 0 | 0 | 100 | 75% | 5.0 | 0 (1) | - | - | - | 0 (1) |
| Mine | Chaff | 49 | 51 (49) | 19 | 32 | 59 | 27% | 2.9 | 32 (21) | 91 (11) | 53 (17) | 76 (32) | 3 (17) |
| Mine | Character | 106 | 52 (106) | 51 | 1 | 47 | 12% | 2.3 | 53 (37) | 63 (45) | 43 (8) | 39 (51) | 80 (39) |
| Mine | Clean-up | 14 | 48 (14) | 1 | 47 | 45 | 21% | 3.2 | 28 (6) | 82 (5) | 21 (3) | 57 (7) | 41 (7) |
| Mine | Early | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Mine | Fast Hammer | 39 | 47 (39) | 21 | 26 | 43 | 18% | 3.0 | 38 (24) | 83 (9) | 25 (6) | 54 (28) | 25 (11) |
| Mine | Fragile | 4 | 0 (4) | 0 | 0 | 46 | 25% | 1.7 | 0 (3) | 0 (1) | - | 0 (1) | 0 (3) |
| Mine | Hammer | 64 | 27 (64) | 19 | 8 | 42 | 9% | 2.8 | 36 (10) | 22 (44) | 46 (10) | 29 (39) | 24 (25) |
| Mine | Holder | 30 | 74 (30) | 12 | 61 | 37 | 27% | 3.0 | 47 (6) | 106 (17) | 0 (7) | 100 (17) | 32 (13) |
| Mine | Shooter | 35 | 89 (35) | 42 | 47 | 39 | 0% | 1.7 | 46 (11) | 129 (19) | 33 (5) | 126 (23) | 23 (12) |
| Mine | Support | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | - | 0 (1) | 0 (1) | - |
| Mine | War machine | 56 | 40 (56) | 40 | 0 | 32 | 4% | 1.4 | 65 (20) | 22 (31) | 29 (5) | 12 (7) | 43 (49) |
| Mine | Wizard | 17 | 18 (17) | 18 | 0 | 46 | 6% | 2.2 | 75 (4) | 0 (3) | 0 (1) | 0 (1) | 33 (7) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | 0 (1) | - | - | - | 0 (1) |
| Opponent | Chaff | 82 | 45 (82) | 20 | 25 | 58 | 38% | 3.1 | 76 (30) | 37 (21) | 23 (31) | 41 (62) | 59 (20) |
| Opponent | Character | 97 | 63 (97) | 63 | 0 | 31 | 20% | 2.5 | 47 (40) | 87 (38) | 54 (7) | 59 (46) | 71 (39) |
| Opponent | Clean-up | 12 | 111 (12) | 17 | 94 | 38 | 25% | 2.4 | 114 (3) | 130 (6) | 65 (3) | 133 (7) | 91 (5) |
| Opponent | Fast | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Fast Hammer | 54 | 50 (54) | 40 | 10 | 32 | 22% | 2.9 | 58 (27) | 23 (17) | 85 (10) | 52 (34) | 46 (20) |
| Opponent | Fragile | 16 | 17 (16) | 17 | 0 | 70 | 44% | 1.8 | 0 (2) | 32 (8) | 0 (3) | 26 (10) | 0 (3) |
| Opponent | Hammer | 64 | 25 (64) | 17 | 8 | 35 | 33% | 3.4 | 26 (20) | 26 (38) | 6 (6) | 28 (42) | 20 (22) |
| Opponent | Holder | 27 | 48 (27) | 14 | 35 | 21 | 52% | 3.8 | 14 (10) | 65 (16) | 25 (1) | 56 (12) | 41 (15) |
| Opponent | Shooter | 34 | 45 (34) | 15 | 30 | 42 | 0% | 1.5 | 28 (9) | 55 (23) | 0 (2) | 40 (20) | 52 (14) |
| Opponent | Support | 6 | 0 (6) | 0 | 0 | 100 | 0% | 5.8 | 0 (3) | - | - | - | 0 (3) |
| Opponent | War machine | 6 | 34 (6) | 34 | 0 | 19 | 0% | 2.0 | 57 (3) | 0 (3) | - | 57 (3) | 0 (3) |
| Opponent | Wizard | 20 | 8 (20) | 8 | 0 | 35 | 5% | 2.5 | 7 (10) | 18 (5) | 0 (2) | 13 (11) | 1 (6) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0114, L0130, L2527, L2634 |
| Charmed Shield | Opponent | L0434, L0624, L0926, L1034, L1126, L1427, L2227, L2527, L2634, L3234 |
| Clockwork Compass | Mine | L1220 |
| Elixir of Power | Mine | L1126 |
| Elixir of Power | Opponent | L0819, L1719, L1819 |
| Fistful of Laurels | Mine | L1819, L1835 |
| Invocation of Nehek | Mine | L2527 |
| Invocation of Nehek | Opponent | L0624, L1427, L2227, L2527 |
| Opal Amulet | Mine | L1427 |
| Opal Amulet | Opponent | L0114, L0214, L1314 |
| Periapt of Soul Exchange | Mine | L2021, L2123 |
| Periapt of Soul Exchange | Opponent | L0520, L1220, L1621, L2021 |
| Ring of Doom | Mine | L0214, L0230, L1126, L1220, L1523 |
| Ring of Doom | Opponent | L0315, L1331, L2331 |
| Ring of Jet | Mine | L1017, L1034, L1126, L1220 |
| Standard of the Fell Warrior | Mine | L1314, L1331 |
| Standard of the Fell Warrior | Opponent | L0713 |
| Storm Daemon (Renegade 2.0) | Mine | L2123 |
| Storm Daemon (Renegade 2.0) | Opponent | L1621, L2021 |
| Twice-Blessed Armour | Mine | L0713, L0729, L1017, L1034 |
| Witch Hunter's Ward | Mine | L0713, L0729, L0819, L0835 |
| Witch Hunter's Ward | Opponent | L0608 |

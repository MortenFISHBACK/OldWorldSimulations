# groups on vs groups off

A = groups on: on-1, 35 of 36 games ended
B = groups off: off-1, 36 of 36 games ended

## Game by game (Victory Points Mine-Opponent; margin = Mine minus Opponent)

| Match-up | Scenario | Seed | A | B | Margin A | Margin B | A minus B | Cost A | Cost B |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0102 | 6 | 1 | Opponent 380-1714 | Opponent 510-1621 | -1334 | -1111 | -223 | 0.00 | 0.00 |
| L0118 | 4 | 1 | Mine 1318-983 | Opponent 774-2414 | +335 | -1640 | +1975 | 0.00 | 0.00 |
| L0135 | 3 | 1 | draw 1846-1599 | Opponent 1440-1746 | +247 | -306 | +553 | 0.00 | 0.00 |
| L0218 | 2 | 1 | Opponent 827-1474 | Opponent 778-1195 | -647 | -417 | -230 | 0.00 | 0.00 |
| L0235 | 1 | 1 | Mine 1965-1386 | Mine 2068-1501 | +579 | +567 | +12 | 0.00 | 0.00 |
| L0319 | 1 | 1 | Mine 2408-1227 | Opponent 520-1726 | +1181 | -1206 | +2387 | 0.00 | 0.00 |
| L0405 | 3 | 1 | draw 1065-1315 | Mine 2819-1097 | -250 | +1722 | -1972 | 0.00 | 0.00 |
| L0421 | 1 | 1 | Mine 3260-530 | Mine 2961-510 | +2730 | +2451 | +279 | 0.00 | 0.00 |
| L0508 | 4 | 1 | Mine 1909-1417 | draw 1365-1244 | +492 | +121 | +371 | 0.00 | 0.00 |
| L0524 | 2 | 1 | Opponent 453-1632 | Opponent 160-1082 | -1179 | -922 | -257 | 0.00 | 0.00 |
| L0612 | 6 | 1 | Mine 2128-1128 | Mine 1343-943 | +1000 | +400 | +600 | 0.00 | 0.00 |
| L0628 | 4 | 1 | Opponent 552-1344 | Mine 1924-1129 | -792 | +795 | -1587 | 0.00 | 0.00 |
| L0717 | 3 | 1 | Opponent 1380-1983 | Opponent 1168-2436 | -603 | -1268 | +665 | 0.00 | 0.00 |
| L0733 | 1 | 1 | Mine 2499-520 | Mine 2058-1357 | +1979 | +701 | +1278 | 0.00 | 0.00 |
| L0823 | 1 | 1 | Opponent 910-3368 | Opponent 1009-2830 | -2458 | -1821 | -637 | 0.00 | 0.00 |
| L0913 | 1 | 1 | Opponent 1102-1698 | draw 1622-1475 | -596 | +147 | -743 | 0.00 | 0.00 |
| L0930 | 6 | 1 | Opponent 1143-1678 | Opponent 1143-1803 | -535 | -660 | +125 | 0.00 | 0.00 |
| L1021 | 1 | 1 | Mine 2102-948 | Mine 2305-535 | +1154 | +1770 | -616 | 0.00 | 0.00 |
| L1114 | 4 | 1 | Opponent 1359-1904 | Mine 1975-903 | -545 | +1072 | -1617 | 0.00 | 0.00 |
| L1131 | 3 | 1 | Opponent 1308-2543 | Mine 1920-1060 | -1235 | +860 | -2095 | 0.00 | 0.00 |
| L1224 | 6 | 1 | Opponent 601-1859 | Mine 2047-782 | -1258 | +1265 | -2523 | 0.00 | 0.00 |
| L1319 | 5 | 1 | draw 1100-1145 | Mine 1120-610 | -45 | +510 | -555 | 0.00 | 0.00 |
| L1335 | 3 | 1 | Mine 1747-1339 | Mine 1599-1182 | +408 | +417 | -9 | 0.00 | 0.00 |
| L1431 | 3 | 1 | Mine 2552-413 | draw 1280-1167 | +2139 | +113 | +2026 | 0.00 | 0.00 |
| L1527 | 3 | 1 | Mine 2023-1223 | Mine 2173-1527 | +800 | +646 | +154 | 0.00 | 0.00 |
| L1625 | 5 | 1 | Mine 2492-298 | Mine 2469-553 | +2194 | +1916 | +278 | 0.00 | 0.00 |
| L1723 | 1 | 1 | Mine 2295-1428 | Opponent 186-2593 | +867 | -2407 | +3274 | 0.00 | 0.00 |
| L1823 | 5 | 1 | Opponent 572-2331 | Opponent 336-2097 | -1759 | -1761 | +2 | 0.00 | 0.00 |
| L1923 | 3 | 1 | Opponent 547-3363 | Opponent 800-2670 | -2816 | -1870 | -946 | 0.00 | 0.00 |
| L2025 | 3 | 1 | Mine 2352-910 | draw 1988-1710 | +1442 | +278 | +1164 | 0.00 | 0.00 |
| L2127 | 3 | 1 | not ended (no) | Opponent 715-3048 | - | -2333 | - | 0.00 | 0.00 |
| L2231 | 5 | 1 | Mine 2652-626 | Mine 2896-321 | +2026 | +2575 | -549 | 0.00 | 0.00 |
| L2335 | 1 | 1 | Mine 1746-1387 | Mine 2983-696 | +359 | +2287 | -1928 | 0.00 | 0.00 |
| L2531 | 5 | 1 | Mine 1830-638 | draw 1050-949 | +1192 | +101 | +1091 | 0.00 | 0.00 |
| L2730 | 6 | 1 | Opponent 513-1779 | Opponent 100-1838 | -1266 | -1738 | +472 | 0.00 | 0.00 |
| L2934 | 6 | 1 | Opponent 931-1458 | Opponent 616-1153 | -527 | -537 | +10 | 0.00 | 0.00 |

## Totals

| | A: groups on | B: groups off |
| --- | --- | --- |
| Mine won / drew / lost | 17 / 3 / 15 | 16 / 5 / 15 |
| Mean margin (Mine - Opponent) | +94 | +20 |
| Cost per game | $0.000 | $0.000 |
| Mine side per game | $0.000 | $0.000 |
| Opponent side per game | $0.000 | $0.000 |
| Cost of the batch | $0.00 | $0.00 |
| Failed calls per game | 0.0 | 0.0 |
| VP from objectives, Mine | 594 | 632 |
| VP from objectives, Opponent | 582 | 565 |
| VP from kills, Mine | 887 | 768 |
| VP from kills, Opponent | 791 | 783 |
| VP from leaders, Mine | 57 | 50 |
| VP from leaders, Opponent | 70 | 81 |
| VP from other, Mine | 1 | 0 |
| VP from other, Opponent | 3 | 3 |
| Units lost, Mine | 5.2 | 5.0 |
| Units lost, Opponent | 5.5 | 4.8 |
| Scorecard: Far marker / quarter contested by round 3 (both sides) | 23% | 21% |
| Scorecard: Lone holders (player turns) (both sides) | 2.1 | 2.2 |
| Scorecard: Round of the first Hammer charge (both sides) | 2.3 | 2.3 |
| Scorecard: Lone charges into a block / monster / character (both sides) | 3.0 | 2.4 |
| Scorecard: Idle units (both sides) | 1.4 | 1.5 |
| Scorecard: Wounded Lords / monsters lost (both sides) | 0.4 | 0.4 |
| Scorecard: Doctrine flags raised (both sides) | 0.0 | 0.0 |
| Scorecard: Answers changed after a flag (both sides) | 0.0 | 0.0 |
| Scorecard: Points that never moved of their own (both sides) | 218.0 | 244.0 |

## Is the difference more than noise?

35 pairs of games: A's margin is +7 VP a game against B's, give or take 437 VP (two standard errors). Verdict: within noise (could be chance).

## KPIs (Morten 2026-11-10)

A = groups on (36 games), B = groups off (36 games).

| KPI | Target | A Mine | A Opponent | A both | B Mine | B Opponent | B both |
| --- | --- | --- | --- | --- | --- | --- | --- |
| Winner chose to follow up after the loser gave ground |  | 98%; on the table 100% | 94%; on the table 94% | 96%; on the table 97% | 98%; on the table 100% | 98%; on the table 98% | 98%; on the table 99% |
| Winner chose to pursue after the loser fell back in good order |  | 83%; on the table 92% | 100%; on the table 100% | 90%; on the table 95% | 91%; on the table 91% | 95%; on the table 95% | 94%; on the table 94% |
| Winner chose to pursue after the loser fled |  | 69%; on the table 76% | 73%; on the table 79% | 71%; on the table 77% | 81%; on the table 81% | 82%; on the table 86% | 82%; on the table 85% |
| Winner chose to follow up or pursue (all three) |  | 88%; on the table 92% | 87%; on the table 89% | 88%; on the table 91% | 93%; on the table 94% | 92%; on the table 93% | 92%; on the table 94% |
| Magic missiles tried each own turn | 50%+ | 26% | 26% | 26% | 28% | 24% | 27% |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 38% | 39% | 38% | 40% | 35% | 38% |
| Points that never fought | lower | 35% | 30% | 32% | 37% | 36% | 37% |
|   infantry points that never fought | lower | 47% | 53% | 49% | 52% | 52% | 52% |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 53% | 57% | 55% | 56% | 57% | 56% |
| Bound items with a magic missile used (at least once a game) |  | 86% | 70% | 79% | 91% | 65% | 79% |
| Bound items with another spell used |  | 69% | 12% | 50% | 50% | 25% | 42% |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 63% | 58% | 61% | 58% | 58% | 58% |
|   their share of the points of units over 100 pts | lower | 47% | 52% | 50% | 51% | 51% | 51% |

Flank and rear charges a unit could have turned to face (the side is the charged unit's):

| Measure | groups on Mine | groups on Opponent | groups off Mine | groups off Opponent |
| --- | --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 53% (48) | 58% (41) | 51% (44) | 40% (25) |
| ...free all their last turn and able to turn (per game) | 0.94 | 0.75 | 0.86 | 0.47 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.19 | 0.19 | 0.14 | 0.06 |
| ...with the charger already in that arc before they moved (per game) | 0.67 | 0.53 | 0.61 | 0.31 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 1.17 | 0.67 | 1.36 | 0.97 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.72 | 0.53 | 0.83 | 0.86 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 10.64 | 9.72 | 10.11 | 10.22 |

### Charges a game and per unit by the wizard it carries

| Charges | A Mine | A Opponent | A both | B Mine | B Opponent | B both |
| --- | --- | --- | --- | --- | --- | --- |
| Charges declared a game | 4.4 | 6.0 | 5.2 | 3.9 | 6.1 | 5.0 |
| Charges that made contact a game | 3.3 | 4.3 | 3.8 | 2.8 | 4.5 | 3.6 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.16 declared, 0.79 contact (19 units) | 0.80 declared, 0.53 contact (15 units) | 1.00 declared, 0.68 contact (34 units) | 1.05 declared, 0.58 contact (19 units) | 0.50 declared, 0.43 contact (14 units) | 0.82 declared, 0.52 contact (33 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.60 declared, 0.60 contact (5 units) | 1.11 declared, 0.89 contact (9 units) | 0.93 declared, 0.79 contact (14 units) | 1.33 declared, 1.17 contact (6 units) | 1.43 declared, 1.00 contact (7 units) | 1.38 declared, 1.08 contact (13 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.53 declared, 0.41 contact (249 units) | 0.68 declared, 0.49 contact (284 units) | 0.61 declared, 0.45 contact (533 units) | 0.45 declared, 0.33 contact (250 units) | 0.71 declared, 0.52 contact (287 units) | 0.59 declared, 0.43 contact (537 units) |

## Movement (Morten 2026-11-11)

A = groups on (36 games), B = groups off (36 games); per side and game.

| Measure | A Mine | A Opponent | A both | B Mine | B Opponent | B both |
| --- | --- | --- | --- | --- | --- | --- |
| Games where this side made the first charge contact | 49% (17 of 35) | 51% (18 of 35) | 50% (35 of 70) | 31% (11 of 36) | 69% (25 of 36) | 50% (36 of 72) |
| Round of a side's first charge contact (sides that made one) | 2.5 | 2.6 | 2.5 | 2.6 | 2.3 | 2.4 |
| Sides that never declared a charge | 8% (3 of 36) | 3% (1 of 36) | 6% (4 of 72) | 17% (6 of 36) | 3% (1 of 36) | 10% (7 of 72) |
| Sides that never made charge contact | 14% (5 of 36) | 6% (2 of 36) | 10% (7 of 72) | 19% (7 of 36) | 6% (2 of 36) | 12% (9 of 72) |
| Charges declared a game | 4.4 | 6.0 | 5.2 | 3.9 | 6.1 | 5.0 |
| Charge contacts made a game | 3.3 | 4.3 | 3.8 | 2.8 | 4.5 | 3.6 |
| Charge contacts received a game | 4.3 | 3.3 | 3.8 | 4.5 | 2.8 | 3.6 |
| Joint charges a game (2+ units on one target in one turn) | 0.3 | 0.5 | 0.4 | 0.2 | 0.8 | 0.5 |
|   share of charged targets hit by 2+ units | 10% (10 of 105) | 14% (19 of 132) | 12% (29 of 237) | 10% (9 of 90) | 21% (27 of 130) | 16% (36 of 220) |
| Lone charges that a friend follows on the same target next turn | 5% (5 of 95) | 4% (4 of 113) | 4% (9 of 208) | 5% (4 of 81) | 6% (6 of 103) | 5% (10 of 184) |
| Set-ups (close in to charge next turn) that charged that target next turn | 13% (21 of 161) | 19% (36 of 193) | 16% (57 of 354) | 15% (24 of 164) | 15% (35 of 227) | 15% (59 of 391) |
|   ... and made contact | 9% (14 of 161) | 12% (24 of 193) | 11% (38 of 354) | 9% (14 of 164) | 10% (22 of 227) | 9% (36 of 391) |
|   ... with a friend on it too | 1% (1 of 161) | 2% (4 of 193) | 1% (5 of 354) | 0% (0 of 164) | 2% (4 of 227) | 1% (4 of 391) |
| Set-ups missed (no charge on that target next turn) | 87% (140 of 161) | 81% (157 of 193) | 84% (297 of 354) | 85% (140 of 164) | 85% (192 of 227) | 85% (332 of 391) |
| Charge contacts in the flank or rear (arc known) | 50% (59 of 119) | 51% (79 of 154) | 51% (138 of 273) | 39% (39 of 100) | 52% (84 of 161) | 47% (123 of 261) |
|   in the rear | 13% (16 of 119) | 8% (13 of 154) | 11% (29 of 273) | 7% (7 of 100) | 14% (22 of 161) | 11% (29 of 261) |
| Declared charges in the flank or rear (arc known) | 48% (76 of 158) | 52% (112 of 215) | 50% (188 of 373) | 43% (60 of 140) | 54% (118 of 220) | 49% (178 of 360) |

## Doctrine scorecard (per game and side; far = share of games contested)

### Scorecard: groups on

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0102 | 6 | 1 | Mine | no | 3 | 2 | 1 | 1 | 1 | 0 | 0 | 0 |
| L0102 | 6 | 1 | Opponent | no | 1 | 1 | 2 | 5 | 1 | 0 | 0 | 170 |
| L0118 | 4 | 1 | Mine | no | 0 | 3 | 0 | 2 | 0 | 0 | 0 | 0 |
| L0118 | 4 | 1 | Opponent | no | 0 | 2 | 5 | 6 | 0 | 0 | 0 | 0 |
| L0135 | 3 | 1 | Mine | no | 1 | - | 0 | 2 | 0 | 0 | 0 | 694 |
| L0135 | 3 | 1 | Opponent | no | 8 | 3 | 3 | 2 | 0 | 0 | 0 | 0 |
| L0218 | 2 | 1 | Mine | - | - | 3 | 3 | 2 | 1 | 0 | 0 | 170 |
| L0218 | 2 | 1 | Opponent | - | - | 5 | 1 | 1 | 0 | 0 | 0 | 0 |
| L0235 | 1 | 1 | Mine | no | 1 | 2 | 3 | 3 | 0 | 0 | 0 | 0 |
| L0235 | 1 | 1 | Opponent | no | 5 | 1 | 3 | 3 | 1 | 0 | 0 | 274 |
| L0319 | 1 | 1 | Mine | no | 8 | 3 | 3 | 0 | 0 | 0 | 0 | 760 |
| L0319 | 1 | 1 | Opponent | no | 2 | 2 | 1 | 0 | 1 | 0 | 0 | 0 |
| L0405 | 3 | 1 | Mine | yes | 1 | 5 | 2 | 1 | 1 | 0 | 0 | 0 |
| L0405 | 3 | 1 | Opponent | no | 2 | 3 | 2 | 2 | 0 | 0 | 0 | 548 |
| L0421 | 1 | 1 | Mine | no | 0 | 2 | 3 | 2 | 0 | 0 | 0 | 0 |
| L0421 | 1 | 1 | Opponent | no | 0 | - | 0 | 4 | 1 | 0 | 0 | 447 |
| L0508 | 4 | 1 | Mine | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 633 |
| L0508 | 4 | 1 | Opponent | no | 4 | - | 0 | 5 | 0 | 0 | 0 | 807 |
| L0524 | 2 | 1 | Mine | - | - | - | 0 | 1 | 0 | 0 | 0 | 901 |
| L0524 | 2 | 1 | Opponent | - | - | 2 | 5 | 4 | 0 | 0 | 0 | 0 |
| L0612 | 6 | 1 | Mine | no | 1 | - | 3 | 2 | 0 | 0 | 0 | 743 |
| L0612 | 6 | 1 | Opponent | no | 8 | 3 | 2 | 0 | 1 | 0 | 0 | 330 |
| L0628 | 4 | 1 | Mine | no | 0 | 3 | 2 | 0 | 0 | 0 | 0 | 615 |
| L0628 | 4 | 1 | Opponent | yes | 0 | 2 | 2 | 0 | 0 | 0 | 0 | 0 |
| L0717 | 3 | 1 | Mine | no | 0 | 2 | 4 | 0 | 0 | 0 | 0 | 375 |
| L0717 | 3 | 1 | Opponent | yes | 4 | 2 | 5 | 1 | 0 | 0 | 0 | 175 |
| L0733 | 1 | 1 | Mine | no | 2 | 3 | 2 | 1 | 1 | 0 | 0 | 375 |
| L0733 | 1 | 1 | Opponent | no | 0 | 1 | 0 | 2 | 0 | 0 | 0 | 0 |
| L0823 | 1 | 1 | Mine | yes | 1 | 2 | 1 | 1 | 1 | 0 | 0 | 560 |
| L0823 | 1 | 1 | Opponent | no | 2 | 2 | 2 | 3 | 2 | 0 | 0 | 60 |
| L0913 | 1 | 1 | Mine | no | 0 | 2 | 3 | 1 | 0 | 0 | 0 | 537 |
| L0913 | 1 | 1 | Opponent | no | 8 | 3 | 2 | 0 | 0 | 0 | 0 | 317 |
| L0930 | 6 | 1 | Mine | no | 0 | 4 | 2 | 1 | 0 | 0 | 0 | 995 |
| L0930 | 6 | 1 | Opponent | no | 4 | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| L1021 | 1 | 1 | Mine | no | 5 | 2 | 4 | 0 | 0 | 0 | 0 | 330 |
| L1021 | 1 | 1 | Opponent | no | 0 | - | 1 | 7 | 1 | 0 | 0 | 145 |
| L1114 | 4 | 1 | Mine | no | 3 | 3 | 1 | 0 | 0 | 0 | 0 | 330 |
| L1114 | 4 | 1 | Opponent | no | 0 | 1 | 6 | 0 | 1 | 0 | 0 | 0 |
| L1131 | 3 | 1 | Mine | no | 1 | - | 2 | 0 | 2 | 0 | 0 | 330 |
| L1131 | 3 | 1 | Opponent | no | 3 | 2 | 4 | 2 | 2 | 0 | 0 | 365 |
| L1224 | 6 | 1 | Mine | no | 10 | 2 | 5 | 0 | 1 | 0 | 0 | 330 |
| L1224 | 6 | 1 | Opponent | no | 0 | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L1319 | 5 | 1 | Mine | yes | - | 2 | 3 | 3 | 0 | 0 | 0 | 140 |
| L1319 | 5 | 1 | Opponent | yes | - | 2 | 2 | 2 | 0 | 0 | 0 | 0 |
| L1335 | 3 | 1 | Mine | no | 4 | 2 | 4 | 0 | 0 | 0 | 0 | 140 |
| L1335 | 3 | 1 | Opponent | no | 2 | 2 | 8 | 0 | 0 | 0 | 0 | 414 |
| L1431 | 3 | 1 | Mine | yes | 1 | 2 | 4 | 0 | 0 | 0 | 0 | 0 |
| L1431 | 3 | 1 | Opponent | no | 0 | - | 1 | 0 | 1 | 0 | 0 | 562 |
| L1527 | 3 | 1 | Mine | no | 6 | 2 | 3 | 0 | 0 | 0 | 0 | 0 |
| L1527 | 3 | 1 | Opponent | no | 0 | 2 | 5 | 1 | 0 | 0 | 0 | 0 |
| L1625 | 5 | 1 | Mine | no | - | 2 | 5 | 2 | 0 | 0 | 0 | 200 |
| L1625 | 5 | 1 | Opponent | yes | - | 1 | 3 | 2 | 0 | 0 | 0 | 0 |
| L1723 | 1 | 1 | Mine | no | 2 | 2 | 4 | 0 | 1 | 0 | 0 | 0 |
| L1723 | 1 | 1 | Opponent | no | 0 | 2 | 7 | 2 | 0 | 0 | 0 | 0 |
| L1823 | 5 | 1 | Mine | yes | - | 3 | 3 | 1 | 1 | 0 | 0 | 0 |
| L1823 | 5 | 1 | Opponent | yes | - | 2 | 5 | 1 | 0 | 0 | 0 | 0 |
| L1923 | 3 | 1 | Mine | yes | 3 | 2 | 6 | 0 | 1 | 0 | 0 | 0 |
| L1923 | 3 | 1 | Opponent | no | 2 | 1 | 5 | 0 | 0 | 0 | 0 | 0 |
| L2025 | 3 | 1 | Mine | yes | 2 | 3 | 3 | 0 | 0 | 0 | 0 | 420 |
| L2025 | 3 | 1 | Opponent | no | 0 | 3 | 6 | 1 | 0 | 0 | 0 | 0 |
| L2127 | 3 | 1 | Mine | - | - | - | - | - | - | - | - | - |
| L2127 | 3 | 1 | Opponent | - | - | - | - | - | - | - | - | - |
| L2231 | 5 | 1 | Mine | yes | - | 2 | 2 | 1 | 0 | 0 | 0 | 72 |
| L2231 | 5 | 1 | Opponent | no | - | 1 | 7 | 0 | 4 | 0 | 0 | 541 |
| L2335 | 1 | 1 | Mine | no | 0 | 1 | 4 | 0 | 0 | 0 | 0 | 60 |
| L2335 | 1 | 1 | Opponent | no | 0 | 3 | 4 | 2 | 0 | 0 | 0 | 0 |
| L2531 | 5 | 1 | Mine | yes | - | 2 | 4 | 4 | 0 | 0 | 0 | 0 |
| L2531 | 5 | 1 | Opponent | yes | - | 4 | 1 | 1 | 1 | 0 | 0 | 170 |
| L2730 | 6 | 1 | Mine | no | 0 | 4 | 5 | 3 | 0 | 0 | 0 | 0 |
| L2730 | 6 | 1 | Opponent | no | 2 | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L2934 | 6 | 1 | Mine | no | 6 | 2 | 5 | 0 | 0 | 0 | 0 | 170 |
| L2934 | 6 | 1 | Opponent | no | 0 | 3 | 4 | 1 | 0 | 0 | 0 | 56 |
| **Average** | | | Mine | 27% | 2.2 | 2.5 | 2.8 | 1.0 | 0.3 | 0.0 | 0.0 | 282.3 |
| **Average** | | | Opponent | 18% | 2.0 | 2.2 | 3.2 | 1.8 | 0.5 | 0.0 | 0.0 | 153.7 |

### Scorecard: groups off

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0102 | 6 | 1 | Mine | no | 4 | - | 0 | 1 | 1 | 0 | 0 | 0 |
| L0102 | 6 | 1 | Opponent | no | 1 | 1 | 3 | 4 | 0 | 0 | 0 | 0 |
| L0118 | 4 | 1 | Mine | no | 1 | - | 0 | 1 | 0 | 0 | 0 | 0 |
| L0118 | 4 | 1 | Opponent | no | 0 | 2 | 4 | 1 | 0 | 0 | 0 | 185 |
| L0135 | 3 | 1 | Mine | yes | 4 | - | 0 | 2 | 0 | 0 | 0 | 639 |
| L0135 | 3 | 1 | Opponent | no | 0 | 2 | 5 | 4 | 0 | 0 | 0 | 0 |
| L0218 | 2 | 1 | Mine | - | - | - | 0 | 6 | 0 | 0 | 0 | 170 |
| L0218 | 2 | 1 | Opponent | - | - | 3 | 0 | 1 | 0 | 0 | 0 | 0 |
| L0235 | 1 | 1 | Mine | no | 0 | 2 | 1 | 4 | 0 | 0 | 0 | 0 |
| L0235 | 1 | 1 | Opponent | no | 1 | 1 | 5 | 2 | 0 | 0 | 0 | 0 |
| L0319 | 1 | 1 | Mine | no | 2 | 3 | 0 | 1 | 0 | 0 | 0 | 675 |
| L0319 | 1 | 1 | Opponent | no | 0 | 2 | 3 | 2 | 0 | 0 | 0 | 0 |
| L0405 | 3 | 1 | Mine | yes | 2 | 2 | 4 | 2 | 1 | 0 | 0 | 0 |
| L0405 | 3 | 1 | Opponent | no | 1 | - | 0 | 0 | 0 | 0 | 0 | 1416 |
| L0421 | 1 | 1 | Mine | no | 0 | 2 | 4 | 3 | 0 | 0 | 0 | 0 |
| L0421 | 1 | 1 | Opponent | no | 1 | - | 0 | 5 | 1 | 0 | 0 | 355 |
| L0508 | 4 | 1 | Mine | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 548 |
| L0508 | 4 | 1 | Opponent | no | 0 | 4 | 1 | 4 | 0 | 0 | 0 | 605 |
| L0524 | 2 | 1 | Mine | - | - | - | 0 | 0 | 0 | 0 | 0 | 548 |
| L0524 | 2 | 1 | Opponent | - | - | 2 | 0 | 4 | 0 | 0 | 0 | 0 |
| L0612 | 6 | 1 | Mine | no | 0 | - | 2 | 2 | 0 | 0 | 0 | 798 |
| L0612 | 6 | 1 | Opponent | no | 6 | 5 | 1 | 0 | 1 | 0 | 0 | 330 |
| L0628 | 4 | 1 | Mine | no | 0 | 2 | 3 | 0 | 0 | 0 | 0 | 1069 |
| L0628 | 4 | 1 | Opponent | yes | 2 | 2 | 2 | 0 | 0 | 0 | 0 | 414 |
| L0717 | 3 | 1 | Mine | no | 3 | 2 | 1 | 0 | 0 | 0 | 0 | 513 |
| L0717 | 3 | 1 | Opponent | no | 10 | 2 | 3 | 2 | 0 | 0 | 0 | 175 |
| L0733 | 1 | 1 | Mine | no | 8 | 2 | 3 | 0 | 1 | 0 | 0 | 375 |
| L0733 | 1 | 1 | Opponent | no | 0 | 1 | 2 | 4 | 0 | 0 | 0 | 316 |
| L0823 | 1 | 1 | Mine | no | 0 | - | 0 | 0 | 1 | 0 | 0 | 515 |
| L0823 | 1 | 1 | Opponent | no | 5 | 2 | 1 | 1 | 2 | 0 | 0 | 185 |
| L0913 | 1 | 1 | Mine | no | 2 | 4 | 2 | 1 | 0 | 0 | 0 | 726 |
| L0913 | 1 | 1 | Opponent | no | 6 | 4 | 3 | 1 | 0 | 0 | 0 | 140 |
| L0930 | 6 | 1 | Mine | no | 0 | 4 | 2 | 1 | 0 | 0 | 0 | 995 |
| L0930 | 6 | 1 | Opponent | no | 4 | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| L1021 | 1 | 1 | Mine | no | 0 | 2 | 4 | 0 | 0 | 0 | 0 | 330 |
| L1021 | 1 | 1 | Opponent | no | 0 | - | 3 | 4 | 1 | 0 | 0 | 650 |
| L1114 | 4 | 1 | Mine | no | 0 | 3 | 1 | 0 | 1 | 0 | 0 | 330 |
| L1114 | 4 | 1 | Opponent | no | 0 | 2 | 3 | 4 | 1 | 0 | 0 | 123 |
| L1131 | 3 | 1 | Mine | no | 2 | 5 | 4 | 0 | 1 | 0 | 0 | 330 |
| L1131 | 3 | 1 | Opponent | no | 2 | - | 0 | 1 | 2 | 0 | 0 | 170 |
| L1224 | 6 | 1 | Mine | no | 3 | 2 | 2 | 0 | 2 | 0 | 0 | 330 |
| L1224 | 6 | 1 | Opponent | no | 10 | 2 | 1 | 3 | 0 | 0 | 0 | 205 |
| L1319 | 5 | 1 | Mine | yes | - | 3 | 1 | 2 | 1 | 0 | 0 | 302 |
| L1319 | 5 | 1 | Opponent | yes | - | 2 | 1 | 1 | 0 | 0 | 0 | 0 |
| L1335 | 3 | 1 | Mine | no | 4 | 2 | 4 | 0 | 1 | 0 | 0 | 140 |
| L1335 | 3 | 1 | Opponent | no | 2 | 2 | 4 | 3 | 1 | 0 | 0 | 140 |
| L1431 | 3 | 1 | Mine | yes | 0 | 2 | 2 | 0 | 0 | 0 | 0 | 177 |
| L1431 | 3 | 1 | Opponent | no | 5 | 2 | 2 | 1 | 2 | 0 | 0 | 170 |
| L1527 | 3 | 1 | Mine | no | 5 | 2 | 5 | 1 | 0 | 0 | 0 | 199 |
| L1527 | 3 | 1 | Opponent | no | 0 | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L1625 | 5 | 1 | Mine | yes | - | 3 | 3 | 1 | 0 | 0 | 0 | 200 |
| L1625 | 5 | 1 | Opponent | yes | - | 1 | 3 | 0 | 0 | 0 | 0 | 0 |
| L1723 | 1 | 1 | Mine | yes | 3 | 2 | 4 | 0 | 3 | 0 | 0 | 147 |
| L1723 | 1 | 1 | Opponent | no | 0 | 2 | 5 | 0 | 0 | 0 | 0 | 0 |
| L1823 | 5 | 1 | Mine | yes | - | - | 2 | 1 | 1 | 0 | 0 | 0 |
| L1823 | 5 | 1 | Opponent | yes | - | 2 | 5 | 3 | 0 | 0 | 0 | 66 |
| L1923 | 3 | 1 | Mine | yes | 2 | 2 | 6 | 1 | 1 | 0 | 0 | 0 |
| L1923 | 3 | 1 | Opponent | no | 2 | 1 | 5 | 0 | 0 | 0 | 0 | 0 |
| L2025 | 3 | 1 | Mine | yes | 5 | - | 1 | 2 | 1 | 0 | 0 | 420 |
| L2025 | 3 | 1 | Opponent | no | 1 | 2 | 2 | 0 | 0 | 0 | 0 | 0 |
| L2127 | 3 | 1 | Mine | no | 6 | - | 3 | 2 | 1 | 0 | 0 | 577 |
| L2127 | 3 | 1 | Opponent | no | 5 | 1 | 4 | 1 | 0 | 0 | 0 | 0 |
| L2231 | 5 | 1 | Mine | yes | - | 2 | 2 | 0 | 0 | 0 | 0 | 0 |
| L2231 | 5 | 1 | Opponent | no | - | 1 | 6 | 1 | 3 | 0 | 0 | 541 |
| L2335 | 1 | 1 | Mine | no | 0 | 1 | 2 | 2 | 0 | 0 | 0 | 0 |
| L2335 | 1 | 1 | Opponent | no | 0 | 3 | 3 | 1 | 0 | 0 | 0 | 158 |
| L2531 | 5 | 1 | Mine | no | - | 5 | 2 | 5 | 0 | 0 | 0 | 0 |
| L2531 | 5 | 1 | Opponent | no | - | 2 | 2 | 1 | 1 | 0 | 0 | 170 |
| L2730 | 6 | 1 | Mine | no | 0 | 4 | 6 | 2 | 0 | 0 | 0 | 0 |
| L2730 | 6 | 1 | Opponent | no | 5 | 2 | 5 | 1 | 0 | 0 | 0 | 0 |
| L2934 | 6 | 1 | Mine | no | 0 | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L2934 | 6 | 1 | Opponent | no | 0 | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 29% | 1.9 | 2.6 | 2.2 | 1.3 | 0.5 | 0.0 | 0.0 | 307.0 |
| **Average** | | | Opponent | 12% | 2.4 | 2.1 | 2.6 | 1.8 | 0.4 | 0.0 | 0.0 | 180.9 |


## Charged fights (points per fight a side charged into; a combined charge is one fight)

### Charged fights: groups on

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 5 | 281 | 61 | 1.8 | 1.1 | 34 | 3 | +30 | 1 of 9 | 7 of 9 | +40 | +29 |
| Mine | Chaos Dwarfs | 3 | 22 | 561 | 3.7 | 1.1 | 153 | 20 | +133 | 8 of 11 | 7 of 11 | +261 | +120 |
| Mine | Dwarfen Mountain Holds | 4 | 487 | 79 | 1.5 | 1.3 | 53 | 113 | -60 | 3 of 6 | 3 of 6 | -363 | +1 |
| Mine | Empire of Man | 5 | 510 | 228 | 2.2 | 1.2 | 104 | 40 | +63 | 2 of 11 | 4 of 11 | +77 | +60 |
| Mine | Grand Cathay | 4 | 506 | 0 | 2.0 | 1.0 | 0 | 0 | +0 | 6 of 8 | 4 of 7 | - | +0 |
| Mine | High Elf Realms | 4 | 121 | 748 | 4.0 | 1.1 | 187 | 9 | +178 | 4 of 16 | 9 of 16 | +913 | +129 |
| Mine | Kingdom of Bretonnia | 1 | 75 | 1290 | 4.0 | 1.0 | 322 | 0 | +322 | 1 of 4 | 3 of 4 | - | +322 |
| Mine | Lizardmen | 1 | 66 | 876 | 4.0 | 1.0 | 219 | 0 | +219 | 1 of 4 | 3 of 4 | - | +219 |
| Mine | Ogre Kingdoms | 1 | 0 | 202 | 4.0 | 1.2 | 50 | 0 | +50 | 0 of 4 | 4 of 4 | +66 | +45 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 331 | 6.0 | 1.0 | 55 | 88 | -33 | 2 of 6 | 4 of 6 | - | -33 |
| Mine | Skaven | 1 | 331 | 751 | 5.0 | 1.0 | 150 | 0 | +150 | 2 of 5 | 3 of 5 | - | +150 |
| Mine | Tomb Kings of Khemri | 2 | 58 | 864 | 4.0 | 1.1 | 216 | 9 | +207 | 2 of 8 | 5 of 8 | +888 | +110 |
| Mine | Vampire Counts | 2 | 0 | 768 | 4.0 | 1.2 | 192 | 77 | +115 | 3 of 8 | 5 of 8 | +53 | +124 |
| Mine | Warriors of Chaos | 1 | 0 | 382 | 4.0 | 1.0 | 96 | 0 | +96 | 1 of 4 | 4 of 4 | - | +96 |
| **Mine** | all armies | 35 | 259 | 387 | 3.0 | 1.1 | 130 | 26 | +104 | 36 of 104 | 65 of 103 | +224 | +93 |
| Opponent | Beastmen Brayherds | 1 | 55 | 77 | 1.0 | 1.0 | 77 | 0 | +77 | 0 of 1 | 1 of 1 | - | +77 |
| Opponent | Dwarfen Mountain Holds | 1 | 890 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 0 of 1 | 1 of 1 | - | +0 |
| Opponent | Empire of Man | 1 | 562 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Grand Cathay | 1 | 235 | 105 | 2.0 | 1.0 | 52 | 0 | +52 | 1 of 2 | 0 of 2 | - | +52 |
| Opponent | High Elf Realms | 2 | 198 | 908 | 6.5 | 1.3 | 140 | 11 | +129 | 4 of 13 | 8 of 13 | +143 | +124 |
| Opponent | Lizardmen | 1 | 0 | 971 | 6.0 | 1.2 | 162 | 14 | +148 | 2 of 6 | 5 of 6 | +189 | +140 |
| Opponent | Ogre Kingdoms | 2 | 28 | 68 | 3.5 | 1.3 | 20 | 65 | -45 | 4 of 7 | 4 of 7 | -66 | -37 |
| Opponent | Orc & Goblin Tribes | 2 | 35 | 262 | 3.5 | 1.1 | 75 | 47 | +28 | 5 of 7 | 2 of 7 | -110 | +51 |
| Opponent | Skaven | 2 | 0 | 0 | 0.5 | 1.0 | 0 | 0 | +0 | 1 of 1 | 0 of 1 | - | +0 |
| Opponent | Tomb Kings of Khemri | 4 | 182 | 975 | 4.5 | 1.2 | 217 | 14 | +202 | 9 of 18 | 11 of 18 | +304 | +182 |
| Opponent | Vampire Counts | 5 | 173 | 547 | 5.4 | 1.1 | 101 | 10 | +92 | 12 of 27 | 13 of 27 | +117 | +90 |
| Opponent | Warriors of Chaos | 7 | 7 | 395 | 3.4 | 1.0 | 115 | 11 | +104 | 6 of 24 | 13 of 24 | +50 | +107 |
| Opponent | Wood Elf Realms | 6 | 100 | 332 | 3.8 | 1.2 | 87 | 56 | +30 | 8 of 23 | 12 of 23 | +104 | +10 |
| **Opponent** | all armies | 35 | 129 | 429 | 3.7 | 1.2 | 116 | 24 | +92 | 52 of 130 | 70 of 130 | +116 | +88 |

### Charged fights: groups off

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 5 | 197 | 0 | 0.6 | 1.0 | 0 | 63 | -63 | 0 of 3 | 0 of 3 | - | -63 |
| Mine | Chaos Dwarfs | 3 | 135 | 982 | 2.7 | 1.1 | 368 | 12 | +356 | 6 of 8 | 5 of 8 | -95 | +421 |
| Mine | Dwarfen Mountain Holds | 4 | 303 | 146 | 1.0 | 1.0 | 146 | 88 | +59 | 1 of 4 | 0 of 4 | - | +59 |
| Mine | Empire of Man | 5 | 526 | 120 | 1.2 | 1.2 | 100 | 49 | +51 | 0 of 6 | 3 of 6 | -104 | +82 |
| Mine | Grand Cathay | 4 | 395 | 378 | 2.8 | 1.1 | 138 | 38 | +99 | 7 of 11 | 4 of 11 | +470 | +62 |
| Mine | High Elf Realms | 4 | 278 | 468 | 4.0 | 1.1 | 117 | 48 | +69 | 6 of 16 | 12 of 16 | +251 | +57 |
| Mine | Kingdom of Bretonnia | 1 | 147 | 1007 | 7.0 | 1.6 | 144 | 0 | +144 | 2 of 7 | 3 of 7 | +180 | +116 |
| Mine | Lizardmen | 1 | 66 | 0 | 4.0 | 1.0 | 0 | 56 | -56 | 1 of 4 | 1 of 4 | - | -56 |
| Mine | Ogre Kingdoms | 1 | 70 | 66 | 2.0 | 1.0 | 33 | 17 | +16 | 1 of 2 | 0 of 2 | - | +16 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 415 | 6.0 | 1.0 | 69 | 44 | +26 | 2 of 6 | 3 of 6 | - | +26 |
| Mine | Skaven | 2 | 70 | 259 | 2.5 | 1.0 | 104 | 0 | +104 | 1 of 5 | 3 of 5 | - | +104 |
| Mine | Tomb Kings of Khemri | 2 | 113 | 690 | 4.0 | 1.2 | 172 | 0 | +172 | 2 of 8 | 5 of 8 | +160 | +176 |
| Mine | Vampire Counts | 2 | 58 | 132 | 4.0 | 1.0 | 33 | 12 | +21 | 1 of 8 | 4 of 8 | - | +21 |
| Mine | Warriors of Chaos | 1 | 0 | 91 | 2.0 | 1.0 | 46 | 0 | +46 | 0 of 2 | 1 of 2 | - | +46 |
| **Mine** | all armies | 36 | 241 | 313 | 2.5 | 1.1 | 125 | 30 | +95 | 30 of 90 | 44 of 90 | +154 | +88 |
| Opponent | Beastmen Brayherds | 1 | 0 | 65 | 4.0 | 1.2 | 16 | 8 | +9 | 2 of 4 | 4 of 4 | +65 | -10 |
| Opponent | Dwarfen Mountain Holds | 1 | 955 | 0 | 1.0 | 2.0 | 0 | 0 | +0 | 0 of 1 | 1 of 1 | +0 | - |
| Opponent | Empire of Man | 1 | 65 | 289 | 1.0 | 1.0 | 289 | 0 | +289 | 1 of 1 | 1 of 1 | - | +289 |
| Opponent | Grand Cathay | 1 | 355 | 185 | 1.0 | 1.0 | 185 | 217 | -32 | 1 of 1 | 0 of 1 | - | -32 |
| Opponent | High Elf Realms | 2 | 62 | 748 | 2.5 | 1.2 | 299 | 0 | +299 | 2 of 5 | 5 of 5 | +416 | +270 |
| Opponent | Lizardmen | 1 | 125 | 825 | 4.0 | 1.2 | 206 | 0 | +206 | 3 of 4 | 4 of 4 | +0 | +275 |
| Opponent | Ogre Kingdoms | 2 | 28 | 457 | 4.0 | 1.1 | 114 | 4 | +110 | 2 of 8 | 5 of 8 | -34 | +131 |
| Opponent | Orc & Goblin Tribes | 2 | 148 | 406 | 4.0 | 1.0 | 102 | 7 | +95 | 4 of 8 | 5 of 8 | - | +95 |
| Opponent | Skaven | 2 | 0 | 0 | 1.0 | 1.0 | 0 | 32 | -32 | 2 of 2 | 0 of 2 | - | -32 |
| Opponent | Tomb Kings of Khemri | 4 | 40 | 964 | 5.8 | 1.3 | 168 | 9 | +159 | 12 of 23 | 16 of 23 | +96 | +176 |
| Opponent | Vampire Counts | 6 | 0 | 312 | 3.5 | 1.5 | 89 | 60 | +29 | 8 of 21 | 16 of 21 | +70 | +4 |
| Opponent | Warriors of Chaos | 7 | 7 | 425 | 3.3 | 1.1 | 129 | 18 | +112 | 10 of 23 | 17 of 23 | +127 | +110 |
| Opponent | Wood Elf Realms | 6 | 84 | 553 | 4.8 | 1.3 | 114 | 27 | +87 | 15 of 29 | 17 of 29 | +153 | +66 |
| **Opponent** | all armies | 36 | 75 | 461 | 3.6 | 1.2 | 128 | 24 | +104 | 62 of 130 | 91 of 130 | +104 | +104 |


## Effective charges (55-75% to win the first round: just enough force)

### Effective charges: groups on

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 9 | 2 (net -15) | 0 | 2 (net +57) | 2 (net +55) | 1 (net +40) | 2 (net +20) | 0 | 22% (2 of 9) |
| Mine | Chaos Dwarfs | 11 | 2 (net +175) | 0 | 0 | 4 (net +182) | 0 | 5 (net +77) | 0 | 0% (0 of 11) |
| Mine | Dwarfen Mountain Holds | 6 | 2 (net -10) | 0 | 2 (net -126) | 1 (net +41) | 0 | 1 (net -128) | 0 | 33% (2 of 6) |
| Mine | Empire of Man | 11 | 1 (net -104) | 1 (net -60) | 3 (net +85) | 1 (net +332) | 1 (net +60) | 3 (net +70) | 1 | 30% (3 of 10) |
| Mine | Grand Cathay | 8 | 1 (net +0) | 0 | 2 (net +0) | 2 (net +0) | 0 | 3 (net +0) | 0 | 25% (2 of 8) |
| Mine | High Elf Realms | 16 | 1 (net +0) | 0 | 2 (net +30) | 1 (net +195) | 4 (net +345) | 5 (net +218) | 3 | 15% (2 of 13) |
| Mine | Kingdom of Bretonnia | 4 | 1 (net +666) | 0 | 0 | 1 (net +153) | 1 (net +45) | 1 (net +426) | 0 | 0% (0 of 4) |
| Mine | Lizardmen | 4 | 1 (net +325) | 0 | 0 | 0 | 1 (net +60) | 0 | 2 | 0% (0 of 2) |
| Mine | Ogre Kingdoms | 4 | 0 | 0 | 0 | 1 (net +66) | 2 (net +68) | 0 | 1 | 0% (0 of 3) |
| Mine | Orc & Goblin Tribes | 6 | 0 | 0 | 0 | 0 | 2 (net +33) | 0 | 4 | 0% (0 of 2) |
| Mine | Skaven | 5 | 1 (net +0) | 0 | 1 (net +0) | 1 (net +398) | 1 (net +85) | 1 (net +268) | 0 | 20% (1 of 5) |
| Mine | Tomb Kings of Khemri | 8 | 0 | 0 | 0 | 0 | 1 (net +888) | 2 (net +216) | 5 | 0% (0 of 3) |
| Mine | Vampire Counts | 8 | 0 | 1 (net +863) | 2 (net -226) | 1 (net +53) | 0 | 4 (net +114) | 0 | 25% (2 of 8) |
| Mine | Warriors of Chaos | 4 | 0 | 0 | 0 | 1 (net +0) | 2 (net +191) | 0 | 1 | 0% (0 of 3) |
| Opponent | Beastmen Brayherds | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +77) | 0 | 0% (0 of 1) |
| Opponent | Dwarfen Mountain Holds | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +0) | 0 | 0% (0 of 1) |
| Opponent | Grand Cathay | 2 | 1 (net +0) | 0 | 0 | 1 (net +105) | 0 | 0 | 0 | 0% (0 of 2) |
| Opponent | High Elf Realms | 13 | 2 (net +352) | 0 | 1 (net +0) | 3 (net +127) | 1 (net +189) | 4 (net +64) | 2 | 9% (1 of 11) |
| Opponent | Lizardmen | 6 | 0 | 0 | 2 (net +200) | 0 | 1 (net +110) | 2 (net +189) | 1 | 40% (2 of 5) |
| Opponent | Ogre Kingdoms | 7 | 0 | 0 | 0 | 1 (net +52) | 0 | 2 (net -210) | 4 | 0% (0 of 3) |
| Opponent | Orc & Goblin Tribes | 7 | 1 (net +347) | 0 | 1 (net +0) | 0 | 0 | 1 (net -110) | 4 | 33% (1 of 3) |
| Opponent | Skaven | 1 | 1 (net +0) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 1) |
| Opponent | Tomb Kings of Khemri | 18 | 0 | 0 | 2 (net +20) | 6 (net +375) | 1 (net +90) | 6 (net +160) | 3 | 13% (2 of 15) |
| Opponent | Vampire Counts | 27 | 8 (net +139) | 0 | 3 (net +2) | 8 (net +56) | 0 | 6 (net +151) | 2 | 12% (3 of 25) |
| Opponent | Warriors of Chaos | 24 | 2 (net +250) | 1 (net +663) | 1 (net +0) | 3 (net +11) | 2 (net +112) | 11 (net +109) | 4 | 5% (1 of 20) |
| Opponent | Wood Elf Realms | 23 | 3 (net -147) | 1 (net -264) | 1 (net +0) | 3 (net +90) | 2 (net +108) | 9 (net +107) | 4 | 5% (1 of 19) |

### Effective charges: groups off

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 3 | 0 | 0 | 0 | 2 (net -68) | 0 | 0 | 1 | 0% (0 of 2) |
| Mine | Chaos Dwarfs | 8 | 3 (net +477) | 0 | 0 | 1 (net -95) | 1 (net +0) | 2 (net +710) | 1 | 0% (0 of 7) |
| Mine | Dwarfen Mountain Holds | 4 | 1 (net +194) | 0 | 1 (net +0) | 1 (net +41) | 0 | 1 (net +0) | 0 | 25% (1 of 4) |
| Mine | Empire of Man | 6 | 2 (net -52) | 0 | 1 (net +258) | 1 (net -189) | 0 | 2 (net +171) | 0 | 17% (1 of 6) |
| Mine | Grand Cathay | 11 | 1 (net +0) | 0 | 4 (net +1) | 1 (net +540) | 1 (net -217) | 3 (net +216) | 1 | 40% (4 of 10) |
| Mine | High Elf Realms | 16 | 1 (net +0) | 0 | 3 (net +83) | 3 (net +37) | 4 (net +95) | 4 (net +247) | 1 | 20% (3 of 15) |
| Mine | Kingdom of Bretonnia | 7 | 2 (net +210) | 0 | 0 | 0 | 3 (net +63) | 2 (net +199) | 0 | 0% (0 of 7) |
| Mine | Lizardmen | 4 | 1 (net +0) | 0 | 0 | 1 (net +0) | 0 | 1 (net +0) | 1 | 0% (0 of 3) |
| Mine | Orc & Goblin Tribes | 6 | 0 | 0 | 0 | 0 | 2 (net +0) | 0 | 4 | 0% (0 of 2) |
| Mine | Skaven | 5 | 3 (net +0) | 0 | 0 | 0 | 0 | 2 (net +259) | 0 | 0% (0 of 5) |
| Mine | Tomb Kings of Khemri | 8 | 0 | 0 | 0 | 1 (net +116) | 2 (net +160) | 3 (net +268) | 2 | 0% (0 of 6) |
| Mine | Vampire Counts | 8 | 1 (net -50) | 0 | 2 (net -22) | 1 (net +0) | 2 (net +132) | 2 (net +0) | 0 | 25% (2 of 8) |
| Mine | Warriors of Chaos | 2 | 0 | 0 | 0 | 0 | 0 | 1 (net +91) | 1 | 0% (0 of 1) |
| Opponent | Beastmen Brayherds | 4 | 0 | 0 | 0 | 1 (net +65) | 0 | 3 (net -10) | 0 | 0% (0 of 4) |
| Opponent | Dwarfen Mountain Holds | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +0) | 0 | 0% (0 of 1) |
| Opponent | Empire of Man | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +289) | 0 | 0% (0 of 1) |
| Opponent | Grand Cathay | 1 | 1 (net -32) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 1) |
| Opponent | High Elf Realms | 5 | 1 (net +704) | 0 | 0 | 2 (net +322) | 1 (net +150) | 0 | 1 | 0% (0 of 4) |
| Opponent | Lizardmen | 4 | 0 | 0 | 0 | 0 | 1 (net +0) | 1 (net +0) | 2 | 0% (0 of 2) |
| Opponent | Ogre Kingdoms | 8 | 0 | 0 | 1 (net +0) | 1 (net -34) | 2 (net +71) | 2 (net +386) | 2 | 17% (1 of 6) |
| Opponent | Orc & Goblin Tribes | 8 | 0 | 0 | 1 (net +310) | 0 | 0 | 0 | 7 | 100% (1 of 1) |
| Opponent | Skaven | 2 | 1 (net +0) | 0 | 0 | 1 (net -65) | 0 | 0 | 0 | 0% (0 of 2) |
| Opponent | Tomb Kings of Khemri | 23 | 1 (net +0) | 1 (net +0) | 4 (net +181) | 7 (net +122) | 0 | 7 (net +214) | 3 | 20% (4 of 20) |
| Opponent | Vampire Counts | 21 | 2 (net -50) | 0 | 6 (net +19) | 3 (net +0) | 2 (net +320) | 6 (net -8) | 2 | 32% (6 of 19) |
| Opponent | Warriors of Chaos | 23 | 1 (net +499) | 0 | 1 (net +0) | 6 (net +174) | 3 (net +98) | 7 (net +145) | 5 | 6% (1 of 18) |
| Opponent | Wood Elf Realms | 29 | 5 (net -26) | 0 | 4 (net +207) | 2 (net +32) | 2 (net +32) | 11 (net +138) | 5 | 17% (4 of 24) |


## Charged fights by odds band, damage counted (Morten 2026-11-10)

### Charged fights, damage counted: groups on

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 12 | 188 | 221 | +99 | 138 | 62 | +76 | +40.5 |
| Mine | 50-54% | 2 | 334 | 216 | +402 | 432 | 90 | +342 | +102.1 |
| Mine | Effective (55-75%) | 14 | 264 | 256 | -20 | 57 | 96 | -39 | -14.6 |
| Mine | 76-89% | 16 | 257 | 174 | +130 | 153 | 27 | +125 | +48.8 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 27 | 235 | 195 | +118 | 161 | 37 | +124 | +52.9 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 16 | 396 | 93 | +196 | 196 | 7 | +189 | +47.8 |
| Mine | No odds | 17 | 296 | 156 | +40 | 99 | 53 | +45 | +15.4 |
| Mine | All fights | 104 | 273 | 181 | +104 | 144 | 45 | +98 | +35.9 |
| Opponent | Long shot (under 50%) | 18 | 238 | 254 | +124 | 184 | 64 | +120 | +50.2 |
| Opponent | 50-54% | 2 | 489 | 440 | +200 | 499 | 300 | +200 | +40.8 |
| Opponent | Effective (55-75%) | 11 | 215 | 184 | +41 | 107 | 46 | +60 | +28.0 |
| Opponent | 76-89% | 25 | 368 | 210 | +142 | 177 | 25 | +153 | +41.5 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 43 | 271 | 182 | +98 | 135 | 30 | +106 | +38.9 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 7 | 411 | 102 | +119 | 119 | 29 | +90 | +21.9 |
| Opponent | No odds | 24 | 157 | 203 | +12 | 38 | 23 | +15 | +9.6 |
| Opponent | All fights | 130 | 270 | 201 | +92 | 134 | 38 | +97 | +35.7 |

### Charged fights, damage counted: groups off

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 15 | 212 | 218 | +126 | 177 | 60 | +117 | +55.3 |
| Mine | Effective (55-75%) | 11 | 194 | 206 | +43 | 84 | 37 | +46 | +24.0 |
| Mine | 76-89% | 12 | 199 | 172 | +32 | 112 | 73 | +39 | +19.8 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 23 | 273 | 193 | +226 | 252 | 14 | +239 | +87.4 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 15 | 430 | 96 | +62 | 122 | 24 | +98 | +22.9 |
| Mine | No odds | 14 | 245 | 176 | -26 | 73 | 86 | -13 | -5.1 |
| Mine | All fights | 90 | 265 | 177 | +95 | 151 | 45 | +106 | +40.0 |
| Opponent | Long shot (under 50%) | 12 | 320 | 283 | +78 | 205 | 134 | +71 | +22.3 |
| Opponent | 50-54% | 1 | 195 | 251 | +0 | 126 | 0 | +126 | +64.4 |
| Opponent | Effective (55-75%) | 17 | 365 | 235 | +116 | 183 | 44 | +138 | +37.8 |
| Opponent | 76-89% | 23 | 259 | 191 | +112 | 142 | 34 | +108 | +41.8 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 39 | 245 | 200 | +128 | 165 | 30 | +135 | +54.9 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 11 | 356 | 89 | +117 | 126 | 13 | +113 | +31.7 |
| Opponent | No odds | 27 | 302 | 257 | +65 | 130 | 32 | +97 | +32.2 |
| Opponent | All fights | 130 | 291 | 214 | +104 | 156 | 41 | +115 | +39.5 |


## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| groups on | move | 456 | 112 (25%) | 81 (18%) | 57 (12%) | 287 (63%) |
| groups on | objective | 354 | 57 (16%) | 38 (11%) | 38 (11%) | 259 (73%) |
| groups off | move | 473 | 102 (22%) | 74 (16%) | 59 (12%) | 312 (66%) |
| groups off | objective | 391 | 60 (15%) | 36 (9%) | 49 (13%) | 282 (72%) |

## Combined arms (paper 2026-11-09, item 8)

### Combined arms: groups on (35 games)

| Side | Fights with 2+ chargers | Enemy charges answered by a counter-charge | Blocks with an escort in reach (end of Movement) | Screens that took the charge | Lanes opened (rule rows) / blocker gone that round |
| --- | --- | --- | --- | --- | --- |
| Mine | 9 of 104 (9%) | 7 of 150 (5%) | 198 of 399 (50%) | 0.37 per game | 0.09 / 0.00 per game |
| Opponent | 18 of 130 (14%) | 10 of 116 (9%) | 141 of 281 (50%) | 0.43 per game | 0.09 / 0.03 per game |

### Combined arms: groups off (36 games)

| Side | Fights with 2+ chargers | Enemy charges answered by a counter-charge | Blocks with an escort in reach (end of Movement) | Screens that took the charge | Lanes opened (rule rows) / blocker gone that round |
| --- | --- | --- | --- | --- | --- |
| Mine | 9 of 90 (10%) | 8 of 161 (5%) | 180 of 363 (50%) | 0.22 per game | 0.14 / 0.03 per game |
| Opponent | 27 of 130 (21%) | 8 of 100 (8%) | 151 of 316 (48%) | 0.28 per game | 0.03 / 0.00 per game |


## Quality by phase (per game and side)

| Phase | Number | A Mine | A Opponent | B Mine | B Opponent |
| --- | --- | --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.1 | 3.4 | 3.1 | 3.4 |
| Strategy | Charge objectives carried out (made contact) | 49% (68 of 139) | 46% (84 of 184) | 48% (58 of 121) | 46% (81 of 175) |
| Strategy | Shoot objectives carried out (shot that target) | 54% (186 of 346) | 65% (99 of 152) | 58% (209 of 361) | 55% (82 of 148) |
| Strategy | Close-in objectives charged next turn | 13% (21 of 161) | 19% (36 of 193) | 15% (25 of 164) | 15% (35 of 227) |
| Strategy | Support requests answered (helper made contact too) | 50% (10 of 20) | 61% (17 of 28) | 38% (3 of 8) | 77% (23 of 30) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (1 of 1) | 50% (2 of 4) | 33% (1 of 3) | 100% (2 of 2) |
| Strategy | Hexes on a unit its side charged or shot that turn | 44% (7 of 16) | 64% (7 of 11) | 21% (3 of 14) | 41% (7 of 17) |
| Strategy | Joined characters whose unit fought | 46% (23 of 50) | 70% (26 of 37) | 37% (18 of 49) | 51% (23 of 45) |
| Strategy | Lone characters that fought | 83% (77 of 93) | 80% (74 of 93) | 82% (80 of 97) | 80% (73 of 91) |
| Movement | Charges halted short of contact | 0.1 | 0.2 | 0.2 | 0.1 |
| Movement | Idle units | 1.0 | 1.8 | 1.3 | 1.8 |
| Movement | Points that never moved of their own | 282.3 | 153.7 | 307.0 | 180.9 |
| Movement | Fights charged into per game | 3.0 | 3.7 | 2.5 | 3.6 |
| Movement | Charges with odds: long shots (under 50%) | 12 of 87, net +99 | 18 of 106, net +124 | 15 of 76, net +126 | 12 of 103, net +78 |
| Movement | Charges with odds: sweet spot (55-75%) | 14 of 87, net -20 | 11 of 106, net +41 | 11 of 76, net +43 | 17 of 103, net +116 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 16 of 87, net +196 | 7 of 106, net +119 | 15 of 76, net +62 | 11 of 103, net +117 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 27 of 87, net +118 | 43 of 106, net +98 | 23 of 76, net +226 | 39 of 103, net +128 |
| Shooting | Shots by shooting units (incl. breath weapons) | 9.4 | 8.7 | 9.7 | 9.2 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 54% (129 of 237) | 33% (16 of 49) | 54% (137 of 256) | 33% (17 of 51) |
| Shooting | Points destroyed by shooting units | 71.7 | 51.9 | 62.9 | 14.7 |
| Shooting | War machine shots | 6.6 | 1.4 | 7.1 | 1.4 |
| Shooting | Points destroyed by war machines | 109.0 | 35.1 | 94.8 | 36.4 |
| Magic | Magic missiles cast | 1.4 | 0.9 | 1.4 | 0.8 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 35% (18 of 52) | 42% (14 of 33) | 31% (16 of 52) | 55% (16 of 29) |
| Magic | Wounds caused by magic missiles | 3.6 | 1.2 | 4.4 | 1.1 |
| Magic | Wounds caused by other spells | 1.8 | 0.6 | 2.4 | 0.5 |
| Magic | Points destroyed by magic (all spells) | 71.0 | 38.2 | 83.6 | 23.7 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.2 / 0.5 / 1.1 / 0.1 | 1.7 / 0.4 / 0.5 / 0.0 | 1.2 / 0.4 / 0.9 / 0.1 | 1.5 / 0.5 / 0.4 / 0.1 |
| Combat | Points destroyed in combat | 332.4 | 419.1 | 299.5 | 424.4 |
| Combat | Points run down | 105.3 | 44.5 | 92.6 | 82.2 |
| Combat | Net points per charged fight, damage counted | +98 | +97 | +106 | +115 |
| Combat | Net per 100 charger points, damage counted | +35.9 | +35.7 | +40.0 | +39.5 |
| Combat | First round won (charged fights) | 63% | 54% | 49% | 70% |
| Combat | Net points per charged fight | +104 | +92 | +95 | +104 |
| Combat | Net points per supported fight / lone fight | +224 / +93 | +116 / +88 | +154 / +88 | +104 / +104 |
| Combat | Charged fights on a top-3 enemy unit | 36 of 104 | 52 of 130 | 30 of 90 | 62 of 130 |
| Game | Points lost | 756.3 | 855.0 | 747.8 | 707.5 |
| Game | VP from objectives | 593.7 | 581.7 | 632.5 | 564.7 |
| Game | Lone holders (player turns) | 2.2 | 2.0 | 1.9 | 2.4 |

A = groups on:
- Mine won / drew / lost: 17 / 3 / 15 of 35 ended games (of 36); mean margin (Mine - Opponent) +94 VP
- The side that went first won 17 of 32 games with a winner
- Points traded per game (both sides' losses): 1611
- Games not ended: 1 (L2127-1); findings 1, warnings 0

B = groups off:
- Mine won / drew / lost: 16 / 5 / 15 of 36 ended games (of 36); mean margin (Mine - Opponent) +20 VP
- The side that went first won 15 of 31 games with a winner
- Points traded per game (both sides' losses): 1455
- Games not ended: 0; findings 0, warnings 0

## Opponent rules (fired a game, figure / won / lost VP a game)

| Rule | A Mine | A Opponent | B Mine | B Opponent |
| --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.6 (+0 / 0 / 0) | 0.7 (+0 / 0 / 3) | 0.6 (+0 / 0 / 0) | 0.7 (+0 / 0 / 0) |
| ALREADY CARRIED | 0.0 (+0 / 0 / 4) | - | 0.0 (+0 / 0 / 4) | - |
| ARRIVAL HUNT | - | 0.0 (+0 / 0 / 0) | - | 0.0 (+0 / 0 / 0) |
| ARTILLERY RE-ROLL WEIGHED | 1.5 (+0 / 0 / 14) | 0.1 (+0 / 0 / 0) | 1.5 (+0 / 0 / 28) | 0.4 (+0 / 0 / 3) |
| BACKUP TARGETS | 1.1 (+10 / 0 / 28) | 0.7 (+8 / 0 / 35) | 0.9 (+9 / 0 / 44) | 1.1 (+10 / 0 / 5) |
| BEST PREY | 3.9 (+276 / 154 / 172) | 4.8 (+340 / 194 / 134) | 4.3 (+282 / 108 / 164) | 5.6 (+394 / 225 / 151) |
| BEST PRIZE | 0.1 (-2 / 0 / 2) | 0.1 (-1 / 0 / 0) | 0.1 (+0 / 0 / 14) | 0.1 (+1 / 6 / 0) |
| BLOCKED CHARGE HANDED OVER | 0.0 (+4 / 4 / 0) | - | - | - |
| BLOCKED CHARGE SKIPPED | 0.2 (+0 / 7 / 0) | 0.0 (+0 / 2 / 0) | 0.1 (+0 / 0 / 0) | 0.0 (+0 / 0 / 1) |
| BLOCKED WHEEL | 0.6 (+5 / 0 / 6) | 0.2 (+19 / 0 / 17) | 0.5 (+4 / 0 / 19) | 0.6 (+1 / 0 / 13) |
| BOMBING RUN | 0.1 (+4 / 6 / 8) | - | 0.1 (+3 / 5 / 0) | - |
| BOUND ASSAILMENT | 0.0 (+0 / 0 / 0) | - | 0.1 (+0 / 0 / 0) | - |
| CANNON PLAN MISSED | 0.7 (+0 / 70 / 12) | 0.0 (+0 / 3 / 0) | 0.6 (+0 / 83 / 0) | 0.1 (+0 / 21 / 0) |
| CANNON PLANNED TARGET | 5.2 (+206 / 448 / 95) | 1.2 (+44 / 99 / 0) | 5.6 (+189 / 369 / 71) | 1.2 (+77 / 146 / 5) |
| CANNON SIGHT KEPT | 1.0 (+0 / 0 / 0) | 0.3 (+0 / 0 / 0) | 1.0 (+0 / 0 / 0) | 0.3 (+0 / 0 / 0) |
| CAST JOB | 0.6 (+37 / 83 / 0) | 0.5 (+12 / 27 / 33) | 0.7 (+32 / 38 / 5) | 0.2 (+4 / 2 / 23) |
| CASTER AWAY FROM SCREEN | 0.3 (+0 / 0 / 0) | 0.2 (+0 / 0 / 0) | 0.3 (+0 / 0 / 0) | 0.2 (+0 / 0 / 0) |
| CASTING BLOCK | 0.7 (+104 / 89 / 0) | 0.1 (+5 / 2 / 0) | 0.6 (+56 / 28 / 0) | 0.2 (+18 / 22 / 0) |
| CASTS AFTER FRIENDS | 0.7 (+0 / 0 / 33) | 0.2 (+0 / 0 / 13) | 0.5 (+0 / 0 / 10) | 0.3 (+0 / 0 / 8) |
| CASTS FROM BEHIND | 0.1 (+0 / 0 / 0) | 0.3 (+0 / 0 / 0) | 0.1 (+0 / 0 / 0) | 0.3 (+0 / 0 / 0) |
| CATCH FLIERS | 0.1 (+1 / 0 / 0) | 0.0 (+0 / 0 / 0) | 0.1 (+1 / 0 / 0) | 0.0 (+0 / 0 / 0) |
| CATCH ODDS | 0.0 (+2 / 0 / 0) | 0.0 (+0 / 0 / 0) | - | - |
| CHAFF PASSED | 0.2 (-1 / 6 / 17) | 0.3 (-1 / 0 / 2) | 0.1 (-0 / 5 / 2) | 0.1 (-0 / 0 / 10) |
| CHARGE NOW WEIGHED | 0.5 (-36 / 16 / 9) | 0.5 (-77 / 7 / 22) | 0.3 (-24 / 18 / 9) | 0.4 (-49 / 20 / 6) |
| CHARIOT NO STATIC JOB | 0.7 (+0 / 10 / 20) | 0.6 (+0 / 2 / 8) | 0.9 (+0 / 0 / 17) | 0.7 (+0 / 3 / 7) |
| CHEAP HELPER | 0.1 (+0 / 0 / 0) | 0.1 (+0 / 18 / 0) | 0.1 (+0 / 3 / 3) | 0.2 (+0 / 8 / 9) |
| CONTINUE AHEAD WEIGHED | 0.0 (+0 / 4 / 0) | 0.0 (+0 / 0 / 0) | 0.1 (+0 / 9 / 0) | - |
| CONVEYANCE SEARCH | 0.6 (+36 / 29 / 33) | 0.2 (+28 / 10 / 29) | 0.5 (+33 / 15 / 21) | 0.3 (+48 / 22 / 29) |
| COUNTER-CHARGE COVER | 8.9 (+713 / 0 / 196) | 7.6 (+665 / 0 / 210) | - | - |
| EDGE GIVE GROUND | 0.1 (+1 / 8 / 4) | 0.2 (+4 / 46 / 0) | 0.1 (+2 / 12 / 6) | 0.1 (+6 / 20 / 0) |
| ELIXIR WORTH | 0.1 (+0 / 0 / 8) | 0.1 (+0 / 0 / 0) | 0.0 (+0 / 0 / 0) | 0.1 (+0 / 0 / 0) |
| ENGINEER BY LORE | 0.1 (+0 / 0 / 0) | - | 0.1 (+0 / 0 / 0) | - |
| ESCORT | 0.5 (+19 / 0 / 10) | 0.3 (+18 / 0 / 2) | - | - |
| FACES THE THREAT | 1.2 (+99 / 0 / 52) | 0.7 (+50 / 0 / 28) | 1.4 (+120 / 0 / 43) | 1.0 (+115 / 0 / 31) |
| FIGHT LIFT | 0.0 (+1 / 17 / 0) | - | 0.1 (+3 / 0 / 0) | - |
| FIRE AND FLEE | 0.1 (+1 / 13 / 5) | 0.1 (+1 / 7 / 3) | - | 0.1 (+1 / 0 / 3) |
| FOCUS FIRE | - | 0.0 (+0 / 0 / 0) | 0.0 (+2 / 3 / 0) | 0.1 (+1 / 2 / 0) |
| FOLLOW UP WEIGHED | 1.0 (+139 / 0 / 38) | 1.1 (+139 / 0 / 26) | 1.1 (+123 / 0 / 24) | 1.1 (+180 / 0 / 14) |
| FRIENDS SHOTS CHECKED | 0.2 (+16 / 0 / 29) | 0.2 (+19 / 0 / 11) | 0.4 (+16 / 0 / 23) | 0.3 (+28 / 0 / 0) |
| GIVES UP | 1.0 (-21 / 103 / 34) | 1.4 (-52 / 153 / 62) | 1.0 (-22 / 138 / 11) | 1.5 (-45 / 183 / 39) |
| GIVES UP ITS SCREEN | 0.5 (-14 / 42 / 10) | 0.9 (-15 / 71 / 9) | 0.4 (-5 / 23 / 18) | 1.2 (-17 / 74 / 13) |
| GROUND FLIERS | 0.0 (+0 / 0 / 0) | 0.0 (+0 / 0 / 0) | 0.0 (+0 / 0 / 0) | 0.0 (+0 / 0 / 0) |
| GROUP AIM | 0.3 (+4 / 0 / 13) | 0.4 (+12 / 0 / 4) | - | - |
| GROUP BROKEN | - | 0.0 (+0 / 0 / 0) | - | - |
| HELPER ALREADY ASKED | 0.1 (+0 / 0 / 0) | 0.1 (+0 / 5 / 0) | - | 0.1 (+0 / 7 / 1) |
| HELPER UNSEEN | 0.2 (+0 / 7 / 0) | 0.4 (+0 / 60 / 7) | 0.2 (+0 / 15 / 0) | 0.4 (+0 / 24 / 1) |
| HOLDS AMBUSHERS | 0.4 (+0 / 0 / 0) | 0.8 (+0 / 0 / 0) | 0.4 (+0 / 0 / 0) | 0.8 (+0 / 0 / 0) |
| HORN WORTH | - | 0.0 (+1 / 0 / 0) | - | - |
| HUNT ADVANCE | 0.1 (+0 / 25 / 0) | 0.1 (+2 / 3 / 3) | - | 0.2 (+15 / 0 / 8) |
| HUNT DROPPED | - | - | - | 0.1 (+0 / 0 / 4) |
| HUNT IN PAIRS | 0.4 (+31 / 0 / 6) | 0.4 (+31 / 0 / 2) | - | - |
| HUNT KEPT | 0.0 (+0 / 6 / 0) | 0.0 (+0 / 3 / 0) | - | 0.1 (+3 / 0 / 8) |
| HUNT RESULT | 0.1 (+27 / 0 / 0) | 0.1 (+11 / 3 / 4) | - | 0.2 (+0 / 4 / 13) |
| HUNT THE GUNS | 0.1 (+30 / 24 / 0) | 0.1 (+28 / 3 / 3) | - | 0.2 (+80 / 0 / 4) |
| JOINT CHARGE PLAN | 0.1 (+7 / 0 / 0) | 0.1 (+2 / 0 / 4) | 0.1 (+4 / 3 / 4) | 0.1 (+1 / 0 / 0) |
| KEEPS ITS PREY | 0.2 (+2 / 2 / 15) | 0.2 (+1 / 7 / 12) | 0.3 (+2 / 0 / 15) | 0.2 (+1 / 3 / 5) |
| KEEPS ITS TARGET | 1.5 (+44 / 144 / 17) | 2.6 (+78 / 199 / 121) | 1.6 (+48 / 145 / 26) | 2.4 (+73 / 169 / 42) |
| KEEPS SCOUTS OR AMBUSH | 0.1 (+0 / 0 / 0) | - | 0.1 (+0 / 0 / 0) | - |
| KILLS COUNT | 1.6 (+84 / 148 / 40) | 2.4 (+88 / 182 / 49) | 1.6 (+61 / 98 / 26) | 2.2 (+86 / 232 / 32) |
| KILLS COUNT NEXT TURN | 8.0 (+339 / 387 / 231) | 9.8 (+440 / 307 / 281) | 8.5 (+307 / 360 / 229) | 11.1 (+475 / 460 / 208) |
| LONE CHARACTER SAFE SPOT | 0.3 (+0 / 9 / 19) | 0.5 (+16 / 12 / 36) | 0.2 (+6 / 3 / 33) | 0.4 (+13 / 14 / 15) |
| LONE WIZARD HOLDS BACK | 0.9 (+0 / 43 / 22) | 1.1 (+0 / 40 / 76) | 0.8 (+0 / 22 / 36) | 1.0 (+0 / 34 / 53) |
| LONE WIZARD KEPT IN | 0.7 (+49 / 0 / 0) | 0.2 (+24 / 0 / 0) | 0.7 (+49 / 0 / 0) | 0.2 (+24 / 0 / 0) |
| MAKE SURE TOGETHER | 0.9 (+38 / 18 / 15) | 0.7 (+32 / 9 / 11) | 0.6 (+36 / 19 / 18) | 0.4 (+29 / 6 / 4) |
| MANOEUVRE | 0.2 (+14 / 0 / 2) | 0.1 (+0 / 0 / 2) | 0.1 (+1 / 0 / 13) | 0.1 (+5 / 0 / 0) |
| MARCH AT ESCAPER | 0.0 (+0 / 0 / 0) | 0.3 (+2 / 0 / 8) | 0.1 (+2 / 0 / 0) | 0.2 (+2 / 0 / 2) |
| MARCH ODDS | 1.0 (+92 / 40 / 6) | 0.6 (+41 / 42 / 19) | 1.0 (+117 / 39 / 21) | 0.7 (+68 / 30 / 0) |
| MISSILES IN THE MOVE | 3.4 (+176 / 0 / 32) | 2.7 (+52 / 0 / 89) | 3.4 (+149 / 0 / 59) | 2.8 (+42 / 0 / 100) |
| MISSILES NEXT TURN | 4.6 (+118 / 0 / 75) | 3.9 (+39 / 0 / 145) | 4.7 (+115 / 0 / 115) | 3.9 (+36 / 0 / 115) |
| MODEL FACING | 0.2 (+54 / 0 / 0) | - | 0.3 (+151 / 0 / 7) | - |
| MOVE AND CAST | 0.2 (+8 / 0 / 0) | 0.1 (+6 / 0 / 0) | 0.2 (+10 / 0 / 0) | 0.1 (+1 / 0 / 0) |
| MOVE SPELL IN RANGE | 0.1 (+4 / 0 / 16) | 0.1 (+1 / 0 / 8) | 0.1 (+4 / 0 / 16) | - |
| MOVE SPELL NOT WORTH | - | - | 0.0 (-0 / 0 / 0) | - |
| MOVE SPELL OUT OF RANGE | 0.2 (-42 / 0 / 28) | 0.0 (-0 / 0 / 8) | 0.3 (-55 / 0 / 38) | 0.2 (-19 / 33 / 0) |
| MOVE SPELL SPOT | 0.2 (+0 / 0 / 22) | 0.1 (+0 / 0 / 0) | 0.2 (+0 / 0 / 0) | 0.2 (+0 / 0 / 0) |
| MOVES UNITS SPELL | 0.1 (+3 / 0 / 0) | 0.1 (+2 / 0 / 0) | 0.1 (+3 / 0 / 0) | 0.1 (+2 / 0 / 0) |
| NEEDED THERE | - | 0.1 (+12 / 0 / 0) | 0.1 (+2 / 3 / 0) | - |
| NO RALLY LEFT | 0.0 (+1 / 0 / 0) | 0.1 (+6 / 0 / 0) | 0.0 (+1 / 0 / 0) | - |
| NOT NEEDED | 0.2 (-9 / 29 / 2) | 0.6 (-25 / 66 / 1) | 0.2 (-15 / 30 / 6) | 0.5 (-24 / 52 / 7) |
| NOT TURNED | 10.6 (+214 / 0 / 243) | 9.7 (+186 / 0 / 256) | 10.1 (+143 / 0 / 289) | 10.2 (+105 / 0 / 209) |
| NOT WORTH A CAST | 0.9 (-1 / 0 / 12) | 0.2 (-0 / 0 / 15) | 0.9 (-1 / 0 / 22) | 0.3 (-0 / 0 / 15) |
| OPENS A LANE | 0.1 (+0 / 6 / 0) | 0.1 (+0 / 5 / 0) | 0.1 (+0 / 7 / 0) | 0.0 (+0 / 0 / 0) |
| OPENS UP | 0.2 (+15 / 14 / 0) | 0.1 (+7 / 2 / 8) | 0.3 (+26 / 23 / 0) | 0.2 (+14 / 10 / 8) |
| OVERRUNS AWAY | 0.8 (+21 / 98 / 21) | 0.6 (+18 / 56 / 46) | 0.3 (+10 / 23 / 13) | 0.6 (+16 / 39 / 10) |
| PATHS CROSS | 2.3 (+139 / 0 / 24) | 2.7 (+191 / 0 / 99) | 2.4 (+125 / 0 / 63) | 2.9 (+147 / 0 / 56) |
| PERIAPT WORTH | - | 0.0 (+3 / 0 / 0) | 0.0 (+3 / 0 / 15) | 0.0 (+3 / 0 / 0) |
| PLAN LEADS | 0.9 (+74 / 37 / 16) | 1.0 (+81 / 23 / 7) | 1.1 (+96 / 32 / 26) | 1.0 (+83 / 25 / 17) |
| PLAN RESULT | 36.7 (+1456 / 1495 / 954) | 37.6 (+1230 / 1193 / 1151) | 37.7 (+1447 / 1272 / 955) | 39.4 (+1354 / 1523 / 969) |
| PURSUES BIG PREY | 0.1 (-4 / 0 / 0) | 0.1 (-10 / 0 / 0) | 0.1 (-4 / 0 / 0) | 0.1 (-3 / 0 / 0) |
| PURSUES ON | 0.0 (+4 / 0 / 0) | - | - | - |
| RAIDS THE BAGGAGE | - | 0.0 (+7 / 0 / 0) | - | 0.0 (+7 / 0 / 0) |
| RAIDS THE BAGGAGE NEXT TURN | 0.1 (+7 / 0 / 2) | 0.1 (+8 / 0 / 0) | 0.1 (+5 / 0 / 0) | 0.1 (+9 / 0 / 0) |
| REDIRECT COUNTER | 3.6 (+200 / 0 / 62) | 5.0 (+307 / 0 / 67) | - | - |
| REDIRECT WEIGHED | 0.2 (+8 / 8 / 10) | 0.4 (+5 / 5 / 12) | 0.3 (+9 / 5 / 17) | 0.6 (+19 / 19 / 5) |
| RESTRAINS TO SHOOT | 0.1 (+11 / 0 / 13) | 0.1 (+4 / 0 / 0) | 0.0 (+0 / 0 / 7) | 0.1 (+3 / 0 / 0) |
| RISK BY ARC | 2.5 (+83 / 204 / 83) | 3.2 (+56 / 273 / 113) | 2.0 (+95 / 184 / 54) | 3.2 (+121 / 279 / 78) |
| SAFER THAN THE JOB | 0.7 (+59 / 0 / 44) | 0.5 (+39 / 0 / 0) | 0.8 (+38 / 0 / 23) | 0.9 (+56 / 0 / 19) |
| SCOUT SPOT | 0.4 (+1 / 0 / 1) | 0.3 (+1 / 0 / 0) | 0.4 (+1 / 0 / 1) | 0.3 (+1 / 0 / 0) |
| SCOUT WAITS | 0.4 (+0 / 0 / 1) | 0.3 (+0 / 0 / 0) | 0.4 (+0 / 0 / 1) | 0.3 (+0 / 0 / 0) |
| SEARCH SPOT | 1.1 (+79 / 0 / 22) | 1.1 (+81 / 0 / 14) | 0.8 (+49 / 0 / 16) | 0.7 (+45 / 0 / 20) |
| SECOND HUNTER | 0.0 (-0 / 6 / 0) | - | - | - |
| SELF MOVE SPELL | 0.2 (+28 / 0 / 29) | 0.3 (+2 / 0 / 0) | 0.3 (+16 / 0 / 0) | 0.3 (+3 / 0 / 0) |
| SET UP TOGETHER | 1.7 (+72 / 44 / 28) | 1.7 (+75 / 22 / 50) | 1.0 (+55 / 25 / 29) | 1.1 (+72 / 24 / 26) |
| SHOOTERS IN TWO RANKS | 0.4 (+1 / 0 / 0) | 0.2 (+1 / 0 / 0) | 0.4 (+1 / 0 / 0) | 0.2 (+1 / 0 / 0) |
| SHORT GUN FORWARD | 0.2 (+0 / 0 / 3) | 0.0 (+0 / 0 / 4) | 0.2 (+0 / 0 / 3) | 0.0 (+0 / 0 / 4) |
| SHOT REPLANNED | 0.6 (+0 / 119 / 24) | 0.2 (+0 / 33 / 12) | 0.4 (+0 / 66 / 9) | 0.2 (+0 / 40 / 0) |
| SHOTS IN THE MOVE | 13.7 (+594 / 0 / 242) | 7.6 (+185 / 0 / 156) | 14.0 (+594 / 0 / 211) | 8.8 (+211 / 0 / 130) |
| SPELL CATCH ODDS | 0.1 (-1 / 6 / 0) | - | 0.1 (-0 / 6 / 0) | - |
| SPELL SETS UP CHARGE | 0.0 (+3 / 0 / 0) | - | 0.0 (+19 / 9 / 0) | 0.1 (+24 / 14 / 14) |
| SPELL WORTH | 1.0 (+23 / 107 / 84) | 1.6 (+39 / 57 / 64) | 0.9 (+20 / 109 / 114) | 1.7 (+34 / 74 / 70) |
| STANDS TO CAST | 0.1 (+3 / 2 / 0) | 0.0 (+0 / 0 / 2) | - | 0.0 (+1 / 0 / 0) |
| STOPS | 0.0 (+2 / 5 / 0) | 0.0 (+2 / 0 / 0) | - | 0.0 (+2 / 0 / 1) |
| STUCK PIVOT | 0.1 (+0 / 0 / 0) | 0.2 (+0 / 0 / 19) | 0.1 (+0 / 0 / 4) | 0.3 (+0 / 0 / 13) |
| SUPPORT JOB KEPT | - | 0.0 (+0 / 4 / 4) | - | 0.0 (+0 / 0 / 0) |
| SURE CHARGE BEATS ADVANCE | 0.2 (-8 / 13 / 1) | 0.3 (-13 / 18 / 9) | 0.1 (-6 / 0 / 0) | 0.2 (-7 / 11 / 0) |
| THROUGH LINE OF FIRE | 0.6 (+35 / 0 / 14) | 0.2 (+18 / 0 / 28) | 0.6 (+22 / 0 / 18) | 0.3 (+2 / 0 / 8) |
| TURN WORTH | 0.6 (-39 / 44 / 22) | 0.3 (-13 / 21 / 4) | 0.5 (-43 / 48 / 15) | 0.5 (-27 / 41 / 11) |
| TWO OR MORE ARRIVE | 0.5 (+4 / 12 / 7) | 0.5 (+4 / 0 / 6) | 0.6 (+12 / 25 / 26) | 0.4 (+1 / 0 / 2) |
| WEARS DOWN | 0.9 (+54 / 89 / 45) | 1.1 (+31 / 121 / 46) | 0.9 (+41 / 126 / 23) | 1.3 (+44 / 105 / 35) |
| WHO HITS BACK | 0.3 (+27 / 0 / 20) | 0.2 (+23 / 0 / 19) | 0.2 (+11 / 0 / 0) | 0.2 (+33 / 0 / 26) |
| WHOLE FIGHT | 0.2 (+8 / 13 / 3) | 0.4 (+5 / 75 / 6) | 0.3 (+19 / 39 / 0) | 0.3 (+23 / 20 / 9) |
| WHOLE FIGHT GAIN | 0.6 (+60 / 46 / 14) | 0.7 (+71 / 73 / 20) | 0.2 (+22 / 10 / 10) | 0.7 (+71 / 84 / 17) |

A = groups on, B = groups off.

## Rule changes (changed a game, VP a change)

| Rule | A | B |
| --- | --- | --- |
| ADVANCE LANE KEPT | 1.31 (+0.0) | 1.31 (+0.0) |
| ALREADY CARRIED | - | - |
| ARRIVAL HUNT | 0.00 (-) | 0.00 (-) |
| ARTILLERY RE-ROLL WEIGHED | 1.64 (+0.0) | 1.89 (+0.0) |
| BACKUP TARGETS | 0.08 (+5.6) | 0.17 (+8.7) |
| BEST PREY | 4.06 (+50.3) | 4.61 (+40.3) |
| BEST PRIZE | 0.14 (-44.5) | 0.19 (-40.1) |
| BLOCKED CHARGE HANDED OVER | 0.03 (+143.9) | - |
| BLOCKED CHARGE SKIPPED | 0.19 (+0.0) | 0.08 (+0.0) |
| BLOCKED WHEEL | - | - |
| BOMBING RUN | 0.06 (+68.5) | 0.08 (+40.5) |
| BOUND ASSAILMENT | 0.03 (+0.1) | 0.06 (+0.2) |
| CANNON PLAN MISSED | 0.00 (-) | 0.00 (-) |
| CANNON PLANNED TARGET | 1.69 (-13.3) | 1.94 (-5.1) |
| CANNON SIGHT KEPT | 1.31 (+0.0) | 1.31 (+0.0) |
| CAST JOB | 0.72 (+26.4) | 0.53 (+29.2) |
| CASTER AWAY FROM SCREEN | 0.53 (+0.0) | 0.53 (+0.0) |
| CASTING BLOCK | 0.69 (+89.5) | 0.64 (+60.7) |
| CASTS AFTER FRIENDS | - | - |
| CASTS FROM BEHIND | 0.39 (+0.0) | 0.39 (+0.0) |
| CATCH FLIERS | - | - |
| CATCH ODDS | - | - |
| CHAFF PASSED | 0.47 (-4.0) | 0.28 (-2.1) |
| CHARGE NOW WEIGHED | 1.00 (+74.1) | 0.72 (+74.1) |
| CHARIOT NO STATIC JOB | 0.67 (-74.1) | 1.00 (-76.3) |
| CHEAP HELPER | - | - |
| CONTINUE AHEAD WEIGHED | 0.06 (+0.0) | 0.06 (+0.0) |
| CONVEYANCE SEARCH | - | - |
| COUNTER-CHARGE COVER | 2.17 (+71.0) | - |
| EDGE GIVE GROUND | 0.03 (+16.0) | 0.03 (+3.9) |
| ELIXIR WORTH | 0.11 (+5.4) | 0.08 (+4.8) |
| ENGINEER BY LORE | 0.00 (-) | 0.00 (-) |
| ESCORT | 0.03 (+10.3) | - |
| FACES THE THREAT | - | - |
| FIGHT LIFT | - | - |
| FIRE AND FLEE | 0.19 (+11.4) | 0.11 (+9.4) |
| FOCUS FIRE | 0.03 (+1.9) | 0.08 (+37.0) |
| FOLLOW UP WEIGHED | 2.08 (+133.5) | 2.17 (+139.7) |
| FRIENDS SHOTS CHECKED | 0.47 (+73.9) | 0.72 (+60.2) |
| GIVES UP | 0.06 (+4.1) | 0.00 (-) |
| GIVES UP ITS SCREEN | 0.00 (-) | 0.00 (-) |
| GROUND FLIERS | - | - |
| GROUP AIM | 0.06 (+30.1) | - |
| GROUP BROKEN | - | - |
| HELPER ALREADY ASKED | - | - |
| HELPER UNSEEN | 0.00 (-) | 0.00 (-) |
| HOLDS AMBUSHERS | 1.22 (+0.0) | 1.22 (+0.0) |
| HORN WORTH | 0.03 (+22.4) | - |
| HUNT ADVANCE | 0.00 (-) | 0.19 (+39.4) |
| HUNT DROPPED | - | - |
| HUNT IN PAIRS | 0.06 (+94.7) | - |
| HUNT KEPT | - | - |
| HUNT RESULT | - | - |
| HUNT THE GUNS | - | - |
| JOINT CHARGE PLAN | 0.08 (+71.3) | 0.11 (+26.1) |
| KEEPS ITS PREY | 0.08 (+9.3) | 0.00 (-) |
| KEEPS ITS TARGET | 1.19 (+16.7) | 1.19 (+15.8) |
| KEEPS SCOUTS OR AMBUSH | 0.06 (+0.0) | 0.06 (+0.0) |
| KILLS COUNT | 1.17 (+50.9) | 0.81 (+28.3) |
| KILLS COUNT NEXT TURN | 5.39 (+48.1) | 5.53 (+38.0) |
| LONE CHARACTER SAFE SPOT | - | - |
| LONE WIZARD HOLDS BACK | 0.61 (-58.4) | 0.83 (-102.8) |
| LONE WIZARD KEPT IN | 0.94 (+77.9) | 0.94 (+77.9) |
| MAKE SURE TOGETHER | 0.58 (+33.0) | 0.56 (+35.1) |
| MANOEUVRE | - | - |
| MARCH AT ESCAPER | - | - |
| MARCH ODDS | 1.28 (+31.9) | 1.25 (+29.0) |
| MISSILES IN THE MOVE | - | - |
| MISSILES NEXT TURN | 0.11 (+18.6) | 0.19 (+15.4) |
| MODEL FACING | 0.22 (+241.2) | 0.31 (+494.0) |
| MOVE AND CAST | - | - |
| MOVE SPELL IN RANGE | 0.00 (-) | 0.00 (-) |
| MOVE SPELL NOT WORTH | - | - |
| MOVE SPELL OUT OF RANGE | - | - |
| MOVE SPELL SPOT | - | - |
| MOVES UNITS SPELL | 0.19 (+26.5) | 0.19 (+26.5) |
| NEEDED THERE | 0.08 (+0.0) | 0.06 (+0.0) |
| NO RALLY LEFT | 0.08 (+64.2) | 0.03 (+5.1) |
| NOT NEEDED | 0.00 (-) | 0.00 (-) |
| NOT TURNED | 0.00 (-) | 0.00 (-) |
| NOT WORTH A CAST | - | - |
| OPENS A LANE | 0.00 (-) | 0.00 (-) |
| OPENS UP | 0.22 (+32.9) | 0.28 (+37.6) |
| OVERRUNS AWAY | 0.22 (+34.8) | 0.22 (+47.3) |
| PATHS CROSS | - | - |
| PERIAPT WORTH | 0.03 (+99.0) | 0.06 (+122.7) |
| PLAN LEADS | 0.67 (+59.1) | 0.92 (+64.5) |
| PLAN RESULT | - | - |
| PURSUES BIG PREY | 0.19 (-71.5) | 0.19 (-36.3) |
| PURSUES ON | 0.03 (+130.0) | - |
| RAIDS THE BAGGAGE | 0.03 (+211.6) | 0.03 (+210.3) |
| RAIDS THE BAGGAGE NEXT TURN | 0.14 (+83.7) | 0.14 (+70.6) |
| REDIRECT COUNTER | 0.58 (+42.5) | - |
| REDIRECT WEIGHED | 0.61 (+30.1) | 0.97 (+65.7) |
| RESTRAINS TO SHOOT | 0.25 (+59.6) | 0.14 (+27.1) |
| RISK BY ARC | 1.19 (+33.4) | 1.72 (+34.9) |
| SAFER THAN THE JOB | - | - |
| SCOUT SPOT | 0.00 (-) | 0.00 (-) |
| SCOUT WAITS | 0.72 (+0.0) | 0.72 (+0.0) |
| SEARCH SPOT | - | - |
| SECOND HUNTER | 0.00 (-) | - |
| SELF MOVE SPELL | - | - |
| SET UP TOGETHER | 1.31 (+39.9) | 1.08 (+42.0) |
| SHOOTERS IN TWO RANKS | 0.64 (+2.3) | 0.64 (+2.3) |
| SHORT GUN FORWARD | 0.22 (+0.0) | 0.22 (+0.0) |
| SHOT REPLANNED | 0.83 (+0.0) | 0.56 (+0.0) |
| SHOTS IN THE MOVE | - | - |
| SPELL CATCH ODDS | - | - |
| SPELL SETS UP CHARGE | - | - |
| SPELL WORTH | - | - |
| STANDS TO CAST | 0.11 (+5.8) | - |
| STOPS | 0.03 (+9.9) | 0.03 (+30.4) |
| STUCK PIVOT | 0.33 (+0.0) | 0.36 (+0.0) |
| SUPPORT JOB KEPT | 0.03 (-38.4) | 0.03 (+69.3) |
| SURE CHARGE BEATS ADVANCE | 0.47 (-44.3) | 0.25 (-51.5) |
| THROUGH LINE OF FIRE | - | - |
| TURN WORTH | 0.03 (+21.7) | 0.00 (-) |
| TWO OR MORE ARRIVE | 0.08 (+22.9) | 0.06 (+21.4) |
| WEARS DOWN | 0.44 (+27.1) | 0.47 (+37.1) |
| WHO HITS BACK | 0.53 (-57.0) | 0.39 (-44.0) |
| WHOLE FIGHT | 0.11 (+18.6) | 0.08 (+260.9) |
| WHOLE FIGHT GAIN | 0.72 (+45.0) | 0.50 (+53.8) |

A = groups on, B = groups off.

## Plans (happened, won of planned)

| Side | Plan | A | B |
| --- | --- | --- | --- |
| Mine | advance | 20% (63%) | 16% (59%) |
| Mine | charge | 52% (74%) | 61% (74%) |
| Mine | close in | 23% (55%) | 24% (54%) |
| Mine | hold | 41% (0%) | 44% (0%) |
| Mine | join | 100% (0%) | 94% (0%) |
| Mine | shoot | 67% (190%) | 61% (179%) |
| Mine | support | 89% (0%) | 91% (0%) |
| Opponent | advance | 20% (71%) | 22% (64%) |
| Opponent | charge | 60% (99%) | 61% (87%) |
| Opponent | close in | 27% (39%) | 26% (36%) |
| Opponent | hold | 39% (0%) | 42% (0%) |
| Opponent | join | 94% (0%) | 91% (0%) |
| Opponent | shoot | 65% (246%) | 65% (315%) |
| Opponent | support | 90% (0%) | 91% (0%) |

A = groups on, B = groups off.

## Packages: hunt the guns (per side)

| Batch | Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| A | Mine | 0.1 | 4 | 0 | 25% | 100% | 0% | 2.2 | 268 | 242 | 100% | 40 |
| A | Opponent | 0.1 | 3 | 0 | 33% | 67% | 0% | 2.5 | 336 | 138 | 0% | 123 |
| B | Mine | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 40 |
| B | Opponent | 0.2 | 7 | 0 | 0% | 0% | 0% | - | 411 | 0 | 0% | 97 |

A = groups on, B = groups off.

### Battle groups: groups on

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 8.9 | 26% | 39% | 6% | 40% | 40% | 1% | 6% | 52% | 0% |
| Mine | REDIRECT COUNTER | 3.6 | 28% | 65% | 14% | 40% | 9% | 0% | 3% | 78% | 9% |
| Opponent | COUNTER-CHARGE COVER | 7.6 | 18% | 52% | 6% | 33% | 45% | 9% | 13% | 34% | 0% |
| Opponent | REDIRECT COUNTER | 5.0 | 17% | 73% | 23% | 14% | 4% | 0% | 13% | 74% | 9% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.3 | 6 | 0% | - |
| Opponent | 0.4 | 12 | 0% | - |

### Deployment: positions vs output by unit type: groups on

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 2 | 0 (2) | 0 | 0 | 46 | 50% | 6.0 | 0 (1) | 0 (1) | - | - | 0 (2) |
| Mine | Chaff | 43 | 59 (43) | 41 | 18 | 49 | 42% | 2.3 | 107 (15) | 0 (7) | 37 (21) | 74 (29) | 30 (14) |
| Mine | Character | 121 | 58 (121) | 58 | 0 | 39 | 15% | 2.4 | 84 (31) | 54 (62) | 30 (11) | 56 (64) | 69 (40) |
| Mine | Clean-up | 20 | 80 (20) | 45 | 35 | 24 | 30% | 2.8 | 70 (10) | 101 (8) | 19 (2) | 116 (11) | 34 (9) |
| Mine | Fast | 1 | 81 (1) | 81 | 0 | 0 | 0% | 3.0 | - | 81 (1) | - | - | 81 (1) |
| Mine | Fast Hammer | 40 | 29 (40) | 17 | 12 | 64 | 28% | 2.6 | 42 (21) | 15 (6) | 13 (13) | 38 (30) | 9 (10) |
| Mine | Fragile | 3 | 0 (3) | 0 | 0 | 67 | 33% | 3.0 | - | 0 (3) | - | 0 (1) | 0 (2) |
| Mine | Hammer | 52 | 26 (52) | 17 | 9 | 38 | 17% | 2.4 | 45 (8) | 25 (34) | 17 (10) | 33 (35) | 13 (17) |
| Mine | Holder | 23 | 101 (23) | 21 | 81 | 14 | 26% | 3.9 | 86 (7) | 86 (11) | 172 (5) | 120 (14) | 76 (9) |
| Mine | Shooter | 45 | 83 (45) | 32 | 51 | 52 | 0% | 1.8 | 18 (7) | 111 (31) | 43 (7) | 113 (26) | 40 (19) |
| Mine | Support | 5 | 0 (5) | 0 | 0 | 42 | 100% | - | - | 0 (2) | - | 0 (1) | 0 (1) |
| Mine | War machine | 56 | 65 (56) | 65 | 0 | 40 | 2% | 1.4 | 90 (13) | 54 (38) | 86 (5) | 48 (10) | 70 (46) |
| Mine | Wizard | 22 | 7 (22) | 7 | 0 | 58 | 18% | 2.3 | 0 (7) | 3 (7) | 49 (3) | 0 (3) | 13 (14) |
| Opponent | Blocker | 1 | 94 (1) | 94 | 0 | 0 | 0% | 3.0 | 94 (1) | - | - | 94 (1) | - |
| Opponent | Chaff | 77 | 45 (77) | 11 | 34 | 55 | 38% | 2.8 | 47 (27) | 58 (21) | 33 (29) | 55 (54) | 18 (23) |
| Opponent | Character | 109 | 52 (109) | 52 | 0 | 44 | 16% | 2.6 | 73 (38) | 48 (52) | 33 (6) | 54 (65) | 65 (31) |
| Opponent | Clean-up | 11 | 11 (11) | 4 | 7 | 44 | 18% | 3.1 | 0 (4) | 18 (7) | - | 13 (8) | 6 (3) |
| Opponent | Early | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Fast Hammer | 51 | 59 (51) | 36 | 22 | 51 | 22% | 3.0 | 30 (22) | 64 (14) | 103 (15) | 64 (37) | 45 (14) |
| Opponent | Fragile | 9 | 0 (9) | 0 | 0 | 82 | 33% | 2.3 | - | 0 (2) | 0 (4) | 0 (5) | 0 (1) |
| Opponent | Hammer | 63 | 34 (63) | 22 | 12 | 47 | 25% | 2.6 | 6 (20) | 49 (38) | 0 (5) | 22 (37) | 52 (26) |
| Opponent | Holder | 35 | 57 (35) | 10 | 47 | 29 | 49% | 3.6 | 44 (8) | 87 (16) | 21 (9) | 81 (14) | 40 (19) |
| Opponent | Shooter | 31 | 76 (31) | 30 | 46 | 51 | 0% | 1.4 | 83 (7) | 75 (19) | 71 (5) | 78 (17) | 74 (14) |
| Opponent | Support | 1 | 0 (1) | 0 | 0 | 100 | 0% | 6.0 | 0 (1) | - | - | - | 0 (1) |
| Opponent | War machine | 13 | 95 (13) | 95 | 0 | 38 | 23% | 1.4 | 0 (3) | 145 (7) | 41 (3) | 0 (2) | 111 (11) |
| Opponent | Wizard | 22 | 30 (22) | 30 | 0 | 41 | 9% | 2.1 | 61 (6) | 21 (9) | 0 (6) | 36 (12) | 20 (9) |

### Deployment: positions vs output by unit type: groups off

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 3 | 0 (3) | 0 | 0 | 100 | 67% | 5.0 | 0 (1) | 0 (1) | - | - | 0 (2) |
| Mine | Chaff | 45 | 39 (45) | 4 | 34 | 56 | 42% | 2.9 | 63 (16) | 7 (8) | 29 (21) | 54 (30) | 9 (15) |
| Mine | Character | 124 | 53 (124) | 53 | 0 | 42 | 18% | 2.4 | 77 (30) | 56 (62) | 5 (8) | 62 (60) | 57 (40) |
| Mine | Clean-up | 20 | 58 (20) | 23 | 35 | 17 | 25% | 3.3 | 35 (10) | 94 (8) | 38 (2) | 69 (11) | 44 (9) |
| Mine | Fast | 1 | 0 (1) | 0 | 0 | 100 | 0% | 2.0 | - | 0 (1) | - | - | 0 (1) |
| Mine | Fast Hammer | 40 | 30 (40) | 22 | 8 | 61 | 25% | 2.5 | 37 (21) | 36 (6) | 15 (13) | 33 (30) | 23 (10) |
| Mine | Fragile | 5 | 14 (5) | 14 | 0 | 40 | 20% | 3.0 | - | 14 (5) | - | 0 (1) | 17 (4) |
| Mine | Hammer | 56 | 30 (56) | 17 | 13 | 44 | 20% | 2.3 | 41 (10) | 31 (36) | 15 (10) | 30 (37) | 30 (19) |
| Mine | Holder | 26 | 64 (26) | 11 | 53 | 23 | 38% | 3.6 | 56 (8) | 78 (10) | 59 (7) | 48 (11) | 82 (14) |
| Mine | Shooter | 45 | 82 (45) | 20 | 63 | 39 | 0% | 1.9 | 67 (7) | 79 (31) | 117 (7) | 88 (27) | 74 (18) |
| Mine | Support | 5 | 0 (5) | 0 | 0 | 42 | 40% | 2.0 | - | 0 (2) | 0 (3) | 0 (1) | 0 (4) |
| Mine | War machine | 56 | 53 (56) | 53 | 0 | 30 | 2% | 1.4 | 73 (13) | 43 (38) | 79 (5) | 14 (10) | 62 (46) |
| Mine | Wizard | 22 | 17 (22) | 17 | 0 | 36 | 9% | 2.5 | 17 (8) | 43 (6) | 0 (3) | 28 (4) | 20 (13) |
| Opponent | Blocker | 1 | 58 (1) | 58 | 0 | 0 | 100% | - | 58 (1) | - | - | 58 (1) | - |
| Opponent | Chaff | 81 | 46 (81) | 7 | 39 | 47 | 31% | 2.8 | 53 (29) | 50 (21) | 37 (31) | 55 (56) | 26 (25) |
| Opponent | Character | 113 | 50 (113) | 50 | 0 | 35 | 19% | 2.2 | 66 (42) | 41 (54) | 66 (8) | 57 (71) | 46 (33) |
| Opponent | Clean-up | 12 | 39 (12) | 28 | 10 | 48 | 8% | 3.0 | 13 (5) | 59 (7) | - | 32 (9) | 60 (3) |
| Opponent | Early | 1 | 0 (1) | 0 | 0 | 0 | 0% | 6.0 | - | 0 (1) | - | 0 (1) | - |
| Opponent | Fast Hammer | 53 | 60 (53) | 39 | 21 | 38 | 36% | 2.9 | 52 (23) | 53 (15) | 84 (15) | 66 (38) | 46 (15) |
| Opponent | Fragile | 9 | 25 (9) | 25 | 0 | 57 | 33% | 2.7 | - | 45 (5) | 0 (4) | 0 (6) | 86 (3) |
| Opponent | Hammer | 63 | 47 (63) | 34 | 13 | 48 | 30% | 2.7 | 13 (20) | 62 (38) | 30 (5) | 40 (37) | 57 (26) |
| Opponent | Holder | 35 | 62 (35) | 8 | 54 | 17 | 40% | 3.8 | 44 (6) | 75 (22) | 36 (7) | 77 (15) | 50 (20) |
| Opponent | Shooter | 31 | 40 (31) | 9 | 32 | 46 | 6% | 1.6 | 32 (7) | 50 (19) | 14 (5) | 50 (17) | 28 (14) |
| Opponent | Support | 2 | 0 (2) | 0 | 0 | 50 | 50% | 6.0 | 0 (2) | - | - | 0 (1) | 0 (1) |
| Opponent | War machine | 13 | 98 (13) | 98 | 0 | 33 | 23% | 1.2 | 132 (3) | 107 (7) | 41 (3) | 61 (2) | 104 (11) |
| Opponent | Wizard | 24 | 14 (24) | 14 | 0 | 28 | 12% | 2.3 | 32 (8) | 0 (7) | 8 (7) | 18 (12) | 8 (10) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0102, L0118, L0135, L2531, L2730 |
| Charmed Shield | Opponent | L0524, L1224, L1527, L1625, L2025, L2127, L2934 |
| Clockwork Compass | Mine | L1224 |
| Clockwork Compass | Opponent | L0612 |
| Elixir of Power | Mine | L1114, L1131, L1923 |
| Elixir of Power | Opponent | L0319, L1319 |
| Fistful of Laurels | Mine | L1823 |
| Fistful of Laurels | Opponent | L0118, L0218 |
| Horn of the Wild Hunt | Opponent | L0733 |
| Invocation of Nehek | Mine | L2531, L2730 |
| Invocation of Nehek | Opponent | L0524, L1224, L1527, L1625, L2025, L2127 |
| Opal Amulet | Mine | L1431 |
| Opal Amulet | Opponent | L1114 |
| Periapt of Soul Exchange | Mine | L2025, L2127 |
| Periapt of Soul Exchange | Opponent | L0421, L1021 |
| Ring of Doom | Mine | L0218, L0235, L1114, L1131, L1224, L1527 |
| Ring of Doom | Opponent | L0102, L0612, L0733, L1131, L1431, L2231, L2531 |
| Ring of Jet | Mine | L1021, L1114, L1131, L1224 |
| Ring of Jet | Opponent | L0612 |
| Standard of the Fell Warrior | Mine | L1319, L1335 |
| Standard of the Fell Warrior | Opponent | L0913 |
| Storm Daemon (Renegade 2.0) | Mine | L2127 |
| Storm Daemon (Renegade 2.0) | Opponent | L0421, L1021 |
| Twice-Blessed Armour | Mine | L0717, L0733, L1021 |
| Witch Hunter's Ward | Mine | L0717, L0733, L0823 |
| Witch Hunter's Ward | Opponent | L0508 |

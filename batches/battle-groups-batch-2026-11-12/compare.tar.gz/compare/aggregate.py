import importlib.util, sys, csv, os, statistics, collections
spec=importlib.util.spec_from_file_location('cb','compare-batches.py'); m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
S=sys.argv[1]
def games(d):
    g={}
    for r in csv.DictReader(open(d+'/games.csv')):
        if r['ended']!='yes': continue
        a,b=map(int,r['vp_mine_opponent'].split('-')); g[(r['pair'],r['scenario'],r['seed'])]=(a,b,r['winner'],r.get('first_player'))
    return g
res={}
for s in ('on','off'):
    G={}; ca=collections.defaultdict(float); cag=0; rc={}; rcg=0; bgc={x:{} for x in m.SIDES}; bga={x:collections.Counter() for x in m.SIDES}; bgg=0
    kp=[]
    for k in range(1,5):
        d=f'{S}/{s}-{k}'
        G.update(games(d))
        t,n=m.combined_arms(d); cag+=n
        for side in t:
            for key,v in t[side].items(): ca[(side,key)]+=v
        r,n=m.rule_changes(d); rcg+=n
        for tag,row in r.items():
            x=rc.setdefault(tag,[0,0,0,0.0]); 
            for i in range(4): x[i]+=row[i]
        c,a,n=m.battle_group_results(d); bgg+=n
        for side in m.SIDES:
            for tag,cnt in c[side].items():
                y=bgc[side].setdefault(tag,collections.Counter()); y.update(cnt)
            bga[side].update(a[side])
    res[s]=dict(G=G,ca=ca,cag=cag,rc=rc,rcg=rcg,bgc=bgc,bga=bga,bgg=bgg)
on,off=res['on'],res['off']
P=sorted(set(on['G'])&set(off['G']))
print('shared ended games',len(P))
for s in ('on','off'):
    G=res[s]['G']; vp=sum(G[p][0]+G[p][1] for p in P)/len(P)/2; mw=sum(G[p][2]=='Mine' for p in P); ow=sum(G[p][2]=='Opponent' for p in P)
    print(s,'VP a side a game %.0f'%vp, 'Mine won',mw,'Opp won',ow)
# per side improvement in the side's own margin: on - off for both sides (each side plays with the rules)
diffs=[(on['G'][p][0]-on['G'][p][1])-(off['G'][p][0]-off['G'][p][1]) for p in P]
print('margin change Mine-Opp a game %.0f, 2se %.0f'%(statistics.mean(diffs),2*statistics.stdev(diffs)/len(diffs)**.5))
changed=sum((on['G'][p][2])!=(off['G'][p][2]) for p in P); print('games changing result',changed)
for s in ('on','off'):
    ca=res[s]['ca']; print(s,'combined', {k:v for k,v in sorted(ca.items())})
for s in ('on','off'):
    print(s,'rules', {t:v for t,v in res[s]['rc'].items() if t in ('GROUP AIM','ESCORT','COUNTER-CHARGE COVER','REDIRECT COUNTER','HUNT IN PAIRS','SET UP TOGETHER','SCREEN STEPS ASIDE','GROUP BROKEN','BACKUP TARGETS','MISSILES NEXT TURN')}, 'games',res[s]['rcg'])
print('cover', {s:{t:dict(c) for t,c in on['bgc'][s].items()} for s in m.SIDES})
print('aims', {s:dict(on['bga'][s]) for s in m.SIDES}, on['bgg'])

# groups on vs groups off

A = groups on: on-2, 36 of 36 games ended
B = groups off: off-2, 36 of 36 games ended

## Game by game (Victory Points Mine-Opponent; margin = Mine minus Opponent)

| Match-up | Scenario | Seed | A | B | Margin A | Margin B | A minus B | Cost A | Cost B |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0106 | 4 | 1 | Mine 2001-740 | draw 905-863 | +1261 | +42 | +1219 | 0.00 | 0.00 |
| L0122 | 2 | 1 | Opponent 465-3223 | Mine 2299-1778 | -2758 | +521 | -3279 | 0.00 | 0.00 |
| L0206 | 2 | 1 | Opponent 865-1555 | draw 1367-1232 | -690 | +135 | -825 | 0.00 | 0.00 |
| L0222 | 6 | 1 | draw 1676-1746 | draw 1414-1119 | -70 | +295 | -365 | 0.00 | 0.00 |
| L0307 | 1 | 1 | draw 1424-1586 | Opponent 404-2066 | -162 | -1662 | +1500 | 0.00 | 0.00 |
| L0323 | 5 | 1 | Opponent 922-1390 | draw 1256-1436 | -468 | -180 | -288 | 0.00 | 0.00 |
| L0409 | 1 | 1 | Opponent 1556-2339 | Mine 2497-1770 | -783 | +727 | -1510 | 0.00 | 0.00 |
| L0425 | 5 | 1 | Mine 1740-769 | draw 1416-1473 | +971 | -57 | +1028 | 0.00 | 0.00 |
| L0512 | 2 | 1 | Opponent 1016-1535 | Mine 1430-981 | -519 | +449 | -968 | 0.00 | 0.00 |
| L0528 | 6 | 1 | Opponent 1219-2045 | Opponent 1091-2060 | -826 | -969 | +143 | 0.00 | 0.00 |
| L0616 | 4 | 1 | draw 1258-1415 | Opponent 1108-2151 | -157 | -1043 | +886 | 0.00 | 0.00 |
| L0632 | 2 | 1 | Opponent 1063-2271 | Opponent 875-2046 | -1208 | -1171 | -37 | 0.00 | 0.00 |
| L0721 | 1 | 1 | Opponent 1222-2459 | Mine 2344-1184 | -1237 | +1160 | -2397 | 0.00 | 0.00 |
| L0810 | 6 | 1 | Opponent 330-2639 | Opponent 709-2814 | -2309 | -2105 | -204 | 0.00 | 0.00 |
| L0827 | 5 | 1 | Opponent 45-2830 | Opponent 147-1642 | -2785 | -1495 | -1290 | 0.00 | 0.00 |
| L0918 | 6 | 1 | draw 1332-1428 | Mine 2471-505 | -96 | +1966 | -2062 | 0.00 | 0.00 |
| L0934 | 4 | 1 | Opponent 624-3107 | Opponent 448-3015 | -2483 | -2567 | +84 | 0.00 | 0.00 |
| L1026 | 6 | 1 | Opponent 664-1158 | Opponent 589-1414 | -494 | -825 | +331 | 0.00 | 0.00 |
| L1118 | 2 | 1 | Mine 2455-680 | Mine 2087-922 | +1775 | +1165 | +610 | 0.00 | 0.00 |
| L1135 | 1 | 1 | Mine 1804-685 | Mine 1852-813 | +1119 | +1039 | +80 | 0.00 | 0.00 |
| L1228 | 4 | 1 | Mine 1057-374 | draw 1062-1333 | +683 | -271 | +954 | 0.00 | 0.00 |
| L1323 | 3 | 1 | Opponent 757-3009 | Mine 2204-942 | -2252 | +1262 | -3514 | 0.00 | 0.00 |
| L1418 | 2 | 1 | Mine 2733-989 | Mine 1676-897 | +1744 | +779 | +965 | 0.00 | 0.00 |
| L1435 | 1 | 1 | Opponent 1186-1993 | draw 1008-1286 | -807 | -278 | -529 | 0.00 | 0.00 |
| L1531 | 1 | 1 | Mine 2231-240 | Mine 1820-445 | +1991 | +1375 | +616 | 0.00 | 0.00 |
| L1629 | 3 | 1 | draw 1769-1525 | Opponent 1349-1786 | +244 | -437 | +681 | 0.00 | 0.00 |
| L1727 | 5 | 1 | draw 831-564 | Opponent 961-1367 | +267 | -406 | +673 | 0.00 | 0.00 |
| L1827 | 3 | 1 | Opponent 480-2883 | Opponent 956-2070 | -2403 | -1114 | -1289 | 0.00 | 0.00 |
| L1927 | 1 | 1 | draw 1537-1828 | Mine 1680-988 | -291 | +692 | -983 | 0.00 | 0.00 |
| L2029 | 1 | 1 | Opponent 525-2790 | Opponent 145-3286 | -2265 | -3141 | +876 | 0.00 | 0.00 |
| L2131 | 1 | 1 | draw 1734-1859 | Opponent 1027-2461 | -125 | -1434 | +1309 | 0.00 | 0.00 |
| L2235 | 3 | 1 | Opponent 1317-2364 | Mine 2387-808 | -1047 | +1579 | -2626 | 0.00 | 0.00 |
| L2429 | 5 | 1 | Opponent 833-1594 | Opponent 270-2883 | -761 | -2613 | +1852 | 0.00 | 0.00 |
| L2535 | 3 | 1 | draw 1062-967 | Mine 1236-666 | +95 | +570 | -475 | 0.00 | 0.00 |
| L2735 | 5 | 1 | draw 1439-1223 | Opponent 0-2625 | +216 | -2625 | +2841 | 0.00 | 0.00 |
| L3033 | 3 | 1 | Mine 2049-901 | Mine 2639-866 | +1148 | +1773 | -625 | 0.00 | 0.00 |

## Totals

| | A: groups on | B: groups off |
| --- | --- | --- |
| Mine won / drew / lost | 8 / 10 / 18 | 14 / 7 / 15 |
| Mean margin (Mine - Opponent) | -430 | -246 |
| Cost per game | $0.000 | $0.000 |
| Mine side per game | $0.000 | $0.000 |
| Opponent side per game | $0.000 | $0.000 |
| Cost of the batch | $0.00 | $0.00 |
| Failed calls per game | 0.0 | 0.0 |
| VP from objectives, Mine | 469 | 504 |
| VP from objectives, Opponent | 634 | 621 |
| VP from kills, Mine | 738 | 750 |
| VP from kills, Opponent | 971 | 855 |
| VP from leaders, Mine | 49 | 54 |
| VP from leaders, Opponent | 76 | 76 |
| VP from other, Mine | 1 | 1 |
| VP from other, Opponent | 4 | 3 |
| Units lost, Mine | 6.1 | 5.4 |
| Units lost, Opponent | 4.4 | 4.7 |
| Scorecard: Far marker / quarter contested by round 3 (both sides) | 30% | 32% |
| Scorecard: Lone holders (player turns) (both sides) | 1.9 | 2.0 |
| Scorecard: Round of the first Hammer charge (both sides) | 2.6 | 2.7 |
| Scorecard: Lone charges into a block / monster / character (both sides) | 2.6 | 2.7 |
| Scorecard: Idle units (both sides) | 1.4 | 1.5 |
| Scorecard: Wounded Lords / monsters lost (both sides) | 0.4 | 0.4 |
| Scorecard: Doctrine flags raised (both sides) | 0.0 | 0.0 |
| Scorecard: Answers changed after a flag (both sides) | 0.0 | 0.0 |
| Scorecard: Points that never moved of their own (both sides) | 273.2 | 304.1 |

## Is the difference more than noise?

36 pairs of games: A's margin is -184 VP a game against B's, give or take 476 VP (two standard errors). Verdict: within noise (could be chance).

## KPIs (Morten 2026-11-10)

A = groups on (36 games), B = groups off (36 games).

| KPI | Target | A Mine | A Opponent | A both | B Mine | B Opponent | B both |
| --- | --- | --- | --- | --- | --- | --- | --- |
| Winner chose to follow up after the loser gave ground |  | 98%; on the table 98% | 95%; on the table 95% | 96%; on the table 96% | 99%; on the table 99% | 96%; on the table 96% | 98%; on the table 98% |
| Winner chose to pursue after the loser fell back in good order |  | 75%; on the table 75% | 90%; on the table 95% | 85%; on the table 88% | 75%; on the table 75% | 80%; on the table 87% | 78%; on the table 83% |
| Winner chose to pursue after the loser fled |  | 36%; on the table 48% | 79%; on the table 82% | 60%; on the table 67% | 63%; on the table 70% | 81%; on the table 86% | 73%; on the table 79% |
| Winner chose to follow up or pursue (all three) |  | 76%; on the table 80% | 90%; on the table 91% | 84%; on the table 86% | 89%; on the table 91% | 88%; on the table 91% | 89%; on the table 91% |
| Magic missiles tried each own turn | 50%+ | 23% | 31% | 25% | 28% | 30% | 29% |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 32% | 43% | 35% | 36% | 44% | 38% |
| Points that never fought | lower | 31% | 38% | 34% | 36% | 37% | 37% |
|   infantry points that never fought | lower | 37% | 62% | 49% | 41% | 51% | 45% |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 61% | 57% | 59% | 59% | 58% | 59% |
| Bound items with a magic missile used (at least once a game) |  | 90% | 72% | 82% | 95% | 67% | 82% |
| Bound items with another spell used |  | 44% | 0% | 40% | 44% | 50% | 45% |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 40% | 14% | 33% | 45% | 29% | 41% |
|   their share of the points of units over 100 pts | lower | 56% | 48% | 52% | 54% | 51% | 52% |

Flank and rear charges a unit could have turned to face (the side is the charged unit's):

| Measure | groups on Mine | groups on Opponent | groups off Mine | groups off Opponent |
| --- | --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 48% (47) | 69% (46) | 49% (45) | 58% (38) |
| ...free all their last turn and able to turn (per game) | 0.78 | 0.86 | 0.83 | 0.72 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.31 | 0.17 | 0.14 | 0.14 |
| ...with the charger already in that arc before they moved (per game) | 0.56 | 0.58 | 0.64 | 0.47 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 1.64 | 1.31 | 1.58 | 1.14 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.64 | 0.81 | 0.67 | 1.03 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 10.86 | 10.14 | 10.56 | 8.81 |

### Charges a game and per unit by the wizard it carries

| Charges | A Mine | A Opponent | A both | B Mine | B Opponent | B both |
| --- | --- | --- | --- | --- | --- | --- |
| Charges declared a game | 4.0 | 6.3 | 5.1 | 4.2 | 6.1 | 5.1 |
| Charges that made contact a game | 3.1 | 4.5 | 3.8 | 2.8 | 4.1 | 3.5 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.65 declared, 0.50 contact (26 units) | 0.77 declared, 0.77 contact (13 units) | 0.69 declared, 0.59 contact (39 units) | 0.72 declared, 0.40 contact (25 units) | 0.71 declared, 0.36 contact (14 units) | 0.72 declared, 0.38 contact (39 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.83 declared, 0.50 contact (6 units) | 1.36 declared, 1.09 contact (11 units) | 1.18 declared, 0.88 contact (17 units) | 0.33 declared, 0.33 contact (6 units) | 1.00 declared, 0.75 contact (12 units) | 0.78 declared, 0.61 contact (18 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.49 declared, 0.39 contact (247 units) | 0.70 declared, 0.49 contact (288 units) | 0.60 declared, 0.44 contact (535 units) | 0.53 declared, 0.37 contact (244 units) | 0.68 declared, 0.46 contact (290 units) | 0.61 declared, 0.42 contact (534 units) |

## Movement (Morten 2026-11-11)

A = groups on (36 games), B = groups off (36 games); per side and game.

| Measure | A Mine | A Opponent | A both | B Mine | B Opponent | B both |
| --- | --- | --- | --- | --- | --- | --- |
| Games where this side made the first charge contact | 42% (15 of 36) | 58% (21 of 36) | 50% (36 of 72) | 33% (12 of 36) | 67% (24 of 36) | 50% (36 of 72) |
| Round of a side's first charge contact (sides that made one) | 2.6 | 2.9 | 2.8 | 3.1 | 2.5 | 2.8 |
| Sides that never declared a charge | 14% (5 of 36) | 3% (1 of 36) | 8% (6 of 72) | 3% (1 of 36) | 0% (0 of 36) | 1% (1 of 72) |
| Sides that never made charge contact | 19% (7 of 36) | 3% (1 of 36) | 11% (8 of 72) | 8% (3 of 36) | 3% (1 of 36) | 6% (4 of 72) |
| Charges declared a game | 4.0 | 6.3 | 5.1 | 4.2 | 6.1 | 5.1 |
| Charge contacts made a game | 3.1 | 4.5 | 3.8 | 2.8 | 4.1 | 3.5 |
| Charge contacts received a game | 4.5 | 3.1 | 3.8 | 4.1 | 2.8 | 3.5 |
| Joint charges a game (2+ units on one target in one turn) | 0.3 | 0.6 | 0.4 | 0.2 | 0.5 | 0.3 |
|   share of charged targets hit by 2+ units | 11% (11 of 101) | 15% (21 of 139) | 13% (32 of 240) | 6% (6 of 95) | 15% (19 of 125) | 11% (25 of 220) |
| Lone charges that a friend follows on the same target next turn | 7% (6 of 90) | 9% (11 of 118) | 8% (17 of 208) | 7% (6 of 89) | 7% (7 of 106) | 7% (13 of 195) |
| Set-ups (close in to charge next turn) that charged that target next turn | 11% (16 of 152) | 18% (43 of 234) | 15% (59 of 386) | 12% (21 of 174) | 17% (36 of 209) | 15% (57 of 383) |
|   ... and made contact | 9% (13 of 152) | 14% (33 of 234) | 12% (46 of 386) | 7% (13 of 174) | 12% (26 of 209) | 10% (39 of 383) |
|   ... with a friend on it too | 2% (3 of 152) | 4% (10 of 234) | 3% (13 of 386) | 3% (5 of 174) | 5% (10 of 209) | 4% (15 of 383) |
| Set-ups missed (no charge on that target next turn) | 89% (136 of 152) | 82% (191 of 234) | 85% (327 of 386) | 88% (153 of 174) | 83% (173 of 209) | 85% (326 of 383) |
| Charge contacts in the flank or rear (arc known) | 57% (64 of 113) | 55% (89 of 163) | 55% (153 of 276) | 50% (51 of 102) | 53% (78 of 147) | 52% (129 of 249) |
|   in the rear | 10% (11 of 113) | 12% (19 of 163) | 11% (30 of 276) | 10% (10 of 102) | 12% (18 of 147) | 11% (28 of 249) |
| Declared charges in the flank or rear (arc known) | 53% (77 of 144) | 50% (113 of 226) | 51% (190 of 370) | 52% (78 of 150) | 48% (105 of 219) | 50% (183 of 369) |

## Doctrine scorecard (per game and side; far = share of games contested)

### Scorecard: groups on

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0106 | 4 | 1 | Mine | no | 2 | 3 | 2 | 3 | 0 | 0 | 0 | 322 |
| L0106 | 4 | 1 | Opponent | no | 0 | 2 | 1 | 1 | 0 | 0 | 0 | 798 |
| L0122 | 2 | 1 | Mine | - | - | - | 0 | 2 | 1 | 0 | 0 | 639 |
| L0122 | 2 | 1 | Opponent | - | - | 2 | 3 | 0 | 0 | 0 | 0 | 0 |
| L0206 | 2 | 1 | Mine | - | - | 4 | 1 | 7 | 1 | 0 | 0 | 0 |
| L0206 | 2 | 1 | Opponent | - | - | 1 | 1 | 1 | 0 | 0 | 0 | 615 |
| L0222 | 6 | 1 | Mine | no | 2 | 4 | 4 | 3 | 2 | 0 | 0 | 170 |
| L0222 | 6 | 1 | Opponent | no | 1 | 1 | 5 | 0 | 0 | 0 | 0 | 0 |
| L0307 | 1 | 1 | Mine | yes | 0 | 3 | 4 | 2 | 0 | 0 | 0 | 760 |
| L0307 | 1 | 1 | Opponent | yes | 3 | 2 | 1 | 1 | 0 | 0 | 0 | 420 |
| L0323 | 5 | 1 | Mine | yes | - | 4 | 2 | 2 | 0 | 0 | 0 | 675 |
| L0323 | 5 | 1 | Opponent | yes | - | 2 | 5 | 3 | 1 | 0 | 0 | 140 |
| L0409 | 1 | 1 | Mine | no | 3 | 2 | 5 | 0 | 0 | 0 | 0 | 0 |
| L0409 | 1 | 1 | Opponent | no | 9 | - | 0 | 1 | 0 | 0 | 0 | 873 |
| L0425 | 5 | 1 | Mine | yes | - | 2 | 6 | 2 | 0 | 0 | 0 | 0 |
| L0425 | 5 | 1 | Opponent | no | - | 2 | 2 | 3 | 0 | 0 | 0 | 0 |
| L0512 | 2 | 1 | Mine | - | - | - | 0 | 2 | 0 | 0 | 0 | 666 |
| L0512 | 2 | 1 | Opponent | - | - | 2 | 5 | 1 | 2 | 0 | 0 | 330 |
| L0528 | 6 | 1 | Mine | no | 0 | 6 | 1 | 1 | 0 | 0 | 0 | 1343 |
| L0528 | 6 | 1 | Opponent | yes | 5 | 3 | 1 | 2 | 1 | 0 | 0 | 0 |
| L0616 | 4 | 1 | Mine | no | 0 | 2 | 2 | 0 | 1 | 0 | 0 | 615 |
| L0616 | 4 | 1 | Opponent | no | 0 | 2 | 0 | 1 | 1 | 0 | 0 | 200 |
| L0632 | 2 | 1 | Mine | - | - | - | 1 | 0 | 0 | 0 | 0 | 838 |
| L0632 | 2 | 1 | Opponent | - | - | 2 | 5 | 3 | 1 | 0 | 0 | 0 |
| L0721 | 1 | 1 | Mine | yes | 1 | 3 | 5 | 0 | 0 | 0 | 0 | 420 |
| L0721 | 1 | 1 | Opponent | no | 4 | 6 | 1 | 4 | 1 | 0 | 0 | 500 |
| L0810 | 6 | 1 | Mine | no | 0 | 4 | 1 | 2 | 0 | 0 | 0 | 515 |
| L0810 | 6 | 1 | Opponent | no | 20 | 5 | 0 | 1 | 0 | 0 | 0 | 330 |
| L0827 | 5 | 1 | Mine | no | - | - | 0 | 1 | 0 | 0 | 0 | 922 |
| L0827 | 5 | 1 | Opponent | yes | - | 2 | 3 | 5 | 0 | 0 | 0 | 0 |
| L0918 | 6 | 1 | Mine | no | 0 | - | 0 | 0 | 0 | 0 | 0 | 420 |
| L0918 | 6 | 1 | Opponent | no | 3 | 2 | 2 | 2 | 1 | 0 | 0 | 234 |
| L0934 | 4 | 1 | Mine | no | 0 | 1 | 1 | 0 | 0 | 0 | 0 | 1105 |
| L0934 | 4 | 1 | Opponent | no | 0 | 2 | 4 | 3 | 0 | 0 | 0 | 56 |
| L1026 | 6 | 1 | Mine | no | 0 | 2 | 4 | 0 | 1 | 0 | 0 | 330 |
| L1026 | 6 | 1 | Opponent | no | 2 | 4 | 3 | 2 | 1 | 0 | 0 | 0 |
| L1118 | 2 | 1 | Mine | - | - | 2 | 4 | 0 | 0 | 0 | 0 | 330 |
| L1118 | 2 | 1 | Opponent | - | - | - | 1 | 3 | 1 | 0 | 0 | 0 |
| L1135 | 1 | 1 | Mine | yes | 0 | 2 | 4 | 0 | 0 | 0 | 0 | 501 |
| L1135 | 1 | 1 | Opponent | yes | 0 | 2 | 2 | 0 | 1 | 0 | 0 | 0 |
| L1228 | 4 | 1 | Mine | no | 3 | 2 | 0 | 1 | 0 | 0 | 0 | 524 |
| L1228 | 4 | 1 | Opponent | no | 0 | 3 | 2 | 1 | 0 | 0 | 0 | 0 |
| L1323 | 3 | 1 | Mine | no | 1 | 2 | 0 | 1 | 2 | 0 | 0 | 291 |
| L1323 | 3 | 1 | Opponent | no | 0 | 2 | 4 | 0 | 1 | 0 | 0 | 132 |
| L1418 | 2 | 1 | Mine | - | - | 2 | 1 | 0 | 1 | 0 | 0 | 123 |
| L1418 | 2 | 1 | Opponent | - | - | - | 0 | 2 | 1 | 0 | 0 | 305 |
| L1435 | 1 | 1 | Mine | no | 0 | 3 | 2 | 2 | 0 | 0 | 0 | 0 |
| L1435 | 1 | 1 | Opponent | no | 3 | 2 | 5 | 0 | 0 | 0 | 0 | 432 |
| L1531 | 1 | 1 | Mine | no | 6 | 2 | 1 | 1 | 0 | 0 | 0 | 176 |
| L1531 | 1 | 1 | Opponent | no | 1 | 6 | 1 | 1 | 0 | 0 | 0 | 170 |
| L1629 | 3 | 1 | Mine | no | 0 | 2 | 3 | 0 | 0 | 0 | 0 | 200 |
| L1629 | 3 | 1 | Opponent | no | 3 | 2 | 6 | 1 | 0 | 0 | 0 | 170 |
| L1727 | 5 | 1 | Mine | yes | - | 3 | 2 | 0 | 0 | 0 | 0 | 0 |
| L1727 | 5 | 1 | Opponent | yes | - | 5 | 4 | 4 | 1 | 0 | 0 | 60 |
| L1827 | 3 | 1 | Mine | no | 0 | 6 | 2 | 1 | 0 | 0 | 0 | 602 |
| L1827 | 3 | 1 | Opponent | no | 4 | 2 | 7 | 1 | 0 | 0 | 0 | 0 |
| L1927 | 1 | 1 | Mine | no | 1 | 1 | 4 | 1 | 0 | 0 | 0 | 0 |
| L1927 | 1 | 1 | Opponent | no | 0 | 2 | 4 | 3 | 0 | 0 | 0 | 60 |
| L2029 | 1 | 1 | Mine | no | 3 | - | 0 | 2 | 0 | 0 | 0 | 210 |
| L2029 | 1 | 1 | Opponent | no | 2 | 2 | 2 | 1 | 1 | 0 | 0 | 292 |
| L2131 | 1 | 1 | Mine | yes | 0 | - | 1 | 2 | 0 | 0 | 0 | 145 |
| L2131 | 1 | 1 | Opponent | no | 5 | 3 | 4 | 0 | 2 | 0 | 0 | 170 |
| L2235 | 3 | 1 | Mine | yes | 1 | 1 | 5 | 0 | 0 | 0 | 0 | 225 |
| L2235 | 3 | 1 | Opponent | no | 0 | 2 | 4 | 2 | 0 | 0 | 0 | 0 |
| L2429 | 5 | 1 | Mine | yes | - | 4 | 4 | 1 | 1 | 0 | 0 | 0 |
| L2429 | 5 | 1 | Opponent | yes | - | 3 | 6 | 2 | 1 | 0 | 0 | 170 |
| L2535 | 3 | 1 | Mine | no | 0 | 4 | 2 | 2 | 0 | 0 | 0 | 0 |
| L2535 | 3 | 1 | Opponent | no | 0 | 1 | 2 | 1 | 0 | 0 | 0 | 0 |
| L2735 | 5 | 1 | Mine | no | - | 3 | 3 | 1 | 0 | 0 | 0 | 0 |
| L2735 | 5 | 1 | Opponent | yes | - | 2 | 3 | 0 | 0 | 0 | 0 | 0 |
| L3033 | 3 | 1 | Mine | yes | 4 | 3 | 3 | 0 | 1 | 0 | 0 | 0 |
| L3033 | 3 | 1 | Opponent | no | 0 | 1 | 6 | 2 | 0 | 0 | 0 | 144 |
| **Average** | | | Mine | 33% | 1.1 | 2.8 | 2.2 | 1.2 | 0.3 | 0.0 | 0.0 | 363.0 |
| **Average** | | | Opponent | 27% | 2.7 | 2.5 | 2.9 | 1.6 | 0.5 | 0.0 | 0.0 | 183.4 |

### Scorecard: groups off

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0106 | 4 | 1 | Mine | no | 2 | 2 | 2 | 3 | 0 | 0 | 0 | 387 |
| L0106 | 4 | 1 | Opponent | no | 0 | 2 | 3 | 0 | 0 | 0 | 0 | 798 |
| L0122 | 2 | 1 | Mine | - | - | 5 | 0 | 2 | 0 | 0 | 0 | 0 |
| L0122 | 2 | 1 | Opponent | - | - | 2 | 3 | 0 | 0 | 0 | 0 | 0 |
| L0206 | 2 | 1 | Mine | - | - | 5 | 1 | 5 | 1 | 0 | 0 | 0 |
| L0206 | 2 | 1 | Opponent | - | - | 1 | 1 | 2 | 0 | 0 | 0 | 615 |
| L0222 | 6 | 1 | Mine | no | 2 | 3 | 2 | 5 | 1 | 0 | 0 | 170 |
| L0222 | 6 | 1 | Opponent | no | 1 | 1 | 3 | 1 | 0 | 0 | 0 | 0 |
| L0307 | 1 | 1 | Mine | yes | 1 | 3 | 1 | 1 | 0 | 0 | 0 | 760 |
| L0307 | 1 | 1 | Opponent | yes | 1 | 2 | 4 | 0 | 0 | 0 | 0 | 420 |
| L0323 | 5 | 1 | Mine | yes | - | 6 | 1 | 2 | 1 | 0 | 0 | 590 |
| L0323 | 5 | 1 | Opponent | yes | - | 2 | 2 | 4 | 2 | 0 | 0 | 140 |
| L0409 | 1 | 1 | Mine | no | 2 | 2 | 2 | 2 | 0 | 0 | 0 | 0 |
| L0409 | 1 | 1 | Opponent | no | 8 | 6 | 0 | 0 | 0 | 0 | 0 | 913 |
| L0425 | 5 | 1 | Mine | yes | - | 2 | 5 | 2 | 0 | 0 | 0 | 0 |
| L0425 | 5 | 1 | Opponent | no | - | 2 | 2 | 6 | 0 | 0 | 0 | 0 |
| L0512 | 2 | 1 | Mine | - | - | 3 | 4 | 2 | 0 | 0 | 0 | 709 |
| L0512 | 2 | 1 | Opponent | - | - | 2 | 5 | 0 | 1 | 0 | 0 | 330 |
| L0528 | 6 | 1 | Mine | no | 0 | 3 | 1 | 2 | 0 | 0 | 0 | 901 |
| L0528 | 6 | 1 | Opponent | no | 4 | 3 | 0 | 2 | 0 | 0 | 0 | 0 |
| L0616 | 4 | 1 | Mine | no | 0 | 4 | 2 | 1 | 0 | 0 | 0 | 750 |
| L0616 | 4 | 1 | Opponent | no | 0 | 2 | 1 | 2 | 2 | 0 | 0 | 200 |
| L0632 | 2 | 1 | Mine | - | - | 3 | 3 | 0 | 0 | 0 | 0 | 801 |
| L0632 | 2 | 1 | Opponent | - | - | 2 | 3 | 4 | 0 | 0 | 0 | 139 |
| L0721 | 1 | 1 | Mine | yes | 1 | 3 | 1 | 0 | 0 | 0 | 0 | 420 |
| L0721 | 1 | 1 | Opponent | no | 0 | 6 | 1 | 3 | 1 | 0 | 0 | 500 |
| L0810 | 6 | 1 | Mine | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 515 |
| L0810 | 6 | 1 | Opponent | no | 8 | 3 | 1 | 1 | 1 | 0 | 0 | 501 |
| L0827 | 5 | 1 | Mine | no | - | 5 | 1 | 1 | 0 | 0 | 0 | 753 |
| L0827 | 5 | 1 | Opponent | yes | - | 3 | 4 | 4 | 0 | 0 | 0 | 0 |
| L0918 | 6 | 1 | Mine | no | 0 | 3 | 4 | 1 | 0 | 0 | 0 | 420 |
| L0918 | 6 | 1 | Opponent | no | 5 | 5 | 2 | 2 | 0 | 0 | 0 | 234 |
| L0934 | 4 | 1 | Mine | no | 1 | 1 | 2 | 0 | 0 | 0 | 0 | 1001 |
| L0934 | 4 | 1 | Opponent | no | 0 | 2 | 5 | 3 | 0 | 0 | 0 | 160 |
| L1026 | 6 | 1 | Mine | no | 0 | 2 | 4 | 1 | 1 | 0 | 0 | 497 |
| L1026 | 6 | 1 | Opponent | no | 2 | 2 | 6 | 0 | 1 | 0 | 0 | 0 |
| L1118 | 2 | 1 | Mine | - | - | 3 | 1 | 0 | 0 | 0 | 0 | 330 |
| L1118 | 2 | 1 | Opponent | - | - | 2 | 5 | 0 | 1 | 0 | 0 | 0 |
| L1135 | 1 | 1 | Mine | yes | 0 | 2 | 5 | 0 | 0 | 0 | 0 | 330 |
| L1135 | 1 | 1 | Opponent | yes | 0 | 2 | 3 | 2 | 0 | 0 | 0 | 158 |
| L1228 | 4 | 1 | Mine | no | 4 | 2 | 1 | 0 | 0 | 0 | 0 | 524 |
| L1228 | 4 | 1 | Opponent | no | 4 | 5 | 2 | 2 | 0 | 0 | 0 | 0 |
| L1323 | 3 | 1 | Mine | yes | 10 | 3 | 2 | 0 | 1 | 0 | 0 | 479 |
| L1323 | 3 | 1 | Opponent | no | 3 | 2 | 2 | 2 | 0 | 0 | 0 | 264 |
| L1418 | 2 | 1 | Mine | - | - | 2 | 5 | 2 | 1 | 0 | 0 | 123 |
| L1418 | 2 | 1 | Opponent | - | - | 2 | 2 | 2 | 1 | 0 | 0 | 836 |
| L1435 | 1 | 1 | Mine | no | 2 | 2 | 0 | 1 | 0 | 0 | 0 | 0 |
| L1435 | 1 | 1 | Opponent | no | 1 | 2 | 6 | 1 | 0 | 0 | 0 | 572 |
| L1531 | 1 | 1 | Mine | no | 4 | 2 | 3 | 0 | 1 | 0 | 0 | 126 |
| L1531 | 1 | 1 | Opponent | no | 3 | 4 | 3 | 0 | 2 | 0 | 0 | 484 |
| L1629 | 3 | 1 | Mine | no | 3 | 3 | 1 | 0 | 1 | 0 | 0 | 536 |
| L1629 | 3 | 1 | Opponent | no | 0 | 2 | 3 | 1 | 0 | 0 | 0 | 170 |
| L1727 | 5 | 1 | Mine | yes | - | 4 | 4 | 0 | 1 | 0 | 0 | 0 |
| L1727 | 5 | 1 | Opponent | yes | - | 2 | 5 | 4 | 2 | 0 | 0 | 0 |
| L1827 | 3 | 1 | Mine | no | 1 | - | 2 | 0 | 0 | 0 | 0 | 482 |
| L1827 | 3 | 1 | Opponent | no | 2 | 2 | 10 | 0 | 0 | 0 | 0 | 0 |
| L1927 | 1 | 1 | Mine | no | 1 | 1 | 4 | 0 | 0 | 0 | 0 | 156 |
| L1927 | 1 | 1 | Opponent | no | 3 | 2 | 2 | 3 | 0 | 0 | 0 | 60 |
| L2029 | 1 | 1 | Mine | no | 0 | - | 1 | 2 | 2 | 0 | 0 | 650 |
| L2029 | 1 | 1 | Opponent | no | 4 | 2 | 1 | 1 | 0 | 0 | 0 | 292 |
| L2131 | 1 | 1 | Mine | yes | 1 | - | 2 | 3 | 0 | 0 | 0 | 850 |
| L2131 | 1 | 1 | Opponent | no | 3 | 2 | 2 | 0 | 1 | 0 | 0 | 170 |
| L2235 | 3 | 1 | Mine | no | 0 | 1 | 5 | 1 | 0 | 0 | 0 | 55 |
| L2235 | 3 | 1 | Opponent | no | 0 | 3 | 2 | 2 | 1 | 0 | 0 | 0 |
| L2429 | 5 | 1 | Mine | yes | - | 4 | 4 | 1 | 0 | 0 | 0 | 0 |
| L2429 | 5 | 1 | Opponent | yes | - | 3 | 5 | 4 | 1 | 0 | 0 | 170 |
| L2535 | 3 | 1 | Mine | no | 2 | 2 | 2 | 0 | 0 | 0 | 0 | 0 |
| L2535 | 3 | 1 | Opponent | yes | 0 | 1 | 2 | 0 | 0 | 0 | 0 | 158 |
| L2735 | 5 | 1 | Mine | yes | - | - | 2 | 1 | 1 | 0 | 0 | 60 |
| L2735 | 5 | 1 | Opponent | yes | - | 2 | 4 | 3 | 0 | 0 | 0 | 0 |
| L3033 | 3 | 1 | Mine | yes | 5 | 3 | 6 | 0 | 1 | 0 | 0 | 0 |
| L3033 | 3 | 1 | Opponent | no | 2 | 1 | 2 | 1 | 0 | 0 | 0 | 236 |
| **Average** | | | Mine | 37% | 1.8 | 2.9 | 2.4 | 1.2 | 0.4 | 0.0 | 0.0 | 371.5 |
| **Average** | | | Opponent | 27% | 2.2 | 2.5 | 3.0 | 1.7 | 0.5 | 0.0 | 0.0 | 236.7 |


## Charged fights (points per fight a side charged into; a combined charge is one fight)

### Charged fights: groups on

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 33 | 318 | 1.8 | 1.0 | 181 | 0 | +181 | 2 of 7 | 5 of 7 | - | +181 |
| Mine | Chaos Dwarfs | 4 | 353 | 255 | 3.5 | 1.0 | 73 | 22 | +51 | 8 of 14 | 13 of 14 | - | +51 |
| Mine | Dwarfen Mountain Holds | 4 | 712 | 34 | 0.8 | 1.0 | 46 | 0 | +46 | 2 of 3 | 2 of 3 | - | +46 |
| Mine | Empire of Man | 5 | 263 | 50 | 1.2 | 1.0 | 42 | 204 | -162 | 4 of 6 | 0 of 6 | - | -162 |
| Mine | Grand Cathay | 4 | 202 | 475 | 3.5 | 1.1 | 136 | 0 | +136 | 4 of 14 | 14 of 14 | +125 | +137 |
| Mine | High Elf Realms | 4 | 168 | 589 | 3.5 | 1.5 | 168 | 10 | +158 | 7 of 14 | 11 of 14 | +233 | +83 |
| Mine | Kingdom of Bretonnia | 1 | 30 | 1129 | 3.0 | 1.0 | 376 | 132 | +244 | 2 of 3 | 1 of 3 | - | +244 |
| Mine | Lizardmen | 1 | 45 | 436 | 4.0 | 1.5 | 109 | 0 | +109 | 0 of 4 | 2 of 4 | +218 | +0 |
| Mine | Ogre Kingdoms | 1 | 0 | 0 | 3.0 | 1.0 | 0 | 11 | -11 | 1 of 3 | 2 of 3 | - | -11 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 911 | 5.0 | 1.4 | 182 | 74 | +108 | 2 of 5 | 4 of 5 | -55 | +149 |
| Mine | Skaven | 2 | 174 | 0 | 0.5 | 1.0 | 0 | 112 | -112 | 0 of 1 | 0 of 1 | - | -112 |
| Mine | Tomb Kings of Khemri | 1 | 114 | 697 | 7.0 | 1.0 | 100 | 73 | +27 | 3 of 7 | 4 of 7 | - | +27 |
| Mine | Vampire Counts | 3 | 0 | 436 | 6.3 | 1.0 | 69 | 50 | +19 | 4 of 19 | 15 of 19 | - | +19 |
| Mine | Warriors of Chaos | 1 | 19 | 608 | 1.0 | 1.0 | 608 | 0 | +608 | 0 of 1 | 0 of 1 | - | +608 |
| **Mine** | all armies | 36 | 215 | 334 | 2.8 | 1.1 | 119 | 40 | +79 | 39 of 101 | 73 of 101 | +194 | +65 |
| Opponent | Dwarfen Mountain Holds | 2 | 270 | 32 | 1.0 | 2.0 | 32 | 0 | +32 | 1 of 2 | 1 of 2 | +32 | - |
| Opponent | Empire of Man | 2 | 927 | 110 | 1.0 | 1.0 | 110 | 0 | +110 | 0 of 2 | 2 of 2 | - | +110 |
| Opponent | Grand Cathay | 2 | 454 | 378 | 4.5 | 1.3 | 84 | 0 | +84 | 6 of 9 | 6 of 9 | +178 | +57 |
| Opponent | Kingdom of Bretonnia | 1 | 225 | 225 | 3.0 | 1.3 | 75 | 92 | -17 | 1 of 3 | 2 of 3 | -277 | +112 |
| Opponent | Ogre Kingdoms | 3 | 340 | 290 | 3.3 | 1.1 | 87 | 21 | +66 | 4 of 10 | 4 of 10 | -34 | +77 |
| Opponent | Skaven | 1 | 0 | 125 | 2.0 | 1.0 | 62 | 0 | +62 | 0 of 2 | 2 of 2 | - | +62 |
| Opponent | Tomb Kings of Khemri | 4 | 38 | 1235 | 5.0 | 1.1 | 247 | 66 | +181 | 9 of 20 | 11 of 20 | +396 | +143 |
| Opponent | Vampire Counts | 6 | 36 | 755 | 4.3 | 1.2 | 174 | 25 | +150 | 12 of 26 | 16 of 26 | +131 | +153 |
| Opponent | Warriors of Chaos | 8 | 8 | 560 | 3.9 | 1.1 | 144 | 30 | +115 | 17 of 31 | 22 of 31 | +232 | +102 |
| Opponent | Wood Elf Realms | 7 | 91 | 522 | 4.9 | 1.2 | 107 | 21 | +86 | 8 of 34 | 20 of 34 | +288 | +51 |
| **Opponent** | all armies | 36 | 156 | 552 | 3.9 | 1.2 | 143 | 30 | +113 | 58 of 139 | 86 of 139 | +188 | +100 |

### Charged fights: groups off

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 90 | 148 | 1.5 | 1.0 | 98 | 0 | +98 | 1 of 6 | 5 of 6 | - | +98 |
| Mine | Chaos Dwarfs | 4 | 149 | 308 | 2.5 | 1.0 | 123 | 31 | +92 | 8 of 10 | 6 of 10 | - | +92 |
| Mine | Dwarfen Mountain Holds | 4 | 307 | 132 | 1.2 | 1.0 | 105 | 133 | -28 | 0 of 5 | 4 of 5 | - | -28 |
| Mine | Empire of Man | 5 | 498 | 99 | 1.2 | 1.5 | 82 | 18 | +64 | 2 of 6 | 5 of 6 | +192 | +0 |
| Mine | Grand Cathay | 4 | 191 | 324 | 2.5 | 1.0 | 130 | 0 | +130 | 1 of 10 | 7 of 10 | - | +130 |
| Mine | High Elf Realms | 4 | 147 | 622 | 4.0 | 1.1 | 155 | 16 | +139 | 4 of 16 | 11 of 16 | +228 | +133 |
| Mine | Kingdom of Bretonnia | 1 | 0 | 0 | 4.0 | 1.2 | 0 | 171 | -171 | 2 of 4 | 2 of 4 | +0 | -228 |
| Mine | Lizardmen | 1 | 0 | 761 | 5.0 | 1.0 | 152 | 100 | +52 | 3 of 5 | 3 of 5 | - | +52 |
| Mine | Ogre Kingdoms | 1 | 0 | 0 | 4.0 | 1.0 | 0 | 17 | -17 | 1 of 4 | 3 of 4 | - | -17 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 714 | 5.0 | 1.0 | 143 | 79 | +64 | 1 of 5 | 5 of 5 | - | +64 |
| Mine | Skaven | 2 | 58 | 0 | 1.5 | 1.0 | 0 | 129 | -129 | 0 of 3 | 0 of 3 | - | -129 |
| Mine | Tomb Kings of Khemri | 1 | 239 | 1258 | 6.0 | 1.0 | 210 | 9 | +200 | 2 of 6 | 3 of 6 | - | +200 |
| Mine | Vampire Counts | 3 | 57 | 117 | 3.0 | 1.1 | 39 | 160 | -121 | 3 of 9 | 5 of 9 | +102 | -148 |
| Mine | Warriors of Chaos | 1 | 0 | 953 | 6.0 | 1.2 | 159 | 29 | +130 | 1 of 6 | 4 of 6 | +0 | +156 |
| **Mine** | all armies | 36 | 182 | 296 | 2.6 | 1.1 | 112 | 53 | +59 | 29 of 95 | 63 of 95 | +119 | +55 |
| Opponent | Dwarfen Mountain Holds | 2 | 111 | 118 | 2.5 | 1.0 | 47 | 33 | +14 | 0 of 5 | 1 of 5 | - | +14 |
| Opponent | Empire of Man | 2 | 530 | 160 | 3.0 | 1.2 | 54 | 38 | +16 | 1 of 6 | 5 of 6 | +0 | +19 |
| Opponent | Grand Cathay | 2 | 342 | 656 | 2.5 | 1.2 | 262 | 87 | +175 | 5 of 5 | 2 of 5 | +776 | +25 |
| Opponent | Kingdom of Bretonnia | 1 | 175 | 663 | 4.0 | 1.8 | 166 | 187 | -21 | 2 of 4 | 4 of 4 | -132 | +90 |
| Opponent | Ogre Kingdoms | 3 | 304 | 102 | 3.7 | 1.2 | 28 | 91 | -63 | 4 of 11 | 2 of 11 | -103 | -55 |
| Opponent | Skaven | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Tomb Kings of Khemri | 4 | 20 | 577 | 2.8 | 1.0 | 210 | 185 | +25 | 8 of 11 | 5 of 11 | - | +25 |
| Opponent | Vampire Counts | 6 | 34 | 485 | 4.5 | 1.1 | 108 | 43 | +65 | 11 of 27 | 15 of 27 | -56 | +74 |
| Opponent | Warriors of Chaos | 8 | 28 | 628 | 3.1 | 1.4 | 201 | 20 | +181 | 14 of 25 | 16 of 25 | +310 | +131 |
| Opponent | Wood Elf Realms | 7 | 18 | 540 | 4.4 | 1.1 | 122 | 16 | +106 | 10 of 31 | 17 of 31 | +107 | +105 |
| **Opponent** | all armies | 36 | 102 | 468 | 3.5 | 1.2 | 135 | 54 | +81 | 55 of 125 | 67 of 125 | +147 | +69 |


## Effective charges (55-75% to win the first round: just enough force)

### Effective charges: groups on

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 7 | 0 | 0 | 0 | 1 (net +0) | 1 (net +278) | 4 (net +189) | 1 | 0% (0 of 6) |
| Mine | Chaos Dwarfs | 14 | 1 (net +217) | 1 (net -309) | 1 (net +0) | 1 (net +0) | 2 (net +30) | 7 (net +106) | 1 | 8% (1 of 13) |
| Mine | Dwarfen Mountain Holds | 3 | 1 (net +0) | 0 | 0 | 0 | 0 | 2 (net +68) | 0 | 0% (0 of 3) |
| Mine | Empire of Man | 6 | 0 | 0 | 2 (net -28) | 1 (net -189) | 1 (net -350) | 2 (net -190) | 0 | 33% (2 of 6) |
| Mine | Grand Cathay | 14 | 0 | 0 | 2 (net +444) | 2 (net +106) | 3 (net +42) | 7 (net +97) | 0 | 14% (2 of 14) |
| Mine | High Elf Realms | 14 | 0 | 0 | 1 (net +0) | 2 (net +58) | 4 (net +303) | 6 (net +171) | 1 | 8% (1 of 13) |
| Mine | Kingdom of Bretonnia | 3 | 0 | 0 | 1 (net +0) | 1 (net +635) | 0 | 1 (net +98) | 0 | 33% (1 of 3) |
| Mine | Lizardmen | 4 | 2 (net +0) | 0 | 0 | 1 (net +186) | 1 (net +250) | 0 | 0 | 0% (0 of 4) |
| Mine | Ogre Kingdoms | 3 | 0 | 0 | 0 | 0 | 0 | 1 (net +0) | 2 | 0% (0 of 1) |
| Mine | Orc & Goblin Tribes | 5 | 1 (net +250) | 0 | 0 | 0 | 0 | 0 | 4 | 0% (0 of 1) |
| Mine | Skaven | 1 | 0 | 0 | 0 | 1 (net -112) | 0 | 0 | 0 | 0% (0 of 1) |
| Mine | Tomb Kings of Khemri | 7 | 0 | 0 | 2 (net -256) | 1 (net +125) | 0 | 3 (net +191) | 1 | 33% (2 of 6) |
| Mine | Vampire Counts | 19 | 6 (net -124) | 0 | 1 (net +0) | 5 (net +136) | 2 (net +118) | 4 (net +48) | 1 | 6% (1 of 18) |
| Mine | Warriors of Chaos | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +608) | 0 | 0% (0 of 1) |
| Opponent | Dwarfen Mountain Holds | 2 | 0 | 1 (net +0) | 0 | 0 | 0 | 1 (net +65) | 0 | 0% (0 of 2) |
| Opponent | Empire of Man | 2 | 0 | 0 | 0 | 1 (net +110) | 0 | 1 (net +110) | 0 | 0% (0 of 2) |
| Opponent | Grand Cathay | 9 | 4 (net +0) | 0 | 0 | 4 (net +189) | 0 | 1 (net +0) | 0 | 0% (0 of 9) |
| Opponent | Kingdom of Bretonnia | 3 | 0 | 1 (net +105) | 1 (net +120) | 1 (net -277) | 0 | 0 | 0 | 33% (1 of 3) |
| Opponent | Ogre Kingdoms | 10 | 2 (net +82) | 0 | 0 | 1 (net +170) | 0 | 2 (net +184) | 5 | 0% (0 of 5) |
| Opponent | Skaven | 2 | 0 | 0 | 0 | 0 | 1 (net +125) | 1 (net +0) | 0 | 0% (0 of 2) |
| Opponent | Tomb Kings of Khemri | 20 | 3 (net +214) | 0 | 3 (net +269) | 5 (net +39) | 1 (net +85) | 6 (net +242) | 2 | 17% (3 of 18) |
| Opponent | Vampire Counts | 26 | 3 (net +338) | 1 (net +0) | 3 (net +249) | 2 (net -134) | 5 (net +84) | 11 (net +179) | 1 | 12% (3 of 25) |
| Opponent | Warriors of Chaos | 31 | 2 (net -205) | 0 | 3 (net +239) | 5 (net +79) | 2 (net +30) | 17 (net +152) | 2 | 10% (3 of 29) |
| Opponent | Wood Elf Realms | 34 | 3 (net -44) | 0 | 3 (net +99) | 12 (net +77) | 2 (net +535) | 11 (net +23) | 3 | 10% (3 of 31) |

### Effective charges: groups off

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 6 | 0 | 0 | 0 | 0 | 1 (net +255) | 3 (net +92) | 2 | 0% (0 of 4) |
| Mine | Chaos Dwarfs | 10 | 4 (net +196) | 0 | 1 (net +0) | 1 (net -189) | 1 (net +60) | 3 (net +88) | 0 | 10% (1 of 10) |
| Mine | Dwarfen Mountain Holds | 5 | 0 | 0 | 0 | 0 | 0 | 5 (net -28) | 0 | 0% (0 of 5) |
| Mine | Empire of Man | 6 | 1 (net +0) | 0 | 0 | 0 | 2 (net +192) | 3 (net +0) | 0 | 0% (0 of 6) |
| Mine | Grand Cathay | 10 | 0 | 0 | 0 | 3 (net +98) | 1 (net +41) | 5 (net +192) | 1 | 0% (0 of 9) |
| Mine | High Elf Realms | 16 | 0 | 0 | 2 (net -58) | 1 (net +40) | 3 (net +280) | 6 (net +224) | 4 | 17% (2 of 12) |
| Mine | Kingdom of Bretonnia | 4 | 1 (net -471) | 0 | 0 | 0 | 0 | 2 (net -107) | 1 | 0% (0 of 3) |
| Mine | Lizardmen | 5 | 3 (net +254) | 0 | 1 (net +0) | 0 | 0 | 0 | 1 | 25% (1 of 4) |
| Mine | Ogre Kingdoms | 4 | 0 | 1 (net +0) | 0 | 0 | 0 | 1 (net +0) | 2 | 0% (0 of 2) |
| Mine | Orc & Goblin Tribes | 5 | 1 (net +250) | 0 | 0 | 0 | 0 | 0 | 4 | 0% (0 of 1) |
| Mine | Skaven | 3 | 1 (net -275) | 0 | 0 | 1 (net +0) | 0 | 1 (net -112) | 0 | 0% (0 of 3) |
| Mine | Tomb Kings of Khemri | 6 | 0 | 0 | 1 (net +102) | 1 (net +599) | 1 (net +0) | 3 (net +167) | 0 | 17% (1 of 6) |
| Mine | Vampire Counts | 9 | 1 (net -713) | 0 | 3 (net -225) | 1 (net -50) | 1 (net +102) | 2 (net +62) | 1 | 38% (3 of 8) |
| Mine | Warriors of Chaos | 6 | 0 | 0 | 0 | 0 | 0 | 4 (net +211) | 2 | 0% (0 of 4) |
| Opponent | Dwarfen Mountain Holds | 5 | 1 (net +65) | 0 | 0 | 2 (net +0) | 0 | 2 (net +2) | 0 | 0% (0 of 5) |
| Opponent | Empire of Man | 6 | 1 (net -227) | 0 | 2 (net +115) | 1 (net +91) | 1 (net +0) | 1 (net +0) | 0 | 33% (2 of 6) |
| Opponent | Grand Cathay | 5 | 3 (net -68) | 0 | 0 | 0 | 0 | 2 (net +540) | 0 | 0% (0 of 5) |
| Opponent | Kingdom of Bretonnia | 4 | 0 | 0 | 1 (net +120) | 1 (net +298) | 1 (net +60) | 1 (net -563) | 0 | 25% (1 of 4) |
| Opponent | Ogre Kingdoms | 11 | 3 (net +87) | 0 | 1 (net -702) | 1 (net -301) | 0 | 1 (net +0) | 5 | 17% (1 of 6) |
| Opponent | Tomb Kings of Khemri | 11 | 4 (net +63) | 0 | 0 | 3 (net +185) | 0 | 4 (net -134) | 0 | 0% (0 of 11) |
| Opponent | Vampire Counts | 27 | 8 (net -9) | 0 | 7 (net +169) | 3 (net -71) | 0 | 8 (net +106) | 1 | 27% (7 of 26) |
| Opponent | Warriors of Chaos | 25 | 1 (net +393) | 1 (net +392) | 2 (net +60) | 7 (net +108) | 2 (net +264) | 7 (net +311) | 5 | 10% (2 of 20) |
| Opponent | Wood Elf Realms | 31 | 3 (net -83) | 0 | 4 (net +128) | 11 (net +137) | 2 (net +64) | 9 (net +134) | 2 | 14% (4 of 29) |


## Charged fights by odds band, damage counted (Morten 2026-11-10)

### Charged fights, damage counted: groups on

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 11 | 147 | 201 | -25 | 62 | 81 | -19 | -12.9 |
| Mine | 50-54% | 1 | 120 | 480 | -309 | 0 | 309 | -309 | -257.5 |
| Mine | Effective (55-75%) | 10 | 347 | 332 | +32 | 116 | 90 | +27 | +7.7 |
| Mine | 76-89% | 16 | 257 | 173 | +103 | 124 | 34 | +90 | +35.0 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 38 | 245 | 182 | +117 | 168 | 42 | +126 | +51.4 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 14 | 562 | 107 | +129 | 165 | 47 | +118 | +21.0 |
| Mine | No odds | 11 | 228 | 222 | +32 | 145 | 77 | +67 | +29.4 |
| Mine | All fights | 101 | 287 | 195 | +79 | 140 | 57 | +83 | +28.8 |
| Opponent | Long shot (under 50%) | 17 | 239 | 279 | +75 | 167 | 63 | +104 | +43.5 |
| Opponent | 50-54% | 3 | 190 | 202 | +35 | 60 | 10 | +50 | +26.3 |
| Opponent | Effective (55-75%) | 13 | 328 | 199 | +207 | 212 | 28 | +184 | +55.9 |
| Opponent | 76-89% | 31 | 275 | 177 | +65 | 114 | 44 | +70 | +25.3 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 51 | 305 | 217 | +134 | 197 | 59 | +138 | +45.0 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 11 | 523 | 125 | +160 | 174 | 3 | +171 | +32.8 |
| Opponent | No odds | 13 | 209 | 172 | +85 | 113 | 47 | +66 | +31.6 |
| Opponent | All fights | 139 | 298 | 202 | +113 | 163 | 47 | +117 | +39.1 |

### Charged fights, damage counted: groups off

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 12 | 201 | 289 | +28 | 177 | 134 | +43 | +21.4 |
| Mine | 50-54% | 1 | 34 | 190 | +0 | 127 | 0 | +127 | +372.5 |
| Mine | Effective (55-75%) | 8 | 222 | 297 | -86 | 16 | 99 | -83 | -37.5 |
| Mine | 76-89% | 8 | 191 | 218 | +87 | 122 | 76 | +47 | +24.4 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 38 | 262 | 172 | +101 | 151 | 41 | +109 | +41.6 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 10 | 442 | 106 | +168 | 211 | 30 | +181 | +40.8 |
| Mine | No odds | 18 | 238 | 150 | -14 | 73 | 84 | -11 | -4.7 |
| Mine | All fights | 95 | 257 | 190 | +59 | 131 | 67 | +64 | +25.0 |
| Opponent | Long shot (under 50%) | 24 | 204 | 258 | +9 | 117 | 123 | -7 | -3.2 |
| Opponent | 50-54% | 1 | 494 | 197 | +392 | 392 | 0 | +392 | +79.4 |
| Opponent | Effective (55-75%) | 17 | 242 | 174 | +86 | 148 | 42 | +106 | +43.7 |
| Opponent | 76-89% | 29 | 268 | 192 | +93 | 155 | 45 | +110 | +41.0 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 35 | 314 | 208 | +120 | 216 | 96 | +120 | +38.3 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 6 | 583 | 110 | +120 | 120 | 17 | +102 | +17.5 |
| Opponent | No odds | 13 | 200 | 176 | +29 | 49 | 23 | +25 | +12.6 |
| Opponent | All fights | 125 | 275 | 201 | +81 | 153 | 70 | +83 | +30.2 |


## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| groups on | move | 482 | 111 (23%) | 81 (17%) | 61 (13%) | 310 (64%) |
| groups on | objective | 386 | 59 (15%) | 46 (12%) | 56 (15%) | 271 (70%) |
| groups off | move | 484 | 111 (23%) | 76 (16%) | 52 (11%) | 321 (66%) |
| groups off | objective | 383 | 57 (15%) | 39 (10%) | 54 (14%) | 272 (71%) |

## Combined arms (paper 2026-11-09, item 8)

### Combined arms: groups on (36 games)

| Side | Fights with 2+ chargers | Enemy charges answered by a counter-charge | Blocks with an escort in reach (end of Movement) | Screens that took the charge | Lanes opened (rule rows) / blocker gone that round |
| --- | --- | --- | --- | --- | --- |
| Mine | 11 of 101 (11%) | 16 of 163 (10%) | 188 of 362 (52%) | 0.39 per game | 0.11 / 0.06 per game |
| Opponent | 21 of 139 (15%) | 10 of 113 (9%) | 190 of 336 (57%) | 0.31 per game | 0.08 / 0.03 per game |

### Combined arms: groups off (36 games)

| Side | Fights with 2+ chargers | Enemy charges answered by a counter-charge | Blocks with an escort in reach (end of Movement) | Screens that took the charge | Lanes opened (rule rows) / blocker gone that round |
| --- | --- | --- | --- | --- | --- |
| Mine | 6 of 95 (6%) | 8 of 147 (5%) | 186 of 362 (51%) | 0.50 per game | 0.06 / 0.03 per game |
| Opponent | 19 of 125 (15%) | 5 of 102 (5%) | 189 of 345 (55%) | 0.33 per game | 0.06 / 0.06 per game |


## Quality by phase (per game and side)

| Phase | Number | A Mine | A Opponent | B Mine | B Opponent |
| --- | --- | --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.8 | 3.3 | 2.8 | 3.3 |
| Strategy | Charge objectives carried out (made contact) | 50% (63 of 125) | 49% (96 of 196) | 43% (52 of 121) | 48% (94 of 195) |
| Strategy | Shoot objectives carried out (shot that target) | 49% (168 of 343) | 55% (108 of 195) | 45% (151 of 334) | 50% (97 of 194) |
| Strategy | Close-in objectives charged next turn | 11% (16 of 152) | 18% (43 of 234) | 12% (21 of 174) | 17% (36 of 209) |
| Strategy | Support requests answered (helper made contact too) | 75% (9 of 12) | 56% (14 of 25) | 54% (7 of 13) | 50% (11 of 22) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 75% (3 of 4) | 100% (2 of 2) | 75% (3 of 4) | 100% (2 of 2) |
| Strategy | Hexes on a unit its side charged or shot that turn | 50% (7 of 14) | 76% (13 of 17) | 29% (4 of 14) | 58% (7 of 12) |
| Strategy | Joined characters whose unit fought | 63% (24 of 38) | 31% (11 of 35) | 57% (26 of 46) | 45% (13 of 29) |
| Strategy | Lone characters that fought | 84% (90 of 107) | 77% (68 of 88) | 77% (76 of 99) | 78% (73 of 94) |
| Movement | Charges halted short of contact | 0.1 | 0.3 | 0.1 | 0.5 |
| Movement | Idle units | 1.2 | 1.6 | 1.2 | 1.7 |
| Movement | Points that never moved of their own | 363.0 | 183.4 | 371.5 | 236.7 |
| Movement | Fights charged into per game | 2.8 | 3.9 | 2.6 | 3.5 |
| Movement | Charges with odds: long shots (under 50%) | 11 of 90, net -25 | 17 of 126, net +75 | 12 of 77, net +28 | 24 of 112, net +9 |
| Movement | Charges with odds: sweet spot (55-75%) | 10 of 90, net +32 | 13 of 126, net +207 | 8 of 77, net -86 | 17 of 112, net +86 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 14 of 90, net +129 | 11 of 126, net +160 | 10 of 77, net +168 | 6 of 112, net +120 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 38 of 90, net +117 | 51 of 126, net +134 | 38 of 77, net +101 | 35 of 112, net +120 |
| Shooting | Shots by shooting units (incl. breath weapons) | 9.1 | 10.2 | 9.3 | 10.1 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 50% (121 of 241) | 46% (38 of 83) | 58% (138 of 240) | 45% (34 of 75) |
| Shooting | Points destroyed by shooting units | 89.6 | 48.7 | 53.1 | 10.2 |
| Shooting | War machine shots | 6.7 | 2.3 | 6.7 | 2.1 |
| Shooting | Points destroyed by war machines | 71.8 | 57.7 | 76.8 | 65.5 |
| Magic | Magic missiles cast | 1.4 | 0.9 | 1.7 | 0.9 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 27% (14 of 52) | 65% (20 of 31) | 48% (29 of 61) | 58% (18 of 31) |
| Magic | Wounds caused by magic missiles | 2.9 | 1.4 | 2.0 | 0.9 |
| Magic | Wounds caused by other spells | 1.2 | 1.6 | 1.2 | 1.0 |
| Magic | Points destroyed by magic (all spells) | 53.6 | 49.4 | 52.1 | 26.8 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.9 / 0.5 / 0.7 / 0.1 | 2.1 / 0.5 / 0.6 / 0.1 | 0.8 / 0.4 / 0.7 / 0.0 | 1.7 / 0.3 / 0.4 / 0.1 |
| Combat | Points destroyed in combat | 316.1 | 471.0 | 395.4 | 435.8 |
| Combat | Points run down | 82.9 | 142.9 | 62.2 | 79.9 |
| Combat | Net points per charged fight, damage counted | +83 | +117 | +64 | +83 |
| Combat | Net per 100 charger points, damage counted | +28.8 | +39.1 | +25.0 | +30.2 |
| Combat | First round won (charged fights) | 72% | 62% | 66% | 54% |
| Combat | Net points per charged fight | +79 | +113 | +59 | +81 |
| Combat | Net points per supported fight / lone fight | +194 / +65 | +188 / +100 | +119 / +55 | +147 / +69 |
| Combat | Charged fights on a top-3 enemy unit | 39 of 101 | 58 of 139 | 29 of 95 | 55 of 125 |
| Game | Points lost | 926.1 | 700.6 | 816.2 | 726.6 |
| Game | VP from objectives | 468.6 | 634.2 | 503.9 | 621.4 |
| Game | Lone holders (player turns) | 1.1 | 2.7 | 1.8 | 2.2 |

A = groups on:
- Mine won / drew / lost: 8 / 10 / 18 of 36 ended games (of 36); mean margin (Mine - Opponent) -430 VP
- The side that went first won 15 of 26 games with a winner
- Points traded per game (both sides' losses): 1627
- Games not ended: 0; findings 0, warnings 0

B = groups off:
- Mine won / drew / lost: 14 / 7 / 15 of 36 ended games (of 36); mean margin (Mine - Opponent) -246 VP
- The side that went first won 19 of 29 games with a winner
- Points traded per game (both sides' losses): 1543
- Games not ended: 0; findings 0, warnings 1

## Opponent rules (fired a game, figure / won / lost VP a game)

| Rule | A Mine | A Opponent | B Mine | B Opponent |
| --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.6 (+0 / 0 / 0) | 0.6 (+0 / 0 / 0) | 0.6 (+0 / 0 / 0) | 0.6 (+0 / 0 / 0) |
| ALREADY CARRIED | 0.0 (+0 / 0 / 0) | - | 0.1 (+0 / 0 / 0) | - |
| ARRIVAL HUNT | - | 0.1 (+4 / 0 / 0) | 0.0 (+0 / 0 / 0) | 0.1 (+3 / 0 / 0) |
| ARTILLERY RE-ROLL WEIGHED | 1.6 (+0 / 0 / 29) | 0.2 (+0 / 0 / 0) | 1.9 (+0 / 0 / 38) | 0.4 (+0 / 0 / 0) |
| BACKUP TARGETS | 1.1 (+7 / 0 / 26) | 0.9 (+11 / 0 / 14) | 0.6 (+4 / 0 / 0) | 1.0 (+13 / 0 / 23) |
| BEST PREY | 4.3 (+247 / 169 / 144) | 5.4 (+368 / 255 / 181) | 4.3 (+238 / 137 / 136) | 4.9 (+325 / 300 / 104) |
| BEST PRIZE | 0.1 (-2 / 7 / 1) | 0.1 (-5 / 10 / 7) | 0.0 (-6 / 0 / 0) | 0.1 (+3 / 17 / 14) |
| BLOCKED CHARGE SKIPPED | 0.0 (+0 / 6 / 0) | 0.1 (+0 / 6 / 0) | 0.1 (+0 / 0 / 0) | 0.1 (+0 / 0 / 0) |
| BLOCKED WHEEL | 0.5 (+0 / 0 / 18) | 0.6 (-13 / 0 / 0) | 0.4 (+6 / 0 / 29) | 0.6 (+13 / 0 / 0) |
| BOMBING RUN | 0.0 (+1 / 0 / 0) | 0.0 (+1 / 0 / 0) | 0.1 (+2 / 0 / 0) | - |
| BOUND ASSAILMENT | 0.1 (+0 / 0 / 4) | - | 0.0 (+0 / 0 / 4) | - |
| CANNON PLAN MISSED | 0.9 (+0 / 168 / 26) | 0.2 (+0 / 41 / 0) | 0.8 (+0 / 94 / 11) | 0.3 (+0 / 24 / 0) |
| CANNON PLANNED TARGET | 5.4 (+139 / 467 / 99) | 2.0 (+137 / 185 / 25) | 5.2 (+143 / 345 / 107) | 1.6 (+104 / 184 / 9) |
| CANNON SIGHT KEPT | 1.3 (+0 / 0 / 2) | 0.5 (+0 / 0 / 0) | 1.3 (+0 / 0 / 2) | 0.5 (+0 / 0 / 0) |
| CAST JOB | 0.9 (+20 / 44 / 18) | 0.5 (+14 / 44 / 0) | 0.9 (+29 / 54 / 33) | 0.3 (+5 / 22 / 7) |
| CASTER AWAY FROM SCREEN | 0.2 (+0 / 0 / 0) | 0.1 (+0 / 0 / 0) | 0.2 (+0 / 0 / 0) | 0.1 (+0 / 0 / 0) |
| CASTING BLOCK | 0.4 (+23 / 32 / 20) | 0.2 (+9 / 11 / 4) | 0.4 (+23 / 20 / 8) | 0.2 (+7 / 8 / 0) |
| CASTS AFTER FRIENDS | 0.4 (+0 / 0 / 27) | 0.2 (+0 / 0 / 8) | 0.5 (+0 / 0 / 21) | 0.5 (+0 / 0 / 18) |
| CASTS FROM BEHIND | 0.1 (+0 / 0 / 0) | 0.3 (+0 / 0 / 0) | 0.1 (+0 / 0 / 0) | 0.3 (+0 / 0 / 0) |
| CATCH FLIERS | 0.1 (+3 / 0 / 0) | - | 0.0 (+0 / 0 / 0) | - |
| CATCH ODDS | - | - | 0.1 (+1 / 0 / 0) | - |
| CHAFF PASSED | 0.2 (-0 / 9 / 16) | 0.2 (-0 / 9 / 3) | 0.2 (-0 / 31 / 0) | 0.2 (-0 / 0 / 0) |
| CHARGE NOW WEIGHED | 0.4 (-20 / 18 / 16) | 0.7 (-29 / 20 / 17) | 0.5 (-36 / 23 / 14) | 0.8 (-66 / 30 / 43) |
| CHARIOT NO STATIC JOB | 0.8 (+0 / 19 / 11) | 0.5 (+0 / 0 / 2) | 0.9 (+0 / 12 / 16) | 0.6 (+0 / 2 / 4) |
| CHEAP HELPER | 0.0 (+0 / 0 / 0) | 0.2 (+0 / 5 / 0) | 0.1 (+0 / 0 / 0) | 0.2 (+0 / 19 / 3) |
| CONTINUE AHEAD WEIGHED | - | - | 0.0 (+0 / 3 / 0) | 0.0 (+0 / 0 / 0) |
| CONVEYANCE SEARCH | 0.4 (+29 / 2 / 16) | 0.5 (+55 / 6 / 28) | 0.5 (+57 / 16 / 24) | 0.6 (+38 / 8 / 35) |
| COUNTER-CHARGE COVER | 10.4 (+791 / 0 / 221) | 7.7 (+575 / 0 / 210) | - | - |
| EDGE GIVE GROUND | 0.2 (+11 / 12 / 0) | 0.3 (+4 / 36 / 0) | 0.2 (+6 / 11 / 5) | 0.3 (+11 / 49 / 0) |
| ELIXIR WORTH | - | - | 0.0 (+0 / 0 / 0) | - |
| ENGINEER BY LORE | 0.1 (+0 / 0 / 2) | - | 0.1 (+0 / 0 / 2) | - |
| ESCORT | 0.7 (+44 / 0 / 15) | 0.6 (+25 / 0 / 3) | - | - |
| FACES THE THREAT | 1.6 (+111 / 0 / 88) | 1.3 (+144 / 0 / 57) | 1.6 (+130 / 0 / 29) | 1.1 (+116 / 0 / 13) |
| FIGHT LIFT | 0.1 (+0 / 0 / 0) | 0.1 (+2 / 21 / 0) | 0.0 (+0 / 0 / 16) | 0.1 (+3 / 24 / 0) |
| FIRE AND FLEE | - | 0.1 (+2 / 8 / 13) | 0.0 (+0 / 0 / 0) | 0.1 (+1 / 0 / 3) |
| FOCUS FIRE | 0.1 (+6 / 8 / 2) | 0.0 (+1 / 0 / 0) | 0.0 (+1 / 0 / 0) | - |
| FOLLOW UP WEIGHED | 0.9 (+121 / 0 / 35) | 1.5 (+250 / 0 / 36) | 1.2 (+175 / 0 / 51) | 1.1 (+163 / 0 / 51) |
| FRIENDS SHOTS CHECKED | 0.1 (+6 / 0 / 0) | 0.1 (+19 / 0 / 3) | 0.2 (+12 / 0 / 7) | 0.1 (+7 / 0 / 0) |
| GATEWAY ESCAPE | - | - | - | 0.0 (+2 / 0 / 0) |
| GIVES UP | 1.1 (-25 / 118 / 48) | 1.8 (-57 / 243 / 91) | 0.9 (-25 / 75 / 9) | 1.5 (-44 / 147 / 64) |
| GIVES UP ITS SCREEN | 0.5 (-6 / 45 / 10) | 1.6 (-34 / 82 / 12) | 0.3 (-12 / 9 / 8) | 1.1 (-27 / 95 / 3) |
| GROUND FLIERS | - | - | 0.0 (+0 / 0 / 0) | - |
| GROUP AIM | 0.1 (+1 / 0 / 2) | 0.6 (+5 / 0 / 30) | - | - |
| GROUP BROKEN | 0.1 (+0 / 0 / 0) | 0.0 (+0 / 4 / 8) | - | - |
| HELPER ALREADY ASKED | - | 0.1 (+0 / 1 / 6) | - | 0.1 (+0 / 0 / 5) |
| HELPER UNSEEN | 0.2 (+0 / 12 / 0) | 0.3 (+0 / 9 / 11) | 0.2 (+0 / 9 / 12) | 0.4 (+0 / 11 / 14) |
| HOLDS AMBUSHERS | 0.4 (+0 / 0 / 0) | 0.7 (+0 / 0 / 0) | 0.4 (+0 / 0 / 0) | 0.7 (+0 / 0 / 0) |
| HORN WORTH | - | - | - | 0.0 (+1 / 0 / 0) |
| HUNT ADVANCE | 0.0 (+0 / 0 / 0) | 0.2 (+1 / 2 / 6) | 0.1 (+1 / 3 / 3) | 0.3 (+6 / 13 / 0) |
| HUNT DROPPED | 0.0 (+0 / 0 / 0) | 0.1 (+0 / 0 / 0) | 0.1 (+0 / 0 / 2) | 0.2 (+0 / 15 / 0) |
| HUNT IN PAIRS | 0.1 (+9 / 0 / 0) | 0.6 (+49 / 0 / 11) | - | - |
| HUNT KEPT | 0.0 (+0 / 3 / 1) | 0.1 (+2 / 23 / 2) | 0.0 (+0 / 0 / 0) | 0.1 (+4 / 27 / 0) |
| HUNT RESULT | 0.1 (+3 / 0 / 0) | 0.3 (+55 / 20 / 2) | 0.1 (+8 / 0 / 3) | 0.3 (+32 / 15 / 0) |
| HUNT THE GUNS | 0.1 (+9 / 3 / 1) | 0.3 (+152 / 9 / 10) | 0.1 (+31 / 3 / 4) | 0.3 (+143 / 22 / 0) |
| JOINT CHARGE PLAN | 0.1 (+7 / 0 / 0) | 0.2 (+4 / 0 / 0) | 0.1 (+8 / 0 / 0) | 0.1 (+2 / 0 / 1) |
| KEEPS ITS PREY | 0.3 (+3 / 0 / 33) | 0.1 (+1 / 5 / 5) | 0.1 (+1 / 0 / 0) | 0.3 (+5 / 11 / 28) |
| KEEPS ITS TARGET | 1.5 (+44 / 104 / 44) | 2.8 (+83 / 337 / 63) | 1.3 (+39 / 85 / 38) | 2.6 (+78 / 202 / 75) |
| KEEPS SCOUTS OR AMBUSH | 0.1 (+0 / 0 / 0) | 0.1 (+0 / 0 / 0) | 0.1 (+0 / 0 / 0) | 0.1 (+0 / 0 / 0) |
| KILLS COUNT | 1.3 (+64 / 124 / 31) | 1.9 (+93 / 146 / 37) | 1.5 (+73 / 68 / 62) | 2.0 (+75 / 182 / 8) |
| KILLS COUNT NEXT TURN | 7.8 (+284 / 340 / 255) | 11.3 (+508 / 623 / 332) | 7.6 (+271 / 276 / 204) | 10.9 (+489 / 571 / 219) |
| LONE CHARACTER SAFE SPOT | 0.5 (+24 / 6 / 39) | 0.4 (+12 / 18 / 8) | 0.6 (+23 / 21 / 25) | 0.3 (+7 / 0 / 6) |
| LONE WIZARD HOLDS BACK | 1.4 (+0 / 34 / 31) | 1.2 (+0 / 47 / 34) | 1.3 (+0 / 65 / 86) | 1.2 (+0 / 75 / 39) |
| LONE WIZARD KEPT IN | 0.6 (+39 / 0 / 0) | 0.3 (+24 / 0 / 0) | 0.6 (+39 / 0 / 0) | 0.3 (+24 / 0 / 0) |
| MAKE SURE TOGETHER | 0.8 (+33 / 10 / 15) | 1.6 (+89 / 63 / 44) | 0.3 (+28 / 8 / 1) | 1.0 (+66 / 64 / 32) |
| MANOEUVRE | 0.2 (+2 / 0 / 5) | 0.2 (+3 / 0 / 9) | 0.2 (+9 / 0 / 0) | 0.1 (+2 / 0 / 0) |
| MARCH AT ESCAPER | 0.1 (+1 / 0 / 0) | 0.2 (+1 / 0 / 4) | 0.1 (+3 / 0 / 4) | 0.1 (+0 / 0 / 0) |
| MARCH ODDS | 0.9 (+59 / 39 / 31) | 0.4 (+39 / 28 / 11) | 0.9 (+104 / 49 / 32) | 0.6 (+58 / 14 / 40) |
| MISSILES IN THE MOVE | 2.9 (+68 / 0 / 94) | 2.6 (+61 / 0 / 70) | 2.9 (+87 / 0 / 86) | 2.4 (+41 / 0 / 106) |
| MISSILES NEXT TURN | 4.4 (+69 / 0 / 158) | 3.6 (+45 / 0 / 74) | 4.4 (+76 / 0 / 119) | 3.2 (+40 / 0 / 95) |
| MODEL FACING | 0.2 (+45 / 0 / 7) | 0.3 (+85 / 0 / 0) | 0.4 (+89 / 0 / 5) | 0.1 (+28 / 0 / 2) |
| MOVE AND CAST | 0.2 (+11 / 0 / 4) | 0.1 (+4 / 0 / 0) | 0.1 (+2 / 0 / 0) | 0.0 (+1 / 0 / 0) |
| MOVE SPELL IN RANGE | 0.2 (+8 / 0 / 32) | 0.0 (+1 / 0 / 11) | 0.1 (+5 / 0 / 32) | - |
| MOVE SPELL OUT OF RANGE | 0.3 (-11 / 5 / 17) | 0.1 (-5 / 0 / 22) | 0.3 (-14 / 7 / 19) | 0.2 (-6 / 0 / 30) |
| MOVE SPELL SPOT | 0.2 (+0 / 0 / 13) | - | 0.4 (+0 / 0 / 11) | 0.1 (+0 / 0 / 10) |
| MOVES UNITS SPELL | 0.1 (+3 / 0 / 0) | - | 0.1 (+3 / 0 / 0) | - |
| NEEDED THERE | 0.1 (+16 / 9 / 0) | 0.1 (+20 / 6 / 0) | 0.0 (+9 / 6 / 0) | 0.1 (+3 / 3 / 0) |
| NO RALLY LEFT | 0.0 (+0 / 0 / 3) | - | 0.0 (+0 / 0 / 0) | - |
| NOT NEEDED | 0.2 (-18 / 52 / 2) | 0.2 (-10 / 25 / 0) | 0.1 (-15 / 3 / 0) | 0.3 (-18 / 34 / 0) |
| NOT TURNED | 10.9 (+79 / 0 / 312) | 10.1 (+136 / 0 / 170) | 10.6 (+62 / 0 / 227) | 8.8 (+63 / 0 / 172) |
| NOT WORTH A CAST | 0.6 (-0 / 0 / 12) | 0.6 (-1 / 0 / 0) | 0.4 (-0 / 0 / 59) | 0.6 (-1 / 0 / 0) |
| OPENS A LANE | 0.1 (+1 / 5 / 0) | 0.1 (+0 / 6 / 0) | 0.1 (+0 / 5 / 0) | 0.1 (+0 / 9 / 0) |
| OPENS UP | 0.1 (+12 / 8 / 0) | 0.2 (+25 / 8 / 5) | 0.1 (+6 / 6 / 0) | 0.3 (+28 / 17 / 14) |
| OVERRUNS AWAY | 0.6 (+9 / 39 / 18) | 0.5 (+3 / 63 / 22) | 0.6 (+16 / 66 / 20) | 0.7 (+15 / 59 / 40) |
| PATHS CROSS | 2.2 (+108 / 0 / 20) | 3.1 (+215 / 0 / 52) | 2.2 (+85 / 0 / 45) | 3.1 (+188 / 0 / 30) |
| PERIAPT WORTH | 0.0 (+3 / 0 / 0) | - | - | 0.0 (+3 / 0 / 15) |
| PLAN LEADS | 1.4 (+149 / 50 / 27) | 1.3 (+89 / 35 / 8) | 1.3 (+139 / 26 / 10) | 1.1 (+63 / 20 / 12) |
| PLAN RESULT | 36.5 (+1515 / 1372 / 1221) | 42.2 (+1420 / 1845 / 981) | 36.8 (+1233 / 1059 / 1073) | 40.6 (+1233 / 1486 / 949) |
| PURSUES BIG PREY | 0.1 (-4 / 0 / 9) | 0.2 (-10 / 0 / 0) | 0.1 (-2 / 0 / 0) | 0.2 (-12 / 0 / 13) |
| PURSUES ON | - | - | - | 0.0 (+0 / 0 / 0) |
| RAIDS THE BAGGAGE NEXT TURN | 0.1 (+4 / 0 / 0) | 0.0 (+2 / 0 / 0) | 0.0 (+2 / 0 / 0) | 0.1 (+6 / 0 / 3) |
| REDIRECT COUNTER | 3.6 (+120 / 0 / 53) | 5.3 (+288 / 0 / 47) | - | - |
| REDIRECT WEIGHED | 0.2 (+2 / 3 / 1) | 0.3 (+10 / 16 / 14) | 0.3 (+4 / 4 / 1) | 0.3 (+19 / 11 / 0) |
| RESTRAINS TO SHOOT | 0.1 (+5 / 0 / 0) | 0.1 (+5 / 0 / 5) | 0.1 (+5 / 0 / 0) | 0.1 (+1 / 0 / 3) |
| RISK BY ARC | 2.0 (+53 / 155 / 65) | 2.8 (+74 / 269 / 142) | 1.8 (+47 / 132 / 67) | 3.0 (+69 / 255 / 100) |
| SAFE SURE CHARGE | - | - | 0.0 (-0 / 11 / 0) | 0.0 (-2 / 5 / 0) |
| SAFER THAN THE JOB | 0.6 (+29 / 0 / 10) | 0.8 (+56 / 0 / 27) | 0.7 (+40 / 0 / 3) | 1.0 (+91 / 0 / 18) |
| SCOUT SPOT | 0.3 (+1 / 0 / 0) | 0.5 (+2 / 0 / 0) | 0.3 (+1 / 0 / 0) | 0.5 (+2 / 0 / 2) |
| SCOUT WAITS | 0.3 (+0 / 0 / 0) | 0.6 (+0 / 0 / 0) | 0.3 (+0 / 0 / 0) | 0.6 (+0 / 0 / 2) |
| SEARCH SPOT | 0.9 (+51 / 0 / 18) | 1.3 (+75 / 0 / 21) | 0.6 (+34 / 0 / 13) | 0.8 (+45 / 0 / 3) |
| SECOND HUNTER | - | 0.1 (-0 / 0 / 6) | 0.0 (-0 / 0 / 0) | 0.1 (-0 / 5 / 0) |
| SELF MOVE SPELL | 0.2 (+11 / 0 / 9) | - | 0.3 (+9 / 0 / 0) | - |
| SET UP TOGETHER | 1.1 (+36 / 10 / 32) | 2.7 (+127 / 71 / 67) | 0.5 (+40 / 18 / 1) | 1.7 (+112 / 77 / 41) |
| SHOOTERS IN TWO RANKS | 0.4 (+1 / 0 / 0) | 0.3 (+1 / 0 / 0) | 0.4 (+1 / 0 / 0) | 0.3 (+1 / 0 / 0) |
| SHORT GUN FORWARD | 0.2 (+0 / 0 / 0) | 0.2 (+0 / 0 / 0) | 0.2 (+0 / 0 / 0) | 0.2 (+0 / 0 / 0) |
| SHOT REPLANNED | 0.7 (+0 / 165 / 14) | 0.4 (+0 / 65 / 0) | 0.7 (+0 / 134 / 2) | 0.2 (+0 / 50 / 5) |
| SHOTS IN THE MOVE | 12.6 (+470 / 0 / 258) | 10.3 (+404 / 0 / 152) | 13.0 (+542 / 0 / 226) | 9.8 (+351 / 0 / 107) |
| SPELL CATCH ODDS | 0.1 (-1 / 0 / 0) | 0.0 (-0 / 0 / 0) | 0.1 (-1 / 5 / 3) | - |
| SPELL SETS UP CHARGE | 0.0 (+14 / 0 / 0) | 0.1 (+32 / 0 / 8) | 0.1 (+45 / 0 / 0) | 0.1 (+46 / 0 / 0) |
| SPELL WORTH | 0.7 (+14 / 75 / 67) | 1.9 (+40 / 101 / 80) | 0.6 (+13 / 115 / 107) | 1.7 (+31 / 134 / 98) |
| STANDS TO CAST | - | - | 0.1 (+2 / 0 / 0) | - |
| STOPS | 0.0 (+0 / 3 / 1) | 0.2 (+8 / 11 / 3) | 0.0 (+0 / 0 / 1) | 0.2 (+8 / 36 / 0) |
| STUCK PIVOT | 0.1 (+0 / 0 / 5) | 0.2 (+0 / 0 / 9) | 0.1 (+0 / 0 / 4) | 0.1 (+0 / 0 / 0) |
| SURE CHARGE BEATS ADVANCE | 0.1 (-3 / 1 / 0) | 0.2 (-10 / 35 / 0) | 0.1 (-2 / 0 / 0) | 0.2 (-6 / 28 / 15) |
| THROUGH LINE OF FIRE | 0.2 (+5 / 0 / 6) | 0.2 (+1 / 0 / 2) | 0.3 (+11 / 0 / 11) | 0.2 (+11 / 0 / 3) |
| TURN WORTH | 0.4 (-25 / 39 / 4) | 0.2 (-23 / 18 / 0) | 0.4 (-37 / 28 / 9) | 0.2 (-20 / 6 / 19) |
| TWO OR MORE ARRIVE | 0.2 (+5 / 0 / 4) | 0.8 (+12 / 38 / 9) | 0.2 (+6 / 18 / 1) | 0.7 (+13 / 43 / 1) |
| WEARS DOWN | 1.0 (+36 / 96 / 37) | 1.9 (+62 / 226 / 72) | 0.7 (+30 / 49 / 11) | 1.5 (+34 / 113 / 98) |
| WHO HITS BACK | 0.2 (+16 / 0 / 0) | 0.3 (+22 / 0 / 16) | 0.2 (+21 / 0 / 7) | 0.2 (+14 / 0 / 14) |
| WHOLE FIGHT | 0.2 (+1 / 13 / 18) | 0.5 (-42 / 105 / 20) | 0.3 (+7 / 47 / 22) | 0.5 (+7 / 32 / 20) |
| WHOLE FIGHT GAIN | 0.3 (+44 / 49 / 2) | 0.5 (+32 / 22 / 11) | 0.3 (+36 / 8 / 13) | 0.4 (+36 / 36 / 2) |

A = groups on, B = groups off.

## Rule changes (changed a game, VP a change)

| Rule | A | B |
| --- | --- | --- |
| ADVANCE LANE KEPT | 1.22 (+0.0) | 1.22 (+0.0) |
| ALREADY CARRIED | - | - |
| ARRIVAL HUNT | 0.00 (-) | 0.00 (-) |
| ARTILLERY RE-ROLL WEIGHED | 1.75 (+0.0) | 2.31 (+0.0) |
| BACKUP TARGETS | 0.08 (+8.3) | 0.03 (+15.7) |
| BEST PREY | 4.19 (+38.6) | 3.83 (+35.3) |
| BEST PRIZE | 0.17 (-106.1) | 0.08 (-194.1) |
| BLOCKED CHARGE SKIPPED | 0.11 (+0.0) | 0.11 (+0.0) |
| BLOCKED WHEEL | - | - |
| BOMBING RUN | 0.06 (+34.0) | 0.06 (+38.8) |
| BOUND ASSAILMENT | 0.06 (+0.1) | 0.03 (+0.1) |
| CANNON PLAN MISSED | 0.00 (-) | 0.00 (-) |
| CANNON PLANNED TARGET | 1.28 (-11.5) | 1.11 (-3.8) |
| CANNON SIGHT KEPT | 1.81 (+0.0) | 1.81 (+0.0) |
| CAST JOB | 0.67 (+23.1) | 0.53 (+21.9) |
| CASTER AWAY FROM SCREEN | 0.33 (+0.0) | 0.33 (+0.0) |
| CASTING BLOCK | 0.50 (+37.0) | 0.50 (+32.8) |
| CASTS AFTER FRIENDS | - | - |
| CASTS FROM BEHIND | 0.42 (+0.0) | 0.42 (+0.0) |
| CATCH FLIERS | - | - |
| CATCH ODDS | - | - |
| CHAFF PASSED | 0.36 (-1.6) | 0.33 (-1.0) |
| CHARGE NOW WEIGHED | 1.08 (+74.6) | 1.33 (+48.6) |
| CHARIOT NO STATIC JOB | 0.83 (-83.8) | 0.97 (-86.4) |
| CHEAP HELPER | - | - |
| CONTINUE AHEAD WEIGHED | - | 0.06 (+0.0) |
| CONVEYANCE SEARCH | - | - |
| COUNTER-CHARGE COVER | 2.14 (+42.9) | - |
| EDGE GIVE GROUND | 0.06 (+37.0) | 0.06 (+41.2) |
| ELIXIR WORTH | - | 0.03 (+11.3) |
| ENGINEER BY LORE | 0.00 (-) | 0.00 (-) |
| ESCORT | 0.03 (+41.6) | - |
| FACES THE THREAT | - | - |
| FIGHT LIFT | - | - |
| FIRE AND FLEE | 0.08 (+21.9) | 0.14 (+8.2) |
| FOCUS FIRE | 0.11 (+58.3) | 0.03 (+31.4) |
| FOLLOW UP WEIGHED | 2.36 (+157.2) | 2.25 (+150.1) |
| FRIENDS SHOTS CHECKED | 0.25 (+99.7) | 0.28 (+65.9) |
| GATEWAY ESCAPE | - | - |
| GIVES UP | 0.00 (-) | 0.00 (-) |
| GIVES UP ITS SCREEN | 0.06 (+23.5) | 0.00 (-) |
| GROUND FLIERS | - | - |
| GROUP AIM | 0.00 (-) | - |
| GROUP BROKEN | - | - |
| HELPER ALREADY ASKED | - | - |
| HELPER UNSEEN | 0.00 (-) | 0.00 (-) |
| HOLDS AMBUSHERS | 1.11 (+0.0) | 1.11 (+0.0) |
| HORN WORTH | - | 0.03 (+20.5) |
| HUNT ADVANCE | 0.00 (-) | 0.08 (+23.3) |
| HUNT DROPPED | - | - |
| HUNT IN PAIRS | 0.08 (+14.9) | - |
| HUNT KEPT | - | - |
| HUNT RESULT | - | - |
| HUNT THE GUNS | - | - |
| JOINT CHARGE PLAN | 0.08 (+25.0) | 0.00 (-) |
| KEEPS ITS PREY | 0.03 (+32.0) | 0.03 (+4.3) |
| KEEPS ITS TARGET | 0.89 (+16.4) | 0.97 (+18.0) |
| KEEPS SCOUTS OR AMBUSH | 0.11 (+0.0) | 0.11 (+0.0) |
| KILLS COUNT | 1.19 (+46.6) | 0.83 (+32.7) |
| KILLS COUNT NEXT TURN | 5.72 (+35.5) | 5.78 (+33.4) |
| LONE CHARACTER SAFE SPOT | - | - |
| LONE WIZARD HOLDS BACK | 1.11 (-49.2) | 1.03 (-44.4) |
| LONE WIZARD KEPT IN | 0.92 (+68.7) | 0.92 (+68.7) |
| MAKE SURE TOGETHER | 0.81 (+44.7) | 0.72 (+55.0) |
| MANOEUVRE | - | - |
| MARCH AT ESCAPER | - | - |
| MARCH ODDS | 1.19 (+31.4) | 1.14 (+37.3) |
| MISSILES IN THE MOVE | - | - |
| MISSILES NEXT TURN | 0.08 (+15.9) | 0.06 (+34.8) |
| MODEL FACING | 0.50 (+260.9) | 0.44 (+263.2) |
| MOVE AND CAST | - | - |
| MOVE SPELL IN RANGE | 0.00 (-) | 0.00 (-) |
| MOVE SPELL OUT OF RANGE | - | - |
| MOVE SPELL SPOT | - | - |
| MOVES UNITS SPELL | 0.11 (+30.4) | 0.11 (+30.4) |
| NEEDED THERE | 0.19 (+0.0) | 0.08 (+0.0) |
| NO RALLY LEFT | 0.03 (+3.8) | 0.03 (+2.4) |
| NOT NEEDED | 0.00 (-) | 0.00 (-) |
| NOT TURNED | 0.00 (-) | 0.00 (-) |
| NOT WORTH A CAST | - | - |
| OPENS A LANE | 0.08 (+5.6) | - |
| OPENS UP | 0.17 (+66.1) | 0.17 (+33.6) |
| OVERRUNS AWAY | 0.11 (+17.4) | 0.17 (+56.8) |
| PATHS CROSS | - | - |
| PERIAPT WORTH | 0.03 (+101.3) | 0.03 (+125.8) |
| PLAN LEADS | 1.11 (+52.3) | 0.97 (+49.5) |
| PLAN RESULT | - | - |
| PURSUES BIG PREY | 0.28 (-50.9) | 0.28 (-50.1) |
| PURSUES ON | - | 0.03 (+3.5) |
| RAIDS THE BAGGAGE NEXT TURN | 0.08 (+38.7) | 0.08 (+43.4) |
| REDIRECT COUNTER | 0.58 (+43.8) | - |
| REDIRECT WEIGHED | 0.50 (+27.1) | 0.61 (+52.2) |
| RESTRAINS TO SHOOT | 0.17 (+63.0) | 0.19 (+31.7) |
| RISK BY ARC | 1.25 (+24.7) | 0.81 (+35.1) |
| SAFE SURE CHARGE | - | 0.06 (-102.0) |
| SAFER THAN THE JOB | - | - |
| SCOUT SPOT | 0.00 (-) | 0.00 (-) |
| SCOUT WAITS | 0.89 (+0.0) | 0.89 (+0.0) |
| SEARCH SPOT | - | - |
| SECOND HUNTER | 0.00 (-) | 0.00 (-) |
| SELF MOVE SPELL | - | - |
| SET UP TOGETHER | 1.17 (+48.9) | 1.25 (+52.3) |
| SHOOTERS IN TWO RANKS | 0.69 (+2.0) | 0.69 (+2.0) |
| SHORT GUN FORWARD | 0.39 (+0.0) | 0.39 (+0.0) |
| SHOT REPLANNED | 1.14 (+0.0) | 0.92 (+0.0) |
| SHOTS IN THE MOVE | - | - |
| SPELL CATCH ODDS | - | - |
| SPELL SETS UP CHARGE | - | - |
| SPELL WORTH | - | - |
| STANDS TO CAST | - | 0.06 (+5.2) |
| STOPS | 0.00 (-) | 0.00 (-) |
| STUCK PIVOT | 0.33 (+0.0) | 0.19 (+0.0) |
| SURE CHARGE BEATS ADVANCE | 0.28 (-47.5) | 0.31 (-25.5) |
| THROUGH LINE OF FIRE | - | - |
| TURN WORTH | 0.00 (-) | 0.00 (-) |
| TWO OR MORE ARRIVE | 0.11 (+5.9) | 0.19 (+21.5) |
| WEARS DOWN | 0.58 (+34.6) | 0.22 (+19.9) |
| WHO HITS BACK | 0.50 (-52.3) | 0.42 (-57.9) |
| WHOLE FIGHT | 0.06 (+44.9) | 0.11 (+72.7) |
| WHOLE FIGHT GAIN | 0.47 (+39.3) | 0.47 (+49.1) |

A = groups on, B = groups off.

## Plans (happened, won of planned)

| Side | Plan | A | B |
| --- | --- | --- | --- |
| Mine | advance | 20% (72%) | 15% (60%) |
| Mine | charge | 59% (108%) | 55% (75%) |
| Mine | close in | 19% (45%) | 22% (41%) |
| Mine | hold | 34% (0%) | 38% (0%) |
| Mine | join | 84% (0%) | 93% (0%) |
| Mine | shoot | 66% (287%) | 65% (225%) |
| Mine | support | 87% (0%) | 91% (0%) |
| Opponent | advance | 19% (75%) | 19% (74%) |
| Opponent | charge | 61% (74%) | 48% (65%) |
| Opponent | close in | 28% (36%) | 24% (32%) |
| Opponent | hold | 40% (0%) | 41% (0%) |
| Opponent | join | 94% (0%) | 97% (0%) |
| Opponent | shoot | 64% (137%) | 64% (180%) |
| Opponent | support | 93% (0%) | 92% (0%) |

A = groups on, B = groups off.

## Packages: hunt the guns (per side)

| Batch | Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| A | Mine | 0.1 | 2 | 0 | 50% | 50% | 0% | 3.0 | 160 | 61 | 50% | 76 |
| A | Opponent | 0.3 | 12 | 0 | 33% | 50% | 0% | 2.7 | 457 | 164 | 50% | 64 |
| B | Mine | 0.1 | 4 | 0 | 0% | 25% | 0% | 2.0 | 277 | 68 | 25% | 47 |
| B | Opponent | 0.3 | 12 | 0 | 17% | 25% | 8% | 3.3 | 428 | 97 | 25% | 79 |

A = groups on, B = groups off.

### Battle groups: groups on

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 10.4 | 18% | 59% | 14% | 20% | 36% | 10% | 10% | 44% | 0% |
| Mine | REDIRECT COUNTER | 3.6 | 20% | 62% | 15% | 50% | 5% | 0% | 23% | 68% | 5% |
| Opponent | COUNTER-CHARGE COVER | 7.7 | 20% | 42% | 11% | 17% | 22% | 12% | 6% | 59% | 0% |
| Opponent | REDIRECT COUNTER | 5.3 | 13% | 72% | 28% | 0% | 11% | 0% | 22% | 56% | 11% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.1 | 5 | 0% | - |
| Opponent | 0.5 | 13 | 8% | 0% |

### Deployment: positions vs output by unit type: groups on

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 5 | 0 (5) | 0 | 0 | 32 | 20% | 5.8 | 0 (1) | 0 (3) | 0 (1) | 0 (3) | 0 (2) |
| Mine | Chaff | 44 | 45 (44) | 24 | 21 | 66 | 36% | 2.9 | 46 (24) | 0 (5) | 59 (15) | 59 (30) | 14 (14) |
| Mine | Character | 123 | 44 (123) | 44 | 0 | 46 | 14% | 2.5 | 54 (34) | 44 (61) | 42 (7) | 49 (61) | 46 (41) |
| Mine | Clean-up | 12 | 46 (12) | 6 | 40 | 68 | 33% | 3.4 | 18 (3) | 38 (6) | 101 (3) | 63 (7) | 23 (5) |
| Mine | Fast Hammer | 45 | 65 (45) | 48 | 17 | 51 | 22% | 3.0 | 55 (24) | 102 (10) | 46 (11) | 38 (31) | 131 (14) |
| Mine | Fragile | 5 | 36 (5) | 36 | 0 | 0 | 0% | 2.0 | - | 59 (3) | 0 (2) | 36 (5) | - |
| Mine | Hammer | 58 | 35 (58) | 23 | 12 | 52 | 22% | 2.7 | 8 (15) | 40 (33) | 63 (10) | 30 (38) | 43 (20) |
| Mine | Holder | 28 | 57 (28) | 10 | 48 | 48 | 43% | 3.2 | 26 (9) | 87 (13) | 45 (6) | 77 (17) | 30 (11) |
| Mine | Shooter | 43 | 75 (43) | 37 | 39 | 48 | 2% | 1.9 | 43 (7) | 86 (26) | 62 (10) | 93 (27) | 44 (16) |
| Mine | Support | 2 | 19 (2) | 19 | 0 | 0 | 50% | 2.0 | 0 (1) | 28 (1) | - | - | 19 (2) |
| Mine | War machine | 59 | 32 (59) | 32 | 0 | 57 | 3% | 1.3 | 3 (13) | 47 (36) | 4 (10) | 6 (10) | 37 (49) |
| Mine | Wizard | 22 | 20 (22) | 20 | 0 | 55 | 9% | 2.7 | 0 (4) | 48 (8) | 0 (3) | 46 (7) | 8 (8) |
| Opponent | Blocker | 2 | 0 (2) | 0 | 0 | 62 | 50% | 6.0 | 0 (2) | - | - | 0 (1) | 0 (1) |
| Opponent | Chaff | 89 | 39 (89) | 26 | 13 | 39 | 42% | 2.8 | 51 (35) | 2 (20) | 52 (34) | 47 (63) | 21 (26) |
| Opponent | Character | 94 | 76 (94) | 76 | 0 | 36 | 18% | 2.3 | 80 (42) | 94 (33) | 54 (7) | 90 (57) | 71 (25) |
| Opponent | Clean-up | 10 | 58 (10) | 31 | 28 | 54 | 20% | 3.0 | 48 (6) | 97 (3) | 0 (1) | 41 (7) | 112 (3) |
| Opponent | Early | 2 | 0 (2) | 0 | 0 | 50 | 50% | 5.0 | - | 0 (2) | - | 0 (2) | - |
| Opponent | Fast Hammer | 45 | 32 (45) | 19 | 12 | 41 | 29% | 3.2 | 13 (28) | 56 (8) | 67 (9) | 22 (28) | 51 (17) |
| Opponent | Fragile | 5 | 0 (5) | 0 | 0 | 0 | 40% | 2.7 | - | 0 (4) | 0 (1) | 0 (4) | 0 (1) |
| Opponent | Hammer | 69 | 40 (69) | 32 | 8 | 47 | 22% | 3.0 | 36 (19) | 40 (37) | 47 (13) | 45 (40) | 34 (29) |
| Opponent | Holder | 33 | 79 (33) | 17 | 61 | 8 | 36% | 3.2 | 31 (4) | 91 (22) | 58 (7) | 83 (19) | 73 (14) |
| Opponent | Shooter | 35 | 79 (35) | 10 | 69 | 36 | 0% | 1.9 | 20 (11) | 127 (17) | 36 (7) | 115 (23) | 24 (12) |
| Opponent | Support | 3 | 7 (3) | 7 | 0 | 0 | 0% | 5.3 | 0 (1) | 30 (1) | 0 (1) | - | 7 (3) |
| Opponent | War machine | 24 | 97 (24) | 97 | 0 | 28 | 4% | 2.0 | 35 (6) | 135 (15) | 30 (3) | 0 (2) | 106 (22) |
| Opponent | Wizard | 29 | 27 (29) | 22 | 5 | 40 | 3% | 1.5 | 17 (14) | 49 (9) | 0 (5) | 30 (14) | 27 (14) |

### Deployment: positions vs output by unit type: groups off

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 5 | 16 (5) | 16 | 0 | 52 | 20% | 3.0 | 0 (1) | 50 (1) | - | - | 33 (2) |
| Mine | Chaff | 44 | 57 (44) | 23 | 35 | 59 | 43% | 2.6 | 87 (24) | 0 (5) | 28 (15) | 74 (30) | 22 (14) |
| Mine | Character | 123 | 53 (123) | 53 | 0 | 46 | 16% | 2.4 | 65 (36) | 50 (57) | 64 (11) | 69 (61) | 40 (43) |
| Mine | Clean-up | 12 | 68 (12) | 6 | 62 | 54 | 25% | 3.6 | 60 (3) | 43 (6) | 151 (3) | 81 (7) | 52 (5) |
| Mine | Fast Hammer | 45 | 34 (45) | 22 | 12 | 51 | 24% | 2.9 | 41 (24) | 16 (10) | 37 (11) | 34 (31) | 34 (14) |
| Mine | Fragile | 5 | 0 (5) | 0 | 0 | 80 | 20% | 2.5 | - | 0 (3) | 0 (2) | 0 (5) | - |
| Mine | Hammer | 58 | 51 (58) | 36 | 15 | 36 | 22% | 2.6 | 20 (15) | 54 (33) | 94 (10) | 65 (38) | 29 (20) |
| Mine | Holder | 28 | 26 (28) | 0 | 26 | 43 | 43% | 3.7 | 12 (10) | 51 (12) | 4 (5) | 32 (18) | 19 (9) |
| Mine | Shooter | 43 | 75 (43) | 26 | 49 | 40 | 0% | 1.7 | 78 (7) | 93 (26) | 23 (10) | 102 (27) | 27 (16) |
| Mine | Support | 2 | 0 (2) | 0 | 0 | 0 | 50% | 2.0 | 0 (1) | 0 (1) | - | 0 (2) | - |
| Mine | War machine | 59 | 40 (59) | 40 | 0 | 48 | 2% | 1.3 | 10 (13) | 50 (36) | 34 (10) | 12 (10) | 45 (49) |
| Mine | Wizard | 22 | 26 (22) | 26 | 0 | 31 | 5% | 3.1 | 1 (8) | 72 (8) | 0 (3) | 49 (10) | 3 (9) |
| Opponent | Blocker | 2 | 0 (2) | 0 | 0 | 0 | 100% | - | 0 (1) | 0 (1) | - | 0 (1) | 0 (1) |
| Opponent | Chaff | 89 | 61 (89) | 30 | 31 | 38 | 39% | 2.7 | 68 (35) | 51 (20) | 62 (34) | 69 (63) | 43 (26) |
| Opponent | Character | 94 | 67 (94) | 66 | 1 | 38 | 18% | 2.3 | 90 (46) | 51 (31) | 34 (6) | 72 (59) | 75 (24) |
| Opponent | Clean-up | 10 | 28 (10) | 13 | 16 | 38 | 50% | 2.2 | 11 (6) | 75 (3) | 0 (1) | 17 (7) | 63 (3) |
| Opponent | Early | 2 | 0 (2) | 0 | 0 | 0 | 0% | 6.0 | - | 0 (2) | - | 0 (2) | - |
| Opponent | Fast Hammer | 45 | 34 (45) | 22 | 12 | 31 | 27% | 3.2 | 16 (28) | 46 (8) | 86 (9) | 27 (28) | 49 (17) |
| Opponent | Fragile | 5 | 0 (5) | 0 | 0 | 61 | 20% | 3.2 | - | 0 (3) | 0 (2) | 0 (4) | 0 (1) |
| Opponent | Hammer | 69 | 37 (69) | 31 | 6 | 52 | 22% | 2.9 | 32 (19) | 44 (37) | 12 (13) | 26 (40) | 51 (29) |
| Opponent | Holder | 33 | 58 (33) | 3 | 55 | 25 | 33% | 3.6 | 79 (7) | 55 (24) | 0 (1) | 71 (17) | 45 (15) |
| Opponent | Shooter | 35 | 60 (35) | 5 | 56 | 37 | 0% | 1.9 | 37 (11) | 84 (17) | 30 (7) | 91 (23) | 13 (12) |
| Opponent | Support | 3 | 20 (3) | 20 | 0 | 0 | 67% | 5.0 | 0 (1) | 40 (2) | - | 0 (1) | 40 (2) |
| Opponent | War machine | 24 | 59 (24) | 59 | 0 | 16 | 8% | 2.0 | 18 (6) | 81 (15) | 30 (3) | 0 (2) | 65 (22) |
| Opponent | Wizard | 29 | 19 (29) | 19 | 0 | 58 | 3% | 1.5 | 5 (10) | 38 (8) | 0 (3) | 28 (9) | 15 (12) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0106, L0122, L2429, L2535, L2735 |
| Charmed Shield | Opponent | L0425, L0827, L0934, L1026, L1727, L1827, L1927 |
| Clockwork Compass | Mine | L1228 |
| Clockwork Compass | Opponent | L0512 |
| Elixir of Power | Mine | L1118, L1135, L1927 |
| Fistful of Laurels | Mine | L1827 |
| Fistful of Laurels | Opponent | L0918, L1118, L1418 |
| Horn of the Wild Hunt | Opponent | L3033 |
| Invocation of Nehek | Mine | L2429, L2535, L2735 |
| Invocation of Nehek | Opponent | L0425, L0827, L1727, L1827, L1927 |
| Opal Amulet | Mine | L1418, L1435 |
| Periapt of Soul Exchange | Mine | L2029, L2131 |
| Periapt of Soul Exchange | Opponent | L0721 |
| Ring of Doom | Mine | L0206, L0222, L1118, L1135, L1228, L1531 |
| Ring of Doom | Opponent | L0512, L1531, L2131, L3033 |
| Ring of Jet | Mine | L1026, L1118, L1135, L1228 |
| Ring of Jet | Opponent | L0512, L0810 |
| Standard of the Fell Warrior | Mine | L1323 |
| Storm Daemon (Renegade 2.0) | Mine | L2131 |
| Storm Daemon (Renegade 2.0) | Opponent | L0721 |
| Twice-Blessed Armour | Mine | L0721, L1026 |
| Twice-Blessed Armour | Opponent | L0307, L0810 |
| Witch Hunter's Ward | Mine | L0721, L0810, L0827 |
| Witch Hunter's Ward | Opponent | L0307 |

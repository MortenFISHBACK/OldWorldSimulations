# groups on vs groups off

A = groups on: on-3, 36 of 36 games ended
B = groups off: off-3, 36 of 36 games ended

## Game by game (Victory Points Mine-Opponent; margin = Mine minus Opponent)

| Match-up | Scenario | Seed | A | B | Margin A | Margin B | A minus B | Cost A | Cost B |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0110 | 2 | 1 | Opponent 1394-1737 | Opponent 381-2514 | -343 | -2133 | +1790 | 0.00 | 0.00 |
| L0126 | 6 | 1 | Opponent 1285-2011 | Opponent 1105-1695 | -726 | -590 | -136 | 0.00 | 0.00 |
| L0210 | 6 | 1 | Opponent 687-1008 | draw 1055-1057 | -321 | -2 | -319 | 0.00 | 0.00 |
| L0226 | 4 | 1 | Opponent 295-1377 | Mine 2580-625 | -1082 | +1955 | -3037 | 0.00 | 0.00 |
| L0311 | 5 | 1 | Mine 1484-1011 | Opponent 165-2431 | +473 | -2266 | +2739 | 0.00 | 0.00 |
| L0327 | 3 | 1 | Opponent 676-1169 | Opponent 1192-2008 | -493 | -816 | +323 | 0.00 | 0.00 |
| L0413 | 5 | 1 | Mine 1990-212 | Mine 1813-522 | +1778 | +1291 | +487 | 0.00 | 0.00 |
| L0429 | 3 | 1 | Mine 2339-1626 | Mine 2107-912 | +713 | +1195 | -482 | 0.00 | 0.00 |
| L0516 | 6 | 1 | Mine 1717-605 | Mine 1375-1003 | +1112 | +372 | +740 | 0.00 | 0.00 |
| L0533 | 5 | 1 | Mine 1188-485 | Mine 1288-432 | +703 | +856 | -153 | 0.00 | 0.00 |
| L0620 | 2 | 1 | Mine 1770-805 | Opponent 931-1511 | +965 | -580 | +1545 | 0.00 | 0.00 |
| L0709 | 1 | 1 | Opponent 1121-2022 | Opponent 1749-2178 | -901 | -429 | -472 | 0.00 | 0.00 |
| L0725 | 5 | 1 | Opponent 478-1818 | draw 638-714 | -1340 | -76 | -1264 | 0.00 | 0.00 |
| L0815 | 5 | 1 | Opponent 670-2628 | draw 1735-1517 | -1958 | +218 | -2176 | 0.00 | 0.00 |
| L0831 | 3 | 1 | Mine 1570-647 | Mine 1570-647 | +923 | +923 | +0 | 0.00 | 0.00 |
| L0922 | 4 | 1 | Opponent 1222-1665 | Opponent 693-3374 | -443 | -2681 | +2238 | 0.00 | 0.00 |
| L1013 | 5 | 1 | Mine 1969-967 | Mine 2458-330 | +1002 | +2128 | -1126 | 0.00 | 0.00 |
| L1030 | 4 | 1 | Mine 1253-822 | Mine 1744-680 | +431 | +1064 | -633 | 0.00 | 0.00 |
| L1122 | 6 | 1 | draw 1654-1612 | Mine 1522-1035 | +42 | +487 | -445 | 0.00 | 0.00 |
| L1216 | 4 | 1 | Mine 2255-400 | Mine 1800-833 | +1855 | +967 | +888 | 0.00 | 0.00 |
| L1232 | 2 | 1 | Opponent 215-1236 | draw 1234-1309 | -1021 | -75 | -946 | 0.00 | 0.00 |
| L1327 | 1 | 1 | Mine 1595-1052 | Mine 1767-1152 | +543 | +615 | -72 | 0.00 | 0.00 |
| L1422 | 6 | 1 | Opponent 901-1919 | Mine 1773-769 | -1018 | +1004 | -2022 | 0.00 | 0.00 |
| L1519 | 1 | 1 | Mine 2733-630 | draw 1254-1033 | +2103 | +221 | +1882 | 0.00 | 0.00 |
| L1535 | 5 | 1 | Mine 2535-768 | Mine 2057-301 | +1767 | +1756 | +11 | 0.00 | 0.00 |
| L1633 | 1 | 1 | Mine 2544-692 | Mine 2414-873 | +1852 | +1541 | +311 | 0.00 | 0.00 |
| L1731 | 3 | 1 | Mine 2243-1251 | Mine 1996-930 | +992 | +1066 | -74 | 0.00 | 0.00 |
| L1831 | 1 | 1 | Mine 2000-1382 | Mine 2557-1079 | +618 | +1478 | -860 | 0.00 | 0.00 |
| L1932 | 6 | 1 | Opponent 915-2230 | draw 1245-1453 | -1315 | -208 | -1107 | 0.00 | 0.00 |
| L2033 | 5 | 1 | draw 669-798 | Opponent 924-1370 | -129 | -446 | +317 | 0.00 | 0.00 |
| L2223 | 3 | 1 | Mine 1772-1128 | draw 1648-1598 | +644 | +50 | +594 | 0.00 | 0.00 |
| L2327 | 5 | 1 | draw 1384-1480 | Mine 2107-432 | -96 | +1675 | -1771 | 0.00 | 0.00 |
| L2433 | 3 | 1 | Mine 2287-371 | Mine 2654-864 | +1916 | +1790 | +126 | 0.00 | 0.00 |
| L2630 | 2 | 1 | draw 1143-1324 | Mine 1900-705 | -181 | +1195 | -1376 | 0.00 | 0.00 |
| L2832 | 6 | 1 | Opponent 418-2223 | Opponent 1523-2329 | -1805 | -806 | -999 | 0.00 | 0.00 |
| L3133 | 1 | 1 | Opponent 662-1725 | Mine 2598-471 | -1063 | +2127 | -3190 | 0.00 | 0.00 |

## Totals

| | A: groups on | B: groups off |
| --- | --- | --- |
| Mine won / drew / lost | 18 / 4 / 14 | 20 / 7 / 9 |
| Mean margin (Mine - Opponent) | +172 | +413 |
| Cost per game | $0.000 | $0.000 |
| Mine side per game | $0.000 | $0.000 |
| Opponent side per game | $0.000 | $0.000 |
| Cost of the batch | $0.00 | $0.00 |
| Failed calls per game | 0.0 | 0.0 |
| VP from objectives, Mine | 587 | 664 |
| VP from objectives, Opponent | 494 | 511 |
| VP from kills, Mine | 780 | 871 |
| VP from kills, Opponent | 687 | 626 |
| VP from leaders, Mine | 50 | 64 |
| VP from leaders, Opponent | 61 | 47 |
| VP from other, Mine | 0 | 0 |
| VP from other, Opponent | 3 | 1 |
| Units lost, Mine | 4.2 | 4.2 |
| Units lost, Opponent | 4.8 | 5.2 |
| Scorecard: Far marker / quarter contested by round 3 (both sides) | 27% | 28% |
| Scorecard: Lone holders (player turns) (both sides) | 3.0 | 2.9 |
| Scorecard: Round of the first Hammer charge (both sides) | 2.7 | 2.5 |
| Scorecard: Lone charges into a block / monster / character (both sides) | 2.6 | 2.3 |
| Scorecard: Idle units (both sides) | 1.5 | 1.6 |
| Scorecard: Wounded Lords / monsters lost (both sides) | 0.4 | 0.3 |
| Scorecard: Doctrine flags raised (both sides) | 0.0 | 0.0 |
| Scorecard: Answers changed after a flag (both sides) | 0.0 | 0.0 |
| Scorecard: Points that never moved of their own (both sides) | 246.6 | 250.1 |

## Is the difference more than noise?

36 pairs of games: A's margin is -241 VP a game against B's, give or take 447 VP (two standard errors). Verdict: within noise (could be chance).

## KPIs (Morten 2026-11-10)

A = groups on (36 games), B = groups off (36 games).

| KPI | Target | A Mine | A Opponent | A both | B Mine | B Opponent | B both |
| --- | --- | --- | --- | --- | --- | --- | --- |
| Winner chose to follow up after the loser gave ground |  | 85%; on the table 88% | 100%; on the table 100% | 92%; on the table 94% | 91%; on the table 91% | 100%; on the table 100% | 95%; on the table 95% |
| Winner chose to pursue after the loser fell back in good order |  | 69%; on the table 85% | 93%; on the table 93% | 82%; on the table 89% | 92%; on the table 92% | 85%; on the table 92% | 88%; on the table 92% |
| Winner chose to pursue after the loser fled |  | 67%; on the table 79% | 48%; on the table 52% | 60%; on the table 69% | 79%; on the table 82% | 64%; on the table 68% | 73%; on the table 76% |
| Winner chose to follow up or pursue (all three) |  | 77%; on the table 84% | 86%; on the table 87% | 81%; on the table 86% | 88%; on the table 89% | 88%; on the table 91% | 88%; on the table 90% |
| Magic missiles tried each own turn | 50%+ | 20% | 22% | 21% | 26% | 27% | 26% |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 32% | 29% | 31% | 38% | 33% | 36% |
| Points that never fought | lower | 37% | 39% | 38% | 42% | 37% | 39% |
|   infantry points that never fought | lower | 48% | 50% | 49% | 49% | 52% | 50% |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 55% | 60% | 58% | 56% | 62% | 59% |
| Bound items with a magic missile used (at least once a game) |  | 88% | 75% | 82% | 88% | 71% | 80% |
| Bound items with another spell used |  | 57% | 0% | 40% | 36% | 83% | 50% |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 45% | 21% | 35% | 40% | 29% | 35% |
|   their share of the points of units over 100 pts | lower | 47% | 54% | 51% | 49% | 56% | 53% |

Flank and rear charges a unit could have turned to face (the side is the charged unit's):

| Measure | groups on Mine | groups on Opponent | groups off Mine | groups off Opponent |
| --- | --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 59% (51) | 49% (40) | 46% (30) | 44% (40) |
| ...free all their last turn and able to turn (per game) | 0.97 | 0.75 | 0.47 | 0.83 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.17 | 0.17 | 0.22 | 0.14 |
| ...with the charger already in that arc before they moved (per game) | 0.61 | 0.53 | 0.28 | 0.64 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 1.33 | 1.33 | 1.36 | 1.06 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.50 | 0.47 | 1.19 | 0.92 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 11.75 | 10.75 | 10.39 | 10.03 |

### Charges a game and per unit by the wizard it carries

| Charges | A Mine | A Opponent | A both | B Mine | B Opponent | B both |
| --- | --- | --- | --- | --- | --- | --- |
| Charges declared a game | 4.2 | 5.7 | 5.0 | 4.8 | 4.7 | 4.7 |
| Charges that made contact a game | 3.4 | 4.1 | 3.8 | 3.8 | 3.3 | 3.5 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.08 declared, 0.92 contact (25 units) | 0.95 declared, 0.65 contact (20 units) | 1.02 declared, 0.80 contact (45 units) | 1.12 declared, 0.88 contact (25 units) | 0.84 declared, 0.63 contact (19 units) | 1.00 declared, 0.77 contact (44 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.67 declared, 0.33 contact (3 units) | 1.50 declared, 1.20 contact (10 units) | 1.31 declared, 1.00 contact (13 units) | 0.50 declared, 0.50 contact (2 units) | 1.27 declared, 0.73 contact (11 units) | 1.15 declared, 0.69 contact (13 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.55 declared, 0.45 contact (221 units) | 0.65 declared, 0.46 contact (265 units) | 0.60 declared, 0.46 contact (486 units) | 0.64 declared, 0.50 contact (223 units) | 0.52 declared, 0.37 contact (269 units) | 0.57 declared, 0.43 contact (492 units) |

## Movement (Morten 2026-11-11)

A = groups on (36 games), B = groups off (36 games); per side and game.

| Measure | A Mine | A Opponent | A both | B Mine | B Opponent | B both |
| --- | --- | --- | --- | --- | --- | --- |
| Games where this side made the first charge contact | 44% (16 of 36) | 56% (20 of 36) | 50% (36 of 72) | 53% (19 of 36) | 47% (17 of 36) | 50% (36 of 72) |
| Round of a side's first charge contact (sides that made one) | 2.8 | 2.6 | 2.7 | 2.5 | 2.7 | 2.6 |
| Sides that never declared a charge | 14% (5 of 36) | 0% (0 of 36) | 7% (5 of 72) | 11% (4 of 36) | 3% (1 of 36) | 7% (5 of 72) |
| Sides that never made charge contact | 17% (6 of 36) | 6% (2 of 36) | 11% (8 of 72) | 11% (4 of 36) | 6% (2 of 36) | 8% (6 of 72) |
| Charges declared a game | 4.3 | 5.6 | 5.0 | 4.9 | 4.6 | 4.7 |
| Charge contacts made a game | 3.5 | 4.0 | 3.8 | 3.8 | 3.2 | 3.5 |
| Charge contacts received a game | 4.0 | 3.5 | 3.8 | 3.2 | 3.8 | 3.5 |
| Joint charges a game (2+ units on one target in one turn) | 0.4 | 0.6 | 0.5 | 0.4 | 0.4 | 0.4 |
|   share of charged targets hit by 2+ units | 13% (15 of 112) | 16% (20 of 122) | 15% (35 of 234) | 12% (14 of 121) | 14% (14 of 102) | 13% (28 of 223) |
| Lone charges that a friend follows on the same target next turn | 7% (7 of 97) | 8% (8 of 102) | 8% (15 of 199) | 0% (0 of 107) | 7% (6 of 88) | 3% (6 of 195) |
| Set-ups (close in to charge next turn) that charged that target next turn | 15% (29 of 195) | 15% (34 of 229) | 15% (63 of 424) | 13% (24 of 184) | 11% (25 of 227) | 12% (49 of 411) |
|   ... and made contact | 13% (25 of 195) | 10% (24 of 229) | 12% (49 of 424) | 11% (21 of 184) | 7% (17 of 227) | 9% (38 of 411) |
|   ... with a friend on it too | 3% (5 of 195) | 3% (8 of 229) | 3% (13 of 424) | 2% (4 of 184) | 2% (5 of 227) | 2% (9 of 411) |
| Set-ups missed (no charge on that target next turn) | 85% (166 of 195) | 85% (195 of 229) | 85% (361 of 424) | 87% (160 of 184) | 89% (202 of 227) | 88% (362 of 411) |
| Charge contacts in the flank or rear (arc known) | 54% (69 of 127) | 59% (85 of 144) | 57% (154 of 271) | 49% (67 of 138) | 54% (63 of 117) | 51% (130 of 255) |
|   in the rear | 7% (9 of 127) | 10% (15 of 144) | 9% (24 of 271) | 7% (9 of 138) | 9% (10 of 117) | 7% (19 of 255) |
| Declared charges in the flank or rear (arc known) | 48% (75 of 155) | 57% (116 of 202) | 54% (191 of 357) | 48% (84 of 175) | 52% (87 of 166) | 50% (171 of 341) |

## Doctrine scorecard (per game and side; far = share of games contested)

### Scorecard: groups on

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0110 | 2 | 1 | Mine | - | - | 1 | 3 | 2 | 0 | 0 | 0 | 322 |
| L0110 | 2 | 1 | Opponent | - | - | 2 | 1 | 0 | 0 | 0 | 0 | 330 |
| L0126 | 6 | 1 | Mine | no | 6 | - | 0 | 2 | 0 | 0 | 0 | 387 |
| L0126 | 6 | 1 | Opponent | no | 9 | 2 | 2 | 3 | 1 | 0 | 0 | 0 |
| L0210 | 6 | 1 | Mine | no | 4 | - | 0 | 4 | 0 | 0 | 0 | 0 |
| L0210 | 6 | 1 | Opponent | no | 3 | 3 | 1 | 1 | 0 | 0 | 0 | 330 |
| L0226 | 4 | 1 | Mine | no | 0 | - | 0 | 2 | 1 | 0 | 0 | 306 |
| L0226 | 4 | 1 | Opponent | no | 6 | 2 | 4 | 3 | 0 | 0 | 0 | 0 |
| L0311 | 5 | 1 | Mine | no | - | 2 | 0 | 1 | 0 | 0 | 0 | 760 |
| L0311 | 5 | 1 | Opponent | yes | - | - | 1 | 1 | 1 | 0 | 0 | 330 |
| L0327 | 3 | 1 | Mine | no | 5 | 6 | 2 | 0 | 0 | 0 | 0 | 760 |
| L0327 | 3 | 1 | Opponent | no | 0 | 2 | 3 | 4 | 0 | 0 | 0 | 0 |
| L0413 | 5 | 1 | Mine | yes | - | 2 | 3 | 2 | 0 | 0 | 0 | 0 |
| L0413 | 5 | 1 | Opponent | no | - | - | 2 | 2 | 1 | 0 | 0 | 317 |
| L0429 | 3 | 1 | Mine | yes | 13 | 2 | 4 | 1 | 1 | 0 | 0 | 0 |
| L0429 | 3 | 1 | Opponent | no | 4 | 2 | 2 | 0 | 1 | 0 | 0 | 170 |
| L0516 | 6 | 1 | Mine | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 475 |
| L0516 | 6 | 1 | Opponent | no | 2 | 2 | 3 | 2 | 2 | 0 | 0 | 280 |
| L0533 | 5 | 1 | Mine | no | - | 6 | 0 | 2 | 0 | 0 | 0 | 548 |
| L0533 | 5 | 1 | Opponent | yes | - | 6 | 0 | 7 | 0 | 0 | 0 | 0 |
| L0620 | 2 | 1 | Mine | - | - | 3 | 5 | 1 | 0 | 0 | 0 | 615 |
| L0620 | 2 | 1 | Opponent | - | - | - | 1 | 4 | 0 | 0 | 0 | 95 |
| L0709 | 1 | 1 | Mine | yes | 0 | 2 | 2 | 1 | 1 | 0 | 0 | 558 |
| L0709 | 1 | 1 | Opponent | no | 0 | 3 | 1 | 0 | 0 | 0 | 0 | 420 |
| L0725 | 5 | 1 | Mine | no | - | - | 1 | 2 | 0 | 0 | 0 | 375 |
| L0725 | 5 | 1 | Opponent | yes | - | 2 | 3 | 4 | 0 | 0 | 0 | 75 |
| L0815 | 5 | 1 | Mine | no | - | 5 | 1 | 1 | 0 | 0 | 0 | 762 |
| L0815 | 5 | 1 | Opponent | yes | - | 3 | 3 | 2 | 1 | 0 | 0 | 0 |
| L0831 | 3 | 1 | Mine | yes | 3 | 2 | 0 | 1 | 0 | 0 | 0 | 605 |
| L0831 | 3 | 1 | Opponent | no | 4 | - | 1 | 3 | 2 | 0 | 0 | 340 |
| L0922 | 4 | 1 | Mine | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 596 |
| L0922 | 4 | 1 | Opponent | no | 1 | 3 | 3 | 1 | 2 | 0 | 0 | 0 |
| L1013 | 5 | 1 | Mine | yes | - | 3 | 1 | 0 | 0 | 0 | 0 | 330 |
| L1013 | 5 | 1 | Opponent | yes | - | 3 | 1 | 1 | 1 | 0 | 0 | 387 |
| L1030 | 4 | 1 | Mine | no | 5 | 5 | 1 | 1 | 0 | 0 | 0 | 330 |
| L1030 | 4 | 1 | Opponent | no | 0 | 2 | 1 | 1 | 1 | 0 | 0 | 0 |
| L1122 | 6 | 1 | Mine | no | 7 | 2 | 5 | 0 | 1 | 0 | 0 | 526 |
| L1122 | 6 | 1 | Opponent | no | 6 | 2 | 3 | 0 | 0 | 0 | 0 | 145 |
| L1216 | 4 | 1 | Mine | no | 2 | 2 | 3 | 0 | 0 | 0 | 0 | 330 |
| L1216 | 4 | 1 | Opponent | no | 5 | 5 | 3 | 2 | 0 | 0 | 0 | 260 |
| L1232 | 2 | 1 | Mine | - | - | 6 | 2 | 0 | 0 | 0 | 0 | 330 |
| L1232 | 2 | 1 | Opponent | - | - | 2 | 2 | 5 | 0 | 0 | 0 | 170 |
| L1327 | 1 | 1 | Mine | no | 4 | 3 | 2 | 0 | 0 | 0 | 0 | 140 |
| L1327 | 1 | 1 | Opponent | no | 2 | 2 | 3 | 3 | 0 | 0 | 0 | 50 |
| L1422 | 6 | 1 | Mine | no | 1 | 2 | 5 | 0 | 1 | 0 | 0 | 0 |
| L1422 | 6 | 1 | Opponent | no | 0 | 1 | 2 | 0 | 0 | 0 | 0 | 225 |
| L1519 | 1 | 1 | Mine | no | 3 | 3 | 3 | 1 | 0 | 0 | 0 | 0 |
| L1519 | 1 | 1 | Opponent | no | 0 | 2 | 10 | 0 | 1 | 0 | 0 | 543 |
| L1535 | 5 | 1 | Mine | yes | - | 2 | 0 | 0 | 1 | 0 | 0 | 0 |
| L1535 | 5 | 1 | Opponent | yes | - | 3 | 4 | 1 | 0 | 0 | 0 | 907 |
| L1633 | 1 | 1 | Mine | no | 2 | 2 | 4 | 0 | 0 | 0 | 0 | 200 |
| L1633 | 1 | 1 | Opponent | no | 0 | 1 | 5 | 4 | 0 | 0 | 0 | 144 |
| L1731 | 3 | 1 | Mine | no | 2 | 5 | 3 | 0 | 0 | 0 | 0 | 0 |
| L1731 | 3 | 1 | Opponent | no | 4 | 3 | 4 | 0 | 1 | 0 | 0 | 290 |
| L1831 | 1 | 1 | Mine | no | 0 | 3 | 6 | 1 | 1 | 0 | 0 | 0 |
| L1831 | 1 | 1 | Opponent | no | 1 | 3 | 4 | 0 | 3 | 0 | 0 | 365 |
| L1932 | 6 | 1 | Mine | no | 2 | 2 | 7 | 0 | 1 | 0 | 0 | 255 |
| L1932 | 6 | 1 | Opponent | no | 3 | 2 | 5 | 2 | 0 | 0 | 0 | 340 |
| L2033 | 5 | 1 | Mine | yes | - | - | 1 | 5 | 0 | 0 | 0 | 210 |
| L2033 | 5 | 1 | Opponent | yes | - | 2 | 1 | 4 | 0 | 0 | 0 | 0 |
| L2223 | 3 | 1 | Mine | no | 1 | 3 | 6 | 1 | 0 | 0 | 0 | 242 |
| L2223 | 3 | 1 | Opponent | no | 7 | 1 | 5 | 0 | 0 | 0 | 0 | 0 |
| L2327 | 5 | 1 | Mine | yes | - | 2 | 2 | 0 | 1 | 0 | 0 | 185 |
| L2327 | 5 | 1 | Opponent | yes | - | 2 | 9 | 3 | 0 | 0 | 0 | 0 |
| L2433 | 3 | 1 | Mine | no | 7 | 3 | 5 | 1 | 0 | 0 | 0 | 0 |
| L2433 | 3 | 1 | Opponent | no | 0 | 1 | 4 | 1 | 0 | 0 | 0 | 380 |
| L2630 | 2 | 1 | Mine | - | - | 2 | 4 | 2 | 0 | 0 | 0 | 0 |
| L2630 | 2 | 1 | Opponent | - | - | 2 | 5 | 1 | 1 | 0 | 0 | 312 |
| L2832 | 6 | 1 | Mine | no | 1 | - | 0 | 0 | 2 | 0 | 0 | 0 |
| L2832 | 6 | 1 | Opponent | no | 9 | 1 | 3 | 2 | 1 | 0 | 0 | 170 |
| L3133 | 1 | 1 | Mine | yes | 3 | 5 | 0 | 2 | 0 | 0 | 0 | 0 |
| L3133 | 1 | 1 | Opponent | no | 3 | 2 | 4 | 3 | 0 | 0 | 0 | 236 |
| **Average** | | | Mine | 28% | 3.1 | 3.1 | 2.2 | 1.1 | 0.3 | 0.0 | 0.0 | 281.9 |
| **Average** | | | Opponent | 25% | 3.0 | 2.3 | 3.0 | 1.9 | 0.6 | 0.0 | 0.0 | 211.4 |

### Scorecard: groups off

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0110 | 2 | 1 | Mine | - | - | 1 | 1 | 0 | 0 | 0 | 0 | 0 |
| L0110 | 2 | 1 | Opponent | - | - | 2 | 3 | 2 | 0 | 0 | 0 | 330 |
| L0126 | 6 | 1 | Mine | no | 2 | - | 0 | 1 | 0 | 0 | 0 | 387 |
| L0126 | 6 | 1 | Opponent | no | 11 | 2 | 3 | 3 | 0 | 0 | 0 | 0 |
| L0210 | 6 | 1 | Mine | no | 0 | 2 | 1 | 3 | 0 | 0 | 0 | 0 |
| L0210 | 6 | 1 | Opponent | no | 11 | 5 | 0 | 1 | 0 | 0 | 0 | 330 |
| L0226 | 4 | 1 | Mine | no | 2 | 2 | 2 | 3 | 0 | 0 | 0 | 170 |
| L0226 | 4 | 1 | Opponent | no | 9 | 2 | 0 | 3 | 0 | 0 | 0 | 0 |
| L0311 | 5 | 1 | Mine | no | - | - | 0 | 2 | 0 | 0 | 0 | 760 |
| L0311 | 5 | 1 | Opponent | yes | - | 5 | 1 | 0 | 0 | 0 | 0 | 330 |
| L0327 | 3 | 1 | Mine | yes | 2 | 4 | 1 | 0 | 0 | 0 | 0 | 760 |
| L0327 | 3 | 1 | Opponent | no | 8 | 3 | 5 | 3 | 0 | 0 | 0 | 0 |
| L0413 | 5 | 1 | Mine | yes | - | 2 | 3 | 2 | 0 | 0 | 0 | 0 |
| L0413 | 5 | 1 | Opponent | yes | - | 4 | 1 | 1 | 0 | 0 | 0 | 291 |
| L0429 | 3 | 1 | Mine | yes | 8 | 2 | 1 | 2 | 0 | 0 | 0 | 139 |
| L0429 | 3 | 1 | Opponent | no | 0 | 2 | 5 | 2 | 1 | 0 | 0 | 170 |
| L0516 | 6 | 1 | Mine | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 548 |
| L0516 | 6 | 1 | Opponent | no | 0 | 3 | 2 | 3 | 1 | 0 | 0 | 280 |
| L0533 | 5 | 1 | Mine | no | - | - | 0 | 3 | 0 | 0 | 0 | 548 |
| L0533 | 5 | 1 | Opponent | no | - | 5 | 1 | 6 | 0 | 0 | 0 | 0 |
| L0620 | 2 | 1 | Mine | - | - | 2 | 4 | 1 | 0 | 0 | 0 | 615 |
| L0620 | 2 | 1 | Opponent | - | - | - | 0 | 4 | 0 | 0 | 0 | 0 |
| L0709 | 1 | 1 | Mine | yes | 4 | 2 | 2 | 0 | 1 | 0 | 0 | 420 |
| L0709 | 1 | 1 | Opponent | yes | 1 | 6 | 1 | 1 | 1 | 0 | 0 | 420 |
| L0725 | 5 | 1 | Mine | yes | - | 6 | 2 | 1 | 0 | 0 | 0 | 375 |
| L0725 | 5 | 1 | Opponent | yes | - | 2 | 4 | 4 | 0 | 0 | 0 | 0 |
| L0815 | 5 | 1 | Mine | no | - | 4 | 2 | 0 | 0 | 0 | 0 | 679 |
| L0815 | 5 | 1 | Opponent | no | - | 3 | 2 | 2 | 2 | 0 | 0 | 0 |
| L0831 | 3 | 1 | Mine | yes | 3 | 2 | 0 | 1 | 0 | 0 | 0 | 605 |
| L0831 | 3 | 1 | Opponent | no | 4 | - | 1 | 3 | 2 | 0 | 0 | 340 |
| L0922 | 4 | 1 | Mine | no | 0 | 3 | 2 | 1 | 0 | 0 | 0 | 524 |
| L0922 | 4 | 1 | Opponent | no | 1 | 2 | 1 | 2 | 0 | 0 | 0 | 55 |
| L1013 | 5 | 1 | Mine | yes | - | 2 | 1 | 2 | 0 | 0 | 0 | 330 |
| L1013 | 5 | 1 | Opponent | no | - | 1 | 3 | 0 | 0 | 0 | 0 | 140 |
| L1030 | 4 | 1 | Mine | no | 2 | 2 | 3 | 0 | 0 | 0 | 0 | 501 |
| L1030 | 4 | 1 | Opponent | no | 3 | 2 | 0 | 1 | 0 | 0 | 0 | 173 |
| L1122 | 6 | 1 | Mine | no | 5 | 2 | 1 | 0 | 0 | 0 | 0 | 330 |
| L1122 | 6 | 1 | Opponent | no | 0 | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L1216 | 4 | 1 | Mine | no | 1 | 3 | 2 | 0 | 0 | 0 | 0 | 330 |
| L1216 | 4 | 1 | Opponent | no | 0 | 2 | 2 | 1 | 0 | 0 | 0 | 200 |
| L1232 | 2 | 1 | Mine | - | - | 2 | 2 | 0 | 0 | 0 | 0 | 330 |
| L1232 | 2 | 1 | Opponent | - | - | 2 | 5 | 3 | 1 | 0 | 0 | 340 |
| L1327 | 1 | 1 | Mine | no | 10 | 4 | 3 | 0 | 0 | 0 | 0 | 140 |
| L1327 | 1 | 1 | Opponent | no | 1 | 2 | 1 | 6 | 2 | 0 | 0 | 50 |
| L1422 | 6 | 1 | Mine | no | 2 | 2 | 7 | 0 | 0 | 0 | 0 | 0 |
| L1422 | 6 | 1 | Opponent | no | 0 | 1 | 3 | 0 | 0 | 0 | 0 | 297 |
| L1519 | 1 | 1 | Mine | no | 0 | 3 | 3 | 2 | 0 | 0 | 0 | 0 |
| L1519 | 1 | 1 | Opponent | no | 0 | 2 | 8 | 1 | 0 | 0 | 0 | 317 |
| L1535 | 5 | 1 | Mine | yes | - | 2 | 3 | 1 | 1 | 0 | 0 | 0 |
| L1535 | 5 | 1 | Opponent | yes | - | 3 | 0 | 3 | 0 | 0 | 0 | 657 |
| L1633 | 1 | 1 | Mine | no | 1 | 2 | 3 | 2 | 0 | 0 | 0 | 200 |
| L1633 | 1 | 1 | Opponent | no | 0 | 1 | 2 | 3 | 1 | 0 | 0 | 773 |
| L1731 | 3 | 1 | Mine | yes | 5 | 4 | 6 | 1 | 0 | 0 | 0 | 98 |
| L1731 | 3 | 1 | Opponent | no | 1 | 2 | 2 | 1 | 2 | 0 | 0 | 340 |
| L1831 | 1 | 1 | Mine | no | 7 | 3 | 2 | 0 | 0 | 0 | 0 | 0 |
| L1831 | 1 | 1 | Opponent | no | 2 | 3 | 2 | 0 | 1 | 0 | 0 | 170 |
| L1932 | 6 | 1 | Mine | no | 3 | 2 | 4 | 0 | 1 | 0 | 0 | 161 |
| L1932 | 6 | 1 | Opponent | no | 1 | 3 | 5 | 0 | 0 | 0 | 0 | 477 |
| L2033 | 5 | 1 | Mine | no | - | - | 0 | 6 | 1 | 0 | 0 | 210 |
| L2033 | 5 | 1 | Opponent | yes | - | 2 | 2 | 5 | 0 | 0 | 0 | 0 |
| L2223 | 3 | 1 | Mine | yes | 3 | 2 | 8 | 0 | 1 | 0 | 0 | 332 |
| L2223 | 3 | 1 | Opponent | no | 0 | 1 | 7 | 1 | 1 | 0 | 0 | 72 |
| L2327 | 5 | 1 | Mine | yes | - | 2 | 2 | 1 | 0 | 0 | 0 | 66 |
| L2327 | 5 | 1 | Opponent | yes | - | 2 | 3 | 0 | 0 | 0 | 0 | 0 |
| L2433 | 3 | 1 | Mine | no | 12 | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L2433 | 3 | 1 | Opponent | no | 0 | 1 | 4 | 2 | 0 | 0 | 0 | 352 |
| L2630 | 2 | 1 | Mine | - | - | 2 | 3 | 2 | 0 | 0 | 0 | 0 |
| L2630 | 2 | 1 | Opponent | - | - | 2 | 2 | 2 | 1 | 0 | 0 | 312 |
| L2832 | 6 | 1 | Mine | no | 1 | - | 0 | 0 | 1 | 0 | 0 | 589 |
| L2832 | 6 | 1 | Opponent | no | 7 | 2 | 4 | 1 | 1 | 0 | 0 | 0 |
| L3133 | 1 | 1 | Mine | no | 0 | 2 | 3 | 2 | 0 | 0 | 0 | 392 |
| L3133 | 1 | 1 | Opponent | no | 0 | 3 | 0 | 2 | 0 | 0 | 0 | 252 |
| **Average** | | | Mine | 34% | 3.2 | 2.5 | 2.2 | 1.2 | 0.2 | 0.0 | 0.0 | 292.8 |
| **Average** | | | Opponent | 22% | 2.6 | 2.5 | 2.5 | 2.0 | 0.5 | 0.0 | 0.0 | 207.4 |


## Charged fights (points per fight a side charged into; a combined charge is one fight)

### Charged fights: groups on

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 21 | 81 | 0.8 | 1.3 | 108 | 0 | +108 | 0 of 3 | 3 of 3 | +162 | +81 |
| Mine | Chaos Dwarfs | 4 | 156 | 256 | 3.0 | 1.2 | 85 | 0 | +85 | 5 of 12 | 7 of 12 | +184 | +66 |
| Mine | Dwarfen Mountain Holds | 3 | 661 | 44 | 2.0 | 1.0 | 22 | 41 | -19 | 2 of 6 | 5 of 6 | - | -19 |
| Mine | Empire of Man | 5 | 296 | 31 | 1.0 | 1.0 | 31 | 53 | -22 | 1 of 5 | 4 of 5 | - | -22 |
| Mine | Grand Cathay | 5 | 241 | 352 | 3.8 | 1.3 | 93 | 25 | +68 | 5 of 19 | 17 of 19 | +186 | +26 |
| Mine | High Elf Realms | 4 | 174 | 560 | 4.5 | 1.1 | 125 | 0 | +125 | 6 of 18 | 13 of 18 | +106 | +127 |
| Mine | Kingdom of Bretonnia | 1 | 0 | 696 | 5.0 | 1.0 | 139 | 55 | +84 | 0 of 5 | 2 of 5 | - | +84 |
| Mine | Lizardmen | 1 | 0 | 887 | 3.0 | 1.0 | 296 | 62 | +234 | 1 of 3 | 2 of 3 | - | +234 |
| Mine | Ogre Kingdoms | 1 | 0 | 509 | 6.0 | 1.0 | 85 | 90 | -6 | 2 of 6 | 4 of 6 | - | -6 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 507 | 9.0 | 1.0 | 56 | 95 | -38 | 3 of 9 | 6 of 9 | - | -38 |
| Mine | Skaven | 1 | 0 | 19 | 2.0 | 1.0 | 10 | 0 | +10 | 0 of 2 | 1 of 2 | - | +10 |
| Mine | Tomb Kings of Khemri | 2 | 0 | 662 | 5.0 | 1.2 | 132 | 6 | +126 | 2 of 10 | 8 of 10 | +419 | +53 |
| Mine | Vampire Counts | 2 | 0 | 1103 | 6.0 | 1.2 | 184 | 7 | +177 | 2 of 12 | 6 of 12 | +206 | +171 |
| Mine | Warriors of Chaos | 2 | 0 | 0 | 1.0 | 1.5 | 0 | 331 | -331 | 1 of 2 | 2 of 2 | -662 | +0 |
| **Mine** | all armies | 36 | 169 | 327 | 3.1 | 1.1 | 105 | 33 | +73 | 30 of 112 | 80 of 112 | +151 | +61 |
| Opponent | Empire of Man | 1 | 380 | 398 | 3.0 | 1.3 | 133 | 35 | +98 | 2 of 3 | 0 of 3 | +288 | +3 |
| Opponent | Grand Cathay | 3 | 263 | 335 | 1.7 | 1.6 | 201 | 0 | +201 | 1 of 5 | 1 of 5 | +307 | +42 |
| Opponent | High Elf Realms | 3 | 139 | 435 | 3.0 | 1.1 | 145 | 116 | +29 | 6 of 9 | 4 of 9 | -162 | +53 |
| Opponent | Kingdom of Bretonnia | 2 | 48 | 0 | 2.0 | 1.0 | 0 | 0 | +0 | 4 of 4 | 0 of 4 | - | +0 |
| Opponent | Orc & Goblin Tribes | 1 | 0 | 241 | 7.0 | 1.1 | 34 | 31 | +4 | 4 of 7 | 2 of 7 | +0 | +4 |
| Opponent | Skaven | 1 | 0 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 0 of 1 | 0 of 1 | - | +0 |
| Opponent | Tomb Kings of Khemri | 4 | 157 | 409 | 3.8 | 1.3 | 109 | 31 | +78 | 6 of 15 | 8 of 15 | +287 | +3 |
| Opponent | Vampire Counts | 6 | 0 | 601 | 5.5 | 1.2 | 109 | 24 | +85 | 14 of 33 | 23 of 33 | +163 | +74 |
| Opponent | Warriors of Chaos | 9 | 19 | 434 | 3.7 | 1.2 | 118 | 41 | +77 | 13 of 33 | 19 of 33 | +8 | +93 |
| Opponent | Wood Elf Realms | 6 | 87 | 127 | 2.0 | 1.0 | 64 | 20 | +43 | 6 of 12 | 6 of 12 | - | +43 |
| **Opponent** | all armies | 36 | 84 | 357 | 3.4 | 1.2 | 105 | 35 | +71 | 56 of 122 | 63 of 122 | +145 | +56 |

### Charged fights: groups off

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 72 | 196 | 1.8 | 1.1 | 112 | 0 | +112 | 2 of 7 | 4 of 7 | +165 | +103 |
| Mine | Chaos Dwarfs | 4 | 170 | 191 | 2.5 | 1.0 | 76 | 40 | +36 | 5 of 10 | 7 of 10 | - | +36 |
| Mine | Dwarfen Mountain Holds | 3 | 685 | 0 | 1.3 | 1.0 | 0 | 62 | -62 | 1 of 4 | 2 of 4 | - | -62 |
| Mine | Empire of Man | 5 | 393 | 81 | 1.8 | 1.0 | 45 | 91 | -46 | 3 of 9 | 5 of 9 | - | -46 |
| Mine | Grand Cathay | 5 | 386 | 308 | 3.6 | 1.2 | 86 | 19 | +67 | 3 of 18 | 18 of 18 | +165 | +39 |
| Mine | High Elf Realms | 4 | 179 | 429 | 4.5 | 1.1 | 95 | 0 | +95 | 6 of 18 | 14 of 18 | +125 | +94 |
| Mine | Kingdom of Bretonnia | 1 | 0 | 943 | 7.0 | 1.1 | 135 | 0 | +135 | 0 of 7 | 5 of 7 | +144 | +133 |
| Mine | Lizardmen | 1 | 116 | 690 | 6.0 | 1.0 | 115 | 68 | +47 | 1 of 6 | 4 of 6 | - | +47 |
| Mine | Ogre Kingdoms | 1 | 0 | 1029 | 3.0 | 1.0 | 343 | 11 | +332 | 1 of 3 | 2 of 3 | - | +332 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 737 | 7.0 | 1.0 | 105 | 0 | +105 | 2 of 7 | 5 of 7 | - | +105 |
| Mine | Skaven | 1 | 19 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Mine | Tomb Kings of Khemri | 2 | 0 | 950 | 6.5 | 1.2 | 146 | 9 | +137 | 2 of 13 | 10 of 13 | +182 | +128 |
| Mine | Vampire Counts | 2 | 72 | 886 | 5.5 | 1.3 | 161 | 0 | +161 | 2 of 11 | 6 of 11 | +170 | +158 |
| Mine | Warriors of Chaos | 2 | 0 | 672 | 4.0 | 1.5 | 168 | 14 | +154 | 1 of 8 | 5 of 8 | +304 | +104 |
| **Mine** | all armies | 36 | 220 | 378 | 3.4 | 1.1 | 113 | 21 | +92 | 29 of 121 | 87 of 121 | +184 | +80 |
| Opponent | Empire of Man | 1 | 380 | 189 | 2.0 | 1.0 | 94 | 120 | -26 | 1 of 2 | 1 of 2 | - | -26 |
| Opponent | Grand Cathay | 3 | 309 | 393 | 2.7 | 1.1 | 147 | 0 | +147 | 1 of 8 | 6 of 8 | +952 | +32 |
| Opponent | High Elf Realms | 3 | 113 | 169 | 3.0 | 1.3 | 56 | 86 | -30 | 6 of 9 | 5 of 9 | -76 | -17 |
| Opponent | Kingdom of Bretonnia | 2 | 162 | 253 | 2.5 | 1.2 | 101 | 0 | +101 | 1 of 5 | 3 of 5 | +165 | +85 |
| Opponent | Orc & Goblin Tribes | 1 | 0 | 291 | 6.0 | 1.0 | 48 | 18 | +30 | 2 of 6 | 3 of 6 | - | +30 |
| Opponent | Skaven | 1 | 105 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Tomb Kings of Khemri | 4 | 99 | 252 | 3.2 | 1.1 | 78 | 54 | +23 | 5 of 13 | 5 of 13 | +177 | +11 |
| Opponent | Vampire Counts | 6 | 0 | 504 | 3.5 | 1.4 | 144 | 74 | +70 | 11 of 21 | 11 of 21 | +51 | +81 |
| Opponent | Warriors of Chaos | 9 | 0 | 296 | 2.8 | 1.0 | 106 | 58 | +48 | 10 of 25 | 13 of 25 | - | +48 |
| Opponent | Wood Elf Realms | 6 | 94 | 192 | 2.2 | 1.1 | 89 | 106 | -17 | 7 of 13 | 5 of 13 | +251 | -39 |
| **Opponent** | all armies | 36 | 84 | 292 | 2.8 | 1.1 | 103 | 61 | +42 | 44 of 102 | 52 of 102 | +129 | +28 |


## Effective charges (55-75% to win the first round: just enough force)

### Effective charges: groups on

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 3 | 0 | 0 | 0 | 1 (net +162) | 1 (net +0) | 0 | 1 | 0% (0 of 2) |
| Mine | Chaos Dwarfs | 12 | 0 | 0 | 2 (net +0) | 4 (net +120) | 1 (net +0) | 4 (net +92) | 1 | 18% (2 of 11) |
| Mine | Dwarfen Mountain Holds | 6 | 2 (net -122) | 0 | 1 (net +0) | 1 (net +0) | 0 | 1 (net +133) | 1 | 20% (1 of 5) |
| Mine | Empire of Man | 5 | 1 (net +153) | 0 | 1 (net -265) | 0 | 0 | 2 (net +0) | 1 | 25% (1 of 4) |
| Mine | Grand Cathay | 19 | 0 | 0 | 3 (net +0) | 4 (net +145) | 5 (net +80) | 5 (net +62) | 2 | 18% (3 of 17) |
| Mine | High Elf Realms | 18 | 1 (net +233) | 0 | 2 (net +0) | 3 (net +122) | 3 (net +112) | 8 (net +151) | 1 | 12% (2 of 17) |
| Mine | Kingdom of Bretonnia | 5 | 2 (net +167) | 0 | 1 (net -277) | 0 | 0 | 1 (net +258) | 1 | 25% (1 of 4) |
| Mine | Lizardmen | 3 | 1 (net +743) | 0 | 1 (net -185) | 1 (net +144) | 0 | 0 | 0 | 33% (1 of 3) |
| Mine | Ogre Kingdoms | 6 | 1 (net -185) | 0 | 0 | 0 | 0 | 2 (net -45) | 3 | 0% (0 of 3) |
| Mine | Orc & Goblin Tribes | 9 | 0 | 0 | 1 (net +340) | 1 (net +0) | 0 | 0 | 7 | 50% (1 of 2) |
| Mine | Skaven | 2 | 1 (net +0) | 0 | 0 | 0 | 0 | 0 | 1 | 0% (0 of 1) |
| Mine | Tomb Kings of Khemri | 10 | 0 | 0 | 1 (net +70) | 1 (net +0) | 2 (net +144) | 5 (net +181) | 1 | 11% (1 of 9) |
| Mine | Vampire Counts | 12 | 1 (net +412) | 0 | 4 (net +192) | 1 (net +53) | 1 (net +0) | 5 (net +178) | 0 | 33% (4 of 12) |
| Mine | Warriors of Chaos | 2 | 0 | 0 | 0 | 0 | 0 | 2 (net -331) | 0 | 0% (0 of 2) |
| Opponent | Empire of Man | 3 | 0 | 0 | 0 | 1 (net +6) | 0 | 2 (net +144) | 0 | 0% (0 of 3) |
| Opponent | Grand Cathay | 5 | 0 | 0 | 0 | 2 (net +428) | 2 (net +32) | 1 (net +84) | 0 | 0% (0 of 5) |
| Opponent | High Elf Realms | 9 | 2 (net -86) | 0 | 0 | 2 (net -81) | 0 | 4 (net +114) | 1 | 0% (0 of 8) |
| Opponent | Kingdom of Bretonnia | 4 | 3 (net +0) | 0 | 1 (net +0) | 0 | 0 | 0 | 0 | 25% (1 of 4) |
| Opponent | Orc & Goblin Tribes | 7 | 0 | 0 | 0 | 0 | 1 (net +115) | 1 (net +0) | 5 | 0% (0 of 2) |
| Opponent | Skaven | 1 | 1 (net +0) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 1) |
| Opponent | Tomb Kings of Khemri | 15 | 1 (net -144) | 1 (net +0) | 0 | 3 (net +191) | 4 (net +169) | 6 (net +12) | 0 | 0% (0 of 15) |
| Opponent | Vampire Counts | 33 | 3 (net +41) | 0 | 5 (net +105) | 10 (net +35) | 5 (net +59) | 7 (net +192) | 3 | 17% (5 of 30) |
| Opponent | Warriors of Chaos | 33 | 3 (net +0) | 0 | 6 (net -38) | 5 (net +124) | 2 (net +48) | 14 (net +149) | 3 | 20% (6 of 30) |
| Opponent | Wood Elf Realms | 12 | 1 (net -19) | 0 | 1 (net +0) | 0 | 0 | 4 (net +114) | 6 | 17% (1 of 6) |

### Effective charges: groups off

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 7 | 1 (net +0) | 1 (net +0) | 0 | 2 (net +165) | 0 | 2 (net +226) | 1 | 0% (0 of 6) |
| Mine | Chaos Dwarfs | 10 | 1 (net -91) | 0 | 2 (net +0) | 2 (net +85) | 0 | 3 (net +44) | 2 | 25% (2 of 8) |
| Mine | Dwarfen Mountain Holds | 4 | 1 (net +0) | 0 | 1 (net -186) | 0 | 0 | 2 (net -30) | 0 | 25% (1 of 4) |
| Mine | Empire of Man | 9 | 2 (net -132) | 0 | 3 (net -47) | 1 (net +104) | 1 (net +72) | 2 (net -92) | 0 | 33% (3 of 9) |
| Mine | Grand Cathay | 18 | 1 (net -340) | 0 | 2 (net +157) | 6 (net +122) | 2 (net +28) | 6 (net +44) | 1 | 12% (2 of 17) |
| Mine | High Elf Realms | 18 | 2 (net +110) | 1 (net +0) | 0 | 4 (net +86) | 3 (net +84) | 5 (net +159) | 3 | 0% (0 of 15) |
| Mine | Kingdom of Bretonnia | 7 | 2 (net +348) | 0 | 0 | 1 (net +0) | 1 (net +0) | 2 (net +72) | 1 | 0% (0 of 6) |
| Mine | Lizardmen | 6 | 0 | 0 | 1 (net -409) | 1 (net +144) | 2 (net +143) | 1 (net +144) | 1 | 20% (1 of 5) |
| Mine | Ogre Kingdoms | 3 | 0 | 1 (net +859) | 0 | 0 | 0 | 1 (net +170) | 1 | 0% (0 of 2) |
| Mine | Orc & Goblin Tribes | 7 | 0 | 0 | 0 | 0 | 0 | 2 (net +322) | 5 | 0% (0 of 2) |
| Mine | Tomb Kings of Khemri | 13 | 1 (net +233) | 0 | 1 (net -122) | 3 (net +245) | 4 (net +121) | 4 (net +112) | 0 | 8% (1 of 13) |
| Mine | Vampire Counts | 11 | 1 (net +412) | 0 | 2 (net +99) | 3 (net +286) | 1 (net +98) | 4 (net +52) | 0 | 18% (2 of 11) |
| Mine | Warriors of Chaos | 8 | 0 | 0 | 3 (net +199) | 1 (net +334) | 1 (net -81) | 3 (net +127) | 0 | 38% (3 of 8) |
| Opponent | Empire of Man | 2 | 0 | 0 | 0 | 0 | 0 | 2 (net -26) | 0 | 0% (0 of 2) |
| Opponent | Grand Cathay | 8 | 0 | 0 | 1 (net +85) | 1 (net +952) | 4 (net +36) | 2 (net +0) | 0 | 12% (1 of 8) |
| Opponent | High Elf Realms | 9 | 2 (net +135) | 0 | 1 (net -347) | 2 (net -76) | 2 (net +118) | 2 (net -140) | 0 | 11% (1 of 9) |
| Opponent | Kingdom of Bretonnia | 5 | 1 (net +0) | 1 (net +95) | 0 | 2 (net +169) | 1 (net +73) | 0 | 0 | 0% (0 of 5) |
| Opponent | Orc & Goblin Tribes | 6 | 0 | 0 | 0 | 1 (net +0) | 1 (net +115) | 1 (net +0) | 3 | 0% (0 of 3) |
| Opponent | Tomb Kings of Khemri | 13 | 0 | 0 | 1 (net +217) | 1 (net -511) | 3 (net +0) | 6 (net +93) | 2 | 9% (1 of 11) |
| Opponent | Vampire Counts | 21 | 1 (net -95) | 1 (net -205) | 2 (net -190) | 5 (net +157) | 4 (net +69) | 6 (net +149) | 2 | 11% (2 of 19) |
| Opponent | Warriors of Chaos | 25 | 2 (net +379) | 1 (net -489) | 0 | 3 (net +81) | 1 (net +45) | 9 (net +124) | 9 | 0% (0 of 16) |
| Opponent | Wood Elf Realms | 13 | 3 (net +91) | 0 | 0 | 2 (net +58) | 0 | 2 (net +68) | 6 | 0% (0 of 7) |


## Charged fights by odds band, damage counted (Morten 2026-11-10)

### Charged fights, damage counted: groups on

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 10 | 261 | 190 | +144 | 207 | 61 | +146 | +56.0 |
| Mine | Effective (55-75%) | 17 | 335 | 245 | +26 | 82 | 52 | +30 | +9.0 |
| Mine | 76-89% | 17 | 258 | 171 | +105 | 110 | 11 | +99 | +38.4 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 35 | 290 | 183 | +95 | 159 | 46 | +113 | +38.9 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 13 | 448 | 102 | +79 | 114 | 26 | +88 | +19.6 |
| Mine | No odds | 20 | 229 | 162 | +6 | 59 | 61 | -2 | -0.7 |
| Mine | All fights | 112 | 297 | 178 | +73 | 121 | 43 | +78 | +26.2 |
| Opponent | Long shot (under 50%) | 14 | 217 | 278 | -15 | 62 | 85 | -23 | -10.5 |
| Opponent | 50-54% | 1 | 195 | 189 | +0 | 0 | 0 | +0 | +0.0 |
| Opponent | Effective (55-75%) | 13 | 347 | 273 | +23 | 160 | 90 | +70 | +20.2 |
| Opponent | 76-89% | 23 | 295 | 199 | +98 | 143 | 31 | +112 | +38.1 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 39 | 272 | 216 | +123 | 177 | 55 | +122 | +44.8 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 14 | 412 | 88 | +89 | 104 | 13 | +91 | +22.1 |
| Opponent | No odds | 18 | 179 | 274 | +15 | 69 | 64 | +6 | +3.3 |
| Opponent | All fights | 122 | 280 | 220 | +71 | 130 | 53 | +76 | +27.3 |

### Charged fights, damage counted: groups off

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 12 | 278 | 253 | +72 | 152 | 120 | +32 | +11.6 |
| Mine | 50-54% | 3 | 189 | 249 | +286 | 327 | 61 | +266 | +140.9 |
| Mine | Effective (55-75%) | 15 | 234 | 224 | +17 | 113 | 87 | +27 | +11.4 |
| Mine | 76-89% | 24 | 294 | 192 | +156 | 162 | 13 | +149 | +50.6 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 37 | 260 | 164 | +96 | 126 | 31 | +95 | +36.7 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 15 | 466 | 91 | +78 | 99 | 20 | +80 | +17.1 |
| Mine | No odds | 15 | 242 | 171 | +48 | 99 | 26 | +74 | +30.4 |
| Mine | All fights | 121 | 287 | 180 | +92 | 133 | 42 | +91 | +31.6 |
| Opponent | Long shot (under 50%) | 9 | 275 | 281 | +134 | 166 | 33 | +132 | +48.2 |
| Opponent | 50-54% | 3 | 435 | 363 | -200 | 180 | 343 | -163 | -37.4 |
| Opponent | Effective (55-75%) | 5 | 575 | 240 | -85 | 170 | 255 | -85 | -14.8 |
| Opponent | 76-89% | 17 | 342 | 208 | +104 | 148 | 52 | +96 | +28.0 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 30 | 284 | 187 | +79 | 131 | 41 | +89 | +31.4 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 16 | 346 | 80 | +56 | 65 | 6 | +58 | +16.9 |
| Opponent | No odds | 22 | 170 | 235 | -42 | 78 | 109 | -30 | -17.8 |
| Opponent | All fights | 102 | 297 | 200 | +42 | 118 | 71 | +48 | +16.0 |


## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| groups on | move | 489 | 101 (21%) | 74 (15%) | 54 (11%) | 334 (68%) |
| groups on | objective | 424 | 63 (15%) | 49 (12%) | 57 (13%) | 304 (72%) |
| groups off | move | 467 | 94 (20%) | 73 (16%) | 42 (9%) | 331 (71%) |
| groups off | objective | 411 | 50 (12%) | 38 (9%) | 59 (14%) | 302 (73%) |

## Combined arms (paper 2026-11-09, item 8)

### Combined arms: groups on (36 games)

| Side | Fights with 2+ chargers | Enemy charges answered by a counter-charge | Blocks with an escort in reach (end of Movement) | Screens that took the charge | Lanes opened (rule rows) / blocker gone that round |
| --- | --- | --- | --- | --- | --- |
| Mine | 15 of 112 (13%) | 8 of 138 (6%) | 204 of 366 (56%) | 0.39 per game | 0.14 / 0.08 per game |
| Opponent | 20 of 122 (16%) | 12 of 127 (9%) | 165 of 336 (49%) | 0.28 per game | 0.03 / 0.00 per game |

### Combined arms: groups off (36 games)

| Side | Fights with 2+ chargers | Enemy charges answered by a counter-charge | Blocks with an escort in reach (end of Movement) | Screens that took the charge | Lanes opened (rule rows) / blocker gone that round |
| --- | --- | --- | --- | --- | --- |
| Mine | 14 of 121 (12%) | 14 of 110 (13%) | 229 of 390 (59%) | 0.33 per game | 0.06 / 0.00 per game |
| Opponent | 14 of 102 (14%) | 12 of 138 (9%) | 120 of 294 (41%) | 0.42 per game | 0.14 / 0.00 per game |


## Quality by phase (per game and side)

| Phase | Number | A Mine | A Opponent | B Mine | B Opponent |
| --- | --- | --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.2 | 3.6 | 3.2 | 3.6 |
| Strategy | Charge objectives carried out (made contact) | 58% (79 of 137) | 54% (83 of 153) | 65% (93 of 143) | 43% (63 of 146) |
| Strategy | Shoot objectives carried out (shot that target) | 45% (153 of 341) | 57% (98 of 172) | 48% (166 of 346) | 55% (86 of 156) |
| Strategy | Close-in objectives charged next turn | 15% (29 of 195) | 15% (34 of 229) | 14% (25 of 184) | 12% (27 of 227) |
| Strategy | Support requests answered (helper made contact too) | 31% (5 of 16) | 55% (6 of 11) | 47% (9 of 19) | 56% (15 of 27) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (3 of 3) | 100% (2 of 2) | 80% (4 of 5) | 100% (1 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | 50% (5 of 10) | 100% (1 of 1) | 64% (7 of 11) | 50% (3 of 6) |
| Strategy | Joined characters whose unit fought | 33% (14 of 42) | 25% (10 of 40) | 43% (20 of 47) | 29% (10 of 35) |
| Strategy | Lone characters that fought | 76% (71 of 93) | 77% (72 of 94) | 73% (64 of 88) | 75% (74 of 99) |
| Movement | Charges halted short of contact | 0.1 | 0.2 | 0.3 | 0.3 |
| Movement | Idle units | 1.1 | 1.9 | 1.2 | 2.0 |
| Movement | Points that never moved of their own | 281.9 | 211.4 | 292.8 | 207.4 |
| Movement | Fights charged into per game | 3.1 | 3.4 | 3.4 | 2.8 |
| Movement | Charges with odds: long shots (under 50%) | 10 of 92, net +144 | 14 of 104, net -15 | 12 of 106, net +72 | 9 of 80, net +134 |
| Movement | Charges with odds: sweet spot (55-75%) | 17 of 92, net +26 | 13 of 104, net +23 | 15 of 106, net +17 | 5 of 80, net -85 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 13 of 92, net +79 | 14 of 104, net +89 | 15 of 106, net +78 | 16 of 80, net +56 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 35 of 92, net +95 | 39 of 104, net +123 | 37 of 106, net +96 | 30 of 80, net +79 |
| Shooting | Shots by shooting units (incl. breath weapons) | 7.9 | 9.0 | 7.6 | 8.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 50% (116 of 233) | 32% (25 of 78) | 43% (100 of 234) | 33% (22 of 67) |
| Shooting | Points destroyed by shooting units | 87.8 | 33.2 | 63.4 | 38.6 |
| Shooting | War machine shots | 6.5 | 2.2 | 6.5 | 1.9 |
| Shooting | Points destroyed by war machines | 43.9 | 23.1 | 83.6 | 21.4 |
| Magic | Magic missiles cast | 1.0 | 0.8 | 1.6 | 0.9 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 51% (19 of 37) | 21% (6 of 28) | 41% (24 of 59) | 29% (10 of 34) |
| Magic | Wounds caused by magic missiles | 2.1 | 1.9 | 2.6 | 1.7 |
| Magic | Wounds caused by other spells | 1.7 | 0.6 | 1.9 | 1.1 |
| Magic | Points destroyed by magic (all spells) | 37.0 | 27.2 | 72.9 | 24.2 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.3 / 0.3 / 0.6 / 0.1 | 2.1 / 0.1 / 0.2 / 0.3 | 1.7 / 0.3 / 0.5 / 0.1 | 1.8 / 0.2 / 0.2 / 0.3 |
| Combat | Points destroyed in combat | 379.4 | 344.1 | 441.1 | 292.4 |
| Combat | Points run down | 88.7 | 118.7 | 119.9 | 61.9 |
| Combat | Net points per charged fight, damage counted | +78 | +76 | +91 | +48 |
| Combat | Net per 100 charger points, damage counted | +26.2 | +27.3 | +31.6 | +16.0 |
| Combat | First round won (charged fights) | 71% | 52% | 72% | 51% |
| Combat | Net points per charged fight | +73 | +71 | +92 | +42 |
| Combat | Net points per supported fight / lone fight | +151 / +61 | +145 / +56 | +184 / +80 | +129 / +28 |
| Combat | Charged fights on a top-3 enemy unit | 30 of 112 | 56 of 122 | 29 of 121 | 44 of 102 |
| Game | Points lost | 633.9 | 716.3 | 587.1 | 824.8 |
| Game | VP from objectives | 587.2 | 494.4 | 663.9 | 510.8 |
| Game | Lone holders (player turns) | 3.1 | 3.0 | 3.2 | 2.6 |

A = groups on:
- Mine won / drew / lost: 18 / 4 / 14 of 36 ended games (of 36); mean margin (Mine - Opponent) +172 VP
- The side that went first won 16 of 32 games with a winner
- Points traded per game (both sides' losses): 1350
- Games not ended: 0; findings 0, warnings 1

B = groups off:
- Mine won / drew / lost: 20 / 7 / 9 of 36 ended games (of 36); mean margin (Mine - Opponent) +413 VP
- The side that went first won 18 of 29 games with a winner
- Points traded per game (both sides' losses): 1412
- Games not ended: 0; findings 1, warnings 0

## Opponent rules (fired a game, figure / won / lost VP a game)

| Rule | A Mine | A Opponent | B Mine | B Opponent |
| --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.6 (+0 / 0 / 0) | 0.3 (+0 / 0 / 0) | 0.6 (+0 / 0 / 0) | 0.3 (+0 / 0 / 0) |
| ALREADY CARRIED | - | - | 0.0 (+0 / 0 / 0) | - |
| ARRIVAL HUNT | 0.0 (+0 / 0 / 0) | 0.1 (+0 / 0 / 0) | - | 0.1 (+0 / 0 / 0) |
| ARTILLERY RE-ROLL WEIGHED | 2.0 (+0 / 0 / 7) | 0.2 (+0 / 0 / 0) | 1.5 (+0 / 0 / 22) | 0.1 (+0 / 0 / 0) |
| BACKUP TARGETS | 1.0 (+9 / 0 / 33) | 0.5 (+4 / 0 / 7) | 0.8 (+7 / 0 / 19) | 0.6 (+7 / 0 / 22) |
| BEST PREY | 4.7 (+299 / 211 / 101) | 4.2 (+264 / 161 / 59) | 4.4 (+295 / 206 / 78) | 4.1 (+309 / 149 / 86) |
| BEST PRIZE | 0.1 (+1 / 5 / 22) | 0.1 (-3 / 0 / 0) | 0.1 (-9 / 6 / 0) | 0.1 (+6 / 4 / 0) |
| BLOCKED CHARGE SKIPPED | 0.1 (+0 / 12 / 0) | 0.3 (+0 / 7 / 7) | 0.0 (+0 / 15 / 0) | 0.0 (+0 / 7 / 0) |
| BLOCKED WHEEL | 0.6 (+22 / 0 / 2) | 0.5 (+8 / 0 / 0) | 0.4 (+14 / 0 / 0) | 0.4 (-0 / 0 / 0) |
| BOMBING RUN | 0.0 (+1 / 0 / 0) | - | - | 0.0 (+2 / 0 / 0) |
| BOUND ASSAILMENT | - | - | - | 0.0 (+0 / 0 / 4) |
| CANNON PLAN MISSED | 1.1 (+0 / 164 / 5) | 0.2 (+0 / 2 / 0) | 0.9 (+0 / 94 / 12) | 0.2 (+0 / 8 / 7) |
| CANNON PLANNED TARGET | 5.6 (+146 / 449 / 67) | 1.2 (+61 / 73 / 30) | 5.5 (+125 / 374 / 110) | 1.0 (+56 / 92 / 20) |
| CANNON SIGHT KEPT | 1.3 (+0 / 0 / 0) | 0.3 (+0 / 0 / 0) | 1.3 (+0 / 0 / 0) | 0.3 (+0 / 0 / 0) |
| CAST JOB | 0.9 (+16 / 17 / 7) | 0.6 (+15 / 19 / 15) | 1.0 (+31 / 92 / 14) | 0.5 (+18 / 39 / 6) |
| CASTER AWAY FROM SCREEN | 0.2 (+0 / 0 / 0) | 0.1 (+0 / 0 / 0) | 0.2 (+0 / 0 / 0) | 0.1 (+0 / 0 / 0) |
| CASTING BLOCK | 0.4 (+36 / 0 / 21) | 0.1 (+1 / 0 / 0) | 0.5 (+32 / 14 / 9) | 0.0 (+1 / 0 / 3) |
| CASTS AFTER FRIENDS | 0.4 (+0 / 0 / 31) | 0.4 (+0 / 0 / 11) | 0.5 (+0 / 0 / 19) | 0.4 (+0 / 0 / 16) |
| CASTS FROM BEHIND | 0.0 (+0 / 0 / 0) | 0.2 (+0 / 0 / 0) | 0.0 (+0 / 0 / 0) | 0.2 (+0 / 0 / 0) |
| CATCH FLIERS | 0.1 (+1 / 0 / 0) | - | 0.0 (+1 / 0 / 0) | - |
| CATCH ODDS | - | - | 0.0 (+1 / 0 / 0) | - |
| CHAFF PASSED | 0.2 (-0 / 0 / 3) | 0.1 (-0 / 4 / 0) | 0.1 (-0 / 0 / 0) | 0.0 (+0 / 0 / 0) |
| CHAMPION TAKES THE CHALLENGE | 0.0 (+3 / 7 / 0) | - | - | 0.0 (+0 / 0 / 0) |
| CHARGE NOW WEIGHED | 0.8 (-107 / 38 / 37) | 0.3 (-32 / 8 / 33) | 0.8 (-68 / 28 / 19) | 0.6 (-69 / 14 / 9) |
| CHARIOT NO STATIC JOB | 0.7 (+0 / 10 / 3) | 0.8 (+0 / 13 / 6) | 0.7 (+0 / 11 / 19) | 0.6 (+0 / 11 / 8) |
| CHEAP HELPER | 0.1 (+0 / 4 / 2) | 0.0 (+0 / 0 / 0) | 0.1 (+0 / 2 / 0) | 0.1 (+0 / 5 / 1) |
| CONTINUE AHEAD WEIGHED | - | 0.0 (+0 / 0 / 0) | - | - |
| CONVEYANCE SEARCH | 0.6 (+51 / 42 / 51) | 0.4 (+20 / 16 / 16) | 0.5 (+21 / 20 / 20) | 0.4 (+16 / 6 / 12) |
| COUNTER-CHARGE COVER | 10.0 (+857 / 0 / 215) | 8.9 (+865 / 0 / 208) | - | - |
| EDGE GIVE GROUND | 0.1 (+7 / 21 / 0) | 0.2 (+5 / 8 / 1) | 0.2 (+11 / 17 / 2) | 0.2 (+5 / 25 / 0) |
| ELIXIR WORTH | - | - | 0.0 (+1 / 0 / 0) | - |
| ENGINEER BY LORE | 0.1 (+0 / 0 / 0) | - | 0.1 (+0 / 0 / 0) | - |
| ESCORT | 0.2 (+13 / 0 / 3) | 0.2 (+14 / 0 / 4) | - | - |
| FACES THE THREAT | 1.3 (+132 / 0 / 40) | 1.3 (+129 / 0 / 25) | 1.4 (+124 / 0 / 26) | 1.1 (+111 / 0 / 30) |
| FIGHT LIFT | 0.0 (+0 / 0 / 0) | 0.1 (+3 / 7 / 0) | 0.0 (+0 / 0 / 0) | 0.1 (+1 / 19 / 0) |
| FIRE AND FLEE | - | - | 0.0 (+0 / 0 / 5) | 0.0 (+2 / 0 / 0) |
| FOCUS FIRE | - | 0.0 (+0 / 3 / 0) | 0.0 (+1 / 2 / 0) | 0.1 (+3 / 4 / 0) |
| FOLLOW UP WEIGHED | 1.0 (+188 / 0 / 47) | 1.1 (+142 / 0 / 3) | 1.2 (+163 / 0 / 52) | 1.1 (+160 / 0 / 32) |
| FRIENDS SHOTS CHECKED | 0.3 (+12 / 0 / 0) | 0.0 (+0 / 0 / 0) | 0.2 (+13 / 0 / 5) | 0.1 (+12 / 0 / 8) |
| GIVES UP | 1.1 (-30 / 169 / 21) | 1.4 (-46 / 178 / 15) | 1.5 (-34 / 228 / 13) | 1.7 (-53 / 133 / 101) |
| GIVES UP ITS SCREEN | 0.4 (-6 / 23 / 9) | 0.8 (-11 / 41 / 18) | 0.5 (-20 / 38 / 8) | 0.8 (-17 / 67 / 9) |
| GROUND FLIERS | 0.1 (+1 / 0 / 0) | - | 0.1 (+1 / 0 / 0) | 0.0 (+0 / 0 / 0) |
| GROUP AIM | 0.3 (+2 / 0 / 0) | 0.5 (+5 / 0 / 2) | - | - |
| GROUP BROKEN | 0.1 (+0 / 0 / 0) | - | - | - |
| HELPER ALREADY ASKED | 0.0 (+0 / 0 / 0) | 0.0 (+0 / 4 / 1) | 0.0 (+0 / 2 / 0) | 0.1 (+0 / 12 / 7) |
| HELPER UNSEEN | 0.3 (+0 / 27 / 13) | 0.2 (+0 / 7 / 2) | 0.2 (+0 / 13 / 11) | 0.2 (+0 / 30 / 12) |
| HOLDS AMBUSHERS | 0.4 (+0 / 0 / 0) | 0.7 (+0 / 0 / 0) | 0.4 (+0 / 0 / 0) | 0.7 (+0 / 0 / 0) |
| HORN WORTH | - | 0.1 (+3 / 0 / 0) | - | 0.1 (+2 / 0 / 14) |
| HUNT ADVANCE | 0.2 (+10 / 5 / 1) | 0.1 (+7 / 0 / 3) | 0.2 (+15 / 24 / 1) | 0.1 (+6 / 3 / 6) |
| HUNT DROPPED | 0.1 (+0 / 0 / 1) | 0.1 (+0 / 0 / 0) | 0.1 (+0 / 9 / 0) | - |
| HUNT IN PAIRS | 0.4 (+18 / 0 / 8) | 0.6 (+53 / 0 / 18) | - | - |
| HUNT KEPT | 0.2 (+2 / 5 / 1) | - | 0.2 (+11 / 21 / 0) | 0.1 (+0 / 7 / 3) |
| HUNT RESULT | 0.1 (+0 / 0 / 1) | 0.2 (+8 / 0 / 4) | 0.2 (+25 / 9 / 0) | 0.1 (+6 / 0 / 0) |
| HUNT THE GUNS | 0.1 (+58 / 5 / 1) | 0.2 (+61 / 5 / 6) | 0.2 (+82 / 20 / 1) | 0.1 (+30 / 0 / 6) |
| JOINT CHARGE PLAN | 0.1 (+4 / 8 / 8) | 0.2 (+7 / 5 / 2) | 0.2 (+12 / 16 / 4) | 0.3 (+21 / 7 / 0) |
| KEEPS ITS PREY | 0.3 (+1 / 15 / 8) | 0.2 (+3 / 3 / 2) | 0.2 (+1 / 0 / 12) | 0.3 (+4 / 27 / 10) |
| KEEPS ITS TARGET | 1.9 (+58 / 224 / 40) | 2.4 (+72 / 145 / 56) | 1.9 (+58 / 186 / 41) | 2.1 (+63 / 76 / 39) |
| KEEPS SCOUTS OR AMBUSH | 0.0 (+0 / 0 / 0) | - | 0.0 (+0 / 0 / 0) | - |
| KILLS COUNT | 1.9 (+96 / 158 / 42) | 1.9 (+106 / 162 / 26) | 1.9 (+68 / 135 / 53) | 2.0 (+111 / 128 / 89) |
| KILLS COUNT NEXT TURN | 10.0 (+380 / 583 / 230) | 10.9 (+433 / 362 / 243) | 9.2 (+351 / 467 / 155) | 9.9 (+395 / 294 / 213) |
| LONE CHARACTER SAFE SPOT | 0.6 (+23 / 7 / 28) | 0.2 (+13 / 8 / 23) | 0.6 (+48 / 21 / 11) | 0.3 (+14 / 2 / 14) |
| LONE WIZARD HOLDS BACK | 1.4 (+0 / 98 / 51) | 1.6 (+0 / 54 / 53) | 1.5 (+0 / 88 / 22) | 1.9 (+0 / 27 / 62) |
| LONE WIZARD KEPT IN | 0.6 (+37 / 0 / 0) | 0.3 (+22 / 0 / 0) | 0.6 (+37 / 0 / 0) | 0.3 (+22 / 0 / 0) |
| MAKE SURE TOGETHER | 1.5 (+88 / 125 / 26) | 1.9 (+102 / 53 / 38) | 0.8 (+60 / 36 / 4) | 0.9 (+46 / 32 / 13) |
| MANOEUVRE | 0.3 (+12 / 0 / 16) | 0.2 (+7 / 0 / 5) | 0.3 (+7 / 0 / 0) | 0.1 (+3 / 0 / 0) |
| MARCH AT ESCAPER | 0.2 (+1 / 0 / 0) | 0.1 (+1 / 0 / 5) | 0.4 (+3 / 0 / 14) | 0.2 (+1 / 0 / 3) |
| MARCH ODDS | 0.9 (+62 / 43 / 38) | 1.0 (+48 / 27 / 30) | 1.1 (+63 / 55 / 0) | 0.9 (+51 / 20 / 22) |
| MISSILES IN THE MOVE | 2.9 (+89 / 0 / 49) | 2.9 (+40 / 0 / 73) | 3.5 (+110 / 0 / 41) | 2.9 (+50 / 0 / 41) |
| MISSILES NEXT TURN | 5.1 (+79 / 0 / 100) | 4.9 (+47 / 0 / 140) | 5.2 (+88 / 0 / 68) | 4.9 (+47 / 0 / 107) |
| MODEL FACING | 0.1 (+9 / 0 / 2) | - | 0.1 (+9 / 0 / 0) | - |
| MOVE AND CAST | 0.1 (+3 / 0 / 0) | 0.2 (+15 / 0 / 6) | 0.3 (+6 / 0 / 0) | 0.1 (+1 / 0 / 6) |
| MOVE SPELL IN RANGE | 0.1 (+5 / 0 / 37) | 0.0 (+0 / 0 / 6) | 0.3 (+12 / 0 / 21) | 0.0 (+0 / 0 / 6) |
| MOVE SPELL NOT WORTH | - | - | 0.0 (+0 / 0 / 0) | - |
| MOVE SPELL OUT OF RANGE | 0.3 (-9 / 8 / 99) | 0.1 (-2 / 3 / 6) | 0.4 (-12 / 2 / 46) | 0.1 (-2 / 0 / 6) |
| MOVE SPELL SPOT | 0.2 (+0 / 0 / 0) | 0.2 (+0 / 0 / 11) | 0.2 (+0 / 0 / 0) | 0.1 (+0 / 0 / 0) |
| MOVES UNITS SPELL | 0.1 (+4 / 0 / 0) | 0.1 (+0 / 0 / 0) | 0.1 (+4 / 0 / 0) | 0.1 (+0 / 0 / 0) |
| NEEDED THERE | - | 0.1 (+1 / 4 / 0) | 0.1 (+5 / 0 / 0) | - |
| NO RALLY LEFT | - | - | 0.1 (+2 / 0 / 0) | 0.0 (+1 / 0 / 4) |
| NOT NEEDED | 0.3 (-15 / 36 / 9) | 0.3 (-17 / 31 / 4) | 0.3 (-16 / 23 / 11) | 0.2 (-8 / 22 / 2) |
| NOT TURNED | 11.8 (+171 / 0 / 238) | 10.8 (+204 / 0 / 239) | 10.4 (+119 / 0 / 197) | 10.0 (+50 / 0 / 176) |
| NOT WORTH A CAST | 0.5 (-0 / 0 / 42) | 0.7 (-1 / 0 / 22) | 0.5 (-15 / 0 / 51) | 0.6 (-1 / 0 / 0) |
| OPENS A LANE | 0.1 (+1 / 16 / 0) | 0.0 (+0 / 0 / 0) | 0.1 (+0 / 4 / 0) | 0.1 (+1 / 0 / 5) |
| OPENS UP | 0.3 (+21 / 16 / 12) | 0.2 (+15 / 13 / 0) | 0.4 (+35 / 25 / 0) | 0.2 (+18 / 16 / 5) |
| OVERRUNS AWAY | 0.4 (+10 / 46 / 13) | 0.6 (+13 / 61 / 18) | 0.4 (+9 / 50 / 13) | 0.5 (+20 / 43 / 10) |
| PATHS CROSS | 2.4 (+172 / 0 / 51) | 3.1 (+221 / 0 / 28) | 2.1 (+134 / 0 / 16) | 2.6 (+159 / 0 / 30) |
| PLAN LEADS | 1.3 (+104 / 16 / 5) | 0.9 (+61 / 5 / 15) | 1.3 (+112 / 44 / 18) | 0.9 (+68 / 14 / 17) |
| PLAN RESULT | 38.1 (+1722 / 1580 / 881) | 38.1 (+1249 / 1112 / 919) | 37.4 (+1606 / 1338 / 735) | 37.0 (+996 / 915 / 1087) |
| PURSUES BIG PREY | 0.1 (-9 / 0 / 0) | 0.1 (-2 / 0 / 0) | 0.1 (-14 / 0 / 11) | - |
| PURSUES ON | 0.0 (+2 / 0 / 0) | 0.0 (+0 / 0 / 0) | 0.0 (+2 / 0 / 0) | - |
| RAIDS THE BAGGAGE | - | - | - | 0.0 (+7 / 0 / 0) |
| RAIDS THE BAGGAGE NEXT TURN | 0.2 (+22 / 0 / 11) | 0.0 (+2 / 0 / 0) | 0.2 (+22 / 0 / 0) | - |
| REDIRECT COUNTER | 2.9 (+109 / 0 / 50) | 4.4 (+313 / 0 / 41) | - | - |
| REDIRECT WEIGHED | 0.4 (+19 / 20 / 33) | 0.4 (+8 / 9 / 14) | 0.1 (+7 / 3 / 0) | 0.3 (+18 / 28 / 0) |
| RESTRAINS TO SHOOT | 0.2 (+3 / 0 / 10) | 0.0 (+0 / 0 / 0) | 0.1 (+6 / 0 / 6) | - |
| RISK BY ARC | 2.5 (+107 / 246 / 58) | 2.5 (+52 / 217 / 53) | 2.6 (+106 / 256 / 71) | 2.6 (+38 / 190 / 101) |
| SAFE SURE CHARGE | 0.0 (-0 / 0 / 0) | - | - | 0.0 (-0 / 0 / 0) |
| SAFER THAN THE JOB | 0.5 (+27 / 0 / 4) | 0.5 (+45 / 0 / 0) | 1.2 (+58 / 0 / 14) | 0.9 (+54 / 0 / 32) |
| SCOUT SPOT | 0.4 (+0 / 0 / 1) | 0.3 (+1 / 0 / 0) | 0.4 (+0 / 0 / 0) | 0.3 (+1 / 0 / 0) |
| SCOUT WAITS | 0.4 (+0 / 0 / 1) | 0.3 (+0 / 0 / 0) | 0.4 (+0 / 0 / 0) | 0.3 (+0 / 0 / 0) |
| SCREEN STEPS ASIDE | 0.0 (+0 / 0 / 1) | 0.0 (+0 / 0 / 0) | - | - |
| SEARCH SPOT | 1.5 (+84 / 0 / 16) | 1.0 (+99 / 0 / 15) | 1.1 (+51 / 0 / 26) | 1.1 (+47 / 0 / 41) |
| SECOND HUNTER | 0.0 (-1 / 0 / 0) | - | 0.1 (-1 / 9 / 0) | - |
| SELF MOVE SPELL | 0.4 (+47 / 0 / 40) | 0.2 (+59 / 0 / 22) | 0.4 (+56 / 0 / 18) | 0.3 (+54 / 0 / 22) |
| SET UP TOGETHER | 2.0 (+135 / 125 / 35) | 2.9 (+169 / 53 / 46) | 1.0 (+89 / 36 / 4) | 1.5 (+92 / 38 / 19) |
| SET-UP MISSED | 0.0 (+7 / 10 / 0) | - | 0.0 (+9 / 0 / 0) | - |
| SHOOTERS IN TWO RANKS | 0.3 (+1 / 0 / 0) | 0.1 (+0 / 0 / 0) | 0.3 (+1 / 0 / 0) | 0.1 (+0 / 0 / 0) |
| SHORT GUN FORWARD | 0.1 (+0 / 0 / 0) | - | 0.1 (+0 / 0 / 0) | - |
| SHOT REPLANNED | 0.9 (+0 / 245 / 2) | 0.1 (+0 / 7 / 0) | 0.7 (+0 / 143 / 3) | 0.1 (+0 / 14 / 0) |
| SHOTS IN THE MOVE | 12.9 (+582 / 0 / 170) | 8.6 (+291 / 0 / 136) | 12.2 (+451 / 0 / 219) | 8.6 (+242 / 0 / 95) |
| SPELL CATCH ODDS | 0.1 (-1 / 0 / 0) | - | - | - |
| SPELL SETS UP CHARGE | 0.1 (+44 / 11 / 11) | - | 0.1 (+30 / 0 / 0) | 0.0 (+5 / 0 / 0) |
| SPELL WORTH | 1.3 (+26 / 30 / 29) | 2.4 (+38 / 114 / 104) | 1.4 (+25 / 7 / 7) | 2.2 (+34 / 143 / 124) |
| STANDS TO CAST | 0.1 (+1 / 0 / 0) | - | 0.1 (+5 / 2 / 0) | - |
| STOPS | - | 0.1 (+4 / 5 / 3) | 0.1 (+8 / 17 / 0) | - |
| STUCK PIVOT | 0.2 (+0 / 0 / 5) | 0.3 (+0 / 0 / 0) | 0.2 (+0 / 0 / 0) | 0.2 (+0 / 0 / 0) |
| SURE CHARGE BEATS ADVANCE | 0.2 (-11 / 24 / 19) | 0.1 (-4 / 18 / 0) | 0.2 (-10 / 13 / 5) | 0.0 (-1 / 0 / 0) |
| THROUGH LINE OF FIRE | 0.6 (+24 / 0 / 0) | 0.2 (+18 / 0 / 0) | 0.6 (+11 / 0 / 0) | 0.2 (+12 / 0 / 0) |
| TURN WORTH | 0.6 (-45 / 58 / 0) | 0.5 (-34 / 40 / 0) | 0.6 (-41 / 68 / 13) | 0.7 (-49 / 36 / 20) |
| TWO OR MORE ARRIVE | 0.8 (+13 / 42 / 10) | 0.9 (+19 / 5 / 6) | 0.5 (+10 / 16 / 4) | 0.8 (+14 / 0 / 8) |
| WEARS DOWN | 1.0 (+57 / 141 / 24) | 1.2 (+26 / 139 / 42) | 1.0 (+50 / 162 / 26) | 1.0 (+34 / 112 / 93) |
| WHO HITS BACK | 0.2 (+30 / 0 / 5) | 0.1 (+9 / 0 / 13) | 0.4 (+29 / 0 / 0) | 0.5 (+62 / 0 / 7) |
| WHOLE FIGHT | 0.4 (+13 / 49 / 8) | 0.2 (+9 / 18 / 8) | 0.3 (+19 / 58 / 0) | 0.3 (+14 / 29 / 0) |
| WHOLE FIGHT GAIN | 0.2 (+18 / 5 / 8) | 0.3 (+34 / 28 / 7) | 0.3 (+31 / 40 / 2) | 0.4 (+56 / 49 / 11) |

A = groups on, B = groups off.

## Rule changes (changed a game, VP a change)

| Rule | A | B |
| --- | --- | --- |
| ADVANCE LANE KEPT | 0.86 (+0.0) | 0.86 (+0.0) |
| ALREADY CARRIED | - | - |
| ARRIVAL HUNT | 0.00 (-) | 0.00 (-) |
| ARTILLERY RE-ROLL WEIGHED | 2.19 (+0.0) | 1.67 (+0.0) |
| BACKUP TARGETS | 0.03 (+1.1) | 0.03 (+0.8) |
| BEST PREY | 3.72 (+42.0) | 3.69 (+52.5) |
| BEST PRIZE | 0.17 (-52.9) | 0.11 (-85.9) |
| BLOCKED CHARGE SKIPPED | 0.33 (+0.0) | 0.06 (+0.0) |
| BLOCKED WHEEL | - | - |
| BOMBING RUN | 0.03 (+27.1) | 0.03 (+56.8) |
| BOUND ASSAILMENT | - | 0.03 (+0.1) |
| CANNON PLAN MISSED | 0.00 (-) | 0.00 (-) |
| CANNON PLANNED TARGET | 1.42 (-4.3) | 1.39 (-0.9) |
| CANNON SIGHT KEPT | 1.56 (+0.0) | 1.56 (+0.0) |
| CAST JOB | 0.67 (+13.1) | 0.89 (+21.2) |
| CASTER AWAY FROM SCREEN | 0.25 (+0.0) | 0.25 (+0.0) |
| CASTING BLOCK | 0.36 (+38.1) | 0.39 (+26.3) |
| CASTS AFTER FRIENDS | - | - |
| CASTS FROM BEHIND | 0.25 (+0.0) | 0.25 (+0.0) |
| CATCH FLIERS | - | - |
| CATCH ODDS | - | - |
| CHAFF PASSED | 0.28 (-1.4) | 0.14 (-0.6) |
| CHAMPION TAKES THE CHALLENGE | 0.00 (-) | 0.00 (-) |
| CHARGE NOW WEIGHED | 1.17 (+106.4) | 1.33 (+88.6) |
| CHARIOT NO STATIC JOB | 0.92 (-64.1) | 0.81 (-116.1) |
| CHEAP HELPER | - | - |
| CONTINUE AHEAD WEIGHED | 0.03 (+0.0) | - |
| CONVEYANCE SEARCH | - | - |
| COUNTER-CHARGE COVER | 2.22 (+64.9) | - |
| EDGE GIVE GROUND | 0.17 (+19.0) | 0.06 (+78.7) |
| ELIXIR WORTH | - | 0.03 (+22.0) |
| ENGINEER BY LORE | 0.00 (-) | 0.00 (-) |
| ESCORT | 0.00 (-) | - |
| FACES THE THREAT | - | - |
| FIGHT LIFT | - | - |
| FIRE AND FLEE | - | 0.06 (+45.6) |
| FOCUS FIRE | 0.03 (+7.2) | 0.08 (+41.9) |
| FOLLOW UP WEIGHED | 2.11 (+156.6) | 2.28 (+142.2) |
| FRIENDS SHOTS CHECKED | 0.33 (+38.5) | 0.31 (+82.8) |
| GIVES UP | 0.06 (+0.9) | 0.00 (-) |
| GIVES UP ITS SCREEN | 0.00 (-) | 0.00 (-) |
| GROUND FLIERS | - | - |
| GROUP AIM | 0.03 (+6.5) | - |
| GROUP BROKEN | - | - |
| HELPER ALREADY ASKED | - | - |
| HELPER UNSEEN | 0.00 (-) | 0.00 (-) |
| HOLDS AMBUSHERS | 1.08 (+0.0) | 1.08 (+0.0) |
| HORN WORTH | 0.11 (+24.3) | 0.11 (+13.7) |
| HUNT ADVANCE | 0.14 (+47.8) | 0.25 (+58.6) |
| HUNT DROPPED | - | - |
| HUNT IN PAIRS | 0.11 (+136.2) | - |
| HUNT KEPT | - | - |
| HUNT RESULT | - | - |
| HUNT THE GUNS | - | - |
| JOINT CHARGE PLAN | 0.03 (+83.2) | 0.11 (+120.7) |
| KEEPS ITS PREY | 0.03 (+0.3) | 0.03 (+1.2) |
| KEEPS ITS TARGET | 1.28 (+16.9) | 1.08 (+15.9) |
| KEEPS SCOUTS OR AMBUSH | 0.03 (+0.0) | 0.03 (+0.0) |
| KILLS COUNT | 1.17 (+49.5) | 0.92 (+39.5) |
| KILLS COUNT NEXT TURN | 4.81 (+38.6) | 5.14 (+34.4) |
| LONE CHARACTER SAFE SPOT | - | - |
| LONE WIZARD HOLDS BACK | 0.86 (-61.9) | 1.22 (-54.3) |
| LONE WIZARD KEPT IN | 0.89 (+66.9) | 0.89 (+66.9) |
| MAKE SURE TOGETHER | 0.81 (+55.0) | 0.75 (+38.0) |
| MANOEUVRE | - | - |
| MARCH AT ESCAPER | - | - |
| MARCH ODDS | 1.53 (+14.6) | 1.47 (+21.9) |
| MISSILES IN THE MOVE | - | - |
| MISSILES NEXT TURN | 0.03 (+2.1) | 0.08 (+17.4) |
| MODEL FACING | 0.06 (+169.2) | 0.08 (+107.3) |
| MOVE AND CAST | - | - |
| MOVE SPELL IN RANGE | 0.00 (-) | 0.00 (-) |
| MOVE SPELL NOT WORTH | - | - |
| MOVE SPELL OUT OF RANGE | - | - |
| MOVE SPELL SPOT | - | - |
| MOVES UNITS SPELL | 0.19 (+20.1) | 0.19 (+20.1) |
| NEEDED THERE | 0.03 (+0.0) | 0.03 (+0.0) |
| NO RALLY LEFT | - | 0.08 (+10.2) |
| NOT NEEDED | 0.00 (-) | 0.00 (-) |
| NOT TURNED | 0.00 (-) | 0.00 (-) |
| NOT WORTH A CAST | - | - |
| OPENS A LANE | 0.00 (-) | 0.03 (+0.7) |
| OPENS UP | 0.25 (+34.6) | 0.25 (+55.9) |
| OVERRUNS AWAY | 0.19 (+23.1) | 0.11 (+62.6) |
| PATHS CROSS | - | - |
| PLAN LEADS | 0.94 (+55.9) | 1.03 (+68.6) |
| PLAN RESULT | - | - |
| PURSUES BIG PREY | 0.19 (-56.2) | 0.06 (-254.8) |
| PURSUES ON | 0.06 (+46.8) | 0.03 (+78.7) |
| RAIDS THE BAGGAGE | - | 0.03 (+143.9) |
| RAIDS THE BAGGAGE NEXT TURN | 0.22 (+41.0) | 0.22 (+39.3) |
| REDIRECT COUNTER | 0.44 (+84.4) | - |
| REDIRECT WEIGHED | 0.78 (+76.4) | 0.42 (+66.6) |
| RESTRAINS TO SHOOT | 0.19 (+19.7) | 0.11 (+57.7) |
| RISK BY ARC | 1.36 (+34.5) | 1.08 (+36.2) |
| SAFE SURE CHARGE | 0.03 (-8.7) | 0.03 (-34.9) |
| SAFER THAN THE JOB | - | - |
| SCOUT SPOT | 0.00 (-) | 0.00 (-) |
| SCOUT WAITS | 0.69 (+0.0) | 0.69 (+0.0) |
| SCREEN STEPS ASIDE | 0.06 (+0.0) | - |
| SEARCH SPOT | - | - |
| SECOND HUNTER | 0.00 (-) | 0.00 (-) |
| SELF MOVE SPELL | - | - |
| SET UP TOGETHER | 1.33 (+65.1) | 1.19 (+56.5) |
| SET-UP MISSED | - | - |
| SHOOTERS IN TWO RANKS | 0.44 (+1.7) | 0.44 (+1.7) |
| SHORT GUN FORWARD | 0.14 (+0.0) | 0.14 (+0.0) |
| SHOT REPLANNED | 1.08 (+0.0) | 0.86 (+0.0) |
| SHOTS IN THE MOVE | - | - |
| SPELL CATCH ODDS | - | - |
| SPELL SETS UP CHARGE | - | - |
| SPELL WORTH | - | - |
| STANDS TO CAST | 0.03 (+6.8) | 0.03 (+0.6) |
| STOPS | 0.03 (+108.8) | 0.06 (+80.0) |
| STUCK PIVOT | 0.47 (+0.0) | 0.44 (+0.0) |
| SURE CHARGE BEATS ADVANCE | 0.28 (-54.3) | 0.19 (-53.4) |
| THROUGH LINE OF FIRE | - | - |
| TURN WORTH | 0.03 (+0.2) | 0.00 (-) |
| TWO OR MORE ARRIVE | 0.17 (+15.4) | 0.19 (+18.4) |
| WEARS DOWN | 0.42 (+26.6) | 0.28 (+32.6) |
| WHO HITS BACK | 0.36 (-58.9) | 0.89 (-80.4) |
| WHOLE FIGHT | 0.19 (+86.9) | 0.25 (+54.6) |
| WHOLE FIGHT GAIN | 0.33 (+68.8) | 0.31 (+120.1) |

A = groups on, B = groups off.

## Plans (happened, won of planned)

| Side | Plan | A | B |
| --- | --- | --- | --- |
| Mine | advance | 18% (93%) | 19% (80%) |
| Mine | charge | 57% (105%) | 67% (95%) |
| Mine | close in | 29% (59%) | 26% (51%) |
| Mine | hold | 40% (0%) | 43% (0%) |
| Mine | join | 92% (0%) | 100% (0%) |
| Mine | shoot | 61% (221%) | 63% (315%) |
| Mine | support | 89% (0%) | 91% (0%) |
| Opponent | advance | 16% (62%) | 20% (53%) |
| Opponent | charge | 54% (80%) | 50% (69%) |
| Opponent | close in | 21% (40%) | 15% (26%) |
| Opponent | hold | 27% (0%) | 38% (0%) |
| Opponent | join | 97% (0%) | 97% (0%) |
| Opponent | shoot | 62% (277%) | 61% (259%) |
| Opponent | support | 93% (0%) | 91% (0%) |

A = groups on, B = groups off.

## Packages: hunt the guns (per side)

| Batch | Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| A | Mine | 0.1 | 5 | 2 | 0% | 0% | 0% | - | 452 | 0 | 0% | 30 |
| A | Opponent | 0.2 | 6 | 0 | 17% | 17% | 0% | 2.0 | 363 | 49 | 17% | 60 |
| B | Mine | 0.2 | 8 | 2 | 33% | 50% | 0% | 3.3 | 408 | 148 | 17% | 29 |
| B | Opponent | 0.1 | 3 | 1 | 50% | 50% | 0% | 3.0 | 417 | 117 | 50% | 83 |

A = groups on, B = groups off.

### Battle groups: groups on

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 10.0 | 23% | 60% | 17% | 36% | 35% | 7% | 12% | 46% | 0% |
| Mine | REDIRECT COUNTER | 2.9 | 29% | 60% | 7% | 50% | 14% | 4% | 4% | 71% | 7% |
| Opponent | COUNTER-CHARGE COVER | 8.9 | 17% | 62% | 23% | 46% | 23% | 9% | 28% | 40% | 0% |
| Opponent | REDIRECT COUNTER | 4.4 | 17% | 78% | 4% | 0% | 15% | 4% | 8% | 62% | 12% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.3 | 7 | 0% | - |
| Opponent | 0.4 | 11 | 0% | - |

### Deployment: positions vs output by unit type: groups on

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 1 | 0 (1) | 0 | 0 | 100 | 0% | 4.0 | - | 0 (1) | - | 0 (1) | - |
| Mine | Chaff | 40 | 73 (40) | 50 | 23 | 55 | 40% | 2.6 | 64 (20) | 84 (8) | 82 (12) | 94 (32) | 0 (8) |
| Mine | Character | 120 | 46 (120) | 46 | 0 | 29 | 22% | 2.5 | 60 (41) | 45 (58) | 30 (7) | 47 (58) | 53 (48) |
| Mine | Clean-up | 15 | 51 (15) | 9 | 42 | 35 | 33% | 2.9 | 50 (7) | 35 (6) | 133 (2) | 60 (8) | 39 (7) |
| Mine | Fast Hammer | 43 | 34 (43) | 25 | 9 | 47 | 16% | 3.0 | 38 (24) | 38 (13) | 0 (6) | 42 (31) | 12 (12) |
| Mine | Fragile | 3 | 0 (3) | 0 | 0 | 33 | 67% | 6.0 | 0 (3) | - | - | 0 (1) | 0 (2) |
| Mine | Hammer | 50 | 37 (50) | 23 | 14 | 37 | 24% | 2.4 | 10 (13) | 39 (32) | 96 (5) | 34 (34) | 43 (16) |
| Mine | Holder | 25 | 54 (25) | 14 | 41 | 11 | 36% | 3.1 | 14 (8) | 77 (10) | 50 (7) | 56 (13) | 52 (12) |
| Mine | Shooter | 38 | 89 (38) | 42 | 47 | 36 | 5% | 1.8 | 102 (10) | 87 (26) | 57 (2) | 122 (22) | 51 (16) |
| Mine | Support | 4 | 46 (4) | 46 | 0 | 0 | 0% | 3.8 | 0 (1) | - | 79 (3) | - | 46 (4) |
| Mine | War machine | 52 | 33 (52) | 33 | 0 | 29 | 4% | 1.0 | 36 (14) | 31 (34) | 36 (4) | 34 (14) | 33 (38) |
| Mine | Wizard | 15 | 7 (15) | 7 | 0 | 44 | 27% | 1.7 | 0 (2) | 11 (9) | 0 (1) | 11 (7) | 0 (5) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Chaff | 73 | 60 (73) | 18 | 42 | 46 | 49% | 2.5 | 60 (31) | 87 (13) | 46 (29) | 70 (52) | 37 (21) |
| Opponent | Character | 101 | 45 (101) | 45 | 0 | 30 | 23% | 2.4 | 45 (39) | 52 (48) | 8 (8) | 49 (51) | 43 (44) |
| Opponent | Clean-up | 9 | 45 (9) | 28 | 17 | 38 | 33% | 2.5 | 53 (3) | 22 (4) | 111 (2) | 70 (5) | 23 (4) |
| Opponent | Fast Hammer | 60 | 47 (60) | 23 | 24 | 46 | 28% | 3.0 | 47 (31) | 44 (17) | 53 (12) | 47 (32) | 47 (28) |
| Opponent | Fragile | 3 | 0 (3) | 0 | 0 | 100 | 33% | 3.0 | - | 0 (2) | 0 (1) | 0 (2) | 0 (1) |
| Opponent | Hammer | 47 | 32 (47) | 27 | 5 | 37 | 28% | 3.3 | 5 (15) | 40 (28) | 39 (4) | 34 (25) | 29 (22) |
| Opponent | Holder | 40 | 74 (40) | 23 | 51 | 36 | 30% | 2.7 | 11 (10) | 105 (21) | 77 (9) | 77 (29) | 65 (11) |
| Opponent | Shooter | 28 | 28 (28) | 20 | 8 | 56 | 7% | 1.2 | 9 (7) | 34 (20) | 35 (1) | 44 (17) | 7 (11) |
| Opponent | Support | 4 | 0 (4) | 0 | 0 | 17 | 50% | 5.0 | 0 (2) | 0 (1) | 0 (1) | 0 (2) | 0 (2) |
| Opponent | War machine | 17 | 53 (17) | 53 | 0 | 45 | 12% | 1.5 | 0 (3) | 84 (10) | 17 (4) | 72 (3) | 50 (14) |
| Opponent | Wizard | 33 | 12 (33) | 12 | 0 | 49 | 15% | 2.0 | 4 (15) | 45 (8) | 0 (4) | 21 (16) | 6 (11) |

### Deployment: positions vs output by unit type: groups off

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Mine | Chaff | 40 | 64 (40) | 24 | 40 | 54 | 42% | 2.8 | 83 (20) | 27 (8) | 56 (12) | 82 (32) | 0 (8) |
| Mine | Character | 120 | 57 (120) | 57 | 0 | 16 | 22% | 2.4 | 78 (43) | 53 (57) | 15 (6) | 74 (57) | 46 (49) |
| Mine | Clean-up | 15 | 80 (15) | 36 | 44 | 31 | 47% | 2.6 | 41 (7) | 114 (6) | 109 (2) | 76 (8) | 85 (7) |
| Mine | Fast Hammer | 43 | 47 (43) | 32 | 15 | 41 | 30% | 2.9 | 49 (24) | 56 (13) | 0 (6) | 53 (31) | 27 (12) |
| Mine | Fragile | 3 | 10 (3) | 10 | 0 | 100 | 33% | 4.0 | 10 (3) | - | - | 0 (1) | 15 (2) |
| Mine | Hammer | 50 | 47 (50) | 33 | 14 | 38 | 24% | 2.7 | 0 (13) | 60 (32) | 75 (5) | 44 (34) | 54 (16) |
| Mine | Holder | 25 | 56 (25) | 1 | 55 | 16 | 52% | 2.5 | 26 (6) | 76 (12) | 41 (6) | 69 (11) | 48 (13) |
| Mine | Shooter | 38 | 67 (38) | 34 | 33 | 40 | 3% | 1.9 | 101 (10) | 65 (25) | 0 (2) | 97 (23) | 30 (14) |
| Mine | Support | 4 | 0 (4) | 0 | 0 | 39 | 25% | 4.0 | - | 0 (1) | 0 (3) | 0 (1) | 0 (3) |
| Mine | War machine | 52 | 46 (52) | 46 | 0 | 39 | 2% | 1.1 | 25 (14) | 48 (34) | 111 (4) | 19 (14) | 56 (38) |
| Mine | Wizard | 15 | 28 (15) | 28 | 0 | 57 | 20% | 1.9 | 0 (4) | 32 (7) | 174 (1) | 64 (5) | 31 (7) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Chaff | 73 | 44 (73) | 5 | 39 | 55 | 49% | 2.6 | 45 (31) | 101 (13) | 11 (29) | 50 (52) | 30 (21) |
| Opponent | Character | 101 | 42 (101) | 42 | 0 | 42 | 21% | 2.5 | 50 (37) | 39 (49) | 39 (7) | 53 (50) | 35 (43) |
| Opponent | Clean-up | 9 | 30 (9) | 3 | 28 | 46 | 44% | 2.8 | 9 (3) | 20 (4) | 111 (2) | 42 (5) | 20 (4) |
| Opponent | Fast Hammer | 60 | 41 (60) | 17 | 24 | 50 | 23% | 3.0 | 26 (31) | 62 (17) | 51 (12) | 47 (32) | 34 (28) |
| Opponent | Fragile | 3 | 54 (3) | 54 | 0 | 0 | 33% | 3.5 | - | 81 (2) | 0 (1) | 81 (2) | 0 (1) |
| Opponent | Hammer | 47 | 26 (47) | 22 | 4 | 45 | 26% | 3.2 | 22 (15) | 29 (28) | 0 (4) | 28 (25) | 23 (22) |
| Opponent | Holder | 40 | 65 (40) | 4 | 61 | 45 | 38% | 3.0 | 61 (11) | 80 (19) | 34 (10) | 73 (30) | 41 (10) |
| Opponent | Shooter | 28 | 28 (28) | 23 | 5 | 44 | 7% | 1.2 | 14 (7) | 28 (20) | 134 (1) | 45 (17) | 6 (11) |
| Opponent | Support | 4 | 0 (4) | 0 | 0 | 50 | 75% | 6.0 | 0 (2) | 0 (1) | 0 (1) | 0 (2) | 0 (2) |
| Opponent | War machine | 17 | 51 (17) | 51 | 0 | 49 | 12% | 1.4 | 102 (3) | 27 (10) | 75 (4) | 0 (3) | 61 (14) |
| Opponent | Wizard | 33 | 16 (33) | 16 | 0 | 34 | 15% | 1.9 | 7 (14) | 49 (6) | 0 (4) | 8 (13) | 24 (11) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0110, L0126, L2433, L2630 |
| Charmed Shield | Opponent | L0126, L0226, L0327, L0725, L1327, L2327 |
| Clockwork Compass | Mine | L1216, L1232 |
| Elixir of Power | Mine | L1122, L1932 |
| Elixir of Power | Opponent | L0311, L1519 |
| Fistful of Laurels | Mine | L1831 |
| Horn of the Wild Hunt | Opponent | L0533, L1633, L2033, L2433, L3133 |
| Invocation of Nehek | Mine | L2433 |
| Invocation of Nehek | Opponent | L0327, L0725, L1327, L2327 |
| Opal Amulet | Mine | L1422 |
| Periapt of Soul Exchange | Mine | L2033 |
| Periapt of Soul Exchange | Opponent | L0620 |
| Ring of Doom | Mine | L0210, L0226, L1122, L1216, L1232, L1519, L1535, L3133 |
| Ring of Doom | Opponent | L0311, L0533, L0815, L0831, L1633, L1731, L1831, L2033, L2433, L3133 |
| Ring of Jet | Mine | L1013, L1030, L1122, L1216, L1232 |
| Ring of Jet | Opponent | L0110, L0210, L0311 |
| Standard of the Fell Warrior | Mine | L1327 |
| Standard of the Fell Warrior | Opponent | L0413, L1013 |
| Twice-Blessed Armour | Mine | L0709, L0725, L1013, L1030 |
| Twice-Blessed Armour | Opponent | L0110, L0210 |
| Witch Hunter's Ward | Mine | L0709, L0725, L0815, L0831 |

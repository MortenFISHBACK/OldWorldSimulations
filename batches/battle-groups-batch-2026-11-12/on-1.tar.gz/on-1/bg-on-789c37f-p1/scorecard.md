# Doctrine scorecard: bg-on-789c37f-p1

### Scorecard: bg-on-789c37f-p1

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0102 | 6 | 1 | Mine | no | 3 | 2 | 1 | 1 | 1 | 0 | 0 | 0 |
| L0102 | 6 | 1 | Opponent | no | 1 | 1 | 2 | 5 | 1 | 0 | 0 | 170 |
| L0118 | 4 | 1 | Mine | no | 0 | 3 | 0 | 2 | 0 | 0 | 0 | 0 |
| L0118 | 4 | 1 | Opponent | no | 0 | 2 | 5 | 6 | 0 | 0 | 0 | 0 |
| L0135 | 3 | 1 | Mine | no | 1 | - | 0 | 2 | 0 | 0 | 0 | 694 |
| L0135 | 3 | 1 | Opponent | no | 8 | 3 | 3 | 2 | 0 | 0 | 0 | 0 |
| L0218 | 2 | 1 | Mine | - | - | 3 | 3 | 2 | 1 | 0 | 0 | 170 |
| L0218 | 2 | 1 | Opponent | - | - | 5 | 1 | 1 | 0 | 0 | 0 | 0 |
| L0235 | 1 | 1 | Mine | no | 1 | 2 | 3 | 3 | 0 | 0 | 0 | 0 |
| L0235 | 1 | 1 | Opponent | no | 5 | 1 | 3 | 3 | 1 | 0 | 0 | 274 |
| L0319 | 1 | 1 | Mine | no | 8 | 3 | 3 | 0 | 0 | 0 | 0 | 760 |
| L0319 | 1 | 1 | Opponent | no | 2 | 2 | 1 | 0 | 1 | 0 | 0 | 0 |
| L0405 | 3 | 1 | Mine | yes | 1 | 5 | 2 | 1 | 1 | 0 | 0 | 0 |
| L0405 | 3 | 1 | Opponent | no | 2 | 3 | 2 | 2 | 0 | 0 | 0 | 548 |
| L0421 | 1 | 1 | Mine | no | 0 | 2 | 3 | 2 | 0 | 0 | 0 | 0 |
| L0421 | 1 | 1 | Opponent | no | 0 | - | 0 | 4 | 1 | 0 | 0 | 447 |
| L0508 | 4 | 1 | Mine | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 633 |
| L0508 | 4 | 1 | Opponent | no | 4 | - | 0 | 5 | 0 | 0 | 0 | 807 |
| L0524 | 2 | 1 | Mine | - | - | - | 0 | 1 | 0 | 0 | 0 | 901 |
| L0524 | 2 | 1 | Opponent | - | - | 2 | 5 | 4 | 0 | 0 | 0 | 0 |
| L0612 | 6 | 1 | Mine | no | 1 | - | 3 | 2 | 0 | 0 | 0 | 743 |
| L0612 | 6 | 1 | Opponent | no | 8 | 3 | 2 | 0 | 1 | 0 | 0 | 330 |
| L0628 | 4 | 1 | Mine | no | 0 | 3 | 2 | 0 | 0 | 0 | 0 | 615 |
| L0628 | 4 | 1 | Opponent | yes | 0 | 2 | 2 | 0 | 0 | 0 | 0 | 0 |
| L0717 | 3 | 1 | Mine | no | 0 | 2 | 4 | 0 | 0 | 0 | 0 | 375 |
| L0717 | 3 | 1 | Opponent | yes | 4 | 2 | 5 | 1 | 0 | 0 | 0 | 175 |
| L0733 | 1 | 1 | Mine | no | 2 | 3 | 2 | 1 | 1 | 0 | 0 | 375 |
| L0733 | 1 | 1 | Opponent | no | 0 | 1 | 0 | 2 | 0 | 0 | 0 | 0 |
| L0823 | 1 | 1 | Mine | yes | 1 | 2 | 1 | 1 | 1 | 0 | 0 | 560 |
| L0823 | 1 | 1 | Opponent | no | 2 | 2 | 2 | 3 | 2 | 0 | 0 | 60 |
| L0913 | 1 | 1 | Mine | no | 0 | 2 | 3 | 1 | 0 | 0 | 0 | 537 |
| L0913 | 1 | 1 | Opponent | no | 8 | 3 | 2 | 0 | 0 | 0 | 0 | 317 |
| L0930 | 6 | 1 | Mine | no | 0 | 4 | 2 | 1 | 0 | 0 | 0 | 995 |
| L0930 | 6 | 1 | Opponent | no | 4 | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| L1021 | 1 | 1 | Mine | no | 5 | 2 | 4 | 0 | 0 | 0 | 0 | 330 |
| L1021 | 1 | 1 | Opponent | no | 0 | - | 1 | 7 | 1 | 0 | 0 | 145 |
| L1114 | 4 | 1 | Mine | no | 3 | 3 | 1 | 0 | 0 | 0 | 0 | 330 |
| L1114 | 4 | 1 | Opponent | no | 0 | 1 | 6 | 0 | 1 | 0 | 0 | 0 |
| L1131 | 3 | 1 | Mine | no | 1 | - | 2 | 0 | 2 | 0 | 0 | 330 |
| L1131 | 3 | 1 | Opponent | no | 3 | 2 | 4 | 2 | 2 | 0 | 0 | 365 |
| L1224 | 6 | 1 | Mine | no | 10 | 2 | 5 | 0 | 1 | 0 | 0 | 330 |
| L1224 | 6 | 1 | Opponent | no | 0 | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L1319 | 5 | 1 | Mine | yes | - | 2 | 3 | 3 | 0 | 0 | 0 | 140 |
| L1319 | 5 | 1 | Opponent | yes | - | 2 | 2 | 2 | 0 | 0 | 0 | 0 |
| L1335 | 3 | 1 | Mine | no | 4 | 2 | 4 | 0 | 0 | 0 | 0 | 140 |
| L1335 | 3 | 1 | Opponent | no | 2 | 2 | 8 | 0 | 0 | 0 | 0 | 414 |
| L1431 | 3 | 1 | Mine | yes | 1 | 2 | 4 | 0 | 0 | 0 | 0 | 0 |
| L1431 | 3 | 1 | Opponent | no | 0 | - | 1 | 0 | 1 | 0 | 0 | 562 |
| L1527 | 3 | 1 | Mine | no | 6 | 2 | 3 | 0 | 0 | 0 | 0 | 0 |
| L1527 | 3 | 1 | Opponent | no | 0 | 2 | 5 | 1 | 0 | 0 | 0 | 0 |
| L1625 | 5 | 1 | Mine | no | - | 2 | 5 | 2 | 0 | 0 | 0 | 200 |
| L1625 | 5 | 1 | Opponent | yes | - | 1 | 3 | 2 | 0 | 0 | 0 | 0 |
| L1723 | 1 | 1 | Mine | no | 2 | 2 | 4 | 0 | 1 | 0 | 0 | 0 |
| L1723 | 1 | 1 | Opponent | no | 0 | 2 | 7 | 2 | 0 | 0 | 0 | 0 |
| L1823 | 5 | 1 | Mine | yes | - | 3 | 3 | 1 | 1 | 0 | 0 | 0 |
| L1823 | 5 | 1 | Opponent | yes | - | 2 | 5 | 1 | 0 | 0 | 0 | 0 |
| L1923 | 3 | 1 | Mine | yes | 3 | 2 | 6 | 0 | 1 | 0 | 0 | 0 |
| L1923 | 3 | 1 | Opponent | no | 2 | 1 | 5 | 0 | 0 | 0 | 0 | 0 |
| L2025 | 3 | 1 | Mine | yes | 2 | 3 | 3 | 0 | 0 | 0 | 0 | 420 |
| L2025 | 3 | 1 | Opponent | no | 0 | 3 | 6 | 1 | 0 | 0 | 0 | 0 |
| L2127 | 3 | 1 | Mine | - | - | - | - | - | - | - | - | - |
| L2127 | 3 | 1 | Opponent | - | - | - | - | - | - | - | - | - |
| L2231 | 5 | 1 | Mine | yes | - | 2 | 2 | 1 | 0 | 0 | 0 | 72 |
| L2231 | 5 | 1 | Opponent | no | - | 1 | 7 | 0 | 4 | 0 | 0 | 541 |
| L2335 | 1 | 1 | Mine | no | 0 | 1 | 4 | 0 | 0 | 0 | 0 | 60 |
| L2335 | 1 | 1 | Opponent | no | 0 | 3 | 4 | 2 | 0 | 0 | 0 | 0 |
| L2531 | 5 | 1 | Mine | yes | - | 2 | 4 | 4 | 0 | 0 | 0 | 0 |
| L2531 | 5 | 1 | Opponent | yes | - | 4 | 1 | 1 | 1 | 0 | 0 | 170 |
| L2730 | 6 | 1 | Mine | no | 0 | 4 | 5 | 3 | 0 | 0 | 0 | 0 |
| L2730 | 6 | 1 | Opponent | no | 2 | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L2934 | 6 | 1 | Mine | no | 6 | 2 | 5 | 0 | 0 | 0 | 0 | 170 |
| L2934 | 6 | 1 | Opponent | no | 0 | 3 | 4 | 1 | 0 | 0 | 0 | 56 |
| **Average** | | | Mine | 27% | 2.2 | 2.5 | 2.8 | 1.0 | 0.3 | 0.0 | 0.0 | 282.3 |
| **Average** | | | Opponent | 18% | 2.0 | 2.2 | 3.2 | 1.8 | 0.5 | 0.0 | 0.0 | 153.7 |

### KPIs: bg-on-789c37f-p1

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Winner chose to follow up after the loser gave ground |  | 98% (56 of 57); on the table 100% | 94% (50 of 53); on the table 94% | 96% (106 of 110); on the table 97% |
| Winner chose to pursue after the loser fell back in good order |  | 83% (10 of 12); on the table 92% | 100% (9 of 9); on the table 100% | 90% (19 of 21); on the table 95% |
| Winner chose to pursue after the loser fled |  | 69% (20 of 29); on the table 76% | 73% (24 of 33); on the table 79% | 71% (44 of 62); on the table 77% |
| Winner chose to follow up or pursue (all three) |  | 88% (86 of 98); on the table 92% | 87% (83 of 95); on the table 89% | 88% (169 of 193); on the table 91% |
| Magic missiles tried each own turn | 50%+ | 26% (84 of 327) | 26% (54 of 206) | 26% (138 of 533) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 38% (84 of 222) | 39% (54 of 139) | 38% (138 of 361) |
| Points that never fought | lower | 35% (24265 of 69485) | 30% (20871 of 69889) | 32% (45136 of 139374) |
|   infantry points that never fought | lower | 47% (7505 of 16095) | 53% (6923 of 13174) | 49% (14428 of 29269) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 53% (143 of 270) | 57% (166 of 289) | 55% (309 of 559) |
| Bound items with a magic missile used (at least once a game) |  | 86% (19 of 22); 1.8 uses a game | 70% (14 of 20); 1.0 uses a game | 79% (33 of 42); 1.4 uses a game |
| Bound items with another spell used |  | 69% (11 of 16); 0.6 uses a game | 12% (1 of 8); 0.1 uses a game | 50% (12 of 24); 0.4 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 63% (12 of 19); 0.3 uses a game | 58% (7 of 12); 0.2 uses a game | 61% (19 of 31); 0.3 uses a game |
|   their share of the points of units over 100 pts | lower | 47% (27391 of 58030) | 52% (32063 of 61153) | 50% (59454 of 119183) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.5 (22%) | 1.2 (29%) | 2.7 (25%) |
| MARCHED: its unit marched | 1.9 (29%) | 0.8 (18%) | 2.7 (25%) |
| CHARGED: its unit charged | 0.3 (5%) | 0.2 (4%) | 0.5 (4%) |
| IN COMBAT: engaged in combat | 1.2 (19%) | 0.6 (14%) | 1.9 (17%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.2 (4%) | 0.2 (2%) |
| FLEEING: fleeing | 0.2 (4%) | 0.2 (5%) | 0.4 (4%) |
| GONE: slain | 1.0 (14%) | 1.0 (24%) | 2.0 (18%) |
| OFF THE TABLE: off the table or not arrived | 0.4 (7%) | 0.1 (1%) | 0.5 (5%) |
| STUPIDITY: Stupidity | 0.1 (2%) | 0.0 (1%) | 0.1 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 3.8 | 1.4 | 1.4 | 3.8 | 0.2 | 2.1 |
| not cast | 3.8 | 2.9 | 3.3 | 11.0 | 2.0 | 21.2 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) | 0.0 (0%) | 1.8 (8%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.9 (32%) | 0.2 (7%) | 2.7 (25%) | 0.4 (21%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.7 (25%) | 0.5 (25%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.5 (4%) | 0.1 (5%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.2 (5%) | 0.2 (8%) | 0.5 (14%) | 1.9 (17%) | 0.3 (15%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.2 (4%) | 0.3 (12%) | 0.3 (10%) | 0.2 (2%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.2 (7%) | 0.1 (4%) | 0.0 (1%) | 0.4 (4%) | 0.0 (0%) | 0.6 (3%) |
| GONE: slain | 0.9 (23%) | 0.6 (20%) | 0.7 (21%) | 2.0 (18%) | 0.6 (29%) | 2.8 (13%) |
| OFF THE TABLE: off the table or not arrived | 0.2 (5%) | 0.1 (4%) | 0.1 (3%) | 0.5 (5%) | 0.0 (0%) | 0.4 (2%) |
| STUPIDITY: Stupidity | 0.1 (2%) | 0.1 (3%) | 0.0 (1%) | 0.1 (1%) | 0.0 (0%) | 0.4 (2%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (2%) | 0.3 (11%) | 0.0 (0%) | 0.0 (0%) | 0.1 (5%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.9 (51%) | 0.2 (7%) | 1.4 (42%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 15.2 (72%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.2 a game | 0.4 a game | 0.8 a game |
| stood (cast and not dispelled) | 64% (23 of 36) | 54% (7 of 13) | 61% (30 of 49) |
| the unit moved after it | 70% (16 of 23) | 86% (6 of 7) | 73% (22 of 30) |
| it charged on its next turn | 4% (1 of 23) | 0% (0 of 7) | 3% (1 of 30) |
| the enemy charged it first | 22% (5 of 23) | 29% (2 of 7) | 23% (7 of 30) |
| it fought by the end of its next turn | 13% (3 of 23) | 14% (1 of 7) | 13% (4 of 30) |
| it moved out of a charge the enemy had planned (not charged first) | 48% (11 of 23) | 14% (1 of 7) | 40% (12 of 30) |
| none of these (no charge, no fight, no charge escaped) | 26% (6 of 23) | 57% (4 of 7) | 33% (10 of 30) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 60% (538 of 895) | 56% (325 of 584) | 58% (863 of 1479) |
|   cavalry | 46% (43 of 93) | 67% (74 of 110) | 58% (117 of 203) |
|   character | 45% (48 of 106) | 30% (35 of 117) | 37% (83 of 223) |
|   chariot | 45% (36 of 80) | 78% (21 of 27) | 53% (57 of 107) |
|   infantry | 56% (157 of 280) | 58% (137 of 238) | 57% (294 of 518) |
|   monster | 39% (17 of 44) | 33% (9 of 27) | 37% (26 of 71) |
|   war machine | 81% (237 of 292) | 75% (49 of 65) | 80% (286 of 357) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 3.4 (35%) | 2.1 (30%) | 5.6 (33%) |
| CHARGED: it charged | 1.4 (14%) | 1.7 (23%) | 3.1 (18%) |
| FLEEING: it fled or was fleeing | 0.1 (1%) | 0.0 (0%) | 0.2 (1%) |
| IN COMBAT: it fought this turn or the last | 0.7 (7%) | 0.6 (8%) | 1.2 (7%) |
| MOVED: a war machine that moved | 0.0 (0%) | 0.1 (1%) | 0.1 (0%) |
| FREE: none of these - no target in range or sight, or held its fire | 0.2 (2%) | 0.0 (0%) | 0.2 (1%) |
| NO TARGET IN RANGE | 1.0 (10%) | 1.0 (14%) | 2.0 (12%) |
| ONLY IN COMBAT: the only targets were in combat | 0.6 (6%) | 0.4 (5%) | 0.9 (6%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.9 (20%) | 0.8 (11%) | 2.8 (16%) |
| SHELTERED: the target was sheltered | 0.3 (3%) | 0.4 (6%) | 0.7 (4%) |
| STUPIDITY | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR | 0.2 (2%) | 0.2 (2%) | 0.4 (2%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 4.7 | 1.2 | 81% | 5.9 pts | 28 pts |
| character | 2.6 | 0.7 | 78% | 7.2 pts | 19 pts |
| chariot | 1.6 | 1.0 | 67% | 10.3 pts | 17 pts |
| infantry | 12.3 | 4.3 | 75% | 8.2 pts | 101 pts |
| monster | 0.8 | 0.3 | 75% | 12.5 pts | 10 pts |
| war machine | 7.9 | 6.6 | 62% | 26.9 pts | 214 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.4 | 6.0 | 5.2 |
| Charges that made contact a game | 3.3 | 4.3 | 3.8 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.16 declared, 0.79 contact (19 units) | 0.80 declared, 0.53 contact (15 units) | 1.00 declared, 0.68 contact (34 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.60 declared, 0.60 contact (5 units) | 1.11 declared, 0.89 contact (9 units) | 0.93 declared, 0.79 contact (14 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.53 declared, 0.41 contact (249 units) | 0.68 declared, 0.49 contact (284 units) | 0.61 declared, 0.45 contact (533 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 49% (33 of 68) | 57% (12 of 21) | 43% (3 of 7) | 50% (48 of 96) |
| Character in a unit | 73% (24 of 33) | 64% (16 of 25) | 100% (2 of 2) | 70% (42 of 60) |
| Character on its own | 80% (40 of 50) | 60% (21 of 35) | 21% (13 of 62) | 50% (74 of 147) |
| Chariot | 79% (11 of 14) | 60% (6 of 10) | - | 71% (17 of 24) |
| Infantry | 45% (39 of 87) | 49% (17 of 35) | 50% (1 of 2) | 46% (57 of 124) |
| Monster | 56% (18 of 32) | 78% (7 of 9) | - | 61% (25 of 41) |
| Monstrous | 91% (10 of 11) | 29% (4 of 14) | - | 56% (14 of 25) |
| War Machines | 76% (31 of 41) | 100% (1 of 1) | - | 76% (32 of 42) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 6 | 78% (14 of 18); on the table 89% | 40% (55 of 138) | 35% | 45% (15 of 33) | 78% (7 of 9); 4.8 uses a game | 100% (3 of 3); 1.3 uses a game | 89% (8 of 9); 1.3 uses a game |
| Chaos Dwarfs | 3 | 50% (3 of 6); on the table 67% | 12% (3 of 24) | 40% | 46% (11 of 24) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 0.3 uses a game |
| Dwarfen Mountain Holds | 5 | 67% (6 of 9); on the table 67% | - | 65% | 68% (28 of 41) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 6 | 86% (6 of 7); on the table 100% | 33% (12 of 36) | 58% | 61% (39 of 64) | 0.0 uses a game | 100% (2 of 2); 0.5 uses a game | 25% (1 of 4); 0.2 uses a game |
| Grand Cathay | 5 | 82% (9 of 11); on the table 82% | 14% (15 of 108) | 33% | 55% (24 of 44) | 100% (12 of 12); 7.4 uses a game | 0% (0 of 1); 0.0 uses a game | 60% (3 of 5); 0.6 uses a game |
| High Elf Realms | 6 | 91% (21 of 23); on the table 91% | 13% (4 of 30) | 23% | 39% (19 of 49) | 100% (5 of 5); 3.0 uses a game | 39% (7 of 18); 2.5 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | 100% (4 of 4); on the table 100% | - | 18% | 33% (2 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Lizardmen | 2 | 100% (3 of 3); on the table 100% | - | 30% | 43% (6 of 14) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 3 | 89% (8 of 9); on the table 89% | 0% (0 of 12) | 33% | 71% (15 of 21) | 33% (1 of 3); 0.3 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 3 | 57% (4 of 7); on the table 57% | 33% (12 of 36) | 7% | 58% (14 of 24) | 0.0 uses a game | 0.0 uses a game | 100% (3 of 3); 1.0 uses a game |
| Skaven | 3 | 100% (2 of 2); on the table 100% | 17% (4 of 24) | 44% | 68% (17 of 25) | 50% (1 of 2); 1.0 uses a game | 0.0 uses a game | 33% (1 of 3); 0.3 uses a game |
| Tomb Kings of Khemri | 6 | 86% (18 of 21); on the table 90% | 17% (2 of 12) | 26% | 20% (6 of 30) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 7 | 100% (45 of 45); on the table 100% | 31% (15 of 48) | 21% | 59% (26 of 44) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 8 | 88% (15 of 17); on the table 94% | 17% (5 of 30) | 20% | 65% (48 of 74) | 100% (4 of 4); 0.9 uses a game | 0.0 uses a game | 50% (1 of 2); 0.1 uses a game |
| Wood Elf Realms | 6 | 100% (11 of 11); on the table 100% | 30% (9 of 30) | 28% | 59% (39 of 66) | 33% (2 of 6); 0.7 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (bg-on-789c37f-p1, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 53% (48) | 58% (41) | 55% (89) |
| ...free all their last turn and able to turn (per game) | 0.94 | 0.75 | 1.69 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.19 | 0.19 | 0.39 |
| ...with the charger already in that arc before they moved (per game) | 0.67 | 0.53 | 1.19 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 1.17 | 0.67 | 1.83 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.72 | 0.53 | 1.25 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 10.64 | 9.72 | 20.36 |

### Quality by phase: bg-on-789c37f-p1

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.1 | 3.4 |
| Strategy | Charge objectives carried out (made contact) | 49% (68 of 139) | 46% (84 of 184) |
| Strategy | Shoot objectives carried out (shot that target) | 54% (186 of 346) | 65% (99 of 152) |
| Strategy | Close-in objectives charged next turn | 13% (21 of 161) | 19% (36 of 193) |
| Strategy | Support requests answered (helper made contact too) | 50% (10 of 20) | 61% (17 of 28) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (1 of 1) | 50% (2 of 4) |
| Strategy | Hexes on a unit its side charged or shot that turn | 44% (7 of 16) | 64% (7 of 11) |
| Strategy | Joined characters whose unit fought | 46% (23 of 50) | 70% (26 of 37) |
| Strategy | Lone characters that fought | 83% (77 of 93) | 80% (74 of 93) |
| Movement | Charges halted short of contact | 0.1 | 0.2 |
| Movement | Idle units | 1.0 | 1.8 |
| Movement | Points that never moved of their own | 282.3 | 153.7 |
| Movement | Fights charged into per game | 3.0 | 3.7 |
| Movement | Charges with odds: long shots (under 50%) | 12 of 87, net +99 | 18 of 106, net +124 |
| Movement | Charges with odds: sweet spot (55-75%) | 14 of 87, net -20 | 11 of 106, net +41 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 16 of 87, net +196 | 7 of 106, net +119 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 27 of 87, net +118 | 43 of 106, net +98 |
| Shooting | Shots by shooting units (incl. breath weapons) | 9.4 | 8.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 42% (144 of 339) | 53% (166 of 312) |
| Shooting | Points destroyed by shooting units | 71.7 | 51.9 |
| Shooting | War machine shots | 6.6 | 1.4 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 54% (129 of 237) | 33% (16 of 49) |
| Shooting | Points destroyed by war machines | 109.0 | 35.1 |
| Magic | Magic missiles cast | 1.4 | 0.9 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 35% (18 of 52) | 42% (14 of 33) |
| Magic | Wounds caused by magic missiles | 3.6 | 1.2 |
| Magic | Wounds caused by other spells | 1.8 | 0.6 |
| Magic | Points destroyed by magic (all spells) | 71.0 | 38.2 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.2 / 0.5 / 1.1 / 0.1 | 1.7 / 0.4 / 0.5 / 0.0 |
| Combat | Points destroyed in combat | 332.4 | 419.1 |
| Combat | Points run down | 105.3 | 44.5 |
| Combat | Net points per charged fight, damage counted | +98 | +97 |
| Combat | Net per 100 charger points, damage counted | +35.9 | +35.7 |
| Combat | First round won (charged fights) | 63% | 54% |
| Combat | Net points per charged fight | +104 | +92 |
| Combat | Net points per supported fight / lone fight | +224 / +93 | +116 / +88 |
| Combat | Charged fights on a top-3 enemy unit | 36 of 104 | 52 of 130 |
| Game | Points lost | 756.3 | 855.0 |
| Game | VP from objectives | 593.7 | 581.7 |
| Game | Lone holders (player turns) | 2.2 | 2.0 |

- Mine won / drew / lost: 17 / 3 / 15 of 35 ended games (of 36); mean margin (Mine - Opponent) +94 VP
- The side that went first won 17 of 32 games with a winner
- Points traded per game (both sides' losses): 1611
- Games not ended: 1 (L2127-1); findings 1, warnings 0

### Opponent rules: bg-on-789c37f-p1

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.6 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 3.5 |
| ALREADY CARRIED | 0.0 | +0.0 | 0.0 | 3.6 | - | - | - | - |
| ARRIVAL HUNT | - | - | - | - | 0.0 | +0.2 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.5 | +0.0 | 0.0 | 13.9 | 0.1 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | 1.1 | +10.2 | 0.0 | 27.7 | 0.7 | +7.6 | 0.0 | 35.0 |
| BEST PREY | 3.9 | +276.2 | 153.9 | 172.0 | 4.8 | +339.8 | 193.9 | 133.7 |
| BEST PRIZE | 0.1 | -2.5 | 0.0 | 1.9 | 0.1 | -1.0 | 0.0 | 0.0 |
| BLOCKED CHARGE HANDED OVER | 0.0 | +4.0 | 4.0 | 0.0 | - | - | - | - |
| BLOCKED CHARGE SKIPPED | 0.2 | +0.0 | 7.1 | 0.0 | 0.0 | +0.0 | 1.7 | 0.0 |
| BLOCKED WHEEL | 0.6 | +5.3 | 0.0 | 5.6 | 0.2 | +18.9 | 0.0 | 16.8 |
| BOMBING RUN | 0.1 | +3.8 | 5.6 | 8.3 | - | - | - | - |
| BOUND ASSAILMENT | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CANNON PLAN MISSED | 0.7 | +0.0 | 70.3 | 11.5 | 0.0 | +0.0 | 3.5 | 0.0 |
| CANNON PLANNED TARGET | 5.2 | +205.6 | 448.3 | 94.6 | 1.2 | +43.8 | 98.7 | 0.0 |
| CANNON SIGHT KEPT | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CAST JOB | 0.6 | +37.0 | 82.5 | 0.0 | 0.5 | +12.0 | 26.8 | 33.4 |
| CASTER AWAY FROM SCREEN | 0.3 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.7 | +104.2 | 88.5 | 0.0 | 0.1 | +5.1 | 1.5 | 0.0 |
| CASTS AFTER FRIENDS | 0.7 | +0.0 | 0.0 | 33.2 | 0.2 | +0.0 | 0.0 | 13.5 |
| CASTS FROM BEHIND | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.1 | +0.7 | 0.0 | 0.0 | 0.0 | +0.1 | 0.0 | 0.0 |
| CATCH ODDS | 0.0 | +1.5 | 0.0 | 0.0 | 0.0 | +0.2 | 0.0 | 0.0 |
| CHAFF PASSED | 0.2 | -1.1 | 5.6 | 17.1 | 0.3 | -0.7 | 0.0 | 1.8 |
| CHARGE NOW WEIGHED | 0.5 | -35.6 | 16.1 | 9.5 | 0.5 | -77.4 | 7.2 | 21.5 |
| CHARIOT NO STATIC JOB | 0.7 | +0.0 | 10.4 | 19.8 | 0.6 | +0.0 | 2.1 | 7.8 |
| CHEAP HELPER | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 17.5 | 0.0 |
| CONTINUE AHEAD WEIGHED | 0.0 | +0.0 | 4.5 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | 0.6 | +35.5 | 28.7 | 33.5 | 0.2 | +27.8 | 10.2 | 28.7 |
| COUNTER-CHARGE COVER | 8.9 | +713.3 | 0.0 | 195.8 | 7.6 | +665.3 | 0.0 | 210.3 |
| EDGE GIVE GROUND | 0.1 | +1.1 | 8.5 | 4.2 | 0.2 | +4.0 | 45.6 | 0.0 |
| ELIXIR WORTH | 0.1 | +0.5 | 0.0 | 8.2 | 0.1 | +0.1 | 0.0 | 0.0 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ESCORT | 0.5 | +19.1 | 0.0 | 10.3 | 0.3 | +18.5 | 0.0 | 2.1 |
| FACES THE THREAT | 1.2 | +98.8 | 0.0 | 51.5 | 0.7 | +49.9 | 0.0 | 27.6 |
| FIGHT LIFT | 0.0 | +1.1 | 16.6 | 0.0 | - | - | - | - |
| FIRE AND FLEE | 0.1 | +0.9 | 12.8 | 4.7 | 0.1 | +1.3 | 6.6 | 3.2 |
| FOCUS FIRE | - | - | - | - | 0.0 | +0.1 | 0.0 | 0.0 |
| FOLLOW UP WEIGHED | 1.0 | +139.0 | 0.0 | 37.7 | 1.1 | +139.0 | 0.0 | 26.2 |
| FRIENDS SHOTS CHECKED | 0.2 | +16.1 | 0.0 | 29.4 | 0.2 | +18.8 | 0.0 | 10.6 |
| GIVES UP | 1.0 | -20.9 | 103.0 | 33.9 | 1.4 | -52.3 | 152.6 | 61.9 |
| GIVES UP ITS SCREEN | 0.5 | -13.9 | 42.3 | 10.2 | 0.9 | -14.8 | 71.2 | 8.6 |
| GROUND FLIERS | 0.0 | +0.1 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| GROUP AIM | 0.3 | +4.4 | 0.0 | 13.3 | 0.4 | +12.2 | 0.0 | 4.4 |
| GROUP BROKEN | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |
| HELPER ALREADY ASKED | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 5.3 | 0.0 |
| HELPER UNSEEN | 0.2 | +0.0 | 7.3 | 0.0 | 0.4 | +0.0 | 60.4 | 6.8 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.8 | +0.0 | 0.0 | 0.0 |
| HORN WORTH | - | - | - | - | 0.0 | +0.6 | 0.0 | 0.0 |
| HUNT ADVANCE | 0.1 | +0.3 | 25.2 | 0.0 | 0.1 | +2.1 | 3.5 | 2.9 |
| HUNT IN PAIRS | 0.4 | +31.4 | 0.0 | 5.7 | 0.4 | +31.1 | 0.0 | 1.9 |
| HUNT KEPT | 0.0 | +0.0 | 5.9 | 0.0 | 0.0 | +0.0 | 2.8 | 0.0 |
| HUNT RESULT | 0.1 | +26.9 | 0.0 | 0.0 | 0.1 | +11.5 | 2.8 | 4.1 |
| HUNT THE GUNS | 0.1 | +29.8 | 23.9 | 0.0 | 0.1 | +28.0 | 3.5 | 2.9 |
| JOINT CHARGE PLAN | 0.1 | +7.4 | 0.0 | 0.0 | 0.1 | +2.0 | 0.0 | 4.5 |
| KEEPS ITS PREY | 0.2 | +1.5 | 1.7 | 14.6 | 0.2 | +0.9 | 7.1 | 11.7 |
| KEEPS ITS TARGET | 1.5 | +44.2 | 144.0 | 16.5 | 2.6 | +77.5 | 199.3 | 121.0 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KILLS COUNT | 1.6 | +84.4 | 147.7 | 40.0 | 2.4 | +88.0 | 182.4 | 48.7 |
| KILLS COUNT NEXT TURN | 8.0 | +339.0 | 386.8 | 231.1 | 9.8 | +440.2 | 306.8 | 280.9 |
| LONE CHARACTER SAFE SPOT | 0.3 | +0.4 | 8.8 | 19.4 | 0.5 | +15.5 | 11.9 | 36.0 |
| LONE WIZARD HOLDS BACK | 0.9 | +0.0 | 43.2 | 21.8 | 1.1 | +0.0 | 40.0 | 76.2 |
| LONE WIZARD KEPT IN | 0.7 | +49.1 | 0.0 | 0.0 | 0.2 | +24.5 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 0.9 | +37.9 | 17.6 | 14.8 | 0.7 | +32.3 | 8.9 | 10.7 |
| MANOEUVRE | 0.2 | +14.3 | 0.0 | 1.9 | 0.1 | +0.4 | 0.0 | 1.7 |
| MARCH AT ESCAPER | 0.0 | +0.0 | 0.0 | 0.0 | 0.3 | +2.0 | 0.0 | 7.8 |
| MARCH ODDS | 1.0 | +92.1 | 39.7 | 5.7 | 0.6 | +41.1 | 41.7 | 19.5 |
| MISSILES IN THE MOVE | 3.4 | +175.6 | 0.0 | 32.1 | 2.7 | +51.8 | 0.0 | 88.9 |
| MISSILES NEXT TURN | 4.6 | +117.9 | 0.0 | 74.6 | 3.9 | +39.4 | 0.0 | 144.8 |
| MODEL FACING | 0.2 | +53.6 | 0.0 | 0.0 | - | - | - | - |
| MOVE AND CAST | 0.2 | +7.5 | 0.0 | 0.0 | 0.1 | +6.4 | 0.0 | 0.0 |
| MOVE SPELL IN RANGE | 0.1 | +3.8 | 0.0 | 16.1 | 0.1 | +0.5 | 0.0 | 7.6 |
| MOVE SPELL OUT OF RANGE | 0.2 | -42.4 | 0.0 | 28.3 | 0.0 | -0.1 | 0.0 | 7.6 |
| MOVE SPELL SPOT | 0.2 | +0.0 | 0.0 | 22.2 | 0.1 | +0.0 | 0.0 | 0.0 |
| MOVES UNITS SPELL | 0.1 | +3.4 | 0.0 | 0.0 | 0.1 | +1.8 | 0.0 | 0.0 |
| NEEDED THERE | - | - | - | - | 0.1 | +12.0 | 0.0 | 0.0 |
| NO RALLY LEFT | 0.0 | +0.7 | 0.0 | 0.0 | 0.1 | +6.1 | 0.0 | 0.0 |
| NOT NEEDED | 0.2 | -9.5 | 28.6 | 1.9 | 0.6 | -24.7 | 65.9 | 0.8 |
| NOT TURNED | 10.6 | +213.5 | 0.0 | 242.7 | 9.7 | +185.6 | 0.0 | 256.3 |
| NOT WORTH A CAST | 0.9 | -0.7 | 0.0 | 12.5 | 0.2 | -0.1 | 0.0 | 15.0 |
| OPENS A LANE | 0.1 | +0.1 | 6.3 | 0.0 | 0.1 | +0.2 | 5.1 | 0.0 |
| OPENS UP | 0.2 | +15.3 | 13.7 | 0.0 | 0.1 | +7.2 | 2.1 | 7.9 |
| OVERRUNS AWAY | 0.8 | +21.5 | 97.9 | 20.8 | 0.6 | +17.7 | 56.2 | 45.7 |
| PATHS CROSS | 2.3 | +139.4 | 0.0 | 24.3 | 2.7 | +190.8 | 0.0 | 98.7 |
| PERIAPT WORTH | - | - | - | - | 0.0 | +2.8 | 0.0 | 0.0 |
| PLAN LEADS | 0.9 | +74.3 | 36.5 | 16.1 | 1.0 | +81.2 | 23.0 | 6.9 |
| PLAN RESULT | 36.7 | +1456.1 | 1494.9 | 953.9 | 37.6 | +1230.0 | 1193.1 | 1150.9 |
| PURSUES BIG PREY | 0.1 | -3.6 | 0.0 | 0.0 | 0.1 | -10.3 | 0.0 | 0.0 |
| PURSUES ON | 0.0 | +3.6 | 0.0 | 0.0 | - | - | - | - |
| RAIDS THE BAGGAGE | - | - | - | - | 0.0 | +6.6 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE NEXT TURN | 0.1 | +6.6 | 0.0 | 2.0 | 0.1 | +7.7 | 0.0 | 0.0 |
| REDIRECT COUNTER | 3.6 | +200.1 | 0.0 | 61.6 | 5.0 | +306.9 | 0.0 | 67.4 |
| REDIRECT WEIGHED | 0.2 | +7.8 | 7.9 | 9.9 | 0.4 | +4.8 | 4.9 | 12.1 |
| RESTRAINS TO SHOOT | 0.1 | +10.9 | 0.0 | 12.8 | 0.1 | +4.0 | 0.0 | 0.0 |
| RISK BY ARC | 2.5 | +83.3 | 204.4 | 83.2 | 3.2 | +55.7 | 272.7 | 113.4 |
| SAFER THAN THE JOB | 0.7 | +58.9 | 0.0 | 44.3 | 0.5 | +39.1 | 0.0 | 0.0 |
| SCOUT SPOT | 0.4 | +0.6 | 0.0 | 0.9 | 0.3 | +0.5 | 0.0 | 0.0 |
| SCOUT WAITS | 0.4 | +0.0 | 0.0 | 0.9 | 0.3 | +0.0 | 0.0 | 0.0 |
| SEARCH SPOT | 1.1 | +79.1 | 0.0 | 22.0 | 1.1 | +80.8 | 0.0 | 13.7 |
| SECOND HUNTER | 0.0 | -0.0 | 5.9 | 0.0 | - | - | - | - |
| SELF MOVE SPELL | 0.2 | +28.4 | 0.0 | 29.1 | 0.3 | +1.9 | 0.0 | 0.0 |
| SET UP TOGETHER | 1.7 | +72.1 | 43.6 | 27.6 | 1.7 | +74.6 | 22.4 | 50.5 |
| SHOOTERS IN TWO RANKS | 0.4 | +0.9 | 0.0 | 0.0 | 0.2 | +0.6 | 0.0 | 0.0 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 3.3 | 0.0 | +0.0 | 0.0 | 3.8 |
| SHOT REPLANNED | 0.6 | +0.0 | 118.8 | 24.2 | 0.2 | +0.0 | 32.8 | 12.5 |
| SHOTS IN THE MOVE | 13.7 | +593.7 | 0.0 | 242.4 | 7.6 | +184.9 | 0.0 | 155.9 |
| SPELL CATCH ODDS | 0.1 | -1.1 | 6.5 | 0.0 | - | - | - | - |
| SPELL SETS UP CHARGE | 0.0 | +2.5 | 0.0 | 0.0 | - | - | - | - |
| SPELL WORTH | 1.0 | +23.1 | 106.8 | 84.5 | 1.6 | +38.8 | 57.3 | 63.8 |
| STANDS TO CAST | 0.1 | +3.5 | 1.7 | 0.0 | 0.0 | +0.2 | 0.0 | 1.7 |
| STOPS | 0.0 | +1.6 | 4.6 | 0.0 | 0.0 | +1.6 | 0.0 | 0.0 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 18.6 |
| SUPPORT JOB KEPT | - | - | - | - | 0.0 | +0.0 | 4.2 | 3.5 |
| SURE CHARGE BEATS ADVANCE | 0.2 | -7.7 | 12.9 | 0.9 | 0.3 | -13.2 | 18.0 | 8.6 |
| THROUGH LINE OF FIRE | 0.6 | +35.3 | 0.0 | 14.3 | 0.2 | +18.4 | 0.0 | 28.2 |
| TURN WORTH | 0.6 | -38.9 | 44.2 | 21.8 | 0.3 | -13.3 | 20.9 | 3.5 |
| TWO OR MORE ARRIVE | 0.5 | +4.5 | 11.8 | 6.9 | 0.5 | +3.5 | 0.0 | 5.7 |
| WEARS DOWN | 0.9 | +54.2 | 88.7 | 45.1 | 1.1 | +31.4 | 120.5 | 46.0 |
| WHO HITS BACK | 0.3 | +26.6 | 0.0 | 20.3 | 0.2 | +22.8 | 0.0 | 19.4 |
| WHOLE FIGHT | 0.2 | +8.4 | 12.6 | 3.5 | 0.4 | +4.9 | 74.9 | 5.9 |
| WHOLE FIGHT GAIN | 0.6 | +60.5 | 45.7 | 14.3 | 0.7 | +71.2 | 72.8 | 19.5 |

### Rule changes: bg-on-789c37f-p1

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| KILLS COUNT NEXT TURN | 639 | 633 | 194 | 5.39 | +9341 | +48.1 |
| BEST PREY | 312 | 307 | 146 | 4.06 | +7342 | +50.3 |
| COUNTER-CHARGE COVER | 594 | 253 | 78 | 2.17 | +5536 | +71.0 |
| FOLLOW UP WEIGHED | 75 | 75 | 75 | 2.08 | +10010 | +133.5 |
| CANNON PLANNED TARGET | 232 | 232 | 61 | 1.69 | -812 | -13.3 |
| ARTILLERY RE-ROLL WEIGHED | 59 | 59 | 59 | 1.64 | +0 | +0.0 |
| ADVANCE LANE KEPT | 47 | 47 | 47 | 1.31 | +0 | +0.0 |
| CANNON SIGHT KEPT | 47 | 47 | 47 | 1.31 | +0 | +0.0 |
| SET UP TOGETHER | 122 | 94 | 47 | 1.31 | +1873 | +39.9 |
| MARCH ODDS | 58 | 50 | 46 | 1.28 | +1468 | +31.9 |
| HOLDS AMBUSHERS | 44 | 44 | 44 | 1.22 | +0 | +0.0 |
| KEEPS ITS TARGET | 146 | 145 | 43 | 1.19 | +717 | +16.7 |
| RISK BY ARC | 207 | 189 | 43 | 1.19 | +1436 | +33.4 |
| KILLS COUNT | 145 | 131 | 42 | 1.17 | +2136 | +50.9 |
| CHARGE NOW WEIGHED | 36 | 36 | 36 | 1.00 | +2667 | +74.1 |
| LONE WIZARD KEPT IN | 34 | 34 | 34 | 0.94 | +2648 | +77.9 |
| SHOT REPLANNED | 30 | 30 | 30 | 0.83 | +0 | +0.0 |
| CAST JOB | 42 | 40 | 26 | 0.72 | +687 | +26.4 |
| SCOUT WAITS | 26 | 26 | 26 | 0.72 | +0 | +0.0 |
| WHOLE FIGHT GAIN | 48 | 40 | 26 | 0.72 | +1170 | +45.0 |
| CASTING BLOCK | 29 | 27 | 25 | 0.69 | +2238 | +89.5 |
| CHARIOT NO STATIC JOB | 46 | 46 | 24 | 0.67 | -1779 | -74.1 |
| PLAN LEADS | 67 | 67 | 24 | 0.67 | +1419 | +59.1 |
| SHOOTERS IN TWO RANKS | 23 | 23 | 23 | 0.64 | +53 | +2.3 |
| LONE WIZARD HOLDS BACK | 70 | 70 | 22 | 0.61 | -1284 | -58.4 |
| REDIRECT WEIGHED | 22 | 22 | 22 | 0.61 | +661 | +30.1 |
| MAKE SURE TOGETHER | 58 | 42 | 21 | 0.58 | +692 | +33.0 |
| REDIRECT COUNTER | 309 | 81 | 21 | 0.58 | +892 | +42.5 |
| CASTER AWAY FROM SCREEN | 19 | 19 | 19 | 0.53 | +0 | +0.0 |
| WHO HITS BACK | 19 | 19 | 19 | 0.53 | -1082 | -57.0 |
| CHAFF PASSED | 17 | 17 | 17 | 0.47 | -68 | -4.0 |
| FRIENDS SHOTS CHECKED | 17 | 17 | 17 | 0.47 | +1256 | +73.9 |
| SURE CHARGE BEATS ADVANCE | 17 | 17 | 17 | 0.47 | -753 | -44.3 |
| WEARS DOWN | 75 | 69 | 16 | 0.44 | +434 | +27.1 |
| CASTS FROM BEHIND | 14 | 14 | 14 | 0.39 | +0 | +0.0 |
| STUCK PIVOT | 12 | 12 | 12 | 0.33 | +0 | +0.0 |
| RESTRAINS TO SHOOT | 9 | 9 | 9 | 0.25 | +537 | +59.6 |
| MODEL FACING | 8 | 8 | 8 | 0.22 | +1930 | +241.2 |
| OPENS UP | 13 | 12 | 8 | 0.22 | +263 | +32.9 |
| OVERRUNS AWAY | 51 | 46 | 8 | 0.22 | +278 | +34.8 |
| SHORT GUN FORWARD | 8 | 8 | 8 | 0.22 | +0 | +0.0 |
| BLOCKED CHARGE SKIPPED | 7 | 7 | 7 | 0.19 | +0 | +0.0 |
| FIRE AND FLEE | 7 | 7 | 7 | 0.19 | +80 | +11.4 |
| MOVES UNITS SPELL | 7 | 7 | 7 | 0.19 | +186 | +26.5 |
| PURSUES BIG PREY | 7 | 7 | 7 | 0.19 | -501 | -71.5 |
| BEST PRIZE | 5 | 5 | 5 | 0.14 | -222 | -44.5 |
| RAIDS THE BAGGAGE NEXT TURN | 5 | 5 | 5 | 0.14 | +419 | +83.7 |
| ELIXIR WORTH | 4 | 4 | 4 | 0.11 | +22 | +5.4 |
| MISSILES NEXT TURN | 306 | 133 | 4 | 0.11 | +74 | +18.6 |
| STANDS TO CAST | 4 | 4 | 4 | 0.11 | +23 | +5.8 |
| WHOLE FIGHT | 21 | 18 | 4 | 0.11 | +74 | +18.6 |
| BACKUP TARGETS | 65 | 30 | 3 | 0.08 | +17 | +5.6 |
| JOINT CHARGE PLAN | 7 | 7 | 3 | 0.08 | +214 | +71.3 |
| KEEPS ITS PREY | 15 | 15 | 3 | 0.08 | +28 | +9.3 |
| NEEDED THERE | 4 | 4 | 3 | 0.08 | +0 | +0.0 |
| NO RALLY LEFT | 3 | 3 | 3 | 0.08 | +193 | +64.2 |
| TWO OR MORE ARRIVE | 34 | 32 | 3 | 0.08 | +69 | +22.9 |
| BOMBING RUN | 2 | 2 | 2 | 0.06 | +137 | +68.5 |
| CONTINUE AHEAD WEIGHED | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| GIVES UP | 89 | 83 | 2 | 0.06 | +8 | +4.1 |
| GROUP AIM | 28 | 14 | 2 | 0.06 | +60 | +30.1 |
| HUNT IN PAIRS | 30 | 12 | 2 | 0.06 | +189 | +94.7 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| BLOCKED CHARGE HANDED OVER | 1 | 1 | 1 | 0.03 | +144 | +143.9 |
| BOUND ASSAILMENT | 1 | 1 | 1 | 0.03 | +0 | +0.1 |
| EDGE GIVE GROUND | 10 | 10 | 1 | 0.03 | +16 | +16.0 |
| ESCORT | 29 | 8 | 1 | 0.03 | +10 | +10.3 |
| FOCUS FIRE | 1 | 1 | 1 | 0.03 | +2 | +1.9 |
| HORN WORTH | 1 | 1 | 1 | 0.03 | +22 | +22.4 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.03 | +99 | +99.0 |
| PURSUES ON | 1 | 1 | 1 | 0.03 | +130 | +130.0 |
| RAIDS THE BAGGAGE | 1 | 1 | 1 | 0.03 | +212 | +211.6 |
| STOPS | 2 | 2 | 1 | 0.03 | +10 | +9.9 |
| SUPPORT JOB KEPT | 1 | 1 | 1 | 0.03 | -38 | -38.4 |
| TURN WORTH | 32 | 28 | 1 | 0.03 | +22 | +21.7 |
| ALREADY CARRIED | 1 | not checked | - | - | - | - |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| BLOCKED WHEEL | 27 | not checked | - | - | - | - |
| CANNON PLAN MISSED | 27 | 27 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 32 | trace | - | - | - | - |
| CATCH FLIERS | 4 | not checked | - | - | - | - |
| CATCH ODDS | 2 | not checked | - | - | - | - |
| CHEAP HELPER | 6 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 29 | not checked | - | - | - | - |
| ENGINEER BY LORE | 2 | 2 | 0 | 0.00 | - | - |
| FACES THE THREAT | 66 | not checked | - | - | - | - |
| FIGHT LIFT | 1 | not checked | - | - | - | - |
| GIVES UP ITS SCREEN | 51 | 49 | 0 | 0.00 | - | - |
| GROUND FLIERS | 2 | not checked | - | - | - | - |
| GROUP BROKEN | 1 | not checked | - | - | - | - |
| HELPER ALREADY ASKED | 7 | not checked | - | - | - | - |
| HELPER UNSEEN | 21 | 18 | 0 | 0.00 | - | - |
| HUNT ADVANCE | 6 | 6 | 0 | 0.00 | - | - |
| HUNT KEPT | 2 | trace | - | - | - | - |
| HUNT RESULT | 7 | trace | - | - | - | - |
| HUNT THE GUNS | 7 | trace | - | - | - | - |
| LONE CHARACTER SAFE SPOT | 29 | not checked | - | - | - | - |
| MANOEUVRE | 11 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 12 | trace | - | - | - | - |
| MISSILES IN THE MOVE | 219 | not checked | - | - | - | - |
| MOVE AND CAST | 12 | not checked | - | - | - | - |
| MOVE SPELL IN RANGE | 5 | 1 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 10 | trace | - | - | - | - |
| MOVE SPELL SPOT | 12 | not checked | - | - | - | - |
| NOT NEEDED | 28 | 28 | 0 | 0.00 | - | - |
| NOT TURNED | 733 | 733 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 37 | not checked | - | - | - | - |
| OPENS A LANE | 6 | 3 | 0 | 0.00 | - | - |
| PATHS CROSS | 180 | not checked | - | - | - | - |
| PLAN RESULT | 2675 | trace | - | - | - | - |
| SAFER THAN THE JOB | 45 | not checked | - | - | - | - |
| SCOUT SPOT | 23 | 23 | 0 | 0.00 | - | - |
| SEARCH SPOT | 78 | not checked | - | - | - | - |
| SECOND HUNTER | 1 | 1 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 20 | not checked | - | - | - | - |
| SHOTS IN THE MOVE | 767 | not checked | - | - | - | - |
| SPELL CATCH ODDS | 2 | not checked | - | - | - | - |
| SPELL SETS UP CHARGE | 1 | not checked | - | - | - | - |
| SPELL WORTH | 94 | not checked | - | - | - | - |
| THROUGH LINE OF FIRE | 31 | not checked | - | - | - | - |

### Plans: bg-on-789c37f-p1

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 11.4 | 20% | 570 | 358 | 63% |
| Mine | charge | 3.3 | 52% | 338 | 249 | 74% |
| Mine | close in | 4.4 | 23% | 319 | 176 | 55% |
| Mine | hold | 4.2 | 41% | 238 | 0 | 0% |
| Mine | join | 0.6 | 100% | 16 | 0 | 0% |
| Mine | shoot | 8.2 | 67% | 354 | 673 | 190% |
| Mine | support | 4.7 | 89% | 237 | 0 | 0% |
| Opponent | advance | 13.2 | 20% | 563 | 398 | 71% |
| Opponent | charge | 4.3 | 60% | 412 | 406 | 99% |
| Opponent | close in | 5.2 | 27% | 360 | 140 | 39% |
| Opponent | hold | 3.5 | 39% | 198 | 0 | 0% |
| Opponent | join | 0.9 | 94% | 37 | 0 | 0% |
| Opponent | shoot | 3.6 | 65% | 117 | 287 | 246% |
| Opponent | support | 6.8 | 90% | 272 | 0 | 0% |

### Packages: hunt the guns, bg-on-789c37f-p1

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.1 | 4 | 0 | 25% | 100% | 0% | 2.2 | 268 | 242 | 100% | 40 |
| Opponent | 0.1 | 3 | 0 | 33% | 67% | 0% | 2.5 | 336 | 138 | 0% | 123 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.2 | 1 | 0 | 0% | 100% | 0% | 2.0 | 308 | 291 | 100% | 0 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 297 |
| Dwarfen Mountain Holds | 0.2 | 1 | 0 | 100% | 100% | 0% | 2.0 | 318 | 242 | 100% | 75 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 101 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 76 |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 104 |
| Kingdom of Bretonnia | 2.0 | 2 | 0 | 0% | 100% | 0% | 2.5 | 223 | 218 | 100% | 0 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 378 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 97 |
| Tomb Kings of Khemri | 0.2 | 1 | 0 | 0% | 100% | 0% | 2.0 | 203 | 125 | 0% | 77 |
| Vampire Counts | 0.1 | 1 | 0 | 100% | 100% | 0% | 3.0 | 475 | 288 | 0% | 60 |
| Warriors of Chaos | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 99 |
| Wood Elf Realms | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 329 | 0 | 0% | 18 |

### Battle groups: bg-on-789c37f-p1

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 8.9 | 26% | 39% | 6% | 40% | 40% | 1% | 6% | 52% | 0% |
| Mine | REDIRECT COUNTER | 3.6 | 28% | 65% | 14% | 40% | 9% | 0% | 3% | 78% | 9% |
| Opponent | COUNTER-CHARGE COVER | 7.6 | 18% | 52% | 6% | 33% | 45% | 9% | 13% | 34% | 0% |
| Opponent | REDIRECT COUNTER | 5.0 | 17% | 73% | 23% | 14% | 4% | 0% | 13% | 74% | 9% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.3 | 6 | 0% | - |
| Opponent | 0.4 | 12 | 0% | - |

### Deployment: positions vs output by unit type: bg-on-789c37f-p1

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 2 | 0 (2) | 0 | 0 | 46 | 50% | 6.0 | 0 (1) | 0 (1) | - | - | 0 (2) |
| Mine | Chaff | 43 | 59 (43) | 41 | 18 | 49 | 42% | 2.3 | 107 (15) | 0 (7) | 37 (21) | 74 (29) | 30 (14) |
| Mine | Character | 121 | 58 (121) | 58 | 0 | 39 | 15% | 2.4 | 84 (31) | 54 (62) | 30 (11) | 56 (64) | 69 (40) |
| Mine | Clean-up | 20 | 80 (20) | 45 | 35 | 24 | 30% | 2.8 | 70 (10) | 101 (8) | 19 (2) | 116 (11) | 34 (9) |
| Mine | Fast | 1 | 81 (1) | 81 | 0 | 0 | 0% | 3.0 | - | 81 (1) | - | - | 81 (1) |
| Mine | Fast Hammer | 40 | 29 (40) | 17 | 12 | 64 | 28% | 2.6 | 42 (21) | 15 (6) | 13 (13) | 38 (30) | 9 (10) |
| Mine | Fragile | 3 | 0 (3) | 0 | 0 | 67 | 33% | 3.0 | - | 0 (3) | - | 0 (1) | 0 (2) |
| Mine | Hammer | 52 | 26 (52) | 17 | 9 | 38 | 17% | 2.4 | 45 (8) | 25 (34) | 17 (10) | 33 (35) | 13 (17) |
| Mine | Holder | 23 | 101 (23) | 21 | 81 | 14 | 26% | 3.9 | 86 (7) | 86 (11) | 172 (5) | 120 (14) | 76 (9) |
| Mine | Shooter | 45 | 83 (45) | 32 | 51 | 52 | 0% | 1.8 | 18 (7) | 111 (31) | 43 (7) | 113 (26) | 40 (19) |
| Mine | Support | 5 | 0 (5) | 0 | 0 | 42 | 100% | - | - | 0 (2) | - | 0 (1) | 0 (1) |
| Mine | War machine | 56 | 65 (56) | 65 | 0 | 40 | 2% | 1.4 | 90 (13) | 54 (38) | 86 (5) | 48 (10) | 70 (46) |
| Mine | Wizard | 22 | 7 (22) | 7 | 0 | 58 | 18% | 2.3 | 0 (7) | 3 (7) | 49 (3) | 0 (3) | 13 (14) |
| Opponent | Blocker | 1 | 94 (1) | 94 | 0 | 0 | 0% | 3.0 | 94 (1) | - | - | 94 (1) | - |
| Opponent | Chaff | 77 | 45 (77) | 11 | 34 | 55 | 38% | 2.8 | 47 (27) | 58 (21) | 33 (29) | 55 (54) | 18 (23) |
| Opponent | Character | 109 | 52 (109) | 52 | 0 | 44 | 16% | 2.6 | 73 (38) | 48 (52) | 33 (6) | 54 (65) | 65 (31) |
| Opponent | Clean-up | 11 | 11 (11) | 4 | 7 | 44 | 18% | 3.1 | 0 (4) | 18 (7) | - | 13 (8) | 6 (3) |
| Opponent | Early | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Fast Hammer | 51 | 59 (51) | 36 | 22 | 51 | 22% | 3.0 | 30 (22) | 64 (14) | 103 (15) | 64 (37) | 45 (14) |
| Opponent | Fragile | 9 | 0 (9) | 0 | 0 | 82 | 33% | 2.3 | - | 0 (2) | 0 (4) | 0 (5) | 0 (1) |
| Opponent | Hammer | 63 | 34 (63) | 22 | 12 | 47 | 25% | 2.6 | 6 (20) | 49 (38) | 0 (5) | 22 (37) | 52 (26) |
| Opponent | Holder | 35 | 57 (35) | 10 | 47 | 29 | 49% | 3.6 | 44 (8) | 87 (16) | 21 (9) | 81 (14) | 40 (19) |
| Opponent | Shooter | 31 | 76 (31) | 30 | 46 | 51 | 0% | 1.4 | 83 (7) | 75 (19) | 71 (5) | 78 (17) | 74 (14) |
| Opponent | Support | 1 | 0 (1) | 0 | 0 | 100 | 0% | 6.0 | 0 (1) | - | - | - | 0 (1) |
| Opponent | War machine | 13 | 95 (13) | 95 | 0 | 38 | 23% | 1.4 | 0 (3) | 145 (7) | 41 (3) | 0 (2) | 111 (11) |
| Opponent | Wizard | 22 | 30 (22) | 30 | 0 | 41 | 9% | 2.1 | 61 (6) | 21 (9) | 0 (6) | 36 (12) | 20 (9) |

### Charged fights: bg-on-789c37f-p1

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 5 | 281 | 61 | 1.8 | 1.1 | 34 | 3 | +30 | 1 of 9 | 7 of 9 | +40 | +29 |
| Mine | Chaos Dwarfs | 3 | 22 | 561 | 3.7 | 1.1 | 153 | 20 | +133 | 8 of 11 | 7 of 11 | +261 | +120 |
| Mine | Dwarfen Mountain Holds | 4 | 487 | 79 | 1.5 | 1.3 | 53 | 113 | -60 | 3 of 6 | 3 of 6 | -363 | +1 |
| Mine | Empire of Man | 5 | 510 | 228 | 2.2 | 1.2 | 104 | 40 | +63 | 2 of 11 | 4 of 11 | +77 | +60 |
| Mine | Grand Cathay | 4 | 506 | 0 | 2.0 | 1.0 | 0 | 0 | +0 | 6 of 8 | 4 of 7 | - | +0 |
| Mine | High Elf Realms | 4 | 121 | 748 | 4.0 | 1.1 | 187 | 9 | +178 | 4 of 16 | 9 of 16 | +913 | +129 |
| Mine | Kingdom of Bretonnia | 1 | 75 | 1290 | 4.0 | 1.0 | 322 | 0 | +322 | 1 of 4 | 3 of 4 | - | +322 |
| Mine | Lizardmen | 1 | 66 | 876 | 4.0 | 1.0 | 219 | 0 | +219 | 1 of 4 | 3 of 4 | - | +219 |
| Mine | Ogre Kingdoms | 1 | 0 | 202 | 4.0 | 1.2 | 50 | 0 | +50 | 0 of 4 | 4 of 4 | +66 | +45 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 331 | 6.0 | 1.0 | 55 | 88 | -33 | 2 of 6 | 4 of 6 | - | -33 |
| Mine | Skaven | 1 | 331 | 751 | 5.0 | 1.0 | 150 | 0 | +150 | 2 of 5 | 3 of 5 | - | +150 |
| Mine | Tomb Kings of Khemri | 2 | 58 | 864 | 4.0 | 1.1 | 216 | 9 | +207 | 2 of 8 | 5 of 8 | +888 | +110 |
| Mine | Vampire Counts | 2 | 0 | 768 | 4.0 | 1.2 | 192 | 77 | +115 | 3 of 8 | 5 of 8 | +53 | +124 |
| Mine | Warriors of Chaos | 1 | 0 | 382 | 4.0 | 1.0 | 96 | 0 | +96 | 1 of 4 | 4 of 4 | - | +96 |
| **Mine** | all armies | 35 | 259 | 387 | 3.0 | 1.1 | 130 | 26 | +104 | 36 of 104 | 65 of 103 | +224 | +93 |
| Opponent | Beastmen Brayherds | 1 | 55 | 77 | 1.0 | 1.0 | 77 | 0 | +77 | 0 of 1 | 1 of 1 | - | +77 |
| Opponent | Dwarfen Mountain Holds | 1 | 890 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 0 of 1 | 1 of 1 | - | +0 |
| Opponent | Empire of Man | 1 | 562 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Grand Cathay | 1 | 235 | 105 | 2.0 | 1.0 | 52 | 0 | +52 | 1 of 2 | 0 of 2 | - | +52 |
| Opponent | High Elf Realms | 2 | 198 | 908 | 6.5 | 1.3 | 140 | 11 | +129 | 4 of 13 | 8 of 13 | +143 | +124 |
| Opponent | Lizardmen | 1 | 0 | 971 | 6.0 | 1.2 | 162 | 14 | +148 | 2 of 6 | 5 of 6 | +189 | +140 |
| Opponent | Ogre Kingdoms | 2 | 28 | 68 | 3.5 | 1.3 | 20 | 65 | -45 | 4 of 7 | 4 of 7 | -66 | -37 |
| Opponent | Orc & Goblin Tribes | 2 | 35 | 262 | 3.5 | 1.1 | 75 | 47 | +28 | 5 of 7 | 2 of 7 | -110 | +51 |
| Opponent | Skaven | 2 | 0 | 0 | 0.5 | 1.0 | 0 | 0 | +0 | 1 of 1 | 0 of 1 | - | +0 |
| Opponent | Tomb Kings of Khemri | 4 | 182 | 975 | 4.5 | 1.2 | 217 | 14 | +202 | 9 of 18 | 11 of 18 | +304 | +182 |
| Opponent | Vampire Counts | 5 | 173 | 547 | 5.4 | 1.1 | 101 | 10 | +92 | 12 of 27 | 13 of 27 | +117 | +90 |
| Opponent | Warriors of Chaos | 7 | 7 | 395 | 3.4 | 1.0 | 115 | 11 | +104 | 6 of 24 | 13 of 24 | +50 | +107 |
| Opponent | Wood Elf Realms | 6 | 100 | 332 | 3.8 | 1.2 | 87 | 56 | +30 | 8 of 23 | 12 of 23 | +104 | +10 |
| **Opponent** | all armies | 35 | 129 | 429 | 3.7 | 1.2 | 116 | 24 | +92 | 52 of 130 | 70 of 130 | +116 | +88 |

### Effective charges: bg-on-789c37f-p1

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 9 | 2 (net -15) | 0 | 2 (net +57) | 2 (net +55) | 1 (net +40) | 2 (net +20) | 0 | 22% (2 of 9) |
| Mine | Chaos Dwarfs | 11 | 2 (net +175) | 0 | 0 | 4 (net +182) | 0 | 5 (net +77) | 0 | 0% (0 of 11) |
| Mine | Dwarfen Mountain Holds | 6 | 2 (net -10) | 0 | 2 (net -126) | 1 (net +41) | 0 | 1 (net -128) | 0 | 33% (2 of 6) |
| Mine | Empire of Man | 11 | 1 (net -104) | 1 (net -60) | 3 (net +85) | 1 (net +332) | 1 (net +60) | 3 (net +70) | 1 | 30% (3 of 10) |
| Mine | Grand Cathay | 8 | 1 (net +0) | 0 | 2 (net +0) | 2 (net +0) | 0 | 3 (net +0) | 0 | 25% (2 of 8) |
| Mine | High Elf Realms | 16 | 1 (net +0) | 0 | 2 (net +30) | 1 (net +195) | 4 (net +345) | 5 (net +218) | 3 | 15% (2 of 13) |
| Mine | Kingdom of Bretonnia | 4 | 1 (net +666) | 0 | 0 | 1 (net +153) | 1 (net +45) | 1 (net +426) | 0 | 0% (0 of 4) |
| Mine | Lizardmen | 4 | 1 (net +325) | 0 | 0 | 0 | 1 (net +60) | 0 | 2 | 0% (0 of 2) |
| Mine | Ogre Kingdoms | 4 | 0 | 0 | 0 | 1 (net +66) | 2 (net +68) | 0 | 1 | 0% (0 of 3) |
| Mine | Orc & Goblin Tribes | 6 | 0 | 0 | 0 | 0 | 2 (net +33) | 0 | 4 | 0% (0 of 2) |
| Mine | Skaven | 5 | 1 (net +0) | 0 | 1 (net +0) | 1 (net +398) | 1 (net +85) | 1 (net +268) | 0 | 20% (1 of 5) |
| Mine | Tomb Kings of Khemri | 8 | 0 | 0 | 0 | 0 | 1 (net +888) | 2 (net +216) | 5 | 0% (0 of 3) |
| Mine | Vampire Counts | 8 | 0 | 1 (net +863) | 2 (net -226) | 1 (net +53) | 0 | 4 (net +114) | 0 | 25% (2 of 8) |
| Mine | Warriors of Chaos | 4 | 0 | 0 | 0 | 1 (net +0) | 2 (net +191) | 0 | 1 | 0% (0 of 3) |
| Opponent | Beastmen Brayherds | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +77) | 0 | 0% (0 of 1) |
| Opponent | Dwarfen Mountain Holds | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +0) | 0 | 0% (0 of 1) |
| Opponent | Grand Cathay | 2 | 1 (net +0) | 0 | 0 | 1 (net +105) | 0 | 0 | 0 | 0% (0 of 2) |
| Opponent | High Elf Realms | 13 | 2 (net +352) | 0 | 1 (net +0) | 3 (net +127) | 1 (net +189) | 4 (net +64) | 2 | 9% (1 of 11) |
| Opponent | Lizardmen | 6 | 0 | 0 | 2 (net +200) | 0 | 1 (net +110) | 2 (net +189) | 1 | 40% (2 of 5) |
| Opponent | Ogre Kingdoms | 7 | 0 | 0 | 0 | 1 (net +52) | 0 | 2 (net -210) | 4 | 0% (0 of 3) |
| Opponent | Orc & Goblin Tribes | 7 | 1 (net +347) | 0 | 1 (net +0) | 0 | 0 | 1 (net -110) | 4 | 33% (1 of 3) |
| Opponent | Skaven | 1 | 1 (net +0) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 1) |
| Opponent | Tomb Kings of Khemri | 18 | 0 | 0 | 2 (net +20) | 6 (net +375) | 1 (net +90) | 6 (net +160) | 3 | 13% (2 of 15) |
| Opponent | Vampire Counts | 27 | 8 (net +139) | 0 | 3 (net +2) | 8 (net +56) | 0 | 6 (net +151) | 2 | 12% (3 of 25) |
| Opponent | Warriors of Chaos | 24 | 2 (net +250) | 1 (net +663) | 1 (net +0) | 3 (net +11) | 2 (net +112) | 11 (net +109) | 4 | 5% (1 of 20) |
| Opponent | Wood Elf Realms | 23 | 3 (net -147) | 1 (net -264) | 1 (net +0) | 3 (net +90) | 2 (net +108) | 9 (net +107) | 4 | 5% (1 of 19) |

### Charged fights, damage counted: bg-on-789c37f-p1

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 12 | 188 | 221 | +99 | 138 | 62 | +76 | +40.5 |
| Mine | 50-54% | 2 | 334 | 216 | +402 | 432 | 90 | +342 | +102.1 |
| Mine | Effective (55-75%) | 14 | 264 | 256 | -20 | 57 | 96 | -39 | -14.6 |
| Mine | 76-89% | 16 | 257 | 174 | +130 | 153 | 27 | +125 | +48.8 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 27 | 235 | 195 | +118 | 161 | 37 | +124 | +52.9 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 16 | 396 | 93 | +196 | 196 | 7 | +189 | +47.8 |
| Mine | No odds | 17 | 296 | 156 | +40 | 99 | 53 | +45 | +15.4 |
| Mine | All fights | 104 | 273 | 181 | +104 | 144 | 45 | +98 | +35.9 |
| Opponent | Long shot (under 50%) | 18 | 238 | 254 | +124 | 184 | 64 | +120 | +50.2 |
| Opponent | 50-54% | 2 | 489 | 440 | +200 | 499 | 300 | +200 | +40.8 |
| Opponent | Effective (55-75%) | 11 | 215 | 184 | +41 | 107 | 46 | +60 | +28.0 |
| Opponent | 76-89% | 25 | 368 | 210 | +142 | 177 | 25 | +153 | +41.5 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 43 | 271 | 182 | +98 | 135 | 30 | +106 | +38.9 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 7 | 411 | 102 | +119 | 119 | 29 | +90 | +21.9 |
| Opponent | No odds | 24 | 157 | 203 | +12 | 38 | 23 | +15 | +9.6 |
| Opponent | All fights | 130 | 270 | 201 | +92 | 134 | 38 | +97 | +35.7 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| bg-on-789c37f-p1 | move | 456 | 112 (25%) | 81 (18%) | 57 (12%) | 287 (63%) |
| bg-on-789c37f-p1 | objective | 354 | 57 (16%) | 38 (11%) | 38 (11%) | 259 (73%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0102, L0118, L0135, L2531, L2730 |
| Charmed Shield | Opponent | L0524, L1224, L1527, L1625, L2025, L2127, L2934 |
| Clockwork Compass | Mine | L1224 |
| Clockwork Compass | Opponent | L0612 |
| Elixir of Power | Mine | L1114, L1131, L1923 |
| Elixir of Power | Opponent | L0319, L1319 |
| Fistful of Laurels | Mine | L1823 |
| Fistful of Laurels | Opponent | L0118, L0218 |
| Horn of the Wild Hunt | Opponent | L0733 |
| Invocation of Nehek | Mine | L2531, L2730 |
| Invocation of Nehek | Opponent | L0524, L1224, L1527, L1625, L2025, L2127 |
| Opal Amulet | Mine | L1431 |
| Opal Amulet | Opponent | L1114 |
| Periapt of Soul Exchange | Mine | L2025, L2127 |
| Periapt of Soul Exchange | Opponent | L0421, L1021 |
| Ring of Doom | Mine | L0218, L0235, L1114, L1131, L1224, L1527 |
| Ring of Doom | Opponent | L0102, L0612, L0733, L1131, L1431, L2231, L2531 |
| Ring of Jet | Mine | L1021, L1114, L1131, L1224 |
| Ring of Jet | Opponent | L0612 |
| Standard of the Fell Warrior | Mine | L1319, L1335 |
| Standard of the Fell Warrior | Opponent | L0913 |
| Storm Daemon (Renegade 2.0) | Mine | L2127 |
| Storm Daemon (Renegade 2.0) | Opponent | L0421, L1021 |
| Twice-Blessed Armour | Mine | L0717, L0733, L1021 |
| Witch Hunter's Ward | Mine | L0717, L0733, L0823 |
| Witch Hunter's Ward | Opponent | L0508 |

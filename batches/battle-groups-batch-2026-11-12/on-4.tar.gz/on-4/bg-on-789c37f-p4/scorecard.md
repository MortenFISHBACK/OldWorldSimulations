# Doctrine scorecard: bg-on-789c37f-p4

### Scorecard: bg-on-789c37f-p4

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0114 | 6 | 1 | Mine | yes | 10 | 3 | 2 | 1 | 0 | 0 | 0 | 0 |
| L0114 | 6 | 1 | Opponent | no | 1 | 1 | 4 | 2 | 0 | 0 | 0 | 0 |
| L0130 | 4 | 1 | Mine | yes | 0 | 6 | 1 | 3 | 0 | 0 | 0 | 0 |
| L0130 | 4 | 1 | Opponent | no | 0 | 2 | 2 | 4 | 1 | 0 | 0 | 70 |
| L0214 | 4 | 1 | Mine | no | 0 | 6 | 2 | 3 | 1 | 0 | 0 | 170 |
| L0214 | 4 | 1 | Opponent | no | 1 | 1 | 5 | 0 | 0 | 0 | 0 | 177 |
| L0230 | 2 | 1 | Mine | - | - | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L0230 | 2 | 1 | Opponent | - | - | 3 | 2 | 1 | 0 | 0 | 0 | 0 |
| L0315 | 3 | 1 | Mine | yes | 5 | 3 | 4 | 0 | 0 | 0 | 0 | 760 |
| L0315 | 3 | 1 | Opponent | yes | 1 | 2 | 3 | 1 | 1 | 0 | 0 | 0 |
| L0332 | 2 | 1 | Mine | - | - | 3 | 1 | 0 | 1 | 0 | 0 | 590 |
| L0332 | 2 | 1 | Opponent | - | - | 1 | 5 | 3 | 0 | 0 | 0 | 170 |
| L0417 | 3 | 1 | Mine | yes | 4 | 2 | 7 | 1 | 1 | 0 | 0 | 0 |
| L0417 | 3 | 1 | Opponent | yes | 8 | 2 | 5 | 0 | 0 | 0 | 0 | 135 |
| L0434 | 2 | 1 | Mine | - | - | 3 | 5 | 0 | 0 | 0 | 0 | 0 |
| L0434 | 2 | 1 | Opponent | - | - | 1 | 5 | 1 | 0 | 0 | 0 | 0 |
| L0520 | 4 | 1 | Mine | no | 0 | 3 | 2 | 0 | 0 | 0 | 0 | 698 |
| L0520 | 4 | 1 | Opponent | no | 0 | 6 | 2 | 4 | 1 | 0 | 0 | 420 |
| L0608 | 2 | 1 | Mine | - | - | 3 | 1 | 2 | 0 | 0 | 0 | 926 |
| L0608 | 2 | 1 | Opponent | - | - | 5 | 2 | 2 | 0 | 0 | 0 | 605 |
| L0624 | 6 | 1 | Mine | no | 0 | 3 | 2 | 0 | 0 | 0 | 0 | 700 |
| L0624 | 6 | 1 | Opponent | no | 7 | 3 | 1 | 3 | 1 | 0 | 0 | 0 |
| L0713 | 5 | 1 | Mine | yes | - | 5 | 2 | 2 | 2 | 0 | 0 | 420 |
| L0713 | 5 | 1 | Opponent | yes | - | 3 | 2 | 3 | 0 | 0 | 0 | 317 |
| L0729 | 3 | 1 | Mine | no | 0 | 1 | 1 | 0 | 0 | 0 | 0 | 375 |
| L0729 | 3 | 1 | Opponent | no | 3 | 2 | 3 | 0 | 0 | 0 | 0 | 170 |
| L0819 | 3 | 1 | Mine | no | 0 | - | 0 | 0 | 0 | 0 | 0 | 515 |
| L0819 | 3 | 1 | Opponent | no | 6 | 2 | 1 | 3 | 0 | 0 | 0 | 0 |
| L0835 | 1 | 1 | Mine | no | 1 | 4 | 2 | 0 | 0 | 0 | 0 | 515 |
| L0835 | 1 | 1 | Opponent | no | 0 | 3 | 4 | 2 | 0 | 0 | 0 | 0 |
| L0926 | 2 | 1 | Mine | - | - | 2 | 1 | 1 | 0 | 0 | 0 | 677 |
| L0926 | 2 | 1 | Opponent | - | - | 2 | 3 | 3 | 0 | 0 | 0 | 0 |
| L1017 | 3 | 1 | Mine | yes | 11 | 2 | 3 | 0 | 0 | 0 | 0 | 497 |
| L1017 | 3 | 1 | Opponent | yes | 4 | 2 | 4 | 2 | 2 | 0 | 0 | 175 |
| L1034 | 2 | 1 | Mine | - | - | 1 | 1 | 0 | 0 | 0 | 0 | 330 |
| L1034 | 2 | 1 | Opponent | - | - | 3 | 0 | 2 | 0 | 0 | 0 | 0 |
| L1126 | 4 | 1 | Mine | yes | 11 | 2 | 4 | 0 | 1 | 0 | 0 | 330 |
| L1126 | 4 | 1 | Opponent | no | 7 | 2 | 2 | 2 | 1 | 0 | 0 | 0 |
| L1220 | 2 | 1 | Mine | - | - | 2 | 4 | 0 | 0 | 0 | 0 | 330 |
| L1220 | 2 | 1 | Opponent | - | - | - | 4 | 3 | 1 | 0 | 0 | 0 |
| L1314 | 6 | 1 | Mine | no | 0 | 2 | 1 | 0 | 1 | 0 | 0 | 140 |
| L1314 | 6 | 1 | Opponent | no | 0 | 2 | 5 | 0 | 0 | 0 | 0 | 0 |
| L1331 | 5 | 1 | Mine | yes | - | 2 | 3 | 3 | 0 | 0 | 0 | 302 |
| L1331 | 5 | 1 | Opponent | yes | - | 4 | 1 | 1 | 2 | 0 | 0 | 456 |
| L1427 | 5 | 1 | Mine | yes | - | 3 | 3 | 1 | 0 | 0 | 0 | 0 |
| L1427 | 5 | 1 | Opponent | no | - | 2 | 4 | 3 | 0 | 0 | 0 | 0 |
| L1523 | 5 | 1 | Mine | yes | - | - | 1 | 0 | 1 | 0 | 0 | 176 |
| L1523 | 5 | 1 | Opponent | yes | - | 2 | 9 | 1 | 1 | 0 | 0 | 192 |
| L1621 | 1 | 1 | Mine | no | 0 | 3 | 5 | 1 | 1 | 0 | 0 | 200 |
| L1621 | 1 | 1 | Opponent | no | 0 | 4 | 2 | 3 | 0 | 0 | 0 | 290 |
| L1719 | 3 | 1 | Mine | no | 0 | 2 | 4 | 0 | 1 | 0 | 0 | 0 |
| L1719 | 3 | 1 | Opponent | yes | 2 | 2 | 6 | 0 | 1 | 0 | 0 | 0 |
| L1819 | 1 | 1 | Mine | no | 0 | 3 | 5 | 1 | 0 | 0 | 0 | 0 |
| L1819 | 1 | 1 | Opponent | no | 0 | 2 | 2 | 0 | 0 | 0 | 0 | 0 |
| L1835 | 5 | 1 | Mine | no | - | 4 | 4 | 3 | 1 | 0 | 0 | 0 |
| L1835 | 5 | 1 | Opponent | yes | - | 2 | 1 | 3 | 1 | 0 | 0 | 140 |
| L2021 | 5 | 1 | Mine | yes | - | - | 1 | 4 | 0 | 0 | 0 | 210 |
| L2021 | 5 | 1 | Opponent | yes | - | 4 | 4 | 4 | 0 | 0 | 0 | 145 |
| L2123 | 5 | 1 | Mine | yes | - | - | 0 | 7 | 0 | 0 | 0 | 210 |
| L2123 | 5 | 1 | Opponent | yes | - | 3 | 2 | 2 | 0 | 0 | 0 | 126 |
| L2227 | 1 | 1 | Mine | yes | 2 | 2 | 2 | 0 | 0 | 0 | 0 | 0 |
| L2227 | 1 | 1 | Opponent | no | 0 | 1 | 5 | 2 | 1 | 0 | 0 | 60 |
| L2331 | 3 | 1 | Mine | yes | 11 | 3 | 5 | 0 | 2 | 0 | 0 | 0 |
| L2331 | 3 | 1 | Opponent | no | 3 | 3 | 4 | 2 | 2 | 0 | 0 | 170 |
| L2527 | 1 | 1 | Mine | no | 0 | 2 | 2 | 2 | 0 | 0 | 0 | 0 |
| L2527 | 1 | 1 | Opponent | no | 0 | 1 | 4 | 3 | 0 | 0 | 0 | 250 |
| L2634 | 6 | 1 | Mine | no | 3 | 2 | 4 | 1 | 1 | 0 | 0 | 0 |
| L2634 | 6 | 1 | Opponent | no | 2 | 2 | 4 | 1 | 0 | 0 | 0 | 107 |
| L2930 | 2 | 1 | Mine | - | - | 2 | 8 | 2 | 0 | 0 | 0 | 0 |
| L2930 | 2 | 1 | Opponent | - | - | 2 | 4 | 2 | 0 | 0 | 0 | 0 |
| L3234 | 6 | 1 | Mine | no | 6 | 2 | 4 | 2 | 0 | 0 | 0 | 0 |
| L3234 | 6 | 1 | Opponent | no | 0 | 4 | 3 | 1 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 50% | 3.0 | 2.8 | 2.8 | 1.1 | 0.4 | 0.0 | 0.0 | 252.0 |
| **Average** | | | Opponent | 36% | 2.1 | 2.5 | 3.3 | 1.9 | 0.4 | 0.0 | 0.0 | 116.0 |

### KPIs: bg-on-789c37f-p4

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Winner chose to follow up after the loser gave ground |  | 96% (78 of 81); on the table 96% | 100% (55 of 55); on the table 100% | 98% (133 of 136); on the table 98% |
| Winner chose to pursue after the loser fell back in good order |  | 93% (13 of 14); on the table 93% | 83% (10 of 12); on the table 83% | 88% (23 of 26); on the table 88% |
| Winner chose to pursue after the loser fled |  | 86% (18 of 21); on the table 86% | 77% (27 of 35); on the table 83% | 80% (45 of 56); on the table 84% |
| Winner chose to follow up or pursue (all three) |  | 94% (109 of 116); on the table 94% | 90% (92 of 102); on the table 92% | 92% (201 of 218); on the table 93% |
| Magic missiles tried each own turn | 50%+ | 21% (56 of 268) | 20% (34 of 174) | 20% (90 of 442) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 32% (56 of 177) | 30% (34 of 112) | 31% (90 of 289) |
| Points that never fought | lower | 34% (22804 of 67942) | 32% (22783 of 71984) | 33% (45587 of 139926) |
|   infantry points that never fought | lower | 41% (6317 of 15347) | 60% (8220 of 13804) | 50% (14537 of 29151) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 56% (151 of 270) | 52% (145 of 280) | 54% (296 of 550) |
| Bound items with a magic missile used (at least once a game) |  | 91% (20 of 22); 1.1 uses a game | 44% (4 of 9); 0.4 uses a game | 77% (24 of 31); 0.7 uses a game |
| Bound items with another spell used |  | 62% (10 of 16); 0.6 uses a game | 35% (7 of 20); 0.2 uses a game | 47% (17 of 36); 0.4 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 53% (10 of 19); 0.3 uses a game | 73% (11 of 15); 0.3 uses a game | 62% (21 of 34); 0.3 uses a game |
|   their share of the points of units over 100 pts | lower | 50% (28797 of 57750) | 45% (28433 of 63347) | 47% (57230 of 121097) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.3 (23%) | 0.6 (16%) | 2.0 (20%) |
| MARCHED: its unit marched | 1.8 (31%) | 1.0 (25%) | 2.8 (29%) |
| CHARGED: its unit charged | 0.1 (1%) | 0.2 (6%) | 0.3 (3%) |
| IN COMBAT: engaged in combat | 1.6 (26%) | 0.8 (19%) | 2.3 (24%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.2 (6%) | 0.2 (3%) |
| FLEEING: fleeing | 0.1 (2%) | 0.1 (2%) | 0.2 (2%) |
| GONE: slain | 0.7 (11%) | 0.8 (21%) | 1.5 (15%) |
| OFF THE TABLE: off the table or not arrived | 0.2 (3%) | 0.1 (2%) | 0.2 (3%) |
| STUPIDITY: Stupidity | 0.1 (2%) | 0.0 (0%) | 0.1 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.1 (2%) | 0.1 (1%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.5 | 1.6 | 1.6 | 2.5 | 0.2 | 2.6 |
| not cast | 2.7 | 2.3 | 3.3 | 9.8 | 1.8 | 20.4 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.2 (11%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.9 (38%) | 0.1 (4%) | 2.0 (20%) | 0.5 (29%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.8 (29%) | 0.6 (35%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (3%) | 0.0 (2%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.2 (6%) | 0.1 (2%) | 1.0 (30%) | 2.3 (24%) | 0.3 (19%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.2 (6%) | 0.2 (7%) | 0.3 (10%) | 0.2 (3%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (1%) | 0.2 (7%) | 0.0 (1%) | 0.2 (2%) | 0.1 (3%) | 0.8 (4%) |
| GONE: slain | 0.9 (35%) | 0.5 (21%) | 0.7 (20%) | 1.5 (15%) | 0.1 (5%) | 3.4 (17%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (0%) | 0.1 (2%) | 0.0 (1%) | 0.2 (3%) | 0.0 (0%) | 0.2 (1%) |
| STUPIDITY: Stupidity | 0.1 (2%) | 0.0 (0%) | 0.1 (2%) | 0.1 (1%) | 0.0 (0%) | 0.2 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.3 (12%) | 0.0 (1%) | 0.1 (1%) | 0.1 (8%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.3 (49%) | 0.2 (10%) | 1.0 (31%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 13.6 (67%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.3 a game | 0.4 a game | 0.8 a game |
| stood (cast and not dispelled) | 68% (27 of 40) | 67% (4 of 6) | 67% (31 of 46) |
| the unit moved after it | 89% (24 of 27) | 50% (2 of 4) | 84% (26 of 31) |
| it charged on its next turn | 7% (2 of 27) | 0% (0 of 4) | 6% (2 of 31) |
| the enemy charged it first | 33% (9 of 27) | 0% (0 of 4) | 29% (9 of 31) |
| it fought by the end of its next turn | 19% (5 of 27) | 0% (0 of 4) | 16% (5 of 31) |
| it moved out of a charge the enemy had planned (not charged first) | 7% (2 of 27) | 0% (0 of 4) | 6% (2 of 31) |
| none of these (no charge, no fight, no charge escaped) | 52% (14 of 27) | 100% (4 of 4) | 58% (18 of 31) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 62% (544 of 877) | 48% (266 of 556) | 57% (810 of 1433) |
|   cavalry | 65% (53 of 81) | 62% (64 of 103) | 64% (117 of 184) |
|   character | 33% (35 of 106) | 10% (13 of 134) | 20% (48 of 240) |
|   chariot | 43% (42 of 98) | 65% (17 of 26) | 48% (59 of 124) |
|   infantry | 56% (148 of 262) | 59% (142 of 240) | 58% (290 of 502) |
|   monster | 41% (14 of 34) | 20% (4 of 20) | 33% (18 of 54) |
|   war machine | 85% (252 of 296) | 79% (26 of 33) | 84% (278 of 329) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 3.3 (35%) | 2.0 (25%) | 5.3 (30%) |
| CHARGED: it charged | 1.3 (14%) | 1.9 (24%) | 3.3 (19%) |
| FLEEING: it fled or was fleeing | 0.1 (1%) | 0.2 (2%) | 0.2 (1%) |
| IN COMBAT: it fought this turn or the last | 0.8 (9%) | 0.5 (6%) | 1.3 (8%) |
| MOVED: a war machine that moved | 0.1 (1%) | 0.0 (0%) | 0.1 (0%) |
| HELD FIRE: a target, but it held its fire | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NO TARGET IN RANGE | 1.4 (15%) | 1.1 (14%) | 2.5 (14%) |
| ONLY IN COMBAT: the only targets were in combat | 0.5 (5%) | 0.6 (7%) | 1.1 (6%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.3 (14%) | 1.6 (20%) | 2.9 (17%) |
| SHELTERED: the target was sheltered | 0.2 (2%) | 0.0 (0%) | 0.2 (1%) |
| STUPIDITY | 0.0 (0%) | 0.1 (1%) | 0.1 (0%) |
| OTHER BAR | 0.2 (2%) | 0.1 (1%) | 0.3 (2%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 5.5 | 1.7 | 78% | 6.3 pts | 35 pts |
| character | 1.6 | 0.3 | 85% | 4.9 pts | 8 pts |
| chariot | 1.6 | 1.1 | 63% | 13.8 pts | 23 pts |
| infantry | 12.0 | 4.9 | 72% | 12.5 pts | 150 pts |
| monster | 0.5 | 0.1 | 89% | 2.3 pts | 1 pts |
| war machine | 7.7 | 5.4 | 63% | 22.0 pts | 170 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.4 | 6.9 | 5.7 |
| Charges that made contact a game | 3.3 | 5.0 | 4.2 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.00 declared, 0.94 contact (17 units) | 0.89 declared, 0.78 contact (18 units) | 0.94 declared, 0.86 contact (35 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.67 declared, 0.67 contact (9 units) | 1.55 declared, 1.09 contact (11 units) | 1.15 declared, 0.90 contact (20 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.54 declared, 0.39 contact (249 units) | 0.72 declared, 0.52 contact (300 units) | 0.64 declared, 0.46 contact (549 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 51% (41 of 81) | 44% (7 of 16) | 67% (4 of 6) | 50% (52 of 103) |
| Character in a unit | 67% (16 of 24) | 69% (11 of 16) | 0% (0 of 1) | 66% (27 of 41) |
| Character on its own | 80% (33 of 41) | 35% (9 of 26) | 23% (18 of 77) | 42% (60 of 144) |
| Chariot | 67% (10 of 15) | 75% (9 of 12) | - | 70% (19 of 27) |
| Infantry | 47% (39 of 83) | 44% (11 of 25) | 17% (1 of 6) | 45% (51 of 114) |
| Monster | 71% (24 of 34) | 64% (9 of 14) | - | 69% (33 of 48) |
| Monstrous | 79% (11 of 14) | 57% (8 of 14) | - | 68% (19 of 28) |
| War Machines | 77% (33 of 43) | 100% (2 of 2) | - | 78% (35 of 45) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 94% (16 of 17); on the table 94% | 21% (21 of 102) | 23% | 55% (12 of 22) | 100% (6 of 6); 3.0 uses a game | 100% (2 of 2); 1.0 uses a game | 83% (5 of 6); 1.2 uses a game |
| Chaos Dwarfs | 4 | 93% (13 of 14); on the table 93% | 17% (4 of 24) | 19% | 53% (17 of 32) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
| Dwarfen Mountain Holds | 3 | 80% (4 of 5); on the table 80% | - | 76% | 63% (17 of 27) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 6 | 89% (8 of 9); on the table 89% | 33% (6 of 18) | 49% | 65% (40 of 62) | 0.0 uses a game | 100% (2 of 2); 1.0 uses a game | 20% (1 of 5); 0.2 uses a game |
| Grand Cathay | 4 | 100% (18 of 18); on the table 100% | 21% (18 of 84) | 29% | 43% (16 of 37) | 89% (8 of 9); 3.5 uses a game | 100% (2 of 2); 0.8 uses a game | 25% (1 of 4); 0.2 uses a game |
| High Elf Realms | 9 | 92% (24 of 26); on the table 92% | 11% (4 of 36) | 40% | 44% (31 of 70) | 86% (6 of 7); 2.0 uses a game | 37% (11 of 30); 2.0 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | 100% (1 of 1); on the table 100% | - | 23% | 33% (2 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Lizardmen | 3 | 94% (15 of 16); on the table 94% | 67% (4 of 6) | 22% | 62% (13 of 21) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 2 | 86% (6 of 7); on the table 86% | 17% (1 of 6) | 42% | 57% (8 of 14) | 50% (1 of 2); 0.5 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 3 | 100% (9 of 9); on the table 100% | 0% (0 of 42) | 17% | 33% (8 of 24) | 0.0 uses a game | 0.0 uses a game | 100% (3 of 3); 1.0 uses a game |
| Skaven | 6 | 77% (10 of 13); on the table 85% | 35% (14 of 40) | 40% | 67% (30 of 45) | 33% (1 of 3); 0.3 uses a game | 0.0 uses a game | 83% (5 of 6); 0.8 uses a game |
| Tomb Kings of Khemri | 4 | 100% (15 of 15); on the table 100% | 50% (3 of 6) | 27% | 45% (9 of 20) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 8 | 96% (26 of 27); on the table 96% | 22% (13 of 60) | 21% | 50% (21 of 42) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 9 | 89% (17 of 19); on the table 89% | 17% (2 of 12) | 32% | 58% (42 of 72) | 50% (1 of 2); 0.3 uses a game | 0.0 uses a game | 100% (3 of 3); 0.3 uses a game |
| Wood Elf Realms | 6 | 86% (19 of 22); on the table 91% | 0% (0 of 6) | 25% | 54% (30 of 56) | 50% (1 of 2); 0.3 uses a game | 0.0 uses a game | 25% (1 of 4); 0.2 uses a game |

Flank and rear charges a unit could have turned to face (bg-on-789c37f-p4, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 50% (55) | 46% (32) | 49% (87) |
| ...free all their last turn and able to turn (per game) | 0.89 | 0.64 | 1.53 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.22 | 0.06 | 0.28 |
| ...with the charger already in that arc before they moved (per game) | 0.56 | 0.44 | 1.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 1.36 | 0.97 | 2.33 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.89 | 0.67 | 1.56 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 9.97 | 10.72 | 20.69 |

### Quality by phase: bg-on-789c37f-p4

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.1 | 3.6 |
| Strategy | Charge objectives carried out (made contact) | 44% (65 of 148) | 43% (92 of 216) |
| Strategy | Shoot objectives carried out (shot that target) | 44% (154 of 353) | 40% (56 of 139) |
| Strategy | Close-in objectives charged next turn | 16% (28 of 175) | 17% (33 of 193) |
| Strategy | Support requests answered (helper made contact too) | 41% (7 of 17) | 40% (16 of 40) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (4 of 4) | 100% (2 of 2) |
| Strategy | Hexes on a unit its side charged or shot that turn | 64% (9 of 14) | 57% (4 of 7) |
| Strategy | Joined characters whose unit fought | 63% (19 of 30) | 41% (12 of 29) |
| Strategy | Lone characters that fought | 74% (69 of 93) | 82% (71 of 87) |
| Movement | Charges halted short of contact | 0.2 | 0.4 |
| Movement | Idle units | 1.1 | 1.9 |
| Movement | Points that never moved of their own | 252.0 | 116.0 |
| Movement | Fights charged into per game | 3.2 | 4.1 |
| Movement | Charges with odds: long shots (under 50%) | 10 of 98, net -51 | 21 of 123, net +11 |
| Movement | Charges with odds: sweet spot (55-75%) | 19 of 98, net -68 | 20 of 123, net +75 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 13 of 98, net +66 | 16 of 123, net +34 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 35 of 98, net +77 | 39 of 123, net +156 |
| Shooting | Shots by shooting units (incl. breath weapons) | 9.1 | 7.8 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 46% (151 of 326) | 44% (122 of 280) |
| Shooting | Points destroyed by shooting units | 104.7 | 71.0 |
| Shooting | War machine shots | 7.0 | 0.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 57% (144 of 252) | 46% (12 of 26) |
| Shooting | Points destroyed by war machines | 33.9 | 8.3 |
| Magic | Magic missiles cast | 1.2 | 0.7 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 33% (14 of 43) | 20% (5 of 25) |
| Magic | Wounds caused by magic missiles | 3.4 | 0.4 |
| Magic | Wounds caused by other spells | 1.7 | 1.2 |
| Magic | Points destroyed by magic (all spells) | 119.5 | 13.4 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.2 / 0.4 / 0.7 / 0.1 | 1.8 / 0.4 / 0.6 / 0.1 |
| Combat | Points destroyed in combat | 300.6 | 425.8 |
| Combat | Points run down | 72.9 | 161.1 |
| Combat | Net points per charged fight, damage counted | +47 | +65 |
| Combat | Net per 100 charger points, damage counted | +16.6 | +21.6 |
| Combat | First round won (charged fights) | 74% | 52% |
| Combat | Net points per charged fight | +36 | +67 |
| Combat | Net points per supported fight / lone fight | +57 / +34 | +138 / +51 |
| Combat | Charged fights on a top-3 enemy unit | 44 of 115 | 61 of 146 |
| Game | Points lost | 782.9 | 704.3 |
| Game | VP from objectives | 538.3 | 530.6 |
| Game | Lone holders (player turns) | 3.0 | 2.1 |

- Mine won / drew / lost: 12 / 11 / 13 of 36 ended games (of 36); mean margin (Mine - Opponent) -83 VP
- The side that went first won 13 of 25 games with a winner
- Points traded per game (both sides' losses): 1487
- Games not ended: 0; findings 0, warnings 1

### Opponent rules: bg-on-789c37f-p4

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.6 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.1 | +0.0 | 0.0 | 20.8 | 0.1 | +0.0 | 0.0 | 3.5 |
| BACKUP TARGETS | 0.8 | +5.1 | 0.0 | 21.1 | 0.9 | +10.2 | 0.0 | 42.3 |
| BEST PREY | 4.6 | +319.6 | 235.8 | 162.2 | 4.6 | +297.3 | 153.7 | 137.3 |
| BEST PRIZE | 0.1 | +1.8 | 3.0 | 13.1 | 0.1 | -1.1 | 3.5 | 0.0 |
| BLOCKED CHARGE SKIPPED | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| BLOCKED WHEEL | 0.8 | +0.8 | 0.0 | 8.9 | 0.4 | -7.7 | 0.0 | 0.0 |
| BOMBING RUN | 0.0 | +0.4 | 1.2 | 0.0 | - | - | - | - |
| BOUND ASSAILMENT | 0.0 | +0.0 | 0.0 | 3.5 | 0.1 | +0.0 | 0.0 | 0.0 |
| CANNON PLAN MISSED | 0.9 | +0.0 | 77.8 | 7.8 | 0.2 | +0.0 | 22.4 | 0.0 |
| CANNON PLANNED TARGET | 5.4 | +206.2 | 357.1 | 62.5 | 0.5 | +15.8 | 45.8 | 6.9 |
| CANNON SIGHT KEPT | 1.3 | +0.0 | 0.0 | 3.2 | 0.0 | +0.0 | 0.0 | 0.0 |
| CAST JOB | 0.8 | +18.6 | 37.4 | 1.7 | 0.4 | +5.9 | 13.4 | 0.0 |
| CASTER AWAY FROM SCREEN | 0.3 | +0.0 | 0.0 | 9.3 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.3 | +51.9 | 41.9 | 10.3 | - | - | - | - |
| CASTS AFTER FRIENDS | 0.9 | +0.0 | 0.0 | 29.6 | 0.3 | +0.0 | 0.0 | 11.1 |
| CASTS FROM BEHIND | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.1 | +0.1 | 0.0 | 0.0 | 0.0 | +0.8 | 0.0 | 0.0 |
| CHAFF PASSED | 0.2 | -0.3 | 15.1 | 8.0 | 0.1 | -0.2 | 6.9 | 1.8 |
| CHAMPION TAKES THE CHALLENGE | - | - | - | - | 0.0 | +0.6 | 11.3 | 0.0 |
| CHARGE NOW WEIGHED | 0.6 | -45.8 | 13.3 | 20.4 | 0.4 | -44.5 | 18.2 | 32.9 |
| CHARIOT NO STATIC JOB | 0.6 | +0.0 | 5.7 | 12.1 | 0.3 | +0.0 | 0.0 | 2.1 |
| CHEAP HELPER | 0.2 | +0.0 | 8.4 | 1.8 | 0.2 | +0.0 | 17.8 | 0.0 |
| CONVEYANCE SEARCH | 0.6 | +60.0 | 15.1 | 23.9 | 0.1 | +22.4 | 0.0 | 7.6 |
| COUNTER-CHARGE COVER | 8.8 | +619.0 | 0.0 | 241.4 | 8.6 | +676.4 | 0.0 | 213.3 |
| EDGE GIVE GROUND | - | - | - | - | 0.2 | +9.9 | 13.8 | 3.9 |
| ELIXIR WORTH | - | - | - | - | 0.1 | +4.4 | 0.0 | 9.7 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ESCORT | 0.6 | +33.0 | 0.0 | 4.4 | 0.1 | +5.3 | 0.0 | 0.0 |
| FACES THE THREAT | 1.4 | +98.3 | 0.0 | 52.5 | 1.0 | +84.8 | 0.0 | 25.8 |
| FIGHT LIFT | 0.1 | +1.5 | 4.0 | 0.0 | - | - | - | - |
| FIRE AND FLEE | 0.0 | +0.1 | 0.0 | 0.0 | 0.0 | +1.2 | 0.0 | 0.0 |
| FOCUS FIRE | 0.0 | +0.3 | 1.5 | 2.0 | 0.1 | +0.6 | 2.5 | 0.0 |
| FOLLOW UP WEIGHED | 1.2 | +149.5 | 0.0 | 45.7 | 1.2 | +141.9 | 0.0 | 21.0 |
| FRIENDS SHOTS CHECKED | 0.4 | +29.2 | 0.0 | 0.0 | 0.2 | +5.6 | 0.0 | 3.0 |
| GIVES UP | 1.1 | -28.2 | 123.8 | 19.4 | 1.6 | -54.4 | 206.1 | 39.7 |
| GIVES UP ITS SCREEN | 0.8 | -15.4 | 37.7 | 17.7 | 1.2 | -25.6 | 103.7 | 14.2 |
| GROUND FLIERS | 0.1 | +0.2 | 0.0 | 0.0 | 0.0 | +0.2 | 0.0 | 0.0 |
| GROUP AIM | 0.2 | +1.5 | 0.0 | 3.8 | 0.2 | +1.6 | 0.0 | 6.2 |
| GROUP BROKEN | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HELPER ALREADY ASKED | 0.0 | +0.0 | 5.6 | 0.0 | 0.1 | +0.0 | 0.0 | 1.5 |
| HELPER UNSEEN | 0.2 | +0.0 | 7.4 | 26.3 | 0.6 | +0.0 | 40.1 | 21.3 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| HUNT ADVANCE | 0.1 | +1.8 | 5.3 | 0.0 | 0.2 | +5.0 | 6.9 | 3.1 |
| HUNT DROPPED | 0.0 | +0.0 | 13.1 | 0.0 | 0.1 | +0.0 | 20.1 | 3.1 |
| HUNT IN PAIRS | 0.3 | +15.8 | 0.0 | 0.0 | 0.3 | +13.7 | 0.0 | 5.4 |
| HUNT KEPT | 0.0 | +0.0 | 0.0 | 0.0 | 0.0 | +2.1 | 3.5 | 0.0 |
| HUNT RESULT | 0.1 | +5.4 | 26.1 | 0.0 | 0.2 | +9.9 | 26.5 | 6.1 |
| HUNT THE GUNS | 0.1 | +58.2 | 5.3 | 0.0 | 0.2 | +76.5 | 30.0 | 3.1 |
| JOINT CHARGE PLAN | 0.1 | +3.7 | 0.0 | 0.0 | 0.1 | +4.3 | 0.0 | 2.5 |
| KEEPS ITS PREY | 0.1 | +0.4 | 2.5 | 4.0 | 0.4 | +1.4 | 11.1 | 6.8 |
| KEEPS ITS TARGET | 2.1 | +62.5 | 184.4 | 35.2 | 2.1 | +63.3 | 198.9 | 28.6 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KILLS COUNT | 1.9 | +55.2 | 136.4 | 41.2 | 2.4 | +107.4 | 149.1 | 15.8 |
| KILLS COUNT NEXT TURN | 9.1 | +366.7 | 378.8 | 231.5 | 10.1 | +512.8 | 419.9 | 245.5 |
| LONE CHARACTER SAFE SPOT | 0.4 | +17.2 | 21.9 | 3.8 | 0.4 | +6.1 | 1.4 | 19.4 |
| LONE WIZARD HOLDS BACK | 1.4 | +0.0 | 101.9 | 24.4 | 1.0 | +0.0 | 30.0 | 49.9 |
| LONE WIZARD KEPT IN | 0.6 | +26.9 | 0.0 | 0.0 | 0.2 | +20.3 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 0.8 | +29.5 | 4.7 | 15.3 | 1.1 | +48.2 | 17.9 | 38.5 |
| MANOEUVRE | 0.2 | +10.0 | 0.0 | 1.8 | 0.1 | +1.7 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.2 | +1.0 | 0.0 | 15.0 | 0.2 | +1.7 | 0.0 | 18.2 |
| MARCH ODDS | 1.2 | +67.1 | 15.2 | 21.9 | 0.7 | +76.6 | 34.7 | 32.2 |
| MISSILES IN THE MOVE | 2.8 | +91.1 | 0.0 | 63.7 | 1.6 | +21.8 | 0.0 | 25.9 |
| MISSILES NEXT TURN | 4.6 | +83.2 | 0.0 | 127.9 | 2.7 | +22.1 | 0.0 | 98.7 |
| MODEL FACING | 0.4 | +91.0 | 0.0 | 3.3 | - | - | - | - |
| MOVE AND CAST | 0.1 | +5.5 | 0.0 | 0.0 | 0.1 | +2.7 | 0.0 | 0.0 |
| MOVE SPELL IN RANGE | 0.2 | +4.9 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.6 | -21.1 | 49.7 | 51.1 | 0.1 | -0.2 | 6.7 | 0.0 |
| MOVE SPELL SPOT | 0.6 | +0.0 | 0.0 | 10.1 | 0.1 | +0.0 | 0.0 | 11.1 |
| MOVES UNITS SPELL | 0.1 | +3.3 | 0.0 | 0.0 | 0.1 | +0.6 | 0.0 | 0.0 |
| NEEDED THERE | 0.1 | +1.7 | 7.9 | 0.0 | 0.1 | +7.3 | 3.9 | 0.0 |
| NO RALLY LEFT | 0.1 | +1.4 | 0.0 | 2.3 | 0.0 | +0.1 | 0.0 | 0.0 |
| NOT NEEDED | 0.2 | -9.1 | 22.3 | 8.8 | 0.4 | -16.9 | 28.3 | 9.3 |
| NOT TURNED | 10.0 | +201.3 | 0.0 | 278.0 | 10.7 | +110.0 | 0.0 | 241.6 |
| NOT WORTH A CAST | 0.5 | -0.4 | 0.0 | 10.6 | 0.4 | -2.6 | 0.0 | 0.0 |
| OPENS A LANE | 0.1 | +0.4 | 12.0 | 1.8 | 0.1 | +1.2 | 4.8 | 0.0 |
| OPENS UP | 0.4 | +25.9 | 14.9 | 13.1 | 0.3 | +32.2 | 11.0 | 0.0 |
| OVERRUNS AWAY | 0.5 | +4.5 | 24.7 | 28.6 | 0.8 | +10.2 | 75.3 | 6.9 |
| PATHS CROSS | 2.2 | +141.1 | 0.0 | 50.4 | 3.1 | +255.6 | 0.0 | 61.9 |
| PERIAPT WORTH | 0.0 | +1.1 | 0.0 | 0.0 | 0.1 | +7.8 | 0.0 | 0.0 |
| PLAN LEADS | 1.2 | +114.5 | 22.6 | 35.3 | 1.0 | +85.9 | 14.9 | 6.5 |
| PLAN RESULT | 39.1 | +1445.7 | 1342.4 | 1141.7 | 39.0 | +1397.2 | 1474.6 | 985.9 |
| PURSUES BIG PREY | 0.0 | -1.1 | 0.0 | 0.0 | 0.1 | -2.2 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE NEXT TURN | 0.1 | +5.7 | 0.0 | 0.0 | 0.1 | +11.2 | 0.0 | 8.9 |
| REDIRECT COUNTER | 3.5 | +149.4 | 0.0 | 58.4 | 5.3 | +305.6 | 0.0 | 87.0 |
| REDIRECT WEIGHED | 0.1 | +2.2 | 3.0 | 1.4 | 0.4 | +15.0 | 13.2 | 10.3 |
| RESTRAINS TO SHOOT | 0.2 | +9.7 | 0.0 | 3.5 | 0.1 | +3.3 | 0.0 | 7.0 |
| RISK BY ARC | 2.9 | +126.3 | 216.3 | 106.6 | 3.3 | +61.5 | 266.6 | 63.9 |
| SAFER THAN THE JOB | 0.9 | +45.7 | 0.0 | 19.8 | 0.7 | +41.9 | 0.0 | 19.0 |
| SCOUT SPOT | 0.4 | +0.5 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 1.8 |
| SCOUT WAITS | 0.5 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 1.8 |
| SEARCH SPOT | 1.3 | +91.1 | 0.0 | 36.7 | 1.5 | +112.5 | 0.0 | 42.2 |
| SECOND HUNTER | 0.0 | -0.0 | 0.0 | 0.0 | - | - | - | - |
| SELF MOVE SPELL | 0.2 | +48.5 | 0.0 | 0.0 | 0.4 | +20.7 | 0.0 | 18.1 |
| SET UP TOGETHER | 1.2 | +44.7 | 4.7 | 25.2 | 1.8 | +62.5 | 17.9 | 46.3 |
| SET-UP MISSED | - | - | - | - | 0.0 | +8.0 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.3 | +0.7 | 0.0 | 0.0 | 0.2 | +0.3 | 0.0 | 0.0 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 3.2 | 0.0 | +0.0 | 0.0 | 0.0 |
| SHOT REPLANNED | 0.5 | +0.0 | 124.4 | 4.6 | 0.3 | +0.0 | 39.9 | 6.6 |
| SHOTS IN THE MOVE | 13.9 | +643.6 | 0.0 | 161.1 | 6.2 | +136.7 | 0.0 | 79.4 |
| SPELL CATCH ODDS | 0.0 | -0.1 | 0.0 | 0.0 | - | - | - | - |
| SPELL SETS UP CHARGE | 0.1 | +22.5 | 0.0 | 0.0 | 0.1 | +16.9 | 0.0 | 0.0 |
| SPELL WORTH | 1.5 | +24.6 | 129.6 | 125.6 | 2.3 | +47.7 | 86.2 | 88.8 |
| STANDS TO CAST | 0.1 | +2.1 | 0.0 | 0.0 | - | - | - | - |
| STOPS | 0.1 | +0.1 | 0.0 | 0.0 | 0.1 | +2.2 | 26.5 | 0.0 |
| STUCK PIVOT | 0.3 | +0.0 | 0.0 | 5.8 | 0.3 | +0.0 | 0.0 | 0.0 |
| SURE CHARGE BEATS ADVANCE | 0.1 | -10.4 | 8.8 | 0.0 | 0.1 | -2.4 | 8.3 | 0.0 |
| THROUGH LINE OF FIRE | 0.5 | +22.5 | 0.0 | 0.0 | 0.4 | +18.3 | 0.0 | 1.9 |
| TURN WORTH | 0.7 | -51.6 | 42.6 | 28.3 | 0.4 | -37.8 | 26.7 | 0.0 |
| TWO OR MORE ARRIVE | 0.5 | +4.6 | 4.7 | 14.2 | 0.6 | +8.9 | 0.0 | 4.5 |
| WEARS DOWN | 1.2 | +61.6 | 90.1 | 69.6 | 1.3 | +49.1 | 137.3 | 78.6 |
| WHO HITS BACK | 0.2 | +21.7 | 0.0 | 16.9 | 0.3 | +15.9 | 0.0 | 7.3 |
| WHOLE FIGHT | 0.4 | +10.3 | 25.4 | 3.1 | 0.6 | +21.5 | 136.8 | 19.4 |
| WHOLE FIGHT GAIN | 0.3 | +28.0 | 25.0 | 2.8 | 0.8 | +54.3 | 45.7 | 12.7 |

### Rule changes: bg-on-789c37f-p4

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| KILLS COUNT NEXT TURN | 689 | 680 | 205 | 5.69 | +8044 | +39.2 |
| BEST PREY | 332 | 325 | 153 | 4.25 | +4795 | +31.3 |
| FOLLOW UP WEIGHED | 88 | 88 | 88 | 2.44 | +10490 | +119.2 |
| COUNTER-CHARGE COVER | 626 | 288 | 81 | 2.25 | +4647 | +57.4 |
| RISK BY ARC | 223 | 203 | 52 | 1.44 | +1671 | +32.1 |
| MARCH ODDS | 69 | 52 | 49 | 1.36 | +1139 | +23.2 |
| CANNON SIGHT KEPT | 48 | 48 | 48 | 1.33 | +0 | +0.0 |
| ARTILLERY RE-ROLL WEIGHED | 46 | 46 | 46 | 1.28 | +0 | +0.0 |
| KILLS COUNT | 154 | 142 | 44 | 1.22 | +1473 | +33.5 |
| ADVANCE LANE KEPT | 41 | 41 | 41 | 1.14 | +0 | +0.0 |
| KEEPS ITS TARGET | 151 | 149 | 37 | 1.03 | +629 | +17.0 |
| CHARGE NOW WEIGHED | 36 | 36 | 36 | 1.00 | +2014 | +55.9 |
| HOLDS AMBUSHERS | 35 | 35 | 35 | 0.97 | +0 | +0.0 |
| SET UP TOGETHER | 108 | 81 | 30 | 0.83 | +909 | +30.3 |
| SHOT REPLANNED | 30 | 30 | 30 | 0.83 | +0 | +0.0 |
| PLAN LEADS | 81 | 81 | 29 | 0.81 | +1303 | +44.9 |
| CANNON PLANNED TARGET | 212 | 212 | 28 | 0.78 | -807 | -28.8 |
| LONE WIZARD KEPT IN | 28 | 28 | 28 | 0.78 | +1699 | +60.7 |
| LONE WIZARD HOLDS BACK | 87 | 87 | 24 | 0.67 | -872 | -36.3 |
| CAST JOB | 40 | 39 | 22 | 0.61 | +369 | +16.8 |
| FRIENDS SHOTS CHECKED | 22 | 22 | 22 | 0.61 | +1251 | +56.9 |
| STUCK PIVOT | 22 | 22 | 22 | 0.61 | +0 | +0.0 |
| CHARIOT NO STATIC JOB | 31 | 31 | 21 | 0.58 | -1762 | -83.9 |
| SCOUT WAITS | 21 | 21 | 21 | 0.58 | +0 | +0.0 |
| WHOLE FIGHT GAIN | 37 | 31 | 21 | 0.58 | +891 | +42.4 |
| WHO HITS BACK | 20 | 20 | 20 | 0.56 | -1247 | -62.3 |
| REDIRECT WEIGHED | 19 | 19 | 19 | 0.53 | +635 | +33.4 |
| REDIRECT COUNTER | 318 | 87 | 17 | 0.47 | +1172 | +69.0 |
| SHOOTERS IN TWO RANKS | 17 | 17 | 17 | 0.47 | +36 | +2.1 |
| CASTER AWAY FROM SCREEN | 16 | 16 | 16 | 0.44 | +0 | +0.0 |
| MAKE SURE TOGETHER | 70 | 40 | 16 | 0.44 | +554 | +34.6 |
| MODEL FACING | 16 | 16 | 16 | 0.44 | +3277 | +204.8 |
| WEARS DOWN | 91 | 84 | 15 | 0.42 | +516 | +34.4 |
| CHAFF PASSED | 14 | 14 | 14 | 0.39 | -19 | -1.3 |
| OPENS UP | 23 | 22 | 12 | 0.33 | +447 | +37.3 |
| WHOLE FIGHT | 36 | 34 | 12 | 0.33 | +520 | +43.3 |
| RESTRAINS TO SHOOT | 11 | 11 | 11 | 0.31 | +467 | +42.4 |
| CASTING BLOCK | 12 | 12 | 10 | 0.28 | +1325 | +132.5 |
| CASTS FROM BEHIND | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| SHORT GUN FORWARD | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| SURE CHARGE BEATS ADVANCE | 9 | 9 | 9 | 0.25 | -460 | -51.1 |
| MOVES UNITS SPELL | 7 | 7 | 7 | 0.19 | +138 | +19.7 |
| TWO OR MORE ARRIVE | 37 | 36 | 7 | 0.19 | +50 | +7.1 |
| BEST PRIZE | 6 | 6 | 6 | 0.17 | -381 | -63.5 |
| RAIDS THE BAGGAGE NEXT TURN | 7 | 7 | 6 | 0.17 | +118 | +19.6 |
| BLOCKED CHARGE SKIPPED | 5 | 5 | 5 | 0.14 | +0 | +0.0 |
| HUNT ADVANCE | 10 | 10 | 5 | 0.14 | +117 | +23.3 |
| PERIAPT WORTH | 5 | 5 | 5 | 0.14 | +321 | +64.1 |
| NEEDED THERE | 6 | 6 | 4 | 0.11 | +0 | +0.0 |
| OVERRUNS AWAY | 47 | 46 | 4 | 0.11 | +121 | +30.3 |
| BOUND ASSAILMENT | 3 | 3 | 3 | 0.08 | +0 | +0.2 |
| ELIXIR WORTH | 3 | 3 | 3 | 0.08 | +158 | +52.7 |
| FOCUS FIRE | 3 | 3 | 3 | 0.08 | +31 | +10.4 |
| NO RALLY LEFT | 3 | 3 | 3 | 0.08 | +17 | +5.8 |
| PURSUES BIG PREY | 3 | 3 | 3 | 0.08 | -116 | -38.7 |
| FIRE AND FLEE | 2 | 2 | 2 | 0.06 | +46 | +23.1 |
| JOINT CHARGE PLAN | 7 | 7 | 2 | 0.06 | +92 | +46.1 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| MISSILES NEXT TURN | 264 | 123 | 2 | 0.06 | +1 | +0.5 |
| STANDS TO CAST | 2 | 2 | 2 | 0.06 | +6 | +2.9 |
| BACKUP TARGETS | 62 | 30 | 1 | 0.03 | +2 | +2.3 |
| BOMBING RUN | 1 | 1 | 1 | 0.03 | +14 | +13.8 |
| EDGE GIVE GROUND | 8 | 8 | 1 | 0.03 | +48 | +47.7 |
| ESCORT | 26 | 7 | 1 | 0.03 | +34 | +34.5 |
| GIVES UP | 95 | 90 | 1 | 0.03 | +4 | +4.4 |
| GIVES UP ITS SCREEN | 71 | 68 | 1 | 0.03 | +2 | +1.7 |
| HUNT IN PAIRS | 24 | 13 | 1 | 0.03 | +35 | +34.8 |
| TURN WORTH | 38 | 37 | 1 | 0.03 | +11 | +11.0 |
| BLOCKED WHEEL | 44 | not checked | - | - | - | - |
| CANNON PLAN MISSED | 37 | 37 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 42 | trace | - | - | - | - |
| CATCH FLIERS | 3 | not checked | - | - | - | - |
| CHAMPION TAKES THE CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| CHEAP HELPER | 12 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 27 | not checked | - | - | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FACES THE THREAT | 84 | not checked | - | - | - | - |
| FIGHT LIFT | 3 | not checked | - | - | - | - |
| GROUND FLIERS | 3 | not checked | - | - | - | - |
| GROUP AIM | 14 | 9 | 0 | 0.00 | - | - |
| GROUP BROKEN | 1 | not checked | - | - | - | - |
| HELPER ALREADY ASKED | 3 | not checked | - | - | - | - |
| HELPER UNSEEN | 31 | 29 | 0 | 0.00 | - | - |
| HUNT DROPPED | 6 | trace | - | - | - | - |
| HUNT KEPT | 2 | trace | - | - | - | - |
| HUNT RESULT | 12 | trace | - | - | - | - |
| HUNT THE GUNS | 13 | trace | - | - | - | - |
| KEEPS ITS PREY | 18 | 17 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 27 | not checked | - | - | - | - |
| MANOEUVRE | 11 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 15 | trace | - | - | - | - |
| MISSILES IN THE MOVE | 156 | not checked | - | - | - | - |
| MOVE AND CAST | 8 | not checked | - | - | - | - |
| MOVE SPELL IN RANGE | 7 | 6 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 26 | trace | - | - | - | - |
| MOVE SPELL SPOT | 22 | not checked | - | - | - | - |
| NOT NEEDED | 23 | 22 | 0 | 0.00 | - | - |
| NOT TURNED | 745 | 745 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 30 | not checked | - | - | - | - |
| OPENS A LANE | 9 | 7 | 0 | 0.00 | - | - |
| PATHS CROSS | 190 | not checked | - | - | - | - |
| PLAN RESULT | 2811 | trace | - | - | - | - |
| SAFER THAN THE JOB | 56 | not checked | - | - | - | - |
| SCOUT SPOT | 19 | 19 | 0 | 0.00 | - | - |
| SEARCH SPOT | 101 | not checked | - | - | - | - |
| SECOND HUNTER | 1 | 1 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 22 | not checked | - | - | - | - |
| SET-UP MISSED | 1 | trace | - | - | - | - |
| SHOTS IN THE MOVE | 721 | not checked | - | - | - | - |
| SPELL CATCH ODDS | 1 | not checked | - | - | - | - |
| SPELL SETS UP CHARGE | 4 | not checked | - | - | - | - |
| SPELL WORTH | 136 | not checked | - | - | - | - |
| STOPS | 5 | 5 | 0 | 0.00 | - | - |
| THROUGH LINE OF FIRE | 31 | not checked | - | - | - | - |

### Plans: bg-on-789c37f-p4

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 12.9 | 19% | 603 | 438 | 73% |
| Mine | charge | 3.2 | 50% | 289 | 243 | 84% |
| Mine | close in | 4.8 | 24% | 297 | 70 | 24% |
| Mine | hold | 4.3 | 40% | 304 | 0 | 0% |
| Mine | join | 0.7 | 92% | 20 | 0 | 0% |
| Mine | shoot | 8.5 | 62% | 345 | 695 | 201% |
| Mine | support | 4.6 | 88% | 236 | 0 | 0% |
| Opponent | advance | 14.1 | 21% | 694 | 438 | 63% |
| Opponent | charge | 5.2 | 63% | 570 | 525 | 92% |
| Opponent | close in | 5.2 | 32% | 401 | 195 | 49% |
| Opponent | hold | 4.2 | 29% | 343 | 0 | 0% |
| Opponent | join | 0.6 | 95% | 24 | 0 | 0% |
| Opponent | shoot | 3.4 | 59% | 83 | 241 | 290% |
| Opponent | support | 6.3 | 86% | 185 | 0 | 0% |

### Packages: hunt the guns, bg-on-789c37f-p4

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.1 | 5 | 1 | 0% | 25% | 0% | 2.0 | 386 | 48 | 25% | 23 |
| Opponent | 0.2 | 8 | 0 | 25% | 25% | 0% | 2.5 | 344 | 44 | 12% | 70 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Dwarfen Mountain Holds | 1.0 | 3 | 0 | 0% | 0% | 0% | - | 450 | 0 | 0% | 100 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 113 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Kingdom of Bretonnia | 1.0 | 1 | 1 | - | - | - | - | - | - | - | 0 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 117 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 117 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 41 |
| Tomb Kings of Khemri | 0.5 | 2 | 0 | 0% | 50% | 0% | 2.0 | 310 | 97 | 50% | 0 |
| Vampire Counts | 0.5 | 4 | 0 | 25% | 25% | 0% | 3.0 | 302 | 31 | 0% | 95 |
| Warriors of Chaos | 0.2 | 2 | 0 | 50% | 50% | 0% | 2.0 | 247 | 115 | 50% | 72 |
| Wood Elf Realms | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 630 | 0 | 0% | 0 |

### Battle groups: bg-on-789c37f-p4

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 8.8 | 30% | 46% | 16% | 27% | 37% | 14% | 5% | 44% | 0% |
| Mine | REDIRECT COUNTER | 3.5 | 35% | 68% | 14% | 17% | 13% | 0% | 8% | 66% | 13% |
| Opponent | COUNTER-CHARGE COVER | 8.6 | 17% | 53% | 16% | 25% | 42% | 2% | 12% | 44% | 0% |
| Opponent | REDIRECT COUNTER | 5.3 | 19% | 81% | 22% | 25% | 14% | 3% | 21% | 52% | 10% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.1 | 5 | 0% | - |
| Opponent | 0.2 | 6 | 0% | - |

### Deployment: positions vs output by unit type: bg-on-789c37f-p4

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 4 | 0 (4) | 0 | 0 | 100 | 75% | 5.0 | - | 0 (1) | - | 0 (1) | - |
| Mine | Chaff | 49 | 49 (49) | 22 | 26 | 63 | 24% | 2.8 | 35 (21) | 51 (11) | 66 (17) | 65 (32) | 17 (17) |
| Mine | Character | 106 | 55 (106) | 55 | 0 | 32 | 16% | 2.3 | 51 (35) | 65 (48) | 7 (9) | 55 (50) | 57 (42) |
| Mine | Clean-up | 14 | 34 (14) | 1 | 33 | 66 | 14% | 3.7 | 35 (6) | 41 (5) | 21 (3) | 26 (7) | 41 (7) |
| Mine | Early | 1 | 0 (1) | 0 | 0 | 100 | 0% | 3.0 | - | 0 (1) | - | - | 0 (1) |
| Mine | Fast Hammer | 39 | 37 (39) | 19 | 19 | 64 | 15% | 2.6 | 20 (24) | 83 (9) | 41 (6) | 41 (28) | 27 (11) |
| Mine | Fragile | 4 | 0 (4) | 0 | 0 | 73 | 25% | 2.3 | 0 (3) | 0 (1) | - | 0 (1) | 0 (3) |
| Mine | Hammer | 64 | 38 (64) | 29 | 9 | 53 | 16% | 2.5 | 56 (10) | 26 (44) | 87 (10) | 42 (39) | 33 (25) |
| Mine | Holder | 30 | 90 (30) | 6 | 84 | 23 | 40% | 2.7 | 10 (7) | 139 (18) | 33 (5) | 99 (18) | 76 (12) |
| Mine | Shooter | 35 | 81 (35) | 37 | 45 | 38 | 3% | 1.6 | 67 (11) | 96 (19) | 58 (5) | 106 (23) | 37 (12) |
| Mine | Support | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Mine | War machine | 56 | 37 (56) | 37 | 0 | 31 | 5% | 1.2 | 35 (20) | 39 (31) | 32 (5) | 0 (7) | 42 (49) |
| Mine | Wizard | 17 | 25 (17) | 25 | 0 | 64 | 6% | 2.0 | 58 (4) | 29 (4) | 29 (1) | 29 (1) | 44 (8) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Chaff | 82 | 63 (82) | 34 | 29 | 61 | 39% | 2.5 | 59 (30) | 60 (21) | 69 (31) | 64 (62) | 59 (20) |
| Opponent | Character | 97 | 58 (97) | 57 | 1 | 27 | 21% | 2.3 | 58 (42) | 56 (40) | 91 (7) | 54 (49) | 66 (40) |
| Opponent | Clean-up | 12 | 88 (12) | 10 | 78 | 24 | 50% | 2.8 | 0 (3) | 128 (6) | 39 (3) | 84 (7) | 92 (5) |
| Opponent | Fast | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Fast Hammer | 54 | 37 (54) | 32 | 5 | 46 | 31% | 2.6 | 42 (27) | 27 (17) | 40 (10) | 34 (34) | 41 (20) |
| Opponent | Fragile | 16 | 0 (16) | 0 | 0 | 63 | 25% | 1.8 | 0 (2) | 0 (8) | 0 (3) | 0 (9) | 0 (4) |
| Opponent | Hammer | 64 | 21 (64) | 13 | 7 | 42 | 31% | 3.4 | 9 (20) | 22 (38) | 43 (6) | 20 (42) | 21 (22) |
| Opponent | Holder | 27 | 44 (27) | 9 | 35 | 29 | 44% | 4.2 | 22 (9) | 58 (15) | 24 (3) | 48 (13) | 40 (14) |
| Opponent | Shooter | 34 | 103 (34) | 49 | 55 | 41 | 0% | 1.5 | 79 (9) | 101 (23) | 219 (2) | 120 (20) | 79 (14) |
| Opponent | Support | 6 | 0 (6) | 0 | 0 | 49 | 50% | 2.0 | 0 (2) | 0 (1) | - | - | 0 (3) |
| Opponent | War machine | 6 | 125 (6) | 125 | 0 | 19 | 0% | 1.7 | 78 (3) | 192 (3) | - | 78 (3) | 192 (3) |
| Opponent | Wizard | 20 | 8 (20) | 8 | 0 | 51 | 10% | 2.7 | 17 (10) | 0 (3) | 0 (2) | 19 (8) | 1 (7) |

### Charged fights: bg-on-789c37f-p4

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 195 | 69 | 2.2 | 1.0 | 31 | 6 | +25 | 2 of 9 | 8 of 9 | - | +25 |
| Mine | Chaos Dwarfs | 4 | 204 | 144 | 4.5 | 1.1 | 32 | 108 | -76 | 7 of 18 | 14 of 18 | +0 | -80 |
| Mine | Dwarfen Mountain Holds | 3 | 578 | 71 | 1.7 | 1.0 | 43 | 0 | +43 | 3 of 5 | 4 of 5 | - | +43 |
| Mine | Empire of Man | 5 | 292 | 176 | 1.4 | 1.1 | 126 | 0 | +126 | 3 of 7 | 6 of 7 | +177 | +117 |
| Mine | Grand Cathay | 4 | 412 | 226 | 4.2 | 1.2 | 53 | 17 | +36 | 4 of 17 | 14 of 17 | +37 | +35 |
| Mine | High Elf Realms | 4 | 426 | 164 | 2.8 | 1.0 | 60 | 32 | +28 | 3 of 11 | 7 of 11 | - | +28 |
| Mine | Kingdom of Bretonnia | 1 | 120 | 0 | 3.0 | 1.0 | 0 | 92 | -92 | 2 of 3 | 1 of 3 | - | -92 |
| Mine | Lizardmen | 1 | 55 | 1419 | 4.0 | 1.2 | 355 | 0 | +355 | 3 of 4 | 3 of 4 | +0 | +473 |
| Mine | Ogre Kingdoms | 2 | 57 | 412 | 6.5 | 1.0 | 63 | 49 | +15 | 8 of 13 | 7 of 13 | - | +15 |
| Mine | Skaven | 2 | 233 | 56 | 0.5 | 1.0 | 112 | 0 | +112 | 0 of 1 | 0 of 1 | - | +112 |
| Mine | Tomb Kings of Khemri | 2 | 173 | 666 | 4.5 | 1.1 | 148 | 43 | +105 | 3 of 9 | 6 of 9 | +75 | +108 |
| Mine | Vampire Counts | 2 | 25 | 206 | 4.0 | 1.0 | 52 | 25 | +27 | 2 of 8 | 7 of 8 | - | +27 |
| Mine | Warriors of Chaos | 2 | 0 | 314 | 5.0 | 1.1 | 63 | 0 | +63 | 4 of 10 | 8 of 10 | +91 | +60 |
| **Mine** | all armies | 36 | 258 | 229 | 3.2 | 1.1 | 72 | 36 | +36 | 44 of 115 | 85 of 115 | +57 | +34 |
| Opponent | Empire of Man | 1 | 903 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 0 of 1 | 1 of 1 | - | +0 |
| Opponent | High Elf Realms | 5 | 249 | 453 | 3.6 | 1.2 | 126 | 92 | +34 | 8 of 18 | 7 of 18 | +113 | +18 |
| Opponent | Lizardmen | 2 | 138 | 384 | 4.5 | 1.3 | 85 | 120 | -35 | 4 of 9 | 4 of 9 | +90 | -97 |
| Opponent | Orc & Goblin Tribes | 3 | 0 | 561 | 3.3 | 1.1 | 168 | 43 | +126 | 3 of 10 | 5 of 10 | +175 | +120 |
| Opponent | Skaven | 4 | 0 | 190 | 2.5 | 1.0 | 76 | 24 | +52 | 5 of 10 | 7 of 10 | - | +52 |
| Opponent | Tomb Kings of Khemri | 2 | 90 | 862 | 4.0 | 1.0 | 216 | 101 | +115 | 4 of 8 | 4 of 8 | - | +115 |
| Opponent | Vampire Counts | 6 | 38 | 566 | 5.2 | 1.3 | 110 | 35 | +75 | 18 of 31 | 14 of 31 | +198 | +39 |
| Opponent | Warriors of Chaos | 7 | 12 | 439 | 3.6 | 1.1 | 123 | 23 | +100 | 9 of 25 | 17 of 25 | +181 | +89 |
| Opponent | Wood Elf Realms | 6 | 71 | 395 | 5.7 | 1.3 | 70 | 14 | +56 | 10 of 34 | 17 of 34 | +97 | +41 |
| **Opponent** | all armies | 36 | 93 | 446 | 4.1 | 1.2 | 110 | 43 | +67 | 61 of 146 | 76 of 146 | +138 | +51 |

### Effective charges: bg-on-789c37f-p4

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 9 | 0 | 0 | 0 | 1 (net +0) | 0 | 4 (net +12) | 4 | 0% (0 of 5) |
| Mine | Chaos Dwarfs | 18 | 3 (net -145) | 0 | 4 (net -254) | 1 (net +0) | 3 (net +30) | 4 (net +44) | 3 | 27% (4 of 15) |
| Mine | Dwarfen Mountain Holds | 5 | 0 | 0 | 1 (net +0) | 2 (net +0) | 0 | 2 (net +107) | 0 | 20% (1 of 5) |
| Mine | Empire of Man | 7 | 2 (net +0) | 0 | 0 | 0 | 0 | 3 (net +203) | 2 | 0% (0 of 5) |
| Mine | Grand Cathay | 17 | 0 | 1 (net +109) | 3 (net +54) | 2 (net +70) | 3 (net +68) | 8 (net -1) | 0 | 18% (3 of 17) |
| Mine | High Elf Realms | 11 | 1 (net +233) | 0 | 3 (net -116) | 4 (net +16) | 1 (net +0) | 1 (net +314) | 1 | 30% (3 of 10) |
| Mine | Kingdom of Bretonnia | 3 | 0 | 0 | 0 | 0 | 0 | 2 (net -138) | 1 | 0% (0 of 2) |
| Mine | Lizardmen | 4 | 0 | 0 | 1 (net +0) | 2 (net +582) | 0 | 1 (net +255) | 0 | 25% (1 of 4) |
| Mine | Ogre Kingdoms | 13 | 2 (net -56) | 1 (net +0) | 3 (net -25) | 1 (net +274) | 1 (net +0) | 2 (net +79) | 3 | 30% (3 of 10) |
| Mine | Skaven | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +112) | 0 | 0% (0 of 1) |
| Mine | Tomb Kings of Khemri | 9 | 1 (net +0) | 0 | 3 (net -8) | 2 (net +197) | 1 (net +75) | 1 (net +693) | 1 | 38% (3 of 8) |
| Mine | Vampire Counts | 8 | 1 (net -197) | 0 | 0 | 3 (net +9) | 2 (net +111) | 2 (net +82) | 0 | 0% (0 of 8) |
| Mine | Warriors of Chaos | 10 | 0 | 0 | 1 (net +0) | 1 (net +27) | 2 (net +134) | 4 (net +61) | 2 | 12% (1 of 8) |
| Opponent | High Elf Realms | 18 | 1 (net -123) | 2 (net -322) | 3 (net -183) | 1 (net +115) | 1 (net +55) | 6 (net +244) | 4 | 21% (3 of 14) |
| Opponent | Lizardmen | 9 | 3 (net -58) | 0 | 0 | 2 (net -202) | 2 (net -20) | 2 (net +155) | 0 | 0% (0 of 9) |
| Opponent | Orc & Goblin Tribes | 10 | 0 | 0 | 1 (net +347) | 2 (net +250) | 0 | 0 | 7 | 33% (1 of 3) |
| Opponent | Skaven | 10 | 1 (net +0) | 1 (net +0) | 2 (net +380) | 1 (net +0) | 1 (net +0) | 3 (net -81) | 1 | 22% (2 of 9) |
| Opponent | Tomb Kings of Khemri | 8 | 0 | 0 | 2 (net +206) | 1 (net +45) | 0 | 2 (net +358) | 3 | 40% (2 of 5) |
| Opponent | Vampire Counts | 31 | 7 (net -80) | 0 | 3 (net +105) | 10 (net +21) | 2 (net +0) | 6 (net +339) | 3 | 11% (3 of 28) |
| Opponent | Warriors of Chaos | 25 | 2 (net +276) | 0 | 3 (net -33) | 2 (net +252) | 4 (net +44) | 11 (net +100) | 3 | 14% (3 of 22) |
| Opponent | Wood Elf Realms | 34 | 7 (net +75) | 1 (net +0) | 6 (net +51) | 4 (net +10) | 6 (net +58) | 9 (net +78) | 1 | 18% (6 of 33) |

### Charged fights, damage counted: bg-on-789c37f-p4

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 10 | 288 | 362 | -51 | 117 | 121 | -4 | -1.3 |
| Mine | 50-54% | 2 | 80 | 82 | +54 | 68 | 0 | +68 | +85.3 |
| Mine | Effective (55-75%) | 19 | 314 | 238 | -68 | 66 | 104 | -39 | -12.3 |
| Mine | 76-89% | 19 | 247 | 178 | +110 | 120 | 16 | +104 | +42.0 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 35 | 208 | 176 | +77 | 122 | 38 | +84 | +40.6 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 13 | 437 | 97 | +66 | 77 | 0 | +77 | +17.7 |
| Mine | No odds | 17 | 336 | 213 | +9 | 64 | 59 | +4 | +1.3 |
| Mine | All fights | 115 | 281 | 198 | +36 | 97 | 51 | +47 | +16.6 |
| Opponent | Long shot (under 50%) | 21 | 173 | 285 | +11 | 71 | 72 | -2 | -0.9 |
| Opponent | 50-54% | 4 | 236 | 187 | -161 | 35 | 161 | -126 | -53.4 |
| Opponent | Effective (55-75%) | 20 | 436 | 314 | +75 | 162 | 105 | +58 | +13.3 |
| Opponent | 76-89% | 23 | 236 | 163 | +44 | 104 | 66 | +38 | +16.2 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 39 | 315 | 193 | +156 | 182 | 23 | +159 | +50.5 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 16 | 412 | 84 | +34 | 73 | 33 | +40 | +9.8 |
| Opponent | No odds | 23 | 279 | 201 | +44 | 127 | 76 | +51 | +18.2 |
| Opponent | All fights | 146 | 302 | 207 | +67 | 127 | 61 | +65 | +21.6 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| bg-on-789c37f-p4 | move | 461 | 121 (26%) | 87 (19%) | 53 (11%) | 287 (62%) |
| bg-on-789c37f-p4 | objective | 368 | 61 (17%) | 46 (12%) | 47 (13%) | 260 (71%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0114, L0130, L2527, L2634 |
| Charmed Shield | Opponent | L0434, L0624, L0926, L1034, L1126, L1427, L2227, L2527, L2634, L3234 |
| Clockwork Compass | Mine | L1220 |
| Elixir of Power | Mine | L1126 |
| Elixir of Power | Opponent | L0819, L1719, L1819 |
| Fistful of Laurels | Mine | L1819, L1835 |
| Invocation of Nehek | Mine | L2527 |
| Invocation of Nehek | Opponent | L0624, L1427, L2227, L2527 |
| Opal Amulet | Mine | L1427 |
| Opal Amulet | Opponent | L0114, L0214, L1314 |
| Periapt of Soul Exchange | Mine | L2021, L2123 |
| Periapt of Soul Exchange | Opponent | L0520, L1220, L1621, L2021 |
| Ring of Doom | Mine | L0214, L0230, L1126, L1220, L1523 |
| Ring of Doom | Opponent | L0315, L1331, L2331 |
| Ring of Jet | Mine | L1017, L1034, L1126, L1220 |
| Standard of the Fell Warrior | Mine | L1314, L1331 |
| Standard of the Fell Warrior | Opponent | L0713 |
| Storm Daemon (Renegade 2.0) | Mine | L2123 |
| Storm Daemon (Renegade 2.0) | Opponent | L1621, L2021 |
| Twice-Blessed Armour | Mine | L0713, L0729, L1017, L1034 |
| Witch Hunter's Ward | Mine | L0713, L0729, L0819, L0835 |
| Witch Hunter's Ward | Opponent | L0608 |

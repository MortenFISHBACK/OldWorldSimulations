# Doctrine scorecard: bg-off-789c37f-p3

### Scorecard: bg-off-789c37f-p3

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0110 | 2 | 1 | Mine | - | - | 1 | 1 | 0 | 0 | 0 | 0 | 0 |
| L0110 | 2 | 1 | Opponent | - | - | 2 | 3 | 2 | 0 | 0 | 0 | 330 |
| L0126 | 6 | 1 | Mine | no | 2 | - | 0 | 1 | 0 | 0 | 0 | 387 |
| L0126 | 6 | 1 | Opponent | no | 11 | 2 | 3 | 3 | 0 | 0 | 0 | 0 |
| L0210 | 6 | 1 | Mine | no | 0 | 2 | 1 | 3 | 0 | 0 | 0 | 0 |
| L0210 | 6 | 1 | Opponent | no | 11 | 5 | 0 | 1 | 0 | 0 | 0 | 330 |
| L0226 | 4 | 1 | Mine | no | 2 | 2 | 2 | 3 | 0 | 0 | 0 | 170 |
| L0226 | 4 | 1 | Opponent | no | 9 | 2 | 0 | 3 | 0 | 0 | 0 | 0 |
| L0311 | 5 | 1 | Mine | no | - | - | 0 | 2 | 0 | 0 | 0 | 760 |
| L0311 | 5 | 1 | Opponent | yes | - | 5 | 1 | 0 | 0 | 0 | 0 | 330 |
| L0327 | 3 | 1 | Mine | yes | 2 | 4 | 1 | 0 | 0 | 0 | 0 | 760 |
| L0327 | 3 | 1 | Opponent | no | 8 | 3 | 5 | 3 | 0 | 0 | 0 | 0 |
| L0413 | 5 | 1 | Mine | yes | - | 2 | 3 | 2 | 0 | 0 | 0 | 0 |
| L0413 | 5 | 1 | Opponent | yes | - | 4 | 1 | 1 | 0 | 0 | 0 | 291 |
| L0429 | 3 | 1 | Mine | yes | 8 | 2 | 1 | 2 | 0 | 0 | 0 | 139 |
| L0429 | 3 | 1 | Opponent | no | 0 | 2 | 5 | 2 | 1 | 0 | 0 | 170 |
| L0516 | 6 | 1 | Mine | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 548 |
| L0516 | 6 | 1 | Opponent | no | 0 | 3 | 2 | 3 | 1 | 0 | 0 | 280 |
| L0533 | 5 | 1 | Mine | no | - | - | 0 | 3 | 0 | 0 | 0 | 548 |
| L0533 | 5 | 1 | Opponent | no | - | 5 | 1 | 6 | 0 | 0 | 0 | 0 |
| L0620 | 2 | 1 | Mine | - | - | 2 | 4 | 1 | 0 | 0 | 0 | 615 |
| L0620 | 2 | 1 | Opponent | - | - | - | 0 | 4 | 0 | 0 | 0 | 0 |
| L0709 | 1 | 1 | Mine | yes | 4 | 2 | 2 | 0 | 1 | 0 | 0 | 420 |
| L0709 | 1 | 1 | Opponent | yes | 1 | 6 | 1 | 1 | 1 | 0 | 0 | 420 |
| L0725 | 5 | 1 | Mine | yes | - | 6 | 2 | 1 | 0 | 0 | 0 | 375 |
| L0725 | 5 | 1 | Opponent | yes | - | 2 | 4 | 4 | 0 | 0 | 0 | 0 |
| L0815 | 5 | 1 | Mine | no | - | 4 | 2 | 0 | 0 | 0 | 0 | 679 |
| L0815 | 5 | 1 | Opponent | no | - | 3 | 2 | 2 | 2 | 0 | 0 | 0 |
| L0831 | 3 | 1 | Mine | yes | 3 | 2 | 0 | 1 | 0 | 0 | 0 | 605 |
| L0831 | 3 | 1 | Opponent | no | 4 | - | 1 | 3 | 2 | 0 | 0 | 340 |
| L0922 | 4 | 1 | Mine | no | 0 | 3 | 2 | 1 | 0 | 0 | 0 | 524 |
| L0922 | 4 | 1 | Opponent | no | 1 | 2 | 1 | 2 | 0 | 0 | 0 | 55 |
| L1013 | 5 | 1 | Mine | yes | - | 2 | 1 | 2 | 0 | 0 | 0 | 330 |
| L1013 | 5 | 1 | Opponent | no | - | 1 | 3 | 0 | 0 | 0 | 0 | 140 |
| L1030 | 4 | 1 | Mine | no | 2 | 2 | 3 | 0 | 0 | 0 | 0 | 501 |
| L1030 | 4 | 1 | Opponent | no | 3 | 2 | 0 | 1 | 0 | 0 | 0 | 173 |
| L1122 | 6 | 1 | Mine | no | 5 | 2 | 1 | 0 | 0 | 0 | 0 | 330 |
| L1122 | 6 | 1 | Opponent | no | 0 | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L1216 | 4 | 1 | Mine | no | 1 | 3 | 2 | 0 | 0 | 0 | 0 | 330 |
| L1216 | 4 | 1 | Opponent | no | 0 | 2 | 2 | 1 | 0 | 0 | 0 | 200 |
| L1232 | 2 | 1 | Mine | - | - | 2 | 2 | 0 | 0 | 0 | 0 | 330 |
| L1232 | 2 | 1 | Opponent | - | - | 2 | 5 | 3 | 1 | 0 | 0 | 340 |
| L1327 | 1 | 1 | Mine | no | 10 | 4 | 3 | 0 | 0 | 0 | 0 | 140 |
| L1327 | 1 | 1 | Opponent | no | 1 | 2 | 1 | 6 | 2 | 0 | 0 | 50 |
| L1422 | 6 | 1 | Mine | no | 2 | 2 | 7 | 0 | 0 | 0 | 0 | 0 |
| L1422 | 6 | 1 | Opponent | no | 0 | 1 | 3 | 0 | 0 | 0 | 0 | 297 |
| L1519 | 1 | 1 | Mine | no | 0 | 3 | 3 | 2 | 0 | 0 | 0 | 0 |
| L1519 | 1 | 1 | Opponent | no | 0 | 2 | 8 | 1 | 0 | 0 | 0 | 317 |
| L1535 | 5 | 1 | Mine | yes | - | 2 | 3 | 1 | 1 | 0 | 0 | 0 |
| L1535 | 5 | 1 | Opponent | yes | - | 3 | 0 | 3 | 0 | 0 | 0 | 657 |
| L1633 | 1 | 1 | Mine | no | 1 | 2 | 3 | 2 | 0 | 0 | 0 | 200 |
| L1633 | 1 | 1 | Opponent | no | 0 | 1 | 2 | 3 | 1 | 0 | 0 | 773 |
| L1731 | 3 | 1 | Mine | yes | 5 | 4 | 6 | 1 | 0 | 0 | 0 | 98 |
| L1731 | 3 | 1 | Opponent | no | 1 | 2 | 2 | 1 | 2 | 0 | 0 | 340 |
| L1831 | 1 | 1 | Mine | no | 7 | 3 | 2 | 0 | 0 | 0 | 0 | 0 |
| L1831 | 1 | 1 | Opponent | no | 2 | 3 | 2 | 0 | 1 | 0 | 0 | 170 |
| L1932 | 6 | 1 | Mine | no | 3 | 2 | 4 | 0 | 1 | 0 | 0 | 161 |
| L1932 | 6 | 1 | Opponent | no | 1 | 3 | 5 | 0 | 0 | 0 | 0 | 477 |
| L2033 | 5 | 1 | Mine | no | - | - | 0 | 6 | 1 | 0 | 0 | 210 |
| L2033 | 5 | 1 | Opponent | yes | - | 2 | 2 | 5 | 0 | 0 | 0 | 0 |
| L2223 | 3 | 1 | Mine | yes | 3 | 2 | 8 | 0 | 1 | 0 | 0 | 332 |
| L2223 | 3 | 1 | Opponent | no | 0 | 1 | 7 | 1 | 1 | 0 | 0 | 72 |
| L2327 | 5 | 1 | Mine | yes | - | 2 | 2 | 1 | 0 | 0 | 0 | 66 |
| L2327 | 5 | 1 | Opponent | yes | - | 2 | 3 | 0 | 0 | 0 | 0 | 0 |
| L2433 | 3 | 1 | Mine | no | 12 | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L2433 | 3 | 1 | Opponent | no | 0 | 1 | 4 | 2 | 0 | 0 | 0 | 352 |
| L2630 | 2 | 1 | Mine | - | - | 2 | 3 | 2 | 0 | 0 | 0 | 0 |
| L2630 | 2 | 1 | Opponent | - | - | 2 | 2 | 2 | 1 | 0 | 0 | 312 |
| L2832 | 6 | 1 | Mine | no | 1 | - | 0 | 0 | 1 | 0 | 0 | 589 |
| L2832 | 6 | 1 | Opponent | no | 7 | 2 | 4 | 1 | 1 | 0 | 0 | 0 |
| L3133 | 1 | 1 | Mine | no | 0 | 2 | 3 | 2 | 0 | 0 | 0 | 392 |
| L3133 | 1 | 1 | Opponent | no | 0 | 3 | 0 | 2 | 0 | 0 | 0 | 252 |
| **Average** | | | Mine | 34% | 3.2 | 2.5 | 2.2 | 1.2 | 0.2 | 0.0 | 0.0 | 292.8 |
| **Average** | | | Opponent | 22% | 2.6 | 2.5 | 2.5 | 2.0 | 0.5 | 0.0 | 0.0 | 207.4 |

### KPIs: bg-off-789c37f-p3

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Winner chose to follow up after the loser gave ground |  | 91% (64 of 70); on the table 91% | 100% (50 of 50); on the table 100% | 95% (114 of 120); on the table 95% |
| Winner chose to pursue after the loser fell back in good order |  | 92% (11 of 12); on the table 92% | 85% (11 of 13); on the table 92% | 88% (22 of 25); on the table 92% |
| Winner chose to pursue after the loser fled |  | 79% (26 of 33); on the table 82% | 64% (14 of 22); on the table 68% | 73% (40 of 55); on the table 76% |
| Winner chose to follow up or pursue (all three) |  | 88% (101 of 115); on the table 89% | 88% (75 of 85); on the table 91% | 88% (176 of 200); on the table 90% |
| Magic missiles tried each own turn | 50%+ | 26% (88 of 342) | 27% (51 of 192) | 26% (139 of 534) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 38% (88 of 234) | 33% (51 of 153) | 36% (139 of 387) |
| Points that never fought | lower | 42% (28829 of 68801) | 37% (26678 of 71990) | 39% (55507 of 140791) |
|   infantry points that never fought | lower | 49% (6894 of 14174) | 52% (7361 of 14220) | 50% (14255 of 28394) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 56% (152 of 272) | 62% (178 of 285) | 59% (330 of 557) |
| Bound items with a magic missile used (at least once a game) |  | 88% (22 of 25); 1.6 uses a game | 71% (17 of 24); 1.2 uses a game | 80% (39 of 49); 1.4 uses a game |
| Bound items with another spell used |  | 36% (5 of 14); 0.4 uses a game | 83% (5 of 6); 0.2 uses a game | 50% (10 of 20); 0.3 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 40% (8 of 20); 0.2 uses a game | 29% (4 of 14); 0.1 uses a game | 35% (12 of 34); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 49% (29356 of 59391) | 56% (36149 of 64043) | 53% (65505 of 123434) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.4 (20%) | 0.8 (19%) | 2.2 (20%) |
| MARCHED: its unit marched | 1.9 (26%) | 1.8 (47%) | 3.7 (34%) |
| CHARGED: its unit charged | 0.4 (6%) | 0.1 (4%) | 0.6 (5%) |
| IN COMBAT: engaged in combat | 1.4 (20%) | 0.6 (15%) | 2.0 (18%) |
| REAR RANK: in a rear rank | 0.1 (1%) | 0.0 (1%) | 0.1 (1%) |
| FLEEING: fleeing | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | 1.0 (14%) | 0.5 (13%) | 1.5 (13%) |
| OFF THE TABLE: off the table or not arrived | 0.6 (8%) | 0.0 (0%) | 0.6 (5%) |
| STUPIDITY: Stupidity | 0.1 (2%) | 0.0 (0%) | 0.1 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (1%) | 0.1 (2%) | 0.1 (1%) |
| NOT OFFERED: not in the cast list | 0.1 (2%) | 0.0 (0%) | 0.1 (1%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.7 | 1.2 | 1.8 | 3.9 | 0.7 | 1.4 |
| not cast | 4.1 | 1.4 | 4.3 | 11.0 | 2.6 | 19.2 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) | 0.0 (0%) | 1.3 (7%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (1%) | 0.6 (41%) | 0.4 (9%) | 2.2 (20%) | 0.4 (15%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 3.7 (34%) | 0.9 (35%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.6 (5%) | 0.1 (4%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.1 (3%) | 0.1 (8%) | 0.6 (13%) | 2.0 (18%) | 0.5 (18%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.2 (4%) | 0.0 (0%) | 0.2 (4%) | 0.1 (1%) | 0.1 (2%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.1 (2%) | 0.4 (2%) |
| GONE: slain | 1.2 (30%) | 0.1 (8%) | 0.6 (15%) | 1.5 (13%) | 0.3 (13%) | 1.7 (9%) |
| OFF THE TABLE: off the table or not arrived | 0.3 (7%) | 0.3 (24%) | 0.4 (10%) | 0.6 (5%) | 0.1 (4%) | 0.8 (4%) |
| STUPIDITY: Stupidity | 0.1 (3%) | 0.0 (0%) | 0.1 (3%) | 0.1 (1%) | 0.0 (0%) | 0.1 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (2%) | 0.1 (6%) | 0.0 (0%) | 0.1 (1%) | 0.2 (7%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.1 (50%) | 0.2 (14%) | 1.9 (45%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 14.9 (78%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.2 a game | 0.7 a game | 1.0 a game |
| stood (cast and not dispelled) | 61% (20 of 33) | 53% (10 of 19) | 58% (30 of 52) |
| the unit moved after it | 65% (13 of 20) | 90% (9 of 10) | 73% (22 of 30) |
| it charged on its next turn | 0% (0 of 20) | 10% (1 of 10) | 3% (1 of 30) |
| the enemy charged it first | 10% (2 of 20) | 0% (0 of 10) | 7% (2 of 30) |
| it fought by the end of its next turn | 5% (1 of 20) | 0% (0 of 10) | 3% (1 of 30) |
| it moved out of a charge the enemy had planned (not charged first) | 30% (6 of 20) | 10% (1 of 10) | 23% (7 of 30) |
| none of these (no charge, no fight, no charge escaped) | 60% (12 of 20) | 80% (8 of 10) | 67% (20 of 30) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 62% (481 of 780) | 52% (319 of 608) | 58% (800 of 1388) |
|   cavalry | 64% (45 of 70) | 55% (58 of 105) | 59% (103 of 175) |
|   character | 39% (45 of 115) | 21% (24 of 113) | 30% (69 of 228) |
|   chariot | 33% (26 of 79) | 66% (21 of 32) | 42% (47 of 111) |
|   infantry | 56% (118 of 210) | 59% (158 of 269) | 58% (276 of 479) |
|   monster | 39% (13 of 33) | 50% (1 of 2) | 40% (14 of 35) |
|   war machine | 86% (234 of 273) | 66% (57 of 87) | 81% (291 of 360) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.8 (33%) | 2.2 (28%) | 5.0 (31%) |
| CHARGED: it charged | 1.0 (12%) | 1.3 (16%) | 2.2 (14%) |
| FLEEING: it fled or was fleeing | 0.1 (1%) | 0.1 (1%) | 0.2 (1%) |
| IN COMBAT: it fought this turn or the last | 0.8 (9%) | 0.7 (9%) | 1.5 (9%) |
| MOVED: a war machine that moved | 0.1 (1%) | 0.1 (1%) | 0.1 (1%) |
| NO TARGET IN RANGE | 1.2 (15%) | 0.9 (11%) | 2.1 (13%) |
| ONLY IN COMBAT: the only targets were in combat | 0.2 (3%) | 0.3 (4%) | 0.6 (3%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.7 (20%) | 1.7 (21%) | 3.4 (21%) |
| SHELTERED: the target was sheltered | 0.1 (1%) | 0.6 (7%) | 0.7 (4%) |
| STUPIDITY | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR | 0.4 (4%) | 0.2 (2%) | 0.5 (3%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 4.3 | 1.5 | 74% | 9.6 pts | 41 pts |
| character | 2.2 | 0.9 | 72% | 9.7 pts | 22 pts |
| chariot | 1.3 | 0.6 | 62% | 15.7 pts | 20 pts |
| infantry | 11.6 | 4.6 | 72% | 10.0 pts | 116 pts |
| monster | 0.4 | 0.1 | 80% | 8.8 pts | 4 pts |
| war machine | 8.4 | 7.3 | 60% | 24.5 pts | 205 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.8 | 4.7 | 4.7 |
| Charges that made contact a game | 3.8 | 3.3 | 3.5 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.12 declared, 0.88 contact (25 units) | 0.84 declared, 0.63 contact (19 units) | 1.00 declared, 0.77 contact (44 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.50 declared, 0.50 contact (2 units) | 1.27 declared, 0.73 contact (11 units) | 1.15 declared, 0.69 contact (13 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.64 declared, 0.50 contact (223 units) | 0.52 declared, 0.37 contact (269 units) | 0.57 declared, 0.43 contact (492 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 56% (43 of 77) | 53% (8 of 15) | 40% (4 of 10) | 54% (55 of 102) |
| Character in a unit | 82% (32 of 39) | 62% (8 of 13) | 25% (1 of 4) | 73% (41 of 56) |
| Character on its own | 76% (29 of 38) | 53% (23 of 43) | 32% (23 of 71) | 49% (75 of 152) |
| Chariot | 91% (10 of 11) | 83% (10 of 12) | - | 87% (20 of 23) |
| Infantry | 67% (47 of 70) | 45% (19 of 42) | 20% (1 of 5) | 57% (67 of 117) |
| Monster | 65% (22 of 34) | 29% (2 of 7) | - | 59% (24 of 41) |
| Monstrous | 90% (9 of 10) | 45% (5 of 11) | - | 67% (14 of 21) |
| War Machines | 74% (32 of 43) | 100% (2 of 2) | - | 76% (34 of 45) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 100% (5 of 5); on the table 100% | 27% (26 of 96) | 41% | 50% (11 of 22) | 100% (6 of 6); 4.0 uses a game | 100% (2 of 2); 0.8 uses a game | 67% (4 of 6); 1.0 uses a game |
| Chaos Dwarfs | 4 | 86% (12 of 14); on the table 86% | 31% (11 of 36) | 46% | 66% (21 of 32) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |
| Dwarfen Mountain Holds | 3 | 25% (1 of 4); on the table 25% | - | 70% | 75% (18 of 24) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 6 | 93% (14 of 15); on the table 93% | 30% (9 of 30) | 52% | 63% (37 of 59) | 0.0 uses a game | 50% (1 of 2); 1.0 uses a game | 25% (1 of 4); 0.2 uses a game |
| Grand Cathay | 8 | 93% (26 of 28); on the table 93% | 26% (49 of 192) | 51% | 59% (44 of 74) | 83% (15 of 18); 4.5 uses a game | 75% (3 of 4); 0.9 uses a game | 25% (2 of 8); 0.2 uses a game |
| High Elf Realms | 7 | 84% (16 of 19); on the table 89% | 29% (12 of 42) | 31% | 50% (27 of 54) | 78% (7 of 9); 3.0 uses a game | 33% (4 of 12); 1.3 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 3 | 100% (6 of 6); on the table 100% | - | 45% | 39% (7 of 18) | 0.0 uses a game | 0.0 uses a game | 67% (2 of 3); 0.7 uses a game |
| Lizardmen | 1 | 80% (4 of 5); on the table 80% | 67% (4 of 6) | 26% | 43% (3 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 1 | 50% (1 of 2); on the table 100% | 0% (0 of 6) | 25% | 57% (4 of 7) | 100% (1 of 1); 4.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 2 | 88% (7 of 8); on the table 88% | 8% (1 of 12) | 14% | 69% (11 of 16) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.5 uses a game |
| Skaven | 2 | 100% (2 of 2); on the table 100% | 17% (2 of 12) | 60% | 57% (8 of 14) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |
| Tomb Kings of Khemri | 6 | 90% (9 of 10); on the table 90% | 0% (0 of 6) | 28% | 42% (11 of 26) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 8 | 92% (36 of 39); on the table 92% | 24% (13 of 54) | 25% | 52% (24 of 46) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 11 | 88% (29 of 33); on the table 88% | 33% (10 of 30) | 32% | 60% (58 of 96) | 25% (1 of 4); 0.2 uses a game | 0.0 uses a game | 100% (2 of 2); 0.2 uses a game |
| Wood Elf Realms | 6 | 80% (8 of 10); on the table 90% | 17% (2 of 12) | 47% | 74% (46 of 62) | 82% (9 of 11); 3.7 uses a game | 0.0 uses a game | 0% (0 of 5); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (bg-off-789c37f-p3, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 46% (30) | 44% (40) | 45% (70) |
| ...free all their last turn and able to turn (per game) | 0.47 | 0.83 | 1.31 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.22 | 0.14 | 0.36 |
| ...with the charger already in that arc before they moved (per game) | 0.28 | 0.64 | 0.92 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 1.36 | 1.06 | 2.42 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 1.19 | 0.92 | 2.11 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 10.39 | 10.03 | 20.42 |

### Quality by phase: bg-off-789c37f-p3

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.2 | 3.6 |
| Strategy | Charge objectives carried out (made contact) | 65% (93 of 143) | 43% (63 of 146) |
| Strategy | Shoot objectives carried out (shot that target) | 48% (166 of 346) | 55% (86 of 156) |
| Strategy | Close-in objectives charged next turn | 14% (25 of 184) | 12% (27 of 227) |
| Strategy | Support requests answered (helper made contact too) | 47% (9 of 19) | 56% (15 of 27) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 80% (4 of 5) | 100% (1 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | 64% (7 of 11) | 50% (3 of 6) |
| Strategy | Joined characters whose unit fought | 43% (20 of 47) | 29% (10 of 35) |
| Strategy | Lone characters that fought | 73% (64 of 88) | 75% (74 of 99) |
| Movement | Charges halted short of contact | 0.3 | 0.3 |
| Movement | Idle units | 1.2 | 2.0 |
| Movement | Points that never moved of their own | 292.8 | 207.4 |
| Movement | Fights charged into per game | 3.4 | 2.8 |
| Movement | Charges with odds: long shots (under 50%) | 12 of 106, net +72 | 9 of 80, net +134 |
| Movement | Charges with odds: sweet spot (55-75%) | 15 of 106, net +17 | 5 of 80, net -85 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 15 of 106, net +78 | 16 of 80, net +56 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 37 of 106, net +96 | 30 of 80, net +79 |
| Shooting | Shots by shooting units (incl. breath weapons) | 7.6 | 8.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 49% (134 of 273) | 47% (146 of 313) |
| Shooting | Points destroyed by shooting units | 63.4 | 38.6 |
| Shooting | War machine shots | 6.5 | 1.9 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 43% (100 of 234) | 33% (22 of 67) |
| Shooting | Points destroyed by war machines | 83.6 | 21.4 |
| Magic | Magic missiles cast | 1.6 | 0.9 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 41% (24 of 59) | 29% (10 of 34) |
| Magic | Wounds caused by magic missiles | 2.6 | 1.7 |
| Magic | Wounds caused by other spells | 1.9 | 1.1 |
| Magic | Points destroyed by magic (all spells) | 72.9 | 24.2 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.7 / 0.3 / 0.5 / 0.1 | 1.8 / 0.2 / 0.2 / 0.3 |
| Combat | Points destroyed in combat | 441.1 | 292.4 |
| Combat | Points run down | 119.9 | 61.9 |
| Combat | Net points per charged fight, damage counted | +91 | +48 |
| Combat | Net per 100 charger points, damage counted | +31.6 | +16.0 |
| Combat | First round won (charged fights) | 72% | 51% |
| Combat | Net points per charged fight | +92 | +42 |
| Combat | Net points per supported fight / lone fight | +184 / +80 | +129 / +28 |
| Combat | Charged fights on a top-3 enemy unit | 29 of 121 | 44 of 102 |
| Game | Points lost | 587.1 | 824.8 |
| Game | VP from objectives | 663.9 | 510.8 |
| Game | Lone holders (player turns) | 3.2 | 2.6 |

- Mine won / drew / lost: 20 / 7 / 9 of 36 ended games (of 36); mean margin (Mine - Opponent) +413 VP
- The side that went first won 18 of 29 games with a winner
- Points traded per game (both sides' losses): 1412
- Games not ended: 0; findings 1, warnings 0

### Opponent rules: bg-off-789c37f-p3

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.6 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| ALREADY CARRIED | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARRIVAL HUNT | - | - | - | - | 0.1 | +0.3 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.5 | +0.0 | 0.0 | 22.1 | 0.1 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | 0.8 | +6.9 | 0.0 | 19.4 | 0.6 | +6.5 | 0.0 | 21.8 |
| BEST PREY | 4.4 | +294.7 | 205.6 | 78.0 | 4.1 | +309.1 | 148.7 | 86.4 |
| BEST PRIZE | 0.1 | -8.8 | 5.7 | 0.0 | 0.1 | +5.8 | 3.9 | 0.0 |
| BLOCKED CHARGE SKIPPED | 0.0 | +0.0 | 15.0 | 0.0 | 0.0 | +0.0 | 6.5 | 0.0 |
| BLOCKED WHEEL | 0.4 | +14.0 | 0.0 | 0.0 | 0.4 | -0.1 | 0.0 | 0.0 |
| BOMBING RUN | - | - | - | - | 0.0 | +1.6 | 0.0 | 0.0 |
| BOUND ASSAILMENT | - | - | - | - | 0.0 | +0.0 | 0.0 | 4.2 |
| CANNON PLAN MISSED | 0.9 | +0.0 | 94.2 | 11.5 | 0.2 | +0.0 | 8.5 | 6.5 |
| CANNON PLANNED TARGET | 5.5 | +124.9 | 374.1 | 110.0 | 1.0 | +55.7 | 92.2 | 20.0 |
| CANNON SIGHT KEPT | 1.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CAST JOB | 1.0 | +31.5 | 92.1 | 13.7 | 0.5 | +18.4 | 38.6 | 6.5 |
| CASTER AWAY FROM SCREEN | 0.2 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.5 | +31.8 | 13.7 | 8.9 | 0.0 | +0.8 | 0.0 | 3.0 |
| CASTS AFTER FRIENDS | 0.5 | +0.0 | 0.0 | 19.2 | 0.4 | +0.0 | 0.0 | 16.2 |
| CASTS FROM BEHIND | 0.0 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.0 | +0.5 | 0.0 | 0.0 | - | - | - | - |
| CATCH ODDS | 0.0 | +0.6 | 0.0 | 0.0 | - | - | - | - |
| CHAFF PASSED | 0.1 | -0.1 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| CHAMPION TAKES THE CHALLENGE | - | - | - | - | 0.0 | +0.4 | 0.0 | 0.0 |
| CHARGE NOW WEIGHED | 0.8 | -67.9 | 28.2 | 18.5 | 0.6 | -69.2 | 14.3 | 9.0 |
| CHARIOT NO STATIC JOB | 0.7 | +0.0 | 11.3 | 19.1 | 0.6 | +0.0 | 10.7 | 8.2 |
| CHEAP HELPER | 0.1 | +0.0 | 1.7 | 0.0 | 0.1 | +0.0 | 5.2 | 1.1 |
| CONVEYANCE SEARCH | 0.5 | +21.1 | 19.5 | 20.4 | 0.4 | +16.2 | 6.5 | 11.8 |
| EDGE GIVE GROUND | 0.2 | +11.2 | 16.6 | 2.2 | 0.2 | +5.2 | 25.2 | 0.0 |
| ELIXIR WORTH | 0.0 | +0.6 | 0.0 | 0.0 | - | - | - | - |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 1.4 | +123.6 | 0.0 | 25.7 | 1.1 | +110.6 | 0.0 | 30.0 |
| FIGHT LIFT | 0.0 | +0.1 | 0.0 | 0.0 | 0.1 | +1.4 | 19.0 | 0.0 |
| FIRE AND FLEE | 0.0 | +0.4 | 0.0 | 4.6 | 0.0 | +2.1 | 0.0 | 0.0 |
| FOCUS FIRE | 0.0 | +0.5 | 2.0 | 0.0 | 0.1 | +3.0 | 4.1 | 0.0 |
| FOLLOW UP WEIGHED | 1.2 | +163.4 | 0.0 | 52.1 | 1.1 | +160.4 | 0.0 | 31.7 |
| FRIENDS SHOTS CHECKED | 0.2 | +13.5 | 0.0 | 5.2 | 0.1 | +11.8 | 0.0 | 7.6 |
| GIVES UP | 1.5 | -33.8 | 228.3 | 13.1 | 1.7 | -53.1 | 133.2 | 100.9 |
| GIVES UP ITS SCREEN | 0.5 | -20.4 | 38.1 | 8.1 | 0.8 | -17.0 | 66.8 | 8.9 |
| GROUND FLIERS | 0.1 | +0.9 | 0.0 | 0.0 | 0.0 | +0.5 | 0.0 | 0.0 |
| HELPER ALREADY ASKED | 0.0 | +0.0 | 1.7 | 0.0 | 0.1 | +0.0 | 12.2 | 7.2 |
| HELPER UNSEEN | 0.2 | +0.0 | 13.4 | 10.8 | 0.2 | +0.0 | 30.0 | 12.3 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HORN WORTH | - | - | - | - | 0.1 | +1.5 | 0.0 | 14.0 |
| HUNT ADVANCE | 0.2 | +15.4 | 23.7 | 1.4 | 0.1 | +6.1 | 3.5 | 6.1 |
| HUNT DROPPED | 0.1 | +0.0 | 9.2 | 0.0 | - | - | - | - |
| HUNT KEPT | 0.2 | +10.9 | 20.7 | 0.0 | 0.1 | +0.4 | 6.9 | 2.9 |
| HUNT RESULT | 0.2 | +24.7 | 9.2 | 0.0 | 0.1 | +6.5 | 0.0 | 0.0 |
| HUNT THE GUNS | 0.2 | +81.9 | 20.2 | 1.4 | 0.1 | +30.3 | 0.0 | 6.1 |
| JOINT CHARGE PLAN | 0.2 | +11.6 | 15.6 | 4.5 | 0.3 | +20.6 | 7.2 | 0.0 |
| KEEPS ITS PREY | 0.2 | +0.9 | 0.0 | 12.4 | 0.3 | +4.0 | 27.4 | 10.4 |
| KEEPS ITS TARGET | 1.9 | +58.3 | 186.4 | 41.4 | 2.1 | +63.3 | 75.7 | 38.8 |
| KEEPS SCOUTS OR AMBUSH | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KILLS COUNT | 1.9 | +68.5 | 135.4 | 52.9 | 2.0 | +110.6 | 127.5 | 89.4 |
| KILLS COUNT NEXT TURN | 9.2 | +350.9 | 467.0 | 154.9 | 9.9 | +395.1 | 294.3 | 212.7 |
| LONE CHARACTER SAFE SPOT | 0.6 | +47.7 | 21.3 | 10.6 | 0.3 | +14.4 | 1.9 | 14.2 |
| LONE WIZARD HOLDS BACK | 1.5 | +0.0 | 88.3 | 21.9 | 1.9 | +0.0 | 26.6 | 62.5 |
| LONE WIZARD KEPT IN | 0.6 | +37.3 | 0.0 | 0.0 | 0.3 | +22.1 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 0.8 | +60.2 | 35.5 | 4.5 | 0.9 | +46.0 | 32.3 | 13.0 |
| MANOEUVRE | 0.3 | +6.7 | 0.0 | 0.0 | 0.1 | +2.8 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.4 | +3.0 | 0.0 | 14.4 | 0.2 | +1.3 | 0.0 | 3.2 |
| MARCH ODDS | 1.1 | +62.7 | 54.6 | 0.0 | 0.9 | +51.2 | 20.4 | 21.9 |
| MISSILES IN THE MOVE | 3.5 | +110.0 | 0.0 | 40.6 | 2.9 | +50.5 | 0.0 | 40.9 |
| MISSILES NEXT TURN | 5.2 | +88.2 | 0.0 | 68.1 | 4.9 | +47.4 | 0.0 | 106.9 |
| MODEL FACING | 0.1 | +8.9 | 0.0 | 0.0 | - | - | - | - |
| MOVE AND CAST | 0.3 | +6.2 | 0.0 | 0.0 | 0.1 | +1.3 | 0.0 | 6.5 |
| MOVE SPELL IN RANGE | 0.3 | +12.3 | 0.0 | 21.1 | 0.0 | +0.2 | 0.0 | 6.5 |
| MOVE SPELL NOT WORTH | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.4 | -12.0 | 2.2 | 46.1 | 0.1 | -2.1 | 0.0 | 6.5 |
| MOVE SPELL SPOT | 0.2 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| MOVES UNITS SPELL | 0.1 | +3.6 | 0.0 | 0.0 | 0.1 | +0.3 | 0.0 | 0.0 |
| NEEDED THERE | 0.1 | +5.3 | 0.0 | 0.0 | - | - | - | - |
| NO RALLY LEFT | 0.1 | +1.9 | 0.0 | 0.0 | 0.0 | +0.8 | 0.0 | 4.0 |
| NOT NEEDED | 0.3 | -16.1 | 22.9 | 10.7 | 0.2 | -8.1 | 21.7 | 1.8 |
| NOT TURNED | 10.4 | +119.0 | 0.0 | 197.0 | 10.0 | +50.4 | 0.0 | 176.1 |
| NOT WORTH A CAST | 0.5 | -15.0 | 0.0 | 50.6 | 0.6 | -0.7 | 0.0 | 0.0 |
| OPENS A LANE | 0.1 | +0.4 | 3.5 | 0.0 | 0.1 | +1.4 | 0.0 | 4.6 |
| OPENS UP | 0.4 | +34.8 | 24.8 | 0.0 | 0.2 | +18.4 | 15.9 | 5.4 |
| OVERRUNS AWAY | 0.4 | +9.1 | 50.0 | 13.0 | 0.5 | +19.9 | 42.8 | 10.3 |
| PATHS CROSS | 2.1 | +133.9 | 0.0 | 16.0 | 2.6 | +158.7 | 0.0 | 30.1 |
| PLAN LEADS | 1.3 | +112.2 | 44.4 | 17.6 | 0.9 | +68.5 | 14.4 | 16.5 |
| PLAN RESULT | 37.4 | +1606.0 | 1337.7 | 735.0 | 37.0 | +996.4 | 915.4 | 1086.8 |
| PURSUES BIG PREY | 0.1 | -14.2 | 0.0 | 10.9 | - | - | - | - |
| PURSUES ON | 0.0 | +2.2 | 0.0 | 0.0 | - | - | - | - |
| RAIDS THE BAGGAGE | - | - | - | - | 0.0 | +6.6 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE NEXT TURN | 0.2 | +22.1 | 0.0 | 0.0 | - | - | - | - |
| REDIRECT WEIGHED | 0.1 | +7.1 | 2.9 | 0.0 | 0.3 | +17.8 | 27.9 | 0.0 |
| RESTRAINS TO SHOOT | 0.1 | +6.4 | 0.0 | 6.3 | - | - | - | - |
| RISK BY ARC | 2.6 | +105.7 | 256.0 | 71.0 | 2.6 | +38.2 | 189.9 | 100.8 |
| SAFE SURE CHARGE | - | - | - | - | 0.0 | -0.0 | 0.0 | 0.0 |
| SAFER THAN THE JOB | 1.2 | +58.1 | 0.0 | 13.9 | 0.9 | +54.1 | 0.0 | 32.2 |
| SCOUT SPOT | 0.4 | +0.3 | 0.0 | 0.0 | 0.3 | +0.8 | 0.0 | 0.0 |
| SCOUT WAITS | 0.4 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| SEARCH SPOT | 1.1 | +50.9 | 0.0 | 25.6 | 1.1 | +46.5 | 0.0 | 40.8 |
| SECOND HUNTER | 0.1 | -0.7 | 9.2 | 0.0 | - | - | - | - |
| SELF MOVE SPELL | 0.4 | +56.3 | 0.0 | 18.1 | 0.3 | +53.7 | 0.0 | 21.9 |
| SET UP TOGETHER | 1.0 | +89.0 | 35.5 | 4.5 | 1.5 | +91.6 | 37.6 | 19.4 |
| SET-UP MISSED | 0.0 | +9.1 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | 0.3 | +0.6 | 0.0 | 0.0 | 0.1 | +0.1 | 0.0 | 0.0 |
| SHORT GUN FORWARD | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SHOT REPLANNED | 0.7 | +0.0 | 142.6 | 3.5 | 0.1 | +0.0 | 13.8 | 0.0 |
| SHOTS IN THE MOVE | 12.2 | +451.3 | 0.0 | 219.3 | 8.6 | +242.1 | 0.0 | 94.7 |
| SPELL SETS UP CHARGE | 0.1 | +30.0 | 0.0 | 0.0 | 0.0 | +4.8 | 0.0 | 0.0 |
| SPELL WORTH | 1.4 | +24.9 | 7.2 | 7.2 | 2.2 | +33.7 | 143.0 | 123.7 |
| STANDS TO CAST | 0.1 | +5.2 | 2.0 | 0.0 | - | - | - | - |
| STOPS | 0.1 | +7.9 | 17.2 | 0.0 | - | - | - | - |
| STUCK PIVOT | 0.2 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| SURE CHARGE BEATS ADVANCE | 0.2 | -9.5 | 12.9 | 5.4 | 0.0 | -0.9 | 0.0 | 0.0 |
| THROUGH LINE OF FIRE | 0.6 | +10.9 | 0.0 | 0.0 | 0.2 | +12.1 | 0.0 | 0.0 |
| TURN WORTH | 0.6 | -41.2 | 67.8 | 12.6 | 0.7 | -49.1 | 36.4 | 20.0 |
| TWO OR MORE ARRIVE | 0.5 | +10.4 | 15.6 | 4.5 | 0.8 | +13.6 | 0.0 | 8.4 |
| WEARS DOWN | 1.0 | +49.8 | 161.6 | 25.5 | 1.0 | +34.4 | 111.8 | 92.7 |
| WHO HITS BACK | 0.4 | +29.1 | 0.0 | 0.0 | 0.5 | +62.4 | 0.0 | 7.2 |
| WHOLE FIGHT | 0.3 | +19.1 | 57.6 | 0.0 | 0.3 | +13.8 | 29.0 | 0.0 |
| WHOLE FIGHT GAIN | 0.3 | +30.6 | 39.7 | 2.5 | 0.4 | +56.0 | 49.4 | 11.4 |

### Rule changes: bg-off-789c37f-p3

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| KILLS COUNT NEXT TURN | 687 | 679 | 185 | 5.14 | +6370 | +34.4 |
| BEST PREY | 309 | 300 | 133 | 3.69 | +6988 | +52.5 |
| FOLLOW UP WEIGHED | 82 | 82 | 82 | 2.28 | +11659 | +142.2 |
| ARTILLERY RE-ROLL WEIGHED | 60 | 60 | 60 | 1.67 | +0 | +0.0 |
| CANNON SIGHT KEPT | 56 | 56 | 56 | 1.56 | +0 | +0.0 |
| MARCH ODDS | 71 | 55 | 53 | 1.47 | +1161 | +21.9 |
| CANNON PLANNED TARGET | 232 | 232 | 50 | 1.39 | -44 | -0.9 |
| CHARGE NOW WEIGHED | 48 | 48 | 48 | 1.33 | +4251 | +88.6 |
| LONE WIZARD HOLDS BACK | 125 | 125 | 44 | 1.22 | -2391 | -54.3 |
| SET UP TOGETHER | 91 | 90 | 43 | 1.19 | +2430 | +56.5 |
| HOLDS AMBUSHERS | 39 | 39 | 39 | 1.08 | +0 | +0.0 |
| KEEPS ITS TARGET | 146 | 143 | 39 | 1.08 | +618 | +15.9 |
| RISK BY ARC | 187 | 170 | 39 | 1.08 | +1413 | +36.2 |
| PLAN LEADS | 78 | 78 | 37 | 1.03 | +2540 | +68.6 |
| KILLS COUNT | 139 | 129 | 33 | 0.92 | +1304 | +39.5 |
| CAST JOB | 52 | 52 | 32 | 0.89 | +679 | +21.2 |
| LONE WIZARD KEPT IN | 32 | 32 | 32 | 0.89 | +2140 | +66.9 |
| WHO HITS BACK | 32 | 32 | 32 | 0.89 | -2572 | -80.4 |
| ADVANCE LANE KEPT | 31 | 31 | 31 | 0.86 | +0 | +0.0 |
| SHOT REPLANNED | 31 | 31 | 31 | 0.86 | +0 | +0.0 |
| CHARIOT NO STATIC JOB | 47 | 47 | 29 | 0.81 | -3366 | -116.1 |
| MAKE SURE TOGETHER | 62 | 61 | 27 | 0.75 | +1027 | +38.0 |
| SCOUT WAITS | 25 | 25 | 25 | 0.69 | +0 | +0.0 |
| SHOOTERS IN TWO RANKS | 16 | 16 | 16 | 0.44 | +27 | +1.7 |
| STUCK PIVOT | 16 | 16 | 16 | 0.44 | +0 | +0.0 |
| REDIRECT WEIGHED | 15 | 15 | 15 | 0.42 | +999 | +66.6 |
| CASTING BLOCK | 18 | 18 | 14 | 0.39 | +368 | +26.3 |
| FRIENDS SHOTS CHECKED | 11 | 11 | 11 | 0.31 | +911 | +82.8 |
| WHOLE FIGHT GAIN | 26 | 23 | 11 | 0.31 | +1321 | +120.1 |
| WEARS DOWN | 74 | 69 | 10 | 0.28 | +326 | +32.6 |
| CASTER AWAY FROM SCREEN | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| CASTS FROM BEHIND | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| HUNT ADVANCE | 13 | 13 | 9 | 0.25 | +527 | +58.6 |
| OPENS UP | 21 | 15 | 9 | 0.25 | +503 | +55.9 |
| WHOLE FIGHT | 23 | 20 | 9 | 0.25 | +491 | +54.6 |
| RAIDS THE BAGGAGE NEXT TURN | 8 | 8 | 8 | 0.22 | +314 | +39.3 |
| MOVES UNITS SPELL | 7 | 7 | 7 | 0.19 | +141 | +20.1 |
| SURE CHARGE BEATS ADVANCE | 7 | 7 | 7 | 0.19 | -374 | -53.4 |
| TWO OR MORE ARRIVE | 49 | 49 | 7 | 0.19 | +129 | +18.4 |
| CHAFF PASSED | 5 | 5 | 5 | 0.14 | -3 | -0.6 |
| SHORT GUN FORWARD | 5 | 5 | 5 | 0.14 | +0 | +0.0 |
| BEST PRIZE | 4 | 4 | 4 | 0.11 | -344 | -85.9 |
| HORN WORTH | 4 | 4 | 4 | 0.11 | +55 | +13.7 |
| JOINT CHARGE PLAN | 18 | 18 | 4 | 0.11 | +483 | +120.7 |
| OVERRUNS AWAY | 32 | 29 | 4 | 0.11 | +250 | +62.6 |
| RESTRAINS TO SHOOT | 4 | 4 | 4 | 0.11 | +231 | +57.7 |
| FOCUS FIRE | 3 | 3 | 3 | 0.08 | +126 | +41.9 |
| MISSILES NEXT TURN | 365 | 172 | 3 | 0.08 | +52 | +17.4 |
| MODEL FACING | 3 | 3 | 3 | 0.08 | +322 | +107.3 |
| NO RALLY LEFT | 3 | 3 | 3 | 0.08 | +31 | +10.2 |
| BLOCKED CHARGE SKIPPED | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| EDGE GIVE GROUND | 14 | 14 | 2 | 0.06 | +157 | +78.7 |
| FIRE AND FLEE | 2 | 2 | 2 | 0.06 | +91 | +45.6 |
| PURSUES BIG PREY | 2 | 2 | 2 | 0.06 | -510 | -254.8 |
| STOPS | 4 | 4 | 2 | 0.06 | +160 | +80.0 |
| BACKUP TARGETS | 49 | 20 | 1 | 0.03 | +1 | +0.8 |
| BOMBING RUN | 1 | 1 | 1 | 0.03 | +57 | +56.8 |
| BOUND ASSAILMENT | 1 | 1 | 1 | 0.03 | +0 | +0.1 |
| ELIXIR WORTH | 1 | 1 | 1 | 0.03 | +22 | +22.0 |
| KEEPS ITS PREY | 19 | 19 | 1 | 0.03 | +1 | +1.2 |
| KEEPS SCOUTS OR AMBUSH | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| NEEDED THERE | 2 | 1 | 1 | 0.03 | +0 | +0.0 |
| OPENS A LANE | 7 | 5 | 1 | 0.03 | +1 | +0.7 |
| PURSUES ON | 1 | 1 | 1 | 0.03 | +79 | +78.7 |
| RAIDS THE BAGGAGE | 1 | 1 | 1 | 0.03 | +144 | +143.9 |
| SAFE SURE CHARGE | 1 | 1 | 1 | 0.03 | -35 | -34.9 |
| STANDS TO CAST | 4 | 1 | 1 | 0.03 | +1 | +0.6 |
| ALREADY CARRIED | 1 | not checked | - | - | - | - |
| ARRIVAL HUNT | 2 | 2 | 0 | 0.00 | - | - |
| BLOCKED WHEEL | 27 | not checked | - | - | - | - |
| CANNON PLAN MISSED | 39 | 39 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 31 | trace | - | - | - | - |
| CATCH FLIERS | 1 | not checked | - | - | - | - |
| CATCH ODDS | 1 | not checked | - | - | - | - |
| CHAMPION TAKES THE CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| CHEAP HELPER | 8 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 32 | not checked | - | - | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FACES THE THREAT | 87 | not checked | - | - | - | - |
| FIGHT LIFT | 3 | not checked | - | - | - | - |
| GIVES UP | 114 | 103 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 44 | 41 | 0 | 0.00 | - | - |
| GROUND FLIERS | 3 | not checked | - | - | - | - |
| HELPER ALREADY ASKED | 3 | not checked | - | - | - | - |
| HELPER UNSEEN | 13 | 11 | 0 | 0.00 | - | - |
| HUNT DROPPED | 2 | trace | - | - | - | - |
| HUNT KEPT | 9 | trace | - | - | - | - |
| HUNT RESULT | 8 | trace | - | - | - | - |
| HUNT THE GUNS | 11 | trace | - | - | - | - |
| LONE CHARACTER SAFE SPOT | 32 | not checked | - | - | - | - |
| MANOEUVRE | 16 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 22 | trace | - | - | - | - |
| MISSILES IN THE MOVE | 231 | not checked | - | - | - | - |
| MOVE AND CAST | 14 | not checked | - | - | - | - |
| MOVE SPELL IN RANGE | 11 | 7 | 0 | 0.00 | - | - |
| MOVE SPELL NOT WORTH | 1 | not checked | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 18 | trace | - | - | - | - |
| MOVE SPELL SPOT | 13 | not checked | - | - | - | - |
| NOT NEEDED | 20 | 19 | 0 | 0.00 | - | - |
| NOT TURNED | 735 | 735 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 39 | not checked | - | - | - | - |
| PATHS CROSS | 168 | not checked | - | - | - | - |
| PLAN RESULT | 2678 | trace | - | - | - | - |
| SAFER THAN THE JOB | 76 | not checked | - | - | - | - |
| SCOUT SPOT | 24 | 24 | 0 | 0.00 | - | - |
| SEARCH SPOT | 79 | not checked | - | - | - | - |
| SECOND HUNTER | 2 | 2 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 26 | not checked | - | - | - | - |
| SET-UP MISSED | 1 | trace | - | - | - | - |
| SHOTS IN THE MOVE | 749 | not checked | - | - | - | - |
| SPELL SETS UP CHARGE | 5 | not checked | - | - | - | - |
| SPELL WORTH | 132 | not checked | - | - | - | - |
| THROUGH LINE OF FIRE | 26 | not checked | - | - | - | - |
| TURN WORTH | 46 | 41 | 0 | 0.00 | - | - |

### Plans: bg-off-789c37f-p3

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 12.3 | 19% | 533 | 425 | 80% |
| Mine | charge | 3.3 | 67% | 340 | 325 | 95% |
| Mine | close in | 5.1 | 26% | 369 | 186 | 51% |
| Mine | hold | 4.1 | 43% | 246 | 0 | 0% |
| Mine | join | 0.4 | 100% | 13 | 0 | 0% |
| Mine | shoot | 8.5 | 63% | 213 | 670 | 315% |
| Mine | support | 3.8 | 91% | 222 | 0 | 0% |
| Opponent | advance | 12.4 | 20% | 629 | 334 | 53% |
| Opponent | charge | 3.8 | 50% | 444 | 306 | 69% |
| Opponent | close in | 6.2 | 15% | 418 | 108 | 26% |
| Opponent | hold | 3.7 | 38% | 381 | 0 | 0% |
| Opponent | join | 0.8 | 97% | 32 | 0 | 0% |
| Opponent | shoot | 3.8 | 61% | 96 | 250 | 259% |
| Opponent | support | 6.2 | 91% | 254 | 0 | 0% |

### Packages: hunt the guns, bg-off-789c37f-p3

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.2 | 8 | 2 | 33% | 50% | 0% | 3.3 | 408 | 148 | 17% | 29 |
| Opponent | 0.1 | 3 | 1 | 50% | 50% | 0% | 3.0 | 417 | 117 | 50% | 83 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 1.5 | 6 | 2 | 25% | 25% | 0% | 4.0 | 392 | 70 | 0% | 34 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 78 |
| Dwarfen Mountain Holds | 0.3 | 1 | 0 | 0% | 100% | 0% | 2.0 | 341 | 320 | 100% | 53 |
| Empire of Man | 0.2 | 1 | 0 | 100% | 100% | 0% | 4.0 | 542 | 292 | 0% | 47 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 41 |
| High Elf Realms | 0.1 | 1 | 0 | 0% | 0% | 0% | - | 581 | 0 | 0% | 16 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 157 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 318 |
| Tomb Kings of Khemri | 0.2 | 1 | 1 | - | - | - | - | - | - | - | 0 |
| Vampire Counts | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 19 |
| Warriors of Chaos | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 119 |
| Wood Elf Realms | 0.2 | 1 | 0 | 100% | 100% | 0% | 3.0 | 253 | 234 | 100% | 24 |

### Deployment: positions vs output by unit type: bg-off-789c37f-p3

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Mine | Chaff | 40 | 64 (40) | 24 | 40 | 54 | 42% | 2.8 | 83 (20) | 27 (8) | 56 (12) | 82 (32) | 0 (8) |
| Mine | Character | 120 | 57 (120) | 57 | 0 | 16 | 22% | 2.4 | 78 (43) | 53 (57) | 15 (6) | 74 (57) | 46 (49) |
| Mine | Clean-up | 15 | 80 (15) | 36 | 44 | 31 | 47% | 2.6 | 41 (7) | 114 (6) | 109 (2) | 76 (8) | 85 (7) |
| Mine | Fast Hammer | 43 | 47 (43) | 32 | 15 | 41 | 30% | 2.9 | 49 (24) | 56 (13) | 0 (6) | 53 (31) | 27 (12) |
| Mine | Fragile | 3 | 10 (3) | 10 | 0 | 100 | 33% | 4.0 | 10 (3) | - | - | 0 (1) | 15 (2) |
| Mine | Hammer | 50 | 47 (50) | 33 | 14 | 38 | 24% | 2.7 | 0 (13) | 60 (32) | 75 (5) | 44 (34) | 54 (16) |
| Mine | Holder | 25 | 56 (25) | 1 | 55 | 16 | 52% | 2.5 | 26 (6) | 76 (12) | 41 (6) | 69 (11) | 48 (13) |
| Mine | Shooter | 38 | 67 (38) | 34 | 33 | 40 | 3% | 1.9 | 101 (10) | 65 (25) | 0 (2) | 97 (23) | 30 (14) |
| Mine | Support | 4 | 0 (4) | 0 | 0 | 39 | 25% | 4.0 | - | 0 (1) | 0 (3) | 0 (1) | 0 (3) |
| Mine | War machine | 52 | 46 (52) | 46 | 0 | 39 | 2% | 1.1 | 25 (14) | 48 (34) | 111 (4) | 19 (14) | 56 (38) |
| Mine | Wizard | 15 | 28 (15) | 28 | 0 | 57 | 20% | 1.9 | 0 (4) | 32 (7) | 174 (1) | 64 (5) | 31 (7) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Chaff | 73 | 44 (73) | 5 | 39 | 55 | 49% | 2.6 | 45 (31) | 101 (13) | 11 (29) | 50 (52) | 30 (21) |
| Opponent | Character | 101 | 42 (101) | 42 | 0 | 42 | 21% | 2.5 | 50 (37) | 39 (49) | 39 (7) | 53 (50) | 35 (43) |
| Opponent | Clean-up | 9 | 30 (9) | 3 | 28 | 46 | 44% | 2.8 | 9 (3) | 20 (4) | 111 (2) | 42 (5) | 20 (4) |
| Opponent | Fast Hammer | 60 | 41 (60) | 17 | 24 | 50 | 23% | 3.0 | 26 (31) | 62 (17) | 51 (12) | 47 (32) | 34 (28) |
| Opponent | Fragile | 3 | 54 (3) | 54 | 0 | 0 | 33% | 3.5 | - | 81 (2) | 0 (1) | 81 (2) | 0 (1) |
| Opponent | Hammer | 47 | 26 (47) | 22 | 4 | 45 | 26% | 3.2 | 22 (15) | 29 (28) | 0 (4) | 28 (25) | 23 (22) |
| Opponent | Holder | 40 | 65 (40) | 4 | 61 | 45 | 38% | 3.0 | 61 (11) | 80 (19) | 34 (10) | 73 (30) | 41 (10) |
| Opponent | Shooter | 28 | 28 (28) | 23 | 5 | 44 | 7% | 1.2 | 14 (7) | 28 (20) | 134 (1) | 45 (17) | 6 (11) |
| Opponent | Support | 4 | 0 (4) | 0 | 0 | 50 | 75% | 6.0 | 0 (2) | 0 (1) | 0 (1) | 0 (2) | 0 (2) |
| Opponent | War machine | 17 | 51 (17) | 51 | 0 | 49 | 12% | 1.4 | 102 (3) | 27 (10) | 75 (4) | 0 (3) | 61 (14) |
| Opponent | Wizard | 33 | 16 (33) | 16 | 0 | 34 | 15% | 1.9 | 7 (14) | 49 (6) | 0 (4) | 8 (13) | 24 (11) |

### Charged fights: bg-off-789c37f-p3

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 72 | 196 | 1.8 | 1.1 | 112 | 0 | +112 | 2 of 7 | 4 of 7 | +165 | +103 |
| Mine | Chaos Dwarfs | 4 | 170 | 191 | 2.5 | 1.0 | 76 | 40 | +36 | 5 of 10 | 7 of 10 | - | +36 |
| Mine | Dwarfen Mountain Holds | 3 | 685 | 0 | 1.3 | 1.0 | 0 | 62 | -62 | 1 of 4 | 2 of 4 | - | -62 |
| Mine | Empire of Man | 5 | 393 | 81 | 1.8 | 1.0 | 45 | 91 | -46 | 3 of 9 | 5 of 9 | - | -46 |
| Mine | Grand Cathay | 5 | 386 | 308 | 3.6 | 1.2 | 86 | 19 | +67 | 3 of 18 | 18 of 18 | +165 | +39 |
| Mine | High Elf Realms | 4 | 179 | 429 | 4.5 | 1.1 | 95 | 0 | +95 | 6 of 18 | 14 of 18 | +125 | +94 |
| Mine | Kingdom of Bretonnia | 1 | 0 | 943 | 7.0 | 1.1 | 135 | 0 | +135 | 0 of 7 | 5 of 7 | +144 | +133 |
| Mine | Lizardmen | 1 | 116 | 690 | 6.0 | 1.0 | 115 | 68 | +47 | 1 of 6 | 4 of 6 | - | +47 |
| Mine | Ogre Kingdoms | 1 | 0 | 1029 | 3.0 | 1.0 | 343 | 11 | +332 | 1 of 3 | 2 of 3 | - | +332 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 737 | 7.0 | 1.0 | 105 | 0 | +105 | 2 of 7 | 5 of 7 | - | +105 |
| Mine | Skaven | 1 | 19 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Mine | Tomb Kings of Khemri | 2 | 0 | 950 | 6.5 | 1.2 | 146 | 9 | +137 | 2 of 13 | 10 of 13 | +182 | +128 |
| Mine | Vampire Counts | 2 | 72 | 886 | 5.5 | 1.3 | 161 | 0 | +161 | 2 of 11 | 6 of 11 | +170 | +158 |
| Mine | Warriors of Chaos | 2 | 0 | 672 | 4.0 | 1.5 | 168 | 14 | +154 | 1 of 8 | 5 of 8 | +304 | +104 |
| **Mine** | all armies | 36 | 220 | 378 | 3.4 | 1.1 | 113 | 21 | +92 | 29 of 121 | 87 of 121 | +184 | +80 |
| Opponent | Empire of Man | 1 | 380 | 189 | 2.0 | 1.0 | 94 | 120 | -26 | 1 of 2 | 1 of 2 | - | -26 |
| Opponent | Grand Cathay | 3 | 309 | 393 | 2.7 | 1.1 | 147 | 0 | +147 | 1 of 8 | 6 of 8 | +952 | +32 |
| Opponent | High Elf Realms | 3 | 113 | 169 | 3.0 | 1.3 | 56 | 86 | -30 | 6 of 9 | 5 of 9 | -76 | -17 |
| Opponent | Kingdom of Bretonnia | 2 | 162 | 253 | 2.5 | 1.2 | 101 | 0 | +101 | 1 of 5 | 3 of 5 | +165 | +85 |
| Opponent | Orc & Goblin Tribes | 1 | 0 | 291 | 6.0 | 1.0 | 48 | 18 | +30 | 2 of 6 | 3 of 6 | - | +30 |
| Opponent | Skaven | 1 | 105 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Tomb Kings of Khemri | 4 | 99 | 252 | 3.2 | 1.1 | 78 | 54 | +23 | 5 of 13 | 5 of 13 | +177 | +11 |
| Opponent | Vampire Counts | 6 | 0 | 504 | 3.5 | 1.4 | 144 | 74 | +70 | 11 of 21 | 11 of 21 | +51 | +81 |
| Opponent | Warriors of Chaos | 9 | 0 | 296 | 2.8 | 1.0 | 106 | 58 | +48 | 10 of 25 | 13 of 25 | - | +48 |
| Opponent | Wood Elf Realms | 6 | 94 | 192 | 2.2 | 1.1 | 89 | 106 | -17 | 7 of 13 | 5 of 13 | +251 | -39 |
| **Opponent** | all armies | 36 | 84 | 292 | 2.8 | 1.1 | 103 | 61 | +42 | 44 of 102 | 52 of 102 | +129 | +28 |

### Effective charges: bg-off-789c37f-p3

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 7 | 1 (net +0) | 1 (net +0) | 0 | 2 (net +165) | 0 | 2 (net +226) | 1 | 0% (0 of 6) |
| Mine | Chaos Dwarfs | 10 | 1 (net -91) | 0 | 2 (net +0) | 2 (net +85) | 0 | 3 (net +44) | 2 | 25% (2 of 8) |
| Mine | Dwarfen Mountain Holds | 4 | 1 (net +0) | 0 | 1 (net -186) | 0 | 0 | 2 (net -30) | 0 | 25% (1 of 4) |
| Mine | Empire of Man | 9 | 2 (net -132) | 0 | 3 (net -47) | 1 (net +104) | 1 (net +72) | 2 (net -92) | 0 | 33% (3 of 9) |
| Mine | Grand Cathay | 18 | 1 (net -340) | 0 | 2 (net +157) | 6 (net +122) | 2 (net +28) | 6 (net +44) | 1 | 12% (2 of 17) |
| Mine | High Elf Realms | 18 | 2 (net +110) | 1 (net +0) | 0 | 4 (net +86) | 3 (net +84) | 5 (net +159) | 3 | 0% (0 of 15) |
| Mine | Kingdom of Bretonnia | 7 | 2 (net +348) | 0 | 0 | 1 (net +0) | 1 (net +0) | 2 (net +72) | 1 | 0% (0 of 6) |
| Mine | Lizardmen | 6 | 0 | 0 | 1 (net -409) | 1 (net +144) | 2 (net +143) | 1 (net +144) | 1 | 20% (1 of 5) |
| Mine | Ogre Kingdoms | 3 | 0 | 1 (net +859) | 0 | 0 | 0 | 1 (net +170) | 1 | 0% (0 of 2) |
| Mine | Orc & Goblin Tribes | 7 | 0 | 0 | 0 | 0 | 0 | 2 (net +322) | 5 | 0% (0 of 2) |
| Mine | Tomb Kings of Khemri | 13 | 1 (net +233) | 0 | 1 (net -122) | 3 (net +245) | 4 (net +121) | 4 (net +112) | 0 | 8% (1 of 13) |
| Mine | Vampire Counts | 11 | 1 (net +412) | 0 | 2 (net +99) | 3 (net +286) | 1 (net +98) | 4 (net +52) | 0 | 18% (2 of 11) |
| Mine | Warriors of Chaos | 8 | 0 | 0 | 3 (net +199) | 1 (net +334) | 1 (net -81) | 3 (net +127) | 0 | 38% (3 of 8) |
| Opponent | Empire of Man | 2 | 0 | 0 | 0 | 0 | 0 | 2 (net -26) | 0 | 0% (0 of 2) |
| Opponent | Grand Cathay | 8 | 0 | 0 | 1 (net +85) | 1 (net +952) | 4 (net +36) | 2 (net +0) | 0 | 12% (1 of 8) |
| Opponent | High Elf Realms | 9 | 2 (net +135) | 0 | 1 (net -347) | 2 (net -76) | 2 (net +118) | 2 (net -140) | 0 | 11% (1 of 9) |
| Opponent | Kingdom of Bretonnia | 5 | 1 (net +0) | 1 (net +95) | 0 | 2 (net +169) | 1 (net +73) | 0 | 0 | 0% (0 of 5) |
| Opponent | Orc & Goblin Tribes | 6 | 0 | 0 | 0 | 1 (net +0) | 1 (net +115) | 1 (net +0) | 3 | 0% (0 of 3) |
| Opponent | Tomb Kings of Khemri | 13 | 0 | 0 | 1 (net +217) | 1 (net -511) | 3 (net +0) | 6 (net +93) | 2 | 9% (1 of 11) |
| Opponent | Vampire Counts | 21 | 1 (net -95) | 1 (net -205) | 2 (net -190) | 5 (net +157) | 4 (net +69) | 6 (net +149) | 2 | 11% (2 of 19) |
| Opponent | Warriors of Chaos | 25 | 2 (net +379) | 1 (net -489) | 0 | 3 (net +81) | 1 (net +45) | 9 (net +124) | 9 | 0% (0 of 16) |
| Opponent | Wood Elf Realms | 13 | 3 (net +91) | 0 | 0 | 2 (net +58) | 0 | 2 (net +68) | 6 | 0% (0 of 7) |

### Charged fights, damage counted: bg-off-789c37f-p3

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 12 | 278 | 253 | +72 | 152 | 120 | +32 | +11.6 |
| Mine | 50-54% | 3 | 189 | 249 | +286 | 327 | 61 | +266 | +140.9 |
| Mine | Effective (55-75%) | 15 | 234 | 224 | +17 | 113 | 87 | +27 | +11.4 |
| Mine | 76-89% | 24 | 294 | 192 | +156 | 162 | 13 | +149 | +50.6 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 37 | 260 | 164 | +96 | 126 | 31 | +95 | +36.7 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 15 | 466 | 91 | +78 | 99 | 20 | +80 | +17.1 |
| Mine | No odds | 15 | 242 | 171 | +48 | 99 | 26 | +74 | +30.4 |
| Mine | All fights | 121 | 287 | 180 | +92 | 133 | 42 | +91 | +31.6 |
| Opponent | Long shot (under 50%) | 9 | 275 | 281 | +134 | 166 | 33 | +132 | +48.2 |
| Opponent | 50-54% | 3 | 435 | 363 | -200 | 180 | 343 | -163 | -37.4 |
| Opponent | Effective (55-75%) | 5 | 575 | 240 | -85 | 170 | 255 | -85 | -14.8 |
| Opponent | 76-89% | 17 | 342 | 208 | +104 | 148 | 52 | +96 | +28.0 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 30 | 284 | 187 | +79 | 131 | 41 | +89 | +31.4 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 16 | 346 | 80 | +56 | 65 | 6 | +58 | +16.9 |
| Opponent | No odds | 22 | 170 | 235 | -42 | 78 | 109 | -30 | -17.8 |
| Opponent | All fights | 102 | 297 | 200 | +42 | 118 | 71 | +48 | +16.0 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| bg-off-789c37f-p3 | move | 467 | 94 (20%) | 73 (16%) | 42 (9%) | 331 (71%) |
| bg-off-789c37f-p3 | objective | 411 | 50 (12%) | 38 (9%) | 59 (14%) | 302 (73%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0110, L0126, L2433, L2630 |
| Charmed Shield | Opponent | L0126, L0226, L0327, L0725, L1327, L2327 |
| Clockwork Compass | Mine | L1216, L1232 |
| Elixir of Power | Mine | L1122, L1932 |
| Elixir of Power | Opponent | L0311, L1519 |
| Fistful of Laurels | Mine | L1831 |
| Horn of the Wild Hunt | Opponent | L0533, L1633, L2033, L2433, L3133 |
| Invocation of Nehek | Mine | L2433 |
| Invocation of Nehek | Opponent | L0327, L0725, L1327, L2327 |
| Opal Amulet | Mine | L1422 |
| Periapt of Soul Exchange | Mine | L2033 |
| Periapt of Soul Exchange | Opponent | L0620 |
| Ring of Doom | Mine | L0210, L0226, L1122, L1216, L1232, L1519, L1535, L3133 |
| Ring of Doom | Opponent | L0311, L0533, L0815, L0831, L1633, L1731, L1831, L2033, L2433, L3133 |
| Ring of Jet | Mine | L1013, L1030, L1122, L1216, L1232 |
| Ring of Jet | Opponent | L0110, L0210, L0311 |
| Standard of the Fell Warrior | Mine | L1327 |
| Standard of the Fell Warrior | Opponent | L0413, L1013 |
| Twice-Blessed Armour | Mine | L0709, L0725, L1013, L1030 |
| Twice-Blessed Armour | Opponent | L0110, L0210 |
| Witch Hunter's Ward | Mine | L0709, L0725, L0815, L0831 |

# Doctrine scorecard: bg-on-789c37f-p2

### Scorecard: bg-on-789c37f-p2

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0106 | 4 | 1 | Mine | no | 2 | 3 | 2 | 3 | 0 | 0 | 0 | 322 |
| L0106 | 4 | 1 | Opponent | no | 0 | 2 | 1 | 1 | 0 | 0 | 0 | 798 |
| L0122 | 2 | 1 | Mine | - | - | - | 0 | 2 | 1 | 0 | 0 | 639 |
| L0122 | 2 | 1 | Opponent | - | - | 2 | 3 | 0 | 0 | 0 | 0 | 0 |
| L0206 | 2 | 1 | Mine | - | - | 4 | 1 | 7 | 1 | 0 | 0 | 0 |
| L0206 | 2 | 1 | Opponent | - | - | 1 | 1 | 1 | 0 | 0 | 0 | 615 |
| L0222 | 6 | 1 | Mine | no | 2 | 4 | 4 | 3 | 2 | 0 | 0 | 170 |
| L0222 | 6 | 1 | Opponent | no | 1 | 1 | 5 | 0 | 0 | 0 | 0 | 0 |
| L0307 | 1 | 1 | Mine | yes | 0 | 3 | 4 | 2 | 0 | 0 | 0 | 760 |
| L0307 | 1 | 1 | Opponent | yes | 3 | 2 | 1 | 1 | 0 | 0 | 0 | 420 |
| L0323 | 5 | 1 | Mine | yes | - | 4 | 2 | 2 | 0 | 0 | 0 | 675 |
| L0323 | 5 | 1 | Opponent | yes | - | 2 | 5 | 3 | 1 | 0 | 0 | 140 |
| L0409 | 1 | 1 | Mine | no | 3 | 2 | 5 | 0 | 0 | 0 | 0 | 0 |
| L0409 | 1 | 1 | Opponent | no | 9 | - | 0 | 1 | 0 | 0 | 0 | 873 |
| L0425 | 5 | 1 | Mine | yes | - | 2 | 6 | 2 | 0 | 0 | 0 | 0 |
| L0425 | 5 | 1 | Opponent | no | - | 2 | 2 | 3 | 0 | 0 | 0 | 0 |
| L0512 | 2 | 1 | Mine | - | - | - | 0 | 2 | 0 | 0 | 0 | 666 |
| L0512 | 2 | 1 | Opponent | - | - | 2 | 5 | 1 | 2 | 0 | 0 | 330 |
| L0528 | 6 | 1 | Mine | no | 0 | 6 | 1 | 1 | 0 | 0 | 0 | 1343 |
| L0528 | 6 | 1 | Opponent | yes | 5 | 3 | 1 | 2 | 1 | 0 | 0 | 0 |
| L0616 | 4 | 1 | Mine | no | 0 | 2 | 2 | 0 | 1 | 0 | 0 | 615 |
| L0616 | 4 | 1 | Opponent | no | 0 | 2 | 0 | 1 | 1 | 0 | 0 | 200 |
| L0632 | 2 | 1 | Mine | - | - | - | 1 | 0 | 0 | 0 | 0 | 838 |
| L0632 | 2 | 1 | Opponent | - | - | 2 | 5 | 3 | 1 | 0 | 0 | 0 |
| L0721 | 1 | 1 | Mine | yes | 1 | 3 | 5 | 0 | 0 | 0 | 0 | 420 |
| L0721 | 1 | 1 | Opponent | no | 4 | 6 | 1 | 4 | 1 | 0 | 0 | 500 |
| L0810 | 6 | 1 | Mine | no | 0 | 4 | 1 | 2 | 0 | 0 | 0 | 515 |
| L0810 | 6 | 1 | Opponent | no | 20 | 5 | 0 | 1 | 0 | 0 | 0 | 330 |
| L0827 | 5 | 1 | Mine | no | - | - | 0 | 1 | 0 | 0 | 0 | 922 |
| L0827 | 5 | 1 | Opponent | yes | - | 2 | 3 | 5 | 0 | 0 | 0 | 0 |
| L0918 | 6 | 1 | Mine | no | 0 | - | 0 | 0 | 0 | 0 | 0 | 420 |
| L0918 | 6 | 1 | Opponent | no | 3 | 2 | 2 | 2 | 1 | 0 | 0 | 234 |
| L0934 | 4 | 1 | Mine | no | 0 | 1 | 1 | 0 | 0 | 0 | 0 | 1105 |
| L0934 | 4 | 1 | Opponent | no | 0 | 2 | 4 | 3 | 0 | 0 | 0 | 56 |
| L1026 | 6 | 1 | Mine | no | 0 | 2 | 4 | 0 | 1 | 0 | 0 | 330 |
| L1026 | 6 | 1 | Opponent | no | 2 | 4 | 3 | 2 | 1 | 0 | 0 | 0 |
| L1118 | 2 | 1 | Mine | - | - | 2 | 4 | 0 | 0 | 0 | 0 | 330 |
| L1118 | 2 | 1 | Opponent | - | - | - | 1 | 3 | 1 | 0 | 0 | 0 |
| L1135 | 1 | 1 | Mine | yes | 0 | 2 | 4 | 0 | 0 | 0 | 0 | 501 |
| L1135 | 1 | 1 | Opponent | yes | 0 | 2 | 2 | 0 | 1 | 0 | 0 | 0 |
| L1228 | 4 | 1 | Mine | no | 3 | 2 | 0 | 1 | 0 | 0 | 0 | 524 |
| L1228 | 4 | 1 | Opponent | no | 0 | 3 | 2 | 1 | 0 | 0 | 0 | 0 |
| L1323 | 3 | 1 | Mine | no | 1 | 2 | 0 | 1 | 2 | 0 | 0 | 291 |
| L1323 | 3 | 1 | Opponent | no | 0 | 2 | 4 | 0 | 1 | 0 | 0 | 132 |
| L1418 | 2 | 1 | Mine | - | - | 2 | 1 | 0 | 1 | 0 | 0 | 123 |
| L1418 | 2 | 1 | Opponent | - | - | - | 0 | 2 | 1 | 0 | 0 | 305 |
| L1435 | 1 | 1 | Mine | no | 0 | 3 | 2 | 2 | 0 | 0 | 0 | 0 |
| L1435 | 1 | 1 | Opponent | no | 3 | 2 | 5 | 0 | 0 | 0 | 0 | 432 |
| L1531 | 1 | 1 | Mine | no | 6 | 2 | 1 | 1 | 0 | 0 | 0 | 176 |
| L1531 | 1 | 1 | Opponent | no | 1 | 6 | 1 | 1 | 0 | 0 | 0 | 170 |
| L1629 | 3 | 1 | Mine | no | 0 | 2 | 3 | 0 | 0 | 0 | 0 | 200 |
| L1629 | 3 | 1 | Opponent | no | 3 | 2 | 6 | 1 | 0 | 0 | 0 | 170 |
| L1727 | 5 | 1 | Mine | yes | - | 3 | 2 | 0 | 0 | 0 | 0 | 0 |
| L1727 | 5 | 1 | Opponent | yes | - | 5 | 4 | 4 | 1 | 0 | 0 | 60 |
| L1827 | 3 | 1 | Mine | no | 0 | 6 | 2 | 1 | 0 | 0 | 0 | 602 |
| L1827 | 3 | 1 | Opponent | no | 4 | 2 | 7 | 1 | 0 | 0 | 0 | 0 |
| L1927 | 1 | 1 | Mine | no | 1 | 1 | 4 | 1 | 0 | 0 | 0 | 0 |
| L1927 | 1 | 1 | Opponent | no | 0 | 2 | 4 | 3 | 0 | 0 | 0 | 60 |
| L2029 | 1 | 1 | Mine | no | 3 | - | 0 | 2 | 0 | 0 | 0 | 210 |
| L2029 | 1 | 1 | Opponent | no | 2 | 2 | 2 | 1 | 1 | 0 | 0 | 292 |
| L2131 | 1 | 1 | Mine | yes | 0 | - | 1 | 2 | 0 | 0 | 0 | 145 |
| L2131 | 1 | 1 | Opponent | no | 5 | 3 | 4 | 0 | 2 | 0 | 0 | 170 |
| L2235 | 3 | 1 | Mine | yes | 1 | 1 | 5 | 0 | 0 | 0 | 0 | 225 |
| L2235 | 3 | 1 | Opponent | no | 0 | 2 | 4 | 2 | 0 | 0 | 0 | 0 |
| L2429 | 5 | 1 | Mine | yes | - | 4 | 4 | 1 | 1 | 0 | 0 | 0 |
| L2429 | 5 | 1 | Opponent | yes | - | 3 | 6 | 2 | 1 | 0 | 0 | 170 |
| L2535 | 3 | 1 | Mine | no | 0 | 4 | 2 | 2 | 0 | 0 | 0 | 0 |
| L2535 | 3 | 1 | Opponent | no | 0 | 1 | 2 | 1 | 0 | 0 | 0 | 0 |
| L2735 | 5 | 1 | Mine | no | - | 3 | 3 | 1 | 0 | 0 | 0 | 0 |
| L2735 | 5 | 1 | Opponent | yes | - | 2 | 3 | 0 | 0 | 0 | 0 | 0 |
| L3033 | 3 | 1 | Mine | yes | 4 | 3 | 3 | 0 | 1 | 0 | 0 | 0 |
| L3033 | 3 | 1 | Opponent | no | 0 | 1 | 6 | 2 | 0 | 0 | 0 | 144 |
| **Average** | | | Mine | 33% | 1.1 | 2.8 | 2.2 | 1.2 | 0.3 | 0.0 | 0.0 | 363.0 |
| **Average** | | | Opponent | 27% | 2.7 | 2.5 | 2.9 | 1.6 | 0.5 | 0.0 | 0.0 | 183.4 |

### KPIs: bg-on-789c37f-p2

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Winner chose to follow up after the loser gave ground |  | 98% (46 of 47); on the table 98% | 95% (58 of 61); on the table 95% | 96% (104 of 108); on the table 96% |
| Winner chose to pursue after the loser fell back in good order |  | 75% (9 of 12); on the table 75% | 90% (19 of 21); on the table 95% | 85% (28 of 33); on the table 88% |
| Winner chose to pursue after the loser fled |  | 36% (9 of 25); on the table 48% | 79% (26 of 33); on the table 82% | 60% (35 of 58); on the table 67% |
| Winner chose to follow up or pursue (all three) |  | 76% (64 of 84); on the table 80% | 90% (103 of 115); on the table 91% | 84% (167 of 199); on the table 86% |
| Magic missiles tried each own turn | 50%+ | 23% (77 of 342) | 31% (49 of 156) | 25% (126 of 498) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 32% (77 of 240) | 43% (49 of 115) | 35% (126 of 355) |
| Points that never fought | lower | 31% (22179 of 71583) | 38% (26996 of 71989) | 34% (49175 of 143572) |
|   infantry points that never fought | lower | 37% (6089 of 16324) | 62% (8636 of 14029) | 49% (14725 of 30353) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 61% (173 of 284) | 57% (169 of 297) | 59% (342 of 581) |
| Bound items with a magic missile used (at least once a game) |  | 90% (18 of 20); 1.2 uses a game | 72% (13 of 18); 1.0 uses a game | 82% (31 of 38); 1.1 uses a game |
| Bound items with another spell used |  | 44% (8 of 18); 0.4 uses a game | 0% (0 of 2); 0.0 uses a game | 40% (8 of 20); 0.2 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 40% (8 of 20); 0.2 uses a game | 14% (1 of 7); 0.0 uses a game | 33% (9 of 27); 0.1 uses a game |
|   their share of the points of units over 100 pts | lower | 56% (33830 of 60231) | 48% (30234 of 63281) | 52% (64064 of 123512) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.9 (26%) | 0.7 (23%) | 2.6 (25%) |
| MARCHED: its unit marched | 2.1 (28%) | 0.8 (25%) | 2.8 (27%) |
| CHARGED: its unit charged | 0.2 (3%) | 0.0 (1%) | 0.2 (2%) |
| IN COMBAT: engaged in combat | 1.4 (18%) | 0.6 (21%) | 2.0 (19%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.2 (7%) | 0.2 (2%) |
| FLEEING: fleeing | 0.3 (4%) | 0.0 (0%) | 0.3 (3%) |
| GONE: slain | 0.9 (12%) | 0.4 (15%) | 1.4 (13%) |
| OFF THE TABLE: off the table or not arrived | 0.3 (4%) | 0.1 (3%) | 0.4 (3%) |
| STUPIDITY: Stupidity | 0.2 (3%) | 0.0 (1%) | 0.2 (2%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.1 (5%) | 0.2 (2%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.2 | 1.5 | 1.2 | 3.5 | 0.4 | 2.1 |
| not cast | 3.6 | 3.4 | 3.8 | 10.3 | 2.0 | 19.6 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.1 (2%) | 0.0 (0%) | 0.0 (0%) | 1.6 (8%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.2 (36%) | 0.3 (8%) | 2.6 (25%) | 0.5 (24%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.8 (27%) | 0.4 (20%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (2%) | 0.0 (1%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.1 (2%) | 0.2 (7%) | 0.5 (14%) | 2.0 (19%) | 0.2 (11%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.3 (8%) | 0.4 (11%) | 0.2 (7%) | 0.2 (2%) | 0.0 (0%) | 0.0 (0%) |
| NO CASTS LEFT: every cast used on other spells | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) |
| FLEEING: fleeing | 0.3 (8%) | 0.4 (12%) | 0.2 (4%) | 0.3 (3%) | 0.1 (6%) | 0.9 (5%) |
| GONE: slain | 0.7 (20%) | 0.3 (10%) | 0.6 (17%) | 1.4 (13%) | 0.2 (13%) | 3.2 (16%) |
| OFF THE TABLE: off the table or not arrived | 0.2 (5%) | 0.2 (7%) | 0.2 (6%) | 0.4 (3%) | 0.2 (8%) | 0.5 (2%) |
| STUPIDITY: Stupidity | 0.1 (2%) | 0.1 (2%) | 0.1 (3%) | 0.2 (2%) | 0.0 (0%) | 0.3 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (2%) | 0.3 (10%) | 0.0 (1%) | 0.1 (1%) | 0.3 (15%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (2%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.9 (53%) | 0.2 (6%) | 1.5 (39%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 13.1 (67%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.8 a game | 0.5 a game | 0.6 a game |
| stood (cast and not dispelled) | 55% (12 of 22) | 26% (5 of 19) | 41% (17 of 41) |
| the unit moved after it | 75% (9 of 12) | 80% (4 of 5) | 76% (13 of 17) |
| it charged on its next turn | 8% (1 of 12) | 0% (0 of 5) | 6% (1 of 17) |
| the enemy charged it first | 42% (5 of 12) | 20% (1 of 5) | 35% (6 of 17) |
| it fought by the end of its next turn | 17% (2 of 12) | 20% (1 of 5) | 18% (3 of 17) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 12) | 20% (1 of 5) | 6% (1 of 17) |
| none of these (no charge, no fight, no charge escaped) | 50% (6 of 12) | 60% (3 of 5) | 53% (9 of 17) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 65% (541 of 833) | 51% (416 of 815) | 58% (957 of 1648) |
|   cavalry | 67% (35 of 52) | 50% (86 of 173) | 54% (121 of 225) |
|   character | 53% (45 of 85) | 28% (33 of 116) | 39% (78 of 201) |
|   chariot | 44% (43 of 97) | 68% (27 of 40) | 51% (70 of 137) |
|   infantry | 58% (160 of 277) | 53% (170 of 319) | 55% (330 of 596) |
|   monster | 44% (17 of 39) | 44% (17 of 39) | 44% (34 of 78) |
|   war machine | 85% (241 of 283) | 65% (83 of 128) | 79% (324 of 411) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.7 (33%) | 3.2 (29%) | 5.9 (31%) |
| CHARGED: it charged | 1.1 (13%) | 1.9 (17%) | 3.0 (15%) |
| FLEEING: it fled or was fleeing | 0.2 (2%) | 0.2 (2%) | 0.4 (2%) |
| IN COMBAT: it fought this turn or the last | 1.1 (13%) | 0.6 (6%) | 1.7 (9%) |
| HELD FIRE: a target, but it held its fire | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NO TARGET IN RANGE | 1.1 (13%) | 1.9 (18%) | 3.0 (16%) |
| ONLY IN COMBAT: the only targets were in combat | 0.2 (2%) | 0.4 (4%) | 0.6 (3%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.5 (18%) | 2.1 (19%) | 3.6 (19%) |
| SHELTERED: the target was sheltered | 0.2 (2%) | 0.3 (3%) | 0.5 (2%) |
| STUPIDITY | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR | 0.1 (2%) | 0.4 (4%) | 0.6 (3%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 4.9 | 1.3 | 83% | 4.8 pts | 24 pts |
| character | 2.3 | 1.1 | 70% | 10.9 pts | 25 pts |
| chariot | 1.9 | 1.4 | 71% | 19.4 pts | 38 pts |
| infantry | 13.2 | 5.7 | 69% | 10.5 pts | 138 pts |
| monster | 1.1 | 0.3 | 80% | 7.6 pts | 9 pts |
| war machine | 9.0 | 7.4 | 60% | 26.8 pts | 241 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.0 | 6.3 | 5.1 |
| Charges that made contact a game | 3.1 | 4.5 | 3.8 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.65 declared, 0.50 contact (26 units) | 0.77 declared, 0.77 contact (13 units) | 0.69 declared, 0.59 contact (39 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.83 declared, 0.50 contact (6 units) | 1.36 declared, 1.09 contact (11 units) | 1.18 declared, 0.88 contact (17 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.49 declared, 0.39 contact (247 units) | 0.70 declared, 0.49 contact (288 units) | 0.60 declared, 0.44 contact (535 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 67% (49 of 73) | 67% (12 of 18) | 50% (6 of 12) | 65% (67 of 103) |
| Character in a unit | 84% (21 of 25) | 46% (6 of 13) | 25% (1 of 4) | 67% (28 of 42) |
| Character on its own | 85% (40 of 47) | 56% (23 of 41) | 21% (13 of 62) | 51% (76 of 150) |
| Chariot | 71% (12 of 17) | 77% (10 of 13) | - | 73% (22 of 30) |
| Infantry | 52% (49 of 94) | 50% (17 of 34) | 67% (2 of 3) | 52% (68 of 131) |
| Monster | 69% (20 of 29) | 56% (5 of 9) | - | 66% (25 of 38) |
| Monstrous | 50% (7 of 14) | 57% (8 of 14) | - | 54% (15 of 28) |
| War Machines | 68% (39 of 57) | 100% (2 of 2) | - | 69% (41 of 59) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 88% (7 of 8); on the table 88% | 15% (15 of 102) | 28% | 59% (13 of 22) | 83% (5 of 6); 2.2 uses a game | 100% (2 of 2); 0.8 uses a game | 83% (5 of 6); 1.2 uses a game |
| Chaos Dwarfs | 4 | 86% (6 of 7); on the table 86% | 42% (15 of 36) | 54% | 59% (19 of 32) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |
| Dwarfen Mountain Holds | 6 | 60% (6 of 10); on the table 60% | - | 47% | 69% (37 of 54) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 7 | 100% (6 of 6); on the table 100% | 35% (17 of 48) | 46% | 66% (50 of 76) | 0.0 uses a game | 50% (1 of 2); 0.1 uses a game | 0% (0 of 4); 0.0 uses a game |
| Grand Cathay | 6 | 88% (15 of 17); on the table 94% | 22% (30 of 138) | 38% | 52% (28 of 54) | 86% (12 of 14); 6.2 uses a game | 50% (1 of 2); 0.2 uses a game | 0% (0 of 6); 0.0 uses a game |
| High Elf Realms | 4 | 54% (7 of 13); on the table 54% | 11% (2 of 18) | 19% | 52% (17 of 33) | 100% (3 of 3); 1.8 uses a game | 29% (4 of 14); 2.2 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 2 | 67% (2 of 3); on the table 67% | - | 32% | 58% (7 of 12) | 0.0 uses a game | 0.0 uses a game | 100% (2 of 2); 1.0 uses a game |
| Lizardmen | 1 | 100% (3 of 3); on the table 100% | - | 26% | 71% (5 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 4 | 100% (7 of 7); on the table 100% | 0% (0 of 18) | 37% | 75% (21 of 28) | 100% (4 of 4); 2.5 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 1 | 100% (2 of 2); on the table 100% | 0% (0 of 12) | 15% | 0% (0 of 8) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Skaven | 3 | 55% (6 of 11); on the table 64% | 22% (4 of 18) | 27% | 56% (14 of 25) | 100% (2 of 2); 0.7 uses a game | 0.0 uses a game | 33% (1 of 3); 0.3 uses a game |
| Tomb Kings of Khemri | 5 | 87% (13 of 15); on the table 93% | - | 30% | 36% (9 of 25) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 9 | 86% (30 of 35); on the table 91% | 48% (32 of 66) | 34% | 63% (34 of 54) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 9 | 89% (24 of 27); on the table 89% | 28% (5 of 18) | 23% | 49% (36 of 73) | 50% (1 of 2); 0.3 uses a game | 0.0 uses a game | 100% (1 of 1); 0.1 uses a game |
| Wood Elf Realms | 7 | 94% (33 of 35); on the table 94% | 25% (6 of 24) | 32% | 67% (52 of 78) | 57% (4 of 7); 1.9 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (bg-on-789c37f-p2, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 48% (47) | 69% (46) | 56% (93) |
| ...free all their last turn and able to turn (per game) | 0.78 | 0.86 | 1.64 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.31 | 0.17 | 0.47 |
| ...with the charger already in that arc before they moved (per game) | 0.56 | 0.58 | 1.14 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 1.64 | 1.31 | 2.94 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.64 | 0.81 | 1.44 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 10.86 | 10.14 | 21.00 |

### Quality by phase: bg-on-789c37f-p2

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.8 | 3.3 |
| Strategy | Charge objectives carried out (made contact) | 50% (63 of 125) | 49% (96 of 196) |
| Strategy | Shoot objectives carried out (shot that target) | 49% (168 of 343) | 55% (108 of 195) |
| Strategy | Close-in objectives charged next turn | 11% (16 of 152) | 18% (43 of 234) |
| Strategy | Support requests answered (helper made contact too) | 75% (9 of 12) | 56% (14 of 25) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 75% (3 of 4) | 100% (2 of 2) |
| Strategy | Hexes on a unit its side charged or shot that turn | 50% (7 of 14) | 76% (13 of 17) |
| Strategy | Joined characters whose unit fought | 63% (24 of 38) | 31% (11 of 35) |
| Strategy | Lone characters that fought | 84% (90 of 107) | 77% (68 of 88) |
| Movement | Charges halted short of contact | 0.1 | 0.3 |
| Movement | Idle units | 1.2 | 1.6 |
| Movement | Points that never moved of their own | 363.0 | 183.4 |
| Movement | Fights charged into per game | 2.8 | 3.9 |
| Movement | Charges with odds: long shots (under 50%) | 11 of 90, net -25 | 17 of 126, net +75 |
| Movement | Charges with odds: sweet spot (55-75%) | 10 of 90, net +32 | 13 of 126, net +207 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 14 of 90, net +129 | 11 of 126, net +160 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 38 of 90, net +117 | 51 of 126, net +134 |
| Shooting | Shots by shooting units (incl. breath weapons) | 9.1 | 10.2 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 41% (133 of 327) | 42% (155 of 368) |
| Shooting | Points destroyed by shooting units | 89.6 | 48.7 |
| Shooting | War machine shots | 6.7 | 2.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 50% (121 of 241) | 46% (38 of 83) |
| Shooting | Points destroyed by war machines | 71.8 | 57.7 |
| Magic | Magic missiles cast | 1.4 | 0.9 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 27% (14 of 52) | 65% (20 of 31) |
| Magic | Wounds caused by magic missiles | 2.9 | 1.4 |
| Magic | Wounds caused by other spells | 1.2 | 1.6 |
| Magic | Points destroyed by magic (all spells) | 53.6 | 49.4 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.9 / 0.5 / 0.7 / 0.1 | 2.1 / 0.5 / 0.6 / 0.1 |
| Combat | Points destroyed in combat | 316.1 | 471.0 |
| Combat | Points run down | 82.9 | 142.9 |
| Combat | Net points per charged fight, damage counted | +83 | +117 |
| Combat | Net per 100 charger points, damage counted | +28.8 | +39.1 |
| Combat | First round won (charged fights) | 72% | 62% |
| Combat | Net points per charged fight | +79 | +113 |
| Combat | Net points per supported fight / lone fight | +194 / +65 | +188 / +100 |
| Combat | Charged fights on a top-3 enemy unit | 39 of 101 | 58 of 139 |
| Game | Points lost | 926.1 | 700.6 |
| Game | VP from objectives | 468.6 | 634.2 |
| Game | Lone holders (player turns) | 1.1 | 2.7 |

- Mine won / drew / lost: 8 / 10 / 18 of 36 ended games (of 36); mean margin (Mine - Opponent) -430 VP
- The side that went first won 15 of 26 games with a winner
- Points traded per game (both sides' losses): 1627
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: bg-on-789c37f-p2

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.6 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| ALREADY CARRIED | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARRIVAL HUNT | - | - | - | - | 0.1 | +4.3 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.6 | +0.0 | 0.0 | 29.4 | 0.2 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | 1.1 | +7.3 | 0.0 | 25.6 | 0.9 | +11.4 | 0.0 | 13.7 |
| BEST PREY | 4.3 | +246.9 | 168.7 | 143.9 | 5.4 | +368.2 | 254.6 | 180.8 |
| BEST PRIZE | 0.1 | -2.4 | 6.7 | 1.4 | 0.1 | -5.3 | 9.8 | 6.6 |
| BLOCKED CHARGE SKIPPED | 0.0 | +0.0 | 5.7 | 0.0 | 0.1 | +0.0 | 6.5 | 0.0 |
| BLOCKED WHEEL | 0.5 | +0.1 | 0.0 | 17.8 | 0.6 | -13.2 | 0.0 | 0.0 |
| BOMBING RUN | 0.0 | +0.9 | 0.0 | 0.0 | 0.0 | +1.0 | 0.0 | 0.0 |
| BOUND ASSAILMENT | 0.1 | +0.0 | 0.0 | 4.2 | - | - | - | - |
| CANNON PLAN MISSED | 0.9 | +0.0 | 167.8 | 26.1 | 0.2 | +0.0 | 40.9 | 0.0 |
| CANNON PLANNED TARGET | 5.4 | +138.7 | 467.0 | 99.2 | 2.0 | +137.4 | 185.4 | 24.6 |
| CANNON SIGHT KEPT | 1.3 | +0.0 | 0.0 | 2.4 | 0.5 | +0.0 | 0.0 | 0.0 |
| CAST JOB | 0.9 | +20.0 | 44.4 | 18.1 | 0.5 | +14.0 | 43.9 | 0.0 |
| CASTER AWAY FROM SCREEN | 0.2 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.4 | +23.3 | 32.0 | 20.0 | 0.2 | +9.5 | 10.5 | 4.4 |
| CASTS AFTER FRIENDS | 0.4 | +0.0 | 0.0 | 27.2 | 0.2 | +0.0 | 0.0 | 7.6 |
| CASTS FROM BEHIND | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.1 | +2.9 | 0.0 | 0.0 | - | - | - | - |
| CHAFF PASSED | 0.2 | -0.2 | 9.2 | 15.8 | 0.2 | -0.4 | 8.8 | 3.2 |
| CHARGE NOW WEIGHED | 0.4 | -20.2 | 17.9 | 16.2 | 0.7 | -29.3 | 20.3 | 17.0 |
| CHARIOT NO STATIC JOB | 0.8 | +0.0 | 18.6 | 11.2 | 0.5 | +0.0 | 0.0 | 2.1 |
| CHEAP HELPER | 0.0 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 4.6 | 0.0 |
| CONVEYANCE SEARCH | 0.4 | +28.9 | 1.8 | 16.1 | 0.5 | +54.9 | 5.8 | 28.1 |
| COUNTER-CHARGE COVER | 10.4 | +791.0 | 0.0 | 221.1 | 7.7 | +575.4 | 0.0 | 210.1 |
| EDGE GIVE GROUND | 0.2 | +10.6 | 12.3 | 0.0 | 0.3 | +3.7 | 35.6 | 0.0 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 2.4 | - | - | - | - |
| ESCORT | 0.7 | +44.3 | 0.0 | 14.9 | 0.6 | +24.7 | 0.0 | 3.2 |
| FACES THE THREAT | 1.6 | +110.8 | 0.0 | 87.6 | 1.3 | +143.5 | 0.0 | 57.2 |
| FIGHT LIFT | 0.1 | +0.2 | 0.0 | 0.0 | 0.1 | +2.1 | 21.1 | 0.0 |
| FIRE AND FLEE | - | - | - | - | 0.1 | +1.8 | 7.9 | 12.5 |
| FOCUS FIRE | 0.1 | +5.9 | 7.9 | 1.5 | 0.0 | +0.6 | 0.0 | 0.0 |
| FOLLOW UP WEIGHED | 0.9 | +121.3 | 0.0 | 35.1 | 1.5 | +249.8 | 0.0 | 36.1 |
| FRIENDS SHOTS CHECKED | 0.1 | +6.4 | 0.0 | 0.0 | 0.1 | +18.5 | 0.0 | 3.4 |
| GIVES UP | 1.1 | -25.3 | 117.9 | 47.9 | 1.8 | -57.4 | 242.7 | 90.7 |
| GIVES UP ITS SCREEN | 0.5 | -5.6 | 45.2 | 9.6 | 1.6 | -34.3 | 82.4 | 12.4 |
| GROUP AIM | 0.1 | +1.1 | 0.0 | 2.2 | 0.6 | +5.4 | 0.0 | 30.3 |
| GROUP BROKEN | 0.1 | +0.0 | 0.0 | 0.0 | 0.0 | +0.0 | 4.4 | 7.6 |
| HELPER ALREADY ASKED | - | - | - | - | 0.1 | +0.0 | 1.1 | 6.2 |
| HELPER UNSEEN | 0.2 | +0.0 | 12.1 | 0.0 | 0.3 | +0.0 | 8.7 | 11.3 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HUNT ADVANCE | 0.0 | +0.0 | 0.0 | 0.0 | 0.2 | +0.6 | 2.4 | 6.4 |
| HUNT DROPPED | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| HUNT IN PAIRS | 0.1 | +9.3 | 0.0 | 0.0 | 0.6 | +49.1 | 0.0 | 11.4 |
| HUNT KEPT | 0.0 | +0.0 | 3.3 | 1.4 | 0.1 | +1.7 | 22.6 | 1.8 |
| HUNT RESULT | 0.1 | +3.4 | 0.0 | 0.0 | 0.3 | +54.8 | 20.3 | 1.8 |
| HUNT THE GUNS | 0.1 | +8.9 | 3.3 | 1.4 | 0.3 | +152.3 | 8.9 | 9.7 |
| JOINT CHARGE PLAN | 0.1 | +6.8 | 0.0 | 0.0 | 0.2 | +3.9 | 0.0 | 0.0 |
| KEEPS ITS PREY | 0.3 | +3.2 | 0.0 | 33.2 | 0.1 | +1.0 | 4.6 | 5.1 |
| KEEPS ITS TARGET | 1.5 | +44.2 | 104.1 | 44.4 | 2.8 | +83.3 | 337.1 | 62.6 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| KILLS COUNT | 1.3 | +64.3 | 123.7 | 31.3 | 1.9 | +93.4 | 145.9 | 36.8 |
| KILLS COUNT NEXT TURN | 7.8 | +283.6 | 339.6 | 254.9 | 11.3 | +507.5 | 622.6 | 332.3 |
| LONE CHARACTER SAFE SPOT | 0.5 | +24.1 | 6.0 | 38.7 | 0.4 | +12.2 | 17.6 | 8.1 |
| LONE WIZARD HOLDS BACK | 1.4 | +0.0 | 33.7 | 31.1 | 1.2 | +0.0 | 47.0 | 34.3 |
| LONE WIZARD KEPT IN | 0.6 | +39.4 | 0.0 | 0.0 | 0.3 | +23.5 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 0.8 | +33.4 | 9.6 | 15.0 | 1.6 | +89.0 | 62.5 | 44.3 |
| MANOEUVRE | 0.2 | +2.0 | 0.0 | 5.2 | 0.2 | +3.4 | 0.0 | 8.9 |
| MARCH AT ESCAPER | 0.1 | +1.2 | 0.0 | 0.0 | 0.2 | +1.5 | 0.0 | 4.4 |
| MARCH ODDS | 0.9 | +58.8 | 39.0 | 31.1 | 0.4 | +39.2 | 28.4 | 10.6 |
| MISSILES IN THE MOVE | 2.9 | +68.3 | 0.0 | 94.5 | 2.6 | +61.0 | 0.0 | 70.1 |
| MISSILES NEXT TURN | 4.4 | +68.6 | 0.0 | 157.7 | 3.6 | +45.4 | 0.0 | 73.8 |
| MODEL FACING | 0.2 | +45.3 | 0.0 | 6.7 | 0.3 | +85.1 | 0.0 | 0.0 |
| MOVE AND CAST | 0.2 | +11.1 | 0.0 | 4.5 | 0.1 | +3.6 | 0.0 | 0.0 |
| MOVE SPELL IN RANGE | 0.2 | +7.9 | 0.0 | 32.2 | 0.0 | +0.6 | 0.0 | 11.2 |
| MOVE SPELL OUT OF RANGE | 0.3 | -10.9 | 4.7 | 17.4 | 0.1 | -4.7 | 0.0 | 22.5 |
| MOVE SPELL SPOT | 0.2 | +0.0 | 0.0 | 12.9 | - | - | - | - |
| MOVES UNITS SPELL | 0.1 | +3.4 | 0.0 | 0.0 | - | - | - | - |
| NEEDED THERE | 0.1 | +16.4 | 8.6 | 0.0 | 0.1 | +20.1 | 5.9 | 0.0 |
| NO RALLY LEFT | 0.0 | +0.3 | 0.0 | 3.1 | - | - | - | - |
| NOT NEEDED | 0.2 | -17.9 | 52.1 | 2.2 | 0.2 | -9.6 | 24.7 | 0.0 |
| NOT TURNED | 10.9 | +79.4 | 0.0 | 312.2 | 10.1 | +136.2 | 0.0 | 169.9 |
| NOT WORTH A CAST | 0.6 | -0.4 | 0.0 | 12.2 | 0.6 | -0.6 | 0.0 | 0.0 |
| OPENS A LANE | 0.1 | +1.4 | 4.9 | 0.0 | 0.1 | +0.4 | 5.6 | 0.0 |
| OPENS UP | 0.1 | +12.1 | 8.2 | 0.0 | 0.2 | +25.1 | 8.4 | 5.4 |
| OVERRUNS AWAY | 0.6 | +9.1 | 39.1 | 18.0 | 0.5 | +3.0 | 62.9 | 21.8 |
| PATHS CROSS | 2.2 | +108.0 | 0.0 | 20.4 | 3.1 | +214.8 | 0.0 | 51.9 |
| PERIAPT WORTH | 0.0 | +2.8 | 0.0 | 0.0 | - | - | - | - |
| PLAN LEADS | 1.4 | +149.0 | 50.0 | 26.6 | 1.3 | +88.5 | 35.2 | 8.2 |
| PLAN RESULT | 36.5 | +1515.3 | 1371.8 | 1221.2 | 42.2 | +1420.2 | 1845.3 | 981.2 |
| PURSUES BIG PREY | 0.1 | -4.2 | 0.0 | 9.4 | 0.2 | -9.9 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE NEXT TURN | 0.1 | +3.5 | 0.0 | 0.0 | 0.0 | +2.4 | 0.0 | 0.0 |
| REDIRECT COUNTER | 3.6 | +120.0 | 0.0 | 52.9 | 5.3 | +288.0 | 0.0 | 46.8 |
| REDIRECT WEIGHED | 0.2 | +2.1 | 3.2 | 1.4 | 0.3 | +9.8 | 15.6 | 13.8 |
| RESTRAINS TO SHOOT | 0.1 | +5.2 | 0.0 | 0.0 | 0.1 | +5.3 | 0.0 | 5.1 |
| RISK BY ARC | 2.0 | +52.8 | 154.6 | 65.0 | 2.8 | +74.0 | 269.4 | 142.1 |
| SAFER THAN THE JOB | 0.6 | +29.1 | 0.0 | 10.0 | 0.8 | +55.9 | 0.0 | 27.3 |
| SCOUT SPOT | 0.3 | +0.6 | 0.0 | 0.0 | 0.5 | +2.1 | 0.0 | 0.0 |
| SCOUT WAITS | 0.3 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| SEARCH SPOT | 0.9 | +50.7 | 0.0 | 18.1 | 1.3 | +74.7 | 0.0 | 20.6 |
| SECOND HUNTER | - | - | - | - | 0.1 | -0.4 | 0.0 | 6.4 |
| SELF MOVE SPELL | 0.2 | +11.0 | 0.0 | 9.1 | - | - | - | - |
| SET UP TOGETHER | 1.1 | +36.2 | 9.6 | 32.1 | 2.7 | +127.3 | 71.1 | 66.6 |
| SHOOTERS IN TWO RANKS | 0.4 | +0.8 | 0.0 | 0.0 | 0.3 | +0.5 | 0.0 | 0.0 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| SHOT REPLANNED | 0.7 | +0.0 | 165.4 | 13.8 | 0.4 | +0.0 | 65.2 | 0.0 |
| SHOTS IN THE MOVE | 12.6 | +469.6 | 0.0 | 258.2 | 10.3 | +404.2 | 0.0 | 151.7 |
| SPELL CATCH ODDS | 0.1 | -1.3 | 0.0 | 0.0 | 0.0 | -0.1 | 0.0 | 0.0 |
| SPELL SETS UP CHARGE | 0.0 | +14.5 | 0.0 | 0.0 | 0.1 | +32.4 | 0.0 | 7.6 |
| SPELL WORTH | 0.7 | +14.3 | 75.0 | 67.4 | 1.9 | +39.5 | 101.1 | 80.0 |
| STOPS | 0.0 | +0.0 | 3.3 | 1.4 | 0.2 | +8.4 | 11.1 | 3.2 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 4.7 | 0.2 | +0.0 | 0.0 | 9.4 |
| SURE CHARGE BEATS ADVANCE | 0.1 | -2.9 | 1.1 | 0.0 | 0.2 | -10.3 | 34.6 | 0.0 |
| THROUGH LINE OF FIRE | 0.2 | +4.6 | 0.0 | 5.9 | 0.2 | +1.3 | 0.0 | 1.8 |
| TURN WORTH | 0.4 | -25.0 | 39.1 | 3.8 | 0.2 | -23.4 | 18.2 | 0.0 |
| TWO OR MORE ARRIVE | 0.2 | +4.7 | 0.0 | 4.2 | 0.8 | +11.8 | 37.5 | 8.6 |
| WEARS DOWN | 1.0 | +36.0 | 95.7 | 37.2 | 1.9 | +62.1 | 225.9 | 71.9 |
| WHO HITS BACK | 0.2 | +16.4 | 0.0 | 0.0 | 0.3 | +21.7 | 0.0 | 16.4 |
| WHOLE FIGHT | 0.2 | +1.3 | 13.4 | 17.5 | 0.5 | -42.2 | 104.7 | 19.7 |
| WHOLE FIGHT GAIN | 0.3 | +43.7 | 48.7 | 2.2 | 0.5 | +32.3 | 21.7 | 11.4 |

### Rule changes: bg-on-789c37f-p2

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| KILLS COUNT NEXT TURN | 690 | 682 | 206 | 5.72 | +7322 | +35.5 |
| BEST PREY | 349 | 343 | 151 | 4.19 | +5830 | +38.6 |
| FOLLOW UP WEIGHED | 85 | 85 | 85 | 2.36 | +13362 | +157.2 |
| COUNTER-CHARGE COVER | 652 | 300 | 77 | 2.14 | +3305 | +42.9 |
| CANNON SIGHT KEPT | 65 | 65 | 65 | 1.81 | +0 | +0.0 |
| ARTILLERY RE-ROLL WEIGHED | 63 | 63 | 63 | 1.75 | +0 | +0.0 |
| CANNON PLANNED TARGET | 264 | 264 | 46 | 1.28 | -528 | -11.5 |
| RISK BY ARC | 172 | 163 | 45 | 1.25 | +1112 | +24.7 |
| ADVANCE LANE KEPT | 44 | 44 | 44 | 1.22 | +0 | +0.0 |
| KILLS COUNT | 115 | 112 | 43 | 1.19 | +2005 | +46.6 |
| MARCH ODDS | 47 | 43 | 43 | 1.19 | +1350 | +31.4 |
| SET UP TOGETHER | 135 | 98 | 42 | 1.17 | +2054 | +48.9 |
| SHOT REPLANNED | 41 | 41 | 41 | 1.14 | +0 | +0.0 |
| HOLDS AMBUSHERS | 40 | 40 | 40 | 1.11 | +0 | +0.0 |
| LONE WIZARD HOLDS BACK | 94 | 94 | 40 | 1.11 | -1967 | -49.2 |
| PLAN LEADS | 98 | 98 | 40 | 1.11 | +2091 | +52.3 |
| CHARGE NOW WEIGHED | 39 | 39 | 39 | 1.08 | +2910 | +74.6 |
| LONE WIZARD KEPT IN | 33 | 33 | 33 | 0.92 | +2266 | +68.7 |
| KEEPS ITS TARGET | 153 | 150 | 32 | 0.89 | +526 | +16.4 |
| SCOUT WAITS | 32 | 32 | 32 | 0.89 | +0 | +0.0 |
| CHARIOT NO STATIC JOB | 48 | 48 | 30 | 0.83 | -2515 | -83.8 |
| MAKE SURE TOGETHER | 83 | 51 | 29 | 0.81 | +1296 | +44.7 |
| SHOOTERS IN TWO RANKS | 25 | 25 | 25 | 0.69 | +49 | +2.0 |
| CAST JOB | 50 | 47 | 24 | 0.67 | +553 | +23.1 |
| REDIRECT COUNTER | 322 | 76 | 21 | 0.58 | +921 | +43.8 |
| WEARS DOWN | 103 | 98 | 21 | 0.58 | +726 | +34.6 |
| CASTING BLOCK | 23 | 23 | 18 | 0.50 | +666 | +37.0 |
| MODEL FACING | 18 | 18 | 18 | 0.50 | +4696 | +260.9 |
| REDIRECT WEIGHED | 18 | 18 | 18 | 0.50 | +488 | +27.1 |
| WHO HITS BACK | 18 | 18 | 18 | 0.50 | -942 | -52.3 |
| WHOLE FIGHT GAIN | 27 | 22 | 17 | 0.47 | +667 | +39.3 |
| CASTS FROM BEHIND | 15 | 15 | 15 | 0.42 | +0 | +0.0 |
| SHORT GUN FORWARD | 14 | 14 | 14 | 0.39 | +0 | +0.0 |
| CHAFF PASSED | 13 | 13 | 13 | 0.36 | -20 | -1.6 |
| CASTER AWAY FROM SCREEN | 12 | 12 | 12 | 0.33 | +0 | +0.0 |
| STUCK PIVOT | 12 | 12 | 12 | 0.33 | +0 | +0.0 |
| PURSUES BIG PREY | 10 | 10 | 10 | 0.28 | -509 | -50.9 |
| SURE CHARGE BEATS ADVANCE | 10 | 10 | 10 | 0.28 | -475 | -47.5 |
| FRIENDS SHOTS CHECKED | 9 | 9 | 9 | 0.25 | +897 | +99.7 |
| NEEDED THERE | 7 | 7 | 7 | 0.19 | +0 | +0.0 |
| BEST PRIZE | 6 | 6 | 6 | 0.17 | -636 | -106.1 |
| OPENS UP | 11 | 11 | 6 | 0.17 | +397 | +66.1 |
| RESTRAINS TO SHOOT | 6 | 6 | 6 | 0.17 | +378 | +63.0 |
| BLOCKED CHARGE SKIPPED | 4 | 4 | 4 | 0.11 | +0 | +0.0 |
| FOCUS FIRE | 4 | 4 | 4 | 0.11 | +233 | +58.3 |
| KEEPS SCOUTS OR AMBUSH | 4 | 4 | 4 | 0.11 | +0 | +0.0 |
| MOVES UNITS SPELL | 4 | 4 | 4 | 0.11 | +122 | +30.4 |
| OVERRUNS AWAY | 39 | 39 | 4 | 0.11 | +69 | +17.4 |
| TWO OR MORE ARRIVE | 38 | 33 | 4 | 0.11 | +24 | +5.9 |
| BACKUP TARGETS | 72 | 26 | 3 | 0.08 | +25 | +8.3 |
| FIRE AND FLEE | 3 | 3 | 3 | 0.08 | +66 | +21.9 |
| HUNT IN PAIRS | 24 | 12 | 3 | 0.08 | +45 | +14.9 |
| JOINT CHARGE PLAN | 9 | 9 | 3 | 0.08 | +75 | +25.0 |
| MISSILES NEXT TURN | 288 | 116 | 3 | 0.08 | +48 | +15.9 |
| OPENS A LANE | 7 | 5 | 3 | 0.08 | +17 | +5.6 |
| RAIDS THE BAGGAGE NEXT TURN | 3 | 3 | 3 | 0.08 | +116 | +38.7 |
| BOMBING RUN | 2 | 2 | 2 | 0.06 | +68 | +34.0 |
| BOUND ASSAILMENT | 2 | 2 | 2 | 0.06 | +0 | +0.1 |
| EDGE GIVE GROUND | 18 | 17 | 2 | 0.06 | +74 | +37.0 |
| GIVES UP ITS SCREEN | 75 | 73 | 2 | 0.06 | +47 | +23.5 |
| WHOLE FIGHT | 28 | 25 | 2 | 0.06 | +90 | +44.9 |
| ESCORT | 45 | 12 | 1 | 0.03 | +42 | +41.6 |
| KEEPS ITS PREY | 16 | 15 | 1 | 0.03 | +32 | +32.0 |
| NO RALLY LEFT | 1 | 1 | 1 | 0.03 | +4 | +3.8 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.03 | +101 | +101.3 |
| ALREADY CARRIED | 1 | not checked | - | - | - | - |
| ARRIVAL HUNT | 3 | 3 | 0 | 0.00 | - | - |
| BLOCKED WHEEL | 37 | not checked | - | - | - | - |
| CANNON PLAN MISSED | 41 | 41 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 25 | trace | - | - | - | - |
| CATCH FLIERS | 2 | not checked | - | - | - | - |
| CHEAP HELPER | 8 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 31 | not checked | - | - | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FACES THE THREAT | 106 | not checked | - | - | - | - |
| FIGHT LIFT | 5 | not checked | - | - | - | - |
| GIVES UP | 105 | 99 | 0 | 0.00 | - | - |
| GROUP AIM | 25 | 10 | 0 | 0.00 | - | - |
| GROUP BROKEN | 3 | not checked | - | - | - | - |
| HELPER ALREADY ASKED | 3 | not checked | - | - | - | - |
| HELPER UNSEEN | 19 | 18 | 0 | 0.00 | - | - |
| HUNT ADVANCE | 8 | 8 | 0 | 0.00 | - | - |
| HUNT DROPPED | 4 | trace | - | - | - | - |
| HUNT KEPT | 5 | trace | - | - | - | - |
| HUNT RESULT | 14 | trace | - | - | - | - |
| HUNT THE GUNS | 14 | trace | - | - | - | - |
| LONE CHARACTER SAFE SPOT | 30 | not checked | - | - | - | - |
| MANOEUVRE | 12 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 11 | trace | - | - | - | - |
| MISSILES IN THE MOVE | 197 | not checked | - | - | - | - |
| MOVE AND CAST | 12 | not checked | - | - | - | - |
| MOVE SPELL IN RANGE | 8 | 3 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 16 | trace | - | - | - | - |
| MOVE SPELL SPOT | 7 | not checked | - | - | - | - |
| NOT NEEDED | 13 | 13 | 0 | 0.00 | - | - |
| NOT TURNED | 756 | 756 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 42 | not checked | - | - | - | - |
| PATHS CROSS | 191 | not checked | - | - | - | - |
| PLAN RESULT | 2832 | trace | - | - | - | - |
| SAFER THAN THE JOB | 52 | not checked | - | - | - | - |
| SCOUT SPOT | 28 | 28 | 0 | 0.00 | - | - |
| SEARCH SPOT | 79 | not checked | - | - | - | - |
| SECOND HUNTER | 4 | 4 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 9 | not checked | - | - | - | - |
| SHOTS IN THE MOVE | 824 | not checked | - | - | - | - |
| SPELL CATCH ODDS | 3 | not checked | - | - | - | - |
| SPELL SETS UP CHARGE | 4 | not checked | - | - | - | - |
| SPELL WORTH | 95 | not checked | - | - | - | - |
| STOPS | 7 | 7 | 0 | 0.00 | - | - |
| THROUGH LINE OF FIRE | 17 | not checked | - | - | - | - |
| TURN WORTH | 24 | 22 | 0 | 0.00 | - | - |

### Plans: bg-on-789c37f-p2

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 11.9 | 20% | 531 | 380 | 72% |
| Mine | charge | 2.6 | 59% | 248 | 268 | 108% |
| Mine | close in | 4.2 | 19% | 255 | 114 | 45% |
| Mine | hold | 3.9 | 34% | 251 | 0 | 0% |
| Mine | join | 0.5 | 84% | 13 | 0 | 0% |
| Mine | shoot | 8.5 | 66% | 263 | 754 | 287% |
| Mine | support | 4.8 | 87% | 281 | 0 | 0% |
| Opponent | advance | 15.1 | 19% | 677 | 504 | 75% |
| Opponent | charge | 4.4 | 61% | 558 | 410 | 74% |
| Opponent | close in | 6.4 | 28% | 526 | 190 | 36% |
| Opponent | hold | 4.4 | 40% | 409 | 0 | 0% |
| Opponent | join | 0.9 | 94% | 43 | 0 | 0% |
| Opponent | shoot | 4.6 | 64% | 230 | 315 | 137% |
| Opponent | support | 6.4 | 93% | 298 | 0 | 0% |

### Packages: hunt the guns, bg-on-789c37f-p2

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.1 | 2 | 0 | 50% | 50% | 0% | 3.0 | 160 | 61 | 50% | 76 |
| Opponent | 0.3 | 12 | 0 | 33% | 50% | 0% | 2.7 | 457 | 164 | 50% | 64 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.2 | 1 | 0 | 100% | 100% | 0% | 3.0 | 122 | 121 | 100% | 72 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 386 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 110 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 117 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 22 |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Ogre Kingdoms | 1.0 | 4 | 0 | 75% | 75% | 0% | 2.7 | 500 | 348 | 75% | 122 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 118 |
| Tomb Kings of Khemri | 0.6 | 3 | 0 | 33% | 100% | 0% | 2.7 | 200 | 193 | 100% | 28 |
| Vampire Counts | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Warriors of Chaos | 0.7 | 6 | 0 | 0% | 0% | 0% | - | 513 | 0 | 0% | 67 |
| Wood Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |

### Battle groups: bg-on-789c37f-p2

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 10.4 | 18% | 59% | 14% | 20% | 36% | 10% | 10% | 44% | 0% |
| Mine | REDIRECT COUNTER | 3.6 | 20% | 62% | 15% | 50% | 5% | 0% | 23% | 68% | 5% |
| Opponent | COUNTER-CHARGE COVER | 7.7 | 20% | 42% | 11% | 17% | 22% | 12% | 6% | 59% | 0% |
| Opponent | REDIRECT COUNTER | 5.3 | 13% | 72% | 28% | 0% | 11% | 0% | 22% | 56% | 11% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.1 | 5 | 0% | - |
| Opponent | 0.5 | 13 | 8% | 0% |

### Deployment: positions vs output by unit type: bg-on-789c37f-p2

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 5 | 0 (5) | 0 | 0 | 32 | 20% | 5.8 | 0 (1) | 0 (3) | 0 (1) | 0 (3) | 0 (2) |
| Mine | Chaff | 44 | 45 (44) | 24 | 21 | 66 | 36% | 2.9 | 46 (24) | 0 (5) | 59 (15) | 59 (30) | 14 (14) |
| Mine | Character | 123 | 44 (123) | 44 | 0 | 46 | 14% | 2.5 | 54 (34) | 44 (61) | 42 (7) | 49 (61) | 46 (41) |
| Mine | Clean-up | 12 | 46 (12) | 6 | 40 | 68 | 33% | 3.4 | 18 (3) | 38 (6) | 101 (3) | 63 (7) | 23 (5) |
| Mine | Fast Hammer | 45 | 65 (45) | 48 | 17 | 51 | 22% | 3.0 | 55 (24) | 102 (10) | 46 (11) | 38 (31) | 131 (14) |
| Mine | Fragile | 5 | 36 (5) | 36 | 0 | 0 | 0% | 2.0 | - | 59 (3) | 0 (2) | 36 (5) | - |
| Mine | Hammer | 58 | 35 (58) | 23 | 12 | 52 | 22% | 2.7 | 8 (15) | 40 (33) | 63 (10) | 30 (38) | 43 (20) |
| Mine | Holder | 28 | 57 (28) | 10 | 48 | 48 | 43% | 3.2 | 26 (9) | 87 (13) | 45 (6) | 77 (17) | 30 (11) |
| Mine | Shooter | 43 | 75 (43) | 37 | 39 | 48 | 2% | 1.9 | 43 (7) | 86 (26) | 62 (10) | 93 (27) | 44 (16) |
| Mine | Support | 2 | 19 (2) | 19 | 0 | 0 | 50% | 2.0 | 0 (1) | 28 (1) | - | - | 19 (2) |
| Mine | War machine | 59 | 32 (59) | 32 | 0 | 57 | 3% | 1.3 | 3 (13) | 47 (36) | 4 (10) | 6 (10) | 37 (49) |
| Mine | Wizard | 22 | 20 (22) | 20 | 0 | 55 | 9% | 2.7 | 0 (4) | 48 (8) | 0 (3) | 46 (7) | 8 (8) |
| Opponent | Blocker | 2 | 0 (2) | 0 | 0 | 62 | 50% | 6.0 | 0 (2) | - | - | 0 (1) | 0 (1) |
| Opponent | Chaff | 89 | 39 (89) | 26 | 13 | 39 | 42% | 2.8 | 51 (35) | 2 (20) | 52 (34) | 47 (63) | 21 (26) |
| Opponent | Character | 94 | 76 (94) | 76 | 0 | 36 | 18% | 2.3 | 80 (42) | 94 (33) | 54 (7) | 90 (57) | 71 (25) |
| Opponent | Clean-up | 10 | 58 (10) | 31 | 28 | 54 | 20% | 3.0 | 48 (6) | 97 (3) | 0 (1) | 41 (7) | 112 (3) |
| Opponent | Early | 2 | 0 (2) | 0 | 0 | 50 | 50% | 5.0 | - | 0 (2) | - | 0 (2) | - |
| Opponent | Fast Hammer | 45 | 32 (45) | 19 | 12 | 41 | 29% | 3.2 | 13 (28) | 56 (8) | 67 (9) | 22 (28) | 51 (17) |
| Opponent | Fragile | 5 | 0 (5) | 0 | 0 | 0 | 40% | 2.7 | - | 0 (4) | 0 (1) | 0 (4) | 0 (1) |
| Opponent | Hammer | 69 | 40 (69) | 32 | 8 | 47 | 22% | 3.0 | 36 (19) | 40 (37) | 47 (13) | 45 (40) | 34 (29) |
| Opponent | Holder | 33 | 79 (33) | 17 | 61 | 8 | 36% | 3.2 | 31 (4) | 91 (22) | 58 (7) | 83 (19) | 73 (14) |
| Opponent | Shooter | 35 | 79 (35) | 10 | 69 | 36 | 0% | 1.9 | 20 (11) | 127 (17) | 36 (7) | 115 (23) | 24 (12) |
| Opponent | Support | 3 | 7 (3) | 7 | 0 | 0 | 0% | 5.3 | 0 (1) | 30 (1) | 0 (1) | - | 7 (3) |
| Opponent | War machine | 24 | 97 (24) | 97 | 0 | 28 | 4% | 2.0 | 35 (6) | 135 (15) | 30 (3) | 0 (2) | 106 (22) |
| Opponent | Wizard | 29 | 27 (29) | 22 | 5 | 40 | 3% | 1.5 | 17 (14) | 49 (9) | 0 (5) | 30 (14) | 27 (14) |

### Charged fights: bg-on-789c37f-p2

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 33 | 318 | 1.8 | 1.0 | 181 | 0 | +181 | 2 of 7 | 5 of 7 | - | +181 |
| Mine | Chaos Dwarfs | 4 | 353 | 255 | 3.5 | 1.0 | 73 | 22 | +51 | 8 of 14 | 13 of 14 | - | +51 |
| Mine | Dwarfen Mountain Holds | 4 | 712 | 34 | 0.8 | 1.0 | 46 | 0 | +46 | 2 of 3 | 2 of 3 | - | +46 |
| Mine | Empire of Man | 5 | 263 | 50 | 1.2 | 1.0 | 42 | 204 | -162 | 4 of 6 | 0 of 6 | - | -162 |
| Mine | Grand Cathay | 4 | 202 | 475 | 3.5 | 1.1 | 136 | 0 | +136 | 4 of 14 | 14 of 14 | +125 | +137 |
| Mine | High Elf Realms | 4 | 168 | 589 | 3.5 | 1.5 | 168 | 10 | +158 | 7 of 14 | 11 of 14 | +233 | +83 |
| Mine | Kingdom of Bretonnia | 1 | 30 | 1129 | 3.0 | 1.0 | 376 | 132 | +244 | 2 of 3 | 1 of 3 | - | +244 |
| Mine | Lizardmen | 1 | 45 | 436 | 4.0 | 1.5 | 109 | 0 | +109 | 0 of 4 | 2 of 4 | +218 | +0 |
| Mine | Ogre Kingdoms | 1 | 0 | 0 | 3.0 | 1.0 | 0 | 11 | -11 | 1 of 3 | 2 of 3 | - | -11 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 911 | 5.0 | 1.4 | 182 | 74 | +108 | 2 of 5 | 4 of 5 | -55 | +149 |
| Mine | Skaven | 2 | 174 | 0 | 0.5 | 1.0 | 0 | 112 | -112 | 0 of 1 | 0 of 1 | - | -112 |
| Mine | Tomb Kings of Khemri | 1 | 114 | 697 | 7.0 | 1.0 | 100 | 73 | +27 | 3 of 7 | 4 of 7 | - | +27 |
| Mine | Vampire Counts | 3 | 0 | 436 | 6.3 | 1.0 | 69 | 50 | +19 | 4 of 19 | 15 of 19 | - | +19 |
| Mine | Warriors of Chaos | 1 | 19 | 608 | 1.0 | 1.0 | 608 | 0 | +608 | 0 of 1 | 0 of 1 | - | +608 |
| **Mine** | all armies | 36 | 215 | 334 | 2.8 | 1.1 | 119 | 40 | +79 | 39 of 101 | 73 of 101 | +194 | +65 |
| Opponent | Dwarfen Mountain Holds | 2 | 270 | 32 | 1.0 | 2.0 | 32 | 0 | +32 | 1 of 2 | 1 of 2 | +32 | - |
| Opponent | Empire of Man | 2 | 927 | 110 | 1.0 | 1.0 | 110 | 0 | +110 | 0 of 2 | 2 of 2 | - | +110 |
| Opponent | Grand Cathay | 2 | 454 | 378 | 4.5 | 1.3 | 84 | 0 | +84 | 6 of 9 | 6 of 9 | +178 | +57 |
| Opponent | Kingdom of Bretonnia | 1 | 225 | 225 | 3.0 | 1.3 | 75 | 92 | -17 | 1 of 3 | 2 of 3 | -277 | +112 |
| Opponent | Ogre Kingdoms | 3 | 340 | 290 | 3.3 | 1.1 | 87 | 21 | +66 | 4 of 10 | 4 of 10 | -34 | +77 |
| Opponent | Skaven | 1 | 0 | 125 | 2.0 | 1.0 | 62 | 0 | +62 | 0 of 2 | 2 of 2 | - | +62 |
| Opponent | Tomb Kings of Khemri | 4 | 38 | 1235 | 5.0 | 1.1 | 247 | 66 | +181 | 9 of 20 | 11 of 20 | +396 | +143 |
| Opponent | Vampire Counts | 6 | 36 | 755 | 4.3 | 1.2 | 174 | 25 | +150 | 12 of 26 | 16 of 26 | +131 | +153 |
| Opponent | Warriors of Chaos | 8 | 8 | 560 | 3.9 | 1.1 | 144 | 30 | +115 | 17 of 31 | 22 of 31 | +232 | +102 |
| Opponent | Wood Elf Realms | 7 | 91 | 522 | 4.9 | 1.2 | 107 | 21 | +86 | 8 of 34 | 20 of 34 | +288 | +51 |
| **Opponent** | all armies | 36 | 156 | 552 | 3.9 | 1.2 | 143 | 30 | +113 | 58 of 139 | 86 of 139 | +188 | +100 |

### Effective charges: bg-on-789c37f-p2

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 7 | 0 | 0 | 0 | 1 (net +0) | 1 (net +278) | 4 (net +189) | 1 | 0% (0 of 6) |
| Mine | Chaos Dwarfs | 14 | 1 (net +217) | 1 (net -309) | 1 (net +0) | 1 (net +0) | 2 (net +30) | 7 (net +106) | 1 | 8% (1 of 13) |
| Mine | Dwarfen Mountain Holds | 3 | 1 (net +0) | 0 | 0 | 0 | 0 | 2 (net +68) | 0 | 0% (0 of 3) |
| Mine | Empire of Man | 6 | 0 | 0 | 2 (net -28) | 1 (net -189) | 1 (net -350) | 2 (net -190) | 0 | 33% (2 of 6) |
| Mine | Grand Cathay | 14 | 0 | 0 | 2 (net +444) | 2 (net +106) | 3 (net +42) | 7 (net +97) | 0 | 14% (2 of 14) |
| Mine | High Elf Realms | 14 | 0 | 0 | 1 (net +0) | 2 (net +58) | 4 (net +303) | 6 (net +171) | 1 | 8% (1 of 13) |
| Mine | Kingdom of Bretonnia | 3 | 0 | 0 | 1 (net +0) | 1 (net +635) | 0 | 1 (net +98) | 0 | 33% (1 of 3) |
| Mine | Lizardmen | 4 | 2 (net +0) | 0 | 0 | 1 (net +186) | 1 (net +250) | 0 | 0 | 0% (0 of 4) |
| Mine | Ogre Kingdoms | 3 | 0 | 0 | 0 | 0 | 0 | 1 (net +0) | 2 | 0% (0 of 1) |
| Mine | Orc & Goblin Tribes | 5 | 1 (net +250) | 0 | 0 | 0 | 0 | 0 | 4 | 0% (0 of 1) |
| Mine | Skaven | 1 | 0 | 0 | 0 | 1 (net -112) | 0 | 0 | 0 | 0% (0 of 1) |
| Mine | Tomb Kings of Khemri | 7 | 0 | 0 | 2 (net -256) | 1 (net +125) | 0 | 3 (net +191) | 1 | 33% (2 of 6) |
| Mine | Vampire Counts | 19 | 6 (net -124) | 0 | 1 (net +0) | 5 (net +136) | 2 (net +118) | 4 (net +48) | 1 | 6% (1 of 18) |
| Mine | Warriors of Chaos | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +608) | 0 | 0% (0 of 1) |
| Opponent | Dwarfen Mountain Holds | 2 | 0 | 1 (net +0) | 0 | 0 | 0 | 1 (net +65) | 0 | 0% (0 of 2) |
| Opponent | Empire of Man | 2 | 0 | 0 | 0 | 1 (net +110) | 0 | 1 (net +110) | 0 | 0% (0 of 2) |
| Opponent | Grand Cathay | 9 | 4 (net +0) | 0 | 0 | 4 (net +189) | 0 | 1 (net +0) | 0 | 0% (0 of 9) |
| Opponent | Kingdom of Bretonnia | 3 | 0 | 1 (net +105) | 1 (net +120) | 1 (net -277) | 0 | 0 | 0 | 33% (1 of 3) |
| Opponent | Ogre Kingdoms | 10 | 2 (net +82) | 0 | 0 | 1 (net +170) | 0 | 2 (net +184) | 5 | 0% (0 of 5) |
| Opponent | Skaven | 2 | 0 | 0 | 0 | 0 | 1 (net +125) | 1 (net +0) | 0 | 0% (0 of 2) |
| Opponent | Tomb Kings of Khemri | 20 | 3 (net +214) | 0 | 3 (net +269) | 5 (net +39) | 1 (net +85) | 6 (net +242) | 2 | 17% (3 of 18) |
| Opponent | Vampire Counts | 26 | 3 (net +338) | 1 (net +0) | 3 (net +249) | 2 (net -134) | 5 (net +84) | 11 (net +179) | 1 | 12% (3 of 25) |
| Opponent | Warriors of Chaos | 31 | 2 (net -205) | 0 | 3 (net +239) | 5 (net +79) | 2 (net +30) | 17 (net +152) | 2 | 10% (3 of 29) |
| Opponent | Wood Elf Realms | 34 | 3 (net -44) | 0 | 3 (net +99) | 12 (net +77) | 2 (net +535) | 11 (net +23) | 3 | 10% (3 of 31) |

### Charged fights, damage counted: bg-on-789c37f-p2

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 11 | 147 | 201 | -25 | 62 | 81 | -19 | -12.9 |
| Mine | 50-54% | 1 | 120 | 480 | -309 | 0 | 309 | -309 | -257.5 |
| Mine | Effective (55-75%) | 10 | 347 | 332 | +32 | 116 | 90 | +27 | +7.7 |
| Mine | 76-89% | 16 | 257 | 173 | +103 | 124 | 34 | +90 | +35.0 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 38 | 245 | 182 | +117 | 168 | 42 | +126 | +51.4 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 14 | 562 | 107 | +129 | 165 | 47 | +118 | +21.0 |
| Mine | No odds | 11 | 228 | 222 | +32 | 145 | 77 | +67 | +29.4 |
| Mine | All fights | 101 | 287 | 195 | +79 | 140 | 57 | +83 | +28.8 |
| Opponent | Long shot (under 50%) | 17 | 239 | 279 | +75 | 167 | 63 | +104 | +43.5 |
| Opponent | 50-54% | 3 | 190 | 202 | +35 | 60 | 10 | +50 | +26.3 |
| Opponent | Effective (55-75%) | 13 | 328 | 199 | +207 | 212 | 28 | +184 | +55.9 |
| Opponent | 76-89% | 31 | 275 | 177 | +65 | 114 | 44 | +70 | +25.3 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 51 | 305 | 217 | +134 | 197 | 59 | +138 | +45.0 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 11 | 523 | 125 | +160 | 174 | 3 | +171 | +32.8 |
| Opponent | No odds | 13 | 209 | 172 | +85 | 113 | 47 | +66 | +31.6 |
| Opponent | All fights | 139 | 298 | 202 | +113 | 163 | 47 | +117 | +39.1 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| bg-on-789c37f-p2 | move | 482 | 111 (23%) | 81 (17%) | 61 (13%) | 310 (64%) |
| bg-on-789c37f-p2 | objective | 386 | 59 (15%) | 46 (12%) | 56 (15%) | 271 (70%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0106, L0122, L2429, L2535, L2735 |
| Charmed Shield | Opponent | L0425, L0827, L0934, L1026, L1727, L1827, L1927 |
| Clockwork Compass | Mine | L1228 |
| Clockwork Compass | Opponent | L0512 |
| Elixir of Power | Mine | L1118, L1135, L1927 |
| Fistful of Laurels | Mine | L1827 |
| Fistful of Laurels | Opponent | L0918, L1118, L1418 |
| Horn of the Wild Hunt | Opponent | L3033 |
| Invocation of Nehek | Mine | L2429, L2535, L2735 |
| Invocation of Nehek | Opponent | L0425, L0827, L1727, L1827, L1927 |
| Opal Amulet | Mine | L1418, L1435 |
| Periapt of Soul Exchange | Mine | L2029, L2131 |
| Periapt of Soul Exchange | Opponent | L0721 |
| Ring of Doom | Mine | L0206, L0222, L1118, L1135, L1228, L1531 |
| Ring of Doom | Opponent | L0512, L1531, L2131, L3033 |
| Ring of Jet | Mine | L1026, L1118, L1135, L1228 |
| Ring of Jet | Opponent | L0512, L0810 |
| Standard of the Fell Warrior | Mine | L1323 |
| Storm Daemon (Renegade 2.0) | Mine | L2131 |
| Storm Daemon (Renegade 2.0) | Opponent | L0721 |
| Twice-Blessed Armour | Mine | L0721, L1026 |
| Twice-Blessed Armour | Opponent | L0307, L0810 |
| Witch Hunter's Ward | Mine | L0721, L0810, L0827 |
| Witch Hunter's Ward | Opponent | L0307 |

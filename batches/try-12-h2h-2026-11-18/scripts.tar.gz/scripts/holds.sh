#!/bin/bash
# Hold claims v scored, new and simpler, split by side: mine-* parts have new = Mine, opp-* parts new = Opponent
for a in mine opp; do echo "== parts $a-* (new = $([ $a = mine ] && echo Mine || echo Opponent))"; timeout 300 python3 -I ~/s12/joint/job_claims3.py ~/t12/$a-*/* 2>/dev/null | grep "^| Hold a marker"; done

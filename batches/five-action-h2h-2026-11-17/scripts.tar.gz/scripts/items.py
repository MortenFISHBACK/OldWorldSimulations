from common import *
import statistics as st
TAGS=["JOINT KNOWS CHALLENGE","REFUSING RETIRES","BLOWS WHERE AIMED","SPELLS IN THE FIGHT","CHARGER SLAIN LOST","WIDER SPREAD"]
C=collections.defaultdict(collections.Counter); V=collections.defaultdict(list); PR=collections.defaultdict(lambda:collections.defaultdict(list))
N=collections.Counter()
for arm,pair,f in games():
  acts=[d for d in load(f) if d.get('kind')=='action' and d.get('type')=='OpponentRule']
  N['games']+=1
  pend=[]  # (tag, brain, side, actor, desc, turn, figure, changed)
  for d in acts:
    s=d['summary'] or ''; b=brain(arm,d['side'])
    m=re.match(r'PLAN RESULT: [^:]+: happened=(\w+) won=(-?[\d.]+) planned=(-?[\d.]+) kind=([a-z ]+): (.*?)(?: \(|$)',s)
    if m:
      hap,won,pl,kind,desc=m.group(1)=='yes',float(m.group(2)),float(m.group(3)),m.group(4),m.group(5).strip()
      PR[b][kind].append((hap,won,pl))
      for x in pend:
        if x['done'] or x['actor']!=d['actor'] or x['side']!=d['side'] or x['turn']>=d['turn']: continue
        if desc and x['desc'].startswith(desc[:40]):
          x['done']=True; x['hap']=hap; x['won']=won; x['pl']=pl
      continue
    for t in TAGS:
      if s.startswith(t+':'):
        m=re.match(re.escape(t)+r': ([+-]?[\d.]+) VP: (.*?)(?: \| (CHANGED|SAME)|$)',s)
        fig=float(m.group(1)) if m else 0; desc=(m.group(2) if m else '').split(': ')[0]; ch=(m.group(3) if m else None)
        C[(b,t)]['rows']+=1; C[(b,t)]['changed']+= ch=='CHANGED'
        V[(b,t)].append(fig)
        pend.append(dict(tag=t,brain=b,side=d['side'],actor=d['actor'],desc=desc,turn=d['turn'],fig=fig,ch=ch,done=False))
  for x in pend:
    k=(x['brain'],x['tag']); 
    if x['done']:
      C[k]['followed']+=1; C[k]['hap']+=x['hap']; C[k]['won']+=x['won']; C[k]['pl']+=x['pl']
      if x['ch']=='CHANGED': C[k]['chf']+=1; C[k]['chhap']+=x['hap']; C[k]['chwon']+=x['won']; C[k]['chpl']+=x['pl']
n=N['games']
print('games',n)
print('| Item | Rows a game (changes side) | Changed the choice a game | Rows on the main side a game | Jobs followed up | Happened | Planned VP a job | Won VP a job | Changed jobs: happened, planned v won |')
print('|'+' --- |'*9)
for t in TAGS:
  c=C[('fix',t)]; o=C[('off',t)]
  f=c['followed']
  print(f"| {t} | {c['rows']/n:.2f} | {c['changed']/n:.2f} | {o['rows']/n:.2f} | {f} | {c['hap']/f if f else 0:.0%} | {c['pl']/f if f else 0:.1f} | {c['won']/f if f else 0:.1f} | " + (f"{c['chhap']/c['chf']:.0%} of {c['chf']}, {c['chpl']/c['chf']:.1f} v {c['chwon']/c['chf']:.1f}" if c['chf'] else '-')+" |")
print()
print('| Job kind | Changes: jobs, happened, planned v won a job | Main: jobs, happened, planned v won a job |'); print('| --- | --- | --- |')
for k in sorted(set(PR['fix'])|set(PR['off'])):
  def s(L): return f"{len(L)}, {sum(h for h,_,_ in L)/len(L):.0%}, {st.mean(p for _,_,p in L):.1f} v {st.mean(w for _,w,_ in L):.1f}" if L else '-'
  print(f"| {k} | {s(PR['fix'][k])} | {s(PR['off'][k])} |")

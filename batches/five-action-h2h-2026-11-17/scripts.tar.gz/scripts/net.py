import sys,os,json,importlib.util
from common import *
spec=importlib.util.spec_from_file_location("cb", os.path.expanduser("~/an/cb.py")); cb=importlib.util.module_from_spec(spec); spec.loader.exec_module(cb)
out={}
for arm in ARMS:
  for d in part_dirs(arm):
    for k,v in cb.charged_fights(d).items():
      for f in v["fights"]:
        key=f"{arm}|{f[12]}|{f[13]}|{f[14]}|{f[15]}"
        if key in out: continue
        out[key]=dict(n=f[0],won=f[1],lost=f[2],top3=f[3],fr=f[4],odds=f[5],overkill=f[6],won_d=f[7],lost_d=f[8],cp=f[9],tp=f[10],redirect=f[11])
    print(d,len(out),file=sys.stderr)
json.dump(out,open(os.path.expanduser('~/an/out/net.json'),'w'))

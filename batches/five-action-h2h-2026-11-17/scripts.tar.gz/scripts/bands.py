import json,collections,math,os
O=os.path.expanduser('~/an/out')
F=json.load(open(O+'/fights.json')); N=json.load(open(O+'/net.json'))
for x in F:
  x['net']=N.get(f"{x['arm']}|{x['game']}|{x['side']}|{x['turn']}|{x['target']}")
F=[x for x in F if x['odds'] is not None and x['res']!='none']
def plain(x):
  return (not x['their_chars'] and not x['chall_issued'] and not x['retired'] and not x['chall_acc'] and x['spells_enemy']==0
          and x['spellw_enemy']==0 and len(x['their_units'])<=1 and x.get('army')!=x.get('enemy_army'))
B=[('below 50',0,50),('50-59',50,60),('60-75',60,76),('76-89',76,90),('90-94',90,95),('95-100',95,101)]
def bandof(o):
  for n,lo,hi in B:
    if lo<=o<hi: return n
def ci(k,n):
  if n==0: return 0
  p=k/n; return 1.96*math.sqrt(p*(1-p)/n)*100
def cal(title,sel):
  print(f"\n### {title}\n\n| Odds band | Fixes on: fights | said | won | drawn | lost | Fixes off: fights | said | won | drawn | lost |\n|---|---|---|---|---|---|---|---|---|---|---|")
  for n,lo,hi in B+[('95-100 (99%+ only)',99,101),('all 90+',90,101)]:
    cells=[]
    for b in ('fix','off'):
      v=[x for x in F if x['brain']==b and sel(x) and lo<=x['odds']<hi]; k=len(v)
      if k==0: cells+=['0','-','-','-','-']; continue
      w=sum(x['res']=='win' for x in v)
      cells+=[str(k),f"{sum(x['odds'] for x in v)/k:.0f}%",f"{w/k*100:.0f}% ±{ci(w,k):.0f}",f"{sum(x['res']=='draw' for x in v)/k*100:.0f}%",f"{sum(x['res']=='loss' for x in v)/k*100:.0f}%"]
    print(f"| {n} | "+" | ".join(cells)+" |")
cal('All figured fights',lambda x:True)
cal('Plain fights (no joined enemy character, no challenge, no enemy spell, one enemy unit, not a mirror match)',plain)
cal('Fights with joined characters, challenges or combat spells (everything else)',lambda x:not plain(x))
# gap: mean said - won per side and set, 60%+
print("\n### Too sure, in points (said minus won), fights at 60%+\n\n| Set | Fixes on | Fixes off |\n|---|---|---|")
for t,sel in (('All',lambda x:True),('Plain',plain),('Other',lambda x:not plain(x))):
  r=[]
  for b in ('fix','off'):
    v=[x for x in F if x['brain']==b and sel(x) and x['odds']>=60]
    r.append(f"{sum(x['odds'] for x in v)/len(v)-100*sum(x['res']=='win' for x in v)/len(v):+.1f} ({len(v)} fights)" if v else '-')
  print(f"| {t} | {r[0]} | {r[1]} |")
# net per 100 charger points by band (review's bands)
def nb(x):
  o=x['odds']
  if o<50: return '1 below 50%'
  if o<60: return '2 50-59%'
  if o<76: return '3 60-75%'
  if o<90: return '4 76-89%'
  return '6 90%+ overkill' if x['net']['overkill'] else '5 90%+ not overkill'
def nbr(x):
  o=x['odds']
  if o<76: return nb(x)
  n=x['net']; ok=(not n['redirect'] and 0<n['tp']<250 and n['cp']>3*n['tp'])
  return '7 76%+ overkill' if ok else '8 76%+ not overkill'
def nettab(title,key,sel=lambda x:True):
  print(f"\n### {title}\n\n| Band | Side | Fights | Said | First round won | Chargers' points | Target's points | Net a fight | Net per 100 charger points |\n|---|---|---|---|---|---|---|---|---|")
  G=collections.defaultdict(list)
  for x in F:
    if x['net'] and sel(x): G[(key(x),x['brain'])].append(x)
  for k in sorted(G):
    v=G[k]; n=len(v); cp=sum(x['net']['cp'] for x in v); nd=[x['net']['won_d']-x['net']['lost_d'] for x in v]
    mean=sum(nd)/n; sd=math.sqrt(sum((d-mean)**2 for d in nd)/max(1,n-1)); se=1.96*sd/math.sqrt(n)/(cp/n)*100 if cp else 0
    print(f"| {k[0][2:]} | {'fixes on' if k[1]=='fix' else 'fixes off'} | {n} | {sum(x['odds'] for x in v)/n:.0f}% | {sum(x['res']=='win' for x in v)/n*100:.0f}% | {cp/n:.0f} | {sum(x['net']['tp'] for x in v)/n:.0f} | {mean:+.0f} | {100*sum(nd)/cp:+.0f} ±{se:.0f} |")
nettab('Net points per 100 charger points, by band (review bands)',nb)
nettab('The proposed rule: 76%+ split by overkill',nbr)
print("\nfights",len(F),collections.Counter(x['brain'] for x in F),"with net",sum(1 for x in F if x['net']))

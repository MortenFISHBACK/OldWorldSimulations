# Doctrine scorecard: fa-h2h-mine-8a94331-p4

### Scorecard: fa-h2h-mine-8a94331-p4

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0114 | 6 | 1 | Mine | no | 8 | 6 | 1 | 1 | 0 | 0 | 0 | 0 |
| L0114 | 6 | 1 | Opponent | no | 1 | 3 | 5 | 1 | 0 | 0 | 0 | 177 |
| L0130 | 4 | 1 | Mine | no | 4 | - | 0 | 3 | 0 | 0 | 0 | 0 |
| L0130 | 4 | 1 | Opponent | no | 2 | 4 | 2 | 4 | 0 | 0 | 0 | 0 |
| L0214 | 4 | 1 | Mine | no | 0 | - | 1 | 3 | 1 | 0 | 0 | 170 |
| L0214 | 4 | 1 | Opponent | no | 0 | 2 | 5 | 0 | 1 | 0 | 0 | 0 |
| L0230 | 2 | 1 | Mine | - | - | - | 5 | 5 | 1 | 0 | 0 | 170 |
| L0230 | 2 | 1 | Opponent | - | - | - | 0 | 2 | 0 | 0 | 0 | 0 |
| L0315 | 3 | 1 | Mine | no | 0 | 2 | 3 | 0 | 0 | 0 | 0 | 110 |
| L0315 | 3 | 1 | Opponent | yes | 24 | 2 | 4 | 0 | 0 | 0 | 0 | 0 |
| L0332 | 2 | 1 | Mine | - | - | 5 | 2 | 0 | 0 | 0 | 0 | 480 |
| L0332 | 2 | 1 | Opponent | - | - | 2 | 2 | 4 | 0 | 0 | 0 | 170 |
| L0417 | 3 | 1 | Mine | no | 0 | 2 | 4 | 2 | 1 | 0 | 0 | 0 |
| L0417 | 3 | 1 | Opponent | yes | 8 | 3 | 1 | 0 | 0 | 0 | 0 | 0 |
| L0434 | 2 | 1 | Mine | - | - | 2 | 0 | 2 | 0 | 0 | 0 | 0 |
| L0434 | 2 | 1 | Opponent | - | - | 2 | 5 | 2 | 0 | 0 | 0 | 107 |
| L0520 | 4 | 1 | Mine | no | 0 | 4 | 0 | 0 | 0 | 0 | 0 | 1560 |
| L0520 | 4 | 1 | Opponent | no | 5 | 3 | 1 | 5 | 1 | 0 | 0 | 210 |
| L0608 | 2 | 1 | Mine | - | - | - | 0 | 2 | 0 | 0 | 0 | 175 |
| L0608 | 2 | 1 | Opponent | - | - | - | 0 | 4 | 0 | 0 | 0 | 605 |
| L0624 | 6 | 1 | Mine | no | 1 | 2 | 2 | 0 | 0 | 0 | 0 | 484 |
| L0624 | 6 | 1 | Opponent | no | 8 | 3 | 3 | 0 | 0 | 0 | 0 | 0 |
| L0713 | 5 | 1 | Mine | no | - | 3 | 1 | 3 | 0 | 0 | 0 | 125 |
| L0713 | 5 | 1 | Opponent | yes | - | 3 | 2 | 3 | 0 | 0 | 0 | 317 |
| L0729 | 3 | 1 | Mine | no | 0 | 3 | 3 | 0 | 0 | 0 | 0 | 375 |
| L0729 | 3 | 1 | Opponent | no | 0 | 2 | 3 | 1 | 1 | 0 | 0 | 170 |
| L0819 | 3 | 1 | Mine | no | 0 | 3 | 1 | 1 | 0 | 0 | 0 | 415 |
| L0819 | 3 | 1 | Opponent | no | 0 | 2 | 0 | 3 | 0 | 0 | 0 | 543 |
| L0835 | 1 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 350 |
| L0835 | 1 | 1 | Opponent | no | 0 | 4 | 1 | 4 | 0 | 0 | 0 | 0 |
| L0926 | 2 | 1 | Mine | - | - | - | 0 | 1 | 0 | 0 | 0 | 479 |
| L0926 | 2 | 1 | Opponent | - | - | 2 | 6 | 5 | 0 | 0 | 0 | 0 |
| L1017 | 3 | 1 | Mine | no | 0 | 5 | 1 | 1 | 1 | 0 | 0 | 165 |
| L1017 | 3 | 1 | Opponent | yes | 19 | 2 | 6 | 2 | 1 | 0 | 0 | 175 |
| L1034 | 2 | 1 | Mine | - | - | 2 | 0 | 1 | 0 | 0 | 0 | 0 |
| L1034 | 2 | 1 | Opponent | - | - | 2 | 3 | 3 | 0 | 0 | 0 | 83 |
| L1126 | 4 | 1 | Mine | no | 0 | 3 | 2 | 1 | 0 | 0 | 0 | 330 |
| L1126 | 4 | 1 | Opponent | no | 1 | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L1220 | 2 | 1 | Mine | - | - | 4 | 3 | 0 | 0 | 0 | 0 | 330 |
| L1220 | 2 | 1 | Opponent | - | - | - | 2 | 4 | 1 | 0 | 0 | 420 |
| L1314 | 6 | 1 | Mine | no | 1 | 4 | 2 | 1 | 0 | 0 | 0 | 140 |
| L1314 | 6 | 1 | Opponent | no | 6 | 2 | 4 | 2 | 0 | 0 | 0 | 274 |
| L1331 | 5 | 1 | Mine | yes | - | 6 | 2 | 3 | 0 | 0 | 0 | 0 |
| L1331 | 5 | 1 | Opponent | yes | - | 6 | 0 | 1 | 1 | 0 | 0 | 170 |
| L1427 | 5 | 1 | Mine | yes | - | 4 | 1 | 3 | 0 | 0 | 0 | 0 |
| L1427 | 5 | 1 | Opponent | yes | - | 2 | 2 | 4 | 0 | 0 | 0 | 0 |
| L1523 | 5 | 1 | Mine | no | - | 1 | 5 | 0 | 1 | 0 | 0 | 0 |
| L1523 | 5 | 1 | Opponent | yes | - | 2 | 8 | 2 | 1 | 0 | 0 | 66 |
| L1621 | 1 | 1 | Mine | no | 2 | 2 | 1 | 1 | 0 | 0 | 0 | 0 |
| L1621 | 1 | 1 | Opponent | no | 0 | - | 2 | 5 | 0 | 0 | 0 | 410 |
| L1719 | 3 | 1 | Mine | no | 5 | 2 | 5 | 0 | 0 | 0 | 0 | 0 |
| L1719 | 3 | 1 | Opponent | yes | 3 | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| L1819 | 1 | 1 | Mine | no | 2 | 4 | 3 | 0 | 1 | 0 | 0 | 77 |
| L1819 | 1 | 1 | Opponent | no | 3 | 2 | 7 | 1 | 0 | 0 | 0 | 0 |
| L1835 | 5 | 1 | Mine | no | - | - | 4 | 1 | 0 | 0 | 0 | 262 |
| L1835 | 5 | 1 | Opponent | yes | - | 2 | 2 | 4 | 0 | 0 | 0 | 110 |
| L2021 | 5 | 1 | Mine | yes | - | - | 0 | 3 | 0 | 0 | 0 | 35 |
| L2021 | 5 | 1 | Opponent | yes | - | - | 2 | 5 | 0 | 0 | 0 | 145 |
| L2123 | 5 | 1 | Mine | yes | - | - | 1 | 6 | 0 | 0 | 0 | 500 |
| L2123 | 5 | 1 | Opponent | yes | - | 2 | 5 | 1 | 1 | 0 | 0 | 0 |
| L2227 | 1 | 1 | Mine | yes | 1 | 3 | 4 | 1 | 0 | 0 | 0 | 170 |
| L2227 | 1 | 1 | Opponent | no | 0 | 2 | 3 | 4 | 0 | 0 | 0 | 0 |
| L2331 | 3 | 1 | Mine | no | 0 | 4 | 3 | 3 | 0 | 0 | 0 | 251 |
| L2331 | 3 | 1 | Opponent | yes | 4 | - | 2 | 0 | 3 | 0 | 0 | 170 |
| L2527 | 1 | 1 | Mine | no | 0 | 3 | 1 | 3 | 0 | 0 | 0 | 0 |
| L2527 | 1 | 1 | Opponent | no | 0 | 1 | 3 | 2 | 0 | 0 | 0 | 0 |
| L2634 | 6 | 1 | Mine | no | 7 | 2 | 2 | 3 | 0 | 0 | 0 | 0 |
| L2634 | 6 | 1 | Opponent | no | 12 | 2 | 0 | 3 | 0 | 0 | 0 | 0 |
| L2930 | 2 | 1 | Mine | - | - | 2 | 4 | 0 | 0 | 0 | 0 | 0 |
| L2930 | 2 | 1 | Opponent | - | - | 2 | 4 | 3 | 0 | 0 | 0 | 0 |
| L3234 | 6 | 1 | Mine | no | 1 | 5 | 1 | 1 | 0 | 0 | 0 | 0 |
| L3234 | 6 | 1 | Opponent | no | 0 | 2 | 5 | 3 | 0 | 0 | 0 | 56 |
| **Average** | | | Mine | 18% | 1.5 | 3.3 | 1.9 | 1.6 | 0.2 | 0.0 | 0.0 | 198.7 |
| **Average** | | | Opponent | 43% | 4.6 | 2.4 | 2.9 | 2.5 | 0.3 | 0.0 | 0.0 | 121.6 |

### KPIs: fa-h2h-mine-8a94331-p4

Rules off - Opponent only: FIVE ACTION, LIKELY CHARGE, FALLS SHORT, TIME ON OUR SIDE, FEATURE BUFFS, GETS AWAY CHANCE, GUN MASK, RUN DOWN, FOUR ROUNDS, CHARGE LOSSES, CHARACTER GUNS, STAND AND SHOOT, FALL BACK GOOD ORDER, AFTERMATH IN POINTS.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 23% (41 of 176) | 2% (4 of 174) | 13% (45 of 350) |
| Winner chose to follow up after the loser gave ground |  | 84% (37 of 44); on the table 86% | 100% (42 of 42); on the table 100% | 92% (79 of 86); on the table 93% |
| Winner chose to pursue after the loser fell back in good order |  | 86% (6 of 7); on the table 100% | 77% (10 of 13); on the table 77% | 80% (16 of 20); on the table 85% |
| Winner chose to pursue after the loser fled |  | 71% (12 of 17); on the table 88% | 79% (26 of 33); on the table 85% | 76% (38 of 50); on the table 86% |
| Winner chose to follow up or pursue (all three) |  | 81% (55 of 68); on the table 88% | 89% (78 of 88); on the table 91% | 85% (133 of 156); on the table 90% |
| Magic missiles tried each own turn | 50%+ | 36% (97 of 266) | 36% (63 of 174) | 36% (160 of 440) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 47% (97 of 208) | 41% (57 of 139) | 44% (154 of 347) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 60% (24 of 40) | 66% (47 of 71) | 64% (71 of 111) |
| Points that never fought | lower | 44% (29560 of 67942) | 44% (31380 of 71984) | 44% (60940 of 139926) |
|   infantry points that never fought | lower | 59% (9045 of 15347) | 65% (8921 of 13804) | 62% (17966 of 29151) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 69% (187 of 270) | 53% (148 of 280) | 61% (335 of 550) |
| Bound items with a magic missile used (at least once a game) |  | 82% (18 of 22); 1.7 uses a game | 89% (8 of 9); 0.8 uses a game | 84% (26 of 31); 1.3 uses a game |
| Bound items with another spell used |  | 31% (5 of 16); 0.2 uses a game | 35% (7 of 20); 0.4 uses a game | 33% (12 of 36); 0.3 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 53% (10 of 19); 0.3 uses a game | 67% (10 of 15); 0.3 uses a game | 59% (20 of 34); 0.3 uses a game |
|   their share of the points of units over 100 pts | lower | 65% (37363 of 57750) | 46% (29161 of 63347) | 55% (66524 of 121097) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.4 (30%) | 1.0 (33%) | 2.4 (31%) |
| MARCHED: its unit marched | 1.5 (33%) | 0.5 (15%) | 2.0 (26%) |
| CHARGED: its unit charged | 0.1 (3%) | 0.4 (14%) | 0.6 (8%) |
| IN COMBAT: engaged in combat | 0.7 (15%) | 0.3 (9%) | 1.0 (13%) |
| REAR RANK: in a rear rank | 0.0 (1%) | 0.3 (11%) | 0.4 (5%) |
| FLEEING: fleeing | 0.0 (1%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | 0.7 (15%) | 0.5 (17%) | 1.2 (16%) |
| OFF THE TABLE: off the table or not arrived | 0.1 (3%) | 0.0 (0%) | 0.1 (2%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.6 | 1.4 | 2.3 | 4.4 | 0.4 | 1.2 |
| not cast | 2.6 | 2.6 | 2.5 | 7.8 | 1.6 | 21.8 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.4 (7%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.5 (58%) | 0.4 (14%) | 2.4 (31%) | 0.4 (25%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.0 (26%) | 0.3 (21%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.6 (8%) | 0.0 (2%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.1 (2%) | 0.1 (2%) | 0.2 (9%) | 1.0 (13%) | 0.3 (18%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.1 (5%) | 0.1 (5%) | 0.3 (12%) | 0.4 (5%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) |
| GONE: slain | 0.6 (21%) | 0.4 (16%) | 0.3 (13%) | 1.2 (16%) | 0.1 (9%) | 2.8 (13%) |
| OFF THE TABLE: off the table or not arrived | 0.1 (2%) | 0.2 (9%) | 0.1 (4%) | 0.1 (2%) | 0.0 (0%) | 0.7 (3%) |
| STUPIDITY: Stupidity | 0.0 (1%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (3%) | 0.1 (5%) | 0.0 (0%) | 0.0 (0%) | 0.4 (26%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.7 (65%) | 0.1 (4%) | 1.2 (47%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 16.8 (77%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.6 a game | 0.8 a game | 1.2 a game |
| stood (cast and not dispelled) | 63% (33 of 52) | 53% (10 of 19) | 61% (43 of 71) |
| the unit moved after it | 79% (26 of 33) | 70% (7 of 10) | 77% (33 of 43) |
| it charged on its next turn | 3% (1 of 33) | 0% (0 of 10) | 2% (1 of 43) |
| the enemy charged it first | 15% (5 of 33) | 0% (0 of 10) | 12% (5 of 43) |
| it fought by the end of its next turn | 15% (5 of 33) | 10% (1 of 10) | 14% (6 of 43) |
| it moved out of a charge the enemy had planned (not charged first) | 27% (9 of 33) | 0% (0 of 10) | 21% (9 of 43) |
| none of these (no charge, no fight, no charge escaped) | 52% (17 of 33) | 90% (9 of 10) | 60% (26 of 43) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 65% (563 of 863) | 59% (319 of 537) | 63% (882 of 1400) |
|   cavalry | 69% (61 of 89) | 78% (83 of 107) | 73% (144 of 196) |
|   character | 52% (53 of 102) | 21% (27 of 128) | 35% (80 of 230) |
|   chariot | 51% (54 of 106) | 78% (18 of 23) | 56% (72 of 129) |
|   infantry | 62% (161 of 259) | 69% (157 of 228) | 65% (318 of 487) |
|   monster | 61% (25 of 41) | 26% (6 of 23) | 48% (31 of 64) |
|   war machine | 79% (209 of 266) | 100% (28 of 28) | 81% (237 of 294) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.7 (20%) | 1.4 (22%) | 3.0 (21%) |
| CHARGED: it charged | 0.8 (10%) | 1.6 (27%) | 2.5 (17%) |
| FLEEING: it fled or was fleeing | 0.1 (2%) | 0.0 (0%) | 0.2 (1%) |
| IN COMBAT: it fought this turn or the last | 0.5 (6%) | 0.2 (4%) | 0.7 (5%) |
| MOVED: a war machine that moved | 1.0 (12%) | 0.0 (0%) | 1.0 (7%) |
| NO TARGET IN RANGE | 2.1 (25%) | 1.4 (22%) | 3.4 (24%) |
| ONLY IN COMBAT: the only targets were in combat | 0.7 (8%) | 0.4 (6%) | 1.0 (7%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.1 (14%) | 1.0 (17%) | 2.1 (15%) |
| SHELTERED: the target was sheltered | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| OTHER BAR | 0.2 (3%) | 0.1 (1%) | 0.3 (2%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 6.2 | 1.9 | 78% | 6.9 pts | 43 pts |
| character | 2.7 | 0.8 | 79% | 7.1 pts | 19 pts |
| chariot | 2.0 | 1.4 | 67% | 16.9 pts | 34 pts |
| infantry | 13.5 | 4.9 | 74% | 10.0 pts | 136 pts |
| monster | 0.9 | 0.1 | 91% | 1.1 pts | 1 pts |
| war machine | 6.6 | 5.5 | 61% | 29.9 pts | 197 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 2.6 | 6.0 | 4.3 |
| Charges that made contact a game | 2.2 | 4.0 | 3.1 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.72 declared, 0.50 contact (18 units) | 0.53 declared, 0.24 contact (17 units) | 0.63 declared, 0.37 contact (35 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.78 declared, 0.67 contact (9 units) | 1.22 declared, 0.89 contact (9 units) | 1.00 declared, 0.78 contact (18 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.29 declared, 0.25 contact (255 units) | 0.66 declared, 0.45 contact (296 units) | 0.49 declared, 0.36 contact (551 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 58% (47 of 81) | 38% (6 of 16) | 83% (5 of 6) | 56% (58 of 103) |
| Character in a unit | 76% (26 of 34) | 84% (16 of 19) | - | 79% (42 of 53) |
| Character on its own | 84% (26 of 31) | 48% (11 of 23) | 29% (23 of 78) | 45% (60 of 132) |
| Chariot | 67% (10 of 15) | 92% (11 of 12) | - | 78% (21 of 27) |
| Infantry | 60% (50 of 83) | 48% (12 of 25) | 67% (4 of 6) | 58% (66 of 114) |
| Monster | 68% (23 of 34) | 86% (12 of 14) | - | 73% (35 of 48) |
| Monstrous | 64% (9 of 14) | 64% (9 of 14) | - | 64% (18 of 28) |
| War Machines | 77% (33 of 43) | 100% (2 of 2) | - | 78% (35 of 45) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 89% (8 of 9); on the table 100% | 37% (38 of 102) | 51% | 64% (14 of 22) | 100% (6 of 6); 4.8 uses a game | 100% (2 of 2); 0.8 uses a game | 67% (4 of 6); 1.0 uses a game |
| Chaos Dwarfs | 4 | 64% (9 of 14); on the table 64% | 71% (17 of 24) | 22% | 78% (25 of 32) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
| Dwarfen Mountain Holds | 3 | 0% (0 of 1); on the table 100% | - | 59% | 63% (17 of 27) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 6 | 0% (0 of 3); on the table 100% | 50% (9 of 18) | 65% | 76% (47 of 62) | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game | 100% (5 of 5); 0.8 uses a game |
| Grand Cathay | 4 | 88% (7 of 8); on the table 88% | 29% (24 of 84) | 46% | 59% (22 of 37) | 89% (8 of 9); 6.0 uses a game | 0% (0 of 2); 0.0 uses a game | 0% (0 of 4); 0.0 uses a game |
| High Elf Realms | 9 | 93% (14 of 15); on the table 93% | 22% (8 of 36) | 43% | 57% (40 of 70) | 86% (6 of 7); 3.3 uses a game | 30% (9 of 30); 1.7 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | 100% (2 of 2); on the table 100% | - | 64% | 50% (3 of 6) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Lizardmen | 3 | 83% (10 of 12); on the table 83% | 100% (6 of 6) | 46% | 57% (12 of 21) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 2 | 100% (2 of 2); on the table 100% | 33% (2 of 6) | 46% | 100% (14 of 14) | 0% (0 of 2); 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 3 | 100% (9 of 9); on the table 100% | 17% (7 of 42) | 19% | 33% (8 of 24) | 0.0 uses a game | 0.0 uses a game | 100% (3 of 3); 1.0 uses a game |
| Skaven | 6 | 82% (9 of 11); on the table 82% | 38% (15 of 39) | 52% | 67% (30 of 45) | 100% (3 of 3); 1.7 uses a game | 0.0 uses a game | 67% (4 of 6); 0.7 uses a game |
| Tomb Kings of Khemri | 4 | 100% (14 of 14); on the table 100% | 17% (1 of 6) | 30% | 35% (7 of 20) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 8 | 88% (23 of 26); on the table 92% | 39% (23 of 59) | 31% | 48% (20 of 42) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 9 | 93% (13 of 14); on the table 93% | 58% (7 of 12) | 38% | 61% (44 of 72) | 100% (2 of 2); 0.7 uses a game | 0.0 uses a game | 100% (3 of 3); 0.3 uses a game |
| Wood Elf Realms | 6 | 81% (13 of 16); on the table 88% | 50% (3 of 6) | 55% | 57% (32 of 56) | 50% (1 of 2); 0.5 uses a game | 0.0 uses a game | 0% (0 of 4); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (fa-h2h-mine-8a94331-p4, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 43% (37) | 48% (31) | 45% (68) |
| ...free all their last turn and able to turn (per game) | 0.69 | 0.42 | 1.11 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.11 | 0.36 | 0.47 |
| ...with the charger already in that arc before they moved (per game) | 0.50 | 0.33 | 0.83 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 1.00 | 1.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.56 | 0.56 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.08 | 6.19 | 6.28 |

### Quality by phase: fa-h2h-mine-8a94331-p4

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.1 | 3.6 |
| Strategy | Charge objectives carried out (made contact) | 58% (55 of 95) | 44% (72 of 165) |
| Strategy | Shoot objectives carried out (shot that target) | 36% (125 of 344) | 36% (75 of 206) |
| Strategy | Close-in objectives charged next turn | - | 15% (40 of 270) |
| Strategy | Support requests answered (helper made contact too) | 50% (4 of 8) | 42% (8 of 19) |
| Strategy | Hexes on a unit its side charged or shot that turn | 33% (2 of 6) | 58% (7 of 12) |
| Strategy | Joined characters whose unit fought | 36% (16 of 45) | 40% (14 of 35) |
| Strategy | Lone characters that fought | 72% (56 of 78) | 67% (54 of 81) |
| Movement | Charges halted short of contact | 0.0 | 0.2 |
| Movement | Idle units | 1.6 | 2.5 |
| Movement | Points that never moved of their own | 198.7 | 121.6 |
| Movement | Fights charged into per game | 2.3 | 3.3 |
| Movement | Charges with odds: long shots (under 50%) | 12 of 76, net +163 | 15 of 106, net -15 |
| Movement | Charges with odds: sweet spot (55-75%) | 11 of 76, net -89 | 18 of 106, net +46 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 4 of 76, net +40 | 16 of 106, net +72 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 22 of 76, net +52 | 24 of 106, net +95 |
| Shooting | Shots by shooting units (incl. breath weapons) | 10.8 | 9.6 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 45% (176 of 389) | 40% (139 of 346) |
| Shooting | Points destroyed by shooting units | 85.9 | 45.1 |
| Shooting | War machine shots | 5.8 | 0.8 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 62% (129 of 209) | 11% (3 of 28) |
| Shooting | Points destroyed by war machines | 82.0 | 12.1 |
| Magic | Magic missiles cast | 1.8 | 1.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 30% (20 of 66) | 21% (10 of 47) |
| Magic | Wounds caused by magic missiles | 3.8 | 1.5 |
| Magic | Wounds caused by other spells | 1.4 | 0.9 |
| Magic | Points destroyed by magic (all spells) | 102.2 | 31.6 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.2 / 0.3 / 0.5 / 0.2 | 2.1 / 0.5 / 0.4 / 0.1 |
| Combat | Points destroyed in combat | 192.6 | 335.3 |
| Combat | Points run down | 85.6 | 113.5 |
| Combat | Net points per charged fight, damage counted | +38 | +86 |
| Combat | Net per 100 charger points, damage counted | +14.3 | +27.7 |
| Combat | First round won (charged fights) | 73% | 79% |
| Combat | Net points per charged fight | +33 | +87 |
| Combat | Net points per supported fight / lone fight | -131 / +41 | +59 / +92 |
| Combat | Charged fights on a top-3 enemy unit | 33 of 82 | 51 of 118 |
| Game | Points lost | 705.2 | 563.4 |
| Game | VP from objectives | 411.4 | 598.9 |
| Game | Lone holders (player turns) | 1.5 | 4.6 |

- Mine won / drew / lost: 9 / 7 / 20 of 36 ended games (of 36); mean margin (Mine - Opponent) -335 VP
- The side that went first won 17 of 29 games with a winner
- Points traded per game (both sides' losses): 1269
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: fa-h2h-mine-8a94331-p4

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 0.8 | +0.0 | 0.0 | 0.0 |
| ADVANCE WORTH | - | - | - | - | 4.1 | -179.1 | 83.4 | 71.7 |
| AFTERMATH IN POINTS | 0.2 | +34.0 | 0.0 | 21.5 | - | - | - | - |
| ALREADY CARRIED | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARTILLERY RE-ROLL WEIGHED | 1.1 | +0.0 | 0.0 | 6.2 | 0.2 | +0.0 | 0.0 | 3.6 |
| BACKUP TARGETS | 0.4 | +2.0 | 0.0 | 7.8 | 0.7 | +4.4 | 0.0 | 25.2 |
| BEST FACING | - | - | - | - | 0.2 | +9.0 | 0.0 | 5.1 |
| BEST FIRST | - | - | - | - | 1.0 | +53.5 | 28.5 | 34.0 |
| BEST OVERALL | - | - | - | - | 0.2 | +10.2 | 0.0 | 5.1 |
| BEST PREY | - | - | - | - | 0.6 | +34.2 | 13.8 | 0.0 |
| BEST PRIZE | 0.0 | -2.2 | 0.0 | 0.0 | 0.1 | -1.9 | 7.8 | 0.0 |
| BIG CHARACTER SAFETY | - | - | - | - | 0.4 | -1.1 | 0.0 | 0.0 |
| BLOCKED CHARGE HANDED OVER | - | - | - | - | 0.0 | +0.4 | 2.4 | 0.0 |
| BLOCKED CHARGE SKIPPED | - | - | - | - | 0.1 | +0.0 | 2.4 | 0.0 |
| BLOCKED WHEEL | - | - | - | - | 0.5 | +13.7 | 0.0 | 0.0 |
| BLOWS WHERE AIMED | 0.2 | -14.6 | 13.9 | 11.8 | 0.1 | -23.4 | 8.7 | 16.4 |
| BOMBING RUN | 0.0 | +0.2 | 0.0 | 0.0 | - | - | - | - |
| BOUND ASSAILMENT | 0.0 | +0.0 | 0.0 | 3.4 | - | - | - | - |
| CANNON PLAN MISSED | 0.5 | +0.0 | 148.2 | 5.6 | 0.1 | +0.0 | 9.4 | 0.0 |
| CANNON PLANNED TARGET | 4.8 | +213.9 | 447.2 | 73.2 | 0.7 | +26.0 | 58.7 | 7.2 |
| CANNON SIGHT KEPT | 1.1 | +0.0 | 0.0 | 7.7 | 0.1 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT COUNTER | 0.0 | +0.0 | 0.0 | 6.6 | - | - | - | - |
| CARRIES OUT SET-UP | - | - | - | - | 0.1 | +0.0 | 6.4 | 0.0 |
| CAST JOB | 0.6 | +18.2 | 36.4 | 15.3 | 0.7 | +17.9 | 28.3 | 7.0 |
| CASTER AWAY FROM SCREEN | 0.3 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.2 | +14.8 | 9.1 | 0.0 | 0.1 | +2.0 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 1.0 | +0.0 | 0.0 | 40.7 | 0.3 | +0.0 | 0.0 | 13.9 |
| CASTS FROM BEHIND | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.0 | +0.5 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | 0.2 | +7.2 | 0.0 | 1.9 | 2.2 | +137.0 | 0.0 | 43.2 |
| CHAFF PASSED | 0.2 | -0.9 | 39.6 | 3.4 | 0.1 | -0.1 | 10.9 | 0.0 |
| CHAMPION TAKES THE CHALLENGE | 0.0 | +0.1 | 0.0 | 0.0 | - | - | - | - |
| CHARACTER GUNS | 0.4 | +0.0 | 0.0 | 5.2 | - | - | - | - |
| CHARGE LOSSES | 11.9 | -322.9 | 0.0 | 391.0 | - | - | - | - |
| CHARGE NOW FIRST | 1.5 | +0.0 | 131.0 | 104.6 | 2.6 | +0.0 | 303.1 | 71.7 |
| CHARGE NOW WEIGHED | - | - | - | - | 0.6 | -36.5 | 10.3 | 40.8 |
| CHARGER SLAIN LOST | 0.2 | -1.9 | 14.8 | 3.1 | 0.8 | -23.9 | 70.4 | 47.8 |
| CHARIOT WIZARD CAREFUL | - | - | - | - | 0.1 | -0.9 | 5.1 | 15.0 |
| CHEAP HELPER | 0.1 | +0.0 | 1.9 | 0.0 | 0.1 | +0.0 | 10.2 | 0.0 |
| COMBAT PIVOT | 0.4 | +0.0 | 17.2 | 24.0 | 0.3 | +0.0 | 3.9 | 14.2 |
| CONVEYANCE SEARCH | 1.1 | +168.8 | 44.0 | 56.9 | 0.4 | +40.4 | 0.0 | 0.0 |
| COVER ONCE | 7.8 | -498.2 | 0.0 | 235.6 | 6.9 | -398.7 | 0.0 | 151.9 |
| DEFENSIVE ARMY | 0.1 | +0.0 | 13.7 | 7.9 | 0.0 | +0.0 | 0.0 | 0.0 |
| DEFENSIVE FLOOR | 0.0 | +0.5 | 0.0 | 0.0 | 0.0 | +0.6 | 0.0 | 1.8 |
| EDGE GIVE GROUND | - | - | - | - | 0.3 | +23.7 | 47.3 | 0.0 |
| ELIXIR WORTH | - | - | - | - | 0.1 | +2.0 | 0.0 | 9.7 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | - | - | - | - | 1.0 | +63.0 | 0.0 | 42.2 |
| FALL BACK GOOD ORDER | 1.7 | +4.0 | 129.9 | 88.7 | - | - | - | - |
| FALLBACK BY WORTH | 0.1 | +0.0 | 0.0 | 0.0 | 6.8 | +48.4 | 0.0 | 71.4 |
| FALLS SHORT | 0.2 | -1.3 | 0.0 | 17.4 | - | - | - | - |
| FEATURE BUFFS | 1.6 | +32.5 | 0.0 | 13.3 | - | - | - | - |
| FIGHT LIFT | 0.0 | +0.1 | 0.0 | 0.0 | - | - | - | - |
| FIRE AND FLEE | 0.0 | +9.0 | 0.0 | 5.6 | - | - | - | - |
| FIVE ACTION | 46.0 | +2461.9 | 999.1 | 953.1 | - | - | - | - |
| FLANK NOT WEIGHED | 5.6 | +0.0 | 0.0 | 198.3 | 5.4 | +0.0 | 0.0 | 120.3 |
| FOLLOW UP WEIGHED | 0.6 | +192.9 | 0.0 | 43.7 | 1.1 | +135.8 | 0.0 | 20.7 |
| FOUR ROUNDS | 2.6 | +169.2 | 198.4 | 114.5 | - | - | - | - |
| FRIENDS SHOTS CHECKED | 0.1 | +1.0 | 0.0 | 4.0 | 0.1 | +6.8 | 0.0 | 0.0 |
| GIVES UP | 0.1 | -1.7 | 10.3 | 0.0 | 0.1 | -0.5 | 10.9 | 0.0 |
| GIVES UP ITS SCREEN | - | - | - | - | 0.0 | -0.2 | 3.4 | 0.0 |
| GROUND FLIERS | 0.1 | +0.9 | 0.0 | 0.0 | 0.0 | +0.2 | 0.0 | 0.0 |
| GUN MASK | 0.7 | +16.5 | 0.0 | 31.1 | - | - | - | - |
| HELPER ALREADY ASKED | - | - | - | - | 0.0 | +0.0 | 0.0 | 4.2 |
| HELPER UNSEEN | 0.2 | +0.0 | 3.3 | 0.0 | 0.4 | +0.0 | 28.6 | 14.7 |
| HILL BY ITS CHANCE | - | - | - | - | 0.4 | -40.4 | 0.0 | 1.9 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 2.2 | -87.4 | 163.5 | 88.9 | 10.4 | -238.1 | 552.8 | 182.4 |
| HUNT ADVANCE | - | - | - | - | 0.2 | +4.3 | 5.8 | 3.2 |
| HUNT DROPPED | - | - | - | - | 0.1 | +0.0 | 3.5 | 3.2 |
| HUNT IN PAIRS | 0.4 | +13.0 | 0.0 | 0.0 | 0.6 | +31.6 | 0.0 | 16.4 |
| HUNT KEPT | - | - | - | - | 0.1 | +0.3 | 4.7 | 0.0 |
| HUNT RESULT | - | - | - | - | 0.2 | +30.3 | 8.1 | 4.4 |
| HUNT THE GUNS | - | - | - | - | 0.2 | +80.3 | 22.9 | 4.4 |
| IDLE COST | 17.5 | -286.7 | 0.0 | 234.9 | 22.3 | -369.2 | 0.0 | 177.8 |
| INVITES THE FIGHT | - | - | - | - | 0.8 | +4.8 | 17.6 | 14.2 |
| JOINT CHARGE PLAN | - | - | - | - | 0.2 | +2.3 | 12.8 | 0.0 |
| JOINT KNOWS CHALLENGE | - | - | - | - | 0.2 | -34.8 | 11.2 | 18.1 |
| KEEP FALLS | 0.1 | +1.8 | 0.0 | 0.0 | 0.0 | +0.5 | 0.0 | 0.0 |
| KEEPS ITS PREY | - | - | - | - | 0.0 | +0.1 | 0.0 | 0.0 |
| KEEPS ITS TARGET | - | - | - | - | 2.4 | +71.7 | 171.2 | 67.3 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KILLS COUNT | 1.3 | +75.6 | 94.2 | 62.3 | 1.8 | +102.4 | 146.7 | 23.9 |
| KILLS COUNT NEXT TURN | - | - | - | - | 7.0 | +242.6 | 275.6 | 129.4 |
| LONE CHARACTER SAFE SPOT | - | - | - | - | 0.2 | +9.0 | 30.0 | 5.0 |
| LONE WIZARD HOLDS BACK | - | - | - | - | 0.2 | +0.0 | 5.5 | 0.0 |
| LONE WIZARD KEPT IN | 0.6 | +26.9 | 0.0 | 0.0 | 0.2 | +20.3 | 0.0 | 0.0 |
| LONG SHOT | 0.2 | +1.0 | 5.9 | 0.0 | 0.5 | +4.5 | 15.7 | 11.2 |
| LOST CHARGE | 0.2 | -0.4 | 12.8 | 4.9 | 1.9 | -24.4 | 62.1 | 61.1 |
| LURE BY WHAT IT DRAWS | 0.0 | -1.5 | 0.0 | 0.0 | 0.2 | -17.4 | 0.0 | 8.8 |
| MAKE SURE TOGETHER | 0.0 | +2.1 | 0.0 | 0.0 | 0.8 | +44.7 | 25.6 | 9.1 |
| MANOEUVRE | 0.8 | +13.0 | 0.0 | 30.1 | 0.2 | +3.2 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.0 | +0.2 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| MARCH CHECK | 0.6 | +30.8 | 0.0 | 10.8 | 0.2 | +2.8 | 0.0 | 5.3 |
| MARCH ODDS | 0.0 | +0.5 | 0.0 | 0.0 | 0.2 | +5.5 | 12.1 | 0.0 |
| MARCH OVER CASTS | 0.6 | +40.8 | 0.0 | 53.8 | 0.3 | +10.7 | 0.0 | 15.0 |
| MAX FOR POSITIONING | 7.1 | +102.5 | 0.0 | 165.8 | 7.0 | +94.1 | 0.0 | 102.0 |
| MISSILES IN THE MOVE | 4.5 | +181.2 | 0.0 | 76.3 | 2.5 | +47.2 | 0.0 | 70.9 |
| MISSILES NEXT TURN | 5.2 | +109.5 | 0.0 | 144.0 | 3.2 | +30.9 | 0.0 | 89.1 |
| MODEL FACING | 0.3 | +56.7 | 0.0 | 5.0 | - | - | - | - |
| MONSTER WIZARD ROAMS | - | - | - | - | 0.2 | +0.0 | 5.2 | 0.0 |
| MOVE AND CAST | - | - | - | - | 0.3 | +10.0 | 0.0 | 22.0 |
| MOVE SPELL IN RANGE | 0.3 | +8.4 | 0.0 | 4.7 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.7 | -49.8 | 16.7 | 23.5 | 0.1 | -5.4 | 0.0 | 0.0 |
| MOVE SPELL SPOT | 0.7 | +0.0 | 0.0 | 18.6 | 0.1 | +0.0 | 0.0 | 13.9 |
| MOVE TO CHARGE | - | - | - | - | 5.6 | +362.3 | 239.9 | 99.4 |
| MOVES UNITS SPELL | 0.1 | +3.3 | 0.0 | 0.0 | 0.1 | +0.6 | 0.0 | 0.0 |
| NEEDED THERE | - | - | - | - | 0.1 | +31.9 | 9.7 | 0.0 |
| NO RALLY LEFT | 0.1 | +0.8 | 0.0 | 1.5 | - | - | - | - |
| NOT NEEDED | - | - | - | - | 0.3 | -18.5 | 52.1 | 0.8 |
| NOT TURNED | 0.1 | -0.0 | 0.0 | 0.0 | 6.2 | +69.1 | 0.0 | 121.8 |
| NOT WORTH A CAST | 0.6 | -0.4 | 0.0 | 0.0 | 0.4 | -0.1 | 0.0 | 11.0 |
| OFF BEST | 1.2 | -31.8 | 0.0 | 13.5 | 17.0 | -780.6 | 1.1 | 203.6 |
| ONE FIGHT FORMULA | 8.4 | -146.1 | 0.0 | 187.3 | 9.0 | -186.5 | 11.3 | 175.7 |
| ONE OBJECTIVE FORMULA | 2.3 | -36.5 | 0.0 | 49.1 | 2.6 | -166.1 | 0.0 | 47.7 |
| OPENS A LANE | 0.1 | +0.5 | 10.0 | 0.0 | 0.1 | +0.6 | 10.9 | 0.0 |
| OPENS UP | 0.3 | +23.6 | 19.2 | 0.0 | 0.3 | +38.5 | 14.0 | 13.7 |
| OVERRUNS AWAY | 0.3 | +12.5 | 27.6 | 8.6 | 0.6 | +15.1 | 50.8 | 23.4 |
| PATHS CROSS | 2.1 | +188.7 | 0.0 | 43.1 | 3.3 | +220.0 | 0.0 | 14.7 |
| PERIAPT WORTH | 0.1 | +6.8 | 0.0 | 0.0 | 0.1 | +4.9 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.1 | -1.6 | 0.0 | 3.4 | 0.1 | -1.5 | 0.0 | 6.2 |
| PLAN RESULT | 40.8 | +887.8 | 586.1 | 1170.0 | 41.4 | +999.0 | 1361.6 | 908.6 |
| RAIDS THE BAGGAGE NEXT TURN | - | - | - | - | 0.1 | +9.0 | 0.0 | 3.4 |
| RANDOM MOVE BY FIGURES | 1.1 | +14.7 | 0.0 | 46.2 | 2.0 | +33.3 | 0.0 | 59.0 |
| RANDOM MOVER NO PROMISE | - | - | - | - | 0.2 | -7.9 | 2.0 | 4.0 |
| REDIRECT BY WHAT IT STOPS | 0.2 | -1.6 | 0.0 | 1.9 | 1.9 | -53.4 | 0.0 | 33.7 |
| REDIRECT COUNTER | 2.7 | +142.1 | 0.0 | 66.4 | 4.4 | +239.0 | 0.0 | 65.1 |
| REDIRECT WEIGHED | 0.1 | -2.2 | 0.0 | 0.0 | 0.4 | +16.9 | 14.2 | 2.6 |
| REFUSING RETIRES | 0.2 | +0.0 | 0.0 | 22.6 | 0.1 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | 0.6 | +11.4 | 0.0 | 10.9 | 0.6 | +14.6 | 0.0 | 7.8 |
| RESTRAINS TO SHOOT | 0.0 | +1.4 | 0.0 | 0.0 | 0.0 | +1.1 | 0.0 | 11.0 |
| RISK BY ARC | 1.9 | +44.8 | 139.1 | 94.8 | 2.3 | +27.5 | 254.2 | 57.4 |
| RISK ONCE | - | - | - | - | 4.6 | +177.5 | 67.6 | 163.6 |
| RUN DOWN | 1.8 | -19.6 | 120.1 | 84.9 | - | - | - | - |
| SAFE SURE CHARGE | - | - | - | - | 0.1 | -8.3 | 1.4 | 0.0 |
| SAFER THAN THE JOB | - | - | - | - | 0.6 | +22.0 | 0.0 | 0.0 |
| SCOUT SPOT | 0.4 | +0.5 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 1.8 |
| SCOUT WAITS | 0.5 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 1.8 |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 0.4 | -17.9 | 0.0 | 0.8 |
| SEARCH SPOT | 4.9 | +133.1 | 0.0 | 129.2 | 2.9 | +91.1 | 0.0 | 34.9 |
| SELF MOVE SPELL | 0.2 | +50.2 | 0.0 | 0.0 | 0.5 | +10.8 | 0.0 | 21.9 |
| SET UP TOGETHER | 0.0 | +2.1 | 0.0 | 0.0 | 2.0 | +140.8 | 57.6 | 20.3 |
| SET-UP ANY TARGET | 0.3 | +50.2 | 2.4 | 2.4 | 0.1 | +12.5 | 0.0 | 0.0 |
| SET-UP MISSED | 0.1 | +16.8 | 0.0 | 0.0 | 0.0 | +3.4 | 0.0 | 0.0 |
| SHOOTER COUNTED ONCE | - | - | - | - | 0.0 | -0.0 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.3 | +0.8 | 0.0 | 0.0 | 0.2 | +0.3 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 0.9 | +18.5 | 9.3 | 16.6 | 1.1 | +14.8 | 34.7 | 18.6 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 3.8 |
| SHOT REPLANNED | 0.9 | +0.0 | 269.3 | 11.4 | 0.2 | +0.0 | 25.6 | 0.0 |
| SHOTS IN THE MOVE | 16.4 | +723.7 | 0.0 | 307.7 | 8.2 | +169.7 | 0.0 | 125.4 |
| SPELL CATCH ODDS | - | - | - | - | 0.0 | -0.6 | 0.0 | 0.0 |
| SPELL SETS UP CHARGE | 0.4 | +67.9 | 2.4 | 2.4 | 0.2 | +36.4 | 0.0 | 0.0 |
| SPELL WORTH | 1.5 | +18.6 | 77.9 | 64.9 | 2.4 | +38.1 | 30.0 | 30.0 |
| SPELLS IN THE FIGHT | 0.6 | +2.0 | 53.5 | 26.2 | 0.7 | -11.2 | 80.3 | 53.9 |
| STABLE ROLE | - | - | - | - | 11.1 | +0.0 | 307.3 | 116.6 |
| STAND AND SHOOT | 0.3 | -4.5 | 13.9 | 19.8 | - | - | - | - |
| STOPS | - | - | - | - | 0.1 | +2.5 | 21.8 | 1.2 |
| STOPS SHORT OF THE FLANK | - | - | - | - | 0.6 | +17.1 | 0.0 | 8.2 |
| STUCK PIVOT | 0.2 | +0.0 | 0.0 | 4.7 | 0.2 | +0.0 | 0.0 | 5.8 |
| SUPPORT NARROWED | 0.9 | +0.0 | 69.4 | 57.1 | 8.4 | -78.8 | 421.0 | 111.7 |
| SUPPORTS | - | - | - | - | 6.2 | +79.0 | 216.8 | 51.1 |
| SURE CHARGE BEATS ADVANCE | - | - | - | - | 0.1 | -3.1 | 1.7 | 0.0 |
| SURE REACH TOGETHER | 0.3 | +2.7 | 0.0 | 4.6 | 0.9 | -1.7 | 0.0 | 16.6 |
| THROUGH LINE OF FIRE | - | - | - | - | 0.2 | +4.3 | 0.0 | 4.4 |
| TIME ON OUR SIDE | 3.0 | +0.0 | 35.0 | 32.6 | - | - | - | - |
| TURN WORTH | 0.1 | -11.0 | 15.6 | 10.3 | 0.2 | -18.2 | 9.3 | 0.0 |
| TWO OR MORE ARRIVE | - | - | - | - | 0.4 | +1.0 | 25.6 | 4.0 |
| WAIT AFTER COSTS | - | - | - | - | 8.5 | -445.4 | 313.9 | 138.7 |
| WALKS TO THE FIGHT | - | - | - | - | 1.0 | +6.6 | 8.2 | 4.9 |
| WAR ENGINE CHARGES | 0.1 | +15.3 | 2.5 | 17.5 | - | - | - | - |
| WAR ENGINE JOBS | 0.2 | +0.0 | 4.5 | 11.8 | 0.2 | +0.0 | 7.7 | 0.0 |
| WEARS DOWN | 0.7 | +36.9 | 67.8 | 52.2 | 1.1 | +35.8 | 119.8 | 63.9 |
| WHO HITS BACK | 0.2 | +72.1 | 0.0 | 0.0 | 0.2 | +8.5 | 0.0 | 4.0 |
| WHOLE FIGHT | 0.2 | +2.6 | 18.4 | 0.0 | 0.4 | +30.5 | 54.0 | 0.0 |
| WHOLE FIGHT GAIN | 0.1 | +6.2 | 5.9 | 0.0 | 0.5 | +36.1 | 51.5 | 7.8 |
| WIDER SPREAD | 1.9 | -7.2 | 140.7 | 73.2 | 3.2 | -6.3 | 307.4 | 84.9 |
| WOUNDED STAYS OUT | - | - | - | - | 0.1 | +0.0 | 5.8 | 10.9 |

### Rule changes: fa-h2h-mine-8a94331-p4

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 655 | 655 | 655 | 18.19 | -29243 | -44.6 |
| SEARCH SPOT | 280 | 280 | 276 | 7.67 | +8073 | +29.3 |
| PATHS CROSS | 195 | 195 | 195 | 5.42 | +14713 | +75.5 |
| SHOTS IN THE MOVE | 888 | 712 | 115 | 3.19 | +2508 | +21.8 |
| MOVE TO CHARGE | 201 | 201 | 108 | 3.00 | +4802 | +44.5 |
| IDLE COST | 1432 | 754 | 101 | 2.81 | +935 | +9.3 |
| SUPPORTS | 225 | 225 | 90 | 2.50 | +971 | +10.8 |
| KILLS COUNT NEXT TURN | 253 | 253 | 87 | 2.42 | +2476 | +28.5 |
| COVER ONCE | 527 | 326 | 81 | 2.25 | +1111 | +13.7 |
| MAX FOR POSITIONING | 506 | 398 | 81 | 2.25 | +244 | +3.0 |
| REDIRECT COUNTER | 257 | 159 | 75 | 2.08 | +4747 | +63.3 |
| RANDOM MOVE BY FIGURES | 111 | 111 | 71 | 1.97 | +1726 | +24.3 |
| CHARGE LOSSES | 429 | 429 | 64 | 1.78 | +3004 | +46.9 |
| FOLLOW UP WEIGHED | 60 | 60 | 60 | 1.67 | +11834 | +197.2 |
| CHAFF IN THE MOVE | 87 | 84 | 58 | 1.61 | +1820 | +31.4 |
| WAIT AFTER COSTS | 307 | 307 | 58 | 1.61 | +804 | +13.9 |
| ADVANCE LANE KEPT | 55 | 55 | 55 | 1.53 | +0 | +0.0 |
| MISSILES IN THE MOVE | 250 | 174 | 50 | 1.39 | +1468 | +29.4 |
| ARTILLERY RE-ROLL WEIGHED | 49 | 49 | 49 | 1.36 | +0 | +0.0 |
| FALLBACK BY WORTH | 247 | 247 | 47 | 1.31 | +1742 | +37.1 |
| SHOOTS FROM THE BEST SPOT | 74 | 74 | 43 | 1.19 | +290 | +6.8 |
| CANNON SIGHT KEPT | 42 | 42 | 42 | 1.17 | +0 | +0.0 |
| RESERVE FALL BACK | 41 | 41 | 41 | 1.14 | +936 | +22.8 |
| SHOT REPLANNED | 39 | 39 | 39 | 1.08 | +0 | +0.0 |
| ONE FIGHT FORMULA | 628 | 341 | 38 | 1.06 | +219 | +5.8 |
| BEST FIRST | 37 | 37 | 37 | 1.03 | +1925 | +52.0 |
| KILLS COUNT | 109 | 109 | 37 | 1.03 | +1447 | +39.1 |
| FACES THE THREAT | 36 | 36 | 36 | 1.00 | +2268 | +63.0 |
| RISK BY ARC | 153 | 149 | 36 | 1.00 | +1060 | +29.5 |
| SET UP TOGETHER | 73 | 61 | 36 | 1.00 | +1936 | +53.8 |
| HOLDS AMBUSHERS | 35 | 35 | 35 | 0.97 | +0 | +0.0 |
| CHARGE NOW FIRST | 145 | 145 | 34 | 0.94 | -2426 | -71.3 |
| RISK ONCE | 164 | 127 | 33 | 0.92 | +1303 | +39.5 |
| CANNON PLANNED TARGET | 196 | 196 | 31 | 0.86 | -1846 | -59.5 |
| LONE WIZARD KEPT IN | 28 | 28 | 28 | 0.78 | +1699 | +60.7 |
| FOUR ROUNDS | 95 | 95 | 26 | 0.72 | +1235 | +47.5 |
| MARCH CHECK | 27 | 27 | 26 | 0.72 | +595 | +22.9 |
| HONEST WORTH | 455 | 453 | 25 | 0.69 | +141 | +5.7 |
| COMBAT PIVOT | 24 | 24 | 24 | 0.67 | +0 | +0.0 |
| CAST JOB | 45 | 45 | 21 | 0.58 | +278 | +13.3 |
| CHARGE NOW WEIGHED | 21 | 21 | 21 | 0.58 | +1246 | +59.3 |
| SCOUT WAITS | 21 | 21 | 21 | 0.58 | +0 | +0.0 |
| STOPS SHORT OF THE FLANK | 21 | 21 | 21 | 0.58 | +615 | +29.3 |
| WALKS TO THE FIGHT | 35 | 35 | 21 | 0.58 | +76 | +3.6 |
| SAFER THAN THE JOB | 20 | 20 | 20 | 0.56 | +794 | +39.7 |
| BLOCKED WHEEL | 19 | 19 | 19 | 0.53 | +495 | +26.0 |
| OPENS UP | 23 | 23 | 19 | 0.53 | +1034 | +54.4 |
| REDIRECT WEIGHED | 18 | 18 | 18 | 0.50 | +468 | +26.0 |
| SHOOTERS IN TWO RANKS | 18 | 18 | 18 | 0.50 | +41 | +2.3 |
| CASTER AWAY FROM SCREEN | 17 | 17 | 17 | 0.47 | +0 | +0.0 |
| MANOEUVRE | 35 | 35 | 17 | 0.47 | +616 | +36.2 |
| ADVANCE WORTH | 146 | 146 | 16 | 0.44 | +156 | +9.7 |
| KEEPS ITS TARGET | 86 | 86 | 16 | 0.44 | +316 | +19.8 |
| STUCK PIVOT | 15 | 15 | 15 | 0.42 | +0 | +0.0 |
| WHO HITS BACK | 15 | 15 | 15 | 0.42 | +1788 | +119.2 |
| BIG CHARACTER SAFETY | 13 | 13 | 13 | 0.36 | -39 | -3.0 |
| CHAFF PASSED | 13 | 13 | 13 | 0.36 | -37 | -2.8 |
| WHOLE FIGHT GAIN | 21 | 17 | 13 | 0.36 | +496 | +38.2 |
| MISSILES NEXT TURN | 306 | 195 | 12 | 0.33 | +37 | +3.1 |
| FEATURE BUFFS | 58 | 58 | 11 | 0.31 | +180 | +16.4 |
| SURE REACH TOGETHER | 42 | 36 | 11 | 0.31 | +31 | +2.8 |
| BEST PREY | 21 | 21 | 10 | 0.28 | +392 | +39.2 |
| HUNT IN PAIRS | 36 | 28 | 10 | 0.28 | +251 | +25.1 |
| MODEL FACING | 10 | 10 | 10 | 0.28 | +2042 | +204.2 |
| MOVE AND CAST | 10 | 10 | 10 | 0.28 | +359 | +35.9 |
| BEST FACING | 9 | 9 | 9 | 0.25 | +324 | +36.0 |
| BEST OVERALL | 9 | 9 | 9 | 0.25 | +368 | +40.9 |
| CASTING BLOCK | 13 | 13 | 9 | 0.25 | +68 | +7.6 |
| CASTS FROM BEHIND | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| FIVE ACTION | 1656 | 1656 | 9 | 0.25 | +795 | +88.3 |
| FRIENDS SHOTS CHECKED | 9 | 9 | 9 | 0.25 | +278 | +30.9 |
| INVITES THE FIGHT | 29 | 29 | 9 | 0.25 | +68 | +7.5 |
| ONE OBJECTIVE FORMULA | 174 | 95 | 9 | 0.25 | +305 | +33.9 |
| SHORT GUN FORWARD | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| PIVOT GUARDS FLANK | 8 | 8 | 8 | 0.22 | -111 | -13.9 |
| WHOLE FIGHT | 23 | 23 | 8 | 0.22 | +380 | +47.5 |
| AFTERMATH IN POINTS | 7 | 7 | 7 | 0.19 | +1225 | +175.0 |
| LOST CHARGE | 76 | 75 | 7 | 0.19 | +146 | +20.9 |
| MAKE SURE TOGETHER | 31 | 20 | 7 | 0.19 | +152 | +21.8 |
| MARCH ODDS | 7 | 7 | 7 | 0.19 | +43 | +6.2 |
| MOVES UNITS SPELL | 7 | 7 | 7 | 0.19 | +138 | +19.7 |
| SUPPORT NARROWED | 335 | 335 | 6 | 0.17 | -151 | -25.2 |
| THROUGH LINE OF FIRE | 6 | 6 | 6 | 0.17 | +155 | +25.9 |
| WEARS DOWN | 64 | 63 | 6 | 0.17 | +441 | +73.5 |
| GUN MASK | 26 | 26 | 5 | 0.14 | +115 | +23.0 |
| KEEP FALLS | 5 | 5 | 5 | 0.14 | +192 | +38.4 |
| OVERRUNS AWAY | 31 | 31 | 5 | 0.14 | +341 | +68.2 |
| REFUSING RETIRES | 11 | 11 | 5 | 0.14 | -1 | -0.3 |
| SAFE SURE CHARGE | 5 | 5 | 5 | 0.14 | -298 | -59.5 |
| BEST PRIZE | 4 | 4 | 4 | 0.11 | -173 | -43.2 |
| NEEDED THERE | 4 | 4 | 4 | 0.11 | +0 | +0.0 |
| PERIAPT WORTH | 4 | 4 | 4 | 0.11 | +419 | +104.8 |
| SURE CHARGE BEATS ADVANCE | 4 | 4 | 4 | 0.11 | -111 | -27.8 |
| WAR ENGINE JOBS | 12 | 12 | 4 | 0.11 | -306 | -76.6 |
| WIDER SPREAD | 184 | 179 | 4 | 0.11 | +4 | +0.9 |
| EDGE GIVE GROUND | 12 | 12 | 3 | 0.08 | +294 | +98.0 |
| ELIXIR WORTH | 3 | 3 | 3 | 0.08 | +73 | +24.4 |
| RAIDS THE BAGGAGE NEXT TURN | 3 | 3 | 3 | 0.08 | +57 | +18.9 |
| SPELLS IN THE FIGHT | 46 | 42 | 3 | 0.08 | +9 | +2.9 |
| WAR ENGINE CHARGES | 4 | 4 | 3 | 0.08 | +234 | +78.0 |
| BLOCKED CHARGE SKIPPED | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| HUNT ADVANCE | 8 | 8 | 2 | 0.06 | +2 | +1.2 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| NO RALLY LEFT | 2 | 2 | 2 | 0.06 | +13 | +6.5 |
| RESTRAINS TO SHOOT | 2 | 2 | 2 | 0.06 | +92 | +45.8 |
| BLOCKED CHARGE HANDED OVER | 1 | 1 | 1 | 0.03 | +16 | +15.6 |
| BLOWS WHERE AIMED | 11 | 10 | 1 | 0.03 | +38 | +37.9 |
| BOMBING RUN | 1 | 1 | 1 | 0.03 | +6 | +5.5 |
| BOUND ASSAILMENT | 1 | 1 | 1 | 0.03 | +0 | +0.1 |
| CHAMPION TAKES THE CHALLENGE | 1 | 1 | 1 | 0.03 | +3 | +3.3 |
| CHARGER SLAIN LOST | 34 | 29 | 1 | 0.03 | +11 | +11.2 |
| DEFENSIVE FLOOR | 2 | 2 | 1 | 0.03 | +21 | +20.6 |
| FIRE AND FLEE | 1 | 1 | 1 | 0.03 | +324 | +324.0 |
| JOINT CHARGE PLAN | 6 | 6 | 1 | 0.03 | +21 | +21.4 |
| LONE WIZARD HOLDS BACK | 9 | 9 | 1 | 0.03 | -22 | -22.3 |
| REDIRECT BY WHAT IT STOPS | 74 | 74 | 1 | 0.03 | +18 | +17.6 |
| STOPS | 4 | 4 | 1 | 0.03 | +59 | +58.9 |
| WOUNDED STAYS OUT | 2 | 2 | 1 | 0.03 | -501 | -500.8 |
| ALREADY CARRIED | 4 | not checked | - | - | - | - |
| BACKUP TARGETS | 38 | 21 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 20 | 20 | 0 | 0.00 | - | - |
| CARRIES OUT COUNTER | 1 | 1 | 0 | 0.00 | - | - |
| CARRIES OUT SET-UP | 3 | 3 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 48 | trace | - | - | - | - |
| CATCH FLIERS | 1 | not checked | - | - | - | - |
| CHARACTER GUNS | 13 | 13 | 0 | 0.00 | - | - |
| CHARIOT WIZARD CAREFUL | 5 | 5 | 0 | 0.00 | - | - |
| CHEAP HELPER | 4 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 55 | not checked | - | - | - | - |
| DEFENSIVE ARMY | 5 | 5 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 62 | 62 | 0 | 0.00 | - | - |
| FALLS SHORT | 9 | 9 | 0 | 0.00 | - | - |
| FIGHT LIFT | 1 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 396 | not checked | - | - | - | - |
| GIVES UP | 6 | 6 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 1 | 1 | 0 | 0.00 | - | - |
| GROUND FLIERS | 3 | not checked | - | - | - | - |
| HELPER ALREADY ASKED | 1 | not checked | - | - | - | - |
| HELPER UNSEEN | 20 | 20 | 0 | 0.00 | - | - |
| HILL BY ITS CHANCE | 15 | 15 | 0 | 0.00 | - | - |
| HUNT DROPPED | 4 | trace | - | - | - | - |
| HUNT KEPT | 3 | trace | - | - | - | - |
| HUNT RESULT | 8 | trace | - | - | - | - |
| HUNT THE GUNS | 9 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 6 | 4 | 0 | 0.00 | - | - |
| KEEPS ITS PREY | 1 | 1 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 7 | not checked | - | - | - | - |
| LONG SHOT | 25 | 24 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 9 | 9 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 2 | trace | - | - | - | - |
| MARCH OVER CASTS | 34 | 34 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 9 | 9 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 12 | 6 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 30 | trace | - | - | - | - |
| MOVE SPELL SPOT | 30 | not checked | - | - | - | - |
| NOT NEEDED | 10 | 10 | 0 | 0.00 | - | - |
| NOT TURNED | 226 | 226 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 37 | not checked | - | - | - | - |
| OPENS A LANE | 7 | not checked | - | - | - | - |
| PLAN RESULT | 2958 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 7 | 7 | 0 | 0.00 | - | - |
| RUN DOWN | 63 | 63 | 0 | 0.00 | - | - |
| SCOUT SPOT | 19 | 19 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 15 | 15 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 23 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 16 | not checked | - | - | - | - |
| SET-UP MISSED | 3 | trace | - | - | - | - |
| SHOOTER COUNTED ONCE | 1 | 1 | 0 | 0.00 | - | - |
| SPELL CATCH ODDS | 1 | not checked | - | - | - | - |
| SPELL SETS UP CHARGE | 21 | not checked | - | - | - | - |
| SPELL WORTH | 140 | not checked | - | - | - | - |
| STABLE ROLE | 401 | 400 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 11 | 11 | 0 | 0.00 | - | - |
| TIME ON OUR SIDE | 109 | 109 | 0 | 0.00 | - | - |
| TURN WORTH | 12 | 12 | 0 | 0.00 | - | - |
| TWO OR MORE ARRIVE | 16 | 14 | 0 | 0.00 | - | - |

### Off best figure: fa-h2h-mine-8a94331-p4

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 0.86 | 15.19 | 45.0 |
| CHARGE NOW FIRST | rule | 0.22 | 0.69 | 73.5 |
| FALLBACK | gate | - | 0.86 | 42.2 |
| CANNON PLANNED TARGET | rule | 0.42 | 0.03 | 117.0 |
| TURN GATE | gate | 0.03 | 0.42 | 46.4 |
| AFTERMATH BAND | gate | 0.11 | 0.17 | 2.4 |
| PIVOT GUARDS FLANK | rule | 0.11 | 0.11 | 13.9 |
| BIG CHARACTER SAFETY | rule | - | 0.19 | 7.5 |
| CHAFF PASSED | rule | 0.11 | 0.08 | 5.2 |
| NO REASON | gate | 0.17 | - | 53.6 |
| SUPPORT NARROWED | rule | - | 0.17 | 25.2 |
| PATHS CROSS | rule | 0.03 | 0.11 | 13.1 |
| SAFE SURE CHARGE | rule | - | 0.14 | 59.5 |
| SUPPORT REQUEST | gate | - | 0.14 | 94.5 |
| BEST PRIZE | rule | 0.03 | 0.08 | 43.2 |
| FIGHT ORDER BAND | gate | - | 0.11 | 2.2 |
| STOPS SHORT OF THE FLANK | rule | - | 0.11 | 3.4 |
| SURE CHARGE BEATS ADVANCE | rule | - | 0.11 | 27.8 |
| WAR ENGINE JOBS | rule | 0.03 | 0.08 | 76.6 |
| SAFER THAN THE JOB | rule | - | 0.08 | 12.9 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.06 | - | 123.5 |
| CHARGE NOW WEIGHED | rule | - | 0.06 | 42.1 |
| FRIENDS SHOTS CHECKED | rule | 0.03 | 0.03 | 2.7 |
| LONE CHARACTER SAFE SPOT | gate | - | 0.06 | 7.0 |
| MARCH ODDS | rule | 0.03 | 0.03 | 3.9 |
| REDIRECT WEIGHED | rule | 0.03 | 0.03 | 41.5 |
| BLOCKED WHEEL | rule | - | 0.03 | 7.1 |
| LONE WIZARD HOLDS BACK | rule | - | 0.03 | 22.3 |
| REFUSING RETIRES | rule | 0.03 | - | 0.8 |
| RULE SWITCHED OFF | gate | - | 0.03 | 85.8 |
| WHO HITS BACK | rule | 0.03 | - | 4.4 |
| WOUNDED STAYS OUT | rule | - | 0.03 | 500.8 |

### Plans: fa-h2h-mine-8a94331-p4

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 2.0 | 69% | 257 | 204 | 79% |
| Mine | join | 0.3 | 91% | 7 | 0 | 0% |
| Mine | move | 30.1 | 92% | 1621 | 0 | 0% |
| Mine | shoot | 8.2 | 59% | 412 | 683 | 166% |
| Mine | support | 0.2 | 67% | 2 | 0 | 0% |
| Opponent | advance | 11.9 | 12% | 124 | 183 | 148% |
| Opponent | charge | 3.7 | 62% | 336 | 379 | 113% |
| Opponent | close in | 7.4 | 19% | 416 | 160 | 39% |
| Opponent | hold | 5.1 | 33% | 330 | 0 | 0% |
| Opponent | join | 0.6 | 90% | 21 | 0 | 0% |
| Opponent | shoot | 4.4 | 54% | 101 | 280 | 277% |
| Opponent | support | 8.3 | 91% | 63 | 0 | 0% |

### Packages: hunt the guns, fa-h2h-mine-8a94331-p4

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 23 |
| Opponent | 0.2 | 9 | 1 | 38% | 50% | 0% | 2.0 | 348 | 136 | 38% | 87 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 145 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 102 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| High Elf Realms | 0.2 | 2 | 1 | 0% | 0% | 0% | - | 243 | 0 | 0% | 81 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 58 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 105 |
| Tomb Kings of Khemri | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Vampire Counts | 0.8 | 6 | 0 | 50% | 67% | 0% | 2.0 | 343 | 182 | 50% | 22 |
| Warriors of Chaos | 0.1 | 1 | 0 | 0% | 0% | 0% | - | 486 | 0 | 0% | 55 |
| Wood Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 117 |

### Battle groups: fa-h2h-mine-8a94331-p4

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 2.7 | 42% | 61% | 7% | 33% | 18% | 0% | 5% | 74% | 3% |
| Opponent | REDIRECT COUNTER | 4.4 | 21% | 74% | 12% | 0% | 13% | 0% | 13% | 57% | 17% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: fa-h2h-mine-8a94331-p4

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 4 | 0 (4) | 0 | 0 | 100 | 75% | 4.0 | - | 0 (1) | - | - | 0 (1) |
| Mine | Chaff | 34 | 36 (34) | 12 | 24 | 68 | 29% | 2.4 | 22 (14) | 0 (7) | 65 (13) | 49 (22) | 10 (12) |
| Mine | Character | 106 | 36 (106) | 36 | 0 | 31 | 22% | 2.7 | 42 (33) | 37 (53) | 8 (8) | 39 (44) | 35 (50) |
| Mine | Clean-up | 22 | 49 (22) | 27 | 23 | 33 | 50% | 3.1 | 0 (2) | 74 (16) | 0 (4) | 62 (10) | 43 (12) |
| Mine | Early | 1 | 0 (1) | 0 | 0 | 100 | 0% | 3.0 | - | 0 (1) | - | - | 0 (1) |
| Mine | Fast | 4 | 0 (4) | 0 | 0 | 46 | 50% | 1.0 | 0 (2) | 0 (2) | - | 0 (3) | 0 (1) |
| Mine | Fast Hammer | 41 | 26 (41) | 15 | 11 | 42 | 24% | 3.0 | 19 (27) | 44 (9) | 24 (5) | 36 (25) | 10 (16) |
| Mine | Fragile | 4 | 0 (4) | 0 | 0 | 73 | 50% | 4.0 | 0 (2) | 0 (2) | - | 0 (1) | 0 (3) |
| Mine | Hammer | 65 | 28 (65) | 17 | 12 | 44 | 20% | 2.6 | 23 (13) | 33 (45) | 2 (7) | 38 (40) | 16 (25) |
| Mine | Holder | 31 | 58 (31) | 4 | 54 | 32 | 39% | 3.2 | 33 (9) | 89 (16) | 18 (5) | 98 (17) | 17 (13) |
| Mine | Shooter | 34 | 62 (34) | 40 | 22 | 39 | 0% | 1.7 | 34 (8) | 81 (21) | 30 (5) | 58 (25) | 75 (9) |
| Mine | Support | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | - | 0 (1) | 0 (1) | - |
| Mine | War machine | 56 | 46 (56) | 46 | 0 | 46 | 4% | 1.2 | 86 (16) | 28 (30) | 20 (10) | 70 (9) | 41 (47) |
| Mine | Wizard | 17 | 27 (17) | 27 | 0 | 55 | 6% | 2.3 | 98 (5) | 7 (8) | 0 (1) | 79 (7) | 0 (7) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Chaff | 75 | 55 (75) | 20 | 35 | 48 | 48% | 2.7 | 52 (31) | 69 (17) | 46 (27) | 59 (56) | 42 (19) |
| Opponent | Character | 97 | 53 (97) | 51 | 2 | 24 | 25% | 2.3 | 65 (45) | 45 (40) | 43 (8) | 57 (55) | 51 (38) |
| Opponent | Clean-up | 11 | 67 (11) | 29 | 38 | 17 | 18% | 3.2 | 0 (3) | 64 (6) | 124 (2) | 62 (6) | 70 (5) |
| Opponent | Fast | 1 | 142 (1) | 142 | 0 | 0 | 0% | 6.0 | - | 142 (1) | - | 142 (1) | - |
| Opponent | Fast Hammer | 60 | 53 (60) | 36 | 17 | 37 | 32% | 3.4 | 33 (26) | 58 (25) | 119 (9) | 52 (39) | 53 (21) |
| Opponent | Fragile | 17 | 2 (17) | 2 | 0 | 63 | 41% | 1.9 | 0 (5) | 4 (8) | 0 (4) | 3 (13) | 0 (4) |
| Opponent | Hammer | 65 | 33 (65) | 20 | 13 | 39 | 38% | 3.4 | 12 (20) | 32 (38) | 122 (7) | 45 (41) | 15 (24) |
| Opponent | Holder | 29 | 28 (29) | 5 | 23 | 23 | 66% | 4.5 | 0 (12) | 56 (10) | 20 (5) | 26 (17) | 36 (10) |
| Opponent | Shooter | 33 | 62 (33) | 14 | 48 | 19 | 3% | 1.5 | 53 (9) | 51 (21) | 189 (3) | 36 (18) | 91 (15) |
| Opponent | Support | 6 | 0 (6) | 0 | 0 | 0 | 50% | 3.0 | 0 (3) | 0 (3) | - | 0 (4) | 0 (2) |
| Opponent | War machine | 6 | 128 (6) | 128 | 0 | 40 | 17% | 1.0 | 86 (3) | 189 (3) | - | 86 (3) | 189 (3) |
| Opponent | Wizard | 19 | 12 (19) | 12 | 0 | 20 | 5% | 2.3 | 5 (10) | 31 (6) | 0 (2) | 13 (13) | 13 (5) |

### Charged fights: fa-h2h-mine-8a94331-p4

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 152 | 69 | 1.2 | 1.0 | 55 | 0 | +55 | 0 of 5 | 5 of 5 | - | +55 |
| Mine | Chaos Dwarfs | 4 | 300 | 27 | 2.5 | 1.0 | 11 | 71 | -60 | 5 of 10 | 7 of 10 | - | -60 |
| Mine | Dwarfen Mountain Holds | 3 | 604 | 42 | 1.0 | 1.3 | 42 | 0 | +42 | 1 of 3 | 2 of 3 | +0 | +62 |
| Mine | Empire of Man | 5 | 425 | 175 | 1.0 | 1.0 | 175 | 179 | -5 | 2 of 5 | 2 of 5 | - | -5 |
| Mine | Grand Cathay | 4 | 378 | 96 | 2.5 | 1.1 | 38 | 58 | -20 | 4 of 10 | 8 of 10 | +0 | -22 |
| Mine | High Elf Realms | 4 | 290 | 365 | 3.0 | 1.0 | 122 | 0 | +122 | 4 of 12 | 11 of 12 | - | +122 |
| Mine | Kingdom of Bretonnia | 1 | 475 | 275 | 2.0 | 1.0 | 138 | 0 | +138 | 1 of 2 | 1 of 2 | - | +138 |
| Mine | Lizardmen | 1 | 115 | 490 | 5.0 | 1.0 | 98 | 116 | -18 | 4 of 5 | 2 of 5 | - | -18 |
| Mine | Ogre Kingdoms | 2 | 28 | 28 | 3.0 | 1.0 | 9 | 52 | -42 | 5 of 6 | 2 of 6 | - | -42 |
| Mine | Skaven | 2 | 184 | 33 | 1.0 | 1.0 | 33 | 0 | +33 | 0 of 2 | 2 of 2 | - | +33 |
| Mine | Tomb Kings of Khemri | 2 | 38 | 953 | 4.5 | 1.0 | 212 | 0 | +212 | 4 of 9 | 6 of 9 | - | +212 |
| Mine | Vampire Counts | 2 | 108 | 44 | 3.0 | 1.2 | 14 | 62 | -48 | 1 of 6 | 6 of 6 | +0 | -57 |
| Mine | Warriors of Chaos | 2 | 0 | 286 | 3.5 | 1.1 | 82 | 75 | +7 | 2 of 7 | 6 of 7 | -525 | +95 |
| **Mine** | all armies | 36 | 270 | 186 | 2.3 | 1.0 | 81 | 49 | +33 | 33 of 82 | 60 of 82 | -131 | +41 |
| Opponent | Empire of Man | 1 | 555 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | High Elf Realms | 5 | 171 | 356 | 3.8 | 1.2 | 94 | 73 | +20 | 8 of 19 | 14 of 18 | -210 | +48 |
| Opponent | Lizardmen | 2 | 124 | 392 | 1.5 | 1.3 | 262 | 0 | +262 | 1 of 3 | 2 of 3 | +189 | +298 |
| Opponent | Orc & Goblin Tribes | 3 | 0 | 636 | 2.7 | 1.2 | 238 | 0 | +238 | 3 of 8 | 8 of 8 | +265 | +230 |
| Opponent | Skaven | 4 | 89 | 40 | 2.0 | 1.2 | 20 | 5 | +15 | 3 of 8 | 3 of 7 | +32 | +9 |
| Opponent | Tomb Kings of Khemri | 2 | 55 | 577 | 4.5 | 1.2 | 128 | 8 | +120 | 5 of 9 | 6 of 9 | +210 | +109 |
| Opponent | Vampire Counts | 6 | 25 | 485 | 5.2 | 1.2 | 94 | 28 | +66 | 18 of 31 | 27 of 31 | +29 | +74 |
| Opponent | Warriors of Chaos | 7 | 19 | 415 | 2.1 | 1.0 | 194 | 34 | +159 | 8 of 15 | 11 of 15 | - | +159 |
| Opponent | Wood Elf Realms | 6 | 132 | 286 | 4.2 | 1.1 | 69 | 7 | +62 | 5 of 25 | 21 of 25 | +86 | +59 |
| **Opponent** | all armies | 36 | 89 | 370 | 3.3 | 1.2 | 113 | 26 | +87 | 51 of 118 | 92 of 116 | +59 | +92 |

### Effective charges: fa-h2h-mine-8a94331-p4

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 5 | 1 (net +0) | 1 (net +80) | 1 (net +0) | 2 (net +98) | 0 | 0 | 0 | 20% (1 of 5) |
| Mine | Chaos Dwarfs | 10 | 0 | 0 | 2 (net -357) | 3 (net +36) | 0 | 4 (net +0) | 1 | 22% (2 of 9) |
| Mine | Dwarfen Mountain Holds | 3 | 0 | 0 | 0 | 1 (net +60) | 0 | 2 (net +32) | 0 | 0% (0 of 3) |
| Mine | Empire of Man | 5 | 2 (net +123) | 0 | 0 | 2 (net -177) | 0 | 1 (net +85) | 0 | 0% (0 of 5) |
| Mine | Grand Cathay | 10 | 1 (net -205) | 0 | 1 (net +210) | 4 (net +44) | 0 | 4 (net -95) | 0 | 10% (1 of 10) |
| Mine | High Elf Realms | 12 | 1 (net +743) | 1 (net +0) | 4 (net +18) | 3 (net +86) | 0 | 3 (net +129) | 0 | 33% (4 of 12) |
| Mine | Kingdom of Bretonnia | 2 | 1 (net +210) | 0 | 0 | 1 (net +65) | 0 | 0 | 0 | 0% (0 of 2) |
| Mine | Lizardmen | 5 | 2 (net -88) | 1 (net -405) | 0 | 0 | 0 | 2 (net +245) | 0 | 0% (0 of 5) |
| Mine | Ogre Kingdoms | 6 | 0 | 1 (net +0) | 0 | 0 | 0 | 1 (net +55) | 4 | 0% (0 of 2) |
| Mine | Skaven | 2 | 0 | 0 | 0 | 0 | 0 | 2 (net +33) | 0 | 0% (0 of 2) |
| Mine | Tomb Kings of Khemri | 9 | 3 (net +360) | 0 | 1 (net +0) | 4 (net +206) | 0 | 1 (net +0) | 0 | 11% (1 of 9) |
| Mine | Vampire Counts | 6 | 1 (net +60) | 1 (net -329) | 1 (net -18) | 0 | 2 (net +0) | 0 | 1 | 20% (1 of 5) |
| Mine | Warriors of Chaos | 7 | 0 | 0 | 1 (net -525) | 2 (net +14) | 2 (net +80) | 2 (net +192) | 0 | 14% (1 of 7) |
| Opponent | High Elf Realms | 19 | 2 (net -326) | 1 (net +0) | 7 (net -9) | 4 (net +155) | 0 | 2 (net +70) | 3 | 44% (7 of 16) |
| Opponent | Lizardmen | 3 | 0 | 0 | 1 (net +434) | 1 (net +162) | 1 (net +189) | 0 | 0 | 33% (1 of 3) |
| Opponent | Orc & Goblin Tribes | 8 | 0 | 0 | 0 | 1 (net +752) | 0 | 3 (net +157) | 4 | 0% (0 of 4) |
| Opponent | Skaven | 8 | 2 (net -20) | 0 | 2 (net +0) | 0 | 2 (net +32) | 2 (net +48) | 0 | 25% (2 of 8) |
| Opponent | Tomb Kings of Khemri | 9 | 1 (net +0) | 0 | 0 | 4 (net +68) | 2 (net +135) | 2 (net +270) | 0 | 0% (0 of 9) |
| Opponent | Vampire Counts | 31 | 5 (net +105) | 0 | 3 (net +85) | 10 (net +94) | 7 (net +47) | 4 (net -32) | 2 | 10% (3 of 29) |
| Opponent | Warriors of Chaos | 15 | 1 (net -173) | 1 (net +533) | 2 (net +158) | 5 (net +317) | 1 (net +0) | 3 (net +157) | 2 | 15% (2 of 13) |
| Opponent | Wood Elf Realms | 25 | 4 (net +28) | 2 (net +0) | 3 (net -38) | 4 (net +136) | 3 (net +96) | 8 (net +85) | 1 | 12% (3 of 24) |

### Charged fights, damage counted: fa-h2h-mine-8a94331-p4

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 12 | 266 | 218 | +163 | 272 | 92 | +180 | +67.4 |
| Mine | 50-54% | 5 | 328 | 342 | -131 | 38 | 159 | -121 | -37.0 |
| Mine | Effective (55-75%) | 11 | 263 | 239 | -89 | 53 | 121 | -68 | -25.9 |
| Mine | 76-89% | 22 | 267 | 147 | +62 | 98 | 47 | +50 | +18.7 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 22 | 247 | 178 | +52 | 100 | 42 | +58 | +23.4 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 4 | 518 | 82 | +40 | 55 | 0 | +55 | +10.6 |
| Mine | No odds | 6 | 167 | 333 | -52 | 11 | 52 | -40 | -24.1 |
| Mine | All fights | 82 | 270 | 200 | +33 | 106 | 67 | +38 | +14.3 |
| Opponent | Long shot (under 50%) | 15 | 190 | 238 | -15 | 88 | 66 | +22 | +11.5 |
| Opponent | 50-54% | 4 | 304 | 231 | +133 | 138 | 0 | +138 | +45.5 |
| Opponent | Effective (55-75%) | 18 | 291 | 225 | +46 | 98 | 75 | +23 | +8.0 |
| Opponent | 76-89% | 29 | 297 | 214 | +168 | 182 | 33 | +149 | +50.1 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 24 | 316 | 211 | +95 | 147 | 38 | +110 | +34.8 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 16 | 427 | 93 | +72 | 72 | 9 | +62 | +14.6 |
| Opponent | No odds | 12 | 348 | 184 | +68 | 110 | 37 | +73 | +21.0 |
| Opponent | All fights | 118 | 309 | 199 | +87 | 127 | 41 | +86 | +27.7 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| fa-h2h-mine-8a94331-p4 | move | 374 | 69 (18%) | 54 (14%) | 54 (14%) | 251 (67%) |
| fa-h2h-mine-8a94331-p4 | objective | 270 | 40 (15%) | 22 (8%) | 43 (16%) | 187 (69%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0114, L0130, L2527, L2634 |
| Charmed Shield | Opponent | L0434, L0624, L0926, L1034, L1126, L1427, L2227, L2527, L2634, L3234 |
| Clockwork Compass | Mine | L1220 |
| Elixir of Power | Mine | L1126 |
| Elixir of Power | Opponent | L0819, L1719, L1819 |
| Fistful of Laurels | Mine | L1819, L1835 |
| Invocation of Nehek | Mine | L2527 |
| Invocation of Nehek | Opponent | L0624, L1427, L2227, L2527 |
| Opal Amulet | Mine | L1427 |
| Opal Amulet | Opponent | L0114, L0214, L1314 |
| Periapt of Soul Exchange | Mine | L2021, L2123 |
| Periapt of Soul Exchange | Opponent | L0520, L1220, L1621, L2021 |
| Ring of Doom | Mine | L0214, L0230, L1126, L1220, L1523 |
| Ring of Doom | Opponent | L0315, L1331, L2331 |
| Ring of Jet | Mine | L1017, L1034, L1126, L1220 |
| Standard of the Fell Warrior | Mine | L1314, L1331 |
| Standard of the Fell Warrior | Opponent | L0713 |
| Storm Daemon (Renegade 2.0) | Mine | L2123 |
| Storm Daemon (Renegade 2.0) | Opponent | L1621, L2021 |
| Twice-Blessed Armour | Mine | L0713, L0729, L1017, L1034 |
| Witch Hunter's Ward | Mine | L0713, L0729, L0819, L0835 |
| Witch Hunter's Ward | Opponent | L0608 |

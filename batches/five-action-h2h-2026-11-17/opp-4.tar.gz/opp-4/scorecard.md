# Doctrine scorecard: fa-h2h-opp-8a94331-p4

### Scorecard: fa-h2h-opp-8a94331-p4

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0114 | 6 | 1 | Mine | no | 2 | 2 | 1 | 2 | 0 | 0 | 0 | 65 |
| L0114 | 6 | 1 | Opponent | no | 3 | 1 | 2 | 1 | 0 | 0 | 0 | 123 |
| L0130 | 4 | 1 | Mine | no | 5 | 4 | 1 | 0 | 0 | 0 | 0 | 65 |
| L0130 | 4 | 1 | Opponent | no | 2 | 1 | 5 | 2 | 0 | 0 | 0 | 98 |
| L0214 | 4 | 1 | Mine | yes | 4 | 3 | 1 | 2 | 1 | 0 | 0 | 0 |
| L0214 | 4 | 1 | Opponent | yes | 0 | 1 | 2 | 0 | 0 | 0 | 0 | 0 |
| L0230 | 2 | 1 | Mine | - | - | 2 | 1 | 3 | 0 | 0 | 0 | 170 |
| L0230 | 2 | 1 | Opponent | - | - | 2 | 1 | 1 | 0 | 0 | 0 | 0 |
| L0315 | 3 | 1 | Mine | no | 1 | 1 | 3 | 1 | 1 | 0 | 0 | 675 |
| L0315 | 3 | 1 | Opponent | yes | 6 | 2 | 1 | 2 | 0 | 0 | 0 | 115 |
| L0332 | 2 | 1 | Mine | - | - | - | 2 | 0 | 0 | 0 | 0 | 590 |
| L0332 | 2 | 1 | Opponent | - | - | 2 | 2 | 4 | 0 | 0 | 0 | 0 |
| L0417 | 3 | 1 | Mine | yes | 10 | 2 | 5 | 1 | 0 | 0 | 0 | 0 |
| L0417 | 3 | 1 | Opponent | yes | 5 | 2 | 3 | 0 | 0 | 0 | 0 | 175 |
| L0434 | 2 | 1 | Mine | - | - | 4 | 3 | 3 | 1 | 0 | 0 | 0 |
| L0434 | 2 | 1 | Opponent | - | - | 3 | 2 | 3 | 0 | 0 | 0 | 107 |
| L0520 | 4 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 1193 |
| L0520 | 4 | 1 | Opponent | no | 3 | - | 0 | 6 | 1 | 0 | 0 | 210 |
| L0608 | 2 | 1 | Mine | - | - | 3 | 2 | 5 | 0 | 0 | 0 | 798 |
| L0608 | 2 | 1 | Opponent | - | - | 3 | 0 | 2 | 0 | 0 | 0 | 639 |
| L0624 | 6 | 1 | Mine | no | 0 | 3 | 2 | 1 | 0 | 0 | 0 | 1262 |
| L0624 | 6 | 1 | Opponent | no | 6 | 4 | 1 | 2 | 0 | 0 | 0 | 0 |
| L0713 | 5 | 1 | Mine | yes | - | 2 | 3 | 1 | 0 | 0 | 0 | 420 |
| L0713 | 5 | 1 | Opponent | yes | - | 6 | 2 | 2 | 0 | 0 | 0 | 140 |
| L0729 | 3 | 1 | Mine | no | 8 | 3 | 3 | 0 | 2 | 0 | 0 | 452 |
| L0729 | 3 | 1 | Opponent | no | 2 | 2 | 2 | 0 | 0 | 0 | 0 | 170 |
| L0819 | 3 | 1 | Mine | no | 2 | 4 | 2 | 0 | 0 | 0 | 0 | 805 |
| L0819 | 3 | 1 | Opponent | yes | 3 | 2 | 3 | 2 | 0 | 0 | 0 | 382 |
| L0835 | 1 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 515 |
| L0835 | 1 | 1 | Opponent | no | 0 | 2 | 2 | 3 | 0 | 0 | 0 | 125 |
| L0926 | 2 | 1 | Mine | - | - | 3 | 1 | 0 | 0 | 0 | 0 | 537 |
| L0926 | 2 | 1 | Opponent | - | - | 2 | 2 | 7 | 1 | 0 | 0 | 0 |
| L1017 | 3 | 1 | Mine | no | 5 | 2 | 6 | 1 | 0 | 0 | 0 | 330 |
| L1017 | 3 | 1 | Opponent | yes | 0 | 2 | 0 | 0 | 2 | 0 | 0 | 273 |
| L1034 | 2 | 1 | Mine | - | - | 2 | 1 | 1 | 1 | 0 | 0 | 330 |
| L1034 | 2 | 1 | Opponent | - | - | 3 | 2 | 6 | 0 | 0 | 0 | 556 |
| L1126 | 4 | 1 | Mine | no | 2 | 3 | 2 | 0 | 0 | 0 | 0 | 330 |
| L1126 | 4 | 1 | Opponent | no | 6 | 3 | 1 | 3 | 1 | 0 | 0 | 0 |
| L1220 | 2 | 1 | Mine | - | - | 2 | 2 | 0 | 1 | 0 | 0 | 330 |
| L1220 | 2 | 1 | Opponent | - | - | - | 2 | 3 | 0 | 0 | 0 | 275 |
| L1314 | 6 | 1 | Mine | no | 2 | 5 | 1 | 0 | 1 | 0 | 0 | 140 |
| L1314 | 6 | 1 | Opponent | yes | 3 | 2 | 5 | 1 | 0 | 0 | 0 | 123 |
| L1331 | 5 | 1 | Mine | no | - | 4 | 3 | 0 | 0 | 0 | 0 | 317 |
| L1331 | 5 | 1 | Opponent | yes | - | 1 | 2 | 4 | 4 | 0 | 0 | 340 |
| L1427 | 5 | 1 | Mine | yes | - | 3 | 5 | 3 | 0 | 0 | 0 | 0 |
| L1427 | 5 | 1 | Opponent | yes | - | 4 | 2 | 2 | 0 | 0 | 0 | 0 |
| L1523 | 5 | 1 | Mine | yes | - | 2 | 6 | 0 | 1 | 0 | 0 | 0 |
| L1523 | 5 | 1 | Opponent | yes | - | 2 | 5 | 2 | 0 | 0 | 0 | 72 |
| L1621 | 1 | 1 | Mine | no | 0 | 2 | 5 | 1 | 0 | 0 | 0 | 200 |
| L1621 | 1 | 1 | Opponent | no | 0 | - | 0 | 5 | 0 | 0 | 0 | 467 |
| L1719 | 3 | 1 | Mine | yes | 3 | 3 | 5 | 0 | 0 | 0 | 0 | 49 |
| L1719 | 3 | 1 | Opponent | yes | 1 | 2 | 7 | 0 | 0 | 0 | 0 | 0 |
| L1819 | 1 | 1 | Mine | no | 1 | 5 | 2 | 2 | 0 | 0 | 0 | 0 |
| L1819 | 1 | 1 | Opponent | no | 0 | 2 | 5 | 0 | 0 | 0 | 0 | 0 |
| L1835 | 5 | 1 | Mine | yes | - | 3 | 2 | 1 | 1 | 0 | 0 | 0 |
| L1835 | 5 | 1 | Opponent | no | - | 1 | 2 | 2 | 0 | 0 | 0 | 140 |
| L2021 | 5 | 1 | Mine | yes | - | - | 0 | 3 | 1 | 0 | 0 | 210 |
| L2021 | 5 | 1 | Opponent | yes | - | - | 1 | 6 | 0 | 0 | 0 | 410 |
| L2123 | 5 | 1 | Mine | yes | - | 2 | 2 | 2 | 0 | 0 | 0 | 565 |
| L2123 | 5 | 1 | Opponent | yes | - | 3 | 3 | 2 | 1 | 0 | 0 | 70 |
| L2227 | 1 | 1 | Mine | yes | 5 | 2 | 2 | 0 | 0 | 0 | 0 | 0 |
| L2227 | 1 | 1 | Opponent | no | 0 | - | 1 | 4 | 0 | 0 | 0 | 190 |
| L2331 | 3 | 1 | Mine | yes | 0 | 2 | 5 | 1 | 0 | 0 | 0 | 72 |
| L2331 | 3 | 1 | Opponent | yes | 6 | 3 | 4 | 0 | 1 | 0 | 0 | 562 |
| L2527 | 1 | 1 | Mine | no | 0 | 3 | 5 | 2 | 1 | 0 | 0 | 0 |
| L2527 | 1 | 1 | Opponent | no | 2 | 1 | 3 | 5 | 0 | 0 | 0 | 190 |
| L2634 | 6 | 1 | Mine | no | 5 | 3 | 3 | 2 | 0 | 0 | 0 | 0 |
| L2634 | 6 | 1 | Opponent | no | 0 | 2 | 3 | 3 | 0 | 0 | 0 | 160 |
| L2930 | 2 | 1 | Mine | - | - | 2 | 5 | 1 | 0 | 0 | 0 | 0 |
| L2930 | 2 | 1 | Opponent | - | - | 6 | 1 | 3 | 0 | 0 | 0 | 0 |
| L3234 | 6 | 1 | Mine | no | 0 | 2 | 2 | 3 | 1 | 0 | 0 | 170 |
| L3234 | 6 | 1 | Opponent | no | 5 | 2 | 4 | 2 | 1 | 0 | 0 | 500 |
| **Average** | | | Mine | 39% | 2.6 | 2.8 | 2.6 | 1.2 | 0.4 | 0.0 | 0.0 | 294.2 |
| **Average** | | | Opponent | 50% | 2.5 | 2.4 | 2.3 | 2.5 | 0.3 | 0.0 | 0.0 | 183.7 |

### KPIs: fa-h2h-opp-8a94331-p4

Rules off - Mine only: FIVE ACTION, LIKELY CHARGE, FALLS SHORT, TIME ON OUR SIDE, FEATURE BUFFS, GETS AWAY CHANCE, GUN MASK, RUN DOWN, FOUR ROUNDS, CHARGE LOSSES, CHARACTER GUNS, STAND AND SHOOT, FALL BACK GOOD ORDER, AFTERMATH IN POINTS.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 22% (37 of 169) | 1% (2 of 186) | 11% (39 of 355) |
| Winner chose to follow up after the loser gave ground |  | 95% (40 of 42); on the table 98% | 88% (28 of 32); on the table 88% | 92% (68 of 74); on the table 93% |
| Winner chose to pursue after the loser fell back in good order |  | 93% (13 of 14); on the table 93% | 86% (12 of 14); on the table 93% | 89% (25 of 28); on the table 93% |
| Winner chose to pursue after the loser fled |  | 63% (17 of 27); on the table 67% | 74% (14 of 19); on the table 74% | 67% (31 of 46); on the table 70% |
| Winner chose to follow up or pursue (all three) |  | 84% (70 of 83); on the table 87% | 83% (54 of 65); on the table 85% | 84% (124 of 148); on the table 86% |
| Magic missiles tried each own turn | 50%+ | 30% (80 of 266) | 36% (63 of 176) | 32% (143 of 442) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 39% (80 of 205) | 47% (63 of 133) | 42% (143 of 338) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 60% (31 of 52) | 67% (40 of 60) | 63% (71 of 112) |
| Points that never fought | lower | 40% (27285 of 67942) | 41% (29431 of 71984) | 41% (56716 of 139926) |
|   infantry points that never fought | lower | 57% (8747 of 15347) | 66% (9055 of 13804) | 61% (17802 of 29151) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 56% (150 of 270) | 60% (168 of 280) | 58% (318 of 550) |
| Bound items with a magic missile used (at least once a game) |  | 86% (19 of 22); 1.6 uses a game | 89% (8 of 9); 0.6 uses a game | 87% (27 of 31); 1.1 uses a game |
| Bound items with another spell used |  | 31% (5 of 16); 0.3 uses a game | 30% (6 of 20); 0.2 uses a game | 31% (11 of 36); 0.3 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 53% (10 of 19); 0.3 uses a game | 80% (12 of 15); 0.3 uses a game | 65% (22 of 34); 0.3 uses a game |
|   their share of the points of units over 100 pts | lower | 50% (28834 of 57750) | 55% (34708 of 63347) | 52% (63542 of 121097) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.8 (34%) | 0.8 (26%) | 2.6 (31%) |
| MARCHED: its unit marched | 1.3 (26%) | 0.4 (14%) | 1.8 (21%) |
| CHARGED: its unit charged | 0.2 (5%) | 0.3 (11%) | 0.6 (7%) |
| IN COMBAT: engaged in combat | 0.9 (17%) | 0.4 (14%) | 1.3 (16%) |
| REAR RANK: in a rear rank | 0.0 (1%) | 0.3 (11%) | 0.4 (4%) |
| FLEEING: fleeing | 0.1 (2%) | 0.1 (4%) | 0.2 (2%) |
| GONE: slain | 0.8 (15%) | 0.5 (17%) | 1.3 (15%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (0%) | 0.1 (4%) | 0.1 (1%) |
| STUPIDITY: Stupidity | 0.1 (2%) | 0.0 (0%) | 0.1 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.3 | 1.6 | 1.6 | 4.0 | 0.5 | 1.9 |
| not cast | 2.9 | 2.3 | 3.2 | 8.3 | 1.5 | 21.1 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.3 (6%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.2 (52%) | 0.4 (11%) | 2.6 (31%) | 0.5 (34%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.8 (21%) | 0.4 (26%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.6 (7%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (1%) | 0.1 (2%) | 0.4 (13%) | 1.3 (16%) | 0.2 (13%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.2 (7%) | 0.2 (7%) | 0.3 (10%) | 0.4 (4%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.1 (4%) | 0.1 (4%) | 0.1 (3%) | 0.2 (2%) | 0.1 (6%) | 0.5 (2%) |
| GONE: slain | 0.9 (30%) | 0.3 (13%) | 0.7 (22%) | 1.3 (15%) | 0.0 (0%) | 3.6 (17%) |
| OFF THE TABLE: off the table or not arrived | 0.1 (3%) | 0.0 (1%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.1 (0%) |
| STUPIDITY: Stupidity | 0.1 (4%) | 0.0 (0%) | 0.0 (1%) | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (1%) | 0.3 (14%) | 0.0 (0%) | 0.0 (0%) | 0.3 (21%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.5 (51%) | 0.1 (6%) | 1.3 (41%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 15.4 (73%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.4 a game | 0.4 a game | 0.9 a game |
| stood (cast and not dispelled) | 74% (32 of 43) | 62% (5 of 8) | 73% (37 of 51) |
| the unit moved after it | 78% (25 of 32) | 80% (4 of 5) | 78% (29 of 37) |
| it charged on its next turn | 12% (4 of 32) | 0% (0 of 5) | 11% (4 of 37) |
| the enemy charged it first | 19% (6 of 32) | 0% (0 of 5) | 16% (6 of 37) |
| it fought by the end of its next turn | 9% (3 of 32) | 40% (2 of 5) | 14% (5 of 37) |
| it moved out of a charge the enemy had planned (not charged first) | 3% (1 of 32) | 0% (0 of 5) | 3% (1 of 37) |
| none of these (no charge, no fight, no charge escaped) | 69% (22 of 32) | 60% (3 of 5) | 68% (25 of 37) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 64% (599 of 929) | 60% (293 of 488) | 63% (892 of 1417) |
|   cavalry | 61% (54 of 88) | 77% (85 of 110) | 70% (139 of 198) |
|   character | 47% (49 of 105) | 27% (32 of 118) | 36% (81 of 223) |
|   chariot | 52% (59 of 114) | 67% (12 of 18) | 54% (71 of 132) |
|   infantry | 61% (167 of 274) | 71% (142 of 201) | 65% (309 of 475) |
|   monster | 48% (25 of 52) | 29% (7 of 24) | 42% (32 of 76) |
|   war machine | 83% (245 of 296) | 88% (15 of 17) | 83% (260 of 313) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.1 (23%) | 1.1 (19%) | 3.1 (22%) |
| CHARGED: it charged | 1.3 (14%) | 1.2 (22%) | 2.5 (17%) |
| FLEEING: it fled or was fleeing | 0.1 (1%) | 0.1 (1%) | 0.1 (1%) |
| IN COMBAT: it fought this turn or the last | 0.6 (7%) | 0.4 (8%) | 1.1 (7%) |
| MOVED: a war machine that moved | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) |
| HELD FIRE: a target, but it held its fire | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NO TARGET IN RANGE | 2.4 (26%) | 1.7 (31%) | 4.1 (28%) |
| ONLY IN COMBAT: the only targets were in combat | 0.5 (5%) | 0.4 (7%) | 0.8 (6%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.6 (17%) | 0.6 (11%) | 2.2 (15%) |
| SHELTERED: the target was sheltered | 0.3 (3%) | 0.0 (1%) | 0.3 (2%) |
| STUPIDITY | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) |
| OTHER BAR | 0.3 (4%) | 0.0 (0%) | 0.3 (2%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 6.0 | 1.2 | 83% | 4.5 pts | 27 pts |
| character | 2.6 | 0.5 | 85% | 4.8 pts | 12 pts |
| chariot | 2.0 | 0.8 | 76% | 9.7 pts | 19 pts |
| infantry | 12.6 | 4.8 | 74% | 10.3 pts | 130 pts |
| monster | 1.0 | 0.2 | 77% | 6.8 pts | 7 pts |
| war machine | 7.2 | 6.5 | 65% | 29.6 pts | 214 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.6 | 4.3 | 4.5 |
| Charges that made contact a game | 3.3 | 3.2 | 3.2 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.82 declared, 0.65 contact (17 units) | 0.67 declared, 0.44 contact (18 units) | 0.74 declared, 0.54 contact (35 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.78 declared, 0.78 contact (9 units) | 0.73 declared, 0.53 contact (15 units) | 0.75 declared, 0.62 contact (24 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.59 declared, 0.40 contact (247 units) | 0.44 declared, 0.33 contact (300 units) | 0.51 declared, 0.37 contact (547 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 63% (51 of 81) | 44% (7 of 16) | 67% (4 of 6) | 60% (62 of 103) |
| Character in a unit | 67% (18 of 27) | 42% (5 of 12) | 100% (1 of 1) | 60% (24 of 40) |
| Character on its own | 89% (34 of 38) | 63% (19 of 30) | 34% (26 of 77) | 54% (79 of 145) |
| Chariot | 47% (7 of 15) | 67% (8 of 12) | - | 56% (15 of 27) |
| Infantry | 53% (44 of 83) | 36% (9 of 25) | 33% (2 of 6) | 48% (55 of 114) |
| Monster | 65% (22 of 34) | 64% (9 of 14) | - | 65% (31 of 48) |
| Monstrous | 71% (10 of 14) | 71% (10 of 14) | - | 71% (20 of 28) |
| War Machines | 70% (30 of 43) | 100% (2 of 2) | - | 71% (32 of 45) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 91% (10 of 11); on the table 91% | 27% (28 of 102) | 21% | 41% (9 of 22) | 100% (6 of 6); 3.5 uses a game | 100% (2 of 2); 1.0 uses a game | 67% (4 of 6); 1.0 uses a game |
| Chaos Dwarfs | 4 | 80% (12 of 15); on the table 87% | 33% (8 of 24) | 31% | 56% (18 of 32) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
| Dwarfen Mountain Holds | 3 | 50% (3 of 6); on the table 67% | - | 74% | 56% (15 of 27) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 6 | 86% (12 of 14); on the table 86% | 50% (9 of 18) | 48% | 66% (41 of 62) | 0.0 uses a game | 50% (1 of 2); 0.7 uses a game | 80% (4 of 5); 0.7 uses a game |
| Grand Cathay | 4 | 64% (7 of 11); on the table 64% | 33% (28 of 84) | 49% | 49% (18 of 37) | 89% (8 of 9); 7.0 uses a game | 0% (0 of 2); 0.0 uses a game | 0% (0 of 4); 0.0 uses a game |
| High Elf Realms | 9 | 100% (12 of 12); on the table 100% | 39% (14 of 36) | 42% | 53% (37 of 70) | 100% (7 of 7); 2.3 uses a game | 27% (8 of 30); 1.3 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | 100% (1 of 1); on the table 100% | - | 50% | 33% (2 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Lizardmen | 3 | 100% (13 of 13); on the table 100% | 67% (4 of 6) | 34% | 62% (13 of 21) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 2 | 100% (2 of 2); on the table 100% | 50% (3 of 6) | 56% | 86% (12 of 14) | 50% (1 of 2); 1.5 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 3 | 86% (6 of 7); on the table 86% | 17% (7 of 42) | 11% | 71% (17 of 24) | 0.0 uses a game | 0.0 uses a game | 67% (2 of 3); 0.7 uses a game |
| Skaven | 6 | 78% (7 of 9); on the table 89% | 32% (13 of 41) | 43% | 56% (25 of 45) | 67% (2 of 3); 0.8 uses a game | 0.0 uses a game | 67% (4 of 6); 0.7 uses a game |
| Tomb Kings of Khemri | 4 | 80% (4 of 5); on the table 80% | 17% (1 of 6) | 46% | 40% (8 of 20) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 8 | 100% (12 of 12); on the table 100% | 31% (18 of 59) | 50% | 69% (29 of 42) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 9 | 86% (12 of 14); on the table 86% | 58% (7 of 12) | 27% | 56% (40 of 72) | 100% (2 of 2); 0.7 uses a game | 0.0 uses a game | 100% (3 of 3); 0.3 uses a game |
| Wood Elf Realms | 6 | 69% (11 of 16); on the table 69% | 50% (3 of 6) | 42% | 61% (34 of 56) | 50% (1 of 2); 0.5 uses a game | 0.0 uses a game | 75% (3 of 4); 0.5 uses a game |

Flank and rear charges a unit could have turned to face (fa-h2h-opp-8a94331-p4, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 48% (38) | 51% (33) | 49% (71) |
| ...free all their last turn and able to turn (per game) | 0.69 | 0.64 | 1.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.17 | 0.08 | 0.25 |
| ...with the charger already in that arc before they moved (per game) | 0.56 | 0.44 | 1.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 1.39 | 0.00 | 1.39 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 1.14 | 0.03 | 1.17 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 6.06 | 0.17 | 6.22 |

### Quality by phase: fa-h2h-opp-8a94331-p4

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.1 | 3.6 |
| Strategy | Charge objectives carried out (made contact) | 49% (73 of 148) | 59% (70 of 118) |
| Strategy | Shoot objectives carried out (shot that target) | 46% (206 of 449) | 36% (43 of 120) |
| Strategy | Close-in objectives charged next turn | 19% (34 of 179) | - |
| Strategy | Support requests answered (helper made contact too) | 38% (5 of 13) | 54% (7 of 13) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (1 of 1) | - |
| Strategy | Hexes on a unit its side charged or shot that turn | 40% (4 of 10) | 36% (4 of 11) |
| Strategy | Joined characters whose unit fought | 49% (22 of 45) | 39% (9 of 23) |
| Strategy | Lone characters that fought | 73% (57 of 78) | 71% (66 of 93) |
| Movement | Charges halted short of contact | 0.2 | 0.1 |
| Movement | Idle units | 1.2 | 2.5 |
| Movement | Points that never moved of their own | 294.2 | 183.7 |
| Movement | Fights charged into per game | 2.9 | 2.8 |
| Movement | Charges with odds: long shots (under 50%) | 17 of 95, net +150 | 13 of 85, net +51 |
| Movement | Charges with odds: sweet spot (55-75%) | 11 of 95, net +27 | 20 of 85, net +48 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 4 of 95, net -13 | 9 of 85, net +50 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 37 of 95, net +66 | 21 of 85, net +102 |
| Shooting | Shots by shooting units (incl. breath weapons) | 10.6 | 9.2 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 51% (194 of 383) | 42% (140 of 333) |
| Shooting | Points destroyed by shooting units | 79.3 | 75.8 |
| Shooting | War machine shots | 6.8 | 0.4 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 56% (136 of 245) | 7% (1 of 15) |
| Shooting | Points destroyed by war machines | 84.1 | 9.4 |
| Magic | Magic missiles cast | 1.6 | 1.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 26% (15 of 57) | 33% (15 of 46) |
| Magic | Wounds caused by magic missiles | 4.0 | 1.5 |
| Magic | Wounds caused by other spells | 2.2 | 1.0 |
| Magic | Points destroyed by magic (all spells) | 100.1 | 12.3 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.1 / 0.3 / 0.9 / 0.3 | 1.9 / 0.5 / 0.4 / 0.0 |
| Combat | Points destroyed in combat | 309.3 | 343.1 |
| Combat | Points run down | 77.2 | 65.8 |
| Combat | Net points per charged fight, damage counted | +84 | +53 |
| Combat | Net per 100 charger points, damage counted | +30.7 | +19.1 |
| Combat | First round won (charged fights) | 77% | 69% |
| Combat | Net points per charged fight | +79 | +51 |
| Combat | Net points per supported fight / lone fight | +202 / +62 | -98 / +64 |
| Combat | Charged fights on a top-3 enemy unit | 35 of 106 | 48 of 102 |
| Game | Points lost | 577.0 | 776.1 |
| Game | VP from objectives | 622.5 | 431.9 |
| Game | Lone holders (player turns) | 2.6 | 2.5 |

- Mine won / drew / lost: 18 / 10 / 8 of 36 ended games (of 36); mean margin (Mine - Opponent) +408 VP
- The side that went first won 16 of 26 games with a winner
- Points traded per game (both sides' losses): 1353
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: fa-h2h-opp-8a94331-p4

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 0.8 | +0.0 | 0.0 | 4.0 |
| ADVANCE WORTH | 5.9 | -154.6 | 222.2 | 114.4 | - | - | - | - |
| AFTERMATH IN POINTS | - | - | - | - | 0.1 | +16.4 | 0.0 | 10.9 |
| ALREADY CARRIED | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARRIVAL HUNT | - | - | - | - | 0.0 | +0.5 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.3 | +0.0 | 0.0 | 3.6 | 0.1 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | 0.4 | +1.2 | 0.0 | 9.6 | 0.7 | +4.2 | 0.0 | 21.6 |
| BEST FACING | 0.3 | +12.7 | 0.0 | 15.8 | - | - | - | - |
| BEST FIRST | 1.2 | +59.6 | 20.9 | 20.7 | - | - | - | - |
| BEST OVERALL | 0.3 | +26.2 | 0.0 | 12.1 | - | - | - | - |
| BEST PREY | 0.6 | +34.7 | 3.6 | 13.6 | - | - | - | - |
| BEST PRIZE | 0.0 | -0.8 | 0.0 | 0.0 | 0.0 | -0.5 | 0.0 | 0.0 |
| BIG CHARACTER SAFETY | 0.2 | -0.1 | 0.0 | 24.1 | - | - | - | - |
| BLOCKED CHARGE SKIPPED | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| BLOCKED WHEEL | 0.5 | +10.4 | 0.0 | 1.8 | - | - | - | - |
| BLOWS WHERE AIMED | 0.2 | -11.6 | 31.5 | 11.0 | 0.2 | -35.3 | 32.6 | 7.4 |
| BOMBING RUN | 0.1 | +2.1 | 0.0 | 0.0 | - | - | - | - |
| CANNON PLAN MISSED | 0.7 | +0.0 | 119.1 | 0.0 | 0.0 | +0.0 | 1.7 | 0.0 |
| CANNON PLANNED TARGET | 5.6 | +133.1 | 430.9 | 35.7 | 0.4 | +23.0 | 26.1 | 10.8 |
| CANNON SIGHT KEPT | 1.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT COUNTER | 0.0 | +0.0 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT SET-UP | 0.2 | +0.0 | 46.4 | 1.4 | 0.1 | -0.1 | 6.2 | 0.0 |
| CAST JOB | 0.9 | +39.1 | 68.2 | 17.0 | 0.1 | +0.2 | 7.8 | 0.0 |
| CASTER AWAY FROM SCREEN | 0.3 | +0.0 | 0.0 | 9.3 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.4 | +29.1 | 15.2 | 0.0 | 0.1 | +3.7 | 5.1 | 0.0 |
| CASTS AFTER FRIENDS | 1.0 | +0.0 | 0.0 | 14.6 | 0.2 | +0.0 | 0.0 | 21.9 |
| CASTS FROM BEHIND | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.0 | +1.9 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | 1.0 | +66.8 | 0.0 | 16.2 | 0.8 | +30.1 | 0.0 | 7.3 |
| CHAFF PASSED | 0.1 | -0.2 | 0.0 | 0.0 | 0.2 | -0.3 | 15.0 | 0.0 |
| CHARACTER GUNS | - | - | - | - | 0.2 | +0.0 | 0.0 | 0.0 |
| CHARGE LOSSES | - | - | - | - | 10.4 | -317.0 | 0.0 | 412.2 |
| CHARGE NOW FIRST | 2.8 | +0.0 | 268.0 | 61.1 | 1.8 | +0.0 | 206.2 | 71.6 |
| CHARGE NOW WEIGHED | 0.5 | -27.5 | 20.3 | 38.9 | - | - | - | - |
| CHARGER SLAIN LOST | 0.5 | -7.8 | 46.9 | 11.0 | 0.6 | -24.4 | 48.6 | 34.4 |
| CHARIOT NO STATIC JOB | 0.1 | +0.0 | 7.9 | 0.0 | - | - | - | - |
| CHARIOT WIZARD CAREFUL | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHEAP HELPER | 0.1 | +0.0 | 14.8 | 1.5 | 0.1 | +0.0 | 13.6 | 1.0 |
| COMBAT PIVOT | 0.4 | +0.0 | 11.0 | 4.7 | 0.4 | +0.0 | 28.9 | 44.2 |
| CONTINUE AHEAD WEIGHED | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CONVEYANCE SEARCH | 0.9 | +88.5 | 2.4 | 21.5 | 0.2 | +11.8 | 0.0 | 11.1 |
| COVER ONCE | 8.0 | -456.8 | 0.0 | 232.0 | 5.7 | -379.0 | 0.0 | 161.6 |
| DEFENSIVE ARMY | 0.2 | +0.0 | 25.8 | 1.0 | - | - | - | - |
| DEFENSIVE FLOOR | 0.0 | +0.8 | 0.0 | 0.0 | - | - | - | - |
| EDGE GIVE GROUND | 0.1 | +3.0 | 11.3 | 5.6 | 0.1 | +2.2 | 9.1 | 0.0 |
| ELIXIR WORTH | - | - | - | - | 0.1 | +0.5 | 0.0 | 0.0 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 1.4 | +74.2 | 0.0 | 52.3 | - | - | - | - |
| FALL BACK GOOD ORDER | - | - | - | - | 2.3 | +2.8 | 231.9 | 53.6 |
| FALLBACK BY WORTH | 4.7 | +36.0 | 0.0 | 27.4 | 0.3 | +0.9 | 0.0 | 1.2 |
| FALLS SHORT | - | - | - | - | 0.5 | -3.2 | 0.0 | 8.7 |
| FEATURE BUFFS | - | - | - | - | 0.6 | +10.8 | 0.0 | 22.2 |
| FIGHT LIFT | 0.1 | +1.2 | 4.0 | 0.0 | - | - | - | - |
| FIRE AND FLEE | - | - | - | - | 0.1 | +0.5 | 0.0 | 3.5 |
| FIVE ACTION | - | - | - | - | 42.9 | +2594.8 | 572.0 | 793.8 |
| FLANK NOT WEIGHED | 5.4 | +0.0 | 0.0 | 153.6 | 5.2 | +0.0 | 0.0 | 182.6 |
| FOCUS FIRE | - | - | - | - | 0.0 | +0.3 | 1.2 | 0.0 |
| FOLLOW UP WEIGHED | 0.6 | +67.2 | 0.0 | 23.3 | 0.7 | +96.7 | 0.0 | 22.9 |
| FOUR ROUNDS | - | - | - | - | 3.2 | +208.6 | 289.2 | 81.6 |
| FRIENDS SHOTS CHECKED | 0.2 | +6.4 | 0.0 | 17.7 | 0.1 | +9.8 | 0.0 | 21.2 |
| GIVES UP | 0.1 | -0.8 | 9.1 | 0.0 | 0.1 | -1.8 | 9.1 | 0.0 |
| GROUND FLIERS | 0.1 | +1.2 | 0.0 | 0.0 | 0.1 | +1.9 | 0.0 | 0.0 |
| HELPER ALREADY ASKED | 0.0 | +0.0 | 1.9 | 0.0 | - | - | - | - |
| HELPER UNSEEN | 0.5 | +0.0 | 59.9 | 16.9 | 0.3 | +0.0 | 26.4 | 7.6 |
| HILL BY ITS CHANCE | 0.9 | -53.9 | 0.0 | 5.8 | - | - | - | - |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 8.3 | -157.1 | 572.4 | 147.4 | 2.3 | -110.9 | 202.4 | 41.9 |
| HUNT ADVANCE | 0.1 | +0.1 | 5.4 | 0.0 | - | - | - | - |
| HUNT DROPPED | 0.0 | +0.0 | 5.4 | 0.0 | 0.1 | +0.0 | 0.0 | 1.2 |
| HUNT IN PAIRS | 0.6 | +13.7 | 0.0 | 6.0 | 0.6 | +22.0 | 0.0 | 19.3 |
| HUNT KEPT | 0.0 | +0.0 | 5.4 | 0.0 | 0.0 | +0.0 | 4.6 | 1.2 |
| HUNT RESULT | 0.0 | +0.0 | 5.4 | 0.0 | 0.1 | +15.2 | 2.6 | 2.5 |
| HUNT THE GUNS | 0.0 | +6.2 | 0.0 | 0.0 | 0.1 | +30.1 | 10.7 | 0.0 |
| IDLE COST | 17.6 | -279.9 | 0.0 | 218.1 | 22.5 | -354.4 | 0.0 | 279.4 |
| INVITES THE FIGHT | 1.3 | +8.2 | 41.5 | 28.3 | - | - | - | - |
| JOINT CHARGE PLAN | 0.1 | +0.3 | 15.0 | 0.0 | - | - | - | - |
| JOINT KNOWS CHALLENGE | 0.0 | -2.8 | 0.0 | 0.0 | 0.1 | -5.0 | 7.2 | 7.4 |
| KEEP FALLS | 0.0 | +0.6 | 0.0 | 0.0 | 0.1 | +0.7 | 0.0 | 0.0 |
| KEEPS ITS PREY | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KEEPS ITS TARGET | 2.2 | +65.8 | 191.5 | 27.5 | - | - | - | - |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KILLS COUNT | 1.6 | +63.1 | 139.6 | 44.9 | 1.5 | +112.7 | 136.9 | 10.0 |
| KILLS COUNT NEXT TURN | 5.2 | +160.3 | 293.4 | 89.6 | - | - | - | - |
| LONE CHARACTER SAFE SPOT | 0.4 | +17.7 | 7.1 | 28.1 | 0.0 | +2.5 | 0.0 | 0.0 |
| LONE WIZARD HOLDS BACK | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| LONE WIZARD KEPT IN | 0.6 | +26.9 | 0.0 | 0.0 | 0.2 | +20.3 | 0.0 | 0.0 |
| LONG SHOT | 0.4 | +1.4 | 22.2 | 0.0 | 0.2 | +0.1 | 12.3 | 9.4 |
| LOST CHARGE | 2.7 | -34.1 | 200.1 | 40.9 | 0.1 | -0.1 | 12.3 | 0.0 |
| LURE BY WHAT IT DRAWS | 0.2 | -23.8 | 0.0 | 5.0 | 0.0 | -3.4 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 0.5 | +49.7 | 75.7 | 11.1 | 0.5 | +28.4 | 0.0 | 15.0 |
| MANOEUVRE | 0.1 | +2.4 | 0.0 | 0.0 | 0.5 | +4.0 | 0.0 | 12.9 |
| MARCH AT ESCAPER | 0.1 | +0.6 | 0.0 | 7.2 | 0.1 | +1.6 | 0.0 | 5.4 |
| MARCH CHECK | 0.4 | +13.5 | 0.0 | 2.2 | 0.3 | +24.2 | 0.0 | 43.6 |
| MARCH ODDS | 0.3 | +16.6 | 16.9 | 21.6 | 0.1 | +0.8 | 0.0 | 0.0 |
| MARCH OVER CASTS | 0.5 | +56.2 | 0.0 | 35.8 | 0.4 | +27.9 | 0.0 | 42.3 |
| MAX FOR POSITIONING | 6.8 | +96.7 | 0.0 | 167.4 | 7.6 | +113.7 | 0.0 | 200.5 |
| MISSILES IN THE MOVE | 4.2 | +134.2 | 0.0 | 54.5 | 2.2 | +32.9 | 0.0 | 75.7 |
| MISSILES NEXT TURN | 4.8 | +78.8 | 0.0 | 87.4 | 2.9 | +26.6 | 0.0 | 144.2 |
| MODEL FACING | 0.3 | +68.8 | 0.0 | 5.0 | - | - | - | - |
| MONSTER WIZARD ROAMS | 0.1 | +0.0 | 11.9 | 0.0 | - | - | - | - |
| MOVE AND CAST | 0.4 | +10.5 | 0.0 | 10.0 | - | - | - | - |
| MOVE SPELL IN RANGE | 0.2 | +7.9 | 0.0 | 2.4 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.5 | -21.6 | 8.7 | 32.6 | 0.1 | -3.4 | 0.0 | 0.0 |
| MOVE SPELL SPOT | 0.7 | +0.0 | 0.0 | 12.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE | 3.5 | +181.8 | 201.7 | 52.3 | - | - | - | - |
| MOVES UNITS SPELL | 0.1 | +3.3 | 0.0 | 0.0 | 0.1 | +0.6 | 0.0 | 0.0 |
| NEEDED THERE | 0.0 | +1.2 | 0.0 | 0.0 | 0.0 | +6.6 | 0.0 | 0.0 |
| NO RALLY LEFT | 0.0 | +1.0 | 0.0 | 0.0 | - | - | - | - |
| NOT NEEDED | 0.4 | -13.7 | 40.6 | 0.0 | - | - | - | - |
| NOT TURNED | 6.1 | +153.1 | 0.0 | 152.2 | 0.2 | +1.2 | 0.0 | 1.5 |
| NOT WORTH A CAST | 0.5 | -0.5 | 0.0 | 10.6 | 0.3 | -2.6 | 0.0 | 0.0 |
| OFF BEST | 16.3 | -681.4 | 25.2 | 215.9 | 1.3 | -42.7 | 0.0 | 26.2 |
| ONE FIGHT FORMULA | 9.2 | -154.8 | 37.0 | 223.3 | 8.4 | -188.3 | 0.0 | 220.8 |
| ONE OBJECTIVE FORMULA | 2.7 | -176.4 | 0.0 | 18.3 | 2.0 | -24.8 | 0.0 | 47.4 |
| OPENS A LANE | 0.2 | +0.9 | 30.8 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| OPENS UP | 0.3 | +20.9 | 20.1 | 5.7 | 0.1 | +6.1 | 7.0 | 0.0 |
| OVERRUNS AWAY | 0.6 | +17.5 | 67.5 | 6.2 | 0.3 | +3.4 | 19.4 | 7.3 |
| PATHS CROSS | 2.6 | +212.4 | 0.0 | 34.1 | 2.5 | +190.1 | 0.0 | 46.2 |
| PERIAPT WORTH | 0.0 | +3.5 | 0.0 | 15.0 | 0.1 | +7.6 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.1 | -1.3 | 0.0 | 18.5 | 0.1 | -1.1 | 0.0 | 1.9 |
| PLAN RESULT | 41.2 | +1516.5 | 1475.6 | 769.8 | 39.2 | +530.3 | 277.6 | 1102.9 |
| PURSUES BIG PREY | - | - | - | - | 0.0 | -0.5 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE NEXT TURN | 0.1 | +3.0 | 0.0 | 0.0 | - | - | - | - |
| RANDOM MOVE BY FIGURES | 1.4 | +29.9 | 0.0 | 32.8 | 1.7 | +45.3 | 0.0 | 87.5 |
| RANDOM MOVER NO PROMISE | 0.2 | -3.9 | 1.9 | 0.0 | - | - | - | - |
| REDIRECT BY WHAT IT STOPS | 0.7 | -12.7 | 0.0 | 11.2 | 0.5 | -2.5 | 0.0 | 2.5 |
| REDIRECT COUNTER | 2.7 | +155.2 | 0.0 | 23.2 | 4.4 | +203.1 | 0.0 | 71.7 |
| REDIRECT WEIGHED | 0.2 | +3.2 | 4.9 | 0.8 | 0.3 | +2.9 | 0.0 | 3.9 |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 17.9 | 0.1 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | 0.4 | +11.3 | 0.0 | 3.8 | 0.9 | +20.9 | 0.0 | 13.7 |
| RESTRAINS TO SHOOT | 0.1 | +9.2 | 0.0 | 5.1 | 0.1 | +2.1 | 0.0 | 10.9 |
| RISK BY ARC | 2.9 | +111.8 | 325.3 | 75.7 | 2.1 | +35.4 | 225.1 | 50.6 |
| RISK ONCE | 1.6 | +32.0 | 1.2 | 141.3 | - | - | - | - |
| RUN DOWN | - | - | - | - | 1.9 | -24.5 | 150.8 | 74.2 |
| SAFER THAN THE JOB | 1.1 | +76.1 | 0.0 | 8.5 | 0.0 | +0.5 | 0.0 | 0.0 |
| SCOUT SPOT | 0.4 | +0.5 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| SCOUT WAITS | 0.5 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.1 | -7.4 | 0.0 | 0.0 | 0.2 | -18.7 | 0.0 | 2.3 |
| SEARCH SPOT | 2.2 | +99.9 | 0.0 | 37.2 | 5.0 | +146.1 | 0.0 | 117.8 |
| SELF MOVE SPELL | 0.2 | +31.7 | 0.0 | 0.0 | 0.4 | +10.8 | 0.0 | 40.1 |
| SET UP TOGETHER | 0.7 | +62.1 | 80.4 | 15.3 | 0.7 | +30.9 | 0.0 | 15.0 |
| SET-UP ANY TARGET | 0.5 | +67.1 | 0.0 | 9.3 | 0.1 | +11.4 | 0.0 | 11.1 |
| SET-UP MISSED | 0.1 | +8.4 | 2.4 | 2.4 | 0.0 | +6.2 | 0.0 | 0.0 |
| SHOOTER COUNTED ONCE | 0.0 | -0.0 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | 0.3 | +0.8 | 0.0 | 0.0 | 0.2 | +0.3 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.5 | +75.9 | 51.5 | 22.5 | 0.6 | +20.8 | 14.9 | 12.2 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 3.3 | 0.0 | +0.0 | 0.0 | 3.8 |
| SHOT REPLANNED | 0.7 | +0.0 | 115.0 | 0.0 | 0.3 | +0.0 | 68.1 | 1.9 |
| SHOTS IN THE MOVE | 15.9 | +631.3 | 0.0 | 204.9 | 8.0 | +322.7 | 0.0 | 132.1 |
| SPELL SETS UP CHARGE | 0.6 | +95.0 | 0.0 | 9.3 | 0.1 | +11.4 | 0.0 | 11.1 |
| SPELL WORTH | 1.4 | +14.8 | 22.9 | 34.7 | 2.2 | +42.4 | 82.2 | 82.2 |
| SPELLS IN THE FIGHT | 0.7 | -0.8 | 121.6 | 8.1 | 0.5 | -5.8 | 26.8 | 18.6 |
| STABLE ROLE | 11.8 | +0.0 | 411.9 | 203.2 | - | - | - | - |
| STAND AND SHOOT | - | - | - | - | 0.5 | -4.0 | 41.7 | 6.5 |
| STANDS TO CAST | 0.0 | +1.1 | 0.0 | 2.2 | - | - | - | - |
| STAY WEIGHED | 0.1 | +5.6 | 0.0 | 3.6 | - | - | - | - |
| STOPS | - | - | - | - | 0.1 | +3.9 | 10.7 | 0.0 |
| STOPS SHORT OF THE FLANK | 0.6 | +38.4 | 0.0 | 13.9 | - | - | - | - |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 8.8 |
| SUPPORT NARROWED | 7.6 | -68.9 | 317.2 | 155.8 | 1.2 | +0.0 | 150.7 | 53.0 |
| SUPPORTS | 5.4 | +73.9 | 105.1 | 119.6 | - | - | - | - |
| SURE CHARGE BEATS ADVANCE | 0.1 | -4.7 | 10.3 | 0.0 | - | - | - | - |
| SURE REACH TOGETHER | 0.4 | +0.8 | 16.9 | 20.4 | 0.6 | +7.0 | 0.0 | 1.6 |
| THROUGH LINE OF FIRE | 0.3 | +5.5 | 0.0 | 7.0 | - | - | - | - |
| TIME ON OUR SIDE | - | - | - | - | 1.7 | +0.0 | 36.3 | 5.3 |
| TURN WORTH | 0.4 | -30.9 | 37.8 | 13.9 | 0.0 | -0.6 | 1.1 | 0.0 |
| TWO OR MORE ARRIVE | 0.2 | +1.0 | 61.9 | 4.2 | 0.0 | +0.0 | 0.0 | 0.0 |
| WAIT AFTER COSTS | 7.2 | -300.8 | 323.5 | 120.1 | - | - | - | - |
| WALKS TO THE FIGHT | 1.8 | +10.7 | 49.1 | 27.4 | - | - | - | - |
| WAR ENGINE CHARGES | 0.1 | +6.3 | 4.7 | 8.6 | - | - | - | - |
| WAR ENGINE JOBS | 0.8 | +0.0 | 33.3 | 23.6 | 0.0 | +0.0 | 1.8 | 4.0 |
| WEARS DOWN | 1.4 | +48.3 | 199.3 | 21.3 | 0.9 | +37.6 | 77.4 | 65.9 |
| WHO HITS BACK | 0.3 | +37.3 | 0.0 | 15.6 | 0.3 | +15.4 | 0.0 | 7.2 |
| WHOLE FIGHT | 0.3 | +19.7 | 22.3 | 2.9 | 0.2 | +8.0 | 27.8 | 1.8 |
| WHOLE FIGHT GAIN | 0.3 | +20.4 | 39.7 | 3.8 | 0.3 | +21.2 | 34.2 | 8.1 |
| WIDER SPREAD | 2.9 | -11.6 | 282.8 | 80.4 | 2.4 | -9.7 | 228.6 | 64.2 |
| WOUNDED STAYS OUT | - | - | - | - | 0.0 | +0.0 | 1.1 | 0.0 |

### Rule changes: fa-h2h-opp-8a94331-p4

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 635 | 635 | 635 | 17.64 | -26069 | -41.1 |
| SEARCH SPOT | 260 | 260 | 252 | 7.00 | +8855 | +35.1 |
| PATHS CROSS | 184 | 184 | 184 | 5.11 | +14492 | +78.8 |
| IDLE COST | 1443 | 786 | 104 | 2.89 | +1152 | +11.1 |
| SHOTS IN THE MOVE | 858 | 630 | 98 | 2.72 | +4314 | +44.0 |
| MAX FOR POSITIONING | 516 | 410 | 90 | 2.50 | +349 | +3.9 |
| SUPPORTS | 193 | 193 | 84 | 2.33 | +1022 | +12.2 |
| RANDOM MOVE BY FIGURES | 112 | 112 | 71 | 1.97 | +2709 | +38.2 |
| COVER ONCE | 494 | 280 | 70 | 1.94 | +1921 | +27.4 |
| MOVE TO CHARGE | 125 | 125 | 69 | 1.92 | +1993 | +28.9 |
| REDIRECT COUNTER | 256 | 158 | 65 | 1.81 | +3872 | +59.6 |
| CHARGE LOSSES | 373 | 373 | 64 | 1.78 | +2746 | +42.9 |
| ADVANCE LANE KEPT | 55 | 55 | 55 | 1.53 | +0 | +0.0 |
| KILLS COUNT NEXT TURN | 186 | 186 | 55 | 1.53 | +1069 | +19.4 |
| ARTILLERY RE-ROLL WEIGHED | 51 | 51 | 51 | 1.42 | +0 | +0.0 |
| FACES THE THREAT | 50 | 50 | 50 | 1.39 | +2673 | +53.5 |
| CHAFF IN THE MOVE | 67 | 62 | 48 | 1.33 | +745 | +15.5 |
| RESERVE FALL BACK | 47 | 47 | 47 | 1.31 | +1159 | +24.7 |
| FOLLOW UP WEIGHED | 46 | 46 | 46 | 1.28 | +5902 | +128.3 |
| MISSILES IN THE MOVE | 232 | 157 | 46 | 1.28 | +1000 | +21.7 |
| SHOOTS FROM THE BEST SPOT | 75 | 75 | 45 | 1.25 | +1091 | +24.2 |
| BEST FIRST | 44 | 44 | 44 | 1.22 | +2146 | +48.8 |
| CANNON SIGHT KEPT | 42 | 42 | 42 | 1.17 | +0 | +0.0 |
| SAFER THAN THE JOB | 42 | 42 | 42 | 1.17 | +2758 | +65.7 |
| RISK BY ARC | 181 | 175 | 40 | 1.11 | +1032 | +25.8 |
| FOUR ROUNDS | 114 | 113 | 39 | 1.08 | +2254 | +57.8 |
| CANNON PLANNED TARGET | 215 | 215 | 37 | 1.03 | -460 | -12.4 |
| SHOT REPLANNED | 36 | 36 | 36 | 1.00 | +0 | +0.0 |
| HOLDS AMBUSHERS | 35 | 35 | 35 | 0.97 | +0 | +0.0 |
| KILLS COUNT | 109 | 108 | 35 | 0.97 | +1517 | +43.3 |
| WAIT AFTER COSTS | 259 | 259 | 35 | 0.97 | +504 | +14.4 |
| ONE FIGHT FORMULA | 635 | 344 | 33 | 0.92 | +108 | +3.3 |
| ADVANCE WORTH | 213 | 213 | 30 | 0.83 | +558 | +18.6 |
| COMBAT PIVOT | 29 | 29 | 29 | 0.81 | +0 | +0.0 |
| LONE WIZARD KEPT IN | 28 | 28 | 28 | 0.78 | +1699 | +60.7 |
| CHARGE NOW FIRST | 168 | 168 | 27 | 0.75 | -802 | -29.7 |
| FALLBACK BY WORTH | 178 | 178 | 27 | 0.75 | +1330 | +49.2 |
| MARCH CHECK | 28 | 27 | 25 | 0.69 | +716 | +28.6 |
| WALKS TO THE FIGHT | 66 | 66 | 24 | 0.67 | +103 | +4.3 |
| WHO HITS BACK | 24 | 24 | 24 | 0.67 | +1196 | +49.8 |
| FIVE ACTION | 1545 | 1544 | 23 | 0.64 | +1401 | +60.9 |
| STOPS SHORT OF THE FLANK | 22 | 22 | 22 | 0.61 | +1382 | +62.8 |
| CAST JOB | 35 | 35 | 21 | 0.58 | +629 | +30.0 |
| SCOUT WAITS | 21 | 21 | 21 | 0.58 | +0 | +0.0 |
| ONE OBJECTIVE FORMULA | 169 | 101 | 18 | 0.50 | +385 | +21.4 |
| SHOOTERS IN TWO RANKS | 18 | 18 | 18 | 0.50 | +41 | +2.3 |
| BLOCKED WHEEL | 17 | 17 | 17 | 0.47 | +375 | +22.0 |
| CASTER AWAY FROM SCREEN | 17 | 17 | 17 | 0.47 | +0 | +0.0 |
| CHARGE NOW WEIGHED | 17 | 17 | 17 | 0.47 | +535 | +31.5 |
| HONEST WORTH | 384 | 379 | 17 | 0.47 | +77 | +4.5 |
| REDIRECT WEIGHED | 16 | 16 | 16 | 0.44 | +815 | +50.9 |
| WAR ENGINE JOBS | 30 | 30 | 16 | 0.44 | -497 | -31.0 |
| WEARS DOWN | 83 | 80 | 16 | 0.44 | +632 | +39.5 |
| MOVE AND CAST | 15 | 15 | 15 | 0.42 | +378 | +25.2 |
| MANOEUVRE | 23 | 23 | 14 | 0.39 | +237 | +16.9 |
| STUCK PIVOT | 14 | 14 | 14 | 0.39 | +0 | +0.0 |
| INVITES THE FIGHT | 47 | 47 | 13 | 0.36 | +61 | +4.7 |
| MARCH ODDS | 13 | 13 | 13 | 0.36 | +218 | +16.8 |
| CHAFF PASSED | 12 | 12 | 12 | 0.33 | -18 | -1.5 |
| FRIENDS SHOTS CHECKED | 12 | 12 | 12 | 0.33 | +580 | +48.3 |
| MODEL FACING | 12 | 12 | 12 | 0.33 | +2477 | +206.4 |
| SET UP TOGETHER | 50 | 33 | 12 | 0.33 | +499 | +41.6 |
| BEST OVERALL | 11 | 11 | 11 | 0.31 | +945 | +85.9 |
| BEST FACING | 10 | 10 | 10 | 0.28 | +459 | +45.9 |
| HUNT IN PAIRS | 41 | 23 | 10 | 0.28 | +347 | +34.7 |
| KEEPS ITS TARGET | 79 | 79 | 10 | 0.28 | +206 | +20.6 |
| OPENS UP | 16 | 16 | 10 | 0.28 | +345 | +34.5 |
| THROUGH LINE OF FIRE | 10 | 10 | 10 | 0.28 | +198 | +19.8 |
| CASTS FROM BEHIND | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| MISSILES NEXT TURN | 277 | 171 | 9 | 0.25 | +40 | +4.4 |
| REFUSING RETIRES | 14 | 14 | 9 | 0.25 | -2 | -0.2 |
| SHORT GUN FORWARD | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| SURE REACH TOGETHER | 36 | 34 | 9 | 0.25 | +51 | +5.6 |
| WHOLE FIGHT GAIN | 24 | 23 | 9 | 0.25 | +226 | +25.1 |
| BIG CHARACTER SAFETY | 8 | 8 | 8 | 0.22 | -3 | -0.4 |
| CASTING BLOCK | 16 | 16 | 8 | 0.22 | +344 | +43.0 |
| SUPPORT NARROWED | 319 | 319 | 8 | 0.22 | -172 | -21.5 |
| BEST PREY | 23 | 23 | 7 | 0.19 | +389 | +55.5 |
| MOVES UNITS SPELL | 7 | 7 | 7 | 0.19 | +138 | +19.7 |
| PIVOT GUARDS FLANK | 7 | 7 | 7 | 0.19 | -87 | -12.4 |
| RESTRAINS TO SHOOT | 6 | 6 | 6 | 0.17 | +406 | +67.6 |
| RISK ONCE | 56 | 46 | 6 | 0.17 | +184 | +30.7 |
| LOST CHARGE | 100 | 98 | 5 | 0.14 | +210 | +42.1 |
| SURE CHARGE BEATS ADVANCE | 5 | 5 | 5 | 0.14 | -168 | -33.6 |
| WIDER SPREAD | 194 | 187 | 5 | 0.14 | +22 | +4.4 |
| AFTERMATH IN POINTS | 4 | 4 | 4 | 0.11 | +590 | +147.4 |
| PERIAPT WORTH | 4 | 4 | 4 | 0.11 | +401 | +100.2 |
| STAY WEIGHED | 4 | 4 | 4 | 0.11 | +203 | +50.7 |
| FALL BACK GOOD ORDER | 83 | 82 | 3 | 0.08 | +9 | +3.0 |
| FEATURE BUFFS | 21 | 21 | 3 | 0.08 | +85 | +28.3 |
| FIRE AND FLEE | 3 | 3 | 3 | 0.08 | +17 | +5.8 |
| KEEP FALLS | 3 | 3 | 3 | 0.08 | +160 | +53.3 |
| MAKE SURE TOGETHER | 37 | 15 | 3 | 0.08 | +188 | +62.8 |
| WHOLE FIGHT | 17 | 17 | 3 | 0.08 | +36 | +12.1 |
| BEST PRIZE | 2 | 2 | 2 | 0.06 | -47 | -23.6 |
| BOMBING RUN | 2 | 2 | 2 | 0.06 | +75 | +37.4 |
| CONTINUE AHEAD WEIGHED | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| EDGE GIVE GROUND | 7 | 7 | 2 | 0.06 | +120 | +60.2 |
| ELIXIR WORTH | 2 | 2 | 2 | 0.06 | +19 | +9.4 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| NEEDED THERE | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| OVERRUNS AWAY | 32 | 31 | 2 | 0.06 | +49 | +24.4 |
| RAIDS THE BAGGAGE NEXT TURN | 2 | 2 | 2 | 0.06 | +65 | +32.5 |
| REDIRECT BY WHAT IT STOPS | 42 | 42 | 2 | 0.06 | +13 | +6.5 |
| SPELLS IN THE FIGHT | 45 | 45 | 2 | 0.06 | +147 | +73.5 |
| WAR ENGINE CHARGES | 4 | 4 | 2 | 0.06 | +92 | +45.8 |
| BLOCKED CHARGE SKIPPED | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| BLOWS WHERE AIMED | 15 | 15 | 1 | 0.03 | +28 | +28.4 |
| CARRIES OUT SET-UP | 11 | 11 | 1 | 0.03 | -4 | -3.6 |
| CHARIOT NO STATIC JOB | 5 | 5 | 1 | 0.03 | -0 | -0.2 |
| DEFENSIVE FLOOR | 1 | 1 | 1 | 0.03 | +9 | +8.5 |
| FOCUS FIRE | 1 | 1 | 1 | 0.03 | +11 | +11.3 |
| HILL BY ITS CHANCE | 32 | 32 | 1 | 0.03 | +69 | +69.3 |
| NO RALLY LEFT | 1 | 1 | 1 | 0.03 | +28 | +28.1 |
| PURSUES BIG PREY | 1 | 1 | 1 | 0.03 | -18 | -18.4 |
| STANDS TO CAST | 1 | 1 | 1 | 0.03 | -38 | -38.2 |
| WOUNDED STAYS OUT | 1 | 1 | 1 | 0.03 | -37 | -36.6 |
| ALREADY CARRIED | 2 | not checked | - | - | - | - |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| BACKUP TARGETS | 40 | 23 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 26 | 26 | 0 | 0.00 | - | - |
| CARRIES OUT COUNTER | 2 | 2 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 45 | trace | - | - | - | - |
| CATCH FLIERS | 1 | not checked | - | - | - | - |
| CHARACTER GUNS | 9 | 9 | 0 | 0.00 | - | - |
| CHARGER SLAIN LOST | 39 | 37 | 0 | 0.00 | - | - |
| CHARIOT WIZARD CAREFUL | 2 | 2 | 0 | 0.00 | - | - |
| CHEAP HELPER | 8 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 37 | not checked | - | - | - | - |
| DEFENSIVE ARMY | 8 | 8 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FALLS SHORT | 17 | 17 | 0 | 0.00 | - | - |
| FIGHT LIFT | 5 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 381 | not checked | - | - | - | - |
| GIVES UP | 7 | 7 | 0 | 0.00 | - | - |
| GROUND FLIERS | 6 | not checked | - | - | - | - |
| HELPER ALREADY ASKED | 1 | not checked | - | - | - | - |
| HELPER UNSEEN | 28 | 28 | 0 | 0.00 | - | - |
| HUNT ADVANCE | 2 | 2 | 0 | 0.00 | - | - |
| HUNT DROPPED | 3 | trace | - | - | - | - |
| HUNT KEPT | 2 | trace | - | - | - | - |
| HUNT RESULT | 6 | trace | - | - | - | - |
| HUNT THE GUNS | 6 | trace | - | - | - | - |
| JOINT CHARGE PLAN | 3 | 3 | 0 | 0.00 | - | - |
| JOINT KNOWS CHALLENGE | 4 | 4 | 0 | 0.00 | - | - |
| KEEPS ITS PREY | 2 | 2 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 17 | not checked | - | - | - | - |
| LONE WIZARD HOLDS BACK | 2 | 2 | 0 | 0.00 | - | - |
| LONG SHOT | 21 | 21 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 10 | 10 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 7 | trace | - | - | - | - |
| MARCH OVER CASTS | 32 | 32 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 4 | 4 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 9 | 3 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 22 | trace | - | - | - | - |
| MOVE SPELL SPOT | 28 | not checked | - | - | - | - |
| NOT NEEDED | 13 | 13 | 0 | 0.00 | - | - |
| NOT TURNED | 224 | 224 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 31 | not checked | - | - | - | - |
| OPENS A LANE | 8 | 2 | 0 | 0.00 | - | - |
| PLAN RESULT | 2892 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 6 | 6 | 0 | 0.00 | - | - |
| RUN DOWN | 70 | 69 | 0 | 0.00 | - | - |
| SCOUT SPOT | 19 | 19 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 13 | 13 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 20 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 22 | not checked | - | - | - | - |
| SET-UP MISSED | 4 | trace | - | - | - | - |
| SHOOTER COUNTED ONCE | 1 | 1 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 24 | not checked | - | - | - | - |
| SPELL WORTH | 130 | not checked | - | - | - | - |
| STABLE ROLE | 424 | 423 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 17 | 17 | 0 | 0.00 | - | - |
| STOPS | 5 | 5 | 0 | 0.00 | - | - |
| TIME ON OUR SIDE | 62 | 62 | 0 | 0.00 | - | - |
| TURN WORTH | 17 | 17 | 0 | 0.00 | - | - |
| TWO OR MORE ARRIVE | 10 | 8 | 0 | 0.00 | - | - |

### Off best figure: fa-h2h-opp-8a94331-p4

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 14.83 | 0.97 | 41.2 |
| CHARGE NOW FIRST | rule | 0.42 | 0.33 | 29.7 |
| FALLBACK | gate | 0.47 | 0.06 | 45.9 |
| TURN GATE | gate | 0.53 | - | 14.0 |
| WAR ENGINE JOBS | rule | 0.44 | - | 31.0 |
| CANNON PLANNED TARGET | rule | 0.33 | - | 60.2 |
| AFTERMATH BAND | gate | 0.17 | 0.11 | 2.3 |
| SUPPORT NARROWED | rule | 0.17 | 0.06 | 21.5 |
| PIVOT GUARDS FLANK | rule | 0.11 | 0.08 | 12.4 |
| SUPPORT REQUEST | gate | 0.19 | - | 85.1 |
| PATHS CROSS | rule | 0.11 | 0.06 | 11.3 |
| CHAFF PASSED | rule | 0.08 | 0.06 | 3.4 |
| CHARGE NOW WEIGHED | rule | 0.14 | - | 20.3 |
| SURE CHARGE BEATS ADVANCE | rule | 0.14 | - | 33.6 |
| MARCH ODDS | rule | 0.08 | 0.03 | 8.9 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.03 | 0.06 | 238.2 |
| BIG CHARACTER SAFETY | rule | 0.08 | - | 5.2 |
| LONE CHARACTER SAFE SPOT | gate | 0.08 | - | 28.6 |
| BEST PRIZE | rule | 0.03 | 0.03 | 23.6 |
| FACES THE THREAT | rule | 0.06 | - | 6.2 |
| FIGHT ORDER BAND | gate | - | 0.06 | 3.5 |
| FRIENDS SHOTS CHECKED | rule | 0.06 | - | 2.1 |
| NO REASON | gate | - | 0.06 | 33.8 |
| THROUGH LINE OF FIRE | rule | 0.06 | - | 3.9 |
| CARRIES OUT SET-UP | rule | - | 0.03 | 3.6 |
| PURSUES BIG PREY | rule | - | 0.03 | 18.4 |
| REFUSING RETIRES | rule | 0.03 | - | 1.1 |
| RULE SWITCHED OFF | gate | 0.03 | - | 4.5 |
| STANDS TO CAST | rule | 0.03 | - | 38.2 |
| STOPS SHORT OF THE FLANK | rule | 0.03 | - | 3.1 |
| WHO HITS BACK | rule | 0.03 | - | 1.9 |
| WOUNDED STAYS OUT | rule | - | 0.03 | 36.6 |

### Plans: fa-h2h-opp-8a94331-p4

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 10.5 | 19% | 162 | 290 | 179% |
| Mine | charge | 3.1 | 60% | 261 | 301 | 115% |
| Mine | close in | 5.0 | 30% | 224 | 138 | 61% |
| Mine | hold | 5.5 | 32% | 349 | 0 | 0% |
| Mine | join | 0.5 | 95% | 11 | 0 | 0% |
| Mine | shoot | 10.3 | 59% | 424 | 788 | 186% |
| Mine | support | 6.2 | 91% | 67 | 0 | 0% |
| Opponent | charge | 2.6 | 62% | 386 | 311 | 81% |
| Opponent | join | 0.6 | 87% | 30 | 0 | 0% |
| Opponent | move | 32.5 | 91% | 1887 | 0 | 0% |
| Opponent | shoot | 2.9 | 52% | 217 | 219 | 101% |
| Opponent | support | 0.5 | 79% | 7 | 0 | 0% |

### Packages: hunt the guns, fa-h2h-opp-8a94331-p4

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.0 | 1 | 0 | 0% | 0% | 0% | - | 221 | 0 | 0% | 13 |
| Opponent | 0.1 | 5 | 0 | 60% | 60% | 0% | 2.3 | 217 | 110 | 40% | 89 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 113 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 43 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 93 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 213 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.2 | 1 | 0 | 100% | 100% | 0% | 2.0 | 180 | 95 | 0% | 22 |
| Tomb Kings of Khemri | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 221 | 0 | 0% | 0 |
| Vampire Counts | 0.2 | 2 | 0 | 50% | 50% | 0% | 3.0 | 233 | 145 | 50% | 33 |
| Warriors of Chaos | 0.2 | 2 | 0 | 50% | 50% | 0% | 2.0 | 219 | 81 | 50% | 119 |
| Wood Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 18 |

### Battle groups: fa-h2h-opp-8a94331-p4

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 2.7 | 26% | 72% | 8% | 100% | 13% | 0% | 0% | 78% | 9% |
| Opponent | REDIRECT COUNTER | 4.4 | 22% | 66% | 11% | 0% | 19% | 0% | 13% | 68% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: fa-h2h-opp-8a94331-p4

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 4 | 0 (4) | 0 | 0 | 41 | 25% | 2.0 | - | 0 (1) | 0 (2) | - | 0 (3) |
| Mine | Chaff | 34 | 27 (34) | 7 | 20 | 61 | 29% | 2.6 | 31 (14) | 9 (7) | 31 (13) | 30 (22) | 21 (12) |
| Mine | Character | 106 | 53 (106) | 53 | 0 | 35 | 15% | 2.3 | 66 (32) | 58 (55) | 0 (6) | 60 (44) | 57 (49) |
| Mine | Clean-up | 22 | 112 (22) | 71 | 41 | 26 | 36% | 3.3 | 56 (2) | 136 (16) | 66 (4) | 40 (10) | 150 (12) |
| Mine | Early | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | - | - | - | - |
| Mine | Fast | 4 | 0 (4) | 0 | 0 | 46 | 25% | 3.0 | 0 (2) | 0 (2) | - | 0 (3) | 0 (1) |
| Mine | Fast Hammer | 41 | 40 (41) | 24 | 16 | 23 | 17% | 3.4 | 44 (27) | 34 (9) | 27 (5) | 39 (25) | 40 (16) |
| Mine | Fragile | 4 | 0 (4) | 0 | 0 | 46 | 25% | 2.0 | 0 (1) | 0 (2) | - | 0 (1) | 0 (2) |
| Mine | Hammer | 65 | 45 (65) | 34 | 11 | 33 | 20% | 2.5 | 92 (13) | 38 (45) | 0 (7) | 54 (40) | 33 (25) |
| Mine | Holder | 31 | 107 (31) | 13 | 94 | 19 | 45% | 3.1 | 36 (9) | 203 (16) | 13 (6) | 170 (20) | 13 (11) |
| Mine | Shooter | 34 | 62 (34) | 30 | 32 | 34 | 0% | 1.7 | 8 (8) | 93 (21) | 21 (5) | 65 (25) | 53 (9) |
| Mine | Support | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | - | 0 (1) | 0 (1) | - |
| Mine | War machine | 56 | 47 (56) | 47 | 0 | 25 | 5% | 1.3 | 9 (16) | 81 (30) | 17 (10) | 19 (9) | 52 (47) |
| Mine | Wizard | 17 | 21 (17) | 21 | 0 | 9 | 0% | 2.2 | 41 (6) | 14 (9) | 0 (1) | 31 (8) | 15 (8) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Chaff | 75 | 40 (75) | 18 | 22 | 49 | 41% | 2.9 | 36 (31) | 52 (17) | 34 (27) | 46 (56) | 18 (19) |
| Opponent | Character | 97 | 42 (97) | 42 | 0 | 34 | 23% | 2.5 | 40 (40) | 36 (35) | 84 (7) | 48 (47) | 37 (35) |
| Opponent | Clean-up | 11 | 36 (11) | 10 | 26 | 27 | 64% | 3.0 | 0 (3) | 31 (6) | 77 (2) | 0 (6) | 56 (5) |
| Opponent | Fast | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Fast Hammer | 60 | 30 (60) | 17 | 13 | 48 | 32% | 3.4 | 27 (26) | 19 (25) | 80 (9) | 30 (39) | 30 (21) |
| Opponent | Fragile | 17 | 0 (17) | 0 | 0 | 94 | 29% | 1.8 | 0 (3) | 0 (9) | 0 (4) | 0 (13) | 0 (3) |
| Opponent | Hammer | 65 | 33 (65) | 18 | 15 | 49 | 32% | 3.0 | 24 (20) | 39 (38) | 16 (7) | 37 (41) | 28 (24) |
| Opponent | Holder | 29 | 36 (29) | 5 | 31 | 15 | 69% | 3.9 | 44 (10) | 40 (13) | 0 (5) | 57 (16) | 8 (12) |
| Opponent | Shooter | 33 | 71 (33) | 52 | 20 | 49 | 0% | 1.6 | 72 (9) | 49 (21) | 263 (3) | 63 (18) | 80 (15) |
| Opponent | Support | 6 | 0 (6) | 0 | 0 | 49 | 100% | - | 0 (1) | - | - | - | 0 (1) |
| Opponent | War machine | 6 | 71 (6) | 71 | 0 | 80 | 17% | 1.0 | 61 (3) | 85 (3) | - | 61 (3) | 85 (3) |
| Opponent | Wizard | 19 | 4 (19) | 4 | 0 | 48 | 16% | 2.2 | 5 (9) | 5 (6) | 0 (2) | 7 (9) | 0 (8) |

### Charged fights: fa-h2h-opp-8a94331-p4

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 140 | 310 | 2.8 | 1.6 | 113 | 12 | +100 | 4 of 11 | 10 of 11 | +151 | +58 |
| Mine | Chaos Dwarfs | 4 | 275 | 200 | 3.2 | 1.1 | 61 | 35 | +27 | 5 of 13 | 11 of 13 | +0 | +29 |
| Mine | Dwarfen Mountain Holds | 3 | 588 | 54 | 1.3 | 1.2 | 40 | 0 | +40 | 1 of 4 | 3 of 4 | +60 | +34 |
| Mine | Empire of Man | 5 | 350 | 99 | 1.4 | 1.1 | 71 | 40 | +31 | 2 of 7 | 5 of 7 | +0 | +36 |
| Mine | Grand Cathay | 4 | 530 | 360 | 3.0 | 1.1 | 120 | 48 | +72 | 3 of 12 | 10 of 12 | +0 | +79 |
| Mine | High Elf Realms | 4 | 264 | 271 | 3.5 | 1.0 | 78 | 76 | +2 | 4 of 14 | 9 of 14 | - | +2 |
| Mine | Kingdom of Bretonnia | 1 | 110 | 1612 | 7.0 | 1.1 | 230 | 0 | +230 | 4 of 7 | 4 of 7 | +540 | +179 |
| Mine | Lizardmen | 1 | 0 | 1685 | 5.0 | 1.2 | 337 | 0 | +337 | 3 of 5 | 5 of 5 | +1140 | +136 |
| Mine | Ogre Kingdoms | 2 | 63 | 90 | 3.5 | 1.0 | 26 | 10 | +16 | 0 of 7 | 4 of 7 | - | +16 |
| Mine | Skaven | 2 | 238 | 130 | 1.5 | 1.0 | 87 | 12 | +75 | 1 of 3 | 1 of 3 | - | +75 |
| Mine | Tomb Kings of Khemri | 2 | 22 | 444 | 3.5 | 1.1 | 127 | 0 | +127 | 3 of 7 | 6 of 7 | +60 | +138 |
| Mine | Vampire Counts | 2 | 190 | 120 | 2.5 | 1.0 | 48 | 0 | +48 | 2 of 5 | 4 of 5 | - | +48 |
| Mine | Warriors of Chaos | 2 | 0 | 445 | 5.5 | 1.2 | 81 | 0 | +81 | 3 of 11 | 10 of 11 | +70 | +82 |
| **Mine** | all armies | 36 | 264 | 305 | 2.9 | 1.2 | 104 | 25 | +79 | 35 of 106 | 82 of 106 | +202 | +62 |
| Opponent | Empire of Man | 1 | 460 | 0 | 2.0 | 2.0 | 0 | 384 | -384 | 2 of 2 | 1 of 2 | -384 | - |
| Opponent | High Elf Realms | 5 | 152 | 296 | 2.6 | 1.1 | 114 | 79 | +35 | 6 of 13 | 9 of 13 | -294 | +62 |
| Opponent | Lizardmen | 2 | 68 | 0 | 2.5 | 1.0 | 0 | 28 | -28 | 3 of 5 | 4 of 5 | - | -28 |
| Opponent | Orc & Goblin Tribes | 3 | 0 | 404 | 5.7 | 1.1 | 71 | 48 | +23 | 4 of 17 | 13 of 17 | +234 | +10 |
| Opponent | Skaven | 4 | 0 | 118 | 1.0 | 1.0 | 118 | 64 | +54 | 2 of 4 | 2 of 4 | - | +54 |
| Opponent | Tomb Kings of Khemri | 2 | 112 | 302 | 2.0 | 1.0 | 151 | 0 | +151 | 0 of 4 | 4 of 4 | - | +151 |
| Opponent | Vampire Counts | 6 | 46 | 315 | 2.3 | 1.2 | 135 | 17 | +118 | 9 of 14 | 10 of 14 | +0 | +138 |
| Opponent | Warriors of Chaos | 7 | 9 | 383 | 2.4 | 1.0 | 158 | 85 | +73 | 10 of 17 | 10 of 17 | - | +73 |
| Opponent | Wood Elf Realms | 6 | 265 | 317 | 4.3 | 1.1 | 73 | 12 | +61 | 12 of 26 | 17 of 26 | +22 | +64 |
| **Opponent** | all armies | 36 | 98 | 284 | 2.8 | 1.1 | 100 | 49 | +51 | 48 of 102 | 70 of 102 | -98 | +64 |

### Effective charges: fa-h2h-opp-8a94331-p4

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 11 | 3 (net +60) | 0 | 2 (net +116) | 2 (net +150) | 0 | 2 (net +84) | 2 | 22% (2 of 9) |
| Mine | Chaos Dwarfs | 13 | 0 | 0 | 2 (net +0) | 4 (net +0) | 1 (net -248) | 5 (net +84) | 1 | 17% (2 of 12) |
| Mine | Dwarfen Mountain Holds | 4 | 1 (net +0) | 0 | 0 | 1 (net +60) | 0 | 2 (net +51) | 0 | 0% (0 of 4) |
| Mine | Empire of Man | 7 | 1 (net +261) | 0 | 1 (net +0) | 1 (net +0) | 0 | 4 (net -11) | 0 | 14% (1 of 7) |
| Mine | Grand Cathay | 12 | 1 (net -369) | 0 | 2 (net -54) | 4 (net +227) | 0 | 5 (net +87) | 0 | 17% (2 of 12) |
| Mine | High Elf Realms | 14 | 4 (net +166) | 0 | 2 (net +85) | 3 (net +23) | 1 (net +66) | 3 (net -199) | 1 | 15% (2 of 13) |
| Mine | Kingdom of Bretonnia | 7 | 1 (net +210) | 0 | 0 | 3 (net +217) | 0 | 2 (net +375) | 1 | 0% (0 of 6) |
| Mine | Lizardmen | 5 | 1 (net +1140) | 0 | 0 | 1 (net +255) | 0 | 2 (net +118) | 1 | 0% (0 of 4) |
| Mine | Ogre Kingdoms | 7 | 0 | 0 | 0 | 2 (net +28) | 0 | 3 (net +42) | 2 | 0% (0 of 5) |
| Mine | Skaven | 3 | 1 (net -35) | 0 | 0 | 0 | 0 | 2 (net +130) | 0 | 0% (0 of 3) |
| Mine | Tomb Kings of Khemri | 7 | 1 (net +0) | 0 | 0 | 3 (net +187) | 1 (net +60) | 2 (net +132) | 0 | 0% (0 of 7) |
| Mine | Vampire Counts | 5 | 1 (net +0) | 0 | 0 | 2 (net +95) | 0 | 1 (net +50) | 1 | 0% (0 of 4) |
| Mine | Warriors of Chaos | 11 | 2 (net +250) | 0 | 2 (net +0) | 0 | 1 (net +70) | 4 (net +66) | 2 | 22% (2 of 9) |
| Opponent | Empire of Man | 2 | 0 | 0 | 1 (net -214) | 0 | 0 | 1 (net -553) | 0 | 50% (1 of 2) |
| Opponent | High Elf Realms | 13 | 2 (net -198) | 1 (net +583) | 2 (net -147) | 4 (net +64) | 1 (net +162) | 1 (net +0) | 2 | 18% (2 of 11) |
| Opponent | Lizardmen | 5 | 0 | 0 | 3 (net +0) | 1 (net +0) | 0 | 0 | 1 | 75% (3 of 4) |
| Opponent | Orc & Goblin Tribes | 17 | 1 (net +0) | 0 | 0 | 2 (net +112) | 0 | 4 (net +124) | 10 | 0% (0 of 7) |
| Opponent | Skaven | 4 | 1 (net +95) | 0 | 1 (net -192) | 1 (net +168) | 0 | 1 (net +145) | 0 | 25% (1 of 4) |
| Opponent | Tomb Kings of Khemri | 4 | 0 | 0 | 1 (net +92) | 1 (net +199) | 1 (net +126) | 1 (net +186) | 0 | 25% (1 of 4) |
| Opponent | Vampire Counts | 14 | 2 (net +180) | 0 | 2 (net +277) | 4 (net +12) | 2 (net +0) | 2 (net +286) | 2 | 17% (2 of 12) |
| Opponent | Warriors of Chaos | 17 | 4 (net +206) | 0 | 3 (net +85) | 2 (net +66) | 1 (net +55) | 5 (net +175) | 2 | 20% (3 of 15) |
| Opponent | Wood Elf Realms | 26 | 3 (net -71) | 1 (net +0) | 7 (net +109) | 5 (net +98) | 4 (net +27) | 6 (net +72) | 0 | 27% (7 of 26) |

### Charged fights, damage counted: fa-h2h-opp-8a94331-p4

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 17 | 283 | 286 | +150 | 216 | 50 | +166 | +58.8 |
| Mine | Effective (55-75%) | 11 | 217 | 237 | +27 | 87 | 41 | +46 | +21.0 |
| Mine | 76-89% | 26 | 290 | 178 | +117 | 135 | 9 | +127 | +43.7 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 37 | 245 | 153 | +66 | 111 | 51 | +60 | +24.5 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 4 | 627 | 72 | -13 | 100 | 89 | +11 | +1.7 |
| Mine | No odds | 11 | 235 | 120 | +8 | 57 | 59 | -2 | -0.9 |
| Mine | All fights | 106 | 272 | 183 | +79 | 125 | 42 | +84 | +30.7 |
| Opponent | Long shot (under 50%) | 13 | 229 | 323 | +51 | 146 | 124 | +22 | +9.6 |
| Opponent | 50-54% | 2 | 300 | 282 | +292 | 292 | 0 | +292 | +97.3 |
| Opponent | Effective (55-75%) | 20 | 265 | 247 | +48 | 151 | 82 | +69 | +26.1 |
| Opponent | 76-89% | 20 | 219 | 170 | +76 | 108 | 28 | +80 | +36.6 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 21 | 327 | 198 | +102 | 153 | 56 | +96 | +29.4 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 9 | 441 | 83 | +50 | 56 | 8 | +47 | +10.7 |
| Opponent | No odds | 17 | 239 | 191 | -65 | 95 | 150 | -54 | -22.6 |
| Opponent | All fights | 102 | 276 | 208 | +51 | 127 | 75 | +53 | +19.1 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| fa-h2h-opp-8a94331-p4 | move | 374 | 76 (20%) | 56 (15%) | 47 (13%) | 251 (67%) |
| fa-h2h-opp-8a94331-p4 | objective | 179 | 34 (19%) | 25 (14%) | 19 (11%) | 126 (70%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0114, L0130, L2527, L2634 |
| Charmed Shield | Opponent | L0434, L0624, L0926, L1034, L1126, L1427, L2227, L2527, L2634, L3234 |
| Clockwork Compass | Mine | L1220 |
| Elixir of Power | Mine | L1126 |
| Elixir of Power | Opponent | L0819, L1719, L1819 |
| Fistful of Laurels | Mine | L1819, L1835 |
| Invocation of Nehek | Mine | L2527 |
| Invocation of Nehek | Opponent | L0624, L1427, L2227, L2527 |
| Opal Amulet | Mine | L1427 |
| Opal Amulet | Opponent | L0114, L0214, L1314 |
| Periapt of Soul Exchange | Mine | L2021, L2123 |
| Periapt of Soul Exchange | Opponent | L0520, L1220, L1621, L2021 |
| Ring of Doom | Mine | L0214, L0230, L1126, L1220, L1523 |
| Ring of Doom | Opponent | L0315, L1331, L2331 |
| Ring of Jet | Mine | L1017, L1034, L1126, L1220 |
| Standard of the Fell Warrior | Mine | L1314, L1331 |
| Standard of the Fell Warrior | Opponent | L0713 |
| Storm Daemon (Renegade 2.0) | Mine | L2123 |
| Storm Daemon (Renegade 2.0) | Opponent | L1621, L2021 |
| Twice-Blessed Armour | Mine | L0713, L0729, L1017, L1034 |
| Witch Hunter's Ward | Mine | L0713, L0729, L0819, L0835 |
| Witch Hunter's Ward | Opponent | L0608 |

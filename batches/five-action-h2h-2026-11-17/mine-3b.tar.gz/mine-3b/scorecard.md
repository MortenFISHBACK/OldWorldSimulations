# Doctrine scorecard: fa-h2h-mine-8a94331-p3b

### Scorecard: fa-h2h-mine-8a94331-p3b

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0533 | 5 | 1 | Mine | yes | - | - | 0 | 1 | 0 | 0 | 0 | 306 |
| L0533 | 5 | 1 | Opponent | no | - | 2 | 5 | 5 | 0 | 0 | 0 | 0 |
| L0620 | 2 | 1 | Mine | - | - | 3 | 2 | 1 | 0 | 0 | 0 | 1105 |
| L0620 | 2 | 1 | Opponent | - | - | - | 0 | 4 | 0 | 0 | 0 | 210 |
| L0709 | 1 | 1 | Mine | yes | 14 | - | 0 | 2 | 2 | 0 | 0 | 170 |
| L0709 | 1 | 1 | Opponent | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 524 |
| L0725 | 5 | 1 | Mine | no | - | - | 0 | 1 | 0 | 0 | 0 | 250 |
| L0725 | 5 | 1 | Opponent | yes | - | 4 | 2 | 4 | 0 | 0 | 0 | 0 |
| L0815 | 5 | 1 | Mine | no | - | 6 | 1 | 2 | 0 | 0 | 0 | 543 |
| L0815 | 5 | 1 | Opponent | yes | - | 2 | 3 | 2 | 1 | 0 | 0 | 0 |
| L0831 | 3 | 1 | Mine | no | 0 | 5 | 1 | 1 | 0 | 0 | 0 | 345 |
| L0831 | 3 | 1 | Opponent | no | 11 | 2 | 3 | 0 | 2 | 0 | 0 | 927 |
| L0922 | 4 | 1 | Mine | no | 2 | - | 0 | 0 | 0 | 0 | 0 | 439 |
| L0922 | 4 | 1 | Opponent | no | 0 | 2 | 3 | 2 | 0 | 0 | 0 | 0 |
| L1013 | 5 | 1 | Mine | no | - | 2 | 1 | 1 | 0 | 0 | 0 | 165 |
| L1013 | 5 | 1 | Opponent | yes | - | 3 | 2 | 3 | 0 | 0 | 0 | 302 |
| L1030 | 4 | 1 | Mine | no | 0 | 2 | 3 | 0 | 0 | 0 | 0 | 330 |
| L1030 | 4 | 1 | Opponent | no | 5 | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L1122 | 6 | 1 | Mine | no | 0 | 5 | 1 | 0 | 0 | 0 | 0 | 0 |
| L1122 | 6 | 1 | Opponent | no | 5 | 2 | 2 | 3 | 1 | 0 | 0 | 242 |
| L1216 | 4 | 1 | Mine | no | 6 | 2 | 2 | 0 | 0 | 0 | 0 | 333 |
| L1216 | 4 | 1 | Opponent | no | 0 | 2 | 3 | 3 | 0 | 0 | 0 | 200 |
| L1232 | 2 | 1 | Mine | - | - | 2 | 1 | 0 | 0 | 0 | 0 | 359 |
| L1232 | 2 | 1 | Opponent | - | - | 3 | 2 | 5 | 0 | 0 | 0 | 309 |
| L1327 | 1 | 1 | Mine | no | 6 | 6 | 1 | 1 | 0 | 0 | 0 | 302 |
| L1327 | 1 | 1 | Opponent | no | 0 | 2 | 2 | 4 | 0 | 0 | 0 | 0 |
| L1422 | 6 | 1 | Mine | no | 3 | 5 | 2 | 1 | 1 | 0 | 0 | 0 |
| L1422 | 6 | 1 | Opponent | no | 0 | 2 | 5 | 0 | 0 | 0 | 0 | 170 |
| **Average** | | | Mine | 17% | 3.9 | 3.8 | 1.1 | 0.8 | 0.2 | 0.0 | 0.0 | 331.9 |
| **Average** | | | Opponent | 25% | 2.6 | 2.3 | 2.6 | 2.6 | 0.3 | 0.0 | 0.0 | 206.0 |

### KPIs: fa-h2h-mine-8a94331-p3b

Rules off - Opponent only: FIVE ACTION, LIKELY CHARGE, FALLS SHORT, TIME ON OUR SIDE, FEATURE BUFFS, GETS AWAY CHANCE, GUN MASK, RUN DOWN, FOUR ROUNDS, CHARGE LOSSES, CHARACTER GUNS, STAND AND SHOOT, FALL BACK GOOD ORDER, AFTERMATH IN POINTS.

Morten 2026-11-10; 14 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 41% (28 of 68) | 6% (4 of 66) | 24% (32 of 134) |
| Winner chose to follow up after the loser gave ground |  | 73% (11 of 15); on the table 93% | 100% (12 of 12); on the table 100% | 85% (23 of 27); on the table 96% |
| Winner chose to pursue after the loser fell back in good order |  | - | 86% (6 of 7); on the table 86% | 86% (6 of 7); on the table 86% |
| Winner chose to pursue after the loser fled |  | 50% (2 of 4); on the table 50% | 75% (9 of 12); on the table 75% | 69% (11 of 16); on the table 69% |
| Winner chose to follow up or pursue (all three) |  | 68% (13 of 19); on the table 84% | 87% (27 of 31); on the table 87% | 80% (40 of 50); on the table 86% |
| Magic missiles tried each own turn | 50%+ | 39% (56 of 144) | 33% (20 of 60) | 37% (76 of 204) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 47% (56 of 120) | 38% (20 of 52) | 44% (76 of 172) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 64% (18 of 28) | 64% (18 of 28) |
| Points that never fought | lower | 48% (12896 of 27101) | 55% (15514 of 27996) | 52% (28410 of 55097) |
|   infantry points that never fought | lower | 57% (2739 of 4802) | 76% (4555 of 5982) | 68% (7294 of 10784) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 66% (84 of 127) | 57% (59 of 103) | 62% (143 of 230) |
| Bound items with a magic missile used (at least once a game) |  | 100% (13 of 13); 2.7 uses a game | 83% (5 of 6); 1.1 uses a game | 95% (18 of 19); 1.9 uses a game |
| Bound items with another spell used |  | 25% (3 of 12); 0.4 uses a game | 0% (0 of 2); 0.0 uses a game | 21% (3 of 14); 0.2 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 56% (5 of 9); 0.4 uses a game | 75% (3 of 4); 0.2 uses a game | 62% (8 of 13); 0.3 uses a game |
|   their share of the points of units over 100 pts | lower | 62% (15360 of 24725) | 50% (11875 of 23702) | 56% (27235 of 48427) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 2.2 (35%) | 1.3 (45%) | 3.5 (38%) |
| MARCHED: its unit marched | 2.3 (36%) | 0.5 (18%) | 2.8 (30%) |
| CHARGED: its unit charged | 0.1 (1%) | 0.1 (5%) | 0.2 (2%) |
| IN COMBAT: engaged in combat | 1.0 (16%) | 0.1 (5%) | 1.1 (12%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.4 (12%) | 0.4 (4%) |
| GONE: slain | 0.6 (9%) | 0.4 (15%) | 1.0 (11%) |
| OFF THE TABLE: off the table or not arrived | 0.1 (2%) | 0.0 (0%) | 0.1 (2%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 5.0 | 1.3 | 2.2 | 5.4 | 1.2 | 1.6 |
| not cast | 1.9 | 1.4 | 3.4 | 9.1 | 2.6 | 20.6 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.1 (2%) | 0.0 (0%) | 0.0 (0%) | 0.5 (2%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.1 (84%) | 0.1 (2%) | 3.5 (38%) | 0.6 (22%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.8 (30%) | 0.5 (19%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (2%) | 0.1 (3%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.1 (5%) | 0.3 (9%) | 1.1 (12%) | 0.1 (5%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.4 (4%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.1 (4%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (1%) |
| GONE: slain | 0.4 (19%) | 0.1 (5%) | 0.6 (17%) | 1.0 (11%) | 0.3 (11%) | 0.9 (4%) |
| OFF THE TABLE: off the table or not arrived | 0.2 (12%) | 0.0 (0%) | 0.0 (0%) | 0.1 (2%) | 0.0 (0%) | 0.6 (3%) |
| STUPIDITY: Stupidity | 0.1 (8%) | 0.0 (0%) | 0.1 (2%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (4%) | 0.1 (5%) | 0.0 (0%) | 0.0 (0%) | 1.1 (41%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.0 (54%) | 0.0 (0%) | 2.3 (68%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 18.3 (89%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.2 a game | 1.0 a game | 1.1 a game |
| stood (cast and not dispelled) | 41% (7 of 17) | 38% (3 of 8) | 40% (10 of 25) |
| the unit moved after it | 100% (7 of 7) | 100% (3 of 3) | 100% (10 of 10) |
| it charged on its next turn | 0% (0 of 7) | 0% (0 of 3) | 0% (0 of 10) |
| the enemy charged it first | 29% (2 of 7) | 33% (1 of 3) | 30% (3 of 10) |
| it fought by the end of its next turn | 0% (0 of 7) | 0% (0 of 3) | 0% (0 of 10) |
| it moved out of a charge the enemy had planned (not charged first) | 29% (2 of 7) | 0% (0 of 3) | 20% (2 of 10) |
| none of these (no charge, no fight, no charge escaped) | 43% (3 of 7) | 67% (2 of 3) | 50% (5 of 10) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 74% (272 of 369) | 56% (186 of 335) | 65% (458 of 704) |
|   cavalry | 73% (24 of 33) | 59% (24 of 41) | 65% (48 of 74) |
|   character | 68% (32 of 47) | 24% (15 of 62) | 43% (47 of 109) |
|   chariot | 71% (20 of 28) | 55% (11 of 20) | 65% (31 of 48) |
|   infantry | 67% (54 of 81) | 58% (97 of 166) | 61% (151 of 247) |
|   monster | 50% (5 of 10) | 83% (5 of 6) | 62% (10 of 16) |
|   war machine | 81% (137 of 170) | 85% (34 of 40) | 81% (171 of 210) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.4 (20%) | 2.1 (20%) | 3.5 (20%) |
| CHARGED: it charged | 0.4 (6%) | 2.0 (19%) | 2.4 (14%) |
| FLEEING: it fled or was fleeing | 0.1 (1%) | 0.0 (0%) | 0.1 (0%) |
| IN COMBAT: it fought this turn or the last | 0.7 (10%) | 0.3 (3%) | 1.0 (6%) |
| MOVED: a war machine that moved | 1.4 (21%) | 0.2 (2%) | 1.6 (9%) |
| NO TARGET IN RANGE | 1.1 (15%) | 2.4 (23%) | 3.5 (20%) |
| ONLY IN COMBAT: the only targets were in combat | 0.1 (2%) | 1.0 (9%) | 1.1 (7%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.3 (19%) | 2.2 (21%) | 3.5 (20%) |
| SHELTERED: the target was sheltered | 0.1 (2%) | 0.1 (1%) | 0.2 (1%) |
| STUPIDITY | 0.0 (0%) | 0.1 (1%) | 0.1 (1%) |
| OTHER BAR | 0.3 (4%) | 0.1 (1%) | 0.4 (2%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 6.4 | 1.8 | 79% | 7.9 pts | 51 pts |
| character | 3.9 | 1.1 | 78% | 5.7 pts | 23 pts |
| chariot | 2.2 | 1.6 | 55% | 21.0 pts | 46 pts |
| infantry | 15.9 | 5.7 | 73% | 8.6 pts | 137 pts |
| monster | 1.1 | 0.4 | 73% | 12.7 pts | 14 pts |
| war machine | 13.2 | 10.1 | 65% | 22.7 pts | 300 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 1.5 | 5.0 | 3.2 |
| Charges that made contact a game | 1.4 | 3.1 | 2.2 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.60 declared, 0.53 contact (15 units) | 0.20 declared, 0.20 contact (5 units) | 0.50 declared, 0.45 contact (20 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.00 declared, 0.00 contact (1 units) | 1.00 declared, 1.00 contact (3 units) | 0.75 declared, 0.75 contact (4 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.15 declared, 0.14 contact (79 units) | 0.59 declared, 0.36 contact (112 units) | 0.41 declared, 0.27 contact (191 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 65% (24 of 37) | 29% (2 of 7) | 0% (0 of 3) | 55% (26 of 47) |
| Character in a unit | 86% (12 of 14) | 100% (4 of 4) | 0% (0 of 1) | 84% (16 of 19) |
| Character on its own | 93% (13 of 14) | 56% (10 of 18) | 30% (8 of 27) | 53% (31 of 59) |
| Chariot | 50% (2 of 4) | 50% (2 of 4) | - | 50% (4 of 8) |
| Infantry | 53% (18 of 34) | 83% (10 of 12) | 100% (2 of 2) | 62% (30 of 48) |
| Monster | 64% (7 of 11) | 67% (2 of 3) | - | 64% (9 of 14) |
| Monstrous | 100% (2 of 2) | 50% (1 of 2) | - | 75% (3 of 4) |
| War Machines | 77% (24 of 31) | - | - | 77% (24 of 31) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Dwarfen Mountain Holds | 2 | 100% (1 of 1); on the table 100% | - | 43% | 76% (13 of 17) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 6 | 33% (1 of 3); on the table 67% | 37% (11 of 30) | 64% | 71% (42 of 59) | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game | 50% (2 of 4); 0.3 uses a game |
| Grand Cathay | 5 | 89% (8 of 9); on the table 89% | 40% (46 of 114) | 45% | 67% (31 of 46) | 100% (12 of 12); 7.4 uses a game | 0% (0 of 2); 0.0 uses a game | 60% (3 of 5); 0.6 uses a game |
| High Elf Realms | 4 | 50% (4 of 8); on the table 75% | 25% (6 of 24) | 53% | 41% (13 of 32) | 75% (3 of 4); 2.5 uses a game | 30% (3 of 10); 1.5 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | 67% (2 of 3); on the table 67% | - | 43% | 50% (3 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Skaven | 1 | 100% (2 of 2); on the table 100% | 33% (2 of 6) | 64% | 43% (3 of 7) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Tomb Kings of Khemri | 3 | 90% (9 of 10); on the table 90% | 33% (2 of 6) | 42% | 47% (7 of 15) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 2 | 100% (3 of 3); on the table 100% | 58% (7 of 12) | 59% | 67% (8 of 12) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 3 | 89% (8 of 9); on the table 89% | 17% (1 of 6) | 40% | 58% (15 of 26) | 100% (1 of 1); 0.7 uses a game | 0.0 uses a game | 100% (1 of 1); 0.3 uses a game |
| Wood Elf Realms | 1 | 100% (2 of 2); on the table 100% | 17% (1 of 6) | 75% | 80% (8 of 10) | 100% (2 of 2); 4.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (fa-h2h-mine-8a94331-p3b, 14 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 47% (16) | 44% (7) | 46% (23) |
| ...free all their last turn and able to turn (per game) | 0.79 | 0.29 | 1.07 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.21 | 0.14 | 0.36 |
| ...with the charger already in that arc before they moved (per game) | 0.50 | 0.21 | 0.71 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.07 | 1.71 | 1.79 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.43 | 0.43 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.07 | 5.57 | 5.64 |

### Quality by phase: fa-h2h-mine-8a94331-p3b

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.9 | 3.6 |
| Strategy | Charge objectives carried out (made contact) | 79% (15 of 19) | 30% (21 of 69) |
| Strategy | Shoot objectives carried out (shot that target) | 47% (100 of 213) | 54% (68 of 125) |
| Strategy | Close-in objectives charged next turn | - | 11% (8 of 75) |
| Strategy | Support requests answered (helper made contact too) | 50% (1 of 2) | 40% (6 of 15) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | - | 67% (2 of 3) |
| Strategy | Hexes on a unit its side charged or shot that turn | 0% (0 of 9) | - |
| Strategy | Joined characters whose unit fought | 27% (3 of 11) | 15% (3 of 20) |
| Strategy | Lone characters that fought | 59% (26 of 44) | 68% (23 of 34) |
| Movement | Charges halted short of contact | 0.0 | 0.4 |
| Movement | Idle units | 0.8 | 2.6 |
| Movement | Points that never moved of their own | 331.9 | 206.0 |
| Movement | Fights charged into per game | 1.3 | 3.0 |
| Movement | Charges with odds: long shots (under 50%) | 3 of 17, net +30 | 6 of 33, net +312 |
| Movement | Charges with odds: sweet spot (55-75%) | 3 of 17, net +129 | 7 of 33, net -38 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 1 of 17, net +60 | 2 of 33, net +146 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 of 17, net +46 | 5 of 33, net +108 |
| Shooting | Shots by shooting units (incl. breath weapons) | 10.3 | 12.9 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 38% (54 of 144) | 46% (82 of 180) |
| Shooting | Points destroyed by shooting units | 86.2 | 98.4 |
| Shooting | War machine shots | 9.8 | 3.4 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 53% (73 of 137) | 42% (20 of 48) |
| Shooting | Points destroyed by war machines | 77.1 | 29.0 |
| Magic | Magic missiles cast | 3.4 | 0.6 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 42% (20 of 48) | 33% (3 of 9) |
| Magic | Wounds caused by magic missiles | 4.5 | 1.2 |
| Magic | Wounds caused by other spells | 3.3 | 0.1 |
| Magic | Points destroyed by magic (all spells) | 77.9 | 27.5 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.9 / 0.6 / 0.9 / 0.3 | 2.7 / 0.1 / 0.1 / 0.1 |
| Combat | Points destroyed in combat | 111.1 | 352.6 |
| Combat | Points run down | 12.4 | 114.9 |
| Combat | Net points per charged fight, damage counted | +30 | +137 |
| Combat | Net per 100 charger points, damage counted | +12.3 | +45.7 |
| Combat | First round won (charged fights) | 67% | 76% |
| Combat | Net points per charged fight | +36 | +126 |
| Combat | Net points per supported fight / lone fight | +0 / +38 | +81 / +129 |
| Combat | Charged fights on a top-3 enemy unit | 4 of 18 | 17 of 42 |
| Game | Points lost | 831.3 | 385.3 |
| Game | VP from objectives | 387.1 | 717.1 |
| Game | Lone holders (player turns) | 3.9 | 2.6 |

- Mine won / drew / lost: 1 / 3 / 10 of 14 ended games (of 14); mean margin (Mine - Opponent) -790 VP
- The side that went first won 4 of 11 games with a winner
- Points traded per game (both sides' losses): 1217
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: fa-h2h-mine-8a94331-p3b

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.5 | +0.0 | 0.0 | 0.0 | 0.5 | +0.0 | 0.0 | 0.0 |
| ADVANCE WORTH | - | - | - | - | 4.9 | -279.3 | 116.2 | 24.5 |
| AFTERMATH IN POINTS | 0.4 | +25.7 | 0.0 | 36.5 | - | - | - | - |
| ARRIVAL HUNT | - | - | - | - | 0.1 | +0.7 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 2.5 | +0.0 | 0.0 | 62.1 | 0.3 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | 0.6 | +2.3 | 0.0 | 8.8 | 0.9 | +7.2 | 0.0 | 0.0 |
| BEST FACING | - | - | - | - | 0.4 | +16.0 | 0.0 | 0.0 |
| BEST FIRST | - | - | - | - | 0.9 | +59.5 | 0.0 | 0.0 |
| BEST OVERALL | - | - | - | - | 0.1 | +8.1 | 0.0 | 0.0 |
| BEST PREY | - | - | - | - | 0.3 | +12.9 | 0.0 | 12.1 |
| BLOCKED WHEEL | - | - | - | - | 0.4 | +12.3 | 0.0 | 0.0 |
| BLOWS WHERE AIMED | 0.1 | -0.4 | 17.9 | 0.0 | 0.2 | -33.4 | 21.9 | 0.0 |
| BOMBING RUN | 0.1 | +1.9 | 0.0 | 0.0 | - | - | - | - |
| CANNON PLAN MISSED | 0.7 | +0.0 | 27.1 | 8.9 | 0.3 | +0.0 | 54.3 | 0.0 |
| CANNON PLANNED TARGET | 8.3 | +270.1 | 239.0 | 255.4 | 2.2 | +79.2 | 286.9 | 0.0 |
| CANNON SIGHT KEPT | 2.5 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT COUNTER | 0.1 | -1.9 | 0.0 | 0.0 | - | - | - | - |
| CARRIES OUT SET-UP | 0.1 | +0.0 | 12.4 | 0.0 | - | - | - | - |
| CAST JOB | 0.6 | +16.6 | 19.3 | 13.5 | 0.3 | +5.2 | 69.6 | 0.0 |
| CASTER AWAY FROM SCREEN | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | - | - | - | - | 0.1 | +1.2 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 0.5 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CATCH ODDS | 0.1 | +0.7 | 0.0 | 0.0 | 0.1 | +4.4 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | - | - | - | - | 2.6 | +127.4 | 0.0 | 27.7 |
| CHAFF PASSED | 0.4 | -1.0 | 0.0 | 0.0 | 0.3 | -0.9 | 8.9 | 5.1 |
| CHARACTER GUNS | 0.5 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHARGE LOSSES | 11.9 | -388.9 | 0.0 | 467.4 | - | - | - | - |
| CHARGE NOW FIRST | 1.1 | +0.0 | 64.3 | 30.1 | 3.1 | +0.0 | 305.6 | 66.1 |
| CHARGE NOW WEIGHED | - | - | - | - | 0.5 | -46.4 | 18.0 | 15.4 |
| CHARGER SLAIN LOST | 0.1 | -6.1 | 0.0 | 0.0 | 0.8 | -21.4 | 72.3 | 22.9 |
| CHARIOT WIZARD CAREFUL | - | - | - | - | 0.1 | -0.5 | 0.0 | 0.0 |
| CHEAP HELPER | - | - | - | - | 0.1 | +0.0 | 0.0 | 0.0 |
| COMBAT PIVOT | 0.3 | +0.0 | 0.0 | 18.9 | 0.3 | +0.0 | 26.9 | 0.0 |
| CONVEYANCE SEARCH | 0.9 | +35.2 | 54.3 | 54.3 | 0.4 | +15.5 | 7.7 | 16.7 |
| COVER ONCE | 8.9 | -557.1 | 0.0 | 317.1 | 8.1 | -810.6 | 0.0 | 79.1 |
| DEFENSIVE ARMY | 0.2 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 27.1 | 0.0 |
| EDGE GIVE GROUND | 0.1 | +0.3 | 9.6 | 0.0 | 0.8 | +12.5 | 85.1 | 0.0 |
| FACES THE THREAT | 0.1 | +2.1 | 0.0 | 8.4 | 1.7 | +126.6 | 0.0 | 0.0 |
| FALL BACK GOOD ORDER | 0.9 | +0.2 | 14.9 | 30.1 | - | - | - | - |
| FALLBACK BY WORTH | - | - | - | - | 5.8 | +29.5 | 0.0 | 22.1 |
| FEATURE BUFFS | 0.5 | +5.6 | 0.0 | 0.0 | - | - | - | - |
| FIGHT LIFT | - | - | - | - | 0.3 | +7.1 | 4.3 | 0.0 |
| FIVE ACTION | 45.8 | +1929.3 | 538.0 | 1069.5 | - | - | - | - |
| FLANK NOT WEIGHED | 5.9 | +0.0 | 0.0 | 144.6 | 4.4 | +0.0 | 0.0 | 59.8 |
| FOCUS FIRE | - | - | - | - | 0.1 | +0.2 | 3.2 | 0.0 |
| FOLLOW UP WEIGHED | 0.4 | +48.3 | 0.0 | 0.0 | 0.9 | +141.8 | 0.0 | 38.3 |
| FOUR ROUNDS | 1.4 | +51.0 | 75.1 | 30.1 | - | - | - | - |
| FRIENDS SHOTS CHECKED | 0.1 | +5.4 | 0.0 | 14.6 | 0.1 | +2.8 | 0.0 | 0.0 |
| GIVES UP | - | - | - | - | 0.1 | -7.0 | 5.0 | 0.0 |
| GIVES UP ITS SCREEN | - | - | - | - | 0.1 | -0.4 | 8.9 | 0.0 |
| GUN MASK | 0.6 | +6.3 | 0.0 | 27.6 | - | - | - | - |
| HELPER ALREADY ASKED | - | - | - | - | 0.1 | +0.0 | 14.6 | 0.0 |
| HELPER UNSEEN | - | - | - | - | 0.4 | +0.0 | 0.0 | 13.3 |
| HILL BY ITS CHANCE | - | - | - | - | 0.8 | -65.2 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 1.1 | -50.3 | 57.1 | 30.1 | 8.1 | -228.3 | 510.6 | 48.3 |
| HUNT ADVANCE | - | - | - | - | 0.1 | +14.4 | 0.0 | 0.0 |
| HUNT DROPPED | - | - | - | - | 0.2 | +0.0 | 8.9 | 8.2 |
| HUNT IN PAIRS | 0.4 | +8.9 | 0.0 | 14.6 | 0.5 | +21.3 | 0.0 | 27.9 |
| HUNT RESULT | - | - | - | - | 0.4 | +29.6 | 8.9 | 8.2 |
| HUNT THE GUNS | - | - | - | - | 0.4 | +124.6 | 20.7 | 0.0 |
| IDLE COST | 14.3 | -254.9 | 0.0 | 245.2 | 20.6 | -398.4 | 0.0 | 125.4 |
| INVITES THE FIGHT | - | - | - | - | 1.6 | +15.1 | 61.0 | 12.4 |
| JOINT CHARGE PLAN | - | - | - | - | 0.1 | +1.1 | 0.0 | 0.0 |
| JOINT KNOWS CHALLENGE | - | - | - | - | 0.1 | -1.3 | 26.5 | 0.0 |
| KEEP FALLS | 0.4 | +6.8 | 0.0 | 19.3 | - | - | - | - |
| KEEPS ITS TARGET | - | - | - | - | 1.9 | +55.7 | 134.9 | 22.2 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KILLS COUNT | 0.5 | +26.2 | 24.8 | 15.5 | 1.8 | +123.4 | 134.6 | 46.8 |
| KILLS COUNT NEXT TURN | - | - | - | - | 5.7 | +167.2 | 125.1 | 91.6 |
| LONE CHARACTER SAFE SPOT | 0.2 | -1.6 | 7.4 | 11.6 | 0.1 | +1.1 | 0.0 | 0.0 |
| LONE WIZARD HOLDS BACK | - | - | - | - | 0.5 | +0.0 | 0.0 | 0.0 |
| LONE WIZARD KEPT IN | 0.4 | +15.2 | 0.0 | 0.0 | 0.7 | +52.6 | 0.0 | 0.0 |
| LONG SHOT | - | - | - | - | 0.4 | -0.8 | 21.1 | 0.0 |
| LOST CHARGE | 0.1 | -1.7 | 33.6 | 0.0 | 1.7 | -35.9 | 86.4 | 10.3 |
| MAKE SURE TOGETHER | 0.1 | +0.3 | 0.0 | 0.0 | 0.9 | +73.9 | 0.0 | 0.0 |
| MANOEUVRE | 0.3 | +9.4 | 0.0 | 23.8 | 0.2 | +3.4 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.2 | +1.4 | 0.0 | 18.5 | - | - | - | - |
| MARCH CHECK | 0.4 | +16.3 | 0.0 | 12.4 | 0.6 | +6.4 | 0.0 | 0.0 |
| MARCH ODDS | 0.1 | +2.1 | 0.0 | 0.0 | 0.1 | +2.8 | 0.0 | 0.0 |
| MARCH OVER CASTS | 1.6 | +103.9 | 0.0 | 18.5 | 0.1 | +2.1 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 7.5 | +124.5 | 0.0 | 185.9 | 6.6 | +123.7 | 0.0 | 71.6 |
| MISSILES IN THE MOVE | 5.5 | +165.5 | 0.0 | 147.6 | 2.7 | +42.5 | 0.0 | 7.7 |
| MISSILES NEXT TURN | 7.5 | +100.3 | 0.0 | 177.7 | 4.0 | +34.9 | 0.0 | 7.7 |
| MODEL FACING | 0.4 | +106.9 | 0.0 | 4.3 | - | - | - | - |
| MONSTER WIZARD ROAMS | - | - | - | - | 0.1 | +0.0 | 0.0 | 0.0 |
| MOVE AND CAST | - | - | - | - | 0.1 | +0.6 | 0.0 | 0.0 |
| MOVE SPELL IN RANGE | 0.6 | +15.1 | 0.0 | 54.3 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.2 | -3.4 | 0.0 | 54.3 | 0.1 | -2.1 | 0.0 | 16.7 |
| MOVE SPELL SPOT | 0.5 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE | - | - | - | - | 3.9 | +220.3 | 129.8 | 29.9 |
| MOVES UNITS SPELL | - | - | - | - | 0.1 | +0.5 | 0.0 | 0.0 |
| NO RALLY LEFT | 0.1 | +12.8 | 0.0 | 0.0 | 0.1 | +0.8 | 0.0 | 17.9 |
| NOT NEEDED | - | - | - | - | 0.4 | -6.7 | 49.9 | 0.0 |
| NOT TURNED | 0.1 | +0.0 | 0.0 | 3.2 | 5.6 | +16.4 | 0.0 | 76.6 |
| NOT WORTH A CAST | 0.4 | -0.1 | 0.0 | 54.3 | 0.1 | -0.1 | 0.0 | 0.0 |
| OFF BEST | 1.5 | -33.6 | 0.0 | 33.6 | 17.3 | -809.5 | 26.5 | 90.8 |
| ONE FIGHT FORMULA | 8.5 | -154.5 | 0.0 | 237.1 | 8.6 | -145.6 | 33.9 | 93.2 |
| ONE OBJECTIVE FORMULA | 1.9 | -18.7 | 0.0 | 40.3 | 2.9 | -102.9 | 0.0 | 12.4 |
| OPENS A LANE | 0.1 | +0.3 | 0.0 | 0.0 | - | - | - | - |
| OPENS UP | - | - | - | - | 0.2 | +35.1 | 10.0 | 0.0 |
| OVERRUNS AWAY | 0.4 | +14.2 | 15.7 | 15.5 | 0.6 | +10.0 | 96.1 | 31.9 |
| PATHS CROSS | 1.8 | +135.2 | 0.0 | 25.3 | 2.6 | +211.2 | 0.0 | 5.4 |
| PERIAPT WORTH | - | - | - | - | 0.1 | +3.9 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.1 | -5.9 | 0.0 | 14.6 | 0.1 | -8.8 | 0.0 | 0.0 |
| PLAN RESULT | 40.9 | +829.9 | 508.8 | 1286.4 | 42.1 | +1757.3 | 1499.7 | 553.5 |
| PURSUES BIG PREY | 0.1 | -1.5 | 0.0 | 0.0 | - | - | - | - |
| RANDOM MOVE BY FIGURES | - | - | - | - | 2.0 | +36.5 | 0.0 | 72.9 |
| RANDOM MOVER NO PROMISE | - | - | - | - | 0.7 | -45.9 | 0.0 | 12.1 |
| REDIRECT BY WHAT IT STOPS | - | - | - | - | 1.5 | -23.8 | 0.0 | 25.0 |
| REDIRECT COUNTER | 0.8 | +30.8 | 0.0 | 34.4 | 4.1 | +485.3 | 0.0 | 29.1 |
| REDIRECT WEIGHED | - | - | - | - | 0.6 | +7.6 | 23.6 | 0.0 |
| REFUSING RETIRES | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | 0.2 | +9.6 | 0.0 | 0.0 | 0.9 | +24.4 | 0.0 | 10.3 |
| RESTRAINS TO SHOOT | 0.1 | +2.9 | 0.0 | 0.0 | 0.1 | +7.2 | 0.0 | 0.0 |
| RISK BY ARC | 1.1 | +72.8 | 55.5 | 30.1 | 2.4 | +50.5 | 289.4 | 88.9 |
| RISK ONCE | - | - | - | - | 5.3 | +256.4 | 52.9 | 171.8 |
| RUN DOWN | 0.9 | -13.6 | 59.4 | 15.5 | - | - | - | - |
| SAFER THAN THE JOB | - | - | - | - | 0.4 | +23.1 | 0.0 | 0.0 |
| SCOUT SPOT | 0.4 | +0.4 | 0.0 | 0.0 | 0.6 | +2.5 | 0.0 | 0.0 |
| SCOUT WAITS | 0.4 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 0.9 | -77.9 | 0.0 | 2.7 |
| SEARCH SPOT | 4.3 | +173.9 | 0.0 | 134.3 | 2.9 | +114.3 | 0.0 | 9.3 |
| SELF MOVE SPELL | - | - | - | - | 0.4 | +166.1 | 0.0 | 0.0 |
| SET UP TOGETHER | 0.1 | +0.3 | 0.0 | 0.0 | 1.9 | +136.3 | 0.0 | 5.1 |
| SET-UP ANY TARGET | 0.6 | +61.3 | 54.3 | 54.3 | 0.1 | +18.0 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.4 | +0.7 | 0.0 | 0.0 | 0.2 | +0.3 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.2 | +59.8 | 16.8 | 11.6 | 1.9 | +64.7 | 88.5 | 12.9 |
| SHORT GUN FORWARD | 0.4 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SHOT REPLANNED | 0.9 | +0.0 | 49.2 | 43.6 | 0.6 | +0.0 | 165.3 | 0.0 |
| SHOTS IN THE MOVE | 20.4 | +984.5 | 0.0 | 560.8 | 14.3 | +442.0 | 0.0 | 40.1 |
| SPELL SETS UP CHARGE | 0.6 | +76.3 | 54.3 | 54.3 | 0.1 | +18.0 | 0.0 | 0.0 |
| SPELL WORTH | 1.3 | +16.6 | 12.1 | 12.1 | 2.7 | +47.7 | 8.6 | 4.3 |
| SPELLS IN THE FIGHT | 0.3 | +2.1 | 16.6 | 0.0 | 1.1 | -27.7 | 72.3 | 47.6 |
| STABLE ROLE | - | - | - | - | 8.6 | +0.0 | 370.4 | 86.5 |
| STAND AND SHOOT | 0.1 | -1.0 | 15.7 | 0.0 | - | - | - | - |
| STANDS TO CAST | 0.1 | +3.6 | 0.0 | 0.0 | - | - | - | - |
| STOPS | - | - | - | - | 0.2 | +8.0 | 20.7 | 0.0 |
| STOPS SHORT OF THE FLANK | - | - | - | - | 0.5 | +22.9 | 0.0 | 0.0 |
| STUCK PIVOT | - | - | - | - | 0.2 | +0.0 | 0.0 | 0.0 |
| SUPPORT NARROWED | 0.6 | +0.0 | 10.7 | 15.5 | 8.6 | -81.4 | 331.9 | 97.1 |
| SUPPORTS | - | - | - | - | 6.0 | +83.1 | 95.9 | 31.4 |
| SURE CHARGE BEATS ADVANCE | - | - | - | - | 0.1 | -1.9 | 8.4 | 0.0 |
| SURE REACH TOGETHER | 0.2 | +1.3 | 0.0 | 0.0 | 0.5 | -8.0 | 0.0 | 0.0 |
| THROUGH LINE OF FIRE | - | - | - | - | 0.1 | +0.6 | 0.0 | 0.0 |
| TIME ON OUR SIDE | 3.1 | +0.0 | 15.1 | 44.6 | - | - | - | - |
| TURN WORTH | 0.1 | -4.8 | 9.9 | 0.0 | 0.1 | -10.7 | 11.8 | 0.0 |
| TWO OR MORE ARRIVE | - | - | - | - | 0.9 | +6.0 | 0.0 | 5.1 |
| WAIT AFTER COSTS | - | - | - | - | 6.9 | -339.3 | 227.6 | 42.2 |
| WALKS TO THE FIGHT | - | - | - | - | 1.1 | +7.8 | 25.3 | 0.0 |
| WAR ENGINE CHARGES | 0.1 | +2.4 | 0.0 | 0.0 | - | - | - | - |
| WAR ENGINE JOBS | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WEARS DOWN | 0.4 | +25.1 | 17.9 | 14.6 | 0.9 | +40.3 | 118.6 | 42.1 |
| WHO HITS BACK | 0.1 | +10.6 | 0.0 | 18.0 | - | - | - | - |
| WHOLE FIGHT | 0.1 | +0.1 | 0.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT GAIN | 0.1 | +12.9 | 0.0 | 0.0 | 0.9 | +87.5 | 123.6 | 17.8 |
| WIDER SPREAD | 0.9 | -3.0 | 37.1 | 15.5 | 3.5 | -11.4 | 342.7 | 47.0 |

### Rule changes: fa-h2h-mine-8a94331-p3b

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 263 | 263 | 263 | 18.79 | -11803 | -44.9 |
| SEARCH SPOT | 101 | 101 | 96 | 6.86 | +4035 | +42.0 |
| PATHS CROSS | 61 | 61 | 61 | 4.36 | +4849 | +79.5 |
| SHOTS IN THE MOVE | 486 | 379 | 48 | 3.43 | +2087 | +43.5 |
| ARTILLERY RE-ROLL WEIGHED | 39 | 39 | 39 | 2.79 | +0 | +0.0 |
| SUPPORTS | 84 | 84 | 39 | 2.79 | +457 | +11.7 |
| CANNON SIGHT KEPT | 37 | 37 | 37 | 2.64 | +0 | +0.0 |
| COVER ONCE | 238 | 127 | 34 | 2.43 | +755 | +22.2 |
| MAX FOR POSITIONING | 198 | 165 | 33 | 2.36 | +216 | +6.5 |
| IDLE COST | 489 | 251 | 29 | 2.07 | +300 | +10.4 |
| MOVE TO CHARGE | 54 | 54 | 29 | 2.07 | +1149 | +39.6 |
| CANNON PLANNED TARGET | 147 | 147 | 28 | 2.00 | -222 | -7.9 |
| FACES THE THREAT | 25 | 25 | 25 | 1.79 | +1803 | +72.1 |
| MISSILES IN THE MOVE | 115 | 71 | 24 | 1.71 | +757 | +31.5 |
| CHARGE LOSSES | 167 | 167 | 23 | 1.64 | +2231 | +97.0 |
| SHOOTS FROM THE BEST SPOT | 43 | 43 | 23 | 1.64 | +482 | +20.9 |
| KILLS COUNT NEXT TURN | 80 | 80 | 22 | 1.57 | +571 | +26.0 |
| SHOT REPLANNED | 22 | 22 | 22 | 1.57 | +0 | +0.0 |
| ONE FIGHT FORMULA | 240 | 128 | 20 | 1.43 | +115 | +5.8 |
| WAIT AFTER COSTS | 97 | 97 | 20 | 1.43 | +446 | +22.3 |
| CHAFF IN THE MOVE | 36 | 35 | 19 | 1.36 | +796 | +41.9 |
| FOLLOW UP WEIGHED | 18 | 18 | 18 | 1.29 | +2662 | +147.9 |
| RANDOM MOVE BY FIGURES | 28 | 28 | 18 | 1.29 | +511 | +28.4 |
| REDIRECT COUNTER | 69 | 32 | 18 | 1.29 | +1684 | +93.6 |
| CHARGE NOW FIRST | 60 | 60 | 16 | 1.14 | -479 | -29.9 |
| LONE WIZARD KEPT IN | 15 | 15 | 15 | 1.07 | +950 | +63.3 |
| RESERVE FALL BACK | 15 | 15 | 15 | 1.07 | +476 | +31.8 |
| ADVANCE LANE KEPT | 14 | 14 | 14 | 1.00 | +0 | +0.0 |
| HOLDS AMBUSHERS | 14 | 14 | 14 | 1.00 | +0 | +0.0 |
| RISK BY ARC | 49 | 47 | 14 | 1.00 | +439 | +31.3 |
| SCOUT WAITS | 14 | 14 | 14 | 1.00 | +0 | +0.0 |
| BEST FIRST | 13 | 13 | 13 | 0.93 | +832 | +64.0 |
| MARCH CHECK | 14 | 14 | 13 | 0.93 | +132 | +10.1 |
| SET UP TOGETHER | 28 | 20 | 12 | 0.86 | +863 | +71.9 |
| ADVANCE WORTH | 68 | 68 | 11 | 0.79 | +547 | +49.7 |
| FALLBACK BY WORTH | 81 | 81 | 11 | 0.79 | +413 | +37.6 |
| RISK ONCE | 74 | 54 | 11 | 0.79 | +711 | +64.6 |
| WHOLE FIGHT GAIN | 15 | 15 | 11 | 0.79 | +442 | +40.2 |
| CHAFF PASSED | 10 | 10 | 10 | 0.71 | -26 | -2.6 |
| FOUR ROUNDS | 19 | 18 | 10 | 0.71 | +427 | +42.7 |
| INVITES THE FIGHT | 23 | 23 | 10 | 0.71 | +66 | +6.6 |
| KILLS COUNT | 32 | 30 | 10 | 0.71 | +467 | +46.7 |
| HONEST WORTH | 129 | 126 | 9 | 0.64 | +42 | +4.6 |
| REDIRECT WEIGHED | 9 | 9 | 9 | 0.64 | +361 | +40.1 |
| COMBAT PIVOT | 8 | 8 | 8 | 0.57 | +0 | +0.0 |
| SHOOTERS IN TWO RANKS | 8 | 8 | 8 | 0.57 | +14 | +1.8 |
| CAST JOB | 12 | 12 | 7 | 0.50 | +50 | +7.2 |
| CHARGE NOW WEIGHED | 7 | 7 | 7 | 0.50 | +518 | +74.0 |
| STOPS SHORT OF THE FLANK | 7 | 7 | 7 | 0.50 | +320 | +45.8 |
| WEARS DOWN | 19 | 18 | 7 | 0.50 | +311 | +44.4 |
| BEST FACING | 6 | 6 | 6 | 0.43 | +224 | +37.4 |
| SAFER THAN THE JOB | 6 | 6 | 6 | 0.43 | +323 | +53.8 |
| SUPPORT NARROWED | 128 | 128 | 6 | 0.43 | -62 | -10.3 |
| AFTERMATH IN POINTS | 5 | 5 | 5 | 0.36 | +360 | +72.1 |
| BLOCKED WHEEL | 5 | 5 | 5 | 0.36 | +173 | +34.6 |
| HUNT IN PAIRS | 12 | 6 | 5 | 0.36 | +105 | +21.0 |
| KEEP FALLS | 5 | 5 | 5 | 0.36 | +196 | +39.2 |
| MAKE SURE TOGETHER | 15 | 7 | 5 | 0.36 | +531 | +106.1 |
| MANOEUVRE | 7 | 7 | 5 | 0.36 | +180 | +36.0 |
| MODEL FACING | 5 | 5 | 5 | 0.36 | +1496 | +299.3 |
| SHORT GUN FORWARD | 5 | 5 | 5 | 0.36 | +0 | +0.0 |
| WALKS TO THE FIGHT | 15 | 15 | 5 | 0.36 | +36 | +7.2 |
| CASTER AWAY FROM SCREEN | 4 | 4 | 4 | 0.29 | +0 | +0.0 |
| CASTS FROM BEHIND | 4 | 4 | 4 | 0.29 | +0 | +0.0 |
| KEEPS ITS TARGET | 26 | 26 | 4 | 0.29 | +50 | +12.6 |
| ONE OBJECTIVE FORMULA | 67 | 35 | 4 | 0.29 | +21 | +5.2 |
| RESTRAINS TO SHOOT | 4 | 4 | 4 | 0.29 | +141 | +35.3 |
| SURE REACH TOGETHER | 10 | 9 | 4 | 0.29 | +9 | +2.2 |
| MARCH ODDS | 3 | 3 | 3 | 0.21 | -38 | -12.7 |
| MISSILES NEXT TURN | 161 | 89 | 3 | 0.21 | +18 | +6.0 |
| NO RALLY LEFT | 3 | 3 | 3 | 0.21 | +106 | +35.3 |
| OPENS UP | 3 | 3 | 3 | 0.21 | +163 | +54.3 |
| OVERRUNS AWAY | 15 | 15 | 3 | 0.21 | +97 | +32.5 |
| PIVOT GUARDS FLANK | 3 | 3 | 3 | 0.21 | -206 | -68.8 |
| REFUSING RETIRES | 4 | 4 | 3 | 0.21 | -1 | -0.4 |
| STUCK PIVOT | 3 | 3 | 3 | 0.21 | +0 | +0.0 |
| BACKUP TARGETS | 21 | 11 | 2 | 0.14 | +30 | +15.1 |
| BEST OVERALL | 2 | 2 | 2 | 0.14 | +114 | +56.8 |
| CATCH ODDS | 2 | 2 | 2 | 0.14 | -40 | -20.2 |
| DEFENSIVE ARMY | 8 | 8 | 2 | 0.14 | -585 | -292.7 |
| FRIENDS SHOTS CHECKED | 2 | 2 | 2 | 0.14 | +116 | +57.8 |
| WAR ENGINE JOBS | 2 | 2 | 2 | 0.14 | -58 | -29.0 |
| WHO HITS BACK | 2 | 2 | 2 | 0.14 | +112 | +55.8 |
| WIDER SPREAD | 61 | 58 | 2 | 0.14 | +7 | +3.4 |
| BEST PREY | 4 | 4 | 1 | 0.07 | +48 | +48.1 |
| BOMBING RUN | 1 | 1 | 1 | 0.07 | +27 | +27.1 |
| CARRIES OUT COUNTER | 1 | 1 | 1 | 0.07 | -26 | -26.3 |
| CASTING BLOCK | 1 | 1 | 1 | 0.07 | +9 | +9.3 |
| EDGE GIVE GROUND | 13 | 13 | 1 | 0.07 | +6 | +6.3 |
| FOCUS FIRE | 1 | 1 | 1 | 0.07 | +3 | +2.9 |
| GUN MASK | 9 | 9 | 1 | 0.07 | +28 | +27.6 |
| HUNT ADVANCE | 2 | 2 | 1 | 0.07 | +48 | +48.1 |
| KEEPS SCOUTS OR AMBUSH | 1 | 1 | 1 | 0.07 | +0 | +0.0 |
| LOST CHARGE | 26 | 26 | 1 | 0.07 | +102 | +101.5 |
| MOVE AND CAST | 1 | 1 | 1 | 0.07 | +9 | +8.7 |
| MOVES UNITS SPELL | 1 | 1 | 1 | 0.07 | +7 | +7.3 |
| OPENS A LANE | 1 | 1 | 1 | 0.07 | +4 | +4.3 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.07 | +54 | +54.4 |
| PURSUES BIG PREY | 1 | 1 | 1 | 0.07 | -21 | -20.8 |
| SPELLS IN THE FIGHT | 19 | 19 | 1 | 0.07 | +3 | +3.1 |
| STANDS TO CAST | 1 | 1 | 1 | 0.07 | -46 | -45.9 |
| STOPS | 3 | 3 | 1 | 0.07 | +28 | +28.0 |
| SURE CHARGE BEATS ADVANCE | 1 | 1 | 1 | 0.07 | -26 | -26.0 |
| THROUGH LINE OF FIRE | 1 | 1 | 1 | 0.07 | +9 | +8.8 |
| WAR ENGINE CHARGES | 1 | 1 | 1 | 0.07 | +28 | +27.8 |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| BLOWS WHERE AIMED | 4 | 3 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 14 | 14 | 0 | 0.00 | - | - |
| CARRIES OUT SET-UP | 1 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 13 | trace | - | - | - | - |
| CHARACTER GUNS | 7 | 7 | 0 | 0.00 | - | - |
| CHARGER SLAIN LOST | 13 | 13 | 0 | 0.00 | - | - |
| CHARIOT WIZARD CAREFUL | 1 | 1 | 0 | 0.00 | - | - |
| CHEAP HELPER | 1 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 18 | not checked | - | - | - | - |
| FALL BACK GOOD ORDER | 12 | 12 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 7 | 7 | 0 | 0.00 | - | - |
| FIGHT LIFT | 4 | not checked | - | - | - | - |
| FIVE ACTION | 641 | 640 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 145 | not checked | - | - | - | - |
| GIVES UP | 2 | 2 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 1 | 1 | 0 | 0.00 | - | - |
| HELPER ALREADY ASKED | 1 | not checked | - | - | - | - |
| HELPER UNSEEN | 5 | 5 | 0 | 0.00 | - | - |
| HILL BY ITS CHANCE | 11 | 11 | 0 | 0.00 | - | - |
| HUNT DROPPED | 3 | trace | - | - | - | - |
| HUNT RESULT | 5 | trace | - | - | - | - |
| HUNT THE GUNS | 5 | trace | - | - | - | - |
| JOINT CHARGE PLAN | 2 | 2 | 0 | 0.00 | - | - |
| JOINT KNOWS CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 5 | not checked | - | - | - | - |
| LONE WIZARD HOLDS BACK | 7 | 7 | 0 | 0.00 | - | - |
| LONG SHOT | 5 | 5 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 3 | trace | - | - | - | - |
| MARCH OVER CASTS | 24 | 24 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 1 | 1 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 8 | 7 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 5 | trace | - | - | - | - |
| MOVE SPELL SPOT | 10 | not checked | - | - | - | - |
| NOT NEEDED | 5 | 5 | 0 | 0.00 | - | - |
| NOT TURNED | 79 | 79 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 7 | not checked | - | - | - | - |
| PLAN RESULT | 1162 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 10 | 10 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 21 | 21 | 0 | 0.00 | - | - |
| RUN DOWN | 13 | 13 | 0 | 0.00 | - | - |
| SCOUT SPOT | 14 | 14 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 12 | 12 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 6 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 10 | not checked | - | - | - | - |
| SPELL SETS UP CHARGE | 11 | not checked | - | - | - | - |
| SPELL WORTH | 56 | not checked | - | - | - | - |
| STABLE ROLE | 120 | 120 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 1 | 1 | 0 | 0.00 | - | - |
| TIME ON OUR SIDE | 43 | 43 | 0 | 0.00 | - | - |
| TURN WORTH | 3 | 3 | 0 | 0.00 | - | - |
| TWO OR MORE ARRIVE | 12 | 10 | 0 | 0.00 | - | - |
| WHOLE FIGHT | 2 | 2 | 0 | 0.00 | - | - |

### Off best figure: fa-h2h-mine-8a94331-p3b

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 1.14 | 15.64 | 44.8 |
| CHARGE NOW FIRST | rule | 0.29 | 0.86 | 29.9 |
| TURN GATE | gate | - | 0.79 | 65.3 |
| CANNON PLANNED TARGET | rule | 0.29 | 0.36 | 38.6 |
| FALLBACK | gate | - | 0.50 | 26.7 |
| SUPPORT NARROWED | rule | 0.07 | 0.36 | 10.3 |
| CHAFF PASSED | rule | 0.21 | 0.14 | 5.2 |
| NO REASON | gate | 0.21 | - | 46.5 |
| PIVOT GUARDS FLANK | rule | 0.07 | 0.14 | 68.8 |
| CATCH ODDS | rule | 0.07 | 0.07 | 20.2 |
| DEFENSIVE ARMY | rule | 0.07 | 0.07 | 292.7 |
| FIGHT ORDER BAND | gate | - | 0.14 | 1.5 |
| LONE CHARACTER SAFE SPOT | gate | 0.07 | 0.07 | 12.4 |
| MARCH ODDS | rule | 0.07 | 0.07 | 18.8 |
| WAR ENGINE JOBS | rule | 0.14 | - | 29.0 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.07 | - | 81.0 |
| CARRIES OUT COUNTER | rule | 0.07 | - | 26.3 |
| PATHS CROSS | rule | 0.07 | - | 28.2 |
| PURSUES BIG PREY | rule | 0.07 | - | 20.8 |
| REFUSING RETIRES | rule | 0.07 | - | 0.7 |
| RULE SWITCHED OFF | gate | - | 0.07 | 1.9 |
| STANDS TO CAST | rule | 0.07 | - | 45.9 |
| SUPPORT REQUEST | gate | - | 0.07 | 121.2 |
| SURE CHARGE BEATS ADVANCE | rule | - | 0.07 | 26.0 |

### Plans: fa-h2h-mine-8a94331-p3b

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.0 | 79% | 121 | 93 | 77% |
| Mine | join | 0.6 | 67% | 12 | 0 | 0% |
| Mine | move | 26.4 | 93% | 1357 | 0 | 0% |
| Mine | shoot | 12.9 | 66% | 490 | 737 | 150% |
| Opponent | advance | 12.3 | 13% | 183 | 426 | 233% |
| Opponent | charge | 4.1 | 67% | 342 | 539 | 158% |
| Opponent | close in | 5.3 | 20% | 287 | 117 | 41% |
| Opponent | hold | 5.1 | 36% | 359 | 0 | 0% |
| Opponent | join | 0.6 | 100% | 30 | 0 | 0% |
| Opponent | shoot | 6.6 | 71% | 216 | 674 | 313% |
| Opponent | support | 8.0 | 93% | 73 | 0 | 0% |

### Packages: hunt the guns, fa-h2h-mine-8a94331-p3b

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 46 |
| Opponent | 0.4 | 5 | 0 | 40% | 40% | 0% | 2.0 | 349 | 83 | 40% | 82 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 130 |
| High Elf Realms | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 581 | 0 | 0% | 0 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 100 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 130 |
| Tomb Kings of Khemri | 0.3 | 1 | 0 | 0% | 0% | 0% | - | 385 | 0 | 0% | 89 |
| Vampire Counts | 0.5 | 1 | 0 | 100% | 100% | 0% | 2.0 | 198 | 162 | 100% | 0 |
| Warriors of Chaos | 0.3 | 1 | 0 | 100% | 100% | 0% | 2.0 | 282 | 252 | 100% | 95 |
| Wood Elf Realms | 1.0 | 1 | 0 | 0% | 0% | 0% | - | 299 | 0 | 0% | 361 |

### Battle groups: fa-h2h-mine-8a94331-p3b

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 0.8 | 27% | 67% | 0% | - | 0% | 0% | 0% | 100% | 0% |
| Opponent | REDIRECT COUNTER | 4.1 | 5% | 100% | 33% | 0% | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: fa-h2h-mine-8a94331-p3b

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 3 | 0 (3) | 0 | 0 | 100 | 33% | 3.0 | 0 (3) | - | - | 0 (3) | - |
| Mine | Character | 52 | 25 (52) | 25 | 0 | 41 | 29% | 2.4 | 43 (19) | 21 (21) | 18 (1) | 35 (26) | 19 (15) |
| Mine | Clean-up | 3 | 0 (3) | 0 | 0 | 13 | 33% | 1.5 | - | 0 (3) | - | 0 (3) | - |
| Mine | Fast Hammer | 23 | 44 (23) | 13 | 31 | 36 | 39% | 3.1 | 36 (12) | 44 (7) | 67 (4) | 55 (16) | 22 (7) |
| Mine | Hammer | 13 | 12 (13) | 12 | 0 | 44 | 31% | 2.1 | 24 (5) | 0 (8) | - | 18 (9) | 0 (4) |
| Mine | Holder | 5 | 70 (5) | 0 | 70 | 0 | 20% | 3.5 | 0 (2) | 113 (3) | - | 87 (4) | 0 (1) |
| Mine | Shooter | 22 | 45 (22) | 22 | 24 | 69 | 0% | 2.0 | 0 (4) | 60 (16) | 0 (2) | 38 (15) | 59 (7) |
| Mine | War machine | 37 | 25 (37) | 25 | 0 | 62 | 3% | 1.3 | 15 (9) | 29 (27) | 0 (1) | 0 (9) | 32 (28) |
| Mine | Wizard | 3 | 0 (3) | 0 | 0 | 23 | 33% | 2.0 | 0 (1) | 0 (1) | - | 0 (2) | - |
| Opponent | Chaff | 29 | 27 (29) | 14 | 13 | 42 | 52% | 2.7 | 28 (13) | 40 (7) | 15 (9) | 37 (21) | 0 (8) |
| Opponent | Character | 38 | 61 (38) | 61 | 0 | 7 | 29% | 2.5 | 69 (17) | 58 (20) | - | 55 (18) | 68 (19) |
| Opponent | Clean-up | 5 | 36 (5) | 21 | 15 | 12 | 40% | 3.7 | 37 (3) | 34 (2) | - | 40 (3) | 29 (2) |
| Opponent | Fast | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Fast Hammer | 20 | 39 (20) | 25 | 13 | 44 | 55% | 3.2 | 42 (8) | 38 (8) | 32 (4) | 13 (8) | 64 (12) |
| Opponent | Fragile | 3 | 31 (3) | 31 | 0 | 100 | 33% | 2.0 | - | 46 (2) | 0 (1) | 46 (2) | 0 (1) |
| Opponent | Hammer | 17 | 65 (17) | 50 | 14 | 21 | 35% | 2.3 | 82 (5) | 59 (12) | - | 98 (10) | 23 (7) |
| Opponent | Holder | 22 | 96 (22) | 16 | 81 | 16 | 32% | 2.2 | 0 (3) | 134 (13) | 83 (6) | 115 (16) | 55 (6) |
| Opponent | Shooter | 10 | 32 (10) | 26 | 6 | 14 | 10% | 1.7 | 0 (3) | 16 (5) | 178 (2) | 10 (6) | 64 (4) |
| Opponent | Support | 2 | 0 (2) | 0 | 0 | 0 | 100% | - | 0 (2) | - | - | 0 (1) | 0 (1) |
| Opponent | War machine | 7 | 91 (7) | 91 | 0 | 14 | 14% | 1.0 | 0 (1) | 125 (5) | 0 (1) | - | 91 (7) |
| Opponent | Wizard | 16 | 0 (16) | 0 | 0 | 18 | 19% | 2.5 | 0 (6) | 0 (6) | 0 (1) | 0 (7) | 0 (6) |

### Charged fights: fa-h2h-mine-8a94331-p3b

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Dwarfen Mountain Holds | 2 | 288 | 0 | 2.0 | 1.2 | 0 | 98 | -98 | 1 of 4 | 3 of 4 | +0 | -131 |
| Mine | Empire of Man | 5 | 242 | 50 | 0.4 | 1.0 | 126 | 0 | +126 | 2 of 2 | 1 of 2 | - | +126 |
| Mine | Grand Cathay | 5 | 252 | 128 | 1.8 | 1.0 | 71 | 0 | +71 | 1 of 9 | 6 of 9 | - | +71 |
| Mine | High Elf Realms | 2 | 165 | 75 | 1.5 | 1.0 | 50 | 0 | +50 | 0 of 3 | 2 of 3 | - | +50 |
| **Mine** | all armies | 14 | 241 | 74 | 1.3 | 1.1 | 58 | 22 | +36 | 4 of 18 | 12 of 18 | +0 | +38 |
| Opponent | Empire of Man | 1 | 569 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | High Elf Realms | 2 | 534 | 336 | 2.0 | 1.0 | 168 | 0 | +168 | 0 of 4 | 4 of 4 | - | +168 |
| Opponent | Kingdom of Bretonnia | 1 | 217 | 498 | 4.0 | 1.2 | 124 | 0 | +124 | 2 of 4 | 3 of 4 | +0 | +166 |
| Opponent | Skaven | 1 | 60 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Tomb Kings of Khemri | 3 | 84 | 905 | 4.0 | 1.0 | 226 | 0 | +226 | 6 of 12 | 8 of 12 | - | +226 |
| Opponent | Vampire Counts | 2 | 0 | 536 | 4.0 | 1.1 | 134 | 29 | +105 | 3 of 8 | 7 of 8 | +162 | +97 |
| Opponent | Warriors of Chaos | 3 | 0 | 276 | 3.0 | 1.0 | 92 | 51 | +41 | 4 of 9 | 7 of 9 | - | +41 |
| Opponent | Wood Elf Realms | 1 | 0 | 320 | 5.0 | 1.0 | 64 | 21 | +43 | 2 of 5 | 3 of 5 | - | +43 |
| **Opponent** | all armies | 14 | 155 | 436 | 3.0 | 1.0 | 145 | 19 | +126 | 17 of 42 | 32 of 42 | +81 | +129 |

### Effective charges: fa-h2h-mine-8a94331-p3b

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Dwarfen Mountain Holds | 4 | 1 (net +0) | 0 | 0 | 3 (net -131) | 0 | 0 | 0 | 0% (0 of 4) |
| Mine | Empire of Man | 2 | 1 (net +0) | 0 | 1 (net +251) | 0 | 0 | 0 | 0 | 50% (1 of 2) |
| Mine | Grand Cathay | 9 | 0 | 1 (net +0) | 2 (net +68) | 3 (net +122) | 0 | 3 (net +46) | 0 | 22% (2 of 9) |
| Mine | High Elf Realms | 3 | 1 (net +90) | 0 | 0 | 0 | 1 (net +60) | 0 | 1 | 0% (0 of 2) |
| Opponent | High Elf Realms | 4 | 0 | 0 | 0 | 0 | 1 (net +130) | 3 (net +180) | 0 | 0% (0 of 4) |
| Opponent | Kingdom of Bretonnia | 4 | 0 | 0 | 2 (net +0) | 2 (net +249) | 0 | 0 | 0 | 50% (2 of 4) |
| Opponent | Tomb Kings of Khemri | 12 | 4 (net +383) | 0 | 0 | 5 (net +191) | 0 | 1 (net +0) | 2 | 0% (0 of 10) |
| Opponent | Vampire Counts | 8 | 2 (net +170) | 0 | 2 (net +94) | 2 (net +12) | 1 (net +162) | 0 | 1 | 29% (2 of 7) |
| Opponent | Warriors of Chaos | 9 | 0 | 0 | 3 (net -153) | 3 (net +276) | 0 | 1 (net +0) | 2 | 43% (3 of 7) |
| Opponent | Wood Elf Realms | 5 | 0 | 0 | 0 | 1 (net +117) | 0 | 0 | 4 | 0% (0 of 1) |

### Charged fights, damage counted: fa-h2h-mine-8a94331-p3b

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 3 | 272 | 265 | +30 | 37 | 52 | -14 | -5.3 |
| Mine | 50-54% | 1 | 205 | 342 | +0 | 114 | 171 | -57 | -27.7 |
| Mine | Effective (55-75%) | 3 | 272 | 183 | +129 | 148 | 36 | +112 | +41.1 |
| Mine | 76-89% | 6 | 184 | 129 | -5 | 97 | 92 | +6 | +3.0 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 | 295 | 183 | +46 | 46 | 0 | +46 | +15.7 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 400 | 60 | +60 | 78 | 0 | +78 | +19.5 |
| Mine | No odds | 1 | 143 | 72 | +0 | 51 | 0 | +51 | +35.7 |
| Mine | All fights | 18 | 243 | 175 | +36 | 85 | 55 | +30 | +12.3 |
| Opponent | Long shot (under 50%) | 6 | 388 | 272 | +312 | 358 | 87 | +271 | +69.8 |
| Opponent | Effective (55-75%) | 7 | 236 | 240 | -38 | 64 | 83 | -20 | -8.4 |
| Opponent | 76-89% | 13 | 278 | 185 | +186 | 219 | 20 | +198 | +71.5 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 5 | 360 | 162 | +108 | 130 | 0 | +130 | +36.0 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 2 | 474 | 146 | +146 | 146 | 0 | +146 | +30.8 |
| Opponent | No odds | 9 | 252 | 184 | +50 | 115 | 31 | +84 | +33.4 |
| Opponent | All fights | 42 | 300 | 202 | +126 | 176 | 39 | +137 | +45.7 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| fa-h2h-mine-8a94331-p3b | move | 155 | 27 (17%) | 17 (11%) | 13 (8%) | 115 (74%) |
| fa-h2h-mine-8a94331-p3b | objective | 75 | 8 (11%) | 6 (8%) | 13 (17%) | 54 (72%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L0725, L1327 |
| Clockwork Compass | Mine | L1216, L1232 |
| Elixir of Power | Mine | L1122 |
| Horn of the Wild Hunt | Opponent | L0533 |
| Invocation of Nehek | Opponent | L0725, L1327 |
| Opal Amulet | Mine | L1422 |
| Periapt of Soul Exchange | Opponent | L0620 |
| Ring of Doom | Mine | L1122, L1216, L1232 |
| Ring of Doom | Opponent | L0533, L0815, L0831 |
| Ring of Jet | Mine | L1013, L1030, L1122, L1216, L1232 |
| Standard of the Fell Warrior | Mine | L1327 |
| Standard of the Fell Warrior | Opponent | L1013 |
| Twice-Blessed Armour | Mine | L0709, L0725, L1013, L1030 |
| Witch Hunter's Ward | Mine | L0709, L0725, L0815, L0831 |

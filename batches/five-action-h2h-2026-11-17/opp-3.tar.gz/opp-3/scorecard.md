# Doctrine scorecard: fa-h2h-opp-8a94331-p3

### Scorecard: fa-h2h-opp-8a94331-p3

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0110 | 2 | 1 | Mine | - | - | 5 | 2 | 2 | 0 | 0 | 0 | 322 |
| L0110 | 2 | 1 | Opponent | - | - | 4 | 2 | 1 | 1 | 0 | 0 | 0 |
| L0126 | 6 | 1 | Mine | no | 5 | - | 0 | 2 | 0 | 0 | 0 | 0 |
| L0126 | 6 | 1 | Opponent | no | 10 | 3 | 2 | 2 | 0 | 0 | 0 | 0 |
| L0210 | 6 | 1 | Mine | no | 0 | 3 | 1 | 2 | 0 | 0 | 0 | 0 |
| L0210 | 6 | 1 | Opponent | no | 6 | 6 | 1 | 0 | 0 | 0 | 0 | 165 |
| L0226 | 4 | 1 | Mine | no | 1 | 2 | 2 | 4 | 0 | 0 | 0 | 170 |
| L0226 | 4 | 1 | Opponent | no | 8 | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| L0311 | 5 | 1 | Mine | yes | - | 3 | 1 | 3 | 0 | 0 | 0 | 590 |
| L0311 | 5 | 1 | Opponent | yes | - | - | 0 | 1 | 2 | 0 | 0 | 433 |
| L0327 | 3 | 1 | Mine | yes | 13 | 6 | 1 | 0 | 0 | 0 | 0 | 985 |
| L0327 | 3 | 1 | Opponent | no | 5 | 2 | 2 | 1 | 1 | 0 | 0 | 0 |
| L0413 | 5 | 1 | Mine | yes | - | 2 | 6 | 2 | 0 | 0 | 0 | 0 |
| L0413 | 5 | 1 | Opponent | no | - | 6 | 1 | 1 | 1 | 0 | 0 | 70 |
| L0429 | 3 | 1 | Mine | no | 2 | 2 | 1 | 2 | 0 | 0 | 0 | 0 |
| L0429 | 3 | 1 | Opponent | no | 5 | 3 | 2 | 1 | 1 | 0 | 0 | 170 |
| L0516 | 6 | 1 | Mine | no | 0 | 3 | 1 | 0 | 0 | 0 | 0 | 548 |
| L0516 | 6 | 1 | Opponent | no | 1 | - | 1 | 3 | 1 | 0 | 0 | 100 |
| L0533 | 5 | 1 | Mine | no | - | 6 | 0 | 1 | 0 | 0 | 0 | 686 |
| L0533 | 5 | 1 | Opponent | yes | - | 4 | 1 | 6 | 0 | 0 | 0 | 0 |
| L0620 | 2 | 1 | Mine | - | - | - | 0 | 2 | 0 | 0 | 0 | 615 |
| L0620 | 2 | 1 | Opponent | - | - | 5 | 3 | 5 | 0 | 0 | 0 | 210 |
| L0709 | 1 | 1 | Mine | yes | 4 | 3 | 0 | 2 | 1 | 0 | 0 | 420 |
| L0709 | 1 | 1 | Opponent | no | 0 | 4 | 1 | 1 | 0 | 0 | 0 | 420 |
| L0725 | 5 | 1 | Mine | yes | - | 2 | 1 | 0 | 0 | 0 | 0 | 375 |
| L0725 | 5 | 1 | Opponent | yes | - | 5 | 2 | 3 | 1 | 0 | 0 | 0 |
| L0815 | 5 | 1 | Mine | no | - | - | 0 | 1 | 0 | 0 | 0 | 780 |
| L0815 | 5 | 1 | Opponent | yes | - | 2 | 2 | 1 | 0 | 0 | 0 | 291 |
| L0831 | 3 | 1 | Mine | no | 0 | 2 | 2 | 0 | 0 | 0 | 0 | 769 |
| L0831 | 3 | 1 | Opponent | no | 6 | - | 1 | 1 | 0 | 0 | 0 | 340 |
| L0922 | 4 | 1 | Mine | no | 0 | 5 | 1 | 1 | 0 | 0 | 0 | 781 |
| L0922 | 4 | 1 | Opponent | no | 0 | 2 | 5 | 1 | 0 | 0 | 0 | 0 |
| L1013 | 5 | 1 | Mine | yes | - | 2 | 3 | 0 | 1 | 0 | 0 | 330 |
| L1013 | 5 | 1 | Opponent | yes | - | 3 | 2 | 2 | 0 | 0 | 0 | 291 |
| L1030 | 4 | 1 | Mine | no | 0 | 2 | 1 | 0 | 0 | 0 | 0 | 330 |
| L1030 | 4 | 1 | Opponent | no | 0 | - | 0 | 4 | 2 | 0 | 0 | 0 |
| L1122 | 6 | 1 | Mine | no | 2 | 6 | 1 | 0 | 1 | 0 | 0 | 330 |
| L1122 | 6 | 1 | Opponent | no | 1 | 2 | 2 | 2 | 1 | 0 | 0 | 72 |
| L1216 | 4 | 1 | Mine | no | 2 | 3 | 3 | 0 | 0 | 0 | 0 | 330 |
| L1216 | 4 | 1 | Opponent | no | 0 | 4 | 1 | 0 | 0 | 0 | 0 | 0 |
| L1232 | 2 | 1 | Mine | - | - | 3 | 3 | 0 | 1 | 0 | 0 | 330 |
| L1232 | 2 | 1 | Opponent | - | - | 3 | 3 | 1 | 0 | 0 | 0 | 340 |
| L1327 | 1 | 1 | Mine | no | 12 | 4 | 2 | 0 | 0 | 0 | 0 | 370 |
| L1327 | 1 | 1 | Opponent | no | 2 | 2 | 3 | 3 | 0 | 0 | 0 | 0 |
| L1422 | 6 | 1 | Mine | no | 12 | 2 | 4 | 1 | 1 | 0 | 0 | 0 |
| L1422 | 6 | 1 | Opponent | no | 3 | 2 | 1 | 1 | 0 | 0 | 0 | 199 |
| L1519 | 1 | 1 | Mine | no | 2 | 2 | 4 | 0 | 0 | 0 | 0 | 521 |
| L1519 | 1 | 1 | Opponent | no | 0 | 2 | 5 | 2 | 0 | 0 | 0 | 235 |
| L1535 | 5 | 1 | Mine | yes | - | 4 | 2 | 1 | 0 | 0 | 0 | 0 |
| L1535 | 5 | 1 | Opponent | no | - | 2 | 3 | 4 | 0 | 0 | 0 | 140 |
| L1633 | 1 | 1 | Mine | no | 7 | 6 | 2 | 1 | 0 | 0 | 0 | 200 |
| L1633 | 1 | 1 | Opponent | no | 0 | 1 | 4 | 2 | 0 | 0 | 0 | 234 |
| L1731 | 3 | 1 | Mine | no | 1 | 2 | 5 | 0 | 0 | 0 | 0 | 0 |
| L1731 | 3 | 1 | Opponent | no | 5 | 2 | 4 | 0 | 1 | 0 | 0 | 340 |
| L1831 | 1 | 1 | Mine | no | 0 | 3 | 5 | 1 | 1 | 0 | 0 | 0 |
| L1831 | 1 | 1 | Opponent | no | 2 | 2 | 2 | 1 | 3 | 0 | 0 | 170 |
| L1932 | 6 | 1 | Mine | no | 1 | 2 | 4 | 0 | 1 | 0 | 0 | 161 |
| L1932 | 6 | 1 | Opponent | no | 5 | 3 | 3 | 1 | 0 | 0 | 0 | 477 |
| L2033 | 5 | 1 | Mine | yes | - | 1 | 0 | 6 | 1 | 0 | 0 | 210 |
| L2033 | 5 | 1 | Opponent | yes | - | 3 | 1 | 4 | 0 | 0 | 0 | 424 |
| L2223 | 3 | 1 | Mine | no | 0 | 2 | 7 | 0 | 0 | 0 | 0 | 0 |
| L2223 | 3 | 1 | Opponent | no | 0 | 2 | 4 | 0 | 0 | 0 | 0 | 0 |
| L2327 | 5 | 1 | Mine | yes | - | 2 | 4 | 1 | 0 | 0 | 0 | 185 |
| L2327 | 5 | 1 | Opponent | yes | - | 4 | 1 | 4 | 0 | 0 | 0 | 0 |
| L2433 | 3 | 1 | Mine | no | 1 | 2 | 3 | 2 | 0 | 0 | 0 | 0 |
| L2433 | 3 | 1 | Opponent | no | 1 | 1 | 4 | 2 | 0 | 0 | 0 | 144 |
| L2630 | 2 | 1 | Mine | - | - | 3 | 3 | 3 | 0 | 0 | 0 | 0 |
| L2630 | 2 | 1 | Opponent | - | - | 2 | 1 | 4 | 0 | 0 | 0 | 0 |
| L2832 | 6 | 1 | Mine | no | 1 | 3 | 0 | 0 | 1 | 0 | 0 | 0 |
| L2832 | 6 | 1 | Opponent | no | 3 | 2 | 3 | 3 | 1 | 0 | 0 | 137 |
| L3133 | 1 | 1 | Mine | no | 0 | 3 | 2 | 1 | 4 | 0 | 0 | 340 |
| L3133 | 1 | 1 | Opponent | no | 3 | 3 | 3 | 0 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 28% | 2.9 | 3.1 | 2.1 | 1.1 | 0.4 | 0.0 | 0.0 | 296.6 |
| **Average** | | | Opponent | 22% | 2.9 | 2.9 | 2.2 | 1.9 | 0.4 | 0.0 | 0.0 | 150.1 |

### KPIs: fa-h2h-opp-8a94331-p3

Rules off - Mine only: FIVE ACTION, LIKELY CHARGE, FALLS SHORT, TIME ON OUR SIDE, FEATURE BUFFS, GETS AWAY CHANCE, GUN MASK, RUN DOWN, FOUR ROUNDS, CHARGE LOSSES, CHARACTER GUNS, STAND AND SHOOT, FALL BACK GOOD ORDER, AFTERMATH IN POINTS.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 25% (44 of 179) | 11% (20 of 175) | 18% (64 of 354) |
| Winner chose to follow up after the loser gave ground |  | 90% (46 of 51); on the table 90% | 85% (29 of 34); on the table 88% | 88% (75 of 85); on the table 89% |
| Winner chose to pursue after the loser fell back in good order |  | 83% (5 of 6); on the table 83% | 80% (4 of 5); on the table 80% | 82% (9 of 11); on the table 82% |
| Winner chose to pursue after the loser fled |  | 78% (18 of 23); on the table 83% | 96% (22 of 23); on the table 96% | 87% (40 of 46); on the table 89% |
| Winner chose to follow up or pursue (all three) |  | 86% (69 of 80); on the table 88% | 89% (55 of 62); on the table 90% | 87% (124 of 142); on the table 89% |
| Magic missiles tried each own turn | 50%+ | 39% (135 of 342) | 49% (95 of 192) | 43% (230 of 534) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 55% (135 of 247) | 58% (95 of 163) | 56% (230 of 410) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 57% (13 of 23) | 53% (33 of 62) | 54% (46 of 85) |
| Points that never fought | lower | 43% (29265 of 68801) | 47% (33877 of 71990) | 45% (63142 of 140791) |
|   infantry points that never fought | lower | 53% (7514 of 14174) | 62% (8827 of 14220) | 58% (16341 of 28394) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 57% (155 of 272) | 63% (179 of 285) | 60% (334 of 557) |
| Bound items with a magic missile used (at least once a game) |  | 100% (25 of 25); 2.2 uses a game | 96% (23 of 24); 2.3 uses a game | 98% (48 of 49); 2.2 uses a game |
| Bound items with another spell used |  | 21% (3 of 14); 0.2 uses a game | 17% (1 of 6); 0.0 uses a game | 20% (4 of 20); 0.1 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 60% (12 of 20); 0.3 uses a game | 36% (5 of 14); 0.1 uses a game | 50% (17 of 34); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 53% (31204 of 59391) | 57% (36753 of 64043) | 55% (67957 of 123434) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.2 (21%) | 0.8 (31%) | 2.0 (24%) |
| MARCHED: its unit marched | 1.5 (27%) | 0.9 (32%) | 2.4 (28%) |
| CHARGED: its unit charged | 0.2 (3%) | 0.1 (2%) | 0.2 (3%) |
| IN COMBAT: engaged in combat | 1.5 (26%) | 0.3 (11%) | 1.8 (21%) |
| REAR RANK: in a rear rank | 0.1 (1%) | 0.1 (5%) | 0.2 (3%) |
| FLEEING: fleeing | 0.2 (4%) | 0.0 (1%) | 0.2 (3%) |
| GONE: slain | 0.9 (16%) | 0.3 (12%) | 1.2 (15%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (0%) | 0.1 (5%) | 0.1 (2%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| NOT OFFERED: not in the cast list | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 5.1 | 1.2 | 1.9 | 6.4 | 1.1 | 1.3 |
| not cast | 3.8 | 1.4 | 4.2 | 8.4 | 2.2 | 19.3 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) | 1.1 (6%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (1%) | 0.7 (48%) | 0.2 (6%) | 2.0 (24%) | 0.3 (13%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.4 (28%) | 0.5 (24%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (3%) | 0.1 (3%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.2 (7%) | 0.2 (13%) | 0.9 (22%) | 1.8 (21%) | 0.2 (12%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.1 (4%) | 0.0 (0%) | 0.3 (7%) | 0.2 (3%) | 0.1 (6%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (0%) | 0.1 (8%) | 0.0 (0%) | 0.2 (3%) | 0.0 (0%) | 0.4 (2%) |
| GONE: slain | 0.6 (16%) | 0.1 (10%) | 0.7 (16%) | 1.2 (15%) | 0.2 (9%) | 2.2 (11%) |
| OFF THE TABLE: off the table or not arrived | 0.2 (5%) | 0.0 (2%) | 0.0 (1%) | 0.1 (2%) | 0.1 (5%) | 0.6 (3%) |
| STUPIDITY: Stupidity | 0.1 (3%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.2 (4%) | 0.1 (6%) | 0.0 (0%) | 0.1 (1%) | 0.6 (28%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.3 (60%) | 0.2 (13%) | 2.0 (48%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 15.1 (78%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.3 a game | 0.8 a game | 1.0 a game |
| stood (cast and not dispelled) | 59% (23 of 39) | 64% (14 of 22) | 61% (37 of 61) |
| the unit moved after it | 70% (16 of 23) | 79% (11 of 14) | 73% (27 of 37) |
| it charged on its next turn | 0% (0 of 23) | 0% (0 of 14) | 0% (0 of 37) |
| the enemy charged it first | 9% (2 of 23) | 14% (2 of 14) | 11% (4 of 37) |
| it fought by the end of its next turn | 9% (2 of 23) | 7% (1 of 14) | 8% (3 of 37) |
| it moved out of a charge the enemy had planned (not charged first) | 9% (2 of 23) | 14% (2 of 14) | 11% (4 of 37) |
| none of these (no charge, no fight, no charge escaped) | 83% (19 of 23) | 71% (10 of 14) | 78% (29 of 37) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 69% (565 of 820) | 61% (397 of 648) | 66% (962 of 1468) |
|   cavalry | 66% (45 of 68) | 64% (70 of 110) | 65% (115 of 178) |
|   character | 63% (69 of 110) | 35% (47 of 134) | 48% (116 of 244) |
|   chariot | 61% (66 of 109) | 79% (26 of 33) | 65% (92 of 142) |
|   infantry | 59% (128 of 216) | 69% (185 of 268) | 65% (313 of 484) |
|   monster | 59% (23 of 39) | 0% (0 of 2) | 56% (23 of 41) |
|   war machine | 84% (234 of 278) | 68% (69 of 101) | 80% (303 of 379) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.1 (29%) | 1.5 (22%) | 3.6 (25%) |
| CHARGED: it charged | 0.7 (10%) | 1.3 (19%) | 2.0 (14%) |
| FLEEING: it fled or was fleeing | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| IN COMBAT: it fought this turn or the last | 0.3 (4%) | 0.4 (6%) | 0.7 (5%) |
| MOVED: a war machine that moved | 0.1 (1%) | 0.4 (6%) | 0.5 (4%) |
| NO TARGET IN RANGE | 1.3 (19%) | 1.2 (18%) | 2.6 (18%) |
| ONLY IN COMBAT: the only targets were in combat | 0.5 (7%) | 0.2 (3%) | 0.7 (5%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.5 (22%) | 1.4 (21%) | 3.0 (21%) |
| SHELTERED: the target was sheltered | 0.1 (2%) | 0.1 (2%) | 0.2 (2%) |
| STUPIDITY | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR | 0.3 (5%) | 0.2 (4%) | 0.6 (4%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 5.2 | 1.3 | 82% | 6.0 pts | 31 pts |
| character | 3.9 | 1.2 | 80% | 7.0 pts | 27 pts |
| chariot | 2.6 | 1.4 | 70% | 16.1 pts | 41 pts |
| infantry | 13.2 | 4.8 | 77% | 9.0 pts | 119 pts |
| monster | 0.8 | 0.3 | 78% | 8.7 pts | 6 pts |
| war machine | 8.7 | 6.5 | 65% | 23.6 pts | 205 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.6 | 3.8 | 3.7 |
| Charges that made contact a game | 2.6 | 2.6 | 2.6 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.88 declared, 0.73 contact (26 units) | 0.35 declared, 0.20 contact (20 units) | 0.65 declared, 0.50 contact (46 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.75 declared, 0.50 contact (4 units) | 0.70 declared, 0.70 contact (10 units) | 0.71 declared, 0.64 contact (14 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.46 declared, 0.33 contact (222 units) | 0.45 declared, 0.30 contact (277 units) | 0.45 declared, 0.31 contact (499 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 58% (45 of 77) | 47% (7 of 15) | 60% (6 of 10) | 57% (58 of 102) |
| Character in a unit | 76% (28 of 37) | 71% (12 of 17) | 43% (3 of 7) | 70% (43 of 61) |
| Character on its own | 85% (34 of 40) | 56% (22 of 39) | 40% (27 of 68) | 56% (83 of 147) |
| Chariot | 91% (10 of 11) | 67% (8 of 12) | - | 78% (18 of 23) |
| Infantry | 61% (43 of 70) | 45% (19 of 42) | 20% (1 of 5) | 54% (63 of 117) |
| Monster | 50% (17 of 34) | 86% (6 of 7) | - | 56% (23 of 41) |
| Monstrous | 100% (10 of 10) | 55% (6 of 11) | - | 76% (16 of 21) |
| War Machines | 70% (30 of 43) | 0% (0 of 2) | - | 67% (30 of 45) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 100% (14 of 14); on the table 100% | 53% (51 of 96) | 41% | 64% (14 of 22) | 100% (6 of 6); 5.5 uses a game | 100% (2 of 2); 1.5 uses a game | 83% (5 of 6); 1.2 uses a game |
| Chaos Dwarfs | 4 | 87% (13 of 15); on the table 87% | 39% (14 of 36) | 45% | 62% (20 of 32) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
| Dwarfen Mountain Holds | 3 | 0% (0 of 2); on the table 0% | - | 65% | 62% (15 of 24) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 6 | 67% (4 of 6); on the table 67% | 53% (16 of 30) | 59% | 66% (39 of 59) | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game | 50% (2 of 4); 0.3 uses a game |
| Grand Cathay | 8 | 93% (13 of 14); on the table 100% | 45% (86 of 192) | 55% | 55% (41 of 74) | 94% (17 of 18); 6.8 uses a game | 0% (0 of 4); 0.0 uses a game | 38% (3 of 8); 0.4 uses a game |
| High Elf Realms | 7 | 70% (7 of 10); on the table 80% | 26% (11 of 42) | 36% | 61% (33 of 54) | 100% (9 of 9); 4.4 uses a game | 17% (2 of 12); 0.3 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 3 | 83% (5 of 6); on the table 83% | - | 57% | 61% (11 of 18) | 0.0 uses a game | 0.0 uses a game | 100% (3 of 3); 1.0 uses a game |
| Lizardmen | 1 | 50% (1 of 2); on the table 50% | 67% (4 of 6) | 21% | 43% (3 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 1 | 100% (2 of 2); on the table 100% | 0% (0 of 6) | 26% | 71% (5 of 7) | 100% (1 of 1); 2.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 2 | 100% (5 of 5); on the table 100% | 33% (4 of 12) | 7% | 44% (7 of 16) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.5 uses a game |
| Skaven | 2 | 100% (2 of 2); on the table 100% | 8% (1 of 12) | 54% | 71% (10 of 14) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |
| Tomb Kings of Khemri | 6 | 100% (6 of 6); on the table 100% | 33% (2 of 6) | 41% | 42% (11 of 26) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 8 | 100% (21 of 21); on the table 100% | 50% (27 of 54) | 37% | 54% (25 of 46) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 11 | 87% (27 of 31); on the table 87% | 43% (13 of 30) | 41% | 58% (56 of 96) | 100% (4 of 4); 1.3 uses a game | 0.0 uses a game | 100% (2 of 2); 0.2 uses a game |
| Wood Elf Realms | 6 | 67% (4 of 6); on the table 67% | 8% (1 of 12) | 51% | 71% (44 of 62) | 100% (11 of 11); 6.3 uses a game | 0.0 uses a game | 0% (0 of 5); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (fa-h2h-opp-8a94331-p3, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 42% (26) | 49% (33) | 46% (59) |
| ...free all their last turn and able to turn (per game) | 0.56 | 0.61 | 1.17 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.11 | 0.17 | 0.28 |
| ...with the charger already in that arc before they moved (per game) | 0.42 | 0.31 | 0.72 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 2.25 | 0.08 | 2.33 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.81 | 0.03 | 0.83 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 6.14 | 0.14 | 6.28 |

### Quality by phase: fa-h2h-opp-8a94331-p3

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.2 | 3.6 |
| Strategy | Charge objectives carried out (made contact) | 54% (59 of 109) | 52% (59 of 114) |
| Strategy | Shoot objectives carried out (shot that target) | 42% (180 of 428) | 47% (81 of 174) |
| Strategy | Close-in objectives charged next turn | 10% (19 of 198) | - |
| Strategy | Support requests answered (helper made contact too) | 67% (8 of 12) | 57% (8 of 14) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (3 of 3) | - |
| Strategy | Hexes on a unit its side charged or shot that turn | 33% (3 of 9) | 46% (6 of 13) |
| Strategy | Joined characters whose unit fought | 44% (21 of 48) | 30% (13 of 43) |
| Strategy | Lone characters that fought | 67% (58 of 87) | 64% (58 of 91) |
| Movement | Charges halted short of contact | 0.1 | 0.3 |
| Movement | Idle units | 1.1 | 1.9 |
| Movement | Points that never moved of their own | 296.6 | 150.1 |
| Movement | Fights charged into per game | 2.4 | 2.3 |
| Movement | Charges with odds: long shots (under 50%) | 8 of 77, net +187 | 16 of 68, net +65 |
| Movement | Charges with odds: sweet spot (55-75%) | 13 of 77, net +48 | 10 of 68, net +158 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 14 of 77, net +76 | 3 of 68, net +100 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 20 of 77, net +114 | 17 of 68, net +153 |
| Shooting | Shots by shooting units (incl. breath weapons) | 9.8 | 10.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 43% (151 of 351) | 41% (159 of 384) |
| Shooting | Points destroyed by shooting units | 55.8 | 29.0 |
| Shooting | War machine shots | 6.5 | 2.2 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 50% (116 of 234) | 26% (20 of 78) |
| Shooting | Points destroyed by war machines | 90.8 | 28.0 |
| Magic | Magic missiles cast | 2.4 | 1.8 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 41% (36 of 87) | 34% (22 of 64) |
| Magic | Wounds caused by magic missiles | 4.3 | 3.5 |
| Magic | Wounds caused by other spells | 1.1 | 0.2 |
| Magic | Points destroyed by magic (all spells) | 87.3 | 51.6 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.9 / 0.2 / 0.6 / 0.1 | 2.0 / 0.5 / 0.2 / 0.4 |
| Combat | Points destroyed in combat | 203.4 | 347.3 |
| Combat | Points run down | 40.6 | 98.4 |
| Combat | Net points per charged fight, damage counted | +85 | +113 |
| Combat | Net per 100 charger points, damage counted | +27.3 | +43.3 |
| Combat | First round won (charged fights) | 86% | 76% |
| Combat | Net points per charged fight | +74 | +105 |
| Combat | Net points per supported fight / lone fight | +74 / +74 | +67 / +108 |
| Combat | Charged fights on a top-3 enemy unit | 31 of 87 | 34 of 83 |
| Game | Points lost | 580.5 | 623.6 |
| Game | VP from objectives | 586.9 | 475.6 |
| Game | Lone holders (player turns) | 2.9 | 2.9 |

- Mine won / drew / lost: 15 / 11 / 10 of 36 ended games (of 36); mean margin (Mine - Opponent) +133 VP
- The side that went first won 10 of 25 games with a winner
- Points traded per game (both sides' losses): 1204
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: fa-h2h-opp-8a94331-p3

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.6 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 0.0 |
| ADVANCE WORTH | 5.4 | -153.9 | 147.7 | 116.6 | - | - | - | - |
| AFTERMATH IN POINTS | - | - | - | - | 0.2 | +32.5 | 0.0 | 7.8 |
| ARRIVAL HUNT | 0.0 | +0.1 | 0.0 | 0.0 | 0.1 | +0.7 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.9 | +0.0 | 0.0 | 40.1 | 0.2 | +0.0 | 0.0 | 4.6 |
| BACKUP TARGETS | 0.8 | +4.4 | 0.0 | 31.2 | 0.7 | +5.5 | 0.0 | 0.0 |
| BEST FACING | 0.6 | +31.3 | 0.0 | 3.5 | 0.1 | +0.6 | 0.0 | 3.2 |
| BEST FIRST | 1.6 | +81.0 | 37.2 | 26.9 | - | - | - | - |
| BEST OVERALL | 0.4 | +20.5 | 0.0 | 0.0 | - | - | - | - |
| BEST PREY | 0.4 | +28.5 | 5.6 | 0.0 | - | - | - | - |
| BEST PRIZE | 0.0 | -0.0 | 0.0 | 0.0 | 0.1 | -1.0 | 0.0 | 0.0 |
| BIG CHARACTER SAFETY | 0.3 | -2.1 | 0.0 | 20.7 | - | - | - | - |
| BLOCKED CHARGE SKIPPED | 0.1 | +0.0 | 5.6 | 0.0 | - | - | - | - |
| BLOCKED WHEEL | 0.7 | +16.4 | 0.0 | 0.0 | - | - | - | - |
| BLOWS WHERE AIMED | 0.4 | -59.2 | 38.3 | 10.2 | 0.2 | -37.2 | 42.3 | 0.0 |
| BOMBING RUN | 0.0 | +0.6 | 0.0 | 4.2 | - | - | - | - |
| BOUND ASSAILMENT | 0.0 | +0.0 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| CANNON PLAN MISSED | 0.9 | +0.0 | 77.2 | 6.2 | 0.1 | +0.0 | 12.1 | 0.0 |
| CANNON PLANNED TARGET | 5.4 | +121.1 | 391.1 | 97.4 | 1.3 | +78.8 | 75.9 | 20.0 |
| CANNON SIGHT KEPT | 1.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT SET-UP | 0.1 | -0.2 | 12.5 | 0.0 | 0.0 | +0.0 | 2.2 | 0.0 |
| CAST JOB | 0.9 | +24.1 | 38.5 | 11.4 | 0.8 | +26.1 | 16.6 | 20.5 |
| CASTER AWAY FROM SCREEN | 0.2 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.6 | +52.4 | 12.4 | 4.8 | - | - | - | - |
| CASTS AFTER FRIENDS | 0.5 | +0.0 | 0.0 | 10.6 | 0.5 | +0.0 | 0.0 | 11.1 |
| CASTS FROM BEHIND | 0.0 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.0 | +0.4 | 0.0 | 0.0 | - | - | - | - |
| CATCH ODDS | 0.0 | +1.6 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | 1.2 | +61.3 | 0.0 | 26.6 | 0.6 | +19.6 | 0.0 | 10.2 |
| CHAFF PASSED | 0.4 | -1.3 | 0.0 | 4.9 | 0.2 | -0.4 | 0.0 | 3.7 |
| CHARACTER GUNS | - | - | - | - | 1.1 | +0.0 | 0.0 | 6.2 |
| CHARGE LOSSES | - | - | - | - | 11.6 | -383.0 | 0.0 | 253.2 |
| CHARGE NOW FIRST | 2.0 | +0.0 | 225.2 | 45.4 | 1.2 | +0.0 | 134.9 | 28.3 |
| CHARGE NOW WEIGHED | 0.8 | -67.9 | 19.9 | 22.1 | - | - | - | - |
| CHARGER SLAIN LOST | 0.3 | -9.3 | 26.9 | 9.9 | 0.4 | -5.6 | 36.6 | 13.7 |
| CHARIOT WIZARD CAREFUL | 0.0 | -3.7 | 0.0 | 11.0 | - | - | - | - |
| CHEAP HELPER | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| COMBAT PIVOT | 0.5 | +0.0 | 33.5 | 49.5 | 0.3 | +0.0 | 8.0 | 16.4 |
| CONTINUE AHEAD WEIGHED | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CONVEYANCE SEARCH | 0.8 | +115.3 | 31.7 | 41.0 | 0.4 | +22.7 | 11.1 | 11.1 |
| COVER ONCE | 9.0 | -576.1 | 0.0 | 155.0 | 5.6 | -432.4 | 0.0 | 82.1 |
| DEFENSIVE ARMY | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 5.8 |
| DEFENSIVE FLOOR | - | - | - | - | 0.0 | +1.4 | 0.0 | 1.8 |
| EDGE GIVE GROUND | 0.3 | +24.4 | 66.4 | 0.0 | 0.1 | +0.7 | 6.9 | 0.0 |
| ELIXIR WORTH | 0.1 | +1.9 | 0.0 | 17.9 | - | - | - | - |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 2.2 | +172.1 | 0.0 | 26.4 | 0.1 | +1.1 | 0.0 | 3.2 |
| FALL BACK GOOD ORDER | - | - | - | - | 2.2 | +5.3 | 154.8 | 50.0 |
| FALLBACK BY WORTH | 4.9 | +46.7 | 0.0 | 41.6 | 0.2 | +0.4 | 0.0 | 0.5 |
| FALLS SHORT | - | - | - | - | 0.3 | -1.3 | 0.0 | 14.2 |
| FEATURE BUFFS | - | - | - | - | 0.6 | +13.0 | 0.0 | 8.2 |
| FIGHT LIFT | 0.1 | +0.9 | 0.0 | 0.0 | 0.0 | +0.3 | 0.0 | 0.0 |
| FIRE AND FLEE | 0.0 | +0.4 | 2.9 | 2.2 | - | - | - | - |
| FIVE ACTION | - | - | - | - | 44.5 | +2285.5 | 467.0 | 663.9 |
| FLANK NOT WEIGHED | 5.9 | +0.0 | 0.0 | 101.9 | 5.8 | +0.0 | 0.0 | 167.4 |
| FOLLOW UP WEIGHED | 0.8 | +121.6 | 0.0 | 38.1 | 0.9 | +157.3 | 0.0 | 13.8 |
| FOUR ROUNDS | - | - | - | - | 2.9 | +213.4 | 240.9 | 88.0 |
| FRIENDS SHOTS CHECKED | 0.2 | +10.7 | 0.0 | 0.9 | 0.1 | +3.8 | 0.0 | 0.0 |
| GIVES UP | 0.1 | -2.3 | 12.8 | 0.0 | 0.1 | -1.9 | 14.1 | 0.0 |
| GROUND FLIERS | 0.0 | +0.9 | 0.0 | 0.0 | - | - | - | - |
| GUN MASK | - | - | - | - | 0.4 | +13.0 | 0.0 | 4.6 |
| HELPER UNSEEN | 0.2 | +0.0 | 18.6 | 7.1 | 0.2 | +0.0 | 24.7 | 12.1 |
| HILL BY ITS CHANCE | 0.2 | -20.0 | 0.0 | 0.0 | - | - | - | - |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 8.8 | -154.4 | 427.7 | 156.3 | 2.4 | -96.8 | 192.9 | 66.1 |
| HORN WORTH | - | - | - | - | 0.1 | +0.8 | 0.0 | 0.0 |
| HUNT ADVANCE | 0.2 | +10.4 | 9.2 | 3.8 | - | - | - | - |
| HUNT DROPPED | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HUNT IN PAIRS | 0.5 | +17.8 | 0.0 | 0.0 | 1.0 | +64.7 | 0.0 | 33.1 |
| HUNT KEPT | 0.2 | +6.0 | 13.8 | 0.0 | - | - | - | - |
| HUNT RESULT | 0.2 | +9.3 | 9.2 | 3.9 | 0.1 | +35.5 | 13.9 | 1.7 |
| HUNT THE GUNS | 0.2 | +73.0 | 9.2 | 6.3 | 0.1 | +40.9 | 25.6 | 0.0 |
| IDLE COST | 15.9 | -271.7 | 0.0 | 184.1 | 20.9 | -351.7 | 0.0 | 210.5 |
| INVITES THE FIGHT | 1.3 | +8.5 | 58.9 | 39.3 | - | - | - | - |
| JOINT CHARGE PLAN | 0.1 | +0.5 | 0.0 | 0.0 | - | - | - | - |
| JOINT KNOWS CHALLENGE | 0.0 | -0.3 | 0.0 | 0.0 | 0.1 | -2.0 | 0.0 | 0.0 |
| KEEP FALLS | 0.2 | +3.4 | 0.0 | 0.0 | 0.0 | +0.1 | 0.0 | 0.0 |
| KEEPS ITS PREY | 0.1 | +0.5 | 2.0 | 4.0 | - | - | - | - |
| KEEPS ITS TARGET | 1.8 | +53.3 | 172.3 | 48.2 | - | - | - | - |
| KEEPS SCOUTS OR AMBUSH | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KILLS COUNT | 1.3 | +51.8 | 99.9 | 30.4 | 1.6 | +85.1 | 115.3 | 43.1 |
| KILLS COUNT NEXT TURN | 5.2 | +169.1 | 174.8 | 97.9 | - | - | - | - |
| LONE CHARACTER SAFE SPOT | 0.4 | +30.1 | 13.9 | 17.1 | 0.1 | +4.8 | 0.0 | 3.2 |
| LONE WIZARD HOLDS BACK | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| LONE WIZARD KEPT IN | 0.6 | +37.3 | 0.0 | 0.0 | 0.4 | +25.4 | 0.0 | 0.0 |
| LONG SHOT | 0.2 | +4.1 | 9.1 | 10.2 | 0.2 | -1.8 | 25.9 | 1.5 |
| LOST CHARGE | 2.9 | -46.5 | 139.7 | 50.7 | 0.2 | -0.3 | 13.9 | 6.4 |
| LURE BY WHAT IT DRAWS | 0.0 | -3.9 | 0.0 | 4.2 | 0.1 | -3.8 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 1.1 | +160.6 | 18.5 | 23.8 | 0.3 | +9.5 | 0.0 | 3.2 |
| MANOEUVRE | 0.3 | +12.0 | 0.0 | 5.4 | 0.6 | +14.0 | 0.0 | 12.6 |
| MARCH AT ESCAPER | 0.2 | +2.0 | 0.0 | 7.2 | 0.1 | +0.4 | 0.0 | 0.0 |
| MARCH CHECK | 0.5 | +19.3 | 0.0 | 2.2 | 1.0 | +91.4 | 0.0 | 8.8 |
| MARCH ODDS | 0.4 | +24.3 | 5.4 | 5.4 | - | - | - | - |
| MARCH OVER CASTS | 0.6 | +34.4 | 0.0 | 15.0 | 0.6 | +60.7 | 0.0 | 26.4 |
| MAX FOR POSITIONING | 7.2 | +111.6 | 0.0 | 126.0 | 8.8 | +141.1 | 0.0 | 209.9 |
| MISSILES IN THE MOVE | 4.8 | +171.4 | 0.0 | 83.1 | 5.0 | +82.2 | 0.0 | 99.1 |
| MISSILES NEXT TURN | 5.8 | +91.4 | 0.0 | 109.3 | 5.5 | +50.8 | 0.0 | 126.4 |
| MODEL FACING | 0.1 | +42.4 | 0.0 | 3.3 | - | - | - | - |
| MONSTER WIZARD ROAMS | 0.2 | +0.0 | 0.0 | 21.1 | - | - | - | - |
| MOVE AND CAST | 0.6 | +21.4 | 0.0 | 5.0 | - | - | - | - |
| MOVE SPELL IN RANGE | 0.2 | +9.1 | 0.0 | 31.7 | 0.0 | +0.7 | 0.0 | 0.0 |
| MOVE SPELL NOT WORTH | 0.1 | -0.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.7 | -27.4 | 28.4 | 33.1 | 0.1 | -3.1 | 0.0 | 6.5 |
| MOVE SPELL SPOT | 0.4 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 11.1 |
| MOVE TO CHARGE | 4.1 | +387.9 | 127.1 | 77.0 | - | - | - | - |
| MOVES UNITS SPELL | 0.1 | +3.6 | 0.0 | 0.0 | 0.1 | +0.3 | 0.0 | 0.0 |
| NEEDED THERE | 0.0 | +9.7 | 0.0 | 0.0 | 0.1 | +14.4 | 6.6 | 0.0 |
| NO RALLY LEFT | 0.1 | +1.4 | 0.0 | 0.0 | - | - | - | - |
| NOT NEEDED | 0.1 | -3.2 | 10.9 | 0.0 | - | - | - | - |
| NOT TURNED | 6.1 | +72.9 | 0.0 | 104.8 | 0.1 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 0.6 | -0.4 | 0.0 | 21.1 | 0.9 | -4.1 | 0.0 | 6.5 |
| OFF BEST | 16.9 | -743.4 | 0.0 | 220.9 | 1.5 | -27.7 | 0.0 | 23.1 |
| ONE FIGHT FORMULA | 10.0 | -167.0 | 53.7 | 202.2 | 8.6 | -213.9 | 0.0 | 222.7 |
| ONE OBJECTIVE FORMULA | 2.8 | -114.3 | 0.0 | 12.3 | 1.8 | -46.1 | 0.0 | 23.4 |
| OPENS A LANE | 0.1 | +1.2 | 12.0 | 6.5 | 0.2 | +0.5 | 0.0 | 37.4 |
| OPENS UP | 0.2 | +24.5 | 13.0 | 0.0 | 0.1 | +4.1 | 4.9 | 0.0 |
| OVERRUNS AWAY | 0.5 | +10.6 | 62.8 | 5.7 | 0.4 | +3.0 | 42.6 | 5.0 |
| PATHS CROSS | 2.0 | +140.9 | 0.0 | 24.7 | 2.8 | +219.7 | 0.0 | 36.5 |
| PIVOT GUARDS FLANK | 0.1 | -2.2 | 0.0 | 0.0 | 0.1 | -3.0 | 0.0 | 0.0 |
| PLAN RESULT | 38.9 | +1297.9 | 1310.8 | 765.2 | 39.9 | +489.9 | 281.7 | 969.9 |
| PURSUES BIG PREY | 0.1 | -1.5 | 0.0 | 0.0 | - | - | - | - |
| RAIDS THE BAGGAGE | 0.1 | +8.3 | 0.0 | 0.0 | - | - | - | - |
| RAIDS THE BAGGAGE NEXT TURN | 0.1 | +5.5 | 0.0 | 0.0 | - | - | - | - |
| RANDOM MOVE BY FIGURES | 0.6 | +6.2 | 0.0 | 24.7 | 1.7 | +22.6 | 0.0 | 48.3 |
| RANDOM MOVER NO PROMISE | 0.1 | -7.0 | 0.0 | 0.0 | - | - | - | - |
| REDIRECT BY WHAT IT STOPS | 1.1 | -29.6 | 0.0 | 20.8 | 0.2 | +0.2 | 0.0 | 0.0 |
| REDIRECT COUNTER | 2.1 | +150.0 | 0.0 | 26.0 | 3.9 | +293.3 | 0.0 | 73.2 |
| REDIRECT WEIGHED | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +5.7 | 3.5 | 0.0 |
| REFUSING RETIRES | 0.4 | +0.0 | 0.0 | 10.5 | 0.2 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | 0.6 | +18.2 | 0.0 | 15.1 | 1.2 | +34.3 | 0.0 | 16.9 |
| RESTRAINS TO SHOOT | 0.1 | +10.6 | 0.0 | 0.0 | 0.0 | +1.4 | 0.0 | 0.0 |
| RISK BY ARC | 1.9 | +62.3 | 158.5 | 54.1 | 1.8 | +25.9 | 176.2 | 27.3 |
| RISK ONCE | 4.2 | +118.0 | 37.1 | 164.5 | - | - | - | - |
| RUN DOWN | - | - | - | - | 2.1 | -28.2 | 160.9 | 46.1 |
| SAFE SURE CHARGE | 0.1 | -3.5 | 9.1 | 0.0 | - | - | - | - |
| SAFER THAN THE JOB | 0.8 | +42.3 | 0.0 | 19.3 | 0.0 | +5.0 | 0.0 | 0.0 |
| SCOUT SPOT | 0.4 | +0.6 | 0.0 | 0.9 | 0.3 | +0.9 | 0.0 | 0.0 |
| SCOUT WAITS | 0.4 | +0.0 | 0.0 | 0.9 | 0.3 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.2 | -10.3 | 0.0 | 0.0 | 0.2 | -7.0 | 0.0 | 2.3 |
| SEARCH SPOT | 2.5 | +114.1 | 0.0 | 10.3 | 4.5 | +129.5 | 0.0 | 122.7 |
| SELF MOVE SPELL | 0.4 | +54.7 | 0.0 | 11.0 | 0.2 | +49.6 | 0.0 | 0.0 |
| SET UP TOGETHER | 1.5 | +186.9 | 26.4 | 48.2 | 0.6 | +14.8 | 0.0 | 10.2 |
| SET-UP ANY TARGET | 0.6 | +113.2 | 21.1 | 30.4 | 0.1 | +9.4 | 11.1 | 11.1 |
| SET-UP MISSED | 0.1 | +15.6 | 0.0 | 0.0 | - | - | - | - |
| SHOOTER COUNTED ONCE | 0.1 | -1.2 | 0.0 | 0.0 | 0.1 | -0.5 | 0.0 | 0.5 |
| SHOOTERS IN TWO RANKS | 0.4 | +0.7 | 0.0 | 0.0 | 0.1 | +0.3 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.5 | +70.0 | 94.3 | 23.2 | 0.5 | +13.6 | 19.4 | 14.2 |
| SHORT GUN FORWARD | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SHOT REPLANNED | 0.8 | +0.0 | 106.1 | 0.0 | 0.3 | +0.0 | 30.3 | 1.5 |
| SHOTS IN THE MOVE | 15.1 | +553.5 | 0.0 | 212.3 | 11.8 | +390.8 | 0.0 | 149.3 |
| SPELL SETS UP CHARGE | 0.8 | +147.8 | 31.7 | 41.0 | 0.1 | +9.4 | 11.1 | 11.1 |
| SPELL WORTH | 1.5 | +22.7 | 0.0 | 9.8 | 2.3 | +27.4 | 38.2 | 34.0 |
| SPELLS IN THE FIGHT | 0.5 | -0.1 | 52.1 | 27.9 | 0.4 | -8.1 | 51.2 | 4.6 |
| STABLE ROLE | 11.0 | +0.0 | 382.5 | 107.7 | - | - | - | - |
| STAND AND SHOOT | - | - | - | - | 0.5 | -4.1 | 24.5 | 5.2 |
| STANDS TO CAST | 0.1 | +3.9 | 0.0 | 0.0 | - | - | - | - |
| STAY WEIGHED | 0.1 | +2.4 | 0.0 | 0.0 | - | - | - | - |
| STOPS | 0.1 | +4.9 | 9.2 | 2.5 | 0.1 | +7.9 | 25.6 | 0.0 |
| STOPS SHORT OF THE FLANK | 0.6 | +26.8 | 0.0 | 14.4 | - | - | - | - |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| SUPPORT NARROWED | 6.2 | -63.9 | 366.9 | 55.1 | 1.1 | +0.0 | 104.4 | 34.5 |
| SUPPORTS | 4.8 | +71.4 | 202.4 | 46.5 | - | - | - | - |
| SURE REACH TOGETHER | 0.5 | +2.6 | 7.9 | 20.1 | 0.3 | +3.4 | 0.0 | 13.1 |
| THROUGH LINE OF FIRE | 0.4 | +16.4 | 0.0 | 14.4 | - | - | - | - |
| TIME ON OUR SIDE | - | - | - | - | 1.6 | +0.0 | 5.8 | 2.9 |
| TURN WORTH | 0.3 | -19.7 | 23.5 | 5.7 | 0.1 | -1.9 | 6.2 | 1.7 |
| TWO OR MORE ARRIVE | 0.4 | +3.0 | 7.9 | 5.7 | 0.1 | +0.2 | 0.0 | 3.2 |
| WAIT AFTER COSTS | 7.9 | -374.0 | 237.6 | 171.7 | - | - | - | - |
| WALKS TO THE FIGHT | 1.9 | +15.8 | 42.2 | 28.2 | - | - | - | - |
| WAR ENGINE CHARGES | 0.0 | +4.1 | 0.0 | 0.0 | - | - | - | - |
| WAR ENGINE JOBS | 0.8 | +0.0 | 70.8 | 29.6 | 0.1 | +0.0 | 0.0 | 0.0 |
| WEARS DOWN | 0.9 | +27.3 | 125.4 | 25.9 | 0.8 | +34.9 | 63.8 | 37.7 |
| WHO HITS BACK | 0.2 | +19.2 | 0.0 | 25.9 | 0.2 | +22.6 | 0.0 | 16.1 |
| WHOLE FIGHT | 0.2 | +10.4 | 32.4 | 5.7 | 0.2 | +24.2 | 37.7 | 1.8 |
| WHOLE FIGHT GAIN | 0.2 | +17.0 | 22.4 | 5.7 | 0.3 | +17.5 | 23.2 | 5.3 |
| WIDER SPREAD | 2.1 | -7.2 | 216.0 | 18.4 | 2.2 | -4.9 | 201.5 | 64.0 |

### Rule changes: fa-h2h-opp-8a94331-p3

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 663 | 663 | 663 | 18.42 | -27761 | -41.9 |
| SEARCH SPOT | 251 | 251 | 242 | 6.72 | +8778 | +36.3 |
| PATHS CROSS | 174 | 174 | 174 | 4.83 | +12982 | +74.6 |
| MAX FOR POSITIONING | 576 | 466 | 102 | 2.83 | +386 | +3.8 |
| SHOTS IN THE MOVE | 970 | 708 | 102 | 2.83 | +2922 | +28.6 |
| MOVE TO CHARGE | 148 | 148 | 95 | 2.64 | +6543 | +68.9 |
| COVER ONCE | 527 | 293 | 92 | 2.56 | +1491 | +16.2 |
| FACES THE THREAT | 84 | 84 | 84 | 2.33 | +6234 | +74.2 |
| SUPPORTS | 171 | 171 | 84 | 2.33 | +1002 | +11.9 |
| IDLE COST | 1326 | 707 | 81 | 2.25 | +734 | +9.1 |
| REDIRECT COUNTER | 215 | 153 | 78 | 2.17 | +7604 | +97.5 |
| ARTILLERY RE-ROLL WEIGHED | 75 | 75 | 75 | 2.08 | +0 | +0.0 |
| MISSILES IN THE MOVE | 353 | 220 | 69 | 1.92 | +1216 | +17.6 |
| RESERVE FALL BACK | 62 | 62 | 62 | 1.72 | +1890 | +30.5 |
| FOLLOW UP WEIGHED | 61 | 61 | 61 | 1.69 | +10042 | +164.6 |
| KILLS COUNT NEXT TURN | 188 | 188 | 60 | 1.67 | +1092 | +18.2 |
| BEST FIRST | 59 | 59 | 59 | 1.64 | +2917 | +49.4 |
| CHARGE LOSSES | 419 | 419 | 58 | 1.61 | +4374 | +75.4 |
| CANNON SIGHT KEPT | 56 | 56 | 56 | 1.56 | +0 | +0.0 |
| MARCH CHECK | 54 | 54 | 51 | 1.42 | +1682 | +33.0 |
| WAIT AFTER COSTS | 285 | 285 | 51 | 1.42 | +1041 | +20.4 |
| CAST JOB | 64 | 64 | 46 | 1.28 | +448 | +9.7 |
| ONE FIGHT FORMULA | 668 | 345 | 46 | 1.28 | +310 | +6.7 |
| RANDOM MOVE BY FIGURES | 85 | 85 | 46 | 1.28 | +1037 | +22.5 |
| ADVANCE WORTH | 196 | 196 | 43 | 1.19 | +547 | +12.7 |
| HOLDS AMBUSHERS | 39 | 39 | 39 | 1.08 | +0 | +0.0 |
| SHOOTS FROM THE BEST SPOT | 72 | 72 | 39 | 1.08 | +656 | +16.8 |
| SHOT REPLANNED | 39 | 39 | 39 | 1.08 | +0 | +0.0 |
| ADVANCE LANE KEPT | 35 | 35 | 35 | 0.97 | +0 | +0.0 |
| FALLBACK BY WORTH | 182 | 182 | 35 | 0.97 | +1695 | +48.4 |
| RISK BY ARC | 132 | 130 | 35 | 0.97 | +907 | +25.9 |
| FOUR ROUNDS | 106 | 106 | 34 | 0.94 | +2325 | +68.4 |
| CHAFF IN THE MOVE | 63 | 57 | 33 | 0.92 | +768 | +23.3 |
| KILLS COUNT | 104 | 104 | 33 | 0.92 | +987 | +29.9 |
| LONE WIZARD KEPT IN | 33 | 33 | 33 | 0.92 | +2259 | +68.5 |
| SET UP TOGETHER | 76 | 63 | 33 | 0.92 | +2443 | +74.0 |
| COMBAT PIVOT | 30 | 30 | 30 | 0.83 | +0 | +0.0 |
| SAFER THAN THE JOB | 30 | 30 | 30 | 0.83 | +1705 | +56.8 |
| CANNON PLANNED TARGET | 241 | 241 | 29 | 0.81 | -322 | -11.1 |
| CHARGE NOW WEIGHED | 27 | 27 | 27 | 0.75 | +2497 | +92.5 |
| WALKS TO THE FIGHT | 67 | 67 | 27 | 0.75 | +171 | +6.3 |
| CHARGE NOW FIRST | 115 | 115 | 26 | 0.72 | -914 | -35.1 |
| BLOCKED WHEEL | 25 | 25 | 25 | 0.69 | +589 | +23.6 |
| SCOUT WAITS | 25 | 25 | 25 | 0.69 | +0 | +0.0 |
| BEST FACING | 24 | 24 | 24 | 0.67 | +1146 | +47.8 |
| CHAFF PASSED | 24 | 24 | 24 | 0.67 | -58 | -2.4 |
| FIVE ACTION | 1602 | 1602 | 22 | 0.61 | +685 | +31.1 |
| MOVE AND CAST | 21 | 21 | 21 | 0.58 | +770 | +36.7 |
| STOPS SHORT OF THE FLANK | 21 | 21 | 21 | 0.58 | +966 | +46.0 |
| HONEST WORTH | 402 | 400 | 20 | 0.56 | +173 | +8.7 |
| RISK ONCE | 152 | 108 | 20 | 0.56 | +878 | +43.9 |
| SHOOTERS IN TWO RANKS | 18 | 18 | 18 | 0.50 | +36 | +2.0 |
| HUNT IN PAIRS | 53 | 32 | 17 | 0.47 | +963 | +56.7 |
| MANOEUVRE | 33 | 33 | 17 | 0.47 | +938 | +55.2 |
| WAR ENGINE JOBS | 30 | 30 | 17 | 0.47 | -734 | -43.2 |
| WHO HITS BACK | 17 | 17 | 17 | 0.47 | +1083 | +63.7 |
| INVITES THE FIGHT | 47 | 47 | 16 | 0.44 | +96 | +6.0 |
| THROUGH LINE OF FIRE | 16 | 16 | 16 | 0.44 | +591 | +37.0 |
| CASTING BLOCK | 20 | 20 | 14 | 0.39 | +592 | +42.3 |
| MAKE SURE TOGETHER | 51 | 29 | 14 | 0.39 | +1365 | +97.5 |
| MISSILES NEXT TURN | 407 | 241 | 14 | 0.39 | +12 | +0.9 |
| BEST OVERALL | 13 | 13 | 13 | 0.36 | +739 | +56.8 |
| KEEPS ITS TARGET | 64 | 63 | 13 | 0.36 | +241 | +18.6 |
| MARCH ODDS | 13 | 13 | 13 | 0.36 | +246 | +19.0 |
| REDIRECT WEIGHED | 13 | 13 | 13 | 0.36 | +578 | +44.5 |
| WEARS DOWN | 59 | 58 | 12 | 0.33 | +346 | +28.8 |
| BIG CHARACTER SAFETY | 11 | 11 | 11 | 0.31 | -75 | -6.8 |
| ONE OBJECTIVE FORMULA | 166 | 99 | 11 | 0.31 | +348 | +31.6 |
| WHOLE FIGHT GAIN | 17 | 16 | 11 | 0.31 | +273 | +24.9 |
| FRIENDS SHOTS CHECKED | 10 | 10 | 10 | 0.28 | +520 | +52.0 |
| BEST PREY | 13 | 13 | 9 | 0.25 | +269 | +29.9 |
| CASTER AWAY FROM SCREEN | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| CASTS FROM BEHIND | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| OPENS UP | 11 | 11 | 9 | 0.25 | +367 | +40.7 |
| FEATURE BUFFS | 20 | 20 | 8 | 0.22 | +163 | +20.4 |
| LOST CHARGE | 112 | 111 | 8 | 0.22 | +197 | +24.6 |
| SURE REACH TOGETHER | 28 | 23 | 8 | 0.22 | +59 | +7.4 |
| KEEP FALLS | 7 | 7 | 7 | 0.19 | +287 | +40.9 |
| MOVES UNITS SPELL | 7 | 7 | 7 | 0.19 | +141 | +20.1 |
| PIVOT GUARDS FLANK | 7 | 7 | 7 | 0.19 | -188 | -26.8 |
| STUCK PIVOT | 7 | 7 | 7 | 0.19 | +0 | +0.0 |
| WIDER SPREAD | 155 | 153 | 7 | 0.19 | +15 | +2.1 |
| AFTERMATH IN POINTS | 6 | 6 | 6 | 0.17 | +1168 | +194.7 |
| REFUSING RETIRES | 23 | 23 | 6 | 0.17 | -2 | -0.3 |
| RESTRAINS TO SHOOT | 6 | 6 | 6 | 0.17 | +433 | +72.2 |
| EDGE GIVE GROUND | 15 | 15 | 5 | 0.14 | +339 | +67.9 |
| SHORT GUN FORWARD | 5 | 5 | 5 | 0.14 | +0 | +0.0 |
| SUPPORT NARROWED | 262 | 262 | 5 | 0.14 | -46 | -9.2 |
| WHOLE FIGHT | 14 | 14 | 5 | 0.14 | +379 | +75.8 |
| BEST PRIZE | 4 | 4 | 4 | 0.11 | -36 | -9.0 |
| HUNT ADVANCE | 8 | 8 | 4 | 0.11 | +167 | +41.7 |
| BLOCKED CHARGE SKIPPED | 3 | 3 | 3 | 0.08 | +0 | +0.0 |
| HORN WORTH | 3 | 3 | 3 | 0.08 | +29 | +9.6 |
| MODEL FACING | 3 | 3 | 3 | 0.08 | +1528 | +509.3 |
| NEEDED THERE | 3 | 3 | 3 | 0.08 | +0 | +0.0 |
| OVERRUNS AWAY | 31 | 31 | 3 | 0.08 | +39 | +13.0 |
| RAIDS THE BAGGAGE NEXT TURN | 3 | 3 | 3 | 0.08 | +24 | +8.0 |
| SAFE SURE CHARGE | 3 | 3 | 3 | 0.08 | -138 | -46.0 |
| SPELLS IN THE FIGHT | 30 | 29 | 3 | 0.08 | +44 | +14.8 |
| STOPS | 8 | 8 | 3 | 0.08 | +80 | +26.8 |
| BACKUP TARGETS | 52 | 28 | 2 | 0.06 | +37 | +18.5 |
| BOUND ASSAILMENT | 2 | 2 | 2 | 0.06 | +0 | +0.1 |
| ELIXIR WORTH | 2 | 2 | 2 | 0.06 | +67 | +33.5 |
| GUN MASK | 15 | 15 | 2 | 0.06 | +139 | +69.5 |
| LONG SHOT | 14 | 13 | 2 | 0.06 | +54 | +26.8 |
| MOVE SPELL IN RANGE | 10 | 6 | 2 | 0.06 | +48 | +23.9 |
| NO RALLY LEFT | 2 | 2 | 2 | 0.06 | +61 | +30.6 |
| OPENS A LANE | 13 | 8 | 2 | 0.06 | +15 | +7.7 |
| PURSUES BIG PREY | 2 | 2 | 2 | 0.06 | -53 | -26.6 |
| RAIDS THE BAGGAGE | 2 | 2 | 2 | 0.06 | +216 | +108.1 |
| REDIRECT BY WHAT IT STOPS | 46 | 46 | 2 | 0.06 | +77 | +38.4 |
| STANDS TO CAST | 2 | 2 | 2 | 0.06 | +34 | +16.8 |
| STAY WEIGHED | 2 | 2 | 2 | 0.06 | +86 | +43.0 |
| BLOWS WHERE AIMED | 20 | 19 | 1 | 0.03 | +0 | +0.0 |
| BOMBING RUN | 1 | 1 | 1 | 0.03 | +21 | +21.3 |
| CARRIES OUT SET-UP | 4 | 4 | 1 | 0.03 | -9 | -8.8 |
| CATCH ODDS | 1 | 1 | 1 | 0.03 | -25 | -24.9 |
| CHARGER SLAIN LOST | 26 | 25 | 1 | 0.03 | +246 | +246.3 |
| CONTINUE AHEAD WEIGHED | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| DEFENSIVE FLOOR | 1 | 1 | 1 | 0.03 | +27 | +26.8 |
| FIRE AND FLEE | 1 | 1 | 1 | 0.03 | +15 | +15.1 |
| KEEPS ITS PREY | 4 | 4 | 1 | 0.03 | +6 | +6.5 |
| KEEPS SCOUTS OR AMBUSH | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| LONE WIZARD HOLDS BACK | 1 | 1 | 1 | 0.03 | -125 | -125.1 |
| ARRIVAL HUNT | 3 | 3 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 35 | 35 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 37 | trace | - | - | - | - |
| CATCH FLIERS | 1 | not checked | - | - | - | - |
| CHARACTER GUNS | 41 | 41 | 0 | 0.00 | - | - |
| CHARIOT WIZARD CAREFUL | 1 | 1 | 0 | 0.00 | - | - |
| CHEAP HELPER | 4 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 46 | not checked | - | - | - | - |
| DEFENSIVE ARMY | 7 | 7 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 79 | 79 | 0 | 0.00 | - | - |
| FALLS SHORT | 12 | 12 | 0 | 0.00 | - | - |
| FIGHT LIFT | 3 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 418 | not checked | - | - | - | - |
| GIVES UP | 7 | 6 | 0 | 0.00 | - | - |
| GROUND FLIERS | 1 | not checked | - | - | - | - |
| HELPER UNSEEN | 17 | 16 | 0 | 0.00 | - | - |
| HILL BY ITS CHANCE | 9 | 9 | 0 | 0.00 | - | - |
| HUNT DROPPED | 1 | trace | - | - | - | - |
| HUNT KEPT | 7 | trace | - | - | - | - |
| HUNT RESULT | 10 | trace | - | - | - | - |
| HUNT THE GUNS | 12 | trace | - | - | - | - |
| JOINT CHARGE PLAN | 2 | 2 | 0 | 0.00 | - | - |
| JOINT KNOWS CHALLENGE | 3 | 3 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 17 | not checked | - | - | - | - |
| LURE BY WHAT IT DRAWS | 3 | 3 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 9 | trace | - | - | - | - |
| MARCH OVER CASTS | 45 | 45 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 6 | 6 | 0 | 0.00 | - | - |
| MOVE SPELL NOT WORTH | 3 | not checked | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 30 | trace | - | - | - | - |
| MOVE SPELL SPOT | 19 | not checked | - | - | - | - |
| NOT NEEDED | 4 | 4 | 0 | 0.00 | - | - |
| NOT TURNED | 226 | 226 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 52 | not checked | - | - | - | - |
| PLAN RESULT | 2838 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 2 | 2 | 0 | 0.00 | - | - |
| RUN DOWN | 77 | 77 | 0 | 0.00 | - | - |
| SCOUT SPOT | 24 | 24 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 14 | 14 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 19 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 27 | not checked | - | - | - | - |
| SET-UP MISSED | 3 | trace | - | - | - | - |
| SHOOTER COUNTED ONCE | 4 | 4 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 31 | not checked | - | - | - | - |
| SPELL WORTH | 137 | not checked | - | - | - | - |
| STABLE ROLE | 397 | 397 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 19 | 19 | 0 | 0.00 | - | - |
| TIME ON OUR SIDE | 56 | 56 | 0 | 0.00 | - | - |
| TURN WORTH | 13 | 13 | 0 | 0.00 | - | - |
| TWO OR MORE ARRIVE | 17 | 12 | 0 | 0.00 | - | - |
| WAR ENGINE CHARGES | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: fa-h2h-opp-8a94331-p3

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 15.44 | 1.03 | 42.1 |
| CHARGE NOW FIRST | rule | 0.58 | 0.11 | 36.5 |
| FALLBACK | gate | 0.67 | - | 41.1 |
| TURN GATE | gate | 0.50 | - | 55.1 |
| WAR ENGINE JOBS | rule | 0.47 | - | 43.2 |
| CHAFF PASSED | rule | 0.17 | 0.14 | 5.2 |
| NO REASON | gate | - | 0.28 | 24.3 |
| BIG CHARACTER SAFETY | rule | 0.22 | - | 11.4 |
| PIVOT GUARDS FLANK | rule | 0.11 | 0.08 | 26.8 |
| AFTERMATH BAND | gate | 0.06 | 0.11 | 2.3 |
| CANNON PLANNED TARGET | rule | 0.14 | 0.03 | 53.6 |
| PATHS CROSS | rule | 0.06 | 0.08 | 18.5 |
| SUPPORT NARROWED | rule | 0.06 | 0.08 | 9.2 |
| BEST PRIZE | rule | 0.03 | 0.08 | 9.0 |
| FIGHT ORDER BAND | gate | 0.08 | 0.03 | 1.4 |
| STOPS SHORT OF THE FLANK | rule | 0.11 | - | 7.6 |
| FACES THE THREAT | rule | 0.08 | - | 15.2 |
| SAFE SURE CHARGE | rule | 0.08 | - | 46.0 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.03 | 0.03 | 48.2 |
| CHARGE NOW WEIGHED | rule | 0.06 | - | 10.8 |
| LONE CHARACTER SAFE SPOT | gate | 0.06 | - | 52.6 |
| MARCH ODDS | rule | 0.06 | - | 3.7 |
| PURSUES BIG PREY | rule | 0.06 | - | 26.6 |
| RULE SWITCHED OFF | gate | 0.06 | - | 11.6 |
| SUPPORT REQUEST | gate | 0.06 | - | 158.7 |
| THROUGH LINE OF FIRE | rule | 0.06 | - | 3.0 |
| WHO HITS BACK | rule | 0.03 | 0.03 | 0.6 |
| BLOCKED WHEEL | rule | 0.03 | - | 3.4 |
| CARRIES OUT SET-UP | rule | 0.03 | - | 8.8 |
| CATCH ODDS | rule | 0.03 | - | 24.9 |
| FOLLOW UP WEIGHED | rule | - | 0.03 | 1.2 |
| LONE WIZARD HOLDS BACK | rule | 0.03 | - | 125.1 |
| REFUSING RETIRES | rule | 0.03 | - | 0.7 |
| SAFER THAN THE JOB | rule | 0.03 | - | 15.5 |

### Plans: fa-h2h-opp-8a94331-p3

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 10.4 | 15% | 150 | 282 | 188% |
| Mine | charge | 2.1 | 60% | 171 | 237 | 139% |
| Mine | close in | 5.5 | 21% | 359 | 138 | 39% |
| Mine | hold | 4.9 | 40% | 324 | 0 | 0% |
| Mine | join | 0.3 | 92% | 11 | 0 | 0% |
| Mine | shoot | 9.9 | 55% | 241 | 640 | 266% |
| Mine | support | 5.7 | 92% | 51 | 0 | 0% |
| Opponent | charge | 2.6 | 61% | 395 | 274 | 69% |
| Opponent | join | 0.6 | 91% | 28 | 0 | 0% |
| Opponent | move | 32.8 | 94% | 1642 | 0 | 0% |
| Opponent | shoot | 3.7 | 56% | 241 | 216 | 90% |
| Opponent | support | 0.3 | 80% | 3 | 0 | 0% |

### Packages: hunt the guns, fa-h2h-opp-8a94331-p3

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.2 | 8 | 2 | 17% | 17% | 0% | 3.0 | 301 | 56 | 17% | 28 |
| Opponent | 0.1 | 4 | 0 | 100% | 100% | 0% | 2.0 | 368 | 320 | 75% | 81 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 1.5 | 6 | 1 | 20% | 20% | 0% | 3.0 | 313 | 67 | 20% | 48 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 56 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 71 |
| Empire of Man | 0.2 | 1 | 1 | - | - | - | - | - | - | - | 63 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 96 |
| High Elf Realms | 0.1 | 1 | 0 | 100% | 100% | 0% | 2.0 | 506 | 431 | 100% | 25 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 224 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Ogre Kingdoms | 1.0 | 1 | 0 | 0% | 0% | 0% | - | 237 | 0 | 0% | 0 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 138 |
| Tomb Kings of Khemri | 0.3 | 2 | 0 | 100% | 100% | 0% | 2.0 | 358 | 312 | 50% | 12 |
| Vampire Counts | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 6 |
| Warriors of Chaos | 0.1 | 1 | 0 | 100% | 100% | 0% | 2.0 | 251 | 222 | 100% | 41 |
| Wood Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 74 |

### Battle groups: fa-h2h-opp-8a94331-p3

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 2.1 | 19% | 79% | 21% | 33% | 27% | 0% | 18% | 55% | 0% |
| Opponent | REDIRECT COUNTER | 3.9 | 20% | 75% | 11% | 0% | 16% | 0% | 4% | 76% | 4% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: fa-h2h-opp-8a94331-p3

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 1 | 129 (1) | 129 | 0 | 0 | 0% | 3.0 | - | 129 (1) | - | 129 (1) | - |
| Mine | Chaff | 34 | 37 (34) | 0 | 37 | 50 | 50% | 2.3 | 49 (21) | 0 (4) | 18 (9) | 55 (24) | 0 (10) |
| Mine | Character | 118 | 39 (118) | 39 | 0 | 33 | 16% | 2.6 | 40 (40) | 42 (60) | 31 (5) | 40 (60) | 40 (45) |
| Mine | Clean-up | 18 | 80 (18) | 34 | 47 | 40 | 17% | 3.2 | 157 (3) | 43 (13) | 357 (2) | 96 (12) | 57 (6) |
| Mine | Fast | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Mine | Fast Hammer | 44 | 37 (44) | 20 | 17 | 29 | 25% | 2.8 | 38 (22) | 45 (14) | 20 (8) | 48 (30) | 18 (14) |
| Mine | Fragile | 3 | 0 (3) | 0 | 0 | 33 | 100% | - | 0 (3) | - | - | 0 (1) | 0 (2) |
| Mine | Hammer | 52 | 28 (52) | 19 | 9 | 32 | 21% | 2.8 | 19 (14) | 32 (35) | 27 (3) | 29 (36) | 26 (16) |
| Mine | Holder | 25 | 58 (25) | 10 | 48 | 7 | 56% | 2.8 | 12 (7) | 69 (13) | 100 (4) | 73 (14) | 41 (10) |
| Mine | Shooter | 37 | 65 (37) | 21 | 44 | 32 | 3% | 1.9 | 47 (7) | 74 (28) | 0 (2) | 68 (21) | 61 (16) |
| Mine | Support | 4 | 63 (4) | 63 | 0 | 19 | 25% | 2.0 | 0 (1) | 43 (2) | - | 0 (1) | 43 (2) |
| Mine | War machine | 52 | 45 (52) | 45 | 0 | 33 | 2% | 1.1 | 59 (13) | 32 (36) | 133 (3) | 46 (13) | 44 (39) |
| Mine | Wizard | 17 | 5 (17) | 5 | 0 | 36 | 12% | 2.7 | 0 (5) | 11 (8) | 0 (1) | 8 (7) | 2 (7) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 0% | 6.0 | - | 0 (1) | - | - | 0 (1) |
| Opponent | Chaff | 68 | 22 (68) | 17 | 5 | 58 | 47% | 2.8 | 23 (29) | 37 (11) | 14 (28) | 31 (48) | 0 (20) |
| Opponent | Character | 102 | 45 (102) | 45 | 0 | 24 | 26% | 2.2 | 63 (40) | 34 (52) | 20 (5) | 56 (57) | 34 (40) |
| Opponent | Clean-up | 11 | 51 (11) | 13 | 38 | 29 | 18% | 3.8 | 10 (4) | 70 (6) | 71 (1) | 18 (6) | 81 (5) |
| Opponent | Fast | 1 | 292 (1) | 292 | 0 | 100 | 0% | 2.0 | - | 292 (1) | - | 292 (1) | - |
| Opponent | Fast Hammer | 60 | 31 (60) | 13 | 18 | 35 | 33% | 3.2 | 29 (30) | 22 (20) | 60 (10) | 25 (28) | 37 (32) |
| Opponent | Fragile | 3 | 62 (3) | 62 | 0 | 67 | 33% | 2.5 | - | 92 (2) | 0 (1) | 0 (2) | 185 (1) |
| Opponent | Hammer | 50 | 37 (50) | 30 | 7 | 42 | 32% | 3.3 | 5 (17) | 49 (30) | 21 (3) | 47 (30) | 21 (20) |
| Opponent | Holder | 40 | 71 (40) | 5 | 66 | 25 | 40% | 3.2 | 23 (8) | 125 (19) | 27 (9) | 90 (26) | 59 (10) |
| Opponent | Shooter | 27 | 29 (27) | 23 | 6 | 33 | 7% | 1.0 | 6 (6) | 28 (19) | 150 (2) | 33 (16) | 22 (11) |
| Opponent | Support | 4 | 0 (4) | 0 | 0 | 0 | 75% | 5.0 | 0 (2) | 0 (1) | 0 (1) | 0 (1) | 0 (3) |
| Opponent | War machine | 17 | 49 (17) | 49 | 0 | 40 | 0% | 1.6 | 46 (3) | 69 (10) | 10 (4) | 28 (3) | 53 (14) |
| Opponent | Wizard | 32 | 9 (32) | 9 | 0 | 47 | 19% | 2.2 | 4 (13) | 24 (8) | 16 (3) | 17 (14) | 0 (10) |

### Charged fights: fa-h2h-opp-8a94331-p3

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 84 | 228 | 2.2 | 1.0 | 102 | 57 | +44 | 2 of 9 | 8 of 9 | - | +44 |
| Mine | Chaos Dwarfs | 4 | 329 | 489 | 3.5 | 1.1 | 140 | 0 | +140 | 4 of 14 | 14 of 14 | +323 | +126 |
| Mine | Dwarfen Mountain Holds | 3 | 606 | 0 | 0.7 | 2.0 | 0 | 32 | -32 | 0 of 2 | 1 of 2 | +0 | -65 |
| Mine | Empire of Man | 5 | 354 | 68 | 0.8 | 1.0 | 85 | 0 | +85 | 2 of 4 | 3 of 4 | - | +85 |
| Mine | Grand Cathay | 5 | 420 | 229 | 2.2 | 1.5 | 104 | 93 | +12 | 6 of 11 | 8 of 11 | -13 | +26 |
| Mine | High Elf Realms | 4 | 100 | 552 | 3.2 | 1.0 | 170 | 11 | +159 | 4 of 13 | 12 of 13 | - | +159 |
| Mine | Kingdom of Bretonnia | 1 | 0 | 108 | 2.0 | 1.0 | 54 | 138 | -84 | 0 of 2 | 1 of 2 | - | -84 |
| Mine | Lizardmen | 1 | 116 | 260 | 4.0 | 1.0 | 65 | 35 | +30 | 2 of 4 | 2 of 4 | - | +30 |
| Mine | Ogre Kingdoms | 1 | 116 | 116 | 2.0 | 1.0 | 58 | 17 | +41 | 1 of 2 | 2 of 2 | - | +41 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 200 | 5.0 | 1.0 | 40 | 44 | -4 | 2 of 5 | 4 of 5 | - | -4 |
| Mine | Skaven | 1 | 19 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 0 of 1 | 1 of 1 | - | +0 |
| Mine | Tomb Kings of Khemri | 2 | 120 | 530 | 5.5 | 1.4 | 96 | 49 | +47 | 6 of 11 | 10 of 11 | +132 | +16 |
| Mine | Vampire Counts | 2 | 95 | 470 | 3.5 | 1.0 | 134 | 0 | +134 | 2 of 7 | 7 of 7 | - | +134 |
| Mine | Warriors of Chaos | 2 | 0 | 68 | 1.0 | 1.0 | 68 | 0 | +68 | 0 of 2 | 2 of 2 | - | +68 |
| **Mine** | all armies | 36 | 234 | 261 | 2.4 | 1.1 | 108 | 34 | +74 | 31 of 87 | 75 of 87 | +74 | +74 |
| Opponent | Empire of Man | 1 | 380 | 288 | 1.0 | 1.0 | 288 | 0 | +288 | 1 of 1 | 1 of 1 | - | +288 |
| Opponent | Grand Cathay | 3 | 346 | 0 | 0.7 | 1.0 | 0 | 0 | +0 | 1 of 2 | 2 of 2 | - | +0 |
| Opponent | High Elf Realms | 3 | 123 | 389 | 3.0 | 1.0 | 130 | 0 | +130 | 2 of 9 | 8 of 9 | - | +130 |
| Opponent | Kingdom of Bretonnia | 2 | 106 | 36 | 1.0 | 1.0 | 36 | 0 | +36 | 1 of 2 | 1 of 2 | - | +36 |
| Opponent | Orc & Goblin Tribes | 1 | 0 | 581 | 4.0 | 1.0 | 145 | 0 | +145 | 1 of 4 | 4 of 4 | - | +145 |
| Opponent | Skaven | 1 | 120 | 0 | 2.0 | 1.0 | 0 | 0 | +0 | 1 of 2 | 1 of 2 | - | +0 |
| Opponent | Tomb Kings of Khemri | 4 | 78 | 588 | 3.0 | 1.1 | 196 | 16 | +180 | 4 of 12 | 10 of 12 | +299 | +169 |
| Opponent | Vampire Counts | 6 | 0 | 354 | 3.0 | 1.2 | 118 | 26 | +92 | 8 of 18 | 13 of 18 | +60 | +101 |
| Opponent | Warriors of Chaos | 9 | 30 | 352 | 2.4 | 1.0 | 144 | 41 | +103 | 10 of 22 | 17 of 22 | -135 | +114 |
| Opponent | Wood Elf Realms | 6 | 202 | 168 | 1.8 | 1.0 | 91 | 40 | +51 | 5 of 11 | 6 of 11 | - | +51 |
| **Opponent** | all armies | 36 | 109 | 299 | 2.3 | 1.1 | 130 | 24 | +105 | 34 of 83 | 63 of 83 | +67 | +108 |

### Effective charges: fa-h2h-opp-8a94331-p3

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 9 | 0 | 0 | 3 (net +110) | 3 (net -126) | 0 | 2 (net +224) | 1 | 38% (3 of 8) |
| Mine | Chaos Dwarfs | 14 | 0 | 0 | 0 | 5 (net +200) | 1 (net +0) | 7 (net +136) | 1 | 0% (0 of 13) |
| Mine | Dwarfen Mountain Holds | 2 | 0 | 0 | 0 | 0 | 0 | 1 (net +0) | 1 | 0% (0 of 1) |
| Mine | Empire of Man | 4 | 1 (net +211) | 0 | 0 | 0 | 1 (net +55) | 2 (net +38) | 0 | 0% (0 of 4) |
| Mine | Grand Cathay | 11 | 1 (net +0) | 1 (net -434) | 2 (net -292) | 2 (net +211) | 2 (net +95) | 3 (net +178) | 0 | 18% (2 of 11) |
| Mine | High Elf Realms | 13 | 1 (net +929) | 1 (net +0) | 2 (net +412) | 2 (net +91) | 5 (net +40) | 1 (net +0) | 1 | 17% (2 of 12) |
| Mine | Kingdom of Bretonnia | 2 | 1 (net -275) | 0 | 0 | 0 | 1 (net +108) | 0 | 0 | 0% (0 of 2) |
| Mine | Lizardmen | 4 | 1 (net +0) | 0 | 0 | 0 | 1 (net +116) | 1 (net +144) | 1 | 0% (0 of 3) |
| Mine | Ogre Kingdoms | 2 | 1 (net -34) | 0 | 1 (net +116) | 0 | 0 | 0 | 0 | 50% (1 of 2) |
| Mine | Orc & Goblin Tribes | 5 | 0 | 0 | 0 | 0 | 1 (net +63) | 1 (net +137) | 3 | 0% (0 of 2) |
| Mine | Skaven | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +0) | 0 | 0% (0 of 1) |
| Mine | Tomb Kings of Khemri | 11 | 2 (net +332) | 1 (net +0) | 4 (net -135) | 1 (net +70) | 2 (net +162) | 1 (net +0) | 0 | 36% (4 of 11) |
| Mine | Vampire Counts | 7 | 0 | 0 | 1 (net +479) | 5 (net +92) | 0 | 0 | 1 | 17% (1 of 6) |
| Mine | Warriors of Chaos | 2 | 0 | 0 | 0 | 1 (net +0) | 0 | 0 | 1 | 0% (0 of 1) |
| Opponent | Empire of Man | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +288) | 0 | 0% (0 of 1) |
| Opponent | Grand Cathay | 2 | 0 | 1 (net +0) | 0 | 0 | 0 | 0 | 1 | 0% (0 of 1) |
| Opponent | High Elf Realms | 9 | 2 (net +65) | 0 | 0 | 4 (net +116) | 0 | 2 (net +218) | 1 | 0% (0 of 8) |
| Opponent | Kingdom of Bretonnia | 2 | 0 | 0 | 0 | 1 (net +73) | 0 | 1 (net +0) | 0 | 0% (0 of 2) |
| Opponent | Orc & Goblin Tribes | 4 | 0 | 0 | 0 | 0 | 0 | 1 (net +395) | 3 | 0% (0 of 1) |
| Opponent | Skaven | 2 | 0 | 0 | 0 | 1 (net +0) | 0 | 1 (net +0) | 0 | 0% (0 of 2) |
| Opponent | Tomb Kings of Khemri | 12 | 2 (net +338) | 0 | 1 (net +125) | 3 (net +35) | 2 (net +150) | 3 (net +276) | 1 | 9% (1 of 11) |
| Opponent | Vampire Counts | 18 | 4 (net +160) | 1 (net +0) | 5 (net +66) | 4 (net +102) | 1 (net +0) | 3 (net +93) | 0 | 28% (5 of 18) |
| Opponent | Warriors of Chaos | 22 | 5 (net -38) | 2 (net +82) | 3 (net +376) | 4 (net +176) | 0 | 5 (net +74) | 3 | 16% (3 of 19) |
| Opponent | Wood Elf Realms | 11 | 3 (net -71) | 0 | 1 (net +0) | 1 (net +170) | 0 | 0 | 6 | 20% (1 of 5) |

### Charged fights, damage counted: fa-h2h-opp-8a94331-p3

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 8 | 326 | 307 | +187 | 256 | 65 | +191 | +58.8 |
| Mine | 50-54% | 3 | 399 | 343 | -145 | 27 | 273 | -246 | -61.6 |
| Mine | Effective (55-75%) | 13 | 310 | 315 | +48 | 165 | 96 | +69 | +22.3 |
| Mine | 76-89% | 19 | 315 | 158 | +93 | 136 | 36 | +99 | +31.6 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 20 | 273 | 174 | +114 | 140 | 14 | +125 | +45.9 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 14 | 398 | 79 | +76 | 85 | 14 | +72 | +18.0 |
| Mine | No odds | 10 | 208 | 160 | -36 | 88 | 61 | +27 | +13.1 |
| Mine | All fights | 87 | 310 | 193 | +74 | 135 | 50 | +85 | +27.3 |
| Opponent | Long shot (under 50%) | 16 | 228 | 263 | +65 | 165 | 113 | +52 | +22.8 |
| Opponent | 50-54% | 4 | 162 | 265 | +41 | 190 | 0 | +190 | +117.2 |
| Opponent | Effective (55-75%) | 10 | 383 | 320 | +158 | 248 | 66 | +182 | +47.6 |
| Opponent | 76-89% | 18 | 289 | 171 | +107 | 146 | 14 | +132 | +45.7 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 17 | 287 | 215 | +153 | 168 | 26 | +142 | +49.5 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 3 | 441 | 133 | +100 | 110 | 43 | +66 | +15.1 |
| Opponent | No odds | 15 | 147 | 140 | +76 | 107 | 40 | +67 | +45.3 |
| Opponent | All fights | 83 | 262 | 213 | +105 | 160 | 47 | +113 | +43.3 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| fa-h2h-opp-8a94331-p3 | move | 413 | 66 (16%) | 50 (12%) | 50 (12%) | 297 (72%) |
| fa-h2h-opp-8a94331-p3 | objective | 198 | 19 (10%) | 16 (8%) | 17 (9%) | 162 (82%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0110, L0126, L2433, L2630 |
| Charmed Shield | Opponent | L0126, L0226, L0327, L0725, L1327, L2327 |
| Clockwork Compass | Mine | L1216, L1232 |
| Elixir of Power | Mine | L1122, L1932 |
| Elixir of Power | Opponent | L0311, L1519 |
| Fistful of Laurels | Mine | L1831 |
| Horn of the Wild Hunt | Opponent | L0533, L1633, L2033, L2433, L3133 |
| Invocation of Nehek | Mine | L2433 |
| Invocation of Nehek | Opponent | L0327, L0725, L1327, L2327 |
| Opal Amulet | Mine | L1422 |
| Periapt of Soul Exchange | Mine | L2033 |
| Periapt of Soul Exchange | Opponent | L0620 |
| Ring of Doom | Mine | L0210, L0226, L1122, L1216, L1232, L1519, L1535, L3133 |
| Ring of Doom | Opponent | L0311, L0533, L0815, L0831, L1633, L1731, L1831, L2033, L2433, L3133 |
| Ring of Jet | Mine | L1013, L1030, L1122, L1216, L1232 |
| Ring of Jet | Opponent | L0110, L0210, L0311 |
| Standard of the Fell Warrior | Mine | L1327 |
| Standard of the Fell Warrior | Opponent | L0413, L1013 |
| Twice-Blessed Armour | Mine | L0709, L0725, L1013, L1030 |
| Twice-Blessed Armour | Opponent | L0110, L0210 |
| Witch Hunter's Ward | Mine | L0709, L0725, L0815, L0831 |

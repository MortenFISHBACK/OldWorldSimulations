# Doctrine scorecard: fa-h2h-opp-8a94331-p2

### Scorecard: fa-h2h-opp-8a94331-p2

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0106 | 4 | 1 | Mine | no | 7 | - | 0 | 3 | 0 | 0 | 0 | 387 |
| L0106 | 4 | 1 | Opponent | no | 0 | 2 | 0 | 2 | 0 | 0 | 0 | 358 |
| L0122 | 2 | 1 | Mine | - | - | 4 | 1 | 2 | 0 | 0 | 0 | 0 |
| L0122 | 2 | 1 | Opponent | - | - | 2 | 1 | 1 | 0 | 0 | 0 | 0 |
| L0206 | 2 | 1 | Mine | - | - | 3 | 3 | 3 | 0 | 0 | 0 | 0 |
| L0206 | 2 | 1 | Opponent | - | - | - | 0 | 1 | 0 | 0 | 0 | 748 |
| L0222 | 6 | 1 | Mine | no | 7 | - | 0 | 5 | 0 | 0 | 0 | 170 |
| L0222 | 6 | 1 | Opponent | no | 12 | 3 | 1 | 1 | 0 | 0 | 0 | 170 |
| L0307 | 1 | 1 | Mine | yes | 8 | 3 | 2 | 0 | 0 | 0 | 0 | 675 |
| L0307 | 1 | 1 | Opponent | no | 11 | 5 | 2 | 2 | 0 | 0 | 0 | 420 |
| L0323 | 5 | 1 | Mine | no | - | 3 | 2 | 2 | 0 | 0 | 0 | 590 |
| L0323 | 5 | 1 | Opponent | yes | - | 2 | 1 | 2 | 2 | 0 | 0 | 132 |
| L0409 | 1 | 1 | Mine | no | 8 | 2 | 3 | 2 | 0 | 0 | 0 | 0 |
| L0409 | 1 | 1 | Opponent | no | 5 | - | 0 | 0 | 0 | 0 | 0 | 329 |
| L0425 | 5 | 1 | Mine | yes | - | 2 | 4 | 2 | 0 | 0 | 0 | 0 |
| L0425 | 5 | 1 | Opponent | yes | - | 3 | 1 | 4 | 0 | 0 | 0 | 0 |
| L0512 | 2 | 1 | Mine | - | - | - | 0 | 2 | 0 | 0 | 0 | 665 |
| L0512 | 2 | 1 | Opponent | - | - | 3 | 0 | 2 | 1 | 0 | 0 | 165 |
| L0528 | 6 | 1 | Mine | no | 0 | 2 | 1 | 1 | 0 | 0 | 0 | 1120 |
| L0528 | 6 | 1 | Opponent | no | 2 | - | 0 | 2 | 1 | 0 | 0 | 0 |
| L0616 | 4 | 1 | Mine | no | 0 | 2 | 3 | 2 | 0 | 0 | 0 | 615 |
| L0616 | 4 | 1 | Opponent | no | 5 | - | 0 | 1 | 0 | 0 | 0 | 0 |
| L0632 | 2 | 1 | Mine | - | - | 1 | 1 | 0 | 0 | 0 | 0 | 743 |
| L0632 | 2 | 1 | Opponent | - | - | 3 | 1 | 4 | 1 | 0 | 0 | 0 |
| L0721 | 1 | 1 | Mine | yes | 6 | 2 | 3 | 0 | 0 | 0 | 0 | 420 |
| L0721 | 1 | 1 | Opponent | yes | 5 | - | 0 | 5 | 0 | 0 | 0 | 355 |
| L0810 | 6 | 1 | Mine | no | 2 | 2 | 3 | 1 | 0 | 0 | 0 | 560 |
| L0810 | 6 | 1 | Opponent | no | 3 | 2 | 1 | 0 | 1 | 0 | 0 | 165 |
| L0827 | 5 | 1 | Mine | no | - | - | 0 | 0 | 0 | 0 | 0 | 605 |
| L0827 | 5 | 1 | Opponent | yes | - | 3 | 2 | 7 | 0 | 0 | 0 | 60 |
| L0918 | 6 | 1 | Mine | no | 0 | 3 | 1 | 1 | 0 | 0 | 0 | 420 |
| L0918 | 6 | 1 | Opponent | no | 2 | - | 1 | 3 | 0 | 0 | 0 | 234 |
| L0934 | 4 | 1 | Mine | no | 0 | - | 0 | 0 | 0 | 0 | 0 | 1029 |
| L0934 | 4 | 1 | Opponent | yes | 11 | 2 | 3 | 3 | 0 | 0 | 0 | 187 |
| L1026 | 6 | 1 | Mine | no | 0 | 2 | 3 | 0 | 0 | 0 | 0 | 330 |
| L1026 | 6 | 1 | Opponent | no | 3 | 5 | 2 | 3 | 0 | 0 | 0 | 329 |
| L1118 | 2 | 1 | Mine | - | - | 3 | 3 | 0 | 1 | 0 | 0 | 330 |
| L1118 | 2 | 1 | Opponent | - | - | 6 | 4 | 1 | 0 | 0 | 0 | 225 |
| L1135 | 1 | 1 | Mine | yes | 1 | 1 | 3 | 0 | 0 | 0 | 0 | 330 |
| L1135 | 1 | 1 | Opponent | yes | 3 | 3 | 4 | 1 | 1 | 0 | 0 | 0 |
| L1228 | 4 | 1 | Mine | no | 8 | 4 | 3 | 1 | 0 | 0 | 0 | 524 |
| L1228 | 4 | 1 | Opponent | no | 1 | - | 0 | 2 | 0 | 0 | 0 | 0 |
| L1323 | 3 | 1 | Mine | yes | 7 | 2 | 4 | 0 | 0 | 0 | 0 | 317 |
| L1323 | 3 | 1 | Opponent | no | 0 | 2 | 2 | 2 | 0 | 0 | 0 | 60 |
| L1418 | 2 | 1 | Mine | - | - | 2 | 6 | 1 | 0 | 0 | 0 | 0 |
| L1418 | 2 | 1 | Opponent | - | - | 2 | 3 | 0 | 0 | 0 | 0 | 0 |
| L1435 | 1 | 1 | Mine | no | 2 | 2 | 2 | 2 | 1 | 0 | 0 | 0 |
| L1435 | 1 | 1 | Opponent | no | 0 | 2 | 3 | 3 | 0 | 0 | 0 | 0 |
| L1531 | 1 | 1 | Mine | no | 1 | 5 | 3 | 1 | 0 | 0 | 0 | 0 |
| L1531 | 1 | 1 | Opponent | no | 1 | - | 1 | 1 | 0 | 0 | 0 | 484 |
| L1629 | 3 | 1 | Mine | no | 2 | 2 | 0 | 1 | 0 | 0 | 0 | 200 |
| L1629 | 3 | 1 | Opponent | no | 0 | 2 | 5 | 0 | 0 | 0 | 0 | 170 |
| L1727 | 5 | 1 | Mine | yes | - | 4 | 1 | 1 | 0 | 0 | 0 | 0 |
| L1727 | 5 | 1 | Opponent | no | - | 4 | 4 | 3 | 0 | 0 | 0 | 0 |
| L1827 | 3 | 1 | Mine | no | 0 | - | 3 | 1 | 0 | 0 | 0 | 0 |
| L1827 | 3 | 1 | Opponent | no | 12 | 2 | 2 | 4 | 0 | 0 | 0 | 0 |
| L1927 | 1 | 1 | Mine | no | 1 | 1 | 4 | 1 | 0 | 0 | 0 | 0 |
| L1927 | 1 | 1 | Opponent | no | 0 | 2 | 3 | 2 | 0 | 0 | 0 | 190 |
| L2029 | 1 | 1 | Mine | no | 2 | - | 3 | 1 | 2 | 0 | 0 | 860 |
| L2029 | 1 | 1 | Opponent | no | 0 | 4 | 3 | 2 | 1 | 0 | 0 | 170 |
| L2131 | 1 | 1 | Mine | yes | 3 | - | 0 | 3 | 0 | 0 | 0 | 722 |
| L2131 | 1 | 1 | Opponent | no | 3 | 2 | 0 | 0 | 0 | 0 | 0 | 170 |
| L2235 | 3 | 1 | Mine | no | 0 | 1 | 3 | 0 | 0 | 0 | 0 | 72 |
| L2235 | 3 | 1 | Opponent | no | 2 | 2 | 3 | 2 | 0 | 0 | 0 | 126 |
| L2429 | 5 | 1 | Mine | yes | - | 4 | 2 | 2 | 0 | 0 | 0 | 0 |
| L2429 | 5 | 1 | Opponent | yes | - | 6 | 1 | 4 | 0 | 0 | 0 | 0 |
| L2535 | 3 | 1 | Mine | no | 10 | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L2535 | 3 | 1 | Opponent | no | 0 | 1 | 2 | 0 | 0 | 0 | 0 | 102 |
| L2735 | 5 | 1 | Mine | yes | - | - | 2 | 1 | 0 | 0 | 0 | 0 |
| L2735 | 5 | 1 | Opponent | yes | - | 2 | 5 | 4 | 0 | 0 | 0 | 140 |
| L3033 | 3 | 1 | Mine | yes | 10 | 3 | 4 | 1 | 0 | 0 | 0 | 0 |
| L3033 | 3 | 1 | Opponent | no | 0 | 1 | 6 | 2 | 0 | 0 | 0 | 163 |
| **Average** | | | Mine | 33% | 3.5 | 2.5 | 2.2 | 1.2 | 0.1 | 0.0 | 0.0 | 324.6 |
| **Average** | | | Opponent | 27% | 3.4 | 2.8 | 1.9 | 2.1 | 0.2 | 0.0 | 0.0 | 157.0 |

### KPIs: fa-h2h-opp-8a94331-p2

Rules off - Mine only: FIVE ACTION, LIKELY CHARGE, FALLS SHORT, TIME ON OUR SIDE, FEATURE BUFFS, GETS AWAY CHANCE, GUN MASK, RUN DOWN, FOUR ROUNDS, CHARGE LOSSES, CHARACTER GUNS, STAND AND SHOOT, FALL BACK GOOD ORDER, AFTERMATH IN POINTS.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 20% (34 of 170) | 14% (24 of 173) | 17% (58 of 343) |
| Winner chose to follow up after the loser gave ground |  | 98% (53 of 54); on the table 98% | 98% (44 of 45); on the table 100% | 98% (97 of 99); on the table 99% |
| Winner chose to pursue after the loser fell back in good order |  | 82% (9 of 11); on the table 82% | 92% (11 of 12); on the table 92% | 87% (20 of 23); on the table 87% |
| Winner chose to pursue after the loser fled |  | 81% (13 of 16); on the table 94% | 70% (16 of 23); on the table 70% | 74% (29 of 39); on the table 79% |
| Winner chose to follow up or pursue (all three) |  | 93% (75 of 81); on the table 95% | 89% (71 of 80); on the table 90% | 91% (146 of 161); on the table 93% |
| Magic missiles tried each own turn | 50%+ | 32% (110 of 342) | 37% (57 of 156) | 34% (167 of 498) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 44% (110 of 252) | 44% (57 of 130) | 44% (167 of 382) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 64% (16 of 25) | 51% (27 of 53) | 55% (43 of 78) |
| Points that never fought | lower | 49% (34912 of 71583) | 50% (36313 of 71989) | 50% (71225 of 143572) |
|   infantry points that never fought | lower | 58% (9408 of 16324) | 68% (9564 of 14029) | 63% (18972 of 30353) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 61% (172 of 284) | 60% (179 of 297) | 60% (351 of 581) |
| Bound items with a magic missile used (at least once a game) |  | 90% (18 of 20); 1.7 uses a game | 72% (13 of 18); 1.2 uses a game | 82% (31 of 38); 1.4 uses a game |
| Bound items with another spell used |  | 56% (10 of 18); 0.5 uses a game | 0% (0 of 2); 0.0 uses a game | 50% (10 of 20); 0.2 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 50% (10 of 20); 0.3 uses a game | 0% (0 of 7); 0.0 uses a game | 37% (10 of 27); 0.1 uses a game |
|   their share of the points of units over 100 pts | lower | 57% (34275 of 60231) | 53% (33711 of 63281) | 55% (67986 of 123512) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 2.3 (35%) | 1.1 (38%) | 3.3 (36%) |
| MARCHED: its unit marched | 1.1 (16%) | 0.5 (17%) | 1.5 (17%) |
| CHARGED: its unit charged | 0.1 (2%) | 0.1 (4%) | 0.2 (2%) |
| IN COMBAT: engaged in combat | 1.3 (21%) | 0.2 (6%) | 1.5 (16%) |
| REAR RANK: in a rear rank | 0.3 (5%) | 0.2 (8%) | 0.6 (6%) |
| FLEEING: fleeing | 0.1 (1%) | 0.1 (3%) | 0.1 (2%) |
| GONE: slain | 1.0 (15%) | 0.3 (12%) | 1.3 (14%) |
| OFF THE TABLE: off the table or not arrived | 0.1 (2%) | 0.1 (5%) | 0.3 (3%) |
| STUPIDITY: Stupidity | 0.1 (2%) | 0.0 (0%) | 0.1 (2%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.2 (6%) | 0.2 (2%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.1 | 1.5 | 1.2 | 4.6 | 0.6 | 1.3 |
| not cast | 3.7 | 3.4 | 3.8 | 9.2 | 1.7 | 20.3 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) | 1.1 (5%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 2.2 (64%) | 0.3 (9%) | 3.3 (36%) | 0.7 (39%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.5 (17%) | 0.2 (13%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (2%) | 0.1 (5%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.1 (4%) | 0.1 (2%) | 0.4 (12%) | 1.5 (16%) | 0.1 (8%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.4 (10%) | 0.4 (11%) | 0.4 (12%) | 0.6 (6%) | 0.0 (0%) | 0.0 (0%) |
| NO CASTS LEFT: every cast used on other spells | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (2%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (1%) | 0.0 (0%) | 0.1 (1%) | 0.1 (2%) | 0.1 (3%) | 0.2 (1%) |
| GONE: slain | 0.6 (17%) | 0.4 (11%) | 0.7 (18%) | 1.3 (14%) | 0.1 (7%) | 1.9 (9%) |
| OFF THE TABLE: off the table or not arrived | 0.1 (3%) | 0.0 (0%) | 0.0 (0%) | 0.3 (3%) | 0.0 (0%) | 0.3 (2%) |
| STUPIDITY: Stupidity | 0.1 (2%) | 0.1 (2%) | 0.1 (1%) | 0.1 (2%) | 0.0 (0%) | 0.5 (2%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (2%) | 0.2 (6%) | 0.0 (0%) | 0.0 (0%) | 0.4 (23%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (2%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.3 (62%) | 0.2 (5%) | 1.7 (45%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 16.4 (81%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.6 a game | 0.8 a game | 0.7 a game |
| stood (cast and not dispelled) | 45% (9 of 20) | 59% (16 of 27) | 53% (25 of 47) |
| the unit moved after it | 78% (7 of 9) | 25% (4 of 16) | 44% (11 of 25) |
| it charged on its next turn | 0% (0 of 9) | 0% (0 of 16) | 0% (0 of 25) |
| the enemy charged it first | 0% (0 of 9) | 12% (2 of 16) | 8% (2 of 25) |
| it fought by the end of its next turn | 0% (0 of 9) | 12% (2 of 16) | 8% (2 of 25) |
| it moved out of a charge the enemy had planned (not charged first) | 11% (1 of 9) | 12% (2 of 16) | 12% (3 of 25) |
| none of these (no charge, no fight, no charge escaped) | 89% (8 of 9) | 75% (12 of 16) | 80% (20 of 25) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 64% (583 of 906) | 60% (469 of 781) | 62% (1052 of 1687) |
|   cavalry | 62% (55 of 88) | 64% (111 of 174) | 63% (166 of 262) |
|   character | 57% (62 of 109) | 42% (45 of 107) | 50% (107 of 216) |
|   chariot | 52% (49 of 95) | 67% (31 of 46) | 57% (80 of 141) |
|   infantry | 59% (162 of 274) | 61% (171 of 280) | 60% (333 of 554) |
|   monster | 44% (21 of 48) | 66% (27 of 41) | 54% (48 of 89) |
|   war machine | 80% (234 of 292) | 63% (84 of 133) | 75% (318 of 425) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.7 (30%) | 1.9 (21%) | 4.5 (26%) |
| CHARGED: it charged | 0.8 (9%) | 1.1 (12%) | 1.9 (11%) |
| FLEEING: it fled or was fleeing | 0.1 (1%) | 0.1 (1%) | 0.2 (1%) |
| IN COMBAT: it fought this turn or the last | 0.6 (7%) | 0.5 (6%) | 1.1 (6%) |
| MOVED: a war machine that moved | 0.1 (1%) | 0.3 (4%) | 0.4 (2%) |
| NO TARGET IN RANGE | 2.0 (22%) | 2.1 (25%) | 4.1 (23%) |
| ONLY IN COMBAT: the only targets were in combat | 0.6 (6%) | 0.3 (4%) | 0.9 (5%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.7 (19%) | 1.6 (19%) | 3.3 (19%) |
| SHELTERED: the target was sheltered | 0.3 (3%) | 0.2 (3%) | 0.5 (3%) |
| STUPIDITY | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR | 0.3 (3%) | 0.5 (5%) | 0.8 (4%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 7.2 | 1.9 | 78% | 5.6 pts | 40 pts |
| character | 3.0 | 1.2 | 70% | 13.6 pts | 41 pts |
| chariot | 2.3 | 1.4 | 66% | 15.5 pts | 35 pts |
| infantry | 12.9 | 5.9 | 68% | 10.1 pts | 130 pts |
| monster | 1.5 | 0.6 | 75% | 9.7 pts | 15 pts |
| war machine | 8.8 | 6.4 | 64% | 23.0 pts | 203 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.6 | 3.4 | 3.5 |
| Charges that made contact a game | 2.6 | 2.4 | 2.5 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.61 declared, 0.52 contact (23 units) | 0.36 declared, 0.14 contact (14 units) | 0.51 declared, 0.38 contact (37 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.33 declared, 0.17 contact (6 units) | 0.79 declared, 0.64 contact (14 units) | 0.65 declared, 0.50 contact (20 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.46 declared, 0.33 contact (245 units) | 0.35 declared, 0.26 contact (300 units) | 0.40 declared, 0.29 contact (545 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 58% (42 of 73) | 72% (13 of 18) | 67% (8 of 12) | 61% (63 of 103) |
| Character in a unit | 85% (34 of 40) | 67% (12 of 18) | 33% (1 of 3) | 77% (47 of 61) |
| Character on its own | 75% (24 of 32) | 50% (18 of 36) | 30% (19 of 63) | 47% (61 of 131) |
| Chariot | 76% (13 of 17) | 77% (10 of 13) | - | 77% (23 of 30) |
| Infantry | 59% (55 of 94) | 56% (19 of 34) | 33% (1 of 3) | 57% (75 of 131) |
| Monster | 55% (16 of 29) | 56% (5 of 9) | - | 55% (21 of 38) |
| Monstrous | 50% (7 of 14) | 71% (10 of 14) | - | 61% (17 of 28) |
| War Machines | 74% (42 of 57) | 100% (2 of 2) | - | 75% (44 of 59) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 86% (6 of 7); on the table 86% | 25% (25 of 102) | 39% | 45% (10 of 22) | 83% (5 of 6); 4.2 uses a game | 50% (1 of 2); 1.2 uses a game | 83% (5 of 6); 1.2 uses a game |
| Chaos Dwarfs | 4 | 100% (11 of 11); on the table 100% | 47% (17 of 36) | 56% | 56% (18 of 32) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
| Dwarfen Mountain Holds | 6 | 90% (9 of 10); on the table 90% | - | 77% | 72% (39 of 54) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 7 | 83% (5 of 6); on the table 83% | 40% (19 of 48) | 57% | 70% (53 of 76) | 0.0 uses a game | 50% (1 of 2); 0.1 uses a game | 50% (2 of 4); 0.3 uses a game |
| Grand Cathay | 6 | 83% (10 of 12); on the table 83% | 38% (52 of 138) | 59% | 56% (30 of 54) | 79% (11 of 14); 5.7 uses a game | 0% (0 of 2); 0.0 uses a game | 0% (0 of 6); 0.0 uses a game |
| High Elf Realms | 4 | 100% (9 of 9); on the table 100% | 11% (2 of 18) | 29% | 48% (16 of 33) | 100% (3 of 3); 3.2 uses a game | 57% (8 of 14); 3.0 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 2 | 100% (2 of 2); on the table 100% | - | 48% | 67% (8 of 12) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.5 uses a game |
| Lizardmen | 1 | - | - | 75% | 86% (6 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 4 | 100% (6 of 6); on the table 100% | 0% (0 of 18) | 59% | 68% (19 of 28) | 100% (4 of 4); 2.2 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 1 | 100% (2 of 2); on the table 100% | 0% (0 of 12) | 12% | 38% (3 of 8) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Skaven | 3 | 90% (9 of 10); on the table 90% | 22% (4 of 18) | 44% | 56% (14 of 25) | 100% (2 of 2); 2.0 uses a game | 0.0 uses a game | 0% (0 of 3); 0.0 uses a game |
| Tomb Kings of Khemri | 5 | 100% (10 of 10); on the table 100% | - | 44% | 28% (7 of 25) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 9 | 89% (25 of 28); on the table 96% | 45% (30 of 66) | 49% | 74% (40 of 54) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 9 | 79% (19 of 24); on the table 83% | 44% (8 of 18) | 42% | 59% (43 of 73) | 100% (2 of 2); 1.1 uses a game | 0.0 uses a game | 100% (1 of 1); 0.1 uses a game |
| Wood Elf Realms | 7 | 96% (23 of 24); on the table 96% | 42% (10 of 24) | 38% | 58% (45 of 78) | 57% (4 of 7); 2.1 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (fa-h2h-opp-8a94331-p2, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 55% (28) | 62% (35) | 59% (63) |
| ...free all their last turn and able to turn (per game) | 0.56 | 0.72 | 1.28 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.11 | 0.14 | 0.25 |
| ...with the charger already in that arc before they moved (per game) | 0.47 | 0.47 | 0.94 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 1.61 | 0.06 | 1.67 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.89 | 0.03 | 0.92 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 6.22 | 0.22 | 6.44 |

### Quality by phase: fa-h2h-opp-8a94331-p2

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.8 | 3.3 |
| Strategy | Charge objectives carried out (made contact) | 55% (55 of 100) | 50% (56 of 113) |
| Strategy | Shoot objectives carried out (shot that target) | 40% (164 of 411) | 55% (124 of 227) |
| Strategy | Close-in objectives charged next turn | 9% (16 of 178) | - |
| Strategy | Support requests answered (helper made contact too) | 38% (3 of 8) | 47% (7 of 15) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (1 of 1) | 100% (2 of 2) |
| Strategy | Hexes on a unit its side charged or shot that turn | 53% (8 of 15) | 57% (12 of 21) |
| Strategy | Joined characters whose unit fought | 35% (19 of 55) | 24% (10 of 41) |
| Strategy | Lone characters that fought | 67% (60 of 90) | 62% (51 of 82) |
| Movement | Charges halted short of contact | 0.1 | 0.1 |
| Movement | Idle units | 1.2 | 2.1 |
| Movement | Points that never moved of their own | 324.6 | 157.0 |
| Movement | Fights charged into per game | 2.4 | 2.2 |
| Movement | Charges with odds: long shots (under 50%) | 9 of 72, net -5 | 12 of 67, net +69 |
| Movement | Charges with odds: sweet spot (55-75%) | 15 of 72, net +37 | 11 of 67, net +197 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 10 of 72, net +48 | 3 of 67, net +27 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 23 of 72, net +130 | 18 of 67, net +173 |
| Shooting | Shots by shooting units (incl. breath weapons) | 10.3 | 12.1 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 50% (186 of 370) | 49% (214 of 435) |
| Shooting | Points destroyed by shooting units | 124.8 | 48.7 |
| Shooting | War machine shots | 6.5 | 2.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 55% (129 of 234) | 56% (47 of 84) |
| Shooting | Points destroyed by war machines | 72.5 | 38.3 |
| Magic | Magic missiles cast | 1.9 | 1.0 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 46% (31 of 67) | 32% (12 of 37) |
| Magic | Wounds caused by magic missiles | 2.7 | 1.4 |
| Magic | Wounds caused by other spells | 0.9 | 0.2 |
| Magic | Points destroyed by magic (all spells) | 61.3 | 42.7 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.0 / 0.5 / 0.6 / 0.1 | 1.8 / 0.6 / 0.4 / 0.2 |
| Combat | Points destroyed in combat | 218.5 | 314.4 |
| Combat | Points run down | 27.5 | 44.5 |
| Combat | Net points per charged fight, damage counted | +59 | +125 |
| Combat | Net per 100 charger points, damage counted | +24.1 | +45.0 |
| Combat | First round won (charged fights) | 79% | 72% |
| Combat | Net points per charged fight | +56 | +118 |
| Combat | Net points per supported fight / lone fight | +36 / +58 | +121 / +118 |
| Combat | Charged fights on a top-3 enemy unit | 22 of 87 | 33 of 81 |
| Game | Points lost | 584.8 | 569.3 |
| Game | VP from objectives | 570.0 | 598.1 |
| Game | Lone holders (player turns) | 3.5 | 3.4 |

- Mine won / drew / lost: 12 / 11 / 13 of 36 ended games (of 36); mean margin (Mine - Opponent) -79 VP
- The side that went first won 14 of 25 games with a winner
- Points traded per game (both sides' losses): 1154
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: fa-h2h-opp-8a94331-p2

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 0.5 | +0.0 | 0.0 | 0.0 |
| ADVANCE WORTH | 5.5 | -239.3 | 121.2 | 89.1 | - | - | - | - |
| AFTERMATH IN POINTS | - | - | - | - | 0.1 | +10.7 | 0.0 | 0.0 |
| ARRIVAL HUNT | - | - | - | - | 0.1 | +2.8 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.5 | +0.0 | 0.0 | 19.3 | 0.1 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | 0.6 | +2.5 | 0.0 | 0.0 | 0.6 | +3.4 | 0.0 | 10.6 |
| BEST FACING | 0.4 | +8.6 | 0.0 | 10.2 | - | - | - | - |
| BEST FIRST | 1.8 | +89.5 | 27.4 | 15.6 | - | - | - | - |
| BEST OVERALL | 0.2 | +8.3 | 0.0 | 9.3 | - | - | - | - |
| BEST PREY | 0.8 | +30.1 | 0.0 | 0.0 | - | - | - | - |
| BEST PRIZE | 0.0 | +0.3 | 0.0 | 0.0 | 0.1 | -4.5 | 6.8 | 16.6 |
| BIG CHARACTER SAFETY | 0.2 | -1.2 | 0.0 | 0.0 | - | - | - | - |
| BLOCKED CHARGE SKIPPED | 0.1 | +0.0 | 8.9 | 0.0 | - | - | - | - |
| BLOCKED WHEEL | 0.3 | +14.0 | 0.0 | 14.2 | - | - | - | - |
| BLOWS WHERE AIMED | 0.2 | -28.9 | 4.4 | 5.5 | 0.3 | -49.6 | 49.7 | 5.4 |
| BOMBING RUN | 0.0 | +0.5 | 0.0 | 0.0 | - | - | - | - |
| BOUND ASSAILMENT | 0.1 | +0.0 | 0.0 | 10.2 | - | - | - | - |
| CANNON PLAN MISSED | 0.8 | +0.0 | 121.7 | 4.6 | 0.2 | +0.0 | 22.1 | 6.2 |
| CANNON PLANNED TARGET | 4.8 | +195.4 | 471.1 | 61.1 | 2.0 | +81.3 | 145.0 | 3.2 |
| CANNON SIGHT KEPT | 1.3 | +0.0 | 0.0 | 3.5 | 0.6 | +0.0 | 0.0 | 7.7 |
| CARRIES OUT COUNTER | 0.0 | +0.0 | 0.0 | 7.4 | 0.0 | -1.2 | 11.1 | 0.0 |
| CARRIES OUT SET-UP | 0.1 | +0.0 | 0.0 | 0.0 | 0.0 | -2.5 | 7.8 | 5.4 |
| CAST JOB | 0.8 | +11.7 | 31.5 | 22.6 | 0.2 | +3.7 | 9.1 | 0.0 |
| CASTER AWAY FROM SCREEN | 0.3 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.6 | +28.9 | 27.8 | 7.6 | 0.1 | +5.9 | 2.1 | 0.0 |
| CASTS AFTER FRIENDS | 0.3 | +0.0 | 0.0 | 13.9 | 0.4 | +0.0 | 0.0 | 24.1 |
| CASTS FROM BEHIND | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.1 | +4.3 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | 0.9 | +54.5 | 0.0 | 26.2 | 0.5 | +12.3 | 0.0 | 5.6 |
| CHAFF PASSED | 0.2 | -0.5 | 9.9 | 0.0 | 0.3 | -0.1 | 5.2 | 2.0 |
| CHARACTER GUNS | - | - | - | - | 0.5 | +0.0 | 0.0 | 5.2 |
| CHARGE LOSSES | - | - | - | - | 11.1 | -321.8 | 0.0 | 308.6 |
| CHARGE NOW FIRST | 1.9 | +0.0 | 104.3 | 35.8 | 1.4 | +0.0 | 165.9 | 60.8 |
| CHARGE NOW WEIGHED | 0.5 | -30.2 | 3.1 | 2.1 | - | - | - | - |
| CHARGER SLAIN LOST | 0.3 | -5.3 | 11.7 | 7.8 | 0.3 | -4.6 | 32.7 | 24.1 |
| CHARIOT WIZARD CAREFUL | 0.0 | -0.0 | 0.0 | 0.0 | - | - | - | - |
| CHEAP HELPER | 0.1 | +0.0 | 8.2 | 0.0 | 0.2 | +0.0 | 13.4 | 0.0 |
| COMBAT PIVOT | 0.3 | +0.0 | 6.1 | 36.5 | 0.4 | +0.0 | 27.7 | 18.9 |
| CONVEYANCE SEARCH | 0.4 | +36.6 | 0.0 | 0.0 | 0.6 | +36.6 | 21.6 | 37.0 |
| COVER ONCE | 9.3 | -716.7 | 0.0 | 119.2 | 6.3 | -487.6 | 0.0 | 155.6 |
| DEFENSIVE ARMY | 0.1 | +0.0 | 49.9 | 0.0 | 0.0 | +0.0 | 8.6 | 0.0 |
| EDGE GIVE GROUND | 0.2 | +7.3 | 26.6 | 4.2 | 0.3 | +9.5 | 28.5 | 0.0 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 1.6 | +83.3 | 0.0 | 23.2 | 0.1 | +5.5 | 0.0 | 0.0 |
| FALL BACK GOOD ORDER | - | - | - | - | 2.3 | +3.6 | 218.0 | 42.0 |
| FALLBACK BY WORTH | 5.4 | +46.2 | 0.0 | 35.6 | 0.1 | +0.0 | 0.0 | 1.5 |
| FALLS SHORT | - | - | - | - | 0.2 | -0.7 | 0.0 | 9.1 |
| FEATURE BUFFS | - | - | - | - | 0.6 | +18.5 | 0.0 | 6.9 |
| FIRE AND FLEE | - | - | - | - | 0.1 | +0.9 | 0.0 | 6.3 |
| FIVE ACTION | - | - | - | - | 48.4 | +2958.3 | 647.5 | 681.2 |
| FLANK NOT WEIGHED | 5.4 | +0.0 | 0.0 | 108.8 | 5.6 | +0.0 | 0.0 | 114.8 |
| FOLLOW UP WEIGHED | 0.9 | +104.6 | 0.0 | 57.1 | 1.1 | +153.0 | 0.0 | 8.6 |
| FOUR ROUNDS | - | - | - | - | 3.1 | +215.4 | 310.2 | 63.5 |
| FRIENDS SHOTS CHECKED | 0.2 | +11.0 | 0.0 | 5.7 | 0.1 | +4.2 | 0.0 | 2.9 |
| GIVES UP | 0.1 | -2.4 | 0.0 | 5.7 | 0.1 | -1.0 | 24.4 | 0.0 |
| GIVES UP ITS SCREEN | 0.0 | -0.1 | 0.0 | 0.0 | 0.0 | -0.0 | 3.4 | 0.0 |
| GROUND FLIERS | 0.0 | +0.7 | 0.0 | 7.5 | - | - | - | - |
| GUN MASK | - | - | - | - | 0.3 | -2.2 | 0.0 | 0.0 |
| HELPER UNSEEN | 0.1 | +0.0 | 0.0 | 5.7 | 0.2 | +0.0 | 8.4 | 15.8 |
| HILL BY ITS CHANCE | 0.3 | -31.6 | 0.0 | 0.0 | - | - | - | - |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 7.8 | -105.1 | 297.7 | 103.1 | 2.6 | -123.4 | 242.7 | 44.8 |
| HORN WORTH | - | - | - | - | 0.0 | +0.1 | 0.0 | 0.0 |
| HUNT ADVANCE | 0.1 | +0.5 | 0.0 | 3.2 | - | - | - | - |
| HUNT DROPPED | 0.0 | +0.0 | 0.0 | 3.2 | - | - | - | - |
| HUNT IN PAIRS | 0.4 | +32.1 | 0.0 | 10.2 | 0.7 | +57.3 | 0.0 | 55.8 |
| HUNT KEPT | 0.0 | +0.3 | 0.0 | 3.2 | 0.1 | +3.0 | 12.6 | 0.0 |
| HUNT RESULT | 0.1 | +7.0 | 0.0 | 3.2 | 0.1 | +53.3 | 3.5 | 0.9 |
| HUNT THE GUNS | 0.1 | +15.6 | 2.8 | 0.0 | 0.1 | +70.3 | 22.9 | 0.0 |
| IDLE COST | 16.6 | -281.2 | 0.0 | 125.5 | 20.6 | -309.3 | 0.0 | 255.0 |
| INVITES THE FIGHT | 1.2 | +9.7 | 26.9 | 50.3 | - | - | - | - |
| JOINT CHARGE PLAN | 0.1 | +0.3 | 0.0 | 0.0 | - | - | - | - |
| KEEP FALLS | 0.0 | +0.4 | 0.0 | 0.0 | - | - | - | - |
| KEEPS ITS PREY | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KEEPS ITS TARGET | 1.6 | +46.7 | 70.8 | 31.5 | - | - | - | - |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| KILLS COUNT | 1.1 | +37.7 | 54.1 | 32.3 | 1.6 | +69.4 | 149.1 | 19.1 |
| KILLS COUNT NEXT TURN | 5.2 | +160.9 | 145.8 | 33.6 | - | - | - | - |
| LONE CHARACTER SAFE SPOT | 0.2 | +16.2 | 9.1 | 0.0 | 0.1 | +0.8 | 0.0 | 0.0 |
| LONE WIZARD HOLDS BACK | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| LONE WIZARD KEPT IN | 0.6 | +39.4 | 0.0 | 0.0 | 0.3 | +23.5 | 0.0 | 0.0 |
| LONG SHOT | 0.4 | -0.7 | 20.3 | 1.8 | 0.3 | +2.6 | 19.6 | 2.8 |
| LOST CHARGE | 2.8 | -44.6 | 74.7 | 73.9 | 0.1 | -0.2 | 5.6 | 2.9 |
| LURE BY WHAT IT DRAWS | 0.1 | -6.4 | 0.0 | 0.0 | 0.1 | -4.5 | 0.0 | 0.5 |
| MAKE SURE TOGETHER | 0.4 | +28.8 | 6.5 | 0.0 | 0.1 | +0.3 | 0.0 | 3.5 |
| MANOEUVRE | 0.2 | +10.1 | 0.0 | 0.0 | 0.6 | +5.1 | 0.0 | 10.5 |
| MARCH AT ESCAPER | 0.0 | +0.1 | 0.0 | 0.0 | 0.1 | +1.2 | 0.0 | 4.4 |
| MARCH CHECK | 0.5 | +4.8 | 0.0 | 4.6 | 0.7 | +26.5 | 0.0 | 0.0 |
| MARCH ODDS | 0.2 | +22.3 | 6.4 | 0.0 | 0.1 | +2.2 | 0.0 | 0.0 |
| MARCH OVER CASTS | 0.4 | +26.4 | 0.0 | 11.1 | 0.6 | +77.9 | 0.0 | 18.9 |
| MAX FOR POSITIONING | 6.4 | +81.2 | 0.0 | 162.5 | 7.3 | +93.0 | 0.0 | 154.0 |
| MISSILES IN THE MOVE | 4.3 | +96.8 | 0.0 | 105.6 | 3.4 | +74.3 | 0.0 | 72.1 |
| MISSILES NEXT TURN | 5.2 | +65.9 | 0.0 | 109.2 | 3.8 | +48.5 | 0.0 | 90.8 |
| MODEL FACING | 0.4 | +106.0 | 0.0 | 0.0 | 0.4 | +98.1 | 0.0 | 0.0 |
| MONSTER WIZARD ROAMS | 0.3 | +0.0 | 9.1 | 10.2 | - | - | - | - |
| MOVE AND CAST | 0.4 | +26.2 | 0.0 | 16.2 | - | - | - | - |
| MOVE SPELL IN RANGE | 0.2 | +11.9 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL NOT WORTH | 0.0 | -0.0 | 0.0 | 0.0 | 0.0 | -0.0 | 0.0 | 0.0 |
| MOVE SPELL OUT OF RANGE | 0.4 | -17.4 | 0.0 | 0.0 | 0.1 | -2.3 | 3.5 | 7.6 |
| MOVE SPELL SPOT | 0.2 | +0.0 | 0.0 | 13.9 | 0.0 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE | 3.6 | +221.8 | 121.4 | 64.3 | - | - | - | - |
| MOVES UNITS SPELL | 0.1 | +3.4 | 0.0 | 0.0 | - | - | - | - |
| NEEDED THERE | 0.1 | +17.8 | 6.3 | 0.0 | 0.0 | +21.1 | 7.1 | 0.0 |
| NO RALLY LEFT | 0.0 | +3.0 | 0.0 | 0.0 | - | - | - | - |
| NOT NEEDED | 0.2 | -6.1 | 13.6 | 1.2 | - | - | - | - |
| NOT TURNED | 6.2 | +115.9 | 0.0 | 136.2 | 0.2 | +1.4 | 0.0 | 0.0 |
| NOT WORTH A CAST | 0.5 | -0.2 | 0.0 | 0.0 | 0.8 | -0.6 | 0.0 | 0.0 |
| OFF BEST | 17.2 | -688.5 | 6.3 | 264.2 | 1.9 | -39.0 | 0.0 | 31.6 |
| ONE FIGHT FORMULA | 9.0 | -154.4 | 20.0 | 231.2 | 8.5 | -183.6 | 0.0 | 197.8 |
| ONE OBJECTIVE FORMULA | 3.0 | -137.9 | 0.0 | 23.8 | 2.7 | -49.3 | 0.0 | 37.3 |
| OPENS A LANE | 0.2 | +0.8 | 6.2 | 3.6 | 0.1 | +0.2 | 13.9 | 0.0 |
| OPENS UP | 0.2 | +22.4 | 14.1 | 0.0 | 0.2 | +17.3 | 11.8 | 5.4 |
| OVERRUNS AWAY | 0.3 | +4.3 | 22.2 | 8.0 | 0.4 | +5.8 | 48.3 | 19.5 |
| PATHS CROSS | 2.1 | +166.6 | 0.0 | 28.0 | 2.7 | +212.0 | 0.0 | 63.9 |
| PIVOT GUARDS FLANK | 0.2 | -3.9 | 0.0 | 10.3 | 0.1 | -1.1 | 0.0 | 0.0 |
| PLAN RESULT | 38.6 | +1279.3 | 1043.5 | 791.4 | 42.8 | +518.5 | 375.9 | 786.4 |
| PURSUES BIG PREY | - | - | - | - | 0.1 | -15.2 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE NEXT TURN | 0.1 | +7.4 | 0.0 | 3.4 | - | - | - | - |
| RANDOM MOVE BY FIGURES | 0.7 | +21.9 | 0.0 | 17.9 | 1.5 | +21.8 | 0.0 | 39.7 |
| RANDOM MOVER NO PROMISE | 0.2 | -10.0 | 0.0 | 0.0 | - | - | - | - |
| REDIRECT BY WHAT IT STOPS | 0.8 | -21.2 | 0.0 | 22.2 | - | - | - | - |
| REDIRECT COUNTER | 2.8 | +172.1 | 0.0 | 62.5 | 3.5 | +258.9 | 0.0 | 68.7 |
| REDIRECT WEIGHED | 0.3 | +0.9 | 0.8 | 0.0 | 0.2 | +2.5 | 15.0 | 8.4 |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | 0.5 | +15.0 | 0.0 | 4.2 | 1.6 | +52.5 | 0.0 | 18.0 |
| RESTRAINS TO SHOOT | 0.0 | +0.4 | 0.0 | 0.0 | 0.1 | +0.7 | 0.0 | 0.0 |
| RISK BY ARC | 1.9 | +73.5 | 123.2 | 45.7 | 2.1 | +48.4 | 233.8 | 48.7 |
| RISK ONCE | 5.1 | +179.8 | 17.5 | 201.8 | - | - | - | - |
| RUN DOWN | - | - | - | - | 2.2 | -25.3 | 245.1 | 48.1 |
| SAFER THAN THE JOB | 0.9 | +34.3 | 0.0 | 31.3 | 0.0 | +1.3 | 0.0 | 1.7 |
| SCOUT SPOT | 0.3 | +0.9 | 0.0 | 0.9 | 0.5 | +2.3 | 0.0 | 0.0 |
| SCOUT WAITS | 0.3 | +0.0 | 0.0 | 0.9 | 0.6 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.3 | -9.0 | 0.0 | 4.0 | 0.1 | -6.8 | 0.0 | 2.7 |
| SEARCH SPOT | 2.6 | +99.6 | 0.0 | 29.6 | 4.9 | +164.5 | 0.0 | 111.4 |
| SECOND HUNTER | - | - | - | - | 0.1 | -0.5 | 9.2 | 0.0 |
| SELF MOVE SPELL | 0.2 | +2.1 | 0.0 | 0.0 | - | - | - | - |
| SET UP TOGETHER | 0.9 | +65.8 | 10.7 | 11.2 | 0.3 | +3.1 | 0.0 | 8.7 |
| SET-UP ANY TARGET | 0.1 | +18.5 | 0.0 | 0.0 | 0.1 | +8.7 | 0.0 | 0.0 |
| SET-UP MISSED | 0.0 | +1.4 | 0.0 | 0.0 | 0.1 | +9.1 | 0.0 | 7.6 |
| SHOOTER COUNTED ONCE | 0.1 | -0.1 | 0.0 | 0.0 | 0.1 | -0.6 | 0.0 | 1.1 |
| SHOOTERS IN TWO RANKS | 0.4 | +0.8 | 0.0 | 0.0 | 0.3 | +0.6 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.8 | +64.2 | 83.1 | 50.7 | 0.8 | +39.0 | 32.3 | 26.4 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| SHOT REPLANNED | 0.9 | +0.0 | 236.8 | 4.6 | 0.6 | +0.0 | 60.8 | 0.0 |
| SHOTS IN THE MOVE | 14.2 | +602.1 | 0.0 | 213.0 | 14.1 | +493.0 | 0.0 | 181.2 |
| SPELL SETS UP CHARGE | 0.2 | +50.6 | 0.0 | 0.0 | 0.1 | +14.4 | 3.2 | 0.0 |
| SPELL WORTH | 0.8 | +17.1 | 40.6 | 40.6 | 1.8 | +23.5 | 63.5 | 63.5 |
| SPELLS IN THE FIGHT | 0.6 | -1.7 | 23.1 | 21.7 | 0.6 | -3.3 | 76.3 | 6.4 |
| STABLE ROLE | 12.1 | +0.0 | 287.9 | 176.3 | - | - | - | - |
| STAND AND SHOOT | - | - | - | - | 0.5 | -4.3 | 47.7 | 5.0 |
| STANDS TO CAST | - | - | - | - | 0.0 | +0.5 | 0.0 | 0.0 |
| STAY WEIGHED | 0.1 | +0.4 | 0.0 | 7.6 | - | - | - | - |
| STOPS | 0.0 | +3.7 | 2.8 | 0.0 | 0.2 | +11.3 | 32.1 | 0.0 |
| STOPS SHORT OF THE FLANK | 0.4 | +11.0 | 0.0 | 22.0 | - | - | - | - |
| STUCK PIVOT | 0.0 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| SUPPORT NARROWED | 6.8 | -65.0 | 219.4 | 114.7 | 1.2 | +0.0 | 122.4 | 41.7 |
| SUPPORTS | 5.2 | +71.9 | 134.1 | 77.3 | - | - | - | - |
| SURE CHARGE BEATS ADVANCE | 0.1 | -2.1 | 1.1 | 0.0 | - | - | - | - |
| SURE REACH TOGETHER | 0.3 | -0.4 | 3.0 | 0.0 | 0.3 | +5.2 | 0.0 | 19.2 |
| THROUGH LINE OF FIRE | 0.4 | +8.4 | 0.0 | 0.0 | - | - | - | - |
| TIME ON OUR SIDE | - | - | - | - | 1.6 | +0.0 | 0.0 | 5.5 |
| TURN WORTH | 0.2 | -20.6 | 17.2 | 0.0 | 0.1 | -2.2 | 6.4 | 5.4 |
| TWO OR MORE ARRIVE | 0.2 | +5.8 | 6.5 | 0.0 | - | - | - | - |
| WAIT AFTER COSTS | 7.1 | -337.6 | 210.1 | 132.3 | - | - | - | - |
| WALKS TO THE FIGHT | 1.8 | +13.9 | 41.2 | 7.4 | - | - | - | - |
| WAR ENGINE CHARGES | 0.1 | +7.3 | 0.0 | 4.2 | - | - | - | - |
| WAR ENGINE JOBS | 0.6 | +0.0 | 3.5 | 56.9 | 0.0 | +0.0 | 4.6 | 3.8 |
| WEARS DOWN | 0.9 | +37.7 | 49.6 | 20.8 | 0.8 | +30.8 | 104.1 | 39.3 |
| WHO HITS BACK | 0.3 | +27.9 | 0.0 | 6.4 | 0.2 | +12.3 | 0.0 | 4.7 |
| WHOLE FIGHT | 0.1 | +2.8 | 4.6 | 1.4 | 0.2 | +6.6 | 57.5 | 1.9 |
| WHOLE FIGHT GAIN | 0.3 | +13.5 | 21.2 | 4.7 | 0.2 | +14.3 | 31.5 | 8.9 |
| WIDER SPREAD | 1.9 | -5.6 | 92.9 | 40.8 | 2.2 | -6.9 | 243.1 | 42.6 |

### Rule changes: fa-h2h-opp-8a94331-p2

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 688 | 688 | 688 | 19.11 | -26187 | -38.1 |
| SEARCH SPOT | 270 | 270 | 261 | 7.25 | +9516 | +36.5 |
| PATHS CROSS | 172 | 172 | 172 | 4.78 | +13631 | +79.2 |
| IDLE COST | 1337 | 703 | 106 | 2.94 | +1093 | +10.3 |
| SHOTS IN THE MOVE | 1020 | 712 | 105 | 2.92 | +4496 | +42.8 |
| SUPPORTS | 188 | 188 | 79 | 2.19 | +941 | +11.9 |
| MAX FOR POSITIONING | 494 | 404 | 77 | 2.14 | +208 | +2.7 |
| COVER ONCE | 563 | 309 | 76 | 2.11 | +1502 | +19.8 |
| REDIRECT COUNTER | 228 | 161 | 74 | 2.06 | +5391 | +72.9 |
| RESERVE FALL BACK | 74 | 74 | 74 | 2.06 | +2431 | +32.9 |
| CANNON SIGHT KEPT | 70 | 70 | 70 | 1.94 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 70 | 70 | 70 | 1.94 | +9276 | +132.5 |
| MOVE TO CHARGE | 131 | 131 | 70 | 1.94 | +2426 | +34.7 |
| BEST FIRST | 63 | 63 | 63 | 1.75 | +3223 | +51.2 |
| KILLS COUNT NEXT TURN | 186 | 186 | 61 | 1.69 | +1174 | +19.3 |
| FACES THE THREAT | 60 | 60 | 60 | 1.67 | +3196 | +53.3 |
| ARTILLERY RE-ROLL WEIGHED | 58 | 58 | 58 | 1.61 | +0 | +0.0 |
| FALLBACK BY WORTH | 197 | 197 | 54 | 1.50 | +1663 | +30.8 |
| MISSILES IN THE MOVE | 277 | 193 | 54 | 1.50 | +968 | +17.9 |
| SHOT REPLANNED | 54 | 54 | 54 | 1.50 | +0 | +0.0 |
| CHARGE LOSSES | 399 | 399 | 49 | 1.36 | +3368 | +68.7 |
| WAIT AFTER COSTS | 254 | 254 | 45 | 1.25 | +806 | +17.9 |
| SHOOTS FROM THE BEST SPOT | 91 | 91 | 44 | 1.22 | +878 | +19.9 |
| RANDOM MOVE BY FIGURES | 78 | 78 | 43 | 1.19 | +1573 | +36.6 |
| ADVANCE LANE KEPT | 42 | 42 | 42 | 1.17 | +0 | +0.0 |
| RISK BY ARC | 143 | 140 | 41 | 1.14 | +1094 | +26.7 |
| HOLDS AMBUSHERS | 40 | 40 | 40 | 1.11 | +0 | +0.0 |
| MARCH CHECK | 42 | 42 | 39 | 1.08 | +986 | +25.3 |
| RISK ONCE | 182 | 132 | 39 | 1.08 | +1591 | +40.8 |
| CANNON PLANNED TARGET | 246 | 246 | 37 | 1.03 | -18 | -0.5 |
| ONE FIGHT FORMULA | 631 | 340 | 36 | 1.00 | +114 | +3.2 |
| CHAFF IN THE MOVE | 51 | 49 | 35 | 0.97 | +1005 | +28.7 |
| FOUR ROUNDS | 111 | 109 | 35 | 0.97 | +2222 | +63.5 |
| KILLS COUNT | 97 | 96 | 35 | 0.97 | +1169 | +33.4 |
| ADVANCE WORTH | 198 | 198 | 34 | 0.94 | +709 | +20.9 |
| LONE WIZARD KEPT IN | 33 | 33 | 33 | 0.92 | +2266 | +68.7 |
| SAFER THAN THE JOB | 33 | 33 | 33 | 0.92 | +1284 | +38.9 |
| WALKS TO THE FIGHT | 63 | 63 | 33 | 0.92 | +190 | +5.7 |
| SCOUT WAITS | 32 | 32 | 32 | 0.89 | +0 | +0.0 |
| COMBAT PIVOT | 27 | 27 | 27 | 0.75 | +0 | +0.0 |
| MODEL FACING | 26 | 26 | 26 | 0.72 | +7348 | +282.6 |
| SHOOTERS IN TWO RANKS | 25 | 25 | 25 | 0.69 | +50 | +2.0 |
| FIVE ACTION | 1741 | 1738 | 24 | 0.67 | +1253 | +52.2 |
| HONEST WORTH | 373 | 372 | 19 | 0.53 | +74 | +3.9 |
| HUNT IN PAIRS | 42 | 28 | 19 | 0.53 | +1373 | +72.2 |
| MANOEUVRE | 31 | 31 | 19 | 0.53 | +566 | +29.8 |
| REDIRECT WEIGHED | 18 | 18 | 18 | 0.50 | +933 | +51.8 |
| WHO HITS BACK | 18 | 18 | 18 | 0.50 | +1072 | +59.6 |
| CHAFF PASSED | 17 | 17 | 17 | 0.47 | -21 | -1.2 |
| CHARGE NOW WEIGHED | 17 | 17 | 17 | 0.47 | +1454 | +85.6 |
| BEST FACING | 16 | 16 | 16 | 0.44 | +310 | +19.4 |
| CASTER AWAY FROM SCREEN | 16 | 16 | 16 | 0.44 | +0 | +0.0 |
| CHARGE NOW FIRST | 119 | 119 | 16 | 0.44 | -809 | -50.6 |
| INVITES THE FIGHT | 43 | 43 | 16 | 0.44 | +115 | +7.2 |
| SET UP TOGETHER | 43 | 36 | 16 | 0.44 | +930 | +58.1 |
| CAST JOB | 35 | 35 | 15 | 0.42 | +146 | +9.7 |
| CASTS FROM BEHIND | 15 | 15 | 15 | 0.42 | +0 | +0.0 |
| MOVE AND CAST | 15 | 15 | 15 | 0.42 | +944 | +62.9 |
| MISSILES NEXT TURN | 325 | 199 | 14 | 0.39 | +116 | +8.3 |
| SHORT GUN FORWARD | 14 | 14 | 14 | 0.39 | +0 | +0.0 |
| STOPS SHORT OF THE FLANK | 14 | 14 | 14 | 0.39 | +396 | +28.3 |
| THROUGH LINE OF FIRE | 14 | 14 | 14 | 0.39 | +301 | +21.5 |
| CASTING BLOCK | 28 | 28 | 13 | 0.36 | +357 | +27.4 |
| ONE OBJECTIVE FORMULA | 204 | 123 | 13 | 0.36 | +278 | +21.4 |
| WEARS DOWN | 64 | 63 | 13 | 0.36 | +393 | +30.2 |
| BLOCKED WHEEL | 12 | 12 | 12 | 0.33 | +504 | +42.0 |
| KEEPS ITS TARGET | 56 | 56 | 12 | 0.33 | +287 | +23.9 |
| BEST PREY | 28 | 28 | 10 | 0.28 | +155 | +15.5 |
| FRIENDS SHOTS CHECKED | 10 | 10 | 10 | 0.28 | +548 | +54.8 |
| LOST CHARGE | 104 | 104 | 10 | 0.28 | +185 | +18.5 |
| MARCH ODDS | 10 | 10 | 10 | 0.28 | +61 | +6.1 |
| REFUSING RETIRES | 21 | 21 | 10 | 0.28 | -3 | -0.3 |
| WAR ENGINE JOBS | 24 | 24 | 10 | 0.28 | -372 | -37.2 |
| WHOLE FIGHT GAIN | 19 | 17 | 10 | 0.28 | +220 | +22.0 |
| BEST OVERALL | 9 | 9 | 9 | 0.25 | +299 | +33.3 |
| PIVOT GUARDS FLANK | 9 | 9 | 9 | 0.25 | -180 | -20.0 |
| STUCK PIVOT | 7 | 7 | 7 | 0.19 | +0 | +0.0 |
| BIG CHARACTER SAFETY | 6 | 6 | 6 | 0.17 | -45 | -7.5 |
| OPENS UP | 14 | 14 | 6 | 0.17 | +381 | +63.5 |
| SURE REACH TOGETHER | 21 | 20 | 6 | 0.17 | +38 | +6.3 |
| GUN MASK | 10 | 10 | 5 | 0.14 | +86 | +17.2 |
| MAKE SURE TOGETHER | 18 | 10 | 5 | 0.14 | +326 | +65.2 |
| SUPPORT NARROWED | 287 | 287 | 5 | 0.14 | -23 | -4.6 |
| AFTERMATH IN POINTS | 4 | 4 | 4 | 0.11 | +383 | +95.8 |
| BEST PRIZE | 4 | 4 | 4 | 0.11 | -175 | -43.8 |
| FEATURE BUFFS | 22 | 22 | 4 | 0.11 | +76 | +18.9 |
| FIRE AND FLEE | 4 | 4 | 4 | 0.11 | +31 | +7.7 |
| KEEPS SCOUTS OR AMBUSH | 4 | 4 | 4 | 0.11 | +0 | +0.0 |
| LONG SHOT | 26 | 26 | 4 | 0.11 | +45 | +11.4 |
| MOVES UNITS SPELL | 4 | 4 | 4 | 0.11 | +122 | +30.4 |
| OVERRUNS AWAY | 27 | 27 | 4 | 0.11 | +58 | +14.6 |
| SURE CHARGE BEATS ADVANCE | 4 | 4 | 4 | 0.11 | -76 | -19.0 |
| BOUND ASSAILMENT | 3 | 3 | 3 | 0.08 | +1 | +0.2 |
| NEEDED THERE | 3 | 3 | 3 | 0.08 | +0 | +0.0 |
| RAIDS THE BAGGAGE NEXT TURN | 3 | 3 | 3 | 0.08 | +185 | +61.7 |
| RESTRAINS TO SHOOT | 3 | 3 | 3 | 0.08 | +40 | +13.3 |
| WHOLE FIGHT | 11 | 10 | 3 | 0.08 | +77 | +25.8 |
| BLOCKED CHARGE SKIPPED | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| EDGE GIVE GROUND | 18 | 18 | 2 | 0.06 | +6 | +2.9 |
| PURSUES BIG PREY | 2 | 2 | 2 | 0.06 | -547 | -273.4 |
| STAY WEIGHED | 2 | 2 | 2 | 0.06 | +15 | +7.5 |
| STOPS | 8 | 8 | 2 | 0.06 | +69 | +34.4 |
| WIDER SPREAD | 148 | 145 | 2 | 0.06 | +12 | +6.0 |
| BACKUP TARGETS | 44 | 28 | 1 | 0.03 | +0 | +0.0 |
| BLOWS WHERE AIMED | 20 | 20 | 1 | 0.03 | +36 | +36.0 |
| BOMBING RUN | 1 | 1 | 1 | 0.03 | +18 | +17.5 |
| CARRIES OUT COUNTER | 2 | 2 | 1 | 0.03 | -42 | -42.3 |
| CARRIES OUT SET-UP | 3 | 3 | 1 | 0.03 | -89 | -88.9 |
| FALL BACK GOOD ORDER | 84 | 84 | 1 | 0.03 | +9 | +9.4 |
| HORN WORTH | 1 | 1 | 1 | 0.03 | +3 | +3.0 |
| KEEP FALLS | 1 | 1 | 1 | 0.03 | +26 | +26.0 |
| MOVE SPELL IN RANGE | 8 | 3 | 1 | 0.03 | +1 | +1.1 |
| NO RALLY LEFT | 1 | 1 | 1 | 0.03 | +81 | +81.2 |
| SCREEN BY WHAT IT SAVES | 15 | 15 | 1 | 0.03 | +14 | +14.1 |
| SPELLS IN THE FIGHT | 41 | 40 | 1 | 0.03 | +48 | +48.0 |
| STANDS TO CAST | 1 | 1 | 1 | 0.03 | -13 | -13.4 |
| TWO OR MORE ARRIVE | 8 | 8 | 1 | 0.03 | +1 | +0.6 |
| ARRIVAL HUNT | 2 | 2 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 34 | 34 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 27 | trace | - | - | - | - |
| CATCH FLIERS | 2 | not checked | - | - | - | - |
| CHARACTER GUNS | 18 | 18 | 0 | 0.00 | - | - |
| CHARGER SLAIN LOST | 23 | 23 | 0 | 0.00 | - | - |
| CHARIOT WIZARD CAREFUL | 1 | 1 | 0 | 0.00 | - | - |
| CHEAP HELPER | 9 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 36 | not checked | - | - | - | - |
| DEFENSIVE ARMY | 5 | 5 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FALLS SHORT | 7 | 7 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 394 | not checked | - | - | - | - |
| GIVES UP | 8 | 8 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 2 | 2 | 0 | 0.00 | - | - |
| GROUND FLIERS | 1 | not checked | - | - | - | - |
| HELPER UNSEEN | 13 | 13 | 0 | 0.00 | - | - |
| HILL BY ITS CHANCE | 12 | 12 | 0 | 0.00 | - | - |
| HUNT ADVANCE | 2 | 2 | 0 | 0.00 | - | - |
| HUNT DROPPED | 1 | trace | - | - | - | - |
| HUNT KEPT | 5 | trace | - | - | - | - |
| HUNT RESULT | 7 | trace | - | - | - | - |
| HUNT THE GUNS | 7 | trace | - | - | - | - |
| JOINT CHARGE PLAN | 2 | 2 | 0 | 0.00 | - | - |
| KEEPS ITS PREY | 2 | 2 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 11 | not checked | - | - | - | - |
| LONE WIZARD HOLDS BACK | 5 | 5 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 6 | 6 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 5 | trace | - | - | - | - |
| MARCH OVER CASTS | 36 | 36 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 10 | 10 | 0 | 0.00 | - | - |
| MOVE SPELL NOT WORTH | 2 | not checked | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 18 | trace | - | - | - | - |
| MOVE SPELL SPOT | 8 | not checked | - | - | - | - |
| NOT NEEDED | 8 | 8 | 0 | 0.00 | - | - |
| NOT TURNED | 232 | 232 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 44 | not checked | - | - | - | - |
| OPENS A LANE | 8 | 3 | 0 | 0.00 | - | - |
| PLAN RESULT | 2932 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 7 | 7 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 27 | 27 | 0 | 0.00 | - | - |
| RUN DOWN | 81 | 79 | 0 | 0.00 | - | - |
| SCOUT SPOT | 28 | 28 | 0 | 0.00 | - | - |
| SECOND HUNTER | 2 | 2 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 7 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 8 | not checked | - | - | - | - |
| SET-UP MISSED | 3 | trace | - | - | - | - |
| SHOOTER COUNTED ONCE | 4 | 4 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 13 | not checked | - | - | - | - |
| SPELL WORTH | 92 | not checked | - | - | - | - |
| STABLE ROLE | 437 | 437 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 19 | 19 | 0 | 0.00 | - | - |
| TIME ON OUR SIDE | 57 | 57 | 0 | 0.00 | - | - |
| TURN WORTH | 11 | 11 | 0 | 0.00 | - | - |
| WAR ENGINE CHARGES | 2 | 2 | 0 | 0.00 | - | - |

### Off best figure: fa-h2h-opp-8a94331-p2

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 15.64 | 1.39 | 38.4 |
| FALLBACK | gate | 0.61 | - | 46.4 |
| TURN GATE | gate | 0.56 | 0.03 | 49.2 |
| CHARGE NOW FIRST | rule | 0.28 | 0.17 | 50.6 |
| AFTERMATH BAND | gate | 0.19 | 0.14 | 2.6 |
| CANNON PLANNED TARGET | rule | 0.25 | 0.03 | 11.9 |
| WAR ENGINE JOBS | rule | 0.28 | - | 37.2 |
| NO REASON | gate | - | 0.25 | 36.6 |
| PIVOT GUARDS FLANK | rule | 0.17 | 0.08 | 20.0 |
| PATHS CROSS | rule | 0.11 | 0.08 | 19.5 |
| CHAFF PASSED | rule | 0.08 | 0.08 | 3.5 |
| BIG CHARACTER SAFETY | rule | 0.14 | - | 9.3 |
| BEST PRIZE | rule | 0.03 | 0.08 | 43.7 |
| FIGHT ORDER BAND | gate | 0.06 | 0.06 | 2.1 |
| SUPPORT NARROWED | rule | 0.03 | 0.08 | 5.7 |
| SURE CHARGE BEATS ADVANCE | rule | 0.11 | - | 19.0 |
| CHARGE NOW WEIGHED | rule | 0.08 | - | 26.6 |
| LONE CHARACTER SAFE SPOT | gate | 0.08 | - | 17.2 |
| STOPS SHORT OF THE FLANK | rule | 0.08 | - | 7.3 |
| BLOCKED WHEEL | rule | 0.06 | - | 17.1 |
| FACES THE THREAT | rule | 0.06 | - | 12.4 |
| MARCH ODDS | rule | - | 0.06 | 3.5 |
| PURSUES BIG PREY | rule | - | 0.06 | 273.4 |
| REFUSING RETIRES | rule | 0.03 | 0.03 | 0.8 |
| RULE SWITCHED OFF | gate | 0.06 | - | 3.4 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.03 | - | 14.3 |
| CARRIES OUT COUNTER | rule | - | 0.03 | 42.3 |
| CARRIES OUT SET-UP | rule | - | 0.03 | 88.9 |
| FOLLOW UP WEIGHED | rule | 0.03 | - | 3.4 |
| REDIRECT WEIGHED | rule | - | 0.03 | 85.4 |
| STANDS TO CAST | rule | - | 0.03 | 13.4 |
| SUPPORT REQUEST | gate | 0.03 | - | 178.7 |
| THROUGH LINE OF FIRE | rule | 0.03 | - | 20.3 |
| WHO HITS BACK | rule | - | 0.03 | 4.1 |

### Plans: fa-h2h-opp-8a94331-p2

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 9.8 | 16% | 150 | 210 | 140% |
| Mine | charge | 2.3 | 62% | 183 | 173 | 94% |
| Mine | close in | 4.9 | 17% | 242 | 142 | 59% |
| Mine | hold | 5.7 | 33% | 366 | 0 | 0% |
| Mine | join | 0.7 | 100% | 24 | 0 | 0% |
| Mine | shoot | 9.0 | 61% | 270 | 754 | 279% |
| Mine | support | 6.2 | 91% | 57 | 0 | 0% |
| Opponent | charge | 2.6 | 56% | 391 | 244 | 62% |
| Opponent | join | 0.9 | 94% | 37 | 0 | 0% |
| Opponent | move | 34.2 | 94% | 1974 | 0 | 0% |
| Opponent | shoot | 4.9 | 59% | 384 | 274 | 71% |
| Opponent | support | 0.2 | 71% | 4 | 0 | 0% |

### Packages: hunt the guns, fa-h2h-opp-8a94331-p2

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.1 | 2 | 0 | 50% | 50% | 0% | 2.0 | 282 | 127 | 50% | 44 |
| Opponent | 0.1 | 5 | 0 | 100% | 100% | 0% | 2.8 | 506 | 384 | 80% | 95 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 102 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 232 |
| Dwarfen Mountain Holds | 0.2 | 1 | 0 | 100% | 100% | 0% | 2.0 | 330 | 253 | 100% | 20 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 25 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 165 |
| High Elf Realms | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 233 | 0 | 0% | 0 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 276 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Ogre Kingdoms | 0.8 | 3 | 0 | 100% | 100% | 0% | 3.3 | 590 | 410 | 67% | 160 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 22 |
| Tomb Kings of Khemri | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 14 |
| Vampire Counts | 0.1 | 1 | 0 | 100% | 100% | 0% | 2.0 | 380 | 369 | 100% | 5 |
| Warriors of Chaos | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 114 |
| Wood Elf Realms | 0.1 | 1 | 0 | 100% | 100% | 0% | 2.0 | 382 | 318 | 100% | 0 |

### Battle groups: fa-h2h-opp-8a94331-p2

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 2.8 | 20% | 65% | 5% | 0% | 11% | 0% | 21% | 63% | 5% |
| Opponent | REDIRECT COUNTER | 3.5 | 25% | 66% | 3% | 0% | 16% | 0% | 6% | 74% | 3% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: fa-h2h-opp-8a94331-p2

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 5 | 0 (5) | 0 | 0 | 16 | 0% | 5.0 | 0 (1) | 0 (4) | - | - | 0 (5) |
| Mine | Chaff | 34 | 55 (34) | 6 | 48 | 56 | 35% | 2.8 | 69 (19) | 61 (7) | 22 (8) | 71 (23) | 19 (11) |
| Mine | Character | 123 | 35 (123) | 35 | 0 | 28 | 26% | 2.4 | 34 (40) | 39 (51) | 45 (13) | 41 (53) | 34 (51) |
| Mine | Clean-up | 21 | 60 (21) | 20 | 40 | 29 | 57% | 2.2 | 29 (5) | 71 (13) | 92 (3) | 95 (13) | 24 (8) |
| Mine | Fast | 1 | 240 (1) | 240 | 0 | 0 | 0% | 6.0 | - | 240 (1) | - | 240 (1) | - |
| Mine | Fast Hammer | 48 | 33 (48) | 18 | 15 | 27 | 25% | 2.8 | 43 (23) | 18 (16) | 20 (9) | 48 (29) | 11 (19) |
| Mine | Fragile | 5 | 52 (5) | 52 | 0 | 60 | 0% | 1.8 | - | 0 (3) | 131 (2) | 52 (5) | - |
| Mine | Hammer | 57 | 38 (57) | 24 | 14 | 38 | 23% | 2.7 | 15 (18) | 55 (29) | 32 (10) | 41 (38) | 32 (19) |
| Mine | Holder | 28 | 51 (28) | 7 | 44 | 30 | 54% | 3.2 | 47 (12) | 65 (9) | 37 (7) | 73 (20) | 3 (8) |
| Mine | Shooter | 41 | 90 (41) | 36 | 54 | 27 | 2% | 1.6 | 146 (5) | 90 (30) | 58 (6) | 129 (25) | 29 (16) |
| Mine | Support | 2 | 0 (2) | 0 | 0 | 0 | 50% | 6.0 | - | 0 (2) | - | - | 0 (2) |
| Mine | War machine | 59 | 48 (59) | 48 | 0 | 40 | 3% | 1.2 | 77 (10) | 48 (37) | 24 (12) | 13 (10) | 55 (49) |
| Mine | Wizard | 22 | 4 (22) | 4 | 0 | 12 | 14% | 2.5 | 1 (9) | 12 (7) | 0 (3) | 9 (8) | 0 (11) |
| Opponent | Blocker | 2 | 0 (2) | 0 | 0 | 100 | 0% | 4.5 | - | 0 (2) | - | 0 (1) | 0 (1) |
| Opponent | Chaff | 76 | 44 (76) | 21 | 22 | 51 | 39% | 2.8 | 58 (32) | 31 (19) | 37 (25) | 62 (54) | 0 (22) |
| Opponent | Character | 97 | 46 (97) | 46 | 0 | 28 | 30% | 2.6 | 44 (43) | 56 (44) | 15 (5) | 42 (60) | 57 (32) |
| Opponent | Clean-up | 19 | 24 (19) | 9 | 15 | 33 | 42% | 3.4 | 2 (9) | 61 (10) | - | 20 (14) | 36 (5) |
| Opponent | Early | 2 | 0 (2) | 0 | 0 | 0 | 50% | 5.0 | - | 0 (2) | - | 0 (1) | 0 (1) |
| Opponent | Fast Hammer | 48 | 23 (48) | 14 | 9 | 34 | 38% | 2.7 | 20 (22) | 15 (16) | 45 (10) | 18 (28) | 32 (20) |
| Opponent | Fragile | 5 | 0 (5) | 0 | 0 | 61 | 60% | 1.5 | - | 0 (3) | 0 (1) | 0 (3) | 0 (1) |
| Opponent | Hammer | 70 | 27 (70) | 24 | 3 | 32 | 36% | 2.8 | 5 (17) | 30 (42) | 46 (11) | 26 (43) | 28 (27) |
| Opponent | Holder | 35 | 85 (35) | 4 | 80 | 19 | 40% | 3.4 | 108 (5) | 96 (22) | 39 (7) | 119 (21) | 37 (13) |
| Opponent | Shooter | 33 | 75 (33) | 11 | 64 | 27 | 0% | 1.7 | 69 (8) | 81 (19) | 61 (6) | 114 (22) | 15 (11) |
| Opponent | Support | 3 | 0 (3) | 0 | 0 | 50 | 67% | 3.0 | 0 (1) | 0 (1) | 0 (1) | - | 0 (3) |
| Opponent | War machine | 24 | 56 (24) | 56 | 0 | 12 | 4% | 1.7 | 116 (6) | 37 (14) | 45 (4) | 0 (3) | 64 (21) |
| Opponent | Wizard | 26 | 22 (26) | 22 | 0 | 27 | 4% | 1.8 | 0 (9) | 9 (8) | 16 (5) | 12 (7) | 4 (15) |

### Charged fights: fa-h2h-opp-8a94331-p2

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 50 | 227 | 1.8 | 1.0 | 130 | 0 | +130 | 2 of 7 | 6 of 7 | - | +130 |
| Mine | Chaos Dwarfs | 4 | 181 | 248 | 2.2 | 1.0 | 110 | 24 | +86 | 2 of 9 | 8 of 9 | - | +86 |
| Mine | Dwarfen Mountain Holds | 4 | 1047 | 94 | 2.0 | 1.5 | 47 | 0 | +47 | 0 of 8 | 7 of 8 | +46 | +47 |
| Mine | Empire of Man | 5 | 399 | 41 | 1.0 | 1.0 | 41 | 53 | -12 | 2 of 5 | 4 of 5 | - | -12 |
| Mine | Grand Cathay | 4 | 267 | 278 | 3.2 | 1.0 | 86 | 56 | +30 | 3 of 13 | 9 of 12 | - | +30 |
| Mine | High Elf Realms | 4 | 109 | 525 | 3.5 | 1.0 | 150 | 11 | +139 | 5 of 14 | 11 of 14 | - | +139 |
| Mine | Kingdom of Bretonnia | 1 | 30 | 410 | 2.0 | 1.0 | 205 | 0 | +205 | 0 of 2 | 2 of 2 | - | +205 |
| Mine | Lizardmen | 1 | 0 | 120 | 2.0 | 1.0 | 60 | 0 | +60 | 0 of 2 | 2 of 2 | - | +60 |
| Mine | Ogre Kingdoms | 1 | 261 | 95 | 4.0 | 1.0 | 24 | 8 | +15 | 1 of 4 | 2 of 4 | - | +15 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 399 | 5.0 | 1.2 | 80 | 11 | +69 | 1 of 5 | 4 of 5 | +45 | +75 |
| Mine | Skaven | 2 | 143 | 0 | 2.0 | 1.0 | 0 | 150 | -150 | 2 of 4 | 2 of 4 | - | -150 |
| Mine | Tomb Kings of Khemri | 1 | 102 | 432 | 2.0 | 1.0 | 216 | 0 | +216 | 1 of 2 | 2 of 2 | - | +216 |
| Mine | Vampire Counts | 3 | 0 | 186 | 3.7 | 1.1 | 51 | 49 | +2 | 3 of 11 | 9 of 11 | +0 | +2 |
| Mine | Warriors of Chaos | 1 | 19 | 0 | 1.0 | 1.0 | 0 | 207 | -207 | 0 of 1 | 0 of 1 | - | -207 |
| **Mine** | all armies | 36 | 259 | 214 | 2.4 | 1.1 | 89 | 32 | +56 | 22 of 87 | 68 of 86 | +36 | +58 |
| Opponent | Dwarfen Mountain Holds | 2 | 374 | 28 | 1.0 | 1.0 | 28 | 0 | +28 | 0 of 2 | 2 of 2 | - | +28 |
| Opponent | Empire of Man | 2 | 508 | 46 | 0.5 | 1.0 | 91 | 0 | +91 | 0 of 1 | 1 of 1 | - | +91 |
| Opponent | Grand Cathay | 2 | 286 | 247 | 1.5 | 1.0 | 165 | 0 | +165 | 1 of 3 | 3 of 3 | - | +165 |
| Opponent | Kingdom of Bretonnia | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Ogre Kingdoms | 3 | 302 | 198 | 2.3 | 1.1 | 85 | 5 | +80 | 2 of 7 | 3 of 7 | +330 | +38 |
| Opponent | Skaven | 1 | 125 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Tomb Kings of Khemri | 4 | 107 | 746 | 2.8 | 1.2 | 271 | 83 | +189 | 6 of 11 | 7 of 11 | -32 | +238 |
| Opponent | Vampire Counts | 6 | 0 | 262 | 1.8 | 1.0 | 143 | 0 | +143 | 8 of 11 | 8 of 11 | - | +143 |
| Opponent | Warriors of Chaos | 8 | 22 | 207 | 1.9 | 1.1 | 111 | 8 | +103 | 4 of 15 | 10 of 15 | +120 | +102 |
| Opponent | Wood Elf Realms | 7 | 100 | 561 | 4.4 | 1.1 | 127 | 23 | +103 | 12 of 31 | 24 of 31 | +154 | +98 |
| **Opponent** | all armies | 36 | 130 | 316 | 2.2 | 1.1 | 140 | 22 | +118 | 33 of 81 | 58 of 81 | +121 | +118 |

### Effective charges: fa-h2h-opp-8a94331-p2

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 7 | 1 (net +0) | 0 | 0 | 2 (net +82) | 0 | 1 (net +233) | 3 | 0% (0 of 4) |
| Mine | Chaos Dwarfs | 9 | 2 (net +208) | 0 | 2 (net +42) | 0 | 4 (net +5) | 1 (net +254) | 0 | 22% (2 of 9) |
| Mine | Dwarfen Mountain Holds | 8 | 3 (net +69) | 0 | 1 (net +0) | 1 (net +0) | 0 | 2 (net +68) | 1 | 14% (1 of 7) |
| Mine | Empire of Man | 5 | 0 | 0 | 1 (net +0) | 3 (net -51) | 0 | 1 (net +92) | 0 | 20% (1 of 5) |
| Mine | Grand Cathay | 13 | 0 | 0 | 1 (net -205) | 3 (net -131) | 4 (net +57) | 3 (net +254) | 2 | 9% (1 of 11) |
| Mine | High Elf Realms | 14 | 0 | 1 (net +492) | 4 (net +8) | 3 (net +104) | 1 (net +126) | 4 (net +246) | 1 | 31% (4 of 13) |
| Mine | Kingdom of Bretonnia | 2 | 0 | 0 | 1 (net +205) | 0 | 0 | 1 (net +205) | 0 | 50% (1 of 2) |
| Mine | Lizardmen | 2 | 0 | 0 | 1 (net +45) | 0 | 0 | 0 | 1 | 100% (1 of 1) |
| Mine | Ogre Kingdoms | 4 | 0 | 0 | 0 | 0 | 0 | 1 (net +50) | 3 | 0% (0 of 1) |
| Mine | Orc & Goblin Tribes | 5 | 0 | 0 | 1 (net +45) | 0 | 0 | 2 (net +147) | 2 | 33% (1 of 3) |
| Mine | Skaven | 4 | 1 (net -392) | 0 | 1 (net +0) | 0 | 0 | 2 (net -105) | 0 | 25% (1 of 4) |
| Mine | Tomb Kings of Khemri | 2 | 0 | 0 | 0 | 0 | 0 | 2 (net +216) | 0 | 0% (0 of 2) |
| Mine | Vampire Counts | 11 | 2 (net -140) | 0 | 2 (net +172) | 2 (net +0) | 1 (net +110) | 3 (net -85) | 1 | 20% (2 of 10) |
| Opponent | Dwarfen Mountain Holds | 2 | 0 | 0 | 0 | 1 (net +0) | 0 | 1 (net +55) | 0 | 0% (0 of 2) |
| Opponent | Empire of Man | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +91) | 0 | 0% (0 of 1) |
| Opponent | Grand Cathay | 3 | 0 | 0 | 1 (net +95) | 2 (net +200) | 0 | 0 | 0 | 33% (1 of 3) |
| Opponent | Ogre Kingdoms | 7 | 3 (net +140) | 0 | 0 | 0 | 0 | 0 | 4 | 0% (0 of 3) |
| Opponent | Tomb Kings of Khemri | 11 | 1 (net -431) | 1 (net +310) | 2 (net +198) | 4 (net +122) | 0 | 3 (net +438) | 0 | 18% (2 of 11) |
| Opponent | Vampire Counts | 11 | 3 (net +205) | 2 (net +150) | 2 (net +180) | 1 (net +0) | 1 (net +0) | 1 (net +293) | 1 | 20% (2 of 10) |
| Opponent | Warriors of Chaos | 15 | 1 (net +0) | 2 (net +379) | 1 (net +0) | 2 (net -36) | 2 (net +40) | 3 (net +149) | 4 | 9% (1 of 11) |
| Opponent | Wood Elf Realms | 31 | 4 (net +56) | 0 | 5 (net +263) | 8 (net +55) | 0 | 9 (net +102) | 5 | 19% (5 of 26) |

### Charged fights, damage counted: fa-h2h-opp-8a94331-p2

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 9 | 144 | 224 | -5 | 113 | 86 | +27 | +18.8 |
| Mine | 50-54% | 1 | 497 | 201 | +492 | 492 | 248 | +244 | +49.0 |
| Mine | Effective (55-75%) | 15 | 254 | 214 | +37 | 95 | 47 | +47 | +18.7 |
| Mine | 76-89% | 14 | 230 | 158 | -5 | 94 | 85 | +9 | +4.0 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 23 | 202 | 170 | +130 | 168 | 43 | +125 | +62.1 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 10 | 323 | 82 | +48 | 86 | 28 | +58 | +17.8 |
| Mine | No odds | 15 | 308 | 152 | +35 | 70 | 46 | +24 | +7.8 |
| Mine | All fights | 87 | 245 | 168 | +56 | 115 | 56 | +59 | +24.1 |
| Opponent | Long shot (under 50%) | 12 | 237 | 258 | +69 | 209 | 104 | +105 | +44.4 |
| Opponent | 50-54% | 5 | 358 | 269 | +274 | 312 | 18 | +294 | +82.0 |
| Opponent | Effective (55-75%) | 11 | 310 | 226 | +197 | 217 | 40 | +178 | +57.3 |
| Opponent | 76-89% | 18 | 237 | 147 | +70 | 109 | 33 | +76 | +31.9 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 18 | 300 | 193 | +173 | 209 | 34 | +175 | +58.1 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 3 | 347 | 84 | +27 | 45 | 17 | +28 | +8.1 |
| Opponent | No odds | 14 | 260 | 196 | +55 | 88 | 30 | +58 | +22.3 |
| Opponent | All fights | 81 | 277 | 198 | +118 | 167 | 43 | +125 | +45.0 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| fa-h2h-opp-8a94331-p2 | move | 382 | 76 (20%) | 50 (13%) | 34 (9%) | 272 (71%) |
| fa-h2h-opp-8a94331-p2 | objective | 178 | 16 (9%) | 12 (7%) | 21 (12%) | 141 (79%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0106, L0122, L2429, L2535, L2735 |
| Charmed Shield | Opponent | L0425, L0827, L0934, L1026, L1727, L1827, L1927 |
| Clockwork Compass | Mine | L1228 |
| Clockwork Compass | Opponent | L0512 |
| Elixir of Power | Mine | L1118, L1135, L1927 |
| Fistful of Laurels | Mine | L1827 |
| Fistful of Laurels | Opponent | L0918, L1118, L1418 |
| Horn of the Wild Hunt | Opponent | L3033 |
| Invocation of Nehek | Mine | L2429, L2535, L2735 |
| Invocation of Nehek | Opponent | L0425, L0827, L1727, L1827, L1927 |
| Opal Amulet | Mine | L1418, L1435 |
| Periapt of Soul Exchange | Mine | L2029, L2131 |
| Periapt of Soul Exchange | Opponent | L0721 |
| Ring of Doom | Mine | L0206, L0222, L1118, L1135, L1228, L1531 |
| Ring of Doom | Opponent | L0512, L1531, L2131, L3033 |
| Ring of Jet | Mine | L1026, L1118, L1135, L1228 |
| Ring of Jet | Opponent | L0512, L0810 |
| Standard of the Fell Warrior | Mine | L1323 |
| Storm Daemon (Renegade 2.0) | Mine | L2131 |
| Storm Daemon (Renegade 2.0) | Opponent | L0721 |
| Twice-Blessed Armour | Mine | L0721, L1026 |
| Twice-Blessed Armour | Opponent | L0307, L0810 |
| Witch Hunter's Ward | Mine | L0721, L0810, L0827 |
| Witch Hunter's Ward | Opponent | L0307 |

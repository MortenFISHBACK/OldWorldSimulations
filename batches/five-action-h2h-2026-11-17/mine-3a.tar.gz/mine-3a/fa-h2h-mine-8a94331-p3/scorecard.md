# Doctrine scorecard: fa-h2h-mine-8a94331-p3

### Scorecard: fa-h2h-mine-8a94331-p3

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0110 | 2 | 1 | Mine | - | - | 2 | 0 | 2 | 0 | 0 | 0 | 0 |
| L0110 | 2 | 1 | Opponent | - | - | 4 | 2 | 1 | 0 | 0 | 0 | 330 |
| L0126 | 6 | 1 | Mine | no | 3 | - | 0 | 1 | 0 | 0 | 0 | 65 |
| L0126 | 6 | 1 | Opponent | no | 22 | 2 | 1 | 1 | 0 | 0 | 0 | 0 |
| L0210 | 6 | 1 | Mine | no | 0 | 3 | 1 | 4 | 0 | 0 | 0 | 0 |
| L0210 | 6 | 1 | Opponent | no | 5 | 4 | 2 | 0 | 0 | 0 | 0 | 330 |
| L0226 | 4 | 1 | Mine | no | 0 | - | 0 | 8 | 0 | 0 | 0 | 170 |
| L0226 | 4 | 1 | Opponent | no | 6 | 2 | 2 | 5 | 0 | 0 | 0 | 0 |
| L0311 | 5 | 1 | Mine | no | - | - | 1 | 3 | 0 | 0 | 0 | 110 |
| L0311 | 5 | 1 | Opponent | yes | - | 5 | 1 | 0 | 1 | 0 | 0 | 330 |
| L0327 | 3 | 1 | Mine | yes | 7 | 3 | 1 | 0 | 0 | 0 | 0 | 0 |
| L0327 | 3 | 1 | Opponent | no | 8 | 2 | 2 | 4 | 1 | 0 | 0 | 0 |
| L0413 | 5 | 1 | Mine | yes | - | 2 | 3 | 2 | 1 | 0 | 0 | 0 |
| L0413 | 5 | 1 | Opponent | yes | - | 2 | 2 | 1 | 0 | 0 | 0 | 140 |
| L0429 | 3 | 1 | Mine | yes | 2 | 3 | 2 | 2 | 0 | 0 | 0 | 139 |
| L0429 | 3 | 1 | Opponent | no | 1 | 2 | 4 | 2 | 0 | 0 | 0 | 0 |
| L0516 | 6 | 1 | Mine | no | 4 | - | 0 | 1 | 0 | 0 | 0 | 1275 |
| L0516 | 6 | 1 | Opponent | no | 9 | 2 | 1 | 0 | 1 | 0 | 0 | 477 |
| **Average** | | | Mine | 38% | 2.7 | 2.6 | 0.9 | 2.6 | 0.1 | 0.0 | 0.0 | 195.4 |
| **Average** | | | Opponent | 25% | 8.5 | 2.8 | 1.9 | 1.6 | 0.3 | 0.0 | 0.0 | 178.6 |

### KPIs: fa-h2h-mine-8a94331-p3

Rules off - Opponent only: FIVE ACTION, LIKELY CHARGE, FALLS SHORT, TIME ON OUR SIDE, FEATURE BUFFS, GETS AWAY CHANCE, GUN MASK, RUN DOWN, FOUR ROUNDS, CHARGE LOSSES, CHARACTER GUNS, STAND AND SHOOT, FALL BACK GOOD ORDER, AFTERMATH IN POINTS.

Morten 2026-11-10; 9 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 22% (9 of 40) | 11% (5 of 45) | 16% (14 of 85) |
| Winner chose to follow up after the loser gave ground |  | 90% (9 of 10); on the table 90% | 100% (16 of 16); on the table 100% | 96% (25 of 26); on the table 96% |
| Winner chose to pursue after the loser fell back in good order |  | 100% (1 of 1); on the table 100% | 100% (4 of 4); on the table 100% | 100% (5 of 5); on the table 100% |
| Winner chose to pursue after the loser fled |  | 100% (2 of 2); on the table 100% | 91% (10 of 11); on the table 91% | 92% (12 of 13); on the table 92% |
| Winner chose to follow up or pursue (all three) |  | 92% (12 of 13); on the table 92% | 97% (30 of 31); on the table 97% | 95% (42 of 44); on the table 95% |
| Magic missiles tried each own turn | 50%+ | 39% (51 of 132) | 48% (52 of 108) | 43% (103 of 240) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 47% (51 of 109) | 56% (52 of 93) | 51% (103 of 202) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 40% (2 of 5) | 50% (3 of 6) | 45% (5 of 11) |
| Points that never fought | lower | 51% (8990 of 17594) | 51% (9129 of 17996) | 51% (18119 of 35590) |
|   infantry points that never fought | lower | 53% (2727 of 5100) | 73% (2473 of 3409) | 61% (5200 of 8509) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 67% (41 of 61) | 48% (31 of 65) | 57% (72 of 126) |
| Bound items with a magic missile used (at least once a game) |  | 100% (6 of 6); 2.8 uses a game | 86% (6 of 7); 2.2 uses a game | 92% (12 of 13); 2.5 uses a game |
| Bound items with another spell used |  | 100% (2 of 2); 0.6 uses a game | 50% (2 of 4); 0.3 uses a game | 67% (4 of 6); 0.4 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 88% (7 of 8); 0.8 uses a game | 25% (1 of 4); 0.1 uses a game | 67% (8 of 12); 0.4 uses a game |
|   their share of the points of units over 100 pts | lower | 66% (8935 of 13520) | 41% (6605 of 16265) | 52% (15540 of 29785) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 3.4 (38%) | 2.3 (38%) | 5.8 (38%) |
| MARCHED: its unit marched | 1.6 (17%) | 1.8 (29%) | 3.3 (22%) |
| CHARGED: its unit charged | 0.3 (4%) | 0.4 (7%) | 0.8 (5%) |
| IN COMBAT: engaged in combat | 1.3 (15%) | 0.8 (12%) | 2.1 (14%) |
| GONE: slain | 0.3 (4%) | 0.9 (14%) | 1.2 (8%) |
| OFF THE TABLE: off the table or not arrived | 0.9 (10%) | 0.0 (0%) | 0.9 (6%) |
| STUPIDITY: Stupidity | 0.9 (10%) | 0.0 (0%) | 0.9 (6%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.2 (2%) | 0.0 (0%) | 0.2 (1%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 5.4 | 1.6 | 3.3 | 11.4 | 1.3 | 1.0 |
| not cast | 4.6 | 1.8 | 6.0 | 15.2 | 2.0 | 21.7 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.0 (5%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.9 (50%) | 0.9 (15%) | 5.8 (38%) | 0.7 (33%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 3.3 (22%) | 0.1 (6%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.8 (5%) | 0.1 (6%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.6 (12%) | 0.2 (12%) | 1.2 (20%) | 2.1 (14%) | 0.3 (17%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (1%) |
| GONE: slain | 0.9 (20%) | 0.3 (19%) | 0.0 (0%) | 1.2 (8%) | 0.3 (17%) | 1.4 (7%) |
| OFF THE TABLE: off the table or not arrived | 0.3 (7%) | 0.1 (6%) | 0.1 (2%) | 0.9 (6%) | 0.0 (0%) | 0.2 (1%) |
| STUPIDITY: Stupidity | 0.1 (2%) | 0.0 (0%) | 0.4 (7%) | 0.9 (6%) | 0.0 (0%) | 0.4 (2%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (2%) | 0.0 (0%) | 0.0 (0%) | 0.2 (1%) | 0.4 (22%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.6 (56%) | 0.2 (12%) | 3.3 (56%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 18.3 (85%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 3.4 a game | 0.4 a game | 1.9 a game |
| stood (cast and not dispelled) | 71% (22 of 31) | 75% (3 of 4) | 71% (25 of 35) |
| the unit moved after it | 73% (16 of 22) | 100% (3 of 3) | 76% (19 of 25) |
| it charged on its next turn | 0% (0 of 22) | 33% (1 of 3) | 4% (1 of 25) |
| the enemy charged it first | 5% (1 of 22) | 33% (1 of 3) | 8% (2 of 25) |
| it fought by the end of its next turn | 5% (1 of 22) | 33% (1 of 3) | 8% (2 of 25) |
| it moved out of a charge the enemy had planned (not charged first) | 55% (12 of 22) | 33% (1 of 3) | 52% (13 of 25) |
| none of these (no charge, no fight, no charge escaped) | 41% (9 of 22) | 0% (0 of 3) | 36% (9 of 25) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 66% (111 of 168) | 70% (78 of 112) | 68% (189 of 280) |
|   cavalry | 55% (6 of 11) | 27% (3 of 11) | 41% (9 of 22) |
|   character | 91% (21 of 23) | 29% (4 of 14) | 68% (25 of 37) |
|   chariot | 29% (12 of 41) | 78% (14 of 18) | 44% (26 of 59) |
|   infantry | 82% (23 of 28) | 78% (18 of 23) | 80% (41 of 51) |
|   war machine | 75% (49 of 65) | 85% (39 of 46) | 79% (88 of 111) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.7 (26%) | 1.3 (35%) | 3.0 (30%) |
| CHARGED: it charged | 0.6 (9%) | 0.7 (18%) | 1.2 (12%) |
| FLEEING: it fled or was fleeing | 0.0 (0%) | 0.1 (3%) | 0.1 (1%) |
| IN COMBAT: it fought this turn or the last | 1.1 (18%) | 0.4 (12%) | 1.6 (15%) |
| MOVED: a war machine that moved | 1.3 (21%) | 0.0 (0%) | 1.3 (13%) |
| NO TARGET IN RANGE | 0.7 (11%) | 0.4 (12%) | 1.1 (11%) |
| ONLY IN COMBAT: the only targets were in combat | 0.3 (5%) | 0.0 (0%) | 0.3 (3%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.3 (5%) | 0.0 (0%) | 0.3 (3%) |
| SHELTERED: the target was sheltered | 0.1 (2%) | 0.3 (9%) | 0.4 (4%) |
| OTHER BAR | 0.2 (4%) | 0.4 (12%) | 0.7 (7%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 1.1 | 0.6 | 70% | 4.6 pts | 5 pts |
| character | 3.7 | 1.7 | 73% | 8.6 pts | 31 pts |
| chariot | 2.9 | 1.1 | 69% | 8.3 pts | 24 pts |
| infantry | 7.9 | 3.0 | 73% | 11.7 pts | 92 pts |
| war machine | 9.8 | 9.9 | 61% | 31.4 pts | 307 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 1.9 | 4.4 | 3.2 |
| Charges that made contact a game | 1.4 | 3.0 | 2.2 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.17 declared, 0.00 contact (6 units) | 0.50 declared, 0.33 contact (12 units) | 0.39 declared, 0.22 contact (18 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 0.75 declared, 0.75 contact (4 units) | 0.75 declared, 0.75 contact (4 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.27 declared, 0.22 contact (60 units) | 0.62 declared, 0.40 contact (50 units) | 0.43 declared, 0.30 contact (110 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 30% (3 of 10) | 100% (2 of 2) | 50% (1 of 2) | 43% (6 of 14) |
| Character in a unit | 62% (8 of 13) | 88% (7 of 8) | - | 71% (15 of 21) |
| Character on its own | 100% (4 of 4) | 42% (5 of 12) | 43% (6 of 14) | 50% (15 of 30) |
| Chariot | 100% (3 of 3) | 38% (3 of 8) | - | 55% (6 of 11) |
| Infantry | 62% (8 of 13) | 50% (7 of 14) | 0% (0 of 2) | 52% (15 of 29) |
| Monster | 60% (3 of 5) | - | - | 60% (3 of 5) |
| Monstrous | - | 50% (1 of 2) | - | 50% (1 of 2) |
| War Machines | 83% (10 of 12) | 50% (1 of 2) | - | 79% (11 of 14) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 100% (5 of 5); on the table 100% | 34% (33 of 96) | 58% | 73% (16 of 22) | 100% (6 of 6); 6.2 uses a game | 100% (2 of 2); 1.2 uses a game | 83% (5 of 6); 1.2 uses a game |
| Chaos Dwarfs | 4 | 86% (6 of 7); on the table 86% | 50% (18 of 36) | 44% | 66% (21 of 32) | 0.0 uses a game | 0.0 uses a game | 100% (2 of 2); 0.5 uses a game |
| Dwarfen Mountain Holds | 1 | 100% (1 of 1); on the table 100% | - | 54% | 57% (4 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Grand Cathay | 3 | 100% (3 of 3); on the table 100% | 51% (40 of 78) | 69% | 54% (15 of 28) | 83% (5 of 6); 4.7 uses a game | 50% (1 of 2); 0.3 uses a game | 33% (1 of 3); 0.3 uses a game |
| High Elf Realms | 1 | 100% (7 of 7); on the table 100% | 50% (3 of 6) | 26% | 62% (5 of 8) | 100% (1 of 1); 6.0 uses a game | 50% (1 of 2); 2.0 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | - | - | 71% | 50% (3 of 6) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Vampire Counts | 3 | 100% (14 of 14); on the table 100% | 38% (9 of 24) | 44% | 38% (6 of 16) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 1 | 86% (6 of 7); on the table 86% | - | 22% | 29% (2 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (fa-h2h-mine-8a94331-p3, 9 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 50% (9) | 56% (5) | 52% (14) |
| ...free all their last turn and able to turn (per game) | 0.78 | 0.22 | 1.00 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.11 | 0.11 | 0.22 |
| ...with the charger already in that arc before they moved (per game) | 0.78 | 0.11 | 0.89 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 1.78 | 1.78 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.67 | 0.67 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.11 | 4.78 | 4.89 |

### Quality by phase: fa-h2h-mine-8a94331-p3

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.8 | 4.9 |
| Strategy | Charge objectives carried out (made contact) | 30% (6 of 20) | 39% (14 of 36) |
| Strategy | Shoot objectives carried out (shot that target) | 39% (39 of 100) | 49% (34 of 69) |
| Strategy | Close-in objectives charged next turn | - | 8% (6 of 77) |
| Strategy | Support requests answered (helper made contact too) | 100% (1 of 1) | 60% (3 of 5) |
| Strategy | Hexes on a unit its side charged or shot that turn | 100% (1 of 1) | 25% (1 of 4) |
| Strategy | Joined characters whose unit fought | 35% (9 of 26) | 33% (2 of 6) |
| Strategy | Lone characters that fought | 67% (10 of 15) | 60% (15 of 25) |
| Movement | Charges halted short of contact | 0.0 | 0.3 |
| Movement | Idle units | 2.6 | 1.6 |
| Movement | Points that never moved of their own | 195.4 | 178.6 |
| Movement | Fights charged into per game | 1.3 | 2.6 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 12 | 4 of 21, net -90 |
| Movement | Charges with odds: sweet spot (55-75%) | 4 of 12, net +49 | 3 of 21, net +78 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 12 | 3 of 21, net +100 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 5 of 12, net +68 | 6 of 21, net +135 |
| Shooting | Shots by shooting units (incl. breath weapons) | 6.9 | 4.8 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 65% (40 of 62) | 65% (28 of 43) |
| Shooting | Points destroyed by shooting units | 25.9 | 80.0 |
| Shooting | War machine shots | 5.4 | 4.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 35% (17 of 49) | 59% (23 of 39) |
| Shooting | Points destroyed by war machines | 96.8 | 23.6 |
| Magic | Magic missiles cast | 3.8 | 4.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 41% (14 of 34) | 23% (9 of 39) |
| Magic | Wounds caused by magic missiles | 6.2 | 5.7 |
| Magic | Wounds caused by other spells | - | 1.2 |
| Magic | Points destroyed by magic (all spells) | 119.4 | 46.8 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.4 / 0.1 / 0.1 / 0.1 | 1.9 / 0.4 / 0.2 / 0.4 |
| Combat | Points destroyed in combat | 210.7 | 181.9 |
| Combat | Points run down | 22.8 | 97.0 |
| Combat | Net points per charged fight, damage counted | +42 | +67 |
| Combat | Net per 100 charger points, damage counted | +18.1 | +19.5 |
| Combat | First round won (charged fights) | 75% | 96% |
| Combat | Net points per charged fight | +22 | +60 |
| Combat | Net points per supported fight / lone fight | +0 / +24 | +322 / +20 |
| Combat | Charged fights on a top-3 enemy unit | 4 of 12 | 9 of 23 |
| Game | Points lost | 562.1 | 483.9 |
| Game | VP from objectives | 501.1 | 678.9 |
| Game | Lone holders (player turns) | 2.7 | 8.5 |

- Mine won / drew / lost: 2 / 1 / 6 of 9 ended games (of 9); mean margin (Mine - Opponent) -266 VP
- The side that went first won 6 of 8 games with a winner
- Points traded per game (both sides' losses): 1046
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: fa-h2h-mine-8a94331-p3

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.2 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| ADVANCE WORTH | - | - | - | - | 3.6 | -98.2 | 128.3 | 78.7 |
| AFTERMATH IN POINTS | 0.1 | +21.8 | 0.0 | 0.0 | - | - | - | - |
| ALREADY CARRIED | 0.2 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARTILLERY RE-ROLL WEIGHED | 2.4 | +0.0 | 0.0 | 31.7 | 0.7 | +0.0 | 0.0 | 73.3 |
| BACKUP TARGETS | 0.2 | +0.4 | 0.0 | 64.4 | 0.2 | +1.1 | 0.0 | 0.0 |
| BEST FACING | - | - | - | - | 0.4 | +0.2 | 0.0 | 25.9 |
| BEST FIRST | - | - | - | - | 0.7 | +26.4 | 21.0 | 60.7 |
| BEST OVERALL | - | - | - | - | 0.1 | +26.8 | 0.0 | 0.0 |
| BEST PREY | - | - | - | - | 0.6 | +16.3 | 0.0 | 0.0 |
| BEST PRIZE | - | - | - | - | 0.2 | -4.3 | 16.7 | 0.0 |
| BIG CHARACTER SAFETY | - | - | - | - | 0.4 | -3.4 | 0.0 | 41.0 |
| BLOCKED WHEEL | - | - | - | - | 0.1 | +4.1 | 0.0 | 0.0 |
| BLOWS WHERE AIMED | - | - | - | - | 0.1 | -3.9 | 35.8 | 0.0 |
| CANNON PLAN MISSED | 1.0 | +0.0 | 65.0 | 0.0 | 0.1 | +0.0 | 15.6 | 0.0 |
| CANNON PLANNED TARGET | 4.8 | +57.2 | 386.8 | 66.7 | 2.8 | +212.9 | 72.4 | 121.1 |
| CANNON SIGHT KEPT | 1.0 | +0.0 | 0.0 | 0.0 | 0.9 | +0.0 | 0.0 | 30.8 |
| CARRIES OUT SET-UP | - | - | - | - | 0.2 | -0.9 | 48.0 | 0.0 |
| CAST JOB | 1.3 | +40.8 | 140.9 | 0.0 | 1.0 | +27.3 | 37.4 | 59.0 |
| CASTER AWAY FROM SCREEN | 0.4 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CASTING BLOCK | 0.3 | +51.2 | 36.3 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | 1.9 | +0.0 | 0.0 | 39.4 | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | - | - | - | - | 0.2 | +0.0 | 0.0 | 0.0 |
| CATCH ODDS | 0.1 | +0.3 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | 0.2 | +2.5 | 0.0 | 0.0 | 0.9 | +38.2 | 0.0 | 10.0 |
| CHAFF PASSED | 0.2 | -0.1 | 0.0 | 0.0 | - | - | - | - |
| CHARACTER GUNS | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHARGE LOSSES | 11.6 | -562.8 | 0.0 | 288.8 | - | - | - | - |
| CHARGE NOW FIRST | 1.2 | +0.0 | 177.4 | 43.9 | 3.1 | +0.0 | 182.7 | 121.7 |
| CHARGE NOW WEIGHED | - | - | - | - | 0.7 | -56.4 | 35.8 | 30.3 |
| CHARGER SLAIN LOST | 0.1 | -0.8 | 18.3 | 5.8 | 0.2 | -1.6 | 0.0 | 10.6 |
| CHARIOT WIZARD CAREFUL | - | - | - | - | 0.3 | +0.0 | 21.0 | 0.0 |
| COMBAT PIVOT | 0.7 | +0.0 | 63.4 | 37.8 | 0.4 | +0.0 | 34.4 | 0.0 |
| CONVEYANCE SEARCH | 2.7 | +343.6 | 35.8 | 39.4 | - | - | - | - |
| COVER ONCE | 10.7 | -1177.5 | 0.0 | 216.7 | 6.3 | -250.0 | 0.0 | 100.2 |
| DEFENSIVE FLOOR | 0.1 | +2.8 | 0.0 | 0.0 | - | - | - | - |
| EDGE GIVE GROUND | 0.1 | +5.0 | 18.3 | 5.8 | - | - | - | - |
| ENGINEER BY LORE | 0.4 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | - | - | - | - | 1.8 | +180.1 | 0.0 | 25.9 |
| FALL BACK GOOD ORDER | 1.1 | +0.0 | 225.1 | 43.9 | - | - | - | - |
| FALLBACK BY WORTH | - | - | - | - | 5.1 | +28.8 | 0.0 | 41.0 |
| FEATURE BUFFS | 3.4 | +127.4 | 0.0 | 19.4 | - | - | - | - |
| FIGHT LIFT | 0.1 | +1.8 | 0.0 | 0.0 | - | - | - | - |
| FIVE ACTION | 43.0 | +2314.9 | 1384.3 | 543.0 | - | - | - | - |
| FLANK NOT WEIGHED | 7.1 | +0.0 | 0.0 | 157.9 | 3.9 | +0.0 | 0.0 | 36.0 |
| FOLLOW UP WEIGHED | 0.9 | +176.5 | 0.0 | 9.4 | 1.0 | +184.8 | 0.0 | 0.0 |
| FOUR ROUNDS | 2.2 | +129.3 | 291.8 | 49.7 | - | - | - | - |
| FRIENDS SHOTS CHECKED | 0.2 | +26.4 | 0.0 | 34.4 | 0.2 | +9.4 | 0.0 | 0.0 |
| GIVES UP | 0.1 | -2.2 | 0.0 | 0.0 | 0.2 | -4.3 | 0.0 | 0.0 |
| GUN MASK | 0.2 | -0.7 | 0.0 | 0.0 | - | - | - | - |
| HELPER ALREADY ASKED | - | - | - | - | 0.3 | +0.0 | 62.9 | 0.0 |
| HELPER UNSEEN | - | - | - | - | 0.2 | +0.0 | 18.9 | 0.0 |
| HILL BY ITS CHANCE | - | - | - | - | 0.9 | -157.2 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 1.8 | -34.0 | 240.1 | 49.7 | 11.7 | -225.7 | 486.8 | 206.6 |
| HUNT ADVANCE | - | - | - | - | 0.2 | +0.3 | 0.0 | 0.0 |
| HUNT DROPPED | - | - | - | - | 0.1 | +0.0 | 0.0 | 0.0 |
| HUNT IN PAIRS | 0.2 | +0.9 | 0.0 | 37.7 | 1.6 | +164.9 | 0.0 | 0.0 |
| HUNT KEPT | 0.2 | +3.9 | 36.7 | 0.0 | 0.2 | +0.1 | 0.0 | 10.0 |
| HUNT RESULT | 0.1 | +24.4 | 0.0 | 6.1 | 0.1 | +0.0 | 0.0 | 0.0 |
| HUNT THE GUNS | 0.1 | +30.6 | 0.0 | 0.0 | 0.2 | +28.2 | 0.0 | 0.0 |
| IDLE COST | 14.4 | -195.3 | 0.0 | 157.4 | 20.9 | -393.5 | 0.0 | 126.0 |
| INVITES THE FIGHT | - | - | - | - | 0.1 | +1.1 | 0.0 | 0.0 |
| JOINT CHARGE PLAN | - | - | - | - | 0.1 | +1.5 | 12.2 | 0.0 |
| KEEP FALLS | 0.3 | +5.1 | 0.0 | 24.3 | 0.1 | +0.2 | 0.0 | 0.0 |
| KEEPS ITS TARGET | - | - | - | - | 2.1 | +63.3 | 147.8 | 5.0 |
| KILLS COUNT | 1.0 | +64.1 | 102.1 | 0.0 | 2.3 | +81.4 | 147.1 | 27.8 |
| KILLS COUNT NEXT TURN | - | - | - | - | 7.4 | +245.5 | 221.8 | 44.0 |
| LONE CHARACTER SAFE SPOT | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| LONE WIZARD KEPT IN | 1.1 | +104.7 | 0.0 | 0.0 | 0.2 | +17.2 | 0.0 | 0.0 |
| LONG SHOT | 0.1 | -0.5 | 15.0 | 0.0 | 0.2 | +9.8 | 0.0 | 0.0 |
| LOST CHARGE | 0.1 | -0.1 | 5.0 | 0.0 | 3.8 | -28.1 | 31.6 | 69.8 |
| MAKE SURE TOGETHER | - | - | - | - | 0.4 | +5.4 | 58.6 | 20.7 |
| MANOEUVRE | 0.4 | +6.9 | 0.0 | 0.0 | 0.1 | +3.5 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.1 | +6.3 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | 0.7 | +49.0 | 0.0 | 0.0 | 0.9 | +91.1 | 0.0 | 0.0 |
| MARCH ODDS | - | - | - | - | 0.9 | +45.7 | 28.3 | 18.0 |
| MARCH OVER CASTS | 0.1 | +1.5 | 0.0 | 0.0 | 1.1 | +127.6 | 0.0 | 18.0 |
| MAX FOR POSITIONING | 8.0 | +94.3 | 0.0 | 168.7 | 8.4 | +99.9 | 0.0 | 176.8 |
| MISSILES IN THE MOVE | 6.2 | +382.3 | 0.0 | 109.7 | 7.0 | +139.3 | 0.0 | 169.8 |
| MISSILES NEXT TURN | 6.1 | +253.1 | 0.0 | 109.7 | 8.9 | +101.2 | 0.0 | 169.8 |
| MONSTER WIZARD ROAMS | - | - | - | - | 0.7 | +0.0 | 0.0 | 51.8 |
| MOVE AND CAST | - | - | - | - | 0.8 | +22.4 | 0.0 | 0.0 |
| MOVE SPELL IN RANGE | 0.4 | +19.9 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL NOT WORTH | 0.1 | -0.1 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 1.8 | -60.4 | 71.6 | 0.0 | - | - | - | - |
| MOVE SPELL SPOT | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE | - | - | - | - | 7.3 | +363.9 | 159.0 | 135.9 |
| MOVES UNITS SPELL | 0.2 | +12.2 | 0.0 | 0.0 | - | - | - | - |
| NOT NEEDED | - | - | - | - | 0.1 | -0.5 | 0.0 | 0.0 |
| NOT TURNED | 0.1 | +0.0 | 0.0 | 0.0 | 4.8 | +119.3 | 0.0 | 36.0 |
| NOT WORTH A CAST | 0.2 | -0.4 | 0.0 | 39.4 | 0.2 | -0.0 | 0.0 | 0.0 |
| OFF BEST | 0.4 | -17.3 | 0.0 | 9.4 | 15.1 | -758.1 | 21.0 | 189.0 |
| ONE FIGHT FORMULA | 6.8 | -109.4 | 0.0 | 196.1 | 9.3 | -210.4 | 0.0 | 164.4 |
| ONE OBJECTIVE FORMULA | 3.4 | +29.2 | 0.0 | 21.1 | 2.6 | -161.7 | 0.0 | 0.0 |
| OPENS A LANE | - | - | - | - | 0.1 | +0.4 | 0.0 | 0.0 |
| OPENS UP | - | - | - | - | 0.1 | +6.8 | 6.1 | 0.0 |
| OVERRUNS AWAY | - | - | - | - | 0.4 | +29.9 | 18.3 | 22.8 |
| PATHS CROSS | 1.3 | +99.3 | 0.0 | 0.0 | 2.3 | +157.0 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.2 | -7.6 | 0.0 | 0.0 | 0.3 | -5.8 | 0.0 | 0.0 |
| PLAN RESULT | 37.9 | +1041.1 | 1093.1 | 810.7 | 38.0 | +1031.0 | 1508.4 | 760.3 |
| PURSUES BIG PREY | 0.1 | -17.0 | 0.0 | 0.0 | - | - | - | - |
| RAIDS THE BAGGAGE NEXT TURN | - | - | - | - | 0.1 | +9.7 | 0.0 | 0.0 |
| RANDOM MOVE BY FIGURES | 0.6 | +6.8 | 0.0 | 37.8 | 0.7 | +9.5 | 0.0 | 0.0 |
| RANDOM MOVER NO PROMISE | - | - | - | - | 0.1 | -6.9 | 13.8 | 0.0 |
| REDIRECT BY WHAT IT STOPS | 0.1 | -1.2 | 0.0 | 0.0 | 0.7 | -21.1 | 0.0 | 5.0 |
| REDIRECT COUNTER | 2.6 | +210.1 | 0.0 | 22.8 | 1.7 | +63.9 | 0.0 | 24.4 |
| REDIRECT WEIGHED | - | - | - | - | 0.4 | -3.4 | 23.9 | 0.0 |
| REFUSING RETIRES | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| RESERVE FALL BACK | 0.7 | +56.2 | 0.0 | 35.8 | 1.1 | +20.9 | 0.0 | 0.0 |
| RISK BY ARC | 1.7 | +48.3 | 224.7 | 49.7 | 3.2 | +94.2 | 233.6 | 85.7 |
| RISK ONCE | - | - | - | - | 5.2 | +179.8 | 28.3 | 289.2 |
| RUN DOWN | 1.6 | -38.6 | 153.2 | 15.2 | - | - | - | - |
| SAFE SURE CHARGE | - | - | - | - | 0.1 | -4.8 | 0.0 | 0.0 |
| SAFER THAN THE JOB | - | - | - | - | 0.7 | +19.7 | 0.0 | 41.0 |
| SCOUT SPOT | 0.2 | +1.0 | 0.0 | 0.0 | - | - | - | - |
| SCOUT WAITS | 0.2 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SCREEN BY WHAT IT SAVES | 0.1 | -1.9 | 0.0 | 0.0 | 0.2 | -22.2 | 0.0 | 5.0 |
| SEARCH SPOT | 3.0 | +70.8 | 0.0 | 44.3 | 1.8 | +64.5 | 0.0 | 18.0 |
| SET UP TOGETHER | - | - | - | - | 2.1 | +60.5 | 79.6 | 25.1 |
| SET-UP ANY TARGET | 0.6 | +96.3 | 35.8 | 0.0 | - | - | - | - |
| SET-UP MISSED | - | - | - | - | 0.1 | +4.8 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.2 | +0.4 | 0.0 | 0.0 | - | - | - | - |
| SHOOTS FROM THE BEST SPOT | 1.3 | +106.8 | 182.1 | 0.0 | 1.0 | +13.1 | 25.0 | 0.0 |
| SHOT REPLANNED | 0.4 | +0.0 | 65.0 | 0.0 | 0.2 | +0.0 | 80.0 | 0.0 |
| SHOTS IN THE MOVE | 12.1 | +387.4 | 0.0 | 116.1 | 9.3 | +501.5 | 0.0 | 229.8 |
| SPELL SETS UP CHARGE | 0.6 | +96.3 | 35.8 | 0.0 | - | - | - | - |
| SPELL WORTH | 0.9 | +6.9 | 0.0 | 0.0 | 3.2 | +49.3 | 126.9 | 126.9 |
| SPELLS IN THE FIGHT | 0.3 | -12.6 | 6.7 | 0.0 | 0.7 | -4.5 | 88.1 | 0.0 |
| STABLE ROLE | - | - | - | - | 11.3 | +0.0 | 381.9 | 56.3 |
| STAND AND SHOOT | 0.1 | -0.4 | 0.0 | 0.0 | - | - | - | - |
| STANDS TO CAST | 0.1 | +0.5 | 0.0 | 0.0 | - | - | - | - |
| STOPS | 0.3 | +5.4 | 36.7 | 0.0 | 0.1 | +0.1 | 0.0 | 5.0 |
| STOPS SHORT OF THE FLANK | - | - | - | - | 0.4 | +47.3 | 0.0 | 0.0 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| SUPPORT NARROWED | 1.1 | +0.0 | 168.0 | 40.2 | 5.4 | -42.8 | 219.8 | 26.2 |
| SUPPORTS | - | - | - | - | 3.3 | +56.3 | 84.1 | 26.2 |
| SURE REACH TOGETHER | 0.1 | +0.3 | 0.0 | 0.0 | 1.8 | -6.9 | 33.2 | 82.0 |
| THROUGH LINE OF FIRE | - | - | - | - | 0.2 | +22.0 | 0.0 | 0.0 |
| TIME ON OUR SIDE | 2.6 | +0.0 | 104.7 | 0.0 | - | - | - | - |
| TURN WORTH | 0.1 | -14.9 | 22.8 | 0.0 | 0.3 | -22.5 | 19.7 | 0.0 |
| TWO OR MORE ARRIVE | - | - | - | - | 0.6 | +2.6 | 0.0 | 0.0 |
| WAIT AFTER COSTS | - | - | - | - | 9.4 | -466.8 | 248.7 | 135.9 |
| WALKS TO THE FIGHT | - | - | - | - | 1.1 | +6.0 | 41.7 | 0.0 |
| WAR ENGINE CHARGES | 0.3 | +22.8 | 149.7 | 34.4 | - | - | - | - |
| WAR ENGINE JOBS | 0.1 | +0.0 | 63.4 | 0.0 | 0.7 | +0.0 | 20.7 | 0.0 |
| WEARS DOWN | 0.9 | +45.8 | 166.9 | 49.7 | 0.8 | +19.5 | 84.9 | 52.3 |
| WHO HITS BACK | - | - | - | - | 0.3 | +14.7 | 0.0 | 0.0 |
| WHOLE FIGHT | 0.3 | -9.0 | 22.8 | 0.0 | 0.2 | +2.1 | 34.4 | 5.6 |
| WHOLE FIGHT GAIN | - | - | - | - | 0.6 | +41.3 | 91.1 | 0.0 |
| WIDER SPREAD | 1.6 | -13.0 | 154.0 | 15.2 | 2.6 | -1.8 | 210.8 | 33.3 |

### Rule changes: fa-h2h-mine-8a94331-p3

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 140 | 140 | 140 | 15.56 | -6978 | -49.8 |
| SEARCH SPOT | 43 | 43 | 42 | 4.67 | +1249 | +29.7 |
| COVER ONCE | 153 | 90 | 33 | 3.67 | +270 | +8.2 |
| PATHS CROSS | 33 | 33 | 33 | 3.67 | +2306 | +69.9 |
| MOVE TO CHARGE | 66 | 66 | 31 | 3.44 | +954 | +30.8 |
| ARTILLERY RE-ROLL WEIGHED | 28 | 28 | 28 | 3.11 | +0 | +0.0 |
| IDLE COST | 318 | 177 | 27 | 3.00 | +178 | +6.6 |
| SHOTS IN THE MOVE | 193 | 145 | 26 | 2.89 | +775 | +29.8 |
| KILLS COUNT NEXT TURN | 67 | 67 | 25 | 2.78 | +467 | +18.7 |
| MISSILES IN THE MOVE | 119 | 66 | 20 | 2.22 | +669 | +33.5 |
| MAX FOR POSITIONING | 148 | 115 | 19 | 2.11 | +79 | +4.2 |
| CANNON SIGHT KEPT | 17 | 17 | 17 | 1.89 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 17 | 17 | 17 | 1.89 | +3251 | +191.3 |
| FACES THE THREAT | 16 | 16 | 16 | 1.78 | +1621 | +101.3 |
| RESERVE FALL BACK | 16 | 16 | 16 | 1.78 | +694 | +43.3 |
| REDIRECT COUNTER | 38 | 24 | 15 | 1.67 | +1646 | +109.7 |
| CANNON PLANNED TARGET | 68 | 68 | 14 | 1.56 | -38 | -2.7 |
| SUPPORTS | 30 | 30 | 14 | 1.56 | +273 | +19.5 |
| WAIT AFTER COSTS | 85 | 85 | 13 | 1.44 | +235 | +18.1 |
| LONE WIZARD KEPT IN | 12 | 12 | 12 | 1.33 | +1097 | +91.4 |
| MARCH CHECK | 14 | 12 | 12 | 1.33 | +428 | +35.6 |
| ONE FIGHT FORMULA | 145 | 70 | 12 | 1.33 | +29 | +2.4 |
| CHARGE LOSSES | 104 | 104 | 11 | 1.22 | +440 | +40.0 |
| HONEST WORTH | 121 | 119 | 11 | 1.22 | +56 | +5.1 |
| SHOOTS FROM THE BEST SPOT | 21 | 21 | 11 | 1.22 | +743 | +67.6 |
| COMBAT PIVOT | 10 | 10 | 10 | 1.11 | +0 | +0.0 |
| FEATURE BUFFS | 31 | 31 | 10 | 1.11 | +206 | +20.6 |
| RISK ONCE | 47 | 35 | 10 | 1.11 | +327 | +32.7 |
| CHARGE NOW FIRST | 39 | 39 | 9 | 1.00 | -142 | -15.8 |
| RISK BY ARC | 44 | 42 | 9 | 1.00 | +301 | +33.4 |
| ADVANCE WORTH | 32 | 32 | 8 | 0.89 | +71 | +8.9 |
| MARCH ODDS | 8 | 8 | 8 | 0.89 | +65 | +8.2 |
| CAST JOB | 21 | 21 | 7 | 0.78 | +92 | +13.1 |
| CHAFF IN THE MOVE | 10 | 9 | 7 | 0.78 | +203 | +29.0 |
| FOUR ROUNDS | 20 | 20 | 7 | 0.78 | +535 | +76.5 |
| HOLDS AMBUSHERS | 7 | 7 | 7 | 0.78 | +0 | +0.0 |
| MOVE AND CAST | 7 | 7 | 7 | 0.78 | +201 | +28.7 |
| BEST FIRST | 6 | 6 | 6 | 0.67 | +238 | +39.6 |
| CHARGE NOW WEIGHED | 6 | 6 | 6 | 0.67 | +555 | +92.5 |
| FALLBACK BY WORTH | 46 | 46 | 6 | 0.67 | +259 | +43.1 |
| KILLS COUNT | 30 | 28 | 6 | 0.67 | +303 | +50.5 |
| ONE OBJECTIVE FORMULA | 54 | 31 | 6 | 0.67 | +458 | +76.3 |
| SAFER THAN THE JOB | 6 | 6 | 6 | 0.67 | +177 | +29.5 |
| SHOT REPLANNED | 6 | 6 | 6 | 0.67 | +0 | +0.0 |
| PIVOT GUARDS FLANK | 5 | 5 | 5 | 0.56 | -121 | -24.1 |
| RANDOM MOVE BY FIGURES | 11 | 11 | 5 | 0.56 | +147 | +29.5 |
| SET UP TOGETHER | 19 | 17 | 5 | 0.56 | +95 | +19.1 |
| ADVANCE LANE KEPT | 4 | 4 | 4 | 0.44 | +0 | +0.0 |
| BEST FACING | 4 | 4 | 4 | 0.44 | +2 | +0.5 |
| BIG CHARACTER SAFETY | 4 | 4 | 4 | 0.44 | -30 | -7.6 |
| CASTER AWAY FROM SCREEN | 4 | 4 | 4 | 0.44 | +0 | +0.0 |
| FRIENDS SHOTS CHECKED | 4 | 4 | 4 | 0.44 | +322 | +80.4 |
| KEEP FALLS | 4 | 4 | 4 | 0.44 | +163 | +40.9 |
| KEEPS ITS TARGET | 19 | 18 | 4 | 0.44 | +60 | +14.9 |
| REDIRECT WEIGHED | 4 | 4 | 4 | 0.44 | -18 | -4.6 |
| STOPS SHORT OF THE FLANK | 4 | 4 | 4 | 0.44 | +426 | +106.5 |
| WAR ENGINE JOBS | 7 | 7 | 4 | 0.44 | -46 | -11.4 |
| WEARS DOWN | 15 | 15 | 4 | 0.44 | +98 | +24.5 |
| WHOLE FIGHT GAIN | 5 | 4 | 4 | 0.44 | +137 | +34.2 |
| CASTING BLOCK | 3 | 3 | 3 | 0.33 | +10 | +3.5 |
| FIVE ACTION | 387 | 387 | 3 | 0.33 | +309 | +102.9 |
| MANOEUVRE | 5 | 5 | 3 | 0.33 | +94 | +31.4 |
| MISSILES NEXT TURN | 135 | 70 | 3 | 0.33 | +16 | +5.3 |
| SURE REACH TOGETHER | 17 | 16 | 3 | 0.33 | +2 | +0.8 |
| WALKS TO THE FIGHT | 10 | 10 | 3 | 0.33 | +27 | +9.1 |
| WHO HITS BACK | 3 | 3 | 3 | 0.33 | +36 | +12.0 |
| BEST PREY | 5 | 5 | 2 | 0.22 | +31 | +15.7 |
| BEST PRIZE | 2 | 2 | 2 | 0.22 | -64 | -32.2 |
| CASTS FROM BEHIND | 2 | 2 | 2 | 0.22 | +0 | +0.0 |
| CHAFF PASSED | 2 | 2 | 2 | 0.22 | -1 | -0.5 |
| HUNT IN PAIRS | 16 | 8 | 2 | 0.22 | +13 | +6.7 |
| LOST CHARGE | 35 | 35 | 2 | 0.22 | +36 | +18.2 |
| MOVES UNITS SPELL | 2 | 2 | 2 | 0.22 | +110 | +55.1 |
| SCOUT WAITS | 2 | 2 | 2 | 0.22 | +0 | +0.0 |
| SHOOTERS IN TWO RANKS | 2 | 2 | 2 | 0.22 | +4 | +2.0 |
| STUCK PIVOT | 2 | 2 | 2 | 0.22 | +0 | +0.0 |
| SUPPORT NARROWED | 59 | 59 | 2 | 0.22 | -9 | -4.6 |
| THROUGH LINE OF FIRE | 2 | 2 | 2 | 0.22 | +198 | +99.2 |
| AFTERMATH IN POINTS | 1 | 1 | 1 | 0.11 | +196 | +196.3 |
| BEST OVERALL | 1 | 1 | 1 | 0.11 | +241 | +241.2 |
| BLOCKED WHEEL | 1 | 1 | 1 | 0.11 | +37 | +37.0 |
| CARRIES OUT SET-UP | 2 | 2 | 1 | 0.11 | -8 | -8.1 |
| CATCH ODDS | 1 | 1 | 1 | 0.11 | -2 | -1.9 |
| GUN MASK | 2 | 2 | 1 | 0.11 | +16 | +16.1 |
| INVITES THE FIGHT | 1 | 1 | 1 | 0.11 | +10 | +10.1 |
| JOINT CHARGE PLAN | 1 | 1 | 1 | 0.11 | +2 | +1.9 |
| PURSUES BIG PREY | 1 | 1 | 1 | 0.11 | -153 | -153.3 |
| RAIDS THE BAGGAGE NEXT TURN | 1 | 1 | 1 | 0.11 | +2 | +2.0 |
| SAFE SURE CHARGE | 1 | 1 | 1 | 0.11 | -34 | -34.4 |
| SPELLS IN THE FIGHT | 9 | 8 | 1 | 0.11 | +5 | +4.9 |
| STANDS TO CAST | 1 | 1 | 1 | 0.11 | -4 | -3.6 |
| TWO OR MORE ARRIVE | 5 | 5 | 1 | 0.11 | +0 | +0.0 |
| WAR ENGINE CHARGES | 3 | 3 | 1 | 0.11 | +34 | +33.6 |
| ALREADY CARRIED | 2 | not checked | - | - | - | - |
| BACKUP TARGETS | 4 | 3 | 0 | 0.00 | - | - |
| BLOWS WHERE AIMED | 1 | 1 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 10 | 10 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 20 | trace | - | - | - | - |
| CHARACTER GUNS | 3 | 3 | 0 | 0.00 | - | - |
| CHARGER SLAIN LOST | 3 | 3 | 0 | 0.00 | - | - |
| CHARIOT WIZARD CAREFUL | 3 | 3 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 24 | not checked | - | - | - | - |
| DEFENSIVE FLOOR | 1 | 1 | 0 | 0.00 | - | - |
| EDGE GIVE GROUND | 1 | 1 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 10 | 10 | 0 | 0.00 | - | - |
| FIGHT LIFT | 1 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 99 | not checked | - | - | - | - |
| GIVES UP | 3 | 3 | 0 | 0.00 | - | - |
| HELPER ALREADY ASKED | 3 | not checked | - | - | - | - |
| HELPER UNSEEN | 2 | 2 | 0 | 0.00 | - | - |
| HILL BY ITS CHANCE | 8 | 8 | 0 | 0.00 | - | - |
| HUNT ADVANCE | 2 | 2 | 0 | 0.00 | - | - |
| HUNT DROPPED | 1 | trace | - | - | - | - |
| HUNT KEPT | 4 | trace | - | - | - | - |
| HUNT RESULT | 2 | trace | - | - | - | - |
| HUNT THE GUNS | 3 | trace | - | - | - | - |
| LONE CHARACTER SAFE SPOT | 1 | not checked | - | - | - | - |
| LONG SHOT | 3 | 3 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 4 | 4 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 11 | 11 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 6 | 6 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 4 | 2 | 0 | 0.00 | - | - |
| MOVE SPELL NOT WORTH | 1 | not checked | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 16 | trace | - | - | - | - |
| MOVE SPELL SPOT | 12 | not checked | - | - | - | - |
| NOT NEEDED | 1 | 1 | 0 | 0.00 | - | - |
| NOT TURNED | 44 | 44 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 4 | not checked | - | - | - | - |
| OPENS A LANE | 1 | not checked | - | - | - | - |
| OPENS UP | 1 | 1 | 0 | 0.00 | - | - |
| OVERRUNS AWAY | 4 | 4 | 0 | 0.00 | - | - |
| PLAN RESULT | 683 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 1 | 1 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 7 | 7 | 0 | 0.00 | - | - |
| REFUSING RETIRES | 1 | 1 | 0 | 0.00 | - | - |
| RUN DOWN | 14 | 14 | 0 | 0.00 | - | - |
| SCOUT SPOT | 2 | 2 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 3 | 3 | 0 | 0.00 | - | - |
| SET-UP ANY TARGET | 5 | not checked | - | - | - | - |
| SET-UP MISSED | 1 | trace | - | - | - | - |
| SPELL SETS UP CHARGE | 5 | not checked | - | - | - | - |
| SPELL WORTH | 37 | not checked | - | - | - | - |
| STABLE ROLE | 102 | 100 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 1 | 1 | 0 | 0.00 | - | - |
| STOPS | 4 | 4 | 0 | 0.00 | - | - |
| TIME ON OUR SIDE | 23 | 23 | 0 | 0.00 | - | - |
| TURN WORTH | 4 | 4 | 0 | 0.00 | - | - |
| WHOLE FIGHT | 5 | 5 | 0 | 0.00 | - | - |
| WIDER SPREAD | 37 | 35 | 0 | 0.00 | - | - |

### Off best figure: fa-h2h-mine-8a94331-p3

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 0.44 | 14.00 | 49.3 |
| CHARGE NOW FIRST | rule | 0.11 | 0.89 | 15.8 |
| FALLBACK | gate | - | 0.67 | 52.0 |
| PIVOT GUARDS FLANK | rule | 0.22 | 0.33 | 24.1 |
| WAR ENGINE JOBS | rule | - | 0.44 | 11.4 |
| BIG CHARACTER SAFETY | rule | - | 0.33 | 10.9 |
| TURN GATE | gate | - | 0.33 | 56.5 |
| BEST PRIZE | rule | - | 0.22 | 32.2 |
| FACES THE THREAT | rule | - | 0.22 | 11.6 |
| REDIRECT WEIGHED | rule | - | 0.22 | 32.2 |
| SUPPORT NARROWED | rule | - | 0.22 | 4.6 |
| CANNON PLANNED TARGET | rule | - | 0.11 | 54.4 |
| CARRIES OUT SET-UP | rule | - | 0.11 | 8.1 |
| CATCH ODDS | rule | 0.11 | - | 1.9 |
| CHAFF PASSED | rule | 0.11 | - | 0.5 |
| PATHS CROSS | rule | - | 0.11 | 32.2 |
| PURSUES BIG PREY | rule | 0.11 | - | 153.3 |
| SAFE SURE CHARGE | rule | - | 0.11 | 34.4 |
| SAFER THAN THE JOB | rule | - | 0.11 | 9.7 |
| STANDS TO CAST | rule | 0.11 | - | 3.6 |
| SUPPORT REQUEST | gate | - | 0.11 | 82.4 |

### Plans: fa-h2h-mine-8a94331-p3

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.8 | 38% | 303 | 258 | 85% |
| Mine | join | 0.3 | 100% | 12 | 0 | 0% |
| Mine | move | 26.1 | 95% | 1904 | 0 | 0% |
| Mine | shoot | 9.6 | 56% | 424 | 783 | 185% |
| Mine | support | 0.1 | 0% | 0 | 0 | - |
| Opponent | advance | 10.7 | 12% | 119 | 173 | 145% |
| Opponent | charge | 3.7 | 64% | 244 | 342 | 140% |
| Opponent | close in | 8.6 | 13% | 310 | 153 | 49% |
| Opponent | hold | 4.4 | 18% | 294 | 0 | 0% |
| Opponent | join | 0.4 | 100% | 19 | 0 | 0% |
| Opponent | shoot | 6.0 | 65% | 265 | 369 | 139% |
| Opponent | support | 4.1 | 89% | 46 | 0 | 0% |

### Packages: hunt the guns, fa-h2h-mine-8a94331-p3

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.1 | 1 | 0 | 100% | 100% | 0% | 4.0 | 275 | 220 | 100% | 88 |
| Opponent | 0.2 | 2 | 1 | 0% | 0% | 0% | - | 142 | 0 | 0% | 97 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.2 | 1 | 0 | 100% | 100% | 0% | 4.0 | 275 | 220 | 100% | 13 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 145 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 160 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 123 |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 377 |
| Vampire Counts | 0.7 | 2 | 1 | 0% | 0% | 0% | - | 142 | 0 | 0% | 42 |
| Warriors of Chaos | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |

### Battle groups: fa-h2h-mine-8a94331-p3

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 2.6 | 17% | 75% | 0% | - | 0% | 0% | 25% | 75% | 0% |
| Opponent | REDIRECT COUNTER | 1.7 | 13% | 100% | 0% | - | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: fa-h2h-mine-8a94331-p3

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 10 | 38 (10) | 20 | 18 | 43 | 70% | 2.7 | 28 (6) | 0 (1) | 77 (3) | 77 (5) | 0 (5) |
| Mine | Character | 36 | 27 (36) | 27 | 0 | 29 | 19% | 2.1 | 102 (6) | 13 (20) | 16 (6) | 27 (17) | 32 (15) |
| Mine | Clean-up | 5 | 206 (5) | 83 | 123 | 73 | 60% | 4.5 | 221 (1) | 159 (2) | 231 (2) | 188 (3) | 231 (2) |
| Mine | Fast Hammer | 7 | 0 (7) | 0 | 0 | 34 | 86% | 3.0 | 0 (3) | 0 (3) | 0 (1) | 0 (6) | 0 (1) |
| Mine | Hammer | 22 | 32 (22) | 21 | 11 | 27 | 18% | 2.9 | 23 (4) | 38 (16) | 5 (2) | 32 (14) | 32 (8) |
| Mine | Holder | 12 | 40 (12) | 0 | 40 | 25 | 67% | 4.0 | 21 (4) | 14 (6) | 162 (2) | 32 (5) | 46 (7) |
| Mine | Shooter | 4 | 38 (4) | 0 | 38 | 75 | 0% | 1.2 | - | 38 (4) | - | 77 (2) | 0 (2) |
| Mine | War machine | 13 | 53 (13) | 53 | 0 | 33 | 8% | 1.2 | 88 (4) | 42 (7) | 0 (2) | 63 (4) | 47 (9) |
| Mine | Wizard | 5 | 0 (5) | 0 | 0 | 18 | 40% | 3.0 | - | 0 (5) | - | 0 (2) | 0 (3) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | 0 (1) | - | - | 0 (1) | - |
| Opponent | Chaff | 15 | 54 (15) | 0 | 54 | 45 | 67% | 3.8 | 46 (7) | - | 61 (8) | 25 (9) | 90 (6) |
| Opponent | Character | 26 | 38 (26) | 38 | 0 | 24 | 15% | 2.4 | 50 (7) | 35 (16) | 0 (3) | 34 (15) | 42 (11) |
| Opponent | Clean-up | 6 | 55 (6) | 17 | 38 | 32 | 67% | 2.0 | 0 (1) | 56 (4) | 108 (1) | 40 (3) | 64 (3) |
| Opponent | Fast Hammer | 13 | 38 (13) | 11 | 27 | 20 | 15% | 2.9 | 21 (6) | 63 (6) | 0 (1) | 62 (7) | 10 (6) |
| Opponent | Hammer | 5 | 66 (5) | 50 | 16 | 0 | 40% | 4.0 | - | 66 (5) | - | 74 (4) | 37 (1) |
| Opponent | Holder | 7 | 93 (7) | 0 | 93 | 0 | 86% | 3.0 | 0 (1) | 112 (6) | - | 144 (4) | 47 (3) |
| Opponent | Shooter | 3 | 32 (3) | 32 | 0 | 78 | 0% | 1.0 | 54 (2) | 0 (1) | - | 32 (3) | - |
| Opponent | Support | 1 | 0 (1) | 0 | 0 | 0 | 0% | 5.0 | - | - | 0 (1) | 0 (1) | - |
| Opponent | War machine | 10 | 60 (10) | 60 | 0 | 57 | 0% | 1.6 | 247 (2) | 0 (5) | 49 (3) | 190 (3) | 21 (7) |
| Opponent | Wizard | 5 | 13 (5) | 13 | 0 | 46 | 20% | 2.8 | 22 (3) | 0 (1) | 0 (1) | 22 (3) | 0 (2) |

### Charged fights: fa-h2h-mine-8a94331-p3

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 176 | 75 | 0.8 | 1.0 | 100 | 28 | +72 | 0 of 3 | 2 of 3 | - | +72 |
| Mine | Chaos Dwarfs | 4 | 275 | 166 | 2.2 | 1.1 | 74 | 69 | +5 | 4 of 9 | 7 of 9 | +0 | +6 |
| Mine | Dwarfen Mountain Holds | 1 | 377 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| **Mine** | all armies | 9 | 242 | 107 | 1.3 | 1.1 | 80 | 59 | +22 | 4 of 12 | 9 of 12 | +0 | +24 |
| Opponent | Grand Cathay | 3 | 167 | 122 | 1.3 | 1.0 | 91 | 0 | +91 | 1 of 4 | 4 of 4 | - | +91 |
| Opponent | High Elf Realms | 1 | 692 | 189 | 4.0 | 1.2 | 47 | 0 | +47 | 1 of 4 | 4 of 4 | +0 | +63 |
| Opponent | Kingdom of Bretonnia | 1 | 160 | 113 | 2.0 | 1.0 | 56 | 236 | -179 | 1 of 2 | 1 of 2 | - | -179 |
| Opponent | Vampire Counts | 3 | 0 | 614 | 3.3 | 1.3 | 184 | 67 | +118 | 5 of 10 | 10 of 10 | +484 | +26 |
| Opponent | Warriors of Chaos | 1 | 0 | 0 | 3.0 | 1.0 | 0 | 0 | +0 | 1 of 3 | 3 of 3 | - | +0 |
| **Opponent** | all armies | 9 | 150 | 279 | 2.6 | 1.2 | 109 | 49 | +60 | 9 of 23 | 22 of 23 | +322 | +20 |

### Effective charges: fa-h2h-mine-8a94331-p3

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 3 | 0 | 0 | 2 (net +150) | 1 (net -85) | 0 | 0 | 0 | 67% (2 of 3) |
| Mine | Chaos Dwarfs | 9 | 0 | 0 | 2 (net -52) | 2 (net -95) | 0 | 5 (net +68) | 0 | 22% (2 of 9) |
| Opponent | Grand Cathay | 4 | 0 | 0 | 1 (net +170) | 2 (net +42) | 1 (net +110) | 0 | 0 | 25% (1 of 4) |
| Opponent | High Elf Realms | 4 | 2 (net +0) | 0 | 0 | 0 | 1 (net +189) | 1 (net +0) | 0 | 0% (0 of 4) |
| Opponent | Kingdom of Bretonnia | 2 | 1 (net -358) | 0 | 0 | 0 | 1 (net +0) | 0 | 0 | 0% (0 of 2) |
| Opponent | Vampire Counts | 10 | 1 (net +0) | 0 | 2 (net +32) | 1 (net +170) | 0 | 4 (net +202) | 2 | 25% (2 of 8) |
| Opponent | Warriors of Chaos | 3 | 0 | 0 | 0 | 2 (net +0) | 0 | 1 (net +0) | 0 | 0% (0 of 3) |

### Charged fights, damage counted: fa-h2h-mine-8a94331-p3

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Effective (55-75%) | 4 | 142 | 218 | +49 | 195 | 84 | +111 | +78.3 |
| Mine | 76-89% | 3 | 100 | 156 | -92 | 40 | 133 | -93 | -93.1 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 5 | 384 | 283 | +68 | 68 | 0 | +68 | +17.7 |
| Mine | All fights | 12 | 232 | 230 | +22 | 103 | 61 | +42 | +18.1 |
| Opponent | Long shot (under 50%) | 4 | 403 | 381 | -90 | 117 | 165 | -47 | -11.7 |
| Opponent | Effective (55-75%) | 3 | 200 | 122 | +78 | 93 | 68 | +26 | +12.8 |
| Opponent | 76-89% | 5 | 287 | 201 | +51 | 61 | 30 | +30 | +10.5 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 6 | 370 | 248 | +135 | 287 | 106 | +180 | +48.7 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 3 | 324 | 95 | +100 | 114 | 18 | +96 | +29.6 |
| Opponent | No odds | 2 | 522 | 65 | +65 | 65 | 0 | +65 | +12.5 |
| Opponent | All fights | 23 | 343 | 209 | +60 | 141 | 74 | +67 | +19.5 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| fa-h2h-mine-8a94331-p3 | move | 85 | 17 (20%) | 13 (15%) | 9 (11%) | 59 (69%) |
| fa-h2h-mine-8a94331-p3 | objective | 77 | 6 (8%) | 6 (8%) | 14 (18%) | 57 (74%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0110, L0126 |
| Charmed Shield | Opponent | L0126, L0226, L0327 |
| Elixir of Power | Opponent | L0311 |
| Invocation of Nehek | Opponent | L0327 |
| Ring of Doom | Mine | L0210, L0226 |
| Ring of Doom | Opponent | L0311 |
| Ring of Jet | Opponent | L0110, L0210, L0311 |
| Standard of the Fell Warrior | Opponent | L0413 |
| Twice-Blessed Armour | Opponent | L0110, L0210 |

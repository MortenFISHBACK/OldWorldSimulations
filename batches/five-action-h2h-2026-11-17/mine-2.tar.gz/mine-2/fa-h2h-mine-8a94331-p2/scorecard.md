# Doctrine scorecard: fa-h2h-mine-8a94331-p2

### Scorecard: fa-h2h-mine-8a94331-p2

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0106 | 4 | 1 | Mine | no | 0 | 5 | 1 | 2 | 0 | 0 | 0 | 65 |
| L0106 | 4 | 1 | Opponent | no | 2 | 4 | 3 | 0 | 1 | 0 | 0 | 1109 |
| L0122 | 2 | 1 | Mine | - | - | - | 0 | 2 | 0 | 0 | 0 | 55 |
| L0122 | 2 | 1 | Opponent | - | - | 2 | 2 | 2 | 0 | 0 | 0 | 0 |
| L0206 | 2 | 1 | Mine | - | - | - | 0 | 6 | 0 | 0 | 0 | 52 |
| L0206 | 2 | 1 | Opponent | - | - | 3 | 0 | 1 | 0 | 0 | 0 | 615 |
| L0222 | 6 | 1 | Mine | no | 2 | 2 | 1 | 5 | 0 | 0 | 0 | 170 |
| L0222 | 6 | 1 | Opponent | no | 12 | 2 | 5 | 0 | 0 | 0 | 0 | 55 |
| L0307 | 1 | 1 | Mine | yes | 4 | 5 | 1 | 2 | 0 | 0 | 0 | 340 |
| L0307 | 1 | 1 | Opponent | yes | 3 | 3 | 1 | 0 | 1 | 0 | 0 | 420 |
| L0323 | 5 | 1 | Mine | no | - | - | 0 | 2 | 0 | 0 | 0 | 250 |
| L0323 | 5 | 1 | Opponent | yes | - | 2 | 7 | 3 | 1 | 0 | 0 | 0 |
| L0409 | 1 | 1 | Mine | no | 4 | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L0409 | 1 | 1 | Opponent | no | 2 | 3 | 1 | 1 | 0 | 0 | 0 | 1117 |
| L0425 | 5 | 1 | Mine | yes | - | 2 | 1 | 4 | 0 | 0 | 0 | 0 |
| L0425 | 5 | 1 | Opponent | yes | - | 3 | 6 | 3 | 2 | 0 | 0 | 0 |
| L0512 | 2 | 1 | Mine | - | - | - | 0 | 2 | 0 | 0 | 0 | 892 |
| L0512 | 2 | 1 | Opponent | - | - | 4 | 0 | 3 | 1 | 0 | 0 | 330 |
| L0528 | 6 | 1 | Mine | no | 0 | - | 1 | 2 | 0 | 0 | 0 | 423 |
| L0528 | 6 | 1 | Opponent | no | 8 | - | 0 | 2 | 0 | 0 | 0 | 0 |
| L0616 | 4 | 1 | Mine | no | 0 | - | 1 | 1 | 0 | 0 | 0 | 60 |
| L0616 | 4 | 1 | Opponent | no | 1 | 3 | 2 | 1 | 1 | 0 | 0 | 200 |
| L0632 | 2 | 1 | Mine | - | - | 2 | 1 | 0 | 1 | 0 | 0 | 701 |
| L0632 | 2 | 1 | Opponent | - | - | 2 | 4 | 3 | 0 | 0 | 0 | 170 |
| L0721 | 1 | 1 | Mine | no | 0 | 2 | 6 | 2 | 1 | 0 | 0 | 327 |
| L0721 | 1 | 1 | Opponent | yes | 6 | - | 0 | 4 | 0 | 0 | 0 | 355 |
| L0810 | 6 | 1 | Mine | no | 1 | - | 0 | 2 | 0 | 0 | 0 | 340 |
| L0810 | 6 | 1 | Opponent | no | 11 | 2 | 2 | 0 | 1 | 0 | 0 | 330 |
| L0827 | 5 | 1 | Mine | no | - | - | 0 | 0 | 0 | 0 | 0 | 954 |
| L0827 | 5 | 1 | Opponent | yes | - | 2 | 3 | 7 | 0 | 0 | 0 | 0 |
| L0918 | 6 | 1 | Mine | no | 2 | - | 0 | 1 | 0 | 0 | 0 | 170 |
| L0918 | 6 | 1 | Opponent | no | 10 | 2 | 2 | 2 | 0 | 0 | 0 | 0 |
| L0934 | 4 | 1 | Mine | no | 2 | - | 0 | 2 | 0 | 0 | 0 | 643 |
| L0934 | 4 | 1 | Opponent | yes | 2 | 2 | 4 | 2 | 0 | 0 | 0 | 0 |
| L1026 | 6 | 1 | Mine | no | 0 | 2 | 2 | 0 | 0 | 0 | 0 | 165 |
| L1026 | 6 | 1 | Opponent | no | 4 | 2 | 4 | 0 | 1 | 0 | 0 | 0 |
| L1118 | 2 | 1 | Mine | - | - | 3 | 2 | 1 | 0 | 0 | 0 | 0 |
| L1118 | 2 | 1 | Opponent | - | - | - | 2 | 1 | 0 | 0 | 0 | 0 |
| L1135 | 1 | 1 | Mine | no | 1 | 3 | 1 | 2 | 1 | 0 | 0 | 0 |
| L1135 | 1 | 1 | Opponent | no | 0 | 2 | 3 | 2 | 0 | 0 | 0 | 0 |
| L1228 | 4 | 1 | Mine | no | 0 | 5 | 2 | 0 | 1 | 0 | 0 | 165 |
| L1228 | 4 | 1 | Opponent | no | 3 | 3 | 2 | 1 | 0 | 0 | 0 | 0 |
| L1323 | 3 | 1 | Mine | yes | 1 | - | 0 | 1 | 0 | 0 | 0 | 70 |
| L1323 | 3 | 1 | Opponent | no | 0 | 2 | 2 | 4 | 1 | 0 | 0 | 251 |
| L1418 | 2 | 1 | Mine | - | - | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L1418 | 2 | 1 | Opponent | - | - | - | 4 | 1 | 2 | 0 | 0 | 0 |
| L1435 | 1 | 1 | Mine | no | 4 | 2 | 3 | 0 | 1 | 0 | 0 | 0 |
| L1435 | 1 | 1 | Opponent | no | 0 | 1 | 2 | 0 | 0 | 0 | 0 | 0 |
| L1531 | 1 | 1 | Mine | no | 1 | 4 | 8 | 0 | 1 | 0 | 0 | 0 |
| L1531 | 1 | 1 | Opponent | no | 4 | 2 | 2 | 1 | 1 | 0 | 0 | 340 |
| L1629 | 3 | 1 | Mine | no | 2 | 2 | 3 | 1 | 0 | 0 | 0 | 80 |
| L1629 | 3 | 1 | Opponent | no | 0 | 2 | 7 | 3 | 0 | 0 | 0 | 0 |
| L1727 | 5 | 1 | Mine | yes | - | 4 | 3 | 0 | 0 | 0 | 0 | 0 |
| L1727 | 5 | 1 | Opponent | yes | - | 2 | 4 | 3 | 0 | 0 | 0 | 0 |
| L1827 | 3 | 1 | Mine | no | 2 | 4 | 2 | 1 | 0 | 0 | 0 | 0 |
| L1827 | 3 | 1 | Opponent | no | 6 | 2 | 4 | 2 | 0 | 0 | 0 | 0 |
| L1927 | 1 | 1 | Mine | no | 0 | 1 | 3 | 0 | 1 | 0 | 0 | 0 |
| L1927 | 1 | 1 | Opponent | no | 2 | 2 | 4 | 0 | 0 | 0 | 0 | 190 |
| L2029 | 1 | 1 | Mine | no | 0 | - | 1 | 1 | 1 | 0 | 0 | 420 |
| L2029 | 1 | 1 | Opponent | no | 0 | 3 | 5 | 0 | 1 | 0 | 0 | 255 |
| L2131 | 1 | 1 | Mine | yes | 3 | - | 1 | 5 | 1 | 0 | 0 | 555 |
| L2131 | 1 | 1 | Opponent | no | 1 | 2 | 3 | 0 | 1 | 0 | 0 | 170 |
| L2235 | 3 | 1 | Mine | no | 2 | 2 | 5 | 0 | 1 | 0 | 0 | 0 |
| L2235 | 3 | 1 | Opponent | no | 0 | 2 | 5 | 1 | 1 | 0 | 0 | 400 |
| L2429 | 5 | 1 | Mine | yes | - | - | 0 | 4 | 0 | 0 | 0 | 0 |
| L2429 | 5 | 1 | Opponent | yes | - | 3 | 2 | 4 | 0 | 0 | 0 | 0 |
| L2535 | 3 | 1 | Mine | no | 5 | - | 0 | 1 | 1 | 0 | 0 | 0 |
| L2535 | 3 | 1 | Opponent | no | 5 | 1 | 6 | 1 | 0 | 0 | 0 | 0 |
| L2735 | 5 | 1 | Mine | yes | - | 4 | 4 | 6 | 0 | 0 | 0 | 0 |
| L2735 | 5 | 1 | Opponent | yes | - | - | 0 | 3 | 0 | 0 | 0 | 0 |
| L3033 | 3 | 1 | Mine | yes | 8 | 2 | 1 | 2 | 2 | 0 | 0 | 0 |
| L3033 | 3 | 1 | Opponent | no | 2 | 1 | 8 | 0 | 0 | 0 | 0 | 236 |
| **Average** | | | Mine | 27% | 1.8 | 2.9 | 1.7 | 1.7 | 0.4 | 0.0 | 0.0 | 191.6 |
| **Average** | | | Opponent | 30% | 3.5 | 2.3 | 3.1 | 1.7 | 0.4 | 0.0 | 0.0 | 181.8 |

### KPIs: fa-h2h-mine-8a94331-p2

Rules off - Opponent only: FIVE ACTION, LIKELY CHARGE, FALLS SHORT, TIME ON OUR SIDE, FEATURE BUFFS, GETS AWAY CHANCE, GUN MASK, RUN DOWN, FOUR ROUNDS, CHARGE LOSSES, CHARACTER GUNS, STAND AND SHOOT, FALL BACK GOOD ORDER, AFTERMATH IN POINTS.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 19% (33 of 177) | 14% (26 of 182) | 16% (59 of 359) |
| Winner chose to follow up after the loser gave ground |  | 88% (61 of 69); on the table 93% | 97% (56 of 58); on the table 97% | 92% (117 of 127); on the table 94% |
| Winner chose to pursue after the loser fell back in good order |  | 69% (9 of 13); on the table 69% | 83% (5 of 6); on the table 83% | 74% (14 of 19); on the table 74% |
| Winner chose to pursue after the loser fled |  | 77% (10 of 13); on the table 92% | 61% (22 of 36); on the table 72% | 65% (32 of 49); on the table 78% |
| Winner chose to follow up or pursue (all three) |  | 84% (80 of 95); on the table 89% | 83% (83 of 100); on the table 87% | 84% (163 of 195); on the table 88% |
| Magic missiles tried each own turn | 50%+ | 38% (131 of 342) | 40% (62 of 156) | 39% (193 of 498) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 52% (131 of 250) | 53% (62 of 116) | 53% (193 of 366) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 68% (15 of 22) | 47% (25 of 53) | 53% (40 of 75) |
| Points that never fought | lower | 51% (36159 of 71583) | 48% (34468 of 71989) | 49% (70627 of 143572) |
|   infantry points that never fought | lower | 57% (9271 of 16324) | 65% (9109 of 14029) | 61% (18380 of 30353) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 61% (172 of 284) | 55% (164 of 297) | 58% (336 of 581) |
| Bound items with a magic missile used (at least once a game) |  | 95% (19 of 20); 1.7 uses a game | 61% (11 of 18); 1.1 uses a game | 79% (30 of 38); 1.4 uses a game |
| Bound items with another spell used |  | 67% (12 of 18); 0.6 uses a game | 50% (1 of 2); 0.1 uses a game | 65% (13 of 20); 0.3 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 55% (11 of 20); 0.3 uses a game | 29% (2 of 7); 0.1 uses a game | 48% (13 of 27); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 57% (34108 of 60231) | 50% (31326 of 63281) | 53% (65434 of 123512) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 2.1 (35%) | 0.7 (27%) | 2.8 (32%) |
| MARCHED: its unit marched | 1.0 (17%) | 0.4 (15%) | 1.4 (16%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.1 (2%) | 0.1 (1%) |
| IN COMBAT: engaged in combat | 1.1 (18%) | 0.3 (11%) | 1.3 (16%) |
| REAR RANK: in a rear rank | 0.1 (1%) | 0.2 (6%) | 0.2 (3%) |
| FLEEING: fleeing | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| GONE: slain | 1.1 (18%) | 0.5 (20%) | 1.6 (19%) |
| OFF THE TABLE: off the table or not arrived | 0.3 (6%) | 0.3 (12%) | 0.6 (8%) |
| STUPIDITY: Stupidity | 0.1 (1%) | 0.0 (1%) | 0.1 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.1 (2%) | 0.2 (6%) | 0.3 (3%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.0 | 1.6 | 1.3 | 5.4 | 0.4 | 1.1 |
| not cast | 3.9 | 3.3 | 3.7 | 8.5 | 1.9 | 20.6 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.1 (2%) | 0.0 (0%) | 0.0 (0%) | 1.3 (6%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (1%) | 1.8 (52%) | 0.1 (4%) | 2.8 (32%) | 0.6 (29%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.4 (16%) | 0.2 (13%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.1 (3%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.2 (5%) | 0.4 (11%) | 1.3 (16%) | 0.1 (6%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.4 (11%) | 0.3 (10%) | 0.4 (12%) | 0.2 (3%) | 0.0 (0%) | 0.0 (0%) |
| NO CASTS LEFT: every cast used on other spells | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (3%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (1%) | 0.0 (1%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.3 (1%) |
| GONE: slain | 0.9 (22%) | 0.6 (17%) | 0.9 (26%) | 1.6 (19%) | 0.3 (14%) | 3.4 (16%) |
| OFF THE TABLE: off the table or not arrived | 0.2 (6%) | 0.1 (2%) | 0.1 (3%) | 0.6 (8%) | 0.1 (6%) | 0.4 (2%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.0 (1%) | 0.0 (1%) | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (1%) | 0.2 (7%) | 0.0 (0%) | 0.0 (0%) | 0.5 (26%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (3%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.2 (58%) | 0.2 (5%) | 1.5 (41%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 15.1 (74%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.8 a game | 0.7 a game | 0.7 a game |
| stood (cast and not dispelled) | 58% (15 of 26) | 84% (21 of 25) | 71% (36 of 51) |
| the unit moved after it | 67% (10 of 15) | 43% (9 of 21) | 53% (19 of 36) |
| it charged on its next turn | 0% (0 of 15) | 10% (2 of 21) | 6% (2 of 36) |
| the enemy charged it first | 13% (2 of 15) | 10% (2 of 21) | 11% (4 of 36) |
| it fought by the end of its next turn | 0% (0 of 15) | 10% (2 of 21) | 6% (2 of 36) |
| it moved out of a charge the enemy had planned (not charged first) | 27% (4 of 15) | 0% (0 of 21) | 11% (4 of 36) |
| none of these (no charge, no fight, no charge escaped) | 60% (9 of 15) | 81% (17 of 21) | 72% (26 of 36) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 67% (574 of 863) | 56% (462 of 830) | 61% (1036 of 1693) |
|   cavalry | 77% (61 of 79) | 61% (114 of 187) | 66% (175 of 266) |
|   character | 55% (57 of 103) | 26% (28 of 109) | 40% (85 of 212) |
|   chariot | 62% (61 of 99) | 65% (33 of 51) | 63% (94 of 150) |
|   infantry | 58% (153 of 265) | 55% (169 of 309) | 56% (322 of 574) |
|   monster | 52% (23 of 44) | 49% (19 of 39) | 51% (42 of 83) |
|   war machine | 80% (219 of 273) | 73% (99 of 135) | 78% (318 of 408) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.7 (21%) | 2.3 (22%) | 4.0 (22%) |
| CHARGED: it charged | 0.8 (9%) | 1.8 (17%) | 2.5 (14%) |
| FLEEING: it fled or was fleeing | 0.2 (2%) | 0.1 (1%) | 0.3 (2%) |
| IN COMBAT: it fought this turn or the last | 0.6 (8%) | 0.4 (4%) | 1.0 (6%) |
| MOVED: a war machine that moved | 0.9 (11%) | 0.0 (0%) | 0.9 (5%) |
| NO TARGET IN RANGE | 2.0 (25%) | 2.2 (22%) | 4.2 (23%) |
| ONLY IN COMBAT: the only targets were in combat | 0.4 (5%) | 0.5 (5%) | 0.9 (5%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.1 (13%) | 2.0 (19%) | 3.1 (17%) |
| SHELTERED: the target was sheltered | 0.1 (2%) | 0.4 (4%) | 0.6 (3%) |
| OTHER BAR | 0.2 (3%) | 0.4 (4%) | 0.7 (4%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 7.5 | 1.9 | 80% | 5.8 pts | 43 pts |
| character | 2.6 | 0.9 | 73% | 9.0 pts | 23 pts |
| chariot | 2.6 | 1.2 | 72% | 14.1 pts | 37 pts |
| infantry | 12.2 | 4.3 | 75% | 9.1 pts | 111 pts |
| monster | 1.5 | 0.4 | 76% | 9.9 pts | 15 pts |
| war machine | 8.8 | 7.4 | 64% | 25.4 pts | 224 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 2.7 | 5.9 | 4.3 |
| Charges that made contact a game | 2.3 | 3.9 | 3.1 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.40 declared, 0.40 contact (25 units) | 0.77 declared, 0.38 contact (13 units) | 0.53 declared, 0.39 contact (38 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.29 declared, 0.29 contact (7 units) | 1.09 declared, 0.82 contact (11 units) | 0.78 declared, 0.61 contact (18 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.34 declared, 0.28 contact (247 units) | 0.66 declared, 0.44 contact (291 units) | 0.51 declared, 0.37 contact (538 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 55% (40 of 73) | 56% (10 of 18) | 58% (7 of 12) | 55% (57 of 103) |
| Character in a unit | 94% (32 of 34) | 74% (14 of 19) | 80% (4 of 5) | 86% (50 of 58) |
| Character on its own | 79% (30 of 38) | 69% (24 of 35) | 23% (14 of 61) | 51% (68 of 134) |
| Chariot | 71% (12 of 17) | 54% (7 of 13) | - | 63% (19 of 30) |
| Infantry | 46% (43 of 94) | 59% (20 of 34) | 33% (1 of 3) | 49% (64 of 131) |
| Monster | 48% (14 of 29) | 78% (7 of 9) | - | 55% (21 of 38) |
| Monstrous | 57% (8 of 14) | 50% (7 of 14) | - | 54% (15 of 28) |
| War Machines | 70% (40 of 57) | 100% (2 of 2) | - | 71% (42 of 59) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 89% (8 of 9); on the table 89% | 32% (33 of 102) | 58% | 64% (14 of 22) | 100% (6 of 6); 4.5 uses a game | 100% (2 of 2); 1.2 uses a game | 83% (5 of 6); 1.2 uses a game |
| Chaos Dwarfs | 4 | 88% (14 of 16); on the table 94% | 50% (18 of 36) | 55% | 62% (20 of 32) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
| Dwarfen Mountain Holds | 6 | 60% (6 of 10); on the table 70% | - | 68% | 69% (37 of 54) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 7 | 100% (13 of 13); on the table 100% | 35% (17 of 48) | 62% | 63% (48 of 76) | 0.0 uses a game | 100% (2 of 2); 0.6 uses a game | 25% (1 of 4); 0.1 uses a game |
| Grand Cathay | 6 | 73% (8 of 11); on the table 100% | 52% (72 of 138) | 60% | 57% (31 of 54) | 79% (11 of 14); 5.8 uses a game | 50% (1 of 2); 0.3 uses a game | 0% (0 of 6); 0.0 uses a game |
| High Elf Realms | 4 | 100% (8 of 8); on the table 100% | 28% (5 of 18) | 37% | 33% (11 of 33) | 100% (3 of 3); 2.5 uses a game | 57% (8 of 14); 3.0 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 2 | 67% (2 of 3); on the table 67% | - | 57% | 67% (8 of 12) | 0.0 uses a game | 0.0 uses a game | 100% (2 of 2); 1.0 uses a game |
| Lizardmen | 1 | 100% (4 of 4); on the table 100% | - | 31% | 43% (3 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 4 | 82% (9 of 11); on the table 91% | 0% (0 of 18) | 53% | 64% (18 of 28) | 50% (2 of 4); 2.5 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 1 | 100% (2 of 2); on the table 100% | 8% (1 of 12) | 0% | 12% (1 of 8) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Skaven | 3 | 70% (7 of 10); on the table 70% | 22% (4 of 18) | 34% | 64% (16 of 25) | 100% (2 of 2); 2.7 uses a game | 0.0 uses a game | 100% (3 of 3); 1.0 uses a game |
| Tomb Kings of Khemri | 5 | 88% (14 of 16); on the table 94% | - | 47% | 28% (7 of 25) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 9 | 84% (26 of 31); on the table 90% | 32% (21 of 66) | 37% | 69% (37 of 54) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 9 | 85% (22 of 26); on the table 85% | 56% (10 of 18) | 47% | 52% (38 of 73) | 100% (2 of 2); 0.6 uses a game | 0.0 uses a game | 100% (1 of 1); 0.1 uses a game |
| Wood Elf Realms | 7 | 80% (20 of 25); on the table 80% | 50% (12 of 24) | 41% | 60% (47 of 78) | 57% (4 of 7); 1.9 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (fa-h2h-mine-8a94331-p2, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 47% (37) | 50% (27) | 48% (64) |
| ...free all their last turn and able to turn (per game) | 0.67 | 0.53 | 1.19 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.19 | 0.11 | 0.31 |
| ...with the charger already in that arc before they moved (per game) | 0.53 | 0.25 | 0.78 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.94 | 0.94 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.89 | 0.89 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.08 | 5.39 | 5.47 |

### Quality by phase: fa-h2h-mine-8a94331-p2

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.8 | 3.3 |
| Strategy | Charge objectives carried out (made contact) | 58% (48 of 83) | 41% (85 of 207) |
| Strategy | Shoot objectives carried out (shot that target) | 38% (143 of 375) | 54% (150 of 278) |
| Strategy | Close-in objectives charged next turn | - | 17% (41 of 245) |
| Strategy | Support requests answered (helper made contact too) | 60% (3 of 5) | 46% (18 of 39) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (3 of 3) | - |
| Strategy | Hexes on a unit its side charged or shot that turn | 56% (10 of 18) | 55% (6 of 11) |
| Strategy | Joined characters whose unit fought | 6% (3 of 48) | 20% (8 of 40) |
| Strategy | Lone characters that fought | 63% (61 of 97) | 64% (53 of 83) |
| Movement | Charges halted short of contact | 0.0 | 0.2 |
| Movement | Idle units | 1.7 | 1.7 |
| Movement | Points that never moved of their own | 191.6 | 181.8 |
| Movement | Fights charged into per game | 2.1 | 3.3 |
| Movement | Charges with odds: long shots (under 50%) | 7 of 61, net +77 | 26 of 105, net +55 |
| Movement | Charges with odds: sweet spot (55-75%) | 19 of 61, net +15 | 19 of 105, net +131 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 3 of 61, net +98 | 13 of 105, net +82 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 19 of 61, net +167 | 24 of 105, net +124 |
| Shooting | Shots by shooting units (incl. breath weapons) | 10.7 | 11.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 38% (145 of 385) | 42% (164 of 395) |
| Shooting | Points destroyed by shooting units | 97.4 | 76.1 |
| Shooting | War machine shots | 6.1 | 2.8 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 67% (146 of 219) | 49% (49 of 99) |
| Shooting | Points destroyed by war machines | 80.1 | 43.7 |
| Magic | Magic missiles cast | 2.2 | 1.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 36% (29 of 80) | 32% (15 of 47) |
| Magic | Wounds caused by magic missiles | 4.2 | 2.3 |
| Magic | Wounds caused by other spells | 0.7 | 0.8 |
| Magic | Points destroyed by magic (all spells) | 52.2 | 74.2 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.9 / 0.6 / 0.3 / 0.1 | 2.0 / 0.3 / 0.2 / 0.2 |
| Combat | Points destroyed in combat | 260.0 | 308.8 |
| Combat | Points run down | 49.8 | 99.2 |
| Combat | Net points per charged fight, damage counted | +83 | +94 |
| Combat | Net per 100 charger points, damage counted | +28.5 | +34.3 |
| Combat | First round won (charged fights) | 77% | 66% |
| Combat | Net points per charged fight | +77 | +101 |
| Combat | Net points per supported fight / lone fight | +95 / +75 | +198 / +82 |
| Combat | Charged fights on a top-3 enemy unit | 33 of 74 | 42 of 119 |
| Game | Points lost | 820.9 | 594.4 |
| Game | VP from objectives | 489.4 | 698.3 |
| Game | Lone holders (player turns) | 1.8 | 3.5 |

- Mine won / drew / lost: 12 / 5 / 19 of 36 ended games (of 36); mean margin (Mine - Opponent) -442 VP
- The side that went first won 20 of 31 games with a winner
- Points traded per game (both sides' losses): 1415
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: fa-h2h-mine-8a94331-p2

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 0.5 | +0.0 | 0.0 | 0.0 |
| ADVANCE WORTH | - | - | - | - | 4.9 | -118.5 | 123.2 | 175.4 |
| AFTERMATH IN POINTS | 0.3 | +15.7 | 0.0 | 15.2 | - | - | - | - |
| ALREADY CARRIED | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARRIVAL HUNT | 0.0 | +0.0 | 0.0 | 2.5 | 0.1 | +2.7 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.1 | +0.0 | 0.0 | 45.6 | 0.4 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | 0.6 | +2.9 | 0.0 | 16.6 | 0.4 | +1.6 | 0.0 | 3.5 |
| BEST FACING | - | - | - | - | 0.2 | +5.7 | 0.0 | 0.0 |
| BEST FIRST | - | - | - | - | 1.1 | +74.9 | 8.2 | 42.5 |
| BEST OVERALL | - | - | - | - | 0.4 | +13.9 | 0.0 | 8.5 |
| BEST PREY | - | - | - | - | 1.0 | +47.4 | 33.5 | 48.0 |
| BEST PRIZE | 0.0 | -1.0 | 0.0 | 0.0 | 0.2 | -20.6 | 7.3 | 8.3 |
| BIG CHARACTER SAFETY | - | - | - | - | 0.1 | +0.0 | 0.0 | 0.0 |
| BLOCKED CHARGE SKIPPED | - | - | - | - | 0.1 | +0.0 | 0.0 | 0.0 |
| BLOCKED WHEEL | - | - | - | - | 0.4 | +7.3 | 0.0 | 0.0 |
| BLOWS WHERE AIMED | 0.3 | -29.4 | 49.5 | 11.4 | 0.4 | -67.0 | 70.0 | 25.1 |
| BOMBING RUN | 0.1 | +1.1 | 0.0 | 0.0 | - | - | - | - |
| BOUND ASSAILMENT | 0.1 | +0.0 | 0.0 | 19.6 | - | - | - | - |
| CANNON PLAN MISSED | 0.8 | +0.0 | 134.2 | 15.1 | 0.4 | +0.0 | 27.8 | 3.5 |
| CANNON PLANNED TARGET | 4.7 | +169.7 | 422.9 | 92.8 | 2.1 | +81.9 | 165.4 | 3.5 |
| CANNON SIGHT KEPT | 1.3 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT COUNTER | 0.1 | +0.0 | 2.5 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT SET-UP | - | - | - | - | 0.3 | -2.4 | 26.9 | 5.2 |
| CAST JOB | 0.6 | +15.4 | 7.0 | 2.4 | 0.4 | +6.7 | 25.2 | 11.1 |
| CASTER AWAY FROM SCREEN | 0.3 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.2 | +15.5 | 1.7 | 0.0 | 0.4 | +19.8 | 16.4 | 0.0 |
| CASTS AFTER FRIENDS | 0.4 | +0.0 | 0.0 | 13.9 | 0.6 | +0.0 | 0.0 | 39.4 |
| CASTS FROM BEHIND | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.1 | +2.8 | 0.0 | 0.0 | - | - | - | - |
| CATCH ODDS | - | - | - | - | 0.0 | +2.1 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | 0.4 | +14.0 | 0.0 | 6.5 | 1.1 | +62.8 | 0.0 | 23.4 |
| CHAFF PASSED | 0.4 | -0.8 | 2.9 | 11.1 | 0.3 | -0.1 | 0.0 | 4.9 |
| CHARACTER GUNS | 0.5 | +0.0 | 0.0 | 7.2 | - | - | - | - |
| CHARGE LOSSES | 11.1 | -477.0 | 0.0 | 361.5 | - | - | - | - |
| CHARGE NOW FIRST | 1.6 | +0.0 | 175.1 | 61.3 | 2.7 | +0.0 | 299.2 | 56.3 |
| CHARGE NOW WEIGHED | - | - | - | - | 0.4 | -32.1 | 9.2 | 14.7 |
| CHARGER SLAIN LOST | 0.2 | -7.3 | 28.3 | 53.7 | 0.7 | -14.6 | 72.9 | 8.3 |
| CHEAP HELPER | 0.1 | +0.0 | 1.5 | 0.0 | 0.3 | +0.0 | 14.2 | 2.2 |
| COMBAT PIVOT | 0.4 | +0.0 | 11.5 | 66.9 | 0.5 | +0.0 | 32.4 | 28.8 |
| CONTINUE AHEAD WEIGHED | - | - | - | - | 0.1 | +0.0 | 6.7 | 0.0 |
| CONVEYANCE SEARCH | 0.5 | +18.4 | 11.2 | 12.5 | 0.6 | +55.7 | 25.2 | 59.0 |
| COVER ONCE | 10.2 | -857.3 | 0.0 | 248.1 | 6.4 | -487.4 | 0.0 | 110.4 |
| DEFENSIVE ARMY | 0.1 | +0.0 | 0.0 | 5.8 | 0.2 | +0.0 | 26.6 | 7.2 |
| EDGE GIVE GROUND | 0.1 | +9.8 | 8.3 | 0.0 | 0.4 | +9.5 | 18.7 | 18.9 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | - | - | - | - | 0.9 | +55.5 | 0.0 | 29.9 |
| FALL BACK GOOD ORDER | 1.6 | +5.1 | 131.8 | 74.8 | - | - | - | - |
| FALLBACK BY WORTH | 0.0 | +0.0 | 0.0 | 0.0 | 5.2 | +58.5 | 0.0 | 97.4 |
| FALLS SHORT | 0.1 | -0.9 | 0.0 | 0.0 | - | - | - | - |
| FEATURE BUFFS | 1.1 | +25.8 | 0.0 | 8.5 | - | - | - | - |
| FIGHT LIFT | 0.1 | +0.1 | 0.0 | 0.0 | 0.0 | +0.5 | 0.0 | 0.0 |
| FIRE AND FLEE | 0.1 | +1.0 | 0.0 | 0.0 | - | - | - | - |
| FIVE ACTION | 44.4 | +2210.0 | 963.3 | 847.7 | - | - | - | - |
| FLANK NOT WEIGHED | 6.1 | +0.0 | 0.0 | 216.0 | 4.7 | +0.0 | 0.0 | 150.6 |
| FOCUS FIRE | 0.0 | +0.9 | 0.0 | 2.9 | 0.1 | +1.2 | 3.8 | 0.0 |
| FOLLOW UP WEIGHED | 0.8 | +201.5 | 0.0 | 46.2 | 0.8 | +92.8 | 0.0 | 37.4 |
| FOUR ROUNDS | 2.3 | +157.0 | 225.6 | 80.9 | - | - | - | - |
| FRIENDS SHOTS CHECKED | 0.2 | +8.5 | 0.0 | 0.0 | 0.1 | +2.8 | 0.0 | 5.1 |
| GIVES UP | - | - | - | - | 0.2 | -1.3 | 16.1 | 0.0 |
| GIVES UP ITS SCREEN | - | - | - | - | 0.0 | -0.1 | 0.0 | 1.2 |
| GUN MASK | 0.4 | +4.5 | 0.0 | 0.0 | - | - | - | - |
| HELPER ALREADY ASKED | - | - | - | - | 0.1 | +0.0 | 12.6 | 0.0 |
| HELPER UNSEEN | 0.1 | +0.0 | 4.7 | 17.1 | 0.7 | +0.0 | 47.7 | 3.8 |
| HILL BY ITS CHANCE | - | - | - | - | 0.8 | -77.7 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 1.9 | -62.1 | 192.4 | 13.7 | 11.4 | -227.7 | 540.4 | 213.7 |
| HORN WORTH | - | - | - | - | 0.0 | +0.1 | 0.0 | 0.0 |
| HUNT ADVANCE | - | - | - | - | 0.3 | +6.1 | 15.8 | 8.9 |
| HUNT DROPPED | - | - | - | - | 0.3 | +0.0 | 6.9 | 3.9 |
| HUNT IN PAIRS | 0.2 | +19.3 | 0.0 | 22.1 | 0.6 | +53.0 | 0.0 | 41.6 |
| HUNT KEPT | - | - | - | - | 0.3 | +7.6 | 14.3 | 0.0 |
| HUNT RESULT | 0.0 | +6.1 | 0.0 | 0.0 | 0.5 | +30.1 | 15.0 | 10.8 |
| HUNT THE GUNS | 0.0 | +6.3 | 5.4 | 0.0 | 0.6 | +165.6 | 15.8 | 8.9 |
| IDLE COST | 15.9 | -255.4 | 0.0 | 167.8 | 19.9 | -305.1 | 0.0 | 239.2 |
| INVITES THE FIGHT | - | - | - | - | 0.8 | +6.2 | 23.8 | 36.2 |
| JOINT CHARGE PLAN | - | - | - | - | 0.1 | +6.5 | 0.0 | 6.0 |
| JOINT KNOWS CHALLENGE | 0.0 | -0.3 | 0.0 | 0.0 | 0.1 | -1.7 | 0.0 | 12.9 |
| KEEP FALLS | 0.1 | +1.2 | 0.0 | 6.1 | - | - | - | - |
| KEEPS ITS PREY | - | - | - | - | 0.1 | +0.0 | 0.0 | 0.0 |
| KEEPS ITS TARGET | - | - | - | - | 2.7 | +80.0 | 253.6 | 52.1 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| KILLS COUNT | 0.8 | +41.8 | 73.5 | 15.9 | 2.3 | +88.9 | 170.9 | 47.2 |
| KILLS COUNT NEXT TURN | - | - | - | - | 7.3 | +298.4 | 306.6 | 119.1 |
| LONE CHARACTER SAFE SPOT | 0.0 | +0.0 | 1.9 | 2.4 | 0.2 | +3.7 | 11.3 | 7.7 |
| LONE WIZARD HOLDS BACK | - | - | - | - | 0.3 | +0.0 | 8.1 | 5.3 |
| LONE WIZARD KEPT IN | 0.6 | +39.4 | 0.0 | 0.0 | 0.3 | +23.5 | 0.0 | 0.0 |
| LONG SHOT | 0.2 | +3.9 | 15.3 | 5.1 | 0.6 | -1.0 | 42.6 | 2.8 |
| LOST CHARGE | 0.1 | -0.6 | 12.4 | 0.0 | 2.0 | -37.6 | 21.8 | 79.6 |
| LURE BY WHAT IT DRAWS | - | - | - | - | 0.1 | -14.4 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 0.3 | +2.7 | 0.0 | 10.6 | 0.7 | +61.8 | 22.5 | 9.1 |
| MANOEUVRE | 0.8 | +10.9 | 0.0 | 18.9 | 0.2 | +1.1 | 0.0 | 6.5 |
| MARCH AT ESCAPER | 0.1 | +0.3 | 0.0 | 0.0 | 0.1 | +0.6 | 0.0 | 5.4 |
| MARCH CHECK | 0.4 | +18.0 | 0.0 | 10.1 | 0.4 | +4.0 | 0.0 | 9.6 |
| MARCH ODDS | 0.0 | +0.3 | 0.0 | 0.0 | 0.2 | +22.1 | 4.6 | 0.0 |
| MARCH OVER CASTS | 0.7 | +70.5 | 0.0 | 24.1 | 0.2 | +20.2 | 0.0 | 5.4 |
| MAX FOR POSITIONING | 7.1 | +88.2 | 0.0 | 200.2 | 7.1 | +99.8 | 0.0 | 106.9 |
| MISSILES IN THE MOVE | 4.4 | +126.2 | 0.0 | 143.8 | 2.9 | +70.5 | 0.0 | 81.9 |
| MISSILES NEXT TURN | 5.3 | +81.8 | 0.0 | 176.2 | 3.2 | +47.7 | 0.0 | 94.0 |
| MODEL FACING | 0.2 | +78.4 | 0.0 | 3.3 | 0.3 | +92.1 | 0.0 | 3.3 |
| MONSTER WIZARD ROAMS | - | - | - | - | 0.1 | +0.0 | 0.0 | 12.1 |
| MOVE AND CAST | - | - | - | - | 0.3 | +10.3 | 0.0 | 11.6 |
| MOVE SPELL IN RANGE | 0.1 | +4.3 | 0.0 | 16.1 | 0.0 | +1.1 | 0.0 | 7.6 |
| MOVE SPELL NOT WORTH | 0.0 | -0.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.3 | -16.3 | 0.0 | 0.0 | 0.2 | -5.0 | 0.0 | 18.9 |
| MOVE SPELL SPOT | 0.1 | +0.0 | 0.0 | 16.1 | 0.1 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE | - | - | - | - | 5.7 | +405.8 | 202.4 | 97.0 |
| MOVES UNITS SPELL | 0.1 | +3.4 | 0.0 | 0.0 | - | - | - | - |
| NEEDED THERE | - | - | - | - | 0.1 | +11.9 | 0.0 | 0.0 |
| NO RALLY LEFT | - | - | - | - | 0.0 | +7.9 | 0.0 | 0.0 |
| NOT NEEDED | - | - | - | - | 0.5 | -14.1 | 47.9 | 3.5 |
| NOT TURNED | 0.1 | +0.3 | 0.0 | 0.0 | 5.4 | +63.1 | 0.0 | 142.6 |
| NOT WORTH A CAST | 0.6 | -0.5 | 0.0 | 2.4 | 0.7 | -0.5 | 0.0 | 0.0 |
| OFF BEST | 1.8 | -31.5 | 0.0 | 23.2 | 18.0 | -898.4 | 4.6 | 303.2 |
| ONE FIGHT FORMULA | 8.6 | -159.8 | 0.0 | 265.1 | 9.1 | -187.0 | 22.3 | 234.6 |
| ONE OBJECTIVE FORMULA | 2.6 | -30.1 | 0.0 | 26.9 | 2.7 | -161.2 | 0.0 | 22.8 |
| OPENS A LANE | 0.0 | +0.0 | 3.1 | 4.6 | 0.1 | +0.9 | 3.8 | 0.0 |
| OPENS UP | 0.2 | +8.2 | 11.7 | 0.0 | 0.2 | +15.3 | 11.4 | 0.0 |
| OVERRUNS AWAY | 0.4 | +7.1 | 54.6 | 6.8 | 0.6 | +12.9 | 51.6 | 34.8 |
| PATHS CROSS | 1.8 | +107.8 | 0.0 | 33.3 | 3.1 | +203.1 | 0.0 | 44.1 |
| PERIAPT WORTH | 0.1 | +5.6 | 0.0 | 0.0 | 0.0 | +0.2 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.2 | -3.2 | 0.0 | 0.0 | 0.1 | -2.6 | 0.0 | 0.0 |
| PLAN RESULT | 39.8 | +898.9 | 575.2 | 1102.3 | 42.9 | +1361.4 | 1756.9 | 842.7 |
| PURSUES BIG PREY | 0.1 | -0.6 | 0.0 | 0.0 | 0.1 | -3.5 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE NEXT TURN | - | - | - | - | 0.0 | +2.4 | 0.0 | 0.0 |
| RANDOM MOVE BY FIGURES | 0.6 | +13.2 | 0.0 | 22.6 | 1.5 | +13.0 | 0.0 | 22.2 |
| RANDOM MOVER NO PROMISE | - | - | - | - | 0.1 | -8.8 | 19.7 | 0.0 |
| REDIRECT BY WHAT IT STOPS | 0.1 | -5.9 | 0.0 | 0.0 | 0.8 | -17.5 | 0.0 | 18.5 |
| REDIRECT COUNTER | 2.3 | +111.8 | 0.0 | 43.8 | 3.8 | +250.0 | 0.0 | 34.7 |
| REDIRECT WEIGHED | 0.1 | +2.7 | 0.0 | 0.0 | 0.4 | +5.0 | 11.8 | 2.5 |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 30.0 |
| RESERVE FALL BACK | 0.4 | +8.9 | 0.0 | 8.3 | 1.7 | +50.4 | 0.0 | 27.5 |
| RESTRAINS TO SHOOT | 0.1 | +5.7 | 0.0 | 1.8 | 0.1 | +2.5 | 0.0 | 5.1 |
| RISK BY ARC | 1.7 | +57.6 | 171.8 | 80.9 | 3.1 | +43.8 | 240.1 | 90.2 |
| RISK ONCE | - | - | - | - | 3.8 | +175.4 | 60.4 | 327.8 |
| RUN DOWN | 1.6 | -19.2 | 130.6 | 63.0 | - | - | - | - |
| SAFE SURE CHARGE | - | - | - | - | 0.0 | -2.0 | 0.0 | 0.0 |
| SAFER THAN THE JOB | - | - | - | - | 0.9 | +48.5 | 0.0 | 12.0 |
| SCOUT SPOT | 0.3 | +0.9 | 0.0 | 0.0 | 0.5 | +2.4 | 0.0 | 1.8 |
| SCOUT WAITS | 0.3 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 1.8 |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 0.3 | -21.3 | 0.0 | 4.8 |
| SEARCH SPOT | 4.8 | +187.1 | 0.0 | 79.5 | 2.5 | +101.4 | 0.0 | 39.5 |
| SECOND HUNTER | - | - | - | - | 0.2 | -1.6 | 3.9 | 0.0 |
| SELF MOVE SPELL | 0.3 | +2.3 | 0.0 | 9.1 | - | - | - | - |
| SET UP TOGETHER | 0.3 | +2.7 | 0.0 | 10.6 | 2.0 | +128.1 | 65.8 | 53.1 |
| SET-UP ANY TARGET | 0.0 | +2.2 | 2.2 | 0.0 | 0.2 | +17.8 | 4.4 | 26.5 |
| SET-UP MISSED | - | - | - | - | 0.1 | +8.2 | 0.0 | 7.6 |
| SHOOTERS IN TWO RANKS | 0.4 | +0.8 | 0.0 | 0.0 | 0.3 | +0.6 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.3 | +32.0 | 38.2 | 29.0 | 1.1 | +25.4 | 21.2 | 8.4 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| SHOT REPLANNED | 0.8 | +0.0 | 194.4 | 32.3 | 0.3 | +0.0 | 56.1 | 0.0 |
| SHOTS IN THE MOVE | 16.0 | +786.7 | 0.0 | 320.9 | 12.5 | +432.8 | 0.0 | 132.2 |
| SPELL SETS UP CHARGE | 0.1 | +23.7 | 2.2 | 0.0 | 0.2 | +25.3 | 16.4 | 38.5 |
| SPELL WORTH | 0.9 | +15.3 | 56.3 | 51.1 | 1.6 | +27.0 | 106.4 | 106.4 |
| SPELLS IN THE FIGHT | 0.3 | -2.7 | 36.8 | 15.8 | 0.7 | -2.7 | 76.3 | 12.1 |
| STABLE ROLE | - | - | - | - | 12.1 | +0.0 | 339.8 | 193.0 |
| STAND AND SHOOT | 0.4 | -3.9 | 31.9 | 9.4 | - | - | - | - |
| STANDS TO CAST | - | - | - | - | 0.1 | +2.2 | 0.0 | 4.4 |
| STOPS | 0.0 | +0.4 | 5.4 | 0.0 | 0.5 | +15.2 | 10.8 | 0.0 |
| STOPS SHORT OF THE FLANK | - | - | - | - | 0.3 | +6.6 | 0.0 | 9.1 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 4.0 |
| SUPPORT NARROWED | 0.8 | +0.0 | 100.5 | 21.5 | 8.1 | -71.4 | 454.3 | 70.9 |
| SUPPORTS | - | - | - | - | 5.4 | +76.2 | 262.1 | 34.7 |
| SURE CHARGE BEATS ADVANCE | - | - | - | - | 0.1 | -3.2 | 9.9 | 5.7 |
| SURE REACH TOGETHER | 0.3 | +2.3 | 0.0 | 12.1 | 1.0 | +7.5 | 16.5 | 23.9 |
| THROUGH LINE OF FIRE | - | - | - | - | 0.2 | +11.4 | 0.0 | 0.0 |
| TIME ON OUR SIDE | 2.1 | +0.0 | 6.6 | 36.9 | - | - | - | - |
| TURN WORTH | 0.1 | -3.9 | 3.2 | 0.0 | 0.1 | -4.9 | 6.6 | 2.9 |
| TWO OR MORE ARRIVE | - | - | - | - | 0.2 | +2.8 | 14.6 | 0.0 |
| WAIT AFTER COSTS | - | - | - | - | 9.2 | -464.2 | 280.1 | 186.4 |
| WALKS TO THE FIGHT | - | - | - | - | 1.6 | +10.0 | 20.2 | 17.8 |
| WAR ENGINE CHARGES | 0.1 | +11.6 | 25.0 | 8.6 | 0.0 | +5.3 | 0.0 | 3.8 |
| WAR ENGINE JOBS | 0.1 | +0.0 | 3.3 | 0.0 | 0.5 | +0.0 | 7.6 | 8.9 |
| WEARS DOWN | 1.0 | +64.4 | 106.5 | 56.4 | 1.5 | +36.7 | 173.6 | 41.2 |
| WHO HITS BACK | 0.3 | +33.5 | 0.0 | 19.3 | 0.2 | +11.9 | 0.0 | 8.4 |
| WHOLE FIGHT | 0.2 | +2.6 | 27.7 | 21.7 | 0.3 | +16.4 | 46.0 | 6.4 |
| WHOLE FIGHT GAIN | 0.1 | +1.8 | 5.0 | 4.0 | 1.0 | +76.2 | 100.9 | 26.8 |
| WIDER SPREAD | 1.6 | -6.7 | 168.8 | 67.5 | 4.0 | -5.6 | 375.6 | 55.2 |
| WOUNDED STAYS OUT | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |

### Rule changes: fa-h2h-mine-8a94331-p2

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 710 | 710 | 710 | 19.72 | -33476 | -47.1 |
| SEARCH SPOT | 260 | 260 | 252 | 7.00 | +10386 | +41.2 |
| PATHS CROSS | 175 | 175 | 175 | 4.86 | +11191 | +63.9 |
| SHOTS IN THE MOVE | 1027 | 772 | 122 | 3.39 | +3795 | +31.1 |
| MOVE TO CHARGE | 204 | 204 | 118 | 3.28 | +5803 | +49.2 |
| COVER ONCE | 600 | 375 | 104 | 2.89 | +1618 | +15.6 |
| IDLE COST | 1291 | 685 | 90 | 2.50 | +947 | +10.5 |
| KILLS COUNT NEXT TURN | 264 | 264 | 87 | 2.42 | +2650 | +30.5 |
| RESERVE FALL BACK | 77 | 77 | 77 | 2.14 | +2132 | +27.7 |
| SUPPORTS | 194 | 194 | 77 | 2.14 | +1061 | +13.8 |
| WAIT AFTER COSTS | 333 | 333 | 73 | 2.03 | +1488 | +20.4 |
| MAX FOR POSITIONING | 510 | 404 | 71 | 1.97 | +243 | +3.4 |
| CANNON SIGHT KEPT | 70 | 70 | 70 | 1.94 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 60 | 60 | 60 | 1.67 | +10596 | +176.6 |
| MISSILES IN THE MOVE | 264 | 184 | 56 | 1.56 | +1064 | +19.0 |
| ARTILLERY RE-ROLL WEIGHED | 54 | 54 | 54 | 1.50 | +0 | +0.0 |
| CHARGE LOSSES | 398 | 398 | 54 | 1.50 | +3525 | +65.3 |
| REDIRECT COUNTER | 221 | 119 | 53 | 1.47 | +3968 | +74.9 |
| SHOOTS FROM THE BEST SPOT | 86 | 86 | 53 | 1.47 | +628 | +11.9 |
| CANNON PLANNED TARGET | 242 | 242 | 51 | 1.42 | -717 | -14.1 |
| RISK BY ARC | 171 | 165 | 43 | 1.19 | +1492 | +34.7 |
| ADVANCE LANE KEPT | 42 | 42 | 42 | 1.17 | +0 | +0.0 |
| BEST FIRST | 40 | 40 | 40 | 1.11 | +2697 | +67.4 |
| FALLBACK BY WORTH | 190 | 190 | 40 | 1.11 | +2104 | +52.6 |
| HOLDS AMBUSHERS | 40 | 40 | 40 | 1.11 | +0 | +0.0 |
| RANDOM MOVE BY FIGURES | 75 | 75 | 40 | 1.11 | +945 | +23.6 |
| SHOT REPLANNED | 37 | 37 | 37 | 1.03 | +0 | +0.0 |
| FACES THE THREAT | 34 | 34 | 34 | 0.94 | +1996 | +58.7 |
| RISK ONCE | 137 | 100 | 34 | 0.94 | +1346 | +39.6 |
| LONE WIZARD KEPT IN | 33 | 33 | 33 | 0.92 | +2266 | +68.7 |
| ADVANCE WORTH | 177 | 177 | 32 | 0.89 | +1162 | +36.3 |
| SAFER THAN THE JOB | 32 | 32 | 32 | 0.89 | +1747 | +54.6 |
| SCOUT WAITS | 32 | 32 | 32 | 0.89 | +0 | +0.0 |
| CHAFF IN THE MOVE | 53 | 44 | 31 | 0.86 | +1065 | +34.3 |
| COMBAT PIVOT | 30 | 30 | 30 | 0.83 | +0 | +0.0 |
| MARCH CHECK | 28 | 28 | 27 | 0.75 | +383 | +14.2 |
| CHAFF PASSED | 26 | 26 | 26 | 0.72 | -32 | -1.2 |
| SET UP TOGETHER | 83 | 69 | 26 | 0.72 | +1544 | +59.4 |
| ONE FIGHT FORMULA | 635 | 383 | 25 | 0.69 | +326 | +13.0 |
| SHOOTERS IN TWO RANKS | 25 | 25 | 25 | 0.69 | +50 | +2.0 |
| FOUR ROUNDS | 82 | 82 | 24 | 0.67 | +1965 | +81.9 |
| WHOLE FIGHT GAIN | 39 | 37 | 24 | 0.67 | +908 | +37.8 |
| CHARGE NOW FIRST | 153 | 153 | 23 | 0.64 | -1185 | -51.5 |
| HONEST WORTH | 477 | 473 | 23 | 0.64 | +95 | +4.1 |
| KILLS COUNT | 111 | 106 | 23 | 0.64 | +971 | +42.2 |
| WALKS TO THE FIGHT | 56 | 56 | 21 | 0.58 | +90 | +4.3 |
| MODEL FACING | 20 | 20 | 20 | 0.56 | +6139 | +306.9 |
| WHO HITS BACK | 19 | 19 | 19 | 0.53 | +1260 | +66.3 |
| MANOEUVRE | 35 | 35 | 18 | 0.50 | +441 | +24.5 |
| REDIRECT WEIGHED | 18 | 18 | 18 | 0.50 | +628 | +34.9 |
| CASTER AWAY FROM SCREEN | 16 | 16 | 16 | 0.44 | +0 | +0.0 |
| CASTING BLOCK | 20 | 20 | 16 | 0.44 | +455 | +28.4 |
| BLOCKED WHEEL | 15 | 15 | 15 | 0.42 | +263 | +17.5 |
| CAST JOB | 37 | 37 | 15 | 0.42 | +128 | +8.6 |
| CASTS FROM BEHIND | 15 | 15 | 15 | 0.42 | +0 | +0.0 |
| CHARGE NOW WEIGHED | 15 | 15 | 15 | 0.42 | +1106 | +73.7 |
| BEST OVERALL | 14 | 14 | 14 | 0.39 | +500 | +35.7 |
| SHORT GUN FORWARD | 14 | 14 | 14 | 0.39 | +0 | +0.0 |
| WEARS DOWN | 92 | 91 | 14 | 0.39 | +508 | +36.3 |
| FRIENDS SHOTS CHECKED | 13 | 13 | 13 | 0.36 | +408 | +31.4 |
| HUNT IN PAIRS | 31 | 20 | 13 | 0.36 | +1016 | +78.2 |
| FEATURE BUFFS | 39 | 39 | 12 | 0.33 | +174 | +14.5 |
| MOVE AND CAST | 12 | 12 | 12 | 0.33 | +371 | +30.9 |
| ONE OBJECTIVE FORMULA | 190 | 91 | 12 | 0.33 | +460 | +38.3 |
| PIVOT GUARDS FLANK | 12 | 12 | 12 | 0.33 | -210 | -17.5 |
| STOPS SHORT OF THE FLANK | 11 | 11 | 11 | 0.31 | +237 | +21.5 |
| AFTERMATH IN POINTS | 10 | 10 | 10 | 0.28 | +565 | +56.5 |
| BEST PREY | 36 | 36 | 10 | 0.28 | +672 | +67.2 |
| BEST PRIZE | 10 | 10 | 10 | 0.28 | -1071 | -107.1 |
| FIVE ACTION | 1598 | 1598 | 10 | 0.28 | +293 | +29.3 |
| KEEPS ITS TARGET | 96 | 95 | 9 | 0.25 | +178 | +19.8 |
| MAKE SURE TOGETHER | 35 | 20 | 9 | 0.25 | +599 | +66.5 |
| OPENS UP | 13 | 13 | 9 | 0.25 | +296 | +32.9 |
| SURE REACH TOGETHER | 45 | 35 | 9 | 0.25 | +43 | +4.8 |
| THROUGH LINE OF FIRE | 8 | 8 | 8 | 0.22 | +410 | +51.3 |
| WAR ENGINE JOBS | 19 | 19 | 8 | 0.22 | -187 | -23.4 |
| MARCH ODDS | 8 | 8 | 7 | 0.19 | +168 | +24.0 |
| REFUSING RETIRES | 26 | 26 | 7 | 0.19 | -2 | -0.3 |
| STUCK PIVOT | 7 | 7 | 7 | 0.19 | +0 | +0.0 |
| SUPPORT NARROWED | 323 | 323 | 7 | 0.19 | -84 | -12.0 |
| BEST FACING | 6 | 6 | 6 | 0.17 | +207 | +34.4 |
| INVITES THE FIGHT | 27 | 27 | 6 | 0.17 | +36 | +6.0 |
| MISSILES NEXT TURN | 309 | 205 | 6 | 0.17 | +26 | +4.3 |
| BIG CHARACTER SAFETY | 5 | 5 | 5 | 0.14 | +1 | +0.3 |
| BOUND ASSAILMENT | 5 | 5 | 5 | 0.14 | +0 | +0.1 |
| PURSUES BIG PREY | 5 | 5 | 5 | 0.14 | -148 | -29.6 |
| RESTRAINS TO SHOOT | 5 | 5 | 5 | 0.14 | +293 | +58.7 |
| STOPS | 18 | 16 | 5 | 0.14 | +102 | +20.4 |
| FOCUS FIRE | 4 | 4 | 4 | 0.11 | +74 | +18.4 |
| KEEPS SCOUTS OR AMBUSH | 4 | 4 | 4 | 0.11 | +0 | +0.0 |
| LOST CHARGE | 74 | 73 | 4 | 0.11 | +154 | +38.4 |
| MOVES UNITS SPELL | 4 | 4 | 4 | 0.11 | +122 | +30.4 |
| SURE CHARGE BEATS ADVANCE | 4 | 4 | 4 | 0.11 | -115 | -28.8 |
| WHOLE FIGHT | 19 | 19 | 4 | 0.11 | +306 | +76.4 |
| CARRIES OUT SET-UP | 11 | 11 | 3 | 0.08 | -85 | -28.4 |
| DEFENSIVE ARMY | 9 | 9 | 3 | 0.08 | -113 | -37.7 |
| HUNT ADVANCE | 12 | 12 | 3 | 0.08 | +96 | +31.9 |
| KEEP FALLS | 3 | 3 | 3 | 0.08 | +279 | +93.0 |
| LONG SHOT | 31 | 31 | 3 | 0.08 | +105 | +34.9 |
| PERIAPT WORTH | 3 | 3 | 3 | 0.08 | +208 | +69.2 |
| BLOCKED CHARGE SKIPPED | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| BOMBING RUN | 2 | 2 | 2 | 0.06 | +41 | +20.4 |
| CONTINUE AHEAD WEIGHED | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| EDGE GIVE GROUND | 21 | 20 | 2 | 0.06 | +132 | +66.2 |
| FIRE AND FLEE | 2 | 2 | 2 | 0.06 | +35 | +17.3 |
| HILL BY ITS CHANCE | 27 | 27 | 2 | 0.06 | +124 | +61.9 |
| LONE WIZARD HOLDS BACK | 12 | 12 | 2 | 0.06 | -2 | -0.9 |
| STANDS TO CAST | 2 | 2 | 2 | 0.06 | -1 | -0.4 |
| WIDER SPREAD | 199 | 192 | 2 | 0.06 | +4 | +2.0 |
| BACKUP TARGETS | 37 | 19 | 1 | 0.03 | +0 | +0.0 |
| BLOWS WHERE AIMED | 25 | 24 | 1 | 0.03 | +12 | +11.8 |
| CATCH ODDS | 1 | 1 | 1 | 0.03 | -72 | -71.5 |
| CHARGER SLAIN LOST | 33 | 32 | 1 | 0.03 | +4 | +3.9 |
| FALL BACK GOOD ORDER | 58 | 58 | 1 | 0.03 | +2 | +2.4 |
| GUN MASK | 13 | 13 | 1 | 0.03 | +30 | +30.0 |
| HORN WORTH | 1 | 1 | 1 | 0.03 | +3 | +3.0 |
| JOINT CHARGE PLAN | 5 | 5 | 1 | 0.03 | +62 | +61.6 |
| NEEDED THERE | 2 | 2 | 1 | 0.03 | +0 | +0.0 |
| NO RALLY LEFT | 1 | 1 | 1 | 0.03 | +280 | +279.6 |
| OVERRUNS AWAY | 36 | 35 | 1 | 0.03 | +56 | +56.2 |
| RAIDS THE BAGGAGE NEXT TURN | 1 | 1 | 1 | 0.03 | +24 | +24.5 |
| SAFE SURE CHARGE | 1 | 1 | 1 | 0.03 | -64 | -64.5 |
| SPELLS IN THE FIGHT | 36 | 36 | 1 | 0.03 | +36 | +36.0 |
| TWO OR MORE ARRIVE | 9 | 9 | 1 | 0.03 | +10 | +10.5 |
| WAR ENGINE CHARGES | 5 | 5 | 1 | 0.03 | +78 | +77.6 |
| ALREADY CARRIED | 3 | not checked | - | - | - | - |
| ARRIVAL HUNT | 3 | 3 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 40 | 40 | 0 | 0.00 | - | - |
| CARRIES OUT COUNTER | 3 | 3 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 35 | trace | - | - | - | - |
| CATCH FLIERS | 2 | not checked | - | - | - | - |
| CHARACTER GUNS | 17 | 17 | 0 | 0.00 | - | - |
| CHEAP HELPER | 14 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 40 | not checked | - | - | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FALLS SHORT | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT LIFT | 3 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 390 | not checked | - | - | - | - |
| GIVES UP | 6 | 5 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 1 | 1 | 0 | 0.00 | - | - |
| HELPER ALREADY ASKED | 5 | not checked | - | - | - | - |
| HELPER UNSEEN | 29 | 27 | 0 | 0.00 | - | - |
| HUNT DROPPED | 10 | trace | - | - | - | - |
| HUNT KEPT | 10 | trace | - | - | - | - |
| HUNT RESULT | 19 | trace | - | - | - | - |
| HUNT THE GUNS | 22 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 3 | 2 | 0 | 0.00 | - | - |
| KEEPS ITS PREY | 3 | 3 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 9 | not checked | - | - | - | - |
| LURE BY WHAT IT DRAWS | 4 | 4 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 4 | trace | - | - | - | - |
| MARCH OVER CASTS | 30 | 30 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 5 | 5 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 4 | 1 | 0 | 0.00 | - | - |
| MOVE SPELL NOT WORTH | 1 | not checked | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 17 | trace | - | - | - | - |
| MOVE SPELL SPOT | 7 | not checked | - | - | - | - |
| NOT NEEDED | 17 | 15 | 0 | 0.00 | - | - |
| NOT TURNED | 197 | 197 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 44 | not checked | - | - | - | - |
| OPENS A LANE | 5 | 3 | 0 | 0.00 | - | - |
| PLAN RESULT | 2974 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 3 | 3 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 32 | 32 | 0 | 0.00 | - | - |
| RUN DOWN | 57 | 57 | 0 | 0.00 | - | - |
| SCOUT SPOT | 28 | 28 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 12 | 12 | 0 | 0.00 | - | - |
| SECOND HUNTER | 7 | 6 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 10 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 8 | not checked | - | - | - | - |
| SET-UP MISSED | 3 | trace | - | - | - | - |
| SPELL SETS UP CHARGE | 11 | not checked | - | - | - | - |
| SPELL WORTH | 88 | not checked | - | - | - | - |
| STABLE ROLE | 437 | 435 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 15 | 15 | 0 | 0.00 | - | - |
| TIME ON OUR SIDE | 77 | 77 | 0 | 0.00 | - | - |
| TURN WORTH | 5 | 5 | 0 | 0.00 | - | - |
| WOUNDED STAYS OUT | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: fa-h2h-mine-8a94331-p2

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 1.36 | 16.50 | 48.3 |
| FALLBACK | gate | - | 0.69 | 49.2 |
| CHARGE NOW FIRST | rule | 0.19 | 0.44 | 51.5 |
| CANNON PLANNED TARGET | rule | 0.44 | 0.08 | 49.6 |
| TURN GATE | gate | 0.03 | 0.33 | 25.8 |
| PIVOT GUARDS FLANK | rule | 0.19 | 0.14 | 17.5 |
| CHAFF PASSED | rule | 0.25 | 0.06 | 2.8 |
| BEST PRIZE | rule | 0.03 | 0.25 | 107.1 |
| AFTERMATH BAND | gate | 0.08 | 0.14 | 2.5 |
| SUPPORT NARROWED | rule | 0.03 | 0.17 | 12.0 |
| WAR ENGINE JOBS | rule | 0.03 | 0.17 | 26.7 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.06 | 0.08 | 66.0 |
| FIGHT ORDER BAND | gate | 0.08 | 0.06 | 3.0 |
| NO REASON | gate | 0.14 | - | 21.3 |
| PURSUES BIG PREY | rule | 0.06 | 0.08 | 29.6 |
| SUPPORT REQUEST | gate | - | 0.14 | 70.7 |
| SURE CHARGE BEATS ADVANCE | rule | - | 0.11 | 28.8 |
| CARRIES OUT SET-UP | rule | - | 0.08 | 28.4 |
| CHARGE NOW WEIGHED | rule | - | 0.08 | 31.5 |
| DEFENSIVE ARMY | rule | 0.06 | 0.03 | 37.7 |
| PATHS CROSS | rule | 0.03 | 0.06 | 21.3 |
| FRIENDS SHOTS CHECKED | rule | 0.03 | 0.03 | 1.7 |
| BIG CHARACTER SAFETY | rule | - | 0.03 | 4.5 |
| BLOCKED WHEEL | rule | - | 0.03 | 1.8 |
| CATCH ODDS | rule | - | 0.03 | 71.5 |
| FOLLOW UP WEIGHED | rule | - | 0.03 | 1.7 |
| LONE CHARACTER SAFE SPOT | gate | - | 0.03 | 13.0 |
| LONE WIZARD HOLDS BACK | rule | - | 0.03 | 1.9 |
| MARCH ODDS | rule | 0.03 | - | 8.7 |
| MOVE AND CAST | rule | - | 0.03 | 3.6 |
| REDIRECT WEIGHED | rule | - | 0.03 | 7.5 |
| REFUSING RETIRES | rule | 0.03 | - | 1.3 |
| SAFE SURE CHARGE | rule | - | 0.03 | 64.5 |
| STANDS TO CAST | rule | - | 0.03 | 1.6 |
| STOPS SHORT OF THE FLANK | rule | - | 0.03 | 4.5 |

### Plans: fa-h2h-mine-8a94331-p2

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.7 | 62% | 291 | 157 | 54% |
| Mine | join | 0.6 | 96% | 25 | 0 | 0% |
| Mine | move | 28.5 | 93% | 1588 | 0 | 0% |
| Mine | shoot | 8.9 | 64% | 470 | 742 | 158% |
| Mine | support | 0.0 | 100% | 0 | 0 | - |
| Opponent | advance | 12.8 | 17% | 206 | 323 | 157% |
| Opponent | charge | 4.9 | 55% | 347 | 386 | 111% |
| Opponent | close in | 6.8 | 26% | 469 | 174 | 37% |
| Opponent | hold | 5.0 | 35% | 359 | 0 | 0% |
| Opponent | join | 0.8 | 97% | 32 | 0 | 0% |
| Opponent | shoot | 6.0 | 63% | 225 | 479 | 213% |
| Opponent | support | 6.6 | 92% | 66 | 0 | 0% |

### Packages: hunt the guns, fa-h2h-mine-8a94331-p2

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.0 | 1 | 0 | 100% | 100% | 0% | 2.0 | 227 | 221 | 100% | 45 |
| Opponent | 0.6 | 21 | 3 | 11% | 22% | 17% | 2.5 | 295 | 60 | 22% | 84 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 74 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 155 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 50 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 110 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 72 |
| High Elf Realms | 0.2 | 1 | 0 | 100% | 100% | 0% | 2.0 | 227 | 221 | 100% | 0 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 40 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Ogre Kingdoms | 1.2 | 5 | 0 | 20% | 20% | 0% | 3.0 | 522 | 87 | 20% | 208 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Tomb Kings of Khemri | 2.0 | 10 | 1 | 11% | 22% | 33% | 2.5 | 133 | 39 | 22% | 14 |
| Vampire Counts | 0.2 | 2 | 0 | 0% | 50% | 0% | 2.0 | 374 | 145 | 50% | 13 |
| Warriors of Chaos | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 121 |
| Wood Elf Realms | 0.6 | 4 | 2 | 0% | 0% | 0% | - | 375 | 0 | 0% | 0 |

### Battle groups: fa-h2h-mine-8a94331-p2

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 2.3 | 25% | 67% | 5% | 0% | 15% | 0% | 0% | 80% | 5% |
| Opponent | REDIRECT COUNTER | 3.8 | 12% | 56% | 19% | 67% | 8% | 8% | 15% | 62% | 8% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: fa-h2h-mine-8a94331-p2

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 5 | 0 (5) | 0 | 0 | 84 | 20% | 2.5 | 0 (2) | - | - | - | 0 (2) |
| Mine | Chaff | 34 | 70 (34) | 17 | 53 | 58 | 47% | 2.7 | 99 (19) | 81 (7) | 5 (8) | 98 (23) | 8 (11) |
| Mine | Character | 123 | 39 (123) | 39 | 0 | 43 | 27% | 2.5 | 35 (39) | 50 (49) | 29 (12) | 55 (50) | 29 (50) |
| Mine | Clean-up | 21 | 41 (21) | 14 | 27 | 47 | 62% | 2.5 | 26 (5) | 40 (13) | 87 (3) | 64 (13) | 17 (8) |
| Mine | Fast | 1 | 0 (1) | 0 | 0 | 100 | 0% | 4.0 | - | 0 (1) | - | 0 (1) | - |
| Mine | Fast Hammer | 48 | 34 (48) | 18 | 16 | 46 | 31% | 2.5 | 25 (23) | 57 (16) | 23 (9) | 30 (29) | 40 (19) |
| Mine | Fragile | 5 | 36 (5) | 36 | 0 | 40 | 20% | 1.5 | - | 59 (3) | 0 (2) | 36 (5) | - |
| Mine | Hammer | 57 | 35 (57) | 27 | 8 | 44 | 23% | 2.5 | 11 (18) | 52 (29) | 33 (10) | 39 (38) | 29 (19) |
| Mine | Holder | 28 | 53 (28) | 22 | 31 | 26 | 43% | 3.1 | 65 (13) | 36 (7) | 49 (8) | 71 (17) | 23 (11) |
| Mine | Shooter | 41 | 101 (41) | 49 | 52 | 36 | 2% | 1.5 | 112 (5) | 78 (30) | 202 (6) | 140 (25) | 41 (16) |
| Mine | Support | 2 | 0 (2) | 0 | 0 | 66 | 50% | 3.0 | 0 (1) | 0 (1) | - | - | 0 (2) |
| Mine | War machine | 59 | 42 (59) | 42 | 0 | 53 | 3% | 1.4 | 68 (10) | 30 (37) | 63 (12) | 6 (10) | 49 (49) |
| Mine | Wizard | 22 | 3 (22) | 3 | 0 | 50 | 32% | 2.4 | 0 (6) | 0 (7) | 12 (4) | 0 (5) | 4 (12) |
| Opponent | Blocker | 2 | 76 (2) | 76 | 0 | 62 | 0% | 6.0 | 0 (1) | 204 (1) | - | 76 (2) | - |
| Opponent | Chaff | 76 | 62 (76) | 22 | 40 | 30 | 34% | 2.6 | 63 (32) | 65 (19) | 58 (25) | 83 (54) | 14 (22) |
| Opponent | Character | 97 | 60 (97) | 60 | 0 | 27 | 36% | 2.5 | 74 (43) | 53 (41) | 18 (5) | 56 (59) | 72 (30) |
| Opponent | Clean-up | 19 | 45 (19) | 27 | 18 | 40 | 47% | 2.7 | 39 (9) | 54 (10) | - | 56 (14) | 10 (5) |
| Opponent | Early | 2 | 0 (2) | 0 | 0 | 0 | 100% | - | - | 0 (2) | - | 0 (1) | 0 (1) |
| Opponent | Fast Hammer | 48 | 37 (48) | 27 | 11 | 38 | 23% | 2.6 | 27 (22) | 19 (16) | 94 (10) | 37 (28) | 38 (20) |
| Opponent | Fragile | 5 | 0 (5) | 0 | 0 | 58 | 60% | 2.5 | - | 0 (3) | 0 (1) | 0 (3) | 0 (1) |
| Opponent | Hammer | 70 | 30 (70) | 28 | 3 | 44 | 26% | 3.2 | 55 (17) | 21 (42) | 49 (11) | 45 (43) | 8 (27) |
| Opponent | Holder | 35 | 85 (35) | 0 | 85 | 24 | 43% | 2.8 | 45 (9) | 111 (20) | 44 (6) | 109 (22) | 44 (13) |
| Opponent | Shooter | 33 | 76 (33) | 25 | 51 | 28 | 3% | 1.9 | 81 (8) | 85 (19) | 42 (6) | 101 (22) | 39 (11) |
| Opponent | Support | 3 | 0 (3) | 0 | 0 | 0 | 100% | - | 0 (1) | 0 (2) | - | 0 (1) | 0 (2) |
| Opponent | War machine | 24 | 57 (24) | 57 | 0 | 9 | 8% | 1.5 | 13 (6) | 57 (14) | 105 (4) | 0 (3) | 65 (21) |
| Opponent | Wizard | 26 | 22 (26) | 22 | 0 | 40 | 8% | 1.6 | 0 (10) | 30 (5) | 0 (6) | 19 (7) | 0 (14) |

### Charged fights: fa-h2h-mine-8a94331-p2

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 108 | 211 | 1.0 | 1.2 | 211 | 47 | +164 | 1 of 4 | 3 of 4 | +55 | +200 |
| Mine | Chaos Dwarfs | 4 | 159 | 378 | 1.8 | 1.4 | 216 | 0 | +216 | 5 of 7 | 7 of 7 | +438 | +127 |
| Mine | Dwarfen Mountain Holds | 4 | 663 | 28 | 1.0 | 1.0 | 28 | 24 | +4 | 1 of 4 | 3 of 4 | - | +4 |
| Mine | Empire of Man | 5 | 334 | 28 | 1.0 | 1.0 | 28 | 0 | +28 | 3 of 5 | 3 of 5 | - | +28 |
| Mine | Grand Cathay | 4 | 285 | 163 | 1.8 | 1.0 | 93 | 0 | +93 | 4 of 7 | 4 of 7 | - | +93 |
| Mine | High Elf Realms | 4 | 305 | 494 | 4.5 | 1.1 | 110 | 39 | +71 | 7 of 18 | 16 of 18 | -156 | +100 |
| Mine | Kingdom of Bretonnia | 1 | 0 | 0 | 3.0 | 1.0 | 0 | 157 | -157 | 3 of 3 | 2 of 3 | - | -157 |
| Mine | Lizardmen | 1 | 231 | 924 | 3.0 | 1.0 | 308 | 0 | +308 | 2 of 3 | 1 of 3 | - | +308 |
| Mine | Ogre Kingdoms | 1 | 50 | 231 | 5.0 | 1.2 | 46 | 99 | -53 | 2 of 5 | 3 of 5 | +0 | -66 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 235 | 5.0 | 1.2 | 47 | 70 | -23 | 2 of 5 | 4 of 5 | +45 | -40 |
| Mine | Skaven | 2 | 58 | 58 | 1.5 | 1.0 | 38 | 0 | +38 | 0 of 3 | 3 of 3 | - | +38 |
| Mine | Tomb Kings of Khemri | 1 | 125 | 432 | 3.0 | 1.0 | 144 | 0 | +144 | 3 of 3 | 2 of 3 | - | +144 |
| Mine | Vampire Counts | 3 | 0 | 120 | 1.7 | 1.0 | 72 | 0 | +72 | 0 of 5 | 5 of 5 | - | +72 |
| Mine | Warriors of Chaos | 1 | 0 | 483 | 2.0 | 1.0 | 242 | 0 | +242 | 0 of 2 | 1 of 2 | - | +242 |
| **Mine** | all armies | 36 | 230 | 223 | 2.1 | 1.1 | 108 | 31 | +77 | 33 of 74 | 57 of 74 | +95 | +75 |
| Opponent | Dwarfen Mountain Holds | 2 | 174 | 84 | 2.5 | 1.4 | 34 | 12 | +22 | 0 of 5 | 2 of 5 | +84 | -20 |
| Opponent | Empire of Man | 2 | 755 | 273 | 2.0 | 1.5 | 136 | 104 | +32 | 1 of 4 | 2 of 4 | +91 | +13 |
| Opponent | Grand Cathay | 2 | 480 | 346 | 1.5 | 1.7 | 231 | 0 | +231 | 2 of 3 | 2 of 3 | +562 | +65 |
| Opponent | Kingdom of Bretonnia | 1 | 120 | 105 | 4.0 | 1.0 | 26 | 0 | +26 | 1 of 4 | 4 of 4 | - | +26 |
| Opponent | Ogre Kingdoms | 3 | 147 | 117 | 3.3 | 1.1 | 35 | 40 | -5 | 2 of 10 | 4 of 10 | +227 | -31 |
| Opponent | Skaven | 1 | 661 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Tomb Kings of Khemri | 4 | 134 | 812 | 3.5 | 1.1 | 232 | 45 | +187 | 5 of 14 | 9 of 14 | +902 | +132 |
| Opponent | Vampire Counts | 6 | 42 | 619 | 5.0 | 1.2 | 124 | 28 | +96 | 13 of 30 | 21 of 30 | +102 | +94 |
| Opponent | Warriors of Chaos | 8 | 7 | 416 | 2.4 | 1.1 | 175 | 30 | +145 | 7 of 19 | 15 of 19 | +414 | +113 |
| Opponent | Wood Elf Realms | 7 | 301 | 513 | 4.3 | 1.2 | 120 | 25 | +94 | 11 of 30 | 20 of 30 | +91 | +95 |
| **Opponent** | all armies | 36 | 194 | 437 | 3.3 | 1.2 | 132 | 31 | +101 | 42 of 119 | 79 of 119 | +198 | +82 |

### Effective charges: fa-h2h-mine-8a94331-p2

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 0 | 0 | 0 | 3 (net +200) | 0 | 1 (net +55) | 0 | 0% (0 of 4) |
| Mine | Chaos Dwarfs | 7 | 2 (net +0) | 0 | 1 (net +265) | 1 (net +0) | 0 | 2 (net +490) | 1 | 17% (1 of 6) |
| Mine | Dwarfen Mountain Holds | 4 | 0 | 0 | 1 (net +0) | 0 | 0 | 2 (net +8) | 1 | 33% (1 of 3) |
| Mine | Empire of Man | 5 | 0 | 1 (net +140) | 3 (net +0) | 0 | 0 | 0 | 1 | 75% (3 of 4) |
| Mine | Grand Cathay | 7 | 2 (net +0) | 0 | 1 (net +301) | 1 (net +0) | 1 (net +77) | 2 (net +137) | 0 | 14% (1 of 7) |
| Mine | High Elf Realms | 18 | 1 (net -199) | 0 | 6 (net +22) | 4 (net +107) | 1 (net -18) | 4 (net +224) | 2 | 38% (6 of 16) |
| Mine | Kingdom of Bretonnia | 3 | 0 | 0 | 2 (net -236) | 1 (net +0) | 0 | 0 | 0 | 67% (2 of 3) |
| Mine | Lizardmen | 3 | 2 (net +369) | 0 | 0 | 0 | 0 | 0 | 1 | 0% (0 of 2) |
| Mine | Ogre Kingdoms | 5 | 0 | 0 | 2 (net -202) | 0 | 0 | 1 (net +96) | 2 | 67% (2 of 3) |
| Mine | Orc & Goblin Tribes | 5 | 0 | 0 | 0 | 0 | 0 | 1 (net +190) | 4 | 0% (0 of 1) |
| Mine | Skaven | 3 | 0 | 0 | 0 | 1 (net +0) | 0 | 2 (net +58) | 0 | 0% (0 of 3) |
| Mine | Tomb Kings of Khemri | 3 | 0 | 0 | 1 (net +0) | 0 | 0 | 2 (net +216) | 0 | 33% (1 of 3) |
| Mine | Vampire Counts | 5 | 0 | 0 | 1 (net +0) | 1 (net +0) | 1 (net +235) | 2 (net +62) | 0 | 20% (1 of 5) |
| Mine | Warriors of Chaos | 2 | 0 | 0 | 1 (net +464) | 0 | 0 | 0 | 1 | 100% (1 of 1) |
| Opponent | Dwarfen Mountain Holds | 5 | 2 (net -30) | 0 | 0 | 3 (net +56) | 0 | 0 | 0 | 0% (0 of 5) |
| Opponent | Empire of Man | 4 | 1 (net -416) | 0 | 1 (net +140) | 1 (net +315) | 1 (net +91) | 0 | 0 | 25% (1 of 4) |
| Opponent | Grand Cathay | 3 | 1 (net +562) | 0 | 0 | 2 (net +65) | 0 | 0 | 0 | 0% (0 of 3) |
| Opponent | Kingdom of Bretonnia | 4 | 1 (net +0) | 0 | 0 | 0 | 1 (net +0) | 0 | 2 | 0% (0 of 2) |
| Opponent | Ogre Kingdoms | 10 | 3 (net +42) | 0 | 0 | 0 | 0 | 1 (net +227) | 6 | 0% (0 of 4) |
| Opponent | Tomb Kings of Khemri | 14 | 2 (net +156) | 0 | 5 (net +351) | 3 (net +57) | 0 | 4 (net +96) | 0 | 36% (5 of 14) |
| Opponent | Vampire Counts | 30 | 7 (net +153) | 1 (net -186) | 6 (net -40) | 5 (net +269) | 5 (net +64) | 5 (net +112) | 1 | 21% (6 of 29) |
| Opponent | Warriors of Chaos | 19 | 5 (net -45) | 1 (net +563) | 3 (net +110) | 1 (net +105) | 3 (net +144) | 4 (net +278) | 2 | 18% (3 of 17) |
| Opponent | Wood Elf Realms | 30 | 4 (net +14) | 2 (net +333) | 4 (net +128) | 4 (net +115) | 3 (net +76) | 10 (net +71) | 3 | 15% (4 of 27) |

### Charged fights, damage counted: fa-h2h-mine-8a94331-p2

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 7 | 321 | 329 | +77 | 105 | 68 | +38 | +11.7 |
| Mine | 50-54% | 1 | 189 | 222 | +140 | 160 | 94 | +66 | +34.8 |
| Mine | Effective (55-75%) | 19 | 274 | 245 | +15 | 123 | 74 | +49 | +17.8 |
| Mine | 76-89% | 12 | 316 | 194 | +86 | 139 | 53 | +86 | +27.2 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 19 | 295 | 183 | +167 | 199 | 12 | +188 | +63.6 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 3 | 445 | 92 | +98 | 152 | 61 | +92 | +20.6 |
| Mine | No odds | 13 | 239 | 150 | +19 | 52 | 52 | -1 | -0.3 |
| Mine | All fights | 74 | 290 | 205 | +77 | 133 | 50 | +83 | +28.5 |
| Opponent | Long shot (under 50%) | 26 | 189 | 230 | +55 | 146 | 104 | +42 | +22.2 |
| Opponent | 50-54% | 4 | 446 | 269 | +261 | 346 | 101 | +245 | +55.0 |
| Opponent | Effective (55-75%) | 19 | 278 | 226 | +131 | 173 | 70 | +104 | +37.4 |
| Opponent | 76-89% | 19 | 344 | 193 | +142 | 167 | 40 | +127 | +36.8 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 24 | 255 | 158 | +124 | 146 | 14 | +132 | +51.7 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 13 | 380 | 94 | +82 | 91 | 0 | +91 | +24.0 |
| Opponent | No odds | 14 | 206 | 130 | +25 | 59 | 35 | +24 | +11.7 |
| Opponent | All fights | 119 | 273 | 184 | +101 | 144 | 51 | +94 | +34.3 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| fa-h2h-mine-8a94331-p2 | move | 400 | 83 (21%) | 57 (14%) | 45 (11%) | 272 (68%) |
| fa-h2h-mine-8a94331-p2 | objective | 245 | 41 (17%) | 26 (11%) | 29 (12%) | 175 (71%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0106, L0122, L2429, L2535, L2735 |
| Charmed Shield | Opponent | L0425, L0827, L0934, L1026, L1727, L1827, L1927 |
| Clockwork Compass | Mine | L1228 |
| Clockwork Compass | Opponent | L0512 |
| Elixir of Power | Mine | L1118, L1135, L1927 |
| Fistful of Laurels | Mine | L1827 |
| Fistful of Laurels | Opponent | L0918, L1118, L1418 |
| Horn of the Wild Hunt | Opponent | L3033 |
| Invocation of Nehek | Mine | L2429, L2535, L2735 |
| Invocation of Nehek | Opponent | L0425, L0827, L1727, L1827, L1927 |
| Opal Amulet | Mine | L1418, L1435 |
| Periapt of Soul Exchange | Mine | L2029, L2131 |
| Periapt of Soul Exchange | Opponent | L0721 |
| Ring of Doom | Mine | L0206, L0222, L1118, L1135, L1228, L1531 |
| Ring of Doom | Opponent | L0512, L1531, L2131, L3033 |
| Ring of Jet | Mine | L1026, L1118, L1135, L1228 |
| Ring of Jet | Opponent | L0512, L0810 |
| Standard of the Fell Warrior | Mine | L1323 |
| Storm Daemon (Renegade 2.0) | Mine | L2131 |
| Storm Daemon (Renegade 2.0) | Opponent | L0721 |
| Twice-Blessed Armour | Mine | L0721, L1026 |
| Twice-Blessed Armour | Opponent | L0307, L0810 |
| Witch Hunter's Ward | Mine | L0721, L0810, L0827 |
| Witch Hunter's Ward | Opponent | L0307 |

# Doctrine scorecard: fa-h2h-opp-8a94331-p1

### Scorecard: fa-h2h-opp-8a94331-p1

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0102 | 6 | 1 | Mine | no | 4 | - | 0 | 2 | 0 | 0 | 0 | 65 |
| L0102 | 6 | 1 | Opponent | no | 3 | 1 | 0 | 4 | 0 | 0 | 0 | 0 |
| L0118 | 4 | 1 | Mine | no | 0 | - | 0 | 3 | 0 | 0 | 0 | 0 |
| L0118 | 4 | 1 | Opponent | no | 0 | - | 1 | 4 | 0 | 0 | 0 | 331 |
| L0135 | 3 | 1 | Mine | no | 0 | 2 | 1 | 2 | 0 | 0 | 0 | 77 |
| L0135 | 3 | 1 | Opponent | yes | 0 | 2 | 3 | 2 | 0 | 0 | 0 | 0 |
| L0218 | 2 | 1 | Mine | - | - | 3 | 0 | 2 | 0 | 0 | 0 | 0 |
| L0218 | 2 | 1 | Opponent | - | - | - | 1 | 1 | 0 | 0 | 0 | 0 |
| L0235 | 1 | 1 | Mine | no | 0 | 2 | 2 | 2 | 0 | 0 | 0 | 170 |
| L0235 | 1 | 1 | Opponent | no | 0 | - | 0 | 3 | 0 | 0 | 0 | 0 |
| L0319 | 1 | 1 | Mine | no | 10 | 3 | 1 | 1 | 0 | 0 | 0 | 675 |
| L0319 | 1 | 1 | Opponent | no | 0 | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| L0405 | 3 | 1 | Mine | yes | 6 | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| L0405 | 3 | 1 | Opponent | yes | 3 | - | 1 | 1 | 0 | 0 | 0 | 306 |
| L0421 | 1 | 1 | Mine | no | 0 | 3 | 3 | 1 | 0 | 0 | 0 | 0 |
| L0421 | 1 | 1 | Opponent | no | 0 | - | 2 | 5 | 0 | 0 | 0 | 355 |
| L0508 | 4 | 1 | Mine | no | 0 | 3 | 1 | 1 | 0 | 0 | 0 | 548 |
| L0508 | 4 | 1 | Opponent | no | 0 | - | 0 | 3 | 0 | 0 | 0 | 260 |
| L0524 | 2 | 1 | Mine | - | - | 2 | 2 | 0 | 0 | 0 | 0 | 1655 |
| L0524 | 2 | 1 | Opponent | - | - | - | 0 | 4 | 0 | 0 | 0 | 0 |
| L0612 | 6 | 1 | Mine | no | 0 | - | 1 | 1 | 0 | 0 | 0 | 828 |
| L0612 | 6 | 1 | Opponent | no | 1 | 2 | 2 | 0 | 1 | 0 | 0 | 0 |
| L0628 | 4 | 1 | Mine | no | 0 | 4 | 2 | 0 | 0 | 0 | 0 | 1197 |
| L0628 | 4 | 1 | Opponent | no | 1 | 4 | 1 | 1 | 0 | 0 | 0 | 127 |
| L0717 | 3 | 1 | Mine | no | 0 | 2 | 7 | 1 | 1 | 0 | 0 | 497 |
| L0717 | 3 | 1 | Opponent | yes | 2 | - | 0 | 1 | 2 | 0 | 0 | 322 |
| L0733 | 1 | 1 | Mine | no | 11 | 1 | 1 | 0 | 1 | 0 | 0 | 375 |
| L0733 | 1 | 1 | Opponent | no | 1 | 2 | 2 | 3 | 0 | 0 | 0 | 0 |
| L0823 | 1 | 1 | Mine | no | 2 | - | 0 | 1 | 0 | 0 | 0 | 560 |
| L0823 | 1 | 1 | Opponent | no | 0 | 2 | 2 | 2 | 1 | 0 | 0 | 70 |
| L0913 | 1 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 726 |
| L0913 | 1 | 1 | Opponent | no | 6 | 2 | 4 | 1 | 1 | 0 | 0 | 140 |
| L0930 | 6 | 1 | Mine | no | 0 | 3 | 1 | 0 | 0 | 0 | 0 | 375 |
| L0930 | 6 | 1 | Opponent | no | 10 | 2 | 1 | 1 | 2 | 0 | 0 | 0 |
| L1021 | 1 | 1 | Mine | no | 0 | 2 | 3 | 0 | 1 | 0 | 0 | 330 |
| L1021 | 1 | 1 | Opponent | no | 1 | - | 0 | 3 | 1 | 0 | 0 | 355 |
| L1114 | 4 | 1 | Mine | no | 0 | 2 | 1 | 0 | 0 | 0 | 0 | 330 |
| L1114 | 4 | 1 | Opponent | no | 0 | 2 | 3 | 1 | 0 | 0 | 0 | 500 |
| L1131 | 3 | 1 | Mine | no | 1 | - | 2 | 0 | 1 | 0 | 0 | 427 |
| L1131 | 3 | 1 | Opponent | no | 3 | 2 | 1 | 2 | 1 | 0 | 0 | 170 |
| L1224 | 6 | 1 | Mine | no | 7 | 4 | 1 | 0 | 0 | 0 | 0 | 330 |
| L1224 | 6 | 1 | Opponent | no | 0 | 2 | 4 | 3 | 0 | 0 | 0 | 0 |
| L1319 | 5 | 1 | Mine | yes | - | 3 | 3 | 0 | 0 | 0 | 0 | 302 |
| L1319 | 5 | 1 | Opponent | yes | - | 2 | 1 | 2 | 1 | 0 | 0 | 0 |
| L1335 | 3 | 1 | Mine | no | 1 | 2 | 3 | 0 | 2 | 0 | 0 | 140 |
| L1335 | 3 | 1 | Opponent | no | 0 | 3 | 3 | 4 | 0 | 0 | 0 | 236 |
| L1431 | 3 | 1 | Mine | yes | 14 | 3 | 2 | 0 | 0 | 0 | 0 | 0 |
| L1431 | 3 | 1 | Opponent | no | 2 | - | 2 | 0 | 0 | 0 | 0 | 340 |
| L1527 | 3 | 1 | Mine | yes | 2 | 4 | 2 | 0 | 0 | 0 | 0 | 0 |
| L1527 | 3 | 1 | Opponent | no | 0 | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L1625 | 5 | 1 | Mine | yes | - | 2 | 2 | 2 | 0 | 0 | 0 | 200 |
| L1625 | 5 | 1 | Opponent | no | - | 6 | 6 | 1 | 0 | 0 | 0 | 0 |
| L1723 | 1 | 1 | Mine | yes | 0 | 2 | 4 | 0 | 2 | 0 | 0 | 0 |
| L1723 | 1 | 1 | Opponent | no | 0 | 2 | 7 | 1 | 1 | 0 | 0 | 132 |
| L1823 | 5 | 1 | Mine | yes | - | - | 2 | 2 | 0 | 0 | 0 | 0 |
| L1823 | 5 | 1 | Opponent | yes | - | 3 | 4 | 2 | 1 | 0 | 0 | 0 |
| L1923 | 3 | 1 | Mine | no | 2 | 2 | 5 | 1 | 1 | 0 | 0 | 0 |
| L1923 | 3 | 1 | Opponent | no | 1 | 2 | 5 | 0 | 0 | 0 | 0 | 185 |
| L2025 | 3 | 1 | Mine | yes | 9 | 6 | 1 | 1 | 2 | 0 | 0 | 420 |
| L2025 | 3 | 1 | Opponent | no | 2 | 2 | 2 | 0 | 0 | 0 | 0 | 0 |
| L2127 | 3 | 1 | Mine | no | 10 | 5 | 0 | 2 | 0 | 0 | 0 | 290 |
| L2127 | 3 | 1 | Opponent | no | 3 | 2 | 5 | 4 | 1 | 0 | 0 | 60 |
| L2231 | 5 | 1 | Mine | yes | - | 1 | 6 | 1 | 0 | 0 | 0 | 0 |
| L2231 | 5 | 1 | Opponent | yes | - | - | 1 | 0 | 3 | 0 | 0 | 795 |
| L2335 | 1 | 1 | Mine | no | 5 | 3 | 4 | 2 | 0 | 0 | 0 | 185 |
| L2335 | 1 | 1 | Opponent | no | 0 | 2 | 3 | 3 | 0 | 0 | 0 | 0 |
| L2531 | 5 | 1 | Mine | yes | - | 4 | 4 | 3 | 0 | 0 | 0 | 68 |
| L2531 | 5 | 1 | Opponent | yes | - | - | 0 | 4 | 0 | 0 | 0 | 0 |
| L2730 | 6 | 1 | Mine | no | 0 | 1 | 4 | 3 | 0 | 0 | 0 | 0 |
| L2730 | 6 | 1 | Opponent | no | 2 | 2 | 2 | 0 | 0 | 0 | 0 | 0 |
| L2934 | 6 | 1 | Mine | no | 7 | - | 1 | 1 | 1 | 0 | 0 | 170 |
| L2934 | 6 | 1 | Opponent | no | 0 | 1 | 1 | 5 | 0 | 0 | 0 | 109 |
| **Average** | | | Mine | 29% | 3.1 | 2.7 | 2.1 | 1.0 | 0.3 | 0.0 | 0.0 | 303.9 |
| **Average** | | | Opponent | 21% | 1.4 | 2.2 | 2.1 | 2.0 | 0.4 | 0.0 | 0.0 | 133.1 |

### KPIs: fa-h2h-opp-8a94331-p1

Rules off - Mine only: FIVE ACTION, LIKELY CHARGE, FALLS SHORT, TIME ON OUR SIDE, FEATURE BUFFS, GETS AWAY CHANCE, GUN MASK, RUN DOWN, FOUR ROUNDS, CHARGE LOSSES, CHARACTER GUNS, STAND AND SHOOT, FALL BACK GOOD ORDER, AFTERMATH IN POINTS.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 26% (46 of 180) | 3% (5 of 182) | 14% (51 of 362) |
| Winner chose to follow up after the loser gave ground |  | 98% (46 of 47); on the table 98% | 83% (40 of 48); on the table 92% | 91% (86 of 95); on the table 95% |
| Winner chose to pursue after the loser fell back in good order |  | 90% (9 of 10); on the table 90% | 67% (4 of 6); on the table 67% | 81% (13 of 16); on the table 81% |
| Winner chose to pursue after the loser fled |  | 68% (26 of 38); on the table 84% | 61% (17 of 28); on the table 61% | 65% (43 of 66); on the table 74% |
| Winner chose to follow up or pursue (all three) |  | 85% (81 of 95); on the table 92% | 74% (61 of 82); on the table 79% | 80% (142 of 177); on the table 86% |
| Magic missiles tried each own turn | 50%+ | 34% (112 of 330) | 31% (65 of 210) | 33% (177 of 540) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 44% (112 of 256) | 40% (65 of 163) | 42% (177 of 419) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 74% (23 of 31) | 55% (31 of 56) | 62% (54 of 87) |
| Points that never fought | lower | 47% (33357 of 71484) | 46% (32710 of 71889) | 46% (66067 of 143373) |
|   infantry points that never fought | lower | 66% (11152 of 16863) | 70% (9340 of 13348) | 68% (20492 of 30211) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 54% (150 of 279) | 64% (189 of 295) | 59% (339 of 574) |
| Bound items with a magic missile used (at least once a game) |  | 95% (21 of 22); 1.8 uses a game | 75% (15 of 20); 1.3 uses a game | 86% (36 of 42); 1.6 uses a game |
| Bound items with another spell used |  | 69% (11 of 16); 0.6 uses a game | 12% (1 of 8); 0.1 uses a game | 50% (12 of 24); 0.4 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 58% (11 of 19); 0.3 uses a game | 58% (7 of 12); 0.2 uses a game | 58% (18 of 31); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 48% (28413 of 59666) | 59% (37055 of 62699) | 54% (65468 of 122365) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 2.5 (41%) | 1.5 (37%) | 3.9 (39%) |
| MARCHED: its unit marched | 1.2 (20%) | 0.8 (19%) | 1.9 (19%) |
| CHARGED: its unit charged | 0.1 (2%) | 0.1 (1%) | 0.2 (2%) |
| IN COMBAT: engaged in combat | 1.4 (22%) | 0.4 (10%) | 1.8 (18%) |
| REAR RANK: in a rear rank | 0.2 (4%) | 0.4 (10%) | 0.6 (6%) |
| FLEEING: fleeing | 0.0 (0%) | 0.2 (4%) | 0.2 (2%) |
| GONE: slain | 0.6 (9%) | 0.6 (16%) | 1.2 (12%) |
| OFF THE TABLE: off the table or not arrived | 0.1 (2%) | 0.1 (2%) | 0.2 (2%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.1 (1%) | 0.1 (1%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.4 | 1.3 | 1.6 | 4.9 | 0.8 | 1.2 |
| not cast | 3.6 | 2.9 | 3.1 | 10.1 | 1.5 | 22.8 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.5 (7%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.6 (53%) | 0.3 (9%) | 3.9 (39%) | 0.5 (31%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.9 (19%) | 0.3 (18%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (2%) | 0.1 (4%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (1%) | 0.2 (6%) | 0.2 (8%) | 1.8 (18%) | 0.3 (20%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.2 (8%) | 0.4 (13%) | 0.6 (6%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.2 (5%) | 0.0 (0%) | 0.0 (0%) | 0.2 (2%) | 0.0 (0%) | 0.5 (2%) |
| GONE: slain | 0.5 (13%) | 0.3 (10%) | 0.7 (21%) | 1.2 (12%) | 0.2 (13%) | 3.2 (14%) |
| OFF THE TABLE: off the table or not arrived | 0.3 (9%) | 0.2 (6%) | 0.2 (5%) | 0.2 (2%) | 0.0 (0%) | 0.5 (2%) |
| STUPIDITY: Stupidity | 0.1 (3%) | 0.0 (1%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (1%) | 0.2 (6%) | 0.0 (0%) | 0.0 (0%) | 0.2 (15%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.5 (69%) | 0.3 (10%) | 1.3 (43%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 16.9 (74%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.4 a game | 0.4 a game | 0.9 a game |
| stood (cast and not dispelled) | 82% (36 of 44) | 50% (7 of 14) | 74% (43 of 58) |
| the unit moved after it | 69% (25 of 36) | 29% (2 of 7) | 63% (27 of 43) |
| it charged on its next turn | 0% (0 of 36) | 0% (0 of 7) | 0% (0 of 43) |
| the enemy charged it first | 8% (3 of 36) | 14% (1 of 7) | 9% (4 of 43) |
| it fought by the end of its next turn | 6% (2 of 36) | 14% (1 of 7) | 7% (3 of 43) |
| it moved out of a charge the enemy had planned (not charged first) | 8% (3 of 36) | 0% (0 of 7) | 7% (3 of 43) |
| none of these (no charge, no fight, no charge escaped) | 83% (30 of 36) | 86% (6 of 7) | 84% (36 of 43) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 64% (610 of 953) | 65% (402 of 619) | 64% (1012 of 1572) |
|   cavalry | 49% (33 of 67) | 74% (99 of 134) | 66% (132 of 201) |
|   character | 57% (77 of 134) | 38% (43 of 114) | 48% (120 of 248) |
|   chariot | 54% (56 of 103) | 78% (29 of 37) | 61% (85 of 140) |
|   infantry | 57% (186 of 325) | 65% (166 of 254) | 61% (352 of 579) |
|   monster | 62% (30 of 48) | 78% (21 of 27) | 68% (51 of 75) |
|   war machine | 83% (228 of 276) | 83% (44 of 53) | 83% (272 of 329) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.7 (28%) | 1.4 (23%) | 4.1 (26%) |
| CHARGED: it charged | 1.1 (12%) | 0.9 (15%) | 2.0 (13%) |
| FLEEING: it fled or was fleeing | 0.1 (1%) | 0.1 (2%) | 0.2 (2%) |
| IN COMBAT: it fought this turn or the last | 0.4 (4%) | 0.3 (5%) | 0.7 (4%) |
| MOVED: a war machine that moved | 0.0 (0%) | 0.2 (3%) | 0.2 (1%) |
| NO TARGET IN RANGE | 2.2 (23%) | 1.6 (27%) | 3.8 (24%) |
| ONLY IN COMBAT: the only targets were in combat | 0.7 (8%) | 0.4 (6%) | 1.1 (7%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.5 (15%) | 1.0 (17%) | 2.5 (16%) |
| SHELTERED: the target was sheltered | 0.4 (4%) | 0.1 (1%) | 0.5 (3%) |
| STUPIDITY | 0.0 (0%) | 0.1 (1%) | 0.1 (0%) |
| OTHER BAR | 0.4 (4%) | 0.0 (0%) | 0.4 (3%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 5.4 | 1.3 | 82% | 3.9 pts | 21 pts |
| character | 3.7 | 1.0 | 80% | 7.8 pts | 29 pts |
| chariot | 2.5 | 1.6 | 65% | 11.3 pts | 28 pts |
| infantry | 14.3 | 5.2 | 74% | 9.6 pts | 137 pts |
| monster | 1.6 | 0.4 | 82% | 4.2 pts | 7 pts |
| war machine | 7.6 | 5.1 | 66% | 23.4 pts | 177 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.6 | 3.8 | 4.2 |
| Charges that made contact a game | 3.5 | 2.8 | 3.1 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.00 declared, 0.86 contact (21 units) | 0.33 declared, 0.33 contact (15 units) | 0.72 declared, 0.64 contact (36 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.50 declared, 0.50 contact (4 units) | 0.56 declared, 0.33 contact (9 units) | 0.54 declared, 0.38 contact (13 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.59 declared, 0.43 contact (244 units) | 0.43 declared, 0.32 contact (293 units) | 0.50 declared, 0.37 contact (537 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 51% (36 of 70) | 62% (13 of 21) | 38% (3 of 8) | 53% (52 of 99) |
| Character in a unit | 94% (34 of 36) | 75% (18 of 24) | 50% (1 of 2) | 85% (53 of 62) |
| Character on its own | 92% (47 of 51) | 50% (18 of 36) | 34% (22 of 64) | 58% (87 of 151) |
| Chariot | 69% (11 of 16) | 50% (5 of 10) | - | 62% (16 of 26) |
| Infantry | 55% (49 of 89) | 39% (14 of 36) | 50% (1 of 2) | 50% (64 of 127) |
| Monster | 44% (14 of 32) | 70% (7 of 10) | - | 50% (21 of 42) |
| Monstrous | 82% (9 of 11) | 57% (8 of 14) | - | 68% (17 of 25) |
| War Machines | 68% (28 of 41) | 100% (1 of 1) | - | 69% (29 of 42) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 6 | 69% (9 of 13); on the table 92% | 41% (56 of 138) | 73% | 64% (21 of 33) | 100% (9 of 9); 5.7 uses a game | 100% (3 of 3); 1.5 uses a game | 89% (8 of 9); 1.3 uses a game |
| Chaos Dwarfs | 3 | 100% (5 of 5); on the table 100% | 25% (6 of 24) | 41% | 33% (8 of 24) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Dwarfen Mountain Holds | 5 | 67% (6 of 9); on the table 67% | - | 73% | 66% (27 of 41) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 6 | 87% (13 of 15); on the table 93% | 58% (21 of 36) | 61% | 64% (41 of 64) | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game | 25% (1 of 4); 0.2 uses a game |
| Grand Cathay | 5 | 86% (12 of 14); on the table 93% | 30% (32 of 108) | 42% | 41% (18 of 44) | 100% (12 of 12); 7.4 uses a game | 100% (1 of 1); 0.8 uses a game | 20% (1 of 5); 0.2 uses a game |
| High Elf Realms | 6 | 89% (17 of 19); on the table 95% | 23% (7 of 30) | 34% | 45% (22 of 49) | 100% (5 of 5); 2.5 uses a game | 44% (8 of 18); 2.2 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | 100% (4 of 4); on the table 100% | - | 50% | 50% (3 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Lizardmen | 2 | 67% (2 of 3); on the table 67% | - | 44% | 79% (11 of 14) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 3 | 100% (1 of 1); on the table 100% | 8% (1 of 12) | 73% | 86% (18 of 21) | 33% (1 of 3); 0.7 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 3 | 100% (13 of 13); on the table 100% | 6% (2 of 36) | 16% | 67% (16 of 24) | 0.0 uses a game | 0.0 uses a game | 100% (3 of 3); 1.0 uses a game |
| Skaven | 4 | 100% (7 of 7); on the table 100% | 37% (11 of 30) | 32% | 56% (19 of 34) | 100% (3 of 3); 1.8 uses a game | 0.0 uses a game | 50% (2 of 4); 0.5 uses a game |
| Tomb Kings of Khemri | 6 | 71% (20 of 28); on the table 75% | 8% (1 of 12) | 36% | 27% (8 of 30) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 8 | 83% (15 of 18); on the table 94% | 30% (16 of 54) | 40% | 68% (34 of 50) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 8 | 67% (10 of 15); on the table 67% | 30% (9 of 30) | 37% | 74% (55 of 74) | 100% (4 of 4); 1.6 uses a game | 0.0 uses a game | 50% (1 of 2); 0.1 uses a game |
| Wood Elf Realms | 6 | 62% (8 of 13); on the table 69% | 50% (15 of 30) | 43% | 58% (38 of 66) | 33% (2 of 6); 1.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |

Flank and rear charges a unit could have turned to face (fa-h2h-opp-8a94331-p1, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 43% (29) | 46% (33) | 45% (62) |
| ...free all their last turn and able to turn (per game) | 0.44 | 0.78 | 1.22 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.17 | 0.03 | 0.19 |
| ...with the charger already in that arc before they moved (per game) | 0.33 | 0.61 | 0.94 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 1.58 | 0.06 | 1.64 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 1.03 | 0.03 | 1.06 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 5.58 | 0.33 | 5.92 |

### Quality by phase: fa-h2h-opp-8a94331-p1

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.1 | 3.4 |
| Strategy | Charge objectives carried out (made contact) | 52% (68 of 131) | 49% (58 of 119) |
| Strategy | Shoot objectives carried out (shot that target) | 45% (194 of 429) | 54% (88 of 163) |
| Strategy | Close-in objectives charged next turn | 14% (24 of 171) | - |
| Strategy | Support requests answered (helper made contact too) | 73% (11 of 15) | 50% (8 of 16) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (2 of 2) | 67% (2 of 3) |
| Strategy | Hexes on a unit its side charged or shot that turn | 38% (3 of 8) | 73% (11 of 15) |
| Strategy | Joined characters whose unit fought | 20% (12 of 61) | 27% (10 of 37) |
| Strategy | Lone characters that fought | 75% (64 of 85) | 70% (69 of 99) |
| Movement | Charges halted short of contact | 0.3 | 0.1 |
| Movement | Idle units | 1.0 | 2.0 |
| Movement | Points that never moved of their own | 303.9 | 133.1 |
| Movement | Fights charged into per game | 2.8 | 2.6 |
| Movement | Charges with odds: long shots (under 50%) | 19 of 94, net +139 | 20 of 78, net +117 |
| Movement | Charges with odds: sweet spot (55-75%) | 12 of 94, net +111 | 18 of 78, net +101 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 9 of 94, net +62 | 3 of 78, net +41 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 26 of 94, net +118 | 13 of 78, net +142 |
| Shooting | Shots by shooting units (incl. breath weapons) | 11.3 | 11.2 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 45% (183 of 406) | 37% (149 of 404) |
| Shooting | Points destroyed by shooting units | 75.6 | 45.9 |
| Shooting | War machine shots | 6.3 | 1.2 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 43% (97 of 228) | 48% (21 of 44) |
| Shooting | Points destroyed by war machines | 97.1 | 13.9 |
| Magic | Magic missiles cast | 2.1 | 1.1 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 43% (32 of 74) | 51% (20 of 39) |
| Magic | Wounds caused by magic missiles | 4.4 | 1.9 |
| Magic | Wounds caused by other spells | 1.4 | 0.4 |
| Magic | Points destroyed by magic (all spells) | 138.7 | 34.5 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.4 / 0.3 / 0.6 / 0.2 | 1.6 / 0.5 / 0.3 / 0.1 |
| Combat | Points destroyed in combat | 326.2 | 279.2 |
| Combat | Points run down | 86.4 | 82.4 |
| Combat | Net points per charged fight, damage counted | +111 | +108 |
| Combat | Net per 100 charger points, damage counted | +38.0 | +43.5 |
| Combat | First round won (charged fights) | 75% | 67% |
| Combat | Net points per charged fight | +114 | +111 |
| Combat | Net points per supported fight / lone fight | +137 / +108 | +340 / +93 |
| Combat | Charged fights on a top-3 enemy unit | 37 of 102 | 38 of 93 |
| Game | Points lost | 538.0 | 836.4 |
| Game | VP from objectives | 663.9 | 568.9 |
| Game | Lone holders (player turns) | 3.1 | 1.4 |

- Mine won / drew / lost: 20 / 4 / 12 of 36 ended games (of 36); mean margin (Mine - Opponent) +374 VP
- The side that went first won 13 of 32 games with a winner
- Points traded per game (both sides' losses): 1374
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: fa-h2h-opp-8a94331-p1

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.6 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| ADVANCE WORTH | 5.9 | -166.2 | 190.9 | 32.2 | - | - | - | - |
| AFTERMATH IN POINTS | - | - | - | - | 0.3 | +15.6 | 0.0 | 15.2 |
| ARRIVAL HUNT | - | - | - | - | 0.0 | +0.1 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.1 | +0.0 | 0.0 | 27.9 | 0.2 | +0.0 | 0.0 | 5.3 |
| BACKUP TARGETS | 0.3 | +0.8 | 0.0 | 0.0 | 0.4 | +2.7 | 0.0 | 14.1 |
| BEST FACING | 0.2 | +5.6 | 0.0 | 5.1 | 0.0 | +0.0 | 0.0 | 0.0 |
| BEST FIRST | 1.3 | +55.4 | 45.6 | 25.9 | - | - | - | - |
| BEST OVERALL | 0.3 | +29.5 | 0.0 | 0.0 | 0.0 | +0.8 | 0.0 | 0.0 |
| BEST PREY | 0.7 | +46.1 | 2.3 | 6.6 | - | - | - | - |
| BEST PRIZE | 0.1 | -1.0 | 1.5 | 0.0 | 0.1 | -5.0 | 2.9 | 6.0 |
| BIG CHARACTER SAFETY | 0.2 | -0.6 | 0.0 | 0.0 | - | - | - | - |
| BLOCKED CHARGE SKIPPED | 0.2 | +0.0 | 5.6 | 11.9 | - | - | - | - |
| BLOCKED WHEEL | 0.4 | +11.2 | 0.0 | 0.0 | - | - | - | - |
| BLOWS WHERE AIMED | 0.3 | -44.9 | 38.0 | 6.5 | 0.2 | -14.9 | 20.6 | 0.0 |
| BOMBING RUN | 0.1 | +4.9 | 9.8 | 0.0 | - | - | - | - |
| CANNON PLAN MISSED | 1.0 | +0.0 | 110.2 | 10.7 | 0.1 | +0.0 | 13.1 | 0.0 |
| CANNON PLANNED TARGET | 4.6 | +124.1 | 351.7 | 73.3 | 1.1 | +22.2 | 52.0 | 25.4 |
| CANNON SIGHT KEPT | 1.0 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT COUNTER | 0.0 | +0.0 | 0.0 | 6.4 | 0.0 | +0.0 | 1.8 | 0.0 |
| CARRIES OUT SET-UP | 0.1 | -3.4 | 4.7 | 0.0 | 0.1 | +0.0 | 2.6 | 1.2 |
| CAST JOB | 1.1 | +52.4 | 112.4 | 12.9 | 0.2 | +5.5 | 8.3 | 15.0 |
| CASTER AWAY FROM SCREEN | 0.4 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.5 | +43.7 | 24.2 | 9.6 | 0.1 | +4.5 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 1.0 | +0.0 | 0.0 | 9.1 | 0.2 | +0.0 | 0.0 | 13.5 |
| CASTS FROM BEHIND | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CATCH ODDS | 0.1 | +1.9 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | 1.2 | +75.2 | 0.0 | 22.7 | 0.7 | +25.2 | 0.0 | 11.3 |
| CHAFF PASSED | 0.2 | -0.8 | 0.0 | 1.8 | 0.6 | -1.5 | 4.9 | 1.7 |
| CHARACTER GUNS | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CHARGE LOSSES | - | - | - | - | 10.9 | -492.7 | 0.0 | 361.3 |
| CHARGE NOW FIRST | 2.6 | +0.0 | 312.9 | 60.5 | 1.8 | +0.0 | 175.0 | 59.8 |
| CHARGE NOW WEIGHED | 0.2 | -29.3 | 9.9 | 6.6 | - | - | - | - |
| CHARGER SLAIN LOST | 0.5 | -7.6 | 82.3 | 13.8 | 0.4 | -8.7 | 41.9 | 26.3 |
| CHARIOT NO STATIC JOB | 0.1 | +0.0 | 1.1 | 0.0 | - | - | - | - |
| CHARIOT WIZARD CAREFUL | 0.1 | -5.6 | 9.5 | 0.0 | - | - | - | - |
| CHEAP HELPER | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 24.0 | 2.4 |
| COMBAT PIVOT | 0.3 | +0.0 | 9.0 | 22.4 | 0.5 | +0.0 | 22.0 | 40.9 |
| CONTINUE AHEAD WEIGHED | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | 0.7 | +67.1 | 0.0 | 11.2 | 0.2 | +39.4 | 26.2 | 28.3 |
| COVER ONCE | 8.0 | -656.2 | 0.0 | 115.0 | 5.6 | -393.1 | 0.0 | 194.0 |
| DEFENSIVE ARMY | 0.2 | +0.0 | 15.4 | 0.0 | - | - | - | - |
| DEFENSIVE FLOOR | 0.1 | +6.1 | 4.0 | 6.4 | 0.1 | +2.4 | 1.7 | 4.8 |
| EDGE GIVE GROUND | 0.2 | +18.4 | 33.4 | 2.8 | 0.1 | +5.4 | 6.9 | 0.0 |
| ELIXIR WORTH | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +2.8 | 0.0 | 0.0 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 1.6 | +122.8 | 0.0 | 48.0 | 0.1 | +2.1 | 0.0 | 0.0 |
| FALL BACK GOOD ORDER | - | - | - | - | 2.6 | +7.2 | 213.9 | 84.2 |
| FALLBACK BY WORTH | 4.4 | +81.2 | 0.0 | 25.8 | 0.2 | +0.0 | 0.0 | 2.5 |
| FALLS SHORT | - | - | - | - | 0.4 | -4.4 | 0.0 | 28.3 |
| FEATURE BUFFS | - | - | - | - | 0.2 | +3.1 | 0.0 | 1.5 |
| FIRE AND FLEE | - | - | - | - | 0.1 | +0.9 | 0.0 | 6.3 |
| FIVE ACTION | - | - | - | - | 42.9 | +2205.1 | 490.2 | 775.4 |
| FLANK NOT WEIGHED | 5.2 | +0.0 | 0.0 | 125.2 | 5.1 | +0.0 | 0.0 | 194.3 |
| FOCUS FIRE | 0.0 | +1.5 | 3.2 | 0.0 | 0.0 | +0.1 | 1.2 | 0.0 |
| FOLLOW UP WEIGHED | 1.0 | +134.4 | 0.0 | 23.5 | 0.6 | +78.2 | 0.0 | 0.0 |
| FOUR ROUNDS | - | - | - | - | 3.2 | +179.6 | 255.1 | 87.4 |
| FRIENDS SHOTS CHECKED | 0.5 | +24.4 | 0.0 | 5.7 | 0.2 | +15.3 | 0.0 | 0.0 |
| GIVES UP | 0.2 | -1.8 | 14.7 | 0.0 | 0.0 | -0.7 | 1.9 | 0.0 |
| GROUND FLIERS | 0.0 | +1.4 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| GUN MASK | - | - | - | - | 0.2 | +2.5 | 0.0 | 0.0 |
| HELPER ALREADY ASKED | 0.0 | +0.0 | 4.9 | 0.0 | - | - | - | - |
| HELPER UNSEEN | 0.3 | +0.0 | 51.4 | 11.3 | 0.4 | +0.0 | 33.3 | 10.4 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.8 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 8.3 | -157.0 | 601.0 | 83.5 | 2.6 | -105.3 | 201.3 | 68.6 |
| HUNT ADVANCE | 0.1 | +0.4 | 20.5 | 0.0 | - | - | - | - |
| HUNT DROPPED | 0.1 | +0.0 | 8.8 | 3.2 | 0.0 | +0.0 | 0.0 | 0.5 |
| HUNT IN PAIRS | 0.7 | +24.7 | 0.0 | 0.0 | 0.7 | +45.8 | 0.0 | 1.9 |
| HUNT KEPT | 0.0 | +0.0 | 5.9 | 0.0 | - | - | - | - |
| HUNT RESULT | 0.1 | +12.8 | 8.8 | 3.2 | 0.0 | +0.0 | 0.0 | 0.5 |
| HUNT THE GUNS | 0.1 | +33.3 | 19.2 | 0.0 | 0.0 | +14.3 | 0.0 | 0.5 |
| IDLE COST | 15.3 | -253.3 | 0.0 | 132.9 | 20.5 | -298.9 | 0.0 | 260.3 |
| INVITES THE FIGHT | 1.6 | +11.7 | 66.2 | 8.5 | - | - | - | - |
| JOINT CHARGE PLAN | 0.2 | +7.3 | 28.6 | 12.0 | - | - | - | - |
| JOINT KNOWS CHALLENGE | 0.1 | -2.5 | 17.5 | 0.0 | 0.1 | -3.2 | 0.0 | 1.2 |
| KEEP FALLS | 0.0 | +0.4 | 0.0 | 0.0 | 0.1 | +0.1 | 0.0 | 0.0 |
| KEEPS ITS PREY | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KEEPS ITS TARGET | 1.7 | +50.0 | 185.6 | 21.7 | - | - | - | - |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KILLS COUNT | 1.4 | +59.3 | 138.4 | 20.7 | 1.4 | +83.6 | 103.2 | 48.2 |
| KILLS COUNT NEXT TURN | 4.4 | +183.2 | 287.0 | 78.0 | - | - | - | - |
| LONE CHARACTER SAFE SPOT | 0.3 | +12.5 | 1.0 | 0.0 | 0.2 | +3.6 | 0.0 | 12.3 |
| LONE WIZARD HOLDS BACK | 0.2 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| LONE WIZARD KEPT IN | 0.7 | +49.1 | 0.0 | 0.0 | 0.2 | +24.5 | 0.0 | 0.0 |
| LONG SHOT | 0.3 | +0.3 | 52.1 | 0.0 | 0.3 | +1.2 | 38.7 | 6.3 |
| LOST CHARGE | 3.1 | -34.3 | 160.2 | 78.7 | 0.2 | -0.4 | 20.9 | 14.8 |
| LURE BY WHAT IT DRAWS | 0.2 | -21.1 | 0.0 | 3.2 | 0.0 | -1.2 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 0.7 | +99.9 | 33.3 | 14.2 | 0.2 | +2.0 | 0.0 | 13.1 |
| MANOEUVRE | 0.2 | +5.7 | 0.0 | 1.9 | 0.5 | +1.1 | 0.0 | 17.0 |
| MARCH AT ESCAPER | - | - | - | - | 0.2 | +3.4 | 0.0 | 14.4 |
| MARCH CHECK | 0.4 | +15.6 | 0.0 | 0.0 | 0.8 | +45.0 | 0.0 | 23.4 |
| MARCH ODDS | 0.2 | +14.1 | 11.6 | 0.0 | 0.0 | +0.3 | 0.0 | 0.0 |
| MARCH OVER CASTS | 0.5 | +47.8 | 0.0 | 0.0 | 0.5 | +105.9 | 0.0 | 14.4 |
| MAX FOR POSITIONING | 6.1 | +106.3 | 0.0 | 61.4 | 7.8 | +103.9 | 0.0 | 192.0 |
| MISSILES IN THE MOVE | 4.5 | +203.9 | 0.0 | 40.3 | 3.4 | +55.7 | 0.0 | 113.3 |
| MISSILES NEXT TURN | 5.1 | +118.8 | 0.0 | 44.6 | 4.3 | +39.5 | 0.0 | 144.6 |
| MODEL FACING | 0.3 | +35.5 | 0.0 | 5.0 | - | - | - | - |
| MONSTER WIZARD ROAMS | 0.1 | +0.0 | 4.9 | 0.0 | - | - | - | - |
| MOVE AND CAST | 0.4 | +32.9 | 0.0 | 10.6 | - | - | - | - |
| MOVE SPELL IN RANGE | 0.1 | +5.1 | 0.0 | 0.0 | 0.0 | +0.2 | 0.0 | 0.0 |
| MOVE SPELL OUT OF RANGE | 0.6 | -59.1 | 0.0 | 7.2 | 0.1 | -2.0 | 0.0 | 15.2 |
| MOVE SPELL SPOT | 0.5 | +0.0 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE | 3.6 | +356.7 | 220.9 | 53.6 | - | - | - | - |
| MOVES UNITS SPELL | 0.1 | +3.4 | 0.0 | 0.0 | 0.1 | +1.8 | 0.0 | 0.0 |
| NEEDED THERE | 0.1 | +6.6 | 5.4 | 0.0 | 0.1 | +16.3 | 10.3 | 0.0 |
| NO RALLY LEFT | - | - | - | - | 0.0 | +0.2 | 0.0 | 2.3 |
| NOT NEEDED | 0.4 | -10.4 | 33.4 | 3.2 | - | - | - | - |
| NOT TURNED | 5.6 | +139.6 | 0.0 | 94.4 | 0.3 | +1.6 | 0.0 | 9.6 |
| NOT WORTH A CAST | 1.4 | -2.3 | 0.0 | 2.6 | 0.1 | -0.1 | 0.0 | 0.0 |
| OFF BEST | 17.4 | -711.9 | 0.0 | 241.9 | 2.1 | -38.3 | 0.0 | 8.5 |
| ONE FIGHT FORMULA | 8.9 | -134.9 | 45.5 | 108.1 | 8.5 | -189.0 | 0.0 | 235.6 |
| ONE OBJECTIVE FORMULA | 2.4 | -65.3 | 0.0 | 22.1 | 2.0 | +15.9 | 0.0 | 45.7 |
| OPENS A LANE | 0.1 | +0.4 | 3.2 | 0.0 | 0.1 | +0.9 | 3.1 | 3.1 |
| OPENS UP | 0.1 | +1.6 | 7.9 | 0.0 | 0.2 | +12.5 | 9.2 | 0.0 |
| OVERRUNS AWAY | 0.5 | +27.1 | 69.4 | 6.5 | 0.5 | +7.3 | 33.2 | 16.2 |
| PATHS CROSS | 2.0 | +128.3 | 0.0 | 11.7 | 2.4 | +185.8 | 0.0 | 46.6 |
| PERIAPT WORTH | 0.1 | +4.3 | 0.0 | 0.0 | - | - | - | - |
| PIVOT GUARDS FLANK | 0.2 | -3.0 | 0.0 | 1.4 | 0.1 | -1.5 | 0.0 | 8.2 |
| PLAN RESULT | 39.4 | +1674.1 | 1613.1 | 694.2 | 39.7 | +517.4 | 348.1 | 1109.4 |
| PURSUES BIG PREY | 0.1 | -10.8 | 0.0 | 0.0 | - | - | - | - |
| RANDOM MOVE BY FIGURES | 0.9 | +13.7 | 0.0 | 23.3 | 1.6 | +21.0 | 0.0 | 51.8 |
| RANDOM MOVER NO PROMISE | 0.1 | -6.3 | 0.0 | 4.7 | - | - | - | - |
| REDIRECT BY WHAT IT STOPS | 0.9 | -17.7 | 0.0 | 17.0 | 0.3 | -7.4 | 0.0 | 1.9 |
| REDIRECT COUNTER | 2.1 | +113.2 | 0.0 | 29.3 | 3.7 | +271.2 | 0.0 | 76.6 |
| REDIRECT WEIGHED | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +2.1 | 2.9 | 6.0 |
| REFUSING RETIRES | 0.4 | +0.0 | 0.0 | 7.8 | 0.4 | +0.0 | 0.0 | 6.4 |
| RESERVE FALL BACK | 0.4 | +7.5 | 0.0 | 3.1 | 0.9 | +33.5 | 0.0 | 23.7 |
| RESTRAINS TO SHOOT | 0.0 | +0.7 | 0.0 | 0.0 | 0.1 | +2.5 | 0.0 | 4.4 |
| RISK BY ARC | 2.3 | +64.4 | 253.2 | 46.6 | 2.3 | +50.2 | 168.7 | 83.3 |
| RISK ONCE | 2.5 | +65.0 | 34.3 | 102.3 | - | - | - | - |
| RUN DOWN | - | - | - | - | 2.3 | -23.3 | 149.9 | 37.6 |
| SAFER THAN THE JOB | 1.0 | +59.0 | 0.0 | 6.5 | 0.0 | +0.8 | 0.0 | 0.0 |
| SCOUT SPOT | 0.4 | +0.7 | 0.0 | 0.0 | 0.3 | +0.6 | 0.0 | 0.9 |
| SCOUT WAITS | 0.4 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.9 |
| SCREEN BY WHAT IT SAVES | 0.2 | -23.9 | 0.0 | 0.9 | 0.1 | -10.3 | 0.0 | 4.8 |
| SEARCH SPOT | 2.0 | +67.3 | 0.0 | 9.7 | 5.2 | +197.1 | 0.0 | 100.3 |
| SELF MOVE SPELL | 0.2 | +33.3 | 0.0 | 18.1 | 0.1 | +0.2 | 0.0 | 9.1 |
| SET UP TOGETHER | 1.1 | +182.4 | 52.4 | 22.0 | 0.4 | +5.7 | 0.0 | 13.1 |
| SET-UP ANY TARGET | 0.2 | +23.6 | 0.0 | 0.0 | 0.1 | +9.2 | 17.4 | 20.7 |
| SET-UP MISSED | 0.1 | +5.7 | 1.8 | 0.0 | 0.1 | +21.5 | 0.0 | 0.0 |
| SHOOTER COUNTED ONCE | 0.1 | -0.2 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | 0.4 | +0.9 | 0.0 | 0.0 | 0.3 | +0.8 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.5 | +60.6 | 143.3 | 1.7 | 0.6 | +19.9 | 19.9 | 15.0 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 3.2 | 0.0 | +0.0 | 0.0 | 0.0 |
| SHOT REPLANNED | 0.7 | +0.0 | 130.9 | 6.5 | 0.4 | +0.0 | 43.3 | 14.2 |
| SHOTS IN THE MOVE | 15.2 | +626.9 | 0.0 | 160.0 | 10.8 | +244.4 | 0.0 | 189.9 |
| SPELL SETS UP CHARGE | 0.3 | +101.7 | 0.0 | 0.0 | 0.1 | +9.2 | 17.4 | 20.7 |
| SPELL WORTH | 0.8 | +19.1 | 61.5 | 61.5 | 1.9 | +35.9 | 104.0 | 100.9 |
| SPELLS IN THE FIGHT | 0.4 | -1.1 | 61.1 | 31.0 | 0.5 | -11.4 | 61.5 | 13.9 |
| STABLE ROLE | 12.3 | +0.0 | 517.0 | 131.8 | - | - | - | - |
| STAND AND SHOOT | - | - | - | - | 0.4 | -3.1 | 30.1 | 28.0 |
| STANDS TO CAST | 0.0 | +0.7 | 3.1 | 0.0 | - | - | - | - |
| STAY WEIGHED | 0.1 | +7.8 | 0.0 | 0.0 | - | - | - | - |
| STOPS | 0.0 | +2.8 | 4.6 | 0.0 | 0.0 | +0.2 | 0.0 | 0.5 |
| STOPS SHORT OF THE FLANK | 0.6 | +19.4 | 0.0 | 19.7 | - | - | - | - |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| SUPPORT NARROWED | 5.9 | -57.8 | 361.2 | 103.5 | 1.5 | +0.0 | 100.8 | 28.8 |
| SUPPORTS | 3.9 | +58.0 | 101.1 | 62.3 | - | - | - | - |
| SURE CHARGE BEATS ADVANCE | 0.1 | -1.2 | 6.2 | 0.0 | - | - | - | - |
| SURE REACH TOGETHER | 0.7 | -9.9 | 45.0 | 14.9 | 0.6 | +9.5 | 0.0 | 8.8 |
| THROUGH LINE OF FIRE | 0.6 | +30.6 | 0.0 | 0.0 | - | - | - | - |
| TIME ON OUR SIDE | - | - | - | - | 1.4 | +0.0 | 5.4 | 0.0 |
| TURN WORTH | 0.3 | -22.7 | 41.1 | 0.0 | 0.0 | -0.5 | 1.5 | 0.0 |
| TWO OR MORE ARRIVE | 0.3 | +4.2 | 4.7 | 9.2 | - | - | - | - |
| WAIT AFTER COSTS | 7.4 | -369.3 | 405.9 | 70.5 | - | - | - | - |
| WALKS TO THE FIGHT | 1.9 | +15.4 | 77.6 | 8.4 | - | - | - | - |
| WAR ENGINE CHARGES | 0.1 | +27.6 | 13.1 | 0.0 | 0.0 | +1.3 | 0.0 | 0.0 |
| WAR ENGINE JOBS | 0.6 | +0.0 | 42.8 | 9.0 | 0.1 | +0.0 | 0.0 | 4.0 |
| WEARS DOWN | 1.3 | +69.4 | 187.9 | 34.2 | 0.9 | +24.9 | 61.3 | 20.5 |
| WHO HITS BACK | 0.4 | +22.3 | 0.0 | 7.8 | 0.4 | +40.8 | 0.0 | 17.2 |
| WHOLE FIGHT | 0.4 | +22.8 | 66.6 | 0.0 | 0.4 | +22.0 | 47.7 | 5.9 |
| WHOLE FIGHT GAIN | 0.4 | +15.5 | 49.6 | 1.4 | 0.3 | +21.6 | 40.8 | 4.7 |
| WIDER SPREAD | 2.5 | -9.6 | 300.4 | 41.1 | 2.4 | -4.0 | 189.7 | 75.7 |

### Rule changes: fa-h2h-opp-8a94331-p1

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 704 | 704 | 704 | 19.56 | -27008 | -38.4 |
| SEARCH SPOT | 259 | 259 | 249 | 6.92 | +9888 | +39.7 |
| PATHS CROSS | 157 | 157 | 157 | 4.36 | +11308 | +72.0 |
| IDLE COST | 1290 | 646 | 104 | 2.89 | +1187 | +11.4 |
| SHOTS IN THE MOVE | 936 | 666 | 100 | 2.78 | +4406 | +44.1 |
| MAX FOR POSITIONING | 502 | 404 | 87 | 2.42 | +212 | +2.4 |
| MOVE TO CHARGE | 130 | 130 | 73 | 2.03 | +5648 | +77.4 |
| COVER ONCE | 488 | 262 | 64 | 1.78 | +987 | +15.4 |
| KILLS COUNT NEXT TURN | 160 | 160 | 62 | 1.72 | +1766 | +28.5 |
| CHARGE LOSSES | 392 | 392 | 60 | 1.67 | +5004 | +83.4 |
| FACES THE THREAT | 59 | 59 | 59 | 1.64 | +4495 | +76.2 |
| FOLLOW UP WEIGHED | 56 | 56 | 56 | 1.56 | +7655 | +136.7 |
| FALLBACK BY WORTH | 167 | 167 | 55 | 1.53 | +2924 | +53.2 |
| RANDOM MOVE BY FIGURES | 87 | 87 | 54 | 1.50 | +1250 | +23.1 |
| REDIRECT COUNTER | 209 | 131 | 52 | 1.44 | +3932 | +75.6 |
| SUPPORTS | 139 | 139 | 52 | 1.44 | +869 | +16.7 |
| CANNON SIGHT KEPT | 51 | 51 | 51 | 1.42 | +0 | +0.0 |
| RESERVE FALL BACK | 49 | 49 | 49 | 1.36 | +1476 | +30.1 |
| ARTILLERY RE-ROLL WEIGHED | 48 | 48 | 48 | 1.33 | +0 | +0.0 |
| FOUR ROUNDS | 114 | 114 | 48 | 1.33 | +2627 | +54.7 |
| ADVANCE LANE KEPT | 46 | 46 | 46 | 1.28 | +0 | +0.0 |
| BEST FIRST | 46 | 46 | 46 | 1.28 | +1993 | +43.3 |
| CHAFF IN THE MOVE | 71 | 69 | 46 | 1.28 | +1215 | +26.4 |
| WAIT AFTER COSTS | 267 | 267 | 46 | 1.28 | +686 | +14.9 |
| HOLDS AMBUSHERS | 44 | 44 | 44 | 1.22 | +0 | +0.0 |
| MISSILES IN THE MOVE | 283 | 168 | 44 | 1.22 | +1557 | +35.4 |
| ONE FIGHT FORMULA | 626 | 324 | 42 | 1.17 | +179 | +4.3 |
| RISK BY ARC | 166 | 165 | 42 | 1.17 | +933 | +22.2 |
| MARCH CHECK | 42 | 41 | 40 | 1.11 | +1475 | +36.9 |
| SHOT REPLANNED | 39 | 39 | 39 | 1.08 | +0 | +0.0 |
| SAFER THAN THE JOB | 38 | 38 | 38 | 1.06 | +2150 | +56.6 |
| KILLS COUNT | 101 | 101 | 37 | 1.03 | +1092 | +29.5 |
| LONE WIZARD KEPT IN | 34 | 34 | 34 | 0.94 | +2648 | +77.9 |
| CHARGE NOW FIRST | 158 | 158 | 33 | 0.92 | -1398 | -42.4 |
| WALKS TO THE FIGHT | 68 | 68 | 32 | 0.89 | +177 | +5.5 |
| ADVANCE WORTH | 213 | 213 | 31 | 0.86 | +381 | +12.3 |
| CANNON PLANNED TARGET | 204 | 204 | 31 | 0.86 | +153 | +4.9 |
| CAST JOB | 48 | 48 | 30 | 0.83 | +756 | +25.2 |
| COMBAT PIVOT | 30 | 30 | 30 | 0.83 | +0 | +0.0 |
| SHOOTS FROM THE BEST SPOT | 75 | 75 | 30 | 0.83 | +571 | +19.0 |
| WHO HITS BACK | 29 | 29 | 29 | 0.81 | +1390 | +47.9 |
| CASTER AWAY FROM SCREEN | 26 | 26 | 26 | 0.72 | +0 | +0.0 |
| CHAFF PASSED | 26 | 26 | 26 | 0.72 | -83 | -3.2 |
| SCOUT WAITS | 26 | 26 | 26 | 0.72 | +0 | +0.0 |
| FRIENDS SHOTS CHECKED | 24 | 24 | 24 | 0.67 | +1427 | +59.5 |
| SHOOTERS IN TWO RANKS | 24 | 24 | 24 | 0.67 | +58 | +2.4 |
| FIVE ACTION | 1543 | 1543 | 23 | 0.64 | +1302 | +56.6 |
| INVITES THE FIGHT | 56 | 56 | 23 | 0.64 | +182 | +7.9 |
| THROUGH LINE OF FIRE | 23 | 23 | 23 | 0.64 | +1103 | +48.0 |
| RISK ONCE | 90 | 73 | 22 | 0.61 | +335 | +15.2 |
| STOPS SHORT OF THE FLANK | 20 | 20 | 20 | 0.56 | +699 | +35.0 |
| HONEST WORTH | 392 | 392 | 17 | 0.47 | +239 | +14.0 |
| WHOLE FIGHT GAIN | 25 | 24 | 17 | 0.47 | +394 | +23.2 |
| MOVE AND CAST | 16 | 16 | 16 | 0.44 | +1184 | +74.0 |
| SET UP TOGETHER | 53 | 39 | 16 | 0.44 | +2662 | +166.4 |
| CASTING BLOCK | 24 | 24 | 14 | 0.39 | +739 | +52.8 |
| CASTS FROM BEHIND | 14 | 14 | 14 | 0.39 | +0 | +0.0 |
| MANOEUVRE | 26 | 26 | 14 | 0.39 | +245 | +17.5 |
| WEARS DOWN | 80 | 79 | 14 | 0.39 | +319 | +22.8 |
| BLOCKED WHEEL | 13 | 13 | 13 | 0.36 | +403 | +31.0 |
| HUNT IN PAIRS | 48 | 24 | 12 | 0.33 | +666 | +55.5 |
| ONE OBJECTIVE FORMULA | 158 | 94 | 12 | 0.33 | +306 | +25.5 |
| BEST OVERALL | 11 | 11 | 11 | 0.31 | +1088 | +98.9 |
| MISSILES NEXT TURN | 337 | 198 | 11 | 0.31 | +46 | +4.2 |
| REDIRECT WEIGHED | 11 | 11 | 11 | 0.31 | +398 | +36.2 |
| STUCK PIVOT | 11 | 11 | 11 | 0.31 | +0 | +0.0 |
| WAR ENGINE JOBS | 23 | 23 | 11 | 0.31 | -1123 | -102.1 |
| AFTERMATH IN POINTS | 10 | 10 | 10 | 0.28 | +561 | +56.1 |
| BEST FACING | 10 | 10 | 10 | 0.28 | +200 | +20.0 |
| MODEL FACING | 10 | 10 | 10 | 0.28 | +1276 | +127.6 |
| PIVOT GUARDS FLANK | 10 | 10 | 10 | 0.28 | -162 | -16.2 |
| KEEPS ITS TARGET | 60 | 60 | 9 | 0.25 | +147 | +16.3 |
| REFUSING RETIRES | 28 | 28 | 9 | 0.25 | -3 | -0.4 |
| SUPPORT NARROWED | 266 | 266 | 9 | 0.25 | -76 | -8.4 |
| SHORT GUN FORWARD | 8 | 8 | 8 | 0.22 | +0 | +0.0 |
| BIG CHARACTER SAFETY | 7 | 7 | 7 | 0.19 | -23 | -3.3 |
| MAKE SURE TOGETHER | 30 | 18 | 7 | 0.19 | +1215 | +173.6 |
| MARCH ODDS | 7 | 7 | 7 | 0.19 | +34 | +4.9 |
| MOVES UNITS SPELL | 7 | 7 | 7 | 0.19 | +186 | +26.5 |
| SURE REACH TOGETHER | 46 | 40 | 7 | 0.19 | +42 | +6.0 |
| BLOCKED CHARGE SKIPPED | 6 | 6 | 6 | 0.17 | +0 | +0.0 |
| CHARGE NOW WEIGHED | 6 | 6 | 6 | 0.17 | +574 | +95.6 |
| OPENS UP | 9 | 9 | 6 | 0.17 | +239 | +39.8 |
| NEEDED THERE | 5 | 5 | 5 | 0.14 | +0 | +0.0 |
| OVERRUNS AWAY | 36 | 36 | 5 | 0.14 | +126 | +25.1 |
| BEST PREY | 25 | 25 | 4 | 0.11 | +219 | +54.8 |
| BEST PRIZE | 4 | 4 | 4 | 0.11 | -215 | -53.8 |
| CHARIOT NO STATIC JOB | 4 | 4 | 4 | 0.11 | -484 | -121.1 |
| FEATURE BUFFS | 7 | 7 | 4 | 0.11 | +44 | +11.0 |
| RESTRAINS TO SHOOT | 4 | 4 | 4 | 0.11 | +115 | +28.8 |
| WHOLE FIGHT | 30 | 30 | 4 | 0.11 | +161 | +40.3 |
| CATCH ODDS | 3 | 3 | 3 | 0.08 | -30 | -10.1 |
| EDGE GIVE GROUND | 11 | 11 | 3 | 0.08 | +234 | +78.0 |
| ELIXIR WORTH | 3 | 3 | 3 | 0.08 | +101 | +33.8 |
| FALL BACK GOOD ORDER | 94 | 94 | 3 | 0.08 | +16 | +5.4 |
| KEEP FALLS | 3 | 3 | 3 | 0.08 | +45 | +15.0 |
| LOST CHARGE | 118 | 117 | 3 | 0.08 | +358 | +119.3 |
| PURSUES BIG PREY | 3 | 3 | 3 | 0.08 | -387 | -129.0 |
| STAY WEIGHED | 3 | 3 | 3 | 0.08 | +281 | +93.7 |
| SURE CHARGE BEATS ADVANCE | 3 | 3 | 3 | 0.08 | -41 | -13.8 |
| WIDER SPREAD | 175 | 174 | 3 | 0.08 | +7 | +2.4 |
| BOMBING RUN | 2 | 2 | 2 | 0.06 | +178 | +89.1 |
| DEFENSIVE FLOOR | 5 | 5 | 2 | 0.06 | +9 | +4.6 |
| FIRE AND FLEE | 2 | 2 | 2 | 0.06 | +31 | +15.5 |
| FOCUS FIRE | 2 | 2 | 2 | 0.06 | +59 | +29.4 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| LONG SHOT | 24 | 24 | 2 | 0.06 | +142 | +70.9 |
| MOVE SPELL IN RANGE | 6 | 3 | 2 | 0.06 | +40 | +19.9 |
| OPENS A LANE | 6 | 5 | 2 | 0.06 | +7 | +3.6 |
| PERIAPT WORTH | 2 | 2 | 2 | 0.06 | +156 | +77.8 |
| SPELLS IN THE FIGHT | 32 | 31 | 2 | 0.06 | +10 | +4.9 |
| WAR ENGINE CHARGES | 4 | 4 | 2 | 0.06 | +619 | +309.5 |
| BACKUP TARGETS | 26 | 13 | 1 | 0.03 | +4 | +4.1 |
| CARRIES OUT SET-UP | 4 | 4 | 1 | 0.03 | -122 | -121.9 |
| CONTINUE AHEAD WEIGHED | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| GUN MASK | 8 | 8 | 1 | 0.03 | +33 | +33.4 |
| NO RALLY LEFT | 1 | 1 | 1 | 0.03 | +5 | +5.2 |
| RUN DOWN | 83 | 83 | 1 | 0.03 | +17 | +17.2 |
| STANDS TO CAST | 1 | 1 | 1 | 0.03 | +3 | +3.4 |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| BLOWS WHERE AIMED | 17 | 17 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 39 | 39 | 0 | 0.00 | - | - |
| CARRIES OUT COUNTER | 2 | 2 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 45 | trace | - | - | - | - |
| CHARACTER GUNS | 11 | 11 | 0 | 0.00 | - | - |
| CHARGER SLAIN LOST | 32 | 31 | 0 | 0.00 | - | - |
| CHARIOT WIZARD CAREFUL | 3 | 3 | 0 | 0.00 | - | - |
| CHEAP HELPER | 8 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 34 | not checked | - | - | - | - |
| DEFENSIVE ARMY | 6 | 6 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 2 | 2 | 0 | 0.00 | - | - |
| FALLS SHORT | 15 | 15 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 370 | not checked | - | - | - | - |
| GIVES UP | 8 | 7 | 0 | 0.00 | - | - |
| GROUND FLIERS | 2 | not checked | - | - | - | - |
| HELPER ALREADY ASKED | 1 | not checked | - | - | - | - |
| HELPER UNSEEN | 23 | 22 | 0 | 0.00 | - | - |
| HUNT ADVANCE | 4 | 4 | 0 | 0.00 | - | - |
| HUNT DROPPED | 3 | trace | - | - | - | - |
| HUNT KEPT | 1 | trace | - | - | - | - |
| HUNT RESULT | 5 | trace | - | - | - | - |
| HUNT THE GUNS | 5 | trace | - | - | - | - |
| JOINT CHARGE PLAN | 7 | 7 | 0 | 0.00 | - | - |
| JOINT KNOWS CHALLENGE | 6 | 6 | 0 | 0.00 | - | - |
| KEEPS ITS PREY | 1 | 1 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 19 | not checked | - | - | - | - |
| LONE WIZARD HOLDS BACK | 6 | 6 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 10 | 10 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 7 | trace | - | - | - | - |
| MARCH OVER CASTS | 37 | 37 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 2 | 2 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 24 | trace | - | - | - | - |
| MOVE SPELL SPOT | 18 | not checked | - | - | - | - |
| NOT NEEDED | 13 | 13 | 0 | 0.00 | - | - |
| NOT TURNED | 213 | 213 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 53 | not checked | - | - | - | - |
| PLAN RESULT | 2848 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 3 | 3 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 42 | 42 | 0 | 0.00 | - | - |
| SCOUT SPOT | 23 | 23 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 14 | 14 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 13 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 10 | not checked | - | - | - | - |
| SET-UP MISSED | 5 | trace | - | - | - | - |
| SHOOTER COUNTED ONCE | 4 | 4 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 15 | not checked | - | - | - | - |
| SPELL WORTH | 100 | not checked | - | - | - | - |
| STABLE ROLE | 443 | 442 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 16 | 16 | 0 | 0.00 | - | - |
| STOPS | 2 | 2 | 0 | 0.00 | - | - |
| TIME ON OUR SIDE | 51 | 51 | 0 | 0.00 | - | - |
| TURN WORTH | 13 | 13 | 0 | 0.00 | - | - |
| TWO OR MORE ARRIVE | 11 | 8 | 0 | 0.00 | - | - |

### Off best figure: fa-h2h-opp-8a94331-p1

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 15.97 | 1.67 | 39.5 |
| CHARGE NOW FIRST | rule | 0.56 | 0.33 | 43.7 |
| FALLBACK | gate | 0.67 | - | 33.7 |
| CHAFF PASSED | rule | 0.11 | 0.39 | 4.6 |
| TURN GATE | gate | 0.44 | - | 18.6 |
| WAR ENGINE JOBS | rule | 0.31 | - | 102.1 |
| AFTERMATH BAND | gate | 0.08 | 0.17 | 3.1 |
| PIVOT GUARDS FLANK | rule | 0.14 | 0.11 | 18.0 |
| SUPPORT NARROWED | rule | 0.17 | 0.08 | 8.4 |
| NO REASON | gate | - | 0.19 | 52.0 |
| CANNON PLANNED TARGET | rule | 0.17 | - | 33.1 |
| PATHS CROSS | rule | 0.11 | 0.06 | 11.4 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.03 | 0.08 | 31.5 |
| BEST PRIZE | rule | 0.06 | 0.06 | 53.8 |
| BIG CHARACTER SAFETY | rule | 0.11 | - | 7.0 |
| CHARIOT NO STATIC JOB | rule | 0.11 | - | 121.1 |
| LONE CHARACTER SAFE SPOT | gate | 0.08 | 0.03 | 12.0 |
| RULE SWITCHED OFF | gate | 0.11 | - | 42.6 |
| CATCH ODDS | rule | 0.08 | - | 10.1 |
| PURSUES BIG PREY | rule | 0.08 | - | 129.0 |
| SURE CHARGE BEATS ADVANCE | rule | 0.08 | - | 13.8 |
| MARCH ODDS | rule | 0.03 | 0.03 | 7.3 |
| REFUSING RETIRES | rule | - | 0.06 | 0.7 |
| SAFER THAN THE JOB | rule | 0.06 | - | 8.8 |
| STOPS SHORT OF THE FLANK | rule | 0.06 | - | 5.2 |
| CARRIES OUT SET-UP | rule | 0.03 | - | 121.9 |
| FOLLOW UP WEIGHED | rule | 0.03 | - | 2.6 |
| SUPPORT REQUEST | gate | 0.03 | - | 61.4 |
| THROUGH LINE OF FIRE | rule | 0.03 | - | 14.8 |

### Plans: fa-h2h-opp-8a94331-p1

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 10.3 | 19% | 180 | 346 | 193% |
| Mine | charge | 3.2 | 62% | 330 | 345 | 105% |
| Mine | close in | 4.7 | 34% | 364 | 192 | 53% |
| Mine | hold | 5.8 | 38% | 388 | 0 | 0% |
| Mine | join | 0.6 | 95% | 19 | 0 | 0% |
| Mine | shoot | 9.7 | 60% | 397 | 791 | 199% |
| Mine | support | 5.1 | 86% | 47 | 0 | 0% |
| Opponent | charge | 2.8 | 67% | 337 | 284 | 84% |
| Opponent | join | 1.6 | 93% | 68 | 0 | 0% |
| Opponent | move | 31.3 | 92% | 1715 | 0 | 0% |
| Opponent | shoot | 3.7 | 59% | 202 | 235 | 116% |
| Opponent | support | 0.3 | 45% | 1 | 0 | 0% |

### Packages: hunt the guns, fa-h2h-opp-8a94331-p1

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.1 | 4 | 0 | 25% | 50% | 0% | 2.5 | 299 | 115 | 50% | 21 |
| Opponent | 0.0 | 1 | 0 | 0% | 0% | 0% | - | 513 | 0 | 0% | 91 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 37 |
| Dwarfen Mountain Holds | 0.4 | 2 | 0 | 50% | 50% | 0% | 2.0 | 384 | 121 | 50% | 78 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 128 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| High Elf Realms | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 204 | 0 | 0% | 83 |
| Kingdom of Bretonnia | 1.0 | 1 | 0 | 0% | 100% | 0% | 3.0 | 225 | 218 | 100% | 0 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 175 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 18 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 72 |
| Tomb Kings of Khemri | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 77 |
| Vampire Counts | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Warriors of Chaos | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 90 |
| Wood Elf Realms | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 513 | 0 | 0% | 63 |

### Battle groups: fa-h2h-opp-8a94331-p1

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 2.1 | 21% | 62% | 0% | - | 12% | 6% | 12% | 62% | 6% |
| Opponent | REDIRECT COUNTER | 3.7 | 27% | 67% | 14% | 40% | 19% | 3% | 10% | 65% | 3% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: fa-h2h-opp-8a94331-p1

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 3 | 0 (3) | 0 | 0 | 37 | 33% | 5.0 | 0 (1) | 0 (2) | - | - | 0 (3) |
| Mine | Chaff | 37 | 34 (37) | 23 | 11 | 51 | 41% | 2.6 | 72 (16) | 10 (9) | 7 (12) | 49 (24) | 13 (13) |
| Mine | Character | 123 | 58 (123) | 58 | 0 | 27 | 20% | 2.3 | 90 (35) | 43 (63) | 79 (13) | 64 (62) | 60 (49) |
| Mine | Clean-up | 24 | 69 (24) | 26 | 43 | 23 | 25% | 3.3 | 46 (9) | 84 (11) | 121 (4) | 70 (14) | 68 (10) |
| Mine | Fast | 4 | 34 (4) | 34 | 0 | 25 | 0% | 1.5 | 0 (1) | 100 (2) | 0 (1) | 34 (4) | - |
| Mine | Fast Hammer | 41 | 27 (41) | 17 | 10 | 48 | 29% | 3.2 | 41 (18) | 24 (12) | 7 (11) | 33 (28) | 18 (13) |
| Mine | Fragile | 5 | 0 (5) | 0 | 0 | 60 | 0% | 1.8 | - | 0 (4) | 0 (1) | 0 (1) | 0 (4) |
| Mine | Hammer | 58 | 52 (58) | 40 | 13 | 26 | 21% | 2.6 | 58 (10) | 54 (38) | 41 (10) | 56 (34) | 48 (24) |
| Mine | Holder | 25 | 103 (25) | 8 | 94 | 11 | 60% | 3.4 | 165 (7) | 84 (13) | 84 (3) | 167 (10) | 67 (13) |
| Mine | Shooter | 44 | 105 (44) | 40 | 65 | 16 | 5% | 2.0 | 30 (5) | 119 (32) | 116 (7) | 129 (23) | 81 (21) |
| Mine | Support | 5 | 0 (5) | 0 | 0 | 42 | 40% | 3.0 | 0 (1) | 0 (1) | - | 0 (2) | - |
| Mine | War machine | 56 | 50 (56) | 50 | 0 | 39 | 5% | 1.2 | 85 (13) | 37 (37) | 55 (6) | 83 (11) | 41 (45) |
| Mine | Wizard | 23 | 20 (23) | 20 | 0 | 33 | 26% | 2.1 | 0 (6) | 0 (11) | 154 (3) | 87 (4) | 3 (16) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | - | 0 (1) | 0 (1) | - |
| Opponent | Chaff | 66 | 47 (66) | 14 | 33 | 38 | 42% | 3.0 | 44 (28) | 40 (16) | 57 (22) | 55 (48) | 25 (18) |
| Opponent | Character | 114 | 38 (114) | 38 | 0 | 39 | 30% | 2.6 | 54 (36) | 33 (54) | 52 (5) | 31 (61) | 63 (34) |
| Opponent | Clean-up | 16 | 36 (16) | 26 | 11 | 52 | 38% | 2.7 | 0 (5) | 42 (8) | 87 (3) | 50 (8) | 26 (8) |
| Opponent | Early | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Fast Hammer | 58 | 37 (58) | 21 | 16 | 64 | 31% | 2.5 | 30 (25) | 51 (19) | 34 (14) | 42 (42) | 23 (16) |
| Opponent | Fragile | 10 | 20 (10) | 20 | 0 | 52 | 20% | 2.6 | 0 (3) | 48 (4) | 0 (2) | 22 (9) | - |
| Opponent | Hammer | 65 | 21 (65) | 12 | 9 | 49 | 32% | 2.3 | 15 (16) | 24 (42) | 8 (7) | 20 (40) | 23 (25) |
| Opponent | Holder | 40 | 48 (40) | 1 | 47 | 22 | 55% | 3.0 | 7 (8) | 86 (20) | 3 (9) | 93 (20) | 8 (17) |
| Opponent | Shooter | 30 | 65 (30) | 27 | 37 | 47 | 0% | 1.6 | 76 (7) | 72 (18) | 17 (5) | 68 (16) | 60 (14) |
| Opponent | Support | 2 | 0 (2) | 0 | 0 | 0 | 100% | - | - | 0 (2) | - | - | 0 (2) |
| Opponent | War machine | 13 | 52 (13) | 52 | 0 | 73 | 8% | 1.2 | 20 (5) | 36 (5) | 139 (3) | 105 (3) | 36 (10) |
| Opponent | Wizard | 22 | 4 (22) | 4 | 0 | 35 | 0% | 2.3 | 0 (12) | 17 (6) | 0 (2) | 9 (10) | 0 (10) |

### Charged fights: fa-h2h-opp-8a94331-p1

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 5 | 197 | 187 | 1.4 | 1.4 | 133 | 12 | +122 | 0 of 7 | 6 of 7 | +106 | +133 |
| Mine | Chaos Dwarfs | 3 | 146 | 536 | 3.0 | 1.1 | 179 | 34 | +144 | 6 of 9 | 5 of 9 | +210 | +136 |
| Mine | Dwarfen Mountain Holds | 4 | 542 | 86 | 2.0 | 1.1 | 43 | 8 | +35 | 1 of 8 | 4 of 8 | +177 | +15 |
| Mine | Empire of Man | 5 | 471 | 104 | 2.4 | 1.1 | 43 | 0 | +43 | 1 of 12 | 8 of 12 | +0 | +47 |
| Mine | Grand Cathay | 4 | 879 | 443 | 3.0 | 1.2 | 148 | 17 | +131 | 8 of 12 | 10 of 12 | +196 | +118 |
| Mine | High Elf Realms | 4 | 74 | 833 | 3.8 | 1.3 | 222 | 33 | +189 | 7 of 15 | 12 of 15 | +75 | +246 |
| Mine | Kingdom of Bretonnia | 1 | 0 | 1030 | 4.0 | 1.2 | 258 | 0 | +258 | 2 of 4 | 4 of 4 | +666 | +121 |
| Mine | Lizardmen | 1 | 540 | 66 | 3.0 | 1.0 | 22 | 24 | -2 | 0 of 3 | 2 of 3 | - | -2 |
| Mine | Ogre Kingdoms | 1 | 136 | 0 | 2.0 | 1.0 | 0 | 17 | -17 | 1 of 2 | 0 of 2 | - | -17 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 321 | 5.0 | 1.2 | 64 | 11 | +53 | 3 of 5 | 4 of 5 | +0 | +66 |
| Mine | Skaven | 2 | 376 | 59 | 2.0 | 1.5 | 30 | 33 | -4 | 1 of 4 | 4 of 4 | +25 | -32 |
| Mine | Tomb Kings of Khemri | 2 | 0 | 1292 | 7.0 | 1.2 | 185 | 5 | +180 | 5 of 14 | 12 of 14 | +308 | +158 |
| Mine | Vampire Counts | 2 | 0 | 375 | 3.0 | 1.3 | 125 | 39 | +86 | 2 of 6 | 6 of 6 | -60 | +115 |
| Mine | Warriors of Chaos | 1 | 27 | 0 | 1.0 | 1.0 | 0 | 30 | -30 | 0 of 1 | 0 of 1 | - | -30 |
| **Mine** | all armies | 36 | 311 | 372 | 2.8 | 1.2 | 131 | 17 | +114 | 37 of 102 | 77 of 102 | +137 | +108 |
| Opponent | Beastmen Brayherds | 1 | 0 | 0 | 1.0 | 2.0 | 0 | 137 | -137 | 1 of 1 | 1 of 1 | -137 | - |
| Opponent | Dwarfen Mountain Holds | 1 | 112 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 0 of 1 | 1 of 1 | - | +0 |
| Opponent | Empire of Man | 1 | 95 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Grand Cathay | 1 | 355 | 408 | 2.0 | 1.0 | 204 | 0 | +204 | 2 of 2 | 1 of 2 | - | +204 |
| Opponent | High Elf Realms | 2 | 148 | 308 | 3.5 | 1.0 | 88 | 0 | +88 | 3 of 7 | 2 of 7 | - | +88 |
| Opponent | Lizardmen | 1 | 519 | 0 | 1.0 | 1.0 | 0 | 141 | -141 | 1 of 1 | 1 of 1 | - | -141 |
| Opponent | Ogre Kingdoms | 2 | 26 | 0 | 1.0 | 1.0 | 0 | 17 | -17 | 0 of 2 | 0 of 2 | - | -17 |
| Opponent | Orc & Goblin Tribes | 2 | 0 | 498 | 3.5 | 1.0 | 142 | 34 | +109 | 3 of 7 | 6 of 7 | - | +109 |
| Opponent | Skaven | 2 | 56 | 0 | 0.5 | 1.0 | 0 | 0 | +0 | 1 of 1 | 0 of 1 | - | +0 |
| Opponent | Tomb Kings of Khemri | 4 | 31 | 1203 | 4.8 | 1.2 | 253 | 0 | +253 | 7 of 19 | 14 of 19 | +650 | +207 |
| Opponent | Vampire Counts | 6 | 103 | 171 | 3.8 | 1.0 | 45 | 42 | +2 | 7 of 23 | 14 of 23 | - | +2 |
| Opponent | Warriors of Chaos | 7 | 0 | 279 | 1.4 | 1.1 | 195 | 35 | +160 | 7 of 10 | 7 of 10 | +81 | +169 |
| Opponent | Wood Elf Realms | 6 | 186 | 419 | 3.2 | 1.2 | 132 | 5 | +127 | 6 of 19 | 15 of 19 | +379 | +80 |
| **Opponent** | all armies | 36 | 94 | 342 | 2.6 | 1.1 | 133 | 21 | +111 | 38 of 93 | 62 of 93 | +340 | +93 |

### Effective charges: fa-h2h-opp-8a94331-p1

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 7 | 1 (net +242) | 0 | 0 | 2 (net +112) | 1 (net -52) | 1 (net +185) | 2 | 0% (0 of 5) |
| Mine | Chaos Dwarfs | 9 | 2 (net +174) | 1 (net +185) | 1 (net +145) | 2 (net -30) | 0 | 3 (net +227) | 0 | 11% (1 of 9) |
| Mine | Dwarfen Mountain Holds | 8 | 3 (net +55) | 0 | 0 | 2 (net -30) | 0 | 3 (net +59) | 0 | 0% (0 of 8) |
| Mine | Empire of Man | 12 | 3 (net +95) | 0 | 2 (net +0) | 1 (net +0) | 2 (net +35) | 3 (net +28) | 1 | 18% (2 of 11) |
| Mine | Grand Cathay | 12 | 3 (net -68) | 0 | 0 | 5 (net +243) | 0 | 4 (net +140) | 0 | 0% (0 of 12) |
| Mine | High Elf Realms | 15 | 2 (net +376) | 1 (net +663) | 4 (net +72) | 2 (net +210) | 2 (net +10) | 4 (net +173) | 0 | 27% (4 of 15) |
| Mine | Kingdom of Bretonnia | 4 | 1 (net +666) | 0 | 0 | 1 (net +153) | 0 | 2 (net +106) | 0 | 0% (0 of 4) |
| Mine | Lizardmen | 3 | 1 (net -72) | 0 | 0 | 0 | 1 (net +66) | 0 | 1 | 0% (0 of 2) |
| Mine | Ogre Kingdoms | 2 | 0 | 0 | 1 (net -34) | 0 | 0 | 0 | 1 | 100% (1 of 1) |
| Mine | Orc & Goblin Tribes | 5 | 0 | 0 | 0 | 1 (net +195) | 1 (net +66) | 0 | 3 | 0% (0 of 2) |
| Mine | Skaven | 4 | 0 | 0 | 1 (net +0) | 1 (net +50) | 0 | 2 (net -32) | 0 | 25% (1 of 4) |
| Mine | Tomb Kings of Khemri | 14 | 2 (net +246) | 0 | 3 (net +310) | 5 (net +114) | 1 (net +446) | 3 (net +24) | 0 | 21% (3 of 14) |
| Mine | Vampire Counts | 6 | 0 | 0 | 0 | 4 (net +24) | 1 (net -60) | 1 (net +479) | 0 | 0% (0 of 6) |
| Mine | Warriors of Chaos | 1 | 1 (net -30) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 1) |
| Opponent | Beastmen Brayherds | 1 | 1 (net -137) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 1) |
| Opponent | Dwarfen Mountain Holds | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +0) | 0 | 0% (0 of 1) |
| Opponent | Grand Cathay | 2 | 2 (net +204) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 2) |
| Opponent | High Elf Realms | 7 | 2 (net +256) | 0 | 0 | 2 (net +52) | 0 | 1 (net +0) | 2 | 0% (0 of 5) |
| Opponent | Ogre Kingdoms | 2 | 1 (net +0) | 0 | 1 (net -34) | 0 | 0 | 0 | 0 | 50% (1 of 2) |
| Opponent | Orc & Goblin Tribes | 7 | 1 (net +583) | 0 | 0 | 0 | 0 | 1 (net +162) | 5 | 0% (0 of 2) |
| Opponent | Skaven | 1 | 1 (net +0) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 1) |
| Opponent | Tomb Kings of Khemri | 19 | 2 (net +458) | 1 (net +405) | 7 (net +208) | 6 (net +293) | 0 | 2 (net +138) | 1 | 39% (7 of 18) |
| Opponent | Vampire Counts | 23 | 6 (net -57) | 2 (net +10) | 6 (net +52) | 5 (net +50) | 1 (net +0) | 2 (net +0) | 1 | 27% (6 of 22) |
| Opponent | Warriors of Chaos | 10 | 2 (net +0) | 0 | 0 | 2 (net +276) | 0 | 3 (net +361) | 3 | 0% (0 of 7) |
| Opponent | Wood Elf Realms | 19 | 2 (net +196) | 0 | 4 (net +21) | 6 (net +227) | 2 (net +61) | 3 (net +109) | 2 | 24% (4 of 17) |

### Charged fights, damage counted: fa-h2h-opp-8a94331-p1

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 19 | 282 | 216 | +139 | 196 | 89 | +107 | +37.8 |
| Mine | 50-54% | 2 | 488 | 310 | +424 | 424 | 0 | +424 | +86.8 |
| Mine | Effective (55-75%) | 12 | 283 | 201 | +111 | 182 | 68 | +115 | +40.6 |
| Mine | 76-89% | 26 | 278 | 180 | +108 | 145 | 39 | +106 | +38.0 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 26 | 235 | 184 | +118 | 163 | 28 | +135 | +57.5 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 9 | 439 | 95 | +62 | 113 | 56 | +57 | +13.0 |
| Mine | No odds | 8 | 356 | 190 | +42 | 52 | 12 | +40 | +11.2 |
| Mine | All fights | 102 | 293 | 186 | +114 | 159 | 47 | +111 | +38.0 |
| Opponent | Long shot (under 50%) | 20 | 221 | 284 | +117 | 158 | 58 | +100 | +45.1 |
| Opponent | 50-54% | 3 | 215 | 225 | +142 | 157 | 15 | +142 | +65.8 |
| Opponent | Effective (55-75%) | 18 | 210 | 182 | +101 | 131 | 27 | +103 | +49.1 |
| Opponent | 76-89% | 21 | 308 | 202 | +192 | 205 | 31 | +174 | +56.7 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 13 | 261 | 181 | +142 | 178 | 26 | +152 | +58.3 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 3 | 499 | 97 | +41 | 56 | 0 | +56 | +11.2 |
| Opponent | No odds | 15 | 189 | 209 | -15 | 72 | 77 | -5 | -2.6 |
| Opponent | All fights | 93 | 248 | 211 | +111 | 149 | 41 | +108 | +43.5 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| fa-h2h-opp-8a94331-p1 | move | 396 | 60 (15%) | 43 (11%) | 54 (14%) | 282 (71%) |
| fa-h2h-opp-8a94331-p1 | objective | 171 | 24 (14%) | 18 (11%) | 27 (16%) | 120 (70%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0102, L0118, L0135, L2531, L2730 |
| Charmed Shield | Opponent | L0524, L1224, L1527, L1625, L2025, L2127, L2934 |
| Clockwork Compass | Mine | L1224 |
| Clockwork Compass | Opponent | L0612 |
| Elixir of Power | Mine | L1114, L1131, L1923 |
| Elixir of Power | Opponent | L0319, L1319 |
| Fistful of Laurels | Mine | L1823 |
| Fistful of Laurels | Opponent | L0118, L0218 |
| Horn of the Wild Hunt | Opponent | L0733 |
| Invocation of Nehek | Mine | L2531, L2730 |
| Invocation of Nehek | Opponent | L0524, L1224, L1527, L1625, L2025, L2127 |
| Opal Amulet | Mine | L1431 |
| Opal Amulet | Opponent | L1114 |
| Periapt of Soul Exchange | Mine | L2025, L2127 |
| Periapt of Soul Exchange | Opponent | L0421, L1021 |
| Ring of Doom | Mine | L0218, L0235, L1114, L1131, L1224, L1527 |
| Ring of Doom | Opponent | L0102, L0612, L0733, L1131, L1431, L2231, L2531 |
| Ring of Jet | Mine | L1021, L1114, L1131, L1224 |
| Ring of Jet | Opponent | L0612 |
| Standard of the Fell Warrior | Mine | L1319, L1335 |
| Standard of the Fell Warrior | Opponent | L0913 |
| Storm Daemon (Renegade 2.0) | Mine | L2127 |
| Storm Daemon (Renegade 2.0) | Opponent | L0421, L1021 |
| Twice-Blessed Armour | Mine | L0717, L0733, L1021 |
| Witch Hunter's Ward | Mine | L0717, L0733, L0823 |
| Witch Hunter's Ward | Opponent | L0508 |

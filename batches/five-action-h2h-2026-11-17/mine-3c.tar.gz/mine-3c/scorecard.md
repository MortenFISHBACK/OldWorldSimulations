# Doctrine scorecard: fa-h2h-mine-8a94331-p3c

### Scorecard: fa-h2h-mine-8a94331-p3c

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L1519 | 1 | 1 | Mine | no | 3 | 2 | 4 | 0 | 0 | 0 | 0 | 432 |
| L1519 | 1 | 1 | Opponent | no | 2 | 2 | 7 | 1 | 1 | 0 | 0 | 0 |
| L1535 | 5 | 1 | Mine | yes | - | 6 | 2 | 1 | 1 | 0 | 0 | 176 |
| L1535 | 5 | 1 | Opponent | no | - | 1 | 2 | 4 | 1 | 0 | 0 | 140 |
| L1633 | 1 | 1 | Mine | yes | 12 | 2 | 3 | 2 | 1 | 0 | 0 | 0 |
| L1633 | 1 | 1 | Opponent | no | 0 | 1 | 3 | 2 | 0 | 0 | 0 | 378 |
| L1731 | 3 | 1 | Mine | no | 1 | 2 | 3 | 0 | 0 | 0 | 0 | 0 |
| L1731 | 3 | 1 | Opponent | yes | 7 | 2 | 4 | 1 | 0 | 0 | 0 | 340 |
| L1831 | 1 | 1 | Mine | no | 5 | 3 | 7 | 1 | 0 | 0 | 0 | 0 |
| L1831 | 1 | 1 | Opponent | no | 3 | 3 | 6 | 0 | 0 | 0 | 0 | 170 |
| L1932 | 6 | 1 | Mine | no | 5 | 2 | 2 | 0 | 0 | 0 | 0 | 0 |
| L1932 | 6 | 1 | Opponent | no | 0 | 2 | 3 | 1 | 1 | 0 | 0 | 340 |
| L2033 | 5 | 1 | Mine | no | - | - | 1 | 3 | 0 | 0 | 0 | 210 |
| L2033 | 5 | 1 | Opponent | yes | - | 5 | 1 | 3 | 0 | 0 | 0 | 0 |
| L2223 | 3 | 1 | Mine | no | 0 | 1 | 7 | 0 | 1 | 0 | 0 | 0 |
| L2223 | 3 | 1 | Opponent | no | 1 | 2 | 5 | 1 | 2 | 0 | 0 | 0 |
| L2327 | 5 | 1 | Mine | yes | - | 2 | 6 | 2 | 0 | 0 | 0 | 0 |
| L2327 | 5 | 1 | Opponent | yes | - | 3 | 1 | 3 | 0 | 0 | 0 | 0 |
| L2433 | 3 | 1 | Mine | no | 1 | 5 | 1 | 3 | 0 | 0 | 0 | 0 |
| L2433 | 3 | 1 | Opponent | no | 1 | 1 | 6 | 2 | 0 | 0 | 0 | 0 |
| L2630 | 2 | 1 | Mine | - | - | 5 | 3 | 1 | 0 | 0 | 0 | 329 |
| L2630 | 2 | 1 | Opponent | - | - | 2 | 4 | 4 | 0 | 0 | 0 | 0 |
| L2832 | 6 | 1 | Mine | no | 2 | 2 | 0 | 0 | 2 | 0 | 0 | 638 |
| L2832 | 6 | 1 | Opponent | no | 1 | 2 | 0 | 3 | 1 | 0 | 0 | 0 |
| L3133 | 1 | 1 | Mine | no | 1 | 1 | 3 | 0 | 4 | 0 | 0 | 340 |
| L3133 | 1 | 1 | Opponent | no | 6 | 3 | 4 | 2 | 0 | 0 | 0 | 405 |
| **Average** | | | Mine | 25% | 3.3 | 2.8 | 3.2 | 1.0 | 0.7 | 0.0 | 0.0 | 163.5 |
| **Average** | | | Opponent | 25% | 2.3 | 2.2 | 3.5 | 2.1 | 0.5 | 0.0 | 0.0 | 136.4 |

### KPIs: fa-h2h-mine-8a94331-p3c

Rules off - Opponent only: FIVE ACTION, LIKELY CHARGE, FALLS SHORT, TIME ON OUR SIDE, FEATURE BUFFS, GETS AWAY CHANCE, GUN MASK, RUN DOWN, FOUR ROUNDS, CHARGE LOSSES, CHARACTER GUNS, STAND AND SHOOT, FALL BACK GOOD ORDER, AFTERMATH IN POINTS.

Morten 2026-11-10; 13 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 66) | 26% (17 of 65) | 13% (17 of 131) |
| Winner chose to follow up after the loser gave ground |  | 94% (15 of 16); on the table 94% | 100% (16 of 16); on the table 100% | 97% (31 of 32); on the table 97% |
| Winner chose to pursue after the loser fell back in good order |  | 100% (6 of 6); on the table 100% | 100% (4 of 4); on the table 100% | 100% (10 of 10); on the table 100% |
| Winner chose to pursue after the loser fled |  | 100% (3 of 3); on the table 100% | 81% (13 of 16); on the table 81% | 84% (16 of 19); on the table 84% |
| Winner chose to follow up or pursue (all three) |  | 96% (24 of 25); on the table 96% | 92% (33 of 36); on the table 92% | 93% (57 of 61); on the table 93% |
| Magic missiles tried each own turn | 50%+ | 33% (22 of 66) | 21% (5 of 24) | 30% (27 of 90) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 42% (22 of 52) | 28% (5 of 18) | 39% (27 of 70) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 43% (3 of 7) | 19% (5 of 26) | 24% (8 of 33) |
| Points that never fought | lower | 30% (7306 of 24106) | 30% (7891 of 25998) | 30% (15197 of 50104) |
|   infantry points that never fought | lower | 49% (2105 of 4272) | 62% (3002 of 4829) | 56% (5107 of 9101) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 54% (45 of 84) | 54% (63 of 117) | 54% (108 of 201) |
| Bound items with a magic missile used (at least once a game) |  | 83% (5 of 6); 1.2 uses a game | 100% (11 of 11); 3.5 uses a game | 94% (16 of 17); 2.4 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 100% (3 of 3); 0.2 uses a game | 17% (1 of 6); 0.1 uses a game | 44% (4 of 9); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 50% (10531 of 21146) | 47% (11230 of 24076) | 48% (21761 of 45222) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 0.7 (20%) | 0.4 (26%) | 1.1 (22%) |
| MARCHED: its unit marched | 0.9 (27%) | 0.2 (16%) | 1.2 (24%) |
| CHARGED: its unit charged | 0.2 (7%) | 0.1 (5%) | 0.3 (6%) |
| IN COMBAT: engaged in combat | 0.3 (9%) | 0.0 (0%) | 0.3 (6%) |
| REAR RANK: in a rear rank | 0.3 (9%) | 0.3 (21%) | 0.6 (13%) |
| FLEEING: fleeing | 0.2 (5%) | 0.0 (0%) | 0.2 (3%) |
| GONE: slain | 0.4 (11%) | 0.2 (11%) | 0.5 (11%) |
| OFF THE TABLE: off the table or not arrived | 0.2 (7%) | 0.3 (21%) | 0.5 (11%) |
| NOT OFFERED: not in the cast list | 0.2 (5%) | 0.0 (0%) | 0.2 (3%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 5.3 | 0.7 | 1.2 | 2.1 | 0.8 | 0.5 |
| not cast | 4.8 | 1.3 | 3.4 | 4.8 | 1.8 | 17.1 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.2 (7%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.1 (2%) | 0.3 (24%) | 0.2 (5%) | 1.1 (22%) | 0.0 (0%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.2 (24%) | 0.1 (4%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (6%) | 0.2 (8%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.2 (3%) | 0.0 (0%) | 0.1 (2%) | 0.3 (6%) | 0.0 (0%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.5 (11%) | 0.2 (12%) | 0.8 (23%) | 0.6 (13%) | 0.3 (17%) | 0.0 (0%) |
| FLEEING: fleeing | 0.2 (3%) | 0.2 (12%) | 0.5 (16%) | 0.2 (3%) | 0.4 (21%) | 0.8 (5%) |
| GONE: slain | 0.6 (13%) | 0.2 (12%) | 0.5 (14%) | 0.5 (11%) | 0.4 (21%) | 2.2 (13%) |
| OFF THE TABLE: off the table or not arrived | 0.2 (5%) | 0.1 (6%) | 0.2 (7%) | 0.5 (11%) | 0.0 (0%) | 0.6 (4%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.1 (6%) | 0.0 (0%) | 0.0 (0%) | 0.5 (29%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (3%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 3.1 (63%) | 0.4 (29%) | 1.2 (34%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 12.3 (72%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.7 a game | 0.5 a game | 0.6 a game |
| stood (cast and not dispelled) | 0% (0 of 1) | 57% (4 of 7) | 50% (4 of 8) |
| the unit moved after it | - | 50% (2 of 4) | 50% (2 of 4) |
| it charged on its next turn | - | 0% (0 of 4) | 0% (0 of 4) |
| the enemy charged it first | - | 25% (1 of 4) | 25% (1 of 4) |
| it fought by the end of its next turn | - | 25% (1 of 4) | 25% (1 of 4) |
| it moved out of a charge the enemy had planned (not charged first) | - | 25% (1 of 4) | 25% (1 of 4) |
| none of these (no charge, no fight, no charge escaped) | - | 50% (2 of 4) | 50% (2 of 4) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 51% (116 of 228) | 60% (127 of 211) | 55% (243 of 439) |
|   cavalry | 72% (21 of 29) | 60% (41 of 68) | 64% (62 of 97) |
|   character | 29% (12 of 41) | 26% (12 of 46) | 28% (24 of 87) |
|   chariot | 54% (13 of 24) | - | 54% (13 of 24) |
|   infantry | 62% (58 of 94) | 76% (74 of 97) | 69% (132 of 191) |
|   monster | 29% (8 of 28) | - | 29% (8 of 28) |
|   war machine | 33% (4 of 12) | - | 33% (4 of 12) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.0 (23%) | 1.3 (20%) | 3.3 (22%) |
| CHARGED: it charged | 1.5 (18%) | 1.7 (26%) | 3.2 (21%) |
| FLEEING: it fled or was fleeing | 0.5 (5%) | 0.0 (0%) | 0.5 (3%) |
| IN COMBAT: it fought this turn or the last | 0.5 (6%) | 1.4 (21%) | 1.9 (13%) |
| MOVED: a war machine that moved | 0.6 (7%) | 0.0 (0%) | 0.6 (4%) |
| NO TARGET IN RANGE | 2.2 (26%) | 0.8 (12%) | 3.0 (20%) |
| ONLY IN COMBAT: the only targets were in combat | 0.4 (4%) | 0.5 (8%) | 0.9 (6%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.8 (10%) | 0.7 (11%) | 1.5 (10%) |
| STUPIDITY | 0.0 (0%) | 0.1 (1%) | 0.1 (1%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 6.5 | 1.5 | 81% | 4.4 pts | 28 pts |
| character | 2.2 | 0.4 | 83% | 2.7 pts | 6 pts |
| chariot | 1.0 | 0.3 | 69% | 4.9 pts | 5 pts |
| infantry | 17.4 | 6.3 | 76% | 7.9 pts | 138 pts |
| monster | 0.6 | 0.0 | 100% | 0.0 pts | 0 pts |
| war machine | 0.3 | 0.0 | 100% | 0.0 pts | 0 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.3 | 6.1 | 5.2 |
| Charges that made contact a game | 3.3 | 4.5 | 3.9 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.50 declared, 0.38 contact (8 units) | 1.00 declared, 1.00 contact (2 units) | 0.60 declared, 0.50 contact (10 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.00 declared, 0.00 contact (2 units) | 0.50 declared, 0.50 contact (4 units) | 0.33 declared, 0.33 contact (6 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.60 declared, 0.46 contact (87 units) | 0.75 declared, 0.55 contact (100 units) | 0.68 declared, 0.51 contact (187 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 37% (11 of 30) | 50% (3 of 6) | 60% (3 of 5) | 41% (17 of 41) |
| Character in a unit | 67% (4 of 6) | 67% (4 of 6) | 0% (0 of 4) | 50% (8 of 16) |
| Character on its own | 73% (19 of 26) | 62% (5 of 8) | 21% (6 of 29) | 48% (30 of 63) |
| Chariot | 75% (3 of 4) | - | - | 75% (3 of 4) |
| Infantry | 52% (12 of 23) | 69% (11 of 16) | 100% (1 of 1) | 60% (24 of 40) |
| Monster | 61% (11 of 18) | 100% (4 of 4) | - | 68% (15 of 22) |
| Monstrous | 88% (7 of 8) | 57% (4 of 7) | - | 73% (11 of 15) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| High Elf Realms | 2 | 100% (3 of 3); on the table 100% | 42% (5 of 12) | 22% | 29% (4 of 14) | 75% (3 of 4); 6.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | 100% (4 of 4); on the table 100% | - | 43% | 50% (3 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Lizardmen | 1 | 100% (1 of 1); on the table 100% | 67% (4 of 6) | 49% | 43% (3 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 1 | 100% (1 of 1); on the table 100% | 0% (0 of 6) | 25% | 71% (5 of 7) | 100% (1 of 1); 2.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 2 | 100% (7 of 7); on the table 100% | 8% (1 of 12) | 8% | 75% (12 of 16) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.5 uses a game |
| Skaven | 1 | 100% (3 of 3); on the table 100% | 33% (2 of 6) | 64% | 71% (5 of 7) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Tomb Kings of Khemri | 3 | 83% (5 of 6); on the table 83% | - | 19% | 36% (4 of 11) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 3 | 100% (5 of 5); on the table 100% | 28% (5 of 18) | 33% | 61% (11 of 18) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 7 | 86% (18 of 21); on the table 86% | 33% (8 of 24) | 23% | 46% (29 of 63) | 100% (3 of 3); 1.6 uses a game | 0.0 uses a game | 100% (1 of 1); 0.1 uses a game |
| Wood Elf Realms | 5 | 100% (10 of 10); on the table 100% | 33% (2 of 6) | 43% | 62% (32 of 52) | 100% (9 of 9); 7.4 uses a game | 0.0 uses a game | 0% (0 of 4); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (fa-h2h-mine-8a94331-p3c, 13 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 50% (13) | 57% (16) | 54% (29) |
| ...free all their last turn and able to turn (per game) | 0.62 | 0.54 | 1.15 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.08 | 0.38 | 0.46 |
| ...with the charger already in that arc before they moved (per game) | 0.46 | 0.46 | 0.92 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 1.92 | 1.92 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.92 | 0.92 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 6.00 | 6.00 |

### Quality by phase: fa-h2h-mine-8a94331-p3c

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.5 | 2.8 |
| Strategy | Charge objectives carried out (made contact) | 65% (30 of 46) | 51% (25 of 49) |
| Strategy | Shoot objectives carried out (shot that target) | 44% (17 of 39) | 44% (32 of 73) |
| Strategy | Close-in objectives charged next turn | - | 24% (21 of 88) |
| Strategy | Support requests answered (helper made contact too) | 50% (1 of 2) | 86% (6 of 7) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (1 of 1) | - |
| Strategy | Hexes on a unit its side charged or shot that turn | 33% (1 of 3) | 100% (2 of 2) |
| Strategy | Joined characters whose unit fought | 25% (1 of 4) | 56% (9 of 16) |
| Strategy | Lone characters that fought | 77% (27 of 35) | 91% (30 of 33) |
| Movement | Charges halted short of contact | 0.2 | 0.1 |
| Movement | Idle units | 1.0 | 2.1 |
| Movement | Points that never moved of their own | 163.5 | 136.4 |
| Movement | Fights charged into per game | 3.3 | 3.6 |
| Movement | Charges with odds: long shots (under 50%) | 6 of 36, net +65 | 3 of 31, net +22 |
| Movement | Charges with odds: sweet spot (55-75%) | 11 of 36, net +92 | 10 of 31, net +127 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 5 of 36, net +147 | 3 of 31, net +18 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 6 of 36, net +230 | 10 of 31, net +144 |
| Shooting | Shots by shooting units (incl. breath weapons) | 9.3 | 12.5 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 21% (26 of 121) | 35% (57 of 163) |
| Shooting | Points destroyed by shooting units | 27.1 | 13.9 |
| Shooting | War machine shots | 0.3 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 0% (0 of 4) | - |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | 1.2 | 0.2 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 20% (3 of 15) | 0% (0 of 2) |
| Magic | Wounds caused by magic missiles | 2.2 | 2.1 |
| Magic | Wounds caused by other spells | 0.3 | 0.2 |
| Magic | Points destroyed by magic (all spells) | 26.3 | 32.4 |
| Magic | Augments / hexes / assailments / vortexes cast | 2.5 / 0.2 / 0.3 / 0.0 | 1.8 / 0.2 / 0.1 / 0.7 |
| Combat | Points destroyed in combat | 458.2 | 486.7 |
| Combat | Points run down | 121.0 | 171.9 |
| Combat | Net points per charged fight, damage counted | +95 | +127 |
| Combat | Net per 100 charger points, damage counted | +32.2 | +56.3 |
| Combat | First round won (charged fights) | 65% | 79% |
| Combat | Net points per charged fight | +85 | +122 |
| Combat | Net points per supported fight / lone fight | +264 / +66 | +172 / +114 |
| Combat | Charged fights on a top-3 enemy unit | 19 of 43 | 16 of 47 |
| Game | Points lost | 925.7 | 668.3 |
| Game | VP from objectives | 477.7 | 625.4 |
| Game | Lone holders (player turns) | 3.3 | 2.3 |

- Mine won / drew / lost: 5 / 1 / 7 of 13 ended games (of 13); mean margin (Mine - Opponent) -448 VP
- The side that went first won 4 of 12 games with a winner
- Points traded per game (both sides' losses): 1594
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: fa-h2h-mine-8a94331-p3c

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.9 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 0.0 |
| ADVANCE WORTH | - | - | - | - | 4.4 | -172.6 | 213.6 | 75.4 |
| AFTERMATH IN POINTS | 0.2 | +28.4 | 0.0 | 0.0 | - | - | - | - |
| BACKUP TARGETS | 0.9 | +4.5 | 0.0 | 0.0 | 0.6 | +3.5 | 0.0 | 15.0 |
| BEST FACING | - | - | - | - | 0.4 | +10.1 | 0.0 | 0.0 |
| BEST FIRST | - | - | - | - | 0.6 | +36.6 | 61.0 | 21.9 |
| BEST OVERALL | - | - | - | - | 0.5 | +17.8 | 0.0 | 0.0 |
| BEST PREY | - | - | - | - | 0.4 | +7.9 | 45.5 | 0.0 |
| BEST PRIZE | 0.2 | -0.0 | 45.5 | 26.9 | - | - | - | - |
| BIG CHARACTER SAFETY | - | - | - | - | 0.1 | -1.0 | 0.0 | 0.0 |
| BLOCKED CHARGE SKIPPED | - | - | - | - | 0.1 | +0.0 | 0.0 | 0.0 |
| BLOCKED WHEEL | - | - | - | - | 0.5 | +1.8 | 0.0 | 1.5 |
| BLOWS WHERE AIMED | 0.4 | -13.1 | 25.1 | 23.9 | 0.4 | -73.1 | 89.0 | 15.0 |
| CANNON PLANNED TARGET | 0.3 | +1.2 | 1.5 | 0.0 | - | - | - | - |
| CANNON SIGHT KEPT | 0.2 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CARRIES OUT COUNTER | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CARRIES OUT SET-UP | - | - | - | - | 0.2 | +0.0 | 26.4 | 0.0 |
| CAST JOB | 0.2 | +4.2 | 10.2 | 26.4 | 0.6 | +36.7 | 24.8 | 60.5 |
| CASTER AWAY FROM SCREEN | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CASTING BLOCK | - | - | - | - | 0.2 | +7.1 | 13.1 | 0.0 |
| CASTS AFTER FRIENDS | 0.2 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CATCH ODDS | 0.1 | +5.7 | 0.0 | 8.9 | - | - | - | - |
| CHAFF IN THE MOVE | 0.5 | +11.1 | 0.0 | 8.7 | 1.8 | +85.7 | 0.0 | 52.8 |
| CHAFF PASSED | 0.5 | -0.7 | 0.0 | 5.1 | 0.2 | -0.4 | 0.0 | 0.0 |
| CHARGE LOSSES | 11.0 | -493.5 | 0.0 | 514.4 | - | - | - | - |
| CHARGE NOW FIRST | 2.2 | +0.0 | 195.4 | 135.7 | 1.8 | +0.0 | 220.2 | 41.8 |
| CHARGE NOW WEIGHED | - | - | - | - | 0.4 | -50.3 | 32.8 | 0.0 |
| CHARGER SLAIN LOST | 0.6 | -31.9 | 27.2 | 34.0 | 0.7 | -17.1 | 77.2 | 24.5 |
| CHEAP HELPER | - | - | - | - | 0.1 | +0.0 | 0.0 | 0.0 |
| COMBAT PIVOT | 0.3 | +0.0 | 0.0 | 13.1 | 0.5 | +0.0 | 79.0 | 26.2 |
| CONVEYANCE SEARCH | 0.1 | +2.0 | 0.0 | 0.0 | 0.4 | +43.7 | 0.0 | 39.1 |
| COVER ONCE | 7.4 | -395.6 | 0.0 | 255.6 | 5.8 | -358.5 | 0.0 | 59.5 |
| DEFENSIVE ARMY | - | - | - | - | 0.2 | +0.0 | 0.0 | 0.0 |
| EDGE GIVE GROUND | 0.2 | +7.9 | 21.9 | 0.0 | 0.1 | +6.9 | 37.1 | 0.0 |
| ELIXIR WORTH | 0.1 | +1.3 | 0.0 | 26.9 | - | - | - | - |
| FACES THE THREAT | - | - | - | - | 1.9 | +174.7 | 0.0 | 43.8 |
| FALL BACK GOOD ORDER | 2.4 | +1.4 | 203.2 | 107.0 | - | - | - | - |
| FALLBACK BY WORTH | - | - | - | - | 5.8 | +103.5 | 0.0 | 27.5 |
| FALLS SHORT | 0.3 | -7.6 | 0.0 | 79.1 | - | - | - | - |
| FEATURE BUFFS | 0.2 | +4.7 | 0.0 | 0.0 | - | - | - | - |
| FIGHT LIFT | 0.1 | +0.4 | 2.3 | 0.0 | - | - | - | - |
| FIVE ACTION | 40.3 | +2479.9 | 379.6 | 1089.7 | - | - | - | - |
| FLANK NOT WEIGHED | 5.8 | +0.0 | 0.0 | 244.4 | 5.8 | +0.0 | 0.0 | 163.5 |
| FOCUS FIRE | 0.1 | +2.5 | 3.5 | 0.0 | 0.1 | +2.6 | 5.1 | 0.0 |
| FOLLOW UP WEIGHED | 1.4 | +273.0 | 0.0 | 62.6 | 0.8 | +180.0 | 0.0 | 66.2 |
| FOUR ROUNDS | 3.5 | +311.2 | 264.7 | 147.2 | - | - | - | - |
| FRIENDS SHOTS CHECKED | 0.1 | +2.0 | 0.0 | 0.0 | 0.1 | +8.0 | 0.0 | 0.0 |
| GATEWAY ESCAPE | - | - | - | - | 0.1 | +4.7 | 0.0 | 0.0 |
| GIVES UP | - | - | - | - | 0.1 | -0.7 | 21.2 | 0.0 |
| GIVES UP ITS SCREEN | 0.1 | -0.2 | 15.0 | 2.6 | - | - | - | - |
| GUN MASK | 0.3 | -1.8 | 0.0 | 0.0 | - | - | - | - |
| HELPER UNSEEN | 0.5 | +0.0 | 12.2 | 40.0 | 0.2 | +0.0 | 0.0 | 11.1 |
| HILL BY ITS CHANCE | - | - | - | - | 0.5 | -34.0 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 0.5 | +0.0 | 0.0 | 0.0 | 0.8 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 2.8 | -116.8 | 210.4 | 90.2 | 8.1 | -130.0 | 578.7 | 100.2 |
| HORN WORTH | - | - | - | - | 0.2 | +10.4 | 0.0 | 0.0 |
| HUNT ADVANCE | - | - | - | - | 0.1 | +0.9 | 0.0 | 0.0 |
| HUNT DROPPED | - | - | - | - | 0.1 | +0.0 | 0.0 | 0.0 |
| HUNT IN PAIRS | 0.3 | +8.6 | 0.0 | 0.0 | 0.8 | +64.4 | 0.0 | 15.0 |
| HUNT RESULT | 0.1 | +16.9 | 0.0 | 2.6 | 0.1 | +0.0 | 0.0 | 0.0 |
| HUNT THE GUNS | 0.1 | +17.6 | 15.0 | 2.6 | 0.1 | +18.7 | 0.0 | 0.0 |
| IDLE COST | 17.5 | -329.1 | 0.0 | 329.5 | 20.5 | -336.5 | 0.0 | 204.3 |
| INVITES THE FIGHT | - | - | - | - | 0.8 | +4.0 | 39.8 | 33.1 |
| JOINT CHARGE PLAN | - | - | - | - | 0.4 | +11.4 | 0.0 | 0.0 |
| JOINT KNOWS CHALLENGE | - | - | - | - | 0.2 | -0.8 | 8.9 | 0.0 |
| KEEPS ITS PREY | - | - | - | - | 0.1 | +0.0 | 0.0 | 0.0 |
| KEEPS ITS TARGET | - | - | - | - | 1.5 | +46.2 | 217.8 | 25.4 |
| KILLS COUNT | 2.0 | +161.0 | 123.2 | 43.5 | 1.3 | +51.0 | 57.5 | 10.4 |
| KILLS COUNT NEXT TURN | - | - | - | - | 7.8 | +269.4 | 340.4 | 94.4 |
| LONE CHARACTER SAFE SPOT | 0.1 | +3.1 | 0.0 | 0.0 | 0.3 | +6.7 | 22.2 | 0.0 |
| LONE WIZARD HOLDS BACK | - | - | - | - | 0.6 | +0.0 | 25.7 | 0.0 |
| LONE WIZARD KEPT IN | 0.4 | +14.6 | 0.0 | 0.0 | 0.1 | +1.7 | 0.0 | 0.0 |
| LONG SHOT | 0.2 | -2.3 | 15.0 | 26.7 | 0.5 | +0.0 | 8.2 | 16.2 |
| LOST CHARGE | - | - | - | - | 3.2 | -44.8 | 92.1 | 8.0 |
| LURE BY WHAT IT DRAWS | - | - | - | - | 0.2 | -17.2 | 0.0 | 16.8 |
| MAKE SURE TOGETHER | 0.2 | +3.5 | 0.0 | 8.5 | 1.6 | +116.9 | 62.0 | 11.1 |
| MANOEUVRE | 0.8 | +16.2 | 0.0 | 44.8 | 0.2 | +0.2 | 0.0 | 0.0 |
| MARCH AT ESCAPER | - | - | - | - | 0.1 | +0.7 | 0.0 | 0.0 |
| MARCH CHECK | 0.6 | +24.4 | 0.0 | 0.0 | 0.3 | +7.0 | 0.0 | 8.3 |
| MARCH ODDS | - | - | - | - | 0.1 | +6.6 | 0.0 | 0.0 |
| MARCH OVER CASTS | 1.0 | +184.7 | 0.0 | 67.5 | 0.5 | +41.1 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 8.5 | +150.3 | 0.0 | 197.0 | 8.5 | +144.0 | 0.0 | 89.1 |
| MISSILES IN THE MOVE | 2.8 | +42.8 | 0.0 | 169.1 | 4.2 | +76.5 | 0.0 | 65.7 |
| MISSILES NEXT TURN | 3.9 | +31.9 | 0.0 | 206.2 | 4.3 | +60.8 | 0.0 | 65.7 |
| MOVE AND CAST | - | - | - | - | 0.6 | +18.9 | 0.0 | 0.0 |
| MOVE TO CHARGE | - | - | - | - | 4.8 | +473.4 | 205.8 | 41.1 |
| MOVES UNITS SPELL | 0.2 | +1.5 | 0.0 | 0.0 | 0.1 | +0.3 | 0.0 | 0.0 |
| NEEDED THERE | 0.1 | +11.1 | 0.0 | 0.0 | - | - | - | - |
| NOT NEEDED | - | - | - | - | 0.2 | -21.8 | 50.9 | 0.0 |
| NOT TURNED | - | - | - | - | 6.0 | +39.0 | 0.0 | 142.2 |
| NOT WORTH A CAST | 0.6 | -0.4 | 0.0 | 30.4 | 1.6 | -2.4 | 0.0 | 0.0 |
| OFF BEST | 1.0 | -19.3 | 0.0 | 0.0 | 15.4 | -709.0 | 0.0 | 257.0 |
| ONE FIGHT FORMULA | 10.5 | -223.3 | 0.0 | 341.0 | 8.0 | -151.3 | 39.8 | 76.7 |
| ONE OBJECTIVE FORMULA | 2.8 | -10.8 | 0.0 | 73.8 | 2.1 | -101.2 | 0.0 | 35.1 |
| OPENS A LANE | 0.1 | +0.0 | 0.0 | 15.0 | 0.1 | +0.3 | 5.0 | 0.0 |
| OPENS UP | 0.2 | +2.3 | 10.4 | 0.0 | - | - | - | - |
| OVERRUNS AWAY | 0.7 | +2.1 | 128.0 | 8.9 | 0.3 | +4.5 | 15.3 | 10.4 |
| PATHS CROSS | 2.5 | +260.3 | 0.0 | 81.5 | 2.5 | +249.0 | 0.0 | 0.0 |
| PERIAPT WORTH | 0.1 | +4.3 | 0.0 | 0.0 | - | - | - | - |
| PIVOT GUARDS FLANK | 0.2 | -5.1 | 0.0 | 11.1 | 0.2 | -9.9 | 0.0 | 11.1 |
| PLAN RESULT | 36.2 | +287.0 | 173.1 | 1371.2 | 38.6 | +951.9 | 1627.5 | 755.6 |
| PURSUES BIG PREY | - | - | - | - | 0.1 | -3.7 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE | - | - | - | - | 0.1 | +13.5 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE NEXT TURN | - | - | - | - | 0.2 | +9.6 | 0.0 | 0.0 |
| RANDOM MOVE BY FIGURES | 0.5 | +16.1 | 0.0 | 45.4 | 2.0 | +2.3 | 0.0 | 65.4 |
| RANDOM MOVER NO PROMISE | - | - | - | - | 0.6 | -13.9 | 0.0 | 13.1 |
| REDIRECT BY WHAT IT STOPS | 0.1 | +9.1 | 0.0 | 2.6 | 1.5 | -57.2 | 0.0 | 34.8 |
| REDIRECT COUNTER | 4.1 | +164.1 | 0.0 | 64.2 | 4.9 | +408.6 | 0.0 | 47.8 |
| REDIRECT WEIGHED | 0.6 | -0.0 | 45.5 | 43.8 | 0.2 | +0.0 | 0.0 | 7.8 |
| REFUSING RETIRES | 0.4 | +0.0 | 0.0 | 26.7 | 0.8 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | 1.3 | +22.2 | 0.0 | 0.0 | 0.8 | +30.1 | 0.0 | 39.4 |
| RESTRAINS TO SHOOT | 0.1 | +2.2 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | 2.5 | +74.6 | 208.5 | 111.1 | 2.4 | +76.9 | 256.7 | 32.3 |
| RISK ONCE | - | - | - | - | 3.4 | +92.2 | 32.3 | 24.6 |
| RUN DOWN | 2.2 | -59.8 | 129.5 | 132.2 | - | - | - | - |
| SAFE SURE CHARGE | - | - | - | - | 0.1 | -0.8 | 4.2 | 0.0 |
| SAFER THAN THE JOB | - | - | - | - | 0.9 | +31.4 | 0.0 | 0.0 |
| SCOUT SPOT | 0.5 | +0.4 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| SCOUT WAITS | 0.5 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.1 | -14.5 | 0.0 | 3.2 | 0.5 | -33.8 | 0.0 | 7.8 |
| SEARCH SPOT | 5.5 | +205.9 | 0.0 | 185.0 | 3.5 | +190.9 | 0.0 | 20.1 |
| SELF MOVE SPELL | 1.1 | +137.7 | 0.0 | 80.5 | - | - | - | - |
| SET UP TOGETHER | 0.8 | +27.7 | 0.0 | 8.5 | 2.5 | +216.2 | 88.7 | 11.1 |
| SET-UP ANY TARGET | 0.1 | +14.8 | 0.0 | 0.0 | 0.2 | +38.1 | 0.0 | 39.1 |
| SHOOTERS IN TWO RANKS | 0.5 | +0.9 | 0.0 | 0.0 | 0.2 | +0.5 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 0.4 | +10.3 | 12.2 | 63.5 | 1.2 | +52.8 | 168.5 | 8.8 |
| SHOT REPLANNED | 0.5 | +0.0 | 74.0 | 0.0 | - | - | - | - |
| SHOTS IN THE MOVE | 10.3 | +209.8 | 0.0 | 156.6 | 7.8 | +259.8 | 0.0 | 58.3 |
| SPELL CATCH ODDS | - | - | - | - | 0.1 | -0.8 | 0.0 | 21.1 |
| SPELL SETS UP CHARGE | 0.1 | +14.8 | 0.0 | 0.0 | 0.2 | +38.1 | 0.0 | 39.1 |
| SPELL WORTH | 2.1 | +27.3 | 126.3 | 81.5 | 1.9 | +20.3 | 23.8 | 23.8 |
| SPELLS IN THE FIGHT | 0.2 | -8.1 | 24.3 | 19.6 | - | - | - | - |
| STABLE ROLE | - | - | - | - | 10.5 | +0.0 | 234.3 | 95.8 |
| STAND AND SHOOT | 0.3 | -5.8 | 5.1 | 23.9 | - | - | - | - |
| STAY WEIGHED | - | - | - | - | 0.1 | +12.1 | 0.0 | 0.0 |
| STOPS | 0.1 | +0.3 | 15.0 | 2.6 | - | - | - | - |
| STOPS SHORT OF THE FLANK | - | - | - | - | 0.7 | +55.1 | 0.0 | 0.0 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 16.2 | 0.2 | +0.0 | 0.0 | 0.0 |
| SUPPORT NARROWED | 1.5 | +0.0 | 87.2 | 120.5 | 9.0 | -96.0 | 498.0 | 107.1 |
| SUPPORTS | - | - | - | - | 6.9 | +100.9 | 301.0 | 56.0 |
| SURE CHARGE BEATS ADVANCE | - | - | - | - | 0.2 | -3.2 | 4.6 | 0.0 |
| SURE REACH TOGETHER | 0.9 | +33.8 | 0.0 | 9.2 | 1.2 | +31.2 | 9.2 | 11.1 |
| THROUGH LINE OF FIRE | - | - | - | - | 0.3 | +33.3 | 0.0 | 0.0 |
| TIME ON OUR SIDE | 1.2 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| TURN WORTH | 0.2 | -7.8 | 9.3 | 0.0 | - | - | - | - |
| TWO OR MORE ARRIVE | - | - | - | - | 0.5 | +5.6 | 26.7 | 0.0 |
| WAIT AFTER COSTS | - | - | - | - | 7.8 | -359.8 | 343.9 | 91.7 |
| WALKS TO THE FIGHT | - | - | - | - | 1.2 | +6.2 | 32.8 | 9.2 |
| WAR ENGINE CHARGES | 0.1 | +0.9 | 0.0 | 14.2 | - | - | - | - |
| WAR ENGINE JOBS | - | - | - | - | 0.1 | +0.0 | 0.0 | 5.8 |
| WEARS DOWN | 1.0 | +73.1 | 87.6 | 103.7 | 1.2 | +46.2 | 249.9 | 34.1 |
| WHO HITS BACK | 0.4 | +47.8 | 0.0 | 33.2 | 0.3 | +29.6 | 0.0 | 13.1 |
| WHOLE FIGHT | 0.3 | +21.7 | 48.1 | 0.0 | 0.5 | +46.0 | 114.4 | 0.0 |
| WHOLE FIGHT GAIN | 0.1 | +1.2 | 2.3 | 0.0 | 0.3 | +12.1 | 35.7 | 1.5 |
| WIDER SPREAD | 2.0 | -8.2 | 169.6 | 51.7 | 2.8 | -11.2 | 306.1 | 62.2 |

### Rule changes: fa-h2h-mine-8a94331-p3c

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 213 | 213 | 213 | 16.38 | -9468 | -44.5 |
| SEARCH SPOT | 116 | 116 | 113 | 8.69 | +5165 | +45.7 |
| PATHS CROSS | 65 | 65 | 65 | 5.00 | +6620 | +101.9 |
| KILLS COUNT NEXT TURN | 101 | 101 | 48 | 3.69 | +881 | +18.4 |
| SUPPORTS | 90 | 90 | 43 | 3.31 | +446 | +10.4 |
| REDIRECT COUNTER | 117 | 72 | 42 | 3.23 | +2798 | +66.6 |
| MOVE TO CHARGE | 62 | 62 | 34 | 2.62 | +2548 | +74.9 |
| FOLLOW UP WEIGHED | 28 | 28 | 28 | 2.15 | +5889 | +210.3 |
| COVER ONCE | 171 | 100 | 27 | 2.08 | +410 | +15.2 |
| RESERVE FALL BACK | 27 | 27 | 27 | 2.08 | +679 | +25.2 |
| FACES THE THREAT | 25 | 25 | 25 | 1.92 | +2270 | +90.8 |
| MAX FOR POSITIONING | 222 | 176 | 25 | 1.92 | +200 | +8.0 |
| SHOTS IN THE MOVE | 235 | 153 | 24 | 1.85 | +457 | +19.1 |
| FALLBACK BY WORTH | 76 | 76 | 23 | 1.77 | +1345 | +58.5 |
| IDLE COST | 495 | 264 | 22 | 1.69 | +248 | +11.3 |
| FIVE ACTION | 524 | 524 | 20 | 1.54 | +1625 | +81.3 |
| CHARGE LOSSES | 143 | 143 | 19 | 1.46 | +2120 | +111.6 |
| CHAFF IN THE MOVE | 30 | 28 | 18 | 1.38 | +363 | +20.1 |
| HOLDS AMBUSHERS | 18 | 18 | 18 | 1.38 | +0 | +0.0 |
| WAIT AFTER COSTS | 101 | 101 | 18 | 1.38 | +329 | +18.3 |
| ADVANCE LANE KEPT | 17 | 17 | 17 | 1.31 | +0 | +0.0 |
| RISK BY ARC | 63 | 62 | 17 | 1.31 | +599 | +35.3 |
| MISSILES IN THE MOVE | 91 | 62 | 16 | 1.23 | +250 | +15.6 |
| FOUR ROUNDS | 45 | 45 | 15 | 1.15 | +1038 | +69.2 |
| ONE FIGHT FORMULA | 240 | 141 | 14 | 1.08 | +154 | +11.0 |
| SET UP TOGETHER | 43 | 30 | 14 | 1.08 | +911 | +65.1 |
| KILLS COUNT | 43 | 43 | 12 | 0.92 | +586 | +48.8 |
| SAFER THAN THE JOB | 12 | 12 | 12 | 0.92 | +408 | +34.0 |
| MARCH CHECK | 12 | 11 | 11 | 0.85 | +185 | +16.8 |
| COMBAT PIVOT | 10 | 10 | 10 | 0.77 | +0 | +0.0 |
| REDIRECT WEIGHED | 10 | 10 | 10 | 0.77 | +341 | +34.1 |
| SHOOTS FROM THE BEST SPOT | 21 | 21 | 10 | 0.77 | +125 | +12.5 |
| SURE REACH TOGETHER | 27 | 23 | 10 | 0.77 | +234 | +23.4 |
| CAST JOB | 11 | 11 | 9 | 0.69 | +311 | +34.6 |
| RISK ONCE | 44 | 32 | 9 | 0.69 | +137 | +15.2 |
| SCOUT WAITS | 9 | 9 | 9 | 0.69 | +0 | +0.0 |
| STOPS SHORT OF THE FLANK | 9 | 9 | 9 | 0.69 | +716 | +79.5 |
| WALKS TO THE FIGHT | 15 | 15 | 9 | 0.69 | +20 | +2.2 |
| WHO HITS BACK | 9 | 9 | 9 | 0.69 | +649 | +72.1 |
| BEST FIRST | 8 | 8 | 8 | 0.62 | +475 | +59.4 |
| CHAFF PASSED | 8 | 8 | 8 | 0.62 | -13 | -1.6 |
| CHARGE NOW FIRST | 52 | 52 | 8 | 0.62 | -262 | -32.8 |
| MOVE AND CAST | 8 | 8 | 8 | 0.62 | +246 | +30.7 |
| RANDOM MOVE BY FIGURES | 33 | 33 | 8 | 0.62 | +239 | +29.9 |
| SHOOTERS IN TWO RANKS | 8 | 8 | 8 | 0.62 | +18 | +2.2 |
| ADVANCE WORTH | 57 | 57 | 7 | 0.54 | +35 | +5.0 |
| BEST OVERALL | 7 | 7 | 7 | 0.54 | +231 | +33.1 |
| MANOEUVRE | 13 | 13 | 7 | 0.54 | +214 | +30.5 |
| BLOCKED WHEEL | 6 | 6 | 6 | 0.46 | +24 | +3.9 |
| LONE WIZARD KEPT IN | 6 | 6 | 6 | 0.46 | +212 | +35.4 |
| PIVOT GUARDS FLANK | 6 | 6 | 6 | 0.46 | -195 | -32.5 |
| SHOT REPLANNED | 6 | 6 | 6 | 0.46 | +0 | +0.0 |
| BEST FACING | 5 | 5 | 5 | 0.38 | +131 | +26.3 |
| CHARGE NOW WEIGHED | 5 | 5 | 5 | 0.38 | +700 | +140.0 |
| KEEPS ITS TARGET | 20 | 20 | 4 | 0.31 | +43 | +10.9 |
| MOVES UNITS SPELL | 4 | 4 | 4 | 0.31 | +23 | +5.8 |
| STUCK PIVOT | 4 | 4 | 4 | 0.31 | +0 | +0.0 |
| THROUGH LINE OF FIRE | 4 | 4 | 4 | 0.31 | +433 | +108.2 |
| WHOLE FIGHT | 11 | 11 | 4 | 0.31 | +639 | +159.8 |
| BACKUP TARGETS | 20 | 15 | 3 | 0.23 | +1 | +0.4 |
| BEST PRIZE | 3 | 3 | 3 | 0.23 | -210 | -69.8 |
| CASTS FROM BEHIND | 3 | 3 | 3 | 0.23 | +0 | +0.0 |
| HORN WORTH | 3 | 3 | 3 | 0.23 | +136 | +45.2 |
| REFUSING RETIRES | 15 | 15 | 3 | 0.23 | -0 | -0.1 |
| WEARS DOWN | 29 | 28 | 3 | 0.23 | +159 | +52.9 |
| AFTERMATH IN POINTS | 2 | 2 | 2 | 0.15 | +370 | +184.8 |
| BEST PREY | 5 | 5 | 2 | 0.15 | +24 | +12.1 |
| CANNON SIGHT KEPT | 2 | 2 | 2 | 0.15 | +0 | +0.0 |
| CASTING BLOCK | 3 | 3 | 2 | 0.15 | +26 | +13.0 |
| FOCUS FIRE | 2 | 2 | 2 | 0.15 | +67 | +33.7 |
| FRIENDS SHOTS CHECKED | 2 | 2 | 2 | 0.15 | +130 | +65.0 |
| HUNT IN PAIRS | 14 | 9 | 2 | 0.15 | +81 | +40.4 |
| MAKE SURE TOGETHER | 23 | 14 | 2 | 0.15 | +81 | +40.4 |
| MISSILES NEXT TURN | 107 | 69 | 2 | 0.15 | +3 | +1.7 |
| ONE OBJECTIVE FORMULA | 64 | 36 | 2 | 0.15 | +50 | +24.8 |
| RAIDS THE BAGGAGE NEXT TURN | 2 | 2 | 2 | 0.15 | +20 | +9.8 |
| SUPPORT NARROWED | 137 | 137 | 2 | 0.15 | -6 | -3.2 |
| SURE CHARGE BEATS ADVANCE | 2 | 2 | 2 | 0.15 | -42 | -21.0 |
| WHOLE FIGHT GAIN | 5 | 5 | 2 | 0.15 | +16 | +8.1 |
| BIG CHARACTER SAFETY | 1 | 1 | 1 | 0.08 | -13 | -12.8 |
| BLOCKED CHARGE SKIPPED | 1 | 1 | 1 | 0.08 | +0 | +0.0 |
| CANNON PLANNED TARGET | 4 | 4 | 1 | 0.08 | +16 | +16.0 |
| CASTER AWAY FROM SCREEN | 1 | 1 | 1 | 0.08 | +0 | +0.0 |
| CATCH ODDS | 1 | 1 | 1 | 0.08 | -65 | -65.4 |
| ELIXIR WORTH | 1 | 1 | 1 | 0.08 | +18 | +17.5 |
| FALLS SHORT | 4 | 4 | 1 | 0.08 | +37 | +37.1 |
| FEATURE BUFFS | 3 | 3 | 1 | 0.08 | +35 | +35.1 |
| HONEST WORTH | 141 | 140 | 1 | 0.08 | +0 | +0.0 |
| INVITES THE FIGHT | 11 | 11 | 1 | 0.08 | +6 | +6.1 |
| LONE WIZARD HOLDS BACK | 8 | 8 | 1 | 0.08 | -72 | -71.6 |
| LOST CHARGE | 41 | 41 | 1 | 0.08 | +21 | +20.8 |
| MARCH ODDS | 1 | 1 | 1 | 0.08 | +58 | +58.3 |
| NEEDED THERE | 1 | 1 | 1 | 0.08 | +0 | +0.0 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.08 | +56 | +56.5 |
| PURSUES BIG PREY | 1 | 1 | 1 | 0.08 | -49 | -48.7 |
| RAIDS THE BAGGAGE | 1 | 1 | 1 | 0.08 | +112 | +111.9 |
| RESTRAINS TO SHOOT | 1 | 1 | 1 | 0.08 | +29 | +28.9 |
| SAFE SURE CHARGE | 1 | 1 | 1 | 0.08 | -10 | -9.6 |
| STAY WEIGHED | 1 | 1 | 1 | 0.08 | +157 | +157.0 |
| TWO OR MORE ARRIVE | 6 | 6 | 1 | 0.08 | +2 | +2.4 |
| BLOWS WHERE AIMED | 10 | 10 | 0 | 0.00 | - | - |
| CARRIES OUT COUNTER | 1 | 1 | 0 | 0.00 | - | - |
| CARRIES OUT SET-UP | 2 | 2 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 5 | trace | - | - | - | - |
| CHARGER SLAIN LOST | 17 | 17 | 0 | 0.00 | - | - |
| CHEAP HELPER | 1 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 6 | not checked | - | - | - | - |
| DEFENSIVE ARMY | 3 | 3 | 0 | 0.00 | - | - |
| EDGE GIVE GROUND | 3 | 3 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 31 | 31 | 0 | 0.00 | - | - |
| FIGHT LIFT | 1 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 152 | not checked | - | - | - | - |
| GATEWAY ESCAPE | 1 | not checked | - | - | - | - |
| GIVES UP | 1 | 1 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 1 | 1 | 0 | 0.00 | - | - |
| GUN MASK | 4 | 4 | 0 | 0.00 | - | - |
| HELPER UNSEEN | 10 | 9 | 0 | 0.00 | - | - |
| HILL BY ITS CHANCE | 7 | 7 | 0 | 0.00 | - | - |
| HUNT ADVANCE | 1 | 1 | 0 | 0.00 | - | - |
| HUNT DROPPED | 1 | trace | - | - | - | - |
| HUNT RESULT | 2 | trace | - | - | - | - |
| HUNT THE GUNS | 2 | trace | - | - | - | - |
| JOINT CHARGE PLAN | 5 | 5 | 0 | 0.00 | - | - |
| JOINT KNOWS CHALLENGE | 3 | 2 | 0 | 0.00 | - | - |
| KEEPS ITS PREY | 1 | 1 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 5 | not checked | - | - | - | - |
| LONG SHOT | 8 | 8 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 2 | 2 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 19 | 19 | 0 | 0.00 | - | - |
| NOT NEEDED | 2 | 2 | 0 | 0.00 | - | - |
| NOT TURNED | 78 | 78 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 29 | not checked | - | - | - | - |
| OPENS A LANE | 2 | 1 | 0 | 0.00 | - | - |
| OPENS UP | 2 | 2 | 0 | 0.00 | - | - |
| OVERRUNS AWAY | 13 | 12 | 0 | 0.00 | - | - |
| PLAN RESULT | 973 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 8 | 8 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 21 | 21 | 0 | 0.00 | - | - |
| RUN DOWN | 28 | 28 | 0 | 0.00 | - | - |
| SCOUT SPOT | 8 | 8 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 7 | 7 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 14 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 4 | not checked | - | - | - | - |
| SPELL CATCH ODDS | 1 | not checked | - | - | - | - |
| SPELL SETS UP CHARGE | 4 | not checked | - | - | - | - |
| SPELL WORTH | 52 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 3 | 3 | 0 | 0.00 | - | - |
| STABLE ROLE | 137 | 137 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 4 | 4 | 0 | 0.00 | - | - |
| STOPS | 1 | 1 | 0 | 0.00 | - | - |
| TIME ON OUR SIDE | 15 | 15 | 0 | 0.00 | - | - |
| TURN WORTH | 3 | 3 | 0 | 0.00 | - | - |
| WAR ENGINE CHARGES | 1 | 1 | 0 | 0.00 | - | - |
| WAR ENGINE JOBS | 1 | 1 | 0 | 0.00 | - | - |
| WIDER SPREAD | 62 | 62 | 0 | 0.00 | - | - |

### Off best figure: fa-h2h-mine-8a94331-p3c

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 0.69 | 14.46 | 44.0 |
| CHARGE NOW FIRST | rule | 0.23 | 0.38 | 32.8 |
| TURN GATE | gate | - | 0.54 | 56.5 |
| PIVOT GUARDS FLANK | rule | 0.23 | 0.23 | 32.5 |
| CHAFF PASSED | rule | 0.31 | 0.08 | 2.5 |
| BEST PRIZE | rule | 0.23 | - | 69.8 |
| AFTERMATH BAND | gate | 0.08 | 0.08 | 4.0 |
| NO REASON | gate | 0.15 | - | 18.1 |
| PATHS CROSS | rule | 0.15 | - | 28.4 |
| REDIRECT WEIGHED | rule | 0.15 | - | 42.7 |
| SUPPORT NARROWED | rule | 0.08 | 0.08 | 3.2 |
| SURE CHARGE BEATS ADVANCE | rule | - | 0.15 | 21.0 |
| AFTERMATH NEEDS NEXT CHARGE | gate | - | 0.08 | 7.5 |
| BIG CHARACTER SAFETY | rule | - | 0.08 | 12.8 |
| BLOCKED WHEEL | rule | - | 0.08 | 12.0 |
| CATCH ODDS | rule | 0.08 | - | 65.4 |
| CHARGE NOW WEIGHED | rule | - | 0.08 | 7.6 |
| FALLBACK | gate | - | 0.08 | 210.4 |
| FIGHT ORDER BAND | gate | 0.08 | - | 0.8 |
| LONE CHARACTER SAFE SPOT | gate | - | 0.08 | 102.5 |
| LONE WIZARD HOLDS BACK | rule | - | 0.08 | 71.6 |
| PURSUES BIG PREY | rule | - | 0.08 | 48.7 |
| SAFE SURE CHARGE | rule | - | 0.08 | 9.6 |
| STOPS SHORT OF THE FLANK | rule | - | 0.08 | 12.8 |
| SUPPORT REQUEST | gate | - | 0.08 | 46.9 |

### Plans: fa-h2h-mine-8a94331-p3c

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 2.8 | 58% | 576 | 217 | 38% |
| Mine | join | 0.2 | 100% | 9 | 0 | 0% |
| Mine | move | 30.9 | 93% | 1977 | 0 | 0% |
| Mine | shoot | 2.2 | 39% | 108 | 70 | 65% |
| Mine | support | 0.2 | 50% | 13 | 0 | 0% |
| Opponent | advance | 11.7 | 16% | 129 | 188 | 146% |
| Opponent | charge | 3.2 | 73% | 323 | 398 | 123% |
| Opponent | close in | 6.6 | 24% | 457 | 144 | 31% |
| Opponent | hold | 3.5 | 51% | 250 | 0 | 0% |
| Opponent | join | 0.5 | 100% | 19 | 0 | 0% |
| Opponent | shoot | 4.5 | 48% | 100 | 222 | 222% |
| Opponent | support | 8.7 | 88% | 72 | 0 | 0% |

### Packages: hunt the guns, fa-h2h-mine-8a94331-p3c

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.1 | 1 | 0 | 100% | 100% | 0% | 2.0 | 229 | 220 | 100% | 0 |
| Opponent | 0.1 | 1 | 0 | 0% | 0% | 0% | - | 243 | 0 | 0% | 0 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Ogre Kingdoms | 1.0 | 1 | 0 | 100% | 100% | 0% | 2.0 | 229 | 220 | 100% | 0 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Tomb Kings of Khemri | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Vampire Counts | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Warriors of Chaos | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Wood Elf Realms | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 243 | 0 | 0% | 0 |

### Battle groups: fa-h2h-mine-8a94331-p3c

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 4.1 | 30% | 62% | 19% | 67% | 8% | 8% | 15% | 69% | 0% |
| Opponent | REDIRECT COUNTER | 4.9 | 11% | 57% | 29% | 50% | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: fa-h2h-mine-8a94331-p3c

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | 0 (1) | - | - | 0 (1) | - |
| Mine | Chaff | 21 | 123 (21) | 47 | 76 | 62 | 10% | 3.1 | 125 (12) | 184 (3) | 99 (6) | 160 (16) | 20 (5) |
| Mine | Character | 30 | 58 (30) | 58 | 0 | 43 | 13% | 2.6 | 67 (13) | 66 (11) | - | 52 (11) | 78 (13) |
| Mine | Clean-up | 10 | 32 (10) | 32 | 0 | 7 | 20% | 3.5 | 42 (2) | 30 (8) | - | 8 (6) | 54 (4) |
| Mine | Fast | 1 | 0 (1) | 0 | 0 | 100 | 0% | 5.0 | - | 0 (1) | - | 0 (1) | - |
| Mine | Fast Hammer | 14 | 38 (14) | 33 | 6 | 58 | 29% | 3.0 | 54 (7) | 27 (4) | 24 (3) | 16 (8) | 66 (6) |
| Mine | Fragile | 3 | 0 (3) | 0 | 0 | 100 | 0% | 2.7 | 0 (3) | - | - | 0 (1) | 0 (2) |
| Mine | Hammer | 17 | 4 (17) | 3 | 2 | 87 | 18% | 2.5 | 3 (5) | 5 (11) | 0 (1) | 5 (13) | 0 (4) |
| Mine | Holder | 8 | 6 (8) | 0 | 6 | 37 | 12% | 3.0 | 0 (1) | 6 (3) | 11 (3) | 19 (3) | 0 (4) |
| Mine | Shooter | 11 | 59 (11) | 16 | 43 | 24 | 0% | 1.5 | 111 (2) | 49 (8) | 0 (1) | 84 (5) | 30 (6) |
| Mine | Support | 4 | 52 (4) | 52 | 0 | 58 | 25% | 2.0 | 0 (1) | - | - | 0 (1) | - |
| Mine | War machine | 2 | 0 (2) | 0 | 0 | 0 | 0% | 3.0 | - | 0 (2) | - | - | 0 (2) |
| Mine | Wizard | 9 | 0 (9) | 0 | 0 | 70 | 11% | 2.0 | 0 (3) | 0 (1) | 0 (2) | 0 (3) | 0 (3) |
| Opponent | Chaff | 24 | 17 (24) | 10 | 7 | 49 | 71% | 2.9 | 0 (9) | 31 (4) | 19 (11) | 23 (18) | 0 (6) |
| Opponent | Character | 38 | 66 (38) | 66 | 0 | 26 | 13% | 2.4 | 47 (12) | 93 (17) | 64 (4) | 69 (23) | 81 (10) |
| Opponent | Fast Hammer | 27 | 57 (27) | 18 | 38 | 63 | 19% | 2.9 | 89 (16) | 3 (6) | 31 (5) | 34 (13) | 77 (14) |
| Opponent | Hammer | 28 | 38 (28) | 29 | 9 | 29 | 32% | 3.3 | 3 (12) | 67 (13) | 0 (3) | 23 (16) | 59 (12) |
| Opponent | Holder | 11 | 69 (11) | 42 | 27 | 41 | 45% | 3.8 | 128 (3) | 38 (5) | 53 (3) | 84 (8) | 11 (3) |
| Opponent | Shooter | 14 | 59 (14) | 19 | 40 | 15 | 7% | 1.0 | 122 (1) | 54 (13) | - | 54 (7) | 64 (7) |
| Opponent | Support | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | 0 (1) | - | - | - | 0 (1) |
| Opponent | Wizard | 11 | 48 (11) | 48 | 0 | 58 | 9% | 2.0 | 9 (4) | 60 (3) | - | 37 (5) | 0 (2) |

### Charged fights: fa-h2h-mine-8a94331-p3c

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | High Elf Realms | 2 | 177 | 864 | 4.0 | 1.2 | 216 | 8 | +208 | 6 of 8 | 6 of 8 | +509 | +108 |
| Mine | Kingdom of Bretonnia | 1 | 38 | 442 | 4.0 | 1.2 | 110 | 69 | +41 | 0 of 4 | 3 of 4 | -133 | +99 |
| Mine | Lizardmen | 1 | 170 | 1033 | 3.0 | 1.0 | 344 | 28 | +317 | 2 of 3 | 3 of 3 | - | +317 |
| Mine | Ogre Kingdoms | 1 | 0 | 170 | 4.0 | 1.2 | 42 | 17 | +26 | 2 of 4 | 1 of 4 | +170 | -23 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 305 | 3.0 | 1.0 | 102 | 153 | -52 | 2 of 3 | 2 of 3 | - | -52 |
| Mine | Skaven | 1 | 19 | 109 | 2.0 | 1.0 | 54 | 32 | +22 | 0 of 2 | 1 of 2 | - | +22 |
| Mine | Tomb Kings of Khemri | 2 | 22 | 746 | 7.0 | 1.0 | 106 | 9 | +98 | 6 of 14 | 11 of 14 | - | +98 |
| Mine | Vampire Counts | 2 | 10 | 238 | 1.5 | 1.0 | 158 | 190 | -32 | 1 of 3 | 1 of 3 | - | -32 |
| Mine | Warriors of Chaos | 2 | 24 | 0 | 1.0 | 1.0 | 0 | 201 | -201 | 0 of 2 | 0 of 2 | - | -201 |
| **Mine** | all armies | 13 | 53 | 442 | 3.3 | 1.1 | 134 | 49 | +85 | 19 of 43 | 28 of 43 | +264 | +66 |
| Opponent | Orc & Goblin Tribes | 1 | 0 | 608 | 4.0 | 1.0 | 152 | 0 | +152 | 3 of 4 | 3 of 4 | - | +152 |
| Opponent | Tomb Kings of Khemri | 1 | 0 | 55 | 3.0 | 1.0 | 18 | 65 | -47 | 1 of 3 | 2 of 3 | - | -47 |
| Opponent | Vampire Counts | 1 | 0 | 0 | 3.0 | 2.0 | 0 | 0 | +0 | 1 of 3 | 3 of 3 | +0 | +0 |
| Opponent | Warriors of Chaos | 5 | 0 | 823 | 4.4 | 1.2 | 187 | 13 | +174 | 8 of 22 | 19 of 22 | +253 | +162 |
| Opponent | Wood Elf Realms | 5 | 120 | 345 | 3.0 | 1.1 | 115 | 21 | +94 | 3 of 15 | 10 of 15 | +275 | +82 |
| **Opponent** | all armies | 13 | 46 | 500 | 3.6 | 1.2 | 138 | 17 | +122 | 16 of 47 | 37 of 47 | +172 | +114 |

### Effective charges: fa-h2h-mine-8a94331-p3c

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | High Elf Realms | 8 | 1 (net -60) | 0 | 2 (net +293) | 2 (net +0) | 1 (net +432) | 2 (net +354) | 0 | 25% (2 of 8) |
| Mine | Kingdom of Bretonnia | 4 | 1 (net +190) | 0 | 0 | 1 (net -133) | 1 (net +108) | 1 (net +0) | 0 | 0% (0 of 4) |
| Mine | Lizardmen | 3 | 1 (net +492) | 0 | 1 (net +87) | 0 | 0 | 0 | 1 | 50% (1 of 2) |
| Mine | Ogre Kingdoms | 4 | 0 | 0 | 1 (net +0) | 0 | 0 | 0 | 3 | 100% (1 of 1) |
| Mine | Skaven | 2 | 1 (net -65) | 0 | 0 | 0 | 0 | 1 (net +109) | 0 | 0% (0 of 2) |
| Mine | Tomb Kings of Khemri | 14 | 1 (net +233) | 0 | 6 (net +72) | 2 (net -30) | 3 (net +65) | 2 (net +281) | 0 | 43% (6 of 14) |
| Mine | Vampire Counts | 3 | 0 | 0 | 1 (net -100) | 2 (net +2) | 0 | 0 | 0 | 33% (1 of 3) |
| Mine | Warriors of Chaos | 2 | 1 (net -402) | 0 | 0 | 1 (net +0) | 0 | 0 | 0 | 0% (0 of 2) |
| Opponent | Orc & Goblin Tribes | 4 | 0 | 0 | 1 (net +482) | 0 | 0 | 0 | 3 | 100% (1 of 1) |
| Opponent | Tomb Kings of Khemri | 3 | 0 | 0 | 1 (net -195) | 1 (net +0) | 1 (net +55) | 0 | 0 | 33% (1 of 3) |
| Opponent | Vampire Counts | 3 | 0 | 0 | 1 (net +0) | 0 | 1 (net +0) | 1 (net +0) | 0 | 33% (1 of 3) |
| Opponent | Warriors of Chaos | 22 | 0 | 0 | 6 (net +145) | 4 (net +472) | 1 (net +0) | 7 (net +146) | 4 | 33% (6 of 18) |
| Opponent | Wood Elf Realms | 15 | 3 (net +22) | 0 | 1 (net +116) | 0 | 0 | 2 (net +210) | 9 | 17% (1 of 6) |

### Charged fights, damage counted: fa-h2h-mine-8a94331-p3c

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 6 | 214 | 198 | +65 | 202 | 99 | +103 | +48.1 |
| Mine | Effective (55-75%) | 11 | 267 | 267 | +92 | 133 | 28 | +105 | +39.4 |
| Mine | 76-89% | 8 | 390 | 210 | -24 | 80 | 108 | -28 | -7.2 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 6 | 272 | 193 | +230 | 252 | 20 | +232 | +85.2 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 5 | 447 | 92 | +147 | 154 | 0 | +154 | +34.5 |
| Mine | No odds | 7 | 202 | 216 | +45 | 130 | 79 | +51 | +25.1 |
| Mine | All fights | 43 | 294 | 208 | +85 | 151 | 57 | +95 | +32.2 |
| Opponent | Long shot (under 50%) | 3 | 106 | 143 | +22 | 57 | 35 | +22 | +20.8 |
| Opponent | Effective (55-75%) | 10 | 228 | 240 | +127 | 193 | 54 | +139 | +61.0 |
| Opponent | 76-89% | 5 | 461 | 230 | +378 | 378 | 50 | +327 | +71.0 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 10 | 237 | 152 | +144 | 146 | 0 | +146 | +61.7 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 3 | 572 | 83 | +18 | 18 | 0 | +18 | +3.2 |
| Opponent | No odds | 16 | 102 | 219 | +62 | 113 | 27 | +86 | +83.8 |
| Opponent | All fights | 47 | 226 | 197 | +122 | 156 | 28 | +127 | +56.3 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| fa-h2h-mine-8a94331-p3c | move | 158 | 35 (22%) | 29 (18%) | 12 (8%) | 111 (70%) |
| fa-h2h-mine-8a94331-p3c | objective | 88 | 20 (23%) | 17 (19%) | 3 (3%) | 65 (74%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L2433, L2630 |
| Charmed Shield | Opponent | L2327 |
| Elixir of Power | Mine | L1932 |
| Elixir of Power | Opponent | L1519 |
| Fistful of Laurels | Mine | L1831 |
| Horn of the Wild Hunt | Opponent | L1633, L2033, L2433, L3133 |
| Invocation of Nehek | Mine | L2433 |
| Invocation of Nehek | Opponent | L2327 |
| Periapt of Soul Exchange | Mine | L2033 |
| Ring of Doom | Mine | L1519, L1535, L3133 |
| Ring of Doom | Opponent | L1633, L1731, L1831, L2033, L2433, L3133 |

# Doctrine scorecard: fa-h2h-mine-8a94331-p1

### Scorecard: fa-h2h-mine-8a94331-p1

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0102 | 6 | 1 | Mine | yes | 14 | 2 | 0 | 1 | 1 | 0 | 0 | 55 |
| L0102 | 6 | 1 | Opponent | no | 2 | 2 | 1 | 4 | 1 | 0 | 0 | 222 |
| L0118 | 4 | 1 | Mine | no | 4 | - | 0 | 2 | 1 | 0 | 0 | 0 |
| L0118 | 4 | 1 | Opponent | no | 0 | 2 | 3 | 3 | 0 | 0 | 0 | 331 |
| L0135 | 3 | 1 | Mine | no | 1 | 6 | 0 | 3 | 0 | 0 | 0 | 0 |
| L0135 | 3 | 1 | Opponent | no | 0 | 2 | 2 | 3 | 0 | 0 | 0 | 0 |
| L0218 | 2 | 1 | Mine | - | - | 2 | 3 | 4 | 0 | 0 | 0 | 0 |
| L0218 | 2 | 1 | Opponent | - | - | 2 | 1 | 2 | 0 | 0 | 0 | 0 |
| L0235 | 1 | 1 | Mine | no | 2 | 6 | 0 | 2 | 0 | 0 | 0 | 170 |
| L0235 | 1 | 1 | Opponent | no | 0 | 2 | 1 | 1 | 0 | 0 | 0 | 0 |
| L0319 | 1 | 1 | Mine | no | 4 | 2 | 2 | 0 | 0 | 0 | 0 | 335 |
| L0319 | 1 | 1 | Opponent | no | 3 | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L0405 | 3 | 1 | Mine | yes | 0 | 3 | 3 | 1 | 0 | 0 | 0 | 263 |
| L0405 | 3 | 1 | Opponent | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 1193 |
| L0421 | 1 | 1 | Mine | no | 3 | 2 | 4 | 0 | 0 | 0 | 0 | 0 |
| L0421 | 1 | 1 | Opponent | no | 2 | - | 1 | 4 | 0 | 0 | 0 | 210 |
| L0508 | 4 | 1 | Mine | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 1465 |
| L0508 | 4 | 1 | Opponent | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 515 |
| L0524 | 2 | 1 | Mine | - | - | - | 0 | 0 | 0 | 0 | 0 | 1212 |
| L0524 | 2 | 1 | Opponent | - | - | 4 | 2 | 2 | 1 | 0 | 0 | 0 |
| L0612 | 6 | 1 | Mine | no | 0 | - | 1 | 0 | 1 | 0 | 0 | 526 |
| L0612 | 6 | 1 | Opponent | no | 8 | 2 | 2 | 0 | 0 | 0 | 0 | 330 |
| L0628 | 4 | 1 | Mine | no | 0 | - | 0 | 4 | 0 | 0 | 0 | 1205 |
| L0628 | 4 | 1 | Opponent | no | 8 | 2 | 1 | 2 | 0 | 0 | 0 | 0 |
| L0717 | 3 | 1 | Mine | yes | 3 | 2 | 2 | 1 | 0 | 0 | 0 | 610 |
| L0717 | 3 | 1 | Opponent | no | 6 | 2 | 1 | 2 | 2 | 0 | 0 | 0 |
| L0733 | 1 | 1 | Mine | no | 3 | 3 | 1 | 1 | 0 | 0 | 0 | 170 |
| L0733 | 1 | 1 | Opponent | no | 5 | 2 | 1 | 2 | 0 | 0 | 0 | 0 |
| L0823 | 1 | 1 | Mine | no | 1 | - | 0 | 1 | 0 | 0 | 0 | 497 |
| L0823 | 1 | 1 | Opponent | no | 0 | 2 | 0 | 2 | 1 | 0 | 0 | 0 |
| L0913 | 1 | 1 | Mine | no | 1 | - | 0 | 2 | 0 | 0 | 0 | 351 |
| L0913 | 1 | 1 | Opponent | no | 8 | 2 | 2 | 1 | 1 | 0 | 0 | 140 |
| L0930 | 6 | 1 | Mine | no | 0 | 4 | 2 | 1 | 0 | 0 | 0 | 310 |
| L0930 | 6 | 1 | Opponent | no | 0 | 2 | 5 | 3 | 0 | 0 | 0 | 98 |
| L1021 | 1 | 1 | Mine | no | 0 | 2 | 2 | 0 | 0 | 0 | 0 | 165 |
| L1021 | 1 | 1 | Opponent | no | 0 | - | 1 | 6 | 2 | 0 | 0 | 795 |
| L1114 | 4 | 1 | Mine | no | 2 | 6 | 0 | 1 | 0 | 0 | 0 | 0 |
| L1114 | 4 | 1 | Opponent | no | 0 | 2 | 1 | 3 | 0 | 0 | 0 | 500 |
| L1131 | 3 | 1 | Mine | no | 5 | - | 5 | 0 | 0 | 0 | 0 | 262 |
| L1131 | 3 | 1 | Opponent | no | 0 | 3 | 2 | 1 | 0 | 0 | 0 | 365 |
| L1224 | 6 | 1 | Mine | no | 6 | 2 | 1 | 0 | 1 | 0 | 0 | 499 |
| L1224 | 6 | 1 | Opponent | no | 4 | 6 | 3 | 2 | 1 | 0 | 0 | 0 |
| L1319 | 5 | 1 | Mine | yes | - | 4 | 1 | 2 | 0 | 0 | 0 | 247 |
| L1319 | 5 | 1 | Opponent | no | - | 2 | 1 | 4 | 1 | 0 | 0 | 0 |
| L1335 | 3 | 1 | Mine | yes | 13 | 5 | 2 | 0 | 1 | 0 | 0 | 140 |
| L1335 | 3 | 1 | Opponent | no | 0 | 2 | 3 | 4 | 0 | 0 | 0 | 126 |
| L1431 | 3 | 1 | Mine | no | 10 | 4 | 4 | 0 | 0 | 0 | 0 | 0 |
| L1431 | 3 | 1 | Opponent | no | 0 | - | 1 | 2 | 0 | 0 | 0 | 340 |
| L1527 | 3 | 1 | Mine | yes | 3 | 4 | 2 | 1 | 0 | 0 | 0 | 0 |
| L1527 | 3 | 1 | Opponent | no | 0 | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L1625 | 5 | 1 | Mine | no | - | 3 | 2 | 0 | 0 | 0 | 0 | 100 |
| L1625 | 5 | 1 | Opponent | yes | - | 2 | 4 | 2 | 0 | 0 | 0 | 0 |
| L1723 | 1 | 1 | Mine | no | 0 | 4 | 3 | 0 | 0 | 0 | 0 | 83 |
| L1723 | 1 | 1 | Opponent | yes | 4 | 2 | 6 | 2 | 1 | 0 | 0 | 0 |
| L1823 | 5 | 1 | Mine | yes | - | 5 | 1 | 2 | 0 | 0 | 0 | 536 |
| L1823 | 5 | 1 | Opponent | yes | - | 2 | 0 | 1 | 2 | 0 | 0 | 0 |
| L1923 | 3 | 1 | Mine | no | 0 | 2 | 5 | 1 | 0 | 0 | 0 | 0 |
| L1923 | 3 | 1 | Opponent | no | 5 | 2 | 6 | 3 | 0 | 0 | 0 | 185 |
| L2025 | 3 | 1 | Mine | yes | 5 | - | 0 | 2 | 2 | 0 | 0 | 420 |
| L2025 | 3 | 1 | Opponent | no | 3 | 2 | 2 | 3 | 0 | 0 | 0 | 0 |
| L2127 | 3 | 1 | Mine | no | 13 | - | 2 | 2 | 1 | 0 | 0 | 500 |
| L2127 | 3 | 1 | Opponent | no | 3 | 3 | 8 | 1 | 0 | 0 | 0 | 0 |
| L2231 | 5 | 1 | Mine | yes | - | 3 | 4 | 1 | 0 | 0 | 0 | 170 |
| L2231 | 5 | 1 | Opponent | no | - | - | 1 | 1 | 4 | 0 | 0 | 371 |
| L2335 | 1 | 1 | Mine | no | 1 | 2 | 3 | 0 | 2 | 0 | 0 | 72 |
| L2335 | 1 | 1 | Opponent | no | 1 | 3 | 6 | 0 | 0 | 0 | 0 | 0 |
| L2531 | 5 | 1 | Mine | yes | - | - | 2 | 4 | 0 | 0 | 0 | 68 |
| L2531 | 5 | 1 | Opponent | no | - | - | 0 | 3 | 0 | 0 | 0 | 0 |
| L2730 | 6 | 1 | Mine | no | 0 | 1 | 1 | 4 | 0 | 0 | 0 | 0 |
| L2730 | 6 | 1 | Opponent | no | 2 | 2 | 2 | 2 | 0 | 0 | 0 | 0 |
| L2934 | 6 | 1 | Mine | no | 7 | 4 | 0 | 1 | 0 | 0 | 0 | 170 |
| L2934 | 6 | 1 | Opponent | no | 0 | 2 | 2 | 1 | 1 | 0 | 0 | 0 |
| **Average** | | | Mine | 29% | 3.5 | 3.3 | 1.6 | 1.3 | 0.3 | 0.0 | 0.0 | 294.5 |
| **Average** | | | Opponent | 9% | 2.2 | 2.3 | 2.2 | 2.2 | 0.5 | 0.0 | 0.0 | 158.9 |

### KPIs: fa-h2h-mine-8a94331-p1

Rules off - Opponent only: FIVE ACTION, LIKELY CHARGE, FALLS SHORT, TIME ON OUR SIDE, FEATURE BUFFS, GETS AWAY CHANCE, GUN MASK, RUN DOWN, FOUR ROUNDS, CHARGE LOSSES, CHARACTER GUNS, STAND AND SHOOT, FALL BACK GOOD ORDER, AFTERMATH IN POINTS.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 25% (44 of 174) | 3% (5 of 165) | 14% (49 of 339) |
| Winner chose to follow up after the loser gave ground |  | 90% (35 of 39); on the table 97% | 95% (35 of 37); on the table 100% | 92% (70 of 76); on the table 99% |
| Winner chose to pursue after the loser fell back in good order |  | 83% (5 of 6); on the table 83% | 94% (16 of 17); on the table 100% | 91% (21 of 23); on the table 96% |
| Winner chose to pursue after the loser fled |  | 69% (9 of 13); on the table 77% | 87% (26 of 30); on the table 93% | 81% (35 of 43); on the table 88% |
| Winner chose to follow up or pursue (all three) |  | 84% (49 of 58); on the table 91% | 92% (77 of 84); on the table 98% | 89% (126 of 142); on the table 95% |
| Magic missiles tried each own turn | 50%+ | 37% (121 of 330) | 35% (74 of 210) | 36% (195 of 540) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 46% (121 of 261) | 47% (74 of 159) | 46% (195 of 420) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 43% (12 of 28) | 50% (32 of 64) | 48% (44 of 92) |
| Points that never fought | lower | 47% (33824 of 71484) | 50% (35754 of 71889) | 49% (69578 of 143373) |
|   infantry points that never fought | lower | 53% (8910 of 16863) | 66% (8755 of 13348) | 58% (17665 of 30211) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 57% (159 of 279) | 64% (189 of 295) | 61% (348 of 574) |
| Bound items with a magic missile used (at least once a game) |  | 91% (20 of 22); 1.8 uses a game | 70% (14 of 20); 1.4 uses a game | 81% (34 of 42); 1.6 uses a game |
| Bound items with another spell used |  | 62% (10 of 16); 0.6 uses a game | 25% (2 of 8); 0.1 uses a game | 50% (12 of 24); 0.4 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 63% (12 of 19); 0.3 uses a game | 67% (8 of 12); 0.2 uses a game | 65% (20 of 31); 0.3 uses a game |
|   their share of the points of units over 100 pts | lower | 50% (29951 of 59666) | 59% (36807 of 62699) | 55% (66758 of 122365) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 2.3 (40%) | 1.3 (35%) | 3.6 (38%) |
| MARCHED: its unit marched | 1.2 (21%) | 0.3 (7%) | 1.5 (15%) |
| CHARGED: its unit charged | 0.3 (5%) | 0.2 (4%) | 0.4 (5%) |
| IN COMBAT: engaged in combat | 0.9 (16%) | 0.2 (6%) | 1.1 (12%) |
| REAR RANK: in a rear rank | 0.1 (1%) | 0.3 (8%) | 0.4 (4%) |
| FLEEING: fleeing | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| GONE: slain | 0.8 (13%) | 0.8 (21%) | 1.5 (16%) |
| OFF THE TABLE: off the table or not arrived | 0.2 (3%) | 0.4 (11%) | 0.6 (6%) |
| STUPIDITY: Stupidity | 0.1 (1%) | 0.1 (4%) | 0.2 (2%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.1 (3%) | 0.1 (1%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 3.9 | 1.6 | 1.3 | 5.4 | 0.5 | 1.2 |
| not cast | 4.1 | 2.8 | 3.4 | 9.6 | 1.8 | 22.8 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.9 (4%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.2 (42%) | 0.4 (13%) | 3.6 (38%) | 0.6 (31%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.5 (15%) | 0.2 (9%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.4 (5%) | 0.1 (3%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.1 (2%) | 0.2 (8%) | 0.3 (9%) | 1.1 (12%) | 0.2 (11%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.2 (6%) | 0.3 (8%) | 0.4 (4%) | 0.0 (0%) | 0.0 (0%) |
| NO CASTS LEFT: every cast used on other spells | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (2%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (0%) | 0.1 (3%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.4 (2%) |
| GONE: slain | 0.9 (22%) | 0.4 (16%) | 0.7 (20%) | 1.5 (16%) | 0.1 (3%) | 2.9 (13%) |
| OFF THE TABLE: off the table or not arrived | 0.4 (10%) | 0.3 (12%) | 0.4 (13%) | 0.6 (6%) | 0.1 (5%) | 1.4 (6%) |
| STUPIDITY: Stupidity | 0.1 (3%) | 0.0 (1%) | 0.0 (1%) | 0.2 (2%) | 0.0 (0%) | 0.4 (2%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (1%) | 0.1 (4%) | 0.0 (0%) | 0.0 (0%) | 0.7 (37%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.5 (62%) | 0.2 (9%) | 1.2 (35%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 16.7 (73%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.2 a game | 0.3 a game | 0.8 a game |
| stood (cast and not dispelled) | 66% (27 of 41) | 45% (5 of 11) | 62% (32 of 52) |
| the unit moved after it | 74% (20 of 27) | 80% (4 of 5) | 75% (24 of 32) |
| it charged on its next turn | 0% (0 of 27) | 0% (0 of 5) | 0% (0 of 32) |
| the enemy charged it first | 15% (4 of 27) | 20% (1 of 5) | 16% (5 of 32) |
| it fought by the end of its next turn | 11% (3 of 27) | 20% (1 of 5) | 12% (4 of 32) |
| it moved out of a charge the enemy had planned (not charged first) | 19% (5 of 27) | 0% (0 of 5) | 16% (5 of 32) |
| none of these (no charge, no fight, no charge escaped) | 63% (17 of 27) | 80% (4 of 5) | 66% (21 of 32) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 65% (573 of 876) | 61% (380 of 622) | 64% (953 of 1498) |
|   cavalry | 63% (46 of 73) | 69% (86 of 125) | 67% (132 of 198) |
|   character | 55% (66 of 119) | 33% (38 of 115) | 44% (104 of 234) |
|   chariot | 58% (50 of 86) | 62% (23 of 37) | 59% (73 of 123) |
|   infantry | 62% (184 of 295) | 64% (160 of 251) | 63% (344 of 546) |
|   monster | 66% (25 of 38) | 41% (11 of 27) | 55% (36 of 65) |
|   war machine | 76% (202 of 265) | 93% (62 of 67) | 80% (264 of 332) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.5 (18%) | 1.4 (21%) | 2.9 (19%) |
| CHARGED: it charged | 0.5 (6%) | 1.3 (19%) | 1.8 (12%) |
| FLEEING: it fled or was fleeing | 0.2 (2%) | 0.0 (0%) | 0.2 (1%) |
| IN COMBAT: it fought this turn or the last | 0.6 (8%) | 0.3 (4%) | 0.9 (6%) |
| MOVED: a war machine that moved | 0.9 (11%) | 0.0 (0%) | 0.9 (6%) |
| NO TARGET IN RANGE | 2.2 (27%) | 2.1 (31%) | 4.3 (28%) |
| ONLY IN COMBAT: the only targets were in combat | 0.4 (5%) | 0.4 (5%) | 0.8 (5%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.6 (19%) | 1.0 (14%) | 2.6 (17%) |
| SHELTERED: the target was sheltered | 0.1 (1%) | 0.1 (2%) | 0.2 (2%) |
| STUPIDITY | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR | 0.3 (3%) | 0.1 (2%) | 0.4 (3%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 5.1 | 1.2 | 82% | 6.0 pts | 31 pts |
| character | 3.2 | 0.8 | 82% | 6.1 pts | 20 pts |
| chariot | 2.0 | 1.5 | 63% | 19.4 pts | 39 pts |
| infantry | 13.6 | 4.8 | 74% | 9.7 pts | 132 pts |
| monster | 1.1 | 0.2 | 87% | 3.5 pts | 4 pts |
| war machine | 7.3 | 5.6 | 64% | 25.5 pts | 187 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 2.4 | 4.8 | 3.6 |
| Charges that made contact a game | 1.8 | 3.4 | 2.6 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.65 declared, 0.45 contact (20 units) | 0.29 declared, 0.14 contact (14 units) | 0.50 declared, 0.32 contact (34 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.20 declared, 0.20 contact (5 units) | 1.50 declared, 1.12 contact (8 units) | 1.00 declared, 0.77 contact (13 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.28 declared, 0.22 contact (260 units) | 0.56 declared, 0.40 contact (281 units) | 0.42 declared, 0.31 contact (541 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 59% (41 of 70) | 67% (14 of 21) | 25% (2 of 8) | 58% (57 of 99) |
| Character in a unit | 87% (40 of 46) | 78% (18 of 23) | 80% (4 of 5) | 84% (62 of 74) |
| Character on its own | 83% (34 of 41) | 51% (19 of 37) | 26% (16 of 61) | 50% (69 of 139) |
| Chariot | 69% (11 of 16) | 60% (6 of 10) | - | 65% (17 of 26) |
| Infantry | 61% (54 of 89) | 47% (17 of 36) | 50% (1 of 2) | 57% (72 of 127) |
| Monster | 47% (15 of 32) | 70% (7 of 10) | - | 52% (22 of 42) |
| Monstrous | 73% (8 of 11) | 86% (12 of 14) | - | 80% (20 of 25) |
| War Machines | 68% (28 of 41) | 100% (1 of 1) | - | 69% (29 of 42) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 6 | 75% (12 of 16); on the table 94% | 40% (55 of 138) | 46% | 45% (15 of 33) | 89% (8 of 9); 4.5 uses a game | 100% (3 of 3); 1.7 uses a game | 89% (8 of 9); 1.3 uses a game |
| Chaos Dwarfs | 3 | 100% (5 of 5); on the table 100% | 33% (8 of 24) | 55% | 42% (10 of 24) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Dwarfen Mountain Holds | 5 | 80% (4 of 5); on the table 100% | - | 69% | 73% (30 of 41) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 6 | 100% (7 of 7); on the table 100% | 25% (9 of 36) | 64% | 69% (44 of 64) | 0.0 uses a game | 100% (2 of 2); 1.2 uses a game | 25% (1 of 4); 0.2 uses a game |
| Grand Cathay | 5 | 100% (8 of 8); on the table 100% | 46% (50 of 108) | 56% | 48% (21 of 44) | 100% (12 of 12); 7.6 uses a game | 0% (0 of 1); 0.0 uses a game | 40% (2 of 5); 0.4 uses a game |
| High Elf Realms | 6 | 86% (12 of 14); on the table 93% | 23% (7 of 30) | 47% | 49% (24 of 49) | 80% (4 of 5); 2.8 uses a game | 39% (7 of 18); 1.5 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | 100% (3 of 3); on the table 100% | - | 18% | 50% (3 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Lizardmen | 2 | 100% (4 of 4); on the table 100% | - | 56% | 71% (10 of 14) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 3 | 75% (3 of 4); on the table 100% | 17% (2 of 12) | 63% | 71% (15 of 21) | 33% (1 of 3); 1.3 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 3 | 100% (6 of 6); on the table 100% | 22% (8 of 36) | 16% | 71% (17 of 24) | 0.0 uses a game | 0.0 uses a game | 100% (3 of 3); 1.0 uses a game |
| Skaven | 4 | 71% (5 of 7); on the table 86% | 43% (13 of 30) | 33% | 65% (22 of 34) | 100% (3 of 3); 1.8 uses a game | 0.0 uses a game | 100% (4 of 4); 1.0 uses a game |
| Tomb Kings of Khemri | 6 | 90% (18 of 20); on the table 90% | 8% (1 of 12) | 37% | 27% (8 of 30) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 8 | 88% (21 of 24); on the table 96% | 50% (27 of 54) | 41% | 64% (32 of 50) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 8 | 90% (9 of 10); on the table 90% | 20% (6 of 30) | 54% | 72% (53 of 74) | 100% (4 of 4); 2.4 uses a game | 0.0 uses a game | 50% (1 of 2); 0.1 uses a game |
| Wood Elf Realms | 6 | 100% (9 of 9); on the table 100% | 30% (9 of 30) | 46% | 67% (44 of 66) | 33% (2 of 6); 0.8 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (fa-h2h-mine-8a94331-p1, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 55% (42) | 43% (20) | 50% (62) |
| ...free all their last turn and able to turn (per game) | 0.83 | 0.36 | 1.19 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.19 | 0.08 | 0.28 |
| ...with the charger already in that arc before they moved (per game) | 0.50 | 0.31 | 0.81 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 1.33 | 1.33 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.78 | 0.78 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.11 | 5.06 | 5.17 |

### Quality by phase: fa-h2h-mine-8a94331-p1

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.1 | 3.4 |
| Strategy | Charge objectives carried out (made contact) | 61% (46 of 76) | 46% (67 of 147) |
| Strategy | Shoot objectives carried out (shot that target) | 50% (177 of 355) | 48% (120 of 250) |
| Strategy | Close-in objectives charged next turn | - | 13% (33 of 253) |
| Strategy | Support requests answered (helper made contact too) | 62% (5 of 8) | 53% (9 of 17) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (2 of 2) | 100% (4 of 4) |
| Strategy | Hexes on a unit its side charged or shot that turn | 28% (5 of 18) | 56% (5 of 9) |
| Strategy | Joined characters whose unit fought | 32% (18 of 56) | 42% (21 of 50) |
| Strategy | Lone characters that fought | 74% (67 of 90) | 63% (54 of 86) |
| Movement | Charges halted short of contact | 0.1 | 0.3 |
| Movement | Idle units | 1.3 | 2.2 |
| Movement | Points that never moved of their own | 294.5 | 158.9 |
| Movement | Fights charged into per game | 1.7 | 2.9 |
| Movement | Charges with odds: long shots (under 50%) | 7 of 54, net +87 | 18 of 92, net +68 |
| Movement | Charges with odds: sweet spot (55-75%) | 13 of 54, net +271 | 16 of 92, net +256 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 6 of 54, net +75 | 7 of 92, net +154 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 21 of 54, net +85 | 20 of 92, net +125 |
| Shooting | Shots by shooting units (incl. breath weapons) | 11.3 | 9.9 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 49% (199 of 406) | 53% (189 of 356) |
| Shooting | Points destroyed by shooting units | 69.3 | 40.8 |
| Shooting | War machine shots | 5.6 | 1.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 49% (99 of 202) | 29% (18 of 62) |
| Shooting | Points destroyed by war machines | 96.7 | 18.8 |
| Magic | Magic missiles cast | 2.5 | 1.5 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 30% (27 of 90) | 33% (18 of 55) |
| Magic | Wounds caused by magic missiles | 5.4 | 0.8 |
| Magic | Wounds caused by other spells | 1.0 | 0.7 |
| Magic | Points destroyed by magic (all spells) | 75.6 | 34.6 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.4 / 0.5 / 0.6 / 0.3 | 1.3 / 0.4 / 0.3 / 0.1 |
| Combat | Points destroyed in combat | 281.2 | 304.0 |
| Combat | Points run down | 25.1 | 114.5 |
| Combat | Net points per charged fight, damage counted | +115 | +100 |
| Combat | Net per 100 charger points, damage counted | +40.6 | +39.9 |
| Combat | First round won (charged fights) | 68% | 68% |
| Combat | Net points per charged fight | +123 | +104 |
| Combat | Net points per supported fight / lone fight | +186 / +116 | +175 / +93 |
| Combat | Charged fights on a top-3 enemy unit | 20 of 60 | 45 of 106 |
| Game | Points lost | 630.8 | 682.6 |
| Game | VP from objectives | 559.2 | 684.7 |
| Game | Lone holders (player turns) | 3.5 | 2.2 |

- Mine won / drew / lost: 11 / 9 / 16 of 36 ended games (of 36); mean margin (Mine - Opponent) -81 VP
- The side that went first won 14 of 27 games with a winner
- Points traded per game (both sides' losses): 1313
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: fa-h2h-mine-8a94331-p1

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.6 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| ADVANCE WORTH | - | - | - | - | 5.1 | -168.1 | 142.1 | 89.4 |
| AFTERMATH IN POINTS | 0.1 | +8.5 | 0.0 | 6.2 | - | - | - | - |
| ARRIVAL HUNT | - | - | - | - | 0.0 | +0.3 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.1 | +0.0 | 0.0 | 11.1 | 0.4 | +0.0 | 0.0 | 9.7 |
| BACKUP TARGETS | 0.2 | +0.9 | 0.0 | 11.1 | 0.6 | +5.7 | 0.0 | 10.7 |
| BEST FACING | - | - | - | - | 0.4 | +3.3 | 0.0 | 12.0 |
| BEST FIRST | - | - | - | - | 1.0 | +56.8 | 13.2 | 23.0 |
| BEST OVERALL | - | - | - | - | 0.3 | +5.9 | 0.0 | 0.0 |
| BEST PREY | - | - | - | - | 0.5 | +29.4 | 22.0 | 0.0 |
| BEST PRIZE | - | - | - | - | 0.1 | -1.7 | 13.4 | 0.0 |
| BIG CHARACTER SAFETY | - | - | - | - | 0.2 | -1.2 | 0.0 | 0.0 |
| BLOCKED WHEEL | - | - | - | - | 0.2 | +4.0 | 0.0 | 13.7 |
| BLOWS WHERE AIMED | 0.1 | -10.5 | 16.1 | 12.3 | 0.5 | -50.6 | 56.2 | 22.6 |
| BOMBING RUN | 0.1 | +3.5 | 13.7 | 4.2 | - | - | - | - |
| CANNON PLAN MISSED | 0.5 | +0.0 | 38.1 | 0.0 | 0.0 | +0.0 | 2.6 | 0.0 |
| CANNON PLANNED TARGET | 4.6 | +160.3 | 306.1 | 77.2 | 1.5 | +39.1 | 30.6 | 17.5 |
| CANNON SIGHT KEPT | 1.0 | +0.0 | 0.0 | 6.1 | 0.4 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT COUNTER | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT SET-UP | 0.0 | -0.2 | 3.5 | 0.0 | 0.1 | +0.0 | 11.0 | 16.1 |
| CAST JOB | 0.6 | +18.9 | 45.8 | 22.6 | 0.8 | +8.4 | 15.2 | 30.0 |
| CASTER AWAY FROM SCREEN | 0.4 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.5 | +65.1 | 37.9 | 9.6 | 0.2 | +4.7 | 1.5 | 8.8 |
| CASTS AFTER FRIENDS | 0.7 | +0.0 | 0.0 | 41.9 | 0.1 | +0.0 | 0.0 | 11.1 |
| CASTS FROM BEHIND | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CATCH ODDS | - | - | - | - | 0.1 | +2.4 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | 0.2 | +8.5 | 0.0 | 3.3 | 1.5 | +98.4 | 0.0 | 44.6 |
| CHAFF PASSED | 0.3 | -0.3 | 9.0 | 12.1 | 0.2 | -0.5 | 13.0 | 4.4 |
| CHAMPION TAKES THE CHALLENGE | - | - | - | - | 0.0 | +0.2 | 0.0 | 0.0 |
| CHARACTER GUNS | 0.6 | +0.0 | 0.0 | 6.2 | - | - | - | - |
| CHARGE LOSSES | 12.0 | -380.4 | 0.0 | 309.6 | - | - | - | - |
| CHARGE NOW FIRST | 1.2 | +0.0 | 134.6 | 39.9 | 2.5 | +0.0 | 233.6 | 29.0 |
| CHARGE NOW WEIGHED | - | - | - | - | 0.6 | -36.2 | 22.0 | 16.9 |
| CHARGER SLAIN LOST | 0.2 | -6.5 | 31.8 | 2.9 | 0.5 | -14.2 | 37.6 | 19.7 |
| CHARIOT NO STATIC JOB | - | - | - | - | 0.1 | +0.0 | 2.1 | 0.0 |
| CHARIOT WIZARD CAREFUL | - | - | - | - | 0.1 | +0.0 | 0.0 | 0.0 |
| CHEAP HELPER | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 1.9 | 1.4 |
| COMBAT PIVOT | 0.3 | +0.0 | 4.4 | 15.8 | 0.3 | +0.0 | 27.8 | 13.5 |
| CONTINUE AHEAD WEIGHED | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CONVEYANCE SEARCH | 0.6 | +45.5 | 11.1 | 45.6 | 0.1 | +41.4 | 7.6 | 22.8 |
| COVER ONCE | 8.0 | -675.4 | 0.0 | 195.7 | 5.7 | -428.6 | 0.0 | 124.5 |
| DEFENSIVE ARMY | 0.1 | +0.0 | 4.7 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| DEFENSIVE FLOOR | - | - | - | - | 0.1 | +8.4 | 11.9 | 3.5 |
| EDGE GIVE GROUND | 0.2 | +21.5 | 29.9 | 1.7 | 0.2 | +8.9 | 10.7 | 16.1 |
| ELIXIR WORTH | 0.0 | +1.4 | 0.0 | 0.0 | 0.1 | +2.6 | 0.0 | 0.0 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | - | - | - | - | 1.3 | +68.9 | 0.0 | 68.1 |
| FALL BACK GOOD ORDER | 1.2 | +6.4 | 100.5 | 43.0 | - | - | - | - |
| FALLBACK BY WORTH | 0.1 | +0.0 | 0.0 | 0.0 | 5.6 | +66.3 | 0.0 | 58.2 |
| FALLS SHORT | 0.1 | -0.9 | 0.0 | 1.7 | - | - | - | - |
| FEATURE BUFFS | 1.1 | +29.7 | 0.0 | 15.9 | - | - | - | - |
| FIGHT LIFT | 0.0 | +0.1 | 0.0 | 0.0 | - | - | - | - |
| FIVE ACTION | 44.4 | +2684.8 | 890.6 | 744.1 | - | - | - | - |
| FLANK NOT WEIGHED | 5.4 | +0.0 | 0.0 | 158.6 | 4.4 | +0.0 | 0.0 | 142.1 |
| FOCUS FIRE | 0.0 | +2.1 | 3.2 | 0.0 | - | - | - | - |
| FOLLOW UP WEIGHED | 0.7 | +151.9 | 0.0 | 16.8 | 0.6 | +118.7 | 0.0 | 20.0 |
| FOUR ROUNDS | 2.0 | +142.6 | 190.2 | 52.0 | - | - | - | - |
| FRIENDS SHOTS CHECKED | 0.1 | +7.8 | 0.0 | 6.1 | 0.1 | +3.5 | 0.0 | 0.0 |
| GIVES UP | 0.0 | -0.1 | 0.0 | 0.0 | 0.1 | -1.0 | 3.5 | 6.5 |
| GIVES UP ITS SCREEN | 0.0 | -0.1 | 0.8 | 0.0 | 0.0 | -0.2 | 1.9 | 0.0 |
| GROUND FLIERS | 0.1 | +1.5 | 0.0 | 0.0 | 0.1 | +1.8 | 0.0 | 0.0 |
| GUN MASK | 0.8 | +25.4 | 0.0 | 2.9 | - | - | - | - |
| HELPER ALREADY ASKED | - | - | - | - | 0.1 | +0.0 | 9.6 | 4.1 |
| HELPER UNSEEN | - | - | - | - | 0.3 | +0.0 | 13.5 | 5.0 |
| HILL BY ITS CHANCE | - | - | - | - | 0.2 | -23.4 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.8 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 1.8 | -73.0 | 176.0 | 37.6 | 9.4 | -204.8 | 470.5 | 138.4 |
| HUNT ADVANCE | - | - | - | - | 0.2 | +5.3 | 13.6 | 2.9 |
| HUNT DROPPED | 0.1 | +0.0 | 0.0 | 1.7 | 0.1 | +0.0 | 9.3 | 2.9 |
| HUNT IN PAIRS | 0.4 | +18.0 | 0.0 | 0.0 | 0.6 | +24.6 | 0.0 | 5.4 |
| HUNT KEPT | - | - | - | - | 0.1 | +2.4 | 10.0 | 0.0 |
| HUNT RESULT | 0.1 | +0.0 | 0.0 | 1.7 | 0.3 | +22.8 | 12.1 | 2.9 |
| HUNT THE GUNS | 0.1 | +21.9 | 0.0 | 1.7 | 0.3 | +70.0 | 20.0 | 2.9 |
| IDLE COST | 16.1 | -263.2 | 0.0 | 121.4 | 19.6 | -297.7 | 0.0 | 220.0 |
| INVITES THE FIGHT | - | - | - | - | 1.3 | +7.9 | 31.8 | 25.4 |
| JOINT CHARGE PLAN | - | - | - | - | 0.3 | +18.4 | 6.1 | 17.1 |
| JOINT KNOWS CHALLENGE | 0.0 | -3.2 | 0.0 | 0.0 | 0.0 | -0.3 | 0.0 | 0.0 |
| KEEP FALLS | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KEEPS ITS PREY | - | - | - | - | 0.1 | +0.7 | 1.8 | 8.2 |
| KEEPS ITS TARGET | - | - | - | - | 2.2 | +65.8 | 160.5 | 38.1 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KILLS COUNT | 1.2 | +47.5 | 94.2 | 21.4 | 2.0 | +102.6 | 173.4 | 15.8 |
| KILLS COUNT NEXT TURN | - | - | - | - | 6.4 | +240.8 | 256.4 | 148.8 |
| LONE CHARACTER SAFE SPOT | 0.1 | +0.0 | 0.0 | 0.0 | 0.5 | +11.8 | 11.9 | 6.3 |
| LONE WIZARD HOLDS BACK | - | - | - | - | 0.1 | +0.0 | 0.0 | 0.0 |
| LONE WIZARD KEPT IN | 0.7 | +49.1 | 0.0 | 0.0 | 0.2 | +24.5 | 0.0 | 0.0 |
| LONG SHOT | 0.3 | -0.3 | 4.0 | 4.1 | 0.6 | +3.0 | 20.4 | 8.8 |
| LOST CHARGE | 0.2 | -0.8 | 9.5 | 1.7 | 1.8 | -25.3 | 82.8 | 70.2 |
| LURE BY WHAT IT DRAWS | 0.1 | -8.0 | 0.0 | 0.9 | 0.3 | -48.1 | 0.0 | 16.0 |
| MAKE SURE TOGETHER | 0.3 | +14.1 | 0.0 | 24.9 | 1.0 | +85.1 | 40.2 | 40.0 |
| MANOEUVRE | 0.5 | +10.0 | 0.0 | 12.7 | 0.2 | +4.5 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.1 | +0.6 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| MARCH CHECK | 0.4 | +26.5 | 0.0 | 0.0 | 0.4 | +21.8 | 0.0 | 0.0 |
| MARCH ODDS | - | - | - | - | 0.3 | +9.9 | 9.7 | 0.0 |
| MARCH OVER CASTS | 0.7 | +57.5 | 0.0 | 5.8 | 0.2 | +8.8 | 0.0 | 11.1 |
| MAX FOR POSITIONING | 6.4 | +133.0 | 0.0 | 140.9 | 6.9 | +90.0 | 0.0 | 112.9 |
| MISSILES IN THE MOVE | 4.5 | +187.9 | 0.0 | 105.2 | 3.7 | +43.7 | 0.0 | 64.1 |
| MISSILES NEXT TURN | 5.3 | +113.4 | 0.0 | 109.4 | 4.1 | +36.7 | 0.0 | 71.4 |
| MODEL FACING | 0.4 | +167.0 | 0.0 | 1.7 | - | - | - | - |
| MONSTER WIZARD ROAMS | - | - | - | - | 0.1 | +0.0 | 0.0 | 0.0 |
| MOVE AND CAST | - | - | - | - | 0.4 | +22.9 | 0.0 | 4.4 |
| MOVE SPELL IN RANGE | 0.2 | +5.3 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL NOT WORTH | 0.0 | -0.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.4 | -58.5 | 0.0 | 26.9 | - | - | - | - |
| MOVE SPELL SPOT | 0.4 | +0.0 | 0.0 | 11.1 | 0.1 | +0.0 | 0.0 | 11.1 |
| MOVE TO CHARGE | - | - | - | - | 5.2 | +419.5 | 180.1 | 115.6 |
| MOVES UNITS SPELL | 0.1 | +3.4 | 0.0 | 0.0 | 0.1 | +1.8 | 0.0 | 0.0 |
| NEEDED THERE | 0.1 | +9.9 | 1.4 | 0.0 | - | - | - | - |
| NO RALLY LEFT | 0.1 | +4.6 | 0.0 | 1.8 | - | - | - | - |
| NOT NEEDED | - | - | - | - | 0.3 | -11.1 | 38.6 | 5.5 |
| NOT TURNED | 0.1 | +0.0 | 0.0 | 0.9 | 5.1 | +30.4 | 0.0 | 125.2 |
| NOT WORTH A CAST | 1.1 | -0.8 | 0.0 | 24.9 | 0.4 | -0.3 | 0.0 | 0.0 |
| OFF BEST | 1.2 | -19.5 | 0.0 | 6.8 | 16.7 | -721.8 | 1.8 | 290.3 |
| ONE FIGHT FORMULA | 8.0 | -156.0 | 0.0 | 165.5 | 8.7 | -164.7 | 7.6 | 159.1 |
| ONE OBJECTIVE FORMULA | 2.8 | -4.2 | 0.0 | 51.3 | 2.1 | -95.2 | 0.0 | 25.2 |
| OPENS A LANE | 0.2 | +0.7 | 29.8 | 11.1 | 0.0 | +0.3 | 3.8 | 0.0 |
| OPENS UP | 0.1 | +12.0 | 10.3 | 0.0 | 0.2 | +13.8 | 8.3 | 0.0 |
| OVERRUNS AWAY | 0.3 | +4.3 | 35.8 | 0.0 | 0.4 | +10.8 | 46.8 | 3.5 |
| PATHS CROSS | 2.2 | +181.2 | 0.0 | 30.8 | 2.6 | +172.7 | 0.0 | 32.9 |
| PERIAPT WORTH | 0.1 | +5.7 | 0.0 | 0.0 | 0.1 | +6.8 | 0.0 | 15.0 |
| PIVOT GUARDS FLANK | 0.1 | -1.5 | 0.0 | 1.4 | 0.1 | -4.5 | 0.0 | 12.0 |
| PLAN RESULT | 39.5 | +783.1 | 495.7 | 883.6 | 40.2 | +1012.7 | 1316.0 | 895.6 |
| PURSUES BIG PREY | 0.1 | -1.2 | 0.0 | 0.0 | 0.0 | -1.2 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE NEXT TURN | - | - | - | - | 0.1 | +4.9 | 0.0 | 0.0 |
| RANDOM MOVE BY FIGURES | 0.8 | +5.9 | 0.0 | 17.5 | 1.8 | +24.4 | 0.0 | 65.6 |
| RANDOM MOVER NO PROMISE | - | - | - | - | 0.2 | -8.8 | 4.2 | 13.5 |
| REDIRECT BY WHAT IT STOPS | 0.0 | -0.4 | 0.0 | 0.0 | 1.2 | -29.0 | 0.0 | 28.6 |
| REDIRECT COUNTER | 1.6 | +100.5 | 0.0 | 37.2 | 3.6 | +349.1 | 0.0 | 59.3 |
| REDIRECT WEIGHED | 0.2 | +5.1 | 0.0 | 0.0 | 0.3 | +3.9 | 16.8 | 0.0 |
| REFUSING RETIRES | 0.4 | +0.0 | 0.0 | 6.1 | 0.3 | +0.0 | 0.0 | 18.7 |
| RESERVE FALL BACK | 0.4 | +16.2 | 0.0 | 6.0 | 0.9 | +42.0 | 0.0 | 24.8 |
| RESTRAINS TO SHOOT | - | - | - | - | 0.0 | +2.3 | 0.0 | 0.0 |
| RISK BY ARC | 1.6 | +62.5 | 147.8 | 41.4 | 2.4 | +43.0 | 203.6 | 31.1 |
| RISK ONCE | - | - | - | - | 5.3 | +290.6 | 83.4 | 344.6 |
| RUN DOWN | 1.3 | -14.8 | 95.1 | 32.8 | - | - | - | - |
| SAFE SURE CHARGE | - | - | - | - | 0.1 | -1.2 | 2.6 | 0.0 |
| SAFER THAN THE JOB | - | - | - | - | 0.8 | +32.4 | 0.0 | 10.2 |
| SCOUT SPOT | 0.4 | +0.7 | 0.0 | 1.5 | 0.3 | +0.6 | 0.0 | 0.9 |
| SCOUT WAITS | 0.4 | +0.0 | 0.0 | 1.5 | 0.3 | +0.0 | 0.0 | 0.9 |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 0.1 | +2.0 | 0.0 | 0.0 |
| SEARCH SPOT | 3.9 | +109.0 | 0.0 | 123.6 | 2.7 | +100.3 | 0.0 | 34.4 |
| SELF MOVE SPELL | 0.2 | +18.0 | 0.0 | 18.1 | 0.1 | +0.4 | 0.0 | 9.1 |
| SET UP TOGETHER | 0.4 | +14.2 | 0.0 | 24.9 | 2.0 | +204.8 | 50.7 | 90.9 |
| SET-UP ANY TARGET | 0.1 | +1.9 | 0.0 | 0.0 | 0.1 | +1.6 | 7.6 | 7.6 |
| SHOOTERS IN TWO RANKS | 0.4 | +0.9 | 0.0 | 0.0 | 0.3 | +0.8 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.1 | +31.3 | 70.1 | 18.1 | 1.1 | +23.8 | 36.6 | 0.0 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| SHOT REPLANNED | 0.5 | +0.0 | 108.1 | 1.8 | 0.2 | +0.0 | 31.8 | 0.0 |
| SHOTS IN THE MOVE | 16.4 | +685.0 | 0.0 | 286.5 | 9.8 | +236.9 | 0.0 | 109.5 |
| SPELL OFF EDGE | - | - | - | - | 0.0 | +3.9 | 0.0 | 6.5 |
| SPELL SETS UP CHARGE | 0.1 | +12.6 | 0.0 | 11.1 | 0.1 | +20.9 | 7.6 | 7.6 |
| SPELL WORTH | 1.1 | +13.6 | 88.2 | 81.6 | 1.4 | +32.6 | 98.4 | 111.4 |
| SPELLS IN THE FIGHT | 0.2 | -2.0 | 30.0 | 6.0 | 0.7 | -12.1 | 47.0 | 20.0 |
| STABLE ROLE | - | - | - | - | 11.2 | +0.0 | 349.4 | 129.9 |
| STAND AND SHOOT | 0.2 | -4.6 | 15.1 | 0.0 | - | - | - | - |
| STAY WEIGHED | - | - | - | - | 0.0 | +0.3 | 0.0 | 0.0 |
| STOPS | 0.1 | +4.6 | 0.0 | 1.7 | 0.2 | +3.5 | 13.6 | 0.0 |
| STOPS SHORT OF THE FLANK | - | - | - | - | 0.3 | +10.4 | 0.0 | 0.0 |
| STUCK PIVOT | 0.0 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| SUPPORT NARROWED | 1.0 | +0.0 | 89.5 | 27.7 | 7.8 | -57.4 | 428.1 | 64.2 |
| SUPPORTS | - | - | - | - | 5.3 | +57.4 | 240.6 | 39.5 |
| SURE CHARGE BEATS ADVANCE | - | - | - | - | 0.1 | -4.4 | 17.4 | 0.0 |
| SURE REACH TOGETHER | 0.7 | +9.2 | 0.0 | 25.6 | 0.6 | +7.3 | 7.1 | 16.8 |
| THROUGH LINE OF FIRE | - | - | - | - | 0.3 | +32.5 | 0.0 | 12.8 |
| TIME ON OUR SIDE | 2.3 | +0.0 | 13.1 | 24.4 | - | - | - | - |
| TURN WORTH | 0.1 | -5.1 | 11.2 | 10.6 | 0.2 | -10.4 | 18.1 | 0.0 |
| TWO OR MORE ARRIVE | 0.1 | +0.8 | 0.0 | 12.1 | 0.7 | +4.2 | 3.3 | 21.1 |
| WAIT AFTER COSTS | - | - | - | - | 8.6 | -462.7 | 318.0 | 154.9 |
| WALKS TO THE FIGHT | - | - | - | - | 1.2 | +10.2 | 48.1 | 15.3 |
| WAR ENGINE CHARGES | 0.1 | +13.5 | 9.5 | 0.0 | 0.1 | +0.7 | 2.4 | 0.0 |
| WAR ENGINE JOBS | 0.0 | +0.0 | 4.0 | 4.2 | 0.3 | +0.0 | 8.5 | 1.8 |
| WEARS DOWN | 0.4 | +26.7 | 76.9 | 28.9 | 0.9 | +30.7 | 95.5 | 15.7 |
| WHO HITS BACK | 0.3 | +35.0 | 0.0 | 9.6 | 0.3 | +21.6 | 0.0 | 9.5 |
| WHOLE FIGHT | 0.2 | -2.8 | 23.1 | 0.0 | 0.4 | +11.0 | 29.1 | 1.5 |
| WHOLE FIGHT GAIN | 0.1 | +5.5 | 5.9 | 2.1 | 0.4 | +31.3 | 29.9 | 16.4 |
| WIDER SPREAD | 1.4 | -4.2 | 152.9 | 41.4 | 3.1 | -6.6 | 212.1 | 55.8 |
| WOUNDED STAYS OUT | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |

### Rule changes: fa-h2h-mine-8a94331-p1

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 644 | 644 | 644 | 17.89 | -26684 | -41.4 |
| SEARCH SPOT | 239 | 239 | 233 | 6.47 | +7536 | +32.3 |
| PATHS CROSS | 171 | 171 | 171 | 4.75 | +12740 | +74.5 |
| SHOTS IN THE MOVE | 944 | 705 | 107 | 2.97 | +3503 | +32.7 |
| MOVE TO CHARGE | 187 | 187 | 105 | 2.92 | +5965 | +56.8 |
| IDLE COST | 1283 | 667 | 90 | 2.50 | +808 | +9.0 |
| COVER ONCE | 493 | 258 | 76 | 2.11 | +1584 | +20.8 |
| MAX FOR POSITIONING | 477 | 375 | 75 | 2.08 | +494 | +6.6 |
| SUPPORTS | 190 | 190 | 74 | 2.06 | +779 | +10.5 |
| KILLS COUNT NEXT TURN | 230 | 230 | 65 | 1.81 | +1630 | +25.1 |
| REDIRECT COUNTER | 189 | 123 | 64 | 1.78 | +4683 | +73.2 |
| WAIT AFTER COSTS | 310 | 310 | 60 | 1.67 | +1023 | +17.1 |
| ARTILLERY RE-ROLL WEIGHED | 55 | 55 | 55 | 1.53 | +0 | +0.0 |
| CANNON PLANNED TARGET | 220 | 220 | 54 | 1.50 | -160 | -3.0 |
| FALLBACK BY WORTH | 205 | 205 | 54 | 1.50 | +2386 | +44.2 |
| CANNON SIGHT KEPT | 51 | 51 | 51 | 1.42 | +0 | +0.0 |
| FACES THE THREAT | 48 | 48 | 48 | 1.33 | +2479 | +51.6 |
| FOLLOW UP WEIGHED | 47 | 47 | 47 | 1.31 | +9742 | +207.3 |
| SHOOTS FROM THE BEST SPOT | 78 | 78 | 47 | 1.31 | +306 | +6.5 |
| ADVANCE LANE KEPT | 46 | 46 | 46 | 1.28 | +0 | +0.0 |
| RESERVE FALL BACK | 45 | 45 | 45 | 1.25 | +2098 | +46.6 |
| HOLDS AMBUSHERS | 44 | 44 | 44 | 1.22 | +0 | +0.0 |
| ONE FIGHT FORMULA | 602 | 316 | 44 | 1.22 | +305 | +6.9 |
| RANDOM MOVE BY FIGURES | 92 | 92 | 44 | 1.22 | +1089 | +24.7 |
| CHARGE LOSSES | 431 | 431 | 42 | 1.17 | +2453 | +58.4 |
| MISSILES IN THE MOVE | 294 | 187 | 42 | 1.17 | +1114 | +26.5 |
| SET UP TOGETHER | 85 | 69 | 41 | 1.14 | +2336 | +57.0 |
| CHAFF IN THE MOVE | 62 | 60 | 40 | 1.11 | +1208 | +30.2 |
| RISK ONCE | 192 | 149 | 40 | 1.11 | +1737 | +43.4 |
| BEST FIRST | 37 | 37 | 37 | 1.03 | +2045 | +55.3 |
| LONE WIZARD KEPT IN | 34 | 34 | 34 | 0.94 | +2648 | +77.9 |
| KILLS COUNT | 116 | 115 | 32 | 0.89 | +1287 | +40.2 |
| RISK BY ARC | 142 | 140 | 30 | 0.83 | +920 | +30.7 |
| ADVANCE WORTH | 184 | 184 | 29 | 0.81 | +357 | +12.3 |
| SAFER THAN THE JOB | 28 | 28 | 28 | 0.78 | +1166 | +41.6 |
| SHOT REPLANNED | 28 | 28 | 28 | 0.78 | +0 | +0.0 |
| MARCH CHECK | 28 | 28 | 27 | 0.75 | +1269 | +47.0 |
| CASTER AWAY FROM SCREEN | 26 | 26 | 26 | 0.72 | +0 | +0.0 |
| CHARGE NOW FIRST | 132 | 132 | 26 | 0.72 | -1533 | -59.0 |
| SCOUT WAITS | 26 | 26 | 26 | 0.72 | +0 | +0.0 |
| CAST JOB | 51 | 51 | 25 | 0.69 | +222 | +8.9 |
| SHOOTERS IN TWO RANKS | 24 | 24 | 24 | 0.67 | +58 | +2.4 |
| WALKS TO THE FIGHT | 44 | 44 | 24 | 0.67 | +128 | +5.3 |
| CHARGE NOW WEIGHED | 23 | 23 | 23 | 0.64 | +821 | +35.7 |
| COMBAT PIVOT | 23 | 23 | 23 | 0.64 | +0 | +0.0 |
| CASTING BLOCK | 25 | 25 | 22 | 0.61 | +700 | +31.8 |
| INVITES THE FIGHT | 48 | 48 | 22 | 0.61 | +105 | +4.8 |
| WHO HITS BACK | 22 | 22 | 22 | 0.61 | +1287 | +58.5 |
| CHAFF PASSED | 20 | 20 | 20 | 0.56 | -28 | -1.4 |
| FOUR ROUNDS | 72 | 71 | 20 | 0.56 | +1436 | +71.8 |
| MANOEUVRE | 26 | 26 | 19 | 0.53 | +520 | +27.3 |
| HONEST WORTH | 405 | 404 | 18 | 0.50 | +147 | +8.2 |
| ONE OBJECTIVE FORMULA | 175 | 97 | 18 | 0.50 | +530 | +29.4 |
| REDIRECT WEIGHED | 18 | 18 | 18 | 0.50 | +766 | +42.5 |
| BEST FACING | 16 | 16 | 16 | 0.44 | +117 | +7.3 |
| MODEL FACING | 16 | 16 | 16 | 0.44 | +6013 | +375.8 |
| FEATURE BUFFS | 40 | 40 | 15 | 0.42 | +274 | +18.3 |
| MOVE AND CAST | 15 | 15 | 15 | 0.42 | +824 | +54.9 |
| CASTS FROM BEHIND | 14 | 14 | 14 | 0.39 | +0 | +0.0 |
| MAKE SURE TOGETHER | 47 | 26 | 14 | 0.39 | +620 | +44.3 |
| REFUSING RETIRES | 23 | 23 | 14 | 0.39 | -6 | -0.4 |
| KEEPS ITS TARGET | 79 | 79 | 12 | 0.33 | +223 | +18.5 |
| SURE REACH TOGETHER | 47 | 40 | 12 | 0.33 | +36 | +3.0 |
| WHOLE FIGHT GAIN | 20 | 19 | 12 | 0.33 | +372 | +31.0 |
| BEST OVERALL | 11 | 11 | 11 | 0.31 | +213 | +19.3 |
| MARCH ODDS | 11 | 11 | 11 | 0.31 | +146 | +13.3 |
| MISSILES NEXT TURN | 339 | 197 | 10 | 0.28 | +84 | +8.4 |
| OPENS UP | 14 | 14 | 10 | 0.28 | +198 | +19.8 |
| STOPS SHORT OF THE FLANK | 10 | 10 | 10 | 0.28 | +375 | +37.5 |
| THROUGH LINE OF FIRE | 10 | 10 | 10 | 0.28 | +1168 | +116.8 |
| BLOCKED WHEEL | 9 | 9 | 9 | 0.25 | +146 | +16.2 |
| FIVE ACTION | 1599 | 1598 | 9 | 0.25 | +626 | +69.5 |
| STUCK PIVOT | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| SUPPORT NARROWED | 317 | 317 | 9 | 0.25 | -162 | -18.0 |
| PIVOT GUARDS FLANK | 8 | 8 | 8 | 0.22 | -213 | -26.6 |
| SHORT GUN FORWARD | 8 | 8 | 8 | 0.22 | +0 | +0.0 |
| BEST PREY | 19 | 19 | 7 | 0.19 | +511 | +73.0 |
| BIG CHARACTER SAFETY | 7 | 7 | 7 | 0.19 | -43 | -6.2 |
| FRIENDS SHOTS CHECKED | 7 | 7 | 7 | 0.19 | +407 | +58.1 |
| MOVES UNITS SPELL | 7 | 7 | 7 | 0.19 | +186 | +26.5 |
| OVERRUNS AWAY | 28 | 28 | 7 | 0.19 | +158 | +22.5 |
| WAR ENGINE JOBS | 11 | 11 | 7 | 0.19 | -829 | -118.4 |
| HUNT IN PAIRS | 34 | 22 | 5 | 0.14 | +183 | +36.7 |
| LOST CHARGE | 71 | 71 | 5 | 0.14 | +53 | +10.5 |
| AFTERMATH IN POINTS | 4 | 4 | 4 | 0.11 | +308 | +76.9 |
| GUN MASK | 28 | 28 | 4 | 0.11 | +263 | +65.7 |
| LONG SHOT | 31 | 31 | 4 | 0.11 | +42 | +10.4 |
| PERIAPT WORTH | 4 | 4 | 4 | 0.11 | +448 | +112.0 |
| STOPS | 8 | 8 | 4 | 0.11 | +92 | +23.0 |
| WIDER SPREAD | 163 | 161 | 4 | 0.11 | +26 | +6.4 |
| BEST PRIZE | 3 | 3 | 3 | 0.08 | -64 | -21.5 |
| CATCH ODDS | 3 | 3 | 3 | 0.08 | -31 | -10.5 |
| EDGE GIVE GROUND | 14 | 14 | 3 | 0.08 | +208 | +69.4 |
| ELIXIR WORTH | 3 | 3 | 3 | 0.08 | +144 | +48.1 |
| JOINT CHARGE PLAN | 10 | 10 | 3 | 0.08 | +331 | +110.2 |
| NO RALLY LEFT | 3 | 3 | 3 | 0.08 | +103 | +34.4 |
| PURSUES BIG PREY | 3 | 3 | 3 | 0.08 | -88 | -29.4 |
| SURE CHARGE BEATS ADVANCE | 3 | 3 | 3 | 0.08 | -159 | -53.0 |
| WHOLE FIGHT | 19 | 19 | 3 | 0.08 | +276 | +92.0 |
| BOMBING RUN | 2 | 2 | 2 | 0.06 | +126 | +63.1 |
| HUNT ADVANCE | 6 | 6 | 2 | 0.06 | +35 | +17.6 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| NEEDED THERE | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| SAFE SURE CHARGE | 2 | 2 | 2 | 0.06 | -44 | -21.8 |
| TWO OR MORE ARRIVE | 28 | 21 | 2 | 0.06 | +21 | +10.3 |
| WEARS DOWN | 48 | 47 | 2 | 0.06 | +73 | +36.6 |
| BACKUP TARGETS | 28 | 10 | 1 | 0.03 | -0 | -0.1 |
| CARRIES OUT SET-UP | 4 | 4 | 1 | 0.03 | -6 | -6.2 |
| CHARIOT NO STATIC JOB | 3 | 3 | 1 | 0.03 | -175 | -174.7 |
| CONTINUE AHEAD WEIGHED | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| FOCUS FIRE | 1 | 1 | 1 | 0.03 | +76 | +75.6 |
| KEEP FALLS | 1 | 1 | 1 | 0.03 | +24 | +24.2 |
| RAIDS THE BAGGAGE NEXT TURN | 2 | 2 | 1 | 0.03 | +76 | +76.0 |
| RESTRAINS TO SHOOT | 1 | 1 | 1 | 0.03 | +84 | +84.5 |
| STAY WEIGHED | 1 | 1 | 1 | 0.03 | +13 | +12.6 |
| WOUNDED STAYS OUT | 1 | 1 | 1 | 0.03 | -11 | -10.6 |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| BLOWS WHERE AIMED | 22 | 22 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 20 | 20 | 0 | 0.00 | - | - |
| CARRIES OUT COUNTER | 3 | 3 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 31 | trace | - | - | - | - |
| CHAMPION TAKES THE CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| CHARACTER GUNS | 21 | 21 | 0 | 0.00 | - | - |
| CHARGER SLAIN LOST | 25 | 24 | 0 | 0.00 | - | - |
| CHARIOT WIZARD CAREFUL | 2 | 2 | 0 | 0.00 | - | - |
| CHEAP HELPER | 6 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 27 | not checked | - | - | - | - |
| DEFENSIVE ARMY | 3 | 3 | 0 | 0.00 | - | - |
| DEFENSIVE FLOOR | 2 | 2 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 2 | 2 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 45 | 45 | 0 | 0.00 | - | - |
| FALLS SHORT | 3 | 3 | 0 | 0.00 | - | - |
| FIGHT LIFT | 1 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 353 | not checked | - | - | - | - |
| GIVES UP | 5 | 5 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 2 | 2 | 0 | 0.00 | - | - |
| GROUND FLIERS | 4 | not checked | - | - | - | - |
| HELPER ALREADY ASKED | 2 | not checked | - | - | - | - |
| HELPER UNSEEN | 10 | 10 | 0 | 0.00 | - | - |
| HILL BY ITS CHANCE | 7 | 7 | 0 | 0.00 | - | - |
| HUNT DROPPED | 7 | trace | - | - | - | - |
| HUNT KEPT | 4 | trace | - | - | - | - |
| HUNT RESULT | 12 | trace | - | - | - | - |
| HUNT THE GUNS | 12 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 2 | 2 | 0 | 0.00 | - | - |
| KEEPS ITS PREY | 5 | 5 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 22 | not checked | - | - | - | - |
| LONE WIZARD HOLDS BACK | 4 | 4 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 14 | 14 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 3 | trace | - | - | - | - |
| MARCH OVER CASTS | 31 | 31 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 5 | 5 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 7 | 2 | 0 | 0.00 | - | - |
| MOVE SPELL NOT WORTH | 1 | not checked | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 14 | trace | - | - | - | - |
| MOVE SPELL SPOT | 16 | not checked | - | - | - | - |
| NOT NEEDED | 11 | 11 | 0 | 0.00 | - | - |
| NOT TURNED | 186 | 186 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 52 | not checked | - | - | - | - |
| OPENS A LANE | 8 | 5 | 0 | 0.00 | - | - |
| PLAN RESULT | 2871 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 8 | 8 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 43 | 43 | 0 | 0.00 | - | - |
| RUN DOWN | 47 | 46 | 0 | 0.00 | - | - |
| SCOUT SPOT | 23 | 23 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 4 | 4 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 12 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 4 | not checked | - | - | - | - |
| SPELL OFF EDGE | 1 | not checked | - | - | - | - |
| SPELL SETS UP CHARGE | 6 | not checked | - | - | - | - |
| SPELL WORTH | 91 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 30 | 30 | 0 | 0.00 | - | - |
| STABLE ROLE | 404 | 404 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 7 | 7 | 0 | 0.00 | - | - |
| TIME ON OUR SIDE | 84 | 84 | 0 | 0.00 | - | - |
| TURN WORTH | 10 | 10 | 0 | 0.00 | - | - |
| WAR ENGINE CHARGES | 4 | 4 | 0 | 0.00 | - | - |

### Off best figure: fa-h2h-mine-8a94331-p1

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 1.00 | 14.92 | 43.2 |
| FALLBACK | gate | 0.03 | 0.97 | 25.7 |
| CHARGE NOW FIRST | rule | 0.28 | 0.42 | 61.3 |
| TURN GATE | gate | - | 0.56 | 36.3 |
| CHAFF PASSED | rule | 0.17 | 0.17 | 2.2 |
| SUPPORT NARROWED | rule | 0.06 | 0.19 | 18.0 |
| CANNON PLANNED TARGET | rule | 0.19 | 0.03 | 37.1 |
| PATHS CROSS | rule | 0.14 | 0.08 | 20.9 |
| PIVOT GUARDS FLANK | rule | 0.08 | 0.14 | 26.6 |
| WAR ENGINE JOBS | rule | - | 0.19 | 118.4 |
| BIG CHARACTER SAFETY | rule | - | 0.14 | 9.9 |
| AFTERMATH BAND | gate | 0.06 | 0.06 | 2.5 |
| FIGHT ORDER BAND | gate | 0.03 | 0.08 | 1.6 |
| CATCH ODDS | rule | - | 0.08 | 10.5 |
| NO REASON | gate | 0.08 | - | 74.8 |
| PURSUES BIG PREY | rule | 0.06 | 0.03 | 29.4 |
| REFUSING RETIRES | rule | 0.06 | 0.03 | 0.8 |
| SURE CHARGE BEATS ADVANCE | rule | - | 0.08 | 53.0 |
| BEST PRIZE | rule | - | 0.06 | 32.2 |
| CHARGE NOW WEIGHED | rule | - | 0.06 | 35.0 |
| LONE CHARACTER SAFE SPOT | gate | - | 0.06 | 9.4 |
| SAFE SURE CHARGE | rule | - | 0.06 | 21.8 |
| SAFER THAN THE JOB | rule | - | 0.06 | 17.4 |
| STOPS SHORT OF THE FLANK | rule | - | 0.06 | 2.4 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.03 | - | 11.3 |
| CARRIES OUT SET-UP | rule | 0.03 | - | 6.2 |
| CHARIOT NO STATIC JOB | rule | - | 0.03 | 174.7 |
| FACES THE THREAT | rule | - | 0.03 | 10.2 |
| MOVE AND CAST | rule | - | 0.03 | 2.4 |
| REDIRECT WEIGHED | rule | - | 0.03 | 4.4 |
| SUPPORT REQUEST | gate | - | 0.03 | 21.7 |
| THROUGH LINE OF FIRE | rule | - | 0.03 | 35.2 |
| WOUNDED STAYS OUT | rule | 0.03 | - | 10.6 |

### Plans: fa-h2h-mine-8a94331-p1

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.6 | 64% | 261 | 130 | 50% |
| Mine | join | 0.5 | 100% | 19 | 0 | 0% |
| Mine | move | 28.9 | 93% | 1906 | 0 | 0% |
| Mine | shoot | 8.5 | 60% | 517 | 653 | 126% |
| Mine | support | 0.1 | 50% | 0 | 0 | - |
| Opponent | advance | 11.8 | 11% | 106 | 224 | 211% |
| Opponent | charge | 3.7 | 59% | 302 | 295 | 98% |
| Opponent | close in | 7.0 | 23% | 499 | 201 | 40% |
| Opponent | hold | 4.6 | 45% | 315 | 0 | 0% |
| Opponent | join | 1.2 | 100% | 56 | 0 | 0% |
| Opponent | shoot | 5.4 | 63% | 135 | 296 | 220% |
| Opponent | support | 6.5 | 93% | 52 | 0 | 0% |

### Packages: hunt the guns, fa-h2h-mine-8a94331-p1

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.1 | 2 | 0 | 0% | 0% | 0% | - | 395 | 0 | 0% | 12 |
| Opponent | 0.3 | 10 | 0 | 40% | 50% | 0% | 2.8 | 252 | 82 | 30% | 115 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Dwarfen Mountain Holds | 0.4 | 2 | 0 | 0% | 0% | 0% | - | 395 | 0 | 0% | 86 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 65 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 150 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 268 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Orc & Goblin Tribes | 0.3 | 1 | 0 | 0% | 0% | 0% | - | 76 | 0 | 0% | 103 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 86 |
| Tomb Kings of Khemri | 0.7 | 4 | 0 | 25% | 50% | 0% | 2.0 | 216 | 85 | 50% | 44 |
| Vampire Counts | 0.2 | 2 | 0 | 100% | 100% | 0% | 3.5 | 270 | 157 | 50% | 59 |
| Warriors of Chaos | 0.2 | 2 | 0 | 50% | 50% | 0% | 3.0 | 356 | 82 | 0% | 101 |
| Wood Elf Realms | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 329 | 0 | 0% | 21 |

### Battle groups: fa-h2h-mine-8a94331-p1

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 1.6 | 25% | 60% | 0% | - | 7% | 0% | 7% | 87% | 0% |
| Opponent | REDIRECT COUNTER | 3.6 | 15% | 75% | 15% | 33% | 29% | 0% | 0% | 59% | 12% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: fa-h2h-mine-8a94331-p1

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 3 | 0 (3) | 0 | 0 | 0 | 33% | 6.0 | 0 (1) | 0 (1) | 0 (1) | - | 0 (3) |
| Mine | Chaff | 37 | 7 (37) | 6 | 1 | 55 | 38% | 2.5 | 0 (16) | 21 (9) | 7 (12) | 12 (24) | 0 (13) |
| Mine | Character | 123 | 45 (123) | 44 | 1 | 26 | 21% | 2.4 | 68 (36) | 36 (57) | 15 (12) | 44 (57) | 47 (48) |
| Mine | Clean-up | 24 | 54 (24) | 13 | 41 | 22 | 46% | 3.6 | 65 (9) | 49 (11) | 24 (4) | 81 (14) | 23 (10) |
| Mine | Fast | 4 | 0 (4) | 0 | 0 | 34 | 0% | 1.2 | 0 (1) | 0 (2) | 0 (1) | 0 (4) | - |
| Mine | Fast Hammer | 41 | 40 (41) | 31 | 9 | 46 | 34% | 2.9 | 32 (18) | 21 (12) | 72 (11) | 28 (28) | 63 (13) |
| Mine | Fragile | 5 | 0 (5) | 0 | 0 | 60 | 0% | 1.4 | - | 0 (4) | 0 (1) | 0 (1) | 0 (4) |
| Mine | Hammer | 58 | 37 (58) | 26 | 11 | 36 | 17% | 2.4 | 26 (10) | 42 (38) | 30 (10) | 58 (34) | 14 (24) |
| Mine | Holder | 25 | 122 (25) | 23 | 99 | 24 | 60% | 3.3 | 183 (8) | 107 (11) | 85 (4) | 178 (11) | 90 (12) |
| Mine | Shooter | 44 | 68 (44) | 21 | 47 | 43 | 5% | 1.6 | 39 (5) | 76 (31) | 76 (7) | 108 (23) | 30 (20) |
| Mine | Support | 5 | 0 (5) | 0 | 0 | 58 | 0% | 2.6 | - | 0 (2) | - | 0 (2) | - |
| Mine | War machine | 56 | 63 (56) | 63 | 0 | 45 | 7% | 1.4 | 116 (13) | 55 (37) | 0 (6) | 56 (11) | 65 (45) |
| Mine | Wizard | 23 | 17 (23) | 17 | 0 | 46 | 13% | 1.9 | 17 (6) | 37 (8) | 0 (3) | 28 (3) | 20 (14) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 0% | 5.0 | - | - | 0 (1) | 0 (1) | - |
| Opponent | Chaff | 66 | 59 (66) | 12 | 47 | 32 | 41% | 3.0 | 81 (28) | 72 (16) | 20 (22) | 76 (48) | 12 (18) |
| Opponent | Character | 114 | 40 (114) | 40 | 0 | 37 | 32% | 2.8 | 43 (40) | 47 (54) | 0 (6) | 43 (65) | 46 (35) |
| Opponent | Clean-up | 16 | 18 (16) | 18 | 0 | 25 | 50% | 3.2 | 16 (5) | 19 (8) | 19 (3) | 23 (8) | 14 (8) |
| Opponent | Early | 1 | 0 (1) | 0 | 0 | 100 | 0% | 5.0 | - | 0 (1) | - | 0 (1) | - |
| Opponent | Fast Hammer | 58 | 65 (58) | 40 | 25 | 34 | 41% | 2.6 | 58 (25) | 62 (19) | 86 (14) | 68 (42) | 58 (16) |
| Opponent | Fragile | 10 | 0 (10) | 0 | 0 | 35 | 70% | 1.3 | 0 (3) | 0 (3) | 0 (4) | 0 (9) | 0 (1) |
| Opponent | Hammer | 65 | 28 (65) | 21 | 6 | 43 | 26% | 2.7 | 8 (16) | 32 (42) | 42 (7) | 30 (40) | 23 (25) |
| Opponent | Holder | 40 | 66 (40) | 7 | 58 | 31 | 50% | 3.6 | 52 (10) | 90 (21) | 10 (9) | 133 (17) | 21 (23) |
| Opponent | Shooter | 30 | 59 (30) | 20 | 39 | 35 | 3% | 1.6 | 32 (7) | 77 (18) | 20 (5) | 43 (16) | 81 (14) |
| Opponent | Support | 2 | 0 (2) | 0 | 0 | 0 | 100% | - | 0 (1) | 0 (1) | - | - | 0 (2) |
| Opponent | War machine | 13 | 29 (13) | 29 | 0 | 48 | 0% | 1.2 | 12 (5) | 50 (5) | 20 (3) | 77 (3) | 15 (10) |
| Opponent | Wizard | 22 | 1 (22) | 1 | 0 | 36 | 18% | 2.2 | 0 (10) | 9 (4) | 0 (3) | 2 (8) | 0 (9) |

### Charged fights: fa-h2h-mine-8a94331-p1

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 5 | 249 | 68 | 1.0 | 1.0 | 68 | 6 | +62 | 0 of 5 | 3 of 5 | - | +62 |
| Mine | Chaos Dwarfs | 3 | 22 | 1117 | 3.0 | 1.1 | 372 | 12 | +360 | 5 of 9 | 7 of 9 | +238 | +375 |
| Mine | Dwarfen Mountain Holds | 4 | 503 | 0 | 0.2 | 1.0 | 0 | 0 | +0 | 0 of 1 | 0 of 1 | - | +0 |
| Mine | Empire of Man | 5 | 279 | 55 | 1.0 | 1.0 | 55 | 76 | -21 | 1 of 5 | 2 of 5 | - | -21 |
| Mine | Grand Cathay | 4 | 667 | 229 | 2.0 | 1.2 | 114 | 48 | +67 | 5 of 8 | 7 of 8 | +298 | -10 |
| Mine | High Elf Realms | 4 | 128 | 411 | 1.8 | 1.0 | 235 | 63 | +172 | 4 of 7 | 6 of 7 | - | +172 |
| Mine | Kingdom of Bretonnia | 1 | 0 | 75 | 2.0 | 1.0 | 38 | 0 | +38 | 1 of 2 | 1 of 2 | - | +38 |
| Mine | Lizardmen | 1 | 0 | 501 | 3.0 | 1.0 | 167 | 47 | +120 | 2 of 3 | 1 of 3 | - | +120 |
| Mine | Ogre Kingdoms | 1 | 610 | 0 | 1.0 | 2.0 | 0 | 0 | +0 | 0 of 1 | 0 of 1 | +0 | - |
| Mine | Orc & Goblin Tribes | 1 | 0 | 586 | 4.0 | 1.0 | 146 | 29 | +118 | 2 of 4 | 3 of 4 | - | +118 |
| Mine | Skaven | 2 | 25 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 0 of 2 | 1 of 2 | - | +0 |
| Mine | Tomb Kings of Khemri | 2 | 58 | 454 | 3.5 | 1.0 | 130 | 0 | +130 | 0 of 7 | 6 of 7 | - | +130 |
| Mine | Vampire Counts | 2 | 0 | 35 | 1.5 | 1.3 | 23 | 0 | +23 | 0 of 3 | 2 of 3 | +0 | +35 |
| Mine | Warriors of Chaos | 1 | 27 | 340 | 3.0 | 1.3 | 113 | 10 | +103 | 0 of 3 | 2 of 3 | +283 | +14 |
| **Mine** | all armies | 36 | 242 | 250 | 1.7 | 1.1 | 150 | 27 | +123 | 20 of 60 | 41 of 60 | +186 | +116 |
| Opponent | Beastmen Brayherds | 1 | 55 | 887 | 2.0 | 1.5 | 444 | 85 | +358 | 1 of 2 | 2 of 2 | +652 | +65 |
| Opponent | Dwarfen Mountain Holds | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Empire of Man | 1 | 255 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Grand Cathay | 1 | 280 | 185 | 1.0 | 1.0 | 185 | 0 | +185 | 1 of 1 | 0 of 1 | - | +185 |
| Opponent | High Elf Realms | 2 | 62 | 724 | 3.5 | 1.3 | 207 | 0 | +207 | 1 of 7 | 5 of 7 | +232 | +197 |
| Opponent | Lizardmen | 1 | 299 | 0 | 2.0 | 1.0 | 0 | 0 | +0 | 1 of 2 | 2 of 2 | - | +0 |
| Opponent | Ogre Kingdoms | 2 | 26 | 293 | 4.0 | 1.0 | 73 | 53 | +20 | 3 of 8 | 4 of 8 | - | +20 |
| Opponent | Orc & Goblin Tribes | 2 | 155 | 276 | 3.5 | 1.0 | 79 | 16 | +63 | 4 of 7 | 4 of 7 | - | +63 |
| Opponent | Skaven | 2 | 0 | 0 | 1.0 | 1.5 | 0 | 144 | -144 | 2 of 2 | 0 of 2 | -177 | -112 |
| Opponent | Tomb Kings of Khemri | 4 | 73 | 1085 | 4.2 | 1.2 | 255 | 0 | +255 | 9 of 17 | 16 of 17 | +455 | +212 |
| Opponent | Vampire Counts | 6 | 153 | 468 | 4.8 | 1.2 | 97 | 57 | +40 | 12 of 29 | 17 of 29 | +16 | +45 |
| Opponent | Warriors of Chaos | 7 | 0 | 269 | 1.3 | 1.0 | 210 | 13 | +196 | 6 of 9 | 6 of 9 | - | +196 |
| Opponent | Wood Elf Realms | 6 | 134 | 220 | 3.7 | 1.1 | 60 | 10 | +50 | 5 of 22 | 16 of 22 | +35 | +51 |
| **Opponent** | all armies | 36 | 94 | 389 | 2.9 | 1.2 | 132 | 28 | +104 | 45 of 106 | 72 of 106 | +175 | +93 |

### Effective charges: fa-h2h-mine-8a94331-p1

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 5 | 1 (net +4) | 0 | 1 (net +125) | 0 | 0 | 2 (net +38) | 1 | 25% (1 of 4) |
| Mine | Chaos Dwarfs | 9 | 1 (net +912) | 0 | 4 (net +535) | 1 (net +145) | 0 | 3 (net +14) | 0 | 44% (4 of 9) |
| Mine | Dwarfen Mountain Holds | 1 | 1 (net +0) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 1) |
| Mine | Empire of Man | 5 | 1 (net -190) | 0 | 0 | 2 (net +42) | 0 | 2 (net +0) | 0 | 0% (0 of 5) |
| Mine | Grand Cathay | 8 | 0 | 0 | 3 (net +198) | 1 (net +0) | 0 | 4 (net -16) | 0 | 38% (3 of 8) |
| Mine | High Elf Realms | 7 | 1 (net -116) | 0 | 0 | 0 | 1 (net +50) | 4 (net +298) | 1 | 0% (0 of 6) |
| Mine | Kingdom of Bretonnia | 2 | 1 (net +0) | 0 | 0 | 1 (net +75) | 0 | 0 | 0 | 0% (0 of 2) |
| Mine | Lizardmen | 3 | 1 (net +0) | 0 | 0 | 1 (net +501) | 0 | 0 | 1 | 0% (0 of 2) |
| Mine | Orc & Goblin Tribes | 4 | 0 | 0 | 2 (net +260) | 0 | 1 (net +66) | 0 | 1 | 67% (2 of 3) |
| Mine | Skaven | 2 | 0 | 0 | 0 | 0 | 0 | 2 (net +0) | 0 | 0% (0 of 2) |
| Mine | Tomb Kings of Khemri | 7 | 0 | 0 | 1 (net +116) | 0 | 2 (net +132) | 4 (net +132) | 0 | 14% (1 of 7) |
| Mine | Vampire Counts | 3 | 0 | 0 | 1 (net +0) | 0 | 1 (net +70) | 0 | 1 | 50% (1 of 2) |
| Mine | Warriors of Chaos | 3 | 0 | 0 | 1 (net +27) | 1 (net +283) | 1 (net +0) | 0 | 0 | 33% (1 of 3) |
| Opponent | Beastmen Brayherds | 2 | 0 | 0 | 1 (net +65) | 0 | 0 | 1 (net +652) | 0 | 50% (1 of 2) |
| Opponent | Grand Cathay | 1 | 1 (net +185) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 1) |
| Opponent | High Elf Realms | 7 | 2 (net +233) | 0 | 0 | 3 (net +187) | 0 | 2 (net +210) | 0 | 0% (0 of 7) |
| Opponent | Lizardmen | 2 | 0 | 0 | 0 | 2 (net +0) | 0 | 0 | 0 | 0% (0 of 2) |
| Opponent | Ogre Kingdoms | 8 | 1 (net +355) | 0 | 1 (net -34) | 3 (net +55) | 0 | 1 (net +65) | 2 | 17% (1 of 6) |
| Opponent | Orc & Goblin Tribes | 7 | 1 (net +219) | 0 | 1 (net -55) | 1 (net +85) | 0 | 0 | 4 | 33% (1 of 3) |
| Opponent | Skaven | 2 | 2 (net -144) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 2) |
| Opponent | Tomb Kings of Khemri | 17 | 1 (net +0) | 1 (net +265) | 4 (net +516) | 4 (net +128) | 2 (net +244) | 4 (net +252) | 1 | 25% (4 of 16) |
| Opponent | Vampire Counts | 29 | 8 (net +39) | 2 (net -160) | 5 (net +175) | 6 (net -9) | 2 (net +96) | 6 (net +24) | 0 | 17% (5 of 29) |
| Opponent | Warriors of Chaos | 9 | 0 | 1 (net +449) | 2 (net +354) | 0 | 1 (net +250) | 1 (net +0) | 4 | 40% (2 of 5) |
| Opponent | Wood Elf Realms | 22 | 2 (net -15) | 0 | 2 (net +240) | 8 (net +42) | 2 (net +75) | 5 (net +43) | 3 | 11% (2 of 19) |

### Charged fights, damage counted: fa-h2h-mine-8a94331-p1

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 7 | 273 | 261 | +87 | 213 | 122 | +91 | +33.5 |
| Mine | Effective (55-75%) | 13 | 344 | 232 | +271 | 285 | 67 | +218 | +63.3 |
| Mine | 76-89% | 7 | 283 | 148 | +155 | 183 | 14 | +169 | +59.8 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 21 | 212 | 162 | +85 | 120 | 27 | +93 | +43.7 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 6 | 431 | 93 | +75 | 87 | 9 | +78 | +18.1 |
| Mine | No odds | 6 | 264 | 134 | -13 | 34 | 63 | -29 | -10.8 |
| Mine | All fights | 60 | 283 | 178 | +123 | 162 | 47 | +115 | +40.6 |
| Opponent | Long shot (under 50%) | 18 | 202 | 247 | +68 | 124 | 54 | +71 | +35.1 |
| Opponent | 50-54% | 4 | 359 | 184 | +98 | 244 | 145 | +98 | +27.5 |
| Opponent | Effective (55-75%) | 16 | 193 | 219 | +256 | 278 | 38 | +240 | +124.5 |
| Opponent | 76-89% | 27 | 251 | 139 | +60 | 95 | 34 | +60 | +23.9 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 20 | 295 | 197 | +125 | 172 | 57 | +115 | +39.0 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 7 | 484 | 113 | +154 | 171 | 23 | +148 | +30.6 |
| Opponent | No odds | 14 | 168 | 193 | +7 | 82 | 73 | +10 | +5.7 |
| Opponent | All fights | 106 | 251 | 188 | +104 | 151 | 51 | +100 | +39.9 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| fa-h2h-mine-8a94331-p1 | move | 387 | 69 (18%) | 46 (12%) | 46 (12%) | 272 (70%) |
| fa-h2h-mine-8a94331-p1 | objective | 253 | 33 (13%) | 21 (8%) | 34 (13%) | 186 (74%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0102, L0118, L0135, L2531, L2730 |
| Charmed Shield | Opponent | L0524, L1224, L1527, L1625, L2025, L2127, L2934 |
| Clockwork Compass | Mine | L1224 |
| Clockwork Compass | Opponent | L0612 |
| Elixir of Power | Mine | L1114, L1131, L1923 |
| Elixir of Power | Opponent | L0319, L1319 |
| Fistful of Laurels | Mine | L1823 |
| Fistful of Laurels | Opponent | L0118, L0218 |
| Horn of the Wild Hunt | Opponent | L0733 |
| Invocation of Nehek | Mine | L2531, L2730 |
| Invocation of Nehek | Opponent | L0524, L1224, L1527, L1625, L2025, L2127 |
| Opal Amulet | Mine | L1431 |
| Opal Amulet | Opponent | L1114 |
| Periapt of Soul Exchange | Mine | L2025, L2127 |
| Periapt of Soul Exchange | Opponent | L0421, L1021 |
| Ring of Doom | Mine | L0218, L0235, L1114, L1131, L1224, L1527 |
| Ring of Doom | Opponent | L0102, L0612, L0733, L1131, L1431, L2231, L2531 |
| Ring of Jet | Mine | L1021, L1114, L1131, L1224 |
| Ring of Jet | Opponent | L0612 |
| Standard of the Fell Warrior | Mine | L1319, L1335 |
| Standard of the Fell Warrior | Opponent | L0913 |
| Storm Daemon (Renegade 2.0) | Mine | L2127 |
| Storm Daemon (Renegade 2.0) | Opponent | L0421, L1021 |
| Twice-Blessed Armour | Mine | L0717, L0733, L1021 |
| Witch Hunter's Ward | Mine | L0717, L0733, L0823 |
| Witch Hunter's Ward | Opponent | L0508 |

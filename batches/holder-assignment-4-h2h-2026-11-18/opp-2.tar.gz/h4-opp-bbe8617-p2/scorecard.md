# Doctrine scorecard: h4-opp-bbe8617-p2

### Scorecard: h4-opp-bbe8617-p2

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0108 | 6 | 1 | Mine | yes | 6 | 3 | 1 | 1 | 0 | 0 | 0 | 0 |
| L0108 | 6 | 1 | Opponent | no | 0 | 3 | 1 | 2 | 0 | 0 | 0 | 0 |
| L0123 | 3 | 1 | Mine | yes | 6 | - | 0 | 1 | 0 | 0 | 0 | 0 |
| L0123 | 3 | 1 | Opponent | yes | 8 | 2 | 6 | 2 | 0 | 0 | 0 | 185 |
| L0207 | 3 | 1 | Mine | no | 6 | - | 0 | 4 | 0 | 0 | 0 | 170 |
| L0207 | 3 | 1 | Opponent | no | 3 | 3 | 0 | 2 | 0 | 0 | 0 | 45 |
| L0224 | 2 | 1 | Mine | - | - | 1 | 3 | 4 | 0 | 0 | 0 | 251 |
| L0224 | 2 | 1 | Opponent | - | - | - | 0 | 4 | 0 | 0 | 0 | 0 |
| L0308 | 2 | 1 | Mine | - | - | 4 | 2 | 3 | 0 | 0 | 0 | 370 |
| L0308 | 2 | 1 | Opponent | - | - | - | 0 | 1 | 0 | 0 | 0 | 350 |
| L0325 | 1 | 1 | Mine | no | 0 | 2 | 0 | 0 | 0 | 0 | 0 | 590 |
| L0325 | 1 | 1 | Opponent | no | 4 | 2 | 2 | 3 | 0 | 0 | 0 | 0 |
| L0411 | 3 | 1 | Mine | no | 0 | 2 | 2 | 2 | 0 | 0 | 0 | 0 |
| L0411 | 3 | 1 | Opponent | no | 2 | - | 0 | 1 | 1 | 0 | 0 | 330 |
| L0427 | 1 | 1 | Mine | no | 0 | 3 | 2 | 0 | 0 | 0 | 0 | 0 |
| L0427 | 1 | 1 | Opponent | no | 0 | 1 | 2 | 3 | 1 | 0 | 0 | 0 |
| L0513 | 3 | 1 | Mine | no | 7 | - | 0 | 2 | 0 | 0 | 0 | 233 |
| L0513 | 3 | 1 | Opponent | yes | 9 | 2 | 1 | 0 | 2 | 0 | 0 | 177 |
| L0530 | 2 | 1 | Mine | - | - | - | 1 | 1 | 0 | 0 | 0 | 0 |
| L0530 | 2 | 1 | Opponent | - | - | 2 | 1 | 4 | 0 | 0 | 0 | 0 |
| L0618 | 6 | 1 | Mine | no | 0 | - | 0 | 3 | 0 | 0 | 0 | 120 |
| L0618 | 6 | 1 | Opponent | no | 1 | - | 0 | 3 | 0 | 0 | 0 | 0 |
| L0633 | 3 | 1 | Mine | no | 8 | - | 3 | 1 | 1 | 0 | 0 | 100 |
| L0633 | 3 | 1 | Opponent | no | 3 | 3 | 0 | 5 | 0 | 0 | 0 | 144 |
| **Average** | | | Mine | 22% | 3.7 | 2.5 | 1.2 | 1.8 | 0.1 | 0.0 | 0.0 | 152.8 |
| **Average** | | | Opponent | 22% | 3.3 | 2.2 | 1.1 | 2.5 | 0.3 | 0.0 | 0.0 | 102.6 |

### KPIs: h4-opp-bbe8617-p2

Rules off - Mine only: HOLDER ASSIGNMENT, QUARTER ODDS.

Morten 2026-11-10; 12 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 42% (20 of 48) | 14% (8 of 59) | 26% (28 of 107) |
| Winner chose to follow up after the loser gave ground |  | 75% (6 of 8); on the table 75% | 82% (9 of 11); on the table 82% | 79% (15 of 19); on the table 79% |
| Winner chose to pursue after the loser fell back in good order |  | 100% (2 of 2); on the table 100% | - | 100% (2 of 2); on the table 100% |
| Winner chose to pursue after the loser fled |  | 0% (0 of 1); on the table 0% | 100% (8 of 8); on the table 100% | 89% (8 of 9); on the table 89% |
| Winner chose to follow up or pursue (all three) |  | 73% (8 of 11); on the table 73% | 89% (17 of 19); on the table 89% | 83% (25 of 30); on the table 83% |
| Magic missiles tried each own turn | 50%+ | 28% (39 of 138) | 46% (22 of 48) | 33% (61 of 186) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 31% (39 of 125) | 56% (22 of 39) | 37% (61 of 164) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 33% (3 of 9) | - | 33% (3 of 9) |
| Points that never fought | lower | 66% (15659 of 23594) | 63% (15112 of 23995) | 65% (30771 of 47589) |
|   infantry points that never fought | lower | 75% (5475 of 7332) | 80% (3449 of 4287) | 77% (8924 of 11619) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 65% (57 of 88) | 65% (60 of 93) | 65% (117 of 181) |
| Bound items with a magic missile used (at least once a game) |  | 100% (6 of 6); 1.0 uses a game | 83% (5 of 6); 1.2 uses a game | 92% (11 of 12); 1.1 uses a game |
| Bound items with another spell used |  | 100% (2 of 2); 0.8 uses a game | 33% (1 of 3); 0.1 uses a game | 60% (3 of 5); 0.4 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 62% (5 of 8); 0.4 uses a game | 17% (1 of 6); 0.1 uses a game | 43% (6 of 14); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 60% (10718 of 17752) | 63% (13101 of 20774) | 62% (23819 of 38526) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 4.2 (51%) | 0.9 (42%) | 5.1 (49%) |
| MARCHED: its unit marched | 2.7 (32%) | 0.4 (19%) | 3.1 (30%) |
| CHARGED: its unit charged | 0.2 (2%) | 0.1 (4%) | 0.2 (2%) |
| IN COMBAT: engaged in combat | 0.7 (8%) | 0.4 (19%) | 1.1 (10%) |
| GONE: slain | 0.4 (5%) | 0.3 (15%) | 0.8 (7%) |
| STUPIDITY: Stupidity | 0.2 (2%) | 0.0 (0%) | 0.2 (2%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 3.9 | 1.0 | 2.6 | 5.1 | 0.5 | 1.0 |
| not cast | 3.6 | 1.8 | 4.9 | 10.4 | 1.5 | 21.0 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.2 (6%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.3 (73%) | 0.5 (10%) | 5.1 (49%) | 0.4 (28%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 3.1 (30%) | 0.1 (6%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (2%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.3 (9%) | 0.3 (18%) | 0.3 (7%) | 1.1 (10%) | 0.2 (17%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (0%) |
| GONE: slain | 0.3 (9%) | 0.0 (0%) | 0.6 (12%) | 0.8 (7%) | 0.0 (0%) | 0.8 (4%) |
| OFF THE TABLE: off the table or not arrived | 0.7 (19%) | 0.0 (0%) | 0.3 (7%) | 0.0 (0%) | 0.3 (22%) | 0.0 (0%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.0 (0%) | 0.1 (2%) | 0.2 (2%) | 0.0 (0%) | 0.3 (2%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.1 (5%) | 0.0 (0%) | 0.0 (0%) | 0.4 (28%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.2 (63%) | 0.1 (5%) | 3.1 (63%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 18.5 (88%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 2.6 a game | 0.8 a game | 1.7 a game |
| stood (cast and not dispelled) | 55% (17 of 31) | 89% (8 of 9) | 62% (25 of 40) |
| the unit moved after it | 65% (11 of 17) | 62% (5 of 8) | 64% (16 of 25) |
| it charged on its next turn | 0% (0 of 17) | 0% (0 of 8) | 0% (0 of 25) |
| the enemy charged it first | 29% (5 of 17) | 0% (0 of 8) | 20% (5 of 25) |
| it fought by the end of its next turn | 18% (3 of 17) | 0% (0 of 8) | 12% (3 of 25) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 17) | 0% (0 of 8) | 0% (0 of 25) |
| none of these (no charge, no fight, no charge escaped) | 71% (12 of 17) | 100% (8 of 8) | 80% (20 of 25) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 54% (191 of 355) | 56% (144 of 257) | 55% (335 of 612) |
|   cavalry | 41% (12 of 29) | 63% (26 of 41) | 54% (38 of 70) |
|   character | 61% (17 of 28) | 38% (11 of 29) | 49% (28 of 57) |
|   chariot | 43% (20 of 46) | 52% (14 of 27) | 47% (34 of 73) |
|   infantry | 37% (31 of 83) | 63% (46 of 73) | 49% (77 of 156) |
|   monster | 70% (7 of 10) | 88% (7 of 8) | 78% (14 of 18) |
|   war machine | 65% (104 of 159) | 51% (40 of 79) | 61% (144 of 238) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 4.5 (33%) | 2.6 (27%) | 7.1 (31%) |
| CHARGED: it charged | 0.8 (6%) | 0.8 (8%) | 1.6 (7%) |
| FLEEING: it fled or was fleeing | 0.1 (1%) | 0.0 (0%) | 0.1 (0%) |
| IN COMBAT: it fought this turn or the last | 0.2 (2%) | 0.2 (2%) | 0.4 (2%) |
| MOVED: a war machine that moved | 1.0 (7%) | 1.3 (14%) | 2.3 (10%) |
| NO TARGET IN RANGE | 3.8 (28%) | 1.2 (13%) | 5.1 (22%) |
| ONLY IN COMBAT: the only targets were in combat | 0.2 (1%) | 0.2 (3%) | 0.4 (2%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.8 (13%) | 1.8 (19%) | 3.6 (16%) |
| SHELTERED: the target was sheltered | 0.8 (5%) | 0.6 (6%) | 1.3 (6%) |
| OTHER BAR | 0.4 (3%) | 0.8 (8%) | 1.2 (5%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 4.4 | 2.0 | 64% | 7.4 pts | 33 pts |
| character | 2.4 | 1.2 | 62% | 12.1 pts | 29 pts |
| chariot | 2.8 | 1.5 | 71% | 13.4 pts | 38 pts |
| infantry | 11.1 | 5.5 | 68% | 8.8 pts | 98 pts |
| monster | 1.2 | 0.6 | 64% | 7.3 pts | 9 pts |
| war machine | 12.0 | 12.1 | 59% | 20.9 pts | 251 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 1.9 | 2.6 | 2.2 |
| Charges that made contact a game | 1.6 | 1.7 | 1.6 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.33 declared, 0.33 contact (6 units) | 0.00 declared, 0.00 contact (5 units) | 0.18 declared, 0.18 contact (11 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 0.75 declared, 0.75 contact (4 units) | 0.75 declared, 0.75 contact (4 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.25 declared, 0.20 contact (83 units) | 0.32 declared, 0.19 contact (88 units) | 0.29 declared, 0.20 contact (171 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 40% (6 of 15) | 67% (4 of 6) | 100% (2 of 2) | 52% (12 of 23) |
| Character in a unit | 91% (21 of 23) | 86% (12 of 14) | 0% (0 of 1) | 87% (33 of 38) |
| Character on its own | 88% (7 of 8) | 62% (5 of 8) | 55% (6 of 11) | 67% (18 of 27) |
| Chariot | 67% (2 of 3) | 80% (8 of 10) | - | 77% (10 of 13) |
| Infantry | 39% (7 of 18) | 35% (7 of 20) | 50% (1 of 2) | 38% (15 of 40) |
| Monster | 50% (3 of 6) | 100% (2 of 2) | - | 62% (5 of 8) |
| Monstrous | 100% (1 of 1) | 50% (1 of 2) | - | 67% (2 of 3) |
| War Machines | 78% (21 of 27) | 50% (1 of 2) | - | 76% (22 of 29) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 100% (1 of 1); on the table 100% | 24% (24 of 102) | 54% | 59% (13 of 22) | 100% (6 of 6); 3.0 uses a game | 100% (2 of 2); 2.2 uses a game | 83% (5 of 6); 1.2 uses a game |
| Chaos Dwarfs | 4 | 75% (6 of 8); on the table 75% | 42% (15 of 36) | 58% | 69% (22 of 32) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |
| Dwarfen Mountain Holds | 4 | 50% (1 of 2); on the table 50% | - | 86% | 65% (22 of 34) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 3 | 67% (2 of 3); on the table 67% | 67% (8 of 12) | 73% | 70% (21 of 30) | 0.0 uses a game | 100% (1 of 1); 0.3 uses a game | 0% (0 of 3); 0.0 uses a game |
| Grand Cathay | 1 | - | 42% (5 of 12) | 53% | 88% (7 of 8) | 100% (2 of 2); 4.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| High Elf Realms | 1 | - | 0% (0 of 6) | 83% | 38% (3 of 8) | 100% (1 of 1); 5.0 uses a game | 0% (0 of 2); 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 1 | - | 67% (4 of 6) | 98% | 71% (5 of 7) | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Tomb Kings of Khemri | 1 | 100% (2 of 2); on the table 100% | - | 37% | 40% (2 of 5) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 3 | 100% (11 of 11); on the table 100% | 42% (5 of 12) | 60% | 74% (14 of 19) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 1 | 100% (2 of 2); on the table 100% | - | 35% | 50% (3 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Wood Elf Realms | 1 | 0% (0 of 1); on the table 0% | - | 51% | 50% (5 of 10) | 100% (2 of 2); 5.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (h4-opp-bbe8617-p2, 12 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 42% (5) | 38% (5) | 40% (10) |
| ...free all their last turn and able to turn (per game) | 0.33 | 0.42 | 0.75 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.17 | 0.17 | 0.33 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.08 | 0.33 | 0.42 |

### Quality by phase: h4-opp-bbe8617-p2

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.4 | 2.2 |
| Strategy | Charge objectives carried out (made contact) | 80% (16 of 20) | 46% (11 of 24) |
| Strategy | Shoot objectives carried out (shot that target) | 48% (79 of 163) | 54% (51 of 94) |
| Strategy | Support requests answered (helper made contact too) | 50% (2 of 4) | 100% (1 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | - | 40% (2 of 5) |
| Strategy | Joined characters whose unit fought | 22% (8 of 37) | 32% (7 of 22) |
| Strategy | Lone characters that fought | 53% (9 of 17) | 50% (13 of 26) |
| Movement | Charges halted short of contact | 0.0 | 0.3 |
| Movement | Idle units | 1.8 | 2.5 |
| Movement | Points that never moved of their own | 152.8 | 102.6 |
| Movement | Fights charged into per game | 1.4 | 1.4 |
| Movement | Charges with odds: long shots (under 50%) | 3 of 17, net +153 | 2 of 15, net -446 |
| Movement | Charges with odds: sweet spot (55-75%) | 4 of 17, net -16 | 2 of 15, net +115 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 2 of 17, net +48 | 4 of 15, net +264 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 of 17, net +198 | 3 of 15, net +61 |
| Shooting | Shots by shooting units (incl. breath weapons) | 7.6 | 9.2 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 35% (32 of 91) | 47% (52 of 110) |
| Shooting | Points destroyed by shooting units | 77.3 | 24.2 |
| Shooting | War machine shots | 8.7 | 3.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 30% (31 of 104) | 48% (19 of 40) |
| Shooting | Points destroyed by war machines | 91.2 | 37.6 |
| Magic | Magic missiles cast | 2.4 | 1.5 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 45% (13 of 29) | 17% (3 of 18) |
| Magic | Wounds caused by magic missiles | 5.5 | 2.2 |
| Magic | Wounds caused by other spells | 0.3 | - |
| Magic | Points destroyed by magic (all spells) | 32.4 | 8.8 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.2 / 0.0 / 0.8 / 0.0 | 1.9 / 0.7 / 0.0 / 0.2 |
| Combat | Points destroyed in combat | 221.7 | 92.4 |
| Combat | Points run down | 0.0 | 121.8 |
| Combat | Net points per charged fight, damage counted | +61 | +69 |
| Combat | Net per 100 charger points, damage counted | +24.5 | +17.4 |
| Combat | First round won (charged fights) | 76% | 82% |
| Combat | Net points per charged fight | +74 | +61 |
| Combat | Net points per supported fight / lone fight | +86 / +72 | +289 / +12 |
| Combat | Charged fights on a top-3 enemy unit | 6 of 17 | 6 of 17 |
| Game | Points lost | 335.5 | 498.3 |
| Game | VP from objectives | 674.2 | 899.2 |
| Game | Lone holders (player turns) | 3.7 | 3.3 |

- Mine won / drew / lost: 5 / 2 / 5 of 12 ended games (of 12); mean margin (Mine - Opponent) -72 VP
- The side that went first won 6 of 10 games with a winner
- Points traded per game (both sides' losses): 834
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: h4-opp-bbe8617-p2

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.4 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.1 | +23.9 | 0.0 | 0.0 | 0.2 | +14.1 | 0.0 | 0.0 |
| ALREADY CARRIED | 0.2 | +0.0 | 0.0 | 10.8 | - | - | - | - |
| ARRIVAL HUNT | - | - | - | - | 0.1 | +1.4 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 2.6 | +0.0 | 0.0 | 42.5 | 0.5 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | - | - | - | - | 0.1 | +0.1 | 0.0 | 0.0 |
| BEST PRIZE | - | - | - | - | 0.2 | -19.0 | 11.7 | 0.0 |
| BLOWS WHERE AIMED | 0.3 | -32.8 | 9.0 | 5.0 | 0.3 | -97.9 | 24.1 | 54.6 |
| BOMBING RUN | - | - | - | - | 0.1 | +1.4 | 0.0 | 0.0 |
| CANNON PLAN MISSED | 1.2 | +0.0 | 256.7 | 8.8 | 0.5 | +0.0 | 23.9 | 0.0 |
| CANNON PLANNED TARGET | 7.7 | +214.7 | 629.2 | 137.1 | 2.8 | +53.1 | 123.8 | 48.3 |
| CANNON SIGHT KEPT | 1.3 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT SET-UP | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | -2.4 | 18.2 | 19.1 |
| CAST JOB | 0.6 | +10.8 | 18.5 | 6.8 | 0.2 | +8.4 | 13.5 | 0.0 |
| CASTER AWAY FROM SCREEN | 0.8 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.3 | +23.6 | 0.0 | 0.0 | 0.1 | +1.1 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 1.4 | +0.0 | 0.0 | 10.8 | 0.7 | +0.0 | 0.0 | 33.3 |
| CASTS FROM BEHIND | - | - | - | - | 0.4 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | 0.3 | +11.5 | 0.0 | 18.1 | 0.8 | +15.2 | 0.0 | 4.6 |
| CHAFF PASSED | - | - | - | - | 0.7 | -1.7 | 0.0 | 0.0 |
| CHARACTER GUNS | 0.2 | +0.0 | 0.0 | 0.0 | 0.5 | +0.0 | 0.0 | 18.7 |
| CHARGE LOSSES | 5.6 | -304.7 | 0.0 | 65.4 | 4.9 | -232.1 | 0.0 | 118.7 |
| CHARGE NOT DECLARED | 0.1 | +0.0 | 5.0 | 0.0 | 0.2 | +0.0 | 24.1 | 0.0 |
| CHARGE NOW FIRST | 1.1 | +0.0 | 58.8 | 8.8 | 0.8 | +0.0 | 30.2 | 71.2 |
| CHARGER SLAIN LOST | 0.3 | -8.5 | 36.2 | 5.0 | - | - | - | - |
| CHEAP HELPER | 0.2 | +0.0 | 0.0 | 5.0 | - | - | - | - |
| CHEAPEST HOLDER | 0.2 | -7.5 | 5.0 | 0.0 | - | - | - | - |
| COMBAT PIVOT | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 22.1 |
| CONVEYANCE SEARCH | 1.8 | +376.1 | 0.0 | 10.8 | 0.6 | +34.4 | 33.3 | 33.3 |
| COVER ONCE | 6.2 | -307.2 | 0.0 | 77.3 | 5.0 | -249.9 | 0.0 | 23.7 |
| DEFENSIVE ARMY | - | - | - | - | 0.1 | +0.0 | 0.0 | 3.0 |
| DEFENSIVE FLOOR | 0.1 | +1.3 | 0.0 | 5.4 | - | - | - | - |
| DEPLOY BY FIGURES | 9.5 | +3.4 | 0.0 | 5.4 | 7.7 | -30.4 | 0.0 | 10.0 |
| EDGE GIVE GROUND | 0.2 | +3.3 | 22.8 | 5.0 | 0.1 | +4.7 | 19.2 | 0.0 |
| ENGINEER BY LORE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FALL BACK GOOD ORDER | 1.0 | +7.5 | 26.9 | 19.2 | 1.2 | +5.4 | 44.2 | 109.6 |
| FALLBACK BY WORTH | 0.2 | +1.1 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| FALLS SHORT | 8.7 | +158.5 | 0.0 | 18.4 | 16.1 | +236.6 | 0.0 | 126.5 |
| FEATURE BUFFS | 2.2 | +62.4 | 0.0 | 15.0 | 0.3 | +11.8 | 0.0 | 0.0 |
| FIGHT TO THE END | 0.8 | +18.8 | 8.2 | 23.5 | 1.0 | +35.4 | 66.1 | 90.5 |
| FIRE AND FLEE | - | - | - | - | 0.1 | +9.8 | 0.0 | 0.0 |
| FIRE IN ORDER | 0.3 | +0.0 | 10.4 | 5.0 | 0.2 | +0.0 | 9.2 | 0.0 |
| FIVE ACTION | 49.3 | +2566.9 | 883.8 | 479.4 | 47.2 | +3018.5 | 323.8 | 512.4 |
| FLANK NOT WEIGHED | 4.8 | +0.0 | 0.0 | 85.2 | 3.5 | +0.0 | 0.0 | 31.9 |
| FOLLOW UP WEIGHED | 0.5 | +121.2 | 0.0 | 0.0 | 0.3 | +34.2 | 0.0 | 0.0 |
| FOUR ROUNDS | 1.7 | +140.5 | 62.9 | 54.3 | 2.0 | +173.9 | 127.6 | 109.6 |
| FRIEND CHARGES FIRST | 0.1 | -0.6 | 0.0 | 0.0 | 0.3 | -15.6 | 0.0 | 16.2 |
| FRIEND SHOOTS FIRST | 0.5 | -6.3 | 0.0 | 5.0 | 0.2 | -1.3 | 0.0 | 0.0 |
| FRIENDS SHOTS CHECKED | 0.1 | +4.3 | 0.0 | 0.0 | - | - | - | - |
| GIVES UP | 0.1 | -0.5 | 0.0 | 0.0 | 0.5 | -7.0 | 75.2 | 0.0 |
| GROUND FLIERS | 0.1 | +1.2 | 0.0 | 0.0 | - | - | - | - |
| GUN FIGURES | 1.8 | +12.0 | 35.2 | 9.6 | 0.5 | +15.4 | 9.2 | 0.0 |
| GUN MASK | 0.4 | +9.1 | 0.0 | 0.0 | 1.2 | +29.5 | 0.0 | 0.0 |
| HARD STAY DROPPED | 1.9 | +0.0 | 0.0 | 5.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| HE SHOOTS OR CHARGES | 2.2 | +0.0 | 0.0 | 42.8 | 2.2 | +0.0 | 0.0 | 1.6 |
| HELPER UNSEEN | 0.1 | +0.0 | 19.1 | 0.0 | - | - | - | - |
| HIS CHARGE DENIED | 0.4 | +3.5 | 16.9 | 4.3 | 0.1 | +2.2 | 0.0 | 0.0 |
| HIS CHARGE LIST | 3.1 | +0.0 | 0.0 | 49.7 | 2.8 | +0.0 | 0.0 | 9.0 |
| HIS LEGAL MOVES | 3.8 | +0.0 | 0.0 | 59.4 | 3.4 | +0.0 | 0.0 | 24.1 |
| HIS MOVE AND SHOT | 1.1 | -14.6 | 0.0 | 10.0 | 2.1 | -59.8 | 0.0 | 40.1 |
| HIS RANDOM MOVE | - | - | - | - | 1.8 | +0.0 | 0.0 | 11.4 |
| HIS SHOT LIST | 21.2 | +813.0 | 0.0 | 129.8 | 25.8 | +1273.2 | 0.0 | 200.2 |
| HIS TURN DENIED | 0.6 | +21.1 | 22.8 | 44.6 | 0.9 | +31.5 | 63.2 | 74.2 |
| HOLD ODDS | - | - | - | - | 8.8 | +0.0 | 0.0 | 24.5 |
| HOLDER ASSIGNMENT | - | - | - | - | 16.2 | +1709.7 | 0.0 | 24.5 |
| HOLDER AT DEPLOYMENT | 1.0 | +183.6 | 0.0 | 0.0 | - | - | - | - |
| HOLDS AMBUSHERS | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 1.5 | -38.2 | 34.8 | 49.3 | 2.0 | -112.9 | 127.6 | 109.6 |
| HUNT IN PAIRS | - | - | - | - | 0.2 | +10.2 | 0.0 | 16.2 |
| IDLE COST | 3.8 | -40.4 | 0.0 | 18.8 | 9.8 | -148.7 | 0.0 | 121.6 |
| JOINT KNOWS CHALLENGE | 0.1 | -0.4 | 0.0 | 0.0 | - | - | - | - |
| KEEP FALLS | 0.1 | +0.2 | 0.0 | 0.0 | - | - | - | - |
| KEEPS SCOUTS OR AMBUSH | 0.2 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| LANE BY FIGURES | 0.2 | +11.9 | 0.0 | 0.0 | 0.7 | +26.2 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 3.0 | +0.0 | 104.2 | 72.2 | 4.4 | +0.0 | 50.2 | 268.5 |
| LONE CHARACTER SAFE SPOT | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +3.8 | 0.0 | 0.0 |
| LONE WIZARD KEPT IN | 0.8 | +66.3 | 0.0 | 0.0 | 0.2 | +25.3 | 0.0 | 0.0 |
| LONG SHOT | 0.1 | +0.3 | 0.0 | 5.4 | - | - | - | - |
| LOST CHARGE | 0.3 | -2.7 | 5.0 | 5.4 | - | - | - | - |
| MAKE SURE TOGETHER | - | - | - | - | 0.6 | +32.3 | 0.0 | 36.8 |
| MANOEUVRE | 1.1 | +12.8 | 0.0 | 33.3 | 1.6 | +26.5 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.2 | +2.7 | 0.0 | 7.1 | 0.1 | +0.3 | 0.0 | 0.0 |
| MARCH BY THE SUM | 0.4 | +23.5 | 0.0 | 6.8 | 0.3 | +17.9 | 0.0 | 0.0 |
| MARCH CHECK | 0.7 | +50.0 | 0.0 | 6.8 | 0.3 | +10.6 | 0.0 | 0.0 |
| MARCH OVER CASTS | 0.8 | +25.7 | 0.0 | 13.8 | 0.6 | +28.1 | 0.0 | 33.3 |
| MAX FOR POSITIONING | 5.8 | +103.1 | 0.0 | 98.1 | 5.1 | +62.3 | 0.0 | 51.2 |
| MISSILES IN THE MOVE | 3.2 | +175.5 | 0.0 | 20.6 | 3.6 | +58.2 | 0.0 | 9.0 |
| MISSILES NEXT TURN | 4.2 | +123.3 | 0.0 | 34.4 | 4.1 | +33.5 | 0.0 | 42.3 |
| MODEL FACING | 1.0 | +104.0 | 0.0 | 20.0 | - | - | - | - |
| MOVE SPELL IN RANGE | 0.3 | +11.4 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL NOT WORTH | 0.1 | -0.1 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.7 | -27.4 | 0.0 | 0.0 | 0.1 | -0.3 | 0.0 | 0.0 |
| MOVE SPELL SPOT | 0.7 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 33.3 |
| MOVE TO CHARGE COMPUTED | 2.4 | +347.8 | 0.0 | 24.6 | 3.9 | +380.5 | 0.0 | 32.8 |
| MOVES UNITS SPELL | 0.2 | +9.2 | 0.0 | 0.0 | - | - | - | - |
| NEARER NOT NEEDED | 4.5 | +236.7 | 0.0 | 24.1 | 7.0 | +286.8 | 0.0 | 22.0 |
| NEXT CHARGE BY LIST | 4.1 | -194.5 | 23.7 | 41.2 | 5.5 | -218.9 | 0.0 | 45.8 |
| NEXT OBJECTIVE NEARER | 7.1 | -334.1 | 65.8 | 51.7 | 0.1 | -3.8 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 1.1 | -42.6 | 22.2 | 50.0 | 1.4 | -32.9 | 89.0 | 109.6 |
| NOT TURNED | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 5.8 |
| NOT WORTH A CAST | 0.2 | -0.2 | 0.0 | 0.0 | 0.8 | -0.3 | 0.0 | 0.0 |
| OFF BEST | 0.5 | -15.0 | 0.0 | 0.0 | 0.5 | -8.8 | 0.0 | 0.0 |
| ONE CHARGE A CHARGER | 2.4 | +0.0 | 0.0 | 55.5 | 1.3 | +0.0 | 0.0 | 10.8 |
| ONE FIGHT FORMULA | 4.0 | -80.5 | 0.0 | 61.0 | 4.8 | -113.5 | 0.0 | 88.3 |
| ONE OBJECTIVE FORMULA | 3.8 | +51.1 | 0.0 | 16.2 | 4.3 | +3.7 | 0.0 | 18.1 |
| ONE TARGET A SHOOTER | 16.6 | +526.7 | 0.0 | 107.5 | 16.5 | +470.5 | 0.0 | 132.9 |
| OPENS A LANE | 0.2 | +0.6 | 10.0 | 0.0 | 0.1 | +0.3 | 0.0 | 0.0 |
| OPENS UP | 0.1 | +2.6 | 0.0 | 0.0 | 0.2 | +21.8 | 15.6 | 0.0 |
| OVERRUNS AWAY | 0.2 | +7.0 | 8.2 | 34.6 | 0.4 | +104.6 | 56.6 | 0.0 |
| PATHS CROSS | 3.6 | +98.9 | 0.0 | 16.4 | 4.8 | +212.3 | 0.0 | 16.2 |
| PLAN RESULT | 43.2 | +839.3 | 586.8 | 479.7 | 42.2 | +378.0 | 146.4 | 846.8 |
| PURSUES BIG PREY | - | - | - | - | 0.1 | -23.8 | 0.0 | 0.0 |
| QUARTER ODDS | - | - | - | - | 3.4 | +648.0 | 16.8 | 69.8 |
| RANDOM MOVE BY FIGURES | 0.8 | +18.6 | 0.0 | 0.0 | - | - | - | - |
| REDIRECT BY WHAT IT STOPS | - | - | - | - | 0.2 | -4.4 | 0.0 | 0.0 |
| REDIRECT COUNTER | 2.1 | +145.7 | 0.0 | 48.2 | 2.2 | +80.4 | 0.0 | 16.8 |
| REDIRECT WEIGHED | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | -17.6 | 11.7 | 0.0 |
| REFORMS TO MEET IT | 0.2 | -19.5 | 0.0 | 0.0 | 0.8 | -113.3 | 0.0 | 2.8 |
| REFUSING RETIRES | 0.2 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 35.9 |
| RESERVE FALL BACK | 0.6 | +20.7 | 0.0 | 0.0 | 0.5 | +19.7 | 0.0 | 5.5 |
| RISK BY ARC | 1.0 | +4.9 | 22.2 | 54.3 | 1.1 | -86.3 | 95.7 | 35.3 |
| RISK BY HIS FIGURE | 12.8 | -256.9 | 0.0 | 182.8 | 9.3 | -97.3 | 0.0 | 60.0 |
| RUN DOWN | 1.0 | -9.9 | 30.9 | 18.8 | 1.5 | -7.1 | 86.7 | 73.7 |
| SAME CHARGE LATER | 0.1 | -6.7 | 15.5 | 0.0 | - | - | - | - |
| SCOUT SPOT | 0.2 | +0.6 | 0.0 | 0.0 | 0.5 | +0.4 | 0.0 | 0.0 |
| SCOUT WAITS | 0.2 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.1 | +4.2 | 0.0 | 6.8 | 0.4 | -39.0 | 0.0 | 8.8 |
| SEARCH SPOT | 5.7 | +281.9 | 0.0 | 31.6 | 6.2 | +326.9 | 0.0 | 10.2 |
| SET UP TOGETHER | 0.2 | +1.2 | 0.0 | 0.0 | 0.6 | +32.3 | 0.0 | 36.8 |
| SET-UP ANY TARGET | 0.2 | +43.1 | 0.0 | 10.8 | 0.1 | +2.4 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.7 | +1.3 | 0.0 | 0.0 | - | - | - | - |
| SHOOTS FROM THE BEST SPOT | 1.1 | +64.1 | 19.2 | 7.1 | 1.3 | +26.6 | 0.0 | 35.9 |
| SHORT GUN FORWARD | 0.5 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| SHOT OR CHARGE | 0.1 | -0.2 | 3.8 | 0.0 | 0.6 | -17.9 | 21.2 | 32.5 |
| SHOT RISK POINTS | 12.2 | +12.2 | 0.0 | 129.3 | 14.1 | +63.5 | 0.0 | 211.0 |
| SHOTS IN THE MOVE | 16.6 | +674.4 | 0.0 | 195.3 | 14.8 | +412.2 | 0.0 | 183.2 |
| SPELL SETS UP CHARGE | 0.4 | +110.7 | 0.0 | 10.8 | 0.1 | +2.4 | 0.0 | 0.0 |
| SPELL WORTH | 0.4 | +2.6 | 6.4 | 0.0 | 1.8 | +17.7 | 49.2 | 68.7 |
| SPELLS IN THE FIGHT | 0.5 | -2.7 | 4.2 | 5.4 | 0.1 | -6.7 | 0.0 | 22.1 |
| STAND AND SHOOT | 0.3 | -4.7 | 9.0 | 44.6 | 0.2 | -1.7 | 10.8 | 0.0 |
| STANDS FOR A REASON | 0.1 | +0.0 | 0.0 | 0.0 | 0.8 | +0.0 | 0.0 | 35.9 |
| STANDS STILL | 24.6 | +0.0 | 820.9 | 242.3 | 15.9 | +0.0 | 196.2 | 185.1 |
| STAY WORTH | 23.2 | +200.2 | 538.0 | 204.9 | 16.8 | +119.5 | 159.6 | 176.6 |
| SUPPORT NARROWED | 1.0 | +0.0 | 36.2 | 24.2 | 0.7 | +0.0 | 20.4 | 19.1 |
| SURE REACH TOGETHER | 0.3 | +5.6 | 0.0 | 0.0 | 0.7 | +5.8 | 0.0 | 35.9 |
| THE DEARER SUM KEEPS ITS PLAN | 4.1 | +0.0 | 0.0 | 30.6 | 4.9 | +0.0 | 0.0 | 16.2 |
| THE PROMISED MOVE | 0.1 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| TIED UP BY THE SUM | 0.2 | +8.6 | 8.8 | 0.0 | 0.5 | +52.7 | 48.0 | 19.1 |
| TIME ON OUR SIDE | 23.0 | +359.5 | 15.4 | 259.8 | 11.8 | +202.0 | 0.0 | 34.8 |
| WAITS AGAIN | 0.9 | +0.0 | 0.0 | 5.0 | 0.8 | +0.0 | 0.0 | 0.0 |
| WAR ENGINE CHARGES | 0.2 | +18.7 | 0.0 | 0.0 | - | - | - | - |
| WAR ENGINE JOBS | 0.4 | +0.0 | 15.5 | 25.8 | - | - | - | - |
| WHO HITS BACK | 0.2 | +8.8 | 0.0 | 0.0 | 0.1 | +3.1 | 0.0 | 0.0 |
| WHOLE FIGHT | - | - | - | - | 0.2 | +5.8 | 15.8 | 16.2 |
| WHOLE FIGHT GAIN | 0.2 | +8.8 | 0.0 | 0.0 | - | - | - | - |
| WIDER SPREAD | 1.6 | -13.2 | 62.9 | 50.0 | 1.7 | -4.8 | 118.7 | 54.6 |
| WOUNDS ON THE RANKS | 1.9 | +136.6 | 0.0 | 24.1 | 1.8 | +66.5 | 0.0 | 0.0 |

### Rule changes: h4-opp-bbe8617-p2

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HOLDER ASSIGNMENT | 195 | 195 | 182 | 15.17 | +10520 | +57.8 |
| HIS SHOT LIST | 563 | 563 | 154 | 12.83 | +3732 | +24.2 |
| SEARCH SPOT | 142 | 142 | 129 | 10.75 | +7306 | +56.6 |
| DEPLOY BY FIGURES | 206 | 206 | 127 | 10.58 | +1988 | +15.7 |
| ONE TARGET A SHOOTER | 397 | 397 | 116 | 9.67 | +1402 | +12.1 |
| PATHS CROSS | 100 | 100 | 100 | 8.33 | +3734 | +37.3 |
| LEGAL CHARGES ONLY | 89 | 89 | 89 | 7.42 | +0 | +0.0 |
| TIME ON OUR SIDE | 417 | 383 | 88 | 7.33 | +278 | +3.2 |
| SHOT RISK POINTS | 315 | 315 | 59 | 4.92 | +2154 | +36.5 |
| FIVE ACTION | 1158 | 1157 | 55 | 4.58 | +2487 | +45.2 |
| MOVE TO CHARGE COMPUTED | 76 | 76 | 42 | 3.50 | +3525 | +83.9 |
| ARTILLERY RE-ROLL WEIGHED | 37 | 37 | 37 | 3.08 | +0 | +0.0 |
| HARD STAY DROPPED | 35 | 35 | 35 | 2.92 | +0 | +0.0 |
| MAX FOR POSITIONING | 130 | 126 | 27 | 2.25 | +33 | +1.2 |
| FOUR ROUNDS | 44 | 43 | 24 | 2.00 | +1138 | +47.4 |
| COVER ONCE | 135 | 113 | 23 | 1.92 | +209 | +9.1 |
| FALLS SHORT | 297 | 266 | 22 | 1.83 | +144 | +6.5 |
| CANNON PLANNED TARGET | 125 | 125 | 21 | 1.75 | -351 | -16.7 |
| REDIRECT COUNTER | 52 | 46 | 20 | 1.67 | +1733 | +86.7 |
| CANNON SIGHT KEPT | 19 | 19 | 19 | 1.58 | +0 | +0.0 |
| CHARGE LOSSES | 126 | 126 | 16 | 1.33 | +1359 | +85.0 |
| MISSILES IN THE MOVE | 82 | 61 | 15 | 1.25 | +441 | +29.4 |
| NEXT OBJECTIVE NEARER | 86 | 86 | 15 | 1.25 | +256 | +17.1 |
| RISK BY HIS FIGURE | 265 | 265 | 15 | 1.25 | +1041 | +69.4 |
| SHOTS IN THE MOVE | 377 | 344 | 15 | 1.25 | +374 | +25.0 |
| IDLE COST | 163 | 139 | 14 | 1.17 | +111 | +7.9 |
| SHOOTS FROM THE BEST SPOT | 29 | 29 | 14 | 1.17 | +187 | +13.4 |
| ADVANCE LANE KEPT | 13 | 13 | 13 | 1.08 | +0 | +0.0 |
| LONE WIZARD KEPT IN | 13 | 13 | 13 | 1.08 | +1099 | +84.5 |
| MANOEUVRE | 32 | 32 | 13 | 1.08 | +508 | +39.0 |
| RESERVE FALL BACK | 13 | 13 | 13 | 1.08 | +486 | +37.4 |
| MODEL FACING | 12 | 12 | 12 | 1.00 | +1248 | +104.0 |
| OFF BEST | 12 | 12 | 12 | 1.00 | -286 | -23.8 |
| WOUNDS ON THE RANKS | 45 | 45 | 12 | 1.00 | +466 | +38.9 |
| LANE BY FIGURES | 11 | 11 | 11 | 0.92 | +457 | +41.6 |
| CASTER AWAY FROM SCREEN | 10 | 10 | 10 | 0.83 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 10 | 10 | 10 | 0.83 | +1865 | +186.5 |
| MARCH BY THE SUM | 9 | 9 | 9 | 0.75 | +496 | +55.1 |
| ONE OBJECTIVE FORMULA | 97 | 84 | 9 | 0.75 | +279 | +31.0 |
| SCOUT WAITS | 9 | 9 | 9 | 0.75 | +0 | +0.0 |
| CHAFF PASSED | 8 | 8 | 8 | 0.67 | -21 | -2.6 |
| HOLDER AT DEPLOYMENT | 12 | 12 | 8 | 0.67 | +376 | +47.0 |
| HOLDS AMBUSHERS | 8 | 8 | 8 | 0.67 | +0 | +0.0 |
| ONE FIGHT FORMULA | 106 | 62 | 8 | 0.67 | +153 | +19.2 |
| SHOOTERS IN TWO RANKS | 8 | 8 | 8 | 0.67 | +16 | +2.0 |
| SHORT GUN FORWARD | 8 | 8 | 8 | 0.67 | +0 | +0.0 |
| CHARGE NOW FIRST | 22 | 22 | 7 | 0.58 | -765 | -109.3 |
| FIRE IN ORDER | 7 | 7 | 7 | 0.58 | +0 | +0.0 |
| QUARTER ODDS | 41 | 41 | 7 | 0.58 | +1758 | +251.1 |
| CHAFF IN THE MOVE | 13 | 12 | 6 | 0.50 | +98 | +16.3 |
| MARCH CHECK | 12 | 12 | 6 | 0.50 | +146 | +24.3 |
| CASTS FROM BEHIND | 5 | 5 | 5 | 0.42 | +0 | +0.0 |
| HIS TURN DENIED | 18 | 18 | 5 | 0.42 | +88 | +17.6 |
| NEXT CHARGE BY LIST | 115 | 115 | 5 | 0.42 | +104 | +20.7 |
| OVERRUNS AWAY | 8 | 8 | 5 | 0.42 | +202 | +40.3 |
| REDIRECT WEIGHED | 5 | 5 | 5 | 0.42 | +368 | +73.5 |
| STAY WORTH | 480 | 460 | 5 | 0.42 | +71 | +14.1 |
| TIED UP BY THE SUM | 8 | 7 | 5 | 0.42 | +94 | +18.9 |
| CAST JOB | 9 | 9 | 4 | 0.33 | +66 | +16.4 |
| CASTING BLOCK | 5 | 5 | 4 | 0.33 | +122 | +30.5 |
| GUN MASK | 19 | 19 | 4 | 0.33 | +99 | +24.7 |
| NEARER NOT NEEDED | 138 | 135 | 4 | 0.33 | +119 | +29.9 |
| RISK BY ARC | 25 | 24 | 4 | 0.33 | +53 | +13.2 |
| SURE REACH TOGETHER | 12 | 12 | 4 | 0.33 | +4 | +1.1 |
| AFTERMATH IN POINTS | 3 | 3 | 3 | 0.25 | +455 | +151.8 |
| CHARGE NOT DECLARED | 3 | 3 | 3 | 0.25 | -181 | -60.4 |
| OPENS UP | 3 | 3 | 3 | 0.25 | +149 | +49.6 |
| RANDOM MOVE BY FIGURES | 9 | 9 | 3 | 0.25 | +223 | +74.5 |
| WHO HITS BACK | 3 | 3 | 3 | 0.25 | +79 | +26.4 |
| BEST PRIZE | 2 | 2 | 2 | 0.17 | -228 | -114.0 |
| COMBAT PIVOT | 2 | 2 | 2 | 0.17 | +0 | +0.0 |
| FEATURE BUFFS | 30 | 30 | 2 | 0.17 | +34 | +16.9 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.17 | +0 | +0.0 |
| MISSILES NEXT TURN | 100 | 74 | 2 | 0.17 | +13 | +6.7 |
| MOVES UNITS SPELL | 2 | 2 | 2 | 0.17 | +110 | +55.1 |
| REFUSING RETIRES | 6 | 6 | 2 | 0.17 | -1 | -0.6 |
| SUPPORT NARROWED | 20 | 20 | 2 | 0.17 | -10 | -5.1 |
| BOMBING RUN | 1 | 1 | 1 | 0.08 | +17 | +17.2 |
| CARRIES OUT SET-UP | 3 | 3 | 1 | 0.08 | -29 | -28.7 |
| DEFENSIVE FLOOR | 1 | 1 | 1 | 0.08 | +10 | +10.4 |
| EDGE GIVE GROUND | 3 | 3 | 1 | 0.08 | +34 | +33.7 |
| FALL BACK GOOD ORDER | 26 | 25 | 1 | 0.08 | +9 | +9.2 |
| FALLBACK BY WORTH | 6 | 6 | 1 | 0.08 | +13 | +12.7 |
| FIGHT TO THE END | 22 | 22 | 1 | 0.08 | +30 | +30.1 |
| FIRE AND FLEE | 1 | 1 | 1 | 0.08 | +118 | +118.2 |
| FRIENDS SHOTS CHECKED | 1 | 1 | 1 | 0.08 | +51 | +51.2 |
| HONEST WORTH | 42 | 41 | 1 | 0.08 | +11 | +10.8 |
| KEEP FALLS | 1 | 1 | 1 | 0.08 | +25 | +24.8 |
| PURSUES BIG PREY | 1 | 1 | 1 | 0.08 | -286 | -285.9 |
| WAR ENGINE CHARGES | 3 | 3 | 1 | 0.08 | +99 | +98.8 |
| WAR ENGINE JOBS | 5 | 5 | 1 | 0.08 | -0 | -0.3 |
| WHOLE FIGHT | 2 | 2 | 1 | 0.08 | +26 | +25.9 |
| ALREADY CARRIED | 3 | not checked | - | - | - | - |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| BACKUP TARGETS | 1 | not checked | - | - | - | - |
| BLOWS WHERE AIMED | 8 | 8 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 21 | 21 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 25 | trace | - | - | - | - |
| CHARACTER GUNS | 8 | 8 | 0 | 0.00 | - | - |
| CHARGER SLAIN LOST | 4 | 4 | 0 | 0.00 | - | - |
| CHEAP HELPER | 2 | not checked | - | - | - | - |
| CHEAPEST HOLDER | 3 | 3 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 29 | not checked | - | - | - | - |
| DEFENSIVE ARMY | 1 | 1 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 99 | not checked | - | - | - | - |
| FRIEND CHARGES FIRST | 5 | 5 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 8 | 8 | 0 | 0.00 | - | - |
| GIVES UP | 7 | 7 | 0 | 0.00 | - | - |
| GROUND FLIERS | 1 | not checked | - | - | - | - |
| GUN FIGURES | 27 | not checked | - | - | - | - |
| HE SHOOTS OR CHARGES | 54 | 54 | 0 | 0.00 | - | - |
| HELPER UNSEEN | 1 | 1 | 0 | 0.00 | - | - |
| HIS CHARGE DENIED | 6 | 6 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 70 | 70 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 86 | 86 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 38 | 38 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 22 | 22 | 0 | 0.00 | - | - |
| HOLD ODDS | 106 | 106 | 0 | 0.00 | - | - |
| HUNT IN PAIRS | 2 | not checked | - | - | - | - |
| JOINT KNOWS CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 2 | not checked | - | - | - | - |
| LONG SHOT | 1 | 1 | 0 | 0.00 | - | - |
| LOST CHARGE | 4 | 4 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 7 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 3 | trace | - | - | - | - |
| MARCH OVER CASTS | 17 | 17 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 4 | 4 | 0 | 0.00 | - | - |
| MOVE SPELL NOT WORTH | 1 | not checked | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 9 | trace | - | - | - | - |
| MOVE SPELL SPOT | 13 | not checked | - | - | - | - |
| NO DOUBLE ROUNDS | 30 | 29 | 0 | 0.00 | - | - |
| NOT TURNED | 5 | 5 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 11 | not checked | - | - | - | - |
| ONE CHARGE A CHARGER | 45 | 45 | 0 | 0.00 | - | - |
| OPENS A LANE | 3 | not checked | - | - | - | - |
| PLAN RESULT | 1025 | trace | - | - | - | - |
| REDIRECT BY WHAT IT STOPS | 2 | 2 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 13 | 13 | 0 | 0.00 | - | - |
| RUN DOWN | 30 | 29 | 0 | 0.00 | - | - |
| SAME CHARGE LATER | 1 | 1 | 0 | 0.00 | - | - |
| SCOUT SPOT | 8 | 8 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 6 | 6 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 9 | 7 | 0 | 0.00 | - | - |
| SET-UP ANY TARGET | 4 | not checked | - | - | - | - |
| SHOT OR CHARGE | 8 | 8 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 6 | not checked | - | - | - | - |
| SPELL WORTH | 26 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 7 | 7 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 7 | 7 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 11 | 11 | 0 | 0.00 | - | - |
| STANDS STILL | 486 | 486 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 108 | not checked | - | - | - | - |
| THE PROMISED MOVE | 13 | not checked | - | - | - | - |
| WAITS AGAIN | 21 | 21 | 0 | 0.00 | - | - |
| WHOLE FIGHT GAIN | 2 | 2 | 0 | 0.00 | - | - |
| WIDER SPREAD | 39 | 39 | 0 | 0.00 | - | - |

### Off best figure: h4-opp-bbe8617-p2

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| HOLDER ASSIGNMENT | rule | - | 1.08 | 18.1 |
| PATHS CROSS | rule | 0.42 | 0.50 | 23.3 |
| JOB FIRST | gate | 0.25 | 0.42 | 32.9 |
| CHARGE NOW FIRST | rule | 0.25 | 0.33 | 109.3 |
| CANNON PLANNED TARGET | rule | 0.50 | - | 76.0 |
| CHARGE NOT DECLARED | rule | 0.08 | 0.17 | 60.4 |
| BEST PRIZE | rule | - | 0.17 | 114.0 |
| CHAFF PASSED | rule | - | 0.17 | 10.4 |
| DEPLOY BY FIGURES | rule | - | 0.17 | 28.4 |
| SUPPORT NARROWED | rule | - | 0.17 | 5.1 |
| AFTERMATH BAND | gate | 0.08 | - | 2.1 |
| CARRIES OUT SET-UP | rule | - | 0.08 | 28.7 |
| FALLBACK | gate | 0.08 | - | 4.1 |
| NO REASON | gate | - | 0.08 | 12.6 |
| PURSUES BIG PREY | rule | - | 0.08 | 285.9 |
| REFUSING RETIRES | rule | - | 0.08 | 0.8 |
| TURN GATE | gate | 0.08 | - | 4.1 |
| WHO HITS BACK | rule | 0.08 | - | 2.1 |

### Plans: h4-opp-bbe8617-p2

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.5 | 44% | 144 | 91 | 63% |
| Mine | join | 0.9 | 100% | 28 | 0 | 0% |
| Mine | move | 29.5 | 95% | 1555 | 0 | 0% |
| Mine | shoot | 11.2 | 61% | 604 | 749 | 124% |
| Mine | support | 0.1 | 100% | 6 | 0 | 0% |
| Opponent | charge | 1.7 | 65% | 234 | 134 | 57% |
| Opponent | join | 1.1 | 100% | 38 | 0 | 0% |
| Opponent | move | 32.8 | 94% | 1844 | 0 | 0% |
| Opponent | shoot | 6.3 | 62% | 304 | 244 | 80% |
| Opponent | support | 0.4 | 80% | 1 | 0 | 0% |

### Battle groups: h4-opp-bbe8617-p2

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 2.1 | 28% | 71% | 14% | 0% | 0% | 0% | 0% | 83% | 17% |
| Opponent | REDIRECT COUNTER | 2.2 | 11% | 67% | 0% | - | 33% | 0% | 0% | 67% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: h4-opp-bbe8617-p2

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 9 | 0 (9) | 0 | 0 | 46 | 67% | 2.3 | 0 (3) | 0 (3) | 0 (3) | 0 (5) | 0 (4) |
| Mine | Character | 49 | 26 (49) | 26 | 0 | 11 | 31% | 2.2 | 0 (14) | 32 (24) | 46 (8) | 12 (11) | 33 (35) |
| Mine | Clean-up | 14 | 148 (14) | 55 | 93 | 44 | 57% | 2.3 | 203 (4) | 185 (6) | 55 (4) | 126 (9) | 213 (5) |
| Mine | Fast Hammer | 4 | 18 (4) | 18 | 0 | 50 | 25% | 2.7 | 35 (2) | 0 (2) | - | 71 (1) | 0 (3) |
| Mine | Hammer | 30 | 52 (30) | 20 | 32 | 12 | 33% | 2.5 | 40 (6) | 60 (18) | 38 (6) | 20 (10) | 63 (20) |
| Mine | Holder | 9 | 46 (9) | 0 | 46 | 29 | 78% | 5.0 | 0 (1) | 81 (5) | 0 (3) | 59 (3) | 38 (6) |
| Mine | Shooter | 14 | 88 (14) | 3 | 85 | 21 | 7% | 2.5 | 88 (3) | 69 (8) | 144 (3) | 104 (10) | 54 (4) |
| Mine | War machine | 30 | 53 (30) | 53 | 0 | 29 | 10% | 1.3 | 84 (14) | 4 (7) | 41 (9) | 109 (5) | 41 (25) |
| Mine | Wizard | 5 | 0 (5) | 0 | 0 | 0 | 80% | 4.0 | 0 (1) | 0 (4) | - | - | 0 (5) |
| Opponent | Chaff | 25 | 154 (25) | 8 | 145 | 38 | 64% | 2.9 | 203 (8) | 169 (9) | 92 (8) | 169 (19) | 117 (6) |
| Opponent | Character | 38 | 15 (38) | 15 | 0 | 27 | 34% | 2.3 | 8 (13) | 22 (20) | 0 (5) | 19 (23) | 11 (15) |
| Opponent | Clean-up | 6 | 8 (6) | 8 | 0 | 47 | 50% | 1.3 | 0 (1) | 10 (5) | - | 7 (4) | 10 (2) |
| Opponent | Early | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Fast | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Fast Hammer | 18 | 49 (18) | 33 | 15 | 17 | 56% | 2.2 | 27 (8) | 66 (9) | 0 (1) | 62 (11) | 30 (7) |
| Opponent | Hammer | 11 | 47 (11) | 2 | 45 | 26 | 36% | 2.3 | - | 67 (7) | 12 (4) | 64 (7) | 13 (4) |
| Opponent | Holder | 6 | 87 (6) | 0 | 87 | 17 | 67% | 1.5 | - | 113 (5) | 0 (1) | - | 87 (6) |
| Opponent | Shooter | 13 | 84 (13) | 18 | 66 | 7 | 8% | 1.7 | 98 (6) | 137 (3) | 21 (4) | 112 (6) | 49 (7) |
| Opponent | Support | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | War machine | 15 | 21 (15) | 21 | 0 | 43 | 0% | 2.6 | 15 (5) | 39 (6) | 0 (4) | 0 (3) | 25 (12) |
| Opponent | Wizard | 10 | 2 (10) | 2 | 0 | 32 | 20% | 3.0 | 0 (4) | 0 (2) | 0 (2) | 0 (6) | 0 (2) |

### Charged fights: h4-opp-bbe8617-p2

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 51 | 72 | 0.8 | 1.0 | 96 | 17 | +79 | 0 of 3 | 2 of 3 | - | +79 |
| Mine | Chaos Dwarfs | 4 | 133 | 200 | 2.5 | 1.2 | 80 | 6 | +74 | 5 of 10 | 8 of 10 | +86 | +70 |
| Mine | Dwarfen Mountain Holds | 4 | 419 | 86 | 1.0 | 1.0 | 86 | 15 | +70 | 1 of 4 | 3 of 4 | - | +70 |
| **Mine** | all armies | 12 | 201 | 119 | 1.4 | 1.1 | 84 | 10 | +74 | 6 of 17 | 13 of 17 | +86 | +72 |
| Opponent | Empire of Man | 3 | 167 | 57 | 0.7 | 1.0 | 85 | 132 | -48 | 1 of 2 | 1 of 2 | - | -48 |
| Opponent | Grand Cathay | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | High Elf Realms | 1 | 65 | 117 | 1.0 | 1.0 | 117 | 0 | +117 | 0 of 1 | 1 of 1 | - | +117 |
| Opponent | Ogre Kingdoms | 1 | 60 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Tomb Kings of Khemri | 1 | 55 | 337 | 6.0 | 1.0 | 56 | 137 | -81 | 3 of 6 | 4 of 6 | - | -81 |
| Opponent | Vampire Counts | 3 | 0 | 252 | 2.0 | 1.3 | 126 | 0 | +126 | 1 of 6 | 6 of 6 | +94 | +142 |
| Opponent | Warriors of Chaos | 1 | 0 | 677 | 1.0 | 2.0 | 677 | 0 | +677 | 1 of 1 | 1 of 1 | +677 | - |
| Opponent | Wood Elf Realms | 1 | 165 | 60 | 1.0 | 1.0 | 60 | 0 | +60 | 0 of 1 | 1 of 1 | - | +60 |
| **Opponent** | all armies | 12 | 70 | 176 | 1.4 | 1.2 | 124 | 64 | +61 | 6 of 17 | 14 of 17 | +289 | +12 |

### Effective charges: h4-opp-bbe8617-p2

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 3 | 2 (net +88) | 0 | 0 | 0 | 0 | 1 (net +60) | 0 | 0% (0 of 3) |
| Mine | Chaos Dwarfs | 10 | 0 | 1 (net +0) | 3 (net -22) | 3 (net +57) | 2 (net +48) | 1 (net +534) | 0 | 30% (3 of 10) |
| Mine | Dwarfen Mountain Holds | 4 | 1 (net +282) | 0 | 1 (net +0) | 1 (net +0) | 0 | 1 (net +0) | 0 | 25% (1 of 4) |
| Opponent | Empire of Man | 2 | 1 (net -265) | 0 | 0 | 1 (net +170) | 0 | 0 | 0 | 0% (0 of 2) |
| Opponent | High Elf Realms | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +117) | 0 | 0% (0 of 1) |
| Opponent | Tomb Kings of Khemri | 6 | 1 (net -626) | 1 (net +195) | 0 | 1 (net -195) | 1 (net +77) | 2 (net +32) | 0 | 0% (0 of 6) |
| Opponent | Vampire Counts | 6 | 0 | 0 | 2 (net +115) | 1 (net +85) | 2 (net +150) | 0 | 1 | 40% (2 of 5) |
| Opponent | Warriors of Chaos | 1 | 0 | 0 | 0 | 0 | 1 (net +677) | 0 | 0 | 0% (0 of 1) |

### Charged fights, damage counted: h4-opp-bbe8617-p2

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 3 | 55 | 133 | +153 | 190 | 52 | +139 | +254.0 |
| Mine | 50-54% | 1 | 310 | 371 | +0 | 0 | 0 | +0 | +0.0 |
| Mine | Effective (55-75%) | 4 | 205 | 259 | -16 | 0 | 29 | -29 | -14.3 |
| Mine | 76-89% | 4 | 410 | 220 | +43 | 86 | 75 | +11 | +2.8 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 | 161 | 86 | +198 | 204 | 7 | +197 | +122.1 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 2 | 395 | 48 | +48 | 48 | 0 | +48 | +12.0 |
| Mine | All fights | 17 | 247 | 179 | +74 | 95 | 35 | +61 | +24.5 |
| Opponent | Long shot (under 50%) | 2 | 348 | 836 | -446 | 44 | 446 | -402 | -115.5 |
| Opponent | 50-54% | 1 | 195 | 322 | +195 | 195 | 0 | +195 | +100.0 |
| Opponent | Effective (55-75%) | 2 | 568 | 284 | +115 | 115 | 0 | +115 | +20.2 |
| Opponent | 76-89% | 3 | 370 | 164 | +20 | 179 | 132 | +47 | +12.7 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 | 244 | 82 | +61 | 61 | 0 | +61 | +24.9 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 4 | 606 | 121 | +264 | 264 | 4 | +259 | +42.8 |
| Opponent | No odds | 2 | 240 | 100 | +100 | 100 | 0 | +100 | +41.7 |
| Opponent | All fights | 17 | 398 | 235 | +61 | 146 | 77 | +69 | +17.4 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| h4-opp-bbe8617-p2 | move | 78 | 11 (14%) | 6 (8%) | 9 (12%) | 58 (74%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0108, L0123 |
| Charmed Shield | Opponent | L0224, L0325, L0427 |
| Elixir of Power | Opponent | L0411 |
| Fistful of Laurels | Opponent | L0618 |
| Horn of the Wild Hunt | Opponent | L0633 |
| Invocation of Nehek | Opponent | L0224, L0325, L0427 |
| Ring of Doom | Mine | L0207, L0224 |
| Ring of Doom | Opponent | L0411, L0633 |
| Ring of Jet | Opponent | L0411 |
| Standard of the Fell Warrior | Opponent | L0513 |
| Twice-Blessed Armour | Opponent | L0207 |
| Witch Hunter's Ward | Opponent | L0108, L0207, L0308 |

# Doctrine scorecard: h4-opp-bbe8617-p4

### Scorecard: h4-opp-bbe8617-p4

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0115 | 1 | 1 | Mine | yes | 2 | - | 1 | 2 | 0 | 0 | 0 | 0 |
| L0115 | 1 | 1 | Opponent | yes | 9 | 2 | 4 | 1 | 1 | 0 | 0 | 0 |
| L0132 | 6 | 1 | Mine | no | 7 | - | 0 | 1 | 0 | 0 | 0 | 0 |
| L0132 | 6 | 1 | Opponent | no | 1 | 4 | 3 | 5 | 0 | 0 | 0 | 340 |
| L0216 | 6 | 1 | Mine | no | 2 | 5 | 1 | 6 | 0 | 0 | 0 | 0 |
| L0216 | 6 | 1 | Opponent | no | 5 | 2 | 1 | 0 | 0 | 0 | 0 | 0 |
| L0232 | 4 | 1 | Mine | no | 2 | 5 | 2 | 3 | 1 | 0 | 0 | 170 |
| L0232 | 4 | 1 | Opponent | no | 0 | 2 | 3 | 3 | 0 | 0 | 0 | 170 |
| L0316 | 4 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 140 |
| L0316 | 4 | 1 | Opponent | no | 0 | 2 | 1 | 2 | 2 | 0 | 0 | 200 |
| L0333 | 3 | 1 | Mine | no | 5 | - | 1 | 0 | 0 | 0 | 0 | 0 |
| L0333 | 3 | 1 | Opponent | no | 4 | 2 | 3 | 3 | 0 | 0 | 0 | 0 |
| L0420 | 6 | 1 | Mine | no | 2 | 3 | 5 | 2 | 0 | 0 | 0 | 0 |
| L0420 | 6 | 1 | Opponent | no | 8 | - | 1 | 2 | 1 | 0 | 0 | 485 |
| L0435 | 3 | 1 | Mine | no | 4 | 4 | 0 | 1 | 0 | 0 | 0 | 0 |
| L0435 | 3 | 1 | Opponent | no | 4 | 4 | 3 | 1 | 0 | 0 | 0 | 0 |
| L0522 | 6 | 1 | Mine | no | 1 | 6 | 1 | 1 | 0 | 0 | 0 | 296 |
| L0522 | 6 | 1 | Opponent | no | 4 | 2 | 0 | 2 | 0 | 0 | 0 | 0 |
| L0609 | 3 | 1 | Mine | no | 10 | 5 | 1 | 2 | 0 | 0 | 0 | 230 |
| L0609 | 3 | 1 | Opponent | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 0 |
| L0625 | 1 | 1 | Mine | yes | 3 | 6 | 1 | 0 | 0 | 0 | 0 | 275 |
| L0625 | 1 | 1 | Opponent | no | 0 | 2 | 1 | 4 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 18% | 3.5 | 4.9 | 1.2 | 1.7 | 0.1 | 0.0 | 0.0 | 101.0 |
| **Average** | | | Opponent | 9% | 3.2 | 2.4 | 1.8 | 2.3 | 0.4 | 0.0 | 0.0 | 108.6 |

### KPIs: h4-opp-bbe8617-p4

Rules off - Mine only: HOLDER ASSIGNMENT, QUARTER ODDS.

Morten 2026-11-10; 11 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 40% (19 of 47) | 0% (0 of 59) | 18% (19 of 106) |
| Winner chose to follow up after the loser gave ground |  | 86% (12 of 14); on the table 93% | 67% (2 of 3); on the table 67% | 82% (14 of 17); on the table 88% |
| Winner chose to pursue after the loser fell back in good order |  | - | 50% (2 of 4); on the table 50% | 50% (2 of 4); on the table 50% |
| Winner chose to pursue after the loser fled |  | 0% (0 of 2); on the table 0% | 80% (8 of 10); on the table 90% | 67% (8 of 12); on the table 75% |
| Winner chose to follow up or pursue (all three) |  | 75% (12 of 16); on the table 81% | 71% (12 of 17); on the table 76% | 73% (24 of 33); on the table 79% |
| Magic missiles tried each own turn | 50%+ | 33% (44 of 132) | 43% (18 of 42) | 36% (62 of 174) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 42% (44 of 106) | 44% (18 of 41) | 42% (62 of 147) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 62% (5 of 8) | 68% (17 of 25) | 67% (22 of 33) |
| Points that never fought | lower | 48% (10451 of 21594) | 56% (12282 of 21995) | 52% (22733 of 43589) |
|   infantry points that never fought | lower | 46% (3143 of 6804) | 72% (3739 of 5211) | 57% (6882 of 12015) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 53% (43 of 81) | 59% (51 of 87) | 56% (94 of 168) |
| Bound items with a magic missile used (at least once a game) |  | 100% (6 of 6); 1.5 uses a game | 80% (4 of 5); 0.8 uses a game | 91% (10 of 11); 1.2 uses a game |
| Bound items with another spell used |  | 100% (2 of 2); 0.5 uses a game | 0.0 uses a game | 100% (2 of 2); 0.3 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 62% (5 of 8); 0.5 uses a game | 75% (3 of 4); 0.3 uses a game | 67% (8 of 12); 0.4 uses a game |
|   their share of the points of units over 100 pts | lower | 46% (7625 of 16500) | 53% (10234 of 19294) | 50% (17859 of 35794) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 3.9 (49%) | 1.3 (58%) | 5.2 (51%) |
| MARCHED: its unit marched | 1.4 (17%) | 0.8 (38%) | 2.2 (21%) |
| CHARGED: its unit charged | 0.2 (2%) | 0.0 (0%) | 0.2 (2%) |
| IN COMBAT: engaged in combat | 1.9 (24%) | 0.1 (4%) | 2.0 (20%) |
| GONE: slain | 0.5 (6%) | 0.0 (0%) | 0.5 (4%) |
| STUPIDITY: Stupidity | 0.2 (2%) | 0.0 (0%) | 0.2 (2%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 5.5 | 0.8 | 2.5 | 5.6 | 1.1 |
| not cast | 5.5 | 0.3 | 3.5 | 10.2 | 15.3 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (5%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.1 (33%) | 0.9 (26%) | 5.2 (51%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.2 (21%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (2%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.5 (10%) | 0.0 (0%) | 1.0 (28%) | 2.0 (20%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) |
| GONE: slain | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.5 (4%) | 0.2 (1%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.0 (0%) | 0.3 (8%) | 0.2 (2%) | 0.2 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.5 (8%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 4.5 (82%) | 0.2 (67%) | 1.4 (38%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 14.1 (92%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 2.4 a game | 0.6 a game | 1.5 a game |
| stood (cast and not dispelled) | 69% (18 of 26) | 50% (2 of 4) | 67% (20 of 30) |
| the unit moved after it | 67% (12 of 18) | 100% (2 of 2) | 70% (14 of 20) |
| it charged on its next turn | 0% (0 of 18) | 0% (0 of 2) | 0% (0 of 20) |
| the enemy charged it first | 28% (5 of 18) | 0% (0 of 2) | 25% (5 of 20) |
| it fought by the end of its next turn | 6% (1 of 18) | 0% (0 of 2) | 5% (1 of 20) |
| it moved out of a charge the enemy had planned (not charged first) | 22% (4 of 18) | 0% (0 of 2) | 20% (4 of 20) |
| none of these (no charge, no fight, no charge escaped) | 50% (9 of 18) | 100% (2 of 2) | 55% (11 of 20) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 60% (170 of 284) | 48% (133 of 280) | 54% (303 of 564) |
|   cavalry | 55% (12 of 22) | 53% (31 of 58) | 54% (43 of 80) |
|   character | 55% (12 of 22) | 25% (12 of 48) | 34% (24 of 70) |
|   chariot | 65% (31 of 48) | 76% (13 of 17) | 68% (44 of 65) |
|   infantry | 41% (28 of 68) | 54% (59 of 109) | 49% (87 of 177) |
|   monster | 67% (8 of 12) | 50% (3 of 6) | 61% (11 of 18) |
|   war machine | 71% (79 of 112) | 36% (15 of 42) | 61% (94 of 154) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 3.5 (33%) | 3.2 (24%) | 6.6 (28%) |
| CHARGED: it charged | 0.5 (5%) | 2.4 (18%) | 2.9 (12%) |
| FLEEING: it fled or was fleeing | 0.0 (0%) | 0.1 (1%) | 0.1 (0%) |
| IN COMBAT: it fought this turn or the last | 0.5 (4%) | 0.0 (0%) | 0.5 (2%) |
| MOVED: a war machine that moved | 1.3 (12%) | 1.3 (10%) | 2.5 (11%) |
| NO TARGET IN RANGE | 2.2 (21%) | 3.1 (23%) | 5.3 (22%) |
| ONLY IN COMBAT: the only targets were in combat | 0.2 (2%) | 0.3 (2%) | 0.5 (2%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 2.2 (21%) | 2.6 (20%) | 4.8 (20%) |
| SHELTERED: the target was sheltered | 0.0 (0%) | 0.4 (3%) | 0.4 (2%) |
| OTHER BAR | 0.1 (1%) | 0.1 (1%) | 0.2 (1%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 4.5 | 1.1 | 84% | 2.8 pts | 12 pts |
| character | 2.5 | 1.4 | 78% | 9.5 pts | 23 pts |
| chariot | 4.0 | 3.1 | 59% | 22.8 pts | 91 pts |
| infantry | 10.6 | 3.5 | 75% | 5.4 pts | 57 pts |
| monster | 1.3 | 0.2 | 86% | 1.2 pts | 1 pts |
| war machine | 8.5 | 6.2 | 66% | 16.9 pts | 145 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 2.1 | 4.6 | 3.4 |
| Charges that made contact a game | 1.5 | 3.7 | 2.6 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.40 declared, 0.40 contact (5 units) | 0.00 declared, 0.00 contact (3 units) | 0.25 declared, 0.25 contact (8 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | - | - |
|   per unit a game, the other units (no war machines, no joined characters) | 0.27 declared, 0.19 contact (77 units) | 0.53 declared, 0.42 contact (97 units) | 0.41 declared, 0.32 contact (174 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 36% (5 of 14) | 50% (1 of 2) | 100% (1 of 1) | 41% (7 of 17) |
| Character in a unit | 94% (16 of 17) | 55% (6 of 11) | - | 79% (22 of 28) |
| Character on its own | 100% (3 of 3) | 29% (2 of 7) | 31% (5 of 16) | 38% (10 of 26) |
| Chariot | 0% (0 of 1) | 56% (5 of 9) | - | 50% (5 of 10) |
| Infantry | 43% (13 of 30) | 35% (7 of 20) | - | 40% (20 of 50) |
| Monster | 90% (9 of 10) | 50% (1 of 2) | - | 83% (10 of 12) |
| Monstrous | 80% (4 of 5) | 100% (1 of 1) | - | 83% (5 of 6) |
| War Machines | 82% (14 of 17) | 50% (1 of 2) | - | 79% (15 of 19) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 60% (3 of 5); on the table 60% | 34% (35 of 102) | 42% | 55% (12 of 22) | 100% (6 of 6); 4.2 uses a game | 100% (2 of 2); 1.5 uses a game | 67% (4 of 6); 1.0 uses a game |
| Chaos Dwarfs | 4 | 86% (6 of 7); on the table 100% | 30% (9 of 30) | 52% | 47% (15 of 32) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
| Dwarfen Mountain Holds | 3 | 75% (3 of 4); on the table 75% | - | 53% | 59% (16 of 27) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 1 | - | 58% (7 of 12) | 95% | 67% (8 of 12) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| High Elf Realms | 1 | 100% (1 of 1); on the table 100% | 17% (1 of 6) | 42% | 43% (3 of 7) | 100% (2 of 2); 4.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 2 | - | - | 72% | 42% (5 of 12) | 0.0 uses a game | 0.0 uses a game | 100% (2 of 2); 1.0 uses a game |
| Skaven | 1 | 67% (2 of 3); on the table 67% | 33% (2 of 6) | 46% | 57% (4 of 7) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Tomb Kings of Khemri | 1 | 100% (2 of 2); on the table 100% | - | 58% | 60% (3 of 5) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 1 | 67% (2 of 3); on the table 100% | 67% (4 of 6) | 54% | 67% (4 of 6) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 2 | 67% (2 of 3); on the table 67% | - | 48% | 50% (8 of 16) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 2 | 60% (3 of 5); on the table 60% | 33% (4 of 12) | 40% | 73% (16 of 22) | 67% (2 of 3); 2.5 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (h4-opp-bbe8617-p4, 11 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 48% (14) | 54% (7) | 50% (21) |
| ...free all their last turn and able to turn (per game) | 0.73 | 0.27 | 1.00 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.45 | 0.18 | 0.64 |
| ...with the charger already in that arc before they moved (per game) | 0.55 | 0.27 | 0.82 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.09 | 0.18 | 0.27 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.09 | 0.18 | 0.27 |

### Quality by phase: h4-opp-bbe8617-p4

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.1 | 1.9 |
| Strategy | Charge objectives carried out (made contact) | 39% (7 of 18) | 56% (25 of 45) |
| Strategy | Shoot objectives carried out (shot that target) | 46% (57 of 125) | 43% (28 of 65) |
| Strategy | Support requests answered (helper made contact too) | 100% (2 of 2) | 50% (2 of 4) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (3 of 3) | - |
| Strategy | Hexes on a unit its side charged or shot that turn | - | 50% (4 of 8) |
| Strategy | Joined characters whose unit fought | 55% (17 of 31) | 12% (2 of 16) |
| Strategy | Lone characters that fought | 69% (11 of 16) | 71% (15 of 21) |
| Movement | Charges halted short of contact | 0.1 | 0.4 |
| Movement | Idle units | 1.7 | 2.3 |
| Movement | Points that never moved of their own | 101.0 | 108.6 |
| Movement | Fights charged into per game | 1.4 | 3.3 |
| Movement | Charges with odds: long shots (under 50%) | 2 of 14, net -36 | 10 of 32, net +31 |
| Movement | Charges with odds: sweet spot (55-75%) | 1 of 14, net +0 | 8 of 32, net +41 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 14 | 5 of 32, net +196 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 7 of 14, net +103 | 5 of 32, net +78 |
| Shooting | Shots by shooting units (incl. breath weapons) | 9.0 | 12.2 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 40% (40 of 99) | 42% (56 of 134) |
| Shooting | Points destroyed by shooting units | 35.6 | 18.9 |
| Shooting | War machine shots | 7.2 | 1.4 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 46% (36 of 79) | 27% (4 of 15) |
| Shooting | Points destroyed by war machines | 62.3 | 32.3 |
| Magic | Magic missiles cast | 2.5 | 0.8 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 30% (8 of 27) | 22% (2 of 9) |
| Magic | Wounds caused by magic missiles | 6.5 | 2.0 |
| Magic | Wounds caused by other spells | 0.2 | - |
| Magic | Points destroyed by magic (all spells) | 149.2 | 10.2 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.8 / 0.0 / 0.8 / 0.0 | 2.2 / 0.7 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 107.5 | 207.1 |
| Combat | Points run down | 61.4 | 74.2 |
| Combat | Net points per charged fight, damage counted | +68 | +65 |
| Combat | Net per 100 charger points, damage counted | +28.3 | +20.1 |
| Combat | First round won (charged fights) | 80% | 75% |
| Combat | Net points per charged fight | +64 | +74 |
| Combat | Net points per supported fight / lone fight | +49 / +66 | +174 / +58 |
| Combat | Charged fights on a top-3 enemy unit | 8 of 15 | 12 of 36 |
| Game | Points lost | 404.1 | 480.6 |
| Game | VP from objectives | 643.6 | 710.9 |
| Game | Lone holders (player turns) | 3.5 | 3.2 |

- Mine won / drew / lost: 4 / 4 / 3 of 11 ended games (of 11); mean margin (Mine - Opponent) -26 VP
- The side that went first won 1 of 7 games with a winner
- Points traded per game (both sides' losses): 885
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: h4-opp-bbe8617-p4

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.5 | +0.0 | 0.0 | 0.0 | 0.5 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.1 | +1.3 | 0.0 | 0.0 | 0.2 | +35.2 | 0.0 | 19.1 |
| ALREADY CARRIED | 0.2 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARTILLERY RE-ROLL WEIGHED | 1.5 | +0.0 | 0.0 | 42.7 | 0.2 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | 0.3 | +1.7 | 0.0 | 0.0 | 0.1 | +0.6 | 0.0 | 0.0 |
| BEST PRIZE | - | - | - | - | 0.3 | -31.2 | 4.7 | 0.0 |
| BLOWS WHERE AIMED | - | - | - | - | 0.3 | -89.0 | 0.0 | 44.5 |
| CANNON PLAN MISSED | 0.7 | +0.0 | 42.9 | 34.1 | 0.1 | +0.0 | 10.5 | 0.0 |
| CANNON PLANNED TARGET | 5.9 | +48.7 | 221.8 | 122.7 | 1.3 | +31.1 | 33.6 | 0.0 |
| CANNON SIGHT KEPT | 1.6 | +0.0 | 0.0 | 10.9 | 0.5 | +0.0 | 0.0 | 0.0 |
| CAST JOB | 0.1 | +6.4 | 49.1 | 0.0 | 0.4 | +1.5 | 0.0 | 0.0 |
| CASTER AWAY FROM SCREEN | 0.6 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.5 | +39.0 | 60.5 | 0.0 | 0.1 | +3.1 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 1.5 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | - | - | - | - | 0.2 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | 0.4 | +13.7 | 0.0 | 7.7 | 0.5 | +12.9 | 0.0 | 3.5 |
| CHAFF PASSED | 0.4 | -1.1 | 0.0 | 0.0 | 0.3 | -0.0 | 0.0 | 0.0 |
| CHARACTER GUNS | 0.2 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| CHARGE LOSSES | 6.4 | -224.5 | 0.0 | 81.5 | 5.5 | -237.8 | 0.0 | 93.6 |
| CHARGE NOT DECLARED | - | - | - | - | 0.7 | +0.0 | 18.4 | 53.7 |
| CHARGE NOW FIRST | 0.5 | +0.0 | 87.3 | 30.8 | 2.3 | +0.0 | 150.1 | 224.7 |
| CHARGER SLAIN LOST | 0.3 | -19.5 | 19.1 | 10.2 | 0.3 | -0.6 | 27.8 | 27.9 |
| CHEAP HELPER | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHEAPEST HOLDER | 0.4 | -14.9 | 0.0 | 0.0 | - | - | - | - |
| COMBAT PIVOT | 0.1 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 68.2 |
| CONVEYANCE SEARCH | 1.6 | +332.6 | 0.0 | 0.0 | 0.3 | +5.1 | 0.0 | 0.0 |
| COVER ONCE | 8.7 | -733.9 | 0.0 | 76.5 | 4.2 | -210.0 | 0.0 | 91.9 |
| DEFENSIVE FLOOR | 0.1 | -1.2 | 39.3 | 0.0 | - | - | - | - |
| DEPLOY BY FIGURES | 9.5 | +35.6 | 0.0 | 10.9 | 7.9 | +43.9 | 0.0 | 2.7 |
| EDGE GIVE GROUND | 0.1 | +0.1 | 0.0 | 0.0 | 0.1 | +0.5 | 12.7 | 0.0 |
| ENGINEER BY LORE | 0.4 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 0.1 | +0.9 | 0.0 | 0.0 | 0.2 | +14.3 | 0.0 | 0.0 |
| FALL BACK GOOD ORDER | 1.2 | +9.3 | 135.8 | 35.5 | 2.5 | +1.9 | 151.9 | 205.5 |
| FALLBACK BY WORTH | 0.5 | +0.0 | 0.0 | 15.4 | 0.1 | +0.0 | 0.0 | 0.0 |
| FALLS SHORT | 3.8 | +57.3 | 0.0 | 12.1 | 22.2 | +316.7 | 0.0 | 189.4 |
| FEATURE BUFFS | 3.6 | +80.8 | 0.0 | 22.5 | 0.3 | +15.7 | 0.0 | 0.0 |
| FIGHT LIFT | - | - | - | - | 0.3 | +1.0 | 39.3 | 0.0 |
| FIGHT TO THE END | 0.3 | +22.6 | 38.2 | 0.0 | 2.0 | +56.8 | 97.1 | 218.5 |
| FIRE IN ORDER | 0.2 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FIVE ACTION | 47.7 | +2524.6 | 683.9 | 510.5 | 50.4 | +3512.1 | 428.1 | 649.8 |
| FLANK NOT WEIGHED | 8.5 | +0.0 | 0.0 | 55.2 | 5.1 | +0.0 | 0.0 | 116.5 |
| FOLLOW UP WEIGHED | 0.8 | +126.3 | 0.0 | 30.8 | 0.4 | +64.2 | 0.0 | 0.0 |
| FOUR ROUNDS | 1.6 | +119.2 | 166.1 | 45.7 | 3.8 | +355.9 | 264.1 | 264.1 |
| FRIEND CHARGES FIRST | - | - | - | - | 0.3 | -6.7 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 0.5 | -9.8 | 0.0 | 0.0 | 0.2 | -7.4 | 0.0 | 0.0 |
| FRIENDS SHOTS CHECKED | - | - | - | - | 0.1 | +1.5 | 0.0 | 0.0 |
| GIVES UP | - | - | - | - | 0.3 | -3.4 | 18.2 | 0.0 |
| GUN FIGURES | 2.1 | +14.8 | 99.3 | 10.5 | 0.6 | +0.9 | 16.4 | 0.0 |
| GUN MASK | 0.9 | +19.0 | 0.0 | 0.0 | 0.4 | +26.2 | 0.0 | 7.3 |
| HARD STAY DROPPED | 1.6 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HE SHOOTS OR CHARGES | 2.5 | +0.0 | 0.0 | 36.9 | 2.3 | +0.0 | 0.0 | 77.1 |
| HELPER ALREADY ASKED | - | - | - | - | 0.1 | +0.0 | 0.0 | 9.3 |
| HELPER UNSEEN | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE DENIED | 0.1 | +2.5 | 0.0 | 0.0 | 0.5 | +29.0 | 48.0 | 0.0 |
| HIS CHARGE LIST | 2.9 | +0.0 | 0.0 | 18.9 | 2.7 | +0.0 | 0.0 | 11.5 |
| HIS LEGAL MOVES | 3.6 | +0.0 | 0.0 | 16.9 | 3.6 | +0.0 | 0.0 | 22.9 |
| HIS MOVE AND SHOT | 2.5 | -22.4 | 0.0 | 22.3 | 1.7 | -93.8 | 0.0 | 18.2 |
| HIS RANDOM MOVE | 3.1 | +0.0 | 0.0 | 43.0 | 1.5 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 20.0 | +617.8 | 0.0 | 188.1 | 25.9 | +1211.3 | 0.0 | 164.0 |
| HIS TURN DENIED | 0.3 | +3.4 | 49.1 | 0.0 | 2.7 | +161.8 | 184.6 | 212.0 |
| HOLD ODDS | - | - | - | - | 9.6 | +0.0 | 0.0 | 55.5 |
| HOLDER ASSIGNMENT | - | - | - | - | 17.5 | +1631.9 | 0.0 | 55.5 |
| HOLDER AT DEPLOYMENT | 1.4 | +216.3 | 0.0 | 0.0 | - | - | - | - |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.5 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 1.3 | -32.2 | 107.7 | 35.5 | 3.3 | -204.6 | 213.9 | 249.9 |
| HUNT IN PAIRS | 0.4 | +7.5 | 0.0 | 0.0 | 0.2 | +7.5 | 0.0 | 17.7 |
| HUNT RESULT | - | - | - | - | 0.1 | +17.3 | 0.0 | 4.1 |
| HUNT THE GUNS | - | - | - | - | 0.1 | +19.6 | 10.5 | 0.0 |
| IDLE COST | 0.7 | -3.2 | 0.0 | 0.0 | 12.8 | -174.9 | 0.0 | 133.4 |
| JOINT KNOWS CHALLENGE | - | - | - | - | 0.3 | -2.6 | 59.9 | 2.7 |
| KEEP FALLS | 0.1 | +0.5 | 0.0 | 0.0 | - | - | - | - |
| KEEPS SCOUTS OR AMBUSH | 0.2 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| LANE BY FIGURES | 0.4 | +10.1 | 0.0 | 0.0 | 1.0 | +34.8 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 5.0 | +0.0 | 182.4 | 92.7 | 5.2 | +0.0 | 149.9 | 163.0 |
| LONE WIZARD KEPT IN | 0.9 | +59.1 | 0.0 | 0.0 | 0.6 | +44.2 | 0.0 | 0.0 |
| LONG SHOT | 0.4 | +4.4 | 3.5 | 0.0 | 0.2 | -5.5 | 0.0 | 11.5 |
| LURE BY WHAT IT DRAWS | - | - | - | - | 0.3 | -6.2 | 0.0 | 3.2 |
| MAKE SURE TOGETHER | 0.1 | +0.4 | 0.0 | 0.0 | 0.5 | +3.9 | 0.0 | 7.3 |
| MANOEUVRE | 1.4 | +13.3 | 0.0 | 0.0 | 1.5 | +11.0 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.3 | +0.0 | 0.0 | 0.0 | 0.4 | +1.3 | 0.0 | 0.0 |
| MARCH BY THE SUM | 0.3 | +30.3 | 0.0 | 0.0 | 0.6 | +40.3 | 0.0 | 0.0 |
| MARCH CHECK | 1.0 | +81.5 | 0.0 | 22.1 | 1.3 | +81.9 | 0.0 | 0.0 |
| MARCH OVER CASTS | 0.3 | +1.3 | 0.0 | 0.0 | 0.8 | -10.1 | 0.0 | 49.1 |
| MAX FOR POSITIONING | 6.9 | +99.4 | 0.0 | 65.9 | 4.5 | +67.6 | 0.0 | 107.0 |
| MISSILES IN THE MOVE | 3.6 | +236.7 | 0.0 | 29.8 | 2.5 | +17.4 | 0.0 | 49.1 |
| MISSILES NEXT TURN | 4.5 | +173.8 | 0.0 | 37.5 | 4.0 | +21.6 | 0.0 | 68.0 |
| MODEL FACING | 1.0 | +264.6 | 0.0 | 10.9 | - | - | - | - |
| MOVE SPELL IN RANGE | 0.8 | +42.6 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 1.3 | -54.2 | 0.0 | 0.0 | 0.5 | -25.8 | 0.0 | 0.0 |
| MOVE SPELL SPOT | 0.9 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 3.2 | +450.5 | 0.0 | 10.2 | 4.1 | +509.9 | 0.0 | 50.2 |
| MOVES UNITS SPELL | 0.2 | +10.0 | 0.0 | 0.0 | 0.1 | +0.7 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 4.7 | +268.1 | 0.0 | 44.1 | 7.1 | +287.5 | 0.0 | 55.5 |
| NEXT CHARGE BY LIST | 4.8 | -179.1 | 52.5 | 21.1 | 6.1 | -318.2 | 0.0 | 72.2 |
| NEXT OBJECTIVE NEARER | 6.1 | -268.0 | 62.2 | 77.7 | 0.1 | -0.2 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 1.3 | -71.3 | 107.7 | 35.5 | 3.1 | -97.3 | 201.4 | 264.1 |
| NOT TURNED | 0.1 | -0.0 | 0.0 | 7.6 | 0.2 | +0.0 | 0.0 | 3.2 |
| NOT WORTH A CAST | 0.4 | -0.2 | 0.0 | 0.0 | 0.5 | -0.5 | 0.0 | 0.0 |
| OFF BEST | 0.7 | -7.6 | 0.0 | 0.0 | 0.5 | -20.2 | 0.0 | 0.0 |
| ONE CHARGE A CHARGER | 3.6 | +0.0 | 0.0 | 45.9 | 2.3 | +0.0 | 0.0 | 51.1 |
| ONE FIGHT FORMULA | 5.6 | -68.4 | 0.0 | 68.3 | 5.3 | -124.2 | 0.0 | 159.8 |
| ONE OBJECTIVE FORMULA | 4.5 | +68.7 | 0.0 | 57.4 | 3.5 | +45.8 | 0.0 | 19.7 |
| ONE TARGET A SHOOTER | 15.9 | +307.3 | 0.0 | 114.1 | 20.3 | +537.7 | 0.0 | 188.0 |
| OPENS A LANE | - | - | - | - | 0.1 | +3.1 | 0.0 | 0.0 |
| OVERRUNS AWAY | 0.3 | +3.2 | 0.0 | 4.7 | 0.4 | +9.2 | 33.8 | 42.8 |
| PATHS CROSS | 3.5 | +178.5 | 0.0 | 52.5 | 5.5 | +242.9 | 0.0 | 7.3 |
| PERIAPT WORTH | - | - | - | - | 0.1 | +4.9 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | - | - | - | - | 0.3 | -7.5 | 0.0 | 49.1 |
| PLAN RESULT | 42.0 | +1004.9 | 243.5 | 507.5 | 44.7 | +471.7 | 77.1 | 854.2 |
| PURSUES BIG PREY | - | - | - | - | 0.3 | -8.9 | 0.0 | 0.0 |
| QUARTER ODDS | - | - | - | - | 4.5 | +711.0 | 41.3 | 53.6 |
| RANDOM MOVE BY FIGURES | 0.7 | +12.3 | 0.0 | 30.9 | 2.3 | +26.4 | 0.0 | 50.0 |
| REDIRECT BY WHAT IT STOPS | 0.3 | -0.9 | 0.0 | 15.4 | 0.2 | +1.2 | 0.0 | 3.5 |
| REDIRECT COUNTER | 2.5 | +281.2 | 0.0 | 37.8 | 3.5 | +93.0 | 0.0 | 50.6 |
| REDIRECT WEIGHED | 0.2 | +0.0 | 0.0 | 0.0 | 0.3 | -30.0 | 0.0 | 42.8 |
| REFORMS TO MEET IT | 0.7 | -8.5 | 0.0 | 0.0 | 0.4 | -67.4 | 0.0 | 0.0 |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | 0.2 | +44.5 | 0.0 | 0.0 | 1.0 | +40.5 | 0.0 | 14.5 |
| RESTRAINS TO SHOOT | 0.1 | +0.9 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | 1.2 | +8.6 | 104.3 | 45.7 | 2.2 | +58.0 | 145.4 | 219.6 |
| RISK BY HIS FIGURE | 14.3 | -178.7 | 0.0 | 108.9 | 12.2 | -142.6 | 0.0 | 189.2 |
| RUN DOWN | 0.9 | -6.6 | 42.7 | 35.5 | 2.5 | -13.9 | 176.8 | 264.1 |
| SAME CHARGE LATER | 0.3 | -12.9 | 49.1 | 0.0 | 0.1 | -2.1 | 0.0 | 0.0 |
| SCOUT SPOT | 0.1 | +0.0 | 0.0 | 0.0 | 0.4 | +0.4 | 0.0 | 0.0 |
| SCOUT WAITS | 0.1 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.1 | -14.6 | 0.0 | 0.0 | 0.1 | -6.2 | 0.0 | 0.0 |
| SEARCH SPOT | 5.3 | +198.6 | 0.0 | 87.2 | 5.4 | +196.6 | 0.0 | 57.1 |
| SELF MOVE SPELL | - | - | - | - | 0.5 | +31.4 | 0.0 | 0.0 |
| SET UP TOGETHER | 0.1 | +0.4 | 0.0 | 0.0 | 0.5 | +4.2 | 0.0 | 7.3 |
| SET-UP ANY TARGET | 0.3 | +49.6 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | 0.5 | +1.1 | 0.0 | 0.0 | 0.5 | +0.8 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.6 | +79.9 | 117.5 | 0.0 | 1.5 | +12.0 | 29.8 | 19.5 |
| SHORT GUN FORWARD | 0.5 | +0.0 | 0.0 | 10.9 | - | - | - | - |
| SHOT OR CHARGE | 0.1 | -1.3 | 3.5 | 0.0 | 0.4 | -6.7 | 47.7 | 0.0 |
| SHOT RISK POINTS | 11.0 | +178.3 | 0.0 | 126.9 | 16.7 | +21.6 | 0.0 | 246.3 |
| SHOTS IN THE MOVE | 15.5 | +418.0 | 0.0 | 277.5 | 14.5 | +301.0 | 0.0 | 85.1 |
| SPELL SETS UP CHARGE | 0.5 | +102.0 | 0.0 | 0.0 | - | - | - | - |
| SPELL WORTH | 0.9 | +10.6 | 0.0 | 0.0 | 2.5 | +49.4 | 144.7 | 98.2 |
| SPELLS IN THE FIGHT | 0.2 | +1.0 | 58.4 | 0.0 | 0.1 | -1.1 | 0.0 | 0.0 |
| STAND AND SHOOT | 0.1 | -0.6 | 0.0 | 0.0 | 0.4 | -5.3 | 33.3 | 0.0 |
| STANDS FOR A REASON | - | - | - | - | 1.3 | +0.0 | 10.3 | 7.3 |
| STANDS STILL | 21.5 | +0.0 | 517.8 | 280.8 | 12.1 | +0.0 | 147.1 | 75.4 |
| STAY WORTH | 17.7 | +5.9 | 297.4 | 237.2 | 14.9 | +106.4 | 108.6 | 68.8 |
| STOPS | - | - | - | - | 0.1 | +0.2 | 10.5 | 0.0 |
| STUCK PIVOT | 0.2 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| SUPPORT NARROWED | 0.5 | +0.0 | 41.6 | 41.0 | 1.1 | +0.0 | 90.1 | 93.0 |
| SURE REACH TOGETHER | - | - | - | - | 0.4 | +1.0 | 0.0 | 25.2 |
| THE DEARER SUM KEEPS ITS PLAN | 4.0 | +0.0 | 0.0 | 69.5 | 5.7 | +0.0 | 0.0 | 7.3 |
| THE PROMISE ADDS | - | - | - | - | 0.2 | -33.0 | 26.3 | 0.0 |
| THE PROMISED MOVE | 0.2 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| TIED UP BY THE SUM | 0.2 | +20.8 | 19.1 | 30.8 | 0.6 | +56.2 | 52.2 | 42.8 |
| TIME ON OUR SIDE | 32.5 | +509.9 | 3.2 | 216.7 | 3.9 | +67.7 | 0.0 | 53.5 |
| WAITS AGAIN | 1.1 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 7.3 |
| WAR ENGINE JOBS | 0.5 | +0.0 | 26.0 | 0.0 | - | - | - | - |
| WHO HITS BACK | 0.2 | +14.6 | 0.0 | 0.0 | 0.4 | +80.9 | 0.0 | 9.3 |
| WHOLE FIGHT | 0.3 | +5.4 | 58.4 | 10.2 | 0.1 | +7.7 | 15.5 | 0.0 |
| WHOLE FIGHT GAIN | - | - | - | - | 0.4 | +42.8 | 24.3 | 12.0 |
| WIDER SPREAD | 1.3 | -4.4 | 162.6 | 45.7 | 3.2 | -7.3 | 211.5 | 135.9 |
| WOUNDED STAYS OUT | 0.1 | +0.0 | 19.1 | 0.0 | - | - | - | - |
| WOUNDS ON THE RANKS | 2.5 | +69.6 | 0.0 | 26.3 | 1.5 | +56.4 | 0.0 | 0.0 |

### Rule changes: h4-opp-bbe8617-p4

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HOLDER ASSIGNMENT | 192 | 192 | 181 | 16.45 | +8824 | +48.8 |
| HIS SHOT LIST | 505 | 505 | 154 | 14.00 | +3961 | +25.7 |
| DEPLOY BY FIGURES | 192 | 192 | 113 | 10.27 | +1413 | +12.5 |
| LEGAL CHARGES ONLY | 112 | 112 | 112 | 10.18 | +0 | +0.0 |
| SEARCH SPOT | 117 | 117 | 112 | 10.18 | +4347 | +38.8 |
| PATHS CROSS | 100 | 100 | 100 | 9.09 | +4636 | +46.4 |
| ONE TARGET A SHOOTER | 398 | 398 | 87 | 7.91 | +1246 | +14.3 |
| TIME ON OUR SIDE | 401 | 358 | 70 | 6.36 | +176 | +2.5 |
| FIVE ACTION | 1079 | 1079 | 46 | 4.18 | +3032 | +65.9 |
| MOVE TO CHARGE COMPUTED | 80 | 80 | 44 | 4.00 | +4351 | +98.9 |
| SHOT RISK POINTS | 305 | 305 | 41 | 3.73 | +1329 | +32.4 |
| COVER ONCE | 142 | 115 | 37 | 3.36 | +762 | +20.6 |
| MAX FOR POSITIONING | 126 | 122 | 36 | 3.27 | +98 | +2.7 |
| FALLS SHORT | 286 | 262 | 31 | 2.82 | +96 | +3.1 |
| FOUR ROUNDS | 60 | 60 | 26 | 2.36 | +1247 | +48.0 |
| HARD STAY DROPPED | 26 | 26 | 26 | 2.36 | +0 | +0.0 |
| REDIRECT COUNTER | 66 | 57 | 25 | 2.27 | +1994 | +79.8 |
| CANNON SIGHT KEPT | 24 | 24 | 24 | 2.18 | +0 | +0.0 |
| SHOOTS FROM THE BEST SPOT | 34 | 34 | 24 | 2.18 | +298 | +12.4 |
| SHOTS IN THE MOVE | 331 | 306 | 24 | 2.18 | +574 | +23.9 |
| RANDOM MOVE BY FIGURES | 33 | 33 | 22 | 2.00 | +426 | +19.4 |
| ARTILLERY RE-ROLL WEIGHED | 19 | 19 | 19 | 1.73 | +0 | +0.0 |
| IDLE COST | 149 | 117 | 17 | 1.55 | +118 | +7.0 |
| LONE WIZARD KEPT IN | 17 | 17 | 17 | 1.55 | +1136 | +66.8 |
| MARCH CHECK | 25 | 25 | 16 | 1.45 | +429 | +26.8 |
| LANE BY FIGURES | 15 | 15 | 15 | 1.36 | +494 | +32.9 |
| NEXT CHARGE BY LIST | 120 | 120 | 15 | 1.36 | +340 | +22.7 |
| MANOEUVRE | 31 | 31 | 14 | 1.27 | +294 | +21.0 |
| OFF BEST | 14 | 14 | 14 | 1.27 | -306 | -21.8 |
| FOLLOW UP WEIGHED | 13 | 13 | 13 | 1.18 | +2095 | +161.2 |
| RESERVE FALL BACK | 13 | 13 | 13 | 1.18 | +934 | +71.9 |
| ADVANCE LANE KEPT | 12 | 12 | 12 | 1.09 | +0 | +0.0 |
| CHARGE LOSSES | 130 | 130 | 12 | 1.09 | +455 | +37.9 |
| NEXT OBJECTIVE NEARER | 68 | 68 | 12 | 1.09 | +59 | +4.9 |
| CANNON PLANNED TARGET | 79 | 79 | 11 | 1.00 | -244 | -22.2 |
| MODEL FACING | 11 | 11 | 11 | 1.00 | +2910 | +264.6 |
| SHOOTERS IN TWO RANKS | 11 | 11 | 11 | 1.00 | +21 | +1.9 |
| MARCH BY THE SUM | 10 | 10 | 10 | 0.91 | +777 | +77.7 |
| QUARTER ODDS | 49 | 49 | 10 | 0.91 | +1100 | +110.0 |
| RISK BY HIS FIGURE | 291 | 291 | 10 | 0.91 | +473 | +47.3 |
| WOUNDS ON THE RANKS | 45 | 45 | 10 | 0.91 | +150 | +15.0 |
| CASTER AWAY FROM SCREEN | 9 | 9 | 9 | 0.82 | +0 | +0.0 |
| FEATURE BUFFS | 43 | 43 | 9 | 0.82 | +181 | +20.1 |
| HIS TURN DENIED | 33 | 33 | 9 | 0.82 | +347 | +38.5 |
| HOLDS AMBUSHERS | 9 | 9 | 9 | 0.82 | +0 | +0.0 |
| RISK BY ARC | 37 | 37 | 9 | 0.82 | +208 | +23.1 |
| CHARGE NOT DECLARED | 8 | 8 | 8 | 0.73 | -2013 | -251.6 |
| HOLDER AT DEPLOYMENT | 15 | 15 | 8 | 0.73 | +507 | +63.4 |
| CHAFF PASSED | 7 | 7 | 7 | 0.64 | -13 | -1.9 |
| NEARER NOT NEEDED | 130 | 127 | 7 | 0.64 | +476 | +68.0 |
| STAY WORTH | 359 | 339 | 7 | 0.64 | +34 | +4.8 |
| TIED UP BY THE SUM | 9 | 9 | 7 | 0.64 | +238 | +34.0 |
| CHARGE NOW FIRST | 30 | 30 | 6 | 0.55 | -310 | -51.6 |
| MISSILES IN THE MOVE | 67 | 54 | 6 | 0.55 | +123 | +20.4 |
| SHORT GUN FORWARD | 6 | 6 | 6 | 0.55 | +0 | +0.0 |
| WHO HITS BACK | 6 | 6 | 6 | 0.55 | +752 | +125.3 |
| CHAFF IN THE MOVE | 9 | 8 | 5 | 0.45 | +14 | +2.7 |
| COMBAT PIVOT | 5 | 5 | 5 | 0.45 | +0 | +0.0 |
| ONE OBJECTIVE FORMULA | 88 | 77 | 5 | 0.45 | +162 | +32.3 |
| REDIRECT WEIGHED | 5 | 5 | 5 | 0.45 | -573 | -114.5 |
| SCOUT WAITS | 5 | 5 | 5 | 0.45 | +0 | +0.0 |
| CAST JOB | 5 | 5 | 4 | 0.36 | +42 | +10.6 |
| CASTING BLOCK | 7 | 7 | 4 | 0.36 | +43 | +10.8 |
| FIGHT TO THE END | 25 | 25 | 4 | 0.36 | +117 | +29.2 |
| ONE FIGHT FORMULA | 120 | 66 | 4 | 0.36 | +65 | +16.3 |
| STUCK PIVOT | 4 | 4 | 4 | 0.36 | +0 | +0.0 |
| AFTERMATH IN POINTS | 3 | 3 | 3 | 0.27 | +401 | +133.7 |
| BEST PRIZE | 3 | 3 | 3 | 0.27 | -1043 | -347.6 |
| FACES THE THREAT | 3 | 3 | 3 | 0.27 | +168 | +55.8 |
| GUN MASK | 14 | 14 | 3 | 0.27 | +44 | +14.8 |
| MISSILES NEXT TURN | 93 | 68 | 3 | 0.27 | +46 | +15.4 |
| MOVES UNITS SPELL | 3 | 3 | 3 | 0.27 | +118 | +39.2 |
| PIVOT GUARDS FLANK | 3 | 3 | 3 | 0.27 | -82 | -27.3 |
| PURSUES BIG PREY | 3 | 3 | 3 | 0.27 | -98 | -32.8 |
| WHOLE FIGHT GAIN | 4 | 4 | 3 | 0.27 | +145 | +48.2 |
| CASTS FROM BEHIND | 2 | 2 | 2 | 0.18 | +0 | +0.0 |
| FALL BACK GOOD ORDER | 41 | 41 | 2 | 0.18 | +7 | +3.5 |
| FIRE IN ORDER | 2 | 2 | 2 | 0.18 | +0 | +0.0 |
| HIS CHARGE DENIED | 6 | 6 | 2 | 0.18 | +68 | +34.2 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.18 | +0 | +0.0 |
| OVERRUNS AWAY | 7 | 7 | 2 | 0.18 | +11 | +5.7 |
| SUPPORT NARROWED | 17 | 17 | 2 | 0.18 | -8 | -4.0 |
| WHOLE FIGHT | 4 | 4 | 2 | 0.18 | +51 | +25.4 |
| WIDER SPREAD | 49 | 49 | 2 | 0.18 | +2 | +1.2 |
| FRIENDS SHOTS CHECKED | 1 | 1 | 1 | 0.09 | +16 | +16.2 |
| HIS MOVE AND SHOT | 47 | 47 | 1 | 0.09 | +15 | +15.0 |
| HONEST WORTH | 50 | 50 | 1 | 0.09 | +13 | +12.7 |
| KEEP FALLS | 1 | 1 | 1 | 0.09 | +22 | +21.9 |
| LONG SHOT | 6 | 6 | 1 | 0.09 | +33 | +33.1 |
| MOVE SPELL IN RANGE | 9 | 3 | 1 | 0.09 | +56 | +55.9 |
| NO DOUBLE ROUNDS | 48 | 48 | 1 | 0.09 | +59 | +58.7 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.09 | +54 | +54.4 |
| REFUSING RETIRES | 5 | 5 | 1 | 0.09 | -1 | -0.8 |
| RESTRAINS TO SHOOT | 1 | 1 | 1 | 0.09 | +10 | +9.7 |
| SPELLS IN THE FIGHT | 3 | 3 | 1 | 0.09 | +2 | +2.5 |
| SURE REACH TOGETHER | 4 | 4 | 1 | 0.09 | +0 | +0.0 |
| WAR ENGINE JOBS | 5 | 5 | 1 | 0.09 | -18 | -17.8 |
| ALREADY CARRIED | 2 | not checked | - | - | - | - |
| BACKUP TARGETS | 4 | 3 | 0 | 0.00 | - | - |
| BLOWS WHERE AIMED | 3 | 3 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 9 | 9 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 20 | trace | - | - | - | - |
| CHARACTER GUNS | 13 | 13 | 0 | 0.00 | - | - |
| CHARGER SLAIN LOST | 6 | 6 | 0 | 0.00 | - | - |
| CHEAP HELPER | 1 | not checked | - | - | - | - |
| CHEAPEST HOLDER | 4 | 4 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 21 | not checked | - | - | - | - |
| DEFENSIVE FLOOR | 1 | 1 | 0 | 0.00 | - | - |
| EDGE GIVE GROUND | 2 | 2 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FALLBACK BY WORTH | 6 | 6 | 0 | 0.00 | - | - |
| FIGHT LIFT | 3 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 149 | not checked | - | - | - | - |
| FRIEND CHARGES FIRST | 3 | 3 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 7 | 7 | 0 | 0.00 | - | - |
| GIVES UP | 3 | 3 | 0 | 0.00 | - | - |
| GUN FIGURES | 30 | not checked | - | - | - | - |
| HE SHOOTS OR CHARGES | 52 | 52 | 0 | 0.00 | - | - |
| HELPER ALREADY ASKED | 1 | not checked | - | - | - | - |
| HELPER UNSEEN | 2 | 2 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 62 | 62 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 80 | 80 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 51 | 51 | 0 | 0.00 | - | - |
| HOLD ODDS | 106 | 106 | 0 | 0.00 | - | - |
| HUNT IN PAIRS | 6 | 1 | 0 | 0.00 | - | - |
| HUNT RESULT | 1 | trace | - | - | - | - |
| HUNT THE GUNS | 1 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 3 | 3 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 3 | 3 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 6 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 7 | trace | - | - | - | - |
| MARCH OVER CASTS | 12 | 12 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 20 | trace | - | - | - | - |
| MOVE SPELL SPOT | 10 | not checked | - | - | - | - |
| NOT TURNED | 3 | 3 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 10 | not checked | - | - | - | - |
| ONE CHARGE A CHARGER | 65 | 65 | 0 | 0.00 | - | - |
| OPENS A LANE | 1 | 1 | 0 | 0.00 | - | - |
| PLAN RESULT | 954 | trace | - | - | - | - |
| REDIRECT BY WHAT IT STOPS | 5 | 5 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 12 | 12 | 0 | 0.00 | - | - |
| RUN DOWN | 37 | 37 | 0 | 0.00 | - | - |
| SAME CHARGE LATER | 4 | 4 | 0 | 0.00 | - | - |
| SCOUT SPOT | 5 | 5 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 2 | 2 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 6 | not checked | - | - | - | - |
| SET UP TOGETHER | 7 | 5 | 0 | 0.00 | - | - |
| SET-UP ANY TARGET | 3 | not checked | - | - | - | - |
| SHOT OR CHARGE | 5 | 5 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 5 | not checked | - | - | - | - |
| SPELL WORTH | 37 | not checked | - | - | - | - |
| STAND AND SHOOT | 5 | 5 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 14 | 14 | 0 | 0.00 | - | - |
| STANDS STILL | 370 | 370 | 0 | 0.00 | - | - |
| STOPS | 1 | 1 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 107 | not checked | - | - | - | - |
| THE PROMISE ADDS | 2 | 2 | 0 | 0.00 | - | - |
| THE PROMISED MOVE | 13 | not checked | - | - | - | - |
| WAITS AGAIN | 23 | 23 | 0 | 0.00 | - | - |
| WOUNDED STAYS OUT | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: h4-opp-bbe8617-p4

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| HOLDER ASSIGNMENT | rule | - | 1.55 | 11.0 |
| PATHS CROSS | rule | 0.64 | 0.55 | 35.9 |
| CHARGE NOT DECLARED | rule | - | 0.64 | 287.5 |
| JOB FIRST | gate | 0.27 | 0.36 | 10.2 |
| CHARGE NOW FIRST | rule | 0.09 | 0.45 | 51.6 |
| CANNON PLANNED TARGET | rule | 0.45 | - | 52.7 |
| CHAFF PASSED | rule | 0.36 | - | 3.1 |
| AFTERMATH BAND | gate | 0.18 | 0.09 | 3.3 |
| BEST PRIZE | rule | - | 0.27 | 347.6 |
| PIVOT GUARDS FLANK | rule | - | 0.27 | 27.3 |
| PURSUES BIG PREY | rule | - | 0.27 | 32.8 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.18 | - | 15.5 |
| REDIRECT WEIGHED | rule | - | 0.18 | 511.1 |
| SUPPORT NARROWED | rule | 0.09 | 0.09 | 4.0 |
| FALLBACK | gate | 0.09 | - | 0.8 |
| FOLLOW UP WEIGHED | rule | 0.09 | - | 4.0 |
| NO REASON | gate | - | 0.09 | 192.7 |
| REFUSING RETIRES | rule | - | 0.09 | 0.8 |
| WAR ENGINE JOBS | rule | 0.09 | - | 17.8 |

### Plans: h4-opp-bbe8617-p4

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 0.9 | 70% | 100 | 94 | 94% |
| Mine | join | 0.5 | 100% | 16 | 0 | 0% |
| Mine | move | 30.5 | 96% | 1752 | 0 | 0% |
| Mine | shoot | 9.8 | 56% | 440 | 911 | 207% |
| Mine | support | 0.4 | 25% | 4 | 0 | 0% |
| Opponent | charge | 3.9 | 60% | 844 | 324 | 38% |
| Opponent | join | 0.5 | 100% | 18 | 0 | 0% |
| Opponent | move | 35.4 | 96% | 1904 | 0 | 0% |
| Opponent | shoot | 4.5 | 47% | 218 | 147 | 67% |
| Opponent | support | 0.5 | 67% | 8 | 0 | 0% |

### Packages: hunt the guns, h4-opp-bbe8617-p4

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 10 |
| Opponent | 0.1 | 1 | 0 | 100% | 100% | 0% | 2.0 | 215 | 190 | 100% | 76 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 38 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 236 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Tomb Kings of Khemri | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 195 |
| Vampire Counts | 1.0 | 1 | 0 | 100% | 100% | 0% | 2.0 | 215 | 190 | 100% | 45 |
| Warriors of Chaos | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Wood Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 62 |

### Battle groups: h4-opp-bbe8617-p4

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 2.5 | 22% | 50% | 0% | - | 0% | 0% | 33% | 67% | 0% |
| Opponent | REDIRECT COUNTER | 3.5 | 5% | 100% | 50% | 0% | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: h4-opp-bbe8617-p4

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 7 | 0 (7) | 0 | 0 | 15 | 100% | - | 0 (3) | 0 (3) | 0 (1) | 0 (5) | 0 (2) |
| Mine | Character | 42 | 39 (42) | 39 | 0 | 19 | 21% | 2.9 | 19 (16) | 57 (14) | 52 (10) | 33 (22) | 48 (18) |
| Mine | Clean-up | 4 | 73 (4) | 0 | 73 | 46 | 0% | 1.2 | 89 (3) | 0 (1) | - | 89 (3) | 0 (1) |
| Mine | Fast Hammer | 10 | 0 (10) | 0 | 0 | 42 | 50% | 4.8 | 0 (1) | 0 (3) | 0 (6) | 0 (9) | 0 (1) |
| Mine | Hammer | 27 | 40 (27) | 21 | 19 | 9 | 22% | 3.2 | 24 (8) | 49 (14) | 34 (5) | 44 (13) | 36 (14) |
| Mine | Holder | 12 | 62 (12) | 0 | 62 | 14 | 58% | 5.0 | 37 (2) | 89 (7) | 20 (3) | 62 (5) | 63 (7) |
| Mine | Shooter | 16 | 90 (16) | 4 | 86 | 28 | 6% | 2.1 | 63 (8) | 146 (7) | 16 (1) | 84 (12) | 109 (4) |
| Mine | War machine | 25 | 29 (25) | 29 | 0 | 49 | 4% | 1.5 | 35 (14) | 22 (10) | 0 (1) | 70 (6) | 16 (19) |
| Mine | Wizard | 5 | 0 (5) | 0 | 0 | 18 | 20% | 2.8 | 0 (4) | 0 (1) | - | 0 (3) | 0 (2) |
| Opponent | Chaff | 24 | 42 (24) | 19 | 23 | 39 | 46% | 2.6 | 52 (13) | 39 (8) | 0 (3) | 37 (18) | 56 (6) |
| Opponent | Character | 27 | 38 (27) | 38 | 0 | 26 | 22% | 2.2 | 30 (5) | 41 (13) | 39 (9) | 49 (13) | 28 (14) |
| Opponent | Clean-up | 10 | 48 (10) | 3 | 44 | 3 | 60% | 3.5 | 0 (3) | 58 (4) | 56 (3) | 57 (6) | 36 (4) |
| Opponent | Fast Hammer | 12 | 24 (12) | 8 | 16 | 43 | 50% | 3.2 | 13 (3) | 32 (6) | 19 (3) | 25 (8) | 20 (4) |
| Opponent | Hammer | 16 | 15 (16) | 13 | 2 | 25 | 38% | 3.1 | 0 (2) | 20 (11) | 9 (3) | 10 (7) | 19 (9) |
| Opponent | Holder | 12 | 123 (12) | 0 | 123 | 3 | 25% | 2.2 | 53 (4) | 161 (7) | 382 (1) | 120 (9) | 133 (3) |
| Opponent | Shooter | 10 | 62 (10) | 0 | 62 | 42 | 0% | 2.5 | 113 (4) | 0 (1) | 28 (5) | 88 (6) | 35 (4) |
| Opponent | Support | 2 | 0 (2) | 0 | 0 | 50 | 50% | 6.0 | 0 (2) | - | - | 0 (1) | 0 (1) |
| Opponent | War machine | 7 | 15 (7) | 15 | 0 | 0 | 0% | 1.9 | 20 (5) | - | 0 (2) | - | 15 (7) |
| Opponent | Wizard | 10 | 0 (10) | 0 | 0 | 9 | 0% | 2.9 | - | 0 (5) | 0 (5) | 0 (1) | 0 (9) |

### Charged fights: h4-opp-bbe8617-p4

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 394 | 0 | 0.8 | 1.3 | 0 | 0 | +0 | 1 of 3 | 2 of 3 | +0 | +0 |
| Mine | Chaos Dwarfs | 4 | 237 | 266 | 2.0 | 1.1 | 133 | 14 | +119 | 5 of 8 | 7 of 8 | +98 | +122 |
| Mine | Dwarfen Mountain Holds | 3 | 65 | 28 | 1.3 | 1.0 | 21 | 18 | +3 | 2 of 4 | 3 of 4 | - | +3 |
| **Mine** | all armies | 11 | 247 | 104 | 1.4 | 1.1 | 76 | 12 | +64 | 8 of 15 | 12 of 15 | +49 | +66 |
| Opponent | Empire of Man | 1 | 355 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | High Elf Realms | 1 | 0 | 65 | 4.0 | 1.2 | 16 | 0 | +16 | 3 of 4 | 2 of 4 | +0 | +22 |
| Opponent | Kingdom of Bretonnia | 2 | 0 | 192 | 2.0 | 1.0 | 96 | 0 | +96 | 0 of 4 | 4 of 4 | - | +96 |
| Opponent | Skaven | 1 | 0 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 0 of 1 | 0 of 1 | - | +0 |
| Opponent | Tomb Kings of Khemri | 1 | 208 | 897 | 4.0 | 1.2 | 224 | 0 | +224 | 1 of 4 | 4 of 4 | +612 | +95 |
| Opponent | Vampire Counts | 1 | 0 | 596 | 7.0 | 1.1 | 85 | 6 | +79 | 2 of 7 | 6 of 7 | +186 | +61 |
| Opponent | Warriors of Chaos | 2 | 0 | 396 | 4.0 | 1.1 | 99 | 42 | +57 | 4 of 8 | 5 of 8 | +85 | +53 |
| Opponent | Wood Elf Realms | 2 | 56 | 328 | 4.0 | 1.1 | 82 | 41 | +40 | 2 of 8 | 6 of 8 | -13 | +48 |
| **Opponent** | all armies | 11 | 61 | 308 | 3.3 | 1.1 | 94 | 20 | +74 | 12 of 36 | 27 of 36 | +174 | +58 |

### Effective charges: h4-opp-bbe8617-p4

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 3 | 1 (net +0) | 0 | 1 (net +0) | 1 (net +0) | 0 | 0 | 0 | 33% (1 of 3) |
| Mine | Chaos Dwarfs | 8 | 0 | 0 | 0 | 3 (net +104) | 0 | 5 (net +128) | 0 | 0% (0 of 8) |
| Mine | Dwarfen Mountain Holds | 4 | 1 (net -73) | 0 | 0 | 0 | 0 | 2 (net +42) | 1 | 0% (0 of 3) |
| Opponent | High Elf Realms | 4 | 2 (net +0) | 0 | 0 | 0 | 0 | 2 (net +32) | 0 | 0% (0 of 4) |
| Opponent | Kingdom of Bretonnia | 4 | 0 | 0 | 0 | 2 (net +125) | 2 (net +66) | 0 | 0 | 0% (0 of 4) |
| Opponent | Skaven | 1 | 0 | 0 | 1 (net +0) | 0 | 0 | 0 | 0 | 100% (1 of 1) |
| Opponent | Tomb Kings of Khemri | 4 | 0 | 0 | 3 (net +95) | 0 | 1 (net +612) | 0 | 0 | 75% (3 of 4) |
| Opponent | Vampire Counts | 7 | 2 (net +35) | 0 | 2 (net +30) | 0 | 2 (net +118) | 1 (net +186) | 0 | 29% (2 of 7) |
| Opponent | Warriors of Chaos | 8 | 3 (net +114) | 0 | 2 (net -10) | 0 | 0 | 2 (net +68) | 1 | 29% (2 of 7) |
| Opponent | Wood Elf Realms | 8 | 3 (net -34) | 0 | 0 | 2 (net +107) | 0 | 0 | 3 | 0% (0 of 5) |

### Charged fights, damage counted: h4-opp-bbe8617-p4

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 2 | 64 | 422 | -36 | 0 | 91 | -91 | -143.9 |
| Mine | Effective (55-75%) | 1 | 136 | 63 | +0 | 13 | 12 | +1 | +0.4 |
| Mine | 76-89% | 4 | 250 | 190 | +78 | 96 | 22 | +73 | +29.3 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 7 | 296 | 217 | +103 | 153 | 25 | +129 | +43.5 |
| Mine | No odds | 1 | 250 | 104 | +0 | 52 | 50 | +2 | +0.8 |
| Mine | All fights | 15 | 239 | 219 | +64 | 101 | 34 | +68 | +28.3 |
| Opponent | Long shot (under 50%) | 10 | 252 | 258 | +31 | 80 | 89 | -9 | -3.6 |
| Opponent | Effective (55-75%) | 8 | 302 | 142 | +41 | 88 | 40 | +48 | +16.0 |
| Opponent | 76-89% | 4 | 343 | 226 | +116 | 213 | 118 | +95 | +27.6 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 5 | 381 | 142 | +78 | 78 | 0 | +78 | +20.4 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 5 | 471 | 121 | +196 | 196 | 0 | +196 | +41.6 |
| Opponent | No odds | 4 | 244 | 95 | +53 | 99 | 29 | +70 | +28.6 |
| Opponent | All fights | 36 | 321 | 175 | +74 | 114 | 50 | +65 | +20.1 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| h4-opp-bbe8617-p4 | move | 88 | 18 (20%) | 13 (15%) | 11 (12%) | 59 (67%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0115, L0132 |
| Charmed Shield | Opponent | L0625 |
| Horn of the Wild Hunt | Opponent | L0333 |
| Invocation of Nehek | Opponent | L0625 |
| Periapt of Soul Exchange | Opponent | L0420 |
| Ring of Doom | Mine | L0216, L0232 |
| Ring of Doom | Opponent | L0115, L0333 |

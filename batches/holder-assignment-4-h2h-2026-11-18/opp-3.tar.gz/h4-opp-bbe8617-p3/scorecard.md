# Doctrine scorecard: h4-opp-bbe8617-p3

### Scorecard: h4-opp-bbe8617-p3

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0111 | 3 | 1 | Mine | no | 6 | 4 | 1 | 2 | 0 | 0 | 0 | 0 |
| L0111 | 3 | 1 | Opponent | yes | 9 | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L0128 | 2 | 1 | Mine | - | - | 5 | 1 | 3 | 0 | 0 | 0 | 0 |
| L0128 | 2 | 1 | Opponent | - | - | - | 0 | 3 | 0 | 0 | 0 | 0 |
| L0211 | 1 | 1 | Mine | no | 0 | - | 1 | 6 | 0 | 0 | 0 | 170 |
| L0211 | 1 | 1 | Opponent | no | 12 | 2 | 0 | 0 | 0 | 0 | 0 | 0 |
| L0228 | 6 | 1 | Mine | yes | 9 | 2 | 3 | 1 | 0 | 0 | 0 | 170 |
| L0228 | 6 | 1 | Opponent | no | 6 | - | 0 | 0 | 0 | 0 | 0 | 0 |
| L0313 | 1 | 1 | Mine | no | 0 | - | 0 | 0 | 0 | 0 | 0 | 225 |
| L0313 | 1 | 1 | Opponent | no | 9 | 2 | 4 | 0 | 0 | 0 | 0 | 70 |
| L0330 | 6 | 1 | Mine | no | 0 | - | 0 | 0 | 0 | 0 | 0 | 110 |
| L0330 | 6 | 1 | Opponent | no | 12 | 2 | 2 | 0 | 0 | 0 | 0 | 0 |
| L0415 | 1 | 1 | Mine | no | 11 | 5 | 1 | 2 | 1 | 0 | 0 | 310 |
| L0415 | 1 | 1 | Opponent | no | 13 | 2 | 3 | 1 | 2 | 0 | 0 | 0 |
| L0432 | 6 | 1 | Mine | no | 2 | 3 | 7 | 0 | 0 | 0 | 0 | 310 |
| L0432 | 6 | 1 | Opponent | no | 0 | 2 | 4 | 2 | 1 | 0 | 0 | 340 |
| L0518 | 2 | 1 | Mine | - | - | - | 0 | 2 | 0 | 0 | 0 | 160 |
| L0518 | 2 | 1 | Opponent | - | - | 6 | 4 | 0 | 0 | 0 | 0 | 0 |
| L0534 | 6 | 1 | Mine | no | 0 | - | 0 | 3 | 0 | 0 | 0 | 790 |
| L0534 | 6 | 1 | Opponent | no | 5 | 2 | 4 | 4 | 0 | 0 | 0 | 0 |
| L0621 | 3 | 1 | Mine | no | 3 | 5 | 1 | 1 | 1 | 0 | 0 | 358 |
| L0621 | 3 | 1 | Opponent | no | 11 | - | 1 | 7 | 0 | 0 | 0 | 145 |
| L0710 | 2 | 1 | Mine | - | - | 2 | 3 | 1 | 0 | 0 | 0 | 125 |
| L0710 | 2 | 1 | Opponent | - | - | 3 | 1 | 0 | 0 | 0 | 0 | 0 |
| L0726 | 6 | 1 | Mine | no | 15 | 2 | 0 | 0 | 0 | 0 | 0 | 250 |
| L0726 | 6 | 1 | Opponent | no | 8 | 2 | 2 | 0 | 1 | 0 | 0 | 0 |
| **Average** | | | Mine | 10% | 4.6 | 3.5 | 1.4 | 1.6 | 0.2 | 0.0 | 0.0 | 229.1 |
| **Average** | | | Opponent | 10% | 8.5 | 2.5 | 2.2 | 1.4 | 0.3 | 0.0 | 0.0 | 42.7 |

### KPIs: h4-opp-bbe8617-p3

Rules off - Mine only: HOLDER ASSIGNMENT, QUARTER ODDS.

Morten 2026-11-10; 13 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 48% (30 of 63) | 5% (3 of 62) | 26% (33 of 125) |
| Winner chose to follow up after the loser gave ground |  | 60% (9 of 15); on the table 73% | 67% (10 of 15); on the table 73% | 63% (19 of 30); on the table 73% |
| Winner chose to pursue after the loser fell back in good order |  | 50% (2 of 4); on the table 50% | 80% (4 of 5); on the table 80% | 67% (6 of 9); on the table 67% |
| Winner chose to pursue after the loser fled |  | 60% (3 of 5); on the table 60% | 67% (4 of 6); on the table 67% | 64% (7 of 11); on the table 64% |
| Winner chose to follow up or pursue (all three) |  | 58% (14 of 24); on the table 67% | 69% (18 of 26); on the table 73% | 64% (32 of 50); on the table 70% |
| Magic missiles tried each own turn | 50%+ | 37% (51 of 138) | 40% (41 of 102) | 38% (92 of 240) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 43% (51 of 119) | 51% (41 of 81) | 46% (92 of 200) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 33% (3 of 9) | 69% (9 of 13) | 55% (12 of 22) |
| Points that never fought | lower | 49% (12651 of 25562) | 55% (14332 of 25993) | 52% (26983 of 51555) |
|   infantry points that never fought | lower | 62% (4189 of 6788) | 71% (2736 of 3879) | 65% (6925 of 10667) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 58% (57 of 98) | 55% (54 of 98) | 57% (111 of 196) |
| Bound items with a magic missile used (at least once a game) |  | 83% (5 of 6); 1.2 uses a game | 91% (10 of 11); 2.3 uses a game | 88% (15 of 17); 1.7 uses a game |
| Bound items with another spell used |  | 100% (4 of 4); 1.0 uses a game | 33% (1 of 3); 0.1 uses a game | 71% (5 of 7); 0.5 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 70% (7 of 10); 0.5 uses a game | 33% (2 of 6); 0.2 uses a game | 56% (9 of 16); 0.3 uses a game |
|   their share of the points of units over 100 pts | lower | 55% (10999 of 19862) | 51% (12048 of 23683) | 53% (23047 of 43545) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 2.9 (44%) | 0.5 (11%) | 3.5 (30%) |
| MARCHED: its unit marched | 1.5 (22%) | 1.6 (34%) | 3.1 (27%) |
| CHARGED: its unit charged | 0.2 (3%) | 0.3 (7%) | 0.5 (5%) |
| IN COMBAT: engaged in combat | 0.5 (8%) | 0.7 (15%) | 1.2 (11%) |
| REAR RANK: in a rear rank | 0.5 (7%) | 0.2 (5%) | 0.7 (6%) |
| GONE: slain | 0.9 (14%) | 0.9 (20%) | 1.8 (16%) |
| STUPIDITY: Stupidity | 0.2 (2%) | 0.2 (3%) | 0.3 (3%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.2 (5%) | 0.2 (2%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 3.7 | 2.2 | 2.1 | 7.1 | 0.4 | 1.7 |
| not cast | 2.8 | 4.5 | 2.5 | 11.4 | 1.9 | 21.4 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.4 (6%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.9 (43%) | 0.1 (3%) | 3.5 (30%) | 0.7 (36%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 3.1 (27%) | 0.5 (28%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.5 (5%) | 0.2 (8%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.2 (8%) | 0.0 (0%) | 0.4 (15%) | 1.2 (11%) | 0.5 (28%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.9 (21%) | 0.5 (18%) | 0.7 (6%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.1 (3%) | 0.1 (2%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (1%) |
| GONE: slain | 0.5 (17%) | 1.0 (22%) | 0.3 (12%) | 1.8 (16%) | 0.0 (0%) | 1.5 (7%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (0%) | 0.0 (0%) | 0.1 (3%) | 0.0 (0%) | 0.0 (0%) | 0.2 (1%) |
| STUPIDITY: Stupidity | 0.2 (8%) | 0.1 (2%) | 0.1 (3%) | 0.3 (3%) | 0.0 (0%) | 0.6 (3%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.1 (3%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (2%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.8 (64%) | 0.5 (10%) | 1.1 (42%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 17.5 (82%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 2.1 a game | 0.6 a game | 1.3 a game |
| stood (cast and not dispelled) | 48% (13 of 27) | 80% (4 of 5) | 53% (17 of 32) |
| the unit moved after it | 38% (5 of 13) | 100% (4 of 4) | 53% (9 of 17) |
| it charged on its next turn | 0% (0 of 13) | 0% (0 of 4) | 0% (0 of 17) |
| the enemy charged it first | 23% (3 of 13) | 0% (0 of 4) | 18% (3 of 17) |
| it fought by the end of its next turn | 15% (2 of 13) | 0% (0 of 4) | 12% (2 of 17) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 13) | 25% (1 of 4) | 6% (1 of 17) |
| none of these (no charge, no fight, no charge escaped) | 69% (9 of 13) | 75% (3 of 4) | 71% (12 of 17) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 68% (242 of 356) | 48% (106 of 221) | 60% (348 of 577) |
|   cavalry | 71% (10 of 14) | 58% (14 of 24) | 63% (24 of 38) |
|   character | 81% (48 of 59) | 26% (11 of 43) | 58% (59 of 102) |
|   chariot | 55% (21 of 38) | 56% (22 of 39) | 56% (43 of 77) |
|   infantry | 55% (48 of 87) | 54% (38 of 70) | 55% (86 of 157) |
|   monster | 100% (2 of 2) | 45% (5 of 11) | 54% (7 of 13) |
|   war machine | 72% (113 of 156) | 47% (16 of 34) | 68% (129 of 190) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.7 (31%) | 2.2 (25%) | 4.9 (28%) |
| CHARGED: it charged | 0.2 (2%) | 1.8 (20%) | 1.9 (11%) |
| FLEEING: it fled or was fleeing | 0.0 (0%) | 0.2 (2%) | 0.2 (1%) |
| IN COMBAT: it fought this turn or the last | 0.7 (8%) | 0.3 (3%) | 1.0 (6%) |
| MOVED: a war machine that moved | 1.7 (19%) | 1.2 (13%) | 2.8 (16%) |
| NO TARGET IN RANGE | 1.6 (18%) | 1.6 (18%) | 3.2 (18%) |
| ONLY IN COMBAT: the only targets were in combat | 0.2 (3%) | 0.4 (4%) | 0.6 (3%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.1 (12%) | 0.8 (10%) | 1.9 (11%) |
| SHELTERED: the target was sheltered | 0.2 (2%) | 0.2 (2%) | 0.3 (2%) |
| OTHER BAR | 0.5 (5%) | 0.2 (3%) | 0.7 (4%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 2.3 | 0.8 | 80% | 4.9 pts | 11 pts |
| character | 5.0 | 1.1 | 83% | 3.1 pts | 16 pts |
| chariot | 3.3 | 2.9 | 49% | 26.6 pts | 88 pts |
| infantry | 10.6 | 3.3 | 75% | 8.3 pts | 88 pts |
| monster | 0.5 | 0.2 | 86% | 0.9 pts | 0 pts |
| war machine | 9.9 | 10.1 | 60% | 26.0 pts | 258 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 2.4 | 4.5 | 3.5 |
| Charges that made contact a game | 2.0 | 3.2 | 2.6 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.33 declared, 0.17 contact (6 units) | 0.80 declared, 0.40 contact (10 units) | 0.62 declared, 0.31 contact (16 units) |
|   per unit a game, units carrying another wizard (or one alone) | 1.00 declared, 1.00 contact (2 units) | 1.67 declared, 1.67 contact (3 units) | 1.40 declared, 1.40 contact (5 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.30 declared, 0.26 contact (89 units) | 0.51 declared, 0.36 contact (90 units) | 0.41 declared, 0.31 contact (179 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 43% (9 of 21) | 50% (1 of 2) | 43% (3 of 7) | 43% (13 of 30) |
| Character in a unit | 80% (16 of 20) | 81% (13 of 16) | 50% (1 of 2) | 79% (30 of 38) |
| Character on its own | 75% (6 of 8) | 70% (7 of 10) | 33% (6 of 18) | 53% (19 of 36) |
| Chariot | 88% (7 of 8) | 62% (5 of 8) | - | 75% (12 of 16) |
| Infantry | 29% (6 of 21) | 27% (4 of 15) | 0% (0 of 1) | 27% (10 of 37) |
| Monster | 50% (3 of 6) | 67% (2 of 3) | - | 56% (5 of 9) |
| Monstrous | 100% (3 of 3) | 33% (1 of 3) | - | 67% (4 of 6) |
| War Machines | 73% (16 of 22) | 100% (2 of 2) | - | 75% (18 of 24) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 67% (6 of 9); on the table 78% | 36% (37 of 102) | 68% | 68% (15 of 22) | 83% (5 of 6); 3.8 uses a game | 100% (2 of 2); 2.0 uses a game | 67% (4 of 6); 1.0 uses a game |
| Chaos Dwarfs | 4 | 62% (5 of 8); on the table 75% | 39% (14 of 36) | 36% | 50% (16 of 32) | 0.0 uses a game | 0.0 uses a game | 100% (2 of 2); 0.5 uses a game |
| Dwarfen Mountain Holds | 3 | 25% (1 of 4); on the table 25% | - | 56% | 62% (15 of 24) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 2 | 67% (2 of 3); on the table 67% | - | 31% | 55% (11 of 20) | 0.0 uses a game | 100% (2 of 2); 2.5 uses a game | 50% (1 of 2); 0.5 uses a game |
| Grand Cathay | 3 | 33% (2 of 6); on the table 50% | 45% (30 of 66) | 49% | 65% (17 of 26) | 100% (6 of 6); 4.7 uses a game | 100% (1 of 1); 0.3 uses a game | 0% (0 of 3); 0.0 uses a game |
| High Elf Realms | 2 | 100% (3 of 3); on the table 100% | 0% (0 of 6) | 72% | 40% (6 of 15) | 67% (2 of 3); 4.5 uses a game | 0% (0 of 2); 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 1 | 75% (3 of 4); on the table 75% | 0% (0 of 6) | 91% | 71% (5 of 7) | 100% (1 of 1); 3.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Skaven | 1 | 0% (0 of 1); on the table 0% | 50% (3 of 6) | 78% | 67% (6 of 9) | 100% (1 of 1); 4.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Vampire Counts | 1 | 100% (2 of 2); on the table 100% | 17% (1 of 6) | 21% | 0% (0 of 5) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 4 | 75% (6 of 8); on the table 75% | 58% (7 of 12) | 48% | 54% (15 of 28) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 0.2 uses a game |
| Wood Elf Realms | 1 | 100% (2 of 2); on the table 100% | - | 44% | 62% (5 of 8) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (h4-opp-bbe8617-p3, 13 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 43% (12) | 63% (12) | 51% (24) |
| ...free all their last turn and able to turn (per game) | 0.85 | 0.77 | 1.62 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.08 | 0.00 | 0.08 |
| ...with the charger already in that arc before they moved (per game) | 0.54 | 0.46 | 1.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.08 | 0.00 | 0.08 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.77 | 0.08 | 0.85 |

### Quality by phase: h4-opp-bbe8617-p3

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.7 | 2.5 |
| Strategy | Charge objectives carried out (made contact) | 69% (20 of 29) | 44% (23 of 52) |
| Strategy | Shoot objectives carried out (shot that target) | 37% (73 of 197) | 38% (22 of 58) |
| Strategy | Support requests answered (helper made contact too) | 100% (1 of 1) | 43% (3 of 7) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (2 of 2) | - |
| Strategy | Hexes on a unit its side charged or shot that turn | 20% (1 of 5) | 20% (1 of 5) |
| Strategy | Joined characters whose unit fought | 38% (13 of 34) | 31% (5 of 16) |
| Strategy | Lone characters that fought | 56% (14 of 25) | 57% (13 of 23) |
| Movement | Charges halted short of contact | 0.0 | 0.3 |
| Movement | Idle units | 1.6 | 1.4 |
| Movement | Points that never moved of their own | 229.1 | 42.7 |
| Movement | Fights charged into per game | 1.7 | 2.8 |
| Movement | Charges with odds: long shots (under 50%) | 5 of 21, net +7 | 6 of 31, net -6 |
| Movement | Charges with odds: sweet spot (55-75%) | 2 of 21, net +0 | 6 of 31, net +135 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 2 of 21, net +52 | 4 of 31, net +119 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 6 of 21, net +90 | 7 of 31, net +159 |
| Shooting | Shots by shooting units (incl. breath weapons) | 10.6 | 7.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 50% (69 of 138) | 42% (42 of 100) |
| Shooting | Points destroyed by shooting units | 79.2 | 13.8 |
| Shooting | War machine shots | 8.7 | 1.2 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 56% (63 of 113) | 62% (10 of 16) |
| Shooting | Points destroyed by war machines | 65.7 | 35.4 |
| Magic | Magic missiles cast | 2.2 | 2.2 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 59% (17 of 29) | 11% (3 of 28) |
| Magic | Wounds caused by magic missiles | 4.2 | 5.8 |
| Magic | Wounds caused by other spells | 1.1 | 1.3 |
| Magic | Points destroyed by magic (all spells) | 78.6 | 106.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.5 / 0.4 / 0.9 / 0.0 | 1.2 / 0.8 / 0.4 / 0.1 |
| Combat | Points destroyed in combat | 150.1 | 315.0 |
| Combat | Points run down | 24.6 | 53.2 |
| Combat | Net points per charged fight, damage counted | +88 | +114 |
| Combat | Net per 100 charger points, damage counted | +35.3 | +32.5 |
| Combat | First round won (charged fights) | 77% | 57% |
| Combat | Net points per charged fight | +69 | +110 |
| Combat | Net points per supported fight / lone fight | +24 / +76 | +487 / +77 |
| Combat | Charged fights on a top-3 enemy unit | 9 of 22 | 22 of 37 |
| Game | Points lost | 546.5 | 455.5 |
| Game | VP from objectives | 663.8 | 733.1 |
| Game | Lone holders (player turns) | 4.6 | 8.5 |

- Mine won / drew / lost: 2 / 5 / 6 of 13 ended games (of 13); mean margin (Mine - Opponent) -195 VP
- The side that went first won 4 of 8 games with a winner
- Points traded per game (both sides' losses): 1002
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: h4-opp-bbe8617-p3

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.6 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.5 | +55.4 | 0.0 | 22.2 | 0.3 | +45.3 | 0.0 | 0.0 |
| ALREADY CARRIED | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARRIVAL HUNT | - | - | - | - | 0.1 | +1.3 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.8 | +0.0 | 0.0 | 61.9 | 0.2 | +0.0 | 0.0 | 25.4 |
| BACKUP TARGETS | 0.2 | +1.0 | 0.0 | 0.0 | 0.2 | +0.9 | 0.0 | 0.0 |
| BEST PRIZE | - | - | - | - | 0.2 | -15.8 | 7.3 | 0.0 |
| BLOWS WHERE AIMED | 0.2 | -7.5 | 0.0 | 4.0 | 0.2 | -45.8 | 0.0 | 11.5 |
| BOMBING RUN | - | - | - | - | 0.1 | +2.1 | 6.5 | 0.0 |
| CANNON PLAN MISSED | 1.0 | +0.0 | 43.7 | 19.2 | 0.2 | +0.0 | 41.9 | 12.7 |
| CANNON PLANNED TARGET | 8.0 | +95.3 | 228.7 | 96.5 | 1.1 | +37.4 | 30.8 | 38.1 |
| CANNON SIGHT KEPT | 1.1 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT SET-UP | - | - | - | - | 0.1 | +0.0 | 22.2 | 0.0 |
| CAST JOB | 0.8 | +14.1 | 53.6 | 13.1 | 0.2 | +1.3 | 0.0 | 0.0 |
| CASTER AWAY FROM SCREEN | 0.4 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.5 | +58.1 | 3.2 | 0.0 | 0.2 | +0.6 | 5.0 | 0.0 |
| CASTS AFTER FRIENDS | 0.9 | +0.0 | 0.0 | 0.0 | 0.5 | +0.0 | 0.0 | 30.8 |
| CATCH FLIERS | - | - | - | - | 0.1 | +0.6 | 0.0 | 0.0 |
| CATCH ODDS | 0.1 | +13.4 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | 0.4 | +11.1 | 0.0 | 6.5 | 0.3 | +7.1 | 0.0 | 6.6 |
| CHAFF PASSED | - | - | - | - | 0.4 | -0.6 | 0.0 | 0.0 |
| CHARACTER GUNS | 0.3 | +0.0 | 0.0 | 0.0 | 0.5 | +0.0 | 0.0 | 0.0 |
| CHARGE LOSSES | 5.2 | -191.7 | 0.0 | 29.0 | 5.8 | -308.9 | 0.0 | 154.2 |
| CHARGE NOT DECLARED | 0.5 | +0.0 | 42.1 | 10.5 | 0.8 | +0.0 | 151.2 | 28.4 |
| CHARGE NOW FIRST | 0.8 | +0.0 | 98.8 | 4.0 | 2.1 | +0.0 | 351.3 | 50.5 |
| CHARGER SLAIN LOST | 0.6 | -34.2 | 12.7 | 42.7 | 0.3 | -14.0 | 17.2 | 20.4 |
| CHEAP HELPER | 0.1 | +0.0 | 0.0 | 4.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CHEAPEST HOLDER | 0.5 | -25.7 | 5.0 | 0.0 | - | - | - | - |
| COMBAT PIVOT | 0.3 | +0.0 | 0.0 | 23.8 | 0.3 | +0.0 | 0.0 | 21.5 |
| CONVEYANCE SEARCH | 1.7 | +178.0 | 10.9 | 0.0 | 0.3 | +29.8 | 30.8 | 30.8 |
| COVER ONCE | 6.8 | -604.0 | 0.0 | 131.5 | 4.5 | -331.5 | 0.0 | 60.8 |
| DEFENSIVE ARMY | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| DEFENSIVE FLOOR | 0.1 | +1.2 | 10.7 | 0.0 | - | - | - | - |
| DEPLOY BY FIGURES | 8.3 | +50.4 | 0.0 | 5.0 | 7.3 | +26.7 | 0.0 | 11.2 |
| EDGE GIVE GROUND | - | - | - | - | 0.2 | +2.4 | 27.3 | 0.0 |
| ENGINEER BY LORE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 0.1 | +4.5 | 0.0 | 0.0 | - | - | - | - |
| FALL BACK GOOD ORDER | 1.5 | +1.8 | 108.9 | 38.7 | 3.2 | +11.3 | 382.8 | 64.2 |
| FALLBACK BY WORTH | 0.5 | +1.7 | 0.0 | 3.5 | 0.2 | +0.0 | 0.0 | 2.1 |
| FALLS SHORT | 5.9 | +103.7 | 0.0 | 87.0 | 20.1 | +330.8 | 0.0 | 160.1 |
| FEATURE BUFFS | 2.0 | +78.2 | 0.0 | 16.3 | 0.8 | +13.6 | 0.0 | 12.5 |
| FIGHT TO THE END | 0.5 | +23.7 | 52.3 | 4.0 | 1.8 | +159.1 | 298.2 | 13.3 |
| FIRE IN ORDER | 0.4 | +0.0 | 21.2 | 8.1 | 0.2 | +0.0 | 6.5 | 0.0 |
| FIVE ACTION | 47.8 | +2744.1 | 788.4 | 530.0 | 42.6 | +3942.9 | 634.5 | 598.8 |
| FLANK NOT WEIGHED | 5.2 | +0.0 | 0.0 | 61.6 | 5.6 | +0.0 | 0.0 | 94.2 |
| FOLLOW UP WEIGHED | 0.5 | +147.9 | 0.0 | 0.0 | 0.8 | +239.5 | 0.0 | 0.0 |
| FOUR ROUNDS | 2.2 | +180.8 | 163.6 | 46.7 | 3.8 | +617.8 | 445.7 | 71.7 |
| FRIEND CHARGES FIRST | - | - | - | - | 0.1 | -5.5 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 0.8 | -21.4 | 0.0 | 23.8 | 0.4 | -16.0 | 0.0 | 30.8 |
| FRIENDS SHOTS CHECKED | 0.1 | +12.3 | 0.0 | 0.0 | 0.1 | +0.5 | 0.0 | 0.0 |
| GIVES UP | 0.2 | -2.0 | 12.5 | 0.0 | 0.2 | -1.6 | 6.5 | 0.0 |
| GROUND FLIERS | 0.1 | +3.3 | 0.0 | 0.0 | - | - | - | - |
| GUN FIGURES | 0.9 | +15.5 | 31.7 | 23.8 | 0.5 | +4.3 | 13.1 | 0.0 |
| GUN MASK | 0.6 | +8.8 | 0.0 | 40.5 | 0.8 | +14.2 | 0.0 | 0.0 |
| HARD STAY DROPPED | 1.8 | +0.0 | 0.0 | 0.0 | 1.2 | +0.0 | 0.0 | 11.6 |
| HE SHOOTS OR CHARGES | 2.4 | +0.0 | 0.0 | 43.8 | 1.8 | +0.0 | 0.0 | 59.2 |
| HELPER ALREADY ASKED | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 2.1 |
| HIS CHARGE DENIED | 0.5 | +16.9 | 26.6 | 28.2 | 0.3 | +18.4 | 67.0 | 0.0 |
| HIS CHARGE LIST | 3.2 | +0.0 | 0.0 | 45.7 | 2.6 | +0.0 | 0.0 | 15.5 |
| HIS LEGAL MOVES | 2.6 | +0.0 | 0.0 | 40.5 | 3.1 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 1.8 | -23.5 | 0.0 | 21.1 | 1.5 | -53.5 | 0.0 | 49.2 |
| HIS RANDOM MOVE | 1.5 | +0.0 | 0.0 | 12.7 | 1.5 | +0.0 | 0.0 | 6.3 |
| HIS SHOT LIST | 18.6 | +550.0 | 0.0 | 158.2 | 24.7 | +1315.2 | 0.0 | 386.6 |
| HIS TURN DENIED | 0.8 | +34.2 | 94.2 | 0.0 | 2.4 | +131.4 | 284.9 | 50.8 |
| HOLD ODDS | - | - | - | - | 8.5 | +0.0 | 0.0 | 20.4 |
| HOLDER ASSIGNMENT | - | - | - | - | 16.5 | +1742.8 | 0.0 | 52.8 |
| HOLDER AT DEPLOYMENT | 1.2 | +148.5 | 0.0 | 0.0 | - | - | - | - |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 1.5 | -39.4 | 151.2 | 4.0 | 3.4 | -182.5 | 429.8 | 50.5 |
| HUNT IN PAIRS | - | - | - | - | 0.5 | +16.1 | 0.0 | 0.0 |
| HUNT RESULT | 0.1 | +21.4 | 0.0 | 0.0 | - | - | - | - |
| HUNT THE GUNS | 0.1 | +25.8 | 12.7 | 0.0 | - | - | - | - |
| IDLE COST | 2.8 | -30.5 | 0.0 | 40.7 | 10.8 | -180.9 | 0.0 | 146.5 |
| JOINT KNOWS CHALLENGE | - | - | - | - | 0.3 | -7.2 | 81.0 | 0.0 |
| KEEP FALLS | 0.3 | +5.5 | 0.0 | 18.3 | - | - | - | - |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KILLS COUNT | 0.1 | +9.0 | 13.1 | 0.0 | - | - | - | - |
| LANE BY FIGURES | 0.5 | +28.8 | 0.0 | 0.0 | 0.8 | +30.1 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 4.0 | +0.0 | 185.7 | 195.3 | 1.9 | +0.0 | 116.3 | 38.4 |
| LONE CHARACTER SAFE SPOT | 0.7 | +18.2 | 0.0 | 0.0 | - | - | - | - |
| LONE WIZARD KEPT IN | 0.8 | +65.1 | 0.0 | 7.3 | 0.2 | +29.9 | 0.0 | 0.0 |
| LONG SHOT | 0.2 | +0.9 | 30.4 | 0.0 | 0.5 | +1.8 | 14.6 | 13.3 |
| LOST CHARGE | - | - | - | - | 0.1 | -0.1 | 0.0 | 13.3 |
| LURE BY WHAT IT DRAWS | 0.2 | -13.6 | 0.0 | 0.0 | - | - | - | - |
| MAKE SURE TOGETHER | 0.1 | +0.1 | 0.0 | 0.0 | 0.2 | +2.0 | 0.0 | 2.6 |
| MANOEUVRE | 1.4 | +2.6 | 0.0 | 0.0 | 1.6 | +18.7 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.2 | +1.4 | 0.0 | 0.0 | - | - | - | - |
| MARCH BY THE SUM | 0.2 | +5.7 | 0.0 | 0.0 | 0.4 | +16.5 | 0.0 | 0.0 |
| MARCH CHECK | 0.8 | +56.0 | 0.0 | 6.2 | 1.8 | +89.5 | 0.0 | 0.0 |
| MARCH OVER CASTS | 0.5 | +134.6 | 0.0 | 0.0 | 1.2 | +21.4 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 4.8 | +73.4 | 0.0 | 71.5 | 7.4 | +101.9 | 0.0 | 163.2 |
| MISSILES IN THE MOVE | 3.8 | +250.6 | 0.0 | 32.4 | 5.0 | +98.8 | 0.0 | 86.5 |
| MISSILES NEXT TURN | 4.0 | +134.3 | 0.0 | 25.8 | 6.5 | +68.5 | 0.0 | 117.2 |
| MODEL FACING | 0.4 | +108.9 | 0.0 | 9.2 | - | - | - | - |
| MOVE SPELL IN RANGE | 0.5 | +6.9 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 1.4 | -129.1 | 77.2 | 0.0 | - | - | - | - |
| MOVE SPELL SPOT | 0.2 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 30.8 |
| MOVE TO CHARGE COMPUTED | 3.1 | +308.0 | 0.0 | 23.8 | 4.7 | +870.0 | 0.0 | 87.0 |
| MOVES UNITS SPELL | 0.2 | +8.5 | 0.0 | 0.0 | 0.1 | +0.6 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 5.1 | +272.2 | 0.0 | 58.2 | 5.5 | +233.9 | 0.0 | 0.0 |
| NEEDED THERE | 0.1 | +23.2 | 13.1 | 0.0 | - | - | - | - |
| NEXT CHARGE BY LIST | 4.8 | -131.4 | 0.0 | 39.0 | 6.2 | -285.8 | 0.0 | 92.2 |
| NEXT OBJECTIVE NEARER | 7.4 | -394.1 | 28.5 | 82.2 | 0.2 | -4.3 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 2.1 | -111.4 | 160.2 | 46.7 | 3.0 | -178.6 | 394.5 | 62.1 |
| NO RALLY LEFT | 0.2 | +24.3 | 0.0 | 0.0 | - | - | - | - |
| NOT TURNED | 0.8 | +0.7 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 3.2 |
| NOT WORTH A CAST | 0.3 | -0.5 | 0.0 | 0.0 | 0.2 | -0.3 | 0.0 | 0.0 |
| OFF BEST | 1.0 | -15.7 | 0.0 | 0.0 | 0.3 | -1.8 | 0.0 | 0.0 |
| ONE CHARGE A CHARGER | 3.2 | +0.0 | 0.0 | 98.3 | 1.5 | +0.0 | 0.0 | 48.8 |
| ONE FIGHT FORMULA | 4.8 | -71.0 | 0.0 | 34.8 | 5.5 | -179.6 | 0.0 | 143.6 |
| ONE OBJECTIVE FORMULA | 4.8 | -6.7 | 0.0 | 50.8 | 4.7 | +70.5 | 0.0 | 30.5 |
| ONE TARGET A SHOOTER | 17.3 | +323.1 | 0.0 | 199.5 | 21.0 | +707.6 | 0.0 | 278.8 |
| OPENS A LANE | 0.3 | +0.7 | 20.8 | 0.0 | - | - | - | - |
| OPENS UP | - | - | - | - | 0.5 | +52.8 | 28.8 | 0.0 |
| OVERRUNS AWAY | 0.1 | +1.1 | 12.7 | 0.0 | 0.8 | +45.3 | 95.1 | 8.8 |
| PATHS CROSS | 4.0 | +215.5 | 0.0 | 81.1 | 4.2 | +217.2 | 0.0 | 10.5 |
| PERIAPT WORTH | - | - | - | - | 0.1 | +4.2 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.1 | -1.6 | 0.0 | 23.8 | 0.2 | -1.3 | 0.0 | 0.0 |
| PLAN RESULT | 43.1 | +989.7 | 455.7 | 789.6 | 37.8 | +547.0 | 425.2 | 768.9 |
| PURSUES BIG PREY | 0.2 | -13.4 | 0.0 | 0.0 | 0.1 | -12.2 | 0.0 | 0.0 |
| QUARTER ODDS | - | - | - | - | 2.9 | +482.0 | 97.7 | 43.9 |
| RANDOM MOVE BY FIGURES | 0.7 | +3.0 | 0.0 | 26.2 | 1.0 | +19.1 | 0.0 | 56.5 |
| REDIRECT BY WHAT IT STOPS | 0.5 | -16.9 | 0.0 | 6.5 | 0.2 | -19.5 | 0.0 | 6.6 |
| REDIRECT COUNTER | 1.7 | +148.0 | 0.0 | 31.1 | 3.5 | +215.7 | 0.0 | 69.5 |
| REDIRECT WEIGHED | 0.2 | +8.9 | 0.0 | 0.0 | 0.3 | +8.8 | 0.0 | 0.0 |
| REFORMS TO MEET IT | 0.5 | -6.4 | 0.0 | 0.0 | 0.8 | -97.4 | 0.0 | 2.1 |
| REFUSING RETIRES | 0.2 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | 0.3 | +10.6 | 0.0 | 0.0 | 0.5 | +46.6 | 0.0 | 0.0 |
| RESTRAINS TO SHOOT | 0.1 | +0.5 | 0.0 | 8.6 | 0.1 | +1.2 | 0.0 | 0.0 |
| RISK BY ARC | 2.0 | +51.5 | 133.6 | 46.7 | 2.4 | -52.1 | 292.2 | 52.6 |
| RISK BY HIS FIGURE | 11.7 | -125.3 | 0.0 | 182.8 | 12.3 | -223.7 | 0.0 | 189.1 |
| RUN DOWN | 1.4 | -18.3 | 144.0 | 25.6 | 2.2 | -17.7 | 300.5 | 37.2 |
| SAME CHARGE LATER | - | - | - | - | 0.5 | -4.5 | 0.0 | 22.8 |
| SCOUT SPOT | 0.5 | +1.8 | 0.0 | 0.0 | 0.2 | -0.0 | 0.0 | 0.0 |
| SCOUT WAITS | 0.5 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.2 | +4.9 | 0.0 | 0.0 | 0.3 | -22.6 | 0.0 | 2.1 |
| SEARCH SPOT | 5.3 | +238.5 | 0.0 | 47.2 | 4.8 | +207.5 | 0.0 | 19.8 |
| SELF MOVE SPELL | - | - | - | - | 0.4 | +71.3 | 0.0 | 30.4 |
| SET UP TOGETHER | 0.2 | +1.5 | 0.0 | 0.0 | 0.2 | +2.0 | 0.0 | 2.6 |
| SET-UP ANY TARGET | 0.2 | +17.1 | 0.0 | 0.0 | 0.2 | +12.0 | 0.0 | 0.0 |
| SET-UP MISSED | 0.2 | +46.0 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | 0.5 | +0.9 | 0.0 | 0.0 | 0.2 | +0.2 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.1 | +55.3 | 28.8 | 0.0 | 0.9 | +18.6 | 10.8 | 0.0 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SHOT OR CHARGE | 0.2 | -5.2 | 0.0 | 6.5 | 0.5 | -28.4 | 85.0 | 2.1 |
| SHOT RISK POINTS | 10.4 | +51.0 | 0.0 | 61.8 | 13.8 | -103.6 | 0.0 | 299.6 |
| SHOTS IN THE MOVE | 17.9 | +639.9 | 0.0 | 224.2 | 10.0 | +318.6 | 0.0 | 197.4 |
| SPELL SETS UP CHARGE | 0.3 | +135.8 | 0.0 | 0.0 | 0.2 | +12.0 | 0.0 | 0.0 |
| SPELL WORTH | 0.3 | +2.9 | 44.6 | 44.6 | 1.6 | +49.3 | 61.5 | 61.5 |
| SPELLS IN THE FIGHT | 0.7 | -4.6 | 82.6 | 21.6 | 0.3 | -2.3 | 75.3 | 0.0 |
| STAND AND SHOOT | 0.2 | -0.9 | 30.4 | 0.0 | 1.0 | -10.5 | 66.7 | 39.3 |
| STANDS FOR A REASON | 0.1 | +0.0 | 0.0 | 5.9 | 0.4 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 23.1 | +0.0 | 611.9 | 282.0 | 8.5 | +0.0 | 169.4 | 86.5 |
| STAY WORTH | 22.5 | +44.3 | 358.6 | 114.4 | 11.8 | +161.6 | 158.6 | 234.3 |
| STOPS | 0.1 | +4.5 | 12.7 | 0.0 | - | - | - | - |
| STUCK PIVOT | - | - | - | - | 0.2 | +0.0 | 0.0 | 16.2 |
| SUPPORT NARROWED | 0.9 | +0.0 | 107.8 | 10.5 | 1.1 | +0.0 | 94.2 | 52.6 |
| SURE REACH TOGETHER | 0.6 | +4.2 | 0.0 | 6.5 | 0.5 | +20.2 | 0.0 | 2.6 |
| THE DEARER SUM KEEPS ITS PLAN | 4.4 | +0.0 | 0.0 | 81.1 | 4.5 | +0.0 | 0.0 | 10.5 |
| THE PROMISE ADDS | 0.3 | -7.7 | 0.0 | 4.0 | 0.3 | -16.2 | 40.5 | 0.0 |
| THE PROMISED MOVE | 0.1 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 22.8 |
| TIED UP BY THE SUM | 0.5 | +45.7 | 42.8 | 4.0 | 0.4 | +40.6 | 18.1 | 28.4 |
| TIME ON OUR SIDE | 31.2 | +444.0 | 8.4 | 263.8 | 5.3 | +112.1 | 0.0 | 35.7 |
| WAITS AGAIN | 1.2 | +0.0 | 0.0 | 23.8 | 1.4 | +0.0 | 0.0 | 0.0 |
| WAR ENGINE CHARGES | - | - | - | - | 0.1 | +13.7 | 0.0 | 11.5 |
| WAR ENGINE JOBS | 0.7 | +0.0 | 63.2 | 47.7 | 0.2 | +0.0 | 6.5 | 0.0 |
| WHO HITS BACK | 0.3 | +30.4 | 0.0 | 0.0 | 0.3 | +76.0 | 0.0 | 0.0 |
| WHOLE FIGHT GAIN | 0.2 | +15.9 | 0.0 | 4.0 | 0.3 | +40.8 | 8.6 | 9.6 |
| WIDER SPREAD | 1.6 | +5.5 | 147.5 | 46.7 | 2.7 | -14.1 | 321.3 | 62.1 |
| WOUNDS ON THE RANKS | 1.5 | +67.2 | 0.0 | 0.0 | 1.4 | +43.2 | 0.0 | 0.0 |

### Rule changes: h4-opp-bbe8617-p3

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HOLDER ASSIGNMENT | 214 | 214 | 201 | 15.46 | +11479 | +57.1 |
| HIS SHOT LIST | 563 | 563 | 167 | 12.85 | +3440 | +20.6 |
| ONE TARGET A SHOOTER | 498 | 498 | 153 | 11.77 | +1657 | +10.8 |
| SEARCH SPOT | 131 | 131 | 124 | 9.54 | +5798 | +46.8 |
| DEPLOY BY FIGURES | 203 | 203 | 119 | 9.15 | +1539 | +12.9 |
| PATHS CROSS | 106 | 106 | 106 | 8.15 | +5624 | +53.1 |
| TIME ON OUR SIDE | 474 | 415 | 85 | 6.54 | +360 | +4.2 |
| LEGAL CHARGES ONLY | 77 | 77 | 77 | 5.92 | +0 | +0.0 |
| FIVE ACTION | 1175 | 1175 | 73 | 5.62 | +4864 | +66.6 |
| MOVE TO CHARGE COMPUTED | 101 | 101 | 68 | 5.23 | +5425 | +79.8 |
| SHOT RISK POINTS | 315 | 315 | 52 | 4.00 | +1366 | +26.3 |
| FOUR ROUNDS | 78 | 78 | 47 | 3.62 | +4300 | +91.5 |
| MAX FOR POSITIONING | 158 | 157 | 44 | 3.38 | +146 | +3.3 |
| HARD STAY DROPPED | 40 | 40 | 40 | 3.08 | +0 | +0.0 |
| FALLS SHORT | 338 | 301 | 30 | 2.31 | +212 | +7.1 |
| CANNON PLANNED TARGET | 118 | 118 | 28 | 2.15 | -240 | -8.6 |
| ARTILLERY RE-ROLL WEIGHED | 27 | 27 | 27 | 2.08 | +0 | +0.0 |
| COVER ONCE | 146 | 108 | 24 | 1.85 | +258 | +10.8 |
| MARCH CHECK | 34 | 34 | 24 | 1.85 | +606 | +25.2 |
| REDIRECT COUNTER | 67 | 62 | 23 | 1.77 | +1326 | +57.7 |
| IDLE COST | 178 | 142 | 21 | 1.62 | +260 | +12.4 |
| SHOTS IN THE MOVE | 363 | 339 | 21 | 1.62 | +564 | +26.9 |
| CANNON SIGHT KEPT | 19 | 19 | 19 | 1.46 | +0 | +0.0 |
| SHOOTS FROM THE BEST SPOT | 26 | 26 | 19 | 1.46 | +197 | +10.4 |
| STAY WORTH | 447 | 427 | 19 | 1.46 | +122 | +6.4 |
| NEXT CHARGE BY LIST | 143 | 143 | 17 | 1.31 | +172 | +10.1 |
| OFF BEST | 17 | 17 | 17 | 1.31 | -228 | -13.4 |
| CHARGE NOT DECLARED | 16 | 16 | 16 | 1.23 | -3167 | -198.0 |
| FOLLOW UP WEIGHED | 16 | 16 | 16 | 1.23 | +5036 | +314.8 |
| LANE BY FIGURES | 16 | 16 | 16 | 1.23 | +765 | +47.8 |
| MANOEUVRE | 39 | 39 | 16 | 1.23 | +499 | +31.2 |
| MISSILES IN THE MOVE | 114 | 88 | 15 | 1.15 | +577 | +38.5 |
| RISK BY ARC | 57 | 57 | 15 | 1.15 | +387 | +25.8 |
| ADVANCE LANE KEPT | 13 | 13 | 13 | 1.00 | +0 | +0.0 |
| CHARGE LOSSES | 142 | 142 | 13 | 1.00 | +557 | +42.9 |
| LONE WIZARD KEPT IN | 13 | 13 | 13 | 1.00 | +1236 | +95.0 |
| RISK BY HIS FIGURE | 312 | 312 | 13 | 1.00 | +846 | +65.1 |
| NEXT OBJECTIVE NEARER | 98 | 98 | 12 | 0.92 | +390 | +32.5 |
| RANDOM MOVE BY FIGURES | 22 | 22 | 12 | 0.92 | +287 | +23.9 |
| AFTERMATH IN POINTS | 11 | 11 | 11 | 0.85 | +1308 | +118.9 |
| CHARGE NOW FIRST | 38 | 38 | 11 | 0.85 | -522 | -47.4 |
| HIS TURN DENIED | 42 | 42 | 11 | 0.85 | +430 | +39.1 |
| RESERVE FALL BACK | 11 | 11 | 11 | 0.85 | +744 | +67.6 |
| TIED UP BY THE SUM | 11 | 11 | 11 | 0.85 | +416 | +37.9 |
| HOLDS AMBUSHERS | 10 | 10 | 10 | 0.77 | +0 | +0.0 |
| ONE OBJECTIVE FORMULA | 123 | 105 | 10 | 0.77 | +251 | +25.1 |
| WOUNDS ON THE RANKS | 37 | 37 | 10 | 0.77 | +235 | +23.5 |
| HOLDER AT DEPLOYMENT | 15 | 15 | 9 | 0.69 | +349 | +38.8 |
| SCOUT WAITS | 9 | 9 | 9 | 0.69 | +0 | +0.0 |
| CASTING BLOCK | 9 | 9 | 8 | 0.62 | +371 | +46.4 |
| CHAFF IN THE MOVE | 9 | 9 | 8 | 0.62 | +14 | +1.8 |
| COMBAT PIVOT | 8 | 8 | 8 | 0.62 | +0 | +0.0 |
| MARCH BY THE SUM | 8 | 8 | 8 | 0.62 | +288 | +35.9 |
| ONE FIGHT FORMULA | 134 | 74 | 8 | 0.62 | +49 | +6.2 |
| SHOOTERS IN TWO RANKS | 8 | 8 | 8 | 0.62 | +14 | +1.8 |
| WHO HITS BACK | 8 | 8 | 8 | 0.62 | +1025 | +128.1 |
| FIRE IN ORDER | 7 | 7 | 7 | 0.54 | +0 | +0.0 |
| QUARTER ODDS | 38 | 38 | 7 | 0.54 | +712 | +101.8 |
| CASTER AWAY FROM SCREEN | 6 | 6 | 6 | 0.46 | +0 | +0.0 |
| REDIRECT WEIGHED | 6 | 6 | 6 | 0.46 | +736 | +122.6 |
| WHOLE FIGHT GAIN | 7 | 7 | 6 | 0.46 | +419 | +69.8 |
| CHAFF PASSED | 5 | 5 | 5 | 0.38 | -8 | -1.7 |
| FEATURE BUFFS | 36 | 36 | 5 | 0.38 | +26 | +5.2 |
| FIGHT TO THE END | 31 | 31 | 5 | 0.38 | +669 | +133.9 |
| MODEL FACING | 5 | 5 | 5 | 0.38 | +1416 | +283.1 |
| NEARER NOT NEEDED | 137 | 132 | 5 | 0.38 | +162 | +32.4 |
| SURE REACH TOGETHER | 15 | 14 | 5 | 0.38 | +12 | +2.4 |
| CAST JOB | 13 | 13 | 4 | 0.31 | +3 | +0.7 |
| KEEP FALLS | 4 | 4 | 4 | 0.31 | +92 | +23.0 |
| BEST PRIZE | 3 | 3 | 3 | 0.23 | -209 | -69.8 |
| HIS CHARGE DENIED | 10 | 10 | 3 | 0.23 | +16 | +5.4 |
| MOVES UNITS SPELL | 3 | 3 | 3 | 0.23 | +118 | +39.2 |
| OPENS UP | 6 | 6 | 3 | 0.23 | +198 | +66.1 |
| OVERRUNS AWAY | 11 | 11 | 3 | 0.23 | +88 | +29.3 |
| PIVOT GUARDS FLANK | 3 | 3 | 3 | 0.23 | -37 | -12.5 |
| PURSUES BIG PREY | 3 | 3 | 3 | 0.23 | -333 | -111.1 |
| SHORT GUN FORWARD | 3 | 3 | 3 | 0.23 | +0 | +0.0 |
| SUPPORT NARROWED | 26 | 26 | 3 | 0.23 | -23 | -7.8 |
| FRIENDS SHOTS CHECKED | 2 | 2 | 2 | 0.15 | +166 | +83.1 |
| HIS MOVE AND SHOT | 43 | 43 | 2 | 0.15 | +29 | +14.5 |
| HUNT IN PAIRS | 6 | 4 | 2 | 0.15 | +110 | +55.1 |
| MISSILES NEXT TURN | 136 | 103 | 2 | 0.15 | +11 | +5.3 |
| NO RALLY LEFT | 2 | 2 | 2 | 0.15 | +63 | +31.3 |
| REFORMS TO MEET IT | 18 | 18 | 2 | 0.15 | +1 | +0.7 |
| RESTRAINS TO SHOOT | 2 | 2 | 2 | 0.15 | +22 | +10.8 |
| SET UP TOGETHER | 5 | 3 | 2 | 0.15 | +23 | +11.6 |
| STUCK PIVOT | 2 | 2 | 2 | 0.15 | +0 | +0.0 |
| BOMBING RUN | 1 | 1 | 1 | 0.08 | +27 | +27.2 |
| CATCH ODDS | 1 | 1 | 1 | 0.08 | -118 | -117.8 |
| CHARGER SLAIN LOST | 12 | 12 | 1 | 0.08 | +18 | +18.3 |
| DEFENSIVE FLOOR | 1 | 1 | 1 | 0.08 | +0 | +0.0 |
| EDGE GIVE GROUND | 2 | 2 | 1 | 0.08 | +27 | +26.7 |
| FACES THE THREAT | 1 | 1 | 1 | 0.08 | +58 | +58.3 |
| FALLBACK BY WORTH | 8 | 8 | 1 | 0.08 | +22 | +21.5 |
| GUN MASK | 18 | 18 | 1 | 0.08 | +4 | +3.9 |
| KEEPS SCOUTS OR AMBUSH | 1 | 1 | 1 | 0.08 | +0 | +0.0 |
| KILLS COUNT | 1 | 1 | 1 | 0.08 | +0 | +0.0 |
| NEEDED THERE | 1 | 1 | 1 | 0.08 | +0 | +0.0 |
| NO DOUBLE ROUNDS | 66 | 66 | 1 | 0.08 | +117 | +117.2 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.08 | +54 | +54.0 |
| SAME CHARGE LATER | 6 | 6 | 1 | 0.08 | +1 | +0.9 |
| SCREEN BY WHAT IT SAVES | 6 | 6 | 1 | 0.08 | +0 | +0.0 |
| SPELLS IN THE FIGHT | 13 | 13 | 1 | 0.08 | +0 | +0.0 |
| THE PROMISE ADDS | 8 | 8 | 1 | 0.08 | +1 | +1.1 |
| WAR ENGINE CHARGES | 1 | 1 | 1 | 0.08 | +114 | +113.5 |
| ALREADY CARRIED | 1 | not checked | - | - | - | - |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| BACKUP TARGETS | 4 | 2 | 0 | 0.00 | - | - |
| BLOWS WHERE AIMED | 5 | 5 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 16 | 16 | 0 | 0.00 | - | - |
| CARRIES OUT SET-UP | 1 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 18 | trace | - | - | - | - |
| CATCH FLIERS | 1 | not checked | - | - | - | - |
| CHARACTER GUNS | 10 | 10 | 0 | 0.00 | - | - |
| CHEAP HELPER | 2 | not checked | - | - | - | - |
| CHEAPEST HOLDER | 6 | 6 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 26 | not checked | - | - | - | - |
| DEFENSIVE ARMY | 1 | 1 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 61 | 61 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 141 | not checked | - | - | - | - |
| FRIEND CHARGES FIRST | 1 | 1 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 16 | 16 | 0 | 0.00 | - | - |
| GIVES UP | 5 | 5 | 0 | 0.00 | - | - |
| GROUND FLIERS | 1 | not checked | - | - | - | - |
| GUN FIGURES | 18 | not checked | - | - | - | - |
| HE SHOOTS OR CHARGES | 54 | 54 | 0 | 0.00 | - | - |
| HELPER ALREADY ASKED | 2 | not checked | - | - | - | - |
| HIS CHARGE LIST | 75 | 75 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 74 | 74 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 38 | 38 | 0 | 0.00 | - | - |
| HOLD ODDS | 111 | 111 | 0 | 0.00 | - | - |
| HONEST WORTH | 63 | 63 | 0 | 0.00 | - | - |
| HUNT RESULT | 1 | trace | - | - | - | - |
| HUNT THE GUNS | 1 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 4 | 4 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 9 | not checked | - | - | - | - |
| LONG SHOT | 9 | 9 | 0 | 0.00 | - | - |
| LOST CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 2 | 2 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 4 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 3 | trace | - | - | - | - |
| MARCH OVER CASTS | 22 | 22 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 6 | 2 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 18 | trace | - | - | - | - |
| MOVE SPELL SPOT | 7 | not checked | - | - | - | - |
| NOT TURNED | 11 | 11 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 7 | not checked | - | - | - | - |
| ONE CHARGE A CHARGER | 61 | 61 | 0 | 0.00 | - | - |
| OPENS A LANE | 4 | 3 | 0 | 0.00 | - | - |
| PLAN RESULT | 1052 | trace | - | - | - | - |
| REDIRECT BY WHAT IT STOPS | 8 | 8 | 0 | 0.00 | - | - |
| REFUSING RETIRES | 3 | 3 | 0 | 0.00 | - | - |
| RUN DOWN | 47 | 47 | 0 | 0.00 | - | - |
| SCOUT SPOT | 8 | 8 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 5 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 4 | not checked | - | - | - | - |
| SET-UP MISSED | 2 | trace | - | - | - | - |
| SHOT OR CHARGE | 8 | 8 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 6 | not checked | - | - | - | - |
| SPELL WORTH | 25 | not checked | - | - | - | - |
| STAND AND SHOOT | 15 | 15 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 6 | 6 | 0 | 0.00 | - | - |
| STANDS STILL | 410 | 410 | 0 | 0.00 | - | - |
| STOPS | 1 | 1 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 116 | not checked | - | - | - | - |
| THE PROMISED MOVE | 14 | not checked | - | - | - | - |
| WAITS AGAIN | 33 | 33 | 0 | 0.00 | - | - |
| WAR ENGINE JOBS | 11 | 11 | 0 | 0.00 | - | - |
| WIDER SPREAD | 56 | 56 | 0 | 0.00 | - | - |

### Off best figure: h4-opp-bbe8617-p3

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| HOLDER ASSIGNMENT | rule | - | 1.92 | 27.2 |
| PATHS CROSS | rule | 0.92 | 0.54 | 31.1 |
| CHARGE NOT DECLARED | rule | 0.46 | 0.77 | 198.0 |
| CHARGE NOW FIRST | rule | 0.31 | 0.54 | 47.4 |
| CANNON PLANNED TARGET | rule | 0.46 | 0.08 | 50.5 |
| AFTERMATH BAND | gate | 0.08 | 0.23 | 2.5 |
| JOB FIRST | gate | 0.31 | - | 28.9 |
| BEST PRIZE | rule | - | 0.23 | 69.8 |
| CHAFF PASSED | rule | - | 0.23 | 2.8 |
| LONE CHARACTER SAFE SPOT | gate | 0.23 | - | 13.4 |
| PIVOT GUARDS FLANK | rule | 0.08 | 0.15 | 12.5 |
| PURSUES BIG PREY | rule | 0.15 | 0.08 | 111.1 |
| SUPPORT NARROWED | rule | - | 0.23 | 7.8 |
| TURN GATE | gate | 0.23 | - | 8.0 |
| FALLBACK | gate | 0.15 | - | 11.4 |
| CATCH ODDS | rule | 0.08 | - | 117.8 |
| DEPLOY BY FIGURES | rule | - | 0.08 | 4.7 |
| NO REASON | gate | - | 0.08 | 15.3 |
| WHO HITS BACK | rule | - | 0.08 | 1.3 |

### Plans: h4-opp-bbe8617-p3

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.8 | 61% | 241 | 193 | 80% |
| Mine | join | 1.5 | 95% | 66 | 0 | 0% |
| Mine | move | 26.4 | 96% | 1564 | 0 | 0% |
| Mine | shoot | 12.9 | 67% | 626 | 797 | 127% |
| Mine | support | 0.5 | 100% | 7 | 0 | 0% |
| Opponent | charge | 3.2 | 56% | 705 | 342 | 48% |
| Opponent | move | 30.3 | 93% | 2362 | 0 | 0% |
| Opponent | shoot | 3.9 | 55% | 219 | 205 | 94% |
| Opponent | support | 0.5 | 50% | 0 | 0 | - |

### Packages: hunt the guns, h4-opp-bbe8617-p3

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.1 | 1 | 0 | 100% | 100% | 0% | 2.0 | 335 | 278 | 100% | 7 |
| Opponent | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 93 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.2 | 1 | 0 | 100% | 100% | 0% | 2.0 | 335 | 278 | 100% | 21 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 45 |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 234 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 416 |
| Vampire Counts | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 110 |
| Warriors of Chaos | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 78 |
| Wood Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |

### Battle groups: h4-opp-bbe8617-p3

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 1.7 | 18% | 25% | 0% | - | 50% | 0% | 0% | 50% | 0% |
| Opponent | REDIRECT COUNTER | 3.5 | 20% | 67% | 11% | 100% | 25% | 0% | 50% | 25% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: h4-opp-bbe8617-p3

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 9 | 38 (9) | 23 | 14 | 28 | 67% | 3.0 | 16 (3) | 81 (3) | 0 (3) | 41 (8) | 0 (1) |
| Mine | Character | 51 | 24 (51) | 21 | 3 | 22 | 24% | 2.1 | 27 (12) | 23 (30) | 31 (6) | 22 (31) | 32 (17) |
| Mine | Clean-up | 8 | 102 (8) | 102 | 0 | 45 | 38% | 2.2 | 0 (2) | 7 (3) | 306 (3) | 227 (4) | 0 (4) |
| Mine | Fast Hammer | 11 | 42 (11) | 15 | 27 | 74 | 18% | 3.0 | 18 (4) | 115 (3) | 0 (4) | 47 (9) | 0 (2) |
| Mine | Fragile | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Mine | Hammer | 25 | 44 (25) | 18 | 25 | 28 | 28% | 2.3 | 50 (5) | 43 (18) | 0 (2) | 45 (20) | 39 (5) |
| Mine | Holder | 16 | 87 (16) | 0 | 87 | 21 | 69% | 3.0 | 0 (1) | 75 (7) | 106 (8) | 100 (11) | 55 (5) |
| Mine | Shooter | 13 | 106 (13) | 11 | 94 | 14 | 0% | 2.3 | 19 (4) | 153 (6) | 110 (3) | 143 (7) | 57 (6) |
| Mine | War machine | 30 | 34 (30) | 34 | 0 | 42 | 3% | 1.4 | 40 (8) | 30 (16) | 41 (6) | 40 (11) | 31 (19) |
| Mine | Wizard | 8 | 39 (8) | 39 | 0 | 34 | 12% | 4.3 | 0 (1) | 44 (7) | - | 0 (3) | 64 (5) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Chaff | 25 | 114 (25) | 17 | 97 | 39 | 44% | 3.6 | 165 (8) | 142 (9) | 25 (8) | 149 (16) | 62 (9) |
| Opponent | Character | 36 | 50 (36) | 50 | 0 | 14 | 22% | 2.1 | 18 (4) | 45 (20) | 69 (11) | 55 (19) | 45 (16) |
| Opponent | Clean-up | 4 | 68 (4) | 34 | 34 | 44 | 0% | 2.2 | - | 68 (4) | - | 47 (3) | 123 (1) |
| Opponent | Fast | 1 | 187 (1) | 187 | 0 | 100 | 100% | - | 187 (1) | - | - | 187 (1) | - |
| Opponent | Fast Hammer | 20 | 47 (20) | 9 | 38 | 17 | 45% | 2.6 | 56 (4) | 28 (10) | 78 (6) | 43 (12) | 53 (8) |
| Opponent | Fragile | 2 | 0 (2) | 0 | 0 | 45 | 50% | 1.0 | - | - | 0 (2) | 0 (1) | 0 (1) |
| Opponent | Hammer | 16 | 16 (16) | 7 | 9 | 37 | 38% | 2.5 | 0 (3) | 32 (5) | 9 (8) | 15 (11) | 18 (5) |
| Opponent | Holder | 9 | 100 (9) | 0 | 100 | 13 | 78% | 5.0 | 295 (1) | 90 (7) | 0 (1) | 117 (4) | 84 (5) |
| Opponent | Shooter | 10 | 104 (10) | 7 | 97 | 22 | 10% | 1.9 | 0 (2) | 141 (6) | 112 (2) | 124 (5) | 80 (5) |
| Opponent | War machine | 8 | 8 (8) | 8 | 0 | 73 | 12% | 2.3 | 10 (5) | 0 (3) | - | - | 8 (8) |
| Opponent | Wizard | 3 | 4 (3) | 4 | 0 | 12 | 0% | 2.7 | - | 0 (1) | 9 (1) | 4 (2) | - |

### Charged fights: h4-opp-bbe8617-p3

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 181 | 130 | 2.0 | 1.2 | 65 | 56 | +9 | 5 of 8 | 4 of 8 | -222 | +42 |
| Mine | Chaos Dwarfs | 4 | 261 | 127 | 1.5 | 1.2 | 84 | 0 | +84 | 2 of 6 | 6 of 6 | +0 | +101 |
| Mine | Dwarfen Mountain Holds | 3 | 298 | 0 | 0.3 | 1.0 | 0 | 0 | +0 | 1 of 1 | 1 of 1 | - | +0 |
| Mine | Empire of Man | 2 | 122 | 465 | 3.5 | 1.1 | 133 | 0 | +133 | 1 of 7 | 6 of 7 | +293 | +106 |
| **Mine** | all armies | 13 | 224 | 150 | 1.7 | 1.2 | 89 | 20 | +69 | 9 of 22 | 17 of 22 | +24 | +76 |
| Opponent | Grand Cathay | 3 | 308 | 105 | 1.3 | 1.0 | 79 | 0 | +79 | 2 of 4 | 3 of 4 | - | +79 |
| Opponent | High Elf Realms | 2 | 42 | 728 | 3.5 | 1.0 | 208 | 16 | +191 | 3 of 7 | 5 of 7 | - | +191 |
| Opponent | Ogre Kingdoms | 1 | 65 | 190 | 4.0 | 1.0 | 48 | 0 | +48 | 2 of 4 | 1 of 4 | - | +48 |
| Opponent | Skaven | 1 | 225 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 1 of 1 | 0 of 1 | - | +0 |
| Opponent | Vampire Counts | 1 | 314 | 715 | 6.0 | 1.3 | 119 | 0 | +119 | 4 of 6 | 5 of 6 | +526 | +38 |
| Opponent | Warriors of Chaos | 4 | 78 | 248 | 2.8 | 1.1 | 90 | 25 | +65 | 6 of 11 | 7 of 11 | +140 | +58 |
| Opponent | Wood Elf Realms | 1 | 95 | 795 | 4.0 | 1.2 | 199 | 0 | +199 | 4 of 4 | 0 of 4 | +795 | +0 |
| **Opponent** | all armies | 13 | 155 | 343 | 2.8 | 1.1 | 121 | 10 | +110 | 22 of 37 | 21 of 37 | +487 | +77 |

### Effective charges: h4-opp-bbe8617-p3

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 8 | 5 (net +7) | 0 | 0 | 1 (net +0) | 0 | 1 (net +41) | 1 | 0% (0 of 7) |
| Mine | Chaos Dwarfs | 6 | 0 | 0 | 1 (net +0) | 1 (net +170) | 1 (net +0) | 3 (net +112) | 0 | 17% (1 of 6) |
| Mine | Dwarfen Mountain Holds | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +0) | 0 | 0% (0 of 1) |
| Mine | Empire of Man | 7 | 0 | 0 | 1 (net +0) | 4 (net +166) | 1 (net +105) | 1 (net +162) | 0 | 14% (1 of 7) |
| Opponent | Grand Cathay | 4 | 1 (net +238) | 0 | 1 (net +0) | 0 | 0 | 2 (net +38) | 0 | 25% (1 of 4) |
| Opponent | High Elf Realms | 7 | 0 | 0 | 2 (net +405) | 2 (net +98) | 2 (net +168) | 0 | 1 | 33% (2 of 6) |
| Opponent | Ogre Kingdoms | 4 | 1 (net +0) | 1 (net +190) | 1 (net +0) | 0 | 0 | 0 | 1 | 33% (1 of 3) |
| Opponent | Skaven | 1 | 1 (net +0) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 1) |
| Opponent | Vampire Counts | 6 | 0 | 0 | 2 (net +0) | 2 (net +263) | 0 | 2 (net +94) | 0 | 33% (2 of 6) |
| Opponent | Warriors of Chaos | 11 | 2 (net -136) | 0 | 0 | 1 (net +0) | 2 (net +70) | 3 (net +283) | 3 | 0% (0 of 8) |
| Opponent | Wood Elf Realms | 4 | 1 (net +0) | 0 | 0 | 2 (net +398) | 0 | 0 | 1 | 0% (0 of 3) |

### Charged fights, damage counted: h4-opp-bbe8617-p3

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 5 | 86 | 373 | +7 | 115 | 94 | +21 | +24.6 |
| Mine | Effective (55-75%) | 2 | 152 | 254 | +0 | 40 | 0 | +40 | +26.0 |
| Mine | 76-89% | 6 | 274 | 134 | +139 | 152 | 4 | +148 | +54.0 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 6 | 206 | 163 | +90 | 108 | 31 | +77 | +37.5 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 2 | 514 | 110 | +52 | 108 | 27 | +81 | +15.7 |
| Mine | No odds | 1 | 836 | 358 | +0 | 274 | 40 | +234 | +28.0 |
| Mine | All fights | 22 | 249 | 215 | +69 | 123 | 35 | +88 | +35.3 |
| Opponent | Long shot (under 50%) | 6 | 196 | 234 | -6 | 64 | 48 | +16 | +8.4 |
| Opponent | 50-54% | 1 | 40 | 95 | +190 | 253 | 4 | +249 | +623.3 |
| Opponent | Effective (55-75%) | 6 | 287 | 270 | +135 | 146 | 11 | +135 | +46.9 |
| Opponent | 76-89% | 7 | 575 | 225 | +217 | 271 | 24 | +247 | +42.9 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 7 | 374 | 199 | +159 | 166 | 3 | +162 | +43.4 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 4 | 487 | 118 | +119 | 136 | 0 | +136 | +28.0 |
| Opponent | No odds | 6 | 249 | 276 | +0 | 6 | 62 | -57 | -22.8 |
| Opponent | All fights | 37 | 352 | 222 | +110 | 139 | 25 | +114 | +32.5 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| h4-opp-bbe8617-p3 | move | 95 | 25 (26%) | 17 (18%) | 10 (11%) | 60 (63%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0111, L0128 |
| Charmed Shield | Opponent | L0534, L0726 |
| Elixir of Power | Opponent | L0111, L0211 |
| Fistful of Laurels | Opponent | L0518 |
| Periapt of Soul Exchange | Opponent | L0621 |
| Ring of Doom | Mine | L0211, L0228 |
| Ring of Doom | Opponent | L0111, L0211, L0415 |
| Ring of Jet | Opponent | L0111, L0211, L0710 |
| Standard of the Fell Warrior | Opponent | L0313 |
| Storm Daemon (Renegade 2.0) | Opponent | L0621 |
| Twice-Blessed Armour | Mine | L0710, L0726 |
| Twice-Blessed Armour | Opponent | L0710 |
| Witch Hunter's Ward | Mine | L0710, L0726 |

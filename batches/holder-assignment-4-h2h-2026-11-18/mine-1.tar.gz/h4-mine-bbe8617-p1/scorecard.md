# Doctrine scorecard: h4-mine-bbe8617-p1

### Scorecard: h4-mine-bbe8617-p1

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0103 | 1 | 1 | Mine | no | 4 | - | 0 | 3 | 0 | 0 | 0 | 0 |
| L0103 | 1 | 1 | Opponent | no | 0 | 5 | 0 | 0 | 0 | 0 | 0 | 590 |
| L0120 | 6 | 1 | Mine | no | 7 | - | 0 | 1 | 0 | 0 | 0 | 0 |
| L0120 | 6 | 1 | Opponent | no | 0 | 6 | 0 | 4 | 0 | 0 | 0 | 210 |
| L0204 | 6 | 1 | Mine | no | 1 | 5 | 1 | 4 | 1 | 0 | 0 | 170 |
| L0204 | 6 | 1 | Opponent | no | 0 | 1 | 1 | 1 | 0 | 0 | 0 | 0 |
| L0219 | 3 | 1 | Mine | no | 9 | 2 | 4 | 1 | 1 | 0 | 0 | 255 |
| L0219 | 3 | 1 | Opponent | yes | 3 | 2 | 1 | 1 | 0 | 0 | 0 | 0 |
| L0304 | 4 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 320 |
| L0304 | 4 | 1 | Opponent | no | 5 | 3 | 2 | 3 | 0 | 0 | 0 | 310 |
| L0321 | 3 | 1 | Mine | no | 7 | - | 0 | 0 | 0 | 0 | 0 | 225 |
| L0321 | 3 | 1 | Opponent | yes | 4 | - | 0 | 4 | 1 | 0 | 0 | 420 |
| L0406 | 4 | 1 | Mine | no | 2 | 3 | 2 | 3 | 0 | 0 | 0 | 0 |
| L0406 | 4 | 1 | Opponent | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 644 |
| L0423 | 3 | 1 | Mine | no | 3 | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L0423 | 3 | 1 | Opponent | no | 4 | 2 | 3 | 1 | 2 | 0 | 0 | 0 |
| L0510 | 6 | 1 | Mine | no | 8 | - | 0 | 2 | 0 | 0 | 0 | 208 |
| L0510 | 6 | 1 | Opponent | no | 4 | 2 | 1 | 0 | 1 | 0 | 0 | 0 |
| L0525 | 3 | 1 | Mine | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 478 |
| L0525 | 3 | 1 | Opponent | no | 5 | 3 | 2 | 4 | 0 | 0 | 0 | 0 |
| L0613 | 1 | 1 | Mine | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 819 |
| L0613 | 1 | 1 | Opponent | no | 0 | 3 | 2 | 1 | 2 | 0 | 0 | 0 |
| L0630 | 6 | 1 | Mine | no | 0 | - | 3 | 2 | 0 | 0 | 0 | 175 |
| L0630 | 6 | 1 | Opponent | no | 7 | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| L0718 | 4 | 1 | Mine | no | 0 | 2 | 2 | 1 | 0 | 0 | 0 | 247 |
| L0718 | 4 | 1 | Opponent | no | 0 | 2 | 5 | 1 | 1 | 0 | 0 | 228 |
| L0734 | 2 | 1 | Mine | - | - | - | 0 | 2 | 0 | 0 | 0 | 295 |
| L0734 | 2 | 1 | Opponent | - | - | 2 | 6 | 3 | 0 | 0 | 0 | 0 |
| L0824 | 2 | 1 | Mine | - | - | 3 | 2 | 2 | 0 | 0 | 0 | 492 |
| L0824 | 2 | 1 | Opponent | - | - | 2 | 1 | 4 | 0 | 0 | 0 | 0 |
| L0915 | 3 | 1 | Mine | no | 1 | 6 | 1 | 1 | 0 | 0 | 0 | 0 |
| L0915 | 3 | 1 | Opponent | yes | 6 | 2 | 2 | 2 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 0% | 3.0 | 3.3 | 1.2 | 1.8 | 0.1 | 0.0 | 0.0 | 230.2 |
| **Average** | | | Opponent | 21% | 2.7 | 2.6 | 1.8 | 2.0 | 0.4 | 0.0 | 0.0 | 150.1 |

### KPIs: h4-mine-bbe8617-p1

Rules off - Opponent only: HOLDER ASSIGNMENT, QUARTER ODDS.

Morten 2026-11-10; 16 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 51% (34 of 67) | 8% (6 of 78) | 28% (40 of 145) |
| Winner chose to follow up after the loser gave ground |  | 71% (12 of 17); on the table 76% | 92% (11 of 12); on the table 92% | 79% (23 of 29); on the table 83% |
| Winner chose to pursue after the loser fell back in good order |  | 75% (3 of 4); on the table 75% | 100% (4 of 4); on the table 100% | 88% (7 of 8); on the table 88% |
| Winner chose to pursue after the loser fled |  | 78% (7 of 9); on the table 100% | 73% (11 of 15); on the table 73% | 75% (18 of 24); on the table 83% |
| Winner chose to follow up or pursue (all three) |  | 73% (22 of 30); on the table 83% | 84% (26 of 31); on the table 84% | 79% (48 of 61); on the table 84% |
| Magic missiles tried each own turn | 50%+ | 40% (65 of 162) | 24% (22 of 90) | 35% (87 of 252) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 45% (65 of 143) | 34% (22 of 64) | 42% (87 of 207) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 43% (3 of 7) | 58% (11 of 19) | 54% (14 of 26) |
| Points that never fought | lower | 59% (18096 of 30785) | 57% (18076 of 31989) | 58% (36172 of 62774) |
|   infantry points that never fought | lower | 70% (5997 of 8571) | 78% (5508 of 7047) | 74% (11505 of 15618) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 61% (78 of 128) | 52% (64 of 122) | 57% (142 of 250) |
| Bound items with a magic missile used (at least once a game) |  | 100% (6 of 6); 1.3 uses a game | 71% (5 of 7); 1.3 uses a game | 85% (11 of 13); 1.3 uses a game |
| Bound items with another spell used |  | 75% (3 of 4); 0.5 uses a game | 67% (2 of 3); 0.3 uses a game | 71% (5 of 7); 0.4 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 45% (5 of 11); 0.3 uses a game | 71% (5 of 7); 0.3 uses a game | 56% (10 of 18); 0.3 uses a game |
|   their share of the points of units over 100 pts | lower | 56% (13724 of 24355) | 49% (13680 of 27829) | 53% (27404 of 52184) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 3.4 (57%) | 0.9 (21%) | 4.3 (42%) |
| MARCHED: its unit marched | 1.4 (24%) | 1.0 (24%) | 2.4 (24%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.4 (9%) | 0.4 (4%) |
| IN COMBAT: engaged in combat | 0.6 (10%) | 0.5 (12%) | 1.1 (11%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.1 (1%) | 0.1 (1%) |
| FLEEING: fleeing | 0.0 (0%) | 0.6 (13%) | 0.6 (5%) |
| GONE: slain | 0.6 (9%) | 0.6 (13%) | 1.1 (11%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.3 (7%) | 0.3 (3%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.1 | 0.8 | 2.4 | 5.4 | 0.4 | 1.1 |
| not cast | 3.1 | 2.2 | 3.6 | 10.3 | 1.9 | 17.7 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.1 (2%) | 0.0 (0%) | 0.0 (0%) | 0.6 (4%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.1 (47%) | 0.8 (22%) | 4.3 (42%) | 0.1 (7%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.4 (24%) | 0.2 (10%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.4 (4%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.1 (2%) | 0.0 (0%) | 0.2 (7%) | 1.1 (11%) | 0.1 (7%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.4 (12%) | 0.4 (17%) | 0.0 (0%) | 0.1 (1%) | 0.4 (20%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (0%) | 0.2 (11%) | 0.1 (2%) | 0.6 (5%) | 0.2 (13%) | 0.2 (1%) |
| GONE: slain | 0.4 (14%) | 0.2 (8%) | 0.4 (12%) | 1.1 (11%) | 0.4 (20%) | 1.5 (8%) |
| STUPIDITY: Stupidity | 0.1 (2%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.2 (11%) | 0.0 (0%) | 0.0 (0%) | 0.4 (23%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (3%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.1 (69%) | 0.1 (6%) | 2.0 (55%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 15.4 (87%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.8 a game | 1.0 a game | 1.4 a game |
| stood (cast and not dispelled) | 68% (19 of 28) | 56% (5 of 9) | 65% (24 of 37) |
| the unit moved after it | 58% (11 of 19) | 100% (5 of 5) | 67% (16 of 24) |
| it charged on its next turn | 0% (0 of 19) | 0% (0 of 5) | 0% (0 of 24) |
| the enemy charged it first | 16% (3 of 19) | 20% (1 of 5) | 17% (4 of 24) |
| it fought by the end of its next turn | 11% (2 of 19) | 0% (0 of 5) | 8% (2 of 24) |
| it moved out of a charge the enemy had planned (not charged first) | 5% (1 of 19) | 0% (0 of 5) | 4% (1 of 24) |
| none of these (no charge, no fight, no charge escaped) | 79% (15 of 19) | 80% (4 of 5) | 79% (19 of 24) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 65% (304 of 469) | 61% (201 of 330) | 63% (505 of 799) |
|   cavalry | 46% (13 of 28) | 77% (23 of 30) | 62% (36 of 58) |
|   character | 82% (37 of 45) | 23% (10 of 43) | 53% (47 of 88) |
|   chariot | 48% (20 of 42) | 43% (24 of 56) | 45% (44 of 98) |
|   infantry | 50% (65 of 131) | 63% (70 of 111) | 56% (135 of 242) |
|   monster | 78% (14 of 18) | 93% (13 of 14) | 84% (27 of 32) |
|   war machine | 76% (155 of 205) | 80% (61 of 76) | 77% (216 of 281) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.3 (22%) | 1.9 (24%) | 4.2 (23%) |
| CHARGED: it charged | 0.2 (2%) | 1.2 (16%) | 1.5 (8%) |
| FLEEING: it fled or was fleeing | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| IN COMBAT: it fought this turn or the last | 0.8 (7%) | 0.3 (4%) | 1.1 (6%) |
| MOVED: a war machine that moved | 1.5 (15%) | 0.4 (5%) | 1.9 (11%) |
| NO TARGET IN RANGE | 1.9 (19%) | 1.4 (17%) | 3.3 (18%) |
| ONLY IN COMBAT: the only targets were in combat | 0.3 (3%) | 0.8 (10%) | 1.1 (6%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 2.2 (21%) | 1.4 (18%) | 3.6 (20%) |
| SHELTERED: the target was sheltered | 0.3 (3%) | 0.2 (3%) | 0.6 (3%) |
| STUPIDITY | 0.1 (1%) | 0.0 (0%) | 0.1 (0%) |
| OTHER BAR | 0.6 (5%) | 0.2 (3%) | 0.8 (4%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 2.8 | 0.3 | 91% | 2.6 pts | 7 pts |
| character | 3.6 | 0.9 | 84% | 8.4 pts | 30 pts |
| chariot | 2.8 | 2.1 | 62% | 16.3 pts | 46 pts |
| infantry | 12.5 | 3.9 | 79% | 6.4 pts | 81 pts |
| monster | 1.9 | 0.4 | 80% | 7.0 pts | 13 pts |
| war machine | 13.5 | 16.4 | 65% | 44.3 pts | 597 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 2.0 | 5.6 | 3.8 |
| Charges that made contact a game | 1.8 | 3.7 | 2.8 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.38 declared, 0.38 contact (8 units) | 0.91 declared, 0.55 contact (11 units) | 0.68 declared, 0.47 contact (19 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 1.25 declared, 0.75 contact (4 units) | 1.25 declared, 0.75 contact (4 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.26 declared, 0.24 contact (110 units) | 0.59 declared, 0.40 contact (126 units) | 0.44 declared, 0.32 contact (236 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 45% (9 of 20) | 43% (3 of 7) | 100% (1 of 1) | 46% (13 of 28) |
| Character in a unit | 93% (25 of 27) | 57% (8 of 14) | - | 80% (33 of 41) |
| Character on its own | 70% (7 of 10) | 27% (3 of 11) | 40% (8 of 20) | 44% (18 of 41) |
| Chariot | 50% (3 of 6) | 57% (8 of 14) | - | 55% (11 of 20) |
| Infantry | 40% (16 of 40) | 38% (8 of 21) | 100% (1 of 1) | 40% (25 of 62) |
| Monster | 43% (3 of 7) | 80% (4 of 5) | - | 58% (7 of 12) |
| Monstrous | 50% (1 of 2) | 60% (3 of 5) | - | 57% (4 of 7) |
| War Machines | 78% (28 of 36) | 100% (3 of 3) | - | 79% (31 of 39) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 100% (8 of 8); on the table 100% | 46% (47 of 102) | 61% | 45% (10 of 22) | 100% (6 of 6); 5.2 uses a game | 100% (2 of 2); 1.5 uses a game | 67% (4 of 6); 1.0 uses a game |
| Chaos Dwarfs | 7 | 92% (11 of 12); on the table 92% | 23% (14 of 60) | 54% | 52% (28 of 54) | 0.0 uses a game | 0.0 uses a game | 67% (2 of 3); 0.3 uses a game |
| Dwarfen Mountain Holds | 5 | 17% (1 of 6); on the table 50% | - | 69% | 70% (31 of 44) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 4 | 62% (5 of 8); on the table 75% | 50% (12 of 24) | 50% | 69% (29 of 42) | 0.0 uses a game | 50% (1 of 2); 0.5 uses a game | 0% (0 of 3); 0.0 uses a game |
| Grand Cathay | 1 | - | 20% (6 of 30) | 58% | 50% (5 of 10) | 0% (0 of 2); 0.0 uses a game | 0% (0 of 1); 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| High Elf Realms | 2 | 100% (6 of 6); on the table 100% | 0% (0 of 6) | 64% | 40% (6 of 15) | 100% (3 of 3); 5.5 uses a game | 100% (2 of 2); 2.5 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 1 | 0% (0 of 1); on the table 0% | 0% (0 of 6) | 35% | 57% (4 of 7) | 100% (1 of 1); 5.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 1 | 100% (4 of 4); on the table 100% | 33% (2 of 6) | 27% | 38% (3 of 8) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Skaven | 2 | 75% (3 of 4); on the table 75% | 33% (4 of 12) | 84% | 56% (9 of 16) | 100% (1 of 1); 2.5 uses a game | 0.0 uses a game | 100% (2 of 2); 1.0 uses a game |
| Tomb Kings of Khemri | 1 | 75% (3 of 4); on the table 75% | - | 14% | 40% (2 of 5) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 2 | 100% (2 of 2); on the table 100% | 33% (2 of 6) | 64% | 46% (6 of 13) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 1 | 100% (2 of 2); on the table 100% | - | 82% | 83% (5 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Wood Elf Realms | 1 | 75% (3 of 4); on the table 75% | - | 36% | 50% (4 of 8) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |

Flank and rear charges a unit could have turned to face (h4-mine-bbe8617-p1, 16 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 46% (16) | 54% (7) | 48% (23) |
| ...free all their last turn and able to turn (per game) | 0.62 | 0.25 | 0.88 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.38 | 0.19 | 0.56 |
| ...with the charger already in that arc before they moved (per game) | 0.38 | 0.25 | 0.62 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.06 | 0.06 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.06 | 0.06 | 0.12 |

### Quality by phase: h4-mine-bbe8617-p1

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.4 | 2.1 |
| Strategy | Charge objectives carried out (made contact) | 77% (23 of 30) | 57% (42 of 74) |
| Strategy | Shoot objectives carried out (shot that target) | 32% (81 of 257) | 50% (58 of 115) |
| Strategy | Support requests answered (helper made contact too) | 100% (3 of 3) | 54% (7 of 13) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | - | 100% (6 of 6) |
| Strategy | Hexes on a unit its side charged or shot that turn | 33% (1 of 3) | 60% (3 of 5) |
| Strategy | Joined characters whose unit fought | 26% (11 of 43) | 25% (4 of 16) |
| Strategy | Lone characters that fought | 45% (13 of 29) | 67% (22 of 33) |
| Movement | Charges halted short of contact | 0.0 | 0.3 |
| Movement | Idle units | 1.8 | 2.0 |
| Movement | Points that never moved of their own | 230.2 | 150.1 |
| Movement | Fights charged into per game | 1.6 | 3.0 |
| Movement | Charges with odds: long shots (under 50%) | 5 of 25, net +86 | 6 of 44, net -52 |
| Movement | Charges with odds: sweet spot (55-75%) | 3 of 25, net -25 | 11 of 44, net +81 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 6 of 25, net -67 | 6 of 44, net +144 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 5 of 25, net +99 | 12 of 44, net +103 |
| Shooting | Shots by shooting units (incl. breath weapons) | 9.4 | 9.4 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 56% (85 of 151) | 40% (61 of 151) |
| Shooting | Points destroyed by shooting units | 48.3 | 39.3 |
| Shooting | War machine shots | 9.7 | 3.8 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 59% (91 of 155) | 66% (40 of 61) |
| Shooting | Points destroyed by war machines | 130.3 | 21.6 |
| Magic | Magic missiles cast | 2.6 | 0.9 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 43% (18 of 42) | 29% (4 of 14) |
| Magic | Wounds caused by magic missiles | 5.1 | 1.8 |
| Magic | Wounds caused by other spells | 1.2 | 0.8 |
| Magic | Points destroyed by magic (all spells) | 79.0 | 9.9 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.8 / 0.2 / 0.6 / 0.1 | 2.1 / 0.4 / 0.2 / 0.1 |
| Combat | Points destroyed in combat | 130.6 | 348.8 |
| Combat | Points run down | 77.8 | 62.4 |
| Combat | Net points per charged fight, damage counted | +42 | +71 |
| Combat | Net per 100 charger points, damage counted | +20.3 | +21.5 |
| Combat | First round won (charged fights) | 83% | 75% |
| Combat | Net points per charged fight | +29 | +78 |
| Combat | Net points per supported fight / lone fight | +23 / +30 | +109 / +70 |
| Combat | Charged fights on a top-3 enemy unit | 6 of 25 | 22 of 48 |
| Game | Points lost | 604.1 | 538.0 |
| Game | VP from objectives | 596.9 | 733.8 |
| Game | Lone holders (player turns) | 3.0 | 2.7 |

- Mine won / drew / lost: 7 / 3 / 6 of 16 ended games (of 16); mean margin (Mine - Opponent) -192 VP
- The side that went first won 6 of 13 games with a winner
- Points traded per game (both sides' losses): 1142
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: h4-mine-bbe8617-p1

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.9 | +0.0 | 0.0 | 0.0 | 1.1 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.2 | +41.0 | 0.0 | 4.8 | 0.1 | +0.7 | 0.0 | 0.0 |
| ALREADY CARRIED | 0.4 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARRIVAL HUNT | - | - | - | - | 0.1 | +4.9 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 2.5 | +0.0 | 0.0 | 43.1 | 0.6 | +0.0 | 0.0 | 8.8 |
| BACKUP TARGETS | 0.3 | +1.2 | 0.0 | 15.8 | 0.2 | +0.4 | 0.0 | 0.0 |
| BEST PRIZE | - | - | - | - | 0.2 | -16.1 | 16.2 | 0.0 |
| BLOWS WHERE AIMED | 0.2 | +2.0 | 11.6 | 15.8 | 0.2 | -32.9 | 0.0 | 0.0 |
| CANNON PLAN MISSED | 1.1 | +0.0 | 115.2 | 29.1 | 0.6 | +0.0 | 91.6 | 10.3 |
| CANNON PLANNED TARGET | 8.9 | +277.9 | 651.1 | 219.7 | 3.8 | +172.1 | 194.8 | 19.1 |
| CANNON SIGHT KEPT | 1.2 | +0.0 | 0.0 | 7.8 | 0.4 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT COUNTER | - | - | - | - | 0.1 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT SET-UP | 0.1 | -3.5 | 7.5 | 0.0 | 0.1 | +0.0 | 7.8 | 0.0 |
| CAST JOB | 0.3 | +4.5 | 3.8 | 5.3 | 0.2 | +10.5 | 0.0 | 5.3 |
| CASTER AWAY FROM SCREEN | 0.4 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.4 | +29.4 | 26.2 | 0.0 | 0.1 | +1.1 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 1.2 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 25.0 |
| CASTS FROM BEHIND | - | - | - | - | 0.2 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.1 | +0.4 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | 0.1 | +6.1 | 0.0 | 3.4 | 0.4 | +27.1 | 0.0 | 14.1 |
| CHAFF PASSED | 0.1 | -0.2 | 13.1 | 0.0 | 0.2 | -0.5 | 14.7 | 18.6 |
| CHARACTER GUNS | 1.2 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| CHARGE LOSSES | 5.5 | -253.8 | 0.0 | 78.1 | 6.9 | -376.5 | 0.0 | 181.3 |
| CHARGE NOT DECLARED | 0.4 | +0.0 | 45.6 | 3.2 | 1.3 | +0.0 | 159.2 | 21.1 |
| CHARGE NOW FIRST | 0.9 | +0.0 | 93.7 | 24.4 | 2.4 | +0.0 | 225.0 | 53.7 |
| CHARGER SLAIN LOST | 0.4 | -6.4 | 17.1 | 6.5 | 0.4 | -17.6 | 76.7 | 3.4 |
| CHEAP HELPER | 0.2 | +0.0 | 7.5 | 3.2 | 0.1 | +0.0 | 0.0 | 4.1 |
| CHEAPEST HOLDER | - | - | - | - | 0.2 | -15.8 | 0.0 | 0.0 |
| COMBAT PIVOT | 0.5 | +0.0 | 0.0 | 52.5 | 0.4 | +0.0 | 55.6 | 23.8 |
| CONTINUE AHEAD WEIGHED | - | - | - | - | 0.1 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | 1.4 | +252.2 | 0.0 | 0.0 | 0.2 | +28.8 | 25.0 | 25.0 |
| COVER ONCE | 8.3 | -511.9 | 0.0 | 205.8 | 5.5 | -332.8 | 0.0 | 104.5 |
| DEFENSIVE ARMY | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| DEPLOY BY FIGURES | 9.1 | -10.2 | 0.0 | 21.8 | 8.4 | +51.3 | 0.0 | 7.2 |
| EDGE GIVE GROUND | 0.1 | +9.1 | 23.2 | 0.0 | 0.3 | +1.7 | 29.6 | 7.2 |
| ENGINEER BY LORE | 0.2 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| FALL BACK GOOD ORDER | 1.3 | +0.1 | 103.6 | 45.9 | 3.2 | +8.6 | 323.2 | 46.5 |
| FALLBACK BY WORTH | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| FALLS SHORT | 4.2 | +72.3 | 0.0 | 52.4 | 18.2 | +254.6 | 0.0 | 222.2 |
| FEATURE BUFFS | 1.3 | +34.8 | 0.0 | 13.4 | 0.5 | +5.7 | 0.0 | 0.0 |
| FIGHT LIFT | - | - | - | - | 0.1 | +0.3 | 7.2 | 0.0 |
| FIGHT TO THE END | 0.6 | +9.8 | 68.6 | 36.9 | 1.6 | +87.8 | 152.7 | 46.5 |
| FIRE IN ORDER | 0.2 | +0.0 | 0.0 | 7.8 | 0.1 | +0.0 | 0.0 | 0.0 |
| FIVE ACTION | 48.1 | +2555.5 | 1110.0 | 811.1 | 48.6 | +3009.3 | 667.1 | 588.1 |
| FLANK NOT WEIGHED | 5.6 | +0.0 | 0.0 | 134.4 | 4.0 | +0.0 | 0.0 | 67.9 |
| FOLLOW UP WEIGHED | 0.5 | +69.3 | 0.0 | 81.8 | 0.4 | +121.6 | 0.0 | 0.0 |
| FOUR ROUNDS | 1.8 | +110.6 | 144.2 | 88.6 | 4.2 | +438.5 | 387.6 | 57.1 |
| FRIEND CHARGES FIRST | 0.1 | -0.4 | 0.0 | 0.0 | 0.2 | -26.2 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 0.3 | -6.0 | 0.0 | 3.2 | 0.4 | -8.7 | 0.0 | 11.4 |
| FRIENDS SHOTS CHECKED | 0.1 | +5.8 | 0.0 | 0.0 | 0.2 | +2.1 | 0.0 | 0.0 |
| GIVES UP | 0.1 | -0.6 | 0.0 | 39.5 | 0.3 | -2.3 | 42.7 | 0.0 |
| GIVES UP ITS SCREEN | - | - | - | - | 0.1 | -0.8 | 13.4 | 0.0 |
| GUN FIGURES | 1.2 | +23.2 | 35.7 | 120.6 | 1.1 | +36.3 | 38.4 | 42.5 |
| GUN MASK | 0.8 | +14.6 | 0.0 | 13.4 | 0.4 | +9.8 | 0.0 | 9.4 |
| HARD STAY DROPPED | 2.3 | +0.0 | 0.0 | 46.8 | 0.7 | +0.0 | 0.0 | 14.2 |
| HE SHOOTS OR CHARGES | 2.4 | +0.0 | 0.0 | 46.2 | 2.4 | +0.0 | 0.0 | 62.5 |
| HELPER ALREADY ASKED | - | - | - | - | 0.1 | +0.0 | 23.8 | 1.7 |
| HELPER UNSEEN | 0.2 | +0.0 | 22.5 | 3.2 | 0.1 | +0.0 | 29.9 | 0.0 |
| HIS CHARGE DENIED | 0.2 | +3.6 | 26.2 | 3.2 | 0.2 | +4.7 | 7.8 | 13.9 |
| HIS CHARGE LIST | 1.8 | +0.0 | 0.0 | 52.8 | 3.5 | +0.0 | 0.0 | 59.1 |
| HIS LEGAL MOVES | 3.8 | +0.0 | 0.0 | 103.2 | 3.2 | +0.0 | 0.0 | 26.9 |
| HIS MOVE AND SHOT | 2.0 | -37.4 | 0.0 | 3.4 | 1.3 | -57.9 | 0.0 | 9.6 |
| HIS RANDOM MOVE | 1.4 | +0.0 | 0.0 | 5.7 | 1.5 | +0.0 | 0.0 | 30.3 |
| HIS SHOT LIST | 18.7 | +644.1 | 0.0 | 152.4 | 25.2 | +1318.1 | 0.0 | 325.3 |
| HIS TURN DENIED | 0.6 | +26.2 | 56.5 | 0.0 | 2.9 | +295.9 | 307.8 | 41.5 |
| HOLD ODDS | 6.3 | +0.0 | 0.0 | 35.8 | - | - | - | - |
| HOLDER ASSIGNMENT | 12.0 | +1147.6 | 0.0 | 84.1 | - | - | - | - |
| HOLDER AT DEPLOYMENT | - | - | - | - | 1.9 | +320.5 | 0.0 | 3.4 |
| HOLDS AMBUSHERS | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 1.5 | -35.2 | 144.2 | 66.4 | 3.8 | -170.0 | 321.9 | 53.7 |
| HUNT IN PAIRS | - | - | - | - | 0.4 | +31.1 | 0.0 | 0.0 |
| HUNT RESULT | - | - | - | - | 0.1 | +48.5 | 0.0 | 7.2 |
| HUNT THE GUNS | - | - | - | - | 0.1 | +58.0 | 15.6 | 14.4 |
| IDLE COST | 3.0 | -39.3 | 0.0 | 22.8 | 11.8 | -173.6 | 0.0 | 124.7 |
| JOINT KNOWS CHALLENGE | - | - | - | - | 0.1 | -21.1 | 0.0 | 0.0 |
| KEEP FALLS | 0.1 | +0.3 | 0.0 | 0.0 | 0.1 | +0.2 | 0.0 | 0.0 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| KILLS COUNT | - | - | - | - | 0.1 | +3.7 | 0.0 | 0.0 |
| LANE BY FIGURES | 0.4 | +11.3 | 0.0 | 0.0 | 0.9 | +52.6 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 4.8 | +0.0 | 124.9 | 148.1 | 2.4 | +0.0 | 152.8 | 82.6 |
| LONE CHARACTER SAFE SPOT | 0.2 | +2.6 | 0.0 | 0.0 | - | - | - | - |
| LONE WIZARD KEPT IN | 0.8 | +46.3 | 0.0 | 0.0 | 0.2 | +20.4 | 0.0 | 0.0 |
| LONG SHOT | 0.2 | +0.7 | 3.4 | 0.0 | 0.2 | +0.6 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 0.2 | +5.6 | 0.0 | 0.0 | 0.1 | +1.3 | 0.0 | 0.0 |
| MANOEUVRE | 1.2 | +20.3 | 0.0 | 28.3 | 1.7 | +19.1 | 0.0 | 19.4 |
| MARCH AT ESCAPER | 0.1 | +0.3 | 0.0 | 0.0 | - | - | - | - |
| MARCH BY THE SUM | 0.2 | +8.6 | 0.0 | 36.2 | 0.3 | +10.0 | 0.0 | 25.0 |
| MARCH CHECK | 0.4 | +10.1 | 0.0 | 41.3 | 1.1 | +66.2 | 0.0 | 10.4 |
| MARCH OVER CASTS | 0.6 | +11.1 | 0.0 | 0.0 | 0.5 | +9.3 | 0.0 | 35.4 |
| MAX FOR POSITIONING | 3.8 | +50.2 | 0.0 | 38.1 | 4.8 | +64.2 | 0.0 | 91.4 |
| MISSILES IN THE MOVE | 3.6 | +190.9 | 0.0 | 57.9 | 3.0 | +64.9 | 0.0 | 53.4 |
| MISSILES NEXT TURN | 4.1 | +114.1 | 0.0 | 94.1 | 4.1 | +40.4 | 0.0 | 98.9 |
| MODEL FACING | 0.9 | +206.2 | 0.0 | 3.8 | 0.2 | +65.2 | 0.0 | 7.5 |
| MOVE SPELL IN RANGE | 0.4 | +11.6 | 0.0 | 36.2 | 0.1 | +0.7 | 0.0 | 0.0 |
| MOVE SPELL NOT WORTH | 0.2 | -0.1 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 1.8 | -26.4 | 0.0 | 72.5 | 0.6 | -21.5 | 0.0 | 0.0 |
| MOVE SPELL SPOT | 0.6 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 25.0 |
| MOVE TO CHARGE COMPUTED | 2.8 | +202.1 | 0.0 | 11.8 | 3.6 | +553.1 | 0.0 | 15.2 |
| MOVES UNITS SPELL | 0.1 | +6.9 | 0.0 | 0.0 | 0.1 | +0.7 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 6.5 | +313.1 | 0.0 | 66.7 | 5.1 | +265.6 | 0.0 | 48.3 |
| NEEDED THERE | - | - | - | - | 0.1 | +3.2 | 16.6 | 0.0 |
| NEXT CHARGE BY LIST | 3.8 | -90.2 | 0.0 | 74.8 | 4.8 | -99.4 | 0.0 | 65.3 |
| NEXT OBJECTIVE NEARER | 0.1 | -0.6 | 0.0 | 15.8 | 10.0 | -513.4 | 3.4 | 131.2 |
| NO DOUBLE ROUNDS | 1.6 | -45.6 | 114.4 | 31.2 | 3.2 | -108.3 | 259.1 | 43.2 |
| NOT TURNED | 0.1 | +0.5 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 6.9 |
| NOT WORTH A CAST | 0.8 | -0.7 | 0.0 | 0.0 | 0.1 | -0.0 | 0.0 | 0.0 |
| OFF BEST | 0.1 | -12.1 | 0.0 | 0.0 | 0.4 | -4.8 | 0.0 | 0.0 |
| ONE CHARGE A CHARGER | 2.9 | +0.0 | 0.0 | 122.9 | 2.4 | +0.0 | 0.0 | 19.1 |
| ONE FIGHT FORMULA | 4.3 | -61.7 | 0.0 | 38.5 | 4.6 | -115.2 | 0.0 | 80.0 |
| ONE OBJECTIVE FORMULA | 4.2 | +13.1 | 0.0 | 54.3 | 3.5 | +57.9 | 0.0 | 37.3 |
| ONE TARGET A SHOOTER | 16.2 | +380.1 | 0.0 | 144.7 | 22.2 | +823.8 | 0.0 | 355.4 |
| OPENS A LANE | 0.3 | +0.7 | 0.0 | 0.0 | - | - | - | - |
| OPENS UP | 0.1 | +3.5 | 3.8 | 36.2 | 0.4 | +11.3 | 24.6 | 0.0 |
| OVERRUNS AWAY | 0.2 | +6.3 | 44.2 | 0.0 | 0.9 | +57.9 | 74.5 | 12.2 |
| PATHS CROSS | 2.6 | +86.9 | 0.0 | 50.4 | 4.8 | +160.6 | 0.0 | 97.6 |
| PERIAPT WORTH | - | - | - | - | 0.1 | +9.6 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.1 | -1.2 | 0.0 | 0.0 | 0.1 | -5.1 | 0.0 | 0.0 |
| PLAN RESULT | 42.6 | +1210.8 | 726.8 | 930.0 | 43.2 | +766.6 | 290.9 | 877.1 |
| QUARTER ODDS | 4.4 | +527.2 | 36.1 | 79.9 | - | - | - | - |
| RANDOM MOVE BY FIGURES | 0.4 | +3.0 | 0.0 | 0.0 | 1.2 | +16.3 | 0.0 | 61.6 |
| REDIRECT BY WHAT IT STOPS | - | - | - | - | 0.3 | -8.0 | 0.0 | 10.3 |
| REDIRECT COUNTER | 1.1 | +87.1 | 0.0 | 7.1 | 3.2 | +297.7 | 0.0 | 52.2 |
| REDIRECT WEIGHED | - | - | - | - | 0.6 | -11.9 | 13.4 | 1.7 |
| REFORMS TO MEET IT | 0.4 | -34.8 | 0.0 | 3.2 | 0.3 | -10.4 | 0.0 | 0.0 |
| REFUSING RETIRES | 0.2 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | 0.1 | +4.4 | 0.0 | 7.0 | 0.9 | +57.9 | 0.0 | 18.2 |
| RESTRAINS TO SHOOT | 0.1 | +12.2 | 0.0 | 0.0 | 0.1 | +1.6 | 0.0 | 0.0 |
| RISK BY ARC | 1.7 | +16.5 | 140.5 | 88.6 | 3.1 | -42.8 | 274.7 | 55.4 |
| RISK BY HIS FIGURE | 10.9 | -157.0 | 0.0 | 230.6 | 11.6 | -195.1 | 0.0 | 209.3 |
| RUN DOWN | 1.3 | -9.2 | 121.4 | 30.1 | 2.9 | -24.6 | 232.3 | 26.6 |
| SAFER THAN THE JOB | - | - | - | - | 0.1 | +10.7 | 0.0 | 0.0 |
| SAME CHARGE LATER | 0.1 | -0.6 | 0.0 | 0.0 | 0.1 | -0.3 | 0.0 | 0.0 |
| SCOUT SPOT | 0.4 | +1.1 | 0.0 | 0.0 | 0.2 | +1.2 | 0.0 | 0.0 |
| SCOUT WAITS | 0.4 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.1 | -10.4 | 0.0 | 3.4 | - | - | - | - |
| SEARCH SPOT | 5.0 | +227.1 | 0.0 | 60.1 | 6.7 | +246.6 | 0.0 | 85.4 |
| SELF MOVE SPELL | - | - | - | - | 0.7 | +129.4 | 0.0 | 0.0 |
| SET UP TOGETHER | 0.2 | +5.6 | 0.0 | 0.0 | 0.6 | +6.4 | 0.0 | 28.8 |
| SET-UP ANY TARGET | 0.2 | +28.1 | 0.0 | 0.0 | - | - | - | - |
| SET-UP MISSED | 0.1 | +4.0 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | 0.6 | +1.1 | 0.0 | 0.0 | 0.3 | +0.7 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.9 | +55.2 | 45.9 | 70.6 | 1.2 | +43.0 | 22.8 | 3.8 |
| SHORT GUN FORWARD | 0.4 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| SHOT OR CHARGE | 0.4 | -9.6 | 15.2 | 5.7 | 0.2 | -2.9 | 4.8 | 0.0 |
| SHOT RISK POINTS | 9.4 | +5.2 | 0.0 | 83.1 | 13.0 | +36.4 | 0.0 | 234.6 |
| SHOTS IN THE MOVE | 20.2 | +930.8 | 0.0 | 494.8 | 13.4 | +416.5 | 0.0 | 233.7 |
| SPELL SETS UP CHARGE | 0.3 | +95.9 | 0.0 | 0.0 | - | - | - | - |
| SPELL WORTH | 0.5 | +3.7 | 0.0 | 0.0 | 1.8 | +35.2 | 57.2 | 50.0 |
| SPELLS IN THE FIGHT | 0.4 | -1.5 | 37.4 | 52.0 | 0.7 | -14.2 | 95.6 | 3.4 |
| STAND AND SHOOT | 0.3 | -3.4 | 34.9 | 5.7 | 0.9 | -18.9 | 63.8 | 27.1 |
| STANDS FOR A REASON | 0.1 | +0.0 | 0.0 | 4.8 | 0.5 | +0.0 | 0.0 | 6.7 |
| STANDS STILL | 24.2 | +0.0 | 965.8 | 453.4 | 11.8 | +0.0 | 226.8 | 101.6 |
| STAY WORTH | 25.2 | +73.4 | 716.6 | 412.4 | 13.8 | +77.6 | 161.6 | 226.1 |
| STOPS | - | - | - | - | 0.1 | +34.4 | 15.6 | 14.4 |
| STUCK PIVOT | - | - | - | - | 0.2 | +0.0 | 0.0 | 13.1 |
| SUPPORT NARROWED | 0.7 | +0.0 | 71.9 | 3.2 | 1.7 | +0.0 | 182.8 | 15.6 |
| SURE REACH TOGETHER | 0.3 | +7.0 | 0.0 | 0.0 | 0.1 | +2.0 | 0.0 | 18.6 |
| THE DEARER SUM KEEPS ITS PLAN | 3.6 | +0.0 | 0.0 | 50.4 | 4.4 | +0.0 | 0.0 | 68.8 |
| THE PROMISE ADDS | 0.1 | -0.8 | 0.0 | 0.0 | 0.1 | -13.4 | 7.8 | 0.0 |
| THE PROMISED MOVE | 0.5 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 11.4 |
| TIED UP BY THE SUM | 0.4 | +41.7 | 34.4 | 36.2 | 0.7 | +61.4 | 49.1 | 0.0 |
| TIME ON OUR SIDE | 28.4 | +434.7 | 28.2 | 420.7 | 6.8 | +93.3 | 0.0 | 132.5 |
| TWO OR MORE ARRIVE | 0.1 | +0.1 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| WAITS AGAIN | 1.6 | +0.0 | 0.0 | 67.2 | 0.7 | +0.0 | 0.0 | 11.4 |
| WAR ENGINE JOBS | 0.2 | +0.0 | 3.8 | 0.0 | 0.2 | +0.0 | 9.1 | 0.0 |
| WHO HITS BACK | 0.2 | +25.4 | 0.0 | 5.7 | 0.1 | +51.7 | 0.0 | 0.0 |
| WHOLE FIGHT | - | - | - | - | 0.1 | +1.8 | 16.6 | 0.0 |
| WHOLE FIGHT GAIN | 0.2 | +10.8 | 15.0 | 3.2 | 0.8 | +71.4 | 95.9 | 3.4 |
| WIDER SPREAD | 1.3 | +0.1 | 104.6 | 55.2 | 3.3 | -7.2 | 365.4 | 29.9 |
| WOUNDS ON THE RANKS | 1.6 | +118.9 | 0.0 | 0.0 | 1.0 | +72.2 | 0.0 | 10.4 |

### Rule changes: h4-mine-bbe8617-p1

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS SHOT LIST | 702 | 702 | 212 | 13.25 | +6099 | +28.8 |
| ONE TARGET A SHOOTER | 615 | 615 | 189 | 11.81 | +2578 | +13.6 |
| HOLDER ASSIGNMENT | 192 | 192 | 181 | 11.31 | +9094 | +50.2 |
| SEARCH SPOT | 187 | 187 | 180 | 11.25 | +7580 | +42.1 |
| DEPLOY BY FIGURES | 281 | 281 | 178 | 11.12 | +3100 | +17.4 |
| TIME ON OUR SIDE | 563 | 527 | 133 | 8.31 | +552 | +4.2 |
| PATHS CROSS | 119 | 119 | 119 | 7.44 | +3960 | +33.3 |
| FIVE ACTION | 1548 | 1547 | 117 | 7.31 | +4097 | +35.0 |
| LEGAL CHARGES ONLY | 116 | 116 | 116 | 7.25 | +0 | +0.0 |
| SHOT RISK POINTS | 359 | 359 | 63 | 3.94 | +2453 | +38.9 |
| MOVE TO CHARGE COMPUTED | 103 | 103 | 62 | 3.88 | +4611 | +74.4 |
| ARTILLERY RE-ROLL WEIGHED | 50 | 50 | 50 | 3.12 | +0 | +0.0 |
| COVER ONCE | 221 | 188 | 50 | 3.12 | +843 | +16.9 |
| HARD STAY DROPPED | 48 | 48 | 48 | 3.00 | +0 | +0.0 |
| FOUR ROUNDS | 97 | 96 | 46 | 2.88 | +3341 | +72.6 |
| CANNON PLANNED TARGET | 203 | 203 | 44 | 2.75 | -419 | -9.5 |
| IDLE COST | 237 | 198 | 39 | 2.44 | +266 | +6.8 |
| SHOOTS FROM THE BEST SPOT | 49 | 49 | 36 | 2.25 | +489 | +13.6 |
| SHOTS IN THE MOVE | 539 | 509 | 36 | 2.25 | +1198 | +33.3 |
| MAX FOR POSITIONING | 137 | 136 | 32 | 2.00 | +103 | +3.2 |
| ADVANCE LANE KEPT | 31 | 31 | 31 | 1.94 | +0 | +0.0 |
| CHARGE NOT DECLARED | 28 | 28 | 28 | 1.75 | -4671 | -166.8 |
| CANNON SIGHT KEPT | 26 | 26 | 26 | 1.62 | +0 | +0.0 |
| MANOEUVRE | 46 | 46 | 25 | 1.56 | +769 | +30.8 |
| FALLS SHORT | 360 | 314 | 24 | 1.50 | +85 | +3.5 |
| RISK BY ARC | 76 | 75 | 22 | 1.38 | +503 | +22.8 |
| LANE BY FIGURES | 21 | 21 | 21 | 1.31 | +1023 | +48.7 |
| HIS TURN DENIED | 55 | 55 | 19 | 1.19 | +1817 | +95.6 |
| MISSILES IN THE MOVE | 105 | 79 | 19 | 1.19 | +658 | +34.6 |
| CHARGE LOSSES | 198 | 198 | 18 | 1.12 | +1331 | +73.9 |
| MODEL FACING | 18 | 18 | 18 | 1.12 | +4343 | +241.3 |
| NEXT OBJECTIVE NEARER | 162 | 162 | 18 | 1.12 | +277 | +15.4 |
| NEXT CHARGE BY LIST | 138 | 138 | 17 | 1.06 | +304 | +17.9 |
| WOUNDS ON THE RANKS | 41 | 41 | 17 | 1.06 | +695 | +40.9 |
| LONE WIZARD KEPT IN | 16 | 16 | 16 | 1.00 | +1067 | +66.7 |
| REDIRECT COUNTER | 68 | 53 | 16 | 1.00 | +2054 | +128.3 |
| FOLLOW UP WEIGHED | 15 | 15 | 15 | 0.94 | +3054 | +203.6 |
| HOLDER AT DEPLOYMENT | 30 | 30 | 15 | 0.94 | +744 | +49.6 |
| MARCH CHECK | 24 | 24 | 15 | 0.94 | +336 | +22.4 |
| RESERVE FALL BACK | 15 | 15 | 15 | 0.94 | +996 | +66.4 |
| COMBAT PIVOT | 14 | 14 | 14 | 0.88 | +0 | +0.0 |
| RANDOM MOVE BY FIGURES | 26 | 26 | 14 | 0.88 | +310 | +22.1 |
| SHOOTERS IN TWO RANKS | 14 | 14 | 14 | 0.88 | +29 | +2.1 |
| TIED UP BY THE SUM | 17 | 17 | 14 | 0.88 | +513 | +36.7 |
| QUARTER ODDS | 70 | 70 | 13 | 0.81 | +1855 | +142.7 |
| RISK BY HIS FIGURE | 360 | 360 | 11 | 0.69 | +584 | +53.1 |
| SCOUT WAITS | 11 | 11 | 11 | 0.69 | +0 | +0.0 |
| HOLDS AMBUSHERS | 10 | 10 | 10 | 0.62 | +0 | +0.0 |
| SHORT GUN FORWARD | 10 | 10 | 10 | 0.62 | +0 | +0.0 |
| WHOLE FIGHT GAIN | 16 | 16 | 10 | 0.62 | +569 | +56.9 |
| CHARGE NOW FIRST | 52 | 52 | 9 | 0.56 | -841 | -93.5 |
| MARCH BY THE SUM | 9 | 9 | 9 | 0.56 | +298 | +33.1 |
| ONE OBJECTIVE FORMULA | 123 | 102 | 9 | 0.56 | +481 | +53.5 |
| REDIRECT WEIGHED | 9 | 9 | 9 | 0.56 | +425 | +47.2 |
| CASTER AWAY FROM SCREEN | 8 | 8 | 8 | 0.50 | +0 | +0.0 |
| OFF BEST | 8 | 8 | 8 | 0.50 | -270 | -33.8 |
| CASTING BLOCK | 8 | 8 | 7 | 0.44 | +38 | +5.4 |
| NEARER NOT NEEDED | 186 | 180 | 7 | 0.44 | +260 | +37.2 |
| STAY WORTH | 624 | 601 | 6 | 0.38 | +68 | +11.4 |
| WHO HITS BACK | 6 | 6 | 6 | 0.38 | +796 | +132.7 |
| AFTERMATH IN POINTS | 5 | 5 | 5 | 0.31 | +667 | +133.4 |
| CHAFF IN THE MOVE | 9 | 8 | 5 | 0.31 | +90 | +18.0 |
| CHAFF PASSED | 5 | 5 | 5 | 0.31 | -12 | -2.5 |
| FEATURE BUFFS | 29 | 29 | 5 | 0.31 | +52 | +10.4 |
| FIRE IN ORDER | 5 | 5 | 5 | 0.31 | +0 | +0.0 |
| HONEST WORTH | 84 | 83 | 5 | 0.31 | +28 | +5.7 |
| ONE FIGHT FORMULA | 143 | 75 | 5 | 0.31 | +25 | +5.1 |
| OVERRUNS AWAY | 18 | 18 | 5 | 0.31 | +141 | +28.3 |
| SURE REACH TOGETHER | 6 | 6 | 5 | 0.31 | +50 | +9.9 |
| BEST PRIZE | 4 | 4 | 4 | 0.25 | -281 | -70.3 |
| FIGHT TO THE END | 34 | 33 | 4 | 0.25 | +545 | +136.2 |
| FRIENDS SHOTS CHECKED | 4 | 4 | 4 | 0.25 | +127 | +31.6 |
| MOVES UNITS SPELL | 4 | 4 | 4 | 0.25 | +122 | +30.4 |
| SUPPORT NARROWED | 38 | 38 | 4 | 0.25 | -61 | -15.3 |
| CASTS FROM BEHIND | 3 | 3 | 3 | 0.19 | +0 | +0.0 |
| GUN MASK | 18 | 18 | 3 | 0.19 | +86 | +28.6 |
| HIS MOVE AND SHOT | 53 | 53 | 3 | 0.19 | +6 | +2.0 |
| KEEP FALLS | 3 | 3 | 3 | 0.19 | +61 | +20.3 |
| KEEPS SCOUTS OR AMBUSH | 3 | 3 | 3 | 0.19 | +0 | +0.0 |
| LONG SHOT | 6 | 6 | 3 | 0.19 | +9 | +3.0 |
| PIVOT GUARDS FLANK | 3 | 3 | 3 | 0.19 | -100 | -33.5 |
| STUCK PIVOT | 3 | 3 | 3 | 0.19 | +0 | +0.0 |
| WIDER SPREAD | 74 | 73 | 3 | 0.19 | +43 | +14.4 |
| CAST JOB | 9 | 9 | 2 | 0.12 | +0 | +0.0 |
| EDGE GIVE GROUND | 7 | 7 | 2 | 0.12 | +117 | +58.7 |
| HUNT IN PAIRS | 7 | 4 | 2 | 0.12 | +58 | +28.8 |
| MISSILES NEXT TURN | 132 | 98 | 2 | 0.12 | +5 | +2.5 |
| PERIAPT WORTH | 2 | 2 | 2 | 0.12 | +153 | +76.7 |
| REFUSING RETIRES | 5 | 5 | 2 | 0.12 | -1 | -0.5 |
| RESTRAINS TO SHOOT | 2 | 2 | 2 | 0.12 | +221 | +110.4 |
| RUN DOWN | 68 | 67 | 2 | 0.12 | +1 | +0.6 |
| STOPS | 2 | 2 | 2 | 0.12 | +101 | +50.7 |
| WAR ENGINE JOBS | 8 | 8 | 2 | 0.12 | -157 | -78.3 |
| WHOLE FIGHT | 2 | 2 | 2 | 0.12 | +0 | +0.0 |
| CARRIES OUT COUNTER | 1 | 1 | 1 | 0.06 | +0 | +0.0 |
| CARRIES OUT SET-UP | 2 | 2 | 1 | 0.06 | -56 | -56.4 |
| CONTINUE AHEAD WEIGHED | 1 | 1 | 1 | 0.06 | +0 | +0.0 |
| KILLS COUNT | 1 | 1 | 1 | 0.06 | +35 | +35.3 |
| NEEDED THERE | 2 | 2 | 1 | 0.06 | +0 | +0.0 |
| NO DOUBLE ROUNDS | 77 | 76 | 1 | 0.06 | +0 | +0.2 |
| OPENS UP | 8 | 8 | 1 | 0.06 | +25 | +24.6 |
| SAFER THAN THE JOB | 1 | 1 | 1 | 0.06 | +171 | +171.3 |
| SAME CHARGE LATER | 2 | 2 | 1 | 0.06 | +1 | +1.2 |
| SET UP TOGETHER | 13 | 10 | 1 | 0.06 | +36 | +35.6 |
| STAND AND SHOOT | 19 | 19 | 1 | 0.06 | +0 | +0.2 |
| ALREADY CARRIED | 6 | not checked | - | - | - | - |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| BACKUP TARGETS | 8 | 3 | 0 | 0.00 | - | - |
| BLOWS WHERE AIMED | 6 | 6 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 26 | 26 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 29 | trace | - | - | - | - |
| CATCH FLIERS | 1 | not checked | - | - | - | - |
| CHARACTER GUNS | 28 | 28 | 0 | 0.00 | - | - |
| CHARGER SLAIN LOST | 14 | 14 | 0 | 0.00 | - | - |
| CHEAP HELPER | 5 | not checked | - | - | - | - |
| CHEAPEST HOLDER | 3 | 3 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 25 | not checked | - | - | - | - |
| DEFENSIVE ARMY | 1 | 1 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 6 | 6 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 73 | 72 | 0 | 0.00 | - | - |
| FALLBACK BY WORTH | 5 | 5 | 0 | 0.00 | - | - |
| FIGHT LIFT | 2 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 154 | not checked | - | - | - | - |
| FRIEND CHARGES FIRST | 4 | 4 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 11 | 11 | 0 | 0.00 | - | - |
| GIVES UP | 7 | 7 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 2 | 2 | 0 | 0.00 | - | - |
| GUN FIGURES | 37 | not checked | - | - | - | - |
| HE SHOOTS OR CHARGES | 76 | 76 | 0 | 0.00 | - | - |
| HELPER ALREADY ASKED | 2 | not checked | - | - | - | - |
| HELPER UNSEEN | 5 | 4 | 0 | 0.00 | - | - |
| HIS CHARGE DENIED | 8 | 7 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 84 | 84 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 111 | 111 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 46 | 46 | 0 | 0.00 | - | - |
| HOLD ODDS | 101 | 101 | 0 | 0.00 | - | - |
| HUNT RESULT | 2 | trace | - | - | - | - |
| HUNT THE GUNS | 2 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 2 | 2 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 3 | not checked | - | - | - | - |
| MAKE SURE TOGETHER | 5 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 18 | 18 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 8 | 4 | 0 | 0.00 | - | - |
| MOVE SPELL NOT WORTH | 3 | not checked | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 37 | trace | - | - | - | - |
| MOVE SPELL SPOT | 11 | not checked | - | - | - | - |
| NOT TURNED | 2 | 2 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 14 | not checked | - | - | - | - |
| ONE CHARGE A CHARGER | 85 | 85 | 0 | 0.00 | - | - |
| OPENS A LANE | 5 | not checked | - | - | - | - |
| PLAN RESULT | 1372 | trace | - | - | - | - |
| REDIRECT BY WHAT IT STOPS | 5 | 5 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 11 | 11 | 0 | 0.00 | - | - |
| SCOUT SPOT | 10 | 10 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 1 | 1 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 11 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 3 | not checked | - | - | - | - |
| SET-UP MISSED | 2 | trace | - | - | - | - |
| SHOT OR CHARGE | 9 | 9 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 5 | not checked | - | - | - | - |
| SPELL WORTH | 36 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 17 | 17 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 10 | 10 | 0 | 0.00 | - | - |
| STANDS STILL | 575 | 575 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 127 | not checked | - | - | - | - |
| THE PROMISE ADDS | 2 | 2 | 0 | 0.00 | - | - |
| THE PROMISED MOVE | 12 | not checked | - | - | - | - |
| TWO OR MORE ARRIVE | 3 | not checked | - | - | - | - |
| WAITS AGAIN | 36 | 36 | 0 | 0.00 | - | - |

### Off best figure: h4-mine-bbe8617-p1

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| CHARGE NOT DECLARED | rule | 0.38 | 1.12 | 194.6 |
| PATHS CROSS | rule | 0.44 | 0.81 | 37.8 |
| HOLDER ASSIGNMENT | rule | 1.12 | - | 19.9 |
| CHARGE NOW FIRST | rule | 0.12 | 0.44 | 93.5 |
| BEST PRIZE | rule | - | 0.25 | 70.3 |
| CANNON PLANNED TARGET | rule | 0.25 | - | 136.7 |
| CHAFF PASSED | rule | 0.06 | 0.19 | 3.1 |
| JOB FIRST | gate | - | 0.25 | 13.1 |
| SUPPORT NARROWED | rule | 0.12 | 0.12 | 15.3 |
| PIVOT GUARDS FLANK | rule | 0.06 | 0.12 | 33.5 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.06 | 0.06 | 107.5 |
| DEPLOY BY FIGURES | rule | - | 0.12 | 6.0 |
| WAR ENGINE JOBS | rule | 0.12 | - | 78.3 |
| AFTERMATH BAND | gate | - | 0.06 | 2.6 |
| CARRIES OUT SET-UP | rule | 0.06 | - | 56.4 |
| FIGHT ORDER BAND | gate | - | 0.06 | 0.6 |
| LONG SHOT | rule | 0.06 | - | 1.7 |
| REDIRECT WEIGHED | rule | - | 0.06 | 123.9 |

### Plans: h4-mine-bbe8617-p1

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.6 | 54% | 202 | 128 | 63% |
| Mine | join | 0.6 | 80% | 19 | 0 | 0% |
| Mine | move | 26.1 | 95% | 1438 | 0 | 0% |
| Mine | shoot | 14.2 | 56% | 699 | 1083 | 155% |
| Mine | support | 0.1 | 0% | 0 | 0 | - |
| Opponent | charge | 4.0 | 53% | 740 | 346 | 47% |
| Opponent | join | 0.5 | 100% | 20 | 0 | 0% |
| Opponent | move | 32.8 | 94% | 1660 | 0 | 0% |
| Opponent | shoot | 5.6 | 58% | 268 | 420 | 157% |
| Opponent | support | 0.3 | 60% | 2 | 0 | 0% |

### Packages: hunt the guns, h4-mine-bbe8617-p1

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 27 |
| Opponent | 0.1 | 2 | 0 | 100% | 100% | 0% | 2.0 | 464 | 388 | 100% | 149 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 24 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 137 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 534 |
| High Elf Realms | 1.0 | 2 | 0 | 100% | 100% | 0% | 2.0 | 464 | 388 | 100% | 406 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 234 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Tomb Kings of Khemri | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Vampire Counts | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 38 |
| Warriors of Chaos | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Wood Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 107 |

### Battle groups: h4-mine-bbe8617-p1

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 1.1 | 6% | 100% | 0% | - | 0% | 0% | 0% | 100% | 0% |
| Opponent | REDIRECT COUNTER | 3.2 | 18% | 67% | 11% | 0% | 0% | 0% | 12% | 88% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: h4-mine-bbe8617-p1

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | - | 0 (1) | - | 0 (1) |
| Mine | Chaff | 9 | 6 (9) | 0 | 6 | 38 | 89% | 2.0 | - | 7 (7) | 0 (2) | 9 (5) | 0 (4) |
| Mine | Character | 62 | 31 (62) | 31 | 0 | 23 | 31% | 2.3 | 31 (31) | 32 (19) | 27 (10) | 34 (42) | 25 (18) |
| Mine | Clean-up | 8 | 52 (8) | 32 | 20 | 49 | 38% | 2.2 | 100 (3) | 33 (4) | 0 (1) | 46 (7) | 75 (1) |
| Mine | Fast | 3 | 54 (3) | 54 | 0 | 0 | 33% | 1.0 | - | 163 (1) | 0 (2) | 82 (2) | 0 (1) |
| Mine | Fast Hammer | 17 | 37 (17) | 16 | 21 | 43 | 41% | 3.2 | 0 (2) | 45 (12) | 43 (3) | 33 (8) | 43 (9) |
| Mine | Hammer | 32 | 43 (32) | 19 | 24 | 20 | 41% | 2.4 | 93 (7) | 32 (15) | 19 (10) | 60 (18) | 17 (14) |
| Mine | Holder | 12 | 139 (12) | 12 | 127 | 15 | 58% | 4.8 | 140 (2) | 187 (7) | 22 (3) | 200 (7) | 63 (5) |
| Mine | Shooter | 18 | 54 (18) | 4 | 50 | 47 | 6% | 1.4 | 5 (5) | 73 (10) | 77 (3) | 73 (13) | 13 (5) |
| Mine | War machine | 43 | 48 (43) | 48 | 0 | 59 | 5% | 1.3 | 53 (19) | 22 (17) | 95 (7) | 36 (7) | 50 (36) |
| Mine | Wizard | 10 | 0 (10) | 0 | 0 | 22 | 30% | 3.7 | 0 (4) | 0 (2) | 0 (3) | 0 (2) | 0 (7) |
| Opponent | Chaff | 31 | 74 (31) | 11 | 63 | 47 | 32% | 2.8 | 42 (13) | 102 (11) | 73 (7) | 72 (24) | 83 (7) |
| Opponent | Character | 42 | 46 (42) | 46 | 0 | 19 | 24% | 2.2 | 59 (12) | 20 (19) | 82 (8) | 72 (17) | 27 (22) |
| Opponent | Clean-up | 11 | 97 (11) | 70 | 27 | 24 | 82% | 3.0 | 0 (1) | 98 (9) | 237 (1) | 61 (6) | 117 (5) |
| Opponent | Early | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | - | 0 (1) | - | 0 (1) |
| Opponent | Fast | 2 | 0 (2) | 0 | 0 | 100 | 50% | 2.0 | 0 (1) | 0 (1) | - | 0 (2) | - |
| Opponent | Fast Hammer | 15 | 45 (15) | 31 | 14 | 18 | 33% | 2.2 | 82 (3) | 27 (9) | 84 (3) | 23 (5) | 53 (10) |
| Opponent | Fragile | 2 | 0 (2) | 0 | 0 | 0 | 50% | 1.0 | 0 (1) | - | 0 (1) | 0 (1) | 0 (1) |
| Opponent | Hammer | 26 | 24 (26) | 9 | 15 | 49 | 42% | 2.1 | 0 (3) | 23 (17) | 37 (6) | 19 (18) | 35 (8) |
| Opponent | Holder | 18 | 98 (18) | 2 | 96 | 17 | 61% | 2.6 | 105 (10) | 93 (5) | 92 (3) | 135 (9) | 60 (9) |
| Opponent | Shooter | 16 | 74 (16) | 17 | 57 | 33 | 12% | 1.6 | 108 (3) | 70 (13) | - | 95 (6) | 64 (10) |
| Opponent | War machine | 14 | 26 (14) | 26 | 0 | 28 | 0% | 1.8 | 0 (2) | 88 (4) | 10 (8) | 0 (3) | 31 (11) |
| Opponent | Wizard | 7 | 19 (7) | 19 | 0 | 8 | 14% | 2.7 | 0 (2) | 3 (3) | 93 (1) | 0 (2) | 26 (4) |

### Charged fights: h4-mine-bbe8617-p1

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 266 | 95 | 1.5 | 1.5 | 64 | 26 | +38 | 3 of 6 | 3 of 6 | +34 | +39 |
| Mine | Chaos Dwarfs | 4 | 218 | 251 | 1.8 | 1.0 | 143 | 96 | +48 | 2 of 7 | 7 of 7 | - | +48 |
| Mine | Dwarfen Mountain Holds | 4 | 376 | 24 | 1.0 | 1.2 | 24 | 0 | +24 | 0 of 4 | 3 of 3 | +0 | +33 |
| Mine | Empire of Man | 4 | 171 | 108 | 2.0 | 1.0 | 54 | 44 | +10 | 1 of 8 | 7 of 8 | - | +10 |
| **Mine** | all armies | 16 | 258 | 120 | 1.6 | 1.2 | 77 | 47 | +29 | 6 of 25 | 20 of 24 | +23 | +30 |
| Opponent | Chaos Dwarfs | 3 | 50 | 277 | 2.7 | 1.1 | 104 | 92 | +12 | 5 of 8 | 3 of 8 | -215 | +45 |
| Opponent | Dwarfen Mountain Holds | 1 | 339 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Grand Cathay | 1 | 113 | 190 | 3.0 | 1.0 | 63 | 242 | -179 | 1 of 3 | 2 of 3 | - | -179 |
| Opponent | High Elf Realms | 2 | 118 | 569 | 4.0 | 1.1 | 142 | 0 | +142 | 4 of 8 | 8 of 8 | +419 | +103 |
| Opponent | Ogre Kingdoms | 1 | 250 | 77 | 2.0 | 1.0 | 38 | 114 | -76 | 0 of 2 | 1 of 2 | - | -76 |
| Opponent | Orc & Goblin Tribes | 1 | 0 | 450 | 3.0 | 1.0 | 150 | 0 | +150 | 0 of 3 | 3 of 3 | - | +150 |
| Opponent | Skaven | 2 | 0 | 0 | 0.5 | 2.0 | 0 | 210 | -210 | 1 of 1 | 1 of 1 | -210 | - |
| Opponent | Tomb Kings of Khemri | 1 | 0 | 744 | 5.0 | 1.0 | 149 | 39 | +110 | 2 of 5 | 3 of 5 | - | +110 |
| Opponent | Vampire Counts | 2 | 22 | 704 | 5.0 | 1.5 | 141 | 0 | +141 | 4 of 10 | 8 of 10 | +201 | +115 |
| Opponent | Warriors of Chaos | 1 | 0 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 1 of 1 | 1 of 1 | - | +0 |
| Opponent | Wood Elf Realms | 1 | 0 | 977 | 7.0 | 1.4 | 140 | 0 | +140 | 4 of 7 | 6 of 7 | +127 | +149 |
| **Opponent** | all armies | 16 | 71 | 363 | 3.0 | 1.2 | 121 | 44 | +78 | 22 of 48 | 36 of 48 | +109 | +70 |

### Effective charges: h4-mine-bbe8617-p1

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 6 | 4 (net +39) | 0 | 0 | 1 (net +0) | 0 | 1 (net +68) | 0 | 0% (0 of 6) |
| Mine | Chaos Dwarfs | 7 | 1 (net +275) | 0 | 1 (net +278) | 0 | 3 (net -153) | 2 (net +120) | 0 | 14% (1 of 7) |
| Mine | Dwarfen Mountain Holds | 4 | 0 | 0 | 0 | 3 (net +33) | 0 | 1 (net +0) | 0 | 0% (0 of 4) |
| Mine | Empire of Man | 8 | 0 | 0 | 2 (net -177) | 2 (net +92) | 3 (net +20) | 1 (net +185) | 0 | 25% (2 of 8) |
| Opponent | Chaos Dwarfs | 8 | 0 | 0 | 3 (net -72) | 1 (net +110) | 0 | 2 (net +256) | 2 | 50% (3 of 6) |
| Opponent | Grand Cathay | 3 | 1 (net -727) | 0 | 2 (net +95) | 0 | 0 | 0 | 0 | 67% (2 of 3) |
| Opponent | High Elf Realms | 8 | 1 (net +0) | 0 | 2 (net +112) | 1 (net +125) | 1 (net +104) | 3 (net +228) | 0 | 25% (2 of 8) |
| Opponent | Ogre Kingdoms | 2 | 0 | 1 (net +77) | 0 | 0 | 0 | 1 (net -228) | 0 | 0% (0 of 2) |
| Opponent | Orc & Goblin Tribes | 3 | 0 | 0 | 0 | 0 | 2 (net +210) | 0 | 1 | 0% (0 of 2) |
| Opponent | Skaven | 1 | 1 (net -210) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 1) |
| Opponent | Tomb Kings of Khemri | 5 | 1 (net +239) | 0 | 0 | 1 (net +310) | 1 (net +0) | 2 (net +0) | 0 | 0% (0 of 5) |
| Opponent | Vampire Counts | 10 | 2 (net +194) | 0 | 2 (net +95) | 3 (net +75) | 2 (net +170) | 1 (net +265) | 0 | 20% (2 of 10) |
| Opponent | Warriors of Chaos | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +0) | 0 | 0% (0 of 1) |
| Opponent | Wood Elf Realms | 7 | 0 | 1 (net +238) | 2 (net +252) | 1 (net +0) | 0 | 2 (net +0) | 1 | 33% (2 of 6) |

### Charged fights, damage counted: h4-mine-bbe8617-p1

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 5 | 133 | 267 | +86 | 158 | 25 | +133 | +100.3 |
| Mine | Effective (55-75%) | 3 | 241 | 232 | -25 | 93 | 134 | -41 | -17.2 |
| Mine | 76-89% | 6 | 152 | 119 | +47 | 61 | 0 | +61 | +40.4 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 5 | 216 | 147 | +99 | 127 | 37 | +90 | +41.6 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 6 | 287 | 54 | -67 | 43 | 97 | -54 | -18.8 |
| Mine | All fights | 25 | 204 | 152 | +29 | 93 | 52 | +42 | +20.3 |
| Opponent | Long shot (under 50%) | 6 | 296 | 222 | -52 | 189 | 210 | -21 | -7.3 |
| Opponent | 50-54% | 2 | 266 | 158 | +158 | 158 | 0 | +158 | +59.1 |
| Opponent | Effective (55-75%) | 11 | 309 | 161 | +81 | 119 | 77 | +42 | +13.6 |
| Opponent | 76-89% | 7 | 300 | 202 | +110 | 110 | 7 | +103 | +34.4 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 12 | 337 | 197 | +103 | 156 | 42 | +114 | +33.7 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 6 | 448 | 116 | +144 | 153 | 33 | +120 | +26.8 |
| Opponent | No odds | 4 | 336 | 177 | -12 | 66 | 78 | -12 | -3.4 |
| Opponent | All fights | 48 | 331 | 179 | +78 | 137 | 66 | +71 | +21.5 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| h4-mine-bbe8617-p1 | move | 99 | 28 (28%) | 23 (23%) | 9 (9%) | 62 (63%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0103, L0120 |
| Charmed Shield | Opponent | L0525, L0734, L0824 |
| Elixir of Power | Opponent | L0219 |
| Fistful of Laurels | Opponent | L0718 |
| Invocation of Nehek | Opponent | L0525, L0824 |
| Periapt of Soul Exchange | Opponent | L0120, L0321 |
| Ring of Doom | Mine | L0204, L0219 |
| Ring of Doom | Opponent | L0915 |
| Ring of Jet | Opponent | L0510 |
| Standard of the Fell Warrior | Opponent | L0613 |
| Storm Daemon (Renegade 2.0) | Opponent | L0321 |
| Twice-Blessed Armour | Mine | L0718, L0734 |
| Twice-Blessed Armour | Opponent | L0510 |
| Witch Hunter's Ward | Mine | L0718, L0734, L0824 |

# Doctrine scorecard: h4-mine-bbe8617-p2

### Scorecard: h4-mine-bbe8617-p2

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0108 | 6 | 1 | Mine | no | 10 | 4 | 1 | 1 | 0 | 0 | 0 | 55 |
| L0108 | 6 | 1 | Opponent | no | 7 | 5 | 2 | 1 | 0 | 0 | 0 | 135 |
| L0123 | 3 | 1 | Mine | no | 5 | - | 0 | 2 | 0 | 0 | 0 | 120 |
| L0123 | 3 | 1 | Opponent | no | 2 | 2 | 4 | 3 | 0 | 0 | 0 | 70 |
| L0207 | 3 | 1 | Mine | no | 3 | - | 0 | 4 | 0 | 0 | 0 | 170 |
| L0207 | 3 | 1 | Opponent | no | 0 | 3 | 1 | 0 | 0 | 0 | 0 | 0 |
| L0224 | 2 | 1 | Mine | - | - | 5 | 4 | 5 | 0 | 0 | 0 | 81 |
| L0224 | 2 | 1 | Opponent | - | - | 4 | 1 | 1 | 0 | 0 | 0 | 0 |
| L0308 | 2 | 1 | Mine | - | - | 2 | 0 | 2 | 0 | 0 | 0 | 110 |
| L0308 | 2 | 1 | Opponent | - | - | - | 0 | 2 | 0 | 0 | 0 | 560 |
| L0325 | 1 | 1 | Mine | no | 9 | 2 | 4 | 0 | 0 | 0 | 0 | 110 |
| L0325 | 1 | 1 | Opponent | no | 1 | 2 | 0 | 2 | 1 | 0 | 0 | 0 |
| L0411 | 3 | 1 | Mine | no | 5 | 2 | 1 | 0 | 0 | 0 | 0 | 0 |
| L0411 | 3 | 1 | Opponent | yes | 9 | 4 | 0 | 0 | 0 | 0 | 0 | 0 |
| L0427 | 1 | 1 | Mine | no | 5 | 3 | 3 | 1 | 0 | 0 | 0 | 0 |
| L0427 | 1 | 1 | Opponent | no | 0 | 3 | 5 | 3 | 0 | 0 | 0 | 0 |
| L0513 | 3 | 1 | Mine | no | 2 | - | 0 | 2 | 0 | 0 | 0 | 424 |
| L0513 | 3 | 1 | Opponent | no | 2 | 3 | 3 | 0 | 1 | 0 | 0 | 70 |
| L0530 | 2 | 1 | Mine | - | - | - | 2 | 1 | 0 | 0 | 0 | 734 |
| L0530 | 2 | 1 | Opponent | - | - | 2 | 4 | 3 | 1 | 0 | 0 | 0 |
| L0618 | 6 | 1 | Mine | no | 5 | 5 | 1 | 1 | 0 | 0 | 0 | 60 |
| L0618 | 6 | 1 | Opponent | no | 8 | 3 | 1 | 1 | 1 | 0 | 0 | 0 |
| L0633 | 3 | 1 | Mine | no | 13 | - | 1 | 2 | 0 | 0 | 0 | 328 |
| L0633 | 3 | 1 | Opponent | no | 0 | 3 | 2 | 3 | 0 | 0 | 0 | 0 |
| L0722 | 2 | 1 | Mine | - | - | 2 | 6 | 1 | 0 | 0 | 0 | 295 |
| L0722 | 2 | 1 | Opponent | - | - | 3 | 3 | 1 | 0 | 0 | 0 | 72 |
| L0812 | 2 | 1 | Mine | - | - | - | 0 | 2 | 0 | 0 | 0 | 435 |
| L0812 | 2 | 1 | Opponent | - | - | 2 | 1 | 0 | 0 | 0 | 0 | 165 |
| L0828 | 6 | 1 | Mine | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 585 |
| L0828 | 6 | 1 | Opponent | yes | 1 | - | 1 | 2 | 0 | 0 | 0 | 0 |
| L0919 | 1 | 1 | Mine | no | 0 | 5 | 1 | 1 | 0 | 0 | 0 | 140 |
| L0919 | 1 | 1 | Opponent | no | 0 | 3 | 6 | 1 | 0 | 0 | 0 | 0 |
| L1011 | 3 | 1 | Mine | yes | 15 | 2 | 3 | 0 | 0 | 0 | 0 | 300 |
| L1011 | 3 | 1 | Opponent | yes | 7 | 4 | 2 | 0 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 8% | 6.0 | 3.2 | 1.6 | 1.6 | 0.0 | 0.0 | 0.0 | 232.2 |
| **Average** | | | Opponent | 25% | 3.1 | 3.1 | 2.1 | 1.4 | 0.2 | 0.0 | 0.0 | 63.1 |

### KPIs: h4-mine-bbe8617-p2

Rules off - Opponent only: HOLDER ASSIGNMENT, QUARTER ODDS.

Morten 2026-11-10; 17 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 59% (45 of 76) | 13% (11 of 84) | 35% (56 of 160) |
| Winner chose to follow up after the loser gave ground |  | 71% (17 of 24); on the table 83% | 69% (9 of 13); on the table 69% | 70% (26 of 37); on the table 78% |
| Winner chose to pursue after the loser fell back in good order |  | 40% (2 of 5); on the table 60% | 100% (5 of 5); on the table 100% | 70% (7 of 10); on the table 80% |
| Winner chose to pursue after the loser fled |  | 67% (4 of 6); on the table 83% | 69% (9 of 13); on the table 77% | 68% (13 of 19); on the table 79% |
| Winner chose to follow up or pursue (all three) |  | 66% (23 of 35); on the table 80% | 74% (23 of 31); on the table 77% | 70% (46 of 66); on the table 79% |
| Magic missiles tried each own turn | 50%+ | 34% (60 of 177) | 36% (37 of 104) | 35% (97 of 281) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 44% (60 of 135) | 44% (37 of 84) | 44% (97 of 219) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 58% (7 of 12) | - | 58% (7 of 12) |
| Points that never fought | lower | 51% (16865 of 32750) | 53% (18004 of 33994) | 52% (34869 of 66744) |
|   infantry points that never fought | lower | 51% (4613 of 9010) | 62% (3242 of 5216) | 55% (7855 of 14226) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 63% (85 of 135) | 56% (73 of 130) | 60% (158 of 265) |
| Bound items with a magic missile used (at least once a game) |  | 100% (8 of 8); 1.5 uses a game | 100% (11 of 11); 1.9 uses a game | 100% (19 of 19); 1.7 uses a game |
| Bound items with another spell used |  | 75% (3 of 4); 0.5 uses a game | 67% (2 of 3); 0.1 uses a game | 71% (5 of 7); 0.3 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 50% (6 of 12); 0.4 uses a game | 33% (3 of 9); 0.2 uses a game | 43% (9 of 21); 0.3 uses a game |
|   their share of the points of units over 100 pts | lower | 57% (14868 of 26122) | 50% (14951 of 29772) | 53% (29819 of 55894) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.8 (26%) | 0.6 (16%) | 2.4 (22%) |
| MARCHED: its unit marched | 1.5 (21%) | 0.9 (24%) | 2.4 (22%) |
| CHARGED: its unit charged | 0.2 (3%) | 0.0 (0%) | 0.2 (2%) |
| IN COMBAT: engaged in combat | 1.5 (22%) | 0.6 (15%) | 2.1 (20%) |
| REAR RANK: in a rear rank | 0.7 (10%) | 0.9 (24%) | 1.6 (15%) |
| GONE: slain | 0.9 (14%) | 0.5 (13%) | 1.5 (14%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (0%) | 0.1 (1%) | 0.1 (1%) |
| STUPIDITY: Stupidity | 0.2 (3%) | 0.0 (0%) | 0.2 (2%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (1%) | 0.1 (3%) | 0.2 (2%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.1 (3%) | 0.1 (1%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 3.1 | 1.6 | 1.6 | 5.7 | 0.8 | 1.6 |
| not cast | 3.2 | 2.4 | 4.4 | 10.8 | 2.1 | 23.8 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.5 (6%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.8 (73%) | 0.5 (11%) | 2.4 (22%) | 0.6 (31%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.4 (22%) | 0.5 (23%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (2%) | 0.1 (3%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.4 (11%) | 0.2 (7%) | 0.6 (13%) | 2.1 (20%) | 0.3 (14%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.6 (18%) | 0.0 (0%) | 0.7 (16%) | 1.6 (15%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (0%) |
| GONE: slain | 0.8 (25%) | 0.2 (10%) | 0.4 (9%) | 1.5 (14%) | 0.2 (11%) | 2.4 (10%) |
| OFF THE TABLE: off the table or not arrived | 0.3 (9%) | 0.1 (5%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.2 (1%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.0 (0%) | 0.2 (4%) | 0.2 (2%) | 0.0 (0%) | 0.2 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.1 (2%) | 0.0 (0%) | 0.2 (2%) | 0.4 (17%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.2 (36%) | 0.1 (2%) | 2.1 (47%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 19.4 (82%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.3 a game | 0.7 a game | 1.0 a game |
| stood (cast and not dispelled) | 64% (14 of 22) | 58% (7 of 12) | 62% (21 of 34) |
| the unit moved after it | 71% (10 of 14) | 100% (7 of 7) | 81% (17 of 21) |
| it charged on its next turn | 0% (0 of 14) | 0% (0 of 7) | 0% (0 of 21) |
| the enemy charged it first | 14% (2 of 14) | 0% (0 of 7) | 10% (2 of 21) |
| it fought by the end of its next turn | 0% (0 of 14) | 0% (0 of 7) | 0% (0 of 21) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 14) | 0% (0 of 7) | 0% (0 of 21) |
| none of these (no charge, no fight, no charge escaped) | 86% (12 of 14) | 100% (7 of 7) | 90% (19 of 21) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 62% (324 of 522) | 51% (171 of 335) | 58% (495 of 857) |
|   cavalry | 57% (26 of 46) | 52% (27 of 52) | 54% (53 of 98) |
|   character | 89% (47 of 53) | 31% (13 of 42) | 63% (60 of 95) |
|   chariot | 52% (31 of 60) | 63% (17 of 27) | 55% (48 of 87) |
|   infantry | 57% (69 of 121) | 57% (58 of 102) | 57% (127 of 223) |
|   monster | 55% (6 of 11) | 62% (5 of 8) | 58% (11 of 19) |
|   war machine | 63% (145 of 231) | 49% (51 of 104) | 59% (196 of 335) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.6 (22%) | 1.8 (18%) | 4.4 (20%) |
| CHARGED: it charged | 0.7 (6%) | 1.1 (11%) | 1.8 (8%) |
| FLEEING: it fled or was fleeing | 0.2 (2%) | 0.1 (1%) | 0.3 (1%) |
| IN COMBAT: it fought this turn or the last | 0.9 (8%) | 0.5 (5%) | 1.4 (7%) |
| MOVED: a war machine that moved | 1.4 (12%) | 1.9 (20%) | 3.3 (15%) |
| HELD FIRE: a target, but it held its fire | 0.0 (0%) | 0.1 (1%) | 0.1 (0%) |
| NO TARGET IN RANGE | 2.5 (21%) | 1.5 (15%) | 3.9 (19%) |
| ONLY IN COMBAT: the only targets were in combat | 0.2 (2%) | 0.3 (3%) | 0.5 (2%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.9 (17%) | 1.8 (18%) | 3.7 (17%) |
| SHELTERED: the target was sheltered | 0.8 (7%) | 0.2 (2%) | 1.1 (5%) |
| OTHER BAR | 0.5 (4%) | 0.5 (5%) | 0.9 (4%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 5.2 | 1.9 | 72% | 9.8 pts | 51 pts |
| character | 4.0 | 1.2 | 74% | 7.6 pts | 30 pts |
| chariot | 2.9 | 4.6 | 43% | 24.8 pts | 72 pts |
| infantry | 11.9 | 4.5 | 73% | 7.2 pts | 85 pts |
| monster | 0.9 | 0.1 | 93% | 1.1 pts | 1 pts |
| war machine | 11.7 | 11.3 | 59% | 28.3 pts | 331 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 2.5 | 4.6 | 3.5 |
| Charges that made contact a game | 1.8 | 2.8 | 2.3 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.78 declared, 0.67 contact (9 units) | 0.90 declared, 0.90 contact (10 units) | 0.84 declared, 0.79 contact (19 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 1.20 declared, 1.00 contact (5 units) | 1.20 declared, 1.00 contact (5 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.31 declared, 0.22 contact (114 units) | 0.54 declared, 0.29 contact (117 units) | 0.42 declared, 0.26 contact (231 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 52% (13 of 25) | 30% (3 of 10) | 40% (2 of 5) | 45% (18 of 40) |
| Character in a unit | 89% (25 of 28) | 43% (6 of 14) | 0% (0 of 1) | 72% (31 of 43) |
| Character on its own | 82% (14 of 17) | 62% (10 of 16) | 21% (4 of 19) | 54% (28 of 52) |
| Chariot | 75% (3 of 4) | 69% (9 of 13) | - | 71% (12 of 17) |
| Infantry | 40% (10 of 25) | 38% (8 of 21) | 75% (3 of 4) | 42% (21 of 50) |
| Monster | 75% (6 of 8) | 100% (2 of 2) | - | 80% (8 of 10) |
| Monstrous | 100% (1 of 1) | 40% (2 of 5) | - | 50% (3 of 6) |
| War Machines | 78% (35 of 45) | 100% (2 of 2) | - | 79% (37 of 47) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 50% (5 of 10); on the table 90% | 36% (37 of 102) | 28% | 32% (7 of 22) | 100% (6 of 6); 5.2 uses a game | 100% (2 of 2); 1.8 uses a game | 67% (4 of 6); 1.0 uses a game |
| Chaos Dwarfs | 4 | 80% (4 of 5); on the table 80% | 33% (12 of 36) | 65% | 66% (21 of 32) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
| Dwarfen Mountain Holds | 4 | 75% (9 of 12); on the table 75% | - | 56% | 74% (25 of 34) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 7 | 60% (6 of 10); on the table 70% | 50% (15 of 30) | 67% | 65% (47 of 72) | 0.0 uses a game | 100% (2 of 2); 0.4 uses a game | 50% (3 of 6); 0.4 uses a game |
| Grand Cathay | 4 | 80% (4 of 5); on the table 80% | 34% (24 of 71) | 49% | 53% (16 of 30) | 100% (9 of 9); 6.8 uses a game | 0% (0 of 1); 0.0 uses a game | 0% (0 of 4); 0.2 uses a game |
| High Elf Realms | 1 | - | 0% (0 of 6) | 35% | 25% (2 of 8) | 100% (1 of 1); 3.0 uses a game | 50% (1 of 2); 1.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 1 | 100% (1 of 1); on the table 100% | 0% (0 of 6) | 66% | 71% (5 of 7) | 100% (1 of 1); 2.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 1 | 100% (3 of 3); on the table 100% | 0% (0 of 12) | 35% | 62% (5 of 8) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Tomb Kings of Khemri | 2 | 50% (2 of 4); on the table 50% | - | 27% | 50% (5 of 10) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 3 | 57% (4 of 7); on the table 71% | 42% (5 of 12) | 39% | 58% (11 of 19) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 2 | 100% (3 of 3); on the table 100% | 67% (4 of 6) | 78% | 69% (9 of 13) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 0.5 uses a game |
| Wood Elf Realms | 1 | 83% (5 of 6); on the table 83% | - | 52% | 50% (5 of 10) | 100% (2 of 2); 5.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (h4-mine-bbe8617-p2, 17 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 58% (11) | 50% (12) | 53% (23) |
| ...free all their last turn and able to turn (per game) | 0.47 | 0.59 | 1.06 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.12 | 0.00 | 0.12 |
| ...with the charger already in that arc before they moved (per game) | 0.29 | 0.35 | 0.65 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.29 | 0.00 | 0.29 |

### Quality by phase: h4-mine-bbe8617-p2

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.5 | 2.3 |
| Strategy | Charge objectives carried out (made contact) | 58% (23 of 40) | 52% (32 of 62) |
| Strategy | Shoot objectives carried out (shot that target) | 47% (121 of 259) | 39% (50 of 129) |
| Strategy | Support requests answered (helper made contact too) | 25% (1 of 4) | 20% (1 of 5) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (2 of 2) | 100% (1 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | 0% (0 of 2) | 40% (2 of 5) |
| Strategy | Joined characters whose unit fought | 55% (21 of 38) | 33% (9 of 27) |
| Strategy | Lone characters that fought | 55% (21 of 38) | 62% (26 of 42) |
| Movement | Charges halted short of contact | 0.1 | 0.2 |
| Movement | Idle units | 1.6 | 1.4 |
| Movement | Points that never moved of their own | 232.2 | 63.1 |
| Movement | Fights charged into per game | 1.9 | 2.5 |
| Movement | Charges with odds: long shots (under 50%) | 4 of 30, net -0 | 12 of 38, net +62 |
| Movement | Charges with odds: sweet spot (55-75%) | 5 of 30, net +49 | 6 of 38, net +71 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 2 of 30, net +55 | 6 of 38, net +65 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 10 of 30, net +92 | 5 of 38, net +84 |
| Shooting | Shots by shooting units (incl. breath weapons) | 11.7 | 7.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 41% (81 of 199) | 46% (60 of 131) |
| Shooting | Points destroyed by shooting units | 164.4 | 13.5 |
| Shooting | War machine shots | 8.5 | 3.2 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 56% (81 of 145) | 54% (29 of 54) |
| Shooting | Points destroyed by war machines | 70.6 | 62.0 |
| Magic | Magic missiles cast | 1.8 | 1.7 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 29% (9 of 31) | 38% (11 of 29) |
| Magic | Wounds caused by magic missiles | 4.1 | 1.5 |
| Magic | Wounds caused by other spells | 1.6 | 0.8 |
| Magic | Points destroyed by magic (all spells) | 47.5 | 26.8 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.6 / 0.1 / 0.9 / 0.1 | 1.6 / 0.5 / 0.4 / 0.5 |
| Combat | Points destroyed in combat | 200.6 | 224.8 |
| Combat | Points run down | 107.3 | 91.9 |
| Combat | Net points per charged fight, damage counted | +69 | +50 |
| Combat | Net per 100 charger points, damage counted | +31.4 | +17.7 |
| Combat | First round won (charged fights) | 75% | 63% |
| Combat | Net points per charged fight | +78 | +74 |
| Combat | Net points per supported fight / lone fight | +347 / +69 | +79 / +73 |
| Combat | Charged fights on a top-3 enemy unit | 13 of 32 | 21 of 43 |
| Game | Points lost | 487.4 | 626.9 |
| Game | VP from objectives | 630.0 | 643.5 |
| Game | Lone holders (player turns) | 6.0 | 3.1 |

- Mine won / drew / lost: 8 / 3 / 6 of 17 ended games (of 17); mean margin (Mine - Opponent) +141 VP
- The side that went first won 4 of 14 games with a winner
- Points traded per game (both sides' losses): 1114
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: h4-mine-bbe8617-p2

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.8 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.4 | +55.3 | 0.0 | 43.4 | 0.2 | +11.5 | 0.0 | 0.0 |
| ARRIVAL HUNT | - | - | - | - | 0.1 | +1.3 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 2.4 | +0.0 | 0.0 | 20.9 | 0.9 | +0.0 | 0.0 | 9.7 |
| BACKUP TARGETS | - | - | - | - | 0.2 | +1.1 | 0.0 | 0.0 |
| BEST PRIZE | - | - | - | - | 0.1 | -18.8 | 13.5 | 0.0 |
| BLOWS WHERE AIMED | 0.2 | -6.6 | 33.4 | 0.0 | 0.2 | -26.1 | 3.8 | 11.5 |
| BOMBING RUN | 0.1 | +0.6 | 2.0 | 0.0 | 0.1 | +3.4 | 0.0 | 17.6 |
| CANNON PLAN MISSED | 1.3 | +0.0 | 176.2 | 25.6 | 0.5 | +0.0 | 36.7 | 7.4 |
| CANNON PLANNED TARGET | 8.1 | +259.3 | 494.5 | 75.0 | 2.5 | +65.8 | 130.8 | 42.4 |
| CANNON SIGHT KEPT | 1.5 | +0.0 | 0.0 | 5.9 | 0.6 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT SET-UP | - | - | - | - | 0.1 | -1.4 | 4.9 | 0.0 |
| CAST JOB | 0.8 | +10.3 | 61.9 | 21.7 | 0.4 | +4.3 | 0.0 | 20.6 |
| CASTER AWAY FROM SCREEN | 0.5 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CASTING BLOCK | 0.4 | +43.7 | 0.0 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | 0.8 | +0.0 | 0.0 | 20.9 | 0.4 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.1 | +1.3 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | 0.3 | +8.9 | 0.0 | 6.5 | 0.5 | +13.0 | 0.0 | 29.9 |
| CHAFF PASSED | - | - | - | - | 0.2 | -1.3 | 0.0 | 0.0 |
| CHARACTER GUNS | 0.8 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 0.0 |
| CHARGE LOSSES | 6.1 | -339.7 | 0.0 | 81.0 | 6.2 | -402.6 | 0.0 | 154.1 |
| CHARGE NOT DECLARED | 0.4 | +0.0 | 76.2 | 0.0 | 0.5 | +0.0 | 18.8 | 16.6 |
| CHARGE NOW FIRST | 1.1 | +0.0 | 142.5 | 24.4 | 1.4 | +0.0 | 67.1 | 44.9 |
| CHARGER SLAIN LOST | 0.3 | -7.0 | 44.9 | 0.0 | 0.4 | -13.6 | 0.0 | 29.4 |
| CHEAP HELPER | 0.2 | +0.0 | 67.5 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CHEAPEST HOLDER | - | - | - | - | 0.2 | -8.4 | 26.8 | 0.0 |
| COMBAT PIVOT | 0.2 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 5.4 | 4.4 |
| CONVEYANCE SEARCH | 1.0 | +68.1 | 3.8 | 20.9 | 0.3 | +5.2 | 0.0 | 0.0 |
| COVER ONCE | 6.3 | -331.3 | 0.0 | 104.1 | 5.4 | -428.2 | 0.0 | 183.1 |
| DEFENSIVE ARMY | 0.1 | +0.0 | 3.2 | 0.0 | - | - | - | - |
| DEPLOY BY FIGURES | 9.1 | -18.2 | 0.0 | 12.6 | 7.0 | -35.8 | 0.0 | 13.9 |
| EDGE GIVE GROUND | 0.1 | +0.2 | 10.0 | 0.0 | 0.2 | +3.5 | 30.8 | 0.0 |
| ENGINEER BY LORE | 0.2 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FALL BACK GOOD ORDER | 1.4 | +4.3 | 149.4 | 29.8 | 2.6 | +8.0 | 167.6 | 13.5 |
| FALLBACK BY WORTH | 0.7 | +1.3 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 6.2 |
| FALLS SHORT | 6.0 | +121.9 | 0.0 | 96.0 | 18.2 | +275.0 | 0.0 | 361.1 |
| FEATURE BUFFS | 1.4 | +36.9 | 0.0 | 4.8 | 0.7 | +15.8 | 0.0 | 28.0 |
| FIGHT TO THE END | 0.9 | +35.1 | 68.1 | 11.5 | 1.5 | +27.4 | 108.7 | 37.0 |
| FIRE AND FLEE | 0.1 | +1.0 | 0.0 | 3.5 | 0.1 | +7.9 | 18.2 | 24.5 |
| FIRE IN ORDER | 0.5 | +0.0 | 49.5 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| FIVE ACTION | 49.2 | +2883.0 | 1149.6 | 380.6 | 44.3 | +3016.7 | 491.7 | 755.9 |
| FLANK NOT WEIGHED | 5.4 | +0.0 | 0.0 | 90.8 | 3.9 | +0.0 | 0.0 | 143.4 |
| FOCUS FIRE | 0.1 | +0.1 | 20.6 | 0.0 | - | - | - | - |
| FOLLOW UP WEIGHED | 0.6 | +95.1 | 0.0 | 6.2 | 0.4 | +35.1 | 0.0 | 0.0 |
| FOUR ROUNDS | 2.2 | +188.2 | 241.8 | 29.8 | 3.6 | +474.1 | 212.1 | 85.5 |
| FRIEND CHARGES FIRST | 0.1 | -11.7 | 0.0 | 0.0 | 0.1 | -0.7 | 0.0 | 23.1 |
| FRIEND SHOOTS FIRST | 0.6 | -17.2 | 0.0 | 3.5 | 0.2 | -30.6 | 0.0 | 0.0 |
| FRIENDS SHOTS CHECKED | 0.2 | +12.2 | 0.0 | 0.0 | 0.2 | +4.3 | 0.0 | 0.0 |
| GIVES UP | 0.1 | -2.4 | 0.0 | 0.0 | 0.6 | -16.5 | 45.9 | 11.1 |
| GIVES UP ITS SCREEN | - | - | - | - | 0.1 | -0.1 | 6.2 | 0.0 |
| GROUND FLIERS | - | - | - | - | 0.1 | +1.6 | 0.0 | 0.0 |
| GUN FIGURES | 1.5 | +21.6 | 103.6 | 0.0 | 0.9 | +0.0 | 0.0 | 0.0 |
| GUN MASK | 0.5 | +20.8 | 0.0 | 0.0 | 1.2 | +35.9 | 0.0 | 8.8 |
| HARD STAY DROPPED | 2.2 | +0.0 | 0.0 | 6.1 | 1.1 | +0.0 | 0.0 | 0.0 |
| HE SHOOTS OR CHARGES | 1.8 | +0.0 | 0.0 | 41.4 | 1.8 | +0.0 | 0.0 | 39.1 |
| HELPER UNSEEN | - | - | - | - | 0.1 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE DENIED | 0.2 | +12.6 | 15.0 | 0.0 | - | - | - | - |
| HIS CHARGE LIST | 3.9 | +0.0 | 0.0 | 26.5 | 2.6 | +0.0 | 0.0 | 64.4 |
| HIS LEGAL MOVES | 2.4 | +0.0 | 0.0 | 25.2 | 3.6 | +0.0 | 0.0 | 106.9 |
| HIS MOVE AND SHOT | 2.2 | -27.0 | 0.0 | 48.1 | 1.9 | -75.2 | 0.0 | 34.0 |
| HIS RANDOM MOVE | - | - | - | - | 1.7 | +0.0 | 0.0 | 8.1 |
| HIS SHOT LIST | 21.7 | +845.7 | 0.0 | 168.7 | 23.0 | +1604.2 | 0.0 | 427.1 |
| HIS TURN DENIED | 1.1 | +55.3 | 138.1 | 24.4 | 2.2 | +157.0 | 102.9 | 71.4 |
| HOLD ODDS | 6.3 | +0.0 | 0.0 | 45.4 | - | - | - | - |
| HOLDER ASSIGNMENT | 12.0 | +1134.2 | 0.0 | 68.5 | - | - | - | - |
| HOLDER AT DEPLOYMENT | - | - | - | - | 0.9 | +166.3 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 0.2 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 2.0 | -58.7 | 220.8 | 29.8 | 3.2 | -130.1 | 205.6 | 65.1 |
| HORN WORTH | - | - | - | - | 0.1 | +1.2 | 0.0 | 0.0 |
| HUNT IN PAIRS | 0.4 | +4.1 | 0.0 | 0.0 | 1.0 | +44.6 | 0.0 | 72.1 |
| HUNT RESULT | - | - | - | - | 0.1 | +8.2 | 0.0 | 0.0 |
| HUNT THE GUNS | - | - | - | - | 0.1 | +8.6 | 6.5 | 0.0 |
| IDLE COST | 2.1 | -24.7 | 0.0 | 6.1 | 9.1 | -155.9 | 0.0 | 157.6 |
| KEEP FALLS | 0.2 | +0.7 | 0.0 | 0.0 | - | - | - | - |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KILLS COUNT | 0.1 | +9.4 | 23.9 | 0.0 | - | - | - | - |
| LANE BY FIGURES | 0.3 | +13.0 | 0.0 | 0.0 | 0.8 | +42.0 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 3.3 | +0.0 | 171.8 | 180.4 | 2.7 | +0.0 | 136.5 | 162.2 |
| LONE CHARACTER SAFE SPOT | 0.2 | +0.7 | 0.0 | 0.0 | - | - | - | - |
| LONE WIZARD KEPT IN | 0.7 | +55.8 | 0.0 | 0.0 | 0.4 | +39.7 | 0.0 | 0.0 |
| LONG SHOT | 0.2 | +1.6 | 11.5 | 0.0 | 0.3 | +2.2 | 5.3 | 0.0 |
| LOST CHARGE | - | - | - | - | 0.1 | -1.2 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 0.1 | +2.6 | 0.0 | 0.0 | - | - | - | - |
| MANOEUVRE | 1.6 | +39.5 | 0.0 | 12.8 | 1.1 | +30.4 | 0.0 | 65.8 |
| MARCH AT ESCAPER | 0.2 | +2.7 | 0.0 | 0.0 | 0.1 | +0.8 | 0.0 | 0.0 |
| MARCH BY THE SUM | 0.4 | +23.3 | 0.0 | 0.0 | 0.6 | +35.5 | 0.0 | 0.0 |
| MARCH CHECK | 1.3 | +113.7 | 0.0 | 14.3 | 1.8 | +117.6 | 0.0 | 20.4 |
| MARCH ODDS | 0.1 | +3.9 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 1.1 | +64.9 | 0.0 | 21.7 | 0.8 | -1.5 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 6.1 | +85.0 | 0.0 | 90.1 | 5.5 | +89.3 | 0.0 | 171.9 |
| MISSILES IN THE MOVE | 3.6 | +175.8 | 0.0 | 49.6 | 4.4 | +96.7 | 0.0 | 179.9 |
| MISSILES NEXT TURN | 5.0 | +127.4 | 0.0 | 71.4 | 5.3 | +62.9 | 0.0 | 159.2 |
| MODEL FACING | 0.5 | +62.3 | 0.0 | 7.1 | - | - | - | - |
| MOVE SPELL IN RANGE | 0.4 | +9.2 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.8 | -33.5 | 0.0 | 41.8 | 0.1 | -4.1 | 0.0 | 0.0 |
| MOVE SPELL SPOT | 0.4 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 2.8 | +369.1 | 0.0 | 7.1 | 3.5 | +479.0 | 0.0 | 79.3 |
| MOVES UNITS SPELL | 0.1 | +6.5 | 0.0 | 0.0 | 0.1 | +0.3 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 6.8 | +318.9 | 0.0 | 41.6 | 4.7 | +294.2 | 0.0 | 33.8 |
| NEEDED THERE | 0.1 | +38.3 | 23.9 | 0.0 | - | - | - | - |
| NEXT CHARGE BY LIST | 4.1 | -231.0 | 0.0 | 10.3 | 6.0 | -283.9 | 0.0 | 212.2 |
| NEXT OBJECTIVE NEARER | - | - | - | - | 8.0 | -485.8 | 47.6 | 112.0 |
| NO DOUBLE ROUNDS | 1.9 | -84.0 | 207.9 | 29.8 | 3.2 | -126.2 | 199.1 | 82.5 |
| NOT TURNED | 0.3 | -2.4 | 0.0 | 1.8 | - | - | - | - |
| NOT WORTH A CAST | 0.1 | -0.1 | 0.0 | 0.0 | 0.6 | -0.5 | 0.0 | 0.0 |
| OFF BEST | 0.5 | -15.7 | 0.0 | 6.6 | 0.8 | -19.1 | 0.0 | 5.8 |
| ONE CHARGE A CHARGER | 2.6 | +0.0 | 0.0 | 49.5 | 1.6 | +0.0 | 0.0 | 38.1 |
| ONE FIGHT FORMULA | 4.6 | -76.1 | 0.0 | 73.4 | 4.7 | -122.4 | 0.0 | 152.4 |
| ONE OBJECTIVE FORMULA | 4.3 | -9.5 | 0.0 | 21.9 | 4.4 | -57.3 | 0.0 | 66.4 |
| ONE TARGET A SHOOTER | 15.4 | +433.4 | 0.0 | 128.9 | 17.4 | +676.1 | 0.0 | 302.6 |
| OPENS UP | 0.1 | +7.2 | 3.2 | 0.0 | 0.2 | +14.9 | 13.3 | 0.0 |
| OVERRUNS AWAY | 0.2 | +1.9 | 14.4 | 11.5 | 0.4 | +7.9 | 41.2 | 6.1 |
| PATHS CROSS | 2.8 | +115.4 | 0.0 | 24.6 | 5.1 | +211.7 | 0.0 | 74.9 |
| PIVOT GUARDS FLANK | 0.1 | -1.5 | 0.0 | 0.0 | 0.1 | -0.5 | 0.0 | 0.0 |
| PLAN RESULT | 44.1 | +1129.6 | 678.8 | 560.8 | 39.8 | +538.9 | 257.8 | 934.1 |
| PURSUES BIG PREY | 0.1 | -14.2 | 0.0 | 0.0 | 0.1 | -0.8 | 0.0 | 0.0 |
| QUARTER ODDS | 3.2 | +444.4 | 71.2 | 11.6 | - | - | - | - |
| RANDOM MOVE BY FIGURES | 0.7 | +1.6 | 0.0 | 0.0 | - | - | - | - |
| REDIRECT BY WHAT IT STOPS | 0.1 | -2.0 | 0.0 | 1.8 | 0.2 | +1.6 | 0.0 | 15.5 |
| REDIRECT COUNTER | 2.0 | +238.7 | 0.0 | 40.2 | 2.5 | +110.9 | 0.0 | 47.8 |
| REDIRECT WEIGHED | 0.1 | +0.0 | 0.0 | 0.0 | 0.5 | -17.7 | 13.5 | 23.1 |
| REFORMS TO MEET IT | 0.8 | -57.8 | 0.0 | 0.0 | 0.6 | -13.9 | 0.0 | 44.2 |
| REFUSING RETIRES | 0.2 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| RESERVE FALL BACK | 0.3 | +6.4 | 0.0 | 6.6 | 0.6 | +24.4 | 0.0 | 23.1 |
| RESTRAINS TO SHOOT | 0.1 | +8.0 | 0.0 | 12.6 | - | - | - | - |
| RISK BY ARC | 1.5 | +41.7 | 161.6 | 11.5 | 2.2 | +23.4 | 129.6 | 56.2 |
| RISK BY HIS FIGURE | 12.2 | -255.6 | 0.0 | 159.5 | 10.8 | -209.5 | 0.0 | 288.6 |
| RUN DOWN | 1.1 | -11.2 | 141.9 | 24.4 | 3.2 | -33.0 | 206.5 | 71.1 |
| SAME CHARGE LATER | 0.1 | -0.4 | 0.0 | 0.0 | 0.2 | -1.8 | 0.0 | 0.0 |
| SCOUT SPOT | 0.4 | +0.5 | 0.0 | 3.2 | 0.5 | +1.0 | 0.0 | 0.0 |
| SCOUT WAITS | 0.4 | +0.0 | 0.0 | 3.2 | 0.5 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.1 | -1.0 | 0.0 | 0.0 | 0.1 | -14.7 | 0.0 | 0.0 |
| SEARCH SPOT | 5.6 | +230.5 | 0.0 | 65.7 | 6.4 | +364.7 | 0.0 | 93.4 |
| SET UP TOGETHER | 0.3 | +5.8 | 0.0 | 0.0 | 0.4 | +10.9 | 0.0 | 0.0 |
| SET-UP ANY TARGET | 0.3 | +42.6 | 0.0 | 0.0 | 0.1 | +4.6 | 0.0 | 0.0 |
| SET-UP MISSED | 0.1 | +3.2 | 0.0 | 0.0 | 0.1 | +7.4 | 10.5 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.5 | +1.1 | 0.0 | 0.0 | 0.1 | +0.5 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 0.9 | +54.6 | 70.9 | 6.2 | 1.1 | +42.6 | 37.9 | 35.3 |
| SHORT GUN FORWARD | 0.5 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| SHOT OR CHARGE | 0.5 | -9.8 | 73.0 | 6.2 | 0.3 | -59.1 | 0.0 | 0.0 |
| SHOT RISK POINTS | 11.5 | +40.0 | 0.0 | 117.9 | 13.3 | +47.7 | 0.0 | 267.0 |
| SHOTS IN THE MOVE | 19.6 | +1003.5 | 0.0 | 153.6 | 13.0 | +418.3 | 0.0 | 215.8 |
| SPELL SETS UP CHARGE | 0.4 | +84.0 | 0.0 | 0.0 | 0.1 | +4.6 | 0.0 | 0.0 |
| SPELL WORTH | 0.3 | +4.0 | 3.8 | 20.9 | 1.6 | +31.4 | 96.4 | 96.4 |
| SPELLS IN THE FIGHT | 0.4 | +4.2 | 55.6 | 0.0 | 0.6 | +8.2 | 30.3 | 46.2 |
| STAND AND SHOOT | 0.2 | -4.2 | 32.5 | 18.2 | 1.0 | -17.0 | 32.7 | 15.0 |
| STANDS FOR A REASON | 0.3 | +0.0 | 18.3 | 21.7 | 0.6 | +0.0 | 0.0 | 24.9 |
| STANDS STILL | 24.7 | +0.0 | 885.2 | 142.3 | 12.7 | +0.0 | 243.9 | 197.4 |
| STAY WORTH | 25.8 | +165.6 | 466.1 | 156.2 | 14.3 | +118.9 | 124.1 | 167.1 |
| STOPS | - | - | - | - | 0.1 | +0.2 | 6.5 | 0.0 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SUPPORT NARROWED | 0.9 | +0.0 | 94.5 | 0.0 | 1.0 | +0.0 | 75.2 | 39.0 |
| SURE REACH TOGETHER | 0.2 | +5.9 | 0.0 | 0.0 | 0.8 | +16.1 | 0.0 | 9.2 |
| THE DEARER SUM KEEPS ITS PLAN | 3.3 | +0.0 | 0.0 | 28.1 | 4.8 | +0.0 | 0.0 | 71.3 |
| THE PROMISE ADDS | 0.1 | -0.6 | 0.0 | 0.0 | 0.2 | -17.8 | 0.0 | 12.2 |
| THE PROMISED MOVE | 0.6 | +0.0 | 0.0 | 7.1 | 0.2 | +0.0 | 0.0 | 0.0 |
| TIED UP BY THE SUM | 0.3 | +25.4 | 30.5 | 18.2 | 0.6 | +85.6 | 42.1 | 0.0 |
| TIME ON OUR SIDE | 27.8 | +403.2 | 20.4 | 131.4 | 8.6 | +148.8 | 0.0 | 120.9 |
| WAITS AGAIN | 0.9 | +0.0 | 0.0 | 0.0 | 1.5 | +0.0 | 0.0 | 26.5 |
| WAR ENGINE CHARGES | 0.4 | +58.4 | 56.8 | 0.0 | - | - | - | - |
| WAR ENGINE JOBS | 0.4 | +0.0 | 9.7 | 0.0 | 0.1 | +0.0 | 3.5 | 0.0 |
| WHO HITS BACK | 0.1 | +6.7 | 0.0 | 6.2 | 0.1 | +6.4 | 0.0 | 0.0 |
| WHOLE FIGHT | 0.2 | +3.9 | 45.1 | 0.0 | 0.1 | -0.0 | 0.0 | 2.9 |
| WHOLE FIGHT GAIN | 0.2 | +14.7 | 26.0 | 0.0 | 0.1 | +6.2 | 6.5 | 0.0 |
| WIDER SPREAD | 1.8 | -6.4 | 210.6 | 24.4 | 2.2 | -3.9 | 120.8 | 85.5 |
| WOUNDS ON THE RANKS | 1.6 | +129.7 | 0.0 | 14.1 | 2.1 | +186.7 | 0.0 | 77.2 |

### Rule changes: h4-mine-bbe8617-p2

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS SHOT LIST | 760 | 760 | 202 | 11.88 | +6631 | +32.8 |
| SEARCH SPOT | 203 | 203 | 196 | 11.53 | +10118 | +51.6 |
| HOLDER ASSIGNMENT | 204 | 204 | 192 | 11.29 | +10377 | +54.0 |
| DEPLOY BY FIGURES | 273 | 273 | 169 | 9.94 | +2553 | +15.1 |
| ONE TARGET A SHOOTER | 558 | 558 | 137 | 8.06 | +2366 | +17.3 |
| PATHS CROSS | 134 | 134 | 134 | 7.88 | +5561 | +41.5 |
| FIVE ACTION | 1589 | 1588 | 115 | 6.76 | +4449 | +38.7 |
| LEGAL CHARGES ONLY | 102 | 102 | 102 | 6.00 | +0 | +0.0 |
| TIME ON OUR SIDE | 619 | 563 | 100 | 5.88 | +210 | +2.1 |
| SHOT RISK POINTS | 421 | 421 | 79 | 4.65 | +3069 | +38.8 |
| MOVE TO CHARGE COMPUTED | 107 | 107 | 62 | 3.65 | +4175 | +67.3 |
| ARTILLERY RE-ROLL WEIGHED | 56 | 56 | 56 | 3.29 | +0 | +0.0 |
| HARD STAY DROPPED | 56 | 56 | 56 | 3.29 | +0 | +0.0 |
| FOUR ROUNDS | 99 | 98 | 50 | 2.94 | +2857 | +57.1 |
| MAX FOR POSITIONING | 197 | 191 | 41 | 2.41 | +90 | +2.2 |
| COVER ONCE | 198 | 159 | 38 | 2.24 | +425 | +11.2 |
| CANNON SIGHT KEPT | 36 | 36 | 36 | 2.12 | +0 | +0.0 |
| MARCH CHECK | 53 | 53 | 36 | 2.12 | +750 | +20.8 |
| SHOTS IN THE MOVE | 555 | 535 | 32 | 1.88 | +1588 | +49.6 |
| FALLS SHORT | 411 | 362 | 28 | 1.65 | +170 | +6.1 |
| ADVANCE LANE KEPT | 26 | 26 | 26 | 1.53 | +0 | +0.0 |
| MANOEUVRE | 45 | 45 | 26 | 1.53 | +1274 | +49.0 |
| SHOOTS FROM THE BEST SPOT | 34 | 34 | 26 | 1.53 | +598 | +23.0 |
| CHARGE LOSSES | 210 | 210 | 25 | 1.47 | +2132 | +85.3 |
| RISK BY HIS FIGURE | 391 | 391 | 25 | 1.47 | +2089 | +83.6 |
| CANNON PLANNED TARGET | 180 | 180 | 24 | 1.41 | -1106 | -46.1 |
| RISK BY ARC | 64 | 63 | 23 | 1.35 | +424 | +18.5 |
| OFF BEST | 22 | 22 | 22 | 1.29 | -592 | -26.9 |
| STAY WORTH | 682 | 666 | 20 | 1.18 | +307 | +15.3 |
| LANE BY FIGURES | 19 | 19 | 19 | 1.12 | +935 | +49.2 |
| LONE WIZARD KEPT IN | 19 | 19 | 19 | 1.12 | +1624 | +85.5 |
| MISSILES IN THE MOVE | 136 | 111 | 19 | 1.12 | +237 | +12.5 |
| HIS TURN DENIED | 57 | 57 | 18 | 1.06 | +993 | +55.2 |
| MARCH BY THE SUM | 18 | 18 | 18 | 1.06 | +999 | +55.5 |
| WOUNDS ON THE RANKS | 63 | 63 | 18 | 1.06 | +1262 | +70.1 |
| FOLLOW UP WEIGHED | 17 | 17 | 17 | 1.00 | +2214 | +130.2 |
| QUARTER ODDS | 54 | 54 | 17 | 1.00 | +1275 | +75.0 |
| IDLE COST | 190 | 153 | 16 | 0.94 | +212 | +13.2 |
| NEXT OBJECTIVE NEARER | 136 | 136 | 16 | 0.94 | +136 | +8.5 |
| REDIRECT COUNTER | 76 | 72 | 16 | 0.94 | +1218 | +76.1 |
| CHARGE NOT DECLARED | 15 | 15 | 15 | 0.88 | -1640 | -109.3 |
| RESERVE FALL BACK | 15 | 15 | 15 | 0.88 | +524 | +34.9 |
| SCOUT WAITS | 15 | 15 | 15 | 0.88 | +0 | +0.0 |
| NEXT CHARGE BY LIST | 171 | 171 | 14 | 0.82 | +529 | +37.8 |
| TIED UP BY THE SUM | 16 | 15 | 12 | 0.71 | +606 | +50.5 |
| AFTERMATH IN POINTS | 11 | 11 | 11 | 0.65 | +1135 | +103.2 |
| FIRE IN ORDER | 11 | 11 | 11 | 0.65 | +0 | +0.0 |
| HOLDS AMBUSHERS | 11 | 11 | 11 | 0.65 | +0 | +0.0 |
| SHOOTERS IN TWO RANKS | 11 | 11 | 11 | 0.65 | +27 | +2.5 |
| REDIRECT WEIGHED | 10 | 10 | 10 | 0.59 | +397 | +39.7 |
| SHORT GUN FORWARD | 10 | 10 | 10 | 0.59 | +0 | +0.0 |
| CHARGE NOW FIRST | 43 | 43 | 9 | 0.53 | -1022 | -113.6 |
| HOLDER AT DEPLOYMENT | 15 | 15 | 9 | 0.53 | +674 | +74.8 |
| ONE OBJECTIVE FORMULA | 148 | 124 | 9 | 0.53 | +422 | +46.9 |
| SURE REACH TOGETHER | 17 | 17 | 9 | 0.53 | +62 | +6.9 |
| CASTER AWAY FROM SCREEN | 8 | 8 | 8 | 0.47 | +0 | +0.0 |
| MODEL FACING | 8 | 8 | 8 | 0.47 | +1058 | +132.3 |
| NEARER NOT NEEDED | 195 | 190 | 8 | 0.47 | +207 | +25.9 |
| CAST JOB | 20 | 20 | 7 | 0.41 | +26 | +3.8 |
| FIGHT TO THE END | 41 | 41 | 7 | 0.41 | +159 | +22.7 |
| FRIENDS SHOTS CHECKED | 7 | 7 | 7 | 0.41 | +280 | +40.0 |
| GUN MASK | 29 | 29 | 7 | 0.41 | +282 | +40.3 |
| RANDOM MOVE BY FIGURES | 12 | 12 | 7 | 0.41 | +27 | +3.8 |
| CHAFF IN THE MOVE | 14 | 14 | 6 | 0.35 | +45 | +7.5 |
| FEATURE BUFFS | 35 | 35 | 6 | 0.35 | +195 | +32.5 |
| CASTING BLOCK | 7 | 7 | 5 | 0.29 | +38 | +7.6 |
| CASTS FROM BEHIND | 5 | 5 | 5 | 0.29 | +0 | +0.0 |
| COMBAT PIVOT | 5 | 5 | 5 | 0.29 | +0 | +0.0 |
| HUNT IN PAIRS | 23 | 11 | 4 | 0.24 | +185 | +46.2 |
| MISSILES NEXT TURN | 175 | 132 | 4 | 0.24 | +18 | +4.6 |
| WAR ENGINE CHARGES | 7 | 7 | 4 | 0.24 | +266 | +66.5 |
| BOMBING RUN | 3 | 3 | 3 | 0.18 | +68 | +22.5 |
| CHAFF PASSED | 3 | 3 | 3 | 0.18 | -23 | -7.5 |
| FIRE AND FLEE | 3 | 3 | 3 | 0.18 | +150 | +50.1 |
| HIS MOVE AND SHOT | 70 | 70 | 3 | 0.18 | +17 | +5.8 |
| KEEP FALLS | 3 | 3 | 3 | 0.18 | +96 | +32.0 |
| MOVES UNITS SPELL | 3 | 3 | 3 | 0.18 | +114 | +38.2 |
| ONE FIGHT FORMULA | 158 | 97 | 3 | 0.18 | +70 | +23.5 |
| OVERRUNS AWAY | 9 | 9 | 3 | 0.18 | +59 | +19.8 |
| PIVOT GUARDS FLANK | 3 | 3 | 3 | 0.18 | -34 | -11.5 |
| SPELLS IN THE FIGHT | 17 | 17 | 3 | 0.18 | +84 | +27.9 |
| WHO HITS BACK | 3 | 3 | 3 | 0.18 | +108 | +36.0 |
| WHOLE FIGHT GAIN | 5 | 5 | 3 | 0.18 | +22 | +7.3 |
| WIDER SPREAD | 68 | 67 | 3 | 0.18 | +11 | +3.7 |
| BEST PRIZE | 2 | 2 | 2 | 0.12 | -319 | -159.4 |
| FALLBACK BY WORTH | 16 | 16 | 2 | 0.12 | +22 | +11.2 |
| HONEST WORTH | 88 | 87 | 2 | 0.12 | +3 | +1.6 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.12 | +0 | +0.0 |
| KILLS COUNT | 2 | 2 | 2 | 0.12 | +0 | +0.0 |
| LONG SHOT | 8 | 8 | 2 | 0.12 | +12 | +5.8 |
| NEEDED THERE | 2 | 2 | 2 | 0.12 | +0 | +0.0 |
| OPENS UP | 6 | 6 | 2 | 0.12 | +84 | +42.1 |
| PURSUES BIG PREY | 2 | 2 | 2 | 0.12 | -256 | -128.2 |
| REFUSING RETIRES | 3 | 3 | 2 | 0.12 | -1 | -0.7 |
| SET UP TOGETHER | 11 | 8 | 2 | 0.12 | +19 | +9.7 |
| STUCK PIVOT | 2 | 2 | 2 | 0.12 | +0 | +0.0 |
| SUPPORT NARROWED | 32 | 32 | 2 | 0.12 | -5 | -2.5 |
| CARRIES OUT SET-UP | 1 | 1 | 1 | 0.06 | -24 | -23.5 |
| FALL BACK GOOD ORDER | 69 | 68 | 1 | 0.06 | +4 | +3.5 |
| FOCUS FIRE | 1 | 1 | 1 | 0.06 | +2 | +2.0 |
| HIS CHARGE DENIED | 3 | 3 | 1 | 0.06 | +64 | +64.4 |
| HORN WORTH | 1 | 1 | 1 | 0.06 | +20 | +19.7 |
| MARCH ODDS | 1 | 1 | 1 | 0.06 | -44 | -44.5 |
| MOVE SPELL IN RANGE | 6 | 5 | 1 | 0.06 | +14 | +13.5 |
| NO DOUBLE ROUNDS | 87 | 86 | 1 | 0.06 | +2 | +2.0 |
| RESTRAINS TO SHOOT | 1 | 1 | 1 | 0.06 | +137 | +136.7 |
| STOPS | 1 | 1 | 1 | 0.06 | +2 | +2.5 |
| WAR ENGINE JOBS | 8 | 8 | 1 | 0.06 | -4 | -3.8 |
| ARRIVAL HUNT | 2 | 2 | 0 | 0.00 | - | - |
| BACKUP TARGETS | 3 | 1 | 0 | 0.00 | - | - |
| BLOWS WHERE AIMED | 6 | 6 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 31 | 31 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 21 | trace | - | - | - | - |
| CATCH FLIERS | 2 | not checked | - | - | - | - |
| CHARACTER GUNS | 20 | 20 | 0 | 0.00 | - | - |
| CHARGER SLAIN LOST | 11 | 11 | 0 | 0.00 | - | - |
| CHEAP HELPER | 4 | not checked | - | - | - | - |
| CHEAPEST HOLDER | 3 | 2 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 22 | not checked | - | - | - | - |
| DEFENSIVE ARMY | 1 | 1 | 0 | 0.00 | - | - |
| EDGE GIVE GROUND | 5 | 4 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 158 | not checked | - | - | - | - |
| FRIEND CHARGES FIRST | 3 | 3 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 14 | 14 | 0 | 0.00 | - | - |
| GIVES UP | 12 | 12 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 1 | 1 | 0 | 0.00 | - | - |
| GROUND FLIERS | 2 | not checked | - | - | - | - |
| GUN FIGURES | 41 | not checked | - | - | - | - |
| HE SHOOTS OR CHARGES | 61 | 61 | 0 | 0.00 | - | - |
| HELPER UNSEEN | 1 | 1 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 112 | 112 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 102 | 102 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 29 | 29 | 0 | 0.00 | - | - |
| HOLD ODDS | 107 | 107 | 0 | 0.00 | - | - |
| HUNT RESULT | 1 | trace | - | - | - | - |
| HUNT THE GUNS | 1 | trace | - | - | - | - |
| LONE CHARACTER SAFE SPOT | 4 | not checked | - | - | - | - |
| LOST CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 2 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 5 | trace | - | - | - | - |
| MARCH OVER CASTS | 32 | 32 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 15 | trace | - | - | - | - |
| MOVE SPELL SPOT | 9 | not checked | - | - | - | - |
| NOT TURNED | 5 | 5 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 13 | not checked | - | - | - | - |
| ONE CHARGE A CHARGER | 73 | 73 | 0 | 0.00 | - | - |
| PLAN RESULT | 1425 | trace | - | - | - | - |
| REDIRECT BY WHAT IT STOPS | 5 | 5 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 24 | 24 | 0 | 0.00 | - | - |
| RUN DOWN | 73 | 72 | 0 | 0.00 | - | - |
| SAME CHARGE LATER | 4 | 4 | 0 | 0.00 | - | - |
| SCOUT SPOT | 14 | 14 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 3 | 3 | 0 | 0.00 | - | - |
| SET-UP ANY TARGET | 7 | not checked | - | - | - | - |
| SET-UP MISSED | 3 | trace | - | - | - | - |
| SHOT OR CHARGE | 14 | 14 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 8 | not checked | - | - | - | - |
| SPELL WORTH | 32 | not checked | - | - | - | - |
| STAND AND SHOOT | 21 | 21 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 16 | 16 | 0 | 0.00 | - | - |
| STANDS STILL | 636 | 636 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 137 | not checked | - | - | - | - |
| THE PROMISE ADDS | 4 | 4 | 0 | 0.00 | - | - |
| THE PROMISED MOVE | 15 | not checked | - | - | - | - |
| WAITS AGAIN | 42 | 42 | 0 | 0.00 | - | - |
| WHOLE FIGHT | 5 | 5 | 0 | 0.00 | - | - |

### Off best figure: h4-mine-bbe8617-p2

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| HOLDER ASSIGNMENT | rule | 1.35 | - | 19.2 |
| PATHS CROSS | rule | 0.41 | 0.71 | 26.8 |
| JOB FIRST | gate | 0.18 | 0.65 | 30.3 |
| CHARGE NOT DECLARED | rule | 0.29 | 0.47 | 126.2 |
| CANNON PLANNED TARGET | rule | 0.59 | 0.06 | 102.8 |
| CHARGE NOW FIRST | rule | 0.18 | 0.35 | 113.6 |
| CHAFF PASSED | rule | - | 0.18 | 7.5 |
| PIVOT GUARDS FLANK | rule | 0.12 | 0.06 | 11.5 |
| AFTERMATH BAND | gate | 0.06 | 0.06 | 3.1 |
| BEST PRIZE | rule | - | 0.12 | 159.4 |
| PURSUES BIG PREY | rule | 0.06 | 0.06 | 128.2 |
| TURN GATE | gate | 0.12 | - | 22.3 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.06 | - | 109.3 |
| CARRIES OUT SET-UP | rule | - | 0.06 | 23.5 |
| DEPLOY BY FIGURES | rule | - | 0.06 | 13.2 |
| FALLBACK | gate | 0.06 | - | 4.1 |
| FIGHT ORDER BAND | gate | - | 0.06 | 0.7 |
| LONE CHARACTER SAFE SPOT | gate | 0.06 | - | 2.9 |
| MARCH ODDS | rule | 0.06 | - | 44.5 |
| REDIRECT WEIGHED | rule | - | 0.06 | 17.7 |
| REFUSING RETIRES | rule | 0.06 | - | 1.3 |
| SUPPORT NARROWED | rule | 0.06 | - | 4.9 |
| WAR ENGINE JOBS | rule | - | 0.06 | 3.8 |

### Plans: h4-mine-bbe8617-p2

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 2.0 | 71% | 334 | 228 | 68% |
| Mine | join | 1.5 | 100% | 42 | 0 | 0% |
| Mine | move | 27.5 | 96% | 1582 | 0 | 0% |
| Mine | shoot | 13.0 | 63% | 645 | 902 | 140% |
| Mine | support | 0.1 | 50% | 0 | 0 | - |
| Opponent | charge | 3.3 | 50% | 542 | 205 | 38% |
| Opponent | join | 0.8 | 86% | 32 | 0 | 0% |
| Opponent | move | 29.1 | 94% | 1757 | 0 | 0% |
| Opponent | shoot | 6.3 | 60% | 279 | 334 | 120% |
| Opponent | support | 0.2 | 50% | 0 | 0 | - |

### Packages: hunt the guns, h4-mine-bbe8617-p2

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 70 |
| Opponent | 0.1 | 1 | 0 | 100% | 100% | 0% | 2.0 | 147 | 139 | 100% | 126 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 35 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 135 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 262 |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 151 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Tomb Kings of Khemri | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 36 |
| Vampire Counts | 0.3 | 1 | 0 | 100% | 100% | 0% | 2.0 | 147 | 139 | 100% | 0 |
| Warriors of Chaos | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 668 |
| Wood Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 38 |

### Battle groups: h4-mine-bbe8617-p2

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 2.0 | 41% | 79% | 7% | 0% | 23% | 0% | 31% | 46% | 0% |
| Opponent | REDIRECT COUNTER | 2.5 | 14% | 67% | 17% | 0% | 40% | 0% | 0% | 60% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: h4-mine-bbe8617-p2

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 11 | 0 (11) | 0 | 0 | 48 | 73% | 3.3 | 0 (4) | 0 (4) | 0 (3) | 0 (6) | 0 (5) |
| Mine | Character | 69 | 33 (69) | 31 | 2 | 29 | 32% | 2.3 | 22 (34) | 39 (16) | 59 (13) | 27 (34) | 45 (29) |
| Mine | Clean-up | 14 | 73 (14) | 27 | 47 | 47 | 29% | 3.6 | 109 (5) | 89 (4) | 27 (5) | 139 (7) | 6 (7) |
| Mine | Fast Hammer | 11 | 49 (11) | 3 | 46 | 40 | 45% | 4.3 | 36 (5) | 61 (6) | - | 79 (6) | 0 (5) |
| Mine | Hammer | 39 | 50 (39) | 30 | 19 | 16 | 28% | 2.6 | 76 (9) | 47 (23) | 24 (7) | 44 (22) | 56 (17) |
| Mine | Holder | 9 | 134 (9) | 36 | 98 | 19 | 78% | 5.0 | 200 (3) | 116 (5) | 0 (1) | 220 (3) | 79 (6) |
| Mine | Shooter | 21 | 146 (21) | 71 | 75 | 28 | 0% | 1.6 | 170 (4) | 176 (11) | 53 (6) | 199 (15) | 0 (6) |
| Mine | War machine | 44 | 42 (44) | 42 | 0 | 29 | 5% | 1.6 | 33 (21) | 86 (12) | 0 (11) | 96 (7) | 29 (37) |
| Mine | Wizard | 7 | 0 (7) | 0 | 0 | 0 | 43% | 4.0 | 0 (1) | 0 (3) | 0 (3) | 0 (1) | 0 (6) |
| Opponent | Chaff | 31 | 94 (31) | 18 | 76 | 44 | 45% | 3.1 | 82 (8) | 112 (11) | 85 (12) | 102 (24) | 69 (7) |
| Opponent | Character | 52 | 38 (52) | 38 | 0 | 29 | 42% | 2.7 | 44 (18) | 38 (20) | 37 (11) | 37 (31) | 44 (18) |
| Opponent | Clean-up | 8 | 80 (8) | 0 | 80 | 30 | 50% | 2.8 | 78 (2) | 126 (4) | 0 (2) | 116 (5) | 12 (3) |
| Opponent | Early | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Fast | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Fast Hammer | 25 | 26 (25) | 7 | 19 | 44 | 44% | 3.6 | 68 (9) | 12 (15) | 0 (1) | 26 (16) | 25 (9) |
| Opponent | Hammer | 14 | 39 (14) | 17 | 22 | 25 | 36% | 2.7 | 59 (2) | 30 (8) | 51 (4) | 48 (10) | 20 (4) |
| Opponent | Holder | 13 | 75 (13) | 0 | 75 | 20 | 23% | 2.9 | 12 (2) | 91 (9) | 69 (2) | 132 (5) | 46 (8) |
| Opponent | Shooter | 15 | 93 (15) | 30 | 64 | 42 | 0% | 2.0 | 147 (8) | 59 (5) | 14 (2) | 128 (11) | 27 (4) |
| Opponent | Support | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | War machine | 19 | 47 (19) | 47 | 0 | 41 | 0% | 1.7 | 82 (6) | 39 (11) | 0 (2) | 13 (3) | 54 (16) |
| Opponent | Wizard | 17 | 0 (17) | 0 | 0 | 29 | 18% | 2.9 | 0 (3) | 0 (7) | 0 (2) | 0 (7) | 0 (5) |

### Charged fights: h4-mine-bbe8617-p2

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 131 | 210 | 1.0 | 1.0 | 210 | 13 | +196 | 1 of 4 | 4 of 4 | - | +196 |
| Mine | Chaos Dwarfs | 4 | 78 | 317 | 3.0 | 1.0 | 106 | 27 | +79 | 6 of 12 | 8 of 12 | - | +79 |
| Mine | Dwarfen Mountain Holds | 4 | 332 | 111 | 1.2 | 1.2 | 89 | 21 | +68 | 2 of 5 | 4 of 5 | +347 | -2 |
| Mine | Empire of Man | 4 | 622 | 155 | 1.8 | 1.0 | 89 | 50 | +39 | 3 of 7 | 6 of 7 | - | +39 |
| Mine | Grand Cathay | 1 | 150 | 147 | 4.0 | 1.0 | 37 | 0 | +37 | 1 of 4 | 2 of 4 | - | +37 |
| **Mine** | all armies | 17 | 283 | 195 | 1.9 | 1.0 | 104 | 26 | +78 | 13 of 32 | 24 of 32 | +347 | +69 |
| Opponent | Empire of Man | 3 | 271 | 46 | 1.7 | 1.2 | 27 | 38 | -10 | 2 of 5 | 4 of 5 | -189 | +34 |
| Opponent | Grand Cathay | 3 | 230 | 248 | 2.3 | 1.1 | 106 | 0 | +106 | 3 of 7 | 6 of 7 | +125 | +103 |
| Opponent | High Elf Realms | 1 | 0 | 351 | 5.0 | 1.0 | 70 | 0 | +70 | 4 of 5 | 1 of 5 | - | +70 |
| Opponent | Ogre Kingdoms | 1 | 60 | 105 | 1.0 | 1.0 | 105 | 0 | +105 | 0 of 1 | 0 of 1 | - | +105 |
| Opponent | Orc & Goblin Tribes | 1 | 0 | 240 | 3.0 | 1.0 | 80 | 85 | -5 | 2 of 3 | 3 of 3 | - | -5 |
| Opponent | Tomb Kings of Khemri | 2 | 28 | 408 | 3.5 | 1.0 | 117 | 83 | +34 | 3 of 7 | 4 of 7 | - | +34 |
| Opponent | Vampire Counts | 3 | 0 | 92 | 2.7 | 1.0 | 35 | 6 | +28 | 1 of 8 | 6 of 8 | - | +28 |
| Opponent | Warriors of Chaos | 2 | 0 | 574 | 2.0 | 1.0 | 287 | 0 | +287 | 3 of 4 | 2 of 4 | - | +287 |
| Opponent | Wood Elf Realms | 1 | 120 | 428 | 3.0 | 1.3 | 143 | 0 | +143 | 3 of 3 | 1 of 3 | +300 | +64 |
| **Opponent** | all armies | 17 | 102 | 250 | 2.5 | 1.1 | 99 | 25 | +74 | 21 of 43 | 27 of 43 | +79 | +73 |

### Effective charges: h4-mine-bbe8617-p2

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 0 | 1 (net +8) | 1 (net +0) | 1 (net +0) | 0 | 0 | 1 | 33% (1 of 3) |
| Mine | Chaos Dwarfs | 12 | 0 | 0 | 3 (net +117) | 3 (net +62) | 0 | 5 (net +82) | 1 | 27% (3 of 11) |
| Mine | Dwarfen Mountain Holds | 5 | 1 (net +347) | 0 | 1 (net -105) | 2 (net +0) | 0 | 1 (net +98) | 0 | 20% (1 of 5) |
| Mine | Empire of Man | 7 | 1 (net -348) | 0 | 0 | 2 (net +125) | 2 (net +55) | 2 (net +130) | 0 | 0% (0 of 7) |
| Mine | Grand Cathay | 4 | 2 (net +0) | 0 | 0 | 0 | 0 | 2 (net +74) | 0 | 0% (0 of 4) |
| Opponent | Empire of Man | 5 | 1 (net +0) | 0 | 0 | 0 | 1 (net -189) | 3 (net +46) | 0 | 0% (0 of 5) |
| Opponent | Grand Cathay | 7 | 0 | 0 | 2 (net +63) | 5 (net +123) | 0 | 0 | 0 | 29% (2 of 7) |
| Opponent | High Elf Realms | 5 | 4 (net +64) | 0 | 0 | 0 | 0 | 1 (net +95) | 0 | 0% (0 of 5) |
| Opponent | Ogre Kingdoms | 1 | 1 (net +105) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 1) |
| Opponent | Orc & Goblin Tribes | 3 | 1 (net +240) | 0 | 1 (net +0) | 0 | 0 | 0 | 1 | 50% (1 of 2) |
| Opponent | Tomb Kings of Khemri | 7 | 1 (net -450) | 0 | 1 (net +0) | 0 | 3 (net +166) | 1 (net +189) | 1 | 17% (1 of 6) |
| Opponent | Vampire Counts | 8 | 2 (net -25) | 1 (net +112) | 1 (net +0) | 1 (net +81) | 2 (net +42) | 0 | 1 | 14% (1 of 7) |
| Opponent | Warriors of Chaos | 4 | 2 (net +322) | 0 | 0 | 1 (net +214) | 0 | 0 | 1 | 0% (0 of 3) |
| Opponent | Wood Elf Realms | 3 | 0 | 1 (net +0) | 1 (net +300) | 0 | 0 | 0 | 1 | 50% (1 of 2) |

### Charged fights, damage counted: h4-mine-bbe8617-p2

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 4 | 216 | 283 | -0 | 87 | 113 | -26 | -12.2 |
| Mine | 50-54% | 1 | 52 | 60 | +8 | 60 | 52 | +8 | +15.4 |
| Mine | Effective (55-75%) | 5 | 217 | 347 | +49 | 136 | 67 | +69 | +31.8 |
| Mine | 76-89% | 8 | 182 | 198 | +54 | 56 | 1 | +55 | +30.2 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 10 | 258 | 146 | +92 | 104 | 35 | +69 | +26.8 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 2 | 280 | 55 | +55 | 55 | 0 | +55 | +19.6 |
| Mine | No odds | 2 | 192 | 220 | +389 | 391 | 37 | +354 | +184.5 |
| Mine | All fights | 32 | 218 | 204 | +78 | 108 | 40 | +69 | +31.4 |
| Opponent | Long shot (under 50%) | 12 | 282 | 290 | +62 | 147 | 128 | +19 | +6.7 |
| Opponent | 50-54% | 2 | 77 | 149 | +56 | 102 | 15 | +88 | +113.6 |
| Opponent | Effective (55-75%) | 6 | 294 | 199 | +71 | 106 | 40 | +65 | +22.2 |
| Opponent | 76-89% | 7 | 247 | 128 | +130 | 136 | 45 | +92 | +37.1 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 5 | 264 | 154 | +84 | 99 | 31 | +68 | +25.7 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 6 | 394 | 71 | +65 | 112 | 55 | +57 | +14.5 |
| Opponent | No odds | 5 | 285 | 219 | +32 | 105 | 97 | +7 | +2.6 |
| Opponent | All fights | 43 | 283 | 190 | +74 | 122 | 72 | +50 | +17.7 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| h4-mine-bbe8617-p2 | move | 103 | 30 (29%) | 22 (21%) | 7 (7%) | 66 (64%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0108, L0123 |
| Charmed Shield | Opponent | L0224, L0325, L0427 |
| Clockwork Compass | Opponent | L0812 |
| Elixir of Power | Opponent | L0411, L0919, L1011 |
| Fistful of Laurels | Opponent | L0618 |
| Horn of the Wild Hunt | Opponent | L0633 |
| Invocation of Nehek | Opponent | L0224, L0325, L0427 |
| Ring of Doom | Mine | L0207, L0224 |
| Ring of Doom | Opponent | L0411, L0633, L0812, L1011 |
| Ring of Jet | Mine | L1011 |
| Ring of Jet | Opponent | L0411, L0812, L1011 |
| Standard of the Fell Warrior | Opponent | L0513 |
| Twice-Blessed Armour | Mine | L0722, L1011 |
| Twice-Blessed Armour | Opponent | L0207 |
| Witch Hunter's Ward | Mine | L0722, L0812, L0828 |
| Witch Hunter's Ward | Opponent | L0108, L0207, L0308 |

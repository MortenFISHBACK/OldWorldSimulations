# Doctrine scorecard: h4-mine-bbe8617-p3

### Scorecard: h4-mine-bbe8617-p3

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0111 | 3 | 1 | Mine | no | 9 | 5 | 1 | 1 | 0 | 0 | 0 | 0 |
| L0111 | 3 | 1 | Opponent | no | 1 | 3 | 1 | 0 | 0 | 0 | 0 | 0 |
| L0128 | 2 | 1 | Mine | - | - | - | 0 | 4 | 0 | 0 | 0 | 0 |
| L0128 | 2 | 1 | Opponent | - | - | - | 0 | 4 | 0 | 0 | 0 | 0 |
| L0211 | 1 | 1 | Mine | no | 0 | 3 | 2 | 2 | 1 | 0 | 0 | 255 |
| L0211 | 1 | 1 | Opponent | yes | 13 | 2 | 1 | 0 | 0 | 0 | 0 | 165 |
| L0228 | 6 | 1 | Mine | no | 3 | 2 | 3 | 3 | 1 | 0 | 0 | 170 |
| L0228 | 6 | 1 | Opponent | no | 8 | - | 0 | 0 | 0 | 0 | 0 | 0 |
| L0313 | 1 | 1 | Mine | no | 5 | - | 0 | 1 | 0 | 0 | 0 | 0 |
| L0313 | 1 | 1 | Opponent | no | 3 | 2 | 1 | 0 | 1 | 0 | 0 | 70 |
| L0330 | 6 | 1 | Mine | no | 6 | - | 0 | 1 | 0 | 0 | 0 | 560 |
| L0330 | 6 | 1 | Opponent | no | 10 | 2 | 1 | 1 | 0 | 0 | 0 | 0 |
| L0415 | 1 | 1 | Mine | no | 4 | - | 2 | 0 | 0 | 0 | 0 | 0 |
| L0415 | 1 | 1 | Opponent | no | 12 | 3 | 3 | 0 | 1 | 0 | 0 | 0 |
| L0432 | 6 | 1 | Mine | no | 1 | 2 | 2 | 1 | 0 | 0 | 0 | 449 |
| L0432 | 6 | 1 | Opponent | no | 3 | 2 | 2 | 4 | 1 | 0 | 0 | 340 |
| L0518 | 2 | 1 | Mine | - | - | 5 | 1 | 1 | 0 | 0 | 0 | 233 |
| L0518 | 2 | 1 | Opponent | - | - | 3 | 1 | 2 | 0 | 0 | 0 | 0 |
| L0534 | 6 | 1 | Mine | no | 8 | - | 0 | 2 | 0 | 0 | 0 | 567 |
| L0534 | 6 | 1 | Opponent | no | 2 | 4 | 1 | 6 | 0 | 0 | 0 | 0 |
| L0621 | 3 | 1 | Mine | no | 0 | - | 4 | 1 | 0 | 0 | 0 | 246 |
| L0621 | 3 | 1 | Opponent | no | 4 | - | 1 | 4 | 1 | 0 | 0 | 500 |
| L0710 | 2 | 1 | Mine | - | - | 4 | 1 | 2 | 0 | 0 | 0 | 0 |
| L0710 | 2 | 1 | Opponent | - | - | 3 | 4 | 0 | 0 | 0 | 0 | 369 |
| L0726 | 6 | 1 | Mine | no | 4 | 2 | 3 | 0 | 0 | 0 | 0 | 170 |
| L0726 | 6 | 1 | Opponent | no | 0 | 2 | 7 | 2 | 1 | 0 | 0 | 0 |
| **Average** | | | Mine | 0% | 4.0 | 3.3 | 1.5 | 1.5 | 0.2 | 0.0 | 0.0 | 203.8 |
| **Average** | | | Opponent | 10% | 5.6 | 2.6 | 1.8 | 1.8 | 0.4 | 0.0 | 0.0 | 111.1 |

### KPIs: h4-mine-bbe8617-p3

Rules off - Opponent only: HOLDER ASSIGNMENT, QUARTER ODDS.

Morten 2026-11-10; 13 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 38% (24 of 63) | 7% (4 of 60) | 23% (28 of 123) |
| Winner chose to follow up after the loser gave ground |  | 100% (6 of 6); on the table 100% | 94% (15 of 16); on the table 94% | 95% (21 of 22); on the table 95% |
| Winner chose to pursue after the loser fell back in good order |  | - | 0% (0 of 1); on the table 100% | 0% (0 of 1); on the table 100% |
| Winner chose to pursue after the loser fled |  | 78% (7 of 9); on the table 89% | 60% (3 of 5); on the table 60% | 71% (10 of 14); on the table 79% |
| Winner chose to follow up or pursue (all three) |  | 87% (13 of 15); on the table 93% | 82% (18 of 22); on the table 86% | 84% (31 of 37); on the table 89% |
| Magic missiles tried each own turn | 50%+ | 37% (51 of 138) | 28% (29 of 102) | 33% (80 of 240) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 46% (51 of 110) | 40% (29 of 72) | 44% (80 of 182) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 44% (4 of 9) | 27% (3 of 11) | 35% (7 of 20) |
| Points that never fought | lower | 60% (15440 of 25562) | 48% (12499 of 25993) | 54% (27939 of 51555) |
|   infantry points that never fought | lower | 67% (4534 of 6788) | 63% (2456 of 3879) | 66% (6990 of 10667) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 62% (61 of 98) | 51% (50 of 98) | 57% (111 of 196) |
| Bound items with a magic missile used (at least once a game) |  | 83% (5 of 6); 1.2 uses a game | 100% (11 of 11); 2.5 uses a game | 94% (16 of 17); 1.8 uses a game |
| Bound items with another spell used |  | 100% (4 of 4); 0.8 uses a game | 33% (1 of 3); 0.1 uses a game | 71% (5 of 7); 0.4 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 80% (8 of 10); 0.6 uses a game | 33% (2 of 6); 0.2 uses a game | 62% (10 of 16); 0.4 uses a game |
|   their share of the points of units over 100 pts | lower | 62% (12344 of 19862) | 46% (10964 of 23683) | 54% (23308 of 43545) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 2.2 (33%) | 0.8 (15%) | 3.1 (25%) |
| MARCHED: its unit marched | 1.6 (24%) | 1.8 (32%) | 3.4 (28%) |
| CHARGED: its unit charged | 0.4 (6%) | 0.3 (5%) | 0.7 (6%) |
| IN COMBAT: engaged in combat | 0.2 (2%) | 1.2 (22%) | 1.4 (11%) |
| REAR RANK: in a rear rank | 0.3 (5%) | 0.2 (4%) | 0.5 (4%) |
| GONE: slain | 2.0 (30%) | 1.1 (19%) | 3.1 (25%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.1 (1%) | 0.1 (1%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.1 (1%) | 0.1 (1%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 3.7 | 2.2 | 1.8 | 6.2 | 0.2 | 1.3 |
| not cast | 2.8 | 4.5 | 2.8 | 12.3 | 2.2 | 21.8 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.3 (6%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.8 (40%) | 0.2 (6%) | 3.1 (25%) | 0.3 (14%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 3.4 (28%) | 0.5 (21%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (6%) | 0.2 (7%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.2 (3%) | 0.1 (3%) | 1.4 (11%) | 0.3 (14%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.6 (14%) | 0.0 (0%) | 0.5 (4%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | 0.4 (14%) | 1.0 (22%) | 1.2 (44%) | 3.1 (25%) | 0.8 (36%) | 4.2 (19%) |
| STUPIDITY: Stupidity | 0.1 (3%) | 0.1 (2%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.2 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.5 (12%) | 0.0 (0%) | 0.0 (0%) | 0.2 (7%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.3 (83%) | 0.3 (7%) | 1.3 (47%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 16.1 (74%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.8 a game | 0.4 a game | 1.1 a game |
| stood (cast and not dispelled) | 46% (11 of 24) | 0% (0 of 1) | 44% (11 of 25) |
| the unit moved after it | 45% (5 of 11) | - | 45% (5 of 11) |
| it charged on its next turn | 0% (0 of 11) | - | 0% (0 of 11) |
| the enemy charged it first | 9% (1 of 11) | - | 9% (1 of 11) |
| it fought by the end of its next turn | 9% (1 of 11) | - | 9% (1 of 11) |
| it moved out of a charge the enemy had planned (not charged first) | 18% (2 of 11) | - | 18% (2 of 11) |
| none of these (no charge, no fight, no charge escaped) | 73% (8 of 11) | - | 73% (8 of 11) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 69% (245 of 353) | 52% (106 of 205) | 63% (351 of 558) |
|   cavalry | 63% (12 of 19) | 38% (6 of 16) | 51% (18 of 35) |
|   character | 91% (41 of 45) | 32% (13 of 41) | 63% (54 of 86) |
|   chariot | 42% (17 of 40) | 68% (21 of 31) | 54% (38 of 71) |
|   infantry | 58% (46 of 79) | 52% (31 of 60) | 55% (77 of 139) |
|   monster | 83% (5 of 6) | 75% (9 of 12) | 78% (14 of 18) |
|   war machine | 76% (124 of 164) | 58% (26 of 45) | 72% (150 of 209) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.5 (19%) | 2.4 (31%) | 3.9 (25%) |
| CHARGED: it charged | 0.3 (4%) | 1.2 (16%) | 1.5 (10%) |
| FLEEING: it fled or was fleeing | 0.0 (0%) | 0.2 (3%) | 0.2 (1%) |
| IN COMBAT: it fought this turn or the last | 0.7 (8%) | 0.2 (2%) | 0.8 (5%) |
| MOVED: a war machine that moved | 1.8 (21%) | 1.2 (16%) | 3.0 (19%) |
| NO TARGET IN RANGE | 1.8 (22%) | 1.2 (15%) | 3.0 (19%) |
| ONLY IN COMBAT: the only targets were in combat | 0.3 (4%) | 0.0 (0%) | 0.3 (2%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.3 (16%) | 0.5 (6%) | 1.8 (11%) |
| SHELTERED: the target was sheltered | 0.1 (1%) | 0.5 (6%) | 0.5 (3%) |
| OTHER BAR | 0.5 (6%) | 0.3 (4%) | 0.8 (5%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 1.8 | 0.6 | 75% | 6.7 pts | 12 pts |
| character | 4.5 | 1.3 | 81% | 5.4 pts | 24 pts |
| chariot | 2.9 | 2.2 | 50% | 17.6 pts | 51 pts |
| infantry | 9.4 | 3.4 | 75% | 8.9 pts | 84 pts |
| monster | 1.1 | 0.3 | 86% | 1.7 pts | 2 pts |
| war machine | 11.5 | 11.8 | 53% | 30.2 pts | 348 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 2.2 | 3.5 | 2.8 |
| Charges that made contact a game | 1.7 | 2.8 | 2.3 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.33 declared, 0.33 contact (6 units) | 1.40 declared, 1.10 contact (10 units) | 1.00 declared, 0.81 contact (16 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.00 declared, 0.00 contact (2 units) | 1.33 declared, 1.00 contact (3 units) | 0.80 declared, 0.60 contact (5 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.30 declared, 0.23 contact (87 units) | 0.31 declared, 0.26 contact (89 units) | 0.31 declared, 0.24 contact (176 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 33% (7 of 21) | 0% (0 of 2) | 43% (3 of 7) | 33% (10 of 30) |
| Character in a unit | 85% (17 of 20) | 87% (13 of 15) | 100% (2 of 2) | 86% (32 of 37) |
| Character on its own | 75% (6 of 8) | 45% (5 of 11) | 39% (7 of 18) | 49% (18 of 37) |
| Chariot | 88% (7 of 8) | 75% (6 of 8) | - | 81% (13 of 16) |
| Infantry | 38% (8 of 21) | 27% (4 of 15) | 0% (0 of 1) | 32% (12 of 37) |
| Monster | 67% (4 of 6) | 67% (2 of 3) | - | 67% (6 of 9) |
| Monstrous | 100% (3 of 3) | 67% (2 of 3) | - | 83% (5 of 6) |
| War Machines | 64% (14 of 22) | 50% (1 of 2) | - | 62% (15 of 24) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 67% (2 of 3); on the table 67% | 33% (34 of 102) | 64% | 73% (16 of 22) | 83% (5 of 6); 3.8 uses a game | 100% (2 of 2); 1.2 uses a game | 83% (5 of 6); 1.2 uses a game |
| Chaos Dwarfs | 4 | 100% (4 of 4); on the table 100% | 47% (17 of 36) | 54% | 59% (19 of 32) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
| Dwarfen Mountain Holds | 3 | 67% (2 of 3); on the table 100% | - | 78% | 54% (13 of 24) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 2 | 100% (5 of 5); on the table 100% | - | 40% | 65% (13 of 20) | 0.0 uses a game | 100% (2 of 2); 2.5 uses a game | 100% (2 of 2); 1.0 uses a game |
| Grand Cathay | 3 | 67% (2 of 3); on the table 67% | 29% (19 of 66) | 42% | 46% (12 of 26) | 100% (6 of 6); 5.0 uses a game | 100% (1 of 1); 0.3 uses a game | 0% (0 of 3); 0.0 uses a game |
| High Elf Realms | 2 | 100% (6 of 6); on the table 100% | 0% (0 of 6) | 52% | 47% (7 of 15) | 100% (3 of 3); 8.0 uses a game | 0% (0 of 2); 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 1 | 100% (1 of 1); on the table 100% | 0% (0 of 6) | 55% | 43% (3 of 7) | 100% (1 of 1); 1.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Skaven | 1 | 50% (1 of 2); on the table 100% | 67% (4 of 6) | 54% | 67% (6 of 9) | 100% (1 of 1); 1.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Vampire Counts | 1 | 0% (0 of 1); on the table 0% | 0% (0 of 6) | 40% | 40% (2 of 5) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 4 | 89% (8 of 9); on the table 89% | 50% (6 of 12) | 51% | 61% (17 of 28) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 0.2 uses a game |
| Wood Elf Realms | 1 | - | - | 45% | 38% (3 of 8) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (h4-mine-bbe8617-p3, 13 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 52% (14) | 47% (8) | 50% (22) |
| ...free all their last turn and able to turn (per game) | 0.62 | 0.54 | 1.15 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.23 | 0.00 | 0.23 |
| ...with the charger already in that arc before they moved (per game) | 0.54 | 0.23 | 0.77 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.08 | 0.15 | 0.23 |

### Quality by phase: h4-mine-bbe8617-p3

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.8 | 2.5 |
| Strategy | Charge objectives carried out (made contact) | 77% (20 of 26) | 60% (26 of 43) |
| Strategy | Shoot objectives carried out (shot that target) | 44% (90 of 206) | 49% (32 of 65) |
| Strategy | Support requests answered (helper made contact too) | 0% (0 of 1) | 33% (1 of 3) |
| Strategy | Hexes on a unit its side charged or shot that turn | 0% (0 of 1) | 11% (1 of 9) |
| Strategy | Joined characters whose unit fought | 22% (7 of 32) | 53% (9 of 17) |
| Strategy | Lone characters that fought | 37% (10 of 27) | 77% (17 of 22) |
| Movement | Charges halted short of contact | 0.0 | 0.1 |
| Movement | Idle units | 1.5 | 1.8 |
| Movement | Points that never moved of their own | 203.8 | 111.1 |
| Movement | Fights charged into per game | 1.6 | 2.6 |
| Movement | Charges with odds: long shots (under 50%) | 5 of 21, net -53 | 5 of 32, net +65 |
| Movement | Charges with odds: sweet spot (55-75%) | 4 of 21, net +23 | 3 of 32, net +69 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 1 of 21, net +63 | 9 of 32, net +115 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 0 of 21 | 6 of 32, net +114 |
| Shooting | Shots by shooting units (incl. breath weapons) | 9.5 | 7.1 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 36% (45 of 124) | 35% (32 of 92) |
| Shooting | Points destroyed by shooting units | 108.5 | 0.0 |
| Shooting | War machine shots | 9.5 | 2.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 46% (57 of 124) | 69% (18 of 26) |
| Shooting | Points destroyed by war machines | 150.4 | 45.0 |
| Magic | Magic missiles cast | 1.6 | 1.7 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 48% (10 of 21) | 27% (6 of 22) |
| Magic | Wounds caused by magic missiles | 5.2 | 2.8 |
| Magic | Wounds caused by other spells | 0.8 | 1.5 |
| Magic | Points destroyed by magic (all spells) | 29.7 | 33.1 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.4 / 0.1 / 0.3 / 0.2 | 1.2 / 1.0 / 0.4 / 0.0 |
| Combat | Points destroyed in combat | 64.7 | 377.3 |
| Combat | Points run down | 53.0 | 26.5 |
| Combat | Net points per charged fight, damage counted | +36 | +87 |
| Combat | Net per 100 charger points, damage counted | +22.7 | +21.9 |
| Combat | First round won (charged fights) | 71% | 82% |
| Combat | Net points per charged fight | +31 | +112 |
| Combat | Net points per supported fight / lone fight | -274 / +46 | -12 / +124 |
| Combat | Charged fights on a top-3 enemy unit | 6 of 21 | 15 of 34 |
| Game | Points lost | 604.0 | 441.7 |
| Game | VP from objectives | 647.7 | 738.5 |
| Game | Lone holders (player turns) | 4.0 | 5.6 |

- Mine won / drew / lost: 2 / 5 / 6 of 13 ended games (of 13); mean margin (Mine - Opponent) -252 VP
- The side that went first won 2 of 8 games with a winner
- Points traded per game (both sides' losses): 1046
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: h4-mine-bbe8617-p3

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.5 | +0.0 | 0.0 | 0.0 | 0.5 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | - | - | - | - | 0.2 | +18.9 | 0.0 | 0.0 |
| ALREADY CARRIED | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARRIVAL HUNT | - | - | - | - | 0.1 | +1.3 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 2.3 | +0.0 | 0.0 | 50.8 | 0.6 | +0.0 | 0.0 | 12.7 |
| BACKUP TARGETS | 0.1 | +0.3 | 0.0 | 0.0 | 0.3 | +0.5 | 0.0 | 0.0 |
| BEST PRIZE | - | - | - | - | 0.3 | -6.0 | 15.9 | 0.0 |
| BLOWS WHERE AIMED | 0.3 | -8.9 | 0.0 | 4.0 | 0.1 | -0.7 | 0.0 | 17.5 |
| BOMBING RUN | 0.1 | +3.8 | 0.0 | 0.0 | 0.2 | +2.9 | 0.0 | 0.0 |
| CANNON PLAN MISSED | 1.0 | +0.0 | 78.5 | 9.6 | 0.3 | +0.0 | 21.5 | 25.4 |
| CANNON PLANNED TARGET | 9.2 | +264.6 | 591.5 | 115.8 | 1.6 | +31.6 | 69.2 | 12.7 |
| CANNON SIGHT KEPT | 1.5 | +0.0 | 0.0 | 0.0 | 0.5 | +0.0 | 0.0 | 34.0 |
| CARRIES OUT COUNTER | - | - | - | - | 0.1 | -12.6 | 0.0 | 0.0 |
| CARRIES OUT SET-UP | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CAST JOB | 0.7 | +10.8 | 50.5 | 6.5 | 0.2 | +5.7 | 0.0 | 0.0 |
| CASTER AWAY FROM SCREEN | 0.3 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.4 | +16.8 | 3.2 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 0.8 | +0.0 | 0.0 | 29.2 | 0.2 | +0.0 | 0.0 | 30.4 |
| CHAFF IN THE MOVE | 0.5 | +13.9 | 0.0 | 19.2 | 0.6 | +34.0 | 0.0 | 4.2 |
| CHAFF PASSED | 0.2 | -2.4 | 0.0 | 0.0 | 0.4 | -0.1 | 0.0 | 0.0 |
| CHARACTER GUNS | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CHARGE LOSSES | 5.6 | -388.4 | 0.0 | 112.8 | 5.5 | -300.1 | 0.0 | 115.2 |
| CHARGE NOT DECLARED | 0.2 | +0.0 | 17.5 | 0.0 | 0.8 | +0.0 | 112.9 | 0.0 |
| CHARGE NOW FIRST | 0.8 | +0.0 | 64.9 | 0.0 | 1.5 | +0.0 | 185.8 | 49.0 |
| CHARGER SLAIN LOST | 0.3 | -3.5 | 0.0 | 0.0 | - | - | - | - |
| CHEAP HELPER | 0.1 | +0.0 | 7.1 | 0.0 | - | - | - | - |
| CHEAPEST HOLDER | - | - | - | - | 0.2 | -7.7 | 14.3 | 8.6 |
| COMBAT PIVOT | 0.2 | +0.0 | 0.0 | 71.5 | 0.2 | +0.0 | 19.0 | 0.0 |
| CONVEYANCE SEARCH | 1.5 | +279.5 | 87.7 | 115.0 | 0.1 | +2.9 | 0.0 | 0.0 |
| COVER ONCE | 5.4 | -352.8 | 0.0 | 100.7 | 4.1 | -215.0 | 0.0 | 72.8 |
| DEPLOY BY FIGURES | 8.3 | +50.6 | 0.0 | 16.5 | 7.3 | +32.3 | 0.0 | 11.2 |
| EDGE GIVE GROUND | 0.1 | +0.9 | 12.7 | 0.0 | 0.1 | +13.6 | 23.8 | 0.0 |
| ENGINEER BY LORE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FALL BACK GOOD ORDER | 1.2 | +0.7 | 52.0 | 4.0 | 2.6 | +3.9 | 272.8 | 53.6 |
| FALLBACK BY WORTH | 0.2 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| FALLS SHORT | 4.6 | +100.5 | 0.0 | 83.5 | 18.0 | +319.4 | 0.0 | 197.1 |
| FEATURE BUFFS | 1.5 | +52.1 | 0.0 | 6.3 | 0.5 | +13.0 | 0.0 | 0.0 |
| FIGHT TO THE END | 0.6 | +16.7 | 49.2 | 0.0 | 1.1 | +99.6 | 159.2 | 53.6 |
| FIRE IN ORDER | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| FIVE ACTION | 47.5 | +2310.0 | 928.5 | 688.7 | 40.5 | +3240.9 | 491.4 | 604.3 |
| FLANK NOT WEIGHED | 3.9 | +0.0 | 0.0 | 122.0 | 5.3 | +0.0 | 0.0 | 29.2 |
| FOLLOW UP WEIGHED | 0.3 | +74.3 | 0.0 | 0.0 | 0.8 | +261.5 | 0.0 | 0.0 |
| FOUR ROUNDS | 2.0 | +129.2 | 107.3 | 14.5 | 3.2 | +375.0 | 337.5 | 53.6 |
| FRIEND CHARGES FIRST | 0.2 | -4.6 | 0.0 | 4.0 | - | - | - | - |
| FRIEND SHOOTS FIRST | 0.8 | -14.9 | 0.0 | 0.0 | 0.5 | -18.0 | 0.0 | 34.0 |
| FRIENDS SHOTS CHECKED | 0.2 | +5.0 | 0.0 | 0.0 | - | - | - | - |
| GIVES UP | 0.1 | -0.2 | 12.7 | 0.0 | 0.2 | -3.3 | 24.4 | 0.0 |
| GUN FIGURES | 0.8 | +12.1 | 46.1 | 8.8 | 0.1 | +4.2 | 5.0 | 14.2 |
| GUN MASK | 0.5 | +6.9 | 0.0 | 8.5 | 0.9 | +13.1 | 0.0 | 14.2 |
| HARD STAY DROPPED | 2.2 | +0.0 | 0.0 | 84.9 | 0.5 | +0.0 | 0.0 | 0.0 |
| HE SHOOTS OR CHARGES | 2.5 | +0.0 | 0.0 | 68.8 | 1.8 | +0.0 | 0.0 | 44.2 |
| HIS CHARGE DENIED | 0.2 | +6.6 | 8.6 | 0.0 | 0.2 | +4.3 | 8.5 | 0.0 |
| HIS CHARGE LIST | 1.9 | +0.0 | 0.0 | 5.9 | 2.2 | +0.0 | 0.0 | 21.7 |
| HIS LEGAL MOVES | 2.8 | +0.0 | 0.0 | 43.6 | 3.7 | +0.0 | 0.0 | 30.8 |
| HIS MOVE AND SHOT | 2.1 | -25.9 | 0.0 | 8.6 | 1.6 | -34.6 | 0.0 | 24.8 |
| HIS RANDOM MOVE | 1.9 | +0.0 | 0.0 | 14.3 | 1.4 | +0.0 | 0.0 | 28.9 |
| HIS SHOT LIST | 18.0 | +684.0 | 0.0 | 219.4 | 21.5 | +1341.0 | 0.0 | 368.4 |
| HIS TURN DENIED | 0.5 | +16.1 | 36.7 | 0.0 | 1.5 | +59.5 | 176.9 | 30.8 |
| HOLD ODDS | 6.6 | +0.0 | 0.0 | 66.5 | - | - | - | - |
| HOLDER ASSIGNMENT | 13.8 | +1417.2 | 0.0 | 141.8 | - | - | - | - |
| HOLDER AT DEPLOYMENT | - | - | - | - | 1.5 | +222.0 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 1.5 | -32.0 | 107.3 | 0.0 | 3.1 | -152.2 | 333.7 | 53.6 |
| IDLE COST | 3.4 | -30.8 | 0.0 | 58.5 | 10.2 | -161.3 | 0.0 | 179.3 |
| JOINT KNOWS CHALLENGE | - | - | - | - | 0.2 | -5.3 | 36.8 | 0.0 |
| KEEP FALLS | 0.3 | +3.7 | 0.0 | 0.0 | 0.1 | +0.8 | 0.0 | 0.0 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KILLS COUNT | - | - | - | - | 0.1 | +4.4 | 14.5 | 0.0 |
| LANE BY FIGURES | 0.4 | +15.6 | 0.0 | 0.0 | 0.8 | +33.4 | 0.0 | 62.4 |
| LEGAL CHARGES ONLY | 5.6 | +0.0 | 96.0 | 280.3 | 2.3 | +0.0 | 195.2 | 41.3 |
| LONE WIZARD KEPT IN | 0.8 | +65.1 | 0.0 | 7.3 | 0.2 | +29.9 | 0.0 | 0.0 |
| LONG SHOT | 0.1 | +0.2 | 0.0 | 0.0 | 0.2 | -1.5 | 14.3 | 26.2 |
| LOST CHARGE | 0.1 | -0.1 | 4.6 | 0.0 | - | - | - | - |
| LURE BY WHAT IT DRAWS | 0.1 | -1.8 | 0.0 | 0.0 | - | - | - | - |
| MAKE SURE TOGETHER | 0.3 | +8.6 | 0.0 | 0.0 | 0.2 | +0.4 | 0.0 | 22.8 |
| MANOEUVRE | 1.8 | +8.5 | 0.0 | 0.0 | 0.9 | +24.3 | 0.0 | 10.4 |
| MARCH AT ESCAPER | 0.2 | +1.3 | 0.0 | 0.0 | - | - | - | - |
| MARCH BY THE SUM | 0.1 | +14.9 | 0.0 | 0.0 | 0.8 | +21.0 | 0.0 | 0.0 |
| MARCH CHECK | 0.8 | +25.3 | 0.0 | 0.0 | 2.2 | +135.1 | 0.0 | 0.0 |
| MARCH OVER CASTS | 0.5 | +140.7 | 0.0 | 0.0 | 1.5 | +91.1 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 4.2 | +74.0 | 0.0 | 29.7 | 5.8 | +71.1 | 0.0 | 86.7 |
| MISSILES IN THE MOVE | 4.3 | +166.0 | 0.0 | 6.5 | 4.5 | +58.4 | 0.0 | 30.4 |
| MISSILES NEXT TURN | 4.5 | +132.8 | 0.0 | 6.5 | 6.3 | +57.9 | 0.0 | 91.9 |
| MODEL FACING | 0.6 | +155.9 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL IN RANGE | 0.2 | +3.9 | 0.0 | 58.5 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.8 | -56.6 | 0.0 | 171.5 | - | - | - | - |
| MOVE SPELL SPOT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 3.2 | +308.2 | 0.0 | 47.8 | 3.2 | +648.6 | 0.0 | 88.1 |
| MOVES UNITS SPELL | 0.2 | +8.5 | 0.0 | 0.0 | 0.1 | +0.6 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 6.9 | +309.8 | 0.0 | 94.8 | 3.5 | +215.4 | 0.0 | 11.3 |
| NEEDED THERE | - | - | - | - | 0.1 | +45.1 | 14.5 | 0.0 |
| NEXT CHARGE BY LIST | 5.1 | -148.6 | 4.8 | 77.0 | 4.7 | -156.2 | 0.0 | 135.5 |
| NEXT OBJECTIVE NEARER | - | - | - | - | 7.7 | -387.6 | 11.5 | 47.3 |
| NO DOUBLE ROUNDS | 1.2 | -28.3 | 35.6 | 6.5 | 2.7 | -138.3 | 263.0 | 53.6 |
| NOT TURNED | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 0.2 | -0.3 | 0.0 | 54.6 | 0.3 | -0.3 | 0.0 | 30.4 |
| OFF BEST | 0.2 | -4.3 | 0.0 | 4.2 | 0.4 | -2.2 | 0.0 | 4.2 |
| ONE CHARGE A CHARGER | 2.4 | +0.0 | 0.0 | 105.8 | 1.5 | +0.0 | 0.0 | 31.0 |
| ONE FIGHT FORMULA | 4.4 | -80.1 | 0.0 | 73.0 | 4.5 | -160.4 | 0.0 | 118.5 |
| ONE OBJECTIVE FORMULA | 5.5 | -26.9 | 0.0 | 96.1 | 4.0 | -48.8 | 0.0 | 39.9 |
| ONE TARGET A SHOOTER | 15.2 | +287.4 | 0.0 | 162.8 | 18.1 | +642.7 | 0.0 | 272.0 |
| OPENS A LANE | - | - | - | - | 0.1 | +0.1 | 0.0 | 0.0 |
| OPENS UP | 0.1 | +6.0 | 4.8 | 0.0 | 0.2 | +8.6 | 19.4 | 0.0 |
| OVERRUNS AWAY | 0.4 | +8.0 | 37.2 | 0.0 | 0.4 | +9.3 | 61.3 | 13.2 |
| PATHS CROSS | 3.2 | +264.2 | 0.0 | 19.5 | 4.2 | +194.9 | 0.0 | 65.4 |
| PERIAPT WORTH | - | - | - | - | 0.1 | +7.6 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | - | - | - | - | 0.1 | -0.5 | 0.0 | 0.0 |
| PLAN RESULT | 41.8 | +986.1 | 338.5 | 863.2 | 36.0 | +469.8 | 263.7 | 587.5 |
| QUARTER ODDS | 1.8 | +267.7 | 37.5 | 23.8 | - | - | - | - |
| RANDOM MOVE BY FIGURES | 0.7 | +16.8 | 0.0 | 26.2 | 0.8 | +2.6 | 0.0 | 91.9 |
| REDIRECT BY WHAT IT STOPS | 0.4 | -7.1 | 0.0 | 6.5 | 0.5 | -13.5 | 0.0 | 0.0 |
| REDIRECT COUNTER | 1.7 | +119.2 | 0.0 | 17.1 | 2.8 | +105.2 | 0.0 | 45.5 |
| REDIRECT WEIGHED | - | - | - | - | 0.3 | -1.0 | 12.5 | 0.0 |
| REFORMS TO MEET IT | 0.9 | -22.9 | 0.0 | 0.0 | 0.7 | -25.1 | 0.0 | 0.0 |
| REFUSING RETIRES | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | 0.2 | +8.3 | 0.0 | 0.0 | 0.3 | +21.9 | 0.0 | 0.0 |
| RESTRAINS TO SHOOT | - | - | - | - | 0.1 | +0.6 | 0.0 | 0.0 |
| RISK BY ARC | 1.7 | +52.0 | 87.2 | 14.5 | 1.9 | -9.3 | 232.2 | 49.0 |
| RISK BY HIS FIGURE | 10.5 | -319.7 | 0.0 | 243.9 | 10.9 | -204.4 | 0.0 | 160.8 |
| RUN DOWN | 1.0 | -5.2 | 60.4 | 0.0 | 2.3 | -17.9 | 207.2 | 36.1 |
| SAME CHARGE LATER | 0.1 | -1.1 | 0.0 | 0.0 | 0.1 | -0.8 | 0.0 | 0.0 |
| SCOUT SPOT | 0.5 | +1.8 | 0.0 | 0.0 | 0.2 | -0.0 | 0.0 | 0.0 |
| SCOUT WAITS | 0.5 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.2 | -12.7 | 0.0 | 4.2 | 0.5 | -36.4 | 0.0 | 4.2 |
| SEARCH SPOT | 5.4 | +289.5 | 0.0 | 44.3 | 6.6 | +260.3 | 0.0 | 86.2 |
| SELF MOVE SPELL | - | - | - | - | 0.5 | +37.7 | 0.0 | 60.8 |
| SET UP TOGETHER | 0.7 | +10.0 | 0.0 | 0.0 | 0.4 | +10.0 | 0.0 | 31.1 |
| SET-UP ANY TARGET | 0.2 | +25.1 | 58.5 | 58.5 | - | - | - | - |
| SET-UP MISSED | 0.1 | +34.7 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | 0.5 | +0.9 | 0.0 | 0.0 | 0.2 | +0.2 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.6 | +81.7 | 35.0 | 23.8 | 0.8 | +19.1 | 29.2 | 30.4 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SHOT OR CHARGE | 0.1 | -0.1 | 4.8 | 0.0 | 0.2 | -9.4 | 20.4 | 12.7 |
| SHOT RISK POINTS | 9.3 | +106.9 | 0.0 | 143.9 | 12.0 | -125.8 | 0.0 | 279.8 |
| SHOTS IN THE MOVE | 18.0 | +926.3 | 0.0 | 320.3 | 10.2 | +281.8 | 0.0 | 171.5 |
| SPELL SETS UP CHARGE | 0.4 | +125.0 | 58.5 | 58.5 | - | - | - | - |
| SPELL WORTH | - | - | - | - | 1.8 | +31.3 | 61.5 | 61.5 |
| SPELLS IN THE FIGHT | 0.5 | +12.9 | 42.3 | 0.0 | 0.5 | -0.7 | 56.7 | 0.0 |
| STAND AND SHOOT | 0.4 | -2.2 | 11.3 | 0.0 | 0.5 | -11.4 | 112.8 | 13.2 |
| STANDS FOR A REASON | - | - | - | - | 0.8 | +0.0 | 0.0 | 30.8 |
| STANDS STILL | 23.0 | +0.0 | 821.2 | 360.2 | 7.9 | +0.0 | 153.8 | 165.5 |
| STAY WORTH | 24.9 | +110.9 | 571.3 | 251.2 | 11.8 | +87.6 | 95.4 | 220.8 |
| SUPPORT NARROWED | 0.4 | +0.0 | 36.3 | 0.0 | 0.6 | +0.0 | 66.1 | 8.6 |
| SURE REACH TOGETHER | 0.2 | +2.4 | 0.0 | 0.0 | 1.1 | +39.1 | 0.0 | 31.1 |
| THE DEARER SUM KEEPS ITS PLAN | 4.1 | +0.0 | 0.0 | 48.8 | 4.5 | +0.0 | 0.0 | 79.6 |
| THE PROMISE ADDS | - | - | - | - | 0.1 | -3.5 | 18.4 | 0.0 |
| THE PROMISED MOVE | 0.8 | +0.0 | 0.0 | 8.5 | 0.2 | +0.0 | 0.0 | 0.0 |
| TIED UP BY THE SUM | 0.1 | +6.8 | 4.8 | 0.0 | 0.8 | +117.8 | 64.1 | 0.0 |
| TIME ON OUR SIDE | 28.2 | +456.9 | 2.6 | 349.5 | 6.2 | +114.7 | 0.0 | 22.6 |
| WAITS AGAIN | 1.1 | +0.0 | 0.0 | 0.0 | 0.9 | +0.0 | 0.0 | 4.8 |
| WAR ENGINE JOBS | 0.3 | +0.0 | 34.2 | 0.0 | 0.2 | +0.0 | 4.2 | 0.0 |
| WHO HITS BACK | 0.4 | +38.9 | 0.0 | 14.3 | 0.2 | +7.5 | 0.0 | 0.0 |
| WHOLE FIGHT | 0.3 | +14.4 | 39.2 | 0.0 | 0.1 | -22.2 | 0.0 | 0.0 |
| WHOLE FIGHT GAIN | - | - | - | - | 0.2 | +22.1 | 8.5 | 17.5 |
| WIDER SPREAD | 1.8 | +1.8 | 107.3 | 4.0 | 2.3 | -5.4 | 298.9 | 45.0 |
| WOUNDS ON THE RANKS | 1.5 | +44.5 | 0.0 | 0.0 | 1.8 | +108.8 | 0.0 | 0.0 |

### Rule changes: h4-mine-bbe8617-p3

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HOLDER ASSIGNMENT | 180 | 180 | 168 | 12.92 | +10686 | +63.6 |
| HIS SHOT LIST | 514 | 514 | 158 | 12.15 | +4008 | +25.4 |
| SEARCH SPOT | 156 | 156 | 145 | 11.15 | +7195 | +49.6 |
| DEPLOY BY FIGURES | 203 | 203 | 115 | 8.85 | +1537 | +13.4 |
| LEGAL CHARGES ONLY | 103 | 103 | 103 | 7.92 | +0 | +0.0 |
| ONE TARGET A SHOOTER | 432 | 432 | 98 | 7.54 | +1071 | +10.9 |
| PATHS CROSS | 96 | 96 | 96 | 7.38 | +5968 | +62.2 |
| TIME ON OUR SIDE | 446 | 412 | 89 | 6.85 | +472 | +5.3 |
| FIVE ACTION | 1144 | 1143 | 83 | 6.38 | +4729 | +57.0 |
| MOVE TO CHARGE COMPUTED | 82 | 82 | 53 | 4.08 | +4498 | +84.9 |
| SHOT RISK POINTS | 277 | 277 | 44 | 3.38 | +1473 | +33.5 |
| ARTILLERY RE-ROLL WEIGHED | 38 | 38 | 38 | 2.92 | +0 | +0.0 |
| FOUR ROUNDS | 67 | 66 | 37 | 2.85 | +1945 | +52.6 |
| HARD STAY DROPPED | 35 | 35 | 35 | 2.69 | +0 | +0.0 |
| MAX FOR POSITIONING | 130 | 129 | 34 | 2.62 | +77 | +2.3 |
| CANNON PLANNED TARGET | 140 | 140 | 30 | 2.31 | -568 | -18.9 |
| CANNON SIGHT KEPT | 27 | 27 | 27 | 2.08 | +0 | +0.0 |
| MARCH CHECK | 39 | 39 | 26 | 2.00 | +448 | +17.2 |
| IDLE COST | 176 | 149 | 24 | 1.85 | +225 | +9.4 |
| COVER ONCE | 123 | 110 | 23 | 1.77 | +551 | +24.0 |
| SHOOTS FROM THE BEST SPOT | 32 | 32 | 20 | 1.54 | +337 | +16.9 |
| SHOTS IN THE MOVE | 367 | 348 | 20 | 1.54 | +567 | +28.4 |
| MANOEUVRE | 36 | 36 | 18 | 1.38 | +468 | +26.0 |
| NEARER NOT NEEDED | 136 | 130 | 18 | 1.38 | +670 | +37.2 |
| ONE OBJECTIVE FORMULA | 124 | 112 | 18 | 1.38 | +746 | +41.4 |
| RISK BY ARC | 47 | 46 | 17 | 1.31 | +405 | +23.8 |
| MISSILES IN THE MOVE | 115 | 99 | 16 | 1.23 | +404 | +25.3 |
| REDIRECT COUNTER | 58 | 50 | 16 | 1.23 | +1007 | +63.0 |
| FOLLOW UP WEIGHED | 15 | 15 | 15 | 1.15 | +4364 | +291.0 |
| LANE BY FIGURES | 15 | 15 | 15 | 1.15 | +638 | +42.5 |
| NEXT CHARGE BY LIST | 127 | 127 | 15 | 1.15 | +315 | +21.0 |
| FALLS SHORT | 294 | 269 | 14 | 1.08 | +147 | +10.5 |
| ADVANCE LANE KEPT | 13 | 13 | 13 | 1.00 | +0 | +0.0 |
| CHARGE LOSSES | 145 | 145 | 13 | 1.00 | +999 | +76.9 |
| CHARGE NOT DECLARED | 13 | 13 | 13 | 1.00 | -2078 | -159.8 |
| LONE WIZARD KEPT IN | 13 | 13 | 13 | 1.00 | +1236 | +95.0 |
| CHARGE NOW FIRST | 31 | 31 | 12 | 0.92 | -397 | -33.1 |
| HOLDER AT DEPLOYMENT | 19 | 19 | 12 | 0.92 | +376 | +31.4 |
| NEXT OBJECTIVE NEARER | 100 | 100 | 12 | 0.92 | +250 | +20.8 |
| RISK BY HIS FIGURE | 278 | 278 | 12 | 0.92 | +990 | +82.5 |
| TIED UP BY THE SUM | 12 | 12 | 12 | 0.92 | +495 | +41.2 |
| MARCH BY THE SUM | 11 | 11 | 11 | 0.85 | +467 | +42.5 |
| WOUNDS ON THE RANKS | 43 | 43 | 11 | 0.85 | +618 | +56.2 |
| CHAFF IN THE MOVE | 15 | 13 | 10 | 0.77 | +0 | +0.0 |
| HOLDS AMBUSHERS | 10 | 10 | 10 | 0.77 | +0 | +0.0 |
| STAY WORTH | 478 | 463 | 10 | 0.77 | +138 | +13.8 |
| HIS TURN DENIED | 27 | 27 | 9 | 0.69 | +197 | +21.9 |
| SCOUT WAITS | 9 | 9 | 9 | 0.69 | +0 | +0.0 |
| CHAFF PASSED | 8 | 8 | 8 | 0.62 | -32 | -4.0 |
| MODEL FACING | 8 | 8 | 8 | 0.62 | +2026 | +253.3 |
| OFF BEST | 8 | 8 | 8 | 0.62 | -84 | -10.5 |
| SHOOTERS IN TWO RANKS | 8 | 8 | 8 | 0.62 | +14 | +1.8 |
| WHO HITS BACK | 8 | 8 | 8 | 0.62 | +425 | +53.1 |
| FEATURE BUFFS | 27 | 27 | 7 | 0.54 | +154 | +22.0 |
| FIGHT TO THE END | 22 | 22 | 7 | 0.54 | +505 | +72.1 |
| RANDOM MOVE BY FIGURES | 20 | 20 | 7 | 0.54 | +251 | +35.9 |
| SURE REACH TOGETHER | 17 | 17 | 7 | 0.54 | +12 | +1.7 |
| COMBAT PIVOT | 6 | 6 | 6 | 0.46 | +0 | +0.0 |
| QUARTER ODDS | 24 | 24 | 6 | 0.46 | +373 | +62.1 |
| RESERVE FALL BACK | 6 | 6 | 6 | 0.46 | +393 | +65.5 |
| WIDER SPREAD | 54 | 53 | 6 | 0.46 | +30 | +5.0 |
| CASTER AWAY FROM SCREEN | 5 | 5 | 5 | 0.38 | +0 | +0.0 |
| CASTING BLOCK | 6 | 6 | 5 | 0.38 | +126 | +25.3 |
| KEEP FALLS | 5 | 5 | 5 | 0.38 | +125 | +24.9 |
| ONE FIGHT FORMULA | 115 | 72 | 5 | 0.38 | +17 | +3.4 |
| BEST PRIZE | 4 | 4 | 4 | 0.31 | -141 | -35.3 |
| CAST JOB | 12 | 12 | 4 | 0.31 | +11 | +2.6 |
| REDIRECT WEIGHED | 4 | 4 | 4 | 0.31 | -35 | -8.6 |
| AFTERMATH IN POINTS | 3 | 3 | 3 | 0.23 | +245 | +81.7 |
| BOMBING RUN | 3 | 3 | 3 | 0.23 | +88 | +29.2 |
| HONEST WORTH | 59 | 59 | 3 | 0.23 | +64 | +21.2 |
| MOVES UNITS SPELL | 3 | 3 | 3 | 0.23 | +118 | +39.2 |
| OPENS UP | 4 | 4 | 3 | 0.23 | +70 | +23.5 |
| SHORT GUN FORWARD | 3 | 3 | 3 | 0.23 | +0 | +0.0 |
| FIRE IN ORDER | 2 | 2 | 2 | 0.15 | +0 | +0.0 |
| FRIENDS SHOTS CHECKED | 2 | 2 | 2 | 0.15 | +64 | +32.2 |
| NO DOUBLE ROUNDS | 50 | 49 | 2 | 0.15 | +29 | +14.7 |
| OVERRUNS AWAY | 10 | 10 | 2 | 0.15 | +51 | +25.6 |
| SAME CHARGE LATER | 2 | 2 | 2 | 0.15 | +1 | +0.7 |
| SPELLS IN THE FIGHT | 13 | 12 | 2 | 0.15 | +87 | +43.5 |
| WHOLE FIGHT | 5 | 5 | 2 | 0.15 | +44 | +22.2 |
| CARRIES OUT COUNTER | 1 | 1 | 1 | 0.08 | -164 | -164.1 |
| GUN MASK | 19 | 19 | 1 | 0.08 | +33 | +33.4 |
| HIS MOVE AND SHOT | 48 | 48 | 1 | 0.08 | +43 | +43.4 |
| KEEPS SCOUTS OR AMBUSH | 1 | 1 | 1 | 0.08 | +0 | +0.0 |
| KILLS COUNT | 1 | 1 | 1 | 0.08 | +0 | +0.0 |
| MISSILES NEXT TURN | 141 | 114 | 1 | 0.08 | +31 | +31.0 |
| NEEDED THERE | 1 | 1 | 1 | 0.08 | +0 | +0.0 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.08 | +99 | +99.0 |
| PIVOT GUARDS FLANK | 1 | 1 | 1 | 0.08 | -6 | -6.4 |
| REFUSING RETIRES | 2 | 2 | 1 | 0.08 | -0 | -0.2 |
| RESTRAINS TO SHOOT | 1 | 1 | 1 | 0.08 | +8 | +8.2 |
| RUN DOWN | 43 | 42 | 1 | 0.08 | +22 | +21.8 |
| SET UP TOGETHER | 14 | 13 | 1 | 0.08 | +36 | +36.1 |
| WHOLE FIGHT GAIN | 2 | 2 | 1 | 0.08 | +79 | +79.3 |
| ALREADY CARRIED | 1 | not checked | - | - | - | - |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| BACKUP TARGETS | 5 | 2 | 0 | 0.00 | - | - |
| BLOWS WHERE AIMED | 5 | 5 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 17 | 17 | 0 | 0.00 | - | - |
| CARRIES OUT SET-UP | 1 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 13 | trace | - | - | - | - |
| CHARACTER GUNS | 8 | 8 | 0 | 0.00 | - | - |
| CHARGER SLAIN LOST | 4 | 4 | 0 | 0.00 | - | - |
| CHEAP HELPER | 1 | not checked | - | - | - | - |
| CHEAPEST HOLDER | 3 | 3 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 21 | not checked | - | - | - | - |
| EDGE GIVE GROUND | 2 | 2 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 50 | 49 | 0 | 0.00 | - | - |
| FALLBACK BY WORTH | 5 | 5 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 120 | not checked | - | - | - | - |
| FRIEND CHARGES FIRST | 3 | 3 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 16 | 16 | 0 | 0.00 | - | - |
| GIVES UP | 4 | 4 | 0 | 0.00 | - | - |
| GUN FIGURES | 12 | not checked | - | - | - | - |
| HE SHOOTS OR CHARGES | 55 | 55 | 0 | 0.00 | - | - |
| HIS CHARGE DENIED | 6 | 5 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 54 | 54 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 85 | 85 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 43 | 43 | 0 | 0.00 | - | - |
| HOLD ODDS | 86 | 86 | 0 | 0.00 | - | - |
| JOINT KNOWS CHALLENGE | 2 | 2 | 0 | 0.00 | - | - |
| LONG SHOT | 4 | 4 | 0 | 0.00 | - | - |
| LOST CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 1 | 1 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 6 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 2 | trace | - | - | - | - |
| MARCH OVER CASTS | 26 | 26 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 2 | 2 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 11 | trace | - | - | - | - |
| MOVE SPELL SPOT | 4 | not checked | - | - | - | - |
| NOT TURNED | 3 | 3 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 6 | not checked | - | - | - | - |
| ONE CHARGE A CHARGER | 51 | 51 | 0 | 0.00 | - | - |
| OPENS A LANE | 1 | not checked | - | - | - | - |
| PLAN RESULT | 1011 | trace | - | - | - | - |
| REDIRECT BY WHAT IT STOPS | 11 | 11 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 21 | 21 | 0 | 0.00 | - | - |
| SCOUT SPOT | 8 | 8 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 9 | 9 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 6 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 3 | not checked | - | - | - | - |
| SET-UP MISSED | 1 | trace | - | - | - | - |
| SHOT OR CHARGE | 4 | 4 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 5 | not checked | - | - | - | - |
| SPELL WORTH | 23 | not checked | - | - | - | - |
| STAND AND SHOOT | 12 | 12 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 10 | 10 | 0 | 0.00 | - | - |
| STANDS STILL | 402 | 402 | 0 | 0.00 | - | - |
| SUPPORT NARROWED | 13 | 13 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 112 | not checked | - | - | - | - |
| THE PROMISE ADDS | 1 | 1 | 0 | 0.00 | - | - |
| THE PROMISED MOVE | 13 | not checked | - | - | - | - |
| WAITS AGAIN | 26 | 26 | 0 | 0.00 | - | - |
| WAR ENGINE JOBS | 7 | 7 | 0 | 0.00 | - | - |

### Off best figure: h4-mine-bbe8617-p3

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| HOLDER ASSIGNMENT | rule | 1.38 | - | 15.1 |
| CHARGE NOT DECLARED | rule | 0.23 | 0.77 | 159.8 |
| PATHS CROSS | rule | 0.08 | 0.92 | 29.0 |
| CHARGE NOW FIRST | rule | 0.46 | 0.46 | 33.1 |
| CANNON PLANNED TARGET | rule | 0.54 | - | 95.0 |
| JOB FIRST | gate | 0.23 | 0.15 | 14.6 |
| BEST PRIZE | rule | - | 0.31 | 35.3 |
| CHAFF PASSED | rule | 0.15 | 0.08 | 10.6 |
| AFTERMATH BAND | gate | - | 0.15 | 3.4 |
| REDIRECT WEIGHED | rule | - | 0.15 | 37.8 |
| CARRIES OUT COUNTER | rule | - | 0.08 | 164.1 |
| DEPLOY BY FIGURES | rule | - | 0.08 | 4.7 |
| FIGHT ORDER BAND | gate | - | 0.08 | 4.1 |
| PIVOT GUARDS FLANK | rule | - | 0.08 | 6.4 |
| WHO HITS BACK | rule | - | 0.08 | 2.0 |

### Plans: h4-mine-bbe8617-p3

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.6 | 62% | 134 | 94 | 70% |
| Mine | join | 0.2 | 100% | 8 | 0 | 0% |
| Mine | move | 26.4 | 95% | 1533 | 0 | 0% |
| Mine | shoot | 13.0 | 69% | 542 | 892 | 165% |
| Mine | support | 0.5 | 86% | 4 | 0 | 0% |
| Opponent | charge | 2.5 | 70% | 455 | 295 | 65% |
| Opponent | move | 28.5 | 92% | 2202 | 0 | 0% |
| Opponent | shoot | 4.0 | 50% | 151 | 174 | 115% |
| Opponent | support | 0.9 | 100% | 0 | 0 | - |

### Battle groups: h4-mine-bbe8617-p3

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 1.7 | 18% | 75% | 25% | 100% | 33% | 0% | 0% | 67% | 0% |
| Opponent | REDIRECT COUNTER | 2.8 | 14% | 60% | 0% | - | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: h4-mine-bbe8617-p3

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 9 | 57 (9) | 24 | 34 | 48 | 44% | 3.2 | 10 (4) | 230 (2) | 0 (3) | 63 (8) | 0 (1) |
| Mine | Character | 51 | 8 (51) | 8 | 0 | 24 | 37% | 2.0 | 6 (13) | 13 (26) | 0 (6) | 9 (30) | 8 (15) |
| Mine | Clean-up | 9 | 53 (9) | 19 | 35 | 43 | 22% | 3.4 | 0 (1) | 82 (5) | 0 (3) | 76 (4) | 34 (5) |
| Mine | Fast Hammer | 11 | 81 (11) | 17 | 65 | 44 | 27% | 3.9 | 94 (5) | 100 (3) | 0 (3) | 86 (10) | 0 (1) |
| Mine | Fragile | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | - | - | - | - |
| Mine | Hammer | 26 | 37 (26) | 14 | 24 | 33 | 35% | 2.5 | 29 (9) | 39 (14) | 75 (3) | 32 (18) | 46 (8) |
| Mine | Holder | 15 | 80 (15) | 20 | 60 | 47 | 47% | 3.4 | 96 (3) | 46 (4) | 91 (8) | 100 (11) | 9 (4) |
| Mine | Shooter | 12 | 104 (12) | 26 | 78 | 30 | 8% | 1.5 | 55 (3) | 152 (6) | 41 (3) | 111 (6) | 93 (6) |
| Mine | War machine | 30 | 70 (30) | 70 | 0 | 38 | 3% | 1.2 | 68 (8) | 69 (14) | 76 (8) | 54 (9) | 76 (21) |
| Mine | Wizard | 8 | 29 (8) | 29 | 0 | 24 | 25% | 4.3 | - | 33 (7) | - | 0 (1) | 40 (6) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Chaff | 25 | 112 (25) | 7 | 106 | 43 | 64% | 3.3 | 197 (6) | 92 (10) | 76 (9) | 74 (19) | 259 (6) |
| Opponent | Character | 36 | 50 (36) | 50 | 0 | 23 | 19% | 2.4 | 47 (9) | 56 (22) | 29 (4) | 49 (20) | 54 (15) |
| Opponent | Clean-up | 4 | 0 (4) | 0 | 0 | 18 | 0% | 2.8 | 0 (1) | 0 (2) | 0 (1) | 0 (3) | 0 (1) |
| Opponent | Fast | 1 | 187 (1) | 187 | 0 | 100 | 0% | 3.0 | 187 (1) | - | - | 187 (1) | - |
| Opponent | Fast Hammer | 20 | 42 (20) | 2 | 40 | 8 | 40% | 2.4 | 30 (4) | 39 (11) | 66 (5) | 49 (13) | 26 (7) |
| Opponent | Fragile | 2 | 0 (2) | 0 | 0 | 55 | 50% | 1.0 | - | 0 (1) | - | 0 (1) | - |
| Opponent | Hammer | 16 | 29 (16) | 18 | 11 | 37 | 12% | 2.9 | - | 38 (7) | 20 (9) | 16 (7) | 36 (9) |
| Opponent | Holder | 9 | 85 (9) | 0 | 85 | 18 | 56% | 3.8 | 154 (3) | 67 (6) | - | 164 (3) | 61 (6) |
| Opponent | Shooter | 10 | 82 (10) | 7 | 75 | 30 | 30% | 2.0 | 107 (3) | 91 (6) | 0 (1) | 95 (7) | 47 (3) |
| Opponent | War machine | 8 | 46 (8) | 46 | 0 | 44 | 0% | 1.8 | 115 (2) | 9 (5) | 52 (1) | - | 46 (8) |
| Opponent | Wizard | 3 | 0 (3) | 0 | 0 | 0 | 33% | 4.0 | 0 (1) | 0 (1) | 0 (1) | 0 (3) | - |

### Charged fights: h4-mine-bbe8617-p3

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 41 | 37 | 1.2 | 1.2 | 29 | 82 | -53 | 3 of 5 | 2 of 5 | -274 | +2 |
| Mine | Chaos Dwarfs | 4 | 442 | 101 | 1.2 | 1.0 | 81 | 0 | +81 | 2 of 5 | 3 of 5 | - | +81 |
| Mine | Dwarfen Mountain Holds | 3 | 483 | 82 | 1.7 | 1.0 | 49 | 0 | +49 | 1 of 5 | 4 of 5 | - | +49 |
| Mine | Empire of Man | 2 | 184 | 132 | 3.0 | 1.0 | 44 | 0 | +44 | 0 of 6 | 6 of 6 | - | +44 |
| **Mine** | all armies | 13 | 289 | 82 | 1.6 | 1.0 | 50 | 20 | +31 | 6 of 21 | 15 of 21 | -274 | +46 |
| Opponent | Grand Cathay | 3 | 252 | 151 | 3.0 | 1.1 | 50 | 0 | +50 | 4 of 9 | 8 of 9 | +0 | +56 |
| Opponent | High Elf Realms | 2 | 42 | 306 | 2.5 | 1.0 | 122 | 59 | +63 | 1 of 5 | 4 of 5 | - | +63 |
| Opponent | Ogre Kingdoms | 1 | 65 | 113 | 2.0 | 1.5 | 56 | 114 | -58 | 1 of 2 | 1 of 2 | -115 | +0 |
| Opponent | Skaven | 1 | 0 | 301 | 1.0 | 1.0 | 301 | 0 | +301 | 1 of 1 | 0 of 1 | - | +301 |
| Opponent | Vampire Counts | 1 | 110 | 835 | 7.0 | 1.1 | 119 | 16 | +104 | 5 of 7 | 6 of 7 | +79 | +108 |
| Opponent | Warriors of Chaos | 4 | 0 | 461 | 1.8 | 1.0 | 263 | 0 | +263 | 3 of 7 | 6 of 7 | - | +263 |
| Opponent | Wood Elf Realms | 1 | 0 | 285 | 3.0 | 1.0 | 95 | 0 | +95 | 0 of 3 | 3 of 3 | - | +95 |
| **Opponent** | all armies | 13 | 78 | 342 | 2.6 | 1.1 | 131 | 19 | +112 | 15 of 34 | 28 of 34 | -12 | +124 |

### Effective charges: h4-mine-bbe8617-p3

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 5 | 4 (net -66) | 0 | 0 | 1 (net +0) | 0 | 0 | 0 | 0% (0 of 5) |
| Mine | Chaos Dwarfs | 5 | 0 | 0 | 1 (net +0) | 3 (net +113) | 1 (net +63) | 0 | 0 | 20% (1 of 5) |
| Mine | Dwarfen Mountain Holds | 5 | 1 (net +0) | 0 | 1 (net +92) | 3 (net +51) | 0 | 0 | 0 | 20% (1 of 5) |
| Mine | Empire of Man | 6 | 0 | 0 | 2 (net +0) | 4 (net +66) | 0 | 0 | 0 | 33% (2 of 6) |
| Opponent | Grand Cathay | 9 | 2 (net +162) | 0 | 1 (net +0) | 1 (net +0) | 3 (net +43) | 1 (net +0) | 1 | 12% (1 of 8) |
| Opponent | High Elf Realms | 5 | 0 | 0 | 1 (net +112) | 1 (net -297) | 2 (net +94) | 1 (net +310) | 0 | 20% (1 of 5) |
| Opponent | Ogre Kingdoms | 2 | 1 (net +0) | 0 | 0 | 0 | 0 | 1 (net -115) | 0 | 0% (0 of 2) |
| Opponent | Skaven | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +301) | 0 | 0% (0 of 1) |
| Opponent | Vampire Counts | 7 | 2 (net +0) | 0 | 0 | 2 (net +190) | 2 (net +78) | 1 (net +189) | 0 | 0% (0 of 7) |
| Opponent | Warriors of Chaos | 7 | 0 | 0 | 0 | 3 (net +427) | 2 (net +282) | 1 (net +0) | 1 | 0% (0 of 6) |
| Opponent | Wood Elf Realms | 3 | 0 | 0 | 1 (net +95) | 2 (net +95) | 0 | 0 | 0 | 33% (1 of 3) |

### Charged fights, damage counted: h4-mine-bbe8617-p3

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 5 | 66 | 333 | -53 | 47 | 89 | -42 | -63.9 |
| Mine | Effective (55-75%) | 4 | 133 | 137 | +23 | 69 | 45 | +24 | +17.8 |
| Mine | 76-89% | 11 | 189 | 103 | +69 | 78 | 6 | +73 | +38.5 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 339 | 63 | +63 | 63 | 0 | +63 | +18.6 |
| Mine | All fights | 21 | 156 | 162 | +31 | 68 | 33 | +36 | +22.7 |
| Opponent | Long shot (under 50%) | 5 | 269 | 200 | +65 | 88 | 22 | +67 | +24.8 |
| Opponent | Effective (55-75%) | 3 | 170 | 160 | +69 | 78 | 90 | -12 | -7.0 |
| Opponent | 76-89% | 9 | 491 | 216 | +173 | 212 | 93 | +119 | +24.2 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 6 | 390 | 218 | +114 | 182 | 100 | +81 | +20.9 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 9 | 500 | 101 | +115 | 138 | 19 | +119 | +23.8 |
| Opponent | No odds | 2 | 170 | 164 | +0 | 24 | 12 | +12 | +7.2 |
| Opponent | All fights | 34 | 396 | 176 | +112 | 146 | 59 | +87 | +21.9 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| h4-mine-bbe8617-p3 | move | 81 | 16 (20%) | 15 (19%) | 8 (10%) | 57 (70%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0111, L0128 |
| Charmed Shield | Opponent | L0534, L0726 |
| Elixir of Power | Opponent | L0111, L0211 |
| Fistful of Laurels | Opponent | L0518 |
| Periapt of Soul Exchange | Opponent | L0621 |
| Ring of Doom | Mine | L0211, L0228 |
| Ring of Doom | Opponent | L0111, L0211, L0415 |
| Ring of Jet | Opponent | L0111, L0211, L0710 |
| Standard of the Fell Warrior | Opponent | L0313 |
| Storm Daemon (Renegade 2.0) | Opponent | L0621 |
| Twice-Blessed Armour | Mine | L0710, L0726 |
| Twice-Blessed Armour | Opponent | L0710 |
| Witch Hunter's Ward | Mine | L0710, L0726 |

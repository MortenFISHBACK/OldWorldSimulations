# Doctrine scorecard: h4-opp-bbe8617-p1

### Scorecard: h4-opp-bbe8617-p1

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0103 | 1 | 1 | Mine | no | 4 | - | 0 | 1 | 0 | 0 | 0 | 0 |
| L0103 | 1 | 1 | Opponent | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 535 |
| L0120 | 6 | 1 | Mine | no | 2 | - | 0 | 0 | 0 | 0 | 0 | 0 |
| L0120 | 6 | 1 | Opponent | no | 2 | - | 2 | 2 | 1 | 0 | 0 | 420 |
| L0204 | 6 | 1 | Mine | no | 8 | 4 | 1 | 6 | 0 | 0 | 0 | 0 |
| L0204 | 6 | 1 | Opponent | no | 0 | 1 | 4 | 1 | 0 | 0 | 0 | 0 |
| L0304 | 4 | 1 | Mine | no | 0 | 5 | 1 | 0 | 0 | 0 | 0 | 110 |
| L0304 | 4 | 1 | Opponent | no | 0 | 2 | 6 | 1 | 1 | 0 | 0 | 112 |
| **Average** | | | Mine | 0% | 3.5 | 4.5 | 0.5 | 1.8 | 0.0 | 0.0 | 0.0 | 27.5 |
| **Average** | | | Opponent | 0% | 0.5 | 1.5 | 3.0 | 1.2 | 0.5 | 0.0 | 0.0 | 266.8 |

### KPIs: h4-opp-bbe8617-p1

Rules off - Mine only: HOLDER ASSIGNMENT, QUARTER ODDS.

Morten 2026-11-10; 4 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 33% (4 of 12) | 16% (3 of 19) | 23% (7 of 31) |
| Winner chose to follow up after the loser gave ground |  | 78% (7 of 9); on the table 78% | - | 78% (7 of 9); on the table 78% |
| Winner chose to pursue after the loser fell back in good order |  | - | - | - |
| Winner chose to pursue after the loser fled |  | 100% (1 of 1); on the table 100% | - | 100% (1 of 1); on the table 100% |
| Winner chose to follow up or pursue (all three) |  | 80% (8 of 10); on the table 80% | - | 80% (8 of 10); on the table 80% |
| Magic missiles tried each own turn | 50%+ | 39% (37 of 96) | 33% (10 of 30) | 37% (47 of 126) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 46% (37 of 81) | 38% (10 of 26) | 44% (47 of 107) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 83% (5 of 6) | 50% (4 of 8) | 64% (9 of 14) |
| Points that never fought | lower | 46% (3178 of 6892) | 62% (4960 of 7996) | 55% (8138 of 14888) |
|   infantry points that never fought | lower | 47% (1208 of 2553) | 85% (1844 of 2172) | 65% (3052 of 4725) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 68% (15 of 22) | 48% (15 of 31) | 57% (30 of 53) |
| Bound items with a magic missile used (at least once a game) |  | 100% (4 of 4); 2.8 uses a game | 0.0 uses a game | 100% (4 of 4); 1.4 uses a game |
| Bound items with another spell used |  | 100% (2 of 2); 0.8 uses a game | 0.0 uses a game | 100% (2 of 2); 0.4 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 100% (5 of 5); 1.2 uses a game | 50% (1 of 2); 0.2 uses a game | 86% (6 of 7); 0.8 uses a game |
|   their share of the points of units over 100 pts | lower | 58% (2886 of 4939) | 45% (3244 of 7147) | 51% (6130 of 12086) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 6.8 (46%) | 3.0 (60%) | 9.8 (49%) |
| MARCHED: its unit marched | 4.2 (29%) | 0.2 (5%) | 4.5 (23%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.5 (10%) | 0.5 (3%) |
| IN COMBAT: engaged in combat | 2.5 (17%) | 1.0 (20%) | 3.5 (18%) |
| GONE: slain | 1.2 (8%) | 0.0 (0%) | 1.2 (6%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.2 (5%) | 0.2 (1%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 9.5 | 0.0 | 4.0 | 11.8 | 0.2 | 4.8 |
| not cast | 2.5 | 1.5 | 8.0 | 19.8 | 1.2 | 22.2 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.0 (9%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.2 (17%) | 1.0 (12%) | 9.8 (49%) | 0.5 (40%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 4.5 (23%) | 0.0 (0%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.5 (3%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.8 (30%) | 0.0 (0%) | 1.5 (19%) | 3.5 (18%) | 0.2 (20%) | 0.0 (0%) |
| GONE: slain | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.2 (6%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.2 (10%) | 0.0 (0%) | 0.2 (3%) | 0.2 (1%) | 0.5 (40%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.5 (60%) | 1.2 (83%) | 5.2 (66%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 20.2 (91%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 4.0 a game | 0.8 a game | 2.4 a game |
| stood (cast and not dispelled) | 44% (7 of 16) | 67% (2 of 3) | 47% (9 of 19) |
| the unit moved after it | 86% (6 of 7) | 100% (2 of 2) | 89% (8 of 9) |
| it charged on its next turn | 0% (0 of 7) | 0% (0 of 2) | 0% (0 of 9) |
| the enemy charged it first | 43% (3 of 7) | 0% (0 of 2) | 33% (3 of 9) |
| it fought by the end of its next turn | 29% (2 of 7) | 0% (0 of 2) | 22% (2 of 9) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 7) | 0% (0 of 2) | 0% (0 of 9) |
| none of these (no charge, no fight, no charge escaped) | 57% (4 of 7) | 100% (2 of 2) | 67% (6 of 9) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 70% (30 of 43) | 42% (33 of 79) | 52% (63 of 122) |
|   cavalry | - | 67% (2 of 3) | 67% (2 of 3) |
|   chariot | - | 44% (20 of 45) | 44% (20 of 45) |
|   infantry | 71% (17 of 24) | 36% (5 of 14) | 58% (22 of 38) |
|   war machine | 68% (13 of 19) | 35% (6 of 17) | 53% (19 of 36) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.2 (38%) | 2.5 (22%) | 3.8 (25%) |
| CHARGED: it charged | 0.2 (8%) | 0.5 (4%) | 0.8 (5%) |
| IN COMBAT: it fought this turn or the last | 0.0 (0%) | 1.5 (13%) | 1.5 (10%) |
| MOVED: a war machine that moved | 1.2 (38%) | 0.2 (2%) | 1.5 (10%) |
| NO TARGET IN RANGE | 0.2 (8%) | 3.2 (28%) | 3.5 (24%) |
| ONLY IN COMBAT: the only targets were in combat | 0.0 (0%) | 0.2 (2%) | 0.2 (2%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.0 (0%) | 2.0 (17%) | 2.0 (14%) |
| OTHER BAR | 0.2 (8%) | 1.2 (11%) | 1.5 (10%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 0.5 | 0.2 | 50% | 4.5 pts | 2 pts |
| chariot | 5.8 | 11.0 | 35% | 22.0 pts | 127 pts |
| infantry | 5.5 | 4.0 | 64% | 6.5 pts | 36 pts |
| war machine | 4.8 | 3.2 | 74% | 5.5 pts | 26 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 0.5 | 4.2 | 2.4 |
| Charges that made contact a game | 0.2 | 3.0 | 1.6 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.00 declared, 0.00 contact (2 units) | 0.80 declared, 0.40 contact (5 units) | 0.57 declared, 0.29 contact (7 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | - | - |
|   per unit a game, the other units (no war machines, no joined characters) | 0.10 declared, 0.05 contact (21 units) | 0.43 declared, 0.33 contact (30 units) | 0.29 declared, 0.22 contact (51 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 100% (2 of 2) | - | - | 100% (2 of 2) |
| Character in a unit | 75% (3 of 4) | 67% (4 of 6) | - | 70% (7 of 10) |
| Character on its own | 100% (3 of 3) | 50% (1 of 2) | 33% (1 of 3) | 62% (5 of 8) |
| Chariot | - | 50% (3 of 6) | - | 50% (3 of 6) |
| Infantry | 11% (1 of 9) | 29% (2 of 7) | - | 19% (3 of 16) |
| Monster | 100% (1 of 1) | 50% (1 of 2) | - | 67% (2 of 3) |
| War Machines | 100% (6 of 6) | 100% (2 of 2) | - | 100% (8 of 8) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 3 | 100% (8 of 8); on the table 100% | 35% (29 of 84) | 46% | 56% (9 of 16) | 100% (4 of 4); 3.7 uses a game | 100% (2 of 2); 1.0 uses a game | 100% (4 of 4); 1.3 uses a game |
| Chaos Dwarfs | 4 | 0% (0 of 2); on the table 0% | 47% (17 of 36) | 54% | 57% (17 of 30) | 0.0 uses a game | 0.0 uses a game | 100% (2 of 2); 0.5 uses a game |
| Skaven | 1 | - | 17% (1 of 6) | 79% | 57% (4 of 7) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (h4-opp-bbe8617-p1, 4 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 30% (3) | 50% (1) | 33% (4) |
| ...free all their last turn and able to turn (per game) | 0.50 | 0.00 | 0.50 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.25 | 0.00 | 0.25 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: h4-opp-bbe8617-p1

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 0.5 | 1.8 |
| Strategy | Charge objectives carried out (made contact) | 0% (0 of 3) | 31% (5 of 16) |
| Strategy | Shoot objectives carried out (shot that target) | 43% (13 of 30) | 30% (8 of 27) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | - | 100% (5 of 5) |
| Strategy | Joined characters whose unit fought | 62% (10 of 16) | 0% (0 of 3) |
| Strategy | Lone characters that fought | 40% (2 of 5) | 57% (4 of 7) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 1.8 | 1.2 |
| Movement | Points that never moved of their own | 27.5 | 266.8 |
| Movement | Fights charged into per game | 0.5 | 2.5 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 2 | 5 of 9, net +67 |
| Movement | Charges with odds: sweet spot (55-75%) | 1 of 2, net +340 | 1 of 9, net +0 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 2 | 0 of 9 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 0 of 2 | 2 of 9, net +115 |
| Shooting | Shots by shooting units (incl. breath weapons) | 4.2 | 7.5 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 29% (5 of 17) | 20% (6 of 30) |
| Shooting | Points destroyed by shooting units | 16.2 | 35.0 |
| Shooting | War machine shots | 3.2 | 1.5 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 38% (5 of 13) | 100% (6 of 6) |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | 5.0 | 1.2 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 35% (7 of 20) | 20% (1 of 5) |
| Magic | Wounds caused by magic missiles | 7.0 | 2.0 |
| Magic | Wounds caused by other spells | 2.8 | 1.0 |
| Magic | Points destroyed by magic (all spells) | 55.5 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 3.2 / 0.0 / 2.5 / 0.2 | 3.8 / 0.0 / 0.8 / 0.0 |
| Combat | Points destroyed in combat | 250.0 | 154.8 |
| Combat | Points run down | 0.0 | 91.0 |
| Combat | Net points per charged fight, damage counted | +236 | -24 |
| Combat | Net per 100 charger points, damage counted | +125.8 | -9.1 |
| Combat | First round won (charged fights) | 100% | 30% |
| Combat | Net points per charged fight | +170 | +56 |
| Combat | Net points per supported fight / lone fight | - / +170 | - / +56 |
| Combat | Charged fights on a top-3 enemy unit | 1 of 2 | 8 of 10 |
| Game | Points lost | 358.8 | 458.5 |
| Game | VP from objectives | 715.0 | 932.5 |
| Game | Lone holders (player turns) | 3.5 | 0.5 |

- Mine won / drew / lost: 1 / 1 / 2 of 4 ended games (of 4); mean margin (Mine - Opponent) -118 VP
- The side that went first won 1 of 3 games with a winner
- Points traded per game (both sides' losses): 817
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: h4-opp-bbe8617-p1

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | - | - | - | - | 0.8 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.5 | +117.8 | 0.0 | 91.0 | - | - | - | - |
| ARTILLERY RE-ROLL WEIGHED | 1.8 | +0.0 | 0.0 | 85.0 | 0.5 | +0.0 | 0.0 | 27.5 |
| BEST PRIZE | - | - | - | - | 0.5 | -135.2 | 21.2 | 0.0 |
| BLOWS WHERE AIMED | - | - | - | - | 0.2 | -6.5 | 0.0 | 0.0 |
| CANNON PLAN MISSED | - | - | - | - | 0.5 | +0.0 | 27.5 | 27.5 |
| CANNON PLANNED TARGET | 3.2 | +0.0 | 28.0 | 112.5 | 1.0 | +0.0 | 0.0 | 27.5 |
| CANNON SIGHT KEPT | 1.0 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT COUNTER | 0.2 | +0.0 | 145.0 | 0.0 | - | - | - | - |
| CAST JOB | 1.0 | +5.2 | 0.0 | 0.0 | 2.0 | +22.1 | 0.0 | 0.0 |
| CASTING BLOCK | 1.0 | +80.9 | 0.0 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | 1.5 | +0.0 | 0.0 | 0.0 | 0.5 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.2 | +13.8 | 0.0 | 0.0 | 0.2 | +4.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | 0.2 | +13.8 | 0.0 | 13.8 | - | - | - | - |
| CHAFF PASSED | 0.2 | -0.5 | 0.0 | 0.0 | - | - | - | - |
| CHARGE LOSSES | 7.0 | -262.0 | 0.0 | 133.5 | 6.5 | -277.4 | 0.0 | 126.2 |
| CHARGE NOT DECLARED | - | - | - | - | 0.2 | +0.0 | 0.0 | 0.0 |
| CHARGE NOW FIRST | 0.8 | +0.0 | 202.5 | 0.0 | 1.8 | +0.0 | 168.8 | 0.0 |
| COMBAT PIVOT | 0.2 | +0.0 | 0.0 | 0.0 | 0.5 | +0.0 | 0.0 | 52.5 |
| CONVEYANCE SEARCH | 2.2 | +144.4 | 0.0 | 0.0 | 0.2 | +5.8 | 0.0 | 0.0 |
| COVER ONCE | 3.0 | -129.4 | 0.0 | 27.5 | 7.5 | -424.3 | 0.0 | 0.0 |
| DEFENSIVE FLOOR | - | - | - | - | 0.5 | -16.4 | 0.0 | 0.0 |
| DEPLOY BY FIGURES | 7.2 | +26.3 | 0.0 | 0.0 | 8.2 | +46.4 | 0.0 | 56.0 |
| EDGE GIVE GROUND | 0.2 | +17.6 | 57.5 | 0.0 | - | - | - | - |
| ENGINEER BY LORE | 0.5 | +0.0 | 0.0 | 0.0 | 0.5 | +0.0 | 0.0 | 0.0 |
| FALL BACK GOOD ORDER | 0.8 | +0.1 | 230.5 | 20.2 | 3.0 | +5.0 | 229.8 | 0.0 |
| FALLS SHORT | 12.2 | +226.6 | 0.0 | 42.5 | 15.0 | +176.7 | 0.0 | 16.2 |
| FEATURE BUFFS | 4.0 | +129.7 | 0.0 | 13.8 | 0.8 | +17.0 | 0.0 | 0.0 |
| FIGHT LIFT | 0.2 | +1.9 | 0.0 | 0.0 | - | - | - | - |
| FIGHT TO THE END | 0.5 | +0.5 | 202.5 | 0.0 | 1.0 | -24.9 | 57.5 | 0.0 |
| FIVE ACTION | 38.5 | +2064.4 | 489.0 | 484.8 | 51.0 | +2872.4 | 384.8 | 330.5 |
| FLANK NOT WEIGHED | 2.0 | +0.0 | 0.0 | 224.5 | 4.5 | +0.0 | 0.0 | 0.0 |
| FOLLOW UP WEIGHED | 0.8 | +132.6 | 0.0 | 0.0 | 0.2 | +137.2 | 0.0 | 145.0 |
| FOUR ROUNDS | 0.8 | +43.0 | 230.5 | 20.2 | 4.0 | +276.8 | 287.2 | 0.0 |
| FRIEND SHOOTS FIRST | 0.5 | -5.1 | 0.0 | 0.0 | - | - | - | - |
| GIVES UP | - | - | - | - | 0.5 | -1.1 | 27.5 | 0.0 |
| GROUND FLIERS | 0.2 | +10.4 | 0.0 | 54.8 | - | - | - | - |
| GUN FIGURES | 0.8 | +0.1 | 0.0 | 0.0 | 4.0 | +2.4 | 13.8 | 0.0 |
| HARD STAY DROPPED | 0.2 | +0.0 | 0.0 | 0.0 | 3.5 | +0.0 | 0.0 | 0.0 |
| HE SHOOTS OR CHARGES | 2.0 | +0.0 | 0.0 | 21.2 | 2.2 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE LIST | 0.8 | +0.0 | 0.0 | 0.0 | 0.8 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 1.0 | +0.0 | 0.0 | 0.0 | 2.5 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 1.2 | -31.1 | 0.0 | 35.0 | 1.0 | -44.5 | 0.0 | 28.0 |
| HIS RANDOM MOVE | 2.8 | +0.0 | 0.0 | 13.8 | 1.8 | +0.0 | 0.0 | 28.0 |
| HIS SHOT LIST | 16.2 | +382.7 | 0.0 | 217.0 | 25.8 | +734.8 | 0.0 | 157.5 |
| HIS TURN DENIED | 0.5 | +3.4 | 85.5 | 20.2 | 2.0 | +59.0 | 105.2 | 0.0 |
| HOLD ODDS | - | - | - | - | 10.5 | +0.0 | 0.0 | 0.0 |
| HOLDER ASSIGNMENT | - | - | - | - | 21.5 | +2023.0 | 0.0 | 0.0 |
| HOLDER AT DEPLOYMENT | 1.0 | +199.9 | 0.0 | 0.0 | - | - | - | - |
| HOLDS AMBUSHERS | 0.8 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HONEST WORTH | 0.2 | -2.0 | 28.0 | 20.2 | 3.2 | -161.3 | 287.2 | 0.0 |
| IDLE COST | 6.5 | -65.8 | 0.0 | 56.2 | 8.5 | -117.3 | 0.0 | 16.2 |
| LANE BY FIGURES | - | - | - | - | 0.8 | +21.0 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 6.5 | +0.0 | 520.0 | 70.0 | 1.5 | +0.0 | 0.0 | 580.0 |
| LONE WIZARD KEPT IN | 2.0 | +136.3 | 0.0 | 28.8 | 0.2 | +29.7 | 0.0 | 0.0 |
| LONG SHOT | 0.5 | -8.4 | 85.5 | 20.2 | - | - | - | - |
| MANOEUVRE | 0.8 | +0.1 | 0.0 | 0.0 | 1.5 | +5.3 | 0.0 | 0.0 |
| MARCH AT ESCAPER | - | - | - | - | 0.2 | +0.0 | 0.0 | 0.0 |
| MARCH BY THE SUM | 0.5 | +18.9 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | 1.5 | +161.6 | 0.0 | 0.0 | 1.2 | +69.0 | 0.0 | 0.0 |
| MARCH OVER CASTS | 0.8 | +25.4 | 0.0 | 0.0 | - | - | - | - |
| MAX FOR POSITIONING | 2.2 | +63.0 | 0.0 | 21.2 | 2.5 | +29.0 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 7.2 | +387.2 | 0.0 | 0.0 | 5.0 | +72.5 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 8.0 | +240.5 | 0.0 | 0.0 | 4.5 | +40.7 | 0.0 | 0.0 |
| MOVE SPELL IN RANGE | - | - | - | - | 0.5 | +7.2 | 0.0 | 0.0 |
| MOVE SPELL OUT OF RANGE | 2.5 | -64.5 | 0.0 | 0.0 | 1.8 | -34.0 | 0.0 | 0.0 |
| MOVE SPELL SPOT | 1.2 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 0.5 | +45.5 | 0.0 | 0.0 | 2.2 | +220.8 | 0.0 | 0.0 |
| MOVES UNITS SPELL | 0.2 | +13.8 | 0.0 | 0.0 | - | - | - | - |
| NEARER NOT NEEDED | 4.2 | +293.2 | 0.0 | 91.0 | 6.8 | +318.1 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 1.5 | -62.1 | 57.5 | 0.0 | 4.8 | -193.2 | 0.0 | 0.0 |
| NEXT OBJECTIVE NEARER | 9.0 | -439.1 | 28.0 | 133.5 | 0.5 | -2.9 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 0.5 | -31.6 | 202.5 | 0.0 | 3.0 | -95.5 | 287.2 | 0.0 |
| NOT WORTH A CAST | 1.2 | -2.1 | 0.0 | 0.0 | 0.2 | -0.2 | 0.0 | 0.0 |
| OFF BEST | 0.2 | -0.2 | 0.0 | 13.8 | 0.2 | -9.3 | 0.0 | 0.0 |
| ONE CHARGE A CHARGER | 2.2 | +0.0 | 0.0 | 112.2 | 1.8 | +0.0 | 0.0 | 52.5 |
| ONE FIGHT FORMULA | 2.2 | -55.8 | 0.0 | 0.0 | 4.8 | -102.4 | 0.0 | 0.0 |
| ONE OBJECTIVE FORMULA | 4.8 | -50.0 | 0.0 | 0.0 | 6.5 | +151.3 | 0.0 | 0.0 |
| ONE TARGET A SHOOTER | 10.0 | +164.9 | 0.0 | 13.8 | 23.0 | +397.0 | 0.0 | 157.5 |
| OPENS A LANE | 0.2 | +0.5 | 27.5 | 0.0 | - | - | - | - |
| OPENS UP | - | - | - | - | 0.5 | +14.1 | 27.5 | 0.0 |
| OVERRUNS AWAY | 0.5 | +21.9 | 85.5 | 20.2 | 0.8 | +37.9 | 47.8 | 0.0 |
| PATHS CROSS | 3.5 | +88.2 | 0.0 | 0.0 | 5.0 | +120.8 | 0.0 | 0.0 |
| PLAN RESULT | 34.2 | +281.6 | 347.5 | 518.8 | 43.8 | +292.2 | 153.8 | 652.2 |
| QUARTER ODDS | - | - | - | - | 3.0 | +402.4 | 182.0 | 0.0 |
| RANDOM MOVE BY FIGURES | 1.5 | +2.2 | 0.0 | 0.0 | 2.0 | +35.5 | 0.0 | 157.5 |
| REDIRECT BY WHAT IT STOPS | 0.5 | -5.8 | 0.0 | 13.8 | - | - | - | - |
| REDIRECT COUNTER | 1.8 | +92.8 | 0.0 | 35.0 | 1.5 | +75.3 | 0.0 | 28.0 |
| REDIRECT WEIGHED | - | - | - | - | 0.2 | +0.0 | 0.0 | 0.0 |
| REFORMS TO MEET IT | - | - | - | - | 0.2 | -7.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | - | - | - | - | 0.2 | +23.9 | 0.0 | 0.0 |
| RISK BY ARC | 0.5 | -9.4 | 85.5 | 20.2 | 1.8 | -41.8 | 105.2 | 0.0 |
| RISK BY HIS FIGURE | 10.2 | -180.8 | 0.0 | 238.2 | 12.2 | -137.1 | 0.0 | 110.0 |
| RUN DOWN | 0.5 | -2.0 | 85.5 | 20.2 | 2.0 | -23.9 | 287.2 | 0.0 |
| SCOUT SPOT | 0.5 | +6.1 | 0.0 | 0.0 | - | - | - | - |
| SCOUT WAITS | 0.5 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SCREEN BY WHAT IT SAVES | 0.8 | -45.3 | 0.0 | 0.0 | - | - | - | - |
| SEARCH SPOT | 7.2 | +188.0 | 0.0 | 21.2 | 5.8 | +122.3 | 0.0 | 0.0 |
| SET-UP ANY TARGET | 0.8 | +100.4 | 0.0 | 0.0 | - | - | - | - |
| SHOOTS FROM THE BEST SPOT | 0.8 | +57.2 | 173.0 | 0.0 | 1.5 | +29.5 | 0.0 | 0.0 |
| SHOT OR CHARGE | 0.5 | -27.6 | 173.0 | 20.2 | 0.2 | -0.0 | 0.0 | 0.0 |
| SHOT RISK POINTS | 13.0 | -53.9 | 0.0 | 98.8 | 11.2 | -116.6 | 0.0 | 201.8 |
| SHOTS IN THE MOVE | 10.5 | +201.7 | 0.0 | 170.0 | 11.8 | +216.0 | 0.0 | 156.8 |
| SPELL SETS UP CHARGE | 0.8 | +100.4 | 0.0 | 0.0 | - | - | - | - |
| SPELL WORTH | 1.5 | +10.2 | 0.0 | 0.0 | 2.8 | +26.3 | 290.0 | 290.0 |
| SPELLS IN THE FIGHT | 0.2 | -15.8 | 145.0 | 0.0 | 0.2 | +0.8 | 27.5 | 0.0 |
| STAND AND SHOOT | 0.2 | -0.7 | 28.0 | 20.2 | - | - | - | - |
| STANDS FOR A REASON | 0.2 | +0.0 | 0.0 | 0.0 | 0.8 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 9.8 | +0.0 | 258.5 | 183.8 | 16.2 | +0.0 | 97.5 | 233.8 |
| STAY WORTH | 13.5 | -224.8 | 85.5 | 255.0 | 11.5 | +102.1 | 70.0 | 71.2 |
| STUCK PIVOT | 0.8 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SUPPORT NARROWED | 0.5 | +0.0 | 145.0 | 0.0 | 0.5 | +0.0 | 57.5 | 0.0 |
| SURE REACH TOGETHER | 0.5 | +2.0 | 0.0 | 0.0 | - | - | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 2.8 | +0.0 | 0.0 | 0.0 | 4.5 | +0.0 | 0.0 | 0.0 |
| THE PROMISE ADDS | 0.2 | -22.1 | 0.0 | 0.0 | - | - | - | - |
| THE PROMISED MOVE | - | - | - | - | 1.5 | +0.0 | 0.0 | 0.0 |
| TIED UP BY THE SUM | - | - | - | - | 0.5 | +61.5 | 47.8 | 0.0 |
| TIME ON OUR SIDE | 14.2 | +296.5 | 0.0 | 13.8 | 19.0 | +314.9 | 0.0 | 28.0 |
| WAITS AGAIN | 0.5 | +0.0 | 0.0 | 0.0 | 1.5 | +0.0 | 0.0 | 0.0 |
| WAR ENGINE CHARGES | 0.2 | +82.2 | 145.0 | 0.0 | - | - | - | - |
| WAR ENGINE JOBS | 0.2 | +0.0 | 0.0 | 0.0 | 1.5 | +0.0 | 56.2 | 0.0 |
| WHO HITS BACK | 0.5 | +230.2 | 0.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT | 0.2 | +32.8 | 145.0 | 0.0 | 0.2 | +28.4 | 0.0 | 0.0 |
| WIDER SPREAD | 0.8 | -7.9 | 230.5 | 20.2 | 2.2 | -5.5 | 267.0 | 0.0 |
| WOUNDS ON THE RANKS | 2.2 | +157.2 | 0.0 | 0.0 | 0.5 | +4.7 | 0.0 | 0.0 |

### Rule changes: h4-opp-bbe8617-p1

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HOLDER ASSIGNMENT | 86 | 86 | 82 | 20.50 | +2888 | +35.2 |
| SEARCH SPOT | 52 | 52 | 49 | 12.25 | +1243 | +25.4 |
| HIS SHOT LIST | 168 | 168 | 44 | 11.00 | +628 | +14.3 |
| DEPLOY BY FIGURES | 62 | 62 | 38 | 9.50 | +1007 | +26.5 |
| PATHS CROSS | 34 | 34 | 34 | 8.50 | +836 | +24.6 |
| ONE TARGET A SHOOTER | 132 | 132 | 33 | 8.25 | +205 | +6.2 |
| LEGAL CHARGES ONLY | 32 | 32 | 32 | 8.00 | +0 | +0.0 |
| TIME ON OUR SIDE | 133 | 124 | 28 | 7.00 | +238 | +8.5 |
| FIVE ACTION | 358 | 358 | 20 | 5.00 | +205 | +10.2 |
| HARD STAY DROPPED | 15 | 15 | 15 | 3.75 | +0 | +0.0 |
| SHOT RISK POINTS | 97 | 97 | 13 | 3.25 | +123 | +9.4 |
| MISSILES IN THE MOVE | 49 | 44 | 11 | 2.75 | +301 | +27.3 |
| FALLS SHORT | 109 | 100 | 10 | 2.50 | +95 | +9.5 |
| IDLE COST | 60 | 51 | 10 | 2.50 | +48 | +4.8 |
| ARTILLERY RE-ROLL WEIGHED | 9 | 9 | 9 | 2.25 | +0 | +0.0 |
| LONE WIZARD KEPT IN | 9 | 9 | 9 | 2.25 | +664 | +73.8 |
| MARCH CHECK | 11 | 11 | 9 | 2.25 | +167 | +18.5 |
| RANDOM MOVE BY FIGURES | 14 | 14 | 9 | 2.25 | +151 | +16.8 |
| SHOTS IN THE MOVE | 89 | 83 | 9 | 2.25 | +146 | +16.2 |
| NEXT OBJECTIVE NEARER | 38 | 38 | 8 | 2.00 | +109 | +13.7 |
| FOUR ROUNDS | 19 | 19 | 7 | 1.75 | +469 | +66.9 |
| MOVE TO CHARGE COMPUTED | 11 | 11 | 7 | 1.75 | +290 | +41.5 |
| CANNON PLANNED TARGET | 17 | 17 | 6 | 1.50 | +0 | +0.0 |
| FEATURE BUFFS | 19 | 19 | 6 | 1.50 | +101 | +16.8 |
| REDIRECT COUNTER | 13 | 11 | 6 | 1.50 | +284 | +47.4 |
| CANNON SIGHT KEPT | 5 | 5 | 5 | 1.25 | +0 | +0.0 |
| CAST JOB | 12 | 12 | 4 | 1.00 | +6 | +1.6 |
| COVER ONCE | 42 | 38 | 4 | 1.00 | +31 | +7.6 |
| FOLLOW UP WEIGHED | 4 | 4 | 4 | 1.00 | +1079 | +269.8 |
| NEARER NOT NEEDED | 44 | 44 | 4 | 1.00 | +87 | +21.9 |
| ONE OBJECTIVE FORMULA | 45 | 39 | 4 | 1.00 | +130 | +32.5 |
| RISK BY HIS FIGURE | 90 | 90 | 4 | 1.00 | +91 | +22.8 |
| SHOOTS FROM THE BEST SPOT | 9 | 9 | 4 | 1.00 | +35 | +8.7 |
| ADVANCE LANE KEPT | 3 | 3 | 3 | 0.75 | +0 | +0.0 |
| CASTING BLOCK | 4 | 4 | 3 | 0.75 | +75 | +25.1 |
| CHARGE LOSSES | 54 | 54 | 3 | 0.75 | +103 | +34.3 |
| COMBAT PIVOT | 3 | 3 | 3 | 0.75 | +0 | +0.0 |
| HOLDS AMBUSHERS | 3 | 3 | 3 | 0.75 | +0 | +0.0 |
| LANE BY FIGURES | 3 | 3 | 3 | 0.75 | +84 | +28.0 |
| MANOEUVRE | 9 | 9 | 3 | 0.75 | +21 | +7.1 |
| NEXT CHARGE BY LIST | 25 | 25 | 3 | 0.75 | +52 | +17.3 |
| OVERRUNS AWAY | 5 | 5 | 3 | 0.75 | +122 | +40.7 |
| STUCK PIVOT | 3 | 3 | 3 | 0.75 | +0 | +0.0 |
| WOUNDS ON THE RANKS | 11 | 11 | 3 | 0.75 | +24 | +8.1 |
| AFTERMATH IN POINTS | 2 | 2 | 2 | 0.50 | +471 | +235.6 |
| BEST PRIZE | 2 | 2 | 2 | 0.50 | -541 | -270.3 |
| HOLDER AT DEPLOYMENT | 4 | 4 | 2 | 0.50 | +58 | +29.1 |
| MARCH BY THE SUM | 2 | 2 | 2 | 0.50 | +76 | +37.8 |
| MAX FOR POSITIONING | 19 | 18 | 2 | 0.50 | +22 | +11.0 |
| OFF BEST | 2 | 2 | 2 | 0.50 | -38 | -19.0 |
| RISK BY ARC | 9 | 9 | 2 | 0.50 | +289 | +144.6 |
| SCOUT WAITS | 2 | 2 | 2 | 0.50 | +0 | +0.0 |
| STAY WORTH | 100 | 94 | 2 | 0.50 | +61 | +30.7 |
| SURE REACH TOGETHER | 2 | 2 | 2 | 0.50 | +0 | +0.0 |
| TIED UP BY THE SUM | 2 | 2 | 2 | 0.50 | +71 | +35.3 |
| WAR ENGINE JOBS | 7 | 7 | 2 | 0.50 | -126 | -63.0 |
| WHO HITS BACK | 2 | 2 | 2 | 0.50 | +791 | +395.6 |
| CHAFF IN THE MOVE | 1 | 1 | 1 | 0.25 | +0 | +0.0 |
| CHAFF PASSED | 1 | 1 | 1 | 0.25 | -2 | -2.0 |
| CHARGE NOT DECLARED | 1 | 1 | 1 | 0.25 | -64 | -64.0 |
| EDGE GIVE GROUND | 1 | 1 | 1 | 0.25 | +20 | +19.9 |
| HIS MOVE AND SHOT | 9 | 9 | 1 | 0.25 | +1 | +1.4 |
| HIS TURN DENIED | 10 | 10 | 1 | 0.25 | +3 | +3.4 |
| HONEST WORTH | 14 | 14 | 1 | 0.25 | +24 | +24.1 |
| MISSILES NEXT TURN | 50 | 44 | 1 | 0.25 | +34 | +33.8 |
| MOVES UNITS SPELL | 1 | 1 | 1 | 0.25 | +55 | +55.1 |
| ONE FIGHT FORMULA | 28 | 19 | 1 | 0.25 | +0 | +0.0 |
| OPENS UP | 2 | 2 | 1 | 0.25 | +24 | +24.2 |
| QUARTER ODDS | 12 | 12 | 1 | 0.25 | +240 | +239.5 |
| REDIRECT WEIGHED | 1 | 1 | 1 | 0.25 | +0 | +0.0 |
| RESERVE FALL BACK | 1 | 1 | 1 | 0.25 | +96 | +95.7 |
| WHOLE FIGHT | 2 | 2 | 1 | 0.25 | +65 | +65.1 |
| BLOWS WHERE AIMED | 1 | 1 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 2 | 2 | 0 | 0.00 | - | - |
| CARRIES OUT COUNTER | 1 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 8 | trace | - | - | - | - |
| CATCH FLIERS | 2 | not checked | - | - | - | - |
| CHARGE NOW FIRST | 10 | 10 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 10 | not checked | - | - | - | - |
| DEFENSIVE FLOOR | 2 | 2 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 15 | 15 | 0 | 0.00 | - | - |
| FIGHT LIFT | 1 | not checked | - | - | - | - |
| FIGHT TO THE END | 6 | 6 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 26 | not checked | - | - | - | - |
| FRIEND SHOOTS FIRST | 2 | 2 | 0 | 0.00 | - | - |
| GIVES UP | 2 | 2 | 0 | 0.00 | - | - |
| GROUND FLIERS | 1 | not checked | - | - | - | - |
| GUN FIGURES | 19 | not checked | - | - | - | - |
| HE SHOOTS OR CHARGES | 17 | 17 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 6 | 6 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 14 | 14 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 18 | 18 | 0 | 0.00 | - | - |
| HOLD ODDS | 42 | 42 | 0 | 0.00 | - | - |
| LONG SHOT | 2 | 2 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 3 | 3 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 2 | 1 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 17 | trace | - | - | - | - |
| MOVE SPELL SPOT | 5 | not checked | - | - | - | - |
| NO DOUBLE ROUNDS | 14 | 14 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 6 | not checked | - | - | - | - |
| ONE CHARGE A CHARGER | 16 | 16 | 0 | 0.00 | - | - |
| OPENS A LANE | 1 | not checked | - | - | - | - |
| PLAN RESULT | 312 | trace | - | - | - | - |
| REDIRECT BY WHAT IT STOPS | 2 | 2 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 1 | 1 | 0 | 0.00 | - | - |
| RUN DOWN | 10 | 10 | 0 | 0.00 | - | - |
| SCOUT SPOT | 2 | 2 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 3 | 3 | 0 | 0.00 | - | - |
| SET-UP ANY TARGET | 3 | not checked | - | - | - | - |
| SHOT OR CHARGE | 3 | 3 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 3 | not checked | - | - | - | - |
| SPELL WORTH | 17 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 1 | 1 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 4 | 4 | 0 | 0.00 | - | - |
| STANDS STILL | 104 | 104 | 0 | 0.00 | - | - |
| SUPPORT NARROWED | 4 | 4 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 29 | not checked | - | - | - | - |
| THE PROMISE ADDS | 1 | 1 | 0 | 0.00 | - | - |
| THE PROMISED MOVE | 6 | not checked | - | - | - | - |
| WAITS AGAIN | 8 | 8 | 0 | 0.00 | - | - |
| WAR ENGINE CHARGES | 1 | 1 | 0 | 0.00 | - | - |
| WIDER SPREAD | 12 | 12 | 0 | 0.00 | - | - |

### Off best figure: h4-opp-bbe8617-p1

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| HOLDER ASSIGNMENT | rule | - | 3.25 | 12.4 |
| PATHS CROSS | rule | 0.75 | 0.25 | 11.5 |
| BEST PRIZE | rule | - | 0.50 | 270.3 |
| WAR ENGINE JOBS | rule | 0.25 | 0.25 | 63.0 |
| CHAFF PASSED | rule | 0.25 | - | 2.0 |
| CHARGE NOT DECLARED | rule | - | 0.25 | 64.0 |
| JOB FIRST | gate | 0.25 | - | 0.8 |
| NO REASON | gate | - | 0.25 | 37.2 |

### Plans: h4-opp-bbe8617-p1

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 0.8 | 100% | 128 | 127 | 99% |
| Mine | move | 26.5 | 96% | 1430 | 0 | 0% |
| Mine | shoot | 6.5 | 27% | 245 | 155 | 63% |
| Mine | support | 0.5 | 50% | 0 | 0 | - |
| Opponent | charge | 2.8 | 36% | 374 | 162 | 43% |
| Opponent | move | 35.2 | 96% | 1898 | 0 | 0% |
| Opponent | shoot | 5.8 | 48% | 263 | 130 | 49% |

### Battle groups: h4-opp-bbe8617-p1

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 1.8 | 29% | 100% | 0% | - | 0% | 0% | 0% | 100% | 0% |
| Opponent | REDIRECT COUNTER | 1.5 | 17% | 100% | 100% | 100% | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: h4-opp-bbe8617-p1

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 3 | 0 (3) | 0 | 0 | 79 | 67% | 2.0 | - | 0 (2) | 0 (1) | 0 (3) | - |
| Mine | Character | 16 | 16 (16) | 16 | 0 | 11 | 12% | 2.2 | - | 18 (7) | 15 (8) | 11 (12) | 40 (3) |
| Mine | Clean-up | 3 | 0 (3) | 0 | 0 | 0 | 100% | - | 0 (1) | - | 0 (2) | 0 (2) | 0 (1) |
| Mine | Fast Hammer | 2 | 0 (2) | 0 | 0 | 50 | 100% | - | - | - | 0 (2) | 0 (2) | - |
| Mine | Hammer | 8 | 31 (8) | 10 | 21 | 21 | 25% | 3.2 | - | 56 (2) | 22 (6) | 37 (7) | 0 (1) |
| Mine | Holder | 5 | 215 (5) | 92 | 122 | 0 | 60% | 2.5 | - | 261 (4) | 0 (1) | 208 (3) | 224 (2) |
| Mine | Shooter | 2 | 258 (2) | 50 | 208 | 0 | 0% | 2.0 | 192 (1) | 323 (1) | - | 258 (2) | - |
| Mine | War machine | 4 | 0 (4) | 0 | 0 | 58 | 0% | 1.2 | - | - | 0 (4) | 0 (2) | 0 (2) |
| Mine | Wizard | 5 | 0 (5) | 0 | 0 | 24 | 0% | 2.0 | - | 0 (1) | 0 (3) | 0 (3) | 0 (1) |
| Opponent | Chaff | 4 | 0 (4) | 0 | 0 | 63 | 50% | 3.5 | 0 (2) | 0 (1) | 0 (1) | 0 (3) | 0 (1) |
| Opponent | Character | 9 | 47 (9) | 47 | 0 | 30 | 33% | 2.7 | 42 (1) | 74 (4) | 0 (3) | 124 (2) | 13 (6) |
| Opponent | Clean-up | 5 | 246 (5) | 0 | 246 | 0 | 100% | - | 632 (1) | 258 (3) | 156 (1) | 312 (4) | 0 (1) |
| Opponent | Hammer | 11 | 15 (11) | 10 | 5 | 14 | 27% | 2.2 | 0 (1) | 13 (8) | 29 (2) | 14 (5) | 15 (6) |
| Opponent | Holder | 6 | 145 (6) | 0 | 145 | 0 | 67% | 5.0 | 148 (2) | 104 (3) | 275 (1) | 149 (5) | 125 (1) |
| Opponent | Shooter | 3 | 0 (3) | 0 | 0 | 33 | 33% | 4.0 | - | 0 (1) | 0 (2) | 0 (1) | 0 (2) |
| Opponent | War machine | 4 | 0 (4) | 0 | 0 | 76 | 0% | 2.5 | - | - | 0 (4) | - | 0 (4) |
| Opponent | Wizard | 1 | 0 (1) | 0 | 0 | 0 | 0% | 3.0 | - | 0 (1) | - | - | 0 (1) |

### Charged fights: h4-opp-bbe8617-p1

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 3 | 96 | 113 | 0.3 | 1.0 | 340 | 0 | +340 | 0 of 1 | 1 of 1 | - | +340 |
| Mine | Chaos Dwarfs | 1 | 0 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 1 of 1 | 1 of 1 | - | +0 |
| **Mine** | all armies | 4 | 72 | 85 | 0.5 | 1.0 | 170 | 0 | +170 | 1 of 2 | 2 of 2 | - | +170 |
| Opponent | Chaos Dwarfs | 3 | 47 | 188 | 3.0 | 1.0 | 63 | 0 | +63 | 7 of 9 | 3 of 9 | - | +63 |
| Opponent | Skaven | 1 | 0 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 1 of 1 | 0 of 1 | - | +0 |
| **Opponent** | all armies | 4 | 35 | 141 | 2.5 | 1.0 | 56 | 0 | +56 | 8 of 10 | 3 of 10 | - | +56 |

### Effective charges: h4-opp-bbe8617-p1

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 1 | 0 | 0 | 1 (net +340) | 0 | 0 | 0 | 0 | 100% (1 of 1) |
| Mine | Chaos Dwarfs | 1 | 0 | 0 | 0 | 1 (net +0) | 0 | 0 | 0 | 0% (0 of 1) |
| Opponent | Chaos Dwarfs | 9 | 4 (net +84) | 0 | 1 (net +0) | 1 (net +0) | 0 | 2 (net +115) | 1 | 12% (1 of 8) |
| Opponent | Skaven | 1 | 1 (net +0) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 1) |

### Charged fights, damage counted: h4-opp-bbe8617-p1

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Effective (55-75%) | 1 | 65 | 230 | +340 | 340 | 5 | +335 | +514.7 |
| Mine | 76-89% | 1 | 310 | 480 | +0 | 137 | 0 | +137 | +44.2 |
| Mine | All fights | 2 | 188 | 355 | +170 | 239 | 3 | +236 | +125.8 |
| Opponent | Long shot (under 50%) | 5 | 202 | 260 | +67 | 67 | 107 | -40 | -19.9 |
| Opponent | Effective (55-75%) | 1 | 339 | 314 | +0 | 26 | 48 | -22 | -6.6 |
| Opponent | 76-89% | 1 | 339 | 170 | +0 | 113 | 48 | +65 | +19.1 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 239 | 270 | +115 | 115 | 134 | -19 | -7.9 |
| Opponent | No odds | 1 | 480 | 310 | +0 | 0 | 44 | -44 | -9.2 |
| Opponent | All fights | 10 | 264 | 263 | +56 | 70 | 94 | -24 | -9.1 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| h4-opp-bbe8617-p1 | move | 15 | 7 (47%) | 3 (20%) | 1 (7%) | 7 (47%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0103, L0120 |
| Periapt of Soul Exchange | Opponent | L0120 |
| Ring of Doom | Mine | L0204 |

# Doctrine scorecard: h4-smoke-bbe8617

### Scorecard: h4-smoke-bbe8617

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0103 | 1 | 1 | Mine | no | 4 | - | 0 | 3 | 0 | 0 | 0 | 0 |
| L0103 | 1 | 1 | Opponent | no | 0 | 5 | 0 | 0 | 0 | 0 | 0 | 590 |
| **Average** | | | Mine | 0% | 4.0 | - | 0.0 | 3.0 | 0.0 | 0.0 | 0.0 | 0.0 |
| **Average** | | | Opponent | 0% | 0.0 | 5.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 590.0 |

### KPIs: h4-smoke-bbe8617

Rules off - Opponent only: HOLDER ASSIGNMENT, QUARTER ODDS.

Morten 2026-11-10; 1 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | - | 67% (2 of 3) | 67% (2 of 3) |
| Winner chose to follow up after the loser gave ground |  | - | - | - |
| Winner chose to pursue after the loser fell back in good order |  | - | - | - |
| Winner chose to pursue after the loser fled |  | - | - | - |
| Winner chose to follow up or pursue (all three) |  | - | - | - |
| Magic missiles tried each own turn | 50%+ | 43% (13 of 30) | 42% (5 of 12) | 43% (18 of 42) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 43% (13 of 30) | 50% (5 of 10) | 45% (18 of 40) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | - | - |
| Points that never fought | lower | 58% (1098 of 1900) | 84% (1689 of 1999) | 71% (2787 of 3899) |
|   infantry points that never fought | lower | 64% (579 of 901) | 100% (500 of 500) | 77% (1079 of 1401) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 60% (3 of 5) | 62% (5 of 8) | 62% (8 of 13) |
| Bound items with a magic missile used (at least once a game) |  | 100% (1 of 1); 4.0 uses a game | 0.0 uses a game | 100% (1 of 1); 2.0 uses a game |
| Bound items with another spell used |  | 100% (1 of 1); 4.0 uses a game | 0.0 uses a game | 100% (1 of 1); 2.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 100% (1 of 1); 1.0 uses a game | 100% (1 of 1); 1.0 uses a game | 100% (2 of 2); 1.0 uses a game |
|   their share of the points of units over 100 pts | lower | 52% (702 of 1359) | 55% (909 of 1643) | 54% (1611 of 3002) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 13.0 (76%) | 4.0 (57%) | 17.0 (71%) |
| MARCHED: its unit marched | 4.0 (24%) | 1.0 (14%) | 5.0 (21%) |
| GONE: slain | 0.0 (0%) | 2.0 (29%) | 2.0 (8%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 12.0 | 1.0 | 7.0 | 18.0 | 1.0 |
| not cast | 0.0 | 5.0 | 5.0 | 24.0 | 35.0 |
| NO TARGET: no enemy in range, sight and arc it may target | - | 3.0 (60%) | 0.0 (0%) | 17.0 (71%) | 0.0 (0%) |
| MARCHED: its unit marched | - | 0.0 (0%) | 0.0 (0%) | 5.0 (21%) | 0.0 (0%) |
| GONE: slain | - | 0.0 (0%) | 0.0 (0%) | 2.0 (8%) | 1.0 (3%) |
| HELD BACK: the computer weighed it and chose not to cast it | - | 2.0 (40%) | 5.0 (100%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | - | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 34.0 (97%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 11.0 a game | 0.0 a game | 5.5 a game |
| stood (cast and not dispelled) | 82% (9 of 11) | - | 82% (9 of 11) |
| the unit moved after it | 33% (3 of 9) | - | 33% (3 of 9) |
| it charged on its next turn | 0% (0 of 9) | - | 0% (0 of 9) |
| the enemy charged it first | 22% (2 of 9) | - | 22% (2 of 9) |
| it fought by the end of its next turn | 22% (2 of 9) | - | 22% (2 of 9) |
| it moved out of a charge the enemy had planned (not charged first) | 11% (1 of 9) | - | 11% (1 of 9) |
| none of these (no charge, no fight, no charge escaped) | 67% (6 of 9) | - | 67% (6 of 9) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 33% (4 of 12) | 65% (22 of 34) | 57% (26 of 46) |
|   chariot | - | 27% (3 of 11) | 27% (3 of 11) |
|   infantry | 33% (4 of 12) | - | 33% (4 of 12) |
|   war machine | - | 83% (19 of 23) | 83% (19 of 23) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 6.0 (75%) | 3.0 (25%) | 9.0 (45%) |
| CHARGED: it charged | 0.0 (0%) | 1.0 (8%) | 1.0 (5%) |
| NO TARGET IN RANGE | 2.0 (25%) | 1.0 (8%) | 3.0 (15%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.0 (0%) | 3.0 (25%) | 3.0 (15%) |
| OTHER BAR | 0.0 (0%) | 4.0 (33%) | 4.0 (20%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| chariot | 3.0 | 5.0 | 33% | 18.3 pts | 55 pts |
| infantry | 4.0 | 0.0 | 100% | 0.0 pts | 0 pts |
| war machine | 19.0 | 19.0 | 79% | 7.9 pts | 150 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 0.0 | 2.0 | 1.0 |
| Charges that made contact a game | 0.0 | 1.0 | 0.5 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | - | 0.00 declared, 0.00 contact (2 units) | 0.00 declared, 0.00 contact (2 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | - | - |
|   per unit a game, the other units (no war machines, no joined characters) | 0.00 declared, 0.00 contact (5 units) | 0.40 declared, 0.20 contact (5 units) | 0.20 declared, 0.10 contact (10 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Character in a unit | 100% (2 of 2) | 50% (1 of 2) | - | 75% (3 of 4) |
| Chariot | - | 50% (1 of 2) | - | 50% (1 of 2) |
| Infantry | - | 33% (1 of 3) | - | 33% (1 of 3) |
| War Machines | 67% (2 of 3) | 100% (1 of 1) | - | 75% (3 of 4) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 1 | - | 43% (13 of 30) | 58% | 60% (3 of 5) | 100% (1 of 1); 4.0 uses a game | 100% (1 of 1); 4.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Chaos Dwarfs | 1 | - | 42% (5 of 12) | 84% | 62% (5 of 8) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |

Flank and rear charges a unit could have turned to face (h4-smoke-bbe8617, 1 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 0% (0) | - | 0% (0) |
| ...free all their last turn and able to turn (per game) | 0.00 | 0.00 | 0.00 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.00 | 0.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: h4-smoke-bbe8617

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 0.0 | 0.0 |
| Strategy | Charge objectives carried out (made contact) | - | 0% (0 of 1) |
| Strategy | Shoot objectives carried out (shot that target) | 0% (0 of 2) | 63% (17 of 27) |
| Strategy | Support requests answered (helper made contact too) | - | 100% (1 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | 100% (1 of 1) | - |
| Strategy | Joined characters whose unit fought | 60% (3 of 5) | 0% (0 of 1) |
| Strategy | Lone characters that fought | 0% (0 of 1) | 0% (0 of 2) |
| Movement | Charges halted short of contact | 0.0 | 1.0 |
| Movement | Idle units | 3.0 | 0.0 |
| Movement | Points that never moved of their own | 0.0 | 590.0 |
| Movement | Fights charged into per game | 0.0 | 1.0 |
| Shooting | Shots by shooting units (incl. breath weapons) | 4.0 | 3.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 75% (3 of 4) | 0% (0 of 3) |
| Shooting | Points destroyed by shooting units | 0.0 | 55.0 |
| Shooting | War machine shots | - | 19.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | - | 89% (17 of 19) |
| Shooting | Points destroyed by war machines | 0.0 | 95.0 |
| Magic | Magic missiles cast | 11.0 | 3.0 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 45% (5 of 11) | 100% (3 of 3) |
| Magic | Wounds caused by magic missiles | 14.0 | 8.0 |
| Magic | Wounds caused by other spells | 5.0 | - |
| Magic | Points destroyed by magic (all spells) | 225.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 7.0 / 1.0 / 1.0 / 0.0 | 0.0 / 0.0 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 310.0 | 0.0 |
| Combat | Points run down | 0.0 | 0.0 |
| Combat | Net points per charged fight, damage counted | - | -310 |
| Combat | Net per 100 charger points, damage counted | - | -100.0 |
| Combat | First round won (charged fights) | - | 0% |
| Combat | Net points per charged fight | - | -310 |
| Combat | Net points per supported fight / lone fight | - / - | - / -310 |
| Combat | Charged fights on a top-3 enemy unit | - | 1 of 1 |
| Game | Points lost | 150.0 | 535.0 |
| Game | VP from objectives | 1100.0 | 760.0 |
| Game | Lone holders (player turns) | 4.0 | 0.0 |

- Mine won / drew / lost: 1 / 0 / 0 of 1 ended games (of 1); mean margin (Mine - Opponent) +566 VP
- The side that went first won 1 of 1 games with a winner
- Points traded per game (both sides' losses): 685
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: h4-smoke-bbe8617

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | - | - | - | - | 2.0 | +0.0 | 0.0 | 0.0 |
| ALREADY CARRIED | 5.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARTILLERY RE-ROLL WEIGHED | - | - | - | - | 8.0 | +0.0 | 0.0 | 140.0 |
| CANNON PLAN MISSED | - | - | - | - | 3.0 | +0.0 | 110.0 | 0.0 |
| CANNON PLANNED TARGET | - | - | - | - | 18.0 | +1324.8 | 165.0 | 140.0 |
| CANNON SIGHT KEPT | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| CAST JOB | - | - | - | - | 3.0 | +162.2 | 0.0 | 85.0 |
| CASTING BLOCK | 2.0 | +39.3 | 0.0 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | 9.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | 1.0 | +55.0 | 0.0 | 55.0 | - | - | - | - |
| CHARGE LOSSES | 8.0 | -940.1 | 0.0 | 0.0 | 6.0 | -48.6 | 0.0 | 310.0 |
| CONVEYANCE SEARCH | 9.0 | +1280.3 | 0.0 | 0.0 | - | - | - | - |
| COVER ONCE | - | - | - | - | 10.0 | -362.3 | 0.0 | 310.0 |
| DEPLOY BY FIGURES | 5.0 | +65.0 | 0.0 | 0.0 | 10.0 | -45.4 | 0.0 | 0.0 |
| ENGINEER BY LORE | - | - | - | - | 2.0 | +0.0 | 0.0 | 0.0 |
| FALL BACK GOOD ORDER | - | - | - | - | 1.0 | +3.4 | 0.0 | 0.0 |
| FALLS SHORT | 20.0 | +520.2 | 0.0 | 0.0 | - | - | - | - |
| FEATURE BUFFS | 6.0 | +157.4 | 0.0 | 0.0 | - | - | - | - |
| FIRE IN ORDER | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| FIVE ACTION | 30.0 | +2904.9 | 0.0 | 55.0 | 56.0 | +3427.2 | 275.0 | 535.0 |
| FLANK NOT WEIGHED | 1.0 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 310.0 |
| FOUR ROUNDS | - | - | - | - | 1.0 | -7.5 | 0.0 | 0.0 |
| GUN FIGURES | - | - | - | - | 2.0 | +5.7 | 55.0 | 0.0 |
| HARD STAY DROPPED | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| HE SHOOTS OR CHARGES | - | - | - | - | 2.0 | +0.0 | 0.0 | 310.0 |
| HIS CHARGE LIST | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 3.0 | -50.0 | 0.0 | 55.0 | - | - | - | - |
| HIS SHOT LIST | 26.0 | +1513.5 | 0.0 | 0.0 | 13.0 | +215.9 | 0.0 | 0.0 |
| HIS TURN DENIED | - | - | - | - | 1.0 | +4.4 | 0.0 | 0.0 |
| HOLD ODDS | 7.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HOLDER ASSIGNMENT | 19.0 | +2468.0 | 0.0 | 0.0 | - | - | - | - |
| HOLDER AT DEPLOYMENT | - | - | - | - | 1.0 | +234.0 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| IDLE COST | 5.0 | -97.5 | 0.0 | 55.0 | - | - | - | - |
| KEEP FALLS | - | - | - | - | 1.0 | +1.5 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 5.0 | +0.0 | 310.0 | 110.0 | - | - | - | - |
| LONE WIZARD KEPT IN | 3.0 | +320.0 | 0.0 | 0.0 | - | - | - | - |
| MANOEUVRE | 2.0 | +109.2 | 0.0 | 0.0 | 1.0 | +15.1 | 0.0 | 0.0 |
| MARCH BY THE SUM | 1.0 | +39.8 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | 1.0 | +44.4 | 0.0 | 0.0 | - | - | - | - |
| MAX FOR POSITIONING | - | - | - | - | 2.0 | +8.5 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 8.0 | +444.5 | 0.0 | 0.0 | 5.0 | +187.8 | 0.0 | 85.0 |
| MISSILES NEXT TURN | 9.0 | +343.1 | 0.0 | 0.0 | 7.0 | +75.6 | 0.0 | 85.0 |
| MOVE SPELL OUT OF RANGE | 10.0 | -229.7 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL SPOT | 2.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NEARER NOT NEEDED | 10.0 | +634.7 | 0.0 | 0.0 | 7.0 | +507.0 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 1.0 | -40.2 | 0.0 | 55.0 | - | - | - | - |
| NEXT OBJECTIVE NEARER | - | - | - | - | 15.0 | -1276.5 | 55.0 | 0.0 |
| NO DOUBLE ROUNDS | - | - | - | - | 1.0 | -10.4 | 0.0 | 0.0 |
| NOT WORTH A CAST | 2.0 | -3.4 | 0.0 | 0.0 | - | - | - | - |
| ONE CHARGE A CHARGER | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 1.0 | -23.4 | 0.0 | 0.0 | - | - | - | - |
| ONE OBJECTIVE FORMULA | 7.0 | +480.0 | 0.0 | 0.0 | 5.0 | +180.6 | 0.0 | 0.0 |
| ONE TARGET A SHOOTER | 13.0 | +240.1 | 0.0 | 55.0 | 11.0 | +143.7 | 0.0 | 310.0 |
| PATHS CROSS | 5.0 | +111.8 | 0.0 | 0.0 | 5.0 | +549.4 | 0.0 | 0.0 |
| PLAN RESULT | 26.0 | +0.0 | 0.0 | 110.0 | 49.0 | +1230.8 | 110.0 | 1070.0 |
| QUARTER ODDS | 6.0 | +1197.7 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | - | - | - | - | 1.0 | -2.5 | 0.0 | 0.0 |
| RISK BY HIS FIGURE | 1.0 | -173.7 | 0.0 | 0.0 | 8.0 | -31.0 | 0.0 | 310.0 |
| RUN DOWN | - | - | - | - | 1.0 | -4.5 | 0.0 | 0.0 |
| SCOUT SPOT | 1.0 | +2.7 | 0.0 | 0.0 | - | - | - | - |
| SCOUT WAITS | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SCREEN BY WHAT IT SAVES | 1.0 | -167.2 | 0.0 | 55.0 | - | - | - | - |
| SEARCH SPOT | 8.0 | +516.1 | 0.0 | 0.0 | 4.0 | +533.0 | 0.0 | 0.0 |
| SET-UP ANY TARGET | 2.0 | +347.0 | 0.0 | 0.0 | - | - | - | - |
| SHOOTS FROM THE BEST SPOT | - | - | - | - | 4.0 | +47.4 | 55.0 | 0.0 |
| SHOT RISK POINTS | 10.0 | +135.5 | 0.0 | 55.0 | 6.0 | -48.6 | 0.0 | 310.0 |
| SHOTS IN THE MOVE | 4.0 | +38.9 | 0.0 | 0.0 | 27.0 | +1466.2 | 0.0 | 140.0 |
| SPELL SETS UP CHARGE | 3.0 | +509.5 | 0.0 | 0.0 | - | - | - | - |
| SPELL WORTH | 7.0 | +57.3 | 0.0 | 0.0 | - | - | - | - |
| STANDS FOR A REASON | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| STANDS STILL | 7.0 | +0.0 | 0.0 | 0.0 | 38.0 | +0.0 | 275.0 | 225.0 |
| STAY WORTH | 7.0 | +33.2 | 0.0 | 0.0 | 42.0 | +271.6 | 220.0 | 365.0 |
| SUPPORT NARROWED | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 5.0 | +0.0 | 0.0 | 0.0 | 5.0 | +0.0 | 0.0 | 0.0 |
| THE PROMISED MOVE | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| TIME ON OUR SIDE | - | - | - | - | 32.0 | +469.6 | 0.0 | 480.0 |
| WAITS AGAIN | 1.0 | +0.0 | 0.0 | 55.0 | - | - | - | - |
| WAR ENGINE JOBS | - | - | - | - | 1.0 | +0.0 | 55.0 | 0.0 |
| WIDER SPREAD | - | - | - | - | 1.0 | +10.6 | 0.0 | 0.0 |
| WOUNDS ON THE RANKS | 8.0 | +1366.1 | 0.0 | 0.0 | - | - | - | - |

### Rule changes: h4-smoke-bbe8617

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HOLDER ASSIGNMENT | 19 | 19 | 18 | 18.00 | +826 | +45.9 |
| SEARCH SPOT | 12 | 12 | 12 | 12.00 | +1049 | +87.4 |
| DEPLOY BY FIGURES | 15 | 15 | 11 | 11.00 | +482 | +43.8 |
| HIS SHOT LIST | 39 | 39 | 11 | 11.00 | +282 | +25.6 |
| PATHS CROSS | 10 | 10 | 10 | 10.00 | +661 | +66.1 |
| ARTILLERY RE-ROLL WEIGHED | 8 | 8 | 8 | 8.00 | +0 | +0.0 |
| ONE TARGET A SHOOTER | 24 | 24 | 8 | 8.00 | +33 | +4.1 |
| FIVE ACTION | 86 | 86 | 7 | 7.00 | +135 | +19.3 |
| LEGAL CHARGES ONLY | 5 | 5 | 5 | 5.00 | +0 | +0.0 |
| TIME ON OUR SIDE | 32 | 30 | 5 | 5.00 | +0 | +0.0 |
| WOUNDS ON THE RANKS | 8 | 8 | 5 | 5.00 | +259 | +51.7 |
| COVER ONCE | 10 | 8 | 3 | 3.00 | +0 | +0.0 |
| LONE WIZARD KEPT IN | 3 | 3 | 3 | 3.00 | +320 | +106.7 |
| MANOEUVRE | 3 | 3 | 3 | 3.00 | +124 | +41.4 |
| ADVANCE LANE KEPT | 2 | 2 | 2 | 2.00 | +0 | +0.0 |
| CASTING BLOCK | 2 | 2 | 2 | 2.00 | +8 | +4.2 |
| CHARGE LOSSES | 14 | 14 | 2 | 2.00 | +166 | +82.9 |
| QUARTER ODDS | 6 | 6 | 2 | 2.00 | +255 | +127.6 |
| SHOT RISK POINTS | 16 | 16 | 2 | 2.00 | +166 | +82.9 |
| CANNON SIGHT KEPT | 1 | 1 | 1 | 1.00 | +0 | +0.0 |
| CHAFF IN THE MOVE | 1 | 1 | 1 | 1.00 | +0 | +0.0 |
| FALLS SHORT | 20 | 16 | 1 | 1.00 | +6 | +5.9 |
| FIRE IN ORDER | 1 | 1 | 1 | 1.00 | +0 | +0.0 |
| HARD STAY DROPPED | 1 | 1 | 1 | 1.00 | +0 | +0.0 |
| HOLDER AT DEPLOYMENT | 1 | 1 | 1 | 1.00 | +17 | +17.1 |
| HOLDS AMBUSHERS | 1 | 1 | 1 | 1.00 | +0 | +0.0 |
| KEEP FALLS | 1 | 1 | 1 | 1.00 | +1 | +0.8 |
| MARCH BY THE SUM | 1 | 1 | 1 | 1.00 | +40 | +39.8 |
| MISSILES IN THE MOVE | 13 | 10 | 1 | 1.00 | +8 | +7.8 |
| NEARER NOT NEEDED | 17 | 17 | 1 | 1.00 | +6 | +5.9 |
| ONE OBJECTIVE FORMULA | 12 | 8 | 1 | 1.00 | +98 | +98.1 |
| SCOUT WAITS | 1 | 1 | 1 | 1.00 | +0 | +0.0 |
| SHOOTS FROM THE BEST SPOT | 4 | 4 | 1 | 1.00 | +4 | +4.3 |
| STAY WORTH | 49 | 48 | 1 | 1.00 | +8 | +8.3 |
| ALREADY CARRIED | 5 | not checked | - | - | - | - |
| CANNON PLAN MISSED | 3 | 3 | 0 | 0.00 | - | - |
| CANNON PLANNED TARGET | 18 | 18 | 0 | 0.00 | - | - |
| CAST JOB | 3 | 3 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 9 | trace | - | - | - | - |
| CONVEYANCE SEARCH | 9 | not checked | - | - | - | - |
| ENGINEER BY LORE | 2 | 2 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 1 | 1 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 6 | 6 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 4 | not checked | - | - | - | - |
| FOUR ROUNDS | 1 | 1 | 0 | 0.00 | - | - |
| GUN FIGURES | 2 | not checked | - | - | - | - |
| HE SHOOTS OR CHARGES | 2 | 2 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 1 | 1 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 3 | 3 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 1 | 1 | 0 | 0.00 | - | - |
| HOLD ODDS | 7 | 7 | 0 | 0.00 | - | - |
| IDLE COST | 5 | 3 | 0 | 0.00 | - | - |
| MARCH CHECK | 1 | 1 | 0 | 0.00 | - | - |
| MAX FOR POSITIONING | 2 | 2 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 16 | 12 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 10 | trace | - | - | - | - |
| MOVE SPELL SPOT | 2 | not checked | - | - | - | - |
| NEXT CHARGE BY LIST | 1 | 1 | 0 | 0.00 | - | - |
| NEXT OBJECTIVE NEARER | 15 | 15 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 1 | 1 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 2 | not checked | - | - | - | - |
| ONE CHARGE A CHARGER | 1 | 1 | 0 | 0.00 | - | - |
| ONE FIGHT FORMULA | 1 | not checked | - | - | - | - |
| PLAN RESULT | 75 | trace | - | - | - | - |
| RISK BY ARC | 1 | 1 | 0 | 0.00 | - | - |
| RISK BY HIS FIGURE | 9 | 9 | 0 | 0.00 | - | - |
| RUN DOWN | 1 | 1 | 0 | 0.00 | - | - |
| SCOUT SPOT | 1 | 1 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 1 | 1 | 0 | 0.00 | - | - |
| SET-UP ANY TARGET | 2 | not checked | - | - | - | - |
| SHOTS IN THE MOVE | 31 | 31 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 3 | not checked | - | - | - | - |
| SPELL WORTH | 7 | not checked | - | - | - | - |
| STANDS FOR A REASON | 1 | 1 | 0 | 0.00 | - | - |
| STANDS STILL | 45 | 45 | 0 | 0.00 | - | - |
| SUPPORT NARROWED | 1 | 1 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 10 | not checked | - | - | - | - |
| THE PROMISED MOVE | 1 | not checked | - | - | - | - |
| WAITS AGAIN | 1 | 1 | 0 | 0.00 | - | - |
| WAR ENGINE JOBS | 1 | 1 | 0 | 0.00 | - | - |
| WIDER SPREAD | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: h4-smoke-bbe8617

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| HOLDER ASSIGNMENT | rule | 3.00 | - | 7.2 |
| PATHS CROSS | rule | 1.00 | 1.00 | 30.1 |

### Plans: h4-smoke-bbe8617

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | move | 24.0 | 100% | 2490 | 0 | 0% |
| Mine | shoot | 1.0 | 0% | 38 | 0 | 0% |
| Mine | support | 1.0 | 0% | 0 | 0 | - |
| Opponent | charge | 2.0 | 0% | 82 | 0 | 0% |
| Opponent | move | 24.0 | 100% | 985 | 0 | 0% |
| Opponent | shoot | 23.0 | 65% | 1258 | 1231 | 98% |

### Deployment: positions vs output by unit type: h4-smoke-bbe8617

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Mine | Character | 5 | 25 (5) | 25 | 0 | 11 | 20% | 2.5 | - | 33 (2) | 0 (2) | 17 (4) | - |
| Mine | Hammer | 2 | 49 (2) | 49 | 0 | 0 | 50% | 5.0 | - | 0 (1) | 96 (1) | 49 (2) | - |
| Mine | Holder | 3 | 145 (3) | 0 | 145 | 0 | 33% | 5.0 | - | 211 (2) | 0 (1) | 231 (2) | 0 (1) |
| Mine | Wizard | 1 | 0 (1) | 0 | 0 | 0 | 0% | 4.0 | - | - | 0 (1) | 0 (1) | - |
| Opponent | Character | 3 | 0 (3) | 0 | 0 | 29 | 67% | 2.0 | - | 0 (1) | 0 (2) | - | 0 (3) |
| Opponent | Clean-up | 2 | 81 (2) | 0 | 81 | 0 | 100% | - | - | 81 (2) | - | 165 (1) | 0 (1) |
| Opponent | Hammer | 3 | 28 (3) | 6 | 22 | 33 | 33% | 2.0 | - | 28 (3) | - | 9 (2) | 67 (1) |
| Opponent | War machine | 4 | 16 (4) | 16 | 0 | 24 | 0% | 2.0 | - | - | 16 (4) | - | 16 (4) |

### Charged fights: h4-smoke-bbe8617

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 1 | 225 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Chaos Dwarfs | 1 | 150 | 0 | 1.0 | 1.0 | 0 | 310 | -310 | 1 of 1 | 0 of 1 | - | -310 |


### Charged fights, damage counted: h4-smoke-bbe8617

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | No odds | 1 | 310 | 322 | -310 | 0 | 310 | -310 | -100.0 |
| Opponent | All fights | 1 | 310 | 322 | -310 | 0 | 310 | -310 | -100.0 |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0103 |

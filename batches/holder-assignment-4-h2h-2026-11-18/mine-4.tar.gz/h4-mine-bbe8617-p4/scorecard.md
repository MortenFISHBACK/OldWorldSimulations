# Doctrine scorecard: h4-mine-bbe8617-p4

### Scorecard: h4-mine-bbe8617-p4

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0115 | 1 | 1 | Mine | no | 7 | - | 0 | 2 | 0 | 0 | 0 | 0 |
| L0115 | 1 | 1 | Opponent | yes | 5 | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L0132 | 6 | 1 | Mine | no | 11 | 6 | 0 | 2 | 0 | 0 | 0 | 0 |
| L0132 | 6 | 1 | Opponent | no | 3 | 3 | 4 | 3 | 0 | 0 | 0 | 340 |
| L0216 | 6 | 1 | Mine | no | 0 | - | 0 | 5 | 0 | 0 | 0 | 222 |
| L0216 | 6 | 1 | Opponent | no | 2 | 2 | 1 | 1 | 1 | 0 | 0 | 0 |
| L0232 | 4 | 1 | Mine | no | 1 | 3 | 1 | 1 | 0 | 0 | 0 | 170 |
| L0232 | 4 | 1 | Opponent | no | 0 | 2 | 2 | 1 | 0 | 0 | 0 | 170 |
| L0316 | 4 | 1 | Mine | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 230 |
| L0316 | 4 | 1 | Opponent | no | 8 | 3 | 1 | 2 | 0 | 0 | 0 | 0 |
| L0333 | 3 | 1 | Mine | yes | 6 | 4 | 1 | 0 | 0 | 0 | 0 | 110 |
| L0333 | 3 | 1 | Opponent | yes | 1 | 3 | 2 | 4 | 0 | 0 | 0 | 0 |
| L0420 | 6 | 1 | Mine | no | 6 | 2 | 2 | 0 | 0 | 0 | 0 | 0 |
| L0420 | 6 | 1 | Opponent | no | 5 | - | 0 | 1 | 1 | 0 | 0 | 485 |
| L0435 | 3 | 1 | Mine | no | 2 | 3 | 3 | 1 | 1 | 0 | 0 | 0 |
| L0435 | 3 | 1 | Opponent | no | 0 | 3 | 3 | 2 | 0 | 0 | 0 | 0 |
| L0522 | 6 | 1 | Mine | no | 2 | - | 0 | 1 | 0 | 0 | 0 | 784 |
| L0522 | 6 | 1 | Opponent | no | 1 | 2 | 4 | 2 | 1 | 0 | 0 | 0 |
| L0609 | 3 | 1 | Mine | no | 0 | - | 3 | 3 | 0 | 0 | 0 | 230 |
| L0609 | 3 | 1 | Opponent | no | 1 | - | 0 | 2 | 0 | 0 | 0 | 0 |
| L0625 | 1 | 1 | Mine | yes | 1 | 3 | 2 | 1 | 0 | 0 | 0 | 165 |
| L0625 | 1 | 1 | Opponent | no | 4 | 2 | 2 | 2 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 18% | 3.3 | 3.5 | 1.1 | 1.6 | 0.1 | 0.0 | 0.0 | 173.7 |
| **Average** | | | Opponent | 18% | 2.7 | 2.4 | 2.1 | 1.9 | 0.3 | 0.0 | 0.0 | 90.5 |

### KPIs: h4-mine-bbe8617-p4

Rules off - Opponent only: HOLDER ASSIGNMENT, QUARTER ODDS.

Morten 2026-11-10; 11 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 37% (19 of 51) | 0% (0 of 54) | 18% (19 of 105) |
| Winner chose to follow up after the loser gave ground |  | 69% (11 of 16); on the table 81% | 78% (7 of 9); on the table 89% | 72% (18 of 25); on the table 84% |
| Winner chose to pursue after the loser fell back in good order |  | 100% (2 of 2); on the table 100% | 100% (3 of 3); on the table 100% | 100% (5 of 5); on the table 100% |
| Winner chose to pursue after the loser fled |  | 60% (3 of 5); on the table 100% | 89% (8 of 9); on the table 100% | 79% (11 of 14); on the table 100% |
| Winner chose to follow up or pursue (all three) |  | 70% (16 of 23); on the table 87% | 86% (18 of 21); on the table 95% | 77% (34 of 44); on the table 91% |
| Magic missiles tried each own turn | 50%+ | 30% (39 of 132) | 21% (9 of 42) | 28% (48 of 174) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 46% (39 of 85) | 24% (9 of 38) | 39% (48 of 123) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 67% (2 of 3) | 52% (13 of 25) | 54% (15 of 28) |
| Points that never fought | lower | 53% (11455 of 21594) | 50% (11101 of 21995) | 52% (22556 of 43589) |
|   infantry points that never fought | lower | 55% (3736 of 6804) | 84% (4363 of 5211) | 67% (8099 of 12015) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 58% (47 of 81) | 48% (42 of 87) | 53% (89 of 168) |
| Bound items with a magic missile used (at least once a game) |  | 100% (6 of 6); 1.4 uses a game | 40% (2 of 5); 1.1 uses a game | 73% (8 of 11); 1.2 uses a game |
| Bound items with another spell used |  | 100% (2 of 2); 0.3 uses a game | 0.0 uses a game | 100% (2 of 2); 0.1 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 50% (4 of 8); 0.4 uses a game | 75% (3 of 4); 0.3 uses a game | 58% (7 of 12); 0.3 uses a game |
|   their share of the points of units over 100 pts | lower | 53% (8802 of 16500) | 39% (7593 of 19294) | 46% (16395 of 35794) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 2.3 (27%) | 1.6 (55%) | 3.9 (34%) |
| MARCHED: its unit marched | 1.5 (18%) | 0.5 (18%) | 2.1 (18%) |
| CHARGED: its unit charged | 0.2 (2%) | 0.0 (0%) | 0.2 (2%) |
| IN COMBAT: engaged in combat | 1.4 (16%) | 0.1 (3%) | 1.5 (13%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.5 (15%) | 0.5 (4%) |
| GONE: slain | 2.7 (32%) | 0.3 (9%) | 3.0 (26%) |
| OFF THE TABLE: off the table or not arrived | 0.2 (2%) | 0.0 (0%) | 0.2 (2%) |
| STUPIDITY: Stupidity | 0.2 (2%) | 0.0 (0%) | 0.2 (2%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 5.5 | 0.4 | 1.5 | 4.4 | 0.4 |
| not cast | 5.5 | 0.7 | 4.5 | 11.5 | 16.0 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.5 (3%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.4 (50%) | 1.0 (22%) | 3.9 (34%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.1 (18%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (2%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.2 (3%) | 0.1 (12%) | 0.6 (14%) | 1.5 (13%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.5 (4%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) |
| GONE: slain | 1.2 (22%) | 0.0 (0%) | 1.1 (24%) | 3.0 (26%) | 2.8 (18%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (0%) | 0.1 (12%) | 0.0 (0%) | 0.2 (2%) | 0.2 (1%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.0 (0%) | 0.2 (4%) | 0.2 (2%) | 0.1 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.2 (3%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 3.9 (72%) | 0.2 (25%) | 1.5 (35%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 12.3 (77%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.1 a game | 0.7 a game | 0.9 a game |
| stood (cast and not dispelled) | 58% (7 of 12) | 0% (0 of 5) | 41% (7 of 17) |
| the unit moved after it | 86% (6 of 7) | - | 86% (6 of 7) |
| it charged on its next turn | 0% (0 of 7) | - | 0% (0 of 7) |
| the enemy charged it first | 43% (3 of 7) | - | 43% (3 of 7) |
| it fought by the end of its next turn | 14% (1 of 7) | - | 14% (1 of 7) |
| it moved out of a charge the enemy had planned (not charged first) | 14% (1 of 7) | - | 14% (1 of 7) |
| none of these (no charge, no fight, no charge escaped) | 29% (2 of 7) | - | 29% (2 of 7) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 64% (186 of 290) | 50% (145 of 288) | 57% (331 of 578) |
|   cavalry | 50% (13 of 26) | 52% (32 of 61) | 52% (45 of 87) |
|   character | 82% (18 of 22) | 33% (17 of 51) | 48% (35 of 73) |
|   chariot | 60% (29 of 48) | 71% (12 of 17) | 63% (41 of 65) |
|   infantry | 56% (41 of 73) | 55% (61 of 111) | 55% (102 of 184) |
|   monster | 67% (8 of 12) | 33% (2 of 6) | 56% (10 of 18) |
|   war machine | 71% (77 of 109) | 50% (21 of 42) | 65% (98 of 151) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.2 (23%) | 3.1 (24%) | 5.3 (23%) |
| CHARGED: it charged | 0.6 (7%) | 2.1 (16%) | 2.7 (12%) |
| FLEEING: it fled or was fleeing | 0.1 (1%) | 0.3 (2%) | 0.4 (2%) |
| IN COMBAT: it fought this turn or the last | 0.5 (6%) | 0.1 (1%) | 0.6 (3%) |
| MOVED: a war machine that moved | 1.0 (11%) | 1.5 (11%) | 2.5 (11%) |
| NO TARGET IN RANGE | 2.7 (29%) | 2.5 (20%) | 5.3 (23%) |
| ONLY IN COMBAT: the only targets were in combat | 0.5 (6%) | 0.5 (4%) | 1.1 (5%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.2 (12%) | 2.5 (19%) | 3.6 (16%) |
| SHELTERED: the target was sheltered | 0.2 (2%) | 0.3 (2%) | 0.5 (2%) |
| OTHER BAR | 0.4 (4%) | 0.2 (1%) | 0.5 (2%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 4.9 | 0.7 | 85% | 6.8 pts | 33 pts |
| character | 3.2 | 0.6 | 86% | 2.6 pts | 8 pts |
| chariot | 3.7 | 2.7 | 56% | 16.2 pts | 60 pts |
| infantry | 12.7 | 3.6 | 79% | 5.7 pts | 72 pts |
| monster | 1.1 | 0.3 | 75% | 4.1 pts | 4 pts |
| war machine | 8.9 | 7.3 | 57% | 15.4 pts | 137 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 1.7 | 4.6 | 3.2 |
| Charges that made contact a game | 1.1 | 3.5 | 2.3 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.40 declared, 0.20 contact (5 units) | 0.00 declared, 0.00 contact (3 units) | 0.25 declared, 0.12 contact (8 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 1.00 declared, 1.00 contact (2 units) | 1.00 declared, 1.00 contact (2 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.21 declared, 0.14 contact (80 units) | 0.52 declared, 0.39 contact (95 units) | 0.38 declared, 0.27 contact (175 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 29% (4 of 14) | 50% (1 of 2) | 100% (1 of 1) | 35% (6 of 17) |
| Character in a unit | 86% (12 of 14) | 43% (3 of 7) | - | 71% (15 of 21) |
| Character on its own | 83% (5 of 6) | 73% (8 of 11) | 12% (2 of 16) | 45% (15 of 33) |
| Chariot | 100% (1 of 1) | 44% (4 of 9) | - | 50% (5 of 10) |
| Infantry | 40% (12 of 30) | 30% (6 of 20) | - | 36% (18 of 50) |
| Monster | 70% (7 of 10) | 100% (2 of 2) | - | 75% (9 of 12) |
| Monstrous | 100% (5 of 5) | 100% (1 of 1) | - | 100% (6 of 6) |
| War Machines | 82% (14 of 17) | 50% (1 of 2) | - | 79% (15 of 19) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 62% (8 of 13); on the table 92% | 24% (24 of 102) | 41% | 55% (12 of 22) | 100% (6 of 6); 3.8 uses a game | 100% (2 of 2); 0.8 uses a game | 67% (4 of 6); 1.0 uses a game |
| Chaos Dwarfs | 4 | 83% (5 of 6); on the table 83% | 50% (15 of 30) | 60% | 50% (16 of 32) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |
| Dwarfen Mountain Holds | 3 | 75% (3 of 4); on the table 75% | - | 59% | 70% (19 of 27) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 1 | 100% (1 of 1); on the table 100% | 17% (2 of 12) | 90% | 58% (7 of 12) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| High Elf Realms | 1 | 100% (3 of 3); on the table 100% | 0% (0 of 6) | 44% | 43% (3 of 7) | 50% (1 of 2); 6.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 2 | 100% (2 of 2); on the table 100% | - | 68% | 42% (5 of 12) | 0.0 uses a game | 0.0 uses a game | 100% (2 of 2); 1.0 uses a game |
| Skaven | 1 | 50% (1 of 2); on the table 100% | 83% (5 of 6) | 43% | 43% (3 of 7) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Tomb Kings of Khemri | 1 | - | - | 48% | 40% (2 of 5) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 1 | 100% (2 of 2); on the table 100% | 0% (0 of 6) | 48% | 50% (3 of 6) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 2 | 83% (5 of 6); on the table 100% | - | 24% | 38% (6 of 16) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 2 | 80% (4 of 5); on the table 80% | 17% (2 of 12) | 50% | 59% (13 of 22) | 33% (1 of 3); 3.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (h4-mine-bbe8617-p4, 11 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 48% (14) | 50% (3) | 49% (17) |
| ...free all their last turn and able to turn (per game) | 0.64 | 0.27 | 0.91 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.45 | 0.00 | 0.45 |
| ...with the charger already in that arc before they moved (per game) | 0.55 | 0.27 | 0.82 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.09 | 0.09 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.09 | 0.18 | 0.27 |

### Quality by phase: h4-mine-bbe8617-p4

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.2 | 2.0 |
| Strategy | Charge objectives carried out (made contact) | 44% (8 of 18) | 53% (26 of 49) |
| Strategy | Shoot objectives carried out (shot that target) | 48% (69 of 144) | 41% (27 of 66) |
| Strategy | Support requests answered (helper made contact too) | - | 20% (1 of 5) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (4 of 4) | 100% (3 of 3) |
| Strategy | Hexes on a unit its side charged or shot that turn | - | 33% (1 of 3) |
| Strategy | Joined characters whose unit fought | 50% (12 of 24) | 23% (3 of 13) |
| Strategy | Lone characters that fought | 52% (12 of 23) | 67% (16 of 24) |
| Movement | Charges halted short of contact | 0.1 | 0.2 |
| Movement | Idle units | 1.6 | 1.9 |
| Movement | Points that never moved of their own | 173.7 | 90.5 |
| Movement | Fights charged into per game | 1.1 | 3.3 |
| Movement | Charges with odds: long shots (under 50%) | 1 of 11, net -339 | 9 of 35, net +100 |
| Movement | Charges with odds: sweet spot (55-75%) | 1 of 11, net +0 | 12 of 35, net +128 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 11 | 6 of 35, net +38 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 7 of 11, net +36 | 3 of 35, net +193 |
| Shooting | Shots by shooting units (incl. breath weapons) | 10.3 | 12.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 53% (60 of 113) | 41% (58 of 140) |
| Shooting | Points destroyed by shooting units | 40.7 | 5.5 |
| Shooting | War machine shots | 7.0 | 1.9 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 39% (30 of 77) | 29% (6 of 21) |
| Shooting | Points destroyed by war machines | 39.0 | 39.3 |
| Magic | Magic missiles cast | 1.5 | 0.7 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 38% (6 of 16) | 25% (2 of 8) |
| Magic | Wounds caused by magic missiles | 5.1 | 0.9 |
| Magic | Wounds caused by other spells | 0.2 | 0.4 |
| Magic | Points destroyed by magic (all spells) | 46.3 | 5.5 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.5 / 0.0 / 0.2 / 0.0 | 2.7 / 0.3 / 0.2 / 0.0 |
| Combat | Points destroyed in combat | 112.5 | 353.3 |
| Combat | Points run down | 0.0 | 74.4 |
| Combat | Net points per charged fight, damage counted | +64 | +91 |
| Combat | Net per 100 charger points, damage counted | +27.9 | +25.9 |
| Combat | First round won (charged fights) | 75% | 69% |
| Combat | Net points per charged fight | +41 | +105 |
| Combat | Net points per supported fight / lone fight | - / +41 | -13 / +116 |
| Combat | Charged fights on a top-3 enemy unit | 5 of 12 | 13 of 36 |
| Game | Points lost | 559.5 | 317.3 |
| Game | VP from objectives | 669.1 | 794.5 |
| Game | Lone holders (player turns) | 3.3 | 2.7 |

- Mine won / drew / lost: 1 / 4 / 6 of 11 ended games (of 11); mean margin (Mine - Opponent) -333 VP
- The side that went first won 4 of 7 games with a winner
- Points traded per game (both sides' losses): 877
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: h4-mine-bbe8617-p4

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.5 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.5 | +93.0 | 0.0 | 0.0 | 0.2 | +21.6 | 0.0 | 0.0 |
| ALREADY CARRIED | 0.1 | +0.0 | 33.8 | 11.8 | - | - | - | - |
| ARTILLERY RE-ROLL WEIGHED | 2.5 | +0.0 | 0.0 | 70.5 | 0.1 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | 0.1 | +0.3 | 0.0 | 0.0 | - | - | - | - |
| BEST PRIZE | 0.1 | -0.2 | 0.0 | 0.0 | 0.5 | -45.9 | 34.1 | 91.8 |
| BLOWS WHERE AIMED | - | - | - | - | 0.8 | -270.6 | 77.3 | 0.0 |
| CANNON PLAN MISSED | 0.7 | +0.0 | 13.6 | 0.0 | 0.5 | +0.0 | 15.9 | 0.0 |
| CANNON PLANNED TARGET | 5.6 | +69.3 | 114.5 | 135.0 | 1.7 | +42.6 | 44.3 | 0.0 |
| CANNON SIGHT KEPT | 1.6 | +0.0 | 0.0 | 10.9 | 0.7 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT COUNTER | 0.1 | +0.0 | 45.9 | 0.0 | - | - | - | - |
| CARRIES OUT SET-UP | - | - | - | - | 0.3 | -31.4 | 35.1 | 0.0 |
| CAST JOB | 0.5 | +11.7 | 57.1 | 0.0 | 0.2 | +1.2 | 0.0 | 0.0 |
| CASTER AWAY FROM SCREEN | 0.6 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.6 | +42.3 | 25.2 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | 0.6 | +0.0 | 0.0 | 32.3 | 0.2 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | - | - | - | - | 0.2 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | - | - | - | - | 1.1 | +36.7 | 0.0 | 7.5 |
| CHAFF PASSED | 0.5 | -1.1 | 0.0 | 22.4 | 0.5 | -0.1 | 10.6 | 0.0 |
| CHARACTER GUNS | 0.6 | +0.0 | 0.0 | 43.5 | 0.6 | +0.0 | 0.0 | 0.0 |
| CHARGE LOSSES | 5.8 | -133.4 | 0.0 | 127.6 | 4.7 | -195.2 | 0.0 | 87.5 |
| CHARGE NOT DECLARED | 0.2 | +0.0 | 0.0 | 0.0 | 0.8 | +0.0 | 57.1 | 0.0 |
| CHARGE NOW FIRST | 0.7 | +0.0 | 65.0 | 0.0 | 1.9 | +0.0 | 117.0 | 27.5 |
| CHARGER SLAIN LOST | 0.2 | -1.6 | 0.0 | 0.0 | 0.2 | -0.4 | 22.7 | 0.0 |
| CHEAP HELPER | - | - | - | - | 0.2 | +0.0 | 0.0 | 0.0 |
| CHEAPEST HOLDER | - | - | - | - | 0.5 | -36.5 | 46.5 | 36.2 |
| COMBAT PIVOT | 0.2 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 19.1 |
| CONVEYANCE SEARCH | 0.6 | +60.0 | 33.8 | 64.5 | 0.3 | +13.0 | 0.0 | 0.0 |
| COVER ONCE | 8.3 | -788.1 | 0.0 | 129.3 | 3.6 | -164.3 | 0.0 | 74.5 |
| DEPLOY BY FIGURES | 9.6 | +43.6 | 0.0 | 10.9 | 8.0 | +31.8 | 0.0 | 7.2 |
| EDGE GIVE GROUND | - | - | - | - | 0.3 | +13.6 | 33.6 | 9.5 |
| ENGINEER BY LORE | 0.4 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | - | - | - | - | 0.1 | +3.3 | 0.0 | 0.0 |
| FALL BACK GOOD ORDER | 1.0 | +4.9 | 36.5 | 0.0 | 3.0 | +2.6 | 215.5 | 21.7 |
| FALLBACK BY WORTH | 0.5 | +10.6 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 0.0 |
| FALLS SHORT | 3.7 | +59.3 | 0.0 | 12.1 | 24.2 | +302.5 | 0.0 | 49.2 |
| FEATURE BUFFS | 3.1 | +85.3 | 0.0 | 60.6 | 0.9 | +16.6 | 0.0 | 2.7 |
| FIGHT LIFT | - | - | - | - | 0.1 | +0.3 | 0.0 | 0.0 |
| FIGHT TO THE END | 0.6 | +40.9 | 19.1 | 0.0 | 1.9 | +72.4 | 142.5 | 9.5 |
| FIRE IN ORDER | 0.2 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| FIVE ACTION | 47.3 | +2758.0 | 471.6 | 526.9 | 51.4 | +3249.3 | 403.3 | 375.9 |
| FLANK NOT WEIGHED | 5.7 | +0.0 | 0.0 | 53.4 | 4.2 | +0.0 | 0.0 | 77.6 |
| FOLLOW UP WEIGHED | 0.5 | +168.3 | 0.0 | 0.0 | 0.7 | +66.8 | 0.0 | 0.0 |
| FOUR ROUNDS | 1.5 | +142.1 | 105.5 | 0.0 | 4.4 | +457.8 | 283.3 | 39.8 |
| FRIEND CHARGES FIRST | 0.1 | -1.6 | 0.0 | 0.0 | 0.1 | -1.8 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 0.4 | -8.5 | 0.0 | 0.0 | - | - | - | - |
| FRIENDS SHOTS CHECKED | 0.1 | +4.7 | 0.0 | 0.0 | 0.2 | +2.3 | 0.0 | 18.1 |
| GIVES UP | 0.2 | -0.4 | 0.0 | 0.0 | 0.5 | -3.2 | 25.0 | 0.0 |
| GUN FIGURES | 2.2 | +14.1 | 51.7 | 20.9 | 0.8 | +0.1 | 0.0 | 0.0 |
| GUN MASK | 0.3 | +2.9 | 0.0 | 0.0 | 0.7 | +39.3 | 0.0 | 0.0 |
| HARD STAY DROPPED | 3.1 | +0.0 | 0.0 | 5.5 | 0.7 | +0.0 | 0.0 | 0.0 |
| HE SHOOTS OR CHARGES | 2.1 | +0.0 | 0.0 | 108.3 | 2.1 | +0.0 | 0.0 | 30.2 |
| HELPER UNSEEN | - | - | - | - | 0.1 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE DENIED | 0.1 | +1.0 | 23.1 | 0.0 | 0.4 | +53.2 | 5.0 | 0.0 |
| HIS CHARGE LIST | 2.3 | +0.0 | 0.0 | 0.0 | 2.6 | +0.0 | 0.0 | 9.5 |
| HIS LEGAL MOVES | 2.9 | +0.0 | 0.0 | 44.7 | 3.1 | +0.0 | 0.0 | 50.4 |
| HIS MOVE AND SHOT | 1.5 | -23.0 | 0.0 | 51.8 | 1.6 | -91.5 | 0.0 | 55.9 |
| HIS RANDOM MOVE | 2.3 | +0.0 | 0.0 | 42.8 | 1.7 | +0.0 | 0.0 | 50.4 |
| HIS SHOT LIST | 19.8 | +690.3 | 0.0 | 268.3 | 23.6 | +1180.1 | 0.0 | 210.5 |
| HIS TURN DENIED | 0.5 | +3.5 | 0.0 | 0.0 | 2.6 | +86.1 | 218.9 | 9.5 |
| HOLD ODDS | 6.3 | +0.0 | 0.0 | 69.0 | - | - | - | - |
| HOLDER ASSIGNMENT | 13.0 | +1274.2 | 0.0 | 76.4 | - | - | - | - |
| HOLDER AT DEPLOYMENT | - | - | - | - | 1.9 | +273.0 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.5 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 1.5 | -33.4 | 123.0 | 0.0 | 4.1 | -222.1 | 283.3 | 27.5 |
| HORN WORTH | - | - | - | - | 0.1 | +1.8 | 0.0 | 45.9 |
| HUNT IN PAIRS | 0.4 | +2.4 | 0.0 | 0.0 | 0.3 | +10.0 | 0.0 | 0.0 |
| HUNT KEPT | - | - | - | - | 0.1 | +0.0 | 0.0 | 9.5 |
| HUNT RESULT | - | - | - | - | 0.1 | +0.0 | 0.0 | 0.0 |
| HUNT THE GUNS | - | - | - | - | 0.1 | +33.0 | 0.0 | 9.5 |
| IDLE COST | 2.1 | -11.6 | 0.0 | 24.5 | 11.9 | -167.0 | 0.0 | 47.2 |
| JOINT KNOWS CHALLENGE | - | - | - | - | 0.1 | -14.6 | 0.0 | 0.0 |
| KEEPS SCOUTS OR AMBUSH | 0.2 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KILLS COUNT | 0.1 | +2.0 | 17.5 | 0.0 | - | - | - | - |
| LANE BY FIGURES | 0.3 | +10.5 | 0.0 | 0.0 | 0.9 | +29.1 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 4.5 | +0.0 | 108.9 | 440.9 | 6.1 | +0.0 | 79.9 | 147.6 |
| LONE CHARACTER SAFE SPOT | - | - | - | - | 0.1 | +7.7 | 0.0 | 0.0 |
| LONE WIZARD KEPT IN | 0.9 | +59.1 | 0.0 | 0.0 | 0.6 | +44.2 | 0.0 | 0.0 |
| LONG SHOT | 0.4 | +2.1 | 23.1 | 0.0 | - | - | - | - |
| MAKE SURE TOGETHER | 0.1 | +0.2 | 0.0 | 0.0 | 0.9 | +16.1 | 0.0 | 7.3 |
| MANOEUVRE | 1.3 | +8.6 | 0.0 | 0.0 | 1.6 | +21.8 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.3 | +11.5 | 0.0 | 0.0 | - | - | - | - |
| MARCH BY THE SUM | 0.6 | +56.6 | 0.0 | 0.0 | 0.3 | +3.0 | 0.0 | 18.1 |
| MARCH CHECK | 1.1 | +72.0 | 0.0 | 0.0 | 1.1 | +42.1 | 0.0 | 18.1 |
| MARCH ODDS | 0.1 | +11.7 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 0.6 | -52.4 | 0.0 | 0.0 | 0.4 | +27.1 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 5.8 | +83.6 | 0.0 | 43.3 | 5.6 | +44.7 | 0.0 | 7.3 |
| MISSILES IN THE MOVE | 3.6 | +185.5 | 0.0 | 63.6 | 2.6 | +22.7 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 4.8 | +161.8 | 0.0 | 63.6 | 3.5 | +22.4 | 0.0 | 18.1 |
| MODEL FACING | 1.0 | +213.1 | 0.0 | 21.8 | - | - | - | - |
| MOVE SPELL IN RANGE | 0.9 | +48.7 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL NOT WORTH | - | - | - | - | 0.1 | -0.0 | 0.0 | 0.0 |
| MOVE SPELL OUT OF RANGE | 1.1 | -23.4 | 0.0 | 67.7 | - | - | - | - |
| MOVE SPELL SPOT | 0.5 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 3.3 | +372.4 | 0.0 | 18.2 | 3.5 | +534.3 | 0.0 | 25.2 |
| MOVES UNITS SPELL | 0.2 | +10.0 | 0.0 | 0.0 | 0.1 | +0.7 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 6.2 | +269.0 | 0.0 | 77.3 | 5.0 | +213.5 | 0.0 | 0.0 |
| NEEDED THERE | 0.1 | +1.9 | 17.5 | 0.0 | 0.1 | +16.8 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 4.8 | -214.4 | 28.5 | 23.6 | 5.5 | -291.3 | 5.5 | 121.1 |
| NEXT OBJECTIVE NEARER | - | - | - | - | 12.4 | -635.2 | 19.5 | 34.5 |
| NO DOUBLE ROUNDS | 1.5 | -89.0 | 105.5 | 0.0 | 3.5 | -130.0 | 202.2 | 39.8 |
| NOT TURNED | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | -4.1 | 0.0 | 0.0 |
| NOT WORTH A CAST | 0.2 | -0.1 | 0.0 | 0.0 | 0.7 | -0.8 | 0.0 | 0.0 |
| OFF BEST | 0.2 | -8.5 | 0.0 | 0.0 | 1.0 | -18.3 | 0.0 | 0.0 |
| ONE CHARGE A CHARGER | 3.1 | +0.0 | 0.0 | 72.1 | 2.9 | +0.0 | 0.0 | 21.4 |
| ONE FIGHT FORMULA | 5.5 | -63.3 | 0.0 | 33.1 | 5.1 | -137.4 | 0.0 | 50.4 |
| ONE OBJECTIVE FORMULA | 5.1 | +49.8 | 0.0 | 54.6 | 3.4 | +70.4 | 0.0 | 0.0 |
| ONE TARGET A SHOOTER | 11.8 | +250.8 | 0.0 | 81.6 | 20.5 | +546.1 | 0.0 | 198.5 |
| OPENS UP | 0.1 | +4.5 | 0.0 | 0.0 | 0.4 | +44.6 | 34.0 | 0.0 |
| OVERRUNS AWAY | 0.4 | +2.9 | 17.5 | 0.0 | 0.5 | +69.2 | 88.7 | 0.0 |
| PATHS CROSS | 3.1 | +85.9 | 0.0 | 14.3 | 6.2 | +280.5 | 0.0 | 0.0 |
| PERIAPT WORTH | - | - | - | - | 0.1 | +4.9 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.1 | -1.7 | 0.0 | 4.7 | 0.2 | -0.6 | 0.0 | 0.0 |
| PLAN RESULT | 41.3 | +647.4 | 345.5 | 621.7 | 44.7 | +426.7 | 99.7 | 395.5 |
| PURSUES ON | 0.1 | -0.0 | 0.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | 3.5 | +480.6 | 18.6 | 43.5 | - | - | - | - |
| RANDOM MOVE BY FIGURES | 0.3 | +6.2 | 0.0 | 46.4 | 2.3 | +6.3 | 0.0 | 19.1 |
| REDIRECT BY WHAT IT STOPS | 0.2 | +0.9 | 0.0 | 0.0 | 0.4 | -8.1 | 0.0 | 0.0 |
| REDIRECT COUNTER | 1.6 | +209.6 | 0.0 | 0.0 | 3.8 | +111.8 | 0.0 | 19.9 |
| REDIRECT WEIGHED | 0.1 | -0.2 | 0.0 | 0.0 | 0.5 | -39.8 | 21.4 | 91.8 |
| REFORMS TO MEET IT | 0.9 | -15.1 | 0.0 | 5.0 | 0.4 | -12.9 | 0.0 | 0.0 |
| REFUSING RETIRES | 0.6 | +0.0 | 0.0 | 30.8 | 0.3 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | 0.5 | +26.8 | 0.0 | 33.8 | 1.5 | +43.5 | 0.0 | 14.5 |
| RISK BY ARC | 1.5 | -3.8 | 54.0 | 0.0 | 2.5 | -82.3 | 207.7 | 27.5 |
| RISK BY HIS FIGURE | 12.1 | -96.1 | 0.0 | 220.4 | 12.6 | -89.9 | 0.0 | 240.4 |
| RUN DOWN | 0.9 | -7.8 | 17.5 | 0.0 | 2.8 | -15.6 | 190.8 | 27.5 |
| SAME CHARGE LATER | 0.2 | -9.9 | 0.0 | 0.0 | 0.1 | -0.3 | 0.0 | 0.0 |
| SCOUT SPOT | 0.1 | -0.0 | 0.0 | 0.0 | 0.4 | +0.4 | 0.0 | 0.0 |
| SCOUT WAITS | 0.1 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 0.1 | -3.5 | 0.0 | 0.0 |
| SEARCH SPOT | 7.2 | +231.1 | 0.0 | 46.4 | 7.9 | +235.6 | 0.0 | 10.0 |
| SELF MOVE SPELL | - | - | - | - | 0.5 | +18.5 | 0.0 | 0.0 |
| SET UP TOGETHER | 0.1 | +0.2 | 0.0 | 0.0 | 1.4 | +19.0 | 0.0 | 7.3 |
| SET-UP ANY TARGET | - | - | - | - | 0.2 | +26.5 | 0.0 | 0.0 |
| SHOOTER COUNTED ONCE | - | - | - | - | 0.1 | -0.0 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.5 | +1.1 | 0.0 | 0.0 | 0.5 | +0.8 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.5 | +80.6 | 71.8 | 13.2 | 1.0 | +10.8 | 16.4 | 18.1 |
| SHORT GUN FORWARD | 0.5 | +0.0 | 0.0 | 10.9 | - | - | - | - |
| SHOT OR CHARGE | 0.2 | -0.7 | 0.0 | 0.0 | 0.1 | -3.3 | 10.6 | 0.0 |
| SHOT RISK POINTS | 11.1 | +153.8 | 0.0 | 190.0 | 15.2 | +68.7 | 0.0 | 190.6 |
| SHOTS IN THE MOVE | 16.7 | +541.3 | 0.0 | 260.4 | 15.5 | +318.1 | 0.0 | 62.7 |
| SPELL SETS UP CHARGE | - | - | - | - | 0.2 | +26.5 | 0.0 | 0.0 |
| SPELL WORTH | 0.6 | +22.1 | 33.8 | 64.5 | 2.2 | +22.5 | 0.0 | 8.6 |
| SPELLS IN THE FIGHT | 0.3 | +2.9 | 34.9 | 0.0 | 0.2 | -2.7 | 33.8 | 0.0 |
| STAND AND SHOOT | 0.5 | -2.9 | 0.0 | 0.0 | 0.6 | -5.0 | 65.8 | 0.0 |
| STANDS FOR A REASON | - | - | - | - | 0.9 | +0.0 | 0.0 | 18.1 |
| STANDS STILL | 22.2 | +0.0 | 366.1 | 313.7 | 11.6 | +0.0 | 120.0 | 43.9 |
| STAY WORTH | 18.2 | +84.8 | 169.5 | 141.7 | 16.5 | +126.8 | 77.4 | 31.4 |
| STOPS | - | - | - | - | 0.1 | +5.3 | 0.0 | 9.5 |
| STUCK PIVOT | - | - | - | - | 0.2 | +0.0 | 0.0 | 0.0 |
| SUPPORT NARROWED | 0.8 | +0.0 | 47.6 | 0.0 | 1.0 | +0.0 | 48.4 | 27.5 |
| SURE REACH TOGETHER | 0.1 | +0.2 | 0.0 | 0.0 | 0.5 | +39.0 | 0.0 | 32.5 |
| THE DEARER SUM KEEPS ITS PLAN | 4.0 | +0.0 | 0.0 | 46.5 | 6.4 | +0.0 | 0.0 | 25.8 |
| THE PROMISE ADDS | 0.1 | -2.8 | 0.0 | 0.0 | 0.1 | -8.1 | 21.7 | 0.0 |
| THE PROMISED MOVE | 1.1 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| TIED UP BY THE SUM | 0.4 | +18.6 | 0.0 | 0.0 | 0.7 | +96.3 | 67.5 | 18.1 |
| TIME ON OUR SIDE | 30.9 | +459.6 | 19.1 | 212.6 | 5.8 | +89.8 | 0.0 | 55.8 |
| WAITS AGAIN | 1.7 | +0.0 | 0.0 | 5.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| WAR ENGINE CHARGES | 0.1 | +29.5 | 45.9 | 0.0 | - | - | - | - |
| WAR ENGINE JOBS | 1.1 | +0.0 | 72.3 | 0.0 | - | - | - | - |
| WHO HITS BACK | 0.3 | +24.6 | 0.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT | 0.2 | +7.5 | 45.9 | 0.0 | 0.5 | +4.5 | 5.5 | 12.3 |
| WIDER SPREAD | 1.0 | -2.3 | 99.9 | 0.0 | 3.0 | -16.6 | 198.7 | 0.0 |
| WOUNDS ON THE RANKS | 2.1 | +61.4 | 0.0 | 33.8 | 0.5 | +12.7 | 0.0 | 0.0 |

### Rule changes: h4-mine-bbe8617-p4

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| SEARCH SPOT | 166 | 166 | 151 | 13.73 | +5133 | +34.0 |
| HIS SHOT LIST | 478 | 478 | 150 | 13.64 | +3054 | +20.4 |
| HOLDER ASSIGNMENT | 143 | 143 | 132 | 12.00 | +7500 | +56.8 |
| DEPLOY BY FIGURES | 194 | 194 | 123 | 11.18 | +1578 | +12.8 |
| LEGAL CHARGES ONLY | 117 | 117 | 117 | 10.64 | +0 | +0.0 |
| PATHS CROSS | 102 | 102 | 102 | 9.27 | +4031 | +39.5 |
| FIVE ACTION | 1085 | 1083 | 98 | 8.91 | +2433 | +24.8 |
| ONE TARGET A SHOOTER | 355 | 355 | 96 | 8.73 | +774 | +8.1 |
| TIME ON OUR SIDE | 404 | 371 | 68 | 6.18 | +298 | +4.4 |
| SHOT RISK POINTS | 289 | 289 | 56 | 5.09 | +1720 | +30.7 |
| FOUR ROUNDS | 65 | 63 | 43 | 3.91 | +1779 | +41.4 |
| HARD STAY DROPPED | 42 | 42 | 42 | 3.82 | +0 | +0.0 |
| MOVE TO CHARGE COMPUTED | 74 | 74 | 35 | 3.18 | +3513 | +100.4 |
| ARTILLERY RE-ROLL WEIGHED | 29 | 29 | 29 | 2.64 | +0 | +0.0 |
| CANNON SIGHT KEPT | 26 | 26 | 26 | 2.36 | +0 | +0.0 |
| COVER ONCE | 131 | 104 | 25 | 2.27 | +396 | +15.8 |
| MAX FOR POSITIONING | 126 | 124 | 24 | 2.18 | +28 | +1.2 |
| REDIRECT COUNTER | 60 | 52 | 22 | 2.00 | +1830 | +83.2 |
| RESERVE FALL BACK | 22 | 22 | 22 | 2.00 | +773 | +35.1 |
| SHOTS IN THE MOVE | 354 | 331 | 22 | 2.00 | +526 | +23.9 |
| SHOOTS FROM THE BEST SPOT | 28 | 28 | 19 | 1.73 | +303 | +15.9 |
| FALLS SHORT | 307 | 266 | 17 | 1.55 | +116 | +6.8 |
| LONE WIZARD KEPT IN | 17 | 17 | 17 | 1.55 | +1136 | +66.8 |
| MANOEUVRE | 32 | 32 | 17 | 1.55 | +338 | +19.9 |
| ADVANCE LANE KEPT | 16 | 16 | 16 | 1.45 | +0 | +0.0 |
| MISSILES IN THE MOVE | 69 | 54 | 16 | 1.45 | +212 | +13.2 |
| NEXT OBJECTIVE NEARER | 136 | 136 | 16 | 1.45 | +70 | +4.4 |
| RANDOM MOVE BY FIGURES | 28 | 28 | 15 | 1.36 | +137 | +9.1 |
| FOLLOW UP WEIGHED | 14 | 14 | 14 | 1.27 | +2586 | +184.7 |
| LANE BY FIGURES | 13 | 13 | 13 | 1.18 | +435 | +33.5 |
| MARCH CHECK | 24 | 24 | 13 | 1.18 | +263 | +20.2 |
| OFF BEST | 13 | 13 | 13 | 1.18 | -294 | -22.6 |
| RISK BY ARC | 44 | 43 | 13 | 1.18 | +461 | +35.4 |
| CANNON PLANNED TARGET | 81 | 81 | 12 | 1.09 | -91 | -7.6 |
| CHARGE NOT DECLARED | 11 | 11 | 11 | 1.00 | -1212 | -110.2 |
| MODEL FACING | 11 | 11 | 11 | 1.00 | +2344 | +213.1 |
| SHOOTERS IN TWO RANKS | 11 | 11 | 11 | 1.00 | +21 | +1.9 |
| TIED UP BY THE SUM | 12 | 12 | 11 | 1.00 | +243 | +22.1 |
| CHAFF PASSED | 10 | 10 | 10 | 0.91 | -13 | -1.3 |
| HOLDER AT DEPLOYMENT | 21 | 21 | 10 | 0.91 | +443 | +44.3 |
| IDLE COST | 154 | 116 | 10 | 0.91 | +79 | +7.9 |
| MARCH BY THE SUM | 10 | 10 | 10 | 0.91 | +656 | +65.6 |
| CASTER AWAY FROM SCREEN | 9 | 9 | 9 | 0.82 | +0 | +0.0 |
| CHARGE LOSSES | 116 | 116 | 9 | 0.82 | +442 | +49.1 |
| HOLDS AMBUSHERS | 9 | 9 | 9 | 0.82 | +0 | +0.0 |
| ONE OBJECTIVE FORMULA | 93 | 78 | 9 | 0.82 | +319 | +35.5 |
| STAY WORTH | 381 | 359 | 9 | 0.82 | +168 | +18.6 |
| CHARGE NOW FIRST | 29 | 29 | 8 | 0.73 | -270 | -33.8 |
| FEATURE BUFFS | 44 | 44 | 8 | 0.73 | +122 | +15.2 |
| NEXT CHARGE BY LIST | 113 | 113 | 8 | 0.73 | +263 | +32.8 |
| AFTERMATH IN POINTS | 7 | 7 | 7 | 0.64 | +1261 | +180.1 |
| BEST PRIZE | 7 | 7 | 7 | 0.64 | -568 | -81.2 |
| MISSILES NEXT TURN | 91 | 67 | 7 | 0.64 | +44 | +6.3 |
| QUARTER ODDS | 38 | 38 | 7 | 0.64 | +523 | +74.7 |
| HIS TURN DENIED | 34 | 32 | 6 | 0.55 | +267 | +44.5 |
| NEARER NOT NEEDED | 123 | 120 | 6 | 0.55 | +155 | +25.9 |
| REDIRECT WEIGHED | 6 | 6 | 6 | 0.55 | +605 | +100.8 |
| REFUSING RETIRES | 10 | 10 | 6 | 0.55 | -1 | -0.2 |
| RISK BY HIS FIGURE | 272 | 272 | 6 | 0.55 | +311 | +51.9 |
| SHORT GUN FORWARD | 6 | 6 | 6 | 0.55 | +0 | +0.0 |
| CASTING BLOCK | 7 | 7 | 5 | 0.45 | +138 | +27.7 |
| CHAFF IN THE MOVE | 12 | 12 | 5 | 0.45 | +79 | +15.9 |
| COMBAT PIVOT | 5 | 5 | 5 | 0.45 | +0 | +0.0 |
| FIGHT TO THE END | 28 | 26 | 5 | 0.45 | +235 | +47.1 |
| ONE FIGHT FORMULA | 116 | 58 | 5 | 0.45 | +37 | +7.4 |
| SCOUT WAITS | 5 | 5 | 5 | 0.45 | +0 | +0.0 |
| SURE REACH TOGETHER | 7 | 7 | 5 | 0.45 | +3 | +0.5 |
| WOUNDS ON THE RANKS | 28 | 28 | 5 | 0.45 | +197 | +39.4 |
| FALL BACK GOOD ORDER | 44 | 42 | 4 | 0.36 | +43 | +10.8 |
| HONEST WORTH | 62 | 60 | 4 | 0.36 | +63 | +15.9 |
| OPENS UP | 5 | 5 | 4 | 0.36 | +90 | +22.6 |
| CAST JOB | 8 | 8 | 3 | 0.27 | +26 | +8.6 |
| FIRE IN ORDER | 3 | 3 | 3 | 0.27 | +0 | +0.0 |
| FRIENDS SHOTS CHECKED | 3 | 3 | 3 | 0.27 | +78 | +25.9 |
| GUN MASK | 11 | 11 | 3 | 0.27 | +201 | +67.0 |
| HIS CHARGE DENIED | 5 | 5 | 3 | 0.27 | +185 | +61.7 |
| MOVES UNITS SPELL | 3 | 3 | 3 | 0.27 | +118 | +39.2 |
| OVERRUNS AWAY | 10 | 10 | 3 | 0.27 | +116 | +38.8 |
| PIVOT GUARDS FLANK | 3 | 3 | 3 | 0.27 | -26 | -8.6 |
| WHO HITS BACK | 3 | 3 | 3 | 0.27 | +65 | +21.6 |
| CARRIES OUT SET-UP | 3 | 3 | 2 | 0.18 | -345 | -172.7 |
| CASTS FROM BEHIND | 2 | 2 | 2 | 0.18 | +0 | +0.0 |
| EDGE GIVE GROUND | 3 | 3 | 2 | 0.18 | +23 | +11.5 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.18 | +0 | +0.0 |
| NEEDED THERE | 2 | 2 | 2 | 0.18 | +0 | +0.0 |
| NO DOUBLE ROUNDS | 54 | 52 | 2 | 0.18 | +130 | +65.0 |
| STUCK PIVOT | 2 | 2 | 2 | 0.18 | +0 | +0.0 |
| WAR ENGINE JOBS | 12 | 12 | 2 | 0.18 | -20 | -10.0 |
| FACES THE THREAT | 1 | 1 | 1 | 0.09 | +37 | +36.7 |
| FALLBACK BY WORTH | 9 | 9 | 1 | 0.09 | +117 | +117.0 |
| HIS MOVE AND SHOT | 35 | 35 | 1 | 0.09 | +2 | +1.5 |
| HORN WORTH | 1 | 1 | 1 | 0.09 | +20 | +19.9 |
| KILLS COUNT | 1 | 1 | 1 | 0.09 | +0 | +0.0 |
| MARCH ODDS | 1 | 1 | 1 | 0.09 | -82 | -81.7 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.09 | +54 | +54.4 |
| PURSUES ON | 1 | 1 | 1 | 0.09 | -0 | -0.2 |
| REDIRECT BY WHAT IT STOPS | 6 | 6 | 1 | 0.09 | +18 | +18.3 |
| SPELLS IN THE FIGHT | 5 | 5 | 1 | 0.09 | +27 | +27.0 |
| STOPS | 1 | 1 | 1 | 0.09 | +35 | +35.4 |
| SUPPORT NARROWED | 20 | 20 | 1 | 0.09 | -0 | -0.4 |
| WAR ENGINE CHARGES | 1 | 1 | 1 | 0.09 | +0 | +0.0 |
| WHOLE FIGHT | 7 | 7 | 1 | 0.09 | +27 | +27.0 |
| WIDER SPREAD | 44 | 43 | 1 | 0.09 | +0 | +0.0 |
| ALREADY CARRIED | 1 | not checked | - | - | - | - |
| BACKUP TARGETS | 1 | 1 | 0 | 0.00 | - | - |
| BLOWS WHERE AIMED | 9 | 8 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 13 | 13 | 0 | 0.00 | - | - |
| CARRIES OUT COUNTER | 1 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 9 | trace | - | - | - | - |
| CHARACTER GUNS | 14 | 14 | 0 | 0.00 | - | - |
| CHARGER SLAIN LOST | 4 | 4 | 0 | 0.00 | - | - |
| CHEAP HELPER | 2 | not checked | - | - | - | - |
| CHEAPEST HOLDER | 6 | 6 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 10 | not checked | - | - | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT LIFT | 1 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 109 | not checked | - | - | - | - |
| FRIEND CHARGES FIRST | 2 | 2 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 4 | 4 | 0 | 0.00 | - | - |
| GIVES UP | 7 | 7 | 0 | 0.00 | - | - |
| GUN FIGURES | 33 | not checked | - | - | - | - |
| HE SHOOTS OR CHARGES | 46 | 46 | 0 | 0.00 | - | - |
| HELPER UNSEEN | 1 | 1 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 54 | 54 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 66 | 66 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 44 | 44 | 0 | 0.00 | - | - |
| HOLD ODDS | 69 | 69 | 0 | 0.00 | - | - |
| HUNT IN PAIRS | 7 | 2 | 0 | 0.00 | - | - |
| HUNT KEPT | 1 | trace | - | - | - | - |
| HUNT RESULT | 1 | trace | - | - | - | - |
| HUNT THE GUNS | 1 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 1 | not checked | - | - | - | - |
| LONG SHOT | 4 | 4 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 11 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 3 | trace | - | - | - | - |
| MARCH OVER CASTS | 11 | 11 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 10 | 3 | 0 | 0.00 | - | - |
| MOVE SPELL NOT WORTH | 1 | not checked | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 12 | trace | - | - | - | - |
| MOVE SPELL SPOT | 6 | not checked | - | - | - | - |
| NOT TURNED | 3 | 3 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 10 | not checked | - | - | - | - |
| ONE CHARGE A CHARGER | 66 | 66 | 0 | 0.00 | - | - |
| PLAN RESULT | 946 | trace | - | - | - | - |
| REFORMS TO MEET IT | 14 | 14 | 0 | 0.00 | - | - |
| RUN DOWN | 41 | 40 | 0 | 0.00 | - | - |
| SAME CHARGE LATER | 3 | 3 | 0 | 0.00 | - | - |
| SCOUT SPOT | 5 | 5 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 1 | 1 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 6 | not checked | - | - | - | - |
| SET UP TOGETHER | 16 | 11 | 0 | 0.00 | - | - |
| SET-UP ANY TARGET | 2 | not checked | - | - | - | - |
| SHOOTER COUNTED ONCE | 1 | 1 | 0 | 0.00 | - | - |
| SHOT OR CHARGE | 3 | 3 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 2 | not checked | - | - | - | - |
| SPELL WORTH | 31 | not checked | - | - | - | - |
| STAND AND SHOOT | 12 | 11 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 10 | 10 | 0 | 0.00 | - | - |
| STANDS STILL | 372 | 372 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 114 | not checked | - | - | - | - |
| THE PROMISE ADDS | 2 | 2 | 0 | 0.00 | - | - |
| THE PROMISED MOVE | 19 | not checked | - | - | - | - |
| WAITS AGAIN | 26 | 26 | 0 | 0.00 | - | - |

### Off best figure: h4-mine-bbe8617-p4

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| HOLDER ASSIGNMENT | rule | 1.36 | - | 13.3 |
| PATHS CROSS | rule | 0.55 | 0.73 | 24.0 |
| CHARGE NOT DECLARED | rule | 0.18 | 0.73 | 121.2 |
| CHARGE NOW FIRST | rule | 0.09 | 0.64 | 33.8 |
| BEST PRIZE | rule | 0.09 | 0.45 | 94.6 |
| JOB FIRST | gate | - | 0.55 | 24.1 |
| AFTERMATH BAND | gate | - | 0.27 | 3.2 |
| PIVOT GUARDS FLANK | rule | 0.09 | 0.18 | 8.6 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.18 | - | 46.7 |
| CANNON PLANNED TARGET | rule | 0.09 | 0.09 | 45.7 |
| CARRIES OUT SET-UP | rule | - | 0.18 | 172.7 |
| CHAFF PASSED | rule | 0.09 | 0.09 | 6.4 |
| WAR ENGINE JOBS | rule | 0.18 | - | 10.0 |
| FALLBACK | gate | - | 0.09 | 1.6 |
| MARCH ODDS | rule | 0.09 | - | 81.7 |
| REDIRECT WEIGHED | rule | - | 0.09 | 45.2 |
| TURN GATE | gate | - | 0.09 | 45.0 |

### Plans: h4-mine-bbe8617-p4

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.1 | 42% | 183 | 85 | 47% |
| Mine | join | 0.3 | 100% | 9 | 0 | 0% |
| Mine | move | 28.5 | 94% | 1730 | 0 | 0% |
| Mine | shoot | 11.4 | 58% | 529 | 562 | 106% |
| Mine | support | 0.1 | 100% | 0 | 0 | - |
| Opponent | charge | 3.5 | 68% | 527 | 268 | 51% |
| Opponent | join | 1.0 | 100% | 48 | 0 | 0% |
| Opponent | move | 35.5 | 96% | 1831 | 0 | 0% |
| Opponent | shoot | 4.5 | 49% | 183 | 159 | 87% |
| Opponent | support | 0.3 | 100% | 6 | 0 | 0% |

### Packages: hunt the guns, h4-mine-bbe8617-p4

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 34 |
| Opponent | 0.1 | 1 | 0 | 100% | 0% | 0% | - | 363 | 0 | 0% | 53 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 34 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 78 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Tomb Kings of Khemri | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 195 |
| Vampire Counts | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 45 |
| Warriors of Chaos | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Wood Elf Realms | 0.5 | 1 | 0 | 100% | 0% | 0% | - | 363 | 0 | 0% | 169 |

### Battle groups: h4-mine-bbe8617-p4

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 1.6 | 11% | 100% | 0% | - | 50% | 0% | 0% | 50% | 0% |
| Opponent | REDIRECT COUNTER | 3.8 | 12% | 100% | 60% | 0% | 0% | 0% | 0% | 50% | 50% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: h4-mine-bbe8617-p4

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 6 | 0 (6) | 0 | 0 | 28 | 67% | 2.5 | 0 (2) | 0 (3) | 0 (1) | 0 (4) | 0 (2) |
| Mine | Character | 41 | 17 (41) | 17 | 0 | 39 | 22% | 2.5 | 10 (16) | 35 (15) | 0 (2) | 21 (9) | 21 (24) |
| Mine | Clean-up | 6 | 104 (6) | 0 | 104 | 39 | 67% | 1.0 | 75 (3) | 133 (3) | - | 116 (5) | 0 (1) |
| Mine | Fast Hammer | 10 | 0 (10) | 0 | 0 | 53 | 50% | 2.8 | 0 (1) | 0 (5) | 0 (4) | 0 (8) | 0 (2) |
| Mine | Hammer | 28 | 36 (28) | 15 | 21 | 17 | 21% | 2.5 | 47 (10) | 36 (14) | 12 (4) | 42 (17) | 27 (11) |
| Mine | Holder | 10 | 79 (10) | 0 | 79 | 8 | 70% | 4.7 | 87 (3) | 99 (5) | 0 (2) | 162 (4) | 28 (6) |
| Mine | Shooter | 16 | 66 (16) | 4 | 63 | 16 | 0% | 1.9 | 33 (7) | 128 (7) | 16 (2) | 57 (13) | 115 (3) |
| Mine | War machine | 25 | 20 (25) | 20 | 0 | 58 | 4% | 1.4 | 18 (15) | 29 (8) | 0 (2) | 0 (6) | 26 (19) |
| Mine | Wizard | 6 | 0 (6) | 0 | 0 | 0 | 33% | 4.0 | 0 (5) | 0 (1) | - | 0 (1) | 0 (5) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | 0 (1) | - | - | - | 0 (1) |
| Opponent | Chaff | 23 | 22 (23) | 0 | 22 | 36 | 35% | 3.5 | 0 (8) | 25 (10) | 66 (5) | 21 (16) | 24 (7) |
| Opponent | Character | 27 | 62 (27) | 62 | 0 | 12 | 19% | 2.3 | 32 (7) | 107 (8) | 53 (11) | 62 (16) | 66 (10) |
| Opponent | Clean-up | 10 | 27 (10) | 0 | 27 | 31 | 40% | 3.0 | 7 (3) | 34 (5) | 33 (2) | 26 (6) | 29 (4) |
| Opponent | Fast Hammer | 11 | 42 (11) | 10 | 32 | 23 | 36% | 3.6 | 36 (4) | 77 (4) | 0 (3) | 48 (9) | 0 (2) |
| Opponent | Hammer | 17 | 13 (17) | 8 | 6 | 25 | 47% | 2.8 | 0 (4) | 11 (10) | 34 (3) | 3 (8) | 22 (9) |
| Opponent | Holder | 13 | 136 (13) | 5 | 131 | 0 | 38% | 2.5 | 228 (3) | 127 (7) | 74 (3) | 152 (11) | 62 (2) |
| Opponent | Shooter | 10 | 77 (10) | 0 | 77 | 5 | 10% | 1.7 | 98 (4) | 117 (2) | 0 (4) | 76 (6) | 79 (4) |
| Opponent | Support | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | 0 (1) | - | - | - | 0 (1) |
| Opponent | War machine | 7 | 48 (7) | 48 | 0 | 0 | 0% | 2.3 | 41 (5) | 137 (1) | 0 (1) | - | 48 (7) |
| Opponent | Wizard | 10 | 6 (10) | 6 | 0 | 10 | 20% | 2.1 | 18 (3) | 0 (2) | 0 (4) | 0 (2) | 8 (7) |

### Charged fights: h4-mine-bbe8617-p4

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 80 | 0 | 0.5 | 1.0 | 0 | 0 | +0 | 0 of 2 | 2 of 2 | - | +0 |
| Mine | Chaos Dwarfs | 4 | 188 | 179 | 1.8 | 1.0 | 102 | 68 | +34 | 4 of 7 | 5 of 7 | - | +34 |
| Mine | Dwarfen Mountain Holds | 3 | 105 | 85 | 1.0 | 1.0 | 85 | 0 | +85 | 1 of 3 | 2 of 3 | - | +85 |
| **Mine** | all armies | 11 | 126 | 88 | 1.1 | 1.0 | 81 | 40 | +41 | 5 of 12 | 9 of 12 | - | +41 |
| Opponent | Empire of Man | 1 | 355 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | High Elf Realms | 1 | 0 | 485 | 5.0 | 1.0 | 97 | 0 | +97 | 3 of 5 | 2 of 5 | - | +97 |
| Opponent | Kingdom of Bretonnia | 2 | 68 | 392 | 3.0 | 1.0 | 130 | 0 | +130 | 0 of 6 | 6 of 6 | - | +130 |
| Opponent | Skaven | 1 | 0 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 0 of 1 | 1 of 1 | - | +0 |
| Opponent | Tomb Kings of Khemri | 1 | 0 | 980 | 7.0 | 1.0 | 140 | 0 | +140 | 2 of 7 | 5 of 7 | - | +140 |
| Opponent | Vampire Counts | 1 | 60 | 246 | 4.0 | 1.2 | 62 | 0 | +62 | 1 of 4 | 4 of 4 | +0 | +82 |
| Opponent | Warriors of Chaos | 2 | 0 | 779 | 4.0 | 1.1 | 195 | 21 | +174 | 5 of 8 | 4 of 8 | -40 | +205 |
| Opponent | Wood Elf Realms | 2 | 0 | 0 | 2.5 | 1.2 | 0 | 21 | -21 | 2 of 5 | 3 of 5 | +0 | -26 |
| **Opponent** | all armies | 11 | 50 | 368 | 3.3 | 1.1 | 113 | 7 | +105 | 13 of 36 | 25 of 36 | -13 | +116 |

### Effective charges: h4-mine-bbe8617-p4

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 2 | 0 | 0 | 0 | 0 | 0 | 2 (net +0) | 0 | 0% (0 of 2) |
| Mine | Chaos Dwarfs | 7 | 1 (net -339) | 0 | 1 (net +0) | 2 (net +288) | 0 | 2 (net +0) | 1 | 17% (1 of 6) |
| Mine | Dwarfen Mountain Holds | 3 | 0 | 0 | 0 | 0 | 0 | 3 (net +85) | 0 | 0% (0 of 3) |
| Opponent | High Elf Realms | 5 | 1 (net +355) | 0 | 2 (net +65) | 0 | 2 (net +0) | 0 | 0 | 40% (2 of 5) |
| Opponent | Kingdom of Bretonnia | 6 | 0 | 0 | 2 (net +141) | 2 (net +125) | 1 (net +81) | 1 (net +170) | 0 | 33% (2 of 6) |
| Opponent | Skaven | 1 | 0 | 0 | 0 | 0 | 1 (net +0) | 0 | 0 | 0% (0 of 1) |
| Opponent | Tomb Kings of Khemri | 7 | 2 (net +194) | 0 | 3 (net +102) | 2 (net +142) | 0 | 0 | 0 | 43% (3 of 7) |
| Opponent | Vampire Counts | 4 | 1 (net +0) | 0 | 1 (net +0) | 0 | 1 (net +60) | 1 (net +186) | 0 | 25% (1 of 4) |
| Opponent | Warriors of Chaos | 8 | 4 (net +66) | 0 | 1 (net +822) | 1 (net +0) | 1 (net +84) | 1 (net +222) | 0 | 12% (1 of 8) |
| Opponent | Wood Elf Realms | 5 | 1 (net -104) | 0 | 3 (net +0) | 0 | 0 | 0 | 1 | 75% (3 of 4) |

### Charged fights, damage counted: h4-mine-bbe8617-p4

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 1 | 480 | 499 | -339 | 55 | 408 | -352 | -73.4 |
| Mine | Effective (55-75%) | 1 | 124 | 102 | +0 | 102 | 53 | +49 | +39.4 |
| Mine | 76-89% | 2 | 324 | 308 | +288 | 448 | 92 | +356 | +109.6 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 7 | 166 | 133 | +36 | 68 | 13 | +55 | +33.1 |
| Mine | No odds | 1 | 339 | 38 | +0 | 25 | 48 | -23 | -6.8 |
| Mine | All fights | 12 | 229 | 182 | +41 | 129 | 65 | +64 | +27.9 |
| Opponent | Long shot (under 50%) | 9 | 315 | 318 | +100 | 146 | 84 | +62 | +19.6 |
| Opponent | Effective (55-75%) | 12 | 370 | 203 | +128 | 142 | 31 | +111 | +30.1 |
| Opponent | 76-89% | 5 | 285 | 105 | +107 | 116 | 0 | +116 | +40.5 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 | 450 | 175 | +193 | 193 | 47 | +145 | +32.3 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 6 | 361 | 68 | +38 | 66 | 5 | +61 | +17.0 |
| Opponent | No odds | 1 | 405 | 140 | +0 | 0 | 0 | +0 | +0.0 |
| Opponent | All fights | 36 | 351 | 192 | +105 | 127 | 36 | +91 | +25.9 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| h4-mine-bbe8617-p4 | move | 88 | 15 (17%) | 12 (14%) | 13 (15%) | 60 (68%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0115, L0132 |
| Charmed Shield | Opponent | L0625 |
| Horn of the Wild Hunt | Opponent | L0333 |
| Invocation of Nehek | Opponent | L0625 |
| Periapt of Soul Exchange | Opponent | L0420 |
| Ring of Doom | Mine | L0216, L0232 |
| Ring of Doom | Opponent | L0115, L0333 |

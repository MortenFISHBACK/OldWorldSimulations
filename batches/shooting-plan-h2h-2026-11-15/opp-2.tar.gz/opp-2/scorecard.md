# Doctrine scorecard: sp-h2h-opp-89601ea-p2

### Scorecard: sp-h2h-opp-89601ea-p2

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0106 | 4 | 1 | Mine | no | 2 | 4 | 0 | 2 | 0 | 0 | 0 | 65 |
| L0106 | 4 | 1 | Opponent | no | 1 | 2 | 2 | 0 | 1 | 0 | 0 | 981 |
| L0122 | 2 | 1 | Mine | - | - | 3 | 1 | 3 | 0 | 0 | 0 | 0 |
| L0122 | 2 | 1 | Opponent | - | - | 2 | 1 | 0 | 2 | 0 | 0 | 0 |
| L0206 | 2 | 1 | Mine | - | - | - | 0 | 4 | 0 | 0 | 0 | 0 |
| L0206 | 2 | 1 | Opponent | - | - | 2 | 1 | 0 | 0 | 0 | 0 | 615 |
| L0222 | 6 | 1 | Mine | no | 8 | 3 | 2 | 3 | 0 | 0 | 0 | 170 |
| L0222 | 6 | 1 | Opponent | no | 3 | 2 | 2 | 0 | 0 | 0 | 0 | 0 |
| L0307 | 1 | 1 | Mine | no | 2 | - | 0 | 1 | 0 | 0 | 0 | 675 |
| L0307 | 1 | 1 | Opponent | yes | 3 | 2 | 0 | 1 | 1 | 0 | 0 | 420 |
| L0323 | 5 | 1 | Mine | no | - | - | 0 | 1 | 0 | 0 | 0 | 590 |
| L0323 | 5 | 1 | Opponent | yes | - | 2 | 5 | 1 | 0 | 0 | 0 | 0 |
| L0409 | 1 | 1 | Mine | no | 3 | 2 | 4 | 0 | 0 | 0 | 0 | 0 |
| L0409 | 1 | 1 | Opponent | no | 0 | 3 | 1 | 0 | 1 | 0 | 0 | 873 |
| L0425 | 5 | 1 | Mine | yes | - | 2 | 4 | 4 | 0 | 0 | 0 | 0 |
| L0425 | 5 | 1 | Opponent | no | - | 2 | 1 | 5 | 2 | 0 | 0 | 348 |
| L0512 | 2 | 1 | Mine | - | - | - | 1 | 1 | 0 | 0 | 0 | 1042 |
| L0512 | 2 | 1 | Opponent | - | - | 2 | 3 | 1 | 1 | 0 | 0 | 330 |
| L0528 | 6 | 1 | Mine | yes | 7 | 5 | 2 | 1 | 0 | 0 | 0 | 475 |
| L0528 | 6 | 1 | Opponent | no | 6 | - | 1 | 1 | 0 | 0 | 0 | 0 |
| L0616 | 4 | 1 | Mine | no | 0 | 4 | 1 | 1 | 0 | 0 | 0 | 615 |
| L0616 | 4 | 1 | Opponent | no | 0 | 3 | 2 | 1 | 1 | 0 | 0 | 200 |
| L0632 | 2 | 1 | Mine | - | - | 2 | 1 | 0 | 0 | 0 | 0 | 743 |
| L0632 | 2 | 1 | Opponent | - | - | 2 | 4 | 4 | 0 | 0 | 0 | 0 |
| L0721 | 1 | 1 | Mine | yes | 0 | 2 | 4 | 1 | 0 | 0 | 0 | 250 |
| L0721 | 1 | 1 | Opponent | yes | 4 | - | 1 | 2 | 1 | 0 | 0 | 355 |
| L0810 | 6 | 1 | Mine | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 679 |
| L0810 | 6 | 1 | Opponent | no | 10 | 2 | 4 | 1 | 0 | 0 | 0 | 330 |
| L0827 | 5 | 1 | Mine | no | - | - | 0 | 1 | 0 | 0 | 0 | 886 |
| L0827 | 5 | 1 | Opponent | yes | - | 2 | 4 | 3 | 0 | 0 | 0 | 0 |
| L0918 | 6 | 1 | Mine | no | 0 | 3 | 3 | 1 | 0 | 0 | 0 | 420 |
| L0918 | 6 | 1 | Opponent | no | 4 | 4 | 4 | 1 | 0 | 0 | 0 | 419 |
| L0934 | 4 | 1 | Mine | no | 0 | 1 | 0 | 1 | 0 | 0 | 0 | 783 |
| L0934 | 4 | 1 | Opponent | no | 0 | 2 | 5 | 4 | 0 | 0 | 0 | 216 |
| L1026 | 6 | 1 | Mine | no | 0 | 2 | 2 | 0 | 0 | 0 | 0 | 330 |
| L1026 | 6 | 1 | Opponent | no | 6 | 2 | 6 | 0 | 1 | 0 | 0 | 0 |
| L1118 | 2 | 1 | Mine | - | - | 2 | 4 | 1 | 0 | 0 | 0 | 330 |
| L1118 | 2 | 1 | Opponent | - | - | 2 | 6 | 2 | 0 | 0 | 0 | 0 |
| L1135 | 1 | 1 | Mine | yes | 2 | 2 | 0 | 0 | 0 | 0 | 0 | 501 |
| L1135 | 1 | 1 | Opponent | no | 0 | 2 | 1 | 2 | 0 | 0 | 0 | 0 |
| L1228 | 4 | 1 | Mine | no | 1 | 6 | 1 | 0 | 0 | 0 | 0 | 524 |
| L1228 | 4 | 1 | Opponent | no | 2 | - | 0 | 2 | 0 | 0 | 0 | 0 |
| L1323 | 3 | 1 | Mine | no | 9 | 2 | 4 | 0 | 2 | 0 | 0 | 140 |
| L1323 | 3 | 1 | Opponent | no | 0 | 2 | 4 | 1 | 2 | 0 | 0 | 90 |
| L1418 | 2 | 1 | Mine | - | - | 2 | 7 | 1 | 0 | 0 | 0 | 0 |
| L1418 | 2 | 1 | Opponent | - | - | - | 3 | 3 | 1 | 0 | 0 | 0 |
| L1435 | 1 | 1 | Mine | no | 0 | 2 | 2 | 2 | 0 | 0 | 0 | 0 |
| L1435 | 1 | 1 | Opponent | no | 0 | 3 | 3 | 3 | 0 | 0 | 0 | 140 |
| L1531 | 1 | 1 | Mine | no | 0 | 2 | 2 | 1 | 0 | 0 | 0 | 126 |
| L1531 | 1 | 1 | Opponent | yes | 2 | 2 | 4 | 0 | 1 | 0 | 0 | 340 |
| L1629 | 3 | 1 | Mine | no | 2 | 1 | 3 | 1 | 0 | 0 | 0 | 200 |
| L1629 | 3 | 1 | Opponent | no | 0 | 2 | 4 | 2 | 0 | 0 | 0 | 170 |
| L1727 | 5 | 1 | Mine | yes | - | 3 | 2 | 0 | 0 | 0 | 0 | 135 |
| L1727 | 5 | 1 | Opponent | yes | - | 2 | 4 | 3 | 0 | 0 | 0 | 0 |
| L1827 | 3 | 1 | Mine | no | 0 | 4 | 1 | 0 | 0 | 0 | 0 | 602 |
| L1827 | 3 | 1 | Opponent | no | 8 | 2 | 8 | 1 | 0 | 0 | 0 | 0 |
| L1927 | 1 | 1 | Mine | no | 1 | 1 | 2 | 0 | 0 | 0 | 0 | 0 |
| L1927 | 1 | 1 | Opponent | no | 0 | 2 | 4 | 3 | 1 | 0 | 0 | 0 |
| L2029 | 1 | 1 | Mine | no | 0 | - | 0 | 0 | 1 | 0 | 0 | 420 |
| L2029 | 1 | 1 | Opponent | no | 0 | 2 | 6 | 0 | 0 | 0 | 0 | 170 |
| L2131 | 1 | 1 | Mine | yes | 2 | - | 2 | 2 | 0 | 0 | 0 | 0 |
| L2131 | 1 | 1 | Opponent | no | 1 | 2 | 0 | 1 | 1 | 0 | 0 | 170 |
| L2235 | 3 | 1 | Mine | no | 8 | 2 | 3 | 0 | 0 | 0 | 0 | 0 |
| L2235 | 3 | 1 | Opponent | no | 0 | 2 | 4 | 2 | 1 | 0 | 0 | 240 |
| L2429 | 5 | 1 | Mine | yes | - | 3 | 3 | 1 | 0 | 0 | 0 | 0 |
| L2429 | 5 | 1 | Opponent | yes | - | 3 | 4 | 1 | 1 | 0 | 0 | 0 |
| L2535 | 3 | 1 | Mine | no | 7 | 2 | 2 | 0 | 1 | 0 | 0 | 0 |
| L2535 | 3 | 1 | Opponent | yes | 3 | 1 | 5 | 1 | 0 | 0 | 0 | 0 |
| L2735 | 5 | 1 | Mine | yes | - | 4 | 4 | 3 | 1 | 0 | 0 | 0 |
| L2735 | 5 | 1 | Opponent | yes | - | 1 | 5 | 3 | 0 | 0 | 0 | 0 |
| L3033 | 3 | 1 | Mine | yes | 6 | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| L3033 | 3 | 1 | Opponent | no | 0 | 1 | 7 | 1 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 30% | 2.5 | 2.6 | 1.9 | 1.1 | 0.1 | 0.0 | 0.0 | 297.2 |
| **Average** | | | Opponent | 30% | 2.2 | 2.1 | 3.3 | 1.6 | 0.5 | 0.0 | 0.0 | 178.0 |

### KPIs: sp-h2h-opp-89601ea-p2

Rules off - Mine only: STAY WORTH, BEST MOVE FOR SHOOTERS, FACE THE CAST, WIZARD FRONT RANK, FIRE PLAN, FIRE IN ORDER, KEEPS THE TARGET, MISSILES IN THE FIRE PLAN, THREAT AT FULL SIZE, SHOOTERS ARE THREATS, SHOOTERS TO THE PRIMARY.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 32% (56 of 173) | 14% (25 of 178) | 23% (81 of 351) |
| Winner chose to follow up after the loser gave ground |  | 100% (67 of 67); on the table 100% | 96% (49 of 51); on the table 96% | 98% (116 of 118); on the table 98% |
| Winner chose to pursue after the loser fell back in good order |  | 88% (7 of 8); on the table 88% | 77% (10 of 13); on the table 85% | 81% (17 of 21); on the table 86% |
| Winner chose to pursue after the loser fled |  | 72% (13 of 18); on the table 72% | 68% (32 of 47); on the table 79% | 69% (45 of 65); on the table 77% |
| Winner chose to follow up or pursue (all three) |  | 94% (87 of 93); on the table 94% | 82% (91 of 111); on the table 87% | 87% (178 of 204); on the table 90% |
| Magic missiles tried each own turn | 50%+ | 35% (119 of 342) | 33% (52 of 156) | 34% (171 of 498) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 50% (107 of 214) | 43% (52 of 120) | 48% (159 of 334) |
|   fighting wizards (on a monster, chariot or monstrous mount) | 50%+ | 29% (44 of 150) | 17% (13 of 78) | 25% (57 of 228) |
|     round 1 |  | 24% (6 of 25) | 8% (1 of 13) | 18% (7 of 38) |
|     rounds 2+ |  | 30% (38 of 125) | 18% (12 of 65) | 26% (50 of 190) |
|   other wizards | 50%+ | 35% (63 of 180) | 50% (39 of 78) | 40% (102 of 258) |
|     round 1 |  | 37% (11 of 30) | 54% (7 of 13) | 42% (18 of 43) |
|     rounds 2+ |  | 35% (52 of 150) | 49% (32 of 65) | 39% (84 of 215) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 50% (16 of 32) | 52% (26 of 50) | 51% (42 of 82) |
| Points that never fought | lower | 35% (25141 of 71583) | 41% (29402 of 71989) | 38% (54543 of 143572) |
|   infantry points that never fought | lower | 45% (7396 of 16324) | 59% (8274 of 14029) | 52% (15670 of 30353) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 59% (168 of 284) | 59% (174 of 297) | 59% (342 of 581) |
| Bound items with a magic missile used (at least once a game) |  | 100% (20 of 20); 1.5 uses a game | 78% (14 of 18); 1.2 uses a game | 89% (34 of 38); 1.4 uses a game |
| Bound items with another spell used |  | 56% (10 of 18); 0.5 uses a game | 50% (1 of 2); 0.1 uses a game | 55% (11 of 20); 0.3 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 45% (9 of 20); 0.2 uses a game | 14% (1 of 7); 0.0 uses a game | 37% (10 of 27); 0.1 uses a game |
|   their share of the points of units over 100 pts | lower | 54% (32667 of 60231) | 54% (34180 of 63281) | 54% (66847 of 123512) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.6 (25%) | 0.9 (30%) | 2.4 (27%) |
| MARCHED: its unit marched | 0.8 (13%) | 0.6 (19%) | 1.4 (15%) |
| CHARGED: its unit charged | 0.3 (4%) | 0.1 (5%) | 0.4 (5%) |
| IN COMBAT: engaged in combat | 1.4 (23%) | 0.6 (20%) | 2.0 (22%) |
| REAR RANK: in a rear rank | 0.1 (1%) | 0.1 (2%) | 0.1 (2%) |
| FLEEING: fleeing | 0.5 (8%) | 0.0 (0%) | 0.5 (6%) |
| GONE: slain | 0.8 (13%) | 0.4 (12%) | 1.2 (13%) |
| OFF THE TABLE: off the table or not arrived | 0.5 (8%) | 0.1 (2%) | 0.5 (6%) |
| STUPIDITY: Stupidity | 0.2 (3%) | 0.1 (2%) | 0.2 (2%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.1 (1%) | 0.2 (7%) | 0.2 (3%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.4 | 2.1 | 1.2 | 4.8 | 0.4 | 1.8 |
| not cast | 3.4 | 2.8 | 3.8 | 9.1 | 2.0 | 19.8 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) | 1.4 (7%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.3 (46%) | 0.3 (8%) | 2.4 (27%) | 0.3 (15%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.4 (15%) | 0.4 (21%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.4 (5%) | 0.1 (3%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.2 (7%) | 0.3 (12%) | 0.5 (14%) | 2.0 (22%) | 0.3 (15%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.3 (10%) | 0.2 (9%) | 0.3 (7%) | 0.1 (2%) | 0.0 (0%) | 0.0 (0%) |
| NO CASTS LEFT: every cast used on other spells | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) |
| FLEEING: fleeing | 0.1 (3%) | 0.1 (3%) | 0.1 (3%) | 0.5 (6%) | 0.1 (4%) | 0.6 (3%) |
| GONE: slain | 0.6 (16%) | 0.2 (8%) | 0.3 (9%) | 1.2 (13%) | 0.2 (13%) | 2.8 (14%) |
| OFF THE TABLE: off the table or not arrived | 0.1 (2%) | 0.3 (12%) | 0.3 (9%) | 0.5 (6%) | 0.1 (6%) | 0.6 (3%) |
| STUPIDITY: Stupidity | 0.1 (4%) | 0.1 (2%) | 0.1 (1%) | 0.2 (2%) | 0.0 (0%) | 0.3 (2%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.2 (5%) | 0.2 (7%) | 0.0 (0%) | 0.0 (0%) | 0.4 (21%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (3%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.8 (53%) | 0.1 (2%) | 1.8 (47%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 14.1 (71%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.6 a game | 0.7 a game | 0.6 a game |
| stood (cast and not dispelled) | 61% (11 of 18) | 62% (15 of 24) | 62% (26 of 42) |
| the unit moved after it | 64% (7 of 11) | 80% (12 of 15) | 73% (19 of 26) |
| it charged on its next turn | 9% (1 of 11) | 20% (3 of 15) | 15% (4 of 26) |
| the enemy charged it first | 0% (0 of 11) | 0% (0 of 15) | 0% (0 of 26) |
| it fought by the end of its next turn | 0% (0 of 11) | 0% (0 of 15) | 0% (0 of 26) |
| it moved out of a charge the enemy had planned (not charged first) | 27% (3 of 11) | 13% (2 of 15) | 19% (5 of 26) |
| none of these (no charge, no fight, no charge escaped) | 64% (7 of 11) | 67% (10 of 15) | 65% (17 of 26) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 64% (548 of 861) | 60% (465 of 779) | 62% (1013 of 1640) |
|   cavalry | 62% (40 of 64) | 64% (114 of 178) | 64% (154 of 242) |
|   character | 48% (55 of 114) | 32% (33 of 102) | 41% (88 of 216) |
|   chariot | 52% (59 of 113) | 67% (28 of 42) | 56% (87 of 155) |
|   infantry | 61% (160 of 261) | 61% (178 of 294) | 61% (338 of 555) |
|   monster | 39% (16 of 41) | 53% (19 of 36) | 45% (35 of 77) |
|   war machine | 81% (218 of 268) | 73% (93 of 127) | 79% (311 of 395) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.8 (32%) | 1.9 (21%) | 4.6 (27%) |
| CHARGED: it charged | 0.9 (11%) | 1.9 (22%) | 2.8 (16%) |
| FLEEING: it fled or was fleeing | 0.1 (1%) | 0.1 (1%) | 0.2 (1%) |
| IN COMBAT: it fought this turn or the last | 0.9 (11%) | 0.5 (6%) | 1.4 (8%) |
| MOVED: a war machine that moved | 0.1 (1%) | 0.0 (0%) | 0.1 (0%) |
| NO TARGET IN RANGE | 1.5 (17%) | 1.7 (20%) | 3.2 (18%) |
| ONLY IN COMBAT: the only targets were in combat | 0.3 (4%) | 0.5 (5%) | 0.8 (4%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.4 (17%) | 1.5 (18%) | 3.0 (17%) |
| SHELTERED: the target was sheltered | 0.3 (3%) | 0.2 (3%) | 0.5 (3%) |
| OTHER BAR | 0.4 (5%) | 0.4 (5%) | 0.8 (5%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 6.3 | 1.6 | 79% | 5.2 pts | 33 pts |
| character | 2.6 | 0.8 | 75% | 12.3 pts | 32 pts |
| chariot | 2.5 | 1.8 | 71% | 14.0 pts | 35 pts |
| infantry | 12.8 | 4.5 | 75% | 8.5 pts | 110 pts |
| monster | 1.2 | 0.4 | 80% | 6.5 pts | 8 pts |
| war machine | 8.6 | 6.7 | 63% | 22.3 pts | 193 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.9 | 6.6 | 5.3 |
| Charges that made contact a game | 2.9 | 4.6 | 3.7 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.08 declared, 0.73 contact (26 units) | 1.15 declared, 0.77 contact (13 units) | 1.10 declared, 0.74 contact (39 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.17 declared, 0.17 contact (6 units) | 1.67 declared, 1.08 contact (12 units) | 1.17 declared, 0.78 contact (18 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.45 declared, 0.33 contact (249 units) | 0.71 declared, 0.49 contact (289 units) | 0.59 declared, 0.42 contact (538 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 58% (42 of 73) | 56% (10 of 18) | 58% (7 of 12) | 57% (59 of 103) |
| Character in a unit | 77% (23 of 30) | 75% (15 of 20) | 80% (4 of 5) | 76% (42 of 55) |
| Character on its own | 81% (34 of 42) | 44% (15 of 34) | 26% (16 of 61) | 47% (65 of 137) |
| Chariot | 59% (10 of 17) | 77% (10 of 13) | - | 67% (20 of 30) |
| Infantry | 55% (52 of 94) | 59% (20 of 34) | 67% (2 of 3) | 56% (74 of 131) |
| Monster | 52% (15 of 29) | 78% (7 of 9) | - | 58% (22 of 38) |
| Monstrous | 43% (6 of 14) | 57% (8 of 14) | - | 50% (14 of 28) |
| War Machines | 77% (44 of 57) | 100% (2 of 2) | - | 78% (46 of 59) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 100% (8 of 8); on the table 100% | 30% (31 of 102) | 48% | 64% (14 of 22) | 100% (6 of 6); 4.0 uses a game | 100% (2 of 2); 0.5 uses a game | 83% (5 of 6); 1.2 uses a game |
| Chaos Dwarfs | 4 | 100% (11 of 11); on the table 100% | 61% (22 of 36) | 54% | 66% (21 of 32) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
| Dwarfen Mountain Holds | 6 | 87% (13 of 15); on the table 87% | - | 57% | 63% (34 of 54) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 7 | 69% (9 of 13); on the table 77% | 35% (17 of 48) | 46% | 64% (49 of 76) | 0.0 uses a game | 100% (2 of 2); 1.1 uses a game | 25% (1 of 4); 0.1 uses a game |
| Grand Cathay | 6 | 95% (21 of 22); on the table 100% | 25% (35 of 138) | 38% | 48% (26 of 54) | 93% (13 of 14); 6.3 uses a game | 50% (1 of 2); 0.2 uses a game | 0% (0 of 6); 0.0 uses a game |
| High Elf Realms | 4 | 100% (9 of 9); on the table 100% | 33% (6 of 18) | 28% | 45% (15 of 33) | 100% (3 of 3); 2.2 uses a game | 43% (6 of 14); 2.2 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 2 | 100% (3 of 3); on the table 100% | - | 53% | 50% (6 of 12) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.5 uses a game |
| Lizardmen | 1 | 100% (2 of 2); on the table 100% | - | 35% | 43% (3 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 4 | 88% (14 of 16); on the table 88% | 0% (0 of 18) | 28% | 79% (22 of 28) | 100% (4 of 4); 2.5 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 1 | 100% (1 of 1); on the table 100% | 33% (4 of 12) | 0% | 25% (2 of 8) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Skaven | 3 | 89% (8 of 9); on the table 89% | 50% (9 of 18) | 41% | 68% (17 of 25) | 100% (2 of 2); 1.7 uses a game | 0.0 uses a game | 33% (1 of 3); 0.3 uses a game |
| Tomb Kings of Khemri | 5 | 100% (12 of 12); on the table 100% | - | 40% | 36% (9 of 25) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 9 | 83% (30 of 36); on the table 92% | 42% (28 of 66) | 19% | 59% (32 of 54) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 9 | 76% (19 of 25); on the table 80% | 56% (10 of 18) | 31% | 58% (42 of 73) | 100% (2 of 2); 0.7 uses a game | 0.0 uses a game | 100% (1 of 1); 0.1 uses a game |
| Wood Elf Realms | 7 | 82% (18 of 22); on the table 82% | 38% (9 of 24) | 42% | 64% (50 of 78) | 57% (4 of 7); 2.0 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (sp-h2h-opp-89601ea-p2, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 52% (56) | 39% (24) | 47% (80) |
| ...free all their last turn and able to turn (per game) | 0.89 | 0.39 | 1.28 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.28 | 0.14 | 0.42 |
| ...with the charger already in that arc before they moved (per game) | 0.58 | 0.22 | 0.81 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 2.14 | 1.25 | 3.39 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.97 | 0.61 | 1.58 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 6.53 | 4.94 | 11.47 |

### Quality by phase: sp-h2h-opp-89601ea-p2

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.8 | 3.3 |
| Strategy | Charge objectives carried out (made contact) | 50% (60 of 121) | 48% (109 of 228) |
| Strategy | Shoot objectives carried out (shot that target) | 39% (134 of 344) | 46% (121 of 261) |
| Strategy | Close-in objectives charged next turn | 13% (15 of 113) | 25% (51 of 206) |
| Strategy | Support requests answered (helper made contact too) | 75% (12 of 16) | 41% (11 of 27) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (6 of 6) | 100% (1 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | 42% (10 of 24) | 39% (9 of 23) |
| Strategy | Joined characters whose unit fought | 46% (22 of 48) | 25% (10 of 40) |
| Strategy | Lone characters that fought | 77% (75 of 97) | 82% (68 of 83) |
| Movement | Charges halted short of contact | 0.1 | 0.4 |
| Movement | Idle units | 1.1 | 1.6 |
| Movement | Points that never moved of their own | 297.2 | 178.0 |
| Movement | Fights charged into per game | 2.5 | 4.0 |
| Movement | Charges with odds: long shots (under 50%) | 10 of 78, net +149 | 26 of 135, net -16 |
| Movement | Charges with odds: sweet spot (55-75%) | 8 of 78, net +128 | 26 of 135, net +153 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 7 of 78, net +71 | 9 of 135, net +61 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 28 of 78, net +115 | 29 of 135, net +146 |
| Shooting | Shots by shooting units (incl. breath weapons) | 9.9 | 11.4 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 47% (168 of 358) | 41% (169 of 409) |
| Shooting | Points destroyed by shooting units | 70.9 | 64.2 |
| Shooting | War machine shots | 6.1 | 2.6 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 56% (123 of 218) | 54% (50 of 93) |
| Shooting | Points destroyed by war machines | 53.0 | 32.9 |
| Magic | Magic missiles cast | 2.2 | 0.9 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 35% (28 of 79) | 27% (9 of 33) |
| Magic | Wounds caused by magic missiles | 3.8 | 1.0 |
| Magic | Wounds caused by other spells | 1.6 | 0.6 |
| Magic | Points destroyed by magic (all spells) | 56.8 | 27.8 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.3 / 0.8 / 0.7 / 0.1 | 1.9 / 0.6 / 0.5 / 0.1 |
| Combat | Points destroyed in combat | 372.1 | 352.3 |
| Combat | Points run down | 36.6 | 125.2 |
| Combat | Net points per charged fight, damage counted | +83 | +89 |
| Combat | Net per 100 charger points, damage counted | +30.3 | +34.3 |
| Combat | First round won (charged fights) | 79% | 72% |
| Combat | Net points per charged fight | +80 | +86 |
| Combat | Net points per supported fight / lone fight | +51 / +84 | +100 / +85 |
| Combat | Charged fights on a top-3 enemy unit | 22 of 90 | 54 of 145 |
| Game | Points lost | 780.7 | 651.8 |
| Game | VP from objectives | 527.2 | 619.2 |
| Game | Lone holders (player turns) | 2.5 | 2.2 |

- Mine won / drew / lost: 14 / 4 / 18 of 36 ended games (of 36); mean margin (Mine - Opponent) -233 VP
- The side that went first won 18 of 32 games with a winner
- Points traded per game (both sides' losses): 1433
- Games not ended: 0; findings 0, warnings 1

### Opponent rules: sp-h2h-opp-89601ea-p2

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 0.5 | +0.0 | 0.0 | 0.0 |
| ALREADY CARRIED | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARRIVAL HUNT | - | - | - | - | 0.1 | +2.4 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.3 | +0.0 | 0.0 | 55.7 | 0.1 | +0.0 | 0.0 | 3.5 |
| BACKUP TARGETS | 0.9 | +7.5 | 0.0 | 11.7 | 1.0 | +12.8 | 0.0 | 3.5 |
| BEST FACING | 0.8 | +20.9 | 0.0 | 23.4 | 0.6 | +24.2 | 0.0 | 6.7 |
| BEST FIRST | 4.9 | +249.0 | 173.0 | 116.8 | 4.2 | +201.2 | 155.9 | 24.9 |
| BEST MOVE FOR SHOOTERS | - | - | - | - | 1.2 | +114.0 | 0.0 | 37.3 |
| BEST OVERALL | 0.8 | +45.4 | 0.0 | 29.8 | 0.3 | +33.7 | 0.0 | 6.7 |
| BEST PREY | 0.9 | +43.3 | 37.4 | 23.1 | 0.6 | +25.8 | 5.8 | 9.0 |
| BEST PRIZE | 0.1 | -3.4 | 7.6 | 4.0 | 0.1 | -2.3 | 3.5 | 0.0 |
| BIG CHARACTER SAFETY | 0.1 | +0.4 | 0.0 | 0.0 | 0.1 | -0.4 | 0.0 | 13.1 |
| BLOCKED CHARGE SKIPPED | 0.1 | +0.0 | 3.1 | 0.0 | 0.0 | +0.0 | 0.0 | 1.4 |
| BLOCKED WHEEL | 0.4 | +21.5 | 0.0 | 0.0 | 0.4 | +7.4 | 0.0 | 0.0 |
| BOMBING RUN | 0.0 | +1.6 | 0.0 | 0.0 | - | - | - | - |
| BOUND ASSAILMENT | 0.1 | +0.0 | 0.0 | 11.9 | - | - | - | - |
| CANNON PLAN MISSED | 0.8 | +0.0 | 106.3 | 15.3 | - | - | - | - |
| CANNON PLANNED TARGET | 4.6 | +88.0 | 245.4 | 118.5 | - | - | - | - |
| CANNON SIGHT KEPT | 1.3 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 7.7 |
| CARRIES OUT COUNTER | 0.1 | -1.2 | 3.5 | 0.0 | 0.1 | +0.0 | 5.7 | 0.0 |
| CARRIES OUT SET-UP | 0.0 | +0.0 | 0.0 | 0.0 | 0.3 | -2.9 | 31.1 | 0.0 |
| CAST JOB | 0.6 | +10.6 | 45.2 | 16.6 | 0.4 | +6.5 | 13.0 | 20.4 |
| CASTER AWAY FROM SCREEN | 0.3 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.2 | +17.2 | 12.8 | 8.9 | 0.2 | +9.0 | 20.1 | 0.0 |
| CASTS AFTER FRIENDS | 0.4 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 7.6 |
| CASTS FROM BEHIND | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.0 | +0.6 | 0.0 | 0.0 | - | - | - | - |
| CATCH ODDS | 0.0 | +1.9 | 0.0 | 0.0 | 0.0 | +2.5 | 0.0 | 0.0 |
| CHAFF PASSED | 0.2 | -0.4 | 0.0 | 2.0 | - | - | - | - |
| CHARGE NOW FIRST | 2.2 | +0.0 | 196.2 | 60.2 | 4.0 | +0.0 | 403.4 | 134.7 |
| CHARGE NOW WEIGHED | 0.5 | -52.5 | 2.8 | 35.2 | 0.4 | -14.0 | 16.4 | 14.7 |
| CHARIOT NO STATIC JOB | 0.0 | +0.0 | 0.0 | 2.4 | - | - | - | - |
| CHARIOT WIZARD CAREFUL | 0.1 | +0.0 | 0.0 | 15.0 | - | - | - | - |
| CHEAP HELPER | 0.0 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 12.4 | 0.9 |
| COMBAT PIVOT | 0.3 | +0.0 | 28.6 | 9.6 | 0.6 | +0.0 | 42.5 | 11.4 |
| CONTINUE AHEAD WEIGHED | 0.0 | +0.0 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | 0.2 | +15.9 | 0.0 | 0.0 | 0.6 | +69.6 | 4.4 | 15.2 |
| COUNTER-CHARGE COVER | 10.3 | +925.8 | 0.0 | 279.3 | 6.8 | +797.1 | 0.0 | 155.5 |
| DEFENSIVE ARMY | 0.3 | +0.0 | 0.0 | 8.0 | 0.1 | +0.0 | 14.3 | 0.0 |
| DEFENSIVE FLOOR | - | - | - | - | 0.1 | +4.9 | 9.9 | 0.0 |
| EDGE GIVE GROUND | 0.1 | +4.0 | 6.7 | 7.1 | 0.5 | +11.8 | 71.5 | 1.9 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 2.1 | +182.3 | 0.0 | 74.6 | 1.2 | +108.7 | 0.0 | 32.3 |
| FALLBACK BY WORTH | 4.7 | +65.7 | 0.0 | 102.5 | 4.8 | +54.6 | 0.0 | 26.8 |
| FIGHT LIFT | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FIRE AND FLEE | 0.1 | +1.1 | 1.2 | 1.7 | 0.1 | +0.6 | 0.0 | 3.1 |
| FIRE IN ORDER | - | - | - | - | 0.7 | +0.0 | 24.2 | 9.9 |
| FIRE PLAN | - | - | - | - | 12.5 | +355.0 | 499.1 | 190.8 |
| FLANK NOT WEIGHED | 6.8 | +0.0 | 0.0 | 207.2 | 4.7 | +0.0 | 0.0 | 129.4 |
| FOCUS FIRE | 0.0 | +2.6 | 3.5 | 0.0 | - | - | - | - |
| FOLLOW UP WEIGHED | 1.1 | +145.0 | 0.0 | 39.3 | 0.8 | +119.2 | 0.0 | 33.6 |
| FRIENDS SHOTS CHECKED | 0.2 | +19.6 | 0.0 | 11.9 | 0.3 | +22.9 | 0.0 | 5.9 |
| GIVES UP | 0.0 | -0.4 | 0.0 | 0.0 | 0.1 | -1.3 | 0.0 | 0.0 |
| GIVES UP ITS SCREEN | - | - | - | - | 0.0 | -1.4 | 0.0 | 2.9 |
| GROUND FLIERS | 0.0 | +0.5 | 0.0 | 0.0 | - | - | - | - |
| HELPER ALREADY ASKED | 0.0 | +0.0 | 6.3 | 0.0 | 0.1 | +0.0 | 8.0 | 0.0 |
| HELPER UNSEEN | 0.2 | +0.0 | 31.5 | 1.8 | 0.4 | +0.0 | 16.4 | 5.8 |
| HILL BY ITS CHANCE | 0.4 | -47.0 | 0.0 | 6.9 | 0.6 | -58.9 | 0.0 | 3.8 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HORN WORTH | - | - | - | - | 0.0 | +0.1 | 0.0 | 0.0 |
| HUNT ADVANCE | 0.1 | +0.6 | 5.4 | 1.4 | 0.4 | +6.1 | 0.0 | 10.0 |
| HUNT DROPPED | 0.1 | +0.0 | 0.0 | 0.9 | 0.1 | +0.0 | 0.0 | 1.9 |
| HUNT IN PAIRS | 0.4 | +34.7 | 0.0 | 0.0 | 0.6 | +12.5 | 0.0 | 10.8 |
| HUNT KEPT | 0.1 | +0.4 | 5.4 | 0.0 | 0.3 | +4.0 | 4.6 | 7.1 |
| HUNT RESULT | 0.1 | +6.1 | 0.0 | 0.9 | 0.4 | +13.2 | 11.9 | 14.2 |
| HUNT THE GUNS | 0.1 | +28.2 | 5.4 | 1.4 | 0.4 | +171.0 | 9.2 | 11.1 |
| INVITES THE FIGHT | 1.7 | +31.3 | 43.1 | 25.1 | 1.3 | +27.0 | 49.4 | 32.1 |
| JOINT CHARGE PLAN | 0.0 | +0.1 | 0.0 | 0.0 | 0.2 | +9.1 | 11.5 | 6.0 |
| KEEP FALLS | 0.1 | +5.1 | 0.0 | 0.0 | - | - | - | - |
| KEEPS ITS PREY | 0.1 | +0.6 | 0.0 | 2.4 | 0.1 | +1.4 | 5.2 | 0.0 |
| KEEPS ITS TARGET | 1.3 | +38.3 | 87.5 | 23.2 | 2.4 | +71.7 | 225.4 | 78.6 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| KEEPS THE TARGET | - | - | - | - | 1.3 | -58.7 | 86.4 | 15.3 |
| KILLS COUNT | 1.6 | +67.2 | 130.3 | 54.2 | 2.4 | +95.4 | 180.1 | 57.5 |
| KILLS COUNT NEXT TURN | 4.5 | +160.5 | 99.5 | 78.7 | 7.0 | +266.9 | 247.9 | 124.8 |
| LONE CHARACTER SAFE SPOT | 0.3 | +28.9 | 15.3 | 6.3 | 0.1 | +0.9 | 9.9 | 16.4 |
| LONE WIZARD HOLDS BACK | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 1.7 | 16.0 |
| LONE WIZARD KEPT IN | 0.6 | +39.4 | 0.0 | 0.0 | 0.3 | +23.5 | 0.0 | 0.0 |
| LONG SHOT | 0.5 | -0.5 | 16.9 | 13.2 | 0.7 | -0.2 | 36.6 | 3.0 |
| LOST CHARGE | 2.9 | -54.1 | 85.2 | 97.6 | 2.5 | -65.5 | 92.7 | 42.4 |
| LURE BY WHAT IT DRAWS | 0.1 | -8.4 | 0.0 | 1.0 | - | - | - | - |
| MAKE SURE TOGETHER | 0.3 | +6.5 | 0.0 | 6.4 | 0.7 | +40.5 | 15.4 | 31.9 |
| MANOEUVRE | 0.2 | +3.2 | 0.0 | 14.3 | 0.1 | +8.3 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.0 | +0.6 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | 0.8 | +25.4 | 0.0 | 28.9 | 0.5 | +36.2 | 0.0 | 8.5 |
| MARCH ODDS | 0.4 | +31.8 | 20.9 | 23.5 | 0.3 | +40.3 | 4.6 | 6.2 |
| MARCH OVER CASTS | 0.4 | +46.8 | 0.0 | 18.0 | 0.3 | +30.8 | 0.0 | 19.4 |
| MAX FOR POSITIONING | 4.9 | +180.3 | 0.0 | 107.7 | 4.8 | +205.4 | 0.0 | 118.6 |
| MISSILES IN THE FIRE PLAN | - | - | - | - | 1.7 | +78.0 | 83.2 | 37.2 |
| MISSILES IN THE MOVE | 3.8 | +88.6 | 0.0 | 124.0 | 3.2 | +60.4 | 0.0 | 76.2 |
| MISSILES NEXT TURN | 4.2 | +57.1 | 0.0 | 137.8 | 3.5 | +43.2 | 0.0 | 85.3 |
| MODEL FACING | 0.2 | +51.6 | 0.0 | 3.3 | 0.2 | +44.8 | 0.0 | 1.7 |
| MONSTER WIZARD ROAMS | 0.2 | +0.0 | 15.0 | 10.2 | 0.3 | +0.0 | 24.1 | 0.0 |
| MOVE AND CAST | 0.4 | +33.4 | 0.0 | 6.5 | 0.3 | +10.9 | 0.0 | 12.6 |
| MOVE SPELL IN RANGE | 0.1 | +6.3 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL NOT WORTH | 0.0 | -0.0 | 0.0 | 0.0 | 0.1 | -0.0 | 0.0 | 0.0 |
| MOVE SPELL OUT OF RANGE | 0.3 | -11.3 | 2.2 | 2.6 | 0.3 | -10.8 | 2.9 | 7.6 |
| MOVE SPELL SPOT | 0.2 | +0.0 | 0.0 | 12.3 | 0.1 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE | 2.2 | +109.8 | 53.9 | 27.4 | 4.9 | +285.8 | 193.3 | 133.3 |
| MOVES UNITS SPELL | 0.1 | +3.4 | 0.0 | 0.0 | - | - | - | - |
| NEEDED THERE | 0.1 | +7.0 | 11.8 | 0.0 | - | - | - | - |
| NOT NEEDED | 0.2 | -9.1 | 21.4 | 7.4 | 0.3 | -22.2 | 25.6 | 1.2 |
| NOT TURNED | 6.5 | +73.1 | 0.0 | 183.9 | 4.9 | +33.6 | 0.0 | 112.5 |
| NOT WORTH A CAST | 0.3 | -0.2 | 0.0 | 0.0 | 0.6 | -0.5 | 0.0 | 0.0 |
| OFF BEST | 15.0 | -710.5 | 5.8 | 361.5 | 14.4 | -899.1 | 0.0 | 202.9 |
| OPENS A LANE | 0.1 | +0.4 | 0.0 | 0.0 | 0.1 | +0.1 | 2.0 | 3.5 |
| OPENS UP | 0.1 | +5.7 | 9.2 | 0.0 | 0.3 | +24.3 | 16.3 | 12.9 |
| OVERRUNS AWAY | 0.4 | +16.6 | 39.4 | 23.9 | 0.8 | +15.3 | 82.3 | 28.9 |
| PATHS CROSS | 2.1 | +138.9 | 0.0 | 16.1 | 2.7 | +198.3 | 0.0 | 61.4 |
| PERIAPT WORTH | - | - | - | - | 0.0 | +1.4 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.1 | -2.3 | 0.0 | 5.5 | 0.1 | -1.4 | 0.0 | 0.0 |
| PLAN RESULT | 36.9 | +1304.4 | 1389.9 | 1045.8 | 40.6 | +1150.0 | 1572.2 | 843.2 |
| PURSUES BIG PREY | 0.1 | -1.0 | 0.0 | 0.0 | 0.1 | -12.7 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE NEXT TURN | 0.1 | +8.3 | 0.0 | 3.4 | 0.0 | +3.3 | 0.0 | 0.0 |
| RANDOM MOVE BY FIGURES | 0.9 | +11.9 | 0.0 | 15.3 | 1.4 | +23.4 | 0.0 | 35.0 |
| RANDOM MOVER NO PROMISE | 0.3 | -31.7 | 0.0 | 4.7 | 0.3 | -21.6 | 30.6 | 0.0 |
| REDIRECT BY WHAT IT STOPS | 0.2 | +1.2 | 0.0 | 1.9 | 0.3 | -5.4 | 0.0 | 0.8 |
| REDIRECT COUNTER | 2.1 | +156.2 | 0.0 | 60.2 | 3.4 | +320.8 | 0.0 | 62.7 |
| REDIRECT WEIGHED | 0.1 | +3.2 | 0.0 | 0.0 | 0.4 | +7.6 | 12.5 | 13.7 |
| RESERVE FALL BACK | 0.1 | +2.6 | 0.0 | 0.0 | 1.2 | +49.2 | 0.0 | 18.2 |
| RESTRAINS TO SHOOT | 0.1 | +2.2 | 0.0 | 0.0 | 0.0 | +0.3 | 0.0 | 6.3 |
| RISK BY ARC | 2.1 | +83.6 | 199.3 | 54.0 | 3.8 | +83.7 | 376.6 | 77.3 |
| SAFER THAN THE JOB | 1.0 | +70.3 | 0.0 | 17.2 | 0.6 | +41.9 | 0.0 | 0.0 |
| SCOUT SPOT | 0.3 | +0.8 | 0.0 | 0.0 | 0.5 | +2.1 | 0.0 | 1.8 |
| SCOUT WAITS | 0.3 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 1.8 |
| SCREEN BY WHAT IT SAVES | 0.2 | -10.3 | 0.0 | 1.2 | 0.4 | -22.0 | 0.0 | 3.8 |
| SEARCH SPOT | 2.9 | +141.9 | 0.0 | 58.8 | 3.1 | +129.7 | 0.0 | 29.0 |
| SECOND HUNTER | 0.0 | -0.0 | 0.0 | 0.0 | 0.1 | -0.4 | 4.6 | 0.9 |
| SELF MOVE SPELL | 0.2 | +14.8 | 0.0 | 9.1 | - | - | - | - |
| SET UP TOGETHER | 0.6 | +22.8 | 0.0 | 10.9 | 1.5 | +115.4 | 54.4 | 44.0 |
| SET-UP ANY TARGET | 0.0 | +1.7 | 0.0 | 0.0 | 0.2 | +13.9 | 4.4 | 15.2 |
| SET-UP MISSED | - | - | - | - | 0.1 | +19.5 | 0.0 | 0.0 |
| SHOOTER COUNTED ONCE | - | - | - | - | 0.0 | -0.0 | 0.0 | 0.0 |
| SHOOTERS ARE THREATS | - | - | - | - | 3.2 | +298.0 | 102.2 | 48.2 |
| SHOOTERS IN TWO RANKS | 0.4 | +0.8 | 0.0 | 0.0 | 0.3 | +0.6 | 0.0 | 0.0 |
| SHOOTERS TO THE PRIMARY | - | - | - | - | 4.5 | +264.8 | 0.0 | 41.1 |
| SHOOTS FROM THE BEST SPOT | 1.1 | +50.3 | 35.3 | 26.8 | 0.6 | +20.0 | 44.2 | 9.9 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| SHOT OPTIONS | 14.6 | +0.0 | 523.0 | 290.5 | 13.6 | +0.0 | 417.7 | 205.4 |
| SHOT REPLANNED | 0.4 | +0.0 | 70.4 | 3.7 | - | - | - | - |
| SHOTS IN THE MOVE | 13.2 | +465.6 | 0.0 | 277.6 | 12.4 | +448.8 | 0.0 | 176.1 |
| SPELL SETS UP CHARGE | 0.1 | +19.4 | 0.0 | 0.0 | 0.2 | +43.8 | 4.4 | 15.2 |
| SPELL WORTH | 1.1 | +25.7 | 27.1 | 29.6 | 1.8 | +32.3 | 61.1 | 61.1 |
| STABLE ROLE | 11.4 | +0.0 | 415.3 | 164.6 | 11.7 | +0.0 | 388.8 | 161.4 |
| STANDS TO CAST | - | - | - | - | 0.1 | +4.4 | 0.0 | 0.0 |
| STAY WEIGHED | - | - | - | - | 0.0 | +2.4 | 0.0 | 0.0 |
| STAY WORTH | - | - | - | - | 13.9 | +106.6 | 212.6 | 170.3 |
| STOPS | 0.1 | +0.4 | 5.4 | 0.0 | 0.3 | +11.9 | 13.8 | 6.2 |
| STOPS SHORT OF THE FLANK | 0.4 | +25.3 | 0.0 | 12.6 | 0.4 | +15.7 | 0.0 | 34.2 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 8.8 |
| SUPPORT NARROWED | 6.0 | -48.5 | 372.0 | 131.9 | 7.2 | -51.8 | 405.5 | 117.7 |
| SUPPORTS | 4.4 | +48.5 | 208.9 | 81.9 | 4.0 | +54.3 | 159.8 | 46.2 |
| SURE CHARGE BEATS ADVANCE | 0.1 | -0.5 | 3.1 | 5.2 | 0.1 | -1.6 | 8.9 | 0.0 |
| SURE REACH TOGETHER | 0.4 | +0.9 | 0.0 | 2.4 | 0.6 | +9.9 | 1.8 | 13.5 |
| THREAT AT FULL SIZE | - | - | - | - | 6.7 | +0.0 | 269.6 | 96.8 |
| THROUGH LINE OF FIRE | 0.3 | +10.6 | 0.0 | 0.0 | 0.2 | +8.6 | 0.0 | 0.0 |
| TURN WORTH | 0.3 | -22.6 | 19.3 | 0.0 | 0.4 | -31.4 | 31.8 | 12.9 |
| TWO OR MORE ARRIVE | 0.1 | +0.4 | 0.0 | 6.4 | 0.5 | +1.6 | 22.4 | 6.0 |
| WAIT AFTER COSTS | 5.6 | -249.4 | 141.3 | 60.4 | 8.6 | -408.6 | 324.8 | 190.6 |
| WALKS TO THE FIGHT | 1.5 | +33.7 | 42.0 | 11.3 | 1.7 | +29.5 | 40.7 | 10.0 |
| WAR ENGINE CHARGES | 0.1 | +7.1 | 16.1 | 0.0 | 0.0 | +0.5 | 0.9 | 0.0 |
| WAR ENGINE JOBS | 0.6 | +0.0 | 41.3 | 11.4 | 0.1 | +0.0 | 13.8 | 20.6 |
| WEARS DOWN | 1.0 | +33.5 | 108.8 | 13.4 | 1.9 | +61.6 | 207.5 | 80.6 |
| WHO HITS BACK | 0.3 | +21.2 | 0.0 | 7.4 | 0.1 | +3.4 | 0.0 | 0.0 |
| WHOLE FIGHT | 0.2 | +3.9 | 33.8 | 5.9 | 0.6 | +13.1 | 56.8 | 7.8 |
| WHOLE FIGHT GAIN | 0.3 | +27.1 | 50.1 | 6.9 | 0.5 | +37.0 | 35.4 | 6.0 |

### Rule changes: sp-h2h-opp-89601ea-p2

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 1059 | 1059 | 1059 | 29.42 | -57943 | -54.7 |
| BEST FIRST | 330 | 330 | 330 | 9.17 | +16205 | +49.1 |
| SEARCH SPOT | 213 | 213 | 206 | 5.72 | +9808 | +47.6 |
| PATHS CROSS | 173 | 173 | 173 | 4.81 | +12137 | +70.2 |
| COUNTER-CHARGE COVER | 616 | 349 | 165 | 4.58 | +12000 | +72.7 |
| KILLS COUNT NEXT TURN | 412 | 412 | 130 | 3.61 | +4169 | +32.1 |
| FACES THE THREAT | 122 | 122 | 122 | 3.39 | +10478 | +85.9 |
| FIRE PLAN | 449 | 449 | 121 | 3.36 | +2557 | +21.1 |
| MOVE TO CHARGE | 256 | 256 | 120 | 3.33 | +4452 | +37.1 |
| SUPPORTS | 301 | 301 | 118 | 3.28 | +1219 | +10.3 |
| SHOTS IN THE MOVE | 925 | 646 | 96 | 2.67 | +2086 | +21.7 |
| FALLBACK BY WORTH | 341 | 341 | 79 | 2.19 | +4330 | +54.8 |
| WAIT AFTER COSTS | 509 | 509 | 74 | 2.06 | +1276 | +17.2 |
| CANNON SIGHT KEPT | 70 | 70 | 70 | 1.94 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 68 | 68 | 68 | 1.89 | +9514 | +139.9 |
| WALKS TO THE FIGHT | 115 | 115 | 66 | 1.83 | +860 | +13.0 |
| SAFER THAN THE JOB | 57 | 57 | 57 | 1.58 | +4040 | +70.9 |
| ARTILLERY RE-ROLL WEIGHED | 52 | 52 | 52 | 1.44 | +0 | +0.0 |
| BEST FACING | 48 | 48 | 48 | 1.33 | +1623 | +33.8 |
| REDIRECT COUNTER | 199 | 117 | 48 | 1.33 | +4251 | +88.6 |
| RESERVE FALL BACK | 47 | 47 | 47 | 1.31 | +1865 | +39.7 |
| BEST MOVE FOR SHOOTERS | 44 | 44 | 44 | 1.22 | +4104 | +93.3 |
| MARCH CHECK | 47 | 46 | 43 | 1.19 | +2569 | +59.8 |
| ADVANCE LANE KEPT | 42 | 42 | 42 | 1.17 | +0 | +0.0 |
| RANDOM MOVE BY FIGURES | 82 | 82 | 42 | 1.17 | +1271 | +30.3 |
| CHARGE NOW FIRST | 222 | 222 | 41 | 1.14 | -2021 | -49.3 |
| HOLDS AMBUSHERS | 40 | 40 | 40 | 1.11 | +0 | +0.0 |
| RISK BY ARC | 213 | 210 | 40 | 1.11 | +1468 | +36.7 |
| BEST OVERALL | 39 | 39 | 39 | 1.08 | +2845 | +73.0 |
| MAX FOR POSITIONING | 351 | 210 | 37 | 1.03 | +423 | +11.4 |
| CANNON PLANNED TARGET | 167 | 167 | 34 | 0.94 | +37 | +1.1 |
| LONE WIZARD KEPT IN | 33 | 33 | 33 | 0.92 | +2266 | +68.7 |
| COMBAT PIVOT | 32 | 32 | 32 | 0.89 | +0 | +0.0 |
| SCOUT WAITS | 32 | 32 | 32 | 0.89 | +0 | +0.0 |
| CHARGE NOW WEIGHED | 31 | 31 | 31 | 0.86 | +2522 | +81.3 |
| MISSILES IN THE MOVE | 252 | 160 | 31 | 0.86 | +643 | +20.8 |
| STOPS SHORT OF THE FLANK | 31 | 31 | 31 | 0.86 | +1477 | +47.6 |
| SET UP TOGETHER | 77 | 68 | 29 | 0.81 | +1887 | +65.1 |
| BLOCKED WHEEL | 27 | 27 | 27 | 0.75 | +1039 | +38.5 |
| KILLS COUNT | 143 | 142 | 27 | 0.75 | +1022 | +37.9 |
| MARCH ODDS | 27 | 27 | 27 | 0.75 | +674 | +25.0 |
| MOVE AND CAST | 27 | 27 | 27 | 0.75 | +1597 | +59.1 |
| SHOOTS FROM THE BEST SPOT | 63 | 63 | 27 | 0.75 | +830 | +30.7 |
| FIRE IN ORDER | 25 | 25 | 25 | 0.69 | +0 | +0.0 |
| SHOOTERS IN TWO RANKS | 25 | 25 | 25 | 0.69 | +50 | +2.0 |
| FRIENDS SHOTS CHECKED | 21 | 21 | 21 | 0.58 | +1531 | +72.9 |
| INVITES THE FIGHT | 108 | 108 | 19 | 0.53 | +431 | +22.7 |
| KEEPS ITS TARGET | 132 | 130 | 19 | 0.53 | +326 | +17.2 |
| KEEPS THE TARGET | 46 | 46 | 19 | 0.53 | -2352 | -123.8 |
| REDIRECT WEIGHED | 18 | 18 | 18 | 0.50 | +415 | +23.0 |
| STAY WORTH | 499 | 405 | 18 | 0.50 | +448 | +24.9 |
| THROUGH LINE OF FIRE | 18 | 18 | 18 | 0.50 | +691 | +38.4 |
| MODEL FACING | 17 | 17 | 17 | 0.47 | +3471 | +204.2 |
| BEST PREY | 54 | 54 | 15 | 0.42 | +547 | +36.5 |
| CAST JOB | 39 | 39 | 15 | 0.42 | +155 | +10.4 |
| CASTER AWAY FROM SCREEN | 15 | 15 | 15 | 0.42 | +0 | +0.0 |
| CASTS FROM BEHIND | 15 | 15 | 15 | 0.42 | +0 | +0.0 |
| SHOT REPLANNED | 15 | 15 | 15 | 0.42 | +0 | +0.0 |
| SHORT GUN FORWARD | 14 | 14 | 14 | 0.39 | +0 | +0.0 |
| WEARS DOWN | 106 | 102 | 14 | 0.39 | +423 | +30.2 |
| WHO HITS BACK | 14 | 14 | 14 | 0.39 | +546 | +39.0 |
| CASTING BLOCK | 15 | 15 | 13 | 0.36 | +517 | +39.8 |
| WHOLE FIGHT GAIN | 29 | 28 | 13 | 0.36 | +732 | +56.3 |
| STUCK PIVOT | 11 | 11 | 11 | 0.31 | +0 | +0.0 |
| MAKE SURE TOGETHER | 35 | 24 | 10 | 0.28 | +148 | +14.8 |
| CHAFF PASSED | 9 | 9 | 9 | 0.25 | -16 | -1.8 |
| OPENS UP | 15 | 15 | 9 | 0.25 | +409 | +45.4 |
| LOST CHARGE | 195 | 194 | 8 | 0.22 | +121 | +15.1 |
| PIVOT GUARDS FLANK | 8 | 8 | 8 | 0.22 | -135 | -16.8 |
| SHOOTERS TO THE PRIMARY | 163 | 126 | 8 | 0.22 | +241 | +30.2 |
| BEST PRIZE | 7 | 7 | 7 | 0.19 | -467 | -66.7 |
| BIG CHARACTER SAFETY | 7 | 7 | 7 | 0.19 | -2 | -0.2 |
| MISSILES NEXT TURN | 279 | 166 | 7 | 0.19 | +40 | +5.7 |
| PURSUES BIG PREY | 7 | 7 | 7 | 0.19 | -494 | -70.5 |
| WHOLE FIGHT | 32 | 31 | 7 | 0.19 | +304 | +43.4 |
| MANOEUVRE | 10 | 10 | 6 | 0.17 | +416 | +69.4 |
| SUPPORT NARROWED | 475 | 475 | 6 | 0.17 | -103 | -17.2 |
| SURE REACH TOGETHER | 35 | 23 | 6 | 0.17 | +68 | +11.4 |
| WAR ENGINE JOBS | 25 | 25 | 6 | 0.17 | -377 | -62.8 |
| OVERRUNS AWAY | 43 | 43 | 5 | 0.14 | +118 | +23.7 |
| SURE CHARGE BEATS ADVANCE | 5 | 5 | 5 | 0.14 | -74 | -14.9 |
| EDGE GIVE GROUND | 22 | 22 | 4 | 0.11 | +90 | +22.4 |
| FIRE AND FLEE | 4 | 4 | 4 | 0.11 | +60 | +15.1 |
| HUNT IN PAIRS | 36 | 19 | 4 | 0.11 | +109 | +27.2 |
| KEEPS SCOUTS OR AMBUSH | 4 | 4 | 4 | 0.11 | +0 | +0.0 |
| MOVES UNITS SPELL | 4 | 4 | 4 | 0.11 | +122 | +30.4 |
| RAIDS THE BAGGAGE NEXT TURN | 4 | 4 | 4 | 0.11 | +327 | +81.8 |
| RESTRAINS TO SHOOT | 4 | 4 | 4 | 0.11 | +92 | +22.9 |
| BLOCKED CHARGE SKIPPED | 3 | 3 | 3 | 0.08 | +0 | +0.0 |
| BOUND ASSAILMENT | 3 | 3 | 3 | 0.08 | +0 | +0.2 |
| KEEP FALLS | 3 | 3 | 3 | 0.08 | +216 | +71.9 |
| MISSILES IN THE FIRE PLAN | 61 | 13 | 3 | 0.08 | +63 | +21.1 |
| STOPS | 13 | 13 | 3 | 0.08 | +79 | +26.2 |
| BACKUP TARGETS | 69 | 36 | 2 | 0.06 | +34 | +17.0 |
| CARRIES OUT COUNTER | 6 | 6 | 2 | 0.06 | -42 | -20.9 |
| CARRIES OUT SET-UP | 11 | 11 | 2 | 0.06 | -105 | -52.4 |
| CATCH ODDS | 2 | 2 | 2 | 0.06 | -63 | -31.7 |
| CONTINUE AHEAD WEIGHED | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| JOINT CHARGE PLAN | 7 | 7 | 2 | 0.06 | +105 | +52.5 |
| LONG SHOT | 43 | 42 | 2 | 0.06 | -1 | -0.5 |
| MOVE SPELL IN RANGE | 4 | 3 | 2 | 0.06 | +31 | +15.4 |
| NEEDED THERE | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| REDIRECT BY WHAT IT STOPS | 18 | 18 | 2 | 0.06 | +58 | +29.2 |
| SHOOTERS ARE THREATS | 116 | 116 | 2 | 0.06 | +0 | +0.0 |
| STANDS TO CAST | 2 | 2 | 2 | 0.06 | -29 | -14.3 |
| THREAT AT FULL SIZE | 241 | 241 | 2 | 0.06 | +0 | +0.0 |
| BOMBING RUN | 1 | 1 | 1 | 0.03 | +58 | +58.5 |
| CHARIOT NO STATIC JOB | 1 | 1 | 1 | 0.03 | -128 | -127.6 |
| DEFENSIVE ARMY | 15 | 15 | 1 | 0.03 | -10 | -9.7 |
| DEFENSIVE FLOOR | 3 | 3 | 1 | 0.03 | +14 | +13.6 |
| FOCUS FIRE | 1 | 1 | 1 | 0.03 | +93 | +93.0 |
| HORN WORTH | 1 | 1 | 1 | 0.03 | +5 | +4.6 |
| HUNT ADVANCE | 17 | 17 | 1 | 0.03 | +31 | +30.8 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.03 | +52 | +51.9 |
| SCREEN BY WHAT IT SAVES | 22 | 22 | 1 | 0.03 | +22 | +22.1 |
| STAY WEIGHED | 1 | 1 | 1 | 0.03 | +87 | +87.2 |
| TURN WORTH | 25 | 25 | 1 | 0.03 | +28 | +28.2 |
| ALREADY CARRIED | 1 | not checked | - | - | - | - |
| ARRIVAL HUNT | 2 | 2 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 29 | 29 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 28 | trace | - | - | - | - |
| CATCH FLIERS | 1 | not checked | - | - | - | - |
| CHARIOT WIZARD CAREFUL | 3 | 3 | 0 | 0.00 | - | - |
| CHEAP HELPER | 7 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 28 | not checked | - | - | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT LIFT | 1 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 414 | not checked | - | - | - | - |
| GIVES UP | 5 | 4 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 1 | 1 | 0 | 0.00 | - | - |
| GROUND FLIERS | 1 | not checked | - | - | - | - |
| HELPER ALREADY ASKED | 3 | not checked | - | - | - | - |
| HELPER UNSEEN | 21 | 20 | 0 | 0.00 | - | - |
| HILL BY ITS CHANCE | 36 | 36 | 0 | 0.00 | - | - |
| HUNT DROPPED | 7 | trace | - | - | - | - |
| HUNT KEPT | 13 | trace | - | - | - | - |
| HUNT RESULT | 19 | trace | - | - | - | - |
| HUNT THE GUNS | 21 | trace | - | - | - | - |
| KEEPS ITS PREY | 7 | 7 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 17 | not checked | - | - | - | - |
| LONE WIZARD HOLDS BACK | 11 | 11 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 2 | 2 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 25 | 25 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 19 | 19 | 0 | 0.00 | - | - |
| MOVE SPELL NOT WORTH | 3 | not checked | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 21 | trace | - | - | - | - |
| MOVE SPELL SPOT | 11 | not checked | - | - | - | - |
| NOT NEEDED | 18 | 17 | 0 | 0.00 | - | - |
| NOT TURNED | 413 | 413 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 32 | not checked | - | - | - | - |
| OPENS A LANE | 4 | 4 | 0 | 0.00 | - | - |
| PLAN RESULT | 2791 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 22 | 22 | 0 | 0.00 | - | - |
| SCOUT SPOT | 28 | 28 | 0 | 0.00 | - | - |
| SECOND HUNTER | 4 | 4 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 8 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 7 | not checked | - | - | - | - |
| SET-UP MISSED | 4 | trace | - | - | - | - |
| SHOOTER COUNTED ONCE | 1 | 1 | 0 | 0.00 | - | - |
| SHOT OPTIONS | 1016 | 1016 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 12 | not checked | - | - | - | - |
| SPELL WORTH | 105 | not checked | - | - | - | - |
| STABLE ROLE | 831 | 829 | 0 | 0.00 | - | - |
| TWO OR MORE ARRIVE | 21 | 18 | 0 | 0.00 | - | - |
| WAR ENGINE CHARGES | 3 | 3 | 0 | 0.00 | - | - |

### Off best figure: sp-h2h-opp-89601ea-p2

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 13.06 | 13.31 | 56.0 |
| TURN GATE | gate | 0.83 | 0.42 | 34.2 |
| FALLBACK | gate | 0.69 | 0.47 | 45.5 |
| CHARGE NOW FIRST | rule | 0.42 | 0.72 | 49.3 |
| KEEPS THE TARGET | rule | - | 0.47 | 144.9 |
| PATHS CROSS | rule | 0.19 | 0.08 | 54.1 |
| FIRE PLAN | rule | - | 0.25 | 111.6 |
| BEST PRIZE | rule | 0.08 | 0.11 | 66.7 |
| CHARGE NOW WEIGHED | rule | 0.06 | 0.14 | 41.2 |
| LONE CHARACTER SAFE SPOT | gate | 0.17 | 0.03 | 94.7 |
| PIVOT GUARDS FLANK | rule | 0.11 | 0.08 | 19.2 |
| PURSUES BIG PREY | rule | 0.06 | 0.14 | 70.5 |
| MARCH ODDS | rule | 0.11 | 0.06 | 9.1 |
| SUPPORT NARROWED | rule | 0.11 | 0.06 | 17.2 |
| WAR ENGINE JOBS | rule | 0.11 | 0.06 | 62.8 |
| BLOCKED WHEEL | rule | 0.08 | 0.06 | 19.9 |
| CANNON PLANNED TARGET | rule | 0.14 | - | 4.3 |
| SURE CHARGE BEATS ADVANCE | rule | 0.06 | 0.08 | 14.9 |
| AFTERMATH BAND | gate | 0.06 | 0.06 | 2.1 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.06 | 0.03 | 60.8 |
| CHAFF PASSED | rule | 0.08 | - | 5.0 |
| NO REASON | gate | - | 0.08 | 105.2 |
| SUPPORT REQUEST | gate | 0.06 | 0.03 | 68.3 |
| BIG CHARACTER SAFETY | rule | - | 0.06 | 14.0 |
| CARRIES OUT COUNTER | rule | 0.06 | - | 20.9 |
| CARRIES OUT SET-UP | rule | - | 0.06 | 52.4 |
| CATCH ODDS | rule | 0.03 | 0.03 | 31.7 |
| FIGHT ORDER BAND | gate | 0.03 | 0.03 | 1.3 |
| FOLLOW UP WEIGHED | rule | - | 0.06 | 1.8 |
| REDIRECT WEIGHED | rule | - | 0.06 | 15.2 |
| STANDS TO CAST | rule | - | 0.06 | 14.3 |
| STOPS SHORT OF THE FLANK | rule | - | 0.06 | 14.0 |
| THROUGH LINE OF FIRE | rule | 0.06 | - | 22.4 |
| CHARIOT NO STATIC JOB | rule | 0.03 | - | 127.6 |
| DEFENSIVE ARMY | rule | - | 0.03 | 9.7 |
| LONG SHOT | rule | - | 0.03 | 3.1 |
| MOVE AND CAST | rule | - | 0.03 | 7.4 |
| RULE SWITCHED OFF | gate | 0.03 | - | 0.7 |

### Plans: sp-h2h-opp-89601ea-p2

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 12.6 | 18% | 531 | 351 | 66% |
| Mine | charge | 2.8 | 59% | 294 | 265 | 90% |
| Mine | close in | 3.1 | 22% | 165 | 69 | 42% |
| Mine | hold | 4.3 | 32% | 296 | 0 | 0% |
| Mine | join | 1.0 | 94% | 27 | 0 | 0% |
| Mine | shoot | 8.4 | 62% | 242 | 620 | 257% |
| Mine | support | 4.6 | 87% | 30 | 0 | 0% |
| Opponent | advance | 14.2 | 14% | 500 | 313 | 63% |
| Opponent | charge | 5.5 | 55% | 657 | 491 | 75% |
| Opponent | close in | 5.7 | 29% | 449 | 92 | 20% |
| Opponent | hold | 4.1 | 39% | 309 | 0 | 0% |
| Opponent | join | 0.8 | 89% | 30 | 0 | 0% |
| Opponent | shoot | 5.8 | 53% | 509 | 254 | 50% |
| Opponent | support | 4.5 | 92% | 44 | 0 | 0% |

### Packages: hunt the guns, sp-h2h-opp-89601ea-p2

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.1 | 5 | 0 | 20% | 20% | 0% | 3.0 | 203 | 44 | 20% | 29 |
| Opponent | 0.4 | 16 | 2 | 7% | 7% | 0% | 3.0 | 402 | 34 | 7% | 69 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.5 | 2 | 0 | 0% | 0% | 0% | - | 196 | 0 | 0% | 13 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 106 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 30 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 56 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 50 |
| High Elf Realms | 0.2 | 1 | 0 | 100% | 100% | 0% | 3.0 | 233 | 221 | 100% | 0 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 138 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Ogre Kingdoms | 1.2 | 5 | 0 | 20% | 20% | 0% | 3.0 | 432 | 95 | 20% | 113 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 277 |
| Tomb Kings of Khemri | 1.0 | 5 | 1 | 0% | 0% | 0% | - | 208 | 0 | 0% | 0 |
| Vampire Counts | 0.2 | 2 | 0 | 0% | 0% | 0% | - | 431 | 0 | 0% | 0 |
| Warriors of Chaos | 0.4 | 4 | 1 | 0% | 0% | 0% | - | 477 | 0 | 0% | 70 |
| Wood Elf Realms | 0.3 | 2 | 0 | 0% | 0% | 0% | - | 368 | 0 | 0% | 0 |

### Battle groups: sp-h2h-opp-89601ea-p2

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 10.3 | 25% | 53% | 9% | 12% | 29% | 16% | 9% | 45% | 0% |
| Mine | REDIRECT COUNTER | 2.1 | 35% | 63% | 22% | 33% | 10% | 0% | 19% | 71% | 0% |
| Opponent | COUNTER-CHARGE COVER | 6.8 | 24% | 68% | 27% | 38% | 33% | 9% | 16% | 42% | 0% |
| Opponent | REDIRECT COUNTER | 3.4 | 24% | 69% | 31% | 11% | 10% | 5% | 20% | 65% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: sp-h2h-opp-89601ea-p2

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 5 | 0 (5) | 0 | 0 | 52 | 20% | 3.8 | 0 (1) | 0 (1) | - | - | 0 (2) |
| Mine | Chaff | 35 | 47 (35) | 8 | 39 | 79 | 40% | 2.7 | 50 (19) | 14 (7) | 65 (9) | 55 (24) | 29 (11) |
| Mine | Character | 123 | 54 (123) | 53 | 1 | 31 | 16% | 2.5 | 66 (39) | 62 (51) | 7 (13) | 68 (50) | 50 (53) |
| Mine | Clean-up | 20 | 32 (20) | 0 | 32 | 54 | 55% | 2.9 | 18 (5) | 27 (12) | 95 (3) | 69 (12) | 0 (8) |
| Mine | Fast | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Mine | Fast Hammer | 44 | 41 (44) | 16 | 25 | 59 | 27% | 2.8 | 36 (21) | 57 (16) | 23 (7) | 41 (27) | 41 (17) |
| Mine | Fragile | 5 | 0 (5) | 0 | 0 | 40 | 0% | 1.6 | - | 0 (3) | 0 (2) | 0 (5) | - |
| Mine | Hammer | 57 | 31 (57) | 20 | 10 | 42 | 18% | 2.6 | 11 (18) | 41 (29) | 39 (10) | 31 (38) | 31 (19) |
| Mine | Holder | 29 | 47 (29) | 14 | 33 | 31 | 31% | 3.5 | 71 (10) | 46 (12) | 15 (7) | 42 (21) | 62 (8) |
| Mine | Shooter | 44 | 77 (44) | 25 | 52 | 42 | 2% | 1.7 | 77 (7) | 77 (30) | 77 (7) | 114 (26) | 27 (18) |
| Mine | Support | 2 | 0 (2) | 0 | 0 | 0 | 50% | 5.0 | - | 0 (1) | 0 (1) | - | 0 (2) |
| Mine | War machine | 59 | 35 (59) | 35 | 0 | 53 | 3% | 1.2 | 13 (10) | 46 (37) | 12 (12) | 25 (10) | 37 (49) |
| Mine | Wizard | 22 | 8 (22) | 8 | 0 | 45 | 18% | 2.0 | 7 (7) | 25 (7) | 0 (5) | 23 (6) | 5 (13) |
| Opponent | Blocker | 2 | 0 (2) | 0 | 0 | 62 | 50% | 4.0 | 0 (1) | 0 (1) | - | - | 0 (2) |
| Opponent | Chaff | 76 | 48 (76) | 21 | 27 | 43 | 38% | 2.6 | 51 (32) | 49 (19) | 43 (25) | 65 (54) | 8 (22) |
| Opponent | Character | 94 | 55 (94) | 55 | 0 | 30 | 23% | 2.6 | 57 (43) | 64 (38) | 34 (4) | 55 (57) | 64 (28) |
| Opponent | Clean-up | 21 | 58 (21) | 34 | 24 | 38 | 29% | 2.6 | 40 (9) | 76 (12) | - | 60 (15) | 54 (6) |
| Opponent | Early | 2 | 58 (2) | 58 | 0 | 0 | 50% | 4.0 | - | 58 (2) | - | 116 (1) | 0 (1) |
| Opponent | Fast Hammer | 48 | 44 (48) | 35 | 9 | 34 | 25% | 2.6 | 35 (22) | 43 (16) | 66 (10) | 41 (28) | 50 (20) |
| Opponent | Fragile | 5 | 16 (5) | 16 | 0 | 80 | 20% | 2.8 | - | 26 (3) | 0 (1) | 24 (3) | 0 (1) |
| Opponent | Hammer | 68 | 36 (68) | 34 | 2 | 42 | 26% | 2.6 | 39 (17) | 37 (40) | 25 (11) | 52 (42) | 11 (26) |
| Opponent | Holder | 35 | 91 (35) | 22 | 69 | 22 | 34% | 3.0 | 103 (5) | 135 (19) | 19 (7) | 139 (19) | 47 (12) |
| Opponent | Shooter | 33 | 77 (33) | 21 | 55 | 40 | 3% | 1.8 | 65 (8) | 82 (19) | 73 (6) | 109 (22) | 28 (11) |
| Opponent | Support | 3 | 0 (3) | 0 | 0 | 0 | 67% | 5.0 | 0 (2) | 0 (1) | - | 0 (1) | 0 (2) |
| Opponent | War machine | 24 | 37 (24) | 37 | 0 | 23 | 12% | 1.4 | 18 (6) | 46 (14) | 30 (4) | 0 (3) | 42 (21) |
| Opponent | Wizard | 29 | 17 (29) | 17 | 0 | 42 | 7% | 1.6 | 0 (10) | 42 (9) | 4 (7) | 30 (11) | 3 (15) |

### Charged fights: sp-h2h-opp-89601ea-p2

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 73 | 202 | 1.0 | 1.2 | 202 | 388 | -186 | 1 of 4 | 3 of 4 | +55 | -267 |
| Mine | Chaos Dwarfs | 4 | 202 | 266 | 1.5 | 1.0 | 177 | 0 | +177 | 5 of 6 | 5 of 6 | - | +177 |
| Mine | Dwarfen Mountain Holds | 4 | 404 | 44 | 1.5 | 1.2 | 30 | 0 | +30 | 2 of 6 | 4 of 6 | +0 | +36 |
| Mine | Empire of Man | 5 | 342 | 127 | 1.2 | 1.2 | 106 | 17 | +89 | 1 of 6 | 5 of 6 | +572 | -8 |
| Mine | Grand Cathay | 4 | 237 | 127 | 3.0 | 1.3 | 42 | 31 | +12 | 2 of 12 | 11 of 12 | +47 | -0 |
| Mine | High Elf Realms | 4 | 80 | 557 | 3.8 | 1.1 | 149 | 8 | +140 | 4 of 15 | 12 of 15 | +195 | +136 |
| Mine | Kingdom of Bretonnia | 1 | 0 | 1334 | 5.0 | 1.0 | 267 | 16 | +251 | 2 of 5 | 4 of 5 | - | +251 |
| Mine | Lizardmen | 1 | 45 | 1023 | 3.0 | 1.0 | 341 | 0 | +341 | 1 of 3 | 1 of 3 | - | +341 |
| Mine | Ogre Kingdoms | 1 | 0 | 75 | 6.0 | 1.3 | 12 | 0 | +12 | 0 of 6 | 2 of 2 | +0 | +19 |
| Mine | Orc & Goblin Tribes | 1 | 50 | 295 | 4.0 | 1.2 | 74 | 0 | +74 | 0 of 4 | 2 of 3 | +45 | +83 |
| Mine | Skaven | 2 | 143 | 0 | 1.0 | 1.0 | 0 | 46 | -46 | 0 of 2 | 1 of 2 | - | -46 |
| Mine | Tomb Kings of Khemri | 1 | 432 | 474 | 6.0 | 1.0 | 79 | 0 | +79 | 2 of 6 | 6 of 6 | - | +79 |
| Mine | Vampire Counts | 3 | 0 | 237 | 4.3 | 1.2 | 55 | 67 | -13 | 2 of 13 | 9 of 13 | -196 | +21 |
| Mine | Warriors of Chaos | 1 | 0 | 1052 | 2.0 | 1.0 | 526 | 0 | +526 | 0 of 2 | 2 of 2 | - | +526 |
| **Mine** | all armies | 36 | 181 | 288 | 2.5 | 1.1 | 115 | 36 | +80 | 22 of 90 | 67 of 85 | +51 | +84 |
| Opponent | Dwarfen Mountain Holds | 2 | 163 | 185 | 4.0 | 1.0 | 46 | 0 | +46 | 0 of 8 | 7 of 8 | - | +46 |
| Opponent | Empire of Man | 2 | 424 | 102 | 3.0 | 1.2 | 34 | 85 | -51 | 1 of 6 | 5 of 6 | +0 | -61 |
| Opponent | Grand Cathay | 2 | 491 | 640 | 4.5 | 1.3 | 142 | 47 | +95 | 5 of 9 | 7 of 9 | +210 | +81 |
| Opponent | Kingdom of Bretonnia | 1 | 60 | 105 | 1.0 | 1.0 | 105 | 0 | +105 | 0 of 1 | 1 of 1 | - | +105 |
| Opponent | Ogre Kingdoms | 3 | 89 | 295 | 4.7 | 1.1 | 63 | 2 | +61 | 3 of 14 | 10 of 14 | +0 | +65 |
| Opponent | Skaven | 1 | 189 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Tomb Kings of Khemri | 4 | 158 | 444 | 3.5 | 1.1 | 127 | 95 | +32 | 8 of 14 | 9 of 14 | +70 | +26 |
| Opponent | Vampire Counts | 6 | 9 | 782 | 5.5 | 1.2 | 142 | 41 | +101 | 14 of 33 | 21 of 33 | +152 | +92 |
| Opponent | Warriors of Chaos | 8 | 7 | 392 | 3.2 | 1.1 | 121 | 11 | +110 | 11 of 26 | 19 of 26 | +0 | +119 |
| Opponent | Wood Elf Realms | 7 | 154 | 641 | 4.9 | 1.1 | 132 | 14 | +118 | 12 of 34 | 25 of 34 | +125 | +117 |
| **Opponent** | all armies | 36 | 125 | 470 | 4.0 | 1.1 | 117 | 30 | +86 | 54 of 145 | 104 of 145 | +100 | +85 |

### Effective charges: sp-h2h-opp-89601ea-p2

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 0 | 0 | 0 | 1 (net +55) | 0 | 3 (net -267) | 0 | 0% (0 of 4) |
| Mine | Chaos Dwarfs | 6 | 2 (net +108) | 0 | 0 | 4 (net +211) | 0 | 0 | 0 | 0% (0 of 6) |
| Mine | Dwarfen Mountain Holds | 6 | 1 (net +0) | 0 | 0 | 2 (net +68) | 0 | 2 (net +20) | 1 | 0% (0 of 5) |
| Mine | Empire of Man | 6 | 0 | 0 | 1 (net -104) | 0 | 1 (net +0) | 2 (net +318) | 2 | 25% (1 of 4) |
| Mine | Grand Cathay | 12 | 1 (net +102) | 0 | 1 (net +0) | 4 (net -82) | 3 (net +60) | 3 (net +62) | 0 | 8% (1 of 12) |
| Mine | High Elf Realms | 15 | 0 | 2 (net +0) | 1 (net +0) | 1 (net +0) | 2 (net +132) | 6 (net +291) | 3 | 8% (1 of 12) |
| Mine | Kingdom of Bretonnia | 5 | 0 | 0 | 2 (net +542) | 1 (net +0) | 0 | 1 (net +0) | 1 | 50% (2 of 4) |
| Mine | Lizardmen | 3 | 2 (net +486) | 0 | 0 | 0 | 1 (net +50) | 0 | 0 | 0% (0 of 3) |
| Mine | Ogre Kingdoms | 6 | 0 | 0 | 0 | 3 (net +0) | 0 | 2 (net +38) | 1 | 0% (0 of 5) |
| Mine | Orc & Goblin Tribes | 4 | 1 (net +190) | 0 | 1 (net +45) | 0 | 0 | 0 | 2 | 50% (1 of 2) |
| Mine | Skaven | 2 | 0 | 0 | 0 | 1 (net -92) | 0 | 1 (net +0) | 0 | 0% (0 of 2) |
| Mine | Tomb Kings of Khemri | 6 | 0 | 0 | 1 (net +0) | 1 (net +125) | 0 | 3 (net +78) | 1 | 20% (1 of 5) |
| Mine | Vampire Counts | 13 | 3 (net +3) | 2 (net -63) | 1 (net +0) | 3 (net -63) | 0 | 3 (net +13) | 1 | 8% (1 of 12) |
| Mine | Warriors of Chaos | 2 | 0 | 0 | 0 | 0 | 0 | 2 (net +526) | 0 | 0% (0 of 2) |
| Opponent | Dwarfen Mountain Holds | 8 | 1 (net +0) | 0 | 2 (net +42) | 4 (net +51) | 0 | 1 (net +81) | 0 | 25% (2 of 8) |
| Opponent | Empire of Man | 6 | 0 | 0 | 2 (net -184) | 2 (net +0) | 2 (net +32) | 0 | 0 | 33% (2 of 6) |
| Opponent | Grand Cathay | 9 | 1 (net +210) | 0 | 2 (net +182) | 4 (net +122) | 0 | 1 (net +0) | 1 | 25% (2 of 8) |
| Opponent | Kingdom of Bretonnia | 1 | 0 | 1 (net +105) | 0 | 0 | 0 | 0 | 0 | 0% (0 of 1) |
| Opponent | Ogre Kingdoms | 14 | 3 (net +130) | 1 (net +0) | 0 | 4 (net +115) | 0 | 3 (net +0) | 3 | 0% (0 of 11) |
| Opponent | Tomb Kings of Khemri | 14 | 3 (net -264) | 0 | 1 (net +140) | 4 (net +90) | 0 | 4 (net +146) | 2 | 8% (1 of 12) |
| Opponent | Vampire Counts | 33 | 8 (net -87) | 1 (net -54) | 7 (net +218) | 11 (net +89) | 2 (net +56) | 4 (net +364) | 0 | 21% (7 of 33) |
| Opponent | Warriors of Chaos | 26 | 3 (net +14) | 0 | 8 (net +149) | 3 (net +171) | 3 (net +0) | 8 (net +138) | 1 | 32% (8 of 25) |
| Opponent | Wood Elf Realms | 34 | 7 (net +62) | 3 (net +74) | 4 (net +257) | 7 (net +74) | 2 (net +188) | 8 (net +127) | 3 | 13% (4 of 31) |

### Charged fights, damage counted: sp-h2h-opp-89601ea-p2

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 10 | 283 | 238 | +149 | 178 | 31 | +147 | +52.1 |
| Mine | 50-54% | 4 | 148 | 161 | -32 | 28 | 89 | -62 | -41.6 |
| Mine | Effective (55-75%) | 8 | 389 | 241 | +128 | 181 | 55 | +125 | +32.2 |
| Mine | 76-89% | 21 | 238 | 175 | +26 | 72 | 46 | +26 | +11.0 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 28 | 256 | 143 | +115 | 196 | 69 | +127 | +49.5 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 7 | 390 | 92 | +71 | 80 | 9 | +71 | +18.3 |
| Mine | No odds | 12 | 277 | 153 | +45 | 70 | 13 | +57 | +20.6 |
| Mine | All fights | 90 | 275 | 168 | +80 | 130 | 47 | +83 | +30.3 |
| Opponent | Long shot (under 50%) | 26 | 230 | 277 | -16 | 117 | 121 | -4 | -1.8 |
| Opponent | 50-54% | 6 | 215 | 190 | +45 | 62 | 63 | -0 | -0.2 |
| Opponent | Effective (55-75%) | 26 | 250 | 199 | +153 | 205 | 60 | +145 | +58.0 |
| Opponent | 76-89% | 39 | 248 | 181 | +90 | 115 | 13 | +102 | +41.0 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 29 | 274 | 205 | +146 | 154 | 13 | +141 | +51.4 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 9 | 380 | 78 | +61 | 87 | 11 | +76 | +20.1 |
| Opponent | No odds | 10 | 266 | 200 | +38 | 94 | 50 | +44 | +16.6 |
| Opponent | All fights | 145 | 258 | 202 | +86 | 134 | 45 | +89 | +34.3 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| sp-h2h-opp-89601ea-p2 | move | 467 | 100 (21%) | 65 (14%) | 67 (14%) | 300 (64%) |
| sp-h2h-opp-89601ea-p2 | objective | 319 | 66 (21%) | 45 (14%) | 49 (15%) | 204 (64%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0106, L0122, L2429, L2535, L2735 |
| Charmed Shield | Opponent | L0425, L0827, L0934, L1026, L1727, L1827, L1927 |
| Clockwork Compass | Mine | L1228 |
| Clockwork Compass | Opponent | L0512 |
| Elixir of Power | Mine | L1118, L1135, L1927 |
| Fistful of Laurels | Mine | L1827 |
| Fistful of Laurels | Opponent | L0918, L1118, L1418 |
| Horn of the Wild Hunt | Opponent | L3033 |
| Invocation of Nehek | Mine | L2429, L2535, L2735 |
| Invocation of Nehek | Opponent | L0425, L0827, L1727, L1827, L1927 |
| Opal Amulet | Mine | L1418, L1435 |
| Periapt of Soul Exchange | Mine | L2029, L2131 |
| Periapt of Soul Exchange | Opponent | L0721 |
| Ring of Doom | Mine | L0206, L0222, L1118, L1135, L1228, L1531 |
| Ring of Doom | Opponent | L0512, L1531, L2131, L3033 |
| Ring of Jet | Mine | L1026, L1118, L1135, L1228 |
| Ring of Jet | Opponent | L0512, L0810 |
| Standard of the Fell Warrior | Mine | L1323 |
| Storm Daemon (Renegade 2.0) | Mine | L2131 |
| Storm Daemon (Renegade 2.0) | Opponent | L0721 |
| Twice-Blessed Armour | Mine | L0721, L1026 |
| Twice-Blessed Armour | Opponent | L0307, L0810 |
| Witch Hunter's Ward | Mine | L0721, L0810, L0827 |
| Witch Hunter's Ward | Opponent | L0307 |

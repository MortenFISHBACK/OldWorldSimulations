# Doctrine scorecard: sp-h2h-mine-89601ea-p2

### Scorecard: sp-h2h-mine-89601ea-p2

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0106 | 4 | 1 | Mine | no | 2 | - | 0 | 1 | 0 | 0 | 0 | 65 |
| L0106 | 4 | 1 | Opponent | no | 0 | 2 | 0 | 1 | 1 | 0 | 0 | 798 |
| L0122 | 2 | 1 | Mine | - | - | - | 1 | 1 | 1 | 0 | 0 | 322 |
| L0122 | 2 | 1 | Opponent | - | - | 2 | 2 | 0 | 0 | 0 | 0 | 0 |
| L0206 | 2 | 1 | Mine | - | - | - | 1 | 3 | 0 | 0 | 0 | 0 |
| L0206 | 2 | 1 | Opponent | - | - | 2 | 4 | 1 | 0 | 0 | 0 | 615 |
| L0222 | 6 | 1 | Mine | no | 12 | 3 | 3 | 2 | 1 | 0 | 0 | 200 |
| L0222 | 6 | 1 | Opponent | no | 17 | 2 | 5 | 0 | 0 | 0 | 0 | 72 |
| L0307 | 1 | 1 | Mine | yes | 3 | 2 | 4 | 1 | 0 | 0 | 0 | 675 |
| L0307 | 1 | 1 | Opponent | yes | 3 | 3 | 1 | 1 | 1 | 0 | 0 | 420 |
| L0323 | 5 | 1 | Mine | no | - | 4 | 1 | 1 | 0 | 0 | 0 | 590 |
| L0323 | 5 | 1 | Opponent | yes | - | 2 | 4 | 2 | 0 | 0 | 0 | 0 |
| L0409 | 1 | 1 | Mine | no | 4 | 2 | 5 | 1 | 1 | 0 | 0 | 0 |
| L0409 | 1 | 1 | Opponent | no | 7 | 3 | 0 | 1 | 0 | 0 | 0 | 564 |
| L0425 | 5 | 1 | Mine | yes | - | 2 | 1 | 4 | 0 | 0 | 0 | 0 |
| L0425 | 5 | 1 | Opponent | yes | - | 2 | 4 | 5 | 0 | 0 | 0 | 254 |
| L0512 | 2 | 1 | Mine | - | - | - | 2 | 1 | 0 | 0 | 0 | 1448 |
| L0512 | 2 | 1 | Opponent | - | - | 2 | 0 | 1 | 0 | 0 | 0 | 330 |
| L0528 | 6 | 1 | Mine | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 1120 |
| L0528 | 6 | 1 | Opponent | no | 5 | 5 | 0 | 2 | 0 | 0 | 0 | 0 |
| L0616 | 4 | 1 | Mine | no | 1 | 4 | 2 | 0 | 1 | 0 | 0 | 615 |
| L0616 | 4 | 1 | Opponent | no | 4 | 3 | 4 | 0 | 2 | 0 | 0 | 200 |
| L0632 | 2 | 1 | Mine | - | - | 2 | 1 | 1 | 0 | 0 | 0 | 743 |
| L0632 | 2 | 1 | Opponent | - | - | 2 | 5 | 3 | 0 | 0 | 0 | 340 |
| L0721 | 1 | 1 | Mine | no | 2 | 2 | 5 | 0 | 0 | 0 | 0 | 558 |
| L0721 | 1 | 1 | Opponent | yes | 6 | - | 1 | 2 | 1 | 0 | 0 | 355 |
| L0810 | 6 | 1 | Mine | no | 4 | 4 | 1 | 2 | 0 | 0 | 0 | 971 |
| L0810 | 6 | 1 | Opponent | no | 8 | 2 | 2 | 0 | 0 | 0 | 0 | 330 |
| L0827 | 5 | 1 | Mine | no | - | 4 | 1 | 1 | 0 | 0 | 0 | 515 |
| L0827 | 5 | 1 | Opponent | yes | - | 2 | 5 | 6 | 0 | 0 | 0 | 0 |
| L0918 | 6 | 1 | Mine | no | 0 | 3 | 3 | 1 | 0 | 0 | 0 | 420 |
| L0918 | 6 | 1 | Opponent | no | 10 | 5 | 1 | 1 | 1 | 0 | 0 | 419 |
| L0934 | 4 | 1 | Mine | no | 0 | 1 | 1 | 1 | 0 | 0 | 0 | 988 |
| L0934 | 4 | 1 | Opponent | yes | 3 | 2 | 6 | 1 | 0 | 0 | 0 | 0 |
| L1026 | 6 | 1 | Mine | no | 12 | 2 | 2 | 0 | 1 | 0 | 0 | 330 |
| L1026 | 6 | 1 | Opponent | no | 1 | 2 | 4 | 2 | 0 | 0 | 0 | 0 |
| L1118 | 2 | 1 | Mine | - | - | 2 | 2 | 0 | 0 | 0 | 0 | 330 |
| L1118 | 2 | 1 | Opponent | - | - | - | 2 | 2 | 0 | 0 | 0 | 459 |
| L1135 | 1 | 1 | Mine | yes | 5 | 2 | 1 | 0 | 0 | 0 | 0 | 598 |
| L1135 | 1 | 1 | Opponent | no | 0 | 2 | 5 | 2 | 0 | 0 | 0 | 0 |
| L1228 | 4 | 1 | Mine | no | 1 | 6 | 1 | 0 | 0 | 0 | 0 | 524 |
| L1228 | 4 | 1 | Opponent | no | 3 | - | 1 | 2 | 0 | 0 | 0 | 0 |
| L1323 | 3 | 1 | Mine | yes | 6 | 2 | 1 | 1 | 1 | 0 | 0 | 140 |
| L1323 | 3 | 1 | Opponent | no | 0 | 1 | 1 | 0 | 1 | 0 | 0 | 66 |
| L1418 | 2 | 1 | Mine | - | - | 2 | 6 | 0 | 0 | 0 | 0 | 0 |
| L1418 | 2 | 1 | Opponent | - | - | 2 | 2 | 3 | 0 | 0 | 0 | 0 |
| L1435 | 1 | 1 | Mine | no | 0 | 3 | 1 | 0 | 0 | 0 | 0 | 0 |
| L1435 | 1 | 1 | Opponent | no | 0 | 3 | 5 | 3 | 0 | 0 | 0 | 140 |
| L1531 | 1 | 1 | Mine | no | 4 | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L1531 | 1 | 1 | Opponent | no | 1 | 3 | 3 | 2 | 1 | 0 | 0 | 340 |
| L1629 | 3 | 1 | Mine | no | 4 | 1 | 4 | 1 | 0 | 0 | 0 | 596 |
| L1629 | 3 | 1 | Opponent | no | 3 | 2 | 2 | 1 | 1 | 0 | 0 | 170 |
| L1727 | 5 | 1 | Mine | no | - | 3 | 4 | 0 | 0 | 0 | 0 | 135 |
| L1727 | 5 | 1 | Opponent | yes | - | 2 | 10 | 4 | 0 | 0 | 0 | 0 |
| L1827 | 3 | 1 | Mine | no | 1 | - | 1 | 1 | 0 | 0 | 0 | 305 |
| L1827 | 3 | 1 | Opponent | no | 6 | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| L1927 | 1 | 1 | Mine | no | 1 | 1 | 1 | 1 | 0 | 0 | 0 | 0 |
| L1927 | 1 | 1 | Opponent | no | 0 | 2 | 5 | 3 | 1 | 0 | 0 | 0 |
| L2029 | 1 | 1 | Mine | no | 2 | - | 1 | 1 | 0 | 0 | 0 | 715 |
| L2029 | 1 | 1 | Opponent | no | 0 | 2 | 6 | 0 | 0 | 0 | 0 | 170 |
| L2131 | 1 | 1 | Mine | yes | 4 | 4 | 3 | 3 | 1 | 0 | 0 | 145 |
| L2131 | 1 | 1 | Opponent | no | 1 | 2 | 5 | 1 | 0 | 0 | 0 | 170 |
| L2235 | 3 | 1 | Mine | no | 2 | 3 | 5 | 0 | 0 | 0 | 0 | 0 |
| L2235 | 3 | 1 | Opponent | no | 0 | 3 | 4 | 0 | 0 | 0 | 0 | 240 |
| L2429 | 5 | 1 | Mine | yes | - | 3 | 3 | 1 | 0 | 0 | 0 | 0 |
| L2429 | 5 | 1 | Opponent | yes | - | 3 | 4 | 1 | 1 | 0 | 0 | 0 |
| L2535 | 3 | 1 | Mine | no | 5 | 3 | 3 | 2 | 1 | 0 | 0 | 0 |
| L2535 | 3 | 1 | Opponent | no | 4 | 1 | 5 | 1 | 0 | 0 | 0 | 0 |
| L2735 | 5 | 1 | Mine | yes | - | 5 | 3 | 3 | 0 | 0 | 0 | 0 |
| L2735 | 5 | 1 | Opponent | yes | - | 1 | 5 | 4 | 1 | 0 | 0 | 0 |
| L3033 | 3 | 1 | Mine | yes | 6 | 2 | 3 | 2 | 0 | 0 | 0 | 0 |
| L3033 | 3 | 1 | Opponent | no | 0 | 1 | 7 | 1 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 27% | 3.4 | 2.7 | 2.2 | 1.1 | 0.2 | 0.0 | 0.0 | 362.4 |
| **Average** | | | Opponent | 30% | 3.4 | 2.3 | 3.4 | 1.7 | 0.3 | 0.0 | 0.0 | 179.2 |

### KPIs: sp-h2h-mine-89601ea-p2

Rules off - Opponent only: STAY WORTH, BEST MOVE FOR SHOOTERS, FACE THE CAST, WIZARD FRONT RANK, FIRE PLAN, FIRE IN ORDER, KEEPS THE TARGET, MISSILES IN THE FIRE PLAN, THREAT AT FULL SIZE, SHOOTERS ARE THREATS, SHOOTERS TO THE PRIMARY.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 30% (53 of 175) | 15% (27 of 186) | 22% (80 of 361) |
| Winner chose to follow up after the loser gave ground |  | 96% (66 of 69); on the table 97% | 98% (53 of 54); on the table 98% | 97% (119 of 123); on the table 98% |
| Winner chose to pursue after the loser fell back in good order |  | 89% (8 of 9); on the table 89% | 89% (17 of 19); on the table 95% | 89% (25 of 28); on the table 93% |
| Winner chose to pursue after the loser fled |  | 86% (24 of 28); on the table 86% | 68% (26 of 38); on the table 74% | 76% (50 of 66); on the table 79% |
| Winner chose to follow up or pursue (all three) |  | 92% (98 of 106); on the table 93% | 86% (96 of 111); on the table 89% | 89% (194 of 217); on the table 91% |
| Magic missiles tried each own turn | 50%+ | 34% (115 of 342) | 31% (48 of 156) | 33% (163 of 498) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 50% (115 of 228) | 41% (48 of 117) | 47% (163 of 345) |
|   fighting wizards (on a monster, chariot or monstrous mount) | 50%+ | 31% (46 of 150) | 14% (11 of 78) | 25% (57 of 228) |
|     round 1 |  | 20% (5 of 25) | 0% (0 of 13) | 13% (5 of 38) |
|     rounds 2+ |  | 33% (41 of 125) | 17% (11 of 65) | 27% (52 of 190) |
|   other wizards | 50%+ | 36% (69 of 192) | 47% (37 of 78) | 39% (106 of 270) |
|     round 1 |  | 44% (14 of 32) | 54% (7 of 13) | 47% (21 of 45) |
|     rounds 2+ |  | 34% (55 of 160) | 46% (30 of 65) | 38% (85 of 225) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 58% (15 of 26) | 49% (25 of 51) | 52% (40 of 77) |
| Points that never fought | lower | 35% (25034 of 71583) | 37% (26582 of 71989) | 36% (51616 of 143572) |
|   infantry points that never fought | lower | 47% (7616 of 16324) | 54% (7601 of 14029) | 50% (15217 of 30353) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 56% (158 of 284) | 57% (168 of 297) | 56% (326 of 581) |
| Bound items with a magic missile used (at least once a game) |  | 95% (19 of 20); 1.7 uses a game | 83% (15 of 18); 1.0 uses a game | 89% (34 of 38); 1.3 uses a game |
| Bound items with another spell used |  | 56% (10 of 18); 0.6 uses a game | 50% (1 of 2); 0.1 uses a game | 55% (11 of 20); 0.3 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 50% (10 of 20); 0.3 uses a game | 14% (1 of 7); 0.0 uses a game | 41% (11 of 27); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 50% (30351 of 60231) | 50% (31716 of 63281) | 50% (62067 of 123512) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.8 (28%) | 0.7 (23%) | 2.4 (26%) |
| MARCHED: its unit marched | 0.9 (14%) | 0.6 (20%) | 1.5 (16%) |
| CHARGED: its unit charged | 0.2 (3%) | 0.2 (6%) | 0.4 (4%) |
| IN COMBAT: engaged in combat | 1.4 (22%) | 0.6 (21%) | 2.1 (22%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.1 (4%) | 0.1 (1%) |
| FLEEING: fleeing | 0.1 (1%) | 0.1 (2%) | 0.1 (1%) |
| GONE: slain | 0.9 (15%) | 0.3 (9%) | 1.2 (13%) |
| OFF THE TABLE: off the table or not arrived | 0.7 (11%) | 0.1 (4%) | 0.8 (9%) |
| STUPIDITY: Stupidity | 0.2 (3%) | 0.0 (1%) | 0.2 (2%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (1%) | 0.1 (2%) | 0.1 (1%) |
| NOT OFFERED: not in the cast list | 0.1 (1%) | 0.2 (7%) | 0.3 (3%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.1 | 2.0 | 1.3 | 4.5 | 0.3 | 2.2 |
| not cast | 3.7 | 3.0 | 3.7 | 9.3 | 2.1 | 19.5 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.1 (2%) | 0.0 (0%) | 0.0 (0%) | 1.4 (7%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.5 (50%) | 0.3 (9%) | 2.4 (26%) | 0.4 (18%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.5 (16%) | 0.3 (16%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.4 (4%) | 0.1 (3%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.1 (4%) | 0.3 (9%) | 0.5 (14%) | 2.1 (22%) | 0.3 (16%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.3 (7%) | 0.3 (11%) | 0.3 (8%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.1 (4%) | 0.0 (0%) | 0.1 (2%) | 0.1 (1%) | 0.0 (1%) | 0.3 (2%) |
| GONE: slain | 0.9 (23%) | 0.3 (10%) | 0.6 (16%) | 1.2 (13%) | 0.4 (18%) | 3.1 (16%) |
| OFF THE TABLE: off the table or not arrived | 0.2 (7%) | 0.2 (7%) | 0.3 (8%) | 0.8 (9%) | 0.1 (4%) | 0.7 (4%) |
| STUPIDITY: Stupidity | 0.1 (1%) | 0.0 (1%) | 0.1 (2%) | 0.2 (2%) | 0.0 (0%) | 0.4 (2%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (1%) | 0.2 (8%) | 0.0 (0%) | 0.1 (1%) | 0.5 (24%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (3%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.9 (52%) | 0.1 (3%) | 1.4 (39%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 13.6 (70%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.8 a game | 0.7 a game | 0.7 a game |
| stood (cast and not dispelled) | 60% (15 of 25) | 64% (16 of 25) | 62% (31 of 50) |
| the unit moved after it | 67% (10 of 15) | 56% (9 of 16) | 61% (19 of 31) |
| it charged on its next turn | 7% (1 of 15) | 6% (1 of 16) | 6% (2 of 31) |
| the enemy charged it first | 7% (1 of 15) | 19% (3 of 16) | 13% (4 of 31) |
| it fought by the end of its next turn | 0% (0 of 15) | 25% (4 of 16) | 13% (4 of 31) |
| it moved out of a charge the enemy had planned (not charged first) | 20% (3 of 15) | 19% (3 of 16) | 19% (6 of 31) |
| none of these (no charge, no fight, no charge escaped) | 67% (10 of 15) | 50% (8 of 16) | 58% (18 of 31) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 69% (582 of 844) | 52% (406 of 784) | 61% (988 of 1628) |
|   cavalry | 71% (53 of 75) | 56% (96 of 170) | 61% (149 of 245) |
|   character | 52% (49 of 94) | 20% (21 of 103) | 36% (70 of 197) |
|   chariot | 48% (54 of 112) | 59% (22 of 37) | 51% (76 of 149) |
|   infantry | 68% (166 of 245) | 54% (169 of 313) | 60% (335 of 558) |
|   monster | 43% (20 of 47) | 61% (22 of 36) | 51% (42 of 83) |
|   war machine | 89% (240 of 271) | 61% (76 of 125) | 80% (316 of 396) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.5 (20%) | 2.8 (26%) | 4.2 (24%) |
| CHARGED: it charged | 0.9 (13%) | 2.0 (19%) | 3.0 (17%) |
| FLEEING: it fled or was fleeing | 0.1 (1%) | 0.2 (2%) | 0.2 (1%) |
| IN COMBAT: it fought this turn or the last | 1.1 (16%) | 0.4 (4%) | 1.5 (9%) |
| MOVED: a war machine that moved | 0.1 (1%) | 0.0 (0%) | 0.1 (0%) |
| NO TARGET IN RANGE | 1.4 (19%) | 1.9 (18%) | 3.3 (18%) |
| ONLY IN COMBAT: the only targets were in combat | 0.3 (5%) | 0.6 (5%) | 0.9 (5%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.4 (20%) | 1.8 (17%) | 3.2 (18%) |
| SHELTERED: the target was sheltered | 0.2 (2%) | 0.5 (5%) | 0.7 (4%) |
| STUPIDITY | 0.0 (0%) | 0.1 (1%) | 0.1 (0%) |
| OTHER BAR | 0.3 (4%) | 0.4 (4%) | 0.7 (4%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 6.4 | 1.5 | 80% | 4.3 pts | 28 pts |
| character | 2.1 | 0.9 | 70% | 15.2 pts | 32 pts |
| chariot | 2.1 | 1.3 | 74% | 12.1 pts | 26 pts |
| infantry | 12.9 | 5.5 | 70% | 9.1 pts | 118 pts |
| monster | 1.5 | 0.5 | 76% | 6.7 pts | 10 pts |
| war machine | 8.8 | 7.3 | 62% | 23.0 pts | 202 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.1 | 7.2 | 5.7 |
| Charges that made contact a game | 3.0 | 4.9 | 4.0 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.81 declared, 0.54 contact (26 units) | 1.31 declared, 0.85 contact (13 units) | 0.97 declared, 0.64 contact (39 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.71 declared, 0.71 contact (7 units) | 1.55 declared, 1.00 contact (11 units) | 1.22 declared, 0.89 contact (18 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.50 declared, 0.37 contact (246 units) | 0.78 declared, 0.53 contact (290 units) | 0.65 declared, 0.46 contact (536 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 55% (40 of 73) | 78% (14 of 18) | 42% (5 of 12) | 57% (59 of 103) |
| Character in a unit | 79% (23 of 29) | 62% (10 of 16) | 50% (1 of 2) | 72% (34 of 47) |
| Character on its own | 84% (36 of 43) | 42% (16 of 38) | 20% (13 of 64) | 45% (65 of 145) |
| Chariot | 71% (12 of 17) | 54% (7 of 13) | - | 63% (19 of 30) |
| Infantry | 52% (49 of 94) | 68% (23 of 34) | 0% (0 of 3) | 55% (72 of 131) |
| Monster | 48% (14 of 29) | 78% (7 of 9) | - | 55% (21 of 38) |
| Monstrous | 50% (7 of 14) | 71% (10 of 14) | - | 61% (17 of 28) |
| War Machines | 67% (38 of 57) | 50% (1 of 2) | - | 66% (39 of 59) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 100% (10 of 10); on the table 100% | 27% (28 of 102) | 37% | 77% (17 of 22) | 83% (5 of 6); 3.5 uses a game | 100% (2 of 2); 1.2 uses a game | 100% (6 of 6); 1.5 uses a game |
| Chaos Dwarfs | 4 | 92% (12 of 13); on the table 92% | 56% (20 of 36) | 52% | 50% (16 of 32) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
| Dwarfen Mountain Holds | 6 | 100% (20 of 20); on the table 100% | - | 51% | 74% (40 of 54) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 7 | 78% (7 of 9); on the table 78% | 31% (15 of 48) | 47% | 58% (44 of 76) | 0.0 uses a game | 100% (2 of 2); 0.7 uses a game | 0% (0 of 4); 0.0 uses a game |
| Grand Cathay | 6 | 83% (15 of 18); on the table 89% | 33% (45 of 138) | 42% | 46% (25 of 54) | 100% (14 of 14); 6.0 uses a game | 50% (1 of 2); 0.2 uses a game | 0% (0 of 6); 0.0 uses a game |
| High Elf Realms | 4 | 93% (14 of 15); on the table 93% | 6% (1 of 18) | 36% | 36% (12 of 33) | 100% (3 of 3); 3.2 uses a game | 43% (6 of 14); 3.5 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 2 | 90% (9 of 10); on the table 90% | - | 27% | 25% (3 of 12) | 0.0 uses a game | 0.0 uses a game | 100% (2 of 2); 1.0 uses a game |
| Lizardmen | 1 | 100% (2 of 2); on the table 100% | - | 15% | 71% (5 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 4 | 100% (7 of 7); on the table 100% | 0% (0 of 18) | 41% | 79% (22 of 28) | 100% (4 of 4); 3.2 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 1 | 100% (1 of 1); on the table 100% | 17% (2 of 12) | 3% | 25% (2 of 8) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Skaven | 3 | 100% (9 of 9); on the table 100% | 33% (6 of 18) | 29% | 60% (15 of 25) | 100% (2 of 2); 1.0 uses a game | 0.0 uses a game | 33% (1 of 3); 0.3 uses a game |
| Tomb Kings of Khemri | 5 | 88% (15 of 17); on the table 88% | - | 31% | 24% (6 of 25) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 9 | 91% (29 of 32); on the table 100% | 45% (30 of 66) | 26% | 59% (32 of 54) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 9 | 77% (30 of 39); on the table 77% | 44% (8 of 18) | 26% | 51% (37 of 73) | 100% (2 of 2); 0.7 uses a game | 0.0 uses a game | 100% (1 of 1); 0.1 uses a game |
| Wood Elf Realms | 7 | 93% (14 of 15); on the table 93% | 33% (8 of 24) | 38% | 64% (50 of 78) | 57% (4 of 7); 1.6 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (sp-h2h-mine-89601ea-p2, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 42% (49) | 49% (30) | 44% (79) |
| ...free all their last turn and able to turn (per game) | 0.69 | 0.42 | 1.11 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.25 | 0.19 | 0.44 |
| ...with the charger already in that arc before they moved (per game) | 0.50 | 0.19 | 0.69 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 1.75 | 1.64 | 3.39 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.83 | 1.00 | 1.83 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 6.25 | 4.72 | 10.97 |

### Quality by phase: sp-h2h-mine-89601ea-p2

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.8 | 3.3 |
| Strategy | Charge objectives carried out (made contact) | 48% (63 of 132) | 44% (112 of 254) |
| Strategy | Shoot objectives carried out (shot that target) | 33% (130 of 395) | 48% (100 of 207) |
| Strategy | Close-in objectives charged next turn | 13% (18 of 134) | 23% (50 of 219) |
| Strategy | Support requests answered (helper made contact too) | 71% (10 of 14) | 50% (16 of 32) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (4 of 4) | 100% (2 of 2) |
| Strategy | Hexes on a unit its side charged or shot that turn | 38% (8 of 21) | 56% (9 of 16) |
| Strategy | Joined characters whose unit fought | 50% (21 of 42) | 27% (10 of 37) |
| Strategy | Lone characters that fought | 76% (78 of 103) | 80% (69 of 86) |
| Movement | Charges halted short of contact | 0.1 | 0.4 |
| Movement | Idle units | 1.1 | 1.7 |
| Movement | Points that never moved of their own | 362.4 | 179.2 |
| Movement | Fights charged into per game | 2.6 | 4.2 |
| Movement | Charges with odds: long shots (under 50%) | 11 of 84, net +60 | 26 of 142, net +31 |
| Movement | Charges with odds: sweet spot (55-75%) | 17 of 84, net +46 | 24 of 142, net +135 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 11 of 84, net +78 | 8 of 142, net +108 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 29 of 84, net +86 | 48 of 142, net +122 |
| Shooting | Shots by shooting units (incl. breath weapons) | 10.3 | 10.2 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 37% (137 of 370) | 41% (151 of 369) |
| Shooting | Points destroyed by shooting units | 90.3 | 57.2 |
| Shooting | War machine shots | 6.7 | 2.1 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 48% (114 of 240) | 57% (43 of 76) |
| Shooting | Points destroyed by war machines | 81.7 | 29.0 |
| Magic | Magic missiles cast | 1.8 | 1.0 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 27% (18 of 66) | 36% (13 of 36) |
| Magic | Wounds caused by magic missiles | 3.1 | 1.0 |
| Magic | Wounds caused by other spells | 2.1 | 0.4 |
| Magic | Points destroyed by magic (all spells) | 101.5 | 10.1 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.7 / 0.7 / 0.9 / 0.1 | 2.1 / 0.4 / 0.5 / 0.1 |
| Combat | Points destroyed in combat | 300.0 | 445.9 |
| Combat | Points run down | 100.0 | 95.8 |
| Combat | Net points per charged fight, damage counted | +61 | +80 |
| Combat | Net per 100 charger points, damage counted | +23.5 | +29.1 |
| Combat | First round won (charged fights) | 72% | 75% |
| Combat | Net points per charged fight | +53 | +85 |
| Combat | Net points per supported fight / lone fight | -1 / +60 | +145 / +76 |
| Combat | Charged fights on a top-3 enemy unit | 31 of 94 | 68 of 151 |
| Game | Points lost | 854.6 | 720.1 |
| Game | VP from objectives | 471.7 | 676.7 |
| Game | Lone holders (player turns) | 3.4 | 3.4 |

- Mine won / drew / lost: 11 / 7 / 18 of 36 ended games (of 36); mean margin (Mine - Opponent) -330 VP
- The side that went first won 19 of 29 games with a winner
- Points traded per game (both sides' losses): 1575
- Games not ended: 0; findings 0, warnings 1

### Opponent rules: sp-h2h-mine-89601ea-p2

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 0.5 | +0.0 | 0.0 | 0.0 |
| ALREADY CARRIED | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARRIVAL HUNT | - | - | - | - | 0.1 | +5.0 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.3 | +0.0 | 0.0 | 16.7 | 0.2 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | 1.0 | +5.3 | 0.0 | 31.4 | 1.1 | +14.8 | 0.0 | 6.7 |
| BEST FACING | 0.5 | +24.7 | 0.0 | 17.9 | 0.9 | +31.5 | 0.0 | 38.4 |
| BEST FIRST | 4.8 | +239.2 | 87.3 | 61.1 | 4.6 | +211.1 | 169.0 | 70.0 |
| BEST MOVE FOR SHOOTERS | 0.8 | +52.0 | 0.0 | 8.8 | - | - | - | - |
| BEST OVERALL | 0.7 | +36.2 | 0.0 | 12.8 | 0.6 | +45.3 | 0.0 | 51.6 |
| BEST PREY | 0.8 | +47.8 | 19.3 | 23.0 | 0.9 | +33.8 | 43.8 | 28.9 |
| BEST PRIZE | 0.1 | -0.7 | 3.5 | 5.4 | 0.1 | -2.7 | 0.0 | 0.0 |
| BIG CHARACTER SAFETY | 0.1 | -0.3 | 0.0 | 0.0 | 0.1 | -0.5 | 0.0 | 0.0 |
| BLOCKED CHARGE SKIPPED | 0.0 | +0.0 | 2.1 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| BLOCKED WHEEL | 0.4 | +5.6 | 0.0 | 10.3 | 0.5 | +4.1 | 0.0 | 5.3 |
| BOMBING RUN | 0.1 | +2.6 | 13.1 | 1.7 | 0.1 | +1.3 | 0.0 | 1.7 |
| BOUND ASSAILMENT | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CANNON PLAN MISSED | - | - | - | - | 0.3 | +0.0 | 23.7 | 0.0 |
| CANNON PLANNED TARGET | - | - | - | - | 1.4 | +61.9 | 108.9 | 26.2 |
| CANNON SIGHT KEPT | 1.3 | +0.0 | 0.0 | 6.7 | 0.6 | +0.0 | 0.0 | 4.6 |
| CARRIES OUT COUNTER | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | -1.1 | 5.4 | 5.1 |
| CARRIES OUT SET-UP | 0.1 | -3.3 | 5.1 | 0.0 | 0.3 | -0.6 | 43.6 | 5.4 |
| CAST JOB | 0.8 | +15.7 | 105.8 | 43.7 | 0.2 | +3.1 | 32.2 | 4.6 |
| CASTER AWAY FROM SCREEN | 0.3 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.3 | +15.1 | 13.3 | 0.0 | 0.2 | +7.4 | 14.5 | 4.4 |
| CASTS AFTER FRIENDS | 0.4 | +0.0 | 0.0 | 13.9 | 0.4 | +0.0 | 0.0 | 18.9 |
| CASTS FROM BEHIND | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.0 | +0.6 | 0.0 | 0.0 | - | - | - | - |
| CATCH ODDS | - | - | - | - | 0.1 | +3.6 | 0.0 | 0.0 |
| CHAFF PASSED | - | - | - | - | 0.2 | +0.0 | 0.0 | 1.8 |
| CHARGE NOW FIRST | 2.6 | +0.0 | 219.4 | 98.6 | 3.8 | +0.0 | 471.9 | 119.6 |
| CHARGE NOW WEIGHED | 0.6 | -54.4 | 64.0 | 2.5 | 0.3 | -18.6 | 9.1 | 27.7 |
| CHARIOT NO STATIC JOB | 0.1 | +0.0 | 0.0 | 2.4 | - | - | - | - |
| CHARIOT WIZARD CAREFUL | 0.1 | -0.4 | 0.0 | 0.0 | 0.1 | -0.0 | 6.6 | 0.0 |
| CHEAP HELPER | 0.0 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 18.7 | 1.7 |
| COMBAT PIVOT | 0.5 | +0.0 | 34.4 | 27.3 | 0.5 | +0.0 | 42.8 | 24.8 |
| CONVEYANCE SEARCH | 0.4 | +88.6 | 13.9 | 13.9 | 0.6 | +82.2 | 17.4 | 26.5 |
| COUNTER-CHARGE COVER | 10.2 | +833.4 | 0.0 | 250.8 | 6.6 | +600.2 | 0.0 | 168.5 |
| DEFENSIVE ARMY | 0.3 | +0.0 | 27.2 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| EDGE GIVE GROUND | 0.1 | +2.7 | 8.3 | 0.0 | 0.4 | +8.9 | 48.0 | 1.7 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACE THE CAST | 0.1 | +4.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 1.8 | +128.3 | 0.0 | 52.7 | 1.6 | +132.9 | 0.0 | 62.6 |
| FALLBACK BY WORTH | 4.4 | +64.1 | 0.0 | 76.2 | 5.2 | +42.4 | 0.0 | 78.5 |
| FIGHT LIFT | 0.0 | +0.0 | 0.0 | 16.1 | 0.1 | +0.4 | 0.0 | 0.0 |
| FIRE AND FLEE | - | - | - | - | 0.1 | +0.7 | 0.0 | 6.9 |
| FIRE IN ORDER | 1.1 | +0.0 | 27.2 | 11.6 | - | - | - | - |
| FIRE PLAN | 17.1 | +687.1 | 1182.5 | 326.9 | - | - | - | - |
| FLANK NOT WEIGHED | 6.1 | +0.0 | 0.0 | 150.6 | 4.3 | +0.0 | 0.0 | 115.8 |
| FOCUS FIRE | - | - | - | - | 0.1 | +2.5 | 3.1 | 0.0 |
| FOLLOW UP WEIGHED | 1.0 | +137.9 | 0.0 | 38.9 | 1.3 | +177.1 | 0.0 | 53.3 |
| FRIENDS SHOTS CHECKED | 0.3 | +15.0 | 0.0 | 5.8 | 0.2 | +16.3 | 0.0 | 0.0 |
| GIVES UP | 0.1 | -0.7 | 12.0 | 0.0 | 0.2 | -2.3 | 7.2 | 5.4 |
| GIVES UP ITS SCREEN | 0.0 | -0.2 | 5.4 | 0.0 | 0.0 | -0.3 | 4.8 | 0.0 |
| GROUND FLIERS | 0.0 | +0.5 | 0.0 | 0.0 | - | - | - | - |
| HELPER ALREADY ASKED | - | - | - | - | 0.1 | +0.0 | 8.0 | 8.3 |
| HELPER UNSEEN | 0.3 | +0.0 | 41.2 | 8.1 | 0.5 | +0.0 | 24.2 | 14.2 |
| HILL BY ITS CHANCE | 0.3 | -27.8 | 0.0 | 5.1 | 0.8 | -63.6 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HORN WORTH | - | - | - | - | 0.0 | +0.1 | 0.0 | 0.0 |
| HUNT ADVANCE | 0.1 | +0.3 | 5.4 | 0.0 | 0.2 | +3.9 | 12.2 | 5.0 |
| HUNT DROPPED | 0.1 | +0.0 | 12.1 | 0.9 | 0.0 | +0.0 | 4.6 | 0.0 |
| HUNT IN PAIRS | 0.5 | +45.9 | 0.0 | 0.0 | 0.4 | +20.4 | 0.0 | 5.4 |
| HUNT KEPT | 0.1 | +0.4 | 5.4 | 0.0 | 0.1 | +3.5 | 9.2 | 0.0 |
| HUNT RESULT | 0.1 | +6.1 | 12.1 | 2.4 | 0.2 | +44.3 | 4.6 | 3.1 |
| HUNT THE GUNS | 0.1 | +33.3 | 5.4 | 1.4 | 0.2 | +83.6 | 24.9 | 5.0 |
| INVITES THE FIGHT | 1.3 | +21.8 | 29.6 | 29.1 | 1.0 | +17.3 | 56.5 | 31.4 |
| JOINT CHARGE PLAN | - | - | - | - | 0.1 | +14.0 | 14.4 | 0.0 |
| KEEP FALLS | 0.1 | +1.2 | 0.0 | 0.0 | - | - | - | - |
| KEEPS ITS PREY | 0.0 | +0.1 | 0.0 | 2.4 | 0.1 | +0.3 | 3.1 | 7.0 |
| KEEPS ITS TARGET | 1.4 | +40.8 | 77.4 | 50.8 | 2.5 | +74.2 | 268.9 | 54.0 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| KEEPS THE TARGET | 1.5 | -46.4 | 117.5 | 18.4 | - | - | - | - |
| KILLS COUNT | 1.7 | +66.9 | 102.8 | 43.9 | 2.6 | +100.4 | 177.1 | 60.7 |
| KILLS COUNT NEXT TURN | 4.2 | +145.4 | 96.8 | 79.6 | 7.4 | +302.4 | 333.3 | 166.5 |
| LONE CHARACTER SAFE SPOT | 0.2 | +26.4 | 14.3 | 13.9 | 0.2 | +4.0 | 3.5 | 4.6 |
| LONE WIZARD HOLDS BACK | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 3.1 | 16.0 |
| LONE WIZARD KEPT IN | 0.6 | +39.4 | 0.0 | 0.0 | 0.3 | +23.5 | 0.0 | 0.0 |
| LONG SHOT | 0.3 | +0.8 | 13.6 | 3.6 | 0.7 | -1.7 | 32.6 | 4.4 |
| LOST CHARGE | 3.1 | -51.0 | 83.8 | 88.5 | 2.2 | -56.7 | 74.8 | 68.8 |
| LURE BY WHAT IT DRAWS | 0.1 | -9.7 | 0.0 | 0.0 | 0.1 | -5.8 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 0.5 | +17.9 | 0.0 | 20.8 | 0.7 | +50.0 | 26.1 | 15.0 |
| MANOEUVRE | 0.2 | +6.6 | 0.0 | 2.7 | 0.2 | +11.8 | 0.0 | 3.5 |
| MARCH AT ESCAPER | 0.1 | +0.9 | 0.0 | 0.0 | 0.1 | +0.6 | 0.0 | 5.4 |
| MARCH CHECK | 0.4 | +13.7 | 0.0 | 14.8 | 0.3 | +15.2 | 0.0 | 5.3 |
| MARCH ODDS | 0.4 | +32.4 | 17.1 | 2.2 | 0.3 | +27.3 | 4.6 | 0.0 |
| MARCH OVER CASTS | 0.6 | +76.2 | 0.0 | 30.0 | 0.3 | +28.8 | 0.0 | 29.5 |
| MAX FOR POSITIONING | 4.7 | +157.0 | 0.0 | 121.1 | 4.1 | +176.1 | 0.0 | 88.3 |
| MISSILES IN THE FIRE PLAN | 3.5 | +109.4 | 248.9 | 85.5 | - | - | - | - |
| MISSILES IN THE MOVE | 4.1 | +99.3 | 0.0 | 100.4 | 2.6 | +41.2 | 0.0 | 56.0 |
| MISSILES NEXT TURN | 4.5 | +66.3 | 0.0 | 154.1 | 3.5 | +35.4 | 0.0 | 89.9 |
| MODEL FACING | 0.3 | +103.5 | 0.0 | 3.3 | 0.3 | +56.2 | 0.0 | 1.7 |
| MONSTER WIZARD ROAMS | 0.3 | +0.0 | 25.0 | 0.0 | 0.2 | +0.0 | 24.1 | 0.0 |
| MOVE AND CAST | 0.6 | +33.2 | 0.0 | 0.0 | 0.4 | +16.2 | 0.0 | 9.3 |
| MOVE SPELL IN RANGE | 0.2 | +7.6 | 0.0 | 32.2 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.3 | -7.2 | 0.0 | 2.6 | 0.2 | -10.4 | 2.9 | 0.0 |
| MOVE SPELL SPOT | 0.2 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE | 2.5 | +120.9 | 51.1 | 77.2 | 4.7 | +310.5 | 213.0 | 128.1 |
| MOVES UNITS SPELL | 0.1 | +3.4 | 0.0 | 0.0 | - | - | - | - |
| NEEDED THERE | 0.1 | +9.1 | 3.5 | 0.0 | 0.1 | +12.2 | 13.2 | 0.0 |
| NO RALLY LEFT | 0.0 | +2.4 | 0.0 | 0.0 | 0.0 | +2.3 | 0.0 | 0.0 |
| NOT NEEDED | 0.1 | -5.6 | 17.0 | 9.6 | 0.6 | -40.2 | 59.3 | 13.4 |
| NOT TURNED | 6.2 | +93.5 | 0.0 | 121.8 | 4.7 | +74.1 | 0.0 | 132.9 |
| NOT WORTH A CAST | 0.3 | -0.2 | 0.0 | 0.0 | 0.6 | -0.4 | 0.0 | 0.0 |
| OFF BEST | 14.8 | -670.1 | 0.0 | 308.1 | 14.9 | -714.0 | 3.3 | 242.2 |
| OPENS A LANE | 0.0 | +0.1 | 1.2 | 0.0 | - | - | - | - |
| OPENS UP | 0.2 | +18.0 | 6.8 | 12.3 | 0.2 | +28.1 | 18.6 | 0.0 |
| OVERRUNS AWAY | 0.7 | +7.5 | 53.3 | 53.2 | 0.8 | +7.5 | 101.7 | 20.1 |
| PATHS CROSS | 1.8 | +146.2 | 0.0 | 35.1 | 2.7 | +194.7 | 0.0 | 33.1 |
| PERIAPT WORTH | 0.0 | +1.5 | 0.0 | 0.0 | - | - | - | - |
| PIVOT GUARDS FLANK | 0.1 | -1.7 | 0.0 | 0.0 | 0.1 | -3.0 | 0.0 | 6.6 |
| PLAN RESULT | 36.4 | +1260.3 | 1537.2 | 1030.2 | 41.2 | +1359.2 | 1753.0 | 1005.8 |
| PURSUES BIG PREY | 0.0 | -0.6 | 0.0 | 0.0 | 0.1 | -7.2 | 0.0 | 0.0 |
| PURSUES ON | 0.0 | +1.0 | 0.0 | 0.0 | - | - | - | - |
| RAIDS THE BAGGAGE NEXT TURN | 0.1 | +8.3 | 0.0 | 3.4 | - | - | - | - |
| RANDOM MOVE BY FIGURES | 0.7 | +15.1 | 0.0 | 12.8 | 1.4 | +16.3 | 0.0 | 46.7 |
| RANDOM MOVER NO PROMISE | 0.2 | -18.4 | 6.0 | 4.7 | 0.2 | -13.9 | 31.4 | 4.7 |
| REDIRECT BY WHAT IT STOPS | 0.1 | -1.7 | 0.0 | 2.3 | 0.3 | -8.3 | 0.0 | 1.2 |
| REDIRECT COUNTER | 2.1 | +110.1 | 0.0 | 42.5 | 3.4 | +308.1 | 0.0 | 60.6 |
| REDIRECT WEIGHED | 0.2 | +4.7 | 3.5 | 1.4 | 0.4 | +15.3 | 22.1 | 0.0 |
| RESERVE FALL BACK | 0.4 | +12.9 | 0.0 | 4.0 | 0.9 | +28.4 | 0.0 | 12.4 |
| RESTRAINS TO SHOOT | 0.1 | +6.9 | 0.0 | 0.0 | 0.1 | +1.2 | 0.0 | 0.0 |
| RISK BY ARC | 2.5 | +84.3 | 216.9 | 96.5 | 4.1 | +63.5 | 425.4 | 99.5 |
| SAFER THAN THE JOB | 0.8 | +48.8 | 0.0 | 3.8 | 1.0 | +71.0 | 0.0 | 22.3 |
| SCOUT SPOT | 0.3 | +0.8 | 0.0 | 0.0 | 0.5 | +2.1 | 0.0 | 0.0 |
| SCOUT WAITS | 0.3 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.2 | -11.3 | 0.0 | 1.2 | 0.3 | -15.6 | 0.0 | 1.9 |
| SEARCH SPOT | 2.8 | +148.9 | 0.0 | 60.5 | 2.3 | +91.4 | 0.0 | 30.8 |
| SECOND HUNTER | 0.0 | -0.0 | 0.0 | 0.0 | 0.1 | -0.6 | 9.2 | 0.0 |
| SELF MOVE SPELL | 0.2 | +17.2 | 0.0 | 9.1 | - | - | - | - |
| SET UP TOGETHER | 0.8 | +31.1 | 13.4 | 24.1 | 1.4 | +111.1 | 74.6 | 24.2 |
| SET-UP ANY TARGET | 0.1 | +9.6 | 0.0 | 0.0 | 0.2 | +14.6 | 6.5 | 11.2 |
| SET-UP MISSED | - | - | - | - | 0.1 | +1.8 | 0.0 | 0.0 |
| SHOOTER COUNTED ONCE | - | - | - | - | 0.0 | -0.0 | 0.0 | 1.1 |
| SHOOTERS ARE THREATS | 3.6 | +431.1 | 243.8 | 71.2 | - | - | - | - |
| SHOOTERS IN TWO RANKS | 0.4 | +0.8 | 0.0 | 0.0 | 0.3 | +0.6 | 0.0 | 0.0 |
| SHOOTERS TO THE PRIMARY | 6.7 | +418.2 | 0.0 | 110.7 | - | - | - | - |
| SHOOTS FROM THE BEST SPOT | 1.1 | +58.7 | 68.1 | 17.6 | 0.5 | +29.0 | 8.1 | 14.1 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 3.2 | 0.2 | +0.0 | 0.0 | 0.0 |
| SHOT OPTIONS | 15.9 | +0.0 | 824.4 | 276.3 | 11.6 | +0.0 | 464.1 | 233.3 |
| SHOT REPLANNED | - | - | - | - | 0.3 | +0.0 | 57.9 | 1.7 |
| SHOTS IN THE MOVE | 14.8 | +569.2 | 0.0 | 257.3 | 10.6 | +272.0 | 0.0 | 168.6 |
| SPELL CATCH ODDS | 0.1 | -0.6 | 0.0 | 0.0 | 0.0 | -0.2 | 0.0 | 0.0 |
| SPELL SETS UP CHARGE | 0.2 | +66.8 | 13.9 | 13.9 | 0.3 | +58.9 | 6.5 | 18.9 |
| SPELL WORTH | 0.9 | +18.6 | 60.3 | 56.9 | 1.9 | +36.3 | 67.8 | 77.5 |
| STABLE ROLE | 10.9 | +0.0 | 318.5 | 172.4 | 11.8 | +0.0 | 434.9 | 199.3 |
| STANDS TO CAST | - | - | - | - | 0.1 | +4.3 | 0.0 | 0.0 |
| STAY WEIGHED | - | - | - | - | 0.1 | +4.7 | 0.0 | 2.0 |
| STAY WORTH | 14.9 | +24.5 | 477.0 | 186.2 | - | - | - | - |
| STOPS | 0.1 | +0.6 | 5.4 | 1.4 | 0.1 | +7.6 | 21.8 | 0.0 |
| STOPS SHORT OF THE FLANK | 0.5 | +25.7 | 0.0 | 20.4 | 0.2 | +12.3 | 0.0 | 0.0 |
| STUCK PIVOT | 0.2 | +0.0 | 0.0 | 4.0 | 0.1 | +0.0 | 0.0 | 4.0 |
| SUPPORT NARROWED | 6.2 | -46.9 | 333.8 | 111.2 | 8.2 | -51.2 | 445.9 | 116.9 |
| SUPPORTS | 4.2 | +49.6 | 185.1 | 41.9 | 4.7 | +54.1 | 132.9 | 42.9 |
| SURE CHARGE BEATS ADVANCE | 0.0 | -0.4 | 0.0 | 0.0 | 0.1 | -6.6 | 17.7 | 0.0 |
| SURE REACH TOGETHER | 0.4 | -1.1 | 0.0 | 3.1 | 0.8 | +14.3 | 1.8 | 21.8 |
| THREAT AT FULL SIZE | 8.6 | +0.0 | 534.0 | 141.1 | - | - | - | - |
| THROUGH LINE OF FIRE | 0.4 | +23.9 | 0.0 | 18.0 | 0.2 | +8.0 | 0.0 | 0.0 |
| TURN WORTH | 0.5 | -33.9 | 32.9 | 27.6 | 0.4 | -21.7 | 27.2 | 5.1 |
| TWO OR MORE ARRIVE | 0.2 | +0.8 | 2.1 | 9.7 | 0.2 | +0.4 | 8.0 | 3.9 |
| WAIT AFTER COSTS | 5.6 | -208.1 | 136.6 | 122.6 | 8.2 | -385.0 | 355.3 | 199.1 |
| WALKS TO THE FIGHT | 1.6 | +28.0 | 45.6 | 10.9 | 1.8 | +31.6 | 39.1 | 17.2 |
| WAR ENGINE CHARGES | 0.1 | +17.0 | 8.0 | 2.1 | 0.1 | +1.7 | 4.0 | 7.2 |
| WAR ENGINE JOBS | 0.7 | +0.0 | 35.6 | 0.0 | 0.1 | +0.0 | 5.2 | 9.2 |
| WEARS DOWN | 1.1 | +41.1 | 117.8 | 23.9 | 2.3 | +70.7 | 294.7 | 80.2 |
| WHO HITS BACK | 0.2 | +24.3 | 0.0 | 13.1 | 0.1 | +2.3 | 0.0 | 0.0 |
| WHOLE FIGHT | 0.5 | +6.7 | 68.8 | 10.3 | 0.6 | +22.6 | 93.8 | 10.6 |
| WHOLE FIGHT GAIN | 0.2 | +11.6 | 34.9 | 2.0 | 0.5 | +55.4 | 46.4 | 18.9 |
| WOUNDED STAYS OUT | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |

### Rule changes: sp-h2h-mine-89601ea-p2

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 1071 | 1071 | 1071 | 29.75 | -49826 | -46.5 |
| BEST FIRST | 337 | 337 | 337 | 9.36 | +16211 | +48.1 |
| FIRE PLAN | 615 | 615 | 253 | 7.03 | +11466 | +45.3 |
| SEARCH SPOT | 184 | 184 | 182 | 5.06 | +8662 | +47.6 |
| PATHS CROSS | 163 | 163 | 163 | 4.53 | +12272 | +75.3 |
| COUNTER-CHARGE COVER | 604 | 332 | 150 | 4.17 | +9925 | +66.2 |
| KILLS COUNT NEXT TURN | 418 | 418 | 125 | 3.47 | +4073 | +32.6 |
| FACES THE THREAT | 122 | 122 | 122 | 3.39 | +9400 | +77.1 |
| MOVE TO CHARGE | 261 | 261 | 120 | 3.33 | +5009 | +41.7 |
| SUPPORTS | 320 | 320 | 113 | 3.14 | +1194 | +10.6 |
| FOLLOW UP WEIGHED | 85 | 85 | 85 | 2.36 | +11337 | +133.4 |
| FALLBACK BY WORTH | 349 | 349 | 82 | 2.28 | +3834 | +46.8 |
| SHOTS IN THE MOVE | 913 | 594 | 79 | 2.19 | +1399 | +17.7 |
| WAIT AFTER COSTS | 498 | 498 | 71 | 1.97 | +1722 | +24.3 |
| CANNON SIGHT KEPT | 70 | 70 | 70 | 1.94 | +0 | +0.0 |
| SAFER THAN THE JOB | 66 | 66 | 66 | 1.83 | +4313 | +65.3 |
| WALKS TO THE FIGHT | 120 | 120 | 65 | 1.81 | +632 | +9.7 |
| ARTILLERY RE-ROLL WEIGHED | 54 | 54 | 54 | 1.50 | +0 | +0.0 |
| BEST FACING | 51 | 51 | 51 | 1.42 | +2022 | +39.6 |
| CHARGE NOW FIRST | 230 | 230 | 49 | 1.36 | -2923 | -59.7 |
| MAX FOR POSITIONING | 318 | 182 | 47 | 1.31 | +585 | +12.5 |
| BEST OVERALL | 45 | 45 | 45 | 1.25 | +2935 | +65.2 |
| RESERVE FALL BACK | 45 | 45 | 45 | 1.25 | +1486 | +33.0 |
| ADVANCE LANE KEPT | 42 | 42 | 42 | 1.17 | +0 | +0.0 |
| HOLDS AMBUSHERS | 40 | 40 | 40 | 1.11 | +0 | +0.0 |
| RANDOM MOVE BY FIGURES | 77 | 77 | 40 | 1.11 | +1129 | +28.2 |
| RISK BY ARC | 237 | 232 | 39 | 1.08 | +1307 | +33.5 |
| FIRE IN ORDER | 38 | 38 | 38 | 1.06 | +0 | +0.0 |
| COMBAT PIVOT | 37 | 37 | 37 | 1.03 | +0 | +0.0 |
| REDIRECT COUNTER | 197 | 110 | 37 | 1.03 | +3294 | +89.0 |
| SET UP TOGETHER | 76 | 66 | 37 | 1.03 | +2807 | +75.9 |
| KILLS COUNT | 156 | 154 | 34 | 0.94 | +964 | +28.4 |
| MOVE AND CAST | 34 | 34 | 34 | 0.94 | +1776 | +52.2 |
| LONE WIZARD KEPT IN | 33 | 33 | 33 | 0.92 | +2266 | +68.7 |
| SCOUT WAITS | 32 | 32 | 32 | 0.89 | +0 | +0.0 |
| BLOCKED WHEEL | 31 | 31 | 31 | 0.86 | +349 | +11.3 |
| CHARGE NOW WEIGHED | 31 | 31 | 31 | 0.86 | +2445 | +78.9 |
| SHOOTS FROM THE BEST SPOT | 58 | 58 | 31 | 0.86 | +1505 | +48.6 |
| MISSILES IN THE MOVE | 241 | 147 | 30 | 0.83 | +624 | +20.8 |
| BEST MOVE FOR SHOOTERS | 27 | 27 | 27 | 0.75 | +1872 | +69.3 |
| STAY WORTH | 537 | 440 | 26 | 0.72 | +575 | +22.1 |
| KEEPS ITS TARGET | 138 | 137 | 25 | 0.69 | +395 | +15.8 |
| SHOOTERS IN TWO RANKS | 25 | 25 | 25 | 0.69 | +50 | +2.0 |
| STOPS SHORT OF THE FLANK | 25 | 25 | 25 | 0.69 | +1368 | +54.7 |
| BEST PREY | 62 | 62 | 23 | 0.64 | +383 | +16.7 |
| MARCH CHECK | 26 | 25 | 23 | 0.64 | +1131 | +49.2 |
| MARCH ODDS | 23 | 23 | 23 | 0.64 | +566 | +24.6 |
| THROUGH LINE OF FIRE | 22 | 22 | 22 | 0.61 | +1148 | +52.2 |
| MODEL FACING | 21 | 21 | 21 | 0.58 | +5751 | +273.8 |
| REDIRECT WEIGHED | 21 | 21 | 21 | 0.58 | +736 | +35.0 |
| FRIENDS SHOTS CHECKED | 19 | 19 | 19 | 0.53 | +1128 | +59.4 |
| KEEPS THE TARGET | 54 | 54 | 18 | 0.50 | -1930 | -107.2 |
| SHOOTERS TO THE PRIMARY | 240 | 169 | 17 | 0.47 | +806 | +47.4 |
| MAKE SURE TOGETHER | 41 | 28 | 16 | 0.44 | +1246 | +77.9 |
| CASTER AWAY FROM SCREEN | 15 | 15 | 15 | 0.42 | +0 | +0.0 |
| CASTS FROM BEHIND | 15 | 15 | 15 | 0.42 | +0 | +0.0 |
| INVITES THE FIGHT | 83 | 83 | 15 | 0.42 | +299 | +19.9 |
| SHOOTERS ARE THREATS | 129 | 129 | 14 | 0.39 | +0 | +0.0 |
| SHORT GUN FORWARD | 14 | 14 | 14 | 0.39 | +0 | +0.0 |
| WEARS DOWN | 121 | 116 | 14 | 0.39 | +557 | +39.8 |
| CAST JOB | 37 | 37 | 13 | 0.36 | +197 | +15.1 |
| CASTING BLOCK | 18 | 18 | 12 | 0.33 | +389 | +32.4 |
| LOST CHARGE | 192 | 192 | 12 | 0.33 | +354 | +29.5 |
| MANOEUVRE | 17 | 17 | 12 | 0.33 | +663 | +55.2 |
| MISSILES IN THE FIRE PLAN | 125 | 26 | 12 | 0.33 | +624 | +52.0 |
| THREAT AT FULL SIZE | 309 | 309 | 12 | 0.33 | +0 | +0.0 |
| WAR ENGINE JOBS | 29 | 29 | 12 | 0.33 | -663 | -55.2 |
| WHOLE FIGHT GAIN | 25 | 23 | 12 | 0.33 | +909 | +75.8 |
| OPENS UP | 15 | 15 | 10 | 0.28 | +372 | +37.2 |
| SHOT REPLANNED | 10 | 10 | 10 | 0.28 | +0 | +0.0 |
| WHO HITS BACK | 10 | 10 | 10 | 0.28 | +742 | +74.2 |
| WHOLE FIGHT | 39 | 38 | 10 | 0.28 | +332 | +33.2 |
| CHAFF PASSED | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| STUCK PIVOT | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| SURE REACH TOGETHER | 45 | 34 | 9 | 0.25 | +28 | +3.1 |
| BIG CHARACTER SAFETY | 8 | 8 | 8 | 0.22 | -31 | -3.9 |
| PIVOT GUARDS FLANK | 7 | 7 | 7 | 0.19 | -169 | -24.2 |
| SUPPORT NARROWED | 517 | 517 | 7 | 0.19 | -168 | -24.0 |
| PURSUES BIG PREY | 6 | 6 | 6 | 0.17 | -279 | -46.6 |
| BOMBING RUN | 5 | 5 | 5 | 0.14 | +141 | +28.2 |
| EDGE GIVE GROUND | 20 | 20 | 5 | 0.14 | +117 | +23.4 |
| RESTRAINS TO SHOOT | 5 | 5 | 5 | 0.14 | +293 | +58.5 |
| SURE CHARGE BEATS ADVANCE | 5 | 5 | 5 | 0.14 | -251 | -50.1 |
| BACKUP TARGETS | 76 | 39 | 4 | 0.11 | +37 | +9.1 |
| BEST PRIZE | 4 | 4 | 4 | 0.11 | -164 | -40.9 |
| CANNON PLANNED TARGET | 50 | 50 | 4 | 0.11 | -140 | -34.9 |
| FIRE AND FLEE | 4 | 4 | 4 | 0.11 | +25 | +6.3 |
| KEEPS SCOUTS OR AMBUSH | 4 | 4 | 4 | 0.11 | +0 | +0.0 |
| MISSILES NEXT TURN | 287 | 172 | 4 | 0.11 | +14 | +3.5 |
| MOVES UNITS SPELL | 4 | 4 | 4 | 0.11 | +122 | +30.4 |
| STAY WEIGHED | 4 | 4 | 4 | 0.11 | +170 | +42.4 |
| FACE THE CAST | 3 | 3 | 3 | 0.08 | +142 | +47.5 |
| FOCUS FIRE | 3 | 3 | 3 | 0.08 | +89 | +29.7 |
| HUNT IN PAIRS | 31 | 18 | 3 | 0.08 | +155 | +51.8 |
| NEEDED THERE | 6 | 6 | 3 | 0.08 | +0 | +0.0 |
| OVERRUNS AWAY | 53 | 51 | 3 | 0.08 | +10 | +3.3 |
| RAIDS THE BAGGAGE NEXT TURN | 3 | 3 | 3 | 0.08 | +211 | +70.2 |
| BLOCKED CHARGE SKIPPED | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| BOUND ASSAILMENT | 2 | 2 | 2 | 0.06 | +0 | +0.2 |
| CARRIES OUT SET-UP | 13 | 13 | 2 | 0.06 | -139 | -69.7 |
| CATCH ODDS | 2 | 2 | 2 | 0.06 | -42 | -21.0 |
| DEFENSIVE ARMY | 16 | 16 | 2 | 0.06 | -116 | -57.8 |
| JOINT CHARGE PLAN | 5 | 5 | 2 | 0.06 | +366 | +182.8 |
| KEEP FALLS | 2 | 2 | 2 | 0.06 | +115 | +57.3 |
| LONE WIZARD HOLDS BACK | 13 | 13 | 2 | 0.06 | +0 | +0.0 |
| NO RALLY LEFT | 2 | 2 | 2 | 0.06 | +91 | +45.7 |
| STANDS TO CAST | 2 | 2 | 2 | 0.06 | -41 | -20.4 |
| WAR ENGINE CHARGES | 7 | 6 | 2 | 0.06 | +494 | +246.9 |
| CARRIES OUT COUNTER | 6 | 6 | 1 | 0.03 | -38 | -38.1 |
| CHARIOT NO STATIC JOB | 2 | 2 | 1 | 0.03 | -55 | -54.8 |
| HORN WORTH | 1 | 1 | 1 | 0.03 | +5 | +4.6 |
| MOVE SPELL IN RANGE | 6 | 4 | 1 | 0.03 | +0 | +0.3 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.03 | +54 | +54.0 |
| PURSUES ON | 1 | 1 | 1 | 0.03 | +36 | +35.9 |
| SCREEN BY WHAT IT SAVES | 16 | 16 | 1 | 0.03 | +70 | +70.3 |
| STOPS | 8 | 8 | 1 | 0.03 | +38 | +38.1 |
| TWO OR MORE ARRIVE | 16 | 10 | 1 | 0.03 | +1 | +0.8 |
| ALREADY CARRIED | 3 | not checked | - | - | - | - |
| ARRIVAL HUNT | 2 | 2 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 10 | 10 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 31 | trace | - | - | - | - |
| CATCH FLIERS | 1 | not checked | - | - | - | - |
| CHARIOT WIZARD CAREFUL | 4 | 4 | 0 | 0.00 | - | - |
| CHEAP HELPER | 8 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 39 | not checked | - | - | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT LIFT | 3 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 375 | not checked | - | - | - | - |
| GIVES UP | 9 | 7 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 2 | 2 | 0 | 0.00 | - | - |
| GROUND FLIERS | 1 | not checked | - | - | - | - |
| HELPER ALREADY ASKED | 4 | not checked | - | - | - | - |
| HELPER UNSEEN | 28 | 26 | 0 | 0.00 | - | - |
| HILL BY ITS CHANCE | 39 | 39 | 0 | 0.00 | - | - |
| HUNT ADVANCE | 11 | 11 | 0 | 0.00 | - | - |
| HUNT DROPPED | 4 | trace | - | - | - | - |
| HUNT KEPT | 7 | trace | - | - | - | - |
| HUNT RESULT | 13 | trace | - | - | - | - |
| HUNT THE GUNS | 14 | trace | - | - | - | - |
| KEEPS ITS PREY | 4 | 4 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 13 | not checked | - | - | - | - |
| LONG SHOT | 36 | 36 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 10 | 10 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 5 | trace | - | - | - | - |
| MARCH OVER CASTS | 31 | 31 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 18 | 18 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 19 | trace | - | - | - | - |
| MOVE SPELL SPOT | 10 | not checked | - | - | - | - |
| NOT NEEDED | 24 | 23 | 0 | 0.00 | - | - |
| NOT TURNED | 395 | 395 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 32 | not checked | - | - | - | - |
| OPENS A LANE | 1 | 1 | 0 | 0.00 | - | - |
| PLAN RESULT | 2797 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 15 | 15 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 13 | 13 | 0 | 0.00 | - | - |
| SCOUT SPOT | 28 | 28 | 0 | 0.00 | - | - |
| SECOND HUNTER | 3 | 3 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 8 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 10 | not checked | - | - | - | - |
| SET-UP MISSED | 2 | trace | - | - | - | - |
| SHOOTER COUNTED ONCE | 1 | 1 | 0 | 0.00 | - | - |
| SHOT OPTIONS | 992 | 992 | 0 | 0.00 | - | - |
| SPELL CATCH ODDS | 3 | not checked | - | - | - | - |
| SPELL SETS UP CHARGE | 19 | not checked | - | - | - | - |
| SPELL WORTH | 100 | not checked | - | - | - | - |
| STABLE ROLE | 819 | 816 | 0 | 0.00 | - | - |
| TURN WORTH | 31 | 31 | 0 | 0.00 | - | - |
| WOUNDED STAYS OUT | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: sp-h2h-mine-89601ea-p2

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 13.31 | 13.67 | 48.1 |
| CHARGE NOW FIRST | rule | 0.64 | 0.72 | 59.7 |
| TURN GATE | gate | 0.58 | 0.42 | 50.2 |
| FALLBACK | gate | 0.42 | 0.50 | 16.2 |
| KEEPS THE TARGET | rule | 0.36 | - | 189.5 |
| FIRE PLAN | rule | 0.33 | - | 75.1 |
| WAR ENGINE JOBS | rule | 0.33 | - | 55.2 |
| PATHS CROSS | rule | 0.11 | 0.19 | 22.6 |
| PIVOT GUARDS FLANK | rule | 0.11 | 0.08 | 24.2 |
| SUPPORT NARROWED | rule | 0.11 | 0.08 | 24.0 |
| AFTERMATH BAND | gate | 0.11 | 0.06 | 2.1 |
| FIGHT ORDER BAND | gate | 0.11 | 0.06 | 1.7 |
| PURSUES BIG PREY | rule | 0.03 | 0.14 | 46.6 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.08 | 0.06 | 88.9 |
| LONE CHARACTER SAFE SPOT | gate | 0.08 | 0.06 | 27.6 |
| SUPPORT REQUEST | gate | 0.03 | 0.11 | 30.8 |
| SURE CHARGE BEATS ADVANCE | rule | 0.03 | 0.11 | 50.1 |
| BEST PRIZE | rule | 0.06 | 0.06 | 40.9 |
| BIG CHARACTER SAFETY | rule | 0.06 | 0.06 | 8.3 |
| CANNON PLANNED TARGET | rule | - | 0.11 | 34.9 |
| NO REASON | gate | 0.11 | - | 17.0 |
| BLOCKED WHEEL | rule | 0.03 | 0.06 | 18.0 |
| CHARGE NOW WEIGHED | rule | 0.08 | - | 21.3 |
| CARRIES OUT SET-UP | rule | 0.03 | 0.03 | 69.7 |
| CATCH ODDS | rule | - | 0.06 | 21.0 |
| DEFENSIVE ARMY | rule | 0.06 | - | 57.8 |
| SAFER THAN THE JOB | rule | 0.03 | 0.03 | 7.8 |
| STANDS TO CAST | rule | - | 0.06 | 20.4 |
| STOPS SHORT OF THE FLANK | rule | 0.03 | 0.03 | 8.8 |
| THROUGH LINE OF FIRE | rule | 0.03 | 0.03 | 7.6 |
| CARRIES OUT COUNTER | rule | - | 0.03 | 38.1 |
| CHARIOT NO STATIC JOB | rule | 0.03 | - | 54.8 |
| MARCH ODDS | rule | 0.03 | - | 1.3 |
| MOVE AND CAST | rule | 0.03 | - | 15.0 |
| REDIRECT WEIGHED | rule | - | 0.03 | 50.5 |
| WHO HITS BACK | rule | 0.03 | - | 0.6 |

### Plans: sp-h2h-mine-89601ea-p2

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 11.4 | 15% | 454 | 223 | 49% |
| Mine | charge | 3.1 | 59% | 296 | 258 | 87% |
| Mine | close in | 3.7 | 22% | 177 | 102 | 58% |
| Mine | hold | 3.8 | 33% | 266 | 0 | 0% |
| Mine | join | 0.7 | 100% | 21 | 0 | 0% |
| Mine | shoot | 9.4 | 64% | 610 | 677 | 111% |
| Mine | support | 4.4 | 91% | 31 | 0 | 0% |
| Opponent | advance | 14.1 | 15% | 400 | 364 | 91% |
| Opponent | charge | 6.1 | 58% | 716 | 561 | 78% |
| Opponent | close in | 6.1 | 34% | 448 | 143 | 32% |
| Opponent | hold | 4.2 | 40% | 326 | 0 | 0% |
| Opponent | join | 0.8 | 100% | 31 | 0 | 0% |
| Opponent | shoot | 4.8 | 55% | 150 | 291 | 194% |
| Opponent | support | 5.2 | 92% | 48 | 0 | 0% |

### Packages: hunt the guns, sp-h2h-mine-89601ea-p2

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.1 | 5 | 0 | 20% | 20% | 0% | 3.0 | 240 | 44 | 20% | 31 |
| Opponent | 0.2 | 9 | 1 | 38% | 62% | 0% | 2.4 | 363 | 199 | 62% | 109 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 122 | 0 | 0% | 34 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 172 |
| Dwarfen Mountain Holds | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 456 | 0 | 0% | 30 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 36 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 205 |
| High Elf Realms | 0.2 | 1 | 0 | 100% | 100% | 0% | 3.0 | 233 | 221 | 100% | 0 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 236 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Ogre Kingdoms | 1.0 | 4 | 0 | 50% | 50% | 0% | 3.0 | 414 | 238 | 50% | 225 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 110 |
| Tomb Kings of Khemri | 0.6 | 3 | 1 | 0% | 50% | 0% | 2.0 | 165 | 70 | 50% | 14 |
| Vampire Counts | 0.2 | 2 | 0 | 0% | 50% | 0% | 2.0 | 269 | 124 | 50% | 13 |
| Warriors of Chaos | 0.1 | 1 | 0 | 0% | 0% | 0% | - | 450 | 0 | 0% | 70 |
| Wood Elf Realms | 0.1 | 1 | 0 | 100% | 100% | 0% | 2.0 | 318 | 253 | 100% | 8 |

### Battle groups: sp-h2h-mine-89601ea-p2

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 10.2 | 26% | 44% | 17% | 31% | 29% | 15% | 18% | 37% | 0% |
| Mine | REDIRECT COUNTER | 2.1 | 34% | 72% | 4% | 0% | 4% | 0% | 17% | 79% | 0% |
| Opponent | COUNTER-CHARGE COVER | 6.6 | 20% | 70% | 26% | 42% | 34% | 6% | 6% | 54% | 0% |
| Opponent | REDIRECT COUNTER | 3.4 | 18% | 64% | 18% | 25% | 17% | 6% | 33% | 44% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: sp-h2h-mine-89601ea-p2

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 5 | 16 (5) | 16 | 0 | 52 | 20% | 3.2 | 0 (1) | 50 (1) | - | 0 (1) | 50 (1) |
| Mine | Chaff | 35 | 41 (35) | 3 | 38 | 61 | 46% | 2.2 | 53 (19) | 68 (7) | 4 (9) | 56 (24) | 5 (11) |
| Mine | Character | 123 | 56 (123) | 55 | 1 | 41 | 17% | 2.5 | 57 (38) | 73 (52) | 16 (13) | 69 (49) | 54 (54) |
| Mine | Clean-up | 20 | 42 (20) | 5 | 36 | 46 | 45% | 2.7 | 25 (5) | 40 (12) | 94 (3) | 86 (12) | 3 (8) |
| Mine | Fast | 1 | 0 (1) | 0 | 0 | 100 | 0% | 2.0 | - | 0 (1) | - | 0 (1) | - |
| Mine | Fast Hammer | 44 | 37 (44) | 16 | 21 | 53 | 18% | 2.7 | 27 (21) | 69 (16) | 4 (7) | 36 (27) | 39 (17) |
| Mine | Fragile | 5 | 0 (5) | 0 | 0 | 60 | 0% | 2.0 | - | 0 (3) | 0 (2) | 0 (5) | - |
| Mine | Hammer | 57 | 34 (57) | 25 | 9 | 42 | 21% | 2.7 | 31 (18) | 45 (29) | 9 (10) | 37 (38) | 30 (19) |
| Mine | Holder | 29 | 62 (29) | 28 | 34 | 48 | 28% | 3.4 | 54 (11) | 45 (10) | 104 (8) | 86 (20) | 6 (9) |
| Mine | Shooter | 44 | 77 (44) | 27 | 49 | 59 | 2% | 1.5 | 54 (7) | 88 (30) | 51 (7) | 110 (26) | 30 (18) |
| Mine | Support | 2 | 0 (2) | 0 | 0 | 0 | 100% | - | 0 (1) | 0 (1) | - | - | 0 (2) |
| Mine | War machine | 59 | 55 (59) | 55 | 0 | 55 | 3% | 1.1 | 20 (10) | 52 (37) | 92 (12) | 58 (10) | 54 (49) |
| Mine | Wizard | 22 | 8 (22) | 8 | 0 | 52 | 14% | 2.1 | 0 (4) | 39 (6) | 0 (5) | 0 (4) | 15 (11) |
| Opponent | Blocker | 2 | 0 (2) | 0 | 0 | 0 | 100% | - | - | 0 (2) | - | 0 (1) | 0 (1) |
| Opponent | Chaff | 76 | 56 (76) | 19 | 37 | 44 | 42% | 2.5 | 60 (32) | 56 (19) | 49 (25) | 75 (54) | 10 (22) |
| Opponent | Character | 94 | 64 (94) | 64 | 0 | 33 | 18% | 2.6 | 69 (40) | 74 (40) | 39 (3) | 65 (55) | 77 (28) |
| Opponent | Clean-up | 21 | 26 (21) | 20 | 6 | 43 | 48% | 2.5 | 3 (9) | 48 (12) | - | 11 (15) | 57 (6) |
| Opponent | Early | 2 | 0 (2) | 0 | 0 | 100 | 0% | 5.0 | - | 0 (2) | - | 0 (1) | 0 (1) |
| Opponent | Fast Hammer | 48 | 55 (48) | 45 | 10 | 50 | 17% | 2.8 | 53 (22) | 36 (16) | 95 (10) | 52 (28) | 60 (20) |
| Opponent | Fragile | 5 | 0 (5) | 0 | 0 | 81 | 20% | 2.5 | - | 0 (3) | 0 (2) | 0 (3) | 0 (2) |
| Opponent | Hammer | 68 | 27 (68) | 20 | 7 | 50 | 29% | 2.7 | 21 (17) | 30 (40) | 20 (11) | 28 (42) | 25 (26) |
| Opponent | Holder | 35 | 92 (35) | 11 | 80 | 13 | 20% | 3.7 | 77 (7) | 107 (21) | 65 (6) | 116 (20) | 60 (14) |
| Opponent | Shooter | 33 | 96 (33) | 31 | 65 | 21 | 6% | 1.9 | 135 (8) | 98 (19) | 39 (6) | 141 (22) | 26 (11) |
| Opponent | Support | 3 | 33 (3) | 33 | 0 | 0 | 33% | 5.0 | 0 (1) | 0 (1) | 133 (1) | 133 (1) | 0 (2) |
| Opponent | War machine | 24 | 40 (24) | 40 | 0 | 28 | 12% | 1.7 | 107 (6) | 18 (14) | 30 (4) | 0 (3) | 46 (21) |
| Opponent | Wizard | 29 | 17 (29) | 17 | 0 | 47 | 10% | 1.6 | 0 (10) | 55 (8) | 1 (7) | 37 (11) | 0 (14) |

### Charged fights: sp-h2h-mine-89601ea-p2

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 126 | 18 | 1.0 | 1.0 | 18 | 13 | +5 | 1 of 4 | 3 of 4 | - | +5 |
| Mine | Chaos Dwarfs | 4 | 224 | 196 | 1.5 | 1.0 | 131 | 0 | +131 | 2 of 6 | 4 of 6 | - | +131 |
| Mine | Dwarfen Mountain Holds | 4 | 685 | 0 | 1.8 | 1.0 | 0 | 25 | -25 | 3 of 7 | 3 of 7 | - | -25 |
| Mine | Empire of Man | 5 | 496 | 200 | 2.2 | 1.0 | 91 | 25 | +66 | 7 of 11 | 7 of 11 | - | +66 |
| Mine | Grand Cathay | 4 | 334 | 124 | 2.0 | 1.2 | 62 | 0 | +62 | 3 of 8 | 7 of 8 | +232 | +37 |
| Mine | High Elf Realms | 4 | 237 | 357 | 3.2 | 1.2 | 110 | 9 | +101 | 3 of 13 | 12 of 13 | +150 | +92 |
| Mine | Kingdom of Bretonnia | 1 | 0 | 783 | 5.0 | 1.0 | 157 | 0 | +157 | 3 of 5 | 4 of 5 | - | +157 |
| Mine | Lizardmen | 1 | 231 | 0 | 4.0 | 1.2 | 0 | 0 | +0 | 1 of 4 | 3 of 4 | +0 | +0 |
| Mine | Ogre Kingdoms | 1 | 100 | 231 | 5.0 | 1.0 | 46 | 157 | -111 | 1 of 5 | 2 of 4 | - | -111 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 235 | 3.0 | 1.3 | 78 | 0 | +78 | 1 of 3 | 2 of 3 | +45 | +95 |
| Mine | Skaven | 2 | 230 | 0 | 2.5 | 1.4 | 0 | 108 | -108 | 2 of 5 | 3 of 5 | -362 | -44 |
| Mine | Tomb Kings of Khemri | 1 | 0 | 989 | 5.0 | 1.2 | 198 | 94 | +104 | 1 of 5 | 4 of 5 | -195 | +178 |
| Mine | Vampire Counts | 3 | 53 | 431 | 5.3 | 1.4 | 81 | 35 | +46 | 3 of 16 | 11 of 16 | -6 | +70 |
| Mine | Warriors of Chaos | 1 | 0 | 608 | 2.0 | 1.0 | 304 | 0 | +304 | 0 of 2 | 2 of 2 | - | +304 |
| **Mine** | all armies | 36 | 274 | 220 | 2.6 | 1.2 | 84 | 32 | +53 | 31 of 94 | 67 of 93 | -1 | +60 |
| Opponent | Dwarfen Mountain Holds | 2 | 68 | 142 | 4.5 | 1.2 | 32 | 7 | +25 | 1 of 9 | 9 of 9 | +40 | +21 |
| Opponent | Empire of Man | 2 | 345 | 125 | 2.5 | 1.0 | 50 | 129 | -79 | 2 of 5 | 3 of 5 | - | -79 |
| Opponent | Grand Cathay | 2 | 121 | 1030 | 3.5 | 2.0 | 294 | 0 | +294 | 7 of 7 | 4 of 7 | +341 | +178 |
| Opponent | Kingdom of Bretonnia | 1 | 60 | 963 | 8.0 | 1.0 | 120 | 0 | +120 | 3 of 8 | 7 of 8 | - | +120 |
| Opponent | Ogre Kingdoms | 3 | 96 | 118 | 3.0 | 1.1 | 39 | 24 | +15 | 3 of 9 | 6 of 9 | +45 | +11 |
| Opponent | Skaven | 1 | 238 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 1 of 1 | 1 of 1 | - | +0 |
| Opponent | Tomb Kings of Khemri | 4 | 343 | 874 | 5.5 | 1.3 | 159 | 69 | +90 | 12 of 22 | 14 of 22 | +180 | +56 |
| Opponent | Vampire Counts | 6 | 0 | 802 | 4.5 | 1.1 | 178 | 41 | +137 | 14 of 27 | 22 of 27 | +71 | +148 |
| Opponent | Warriors of Chaos | 8 | 7 | 379 | 3.0 | 1.1 | 126 | 48 | +79 | 12 of 24 | 19 of 24 | -30 | +89 |
| Opponent | Wood Elf Realms | 7 | 55 | 524 | 5.6 | 1.0 | 94 | 34 | +60 | 13 of 39 | 28 of 39 | -102 | +64 |
| **Opponent** | all armies | 36 | 96 | 525 | 4.2 | 1.2 | 125 | 40 | +85 | 68 of 151 | 113 of 151 | +145 | +76 |

### Effective charges: sp-h2h-mine-89601ea-p2

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 0 | 0 | 1 (net -52) | 2 (net +0) | 0 | 1 (net +72) | 0 | 25% (1 of 4) |
| Mine | Chaos Dwarfs | 6 | 2 (net +203) | 0 | 1 (net +268) | 0 | 1 (net +66) | 2 (net +22) | 0 | 17% (1 of 6) |
| Mine | Dwarfen Mountain Holds | 7 | 0 | 0 | 3 (net -20) | 0 | 0 | 2 (net -59) | 2 | 60% (3 of 5) |
| Mine | Empire of Man | 11 | 1 (net +0) | 1 (net +0) | 2 (net +70) | 2 (net +316) | 1 (net +0) | 3 (net -15) | 1 | 20% (2 of 10) |
| Mine | Grand Cathay | 8 | 0 | 0 | 2 (net +116) | 0 | 1 (net +77) | 4 (net +46) | 1 | 29% (2 of 7) |
| Mine | High Elf Realms | 13 | 1 (net +40) | 2 (net +40) | 1 (net +0) | 1 (net +0) | 2 (net +33) | 6 (net +188) | 0 | 8% (1 of 13) |
| Mine | Kingdom of Bretonnia | 5 | 2 (net +102) | 1 (net +0) | 2 (net +289) | 0 | 0 | 0 | 0 | 40% (2 of 5) |
| Mine | Lizardmen | 4 | 1 (net +0) | 0 | 1 (net +0) | 0 | 1 (net +0) | 1 (net +0) | 0 | 25% (1 of 4) |
| Mine | Ogre Kingdoms | 5 | 0 | 0 | 0 | 2 (net +22) | 0 | 2 (net +93) | 1 | 0% (0 of 4) |
| Mine | Orc & Goblin Tribes | 3 | 0 | 0 | 1 (net +45) | 0 | 0 | 1 (net +190) | 1 | 50% (1 of 2) |
| Mine | Skaven | 5 | 0 | 0 | 2 (net -181) | 0 | 0 | 2 (net -88) | 1 | 50% (2 of 4) |
| Mine | Tomb Kings of Khemri | 5 | 0 | 1 (net +324) | 0 | 0 | 1 (net +140) | 0 | 3 | 0% (0 of 2) |
| Mine | Vampire Counts | 16 | 4 (net +2) | 0 | 1 (net +0) | 4 (net -47) | 4 (net +126) | 3 (net +138) | 0 | 6% (1 of 16) |
| Mine | Warriors of Chaos | 2 | 0 | 0 | 0 | 0 | 0 | 2 (net +304) | 0 | 0% (0 of 2) |
| Opponent | Dwarfen Mountain Holds | 9 | 1 (net +65) | 0 | 2 (net +28) | 3 (net +28) | 0 | 2 (net +40) | 1 | 25% (2 of 8) |
| Opponent | Empire of Man | 5 | 1 (net -265) | 0 | 2 (net -190) | 1 (net +140) | 0 | 1 (net +110) | 0 | 40% (2 of 5) |
| Opponent | Grand Cathay | 7 | 4 (net +242) | 0 | 0 | 0 | 1 (net +0) | 2 (net +547) | 0 | 0% (0 of 7) |
| Opponent | Kingdom of Bretonnia | 8 | 1 (net +185) | 2 (net +58) | 1 (net +60) | 0 | 0 | 3 (net +161) | 1 | 14% (1 of 7) |
| Opponent | Ogre Kingdoms | 9 | 3 (net +55) | 0 | 1 (net +0) | 2 (net +94) | 0 | 2 (net -65) | 1 | 12% (1 of 8) |
| Opponent | Skaven | 1 | 0 | 0 | 0 | 1 (net +0) | 0 | 0 | 0 | 0% (0 of 1) |
| Opponent | Tomb Kings of Khemri | 22 | 3 (net -211) | 0 | 3 (net +350) | 4 (net +28) | 2 (net +170) | 8 (net +96) | 2 | 15% (3 of 20) |
| Opponent | Vampire Counts | 27 | 6 (net +122) | 0 | 5 (net +334) | 8 (net +67) | 2 (net +165) | 5 (net +48) | 1 | 19% (5 of 26) |
| Opponent | Warriors of Chaos | 24 | 2 (net +0) | 0 | 3 (net +8) | 6 (net -65) | 1 (net -60) | 11 (net +194) | 1 | 13% (3 of 23) |
| Opponent | Wood Elf Realms | 39 | 5 (net -82) | 1 (net +0) | 7 (net +108) | 8 (net +86) | 2 (net +125) | 14 (net +75) | 2 | 19% (7 of 37) |

### Charged fights, damage counted: sp-h2h-mine-89601ea-p2

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 11 | 257 | 243 | +60 | 85 | 32 | +53 | +20.7 |
| Mine | 50-54% | 5 | 219 | 292 | +81 | 210 | 115 | +95 | +43.5 |
| Mine | Effective (55-75%) | 17 | 280 | 219 | +46 | 119 | 58 | +61 | +21.9 |
| Mine | 76-89% | 11 | 192 | 162 | +44 | 94 | 45 | +49 | +25.5 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 29 | 222 | 180 | +86 | 135 | 23 | +111 | +50.2 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 11 | 452 | 99 | +78 | 81 | 26 | +55 | +12.1 |
| Mine | No odds | 10 | 235 | 224 | -73 | 34 | 105 | -71 | -30.3 |
| Mine | All fights | 94 | 261 | 193 | +53 | 108 | 47 | +61 | +23.5 |
| Opponent | Long shot (under 50%) | 26 | 268 | 272 | +31 | 136 | 118 | +19 | +7.0 |
| Opponent | 50-54% | 3 | 217 | 193 | +38 | 62 | 11 | +51 | +23.4 |
| Opponent | Effective (55-75%) | 24 | 266 | 232 | +135 | 181 | 48 | +132 | +49.7 |
| Opponent | 76-89% | 33 | 259 | 214 | +41 | 108 | 68 | +39 | +15.2 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 48 | 259 | 188 | +122 | 153 | 35 | +119 | +45.7 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 8 | 554 | 158 | +108 | 162 | 51 | +110 | +19.9 |
| Opponent | No odds | 9 | 246 | 234 | +73 | 111 | 65 | +46 | +18.9 |
| Opponent | All fights | 151 | 276 | 216 | +85 | 141 | 61 | +80 | +29.1 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| sp-h2h-mine-89601ea-p2 | move | 434 | 111 (26%) | 73 (17%) | 57 (13%) | 266 (61%) |
| sp-h2h-mine-89601ea-p2 | objective | 353 | 68 (19%) | 48 (14%) | 50 (14%) | 235 (67%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0106, L0122, L2429, L2535, L2735 |
| Charmed Shield | Opponent | L0425, L0827, L0934, L1026, L1727, L1827, L1927 |
| Clockwork Compass | Mine | L1228 |
| Clockwork Compass | Opponent | L0512 |
| Elixir of Power | Mine | L1118, L1135, L1927 |
| Fistful of Laurels | Mine | L1827 |
| Fistful of Laurels | Opponent | L0918, L1118, L1418 |
| Horn of the Wild Hunt | Opponent | L3033 |
| Invocation of Nehek | Mine | L2429, L2535, L2735 |
| Invocation of Nehek | Opponent | L0425, L0827, L1727, L1827, L1927 |
| Opal Amulet | Mine | L1418, L1435 |
| Periapt of Soul Exchange | Mine | L2029, L2131 |
| Periapt of Soul Exchange | Opponent | L0721 |
| Ring of Doom | Mine | L0206, L0222, L1118, L1135, L1228, L1531 |
| Ring of Doom | Opponent | L0512, L1531, L2131, L3033 |
| Ring of Jet | Mine | L1026, L1118, L1135, L1228 |
| Ring of Jet | Opponent | L0512, L0810 |
| Standard of the Fell Warrior | Mine | L1323 |
| Storm Daemon (Renegade 2.0) | Mine | L2131 |
| Storm Daemon (Renegade 2.0) | Opponent | L0721 |
| Twice-Blessed Armour | Mine | L0721, L1026 |
| Twice-Blessed Armour | Opponent | L0307, L0810 |
| Witch Hunter's Ward | Mine | L0721, L0810, L0827 |
| Witch Hunter's Ward | Opponent | L0307 |

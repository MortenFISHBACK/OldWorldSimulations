# Doctrine scorecard: sp-h2h-opp-89601ea-p3

### Scorecard: sp-h2h-opp-89601ea-p3

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0110 | 2 | 1 | Mine | - | - | 3 | 1 | 3 | 0 | 0 | 0 | 387 |
| L0110 | 2 | 1 | Opponent | - | - | 2 | 3 | 0 | 0 | 0 | 0 | 330 |
| L0126 | 6 | 1 | Mine | no | 9 | 6 | 1 | 0 | 0 | 0 | 0 | 322 |
| L0126 | 6 | 1 | Opponent | no | 8 | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L0210 | 6 | 1 | Mine | no | 0 | - | 0 | 5 | 0 | 0 | 0 | 30 |
| L0210 | 6 | 1 | Opponent | no | 13 | 2 | 1 | 0 | 0 | 0 | 0 | 330 |
| L0226 | 4 | 1 | Mine | no | 1 | 3 | 1 | 0 | 1 | 0 | 0 | 523 |
| L0226 | 4 | 1 | Opponent | no | 0 | 2 | 2 | 0 | 0 | 0 | 0 | 0 |
| L0311 | 5 | 1 | Mine | no | - | 3 | 3 | 4 | 0 | 0 | 0 | 675 |
| L0311 | 5 | 1 | Opponent | yes | - | - | 2 | 1 | 0 | 0 | 0 | 330 |
| L0327 | 3 | 1 | Mine | no | 0 | 5 | 1 | 1 | 0 | 0 | 0 | 685 |
| L0327 | 3 | 1 | Opponent | no | 9 | 2 | 3 | 2 | 1 | 0 | 0 | 0 |
| L0413 | 5 | 1 | Mine | - | - | - | - | - | - | - | - | - |
| L0413 | 5 | 1 | Opponent | - | - | - | - | - | - | - | - | - |
| L0429 | 3 | 1 | Mine | yes | 7 | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L0429 | 3 | 1 | Opponent | no | 8 | 2 | 1 | 0 | 1 | 0 | 0 | 375 |
| L0516 | 6 | 1 | Mine | no | 10 | 3 | 1 | 1 | 0 | 0 | 0 | 548 |
| L0516 | 6 | 1 | Opponent | no | 1 | 2 | 2 | 2 | 1 | 0 | 0 | 200 |
| L0533 | 5 | 1 | Mine | yes | - | - | 0 | 1 | 0 | 0 | 0 | 1193 |
| L0533 | 5 | 1 | Opponent | yes | - | 2 | 3 | 5 | 0 | 0 | 0 | 0 |
| L0620 | 2 | 1 | Mine | - | - | 3 | 3 | 2 | 0 | 0 | 0 | 801 |
| L0620 | 2 | 1 | Opponent | - | - | 4 | 0 | 6 | 1 | 0 | 0 | 210 |
| L0709 | 1 | 1 | Mine | yes | 6 | 2 | 5 | 1 | 0 | 0 | 0 | 420 |
| L0709 | 1 | 1 | Opponent | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 524 |
| L0725 | 5 | 1 | Mine | no | - | - | 0 | 1 | 0 | 0 | 0 | 513 |
| L0725 | 5 | 1 | Opponent | yes | - | 2 | 4 | 5 | 0 | 0 | 0 | 0 |
| L0815 | 5 | 1 | Mine | no | - | - | 0 | 1 | 0 | 0 | 0 | 780 |
| L0815 | 5 | 1 | Opponent | yes | - | 2 | 2 | 2 | 1 | 0 | 0 | 115 |
| L0831 | 3 | 1 | Mine | no | 0 | 6 | 1 | 1 | 0 | 0 | 0 | 605 |
| L0831 | 3 | 1 | Opponent | no | 0 | - | 0 | 3 | 2 | 0 | 0 | 314 |
| L0922 | 4 | 1 | Mine | no | 0 | - | 0 | 0 | 0 | 0 | 0 | 664 |
| L0922 | 4 | 1 | Opponent | no | 0 | 2 | 4 | 1 | 1 | 0 | 0 | 0 |
| L1013 | 5 | 1 | Mine | yes | - | 3 | 4 | 2 | 1 | 0 | 0 | 330 |
| L1013 | 5 | 1 | Opponent | no | - | 1 | 1 | 2 | 3 | 0 | 0 | 479 |
| L1030 | 4 | 1 | Mine | no | 0 | 2 | 2 | 0 | 0 | 0 | 0 | 492 |
| L1030 | 4 | 1 | Opponent | yes | 3 | 2 | 2 | 1 | 1 | 0 | 0 | 0 |
| L1122 | 6 | 1 | Mine | no | 3 | 2 | 5 | 0 | 1 | 0 | 0 | 330 |
| L1122 | 6 | 1 | Opponent | no | 3 | 2 | 3 | 2 | 1 | 0 | 0 | 144 |
| L1216 | 4 | 1 | Mine | no | 2 | 2 | 5 | 0 | 0 | 0 | 0 | 330 |
| L1216 | 4 | 1 | Opponent | no | 0 | 2 | 3 | 3 | 0 | 0 | 0 | 200 |
| L1232 | 2 | 1 | Mine | - | - | 3 | 2 | 0 | 0 | 0 | 0 | 330 |
| L1232 | 2 | 1 | Opponent | - | - | 3 | 4 | 3 | 3 | 0 | 0 | 340 |
| L1327 | 1 | 1 | Mine | no | 6 | 4 | 3 | 0 | 0 | 0 | 0 | 140 |
| L1327 | 1 | 1 | Opponent | no | 3 | 1 | 6 | 1 | 2 | 0 | 0 | 0 |
| L1422 | 6 | 1 | Mine | no | 6 | 3 | 5 | 0 | 1 | 0 | 0 | 0 |
| L1422 | 6 | 1 | Opponent | no | 1 | 2 | 4 | 0 | 0 | 0 | 0 | 170 |
| L1519 | 1 | 1 | Mine | no | 1 | 2 | 2 | 1 | 0 | 0 | 0 | 199 |
| L1519 | 1 | 1 | Opponent | no | 0 | 2 | 8 | 1 | 1 | 0 | 0 | 0 |
| L1535 | 5 | 1 | Mine | yes | - | 3 | 2 | 1 | 0 | 0 | 0 | 0 |
| L1535 | 5 | 1 | Opponent | yes | - | 2 | 4 | 2 | 0 | 0 | 0 | 268 |
| L1633 | 1 | 1 | Mine | yes | 8 | 2 | 6 | 1 | 0 | 0 | 0 | 200 |
| L1633 | 1 | 1 | Opponent | no | 4 | 1 | 3 | 3 | 1 | 0 | 0 | 513 |
| L1731 | 3 | 1 | Mine | no | 0 | 2 | 5 | 0 | 0 | 0 | 0 | 98 |
| L1731 | 3 | 1 | Opponent | no | 1 | 2 | 2 | 1 | 3 | 0 | 0 | 340 |
| L1831 | 1 | 1 | Mine | no | 6 | 3 | 2 | 1 | 0 | 0 | 0 | 0 |
| L1831 | 1 | 1 | Opponent | no | 6 | 4 | 2 | 2 | 0 | 0 | 0 | 170 |
| L1932 | 6 | 1 | Mine | no | 3 | 2 | 1 | 0 | 0 | 0 | 0 | 0 |
| L1932 | 6 | 1 | Opponent | no | 0 | 2 | 4 | 3 | 0 | 0 | 0 | 170 |
| L2033 | 5 | 1 | Mine | yes | - | - | 0 | 6 | 1 | 0 | 0 | 407 |
| L2033 | 5 | 1 | Opponent | yes | - | 6 | 1 | 3 | 0 | 0 | 0 | 405 |
| L2223 | 3 | 1 | Mine | no | 0 | 1 | 7 | 0 | 1 | 0 | 0 | 0 |
| L2223 | 3 | 1 | Opponent | no | 3 | 3 | 4 | 1 | 0 | 0 | 0 | 0 |
| L2327 | 5 | 1 | Mine | yes | - | 2 | 4 | 0 | 0 | 0 | 0 | 0 |
| L2327 | 5 | 1 | Opponent | yes | - | 2 | 6 | 3 | 1 | 0 | 0 | 0 |
| L2433 | 3 | 1 | Mine | no | 0 | 4 | 5 | 0 | 0 | 0 | 0 | 0 |
| L2433 | 3 | 1 | Opponent | no | 0 | 2 | 3 | 3 | 0 | 0 | 0 | 0 |
| L2630 | 2 | 1 | Mine | - | - | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L2630 | 2 | 1 | Opponent | - | - | 2 | 6 | 2 | 0 | 0 | 0 | 0 |
| L2832 | 6 | 1 | Mine | no | 6 | - | 0 | 0 | 0 | 0 | 0 | 0 |
| L2832 | 6 | 1 | Opponent | no | 2 | 1 | 4 | 2 | 0 | 0 | 0 | 0 |
| L3133 | 1 | 1 | Mine | no | 2 | 4 | 3 | 0 | 3 | 0 | 0 | 170 |
| L3133 | 1 | 1 | Opponent | no | 6 | 4 | 4 | 0 | 0 | 0 | 0 | 405 |
| **Average** | | | Mine | 26% | 3.3 | 2.9 | 2.5 | 1.0 | 0.3 | 0.0 | 0.0 | 319.2 |
| **Average** | | | Opponent | 26% | 3.1 | 2.2 | 3.0 | 1.9 | 0.7 | 0.0 | 0.0 | 180.9 |

### KPIs: sp-h2h-opp-89601ea-p3

Rules off - Mine only: STAY WORTH, BEST MOVE FOR SHOOTERS, FACE THE CAST, WIZARD FRONT RANK, FIRE PLAN, FIRE IN ORDER, KEEPS THE TARGET, MISSILES IN THE FIRE PLAN, THREAT AT FULL SIZE, SHOOTERS ARE THREATS, SHOOTERS TO THE PRIMARY.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 27% (49 of 184) | 9% (16 of 173) | 18% (65 of 357) |
| Winner chose to follow up after the loser gave ground |  | 93% (57 of 61); on the table 93% | 98% (55 of 56); on the table 100% | 96% (112 of 117); on the table 97% |
| Winner chose to pursue after the loser fell back in good order |  | 50% (4 of 8); on the table 75% | 85% (11 of 13); on the table 92% | 71% (15 of 21); on the table 86% |
| Winner chose to pursue after the loser fled |  | 75% (15 of 20); on the table 90% | 69% (20 of 29); on the table 69% | 71% (35 of 49); on the table 78% |
| Winner chose to follow up or pursue (all three) |  | 85% (76 of 89); on the table 91% | 88% (86 of 98); on the table 90% | 87% (162 of 187); on the table 90% |
| Magic missiles tried each own turn | 50%+ | 27% (92 of 340) | 31% (60 of 191) | 29% (152 of 531) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 45% (92 of 205) | 43% (60 of 139) | 44% (152 of 344) |
|   fighting wizards (on a monster, chariot or monstrous mount) | 50%+ | 22% (42 of 190) | 31% (43 of 137) | 26% (85 of 327) |
|     round 1 |  | 16% (5 of 32) | 30% (7 of 23) | 22% (12 of 55) |
|     rounds 2+ |  | 23% (37 of 158) | 32% (36 of 114) | 27% (73 of 272) |
|   other wizards | 50%+ | 33% (50 of 150) | 31% (17 of 54) | 33% (67 of 204) |
|     round 1 |  | 36% (9 of 25) | 11% (1 of 9) | 29% (10 of 34) |
|     rounds 2+ |  | 33% (41 of 125) | 36% (16 of 45) | 34% (57 of 170) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 35% (9 of 26) | 45% (28 of 62) | 42% (37 of 88) |
| Points that never fought | lower | 35% (23669 of 66802) | 41% (29028 of 69990) | 39% (52697 of 136792) |
|   infantry points that never fought | lower | 45% (6238 of 13726) | 56% (7582 of 13651) | 50% (13820 of 27377) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 55% (145 of 264) | 55% (153 of 277) | 55% (298 of 541) |
| Bound items with a magic missile used (at least once a game) |  | 84% (21 of 25); 1.5 uses a game | 92% (22 of 24); 2.3 uses a game | 88% (43 of 49); 1.9 uses a game |
| Bound items with another spell used |  | 50% (7 of 14); 0.2 uses a game | 33% (2 of 6); 0.1 uses a game | 45% (9 of 20); 0.2 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 60% (12 of 20); 0.3 uses a game | 43% (6 of 14); 0.2 uses a game | 53% (18 of 34); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 50% (28543 of 57457) | 48% (29981 of 62183) | 49% (58524 of 119640) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.2 (17%) | 1.1 (31%) | 2.3 (22%) |
| MARCHED: its unit marched | 1.5 (22%) | 0.8 (22%) | 2.3 (22%) |
| CHARGED: its unit charged | 0.2 (3%) | 0.2 (5%) | 0.4 (4%) |
| IN COMBAT: engaged in combat | 1.7 (25%) | 0.8 (22%) | 2.5 (24%) |
| REAR RANK: in a rear rank | 0.1 (1%) | 0.1 (2%) | 0.1 (1%) |
| FLEEING: fleeing | 0.1 (2%) | 0.0 (0%) | 0.1 (1%) |
| GONE: slain | 1.3 (19%) | 0.4 (11%) | 1.7 (16%) |
| OFF THE TABLE: off the table or not arrived | 0.6 (9%) | 0.2 (7%) | 0.9 (8%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| NOT OFFERED: not in the cast list | 0.1 (2%) | 0.0 (0%) | 0.1 (1%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.6 | 1.1 | 1.9 | 4.2 | 0.8 | 1.5 |
| not cast | 4.1 | 1.6 | 4.3 | 10.5 | 2.5 | 19.0 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) | 0.0 (0%) | 1.4 (8%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (1%) | 0.6 (39%) | 0.4 (10%) | 2.3 (22%) | 0.1 (4%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.3 (22%) | 0.5 (19%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.4 (4%) | 0.1 (3%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.2 (5%) | 0.2 (12%) | 0.8 (19%) | 2.5 (24%) | 0.6 (24%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.2 (4%) | 0.0 (0%) | 0.2 (5%) | 0.1 (1%) | 0.1 (3%) | 0.0 (0%) |
| FLEEING: fleeing | 0.1 (3%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (1%) | 0.4 (2%) |
| GONE: slain | 0.8 (21%) | 0.3 (18%) | 0.9 (20%) | 1.7 (16%) | 0.1 (6%) | 2.6 (13%) |
| OFF THE TABLE: off the table or not arrived | 0.6 (14%) | 0.2 (16%) | 0.8 (19%) | 0.9 (8%) | 0.6 (25%) | 1.4 (7%) |
| STUPIDITY: Stupidity | 0.1 (3%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (3%) | 0.0 (2%) | 0.0 (0%) | 0.1 (1%) | 0.4 (15%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.8 (45%) | 0.2 (14%) | 1.1 (27%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 13.2 (69%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.3 a game | 0.6 a game | 1.0 a game |
| stood (cast and not dispelled) | 74% (28 of 38) | 59% (10 of 17) | 69% (38 of 55) |
| the unit moved after it | 89% (25 of 28) | 80% (8 of 10) | 87% (33 of 38) |
| it charged on its next turn | 0% (0 of 28) | 10% (1 of 10) | 3% (1 of 38) |
| the enemy charged it first | 14% (4 of 28) | 10% (1 of 10) | 13% (5 of 38) |
| it fought by the end of its next turn | 4% (1 of 28) | 0% (0 of 10) | 3% (1 of 38) |
| it moved out of a charge the enemy had planned (not charged first) | 21% (6 of 28) | 0% (0 of 10) | 16% (6 of 38) |
| none of these (no charge, no fight, no charge escaped) | 64% (18 of 28) | 80% (8 of 10) | 68% (26 of 38) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 68% (492 of 719) | 60% (342 of 568) | 65% (834 of 1287) |
|   cavalry | 68% (34 of 50) | 66% (65 of 98) | 67% (99 of 148) |
|   character | 61% (58 of 95) | 26% (31 of 118) | 42% (89 of 213) |
|   chariot | 56% (46 of 82) | 89% (24 of 27) | 64% (70 of 109) |
|   infantry | 57% (113 of 198) | 65% (159 of 245) | 61% (272 of 443) |
|   monster | 50% (17 of 34) | 67% (4 of 6) | 52% (21 of 40) |
|   war machine | 86% (224 of 260) | 80% (59 of 74) | 85% (283 of 334) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.0 (32%) | 1.2 (19%) | 3.2 (25%) |
| CHARGED: it charged | 0.9 (15%) | 1.5 (23%) | 2.4 (19%) |
| FLEEING: it fled or was fleeing | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: it fought this turn or the last | 0.6 (10%) | 0.7 (12%) | 1.3 (11%) |
| MOVED: a war machine that moved | 0.1 (1%) | 0.0 (0%) | 0.1 (0%) |
| NO TARGET IN RANGE | 0.9 (14%) | 0.9 (14%) | 1.8 (14%) |
| ONLY IN COMBAT: the only targets were in combat | 0.2 (3%) | 0.6 (10%) | 0.8 (6%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.1 (17%) | 0.9 (15%) | 2.0 (16%) |
| SHELTERED: the target was sheltered | 0.2 (3%) | 0.2 (4%) | 0.4 (3%) |
| OTHER BAR | 0.3 (5%) | 0.2 (4%) | 0.6 (4%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 4.1 | 1.0 | 79% | 6.2 pts | 25 pts |
| character | 2.8 | 1.0 | 79% | 6.7 pts | 19 pts |
| chariot | 1.9 | 0.6 | 76% | 7.9 pts | 15 pts |
| infantry | 11.8 | 4.4 | 72% | 9.1 pts | 108 pts |
| monster | 0.7 | 0.2 | 84% | 5.2 pts | 4 pts |
| war machine | 8.3 | 7.8 | 58% | 26.6 pts | 221 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.6 | 5.9 | 4.8 |
| Charges that made contact a game | 2.6 | 4.2 | 3.4 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.96 declared, 0.77 contact (26 units) | 1.05 declared, 0.79 contact (19 units) | 1.00 declared, 0.78 contact (45 units) |
|   per unit a game, units carrying another wizard (or one alone) | 1.00 declared, 0.50 contact (4 units) | 1.70 declared, 1.00 contact (10 units) | 1.50 declared, 0.86 contact (14 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.46 declared, 0.31 contact (223 units) | 0.66 declared, 0.47 contact (266 units) | 0.57 declared, 0.40 contact (489 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 53% (39 of 74) | 40% (6 of 15) | 50% (5 of 10) | 51% (50 of 99) |
| Character in a unit | 82% (31 of 38) | 79% (11 of 14) | 50% (3 of 6) | 78% (45 of 58) |
| Character on its own | 85% (33 of 39) | 49% (19 of 39) | 22% (15 of 67) | 46% (67 of 145) |
| Chariot | 73% (8 of 11) | 70% (7 of 10) | - | 71% (15 of 21) |
| Infantry | 57% (37 of 65) | 44% (18 of 41) | 40% (2 of 5) | 51% (57 of 111) |
| Monster | 53% (18 of 34) | 57% (4 of 7) | - | 54% (22 of 41) |
| Monstrous | 80% (8 of 10) | 55% (6 of 11) | - | 67% (14 of 21) |
| War Machines | 63% (27 of 43) | 50% (1 of 2) | - | 62% (28 of 45) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 100% (12 of 12); on the table 100% | 26% (25 of 96) | 26% | 68% (15 of 22) | 100% (6 of 6); 2.5 uses a game | 100% (2 of 2); 0.5 uses a game | 83% (5 of 6); 1.2 uses a game |
| Chaos Dwarfs | 3 | 67% (4 of 6); on the table 67% | 53% (16 of 30) | 41% | 54% (13 of 24) | 0.0 uses a game | 0.0 uses a game | 100% (2 of 2); 0.7 uses a game |
| Dwarfen Mountain Holds | 3 | - | - | 77% | 71% (17 of 24) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 6 | 80% (4 of 5); on the table 80% | 60% (18 of 30) | 61% | 66% (39 of 59) | 0.0 uses a game | 0% (0 of 2); 0.2 uses a game | 25% (1 of 4); 0.2 uses a game |
| Grand Cathay | 8 | 100% (22 of 22); on the table 100% | 24% (47 of 192) | 43% | 50% (37 of 74) | 78% (14 of 18); 5.8 uses a game | 0% (0 of 4); 0.0 uses a game | 38% (3 of 8); 0.4 uses a game |
| High Elf Realms | 6 | 67% (8 of 12); on the table 83% | 28% (10 of 36) | 29% | 43% (20 of 46) | 88% (7 of 8); 2.7 uses a game | 60% (6 of 10); 1.2 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 3 | 100% (8 of 8); on the table 100% | - | 56% | 28% (5 of 18) | 0.0 uses a game | 0.0 uses a game | 100% (3 of 3); 1.0 uses a game |
| Lizardmen | 1 | 71% (5 of 7); on the table 86% | 33% (2 of 6) | 24% | 43% (3 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 1 | 33% (1 of 3); on the table 100% | 0% (0 of 6) | 15% | 71% (5 of 7) | 100% (1 of 1); 4.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 2 | 100% (6 of 6); on the table 100% | 8% (1 of 12) | 9% | 69% (11 of 16) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.5 uses a game |
| Skaven | 2 | 67% (2 of 3); on the table 100% | 0% (0 of 12) | 65% | 50% (7 of 14) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.5 uses a game |
| Tomb Kings of Khemri | 6 | 86% (19 of 22); on the table 91% | 50% (3 of 6) | 31% | 42% (11 of 26) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 8 | 97% (34 of 35); on the table 97% | 24% (13 of 54) | 24% | 41% (19 of 46) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 11 | 77% (27 of 35); on the table 77% | 40% (12 of 30) | 32% | 50% (48 of 96) | 100% (4 of 4); 1.5 uses a game | 0.0 uses a game | 100% (2 of 2); 0.2 uses a game |
| Wood Elf Realms | 6 | 91% (10 of 11); on the table 91% | 0% (0 of 12) | 45% | 77% (48 of 62) | 91% (10 of 11); 6.3 uses a game | 0.0 uses a game | 0% (0 of 5); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (sp-h2h-opp-89601ea-p3, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 42% (39) | 53% (33) | 47% (72) |
| ...free all their last turn and able to turn (per game) | 0.69 | 0.53 | 1.22 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.17 | 0.17 | 0.33 |
| ...with the charger already in that arc before they moved (per game) | 0.56 | 0.44 | 1.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 1.97 | 0.97 | 2.94 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.94 | 0.75 | 1.69 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 5.25 | 5.39 | 10.64 |

### Quality by phase: sp-h2h-opp-89601ea-p3

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.2 | 3.6 |
| Strategy | Charge objectives carried out (made contact) | 53% (62 of 116) | 49% (82 of 168) |
| Strategy | Shoot objectives carried out (shot that target) | 46% (157 of 343) | 46% (112 of 244) |
| Strategy | Close-in objectives charged next turn | 15% (24 of 161) | 20% (45 of 225) |
| Strategy | Support requests answered (helper made contact too) | 20% (2 of 10) | 47% (7 of 15) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (3 of 3) | - |
| Strategy | Hexes on a unit its side charged or shot that turn | 67% (4 of 6) | 75% (6 of 8) |
| Strategy | Joined characters whose unit fought | 37% (16 of 43) | 23% (10 of 43) |
| Strategy | Lone characters that fought | 77% (69 of 90) | 78% (69 of 88) |
| Movement | Charges halted short of contact | 0.1 | 0.3 |
| Movement | Idle units | 1.0 | 1.9 |
| Movement | Points that never moved of their own | 319.2 | 180.9 |
| Movement | Fights charged into per game | 2.6 | 3.5 |
| Movement | Charges with odds: long shots (under 50%) | 7 of 79, net +45 | 25 of 104, net +122 |
| Movement | Charges with odds: sweet spot (55-75%) | 12 of 79, net +160 | 14 of 104, net +30 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 14 of 79, net +17 | 14 of 104, net +51 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 28 of 79, net +117 | 26 of 104, net +198 |
| Shooting | Shots by shooting units (incl. breath weapons) | 8.2 | 9.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 37% (109 of 294) | 33% (112 of 336) |
| Shooting | Points destroyed by shooting units | 59.7 | 52.1 |
| Shooting | War machine shots | 6.2 | 2.1 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 56% (126 of 224) | 31% (23 of 74) |
| Shooting | Points destroyed by war machines | 69.7 | 39.9 |
| Magic | Magic missiles cast | 1.4 | 1.0 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 39% (20 of 51) | 24% (9 of 37) |
| Magic | Wounds caused by magic missiles | 2.8 | 2.5 |
| Magic | Wounds caused by other spells | 0.9 | 1.1 |
| Magic | Points destroyed by magic (all spells) | 52.5 | 47.4 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.5 / 0.2 / 0.4 / 0.1 | 1.6 / 0.3 / 0.3 / 0.4 |
| Combat | Points destroyed in combat | 328.1 | 365.3 |
| Combat | Points run down | 74.8 | 122.6 |
| Combat | Net points per charged fight, damage counted | +90 | +97 |
| Combat | Net per 100 charger points, damage counted | +30.6 | +33.1 |
| Combat | First round won (charged fights) | 72% | 69% |
| Combat | Net points per charged fight | +90 | +95 |
| Combat | Net points per supported fight / lone fight | +9 / +99 | +175 / +88 |
| Combat | Charged fights on a top-3 enemy unit | 20 of 90 | 62 of 123 |
| Game | Points lost | 774.1 | 713.5 |
| Game | VP from objectives | 500.0 | 628.0 |
| Game | Lone holders (player turns) | 3.3 | 3.1 |

- Mine won / drew / lost: 10 / 7 / 18 of 35 ended games (of 36); mean margin (Mine - Opponent) -226 VP
- The side that went first won 13 of 28 games with a winner
- Points traded per game (both sides' losses): 1488
- Games not ended: 1 (L0413-1); findings 1, warnings 0

### Opponent rules: sp-h2h-opp-89601ea-p3

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.6 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 0.0 |
| ARRIVAL HUNT | - | - | - | - | 0.1 | +0.3 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.9 | +0.0 | 0.0 | 35.0 | 0.2 | +0.0 | 0.0 | 4.6 |
| BACKUP TARGETS | 0.8 | +7.1 | 0.0 | 19.9 | 0.7 | +7.8 | 0.0 | 13.3 |
| BEST FACING | 0.8 | +32.4 | 0.0 | 41.3 | 0.4 | +24.1 | 0.0 | 32.9 |
| BEST FIRST | 4.4 | +178.7 | 137.9 | 130.8 | 3.0 | +149.7 | 144.7 | 76.8 |
| BEST MOVE FOR SHOOTERS | - | - | - | - | 0.5 | +62.3 | 0.0 | 16.0 |
| BEST OVERALL | 0.9 | +76.9 | 0.0 | 70.4 | 0.6 | +54.7 | 0.0 | 39.5 |
| BEST PREY | 0.8 | +59.8 | 7.3 | 6.8 | 0.9 | +30.5 | 20.7 | 2.9 |
| BEST PRIZE | 0.1 | +6.3 | 3.5 | 0.0 | 0.1 | +3.7 | 0.0 | 1.4 |
| BIG CHARACTER SAFETY | 0.2 | -0.0 | 0.0 | 12.1 | 0.3 | +0.0 | 0.0 | 22.1 |
| BLOCKED CHARGE SKIPPED | - | - | - | - | 0.2 | +0.0 | 0.0 | 0.0 |
| BLOCKED WHEEL | 0.7 | +16.8 | 0.0 | 0.0 | 0.4 | +6.5 | 0.0 | 0.5 |
| BOMBING RUN | 0.0 | +0.3 | 0.0 | 4.2 | - | - | - | - |
| BOUND ASSAILMENT | 0.0 | +0.0 | 0.0 | 4.2 | - | - | - | - |
| CANNON PLAN MISSED | 1.0 | +0.0 | 112.4 | 23.1 | - | - | - | - |
| CANNON PLANNED TARGET | 5.4 | +186.7 | 357.7 | 145.8 | - | - | - | - |
| CANNON SIGHT KEPT | 1.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT COUNTER | 0.0 | -3.7 | 7.6 | 0.0 | - | - | - | - |
| CARRIES OUT SET-UP | 0.2 | -6.2 | 24.6 | 20.8 | 0.1 | -2.5 | 16.4 | 3.2 |
| CAST JOB | 0.9 | +43.9 | 86.6 | 7.0 | 1.0 | +16.6 | 31.6 | 4.5 |
| CASTER AWAY FROM SCREEN | 0.2 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.2 | +20.8 | 10.0 | 4.8 | 0.1 | -0.6 | 0.0 | 6.0 |
| CASTS AFTER FRIENDS | 0.8 | +0.0 | 0.0 | 43.5 | 0.3 | +0.0 | 0.0 | 14.1 |
| CASTS FROM BEHIND | 0.0 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CATCH ODDS | 0.0 | +0.2 | 0.0 | 0.0 | - | - | - | - |
| CHAFF PASSED | 0.1 | -0.1 | 5.4 | 0.0 | - | - | - | - |
| CHAMPION TAKES THE CHALLENGE | - | - | - | - | 0.0 | +1.0 | 11.3 | 0.0 |
| CHARGE NOW FIRST | 2.2 | +0.0 | 212.4 | 52.2 | 2.9 | +0.0 | 275.2 | 57.9 |
| CHARGE NOW WEIGHED | 0.6 | -34.2 | 21.1 | 0.0 | 0.4 | -36.9 | 15.7 | 9.6 |
| CHARIOT NO STATIC JOB | 0.1 | +0.0 | 0.0 | 4.7 | - | - | - | - |
| CHARIOT WIZARD CAREFUL | - | - | - | - | 0.2 | -0.9 | 0.0 | 15.0 |
| CHEAP HELPER | 0.1 | +0.0 | 5.2 | 0.0 | 0.1 | +0.0 | 0.0 | 3.0 |
| COMBAT PIVOT | 0.5 | +0.0 | 9.4 | 12.5 | 0.4 | +0.0 | 28.1 | 14.2 |
| CONVEYANCE SEARCH | 0.8 | +56.9 | 47.1 | 47.5 | 0.4 | +31.5 | 0.0 | 14.1 |
| COUNTER-CHARGE COVER | 8.9 | +850.5 | 0.0 | 242.4 | 6.7 | +667.3 | 0.0 | 152.4 |
| DEFENSIVE ARMY | 0.1 | -0.0 | 13.1 | 12.8 | 0.1 | +0.0 | 4.9 | 0.0 |
| DEFENSIVE FLOOR | 0.0 | +1.9 | 0.0 | 0.0 | 0.0 | +2.9 | 0.0 | 0.0 |
| EDGE GIVE GROUND | 0.3 | +7.9 | 13.8 | 1.7 | 0.2 | +2.6 | 17.0 | 1.2 |
| ELIXIR WORTH | 0.0 | +0.1 | 0.0 | 9.7 | - | - | - | - |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACE THE CAST | - | - | - | - | 0.1 | +0.4 | 0.0 | 0.0 |
| FACES THE THREAT | 2.0 | +156.4 | 0.0 | 96.4 | 1.0 | +82.1 | 0.0 | 42.5 |
| FALLBACK BY WORTH | 4.8 | +62.1 | 0.0 | 115.7 | 5.3 | +59.9 | 0.0 | 30.4 |
| FIGHT LIFT | 0.1 | +1.0 | 3.9 | 0.0 | - | - | - | - |
| FIRE AND FLEE | 0.0 | +0.4 | 2.9 | 2.2 | - | - | - | - |
| FIRE IN ORDER | - | - | - | - | 0.4 | +0.0 | 2.5 | 6.4 |
| FIRE PLAN | - | - | - | - | 11.2 | +393.5 | 763.2 | 164.5 |
| FLANK NOT WEIGHED | 5.5 | +0.0 | 0.0 | 195.0 | 5.1 | +0.0 | 0.0 | 127.1 |
| FOLLOW UP WEIGHED | 1.2 | +181.3 | 0.0 | 92.6 | 1.2 | +200.7 | 0.0 | 46.2 |
| FRIENDS SHOTS CHECKED | 0.2 | +11.2 | 0.0 | 0.0 | 0.2 | +16.1 | 0.0 | 0.0 |
| GIVES UP | 0.1 | -0.3 | 4.1 | 0.0 | 0.2 | -2.7 | 51.9 | 9.1 |
| GIVES UP ITS SCREEN | - | - | - | - | 0.1 | -1.0 | 4.5 | 1.2 |
| GROUND FLIERS | 0.0 | +1.6 | 0.0 | 0.0 | - | - | - | - |
| HELPER UNSEEN | 0.1 | +0.0 | 0.0 | 3.2 | 0.2 | +0.0 | 28.0 | 2.0 |
| HILL BY ITS CHANCE | 0.1 | -14.2 | 0.0 | 1.8 | 0.5 | -47.3 | 0.0 | 14.1 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HORN WORTH | - | - | - | - | 0.1 | +1.7 | 0.0 | 14.0 |
| HUNT ADVANCE | 0.3 | +11.7 | 49.6 | 2.9 | 0.2 | +6.3 | 10.8 | 5.8 |
| HUNT DROPPED | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 6.9 | 0.0 |
| HUNT IN PAIRS | 0.2 | +9.7 | 0.0 | 17.5 | 0.7 | +55.7 | 0.0 | 10.8 |
| HUNT KEPT | 0.3 | +9.1 | 30.0 | 0.0 | 0.1 | +2.6 | 10.8 | 5.8 |
| HUNT RESULT | 0.2 | +30.0 | 4.6 | 1.4 | 0.2 | +18.2 | 6.9 | 5.8 |
| HUNT THE GUNS | 0.2 | +100.2 | 34.6 | 2.9 | 0.2 | +61.1 | 10.0 | 0.5 |
| INVITES THE FIGHT | 1.5 | +41.1 | 88.9 | 2.9 | 1.2 | +25.4 | 49.6 | 11.1 |
| JOINT CHARGE PLAN | 0.1 | +14.1 | 0.0 | 1.7 | 0.2 | +4.5 | 4.8 | 11.9 |
| KEEP FALLS | 0.1 | +1.9 | 0.0 | 6.1 | 0.0 | +0.0 | 0.0 | 0.0 |
| KEEPS ITS PREY | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KEEPS ITS TARGET | 1.4 | +40.8 | 122.4 | 34.8 | 2.2 | +66.7 | 215.4 | 47.7 |
| KEEPS SCOUTS OR AMBUSH | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KEEPS THE TARGET | - | - | - | - | 0.9 | -48.6 | 53.1 | 21.7 |
| KILLS COUNT | 1.4 | +60.9 | 102.6 | 27.5 | 2.2 | +102.0 | 182.9 | 26.4 |
| KILLS COUNT NEXT TURN | 5.7 | +220.9 | 232.9 | 144.5 | 7.5 | +267.8 | 336.7 | 133.7 |
| LONE CHARACTER SAFE SPOT | 0.4 | +13.5 | 12.3 | 0.0 | 0.3 | +10.7 | 9.1 | 4.6 |
| LONE WIZARD HOLDS BACK | 0.1 | +0.0 | 3.0 | 0.0 | 0.3 | +0.0 | 16.7 | 5.4 |
| LONE WIZARD KEPT IN | 0.6 | +37.3 | 0.0 | 0.0 | 0.4 | +25.4 | 0.0 | 0.0 |
| LONG SHOT | 0.2 | +2.5 | 15.3 | 1.7 | 0.2 | -0.8 | 22.5 | 1.4 |
| LOST CHARGE | 3.0 | -62.8 | 165.9 | 129.7 | 2.5 | -37.4 | 101.4 | 52.2 |
| LURE BY WHAT IT DRAWS | - | - | - | - | 0.0 | -5.2 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 0.9 | +110.7 | 39.8 | 26.2 | 0.8 | +92.5 | 30.7 | 17.1 |
| MANOEUVRE | 0.4 | +23.3 | 0.0 | 1.8 | 0.2 | +2.5 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.1 | +3.8 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| MARCH CHECK | 0.6 | +43.2 | 0.0 | 22.4 | 0.4 | +31.1 | 0.0 | 8.4 |
| MARCH ODDS | 0.3 | +19.6 | 20.6 | 5.4 | 0.1 | +7.5 | 3.2 | 5.4 |
| MARCH OVER CASTS | 0.7 | +56.8 | 0.0 | 40.5 | 0.3 | +27.2 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 4.6 | +192.7 | 0.0 | 141.6 | 4.3 | +180.3 | 0.0 | 87.9 |
| MISSILES IN THE FIRE PLAN | - | - | - | - | 2.6 | +74.9 | 88.0 | 32.0 |
| MISSILES IN THE MOVE | 3.8 | +164.1 | 0.0 | 124.8 | 4.3 | +63.3 | 0.0 | 59.6 |
| MISSILES NEXT TURN | 4.9 | +104.8 | 0.0 | 180.5 | 5.0 | +42.0 | 0.0 | 62.6 |
| MODEL FACING | 0.1 | +31.2 | 0.0 | 1.7 | - | - | - | - |
| MONSTER WIZARD ROAMS | 0.3 | +0.0 | 37.6 | 12.1 | 0.1 | +0.0 | 8.9 | 0.0 |
| MOVE AND CAST | 0.4 | +34.5 | 0.0 | 6.9 | 0.4 | +13.8 | 0.0 | 22.4 |
| MOVE SPELL IN RANGE | 0.2 | +7.1 | 0.0 | 10.6 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.4 | -13.0 | 0.0 | 46.1 | 0.1 | -0.9 | 0.0 | 13.0 |
| MOVE SPELL SPOT | 0.6 | +0.0 | 0.0 | 38.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE | 3.2 | +268.7 | 152.6 | 84.9 | 5.1 | +510.3 | 243.6 | 78.1 |
| MOVES UNITS SPELL | 0.1 | +3.6 | 0.0 | 0.0 | 0.1 | +0.3 | 0.0 | 0.0 |
| NEEDED THERE | - | - | - | - | 0.2 | +14.2 | 28.8 | 0.0 |
| NO RALLY LEFT | 0.1 | +2.3 | 0.0 | 0.0 | - | - | - | - |
| NOT NEEDED | 0.2 | -9.7 | 26.9 | 0.0 | 0.2 | -30.8 | 38.0 | 1.1 |
| NOT TURNED | 5.2 | +125.0 | 0.0 | 125.0 | 5.4 | +92.7 | 0.0 | 91.7 |
| NOT WORTH A CAST | 0.5 | -0.4 | 0.0 | 31.0 | 0.8 | -0.8 | 0.0 | 6.5 |
| OFF BEST | 14.6 | -747.1 | 12.2 | 291.8 | 13.8 | -835.7 | 10.9 | 200.6 |
| OPENS A LANE | 0.1 | +0.1 | 14.7 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| OPENS UP | 0.2 | +6.0 | 6.6 | 13.9 | 0.4 | +40.0 | 30.7 | 0.0 |
| OVERRUNS AWAY | 0.4 | +9.8 | 48.1 | 17.6 | 0.3 | +3.2 | 29.8 | 10.9 |
| PATHS CROSS | 1.9 | +113.9 | 0.0 | 16.3 | 2.4 | +227.1 | 0.0 | 24.0 |
| PERIAPT WORTH | - | - | - | - | 0.0 | +1.5 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.1 | -4.4 | 0.0 | 0.0 | 0.2 | -5.8 | 0.0 | 2.9 |
| PLAN RESULT | 35.2 | +1357.5 | 1397.7 | 975.7 | 36.9 | +1370.3 | 1562.3 | 919.2 |
| PURSUES BIG PREY | - | - | - | - | 0.0 | -1.5 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE | 0.0 | +6.6 | 0.0 | 0.0 | 0.1 | +11.5 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE NEXT TURN | 0.1 | +4.9 | 0.0 | 0.0 | 0.0 | +1.0 | 0.0 | 0.0 |
| RANDOM MOVE BY FIGURES | 0.7 | +6.7 | 0.0 | 11.7 | 1.7 | +19.4 | 0.0 | 48.3 |
| RANDOM MOVER NO PROMISE | 0.1 | -5.7 | 0.0 | 0.0 | 0.6 | -36.3 | 19.5 | 15.3 |
| REDIRECT BY WHAT IT STOPS | 0.1 | -3.3 | 0.0 | 0.0 | 0.5 | +4.8 | 0.0 | 5.1 |
| REDIRECT COUNTER | 1.9 | +156.0 | 0.0 | 51.0 | 3.5 | +342.4 | 0.0 | 51.3 |
| REDIRECT WEIGHED | 0.2 | +7.4 | 11.8 | 0.0 | 0.4 | +9.2 | 8.7 | 1.4 |
| RESERVE FALL BACK | 0.4 | +5.7 | 0.0 | 6.5 | 0.7 | +19.4 | 0.0 | 10.1 |
| RESTRAINS TO SHOOT | 0.1 | +7.1 | 0.0 | 0.0 | 0.1 | +7.0 | 0.0 | 17.2 |
| RISK BY ARC | 2.1 | +77.1 | 175.4 | 67.8 | 2.4 | +56.2 | 262.4 | 67.4 |
| SAFE SURE CHARGE | - | - | - | - | 0.0 | -1.3 | 0.0 | 0.0 |
| SAFER THAN THE JOB | 0.9 | +60.3 | 0.0 | 17.2 | 0.8 | +66.3 | 0.0 | 22.3 |
| SCOUT SPOT | 0.4 | +0.5 | 0.0 | 0.9 | 0.3 | +0.8 | 0.0 | 0.0 |
| SCOUT WAITS | 0.4 | +0.0 | 0.0 | 0.9 | 0.3 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.1 | +1.3 | 0.0 | 0.0 | 0.1 | -4.7 | 0.0 | 0.0 |
| SEARCH SPOT | 2.6 | +124.9 | 0.0 | 50.3 | 2.1 | +126.6 | 0.0 | 36.4 |
| SECOND HUNTER | 0.1 | -1.2 | 15.0 | 1.4 | 0.0 | -0.0 | 5.4 | 0.5 |
| SELF MOVE SPELL | 0.4 | +49.8 | 0.0 | 11.0 | 0.1 | +43.8 | 0.0 | 20.0 |
| SET UP TOGETHER | 1.2 | +137.1 | 67.8 | 41.5 | 1.7 | +161.7 | 30.7 | 24.2 |
| SET-UP ANY TARGET | 0.4 | +84.2 | 47.1 | 35.0 | 0.2 | +21.0 | 0.0 | 0.0 |
| SET-UP MISSED | 0.0 | +6.0 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS ARE THREATS | - | - | - | - | 3.1 | +399.5 | 191.3 | 41.9 |
| SHOOTERS IN TWO RANKS | 0.4 | +0.7 | 0.0 | 0.0 | 0.1 | +0.3 | 0.0 | 0.0 |
| SHOOTERS TO THE PRIMARY | - | - | - | - | 3.9 | +276.4 | 0.0 | 57.3 |
| SHOOTS FROM THE BEST SPOT | 0.7 | +29.8 | 57.5 | 21.8 | 0.5 | +13.4 | 27.2 | 14.4 |
| SHORT GUN FORWARD | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SHOT OPTIONS | 14.3 | +0.0 | 517.0 | 350.8 | 10.4 | +0.0 | 518.4 | 152.8 |
| SHOT REPLANNED | 0.8 | +0.0 | 153.1 | 15.0 | - | - | - | - |
| SHOTS IN THE MOVE | 13.3 | +569.7 | 0.0 | 320.4 | 9.5 | +333.3 | 0.0 | 162.0 |
| SPELL SETS UP CHARGE | 0.5 | +105.3 | 47.1 | 35.0 | 0.2 | +21.0 | 0.0 | 0.0 |
| SPELL WORTH | 1.3 | +16.5 | 63.5 | 72.5 | 2.2 | +30.4 | 92.5 | 84.5 |
| STABLE ROLE | 9.9 | +0.0 | 433.3 | 153.8 | 8.6 | +0.0 | 340.0 | 105.6 |
| STANDS TO CAST | - | - | - | - | 0.0 | +1.0 | 0.0 | 3.0 |
| STAY WEIGHED | 0.0 | +1.8 | 0.0 | 0.0 | - | - | - | - |
| STAY WORTH | - | - | - | - | 10.2 | +58.5 | 338.9 | 103.4 |
| STOPS | 0.2 | +6.1 | 0.0 | 0.0 | 0.1 | +2.8 | 10.0 | 0.5 |
| STOPS SHORT OF THE FLANK | 0.4 | +23.4 | 0.0 | 25.7 | 0.5 | +34.2 | 0.0 | 33.4 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 4.7 |
| SUPPORT NARROWED | 5.1 | -44.3 | 244.1 | 71.0 | 6.0 | -51.5 | 426.6 | 121.6 |
| SUPPORTS | 3.4 | +56.2 | 96.9 | 45.2 | 3.8 | +54.3 | 233.2 | 48.1 |
| SURE CHARGE BEATS ADVANCE | 0.2 | -8.3 | 9.6 | 9.7 | 0.1 | -2.1 | 2.8 | 2.7 |
| SURE REACH TOGETHER | 0.4 | +5.2 | 3.3 | 18.1 | 0.6 | -1.4 | 0.0 | 0.0 |
| THREAT AT FULL SIZE | - | - | - | - | 5.5 | +0.0 | 339.4 | 78.5 |
| THROUGH LINE OF FIRE | 0.4 | +16.7 | 0.0 | 12.9 | 0.1 | +10.1 | 0.0 | 0.0 |
| TURN WORTH | 0.6 | -46.0 | 52.6 | 13.9 | 0.5 | -45.4 | 58.0 | 3.8 |
| TWO OR MORE ARRIVE | 0.5 | +6.8 | 7.3 | 1.7 | 0.5 | +5.9 | 14.2 | 6.2 |
| WAIT AFTER COSTS | 6.9 | -319.8 | 311.8 | 150.1 | 7.8 | -455.1 | 366.2 | 115.3 |
| WALKS TO THE FIGHT | 1.7 | +40.2 | 60.7 | 44.6 | 1.0 | +17.5 | 38.5 | 7.3 |
| WAR ENGINE CHARGES | 0.1 | +13.0 | 11.1 | 12.4 | 0.1 | +0.7 | 1.7 | 2.1 |
| WAR ENGINE JOBS | 0.6 | +0.0 | 48.4 | 23.1 | 0.1 | +0.0 | 4.7 | 3.8 |
| WEARS DOWN | 0.8 | +32.3 | 62.8 | 33.2 | 1.3 | +61.6 | 182.6 | 58.2 |
| WHO HITS BACK | 0.3 | +46.5 | 0.0 | 6.4 | 0.2 | +27.5 | 0.0 | 15.0 |
| WHOLE FIGHT | 0.4 | -1.3 | 49.3 | 6.9 | 0.5 | +3.8 | 120.3 | 0.0 |
| WHOLE FIGHT GAIN | 0.2 | +7.0 | 16.5 | 13.8 | 0.4 | +30.2 | 37.5 | 6.3 |
| WIZARD FRONT RANK | - | - | - | - | 0.0 | +0.0 | 0.0 | 9.1 |

### Rule changes: sp-h2h-opp-89601ea-p3

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 1021 | 1021 | 1021 | 28.36 | -56980 | -55.8 |
| BEST FIRST | 268 | 268 | 268 | 7.44 | +11823 | +44.1 |
| SEARCH SPOT | 169 | 169 | 169 | 4.69 | +9056 | +53.6 |
| MOVE TO CHARGE | 301 | 301 | 168 | 4.67 | +11151 | +66.4 |
| PATHS CROSS | 153 | 153 | 153 | 4.25 | +12278 | +80.2 |
| FIRE PLAN | 404 | 404 | 141 | 3.92 | +5532 | +39.2 |
| COUNTER-CHARGE COVER | 563 | 311 | 130 | 3.61 | +9782 | +75.2 |
| KILLS COUNT NEXT TURN | 474 | 474 | 115 | 3.19 | +3186 | +27.7 |
| FACES THE THREAT | 106 | 106 | 106 | 2.94 | +8583 | +81.0 |
| FALLBACK BY WORTH | 364 | 364 | 88 | 2.44 | +4393 | +49.9 |
| FOLLOW UP WEIGHED | 88 | 88 | 88 | 2.44 | +13755 | +156.3 |
| SUPPORTS | 256 | 256 | 85 | 2.36 | +924 | +10.9 |
| SHOTS IN THE MOVE | 822 | 550 | 80 | 2.22 | +2639 | +33.0 |
| ARTILLERY RE-ROLL WEIGHED | 77 | 77 | 77 | 2.14 | +0 | +0.0 |
| WAIT AFTER COSTS | 528 | 528 | 64 | 1.78 | +1303 | +20.4 |
| SAFER THAN THE JOB | 61 | 61 | 61 | 1.69 | +4558 | +74.7 |
| WALKS TO THE FIGHT | 97 | 97 | 60 | 1.67 | +896 | +14.9 |
| BEST OVERALL | 57 | 57 | 57 | 1.58 | +4737 | +83.1 |
| CANNON SIGHT KEPT | 57 | 57 | 57 | 1.58 | +0 | +0.0 |
| SET UP TOGETHER | 105 | 92 | 50 | 1.39 | +4025 | +80.5 |
| REDIRECT COUNTER | 193 | 108 | 49 | 1.36 | +3726 | +76.0 |
| MAX FOR POSITIONING | 321 | 198 | 47 | 1.31 | +656 | +14.0 |
| CANNON PLANNED TARGET | 194 | 194 | 45 | 1.25 | +154 | +3.4 |
| BEST FACING | 43 | 43 | 43 | 1.19 | +2035 | +47.3 |
| HOLDS AMBUSHERS | 39 | 39 | 39 | 1.08 | +0 | +0.0 |
| MISSILES IN THE MOVE | 290 | 175 | 38 | 1.06 | +1016 | +26.7 |
| RESERVE FALL BACK | 38 | 38 | 38 | 1.06 | +904 | +23.8 |
| ADVANCE LANE KEPT | 37 | 37 | 37 | 1.03 | +0 | +0.0 |
| BLOCKED WHEEL | 37 | 37 | 37 | 1.03 | +840 | +22.7 |
| RANDOM MOVE BY FIGURES | 88 | 88 | 37 | 1.03 | +941 | +25.4 |
| INVITES THE FIGHT | 96 | 96 | 36 | 1.00 | +504 | +14.0 |
| CHARGE NOW WEIGHED | 35 | 35 | 35 | 0.97 | +2519 | +72.0 |
| CHARGE NOW FIRST | 181 | 181 | 34 | 0.94 | -1976 | -58.1 |
| STOPS SHORT OF THE FLANK | 34 | 34 | 34 | 0.94 | +2072 | +60.9 |
| COMBAT PIVOT | 33 | 33 | 33 | 0.92 | +0 | +0.0 |
| LONE WIZARD KEPT IN | 33 | 33 | 33 | 0.92 | +2259 | +68.5 |
| CAST JOB | 71 | 71 | 30 | 0.83 | +756 | +25.2 |
| MOVE AND CAST | 29 | 29 | 29 | 0.81 | +1737 | +59.9 |
| SHOT REPLANNED | 28 | 28 | 28 | 0.78 | +0 | +0.0 |
| RISK BY ARC | 162 | 154 | 27 | 0.75 | +1026 | +38.0 |
| KILLS COUNT | 131 | 129 | 26 | 0.72 | +1151 | +44.3 |
| MAKE SURE TOGETHER | 62 | 46 | 26 | 0.72 | +2546 | +97.9 |
| MARCH CHECK | 39 | 36 | 26 | 0.72 | +2088 | +80.3 |
| SCOUT WAITS | 25 | 25 | 25 | 0.69 | +0 | +0.0 |
| REDIRECT WEIGHED | 22 | 22 | 22 | 0.61 | +288 | +13.1 |
| STAY WORTH | 369 | 299 | 22 | 0.61 | +232 | +10.5 |
| MANOEUVRE | 22 | 22 | 21 | 0.58 | +932 | +44.4 |
| SHOOTS FROM THE BEST SPOT | 43 | 43 | 20 | 0.56 | +448 | +22.4 |
| BEST MOVE FOR SHOOTERS | 19 | 19 | 19 | 0.53 | +2243 | +118.0 |
| KEEPS ITS TARGET | 129 | 126 | 19 | 0.53 | +275 | +14.5 |
| BIG CHARACTER SAFETY | 18 | 18 | 18 | 0.50 | +0 | +0.0 |
| SHOOTERS IN TWO RANKS | 18 | 18 | 18 | 0.50 | +36 | +2.0 |
| MARCH ODDS | 17 | 17 | 17 | 0.47 | +122 | +7.2 |
| THROUGH LINE OF FIRE | 17 | 17 | 17 | 0.47 | +965 | +56.8 |
| WHO HITS BACK | 17 | 17 | 17 | 0.47 | +1941 | +114.2 |
| FIRE IN ORDER | 16 | 16 | 16 | 0.44 | +0 | +0.0 |
| STUCK PIVOT | 16 | 16 | 16 | 0.44 | +0 | +0.0 |
| KEEPS THE TARGET | 31 | 31 | 14 | 0.39 | -1804 | -128.9 |
| BEST PREY | 59 | 59 | 13 | 0.36 | +1314 | +101.0 |
| FRIENDS SHOTS CHECKED | 12 | 12 | 12 | 0.33 | +983 | +81.9 |
| SHOOTERS TO THE PRIMARY | 142 | 96 | 11 | 0.31 | +482 | +43.8 |
| WAR ENGINE JOBS | 25 | 25 | 11 | 0.31 | -406 | -36.9 |
| WEARS DOWN | 74 | 69 | 11 | 0.31 | +674 | +61.3 |
| LOST CHARGE | 200 | 199 | 10 | 0.28 | +189 | +18.9 |
| CASTER AWAY FROM SCREEN | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| CASTS FROM BEHIND | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| HUNT IN PAIRS | 33 | 19 | 9 | 0.25 | +878 | +97.5 |
| MISSILES NEXT TURN | 355 | 217 | 9 | 0.25 | +39 | +4.3 |
| PIVOT GUARDS FLANK | 9 | 9 | 9 | 0.25 | -369 | -41.0 |
| SURE CHARGE BEATS ADVANCE | 9 | 9 | 9 | 0.25 | -372 | -41.4 |
| OPENS UP | 19 | 18 | 8 | 0.22 | +782 | +97.8 |
| MOVES UNITS SPELL | 7 | 7 | 7 | 0.19 | +141 | +20.1 |
| WHOLE FIGHT | 32 | 31 | 7 | 0.19 | +219 | +31.3 |
| WHOLE FIGHT GAIN | 19 | 16 | 7 | 0.19 | +351 | +50.1 |
| BEST PRIZE | 6 | 6 | 6 | 0.17 | -286 | -47.7 |
| BLOCKED CHARGE SKIPPED | 6 | 6 | 6 | 0.17 | +0 | +0.0 |
| KEEP FALLS | 6 | 6 | 6 | 0.17 | +318 | +53.0 |
| MISSILES IN THE FIRE PLAN | 94 | 18 | 6 | 0.17 | +321 | +53.4 |
| NEEDED THERE | 6 | 6 | 6 | 0.17 | +0 | +0.0 |
| RESTRAINS TO SHOOT | 6 | 6 | 6 | 0.17 | +508 | +84.6 |
| SUPPORT NARROWED | 402 | 402 | 6 | 0.17 | -57 | -9.5 |
| SHORT GUN FORWARD | 5 | 5 | 5 | 0.14 | +0 | +0.0 |
| BACKUP TARGETS | 54 | 29 | 4 | 0.11 | +23 | +5.8 |
| CARRIES OUT SET-UP | 9 | 9 | 4 | 0.11 | -315 | -78.7 |
| CASTING BLOCK | 9 | 9 | 4 | 0.11 | +292 | +73.0 |
| CHAFF PASSED | 4 | 4 | 4 | 0.11 | -4 | -0.9 |
| LONE WIZARD HOLDS BACK | 14 | 14 | 4 | 0.11 | -422 | -105.6 |
| SHOOTERS ARE THREATS | 113 | 113 | 4 | 0.11 | +0 | +0.0 |
| SURE REACH TOGETHER | 34 | 27 | 4 | 0.11 | +68 | +17.0 |
| MODEL FACING | 3 | 3 | 3 | 0.08 | +1125 | +374.9 |
| RAIDS THE BAGGAGE NEXT TURN | 3 | 3 | 3 | 0.08 | +22 | +7.4 |
| CHARIOT NO STATIC JOB | 2 | 2 | 2 | 0.06 | -92 | -46.1 |
| FACE THE CAST | 2 | 2 | 2 | 0.06 | +13 | +6.5 |
| HORN WORTH | 2 | 2 | 2 | 0.06 | +62 | +30.9 |
| NO RALLY LEFT | 2 | 2 | 2 | 0.06 | +33 | +16.5 |
| OVERRUNS AWAY | 27 | 25 | 2 | 0.06 | +68 | +34.1 |
| RAIDS THE BAGGAGE | 3 | 3 | 2 | 0.06 | +274 | +137.1 |
| SCREEN BY WHAT IT SAVES | 9 | 9 | 2 | 0.06 | +5 | +2.5 |
| THREAT AT FULL SIZE | 197 | 197 | 2 | 0.06 | +0 | +0.0 |
| BOMBING RUN | 1 | 1 | 1 | 0.03 | +9 | +9.2 |
| BOUND ASSAILMENT | 1 | 1 | 1 | 0.03 | +0 | +0.1 |
| CARRIES OUT COUNTER | 1 | 1 | 1 | 0.03 | -133 | -133.2 |
| CATCH ODDS | 1 | 1 | 1 | 0.03 | -2 | -1.5 |
| DEFENSIVE ARMY | 8 | 8 | 1 | 0.03 | -123 | -123.4 |
| DEFENSIVE FLOOR | 2 | 2 | 1 | 0.03 | +50 | +49.8 |
| EDGE GIVE GROUND | 17 | 15 | 1 | 0.03 | +43 | +42.7 |
| ELIXIR WORTH | 1 | 1 | 1 | 0.03 | +2 | +2.3 |
| FIRE AND FLEE | 1 | 1 | 1 | 0.03 | +15 | +15.1 |
| HUNT ADVANCE | 19 | 19 | 1 | 0.03 | +66 | +66.2 |
| KEEPS SCOUTS OR AMBUSH | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| LONG SHOT | 14 | 13 | 1 | 0.03 | +14 | +14.0 |
| MOVE SPELL IN RANGE | 8 | 7 | 1 | 0.03 | +7 | +7.1 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.03 | +54 | +54.4 |
| PURSUES BIG PREY | 1 | 1 | 1 | 0.03 | -52 | -52.3 |
| REDIRECT BY WHAT IT STOPS | 22 | 22 | 1 | 0.03 | +147 | +147.3 |
| SAFE SURE CHARGE | 1 | 1 | 1 | 0.03 | -40 | -40.2 |
| STANDS TO CAST | 1 | 1 | 1 | 0.03 | -23 | -23.1 |
| STAY WEIGHED | 1 | 1 | 1 | 0.03 | +67 | +66.6 |
| STOPS | 9 | 9 | 1 | 0.03 | +24 | +24.3 |
| TWO OR MORE ARRIVE | 36 | 29 | 1 | 0.03 | +24 | +23.5 |
| WAR ENGINE CHARGES | 5 | 5 | 1 | 0.03 | +162 | +162.1 |
| WIZARD FRONT RANK | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| ARRIVAL HUNT | 2 | 2 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 36 | 36 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 39 | trace | - | - | - | - |
| CHAMPION TAKES THE CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| CHARIOT WIZARD CAREFUL | 8 | 8 | 0 | 0.00 | - | - |
| CHEAP HELPER | 7 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 42 | not checked | - | - | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT LIFT | 4 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 384 | not checked | - | - | - | - |
| GIVES UP | 9 | 8 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 2 | 2 | 0 | 0.00 | - | - |
| GROUND FLIERS | 1 | not checked | - | - | - | - |
| HELPER UNSEEN | 12 | 12 | 0 | 0.00 | - | - |
| HILL BY ITS CHANCE | 22 | 22 | 0 | 0.00 | - | - |
| HUNT DROPPED | 6 | trace | - | - | - | - |
| HUNT KEPT | 15 | trace | - | - | - | - |
| HUNT RESULT | 14 | trace | - | - | - | - |
| HUNT THE GUNS | 16 | trace | - | - | - | - |
| JOINT CHARGE PLAN | 11 | 11 | 0 | 0.00 | - | - |
| KEEPS ITS PREY | 1 | 1 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 23 | not checked | - | - | - | - |
| LURE BY WHAT IT DRAWS | 1 | 1 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 5 | trace | - | - | - | - |
| MARCH OVER CASTS | 35 | 35 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 13 | 13 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 15 | trace | - | - | - | - |
| MOVE SPELL SPOT | 27 | not checked | - | - | - | - |
| NOT NEEDED | 17 | 17 | 0 | 0.00 | - | - |
| NOT TURNED | 383 | 383 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 46 | not checked | - | - | - | - |
| OPENS A LANE | 3 | 3 | 0 | 0.00 | - | - |
| PLAN RESULT | 2596 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 24 | 24 | 0 | 0.00 | - | - |
| SCOUT SPOT | 24 | 24 | 0 | 0.00 | - | - |
| SECOND HUNTER | 3 | 3 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 18 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 24 | not checked | - | - | - | - |
| SET-UP MISSED | 1 | trace | - | - | - | - |
| SHOT OPTIONS | 891 | 891 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 27 | not checked | - | - | - | - |
| SPELL WORTH | 125 | not checked | - | - | - | - |
| STABLE ROLE | 665 | 664 | 0 | 0.00 | - | - |
| TURN WORTH | 40 | 38 | 0 | 0.00 | - | - |

### Off best figure: sp-h2h-opp-89601ea-p3

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 13.06 | 12.47 | 56.3 |
| FALLBACK | gate | 0.64 | 0.53 | 60.6 |
| CHARGE NOW FIRST | rule | 0.39 | 0.53 | 59.9 |
| TURN GATE | gate | 0.44 | 0.44 | 44.3 |
| LONE CHARACTER SAFE SPOT | gate | 0.19 | 0.14 | 70.9 |
| WAR ENGINE JOBS | rule | 0.25 | 0.06 | 36.9 |
| KEEPS THE TARGET | rule | - | 0.28 | 193.8 |
| PIVOT GUARDS FLANK | rule | 0.08 | 0.17 | 41.0 |
| SURE CHARGE BEATS ADVANCE | rule | 0.17 | 0.08 | 41.4 |
| BIG CHARACTER SAFETY | rule | 0.06 | 0.11 | 9.6 |
| CANNON PLANNED TARGET | rule | 0.17 | - | 12.7 |
| CHARGE NOW WEIGHED | rule | 0.14 | 0.03 | 68.3 |
| FIRE PLAN | rule | - | 0.17 | 86.5 |
| AFTERMATH BAND | gate | 0.08 | 0.06 | 2.9 |
| SUPPORT NARROWED | rule | 0.08 | 0.06 | 11.3 |
| BEST PRIZE | rule | 0.06 | 0.06 | 71.5 |
| BLOCKED WHEEL | rule | 0.08 | 0.03 | 9.0 |
| CARRIES OUT SET-UP | rule | 0.08 | 0.03 | 78.7 |
| LONE WIZARD HOLDS BACK | rule | 0.06 | 0.06 | 105.6 |
| PATHS CROSS | rule | 0.06 | 0.06 | 42.1 |
| SUPPORT REQUEST | gate | 0.06 | 0.06 | 67.0 |
| MARCH ODDS | rule | 0.06 | 0.03 | 6.7 |
| NO REASON | gate | - | 0.08 | 10.9 |
| STOPS SHORT OF THE FLANK | rule | 0.03 | 0.06 | 10.0 |
| CHARIOT NO STATIC JOB | rule | 0.06 | - | 46.1 |
| FIGHT ORDER BAND | gate | 0.03 | 0.03 | 0.6 |
| REDIRECT WEIGHED | rule | - | 0.06 | 77.5 |
| RULE SWITCHED OFF | gate | 0.06 | - | 74.3 |
| SAFER THAN THE JOB | rule | - | 0.06 | 9.6 |
| THROUGH LINE OF FIRE | rule | 0.06 | - | 11.4 |
| CARRIES OUT COUNTER | rule | 0.03 | - | 133.2 |
| CATCH ODDS | rule | 0.03 | - | 1.5 |
| CHAFF PASSED | rule | 0.03 | - | 3.6 |
| DEFENSIVE ARMY | rule | 0.03 | - | 123.4 |
| FACES THE THREAT | rule | 0.03 | - | 8.5 |
| FALLBACK BY WORTH | rule | - | 0.03 | 323.2 |
| PURSUES BIG PREY | rule | - | 0.03 | 52.3 |
| SAFE SURE CHARGE | rule | - | 0.03 | 40.2 |
| STANDS TO CAST | rule | - | 0.03 | 23.1 |
| WHO HITS BACK | rule | - | 0.03 | 4.8 |

### Plans: sp-h2h-opp-89601ea-p3

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 12.3 | 19% | 440 | 415 | 94% |
| Mine | charge | 2.6 | 69% | 235 | 232 | 99% |
| Mine | close in | 4.4 | 24% | 343 | 121 | 35% |
| Mine | hold | 3.9 | 32% | 245 | 0 | 0% |
| Mine | join | 0.4 | 86% | 10 | 0 | 0% |
| Mine | shoot | 8.1 | 57% | 232 | 590 | 255% |
| Mine | support | 3.5 | 93% | 38 | 0 | 0% |
| Opponent | advance | 12.0 | 16% | 322 | 342 | 106% |
| Opponent | charge | 4.0 | 59% | 489 | 415 | 85% |
| Opponent | close in | 6.2 | 28% | 501 | 199 | 40% |
| Opponent | hold | 3.7 | 32% | 316 | 0 | 0% |
| Opponent | join | 1.0 | 97% | 34 | 0 | 0% |
| Opponent | shoot | 5.8 | 63% | 395 | 418 | 106% |
| Opponent | support | 4.1 | 87% | 44 | 0 | 0% |

### Packages: hunt the guns, sp-h2h-opp-89601ea-p3

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.2 | 8 | 1 | 0% | 29% | 0% | 3.0 | 476 | 154 | 29% | 41 |
| Opponent | 0.2 | 8 | 1 | 29% | 43% | 0% | 2.7 | 285 | 94 | 43% | 74 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 1.5 | 6 | 1 | 0% | 0% | 0% | - | 446 | 0 | 0% | 13 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 47 |
| Dwarfen Mountain Holds | 0.7 | 2 | 0 | 0% | 100% | 0% | 3.0 | 551 | 540 | 100% | 85 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 103 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 67 |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 31 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 33 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 138 |
| Tomb Kings of Khemri | 0.7 | 4 | 1 | 0% | 0% | 0% | - | 324 | 0 | 0% | 77 |
| Vampire Counts | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 9 |
| Warriors of Chaos | 0.1 | 1 | 0 | 100% | 100% | 0% | 2.0 | 252 | 223 | 100% | 106 |
| Wood Elf Realms | 0.5 | 3 | 0 | 33% | 67% | 0% | 3.0 | 257 | 144 | 67% | 24 |

### Battle groups: sp-h2h-opp-89601ea-p3

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 8.9 | 24% | 46% | 11% | 25% | 34% | 6% | 10% | 50% | 0% |
| Mine | REDIRECT COUNTER | 1.9 | 34% | 83% | 13% | 67% | 35% | 0% | 20% | 40% | 5% |
| Opponent | COUNTER-CHARGE COVER | 6.7 | 18% | 68% | 7% | 0% | 24% | 12% | 7% | 56% | 0% |
| Opponent | REDIRECT COUNTER | 3.5 | 20% | 76% | 28% | 71% | 11% | 0% | 17% | 72% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: sp-h2h-opp-89601ea-p3

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 0% | 6.0 | - | 0 (1) | - | - | 0 (1) |
| Mine | Chaff | 32 | 54 (32) | 20 | 34 | 65 | 41% | 2.4 | 68 (19) | 0 (4) | 41 (9) | 68 (24) | 13 (8) |
| Mine | Character | 117 | 48 (117) | 48 | 0 | 39 | 22% | 2.3 | 58 (37) | 49 (53) | 55 (9) | 52 (58) | 56 (41) |
| Mine | Clean-up | 20 | 29 (20) | 6 | 23 | 32 | 35% | 3.2 | 48 (5) | 22 (13) | 0 (2) | 38 (13) | 17 (7) |
| Mine | Fast | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Mine | Fast Hammer | 44 | 34 (44) | 21 | 13 | 42 | 18% | 3.1 | 33 (20) | 42 (18) | 18 (6) | 34 (31) | 35 (13) |
| Mine | Fragile | 3 | 0 (3) | 0 | 0 | 33 | 67% | 2.0 | 0 (3) | - | - | 0 (1) | 0 (2) |
| Mine | Hammer | 48 | 43 (48) | 27 | 15 | 44 | 12% | 2.5 | 5 (11) | 54 (33) | 53 (4) | 42 (33) | 43 (15) |
| Mine | Holder | 22 | 64 (22) | 20 | 44 | 33 | 27% | 3.6 | 59 (6) | 57 (10) | 106 (5) | 102 (11) | 28 (10) |
| Mine | Shooter | 37 | 53 (37) | 29 | 24 | 60 | 11% | 1.8 | 39 (6) | 61 (28) | 0 (3) | 54 (22) | 50 (15) |
| Mine | Support | 4 | 80 (4) | 80 | 0 | 19 | 25% | 2.0 | - | 80 (4) | - | 66 (3) | 139 (1) |
| Mine | War machine | 52 | 40 (52) | 40 | 0 | 54 | 6% | 1.1 | 22 (13) | 50 (35) | 0 (4) | 26 (13) | 45 (39) |
| Mine | Wizard | 16 | 4 (16) | 4 | 0 | 30 | 19% | 2.1 | 14 (4) | 0 (7) | 0 (2) | 0 (8) | 12 (5) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 0% | 6.0 | - | 0 (1) | - | - | 0 (1) |
| Opponent | Chaff | 68 | 58 (68) | 28 | 31 | 53 | 44% | 2.8 | 84 (29) | 73 (11) | 30 (28) | 78 (48) | 12 (20) |
| Opponent | Character | 98 | 60 (98) | 60 | 0 | 31 | 21% | 2.1 | 63 (33) | 67 (51) | 26 (5) | 53 (48) | 75 (41) |
| Opponent | Clean-up | 10 | 53 (10) | 19 | 34 | 40 | 40% | 2.8 | 31 (4) | 51 (5) | 167 (1) | 57 (6) | 50 (4) |
| Opponent | Fast | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Fast Hammer | 57 | 36 (57) | 18 | 18 | 44 | 30% | 2.7 | 31 (27) | 38 (20) | 47 (10) | 43 (26) | 30 (31) |
| Opponent | Fragile | 3 | 0 (3) | 0 | 0 | 67 | 33% | 2.0 | - | 0 (2) | 0 (1) | 0 (2) | 0 (1) |
| Opponent | Hammer | 47 | 34 (47) | 23 | 11 | 36 | 36% | 3.2 | 9 (16) | 46 (28) | 0 (3) | 42 (29) | 21 (18) |
| Opponent | Holder | 41 | 87 (41) | 11 | 76 | 39 | 34% | 2.7 | 35 (9) | 114 (22) | 73 (10) | 103 (29) | 53 (12) |
| Opponent | Shooter | 28 | 59 (28) | 30 | 29 | 50 | 4% | 1.0 | 66 (7) | 46 (19) | 221 (2) | 74 (16) | 40 (12) |
| Opponent | Support | 4 | 0 (4) | 0 | 0 | 17 | 75% | 6.0 | 0 (2) | 0 (1) | 0 (1) | 0 (1) | 0 (3) |
| Opponent | War machine | 15 | 75 (15) | 75 | 0 | 41 | 7% | 1.4 | 60 (2) | 67 (9) | 98 (4) | 0 (1) | 82 (14) |
| Opponent | Wizard | 33 | 27 (33) | 27 | 0 | 37 | 24% | 1.8 | 5 (13) | 79 (8) | 0 (2) | 7 (12) | 53 (11) |

### Charged fights: sp-h2h-opp-89601ea-p3

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 34 | 92 | 1.2 | 1.2 | 74 | 0 | +74 | 1 of 5 | 4 of 5 | +40 | +82 |
| Mine | Chaos Dwarfs | 3 | 204 | 109 | 2.3 | 1.1 | 47 | 44 | +2 | 4 of 7 | 5 of 7 | +0 | +3 |
| Mine | Dwarfen Mountain Holds | 3 | 371 | 272 | 1.0 | 1.0 | 272 | 82 | +190 | 2 of 3 | 1 of 3 | - | +190 |
| Mine | Empire of Man | 5 | 394 | 95 | 0.8 | 1.0 | 119 | 0 | +119 | 0 of 4 | 4 of 4 | - | +119 |
| Mine | Grand Cathay | 5 | 441 | 501 | 4.0 | 1.1 | 125 | 28 | +97 | 4 of 20 | 15 of 20 | -190 | +129 |
| Mine | High Elf Realms | 4 | 41 | 475 | 3.5 | 1.1 | 136 | 0 | +136 | 2 of 14 | 11 of 14 | +125 | +136 |
| Mine | Kingdom of Bretonnia | 1 | 0 | 398 | 3.0 | 1.0 | 133 | 0 | +133 | 1 of 3 | 2 of 3 | - | +133 |
| Mine | Lizardmen | 1 | 0 | 1227 | 4.0 | 1.2 | 307 | 21 | +286 | 1 of 4 | 4 of 4 | +144 | +333 |
| Mine | Ogre Kingdoms | 1 | 0 | 170 | 3.0 | 1.3 | 57 | 0 | +57 | 0 of 3 | 3 of 3 | +0 | +85 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 272 | 4.0 | 1.0 | 68 | 0 | +68 | 0 of 4 | 3 of 4 | - | +68 |
| Mine | Skaven | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Mine | Tomb Kings of Khemri | 2 | 0 | 353 | 6.0 | 1.1 | 59 | 0 | +59 | 3 of 12 | 7 of 12 | +75 | +57 |
| Mine | Vampire Counts | 2 | 176 | 176 | 4.0 | 1.0 | 44 | 8 | +36 | 2 of 8 | 5 of 8 | - | +36 |
| Mine | Warriors of Chaos | 2 | 0 | 110 | 1.5 | 1.3 | 73 | 125 | -52 | 0 of 3 | 1 of 3 | +74 | -115 |
| **Mine** | all armies | 35 | 187 | 278 | 2.6 | 1.1 | 108 | 18 | +90 | 20 of 90 | 65 of 90 | +9 | +99 |
| Opponent | Empire of Man | 1 | 618 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Grand Cathay | 3 | 359 | 313 | 2.3 | 1.0 | 134 | 0 | +134 | 2 of 7 | 6 of 7 | - | +134 |
| Opponent | High Elf Realms | 2 | 394 | 388 | 2.0 | 1.2 | 194 | 87 | +107 | 4 of 4 | 3 of 4 | +506 | -26 |
| Opponent | Kingdom of Bretonnia | 2 | 312 | 616 | 3.5 | 1.0 | 176 | 0 | +176 | 3 of 7 | 6 of 7 | - | +176 |
| Opponent | Orc & Goblin Tribes | 1 | 0 | 561 | 5.0 | 1.0 | 112 | 0 | +112 | 1 of 5 | 5 of 5 | - | +112 |
| Opponent | Skaven | 1 | 60 | 115 | 1.0 | 2.0 | 115 | 0 | +115 | 1 of 1 | 1 of 1 | +115 | - |
| Opponent | Tomb Kings of Khemri | 4 | 236 | 698 | 3.5 | 1.1 | 199 | 5 | +194 | 9 of 14 | 13 of 14 | +259 | +189 |
| Opponent | Vampire Counts | 6 | 33 | 764 | 6.0 | 1.2 | 127 | 30 | +97 | 19 of 36 | 19 of 36 | +65 | +101 |
| Opponent | Warriors of Chaos | 9 | 4 | 548 | 4.1 | 1.1 | 133 | 33 | +100 | 18 of 37 | 26 of 37 | +196 | +88 |
| Opponent | Wood Elf Realms | 6 | 112 | 22 | 2.0 | 1.0 | 11 | 132 | -121 | 5 of 12 | 6 of 12 | - | -121 |
| **Opponent** | all armies | 35 | 143 | 459 | 3.5 | 1.1 | 131 | 35 | +95 | 62 of 123 | 85 of 123 | +175 | +88 |

### Effective charges: sp-h2h-opp-89601ea-p3

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 5 | 1 (net +0) | 0 | 1 (net +165) | 0 | 0 | 1 (net +40) | 2 | 33% (1 of 3) |
| Mine | Chaos Dwarfs | 7 | 0 | 0 | 0 | 4 (net -47) | 0 | 3 (net +68) | 0 | 0% (0 of 7) |
| Mine | Dwarfen Mountain Holds | 3 | 0 | 0 | 0 | 2 (net +147) | 0 | 1 (net +277) | 0 | 0% (0 of 3) |
| Mine | Empire of Man | 4 | 0 | 0 | 1 (net +104) | 0 | 0 | 3 (net +124) | 0 | 25% (1 of 4) |
| Mine | Grand Cathay | 20 | 2 (net +45) | 0 | 4 (net +103) | 1 (net +0) | 4 (net -63) | 6 (net +210) | 3 | 24% (4 of 17) |
| Mine | High Elf Realms | 14 | 0 | 0 | 1 (net +72) | 3 (net +328) | 4 (net +60) | 4 (net +92) | 2 | 8% (1 of 12) |
| Mine | Kingdom of Bretonnia | 3 | 1 (net +190) | 0 | 0 | 1 (net +208) | 0 | 1 (net +0) | 0 | 0% (0 of 3) |
| Mine | Lizardmen | 4 | 0 | 0 | 1 (net +913) | 0 | 1 (net +0) | 2 (net +116) | 0 | 25% (1 of 4) |
| Mine | Ogre Kingdoms | 3 | 0 | 0 | 0 | 0 | 0 | 3 (net +57) | 0 | 0% (0 of 3) |
| Mine | Orc & Goblin Tribes | 4 | 0 | 0 | 0 | 0 | 0 | 2 (net +136) | 2 | 0% (0 of 2) |
| Mine | Tomb Kings of Khemri | 12 | 2 (net +0) | 0 | 0 | 5 (net +76) | 3 (net +83) | 2 (net +38) | 0 | 0% (0 of 12) |
| Mine | Vampire Counts | 8 | 1 (net +38) | 0 | 4 (net +63) | 0 | 2 (net +0) | 0 | 1 | 57% (4 of 7) |
| Mine | Warriors of Chaos | 3 | 0 | 1 (net +30) | 0 | 1 (net +74) | 0 | 0 | 1 | 0% (0 of 2) |
| Opponent | Grand Cathay | 7 | 1 (net +0) | 0 | 1 (net +230) | 2 (net +316) | 2 (net +38) | 0 | 1 | 17% (1 of 6) |
| Opponent | High Elf Realms | 4 | 1 (net +0) | 0 | 1 (net -347) | 1 (net +270) | 0 | 1 (net +506) | 0 | 25% (1 of 4) |
| Opponent | Kingdom of Bretonnia | 7 | 2 (net +286) | 1 (net +117) | 0 | 1 (net +0) | 0 | 2 (net +272) | 1 | 0% (0 of 6) |
| Opponent | Orc & Goblin Tribes | 5 | 0 | 0 | 1 (net +0) | 1 (net +199) | 0 | 0 | 3 | 50% (1 of 2) |
| Opponent | Skaven | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +115) | 0 | 0% (0 of 1) |
| Opponent | Tomb Kings of Khemri | 14 | 1 (net +0) | 1 (net +511) | 1 (net +217) | 1 (net +122) | 3 (net +86) | 6 (net +207) | 1 | 8% (1 of 13) |
| Opponent | Vampire Counts | 36 | 11 (net +164) | 2 (net +246) | 5 (net +12) | 7 (net +33) | 6 (net +33) | 3 (net +211) | 2 | 15% (5 of 34) |
| Opponent | Warriors of Chaos | 37 | 8 (net +97) | 3 (net -79) | 3 (net +131) | 3 (net +119) | 2 (net +88) | 13 (net +163) | 5 | 9% (3 of 32) |
| Opponent | Wood Elf Realms | 12 | 1 (net -104) | 0 | 2 (net -70) | 2 (net -52) | 1 (net +0) | 0 | 6 | 33% (2 of 6) |

### Charged fights, damage counted: sp-h2h-opp-89601ea-p3

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 7 | 183 | 216 | +45 | 58 | 48 | +10 | +5.4 |
| Mine | 50-54% | 1 | 41 | 30 | +30 | 30 | 7 | +23 | +56.5 |
| Mine | Effective (55-75%) | 12 | 252 | 187 | +160 | 213 | 31 | +182 | +72.3 |
| Mine | 76-89% | 17 | 326 | 233 | +103 | 155 | 51 | +104 | +31.9 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 28 | 232 | 164 | +117 | 147 | 20 | +127 | +54.6 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 14 | 426 | 84 | +17 | 58 | 48 | +10 | +2.3 |
| Mine | No odds | 11 | 373 | 185 | +51 | 81 | 48 | +33 | +8.8 |
| Mine | All fights | 90 | 294 | 173 | +90 | 127 | 37 | +90 | +30.6 |
| Opponent | Long shot (under 50%) | 25 | 215 | 263 | +122 | 140 | 33 | +107 | +49.6 |
| Opponent | 50-54% | 7 | 373 | 400 | +126 | 240 | 162 | +78 | +20.9 |
| Opponent | Effective (55-75%) | 14 | 226 | 237 | +30 | 116 | 82 | +34 | +15.2 |
| Opponent | 76-89% | 18 | 235 | 242 | +95 | 105 | 12 | +93 | +39.4 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 26 | 388 | 238 | +198 | 262 | 40 | +222 | +57.3 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 14 | 505 | 86 | +51 | 87 | 41 | +46 | +9.0 |
| Opponent | No odds | 19 | 186 | 200 | -10 | 99 | 91 | +8 | +4.5 |
| Opponent | All fights | 123 | 293 | 230 | +95 | 151 | 54 | +97 | +33.1 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| sp-h2h-opp-89601ea-p3 | move | 432 | 96 (22%) | 74 (17%) | 59 (14%) | 277 (64%) |
| sp-h2h-opp-89601ea-p3 | objective | 386 | 68 (18%) | 51 (13%) | 60 (16%) | 258 (67%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0110, L0126, L2433, L2630 |
| Charmed Shield | Opponent | L0126, L0226, L0327, L0725, L1327, L2327 |
| Clockwork Compass | Mine | L1216, L1232 |
| Elixir of Power | Mine | L1122, L1932 |
| Elixir of Power | Opponent | L0311, L1519 |
| Fistful of Laurels | Mine | L1831 |
| Horn of the Wild Hunt | Opponent | L0533, L1633, L2033, L2433, L3133 |
| Invocation of Nehek | Mine | L2433 |
| Invocation of Nehek | Opponent | L0327, L0725, L1327, L2327 |
| Opal Amulet | Mine | L1422 |
| Periapt of Soul Exchange | Mine | L2033 |
| Periapt of Soul Exchange | Opponent | L0620 |
| Ring of Doom | Mine | L0210, L0226, L1122, L1216, L1232, L1519, L1535, L3133 |
| Ring of Doom | Opponent | L0311, L0533, L0815, L0831, L1633, L1731, L1831, L2033, L2433, L3133 |
| Ring of Jet | Mine | L1013, L1030, L1122, L1216, L1232 |
| Ring of Jet | Opponent | L0110, L0210, L0311 |
| Standard of the Fell Warrior | Mine | L1327 |
| Standard of the Fell Warrior | Opponent | L0413, L1013 |
| Twice-Blessed Armour | Mine | L0709, L0725, L1013, L1030 |
| Twice-Blessed Armour | Opponent | L0110, L0210 |
| Witch Hunter's Ward | Mine | L0709, L0725, L0815, L0831 |

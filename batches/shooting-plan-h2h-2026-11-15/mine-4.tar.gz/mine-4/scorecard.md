# Doctrine scorecard: sp-h2h-mine-89601ea-p4

### Scorecard: sp-h2h-mine-89601ea-p4

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0114 | 6 | 1 | Mine | no | 4 | - | 0 | 2 | 0 | 0 | 0 | 95 |
| L0114 | 6 | 1 | Opponent | no | 3 | 2 | 5 | 1 | 0 | 0 | 0 | 0 |
| L0130 | 4 | 1 | Mine | yes | 8 | 4 | 1 | 0 | 0 | 0 | 0 | 0 |
| L0130 | 4 | 1 | Opponent | no | 2 | 1 | 5 | 2 | 0 | 0 | 0 | 0 |
| L0214 | 4 | 1 | Mine | no | 2 | 3 | 6 | 1 | 0 | 0 | 0 | 170 |
| L0214 | 4 | 1 | Opponent | no | 4 | 2 | 2 | 0 | 0 | 0 | 0 | 0 |
| L0230 | 2 | 1 | Mine | - | - | 3 | 3 | 4 | 0 | 0 | 0 | 255 |
| L0230 | 2 | 1 | Opponent | - | - | 2 | 3 | 3 | 0 | 0 | 0 | 0 |
| L0315 | 3 | 1 | Mine | no | 0 | 6 | 1 | 1 | 0 | 0 | 0 | 675 |
| L0315 | 3 | 1 | Opponent | yes | 7 | 2 | 2 | 0 | 0 | 0 | 0 | 0 |
| L0332 | 2 | 1 | Mine | - | - | 4 | 2 | 1 | 0 | 0 | 0 | 675 |
| L0332 | 2 | 1 | Opponent | - | - | 2 | 4 | 4 | 0 | 0 | 0 | 0 |
| L0417 | 3 | 1 | Mine | yes | 1 | 2 | 7 | 1 | 0 | 0 | 0 | 0 |
| L0417 | 3 | 1 | Opponent | yes | 2 | 2 | 5 | 0 | 1 | 0 | 0 | 0 |
| L0434 | 2 | 1 | Mine | - | - | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L0434 | 2 | 1 | Opponent | - | - | 1 | 2 | 2 | 1 | 0 | 0 | 0 |
| L0520 | 4 | 1 | Mine | no | 0 | 5 | 1 | 0 | 0 | 0 | 0 | 1416 |
| L0520 | 4 | 1 | Opponent | no | 0 | 4 | 3 | 4 | 0 | 0 | 0 | 0 |
| L0608 | 2 | 1 | Mine | - | - | - | 2 | 4 | 1 | 0 | 0 | 1197 |
| L0608 | 2 | 1 | Opponent | - | - | 4 | 2 | 2 | 0 | 0 | 0 | 1012 |
| L0624 | 6 | 1 | Mine | no | 1 | 2 | 2 | 1 | 0 | 0 | 0 | 801 |
| L0624 | 6 | 1 | Opponent | no | 7 | 4 | 2 | 1 | 0 | 0 | 0 | 0 |
| L0713 | 5 | 1 | Mine | no | - | 3 | 2 | 1 | 1 | 0 | 0 | 375 |
| L0713 | 5 | 1 | Opponent | no | - | 2 | 4 | 1 | 1 | 0 | 0 | 140 |
| L0729 | 3 | 1 | Mine | no | 3 | 2 | 0 | 1 | 0 | 0 | 0 | 375 |
| L0729 | 3 | 1 | Opponent | no | 3 | 2 | 9 | 1 | 0 | 0 | 0 | 170 |
| L0819 | 3 | 1 | Mine | no | 0 | 3 | 1 | 1 | 0 | 0 | 0 | 798 |
| L0819 | 3 | 1 | Opponent | no | 0 | 2 | 0 | 3 | 1 | 0 | 0 | 0 |
| L0835 | 1 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 515 |
| L0835 | 1 | 1 | Opponent | no | 0 | 2 | 0 | 4 | 0 | 0 | 0 | 0 |
| L0926 | 2 | 1 | Mine | - | - | 2 | 2 | 0 | 0 | 0 | 0 | 821 |
| L0926 | 2 | 1 | Opponent | - | - | 2 | 5 | 3 | 0 | 0 | 0 | 0 |
| L1017 | 3 | 1 | Mine | no | 2 | 2 | 5 | 0 | 0 | 0 | 0 | 330 |
| L1017 | 3 | 1 | Opponent | no | 1 | 2 | 5 | 0 | 3 | 0 | 0 | 175 |
| L1034 | 2 | 1 | Mine | - | - | 1 | 2 | 1 | 0 | 0 | 0 | 330 |
| L1034 | 2 | 1 | Opponent | - | - | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| L1126 | 4 | 1 | Mine | no | 2 | 3 | 2 | 0 | 1 | 0 | 0 | 330 |
| L1126 | 4 | 1 | Opponent | no | 1 | 2 | 4 | 3 | 1 | 0 | 0 | 40 |
| L1220 | 2 | 1 | Mine | - | - | 3 | 2 | 0 | 0 | 0 | 0 | 330 |
| L1220 | 2 | 1 | Opponent | - | - | - | 3 | 6 | 0 | 0 | 0 | 197 |
| L1314 | 6 | 1 | Mine | no | 3 | 2 | 0 | 0 | 0 | 0 | 0 | 140 |
| L1314 | 6 | 1 | Opponent | no | 1 | 2 | 7 | 1 | 1 | 0 | 0 | 143 |
| L1331 | 5 | 1 | Mine | yes | - | 3 | 4 | 3 | 0 | 0 | 0 | 140 |
| L1331 | 5 | 1 | Opponent | yes | - | - | 0 | 3 | 3 | 0 | 0 | 170 |
| L1427 | 5 | 1 | Mine | no | - | 2 | 1 | 2 | 0 | 0 | 0 | 177 |
| L1427 | 5 | 1 | Opponent | yes | - | 2 | 4 | 4 | 0 | 0 | 0 | 0 |
| L1523 | 5 | 1 | Mine | yes | - | 2 | 7 | 0 | 1 | 0 | 0 | 0 |
| L1523 | 5 | 1 | Opponent | no | - | 2 | 3 | 1 | 0 | 0 | 0 | 126 |
| L1621 | 1 | 1 | Mine | no | 3 | 2 | 7 | 0 | 0 | 0 | 0 | 200 |
| L1621 | 1 | 1 | Opponent | no | 1 | - | 3 | 3 | 0 | 0 | 0 | 500 |
| L1719 | 3 | 1 | Mine | no | 3 | 2 | 5 | 0 | 0 | 0 | 0 | 0 |
| L1719 | 3 | 1 | Opponent | yes | 2 | 2 | 3 | 0 | 0 | 0 | 0 | 0 |
| L1819 | 1 | 1 | Mine | no | 0 | 2 | 6 | 1 | 0 | 0 | 0 | 0 |
| L1819 | 1 | 1 | Opponent | no | 0 | 2 | 3 | 0 | 1 | 0 | 0 | 0 |
| L1835 | 5 | 1 | Mine | yes | - | 5 | 1 | 0 | 1 | 0 | 0 | 0 |
| L1835 | 5 | 1 | Opponent | yes | - | 1 | 3 | 4 | 0 | 0 | 0 | 0 |
| L2021 | 5 | 1 | Mine | yes | - | 5 | 3 | 3 | 0 | 0 | 0 | 210 |
| L2021 | 5 | 1 | Opponent | no | - | - | 0 | 3 | 0 | 0 | 0 | 355 |
| L2123 | 5 | 1 | Mine | yes | - | - | 1 | 4 | 1 | 0 | 0 | 290 |
| L2123 | 5 | 1 | Opponent | yes | - | 2 | 4 | 0 | 0 | 0 | 0 | 0 |
| L2227 | 1 | 1 | Mine | yes | 7 | 2 | 3 | 0 | 0 | 0 | 0 | 0 |
| L2227 | 1 | 1 | Opponent | yes | 2 | 1 | 6 | 1 | 1 | 0 | 0 | 0 |
| L2331 | 3 | 1 | Mine | no | 0 | 3 | 4 | 1 | 1 | 0 | 0 | 0 |
| L2331 | 3 | 1 | Opponent | yes | 5 | 5 | 2 | 1 | 1 | 0 | 0 | 170 |
| L2527 | 1 | 1 | Mine | no | 0 | 6 | 2 | 3 | 0 | 0 | 0 | 0 |
| L2527 | 1 | 1 | Opponent | no | 0 | 1 | 1 | 4 | 0 | 0 | 0 | 0 |
| L2634 | 6 | 1 | Mine | no | 7 | 2 | 6 | 0 | 0 | 0 | 0 | 0 |
| L2634 | 6 | 1 | Opponent | no | 3 | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L2930 | 2 | 1 | Mine | - | - | 2 | 5 | 0 | 0 | 0 | 0 | 323 |
| L2930 | 2 | 1 | Opponent | - | - | 2 | 6 | 3 | 0 | 0 | 0 | 0 |
| L3234 | 6 | 1 | Mine | no | 0 | 2 | 4 | 3 | 0 | 0 | 0 | 170 |
| L3234 | 6 | 1 | Opponent | no | 0 | 2 | 4 | 2 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 29% | 2.2 | 2.9 | 2.9 | 1.1 | 0.2 | 0.0 | 0.0 | 309.4 |
| **Average** | | | Opponent | 32% | 2.1 | 2.1 | 3.3 | 2.0 | 0.4 | 0.0 | 0.0 | 88.8 |

### KPIs: sp-h2h-mine-89601ea-p4

Rules off - Opponent only: STAY WORTH, BEST MOVE FOR SHOOTERS, FACE THE CAST, WIZARD FRONT RANK, FIRE PLAN, FIRE IN ORDER, KEEPS THE TARGET, MISSILES IN THE FIRE PLAN, THREAT AT FULL SIZE, SHOOTERS ARE THREATS, SHOOTERS TO THE PRIMARY.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 23% (40 of 176) | 1% (2 of 178) | 12% (42 of 354) |
| Winner chose to follow up after the loser gave ground |  | 98% (87 of 89); on the table 98% | 95% (54 of 57); on the table 95% | 97% (141 of 146); on the table 97% |
| Winner chose to pursue after the loser fell back in good order |  | 89% (8 of 9); on the table 89% | 100% (10 of 10); on the table 100% | 95% (18 of 19); on the table 95% |
| Winner chose to pursue after the loser fled |  | 73% (22 of 30); on the table 77% | 81% (30 of 37); on the table 86% | 78% (52 of 67); on the table 82% |
| Winner chose to follow up or pursue (all three) |  | 91% (117 of 128); on the table 92% | 90% (94 of 104); on the table 92% | 91% (211 of 232); on the table 92% |
| Magic missiles tried each own turn | 50%+ | 29% (75 of 263) | 28% (48 of 174) | 28% (123 of 437) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 46% (75 of 162) | 38% (48 of 125) | 43% (123 of 287) |
|   fighting wizards (on a monster, chariot or monstrous mount) | 50%+ | 23% (30 of 133) | 26% (22 of 86) | 24% (52 of 219) |
|     round 1 |  | 14% (3 of 22) | 33% (5 of 15) | 22% (8 of 37) |
|     rounds 2+ |  | 24% (27 of 111) | 24% (17 of 71) | 24% (44 of 182) |
|   other wizards | 50%+ | 35% (45 of 130) | 22% (18 of 80) | 30% (63 of 210) |
|     round 1 |  | 13% (3 of 23) | 29% (4 of 14) | 19% (7 of 37) |
|     rounds 2+ |  | 39% (42 of 107) | 21% (14 of 66) | 32% (56 of 173) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 57% (20 of 35) | 59% (38 of 64) | 59% (58 of 99) |
| Points that never fought | lower | 36% (24218 of 67942) | 34% (24496 of 71984) | 35% (48714 of 139926) |
|   infantry points that never fought | lower | 42% (6448 of 15347) | 55% (7639 of 13804) | 48% (14087 of 29151) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 62% (168 of 270) | 57% (159 of 280) | 59% (327 of 550) |
| Bound items with a magic missile used (at least once a game) |  | 95% (21 of 22); 1.5 uses a game | 89% (8 of 9); 0.6 uses a game | 94% (29 of 31); 1.1 uses a game |
| Bound items with another spell used |  | 38% (6 of 16); 0.4 uses a game | 45% (9 of 20); 0.4 uses a game | 42% (15 of 36); 0.4 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 58% (11 of 19); 0.3 uses a game | 80% (12 of 15); 0.4 uses a game | 68% (23 of 34); 0.3 uses a game |
|   their share of the points of units over 100 pts | lower | 58% (33768 of 57750) | 47% (29679 of 63347) | 52% (63447 of 121097) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.3 (25%) | 1.0 (29%) | 2.3 (27%) |
| MARCHED: its unit marched | 1.0 (19%) | 0.4 (13%) | 1.4 (16%) |
| CHARGED: its unit charged | 0.0 (1%) | 0.1 (2%) | 0.1 (1%) |
| IN COMBAT: engaged in combat | 1.8 (34%) | 0.9 (27%) | 2.7 (31%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.6 (17%) | 0.6 (7%) |
| FLEEING: fleeing | 0.1 (1%) | 0.1 (2%) | 0.1 (1%) |
| GONE: slain | 1.0 (19%) | 0.4 (10%) | 1.3 (15%) |
| STUPIDITY: Stupidity | 0.1 (2%) | 0.0 (0%) | 0.1 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (1%) | 0.0 (0%) | 0.0 (0%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.3 | 1.4 | 1.9 | 3.4 | 0.4 | 2.9 |
| not cast | 2.9 | 2.6 | 2.9 | 8.7 | 1.6 | 20.1 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.9 (9%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.1 (45%) | 0.2 (8%) | 2.3 (27%) | 0.3 (18%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.4 (16%) | 0.3 (21%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.1 (5%) | 0.3 (12%) | 0.6 (22%) | 2.7 (31%) | 0.6 (40%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.2 (6%) | 0.2 (7%) | 0.4 (15%) | 0.6 (7%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.1 (3%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (2%) | 0.4 (2%) |
| GONE: slain | 0.6 (21%) | 0.5 (21%) | 0.3 (9%) | 1.3 (15%) | 0.1 (9%) | 2.6 (13%) |
| OFF THE TABLE: off the table or not arrived | 0.1 (4%) | 0.0 (0%) | 0.1 (3%) | 0.0 (0%) | 0.0 (0%) | 0.3 (1%) |
| STUPIDITY: Stupidity | 0.1 (4%) | 0.0 (0%) | 0.0 (1%) | 0.1 (1%) | 0.0 (0%) | 0.2 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.2 (10%) | 0.0 (0%) | 0.0 (0%) | 0.2 (11%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.6 (57%) | 0.2 (7%) | 1.2 (42%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 14.8 (73%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.5 a game | 0.5 a game | 1.0 a game |
| stood (cast and not dispelled) | 60% (28 of 47) | 56% (5 of 9) | 59% (33 of 56) |
| the unit moved after it | 75% (21 of 28) | 60% (3 of 5) | 73% (24 of 33) |
| it charged on its next turn | 0% (0 of 28) | 0% (0 of 5) | 0% (0 of 33) |
| the enemy charged it first | 29% (8 of 28) | 20% (1 of 5) | 27% (9 of 33) |
| it fought by the end of its next turn | 21% (6 of 28) | 0% (0 of 5) | 18% (6 of 33) |
| it moved out of a charge the enemy had planned (not charged first) | 25% (7 of 28) | 0% (0 of 5) | 21% (7 of 33) |
| none of these (no charge, no fight, no charge escaped) | 43% (12 of 28) | 80% (4 of 5) | 48% (16 of 33) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 64% (558 of 871) | 51% (284 of 558) | 59% (842 of 1429) |
|   cavalry | 71% (54 of 76) | 71% (82 of 116) | 71% (136 of 192) |
|   character | 34% (30 of 89) | 10% (14 of 139) | 19% (44 of 228) |
|   chariot | 44% (49 of 111) | 67% (14 of 21) | 48% (63 of 132) |
|   infantry | 65% (173 of 267) | 61% (137 of 226) | 63% (310 of 493) |
|   monster | 38% (18 of 47) | 35% (8 of 23) | 37% (26 of 70) |
|   war machine | 83% (234 of 281) | 88% (29 of 33) | 84% (263 of 314) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.6 (19%) | 1.6 (20%) | 3.2 (20%) |
| CHARGED: it charged | 1.3 (15%) | 2.1 (28%) | 3.4 (21%) |
| FLEEING: it fled or was fleeing | 0.1 (1%) | 0.1 (1%) | 0.1 (1%) |
| IN COMBAT: it fought this turn or the last | 1.0 (12%) | 0.9 (12%) | 1.9 (12%) |
| MOVED: a war machine that moved | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| NO TARGET IN RANGE | 1.9 (22%) | 1.1 (15%) | 3.0 (18%) |
| ONLY IN COMBAT: the only targets were in combat | 0.7 (8%) | 0.6 (8%) | 1.3 (8%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.4 (16%) | 1.2 (16%) | 2.6 (16%) |
| SHELTERED: the target was sheltered | 0.2 (3%) | 0.0 (0%) | 0.2 (2%) |
| OTHER BAR | 0.4 (5%) | 0.0 (0%) | 0.4 (3%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 6.2 | 1.7 | 81% | 5.7 pts | 35 pts |
| character | 1.6 | 0.4 | 81% | 4.6 pts | 7 pts |
| chariot | 1.8 | 1.1 | 62% | 13.7 pts | 24 pts |
| infantry | 13.1 | 5.3 | 71% | 9.3 pts | 122 pts |
| monster | 0.8 | 0.1 | 89% | 4.8 pts | 4 pts |
| war machine | 7.3 | 4.6 | 64% | 17.2 pts | 126 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.8 | 6.6 | 5.7 |
| Charges that made contact a game | 3.4 | 4.4 | 3.9 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.73 declared, 0.73 contact (15 units) | 0.65 declared, 0.59 contact (17 units) | 0.69 declared, 0.66 contact (32 units) |
|   per unit a game, units carrying another wizard (or one alone) | 1.00 declared, 0.80 contact (10 units) | 1.44 declared, 1.11 contact (9 units) | 1.21 declared, 0.95 contact (19 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.61 declared, 0.42 contact (249 units) | 0.72 declared, 0.47 contact (295 units) | 0.67 declared, 0.45 contact (544 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 53% (43 of 81) | 56% (9 of 16) | 33% (2 of 6) | 52% (54 of 103) |
| Character in a unit | 79% (23 of 29) | 69% (11 of 16) | 100% (1 of 1) | 76% (35 of 46) |
| Character on its own | 89% (32 of 36) | 50% (13 of 26) | 27% (21 of 77) | 47% (66 of 139) |
| Chariot | 60% (9 of 15) | 67% (8 of 12) | - | 63% (17 of 27) |
| Infantry | 61% (51 of 83) | 44% (11 of 25) | 33% (2 of 6) | 56% (64 of 114) |
| Monster | 74% (25 of 34) | 79% (11 of 14) | - | 75% (36 of 48) |
| Monstrous | 79% (11 of 14) | 71% (10 of 14) | - | 75% (21 of 28) |
| War Machines | 74% (32 of 43) | 100% (2 of 2) | - | 76% (34 of 45) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 93% (14 of 15); on the table 100% | 33% (34 of 102) | 22% | 68% (15 of 22) | 100% (6 of 6); 3.0 uses a game | 50% (1 of 2); 0.5 uses a game | 83% (5 of 6); 1.2 uses a game |
| Chaos Dwarfs | 4 | 100% (16 of 16); on the table 100% | 33% (8 of 24) | 24% | 62% (20 of 32) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
| Dwarfen Mountain Holds | 3 | 100% (7 of 7); on the table 100% | - | 54% | 67% (18 of 27) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 6 | 90% (18 of 20); on the table 90% | 44% (8 of 18) | 60% | 71% (44 of 62) | 0.0 uses a game | 100% (2 of 2); 0.8 uses a game | 100% (5 of 5); 0.8 uses a game |
| Grand Cathay | 4 | 86% (12 of 14); on the table 86% | 25% (21 of 84) | 28% | 43% (16 of 37) | 100% (9 of 9); 5.8 uses a game | 50% (1 of 2); 0.2 uses a game | 0% (0 of 4); 0.0 uses a game |
| High Elf Realms | 9 | 97% (38 of 39); on the table 97% | 11% (4 of 36) | 31% | 44% (31 of 70) | 100% (7 of 7); 2.4 uses a game | 37% (11 of 30); 2.6 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | 75% (3 of 4); on the table 75% | - | 19% | 17% (1 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Lizardmen | 3 | 86% (12 of 14); on the table 86% | 17% (1 of 6) | 25% | 62% (13 of 21) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 2 | 71% (5 of 7); on the table 71% | 17% (1 of 6) | 27% | 79% (11 of 14) | 50% (1 of 2); 0.5 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 3 | 100% (3 of 3); on the table 100% | 12% (5 of 42) | 29% | 50% (12 of 24) | 0.0 uses a game | 0.0 uses a game | 100% (3 of 3); 1.0 uses a game |
| Skaven | 6 | 83% (10 of 12); on the table 83% | 38% (15 of 39) | 43% | 73% (33 of 45) | 100% (3 of 3); 1.3 uses a game | 0.0 uses a game | 33% (2 of 6); 0.5 uses a game |
| Tomb Kings of Khemri | 4 | 94% (16 of 17); on the table 94% | 17% (1 of 6) | 37% | 50% (10 of 20) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 8 | 92% (23 of 25); on the table 96% | 32% (18 of 56) | 28% | 52% (22 of 42) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 9 | 81% (13 of 16); on the table 81% | 42% (5 of 12) | 39% | 64% (46 of 72) | 100% (2 of 2); 0.4 uses a game | 0.0 uses a game | 100% (3 of 3); 0.3 uses a game |
| Wood Elf Realms | 6 | 91% (21 of 23); on the table 96% | 33% (2 of 6) | 32% | 62% (35 of 56) | 50% (1 of 2); 1.0 uses a game | 0.0 uses a game | 75% (3 of 4); 0.5 uses a game |

Flank and rear charges a unit could have turned to face (sp-h2h-mine-89601ea-p4, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 55% (54) | 37% (25) | 47% (79) |
| ...free all their last turn and able to turn (per game) | 0.78 | 0.42 | 1.19 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.36 | 0.17 | 0.53 |
| ...with the charger already in that arc before they moved (per game) | 0.56 | 0.22 | 0.78 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 1.33 | 1.14 | 2.47 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.97 | 0.64 | 1.61 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 5.58 | 5.22 | 10.81 |

### Quality by phase: sp-h2h-mine-89601ea-p4

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.1 | 3.6 |
| Strategy | Charge objectives carried out (made contact) | 42% (73 of 173) | 39% (80 of 207) |
| Strategy | Shoot objectives carried out (shot that target) | 39% (158 of 406) | 54% (73 of 134) |
| Strategy | Close-in objectives charged next turn | 14% (20 of 146) | 14% (33 of 228) |
| Strategy | Support requests answered (helper made contact too) | 50% (9 of 18) | 32% (12 of 38) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (3 of 3) | - |
| Strategy | Hexes on a unit its side charged or shot that turn | 77% (10 of 13) | 67% (4 of 6) |
| Strategy | Joined characters whose unit fought | 61% (20 of 33) | 44% (14 of 32) |
| Strategy | Lone characters that fought | 73% (66 of 90) | 77% (65 of 84) |
| Movement | Charges halted short of contact | 0.1 | 0.3 |
| Movement | Idle units | 1.1 | 2.0 |
| Movement | Points that never moved of their own | 309.4 | 88.8 |
| Movement | Fights charged into per game | 3.1 | 3.9 |
| Movement | Charges with odds: long shots (under 50%) | 12 of 97, net +38 | 22 of 117, net -23 |
| Movement | Charges with odds: sweet spot (55-75%) | 17 of 97, net +55 | 19 of 117, net +93 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 12 of 97, net +60 | 13 of 117, net +84 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 37 of 97, net +123 | 41 of 117, net +113 |
| Shooting | Shots by shooting units (incl. breath weapons) | 10.1 | 8.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 44% (161 of 364) | 37% (110 of 299) |
| Shooting | Points destroyed by shooting units | 94.6 | 50.1 |
| Shooting | War machine shots | 6.5 | 0.8 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 48% (112 of 234) | 28% (8 of 29) |
| Shooting | Points destroyed by war machines | 45.4 | 11.4 |
| Magic | Magic missiles cast | 1.4 | 1.0 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 31% (16 of 52) | 34% (12 of 35) |
| Magic | Wounds caused by magic missiles | 3.7 | 1.2 |
| Magic | Wounds caused by other spells | 2.7 | 1.7 |
| Magic | Points destroyed by magic (all spells) | 104.5 | 30.1 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.2 / 0.4 / 0.9 / 0.1 | 2.0 / 0.5 / 0.8 / 0.1 |
| Combat | Points destroyed in combat | 372.3 | 450.1 |
| Combat | Points run down | 98.4 | 76.6 |
| Combat | Net points per charged fight, damage counted | +79 | +79 |
| Combat | Net per 100 charger points, damage counted | +28.7 | +25.4 |
| Combat | First round won (charged fights) | 74% | 69% |
| Combat | Net points per charged fight | +86 | +82 |
| Combat | Net points per supported fight / lone fight | +78 / +87 | +120 / +78 |
| Combat | Charged fights on a top-3 enemy unit | 36 of 110 | 65 of 139 |
| Game | Points lost | 759.6 | 778.7 |
| Game | VP from objectives | 511.4 | 495.0 |
| Game | Lone holders (player turns) | 2.2 | 2.1 |

- Mine won / drew / lost: 13 / 9 / 14 of 36 ended games (of 36); mean margin (Mine - Opponent) -40 VP
- The side that went first won 16 of 27 games with a winner
- Points traded per game (both sides' losses): 1538
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: sp-h2h-mine-89601ea-p4

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 0.8 | +0.0 | 0.0 | 0.0 |
| ALREADY CARRIED | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARTILLERY RE-ROLL WEIGHED | 1.2 | +0.0 | 0.0 | 19.3 | 0.1 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | 0.7 | +4.4 | 0.0 | 8.6 | 1.1 | +12.3 | 0.0 | 17.1 |
| BEST FACING | 0.4 | +24.8 | 0.0 | 26.7 | 0.5 | +19.1 | 0.0 | 34.8 |
| BEST FIRST | 3.4 | +129.7 | 111.0 | 58.1 | 3.5 | +121.9 | 47.6 | 42.5 |
| BEST MOVE FOR SHOOTERS | 1.1 | +70.2 | 0.0 | 31.7 | - | - | - | - |
| BEST OVERALL | 0.5 | +32.4 | 0.0 | 6.9 | 0.2 | +7.9 | 0.0 | 14.9 |
| BEST PREY | 0.8 | +33.2 | 6.9 | 21.1 | 0.8 | +49.4 | 24.9 | 37.4 |
| BEST PRIZE | 0.0 | -5.9 | 0.0 | 0.0 | 0.1 | -15.1 | 20.1 | 9.7 |
| BIG CHARACTER SAFETY | 0.1 | -0.5 | 0.0 | 0.0 | 0.2 | -0.3 | 0.0 | 24.7 |
| BLOCKED CHARGE HANDED OVER | - | - | - | - | 0.0 | +3.3 | 5.5 | 15.0 |
| BLOCKED CHARGE SKIPPED | 0.1 | +0.0 | 3.3 | 0.0 | 0.2 | +0.0 | 11.4 | 1.5 |
| BLOCKED WHEEL | 0.5 | +8.4 | 0.0 | 0.0 | 0.6 | +6.9 | 0.0 | 8.8 |
| BOMBING RUN | 0.0 | +0.2 | 0.0 | 0.0 | - | - | - | - |
| BOUND ASSAILMENT | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CANNON PLAN MISSED | - | - | - | - | 0.0 | +0.0 | 10.6 | 0.0 |
| CANNON PLANNED TARGET | - | - | - | - | 0.6 | +35.9 | 66.8 | 6.9 |
| CANNON SIGHT KEPT | 1.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT COUNTER | 0.1 | +0.0 | 31.7 | 10.2 | 0.1 | +0.0 | 3.3 | 11.3 |
| CARRIES OUT SET-UP | 0.0 | +0.0 | 6.2 | 0.0 | 0.2 | -16.6 | 6.9 | 0.0 |
| CAST JOB | 0.8 | +21.2 | 61.1 | 13.5 | 0.4 | +6.2 | 21.2 | 0.0 |
| CASTER AWAY FROM SCREEN | 0.3 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.2 | +23.4 | 2.7 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | 0.8 | +0.0 | 0.0 | 23.5 | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.0 | +1.1 | 0.0 | 6.6 | - | - | - | - |
| CHAFF PASSED | - | - | - | - | 0.1 | -0.0 | 0.0 | 0.0 |
| CHARGE NOW FIRST | 3.1 | +0.0 | 322.5 | 80.5 | 3.1 | +0.0 | 214.9 | 113.2 |
| CHARGE NOW WEIGHED | 0.6 | -64.6 | 23.0 | 34.6 | 0.6 | -54.9 | 5.7 | 61.6 |
| CHARIOT NO STATIC JOB | 0.1 | +0.0 | 11.8 | 0.0 | - | - | - | - |
| CHARIOT WIZARD CAREFUL | 0.1 | -0.8 | 13.9 | 13.9 | 0.1 | -2.0 | 0.0 | 0.0 |
| CHEAP HELPER | 0.1 | +0.0 | 4.8 | 4.0 | 0.1 | +0.0 | 9.4 | 4.5 |
| COMBAT PIVOT | 0.6 | +0.0 | 59.0 | 24.2 | 0.8 | +0.0 | 33.6 | 69.6 |
| CONVEYANCE SEARCH | 0.8 | +160.3 | 20.2 | 44.4 | 0.2 | +42.9 | 4.4 | 0.0 |
| COUNTER-CHARGE COVER | 8.9 | +591.3 | 0.0 | 187.0 | 6.5 | +518.4 | 0.0 | 156.6 |
| DEFENSIVE ARMY | 0.2 | +0.0 | 35.3 | 3.5 | 0.0 | +0.0 | 0.0 | 0.0 |
| DEFENSIVE FLOOR | 0.1 | +1.3 | 9.7 | 0.0 | 0.1 | +4.9 | 17.2 | 0.0 |
| EDGE GIVE GROUND | 0.1 | +2.5 | 14.3 | 3.4 | 0.1 | +5.2 | 15.4 | 0.0 |
| ELIXIR WORTH | - | - | - | - | 0.1 | +2.2 | 0.0 | 0.0 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACE THE CAST | 0.1 | +1.5 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 1.3 | +120.8 | 0.0 | 57.1 | 1.1 | +93.9 | 0.0 | 56.9 |
| FALLBACK BY WORTH | 4.6 | +50.7 | 0.0 | 49.8 | 6.1 | +53.0 | 0.0 | 78.7 |
| FIGHT LIFT | 0.2 | +1.4 | 3.2 | 16.1 | - | - | - | - |
| FIRE AND FLEE | - | - | - | - | 0.0 | +0.3 | 0.0 | 3.0 |
| FIRE IN ORDER | 0.5 | +0.0 | 14.0 | 1.8 | - | - | - | - |
| FIRE PLAN | 16.5 | +520.2 | 1036.4 | 244.4 | - | - | - | - |
| FLANK NOT WEIGHED | 5.7 | +0.0 | 0.0 | 124.7 | 4.7 | +0.0 | 0.0 | 126.4 |
| FOCUS FIRE | - | - | - | - | 0.0 | +0.4 | 1.8 | 0.0 |
| FOLLOW UP WEIGHED | 1.3 | +155.5 | 0.0 | 56.5 | 1.5 | +228.3 | 0.0 | 91.3 |
| FRIENDS SHOTS CHECKED | 0.5 | +47.7 | 0.0 | 10.5 | 0.1 | +3.1 | 0.0 | 4.9 |
| GIVES UP | 0.1 | -1.4 | 8.2 | 2.4 | 0.1 | -2.1 | 17.5 | 0.0 |
| GIVES UP ITS SCREEN | - | - | - | - | 0.1 | -1.0 | 7.1 | 1.2 |
| GROUND FLIERS | 0.0 | +0.6 | 0.0 | 6.1 | 0.1 | +1.9 | 0.0 | 0.0 |
| HELPER ALREADY ASKED | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 6.2 | 0.0 |
| HELPER UNSEEN | 0.2 | +0.0 | 24.7 | 5.7 | 0.3 | +0.0 | 23.4 | 1.8 |
| HILL BY ITS CHANCE | 0.4 | -42.5 | 0.0 | 15.0 | 0.5 | -46.8 | 0.0 | 23.6 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| HUNT ADVANCE | 0.0 | +0.0 | 0.0 | 0.0 | 0.2 | +6.6 | 3.5 | 2.4 |
| HUNT DROPPED | 0.1 | +0.0 | 0.0 | 1.9 | 0.1 | +0.0 | 0.0 | 3.1 |
| HUNT IN PAIRS | 0.4 | +18.5 | 0.0 | 0.0 | 0.5 | +24.7 | 0.0 | 0.0 |
| HUNT KEPT | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +2.5 | 0.0 | 1.2 |
| HUNT RESULT | 0.1 | +0.0 | 0.0 | 1.9 | 0.2 | +24.2 | 0.0 | 6.7 |
| HUNT THE GUNS | 0.1 | +19.6 | 0.0 | 0.0 | 0.2 | +89.6 | 21.9 | 2.4 |
| INVITES THE FIGHT | 1.8 | +29.0 | 61.0 | 40.8 | 1.0 | +16.9 | 20.7 | 42.6 |
| JOINT CHARGE PLAN | 0.1 | +1.3 | 0.0 | 0.0 | 0.1 | +6.3 | 0.0 | 14.6 |
| KEEP FALLS | 0.1 | +1.3 | 0.0 | 0.0 | 0.1 | +0.3 | 0.0 | 0.0 |
| KEEPS ITS PREY | - | - | - | - | 0.1 | +0.6 | 0.0 | 5.8 |
| KEEPS ITS TARGET | 1.8 | +53.3 | 157.2 | 43.1 | 2.2 | +66.7 | 163.6 | 37.6 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KEEPS THE TARGET | 1.6 | -31.0 | 193.1 | 26.5 | - | - | - | - |
| KILLS COUNT | 2.3 | +81.9 | 216.3 | 67.5 | 2.7 | +147.8 | 191.2 | 64.9 |
| KILLS COUNT NEXT TURN | 4.8 | +174.3 | 202.4 | 110.5 | 7.1 | +276.9 | 292.1 | 150.3 |
| LONE CHARACTER SAFE SPOT | 0.2 | +10.0 | 0.0 | 1.2 | 0.1 | +0.2 | 0.0 | 15.5 |
| LONE WIZARD HOLDS BACK | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 1.8 | 0.0 |
| LONE WIZARD KEPT IN | 0.6 | +26.9 | 0.0 | 0.0 | 0.2 | +20.3 | 0.0 | 0.0 |
| LONG SHOT | 0.7 | -3.1 | 64.7 | 19.7 | 0.7 | -3.9 | 30.2 | 4.3 |
| LOST CHARGE | 2.9 | -39.0 | 122.1 | 82.9 | 2.1 | -56.7 | 34.5 | 37.8 |
| LURE BY WHAT IT DRAWS | 0.0 | -0.1 | 0.0 | 0.0 | 0.1 | -5.7 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 0.5 | +33.8 | 6.2 | 1.4 | 0.8 | +132.0 | 0.0 | 25.7 |
| MANOEUVRE | 0.2 | +16.8 | 0.0 | 0.0 | 0.1 | +0.9 | 0.0 | 3.4 |
| MARCH AT ESCAPER | 0.1 | +0.3 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | 0.4 | +22.7 | 0.0 | 9.1 | 0.3 | +17.5 | 0.0 | 4.4 |
| MARCH ODDS | 0.2 | +12.5 | 7.0 | 0.0 | 0.3 | +10.6 | 23.4 | 28.9 |
| MARCH OVER CASTS | 0.2 | +18.9 | 0.0 | 10.6 | 0.3 | +37.3 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 4.7 | +146.6 | 0.0 | 94.7 | 4.6 | +160.0 | 0.0 | 96.8 |
| MISSILES IN THE FIRE PLAN | 3.3 | +124.2 | 213.2 | 35.7 | - | - | - | - |
| MISSILES IN THE MOVE | 3.9 | +119.9 | 0.0 | 79.9 | 2.1 | +32.4 | 0.0 | 72.4 |
| MISSILES NEXT TURN | 4.5 | +81.8 | 0.0 | 110.8 | 2.9 | +24.5 | 0.0 | 62.8 |
| MODEL FACING | 0.2 | +19.0 | 0.0 | 3.3 | - | - | - | - |
| MONSTER WIZARD ROAMS | 0.3 | +0.0 | 18.3 | 10.6 | 0.1 | +0.0 | 6.6 | 0.0 |
| MOVE AND CAST | 0.3 | +16.3 | 0.0 | 7.2 | 0.3 | +8.3 | 0.0 | 0.0 |
| MOVE SPELL IN RANGE | 0.4 | +8.0 | 0.0 | 9.4 | 0.0 | +0.4 | 0.0 | 0.0 |
| MOVE SPELL OUT OF RANGE | 0.4 | -16.1 | 4.3 | 0.0 | 0.1 | -12.3 | 0.0 | 0.0 |
| MOVE SPELL SPOT | 0.5 | +0.0 | 0.0 | 11.9 | 0.1 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE | 3.1 | +143.1 | 133.5 | 28.8 | 4.8 | +515.6 | 190.0 | 104.6 |
| MOVES UNITS SPELL | 0.1 | +3.3 | 0.0 | 0.0 | 0.1 | +0.6 | 0.0 | 0.0 |
| NEEDED THERE | 0.0 | +1.1 | 1.9 | 0.0 | 0.1 | +5.9 | 18.9 | 0.0 |
| NO RALLY LEFT | 0.1 | +1.6 | 0.0 | 3.4 | - | - | - | - |
| NOT NEEDED | 0.4 | -17.7 | 47.6 | 5.6 | 0.6 | -23.2 | 58.5 | 0.0 |
| NOT TURNED | 5.6 | +104.8 | 0.0 | 87.2 | 5.2 | +99.1 | 0.0 | 148.1 |
| NOT WORTH A CAST | 0.8 | -0.5 | 0.0 | 0.0 | 0.4 | -0.2 | 0.0 | 0.0 |
| OFF BEST | 14.6 | -690.2 | 1.9 | 244.8 | 14.1 | -654.9 | 12.5 | 287.3 |
| OPENS A LANE | 0.1 | +1.9 | 19.6 | 0.0 | - | - | - | - |
| OPENS UP | 0.2 | +13.6 | 15.7 | 0.0 | 0.3 | +54.3 | 12.0 | 0.0 |
| OVERRUNS AWAY | 0.5 | +14.9 | 59.9 | 17.8 | 0.6 | +5.6 | 29.2 | 20.2 |
| PATHS CROSS | 2.3 | +211.4 | 0.0 | 46.3 | 2.8 | +241.8 | 0.0 | 52.9 |
| PERIAPT WORTH | 0.0 | +3.4 | 0.0 | 0.0 | 0.1 | +4.2 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.3 | -7.0 | 0.0 | 0.0 | 0.1 | -2.5 | 0.0 | 13.4 |
| PLAN RESULT | 37.9 | +1403.2 | 1679.7 | 973.6 | 38.8 | +1145.9 | 1454.4 | 1201.2 |
| PURSUES BIG PREY | 0.1 | -10.0 | 0.0 | 0.0 | 0.1 | -4.4 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE NEXT TURN | 0.1 | +8.8 | 0.0 | 2.2 | 0.1 | +7.4 | 0.0 | 3.4 |
| RANDOM MOVE BY FIGURES | 1.0 | +12.8 | 0.0 | 38.6 | 1.8 | +31.8 | 0.0 | 71.8 |
| RANDOM MOVER NO PROMISE | 0.3 | -17.4 | 10.8 | 9.4 | 0.3 | -24.5 | 27.1 | 15.7 |
| REDIRECT BY WHAT IT STOPS | 0.2 | +4.4 | 0.0 | 6.2 | 0.5 | -12.6 | 0.0 | 11.3 |
| REDIRECT COUNTER | 2.4 | +180.0 | 0.0 | 35.9 | 3.9 | +352.9 | 0.0 | 102.3 |
| REDIRECT WEIGHED | 0.4 | +18.8 | 22.2 | 3.3 | 0.4 | -8.8 | 24.8 | 9.7 |
| RESERVE FALL BACK | 0.4 | +17.7 | 0.0 | 5.7 | 0.5 | +24.9 | 0.0 | 9.2 |
| RESTRAINS TO SHOOT | 0.1 | +4.1 | 0.0 | 6.1 | 0.1 | +2.0 | 0.0 | 3.4 |
| RISK BY ARC | 3.2 | +133.1 | 287.5 | 89.7 | 3.2 | +30.0 | 239.4 | 105.7 |
| SAFER THAN THE JOB | 1.0 | +69.6 | 0.0 | 17.6 | 0.6 | +24.1 | 0.0 | 23.9 |
| SCOUT SPOT | 0.4 | +0.5 | 0.0 | 0.9 | 0.1 | +0.0 | 0.0 | 1.8 |
| SCOUT WAITS | 0.5 | +0.0 | 0.0 | 0.9 | 0.1 | +0.0 | 0.0 | 1.8 |
| SCREEN BY WHAT IT SAVES | 0.1 | -3.7 | 0.0 | 1.0 | 0.2 | -11.0 | 0.0 | 3.1 |
| SEARCH SPOT | 3.4 | +139.6 | 0.0 | 53.0 | 2.8 | +150.0 | 0.0 | 50.6 |
| SELF MOVE SPELL | 0.2 | +51.4 | 0.0 | 0.0 | 0.4 | +12.6 | 0.0 | 0.0 |
| SET UP TOGETHER | 0.8 | +63.8 | 6.2 | 4.5 | 1.4 | +177.0 | 13.3 | 52.6 |
| SET-UP ANY TARGET | 0.6 | +104.9 | 0.0 | 18.6 | 0.0 | +1.1 | 4.4 | 0.0 |
| SET-UP MISSED | 0.1 | +14.0 | 4.9 | 4.7 | - | - | - | - |
| SHOOTERS ARE THREATS | 3.7 | +237.6 | 243.9 | 73.9 | - | - | - | - |
| SHOOTERS IN TWO RANKS | 0.3 | +0.8 | 0.0 | 0.0 | 0.2 | +0.3 | 0.0 | 0.0 |
| SHOOTERS TO THE PRIMARY | 5.4 | +364.3 | 0.0 | 99.9 | - | - | - | - |
| SHOOTS FROM THE BEST SPOT | 1.0 | +48.2 | 82.8 | 19.3 | 0.5 | +11.7 | 28.4 | 19.1 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 3.3 | 0.0 | +0.0 | 0.0 | 0.0 |
| SHOT OPTIONS | 16.2 | +0.0 | 755.4 | 272.3 | 8.2 | +0.0 | 280.7 | 135.3 |
| SHOT REPLANNED | - | - | - | - | 0.1 | +0.0 | 20.6 | 0.0 |
| SHOTS IN THE MOVE | 15.0 | +572.5 | 0.0 | 214.3 | 6.6 | +177.4 | 0.0 | 84.6 |
| SPELL CATCH ODDS | 0.0 | -1.5 | 0.0 | 0.0 | - | - | - | - |
| SPELL SETS UP CHARGE | 0.6 | +119.9 | 0.0 | 18.6 | 0.1 | +33.0 | 4.4 | 0.0 |
| SPELL WORTH | 1.4 | +24.0 | 104.2 | 120.1 | 2.4 | +43.3 | 95.5 | 95.5 |
| STABLE ROLE | 10.9 | +0.0 | 480.9 | 210.4 | 9.4 | +0.0 | 187.9 | 162.4 |
| STANDS TO CAST | 0.1 | +1.0 | 0.0 | 0.0 | - | - | - | - |
| STAY WORTH | 17.8 | +54.0 | 466.9 | 166.1 | - | - | - | - |
| STOPS | 0.0 | +0.3 | 0.0 | 0.0 | 0.1 | +2.9 | 18.5 | 1.2 |
| STOPS SHORT OF THE FLANK | 0.4 | +11.1 | 0.0 | 8.6 | 0.4 | +14.1 | 0.0 | 0.0 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 9.9 |
| SUPPORT JOB KEPT | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SUPPORT NARROWED | 6.1 | -46.4 | 404.4 | 116.1 | 8.0 | -53.5 | 304.0 | 160.0 |
| SUPPORTS | 3.6 | +51.7 | 189.9 | 73.5 | 5.4 | +55.8 | 150.4 | 93.4 |
| SURE CHARGE BEATS ADVANCE | 0.1 | -2.4 | 3.1 | 3.1 | - | - | - | - |
| SURE REACH TOGETHER | 0.3 | +0.5 | 0.0 | 2.6 | 0.5 | -7.2 | 0.0 | 14.7 |
| THREAT AT FULL SIZE | 8.6 | +0.0 | 542.3 | 159.3 | - | - | - | - |
| THROUGH LINE OF FIRE | 0.4 | +28.8 | 0.0 | 11.6 | 0.1 | +4.4 | 0.0 | 0.0 |
| TURN WORTH | 0.7 | -45.1 | 53.9 | 6.0 | 0.5 | -53.0 | 22.0 | 0.0 |
| TWO OR MORE ARRIVE | 0.3 | +1.9 | 6.2 | 0.0 | 0.2 | +2.1 | 0.0 | 10.7 |
| WAIT AFTER COSTS | 6.5 | -266.3 | 253.6 | 82.0 | 7.8 | -395.0 | 263.9 | 209.4 |
| WALKS TO THE FIGHT | 1.4 | +23.4 | 40.1 | 36.8 | 1.4 | +23.2 | 18.5 | 21.5 |
| WAR ENGINE CHARGES | 0.0 | +0.4 | 0.0 | 0.0 | - | - | - | - |
| WAR ENGINE JOBS | 0.8 | +0.0 | 55.6 | 8.9 | 0.1 | +0.0 | 8.1 | 8.1 |
| WEARS DOWN | 1.4 | +66.2 | 110.3 | 33.8 | 1.1 | +39.4 | 76.4 | 69.2 |
| WHO HITS BACK | 0.4 | +24.7 | 0.0 | 9.1 | 0.1 | +5.7 | 0.0 | 15.0 |
| WHOLE FIGHT | 0.2 | +13.8 | 29.6 | 2.2 | 0.6 | +24.0 | 60.2 | 2.2 |
| WHOLE FIGHT GAIN | 0.3 | +34.6 | 18.5 | 12.3 | 0.8 | +51.7 | 45.1 | 7.3 |
| WOUNDED STAYS OUT | 0.0 | +0.0 | 4.4 | 0.0 | 0.1 | +0.0 | 4.5 | 0.0 |

### Rule changes: sp-h2h-mine-89601ea-p4

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 1033 | 1033 | 1033 | 28.69 | -48425 | -46.9 |
| BEST FIRST | 249 | 249 | 249 | 6.92 | +9057 | +36.4 |
| SEARCH SPOT | 223 | 223 | 221 | 6.14 | +10431 | +47.2 |
| FIRE PLAN | 595 | 595 | 187 | 5.19 | +7487 | +40.0 |
| PATHS CROSS | 185 | 185 | 185 | 5.14 | +16315 | +88.2 |
| MOVE TO CHARGE | 281 | 281 | 164 | 4.56 | +9693 | +59.1 |
| COUNTER-CHARGE COVER | 555 | 309 | 123 | 3.42 | +6137 | +49.9 |
| KILLS COUNT NEXT TURN | 431 | 431 | 116 | 3.22 | +4443 | +38.3 |
| SUPPORTS | 324 | 324 | 105 | 2.92 | +1174 | +11.2 |
| FOLLOW UP WEIGHED | 100 | 100 | 100 | 2.78 | +13817 | +138.2 |
| FACES THE THREAT | 89 | 89 | 89 | 2.47 | +7729 | +86.8 |
| FALLBACK BY WORTH | 387 | 387 | 83 | 2.31 | +3734 | +45.0 |
| SHOTS IN THE MOVE | 778 | 518 | 82 | 2.28 | +2005 | +24.5 |
| WALKS TO THE FIGHT | 102 | 102 | 61 | 1.69 | +547 | +9.0 |
| CHARGE NOW FIRST | 221 | 221 | 60 | 1.67 | -4027 | -67.1 |
| WAIT AFTER COSTS | 513 | 513 | 59 | 1.64 | +1068 | +18.1 |
| RANDOM MOVE BY FIGURES | 99 | 99 | 58 | 1.61 | +1605 | +27.7 |
| SAFER THAN THE JOB | 58 | 58 | 58 | 1.61 | +3372 | +58.1 |
| REDIRECT COUNTER | 226 | 142 | 56 | 1.56 | +5391 | +96.3 |
| ADVANCE LANE KEPT | 55 | 55 | 55 | 1.53 | +0 | +0.0 |
| COMBAT PIVOT | 49 | 49 | 49 | 1.36 | +0 | +0.0 |
| ARTILLERY RE-ROLL WEIGHED | 45 | 45 | 45 | 1.25 | +0 | +0.0 |
| CHARGE NOW WEIGHED | 43 | 43 | 43 | 1.19 | +2667 | +62.0 |
| MAX FOR POSITIONING | 333 | 192 | 43 | 1.19 | +394 | +9.2 |
| CANNON SIGHT KEPT | 42 | 42 | 42 | 1.17 | +0 | +0.0 |
| BEST MOVE FOR SHOOTERS | 39 | 39 | 39 | 1.08 | +2528 | +64.8 |
| SET UP TOGETHER | 79 | 67 | 39 | 1.08 | +4403 | +112.9 |
| BLOCKED WHEEL | 38 | 38 | 38 | 1.06 | +552 | +14.5 |
| RISK BY ARC | 232 | 225 | 36 | 1.00 | +1572 | +43.7 |
| HOLDS AMBUSHERS | 35 | 35 | 35 | 0.97 | +0 | +0.0 |
| KILLS COUNT | 181 | 178 | 35 | 0.97 | +1618 | +46.2 |
| RESERVE FALL BACK | 34 | 34 | 34 | 0.94 | +1535 | +45.1 |
| BEST FACING | 33 | 33 | 33 | 0.92 | +1580 | +47.9 |
| REDIRECT WEIGHED | 31 | 31 | 31 | 0.86 | +890 | +28.7 |
| SHOOTS FROM THE BEST SPOT | 55 | 55 | 31 | 0.86 | +863 | +27.8 |
| STOPS SHORT OF THE FLANK | 29 | 29 | 29 | 0.81 | +908 | +31.3 |
| LONE WIZARD KEPT IN | 28 | 28 | 28 | 0.78 | +1699 | +60.7 |
| BEST OVERALL | 27 | 27 | 27 | 0.75 | +1454 | +53.8 |
| WHOLE FIGHT GAIN | 39 | 38 | 27 | 0.75 | +1268 | +47.0 |
| MISSILES IN THE MOVE | 216 | 112 | 26 | 0.72 | +558 | +21.5 |
| STAY WORTH | 642 | 543 | 25 | 0.69 | +189 | +7.5 |
| FRIENDS SHOTS CHECKED | 24 | 24 | 24 | 0.67 | +1828 | +76.2 |
| INVITES THE FIGHT | 101 | 101 | 24 | 0.67 | +454 | +18.9 |
| KEEPS ITS TARGET | 144 | 142 | 24 | 0.67 | +422 | +17.6 |
| MARCH CHECK | 26 | 25 | 23 | 0.64 | +909 | +39.5 |
| MOVE AND CAST | 22 | 22 | 22 | 0.61 | +887 | +40.3 |
| SCOUT WAITS | 21 | 21 | 21 | 0.58 | +0 | +0.0 |
| WHO HITS BACK | 20 | 20 | 20 | 0.56 | +550 | +27.5 |
| FIRE IN ORDER | 19 | 19 | 19 | 0.53 | +0 | +0.0 |
| MAKE SURE TOGETHER | 46 | 34 | 19 | 0.53 | +3411 | +179.5 |
| MARCH ODDS | 19 | 19 | 19 | 0.53 | +180 | +9.5 |
| BEST PREY | 58 | 58 | 18 | 0.50 | +782 | +43.4 |
| SHOOTERS IN TWO RANKS | 18 | 18 | 18 | 0.50 | +41 | +2.3 |
| CAST JOB | 44 | 44 | 17 | 0.47 | +147 | +8.6 |
| CASTER AWAY FROM SCREEN | 17 | 17 | 17 | 0.47 | +0 | +0.0 |
| PIVOT GUARDS FLANK | 16 | 16 | 16 | 0.44 | -342 | -21.4 |
| THROUGH LINE OF FIRE | 16 | 16 | 16 | 0.44 | +1193 | +74.6 |
| WEARS DOWN | 90 | 86 | 16 | 0.44 | +489 | +30.6 |
| KEEPS THE TARGET | 59 | 59 | 15 | 0.42 | -1210 | -80.6 |
| STUCK PIVOT | 13 | 13 | 13 | 0.36 | +0 | +0.0 |
| BIG CHARACTER SAFETY | 11 | 11 | 11 | 0.31 | -28 | -2.5 |
| BLOCKED CHARGE SKIPPED | 11 | 11 | 11 | 0.31 | +0 | +0.0 |
| MISSILES IN THE FIRE PLAN | 119 | 25 | 11 | 0.31 | +355 | +32.3 |
| SHOOTERS TO THE PRIMARY | 195 | 142 | 11 | 0.31 | +378 | +34.4 |
| WAR ENGINE JOBS | 30 | 30 | 11 | 0.31 | -322 | -29.3 |
| MANOEUVRE | 11 | 11 | 10 | 0.28 | +637 | +63.7 |
| OPENS UP | 18 | 18 | 10 | 0.28 | +981 | +98.1 |
| SUPPORT NARROWED | 508 | 508 | 10 | 0.28 | -119 | -11.9 |
| CASTS FROM BEHIND | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| SHORT GUN FORWARD | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| MISSILES NEXT TURN | 267 | 149 | 8 | 0.22 | +43 | +5.3 |
| WHOLE FIGHT | 28 | 26 | 8 | 0.22 | +463 | +57.8 |
| LOST CHARGE | 177 | 175 | 7 | 0.19 | +115 | +16.4 |
| MOVES UNITS SPELL | 7 | 7 | 7 | 0.19 | +138 | +19.7 |
| RAIDS THE BAGGAGE NEXT TURN | 7 | 7 | 7 | 0.19 | +459 | +65.6 |
| SHOOTERS ARE THREATS | 132 | 132 | 7 | 0.19 | +0 | +0.0 |
| BEST PRIZE | 6 | 6 | 6 | 0.17 | -995 | -165.9 |
| HUNT IN PAIRS | 33 | 21 | 6 | 0.17 | +183 | +30.6 |
| KEEP FALLS | 6 | 6 | 6 | 0.17 | +214 | +35.7 |
| MODEL FACING | 6 | 6 | 6 | 0.17 | +684 | +114.1 |
| RESTRAINS TO SHOOT | 6 | 6 | 6 | 0.17 | +218 | +36.3 |
| CASTING BLOCK | 8 | 8 | 5 | 0.14 | +402 | +80.4 |
| FACE THE CAST | 5 | 5 | 5 | 0.14 | +55 | +11.0 |
| PURSUES BIG PREY | 5 | 5 | 5 | 0.14 | -520 | -104.1 |
| SHOT REPLANNED | 5 | 5 | 5 | 0.14 | +0 | +0.0 |
| SURE REACH TOGETHER | 28 | 24 | 5 | 0.14 | +4 | +0.8 |
| BACKUP TARGETS | 64 | 31 | 4 | 0.11 | +22 | +5.5 |
| CANNON PLANNED TARGET | 20 | 20 | 4 | 0.11 | +0 | +0.0 |
| DEFENSIVE ARMY | 9 | 9 | 4 | 0.11 | -82 | -20.6 |
| DEFENSIVE FLOOR | 6 | 6 | 4 | 0.11 | +116 | +28.9 |
| ELIXIR WORTH | 3 | 3 | 3 | 0.08 | +78 | +26.1 |
| HUNT ADVANCE | 8 | 8 | 3 | 0.08 | +55 | +18.4 |
| LONE WIZARD HOLDS BACK | 14 | 14 | 3 | 0.08 | -198 | -66.0 |
| LONG SHOT | 49 | 47 | 3 | 0.08 | +40 | +13.3 |
| NEEDED THERE | 4 | 4 | 3 | 0.08 | +0 | +0.0 |
| OVERRUNS AWAY | 39 | 39 | 3 | 0.08 | +103 | +34.4 |
| PERIAPT WORTH | 3 | 3 | 3 | 0.08 | +275 | +91.6 |
| SURE CHARGE BEATS ADVANCE | 3 | 3 | 3 | 0.08 | -88 | -29.3 |
| THREAT AT FULL SIZE | 310 | 310 | 3 | 0.08 | +0 | +0.0 |
| WOUNDED STAYS OUT | 3 | 3 | 3 | 0.08 | -136 | -45.4 |
| BOUND ASSAILMENT | 2 | 2 | 2 | 0.06 | +0 | +0.2 |
| CARRIES OUT SET-UP | 8 | 8 | 2 | 0.06 | -596 | -298.1 |
| CHAFF PASSED | 2 | 2 | 2 | 0.06 | -0 | -0.2 |
| CHARIOT NO STATIC JOB | 4 | 4 | 2 | 0.06 | -232 | -116.0 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| NO RALLY LEFT | 2 | 2 | 2 | 0.06 | +28 | +14.0 |
| STANDS TO CAST | 2 | 2 | 2 | 0.06 | -33 | -16.6 |
| BLOCKED CHARGE HANDED OVER | 1 | 1 | 1 | 0.03 | +118 | +118.5 |
| BOMBING RUN | 1 | 1 | 1 | 0.03 | +6 | +5.5 |
| FIRE AND FLEE | 1 | 1 | 1 | 0.03 | +12 | +12.5 |
| FOCUS FIRE | 1 | 1 | 1 | 0.03 | +13 | +13.0 |
| JOINT CHARGE PLAN | 7 | 7 | 1 | 0.03 | +17 | +17.0 |
| REDIRECT BY WHAT IT STOPS | 24 | 24 | 1 | 0.03 | +6 | +5.7 |
| SCREEN BY WHAT IT SAVES | 11 | 11 | 1 | 0.03 | +24 | +24.4 |
| STOPS | 6 | 6 | 1 | 0.03 | +11 | +11.1 |
| SUPPORT JOB KEPT | 1 | 1 | 1 | 0.03 | +87 | +87.1 |
| WAR ENGINE CHARGES | 1 | 1 | 1 | 0.03 | +9 | +9.0 |
| ALREADY CARRIED | 1 | not checked | - | - | - | - |
| CANNON PLAN MISSED | 1 | 1 | 0 | 0.00 | - | - |
| CARRIES OUT COUNTER | 8 | 8 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 40 | trace | - | - | - | - |
| CATCH FLIERS | 1 | not checked | - | - | - | - |
| CHARIOT WIZARD CAREFUL | 8 | 8 | 0 | 0.00 | - | - |
| CHEAP HELPER | 9 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 36 | not checked | - | - | - | - |
| EDGE GIVE GROUND | 7 | 7 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT LIFT | 6 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 375 | not checked | - | - | - | - |
| GIVES UP | 7 | 6 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 3 | 3 | 0 | 0.00 | - | - |
| GROUND FLIERS | 3 | not checked | - | - | - | - |
| HELPER ALREADY ASKED | 4 | not checked | - | - | - | - |
| HELPER UNSEEN | 21 | 21 | 0 | 0.00 | - | - |
| HILL BY ITS CHANCE | 33 | 33 | 0 | 0.00 | - | - |
| HUNT DROPPED | 6 | trace | - | - | - | - |
| HUNT KEPT | 5 | trace | - | - | - | - |
| HUNT RESULT | 10 | trace | - | - | - | - |
| HUNT THE GUNS | 11 | trace | - | - | - | - |
| KEEPS ITS PREY | 3 | 3 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 13 | not checked | - | - | - | - |
| LURE BY WHAT IT DRAWS | 3 | 3 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 4 | trace | - | - | - | - |
| MARCH OVER CASTS | 18 | 18 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 13 | 13 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 14 | 4 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 19 | trace | - | - | - | - |
| MOVE SPELL SPOT | 19 | not checked | - | - | - | - |
| NOT NEEDED | 33 | 33 | 0 | 0.00 | - | - |
| NOT TURNED | 389 | 389 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 41 | not checked | - | - | - | - |
| OPENS A LANE | 5 | 3 | 0 | 0.00 | - | - |
| PLAN RESULT | 2761 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 20 | 20 | 0 | 0.00 | - | - |
| SCOUT SPOT | 19 | 19 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 20 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 22 | not checked | - | - | - | - |
| SET-UP MISSED | 4 | trace | - | - | - | - |
| SHOT OPTIONS | 878 | 878 | 0 | 0.00 | - | - |
| SPELL CATCH ODDS | 1 | not checked | - | - | - | - |
| SPELL SETS UP CHARGE | 26 | not checked | - | - | - | - |
| SPELL WORTH | 135 | not checked | - | - | - | - |
| STABLE ROLE | 732 | 729 | 0 | 0.00 | - | - |
| TURN WORTH | 43 | 42 | 0 | 0.00 | - | - |
| TWO OR MORE ARRIVE | 21 | 18 | 0 | 0.00 | - | - |

### Off best figure: sp-h2h-mine-89601ea-p4

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 12.92 | 12.00 | 48.8 |
| FALLBACK | gate | 0.56 | 1.17 | 39.9 |
| CHARGE NOW FIRST | rule | 0.67 | 1.00 | 67.1 |
| TURN GATE | gate | 0.64 | 0.44 | 29.9 |
| PIVOT GUARDS FLANK | rule | 0.31 | 0.14 | 21.4 |
| AFTERMATH BAND | gate | 0.25 | 0.14 | 2.7 |
| KEEPS THE TARGET | rule | 0.31 | - | 121.7 |
| WAR ENGINE JOBS | rule | 0.28 | - | 32.2 |
| SUPPORT NARROWED | rule | 0.14 | 0.11 | 13.2 |
| BIG CHARACTER SAFETY | rule | 0.08 | 0.14 | 5.4 |
| SUPPORT REQUEST | gate | 0.11 | 0.11 | 89.2 |
| BEST PRIZE | rule | 0.03 | 0.14 | 165.9 |
| CHARGE NOW WEIGHED | rule | 0.03 | 0.14 | 32.4 |
| PATHS CROSS | rule | 0.03 | 0.14 | 30.2 |
| FIRE PLAN | rule | 0.14 | - | 246.0 |
| PURSUES BIG PREY | rule | 0.08 | 0.06 | 104.1 |
| STOPS SHORT OF THE FLANK | rule | 0.08 | 0.06 | 5.9 |
| DEFENSIVE ARMY | rule | 0.08 | 0.03 | 20.6 |
| FIGHT ORDER BAND | gate | 0.03 | 0.08 | 3.0 |
| LONE CHARACTER SAFE SPOT | gate | 0.06 | 0.06 | 29.3 |
| LONE WIZARD HOLDS BACK | rule | 0.03 | 0.06 | 66.0 |
| REDIRECT WEIGHED | rule | - | 0.08 | 123.7 |
| SURE CHARGE BEATS ADVANCE | rule | 0.08 | - | 29.3 |
| WHO HITS BACK | rule | 0.08 | - | 3.1 |
| WOUNDED STAYS OUT | rule | 0.03 | 0.06 | 45.4 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.03 | 0.03 | 36.6 |
| CARRIES OUT SET-UP | rule | - | 0.06 | 298.1 |
| CHARIOT NO STATIC JOB | rule | 0.06 | - | 116.0 |
| NO REASON | gate | 0.06 | - | 43.4 |
| SAFER THAN THE JOB | rule | - | 0.06 | 5.8 |
| STANDS TO CAST | rule | 0.06 | - | 16.6 |
| BLOCKED WHEEL | rule | - | 0.03 | 49.3 |
| FACES THE THREAT | rule | - | 0.03 | 2.5 |
| FALLBACK BY WORTH | rule | 0.03 | - | 31.7 |
| FRIENDS SHOTS CHECKED | rule | - | 0.03 | 3.2 |
| LONG SHOT | rule | 0.03 | - | 3.2 |
| MARCH ODDS | rule | - | 0.03 | 13.8 |
| MOVE AND CAST | rule | - | 0.03 | 3.3 |
| RULE SWITCHED OFF | gate | - | 0.03 | 6.5 |

### Plans: sp-h2h-mine-89601ea-p4

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 11.8 | 17% | 394 | 303 | 77% |
| Mine | charge | 3.9 | 58% | 296 | 352 | 119% |
| Mine | close in | 4.1 | 29% | 237 | 151 | 64% |
| Mine | hold | 4.1 | 21% | 272 | 0 | 0% |
| Mine | join | 0.5 | 89% | 8 | 0 | 0% |
| Mine | shoot | 9.8 | 58% | 699 | 597 | 85% |
| Mine | support | 3.8 | 90% | 43 | 0 | 0% |
| Opponent | advance | 13.2 | 18% | 279 | 334 | 120% |
| Opponent | charge | 5.0 | 57% | 516 | 428 | 83% |
| Opponent | close in | 6.3 | 27% | 538 | 201 | 37% |
| Opponent | hold | 4.4 | 30% | 312 | 0 | 0% |
| Opponent | join | 0.6 | 95% | 22 | 0 | 0% |
| Opponent | shoot | 3.2 | 56% | 60 | 184 | 308% |
| Opponent | support | 6.1 | 86% | 37 | 0 | 0% |

### Packages: hunt the guns, sp-h2h-mine-89601ea-p4

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.1 | 2 | 0 | 0% | 0% | 0% | - | 353 | 0 | 0% | 24 |
| Opponent | 0.2 | 9 | 1 | 25% | 38% | 0% | 2.0 | 372 | 109 | 38% | 80 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 117 |
| Empire of Man | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 490 | 0 | 0% | 107 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| High Elf Realms | 0.1 | 1 | 0 | 100% | 100% | 0% | 2.0 | 135 | 118 | 100% | 105 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 58 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 266 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 53 |
| Tomb Kings of Khemri | 0.5 | 2 | 0 | 0% | 0% | 0% | - | 337 | 0 | 0% | 0 |
| Vampire Counts | 0.6 | 5 | 1 | 0% | 0% | 0% | - | 385 | 0 | 0% | 36 |
| Warriors of Chaos | 0.1 | 1 | 0 | 0% | 100% | 0% | 2.0 | 223 | 174 | 100% | 0 |
| Wood Elf Realms | 0.2 | 1 | 0 | 100% | 100% | 0% | 2.0 | 621 | 580 | 100% | 36 |

### Battle groups: sp-h2h-mine-89601ea-p4

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 8.9 | 27% | 45% | 15% | 38% | 36% | 7% | 14% | 43% | 0% |
| Mine | REDIRECT COUNTER | 2.4 | 36% | 52% | 13% | 25% | 33% | 0% | 11% | 56% | 0% |
| Opponent | COUNTER-CHARGE COVER | 6.5 | 20% | 74% | 21% | 40% | 35% | 5% | 22% | 38% | 0% |
| Opponent | REDIRECT COUNTER | 3.9 | 34% | 64% | 13% | 17% | 37% | 0% | 7% | 46% | 10% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: sp-h2h-mine-89601ea-p4

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 4 | 0 (4) | 0 | 0 | 62 | 0% | 3.0 | - | 0 (1) | - | - | 0 (1) |
| Mine | Chaff | 34 | 30 (34) | 21 | 9 | 67 | 32% | 2.9 | 21 (14) | 25 (5) | 39 (15) | 33 (20) | 24 (14) |
| Mine | Character | 106 | 49 (106) | 49 | 0 | 36 | 17% | 2.5 | 48 (31) | 56 (51) | 73 (9) | 41 (43) | 65 (48) |
| Mine | Clean-up | 23 | 92 (23) | 51 | 41 | 47 | 22% | 2.8 | 0 (2) | 97 (17) | 119 (4) | 118 (11) | 75 (12) |
| Mine | Early | 1 | 140 (1) | 140 | 0 | 0 | 0% | 5.0 | - | 140 (1) | - | - | 140 (1) |
| Mine | Fast | 4 | 0 (4) | 0 | 0 | 73 | 50% | 1.5 | 0 (2) | 0 (2) | - | 0 (3) | 0 (1) |
| Mine | Fast Hammer | 40 | 40 (40) | 30 | 9 | 45 | 18% | 2.5 | 37 (25) | 60 (9) | 18 (6) | 55 (25) | 14 (15) |
| Mine | Fragile | 4 | 88 (4) | 88 | 0 | 54 | 50% | 2.5 | 323 (1) | 0 (3) | - | 0 (1) | 120 (3) |
| Mine | Hammer | 64 | 44 (64) | 34 | 10 | 59 | 17% | 2.5 | 25 (13) | 53 (42) | 31 (9) | 31 (39) | 60 (25) |
| Mine | Holder | 31 | 67 (31) | 7 | 60 | 38 | 29% | 3.0 | 50 (7) | 96 (17) | 12 (7) | 74 (20) | 56 (11) |
| Mine | Shooter | 35 | 75 (35) | 35 | 39 | 26 | 0% | 1.7 | 38 (8) | 103 (22) | 22 (5) | 75 (26) | 72 (9) |
| Mine | Support | 1 | 0 (1) | 0 | 0 | 0 | 0% | 3.0 | - | - | 0 (1) | - | 0 (1) |
| Mine | War machine | 56 | 42 (56) | 42 | 0 | 36 | 2% | 1.3 | 72 (16) | 19 (30) | 51 (10) | 52 (9) | 40 (47) |
| Mine | Wizard | 17 | 0 (17) | 0 | 0 | 40 | 6% | 2.4 | 0 (5) | 0 (6) | 0 (1) | 0 (5) | 0 (7) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Chaff | 77 | 36 (77) | 15 | 21 | 63 | 39% | 2.7 | 41 (32) | 28 (18) | 37 (27) | 37 (58) | 31 (19) |
| Opponent | Character | 97 | 64 (97) | 64 | 0 | 35 | 27% | 2.2 | 79 (45) | 56 (40) | 48 (6) | 63 (52) | 70 (39) |
| Opponent | Clean-up | 12 | 38 (12) | 10 | 27 | 59 | 17% | 2.4 | 21 (4) | 25 (5) | 75 (3) | 11 (7) | 56 (5) |
| Opponent | Fast | 1 | 142 (1) | 142 | 0 | 0 | 0% | 4.0 | - | 142 (1) | - | 142 (1) | - |
| Opponent | Fast Hammer | 54 | 39 (54) | 23 | 16 | 45 | 33% | 2.6 | 28 (23) | 53 (23) | 38 (8) | 33 (33) | 47 (21) |
| Opponent | Fragile | 17 | 0 (17) | 0 | 0 | 61 | 24% | 1.8 | 0 (5) | 0 (8) | 0 (4) | 0 (13) | 0 (4) |
| Opponent | Hammer | 65 | 28 (65) | 15 | 13 | 44 | 40% | 2.9 | 22 (20) | 31 (38) | 16 (7) | 27 (41) | 28 (24) |
| Opponent | Holder | 30 | 21 (30) | 3 | 18 | 32 | 50% | 4.1 | 0 (10) | 26 (13) | 40 (7) | 30 (18) | 8 (12) |
| Opponent | Shooter | 34 | 77 (34) | 12 | 65 | 45 | 0% | 1.5 | 32 (10) | 102 (21) | 55 (3) | 76 (19) | 77 (15) |
| Opponent | Support | 6 | 41 (6) | 41 | 0 | 67 | 67% | 6.0 | 0 (1) | 114 (2) | - | - | 80 (3) |
| Opponent | War machine | 6 | 131 (6) | 131 | 0 | 40 | 0% | 1.0 | 91 (3) | 187 (3) | - | 91 (3) | 187 (3) |
| Opponent | Wizard | 20 | 6 (20) | 6 | 0 | 20 | 20% | 2.1 | 9 (11) | 0 (2) | 7 (3) | 9 (11) | 0 (5) |

### Charged fights: sp-h2h-mine-89601ea-p4

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 299 | 275 | 3.0 | 1.2 | 92 | 30 | +62 | 4 of 12 | 6 of 12 | +173 | +52 |
| Mine | Chaos Dwarfs | 4 | 29 | 191 | 2.2 | 1.1 | 85 | 14 | +71 | 4 of 9 | 6 of 9 | +0 | +80 |
| Mine | Dwarfen Mountain Holds | 3 | 267 | 150 | 2.0 | 1.2 | 75 | 19 | +56 | 4 of 6 | 2 of 5 | +0 | +67 |
| Mine | Empire of Man | 5 | 475 | 83 | 1.2 | 1.7 | 70 | 40 | +30 | 1 of 6 | 6 of 6 | +128 | -19 |
| Mine | Grand Cathay | 4 | 477 | 342 | 4.2 | 1.2 | 81 | 52 | +29 | 4 of 17 | 14 of 17 | -107 | +70 |
| Mine | High Elf Realms | 4 | 377 | 573 | 3.8 | 1.1 | 153 | 0 | +153 | 3 of 15 | 14 of 15 | +70 | +159 |
| Mine | Kingdom of Bretonnia | 1 | 106 | 1197 | 7.0 | 1.1 | 171 | 0 | +171 | 4 of 7 | 5 of 7 | +540 | +110 |
| Mine | Lizardmen | 1 | 55 | 235 | 5.0 | 1.2 | 47 | 0 | +47 | 2 of 5 | 5 of 5 | +0 | +59 |
| Mine | Ogre Kingdoms | 2 | 0 | 832 | 4.0 | 1.1 | 208 | 38 | +170 | 4 of 8 | 7 of 8 | +350 | +145 |
| Mine | Skaven | 2 | 238 | 0 | 3.5 | 1.0 | 0 | 5 | -5 | 1 of 7 | 2 of 7 | - | -5 |
| Mine | Tomb Kings of Khemri | 2 | 38 | 326 | 2.0 | 1.2 | 163 | 0 | +163 | 0 of 4 | 3 of 4 | +286 | +122 |
| Mine | Vampire Counts | 2 | 95 | 94 | 3.0 | 1.2 | 31 | 77 | -46 | 2 of 6 | 4 of 6 | -5 | -54 |
| Mine | Warriors of Chaos | 2 | 0 | 803 | 4.0 | 1.1 | 201 | 0 | +201 | 3 of 8 | 7 of 8 | +0 | +229 |
| **Mine** | all armies | 36 | 245 | 331 | 3.1 | 1.2 | 108 | 23 | +86 | 36 of 110 | 81 of 109 | +78 | +87 |
| Opponent | Empire of Man | 1 | 575 | 186 | 1.0 | 1.0 | 186 | 0 | +186 | 1 of 1 | 1 of 1 | - | +186 |
| Opponent | High Elf Realms | 5 | 184 | 750 | 5.0 | 1.0 | 150 | 49 | +101 | 16 of 25 | 17 of 25 | +0 | +105 |
| Opponent | Lizardmen | 2 | 0 | 660 | 4.0 | 1.0 | 165 | 18 | +147 | 5 of 8 | 5 of 8 | - | +147 |
| Opponent | Orc & Goblin Tribes | 3 | 0 | 426 | 2.7 | 1.0 | 160 | 0 | +160 | 1 of 8 | 8 of 8 | - | +160 |
| Opponent | Skaven | 4 | 142 | 173 | 1.8 | 1.0 | 99 | 9 | +90 | 6 of 7 | 4 of 7 | - | +90 |
| Opponent | Tomb Kings of Khemri | 2 | 426 | 292 | 4.0 | 1.2 | 73 | 24 | +49 | 2 of 8 | 5 of 8 | +0 | +65 |
| Opponent | Vampire Counts | 6 | 28 | 514 | 5.7 | 1.1 | 91 | 42 | +49 | 13 of 34 | 21 of 33 | +238 | +23 |
| Opponent | Warriors of Chaos | 7 | 19 | 441 | 3.3 | 1.0 | 134 | 33 | +102 | 11 of 23 | 16 of 23 | +310 | +92 |
| Opponent | Wood Elf Realms | 6 | 13 | 414 | 4.2 | 1.2 | 99 | 52 | +47 | 10 of 25 | 18 of 25 | +60 | +44 |
| **Opponent** | all armies | 36 | 92 | 457 | 3.9 | 1.1 | 118 | 37 | +82 | 65 of 139 | 95 of 138 | +120 | +78 |

### Effective charges: sp-h2h-mine-89601ea-p4

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 12 | 2 (net +165) | 0 | 3 (net +0) | 2 (net +76) | 0 | 3 (net +90) | 2 | 30% (3 of 10) |
| Mine | Chaos Dwarfs | 9 | 1 (net +0) | 0 | 2 (net +155) | 0 | 0 | 3 (net -41) | 3 | 33% (2 of 6) |
| Mine | Dwarfen Mountain Holds | 6 | 1 (net +0) | 0 | 0 | 0 | 0 | 4 (net +84) | 1 | 0% (0 of 5) |
| Mine | Empire of Man | 6 | 0 | 0 | 0 | 1 (net +85) | 1 (net +170) | 3 (net +54) | 1 | 0% (0 of 5) |
| Mine | Grand Cathay | 17 | 1 (net +0) | 0 | 3 (net -115) | 5 (net +97) | 2 (net +8) | 5 (net +66) | 1 | 19% (3 of 16) |
| Mine | High Elf Realms | 15 | 0 | 0 | 2 (net +118) | 4 (net +178) | 2 (net +35) | 7 (net +182) | 0 | 13% (2 of 15) |
| Mine | Kingdom of Bretonnia | 7 | 1 (net +210) | 0 | 0 | 0 | 0 | 5 (net +155) | 1 | 0% (0 of 6) |
| Mine | Lizardmen | 5 | 1 (net +0) | 0 | 0 | 2 (net +118) | 1 (net +0) | 0 | 1 | 0% (0 of 4) |
| Mine | Ogre Kingdoms | 8 | 1 (net -145) | 0 | 2 (net +238) | 0 | 1 (net +110) | 3 (net +307) | 1 | 29% (2 of 7) |
| Mine | Skaven | 7 | 0 | 0 | 3 (net -12) | 1 (net +0) | 0 | 3 (net +0) | 0 | 43% (3 of 7) |
| Mine | Tomb Kings of Khemri | 4 | 1 (net +0) | 0 | 1 (net +286) | 1 (net +116) | 1 (net +250) | 0 | 0 | 25% (1 of 4) |
| Mine | Vampire Counts | 6 | 1 (net -40) | 0 | 1 (net +0) | 1 (net +97) | 2 (net -2) | 0 | 1 | 20% (1 of 5) |
| Mine | Warriors of Chaos | 8 | 2 (net +54) | 0 | 0 | 2 (net +142) | 2 (net +58) | 1 (net +599) | 1 | 0% (0 of 7) |
| Opponent | Empire of Man | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +186) | 0 | 0% (0 of 1) |
| Opponent | High Elf Realms | 25 | 4 (net -99) | 1 (net +85) | 2 (net -126) | 6 (net +264) | 3 (net +0) | 7 (net +171) | 2 | 9% (2 of 23) |
| Opponent | Lizardmen | 8 | 1 (net +0) | 0 | 2 (net +530) | 1 (net +120) | 0 | 1 (net +0) | 3 | 40% (2 of 5) |
| Opponent | Orc & Goblin Tribes | 8 | 0 | 0 | 0 | 0 | 1 (net +83) | 1 (net +40) | 6 | 0% (0 of 2) |
| Opponent | Skaven | 7 | 1 (net +185) | 0 | 1 (net +80) | 1 (net -65) | 0 | 4 (net +107) | 0 | 14% (1 of 7) |
| Opponent | Tomb Kings of Khemri | 8 | 1 (net -66) | 0 | 0 | 3 (net +67) | 0 | 1 (net +0) | 3 | 0% (0 of 5) |
| Opponent | Vampire Counts | 34 | 9 (net -30) | 1 (net +0) | 6 (net +126) | 3 (net +65) | 6 (net +123) | 9 (net +26) | 0 | 18% (6 of 34) |
| Opponent | Warriors of Chaos | 23 | 3 (net +41) | 0 | 2 (net +55) | 3 (net +42) | 1 (net +77) | 7 (net +218) | 7 | 12% (2 of 16) |
| Opponent | Wood Elf Realms | 25 | 3 (net -28) | 1 (net +0) | 6 (net +2) | 2 (net +18) | 2 (net +94) | 10 (net +102) | 1 | 25% (6 of 24) |

### Charged fights, damage counted: sp-h2h-mine-89601ea-p4

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 12 | 213 | 298 | +38 | 123 | 78 | +45 | +21.3 |
| Mine | Effective (55-75%) | 17 | 248 | 193 | +55 | 99 | 48 | +51 | +20.5 |
| Mine | 76-89% | 19 | 354 | 181 | +114 | 133 | 51 | +83 | +23.4 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 37 | 223 | 191 | +123 | 143 | 30 | +113 | +50.8 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 12 | 403 | 84 | +60 | 100 | 19 | +81 | +20.1 |
| Mine | No odds | 13 | 284 | 246 | +45 | 107 | 65 | +42 | +14.7 |
| Mine | All fights | 110 | 275 | 196 | +86 | 123 | 44 | +79 | +28.7 |
| Opponent | Long shot (under 50%) | 22 | 231 | 216 | -23 | 70 | 94 | -24 | -10.3 |
| Opponent | 50-54% | 3 | 103 | 97 | +28 | 28 | 0 | +28 | +27.4 |
| Opponent | Effective (55-75%) | 19 | 244 | 222 | +93 | 186 | 74 | +112 | +45.9 |
| Opponent | 76-89% | 19 | 348 | 231 | +115 | 131 | 32 | +99 | +28.6 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 41 | 331 | 235 | +113 | 164 | 52 | +112 | +34.0 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 13 | 455 | 101 | +84 | 98 | 38 | +60 | +13.2 |
| Opponent | No odds | 22 | 313 | 192 | +96 | 121 | 32 | +89 | +28.4 |
| Opponent | All fights | 139 | 309 | 208 | +82 | 132 | 53 | +79 | +25.4 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| sp-h2h-mine-89601ea-p4 | move | 431 | 98 (23%) | 70 (16%) | 62 (14%) | 271 (63%) |
| sp-h2h-mine-89601ea-p4 | objective | 374 | 53 (14%) | 37 (10%) | 54 (14%) | 267 (71%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0114, L0130, L2527, L2634 |
| Charmed Shield | Opponent | L0434, L0624, L0926, L1034, L1126, L1427, L2227, L2527, L2634, L3234 |
| Clockwork Compass | Mine | L1220 |
| Elixir of Power | Mine | L1126 |
| Elixir of Power | Opponent | L0819, L1719, L1819 |
| Fistful of Laurels | Mine | L1819, L1835 |
| Invocation of Nehek | Mine | L2527 |
| Invocation of Nehek | Opponent | L0624, L1427, L2227, L2527 |
| Opal Amulet | Mine | L1427 |
| Opal Amulet | Opponent | L0114, L0214, L1314 |
| Periapt of Soul Exchange | Mine | L2021, L2123 |
| Periapt of Soul Exchange | Opponent | L0520, L1220, L1621, L2021 |
| Ring of Doom | Mine | L0214, L0230, L1126, L1220, L1523 |
| Ring of Doom | Opponent | L0315, L1331, L2331 |
| Ring of Jet | Mine | L1017, L1034, L1126, L1220 |
| Standard of the Fell Warrior | Mine | L1314, L1331 |
| Standard of the Fell Warrior | Opponent | L0713 |
| Storm Daemon (Renegade 2.0) | Mine | L2123 |
| Storm Daemon (Renegade 2.0) | Opponent | L1621, L2021 |
| Twice-Blessed Armour | Mine | L0713, L0729, L1017, L1034 |
| Witch Hunter's Ward | Mine | L0713, L0729, L0819, L0835 |
| Witch Hunter's Ward | Opponent | L0608 |

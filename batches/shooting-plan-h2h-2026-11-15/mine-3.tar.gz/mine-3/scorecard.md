# Doctrine scorecard: sp-h2h-mine-89601ea-p3

### Scorecard: sp-h2h-mine-89601ea-p3

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0110 | 2 | 1 | Mine | - | - | 3 | 0 | 2 | 0 | 0 | 0 | 0 |
| L0110 | 2 | 1 | Opponent | - | - | 2 | 3 | 1 | 0 | 0 | 0 | 330 |
| L0126 | 6 | 1 | Mine | no | 7 | - | 0 | 0 | 1 | 0 | 0 | 387 |
| L0126 | 6 | 1 | Opponent | no | 8 | 2 | 6 | 1 | 0 | 0 | 0 | 0 |
| L0210 | 6 | 1 | Mine | no | 1 | - | 0 | 5 | 1 | 0 | 0 | 0 |
| L0210 | 6 | 1 | Opponent | no | 10 | 2 | 1 | 0 | 0 | 0 | 0 | 330 |
| L0226 | 4 | 1 | Mine | no | 1 | 3 | 1 | 0 | 1 | 0 | 0 | 523 |
| L0226 | 4 | 1 | Opponent | no | 0 | 2 | 2 | 0 | 0 | 0 | 0 | 0 |
| L0311 | 5 | 1 | Mine | no | - | 3 | 3 | 1 | 0 | 0 | 0 | 590 |
| L0311 | 5 | 1 | Opponent | no | - | 3 | 2 | 0 | 1 | 0 | 0 | 427 |
| L0327 | 3 | 1 | Mine | no | 3 | 3 | 4 | 1 | 0 | 0 | 0 | 530 |
| L0327 | 3 | 1 | Opponent | no | 8 | 2 | 3 | 3 | 0 | 0 | 0 | 0 |
| L0413 | 5 | 1 | Mine | yes | - | 2 | 6 | 0 | 0 | 0 | 0 | 0 |
| L0413 | 5 | 1 | Opponent | yes | - | 2 | 2 | 0 | 1 | 0 | 0 | 317 |
| L0429 | 3 | 1 | Mine | yes | 5 | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L0429 | 3 | 1 | Opponent | no | 8 | 2 | 1 | 1 | 1 | 0 | 0 | 375 |
| L0516 | 6 | 1 | Mine | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 1019 |
| L0516 | 6 | 1 | Opponent | no | 0 | 2 | 2 | 2 | 2 | 0 | 0 | 200 |
| L0533 | 5 | 1 | Mine | yes | - | - | 0 | 1 | 0 | 0 | 0 | 1193 |
| L0533 | 5 | 1 | Opponent | yes | - | 2 | 2 | 4 | 0 | 0 | 0 | 0 |
| L0620 | 2 | 1 | Mine | - | - | 4 | 1 | 0 | 0 | 0 | 0 | 929 |
| L0620 | 2 | 1 | Opponent | - | - | 3 | 2 | 1 | 1 | 0 | 0 | 210 |
| L0709 | 1 | 1 | Mine | yes | 1 | 2 | 3 | 1 | 1 | 0 | 0 | 420 |
| L0709 | 1 | 1 | Opponent | no | 0 | 2 | 1 | 2 | 0 | 0 | 0 | 524 |
| L0725 | 5 | 1 | Mine | no | - | 4 | 1 | 2 | 0 | 0 | 0 | 375 |
| L0725 | 5 | 1 | Opponent | yes | - | 2 | 5 | 4 | 0 | 0 | 0 | 0 |
| L0815 | 5 | 1 | Mine | no | - | - | 0 | 1 | 0 | 0 | 0 | 515 |
| L0815 | 5 | 1 | Opponent | yes | - | 2 | 2 | 2 | 1 | 0 | 0 | 115 |
| L0831 | 3 | 1 | Mine | no | 0 | - | 1 | 0 | 0 | 0 | 0 | 762 |
| L0831 | 3 | 1 | Opponent | no | 4 | - | 0 | 2 | 2 | 0 | 0 | 340 |
| L0922 | 4 | 1 | Mine | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 479 |
| L0922 | 4 | 1 | Opponent | no | 0 | 3 | 4 | 2 | 1 | 0 | 0 | 0 |
| L1013 | 5 | 1 | Mine | yes | - | 3 | 4 | 1 | 0 | 0 | 0 | 330 |
| L1013 | 5 | 1 | Opponent | no | - | 1 | 1 | 1 | 1 | 0 | 0 | 630 |
| L1030 | 4 | 1 | Mine | no | 5 | 2 | 4 | 0 | 0 | 0 | 0 | 492 |
| L1030 | 4 | 1 | Opponent | no | 6 | 2 | 3 | 0 | 1 | 0 | 0 | 0 |
| L1122 | 6 | 1 | Mine | no | 4 | 3 | 2 | 0 | 1 | 0 | 0 | 427 |
| L1122 | 6 | 1 | Opponent | no | 0 | 2 | 4 | 0 | 0 | 0 | 0 | 0 |
| L1216 | 4 | 1 | Mine | no | 2 | 2 | 6 | 0 | 0 | 0 | 0 | 330 |
| L1216 | 4 | 1 | Opponent | no | 0 | 4 | 2 | 2 | 1 | 0 | 0 | 536 |
| L1232 | 2 | 1 | Mine | - | - | 5 | 1 | 0 | 1 | 0 | 0 | 330 |
| L1232 | 2 | 1 | Opponent | - | - | 2 | 4 | 3 | 1 | 0 | 0 | 170 |
| L1327 | 1 | 1 | Mine | no | 3 | 3 | 2 | 0 | 0 | 0 | 0 | 140 |
| L1327 | 1 | 1 | Opponent | no | 5 | 1 | 3 | 2 | 0 | 0 | 0 | 0 |
| L1422 | 6 | 1 | Mine | no | 4 | 3 | 3 | 1 | 0 | 0 | 0 | 177 |
| L1422 | 6 | 1 | Opponent | no | 0 | 2 | 3 | 2 | 0 | 0 | 0 | 242 |
| L1519 | 1 | 1 | Mine | no | 0 | 2 | 2 | 0 | 0 | 0 | 0 | 199 |
| L1519 | 1 | 1 | Opponent | no | 0 | 2 | 6 | 0 | 0 | 0 | 0 | 543 |
| L1535 | 5 | 1 | Mine | yes | - | 3 | 6 | 0 | 0 | 0 | 0 | 0 |
| L1535 | 5 | 1 | Opponent | no | - | 1 | 1 | 3 | 1 | 0 | 0 | 0 |
| L1633 | 1 | 1 | Mine | yes | 5 | 2 | 3 | 0 | 0 | 0 | 0 | 200 |
| L1633 | 1 | 1 | Opponent | no | 0 | 1 | 5 | 2 | 1 | 0 | 0 | 344 |
| L1731 | 3 | 1 | Mine | no | 6 | 3 | 1 | 0 | 1 | 0 | 0 | 0 |
| L1731 | 3 | 1 | Opponent | no | 0 | 2 | 4 | 0 | 5 | 0 | 0 | 170 |
| **Average** | | | Mine | 29% | 2.8 | 2.9 | 2.1 | 0.8 | 0.3 | 0.0 | 0.0 | 383.2 |
| **Average** | | | Opponent | 17% | 2.9 | 2.0 | 2.7 | 1.5 | 0.8 | 0.0 | 0.0 | 214.9 |

### KPIs: sp-h2h-mine-89601ea-p3

Rules off - Opponent only: STAY WORTH, BEST MOVE FOR SHOOTERS, FACE THE CAST, WIZARD FRONT RANK, FIRE PLAN, FIRE IN ORDER, KEEPS THE TARGET, MISSILES IN THE FIRE PLAN, THREAT AT FULL SIZE, SHOOTERS ARE THREATS, SHOOTERS TO THE PRIMARY.

Morten 2026-11-10; 27 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 35% (45 of 130) | 2% (3 of 128) | 19% (48 of 258) |
| Winner chose to follow up after the loser gave ground |  | 100% (35 of 35); on the table 100% | 96% (43 of 45); on the table 96% | 98% (78 of 80); on the table 98% |
| Winner chose to pursue after the loser fell back in good order |  | 100% (7 of 7); on the table 100% | 80% (4 of 5); on the table 80% | 92% (11 of 12); on the table 92% |
| Winner chose to pursue after the loser fled |  | 85% (17 of 20); on the table 90% | 77% (20 of 26); on the table 77% | 80% (37 of 46); on the table 83% |
| Winner chose to follow up or pursue (all three) |  | 95% (59 of 62); on the table 97% | 88% (67 of 76); on the table 88% | 91% (126 of 138); on the table 92% |
| Magic missiles tried each own turn | 50%+ | 30% (87 of 294) | 33% (60 of 180) | 31% (147 of 474) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 50% (87 of 175) | 49% (60 of 122) | 49% (147 of 297) |
|   fighting wizards (on a monster, chariot or monstrous mount) | 50%+ | 26% (41 of 156) | 30% (40 of 132) | 28% (81 of 288) |
|     round 1 |  | 12% (3 of 26) | 32% (7 of 22) | 21% (10 of 48) |
|     rounds 2+ |  | 29% (38 of 130) | 30% (33 of 110) | 30% (71 of 240) |
|   other wizards | 50%+ | 33% (46 of 138) | 42% (20 of 48) | 35% (66 of 186) |
|     round 1 |  | 43% (10 of 23) | 25% (2 of 8) | 39% (12 of 31) |
|     rounds 2+ |  | 31% (36 of 115) | 45% (18 of 40) | 35% (54 of 155) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 33% (3 of 9) | 51% (20 of 39) | 48% (23 of 48) |
| Points that never fought | lower | 36% (18807 of 52695) | 38% (20507 of 53992) | 37% (39314 of 106687) |
|   infantry points that never fought | lower | 38% (4367 of 11536) | 57% (6269 of 10980) | 47% (10636 of 22516) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 57% (122 of 215) | 62% (130 of 210) | 59% (252 of 425) |
| Bound items with a magic missile used (at least once a game) |  | 96% (22 of 23); 2.1 uses a game | 88% (15 of 17); 1.8 uses a game | 92% (37 of 40); 2.0 uses a game |
| Bound items with another spell used |  | 29% (4 of 14); 0.1 uses a game | 50% (3 of 6); 0.1 uses a game | 35% (7 of 20); 0.1 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 56% (10 of 18); 0.4 uses a game | 60% (6 of 10); 0.2 uses a game | 57% (16 of 28); 0.3 uses a game |
|   their share of the points of units over 100 pts | lower | 50% (22630 of 45320) | 54% (25868 of 47759) | 52% (48498 of 93079) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.1 (14%) | 0.9 (20%) | 2.0 (16%) |
| MARCHED: its unit marched | 1.9 (24%) | 1.1 (26%) | 3.0 (25%) |
| CHARGED: its unit charged | 0.2 (3%) | 0.1 (3%) | 0.4 (3%) |
| IN COMBAT: engaged in combat | 2.2 (29%) | 1.1 (26%) | 3.4 (28%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.1 (2%) | 0.1 (1%) |
| FLEEING: fleeing | 0.0 (0%) | 0.0 (1%) | 0.1 (1%) |
| GONE: slain | 1.6 (21%) | 0.7 (17%) | 2.4 (20%) |
| OFF THE TABLE: off the table or not arrived | 0.5 (7%) | 0.2 (5%) | 0.7 (6%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.4 | 1.1 | 2.3 | 5.4 | 0.6 | 2.4 |
| not cast | 3.6 | 1.6 | 4.8 | 12.1 | 2.9 | 19.4 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) | 0.0 (0%) | 1.0 (5%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.6 (40%) | 0.4 (9%) | 2.0 (16%) | 0.2 (8%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 3.0 (25%) | 0.7 (23%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.4 (3%) | 0.0 (1%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.3 (9%) | 0.2 (12%) | 0.8 (17%) | 3.4 (28%) | 0.7 (25%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.0 (0%) | 0.1 (2%) | 0.1 (1%) | 0.1 (4%) | 0.0 (0%) |
| FLEEING: fleeing | 0.2 (6%) | 0.1 (5%) | 0.1 (2%) | 0.1 (1%) | 0.0 (1%) | 0.4 (2%) |
| GONE: slain | 0.8 (22%) | 0.5 (33%) | 1.1 (23%) | 2.4 (20%) | 0.4 (13%) | 3.1 (16%) |
| OFF THE TABLE: off the table or not arrived | 0.3 (9%) | 0.1 (7%) | 0.9 (18%) | 0.7 (6%) | 0.4 (14%) | 1.6 (8%) |
| STUPIDITY: Stupidity | 0.1 (3%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (2%) | 0.0 (0%) | 0.1 (1%) | 0.3 (11%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.8 (51%) | 0.0 (2%) | 1.3 (27%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 13.3 (69%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.5 a game | 0.8 a game | 1.2 a game |
| stood (cast and not dispelled) | 67% (22 of 33) | 56% (9 of 16) | 63% (31 of 49) |
| the unit moved after it | 82% (18 of 22) | 89% (8 of 9) | 84% (26 of 31) |
| it charged on its next turn | 0% (0 of 22) | 11% (1 of 9) | 3% (1 of 31) |
| the enemy charged it first | 23% (5 of 22) | 11% (1 of 9) | 19% (6 of 31) |
| it fought by the end of its next turn | 5% (1 of 22) | 11% (1 of 9) | 6% (2 of 31) |
| it moved out of a charge the enemy had planned (not charged first) | 27% (6 of 22) | 33% (3 of 9) | 29% (9 of 31) |
| none of these (no charge, no fight, no charge escaped) | 50% (11 of 22) | 44% (4 of 9) | 48% (15 of 31) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 72% (486 of 672) | 59% (257 of 437) | 67% (743 of 1109) |
|   cavalry | 77% (37 of 48) | 56% (32 of 57) | 66% (69 of 105) |
|   character | 67% (56 of 84) | 25% (21 of 83) | 46% (77 of 167) |
|   chariot | 47% (36 of 77) | 70% (21 of 30) | 53% (57 of 107) |
|   infantry | 68% (114 of 167) | 62% (114 of 184) | 65% (228 of 351) |
|   monster | 50% (13 of 26) | 50% (1 of 2) | 50% (14 of 28) |
|   war machine | 85% (230 of 270) | 84% (68 of 81) | 85% (298 of 351) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.7 (24%) | 1.6 (24%) | 3.3 (24%) |
| CHARGED: it charged | 1.2 (18%) | 1.7 (26%) | 2.9 (22%) |
| FLEEING: it fled or was fleeing | 0.1 (1%) | 0.1 (2%) | 0.2 (1%) |
| IN COMBAT: it fought this turn or the last | 0.8 (11%) | 0.7 (10%) | 1.4 (11%) |
| MOVED: a war machine that moved | 0.1 (2%) | 0.0 (1%) | 0.2 (1%) |
| NO TARGET IN RANGE | 0.7 (11%) | 0.8 (12%) | 1.6 (11%) |
| ONLY IN COMBAT: the only targets were in combat | 0.4 (5%) | 0.3 (4%) | 0.6 (5%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.3 (19%) | 1.0 (15%) | 2.3 (17%) |
| SHELTERED: the target was sheltered | 0.3 (4%) | 0.2 (3%) | 0.4 (3%) |
| STUPIDITY | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) |
| OTHER BAR | 0.3 (4%) | 0.3 (4%) | 0.6 (4%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 4.0 | 1.1 | 79% | 7.3 pts | 29 pts |
| character | 3.5 | 0.7 | 87% | 4.3 pts | 15 pts |
| chariot | 2.1 | 0.3 | 89% | 4.5 pts | 10 pts |
| infantry | 12.5 | 4.8 | 74% | 8.9 pts | 111 pts |
| monster | 0.7 | 0.1 | 89% | 1.3 pts | 1 pts |
| war machine | 11.6 | 11.4 | 59% | 28.9 pts | 334 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.7 | 6.1 | 4.9 |
| Charges that made contact a game | 2.9 | 4.0 | 3.4 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.76 declared, 0.67 contact (21 units) | 0.89 declared, 0.74 contact (19 units) | 0.82 declared, 0.70 contact (40 units) |
|   per unit a game, units carrying another wizard (or one alone) | 1.33 declared, 1.33 contact (3 units) | 1.83 declared, 1.00 contact (6 units) | 1.67 declared, 1.11 contact (9 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.50 declared, 0.37 contact (160 units) | 0.69 declared, 0.45 contact (198 units) | 0.60 declared, 0.41 contact (358 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 55% (31 of 56) | 73% (8 of 11) | 43% (3 of 7) | 57% (42 of 74) |
| Character in a unit | 100% (24 of 24) | 86% (6 of 7) | 33% (1 of 3) | 91% (31 of 34) |
| Character on its own | 87% (27 of 31) | 48% (19 of 40) | 28% (14 of 50) | 50% (60 of 121) |
| Chariot | 100% (9 of 9) | 67% (8 of 12) | - | 81% (17 of 21) |
| Infantry | 63% (38 of 60) | 52% (16 of 31) | 25% (1 of 4) | 58% (55 of 95) |
| Monster | 43% (9 of 21) | 67% (2 of 3) | - | 46% (11 of 24) |
| Monstrous | 100% (5 of 5) | 67% (4 of 6) | - | 82% (9 of 11) |
| War Machines | 58% (25 of 43) | 100% (2 of 2) | - | 60% (27 of 45) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 93% (13 of 14); on the table 100% | 32% (31 of 96) | 27% | 73% (16 of 22) | 100% (6 of 6); 4.0 uses a game | 50% (1 of 2); 0.2 uses a game | 83% (5 of 6); 1.2 uses a game |
| Chaos Dwarfs | 4 | 90% (9 of 10); on the table 90% | 36% (13 of 36) | 33% | 59% (19 of 32) | 0.0 uses a game | 0.0 uses a game | 100% (2 of 2); 0.5 uses a game |
| Dwarfen Mountain Holds | 3 | 100% (2 of 2); on the table 100% | - | 53% | 79% (19 of 24) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 6 | 67% (4 of 6); on the table 67% | 47% (14 of 30) | 58% | 68% (40 of 59) | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game | 0% (0 of 4); 0.0 uses a game |
| Grand Cathay | 8 | 100% (11 of 11); on the table 100% | 30% (58 of 192) | 43% | 53% (39 of 74) | 89% (16 of 18); 6.0 uses a game | 25% (1 of 4); 0.1 uses a game | 50% (4 of 8); 0.5 uses a game |
| High Elf Realms | 7 | 95% (21 of 22); on the table 95% | 31% (13 of 42) | 32% | 48% (26 of 54) | 100% (9 of 9); 3.7 uses a game | 42% (5 of 12); 0.7 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 3 | 100% (8 of 8); on the table 100% | - | 29% | 33% (6 of 18) | 0.0 uses a game | 0.0 uses a game | 100% (3 of 3); 1.0 uses a game |
| Lizardmen | 1 | 100% (4 of 4); on the table 100% | 50% (3 of 6) | 0% | 29% (2 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 1 | 0% (0 of 1); on the table 0% | 0% (0 of 6) | 0% | 75% (6 of 8) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Skaven | 1 | 80% (4 of 5); on the table 80% | 50% (3 of 6) | 48% | 29% (2 of 7) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Tomb Kings of Khemri | 3 | 100% (8 of 8); on the table 100% | 17% (1 of 6) | 35% | 53% (8 of 15) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 5 | 93% (25 of 27); on the table 93% | 19% (7 of 36) | 29% | 43% (12 of 28) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 5 | 93% (14 of 15); on the table 93% | 25% (3 of 12) | 29% | 64% (29 of 45) | 100% (2 of 2); 1.8 uses a game | 0.0 uses a game | 100% (1 of 1); 0.2 uses a game |
| Wood Elf Realms | 3 | 60% (3 of 5); on the table 60% | 17% (1 of 6) | 48% | 88% (28 of 32) | 80% (4 of 5); 2.7 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (sp-h2h-mine-89601ea-p3, 27 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 38% (21) | 32% (15) | 35% (36) |
| ...free all their last turn and able to turn (per game) | 0.52 | 0.37 | 0.89 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.07 | 0.07 | 0.15 |
| ...with the charger already in that arc before they moved (per game) | 0.41 | 0.33 | 0.74 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 1.37 | 1.11 | 2.48 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 1.04 | 0.59 | 1.63 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 5.30 | 4.33 | 9.63 |

### Quality by phase: sp-h2h-mine-89601ea-p3

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.3 | 3.9 |
| Strategy | Charge objectives carried out (made contact) | 51% (50 of 98) | 41% (61 of 149) |
| Strategy | Shoot objectives carried out (shot that target) | 38% (144 of 378) | 51% (87 of 170) |
| Strategy | Close-in objectives charged next turn | 14% (17 of 123) | 15% (21 of 142) |
| Strategy | Support requests answered (helper made contact too) | 44% (4 of 9) | 29% (8 of 28) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (5 of 5) | - |
| Strategy | Hexes on a unit its side charged or shot that turn | 80% (4 of 5) | 57% (4 of 7) |
| Strategy | Joined characters whose unit fought | 41% (11 of 27) | 37% (10 of 27) |
| Strategy | Lone characters that fought | 80% (64 of 80) | 74% (55 of 74) |
| Movement | Charges halted short of contact | 0.1 | 0.1 |
| Movement | Idle units | 0.8 | 1.5 |
| Movement | Points that never moved of their own | 383.2 | 214.9 |
| Movement | Fights charged into per game | 2.4 | 3.4 |
| Movement | Charges with odds: long shots (under 50%) | 8 of 58, net -60 | 18 of 77, net +135 |
| Movement | Charges with odds: sweet spot (55-75%) | 5 of 58, net +20 | 10 of 77, net +65 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 7 of 58, net +104 | 6 of 77, net +3 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 23 of 58, net +129 | 20 of 77, net +106 |
| Shooting | Shots by shooting units (incl. breath weapons) | 10.1 | 8.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 33% (91 of 272) | 54% (120 of 223) |
| Shooting | Points destroyed by shooting units | 28.0 | 23.5 |
| Shooting | War machine shots | 8.5 | 3.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 45% (104 of 230) | 30% (25 of 82) |
| Shooting | Points destroyed by war machines | 148.0 | 42.6 |
| Magic | Magic missiles cast | 1.9 | 1.5 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 37% (19 of 52) | 32% (13 of 41) |
| Magic | Wounds caused by magic missiles | 3.8 | 1.9 |
| Magic | Wounds caused by other spells | 1.4 | 0.9 |
| Magic | Points destroyed by magic (all spells) | 112.7 | 46.5 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.2 / 0.2 / 0.8 / 0.1 | 1.8 / 0.3 / 0.5 / 0.3 |
| Combat | Points destroyed in combat | 314.1 | 375.4 |
| Combat | Points run down | 50.2 | 65.3 |
| Combat | Net points per charged fight, damage counted | +65 | +98 |
| Combat | Net per 100 charger points, damage counted | +20.0 | +31.3 |
| Combat | First round won (charged fights) | 72% | 66% |
| Combat | Net points per charged fight | +73 | +87 |
| Combat | Net points per supported fight / lone fight | +140 / +58 | +110 / +82 |
| Combat | Charged fights on a top-3 enemy unit | 21 of 65 | 47 of 92 |
| Game | Points lost | 779.3 | 799.6 |
| Game | VP from objectives | 546.7 | 553.7 |
| Game | Lone holders (player turns) | 2.8 | 2.9 |

- Mine won / drew / lost: 9 / 6 / 12 of 27 ended games (of 27); mean margin (Mine - Opponent) +12 VP
- The side that went first won 12 of 21 games with a winner
- Points traded per game (both sides' losses): 1579
- Games not ended: 0; findings 1, warnings 1

### Opponent rules: sp-h2h-mine-89601ea-p3

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.6 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 0.0 |
| ARRIVAL HUNT | - | - | - | - | 0.1 | +0.5 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 2.9 | +0.0 | 0.0 | 35.9 | 0.3 | +0.0 | 0.0 | 12.2 |
| BACKUP TARGETS | 0.9 | +8.7 | 0.0 | 41.6 | 0.8 | +14.7 | 0.0 | 29.4 |
| BEST FACING | 0.6 | +23.1 | 0.0 | 21.0 | 0.7 | +51.6 | 0.0 | 34.5 |
| BEST FIRST | 3.3 | +147.4 | 147.6 | 79.7 | 3.7 | +188.0 | 141.9 | 52.0 |
| BEST MOVE FOR SHOOTERS | 0.8 | +62.2 | 0.0 | 17.5 | - | - | - | - |
| BEST OVERALL | 0.6 | +58.4 | 0.0 | 39.7 | 0.6 | +35.6 | 0.0 | 42.9 |
| BEST PREY | 0.4 | +23.9 | 0.0 | 3.1 | 0.6 | +28.1 | 29.3 | 29.4 |
| BEST PRIZE | 0.1 | +1.3 | 3.9 | 18.3 | 0.1 | +14.7 | 14.0 | 0.0 |
| BIG CHARACTER SAFETY | 0.2 | -0.8 | 0.0 | 18.5 | 0.3 | -1.1 | 0.0 | 22.2 |
| BLOCKED CHARGE SKIPPED | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| BLOCKED WHEEL | 0.6 | +9.3 | 0.0 | 24.5 | 0.3 | +7.4 | 0.0 | 17.8 |
| BOMBING RUN | 0.0 | +1.0 | 0.0 | 5.6 | - | - | - | - |
| BOUND ASSAILMENT | - | - | - | - | 0.0 | +0.0 | 0.0 | 5.6 |
| CANNON PLAN MISSED | - | - | - | - | 0.3 | +0.0 | 32.9 | 6.1 |
| CANNON PLANNED TARGET | - | - | - | - | 1.8 | +111.9 | 110.5 | 15.0 |
| CANNON SIGHT KEPT | 1.7 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 3.7 |
| CARRIES OUT COUNTER | 0.1 | +0.0 | 0.0 | 7.0 | 0.1 | -4.5 | 16.4 | 0.0 |
| CARRIES OUT SET-UP | 0.2 | -7.9 | 32.9 | 13.7 | 0.1 | -0.6 | 10.4 | 6.0 |
| CAST JOB | 1.2 | +39.0 | 139.7 | 13.1 | 0.6 | +12.4 | 17.6 | 0.0 |
| CASTER AWAY FROM SCREEN | 0.2 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.4 | +39.2 | 0.0 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | 0.8 | +0.0 | 0.0 | 36.1 | 0.5 | +0.0 | 0.0 | 14.8 |
| CASTS FROM BEHIND | - | - | - | - | 0.2 | +0.0 | 0.0 | 0.0 |
| CATCH ODDS | 0.0 | +0.3 | 0.0 | 18.5 | - | - | - | - |
| CHAFF PASSED | - | - | - | - | 0.1 | -0.4 | 0.0 | 3.0 |
| CHARGE NOW FIRST | 2.1 | +0.0 | 257.2 | 52.9 | 3.3 | +0.0 | 290.7 | 105.8 |
| CHARGE NOW WEIGHED | 0.6 | -54.3 | 20.9 | 29.7 | 0.3 | -28.4 | 3.1 | 20.2 |
| CHARIOT NO STATIC JOB | 0.1 | +0.0 | 0.0 | 6.3 | - | - | - | - |
| CHARIOT WIZARD CAREFUL | - | - | - | - | 0.1 | -0.7 | 0.0 | 0.0 |
| CHEAP HELPER | 0.0 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 7.7 |
| COMBAT PIVOT | 0.4 | +0.0 | 19.4 | 26.0 | 0.2 | +0.0 | 0.0 | 6.3 |
| CONVEYANCE SEARCH | 1.0 | +76.3 | 43.0 | 50.0 | 0.5 | +33.6 | 30.6 | 30.5 |
| COUNTER-CHARGE COVER | 9.9 | +846.5 | 0.0 | 222.6 | 6.7 | +747.1 | 0.0 | 140.7 |
| DEFENSIVE ARMY | 0.1 | +0.0 | 3.0 | 0.0 | - | - | - | - |
| EDGE GIVE GROUND | 0.2 | +13.6 | 31.0 | 0.0 | 0.3 | +13.7 | 37.0 | 4.3 |
| ELIXIR WORTH | 0.0 | +1.9 | 0.0 | 0.0 | 0.0 | +3.0 | 0.0 | 11.0 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACE THE CAST | 0.1 | +3.4 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 1.4 | +113.1 | 0.0 | 58.4 | 1.1 | +69.6 | 0.0 | 57.3 |
| FALLBACK BY WORTH | 3.9 | +65.5 | 0.0 | 49.7 | 4.6 | +65.1 | 0.0 | 67.5 |
| FIGHT LIFT | 0.1 | +1.1 | 0.0 | 0.0 | 0.1 | +2.7 | 2.2 | 0.0 |
| FIRE AND FLEE | 0.0 | +0.6 | 3.9 | 3.0 | 0.0 | +0.8 | 4.3 | 0.0 |
| FIRE IN ORDER | 1.0 | +0.0 | 90.2 | 24.1 | - | - | - | - |
| FIRE PLAN | 19.3 | +742.3 | 1314.3 | 267.3 | - | - | - | - |
| FLANK NOT WEIGHED | 5.4 | +0.0 | 0.0 | 184.4 | 4.5 | +0.0 | 0.0 | 177.7 |
| FOLLOW UP WEIGHED | 0.7 | +112.8 | 0.0 | 42.4 | 1.3 | +249.3 | 0.0 | 56.1 |
| FRIENDS SHOTS CHECKED | 0.3 | +7.2 | 0.0 | 6.5 | 0.1 | +4.6 | 0.0 | 0.0 |
| GIVES UP | 0.1 | -0.4 | 5.5 | 0.0 | 0.1 | -3.5 | 6.0 | 0.0 |
| GIVES UP ITS SCREEN | - | - | - | - | 0.1 | -2.9 | 10.4 | 1.7 |
| HELPER ALREADY ASKED | - | - | - | - | 0.1 | +0.0 | 18.5 | 0.0 |
| HELPER UNSEEN | 0.2 | +0.0 | 3.7 | 0.0 | 0.4 | +0.0 | 16.0 | 8.8 |
| HILL BY ITS CHANCE | 0.4 | -40.0 | 0.0 | 0.0 | 0.4 | -69.2 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 0.3 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| HORN WORTH | - | - | - | - | 0.0 | +0.3 | 0.0 | 18.7 |
| HUNT ADVANCE | 0.2 | +11.0 | 0.0 | 1.9 | 0.2 | +4.4 | 0.0 | 6.5 |
| HUNT DROPPED | 0.1 | +0.0 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| HUNT IN PAIRS | 0.5 | +12.1 | 0.0 | 18.5 | 0.9 | +30.8 | 0.0 | 8.6 |
| HUNT KEPT | 0.1 | +1.8 | 0.0 | 0.0 | 0.1 | +0.9 | 0.0 | 1.7 |
| HUNT RESULT | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +14.6 | 0.0 | 10.4 |
| HUNT THE GUNS | 0.1 | +60.4 | 0.0 | 1.9 | 0.3 | +73.7 | 9.8 | 8.7 |
| INVITES THE FIGHT | 1.3 | +23.8 | 59.3 | 19.9 | 1.3 | +29.4 | 108.9 | 10.8 |
| JOINT CHARGE PLAN | 0.2 | +27.5 | 0.0 | 0.0 | 0.1 | +3.7 | 0.0 | 4.3 |
| KEEP FALLS | 0.1 | +5.7 | 0.0 | 0.0 | 0.0 | +0.1 | 0.0 | 0.0 |
| KEEPS ITS PREY | 0.0 | +0.1 | 0.0 | 0.0 | - | - | - | - |
| KEEPS ITS TARGET | 1.7 | +50.0 | 234.3 | 49.3 | 1.9 | +57.8 | 139.1 | 57.6 |
| KEEPS SCOUTS OR AMBUSH | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KEEPS THE TARGET | 1.9 | -68.1 | 193.5 | 35.5 | - | - | - | - |
| KILLS COUNT | 1.4 | +47.7 | 127.3 | 40.3 | 2.6 | +104.5 | 193.1 | 54.8 |
| KILLS COUNT NEXT TURN | 4.8 | +146.8 | 216.5 | 141.4 | 6.0 | +226.9 | 172.3 | 224.8 |
| LONE CHARACTER SAFE SPOT | 0.7 | +34.5 | 20.4 | 31.9 | 0.2 | +10.8 | 16.4 | 14.8 |
| LONE WIZARD HOLDS BACK | - | - | - | - | 0.2 | +0.0 | 5.3 | 7.0 |
| LONE WIZARD KEPT IN | 0.6 | +44.7 | 0.0 | 2.2 | 0.4 | +33.0 | 0.0 | 0.0 |
| LONG SHOT | 0.2 | -1.8 | 22.4 | 0.0 | 0.2 | -1.3 | 0.0 | 8.7 |
| LOST CHARGE | 3.0 | -51.7 | 183.9 | 89.4 | 2.6 | -49.8 | 54.5 | 78.3 |
| LURE BY WHAT IT DRAWS | - | - | - | - | 0.0 | -4.7 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 0.7 | +87.2 | 39.3 | 27.3 | 0.9 | +32.8 | 0.0 | 22.8 |
| MANOEUVRE | 0.3 | +8.9 | 0.0 | 8.4 | 0.1 | +4.8 | 0.0 | 15.4 |
| MARCH AT ESCAPER | 0.1 | +1.7 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| MARCH CHECK | 0.7 | +64.4 | 0.0 | 13.7 | 1.0 | +88.2 | 0.0 | 19.1 |
| MARCH ODDS | 0.2 | +7.4 | 5.1 | 34.6 | 0.4 | +21.0 | 17.6 | 0.0 |
| MARCH OVER CASTS | 0.8 | +91.3 | 0.0 | 34.6 | 0.6 | +40.5 | 0.0 | 4.3 |
| MAX FOR POSITIONING | 4.0 | +133.2 | 0.0 | 147.3 | 4.2 | +205.0 | 0.0 | 64.1 |
| MISSILES IN THE FIRE PLAN | 4.4 | +174.6 | 215.7 | 70.4 | - | - | - | - |
| MISSILES IN THE MOVE | 4.1 | +163.6 | 0.0 | 105.0 | 3.9 | +58.7 | 0.0 | 81.6 |
| MISSILES NEXT TURN | 5.5 | +120.2 | 0.0 | 153.3 | 5.1 | +54.5 | 0.0 | 109.3 |
| MODEL FACING | 0.1 | +46.1 | 0.0 | 2.2 | - | - | - | - |
| MONSTER WIZARD ROAMS | 0.4 | +0.0 | 62.6 | 13.7 | 0.1 | +0.0 | 0.0 | 0.0 |
| MOVE AND CAST | 0.5 | +46.2 | 0.0 | 13.1 | 0.3 | +8.9 | 0.0 | 0.0 |
| MOVE SPELL IN RANGE | 0.3 | +8.9 | 0.0 | 28.1 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.6 | -25.4 | 0.0 | 54.4 | 0.1 | -1.7 | 0.0 | 0.0 |
| MOVE SPELL SPOT | 0.6 | +0.0 | 0.0 | 18.5 | 0.3 | +0.0 | 0.0 | 14.8 |
| MOVE TO CHARGE | 3.2 | +212.5 | 195.9 | 109.0 | 4.4 | +349.8 | 55.2 | 135.3 |
| MOVES UNITS SPELL | 0.1 | +4.6 | 0.0 | 0.0 | 0.1 | +0.4 | 0.0 | 0.0 |
| NEEDED THERE | - | - | - | - | 0.1 | +23.9 | 10.3 | 0.0 |
| NO RALLY LEFT | 0.1 | +2.1 | 0.0 | 0.0 | - | - | - | - |
| NOT NEEDED | 0.4 | -23.1 | 65.0 | 0.0 | 0.4 | -27.2 | 42.9 | 3.1 |
| NOT TURNED | 5.3 | +125.2 | 0.0 | 143.3 | 4.3 | +29.6 | 0.0 | 96.4 |
| NOT WORTH A CAST | 0.3 | -0.2 | 0.0 | 28.1 | 0.4 | -0.1 | 0.0 | 0.0 |
| OFF BEST | 14.9 | -788.0 | 0.0 | 280.3 | 13.1 | -772.8 | 11.6 | 191.5 |
| OPENS A LANE | 0.2 | +0.3 | 10.4 | 0.0 | 0.3 | +2.1 | 13.5 | 0.0 |
| OPENS UP | 0.2 | +15.1 | 7.3 | 0.0 | 0.4 | +44.9 | 22.4 | 0.0 |
| OVERRUNS AWAY | 0.7 | +13.5 | 104.4 | 29.5 | 0.5 | +5.7 | 39.0 | 31.1 |
| PATHS CROSS | 1.4 | +106.6 | 0.0 | 44.3 | 2.5 | +208.8 | 0.0 | 38.2 |
| PERIAPT WORTH | - | - | - | - | 0.0 | +2.0 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | - | - | - | - | 0.0 | -0.5 | 0.0 | 0.0 |
| PLAN RESULT | 36.6 | +1529.4 | 1795.9 | 910.4 | 35.6 | +1273.4 | 1456.4 | 1124.3 |
| PURSUES BIG PREY | 0.1 | -4.2 | 0.0 | 0.0 | 0.1 | -8.0 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE | - | - | - | - | 0.0 | +6.5 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE NEXT TURN | 0.0 | +2.3 | 0.0 | 4.6 | 0.1 | +5.8 | 0.0 | 0.0 |
| RANDOM MOVE BY FIGURES | 0.3 | +1.1 | 0.0 | 0.0 | 1.4 | +34.1 | 0.0 | 45.6 |
| RANDOM MOVER NO PROMISE | 0.0 | -1.5 | 0.0 | 0.0 | 0.5 | -41.8 | 13.8 | 18.9 |
| REDIRECT BY WHAT IT STOPS | 0.0 | -0.4 | 0.0 | 0.0 | 0.2 | -7.8 | 0.0 | 7.0 |
| REDIRECT COUNTER | 1.5 | +128.6 | 0.0 | 39.3 | 2.7 | +298.1 | 0.0 | 45.3 |
| REDIRECT WEIGHED | 0.2 | +11.9 | 13.9 | 8.0 | 0.6 | +21.9 | 23.7 | 0.0 |
| RESERVE FALL BACK | 0.1 | +9.1 | 0.0 | 5.6 | 0.7 | +8.4 | 0.0 | 4.1 |
| RESTRAINS TO SHOOT | 0.1 | +4.3 | 0.0 | 8.9 | 0.1 | +0.8 | 0.0 | 5.2 |
| RISK BY ARC | 2.4 | +67.4 | 271.4 | 76.8 | 2.9 | +45.2 | 216.1 | 127.8 |
| SAFER THAN THE JOB | 1.0 | +85.8 | 0.0 | 20.8 | 0.6 | +22.6 | 0.0 | 34.8 |
| SCOUT SPOT | 0.3 | +0.5 | 0.0 | 0.0 | 0.3 | +1.1 | 0.0 | 2.7 |
| SCOUT WAITS | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 2.7 |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 0.1 | -10.8 | 0.0 | 2.4 |
| SEARCH SPOT | 2.3 | +111.1 | 0.0 | 53.3 | 2.4 | +164.2 | 0.0 | 54.1 |
| SECOND HUNTER | 0.0 | -1.7 | 0.0 | 0.0 | - | - | - | - |
| SELF MOVE SPELL | 0.4 | +65.9 | 0.0 | 0.0 | 0.2 | +87.7 | 0.0 | 0.0 |
| SET UP TOGETHER | 1.0 | +126.7 | 89.1 | 27.3 | 1.0 | +46.6 | 0.0 | 24.2 |
| SET-UP ANY TARGET | 0.6 | +111.1 | 43.0 | 46.5 | 0.3 | +22.5 | 23.6 | 23.5 |
| SET-UP MISSED | 0.0 | +8.0 | 0.0 | 0.0 | - | - | - | - |
| SHOOTER COUNTED ONCE | - | - | - | - | 0.0 | -0.6 | 0.0 | 0.7 |
| SHOOTERS ARE THREATS | 4.1 | +582.8 | 276.1 | 58.4 | - | - | - | - |
| SHOOTERS IN TWO RANKS | 0.4 | +0.8 | 0.0 | 0.0 | 0.1 | +0.2 | 0.0 | 0.0 |
| SHOOTERS TO THE PRIMARY | 6.1 | +462.0 | 0.0 | 62.7 | - | - | - | - |
| SHOOTS FROM THE BEST SPOT | 0.7 | +43.5 | 105.7 | 2.2 | 0.7 | +27.3 | 54.7 | 26.1 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 5.0 | - | - | - | - |
| SHOT OPTIONS | 17.7 | +0.0 | 992.6 | 247.9 | 10.0 | +0.0 | 444.1 | 159.6 |
| SHOT REPLANNED | - | - | - | - | 0.3 | +0.0 | 51.9 | 0.0 |
| SHOTS IN THE MOVE | 17.2 | +660.2 | 0.0 | 240.6 | 9.1 | +388.0 | 0.0 | 164.5 |
| SPELL SETS UP CHARGE | 0.7 | +120.2 | 43.0 | 46.5 | 0.3 | +22.5 | 23.6 | 23.5 |
| SPELL WORTH | 1.0 | +16.7 | 76.1 | 76.8 | 2.4 | +37.5 | 47.6 | 29.6 |
| STABLE ROLE | 10.5 | +0.0 | 392.7 | 111.3 | 8.2 | +0.0 | 351.0 | 133.2 |
| STAY WEIGHED | 0.1 | +4.4 | 0.0 | 0.0 | - | - | - | - |
| STAY WORTH | 20.4 | +45.1 | 580.3 | 261.1 | - | - | - | - |
| STOPS | 0.0 | +1.0 | 0.0 | 0.0 | 0.1 | +3.1 | 9.8 | 2.2 |
| STOPS SHORT OF THE FLANK | 0.3 | +7.0 | 0.0 | 10.7 | 0.4 | +41.3 | 0.0 | 26.0 |
| STUCK PIVOT | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| SUPPORT NARROWED | 4.8 | -46.9 | 336.4 | 96.0 | 6.0 | -57.2 | 424.1 | 127.0 |
| SUPPORTS | 2.8 | +55.2 | 150.1 | 51.1 | 3.7 | +57.2 | 223.8 | 52.0 |
| SURE CHARGE BEATS ADVANCE | 0.1 | -3.9 | 23.3 | 0.0 | 0.2 | -4.5 | 0.0 | 2.0 |
| SURE REACH TOGETHER | 0.2 | -0.5 | 0.0 | 0.0 | 0.8 | -1.5 | 0.0 | 19.0 |
| THREAT AT FULL SIZE | 9.3 | +0.0 | 684.7 | 150.3 | - | - | - | - |
| THROUGH LINE OF FIRE | 0.3 | +3.3 | 0.0 | 0.0 | 0.1 | +9.6 | 0.0 | 0.0 |
| TURN WORTH | 0.6 | -42.1 | 52.4 | 20.6 | 0.6 | -45.8 | 43.5 | 5.3 |
| TWO OR MORE ARRIVE | 0.3 | +2.2 | 7.9 | 27.3 | 0.1 | +0.6 | 0.0 | 3.1 |
| WAIT AFTER COSTS | 6.4 | -236.6 | 309.7 | 146.6 | 7.2 | -427.7 | 188.6 | 171.1 |
| WALKS TO THE FIGHT | 1.8 | +33.6 | 57.1 | 17.7 | 0.9 | +17.4 | 18.2 | 7.9 |
| WAR ENGINE CHARGES | 0.2 | +35.7 | 6.9 | 0.0 | 0.0 | +1.6 | 3.0 | 0.0 |
| WAR ENGINE JOBS | 0.7 | +0.0 | 38.6 | 11.5 | 0.3 | +0.0 | 11.7 | 5.6 |
| WEARS DOWN | 1.2 | +80.4 | 129.3 | 39.0 | 1.0 | +37.2 | 88.9 | 74.5 |
| WHO HITS BACK | 0.4 | +28.7 | 0.0 | 21.0 | 0.1 | +18.5 | 0.0 | 0.0 |
| WHOLE FIGHT | 0.3 | +6.2 | 72.4 | 0.0 | 0.4 | -17.6 | 64.1 | 0.0 |
| WHOLE FIGHT GAIN | 0.2 | +13.3 | 8.7 | 5.5 | 0.9 | +58.3 | 56.2 | 32.4 |

### Rule changes: sp-h2h-mine-89601ea-p3

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 757 | 757 | 757 | 28.04 | -42139 | -55.7 |
| BEST FIRST | 190 | 190 | 190 | 7.04 | +9054 | +47.7 |
| FIRE PLAN | 520 | 520 | 181 | 6.70 | +8379 | +46.3 |
| SEARCH SPOT | 125 | 125 | 124 | 4.59 | +7433 | +59.9 |
| COUNTER-CHARGE COVER | 448 | 263 | 118 | 4.37 | +8699 | +73.7 |
| MOVE TO CHARGE | 204 | 204 | 112 | 4.15 | +6023 | +53.8 |
| PATHS CROSS | 107 | 107 | 107 | 3.96 | +8517 | +79.6 |
| ARTILLERY RE-ROLL WEIGHED | 86 | 86 | 86 | 3.19 | +0 | +0.0 |
| KILLS COUNT NEXT TURN | 290 | 290 | 76 | 2.81 | +1808 | +23.8 |
| SUPPORTS | 177 | 177 | 68 | 2.52 | +854 | +12.6 |
| FACES THE THREAT | 67 | 67 | 67 | 2.48 | +4932 | +73.6 |
| SHOTS IN THE MOVE | 711 | 508 | 63 | 2.33 | +1608 | +25.5 |
| CANNON SIGHT KEPT | 57 | 57 | 57 | 2.11 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 54 | 54 | 54 | 2.00 | +9777 | +181.1 |
| FALLBACK BY WORTH | 230 | 230 | 50 | 1.85 | +3525 | +70.5 |
| SAFER THAN THE JOB | 44 | 44 | 44 | 1.63 | +2926 | +66.5 |
| WAIT AFTER COSTS | 368 | 368 | 44 | 1.63 | +746 | +17.0 |
| WALKS TO THE FIGHT | 72 | 72 | 44 | 1.63 | +506 | +11.5 |
| BEST FACING | 36 | 36 | 36 | 1.33 | +2017 | +56.0 |
| MISSILES IN THE MOVE | 217 | 117 | 35 | 1.30 | +702 | +20.1 |
| BEST OVERALL | 33 | 33 | 33 | 1.22 | +2539 | +76.9 |
| MARCH CHECK | 45 | 42 | 32 | 1.19 | +2726 | +85.2 |
| MAX FOR POSITIONING | 222 | 132 | 30 | 1.11 | +451 | +15.0 |
| RISK BY ARC | 144 | 138 | 29 | 1.07 | +668 | +23.0 |
| CHARGE NOW FIRST | 148 | 148 | 28 | 1.04 | -1428 | -51.0 |
| LONE WIZARD KEPT IN | 28 | 28 | 28 | 1.04 | +2097 | +74.9 |
| ADVANCE LANE KEPT | 26 | 26 | 26 | 0.96 | +0 | +0.0 |
| FIRE IN ORDER | 26 | 26 | 26 | 0.96 | +0 | +0.0 |
| REDIRECT COUNTER | 115 | 60 | 26 | 0.96 | +2437 | +93.7 |
| HOLDS AMBUSHERS | 25 | 25 | 25 | 0.93 | +0 | +0.0 |
| BLOCKED WHEEL | 24 | 24 | 24 | 0.89 | +449 | +18.7 |
| CAST JOB | 49 | 49 | 24 | 0.89 | +553 | +23.0 |
| CHARGE NOW WEIGHED | 23 | 23 | 23 | 0.85 | +1390 | +60.4 |
| RANDOM MOVE BY FIGURES | 48 | 48 | 23 | 0.85 | +951 | +41.4 |
| RESERVE FALL BACK | 23 | 23 | 23 | 0.85 | +472 | +20.5 |
| BEST MOVE FOR SHOOTERS | 22 | 22 | 22 | 0.81 | +1680 | +76.4 |
| SHOOTS FROM THE BEST SPOT | 38 | 38 | 21 | 0.78 | +661 | +31.5 |
| MOVE AND CAST | 20 | 20 | 20 | 0.74 | +1489 | +74.5 |
| REDIRECT WEIGHED | 20 | 20 | 20 | 0.74 | +992 | +49.6 |
| STOPS SHORT OF THE FLANK | 20 | 20 | 20 | 0.74 | +1303 | +65.1 |
| KEEPS ITS TARGET | 97 | 94 | 19 | 0.70 | +231 | +12.1 |
| KEEPS THE TARGET | 51 | 51 | 19 | 0.70 | -2126 | -111.9 |
| KILLS COUNT | 110 | 105 | 18 | 0.67 | +771 | +42.8 |
| MISSILES IN THE FIRE PLAN | 118 | 29 | 18 | 0.67 | +744 | +41.3 |
| SET UP TOGETHER | 56 | 53 | 18 | 0.67 | +1104 | +61.3 |
| COMBAT PIVOT | 16 | 16 | 16 | 0.59 | +0 | +0.0 |
| INVITES THE FIGHT | 70 | 70 | 16 | 0.59 | +177 | +11.1 |
| SCOUT WAITS | 16 | 16 | 16 | 0.59 | +0 | +0.0 |
| SHOOTERS IN TWO RANKS | 16 | 16 | 16 | 0.59 | +27 | +1.7 |
| BIG CHARACTER SAFETY | 15 | 15 | 15 | 0.56 | -52 | -3.5 |
| MARCH ODDS | 16 | 16 | 15 | 0.56 | +125 | +8.4 |
| SHOOTERS TO THE PRIMARY | 165 | 133 | 15 | 0.56 | +409 | +27.2 |
| STAY WORTH | 551 | 483 | 15 | 0.56 | +354 | +23.6 |
| WHO HITS BACK | 14 | 14 | 14 | 0.52 | +896 | +64.0 |
| WHOLE FIGHT GAIN | 30 | 26 | 13 | 0.48 | +429 | +33.0 |
| WAR ENGINE JOBS | 27 | 27 | 12 | 0.44 | -434 | -36.2 |
| FRIENDS SHOTS CHECKED | 11 | 11 | 11 | 0.41 | +317 | +28.8 |
| MAKE SURE TOGETHER | 43 | 30 | 11 | 0.41 | +884 | +80.4 |
| MANOEUVRE | 12 | 12 | 11 | 0.41 | +370 | +33.7 |
| CANNON PLANNED TARGET | 48 | 48 | 10 | 0.37 | -608 | -60.8 |
| THROUGH LINE OF FIRE | 10 | 10 | 10 | 0.37 | +346 | +34.6 |
| CASTER AWAY FROM SCREEN | 8 | 8 | 8 | 0.30 | +0 | +0.0 |
| SHOT REPLANNED | 8 | 8 | 8 | 0.30 | +0 | +0.0 |
| BEST PREY | 27 | 27 | 7 | 0.26 | +367 | +52.4 |
| CASTING BLOCK | 12 | 12 | 7 | 0.26 | +379 | +54.1 |
| MISSILES NEXT TURN | 288 | 160 | 7 | 0.26 | +44 | +6.3 |
| SUPPORT NARROWED | 291 | 291 | 7 | 0.26 | -36 | -5.2 |
| SURE CHARGE BEATS ADVANCE | 7 | 7 | 7 | 0.26 | -227 | -32.4 |
| CASTS FROM BEHIND | 6 | 6 | 6 | 0.22 | +0 | +0.0 |
| MOVES UNITS SPELL | 6 | 6 | 6 | 0.22 | +136 | +22.7 |
| PURSUES BIG PREY | 6 | 6 | 6 | 0.22 | -331 | -55.2 |
| WEARS DOWN | 60 | 56 | 6 | 0.22 | +196 | +32.7 |
| BEST PRIZE | 5 | 5 | 5 | 0.19 | -126 | -25.1 |
| HUNT IN PAIRS | 38 | 20 | 5 | 0.19 | +137 | +27.3 |
| KEEP FALLS | 5 | 5 | 5 | 0.19 | +298 | +59.5 |
| LOST CHARGE | 151 | 151 | 5 | 0.19 | +72 | +14.4 |
| OPENS UP | 16 | 15 | 5 | 0.19 | +491 | +98.2 |
| RESTRAINS TO SHOOT | 5 | 5 | 5 | 0.19 | +138 | +27.6 |
| SHOOTERS ARE THREATS | 110 | 110 | 5 | 0.19 | +0 | +0.0 |
| SHORT GUN FORWARD | 5 | 5 | 5 | 0.19 | +0 | +0.0 |
| STUCK PIVOT | 5 | 5 | 5 | 0.19 | +0 | +0.0 |
| MODEL FACING | 4 | 4 | 4 | 0.15 | +1246 | +311.5 |
| THREAT AT FULL SIZE | 250 | 250 | 4 | 0.15 | +0 | +0.0 |
| WAR ENGINE CHARGES | 6 | 6 | 4 | 0.15 | +644 | +160.9 |
| WHOLE FIGHT | 19 | 18 | 4 | 0.15 | +72 | +17.9 |
| BACKUP TARGETS | 45 | 20 | 3 | 0.11 | +11 | +3.8 |
| CARRIES OUT SET-UP | 9 | 9 | 3 | 0.11 | -231 | -77.0 |
| CHAFF PASSED | 3 | 3 | 3 | 0.11 | -10 | -3.2 |
| EDGE GIVE GROUND | 15 | 15 | 3 | 0.11 | +371 | +123.7 |
| FACE THE CAST | 3 | 3 | 3 | 0.11 | +91 | +30.3 |
| NEEDED THERE | 3 | 3 | 3 | 0.11 | +0 | +0.0 |
| RAIDS THE BAGGAGE NEXT TURN | 3 | 3 | 3 | 0.11 | +171 | +57.0 |
| STAY WEIGHED | 3 | 3 | 3 | 0.11 | +119 | +39.6 |
| BLOCKED CHARGE SKIPPED | 2 | 2 | 2 | 0.07 | +0 | +0.0 |
| CHARIOT NO STATIC JOB | 2 | 2 | 2 | 0.07 | -92 | -46.1 |
| ELIXIR WORTH | 2 | 2 | 2 | 0.07 | +132 | +66.2 |
| FIRE AND FLEE | 2 | 2 | 2 | 0.07 | +37 | +18.7 |
| HUNT ADVANCE | 10 | 10 | 2 | 0.07 | +70 | +34.9 |
| NO RALLY LEFT | 2 | 2 | 2 | 0.07 | +40 | +20.2 |
| OPENS A LANE | 14 | 6 | 2 | 0.07 | +38 | +18.8 |
| OVERRUNS AWAY | 33 | 33 | 2 | 0.07 | +29 | +14.3 |
| STOPS | 5 | 5 | 2 | 0.07 | +29 | +14.5 |
| TURN WORTH | 33 | 31 | 2 | 0.07 | +38 | +19.2 |
| BOMBING RUN | 1 | 1 | 1 | 0.04 | +27 | +27.1 |
| BOUND ASSAILMENT | 1 | 1 | 1 | 0.04 | +0 | +0.1 |
| CARRIES OUT COUNTER | 4 | 4 | 1 | 0.04 | -122 | -122.4 |
| CATCH ODDS | 1 | 1 | 1 | 0.04 | -2 | -1.5 |
| HORN WORTH | 1 | 1 | 1 | 0.04 | +9 | +8.7 |
| JOINT CHARGE PLAN | 10 | 10 | 1 | 0.04 | +127 | +127.3 |
| KEEPS SCOUTS OR AMBUSH | 1 | 1 | 1 | 0.04 | +0 | +0.0 |
| MOVE SPELL IN RANGE | 8 | 6 | 1 | 0.04 | +0 | +0.0 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.04 | +54 | +54.4 |
| PIVOT GUARDS FLANK | 1 | 1 | 1 | 0.04 | -12 | -12.5 |
| ARRIVAL HUNT | 2 | 2 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 9 | 9 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 34 | trace | - | - | - | - |
| CHARIOT WIZARD CAREFUL | 4 | 4 | 0 | 0.00 | - | - |
| CHEAP HELPER | 6 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 39 | not checked | - | - | - | - |
| DEFENSIVE ARMY | 4 | 4 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT LIFT | 6 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 268 | not checked | - | - | - | - |
| GIVES UP | 6 | 4 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 3 | 2 | 0 | 0.00 | - | - |
| HELPER ALREADY ASKED | 2 | not checked | - | - | - | - |
| HELPER UNSEEN | 16 | 15 | 0 | 0.00 | - | - |
| HILL BY ITS CHANCE | 22 | 22 | 0 | 0.00 | - | - |
| HUNT DROPPED | 4 | trace | - | - | - | - |
| HUNT KEPT | 6 | trace | - | - | - | - |
| HUNT RESULT | 11 | trace | - | - | - | - |
| HUNT THE GUNS | 11 | trace | - | - | - | - |
| KEEPS ITS PREY | 1 | 1 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 26 | not checked | - | - | - | - |
| LONE WIZARD HOLDS BACK | 6 | 6 | 0 | 0.00 | - | - |
| LONG SHOT | 11 | 11 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 1 | 1 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 5 | trace | - | - | - | - |
| MARCH OVER CASTS | 38 | 38 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 14 | 14 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 17 | trace | - | - | - | - |
| MOVE SPELL SPOT | 23 | not checked | - | - | - | - |
| NOT NEEDED | 21 | 21 | 0 | 0.00 | - | - |
| NOT TURNED | 260 | 260 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 21 | not checked | - | - | - | - |
| PLAN RESULT | 1949 | trace | - | - | - | - |
| RAIDS THE BAGGAGE | 1 | 1 | 0 | 0.00 | - | - |
| RANDOM MOVER NO PROMISE | 14 | 14 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 7 | 7 | 0 | 0.00 | - | - |
| SCOUT SPOT | 16 | 16 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 4 | 4 | 0 | 0.00 | - | - |
| SECOND HUNTER | 1 | 1 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 17 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 24 | not checked | - | - | - | - |
| SET-UP MISSED | 1 | trace | - | - | - | - |
| SHOOTER COUNTED ONCE | 1 | 1 | 0 | 0.00 | - | - |
| SHOT OPTIONS | 748 | 748 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 26 | not checked | - | - | - | - |
| SPELL WORTH | 91 | not checked | - | - | - | - |
| STABLE ROLE | 505 | 504 | 0 | 0.00 | - | - |
| SURE REACH TOGETHER | 26 | 20 | 0 | 0.00 | - | - |
| TWO OR MORE ARRIVE | 13 | 11 | 0 | 0.00 | - | - |

### Off best figure: sp-h2h-mine-89601ea-p3

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 13.07 | 11.56 | 57.5 |
| TURN GATE | gate | 0.52 | 0.81 | 40.5 |
| CHARGE NOW FIRST | rule | 0.37 | 0.63 | 52.9 |
| FALLBACK | gate | 0.56 | 0.44 | 25.4 |
| FIRE PLAN | rule | 0.67 | - | 61.9 |
| KEEPS THE TARGET | rule | 0.59 | - | 139.2 |
| WAR ENGINE JOBS | rule | 0.33 | 0.11 | 36.2 |
| LONE CHARACTER SAFE SPOT | gate | 0.37 | 0.04 | 69.5 |
| CHARGE NOW WEIGHED | rule | 0.19 | 0.15 | 39.8 |
| SUPPORT REQUEST | gate | 0.04 | 0.22 | 125.5 |
| SURE CHARGE BEATS ADVANCE | rule | 0.07 | 0.19 | 32.4 |
| BIG CHARACTER SAFETY | rule | 0.07 | 0.15 | 12.9 |
| PURSUES BIG PREY | rule | 0.11 | 0.11 | 55.2 |
| SUPPORT NARROWED | rule | 0.07 | 0.15 | 6.0 |
| AFTERMATH BAND | gate | 0.11 | 0.04 | 1.1 |
| BEST PRIZE | rule | 0.07 | 0.07 | 31.3 |
| CANNON PLANNED TARGET | rule | - | 0.15 | 151.9 |
| NO REASON | gate | 0.15 | - | 23.8 |
| STOPS SHORT OF THE FLANK | rule | 0.07 | 0.07 | 16.7 |
| CARRIES OUT SET-UP | rule | 0.07 | 0.04 | 77.0 |
| MARCH ODDS | rule | 0.04 | 0.07 | 13.5 |
| BLOCKED WHEEL | rule | 0.07 | - | 6.3 |
| CHAFF PASSED | rule | - | 0.07 | 4.8 |
| CHARIOT NO STATIC JOB | rule | 0.07 | - | 46.1 |
| FIGHT ORDER BAND | gate | 0.04 | 0.04 | 1.8 |
| SAFER THAN THE JOB | rule | - | 0.07 | 5.2 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.04 | - | 24.9 |
| CARRIES OUT COUNTER | rule | - | 0.04 | 122.4 |
| CATCH ODDS | rule | 0.04 | - | 1.5 |
| MOVE AND CAST | rule | 0.04 | - | 2.0 |
| PATHS CROSS | rule | - | 0.04 | 60.1 |
| PIVOT GUARDS FLANK | rule | - | 0.04 | 12.5 |
| THROUGH LINE OF FIRE | rule | - | 0.04 | 1.2 |

### Plans: sp-h2h-mine-89601ea-p3

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 9.4 | 19% | 301 | 292 | 97% |
| Mine | charge | 3.0 | 52% | 349 | 286 | 82% |
| Mine | close in | 4.6 | 31% | 353 | 158 | 45% |
| Mine | hold | 4.4 | 29% | 256 | 0 | 0% |
| Mine | join | 0.7 | 90% | 10 | 0 | 0% |
| Mine | shoot | 11.6 | 61% | 805 | 793 | 99% |
| Mine | support | 2.9 | 96% | 32 | 0 | 0% |
| Opponent | advance | 10.9 | 18% | 438 | 326 | 74% |
| Opponent | charge | 5.0 | 49% | 507 | 408 | 81% |
| Opponent | close in | 5.2 | 24% | 362 | 191 | 53% |
| Opponent | hold | 4.1 | 28% | 313 | 0 | 0% |
| Opponent | join | 0.9 | 92% | 41 | 0 | 0% |
| Opponent | shoot | 5.4 | 55% | 200 | 350 | 175% |
| Opponent | support | 4.0 | 87% | 33 | 0 | 0% |

### Packages: hunt the guns, sp-h2h-mine-89601ea-p3

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.1 | 4 | 0 | 0% | 0% | 0% | - | 407 | 0 | 0% | 38 |
| Opponent | 0.3 | 7 | 0 | 43% | 29% | 0% | 2.0 | 284 | 56 | 29% | 147 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.8 | 3 | 0 | 0% | 0% | 0% | - | 391 | 0 | 0% | 68 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 92 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Empire of Man | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 458 | 0 | 0% | 63 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 68 |
| High Elf Realms | 0.1 | 1 | 0 | 0% | 0% | 0% | - | 506 | 0 | 0% | 122 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 310 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 1.0 | 1 | 0 | 100% | 100% | 0% | 2.0 | 185 | 142 | 100% | 248 |
| Tomb Kings of Khemri | 0.3 | 1 | 0 | 0% | 0% | 0% | - | 425 | 0 | 0% | 154 |
| Vampire Counts | 0.2 | 1 | 0 | 100% | 0% | 0% | - | 131 | 0 | 0% | 49 |
| Warriors of Chaos | 0.2 | 1 | 0 | 100% | 100% | 0% | 2.0 | 282 | 252 | 100% | 34 |
| Wood Elf Realms | 0.7 | 2 | 0 | 0% | 0% | 0% | - | 231 | 0 | 0% | 175 |

### Battle groups: sp-h2h-mine-89601ea-p3

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 9.9 | 30% | 40% | 9% | 57% | 38% | 18% | 5% | 39% | 0% |
| Mine | REDIRECT COUNTER | 1.5 | 54% | 59% | 0% | - | 18% | 5% | 5% | 64% | 9% |
| Opponent | COUNTER-CHARGE COVER | 6.7 | 16% | 69% | 28% | 38% | 43% | 14% | 5% | 38% | 0% |
| Opponent | REDIRECT COUNTER | 2.7 | 20% | 80% | 20% | 0% | 25% | 0% | 17% | 58% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: sp-h2h-mine-89601ea-p3

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 15 | 25 (15) | 16 | 9 | 61 | 27% | 3.3 | 20 (10) | 0 (1) | 43 (4) | 36 (10) | 5 (5) |
| Mine | Character | 99 | 53 (99) | 53 | 0 | 42 | 20% | 2.2 | 66 (31) | 56 (45) | 68 (4) | 46 (45) | 79 (35) |
| Mine | Clean-up | 13 | 93 (13) | 59 | 33 | 43 | 23% | 2.7 | 89 (2) | 93 (9) | 105 (2) | 64 (8) | 135 (5) |
| Mine | Fast | 1 | 0 (1) | 0 | 0 | 100 | 0% | 4.0 | - | 0 (1) | - | 0 (1) | - |
| Mine | Fast Hammer | 36 | 30 (36) | 12 | 17 | 56 | 25% | 2.9 | 24 (16) | 43 (16) | 0 (4) | 44 (26) | 4 (10) |
| Mine | Hammer | 35 | 31 (35) | 23 | 8 | 42 | 17% | 2.4 | 28 (7) | 34 (25) | 20 (3) | 33 (22) | 28 (13) |
| Mine | Holder | 17 | 58 (17) | 0 | 58 | 16 | 47% | 4.3 | 54 (6) | 57 (9) | 73 (2) | 75 (10) | 30 (7) |
| Mine | Shooter | 35 | 56 (35) | 13 | 43 | 36 | 6% | 1.5 | 12 (5) | 74 (26) | 0 (3) | 61 (22) | 54 (12) |
| Mine | Support | 4 | 0 (4) | 0 | 0 | 0 | 0% | 3.0 | 0 (1) | 0 (3) | - | 0 (1) | 0 (3) |
| Mine | War machine | 52 | 61 (52) | 61 | 0 | 34 | 0% | 1.1 | 107 (13) | 43 (35) | 61 (4) | 55 (13) | 63 (39) |
| Mine | Wizard | 8 | 0 (8) | 0 | 0 | 62 | 0% | 3.0 | 0 (1) | 0 (3) | - | 0 (3) | 0 (1) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Chaff | 48 | 43 (48) | 13 | 30 | 66 | 46% | 2.7 | 39 (22) | 76 (7) | 30 (19) | 47 (34) | 32 (14) |
| Opponent | Character | 76 | 50 (76) | 50 | 0 | 34 | 17% | 2.1 | 80 (28) | 37 (36) | 12 (5) | 77 (35) | 34 (34) |
| Opponent | Clean-up | 10 | 57 (10) | 29 | 28 | 31 | 30% | 2.6 | 27 (4) | 57 (5) | 182 (1) | 56 (6) | 58 (4) |
| Opponent | Fast | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Fast Hammer | 38 | 41 (38) | 28 | 13 | 51 | 18% | 2.5 | 24 (15) | 63 (17) | 19 (6) | 30 (18) | 52 (20) |
| Opponent | Fragile | 3 | 0 (3) | 0 | 0 | 67 | 0% | 2.7 | - | 0 (2) | 0 (1) | 0 (2) | 0 (1) |
| Opponent | Hammer | 32 | 36 (32) | 21 | 15 | 57 | 22% | 3.3 | 8 (11) | 49 (19) | 0 (2) | 28 (21) | 55 (11) |
| Opponent | Holder | 34 | 100 (34) | 35 | 65 | 32 | 24% | 2.9 | 37 (7) | 121 (19) | 112 (8) | 104 (26) | 91 (8) |
| Opponent | Shooter | 21 | 21 (21) | 16 | 5 | 54 | 0% | 1.2 | 10 (7) | 6 (12) | 222 (2) | 6 (14) | 50 (7) |
| Opponent | Support | 3 | 0 (3) | 0 | 0 | 40 | 67% | 4.0 | 0 (1) | 0 (1) | 0 (1) | 0 (3) | - |
| Opponent | War machine | 17 | 50 (17) | 50 | 0 | 34 | 12% | 1.3 | 121 (3) | 36 (10) | 40 (4) | 0 (3) | 59 (14) |
| Opponent | Wizard | 25 | 12 (25) | 12 | 0 | 39 | 20% | 2.1 | 9 (11) | 25 (7) | 0 (3) | 14 (10) | 12 (11) |

### Charged fights: sp-h2h-mine-89601ea-p3

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 0 | 10 | 0.5 | 1.5 | 20 | 0 | +20 | 0 of 2 | 2 of 2 | +40 | +0 |
| Mine | Chaos Dwarfs | 4 | 156 | 346 | 4.0 | 1.2 | 87 | 28 | +58 | 10 of 16 | 11 of 16 | +182 | +17 |
| Mine | Dwarfen Mountain Holds | 3 | 407 | 0 | 1.0 | 1.3 | 0 | 63 | -63 | 0 of 3 | 1 of 3 | +0 | -94 |
| Mine | Empire of Man | 5 | 424 | 34 | 0.8 | 1.0 | 43 | 9 | +34 | 0 of 4 | 3 of 4 | - | +34 |
| Mine | Grand Cathay | 5 | 495 | 342 | 3.6 | 1.1 | 95 | 34 | +61 | 3 of 18 | 14 of 18 | +173 | +55 |
| Mine | High Elf Realms | 4 | 149 | 580 | 3.5 | 1.1 | 166 | 0 | +166 | 5 of 14 | 10 of 14 | +245 | +153 |
| Mine | Kingdom of Bretonnia | 1 | 524 | 553 | 5.0 | 1.2 | 111 | 0 | +111 | 1 of 5 | 4 of 5 | +208 | +86 |
| Mine | Lizardmen | 1 | 232 | 260 | 3.0 | 1.7 | 87 | 133 | -46 | 2 of 3 | 2 of 3 | +18 | -175 |
| **Mine** | all armies | 27 | 289 | 239 | 2.4 | 1.2 | 99 | 26 | +73 | 21 of 65 | 47 of 65 | +140 | +58 |
| Opponent | Empire of Man | 1 | 569 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 1 of 1 | 1 of 1 | - | +0 |
| Opponent | Grand Cathay | 3 | 345 | 252 | 2.0 | 1.2 | 126 | 62 | +65 | 2 of 6 | 5 of 6 | +0 | +78 |
| Opponent | High Elf Realms | 3 | 180 | 222 | 2.7 | 1.4 | 83 | 43 | +40 | 7 of 8 | 7 of 8 | +28 | +47 |
| Opponent | Kingdom of Bretonnia | 2 | 0 | 616 | 2.5 | 1.0 | 246 | 110 | +136 | 4 of 5 | 3 of 5 | - | +136 |
| Opponent | Orc & Goblin Tribes | 1 | 0 | 175 | 5.0 | 1.0 | 35 | 22 | +13 | 0 of 5 | 1 of 5 | - | +13 |
| Opponent | Skaven | 1 | 60 | 391 | 4.0 | 1.0 | 98 | 0 | +98 | 2 of 4 | 2 of 4 | - | +98 |
| Opponent | Tomb Kings of Khemri | 3 | 170 | 531 | 4.0 | 1.3 | 133 | 32 | +100 | 6 of 12 | 9 of 12 | +207 | +47 |
| Opponent | Vampire Counts | 5 | 65 | 995 | 4.8 | 1.2 | 207 | 56 | +151 | 11 of 24 | 14 of 24 | +154 | +150 |
| Opponent | Warriors of Chaos | 5 | 0 | 424 | 3.6 | 1.2 | 118 | 74 | +44 | 10 of 18 | 13 of 18 | -52 | +63 |
| Opponent | Wood Elf Realms | 3 | 0 | 280 | 3.0 | 1.1 | 93 | 35 | +58 | 4 of 9 | 6 of 9 | +390 | +17 |
| **Opponent** | all armies | 27 | 113 | 472 | 3.4 | 1.2 | 139 | 52 | +87 | 47 of 92 | 61 of 92 | +110 | +82 |

### Effective charges: sp-h2h-mine-89601ea-p3

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 2 | 1 (net +0) | 0 | 0 | 0 | 0 | 1 (net +40) | 0 | 0% (0 of 2) |
| Mine | Chaos Dwarfs | 16 | 1 (net -65) | 0 | 2 (net +0) | 4 (net +77) | 1 (net +85) | 7 (net +130) | 1 | 13% (2 of 15) |
| Mine | Dwarfen Mountain Holds | 3 | 1 (net +0) | 0 | 0 | 1 (net -128) | 0 | 1 (net -60) | 0 | 0% (0 of 3) |
| Mine | Empire of Man | 4 | 1 (net -36) | 0 | 0 | 0 | 0 | 2 (net +86) | 1 | 0% (0 of 3) |
| Mine | Grand Cathay | 18 | 1 (net -205) | 0 | 3 (net +33) | 3 (net +66) | 3 (net +103) | 5 (net +53) | 3 | 20% (3 of 15) |
| Mine | High Elf Realms | 14 | 1 (net +0) | 1 (net +0) | 0 | 4 (net +176) | 2 (net +65) | 4 (net +340) | 2 | 0% (0 of 12) |
| Mine | Kingdom of Bretonnia | 5 | 1 (net +0) | 0 | 0 | 2 (net +54) | 1 (net +208) | 1 (net +236) | 0 | 0% (0 of 5) |
| Mine | Lizardmen | 3 | 1 (net -175) | 0 | 0 | 0 | 0 | 2 (net +18) | 0 | 0% (0 of 3) |
| Opponent | Empire of Man | 1 | 1 (net +0) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 1) |
| Opponent | Grand Cathay | 6 | 1 (net -14) | 1 (net +317) | 0 | 1 (net +85) | 1 (net +0) | 0 | 2 | 0% (0 of 4) |
| Opponent | High Elf Realms | 8 | 0 | 0 | 3 (net -12) | 2 (net +135) | 0 | 3 (net +28) | 0 | 38% (3 of 8) |
| Opponent | Kingdom of Bretonnia | 5 | 2 (net +124) | 2 (net +163) | 0 | 0 | 0 | 1 (net +104) | 0 | 0% (0 of 5) |
| Opponent | Orc & Goblin Tribes | 5 | 1 (net +60) | 0 | 0 | 2 (net -28) | 0 | 0 | 2 | 0% (0 of 3) |
| Opponent | Skaven | 4 | 3 (net +130) | 0 | 0 | 0 | 0 | 1 (net +0) | 0 | 0% (0 of 4) |
| Opponent | Tomb Kings of Khemri | 12 | 1 (net -72) | 0 | 0 | 5 (net +67) | 2 (net +88) | 2 (net +62) | 2 | 0% (0 of 10) |
| Opponent | Vampire Counts | 24 | 5 (net +248) | 1 (net +230) | 5 (net +60) | 4 (net +135) | 3 (net -53) | 5 (net +282) | 1 | 22% (5 of 23) |
| Opponent | Warriors of Chaos | 18 | 4 (net +142) | 2 (net -232) | 0 | 1 (net +0) | 0 | 8 (net +49) | 3 | 0% (0 of 15) |
| Opponent | Wood Elf Realms | 9 | 0 | 0 | 2 (net +195) | 2 (net +35) | 0 | 0 | 5 | 50% (2 of 4) |

### Charged fights, damage counted: sp-h2h-mine-89601ea-p3

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 8 | 180 | 236 | -60 | 12 | 87 | -75 | -41.8 |
| Mine | 50-54% | 1 | 497 | 499 | +0 | 0 | 0 | +0 | +0.0 |
| Mine | Effective (55-75%) | 5 | 268 | 357 | +20 | 49 | 25 | +24 | +9.0 |
| Mine | 76-89% | 14 | 340 | 174 | +85 | 147 | 69 | +79 | +23.1 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 23 | 348 | 202 | +129 | 179 | 58 | +121 | +34.9 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 7 | 433 | 107 | +104 | 107 | 23 | +84 | +19.5 |
| Mine | No odds | 7 | 284 | 167 | +37 | 80 | 49 | +31 | +10.9 |
| Mine | All fights | 65 | 324 | 203 | +73 | 121 | 56 | +65 | +20.0 |
| Opponent | Long shot (under 50%) | 18 | 174 | 199 | +135 | 221 | 68 | +153 | +87.6 |
| Opponent | 50-54% | 6 | 294 | 250 | +68 | 150 | 80 | +71 | +24.0 |
| Opponent | Effective (55-75%) | 10 | 242 | 348 | +65 | 209 | 112 | +97 | +40.1 |
| Opponent | 76-89% | 17 | 315 | 219 | +73 | 151 | 47 | +104 | +33.0 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 20 | 434 | 259 | +106 | 162 | 65 | +97 | +22.3 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 6 | 515 | 97 | +3 | 94 | 77 | +17 | +3.3 |
| Opponent | No odds | 15 | 297 | 181 | +75 | 140 | 68 | +72 | +24.4 |
| Opponent | All fights | 92 | 314 | 226 | +87 | 168 | 70 | +98 | +31.3 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| sp-h2h-mine-89601ea-p3 | move | 314 | 71 (23%) | 49 (16%) | 41 (13%) | 202 (64%) |
| sp-h2h-mine-89601ea-p3 | objective | 265 | 38 (14%) | 27 (10%) | 41 (15%) | 186 (70%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0110, L0126 |
| Charmed Shield | Opponent | L0126, L0226, L0327, L0725, L1327 |
| Clockwork Compass | Mine | L1216, L1232 |
| Elixir of Power | Mine | L1122 |
| Elixir of Power | Opponent | L0311, L1519 |
| Horn of the Wild Hunt | Opponent | L0533, L1633 |
| Invocation of Nehek | Opponent | L0327, L0725, L1327 |
| Opal Amulet | Mine | L1422 |
| Periapt of Soul Exchange | Opponent | L0620 |
| Ring of Doom | Mine | L0210, L0226, L1122, L1216, L1232, L1519, L1535 |
| Ring of Doom | Opponent | L0311, L0533, L0815, L0831, L1633, L1731 |
| Ring of Jet | Mine | L1013, L1030, L1122, L1216, L1232 |
| Ring of Jet | Opponent | L0110, L0210, L0311 |
| Standard of the Fell Warrior | Mine | L1327 |
| Standard of the Fell Warrior | Opponent | L0413, L1013 |
| Twice-Blessed Armour | Mine | L0709, L0725, L1013, L1030 |
| Twice-Blessed Armour | Opponent | L0110, L0210 |
| Witch Hunter's Ward | Mine | L0709, L0725, L0815, L0831 |

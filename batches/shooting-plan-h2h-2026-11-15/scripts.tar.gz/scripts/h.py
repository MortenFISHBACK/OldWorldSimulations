import csv,glob,statistics as st,math,collections,sys
D='/root/an/root'
rows=[]
for arm in ('mine','opp'):
  for f in sorted(glob.glob(f'{D}/{arm}-*/games.csv')):
    for r in csv.DictReader(open(f)):
      fw,off=('mine','opponent') if arm=='mine' else ('opponent','mine')
      if r['ended']!='yes' or not r['vp_mine_opponent']: print('not ended',arm,r['pair'],r['scenario']); continue
      m,o=map(int,r['vp_mine_opponent'].split('-')); v={'mine':m,'opponent':o}
      win=r['winner'].lower(); res='D' if win=='draw' else ('W' if win==fw else 'L')
      g=dict(arm=arm,pair=r['pair'],sc=r['scenario'],margin=v[fw]-v[off],res=res,fwfirst=r['first_player'].lower()==fw,
             army_fw=r.get(f'army_{fw}'),army_off=r.get(f'army_{off}'))
      for k in ('vp_kills','vp_objectives','vp_leaders','vp_other','units_lost','points_lost'):
        g[k+'_fw']=float(r.get(f'{k}_{fw}') or 0); g[k+'_off']=float(r.get(f'{k}_{off}') or 0)
      rows.append(g)
by=collections.defaultdict(dict)
for g in rows: by[g['pair']][g['arm']]=g
matched=[p for p,v in by.items() if len(v)==2]
M=[g for p in matched for g in by[p].values()]
band=lambda xs:1.96*st.stdev(xs)/math.sqrt(len(xs))
ps=[by[p]['mine']['margin']+by[p]['opp']['margin'] for p in matched]
c=collections.Counter(g['res'] for g in M)
print(f"games {len(rows)}, matched pairs {len(matched)}; margin {st.mean(g['margin'] for g in M):+.0f} ±{band(ps)/2:.0f} (paired); W/D/L {c['W']}/{c['D']}/{c['L']}; pairs ahead/behind {sum(x>0 for x in ps)}/{sum(x<0 for x in ps)}")
for lab,f in (('plan as Mine',lambda g:g['arm']=='mine'),('plan as Opp',lambda g:g['arm']=='opp'),('plan first',lambda g:g['fwfirst']),('plan second',lambda g:not g['fwfirst'])):
  xs=[g['margin'] for g in M if f(g)]; print(f"  {lab}: {len(xs)} {st.mean(xs):+.0f} ±{band(xs):.0f}")
for k in ('vp_kills','vp_objectives','vp_leaders','units_lost','points_lost'):
  d=[g[k+'_fw']-g[k+'_off'] for g in M]
  print(f"  {k}: plan {st.mean(g[k+'_fw'] for g in M):.1f} main {st.mean(g[k+'_off'] for g in M):.1f}")
pl=[by[p]['mine']['points_lost_fw']+by[p]['opp']['points_lost_fw']-by[p]['mine']['points_lost_off']-by[p]['opp']['points_lost_off'] for p in matched]
print(f"  points lost diff {st.mean(pl)/2:+.0f} ±{band(pl)/2:.0f}")

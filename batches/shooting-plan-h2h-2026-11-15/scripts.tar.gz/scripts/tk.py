import json,glob,os,re,collections,statistics as st,math,csv
R='/root/an/root'
out=collections.defaultdict(collections.Counter); L=collections.defaultdict(list)
army_rows=[]
def band(x): return 1.96*st.stdev(x)/math.sqrt(len(x)) if len(x)>1 else 0
for part in sorted(glob.glob(R+'/*-*')):
    if not os.path.exists(part+'/units.jsonl'): continue
    plan='Mine' if os.path.basename(part).startswith('mine') else 'Opponent'
    U=collections.defaultdict(list)
    for l in open(part+'/units.jsonl'):
        d=json.loads(l); U[d['game']].append(d)
    games={}
    for g,us in U.items(): games.setdefault(tuple(sorted((u['side'],u['unit']) for u in us)),[]).append(g)
    gcsv={r['pair']:r for r in csv.DictReader(open(part+'/games.csv'))}
    for lf in sorted(glob.glob(part+'/game-*.log.jsonl')):
        pair=re.search(r'game-(L\d+)-',lf).group(1)
        rows=[json.loads(l) for l in open(lf)]
        board=next(r for r in rows if r.get('kind')=='board')
        k=tuple(sorted((u['s'],u['lk']['cn']) for u in board['units']))
        if not games.get(k): out['x']['no units match']+=1; continue
        us=U[games[k].pop(0)]
        names=collections.defaultdict(set)
        for b in board['units']: names[b['lk']['cn']].add(b['n']); names[b['n']].add(b['n'])
        wmset={b['n'] for b in board['units'] if b['lk']['tt'].startswith('War Machine')}
        acts=[r for r in rows if r.get('kind')=='action']
        sideof={b['n']:b['s'] for b in board['units']}
        missile_wiz=collections.defaultdict(set)
        for r in acts:
            if r['type']=='MissileWizard': missile_wiz[r['side']].add((r['actor'] or '').split(' (')[0])
        fought=collections.defaultdict(set); charged=collections.defaultdict(set)
        for r in acts:
            if r['type']=='CombatAttack':
                fought[r['turn']].add(r.get('actor')); fought[r['turn']].add(r.get('target'))
            if r['type']=='Charge': charged[r['turn']].add(r.get('actor'))
        r_g=gcsv.get(pair)
        for side in ('Mine','Opponent'):
            key='plan' if side==plan else 'main'; C=out[key]; enemy='Opponent' if side=='Mine' else 'Mine'
            # shooting-heavy: share of own points in Shooter-purpose units or war machines
            own=[u for u in us if u['side']==side]; tot=sum(u['points'] for u in own) or 1
            sh=sum(u['points'] for u in own if ('Shooter' in (u.get('purposes') or '') and not u['isCharacter']) or u['troopType']=='War Machine')/tot
            if r_g and r_g['ended']=='yes':
                m,o=map(int,r_g['vp_mine_opponent'].split('-')); v={'Mine':m,'Opponent':o}
                army_rows.append(dict(key=key,pair=pair,heavy=sh>=0.30,share=sh,margin=v[side]-v[enemy],army=own[0]['army'] if own else '?'))
            # top killer of this side = enemy unit that took most of this side's points in fights
            kb=collections.Counter()
            for u in own:
                if u['gone'] and u['goneCause'] in ('Combat','RunDown','FledOff') and u['goneBy']: kb[u['goneBy']]+=u['vpGivenUp']
            C['sides']+=1
            # dearest enemy unit (by points, not joined), outcome-free
            en=[u for u in us if u['side']==enemy and not u.get('joinedTo')]
            if en:
                dear=max(en,key=lambda u:u['points']); C['dearest']+=1
                C['dearest dead by r3']+= bool(dear['gone'] and (dear['goneRound'] or 99)<=3)
            if not kb: C['no top killer']+=1; continue
            top,took=kb.most_common(1)[0]
            tu=next((u for u in us if u['side']==enemy and (u['unit']==top or top in names[u['unit']])),None)
            if tu is None: C['top not found']+=1; continue
            topn=names[top]|names[tu['unit']]
            C['top']+=1; C['top dead by r3']+= bool(tu['gone'] and (tu['goneRound'] or 99)<=3)
            C['top dead at all']+= bool(tu['gone'])
            tdead=tu['goneRound'] if tu['gone'] else 99
            joined=tu.get('joinedTo') is not None
            enwm={n for n in wmset if sideof.get(n)==enemy}
            for r in acts:
                if r.get('side')!=side or r['phase']!='Shooting': continue
                t=r['turn']
                kind=None
                if r['type'] in ('WarMachineShot','Shooting') and r.get('actor') in wmset: kind='wm'
                elif r['type']=='SpellCast' and (r.get('actor') or '').split(' (')[0] in missile_wiz[side] and r.get('target'): kind='mm'
                elif r['type']=='Shooting': kind='sh'
                if not kind: continue
                C[kind+' all']+=1; C[kind+' at wm']+= r.get('target') in enwm
                if t>tdead: continue
                free = (not joined) and not (topn & fought.get(t-1,set())) and not (topn & fought.get(t,set()) and not (topn & charged.get(t,set())))
                C[kind+' shots alive']+=1
                if free:
                    C[kind+' shots free']+=1; C[kind+' at top when free']+= r.get('target') in topn
for k in ('plan','main'):
    C=out[k]; print('==',k)
    for kind,lab in (('wm','war machine shots'),('mm','magic missiles'),('sh','other shooting')):
        a,f,t=C[kind+' shots alive'],C[kind+' shots free'],C[kind+' at top when free']
        print(f"  {lab}: at enemy war machines {C[kind+' at wm']/max(1,C[kind+' all']):.0%} of {C[kind+' all']};", end='')
        print(f"  {lab}: top free {f/max(1,a):.0%} of {a}; at top when free {t/max(1,f):.0%} ({t} of {f})")
    print(f"  top killer dead by r3 {C['top dead by r3']/C['top']:.0%} ({C['top dead by r3']} of {C['top']}); dead at all {C['top dead at all']/C['top']:.0%}; dearest dead by r3 {C['dearest dead by r3']/C['dearest']:.0%} of {C['dearest']}")
print(out['x'])
# shooting-heavy split, paired by pair+army arm
by=collections.defaultdict(dict)
for a in army_rows: by[(a['pair'],a['army'],a['heavy'])].setdefault(a['key'],[]).append(a['margin'])
for h in (True,False):
    d=[];pl=[];mn=[]
    for (p,ar,hv),v in by.items():
        if hv!=h or 'plan' not in v or 'main' not in v: continue
        for x,y in zip(v['plan'],v['main']): d.append(x-y); pl.append(x); mn.append(y)
    print(f"heavy={h}: army-games paired {len(d)}: plan {st.mean(pl):+.0f} main {st.mean(mn):+.0f} diff {st.mean(d):+.0f} ±{band(d):.0f}; better/worse {sum(x>0 for x in d)}/{sum(x<0 for x in d)}")
print('heavy share of army-games', sum(a['heavy'] for a in army_rows)/len(army_rows), len(army_rows))

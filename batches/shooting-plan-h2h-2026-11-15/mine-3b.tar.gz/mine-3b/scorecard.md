# Doctrine scorecard: sp-h2h-mine-89601ea-p3b

### Scorecard: sp-h2h-mine-89601ea-p3b

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L1831 | 1 | 1 | Mine | no | 4 | 3 | 5 | 0 | 1 | 0 | 0 | 0 |
| L1831 | 1 | 1 | Opponent | no | 1 | 2 | 3 | 0 | 2 | 0 | 0 | 170 |
| L1932 | 6 | 1 | Mine | no | 3 | 2 | 1 | 0 | 0 | 0 | 0 | 0 |
| L1932 | 6 | 1 | Opponent | no | 0 | 2 | 4 | 3 | 0 | 0 | 0 | 170 |
| L2033 | 5 | 1 | Mine | yes | - | - | 0 | 5 | 0 | 0 | 0 | 210 |
| L2033 | 5 | 1 | Opponent | yes | - | 5 | 2 | 2 | 0 | 0 | 0 | 0 |
| L2223 | 3 | 1 | Mine | no | 1 | 1 | 6 | 0 | 3 | 0 | 0 | 72 |
| L2223 | 3 | 1 | Opponent | no | 0 | 2 | 5 | 1 | 4 | 0 | 0 | 90 |
| L2327 | 5 | 1 | Mine | yes | - | 2 | 3 | 0 | 0 | 0 | 0 | 70 |
| L2327 | 5 | 1 | Opponent | yes | - | 2 | 8 | 1 | 1 | 0 | 0 | 0 |
| L2433 | 3 | 1 | Mine | no | 0 | 4 | 5 | 0 | 0 | 0 | 0 | 0 |
| L2433 | 3 | 1 | Opponent | no | 0 | 2 | 6 | 1 | 0 | 0 | 0 | 0 |
| L2630 | 2 | 1 | Mine | - | - | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L2630 | 2 | 1 | Opponent | - | - | 2 | 6 | 2 | 0 | 0 | 0 | 0 |
| L2832 | 6 | 1 | Mine | no | 4 | 2 | 0 | 0 | 2 | 0 | 0 | 0 |
| L2832 | 6 | 1 | Opponent | no | 2 | 1 | 2 | 3 | 0 | 0 | 0 | 0 |
| L3133 | 1 | 1 | Mine | no | 6 | 3 | 4 | 1 | 2 | 0 | 0 | 170 |
| L3133 | 1 | 1 | Opponent | no | 4 | 4 | 2 | 3 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 25% | 3.0 | 2.4 | 3.1 | 0.8 | 0.9 | 0.0 | 0.0 | 58.0 |
| **Average** | | | Opponent | 25% | 1.2 | 2.4 | 4.2 | 1.8 | 0.8 | 0.0 | 0.0 | 47.8 |

### KPIs: sp-h2h-mine-89601ea-p3b

Rules off - Opponent only: STAY WORTH, BEST MOVE FOR SHOOTERS, FACE THE CAST, WIZARD FRONT RANK, FIRE PLAN, FIRE IN ORDER, KEEPS THE TARGET, MISSILES IN THE FIRE PLAN, THREAT AT FULL SIZE, SHOOTERS ARE THREATS, SHOOTERS TO THE PRIMARY.

Morten 2026-11-10; 9 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 48) | 31% (14 of 45) | 15% (14 of 93) |
| Winner chose to follow up after the loser gave ground |  | 96% (22 of 23); on the table 100% | 100% (23 of 23); on the table 100% | 98% (45 of 46); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | 100% (2 of 2); on the table 100% | - | 100% (2 of 2); on the table 100% |
| Winner chose to pursue after the loser fled |  | 100% (8 of 8); on the table 100% | 44% (4 of 9); on the table 56% | 71% (12 of 17); on the table 76% |
| Winner chose to follow up or pursue (all three) |  | 97% (32 of 33); on the table 100% | 84% (27 of 32); on the table 88% | 91% (59 of 65); on the table 94% |
| Magic missiles tried each own turn | 50%+ | 25% (12 of 48) | 17% (2 of 12) | 23% (14 of 60) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 31% (12 of 39) | 50% (2 of 4) | 33% (14 of 43) |
|   fighting wizards (on a monster, chariot or monstrous mount) | 50%+ | 25% (9 of 36) | 17% (1 of 6) | 24% (10 of 42) |
|     round 1 |  | 33% (2 of 6) | 100% (1 of 1) | 43% (3 of 7) |
|     rounds 2+ |  | 23% (7 of 30) | 0% (0 of 5) | 20% (7 of 35) |
|   other wizards | 50%+ | 25% (3 of 12) | 17% (1 of 6) | 22% (4 of 18) |
|     round 1 |  | 50% (1 of 2) | 0% (0 of 1) | 33% (1 of 3) |
|     rounds 2+ |  | 20% (2 of 10) | 20% (1 of 5) | 20% (3 of 15) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 38% (5 of 13) | 53% (17 of 32) | 49% (22 of 45) |
| Points that never fought | lower | 19% (3024 of 16106) | 29% (5304 of 17998) | 24% (8328 of 34104) |
|   infantry points that never fought | lower | 29% (771 of 2638) | 41% (1315 of 3240) | 35% (2086 of 5878) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 58% (33 of 57) | 55% (41 of 75) | 56% (74 of 132) |
| Bound items with a magic missile used (at least once a game) |  | 100% (2 of 2); 0.9 uses a game | 100% (7 of 7); 3.1 uses a game | 100% (9 of 9); 2.0 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 50% (1 of 2); 0.1 uses a game | 25% (1 of 4); 0.1 uses a game | 33% (2 of 6); 0.1 uses a game |
|   their share of the points of units over 100 pts | lower | 55% (7745 of 14071) | 50% (8092 of 16284) | 52% (15837 of 30355) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.3 (33%) | 0.2 (20%) | 1.6 (30%) |
| MARCHED: its unit marched | 0.8 (19%) | 0.0 (0%) | 0.8 (15%) |
| CHARGED: its unit charged | 0.2 (6%) | 0.0 (0%) | 0.2 (4%) |
| IN COMBAT: engaged in combat | 0.6 (14%) | 0.4 (40%) | 1.0 (20%) |
| REAR RANK: in a rear rank | 0.2 (6%) | 0.0 (0%) | 0.2 (4%) |
| GONE: slain | 0.2 (6%) | 0.4 (40%) | 0.7 (13%) |
| OFF THE TABLE: off the table or not arrived | 0.2 (6%) | 0.0 (0%) | 0.2 (4%) |
| NOT OFFERED: not in the cast list | 0.4 (11%) | 0.0 (0%) | 0.4 (9%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 5.7 | 0.8 | 0.9 | 1.6 | 1.3 | 0.7 |
| not cast | 5.7 | 1.7 | 2.4 | 5.1 | 1.0 | 16.7 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.1 (7%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.1 (2%) | 0.7 (40%) | 0.1 (5%) | 1.6 (30%) | 0.0 (0%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.8 (15%) | 0.2 (22%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (4%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.2 (4%) | 0.1 (7%) | 0.2 (9%) | 1.0 (20%) | 0.1 (11%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.7 (12%) | 0.0 (0%) | 0.7 (27%) | 0.2 (4%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (0%) | 0.1 (7%) | 0.0 (0%) | 0.0 (0%) | 0.1 (11%) | 0.4 (3%) |
| GONE: slain | 1.1 (20%) | 0.2 (13%) | 0.6 (23%) | 0.7 (13%) | 0.2 (22%) | 2.0 (12%) |
| OFF THE TABLE: off the table or not arrived | 0.4 (8%) | 0.0 (0%) | 0.0 (0%) | 0.2 (4%) | 0.0 (0%) | 0.6 (3%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (33%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.4 (9%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 3.1 (55%) | 0.6 (33%) | 0.9 (36%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 12.6 (75%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.8 a game | 0.1 a game | 0.4 a game |
| stood (cast and not dispelled) | 100% (4 of 4) | 0% (0 of 1) | 80% (4 of 5) |
| the unit moved after it | 75% (3 of 4) | - | 75% (3 of 4) |
| it charged on its next turn | 0% (0 of 4) | - | 0% (0 of 4) |
| the enemy charged it first | 0% (0 of 4) | - | 0% (0 of 4) |
| it fought by the end of its next turn | 0% (0 of 4) | - | 0% (0 of 4) |
| it moved out of a charge the enemy had planned (not charged first) | 25% (1 of 4) | - | 25% (1 of 4) |
| none of these (no charge, no fight, no charge escaped) | 75% (3 of 4) | - | 75% (3 of 4) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 56% (64 of 114) | 54% (82 of 153) | 55% (146 of 267) |
|   cavalry | 80% (8 of 10) | 63% (24 of 38) | 67% (32 of 48) |
|   character | 29% (5 of 17) | 19% (8 of 43) | 22% (13 of 60) |
|   chariot | 88% (15 of 17) | - | 88% (15 of 17) |
|   infantry | 45% (26 of 58) | 69% (50 of 72) | 58% (76 of 130) |
|   monster | 83% (10 of 12) | - | 83% (10 of 12) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.6 (28%) | 1.4 (18%) | 3.0 (22%) |
| CHARGED: it charged | 0.8 (14%) | 2.6 (32%) | 3.3 (25%) |
| FLEEING: it fled or was fleeing | 0.0 (0%) | 0.1 (1%) | 0.1 (1%) |
| IN COMBAT: it fought this turn or the last | 0.8 (14%) | 1.3 (17%) | 2.1 (16%) |
| NO TARGET IN RANGE | 0.8 (14%) | 0.7 (8%) | 1.4 (11%) |
| ONLY IN COMBAT: the only targets were in combat | 0.3 (6%) | 0.4 (6%) | 0.8 (6%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.2 (22%) | 1.3 (17%) | 2.6 (19%) |
| SHELTERED: the target was sheltered | 0.1 (2%) | 0.0 (0%) | 0.1 (1%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 5.0 | 1.0 | 80% | 5.9 pts | 29 pts |
| character | 1.6 | 0.7 | 64% | 12.9 pts | 20 pts |
| chariot | 1.7 | 0.6 | 80% | 8.3 pts | 14 pts |
| infantry | 14.4 | 7.0 | 70% | 7.6 pts | 110 pts |
| monster | 1.1 | 0.4 | 70% | 14.4 pts | 16 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.6 | 6.8 | 5.7 |
| Charges that made contact a game | 3.2 | 6.1 | 4.7 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.00 declared, 0.75 contact (4 units) | 0.00 declared, 0.00 contact (1 units) | 0.80 declared, 0.60 contact (5 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 1.67 declared, 1.67 contact (3 units) | 1.67 declared, 1.67 contact (3 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.56 declared, 0.39 contact (66 units) | 0.77 declared, 0.68 contact (73 units) | 0.67 declared, 0.55 contact (139 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 43% (9 of 21) | 75% (3 of 4) | 67% (2 of 3) | 50% (14 of 28) |
| Character in a unit | 70% (7 of 10) | 100% (6 of 6) | 50% (2 of 4) | 75% (15 of 20) |
| Character on its own | 83% (10 of 12) | 100% (3 of 3) | 28% (5 of 18) | 55% (18 of 33) |
| Chariot | 50% (1 of 2) | - | - | 50% (1 of 2) |
| Infantry | 70% (7 of 10) | 27% (3 of 11) | 100% (1 of 1) | 50% (11 of 22) |
| Monster | 69% (9 of 13) | 25% (1 of 4) | - | 59% (10 of 17) |
| Monstrous | 60% (3 of 5) | 40% (2 of 5) | - | 50% (5 of 10) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Ogre Kingdoms | 1 | 50% (1 of 2); on the table 100% | 0% (0 of 6) | 21% | 57% (4 of 7) | 100% (1 of 1); 4.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 1 | 100% (2 of 2); on the table 100% | 17% (1 of 6) | 0% | 62% (5 of 8) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Skaven | 1 | 100% (2 of 2); on the table 100% | 0% (0 of 6) | 65% | 71% (5 of 7) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Tomb Kings of Khemri | 3 | 100% (16 of 16); on the table 100% | - | 13% | 55% (6 of 11) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 3 | 100% (10 of 10); on the table 100% | 22% (4 of 18) | 13% | 61% (11 of 18) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 6 | 80% (20 of 25); on the table 84% | 44% (8 of 18) | 30% | 45% (23 of 51) | 100% (2 of 2); 1.0 uses a game | 0.0 uses a game | 100% (1 of 1); 0.2 uses a game |
| Wood Elf Realms | 3 | 100% (8 of 8); on the table 100% | 17% (1 of 6) | 31% | 67% (20 of 30) | 100% (6 of 6); 8.7 uses a game | 0.0 uses a game | 0% (0 of 3); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (sp-h2h-mine-89601ea-p3b, 9 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 45% (14) | 41% (12) | 43% (26) |
| ...free all their last turn and able to turn (per game) | 0.67 | 0.44 | 1.11 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.22 | 0.44 | 0.67 |
| ...with the charger already in that arc before they moved (per game) | 0.33 | 0.22 | 0.56 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.78 | 1.78 | 2.56 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.67 | 0.56 | 1.22 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 6.33 | 5.67 | 12.00 |

### Quality by phase: sp-h2h-mine-89601ea-p3b

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.0 | 2.9 |
| Strategy | Charge objectives carried out (made contact) | 60% (21 of 35) | 60% (32 of 53) |
| Strategy | Shoot objectives carried out (shot that target) | 34% (12 of 35) | 55% (24 of 44) |
| Strategy | Close-in objectives charged next turn | 19% (8 of 43) | 26% (12 of 46) |
| Strategy | Support requests answered (helper made contact too) | 20% (1 of 5) | 44% (4 of 9) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (1 of 1) | - |
| Strategy | Hexes on a unit its side charged or shot that turn | 0% (0 of 2) | - |
| Strategy | Joined characters whose unit fought | 71% (5 of 7) | 60% (9 of 15) |
| Strategy | Lone characters that fought | 81% (17 of 21) | 94% (17 of 18) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 0.8 | 1.8 |
| Movement | Points that never moved of their own | 58.0 | 47.8 |
| Movement | Fights charged into per game | 3.7 | 4.9 |
| Movement | Charges with odds: long shots (under 50%) | 7 of 29, net +11 | 6 of 37, net +46 |
| Movement | Charges with odds: sweet spot (55-75%) | 6 of 29, net +99 | 4 of 37, net +67 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 2 of 29, net +30 | 3 of 37, net +37 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 6 of 29, net +138 | 15 of 37, net +164 |
| Shooting | Shots by shooting units (incl. breath weapons) | 8.0 | 12.6 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 15% (11 of 72) | 36% (41 of 113) |
| Shooting | Points destroyed by shooting units | 35.1 | 13.9 |
| Shooting | Points destroyed by war machines | 18.9 | 0.0 |
| Magic | Magic missiles cast | 1.2 | - |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 18% (2 of 11) | - |
| Magic | Wounds caused by magic missiles | 1.9 | 0.7 |
| Magic | Wounds caused by other spells | 0.9 | 0.2 |
| Magic | Points destroyed by magic (all spells) | 26.7 | 22.1 |
| Magic | Augments / hexes / assailments / vortexes cast | 2.1 / 0.2 / 0.2 / 0.0 | 1.7 / 0.1 / 0.2 / 1.3 |
| Combat | Points destroyed in combat | 415.6 | 540.2 |
| Combat | Points run down | 84.6 | 26.3 |
| Combat | Net points per charged fight, damage counted | +64 | +73 |
| Combat | Net per 100 charger points, damage counted | +29.7 | +27.4 |
| Combat | First round won (charged fights) | 52% | 75% |
| Combat | Net points per charged fight | +50 | +77 |
| Combat | Net points per supported fight / lone fight | +208 / +45 | +243 / +56 |
| Combat | Charged fights on a top-3 enemy unit | 8 of 33 | 19 of 44 |
| Game | Points lost | 786.1 | 579.4 |
| Game | VP from objectives | 423.3 | 531.1 |
| Game | Lone holders (player turns) | 3.0 | 1.2 |

- Mine won / drew / lost: 1 / 3 / 5 of 9 ended games (of 9); mean margin (Mine - Opponent) -302 VP
- The side that went first won 3 of 6 games with a winner
- Points traded per game (both sides' losses): 1366
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: sp-h2h-mine-89601ea-p3b

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | 0.3 | +1.3 | 0.0 | 0.0 | 0.9 | +4.4 | 0.0 | 21.7 |
| BEST FACING | 0.1 | +6.3 | 0.0 | 0.0 | 0.7 | +18.9 | 0.0 | 12.9 |
| BEST FIRST | 4.8 | +147.8 | 2.1 | 119.4 | 2.2 | +138.9 | 14.7 | 82.0 |
| BEST MOVE FOR SHOOTERS | 1.1 | +109.1 | 0.0 | 40.1 | - | - | - | - |
| BEST OVERALL | 0.1 | +3.5 | 0.0 | 0.0 | 0.3 | +24.8 | 0.0 | 20.7 |
| BEST PREY | 0.8 | +41.9 | 0.0 | 20.6 | 0.6 | +31.0 | 44.4 | 0.0 |
| BIG CHARACTER SAFETY | - | - | - | - | 0.1 | +0.8 | 0.0 | 0.0 |
| BLOCKED WHEEL | 0.1 | +0.0 | 0.0 | 0.0 | 0.4 | +9.6 | 0.0 | 0.0 |
| CAST JOB | 0.2 | +3.6 | 26.2 | 0.0 | 1.2 | +48.3 | 17.9 | 0.0 |
| CASTER AWAY FROM SCREEN | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CASTING BLOCK | 0.3 | +17.9 | 0.0 | 0.0 | 0.2 | +2.4 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 0.7 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CHAFF PASSED | - | - | - | - | 0.2 | -0.2 | 47.9 | 0.0 |
| CHARGE NOW FIRST | 2.3 | +0.0 | 277.8 | 114.3 | 2.8 | +0.0 | 258.4 | 51.1 |
| CHARGE NOW WEIGHED | 0.3 | -95.0 | 0.0 | 0.0 | 0.4 | -48.2 | 0.0 | 47.8 |
| CHEAP HELPER | 0.1 | +0.0 | 23.1 | 12.9 | 0.2 | +0.0 | 13.3 | 0.0 |
| COMBAT PIVOT | 1.0 | +0.0 | 95.0 | 72.2 | 0.2 | +0.0 | 52.2 | 21.7 |
| CONVEYANCE SEARCH | 0.3 | +43.8 | 0.0 | 0.0 | 0.1 | +0.3 | 0.0 | 0.0 |
| COUNTER-CHARGE COVER | 6.2 | +337.5 | 0.0 | 76.4 | 5.6 | +273.7 | 0.0 | 97.6 |
| DEFENSIVE ARMY | - | - | - | - | 0.3 | +0.0 | 12.0 | 0.0 |
| DEFENSIVE FLOOR | 0.4 | +17.3 | 0.0 | 0.0 | - | - | - | - |
| EDGE GIVE GROUND | 0.1 | +3.5 | 0.0 | 6.7 | 0.1 | +5.8 | 0.0 | 21.7 |
| ELIXIR WORTH | 0.1 | +0.3 | 0.0 | 38.9 | - | - | - | - |
| FACE THE CAST | 0.1 | +0.1 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 0.8 | +45.4 | 0.0 | 0.0 | 1.8 | +183.7 | 0.0 | 20.7 |
| FALLBACK BY WORTH | 6.1 | +65.1 | 0.0 | 148.7 | 5.4 | +63.1 | 0.0 | 56.8 |
| FIGHT LIFT | 0.1 | +0.6 | 3.3 | 0.0 | - | - | - | - |
| FIRE IN ORDER | 0.2 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FIRE PLAN | 8.7 | +85.6 | 362.4 | 166.8 | - | - | - | - |
| FLANK NOT WEIGHED | 4.8 | +0.0 | 0.0 | 116.8 | 4.9 | +0.0 | 0.0 | 52.0 |
| FOLLOW UP WEIGHED | 2.1 | +256.8 | 0.0 | 117.6 | 1.3 | +194.2 | 0.0 | 51.1 |
| FRIENDS SHOTS CHECKED | - | - | - | - | 0.4 | +59.9 | 0.0 | 0.0 |
| GIVES UP | 0.1 | -0.1 | 0.0 | 0.0 | - | - | - | - |
| HELPER ALREADY ASKED | - | - | - | - | 0.2 | +0.0 | 6.7 | 12.0 |
| HELPER UNSEEN | 0.4 | +0.0 | 47.9 | 47.9 | 0.3 | +0.0 | 35.0 | 0.0 |
| HILL BY ITS CHANCE | - | - | - | - | 0.7 | -27.9 | 0.0 | 41.0 |
| HOLDS AMBUSHERS | 0.7 | +0.0 | 0.0 | 0.0 | 0.9 | +0.0 | 0.0 | 0.0 |
| HORN WORTH | - | - | - | - | 0.2 | +3.2 | 0.0 | 0.0 |
| HUNT ADVANCE | 0.1 | +0.7 | 21.7 | 10.0 | - | - | - | - |
| HUNT IN PAIRS | 0.4 | +13.2 | 0.0 | 21.7 | 0.8 | +11.5 | 0.0 | 29.4 |
| HUNT RESULT | 0.1 | +23.5 | 0.0 | 10.0 | - | - | - | - |
| HUNT THE GUNS | 0.1 | +24.5 | 21.7 | 10.0 | - | - | - | - |
| INVITES THE FIGHT | 0.6 | +13.3 | 15.9 | 0.0 | 1.3 | +19.7 | 34.0 | 7.8 |
| KEEPS ITS TARGET | 1.6 | +46.7 | 147.7 | 39.6 | 2.2 | +66.7 | 167.4 | 18.7 |
| KEEPS THE TARGET | 0.7 | -7.0 | 21.7 | 46.7 | - | - | - | - |
| KILLS COUNT | 1.9 | +63.5 | 120.8 | 54.6 | 2.4 | +111.6 | 175.8 | 54.3 |
| KILLS COUNT NEXT TURN | 7.4 | +306.8 | 269.0 | 168.3 | 8.9 | +302.9 | 254.6 | 102.8 |
| LONE CHARACTER SAFE SPOT | - | - | - | - | 0.3 | +0.0 | 7.3 | 0.0 |
| LONE WIZARD HOLDS BACK | 0.8 | +0.0 | 52.4 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| LONE WIZARD KEPT IN | 0.4 | +15.4 | 0.0 | 0.0 | 0.1 | +2.5 | 0.0 | 0.0 |
| LONG SHOT | 0.6 | -3.8 | 0.0 | 6.7 | 0.2 | -0.4 | 0.0 | 0.0 |
| LOST CHARGE | 2.6 | -56.0 | 120.2 | 72.3 | 2.6 | -43.0 | 13.3 | 47.8 |
| MAKE SURE TOGETHER | 0.8 | +76.0 | 0.0 | 17.9 | 0.3 | +10.0 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.1 | +0.7 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | 0.4 | +12.5 | 0.0 | 0.0 | - | - | - | - |
| MARCH ODDS | 0.3 | +22.9 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 0.7 | +61.9 | 0.0 | 0.0 | 0.2 | -8.8 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 5.1 | +206.7 | 0.0 | 95.0 | 6.4 | +167.8 | 0.0 | 91.1 |
| MISSILES IN THE FIRE PLAN | 1.7 | +95.3 | 74.6 | 0.0 | - | - | - | - |
| MISSILES IN THE MOVE | 2.7 | +44.7 | 0.0 | 43.7 | 3.6 | +84.0 | 0.0 | 35.1 |
| MISSILES NEXT TURN | 3.8 | +32.4 | 0.0 | 87.3 | 3.4 | +44.0 | 0.0 | 35.1 |
| MONSTER WIZARD ROAMS | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE AND CAST | 0.2 | +6.6 | 0.0 | 0.0 | 0.7 | +33.5 | 0.0 | 23.1 |
| MOVE SPELL SPOT | 0.4 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE TO CHARGE | 3.8 | +217.1 | 122.2 | 92.0 | 3.7 | +566.3 | 123.9 | 23.8 |
| MOVES UNITS SPELL | 0.1 | +0.5 | 0.0 | 0.0 | - | - | - | - |
| NEEDED THERE | 0.2 | +15.7 | 0.0 | 0.0 | - | - | - | - |
| NOT NEEDED | - | - | - | - | 0.3 | -92.5 | 43.7 | 7.0 |
| NOT TURNED | 6.3 | +96.6 | 0.0 | 186.6 | 5.7 | +13.8 | 0.0 | 51.2 |
| NOT WORTH A CAST | 1.0 | -0.7 | 0.0 | 10.6 | 2.3 | -3.4 | 0.0 | 26.0 |
| OFF BEST | 13.2 | -723.8 | 23.1 | 221.4 | 13.9 | -916.2 | 0.0 | 155.1 |
| OPENS A LANE | 0.2 | +1.2 | 0.0 | 0.0 | - | - | - | - |
| OPENS UP | 0.2 | +4.2 | 0.0 | 0.0 | 0.2 | +30.7 | 7.8 | 21.7 |
| OVERRUNS AWAY | 0.1 | +0.7 | 2.1 | 0.0 | 0.1 | +5.5 | 0.0 | 0.0 |
| PATHS CROSS | 2.8 | +139.1 | 0.0 | 7.2 | 3.2 | +359.2 | 0.0 | 18.7 |
| PIVOT GUARDS FLANK | 0.1 | -0.8 | 0.0 | 0.0 | 0.2 | -0.8 | 0.0 | 0.0 |
| PLAN RESULT | 35.9 | +995.8 | 1143.1 | 1052.8 | 38.4 | +860.0 | 1067.3 | 678.6 |
| PURSUES BIG PREY | - | - | - | - | 0.1 | -3.5 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE NEXT TURN | 0.2 | +19.4 | 0.0 | 0.0 | - | - | - | - |
| RANDOM MOVE BY FIGURES | 1.4 | +3.6 | 0.0 | 37.8 | 3.6 | +30.3 | 0.0 | 18.9 |
| RANDOM MOVER NO PROMISE | 0.3 | -46.2 | 0.0 | 18.9 | 1.6 | -83.2 | 24.6 | 0.0 |
| REDIRECT BY WHAT IT STOPS | 0.1 | -2.4 | 0.0 | 0.0 | 1.1 | -55.0 | 0.0 | 2.1 |
| REDIRECT COUNTER | 3.7 | +155.1 | 0.0 | 52.8 | 5.6 | +364.0 | 0.0 | 85.0 |
| REDIRECT WEIGHED | 0.2 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 12.1 |
| RESERVE FALL BACK | 0.9 | +15.0 | 0.0 | 7.3 | 1.2 | +104.8 | 0.0 | 19.3 |
| RESTRAINS TO SHOOT | 0.1 | +0.6 | 0.0 | 3.8 | - | - | - | - |
| RISK BY ARC | 2.2 | +85.0 | 101.7 | 41.2 | 3.1 | +67.1 | 252.2 | 57.8 |
| SAFE SURE CHARGE | 0.1 | -10.1 | 12.1 | 0.0 | - | - | - | - |
| SAFER THAN THE JOB | 0.7 | +36.1 | 0.0 | 7.8 | 0.6 | +29.7 | 0.0 | 0.0 |
| SCOUT SPOT | 0.7 | +0.5 | 0.0 | 3.8 | 0.2 | +0.0 | 0.0 | 0.0 |
| SCOUT WAITS | 0.8 | +0.0 | 0.0 | 3.8 | 0.2 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.4 | -3.3 | 0.0 | 8.0 | 0.2 | -11.7 | 0.0 | 5.0 |
| SEARCH SPOT | 3.7 | +123.3 | 0.0 | 33.7 | 2.7 | +148.1 | 0.0 | 30.7 |
| SELF MOVE SPELL | 0.7 | +15.5 | 0.0 | 0.0 | - | - | - | - |
| SET UP TOGETHER | 1.1 | +111.0 | 0.0 | 17.9 | 1.4 | +158.7 | 0.0 | 0.0 |
| SHOOTERS ARE THREATS | 0.9 | +11.4 | 14.7 | 26.1 | - | - | - | - |
| SHOOTERS IN TWO RANKS | 0.1 | +0.4 | 0.0 | 0.0 | 0.1 | +0.6 | 0.0 | 0.0 |
| SHOOTERS TO THE PRIMARY | 3.1 | +88.5 | 0.0 | 155.2 | - | - | - | - |
| SHOOTS FROM THE BEST SPOT | 0.7 | +24.5 | 0.0 | 47.9 | 0.3 | +2.1 | 0.0 | 0.0 |
| SHOT OPTIONS | 10.1 | +0.0 | 245.2 | 195.1 | 9.4 | +0.0 | 221.3 | 76.0 |
| SHOTS IN THE MOVE | 8.8 | +146.4 | 0.0 | 195.1 | 7.8 | +180.2 | 0.0 | 76.0 |
| SPELL SETS UP CHARGE | 0.3 | +144.4 | 0.0 | 0.0 | - | - | - | - |
| SPELL WORTH | 2.2 | +26.1 | 70.3 | 99.0 | 2.1 | +10.9 | 12.0 | 26.0 |
| STABLE ROLE | 7.7 | +0.0 | 342.0 | 144.1 | 9.7 | +0.0 | 121.7 | 128.8 |
| STAY WEIGHED | 0.1 | +0.8 | 0.0 | 0.0 | - | - | - | - |
| STAY WORTH | 6.1 | +48.2 | 153.9 | 93.3 | - | - | - | - |
| STOPS SHORT OF THE FLANK | 0.2 | +8.3 | 0.0 | 0.0 | 0.2 | +24.0 | 0.0 | 0.0 |
| STUCK PIVOT | 0.2 | +0.0 | 0.0 | 0.0 | 0.9 | +0.0 | 0.0 | 0.0 |
| SUPPORT NARROWED | 7.0 | -49.2 | 243.2 | 79.2 | 8.1 | -28.0 | 340.3 | 129.7 |
| SUPPORTS | 4.9 | +49.2 | 138.0 | 25.7 | 4.3 | +28.0 | 115.6 | 29.3 |
| SURE CHARGE BEATS ADVANCE | 0.2 | -8.1 | 15.2 | 38.9 | 0.1 | -3.2 | 6.7 | 10.9 |
| SURE REACH TOGETHER | 0.6 | +21.4 | 0.0 | 17.9 | 0.8 | +3.7 | 0.0 | 2.1 |
| THREAT AT FULL SIZE | 5.7 | +0.0 | 127.3 | 113.7 | - | - | - | - |
| THROUGH LINE OF FIRE | 0.2 | +6.6 | 0.0 | 0.0 | - | - | - | - |
| TURN WORTH | 0.2 | -27.3 | 37.1 | 0.0 | 1.1 | -50.0 | 69.9 | 36.7 |
| TWO OR MORE ARRIVE | 0.3 | +1.4 | 0.0 | 0.0 | 0.8 | +20.8 | 0.0 | 0.0 |
| WAIT AFTER COSTS | 7.1 | -320.5 | 221.6 | 214.7 | 6.6 | -385.5 | 164.6 | 42.4 |
| WALKS TO THE FIGHT | 2.8 | +85.2 | 83.4 | 143.2 | 1.1 | +15.5 | 0.0 | 0.0 |
| WAR ENGINE CHARGES | - | - | - | - | 0.2 | +7.7 | 13.3 | 0.0 |
| WAR ENGINE JOBS | 0.3 | +0.0 | 21.7 | 20.6 | - | - | - | - |
| WEARS DOWN | 1.1 | +43.3 | 120.2 | 54.1 | 1.4 | +141.8 | 94.7 | 28.7 |
| WHO HITS BACK | 0.3 | +34.4 | 0.0 | 12.9 | - | - | - | - |
| WHOLE FIGHT | 0.6 | +8.2 | 10.9 | 0.0 | 0.8 | +6.9 | 56.8 | 2.1 |
| WHOLE FIGHT GAIN | 0.4 | +24.6 | 11.1 | 0.0 | 0.6 | +39.5 | 6.7 | 29.3 |

### Rule changes: sp-h2h-mine-89601ea-p3b

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 244 | 244 | 244 | 27.11 | -14760 | -60.5 |
| BEST FIRST | 63 | 63 | 63 | 7.00 | +2580 | +40.9 |
| SEARCH SPOT | 57 | 57 | 57 | 6.33 | +2444 | +42.9 |
| PATHS CROSS | 54 | 54 | 54 | 6.00 | +4484 | +83.0 |
| KILLS COUNT NEXT TURN | 147 | 147 | 35 | 3.89 | +829 | +23.7 |
| MOVE TO CHARGE | 67 | 67 | 34 | 3.78 | +2783 | +81.9 |
| FIRE PLAN | 78 | 78 | 32 | 3.56 | +456 | +14.3 |
| FOLLOW UP WEIGHED | 31 | 31 | 31 | 3.44 | +4059 | +130.9 |
| COUNTER-CHARGE COVER | 106 | 60 | 29 | 3.22 | +727 | +25.1 |
| SHOTS IN THE MOVE | 149 | 91 | 29 | 3.22 | +446 | +15.4 |
| SUPPORTS | 83 | 83 | 26 | 2.89 | +189 | +7.3 |
| FACES THE THREAT | 23 | 23 | 23 | 2.56 | +2063 | +89.7 |
| FALLBACK BY WORTH | 104 | 104 | 22 | 2.44 | +1154 | +52.4 |
| RANDOM MOVE BY FIGURES | 45 | 45 | 22 | 2.44 | +305 | +13.9 |
| REDIRECT COUNTER | 83 | 43 | 19 | 2.11 | +1701 | +89.5 |
| RESERVE FALL BACK | 19 | 19 | 19 | 2.11 | +1079 | +56.8 |
| MAX FOR POSITIONING | 104 | 63 | 18 | 2.00 | +201 | +11.2 |
| WALKS TO THE FIGHT | 35 | 35 | 18 | 2.00 | +261 | +14.5 |
| HOLDS AMBUSHERS | 14 | 14 | 14 | 1.56 | +0 | +0.0 |
| SET UP TOGETHER | 23 | 18 | 13 | 1.44 | +1136 | +87.4 |
| CHARGE NOW FIRST | 46 | 46 | 12 | 1.33 | -868 | -72.4 |
| ADVANCE LANE KEPT | 11 | 11 | 11 | 1.22 | +0 | +0.0 |
| CAST JOB | 13 | 13 | 11 | 1.22 | +218 | +19.8 |
| COMBAT PIVOT | 11 | 11 | 11 | 1.22 | +0 | +0.0 |
| KILLS COUNT | 39 | 39 | 11 | 1.22 | +446 | +40.5 |
| SAFER THAN THE JOB | 11 | 11 | 11 | 1.22 | +592 | +53.8 |
| BEST MOVE FOR SHOOTERS | 10 | 10 | 10 | 1.11 | +982 | +98.2 |
| RISK BY ARC | 48 | 47 | 10 | 1.11 | +190 | +18.9 |
| STUCK PIVOT | 10 | 10 | 10 | 1.11 | +0 | +0.0 |
| WAIT AFTER COSTS | 123 | 123 | 10 | 1.11 | +206 | +20.6 |
| INVITES THE FIGHT | 17 | 17 | 9 | 1.00 | +84 | +9.4 |
| SCOUT WAITS | 9 | 9 | 9 | 1.00 | +0 | +0.0 |
| MISSILES IN THE MOVE | 56 | 33 | 8 | 0.89 | +105 | +13.1 |
| MOVE AND CAST | 8 | 8 | 8 | 0.89 | +362 | +45.2 |
| WEARS DOWN | 23 | 21 | 8 | 0.89 | +552 | +69.0 |
| BEST FACING | 7 | 7 | 7 | 0.78 | +227 | +32.4 |
| CHARGE NOW WEIGHED | 7 | 7 | 7 | 0.78 | +1246 | +178.0 |
| KEEPS ITS TARGET | 34 | 34 | 7 | 0.78 | +97 | +13.8 |
| BLOCKED WHEEL | 5 | 5 | 5 | 0.56 | +86 | +17.3 |
| LONE WIZARD KEPT IN | 5 | 5 | 5 | 0.56 | +162 | +32.3 |
| BEST OVERALL | 4 | 4 | 4 | 0.44 | +254 | +63.6 |
| CASTING BLOCK | 5 | 5 | 4 | 0.44 | +57 | +14.4 |
| FRIENDS SHOTS CHECKED | 4 | 4 | 4 | 0.44 | +539 | +134.7 |
| LONE WIZARD HOLDS BACK | 9 | 9 | 4 | 0.44 | -220 | -55.1 |
| MARCH CHECK | 4 | 4 | 4 | 0.44 | +108 | +26.9 |
| OPENS UP | 4 | 4 | 4 | 0.44 | +67 | +16.6 |
| SHOOTS FROM THE BEST SPOT | 9 | 9 | 4 | 0.44 | +65 | +16.2 |
| STAY WORTH | 55 | 44 | 4 | 0.44 | +7 | +1.8 |
| STOPS SHORT OF THE FLANK | 4 | 4 | 4 | 0.44 | +290 | +72.6 |
| BEST PREY | 12 | 12 | 3 | 0.33 | +87 | +28.9 |
| CASTS FROM BEHIND | 3 | 3 | 3 | 0.33 | +0 | +0.0 |
| DEFENSIVE FLOOR | 4 | 4 | 3 | 0.33 | +55 | +18.2 |
| MARCH ODDS | 3 | 3 | 3 | 0.33 | -22 | -7.5 |
| MISSILES IN THE FIRE PLAN | 15 | 3 | 3 | 0.33 | +163 | +54.3 |
| PIVOT GUARDS FLANK | 3 | 3 | 3 | 0.33 | -14 | -4.6 |
| REDIRECT WEIGHED | 3 | 3 | 3 | 0.33 | +17 | +5.7 |
| SURE CHARGE BEATS ADVANCE | 3 | 3 | 3 | 0.33 | -102 | -33.9 |
| SURE REACH TOGETHER | 12 | 7 | 3 | 0.33 | +79 | +26.3 |
| WHO HITS BACK | 3 | 3 | 3 | 0.33 | +168 | +56.0 |
| WHOLE FIGHT GAIN | 9 | 9 | 3 | 0.33 | +92 | +30.7 |
| CHAFF PASSED | 2 | 2 | 2 | 0.22 | -1 | -0.7 |
| DEFENSIVE ARMY | 3 | 3 | 2 | 0.22 | -98 | -49.2 |
| FIRE IN ORDER | 2 | 2 | 2 | 0.22 | +0 | +0.0 |
| HORN WORTH | 2 | 2 | 2 | 0.22 | +29 | +14.6 |
| LOST CHARGE | 46 | 46 | 2 | 0.22 | +96 | +48.1 |
| MAKE SURE TOGETHER | 10 | 5 | 2 | 0.22 | +135 | +67.7 |
| NEEDED THERE | 2 | 2 | 2 | 0.22 | +0 | +0.0 |
| RAIDS THE BAGGAGE NEXT TURN | 2 | 2 | 2 | 0.22 | +4 | +2.0 |
| SHOOTERS IN TWO RANKS | 2 | 2 | 2 | 0.22 | +9 | +4.5 |
| SHOOTERS TO THE PRIMARY | 28 | 15 | 2 | 0.22 | +1 | +0.6 |
| SUPPORT NARROWED | 136 | 136 | 2 | 0.22 | -19 | -9.6 |
| THROUGH LINE OF FIRE | 2 | 2 | 2 | 0.22 | +60 | +29.8 |
| WHOLE FIGHT | 12 | 12 | 2 | 0.22 | +22 | +10.8 |
| BIG CHARACTER SAFETY | 1 | 1 | 1 | 0.11 | +7 | +7.2 |
| CASTER AWAY FROM SCREEN | 1 | 1 | 1 | 0.11 | +0 | +0.0 |
| ELIXIR WORTH | 1 | 1 | 1 | 0.11 | +2 | +2.3 |
| FACE THE CAST | 1 | 1 | 1 | 0.11 | +1 | +0.9 |
| HUNT IN PAIRS | 11 | 8 | 1 | 0.11 | +26 | +25.8 |
| KEEPS THE TARGET | 6 | 6 | 1 | 0.11 | -63 | -62.8 |
| MISSILES NEXT TURN | 65 | 39 | 1 | 0.11 | +1 | +0.6 |
| MOVES UNITS SPELL | 1 | 1 | 1 | 0.11 | +4 | +4.3 |
| OVERRUNS AWAY | 2 | 2 | 1 | 0.11 | +6 | +6.3 |
| PURSUES BIG PREY | 1 | 1 | 1 | 0.11 | -32 | -31.8 |
| RESTRAINS TO SHOOT | 1 | 1 | 1 | 0.11 | +5 | +5.1 |
| SAFE SURE CHARGE | 1 | 1 | 1 | 0.11 | -126 | -125.9 |
| STAY WEIGHED | 1 | 1 | 1 | 0.11 | +8 | +7.5 |
| TWO OR MORE ARRIVE | 10 | 10 | 1 | 0.11 | +1 | +0.8 |
| BACKUP TARGETS | 11 | 5 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 7 | trace | - | - | - | - |
| CHEAP HELPER | 3 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 4 | not checked | - | - | - | - |
| EDGE GIVE GROUND | 2 | 2 | 0 | 0.00 | - | - |
| FIGHT LIFT | 1 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 87 | not checked | - | - | - | - |
| GIVES UP | 1 | 1 | 0 | 0.00 | - | - |
| HELPER ALREADY ASKED | 2 | not checked | - | - | - | - |
| HELPER UNSEEN | 7 | 7 | 0 | 0.00 | - | - |
| HILL BY ITS CHANCE | 6 | 6 | 0 | 0.00 | - | - |
| HUNT ADVANCE | 1 | 1 | 0 | 0.00 | - | - |
| HUNT RESULT | 1 | trace | - | - | - | - |
| HUNT THE GUNS | 1 | trace | - | - | - | - |
| LONE CHARACTER SAFE SPOT | 3 | not checked | - | - | - | - |
| LONG SHOT | 7 | 7 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 8 | 8 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 1 | 1 | 0 | 0.00 | - | - |
| MOVE SPELL SPOT | 4 | not checked | - | - | - | - |
| NOT NEEDED | 3 | 3 | 0 | 0.00 | - | - |
| NOT TURNED | 108 | 108 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 30 | not checked | - | - | - | - |
| OPENS A LANE | 2 | 1 | 0 | 0.00 | - | - |
| PLAN RESULT | 669 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 17 | 17 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 11 | 11 | 0 | 0.00 | - | - |
| SCOUT SPOT | 8 | 8 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 6 | 6 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 6 | not checked | - | - | - | - |
| SHOOTERS ARE THREATS | 8 | 8 | 0 | 0.00 | - | - |
| SHOT OPTIONS | 176 | 176 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 3 | not checked | - | - | - | - |
| SPELL WORTH | 39 | not checked | - | - | - | - |
| STABLE ROLE | 156 | 156 | 0 | 0.00 | - | - |
| THREAT AT FULL SIZE | 51 | 51 | 0 | 0.00 | - | - |
| TURN WORTH | 12 | 12 | 0 | 0.00 | - | - |
| WAR ENGINE CHARGES | 2 | 2 | 0 | 0.00 | - | - |
| WAR ENGINE JOBS | 3 | 3 | 0 | 0.00 | - | - |

### Off best figure: sp-h2h-mine-89601ea-p3b

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 11.67 | 12.33 | 61.6 |
| CHARGE NOW FIRST | rule | 0.56 | 0.67 | 78.9 |
| FALLBACK | gate | 0.44 | 0.67 | 38.3 |
| TURN GATE | gate | 0.56 | 0.33 | 16.0 |
| LONE WIZARD HOLDS BACK | rule | 0.33 | 0.11 | 55.1 |
| PIVOT GUARDS FLANK | rule | 0.11 | 0.22 | 4.6 |
| SUPPORT REQUEST | gate | 0.22 | 0.11 | 197.1 |
| SURE CHARGE BEATS ADVANCE | rule | 0.22 | 0.11 | 33.9 |
| AFTERMATH BAND | gate | 0.11 | 0.11 | 2.1 |
| DEFENSIVE ARMY | rule | - | 0.22 | 49.2 |
| LONE CHARACTER SAFE SPOT | gate | - | 0.22 | 152.5 |
| PATHS CROSS | rule | 0.11 | 0.11 | 4.3 |
| SUPPORT NARROWED | rule | - | 0.22 | 9.6 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.11 | - | 20.4 |
| CHAFF PASSED | rule | - | 0.11 | 1.5 |
| CHARGE NOW WEIGHED | rule | - | 0.11 | 26.3 |
| KEEPS THE TARGET | rule | 0.11 | - | 62.8 |
| MARCH ODDS | rule | 0.11 | - | 38.0 |
| NO REASON | gate | 0.11 | - | 11.7 |
| PURSUES BIG PREY | rule | - | 0.11 | 31.8 |
| RULE SWITCHED OFF | gate | - | 0.11 | 3.8 |
| SAFE SURE CHARGE | rule | 0.11 | - | 125.9 |

### Plans: sp-h2h-mine-89601ea-p3b

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 15.8 | 17% | 453 | 360 | 79% |
| Mine | charge | 3.3 | 70% | 220 | 260 | 118% |
| Mine | close in | 4.8 | 23% | 341 | 157 | 46% |
| Mine | hold | 3.4 | 16% | 204 | 0 | 0% |
| Mine | join | 0.2 | 100% | 10 | 0 | 0% |
| Mine | shoot | 3.0 | 67% | 98 | 220 | 224% |
| Mine | support | 5.3 | 88% | 29 | 0 | 0% |
| Opponent | advance | 13.8 | 16% | 291 | 214 | 74% |
| Opponent | charge | 5.3 | 50% | 630 | 443 | 70% |
| Opponent | close in | 5.1 | 28% | 544 | 99 | 18% |
| Opponent | hold | 3.8 | 38% | 276 | 0 | 0% |
| Opponent | join | 1.0 | 89% | 28 | 0 | 0% |
| Opponent | shoot | 4.0 | 39% | 52 | 104 | 200% |
| Opponent | support | 5.4 | 94% | 22 | 0 | 0% |

### Packages: hunt the guns, sp-h2h-mine-89601ea-p3b

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.1 | 1 | 0 | 0% | 100% | 0% | 2.0 | 220 | 212 | 100% | 0 |
| Opponent | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Ogre Kingdoms | 1.0 | 1 | 0 | 0% | 100% | 0% | 2.0 | 220 | 212 | 100% | 0 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Tomb Kings of Khemri | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Vampire Counts | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Warriors of Chaos | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Wood Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |

### Battle groups: sp-h2h-mine-89601ea-p3b

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 6.2 | 20% | 73% | 0% | - | 45% | 9% | 0% | 45% | 0% |
| Mine | REDIRECT COUNTER | 3.7 | 24% | 75% | 38% | 33% | 40% | 0% | 0% | 60% | 0% |
| Opponent | COUNTER-CHARGE COVER | 5.6 | 20% | 60% | 20% | 0% | 50% | 12% | 0% | 38% | 0% |
| Opponent | REDIRECT COUNTER | 5.6 | 30% | 67% | 27% | 100% | 9% | 0% | 18% | 73% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: sp-h2h-mine-89601ea-p3b

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 1 | 0 (1) | 0 | 0 | 100 | 0% | 4.0 | - | 0 (1) | - | 0 (1) | - |
| Mine | Chaff | 19 | 82 (19) | 42 | 40 | 71 | 16% | 2.9 | 104 (11) | 0 (3) | 61 (5) | 111 (14) | 16 (5) |
| Mine | Character | 20 | 32 (20) | 32 | 0 | 36 | 15% | 2.4 | 35 (9) | 31 (9) | - | 38 (10) | 29 (8) |
| Mine | Clean-up | 7 | 15 (7) | 9 | 6 | 24 | 14% | 4.8 | 0 (3) | 26 (4) | - | 13 (5) | 17 (2) |
| Mine | Fast Hammer | 8 | 15 (8) | 2 | 13 | 41 | 0% | 3.4 | 0 (4) | 0 (2) | 68 (2) | 22 (5) | 0 (3) |
| Mine | Fragile | 3 | 10 (3) | 10 | 0 | 33 | 33% | 5.0 | 10 (3) | - | - | 0 (1) | 15 (2) |
| Mine | Hammer | 15 | 50 (15) | 33 | 16 | 36 | 7% | 2.9 | 24 (4) | 52 (10) | 92 (1) | 49 (12) | 51 (3) |
| Mine | Holder | 8 | 70 (8) | 28 | 42 | 64 | 12% | 2.3 | 0 (1) | 6 (3) | 164 (4) | 142 (4) | 8 (4) |
| Mine | Shooter | 2 | 30 (2) | 0 | 30 | 117 | 0% | 1.5 | 81 (1) | 0 (1) | - | 81 (1) | 0 (1) |
| Mine | Wizard | 8 | 23 (8) | 23 | 0 | 36 | 0% | 1.9 | 52 (2) | 0 (2) | 73 (1) | 51 (4) | 0 (1) |
| Opponent | Chaff | 20 | 22 (20) | 22 | 0 | 58 | 40% | 3.0 | 57 (7) | 0 (4) | 20 (9) | 32 (14) | 0 (6) |
| Opponent | Character | 25 | 55 (25) | 55 | 0 | 21 | 20% | 2.0 | 36 (8) | 74 (14) | - | 42 (14) | 84 (8) |
| Opponent | Fast Hammer | 21 | 39 (21) | 20 | 19 | 51 | 29% | 2.6 | 45 (13) | 4 (4) | 61 (4) | 60 (8) | 29 (13) |
| Opponent | Hammer | 15 | 16 (15) | 16 | 0 | 17 | 27% | 3.6 | 0 (5) | 23 (9) | 0 (1) | 33 (8) | 0 (7) |
| Opponent | Holder | 8 | 106 (8) | 33 | 73 | 20 | 38% | 3.8 | 227 (2) | 94 (4) | 58 (2) | 89 (5) | 149 (3) |
| Opponent | Shooter | 9 | 57 (9) | 14 | 42 | 41 | 0% | 1.0 | 0 (1) | 64 (8) | - | 73 (4) | 45 (5) |
| Opponent | Support | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | 0 (1) | - | - | - | 0 (1) |
| Opponent | Wizard | 8 | 19 (8) | 19 | 0 | 35 | 0% | 2.5 | 0 (4) | 40 (4) | - | 11 (4) | 30 (4) |

### Charged fights: sp-h2h-mine-89601ea-p3b

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Ogre Kingdoms | 1 | 286 | 195 | 4.0 | 1.0 | 49 | 77 | -28 | 1 of 4 | 1 of 4 | - | -28 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 272 | 4.0 | 1.0 | 68 | 0 | +68 | 0 of 4 | 3 of 4 | - | +68 |
| Mine | Skaven | 1 | 19 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Mine | Tomb Kings of Khemri | 2 | 90 | 459 | 5.0 | 1.0 | 92 | 51 | +41 | 5 of 10 | 6 of 10 | - | +41 |
| Mine | Vampire Counts | 2 | 49 | 185 | 3.5 | 1.0 | 53 | 9 | +44 | 1 of 7 | 3 of 7 | - | +44 |
| Mine | Warriors of Chaos | 2 | 71 | 448 | 4.0 | 1.1 | 112 | 14 | +97 | 1 of 8 | 4 of 8 | +208 | +82 |
| **Mine** | all armies | 9 | 81 | 294 | 3.7 | 1.0 | 80 | 30 | +50 | 8 of 33 | 17 of 33 | +208 | +45 |
| Opponent | Tomb Kings of Khemri | 1 | 0 | 0 | 5.0 | 1.0 | 0 | 53 | -53 | 3 of 5 | 4 of 5 | - | -53 |
| Opponent | Vampire Counts | 1 | 0 | 971 | 9.0 | 1.2 | 108 | 21 | +87 | 4 of 9 | 8 of 9 | +30 | +103 |
| Opponent | Warriors of Chaos | 4 | 0 | 644 | 4.8 | 1.2 | 136 | 11 | +125 | 10 of 19 | 14 of 19 | +386 | +76 |
| Opponent | Wood Elf Realms | 3 | 108 | 212 | 3.7 | 1.0 | 58 | 11 | +47 | 2 of 11 | 7 of 11 | - | +47 |
| **Opponent** | all armies | 9 | 36 | 465 | 4.9 | 1.1 | 95 | 18 | +77 | 19 of 44 | 33 of 44 | +243 | +56 |

### Effective charges: sp-h2h-mine-89601ea-p3b

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Ogre Kingdoms | 4 | 0 | 0 | 2 (net +0) | 0 | 0 | 0 | 2 | 100% (2 of 2) |
| Mine | Orc & Goblin Tribes | 4 | 0 | 0 | 0 | 0 | 0 | 2 (net +136) | 2 | 0% (0 of 2) |
| Mine | Tomb Kings of Khemri | 10 | 3 (net +51) | 0 | 1 (net +0) | 4 (net +49) | 1 (net +60) | 1 (net +0) | 0 | 10% (1 of 10) |
| Mine | Vampire Counts | 7 | 1 (net +38) | 0 | 2 (net +126) | 3 (net +6) | 1 (net +0) | 0 | 0 | 29% (2 of 7) |
| Mine | Warriors of Chaos | 8 | 3 (net -39) | 0 | 1 (net +342) | 1 (net +0) | 0 | 3 (net +184) | 0 | 12% (1 of 8) |
| Opponent | Tomb Kings of Khemri | 5 | 0 | 0 | 0 | 3 (net -88) | 1 (net +0) | 1 (net +0) | 0 | 0% (0 of 5) |
| Opponent | Vampire Counts | 9 | 2 (net +2) | 0 | 0 | 3 (net +65) | 1 (net +70) | 3 (net +170) | 0 | 0% (0 of 9) |
| Opponent | Warriors of Chaos | 19 | 3 (net +90) | 1 (net +77) | 2 (net +0) | 1 (net +0) | 1 (net +40) | 9 (net +216) | 2 | 12% (2 of 17) |
| Opponent | Wood Elf Realms | 11 | 1 (net +0) | 0 | 2 (net +134) | 1 (net +0) | 0 | 2 (net +0) | 5 | 33% (2 of 6) |

### Charged fights, damage counted: sp-h2h-mine-89601ea-p3b

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 7 | 228 | 243 | +11 | 198 | 102 | +96 | +42.0 |
| Mine | Effective (55-75%) | 6 | 181 | 171 | +99 | 111 | 25 | +87 | +47.8 |
| Mine | 76-89% | 8 | 259 | 152 | +27 | 27 | 2 | +25 | +9.6 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 6 | 197 | 150 | +138 | 138 | 3 | +134 | +68.1 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 2 | 465 | 79 | +30 | 30 | 0 | +30 | +6.5 |
| Mine | No odds | 4 | 58 | 132 | -28 | 56 | 92 | -37 | -62.7 |
| Mine | All fights | 33 | 215 | 168 | +50 | 102 | 38 | +64 | +29.7 |
| Opponent | Long shot (under 50%) | 6 | 241 | 324 | +46 | 117 | 63 | +54 | +22.2 |
| Opponent | 50-54% | 1 | 144 | 77 | +77 | 77 | 0 | +77 | +53.5 |
| Opponent | Effective (55-75%) | 4 | 214 | 287 | +67 | 153 | 171 | -18 | -8.4 |
| Opponent | 76-89% | 8 | 295 | 277 | -9 | 24 | 41 | -16 | -5.5 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 15 | 364 | 183 | +164 | 204 | 28 | +176 | +48.3 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 3 | 270 | 57 | +37 | 37 | 17 | +20 | +7.4 |
| Opponent | No odds | 7 | 95 | 174 | +42 | 66 | 20 | +46 | +49.0 |
| Opponent | All fights | 44 | 267 | 216 | +77 | 119 | 45 | +73 | +27.4 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| sp-h2h-mine-89601ea-p3b | move | 122 | 28 (23%) | 26 (21%) | 14 (11%) | 80 (66%) |
| sp-h2h-mine-89601ea-p3b | objective | 89 | 19 (21%) | 16 (18%) | 11 (12%) | 59 (66%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L2433, L2630 |
| Charmed Shield | Opponent | L2327 |
| Elixir of Power | Mine | L1932 |
| Fistful of Laurels | Mine | L1831 |
| Horn of the Wild Hunt | Opponent | L2033, L2433, L3133 |
| Invocation of Nehek | Mine | L2433 |
| Invocation of Nehek | Opponent | L2327 |
| Periapt of Soul Exchange | Mine | L2033 |
| Ring of Doom | Mine | L3133 |
| Ring of Doom | Opponent | L1831, L2033, L2433, L3133 |

# Doctrine scorecard: sp-h2h-opp-89601ea-p4

### Scorecard: sp-h2h-opp-89601ea-p4

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0114 | 6 | 1 | Mine | no | 6 | 2 | 1 | 2 | 1 | 0 | 0 | 0 |
| L0114 | 6 | 1 | Opponent | no | 0 | 2 | 5 | 0 | 0 | 0 | 0 | 0 |
| L0130 | 4 | 1 | Mine | yes | 5 | - | 0 | 1 | 0 | 0 | 0 | 65 |
| L0130 | 4 | 1 | Opponent | no | 1 | 1 | 9 | 1 | 0 | 0 | 0 | 0 |
| L0214 | 4 | 1 | Mine | no | 3 | 3 | 3 | 2 | 0 | 0 | 0 | 0 |
| L0214 | 4 | 1 | Opponent | no | 4 | 2 | 1 | 0 | 0 | 0 | 0 | 0 |
| L0230 | 2 | 1 | Mine | - | - | 4 | 2 | 4 | 0 | 0 | 0 | 442 |
| L0230 | 2 | 1 | Opponent | - | - | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L0315 | 3 | 1 | Mine | no | 5 | 5 | 1 | 0 | 0 | 0 | 0 | 590 |
| L0315 | 3 | 1 | Opponent | yes | 4 | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L0332 | 2 | 1 | Mine | - | - | 4 | 1 | 1 | 0 | 0 | 0 | 675 |
| L0332 | 2 | 1 | Opponent | - | - | 2 | 4 | 3 | 0 | 0 | 0 | 0 |
| L0417 | 3 | 1 | Mine | yes | 7 | 2 | 8 | 0 | 0 | 0 | 0 | 0 |
| L0417 | 3 | 1 | Opponent | no | 0 | 4 | 4 | 0 | 1 | 0 | 0 | 98 |
| L0434 | 2 | 1 | Mine | - | - | 2 | 2 | 1 | 1 | 0 | 0 | 0 |
| L0434 | 2 | 1 | Opponent | - | - | 1 | 2 | 1 | 1 | 0 | 0 | 107 |
| L0520 | 4 | 1 | Mine | no | 0 | 3 | 0 | 1 | 0 | 0 | 0 | 1331 |
| L0520 | 4 | 1 | Opponent | no | 1 | - | 1 | 3 | 2 | 0 | 0 | 210 |
| L0608 | 2 | 1 | Mine | - | - | - | 1 | 2 | 1 | 0 | 0 | 615 |
| L0608 | 2 | 1 | Opponent | - | - | 5 | 1 | 3 | 0 | 0 | 0 | 605 |
| L0624 | 6 | 1 | Mine | no | 0 | 3 | 3 | 0 | 0 | 0 | 0 | 801 |
| L0624 | 6 | 1 | Opponent | no | 6 | 3 | 2 | 1 | 0 | 0 | 0 | 0 |
| L0713 | 5 | 1 | Mine | no | - | 3 | 3 | 0 | 0 | 0 | 0 | 452 |
| L0713 | 5 | 1 | Opponent | no | - | 2 | 2 | 2 | 1 | 0 | 0 | 479 |
| L0729 | 3 | 1 | Mine | no | 9 | 2 | 2 | 0 | 0 | 0 | 0 | 452 |
| L0729 | 3 | 1 | Opponent | no | 3 | 2 | 2 | 0 | 2 | 0 | 0 | 170 |
| L0819 | 3 | 1 | Mine | no | 0 | 3 | 1 | 0 | 0 | 0 | 0 | 386 |
| L0819 | 3 | 1 | Opponent | yes | 4 | 2 | 0 | 2 | 2 | 0 | 0 | 0 |
| L0835 | 1 | 1 | Mine | no | 0 | - | 0 | 0 | 0 | 0 | 0 | 515 |
| L0835 | 1 | 1 | Opponent | no | 0 | 3 | 3 | 4 | 0 | 0 | 0 | 0 |
| L0926 | 2 | 1 | Mine | - | - | 2 | 2 | 1 | 0 | 0 | 0 | 515 |
| L0926 | 2 | 1 | Opponent | - | - | 2 | 2 | 4 | 0 | 0 | 0 | 0 |
| L1017 | 3 | 1 | Mine | no | 1 | 2 | 5 | 0 | 0 | 0 | 0 | 330 |
| L1017 | 3 | 1 | Opponent | yes | 2 | 2 | 2 | 1 | 1 | 0 | 0 | 322 |
| L1034 | 2 | 1 | Mine | - | - | 1 | 1 | 0 | 1 | 0 | 0 | 330 |
| L1034 | 2 | 1 | Opponent | - | - | 2 | 6 | 2 | 0 | 0 | 0 | 0 |
| L1126 | 4 | 1 | Mine | no | 2 | 2 | 4 | 0 | 0 | 0 | 0 | 330 |
| L1126 | 4 | 1 | Opponent | no | 4 | 2 | 2 | 2 | 1 | 0 | 0 | 0 |
| L1220 | 2 | 1 | Mine | - | - | 3 | 3 | 0 | 1 | 0 | 0 | 330 |
| L1220 | 2 | 1 | Opponent | - | - | 5 | 5 | 3 | 1 | 0 | 0 | 0 |
| L1314 | 6 | 1 | Mine | no | 2 | 2 | 6 | 0 | 0 | 0 | 0 | 302 |
| L1314 | 6 | 1 | Opponent | no | 0 | 2 | 3 | 1 | 1 | 0 | 0 | 0 |
| L1331 | 5 | 1 | Mine | no | - | - | 0 | 2 | 0 | 0 | 0 | 302 |
| L1331 | 5 | 1 | Opponent | yes | - | - | 0 | 4 | 2 | 0 | 0 | 340 |
| L1427 | 5 | 1 | Mine | yes | - | 3 | 2 | 2 | 0 | 0 | 0 | 0 |
| L1427 | 5 | 1 | Opponent | yes | - | 2 | 3 | 2 | 0 | 0 | 0 | 0 |
| L1523 | 5 | 1 | Mine | yes | - | 2 | 4 | 0 | 1 | 0 | 0 | 0 |
| L1523 | 5 | 1 | Opponent | yes | - | 2 | 4 | 1 | 0 | 0 | 0 | 66 |
| L1621 | 1 | 1 | Mine | no | 0 | 2 | 6 | 1 | 0 | 0 | 0 | 200 |
| L1621 | 1 | 1 | Opponent | no | 0 | - | 2 | 4 | 0 | 0 | 0 | 355 |
| L1719 | 3 | 1 | Mine | no | 2 | 2 | 6 | 0 | 2 | 0 | 0 | 0 |
| L1719 | 3 | 1 | Opponent | yes | 5 | 2 | 5 | 0 | 0 | 0 | 0 | 156 |
| L1819 | 1 | 1 | Mine | no | 0 | 3 | 3 | 0 | 1 | 0 | 0 | 0 |
| L1819 | 1 | 1 | Opponent | no | 2 | 2 | 4 | 0 | 0 | 0 | 0 | 0 |
| L1835 | 5 | 1 | Mine | yes | - | - | 0 | 3 | 1 | 0 | 0 | 0 |
| L1835 | 5 | 1 | Opponent | yes | - | 2 | 2 | 3 | 0 | 0 | 0 | 765 |
| L2021 | 5 | 1 | Mine | no | - | 2 | 3 | 3 | 1 | 0 | 0 | 210 |
| L2021 | 5 | 1 | Opponent | yes | - | - | 3 | 6 | 0 | 0 | 0 | 355 |
| L2123 | 5 | 1 | Mine | yes | - | - | 3 | 4 | 0 | 0 | 0 | 500 |
| L2123 | 5 | 1 | Opponent | yes | - | 2 | 3 | 1 | 1 | 0 | 0 | 0 |
| L2227 | 1 | 1 | Mine | no | 2 | 3 | 4 | 0 | 0 | 0 | 0 | 0 |
| L2227 | 1 | 1 | Opponent | yes | 2 | 1 | 1 | 3 | 0 | 0 | 0 | 0 |
| L2331 | 3 | 1 | Mine | no | 0 | 3 | 5 | 1 | 1 | 0 | 0 | 0 |
| L2331 | 3 | 1 | Opponent | yes | 2 | 5 | 3 | 1 | 1 | 0 | 0 | 562 |
| L2527 | 1 | 1 | Mine | no | 0 | 6 | 2 | 3 | 0 | 0 | 0 | 0 |
| L2527 | 1 | 1 | Opponent | no | 0 | 1 | 1 | 4 | 0 | 0 | 0 | 0 |
| L2634 | 6 | 1 | Mine | no | 6 | 3 | 4 | 0 | 0 | 0 | 0 | 110 |
| L2634 | 6 | 1 | Opponent | no | 3 | 2 | 5 | 3 | 0 | 0 | 0 | 56 |
| L2930 | 2 | 1 | Mine | - | - | 2 | 6 | 1 | 0 | 0 | 0 | 323 |
| L2930 | 2 | 1 | Opponent | - | - | 2 | 6 | 3 | 0 | 0 | 0 | 0 |
| L3234 | 6 | 1 | Mine | no | 4 | 2 | 4 | 3 | 0 | 0 | 0 | 340 |
| L3234 | 6 | 1 | Opponent | no | 0 | 2 | 2 | 0 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 21% | 2.6 | 2.7 | 2.8 | 1.1 | 0.3 | 0.0 | 0.0 | 290.2 |
| **Average** | | | Opponent | 43% | 2.0 | 2.3 | 3.0 | 1.9 | 0.5 | 0.0 | 0.0 | 129.1 |

### KPIs: sp-h2h-opp-89601ea-p4

Rules off - Mine only: STAY WORTH, BEST MOVE FOR SHOOTERS, FACE THE CAST, WIZARD FRONT RANK, FIRE PLAN, FIRE IN ORDER, KEEPS THE TARGET, MISSILES IN THE FIRE PLAN, THREAT AT FULL SIZE, SHOOTERS ARE THREATS, SHOOTERS TO THE PRIMARY.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 29% (50 of 175) | 2% (4 of 175) | 15% (54 of 350) |
| Winner chose to follow up after the loser gave ground |  | 94% (50 of 53); on the table 94% | 94% (51 of 54); on the table 96% | 94% (101 of 107); on the table 95% |
| Winner chose to pursue after the loser fell back in good order |  | 82% (9 of 11); on the table 91% | 100% (18 of 18); on the table 100% | 93% (27 of 29); on the table 97% |
| Winner chose to pursue after the loser fled |  | 79% (31 of 39); on the table 85% | 78% (25 of 32); on the table 84% | 79% (56 of 71); on the table 85% |
| Winner chose to follow up or pursue (all three) |  | 87% (90 of 103); on the table 90% | 90% (94 of 104); on the table 93% | 89% (184 of 207); on the table 92% |
| Magic missiles tried each own turn | 50%+ | 30% (80 of 266) | 29% (50 of 173) | 30% (130 of 439) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 46% (80 of 173) | 46% (50 of 109) | 46% (130 of 282) |
|   fighting wizards (on a monster, chariot or monstrous mount) | 50%+ | 28% (37 of 134) | 23% (20 of 87) | 26% (57 of 221) |
|     round 1 |  | 17% (4 of 23) | 14% (2 of 14) | 16% (6 of 37) |
|     rounds 2+ |  | 30% (33 of 111) | 25% (18 of 73) | 28% (51 of 184) |
|   other wizards | 50%+ | 33% (43 of 132) | 30% (24 of 80) | 32% (67 of 212) |
|     round 1 |  | 13% (3 of 23) | 36% (5 of 14) | 22% (8 of 37) |
|     rounds 2+ |  | 37% (40 of 109) | 29% (19 of 66) | 34% (59 of 175) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 52% (22 of 42) | 61% (37 of 61) | 57% (59 of 103) |
| Points that never fought | lower | 29% (19566 of 67942) | 34% (24372 of 71984) | 31% (43938 of 139926) |
|   infantry points that never fought | lower | 41% (6369 of 15347) | 59% (8179 of 13804) | 50% (14548 of 29151) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 56% (150 of 270) | 56% (157 of 280) | 56% (307 of 550) |
| Bound items with a magic missile used (at least once a game) |  | 95% (21 of 22); 1.2 uses a game | 78% (7 of 9); 0.6 uses a game | 90% (28 of 31); 0.9 uses a game |
| Bound items with another spell used |  | 38% (6 of 16); 0.3 uses a game | 45% (9 of 20); 0.5 uses a game | 42% (15 of 36); 0.4 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 53% (10 of 19); 0.3 uses a game | 73% (11 of 15); 0.3 uses a game | 62% (21 of 34); 0.3 uses a game |
|   their share of the points of units over 100 pts | lower | 48% (27937 of 57750) | 50% (31393 of 63347) | 49% (59330 of 121097) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.3 (25%) | 0.8 (23%) | 2.1 (24%) |
| MARCHED: its unit marched | 1.1 (20%) | 0.6 (18%) | 1.7 (19%) |
| CHARGED: its unit charged | 0.2 (3%) | 0.1 (4%) | 0.3 (4%) |
| IN COMBAT: engaged in combat | 1.8 (35%) | 0.7 (21%) | 2.6 (30%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.1 (3%) | 0.1 (1%) |
| FLEEING: fleeing | 0.1 (2%) | 0.1 (2%) | 0.2 (2%) |
| GONE: slain | 0.6 (12%) | 1.0 (28%) | 1.6 (18%) |
| OFF THE TABLE: off the table or not arrived | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.2 | 1.5 | 1.8 | 3.6 | 0.4 | 2.6 |
| not cast | 3.0 | 2.4 | 3.1 | 8.6 | 1.6 | 20.4 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.5 (7%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.1 (44%) | 0.2 (7%) | 2.1 (24%) | 0.3 (19%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.7 (19%) | 0.3 (19%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (4%) | 0.1 (7%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.1 (4%) | 0.1 (6%) | 0.7 (23%) | 2.6 (30%) | 0.5 (33%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.1 (5%) | 0.1 (6%) | 0.2 (6%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (1%) | 0.0 (0%) | 0.0 (0%) | 0.2 (2%) | 0.0 (0%) | 0.2 (1%) |
| GONE: slain | 0.9 (29%) | 0.7 (28%) | 0.6 (21%) | 1.6 (18%) | 0.2 (10%) | 4.0 (20%) |
| OFF THE TABLE: off the table or not arrived | 0.1 (2%) | 0.0 (0%) | 0.1 (4%) | 0.1 (1%) | 0.0 (0%) | 0.5 (2%) |
| STUPIDITY: Stupidity | 0.0 (1%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (1%) | 0.2 (7%) | 0.0 (0%) | 0.1 (1%) | 0.2 (12%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.8 (58%) | 0.2 (9%) | 1.2 (40%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 14.0 (68%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.3 a game | 0.6 a game | 0.9 a game |
| stood (cast and not dispelled) | 68% (28 of 41) | 58% (7 of 12) | 66% (35 of 53) |
| the unit moved after it | 71% (20 of 28) | 71% (5 of 7) | 71% (25 of 35) |
| it charged on its next turn | 7% (2 of 28) | 0% (0 of 7) | 6% (2 of 35) |
| the enemy charged it first | 21% (6 of 28) | 14% (1 of 7) | 20% (7 of 35) |
| it fought by the end of its next turn | 21% (6 of 28) | 29% (2 of 7) | 23% (8 of 35) |
| it moved out of a charge the enemy had planned (not charged first) | 11% (3 of 28) | 0% (0 of 7) | 9% (3 of 35) |
| none of these (no charge, no fight, no charge escaped) | 57% (16 of 28) | 71% (5 of 7) | 60% (21 of 35) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 64% (563 of 886) | 56% (288 of 514) | 61% (851 of 1400) |
|   cavalry | 63% (49 of 78) | 74% (84 of 113) | 70% (133 of 191) |
|   character | 38% (37 of 97) | 13% (17 of 126) | 24% (54 of 223) |
|   chariot | 48% (49 of 103) | 67% (14 of 21) | 51% (63 of 124) |
|   infantry | 60% (168 of 280) | 68% (143 of 210) | 63% (311 of 490) |
|   monster | 41% (19 of 46) | 40% (8 of 20) | 41% (27 of 66) |
|   war machine | 85% (241 of 282) | 92% (22 of 24) | 86% (263 of 306) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.6 (29%) | 1.1 (18%) | 3.8 (25%) |
| CHARGED: it charged | 1.7 (19%) | 1.7 (27%) | 3.4 (22%) |
| FLEEING: it fled or was fleeing | 0.1 (2%) | 0.2 (3%) | 0.3 (2%) |
| IN COMBAT: it fought this turn or the last | 0.6 (7%) | 0.4 (7%) | 1.0 (7%) |
| MOVED: a war machine that moved | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| NO TARGET IN RANGE | 1.7 (19%) | 1.0 (15%) | 2.7 (18%) |
| ONLY IN COMBAT: the only targets were in combat | 0.4 (5%) | 0.5 (8%) | 0.9 (6%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.2 (14%) | 1.2 (20%) | 2.5 (16%) |
| SHELTERED: the target was sheltered | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| OTHER BAR | 0.3 (3%) | 0.1 (2%) | 0.4 (3%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 6.2 | 1.3 | 82% | 4.5 pts | 28 pts |
| character | 1.7 | 0.4 | 83% | 6.4 pts | 11 pts |
| chariot | 1.8 | 1.3 | 61% | 13.8 pts | 25 pts |
| infantry | 12.8 | 4.4 | 75% | 8.9 pts | 114 pts |
| monster | 0.8 | 0.1 | 86% | 1.5 pts | 1 pts |
| war machine | 7.3 | 6.4 | 63% | 30.3 pts | 221 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.7 | 6.3 | 5.5 |
| Charges that made contact a game | 3.6 | 4.6 | 4.1 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.18 declared, 1.00 contact (17 units) | 0.36 declared, 0.29 contact (14 units) | 0.81 declared, 0.68 contact (31 units) |
|   per unit a game, units carrying another wizard (or one alone) | 1.78 declared, 1.33 contact (9 units) | 0.78 declared, 0.67 contact (9 units) | 1.28 declared, 1.00 contact (18 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.54 declared, 0.41 contact (250 units) | 0.72 declared, 0.52 contact (298 units) | 0.64 declared, 0.47 contact (548 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 59% (48 of 81) | 50% (8 of 16) | 50% (3 of 6) | 57% (59 of 103) |
| Character in a unit | 67% (16 of 24) | 46% (6 of 13) | 100% (1 of 1) | 61% (23 of 38) |
| Character on its own | 80% (33 of 41) | 41% (12 of 29) | 31% (24 of 77) | 47% (69 of 147) |
| Chariot | 80% (12 of 15) | 42% (5 of 12) | - | 63% (17 of 27) |
| Infantry | 66% (55 of 83) | 32% (8 of 25) | 17% (1 of 6) | 56% (64 of 114) |
| Monster | 62% (21 of 34) | 64% (9 of 14) | - | 62% (30 of 48) |
| Monstrous | 64% (9 of 14) | 57% (8 of 14) | - | 61% (17 of 28) |
| War Machines | 63% (27 of 43) | 50% (1 of 2) | - | 62% (28 of 45) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 100% (17 of 17); on the table 100% | 31% (32 of 102) | 11% | 41% (9 of 22) | 100% (6 of 6); 2.8 uses a game | 100% (2 of 2); 1.0 uses a game | 67% (4 of 6); 1.0 uses a game |
| Chaos Dwarfs | 4 | 93% (14 of 15); on the table 93% | 42% (10 of 24) | 19% | 34% (11 of 32) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
| Dwarfen Mountain Holds | 3 | 33% (1 of 3); on the table 33% | - | 60% | 70% (19 of 27) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 6 | 80% (8 of 10); on the table 100% | 50% (9 of 18) | 47% | 63% (39 of 62) | 0.0 uses a game | 50% (1 of 2); 0.5 uses a game | 60% (3 of 5); 0.5 uses a game |
| Grand Cathay | 4 | 100% (15 of 15); on the table 100% | 25% (21 of 84) | 19% | 43% (16 of 37) | 100% (9 of 9); 4.5 uses a game | 50% (1 of 2); 0.2 uses a game | 25% (1 of 4); 0.2 uses a game |
| High Elf Realms | 9 | 92% (24 of 26); on the table 92% | 8% (3 of 36) | 34% | 60% (42 of 70) | 100% (7 of 7); 2.3 uses a game | 37% (11 of 30); 2.3 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | - | - | 35% | 17% (1 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Lizardmen | 3 | 90% (9 of 10); on the table 100% | 17% (1 of 6) | 26% | 71% (15 of 21) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 2 | 86% (6 of 7); on the table 86% | 50% (3 of 6) | 46% | 71% (10 of 14) | 50% (1 of 2); 0.5 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 3 | 100% (14 of 14); on the table 100% | 19% (8 of 42) | 15% | 29% (7 of 24) | 0.0 uses a game | 0.0 uses a game | 67% (2 of 3); 0.7 uses a game |
| Skaven | 6 | 92% (12 of 13); on the table 92% | 27% (11 of 41) | 39% | 64% (29 of 45) | 67% (2 of 3); 1.2 uses a game | 0.0 uses a game | 67% (4 of 6); 0.8 uses a game |
| Tomb Kings of Khemri | 4 | 69% (11 of 16); on the table 75% | 17% (1 of 6) | 32% | 35% (7 of 20) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 8 | 89% (16 of 18); on the table 94% | 38% (21 of 56) | 20% | 55% (23 of 42) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 9 | 90% (19 of 21); on the table 90% | 42% (5 of 12) | 26% | 61% (44 of 72) | 100% (2 of 2); 0.6 uses a game | 0.0 uses a game | 100% (3 of 3); 0.3 uses a game |
| Wood Elf Realms | 6 | 82% (18 of 22); on the table 86% | 83% (5 of 6) | 47% | 62% (35 of 56) | 50% (1 of 2); 0.7 uses a game | 0.0 uses a game | 50% (2 of 4); 0.3 uses a game |

Flank and rear charges a unit could have turned to face (sp-h2h-opp-89601ea-p4, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 38% (39) | 44% (36) | 41% (75) |
| ...free all their last turn and able to turn (per game) | 0.78 | 0.50 | 1.28 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.11 | 0.17 | 0.28 |
| ...with the charger already in that arc before they moved (per game) | 0.44 | 0.36 | 0.81 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 1.69 | 1.08 | 2.78 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 1.00 | 0.39 | 1.39 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 5.47 | 5.94 | 11.42 |

### Quality by phase: sp-h2h-opp-89601ea-p4

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.1 | 3.6 |
| Strategy | Charge objectives carried out (made contact) | 53% (89 of 168) | 44% (82 of 188) |
| Strategy | Shoot objectives carried out (shot that target) | 44% (170 of 386) | 40% (70 of 173) |
| Strategy | Close-in objectives charged next turn | 15% (23 of 151) | 18% (38 of 213) |
| Strategy | Support requests answered (helper made contact too) | 78% (14 of 18) | 46% (11 of 24) |
| Strategy | Hexes on a unit its side charged or shot that turn | 46% (6 of 13) | 71% (5 of 7) |
| Strategy | Joined characters whose unit fought | 65% (22 of 34) | 44% (12 of 27) |
| Strategy | Lone characters that fought | 83% (74 of 89) | 75% (67 of 89) |
| Movement | Charges halted short of contact | 0.1 | 0.2 |
| Movement | Idle units | 1.1 | 1.9 |
| Movement | Points that never moved of their own | 290.2 | 129.1 |
| Movement | Fights charged into per game | 3.2 | 3.9 |
| Movement | Charges with odds: long shots (under 50%) | 12 of 110, net +40 | 24 of 120, net +18 |
| Movement | Charges with odds: sweet spot (55-75%) | 18 of 110, net +96 | 17 of 120, net +62 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 13 of 110, net +111 | 13 of 120, net +119 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 45 of 110, net +89 | 39 of 120, net +136 |
| Shooting | Shots by shooting units (incl. breath weapons) | 9.9 | 8.4 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 48% (171 of 356) | 34% (104 of 302) |
| Shooting | Points destroyed by shooting units | 99.9 | 45.5 |
| Shooting | War machine shots | 6.7 | 0.6 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 59% (143 of 241) | 14% (3 of 22) |
| Shooting | Points destroyed by war machines | 83.4 | 15.4 |
| Magic | Magic missiles cast | 1.5 | 1.0 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 43% (23 of 53) | 24% (8 of 34) |
| Magic | Wounds caused by magic missiles | 3.3 | 1.3 |
| Magic | Wounds caused by other spells | 2.5 | 0.8 |
| Magic | Points destroyed by magic (all spells) | 113.8 | 46.4 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.1 / 0.4 / 1.2 / 0.2 | 1.9 / 0.4 / 0.4 / 0.1 |
| Combat | Points destroyed in combat | 373.9 | 401.6 |
| Combat | Points run down | 125.1 | 149.7 |
| Combat | Net points per charged fight, damage counted | +78 | +68 |
| Combat | Net per 100 charger points, damage counted | +26.7 | +21.4 |
| Combat | First round won (charged fights) | 77% | 71% |
| Combat | Net points per charged fight | +68 | +76 |
| Combat | Net points per supported fight / lone fight | -4 / +81 | +206 / +54 |
| Combat | Charged fights on a top-3 enemy unit | 47 of 117 | 66 of 139 |
| Game | Points lost | 762.3 | 853.0 |
| Game | VP from objectives | 545.3 | 502.2 |
| Game | Lone holders (player turns) | 2.6 | 2.0 |

- Mine won / drew / lost: 13 / 11 / 12 of 36 ended games (of 36); mean margin (Mine - Opponent) +139 VP
- The side that went first won 14 of 25 games with a winner
- Points traded per game (both sides' losses): 1615
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: sp-h2h-opp-89601ea-p4

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 0.8 | +0.0 | 0.0 | 0.0 |
| ALREADY CARRIED | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARTILLERY RE-ROLL WEIGHED | 1.2 | +0.0 | 0.0 | 9.2 | 0.1 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | 0.9 | +5.1 | 0.0 | 12.9 | 1.1 | +10.8 | 0.0 | 36.8 |
| BEST FACING | 0.5 | +17.5 | 0.0 | 6.3 | 0.5 | +21.4 | 0.0 | 9.9 |
| BEST FIRST | 4.4 | +161.1 | 211.2 | 85.1 | 3.8 | +148.5 | 68.4 | 105.3 |
| BEST MOVE FOR SHOOTERS | - | - | - | - | 0.5 | +35.1 | 0.0 | 20.7 |
| BEST OVERALL | 0.4 | +25.2 | 0.0 | 4.9 | 0.2 | +13.7 | 0.0 | 7.4 |
| BEST PREY | 0.7 | +45.6 | 12.1 | 15.3 | 1.0 | +52.9 | 29.9 | 41.6 |
| BEST PRIZE | - | - | - | - | 0.1 | +8.2 | 5.5 | 4.8 |
| BIG CHARACTER SAFETY | 0.1 | +0.3 | 0.0 | 0.0 | 0.2 | -1.4 | 0.0 | 37.0 |
| BLOCKED CHARGE SKIPPED | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 10.6 | 7.9 |
| BLOCKED WHEEL | 0.4 | +2.7 | 0.0 | 4.9 | 0.6 | +20.4 | 0.0 | 11.1 |
| BOMBING RUN | 0.1 | +1.8 | 0.0 | 0.0 | - | - | - | - |
| CANNON PLAN MISSED | 0.8 | +0.0 | 133.6 | 19.0 | - | - | - | - |
| CANNON PLANNED TARGET | 5.0 | +203.3 | 422.4 | 90.4 | - | - | - | - |
| CANNON SIGHT KEPT | 1.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 1.9 |
| CARRIES OUT COUNTER | - | - | - | - | 0.1 | +0.0 | 10.2 | 0.0 |
| CARRIES OUT SET-UP | - | - | - | - | 0.1 | -2.1 | 0.0 | 0.0 |
| CAST JOB | 0.6 | +24.0 | 47.1 | 18.4 | 0.4 | +14.7 | 29.3 | 3.2 |
| CASTER AWAY FROM SCREEN | 0.3 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.4 | +49.6 | 47.5 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | 0.9 | +0.0 | 0.0 | 25.6 | 0.2 | +0.0 | 0.0 | 45.0 |
| CASTS FROM BEHIND | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CATCH ODDS | - | - | - | - | 0.1 | +1.4 | 0.0 | 3.2 |
| CHAFF PASSED | 0.3 | -0.8 | 13.5 | 11.3 | - | - | - | - |
| CHAMPION TAKES THE CHALLENGE | 0.0 | +0.0 | 11.3 | 0.0 | - | - | - | - |
| CHARGE NOW FIRST | 2.6 | +0.0 | 333.4 | 123.6 | 3.0 | +0.0 | 280.3 | 175.1 |
| CHARGE NOW WEIGHED | 0.5 | -40.1 | 1.5 | 16.1 | 0.4 | -28.0 | 21.5 | 35.6 |
| CHARIOT NO STATIC JOB | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHARIOT WIZARD CAREFUL | 0.1 | -1.8 | 13.9 | 13.9 | 0.2 | -1.8 | 0.0 | 56.0 |
| CHEAP HELPER | 0.1 | +0.0 | 1.2 | 1.8 | 0.1 | +0.0 | 0.0 | 2.4 |
| COMBAT PIVOT | 0.7 | +0.0 | 30.8 | 61.5 | 0.6 | +0.0 | 14.9 | 37.7 |
| CONTINUE AHEAD WEIGHED | 0.0 | +0.0 | 0.0 | 10.2 | - | - | - | - |
| CONVEYANCE SEARCH | 0.9 | +147.8 | 13.9 | 37.8 | 0.2 | +44.6 | 21.4 | 13.9 |
| COUNTER-CHARGE COVER | 7.7 | +574.7 | 0.0 | 199.0 | 6.5 | +528.5 | 0.0 | 146.5 |
| DEFENSIVE ARMY | 0.2 | +0.0 | 23.4 | 3.5 | - | - | - | - |
| DEFENSIVE FLOOR | 0.1 | +0.9 | 2.7 | 1.8 | - | - | - | - |
| EDGE GIVE GROUND | 0.1 | +0.8 | 12.6 | 2.2 | 0.3 | +11.7 | 38.0 | 1.2 |
| ELIXIR WORTH | - | - | - | - | 0.1 | +1.3 | 0.0 | 9.7 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 1.7 | +188.8 | 0.0 | 42.3 | 1.1 | +75.6 | 0.0 | 35.7 |
| FALLBACK BY WORTH | 4.7 | +52.6 | 0.0 | 48.5 | 6.0 | +52.4 | 0.0 | 135.4 |
| FIGHT LIFT | 0.0 | +0.2 | 0.0 | 0.0 | - | - | - | - |
| FIRE AND FLEE | - | - | - | - | 0.1 | +0.3 | 0.0 | 0.0 |
| FIRE IN ORDER | - | - | - | - | 0.3 | +0.0 | 6.3 | 25.9 |
| FIRE PLAN | - | - | - | - | 7.8 | +227.8 | 330.3 | 123.0 |
| FLANK NOT WEIGHED | 5.2 | +0.0 | 0.0 | 150.2 | 5.5 | +0.0 | 0.0 | 187.7 |
| FOLLOW UP WEIGHED | 1.2 | +123.2 | 0.0 | 58.8 | 1.3 | +200.8 | 0.0 | 72.6 |
| FRIENDS SHOTS CHECKED | 0.2 | +9.8 | 0.0 | 3.1 | 0.2 | +6.3 | 0.0 | 13.4 |
| GIVES UP | 0.2 | -2.5 | 30.0 | 2.2 | 0.1 | -1.7 | 20.3 | 0.0 |
| GIVES UP ITS SCREEN | 0.0 | -0.1 | 5.1 | 0.0 | 0.0 | -0.1 | 3.4 | 0.0 |
| GROUND FLIERS | 0.0 | +0.3 | 0.0 | 0.0 | 0.1 | +1.9 | 0.0 | 0.0 |
| HELPER ALREADY ASKED | - | - | - | - | 0.0 | +0.0 | 3.3 | 0.0 |
| HELPER UNSEEN | 0.4 | +0.0 | 65.1 | 19.7 | 0.4 | +0.0 | 7.1 | 12.2 |
| HILL BY ITS CHANCE | 0.6 | -51.0 | 0.0 | 20.9 | 0.4 | -28.7 | 0.0 | 10.8 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| HUNT ADVANCE | 0.0 | +0.1 | 0.0 | 0.0 | 0.2 | +6.8 | 0.0 | 9.5 |
| HUNT IN PAIRS | 0.2 | +9.4 | 0.0 | 0.0 | 0.5 | +29.0 | 0.0 | 0.0 |
| HUNT KEPT | 0.0 | +0.0 | 0.0 | 1.7 | 0.1 | +8.6 | 6.9 | 6.2 |
| HUNT RESULT | 0.0 | +0.0 | 0.0 | 1.7 | 0.1 | +11.5 | 4.6 | 6.3 |
| HUNT THE GUNS | 0.0 | +13.5 | 0.0 | 0.0 | 0.1 | +48.6 | 4.6 | 6.4 |
| INVITES THE FIGHT | 1.8 | +35.2 | 70.0 | 9.9 | 1.4 | +21.5 | 80.5 | 32.2 |
| JOINT CHARGE PLAN | 0.1 | +2.3 | 0.0 | 0.0 | 0.1 | +14.9 | 13.7 | 0.0 |
| KEEP FALLS | 0.1 | +2.6 | 0.0 | 6.1 | 0.0 | +0.4 | 0.0 | 0.0 |
| KEEPS ITS PREY | - | - | - | - | 0.1 | +0.5 | 0.0 | 3.1 |
| KEEPS ITS TARGET | 1.8 | +52.5 | 230.9 | 70.4 | 2.2 | +65.8 | 187.9 | 60.5 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KEEPS THE TARGET | - | - | - | - | 1.0 | +8.2 | 27.4 | 21.0 |
| KILLS COUNT | 2.2 | +65.6 | 192.2 | 78.5 | 2.0 | +114.9 | 185.4 | 114.9 |
| KILLS COUNT NEXT TURN | 5.4 | +168.2 | 171.9 | 130.0 | 7.1 | +267.0 | 262.6 | 186.2 |
| LONE CHARACTER SAFE SPOT | 0.4 | +5.2 | 3.0 | 15.1 | 0.2 | +7.9 | 11.2 | 11.5 |
| LONE WIZARD HOLDS BACK | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 3.2 | 10.7 |
| LONE WIZARD KEPT IN | 0.6 | +26.9 | 0.0 | 0.0 | 0.2 | +20.3 | 0.0 | 0.0 |
| LONG SHOT | 0.6 | -8.4 | 55.6 | 17.0 | 0.5 | +2.5 | 28.3 | 7.4 |
| LOST CHARGE | 3.0 | -45.5 | 124.7 | 143.8 | 2.0 | -29.0 | 47.9 | 79.0 |
| LURE BY WHAT IT DRAWS | 0.0 | -1.2 | 0.0 | 0.0 | 0.1 | -4.8 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 0.4 | +24.1 | 0.0 | 14.8 | 0.5 | +120.9 | 36.8 | 16.1 |
| MANOEUVRE | 0.1 | +3.7 | 0.0 | 0.0 | 0.1 | +1.4 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.1 | +1.3 | 0.0 | 0.0 | 0.0 | +0.2 | 0.0 | 0.0 |
| MARCH CHECK | 0.5 | +23.7 | 0.0 | 0.0 | 0.3 | +3.0 | 0.0 | 13.9 |
| MARCH ODDS | 0.3 | +16.4 | 9.5 | 20.6 | 0.2 | +19.2 | 23.6 | 15.0 |
| MARCH OVER CASTS | 0.4 | +26.8 | 0.0 | 18.7 | 0.4 | +32.3 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 3.8 | +124.2 | 0.0 | 134.6 | 4.7 | +187.8 | 0.0 | 77.8 |
| MISSILES IN THE FIRE PLAN | - | - | - | - | 1.2 | +36.7 | 40.9 | 20.4 |
| MISSILES IN THE MOVE | 3.5 | +131.6 | 0.0 | 96.3 | 2.2 | +46.6 | 0.0 | 128.5 |
| MISSILES NEXT TURN | 4.6 | +87.8 | 0.0 | 133.4 | 2.9 | +31.3 | 0.0 | 113.5 |
| MODEL FACING | 0.3 | +30.8 | 0.0 | 5.0 | - | - | - | - |
| MONSTER WIZARD ROAMS | 0.2 | +0.0 | 9.1 | 0.0 | 0.2 | +0.0 | 14.2 | 0.0 |
| MOVE AND CAST | 0.3 | +10.6 | 0.0 | 6.5 | 0.3 | +26.1 | 0.0 | 7.6 |
| MOVE SPELL IN RANGE | 0.3 | +8.6 | 0.0 | 4.7 | 0.1 | +4.4 | 0.0 | 0.0 |
| MOVE SPELL OUT OF RANGE | 0.6 | -29.8 | 10.1 | 21.1 | 0.1 | -10.0 | 0.0 | 0.0 |
| MOVE SPELL SPOT | 0.6 | +0.0 | 0.0 | 26.2 | 0.1 | +0.0 | 0.0 | 25.0 |
| MOVE TO CHARGE | 3.2 | +146.4 | 112.3 | 101.5 | 4.3 | +425.3 | 186.2 | 89.4 |
| MOVES UNITS SPELL | 0.1 | +3.3 | 0.0 | 0.0 | 0.1 | +0.6 | 0.0 | 0.0 |
| NEEDED THERE | 0.1 | +6.9 | 13.9 | 0.0 | 0.1 | +15.0 | 6.0 | 0.0 |
| NOT NEEDED | 0.4 | -9.9 | 35.3 | 9.6 | 0.2 | -21.5 | 50.5 | 0.0 |
| NOT TURNED | 5.5 | +106.1 | 0.0 | 112.3 | 5.9 | +55.0 | 0.0 | 143.7 |
| NOT WORTH A CAST | 1.0 | -0.6 | 0.0 | 23.8 | 0.2 | -3.7 | 0.0 | 0.0 |
| OFF BEST | 15.1 | -758.2 | 6.7 | 303.1 | 12.9 | -720.2 | 1.7 | 256.4 |
| OPENS A LANE | 0.1 | +0.2 | 10.5 | 0.0 | 0.1 | +0.4 | 3.1 | 5.4 |
| OPENS UP | 0.2 | +18.1 | 19.8 | 11.7 | 0.4 | +35.8 | 20.3 | 25.4 |
| OVERRUNS AWAY | 0.7 | +12.0 | 68.5 | 0.0 | 0.5 | +14.3 | 59.4 | 46.7 |
| PATHS CROSS | 2.4 | +161.8 | 0.0 | 19.5 | 3.2 | +315.6 | 0.0 | 51.6 |
| PERIAPT WORTH | 0.1 | +6.8 | 0.0 | 15.0 | 0.1 | +5.9 | 0.0 | 15.0 |
| PIVOT GUARDS FLANK | 0.1 | -1.7 | 0.0 | 0.0 | 0.1 | -0.6 | 0.0 | 1.5 |
| PLAN RESULT | 38.1 | +1802.9 | 1706.0 | 1065.4 | 38.1 | +1190.3 | 1363.1 | 1271.8 |
| PURSUES BIG PREY | 0.1 | -5.5 | 0.0 | 0.0 | 0.1 | -8.1 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE NEXT TURN | 0.1 | +6.3 | 0.0 | 2.2 | 0.1 | +14.0 | 0.0 | 0.0 |
| RANDOM MOVE BY FIGURES | 1.2 | +18.1 | 0.0 | 23.3 | 1.7 | +27.4 | 0.0 | 53.6 |
| RANDOM MOVER NO PROMISE | 0.4 | -19.6 | 17.9 | 0.0 | 0.3 | -19.5 | 3.3 | 4.0 |
| REDIRECT BY WHAT IT STOPS | 0.2 | +1.5 | 0.0 | 2.8 | 0.4 | -7.9 | 0.0 | 8.8 |
| REDIRECT COUNTER | 1.9 | +113.7 | 0.0 | 20.1 | 3.9 | +312.6 | 0.0 | 72.7 |
| REDIRECT WEIGHED | 0.2 | +4.6 | 6.9 | 10.2 | 0.4 | +23.5 | 30.8 | 35.9 |
| RESERVE FALL BACK | 0.5 | +20.9 | 0.0 | 6.2 | 0.6 | +20.4 | 0.0 | 6.6 |
| RESTRAINS TO SHOOT | 0.1 | +6.0 | 0.0 | 0.0 | 0.2 | +9.3 | 0.0 | 26.9 |
| RISK BY ARC | 3.0 | +115.9 | 299.4 | 106.3 | 2.9 | +43.4 | 272.3 | 180.6 |
| SAFER THAN THE JOB | 1.0 | +61.8 | 0.0 | 25.1 | 0.4 | +19.4 | 0.0 | 0.0 |
| SCOUT SPOT | 0.4 | +0.5 | 0.0 | 0.9 | 0.1 | +0.0 | 0.0 | 3.7 |
| SCOUT WAITS | 0.5 | +0.0 | 0.0 | 0.9 | 0.1 | +0.0 | 0.0 | 3.7 |
| SCREEN BY WHAT IT SAVES | 0.1 | -2.6 | 0.0 | 0.0 | 0.3 | -11.7 | 0.0 | 0.8 |
| SEARCH SPOT | 2.4 | +107.7 | 0.0 | 20.1 | 3.0 | +137.2 | 0.0 | 66.8 |
| SELF MOVE SPELL | 0.2 | +44.9 | 0.0 | 0.0 | 0.4 | +14.3 | 0.0 | 58.2 |
| SET UP TOGETHER | 0.6 | +38.1 | 0.0 | 16.2 | 1.1 | +151.4 | 63.2 | 35.2 |
| SET-UP ANY TARGET | 0.7 | +115.6 | 13.9 | 27.9 | 0.1 | +14.2 | 7.6 | 0.0 |
| SET-UP MISSED | 0.1 | +21.3 | 5.0 | 2.4 | 0.1 | +8.9 | 0.0 | 0.0 |
| SHOOTERS ARE THREATS | - | - | - | - | 2.6 | +324.9 | 124.2 | 24.0 |
| SHOOTERS IN TWO RANKS | 0.3 | +0.8 | 0.0 | 0.0 | 0.2 | +0.3 | 0.0 | 0.0 |
| SHOOTERS TO THE PRIMARY | - | - | - | - | 2.5 | +163.8 | 0.0 | 54.3 |
| SHOOTS FROM THE BEST SPOT | 1.0 | +36.8 | 36.0 | 10.7 | 0.6 | +24.2 | 12.9 | 12.9 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 3.8 |
| SHOT OPTIONS | 15.8 | +0.0 | 836.6 | 295.9 | 8.3 | +0.0 | 257.1 | 135.9 |
| SHOT REPLANNED | 0.6 | +0.0 | 150.3 | 15.4 | - | - | - | - |
| SHOTS IN THE MOVE | 14.4 | +654.2 | 0.0 | 228.1 | 7.4 | +274.7 | 0.0 | 134.5 |
| SPELL SETS UP CHARGE | 0.7 | +124.7 | 13.9 | 27.9 | 0.1 | +24.0 | 21.4 | 13.9 |
| SPELL WORTH | 1.2 | +15.7 | 108.4 | 122.4 | 2.4 | +52.2 | 133.6 | 133.6 |
| STABLE ROLE | 10.7 | +0.0 | 404.9 | 213.1 | 9.8 | +0.0 | 383.2 | 131.0 |
| STAY WEIGHED | 0.1 | +8.7 | 0.0 | 0.0 | - | - | - | - |
| STAY WORTH | - | - | - | - | 8.7 | +84.3 | 139.5 | 137.5 |
| STOPS | - | - | - | - | 0.1 | +6.5 | 11.5 | 3.2 |
| STOPS SHORT OF THE FLANK | 0.3 | +11.7 | 0.0 | 10.4 | 0.4 | +9.4 | 0.0 | 40.3 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| SUPPORT JOB KEPT | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SUPPORT NARROWED | 5.4 | -44.3 | 342.8 | 119.5 | 7.7 | -59.6 | 463.6 | 141.8 |
| SUPPORTS | 3.2 | +49.2 | 105.1 | 37.1 | 5.2 | +59.6 | 254.4 | 43.2 |
| SURE CHARGE BEATS ADVANCE | 0.1 | -4.9 | 3.8 | 0.0 | 0.2 | -13.5 | 12.3 | 0.0 |
| SURE REACH TOGETHER | 0.3 | -0.8 | 0.0 | 21.2 | 0.2 | -2.5 | 0.0 | 4.5 |
| THREAT AT FULL SIZE | - | - | - | - | 4.3 | +0.0 | 161.8 | 71.8 |
| THROUGH LINE OF FIRE | 0.3 | +0.5 | 0.0 | 11.1 | 0.2 | +21.2 | 0.0 | 0.0 |
| TURN WORTH | 0.7 | -50.5 | 59.0 | 11.2 | 0.6 | -56.8 | 42.7 | 57.5 |
| TWO OR MORE ARRIVE | 0.2 | +0.8 | 0.0 | 0.0 | 0.3 | +3.0 | 28.4 | 0.0 |
| WAIT AFTER COSTS | 6.9 | -266.5 | 239.1 | 142.4 | 7.5 | -403.7 | 323.3 | 167.0 |
| WALKS TO THE FIGHT | 1.7 | +26.0 | 36.4 | 43.8 | 0.9 | +14.1 | 14.2 | 13.1 |
| WAR ENGINE CHARGES | 0.1 | +18.9 | 38.5 | 8.6 | - | - | - | - |
| WAR ENGINE JOBS | 0.6 | +0.0 | 16.4 | 12.1 | 0.1 | +0.0 | 2.2 | 0.0 |
| WEARS DOWN | 1.1 | +48.4 | 149.6 | 66.8 | 1.4 | +35.2 | 90.0 | 52.9 |
| WHO HITS BACK | 0.2 | +4.6 | 0.0 | 2.5 | 0.2 | +5.9 | 0.0 | 0.8 |
| WHOLE FIGHT | 0.6 | +40.5 | 154.1 | 19.1 | 0.3 | +1.3 | 40.2 | 24.7 |
| WHOLE FIGHT GAIN | 0.2 | +26.8 | 12.0 | 8.6 | 0.6 | +33.1 | 41.2 | 10.1 |
| WIZARD FRONT RANK | - | - | - | - | 0.0 | +0.0 | 0.0 | 4.3 |

### Rule changes: sp-h2h-opp-89601ea-p4

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 1011 | 1011 | 1011 | 28.08 | -53224 | -52.6 |
| BEST FIRST | 293 | 293 | 293 | 8.14 | +11147 | +38.0 |
| PATHS CROSS | 202 | 202 | 202 | 5.61 | +17186 | +85.1 |
| SEARCH SPOT | 194 | 194 | 191 | 5.31 | +8822 | +46.2 |
| MOVE TO CHARGE | 271 | 271 | 145 | 4.03 | +8735 | +60.2 |
| COUNTER-CHARGE COVER | 509 | 286 | 143 | 3.97 | +7910 | +55.3 |
| KILLS COUNT NEXT TURN | 450 | 450 | 123 | 3.42 | +4057 | +33.0 |
| FIRE PLAN | 280 | 280 | 115 | 3.19 | +4620 | +40.2 |
| FACES THE THREAT | 100 | 100 | 100 | 2.78 | +9518 | +95.2 |
| SUPPORTS | 301 | 301 | 94 | 2.61 | +1064 | +11.3 |
| FOLLOW UP WEIGHED | 88 | 88 | 88 | 2.44 | +11665 | +132.6 |
| FALLBACK BY WORTH | 384 | 384 | 79 | 2.19 | +3783 | +47.9 |
| SHOTS IN THE MOVE | 782 | 519 | 75 | 2.08 | +3258 | +43.4 |
| WAIT AFTER COSTS | 516 | 516 | 66 | 1.83 | +1111 | +16.8 |
| RANDOM MOVE BY FIGURES | 103 | 103 | 59 | 1.64 | +1637 | +27.7 |
| WALKS TO THE FIGHT | 95 | 95 | 57 | 1.58 | +584 | +10.2 |
| ADVANCE LANE KEPT | 55 | 55 | 55 | 1.53 | +0 | +0.0 |
| CHARGE NOW FIRST | 203 | 203 | 50 | 1.39 | -2529 | -50.6 |
| SAFER THAN THE JOB | 50 | 50 | 50 | 1.39 | +2924 | +58.5 |
| ARTILLERY RE-ROLL WEIGHED | 47 | 47 | 47 | 1.31 | +0 | +0.0 |
| REDIRECT COUNTER | 206 | 120 | 46 | 1.28 | +3667 | +79.7 |
| COMBAT PIVOT | 45 | 45 | 45 | 1.25 | +0 | +0.0 |
| CANNON SIGHT KEPT | 42 | 42 | 42 | 1.17 | +0 | +0.0 |
| RESERVE FALL BACK | 40 | 40 | 40 | 1.11 | +1487 | +37.2 |
| RISK BY ARC | 212 | 207 | 40 | 1.11 | +1467 | +36.7 |
| MAX FOR POSITIONING | 307 | 169 | 39 | 1.08 | +511 | +13.1 |
| KILLS COUNT | 150 | 145 | 36 | 1.00 | +1749 | +48.6 |
| BEST FACING | 35 | 35 | 35 | 0.97 | +1401 | +40.0 |
| HOLDS AMBUSHERS | 35 | 35 | 35 | 0.97 | +0 | +0.0 |
| BLOCKED WHEEL | 34 | 34 | 34 | 0.94 | +832 | +24.5 |
| CHARGE NOW WEIGHED | 33 | 33 | 33 | 0.92 | +1690 | +51.2 |
| SHOOTS FROM THE BEST SPOT | 57 | 57 | 31 | 0.86 | +886 | +28.6 |
| LONE WIZARD KEPT IN | 28 | 28 | 28 | 0.78 | +1699 | +60.7 |
| MISSILES IN THE MOVE | 206 | 119 | 28 | 0.78 | +550 | +19.6 |
| STOPS SHORT OF THE FLANK | 28 | 28 | 28 | 0.78 | +758 | +27.1 |
| BEST OVERALL | 24 | 24 | 24 | 0.67 | +1403 | +58.4 |
| KEEPS ITS TARGET | 142 | 141 | 24 | 0.67 | +460 | +19.2 |
| MARCH CHECK | 27 | 26 | 24 | 0.67 | +1115 | +46.5 |
| CANNON PLANNED TARGET | 179 | 179 | 22 | 0.61 | +179 | +8.1 |
| INVITES THE FIGHT | 115 | 115 | 22 | 0.61 | +268 | +12.2 |
| MOVE AND CAST | 22 | 22 | 22 | 0.61 | +1320 | +60.0 |
| SHOT REPLANNED | 22 | 22 | 22 | 0.61 | +0 | +0.0 |
| REDIRECT WEIGHED | 21 | 21 | 21 | 0.58 | +898 | +42.7 |
| SCOUT WAITS | 21 | 21 | 21 | 0.58 | +0 | +0.0 |
| BEST PREY | 62 | 62 | 19 | 0.53 | +758 | +39.9 |
| CAST JOB | 36 | 36 | 18 | 0.50 | +632 | +35.1 |
| MARCH ODDS | 18 | 18 | 18 | 0.50 | +385 | +21.4 |
| SET UP TOGETHER | 61 | 51 | 18 | 0.50 | +2912 | +161.8 |
| SHOOTERS IN TWO RANKS | 18 | 18 | 18 | 0.50 | +41 | +2.3 |
| BEST MOVE FOR SHOOTERS | 17 | 17 | 17 | 0.47 | +1263 | +74.3 |
| CASTER AWAY FROM SCREEN | 17 | 17 | 17 | 0.47 | +0 | +0.0 |
| STAY WORTH | 314 | 246 | 16 | 0.44 | +228 | +14.2 |
| STUCK PIVOT | 16 | 16 | 16 | 0.44 | +0 | +0.0 |
| THROUGH LINE OF FIRE | 16 | 16 | 16 | 0.44 | +781 | +48.8 |
| WEARS DOWN | 90 | 86 | 16 | 0.44 | +356 | +22.2 |
| WHO HITS BACK | 15 | 15 | 15 | 0.42 | +261 | +17.4 |
| WHOLE FIGHT GAIN | 29 | 25 | 15 | 0.42 | +465 | +31.0 |
| FRIENDS SHOTS CHECKED | 13 | 13 | 13 | 0.36 | +579 | +44.6 |
| BIG CHARACTER SAFETY | 12 | 12 | 12 | 0.33 | -42 | -3.5 |
| CASTING BLOCK | 14 | 14 | 12 | 0.33 | +968 | +80.7 |
| CHAFF PASSED | 11 | 11 | 11 | 0.31 | -29 | -2.7 |
| MODEL FACING | 11 | 11 | 11 | 0.31 | +1108 | +100.7 |
| WAR ENGINE JOBS | 23 | 23 | 11 | 0.31 | -393 | -35.8 |
| FIRE IN ORDER | 10 | 10 | 10 | 0.28 | +0 | +0.0 |
| OPENS UP | 22 | 22 | 10 | 0.28 | +539 | +53.9 |
| RESTRAINS TO SHOOT | 10 | 10 | 10 | 0.28 | +547 | +54.7 |
| CASTS FROM BEHIND | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| SHOOTERS TO THE PRIMARY | 90 | 66 | 9 | 0.25 | +598 | +66.4 |
| SHORT GUN FORWARD | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| SURE CHARGE BEATS ADVANCE | 9 | 9 | 9 | 0.25 | -660 | -73.3 |
| WHOLE FIGHT | 35 | 35 | 9 | 0.25 | +240 | +26.7 |
| BLOCKED CHARGE SKIPPED | 8 | 8 | 8 | 0.22 | +0 | +0.0 |
| LOST CHARGE | 178 | 175 | 8 | 0.22 | +163 | +20.4 |
| MAKE SURE TOGETHER | 32 | 28 | 8 | 0.22 | +2113 | +264.1 |
| MANOEUVRE | 8 | 8 | 8 | 0.22 | +185 | +23.2 |
| RAIDS THE BAGGAGE NEXT TURN | 8 | 8 | 8 | 0.22 | +391 | +48.9 |
| SUPPORT NARROWED | 470 | 470 | 8 | 0.22 | -159 | -19.9 |
| MOVES UNITS SPELL | 7 | 7 | 7 | 0.19 | +138 | +19.7 |
| NEEDED THERE | 9 | 9 | 7 | 0.19 | +0 | +0.0 |
| PURSUES BIG PREY | 7 | 7 | 7 | 0.19 | -490 | -70.0 |
| HUNT IN PAIRS | 27 | 18 | 6 | 0.17 | +333 | +55.4 |
| KEEPS THE TARGET | 37 | 37 | 6 | 0.17 | -274 | -45.6 |
| MISSILES NEXT TURN | 267 | 150 | 6 | 0.17 | +8 | +1.4 |
| OVERRUNS AWAY | 42 | 42 | 6 | 0.17 | +63 | +10.5 |
| BACKUP TARGETS | 73 | 35 | 5 | 0.14 | +54 | +10.8 |
| KEEP FALLS | 5 | 5 | 5 | 0.14 | +199 | +39.8 |
| PERIAPT WORTH | 5 | 5 | 5 | 0.14 | +458 | +91.5 |
| PIVOT GUARDS FLANK | 5 | 5 | 5 | 0.14 | -84 | -16.9 |
| BEST PRIZE | 4 | 4 | 4 | 0.11 | -400 | -100.1 |
| MISSILES IN THE FIRE PLAN | 43 | 8 | 4 | 0.11 | +92 | +22.9 |
| HUNT ADVANCE | 7 | 7 | 3 | 0.08 | +61 | +20.5 |
| LONE WIZARD HOLDS BACK | 12 | 12 | 3 | 0.08 | -246 | -82.1 |
| LONG SHOT | 37 | 35 | 3 | 0.08 | +53 | +17.7 |
| SHOOTERS ARE THREATS | 94 | 94 | 3 | 0.08 | +0 | +0.0 |
| STAY WEIGHED | 3 | 3 | 3 | 0.08 | +314 | +104.5 |
| WAR ENGINE CHARGES | 4 | 4 | 3 | 0.08 | +154 | +51.3 |
| BOMBING RUN | 2 | 2 | 2 | 0.06 | +66 | +33.2 |
| CARRIES OUT SET-UP | 4 | 4 | 2 | 0.06 | -77 | -38.6 |
| CATCH ODDS | 2 | 2 | 2 | 0.06 | -40 | -19.8 |
| DEFENSIVE FLOOR | 2 | 2 | 2 | 0.06 | +10 | +4.8 |
| EDGE GIVE GROUND | 15 | 15 | 2 | 0.06 | +9 | +4.4 |
| ELIXIR WORTH | 2 | 2 | 2 | 0.06 | +48 | +24.2 |
| FIRE AND FLEE | 2 | 2 | 2 | 0.06 | +10 | +5.1 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| STOPS | 4 | 4 | 2 | 0.06 | +100 | +50.2 |
| THREAT AT FULL SIZE | 155 | 155 | 2 | 0.06 | +0 | +0.0 |
| CONTINUE AHEAD WEIGHED | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| DEFENSIVE ARMY | 8 | 8 | 1 | 0.03 | -3 | -3.1 |
| HILL BY ITS CHANCE | 36 | 36 | 1 | 0.03 | +1 | +1.1 |
| JOINT CHARGE PLAN | 9 | 9 | 1 | 0.03 | +491 | +491.5 |
| MOVE SPELL IN RANGE | 15 | 9 | 1 | 0.03 | +52 | +52.4 |
| REDIRECT BY WHAT IT STOPS | 22 | 22 | 1 | 0.03 | +88 | +87.6 |
| SUPPORT JOB KEPT | 1 | 1 | 1 | 0.03 | +87 | +87.1 |
| SURE REACH TOGETHER | 20 | 15 | 1 | 0.03 | +0 | +0.0 |
| TURN WORTH | 46 | 45 | 1 | 0.03 | +9 | +8.6 |
| WIZARD FRONT RANK | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| ALREADY CARRIED | 5 | not checked | - | - | - | - |
| CANNON PLAN MISSED | 27 | 27 | 0 | 0.00 | - | - |
| CARRIES OUT COUNTER | 2 | 2 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 42 | trace | - | - | - | - |
| CHAMPION TAKES THE CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| CHARIOT NO STATIC JOB | 1 | 1 | 0 | 0.00 | - | - |
| CHARIOT WIZARD CAREFUL | 12 | 12 | 0 | 0.00 | - | - |
| CHEAP HELPER | 7 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 41 | not checked | - | - | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT LIFT | 1 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 384 | not checked | - | - | - | - |
| GIVES UP | 8 | 7 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 2 | 2 | 0 | 0.00 | - | - |
| GROUND FLIERS | 3 | not checked | - | - | - | - |
| HELPER ALREADY ASKED | 1 | not checked | - | - | - | - |
| HELPER UNSEEN | 26 | 25 | 0 | 0.00 | - | - |
| HUNT KEPT | 6 | trace | - | - | - | - |
| HUNT RESULT | 6 | trace | - | - | - | - |
| HUNT THE GUNS | 6 | trace | - | - | - | - |
| KEEPS ITS PREY | 4 | 4 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 20 | not checked | - | - | - | - |
| LURE BY WHAT IT DRAWS | 3 | 3 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 6 | trace | - | - | - | - |
| MARCH OVER CASTS | 30 | 30 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 14 | 14 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 25 | trace | - | - | - | - |
| MOVE SPELL SPOT | 23 | not checked | - | - | - | - |
| NOT NEEDED | 22 | 22 | 0 | 0.00 | - | - |
| NOT TURNED | 411 | 411 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 44 | not checked | - | - | - | - |
| OPENS A LANE | 7 | 2 | 0 | 0.00 | - | - |
| PLAN RESULT | 2744 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 28 | 28 | 0 | 0.00 | - | - |
| SCOUT SPOT | 19 | 19 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 12 | 12 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 21 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 29 | not checked | - | - | - | - |
| SET-UP MISSED | 7 | trace | - | - | - | - |
| SHOT OPTIONS | 870 | 870 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 31 | not checked | - | - | - | - |
| SPELL WORTH | 130 | not checked | - | - | - | - |
| STABLE ROLE | 740 | 739 | 0 | 0.00 | - | - |
| TWO OR MORE ARRIVE | 19 | 19 | 0 | 0.00 | - | - |

### Off best figure: sp-h2h-opp-89601ea-p4

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 13.39 | 11.14 | 55.4 |
| CHARGE NOW FIRST | rule | 0.58 | 0.81 | 50.6 |
| TURN GATE | gate | 0.83 | 0.56 | 23.8 |
| FALLBACK | gate | 0.44 | 0.81 | 44.8 |
| PATHS CROSS | rule | 0.25 | 0.19 | 13.1 |
| WAR ENGINE JOBS | rule | 0.28 | - | 39.3 |
| SURE CHARGE BEATS ADVANCE | rule | 0.08 | 0.17 | 73.3 |
| AFTERMATH BAND | gate | 0.08 | 0.14 | 2.6 |
| LONE CHARACTER SAFE SPOT | gate | 0.11 | 0.11 | 66.8 |
| SUPPORT NARROWED | rule | 0.03 | 0.19 | 19.9 |
| SUPPORT REQUEST | gate | 0.11 | 0.11 | 51.0 |
| CHARGE NOW WEIGHED | rule | 0.08 | 0.11 | 38.3 |
| FIRE PLAN | rule | - | 0.19 | 44.8 |
| PURSUES BIG PREY | rule | 0.08 | 0.11 | 70.0 |
| BIG CHARACTER SAFETY | rule | 0.06 | 0.11 | 12.7 |
| CHAFF PASSED | rule | 0.17 | - | 4.9 |
| KEEPS THE TARGET | rule | - | 0.17 | 45.6 |
| STOPS SHORT OF THE FLANK | rule | 0.06 | 0.11 | 12.7 |
| FIGHT ORDER BAND | gate | 0.08 | 0.06 | 1.4 |
| PIVOT GUARDS FLANK | rule | 0.08 | 0.06 | 16.9 |
| BEST PRIZE | rule | - | 0.11 | 100.1 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.06 | 0.03 | 39.5 |
| CANNON PLANNED TARGET | rule | 0.08 | - | 3.8 |
| FRIENDS SHOTS CHECKED | rule | 0.03 | 0.06 | 3.5 |
| LONE WIZARD HOLDS BACK | rule | 0.03 | 0.06 | 82.1 |
| REDIRECT WEIGHED | rule | - | 0.08 | 130.0 |
| THROUGH LINE OF FIRE | rule | 0.08 | - | 27.3 |
| BLOCKED WHEEL | rule | 0.03 | 0.03 | 1.7 |
| CARRIES OUT SET-UP | rule | - | 0.06 | 38.6 |
| CATCH ODDS | rule | - | 0.06 | 19.8 |
| DEFENSIVE ARMY | rule | 0.03 | - | 3.1 |
| FALLBACK BY WORTH | rule | 0.03 | - | 15.9 |
| MARCH ODDS | rule | 0.03 | - | 5.5 |
| RULE SWITCHED OFF | gate | 0.03 | - | 15.7 |
| WHO HITS BACK | rule | 0.03 | - | 3.3 |

### Plans: sp-h2h-opp-89601ea-p4

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 12.4 | 19% | 412 | 365 | 89% |
| Mine | charge | 4.1 | 63% | 335 | 403 | 120% |
| Mine | close in | 4.2 | 34% | 244 | 156 | 64% |
| Mine | hold | 4.1 | 36% | 272 | 0 | 0% |
| Mine | join | 0.7 | 96% | 13 | 0 | 0% |
| Mine | shoot | 9.2 | 66% | 404 | 879 | 217% |
| Mine | support | 3.4 | 90% | 38 | 0 | 0% |
| Opponent | advance | 13.4 | 18% | 364 | 382 | 105% |
| Opponent | charge | 4.4 | 57% | 605 | 409 | 68% |
| Opponent | close in | 5.9 | 31% | 530 | 186 | 35% |
| Opponent | hold | 4.0 | 27% | 273 | 0 | 0% |
| Opponent | join | 0.6 | 95% | 26 | 0 | 0% |
| Opponent | shoot | 4.0 | 57% | 316 | 218 | 69% |
| Opponent | support | 5.8 | 89% | 49 | 0 | 0% |

### Packages: hunt the guns, sp-h2h-opp-89601ea-p4

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.0 | 1 | 0 | 0% | 0% | 0% | - | 487 | 0 | 0% | 13 |
| Opponent | 0.1 | 5 | 0 | 40% | 40% | 0% | 3.5 | 350 | 83 | 20% | 122 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Dwarfen Mountain Holds | 0.3 | 1 | 0 | 0% | 0% | 0% | - | 487 | 0 | 0% | 112 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 21 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| High Elf Realms | 0.1 | 1 | 0 | 0% | 0% | 0% | - | 240 | 0 | 0% | 167 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 228 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 114 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 77 |
| Tomb Kings of Khemri | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Vampire Counts | 0.4 | 3 | 0 | 67% | 67% | 0% | 3.5 | 360 | 138 | 33% | 0 |
| Warriors of Chaos | 0.1 | 1 | 0 | 0% | 0% | 0% | - | 429 | 0 | 0% | 114 |
| Wood Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 62 |

### Battle groups: sp-h2h-opp-89601ea-p4

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 7.7 | 30% | 33% | 21% | 35% | 46% | 9% | 12% | 32% | 0% |
| Mine | REDIRECT COUNTER | 1.9 | 37% | 56% | 20% | 20% | 25% | 0% | 10% | 65% | 0% |
| Opponent | COUNTER-CHARGE COVER | 6.5 | 21% | 71% | 15% | 43% | 37% | 10% | 10% | 44% | 0% |
| Opponent | REDIRECT COUNTER | 3.9 | 22% | 71% | 13% | 25% | 11% | 0% | 11% | 78% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: sp-h2h-opp-89601ea-p4

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 4 | 110 (4) | 110 | 0 | 100 | 0% | 3.2 | - | 0 (1) | - | - | 0 (1) |
| Mine | Chaff | 34 | 15 (34) | 14 | 2 | 64 | 24% | 2.4 | 28 (14) | 0 (5) | 10 (15) | 19 (20) | 9 (14) |
| Mine | Character | 106 | 62 (106) | 62 | 0 | 41 | 11% | 2.4 | 56 (33) | 71 (46) | 53 (9) | 74 (45) | 55 (43) |
| Mine | Clean-up | 23 | 53 (23) | 21 | 32 | 41 | 26% | 2.3 | 0 (2) | 57 (17) | 64 (4) | 40 (11) | 61 (12) |
| Mine | Early | 1 | 0 (1) | 0 | 0 | 100 | 0% | 6.0 | - | 0 (1) | - | - | 0 (1) |
| Mine | Fast | 4 | 0 (4) | 0 | 0 | 73 | 25% | 3.0 | 0 (2) | 0 (2) | - | 0 (3) | 0 (1) |
| Mine | Fast Hammer | 40 | 36 (40) | 19 | 17 | 46 | 15% | 2.6 | 41 (25) | 39 (9) | 9 (6) | 39 (25) | 30 (15) |
| Mine | Fragile | 4 | 0 (4) | 0 | 0 | 27 | 25% | 2.0 | 0 (2) | 0 (2) | - | 0 (1) | 0 (3) |
| Mine | Hammer | 64 | 45 (64) | 35 | 9 | 47 | 14% | 2.7 | 26 (13) | 51 (42) | 38 (9) | 30 (39) | 62 (25) |
| Mine | Holder | 31 | 97 (31) | 13 | 83 | 28 | 39% | 2.8 | 27 (8) | 163 (16) | 24 (6) | 143 (19) | 38 (11) |
| Mine | Shooter | 35 | 64 (35) | 28 | 36 | 34 | 0% | 1.9 | 6 (8) | 102 (22) | 5 (5) | 51 (26) | 100 (9) |
| Mine | Support | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Mine | War machine | 56 | 64 (56) | 64 | 0 | 42 | 2% | 1.3 | 74 (16) | 73 (30) | 19 (10) | 69 (9) | 64 (47) |
| Mine | Wizard | 17 | 6 (17) | 6 | 0 | 51 | 0% | 2.6 | 0 (5) | 0 (6) | 0 (1) | 0 (6) | 0 (6) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Chaff | 77 | 47 (77) | 18 | 29 | 55 | 42% | 2.7 | 38 (32) | 74 (18) | 35 (27) | 48 (58) | 46 (19) |
| Opponent | Character | 97 | 59 (97) | 58 | 1 | 45 | 22% | 2.2 | 55 (42) | 70 (39) | 41 (7) | 50 (50) | 72 (38) |
| Opponent | Clean-up | 12 | 64 (12) | 35 | 29 | 59 | 8% | 2.7 | 0 (4) | 72 (5) | 97 (3) | 33 (7) | 85 (5) |
| Opponent | Fast | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Fast Hammer | 54 | 38 (54) | 25 | 13 | 49 | 26% | 3.0 | 44 (23) | 32 (23) | 24 (8) | 33 (33) | 45 (21) |
| Opponent | Fragile | 17 | 49 (17) | 49 | 0 | 55 | 29% | 2.1 | 59 (2) | 67 (11) | 0 (4) | 53 (14) | 35 (3) |
| Opponent | Hammer | 65 | 53 (65) | 37 | 16 | 42 | 25% | 3.3 | 21 (20) | 70 (38) | 0 (7) | 61 (41) | 42 (24) |
| Opponent | Holder | 30 | 45 (30) | 16 | 28 | 27 | 57% | 4.0 | 19 (9) | 64 (14) | 28 (6) | 75 (17) | 8 (12) |
| Opponent | Shooter | 34 | 69 (34) | 33 | 37 | 38 | 0% | 1.4 | 102 (10) | 58 (21) | 28 (3) | 88 (19) | 48 (15) |
| Opponent | Support | 6 | 41 (6) | 41 | 0 | 49 | 33% | 3.0 | 0 (3) | 0 (2) | 228 (1) | 0 (4) | 124 (2) |
| Opponent | War machine | 6 | 70 (6) | 70 | 0 | 42 | 17% | 1.0 | 87 (3) | 46 (3) | - | 87 (3) | 46 (3) |
| Opponent | Wizard | 20 | 7 (20) | 7 | 0 | 64 | 15% | 2.4 | 14 (10) | 5 (3) | 0 (3) | 7 (11) | 18 (5) |

### Charged fights: sp-h2h-opp-89601ea-p4

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 424 | 247 | 2.2 | 1.1 | 110 | 9 | +100 | 3 of 9 | 6 of 9 | +0 | +113 |
| Mine | Chaos Dwarfs | 4 | 196 | 402 | 3.2 | 1.1 | 124 | 0 | +124 | 7 of 13 | 12 of 13 | +91 | +126 |
| Mine | Dwarfen Mountain Holds | 3 | 376 | 295 | 2.0 | 1.3 | 147 | 144 | +3 | 2 of 6 | 4 of 6 | -119 | +64 |
| Mine | Empire of Man | 5 | 477 | 207 | 1.6 | 1.4 | 129 | 177 | -48 | 4 of 8 | 6 of 8 | -214 | +8 |
| Mine | Grand Cathay | 4 | 432 | 494 | 4.5 | 1.2 | 110 | 52 | +58 | 7 of 18 | 14 of 18 | +131 | +44 |
| Mine | High Elf Realms | 4 | 333 | 314 | 3.0 | 1.2 | 105 | 0 | +105 | 3 of 12 | 9 of 12 | +98 | +106 |
| Mine | Kingdom of Bretonnia | 1 | 330 | 467 | 6.0 | 1.0 | 78 | 0 | +78 | 3 of 6 | 5 of 6 | - | +78 |
| Mine | Lizardmen | 1 | 0 | 1289 | 7.0 | 1.3 | 184 | 154 | +30 | 5 of 7 | 5 of 7 | -233 | +135 |
| Mine | Ogre Kingdoms | 2 | 82 | 210 | 3.5 | 1.4 | 60 | 103 | -43 | 3 of 7 | 5 of 7 | +9 | -82 |
| Mine | Skaven | 2 | 342 | 284 | 3.5 | 1.0 | 81 | 5 | +76 | 1 of 7 | 5 of 7 | - | +76 |
| Mine | Tomb Kings of Khemri | 2 | 135 | 861 | 4.0 | 1.1 | 215 | 0 | +215 | 4 of 8 | 7 of 8 | +236 | +212 |
| Mine | Vampire Counts | 2 | 95 | 322 | 4.0 | 1.1 | 80 | 127 | -47 | 3 of 8 | 5 of 8 | -5 | -53 |
| Mine | Warriors of Chaos | 2 | 0 | 604 | 4.0 | 1.1 | 151 | 0 | +151 | 2 of 8 | 7 of 8 | +115 | +156 |
| **Mine** | all armies | 36 | 297 | 391 | 3.2 | 1.2 | 120 | 53 | +68 | 47 of 117 | 90 of 117 | -4 | +81 |
| Opponent | Empire of Man | 1 | 500 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | High Elf Realms | 5 | 113 | 524 | 4.2 | 1.1 | 125 | 35 | +90 | 14 of 21 | 13 of 21 | +213 | +77 |
| Opponent | Lizardmen | 2 | 0 | 240 | 2.0 | 1.0 | 120 | 56 | +64 | 3 of 4 | 3 of 4 | - | +64 |
| Opponent | Orc & Goblin Tribes | 3 | 0 | 316 | 3.3 | 1.3 | 95 | 61 | +34 | 3 of 10 | 8 of 10 | +181 | -30 |
| Opponent | Skaven | 4 | 272 | 20 | 2.0 | 1.0 | 10 | 129 | -119 | 5 of 8 | 4 of 8 | - | -119 |
| Opponent | Tomb Kings of Khemri | 2 | 153 | 478 | 3.0 | 1.3 | 159 | 0 | +159 | 4 of 6 | 5 of 6 | +270 | +104 |
| Opponent | Vampire Counts | 6 | 12 | 400 | 4.7 | 1.2 | 86 | 2 | +84 | 12 of 28 | 22 of 28 | +201 | +52 |
| Opponent | Warriors of Chaos | 7 | 31 | 691 | 4.6 | 1.1 | 151 | 17 | +134 | 18 of 32 | 22 of 32 | +629 | +101 |
| Opponent | Wood Elf Realms | 6 | 185 | 382 | 5.0 | 1.2 | 76 | 27 | +50 | 7 of 30 | 22 of 30 | +30 | +53 |
| **Opponent** | all armies | 36 | 107 | 406 | 3.9 | 1.2 | 105 | 29 | +76 | 66 of 139 | 99 of 139 | +206 | +54 |

### Effective charges: sp-h2h-opp-89601ea-p4

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 9 | 1 (net +500) | 0 | 2 (net +0) | 1 (net +151) | 0 | 4 (net +27) | 1 | 25% (2 of 8) |
| Mine | Chaos Dwarfs | 13 | 2 (net +202) | 0 | 2 (net +241) | 3 (net +87) | 2 (net +142) | 3 (net +58) | 1 | 17% (2 of 12) |
| Mine | Dwarfen Mountain Holds | 6 | 1 (net -60) | 0 | 0 | 2 (net -234) | 0 | 3 (net +182) | 0 | 0% (0 of 6) |
| Mine | Empire of Man | 8 | 0 | 0 | 3 (net -180) | 2 (net -197) | 2 (net +0) | 1 (net +551) | 0 | 38% (3 of 8) |
| Mine | Grand Cathay | 18 | 1 (net -205) | 1 (net +210) | 3 (net +37) | 4 (net +107) | 1 (net +0) | 7 (net +72) | 1 | 18% (3 of 17) |
| Mine | High Elf Realms | 12 | 2 (net +188) | 0 | 0 | 0 | 2 (net +198) | 8 (net +60) | 0 | 0% (0 of 12) |
| Mine | Kingdom of Bretonnia | 6 | 1 (net +0) | 0 | 0 | 1 (net +0) | 0 | 3 (net +156) | 1 | 0% (0 of 5) |
| Mine | Lizardmen | 7 | 0 | 0 | 1 (net -29) | 2 (net -158) | 0 | 3 (net +57) | 1 | 17% (1 of 6) |
| Mine | Ogre Kingdoms | 7 | 1 (net -495) | 0 | 1 (net +55) | 1 (net -228) | 1 (net +110) | 3 (net +85) | 0 | 14% (1 of 7) |
| Mine | Skaven | 7 | 0 | 0 | 2 (net +33) | 0 | 0 | 4 (net +64) | 1 | 33% (2 of 6) |
| Mine | Tomb Kings of Khemri | 8 | 0 | 0 | 1 (net +492) | 2 (net +174) | 1 (net +236) | 3 (net +167) | 1 | 14% (1 of 7) |
| Mine | Vampire Counts | 8 | 2 (net -20) | 0 | 2 (net +300) | 1 (net -928) | 1 (net -5) | 2 (net +0) | 0 | 25% (2 of 8) |
| Mine | Warriors of Chaos | 8 | 1 (net +0) | 0 | 1 (net +500) | 2 (net +142) | 3 (net +141) | 1 (net +0) | 0 | 12% (1 of 8) |
| Opponent | High Elf Realms | 21 | 4 (net -39) | 1 (net +310) | 1 (net +0) | 6 (net +96) | 0 | 7 (net +142) | 2 | 5% (1 of 19) |
| Opponent | Lizardmen | 4 | 0 | 1 (net +0) | 2 (net +114) | 0 | 0 | 1 (net +29) | 0 | 50% (2 of 4) |
| Opponent | Orc & Goblin Tribes | 10 | 2 (net -42) | 0 | 0 | 2 (net +160) | 2 (net +132) | 1 (net +0) | 3 | 0% (0 of 7) |
| Opponent | Skaven | 8 | 0 | 2 (net -496) | 1 (net +39) | 2 (net +0) | 0 | 3 (net +0) | 0 | 12% (1 of 8) |
| Opponent | Tomb Kings of Khemri | 6 | 1 (net +0) | 0 | 0 | 1 (net +60) | 0 | 2 (net +270) | 2 | 0% (0 of 4) |
| Opponent | Vampire Counts | 28 | 4 (net +0) | 1 (net +0) | 9 (net +67) | 2 (net +150) | 6 (net +101) | 4 (net +114) | 2 | 35% (9 of 26) |
| Opponent | Warriors of Chaos | 32 | 5 (net +132) | 0 | 3 (net +104) | 0 | 1 (net +110) | 13 (net +196) | 10 | 14% (3 of 22) |
| Opponent | Wood Elf Realms | 30 | 8 (net +3) | 0 | 1 (net -126) | 9 (net +30) | 4 (net +141) | 8 (net +94) | 0 | 3% (1 of 30) |

### Charged fights, damage counted: sp-h2h-opp-89601ea-p4

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 12 | 271 | 320 | +40 | 139 | 105 | +35 | +12.8 |
| Mine | 50-54% | 1 | 217 | 210 | +210 | 210 | 0 | +210 | +96.8 |
| Mine | Effective (55-75%) | 18 | 288 | 248 | +96 | 161 | 63 | +98 | +34.1 |
| Mine | 76-89% | 21 | 321 | 229 | -41 | 144 | 164 | -21 | -6.4 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 45 | 229 | 182 | +89 | 144 | 39 | +105 | +45.9 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 13 | 496 | 106 | +111 | 124 | 8 | +116 | +23.4 |
| Mine | No odds | 7 | 262 | 198 | +125 | 139 | 11 | +128 | +48.8 |
| Mine | All fights | 117 | 290 | 207 | +68 | 144 | 66 | +78 | +26.7 |
| Opponent | Long shot (under 50%) | 24 | 226 | 262 | +18 | 86 | 72 | +15 | +6.4 |
| Opponent | 50-54% | 5 | 300 | 289 | -136 | 62 | 238 | -176 | -58.8 |
| Opponent | Effective (55-75%) | 17 | 272 | 212 | +62 | 96 | 47 | +49 | +18.0 |
| Opponent | 76-89% | 22 | 331 | 186 | +69 | 115 | 34 | +81 | +24.6 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 39 | 327 | 207 | +136 | 157 | 34 | +123 | +37.7 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 13 | 555 | 119 | +119 | 123 | 13 | +110 | +19.8 |
| Opponent | No odds | 19 | 287 | 212 | +75 | 114 | 54 | +60 | +20.9 |
| Opponent | All fights | 139 | 318 | 209 | +76 | 118 | 50 | +68 | +21.4 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| sp-h2h-opp-89601ea-p4 | move | 431 | 100 (23%) | 76 (18%) | 61 (14%) | 270 (63%) |
| sp-h2h-opp-89601ea-p4 | objective | 364 | 61 (17%) | 43 (12%) | 53 (15%) | 250 (69%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0114, L0130, L2527, L2634 |
| Charmed Shield | Opponent | L0434, L0624, L0926, L1034, L1126, L1427, L2227, L2527, L2634, L3234 |
| Clockwork Compass | Mine | L1220 |
| Elixir of Power | Mine | L1126 |
| Elixir of Power | Opponent | L0819, L1719, L1819 |
| Fistful of Laurels | Mine | L1819, L1835 |
| Invocation of Nehek | Mine | L2527 |
| Invocation of Nehek | Opponent | L0624, L1427, L2227, L2527 |
| Opal Amulet | Mine | L1427 |
| Opal Amulet | Opponent | L0114, L0214, L1314 |
| Periapt of Soul Exchange | Mine | L2021, L2123 |
| Periapt of Soul Exchange | Opponent | L0520, L1220, L1621, L2021 |
| Ring of Doom | Mine | L0214, L0230, L1126, L1220, L1523 |
| Ring of Doom | Opponent | L0315, L1331, L2331 |
| Ring of Jet | Mine | L1017, L1034, L1126, L1220 |
| Standard of the Fell Warrior | Mine | L1314, L1331 |
| Standard of the Fell Warrior | Opponent | L0713 |
| Storm Daemon (Renegade 2.0) | Mine | L2123 |
| Storm Daemon (Renegade 2.0) | Opponent | L1621, L2021 |
| Twice-Blessed Armour | Mine | L0713, L0729, L1017, L1034 |
| Witch Hunter's Ward | Mine | L0713, L0729, L0819, L0835 |
| Witch Hunter's Ward | Opponent | L0608 |

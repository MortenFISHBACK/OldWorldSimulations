# Doctrine scorecard: sp-h2h-opp-89601ea-p1

### Scorecard: sp-h2h-opp-89601ea-p1

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0102 | 6 | 1 | Mine | no | 5 | 3 | 0 | 1 | 0 | 0 | 0 | 65 |
| L0102 | 6 | 1 | Opponent | no | 9 | 1 | 2 | 3 | 0 | 0 | 0 | 222 |
| L0118 | 4 | 1 | Mine | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 0 |
| L0118 | 4 | 1 | Opponent | no | 10 | 6 | 2 | 3 | 0 | 0 | 0 | 268 |
| L0135 | 3 | 1 | Mine | yes | 2 | - | 0 | 2 | 1 | 0 | 0 | 0 |
| L0135 | 3 | 1 | Opponent | no | 0 | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L0218 | 2 | 1 | Mine | - | - | 2 | 0 | 4 | 0 | 0 | 0 | 136 |
| L0218 | 2 | 1 | Opponent | - | - | 3 | 2 | 2 | 0 | 0 | 0 | 0 |
| L0235 | 1 | 1 | Mine | no | 4 | 2 | 2 | 4 | 0 | 0 | 0 | 170 |
| L0235 | 1 | 1 | Opponent | no | 0 | 2 | 1 | 1 | 0 | 0 | 0 | 140 |
| L0319 | 1 | 1 | Mine | no | 5 | 2 | 3 | 0 | 0 | 0 | 0 | 985 |
| L0319 | 1 | 1 | Opponent | no | 2 | 2 | 3 | 0 | 0 | 0 | 0 | 226 |
| L0405 | 3 | 1 | Mine | yes | 9 | 2 | 4 | 2 | 0 | 0 | 0 | 0 |
| L0405 | 3 | 1 | Opponent | no | 0 | - | 1 | 1 | 0 | 0 | 0 | 1104 |
| L0421 | 1 | 1 | Mine | no | 0 | 2 | 5 | 1 | 0 | 0 | 0 | 0 |
| L0421 | 1 | 1 | Opponent | no | 0 | - | 0 | 3 | 1 | 0 | 0 | 355 |
| L0508 | 4 | 1 | Mine | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 1193 |
| L0508 | 4 | 1 | Opponent | no | 0 | 3 | 1 | 4 | 0 | 0 | 0 | 605 |
| L0524 | 2 | 1 | Mine | - | - | 5 | 3 | 0 | 0 | 0 | 0 | 613 |
| L0524 | 2 | 1 | Opponent | - | - | 2 | 4 | 3 | 1 | 0 | 0 | 0 |
| L0612 | 6 | 1 | Mine | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 615 |
| L0612 | 6 | 1 | Opponent | no | 3 | - | 0 | 0 | 1 | 0 | 0 | 330 |
| L0628 | 4 | 1 | Mine | no | 0 | 6 | 3 | 1 | 0 | 0 | 0 | 984 |
| L0628 | 4 | 1 | Opponent | no | 0 | - | 1 | 2 | 0 | 0 | 0 | 0 |
| L0717 | 3 | 1 | Mine | yes | 11 | 2 | 1 | 1 | 0 | 0 | 0 | 420 |
| L0717 | 3 | 1 | Opponent | yes | 1 | 3 | 2 | 0 | 1 | 0 | 0 | 0 |
| L0733 | 1 | 1 | Mine | no | 3 | 5 | 1 | 2 | 0 | 0 | 0 | 375 |
| L0733 | 1 | 1 | Opponent | no | 0 | 2 | 2 | 2 | 0 | 0 | 0 | 0 |
| L0823 | 1 | 1 | Mine | no | 3 | - | 0 | 1 | 0 | 0 | 0 | 515 |
| L0823 | 1 | 1 | Opponent | no | 7 | 2 | 2 | 4 | 1 | 0 | 0 | 60 |
| L0913 | 1 | 1 | Mine | no | 0 | 6 | 0 | 0 | 0 | 0 | 0 | 420 |
| L0913 | 1 | 1 | Opponent | no | 4 | 2 | 3 | 0 | 0 | 0 | 0 | 140 |
| L0930 | 6 | 1 | Mine | no | 0 | 4 | 1 | 1 | 0 | 0 | 0 | 994 |
| L0930 | 6 | 1 | Opponent | no | 3 | 2 | 5 | 2 | 0 | 0 | 0 | 0 |
| L1021 | 1 | 1 | Mine | no | 0 | 2 | 3 | 0 | 0 | 0 | 0 | 330 |
| L1021 | 1 | 1 | Opponent | no | 0 | - | 3 | 6 | 1 | 0 | 0 | 355 |
| L1114 | 4 | 1 | Mine | no | 0 | 2 | 2 | 0 | 0 | 0 | 0 | 330 |
| L1114 | 4 | 1 | Opponent | no | 0 | 2 | 2 | 2 | 0 | 0 | 0 | 500 |
| L1131 | 3 | 1 | Mine | no | 0 | - | 1 | 0 | 0 | 0 | 0 | 330 |
| L1131 | 3 | 1 | Opponent | no | 3 | 5 | 0 | 0 | 0 | 0 | 0 | 286 |
| L1224 | 6 | 1 | Mine | no | 10 | 2 | 2 | 0 | 0 | 0 | 0 | 330 |
| L1224 | 6 | 1 | Opponent | no | 5 | 2 | 3 | 2 | 2 | 0 | 0 | 0 |
| L1319 | 5 | 1 | Mine | yes | - | 3 | 2 | 1 | 1 | 0 | 0 | 302 |
| L1319 | 5 | 1 | Opponent | no | - | 2 | 3 | 2 | 1 | 0 | 0 | 226 |
| L1335 | 3 | 1 | Mine | no | 0 | 2 | 4 | 0 | 1 | 0 | 0 | 140 |
| L1335 | 3 | 1 | Opponent | no | 4 | 3 | 2 | 3 | 0 | 0 | 0 | 126 |
| L1431 | 3 | 1 | Mine | yes | 9 | 2 | 5 | 0 | 0 | 0 | 0 | 0 |
| L1431 | 3 | 1 | Opponent | no | 0 | 5 | 1 | 0 | 2 | 0 | 0 | 460 |
| L1527 | 3 | 1 | Mine | yes | 1 | 4 | 1 | 1 | 0 | 0 | 0 | 0 |
| L1527 | 3 | 1 | Opponent | no | 0 | 2 | 2 | 2 | 0 | 0 | 0 | 0 |
| L1625 | 5 | 1 | Mine | yes | - | 3 | 4 | 0 | 0 | 0 | 0 | 200 |
| L1625 | 5 | 1 | Opponent | yes | - | 1 | 2 | 3 | 0 | 0 | 0 | 0 |
| L1723 | 1 | 1 | Mine | no | 0 | 1 | 2 | 0 | 3 | 0 | 0 | 98 |
| L1723 | 1 | 1 | Opponent | yes | 6 | 2 | 6 | 0 | 1 | 0 | 0 | 0 |
| L1823 | 5 | 1 | Mine | no | - | - | 2 | 1 | 1 | 0 | 0 | 305 |
| L1823 | 5 | 1 | Opponent | yes | - | 2 | 3 | 2 | 0 | 0 | 0 | 70 |
| L1923 | 3 | 1 | Mine | no | 0 | 2 | 4 | 0 | 0 | 0 | 0 | 0 |
| L1923 | 3 | 1 | Opponent | no | 4 | 2 | 4 | 1 | 1 | 0 | 0 | 0 |
| L2025 | 3 | 1 | Mine | yes | 4 | 2 | 3 | 0 | 0 | 0 | 0 | 420 |
| L2025 | 3 | 1 | Opponent | no | 6 | 3 | 6 | 1 | 0 | 0 | 0 | 0 |
| L2127 | 3 | 1 | Mine | yes | 7 | 4 | 1 | 4 | 0 | 0 | 0 | 500 |
| L2127 | 3 | 1 | Opponent | no | 2 | 2 | 1 | 1 | 1 | 0 | 0 | 0 |
| L2231 | 5 | 1 | Mine | yes | - | 2 | 6 | 0 | 0 | 0 | 0 | 72 |
| L2231 | 5 | 1 | Opponent | no | - | 2 | 5 | 1 | 2 | 0 | 0 | 933 |
| L2335 | 1 | 1 | Mine | no | 0 | 2 | 6 | 0 | 1 | 0 | 0 | 60 |
| L2335 | 1 | 1 | Opponent | no | 0 | 2 | 5 | 1 | 2 | 0 | 0 | 0 |
| L2531 | 5 | 1 | Mine | no | - | 4 | 3 | 3 | 0 | 0 | 0 | 68 |
| L2531 | 5 | 1 | Opponent | yes | - | 4 | 0 | 2 | 0 | 0 | 0 | 0 |
| L2730 | 6 | 1 | Mine | no | 1 | 1 | 9 | 3 | 0 | 0 | 0 | 60 |
| L2730 | 6 | 1 | Opponent | no | 4 | 4 | 3 | 0 | 0 | 0 | 0 | 0 |
| L2934 | 6 | 1 | Mine | no | 3 | 2 | 1 | 1 | 1 | 0 | 0 | 170 |
| L2934 | 6 | 1 | Opponent | no | 3 | 1 | 4 | 1 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 29% | 2.7 | 2.8 | 2.3 | 1.1 | 0.2 | 0.0 | 0.0 | 311.1 |
| **Average** | | | Opponent | 15% | 2.6 | 2.5 | 2.5 | 1.7 | 0.5 | 0.0 | 0.0 | 177.9 |

### KPIs: sp-h2h-opp-89601ea-p1

Rules off - Mine only: STAY WORTH, BEST MOVE FOR SHOOTERS, FACE THE CAST, WIZARD FRONT RANK, FIRE PLAN, FIRE IN ORDER, KEEPS THE TARGET, MISSILES IN THE FIRE PLAN, THREAT AT FULL SIZE, SHOOTERS ARE THREATS, SHOOTERS TO THE PRIMARY.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 26% (45 of 174) | 3% (5 of 183) | 14% (50 of 357) |
| Winner chose to follow up after the loser gave ground |  | 97% (89 of 92); on the table 98% | 98% (44 of 45); on the table 98% | 97% (133 of 137); on the table 98% |
| Winner chose to pursue after the loser fell back in good order |  | 86% (18 of 21); on the table 86% | 90% (18 of 20); on the table 95% | 88% (36 of 41); on the table 90% |
| Winner chose to pursue after the loser fled |  | 77% (24 of 31); on the table 81% | 92% (34 of 37); on the table 92% | 85% (58 of 68); on the table 87% |
| Winner chose to follow up or pursue (all three) |  | 91% (131 of 144); on the table 92% | 94% (96 of 102); on the table 95% | 92% (227 of 246); on the table 93% |
| Magic missiles tried each own turn | 50%+ | 33% (110 of 330) | 34% (72 of 210) | 34% (182 of 540) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 47% (110 of 233) | 48% (72 of 150) | 48% (182 of 383) |
|   fighting wizards (on a monster, chariot or monstrous mount) | 50%+ | 31% (46 of 150) | 27% (23 of 84) | 29% (69 of 234) |
|     round 1 |  | 24% (6 of 25) | 14% (2 of 14) | 21% (8 of 39) |
|     rounds 2+ |  | 32% (40 of 125) | 30% (21 of 70) | 31% (61 of 195) |
|   other wizards | 50%+ | 36% (64 of 180) | 39% (49 of 126) | 37% (113 of 306) |
|     round 1 |  | 20% (6 of 30) | 38% (8 of 21) | 27% (14 of 51) |
|     rounds 2+ |  | 39% (58 of 150) | 39% (41 of 105) | 39% (99 of 255) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 60% (18 of 30) | 52% (23 of 44) | 55% (41 of 74) |
| Points that never fought | lower | 37% (26328 of 71484) | 41% (29466 of 71889) | 39% (55794 of 143373) |
|   infantry points that never fought | lower | 48% (8119 of 16863) | 57% (7654 of 13348) | 52% (15773 of 30211) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 51% (142 of 279) | 61% (180 of 295) | 56% (322 of 574) |
| Bound items with a magic missile used (at least once a game) |  | 91% (20 of 22); 2.0 uses a game | 75% (15 of 20); 1.5 uses a game | 83% (35 of 42); 1.7 uses a game |
| Bound items with another spell used |  | 75% (12 of 16); 0.7 uses a game | 38% (3 of 8); 0.1 uses a game | 62% (15 of 24); 0.4 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 63% (12 of 19); 0.3 uses a game | 58% (7 of 12); 0.2 uses a game | 61% (19 of 31); 0.3 uses a game |
|   their share of the points of units over 100 pts | lower | 46% (27195 of 59666) | 57% (35482 of 62699) | 51% (62677 of 122365) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 2.3 (38%) | 1.2 (33%) | 3.6 (36%) |
| MARCHED: its unit marched | 0.8 (14%) | 0.6 (16%) | 1.4 (15%) |
| CHARGED: its unit charged | 0.2 (4%) | 0.1 (3%) | 0.3 (3%) |
| IN COMBAT: engaged in combat | 1.7 (27%) | 0.7 (18%) | 2.4 (24%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.1 (3%) | 0.1 (1%) |
| FLEEING: fleeing | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | 0.8 (14%) | 0.8 (20%) | 1.6 (16%) |
| OFF THE TABLE: off the table or not arrived | 0.2 (3%) | 0.2 (5%) | 0.4 (4%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.1 (2%) | 0.1 (1%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.4 | 1.6 | 1.4 | 5.1 | 0.5 | 2.1 |
| not cast | 3.6 | 2.8 | 3.3 | 9.9 | 1.8 | 21.9 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.8 (8%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.9 (31%) | 0.2 (6%) | 3.6 (36%) | 0.4 (25%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.4 (15%) | 0.2 (12%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (3%) | 0.1 (3%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.2 (5%) | 0.4 (13%) | 0.7 (21%) | 2.4 (24%) | 0.6 (31%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.3 (8%) | 0.3 (12%) | 0.4 (12%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) |
| NO CASTS LEFT: every cast used on other spells | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (2%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (1%) | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) |
| GONE: slain | 1.0 (28%) | 0.5 (19%) | 0.6 (18%) | 1.6 (16%) | 0.1 (6%) | 3.6 (16%) |
| OFF THE TABLE: off the table or not arrived | 0.3 (8%) | 0.2 (7%) | 0.1 (3%) | 0.4 (4%) | 0.0 (0%) | 0.6 (3%) |
| STUPIDITY: Stupidity | 0.0 (1%) | 0.1 (4%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.2 (6%) | 0.0 (0%) | 0.0 (0%) | 0.4 (22%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.8 (51%) | 0.2 (7%) | 1.3 (39%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 15.6 (71%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.2 a game | 0.4 a game | 0.8 a game |
| stood (cast and not dispelled) | 63% (26 of 41) | 73% (11 of 15) | 66% (37 of 56) |
| the unit moved after it | 69% (18 of 26) | 45% (5 of 11) | 62% (23 of 37) |
| it charged on its next turn | 4% (1 of 26) | 9% (1 of 11) | 5% (2 of 37) |
| the enemy charged it first | 19% (5 of 26) | 0% (0 of 11) | 14% (5 of 37) |
| it fought by the end of its next turn | 19% (5 of 26) | 0% (0 of 11) | 14% (5 of 37) |
| it moved out of a charge the enemy had planned (not charged first) | 15% (4 of 26) | 9% (1 of 11) | 14% (5 of 37) |
| none of these (no charge, no fight, no charge escaped) | 62% (16 of 26) | 82% (9 of 11) | 68% (25 of 37) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 65% (580 of 889) | 60% (369 of 616) | 63% (949 of 1505) |
|   cavalry | 71% (49 of 69) | 67% (87 of 130) | 68% (136 of 199) |
|   character | 50% (52 of 105) | 29% (33 of 115) | 39% (85 of 220) |
|   chariot | 52% (52 of 100) | 70% (31 of 44) | 58% (83 of 144) |
|   infantry | 57% (169 of 297) | 64% (150 of 236) | 60% (319 of 533) |
|   monster | 68% (23 of 34) | 52% (13 of 25) | 61% (36 of 59) |
|   war machine | 83% (235 of 284) | 83% (55 of 66) | 83% (290 of 350) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.4 (28%) | 1.4 (20%) | 3.8 (25%) |
| CHARGED: it charged | 0.9 (11%) | 1.3 (19%) | 2.2 (15%) |
| FLEEING: it fled or was fleeing | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: it fought this turn or the last | 1.0 (12%) | 0.5 (7%) | 1.5 (10%) |
| MOVED: a war machine that moved | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NO TARGET IN RANGE | 1.7 (19%) | 1.4 (21%) | 3.1 (20%) |
| ONLY IN COMBAT: the only targets were in combat | 0.4 (5%) | 0.9 (13%) | 1.3 (9%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.4 (17%) | 0.9 (13%) | 2.3 (15%) |
| SHELTERED: the target was sheltered | 0.2 (3%) | 0.2 (4%) | 0.5 (3%) |
| STUPIDITY | 0.1 (1%) | 0.1 (1%) | 0.1 (1%) |
| OTHER BAR | 0.3 (4%) | 0.2 (2%) | 0.5 (3%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 5.6 | 1.4 | 81% | 4.3 pts | 24 pts |
| character | 2.8 | 0.8 | 77% | 6.5 pts | 18 pts |
| chariot | 2.3 | 1.6 | 67% | 13.3 pts | 31 pts |
| infantry | 13.1 | 4.6 | 75% | 8.7 pts | 114 pts |
| monster | 1.1 | 0.4 | 76% | 7.8 pts | 9 pts |
| war machine | 8.1 | 5.1 | 69% | 20.2 pts | 163 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.5 | 5.7 | 5.1 |
| Charges that made contact a game | 3.5 | 3.8 | 3.7 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.24 declared, 1.00 contact (21 units) | 0.54 declared, 0.38 contact (13 units) | 0.97 declared, 0.76 contact (34 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.57 declared, 0.29 contact (7 units) | 0.88 declared, 0.75 contact (8 units) | 0.73 declared, 0.53 contact (15 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.54 declared, 0.42 contact (248 units) | 0.67 declared, 0.44 contact (288 units) | 0.61 declared, 0.43 contact (536 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 47% (33 of 70) | 57% (12 of 21) | 50% (4 of 8) | 49% (49 of 99) |
| Character in a unit | 87% (27 of 31) | 71% (17 of 24) | 40% (2 of 5) | 77% (46 of 60) |
| Character on its own | 77% (43 of 56) | 58% (21 of 36) | 31% (19 of 61) | 54% (83 of 153) |
| Chariot | 62% (10 of 16) | 40% (4 of 10) | - | 54% (14 of 26) |
| Infantry | 52% (46 of 89) | 28% (10 of 36) | 100% (2 of 2) | 46% (58 of 127) |
| Monster | 59% (19 of 32) | 80% (8 of 10) | - | 64% (27 of 42) |
| Monstrous | 73% (8 of 11) | 50% (7 of 14) | - | 60% (15 of 25) |
| War Machines | 71% (29 of 41) | 100% (1 of 1) | - | 71% (30 of 42) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 6 | 100% (19 of 19); on the table 100% | 41% (57 of 138) | 49% | 55% (18 of 33) | 89% (8 of 9); 5.7 uses a game | 100% (3 of 3); 1.8 uses a game | 89% (8 of 9); 1.3 uses a game |
| Chaos Dwarfs | 3 | 76% (13 of 17); on the table 76% | 33% (8 of 24) | 34% | 38% (9 of 24) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 0.3 uses a game |
| Dwarfen Mountain Holds | 5 | 93% (13 of 14); on the table 93% | - | 64% | 71% (29 of 41) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 6 | 67% (4 of 6); on the table 83% | 44% (16 of 36) | 63% | 66% (42 of 64) | 0.0 uses a game | 50% (1 of 2); 0.8 uses a game | 25% (1 of 4); 0.2 uses a game |
| Grand Cathay | 5 | 89% (24 of 27); on the table 89% | 32% (35 of 108) | 43% | 45% (20 of 44) | 92% (11 of 12); 7.0 uses a game | 100% (1 of 1); 0.2 uses a game | 40% (2 of 5); 0.4 uses a game |
| High Elf Realms | 6 | 84% (16 of 19); on the table 89% | 30% (9 of 30) | 34% | 35% (17 of 49) | 100% (5 of 5); 3.3 uses a game | 56% (10 of 18); 2.3 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | 100% (2 of 2); on the table 100% | - | 18% | 67% (4 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Lizardmen | 2 | 100% (7 of 7); on the table 100% | - | 29% | 64% (9 of 14) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 3 | 100% (3 of 3); on the table 100% | 8% (1 of 12) | 69% | 67% (14 of 21) | 100% (3 of 3); 3.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 3 | 100% (14 of 14); on the table 100% | 8% (3 of 36) | 7% | 58% (14 of 24) | 0.0 uses a game | 0.0 uses a game | 33% (1 of 3); 0.3 uses a game |
| Skaven | 4 | 93% (13 of 14); on the table 93% | 37% (11 of 30) | 18% | 62% (21 of 34) | 67% (2 of 3); 0.8 uses a game | 0.0 uses a game | 100% (4 of 4); 1.0 uses a game |
| Tomb Kings of Khemri | 6 | 91% (29 of 32); on the table 94% | 0% (0 of 12) | 35% | 23% (7 of 30) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 8 | 97% (36 of 37); on the table 97% | 37% (20 of 54) | 26% | 60% (30 of 50) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 8 | 96% (24 of 25); on the table 96% | 27% (8 of 30) | 35% | 64% (47 of 74) | 100% (4 of 4); 1.8 uses a game | 0.0 uses a game | 50% (1 of 2); 0.1 uses a game |
| Wood Elf Realms | 6 | 100% (10 of 10); on the table 100% | 47% (14 of 30) | 35% | 62% (41 of 66) | 33% (2 of 6); 1.7 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (sp-h2h-opp-89601ea-p1, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 52% (41) | 37% (26) | 45% (67) |
| ...free all their last turn and able to turn (per game) | 0.56 | 0.42 | 0.97 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.33 | 0.11 | 0.44 |
| ...with the charger already in that arc before they moved (per game) | 0.42 | 0.28 | 0.69 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 1.31 | 1.31 | 2.61 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.97 | 0.61 | 1.58 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 5.14 | 4.83 | 9.97 |

### Quality by phase: sp-h2h-opp-89601ea-p1

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.1 | 3.4 |
| Strategy | Charge objectives carried out (made contact) | 56% (85 of 151) | 44% (82 of 187) |
| Strategy | Shoot objectives carried out (shot that target) | 50% (193 of 383) | 43% (91 of 213) |
| Strategy | Close-in objectives charged next turn | 12% (17 of 139) | 15% (30 of 194) |
| Strategy | Support requests answered (helper made contact too) | 42% (8 of 19) | 50% (13 of 26) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 33% (1 of 3) | 0% (0 of 3) |
| Strategy | Hexes on a unit its side charged or shot that turn | 50% (8 of 16) | 55% (6 of 11) |
| Strategy | Joined characters whose unit fought | 38% (21 of 55) | 31% (11 of 35) |
| Strategy | Lone characters that fought | 86% (78 of 91) | 75% (76 of 101) |
| Movement | Charges halted short of contact | 0.1 | 0.2 |
| Movement | Idle units | 1.1 | 1.7 |
| Movement | Points that never moved of their own | 311.1 | 177.9 |
| Movement | Fights charged into per game | 2.8 | 3.2 |
| Movement | Charges with odds: long shots (under 50%) | 15 of 92, net -104 | 20 of 105, net +17 |
| Movement | Charges with odds: sweet spot (55-75%) | 14 of 92, net +196 | 18 of 105, net +56 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 11 of 92, net +78 | 7 of 105, net +94 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 33 of 92, net +91 | 31 of 105, net +147 |
| Shooting | Shots by shooting units (incl. breath weapons) | 10.5 | 9.8 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 40% (152 of 377) | 38% (135 of 351) |
| Shooting | Points destroyed by shooting units | 98.1 | 32.6 |
| Shooting | War machine shots | 6.5 | 1.5 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 40% (95 of 235) | 16% (9 of 55) |
| Shooting | Points destroyed by war machines | 69.4 | 10.9 |
| Magic | Magic missiles cast | 2.2 | 1.1 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 35% (27 of 78) | 38% (15 of 40) |
| Magic | Wounds caused by magic missiles | 5.8 | 1.3 |
| Magic | Wounds caused by other spells | 1.9 | 0.7 |
| Magic | Points destroyed by magic (all spells) | 122.2 | 22.2 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.7 / 0.5 / 0.8 / 0.1 | 1.6 / 0.4 / 0.6 / 0.1 |
| Combat | Points destroyed in combat | 383.6 | 339.1 |
| Combat | Points run down | 50.3 | 150.3 |
| Combat | Net points per charged fight, damage counted | +67 | +68 |
| Combat | Net per 100 charger points, damage counted | +22.5 | +28.4 |
| Combat | First round won (charged fights) | 80% | 60% |
| Combat | Net points per charged fight | +63 | +72 |
| Combat | Net points per supported fight / lone fight | +142 / +38 | +31 / +80 |
| Combat | Charged fights on a top-3 enemy unit | 42 of 101 | 49 of 117 |
| Game | Points lost | 669.3 | 812.4 |
| Game | VP from objectives | 631.7 | 602.5 |
| Game | Lone holders (player turns) | 2.7 | 2.6 |

- Mine won / drew / lost: 17 / 6 / 13 of 36 ended games (of 36); mean margin (Mine - Opponent) +174 VP
- The side that went first won 16 of 30 games with a winner
- Points traded per game (both sides' losses): 1482
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: sp-h2h-opp-89601ea-p1

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.6 | +0.0 | 0.0 | 0.0 | 0.8 | +0.0 | 0.0 | 0.0 |
| ARRIVAL HUNT | - | - | - | - | 0.0 | +0.2 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.3 | +0.0 | 0.0 | 15.4 | 0.4 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | 0.6 | +6.5 | 0.0 | 8.3 | 1.0 | +10.4 | 0.0 | 23.6 |
| BEST FACING | 0.6 | +28.7 | 0.0 | 25.3 | 0.5 | +24.8 | 0.0 | 11.2 |
| BEST FIRST | 4.0 | +193.5 | 185.3 | 69.0 | 4.0 | +174.6 | 117.6 | 50.9 |
| BEST MOVE FOR SHOOTERS | - | - | - | - | 0.8 | +66.3 | 0.0 | 13.1 |
| BEST OVERALL | 0.5 | +34.5 | 0.0 | 15.4 | 0.4 | +24.4 | 0.0 | 6.0 |
| BEST PREY | 0.9 | +53.8 | 63.5 | 15.3 | 0.9 | +44.3 | 6.8 | 20.1 |
| BEST PRIZE | 0.1 | +2.8 | 4.7 | 0.0 | 0.1 | +2.2 | 10.9 | 0.0 |
| BIG CHARACTER SAFETY | 0.2 | +0.3 | 0.0 | 22.1 | 0.1 | -0.5 | 0.0 | 12.1 |
| BLOCKED CHARGE SKIPPED | 0.1 | +0.0 | 2.9 | 0.0 | 0.1 | +0.0 | 0.0 | 1.2 |
| BLOCKED WHEEL | 0.3 | +11.6 | 0.0 | 9.3 | 0.4 | +20.1 | 0.0 | 21.9 |
| BOMBING RUN | 0.0 | +0.9 | 4.0 | 4.2 | - | - | - | - |
| CANNON PLAN MISSED | 0.6 | +0.0 | 59.7 | 17.6 | - | - | - | - |
| CANNON PLANNED TARGET | 5.0 | +131.6 | 347.5 | 105.7 | - | - | - | - |
| CANNON SIGHT KEPT | 1.0 | +0.0 | 0.0 | 3.5 | 0.4 | +0.0 | 0.0 | 7.2 |
| CARRIES OUT COUNTER | - | - | - | - | 0.1 | +0.0 | 1.4 | 0.0 |
| CARRIES OUT SET-UP | 0.1 | +0.0 | 7.6 | 10.6 | 0.1 | -4.9 | 16.7 | 1.9 |
| CAST JOB | 0.6 | +26.7 | 63.9 | 12.3 | 0.5 | +3.5 | 3.3 | 13.8 |
| CASTER AWAY FROM SCREEN | 0.4 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.4 | +45.7 | 18.2 | 9.6 | 0.2 | +6.9 | 4.7 | 0.0 |
| CASTS AFTER FRIENDS | 0.7 | +0.0 | 0.0 | 25.7 | 0.3 | +0.0 | 0.0 | 7.6 |
| CASTS FROM BEHIND | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.1 | +0.9 | 0.0 | 0.0 | 0.0 | +0.2 | 0.0 | 0.0 |
| CATCH ODDS | - | - | - | - | 0.1 | +1.8 | 0.0 | 0.0 |
| CHAFF PASSED | 0.1 | -0.1 | 0.0 | 11.0 | - | - | - | - |
| CHARGE NOW FIRST | 3.0 | +0.0 | 288.7 | 120.8 | 2.7 | +0.0 | 217.7 | 37.4 |
| CHARGE NOW WEIGHED | 0.4 | -31.8 | 9.5 | 14.2 | 0.5 | -33.4 | 24.2 | 4.3 |
| CHARIOT WIZARD CAREFUL | 0.1 | -3.3 | 9.5 | 11.1 | 0.1 | -1.2 | 0.0 | 0.0 |
| CHEAP HELPER | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 7.2 | 4.3 |
| COMBAT PIVOT | 0.5 | +0.0 | 49.9 | 18.6 | 0.6 | +0.0 | 75.5 | 0.0 |
| CONVEYANCE SEARCH | 0.7 | +126.0 | 0.0 | 3.6 | 0.3 | +73.7 | 3.2 | 15.2 |
| COUNTER-CHARGE COVER | 9.3 | +686.8 | 0.0 | 175.3 | 6.9 | +628.4 | 0.0 | 175.1 |
| DEFENSIVE ARMY | 0.4 | +0.0 | 37.4 | 5.9 | 0.1 | +0.0 | 12.4 | 0.0 |
| DEFENSIVE FLOOR | 0.1 | +5.6 | 4.0 | 6.7 | 0.0 | +1.7 | 2.4 | 0.0 |
| EDGE GIVE GROUND | 0.1 | +13.6 | 22.3 | 3.4 | 0.1 | +12.4 | 21.4 | 0.0 |
| ELIXIR WORTH | - | - | - | - | 0.0 | +1.3 | 0.0 | 0.0 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACE THE CAST | - | - | - | - | 0.1 | +0.2 | 0.0 | 3.2 |
| FACES THE THREAT | 1.3 | +135.6 | 0.0 | 62.4 | 1.3 | +146.2 | 0.0 | 46.4 |
| FALLBACK BY WORTH | 4.8 | +49.2 | 0.0 | 50.4 | 5.1 | +87.8 | 0.0 | 43.0 |
| FIGHT LIFT | 0.0 | +0.8 | 7.0 | 0.0 | - | - | - | - |
| FIRE AND FLEE | 0.0 | +0.1 | 0.0 | 0.0 | - | - | - | - |
| FIRE IN ORDER | - | - | - | - | 0.4 | +0.0 | 9.2 | 4.4 |
| FIRE PLAN | - | - | - | - | 10.5 | +255.0 | 297.3 | 95.4 |
| FLANK NOT WEIGHED | 5.1 | +0.0 | 0.0 | 110.2 | 5.0 | +0.0 | 0.0 | 181.4 |
| FOCUS FIRE | 0.1 | +4.5 | 6.9 | 0.0 | - | - | - | - |
| FOLLOW UP WEIGHED | 1.2 | +192.5 | 0.0 | 29.3 | 0.7 | +93.3 | 0.0 | 40.8 |
| FRIENDS SHOTS CHECKED | 0.4 | +26.3 | 0.0 | 54.3 | 0.1 | +0.5 | 0.0 | 0.0 |
| GIVES UP | 0.1 | -1.3 | 4.4 | 1.4 | 0.2 | -3.5 | 30.3 | 9.4 |
| GIVES UP ITS SCREEN | 0.1 | -0.1 | 11.0 | 4.9 | - | - | - | - |
| HELPER ALREADY ASKED | 0.0 | +0.0 | 0.0 | 1.4 | 0.1 | +0.0 | 7.9 | 0.0 |
| HELPER UNSEEN | 0.1 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 25.3 | 2.8 |
| HILL BY ITS CHANCE | - | - | - | - | 0.1 | -18.9 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.8 | +0.0 | 0.0 | 0.0 |
| HUNT ADVANCE | 0.1 | +0.3 | 7.6 | 1.7 | 0.3 | +9.2 | 8.1 | 9.3 |
| HUNT DROPPED | - | - | - | - | 0.2 | +0.0 | 9.2 | 6.1 |
| HUNT IN PAIRS | 0.4 | +32.5 | 0.0 | 0.0 | 0.2 | +6.0 | 0.0 | 5.4 |
| HUNT KEPT | 0.0 | +0.0 | 7.6 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| HUNT RESULT | 0.0 | +0.0 | 0.0 | 0.0 | 0.4 | +14.8 | 19.4 | 8.8 |
| HUNT THE GUNS | 0.1 | +14.3 | 7.6 | 1.7 | 0.4 | +140.4 | 11.9 | 12.0 |
| INVITES THE FIGHT | 1.9 | +46.4 | 91.3 | 42.2 | 1.6 | +30.8 | 45.4 | 36.1 |
| JOINT CHARGE PLAN | 0.1 | +6.9 | 0.0 | 3.4 | 0.1 | +11.1 | 0.0 | 0.0 |
| KEEP FALLS | 0.1 | +0.2 | 0.0 | 0.0 | 0.0 | +0.1 | 0.0 | 0.0 |
| KEEPS ITS PREY | 0.0 | +0.1 | 0.0 | 7.4 | 0.1 | +0.2 | 0.0 | 0.0 |
| KEEPS ITS TARGET | 1.7 | +51.7 | 159.7 | 54.0 | 2.1 | +64.2 | 172.9 | 33.1 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KEEPS THE TARGET | - | - | - | - | 1.2 | -33.0 | 47.4 | 24.3 |
| KILLS COUNT | 2.0 | +74.1 | 133.7 | 38.3 | 2.2 | +90.2 | 185.1 | 49.3 |
| KILLS COUNT NEXT TURN | 4.5 | +176.5 | 182.5 | 54.8 | 6.4 | +258.4 | 204.5 | 190.5 |
| LONE CHARACTER SAFE SPOT | 0.4 | +4.6 | 7.9 | 0.0 | 0.5 | +8.1 | 6.6 | 19.8 |
| LONE WIZARD HOLDS BACK | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 13.0 |
| LONE WIZARD KEPT IN | 0.7 | +49.1 | 0.0 | 0.0 | 0.2 | +24.5 | 0.0 | 0.0 |
| LONG SHOT | 0.3 | -2.9 | 14.9 | 3.6 | 0.4 | +1.8 | 7.1 | 3.5 |
| LOST CHARGE | 3.1 | -62.7 | 112.5 | 108.6 | 2.7 | -49.3 | 63.6 | 79.0 |
| LURE BY WHAT IT DRAWS | 0.1 | -3.2 | 0.0 | 1.0 | 0.0 | -4.9 | 0.0 | 4.0 |
| MAKE SURE TOGETHER | 0.7 | +97.7 | 22.6 | 26.2 | 0.6 | +28.4 | 12.0 | 9.8 |
| MANOEUVRE | 0.2 | +7.5 | 0.0 | 0.0 | 0.2 | +4.6 | 0.0 | 2.1 |
| MARCH AT ESCAPER | 0.1 | +0.7 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | 0.6 | +23.4 | 0.0 | 0.0 | 0.4 | +14.2 | 0.0 | 0.0 |
| MARCH ODDS | 0.2 | +19.4 | 6.0 | 0.0 | 0.3 | +7.3 | 8.0 | 0.0 |
| MARCH OVER CASTS | 0.3 | +12.0 | 0.0 | 15.6 | 0.3 | +37.9 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 5.1 | +217.1 | 0.0 | 84.5 | 4.8 | +152.3 | 0.0 | 135.0 |
| MISSILES IN THE FIRE PLAN | - | - | - | - | 2.2 | +62.4 | 38.1 | 53.0 |
| MISSILES IN THE MOVE | 4.4 | +199.4 | 0.0 | 86.4 | 3.8 | +53.4 | 0.0 | 64.9 |
| MISSILES NEXT TURN | 5.0 | +125.8 | 0.0 | 112.6 | 4.1 | +35.0 | 0.0 | 70.3 |
| MODEL FACING | 0.2 | +100.2 | 0.0 | 3.3 | - | - | - | - |
| MONSTER WIZARD ROAMS | 0.1 | +0.0 | 6.2 | 0.0 | 0.1 | +0.0 | 0.0 | 5.7 |
| MOVE AND CAST | 0.2 | +18.5 | 0.0 | 11.1 | 0.6 | +27.6 | 0.0 | 16.4 |
| MOVE SPELL IN RANGE | 0.1 | +5.6 | 0.0 | 0.0 | 0.1 | +0.4 | 0.0 | 7.6 |
| MOVE SPELL OUT OF RANGE | 0.2 | -39.1 | 0.0 | 3.6 | 0.2 | -23.4 | 6.9 | 22.8 |
| MOVE SPELL SPOT | 0.3 | +0.0 | 0.0 | 11.1 | 0.1 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE | 2.9 | +248.9 | 103.4 | 73.6 | 4.0 | +318.9 | 139.4 | 150.6 |
| MOVES UNITS SPELL | 0.1 | +3.4 | 0.0 | 0.0 | 0.1 | +1.8 | 0.0 | 0.0 |
| NEEDED THERE | 0.1 | +4.2 | 6.9 | 0.0 | 0.1 | +18.1 | 20.2 | 32.5 |
| NOT NEEDED | 0.2 | -11.5 | 44.1 | 17.8 | 0.3 | -15.6 | 24.6 | 1.9 |
| NOT TURNED | 5.1 | +92.6 | 0.0 | 70.4 | 4.8 | +51.0 | 0.0 | 170.4 |
| NOT WORTH A CAST | 0.6 | -0.6 | 0.0 | 23.5 | 0.2 | -0.2 | 0.0 | 0.0 |
| OFF BEST | 16.6 | -830.9 | 21.0 | 271.4 | 14.7 | -768.6 | 5.3 | 248.3 |
| OPENS A LANE | 0.2 | +0.6 | 37.6 | 0.0 | 0.1 | +0.3 | 4.6 | 0.0 |
| OPENS UP | 0.2 | +22.1 | 10.4 | 13.7 | 0.2 | +28.2 | 13.3 | 7.9 |
| OVERRUNS AWAY | 0.4 | +8.0 | 53.1 | 20.2 | 0.6 | +20.1 | 27.4 | 7.1 |
| PATHS CROSS | 1.9 | +120.0 | 0.0 | 36.9 | 2.5 | +193.0 | 0.0 | 41.8 |
| PERIAPT WORTH | 0.1 | +5.0 | 0.0 | 0.0 | 0.1 | +4.9 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.2 | -3.4 | 0.0 | 0.9 | 0.1 | -2.4 | 0.0 | 2.9 |
| PLAN RESULT | 37.6 | +1483.0 | 1435.2 | 912.1 | 37.6 | +1163.4 | 1249.8 | 990.7 |
| PURSUES BIG PREY | 0.1 | -15.3 | 0.0 | 5.2 | 0.2 | -12.9 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE | - | - | - | - | 0.0 | +4.9 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE NEXT TURN | - | - | - | - | 0.1 | +13.9 | 0.0 | 0.0 |
| RANDOM MOVE BY FIGURES | 0.8 | +11.9 | 0.0 | 0.0 | 1.2 | +13.1 | 0.0 | 64.4 |
| RANDOM MOVER NO PROMISE | 0.2 | -10.8 | 7.6 | 0.0 | 0.3 | -11.9 | 0.0 | 18.9 |
| REDIRECT BY WHAT IT STOPS | 0.2 | -0.8 | 0.0 | 3.2 | 0.3 | -5.7 | 0.0 | 8.8 |
| REDIRECT COUNTER | 2.4 | +170.1 | 0.0 | 44.2 | 3.9 | +336.2 | 0.0 | 57.1 |
| REDIRECT WEIGHED | 0.2 | +3.9 | 4.7 | 6.9 | 0.4 | +11.0 | 26.1 | 0.0 |
| RESERVE FALL BACK | 0.6 | +14.6 | 0.0 | 2.0 | 1.0 | +61.1 | 0.0 | 24.5 |
| RESTRAINS TO SHOOT | 0.1 | +3.3 | 0.0 | 5.8 | 0.1 | +5.3 | 0.0 | 0.0 |
| RISK BY ARC | 2.7 | +121.0 | 262.6 | 124.0 | 3.1 | +73.3 | 238.5 | 74.8 |
| SAFER THAN THE JOB | 1.0 | +49.6 | 0.0 | 32.0 | 0.6 | +31.4 | 0.0 | 19.4 |
| SCOUT SPOT | 0.4 | +0.6 | 0.0 | 0.0 | 0.3 | +0.3 | 0.0 | 0.9 |
| SCOUT WAITS | 0.4 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.9 |
| SCREEN BY WHAT IT SAVES | 0.1 | -8.3 | 0.0 | 0.0 | 0.1 | -0.4 | 0.0 | 1.2 |
| SEARCH SPOT | 2.2 | +98.4 | 0.0 | 52.9 | 2.9 | +156.5 | 0.0 | 24.7 |
| SELF MOVE SPELL | 0.2 | +12.8 | 0.0 | 40.1 | 0.2 | -0.1 | 0.0 | 0.0 |
| SET UP TOGETHER | 1.1 | +180.4 | 50.6 | 27.8 | 1.1 | +70.7 | 12.0 | 20.7 |
| SET-UP ANY TARGET | 0.3 | +39.7 | 0.0 | 3.6 | 0.2 | +18.3 | 3.2 | 15.2 |
| SET-UP MISSED | 0.0 | +0.6 | 0.0 | 0.0 | 0.1 | +4.6 | 0.0 | 0.0 |
| SHOOTER COUNTED ONCE | 0.0 | -0.1 | 0.0 | 0.0 | 0.0 | -0.1 | 0.0 | 0.0 |
| SHOOTERS ARE THREATS | - | - | - | - | 2.7 | +308.2 | 106.2 | 29.9 |
| SHOOTERS IN TWO RANKS | 0.4 | +0.9 | 0.0 | 0.0 | 0.3 | +0.8 | 0.0 | 0.0 |
| SHOOTERS TO THE PRIMARY | - | - | - | - | 3.7 | +176.8 | 0.0 | 37.2 |
| SHOOTS FROM THE BEST SPOT | 1.4 | +53.5 | 125.6 | 19.9 | 0.7 | +12.8 | 27.9 | 26.2 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 3.8 |
| SHOT OPTIONS | 15.8 | +0.0 | 858.9 | 323.2 | 10.5 | +0.0 | 287.9 | 120.3 |
| SHOT REPLANNED | 0.7 | +0.0 | 140.6 | 9.7 | - | - | - | - |
| SHOTS IN THE MOVE | 14.2 | +543.3 | 0.0 | 266.9 | 9.3 | +246.6 | 0.0 | 90.1 |
| SPELL SETS UP CHARGE | 0.5 | +134.8 | 0.0 | 3.6 | 0.2 | +45.3 | 3.2 | 15.2 |
| SPELL WORTH | 1.5 | +26.9 | 107.4 | 67.6 | 1.6 | +37.9 | 105.6 | 105.6 |
| STABLE ROLE | 11.0 | +0.0 | 441.5 | 123.0 | 10.8 | +0.0 | 376.7 | 136.0 |
| STANDS TO CAST | 0.1 | +4.7 | 0.0 | 0.0 | 0.0 | +1.4 | 3.2 | 0.0 |
| STAY WEIGHED | 0.0 | +1.0 | 0.0 | 0.0 | - | - | - | - |
| STAY WORTH | - | - | - | - | 10.4 | +46.4 | 132.9 | 46.4 |
| STOPS | - | - | - | - | 0.1 | +2.1 | 3.9 | 2.6 |
| STOPS SHORT OF THE FLANK | 0.5 | +33.0 | 0.0 | 13.2 | 0.4 | +27.2 | 0.0 | 5.1 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 4.0 |
| SUPPORT NARROWED | 5.2 | -44.9 | 352.1 | 107.7 | 6.9 | -44.8 | 359.8 | 102.3 |
| SUPPORTS | 3.2 | +46.5 | 167.3 | 53.4 | 4.4 | +49.3 | 163.0 | 60.7 |
| SURE CHARGE BEATS ADVANCE | 0.1 | -3.3 | 3.9 | 7.1 | 0.1 | -7.1 | 9.6 | 1.1 |
| SURE REACH TOGETHER | 0.6 | -2.7 | 16.5 | 0.0 | 0.8 | +0.7 | 0.0 | 39.9 |
| THREAT AT FULL SIZE | - | - | - | - | 6.4 | +0.0 | 188.6 | 67.8 |
| THROUGH LINE OF FIRE | 0.6 | +15.8 | 0.0 | 25.9 | 0.4 | +13.6 | 0.0 | 15.6 |
| TURN WORTH | 0.5 | -31.9 | 24.2 | 34.9 | 0.5 | -34.4 | 32.8 | 9.8 |
| TWO OR MORE ARRIVE | 0.4 | +7.0 | 0.0 | 1.7 | 0.3 | +1.1 | 5.5 | 3.4 |
| WAIT AFTER COSTS | 7.0 | -345.4 | 286.1 | 143.4 | 7.9 | -413.6 | 276.4 | 206.8 |
| WALKS TO THE FIGHT | 1.9 | +44.8 | 44.9 | 33.6 | 1.3 | +48.4 | 40.3 | 6.0 |
| WAR ENGINE CHARGES | 0.1 | +10.2 | 13.1 | 1.8 | 0.1 | +3.7 | 0.0 | 0.0 |
| WAR ENGINE JOBS | 0.7 | +0.0 | 46.1 | 17.1 | 0.6 | +0.0 | 16.3 | 11.2 |
| WEARS DOWN | 1.0 | +56.2 | 132.6 | 61.2 | 1.4 | +37.2 | 123.7 | 41.0 |
| WHO HITS BACK | 0.2 | +18.3 | 0.0 | 5.1 | 0.2 | +18.2 | 0.0 | 17.1 |
| WHOLE FIGHT | 0.3 | +13.1 | 66.9 | 13.7 | 0.4 | +14.8 | 37.5 | 6.9 |
| WHOLE FIGHT GAIN | 0.2 | +13.4 | 20.8 | 11.2 | 0.6 | +49.2 | 78.2 | 17.0 |
| WOUNDED STAYS OUT | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |

### Rule changes: sp-h2h-opp-89601ea-p1

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 1127 | 1127 | 1127 | 31.31 | -57582 | -51.1 |
| BEST FIRST | 287 | 287 | 287 | 7.97 | +13249 | +46.2 |
| SEARCH SPOT | 184 | 184 | 181 | 5.03 | +9178 | +50.7 |
| COUNTER-CHARGE COVER | 585 | 319 | 164 | 4.56 | +9721 | +59.3 |
| PATHS CROSS | 160 | 160 | 160 | 4.44 | +11268 | +70.4 |
| FIRE PLAN | 378 | 378 | 146 | 4.06 | +5043 | +34.5 |
| MOVE TO CHARGE | 248 | 248 | 127 | 3.53 | +7399 | +58.3 |
| KILLS COUNT NEXT TURN | 392 | 392 | 115 | 3.19 | +4297 | +37.4 |
| FACES THE THREAT | 94 | 94 | 94 | 2.61 | +10146 | +107.9 |
| SUPPORTS | 274 | 274 | 91 | 2.53 | +977 | +10.7 |
| FALLBACK BY WORTH | 358 | 358 | 81 | 2.25 | +4931 | +60.9 |
| WALKS TO THE FIGHT | 116 | 116 | 73 | 2.03 | +1416 | +19.4 |
| FOLLOW UP WEIGHED | 69 | 69 | 69 | 1.92 | +10289 | +149.1 |
| SHOTS IN THE MOVE | 845 | 562 | 65 | 1.81 | +1134 | +17.5 |
| WAIT AFTER COSTS | 536 | 536 | 63 | 1.75 | +1120 | +17.8 |
| ARTILLERY RE-ROLL WEIGHED | 61 | 61 | 61 | 1.69 | +0 | +0.0 |
| RESERVE FALL BACK | 57 | 57 | 57 | 1.58 | +2723 | +47.8 |
| SAFER THAN THE JOB | 57 | 57 | 57 | 1.58 | +2916 | +51.2 |
| CANNON SIGHT KEPT | 52 | 52 | 52 | 1.44 | +0 | +0.0 |
| REDIRECT COUNTER | 227 | 127 | 51 | 1.42 | +4680 | +91.8 |
| CHARGE NOW FIRST | 203 | 203 | 50 | 1.39 | -4446 | -88.9 |
| ADVANCE LANE KEPT | 49 | 49 | 49 | 1.36 | +0 | +0.0 |
| HOLDS AMBUSHERS | 44 | 44 | 44 | 1.22 | +0 | +0.0 |
| RISK BY ARC | 209 | 197 | 43 | 1.19 | +1643 | +38.2 |
| MISSILES IN THE MOVE | 295 | 172 | 42 | 1.17 | +1566 | +37.3 |
| RANDOM MOVE BY FIGURES | 74 | 74 | 41 | 1.14 | +898 | +21.9 |
| SHOOTS FROM THE BEST SPOT | 75 | 75 | 41 | 1.14 | +1149 | +28.0 |
| CANNON PLANNED TARGET | 181 | 181 | 40 | 1.11 | +131 | +3.3 |
| COMBAT PIVOT | 40 | 40 | 40 | 1.11 | +0 | +0.0 |
| KILLS COUNT | 152 | 146 | 40 | 1.11 | +1722 | +43.0 |
| MAX FOR POSITIONING | 357 | 214 | 39 | 1.08 | +449 | +11.5 |
| BEST FACING | 37 | 37 | 37 | 1.03 | +1926 | +52.1 |
| SET UP TOGETHER | 80 | 69 | 37 | 1.03 | +3760 | +101.6 |
| CHARGE NOW WEIGHED | 35 | 35 | 35 | 0.97 | +2715 | +77.6 |
| MARCH CHECK | 38 | 37 | 35 | 0.97 | +1970 | +56.3 |
| LONE WIZARD KEPT IN | 34 | 34 | 34 | 0.94 | +2648 | +77.9 |
| STOPS SHORT OF THE FLANK | 33 | 33 | 33 | 0.92 | +2170 | +65.8 |
| THROUGH LINE OF FIRE | 33 | 33 | 33 | 0.92 | +1058 | +32.0 |
| INVITES THE FIGHT | 128 | 128 | 32 | 0.89 | +593 | +18.5 |
| BEST OVERALL | 31 | 31 | 31 | 0.86 | +2119 | +68.4 |
| BEST MOVE FOR SHOOTERS | 29 | 29 | 29 | 0.81 | +2388 | +82.3 |
| MOVE AND CAST | 29 | 29 | 29 | 0.81 | +1659 | +57.2 |
| BEST PREY | 67 | 67 | 28 | 0.78 | +759 | +27.1 |
| BLOCKED WHEEL | 26 | 26 | 26 | 0.72 | +1143 | +43.9 |
| SCOUT WAITS | 26 | 26 | 26 | 0.72 | +0 | +0.0 |
| CASTER AWAY FROM SCREEN | 25 | 25 | 25 | 0.69 | +0 | +0.0 |
| SHOT REPLANNED | 25 | 25 | 25 | 0.69 | +0 | +0.0 |
| SHOOTERS IN TWO RANKS | 24 | 24 | 24 | 0.67 | +58 | +2.4 |
| KEEPS ITS TARGET | 139 | 137 | 23 | 0.64 | +382 | +16.6 |
| REDIRECT WEIGHED | 19 | 19 | 19 | 0.53 | +329 | +17.3 |
| MARCH ODDS | 18 | 18 | 18 | 0.50 | +245 | +13.6 |
| STAY WORTH | 376 | 304 | 18 | 0.50 | +172 | +9.5 |
| CAST JOB | 40 | 40 | 17 | 0.47 | +316 | +18.6 |
| FRIENDS SHOTS CHECKED | 17 | 17 | 17 | 0.47 | +965 | +56.8 |
| KEEPS THE TARGET | 44 | 44 | 17 | 0.47 | -1339 | -78.8 |
| MAKE SURE TOGETHER | 44 | 31 | 17 | 0.47 | +1582 | +93.1 |
| FIRE IN ORDER | 16 | 16 | 16 | 0.44 | +0 | +0.0 |
| CASTING BLOCK | 23 | 23 | 15 | 0.42 | +693 | +46.2 |
| WHO HITS BACK | 15 | 15 | 15 | 0.42 | +851 | +56.7 |
| WHOLE FIGHT GAIN | 30 | 24 | 15 | 0.42 | +732 | +48.8 |
| CASTS FROM BEHIND | 14 | 14 | 14 | 0.39 | +0 | +0.0 |
| WAR ENGINE JOBS | 45 | 45 | 14 | 0.39 | -1200 | -85.7 |
| MANOEUVRE | 16 | 16 | 13 | 0.36 | +434 | +33.4 |
| SHOOTERS TO THE PRIMARY | 132 | 94 | 12 | 0.33 | +219 | +18.2 |
| WEARS DOWN | 88 | 84 | 12 | 0.33 | +538 | +44.9 |
| BIG CHARACTER SAFETY | 10 | 10 | 10 | 0.28 | -9 | -0.9 |
| PURSUES BIG PREY | 10 | 10 | 10 | 0.28 | -1018 | -101.8 |
| STUCK PIVOT | 10 | 10 | 10 | 0.28 | +0 | +0.0 |
| SUPPORT NARROWED | 436 | 436 | 10 | 0.28 | -76 | -7.6 |
| MODEL FACING | 9 | 9 | 9 | 0.25 | +3606 | +400.7 |
| PIVOT GUARDS FLANK | 9 | 9 | 9 | 0.25 | -207 | -23.0 |
| BACKUP TARGETS | 59 | 31 | 8 | 0.22 | +90 | +11.2 |
| HUNT IN PAIRS | 20 | 15 | 8 | 0.22 | +286 | +35.8 |
| OPENS UP | 17 | 17 | 8 | 0.22 | +462 | +57.8 |
| SHORT GUN FORWARD | 8 | 8 | 8 | 0.22 | +0 | +0.0 |
| BLOCKED CHARGE SKIPPED | 7 | 7 | 7 | 0.19 | +0 | +0.0 |
| MISSILES IN THE FIRE PLAN | 81 | 14 | 7 | 0.19 | +126 | +18.1 |
| MISSILES NEXT TURN | 325 | 191 | 7 | 0.19 | +36 | +5.2 |
| MOVES UNITS SPELL | 7 | 7 | 7 | 0.19 | +186 | +26.5 |
| OVERRUNS AWAY | 36 | 36 | 7 | 0.19 | +159 | +22.8 |
| RESTRAINS TO SHOOT | 7 | 7 | 7 | 0.19 | +312 | +44.6 |
| LOST CHARGE | 209 | 209 | 6 | 0.17 | +134 | +22.2 |
| NEEDED THERE | 7 | 7 | 5 | 0.14 | +0 | +0.0 |
| RAIDS THE BAGGAGE NEXT TURN | 5 | 5 | 5 | 0.14 | +277 | +55.5 |
| STANDS TO CAST | 5 | 5 | 5 | 0.14 | +15 | +3.1 |
| SURE CHARGE BEATS ADVANCE | 5 | 5 | 5 | 0.14 | -374 | -74.7 |
| BEST PRIZE | 4 | 4 | 4 | 0.11 | -268 | -67.0 |
| HUNT ADVANCE | 12 | 12 | 4 | 0.11 | +159 | +39.8 |
| PERIAPT WORTH | 4 | 4 | 4 | 0.11 | +358 | +89.5 |
| SURE REACH TOGETHER | 50 | 31 | 4 | 0.11 | +6 | +1.6 |
| CHAFF PASSED | 3 | 3 | 3 | 0.08 | -4 | -1.3 |
| KEEP FALLS | 3 | 3 | 3 | 0.08 | +48 | +15.8 |
| REDIRECT BY WHAT IT STOPS | 21 | 21 | 3 | 0.08 | +93 | +30.9 |
| SHOOTERS ARE THREATS | 96 | 96 | 3 | 0.08 | +0 | +0.0 |
| WHOLE FIGHT | 26 | 26 | 3 | 0.08 | +137 | +45.5 |
| CATCH ODDS | 2 | 2 | 2 | 0.06 | -39 | -19.7 |
| DEFENSIVE ARMY | 17 | 17 | 2 | 0.06 | -27 | -13.5 |
| EDGE GIVE GROUND | 10 | 10 | 2 | 0.06 | +373 | +186.4 |
| FACE THE CAST | 2 | 2 | 2 | 0.06 | +6 | +2.8 |
| FOCUS FIRE | 2 | 2 | 2 | 0.06 | +163 | +81.6 |
| JOINT CHARGE PLAN | 5 | 5 | 2 | 0.06 | +260 | +130.2 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| LONG SHOT | 27 | 27 | 2 | 0.06 | +4 | +1.8 |
| MOVE SPELL IN RANGE | 7 | 3 | 2 | 0.06 | +6 | +3.2 |
| THREAT AT FULL SIZE | 232 | 232 | 2 | 0.06 | +0 | +0.0 |
| BOMBING RUN | 1 | 1 | 1 | 0.03 | +31 | +30.9 |
| CARRIES OUT SET-UP | 7 | 7 | 1 | 0.03 | -178 | -177.9 |
| DEFENSIVE FLOOR | 5 | 5 | 1 | 0.03 | +2 | +2.1 |
| ELIXIR WORTH | 1 | 1 | 1 | 0.03 | +47 | +46.9 |
| FIRE AND FLEE | 1 | 1 | 1 | 0.03 | +3 | +2.9 |
| RAIDS THE BAGGAGE | 1 | 1 | 1 | 0.03 | +148 | +147.8 |
| STAY WEIGHED | 1 | 1 | 1 | 0.03 | +37 | +37.0 |
| TWO OR MORE ARRIVE | 25 | 19 | 1 | 0.03 | +22 | +22.2 |
| WAR ENGINE CHARGES | 6 | 6 | 1 | 0.03 | +139 | +138.6 |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 23 | 23 | 0 | 0.00 | - | - |
| CARRIES OUT COUNTER | 2 | 2 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 36 | trace | - | - | - | - |
| CATCH FLIERS | 3 | not checked | - | - | - | - |
| CHARIOT WIZARD CAREFUL | 6 | 6 | 0 | 0.00 | - | - |
| CHEAP HELPER | 8 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 37 | not checked | - | - | - | - |
| ENGINEER BY LORE | 2 | 2 | 0 | 0.00 | - | - |
| FIGHT LIFT | 1 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 366 | not checked | - | - | - | - |
| GIVES UP | 8 | 7 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 2 | 2 | 0 | 0.00 | - | - |
| HELPER ALREADY ASKED | 3 | not checked | - | - | - | - |
| HELPER UNSEEN | 18 | 18 | 0 | 0.00 | - | - |
| HILL BY ITS CHANCE | 5 | 5 | 0 | 0.00 | - | - |
| HUNT DROPPED | 7 | trace | - | - | - | - |
| HUNT KEPT | 2 | trace | - | - | - | - |
| HUNT RESULT | 14 | trace | - | - | - | - |
| HUNT THE GUNS | 15 | trace | - | - | - | - |
| KEEPS ITS PREY | 3 | 3 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 34 | not checked | - | - | - | - |
| LONE WIZARD HOLDS BACK | 17 | 17 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 3 | 3 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 2 | trace | - | - | - | - |
| MARCH OVER CASTS | 22 | 22 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 8 | 8 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 15 | trace | - | - | - | - |
| MOVE SPELL SPOT | 15 | not checked | - | - | - | - |
| NOT NEEDED | 18 | 17 | 0 | 0.00 | - | - |
| NOT TURNED | 359 | 359 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 30 | not checked | - | - | - | - |
| OPENS A LANE | 11 | 7 | 0 | 0.00 | - | - |
| PLAN RESULT | 2704 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 17 | 17 | 0 | 0.00 | - | - |
| SCOUT SPOT | 23 | 23 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 7 | 7 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 15 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 20 | not checked | - | - | - | - |
| SET-UP MISSED | 3 | trace | - | - | - | - |
| SHOOTER COUNTED ONCE | 2 | 2 | 0 | 0.00 | - | - |
| SHOT OPTIONS | 946 | 946 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 28 | not checked | - | - | - | - |
| SPELL WORTH | 113 | not checked | - | - | - | - |
| STABLE ROLE | 786 | 781 | 0 | 0.00 | - | - |
| STOPS | 4 | 4 | 0 | 0.00 | - | - |
| TURN WORTH | 36 | 35 | 0 | 0.00 | - | - |
| WOUNDED STAYS OUT | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: sp-h2h-opp-89601ea-p1

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 14.69 | 13.00 | 52.7 |
| FALLBACK | gate | 0.81 | 0.67 | 40.6 |
| CHARGE NOW FIRST | rule | 0.67 | 0.69 | 90.7 |
| TURN GATE | gate | 0.36 | 0.50 | 20.6 |
| LONE CHARACTER SAFE SPOT | gate | 0.14 | 0.31 | 31.2 |
| KEEPS THE TARGET | rule | - | 0.39 | 100.3 |
| WAR ENGINE JOBS | rule | 0.25 | 0.14 | 85.7 |
| SUPPORT REQUEST | gate | 0.25 | 0.11 | 112.9 |
| PATHS CROSS | rule | 0.31 | 0.03 | 32.7 |
| PURSUES BIG PREY | rule | 0.11 | 0.17 | 101.8 |
| PIVOT GUARDS FLANK | rule | 0.17 | 0.08 | 23.0 |
| SUPPORT NARROWED | rule | 0.08 | 0.17 | 8.4 |
| FIRE PLAN | rule | - | 0.19 | 32.7 |
| CHARGE NOW WEIGHED | rule | 0.06 | 0.11 | 47.6 |
| AFTERMATH BAND | gate | 0.08 | 0.06 | 3.1 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.14 | - | 46.4 |
| BIG CHARACTER SAFETY | rule | 0.08 | 0.06 | 8.6 |
| FIGHT ORDER BAND | gate | 0.11 | 0.03 | 1.5 |
| SURE CHARGE BEATS ADVANCE | rule | 0.06 | 0.08 | 74.7 |
| THROUGH LINE OF FIRE | rule | 0.11 | 0.03 | 16.6 |
| BEST PRIZE | rule | 0.06 | 0.06 | 67.0 |
| BLOCKED WHEEL | rule | 0.06 | 0.06 | 15.6 |
| CANNON PLANNED TARGET | rule | 0.08 | - | 76.2 |
| MARCH ODDS | rule | 0.03 | 0.06 | 15.9 |
| SAFER THAN THE JOB | rule | 0.03 | 0.06 | 10.3 |
| CATCH ODDS | rule | - | 0.06 | 19.7 |
| DEFENSIVE ARMY | rule | 0.06 | - | 13.5 |
| NO REASON | gate | - | 0.06 | 8.5 |
| REDIRECT WEIGHED | rule | 0.03 | 0.03 | 111.4 |
| CARRIES OUT SET-UP | rule | - | 0.03 | 177.9 |
| CHAFF PASSED | rule | 0.03 | - | 3.8 |
| FACES THE THREAT | rule | 0.03 | - | 6.7 |
| FOLLOW UP WEIGHED | rule | 0.03 | - | 4.8 |
| FRIENDS SHOTS CHECKED | rule | - | 0.03 | 1.0 |
| STANDS TO CAST | rule | 0.03 | - | 10.0 |
| STOPS SHORT OF THE FLANK | rule | 0.03 | - | 5.6 |

### Plans: sp-h2h-opp-89601ea-p1

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 11.4 | 17% | 555 | 311 | 56% |
| Mine | charge | 3.6 | 52% | 409 | 304 | 74% |
| Mine | close in | 3.8 | 27% | 317 | 161 | 51% |
| Mine | hold | 5.1 | 46% | 322 | 0 | 0% |
| Mine | join | 0.7 | 100% | 22 | 0 | 0% |
| Mine | shoot | 9.3 | 56% | 338 | 708 | 209% |
| Mine | support | 3.5 | 84% | 30 | 0 | 0% |
| Opponent | advance | 12.6 | 15% | 403 | 360 | 89% |
| Opponent | charge | 4.6 | 61% | 503 | 416 | 83% |
| Opponent | close in | 5.4 | 26% | 454 | 152 | 34% |
| Opponent | hold | 4.3 | 45% | 314 | 0 | 0% |
| Opponent | join | 1.2 | 93% | 50 | 0 | 0% |
| Opponent | shoot | 4.8 | 60% | 253 | 237 | 93% |
| Opponent | support | 4.7 | 86% | 38 | 0 | 0% |

### Packages: hunt the guns, sp-h2h-opp-89601ea-p1

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.1 | 2 | 1 | 0% | 0% | 0% | - | 206 | 0 | 0% | 12 |
| Opponent | 0.4 | 13 | 0 | 8% | 15% | 8% | 2.0 | 389 | 41 | 15% | 94 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.2 | 1 | 1 | - | - | - | - | - | - | - | 0 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 22 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 55 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 76 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 128 |
| High Elf Realms | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 206 | 0 | 0% | 83 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 158 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Orc & Goblin Tribes | 0.7 | 2 | 0 | 50% | 50% | 0% | 2.0 | 135 | 70 | 50% | 0 |
| Skaven | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 463 | 0 | 0% | 32 |
| Tomb Kings of Khemri | 0.2 | 1 | 0 | 0% | 100% | 0% | 2.0 | 342 | 298 | 100% | 32 |
| Vampire Counts | 0.2 | 2 | 0 | 0% | 0% | 50% | - | 399 | 47 | 0% | 27 |
| Warriors of Chaos | 0.8 | 6 | 0 | 0% | 0% | 0% | - | 476 | 0 | 0% | 24 |
| Wood Elf Realms | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 329 | 0 | 0% | 141 |

### Battle groups: sp-h2h-opp-89601ea-p1

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 9.3 | 21% | 50% | 7% | 20% | 51% | 7% | 6% | 36% | 0% |
| Mine | REDIRECT COUNTER | 2.4 | 31% | 63% | 11% | 0% | 21% | 4% | 4% | 67% | 4% |
| Opponent | COUNTER-CHARGE COVER | 6.9 | 17% | 63% | 19% | 25% | 51% | 17% | 3% | 29% | 0% |
| Opponent | REDIRECT COUNTER | 3.9 | 21% | 72% | 34% | 20% | 47% | 0% | 11% | 42% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: sp-h2h-opp-89601ea-p1

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 3 | 14 (3) | 14 | 0 | 81 | 33% | 3.5 | 0 (1) | 17 (2) | - | 37 (1) | 0 (2) |
| Mine | Chaff | 36 | 13 (36) | 7 | 7 | 65 | 47% | 2.2 | 11 (15) | 5 (10) | 22 (11) | 5 (22) | 24 (14) |
| Mine | Character | 123 | 53 (123) | 52 | 1 | 30 | 13% | 2.5 | 71 (38) | 50 (59) | 42 (10) | 57 (63) | 57 (44) |
| Mine | Clean-up | 26 | 83 (26) | 34 | 49 | 26 | 27% | 3.3 | 94 (10) | 85 (12) | 16 (4) | 106 (13) | 64 (13) |
| Mine | Fast | 4 | 18 (4) | 18 | 0 | 47 | 25% | 1.3 | 33 (1) | 0 (2) | 0 (1) | 18 (4) | - |
| Mine | Fast Hammer | 40 | 38 (40) | 27 | 12 | 56 | 28% | 2.6 | 51 (18) | 38 (11) | 16 (11) | 43 (29) | 28 (11) |
| Mine | Fragile | 5 | 0 (5) | 0 | 0 | 80 | 0% | 1.6 | - | 0 (4) | 0 (1) | 0 (1) | 0 (4) |
| Mine | Hammer | 56 | 54 (56) | 39 | 15 | 35 | 16% | 2.3 | 35 (11) | 64 (37) | 31 (8) | 57 (34) | 51 (22) |
| Mine | Holder | 26 | 88 (26) | 8 | 80 | 15 | 46% | 2.9 | 92 (8) | 78 (10) | 102 (8) | 93 (14) | 84 (12) |
| Mine | Shooter | 45 | 121 (45) | 51 | 69 | 34 | 2% | 1.9 | 42 (5) | 136 (33) | 125 (7) | 141 (23) | 101 (22) |
| Mine | Support | 5 | 24 (5) | 24 | 0 | 42 | 20% | 2.8 | 0 (1) | 28 (4) | - | 24 (5) | - |
| Mine | War machine | 56 | 51 (56) | 51 | 0 | 41 | 2% | 1.4 | 94 (14) | 37 (37) | 39 (5) | 91 (11) | 41 (45) |
| Mine | Wizard | 23 | 34 (23) | 34 | 0 | 40 | 17% | 2.1 | 63 (5) | 44 (10) | 0 (2) | 173 (3) | 5 (14) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Chaff | 68 | 71 (68) | 16 | 54 | 48 | 34% | 2.7 | 94 (30) | 24 (16) | 78 (22) | 92 (50) | 6 (18) |
| Opponent | Character | 113 | 55 (113) | 55 | 0 | 40 | 24% | 2.4 | 67 (34) | 59 (60) | 0 (8) | 59 (69) | 56 (33) |
| Opponent | Clean-up | 18 | 30 (18) | 19 | 11 | 63 | 39% | 3.1 | 14 (5) | 29 (10) | 56 (3) | 42 (11) | 10 (7) |
| Opponent | Early | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Fast Hammer | 53 | 41 (53) | 23 | 18 | 50 | 28% | 2.5 | 34 (20) | 54 (18) | 38 (15) | 42 (37) | 39 (16) |
| Opponent | Fragile | 10 | 69 (10) | 69 | 0 | 63 | 40% | 2.5 | 259 (3) | 0 (3) | 0 (4) | 75 (9) | 0 (1) |
| Opponent | Hammer | 63 | 18 (63) | 6 | 12 | 53 | 22% | 2.8 | 4 (16) | 24 (40) | 8 (7) | 14 (39) | 26 (24) |
| Opponent | Holder | 40 | 69 (40) | 15 | 54 | 25 | 38% | 3.6 | 67 (6) | 91 (21) | 35 (12) | 102 (24) | 21 (15) |
| Opponent | Shooter | 32 | 67 (32) | 21 | 47 | 42 | 3% | 1.3 | 78 (8) | 74 (18) | 31 (6) | 59 (17) | 79 (15) |
| Opponent | Support | 2 | 0 (2) | 0 | 0 | 0 | 100% | - | 0 (2) | - | - | - | 0 (2) |
| Opponent | War machine | 13 | 30 (13) | 30 | 0 | 24 | 23% | 1.1 | 29 (5) | 20 (5) | 54 (3) | 32 (3) | 30 (10) |
| Opponent | Wizard | 24 | 4 (24) | 4 | 0 | 43 | 8% | 2.2 | 4 (10) | 14 (5) | 0 (4) | 5 (11) | 6 (8) |

### Charged fights: sp-h2h-opp-89601ea-p1

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 5 | 255 | 65 | 1.2 | 1.3 | 54 | 23 | +32 | 1 of 6 | 5 of 6 | -68 | +82 |
| Mine | Chaos Dwarfs | 3 | 75 | 704 | 5.0 | 1.1 | 141 | 12 | +129 | 8 of 15 | 13 of 15 | +128 | +129 |
| Mine | Dwarfen Mountain Holds | 4 | 587 | 25 | 1.5 | 1.2 | 17 | 18 | -1 | 3 of 6 | 4 of 6 | -105 | +20 |
| Mine | Empire of Man | 5 | 318 | 111 | 1.0 | 1.2 | 111 | 132 | -21 | 0 of 5 | 5 of 5 | +83 | -47 |
| Mine | Grand Cathay | 4 | 705 | 387 | 3.2 | 1.3 | 119 | 63 | +56 | 7 of 13 | 11 of 13 | -31 | +95 |
| Mine | High Elf Realms | 4 | 308 | 545 | 3.0 | 1.5 | 182 | 45 | +136 | 5 of 12 | 10 of 12 | +268 | +4 |
| Mine | Kingdom of Bretonnia | 1 | 218 | 153 | 4.0 | 1.0 | 38 | 153 | -115 | 3 of 4 | 2 of 4 | - | -115 |
| Mine | Lizardmen | 1 | 0 | 385 | 3.0 | 1.0 | 128 | 47 | +81 | 1 of 3 | 3 of 3 | - | +81 |
| Mine | Ogre Kingdoms | 1 | 136 | 66 | 2.0 | 2.0 | 33 | 84 | -50 | 1 of 2 | 1 of 2 | -11 | -90 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 580 | 5.0 | 1.2 | 116 | 22 | +94 | 1 of 5 | 4 of 5 | +195 | +69 |
| Mine | Skaven | 2 | 127 | 444 | 3.0 | 1.3 | 148 | 0 | +148 | 4 of 6 | 6 of 6 | +0 | +222 |
| Mine | Tomb Kings of Khemri | 2 | 120 | 848 | 4.0 | 1.4 | 212 | 15 | +197 | 2 of 8 | 8 of 8 | +487 | +23 |
| Mine | Vampire Counts | 2 | 0 | 85 | 6.5 | 1.1 | 13 | 62 | -49 | 5 of 13 | 6 of 13 | +170 | -68 |
| Mine | Warriors of Chaos | 1 | 91 | 0 | 3.0 | 1.0 | 0 | 0 | +0 | 1 of 3 | 3 of 3 | - | +0 |
| **Mine** | all armies | 36 | 290 | 299 | 2.8 | 1.2 | 107 | 44 | +63 | 42 of 101 | 81 of 101 | +142 | +38 |
| Opponent | Beastmen Brayherds | 1 | 0 | 130 | 2.0 | 1.5 | 65 | 111 | -46 | 2 of 2 | 1 of 2 | -137 | +45 |
| Opponent | Dwarfen Mountain Holds | 1 | 65 | 0 | 1.0 | 1.0 | 0 | 388 | -388 | 1 of 1 | 1 of 1 | - | -388 |
| Opponent | Empire of Man | 1 | 160 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Grand Cathay | 1 | 240 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | High Elf Realms | 2 | 52 | 690 | 4.0 | 1.4 | 172 | 19 | +154 | 3 of 8 | 3 of 8 | +117 | +175 |
| Opponent | Lizardmen | 1 | 0 | 110 | 1.0 | 1.0 | 110 | 0 | +110 | 0 of 1 | 1 of 1 | - | +110 |
| Opponent | Ogre Kingdoms | 2 | 80 | 15 | 2.5 | 1.0 | 6 | 14 | -8 | 0 of 5 | 2 of 5 | - | -8 |
| Opponent | Orc & Goblin Tribes | 2 | 0 | 423 | 5.5 | 1.3 | 77 | 135 | -58 | 4 of 11 | 7 of 11 | -91 | -46 |
| Opponent | Skaven | 2 | 81 | 0 | 1.5 | 1.0 | 0 | 281 | -281 | 3 of 3 | 0 of 3 | - | -281 |
| Opponent | Tomb Kings of Khemri | 4 | 84 | 1180 | 4.8 | 1.2 | 249 | 21 | +227 | 11 of 19 | 17 of 19 | +77 | +245 |
| Opponent | Vampire Counts | 6 | 79 | 425 | 4.7 | 1.2 | 91 | 25 | +66 | 11 of 28 | 17 of 28 | +35 | +71 |
| Opponent | Warriors of Chaos | 7 | 7 | 327 | 2.7 | 1.1 | 120 | 12 | +108 | 6 of 19 | 12 of 19 | +76 | +112 |
| Opponent | Wood Elf Realms | 6 | 103 | 381 | 3.3 | 1.1 | 114 | 69 | +46 | 8 of 20 | 9 of 20 | +56 | +44 |
| **Opponent** | all armies | 36 | 66 | 398 | 3.2 | 1.2 | 123 | 50 | +72 | 49 of 117 | 70 of 117 | +31 | +80 |

### Effective charges: sp-h2h-opp-89601ea-p1

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 6 | 0 | 1 (net -137) | 0 | 0 | 1 (net +0) | 2 (net +137) | 2 | 0% (0 of 4) |
| Mine | Chaos Dwarfs | 15 | 2 (net +26) | 0 | 2 (net +105) | 2 (net +69) | 1 (net +45) | 7 (net +213) | 1 | 14% (2 of 14) |
| Mine | Dwarfen Mountain Holds | 6 | 1 (net -105) | 1 (net +0) | 0 | 1 (net +0) | 0 | 3 (net +34) | 0 | 0% (0 of 6) |
| Mine | Empire of Man | 5 | 1 (net -380) | 0 | 1 (net +190) | 1 (net +109) | 1 (net +83) | 1 (net -106) | 0 | 20% (1 of 5) |
| Mine | Grand Cathay | 13 | 1 (net -233) | 0 | 2 (net +342) | 4 (net +162) | 2 (net +46) | 4 (net -116) | 0 | 15% (2 of 13) |
| Mine | High Elf Realms | 12 | 1 (net +0) | 0 | 4 (net +129) | 2 (net +332) | 1 (net +432) | 2 (net +0) | 2 | 40% (4 of 10) |
| Mine | Kingdom of Bretonnia | 4 | 1 (net -277) | 0 | 1 (net -336) | 1 (net +0) | 1 (net +153) | 0 | 0 | 25% (1 of 4) |
| Mine | Lizardmen | 3 | 0 | 0 | 0 | 0 | 1 (net +60) | 1 (net +325) | 1 | 0% (0 of 2) |
| Mine | Ogre Kingdoms | 2 | 0 | 0 | 0 | 0 | 1 (net -11) | 0 | 1 | 0% (0 of 1) |
| Mine | Orc & Goblin Tribes | 5 | 0 | 0 | 1 (net +195) | 0 | 1 (net +0) | 1 (net +325) | 2 | 33% (1 of 3) |
| Mine | Skaven | 6 | 0 | 0 | 1 (net +0) | 1 (net +0) | 0 | 4 (net +222) | 0 | 17% (1 of 6) |
| Mine | Tomb Kings of Khemri | 8 | 0 | 0 | 1 (net +1108) | 1 (net +116) | 0 | 6 (net +58) | 0 | 12% (1 of 8) |
| Mine | Vampire Counts | 13 | 8 (net -78) | 0 | 1 (net +170) | 2 (net +0) | 0 | 2 (net -93) | 0 | 8% (1 of 13) |
| Mine | Warriors of Chaos | 3 | 0 | 0 | 0 | 2 (net +0) | 1 (net +0) | 0 | 0 | 0% (0 of 3) |
| Opponent | Beastmen Brayherds | 2 | 1 (net -137) | 0 | 0 | 0 | 0 | 1 (net +45) | 0 | 0% (0 of 2) |
| Opponent | Dwarfen Mountain Holds | 1 | 0 | 0 | 0 | 1 (net -388) | 0 | 0 | 0 | 0% (0 of 1) |
| Opponent | High Elf Realms | 8 | 2 (net +148) | 0 | 1 (net +0) | 4 (net +210) | 1 (net +95) | 0 | 0 | 12% (1 of 8) |
| Opponent | Lizardmen | 1 | 0 | 0 | 0 | 0 | 1 (net +110) | 0 | 0 | 0% (0 of 1) |
| Opponent | Ogre Kingdoms | 5 | 1 (net -34) | 0 | 1 (net +0) | 0 | 0 | 2 (net +15) | 1 | 25% (1 of 4) |
| Opponent | Orc & Goblin Tribes | 11 | 3 (net -98) | 0 | 0 | 1 (net +230) | 0 | 2 (net +81) | 5 | 0% (0 of 6) |
| Opponent | Skaven | 3 | 0 | 1 (net -732) | 0 | 1 (net -112) | 0 | 1 (net +0) | 0 | 0% (0 of 3) |
| Opponent | Tomb Kings of Khemri | 19 | 2 (net +200) | 1 (net +0) | 4 (net +279) | 2 (net +0) | 2 (net +77) | 8 (net +332) | 0 | 21% (4 of 19) |
| Opponent | Vampire Counts | 28 | 5 (net -63) | 0 | 7 (net +73) | 5 (net +38) | 1 (net +133) | 9 (net +146) | 1 | 26% (7 of 27) |
| Opponent | Warriors of Chaos | 19 | 3 (net +141) | 1 (net -116) | 2 (net +75) | 5 (net +195) | 1 (net +104) | 5 (net +49) | 2 | 12% (2 of 17) |
| Opponent | Wood Elf Realms | 20 | 3 (net +0) | 2 (net -51) | 3 (net -257) | 5 (net +294) | 1 (net +65) | 3 (net +34) | 3 | 18% (3 of 17) |

### Charged fights, damage counted: sp-h2h-opp-89601ea-p1

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 15 | 253 | 265 | -104 | 49 | 112 | -64 | -25.2 |
| Mine | 50-54% | 2 | 121 | 170 | -68 | 92 | 82 | +11 | +8.9 |
| Mine | Effective (55-75%) | 14 | 404 | 262 | +196 | 263 | 94 | +168 | +41.7 |
| Mine | 76-89% | 17 | 307 | 285 | +98 | 110 | 47 | +62 | +20.3 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 33 | 263 | 206 | +91 | 152 | 47 | +105 | +39.7 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 11 | 338 | 75 | +78 | 93 | 18 | +76 | +22.4 |
| Mine | No odds | 9 | 293 | 112 | -22 | 54 | 57 | -2 | -0.8 |
| Mine | All fights | 101 | 296 | 213 | +63 | 129 | 62 | +67 | +22.5 |
| Opponent | Long shot (under 50%) | 20 | 243 | 256 | +17 | 129 | 119 | +9 | +3.8 |
| Opponent | 50-54% | 5 | 231 | 307 | -190 | 21 | 250 | -229 | -98.9 |
| Opponent | Effective (55-75%) | 18 | 212 | 190 | +56 | 115 | 84 | +31 | +14.8 |
| Opponent | 76-89% | 24 | 254 | 229 | +134 | 174 | 52 | +122 | +48.2 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 31 | 243 | 199 | +147 | 187 | 16 | +171 | +70.3 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 7 | 455 | 102 | +94 | 104 | 17 | +88 | +19.3 |
| Opponent | No odds | 12 | 125 | 177 | -29 | 61 | 100 | -39 | -31.1 |
| Opponent | All fights | 117 | 240 | 210 | +72 | 138 | 70 | +68 | +28.4 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| sp-h2h-opp-89601ea-p1 | move | 469 | 110 (23%) | 77 (16%) | 46 (10%) | 313 (67%) |
| sp-h2h-opp-89601ea-p1 | objective | 333 | 47 (14%) | 34 (10%) | 51 (15%) | 235 (71%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0102, L0118, L0135, L2531, L2730 |
| Charmed Shield | Opponent | L0524, L1224, L1527, L1625, L2025, L2127, L2934 |
| Clockwork Compass | Mine | L1224 |
| Clockwork Compass | Opponent | L0612 |
| Elixir of Power | Mine | L1114, L1131, L1923 |
| Elixir of Power | Opponent | L0319, L1319 |
| Fistful of Laurels | Mine | L1823 |
| Fistful of Laurels | Opponent | L0118, L0218 |
| Horn of the Wild Hunt | Opponent | L0733 |
| Invocation of Nehek | Mine | L2531, L2730 |
| Invocation of Nehek | Opponent | L0524, L1224, L1527, L1625, L2025, L2127 |
| Opal Amulet | Mine | L1431 |
| Opal Amulet | Opponent | L1114 |
| Periapt of Soul Exchange | Mine | L2025, L2127 |
| Periapt of Soul Exchange | Opponent | L0421, L1021 |
| Ring of Doom | Mine | L0218, L0235, L1114, L1131, L1224, L1527 |
| Ring of Doom | Opponent | L0102, L0612, L0733, L1131, L1431, L2231, L2531 |
| Ring of Jet | Mine | L1021, L1114, L1131, L1224 |
| Ring of Jet | Opponent | L0612 |
| Standard of the Fell Warrior | Mine | L1319, L1335 |
| Standard of the Fell Warrior | Opponent | L0913 |
| Storm Daemon (Renegade 2.0) | Mine | L2127 |
| Storm Daemon (Renegade 2.0) | Opponent | L0421, L1021 |
| Twice-Blessed Armour | Mine | L0717, L0733, L1021 |
| Witch Hunter's Ward | Mine | L0717, L0733, L0823 |
| Witch Hunter's Ward | Opponent | L0508 |

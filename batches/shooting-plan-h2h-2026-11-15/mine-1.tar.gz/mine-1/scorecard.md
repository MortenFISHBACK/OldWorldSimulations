# Doctrine scorecard: sp-h2h-mine-89601ea-p1

### Scorecard: sp-h2h-mine-89601ea-p1

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0102 | 6 | 1 | Mine | no | 10 | - | 0 | 0 | 0 | 0 | 0 | 65 |
| L0102 | 6 | 1 | Opponent | no | 2 | 1 | 5 | 3 | 1 | 0 | 0 | 222 |
| L0118 | 4 | 1 | Mine | no | 1 | - | 0 | 1 | 1 | 0 | 0 | 0 |
| L0118 | 4 | 1 | Opponent | no | 0 | 4 | 5 | 3 | 0 | 0 | 0 | 68 |
| L0135 | 3 | 1 | Mine | yes | 0 | - | 0 | 1 | 0 | 0 | 0 | 65 |
| L0135 | 3 | 1 | Opponent | no | 0 | 2 | 4 | 2 | 0 | 0 | 0 | 0 |
| L0218 | 2 | 1 | Mine | - | - | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L0218 | 2 | 1 | Opponent | - | - | 3 | 0 | 1 | 0 | 0 | 0 | 0 |
| L0235 | 1 | 1 | Mine | no | 1 | 2 | 1 | 3 | 0 | 0 | 0 | 0 |
| L0235 | 1 | 1 | Opponent | no | 0 | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| L0319 | 1 | 1 | Mine | no | 2 | 2 | 3 | 0 | 0 | 0 | 0 | 675 |
| L0319 | 1 | 1 | Opponent | no | 2 | 2 | 5 | 1 | 1 | 0 | 0 | 235 |
| L0405 | 3 | 1 | Mine | yes | 6 | 2 | 6 | 2 | 0 | 0 | 0 | 0 |
| L0405 | 3 | 1 | Opponent | no | 4 | - | 1 | 0 | 0 | 0 | 0 | 1120 |
| L0421 | 1 | 1 | Mine | no | 0 | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L0421 | 1 | 1 | Opponent | no | 1 | - | 1 | 5 | 1 | 0 | 0 | 355 |
| L0508 | 4 | 1 | Mine | no | 0 | 6 | 1 | 1 | 0 | 0 | 0 | 548 |
| L0508 | 4 | 1 | Opponent | no | 9 | 3 | 1 | 4 | 0 | 0 | 0 | 605 |
| L0524 | 2 | 1 | Mine | - | - | - | 0 | 1 | 0 | 0 | 0 | 1087 |
| L0524 | 2 | 1 | Opponent | - | - | 2 | 2 | 4 | 0 | 0 | 0 | 0 |
| L0612 | 6 | 1 | Mine | no | 0 | - | 2 | 1 | 0 | 0 | 0 | 615 |
| L0612 | 6 | 1 | Opponent | no | 3 | 2 | 2 | 0 | 0 | 0 | 0 | 330 |
| L0628 | 4 | 1 | Mine | no | 0 | 5 | 1 | 0 | 0 | 0 | 0 | 1011 |
| L0628 | 4 | 1 | Opponent | no | 5 | 3 | 1 | 1 | 0 | 0 | 0 | 0 |
| L0717 | 3 | 1 | Mine | yes | 0 | 2 | 3 | 1 | 0 | 0 | 0 | 420 |
| L0717 | 3 | 1 | Opponent | yes | 3 | 5 | 2 | 0 | 1 | 0 | 0 | 0 |
| L0733 | 1 | 1 | Mine | no | 5 | 3 | 1 | 1 | 0 | 0 | 0 | 375 |
| L0733 | 1 | 1 | Opponent | no | 2 | 3 | 3 | 3 | 0 | 0 | 0 | 0 |
| L0823 | 1 | 1 | Mine | no | 0 | - | 0 | 0 | 1 | 0 | 0 | 679 |
| L0823 | 1 | 1 | Opponent | no | 0 | 2 | 3 | 3 | 2 | 0 | 0 | 70 |
| L0913 | 1 | 1 | Mine | no | 1 | - | 0 | 0 | 0 | 0 | 0 | 970 |
| L0913 | 1 | 1 | Opponent | no | 12 | 2 | 2 | 0 | 1 | 0 | 0 | 140 |
| L0930 | 6 | 1 | Mine | no | 0 | 4 | 3 | 1 | 0 | 0 | 0 | 793 |
| L0930 | 6 | 1 | Opponent | no | 1 | 2 | 3 | 2 | 1 | 0 | 0 | 0 |
| L1021 | 1 | 1 | Mine | no | 0 | 2 | 4 | 0 | 1 | 0 | 0 | 330 |
| L1021 | 1 | 1 | Opponent | no | 0 | 3 | 3 | 6 | 1 | 0 | 0 | 355 |
| L1114 | 4 | 1 | Mine | no | 0 | 2 | 4 | 0 | 0 | 0 | 0 | 330 |
| L1114 | 4 | 1 | Opponent | no | 0 | 2 | 3 | 1 | 0 | 0 | 0 | 500 |
| L1131 | 3 | 1 | Mine | no | 6 | 5 | 2 | 0 | 0 | 0 | 0 | 330 |
| L1131 | 3 | 1 | Opponent | no | 3 | - | 1 | 1 | 1 | 0 | 0 | 597 |
| L1224 | 6 | 1 | Mine | no | 9 | 2 | 6 | 0 | 0 | 0 | 0 | 330 |
| L1224 | 6 | 1 | Opponent | no | 1 | 2 | 1 | 1 | 2 | 0 | 0 | 0 |
| L1319 | 5 | 1 | Mine | yes | - | 2 | 1 | 2 | 0 | 0 | 0 | 302 |
| L1319 | 5 | 1 | Opponent | no | - | 2 | 3 | 2 | 0 | 0 | 0 | 317 |
| L1335 | 3 | 1 | Mine | yes | 1 | 5 | 1 | 0 | 0 | 0 | 0 | 317 |
| L1335 | 3 | 1 | Opponent | no | 0 | 3 | 5 | 4 | 0 | 0 | 0 | 126 |
| L1431 | 3 | 1 | Mine | no | 3 | 2 | 5 | 0 | 0 | 0 | 0 | 123 |
| L1431 | 3 | 1 | Opponent | no | 2 | - | 4 | 1 | 1 | 0 | 0 | 340 |
| L1527 | 3 | 1 | Mine | no | 1 | 4 | 4 | 0 | 0 | 0 | 0 | 0 |
| L1527 | 3 | 1 | Opponent | no | 1 | 2 | 2 | 2 | 1 | 0 | 0 | 0 |
| L1625 | 5 | 1 | Mine | yes | - | 3 | 4 | 1 | 0 | 0 | 0 | 200 |
| L1625 | 5 | 1 | Opponent | yes | - | 1 | 2 | 4 | 0 | 0 | 0 | 0 |
| L1723 | 1 | 1 | Mine | no | 1 | 1 | 3 | 0 | 0 | 0 | 0 | 207 |
| L1723 | 1 | 1 | Opponent | yes | 11 | 2 | 7 | 0 | 0 | 0 | 0 | 0 |
| L1823 | 5 | 1 | Mine | no | - | - | 5 | 2 | 0 | 0 | 0 | 0 |
| L1823 | 5 | 1 | Opponent | yes | - | 2 | 1 | 1 | 1 | 0 | 0 | 70 |
| L1923 | 3 | 1 | Mine | no | 0 | 2 | 5 | 0 | 1 | 0 | 0 | 255 |
| L1923 | 3 | 1 | Opponent | no | 3 | 2 | 5 | 1 | 0 | 0 | 0 | 0 |
| L2025 | 3 | 1 | Mine | yes | 2 | 2 | 2 | 1 | 2 | 0 | 0 | 420 |
| L2025 | 3 | 1 | Opponent | no | 11 | 4 | 6 | 1 | 0 | 0 | 0 | 0 |
| L2127 | 3 | 1 | Mine | yes | 3 | - | 3 | 2 | 0 | 0 | 0 | 355 |
| L2127 | 3 | 1 | Opponent | no | 8 | 3 | 7 | 1 | 1 | 0 | 0 | 0 |
| L2231 | 5 | 1 | Mine | yes | - | 2 | 5 | 0 | 0 | 0 | 0 | 0 |
| L2231 | 5 | 1 | Opponent | no | - | 2 | 2 | 1 | 1 | 0 | 0 | 541 |
| L2335 | 1 | 1 | Mine | no | 0 | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L2335 | 1 | 1 | Opponent | no | 5 | 2 | 6 | 2 | 0 | 0 | 0 | 0 |
| L2531 | 5 | 1 | Mine | yes | - | 4 | 1 | 3 | 0 | 0 | 0 | 68 |
| L2531 | 5 | 1 | Opponent | yes | - | 5 | 0 | 2 | 1 | 0 | 0 | 0 |
| L2730 | 6 | 1 | Mine | no | 1 | 1 | 9 | 3 | 0 | 0 | 0 | 60 |
| L2730 | 6 | 1 | Opponent | no | 4 | 4 | 3 | 0 | 0 | 0 | 0 | 0 |
| L2934 | 6 | 1 | Mine | no | 6 | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L2934 | 6 | 1 | Opponent | no | 2 | 1 | 2 | 0 | 0 | 0 | 0 | 56 |
| **Average** | | | Mine | 29% | 2.0 | 2.7 | 2.7 | 0.9 | 0.2 | 0.0 | 0.0 | 303.6 |
| **Average** | | | Opponent | 15% | 3.3 | 2.5 | 2.9 | 1.8 | 0.5 | 0.0 | 0.0 | 168.0 |

### KPIs: sp-h2h-mine-89601ea-p1

Rules off - Opponent only: STAY WORTH, BEST MOVE FOR SHOOTERS, FACE THE CAST, WIZARD FRONT RANK, FIRE PLAN, FIRE IN ORDER, KEEPS THE TARGET, MISSILES IN THE FIRE PLAN, THREAT AT FULL SIZE, SHOOTERS ARE THREATS, SHOOTERS TO THE PRIMARY.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 32% (56 of 176) | 3% (6 of 172) | 18% (62 of 348) |
| Winner chose to follow up after the loser gave ground |  | 94% (73 of 78); on the table 97% | 100% (52 of 52); on the table 100% | 96% (125 of 130); on the table 98% |
| Winner chose to pursue after the loser fell back in good order |  | 88% (14 of 16); on the table 88% | 100% (11 of 11); on the table 100% | 93% (25 of 27); on the table 93% |
| Winner chose to pursue after the loser fled |  | 62% (20 of 32); on the table 69% | 74% (29 of 39); on the table 79% | 69% (49 of 71); on the table 75% |
| Winner chose to follow up or pursue (all three) |  | 85% (107 of 126); on the table 89% | 90% (92 of 102); on the table 92% | 87% (199 of 228); on the table 90% |
| Magic missiles tried each own turn | 50%+ | 36% (120 of 330) | 34% (72 of 210) | 36% (192 of 540) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 51% (120 of 236) | 50% (66 of 133) | 50% (186 of 369) |
|   fighting wizards (on a monster, chariot or monstrous mount) | 50%+ | 33% (49 of 150) | 19% (16 of 84) | 28% (65 of 234) |
|     round 1 |  | 20% (5 of 25) | 14% (2 of 14) | 18% (7 of 39) |
|     rounds 2+ |  | 35% (44 of 125) | 20% (14 of 70) | 30% (58 of 195) |
|   other wizards | 50%+ | 39% (71 of 180) | 42% (50 of 120) | 40% (121 of 300) |
|     round 1 |  | 37% (11 of 30) | 35% (7 of 20) | 36% (18 of 50) |
|     rounds 2+ |  | 40% (60 of 150) | 43% (43 of 100) | 41% (103 of 250) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 65% (20 of 31) | 63% (31 of 49) | 64% (51 of 80) |
| Points that never fought | lower | 38% (27258 of 71484) | 39% (27686 of 71889) | 38% (54944 of 143373) |
|   infantry points that never fought | lower | 46% (7832 of 16863) | 57% (7653 of 13348) | 51% (15485 of 30211) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 54% (152 of 279) | 59% (174 of 295) | 57% (326 of 574) |
| Bound items with a magic missile used (at least once a game) |  | 91% (20 of 22); 1.9 uses a game | 75% (15 of 20); 1.7 uses a game | 83% (35 of 42); 1.8 uses a game |
| Bound items with another spell used |  | 62% (10 of 16); 0.5 uses a game | 25% (2 of 8); 0.1 uses a game | 50% (12 of 24); 0.3 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 63% (12 of 19); 0.3 uses a game | 58% (7 of 12); 0.2 uses a game | 61% (19 of 31); 0.3 uses a game |
|   their share of the points of units over 100 pts | lower | 48% (28680 of 59666) | 54% (33811 of 62699) | 51% (62491 of 122365) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 2.1 (37%) | 1.1 (28%) | 3.2 (33%) |
| MARCHED: its unit marched | 0.8 (14%) | 0.4 (12%) | 1.2 (13%) |
| CHARGED: its unit charged | 0.2 (3%) | 0.2 (4%) | 0.3 (3%) |
| IN COMBAT: engaged in combat | 1.7 (29%) | 0.7 (19%) | 2.4 (25%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.1 (2%) | 0.1 (1%) |
| FLEEING: fleeing | 0.1 (2%) | 0.1 (2%) | 0.2 (2%) |
| GONE: slain | 0.7 (11%) | 1.0 (27%) | 1.7 (18%) |
| OFF THE TABLE: off the table or not arrived | 0.2 (3%) | 0.1 (4%) | 0.3 (3%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.0 (1%) | 0.1 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.1 (2%) | 0.1 (1%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.5 | 1.4 | 1.4 | 5.3 | 0.5 | 2.5 |
| not cast | 3.5 | 3.0 | 3.3 | 9.7 | 1.9 | 21.5 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.8 (8%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.1 (38%) | 0.2 (7%) | 3.2 (33%) | 0.2 (13%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.2 (13%) | 0.2 (13%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (3%) | 0.0 (1%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.2 (6%) | 0.4 (12%) | 0.5 (14%) | 2.4 (25%) | 0.6 (34%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.2 (5%) | 0.3 (11%) | 0.3 (10%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) |
| NO CASTS LEFT: every cast used on other spells | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (1%) | 0.0 (0%) | 0.0 (1%) | 0.2 (2%) | 0.0 (0%) | 0.3 (1%) |
| GONE: slain | 0.8 (21%) | 0.6 (19%) | 0.7 (21%) | 1.7 (18%) | 0.1 (4%) | 2.9 (13%) |
| OFF THE TABLE: off the table or not arrived | 0.2 (7%) | 0.1 (2%) | 0.1 (3%) | 0.3 (3%) | 0.0 (0%) | 0.6 (3%) |
| STUPIDITY: Stupidity | 0.1 (2%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.3 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.3 (11%) | 0.0 (1%) | 0.1 (1%) | 0.6 (31%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.0 (58%) | 0.2 (6%) | 1.4 (42%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 15.7 (73%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.4 a game | 0.3 a game | 0.8 a game |
| stood (cast and not dispelled) | 68% (30 of 44) | 80% (8 of 10) | 70% (38 of 54) |
| the unit moved after it | 70% (21 of 30) | 50% (4 of 8) | 66% (25 of 38) |
| it charged on its next turn | 0% (0 of 30) | 0% (0 of 8) | 0% (0 of 38) |
| the enemy charged it first | 27% (8 of 30) | 12% (1 of 8) | 24% (9 of 38) |
| it fought by the end of its next turn | 13% (4 of 30) | 12% (1 of 8) | 13% (5 of 38) |
| it moved out of a charge the enemy had planned (not charged first) | 7% (2 of 30) | 12% (1 of 8) | 8% (3 of 38) |
| none of these (no charge, no fight, no charge escaped) | 63% (19 of 30) | 75% (6 of 8) | 66% (25 of 38) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 63% (578 of 919) | 55% (331 of 604) | 60% (909 of 1523) |
|   cavalry | 54% (45 of 84) | 63% (80 of 127) | 59% (125 of 211) |
|   character | 44% (47 of 106) | 29% (34 of 116) | 36% (81 of 222) |
|   chariot | 46% (46 of 101) | 57% (20 of 35) | 49% (66 of 136) |
|   infantry | 60% (176 of 292) | 54% (128 of 235) | 58% (304 of 527) |
|   monster | 68% (27 of 40) | 57% (17 of 30) | 63% (44 of 70) |
|   war machine | 80% (237 of 296) | 85% (52 of 61) | 81% (289 of 357) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.8 (19%) | 1.7 (22%) | 3.5 (21%) |
| CHARGED: it charged | 1.2 (13%) | 1.7 (22%) | 2.9 (17%) |
| FLEEING: it fled or was fleeing | 0.0 (0%) | 0.1 (2%) | 0.2 (1%) |
| IN COMBAT: it fought this turn or the last | 1.1 (11%) | 0.4 (5%) | 1.4 (8%) |
| MOVED: a war machine that moved | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| FREE: none of these - no target in range or sight, or held its fire | 0.3 (3%) | 0.0 (0%) | 0.3 (2%) |
| NO TARGET IN RANGE | 1.8 (19%) | 1.6 (22%) | 3.4 (20%) |
| ONLY IN COMBAT: the only targets were in combat | 0.4 (5%) | 0.6 (7%) | 1.0 (6%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 2.1 (22%) | 0.9 (12%) | 3.0 (17%) |
| SHELTERED: the target was sheltered | 0.2 (3%) | 0.2 (3%) | 0.4 (3%) |
| STUPIDITY | 0.0 (0%) | 0.1 (2%) | 0.1 (1%) |
| OTHER BAR | 0.4 (4%) | 0.3 (4%) | 0.7 (4%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 5.2 | 1.2 | 81% | 4.9 pts | 25 pts |
| character | 2.7 | 1.1 | 72% | 8.6 pts | 23 pts |
| chariot | 1.9 | 1.6 | 64% | 12.0 pts | 22 pts |
| infantry | 12.2 | 4.3 | 75% | 7.8 pts | 95 pts |
| monster | 1.4 | 0.5 | 80% | 7.7 pts | 11 pts |
| war machine | 8.0 | 5.7 | 61% | 21.4 pts | 172 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.6 | 5.8 | 5.2 |
| Charges that made contact a game | 3.5 | 4.2 | 3.8 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.00 declared, 0.95 contact (22 units) | 0.57 declared, 0.36 contact (14 units) | 0.83 declared, 0.72 contact (36 units) |
|   per unit a game, units carrying another wizard (or one alone) | 1.00 declared, 0.88 contact (8 units) | 0.86 declared, 0.57 contact (7 units) | 0.93 declared, 0.73 contact (15 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.53 declared, 0.39 contact (251 units) | 0.68 declared, 0.49 contact (286 units) | 0.61 declared, 0.45 contact (537 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 54% (38 of 70) | 52% (11 of 21) | 38% (3 of 8) | 53% (52 of 99) |
| Character in a unit | 83% (25 of 30) | 80% (16 of 20) | 75% (3 of 4) | 81% (44 of 54) |
| Character on its own | 84% (48 of 57) | 38% (15 of 40) | 29% (18 of 62) | 51% (81 of 159) |
| Chariot | 50% (8 of 16) | 50% (5 of 10) | - | 50% (13 of 26) |
| Infantry | 57% (51 of 89) | 36% (13 of 36) | 50% (1 of 2) | 51% (65 of 127) |
| Monster | 56% (18 of 32) | 70% (7 of 10) | - | 60% (25 of 42) |
| Monstrous | 73% (8 of 11) | 57% (8 of 14) | - | 64% (16 of 25) |
| War Machines | 71% (29 of 41) | 100% (1 of 1) | - | 71% (30 of 42) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 6 | 82% (14 of 17); on the table 82% | 48% (66 of 138) | 43% | 55% (18 of 33) | 100% (9 of 9); 5.3 uses a game | 100% (3 of 3); 1.8 uses a game | 89% (8 of 9); 1.3 uses a game |
| Chaos Dwarfs | 3 | 83% (10 of 12); on the table 83% | 29% (7 of 24) | 38% | 38% (9 of 24) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 0.3 uses a game |
| Dwarfen Mountain Holds | 5 | 62% (8 of 13); on the table 69% | - | 57% | 76% (31 of 41) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 6 | 88% (7 of 8); on the table 100% | 42% (15 of 36) | 59% | 64% (41 of 64) | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game | 50% (2 of 4); 0.3 uses a game |
| Grand Cathay | 5 | 100% (18 of 18); on the table 100% | 29% (31 of 108) | 47% | 39% (17 of 44) | 92% (11 of 12); 9.4 uses a game | 100% (1 of 1); 0.2 uses a game | 20% (1 of 5); 0.2 uses a game |
| High Elf Realms | 6 | 84% (21 of 25); on the table 84% | 17% (5 of 30) | 32% | 47% (23 of 49) | 100% (5 of 5); 2.7 uses a game | 39% (7 of 18); 1.2 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | 100% (3 of 3); on the table 100% | - | 29% | 50% (3 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Lizardmen | 2 | 100% (5 of 5); on the table 100% | - | 46% | 86% (12 of 14) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 3 | 88% (14 of 16); on the table 94% | 25% (3 of 12) | 34% | 62% (13 of 21) | 67% (2 of 3); 2.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 3 | 100% (12 of 12); on the table 100% | 14% (5 of 36) | 4% | 71% (17 of 24) | 0.0 uses a game | 0.0 uses a game | 100% (3 of 3); 1.0 uses a game |
| Skaven | 4 | 100% (23 of 23); on the table 100% | 47% (14 of 30) | 32% | 50% (17 of 34) | 67% (2 of 3); 1.2 uses a game | 0.0 uses a game | 50% (2 of 4); 0.5 uses a game |
| Tomb Kings of Khemri | 6 | 70% (16 of 23); on the table 78% | 0% (0 of 12) | 29% | 33% (10 of 30) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 8 | 95% (21 of 22); on the table 100% | 44% (24 of 54) | 37% | 64% (32 of 50) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 8 | 84% (16 of 19); on the table 89% | 33% (10 of 30) | 30% | 61% (45 of 74) | 100% (4 of 4); 1.9 uses a game | 0.0 uses a game | 50% (1 of 2); 0.1 uses a game |
| Wood Elf Realms | 6 | 92% (11 of 12); on the table 92% | 40% (12 of 30) | 41% | 58% (38 of 66) | 33% (2 of 6); 1.5 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (sp-h2h-mine-89601ea-p1, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 47% (40) | 42% (31) | 45% (71) |
| ...free all their last turn and able to turn (per game) | 0.58 | 0.44 | 1.03 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.28 | 0.17 | 0.44 |
| ...with the charger already in that arc before they moved (per game) | 0.36 | 0.36 | 0.72 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 1.17 | 1.14 | 2.31 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.81 | 1.06 | 1.86 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 5.56 | 4.72 | 10.28 |

### Quality by phase: sp-h2h-mine-89601ea-p1

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.1 | 3.4 |
| Strategy | Charge objectives carried out (made contact) | 53% (85 of 159) | 46% (80 of 175) |
| Strategy | Shoot objectives carried out (shot that target) | 38% (168 of 437) | 58% (102 of 176) |
| Strategy | Close-in objectives charged next turn | 18% (26 of 144) | 18% (38 of 209) |
| Strategy | Support requests answered (helper made contact too) | 39% (7 of 18) | 54% (13 of 24) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 80% (4 of 5) | 33% (1 of 3) |
| Strategy | Hexes on a unit its side charged or shot that turn | 45% (5 of 11) | 80% (8 of 10) |
| Strategy | Joined characters whose unit fought | 38% (18 of 47) | 51% (18 of 35) |
| Strategy | Lone characters that fought | 82% (81 of 99) | 67% (68 of 101) |
| Movement | Charges halted short of contact | 0.1 | 0.3 |
| Movement | Idle units | 0.9 | 1.8 |
| Movement | Points that never moved of their own | 303.6 | 168.0 |
| Movement | Fights charged into per game | 3.0 | 3.3 |
| Movement | Charges with odds: long shots (under 50%) | 19 of 95, net +12 | 16 of 101, net +65 |
| Movement | Charges with odds: sweet spot (55-75%) | 17 of 95, net +133 | 17 of 101, net +124 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 9 of 95, net +54 | 9 of 101, net -17 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 33 of 95, net +76 | 36 of 101, net +114 |
| Shooting | Shots by shooting units (incl. breath weapons) | 10.4 | 8.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 40% (150 of 375) | 47% (148 of 314) |
| Shooting | Points destroyed by shooting units | 51.6 | 39.4 |
| Shooting | War machine shots | 6.6 | 1.4 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 39% (92 of 237) | 35% (18 of 52) |
| Shooting | Points destroyed by war machines | 90.0 | 6.7 |
| Magic | Magic missiles cast | 2.1 | 1.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 31% (23 of 75) | 29% (14 of 48) |
| Magic | Wounds caused by magic missiles | 4.6 | 1.5 |
| Magic | Wounds caused by other spells | 2.2 | 0.4 |
| Magic | Points destroyed by magic (all spells) | 134.0 | 11.7 |
| Magic | Augments / hexes / assailments / vortexes cast | 2.0 / 0.4 / 1.2 / 0.1 | 1.6 / 0.4 / 0.3 / 0.1 |
| Combat | Points destroyed in combat | 322.5 | 340.8 |
| Combat | Points run down | 36.2 | 163.2 |
| Combat | Net points per charged fight, damage counted | +74 | +84 |
| Combat | Net per 100 charger points, damage counted | +28.4 | +29.5 |
| Combat | First round won (charged fights) | 71% | 64% |
| Combat | Net points per charged fight | +69 | +91 |
| Combat | Net points per supported fight / lone fight | +63 / +70 | +114 / +84 |
| Combat | Charged fights on a top-3 enemy unit | 42 of 109 | 56 of 120 |
| Game | Points lost | 656.7 | 762.9 |
| Game | VP from objectives | 666.9 | 635.3 |
| Game | Lone holders (player turns) | 2.0 | 3.3 |

- Mine won / drew / lost: 19 / 2 / 15 of 36 ended games (of 36); mean margin (Mine - Opponent) +131 VP
- The side that went first won 20 of 34 games with a winner
- Points traded per game (both sides' losses): 1420
- Games not ended: 0; findings 1, warnings 0

### Opponent rules: sp-h2h-mine-89601ea-p1

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.6 | +0.0 | 0.0 | 1.8 | 0.8 | +0.0 | 0.0 | 0.0 |
| ALREADY CARRIED | 0.1 | +0.0 | 0.0 | 3.6 | - | - | - | - |
| ARRIVAL HUNT | - | - | - | - | 0.0 | +0.2 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.1 | +0.0 | 0.0 | 3.5 | 0.4 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | 0.7 | +5.9 | 0.0 | 21.9 | 1.0 | +11.3 | 0.0 | 13.9 |
| BEST FACING | 0.5 | +12.6 | 0.0 | 27.6 | 0.3 | +18.9 | 0.0 | 7.1 |
| BEST FIRST | 3.5 | +164.6 | 81.8 | 85.4 | 4.6 | +240.8 | 100.3 | 66.4 |
| BEST MOVE FOR SHOOTERS | 0.9 | +60.0 | 0.0 | 12.8 | - | - | - | - |
| BEST OVERALL | 0.5 | +33.0 | 0.0 | 18.1 | 0.4 | +30.7 | 0.0 | 5.3 |
| BEST PREY | 0.8 | +36.4 | 43.2 | 9.5 | 0.8 | +36.8 | 31.8 | 4.0 |
| BEST PRIZE | 0.1 | -2.7 | 6.5 | 0.0 | 0.0 | -2.5 | 0.0 | 0.0 |
| BIG CHARACTER SAFETY | 0.2 | -0.1 | 0.0 | 11.2 | 0.2 | -0.6 | 0.0 | 27.1 |
| BLOCKED CHARGE SKIPPED | 0.1 | +0.0 | 4.6 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| BLOCKED WHEEL | 0.2 | +0.3 | 0.0 | 0.0 | 0.4 | +24.2 | 0.0 | 1.8 |
| BOMBING RUN | 0.0 | +0.9 | 4.0 | 0.0 | - | - | - | - |
| CANNON PLAN MISSED | - | - | - | - | 0.0 | +0.0 | 3.3 | 0.0 |
| CANNON PLANNED TARGET | - | - | - | - | 1.4 | +30.8 | 28.3 | 0.0 |
| CANNON SIGHT KEPT | 1.0 | +0.0 | 0.0 | 3.5 | 0.4 | +0.0 | 0.0 | 7.2 |
| CARRIES OUT COUNTER | - | - | - | - | 0.1 | +0.0 | 1.4 | 0.0 |
| CARRIES OUT SET-UP | 0.1 | -2.0 | 9.5 | 10.6 | 0.1 | -1.8 | 12.6 | 3.2 |
| CAST JOB | 0.9 | +29.1 | 57.6 | 0.0 | 0.4 | +5.4 | 7.8 | 27.6 |
| CASTER AWAY FROM SCREEN | 0.4 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.5 | +52.0 | 27.1 | 10.2 | 0.2 | +7.1 | 16.6 | 4.4 |
| CASTS AFTER FRIENDS | 0.8 | +0.0 | 0.0 | 3.6 | 0.2 | +0.0 | 0.0 | 20.7 |
| CASTS FROM BEHIND | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.0 | +0.1 | 0.0 | 6.1 | 0.0 | +0.3 | 0.0 | 0.0 |
| CATCH ODDS | 0.0 | +4.2 | 0.0 | 0.0 | - | - | - | - |
| CHAFF PASSED | - | - | - | - | 0.1 | -0.2 | 0.0 | 0.0 |
| CHAMPION TAKES THE CHALLENGE | - | - | - | - | 0.0 | +0.1 | 8.0 | 0.0 |
| CHARGE NOW FIRST | 3.0 | +0.0 | 227.7 | 85.6 | 2.5 | +0.0 | 204.2 | 53.5 |
| CHARGE NOW WEIGHED | 0.5 | -38.1 | 3.0 | 7.8 | 0.6 | -77.9 | 25.9 | 27.1 |
| CHARIOT NO STATIC JOB | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHARIOT WIZARD CAREFUL | - | - | - | - | 0.0 | -1.8 | 0.0 | 0.0 |
| CHEAP HELPER | 0.1 | +0.0 | 1.1 | 1.7 | 0.1 | +0.0 | 8.1 | 1.4 |
| COMBAT PIVOT | 0.3 | +0.0 | 33.2 | 2.5 | 0.5 | +0.0 | 13.1 | 44.4 |
| CONTINUE AHEAD WEIGHED | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | 0.7 | +94.5 | 6.3 | 7.2 | 0.2 | +23.6 | 17.4 | 35.9 |
| COUNTER-CHARGE COVER | 10.0 | +821.4 | 0.0 | 240.0 | 6.8 | +609.7 | 0.0 | 167.9 |
| DEFENSIVE ARMY | 0.4 | +0.0 | 96.8 | 5.8 | - | - | - | - |
| DEFENSIVE FLOOR | 0.1 | +0.8 | 0.0 | 6.7 | 0.1 | +17.3 | 0.0 | 3.0 |
| EDGE GIVE GROUND | 0.2 | +7.7 | 40.2 | 2.4 | 0.1 | +4.0 | 14.7 | 0.0 |
| ELIXIR WORTH | 0.0 | +0.4 | 0.0 | 0.0 | 0.1 | +0.9 | 0.0 | 0.0 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACE THE CAST | 0.1 | +2.9 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 1.2 | +99.6 | 0.0 | 53.8 | 1.1 | +124.2 | 0.0 | 58.7 |
| FALLBACK BY WORTH | 4.6 | +49.9 | 0.0 | 71.5 | 5.7 | +50.0 | 0.0 | 37.1 |
| FIGHT LIFT | 0.0 | +0.1 | 4.7 | 0.0 | - | - | - | - |
| FIRE IN ORDER | 1.0 | +0.0 | 42.8 | 6.6 | - | - | - | - |
| FIRE PLAN | 16.4 | +501.9 | 1279.0 | 209.2 | - | - | - | - |
| FLANK NOT WEIGHED | 5.3 | +0.0 | 0.0 | 176.0 | 4.6 | +0.0 | 0.0 | 134.9 |
| FOLLOW UP WEIGHED | 1.1 | +120.0 | 0.0 | 35.4 | 0.9 | +142.2 | 0.0 | 24.6 |
| FRIENDS SHOTS CHECKED | 0.3 | +20.8 | 0.0 | 17.2 | 0.0 | +1.6 | 0.0 | 0.0 |
| GIVES UP | 0.1 | -1.0 | 0.0 | 1.4 | 0.1 | -1.5 | 11.9 | 1.4 |
| GIVES UP ITS SCREEN | 0.1 | -0.0 | 4.0 | 1.8 | - | - | - | - |
| HELPER ALREADY ASKED | 0.0 | +0.0 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 0.8 |
| HELPER UNSEEN | 0.3 | +0.0 | 22.6 | 7.0 | 0.2 | +0.0 | 17.8 | 0.0 |
| HILL BY ITS CHANCE | - | - | - | - | 0.2 | -18.2 | 0.0 | 2.2 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.8 | +0.0 | 0.0 | 0.0 |
| HUNT ADVANCE | 0.1 | +0.6 | 15.2 | 2.4 | 0.1 | +4.6 | 3.6 | 2.9 |
| HUNT DROPPED | 0.1 | +0.0 | 7.6 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| HUNT IN PAIRS | 0.5 | +39.9 | 0.0 | 0.0 | 0.4 | +15.8 | 0.0 | 37.9 |
| HUNT RESULT | 0.1 | +16.2 | 7.6 | 0.0 | 0.1 | +5.8 | 3.6 | 3.9 |
| HUNT THE GUNS | 0.1 | +43.8 | 22.8 | 4.0 | 0.1 | +46.4 | 3.6 | 8.1 |
| INVITES THE FIGHT | 1.8 | +41.4 | 108.2 | 63.9 | 2.1 | +45.1 | 65.8 | 39.2 |
| JOINT CHARGE PLAN | 0.1 | +12.8 | 9.5 | 0.0 | 0.1 | +7.2 | 0.0 | 0.0 |
| KEEP FALLS | 0.1 | +2.2 | 0.0 | 7.5 | 0.0 | +0.5 | 0.0 | 0.0 |
| KEEPS ITS PREY | 0.0 | +0.1 | 0.0 | 0.0 | 0.1 | +0.6 | 0.0 | 4.7 |
| KEEPS ITS TARGET | 1.9 | +58.3 | 102.9 | 37.0 | 2.1 | +64.2 | 146.3 | 35.2 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KEEPS THE TARGET | 1.7 | -36.0 | 259.7 | 37.1 | - | - | - | - |
| KILLS COUNT | 1.8 | +56.3 | 114.6 | 28.9 | 1.9 | +91.5 | 163.7 | 38.5 |
| KILLS COUNT NEXT TURN | 4.4 | +140.6 | 131.3 | 70.0 | 6.8 | +317.6 | 256.2 | 169.8 |
| LONE CHARACTER SAFE SPOT | 0.4 | +10.2 | 35.1 | 0.0 | 0.6 | +12.2 | 23.6 | 12.5 |
| LONE WIZARD HOLDS BACK | 0.1 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 14.2 | 7.6 |
| LONE WIZARD KEPT IN | 0.7 | +49.1 | 0.0 | 0.0 | 0.2 | +24.5 | 0.0 | 0.0 |
| LONG SHOT | 0.3 | +1.7 | 14.6 | 1.1 | 0.4 | -3.7 | 14.5 | 5.2 |
| LOST CHARGE | 2.9 | -45.5 | 119.0 | 84.8 | 2.8 | -50.0 | 67.6 | 84.2 |
| LURE BY WHAT IT DRAWS | 0.1 | -6.4 | 0.0 | 1.1 | 0.0 | -2.8 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 0.5 | +38.4 | 21.2 | 33.4 | 0.6 | +55.2 | 4.9 | 1.7 |
| MANOEUVRE | 0.2 | +7.7 | 0.0 | 6.3 | 0.2 | +2.8 | 0.0 | 2.4 |
| MARCH AT ESCAPER | 0.0 | +0.0 | 0.0 | 0.0 | 0.0 | +0.9 | 0.0 | 0.0 |
| MARCH CHECK | 0.4 | +26.8 | 0.0 | 16.1 | 0.7 | +35.3 | 0.0 | 14.1 |
| MARCH ODDS | 0.2 | +25.3 | 22.8 | 0.0 | 0.2 | +12.1 | 3.3 | 6.2 |
| MARCH OVER CASTS | 0.4 | +48.7 | 0.0 | 1.1 | 0.2 | +35.1 | 0.0 | 22.4 |
| MAX FOR POSITIONING | 4.9 | +215.4 | 0.0 | 156.1 | 4.3 | +157.8 | 0.0 | 115.6 |
| MISSILES IN THE FIRE PLAN | 3.7 | +153.9 | 218.0 | 33.6 | - | - | - | - |
| MISSILES IN THE MOVE | 4.5 | +184.7 | 0.0 | 73.5 | 3.6 | +54.1 | 0.0 | 129.4 |
| MISSILES NEXT TURN | 5.0 | +120.7 | 0.0 | 89.6 | 4.0 | +39.1 | 0.0 | 168.3 |
| MODEL FACING | 0.2 | +59.9 | 0.0 | 3.3 | - | - | - | - |
| MONSTER WIZARD ROAMS | 0.2 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| MOVE AND CAST | 0.4 | +44.1 | 0.0 | 0.0 | 0.2 | +5.3 | 0.0 | 0.0 |
| MOVE SPELL IN RANGE | 0.1 | +5.6 | 0.0 | 0.0 | 0.1 | +0.5 | 0.0 | 7.6 |
| MOVE SPELL OUT OF RANGE | 0.3 | -54.6 | 0.0 | 3.6 | 0.1 | -17.7 | 0.0 | 7.6 |
| MOVE SPELL SPOT | 0.4 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 13.1 |
| MOVE TO CHARGE | 3.0 | +220.0 | 99.9 | 52.6 | 4.8 | +469.7 | 143.1 | 114.8 |
| MOVES UNITS SPELL | 0.1 | +3.4 | 0.0 | 0.0 | 0.1 | +1.8 | 0.0 | 0.0 |
| NEEDED THERE | - | - | - | - | 0.1 | +12.3 | 23.1 | 0.0 |
| NO RALLY LEFT | - | - | - | - | 0.1 | +8.3 | 0.0 | 1.9 |
| NOT NEEDED | 0.4 | -18.8 | 38.2 | 8.1 | 0.4 | -15.8 | 49.5 | 2.5 |
| NOT TURNED | 5.6 | +193.4 | 0.0 | 116.3 | 4.7 | +53.5 | 0.0 | 127.9 |
| NOT WORTH A CAST | 0.6 | -0.5 | 0.0 | 22.8 | 0.3 | -0.3 | 0.0 | 0.0 |
| OFF BEST | 14.9 | -803.6 | 6.2 | 233.2 | 15.1 | -798.3 | 6.3 | 322.1 |
| OPENS A LANE | 0.2 | +0.8 | 0.0 | 0.0 | 0.1 | +0.1 | 8.2 | 12.1 |
| OPENS UP | 0.4 | +24.4 | 22.9 | 0.0 | 0.2 | +26.0 | 12.6 | 7.9 |
| OVERRUNS AWAY | 0.6 | +16.8 | 35.8 | 41.6 | 0.6 | +12.8 | 46.2 | 13.7 |
| PATHS CROSS | 1.9 | +135.2 | 0.0 | 21.8 | 2.4 | +164.3 | 0.0 | 23.6 |
| PERIAPT WORTH | - | - | - | - | 0.1 | +5.0 | 0.0 | 15.0 |
| PIVOT GUARDS FLANK | 0.1 | -1.0 | 0.0 | 0.0 | 0.1 | -2.0 | 0.0 | 2.9 |
| PLAN RESULT | 37.9 | +1478.3 | 1665.1 | 830.0 | 37.8 | +1063.7 | 1170.4 | 972.5 |
| PURSUES BIG PREY | 0.1 | -2.1 | 0.0 | 5.2 | 0.1 | -4.9 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE NEXT TURN | - | - | - | - | 0.1 | +14.8 | 0.0 | 1.5 |
| RANDOM MOVE BY FIGURES | 0.9 | +16.6 | 0.0 | 13.9 | 1.4 | +22.7 | 0.0 | 60.1 |
| RANDOM MOVER NO PROMISE | 0.1 | -8.0 | 4.4 | 0.0 | 0.4 | -25.8 | 0.0 | 24.0 |
| REDIRECT BY WHAT IT STOPS | 0.2 | -6.4 | 0.0 | 4.1 | 0.5 | -11.5 | 0.0 | 11.2 |
| REDIRECT COUNTER | 2.2 | +138.7 | 0.0 | 38.0 | 3.7 | +284.3 | 0.0 | 62.3 |
| REDIRECT WEIGHED | 0.3 | +2.7 | 7.8 | 1.4 | 0.5 | +9.3 | 7.1 | 7.7 |
| RESERVE FALL BACK | 0.5 | +6.2 | 0.0 | 2.0 | 0.8 | +26.7 | 0.0 | 14.9 |
| RESTRAINS TO SHOOT | 0.1 | +7.8 | 0.0 | 15.3 | 0.0 | +2.8 | 0.0 | 5.1 |
| RISK BY ARC | 2.6 | +97.9 | 210.4 | 92.4 | 2.9 | +75.9 | 226.6 | 70.8 |
| SAFER THAN THE JOB | 0.8 | +42.7 | 0.0 | 18.5 | 1.1 | +52.9 | 0.0 | 14.9 |
| SCOUT SPOT | 0.4 | +0.6 | 0.0 | 0.0 | 0.3 | +0.3 | 0.0 | 1.9 |
| SCOUT WAITS | 0.4 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 1.9 |
| SCREEN BY WHAT IT SAVES | 0.1 | -8.3 | 0.0 | 1.5 | 0.2 | +5.3 | 0.0 | 3.4 |
| SEARCH SPOT | 2.5 | +78.9 | 0.0 | 44.8 | 3.1 | +156.5 | 0.0 | 41.9 |
| SECOND HUNTER | 0.0 | -0.9 | 7.6 | 0.0 | - | - | - | - |
| SELF MOVE SPELL | 0.2 | +19.7 | 0.0 | 9.1 | 0.2 | +2.1 | 0.0 | 18.1 |
| SET UP TOGETHER | 0.9 | +102.7 | 21.2 | 50.2 | 1.2 | +145.5 | 10.1 | 8.9 |
| SET-UP ANY TARGET | 0.4 | +28.9 | 6.3 | 7.2 | 0.1 | +11.0 | 17.4 | 20.7 |
| SET-UP MISSED | - | - | - | - | 0.0 | +2.1 | 2.8 | 7.6 |
| SHOOTER COUNTED ONCE | 0.0 | -0.0 | 0.0 | 1.5 | 0.0 | -0.1 | 0.0 | 0.0 |
| SHOOTERS ARE THREATS | 3.1 | +208.0 | 350.2 | 45.3 | - | - | - | - |
| SHOOTERS IN TWO RANKS | 0.4 | +0.9 | 0.0 | 0.0 | 0.3 | +0.8 | 0.0 | 0.0 |
| SHOOTERS TO THE PRIMARY | 6.1 | +330.9 | 0.0 | 91.1 | - | - | - | - |
| SHOOTS FROM THE BEST SPOT | 1.0 | +48.6 | 99.4 | 5.1 | 0.6 | +23.3 | 28.8 | 11.1 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 3.2 | 0.0 | +0.0 | 0.0 | 3.8 |
| SHOT OPTIONS | 15.9 | +0.0 | 1035.2 | 217.5 | 9.6 | +0.0 | 343.5 | 142.2 |
| SHOT REPLANNED | - | - | - | - | 0.1 | +0.0 | 12.8 | 18.1 |
| SHOTS IN THE MOVE | 15.6 | +696.5 | 0.0 | 221.3 | 8.6 | +212.1 | 0.0 | 96.2 |
| SPELL SETS UP CHARGE | 0.4 | +50.0 | 6.3 | 7.2 | 0.1 | +11.0 | 17.4 | 20.7 |
| SPELL WORTH | 1.6 | +24.3 | 48.8 | 39.0 | 1.6 | +39.4 | 122.3 | 116.3 |
| STABLE ROLE | 11.6 | +0.0 | 488.8 | 172.0 | 10.6 | +0.0 | 295.7 | 143.8 |
| STANDS TO CAST | 0.1 | +8.1 | 0.0 | 15.0 | - | - | - | - |
| STAY WEIGHED | 0.1 | +6.5 | 0.0 | 0.0 | 0.0 | +0.8 | 0.0 | 0.0 |
| STAY WORTH | 17.9 | +36.3 | 543.4 | 176.8 | - | - | - | - |
| STOPS | 0.1 | +1.4 | 7.6 | 1.7 | 0.1 | +1.7 | 0.0 | 5.2 |
| STOPS SHORT OF THE FLANK | 0.4 | +13.9 | 0.0 | 20.1 | 0.6 | +29.0 | 0.0 | 16.8 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 4.0 | 0.2 | +0.0 | 0.0 | 4.0 |
| SUPPORT NARROWED | 5.7 | -47.6 | 316.3 | 107.6 | 7.1 | -49.6 | 348.9 | 105.1 |
| SUPPORTS | 3.5 | +51.1 | 185.4 | 60.3 | 4.6 | +58.1 | 180.4 | 67.2 |
| SURE CHARGE BEATS ADVANCE | 0.1 | -17.5 | 7.6 | 0.0 | 0.1 | -0.8 | 2.0 | 3.2 |
| SURE REACH TOGETHER | 0.5 | +1.2 | 5.1 | 0.0 | 0.6 | +1.4 | 3.8 | 8.1 |
| THREAT AT FULL SIZE | 8.7 | +0.0 | 711.8 | 129.4 | - | - | - | - |
| THROUGH LINE OF FIRE | 0.6 | +11.7 | 0.0 | 1.7 | 0.2 | +5.6 | 0.0 | 16.2 |
| TURN WORTH | 0.8 | -53.3 | 55.4 | 7.5 | 0.4 | -27.7 | 25.8 | 0.0 |
| TWO OR MORE ARRIVE | 0.2 | +2.1 | 6.5 | 12.3 | 0.3 | +4.5 | 4.9 | 0.0 |
| WAIT AFTER COSTS | 6.9 | -333.8 | 262.5 | 152.2 | 9.2 | -507.1 | 278.5 | 207.4 |
| WALKS TO THE FIGHT | 1.6 | +43.4 | 59.5 | 19.8 | 1.5 | +43.4 | 25.5 | 20.4 |
| WAR ENGINE CHARGES | 0.0 | +1.5 | 1.5 | 0.0 | 0.0 | +1.5 | 0.0 | 0.0 |
| WAR ENGINE JOBS | 0.6 | +0.0 | 27.9 | 11.0 | 0.5 | +0.0 | 17.9 | 11.0 |
| WEARS DOWN | 1.3 | +51.8 | 163.3 | 42.2 | 1.6 | +59.5 | 155.2 | 25.8 |
| WHO HITS BACK | 0.3 | +13.7 | 0.0 | 6.0 | 0.2 | +14.7 | 0.0 | 10.6 |
| WHOLE FIGHT | 0.3 | +11.1 | 50.0 | 13.6 | 0.4 | -0.3 | 22.8 | 5.5 |
| WHOLE FIGHT GAIN | 0.2 | +21.4 | 20.8 | 1.2 | 0.7 | +50.6 | 70.5 | 19.3 |

### Rule changes: sp-h2h-mine-89601ea-p1

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 1082 | 1082 | 1082 | 30.06 | -57672 | -53.3 |
| BEST FIRST | 292 | 292 | 292 | 8.11 | +14593 | +50.0 |
| SEARCH SPOT | 200 | 200 | 200 | 5.56 | +8474 | +42.4 |
| FIRE PLAN | 590 | 590 | 173 | 4.81 | +6482 | +37.5 |
| COUNTER-CHARGE COVER | 602 | 368 | 167 | 4.64 | +10041 | +60.1 |
| PATHS CROSS | 153 | 153 | 153 | 4.25 | +10782 | +70.5 |
| MOVE TO CHARGE | 280 | 280 | 151 | 4.19 | +10380 | +68.7 |
| KILLS COUNT NEXT TURN | 400 | 400 | 120 | 3.33 | +4077 | +34.0 |
| SUPPORTS | 293 | 293 | 101 | 2.81 | +1192 | +11.8 |
| FACES THE THREAT | 83 | 83 | 83 | 2.31 | +8057 | +97.1 |
| SHOTS IN THE MOVE | 871 | 581 | 82 | 2.28 | +2407 | +29.4 |
| FOLLOW UP WEIGHED | 70 | 70 | 70 | 1.94 | +9438 | +134.8 |
| WALKS TO THE FIGHT | 109 | 109 | 70 | 1.94 | +1022 | +14.6 |
| FALLBACK BY WORTH | 372 | 372 | 69 | 1.92 | +3600 | +52.2 |
| SAFER THAN THE JOB | 67 | 67 | 67 | 1.86 | +3442 | +51.4 |
| WAIT AFTER COSTS | 581 | 581 | 64 | 1.78 | +1188 | +18.6 |
| REDIRECT COUNTER | 213 | 121 | 56 | 1.56 | +3909 | +69.8 |
| ARTILLERY RE-ROLL WEIGHED | 55 | 55 | 55 | 1.53 | +0 | +0.0 |
| CANNON SIGHT KEPT | 52 | 52 | 52 | 1.44 | +0 | +0.0 |
| RANDOM MOVE BY FIGURES | 80 | 80 | 51 | 1.42 | +1415 | +27.7 |
| ADVANCE LANE KEPT | 49 | 49 | 49 | 1.36 | +0 | +0.0 |
| MISSILES IN THE MOVE | 292 | 176 | 48 | 1.33 | +1940 | +40.4 |
| CHARGE NOW FIRST | 196 | 196 | 45 | 1.25 | -4588 | -102.0 |
| INVITES THE FIGHT | 139 | 139 | 45 | 1.25 | +852 | +18.9 |
| HOLDS AMBUSHERS | 44 | 44 | 44 | 1.22 | +0 | +0.0 |
| RESERVE FALL BACK | 44 | 44 | 44 | 1.22 | +1183 | +26.9 |
| CHARGE NOW WEIGHED | 39 | 39 | 39 | 1.08 | +2771 | +71.0 |
| MARCH CHECK | 41 | 39 | 39 | 1.08 | +1965 | +50.4 |
| MAX FOR POSITIONING | 333 | 202 | 39 | 1.08 | +458 | +11.7 |
| FIRE IN ORDER | 36 | 36 | 36 | 1.00 | +0 | +0.0 |
| SET UP TOGETHER | 74 | 65 | 36 | 1.00 | +3751 | +104.2 |
| BEST MOVE FOR SHOOTERS | 34 | 34 | 34 | 0.94 | +2162 | +63.6 |
| BEST OVERALL | 34 | 34 | 34 | 0.94 | +2295 | +67.5 |
| LONE WIZARD KEPT IN | 34 | 34 | 34 | 0.94 | +2648 | +77.9 |
| RISK BY ARC | 199 | 188 | 34 | 0.94 | +1079 | +31.7 |
| STOPS SHORT OF THE FLANK | 34 | 34 | 34 | 0.94 | +1547 | +45.5 |
| COMBAT PIVOT | 31 | 31 | 31 | 0.86 | +0 | +0.0 |
| KILLS COUNT | 134 | 133 | 31 | 0.86 | +1281 | +41.3 |
| REDIRECT WEIGHED | 30 | 30 | 30 | 0.83 | +825 | +27.5 |
| SHOOTS FROM THE BEST SPOT | 60 | 60 | 30 | 0.83 | +1076 | +35.9 |
| BEST FACING | 29 | 29 | 29 | 0.81 | +1134 | +39.1 |
| THROUGH LINE OF FIRE | 29 | 29 | 29 | 0.81 | +622 | +21.5 |
| STAY WORTH | 643 | 527 | 27 | 0.75 | +519 | +19.2 |
| SCOUT WAITS | 26 | 26 | 26 | 0.72 | +0 | +0.0 |
| CASTER AWAY FROM SCREEN | 25 | 25 | 25 | 0.69 | +0 | +0.0 |
| SHOOTERS IN TWO RANKS | 24 | 24 | 24 | 0.67 | +58 | +2.4 |
| BLOCKED WHEEL | 23 | 23 | 23 | 0.64 | +881 | +38.3 |
| MOVE AND CAST | 22 | 22 | 22 | 0.61 | +1780 | +80.9 |
| CAST JOB | 47 | 47 | 21 | 0.58 | +435 | +20.7 |
| CASTING BLOCK | 25 | 25 | 21 | 0.58 | +1003 | +47.8 |
| KEEPS ITS TARGET | 147 | 144 | 20 | 0.56 | +373 | +18.6 |
| WHO HITS BACK | 20 | 20 | 20 | 0.56 | +819 | +40.9 |
| WHOLE FIGHT GAIN | 32 | 25 | 19 | 0.53 | +1074 | +56.5 |
| BEST PREY | 56 | 56 | 18 | 0.50 | +644 | +35.8 |
| KEEPS THE TARGET | 60 | 60 | 18 | 0.50 | -1605 | -89.2 |
| CANNON PLANNED TARGET | 49 | 49 | 17 | 0.47 | -431 | -25.4 |
| WAR ENGINE JOBS | 39 | 39 | 16 | 0.44 | -1255 | -78.5 |
| SHOOTERS TO THE PRIMARY | 219 | 150 | 15 | 0.42 | +333 | +22.2 |
| CASTS FROM BEHIND | 14 | 14 | 14 | 0.39 | +0 | +0.0 |
| MARCH ODDS | 14 | 14 | 14 | 0.39 | +204 | +14.5 |
| BIG CHARACTER SAFETY | 13 | 13 | 13 | 0.36 | -28 | -2.2 |
| FRIENDS SHOTS CHECKED | 12 | 12 | 12 | 0.33 | +807 | +67.2 |
| MANOEUVRE | 16 | 16 | 12 | 0.33 | +378 | +31.5 |
| LOST CHARGE | 204 | 201 | 11 | 0.31 | +343 | +31.2 |
| OPENS UP | 23 | 23 | 11 | 0.31 | +387 | +35.2 |
| STUCK PIVOT | 11 | 11 | 11 | 0.31 | +0 | +0.0 |
| HUNT IN PAIRS | 32 | 22 | 10 | 0.28 | +475 | +47.5 |
| MAKE SURE TOGETHER | 40 | 25 | 10 | 0.28 | +846 | +84.7 |
| WEARS DOWN | 106 | 98 | 10 | 0.28 | +418 | +41.8 |
| PIVOT GUARDS FLANK | 9 | 9 | 9 | 0.25 | -110 | -12.3 |
| SHORT GUN FORWARD | 8 | 8 | 8 | 0.22 | +0 | +0.0 |
| SUPPORT NARROWED | 463 | 463 | 8 | 0.22 | -94 | -11.7 |
| BLOCKED CHARGE SKIPPED | 7 | 7 | 7 | 0.19 | +0 | +0.0 |
| MISSILES IN THE FIRE PLAN | 132 | 22 | 7 | 0.19 | +294 | +42.0 |
| MODEL FACING | 7 | 7 | 7 | 0.19 | +2155 | +307.9 |
| MOVES UNITS SPELL | 7 | 7 | 7 | 0.19 | +186 | +26.5 |
| SURE REACH TOGETHER | 39 | 32 | 7 | 0.19 | +10 | +1.4 |
| PURSUES BIG PREY | 6 | 6 | 6 | 0.17 | -250 | -41.7 |
| RESTRAINS TO SHOOT | 6 | 6 | 6 | 0.17 | +382 | +63.6 |
| BACKUP TARGETS | 63 | 36 | 5 | 0.14 | +35 | +7.0 |
| HUNT ADVANCE | 6 | 6 | 5 | 0.14 | +90 | +18.1 |
| KEEP FALLS | 5 | 5 | 5 | 0.14 | +293 | +58.6 |
| RAIDS THE BAGGAGE NEXT TURN | 5 | 5 | 5 | 0.14 | +360 | +72.0 |
| SHOT REPLANNED | 5 | 5 | 5 | 0.14 | +0 | +0.0 |
| BEST PRIZE | 4 | 4 | 4 | 0.11 | -844 | -211.0 |
| CHAFF PASSED | 4 | 4 | 4 | 0.11 | -9 | -2.2 |
| MISSILES NEXT TURN | 323 | 195 | 4 | 0.11 | +6 | +1.5 |
| OVERRUNS AWAY | 42 | 39 | 4 | 0.11 | +67 | +16.6 |
| STANDS TO CAST | 4 | 4 | 4 | 0.11 | +16 | +4.0 |
| SURE CHARGE BEATS ADVANCE | 4 | 4 | 4 | 0.11 | -659 | -164.7 |
| CARRIES OUT SET-UP | 7 | 7 | 3 | 0.08 | -137 | -45.8 |
| ELIXIR WORTH | 3 | 3 | 3 | 0.08 | +50 | +16.7 |
| NEEDED THERE | 4 | 4 | 3 | 0.08 | +0 | +0.0 |
| SHOOTERS ARE THREATS | 111 | 111 | 3 | 0.08 | +0 | +0.0 |
| STAY WEIGHED | 3 | 3 | 3 | 0.08 | +264 | +88.1 |
| WHOLE FIGHT | 28 | 28 | 3 | 0.08 | +75 | +25.1 |
| FACE THE CAST | 2 | 2 | 2 | 0.06 | +105 | +52.4 |
| JOINT CHARGE PLAN | 7 | 7 | 2 | 0.06 | +160 | +80.2 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| LONE WIZARD HOLDS BACK | 19 | 19 | 2 | 0.06 | -233 | -116.5 |
| LONG SHOT | 26 | 26 | 2 | 0.06 | -1 | -0.5 |
| NO RALLY LEFT | 2 | 2 | 2 | 0.06 | +19 | +9.4 |
| PERIAPT WORTH | 2 | 2 | 2 | 0.06 | +180 | +89.9 |
| BOMBING RUN | 1 | 1 | 1 | 0.03 | +31 | +30.9 |
| CATCH ODDS | 1 | 1 | 1 | 0.03 | -115 | -115.3 |
| CONTINUE AHEAD WEIGHED | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| DEFENSIVE ARMY | 15 | 15 | 1 | 0.03 | -51 | -50.9 |
| DEFENSIVE FLOOR | 5 | 5 | 1 | 0.03 | +556 | +556.5 |
| EDGE GIVE GROUND | 13 | 13 | 1 | 0.03 | +28 | +27.5 |
| MOVE SPELL IN RANGE | 6 | 4 | 1 | 0.03 | +4 | +3.9 |
| REDIRECT BY WHAT IT STOPS | 27 | 27 | 1 | 0.03 | +14 | +13.5 |
| THREAT AT FULL SIZE | 312 | 312 | 1 | 0.03 | +0 | +0.0 |
| TWO OR MORE ARRIVE | 21 | 21 | 1 | 0.03 | +5 | +5.1 |
| WAR ENGINE CHARGES | 2 | 2 | 1 | 0.03 | +46 | +45.5 |
| ALREADY CARRIED | 2 | not checked | - | - | - | - |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 1 | 1 | 0 | 0.00 | - | - |
| CARRIES OUT COUNTER | 2 | 2 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 35 | trace | - | - | - | - |
| CATCH FLIERS | 2 | not checked | - | - | - | - |
| CHAMPION TAKES THE CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| CHARIOT NO STATIC JOB | 1 | 1 | 0 | 0.00 | - | - |
| CHARIOT WIZARD CAREFUL | 1 | 1 | 0 | 0.00 | - | - |
| CHEAP HELPER | 6 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 31 | not checked | - | - | - | - |
| ENGINEER BY LORE | 2 | 2 | 0 | 0.00 | - | - |
| FIGHT LIFT | 1 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 356 | not checked | - | - | - | - |
| GIVES UP | 5 | 4 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 2 | 2 | 0 | 0.00 | - | - |
| HELPER ALREADY ASKED | 2 | not checked | - | - | - | - |
| HELPER UNSEEN | 18 | 17 | 0 | 0.00 | - | - |
| HILL BY ITS CHANCE | 8 | 8 | 0 | 0.00 | - | - |
| HUNT DROPPED | 3 | trace | - | - | - | - |
| HUNT RESULT | 10 | trace | - | - | - | - |
| HUNT THE GUNS | 10 | trace | - | - | - | - |
| KEEPS ITS PREY | 5 | 5 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 36 | not checked | - | - | - | - |
| LURE BY WHAT IT DRAWS | 3 | 3 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 2 | trace | - | - | - | - |
| MARCH OVER CASTS | 22 | 22 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 13 | 13 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 15 | trace | - | - | - | - |
| MOVE SPELL SPOT | 17 | not checked | - | - | - | - |
| NOT NEEDED | 27 | 27 | 0 | 0.00 | - | - |
| NOT TURNED | 370 | 370 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 34 | not checked | - | - | - | - |
| OPENS A LANE | 9 | 6 | 0 | 0.00 | - | - |
| PLAN RESULT | 2726 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 18 | 18 | 0 | 0.00 | - | - |
| SCOUT SPOT | 23 | 23 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 10 | 10 | 0 | 0.00 | - | - |
| SECOND HUNTER | 1 | 1 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 15 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 17 | not checked | - | - | - | - |
| SET-UP MISSED | 1 | trace | - | - | - | - |
| SHOOTER COUNTED ONCE | 2 | 2 | 0 | 0.00 | - | - |
| SHOT OPTIONS | 918 | 918 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 19 | not checked | - | - | - | - |
| SPELL WORTH | 116 | not checked | - | - | - | - |
| STABLE ROLE | 799 | 796 | 0 | 0.00 | - | - |
| STOPS | 4 | 4 | 0 | 0.00 | - | - |
| TURN WORTH | 41 | 41 | 0 | 0.00 | - | - |

### Off best figure: sp-h2h-mine-89601ea-p1

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 13.28 | 13.28 | 53.7 |
| FALLBACK | gate | 0.67 | 0.75 | 42.1 |
| CHARGE NOW FIRST | rule | 0.61 | 0.64 | 102.0 |
| TURN GATE | gate | 0.42 | 0.61 | 31.2 |
| KEEPS THE TARGET | rule | 0.44 | - | 106.0 |
| WAR ENGINE JOBS | rule | 0.25 | 0.19 | 78.5 |
| LONE CHARACTER SAFE SPOT | gate | 0.14 | 0.25 | 90.3 |
| SUPPORT REQUEST | gate | 0.14 | 0.14 | 128.5 |
| PIVOT GUARDS FLANK | rule | 0.14 | 0.11 | 12.3 |
| AFTERMATH BAND | gate | 0.11 | 0.08 | 2.2 |
| CHARGE NOW WEIGHED | rule | - | 0.17 | 33.6 |
| PATHS CROSS | rule | 0.08 | 0.08 | 28.3 |
| PURSUES BIG PREY | rule | 0.06 | 0.11 | 41.7 |
| SUPPORT NARROWED | rule | 0.06 | 0.11 | 15.5 |
| FIRE PLAN | rule | 0.14 | - | 122.7 |
| BEST PRIZE | rule | 0.08 | 0.03 | 211.0 |
| BIG CHARACTER SAFETY | rule | 0.06 | 0.06 | 12.1 |
| CANNON PLANNED TARGET | rule | - | 0.11 | 108.7 |
| SURE CHARGE BEATS ADVANCE | rule | 0.06 | 0.06 | 164.7 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.08 | - | 91.2 |
| CARRIES OUT SET-UP | rule | 0.03 | 0.06 | 45.8 |
| MARCH ODDS | rule | 0.06 | 0.03 | 15.3 |
| CHAFF PASSED | rule | - | 0.06 | 4.2 |
| FIGHT ORDER BAND | gate | 0.06 | - | 1.4 |
| LONE WIZARD HOLDS BACK | rule | - | 0.06 | 116.5 |
| REDIRECT WEIGHED | rule | 0.03 | 0.03 | 19.4 |
| STOPS SHORT OF THE FLANK | rule | 0.03 | 0.03 | 10.5 |
| THROUGH LINE OF FIRE | rule | 0.03 | 0.03 | 37.2 |
| CATCH ODDS | rule | 0.03 | - | 115.3 |
| DEFENSIVE ARMY | rule | 0.03 | - | 50.9 |
| FACES THE THREAT | rule | - | 0.03 | 16.9 |
| LONG SHOT | rule | 0.03 | - | 9.6 |
| MOVE AND CAST | rule | - | 0.03 | 13.2 |
| NO REASON | gate | 0.03 | - | 162.3 |
| RULE SWITCHED OFF | gate | - | 0.03 | 1.5 |
| SAFER THAN THE JOB | rule | 0.03 | - | 10.3 |
| STANDS TO CAST | rule | 0.03 | - | 10.0 |
| WHO HITS BACK | rule | 0.03 | - | 2.2 |

### Plans: sp-h2h-mine-89601ea-p1

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 11.3 | 19% | 478 | 316 | 66% |
| Mine | charge | 3.4 | 56% | 355 | 272 | 77% |
| Mine | close in | 4.0 | 26% | 258 | 103 | 40% |
| Mine | hold | 4.6 | 40% | 303 | 0 | 0% |
| Mine | join | 0.7 | 96% | 24 | 0 | 0% |
| Mine | shoot | 10.2 | 65% | 715 | 787 | 110% |
| Mine | support | 3.8 | 87% | 28 | 0 | 0% |
| Opponent | advance | 13.2 | 17% | 417 | 371 | 89% |
| Opponent | charge | 4.0 | 61% | 453 | 371 | 82% |
| Opponent | close in | 5.8 | 22% | 483 | 129 | 27% |
| Opponent | hold | 4.3 | 44% | 307 | 0 | 0% |
| Opponent | join | 1.2 | 93% | 50 | 0 | 0% |
| Opponent | shoot | 4.2 | 53% | 82 | 193 | 234% |
| Opponent | support | 5.1 | 87% | 47 | 0 | 0% |

### Packages: hunt the guns, sp-h2h-mine-89601ea-p1

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.1 | 5 | 0 | 20% | 40% | 0% | 2.0 | 315 | 116 | 40% | 14 |
| Opponent | 0.1 | 5 | 0 | 0% | 20% | 0% | 2.0 | 334 | 42 | 20% | 105 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.5 | 3 | 0 | 33% | 67% | 0% | 2.0 | 314 | 194 | 67% | 0 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Dwarfen Mountain Holds | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 430 | 0 | 0% | 48 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 158 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 87 |
| High Elf Realms | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 206 | 0 | 0% | 83 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 175 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 36 |
| Tomb Kings of Khemri | 0.5 | 3 | 0 | 0% | 33% | 0% | 2.0 | 265 | 69 | 33% | 44 |
| Vampire Counts | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 30 |
| Warriors of Chaos | 0.1 | 1 | 0 | 0% | 0% | 0% | - | 546 | 0 | 0% | 74 |
| Wood Elf Realms | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 329 | 0 | 0% | 95 |

### Battle groups: sp-h2h-mine-89601ea-p1

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 10.0 | 25% | 45% | 5% | 0% | 38% | 7% | 6% | 49% | 0% |
| Mine | REDIRECT COUNTER | 2.2 | 29% | 61% | 0% | - | 26% | 4% | 4% | 65% | 0% |
| Opponent | COUNTER-CHARGE COVER | 6.8 | 17% | 76% | 22% | 44% | 56% | 3% | 6% | 34% | 0% |
| Opponent | REDIRECT COUNTER | 3.7 | 27% | 67% | 22% | 0% | 21% | 0% | 7% | 71% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: sp-h2h-mine-89601ea-p1

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 3 | 0 (3) | 0 | 0 | 81 | 67% | 5.0 | 0 (1) | - | 0 (1) | 0 (1) | 0 (1) |
| Mine | Chaff | 36 | 15 (36) | 12 | 3 | 61 | 39% | 2.4 | 33 (15) | 9 (10) | 0 (11) | 19 (22) | 9 (14) |
| Mine | Character | 123 | 51 (123) | 51 | 0 | 34 | 16% | 2.3 | 63 (33) | 54 (64) | 0 (8) | 55 (55) | 55 (50) |
| Mine | Clean-up | 26 | 68 (26) | 34 | 34 | 35 | 31% | 3.0 | 71 (10) | 80 (12) | 0 (4) | 76 (13) | 62 (13) |
| Mine | Fast | 4 | 35 (4) | 35 | 0 | 47 | 0% | 1.5 | 67 (1) | 0 (2) | 0 (1) | 35 (4) | - |
| Mine | Fast Hammer | 40 | 29 (40) | 15 | 14 | 41 | 28% | 2.4 | 50 (18) | 16 (11) | 3 (11) | 34 (29) | 19 (11) |
| Mine | Fragile | 5 | 0 (5) | 0 | 0 | 40 | 0% | 2.0 | - | 0 (4) | 0 (1) | 0 (1) | 0 (4) |
| Mine | Hammer | 56 | 32 (56) | 17 | 15 | 39 | 11% | 2.6 | 31 (11) | 33 (37) | 31 (8) | 29 (34) | 36 (22) |
| Mine | Holder | 26 | 108 (26) | 15 | 93 | 20 | 31% | 3.8 | 99 (8) | 102 (11) | 135 (7) | 133 (13) | 84 (13) |
| Mine | Shooter | 45 | 91 (45) | 27 | 64 | 37 | 2% | 1.7 | 68 (5) | 91 (32) | 134 (7) | 117 (24) | 68 (20) |
| Mine | Support | 5 | 0 (5) | 0 | 0 | 42 | 80% | 2.0 | - | 0 (2) | - | 0 (2) | - |
| Mine | War machine | 56 | 58 (56) | 58 | 0 | 26 | 2% | 1.4 | 86 (14) | 32 (37) | 173 (5) | 97 (11) | 47 (45) |
| Mine | Wizard | 23 | 42 (23) | 42 | 0 | 47 | 17% | 2.2 | 40 (6) | 90 (8) | 9 (3) | 172 (2) | 25 (15) |
| Opponent | Blocker | 1 | 94 (1) | 94 | 0 | 0 | 0% | 6.0 | - | 94 (1) | - | - | 94 (1) |
| Opponent | Chaff | 68 | 66 (68) | 15 | 50 | 52 | 37% | 2.8 | 83 (30) | 37 (16) | 67 (22) | 84 (50) | 12 (18) |
| Opponent | Character | 113 | 46 (113) | 45 | 1 | 34 | 27% | 2.4 | 63 (36) | 43 (57) | 16 (6) | 48 (66) | 55 (33) |
| Opponent | Clean-up | 18 | 34 (18) | 23 | 11 | 45 | 44% | 3.0 | 12 (5) | 40 (10) | 51 (3) | 37 (11) | 29 (7) |
| Opponent | Early | 1 | 144 (1) | 144 | 0 | 0 | 0% | 3.0 | - | - | 144 (1) | 144 (1) | - |
| Opponent | Fast Hammer | 53 | 57 (53) | 38 | 19 | 56 | 30% | 2.5 | 65 (20) | 61 (18) | 41 (15) | 50 (37) | 72 (16) |
| Opponent | Fragile | 10 | 84 (10) | 84 | 0 | 57 | 50% | 1.6 | 259 (3) | 0 (2) | 31 (5) | 84 (10) | - |
| Opponent | Hammer | 63 | 28 (63) | 20 | 9 | 48 | 21% | 2.6 | 6 (16) | 24 (40) | 141 (7) | 21 (39) | 44 (24) |
| Opponent | Holder | 40 | 74 (40) | 11 | 63 | 23 | 32% | 3.7 | 19 (8) | 104 (21) | 46 (9) | 133 (18) | 29 (20) |
| Opponent | Shooter | 32 | 58 (32) | 11 | 47 | 41 | 3% | 1.3 | 73 (8) | 56 (18) | 46 (6) | 57 (17) | 59 (15) |
| Opponent | Support | 2 | 0 (2) | 0 | 0 | 0 | 100% | - | 0 (1) | 0 (1) | - | - | 0 (2) |
| Opponent | War machine | 13 | 34 (13) | 34 | 0 | 26 | 23% | 1.0 | 12 (5) | 0 (5) | 139 (3) | 38 (3) | 32 (10) |
| Opponent | Wizard | 24 | 14 (24) | 14 | 0 | 38 | 8% | 2.0 | 11 (10) | 27 (8) | 0 (2) | 29 (10) | 0 (10) |

### Charged fights: sp-h2h-mine-89601ea-p1

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 5 | 286 | 81 | 1.8 | 1.6 | 45 | 19 | +26 | 1 of 9 | 6 of 9 | +60 | -2 |
| Mine | Chaos Dwarfs | 3 | 147 | 511 | 3.7 | 1.1 | 139 | 0 | +139 | 6 of 11 | 9 of 11 | +0 | +153 |
| Mine | Dwarfen Mountain Holds | 4 | 421 | 10 | 1.5 | 1.5 | 7 | 71 | -64 | 3 of 6 | 4 of 6 | +0 | -97 |
| Mine | Empire of Man | 5 | 316 | 31 | 1.0 | 1.2 | 31 | 76 | -45 | 0 of 5 | 5 of 5 | +83 | -78 |
| Mine | Grand Cathay | 4 | 784 | 344 | 4.2 | 1.1 | 81 | 0 | +81 | 7 of 17 | 11 of 17 | +0 | +86 |
| Mine | High Elf Realms | 4 | 334 | 292 | 2.5 | 1.1 | 117 | 59 | +58 | 5 of 10 | 7 of 10 | +156 | +47 |
| Mine | Kingdom of Bretonnia | 1 | 0 | 1291 | 5.0 | 1.0 | 258 | 0 | +258 | 4 of 5 | 5 of 5 | - | +258 |
| Mine | Lizardmen | 1 | 0 | 315 | 5.0 | 1.2 | 63 | 63 | -0 | 3 of 5 | 3 of 5 | +0 | -0 |
| Mine | Ogre Kingdoms | 1 | 265 | 126 | 5.0 | 1.0 | 25 | 26 | -1 | 0 of 5 | 2 of 5 | - | -1 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 951 | 5.0 | 1.0 | 190 | 64 | +126 | 3 of 5 | 4 of 5 | - | +126 |
| Mine | Skaven | 2 | 25 | 93 | 2.5 | 1.0 | 37 | 50 | -13 | 2 of 5 | 3 of 5 | - | -13 |
| Mine | Tomb Kings of Khemri | 2 | 0 | 1093 | 4.5 | 1.1 | 243 | 7 | +236 | 2 of 9 | 7 of 9 | +144 | +247 |
| Mine | Vampire Counts | 2 | 0 | 157 | 6.5 | 1.2 | 24 | 18 | +6 | 5 of 13 | 8 of 13 | +105 | -23 |
| Mine | Warriors of Chaos | 1 | 0 | 307 | 4.0 | 1.0 | 77 | 0 | +77 | 1 of 4 | 3 of 4 | - | +77 |
| **Mine** | all armies | 36 | 276 | 288 | 3.0 | 1.2 | 95 | 26 | +69 | 42 of 109 | 77 of 109 | +63 | +70 |
| Opponent | Beastmen Brayherds | 1 | 0 | 130 | 5.0 | 1.2 | 26 | 78 | -52 | 4 of 5 | 0 of 5 | -137 | -31 |
| Opponent | Dwarfen Mountain Holds | 1 | 112 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 0 of 1 | 0 of 1 | - | +0 |
| Opponent | Empire of Man | 1 | 65 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Grand Cathay | 1 | 175 | 508 | 5.0 | 1.8 | 102 | 0 | +102 | 2 of 5 | 4 of 5 | +164 | +60 |
| Opponent | High Elf Realms | 2 | 148 | 718 | 3.0 | 1.2 | 239 | 123 | +117 | 5 of 6 | 2 of 6 | +226 | +95 |
| Opponent | Lizardmen | 1 | 281 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Ogre Kingdoms | 2 | 96 | 446 | 5.0 | 1.5 | 89 | 0 | +89 | 3 of 10 | 8 of 10 | +61 | +108 |
| Opponent | Orc & Goblin Tribes | 2 | 0 | 428 | 3.5 | 1.0 | 122 | 274 | -152 | 2 of 7 | 6 of 7 | - | -152 |
| Opponent | Skaven | 2 | 63 | 0 | 1.5 | 1.0 | 0 | 37 | -37 | 2 of 3 | 2 of 3 | - | -37 |
| Opponent | Tomb Kings of Khemri | 4 | 85 | 1070 | 5.2 | 1.2 | 204 | 9 | +195 | 10 of 21 | 20 of 21 | +187 | +197 |
| Opponent | Vampire Counts | 6 | 0 | 516 | 3.5 | 1.0 | 148 | 33 | +114 | 11 of 21 | 11 of 21 | -50 | +122 |
| Opponent | Warriors of Chaos | 7 | 7 | 349 | 2.0 | 1.3 | 174 | 8 | +166 | 7 of 14 | 9 of 14 | +178 | +162 |
| Opponent | Wood Elf Realms | 6 | 74 | 316 | 4.5 | 1.3 | 70 | 18 | +52 | 10 of 27 | 15 of 27 | +89 | +36 |
| **Opponent** | all armies | 36 | 58 | 432 | 3.3 | 1.2 | 129 | 39 | +91 | 56 of 120 | 77 of 120 | +114 | +84 |

### Effective charges: sp-h2h-mine-89601ea-p1

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 9 | 0 | 1 (net -85) | 2 (net +92) | 2 (net +47) | 2 (net +20) | 1 (net +0) | 1 | 25% (2 of 8) |
| Mine | Chaos Dwarfs | 11 | 1 (net +118) | 0 | 0 | 1 (net +0) | 0 | 7 (net +116) | 2 | 0% (0 of 9) |
| Mine | Dwarfen Mountain Holds | 6 | 2 (net -214) | 0 | 0 | 1 (net +0) | 0 | 2 (net +20) | 1 | 0% (0 of 5) |
| Mine | Empire of Man | 5 | 1 (net -380) | 0 | 1 (net +0) | 0 | 2 (net +76) | 1 (net +0) | 0 | 20% (1 of 5) |
| Mine | Grand Cathay | 17 | 2 (net +196) | 0 | 4 (net +38) | 3 (net +0) | 1 (net +60) | 7 (net +111) | 0 | 24% (4 of 17) |
| Mine | High Elf Realms | 10 | 4 (net +171) | 0 | 1 (net +0) | 1 (net +45) | 1 (net +0) | 3 (net -49) | 0 | 10% (1 of 10) |
| Mine | Kingdom of Bretonnia | 5 | 1 (net +268) | 0 | 3 (net +148) | 1 (net +580) | 0 | 0 | 0 | 60% (3 of 5) |
| Mine | Lizardmen | 5 | 1 (net -175) | 0 | 0 | 0 | 1 (net +0) | 1 (net +255) | 2 | 0% (0 of 3) |
| Mine | Ogre Kingdoms | 5 | 0 | 0 | 0 | 1 (net +66) | 0 | 2 (net +10) | 2 | 0% (0 of 3) |
| Mine | Skaven | 5 | 2 (net -105) | 0 | 1 (net +0) | 0 | 0 | 2 (net +72) | 0 | 20% (1 of 5) |
| Mine | Tomb Kings of Khemri | 9 | 0 | 0 | 4 (net +328) | 1 (net +116) | 0 | 4 (net +172) | 0 | 44% (4 of 9) |
| Mine | Vampire Counts | 13 | 5 (net -9) | 0 | 1 (net +170) | 4 (net +0) | 1 (net +144) | 2 (net -93) | 0 | 8% (1 of 13) |
| Mine | Warriors of Chaos | 4 | 0 | 0 | 0 | 1 (net +0) | 1 (net +91) | 1 (net +107) | 1 | 0% (0 of 3) |
| Opponent | Beastmen Brayherds | 5 | 1 (net -137) | 0 | 0 | 2 (net -128) | 0 | 2 (net +65) | 0 | 0% (0 of 5) |
| Opponent | Dwarfen Mountain Holds | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +0) | 0 | 0% (0 of 1) |
| Opponent | Grand Cathay | 5 | 0 | 0 | 0 | 1 (net +0) | 1 (net +328) | 2 (net +60) | 1 | 0% (0 of 4) |
| Opponent | High Elf Realms | 6 | 3 (net +208) | 0 | 0 | 0 | 0 | 2 (net +113) | 1 | 0% (0 of 5) |
| Opponent | Ogre Kingdoms | 10 | 0 | 0 | 3 (net +162) | 1 (net +0) | 0 | 4 (net +59) | 2 | 38% (3 of 8) |
| Opponent | Orc & Goblin Tribes | 7 | 1 (net +583) | 0 | 0 | 1 (net +110) | 1 (net -1190) | 0 | 4 | 0% (0 of 3) |
| Opponent | Skaven | 3 | 0 | 0 | 0 | 2 (net -56) | 0 | 1 (net +0) | 0 | 0% (0 of 3) |
| Opponent | Tomb Kings of Khemri | 21 | 1 (net -195) | 1 (net +0) | 3 (net +155) | 4 (net +276) | 1 (net +185) | 7 (net +301) | 4 | 18% (3 of 17) |
| Opponent | Vampire Counts | 21 | 3 (net -31) | 0 | 5 (net +106) | 6 (net +140) | 0 | 5 (net +58) | 2 | 26% (5 of 19) |
| Opponent | Warriors of Chaos | 14 | 3 (net +166) | 0 | 2 (net +147) | 3 (net +293) | 0 | 5 (net +101) | 1 | 15% (2 of 13) |
| Opponent | Wood Elf Realms | 27 | 4 (net -58) | 1 (net -27) | 4 (net +84) | 1 (net +0) | 6 (net +87) | 7 (net +70) | 4 | 17% (4 of 23) |

### Charged fights, damage counted: sp-h2h-mine-89601ea-p1

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 19 | 260 | 283 | +12 | 94 | 75 | +19 | +7.2 |
| Mine | 50-54% | 1 | 52 | 251 | -85 | 188 | 111 | +77 | +148.6 |
| Mine | Effective (55-75%) | 17 | 255 | 215 | +133 | 153 | 22 | +132 | +51.6 |
| Mine | 76-89% | 16 | 216 | 208 | +56 | 102 | 46 | +56 | +25.8 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 33 | 269 | 171 | +76 | 127 | 40 | +87 | +32.4 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 9 | 352 | 86 | +54 | 65 | 16 | +50 | +14.1 |
| Mine | No odds | 14 | 253 | 174 | +84 | 129 | 44 | +84 | +33.4 |
| Mine | All fights | 109 | 260 | 197 | +69 | 117 | 43 | +74 | +28.4 |
| Opponent | Long shot (under 50%) | 16 | 221 | 308 | +65 | 172 | 122 | +50 | +22.5 |
| Opponent | 50-54% | 2 | 483 | 364 | -14 | 46 | 14 | +33 | +6.8 |
| Opponent | Effective (55-75%) | 17 | 240 | 162 | +124 | 147 | 49 | +98 | +40.7 |
| Opponent | 76-89% | 21 | 313 | 237 | +122 | 162 | 64 | +99 | +31.5 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 36 | 276 | 209 | +114 | 149 | 23 | +126 | +45.6 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 9 | 567 | 116 | -17 | 133 | 144 | -12 | -2.0 |
| Opponent | No odds | 19 | 215 | 142 | +65 | 134 | 76 | +58 | +27.0 |
| Opponent | All fights | 120 | 286 | 205 | +91 | 149 | 64 | +84 | +29.5 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| sp-h2h-mine-89601ea-p1 | move | 428 | 107 (25%) | 76 (18%) | 57 (13%) | 264 (62%) |
| sp-h2h-mine-89601ea-p1 | objective | 353 | 64 (18%) | 40 (11%) | 42 (12%) | 247 (70%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0102, L0118, L0135, L2531, L2730 |
| Charmed Shield | Opponent | L0524, L1224, L1527, L1625, L2025, L2127, L2934 |
| Clockwork Compass | Mine | L1224 |
| Clockwork Compass | Opponent | L0612 |
| Elixir of Power | Mine | L1114, L1131, L1923 |
| Elixir of Power | Opponent | L0319, L1319 |
| Fistful of Laurels | Mine | L1823 |
| Fistful of Laurels | Opponent | L0118, L0218 |
| Horn of the Wild Hunt | Opponent | L0733 |
| Invocation of Nehek | Mine | L2531, L2730 |
| Invocation of Nehek | Opponent | L0524, L1224, L1527, L1625, L2025, L2127 |
| Opal Amulet | Mine | L1431 |
| Opal Amulet | Opponent | L1114 |
| Periapt of Soul Exchange | Mine | L2025, L2127 |
| Periapt of Soul Exchange | Opponent | L0421, L1021 |
| Ring of Doom | Mine | L0218, L0235, L1114, L1131, L1224, L1527 |
| Ring of Doom | Opponent | L0102, L0612, L0733, L1131, L1431, L2231, L2531 |
| Ring of Jet | Mine | L1021, L1114, L1131, L1224 |
| Ring of Jet | Opponent | L0612 |
| Standard of the Fell Warrior | Mine | L1319, L1335 |
| Standard of the Fell Warrior | Opponent | L0913 |
| Storm Daemon (Renegade 2.0) | Mine | L2127 |
| Storm Daemon (Renegade 2.0) | Opponent | L0421, L1021 |
| Twice-Blessed Armour | Mine | L0717, L0733, L1021 |
| Witch Hunter's Ward | Mine | L0717, L0733, L0823 |
| Witch Hunter's Ward | Opponent | L0508 |

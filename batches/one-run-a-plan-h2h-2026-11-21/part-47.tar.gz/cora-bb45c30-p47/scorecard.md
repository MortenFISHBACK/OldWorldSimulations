# Doctrine scorecard: cora-bb45c30-p47

### Scorecard: cora-bb45c30-p47

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L2131 | 1 | 1 | Mine | yes | 12 | - | 1 | 1 | 0 | 0 | 0 | 555 |
| L2131 | 1 | 1 | Opponent | no | 0 | - | 1 | 0 | 2 | 0 | 0 | 170 |
| L2235 | 3 | 1 | Mine | no | 4 | 2 | 3 | 0 | 0 | 0 | 0 | 0 |
| L2235 | 3 | 1 | Opponent | no | 4 | 3 | 1 | 1 | 0 | 0 | 0 | 0 |
| L2429 | 5 | 1 | Mine | yes | - | - | 1 | 3 | 0 | 0 | 0 | 0 |
| L2429 | 5 | 1 | Opponent | yes | - | 3 | 7 | 4 | 1 | 0 | 0 | 0 |
| **Average** | | | Mine | 67% | 8.0 | 2.0 | 1.7 | 1.3 | 0.0 | 0.0 | 0.0 | 185.0 |
| **Average** | | | Opponent | 33% | 2.0 | 3.0 | 3.0 | 1.7 | 1.0 | 0.0 | 0.0 | 56.7 |

### KPIs: cora-bb45c30-p47

Rules off - Opponent only: ONE RUN A PLAN.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 12) | 0% (0 of 16) | 0% (0 of 28) |
| Winner chose to follow up after the loser gave ground |  | 43% (3 of 7); on the table 86% | 100% (1 of 1); on the table 100% | 50% (4 of 8); on the table 88% |
| Winner chose to pursue after the loser fell back in good order |  | 50% (1 of 2); on the table 50% | - | 50% (1 of 2); on the table 50% |
| Winner chose to pursue after the loser fled |  | 0% (0 of 1); on the table 0% | 100% (2 of 2); on the table 100% | 67% (2 of 3); on the table 67% |
| Winner chose to follow up or pursue (all three) |  | 40% (4 of 10); on the table 70% | 100% (3 of 3); on the table 100% | 54% (7 of 13); on the table 77% |
| Magic missiles tried each own turn | 50%+ | 8% (1 of 12) | - | 8% (1 of 12) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 8% (1 of 12) | - | 8% (1 of 12) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 50% (6 of 12) | 38% (5 of 13) | 44% (11 of 25) |
| Points that never fought | lower | 52% (3113 of 5997) | 34% (2031 of 5999) | 43% (5144 of 11996) |
|   infantry points that never fought | lower | 73% (1218 of 1675) | 54% (701 of 1306) | 64% (1919 of 2981) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 57% (12 of 21) | 65% (20 of 31) | 62% (32 of 52) |
| Bound items with a magic missile used (at least once a game) |  | 100% (1 of 1); 1.0 uses a game | 100% (2 of 2); 1.3 uses a game | 100% (3 of 3); 1.2 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 100% (1 of 1); 0.3 uses a game | 0.0 uses a game | 100% (1 of 1); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 64% (3103 of 4866) | 52% (3076 of 5884) | 57% (6179 of 10750) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 2.0 (55%) | - | 2.0 (55%) |
| MARCHED: its unit marched | 1.7 (45%) | - | 1.7 (45%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 5.0 | 3.7 | 1.7 | 0.3 | 1.7 |
| not cast | 5.0 | 4.3 | 0.3 | 3.7 | 22.3 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (1%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.3 (7%) | 4.3 (100%) | 0.0 (0%) | 2.0 (55%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.7 (45%) | 0.0 (0%) |
| GONE: slain | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 3.7 (16%) |
| HELD BACK: the computer weighed it and chose not to cast it | 4.7 (93%) | 0.0 (0%) | 0.3 (100%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 18.3 (82%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.0 a game | 1.7 a game | 0.8 a game |
| stood (cast and not dispelled) | - | 60% (3 of 5) | 60% (3 of 5) |
| the unit moved after it | - | 33% (1 of 3) | 33% (1 of 3) |
| it charged on its next turn | - | 0% (0 of 3) | 0% (0 of 3) |
| the enemy charged it first | - | 0% (0 of 3) | 0% (0 of 3) |
| it fought by the end of its next turn | - | 0% (0 of 3) | 0% (0 of 3) |
| it moved out of a charge the enemy had planned (not charged first) | - | 0% (0 of 3) | 0% (0 of 3) |
| none of these (no charge, no fight, no charge escaped) | - | 100% (3 of 3) | 100% (3 of 3) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 75% (47 of 63) | 54% (21 of 39) | 67% (68 of 102) |
|   cavalry | 100% (8 of 8) | 55% (12 of 22) | 67% (20 of 30) |
|   character | 0% (0 of 4) | 25% (2 of 8) | 17% (2 of 12) |
|   chariot | 83% (10 of 12) | - | 83% (10 of 12) |
|   infantry | 74% (29 of 39) | 78% (7 of 9) | 75% (36 of 48) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 0.0 (0%) | 2.3 (39%) | 2.3 (21%) |
| CHARGED: it charged | 0.7 (12%) | 1.7 (28%) | 2.3 (21%) |
| IN COMBAT: it fought this turn or the last | 0.7 (12%) | 0.3 (6%) | 1.0 (9%) |
| NO TARGET IN RANGE | 3.3 (62%) | 1.0 (17%) | 4.3 (38%) |
| ONLY IN COMBAT: the only targets were in combat | 0.3 (6%) | 0.0 (0%) | 0.3 (3%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.3 (6%) | 0.7 (11%) | 1.0 (9%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 10.3 | 2.7 | 77% | 7.2 pts | 74 pts |
| character | 0.7 | 0.0 | 100% | 0.0 pts | 0 pts |
| chariot | 3.3 | 2.0 | 70% | 30.1 pts | 100 pts |
| infantry | 12.7 | 1.7 | 87% | 5.0 pts | 64 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 2.3 | 3.3 | 2.8 |
| Charges that made contact a game | 1.7 | 2.3 | 2.0 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.00 declared, 0.00 contact (2 units) | - | 0.00 declared, 0.00 contact (2 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 2.00 declared, 1.00 contact (1 units) | 2.00 declared, 1.00 contact (1 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.25 declared, 0.18 contact (28 units) | 0.33 declared, 0.25 contact (24 units) | 0.29 declared, 0.21 contact (52 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 50% (3 of 6) | 75% (3 of 4) | - | 60% (6 of 10) |
| Character in a unit | - | 100% (2 of 2) | 0% (0 of 1) | 67% (2 of 3) |
| Character on its own | 100% (7 of 7) | - | 43% (3 of 7) | 71% (10 of 14) |
| Chariot | 50% (1 of 2) | - | - | 50% (1 of 2) |
| Infantry | 64% (7 of 11) | 75% (3 of 4) | - | 67% (10 of 15) |
| Monster | 20% (1 of 5) | 0% (0 of 1) | - | 17% (1 of 6) |
| Monstrous | 100% (2 of 2) | - | - | 100% (2 of 2) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Skaven | 1 | 38% (3 of 8); on the table 75% | 17% (1 of 6) | 49% | 44% (4 of 9) | 100% (1 of 1); 3.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Tomb Kings of Khemri | 1 | 0% (0 of 1); on the table 0% | - | 53% | 40% (2 of 5) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 1 | 100% (1 of 1); on the table 100% | 0% (0 of 6) | 54% | 86% (6 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 2 | 100% (3 of 3); on the table 100% | - | 28% | 63% (12 of 19) | 100% (1 of 1); 1.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 1 | - | - | 46% | 67% (8 of 12) | 100% (1 of 1); 2.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (cora-bb45c30-p47, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 20% (1) | 80% (4) | 50% (5) |
| ...free all their last turn and able to turn (per game) | 0.33 | 1.33 | 1.67 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 1.00 | 1.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.33 | 0.33 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 1.33 | 1.33 |

### Quality by phase: cora-bb45c30-p47

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.7 | 3.7 |
| Strategy | Charge objectives carried out (made contact) | 50% (2 of 4) | 71% (5 of 7) |
| Strategy | Shoot objectives carried out (shot that target) | 36% (5 of 14) | 67% (6 of 9) |
| Strategy | Hexes on a unit its side charged or shot that turn | 0% (0 of 1) | 57% (4 of 7) |
| Strategy | Joined characters whose unit fought | 0% (0 of 3) | 50% (1 of 2) |
| Strategy | Lone characters that fought | 50% (4 of 8) | 86% (6 of 7) |
| Movement | Charges halted short of contact | 0.0 | 0.3 |
| Movement | Idle units | 1.3 | 1.7 |
| Movement | Points that never moved of their own | 185.0 | 56.7 |
| Movement | Fights charged into per game | 1.7 | 2.3 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 2 | 2 of 6, net +0 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 2 | 1 of 6, net +470 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 1 of 2, net +110 | 2 of 6, net +91 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 of 2, net +265 | 1 of 6, net +72 |
| Shooting | Shots by shooting units (incl. breath weapons) | 18.3 | 8.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 40% (22 of 55) | 48% (12 of 25) |
| Shooting | Points destroyed by shooting units | 38.7 | 65.0 |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | 0.3 | - |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 0% (0 of 1) | - |
| Magic | Wounds caused by magic missiles | 0.7 | 2.3 |
| Magic | Points destroyed by magic (all spells) | 0.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 4.3 / 0.3 / 0.7 / 0.0 | 0.0 / 2.3 / 0.3 / 0.0 |
| Combat | Points destroyed in combat | 407.3 | 476.3 |
| Combat | Points run down | 46.7 | 0.0 |
| Combat | Net points per charged fight, damage counted | +148 | +109 |
| Combat | Net per 100 charger points, damage counted | +53.9 | +34.9 |
| Combat | First round won (charged fights) | 100% | 86% |
| Combat | Net points per charged fight | +154 | +103 |
| Combat | Net points per supported fight / lone fight | - / +154 | - / +103 |
| Combat | Charged fights on a top-3 enemy unit | 0 of 5 | 2 of 7 |
| Game | Points lost | 526.7 | 534.3 |
| Game | VP from objectives | 983.3 | 360.0 |
| Game | Lone holders (player turns) | 8.0 | 2.0 |

- Mine won / drew / lost: 2 / 1 / 0 of 3 ended games (of 3); mean margin (Mine - Opponent) +581 VP
- The side that went first won 0 of 2 games with a winner
- Points traded per game (both sides' losses): 1061
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: cora-bb45c30-p47

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 2.0 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.7 | +165.4 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | 32.0 | +24.5 | 0.0 | 208.0 | 32.3 | +278.5 | 0.0 | 696.3 |
| BACKUP TARGETS | 0.3 | +0.3 | 0.0 | 0.0 | 0.3 | +0.2 | 0.0 | 0.0 |
| CAST JOB | 0.7 | +2.1 | 113.3 | 313.3 | - | - | - | - |
| CASTS AFTER FRIENDS | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | 1.0 | +38.6 | 0.0 | 20.0 | 1.3 | +5.9 | 0.0 | 0.0 |
| CHALLENGE BY POINTS | 0.3 | +0.0 | 0.0 | 24.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CHAMPION KNOWS CHALLENGE | - | - | - | - | 0.3 | -3.7 | 0.0 | 0.0 |
| CHARACTER GUNS | 2.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHARGE LOSSES | 7.0 | -264.3 | 0.0 | 0.0 | 25.0 | -1428.8 | 0.0 | 597.7 |
| CHARGE NOW FIRST | 1.7 | +0.0 | 159.0 | 65.0 | 0.7 | +0.0 | 44.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 11.7 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 38.7 |
| COMBAT PIVOT | 0.3 | +0.0 | 0.0 | 156.7 | 1.0 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | - | - | - | - | 1.7 | +85.2 | 0.0 | 0.0 |
| COVER ONCE | 8.7 | -535.7 | 0.0 | 178.3 | 13.3 | -711.6 | 0.0 | 263.0 |
| DENIED BY THE FIGHT | 0.3 | -2.9 | 46.7 | 0.0 | - | - | - | - |
| DEPLOY BY FIGURES | 7.7 | +9.0 | 0.0 | 0.0 | 7.7 | +16.7 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | - | - | - | - | 0.7 | -118.4 | 0.0 | 0.0 |
| EVASIVE BY THE ODDS | - | - | - | - | 5.0 | +1388.8 | 40.7 | 0.0 |
| EXACT ROUND | 1.3 | +7.9 | 135.7 | 0.0 | 1.0 | +13.1 | 354.0 | 0.0 |
| FACES THE THREAT | - | - | - | - | 0.3 | +0.0 | 0.0 | 65.0 |
| FALL BACK GOOD ORDER | 1.7 | +13.5 | 187.3 | 65.0 | 2.7 | +0.0 | 378.0 | 0.0 |
| FALLS SHORT | 7.7 | +111.4 | 0.0 | 20.0 | 17.0 | +210.5 | 0.0 | 416.7 |
| FEATURE BUFFS | - | - | - | - | 0.7 | +21.5 | 0.0 | 0.0 |
| FIGHT TO THE END | 0.7 | +18.6 | 65.0 | 0.0 | 0.3 | +5.2 | 0.0 | 0.0 |
| FIRE IN ORDER | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| FIVE ACTION | 103.0 | +6316.4 | 497.3 | 842.7 | 86.0 | +4495.5 | 1004.7 | 1364.7 |
| FLANK NOT WEIGHED | 3.3 | +0.0 | 0.0 | 0.0 | 10.3 | +0.0 | 0.0 | 366.0 |
| FOCUS FIRE | 0.3 | +27.9 | 0.0 | 0.0 | - | - | - | - |
| FOLLOW UP WEIGHED | 0.7 | +175.5 | 0.0 | 156.7 | 0.3 | +0.0 | 0.0 | 0.0 |
| FOUR ROUNDS | 2.3 | +136.0 | 224.0 | 65.0 | 3.0 | +155.1 | 398.0 | 0.0 |
| FREED FROM HIS FIGHT | 1.0 | +0.0 | 0.0 | 0.0 | 7.3 | +0.0 | 0.0 | 166.7 |
| GIVES UP | - | - | - | - | 0.3 | -1.6 | 0.0 | 0.0 |
| GOAL WALK | 3.3 | +127.2 | 0.0 | 0.0 | 14.3 | +1520.1 | 0.0 | 125.0 |
| GUN FIGURES | 2.0 | +0.5 | 86.7 | 43.3 | - | - | - | - |
| HARD STAY DROPPED | 2.3 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 46.7 |
| HE REFORMS ONCE FREED | - | - | - | - | 4.7 | +0.0 | 0.0 | 93.3 |
| HIS CHARGE BY HIS RUN | 5.7 | +0.0 | 0.0 | 0.0 | 13.0 | +0.0 | 0.0 | 240.7 |
| HIS CHARGE LIST | 11.3 | +0.0 | 0.0 | 0.0 | 8.0 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 2.3 | +0.0 | 0.0 | 0.0 | 4.7 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 4.0 | -33.0 | 0.0 | 40.0 | 6.7 | -62.7 | 0.0 | 36.7 |
| HIS ONE QUARTER | 2.0 | +0.0 | 0.0 | 70.0 | 8.7 | +0.0 | 0.0 | 152.7 |
| HIS OWN BEST MOVE | 9.0 | +0.0 | 0.0 | 40.0 | 7.7 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVE | 19.7 | +0.0 | 0.0 | 173.3 | 11.7 | +0.0 | 0.0 | 568.0 |
| HIS RANDOM MOVER COMES | 0.3 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 192.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 35.3 | +464.5 | 0.0 | 253.0 | 49.3 | +918.0 | 0.0 | 1138.7 |
| HIS SHOTS BY HIS RUN | 27.3 | +249.2 | 0.0 | 108.0 | 39.7 | +540.6 | 0.0 | 886.0 |
| HIS TURN DENIED | 0.7 | +4.5 | 83.3 | 0.0 | 0.3 | +0.3 | 24.0 | 0.0 |
| HIS TURN RUN | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 24.7 | +0.0 | 0.0 | 0.0 | 9.7 | +0.0 | 0.0 | 237.3 |
| HOLDER ASSIGNMENT | 14.7 | +1043.1 | 0.0 | 0.0 | 7.0 | +418.2 | 0.0 | 142.7 |
| HOLDS AMBUSHERS | 1.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 1.7 | -54.8 | 117.3 | 0.0 | 2.3 | -143.6 | 84.7 | 0.0 |
| HUNT IN PAIRS | 1.0 | +34.5 | 0.0 | 0.0 | - | - | - | - |
| IDLE COST | 5.0 | -88.9 | 0.0 | 0.0 | 13.3 | -158.9 | 0.0 | 330.3 |
| JOINT CHARGE NOW | - | - | - | - | 0.3 | -1.4 | 0.0 | 0.0 |
| JOINT KNOWS CHALLENGE | - | - | - | - | 0.3 | -3.5 | 0.0 | 0.0 |
| KEPT FROM ITS LAST STOP | 6.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 93.3 |
| LANE BY FIGURES | 0.3 | +16.4 | 0.0 | 0.0 | 0.3 | +0.7 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| LEGAL CHARGES ONLY | 10.3 | +0.0 | 160.0 | 531.7 | 6.0 | +0.0 | 286.7 | 259.0 |
| LONE WIZARD KEPT IN | 1.0 | +52.2 | 0.0 | 0.0 | - | - | - | - |
| LONG SHOT | 0.3 | +11.7 | 65.0 | 0.0 | - | - | - | - |
| LOST AFTER ESCAPE | 1.0 | +0.2 | 111.7 | 0.0 | 1.0 | -2.6 | 0.0 | 0.0 |
| LURE BY WHAT IT DRAWS | 0.3 | -19.7 | 0.0 | 20.0 | - | - | - | - |
| MAKE SURE TOGETHER | - | - | - | - | 1.0 | +26.7 | 0.0 | 86.7 |
| MANOEUVRE | 1.0 | -11.8 | 0.0 | 0.0 | 2.7 | +107.1 | 0.0 | 185.7 |
| MARCH AT ESCAPER | - | - | - | - | 0.7 | +5.1 | 0.0 | 0.0 |
| MARCH BY THE SUM | 1.0 | +67.9 | 0.0 | 156.7 | - | - | - | - |
| MARCH CHECK | - | - | - | - | 0.7 | +29.8 | 0.0 | 0.0 |
| MARCH OF THE TABLE | 0.3 | +26.8 | 0.0 | 156.7 | - | - | - | - |
| MARCH OVER CASTS | 1.0 | -36.7 | 0.0 | 156.7 | 1.0 | +411.6 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 2.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 2.0 | +37.1 | 0.0 | 156.7 | 2.0 | +60.5 | 0.0 | 125.3 |
| MEETS IN TIME | 5.3 | +188.6 | 0.0 | 0.0 | 3.7 | +115.9 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 2.3 | +18.5 | 0.0 | 0.0 | 2.3 | +20.7 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 4.0 | +19.7 | 0.0 | 156.7 | 3.0 | +21.0 | 0.0 | 0.0 |
| MOVE ORDER | 1.7 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 48.0 | 41.7 |
| MOVE SPELL OUT OF RANGE | - | - | - | - | 1.3 | -30.9 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 9.3 | +1334.5 | 0.0 | 40.0 | 8.0 | +639.8 | 0.0 | 193.3 |
| NEARER NOT NEEDED | 10.7 | +345.1 | 0.0 | 20.0 | 8.3 | +406.1 | 0.0 | 190.7 |
| NEXT CHARGE BY LIST | 6.0 | +912.4 | 0.0 | 0.0 | 6.3 | +359.4 | 0.0 | 154.7 |
| NO DOUBLE ROUNDS | 2.3 | -111.4 | 224.0 | 65.0 | 1.3 | -41.0 | 333.3 | 0.0 |
| NO LATE CUT | 2.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 93.3 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | - | - | - | - | 1.3 | +7.1 | 0.0 | 130.0 |
| NOT WORTH A CAST | 5.0 | -4.3 | 0.0 | 156.7 | - | - | - | - |
| OFF BEST | 5.0 | -78.9 | 0.0 | 0.0 | 6.0 | -210.1 | 0.0 | 99.0 |
| ONE CHECK AFTER THE LAST CHANGE | - | - | - | - | 0.7 | +0.0 | 0.0 | 41.7 |
| ONE FIGHT FORMULA | 5.0 | -117.7 | 0.0 | 156.7 | 6.0 | -97.3 | 0.0 | 116.0 |
| ONE OBJECTIVE FORMULA | 7.3 | +23.0 | 0.0 | 0.0 | 2.3 | +61.8 | 0.0 | 48.0 |
| ONE PROMISE A TARGET | 1.0 | -199.7 | 0.0 | 0.0 | - | - | - | - |
| ONE ROUTE | 2.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| OPENS UP | 0.3 | +5.7 | 36.7 | 0.0 | 0.7 | +6.9 | 60.7 | 0.0 |
| OVERRUNS AWAY | 1.3 | +18.1 | 125.0 | 65.0 | 0.7 | +4.2 | 64.7 | 0.0 |
| PATHS CROSS | 0.7 | +13.6 | 0.0 | 0.0 | 0.3 | +8.4 | 0.0 | 0.0 |
| PERIAPT WORTH | 0.3 | +40.5 | 0.0 | 0.0 | - | - | - | - |
| PIVOT GUARDS FLANK | - | - | - | - | 0.3 | -2.7 | 0.0 | 0.0 |
| PLAN RESULT | 49.3 | +386.1 | 195.0 | 858.0 | 43.0 | +415.6 | 339.3 | 827.0 |
| PROMISE BELOW ZERO | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| PROMISE BY ITS OWN SUM | 8.0 | -243.8 | 0.0 | 40.0 | 14.0 | -554.6 | 0.0 | 116.0 |
| PROMISE KNOWS THE FIGHT | 0.3 | +0.0 | 0.0 | 0.0 | 1.7 | -0.8 | 0.0 | 77.3 |
| PROMISE READS THE TABLE | 0.3 | -0.2 | 0.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | 28.7 | +2422.2 | 273.3 | 464.7 | 21.3 | +2224.7 | 354.0 | 228.0 |
| RANDOM MOVE BY FIGURES | 4.0 | +152.7 | 0.0 | 188.3 | 4.3 | +26.2 | 0.0 | 0.0 |
| REAL GROUND | 2.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| REDIRECT BY WHAT IT STOPS | 0.7 | +27.8 | 0.0 | 0.0 | - | - | - | - |
| REDIRECT COUNTER | 3.0 | +326.7 | 0.0 | 64.7 | 1.3 | +37.1 | 0.0 | 0.0 |
| REDIRECT FOR A FRIEND IN REACH | 3.7 | +35.1 | 0.0 | 80.7 | 1.0 | +0.0 | 0.0 | 0.0 |
| REFORMS TO MEET IT | 3.0 | -31.9 | 0.0 | 0.0 | 0.7 | -0.1 | 0.0 | 0.0 |
| RESERVE FALL BACK | 2.7 | +59.0 | 0.0 | 40.7 | 0.3 | +5.8 | 0.0 | 0.0 |
| RISK BY ARC | 2.3 | +18.3 | 224.0 | 65.0 | 2.0 | +41.9 | 221.3 | 0.0 |
| RISK ON THE WAY | 1.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 93.3 |
| ROUNDS AFTER TERROR | 1.0 | -15.3 | 83.3 | 0.0 | - | - | - | - |
| RUN DOWN | 1.7 | -11.2 | 190.0 | 65.0 | - | - | - | - |
| SCOUT SPOT | 0.7 | +0.4 | 0.0 | 0.0 | - | - | - | - |
| SCOUT WAITS | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 1.3 | -97.3 | 0.0 | 0.0 |
| SEARCH SPOT | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | -0.4 | 0.0 | 0.0 |
| SECOND LOOK | 0.3 | +7.7 | 34.0 | 0.0 | 0.7 | +11.5 | 0.0 | 0.0 |
| SET CREDITED ONCE | 2.3 | -52.7 | 0.0 | 0.0 | 0.7 | -10.6 | 0.0 | 0.0 |
| SET UP BY THE SET | 5.7 | +273.1 | 78.3 | 65.0 | 0.7 | +4.8 | 0.0 | 0.0 |
| SET UP TOGETHER | - | - | - | - | 1.0 | +26.7 | 0.0 | 86.7 |
| SHOOTERS IN TWO RANKS | 0.3 | +1.3 | 0.0 | 0.0 | 0.3 | +0.3 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 4.3 | +0.0 | 0.0 | 197.3 | 3.3 | +0.0 | 0.0 | 111.7 |
| SHOOTS FROM THE BEST SPOT | 3.0 | +149.8 | 36.7 | 81.3 | 2.7 | +26.9 | 86.7 | 0.0 |
| SHOT RISK POINTS | 11.3 | -181.0 | 0.0 | 88.0 | 22.0 | -344.3 | 0.0 | 473.0 |
| SHOTS AFTER THE MOVES | 2.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 16.3 | +221.8 | 0.0 | 108.0 | 7.7 | +79.3 | 0.0 | 166.7 |
| SPELL WORTH | 1.0 | +13.4 | 156.7 | 156.7 | - | - | - | - |
| SPELLS IN THE FIGHT | 0.3 | -3.2 | 65.0 | 0.0 | 0.7 | -26.0 | 313.3 | 0.0 |
| SPOT AS THE GAME MOVES | 6.7 | +0.0 | 0.0 | 20.0 | 10.0 | +0.0 | 0.0 | 201.0 |
| STAND AND SHOOT | 0.3 | -5.0 | 0.0 | 0.0 | - | - | - | - |
| STANDS FOR A REASON | 0.7 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 130.0 | 73.3 |
| STANDS STILL | 41.3 | +0.0 | 273.3 | 652.7 | 30.3 | +0.0 | 606.7 | 209.3 |
| STAY WORTH | 11.3 | +61.2 | 150.0 | 378.3 | 8.3 | -15.1 | 260.0 | 83.3 |
| STRIKE BY THE ODDS | 0.7 | +14.4 | 48.0 | 70.0 | 0.7 | +35.0 | 93.3 | 0.0 |
| STUCK PIVOT | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 3.3 | +117.1 | 0.0 | 20.0 | 8.7 | +559.3 | 0.0 | 472.0 |
| SUPPORT NARROWED | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 156.7 | 0.0 |
| SUPPORT WORKED OUT | 3.3 | +117.1 | 0.0 | 20.0 | 8.7 | +559.3 | 0.0 | 472.0 |
| SURE REACH TOGETHER | - | - | - | - | 1.0 | +4.2 | 0.0 | 65.0 |
| THE DEARER SUM KEEPS ITS PLAN | 2.0 | +0.0 | 0.0 | 21.7 | 2.3 | +0.0 | 0.0 | 41.7 |
| THE PROMISED MOVE | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE ROW IN ITS ORDER | 2.3 | +0.0 | 0.0 | 0.0 | 5.3 | +0.0 | 0.0 | 171.7 |
| THE ROW KEEPS ITS WAY | 2.3 | +0.0 | 0.0 | 21.7 | 3.0 | +0.0 | 0.0 | 75.7 |
| THE ROW READS HIS LAST RUN | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE STEP BACK IS MADE | 3.0 | +0.0 | 0.0 | 21.7 | 2.0 | +0.0 | 0.0 | 89.7 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 49.7 | +0.0 | 0.0 | 284.7 | 40.0 | +0.0 | 0.0 | 788.3 |
| TIED UP BY THE SUM | 2.0 | +192.7 | 159.0 | 65.0 | 0.3 | +42.3 | 20.0 | 0.0 |
| TIME ON OUR SIDE | 37.7 | +321.6 | 0.0 | 67.3 | 17.0 | +159.3 | 0.0 | 0.0 |
| TWO OR MORE ARRIVE | - | - | - | - | 0.3 | +2.7 | 0.0 | 48.0 |
| WAITS AGAIN | 1.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 116.0 |
| WALKS ON ITS ROUTE | - | - | - | - | 0.3 | -4.4 | 0.0 | 0.0 |
| WEAPON BY POINTS | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| WHAT THE JOINER ADDS | - | - | - | - | 1.3 | -9.5 | 313.3 | 0.0 |
| WHO FIGHTS | - | - | - | - | 0.3 | +6.6 | 156.7 | 0.0 |
| WHO HITS BACK | - | - | - | - | 0.7 | +10.7 | 0.0 | 0.0 |
| WHOLE FIGHT | - | - | - | - | 0.7 | -33.2 | 156.7 | 0.0 |
| WHOLE FIGHT DANGER | 2.3 | -204.1 | 0.0 | 0.0 | 5.3 | -920.9 | 0.0 | 275.3 |
| WHOLE FIGHT GAIN | - | - | - | - | 0.3 | +1.4 | 0.0 | 0.0 |
| WOUNDS ON THE RANKS | - | - | - | - | 4.0 | +115.8 | 0.0 | 48.0 |

### Rule changes: cora-bb45c30-p47

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 193 | 193 | 117 | 39.00 | +501 | +4.3 |
| HOLDER ASSIGNMENT | 65 | 65 | 61 | 20.33 | +3497 | +57.3 |
| LEGAL CHARGES ONLY | 49 | 49 | 49 | 16.33 | +0 | +0.0 |
| HIS SHOT LIST | 254 | 233 | 39 | 13.00 | +520 | +13.3 |
| HIS SHOTS BY HIS RUN | 201 | 190 | 38 | 12.67 | +358 | +9.4 |
| OFF BEST | 33 | 33 | 33 | 11.00 | -868 | -26.3 |
| FIVE ACTION | 567 | 538 | 27 | 9.00 | +1642 | +60.8 |
| PROMISE BY ITS OWN SUM | 66 | 66 | 26 | 8.67 | -2395 | -92.1 |
| THE TABLE AGAIN | 36 | 36 | 26 | 8.67 | +0 | +0.0 |
| MOVE TO CHARGE COMPUTED | 52 | 44 | 25 | 8.33 | +1628 | +65.1 |
| DEPLOY BY FIGURES | 46 | 46 | 23 | 7.67 | +275 | +12.0 |
| QUARTER ODDS | 150 | 148 | 20 | 6.67 | +1194 | +59.7 |
| HARD STAY DROPPED | 18 | 18 | 18 | 6.00 | +0 | +0.0 |
| TIME ON OUR SIDE | 164 | 146 | 18 | 6.00 | +42 | +2.4 |
| NEXT CHARGE BY LIST | 37 | 35 | 16 | 5.33 | +1411 | +88.2 |
| REDIRECT FOR A FRIEND IN REACH | 14 | 14 | 14 | 4.67 | +98 | +7.0 |
| ADVANCE LANE KEPT | 13 | 13 | 13 | 4.33 | +0 | +0.0 |
| SHOOTS FROM THE BEST SPOT | 17 | 17 | 13 | 4.33 | +288 | +22.1 |
| MOVE ORDER | 12 | 12 | 12 | 4.00 | +0 | +0.0 |
| SHOT RISK POINTS | 100 | 92 | 12 | 4.00 | +162 | +13.5 |
| MEETS IN TIME | 27 | 27 | 11 | 3.67 | +349 | +31.8 |
| RANDOM MOVE BY FIGURES | 25 | 25 | 11 | 3.67 | +537 | +48.8 |
| SET UP BY THE SET | 19 | 19 | 11 | 3.67 | +655 | +59.5 |
| GOAL WALK | 53 | 48 | 10 | 3.33 | +738 | +73.8 |
| COVER ONCE | 66 | 42 | 9 | 3.00 | +65 | +7.2 |
| RESERVE FALL BACK | 9 | 9 | 9 | 3.00 | +194 | +21.6 |
| CHARGE LOSSES | 96 | 89 | 8 | 2.67 | +876 | +109.5 |
| HOLDS AMBUSHERS | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| NEARER NOT NEEDED | 57 | 56 | 7 | 2.33 | +230 | +32.9 |
| SUPPORT ADDS | 36 | 33 | 7 | 2.33 | +162 | +23.1 |
| SUPPORT WORKED OUT | 36 | 33 | 7 | 2.33 | +162 | +23.1 |
| IDLE COST | 55 | 34 | 6 | 2.00 | +20 | +3.4 |
| TIED UP BY THE SUM | 7 | 6 | 6 | 2.00 | +174 | +29.1 |
| CHAFF IN THE MOVE | 7 | 7 | 5 | 1.67 | +0 | +0.0 |
| EVASIVE BY THE ODDS | 15 | 15 | 5 | 1.67 | +1762 | +352.5 |
| FOUR ROUNDS | 16 | 13 | 5 | 1.67 | +103 | +20.6 |
| COMBAT PIVOT | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| MANOEUVRE | 11 | 11 | 4 | 1.33 | +327 | +81.8 |
| REDIRECT COUNTER | 13 | 12 | 4 | 1.33 | +84 | +21.1 |
| STRIKE BY THE ODDS | 4 | 4 | 4 | 1.33 | +148 | +37.0 |
| CHARGE NOW FIRST | 7 | 7 | 3 | 1.00 | -191 | -63.7 |
| FOLLOW UP WEIGHED | 3 | 3 | 3 | 1.00 | +526 | +175.5 |
| LONE WIZARD KEPT IN | 3 | 3 | 3 | 1.00 | +157 | +52.2 |
| MARCH BY THE SUM | 3 | 3 | 3 | 1.00 | +204 | +67.9 |
| ONE PROMISE A TARGET | 3 | 3 | 3 | 1.00 | -599 | -199.8 |
| PATHS CROSS | 3 | 3 | 3 | 1.00 | +66 | +22.1 |
| RISK BY ARC | 13 | 10 | 3 | 1.00 | +72 | +24.2 |
| SECOND LOOK | 3 | 3 | 3 | 1.00 | +58 | +19.2 |
| AFTERMATH IN POINTS | 2 | 2 | 2 | 0.67 | +496 | +248.0 |
| CHALLENGE BY POINTS | 2 | 2 | 2 | 0.67 | +0 | +0.1 |
| FIRE IN ORDER | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| LANE BY FIGURES | 2 | 2 | 2 | 0.67 | +51 | +25.7 |
| PROMISE KNOWS THE FIGHT | 6 | 4 | 2 | 0.67 | -2 | -1.2 |
| SCOUT WAITS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| SHOOTERS IN TWO RANKS | 2 | 2 | 2 | 0.67 | +5 | +2.5 |
| STUCK PIVOT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| SUPPORT NARROWED | 2 | 2 | 2 | 0.67 | -90 | -45.1 |
| THE ROW IN ITS ORDER | 23 | 2 | 2 | 0.67 | +0 | +0.0 |
| WHO HITS BACK | 2 | 2 | 2 | 0.67 | +32 | +16.1 |
| CASTS FROM BEHIND | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| EXACT ROUND | 7 | 6 | 1 | 0.33 | +5 | +4.7 |
| FACES THE THREAT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FALLS SHORT | 74 | 62 | 1 | 0.33 | +0 | +0.0 |
| FEATURE BUFFS | 2 | 2 | 1 | 0.33 | +15 | +14.8 |
| FIGHT TO THE END | 3 | 2 | 1 | 0.33 | +37 | +37.5 |
| FOCUS FIRE | 1 | 1 | 1 | 0.33 | +84 | +83.6 |
| JOINT CHARGE NOW | 1 | 1 | 1 | 0.33 | -4 | -4.1 |
| MARCH CHECK | 2 | 2 | 1 | 0.33 | +27 | +26.7 |
| MARCH OF THE TABLE | 1 | 1 | 1 | 0.33 | -80 | -80.3 |
| MAX FOR POSITIONING | 12 | 12 | 1 | 0.33 | +3 | +2.9 |
| MISSILES IN THE MOVE | 14 | 9 | 1 | 0.33 | +0 | +0.0 |
| MISSILES NEXT TURN | 21 | 15 | 1 | 0.33 | +0 | +0.0 |
| NO DOUBLE ROUNDS | 11 | 10 | 1 | 0.33 | +28 | +27.6 |
| ONE FIGHT FORMULA | 33 | 12 | 1 | 0.33 | +114 | +113.8 |
| ONE OBJECTIVE FORMULA | 29 | 24 | 1 | 0.33 | +37 | +36.5 |
| OVERRUNS AWAY | 6 | 6 | 1 | 0.33 | +25 | +25.5 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.33 | +122 | +121.5 |
| PIVOT GUARDS FLANK | 1 | 1 | 1 | 0.33 | -8 | -8.2 |
| PROMISE READS THE TABLE | 1 | 1 | 1 | 0.33 | +12 | +11.6 |
| SHOTS AFTER THE MOVES | 10 | 10 | 1 | 0.33 | +0 | +0.0 |
| SHOTS IN THE MOVE | 72 | 51 | 1 | 0.33 | +14 | +14.2 |
| WALKS ON ITS ROUTE | 1 | 1 | 1 | 0.33 | -13 | -13.1 |
| WEAPON BY POINTS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| BACKUP TARGETS | 2 | 1 | 0 | 0.00 | - | - |
| CAST JOB | 2 | 2 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 3 | trace | - | - | - | - |
| CHAMPION KNOWS CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| CHARACTER GUNS | 6 | 6 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 53 | 53 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 5 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 2 | 1 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 13 | 10 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 41 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 25 | 24 | 0 | 0.00 | - | - |
| GIVES UP | 1 | 1 | 0 | 0.00 | - | - |
| GUN FIGURES | 6 | not checked | - | - | - | - |
| HE REFORMS ONCE FREED | 14 | 13 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 56 | 55 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 58 | 53 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 21 | 21 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 32 | 28 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 32 | 32 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 50 | 48 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 94 | 89 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 11 | 11 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 3 | 3 | 0 | 0.00 | - | - |
| HIS TURN RUN | 18 | 18 | 0 | 0.00 | - | - |
| HOLD ODDS | 103 | 101 | 0 | 0.00 | - | - |
| HONEST WORTH | 12 | 9 | 0 | 0.00 | - | - |
| HUNT IN PAIRS | 3 | 1 | 0 | 0.00 | - | - |
| JOINT KNOWS CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 24 | 22 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 2 | 2 | 0 | 0.00 | - | - |
| LONG SHOT | 1 | 1 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 6 | 5 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 1 | 1 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 3 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 2 | trace | - | - | - | - |
| MARCH OVER CASTS | 6 | 6 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 10 | 9 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 4 | trace | - | - | - | - |
| NO LATE CUT | 9 | 9 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT TURNED | 4 | 4 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 15 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 2 | not checked | - | - | - | - |
| ONE ROUTE | 10 | 9 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 18 | 18 | 0 | 0.00 | - | - |
| OPENS UP | 3 | 3 | 0 | 0.00 | - | - |
| PLAN RESULT | 277 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 4 | 4 | 0 | 0.00 | - | - |
| REAL GROUND | 10 | 9 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 2 | 2 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 11 | 11 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 6 | 5 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 3 | 3 | 0 | 0.00 | - | - |
| RUN DOWN | 5 | 5 | 0 | 0.00 | - | - |
| SCOUT SPOT | 2 | 2 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 4 | 4 | 0 | 0.00 | - | - |
| SEARCH SPOT | 2 | 2 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 9 | 9 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 3 | 3 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 23 | not checked | - | - | - | - |
| SPELL WORTH | 3 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 3 | 3 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 50 | 45 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 1 | 1 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 11 | 7 | 0 | 0.00 | - | - |
| STANDS STILL | 215 | 208 | 0 | 0.00 | - | - |
| STAY WORTH | 59 | 50 | 0 | 0.00 | - | - |
| SURE REACH TOGETHER | 3 | 2 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 13 | not checked | - | - | - | - |
| THE PROMISED MOVE | 2 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 16 | not checked | - | - | - | - |
| THE ROW READS HIS LAST RUN | 1 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 15 | not checked | - | - | - | - |
| THE TABLE BINDS | 269 | not checked | - | - | - | - |
| TWO OR MORE ARRIVE | 1 | not checked | - | - | - | - |
| WAITS AGAIN | 7 | 3 | 0 | 0.00 | - | - |
| WHAT THE JOINER ADDS | 4 | 2 | 0 | 0.00 | - | - |
| WHO FIGHTS | 1 | 1 | 0 | 0.00 | - | - |
| WHOLE FIGHT | 2 | 1 | 0 | 0.00 | - | - |
| WHOLE FIGHT DANGER | 23 | 23 | 0 | 0.00 | - | - |
| WHOLE FIGHT GAIN | 1 | 1 | 0 | 0.00 | - | - |
| WOUNDS ON THE RANKS | 12 | 12 | 0 | 0.00 | - | - |

### Off best figure: cora-bb45c30-p47

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 4.33 | 4.33 | 18.6 |
| PROMISE BY ITS OWN SUM | rule | 3.00 | 5.67 | 92.1 |
| ARMY TABLE | rule | 3.00 | 2.67 | 74.8 |
| RULE SWITCHED OFF | gate | - | 1.67 | 59.3 |
| CHARGE NOW FIRST | rule | 0.67 | 0.33 | 63.7 |
| ONE PROMISE A TARGET | rule | 1.00 | - | 199.8 |
| PROMISE KNOWS THE FIGHT | rule | - | 0.67 | 1.2 |
| SUPPORT NARROWED | rule | 0.33 | 0.33 | 45.1 |
| AFTERMATH BAND | gate | 0.33 | - | 3.7 |
| JOINT CHARGE NOW | rule | - | 0.33 | 4.1 |
| MARCH OF THE TABLE | rule | 0.33 | - | 80.3 |
| NO REASON | gate | 0.33 | - | 83.4 |
| PIVOT GUARDS FLANK | rule | - | 0.33 | 8.2 |
| RESERVE FALL BACK | rule | 0.33 | - | 5.0 |
| WALKS ON ITS ROUTE | rule | - | 0.33 | 13.1 |

### Plans: cora-bb45c30-p47

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 2.3 | 86% | 232 | 255 | 110% |
| Mine | join | 1.7 | 100% | 96 | 0 | 0% |
| Mine | move | 41.3 | 96% | 1720 | 0 | 0% |
| Mine | shoot | 3.7 | 45% | 185 | 131 | 70% |
| Mine | support | 0.3 | 100% | 18 | 0 | 0% |
| Opponent | charge | 2.0 | 50% | 133 | 144 | 108% |
| Opponent | join | 1.3 | 75% | 31 | 0 | 0% |
| Opponent | move | 36.3 | 93% | 1848 | 0 | 0% |
| Opponent | shoot | 2.7 | 75% | 108 | 272 | 252% |
| Opponent | support | 0.7 | 100% | 0 | 0 | - |

### Battle groups: cora-bb45c30-p47

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 3.0 | 22% | 100% | 0% | - | 0% | 0% | 0% | 100% | 0% |
| Opponent | REDIRECT COUNTER | 1.3 | 0% | - | - | - | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: cora-bb45c30-p47

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | - | - | - | - |
| Mine | Chaff | 5 | 75 (5) | 0 | 75 | 41 | 40% | 1.7 | 93 (4) | 0 (1) | - | 93 (4) | 0 (1) |
| Mine | Character | 9 | 9 (9) | 9 | 0 | 33 | 33% | 2.8 | 12 (5) | 0 (2) | - | 25 (2) | 0 (5) |
| Mine | Clean-up | 2 | 76 (2) | 44 | 31 | 0 | 0% | 3.5 | - | 106 (1) | 54 (1) | 54 (1) | 106 (1) |
| Mine | Fast Hammer | 4 | 48 (4) | 48 | 0 | 39 | 25% | 2.0 | 23 (2) | 99 (2) | - | 64 (1) | 43 (3) |
| Mine | Hammer | 4 | 124 (4) | 124 | 0 | 53 | 0% | 1.5 | 0 (1) | 234 (2) | 0 (1) | 166 (3) | 0 (1) |
| Mine | Holder | 7 | 48 (7) | 0 | 48 | 5 | 71% | 5.5 | 104 (2) | 21 (3) | 0 (1) | 53 (6) | - |
| Mine | Shooter | 5 | 92 (5) | 0 | 92 | 22 | 0% | 1.4 | 436 (1) | 25 (2) | 0 (2) | 130 (3) | 27 (2) |
| Mine | Wizard | 2 | 0 (2) | 0 | 0 | 0 | 0% | 1.0 | 0 (2) | - | - | - | 0 (2) |
| Opponent | Chaff | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Character | 9 | 33 (9) | 33 | 0 | 21 | 11% | 3.4 | 35 (6) | 0 (2) | 49 (1) | 22 (6) | 47 (3) |
| Opponent | Clean-up | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Fast Hammer | 5 | 16 (5) | 2 | 13 | 0 | 40% | 2.3 | 21 (3) | - | 6 (2) | 5 (2) | 25 (3) |
| Opponent | Hammer | 10 | 37 (10) | 37 | 0 | 34 | 30% | 2.7 | 64 (4) | 0 (5) | 58 (1) | 81 (4) | 8 (6) |
| Opponent | Holder | 4 | 12 (4) | 0 | 12 | 58 | 0% | 4.8 | 50 (1) | 0 (3) | - | - | 12 (4) |
| Opponent | Shooter | 3 | 54 (3) | 54 | 0 | 69 | 0% | 1.0 | 0 (1) | 87 (2) | - | - | 54 (3) |

### Charged fights: cora-bb45c30-p47

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Skaven | 1 | 116 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Mine | Tomb Kings of Khemri | 1 | 0 | 602 | 4.0 | 1.0 | 150 | 0 | +150 | 0 of 4 | 4 of 4 | - | +150 |
| Mine | Vampire Counts | 1 | 0 | 170 | 1.0 | 1.0 | 170 | 0 | +170 | 0 of 1 | 1 of 1 | - | +170 |
| **Mine** | all armies | 3 | 39 | 257 | 1.7 | 1.0 | 154 | 0 | +154 | 0 of 5 | 5 of 5 | - | +154 |
| Opponent | Warriors of Chaos | 2 | 0 | 265 | 2.5 | 1.0 | 106 | 0 | +106 | 2 of 5 | 4 of 5 | - | +106 |
| Opponent | Wood Elf Realms | 1 | 195 | 194 | 2.0 | 1.0 | 97 | 0 | +97 | 0 of 2 | 2 of 2 | - | +97 |
| **Opponent** | all armies | 3 | 65 | 241 | 2.3 | 1.0 | 103 | 0 | +103 | 2 of 7 | 6 of 7 | - | +103 |

### Effective charges: cora-bb45c30-p47

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Tomb Kings of Khemri | 4 | 0 | 0 | 0 | 0 | 1 (net +110) | 1 (net +265) | 2 | 0% (0 of 2) |
| Opponent | Warriors of Chaos | 5 | 2 (net +0) | 0 | 1 (net +470) | 0 | 1 (net +60) | 0 | 1 | 25% (1 of 4) |
| Opponent | Wood Elf Realms | 2 | 0 | 0 | 0 | 0 | 1 (net +122) | 1 (net +72) | 0 | 0% (0 of 2) |

### Charged fights, damage counted: cora-bb45c30-p47

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 195 | 110 | +265 | 304 | 32 | +272 | +139.5 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 411 | 110 | +110 | 148 | 12 | +136 | +33.1 |
| Mine | No odds | 3 | 256 | 132 | +132 | 132 | 22 | +111 | +43.3 |
| Mine | All fights | 5 | 275 | 123 | +154 | 170 | 22 | +148 | +53.9 |
| Opponent | Long shot (under 50%) | 2 | 290 | 352 | +0 | 3 | 0 | +3 | +1.0 |
| Opponent | Effective (55-75%) | 1 | 365 | 470 | +470 | 470 | 0 | +470 | +128.8 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 125 | 72 | +72 | 72 | 0 | +72 | +57.6 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 2 | 496 | 66 | +91 | 91 | 0 | +91 | +18.3 |
| Opponent | No odds | 1 | 120 | 41 | +0 | 32 | 0 | +32 | +26.3 |
| Opponent | All fights | 7 | 312 | 203 | +103 | 109 | 0 | +109 | +34.9 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| cora-bb45c30-p47 | move | 23 | 6 (26%) | 5 (22%) | 0 (0%) | 17 (74%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L2429 |
| Invocation of Nehek | Mine | L2429 |
| Periapt of Soul Exchange | Mine | L2131 |
| Ring of Doom | Opponent | L2131 |
| Storm Daemon (Renegade 2.0) | Mine | L2131 |

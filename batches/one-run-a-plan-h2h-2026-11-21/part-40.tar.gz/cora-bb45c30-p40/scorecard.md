# Doctrine scorecard: cora-bb45c30-p40

### Scorecard: cora-bb45c30-p40

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0528 | 6 | 1 | Mine | no | 2 | - | 0 | 2 | 0 | 0 | 0 | 335 |
| L0528 | 6 | 1 | Opponent | no | 9 | - | 0 | 2 | 0 | 0 | 0 | 0 |
| L0616 | 4 | 1 | Mine | no | 0 | - | 2 | 4 | 0 | 0 | 0 | 698 |
| L0616 | 4 | 1 | Opponent | no | 0 | 5 | 2 | 1 | 1 | 0 | 0 | 200 |
| L0632 | 2 | 1 | Mine | - | - | 5 | 4 | 2 | 0 | 0 | 0 | 325 |
| L0632 | 2 | 1 | Opponent | - | - | - | 0 | 6 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 0% | 1.0 | 5.0 | 2.0 | 2.7 | 0.0 | 0.0 | 0.0 | 452.7 |
| **Average** | | | Opponent | 0% | 4.5 | 5.0 | 0.7 | 3.0 | 0.3 | 0.0 | 0.0 | 66.7 |

### KPIs: cora-bb45c30-p40

Rules off - Opponent only: ONE RUN A PLAN.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 100% (12 of 12) | 0% (0 of 9) | 57% (12 of 21) |
| Winner chose to follow up after the loser gave ground |  | - | - | - |
| Winner chose to pursue after the loser fell back in good order |  | - | - | - |
| Winner chose to pursue after the loser fled |  | - | 100% (1 of 1); on the table 100% | 100% (1 of 1); on the table 100% |
| Winner chose to follow up or pursue (all three) |  | - | 100% (1 of 1); on the table 100% | 100% (1 of 1); on the table 100% |
| Magic missiles tried each own turn | 50%+ | - | 0% (0 of 6) | 0% (0 of 6) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | - | 0% (0 of 6) | 0% (0 of 6) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 67% (8 of 12) | 67% (8 of 12) |
| Points that never fought | lower | 91% (5437 of 6000) | 82% (4902 of 5999) | 86% (10339 of 11999) |
|   infantry points that never fought | lower | 90% (1999 of 2232) | 70% (506 of 720) | 85% (2505 of 2952) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 63% (17 of 27) | 76% (16 of 21) | 69% (33 of 48) |
| Bound items with a magic missile used (at least once a game) |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0.0 uses a game | 100% (1 of 1); 0.3 uses a game | 100% (1 of 1); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 58% (2471 of 4232) | 76% (4094 of 5415) | 68% (6565 of 9647) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | - | 1.7 (83%) | 1.7 (83%) |
| MARCHED: its unit marched | - | 0.3 (17%) | 0.3 (17%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Magic missiles | Assailments |
| --- | --- | --- | --- | --- |
| tried | 1.0 | 0.0 | 0.0 | 0.0 |
| not cast | 3.0 | 2.0 | 2.0 | 4.0 |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 2.0 (100%) | 1.7 (83%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.3 (17%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 1.0 (33%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.0 (67%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 4.0 (100%) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 60% (121 of 200) | 62% (18 of 29) | 61% (139 of 229) |
|   cavalry | 56% (10 of 18) | 67% (6 of 9) | 59% (16 of 27) |
|   character | 65% (17 of 26) | 0% (0 of 3) | 59% (17 of 29) |
|   infantry | 48% (25 of 52) | 0% (0 of 5) | 44% (25 of 57) |
|   monster | 50% (5 of 10) | - | 50% (5 of 10) |
|   war machine | 68% (64 of 94) | 100% (12 of 12) | 72% (76 of 106) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 4.3 (16%) | 0.7 (18%) | 5.0 (17%) |
| CHARGED: it charged | 2.3 (9%) | 0.0 (0%) | 2.3 (8%) |
| MOVED: a war machine that moved | 0.3 (1%) | 0.0 (0%) | 0.3 (1%) |
| NO TARGET IN RANGE | 7.0 (27%) | 2.7 (73%) | 9.7 (32%) |
| ONLY IN COMBAT: the only targets were in combat | 0.0 (0%) | 0.3 (9%) | 0.3 (1%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 9.3 (35%) | 0.0 (0%) | 9.3 (31%) |
| SHELTERED: the target was sheltered | 2.0 (8%) | 0.0 (0%) | 2.0 (7%) |
| OTHER BAR | 1.0 (4%) | 0.0 (0%) | 1.0 (3%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 6.0 | 0.7 | 89% | 4.3 pts | 26 pts |
| character | 5.7 | 8.0 | 53% | 14.4 pts | 82 pts |
| infantry | 16.7 | 8.0 | 66% | 15.1 pts | 252 pts |
| monster | 1.7 | 0.0 | 100% | 0.0 pts | 0 pts |
| war machine | 25.3 | 14.7 | 67% | 16.7 pts | 423 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 2.7 | 0.7 | 1.7 |
| Charges that made contact a game | 2.3 | 0.7 | 1.5 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | - | - | - |
|   per unit a game, units carrying another wizard (or one alone) | - | - | - |
|   per unit a game, the other units (no war machines, no joined characters) | 0.38 declared, 0.33 contact (21 units) | 0.10 declared, 0.10 contact (20 units) | 0.24 declared, 0.22 contact (41 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 75% (3 of 4) | - | 50% (1 of 2) | 67% (4 of 6) |
| Character in a unit | 86% (6 of 7) | 67% (2 of 3) | 100% (1 of 1) | 82% (9 of 11) |
| Character on its own | - | 50% (1 of 2) | 100% (3 of 3) | 80% (4 of 5) |
| Infantry | 57% (4 of 7) | 33% (2 of 6) | - | 46% (6 of 13) |
| Monster | 50% (2 of 4) | - | - | 50% (2 of 4) |
| Monstrous | 100% (1 of 1) | - | - | 100% (1 of 1) |
| War Machines | 88% (7 of 8) | - | - | 88% (7 of 8) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Dwarfen Mountain Holds | 3 | - | - | 91% | 63% (17 of 27) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | 100% (1 of 1); on the table 100% | - | 67% | 50% (3 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Warriors of Chaos | 2 | - | 0% (0 of 6) | 89% | 87% (13 of 15) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (cora-bb45c30-p40, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 0% (0) | 75% (3) | 60% (3) |
| ...free all their last turn and able to turn (per game) | 0.00 | 1.00 | 1.00 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.67 | 0.67 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: cora-bb45c30-p40

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.3 | 1.3 |
| Strategy | Charge objectives carried out (made contact) | 88% (7 of 8) | 50% (1 of 2) |
| Strategy | Shoot objectives carried out (shot that target) | 64% (49 of 76) | 53% (8 of 15) |
| Strategy | Joined characters whose unit fought | 0% (0 of 12) | 0% (0 of 5) |
| Strategy | Lone characters that fought | 0% (0 of 1) | 20% (1 of 5) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 2.7 | 3.0 |
| Movement | Points that never moved of their own | 452.7 | 66.7 |
| Movement | Fights charged into per game | 2.0 | 0.7 |
| Movement | Charges with odds: long shots (under 50%) | 1 of 6, net +0 | 0 of 1 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 6 | 0 of 1 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 6 | 0 of 1 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 of 6, net +138 | 1 of 1, net +0 |
| Shooting | Shots by shooting units (incl. breath weapons) | 20.7 | 4.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 47% (29 of 62) | 21% (3 of 14) |
| Shooting | Points destroyed by shooting units | 60.7 | 0.0 |
| Shooting | War machine shots | 21.3 | 4.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 69% (44 of 64) | 58% (7 of 12) |
| Shooting | Points destroyed by war machines | 320.0 | 93.3 |
| Magic | Points destroyed by magic (all spells) | 0.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.0 / 0.0 / 0.0 / 0.0 | 0.7 / 0.0 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 45.7 | 35.0 |
| Combat | Points run down | 53.3 | 0.0 |
| Combat | Net points per charged fight, damage counted | +87 | +32 |
| Combat | Net per 100 charger points, damage counted | +95.6 | +13.0 |
| Combat | First round won (charged fights) | 83% | 100% |
| Combat | Net points per charged fight | +73 | +52 |
| Combat | Net points per supported fight / lone fight | +137 / +60 | - / +52 |
| Combat | Charged fights on a top-3 enemy unit | 1 of 6 | 1 of 2 |
| Game | Points lost | 145.0 | 492.7 |
| Game | VP from objectives | 676.7 | 486.7 |
| Game | Lone holders (player turns) | 1.0 | 4.5 |

- Mine won / drew / lost: 2 / 1 / 0 of 3 ended games (of 3); mean margin (Mine - Opponent) +590 VP
- The side that went first won 0 of 2 games with a winner
- Points traded per game (both sides' losses): 638
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: cora-bb45c30-p40

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| ARMY TABLE | 9.7 | +11.0 | 0.0 | 0.0 | 19.3 | +132.4 | 0.0 | 530.7 |
| ARTILLERY RE-ROLL WEIGHED | 3.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| BACKUP TARGETS | 0.7 | +4.4 | 0.0 | 0.0 | - | - | - | - |
| BEST PRIZE | - | - | - | - | 0.3 | -30.0 | 35.0 | 0.0 |
| CANNON PLAN MISSED | 2.0 | +0.0 | 305.0 | 0.0 | 0.3 | +0.0 | 35.0 | 0.0 |
| CANNON PLANNED TARGET | 19.7 | +299.6 | 2784.3 | 35.0 | 4.0 | +151.9 | 181.7 | 0.0 |
| CANNON SIGHT KEPT | 3.0 | +0.0 | 0.0 | 38.3 | - | - | - | - |
| CHAFF IN THE MOVE | - | - | - | - | 2.7 | +39.9 | 0.0 | 36.7 |
| CHAFF PASSED | 1.0 | -1.5 | 0.0 | 0.0 | - | - | - | - |
| CHALLENGE BY POINTS | 0.3 | +0.1 | 0.0 | 0.0 | - | - | - | - |
| CHARACTER GUNS | 4.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHARGE LOSSES | 6.7 | -161.4 | 0.0 | 40.0 | 21.7 | -945.6 | 0.0 | 1357.7 |
| CHARGE NOW FIRST | 1.7 | +0.0 | 191.0 | 35.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 10.3 | +0.0 | 0.0 | 0.0 | 9.0 | +0.0 | 0.0 | 660.0 |
| COVER ONCE | 5.0 | -422.9 | 0.0 | 0.0 | 7.3 | -303.9 | 0.0 | 575.0 |
| DEFENSIVE ARMY | 0.7 | +0.0 | 163.0 | 0.0 | - | - | - | - |
| DENIED BY THE FIGHT | 0.7 | -4.0 | 26.7 | 0.0 | - | - | - | - |
| DEPLOY BY FIGURES | 13.0 | -157.2 | 0.0 | 38.3 | 6.0 | +73.0 | 0.0 | 0.0 |
| EXACT ROUND | 2.0 | +10.1 | 137.7 | 0.0 | 0.3 | +0.2 | 0.0 | 0.0 |
| FALL BACK GOOD ORDER | 2.7 | +2.2 | 191.0 | 35.0 | - | - | - | - |
| FALLS SHORT | - | - | - | - | 20.7 | +163.1 | 0.0 | 673.3 |
| FEATURE BUFFS | 1.0 | +14.4 | 0.0 | 0.0 | - | - | - | - |
| FIGHT TO THE END | 1.3 | +1.0 | 99.7 | 35.0 | 0.3 | +0.1 | 0.0 | 0.0 |
| FIRE IN ORDER | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 20.0 | 0.0 |
| FIVE ACTION | 138.7 | +5170.0 | 7118.0 | 145.0 | 74.3 | +2432.0 | 363.3 | 2030.7 |
| FLANK NOT WEIGHED | 1.7 | +0.0 | 0.0 | 0.0 | 6.7 | +0.0 | 0.0 | 372.3 |
| FOUR ROUNDS | 2.7 | +84.6 | 191.0 | 35.0 | 0.7 | +31.5 | 0.0 | 0.0 |
| FREED FROM HIS FIGHT | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FRIEND SHOOTS FIRST | 2.0 | -65.7 | 0.0 | 0.0 | - | - | - | - |
| GOAL WALK | 4.3 | +120.3 | 0.0 | 0.0 | 14.3 | +1012.0 | 0.0 | 92.7 |
| GUN FIGURES | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| GUN MASK | 3.7 | +103.2 | 0.0 | 0.0 | 0.7 | +18.3 | 0.0 | 0.0 |
| HARD STAY DROPPED | 6.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 3.7 | +0.0 | 0.0 | 40.0 | 12.7 | +0.0 | 0.0 | 1237.3 |
| HIS CHARGE DENIED | 0.3 | +4.6 | 0.0 | 0.0 | - | - | - | - |
| HIS CHARGE LIST | 5.3 | +0.0 | 0.0 | 40.0 | 21.0 | +0.0 | 0.0 | 418.7 |
| HIS LEGAL MOVES | 1.3 | +0.0 | 0.0 | 0.0 | 4.7 | +0.0 | 0.0 | 471.0 |
| HIS MOVE AND SHOT | 0.7 | -2.9 | 0.0 | 0.0 | 5.0 | -48.3 | 0.0 | 406.7 |
| HIS ONE QUARTER | 4.0 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 5.3 | +0.0 | 0.0 | 0.0 | 4.7 | +0.0 | 0.0 | 471.0 |
| HIS RANDOM MOVE | 19.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS RANDOM MOVER COMES | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 27.3 | +705.5 | 0.0 | 40.0 | 58.0 | +4775.2 | 0.0 | 1571.3 |
| HIS SHOTS BY HIS RUN | 22.0 | +326.1 | 0.0 | 40.0 | 50.7 | +1448.0 | 0.0 | 1734.3 |
| HIS TURN DENIED | 0.3 | +2.9 | 26.7 | 0.0 | - | - | - | - |
| HIS TURN RUN | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 14.3 | +0.0 | 0.0 | 0.0 | 12.0 | +0.0 | 0.0 | 256.7 |
| HOLDER ASSIGNMENT | 10.3 | +1137.8 | 0.0 | 0.0 | 7.0 | +724.1 | 0.0 | 128.3 |
| HOLDS AMBUSHERS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 2.0 | -19.8 | 191.0 | 35.0 | 0.7 | -16.8 | 0.0 | 0.0 |
| IDLE COST | - | - | - | - | 19.0 | -332.3 | 0.0 | 714.3 |
| JOINT CHARGE NOW | 0.3 | -6.0 | 45.7 | 0.0 | - | - | - | - |
| KEEPS SCOUTS OR AMBUSH | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 3.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | - | - | - | - | 1.3 | +77.7 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 1.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 35.0 | 106.7 |
| LONE WIZARD KEPT IN | - | - | - | - | 0.3 | +25.0 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | 2.0 | +2.8 | 144.7 | 35.0 | 0.3 | +0.1 | 0.0 | 0.0 |
| MANOEUVRE | 1.3 | -23.4 | 0.0 | 0.0 | 2.0 | +3.8 | 0.0 | 45.7 |
| MARCH WHEELS ONLY | 1.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 1.0 | +5.0 | 0.0 | 0.0 | 0.3 | +2.6 | 0.0 | 0.0 |
| MEETS IN TIME | 6.0 | +54.8 | 0.0 | 0.0 | 3.0 | +184.7 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | - | - | - | - | 0.3 | +0.5 | 0.0 | 0.0 |
| MISSILES NEXT TURN | - | - | - | - | 1.7 | +4.3 | 0.0 | 0.0 |
| MODEL FACING | 4.7 | +1190.1 | 0.0 | 20.0 | - | - | - | - |
| MOVE ORDER | 2.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 6.0 | +178.1 | 0.0 | 0.0 | 2.0 | +77.3 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 4.7 | +233.2 | 0.0 | 0.0 | 3.7 | +187.2 | 0.0 | 138.3 |
| NEXT CHARGE BY LIST | 2.0 | +95.9 | 0.0 | 0.0 | 1.3 | +65.7 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 2.3 | -53.5 | 191.0 | 35.0 | 0.7 | -36.1 | 0.0 | 0.0 |
| NO LATE CUT | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OFF BEST | 5.3 | -76.1 | 0.0 | 0.0 | 4.7 | -204.2 | 0.0 | 26.7 |
| ONE CHECK AFTER THE LAST CHANGE | 0.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 45.7 |
| ONE FIGHT FORMULA | 5.3 | -55.8 | 0.0 | 0.0 | 3.7 | -81.5 | 0.0 | 685.7 |
| ONE JOINT FIGURE | 0.7 | +5.6 | 45.7 | 0.0 | - | - | - | - |
| ONE OBJECTIVE FORMULA | 3.7 | -17.8 | 0.0 | 0.0 | 3.3 | -105.3 | 0.0 | 128.3 |
| ONE PROMISE A TARGET | 0.3 | +4.1 | 0.0 | 0.0 | - | - | - | - |
| ONE ROUTE | 1.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| OVERRUNS AWAY | 0.7 | +10.5 | 53.3 | 35.0 | 0.7 | +83.3 | 0.0 | 0.0 |
| PATHS CROSS | 0.3 | +1.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 10.0 |
| PLAN RESULT | 62.7 | +3136.0 | 2336.0 | 180.0 | 35.7 | +120.3 | 35.0 | 968.7 |
| PROMISE BY ITS OWN SUM | 10.3 | -148.9 | 0.0 | 0.0 | 2.3 | -16.0 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | 2.0 | -76.3 | 0.0 | 0.0 | - | - | - | - |
| PURSUES BIG PREY | - | - | - | - | 0.3 | -2.7 | 0.0 | 0.0 |
| QUARTER ODDS | 13.3 | +1007.9 | 0.0 | 110.0 | 6.7 | +828.0 | 210.0 | 0.0 |
| RANDOM MOVE BY FIGURES | - | - | - | - | 4.0 | +35.7 | 0.0 | 0.0 |
| REAL GROUND | 1.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| REDIRECT BY WHAT IT STOPS | - | - | - | - | 1.0 | +14.7 | 0.0 | 53.3 |
| REDIRECT COUNTER | - | - | - | - | 2.3 | +142.8 | 0.0 | 80.0 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 1.7 | +0.0 | 0.0 | 36.7 |
| REDIRECT WEIGHED | - | - | - | - | 0.3 | -30.0 | 35.0 | 0.0 |
| REFORMS TO MEET IT | 1.7 | -38.3 | 0.0 | 0.0 | - | - | - | - |
| REFUSING RETIRES | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | - | - | - | - | 1.0 | +17.2 | 0.0 | 26.7 |
| RESTRAINS TO SHOOT | 0.3 | +2.4 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | 2.3 | +87.8 | 191.0 | 35.0 | 0.7 | -138.2 | 0.0 | 0.0 |
| RUN DOWN | 2.3 | -33.7 | 191.0 | 35.0 | 0.7 | -13.1 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 2.7 | -116.9 | 0.0 | 20.0 |
| SEARCH SPOT | - | - | - | - | 0.3 | +1.0 | 0.0 | 0.0 |
| SET CREDITED ONCE | 2.0 | -103.7 | 0.0 | 0.0 | 0.3 | -10.9 | 0.0 | 163.0 |
| SET UP BY THE SET | 2.0 | +103.1 | 0.0 | 0.0 | 0.3 | +3.8 | 0.0 | 163.0 |
| SET UP TOGETHER | - | - | - | - | 1.3 | +43.2 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 2.0 | +4.0 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS ON THE TABLE | 27.0 | +0.0 | 0.0 | 35.0 | 6.3 | +0.0 | 0.0 | 106.7 |
| SHOOTS FROM THE BEST SPOT | - | - | - | - | 0.3 | +34.0 | 0.0 | 163.0 |
| SHORT GUN FORWARD | 2.0 | +0.0 | 0.0 | 38.3 | - | - | - | - |
| SHOT RISK POINTS | 11.7 | +303.2 | 0.0 | 0.0 | 31.3 | -687.1 | 0.0 | 975.0 |
| SHOTS AFTER THE MOVES | 5.7 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 36.7 | +1166.8 | 0.0 | 35.0 | 7.3 | +250.7 | 0.0 | 306.7 |
| SPELL WORTH | - | - | - | - | 1.0 | +16.7 | 0.0 | 0.0 |
| SPOT AS THE GAME MOVES | 4.3 | +0.0 | 0.0 | 0.0 | 7.3 | +0.0 | 0.0 | 200.0 |
| STAND AND SHOOT | 0.7 | -2.4 | 53.3 | 35.0 | 0.3 | -6.6 | 0.0 | 0.0 |
| STANDS FOR A REASON | - | - | - | - | 1.7 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 102.0 | +0.0 | 6927.0 | 70.0 | 22.0 | +0.0 | 363.3 | 342.7 |
| STAY WORTH | 73.7 | +419.6 | 5933.7 | 105.0 | 11.3 | +225.1 | 223.3 | 26.7 |
| STUCK PIVOT | - | - | - | - | 1.7 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 1.0 | +15.5 | 0.0 | 0.0 | 2.3 | +19.2 | 0.0 | 72.3 |
| SUPPORT NARROWED | 0.3 | +0.0 | 26.7 | 0.0 | - | - | - | - |
| SUPPORT WORKED OUT | 1.0 | +15.5 | 0.0 | 0.0 | 2.3 | +19.2 | 0.0 | 72.3 |
| SURE REACH TOGETHER | 0.3 | +0.5 | 0.0 | 0.0 | - | - | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 2.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 10.0 |
| THE PROMISED MOVE | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 1.3 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 1.7 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 60.0 |
| THE STEP BACK IS MADE | 0.7 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 60.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 59.7 | +0.0 | 0.0 | 55.0 | 36.3 | +0.0 | 0.0 | 1052.0 |
| TIED UP BY THE SUM | 0.7 | +16.5 | 92.0 | 0.0 | 0.3 | +27.7 | 0.0 | 0.0 |
| TIME ON OUR SIDE | 58.7 | +619.8 | 27.3 | 0.0 | - | - | - | - |
| TWO OR MORE ARRIVE | - | - | - | - | 1.0 | +1.4 | 0.0 | 0.0 |
| WAITS AGAIN | 2.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WHO FIGHTS | 1.3 | -6.0 | 99.0 | 35.0 | - | - | - | - |
| WHO HITS BACK | 0.3 | +13.0 | 0.0 | 0.0 | 0.3 | +8.0 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | 1.3 | -62.3 | 0.0 | 40.0 | 4.0 | -260.1 | 0.0 | 840.0 |
| WOUNDS ON THE RANKS | 1.3 | +52.2 | 0.0 | 0.0 | 3.7 | +259.0 | 0.0 | 0.0 |

### Rule changes: cora-bb45c30-p40

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS SHOT LIST | 256 | 247 | 57 | 19.00 | +1479 | +26.0 |
| ARMY TABLE | 87 | 87 | 51 | 17.00 | +618 | +12.1 |
| HOLDER ASSIGNMENT | 52 | 52 | 49 | 16.33 | +3283 | +67.0 |
| DEPLOY BY FIGURES | 57 | 57 | 39 | 13.00 | +580 | +14.9 |
| HIS SHOTS BY HIS RUN | 218 | 210 | 32 | 10.67 | +629 | +19.7 |
| OFF BEST | 30 | 30 | 30 | 10.00 | -841 | -28.0 |
| SHOT RISK POINTS | 129 | 124 | 27 | 9.00 | +656 | +24.3 |
| TIME ON OUR SIDE | 176 | 156 | 27 | 9.00 | +89 | +3.3 |
| HARD STAY DROPPED | 20 | 20 | 20 | 6.67 | +0 | +0.0 |
| THE TABLE AGAIN | 36 | 36 | 20 | 6.67 | +0 | +0.0 |
| CANNON PLANNED TARGET | 71 | 71 | 18 | 6.00 | -323 | -18.0 |
| PROMISE BY ITS OWN SUM | 38 | 38 | 18 | 6.00 | -495 | -27.5 |
| FIVE ACTION | 639 | 626 | 14 | 4.67 | +167 | +11.9 |
| MODEL FACING | 14 | 14 | 14 | 4.67 | +3570 | +255.0 |
| MOVE TO CHARGE COMPUTED | 24 | 18 | 13 | 4.33 | +208 | +16.0 |
| MOVE ORDER | 12 | 12 | 12 | 4.00 | +0 | +0.0 |
| ARTILLERY RE-ROLL WEIGHED | 11 | 11 | 11 | 3.67 | +0 | +0.0 |
| GOAL WALK | 56 | 56 | 10 | 3.33 | +465 | +46.5 |
| CANNON SIGHT KEPT | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| COVER ONCE | 37 | 29 | 9 | 3.00 | +162 | +17.9 |
| LEGAL CHARGES ONLY | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| RANDOM MOVE BY FIGURES | 12 | 12 | 8 | 2.67 | +107 | +13.4 |
| IDLE COST | 57 | 50 | 7 | 2.33 | +30 | +4.2 |
| CHAFF IN THE MOVE | 8 | 7 | 6 | 2.00 | +14 | +2.3 |
| CHARGE LOSSES | 85 | 85 | 6 | 2.00 | +208 | +34.6 |
| FOUR ROUNDS | 10 | 10 | 6 | 2.00 | +108 | +18.0 |
| GUN MASK | 13 | 13 | 6 | 2.00 | +193 | +32.2 |
| MEETS IN TIME | 27 | 27 | 6 | 2.00 | +34 | +5.6 |
| NEXT CHARGE BY LIST | 10 | 7 | 6 | 2.00 | +171 | +28.6 |
| SHOOTERS IN TWO RANKS | 6 | 6 | 6 | 2.00 | +12 | +2.0 |
| SHORT GUN FORWARD | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| SHOTS IN THE MOVE | 132 | 110 | 6 | 2.00 | +99 | +16.5 |
| QUARTER ODDS | 60 | 60 | 5 | 1.67 | +273 | +54.6 |
| REDIRECT FOR A FRIEND IN REACH | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| RISK BY ARC | 9 | 9 | 5 | 1.67 | +78 | +15.5 |
| STUCK PIVOT | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| WOUNDS ON THE RANKS | 15 | 15 | 5 | 1.67 | +214 | +42.7 |
| LANE BY FIGURES | 4 | 4 | 4 | 1.33 | +233 | +58.2 |
| PROMISE READS THE TABLE | 6 | 6 | 4 | 1.33 | -183 | -45.7 |
| SHOTS AFTER THE MOVES | 24 | 24 | 4 | 1.33 | +0 | +0.0 |
| SUPPORT ADDS | 10 | 10 | 4 | 1.33 | +38 | +9.6 |
| SUPPORT WORKED OUT | 10 | 10 | 4 | 1.33 | +38 | +9.6 |
| ADVANCE LANE KEPT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| CHAFF PASSED | 3 | 3 | 3 | 1.00 | -4 | -1.5 |
| FIRE IN ORDER | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| RESERVE FALL BACK | 3 | 3 | 3 | 1.00 | +52 | +17.2 |
| STAY WORTH | 255 | 234 | 3 | 1.00 | +67 | +22.3 |
| CHARGE NOW FIRST | 6 | 6 | 2 | 0.67 | -85 | -42.5 |
| HOLDS AMBUSHERS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| MANOEUVRE | 10 | 10 | 2 | 0.67 | +11 | +5.7 |
| OVERRUNS AWAY | 4 | 4 | 2 | 0.67 | +18 | +9.0 |
| PATHS CROSS | 2 | 2 | 2 | 0.67 | +3 | +1.6 |
| REDIRECT BY WHAT IT STOPS | 3 | 3 | 2 | 0.67 | +25 | +12.3 |
| TIED UP BY THE SUM | 3 | 3 | 2 | 0.67 | +34 | +16.8 |
| WHO HITS BACK | 2 | 2 | 2 | 0.67 | +31 | +15.7 |
| BEST PRIZE | 1 | 1 | 1 | 0.33 | -90 | -90.0 |
| CHALLENGE BY POINTS | 1 | 1 | 1 | 0.33 | +0 | +0.3 |
| EXACT ROUND | 7 | 7 | 1 | 0.33 | +3 | +3.1 |
| FEATURE BUFFS | 3 | 3 | 1 | 0.33 | +4 | +4.3 |
| JOINT CHARGE NOW | 1 | 1 | 1 | 0.33 | -18 | -18.1 |
| LONE WIZARD KEPT IN | 1 | 1 | 1 | 0.33 | +75 | +75.0 |
| MAX FOR POSITIONING | 4 | 3 | 1 | 0.33 | +0 | +0.0 |
| NEARER NOT NEEDED | 25 | 24 | 1 | 0.33 | +23 | +23.2 |
| ONE FIGHT FORMULA | 27 | 21 | 1 | 0.33 | +0 | +0.0 |
| ONE JOINT FIGURE | 2 | 2 | 1 | 0.33 | +3 | +3.2 |
| ONE PROMISE A TARGET | 1 | 1 | 1 | 0.33 | +12 | +12.4 |
| PURSUES BIG PREY | 1 | 1 | 1 | 0.33 | -8 | -8.2 |
| REDIRECT WEIGHED | 1 | 1 | 1 | 0.33 | -32 | -32.2 |
| RESTRAINS TO SHOOT | 1 | 1 | 1 | 0.33 | +7 | +7.1 |
| SEARCH SPOT | 1 | 1 | 1 | 0.33 | +3 | +2.9 |
| SET UP BY THE SET | 7 | 4 | 1 | 0.33 | +19 | +18.5 |
| SHOOTS FROM THE BEST SPOT | 1 | 1 | 1 | 0.33 | +57 | +57.0 |
| THE ROW IN ITS ORDER | 16 | 1 | 1 | 0.33 | +0 | +0.0 |
| WHOLE FIGHT DANGER | 16 | 16 | 1 | 0.33 | +4 | +4.1 |
| BACKUP TARGETS | 2 | 2 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 7 | 7 | 0 | 0.00 | - | - |
| CHARACTER GUNS | 12 | 12 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 58 | 58 | 0 | 0.00 | - | - |
| DEFENSIVE ARMY | 2 | 2 | 0 | 0.00 | - | - |
| DENIED BY THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 8 | 8 | 0 | 0.00 | - | - |
| FALLS SHORT | 62 | 53 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 5 | 5 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 25 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 6 | 3 | 0 | 0.00 | - | - |
| GUN FIGURES | 3 | not checked | - | - | - | - |
| HIS CHARGE BY HIS RUN | 49 | 49 | 0 | 0.00 | - | - |
| HIS CHARGE DENIED | 1 | 1 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 79 | 76 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 18 | 18 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 17 | 17 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 22 | 22 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 30 | 28 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 59 | 53 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 2 | 2 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 1 | 1 | 0 | 0.00 | - | - |
| HIS TURN RUN | 18 | 18 | 0 | 0.00 | - | - |
| HOLD ODDS | 79 | 79 | 0 | 0.00 | - | - |
| HONEST WORTH | 8 | 8 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 12 | 12 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 7 | 7 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 5 | 5 | 0 | 0.00 | - | - |
| MISSILES IN THE MOVE | 1 | 1 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 5 | 5 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 9 | 9 | 0 | 0.00 | - | - |
| NO LATE CUT | 3 | 3 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 5 | not checked | - | - | - | - |
| ONE OBJECTIVE FORMULA | 21 | 18 | 0 | 0.00 | - | - |
| ONE ROUTE | 5 | 5 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 18 | 18 | 0 | 0.00 | - | - |
| PLAN RESULT | 295 | trace | - | - | - | - |
| PROMISE KNOWS THE FIGHT | 4 | 3 | 0 | 0.00 | - | - |
| REAL GROUND | 5 | 5 | 0 | 0.00 | - | - |
| REDIRECT COUNTER | 7 | 5 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 5 | 3 | 0 | 0.00 | - | - |
| REFUSING RETIRES | 1 | 1 | 0 | 0.00 | - | - |
| RUN DOWN | 9 | 9 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 8 | 8 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 7 | 4 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 4 | 4 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 100 | not checked | - | - | - | - |
| SPELL WORTH | 3 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 35 | 25 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 3 | 3 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 5 | 5 | 0 | 0.00 | - | - |
| STANDS STILL | 372 | 366 | 0 | 0.00 | - | - |
| SUPPORT NARROWED | 1 | 1 | 0 | 0.00 | - | - |
| SURE REACH TOGETHER | 1 | 1 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 9 | not checked | - | - | - | - |
| THE PROMISED MOVE | 1 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 23 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 14 | not checked | - | - | - | - |
| THE TABLE BINDS | 288 | not checked | - | - | - | - |
| TWO OR MORE ARRIVE | 3 | not checked | - | - | - | - |
| WAITS AGAIN | 6 | 4 | 0 | 0.00 | - | - |
| WHO FIGHTS | 4 | 4 | 0 | 0.00 | - | - |

### Off best figure: cora-bb45c30-p40

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 4.67 | 4.33 | 30.6 |
| PROMISE BY ITS OWN SUM | rule | 5.33 | 0.67 | 27.5 |
| ARMY TABLE | rule | 2.00 | 2.33 | 26.5 |
| CANNON PLANNED TARGET | rule | 2.33 | 1.00 | 33.1 |
| PROMISE READS THE TABLE | rule | 1.33 | - | 45.7 |
| CHAFF PASSED | rule | 0.67 | - | 2.2 |
| CHARGE NOW FIRST | rule | 0.67 | - | 42.5 |
| HOLDER ASSIGNMENT | rule | 0.67 | - | 22.9 |
| AFTERMATH BAND | gate | - | 0.33 | 1.6 |
| BEST PRIZE | rule | - | 0.33 | 90.0 |
| DEPLOY BY FIGURES | rule | - | 0.33 | 5.8 |
| FALLBACK | gate | 0.33 | - | 7.6 |
| JOINT CHARGE NOW | rule | 0.33 | - | 18.1 |
| NO REASON | gate | 0.33 | - | 4.8 |
| PURSUES BIG PREY | rule | - | 0.33 | 8.2 |
| REDIRECT WEIGHED | rule | - | 0.33 | 32.2 |

### Plans: cora-bb45c30-p40

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 2.3 | 71% | 94 | 204 | 216% |
| Mine | join | 2.7 | 100% | 88 | 0 | 0% |
| Mine | move | 35.7 | 99% | 1022 | 0 | 0% |
| Mine | shoot | 22.0 | 86% | 1070 | 2932 | 274% |
| Opponent | charge | 0.7 | 0% | 16 | 0 | 0% |
| Opponent | move | 29.0 | 93% | 895 | 0 | 0% |
| Opponent | shoot | 4.3 | 31% | 271 | 120 | 44% |
| Opponent | support | 1.7 | 80% | 22 | 0 | 0% |

### Battle groups: cora-bb45c30-p40

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | REDIRECT COUNTER | 2.3 | 43% | 67% | 67% | 0% | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: cora-bb45c30-p40

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | - | 0 (1) | 0 (1) | - |
| Mine | Character | 13 | 5 (13) | 5 | 0 | 0 | 46% | 2.9 | 10 (3) | 0 (6) | 7 (4) | 4 (8) | 6 (5) |
| Mine | Clean-up | 3 | 38 (3) | 38 | 0 | 0 | 33% | 1.0 | 0 (1) | 232 (1) | 0 (1) | 116 (2) | 0 (1) |
| Mine | Hammer | 6 | 78 (6) | 13 | 65 | 0 | 50% | 3.3 | - | 80 (4) | 73 (2) | 74 (5) | 88 (1) |
| Mine | Shooter | 10 | 67 (10) | 21 | 46 | 12 | 10% | 2.0 | - | 90 (4) | 42 (6) | 93 (5) | 34 (5) |
| Mine | War machine | 17 | 56 (17) | 56 | 0 | 13 | 18% | 1.1 | 53 (9) | 230 (2) | 0 (6) | 0 (3) | 68 (14) |
| Opponent | Chaff | 5 | 0 (5) | 0 | 0 | 89 | 60% | 2.0 | 0 (4) | - | 0 (1) | 0 (4) | 0 (1) |
| Opponent | Character | 8 | 4 (8) | 4 | 0 | 38 | 62% | 3.0 | 9 (3) | 0 (1) | 0 (4) | 6 (5) | 0 (3) |
| Opponent | Clean-up | 3 | 53 (3) | 0 | 53 | 0 | 67% | 5.0 | 71 (1) | 34 (2) | - | 53 (3) | - |
| Opponent | Fast Hammer | 4 | 44 (4) | 0 | 44 | 12 | 75% | 1.0 | - | 79 (3) | 0 (1) | 101 (2) | 0 (2) |
| Opponent | Hammer | 3 | 0 (3) | 0 | 0 | 0 | 67% | 5.0 | 0 (1) | 0 (2) | - | 0 (3) | - |
| Opponent | Holder | 2 | 0 (2) | 0 | 0 | 100 | 0% | 3.0 | - | 0 (2) | - | 0 (1) | 0 (1) |
| Opponent | Support | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | War machine | 2 | 140 (2) | 140 | 0 | 0 | 0% | 1.0 | - | - | 140 (2) | - | 140 (2) |
| Opponent | Wizard | 2 | 0 (2) | 0 | 0 | 0 | 50% | 1.0 | 0 (1) | 0 (1) | - | 0 (2) | - |

### Charged fights: cora-bb45c30-p40

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Dwarfen Mountain Holds | 3 | 381 | 145 | 2.0 | 1.2 | 73 | 0 | +73 | 1 of 6 | 5 of 6 | +137 | +60 |
| Opponent | Kingdom of Bretonnia | 1 | 280 | 105 | 2.0 | 1.0 | 52 | 0 | +52 | 1 of 2 | 2 of 2 | - | +52 |
| Opponent | Warriors of Chaos | 2 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| **Opponent** | all armies | 3 | 93 | 35 | 0.7 | 1.0 | 52 | 0 | +52 | 1 of 2 | 2 of 2 | - | +52 |

### Effective charges: cora-bb45c30-p40

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Dwarfen Mountain Holds | 6 | 1 (net +0) | 0 | 0 | 3 (net +53) | 0 | 2 (net +138) | 0 | 0% (0 of 6) |
| Opponent | Kingdom of Bretonnia | 2 | 0 | 0 | 0 | 0 | 0 | 1 (net +0) | 1 | 0% (0 of 1) |

### Charged fights, damage counted: cora-bb45c30-p40

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 1 | 50 | 170 | +0 | 85 | 0 | +85 | +170.0 |
| Mine | 76-89% | 3 | 90 | 99 | +53 | 53 | 0 | +53 | +59.3 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 112 | 138 | +138 | 138 | 0 | +138 | +122.7 |
| Mine | All fights | 6 | 91 | 124 | +73 | 87 | 0 | +87 | +95.6 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 214 | 183 | +0 | 92 | 133 | -41 | -19.3 |
| Opponent | No odds | 1 | 277 | 105 | +105 | 105 | 0 | +105 | +37.9 |
| Opponent | All fights | 2 | 246 | 144 | +52 | 98 | 66 | +32 | +13.0 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| cora-bb45c30-p40 | move | 20 | 2 (10%) | 2 (10%) | 0 (0%) | 18 (90%) |

## Decision items and abilities without guidance

None: every decision item and ability on these lists has its guidance line.

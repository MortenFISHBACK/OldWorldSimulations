# Doctrine scorecard: cora-bb45c30-p36

### Scorecard: cora-bb45c30-p36

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L2531 | 5 | 1 | Mine | no | - | - | 0 | 2 | 0 | 0 | 0 | 211 |
| L2531 | 5 | 1 | Opponent | yes | - | 1 | 1 | 3 | 1 | 0 | 0 | 0 |
| L2730 | 6 | 1 | Mine | no | 1 | 2 | 6 | 2 | 0 | 0 | 0 | 60 |
| L2730 | 6 | 1 | Opponent | no | 3 | 2 | 2 | 0 | 0 | 0 | 0 | 0 |
| L2934 | 6 | 1 | Mine | no | 5 | 3 | 1 | 1 | 0 | 0 | 0 | 0 |
| L2934 | 6 | 1 | Opponent | no | 2 | 2 | 3 | 3 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 0% | 3.0 | 2.5 | 2.3 | 1.7 | 0.0 | 0.0 | 0.0 | 90.3 |
| **Average** | | | Opponent | 33% | 2.5 | 1.7 | 2.0 | 2.0 | 0.3 | 0.0 | 0.0 | 0.0 |

### KPIs: cora-bb45c30-p36

Rules off - Opponent only: ONE RUN A PLAN.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 17) | 0% (0 of 16) | 0% (0 of 33) |
| Winner chose to follow up after the loser gave ground |  | 100% (2 of 2); on the table 100% | 86% (6 of 7); on the table 86% | 89% (8 of 9); on the table 89% |
| Winner chose to pursue after the loser fell back in good order |  | 100% (1 of 1); on the table 100% | - | 100% (1 of 1); on the table 100% |
| Winner chose to pursue after the loser fled |  | 40% (2 of 5); on the table 60% | 100% (1 of 1); on the table 100% | 50% (3 of 6); on the table 67% |
| Winner chose to follow up or pursue (all three) |  | 62% (5 of 8); on the table 75% | 88% (7 of 8); on the table 88% | 75% (12 of 16); on the table 81% |
| Magic missiles tried each own turn | 50%+ | 50% (3 of 6) | 50% (3 of 6) | 50% (6 of 12) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 100% (3 of 3) | 50% (3 of 6) | 67% (6 of 9) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 50% (1 of 2) | 55% (6 of 11) | 54% (7 of 13) |
| Points that never fought | lower | 41% (2488 of 5998) | 40% (2380 of 5998) | 41% (4868 of 11996) |
|   infantry points that never fought | lower | 63% (565 of 902) | 50% (533 of 1072) | 56% (1098 of 1974) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 63% (12 of 19) | 65% (17 of 26) | 64% (29 of 45) |
| Bound items with a magic missile used (at least once a game) |  | 0.0 uses a game | 100% (1 of 1); 1.3 uses a game | 100% (1 of 1); 0.7 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0.0 uses a game | 50% (1 of 2); 0.3 uses a game | 50% (1 of 2); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 54% (2714 of 5038) | 61% (3243 of 5360) | 57% (5957 of 10398) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.0 (100%) | 1.0 (50%) |
| GONE: slain | 1.0 (100%) | 0.0 (0%) | 1.0 (50%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 1.7 | 1.7 | 1.0 | 2.0 | 0.3 | 0.3 |
| not cast | 4.3 | 0.0 | 3.0 | 2.0 | 1.7 | 23.7 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | - | 0.7 (22%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | - | 0.0 (0%) | 1.0 (50%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | 0.0 (0%) | - | 1.0 (33%) | 1.0 (50%) | 1.0 (60%) | 2.0 (8%) |
| STUPIDITY: Stupidity | 0.0 (0%) | - | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.0 (8%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | - | 0.0 (0%) | 0.0 (0%) | 0.7 (40%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 4.3 (100%) | - | 1.3 (44%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | - | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 19.7 (83%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.0 a game | 0.0 a game | 0.5 a game |
| stood (cast and not dispelled) | 100% (3 of 3) | - | 100% (3 of 3) |
| the unit moved after it | 100% (3 of 3) | - | 100% (3 of 3) |
| it charged on its next turn | 0% (0 of 3) | - | 0% (0 of 3) |
| the enemy charged it first | 0% (0 of 3) | - | 0% (0 of 3) |
| it fought by the end of its next turn | 0% (0 of 3) | - | 0% (0 of 3) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 3) | - | 0% (0 of 3) |
| none of these (no charge, no fight, no charge escaped) | 100% (3 of 3) | - | 100% (3 of 3) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 17% (1 of 6) | 67% (24 of 36) | 60% (25 of 42) |
|   cavalry | 33% (1 of 3) | 92% (11 of 12) | 80% (12 of 15) |
|   character | 0% (0 of 3) | 40% (6 of 15) | 33% (6 of 18) |
|   infantry | - | 78% (7 of 9) | 78% (7 of 9) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 0.3 (20%) | 0.7 (17%) | 1.0 (18%) |
| CHARGED: it charged | 0.7 (40%) | 2.0 (50%) | 2.7 (47%) |
| IN COMBAT: it fought this turn or the last | 0.3 (20%) | 0.0 (0%) | 0.3 (6%) |
| NO TARGET IN RANGE | 0.3 (20%) | 0.7 (17%) | 1.0 (18%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.0 (0%) | 0.3 (8%) | 0.3 (6%) |
| OTHER BAR | 0.0 (0%) | 0.3 (8%) | 0.3 (6%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 7.7 | 0.7 | 91% | 1.4 pts | 11 pts |
| character | 2.0 | 0.0 | 100% | 0.0 pts | 0 pts |
| infantry | 4.0 | 0.3 | 92% | 4.6 pts | 18 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 5.0 | 4.0 | 4.5 |
| Charges that made contact a game | 4.3 | 3.7 | 4.0 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.00 declared, 0.00 contact (1 units) | - | 0.00 declared, 0.00 contact (1 units) |
|   per unit a game, units carrying another wizard (or one alone) | 2.00 declared, 2.00 contact (2 units) | 0.00 declared, 0.00 contact (1 units) | 1.33 declared, 1.33 contact (3 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.44 declared, 0.36 contact (25 units) | 0.48 declared, 0.44 contact (25 units) | 0.46 declared, 0.40 contact (50 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 57% (4 of 7) | 80% (4 of 5) | 0% (0 of 1) | 62% (8 of 13) |
| Character in a unit | 100% (5 of 5) | - | 100% (1 of 1) | 100% (6 of 6) |
| Character on its own | 50% (1 of 2) | 100% (3 of 3) | 43% (3 of 7) | 58% (7 of 12) |
| Infantry | 57% (4 of 7) | 0% (0 of 1) | - | 50% (4 of 8) |
| Monster | 67% (2 of 3) | 0% (0 of 1) | - | 50% (2 of 4) |
| Monstrous | 100% (2 of 2) | - | - | 100% (2 of 2) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Vampire Counts | 2 | 57% (4 of 7); on the table 71% | 50% (3 of 6) | 44% | 67% (8 of 12) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 3 | 86% (6 of 7); on the table 86% | 50% (3 of 6) | 42% | 72% (18 of 25) | 100% (1 of 1); 1.3 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Wood Elf Realms | 1 | 100% (2 of 2); on the table 100% | - | 30% | 38% (3 of 8) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |

Flank and rear charges a unit could have turned to face (cora-bb45c30-p36, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 56% (5) | 62% (5) | 59% (10) |
| ...free all their last turn and able to turn (per game) | 1.67 | 1.33 | 3.00 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.33 | 0.33 |
| ...with the charger already in that arc before they moved (per game) | 1.00 | 1.33 | 2.33 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.33 | 0.00 | 0.33 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: cora-bb45c30-p36

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.7 | 3.3 |
| Strategy | Charge objectives carried out (made contact) | 71% (10 of 14) | 80% (8 of 10) |
| Strategy | Shoot objectives carried out (shot that target) | - | 14% (1 of 7) |
| Strategy | Support requests answered (helper made contact too) | 100% (3 of 3) | 50% (1 of 2) |
| Strategy | Joined characters whose unit fought | 20% (1 of 5) | 0% (0 of 3) |
| Strategy | Lone characters that fought | 62% (5 of 8) | 100% (7 of 7) |
| Movement | Charges halted short of contact | 0.3 | 0.0 |
| Movement | Idle units | 1.7 | 2.0 |
| Movement | Points that never moved of their own | 90.3 | 0.0 |
| Movement | Fights charged into per game | 3.0 | 3.3 |
| Movement | Charges with odds: long shots (under 50%) | 2 of 8, net +0 | 3 of 8, net -39 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 8 | 1 of 8, net +254 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 3 of 8, net +92 | 1 of 8, net +122 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 of 8, net +217 | 2 of 8, net +102 |
| Shooting | Shots by shooting units (incl. breath weapons) | 1.3 | 8.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 25% (1 of 4) | 60% (15 of 25) |
| Shooting | Points destroyed by shooting units | 0.0 | 0.0 |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | 0.7 | 0.7 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 0% (0 of 2) | 100% (2 of 2) |
| Magic | Wounds caused by magic missiles | - | 0.3 |
| Magic | Points destroyed by magic (all spells) | 0.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.3 / 0.0 / 0.3 / 0.3 | 0.0 / 1.0 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 393.0 | 297.0 |
| Combat | Points run down | 0.0 | 40.7 |
| Combat | Net points per charged fight, damage counted | +192 | +100 |
| Combat | Net per 100 charger points, damage counted | +46.1 | +29.1 |
| Combat | First round won (charged fights) | 78% | 80% |
| Combat | Net points per charged fight | +179 | +103 |
| Combat | Net points per supported fight / lone fight | +232 / +153 | -116 / +128 |
| Combat | Charged fights on a top-3 enemy unit | 4 of 9 | 3 of 10 |
| Game | Points lost | 500.7 | 558.0 |
| Game | VP from objectives | 450.0 | 706.7 |
| Game | Lone holders (player turns) | 3.0 | 2.5 |

- Mine won / drew / lost: 1 / 0 / 2 of 3 ended games (of 3); mean margin (Mine - Opponent) -137 VP
- The side that went first won 0 of 3 games with a winner
- Points traded per game (both sides' losses): 1059
- Games not ended: 0; findings 1, warnings 0

### Opponent rules: cora-bb45c30-p36

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.7 | +43.9 | 0.0 | 0.0 | 0.3 | +96.4 | 0.0 | 0.0 |
| AFTERMATH WITH FRIENDS | 1.0 | +27.0 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | 24.3 | +192.9 | 0.0 | 516.0 | 21.7 | +114.7 | 0.0 | 175.7 |
| ASSAILMENT BY POINTS | 0.3 | +0.3 | 0.0 | 70.3 | - | - | - | - |
| BACKUP TARGETS | 0.3 | +1.0 | 0.0 | 0.0 | 0.3 | +3.0 | 0.0 | 0.0 |
| BLOWS WHERE AIMED | - | - | - | - | 0.3 | -28.3 | 0.0 | 38.7 |
| CARRIES OUT SET-UP | 0.3 | +0.0 | 95.0 | 0.0 | - | - | - | - |
| CAST JOB | - | - | - | - | 1.3 | +14.9 | 49.0 | 0.0 |
| CASTER AWAY FROM SCREEN | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 1.0 | +0.0 | 0.0 | 70.3 | - | - | - | - |
| CASTS FROM BEHIND | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | 1.3 | +41.9 | 0.0 | 30.0 | 1.3 | +11.2 | 0.0 | 0.0 |
| CHAFF PASSED | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| CHALLENGE BY POINTS | 1.3 | +15.8 | 0.0 | 153.0 | 1.0 | +34.8 | 0.0 | 38.3 |
| CHARGE LOSSES | 19.0 | -473.4 | 0.0 | 632.7 | 5.7 | -240.0 | 0.0 | 0.0 |
| CHARGE NOW FIRST | 3.0 | +0.0 | 441.7 | 0.0 | 2.7 | +0.0 | 208.3 | 159.7 |
| CHARGER SLAIN LOST | 0.3 | -4.4 | 0.0 | 0.0 | - | - | - | - |
| CLOSES ON WHAT IT BEATS | 23.0 | +0.0 | 0.0 | 98.0 | 12.0 | +0.0 | 0.0 | 0.0 |
| COMBAT PIVOT | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | 1.0 | +17.3 | 0.0 | 70.3 | - | - | - | - |
| COVER ONCE | 9.0 | -597.8 | 0.0 | 262.0 | 7.3 | -427.7 | 0.0 | 0.0 |
| DENIED BY THE FIGHT | 0.3 | -8.3 | 0.0 | 0.0 | - | - | - | - |
| DEPLOY BY FIGURES | 7.0 | +107.4 | 0.0 | 15.0 | 7.3 | -37.6 | 0.0 | 0.0 |
| EDGE GIVE GROUND | 0.3 | +108.1 | 159.7 | 0.0 | 0.3 | +54.6 | 84.7 | 0.0 |
| EXACT ROUND | 2.7 | +18.5 | 483.3 | 0.0 | 2.7 | -8.7 | 156.3 | 198.3 |
| FACES THE THREAT | 0.3 | +0.0 | 0.0 | 70.3 | - | - | - | - |
| FALL BACK GOOD ORDER | 4.0 | +9.2 | 441.7 | 15.0 | 3.3 | +0.0 | 333.7 | 38.7 |
| FALLBACK BY WORTH | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FALLS SHORT | 23.3 | +304.5 | 0.0 | 482.3 | - | - | - | - |
| FEATURE BUFFS | - | - | - | - | 0.3 | +3.5 | 0.0 | 0.0 |
| FIGHT TO THE END | 2.0 | +56.6 | 323.7 | 0.0 | 1.3 | +64.3 | 0.0 | 198.3 |
| FIVE ACTION | 80.3 | +4139.0 | 536.7 | 1183.0 | 94.3 | +5103.8 | 464.0 | 831.3 |
| FLANK NOT WEIGHED | 7.3 | +0.0 | 0.0 | 286.3 | 10.7 | +0.0 | 0.0 | 69.0 |
| FOLLOW UP WEIGHED | - | - | - | - | 1.0 | +165.8 | 0.0 | 0.0 |
| FOUR ROUNDS | 5.0 | +329.0 | 536.7 | 15.0 | 4.0 | +342.6 | 333.7 | 198.3 |
| FREED FROM HIS FIGHT | 1.3 | +0.0 | 0.0 | 136.7 | 8.7 | +0.0 | 0.0 | 319.3 |
| FRIEND SHOOTS FIRST | - | - | - | - | 0.7 | -2.3 | 0.0 | 0.0 |
| GOAL WALK | 9.0 | +678.5 | 0.0 | 136.7 | 13.7 | +977.2 | 0.0 | 207.0 |
| HARD STAY DROPPED | 0.3 | +0.0 | 0.0 | 70.3 | 3.7 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 1.3 | +0.0 | 0.0 | 136.7 | 5.3 | +0.0 | 0.0 | 0.0 |
| HELPER UNSEEN | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 12.3 | +0.0 | 0.0 | 632.7 | 4.3 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE DENIED | 0.7 | +21.0 | 0.0 | 0.0 | 0.7 | +3.2 | 0.0 | 159.7 |
| HIS CHARGE LIST | 3.7 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 69.0 |
| HIS LEGAL MOVES | 4.0 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 5.0 | -29.0 | 0.0 | 136.7 | 0.3 | -16.9 | 0.0 | 0.0 |
| HIS ONE QUARTER | 1.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 6.0 | +0.0 | 0.0 | 0.0 | 5.0 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVE | 16.0 | +0.0 | 0.0 | 482.0 | 5.7 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVER COMES | 2.0 | +0.0 | 0.0 | 45.3 | 0.3 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 32.3 | +322.9 | 0.0 | 787.3 | 12.0 | +323.7 | 0.0 | 106.7 |
| HIS SHOTS BY HIS RUN | 33.3 | +225.0 | 0.0 | 816.0 | 9.7 | +155.0 | 0.0 | 0.0 |
| HIS TURN RUN | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 16.3 | +0.0 | 0.0 | 162.7 | 16.7 | +0.0 | 0.0 | 0.0 |
| HOLDER ASSIGNMENT | 10.0 | +943.9 | 0.0 | 81.3 | 10.7 | +1213.6 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 0.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 4.3 | -147.2 | 536.7 | 0.0 | 4.0 | -108.5 | 333.7 | 198.3 |
| HUNT IN PAIRS | - | - | - | - | 0.7 | +23.8 | 0.0 | 0.0 |
| IDLE COST | 19.7 | -280.1 | 0.0 | 326.3 | - | - | - | - |
| JOINT CHARGE NOW | 2.7 | +125.1 | 0.0 | 15.0 | 1.0 | +123.6 | 0.0 | 38.7 |
| KEEP FALLS | - | - | - | - | 0.3 | +6.2 | 0.0 | 0.0 |
| KEPT FROM ITS LAST STOP | 1.3 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 1.0 | +42.8 | 0.0 | 0.0 | 0.7 | +13.7 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 5.3 | +0.0 | 133.3 | 140.0 | 8.0 | +0.0 | 271.7 | 281.7 |
| LOST AFTER ESCAPE | 3.0 | +9.9 | 377.0 | 0.0 | 2.7 | +8.9 | 192.3 | 198.3 |
| LOST CHARGE | - | - | - | - | 0.3 | -2.7 | 84.7 | 0.0 |
| MANOEUVRE | 1.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| MARCH AT ESCAPER | - | - | - | - | 0.3 | +5.2 | 0.0 | 0.0 |
| MARCH BY THE SUM | - | - | - | - | 1.0 | +15.9 | 0.0 | 0.0 |
| MARCH OF THE TABLE | - | - | - | - | 0.3 | +17.0 | 0.0 | 0.0 |
| MARCH OVER CASTS | 0.3 | +34.1 | 0.0 | 70.3 | 1.0 | -17.3 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 4.7 | +96.7 | 0.0 | 15.0 | 3.3 | +80.7 | 0.0 | 0.0 |
| MEETS IN TIME | 3.7 | +311.9 | 0.0 | 0.0 | 3.3 | +260.0 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 0.7 | +1.6 | 0.0 | 70.3 | 2.7 | +43.6 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 1.0 | +1.7 | 0.0 | 140.7 | 3.3 | +32.7 | 0.0 | 0.0 |
| MOVE ORDER | 2.0 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 6.3 | +499.1 | 0.0 | 0.0 | 4.3 | +418.5 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 8.3 | +341.7 | 0.0 | 22.7 | 8.7 | +416.6 | 0.0 | 53.3 |
| NEXT CHARGE BY LIST | 5.0 | +430.9 | 0.0 | 0.0 | 4.0 | +427.3 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 3.0 | -226.7 | 441.7 | 0.0 | 3.7 | -197.1 | 333.7 | 198.3 |
| NO LATE CUT | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 2.3 | -0.6 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 4.3 | -46.6 | 0.0 | 15.0 | 4.0 | -129.0 | 0.0 | 69.0 |
| ONE CHECK AFTER THE LAST CHANGE | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 5.0 | -73.7 | 0.0 | 0.0 | 3.0 | -103.2 | 0.0 | 0.0 |
| ONE JOINT FIGURE | 1.3 | +30.0 | 0.0 | 0.0 | 0.3 | +4.9 | 0.0 | 38.7 |
| ONE OBJECTIVE FORMULA | 4.7 | +44.3 | 0.0 | 40.7 | 4.3 | -44.6 | 0.0 | 0.0 |
| ONE PROMISE A TARGET | 0.7 | -39.1 | 0.0 | 0.0 | - | - | - | - |
| ONE ROUTE | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| OVERRUNS AWAY | 0.7 | +6.8 | 53.3 | 0.0 | 0.3 | +1.5 | 84.7 | 0.0 |
| OWN CAST FIRST | - | - | - | - | 0.7 | -1.7 | 0.0 | 0.0 |
| PATHS CROSS | 0.7 | +18.6 | 0.0 | 0.0 | 0.3 | +25.1 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.3 | -2.2 | 0.0 | 0.0 | 0.7 | -6.6 | 0.0 | 0.0 |
| PLAN RESULT | 43.0 | +516.9 | 604.3 | 855.7 | 44.7 | +402.4 | 119.0 | 705.7 |
| PROMISE BELOW ZERO | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 159.7 |
| PROMISE BY ITS OWN SUM | 9.0 | -188.7 | 0.0 | 136.7 | 8.7 | -164.5 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| PURSUES BIG PREY | - | - | - | - | 0.3 | -24.5 | 0.0 | 0.0 |
| QUARTER ODDS | 4.7 | +467.8 | 0.0 | 0.0 | 8.3 | +1283.3 | 0.0 | 0.0 |
| RANDOM MOVE BY FIGURES | 0.7 | +0.0 | 0.0 | 113.3 | 3.7 | +78.1 | 0.0 | 0.0 |
| REAL GROUND | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | 4.7 | +228.1 | 0.0 | 52.7 | 2.7 | +118.5 | 0.0 | 0.0 |
| REDIRECT FOR A FRIEND IN REACH | 1.3 | +0.0 | 0.0 | 30.0 | 3.7 | +0.0 | 0.0 | 0.0 |
| REFORMS TO MEET IT | 2.0 | -21.6 | 0.0 | 0.0 | 2.0 | -93.8 | 0.0 | 0.0 |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 68.3 | 1.0 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | - | - | - | - | 0.3 | +9.5 | 0.0 | 0.0 |
| RISK BY ARC | 3.7 | +192.2 | 536.7 | 15.0 | 3.3 | +136.2 | 293.0 | 198.3 |
| RISK ON THE WAY | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| ROUNDS AFTER TERROR | 1.7 | -35.6 | 122.3 | 0.0 | 0.3 | -7.7 | 40.7 | 0.0 |
| RUN DOWN | 4.3 | -43.5 | 536.7 | 0.0 | 1.7 | -14.6 | 177.3 | 0.0 |
| SCREEN BY WHAT IT SAVES | 2.0 | -110.3 | 0.0 | 60.0 | 1.7 | -36.3 | 0.0 | 0.0 |
| SEARCH SPOT | 0.7 | +31.0 | 0.0 | 0.0 | 0.7 | +33.8 | 0.0 | 0.0 |
| SECOND LOOK | - | - | - | - | 0.3 | +34.3 | 56.7 | 0.0 |
| SET CREDITED ONCE | 2.7 | -45.0 | 0.0 | 84.7 | 2.3 | -28.4 | 0.0 | 0.0 |
| SET UP BY THE SET | 4.7 | +67.6 | 69.0 | 84.7 | 4.0 | -2.4 | 68.3 | 0.0 |
| SHOOTERS ON THE TABLE | 1.3 | +0.0 | 0.0 | 170.7 | 2.7 | +0.0 | 0.0 | 69.0 |
| SHOOTS FROM THE BEST SPOT | - | - | - | - | 0.3 | +0.5 | 0.0 | 0.0 |
| SHOT RISK POINTS | 22.7 | -189.9 | 0.0 | 496.0 | 9.3 | +7.0 | 0.0 | 0.0 |
| SHOTS AFTER THE MOVES | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 0.7 | +23.0 | 0.0 | 0.0 | 8.3 | +75.1 | 0.0 | 159.7 |
| SPELL WORTH | 1.7 | +22.5 | 0.0 | 0.0 | - | - | - | - |
| SPOT AS THE GAME MOVES | 11.0 | +0.0 | 0.0 | 370.0 | 9.7 | +0.0 | 0.0 | 53.3 |
| STAND AND SHOOT | 0.3 | -4.9 | 53.3 | 0.0 | 0.3 | -2.5 | 0.0 | 0.0 |
| STANDS STILL | 12.0 | +0.0 | 0.0 | 276.0 | 44.3 | +0.0 | 130.3 | 0.0 |
| STAY WORTH | 1.0 | +3.8 | 0.0 | 0.0 | 9.3 | +47.5 | 130.3 | 213.0 |
| STRIKE BY THE ODDS | - | - | - | - | 0.3 | +5.8 | 15.0 | 0.0 |
| STUCK PIVOT | 0.3 | +0.0 | 0.0 | 56.7 | 1.0 | +0.0 | 0.0 | 0.0 |
| STUPIDITY NEXT TURN | 2.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SUPPORT ADDS | 10.0 | +1076.0 | 0.0 | 169.3 | 5.3 | +317.2 | 0.0 | 0.0 |
| SUPPORT NARROWED | 0.7 | +0.0 | 69.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| SUPPORT WORKED OUT | 10.0 | +1076.0 | 0.0 | 169.3 | 5.3 | +317.2 | 0.0 | 0.0 |
| SWIFTSTRIDE BY POINTS | - | - | - | - | 0.3 | -3.4 | 0.0 | 159.7 |
| THE DEARER SUM KEEPS ITS PLAN | 1.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 3.0 | +0.0 | 0.0 | 84.7 | 6.0 | +0.0 | 0.0 | 159.7 |
| THE ROW KEEPS ITS WAY | 5.3 | +0.0 | 0.0 | 68.3 | 1.0 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 3.3 | +0.0 | 0.0 | 68.3 | 0.7 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 41.0 | +0.0 | 0.0 | 698.0 | 44.7 | +0.0 | 0.0 | 351.0 |
| TIED UP BY THE SUM | 1.0 | +146.2 | 122.3 | 0.0 | 1.3 | +290.6 | 193.3 | 0.0 |
| TIME ON OUR SIDE | - | - | - | - | 75.0 | +615.6 | 0.0 | 351.0 |
| WAITS AGAIN | 2.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| WHAT THE JOINER ADDS | 0.7 | -44.5 | 190.0 | 0.0 | - | - | - | - |
| WHO FIGHTS | 0.3 | +7.6 | 0.0 | 0.0 | - | - | - | - |
| WHO HITS BACK | 0.3 | +5.0 | 0.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT | 0.3 | +34.6 | 95.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT DANGER | 2.7 | -283.0 | 0.0 | 273.3 | 2.3 | -198.4 | 0.0 | 0.0 |
| WHOLE FIGHT GAIN | 1.0 | +39.8 | 0.0 | 0.0 | - | - | - | - |
| WOUNDS ON THE RANKS | 2.0 | +11.5 | 0.0 | 0.0 | - | - | - | - |

### Rule changes: cora-bb45c30-p36

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 138 | 138 | 74 | 24.67 | +1102 | +14.9 |
| HOLDER ASSIGNMENT | 62 | 62 | 57 | 19.00 | +3960 | +69.5 |
| LEGAL CHARGES ONLY | 40 | 40 | 40 | 13.33 | +0 | +0.0 |
| TIME ON OUR SIDE | 225 | 187 | 34 | 11.33 | +19 | +0.6 |
| FIVE ACTION | 524 | 505 | 30 | 10.00 | +2282 | +76.1 |
| THE TABLE AGAIN | 36 | 36 | 30 | 10.00 | +0 | +0.0 |
| OFF BEST | 25 | 25 | 25 | 8.33 | -527 | -21.1 |
| DEPLOY BY FIGURES | 43 | 43 | 24 | 8.00 | +122 | +5.1 |
| GOAL WALK | 68 | 67 | 23 | 7.67 | +1519 | +66.1 |
| HIS SHOTS BY HIS RUN | 129 | 120 | 22 | 7.33 | +185 | +8.4 |
| HIS SHOT LIST | 133 | 122 | 17 | 5.67 | +99 | +5.8 |
| PROMISE BY ITS OWN SUM | 53 | 53 | 16 | 5.33 | -1060 | -66.2 |
| REDIRECT FOR A FRIEND IN REACH | 15 | 15 | 15 | 5.00 | +0 | +0.0 |
| FOUR ROUNDS | 27 | 27 | 14 | 4.67 | +605 | +43.2 |
| MOVE TO CHARGE COMPUTED | 32 | 26 | 14 | 4.67 | +938 | +67.0 |
| IDLE COST | 59 | 40 | 13 | 4.33 | +129 | +9.9 |
| MEETS IN TIME | 21 | 21 | 13 | 4.33 | +865 | +66.5 |
| MOVE ORDER | 13 | 13 | 13 | 4.33 | +0 | +0.0 |
| NEXT CHARGE BY LIST | 27 | 25 | 13 | 4.33 | +813 | +62.6 |
| HARD STAY DROPPED | 12 | 12 | 12 | 4.00 | +0 | +0.0 |
| JOINT CHARGE NOW | 11 | 11 | 11 | 3.67 | +746 | +67.8 |
| SUPPORT ADDS | 46 | 41 | 11 | 3.67 | +139 | +12.7 |
| SUPPORT WORKED OUT | 46 | 41 | 11 | 3.67 | +139 | +12.7 |
| SET UP BY THE SET | 26 | 26 | 10 | 3.33 | +488 | +48.8 |
| QUARTER ODDS | 39 | 39 | 8 | 2.67 | +957 | +119.7 |
| CHALLENGE BY POINTS | 7 | 7 | 7 | 2.33 | +152 | +21.7 |
| MAX FOR POSITIONING | 24 | 21 | 7 | 2.33 | +3 | +0.4 |
| RANDOM MOVE BY FIGURES | 13 | 13 | 7 | 2.33 | +234 | +33.5 |
| RISK BY ARC | 21 | 21 | 7 | 2.33 | +220 | +31.4 |
| SHOT RISK POINTS | 96 | 89 | 7 | 2.33 | +162 | +23.2 |
| TIED UP BY THE SUM | 7 | 7 | 7 | 2.33 | +214 | +30.6 |
| ADVANCE LANE KEPT | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| CHAFF IN THE MOVE | 8 | 6 | 6 | 2.00 | +0 | +0.0 |
| COVER ONCE | 49 | 36 | 6 | 2.00 | +68 | +11.3 |
| HOLDS AMBUSHERS | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| FALLS SHORT | 70 | 60 | 5 | 1.67 | +6 | +1.1 |
| LANE BY FIGURES | 5 | 5 | 5 | 1.67 | +170 | +33.9 |
| CASTS FROM BEHIND | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| CHARGE NOW FIRST | 17 | 17 | 4 | 1.33 | -157 | -39.3 |
| STAY WORTH | 31 | 26 | 4 | 1.33 | +54 | +13.5 |
| STUCK PIVOT | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| AFTERMATH IN POINTS | 3 | 3 | 3 | 1.00 | +421 | +140.3 |
| AFTERMATH WITH FRIENDS | 3 | 3 | 3 | 1.00 | +81 | +27.0 |
| EXACT ROUND | 16 | 16 | 3 | 1.00 | +14 | +4.7 |
| FIGHT TO THE END | 10 | 10 | 3 | 1.00 | +33 | +10.9 |
| FOLLOW UP WEIGHED | 3 | 3 | 3 | 1.00 | +498 | +165.9 |
| MARCH BY THE SUM | 3 | 3 | 3 | 1.00 | +48 | +16.0 |
| PATHS CROSS | 3 | 3 | 3 | 1.00 | +131 | +43.8 |
| PIVOT GUARDS FLANK | 3 | 3 | 3 | 1.00 | -26 | -8.8 |
| REDIRECT COUNTER | 22 | 19 | 3 | 1.00 | +212 | +70.8 |
| SEARCH SPOT | 4 | 4 | 3 | 1.00 | +194 | +64.8 |
| SHOTS IN THE MOVE | 27 | 20 | 3 | 1.00 | +64 | +21.3 |
| SUPPORT NARROWED | 3 | 3 | 3 | 1.00 | -193 | -64.4 |
| WHOLE FIGHT DANGER | 15 | 13 | 3 | 1.00 | +27 | +8.8 |
| CAST JOB | 4 | 4 | 2 | 0.67 | +14 | +7.0 |
| CHAFF PASSED | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| COMBAT PIVOT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| EDGE GIVE GROUND | 2 | 2 | 2 | 0.67 | +279 | +139.5 |
| HONEST WORTH | 25 | 25 | 2 | 0.67 | +75 | +37.3 |
| ONE FIGHT FORMULA | 24 | 11 | 2 | 0.67 | +4 | +1.8 |
| ONE PROMISE A TARGET | 2 | 2 | 2 | 0.67 | -117 | -58.6 |
| OVERRUNS AWAY | 3 | 3 | 2 | 0.67 | +10 | +5.1 |
| OWN CAST FIRST | 2 | 2 | 2 | 0.67 | -5 | -2.5 |
| WHOLE FIGHT GAIN | 3 | 3 | 2 | 0.67 | +25 | +12.5 |
| ASSAILMENT BY POINTS | 1 | 1 | 1 | 0.33 | +1 | +1.0 |
| CASTER AWAY FROM SCREEN | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FACES THE THREAT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| KEEP FALLS | 1 | 1 | 1 | 0.33 | +26 | +26.0 |
| LOST AFTER ESCAPE | 17 | 17 | 1 | 0.33 | +0 | +0.5 |
| MARCH OF THE TABLE | 1 | 1 | 1 | 0.33 | -51 | -51.1 |
| MISSILES IN THE MOVE | 10 | 5 | 1 | 0.33 | +8 | +7.9 |
| ONE JOINT FIGURE | 5 | 5 | 1 | 0.33 | +0 | +0.4 |
| ONE OBJECTIVE FORMULA | 27 | 26 | 1 | 0.33 | +36 | +36.2 |
| PURSUES BIG PREY | 1 | 1 | 1 | 0.33 | -73 | -73.4 |
| REFUSING RETIRES | 4 | 4 | 1 | 0.33 | -6 | -5.9 |
| RESERVE FALL BACK | 1 | 1 | 1 | 0.33 | +28 | +28.5 |
| SECOND LOOK | 1 | 1 | 1 | 0.33 | +103 | +103.0 |
| STRIKE BY THE ODDS | 1 | 1 | 1 | 0.33 | +17 | +17.4 |
| SWIFTSTRIDE BY POINTS | 1 | 1 | 1 | 0.33 | -10 | -10.1 |
| THE ROW IN ITS ORDER | 27 | 1 | 1 | 0.33 | +0 | +0.0 |
| WHO HITS BACK | 1 | 1 | 1 | 0.33 | +15 | +14.9 |
| WHOLE FIGHT | 1 | 1 | 1 | 0.33 | +21 | +20.8 |
| BACKUP TARGETS | 2 | 1 | 0 | 0.00 | - | - |
| BLOWS WHERE AIMED | 1 | 1 | 0 | 0.00 | - | - |
| CARRIES OUT SET-UP | 1 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 3 | trace | - | - | - | - |
| CHARGE LOSSES | 74 | 67 | 0 | 0.00 | - | - |
| CHARGER SLAIN LOST | 1 | 1 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 105 | 103 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 3 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 22 | 22 | 0 | 0.00 | - | - |
| FALLBACK BY WORTH | 1 | 1 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 1 | 1 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 54 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 30 | 30 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 2 | 2 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 20 | 20 | 0 | 0.00 | - | - |
| HELPER UNSEEN | 1 | 1 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 50 | 44 | 0 | 0.00 | - | - |
| HIS CHARGE DENIED | 4 | 4 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 29 | 29 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 22 | 21 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 16 | 14 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 9 | 9 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 33 | 30 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 65 | 60 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 7 | 7 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN RUN | 18 | 18 | 0 | 0.00 | - | - |
| HOLD ODDS | 99 | 98 | 0 | 0.00 | - | - |
| HUNT IN PAIRS | 2 | not checked | - | - | - | - |
| KEPT FROM ITS LAST STOP | 11 | 10 | 0 | 0.00 | - | - |
| LOST CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| MANOEUVRE | 6 | 6 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 4 | 4 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 2 | 2 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 13 | 6 | 0 | 0.00 | - | - |
| NEARER NOT NEEDED | 51 | 48 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 20 | 20 | 0 | 0.00 | - | - |
| NO LATE CUT | 4 | 3 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 7 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 1 | not checked | - | - | - | - |
| ONE ROUTE | 2 | 2 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 18 | 18 | 0 | 0.00 | - | - |
| PLAN RESULT | 263 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 4 | 4 | 0 | 0.00 | - | - |
| PROMISE KNOWS THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| REAL GROUND | 2 | 2 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 12 | 11 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 1 | not checked | - | - | - | - |
| ROUNDS AFTER TERROR | 6 | 6 | 0 | 0.00 | - | - |
| RUN DOWN | 18 | 18 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 11 | 11 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 15 | 15 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 12 | not checked | - | - | - | - |
| SHOOTS FROM THE BEST SPOT | 1 | 1 | 0 | 0.00 | - | - |
| SHOTS AFTER THE MOVES | 3 | 3 | 0 | 0.00 | - | - |
| SPELL WORTH | 5 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 62 | 54 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 2 | 2 | 0 | 0.00 | - | - |
| STANDS STILL | 169 | 163 | 0 | 0.00 | - | - |
| STUPIDITY NEXT TURN | 6 | 2 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 6 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 19 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 12 | not checked | - | - | - | - |
| THE TABLE BINDS | 257 | not checked | - | - | - | - |
| WAITS AGAIN | 10 | 6 | 0 | 0.00 | - | - |
| WHAT THE JOINER ADDS | 2 | 2 | 0 | 0.00 | - | - |
| WHO FIGHTS | 1 | 1 | 0 | 0.00 | - | - |
| WOUNDS ON THE RANKS | 6 | 6 | 0 | 0.00 | - | - |

### Off best figure: cora-bb45c30-p36

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 3.67 | 3.33 | 24.9 |
| PROMISE BY ITS OWN SUM | rule | 3.00 | 2.33 | 66.2 |
| ARMY TABLE | rule | 2.67 | 2.00 | 21.3 |
| CHARGE NOW FIRST | rule | 0.67 | 0.67 | 39.3 |
| JOINT CHARGE NOW | rule | 1.00 | - | 46.6 |
| PIVOT GUARDS FLANK | rule | 0.33 | 0.67 | 8.8 |
| SUPPORT NARROWED | rule | 0.67 | 0.33 | 64.4 |
| FIGHT ORDER BAND | gate | 0.33 | 0.33 | 1.0 |
| ONE PROMISE A TARGET | rule | 0.67 | - | 58.6 |
| OWN CAST FIRST | rule | - | 0.67 | 2.5 |
| FALLBACK | gate | 0.33 | - | 1.0 |
| HOLDER ASSIGNMENT | rule | 0.33 | - | 73.6 |
| MARCH OF THE TABLE | rule | - | 0.33 | 51.1 |
| PURSUES BIG PREY | rule | - | 0.33 | 73.4 |
| REFUSING RETIRES | rule | 0.33 | - | 5.9 |
| RULE SWITCHED OFF | gate | - | 0.33 | 1.0 |
| SWIFTSTRIDE BY POINTS | rule | - | 0.33 | 10.1 |

### Plans: cora-bb45c30-p36

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 4.0 | 50% | 558 | 517 | 93% |
| Mine | join | 4.3 | 92% | 144 | 0 | 0% |
| Mine | move | 33.7 | 96% | 1825 | 0 | 0% |
| Mine | support | 1.0 | 67% | 0 | 0 | - |
| Opponent | charge | 3.7 | 55% | 445 | 353 | 79% |
| Opponent | join | 0.7 | 100% | 23 | 0 | 0% |
| Opponent | move | 38.0 | 97% | 1904 | 0 | 0% |
| Opponent | shoot | 1.7 | 20% | 97 | 49 | 51% |
| Opponent | support | 0.7 | 100% | 0 | 0 | 0% |

### Battle groups: cora-bb45c30-p36

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 4.7 | 21% | 33% | 0% | - | 0% | 0% | 0% | 100% | 0% |
| Opponent | REDIRECT COUNTER | 2.7 | 0% | - | - | - | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: cora-bb45c30-p36

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 9 | 97 (9) | 0 | 97 | 36 | 67% | 2.7 | 0 (4) | 222 (3) | 156 (2) | 151 (6) | 0 (3) |
| Mine | Character | 9 | 52 (9) | 52 | 0 | 0 | 44% | 3.6 | 95 (2) | 22 (6) | 0 (1) | 66 (6) | 0 (3) |
| Mine | Clean-up | 1 | 172 (1) | 0 | 172 | 100 | 0% | 6.0 | - | - | 172 (1) | 172 (1) | - |
| Mine | Fast | 1 | 0 (1) | 0 | 0 | 100 | 0% | 3.0 | - | 0 (1) | - | - | 0 (1) |
| Mine | Fast Hammer | 6 | 43 (6) | 39 | 4 | 27 | 17% | 3.4 | - | 59 (4) | 0 (2) | 72 (3) | 0 (3) |
| Mine | Hammer | 2 | 6 (2) | 0 | 6 | 34 | 50% | 2.0 | - | 6 (2) | - | 0 (1) | 9 (1) |
| Mine | Holder | 1 | 106 (1) | 0 | 106 | 0 | 0% | 4.0 | 106 (1) | - | - | 106 (1) | - |
| Mine | Support | 2 | 0 (2) | 0 | 0 | 73 | 50% | 2.0 | 0 (1) | 0 (1) | - | 0 (1) | 0 (1) |
| Mine | Wizard | 4 | 0 (4) | 0 | 0 | 39 | 50% | 1.0 | 0 (2) | 0 (1) | 0 (1) | 0 (3) | 0 (1) |
| Opponent | Chaff | 3 | 266 (3) | 0 | 266 | 0 | 67% | 5.0 | 0 (1) | 471 (1) | 0 (1) | 266 (3) | - |
| Opponent | Character | 10 | 39 (10) | 39 | 0 | 41 | 20% | 2.4 | 19 (3) | 71 (5) | 0 (1) | 67 (5) | 17 (4) |
| Opponent | Clean-up | 2 | 0 (2) | 0 | 0 | 0 | 100% | - | - | 0 (2) | - | 0 (1) | 0 (1) |
| Opponent | Fast Hammer | 5 | 39 (5) | 5 | 34 | 32 | 60% | 3.0 | 50 (2) | 0 (1) | 51 (2) | 51 (2) | 33 (3) |
| Opponent | Fragile | 2 | 0 (2) | 0 | 0 | 67 | 0% | 3.0 | 0 (1) | - | 0 (1) | 0 (2) | - |
| Opponent | Hammer | 6 | 38 (6) | 34 | 4 | 0 | 17% | 4.0 | - | 49 (4) | 0 (2) | 65 (3) | 8 (3) |
| Opponent | Holder | 6 | 21 (6) | 0 | 21 | 0 | 67% | 1.5 | 48 (2) | 12 (2) | - | - | 30 (4) |
| Opponent | Shooter | 1 | 38 (1) | 0 | 38 | 100 | 0% | 2.0 | - | - | 38 (1) | 38 (1) | - |

### Charged fights: cora-bb45c30-p36

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Vampire Counts | 2 | 0 | 692 | 3.5 | 1.6 | 198 | 6 | +191 | 3 of 7 | 5 of 7 | +232 | +160 |
| Mine | Warriors of Chaos | 1 | 0 | 275 | 2.0 | 1.0 | 138 | 0 | +138 | 1 of 2 | 2 of 2 | - | +138 |
| **Mine** | all armies | 3 | 0 | 553 | 3.0 | 1.4 | 184 | 5 | +179 | 4 of 9 | 7 of 9 | +232 | +153 |
| Opponent | Warriors of Chaos | 2 | 0 | 223 | 2.5 | 1.2 | 89 | 23 | +66 | 3 of 5 | 4 of 5 | -116 | +112 |
| Opponent | Wood Elf Realms | 1 | 0 | 702 | 5.0 | 1.0 | 140 | 0 | +140 | 0 of 5 | 4 of 5 | - | +140 |
| **Opponent** | all armies | 3 | 0 | 383 | 3.3 | 1.1 | 115 | 12 | +103 | 3 of 10 | 8 of 10 | -116 | +128 |

### Effective charges: cora-bb45c30-p36

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Vampire Counts | 7 | 2 (net +0) | 0 | 0 | 1 (net +697) | 1 (net +0) | 2 (net +217) | 1 | 0% (0 of 6) |
| Mine | Warriors of Chaos | 2 | 0 | 0 | 0 | 0 | 2 (net +138) | 0 | 0 | 0% (0 of 2) |
| Opponent | Warriors of Chaos | 5 | 2 (net -58) | 0 | 1 (net +254) | 1 (net +192) | 0 | 1 (net +0) | 0 | 20% (1 of 5) |
| Opponent | Wood Elf Realms | 5 | 1 (net +0) | 0 | 0 | 0 | 1 (net +122) | 1 (net +205) | 2 | 0% (0 of 3) |

### Charged fights, damage counted: cora-bb45c30-p36

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 2 | 351 | 229 | +0 | 0 | 0 | +0 | +0.0 |
| Mine | 76-89% | 1 | 521 | 198 | +697 | 697 | 0 | +697 | +133.8 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 186 | 479 | +217 | 240 | 22 | +217 | +116.7 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 3 | 565 | 141 | +92 | 150 | 18 | +131 | +23.3 |
| Mine | No odds | 1 | 471 | 207 | +207 | 207 | 0 | +207 | +43.9 |
| Mine | All fights | 9 | 418 | 249 | +179 | 204 | 11 | +192 | +46.1 |
| Opponent | Long shot (under 50%) | 3 | 246 | 301 | -39 | 37 | 68 | -31 | -12.7 |
| Opponent | Effective (55-75%) | 1 | 116 | 254 | +254 | 258 | 0 | +258 | +222.4 |
| Opponent | 76-89% | 1 | 116 | 45 | +192 | 192 | 57 | +135 | +116.7 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 490 | 196 | +102 | 102 | 0 | +102 | +20.9 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 500 | 122 | +122 | 122 | 0 | +122 | +24.4 |
| Opponent | No odds | 2 | 500 | 188 | +188 | 188 | 0 | +188 | +37.5 |
| Opponent | All fights | 10 | 345 | 209 | +103 | 126 | 26 | +100 | +29.1 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| cora-bb45c30-p36 | move | 19 | 4 (21%) | 3 (16%) | 7 (37%) | 8 (42%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L2531, L2730 |
| Charmed Shield | Opponent | L2934 |
| Invocation of Nehek | Mine | L2531, L2730 |
| Ring of Doom | Opponent | L2531 |

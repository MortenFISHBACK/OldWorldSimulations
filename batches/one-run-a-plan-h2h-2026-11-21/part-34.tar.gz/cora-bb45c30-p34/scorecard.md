# Doctrine scorecard: cora-bb45c30-p34

### Scorecard: cora-bb45c30-p34

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L1823 | 5 | 1 | Mine | no | - | 5 | 2 | 2 | 0 | 0 | 0 | 40 |
| L1823 | 5 | 1 | Opponent | yes | - | 2 | 2 | 1 | 1 | 0 | 0 | 0 |
| L1923 | 3 | 1 | Mine | no | 1 | 1 | 5 | 0 | 1 | 0 | 0 | 255 |
| L1923 | 3 | 1 | Opponent | yes | 8 | 2 | 3 | 1 | 0 | 0 | 0 | 327 |
| L2025 | 3 | 1 | Mine | yes | 1 | - | 2 | 3 | 2 | 0 | 0 | 420 |
| L2025 | 3 | 1 | Opponent | no | 0 | 3 | 6 | 1 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 33% | 1.0 | 3.0 | 3.0 | 1.7 | 1.0 | 0.0 | 0.0 | 238.3 |
| **Average** | | | Opponent | 67% | 4.0 | 2.3 | 3.7 | 1.0 | 0.3 | 0.0 | 0.0 | 109.0 |

### KPIs: cora-bb45c30-p34

Rules off - Opponent only: ONE RUN A PLAN.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 12) | 0% (0 of 16) | 0% (0 of 28) |
| Winner chose to follow up after the loser gave ground |  | 60% (3 of 5); on the table 100% | 100% (7 of 7); on the table 100% | 83% (10 of 12); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | - | 50% (1 of 2); on the table 50% | 50% (1 of 2); on the table 50% |
| Winner chose to pursue after the loser fled |  | - | 100% (3 of 3); on the table 100% | 100% (3 of 3); on the table 100% |
| Winner chose to follow up or pursue (all three) |  | 60% (3 of 5); on the table 100% | 92% (11 of 12); on the table 92% | 82% (14 of 17); on the table 94% |
| Magic missiles tried each own turn | 50%+ | 23% (7 of 30) | 11% (2 of 18) | 19% (9 of 48) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 32% (7 of 22) | 11% (2 of 18) | 22% (9 of 40) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 75% (6 of 8) | - | 75% (6 of 8) |
| Points that never fought | lower | 26% (1547 of 5999) | 30% (1800 of 5999) | 28% (3347 of 11998) |
|   infantry points that never fought | lower | 87% (868 of 993) | 73% (762 of 1037) | 80% (1630 of 2030) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 64% (14 of 22) | 44% (7 of 16) | 55% (21 of 38) |
| Bound items with a magic missile used (at least once a game) |  | 100% (1 of 1); 1.0 uses a game | 0.0 uses a game | 100% (1 of 1); 0.5 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 50% (1 of 2); 0.3 uses a game | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 68% (3485 of 5151) | 38% (1723 of 4500) | 54% (5208 of 9651) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 0.7 (9%) | 5.3 (100%) | 6.0 (46%) |
| MARCHED: its unit marched | 1.7 (22%) | 0.0 (0%) | 1.7 (13%) |
| CHARGED: its unit charged | 0.7 (9%) | 0.0 (0%) | 0.7 (5%) |
| IN COMBAT: engaged in combat | 1.7 (22%) | 0.0 (0%) | 1.7 (13%) |
| REAR RANK: in a rear rank | 1.0 (13%) | 0.0 (0%) | 1.0 (8%) |
| GONE: slain | 0.3 (4%) | 0.0 (0%) | 0.3 (3%) |
| OFF THE TABLE: off the table or not arrived | 0.7 (9%) | 0.0 (0%) | 0.7 (5%) |
| NOT OFFERED: not in the cast list | 1.0 (13%) | 0.0 (0%) | 1.0 (8%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 4.7 | 1.7 | 0.3 | 3.0 | 0.7 |
| not cast | 5.3 | 0.3 | 5.7 | 13.0 | 19.3 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.0 (10%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.3 (100%) | 0.0 (0%) | 6.0 (46%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.7 (13%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (5%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.7 (13%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 2.0 (38%) | 0.0 (0%) | 2.0 (35%) | 1.0 (8%) | 0.0 (0%) |
| GONE: slain | 0.3 (6%) | 0.0 (0%) | 0.0 (0%) | 0.3 (3%) | 0.3 (2%) |
| OFF THE TABLE: off the table or not arrived | 0.7 (12%) | 0.0 (0%) | 0.0 (0%) | 0.7 (5%) | 1.0 (5%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.0 (8%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.3 (44%) | 0.0 (0%) | 3.7 (65%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 16.0 (83%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.0 a game | 0.3 a game | 0.2 a game |
| stood (cast and not dispelled) | - | 100% (1 of 1) | 100% (1 of 1) |
| the unit moved after it | - | 100% (1 of 1) | 100% (1 of 1) |
| it charged on its next turn | - | 0% (0 of 1) | 0% (0 of 1) |
| the enemy charged it first | - | 0% (0 of 1) | 0% (0 of 1) |
| it fought by the end of its next turn | - | 0% (0 of 1) | 0% (0 of 1) |
| it moved out of a charge the enemy had planned (not charged first) | - | 0% (0 of 1) | 0% (0 of 1) |
| none of these (no charge, no fight, no charge escaped) | - | 100% (1 of 1) | 100% (1 of 1) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 61% (33 of 54) | 53% (42 of 79) | 56% (75 of 133) |
|   cavalry | - | 74% (14 of 19) | 74% (14 of 19) |
|   character | 80% (4 of 5) | 0% (0 of 17) | 18% (4 of 22) |
|   chariot | 86% (6 of 7) | - | 86% (6 of 7) |
|   infantry | 45% (14 of 31) | 65% (28 of 43) | 57% (42 of 74) |
|   monster | 82% (9 of 11) | - | 82% (9 of 11) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.0 (14%) | 0.0 (0%) | 1.0 (5%) |
| CHARGED: it charged | 0.7 (10%) | 1.3 (11%) | 2.0 (10%) |
| IN COMBAT: it fought this turn or the last | 0.7 (10%) | 0.0 (0%) | 0.7 (3%) |
| NO TARGET IN RANGE | 3.3 (48%) | 6.3 (51%) | 9.7 (50%) |
| ONLY IN COMBAT: the only targets were in combat | 0.7 (10%) | 2.0 (16%) | 2.7 (14%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.7 (10%) | 2.0 (16%) | 2.7 (14%) |
| SHELTERED: the target was sheltered | 0.0 (0%) | 0.7 (5%) | 0.7 (3%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 5.3 | 2.3 | 69% | 5.9 pts | 32 pts |
| character | 1.3 | 0.3 | 75% | 8.1 pts | 11 pts |
| chariot | 2.3 | 2.7 | 43% | 35.8 pts | 84 pts |
| infantry | 16.0 | 6.0 | 75% | 4.4 pts | 70 pts |
| monster | 3.0 | 0.0 | 100% | 0.0 pts | 0 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.7 | 7.0 | 5.3 |
| Charges that made contact a game | 3.0 | 5.7 | 4.3 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.00 declared, 0.00 contact (1 units) | 0.00 declared, 0.00 contact (2 units) | 0.00 declared, 0.00 contact (3 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 2.00 declared, 1.00 contact (1 units) | 2.00 declared, 1.00 contact (1 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.39 declared, 0.32 contact (28 units) | 0.66 declared, 0.55 contact (29 units) | 0.53 declared, 0.44 contact (57 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | - | 67% (2 of 3) | - | 67% (2 of 3) |
| Character in a unit | 100% (1 of 1) | 100% (2 of 2) | - | 100% (3 of 3) |
| Character on its own | 25% (1 of 4) | 0% (0 of 2) | 29% (2 of 7) | 23% (3 of 13) |
| Chariot | 100% (2 of 2) | - | - | 100% (2 of 2) |
| Infantry | 67% (4 of 6) | - | - | 67% (4 of 6) |
| Monster | 25% (1 of 4) | 67% (2 of 3) | - | 43% (3 of 7) |
| Monstrous | - | 100% (4 of 4) | - | 100% (4 of 4) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Ogre Kingdoms | 1 | - | 0% (0 of 6) | 24% | 86% (6 of 7) | 100% (1 of 1); 3.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 1 | - | 33% (4 of 12) | 3% | 50% (4 of 8) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Skaven | 1 | 60% (3 of 5); on the table 100% | 25% (3 of 12) | 51% | 57% (4 of 7) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Tomb Kings of Khemri | 2 | 80% (4 of 5); on the table 80% | 0% (0 of 6) | 41% | 40% (4 of 10) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 1 | 100% (7 of 7); on the table 100% | 17% (2 of 12) | 8% | 50% (3 of 6) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (cora-bb45c30-p34, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 67% (8) | 50% (2) | 62% (10) |
| ...free all their last turn and able to turn (per game) | 2.33 | 0.67 | 3.00 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 1.00 | 0.00 | 1.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: cora-bb45c30-p34

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.7 | 2.3 |
| Strategy | Charge objectives carried out (made contact) | 67% (4 of 6) | 60% (12 of 20) |
| Strategy | Shoot objectives carried out (shot that target) | 25% (5 of 20) | 73% (11 of 15) |
| Strategy | Support requests answered (helper made contact too) | 100% (1 of 1) | 67% (2 of 3) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 0% (0 of 2) | - |
| Strategy | Hexes on a unit its side charged or shot that turn | - | 0% (0 of 2) |
| Strategy | Joined characters whose unit fought | 50% (1 of 2) | 50% (2 of 4) |
| Strategy | Lone characters that fought | 100% (8 of 8) | 71% (5 of 7) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 1.7 | 1.0 |
| Movement | Points that never moved of their own | 238.3 | 109.0 |
| Movement | Fights charged into per game | 2.7 | 4.7 |
| Movement | Charges with odds: long shots (under 50%) | 1 of 5, net +0 | 3 of 14, net +435 |
| Movement | Charges with odds: sweet spot (55-75%) | 1 of 5, net -462 | 1 of 14, net +262 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 1 of 5, net +66 | 3 of 14, net +97 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 0 of 5 | 6 of 14, net +202 |
| Shooting | Shots by shooting units (incl. breath weapons) | 11.3 | 16.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 38% (13 of 34) | 40% (20 of 50) |
| Shooting | Points destroyed by shooting units | 65.0 | 29.7 |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | 1.3 | 0.7 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 75% (3 of 4) | 0% (0 of 2) |
| Magic | Wounds caused by magic missiles | 1.7 | - |
| Magic | Points destroyed by magic (all spells) | 0.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 2.0 / 0.0 / 0.3 / 0.0 | 1.0 / 0.7 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 105.7 | 630.0 |
| Combat | Points run down | 0.0 | 252.7 |
| Combat | Net points per charged fight, damage counted | -54 | +206 |
| Combat | Net per 100 charger points, damage counted | -24.9 | +70.8 |
| Combat | First round won (charged fights) | 50% | 71% |
| Combat | Net points per charged fight | -52 | +234 |
| Combat | Net points per supported fight / lone fight | -462 / +7 | +98 / +272 |
| Combat | Charged fights on a top-3 enemy unit | 3 of 8 | 6 of 14 |
| Game | Points lost | 1247.3 | 170.7 |
| Game | VP from objectives | 273.3 | 1153.3 |
| Game | Lone holders (player turns) | 1.0 | 4.0 |

- Mine won / drew / lost: 0 / 0 / 3 of 3 ended games (of 3); mean margin (Mine - Opponent) -2023 VP
- The side that went first won 2 of 3 games with a winner
- Points traded per game (both sides' losses): 1418
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: cora-bb45c30-p34

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.7 | +7.0 | 0.0 | 43.3 | - | - | - | - |
| AFTERMATH WITH FRIENDS | - | - | - | - | 0.7 | +20.9 | 0.0 | 0.0 |
| ARMY TABLE | 17.3 | +104.7 | 0.0 | 175.7 | 23.7 | +329.7 | 0.0 | 66.0 |
| ASSAILMENT BY POINTS | 0.3 | +2.1 | 0.0 | 180.0 | - | - | - | - |
| BACKUP TARGETS | 0.7 | +2.7 | 0.0 | 76.0 | 1.0 | +7.0 | 0.0 | 0.0 |
| CAST JOB | 1.3 | +149.1 | 0.0 | 0.0 | - | - | - | - |
| CASTER AWAY FROM SCREEN | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 1.7 | +27.9 | 22.0 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | 0.3 | +1.4 | 0.0 | 11.3 | - | - | - | - |
| CHAFF PASSED | 0.3 | -3.8 | 0.0 | 61.7 | 1.0 | -3.4 | 61.7 | 22.0 |
| CHALLENGE BY POINTS | 0.3 | +9.1 | 0.0 | 0.0 | - | - | - | - |
| CHARGE LIST READ AGAIN | - | - | - | - | 0.3 | +0.8 | 61.7 | 0.0 |
| CHARGE LOSSES | 14.0 | -1404.6 | 0.0 | 201.7 | 10.0 | -308.1 | 0.0 | 170.0 |
| CHARGE NOT DECLARED | 0.3 | +0.0 | 22.0 | 0.0 | - | - | - | - |
| CHARGE NOW FIRST | 1.0 | +0.0 | 152.0 | 152.0 | 2.7 | +0.0 | 453.3 | 16.7 |
| CLOSES ON WHAT IT BEATS | 7.7 | +0.0 | 0.0 | 73.3 | 15.0 | +0.0 | 0.0 | 137.0 |
| COMBAT PIVOT | 0.3 | +0.0 | 0.0 | 30.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | - | - | - | - | 0.3 | +22.2 | 0.0 | 0.0 |
| COVER ONCE | 12.3 | -424.9 | 0.0 | 350.7 | 2.0 | -96.1 | 0.0 | 65.0 |
| DENIED BY THE FIGHT | 0.3 | -0.2 | 0.0 | 78.0 | 0.7 | -2.1 | 123.3 | 0.0 |
| DEPLOY BY FIGURES | 7.7 | +43.1 | 0.0 | 36.7 | 7.3 | +33.6 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | - | - | - | - | 0.3 | -197.8 | 131.0 | 0.0 |
| EDGE GIVE GROUND | - | - | - | - | 1.0 | +6.3 | 189.0 | 0.0 |
| EXACT ROUND | 1.0 | +22.2 | 0.0 | 94.3 | 5.0 | +21.4 | 825.7 | 0.0 |
| FALL BACK GOOD ORDER | 2.0 | +0.0 | 22.0 | 172.3 | 4.7 | +0.1 | 610.0 | 33.3 |
| FALLS SHORT | 2.7 | +56.2 | 0.0 | 140.0 | 18.3 | +203.9 | 0.0 | 65.0 |
| FEATURE BUFFS | 2.0 | +16.3 | 0.0 | 26.7 | 1.3 | +14.2 | 0.0 | 0.0 |
| FIGHT TO THE END | 0.3 | +2.9 | 0.0 | 0.0 | 3.7 | +40.8 | 406.7 | 33.3 |
| FIRE IN ORDER | 0.3 | +0.0 | 0.0 | 78.0 | 0.3 | +0.0 | 13.3 | 0.0 |
| FIVE ACTION | 72.3 | +4242.9 | 629.0 | 1788.7 | 104.7 | +8999.8 | 1391.7 | 519.3 |
| FLANK NOT WEIGHED | 14.7 | +0.0 | 0.0 | 539.0 | 1.7 | +0.0 | 0.0 | 25.0 |
| FOLLOW UP WEIGHED | - | - | - | - | 2.7 | +371.1 | 0.0 | 0.0 |
| FOUR ROUNDS | 2.0 | +78.3 | 22.0 | 172.3 | 7.0 | +759.5 | 1018.3 | 33.3 |
| FREED FROM HIS FIGHT | 6.3 | +0.0 | 0.0 | 52.3 | 1.0 | +0.0 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 2.0 | -10.8 | 0.0 | 11.3 | 1.7 | -4.9 | 0.0 | 0.0 |
| FRIENDS SHOTS CHECKED | - | - | - | - | 0.3 | +21.7 | 0.0 | 0.0 |
| GIVES UP | - | - | - | - | 1.0 | -18.1 | 78.3 | 16.7 |
| GOAL WALK | 9.7 | +740.0 | 0.0 | 61.7 | 7.3 | +551.2 | 0.0 | 75.0 |
| GUN FIGURES | 3.3 | +52.9 | 65.0 | 123.3 | - | - | - | - |
| HARD STAY DROPPED | 1.3 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 3.7 | +0.0 | 0.0 | 40.0 | - | - | - | - |
| HELPER UNSEEN | 0.3 | +0.0 | 0.0 | 78.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 13.7 | +0.0 | 0.0 | 201.7 | 4.7 | +0.0 | 0.0 | 170.0 |
| HIS CHARGE DENIED | 0.7 | +72.9 | 0.0 | 154.0 | - | - | - | - |
| HIS CHARGE LIST | 5.0 | +0.0 | 0.0 | 73.3 | 1.0 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 5.3 | +0.0 | 0.0 | 123.3 | 4.3 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 3.3 | -5.5 | 0.0 | 78.3 | 8.0 | -78.1 | 0.0 | 131.0 |
| HIS ONE QUARTER | 2.0 | +0.0 | 0.0 | 51.3 | 6.7 | +0.0 | 0.0 | 44.0 |
| HIS OWN BEST MOVE | 7.3 | +0.0 | 0.0 | 123.3 | 10.7 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVE | - | - | - | - | 8.0 | +0.0 | 0.0 | 100.0 |
| HIS RANDOM MOVER COMES | - | - | - | - | 2.3 | +0.0 | 0.0 | 25.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 35.7 | +191.5 | 0.0 | 701.7 | 41.3 | +958.8 | 0.0 | 172.0 |
| HIS SHOTS BY HIS RUN | 28.7 | +188.3 | 0.0 | 541.7 | 37.7 | +564.9 | 0.0 | 344.0 |
| HIS TURN DENIED | 0.3 | +1.0 | 22.0 | 0.0 | 0.7 | +13.4 | 123.3 | 0.0 |
| HIS TURN RUN | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 12.0 | +0.0 | 0.0 | 157.0 | 20.7 | +0.0 | 0.0 | 256.0 |
| HOLDER ASSIGNMENT | 7.7 | +459.0 | 0.0 | 96.3 | 11.3 | +1041.7 | 0.0 | 150.0 |
| HOLDS AMBUSHERS | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 0.7 | -46.9 | 22.0 | 18.3 | 5.0 | -157.9 | 866.7 | 0.0 |
| HUNT IN PAIRS | - | - | - | - | 0.7 | +70.3 | 0.0 | 0.0 |
| IDLE COST | 1.3 | -33.8 | 0.0 | 0.0 | 11.3 | -157.0 | 0.0 | 50.0 |
| JOINT CHARGE NOW | 0.7 | +122.0 | 0.0 | 154.0 | 2.7 | -25.1 | 406.0 | 16.7 |
| JOINT LOOK BACK | - | - | - | - | 0.3 | +33.3 | 78.3 | 0.0 |
| JOINT ON THE TABLE | - | - | - | - | 0.3 | +10.2 | 61.7 | 0.0 |
| KEPT FROM ITS LAST STOP | 1.0 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 0.3 | +6.3 | 0.0 | 0.0 | 1.7 | +89.0 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 5.3 | +0.0 | 0.0 | 510.3 | 12.3 | +0.0 | 916.0 | 150.0 |
| LONE WIZARD KEPT IN | 0.3 | +16.1 | 0.0 | 0.0 | 0.7 | +39.2 | 0.0 | 0.0 |
| LONG SHOT | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +2.6 | 0.0 | 33.3 |
| LOST AFTER ESCAPE | 0.7 | -0.5 | 0.0 | 0.0 | 4.0 | +3.8 | 395.7 | 33.3 |
| LOST CHARGE | - | - | - | - | 0.3 | -0.2 | 85.0 | 0.0 |
| MAKE SURE TOGETHER | - | - | - | - | 0.3 | +5.2 | 0.0 | 0.0 |
| MANOEUVRE | 2.7 | +9.1 | 0.0 | 0.0 | 1.3 | -4.0 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.3 | +1.4 | 0.0 | 0.0 | - | - | - | - |
| MARCH BY THE SUM | 0.7 | +29.8 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | 1.0 | +34.5 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 0.7 | -13.6 | 0.0 | 0.0 | - | - | - | - |
| MARCH WHEELS ONLY | 0.7 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 4.0 | +80.1 | 0.0 | 13.3 | 2.0 | +75.5 | 0.0 | 25.0 |
| MEETS IN TIME | 3.7 | +210.7 | 0.0 | 18.3 | 2.3 | +191.0 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 4.0 | +69.5 | 0.0 | 0.0 | 1.0 | +3.0 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 5.3 | +61.8 | 0.0 | 180.0 | 3.3 | +11.6 | 0.0 | 0.0 |
| MOVE ORDER | 1.7 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 25.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 4.7 | +138.5 | 0.0 | 23.3 | 12.3 | +1849.7 | 0.0 | 0.0 |
| MOVES UNITS SPELL | 0.3 | +1.4 | 0.0 | 0.0 | - | - | - | - |
| NEARER NOT NEEDED | 9.3 | +396.8 | 0.0 | 26.7 | 12.0 | +401.7 | 0.0 | 42.0 |
| NEXT CHARGE BY LIST | 3.3 | +86.7 | 0.0 | 0.0 | 8.7 | +1446.5 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 1.3 | -52.8 | 0.0 | 172.3 | 5.3 | -346.0 | 791.7 | 0.0 |
| NO LATE CUT | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 5.7 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 1.7 | -0.8 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 2.3 | -44.1 | 0.0 | 39.0 | 5.0 | -220.4 | 0.0 | 62.0 |
| ONE CHECK AFTER THE LAST CHANGE | 1.3 | +0.0 | 0.0 | 25.0 | - | - | - | - |
| ONE FIGHT FORMULA | 3.0 | -21.2 | 0.0 | 106.0 | 8.7 | -215.6 | 0.0 | 25.0 |
| ONE JOINT FIGURE | 0.3 | +9.7 | 0.0 | 76.0 | 1.7 | +188.0 | 192.7 | 33.3 |
| ONE OBJECTIVE FORMULA | 5.3 | -95.3 | 0.0 | 78.0 | 4.3 | +1.6 | 0.0 | 86.0 |
| ONE PROMISE A TARGET | 0.3 | -0.5 | 0.0 | 0.0 | - | - | - | - |
| ONE ROUTE | 0.7 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| OPENS A LANE | 0.3 | +0.9 | 65.0 | 0.0 | - | - | - | - |
| OPENS UP | - | - | - | - | 0.3 | +14.1 | 25.7 | 0.0 |
| OVERRUNS AWAY | - | - | - | - | 1.7 | +15.1 | 213.3 | 0.0 |
| PERIAPT WORTH | 0.3 | +18.1 | 0.0 | 0.0 | - | - | - | - |
| PLAN RESULT | 36.7 | +345.5 | 217.0 | 1529.3 | 49.3 | +827.9 | 780.0 | 294.3 |
| PROMISE BELOW ZERO | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| PROMISE BY ITS OWN SUM | 6.0 | -36.6 | 0.0 | 23.3 | 12.3 | -467.4 | 0.0 | 0.0 |
| PROMISE IN STEPS | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | 1.3 | +0.0 | 0.0 | 23.3 | 0.7 | +0.0 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | 0.7 | -2.4 | 0.0 | 11.3 | 0.7 | -81.0 | 0.0 | 0.0 |
| PROMISE SHOT AWAY | 0.7 | -16.4 | 130.0 | 123.3 | - | - | - | - |
| QUARTER ODDS | 12.3 | +1041.8 | 0.0 | 256.7 | 28.7 | +3492.5 | 444.0 | 44.0 |
| RANDOM MOVE BY FIGURES | 2.7 | +130.5 | 0.0 | 0.0 | - | - | - | - |
| REAL GROUND | 0.7 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | 3.7 | +304.1 | 0.0 | 61.3 | 3.3 | +110.8 | 0.0 | 69.0 |
| REDIRECT FOR A FRIEND IN REACH | 2.3 | +0.0 | 0.0 | 105.3 | 5.7 | +0.0 | 0.0 | 44.0 |
| REFORMS TO MEET IT | 1.0 | -71.0 | 0.0 | 0.0 | 1.3 | -87.1 | 0.0 | 0.0 |
| REFUSING RETIRES | - | - | - | - | 0.3 | +0.0 | 0.0 | 16.7 |
| RESERVE FALL BACK | - | - | - | - | 1.0 | +27.0 | 0.0 | 0.0 |
| RESTRAINS TO SHOOT | - | - | - | - | 0.3 | +9.0 | 0.0 | 0.0 |
| RISK BY ARC | 1.7 | +81.5 | 22.0 | 172.3 | 5.3 | -22.1 | 922.7 | 16.7 |
| ROUNDS AFTER TERROR | - | - | - | - | 4.0 | -115.6 | 636.7 | 33.3 |
| RUN DOWN | - | - | - | - | 5.7 | -55.0 | 768.3 | 33.3 |
| SCOUT SPOT | 0.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| SCOUT WAITS | 1.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| SEARCH SPOT | 1.0 | +7.5 | 0.0 | 0.0 | 1.7 | +76.3 | 0.0 | 22.0 |
| SELF MOVE SPELL | 2.0 | -4.2 | 0.0 | 217.3 | - | - | - | - |
| SET CREDITED ONCE | 0.3 | -0.9 | 0.0 | 11.3 | 2.7 | -241.9 | 0.0 | 0.0 |
| SET UP BY THE SET | 3.7 | -40.4 | 130.0 | 163.3 | 5.3 | +247.7 | 0.0 | 0.0 |
| SET UP TOGETHER | - | - | - | - | 0.3 | +5.2 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | - | - | - | - | 0.3 | +1.7 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 5.0 | +0.0 | 0.0 | 277.3 | 5.3 | +0.0 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 6.0 | +70.1 | 65.0 | 0.0 | 0.3 | +2.0 | 0.0 | 0.0 |
| SHOT OR CHARGE | - | - | - | - | 0.7 | -1.2 | 131.0 | 0.0 |
| SHOT RISK POINTS | 14.3 | -109.8 | 0.0 | 248.7 | 26.7 | +336.6 | 0.0 | 153.0 |
| SHOTS AFTER THE MOVES | 2.7 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 11.0 | +350.9 | 0.0 | 391.3 | 14.7 | +99.5 | 0.0 | 128.0 |
| SPELL OFF EDGE | 0.7 | +146.2 | 0.0 | 0.0 | - | - | - | - |
| SPELL WORTH | 1.7 | +32.6 | 180.0 | 180.0 | - | - | - | - |
| SPOT AS THE GAME MOVES | 9.0 | +0.0 | 0.0 | 338.0 | 6.7 | +0.0 | 0.0 | 0.0 |
| STAND AND SHOOT | 0.3 | -0.5 | 0.0 | 18.3 | 0.7 | -8.5 | 83.3 | 0.0 |
| STANDS FOR A REASON | 1.7 | +0.0 | 22.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 25.3 | +0.0 | 607.0 | 731.3 | 40.7 | +0.0 | 373.3 | 0.0 |
| STAY WORTH | 8.3 | +37.7 | 152.0 | 185.0 | 17.7 | +93.9 | 263.3 | 86.0 |
| STUPIDITY NEXT TURN | - | - | - | - | 2.0 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 10.0 | +1842.2 | 0.0 | 52.3 | 6.3 | +324.9 | 0.0 | 0.0 |
| SUPPORT NARROWED | - | - | - | - | 0.7 | +0.0 | 0.0 | 16.7 |
| SUPPORT WORKED OUT | 10.0 | +1842.2 | 0.0 | 52.3 | 6.3 | +324.9 | 0.0 | 0.0 |
| SURE REACH TOGETHER | - | - | - | - | 1.0 | +17.2 | 0.0 | 65.0 |
| SWIFTSTRIDE BY POINTS | 0.7 | +21.2 | 0.0 | 142.3 | - | - | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 1.0 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 22.0 |
| THE PROMISE ADDS | - | - | - | - | 0.7 | -81.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 3.0 | +0.0 | 0.0 | 180.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 2.7 | +0.0 | 0.0 | 88.0 | 4.7 | +0.0 | 0.0 | 65.0 |
| THE STEP BACK IS MADE | 3.0 | +0.0 | 0.0 | 51.3 | 2.0 | +0.0 | 0.0 | 65.0 |
| THE TABLE AGAIN | 5.7 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 30.0 | +0.0 | 0.0 | 675.0 | 50.3 | +0.0 | 0.0 | 243.0 |
| TIED UP BY THE SUM | 0.3 | +82.5 | 22.0 | 0.0 | 1.7 | +130.7 | 333.3 | 0.0 |
| TIME ON OUR SIDE | 33.3 | +363.4 | 195.0 | 668.7 | 19.7 | +172.3 | 0.0 | 106.0 |
| WAITS AGAIN | 2.3 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| WAR ENGINE JOBS | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WEAPON BY POINTS | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| WHAT THE JOINER ADDS | - | - | - | - | 0.7 | -6.2 | 140.0 | 0.0 |
| WHO FIGHTS | 0.7 | -4.1 | 0.0 | 18.3 | 1.0 | -3.2 | 140.7 | 0.0 |
| WHO GETS IN | - | - | - | - | 0.7 | +2.8 | 73.3 | 0.0 |
| WHO HITS BACK | 0.3 | +37.4 | 0.0 | 0.0 | 0.3 | +49.0 | 0.0 | 0.0 |
| WHOLE FIGHT | - | - | - | - | 0.3 | +3.1 | 70.0 | 0.0 |
| WHOLE FIGHT DANGER | 7.0 | -1338.2 | 0.0 | 201.7 | 2.3 | -114.8 | 0.0 | 170.0 |
| WHOLE FIGHT GAIN | - | - | - | - | 0.3 | +38.9 | 131.0 | 0.0 |
| WOUNDS ON THE RANKS | 1.7 | +26.1 | 0.0 | 0.0 | 0.7 | +0.4 | 0.0 | 0.0 |

### Rule changes: cora-bb45c30-p34

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 123 | 123 | 89 | 29.67 | +677 | +7.6 |
| LEGAL CHARGES ONLY | 53 | 53 | 53 | 17.67 | +0 | +0.0 |
| HOLDER ASSIGNMENT | 57 | 57 | 51 | 17.00 | +2992 | +58.7 |
| HIS SHOT LIST | 231 | 226 | 45 | 15.00 | +187 | +4.1 |
| FIVE ACTION | 531 | 522 | 43 | 14.33 | +3659 | +85.1 |
| HIS SHOTS BY HIS RUN | 199 | 196 | 28 | 9.33 | +123 | +4.4 |
| THE TABLE AGAIN | 35 | 35 | 28 | 9.33 | +0 | +0.0 |
| MOVE TO CHARGE COMPUTED | 51 | 46 | 24 | 8.00 | +1971 | +82.1 |
| REDIRECT FOR A FRIEND IN REACH | 24 | 24 | 24 | 8.00 | +0 | +0.0 |
| OFF BEST | 22 | 22 | 22 | 7.33 | -793 | -36.1 |
| SUPPORT ADDS | 49 | 49 | 22 | 7.33 | +374 | +17.0 |
| SUPPORT WORKED OUT | 49 | 49 | 22 | 7.33 | +374 | +17.0 |
| DEPLOY BY FIGURES | 45 | 45 | 19 | 6.33 | +155 | +8.1 |
| NEXT CHARGE BY LIST | 36 | 35 | 17 | 5.67 | +1878 | +110.5 |
| HARD STAY DROPPED | 16 | 16 | 16 | 5.33 | +0 | +0.0 |
| TIME ON OUR SIDE | 159 | 143 | 16 | 5.33 | +43 | +2.7 |
| PROMISE BY ITS OWN SUM | 55 | 55 | 15 | 5.00 | -1512 | -100.8 |
| SHOOTS FROM THE BEST SPOT | 19 | 19 | 14 | 4.67 | +20 | +1.4 |
| GOAL WALK | 51 | 50 | 13 | 4.33 | +272 | +20.9 |
| MOVE ORDER | 13 | 13 | 13 | 4.33 | +0 | +0.0 |
| SHOT RISK POINTS | 123 | 121 | 13 | 4.33 | +127 | +9.8 |
| FOUR ROUNDS | 27 | 27 | 11 | 3.67 | +1171 | +106.4 |
| JOINT CHARGE NOW | 10 | 10 | 10 | 3.33 | +291 | +29.1 |
| QUARTER ODDS | 123 | 123 | 10 | 3.33 | +608 | +60.8 |
| SET UP BY THE SET | 27 | 27 | 9 | 3.00 | +351 | +39.0 |
| ADVANCE LANE KEPT | 8 | 8 | 8 | 2.67 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 8 | 8 | 8 | 2.67 | +1113 | +139.2 |
| MEETS IN TIME | 18 | 18 | 8 | 2.67 | +507 | +63.4 |
| WHOLE FIGHT DANGER | 28 | 25 | 8 | 2.67 | +955 | +119.4 |
| CHARGE LOSSES | 72 | 69 | 7 | 2.33 | +1122 | +160.2 |
| COVER ONCE | 43 | 34 | 7 | 2.33 | +34 | +4.9 |
| RISK BY ARC | 21 | 21 | 7 | 2.33 | +92 | +13.2 |
| SCOUT WAITS | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| LANE BY FIGURES | 6 | 6 | 6 | 2.00 | +286 | +47.6 |
| RANDOM MOVE BY FIGURES | 8 | 8 | 6 | 2.00 | +391 | +65.2 |
| SEARCH SPOT | 8 | 8 | 6 | 2.00 | +252 | +41.9 |
| STAY WORTH | 78 | 73 | 6 | 2.00 | +18 | +3.0 |
| CASTER AWAY FROM SCREEN | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| CHAFF PASSED | 4 | 4 | 4 | 1.33 | -22 | -5.4 |
| MAX FOR POSITIONING | 18 | 16 | 4 | 1.33 | +17 | +4.3 |
| SHOTS IN THE MOVE | 77 | 66 | 4 | 1.33 | +12 | +3.1 |
| CASTING BLOCK | 5 | 5 | 3 | 1.00 | +1 | +0.3 |
| CHARGE NOW FIRST | 11 | 11 | 3 | 1.00 | -137 | -45.8 |
| EXACT ROUND | 18 | 18 | 3 | 1.00 | +33 | +10.9 |
| HOLDS AMBUSHERS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| LONE WIZARD KEPT IN | 3 | 3 | 3 | 1.00 | +166 | +55.3 |
| MANOEUVRE | 12 | 12 | 3 | 1.00 | +29 | +9.7 |
| ONE JOINT FIGURE | 6 | 6 | 3 | 1.00 | +15 | +5.0 |
| RESERVE FALL BACK | 3 | 3 | 3 | 1.00 | +81 | +27.0 |
| TIED UP BY THE SUM | 6 | 6 | 3 | 1.00 | +93 | +30.9 |
| AFTERMATH IN POINTS | 2 | 2 | 2 | 0.67 | +21 | +10.4 |
| AFTERMATH WITH FRIENDS | 2 | 2 | 2 | 0.67 | +63 | +31.3 |
| CAST JOB | 4 | 4 | 2 | 0.67 | +218 | +109.1 |
| CASTS FROM BEHIND | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| COMBAT PIVOT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| FEATURE BUFFS | 10 | 10 | 2 | 0.67 | +1 | +0.6 |
| FIGHT TO THE END | 12 | 12 | 2 | 0.67 | +7 | +3.4 |
| FIRE IN ORDER | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| MARCH BY THE SUM | 2 | 2 | 2 | 0.67 | +90 | +44.8 |
| MARCH CHECK | 3 | 3 | 2 | 0.67 | +35 | +17.5 |
| ONE FIGHT FORMULA | 35 | 23 | 2 | 0.67 | +94 | +47.2 |
| PROMISE SHOT AWAY | 2 | 2 | 2 | 0.67 | -49 | -24.6 |
| SWIFTSTRIDE BY POINTS | 2 | 2 | 2 | 0.67 | +64 | +31.8 |
| WHO GETS IN | 2 | 2 | 2 | 0.67 | +8 | +4.2 |
| WHO HITS BACK | 2 | 2 | 2 | 0.67 | +143 | +71.5 |
| WOUNDS ON THE RANKS | 7 | 7 | 2 | 0.67 | +14 | +7.1 |
| ASSAILMENT BY POINTS | 1 | 1 | 1 | 0.33 | +6 | +6.3 |
| CHALLENGE BY POINTS | 1 | 1 | 1 | 0.33 | +27 | +27.4 |
| CHARGE LIST READ AGAIN | 1 | 1 | 1 | 0.33 | +2 | +2.5 |
| CHARGE NOT DECLARED | 1 | 1 | 1 | 0.33 | -50 | -49.9 |
| EDGE GIVE GROUND | 3 | 3 | 1 | 0.33 | +1 | +1.2 |
| FALLS SHORT | 63 | 55 | 1 | 0.33 | +0 | +0.0 |
| FRIENDS SHOTS CHECKED | 1 | 1 | 1 | 0.33 | +65 | +65.0 |
| HIS CHARGE DENIED | 2 | 2 | 1 | 0.33 | +37 | +37.0 |
| HIS TURN DENIED | 3 | 3 | 1 | 0.33 | +7 | +7.1 |
| HONEST WORTH | 17 | 17 | 1 | 0.33 | +1 | +1.2 |
| IDLE COST | 38 | 23 | 1 | 0.33 | +4 | +4.2 |
| JOINT LOOK BACK | 1 | 1 | 1 | 0.33 | +100 | +99.9 |
| JOINT ON THE TABLE | 1 | 1 | 1 | 0.33 | +31 | +30.6 |
| LONG SHOT | 4 | 4 | 1 | 0.33 | +2 | +2.4 |
| MOVES UNITS SPELL | 1 | 1 | 1 | 0.33 | +4 | +4.3 |
| NEARER NOT NEEDED | 64 | 61 | 1 | 0.33 | +52 | +51.9 |
| NO DOUBLE ROUNDS | 20 | 20 | 1 | 0.33 | +1 | +1.2 |
| ONE OBJECTIVE FORMULA | 29 | 19 | 1 | 0.33 | +7 | +7.2 |
| ONE PROMISE A TARGET | 1 | 1 | 1 | 0.33 | -2 | -1.6 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.33 | +54 | +54.4 |
| REDIRECT COUNTER | 21 | 20 | 1 | 0.33 | +13 | +13.3 |
| REFUSING RETIRES | 1 | 1 | 1 | 0.33 | -10 | -9.6 |
| RESTRAINS TO SHOOT | 1 | 1 | 1 | 0.33 | +27 | +27.1 |
| SHOOTERS IN TWO RANKS | 1 | 1 | 1 | 0.33 | +5 | +5.0 |
| SHOTS AFTER THE MOVES | 17 | 17 | 1 | 0.33 | +0 | +0.0 |
| SUPPORT NARROWED | 2 | 2 | 1 | 0.33 | -0 | -0.3 |
| WEAPON BY POINTS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| BACKUP TARGETS | 5 | 5 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 1 | trace | - | - | - | - |
| CHAFF IN THE MOVE | 1 | 1 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 68 | 68 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 1 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 3 | 3 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 1 | 1 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 20 | 20 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 49 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 22 | 22 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 11 | 11 | 0 | 0.00 | - | - |
| GIVES UP | 3 | 3 | 0 | 0.00 | - | - |
| GUN FIGURES | 10 | not checked | - | - | - | - |
| HE REFORMS ONCE FREED | 11 | 11 | 0 | 0.00 | - | - |
| HELPER UNSEEN | 2 | 2 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 55 | 54 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 18 | 18 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 29 | 26 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 34 | 33 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 26 | 26 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 54 | 51 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 24 | 22 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 7 | 5 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN RUN | 18 | 18 | 0 | 0.00 | - | - |
| HOLD ODDS | 98 | 98 | 0 | 0.00 | - | - |
| HUNT IN PAIRS | 2 | 2 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 15 | 15 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 4 | 4 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 14 | 14 | 0 | 0.00 | - | - |
| LOST CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 1 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 2 | 2 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 8 | 8 | 0 | 0.00 | - | - |
| MISSILES IN THE MOVE | 15 | 9 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 26 | 16 | 0 | 0.00 | - | - |
| NO LATE CUT | 2 | 2 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 35 | 35 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 5 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 4 | not checked | - | - | - | - |
| ONE ROUTE | 8 | 8 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 18 | 18 | 0 | 0.00 | - | - |
| OPENS A LANE | 1 | not checked | - | - | - | - |
| OPENS UP | 1 | 1 | 0 | 0.00 | - | - |
| OVERRUNS AWAY | 5 | 5 | 0 | 0.00 | - | - |
| PLAN RESULT | 258 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 2 | 2 | 0 | 0.00 | - | - |
| PROMISE IN STEPS | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE KNOWS THE FIGHT | 6 | 4 | 0 | 0.00 | - | - |
| PROMISE READS THE TABLE | 4 | 4 | 0 | 0.00 | - | - |
| REAL GROUND | 8 | 8 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 7 | 7 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 12 | 12 | 0 | 0.00 | - | - |
| RUN DOWN | 17 | 17 | 0 | 0.00 | - | - |
| SCOUT SPOT | 6 | 6 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 6 | not checked | - | - | - | - |
| SET CREDITED ONCE | 9 | 9 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 1 | 1 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 31 | not checked | - | - | - | - |
| SHOT OR CHARGE | 2 | 2 | 0 | 0.00 | - | - |
| SPELL OFF EDGE | 2 | not checked | - | - | - | - |
| SPELL WORTH | 5 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 47 | 41 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 3 | 3 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 6 | 6 | 0 | 0.00 | - | - |
| STANDS STILL | 198 | 195 | 0 | 0.00 | - | - |
| STUPIDITY NEXT TURN | 6 | 4 | 0 | 0.00 | - | - |
| SURE REACH TOGETHER | 3 | 3 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 8 | not checked | - | - | - | - |
| THE PROMISE ADDS | 2 | 2 | 0 | 0.00 | - | - |
| THE ROW IN ITS ORDER | 12 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 22 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 15 | not checked | - | - | - | - |
| THE TABLE BINDS | 241 | not checked | - | - | - | - |
| WAITS AGAIN | 16 | 16 | 0 | 0.00 | - | - |
| WAR ENGINE JOBS | 2 | 2 | 0 | 0.00 | - | - |
| WHAT THE JOINER ADDS | 2 | 2 | 0 | 0.00 | - | - |
| WHO FIGHTS | 5 | 5 | 0 | 0.00 | - | - |
| WHOLE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| WHOLE FIGHT GAIN | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: cora-bb45c30-p34

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 2.33 | 5.00 | 36.1 |
| ARMY TABLE | rule | 4.33 | 0.67 | 23.7 |
| PROMISE BY ITS OWN SUM | rule | 1.00 | 4.00 | 100.8 |
| JOINT CHARGE NOW | rule | - | 1.67 | 30.1 |
| CHAFF PASSED | rule | 0.33 | 1.00 | 5.4 |
| CHARGE NOW FIRST | rule | - | 1.00 | 45.8 |
| PROMISE SHOT AWAY | rule | 0.67 | - | 24.6 |
| CHARGE NOT DECLARED | rule | 0.33 | - | 49.9 |
| DEPLOY BY FIGURES | rule | 0.33 | - | 1.1 |
| HOLDER ASSIGNMENT | rule | 0.33 | - | 12.9 |
| ONE PROMISE A TARGET | rule | 0.33 | - | 1.6 |
| REFUSING RETIRES | rule | - | 0.33 | 9.6 |
| WHO GETS IN | rule | - | 0.33 | 21.5 |

### Plans: cora-bb45c30-p34

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.7 | 40% | 180 | 28 | 16% |
| Mine | move | 28.7 | 87% | 2057 | 0 | 0% |
| Mine | shoot | 6.3 | 53% | 354 | 317 | 90% |
| Opponent | charge | 6.0 | 78% | 991 | 758 | 76% |
| Opponent | join | 2.0 | 100% | 76 | 0 | 0% |
| Opponent | move | 37.3 | 96% | 2626 | 0 | 0% |
| Opponent | shoot | 4.0 | 50% | 140 | 70 | 50% |

### Battle groups: cora-bb45c30-p34

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 3.7 | 9% | 100% | 0% | - | 0% | 0% | 100% | 0% | 0% |
| Opponent | REDIRECT COUNTER | 3.3 | 40% | 50% | 0% | - | 25% | 0% | 25% | 50% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: cora-bb45c30-p34

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 1 | 0 (1) | 0 | 0 | 100 | 0% | 3.0 | - | 0 (1) | - | - | 0 (1) |
| Mine | Chaff | 7 | 9 (7) | 0 | 9 | 100 | 57% | 3.0 | 10 (6) | 0 (1) | - | 9 (7) | - |
| Mine | Character | 8 | 23 (8) | 23 | 0 | 71 | 0% | 2.2 | 18 (4) | - | 36 (1) | - | 23 (5) |
| Mine | Clean-up | 4 | 87 (4) | 0 | 87 | 0 | 75% | 3.0 | 93 (2) | 0 (1) | 474 (1) | 188 (1) | 42 (3) |
| Mine | Fast Hammer | 1 | 0 (1) | 0 | 0 | 115 | 0% | 2.0 | 0 (1) | - | - | - | 0 (1) |
| Mine | Hammer | 11 | 3 (11) | 3 | 0 | 67 | 9% | 2.3 | 0 (3) | 5 (7) | 0 (1) | 0 (4) | 6 (7) |
| Mine | Shooter | 3 | 0 (3) | 0 | 0 | 33 | 0% | 2.7 | 0 (2) | 0 (1) | - | 0 (1) | 0 (2) |
| Mine | Wizard | 2 | 2 (2) | 2 | 0 | 126 | 0% | 2.0 | - | - | - | - | - |
| Opponent | Chaff | 8 | 120 (8) | 34 | 87 | 40 | 12% | 1.9 | 147 (2) | 133 (4) | 58 (2) | 164 (5) | 36 (3) |
| Opponent | Character | 8 | 102 (8) | 102 | 0 | 2 | 12% | 3.4 | 35 (5) | 210 (3) | - | 60 (3) | 126 (5) |
| Opponent | Clean-up | 4 | 88 (4) | 88 | 0 | 0 | 25% | 3.0 | 26 (2) | 110 (2) | - | 26 (2) | 110 (2) |
| Opponent | Fast Hammer | 7 | 41 (7) | 41 | 0 | 15 | 29% | 3.6 | 13 (2) | 62 (5) | - | 63 (4) | 25 (3) |
| Opponent | Holder | 4 | 92 (4) | 13 | 80 | 23 | 0% | 1.5 | 175 (2) | - | 24 (2) | 175 (2) | 24 (2) |
| Opponent | Shooter | 4 | 0 (4) | 0 | 0 | 0 | 0% | 1.2 | 0 (2) | 0 (2) | - | 0 (2) | 0 (2) |
| Opponent | Wizard | 3 | 0 (3) | 0 | 0 | 0 | 0% | 3.3 | 0 (1) | 0 (1) | 0 (1) | - | 0 (3) |

### Charged fights: cora-bb45c30-p34

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Ogre Kingdoms | 1 | 195 | 0 | 2.0 | 1.5 | 0 | 276 | -276 | 2 of 2 | 0 of 2 | -462 | -90 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 192 | 4.0 | 1.0 | 48 | 14 | +34 | 0 of 4 | 3 of 4 | - | +34 |
| Mine | Skaven | 1 | 0 | 0 | 2.0 | 1.0 | 0 | 0 | +0 | 1 of 2 | 1 of 2 | - | +0 |
| **Mine** | all armies | 3 | 65 | 64 | 2.7 | 1.1 | 24 | 76 | -52 | 3 of 8 | 4 of 8 | -462 | +7 |
| Opponent | Tomb Kings of Khemri | 2 | 44 | 1144 | 4.0 | 1.2 | 286 | 0 | +286 | 3 of 8 | 7 of 8 | +172 | +324 |
| Opponent | Vampire Counts | 1 | 0 | 1045 | 6.0 | 1.2 | 174 | 8 | +166 | 3 of 6 | 3 of 6 | -50 | +209 |
| **Opponent** | all armies | 3 | 30 | 1111 | 4.7 | 1.2 | 238 | 4 | +234 | 6 of 14 | 10 of 14 | +98 | +272 |

### Effective charges: cora-bb45c30-p34

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Ogre Kingdoms | 2 | 0 | 0 | 1 (net -462) | 0 | 0 | 0 | 1 | 100% (1 of 1) |
| Mine | Orc & Goblin Tribes | 4 | 0 | 0 | 0 | 1 (net -55) | 1 (net +66) | 0 | 2 | 0% (0 of 2) |
| Mine | Skaven | 2 | 1 (net +0) | 0 | 0 | 1 (net +0) | 0 | 0 | 0 | 0% (0 of 2) |
| Opponent | Tomb Kings of Khemri | 8 | 1 (net +1240) | 0 | 1 (net +262) | 0 | 1 (net +110) | 5 (net +135) | 0 | 12% (1 of 8) |
| Opponent | Vampire Counts | 6 | 2 (net +32) | 0 | 0 | 1 (net +210) | 2 (net +90) | 1 (net +540) | 0 | 0% (0 of 6) |

### Charged fights, damage counted: cora-bb45c30-p34

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 1 | 38 | 348 | +0 | 0 | 19 | -19 | -50.0 |
| Mine | Effective (55-75%) | 1 | 462 | 440 | -462 | 0 | 462 | -462 | -100.0 |
| Mine | 76-89% | 2 | 46 | 67 | -28 | 2 | 28 | -25 | -53.9 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 343 | 66 | +66 | 66 | 0 | +66 | +19.2 |
| Mine | No odds | 3 | 263 | 189 | +12 | 42 | 30 | +12 | +4.6 |
| Mine | All fights | 8 | 216 | 194 | -52 | 25 | 78 | -54 | -24.9 |
| Opponent | Long shot (under 50%) | 3 | 246 | 206 | +435 | 435 | 75 | +360 | +146.1 |
| Opponent | Effective (55-75%) | 1 | 195 | 185 | +262 | 262 | 32 | +230 | +117.7 |
| Opponent | 76-89% | 1 | 147 | 210 | +210 | 210 | 0 | +210 | +142.9 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 6 | 396 | 274 | +202 | 211 | 33 | +178 | +45.0 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 3 | 203 | 43 | +97 | 113 | 17 | +97 | +47.6 |
| Opponent | All fights | 14 | 290 | 199 | +234 | 242 | 36 | +206 | +70.8 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| cora-bb45c30-p34 | move | 29 | 12 (41%) | 10 (34%) | 4 (14%) | 13 (45%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L2025 |
| Elixir of Power | Mine | L1923 |
| Fistful of Laurels | Mine | L1823 |
| Invocation of Nehek | Opponent | L2025 |
| Periapt of Soul Exchange | Mine | L2025 |

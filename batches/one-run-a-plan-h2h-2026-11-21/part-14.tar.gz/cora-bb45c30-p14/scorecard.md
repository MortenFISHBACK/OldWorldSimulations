# Doctrine scorecard: cora-bb45c30-p14

### Scorecard: cora-bb45c30-p14

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0222 | 6 | 1 | Mine | no | 2 | 2 | 3 | 5 | 0 | 0 | 0 | 0 |
| L0222 | 6 | 1 | Opponent | no | 7 | 1 | 3 | 1 | 0 | 0 | 0 | 72 |
| L0307 | 1 | 1 | Mine | yes | 0 | - | 0 | 1 | 0 | 0 | 0 | 590 |
| L0307 | 1 | 1 | Opponent | no | 10 | 5 | 0 | 3 | 1 | 0 | 0 | 375 |
| L0323 | 5 | 1 | Mine | yes | - | 2 | 1 | 1 | 0 | 0 | 0 | 535 |
| L0323 | 5 | 1 | Opponent | yes | - | 3 | 1 | 3 | 0 | 0 | 0 | 245 |
| **Average** | | | Mine | 67% | 1.0 | 2.0 | 1.3 | 2.3 | 0.0 | 0.0 | 0.0 | 375.0 |
| **Average** | | | Opponent | 33% | 8.5 | 3.0 | 1.3 | 2.3 | 0.3 | 0.0 | 0.0 | 230.7 |

### KPIs: cora-bb45c30-p14

Rules off - Mine only: ONE RUN A PLAN.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 46% (6 of 13) | 0% (0 of 16) | 21% (6 of 29) |
| Winner chose to follow up after the loser gave ground |  | 0% (0 of 2); on the table 50% | 100% (3 of 3); on the table 100% | 60% (3 of 5); on the table 80% |
| Winner chose to pursue after the loser fell back in good order |  | - | - | - |
| Winner chose to pursue after the loser fled |  | - | - | - |
| Winner chose to follow up or pursue (all three) |  | 0% (0 of 2); on the table 50% | 100% (3 of 3); on the table 100% | 60% (3 of 5); on the table 80% |
| Magic missiles tried each own turn | 50%+ | 31% (11 of 36) | 83% (5 of 6) | 38% (16 of 42) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 31% (11 of 35) | 83% (5 of 6) | 39% (16 of 41) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 67% (2 of 3) | - | 67% (2 of 3) |
| Points that never fought | lower | 85% (4994 of 5897) | 66% (3942 of 5999) | 75% (8936 of 11896) |
|   infantry points that never fought | lower | 88% (1261 of 1437) | 76% (713 of 938) | 83% (1974 of 2375) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 64% (14 of 22) | 50% (10 of 20) | 57% (24 of 42) |
| Bound items with a magic missile used (at least once a game) |  | 100% (2 of 2); 2.0 uses a game | 0.0 uses a game | 100% (2 of 2); 1.0 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 25% (1 of 4); 0.3 uses a game | 0% (0 of 1); 0.0 uses a game | 20% (1 of 5); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 55% (2488 of 4484) | 40% (1878 of 4648) | 48% (4366 of 9132) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 6.7 (80%) | 0.0 (0%) | 6.7 (77%) |
| MARCHED: its unit marched | 0.7 (8%) | 0.3 (100%) | 1.0 (12%) |
| GONE: slain | 0.3 (4%) | 0.0 (0%) | 0.3 (4%) |
| STUPIDITY: Stupidity | 0.7 (8%) | 0.0 (0%) | 0.7 (8%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 6.0 | 1.7 | 5.3 | 0.7 | 0.0 |
| not cast | 0.0 | 2.3 | 8.7 | 1.3 | 8.0 |
| NO TARGET: no enemy in range, sight and arc it may target | - | 0.0 (0%) | 6.7 (77%) | 0.3 (25%) | 0.0 (0%) |
| MARCHED: its unit marched | - | 0.0 (0%) | 1.0 (12%) | 0.3 (25%) | 0.0 (0%) |
| GONE: slain | - | 0.0 (0%) | 0.3 (4%) | 0.0 (0%) | 0.0 (0%) |
| STUPIDITY: Stupidity | - | 0.7 (29%) | 0.7 (8%) | 0.0 (0%) | 0.7 (8%) |
| OTHER BAR: another bar (miscast, baggage ...) | - | 0.0 (0%) | 0.0 (0%) | 0.7 (50%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | - | 1.7 (71%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | - | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 7.3 (92%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.7 a game | 0.0 a game | 0.8 a game |
| stood (cast and not dispelled) | 40% (2 of 5) | - | 40% (2 of 5) |
| the unit moved after it | 0% (0 of 2) | - | 0% (0 of 2) |
| it charged on its next turn | 0% (0 of 2) | - | 0% (0 of 2) |
| the enemy charged it first | 0% (0 of 2) | - | 0% (0 of 2) |
| it fought by the end of its next turn | 0% (0 of 2) | - | 0% (0 of 2) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 2) | - | 0% (0 of 2) |
| none of these (no charge, no fight, no charge escaped) | 100% (2 of 2) | - | 100% (2 of 2) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 81% (51 of 63) | 69% (72 of 104) | 74% (123 of 167) |
|   cavalry | - | 100% (15 of 15) | 100% (15 of 15) |
|   character | - | 0% (0 of 16) | 0% (0 of 16) |
|   chariot | 65% (15 of 23) | 100% (3 of 3) | 69% (18 of 26) |
|   infantry | - | 73% (44 of 60) | 73% (44 of 60) |
|   war machine | 90% (36 of 40) | 100% (10 of 10) | 92% (46 of 50) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 0.7 (17%) | 1.3 (12%) | 2.0 (14%) |
| CHARGED: it charged | 0.7 (17%) | 2.0 (19%) | 2.7 (18%) |
| IN COMBAT: it fought this turn or the last | 0.7 (17%) | 0.3 (3%) | 1.0 (7%) |
| MOVED: a war machine that moved | 0.3 (8%) | 0.0 (0%) | 0.3 (2%) |
| NO TARGET IN RANGE | 0.3 (8%) | 4.3 (41%) | 4.7 (32%) |
| ONLY IN COMBAT: the only targets were in combat | 0.0 (0%) | 1.0 (9%) | 1.0 (7%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.7 (17%) | 1.7 (16%) | 2.3 (16%) |
| OTHER BAR | 0.7 (17%) | 0.0 (0%) | 0.7 (5%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 8.0 | 0.0 | 100% | 0.0 pts | 0 pts |
| chariot | 6.3 | 7.7 | 58% | 28.6 pts | 181 pts |
| infantry | 17.3 | 6.0 | 77% | 7.4 pts | 128 pts |
| war machine | 15.7 | 17.7 | 66% | 35.3 pts | 554 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.0 | 3.7 | 3.3 |
| Charges that made contact a game | 1.7 | 2.0 | 1.8 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.00 declared, 0.00 contact (4 units) | 0.00 declared, 0.00 contact (1 units) | 0.00 declared, 0.00 contact (5 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | - | - |
|   per unit a game, the other units (no war machines, no joined characters) | 0.45 declared, 0.25 contact (20 units) | 0.37 declared, 0.20 contact (30 units) | 0.40 declared, 0.22 contact (50 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 100% (3 of 3) | 0% (0 of 1) | - | 75% (3 of 4) |
| Character in a unit | 100% (5 of 5) | 100% (2 of 2) | - | 100% (7 of 7) |
| Character on its own | 100% (1 of 1) | - | 20% (1 of 5) | 33% (2 of 6) |
| Chariot | - | 25% (1 of 4) | - | 25% (1 of 4) |
| Infantry | 0% (0 of 2) | 33% (1 of 3) | - | 20% (1 of 5) |
| Monster | 60% (3 of 5) | - | - | 60% (3 of 5) |
| War Machines | 67% (6 of 9) | 50% (1 of 2) | - | 64% (7 of 11) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 1 | 0% (0 of 1); on the table 100% | 25% (3 of 12) | 80% | 83% (5 of 6) | 100% (2 of 2); 6.0 uses a game | 0.0 uses a game | 50% (1 of 2); 1.0 uses a game |
| Chaos Dwarfs | 2 | 0% (0 of 1); on the table 0% | 33% (8 of 24) | 87% | 56% (9 of 16) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |
| Empire of Man | 1 | - | 83% (5 of 6) | 100% | 70% (7 of 10) | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Tomb Kings of Khemri | 2 | 100% (3 of 3); on the table 100% | - | 49% | 30% (3 of 10) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (cora-bb45c30-p14, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 80% (4) | 100% (1) | 83% (5) |
| ...free all their last turn and able to turn (per game) | 0.33 | 0.33 | 0.67 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 1.00 | 0.00 | 1.00 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.33 | 0.33 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: cora-bb45c30-p14

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 0.7 | 2.7 |
| Strategy | Charge objectives carried out (made contact) | 56% (5 of 9) | 33% (3 of 9) |
| Strategy | Shoot objectives carried out (shot that target) | 68% (32 of 47) | 59% (20 of 34) |
| Strategy | Support requests answered (helper made contact too) | 0% (0 of 1) | - |
| Strategy | Joined characters whose unit fought | 0% (0 of 7) | 33% (1 of 3) |
| Strategy | Lone characters that fought | 0% (0 of 5) | 50% (4 of 8) |
| Movement | Charges halted short of contact | 0.0 | 0.3 |
| Movement | Idle units | 2.3 | 2.3 |
| Movement | Points that never moved of their own | 375.0 | 230.7 |
| Movement | Fights charged into per game | 1.7 | 1.7 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 5 | 0 of 4 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 5 | 0 of 4 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 1 of 5, net +66 | 1 of 4, net +170 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 of 5, net +72 | 2 of 4, net +55 |
| Shooting | Shots by shooting units (incl. breath weapons) | 5.0 | 24.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 27% (4 of 15) | 36% (26 of 72) |
| Shooting | Points destroyed by shooting units | 115.7 | 54.0 |
| Shooting | War machine shots | 12.0 | 3.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 28% (10 of 36) | 40% (4 of 10) |
| Shooting | Points destroyed by war machines | 101.7 | 28.3 |
| Magic | Magic missiles cast | 1.3 | 1.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 50% (2 of 4) | 25% (1 of 4) |
| Magic | Wounds caused by magic missiles | 1.7 | 0.3 |
| Magic | Points destroyed by magic (all spells) | 0.0 | 46.7 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.0 / 0.0 / 0.0 / 0.0 | 5.3 / 0.0 / 0.0 / 0.7 |
| Combat | Points destroyed in combat | 135.0 | 196.7 |
| Combat | Points run down | 0.0 | 0.0 |
| Combat | Net points per charged fight, damage counted | +76 | +154 |
| Combat | Net per 100 charger points, damage counted | +62.3 | +36.4 |
| Combat | First round won (charged fights) | 100% | 100% |
| Combat | Net points per charged fight | +81 | +137 |
| Combat | Net points per supported fight / lone fight | - / +81 | +170 / +129 |
| Combat | Charged fights on a top-3 enemy unit | 0 of 5 | 2 of 5 |
| Game | Points lost | 489.3 | 344.0 |
| Game | VP from objectives | 440.0 | 823.3 |
| Game | Lone holders (player turns) | 1.0 | 8.5 |

- Mine won / drew / lost: 0 / 1 / 2 of 3 ended games (of 3); mean margin (Mine - Opponent) -480 VP
- The side that went first won 1 of 2 games with a winner
- Points traded per game (both sides' losses): 833
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: cora-bb45c30-p14

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.7 | +25.4 | 0.0 | 103.3 | - | - | - | - |
| ARMY TABLE | 13.7 | +107.7 | 0.0 | 66.3 | 33.0 | +907.5 | 0.0 | 216.0 |
| ARTILLERY RE-ROLL WEIGHED | 4.3 | +0.0 | 0.0 | 83.3 | - | - | - | - |
| BACKUP TARGETS | - | - | - | - | 0.3 | +1.0 | 0.0 | 0.0 |
| BEST PRIZE | - | - | - | - | 0.3 | -6.8 | 10.0 | 0.0 |
| BLOWS WHERE AIMED | 0.3 | -2.4 | 0.0 | 0.0 | - | - | - | - |
| CANNON PLANNED TARGET | 11.0 | +28.9 | 377.7 | 320.0 | 3.3 | +148.7 | 28.3 | 83.3 |
| CANNON SIGHT KEPT | 1.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 41.7 |
| CAST JOB | 4.3 | +56.8 | 374.7 | 56.7 | 0.7 | +33.2 | 93.3 | 0.0 |
| CASTER AWAY FROM SCREEN | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CATCH FLIERS | 0.3 | +15.9 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | 0.7 | +4.2 | 0.0 | 20.0 | - | - | - | - |
| CHAFF PASSED | - | - | - | - | 0.3 | -0.5 | 56.7 | 0.0 |
| CHARGE LOSSES | 21.0 | -602.8 | 0.0 | 211.3 | 27.3 | -578.1 | 0.0 | 307.3 |
| CHARGE NOW FIRST | 0.7 | +0.0 | 46.0 | 17.3 | 2.7 | +0.0 | 204.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 7.7 | +0.0 | 0.0 | 0.0 | 12.0 | +0.0 | 0.0 | 118.7 |
| COMBAT PIVOT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CONTINUE AHEAD WEIGHED | - | - | - | - | 0.3 | +0.0 | 17.3 | 0.0 |
| CONVEYANCE SEARCH | 1.0 | +104.9 | 0.0 | 0.0 | - | - | - | - |
| COVER ONCE | 11.3 | -791.8 | 0.0 | 85.7 | 1.7 | -41.2 | 0.0 | 18.3 |
| DEPLOY BY FIGURES | 9.0 | -61.4 | 0.0 | 0.0 | 7.3 | -45.6 | 0.0 | 65.0 |
| EDGE GIVE GROUND | - | - | - | - | 0.3 | +3.8 | 76.7 | 0.0 |
| ENGINEER BY LORE | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| EXACT ROUND | 3.0 | -2.7 | 230.3 | 17.3 | 3.7 | +54.8 | 442.7 | 0.0 |
| FALL BACK GOOD ORDER | 2.0 | +0.0 | 171.3 | 17.3 | 1.0 | +0.0 | 103.3 | 0.0 |
| FALLS SHORT | 6.7 | +141.3 | 0.0 | 56.0 | 14.7 | +151.5 | 0.0 | 181.7 |
| FEATURE BUFFS | 4.3 | +80.8 | 0.0 | 56.0 | 3.0 | +73.6 | 0.0 | 44.0 |
| FIGHT TO THE END | - | - | - | - | 0.3 | +5.2 | 0.0 | 0.0 |
| FIRE IN ORDER | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| FIVE ACTION | 93.0 | +2973.0 | 1808.3 | 1033.3 | 106.3 | +8993.8 | 1256.7 | 816.0 |
| FLANK NOT WEIGHED | 9.0 | +0.0 | 0.0 | 105.7 | 2.3 | +0.0 | 0.0 | 134.3 |
| FOLLOW UP WEIGHED | - | - | - | - | 0.7 | +83.3 | 0.0 | 0.0 |
| FOUR ROUNDS | 3.0 | +51.0 | 230.3 | 17.3 | 3.7 | +223.2 | 442.7 | 0.0 |
| FREED FROM HIS FIGHT | 7.3 | +0.0 | 0.0 | 80.7 | - | - | - | - |
| FRIEND CHARGES FIRST | 0.3 | -11.4 | 0.0 | 0.0 | - | - | - | - |
| FRIEND SHOOTS FIRST | - | - | - | - | 0.3 | -0.0 | 0.0 | 0.0 |
| GIVES UP | - | - | - | - | 0.7 | -4.5 | 56.7 | 0.0 |
| GOAL WALK | 14.7 | +903.7 | 0.0 | 17.3 | 20.0 | +2443.1 | 0.0 | 120.0 |
| GUN FIGURES | 3.7 | +80.5 | 303.0 | 0.0 | - | - | - | - |
| HARD STAY DROPPED | 1.3 | +0.0 | 0.0 | 31.7 | 2.3 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 1.3 | +0.0 | 0.0 | 17.3 | - | - | - | - |
| HIS CHARGE BY HIS RUN | 17.0 | +0.0 | 0.0 | 211.3 | 5.3 | +0.0 | 0.0 | 187.3 |
| HIS CHARGE DENIED | - | - | - | - | 0.7 | +47.0 | 0.0 | 0.0 |
| HIS CHARGE LIST | 6.7 | +0.0 | 0.0 | 56.7 | 0.3 | +0.0 | 0.0 | 24.0 |
| HIS LEGAL MOVES | 6.3 | +0.0 | 0.0 | 0.0 | 6.3 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 4.3 | -31.7 | 0.0 | 80.7 | 4.0 | -80.7 | 0.0 | 68.0 |
| HIS ONE QUARTER | 5.0 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 8.7 | +0.0 | 0.0 | 0.0 | 6.3 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVE | - | - | - | - | 7.0 | +0.0 | 0.0 | 48.0 |
| HIS RANDOM MOVER COMES | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 47.7 | +1119.8 | 0.0 | 319.3 | 60.3 | +2176.1 | 0.0 | 483.3 |
| HIS SHOTS BY HIS RUN | 46.3 | +550.4 | 0.0 | 319.3 | 52.7 | +624.6 | 0.0 | 612.7 |
| HIS TURN DENIED | 1.3 | +9.1 | 99.7 | 0.0 | - | - | - | - |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HOLD ODDS | 16.0 | +0.0 | 0.0 | 0.0 | 25.3 | +0.0 | 0.0 | 136.0 |
| HOLDER ASSIGNMENT | 8.0 | +685.6 | 0.0 | 28.0 | 16.3 | +1525.0 | 0.0 | 46.0 |
| HOLDS AMBUSHERS | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 2.7 | -31.3 | 189.7 | 17.3 | 3.7 | -91.2 | 442.7 | 0.0 |
| HUNT IN PAIRS | - | - | - | - | 0.7 | +248.9 | 0.0 | 0.0 |
| IDLE COST | 7.7 | -66.5 | 0.0 | 34.7 | 13.0 | -201.1 | 0.0 | 60.0 |
| JOINT CHARGE NOW | 1.3 | -5.0 | 125.3 | 0.0 | 0.3 | -21.6 | 56.7 | 0.0 |
| JOINT LOOK BACK | - | - | - | - | 0.3 | +8.6 | 56.7 | 0.0 |
| KEEP FALLS | 0.3 | +0.3 | 0.0 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 0.7 | +0.0 | 0.0 | 0.0 | 5.3 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | - | - | - | - | 1.3 | +45.8 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 0.7 | +0.0 | 0.0 | 103.3 | 11.3 | +0.0 | 317.0 | 231.0 |
| LONE WIZARD KEPT IN | 0.7 | +17.5 | 0.0 | 0.0 | 1.0 | +78.3 | 0.0 | 0.0 |
| LONG SHOT | 0.7 | +13.5 | 62.7 | 0.0 | - | - | - | - |
| LOST AFTER ESCAPE | 1.7 | -0.4 | 123.7 | 17.3 | 1.3 | +0.9 | 132.7 | 0.0 |
| MAKE SURE TOGETHER | - | - | - | - | 0.7 | +3.7 | 0.0 | 0.0 |
| MANOEUVRE | 1.7 | -0.0 | 0.0 | 0.0 | 1.0 | -9.5 | 0.0 | 23.3 |
| MARCH AT ESCAPER | 0.3 | +1.1 | 0.0 | 0.0 | - | - | - | - |
| MARCH BY THE SUM | 0.3 | +3.8 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | 1.0 | +38.4 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 0.3 | -1.1 | 0.0 | 0.0 | 0.3 | +14.1 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | - | - | - | - | 1.7 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 2.0 | +11.8 | 0.0 | 28.3 | 1.7 | +21.8 | 0.0 | 40.7 |
| MEETS IN TIME | 3.3 | +203.8 | 0.0 | 0.0 | 1.7 | +142.6 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 5.3 | +95.6 | 0.0 | 28.3 | 1.7 | +58.9 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 7.7 | +95.1 | 0.0 | 56.7 | 1.7 | +40.4 | 0.0 | 0.0 |
| MOVE ORDER | 1.0 | +0.0 | 10.0 | 0.0 | 1.7 | +0.0 | 44.0 | 0.0 |
| MOVE SPELL SPOT | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 4.7 | +154.3 | 0.0 | 17.3 | 5.3 | +458.7 | 0.0 | 187.3 |
| MOVES UNITS SPELL | 0.3 | +18.4 | 0.0 | 0.0 | - | - | - | - |
| NEARER NOT NEEDED | 5.7 | +286.3 | 0.0 | 28.0 | 12.0 | +544.6 | 0.0 | 86.3 |
| NEXT CHARGE BY LIST | 2.7 | +102.5 | 0.0 | 0.0 | 4.0 | +384.3 | 34.7 | 187.3 |
| NO DOUBLE ROUNDS | 2.3 | -10.9 | 186.3 | 17.3 | 3.3 | -201.8 | 339.3 | 0.0 |
| NO LATE CUT | - | - | - | - | 2.0 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OFF BEST | 4.7 | -109.6 | 0.0 | 0.0 | 7.0 | -120.7 | 0.0 | 22.0 |
| OGRE LOADER SECOND SHOT | 2.7 | +25.9 | 36.7 | 0.0 | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ONE FIGHT FORMULA | 3.0 | -15.7 | 0.0 | 17.3 | 6.0 | -142.1 | 0.0 | 134.3 |
| ONE OBJECTIVE FORMULA | 4.7 | -2.7 | 0.0 | 0.0 | 5.3 | +124.6 | 0.0 | 24.0 |
| ONE PROMISE A TARGET | 0.7 | +8.4 | 0.0 | 0.0 | - | - | - | - |
| ONE ROUTE | - | - | - | - | 1.7 | +0.0 | 0.0 | 0.0 |
| ONE RUN A PLAN | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS UP | - | - | - | - | 1.0 | +29.3 | 36.7 | 0.0 |
| OVERRUNS AWAY | 0.7 | +3.6 | 81.3 | 0.0 | 1.3 | +26.5 | 208.0 | 0.0 |
| PATHS CROSS | - | - | - | - | 0.7 | -1.7 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.7 | -9.2 | 0.0 | 0.0 | - | - | - | - |
| PLAN RESULT | 42.3 | +861.2 | 345.3 | 652.0 | 47.0 | +546.3 | 336.0 | 574.0 |
| PROMISE BELOW ZERO | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE BY ITS OWN SUM | 7.0 | -98.3 | 0.0 | 0.0 | 9.7 | -299.1 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | 1.0 | -8.5 | 0.0 | 34.7 | - | - | - | - |
| PROMISE SHOT AWAY | 0.7 | -1.3 | 187.3 | 56.7 | 0.3 | -0.0 | 0.0 | 18.3 |
| QUARTER ODDS | 16.7 | +1285.8 | 0.0 | 380.0 | 17.3 | +1897.1 | 686.7 | 0.0 |
| RANDOM MOVE BY FIGURES | 1.0 | +55.4 | 0.0 | 113.3 | - | - | - | - |
| REAL GROUND | - | - | - | - | 1.7 | +0.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | 2.3 | +41.4 | 0.0 | 28.0 | 2.3 | +68.5 | 0.0 | 106.7 |
| REDIRECT FOR A FRIEND IN REACH | 2.0 | +0.0 | 0.0 | 28.0 | 3.7 | +0.0 | 0.0 | 128.7 |
| REFORMS TO MEET IT | 0.7 | -0.7 | 0.0 | 0.0 | 0.3 | -0.1 | 0.0 | 0.0 |
| RESERVE FALL BACK | - | - | - | - | 1.0 | +50.5 | 0.0 | 0.0 |
| RESERVE MOVE SPELL | 0.3 | +3.3 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | 3.0 | +14.7 | 230.3 | 17.3 | 3.0 | +11.6 | 358.0 | 0.0 |
| ROUNDS AFTER TERROR | - | - | - | - | 1.3 | -21.9 | 92.7 | 0.0 |
| RUN DOWN | - | - | - | - | 2.0 | -9.9 | 169.3 | 0.0 |
| SAME CHARGE LATER | - | - | - | - | 0.3 | -4.9 | 17.3 | 0.0 |
| SCOUT SPOT | - | - | - | - | 2.0 | +1.8 | 0.0 | 0.0 |
| SCOUT WAITS | - | - | - | - | 2.0 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.7 | -149.3 | 0.0 | 20.0 | - | - | - | - |
| SEARCH SPOT | 0.3 | +1.0 | 0.0 | 0.0 | - | - | - | - |
| SECOND LOOK | - | - | - | - | 0.3 | +26.9 | 0.0 | 0.0 |
| SET CREDITED ONCE | 0.3 | -2.3 | 0.0 | 17.3 | 2.0 | -277.4 | 0.0 | 0.0 |
| SET UP BY THE SET | 1.3 | -10.0 | 0.0 | 17.3 | 3.3 | +179.9 | 0.0 | 0.0 |
| SET UP TOGETHER | - | - | - | - | 0.7 | +3.7 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | - | - | - | - | 0.3 | +1.3 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 16.0 | +0.0 | 0.0 | 358.3 | 11.7 | +0.0 | 0.0 | 101.7 |
| SHOOTS FROM THE BEST SPOT | 3.0 | +86.1 | 374.7 | 0.0 | 4.0 | +129.0 | 34.7 | 0.0 |
| SHOT OR CHARGE | - | - | - | - | 0.3 | -59.7 | 103.3 | 0.0 |
| SHOT RISK POINTS | 27.7 | -246.8 | 0.0 | 137.3 | 37.7 | -548.5 | 0.0 | 425.3 |
| SHOTS AFTER THE MOVES | 4.0 | +0.0 | 0.0 | 0.0 | 5.3 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 18.3 | +443.3 | 0.0 | 320.0 | 26.0 | +433.2 | 0.0 | 254.3 |
| SPOT AS THE GAME MOVES | 5.0 | +0.0 | 0.0 | 74.0 | 6.3 | +0.0 | 0.0 | 117.0 |
| STAND AND SHOOT | 2.3 | -4.1 | 167.7 | 17.3 | - | - | - | - |
| STANDS FOR A REASON | 2.3 | +0.0 | 0.0 | 0.0 | 6.3 | +0.0 | 0.0 | 44.0 |
| STANDS STILL | 48.7 | +0.0 | 1578.0 | 929.3 | 43.0 | +0.0 | 814.0 | 352.7 |
| STAY WORTH | 28.0 | -504.6 | 494.7 | 406.7 | 36.3 | +488.5 | 366.0 | 373.0 |
| STUCK PIVOT | 0.3 | +0.0 | 0.0 | 56.7 | - | - | - | - |
| SUPPORT ADDS | 2.7 | +139.4 | 0.0 | 0.0 | 3.3 | +111.7 | 0.0 | 24.0 |
| SUPPORT NARROWED | 0.3 | +0.0 | 18.3 | 0.0 | - | - | - | - |
| SUPPORT WORKED OUT | 2.7 | +139.4 | 0.0 | 0.0 | 3.3 | +111.7 | 0.0 | 24.0 |
| SURE REACH TOGETHER | 0.3 | +0.2 | 0.0 | 17.3 | 1.7 | +11.2 | 0.0 | 24.0 |
| SWIFTSTRIDE BY POINTS | 0.3 | +0.3 | 0.0 | 10.0 | - | - | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 0.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| THE PROMISE ADDS | 0.3 | -18.5 | 0.0 | 0.0 | 0.3 | -63.7 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 3.0 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 2.7 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 1.0 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 23.3 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 42.3 | +0.0 | 0.0 | 452.7 | 51.0 | +0.0 | 0.0 | 408.0 |
| TIED UP BY THE SUM | 1.0 | +57.7 | 68.0 | 17.3 | 2.3 | +280.5 | 226.0 | 0.0 |
| TIME ON OUR SIDE | 21.7 | +282.1 | 0.0 | 28.3 | 22.0 | +238.2 | 0.0 | 164.3 |
| WAITS AGAIN | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| WAR ENGINE JOBS | 1.7 | +0.0 | 22.0 | 0.0 | - | - | - | - |
| WHO FIGHTS | 1.3 | +3.5 | 105.3 | 17.3 | 0.3 | +1.7 | 76.7 | 0.0 |
| WHO HITS BACK | - | - | - | - | 0.3 | +57.2 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | 2.0 | -309.2 | 0.0 | 74.0 | 1.0 | -37.8 | 0.0 | 187.3 |
| WHOLE FIGHT GAIN | 0.3 | +1.6 | 40.7 | 0.0 | - | - | - | - |
| WOUNDS ON THE RANKS | 5.0 | +138.1 | 0.0 | 0.0 | 2.3 | +71.0 | 0.0 | 0.0 |

### Rule changes: cora-bb45c30-p14

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 140 | 140 | 109 | 36.33 | +2956 | +27.1 |
| HIS SHOT LIST | 324 | 312 | 99 | 33.00 | +1569 | +15.9 |
| HOLDER ASSIGNMENT | 73 | 73 | 69 | 23.00 | +3985 | +57.8 |
| HIS SHOTS BY HIS RUN | 297 | 285 | 40 | 13.33 | +439 | +11.0 |
| LEGAL CHARGES ONLY | 36 | 36 | 36 | 12.00 | +0 | +0.0 |
| OFF BEST | 35 | 35 | 35 | 11.67 | -691 | -19.7 |
| DEPLOY BY FIGURES | 49 | 49 | 32 | 10.67 | +405 | +12.6 |
| FIVE ACTION | 598 | 584 | 30 | 10.00 | +1082 | +36.1 |
| GOAL WALK | 104 | 101 | 29 | 9.67 | +1661 | +57.3 |
| THE TABLE AGAIN | 36 | 36 | 28 | 9.33 | +0 | +0.0 |
| SHOT RISK POINTS | 196 | 188 | 24 | 8.00 | +243 | +10.1 |
| TIME ON OUR SIDE | 131 | 115 | 22 | 7.33 | +57 | +2.6 |
| MOVE TO CHARGE COMPUTED | 30 | 28 | 19 | 6.33 | +542 | +28.6 |
| PROMISE BY ITS OWN SUM | 50 | 50 | 19 | 6.33 | -1192 | -62.8 |
| REDIRECT FOR A FRIEND IN REACH | 17 | 17 | 17 | 5.67 | +0 | +0.0 |
| NEXT CHARGE BY LIST | 20 | 20 | 14 | 4.67 | +515 | +36.8 |
| ARTILLERY RE-ROLL WEIGHED | 13 | 13 | 13 | 4.33 | +0 | +0.0 |
| HARD STAY DROPPED | 11 | 11 | 11 | 3.67 | +0 | +0.0 |
| QUARTER ODDS | 102 | 98 | 11 | 3.67 | +999 | +90.8 |
| SHOOTS FROM THE BEST SPOT | 21 | 21 | 11 | 3.67 | +167 | +15.1 |
| STAY WORTH | 193 | 176 | 9 | 3.00 | +80 | +8.9 |
| TIED UP BY THE SUM | 10 | 10 | 9 | 3.00 | +371 | +41.2 |
| FOUR ROUNDS | 20 | 20 | 8 | 2.67 | +264 | +33.0 |
| MOVE ORDER | 8 | 8 | 8 | 2.67 | +0 | +0.0 |
| OGRE LOADER SECOND SHOT | 8 | 8 | 8 | 2.67 | +77 | +9.7 |
| CANNON PLANNED TARGET | 43 | 43 | 7 | 2.33 | +0 | +0.0 |
| CHARGE LOSSES | 145 | 138 | 7 | 2.33 | +93 | +13.3 |
| COVER ONCE | 39 | 30 | 7 | 2.33 | +196 | +28.0 |
| SHOTS IN THE MOVE | 133 | 100 | 7 | 2.33 | +290 | +41.5 |
| CANNON SIGHT KEPT | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| MEETS IN TIME | 15 | 15 | 6 | 2.00 | +516 | +86.1 |
| SCOUT WAITS | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| SET UP BY THE SET | 14 | 14 | 6 | 2.00 | +392 | +65.4 |
| SUPPORT ADDS | 18 | 18 | 6 | 2.00 | +145 | +24.1 |
| SUPPORT WORKED OUT | 18 | 18 | 6 | 2.00 | +145 | +24.1 |
| ADVANCE LANE KEPT | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| CAST JOB | 15 | 15 | 5 | 1.67 | +63 | +12.6 |
| JOINT CHARGE NOW | 5 | 5 | 5 | 1.67 | -80 | -15.9 |
| LONE WIZARD KEPT IN | 5 | 5 | 5 | 1.67 | +288 | +57.5 |
| LANE BY FIGURES | 4 | 4 | 4 | 1.33 | +137 | +34.3 |
| MAX FOR POSITIONING | 11 | 10 | 4 | 1.33 | +2 | +0.4 |
| REDIRECT COUNTER | 14 | 14 | 4 | 1.33 | +76 | +19.0 |
| RISK BY ARC | 18 | 18 | 4 | 1.33 | +82 | +20.5 |
| CHARGE NOW FIRST | 10 | 10 | 3 | 1.00 | -26 | -8.7 |
| FIRE IN ORDER | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| HOLDS AMBUSHERS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| IDLE COST | 62 | 32 | 3 | 1.00 | +37 | +12.2 |
| MARCH CHECK | 3 | 3 | 3 | 1.00 | +78 | +25.9 |
| NEARER NOT NEEDED | 53 | 52 | 3 | 1.00 | +134 | +44.6 |
| PROMISE SHOT AWAY | 3 | 3 | 3 | 1.00 | -4 | -1.3 |
| RESERVE FALL BACK | 3 | 3 | 3 | 1.00 | +151 | +50.5 |
| SHOTS AFTER THE MOVES | 28 | 28 | 3 | 1.00 | +0 | +0.0 |
| AFTERMATH IN POINTS | 2 | 2 | 2 | 0.67 | +76 | +38.2 |
| CASTER AWAY FROM SCREEN | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| CHAFF IN THE MOVE | 2 | 2 | 2 | 0.67 | +1 | +0.3 |
| FEATURE BUFFS | 22 | 22 | 2 | 0.67 | +14 | +7.2 |
| FOLLOW UP WEIGHED | 2 | 2 | 2 | 0.67 | +250 | +125.0 |
| HIS TURN DENIED | 4 | 4 | 2 | 0.67 | +19 | +9.6 |
| MANOEUVRE | 8 | 8 | 2 | 0.67 | +4 | +2.1 |
| ONE OBJECTIVE FORMULA | 30 | 24 | 2 | 0.67 | +19 | +9.6 |
| ONE PROMISE A TARGET | 2 | 2 | 2 | 0.67 | +25 | +12.6 |
| PATHS CROSS | 2 | 2 | 2 | 0.67 | -5 | -2.5 |
| PIVOT GUARDS FLANK | 2 | 2 | 2 | 0.67 | -28 | -13.8 |
| PROMISE KNOWS THE FIGHT | 3 | 3 | 2 | 0.67 | -25 | -12.7 |
| RANDOM MOVE BY FIGURES | 3 | 3 | 2 | 0.67 | +166 | +83.0 |
| SURE REACH TOGETHER | 6 | 5 | 2 | 0.67 | +2 | +0.8 |
| WHOLE FIGHT DANGER | 9 | 9 | 2 | 0.67 | +25 | +12.6 |
| BEST PRIZE | 1 | 1 | 1 | 0.33 | -20 | -20.5 |
| CHAFF PASSED | 1 | 1 | 1 | 0.33 | -1 | -1.4 |
| COMBAT PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CONTINUE AHEAD WEIGHED | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FALLS SHORT | 64 | 53 | 1 | 0.33 | +6 | +6.3 |
| HONEST WORTH | 19 | 19 | 1 | 0.33 | +20 | +20.5 |
| JOINT LOOK BACK | 1 | 1 | 1 | 0.33 | +26 | +25.8 |
| KEEP FALLS | 1 | 1 | 1 | 0.33 | +34 | +33.5 |
| MARCH BY THE SUM | 1 | 1 | 1 | 0.33 | +11 | +11.4 |
| MISSILES IN THE MOVE | 21 | 11 | 1 | 0.33 | +7 | +7.4 |
| MISSILES NEXT TURN | 28 | 18 | 1 | 0.33 | +4 | +3.8 |
| MOVES UNITS SPELL | 1 | 1 | 1 | 0.33 | +55 | +55.1 |
| ONE FIGHT FORMULA | 27 | 13 | 1 | 0.33 | +6 | +6.1 |
| OVERRUNS AWAY | 6 | 6 | 1 | 0.33 | +3 | +2.6 |
| RESERVE MOVE SPELL | 1 | 1 | 1 | 0.33 | +11 | +10.9 |
| SEARCH SPOT | 1 | 1 | 1 | 0.33 | +3 | +3.0 |
| SECOND LOOK | 1 | 1 | 1 | 0.33 | +81 | +80.6 |
| SHOOTERS IN TWO RANKS | 1 | 1 | 1 | 0.33 | +4 | +4.0 |
| STUCK PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| SUPPORT NARROWED | 1 | 1 | 1 | 0.33 | -25 | -24.8 |
| SWIFTSTRIDE BY POINTS | 1 | 1 | 1 | 0.33 | +1 | +0.8 |
| THE ROW IN ITS ORDER | 15 | 1 | 1 | 0.33 | +0 | +0.0 |
| WHO HITS BACK | 1 | 1 | 1 | 0.33 | +148 | +147.6 |
| WOUNDS ON THE RANKS | 22 | 22 | 1 | 0.33 | +46 | +45.8 |
| BACKUP TARGETS | 1 | 1 | 0 | 0.00 | - | - |
| BLOWS WHERE AIMED | 1 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 2 | trace | - | - | - | - |
| CATCH FLIERS | 1 | not checked | - | - | - | - |
| CLOSES ON WHAT IT BEATS | 59 | 59 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 3 | not checked | - | - | - | - |
| EDGE GIVE GROUND | 1 | 1 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| EXACT ROUND | 20 | 20 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 9 | 9 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 1 | 1 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 34 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 22 | 21 | 0 | 0.00 | - | - |
| FRIEND CHARGES FIRST | 1 | 1 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 1 | 1 | 0 | 0.00 | - | - |
| GIVES UP | 2 | 2 | 0 | 0.00 | - | - |
| GUN FIGURES | 11 | not checked | - | - | - | - |
| HE REFORMS ONCE FREED | 4 | 3 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 67 | 64 | 0 | 0.00 | - | - |
| HIS CHARGE DENIED | 2 | 2 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 21 | 20 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 38 | 38 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 25 | 25 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 25 | 24 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 45 | 44 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 21 | 21 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 2 | 2 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN RUN | 18 | 18 | 0 | 0.00 | - | - |
| HOLD ODDS | 124 | 124 | 0 | 0.00 | - | - |
| HUNT IN PAIRS | 2 | 2 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 18 | 18 | 0 | 0.00 | - | - |
| LONG SHOT | 2 | 2 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 9 | 9 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 2 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 2 | 2 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 5 | 5 | 0 | 0.00 | - | - |
| MOVE SPELL SPOT | 2 | not checked | - | - | - | - |
| NO DOUBLE ROUNDS | 17 | 17 | 0 | 0.00 | - | - |
| NO LATE CUT | 6 | 6 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 1 | not checked | - | - | - | - |
| ONE ROUTE | 5 | 5 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 18 | 18 | 0 | 0.00 | - | - |
| OPENS UP | 3 | 3 | 0 | 0.00 | - | - |
| PLAN RESULT | 268 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 1 | 1 | 0 | 0.00 | - | - |
| REAL GROUND | 5 | 5 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 3 | 3 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 4 | 4 | 0 | 0.00 | - | - |
| RUN DOWN | 6 | 6 | 0 | 0.00 | - | - |
| SAME CHARGE LATER | 1 | 1 | 0 | 0.00 | - | - |
| SCOUT SPOT | 6 | 6 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 2 | 2 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 7 | 7 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 2 | not checked | - | - | - | - |
| SHOOTERS ON THE TABLE | 83 | not checked | - | - | - | - |
| SHOT OR CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 34 | 25 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 7 | 7 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 26 | 26 | 0 | 0.00 | - | - |
| STANDS STILL | 275 | 269 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 6 | not checked | - | - | - | - |
| THE PROMISE ADDS | 2 | 2 | 0 | 0.00 | - | - |
| THE ROW KEEPS ITS WAY | 15 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 10 | not checked | - | - | - | - |
| THE TABLE BINDS | 280 | not checked | - | - | - | - |
| WAITS AGAIN | 4 | 3 | 0 | 0.00 | - | - |
| WAR ENGINE JOBS | 5 | 5 | 0 | 0.00 | - | - |
| WHO FIGHTS | 5 | 5 | 0 | 0.00 | - | - |
| WHOLE FIGHT GAIN | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: cora-bb45c30-p14

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 4.33 | 6.00 | 21.4 |
| PROMISE BY ITS OWN SUM | rule | 2.67 | 3.67 | 62.8 |
| ARMY TABLE | rule | 2.00 | 2.67 | 22.9 |
| HOLDER ASSIGNMENT | rule | - | 1.67 | 3.7 |
| JOINT CHARGE NOW | rule | 1.00 | 0.33 | 25.0 |
| CHARGE NOW FIRST | rule | 0.67 | 0.33 | 8.7 |
| AFTERMATH BAND | gate | 0.33 | 0.33 | 2.8 |
| NO REASON | gate | - | 0.67 | 11.0 |
| PIVOT GUARDS FLANK | rule | 0.67 | - | 13.8 |
| PROMISE KNOWS THE FIGHT | rule | 0.67 | - | 12.7 |
| PROMISE SHOT AWAY | rule | 0.67 | - | 1.9 |
| BEST PRIZE | rule | - | 0.33 | 20.5 |
| CHAFF PASSED | rule | - | 0.33 | 1.4 |
| PATHS CROSS | rule | - | 0.33 | 10.9 |
| SUPPORT NARROWED | rule | 0.33 | - | 24.8 |

### Plans: cora-bb45c30-p14

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 2.7 | 62% | 93 | 112 | 121% |
| Mine | move | 25.7 | 94% | 1085 | 0 | 0% |
| Mine | shoot | 13.7 | 46% | 223 | 749 | 336% |
| Mine | support | 0.3 | 0% | 0 | 0 | 0% |
| Opponent | charge | 3.0 | 67% | 293 | 293 | 100% |
| Opponent | move | 35.3 | 93% | 2554 | 0 | 0% |
| Opponent | shoot | 8.7 | 62% | 635 | 253 | 40% |

### Battle groups: cora-bb45c30-p14

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 2.3 | 14% | 100% | 0% | - | 0% | 0% | 0% | 100% | 0% |
| Opponent | REDIRECT COUNTER | 2.3 | 57% | 75% | 25% | 0% | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: cora-bb45c30-p14

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Mine | Character | 7 | 0 (7) | 0 | 0 | 0 | 57% | 3.0 | 0 (1) | 0 (1) | 0 (5) | 0 (6) | 0 (1) |
| Mine | Clean-up | 4 | 16 (4) | 0 | 16 | 26 | 75% | 3.0 | 0 (1) | 21 (3) | - | 21 (3) | 0 (1) |
| Mine | Fast Hammer | 5 | 67 (5) | 67 | 0 | 32 | 60% | 3.5 | - | 46 (3) | 85 (2) | 53 (4) | 138 (1) |
| Mine | Hammer | 9 | 37 (9) | 22 | 15 | 20 | 33% | 2.2 | 0 (1) | 12 (4) | 78 (4) | 47 (7) | 11 (2) |
| Mine | Holder | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | 0 (1) | - | - | - | 0 (1) |
| Mine | War machine | 8 | 26 (8) | 26 | 0 | 50 | 0% | 1.1 | 0 (2) | 32 (5) | 48 (1) | 0 (3) | 42 (5) |
| Mine | Wizard | 5 | 0 (5) | 0 | 0 | 20 | 60% | 4.0 | 0 (1) | 0 (2) | 0 (2) | 0 (2) | 0 (3) |
| Opponent | Chaff | 5 | 95 (5) | 0 | 95 | 94 | 0% | 1.0 | 0 (1) | 120 (4) | - | 95 (5) | - |
| Opponent | Character | 8 | 25 (8) | 25 | 0 | 11 | 38% | 3.4 | 34 (3) | 31 (2) | 9 (3) | 31 (6) | 0 (2) |
| Opponent | Clean-up | 4 | 68 (4) | 0 | 68 | 37 | 100% | - | 0 (2) | 0 (1) | 139 (1) | 79 (3) | 0 (1) |
| Opponent | Fast Hammer | 6 | 17 (6) | 17 | 0 | 0 | 83% | 3.0 | 0 (3) | 33 (3) | - | 22 (2) | 14 (4) |
| Opponent | Holder | 9 | 51 (9) | 0 | 51 | 9 | 11% | 1.8 | 0 (2) | 114 (4) | 0 (2) | 114 (4) | 0 (4) |
| Opponent | Shooter | 2 | 63 (2) | 46 | 17 | 0 | 0% | 1.5 | 59 (1) | 66 (1) | - | 59 (1) | 66 (1) |
| Opponent | War machine | 3 | 23 (3) | 23 | 0 | 67 | 33% | 1.0 | 23 (3) | - | - | 34 (2) | 0 (1) |
| Opponent | Wizard | 3 | 0 (3) | 0 | 0 | 38 | 0% | 1.0 | 0 (1) | 0 (1) | - | 0 (1) | 0 (1) |

### Charged fights: cora-bb45c30-p14

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 1 | 0 | 339 | 4.0 | 1.0 | 85 | 0 | +85 | 0 of 4 | 4 of 4 | - | +85 |
| Mine | Chaos Dwarfs | 2 | 326 | 33 | 0.5 | 1.0 | 66 | 0 | +66 | 0 of 1 | 1 of 1 | - | +66 |
| **Mine** | all armies | 3 | 217 | 135 | 1.7 | 1.0 | 81 | 0 | +81 | 0 of 5 | 5 of 5 | - | +81 |
| Opponent | Empire of Man | 1 | 225 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Tomb Kings of Khemri | 2 | 81 | 342 | 2.5 | 1.2 | 137 | 0 | +137 | 2 of 5 | 5 of 5 | +170 | +129 |
| **Opponent** | all armies | 3 | 129 | 228 | 1.7 | 1.2 | 137 | 0 | +137 | 2 of 5 | 5 of 5 | +170 | +129 |

### Effective charges: cora-bb45c30-p14

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 0 | 0 | 0 | 3 (net +89) | 0 | 1 (net +72) | 0 | 0% (0 of 4) |
| Mine | Chaos Dwarfs | 1 | 0 | 0 | 0 | 0 | 1 (net +66) | 0 | 0 | 0% (0 of 1) |
| Opponent | Tomb Kings of Khemri | 5 | 0 | 0 | 0 | 1 (net +310) | 1 (net +170) | 2 (net +55) | 1 | 0% (0 of 4) |

### Charged fights, damage counted: cora-bb45c30-p14

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 76-89% | 3 | 84 | 99 | +89 | 103 | 14 | +89 | +106.4 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 52 | 72 | +72 | 72 | 17 | +55 | +105.1 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 310 | 66 | +66 | 149 | 89 | +60 | +19.5 |
| Mine | All fights | 5 | 123 | 87 | +81 | 106 | 30 | +76 | +62.3 |
| Opponent | 76-89% | 1 | 440 | 310 | +310 | 310 | 0 | +310 | +70.5 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 318 | 210 | +55 | 55 | 0 | +55 | +17.3 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 842 | 170 | +170 | 252 | 46 | +206 | +24.5 |
| Opponent | No odds | 1 | 195 | 95 | +95 | 142 | 0 | +142 | +72.6 |
| Opponent | All fights | 5 | 422 | 199 | +137 | 163 | 9 | +154 | +36.4 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| cora-bb45c30-p14 | move | 20 | 3 (15%) | 2 (10%) | 2 (10%) | 15 (75%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Ring of Doom | Mine | L0222 |
| Twice-Blessed Armour | Opponent | L0307 |
| Witch Hunter's Ward | Opponent | L0307 |

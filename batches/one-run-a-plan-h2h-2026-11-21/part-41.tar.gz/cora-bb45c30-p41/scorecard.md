# Doctrine scorecard: cora-bb45c30-p41

### Scorecard: cora-bb45c30-p41

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0721 | 1 | 1 | Mine | no | 3 | 1 | 3 | 1 | 0 | 0 | 0 | 420 |
| L0721 | 1 | 1 | Opponent | yes | 1 | - | 1 | 5 | 1 | 0 | 0 | 410 |
| L0810 | 6 | 1 | Mine | no | 1 | 5 | 1 | 2 | 0 | 0 | 0 | 461 |
| L0810 | 6 | 1 | Opponent | no | 11 | 2 | 1 | 0 | 0 | 0 | 0 | 330 |
| L0827 | 5 | 1 | Mine | no | - | - | 1 | 2 | 0 | 0 | 0 | 467 |
| L0827 | 5 | 1 | Opponent | yes | - | 2 | 2 | 5 | 0 | 0 | 0 | 60 |
| **Average** | | | Mine | 0% | 2.0 | 3.0 | 1.7 | 1.7 | 0.0 | 0.0 | 0.0 | 449.3 |
| **Average** | | | Opponent | 67% | 6.0 | 2.0 | 1.3 | 3.3 | 0.3 | 0.0 | 0.0 | 266.7 |

### KPIs: cora-bb45c30-p41

Rules off - Opponent only: ONE RUN A PLAN.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 100% (13 of 13) | 0% (0 of 13) | 50% (13 of 26) |
| Winner chose to follow up after the loser gave ground |  | 100% (2 of 2); on the table 100% | 100% (5 of 5); on the table 100% | 100% (7 of 7); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | - | 100% (1 of 1); on the table 100% | 100% (1 of 1); on the table 100% |
| Winner chose to pursue after the loser fled |  | 0% (0 of 1); on the table 0% | 0% (0 of 1); on the table 100% | 0% (0 of 2); on the table 50% |
| Winner chose to follow up or pursue (all three) |  | 67% (2 of 3); on the table 67% | 86% (6 of 7); on the table 100% | 80% (8 of 10); on the table 90% |
| Magic missiles tried each own turn | 50%+ | 50% (3 of 6) | 33% (12 of 36) | 36% (15 of 42) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 60% (3 of 5) | 38% (12 of 32) | 41% (15 of 37) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 40% (4 of 10) | 40% (4 of 10) |
| Points that never fought | lower | 61% (3642 of 5999) | 63% (3789 of 5998) | 62% (7431 of 11997) |
|   infantry points that never fought | lower | 80% (778 of 968) | 76% (850 of 1113) | 78% (1628 of 2081) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 70% (21 of 30) | 60% (15 of 25) | 65% (36 of 55) |
| Bound items with a magic missile used (at least once a game) |  | 0.0 uses a game | 100% (3 of 3); 2.0 uses a game | 100% (3 of 3); 1.0 uses a game |
| Bound items with another spell used |  | 100% (1 of 1); 1.0 uses a game | 100% (1 of 1); 1.0 uses a game | 100% (2 of 2); 1.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 33% (1 of 3); 0.3 uses a game | 50% (1 of 2); 0.3 uses a game | 40% (2 of 5); 0.3 uses a game |
|   their share of the points of units over 100 pts | lower | 65% (3482 of 5378) | 63% (3266 of 5181) | 64% (6748 of 10559) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 4.0 (50%) | 4.0 (44%) |
| MARCHED: its unit marched | 0.7 (67%) | 2.3 (29%) | 3.0 (33%) |
| IN COMBAT: engaged in combat | 0.3 (33%) | 0.7 (8%) | 1.0 (11%) |
| GONE: slain | 0.0 (0%) | 0.7 (8%) | 0.7 (7%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.3 (4%) | 0.3 (4%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 7.0 | 1.7 | 3.0 | 5.0 | 1.0 | 0.7 |
| not cast | 3.0 | 0.3 | 3.0 | 9.0 | 3.0 | 27.3 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (1%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.3 (100%) | 0.3 (11%) | 4.0 (44%) | 1.3 (44%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 3.0 (33%) | 0.7 (22%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.0 (11%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | 0.7 (22%) | 0.0 (0%) | 0.0 (0%) | 0.7 (7%) | 0.0 (0%) | 3.3 (12%) |
| STUPIDITY: Stupidity | 0.3 (11%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (4%) | 1.0 (33%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.0 (67%) | 0.0 (0%) | 2.7 (89%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 23.7 (87%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.0 a game | 3.0 a game | 1.5 a game |
| stood (cast and not dispelled) | - | 67% (6 of 9) | 67% (6 of 9) |
| the unit moved after it | - | 67% (4 of 6) | 67% (4 of 6) |
| it charged on its next turn | - | 0% (0 of 6) | 0% (0 of 6) |
| the enemy charged it first | - | 0% (0 of 6) | 0% (0 of 6) |
| it fought by the end of its next turn | - | 0% (0 of 6) | 0% (0 of 6) |
| it moved out of a charge the enemy had planned (not charged first) | - | 0% (0 of 6) | 0% (0 of 6) |
| none of these (no charge, no fight, no charge escaped) | - | 100% (6 of 6) | 100% (6 of 6) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 70% (66 of 94) | 71% (17 of 24) | 70% (83 of 118) |
|   cavalry | 65% (13 of 20) | - | 65% (13 of 20) |
|   chariot | 75% (6 of 8) | 79% (11 of 14) | 77% (17 of 22) |
|   infantry | 73% (8 of 11) | 43% (3 of 7) | 61% (11 of 18) |
|   war machine | 71% (39 of 55) | 100% (3 of 3) | 72% (42 of 58) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.7 (18%) | 0.0 (0%) | 1.7 (14%) |
| CHARGED: it charged | 0.3 (4%) | 0.0 (0%) | 0.3 (3%) |
| IN COMBAT: it fought this turn or the last | 0.7 (7%) | 0.7 (29%) | 1.3 (11%) |
| MOVED: a war machine that moved | 1.3 (14%) | 0.0 (0%) | 1.3 (11%) |
| NO TARGET IN RANGE | 0.7 (7%) | 1.3 (57%) | 2.0 (17%) |
| ONLY IN COMBAT: the only targets were in combat | 0.7 (7%) | 0.3 (14%) | 1.0 (9%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 3.3 (36%) | 0.0 (0%) | 3.3 (29%) |
| SHELTERED: the target was sheltered | 0.3 (4%) | 0.0 (0%) | 0.3 (3%) |
| OTHER BAR | 0.3 (4%) | 0.0 (0%) | 0.3 (3%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 10.0 | 4.0 | 67% | 9.7 pts | 97 pts |
| chariot | 6.0 | 1.3 | 78% | 5.1 pts | 31 pts |
| infantry | 3.7 | 0.3 | 91% | 2.6 pts | 10 pts |
| war machine | 14.3 | 10.7 | 70% | 30.4 pts | 436 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 2.0 | 3.3 | 2.7 |
| Charges that made contact a game | 2.0 | 2.3 | 2.2 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.00 declared, 1.00 contact (1 units) | 0.20 declared, 0.20 contact (5 units) | 0.33 declared, 0.33 contact (6 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 0.00 declared, 0.00 contact (2 units) | 0.00 declared, 0.00 contact (2 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.24 declared, 0.24 contact (21 units) | 0.41 declared, 0.27 contact (22 units) | 0.33 declared, 0.26 contact (43 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 44% (4 of 9) | 33% (1 of 3) | 100% (1 of 1) | 46% (6 of 13) |
| Character in a unit | 100% (6 of 6) | - | - | 100% (6 of 6) |
| Character on its own | 80% (4 of 5) | 50% (1 of 2) | 50% (2 of 4) | 64% (7 of 11) |
| Chariot | 33% (1 of 3) | 100% (2 of 2) | - | 60% (3 of 5) |
| Infantry | 67% (2 of 3) | 100% (1 of 1) | 50% (1 of 2) | 67% (4 of 6) |
| Monster | - | 0% (0 of 1) | - | 0% (0 of 1) |
| War Machines | 77% (10 of 13) | - | - | 77% (10 of 13) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Empire of Man | 3 | 67% (2 of 3); on the table 67% | 50% (3 of 6) | 61% | 70% (21 of 30) | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game | 33% (1 of 3); 0.3 uses a game |
| Grand Cathay | 1 | 100% (2 of 2); on the table 100% | 42% (10 of 24) | 67% | 30% (3 of 10) | 100% (2 of 2); 5.0 uses a game | 100% (1 of 1); 3.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Skaven | 1 | 0% (0 of 1); on the table 100% | 17% (1 of 6) | 46% | 78% (7 of 9) | 100% (1 of 1); 1.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Vampire Counts | 1 | 100% (4 of 4); on the table 100% | 17% (1 of 6) | 77% | 83% (5 of 6) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (cora-bb45c30-p41, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 0% (0) | 60% (3) | 38% (3) |
| ...free all their last turn and able to turn (per game) | 0.00 | 0.67 | 0.67 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.33 | 0.33 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.33 | 0.33 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: cora-bb45c30-p41

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.0 | 3.7 |
| Strategy | Charge objectives carried out (made contact) | 67% (4 of 6) | 70% (7 of 10) |
| Strategy | Shoot objectives carried out (shot that target) | 25% (12 of 48) | 25% (4 of 16) |
| Strategy | Support requests answered (helper made contact too) | - | 0% (0 of 1) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | - | 100% (2 of 2) |
| Strategy | Hexes on a unit its side charged or shot that turn | 50% (2 of 4) | - |
| Strategy | Joined characters whose unit fought | 0% (0 of 6) | 33% (1 of 3) |
| Strategy | Lone characters that fought | 38% (3 of 8) | 30% (3 of 10) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 1.7 | 3.3 |
| Movement | Points that never moved of their own | 449.3 | 266.7 |
| Movement | Fights charged into per game | 2.0 | 2.3 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 6 | 2 of 7, net +65 |
| Movement | Charges with odds: sweet spot (55-75%) | 2 of 6, net -140 | 2 of 7, net +0 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 1 of 6, net +0 | 0 of 7 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 of 6, net +8 | 1 of 7, net +304 |
| Shooting | Shots by shooting units (incl. breath weapons) | 11.0 | 4.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 36% (12 of 33) | 71% (10 of 14) |
| Shooting | Points destroyed by shooting units | 125.0 | 67.3 |
| Shooting | War machine shots | 13.0 | 1.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 41% (16 of 39) | 0% (0 of 4) |
| Shooting | Points destroyed by war machines | 318.3 | 43.3 |
| Magic | Magic missiles cast | 1.0 | 3.0 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 67% (2 of 3) | 33% (3 of 9) |
| Magic | Wounds caused by magic missiles | 1.0 | 5.3 |
| Magic | Wounds caused by other spells | 1.7 | 2.3 |
| Magic | Points destroyed by magic (all spells) | 63.3 | 54.7 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.0 / 1.3 / 0.3 / 0.0 | 3.0 / 0.0 / 0.3 / 0.3 |
| Combat | Points destroyed in combat | 0.0 | 178.7 |
| Combat | Points run down | 0.0 | 25.7 |
| Combat | Net points per charged fight, damage counted | -64 | +82 |
| Combat | Net per 100 charger points, damage counted | -27.9 | +64.6 |
| Combat | First round won (charged fights) | 67% | 86% |
| Combat | Net points per charged fight | -44 | +74 |
| Combat | Net points per supported fight / lone fight | - / -44 | - / +74 |
| Combat | Charged fights on a top-3 enemy unit | 0 of 6 | 2 of 7 |
| Game | Points lost | 437.7 | 701.7 |
| Game | VP from objectives | 486.7 | 753.3 |
| Game | Lone holders (player turns) | 2.0 | 6.0 |

- Mine won / drew / lost: 1 / 0 / 2 of 3 ended games (of 3); mean margin (Mine - Opponent) +10 VP
- The side that went first won 1 of 3 games with a winner
- Points traded per game (both sides' losses): 1139
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: cora-bb45c30-p41

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | - | - | - | - | 0.3 | +35.1 | 0.0 | 0.0 |
| ARMY TABLE | 14.3 | -47.4 | 0.0 | 51.3 | 16.7 | +707.8 | 0.0 | 420.7 |
| ARTILLERY RE-ROLL WEIGHED | 5.7 | +0.0 | 0.0 | 85.0 | 0.3 | +0.0 | 0.0 | 55.0 |
| CANNON PLAN MISSED | 1.0 | +0.0 | 180.0 | 43.3 | 0.3 | +0.0 | 43.3 | 55.0 |
| CANNON PLANNED TARGET | 12.7 | +607.0 | 853.3 | 85.0 | 1.0 | +107.3 | 86.7 | 165.0 |
| CANNON SIGHT KEPT | 2.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 55.0 |
| CARRIES OUT SET-UP | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CAST JOB | - | - | - | - | 5.3 | +148.6 | 273.3 | 0.0 |
| CASTS AFTER FRIENDS | - | - | - | - | 1.7 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | - | - | - | - | 2.0 | +50.1 | 0.0 | 18.3 |
| CHAFF PASSED | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHARACTER GUNS | - | - | - | - | 2.7 | +0.0 | 0.0 | 296.0 |
| CHARGE LOSSES | 13.3 | -316.2 | 0.0 | 51.3 | 16.7 | -1323.2 | 0.0 | 744.7 |
| CHARGE NOW FIRST | 1.3 | +0.0 | 48.3 | 93.7 | 1.7 | +0.0 | 194.3 | 0.0 |
| CLOSES ON WHAT IT BEATS | 7.3 | +0.0 | 0.0 | 0.0 | 16.0 | +0.0 | 0.0 | 30.7 |
| COMBAT PIVOT | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 48.3 |
| CONVEYANCE SEARCH | - | - | - | - | 3.0 | +219.7 | 0.0 | 0.0 |
| COVER ONCE | 5.7 | -222.7 | 0.0 | 110.7 | 8.0 | -664.4 | 0.0 | 104.7 |
| DEFENSIVE ARMY | 0.7 | +0.0 | 360.0 | 0.0 | - | - | - | - |
| DENIED BY THE FIGHT | 0.7 | -1.7 | 0.0 | 0.0 | 1.3 | -12.7 | 163.7 | 0.0 |
| DEPLOY BY FIGURES | 7.0 | -106.9 | 0.0 | 0.0 | 7.3 | -20.3 | 0.0 | 55.0 |
| EXACT ROUND | 1.3 | +17.2 | 79.0 | 93.7 | 2.3 | -48.0 | 207.0 | 0.0 |
| FALL BACK GOOD ORDER | 2.0 | +114.7 | 79.0 | 93.7 | 3.0 | +8.5 | 207.0 | 0.0 |
| FALLS SHORT | - | - | - | - | 24.0 | +385.1 | 0.0 | 445.3 |
| FEATURE BUFFS | 0.7 | +20.5 | 0.0 | 0.0 | 2.3 | +18.4 | 0.0 | 0.0 |
| FIGHT TO THE END | 1.0 | +9.6 | 48.3 | 93.7 | 1.3 | +57.1 | 54.7 | 0.0 |
| FIVE ACTION | 96.7 | +6908.2 | 3099.0 | 828.3 | 89.7 | +4929.7 | 1087.0 | 1627.0 |
| FLANK NOT WEIGHED | 4.7 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 52.3 |
| FOLLOW UP WEIGHED | 1.3 | +188.4 | 0.0 | 93.7 | 1.0 | +106.1 | 0.0 | 0.0 |
| FOUR ROUNDS | 2.0 | +278.0 | 79.0 | 93.7 | 3.3 | +222.7 | 207.0 | 0.0 |
| FREED FROM HIS FIGHT | 3.0 | +0.0 | 0.0 | 0.0 | 5.7 | +0.0 | 0.0 | 144.0 |
| FRIEND SHOOTS FIRST | 0.3 | -3.5 | 0.0 | 0.0 | - | - | - | - |
| GIVES UP | - | - | - | - | 0.7 | -9.5 | 67.3 | 0.0 |
| GOAL WALK | 6.0 | +373.9 | 0.0 | 0.0 | 15.0 | +1111.3 | 0.0 | 0.0 |
| GUN FIGURES | 2.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.6 | 0.0 | 65.0 |
| GUN MASK | 1.0 | +3.9 | 0.0 | 0.0 | - | - | - | - |
| HARD STAY DROPPED | 2.7 | +0.0 | 0.0 | 202.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | - | - | - | - | 2.7 | +0.0 | 0.0 | 74.0 |
| HIS CHARGE BY HIS RUN | 5.3 | +0.0 | 0.0 | 0.0 | 7.3 | +0.0 | 0.0 | 336.3 |
| HIS CHARGE DENIED | 0.7 | +27.8 | 0.0 | 0.0 | 0.7 | +7.4 | 0.0 | 0.0 |
| HIS CHARGE LIST | 5.0 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 148.3 |
| HIS LEGAL MOVES | 2.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 5.3 | -41.0 | 0.0 | 0.0 | 2.7 | -64.3 | 0.0 | 118.3 |
| HIS ONE QUARTER | 2.7 | +0.0 | 0.0 | 0.0 | 5.0 | +0.0 | 0.0 | 60.0 |
| HIS OWN BEST MOVE | 2.7 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVE | 11.7 | +0.0 | 0.0 | 51.3 | - | - | - | - |
| HIS RANDOM MOVER COMES | 3.3 | +0.0 | 0.0 | 51.3 | - | - | - | - |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 40.0 | +1090.2 | 0.0 | 67.3 | 56.3 | +3956.8 | 0.0 | 1275.3 |
| HIS SHOTS BY HIS RUN | 23.0 | +476.1 | 0.0 | 51.3 | 44.3 | +1575.2 | 0.0 | 1040.7 |
| HIS TURN DENIED | - | - | - | - | 1.7 | +102.1 | 163.7 | 0.0 |
| HIS TURN RUN | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 14.0 | +0.0 | 0.0 | 51.3 | 21.3 | +0.0 | 0.0 | 61.3 |
| HOLDER ASSIGNMENT | 8.3 | +876.5 | 0.0 | 25.7 | 12.0 | +959.2 | 0.0 | 30.7 |
| HOLDS AMBUSHERS | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 1.7 | -40.4 | 79.0 | 93.7 | 3.0 | -51.9 | 207.0 | 0.0 |
| HUNT IN PAIRS | - | - | - | - | 0.7 | +26.1 | 0.0 | 0.0 |
| IDLE COST | - | - | - | - | 15.0 | -189.7 | 0.0 | 254.0 |
| JOINT CHARGE NOW | - | - | - | - | 1.0 | -19.0 | 54.7 | 0.0 |
| KEEP FALLS | 0.3 | +1.8 | 0.0 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 2.7 | +0.0 | 0.0 | 51.3 | 0.7 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 0.3 | +1.4 | 0.0 | 0.0 | 1.0 | +51.5 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 4.3 | +0.0 | 70.0 | 644.0 | 6.0 | +0.0 | 319.3 | 180.0 |
| LONE WIZARD KEPT IN | 0.7 | +46.6 | 0.0 | 0.0 | 0.3 | +58.3 | 0.0 | 0.0 |
| LONG SHOT | - | - | - | - | 0.3 | +0.6 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | 1.3 | +1.2 | 79.0 | 93.7 | 2.3 | +3.1 | 139.7 | 0.0 |
| MANOEUVRE | 1.3 | +0.0 | 0.0 | 0.0 | 2.3 | +33.5 | 0.0 | 30.7 |
| MARCH BY THE SUM | 0.3 | +0.8 | 0.0 | 0.0 | 0.3 | +1.9 | 0.0 | 0.0 |
| MARCH CHECK | - | - | - | - | 1.0 | +86.3 | 0.0 | 0.0 |
| MARCH OF THE TABLE | - | - | - | - | 0.7 | +21.1 | 0.0 | 0.0 |
| MARCH OVER CASTS | 0.3 | -121.7 | 0.0 | 0.0 | 1.0 | +211.2 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 2.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MAX FOR POSITIONING | 2.0 | +63.6 | 0.0 | 0.0 | 4.7 | +116.7 | 0.0 | 180.0 |
| MEETS IN TIME | 4.0 | +342.3 | 0.0 | 0.0 | 4.3 | +157.8 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 1.0 | +87.5 | 0.0 | 0.0 | 7.3 | +126.8 | 0.0 | 328.0 |
| MISSILES NEXT TURN | 1.3 | +55.0 | 0.0 | 0.0 | 10.7 | +130.1 | 0.0 | 328.0 |
| MOVE ORDER | 0.3 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 104.7 | 74.0 |
| MOVE SPELL SPOT | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 3.0 | +281.1 | 0.0 | 0.0 | 4.3 | +589.4 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 8.3 | +337.5 | 0.0 | 122.0 | 8.0 | +373.6 | 0.0 | 104.7 |
| NEXT CHARGE BY LIST | 0.7 | +93.4 | 0.0 | 0.0 | 4.3 | +570.7 | 0.0 | 0.0 |
| NEXT OBJECTIVE NEARER | - | - | - | - | 0.7 | -2.2 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 1.7 | -106.6 | 79.0 | 93.7 | 2.3 | -84.7 | 207.0 | 0.0 |
| NO LATE CUT | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 0.7 | -0.8 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 3.0 | -272.7 | 0.0 | 0.0 | 1.7 | -72.7 | 0.0 | 55.0 |
| OGRE LOADER SECOND SHOT | - | - | - | - | 0.3 | +36.0 | 0.0 | 0.0 |
| ONE CHECK AFTER THE LAST CHANGE | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 3.0 | -60.2 | 0.0 | 0.0 | 5.7 | -113.3 | 0.0 | 180.0 |
| ONE JOINT FIGURE | - | - | - | - | 0.7 | -4.9 | 54.7 | 0.0 |
| ONE OBJECTIVE FORMULA | 3.3 | +45.4 | 0.0 | 0.0 | 8.7 | -52.6 | 0.0 | 30.7 |
| ONE ROUTE | 2.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| OPENS UP | 0.3 | +67.5 | 0.0 | 0.0 | - | - | - | - |
| OVERRUNS AWAY | 1.0 | +15.2 | 30.7 | 0.0 | - | - | - | - |
| PATHS CROSS | - | - | - | - | 0.7 | +2.1 | 0.0 | 0.0 |
| PERIAPT WORTH | - | - | - | - | 0.3 | +24.8 | 0.0 | 0.0 |
| PLAN RESULT | 42.7 | +1431.3 | 1321.7 | 652.0 | 45.0 | +383.4 | 274.7 | 1058.0 |
| PROMISE BY ITS OWN SUM | 5.0 | -95.1 | 0.0 | 0.0 | 4.3 | -43.1 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | - | - | - | - | 1.0 | -2.5 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | 0.3 | -3.5 | 0.0 | 0.0 | 0.3 | -28.2 | 0.0 | 0.0 |
| PROMISE SHOT AWAY | 0.3 | -0.4 | 0.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | 20.3 | +1566.7 | 483.3 | 272.7 | 13.3 | +1574.5 | 110.7 | 108.3 |
| RANDOM MOVE BY FIGURES | - | - | - | - | 3.3 | +18.7 | 0.0 | 285.0 |
| REAL GROUND | 2.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| REDIRECT COUNTER | 0.7 | +35.6 | 0.0 | 0.0 | 0.7 | +62.3 | 0.0 | 0.0 |
| REDIRECT FOR A FRIEND IN REACH | 0.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| REDIRECT WEIGHED | - | - | - | - | 0.3 | +2.7 | 0.0 | 0.0 |
| REFORMS TO MEET IT | 0.7 | -7.3 | 0.0 | 0.0 | - | - | - | - |
| RESERVE FALL BACK | - | - | - | - | 0.3 | +12.9 | 0.0 | 0.0 |
| RISK BY ARC | 2.0 | -39.0 | 79.0 | 93.7 | 2.7 | +51.1 | 152.3 | 0.0 |
| ROUNDS AFTER TERROR | 0.7 | -9.7 | 0.0 | 0.0 | 1.3 | -24.2 | 110.7 | 0.0 |
| RUN DOWN | 1.7 | -12.2 | 79.0 | 93.7 | 3.0 | -18.3 | 207.0 | 0.0 |
| SAFER THAN THE JOB | - | - | - | - | 0.3 | +16.1 | 0.0 | 0.0 |
| SCOUT SPOT | 0.7 | +4.7 | 0.0 | 0.0 | - | - | - | - |
| SCOUT WAITS | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 2.3 | -180.5 | 0.0 | 55.0 |
| SEARCH SPOT | 0.3 | +0.8 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| SET CREDITED ONCE | - | - | - | - | 1.3 | -6.0 | 0.0 | 0.0 |
| SET UP BY THE SET | - | - | - | - | 1.7 | -15.4 | 0.0 | 30.7 |
| SET-UP ANY TARGET | - | - | - | - | 0.3 | +6.3 | 0.0 | 0.0 |
| SET-UP MISSED | - | - | - | - | 0.7 | +70.9 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 16.0 | +0.0 | 0.0 | 274.3 | 6.3 | +0.0 | 0.0 | 165.0 |
| SHOOTS FROM THE BEST SPOT | - | - | - | - | 3.3 | +134.2 | 298.7 | 0.0 |
| SHORT GUN FORWARD | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SHOT OR CHARGE | 0.3 | -1.1 | 0.0 | 0.0 | 0.3 | -8.6 | 54.7 | 0.0 |
| SHOT REPLANNED | - | - | - | - | 0.3 | +0.0 | 43.3 | 55.0 |
| SHOT RISK POINTS | 18.7 | +329.5 | 0.0 | 118.7 | 36.3 | -275.0 | 0.0 | 1026.3 |
| SHOTS AFTER THE MOVES | 6.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 20.7 | +1706.4 | 0.0 | 300.0 | 5.0 | +285.9 | 0.0 | 378.0 |
| SPELL SETS UP CHARGE | - | - | - | - | 0.3 | +6.3 | 0.0 | 0.0 |
| SPELL WORTH | 1.3 | +2.9 | 0.0 | 0.0 | 5.0 | +81.7 | 360.0 | 360.0 |
| SPELLS IN THE FIGHT | 0.7 | +4.7 | 48.3 | 93.7 | - | - | - | - |
| SPOT AS THE GAME MOVES | 4.3 | +0.0 | 0.0 | 0.0 | 9.3 | +0.0 | 0.0 | 52.3 |
| STAND AND SHOOT | - | - | - | - | 0.3 | -12.6 | 54.7 | 0.0 |
| STANDS FOR A REASON | - | - | - | - | 1.7 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 62.7 | +0.0 | 3020.0 | 683.3 | 26.3 | +0.0 | 880.0 | 683.0 |
| STAY WORTH | 41.3 | +1228.9 | 2730.0 | 497.0 | 7.0 | +120.4 | 228.0 | 560.0 |
| STRIKE BY THE ODDS | - | - | - | - | 0.3 | +1.3 | 67.3 | 0.0 |
| STUCK PIVOT | - | - | - | - | 0.7 | +0.0 | 0.0 | 48.3 |
| SUPPORT ADDS | 4.3 | +171.6 | 0.0 | 0.0 | 1.3 | +47.9 | 0.0 | 0.0 |
| SUPPORT WORKED OUT | 4.3 | +171.6 | 0.0 | 0.0 | 1.3 | +47.9 | 0.0 | 0.0 |
| SURE REACH TOGETHER | 0.3 | +5.7 | 0.0 | 0.0 | - | - | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 2.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| THE PROMISE ADDS | - | - | - | - | 0.3 | -28.2 | 0.0 | 0.0 |
| THE PROMISED MOVE | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE ROW IN ITS ORDER | 3.3 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 52.3 |
| THE ROW KEEPS ITS WAY | 1.3 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 0.7 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 42.0 | +0.0 | 0.0 | 367.3 | 43.7 | +0.0 | 0.0 | 671.0 |
| TIED UP BY THE SUM | 1.0 | +104.3 | 30.7 | 0.0 | 0.3 | +7.3 | 0.0 | 0.0 |
| TIME ON OUR SIDE | 46.7 | +503.7 | 0.0 | 458.7 | - | - | - | - |
| WAITS AGAIN | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| WAR ENGINE JOBS | - | - | - | - | 0.7 | +0.0 | 134.7 | 0.0 |
| WHAT THE JOINER ADDS | 0.7 | +37.9 | 0.0 | 0.0 | - | - | - | - |
| WHO FIGHTS | 0.3 | -2.8 | 0.0 | 0.0 | 1.3 | +11.0 | 54.7 | 0.0 |
| WHO HITS BACK | - | - | - | - | 0.3 | +5.5 | 0.0 | 0.0 |
| WHOLE FIGHT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT DANGER | 4.3 | -190.3 | 0.0 | 51.3 | 1.0 | -58.7 | 0.0 | 0.0 |
| WHOLE FIGHT GAIN | - | - | - | - | 0.3 | +39.1 | 54.7 | 0.0 |
| WOUNDS ON THE RANKS | 3.3 | +28.2 | 0.0 | 0.0 | 4.0 | +136.7 | 0.0 | 148.0 |

### Rule changes: cora-bb45c30-p41

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS SHOT LIST | 289 | 288 | 67 | 22.33 | +1643 | +24.5 |
| ARMY TABLE | 93 | 93 | 59 | 19.67 | +1741 | +29.5 |
| HOLDER ASSIGNMENT | 61 | 61 | 56 | 18.67 | +4297 | +76.7 |
| HIS SHOTS BY HIS RUN | 202 | 202 | 49 | 16.33 | +953 | +19.5 |
| SHOT RISK POINTS | 165 | 165 | 33 | 11.00 | +821 | +24.9 |
| LEGAL CHARGES ONLY | 31 | 31 | 31 | 10.33 | +0 | +0.0 |
| TIME ON OUR SIDE | 140 | 126 | 31 | 10.33 | +118 | +3.8 |
| FIVE ACTION | 559 | 557 | 26 | 8.67 | +1965 | +75.6 |
| DEPLOY BY FIGURES | 43 | 43 | 25 | 8.33 | +379 | +15.2 |
| THE TABLE AGAIN | 36 | 36 | 24 | 8.00 | +0 | +0.0 |
| GOAL WALK | 63 | 63 | 21 | 7.00 | +878 | +41.8 |
| ARTILLERY RE-ROLL WEIGHED | 18 | 18 | 18 | 6.00 | +0 | +0.0 |
| MOVE TO CHARGE COMPUTED | 22 | 21 | 17 | 5.67 | +813 | +47.8 |
| CAST JOB | 16 | 16 | 14 | 4.67 | +140 | +10.0 |
| OFF BEST | 14 | 14 | 14 | 4.67 | -1036 | -74.0 |
| QUARTER ODDS | 101 | 100 | 14 | 4.67 | +1872 | +133.7 |
| MEETS IN TIME | 25 | 25 | 12 | 4.00 | +880 | +73.3 |
| MOVE ORDER | 12 | 12 | 12 | 4.00 | +0 | +0.0 |
| HARD STAY DROPPED | 11 | 11 | 11 | 3.67 | +0 | +0.0 |
| NEXT CHARGE BY LIST | 15 | 15 | 11 | 3.67 | +623 | +56.7 |
| IDLE COST | 45 | 41 | 10 | 3.33 | +55 | +5.5 |
| CANNON SIGHT KEPT | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| CHARGE LOSSES | 90 | 90 | 9 | 3.00 | +639 | +71.0 |
| FOUR ROUNDS | 16 | 16 | 8 | 2.67 | +597 | +74.6 |
| ADVANCE LANE KEPT | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 7 | 7 | 7 | 2.33 | +883 | +126.2 |
| MAX FOR POSITIONING | 20 | 20 | 7 | 2.33 | +101 | +14.4 |
| FALLS SHORT | 72 | 56 | 6 | 2.00 | +26 | +4.3 |
| PROMISE BY ITS OWN SUM | 28 | 28 | 6 | 2.00 | -415 | -69.1 |
| REDIRECT FOR A FRIEND IN REACH | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| SHOOTS FROM THE BEST SPOT | 10 | 10 | 6 | 2.00 | +172 | +28.6 |
| COVER ONCE | 41 | 32 | 5 | 1.67 | +167 | +33.5 |
| SUPPORT ADDS | 17 | 17 | 5 | 1.67 | +51 | +10.1 |
| SUPPORT WORKED OUT | 17 | 17 | 5 | 1.67 | +51 | +10.1 |
| LANE BY FIGURES | 4 | 4 | 4 | 1.33 | +159 | +39.7 |
| RANDOM MOVE BY FIGURES | 10 | 10 | 4 | 1.33 | +56 | +14.0 |
| TIED UP BY THE SUM | 4 | 4 | 4 | 1.33 | +156 | +38.9 |
| CHAFF IN THE MOVE | 6 | 5 | 3 | 1.00 | +18 | +6.0 |
| CHARGE NOW FIRST | 9 | 9 | 3 | 1.00 | -197 | -65.6 |
| COMBAT PIVOT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| HOLDS AMBUSHERS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| JOINT CHARGE NOW | 3 | 3 | 3 | 1.00 | -57 | -19.0 |
| LONE WIZARD KEPT IN | 3 | 3 | 3 | 1.00 | +315 | +104.9 |
| MARCH CHECK | 3 | 3 | 3 | 1.00 | +59 | +19.6 |
| MISSILES IN THE MOVE | 25 | 18 | 3 | 1.00 | +188 | +62.6 |
| PROMISE KNOWS THE FIGHT | 3 | 3 | 3 | 1.00 | -7 | -2.5 |
| RISK BY ARC | 14 | 14 | 3 | 1.00 | +50 | +16.6 |
| SHOTS IN THE MOVE | 77 | 57 | 3 | 1.00 | +163 | +54.4 |
| CANNON PLANNED TARGET | 41 | 41 | 2 | 0.67 | +26 | +13.2 |
| CASTS FROM BEHIND | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| CHAFF PASSED | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| EXACT ROUND | 11 | 11 | 2 | 0.67 | +5 | +2.5 |
| FALL BACK GOOD ORDER | 15 | 15 | 2 | 0.67 | +90 | +45.2 |
| MARCH BY THE SUM | 2 | 2 | 2 | 0.67 | +8 | +4.0 |
| MARCH OF THE TABLE | 2 | 2 | 2 | 0.67 | -63 | -31.7 |
| NEARER NOT NEEDED | 49 | 47 | 2 | 0.67 | +48 | +23.8 |
| ONE OBJECTIVE FORMULA | 36 | 29 | 2 | 0.67 | +78 | +38.8 |
| PATHS CROSS | 2 | 2 | 2 | 0.67 | +6 | +3.1 |
| SCOUT WAITS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| SHORT GUN FORWARD | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| STAY WORTH | 145 | 134 | 2 | 0.67 | +31 | +15.3 |
| STUCK PIVOT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| THE ROW IN ITS ORDER | 23 | 2 | 2 | 0.67 | +0 | +0.0 |
| WHOLE FIGHT DANGER | 16 | 16 | 2 | 0.67 | +19 | +9.6 |
| WOUNDS ON THE RANKS | 22 | 22 | 2 | 0.67 | +93 | +46.6 |
| AFTERMATH IN POINTS | 1 | 1 | 1 | 0.33 | +105 | +105.3 |
| HIS CHARGE DENIED | 4 | 4 | 1 | 0.33 | +65 | +65.2 |
| HUNT IN PAIRS | 2 | 2 | 1 | 0.33 | +25 | +25.0 |
| KEEP FALLS | 1 | 1 | 1 | 0.33 | +9 | +8.8 |
| MANOEUVRE | 11 | 11 | 1 | 0.33 | +128 | +127.6 |
| MISSILES NEXT TURN | 36 | 25 | 1 | 0.33 | +0 | +0.0 |
| OGRE LOADER SECOND SHOT | 1 | 1 | 1 | 0.33 | +108 | +108.0 |
| ONE FIGHT FORMULA | 26 | 15 | 1 | 0.33 | +6 | +5.5 |
| OPENS UP | 1 | 1 | 1 | 0.33 | +65 | +65.2 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.33 | +74 | +74.4 |
| PROMISE SHOT AWAY | 1 | 1 | 1 | 0.33 | -1 | -1.1 |
| REDIRECT COUNTER | 4 | 4 | 1 | 0.33 | +57 | +57.2 |
| REDIRECT WEIGHED | 1 | 1 | 1 | 0.33 | +11 | +10.9 |
| RESERVE FALL BACK | 1 | 1 | 1 | 0.33 | +39 | +38.6 |
| SAFER THAN THE JOB | 1 | 1 | 1 | 0.33 | +48 | +48.3 |
| SEARCH SPOT | 2 | 2 | 1 | 0.33 | +2 | +2.4 |
| SHOT REPLANNED | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| SHOTS AFTER THE MOVES | 22 | 22 | 1 | 0.33 | +0 | +0.0 |
| SPELLS IN THE FIGHT | 2 | 2 | 1 | 0.33 | +5 | +5.4 |
| STRIKE BY THE ODDS | 1 | 1 | 1 | 0.33 | +4 | +3.9 |
| SURE REACH TOGETHER | 1 | 1 | 1 | 0.33 | +10 | +9.6 |
| WHO HITS BACK | 1 | 1 | 1 | 0.33 | +11 | +10.8 |
| CANNON PLAN MISSED | 4 | 4 | 0 | 0.00 | - | - |
| CARRIES OUT SET-UP | 1 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 5 | trace | - | - | - | - |
| CHARACTER GUNS | 8 | 8 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 70 | 70 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 9 | not checked | - | - | - | - |
| DEFENSIVE ARMY | 2 | 2 | 0 | 0.00 | - | - |
| DENIED BY THE FIGHT | 6 | 6 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 9 | 9 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 7 | 7 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 27 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 26 | 26 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 1 | 1 | 0 | 0.00 | - | - |
| GIVES UP | 2 | 2 | 0 | 0.00 | - | - |
| GUN FIGURES | 9 | not checked | - | - | - | - |
| GUN MASK | 3 | 3 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 8 | 8 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 38 | 38 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 20 | 20 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 7 | 7 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 24 | 24 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 23 | 23 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 18 | 17 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 35 | 33 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 10 | 10 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 5 | 5 | 0 | 0.00 | - | - |
| HIS TURN RUN | 18 | 18 | 0 | 0.00 | - | - |
| HOLD ODDS | 106 | 106 | 0 | 0.00 | - | - |
| HONEST WORTH | 14 | 14 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 10 | 10 | 0 | 0.00 | - | - |
| LONG SHOT | 1 | 1 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 11 | 11 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 4 | 4 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 6 | 6 | 0 | 0.00 | - | - |
| MOVE SPELL SPOT | 4 | not checked | - | - | - | - |
| NEXT OBJECTIVE NEARER | 2 | 2 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 12 | 12 | 0 | 0.00 | - | - |
| NO LATE CUT | 3 | 3 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 2 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 3 | not checked | - | - | - | - |
| ONE JOINT FIGURE | 2 | 2 | 0 | 0.00 | - | - |
| ONE ROUTE | 6 | 6 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 18 | 18 | 0 | 0.00 | - | - |
| OVERRUNS AWAY | 3 | 3 | 0 | 0.00 | - | - |
| PLAN RESULT | 263 | trace | - | - | - | - |
| PROMISE READS THE TABLE | 2 | 2 | 0 | 0.00 | - | - |
| REAL GROUND | 6 | 6 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 2 | 1 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 6 | 6 | 0 | 0.00 | - | - |
| RUN DOWN | 14 | 14 | 0 | 0.00 | - | - |
| SCOUT SPOT | 2 | 2 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 7 | 7 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 4 | 4 | 0 | 0.00 | - | - |
| SET UP BY THE SET | 5 | 5 | 0 | 0.00 | - | - |
| SET-UP ANY TARGET | 1 | not checked | - | - | - | - |
| SET-UP MISSED | 2 | trace | - | - | - | - |
| SHOOTERS ON THE TABLE | 67 | not checked | - | - | - | - |
| SHOT OR CHARGE | 2 | 2 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 1 | not checked | - | - | - | - |
| SPELL WORTH | 19 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 41 | 39 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 1 | 1 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 5 | 5 | 0 | 0.00 | - | - |
| STANDS STILL | 267 | 266 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 8 | not checked | - | - | - | - |
| THE PROMISE ADDS | 1 | 1 | 0 | 0.00 | - | - |
| THE PROMISED MOVE | 3 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 10 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 7 | not checked | - | - | - | - |
| THE TABLE BINDS | 257 | not checked | - | - | - | - |
| WAITS AGAIN | 4 | 4 | 0 | 0.00 | - | - |
| WAR ENGINE JOBS | 2 | 2 | 0 | 0.00 | - | - |
| WHAT THE JOINER ADDS | 2 | 2 | 0 | 0.00 | - | - |
| WHO FIGHTS | 5 | 5 | 0 | 0.00 | - | - |
| WHOLE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| WHOLE FIGHT GAIN | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: cora-bb45c30-p41

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 3.00 | 1.67 | 74.0 |
| ARMY TABLE | rule | 2.67 | 1.00 | 59.1 |
| PROMISE BY ITS OWN SUM | rule | 1.67 | 0.33 | 69.1 |
| CHARGE NOW FIRST | rule | 0.67 | 0.33 | 65.6 |
| PROMISE KNOWS THE FIGHT | rule | - | 1.00 | 2.5 |
| MARCH OF THE TABLE | rule | - | 0.67 | 31.7 |
| JOINT CHARGE NOW | rule | - | 0.33 | 117.4 |
| PROMISE SHOT AWAY | rule | 0.33 | - | 1.1 |

### Plans: cora-bb45c30-p41

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 2.0 | 50% | 259 | 101 | 39% |
| Mine | move | 26.3 | 99% | 1356 | 0 | 0% |
| Mine | shoot | 14.3 | 49% | 1744 | 1330 | 76% |
| Opponent | charge | 3.0 | 44% | 396 | 195 | 49% |
| Opponent | join | 1.7 | 100% | 43 | 0 | 0% |
| Opponent | move | 35.3 | 94% | 2015 | 0 | 0% |
| Opponent | shoot | 3.7 | 73% | 219 | 189 | 86% |
| Opponent | support | 1.3 | 75% | 6 | 0 | 0% |

### Battle groups: cora-bb45c30-p41

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 0.7 | 50% | 100% | 0% | - | 0% | 0% | 0% | 100% | 0% |
| Opponent | REDIRECT COUNTER | 0.7 | 50% | 0% | 0% | - | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: cora-bb45c30-p41

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 2 | 0 (2) | 0 | 0 | 0 | 50% | 6.0 | 0 (1) | - | 0 (1) | 0 (1) | 0 (1) |
| Mine | Character | 12 | 13 (12) | 13 | 0 | 26 | 75% | 2.3 | 0 (4) | 0 (3) | 27 (3) | 20 (6) | 0 (4) |
| Mine | Fast Hammer | 5 | 13 (5) | 0 | 13 | 22 | 60% | 1.5 | 6 (3) | 0 (1) | 38 (1) | 22 (3) | 0 (2) |
| Mine | Hammer | 4 | 26 (4) | 0 | 26 | 0 | 50% | 1.0 | 0 (1) | 37 (3) | - | 0 (3) | 89 (1) |
| Mine | Shooter | 5 | 33 (5) | 24 | 9 | 65 | 0% | 1.2 | 18 (1) | 0 (2) | 70 (2) | 33 (5) | - |
| Mine | War machine | 11 | 68 (11) | 68 | 0 | 27 | 18% | 1.1 | 10 (5) | 116 (6) | - | 0 (2) | 83 (9) |
| Mine | Wizard | 2 | 0 (2) | 0 | 0 | 0 | 50% | 4.0 | 0 (1) | 0 (1) | - | 0 (1) | 0 (1) |
| Opponent | Chaff | 5 | 0 (5) | 0 | 0 | 19 | 80% | 6.0 | 0 (3) | 0 (2) | - | 0 (5) | - |
| Opponent | Character | 11 | 17 (11) | 17 | 0 | 35 | 27% | 2.9 | 0 (3) | 21 (3) | 32 (3) | 28 (5) | 13 (4) |
| Opponent | Clean-up | 1 | 220 (1) | 0 | 220 | 100 | 0% | 3.0 | - | 220 (1) | - | 220 (1) | - |
| Opponent | Fast Hammer | 6 | 91 (6) | 42 | 49 | 0 | 17% | 2.8 | 33 (3) | 179 (3) | - | 123 (4) | 54 (2) |
| Opponent | Fragile | 2 | 0 (2) | 0 | 0 | 45 | 100% | - | - | 0 (1) | 0 (1) | - | 0 (2) |
| Opponent | Hammer | 4 | 79 (4) | 79 | 0 | 100 | 25% | 1.7 | 99 (2) | 134 (1) | 0 (1) | 114 (3) | 0 (1) |
| Opponent | Holder | 4 | 86 (4) | 0 | 86 | 19 | 50% | 3.0 | - | 0 (2) | 160 (2) | 86 (4) | - |
| Opponent | Shooter | 2 | 0 (2) | 0 | 0 | 100 | 0% | 2.5 | - | - | 0 (2) | 0 (1) | 0 (1) |
| Opponent | War machine | 2 | 39 (2) | 39 | 0 | 100 | 0% | 1.0 | - | 39 (2) | - | 79 (1) | 0 (1) |
| Opponent | Wizard | 2 | 0 (2) | 0 | 0 | 0 | 0% | 1.0 | 0 (2) | - | - | 0 (2) | - |

### Charged fights: cora-bb45c30-p41

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Empire of Man | 3 | 507 | 31 | 2.0 | 1.0 | 15 | 60 | -44 | 0 of 6 | 4 of 6 | - | -44 |
| Opponent | Grand Cathay | 1 | 496 | 125 | 2.0 | 1.0 | 62 | 0 | +62 | 0 of 2 | 2 of 2 | - | +62 |
| Opponent | Skaven | 1 | 0 | 0 | 1.0 | 1.0 | 0 | 41 | -41 | 0 of 1 | 1 of 1 | - | -41 |
| Opponent | Vampire Counts | 1 | 0 | 434 | 4.0 | 1.0 | 108 | 0 | +108 | 2 of 4 | 3 of 4 | - | +108 |
| **Opponent** | all armies | 3 | 165 | 186 | 2.3 | 1.0 | 80 | 6 | +74 | 2 of 7 | 6 of 7 | - | +74 |

### Effective charges: cora-bb45c30-p41

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Empire of Man | 6 | 0 | 0 | 2 (net -140) | 1 (net +0) | 1 (net +0) | 2 (net +8) | 0 | 33% (2 of 6) |
| Opponent | Grand Cathay | 2 | 1 (net +0) | 0 | 0 | 1 (net +125) | 0 | 0 | 0 | 0% (0 of 2) |
| Opponent | Skaven | 1 | 0 | 0 | 0 | 1 (net -41) | 0 | 0 | 0 | 0% (0 of 1) |
| Opponent | Vampire Counts | 4 | 1 (net +130) | 0 | 2 (net +0) | 0 | 0 | 1 (net +304) | 0 | 50% (2 of 4) |

### Charged fights, damage counted: cora-bb45c30-p41

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Effective (55-75%) | 2 | 172 | 166 | -140 | 44 | 274 | -231 | -133.8 |
| Mine | 76-89% | 1 | 265 | 167 | +0 | 139 | 106 | +33 | +12.5 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 189 | 92 | +8 | 132 | 122 | +9 | +4.8 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 380 | 41 | +0 | 28 | 0 | +28 | +7.5 |
| Mine | All fights | 6 | 228 | 120 | -44 | 86 | 150 | -64 | -27.9 |
| Opponent | Long shot (under 50%) | 2 | 110 | 147 | +65 | 86 | 0 | +86 | +77.4 |
| Opponent | Effective (55-75%) | 2 | 116 | 150 | +0 | 6 | 0 | +6 | +5.2 |
| Opponent | 76-89% | 2 | 123 | 101 | +42 | 62 | 20 | +42 | +34.1 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 186 | 202 | +304 | 304 | 0 | +304 | +163.4 |
| Opponent | All fights | 7 | 126 | 143 | +74 | 87 | 6 | +82 | +64.6 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| cora-bb45c30-p41 | move | 17 | 3 (18%) | 3 (18%) | 2 (12%) | 12 (71%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L0827 |
| Invocation of Nehek | Opponent | L0827 |
| Periapt of Soul Exchange | Opponent | L0721 |
| Ring of Jet | Opponent | L0810 |
| Storm Daemon (Renegade 2.0) | Opponent | L0721 |
| Twice-Blessed Armour | Mine | L0721 |
| Twice-Blessed Armour | Opponent | L0810 |
| Witch Hunter's Ward | Mine | L0721, L0810, L0827 |

# Doctrine scorecard: cora-bb45c30-p43

### Scorecard: cora-bb45c30-p43

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L1118 | 2 | 1 | Mine | - | - | 2 | 1 | 1 | 0 | 0 | 0 | 330 |
| L1118 | 2 | 1 | Opponent | - | - | 3 | 2 | 0 | 0 | 0 | 0 | 490 |
| L1135 | 1 | 1 | Mine | no | 0 | 2 | 6 | 1 | 0 | 0 | 0 | 330 |
| L1135 | 1 | 1 | Opponent | no | 0 | 4 | 0 | 2 | 0 | 0 | 0 | 0 |
| L1228 | 4 | 1 | Mine | no | 0 | 2 | 1 | 1 | 0 | 0 | 0 | 330 |
| L1228 | 4 | 1 | Opponent | no | 1 | 3 | 1 | 1 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 0% | 0.0 | 2.0 | 2.7 | 1.0 | 0.0 | 0.0 | 0.0 | 330.0 |
| **Average** | | | Opponent | 0% | 0.5 | 3.3 | 1.0 | 1.0 | 0.0 | 0.0 | 0.0 | 163.3 |

### KPIs: cora-bb45c30-p43

Rules off - Opponent only: ONE RUN A PLAN.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 57% (8 of 14) | 0% (0 of 16) | 27% (8 of 30) |
| Winner chose to follow up after the loser gave ground |  | 100% (5 of 5); on the table 100% | 0% (0 of 1); on the table 0% | 83% (5 of 6); on the table 83% |
| Winner chose to pursue after the loser fell back in good order |  | 67% (2 of 3); on the table 100% | - | 67% (2 of 3); on the table 100% |
| Winner chose to pursue after the loser fled |  | 33% (1 of 3); on the table 33% | 50% (1 of 2); on the table 50% | 40% (2 of 5); on the table 40% |
| Winner chose to follow up or pursue (all three) |  | 73% (8 of 11); on the table 82% | 33% (1 of 3); on the table 33% | 64% (9 of 14); on the table 71% |
| Magic missiles tried each own turn | 50%+ | 12% (9 of 72) | 28% (5 of 18) | 16% (14 of 90) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 19% (9 of 48) | 42% (5 of 12) | 23% (14 of 60) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | - | - |
| Points that never fought | lower | 53% (3172 of 5998) | 24% (1446 of 6000) | 38% (4618 of 11998) |
|   infantry points that never fought | lower | 100% (730 of 730) | 52% (407 of 782) | 75% (1137 of 1512) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 56% (14 of 25) | 85% (22 of 26) | 71% (36 of 51) |
| Bound items with a magic missile used (at least once a game) |  | 57% (4 of 7); 3.7 uses a game | 50% (1 of 2); 0.7 uses a game | 56% (5 of 9); 2.2 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0% (0 of 3); 0.0 uses a game | 0.0 uses a game | 0% (0 of 3); 0.0 uses a game |
|   their share of the points of units over 100 pts | lower | 53% (2965 of 5614) | 81% (4592 of 5644) | 67% (7557 of 11258) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 5.7 (27%) | 0.3 (8%) | 6.0 (24%) |
| MARCHED: its unit marched | 6.0 (29%) | 0.7 (15%) | 6.7 (26%) |
| CHARGED: its unit charged | 1.3 (6%) | 0.0 (0%) | 1.3 (5%) |
| IN COMBAT: engaged in combat | 7.3 (35%) | 0.0 (0%) | 7.3 (29%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.7 (15%) | 0.7 (3%) |
| FLEEING: fleeing | 0.7 (3%) | 0.7 (15%) | 1.3 (5%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (0%) | 1.3 (31%) | 1.3 (5%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.7 (15%) | 0.7 (3%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 1.7 | 5.7 | 0.7 | 4.7 | 1.0 | 4.3 |
| not cast | 2.3 | 10.3 | 5.3 | 25.3 | 3.0 | 23.7 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.0 (8%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 6.0 (58%) | 0.0 (0%) | 6.0 (24%) | 0.0 (0%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 6.7 (26%) | 1.3 (44%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.3 (5%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.3 (3%) | 0.0 (0%) | 7.3 (29%) | 1.0 (33%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 1.3 (13%) | 1.3 (25%) | 0.7 (3%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.7 (29%) | 0.7 (6%) | 0.7 (12%) | 1.3 (5%) | 0.0 (0%) | 3.3 (14%) |
| OFF THE TABLE: off the table or not arrived | 1.3 (57%) | 0.7 (6%) | 1.3 (25%) | 1.3 (5%) | 0.0 (0%) | 2.7 (11%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.3 (3%) | 0.0 (0%) | 0.0 (0%) | 0.7 (22%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (3%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 0.3 (14%) | 1.0 (10%) | 2.0 (38%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 15.7 (66%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.0 a game | 0.7 a game | 0.3 a game |
| stood (cast and not dispelled) | - | 100% (2 of 2) | 100% (2 of 2) |
| the unit moved after it | - | 0% (0 of 2) | 0% (0 of 2) |
| it charged on its next turn | - | 0% (0 of 2) | 0% (0 of 2) |
| the enemy charged it first | - | 0% (0 of 2) | 0% (0 of 2) |
| it fought by the end of its next turn | - | 0% (0 of 2) | 0% (0 of 2) |
| it moved out of a charge the enemy had planned (not charged first) | - | 0% (0 of 2) | 0% (0 of 2) |
| none of these (no charge, no fight, no charge escaped) | - | 100% (2 of 2) | 100% (2 of 2) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 77% (46 of 60) | 57% (39 of 68) | 66% (85 of 128) |
|   cavalry | - | 62% (10 of 16) | 62% (10 of 16) |
|   character | - | 90% (9 of 10) | 90% (9 of 10) |
|   chariot | 58% (7 of 12) | 83% (5 of 6) | 67% (12 of 18) |
|   infantry | 83% (10 of 12) | 36% (10 of 28) | 50% (20 of 40) |
|   monster | - | 62% (5 of 8) | 62% (5 of 8) |
|   war machine | 81% (29 of 36) | - | 81% (29 of 36) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.7 (36%) | 3.7 (38%) | 5.3 (37%) |
| CHARGED: it charged | 0.7 (14%) | 0.7 (7%) | 1.3 (9%) |
| FLEEING: it fled or was fleeing | 0.0 (0%) | 0.7 (7%) | 0.7 (5%) |
| NO TARGET IN RANGE | 0.0 (0%) | 3.3 (34%) | 3.3 (23%) |
| ONLY IN COMBAT: the only targets were in combat | 0.0 (0%) | 0.7 (7%) | 0.7 (5%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.0 (0%) | 0.3 (3%) | 0.3 (2%) |
| SHELTERED: the target was sheltered | 2.0 (43%) | 0.0 (0%) | 2.0 (14%) |
| OTHER BAR | 0.3 (7%) | 0.3 (3%) | 0.7 (5%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 5.0 | 0.3 | 93% | 1.4 pts | 7 pts |
| character | 3.0 | 1.0 | 67% | 14.5 pts | 43 pts |
| chariot | 4.0 | 1.7 | 67% | 14.6 pts | 59 pts |
| infantry | 9.3 | 1.0 | 89% | 3.5 pts | 32 pts |
| monster | 1.7 | 1.0 | 60% | 12.9 pts | 21 pts |
| war machine | 10.3 | 13.3 | 32% | 27.4 pts | 283 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 6.0 | 3.3 | 4.7 |
| Charges that made contact a game | 4.7 | 2.3 | 3.5 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 2.17 declared, 1.83 contact (6 units) | - | 2.17 declared, 1.83 contact (6 units) |
|   per unit a game, units carrying another wizard (or one alone) | 1.00 declared, 1.00 contact (1 units) | - | 1.00 declared, 1.00 contact (1 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.44 declared, 0.22 contact (9 units) | 0.40 declared, 0.28 contact (25 units) | 0.41 declared, 0.26 contact (34 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 83% (5 of 6) | - | 50% (2 of 4) | 70% (7 of 10) |
| Character in a unit | 67% (2 of 3) | 50% (1 of 2) | 100% (1 of 1) | 67% (4 of 6) |
| Character on its own | - | 62% (5 of 8) | 50% (2 of 4) | 58% (7 of 12) |
| Chariot | 75% (3 of 4) | - | - | 75% (3 of 4) |
| Infantry | 88% (7 of 8) | - | - | 88% (7 of 8) |
| Monster | - | 100% (1 of 1) | - | 100% (1 of 1) |
| Monstrous | 100% (2 of 2) | 50% (1 of 2) | - | 75% (3 of 4) |
| War Machines | 67% (4 of 6) | - | - | 67% (4 of 6) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Grand Cathay | 3 | 73% (8 of 11); on the table 82% | 12% (9 of 72) | 53% | 56% (14 of 25) | 57% (4 of 7); 3.7 uses a game | 0.0 uses a game | 0% (0 of 3); 0.0 uses a game |
| Ogre Kingdoms | 1 | - | 0% (0 of 6) | 40% | 86% (6 of 7) | 100% (1 of 1); 2.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 1 | 33% (1 of 3); on the table 33% | 50% (3 of 6) | 8% | 57% (4 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 1 | - | 33% (2 of 6) | 24% | 100% (12 of 12) | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (cora-bb45c30-p43, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 60% (3) | 43% (3) | 50% (6) |
| ...free all their last turn and able to turn (per game) | 0.67 | 0.67 | 1.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.33 | 0.33 |
| ...with the charger already in that arc before they moved (per game) | 0.33 | 0.67 | 1.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: cora-bb45c30-p43

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.7 | 1.0 |
| Strategy | Charge objectives carried out (made contact) | 78% (14 of 18) | 50% (3 of 6) |
| Strategy | Shoot objectives carried out (shot that target) | 36% (20 of 56) | 39% (7 of 18) |
| Strategy | Support requests answered (helper made contact too) | 100% (2 of 2) | 50% (1 of 2) |
| Strategy | Hexes on a unit its side charged or shot that turn | 88% (7 of 8) | - |
| Strategy | Joined characters whose unit fought | 25% (1 of 4) | 100% (4 of 4) |
| Strategy | Lone characters that fought | 88% (7 of 8) | 75% (3 of 4) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 1.0 | 1.0 |
| Movement | Points that never moved of their own | 330.0 | 163.3 |
| Movement | Fights charged into per game | 4.0 | 1.7 |
| Movement | Charges with odds: long shots (under 50%) | 3 of 12, net -145 | 0 of 3 |
| Movement | Charges with odds: sweet spot (55-75%) | 1 of 12, net +0 | 0 of 3 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 3 of 12, net +45 | 0 of 3 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 5 of 12, net +60 | 3 of 3, net -369 |
| Shooting | Shots by shooting units (incl. breath weapons) | 5.7 | 13.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 18% (3 of 17) | 50% (20 of 40) |
| Shooting | Points destroyed by shooting units | 80.0 | 0.0 |
| Shooting | War machine shots | 9.7 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 28% (8 of 29) | - |
| Shooting | Points destroyed by war machines | 139.7 | 0.0 |
| Magic | Magic missiles cast | 1.7 | 1.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 20% (1 of 5) | 50% (2 of 4) |
| Magic | Wounds caused by magic missiles | 3.0 | 0.3 |
| Magic | Wounds caused by other spells | 6.7 | - |
| Magic | Points destroyed by magic (all spells) | 244.3 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.0 / 2.7 / 2.0 / 0.7 | 0.7 / 0.0 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 137.3 | 0.0 |
| Combat | Points run down | 148.7 | 0.0 |
| Combat | Net points per charged fight, damage counted | +28 | -228 |
| Combat | Net per 100 charger points, damage counted | +7.9 | -73.5 |
| Combat | First round won (charged fights) | 83% | 20% |
| Combat | Net points per charged fight | +0 | -228 |
| Combat | Net points per supported fight / lone fight | +0 / +0 | -553 / -11 |
| Combat | Charged fights on a top-3 enemy unit | 5 of 12 | 5 of 5 |
| Game | Points lost | 111.3 | 1027.0 |
| Game | VP from objectives | 820.0 | 246.7 |
| Game | Lone holders (player turns) | 0.0 | 0.5 |

- Mine won / drew / lost: 2 / 1 / 0 of 3 ended games (of 3); mean margin (Mine - Opponent) +1623 VP
- The side that went first won 2 of 2 games with a winner
- Points traded per game (both sides' losses): 1138
- Games not ended: 0; findings 1, warnings 0

### Opponent rules: cora-bb45c30-p43

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | - | - | - | - | 0.3 | +184.4 | 0.0 | 0.0 |
| ARMY TABLE | 6.3 | +35.6 | 0.0 | 0.0 | 29.0 | +163.5 | 0.0 | 650.3 |
| ARRIVAL HUNT | - | - | - | - | 0.3 | +31.3 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 3.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ASSAILMENT BY POINTS | 0.7 | +2.6 | 0.0 | 289.3 | - | - | - | - |
| BACKUP TARGETS | 0.3 | +1.1 | 0.0 | 0.0 | 1.0 | +1.6 | 0.0 | 61.7 |
| BEST PRIZE | 0.3 | -13.7 | 0.0 | 0.0 | - | - | - | - |
| BOMBING RUN | 0.7 | +21.7 | 78.0 | 0.0 | - | - | - | - |
| CANNON PLAN MISSED | 0.7 | +0.0 | 78.0 | 0.0 | - | - | - | - |
| CANNON PLANNED TARGET | 9.3 | +134.1 | 499.0 | 0.0 | - | - | - | - |
| CANNON SIGHT KEPT | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CAST JOB | 3.0 | +108.7 | 0.0 | 0.0 | 1.3 | +6.1 | 0.0 | 0.0 |
| CASTER AWAY FROM SCREEN | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 3.7 | +50.1 | 251.0 | 0.0 | 0.7 | +6.3 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | - | - | - | - | 0.7 | +0.0 | 0.0 | 91.3 |
| CHAFF IN THE MOVE | - | - | - | - | 2.0 | +150.5 | 0.0 | 11.3 |
| CHALLENGE BY POINTS | 0.7 | +19.1 | 0.0 | 144.7 | 0.3 | +41.9 | 0.0 | 0.0 |
| CHAMPION KNOWS CHALLENGE | - | - | - | - | 0.7 | +4.2 | 0.0 | 99.0 |
| CHARGE LOSSES | 12.0 | -240.6 | 0.0 | 0.0 | 21.3 | -1367.5 | 0.0 | 1097.0 |
| CHARGE NOW FIRST | 3.0 | +0.0 | 346.0 | 0.0 | 1.0 | +0.0 | 0.0 | 298.7 |
| CLOSES ON WHAT IT BEATS | 6.7 | +0.0 | 0.0 | 0.0 | 6.3 | +0.0 | 0.0 | 11.3 |
| CONVEYANCE SEARCH | - | - | - | - | 0.7 | +46.3 | 0.0 | 91.3 |
| COVER ONCE | 5.7 | -303.5 | 0.0 | 0.0 | 8.0 | -928.4 | 0.0 | 190.3 |
| DENIED BY THE FIGHT | 1.0 | -10.5 | 161.0 | 0.0 | - | - | - | - |
| DEPLOY BY FIGURES | 6.0 | -45.0 | 0.0 | 0.0 | 8.3 | -61.2 | 0.0 | 0.0 |
| EDGE GIVE GROUND | 1.0 | +105.4 | 152.0 | 0.0 | 0.3 | +17.0 | 0.0 | 34.0 |
| EVASIVE BY THE ODDS | - | - | - | - | 1.0 | +66.4 | 0.0 | 42.0 |
| EXACT ROUND | 3.3 | +22.1 | 380.7 | 0.0 | 1.0 | +10.7 | 0.0 | 233.7 |
| FALL BACK GOOD ORDER | 4.3 | +49.9 | 369.3 | 144.7 | 2.0 | +0.0 | 144.7 | 332.7 |
| FALLS SHORT | - | - | - | - | 24.7 | +285.5 | 0.0 | 502.3 |
| FEATURE BUFFS | 1.3 | +2.5 | 0.0 | 0.0 | - | - | - | - |
| FIGHT LIFT | - | - | - | - | 0.7 | +15.0 | 144.7 | 0.0 |
| FIGHT TO THE END | 1.7 | +21.9 | 114.3 | 0.0 | 1.0 | +1.9 | 0.0 | 233.7 |
| FIRE AND FLEE | - | - | - | - | 0.3 | +2.8 | 0.0 | 38.0 |
| FIVE ACTION | 85.3 | +7164.4 | 3005.0 | 434.0 | 73.7 | +4431.4 | 144.7 | 1866.0 |
| FLANK NOT WEIGHED | 2.7 | +0.0 | 0.0 | 0.0 | 5.7 | +0.0 | 0.0 | 159.0 |
| FOLLOW UP WEIGHED | 0.7 | +258.0 | 0.0 | 0.0 | - | - | - | - |
| FOUR ROUNDS | 6.0 | +1276.1 | 441.0 | 144.7 | 2.0 | +414.2 | 144.7 | 332.7 |
| FREED FROM HIS FIGHT | 0.7 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 83.7 |
| FRIEND SHOOTS FIRST | 2.0 | -19.9 | 0.0 | 0.0 | - | - | - | - |
| GIVES UP | 1.0 | -4.3 | 0.0 | 0.0 | - | - | - | - |
| GOAL WALK | 2.0 | +159.7 | 0.0 | 0.0 | 10.0 | +896.0 | 0.0 | 0.0 |
| GUN MASK | 2.0 | +160.5 | 0.0 | 0.0 | - | - | - | - |
| HARD STAY DROPPED | 1.3 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 156.3 |
| HE REFORMS ONCE FREED | 0.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 8.0 | +0.0 | 0.0 | 0.0 | 10.0 | +0.0 | 0.0 | 303.7 |
| HIS CHARGE DENIED | 0.7 | +21.6 | 95.0 | 0.0 | - | - | - | - |
| HIS CHARGE LIST | 3.0 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 3.7 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 555.3 |
| HIS MOVE AND SHOT | 3.7 | -20.6 | 0.0 | 0.0 | 12.0 | -124.8 | 0.0 | 846.3 |
| HIS ONE QUARTER | 1.7 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 6.3 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 555.3 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 27.7 | +690.9 | 0.0 | 289.3 | 50.0 | +3416.1 | 0.0 | 1374.0 |
| HIS SHOTS BY HIS RUN | 31.3 | +631.8 | 0.0 | 289.3 | 48.0 | +1129.0 | 0.0 | 1334.3 |
| HIS TURN DENIED | 1.7 | +68.7 | 199.0 | 0.0 | - | - | - | - |
| HIS TURN RUN | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 13.7 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 0.0 |
| HOLDER ASSIGNMENT | 10.3 | +1084.6 | 0.0 | 0.0 | 4.0 | +488.3 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 5.3 | -162.9 | 441.0 | 144.7 | 1.3 | -28.7 | 0.0 | 332.7 |
| HUNT IN PAIRS | 0.7 | +40.8 | 0.0 | 0.0 | - | - | - | - |
| IDLE COST | - | - | - | - | 14.0 | -223.9 | 0.0 | 461.7 |
| JOINT CHARGE NOW | 1.3 | -73.5 | 0.0 | 0.0 | 1.3 | +199.2 | 0.0 | 233.7 |
| JOINT KNOWS CHALLENGE | - | - | - | - | 0.3 | -8.3 | 0.0 | 0.0 |
| KEPT FROM ITS LAST STOP | 4.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 1.3 | +33.7 | 0.0 | 0.0 | 0.3 | +15.7 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 4.0 | +0.0 | 280.7 | 0.0 | 3.7 | +0.0 | 0.0 | 93.3 |
| LONE WIZARD KEPT IN | 0.7 | +52.8 | 0.0 | 0.0 | - | - | - | - |
| LONG SHOT | - | - | - | - | 1.0 | -8.7 | 0.0 | 99.0 |
| LOST AFTER ESCAPE | 3.7 | -7.2 | 211.7 | 144.7 | 0.3 | -0.2 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | - | - | - | - | 0.3 | +10.5 | 0.0 | 42.0 |
| MANOEUVRE | 1.3 | +0.0 | 0.0 | 0.0 | 1.3 | +7.6 | 0.0 | 0.0 |
| MARCH BY THE SUM | 0.7 | +82.2 | 0.0 | 0.0 | 0.3 | +11.5 | 0.0 | 0.0 |
| MARCH CHECK | 1.3 | +38.5 | 0.0 | 0.0 | - | - | - | - |
| MARCH OF THE TABLE | 1.7 | +170.3 | 0.0 | 0.0 | 0.3 | +11.2 | 0.0 | 0.0 |
| MARCH OVER CASTS | 2.0 | +58.4 | 0.0 | 0.0 | 0.7 | -22.3 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 3.3 | +71.4 | 0.0 | 0.0 | 2.7 | +75.4 | 0.0 | 61.7 |
| MEETS IN TIME | 1.7 | +155.5 | 0.0 | 0.0 | 4.0 | +307.2 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 6.0 | +120.2 | 0.0 | 144.7 | 2.7 | +24.1 | 0.0 | 52.7 |
| MISSILES NEXT TURN | 12.7 | +188.0 | 0.0 | 144.7 | 3.0 | +16.1 | 0.0 | 52.7 |
| MOVE ORDER | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| MOVE SPELL OUT OF RANGE | - | - | - | - | 0.3 | -2.2 | 78.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 4.0 | +417.9 | 0.0 | 0.0 | 1.7 | +133.0 | 0.0 | 34.0 |
| NEARER NOT NEEDED | 6.0 | +257.6 | 0.0 | 0.0 | 4.7 | +234.5 | 0.0 | 52.7 |
| NEXT CHARGE BY LIST | 4.3 | +431.1 | 0.0 | 0.0 | 1.3 | +106.7 | 0.0 | 0.0 |
| NEXT OBJECTIVE NEARER | 0.3 | -10.0 | 0.0 | 0.0 | 0.3 | -33.3 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 4.3 | -179.3 | 441.0 | 0.0 | 2.0 | -315.2 | 144.7 | 332.7 |
| NO LATE CUT | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 0.3 | -0.1 | 0.0 | 0.0 | 1.0 | -1.8 | 0.0 | 0.0 |
| OFF BEST | 3.3 | -58.8 | 0.0 | 0.0 | 2.7 | -128.4 | 0.0 | 0.0 |
| OGRE LOADER SECOND SHOT | 4.7 | +29.1 | 0.0 | 0.0 | - | - | - | - |
| ONE FIGHT FORMULA | 4.3 | -89.0 | 0.0 | 0.0 | 4.0 | -93.2 | 0.0 | 145.3 |
| ONE OBJECTIVE FORMULA | 3.3 | +11.0 | 0.0 | 0.0 | 0.7 | -10.1 | 0.0 | 0.0 |
| ONE PROMISE A TARGET | 0.7 | -10.9 | 0.0 | 0.0 | - | - | - | - |
| ONE ROUTE | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| OPENS UP | 0.3 | +8.2 | 0.0 | 0.0 | - | - | - | - |
| OVERRUNS AWAY | 1.0 | +16.4 | 144.0 | 0.0 | 0.7 | +2.6 | 0.0 | 133.0 |
| PATHS CROSS | - | - | - | - | 0.3 | +25.8 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.3 | -18.4 | 0.0 | 0.0 | - | - | - | - |
| PLAN RESULT | 37.7 | +1573.1 | 1002.7 | 289.3 | 36.0 | +198.9 | 144.7 | 1696.7 |
| PROMISE BELOW ZERO | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE BY ITS OWN SUM | 3.0 | +0.0 | 0.0 | 0.0 | 4.3 | -96.3 | 0.0 | 0.0 |
| PROMISE IN STEPS | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE KNOWS THE FIGHT | 0.3 | -1.7 | 0.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | 17.7 | +2135.6 | 228.0 | 0.0 | 8.0 | +1204.3 | 0.0 | 0.0 |
| REAL GROUND | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| REDIRECT BY WHAT IT STOPS | - | - | - | - | 0.7 | +6.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | - | - | - | - | 3.3 | +376.4 | 0.0 | 0.0 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 2.3 | +0.0 | 0.0 | 47.7 |
| REDIRECT WEIGHED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| REFORMS TO MEET IT | 1.3 | -3.0 | 0.0 | 0.0 | 0.7 | -61.2 | 0.0 | 34.0 |
| REFUSING RETIRES | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | 0.7 | +37.1 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | 5.7 | +153.3 | 429.7 | 144.7 | 2.0 | -74.0 | 144.7 | 332.7 |
| RISK ON THE WAY | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| ROUNDS AFTER TERROR | 0.3 | -7.8 | 13.7 | 0.0 | 0.3 | -16.0 | 0.0 | 199.7 |
| RUN DOWN | 4.3 | -25.6 | 360.3 | 144.7 | 2.0 | -47.0 | 144.7 | 332.7 |
| SCOUT SPOT | - | - | - | - | 0.7 | +2.9 | 0.0 | 0.0 |
| SCOUT WAITS | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 1.3 | +110.7 | 0.0 | 11.3 |
| SEARCH SPOT | 0.7 | +83.4 | 0.0 | 0.0 | 1.3 | +4.3 | 0.0 | 103.7 |
| SET CREDITED ONCE | 1.0 | -115.3 | 0.0 | 144.7 | 2.3 | -91.3 | 0.0 | 34.0 |
| SET UP BY THE SET | 1.0 | +19.7 | 0.0 | 144.7 | 5.0 | +69.8 | 0.0 | 233.7 |
| SET UP TOGETHER | - | - | - | - | 0.3 | +10.5 | 0.0 | 42.0 |
| SHOOTERS IN TWO RANKS | - | - | - | - | 0.3 | +0.3 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 18.0 | +0.0 | 0.0 | 0.0 | 7.0 | +0.0 | 0.0 | 103.7 |
| SHOOTS FROM THE BEST SPOT | 4.7 | +386.5 | 0.0 | 0.0 | 2.0 | +9.5 | 0.0 | 0.0 |
| SHOT OR CHARGE | 2.0 | -192.4 | 168.0 | 144.7 | - | - | - | - |
| SHOT RISK POINTS | 12.7 | -114.6 | 0.0 | 0.0 | 33.0 | +659.4 | 0.0 | 1188.0 |
| SHOTS AFTER THE MOVES | 5.3 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 16.0 | +694.0 | 0.0 | 0.0 | 12.0 | +512.4 | 0.0 | 584.3 |
| SPELL WORTH | 1.0 | +23.9 | 289.3 | 289.3 | 1.7 | +37.9 | 236.0 | 91.3 |
| SPELLS IN THE FIGHT | 0.7 | +3.5 | 114.3 | 0.0 | 0.3 | -17.3 | 0.0 | 0.0 |
| SPOT AS THE GAME MOVES | 3.3 | +0.0 | 0.0 | 144.7 | 5.3 | +0.0 | 0.0 | 22.7 |
| STAND AND SHOOT | 1.0 | -6.8 | 189.0 | 0.0 | - | - | - | - |
| STANDS FOR A REASON | - | - | - | - | 7.0 | +0.0 | 0.0 | 650.0 |
| STANDS STILL | 51.7 | +0.0 | 2564.0 | 144.7 | 26.3 | +0.0 | 0.0 | 412.7 |
| STANDS TO CAST | - | - | - | - | 0.3 | +42.9 | 0.0 | 0.0 |
| STAY WORTH | 36.3 | +135.0 | 2267.7 | 0.0 | 14.7 | +197.2 | 0.0 | 443.0 |
| STRIKE BY THE ODDS | 1.7 | +36.9 | 34.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | - | - | - | - | 11.0 | +1352.8 | 0.0 | 271.7 |
| SUPPORT WORKED OUT | - | - | - | - | 11.0 | +1352.8 | 0.0 | 271.7 |
| SURE REACH TOGETHER | 0.3 | +8.0 | 0.0 | 0.0 | - | - | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 1.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 1.0 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 55.7 |
| THE ROW KEEPS ITS WAY | 1.7 | +0.0 | 0.0 | 0.0 | 5.7 | +0.0 | 0.0 | 146.0 |
| THE STEP BACK IS MADE | 0.7 | +0.0 | 0.0 | 0.0 | 5.3 | +0.0 | 0.0 | 146.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 37.3 | +0.0 | 0.0 | 144.7 | 34.3 | +0.0 | 0.0 | 749.7 |
| TIED UP BY THE SUM | 2.3 | +227.9 | 179.0 | 0.0 | - | - | - | - |
| TIME ON OUR SIDE | 29.7 | +469.3 | 0.0 | 434.0 | - | - | - | - |
| TWO OR MORE ARRIVE | - | - | - | - | 0.3 | +0.2 | 0.0 | 42.0 |
| WAR ENGINE JOBS | 1.7 | +0.0 | 243.3 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| WHO GETS IN | 0.7 | +100.8 | 0.0 | 0.0 | 0.7 | -3.9 | 0.0 | 233.7 |
| WHO HITS BACK | - | - | - | - | 0.3 | +81.2 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | 0.3 | -10.6 | 0.0 | 0.0 | 5.7 | -691.1 | 0.0 | 186.0 |
| WOUNDED STAYS OUT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| WOUNDS ON THE RANKS | 1.3 | +37.1 | 0.0 | 0.0 | 3.7 | +38.9 | 0.0 | 0.0 |

### Rule changes: cora-bb45c30-p43

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 106 | 106 | 78 | 26.00 | +509 | +6.5 |
| HIS SHOT LIST | 233 | 226 | 67 | 22.33 | +2929 | +43.7 |
| HIS SHOTS BY HIS RUN | 238 | 231 | 47 | 15.67 | +759 | +16.2 |
| HOLDER ASSIGNMENT | 43 | 43 | 37 | 12.33 | +1800 | +48.6 |
| THE TABLE AGAIN | 36 | 36 | 25 | 8.33 | +0 | +0.0 |
| FIVE ACTION | 477 | 470 | 24 | 8.00 | +1756 | +73.2 |
| LEGAL CHARGES ONLY | 23 | 23 | 23 | 7.67 | +0 | +0.0 |
| DEPLOY BY FIGURES | 43 | 43 | 22 | 7.33 | +408 | +18.6 |
| SHOT RISK POINTS | 137 | 135 | 19 | 6.33 | +1495 | +78.7 |
| OFF BEST | 18 | 18 | 18 | 6.00 | -561 | -31.2 |
| FOUR ROUNDS | 24 | 24 | 14 | 4.67 | +2264 | +161.7 |
| HARD STAY DROPPED | 14 | 14 | 14 | 4.67 | +0 | +0.0 |
| OGRE LOADER SECOND SHOT | 14 | 14 | 14 | 4.67 | +87 | +6.2 |
| MOVE TO CHARGE COMPUTED | 17 | 17 | 13 | 4.33 | +999 | +76.8 |
| NEXT CHARGE BY LIST | 17 | 17 | 13 | 4.33 | +999 | +76.8 |
| CAST JOB | 13 | 13 | 12 | 4.00 | +147 | +12.3 |
| CHARGE LOSSES | 100 | 94 | 12 | 4.00 | +1389 | +115.8 |
| SHOOTS FROM THE BEST SPOT | 20 | 20 | 12 | 4.00 | +390 | +32.5 |
| ARTILLERY RE-ROLL WEIGHED | 11 | 11 | 11 | 3.67 | +0 | +0.0 |
| GOAL WALK | 36 | 33 | 10 | 3.33 | +364 | +36.4 |
| MEETS IN TIME | 17 | 17 | 10 | 3.33 | +481 | +48.1 |
| TIME ON OUR SIDE | 89 | 79 | 10 | 3.33 | +52 | +5.2 |
| CASTING BLOCK | 13 | 13 | 9 | 3.00 | +56 | +6.2 |
| SET UP BY THE SET | 18 | 18 | 9 | 3.00 | +298 | +33.1 |
| COVER ONCE | 41 | 31 | 8 | 2.67 | +342 | +42.8 |
| JOINT CHARGE NOW | 8 | 8 | 8 | 2.67 | +377 | +47.1 |
| QUARTER ODDS | 77 | 77 | 7 | 2.33 | +555 | +79.3 |
| REDIRECT FOR A FRIEND IN REACH | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| SHOTS AFTER THE MOVES | 25 | 25 | 7 | 2.33 | +0 | +0.0 |
| ADVANCE LANE KEPT | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| MARCH OF THE TABLE | 6 | 6 | 6 | 2.00 | -544 | -90.7 |
| MAX FOR POSITIONING | 18 | 18 | 6 | 2.00 | +33 | +5.6 |
| RISK BY ARC | 23 | 23 | 6 | 2.00 | +324 | +54.0 |
| STAY WORTH | 153 | 145 | 6 | 2.00 | +25 | +4.2 |
| STRIKE BY THE ODDS | 6 | 6 | 6 | 2.00 | +111 | +18.5 |
| SUPPORT ADDS | 33 | 33 | 6 | 2.00 | +184 | +30.7 |
| SUPPORT WORKED OUT | 33 | 33 | 6 | 2.00 | +184 | +30.7 |
| TIED UP BY THE SUM | 7 | 7 | 6 | 2.00 | +124 | +20.6 |
| CANNON SIGHT KEPT | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| IDLE COST | 42 | 27 | 5 | 1.67 | +49 | +9.7 |
| LANE BY FIGURES | 5 | 5 | 5 | 1.67 | +148 | +29.7 |
| SEARCH SPOT | 6 | 6 | 5 | 1.67 | +263 | +52.6 |
| SHOTS IN THE MOVE | 84 | 68 | 5 | 1.67 | +188 | +37.5 |
| HOLDS AMBUSHERS | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| WHO GETS IN | 4 | 4 | 4 | 1.33 | +290 | +72.6 |
| CHALLENGE BY POINTS | 3 | 3 | 3 | 1.00 | +183 | +61.0 |
| CHARGE NOW FIRST | 12 | 12 | 3 | 1.00 | -125 | -41.7 |
| EDGE GIVE GROUND | 4 | 4 | 3 | 1.00 | +169 | +56.3 |
| MARCH BY THE SUM | 3 | 3 | 3 | 1.00 | +281 | +93.6 |
| MISSILES IN THE MOVE | 26 | 19 | 3 | 1.00 | +77 | +25.8 |
| MOVE ORDER | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| REDIRECT COUNTER | 10 | 10 | 3 | 1.00 | +140 | +46.8 |
| SCOUT WAITS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| SCREEN BY WHAT IT SAVES | 4 | 4 | 3 | 1.00 | +8 | +2.5 |
| THE ROW IN ITS ORDER | 15 | 3 | 3 | 1.00 | +0 | +0.0 |
| ASSAILMENT BY POINTS | 2 | 2 | 2 | 0.67 | +8 | +3.9 |
| BOMBING RUN | 2 | 2 | 2 | 0.67 | +65 | +32.6 |
| CANNON PLANNED TARGET | 28 | 28 | 2 | 0.67 | -49 | -24.7 |
| EXACT ROUND | 13 | 13 | 2 | 0.67 | +30 | +15.2 |
| FOLLOW UP WEIGHED | 2 | 2 | 2 | 0.67 | +774 | +387.0 |
| HIS MOVE AND SHOT | 47 | 46 | 2 | 0.67 | +2 | +0.8 |
| LONE WIZARD KEPT IN | 2 | 2 | 2 | 0.67 | +158 | +79.2 |
| MANOEUVRE | 8 | 8 | 2 | 0.67 | +23 | +11.3 |
| MARCH CHECK | 4 | 4 | 2 | 0.67 | +65 | +32.3 |
| MISSILES NEXT TURN | 47 | 33 | 2 | 0.67 | +6 | +2.8 |
| ONE PROMISE A TARGET | 2 | 2 | 2 | 0.67 | -33 | -16.4 |
| PROMISE BY ITS OWN SUM | 22 | 22 | 2 | 0.67 | -289 | -144.5 |
| RESERVE FALL BACK | 2 | 2 | 2 | 0.67 | +111 | +55.6 |
| WOUNDS ON THE RANKS | 15 | 14 | 2 | 0.67 | +35 | +17.4 |
| AFTERMATH IN POINTS | 1 | 1 | 1 | 0.33 | +553 | +553.3 |
| BEST PRIZE | 1 | 1 | 1 | 0.33 | -41 | -41.0 |
| CASTER AWAY FROM SCREEN | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FALL BACK GOOD ORDER | 19 | 19 | 1 | 0.33 | +0 | +0.0 |
| FALLS SHORT | 74 | 60 | 1 | 0.33 | +0 | +0.0 |
| FIRE AND FLEE | 1 | 1 | 1 | 0.33 | +8 | +8.3 |
| HUNT IN PAIRS | 2 | 1 | 1 | 0.33 | +64 | +63.9 |
| NEARER NOT NEEDED | 32 | 31 | 1 | 0.33 | +50 | +50.3 |
| ONE OBJECTIVE FORMULA | 12 | 9 | 1 | 0.33 | +43 | +43.2 |
| OPENS UP | 1 | 1 | 1 | 0.33 | +20 | +19.9 |
| PATHS CROSS | 1 | 1 | 1 | 0.33 | +77 | +77.3 |
| PIVOT GUARDS FLANK | 1 | 1 | 1 | 0.33 | -55 | -55.1 |
| PROMISE KNOWS THE FIGHT | 1 | 1 | 1 | 0.33 | -5 | -5.0 |
| REDIRECT WEIGHED | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| REFUSING RETIRES | 3 | 3 | 1 | 0.33 | -16 | -15.8 |
| SHOOTERS IN TWO RANKS | 1 | 1 | 1 | 0.33 | +1 | +1.0 |
| STANDS TO CAST | 1 | 1 | 1 | 0.33 | -57 | -57.5 |
| SURE REACH TOGETHER | 1 | 1 | 1 | 0.33 | +9 | +9.1 |
| WHO HITS BACK | 1 | 1 | 1 | 0.33 | +19 | +19.0 |
| WHOLE FIGHT DANGER | 18 | 14 | 1 | 0.33 | +67 | +66.8 |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| BACKUP TARGETS | 4 | 3 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 2 | 2 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 2 | trace | - | - | - | - |
| CHAFF IN THE MOVE | 6 | 6 | 0 | 0.00 | - | - |
| CHAMPION KNOWS CHALLENGE | 2 | 2 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 39 | 39 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 2 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 3 | 3 | 0 | 0.00 | - | - |
| EVASIVE BY THE ODDS | 3 | 3 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT LIFT | 2 | not checked | - | - | - | - |
| FIGHT TO THE END | 8 | 8 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 25 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 10 | 10 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 6 | 6 | 0 | 0.00 | - | - |
| GIVES UP | 3 | 3 | 0 | 0.00 | - | - |
| GUN MASK | 6 | 6 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 4 | 4 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 54 | 49 | 0 | 0.00 | - | - |
| HIS CHARGE DENIED | 2 | 2 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 21 | 20 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 24 | 23 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 15 | 15 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 32 | 31 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 5 | 5 | 0 | 0.00 | - | - |
| HIS TURN RUN | 18 | 18 | 0 | 0.00 | - | - |
| HOLD ODDS | 53 | 53 | 0 | 0.00 | - | - |
| HONEST WORTH | 20 | 20 | 0 | 0.00 | - | - |
| JOINT KNOWS CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 15 | 15 | 0 | 0.00 | - | - |
| LONG SHOT | 3 | 3 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 12 | 12 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 1 | not checked | - | - | - | - |
| MARCH OVER CASTS | 8 | 8 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 4 | 4 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 1 | trace | - | - | - | - |
| NEXT OBJECTIVE NEARER | 2 | 2 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 19 | 19 | 0 | 0.00 | - | - |
| NO LATE CUT | 5 | 5 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 4 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 25 | 15 | 0 | 0.00 | - | - |
| ONE ROUTE | 4 | 4 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 18 | 18 | 0 | 0.00 | - | - |
| OVERRUNS AWAY | 5 | 5 | 0 | 0.00 | - | - |
| PLAN RESULT | 221 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 2 | 2 | 0 | 0.00 | - | - |
| PROMISE IN STEPS | 4 | 4 | 0 | 0.00 | - | - |
| REAL GROUND | 4 | 4 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 2 | 2 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 6 | 6 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 1 | 1 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 2 | 2 | 0 | 0.00 | - | - |
| RUN DOWN | 19 | 19 | 0 | 0.00 | - | - |
| SCOUT SPOT | 2 | 2 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 10 | 10 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 1 | 1 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 75 | not checked | - | - | - | - |
| SHOT OR CHARGE | 6 | 6 | 0 | 0.00 | - | - |
| SPELL WORTH | 8 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 3 | 3 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 26 | 22 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 3 | 3 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 21 | 20 | 0 | 0.00 | - | - |
| STANDS STILL | 234 | 232 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 9 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 22 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 18 | not checked | - | - | - | - |
| THE TABLE BINDS | 215 | not checked | - | - | - | - |
| TWO OR MORE ARRIVE | 1 | not checked | - | - | - | - |
| WAR ENGINE JOBS | 6 | 6 | 0 | 0.00 | - | - |
| WOUNDED STAYS OUT | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: cora-bb45c30-p43

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| ARMY TABLE | rule | 1.67 | 5.33 | 80.2 |
| JOB FIRST | gate | 3.33 | 2.67 | 31.2 |
| MARCH OF THE TABLE | rule | 1.67 | 0.33 | 90.7 |
| CHARGE NOW FIRST | rule | 1.00 | - | 41.7 |
| HOLDER ASSIGNMENT | rule | 0.33 | 0.33 | 82.2 |
| JOINT CHARGE NOW | rule | 0.33 | 0.33 | 330.3 |
| ONE PROMISE A TARGET | rule | 0.67 | - | 16.4 |
| PROMISE BY ITS OWN SUM | rule | - | 0.67 | 144.5 |
| BEST PRIZE | rule | 0.33 | - | 41.0 |
| CANNON PLANNED TARGET | rule | 0.33 | - | 49.4 |
| PIVOT GUARDS FLANK | rule | 0.33 | - | 55.1 |
| PROMISE KNOWS THE FIGHT | rule | 0.33 | - | 5.0 |
| REFUSING RETIRES | rule | - | 0.33 | 15.8 |
| SET UP BY THE SET | rule | - | 0.33 | 3.0 |
| STANDS TO CAST | rule | - | 0.33 | 57.5 |
| WHO GETS IN | rule | - | 0.33 | 68.2 |

### Plans: cora-bb45c30-p43

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 5.0 | 40% | 936 | 552 | 59% |
| Mine | move | 17.3 | 100% | 1311 | 0 | 0% |
| Mine | shoot | 15.3 | 54% | 886 | 1021 | 115% |
| Opponent | charge | 2.0 | 17% | 399 | 145 | 36% |
| Opponent | move | 27.7 | 84% | 1761 | 0 | 0% |
| Opponent | shoot | 5.7 | 12% | 643 | 54 | 8% |
| Opponent | support | 0.7 | 50% | 76 | 0 | 0% |

### Battle groups: cora-bb45c30-p43

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | REDIRECT COUNTER | 3.3 | 20% | 100% | 100% | 100% | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: cora-bb45c30-p43

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Character | 12 | 89 (12) | 89 | 0 | 15 | 25% | 2.7 | - | 6 (7) | 194 (5) | 22 (7) | 140 (5) |
| Mine | Fast Hammer | 4 | 16 (4) | 16 | 0 | 0 | 25% | 2.7 | 42 (2) | 5 (2) | - | 24 (3) | 0 (1) |
| Mine | Holder | 5 | 41 (5) | 0 | 41 | 0 | 60% | 3.5 | - | 51 (4) | 0 (1) | 67 (3) | 0 (2) |
| Mine | Shooter | 2 | 316 (2) | 59 | 258 | 0 | 0% | 1.0 | 118 (1) | 515 (1) | - | 316 (2) | - |
| Mine | War machine | 6 | 42 (6) | 42 | 0 | 0 | 0% | 1.3 | 0 (2) | 0 (2) | 127 (2) | 0 (1) | 51 (5) |
| Opponent | Chaff | 6 | 0 (6) | 0 | 0 | 41 | 33% | 3.5 | 0 (5) | 0 (1) | - | 0 (5) | 0 (1) |
| Opponent | Character | 7 | 22 (7) | 22 | 0 | 65 | 0% | 2.1 | 0 (1) | 30 (5) | - | 37 (5) | 0 (1) |
| Opponent | Clean-up | 3 | 0 (3) | 0 | 0 | 100 | 0% | 3.0 | - | 0 (3) | - | 0 (2) | 0 (1) |
| Opponent | Early | 1 | 0 (1) | 0 | 0 | 0 | 0% | 4.0 | - | 0 (1) | - | - | 0 (1) |
| Opponent | Fast Hammer | 4 | 11 (4) | 0 | 11 | 25 | 0% | 2.0 | - | 12 (3) | 0 (1) | 12 (3) | 0 (1) |
| Opponent | Hammer | 8 | 7 (8) | 0 | 7 | 75 | 25% | 1.8 | 0 (2) | 18 (2) | 0 (4) | 10 (5) | 0 (3) |
| Opponent | Holder | 1 | 108 (1) | 0 | 108 | 0 | 0% | 5.0 | - | 108 (1) | - | 108 (1) | - |
| Opponent | Shooter | 2 | 0 (2) | 0 | 0 | 56 | 0% | 1.0 | 0 (1) | 0 (1) | - | 0 (2) | - |
| Opponent | Wizard | 1 | 0 (1) | 0 | 0 | 0 | 0% | 4.0 | - | 0 (1) | - | 0 (1) | - |

### Charged fights: cora-bb45c30-p43

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Grand Cathay | 3 | 464 | 145 | 4.0 | 1.2 | 36 | 36 | +0 | 5 of 12 | 10 of 12 | +0 | +0 |
| Opponent | Ogre Kingdoms | 1 | 0 | 0 | 3.0 | 1.3 | 0 | 146 | -146 | 3 of 3 | 0 of 3 | -405 | -17 |
| Opponent | Warriors of Chaos | 1 | 0 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 1 of 1 | 1 of 1 | - | +0 |
| Opponent | Wood Elf Realms | 1 | 0 | 0 | 1.0 | 2.0 | 0 | 701 | -701 | 1 of 1 | 0 of 1 | -701 | - |
| **Opponent** | all armies | 3 | 0 | 0 | 1.7 | 1.4 | 0 | 228 | -228 | 5 of 5 | 1 of 5 | -553 | -11 |

### Effective charges: cora-bb45c30-p43

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Grand Cathay | 12 | 3 (net -145) | 0 | 1 (net +0) | 0 | 3 (net +45) | 5 (net +60) | 0 | 8% (1 of 12) |
| Opponent | Ogre Kingdoms | 3 | 0 | 0 | 0 | 0 | 0 | 1 (net -405) | 2 | 0% (0 of 1) |
| Opponent | Warriors of Chaos | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +0) | 0 | 0% (0 of 1) |
| Opponent | Wood Elf Realms | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net -701) | 0 | 0% (0 of 1) |

### Charged fights, damage counted: cora-bb45c30-p43

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 3 | 544 | 494 | -145 | 35 | 163 | -128 | -23.6 |
| Mine | Effective (55-75%) | 1 | 369 | 185 | +0 | 113 | 0 | +113 | +30.7 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 5 | 271 | 163 | +60 | 79 | 0 | +79 | +29.0 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 3 | 320 | 82 | +45 | 73 | 0 | +73 | +22.7 |
| Mine | All fights | 12 | 360 | 227 | +0 | 69 | 41 | +28 | +7.9 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 | 494 | 357 | -369 | 0 | 369 | -369 | -74.6 |
| Opponent | No odds | 2 | 34 | 301 | -17 | 0 | 17 | -17 | -50.0 |
| Opponent | All fights | 5 | 310 | 335 | -228 | 0 | 228 | -228 | -73.5 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| cora-bb45c30-p43 | move | 16 | 1 (6%) | 1 (6%) | 3 (19%) | 12 (75%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Clockwork Compass | Mine | L1228 |
| Elixir of Power | Mine | L1118, L1135 |
| Fistful of Laurels | Opponent | L1118 |
| Ring of Doom | Mine | L1118, L1135, L1228 |
| Ring of Jet | Mine | L1118, L1135, L1228 |

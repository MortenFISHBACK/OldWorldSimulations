# Doctrine scorecard: cora-bb45c30-p31

### Scorecard: cora-bb45c30-p31

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L1114 | 4 | 1 | Mine | no | 0 | 5 | 1 | 0 | 0 | 0 | 0 | 330 |
| L1114 | 4 | 1 | Opponent | no | 0 | 4 | 4 | 3 | 0 | 0 | 0 | 0 |
| L1131 | 3 | 1 | Mine | no | 5 | - | 3 | 0 | 0 | 0 | 0 | 97 |
| L1131 | 3 | 1 | Opponent | yes | 1 | 3 | 0 | 2 | 1 | 0 | 0 | 340 |
| L1224 | 6 | 1 | Mine | no | 13 | 1 | 6 | 0 | 1 | 0 | 0 | 330 |
| L1224 | 6 | 1 | Opponent | no | 0 | - | 0 | 3 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 0% | 6.0 | 3.0 | 3.3 | 0.0 | 0.3 | 0.0 | 0.0 | 252.3 |
| **Average** | | | Opponent | 33% | 0.3 | 3.5 | 1.3 | 2.7 | 0.3 | 0.0 | 0.0 | 113.3 |

### KPIs: cora-bb45c30-p31

Rules off - Opponent only: ONE RUN A PLAN.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 44% (7 of 16) | 0% (0 of 15) | 23% (7 of 31) |
| Winner chose to follow up after the loser gave ground |  | 75% (6 of 8); on the table 75% | 50% (1 of 2); on the table 50% | 70% (7 of 10); on the table 70% |
| Winner chose to pursue after the loser fell back in good order |  | - | 67% (2 of 3); on the table 67% | 67% (2 of 3); on the table 67% |
| Winner chose to pursue after the loser fled |  | 100% (1 of 1); on the table 100% | - | 100% (1 of 1); on the table 100% |
| Winner chose to follow up or pursue (all three) |  | 78% (7 of 9); on the table 78% | 60% (3 of 5); on the table 60% | 71% (10 of 14); on the table 71% |
| Magic missiles tried each own turn | 50%+ | 33% (22 of 66) | 17% (3 of 18) | 30% (25 of 84) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 48% (22 of 46) | 21% (3 of 14) | 42% (25 of 60) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 56% (5 of 9) | 56% (5 of 9) |
| Points that never fought | lower | 45% (2685 of 5998) | 58% (3484 of 5998) | 51% (6169 of 11996) |
|   infantry points that never fought | lower | 87% (633 of 730) | 52% (472 of 913) | 67% (1105 of 1643) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 48% (12 of 25) | 79% (22 of 28) | 64% (34 of 53) |
| Bound items with a magic missile used (at least once a game) |  | 100% (7 of 7); 7.7 uses a game | 100% (1 of 1); 1.0 uses a game | 100% (8 of 8); 4.3 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 17% (1 of 6); 0.7 uses a game | 17% (1 of 6); 0.3 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0% (0 of 3); 0.0 uses a game | 0.0 uses a game | 0% (0 of 3); 0.0 uses a game |
|   their share of the points of units over 100 pts | lower | 40% (2242 of 5614) | 78% (4524 of 5828) | 59% (6766 of 11442) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 3.0 (20%) | 1.7 (33%) | 4.7 (24%) |
| MARCHED: its unit marched | 4.3 (30%) | 2.0 (40%) | 6.3 (32%) |
| IN COMBAT: engaged in combat | 6.7 (45%) | 0.3 (7%) | 7.0 (36%) |
| GONE: slain | 0.0 (0%) | 1.0 (20%) | 1.0 (5%) |
| STUPIDITY: Stupidity | 0.7 (5%) | 0.0 (0%) | 0.7 (3%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 3.7 | 4.7 | 2.7 | 8.3 | 2.3 | 4.3 |
| not cast | 0.3 | 7.3 | 1.3 | 19.7 | 5.7 | 31.7 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (1%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 5.0 (68%) | 0.0 (0%) | 4.7 (24%) | 0.7 (12%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 6.3 (32%) | 1.3 (24%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.3 (5%) | 0.3 (25%) | 7.0 (36%) | 0.7 (12%) | 0.0 (0%) |
| GONE: slain | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.0 (5%) | 0.0 (0%) | 1.0 (3%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (0%) | 0.3 (5%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (2%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (3%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 1.7 (23%) | 0.0 (0%) | 0.0 (0%) | 3.0 (53%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 0.3 (100%) | 0.0 (0%) | 1.0 (75%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 29.7 (94%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.0 a game | 2.7 a game | 1.3 a game |
| stood (cast and not dispelled) | - | 62% (5 of 8) | 62% (5 of 8) |
| the unit moved after it | - | 40% (2 of 5) | 40% (2 of 5) |
| it charged on its next turn | - | 0% (0 of 5) | 0% (0 of 5) |
| the enemy charged it first | - | 20% (1 of 5) | 20% (1 of 5) |
| it fought by the end of its next turn | - | 20% (1 of 5) | 20% (1 of 5) |
| it moved out of a charge the enemy had planned (not charged first) | - | 0% (0 of 5) | 0% (0 of 5) |
| none of these (no charge, no fight, no charge escaped) | - | 80% (4 of 5) | 80% (4 of 5) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 88% (49 of 56) | 36% (8 of 22) | 73% (57 of 78) |
|   cavalry | - | 29% (2 of 7) | 29% (2 of 7) |
|   character | - | 0% (0 of 9) | 0% (0 of 9) |
|   chariot | 67% (6 of 9) | - | 67% (6 of 9) |
|   infantry | 91% (10 of 11) | 100% (6 of 6) | 94% (16 of 17) |
|   war machine | 92% (33 of 36) | - | 92% (33 of 36) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.0 (43%) | 1.0 (21%) | 2.0 (29%) |
| CHARGED: it charged | 0.0 (0%) | 1.0 (21%) | 1.0 (14%) |
| IN COMBAT: it fought this turn or the last | 0.3 (14%) | 0.0 (0%) | 0.3 (5%) |
| MOVED: a war machine that moved | 0.7 (29%) | 0.0 (0%) | 0.7 (10%) |
| NO TARGET IN RANGE | 0.0 (0%) | 2.7 (57%) | 2.7 (38%) |
| SHELTERED: the target was sheltered | 0.3 (14%) | 0.0 (0%) | 0.3 (5%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 1.3 | 0.0 | 100% | 0.0 pts | 0 pts |
| chariot | 2.0 | 0.3 | 83% | 5.0 pts | 10 pts |
| infantry | 10.7 | 1.0 | 91% | 4.3 pts | 46 pts |
| war machine | 11.7 | 7.7 | 69% | 18.7 pts | 218 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.3 | 2.0 | 2.7 |
| Charges that made contact a game | 3.3 | 1.7 | 2.5 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.14 declared, 1.14 contact (7 units) | 0.00 declared, 0.00 contact (3 units) | 0.80 declared, 0.80 contact (10 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | - | - |
|   per unit a game, the other units (no war machines, no joined characters) | 0.20 declared, 0.20 contact (10 units) | 0.29 declared, 0.24 contact (21 units) | 0.26 declared, 0.23 contact (31 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 82% (9 of 11) | 50% (1 of 2) | 0% (0 of 2) | 67% (10 of 15) |
| Character in a unit | 100% (1 of 1) | - | - | 100% (1 of 1) |
| Character on its own | 100% (6 of 6) | 50% (3 of 6) | 43% (3 of 7) | 63% (12 of 19) |
| Chariot | 100% (2 of 2) | - | - | 100% (2 of 2) |
| Infantry | 50% (3 of 6) | 50% (1 of 2) | - | 50% (4 of 8) |
| Monster | 50% (1 of 2) | - | - | 50% (1 of 2) |
| War Machines | 67% (4 of 6) | - | - | 67% (4 of 6) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Grand Cathay | 3 | 78% (7 of 9); on the table 78% | 33% (22 of 66) | 45% | 48% (12 of 25) | 100% (7 of 7); 7.7 uses a game | 0.0 uses a game | 0% (0 of 3); 0.0 uses a game |
| High Elf Realms | 1 | - | 0% (0 of 6) | 61% | 78% (7 of 9) | 0.0 uses a game | 17% (1 of 6); 2.0 uses a game | 0.0 uses a game |
| Vampire Counts | 1 | 33% (1 of 3); on the table 33% | 33% (2 of 6) | 57% | 86% (6 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 1 | 100% (2 of 2); on the table 100% | 17% (1 of 6) | 57% | 75% (9 of 12) | 100% (1 of 1); 3.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (cora-bb45c30-p31, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 20% (1) | 56% (5) | 43% (6) |
| ...free all their last turn and able to turn (per game) | 0.33 | 1.33 | 1.67 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 1.00 | 1.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.33 | 0.33 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: cora-bb45c30-p31

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 4.3 | 3.7 |
| Strategy | Charge objectives carried out (made contact) | 75% (6 of 8) | 75% (3 of 4) |
| Strategy | Shoot objectives carried out (shot that target) | 31% (16 of 52) | 33% (2 of 6) |
| Strategy | Hexes on a unit its side charged or shot that turn | 80% (4 of 5) | 0% (0 of 2) |
| Strategy | Joined characters whose unit fought | 0% (0 of 3) | - |
| Strategy | Lone characters that fought | 100% (9 of 9) | 36% (4 of 11) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 0.0 | 2.7 |
| Movement | Points that never moved of their own | 252.3 | 113.3 |
| Movement | Fights charged into per game | 3.3 | 1.7 |
| Movement | Charges with odds: long shots (under 50%) | 1 of 8, net +0 | 1 of 3, net +654 |
| Movement | Charges with odds: sweet spot (55-75%) | 2 of 8, net +0 | 0 of 3 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 1 of 8, net +60 | 0 of 3 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 of 8, net +240 | 2 of 3, net +75 |
| Shooting | Shots by shooting units (incl. breath weapons) | 5.3 | 3.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 38% (6 of 16) | 45% (5 of 11) |
| Shooting | Points destroyed by shooting units | 0.0 | 0.0 |
| Shooting | War machine shots | 11.0 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 55% (18 of 33) | - |
| Shooting | Points destroyed by war machines | 185.0 | 0.0 |
| Magic | Magic missiles cast | 5.7 | 0.7 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 18% (3 of 17) | 100% (2 of 2) |
| Magic | Wounds caused by magic missiles | 7.0 | - |
| Magic | Wounds caused by other spells | 3.0 | 1.7 |
| Magic | Points destroyed by magic (all spells) | 233.3 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.3 / 1.7 / 1.3 / 0.7 | 1.7 / 0.7 / 1.3 / 0.0 |
| Combat | Points destroyed in combat | 224.3 | 148.7 |
| Combat | Points run down | 83.7 | 0.0 |
| Combat | Net points per charged fight, damage counted | +83 | +148 |
| Combat | Net per 100 charger points, damage counted | +27.8 | +54.6 |
| Combat | First round won (charged fights) | 60% | 60% |
| Combat | Net points per charged fight | +105 | +132 |
| Combat | Net points per supported fight / lone fight | - / +105 | - / +132 |
| Combat | Charged fights on a top-3 enemy unit | 3 of 10 | 3 of 5 |
| Game | Points lost | 339.3 | 766.7 |
| Game | VP from objectives | 626.7 | 473.3 |
| Game | Lone holders (player turns) | 6.0 | 0.3 |

- Mine won / drew / lost: 2 / 1 / 0 of 3 ended games (of 3); mean margin (Mine - Opponent) +632 VP
- The side that went first won 0 of 2 games with a winner
- Points traded per game (both sides' losses): 1106
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: cora-bb45c30-p31

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.7 | +198.1 | 0.0 | 119.3 | 0.3 | +31.0 | 0.0 | 0.0 |
| ARMY TABLE | 12.0 | +356.3 | 0.0 | 0.0 | 24.7 | +119.7 | 0.0 | 303.0 |
| ARTILLERY RE-ROLL WEIGHED | 7.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| BACKUP TARGETS | - | - | - | - | 0.7 | +1.0 | 0.0 | 0.0 |
| CANNON PLAN MISSED | 0.3 | +0.0 | 128.3 | 0.0 | - | - | - | - |
| CANNON PLANNED TARGET | 10.7 | +288.9 | 498.3 | 0.0 | - | - | - | - |
| CANNON SIGHT KEPT | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CAST JOB | 2.7 | +99.8 | 514.7 | 0.0 | 1.3 | +2.7 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | - | - | - | - | 1.7 | +0.0 | 0.0 | 156.7 |
| CASTS FROM BEHIND | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | - | - | - | - | 2.0 | +78.8 | 0.0 | 80.0 |
| CHALLENGE BY POINTS | - | - | - | - | 1.0 | +41.5 | 0.0 | 207.0 |
| CHAMPION KNOWS CHALLENGE | 0.3 | -4.7 | 0.0 | 0.0 | - | - | - | - |
| CHARGE LOSSES | 13.0 | -477.8 | 0.0 | 477.3 | 23.3 | -1325.0 | 0.0 | 971.7 |
| CHARGE NOW FIRST | 1.7 | +0.0 | 300.3 | 0.0 | 0.3 | +0.0 | 50.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 5.7 | +0.0 | 0.0 | 0.0 | 9.0 | +0.0 | 0.0 | 0.0 |
| COMBAT PIVOT | - | - | - | - | 0.3 | +0.0 | 0.0 | 156.7 |
| CONVEYANCE SEARCH | - | - | - | - | 2.0 | +209.8 | 156.7 | 156.7 |
| COVER ONCE | 10.7 | -725.8 | 0.0 | 0.0 | 7.0 | -344.2 | 0.0 | 437.0 |
| DENIED BY THE FIGHT | 0.3 | -4.5 | 83.7 | 0.0 | - | - | - | - |
| DEPLOY BY FIGURES | 6.0 | +5.5 | 0.0 | 0.0 | 6.7 | +127.1 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | 0.3 | -29.0 | 0.0 | 0.0 | 0.3 | -27.2 | 119.3 | 0.0 |
| EDGE GIVE GROUND | 0.3 | +8.7 | 40.0 | 0.0 | 0.7 | +26.6 | 238.7 | 0.0 |
| EXACT ROUND | 1.7 | +9.3 | 216.7 | 0.0 | 1.0 | -5.1 | 219.3 | 0.0 |
| FACES THE THREAT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| FALL BACK GOOD ORDER | 2.3 | +2.8 | 174.0 | 0.0 | 1.3 | +27.9 | 338.7 | 0.0 |
| FALLS SHORT | - | - | - | - | 25.0 | +186.4 | 0.0 | 722.0 |
| FIGHT TO THE END | 1.3 | +41.1 | 123.7 | 0.0 | - | - | - | - |
| FIRE IN ORDER | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FIVE ACTION | 82.3 | +6017.5 | 2676.7 | 614.3 | 83.7 | +3943.1 | 338.7 | 2030.7 |
| FLANK NOT WEIGHED | 6.7 | +0.0 | 0.0 | 119.3 | 6.3 | +0.0 | 0.0 | 302.3 |
| FOLLOW UP WEIGHED | 1.7 | +99.2 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| FOUR ROUNDS | 3.3 | +364.9 | 350.7 | 0.0 | 1.3 | +143.8 | 338.7 | 0.0 |
| FREED FROM HIS FIGHT | 2.0 | +0.0 | 0.0 | 0.0 | 4.7 | +0.0 | 0.0 | 295.3 |
| FRIEND SHOOTS FIRST | 2.7 | -53.9 | 0.0 | 0.0 | 0.3 | -0.9 | 0.0 | 0.0 |
| FRIENDS SHOTS CHECKED | 0.3 | +16.5 | 0.0 | 0.0 | - | - | - | - |
| GIVES UP | 0.7 | -10.0 | 50.3 | 0.0 | - | - | - | - |
| GOAL WALK | 1.3 | +135.4 | 0.0 | 0.0 | 12.7 | +1800.9 | 0.0 | 95.3 |
| GUN MASK | 6.0 | +263.5 | 0.0 | 72.3 | - | - | - | - |
| HARD STAY DROPPED | 2.0 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 79.7 |
| HE REFORMS ONCE FREED | 1.7 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 295.3 |
| HIS CHARGE BY HIS RUN | 11.0 | +0.0 | 0.0 | 477.3 | 11.7 | +0.0 | 0.0 | 637.7 |
| HIS CHARGE DENIED | 0.3 | +9.1 | 83.7 | 0.0 | - | - | - | - |
| HIS CHARGE LIST | 3.7 | +0.0 | 0.0 | 0.0 | 7.0 | +0.0 | 0.0 | 527.0 |
| HIS LEGAL MOVES | 1.3 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 4.0 | -9.7 | 0.0 | 238.7 | 13.0 | -151.2 | 0.0 | 437.7 |
| HIS ONE QUARTER | 1.3 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 6.0 | +0.0 | 0.0 | 72.3 | 3.7 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVE | 13.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 15.7 | +93.2 | 0.0 | 72.3 | 70.7 | +5804.1 | 0.0 | 1817.0 |
| HIS SHOTS BY HIS RUN | 21.3 | +291.0 | 0.0 | 477.3 | 58.7 | +2381.4 | 0.0 | 1784.7 |
| HIS TURN RUN | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 14.0 | +0.0 | 0.0 | 0.0 | 11.7 | +0.0 | 0.0 | 333.0 |
| HOLDER ASSIGNMENT | 11.3 | +988.2 | 0.0 | 32.3 | 8.7 | +895.6 | 0.0 | 258.7 |
| HOLDS AMBUSHERS | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 3.3 | -114.5 | 350.7 | 0.0 | 1.0 | -79.5 | 288.7 | 0.0 |
| HUNT IN PAIRS | 0.7 | +5.7 | 0.0 | 0.0 | - | - | - | - |
| IDLE COST | - | - | - | - | 20.7 | -326.8 | 0.0 | 511.3 |
| JOINT CHARGE NOW | 0.3 | -29.1 | 0.0 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 1.3 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 1.0 | +5.5 | 0.0 | 0.0 | 0.7 | +40.1 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 5.0 | +0.0 | 585.3 | 254.7 | 4.3 | +0.0 | 50.0 | 88.7 |
| LONE WIZARD KEPT IN | 0.7 | +41.6 | 0.0 | 0.0 | - | - | - | - |
| LONG SHOT | - | - | - | - | 0.3 | -1.0 | 50.0 | 0.0 |
| LOST AFTER ESCAPE | 2.7 | -3.3 | 280.3 | 0.0 | 1.3 | -0.3 | 338.7 | 0.0 |
| MAKE SURE TOGETHER | - | - | - | - | 0.7 | +1.1 | 0.0 | 128.3 |
| MANOEUVRE | 1.0 | +2.5 | 0.0 | 0.0 | 0.7 | +7.9 | 0.0 | 0.0 |
| MARCH BY THE SUM | 2.0 | +88.6 | 0.0 | 0.0 | 0.3 | +58.3 | 0.0 | 0.0 |
| MARCH CHECK | 3.0 | +195.0 | 0.0 | 0.0 | - | - | - | - |
| MARCH OF THE TABLE | 2.0 | +277.4 | 0.0 | 0.0 | 0.3 | +0.4 | 0.0 | 156.7 |
| MARCH OVER CASTS | 3.3 | +50.0 | 0.0 | 0.0 | 1.3 | +191.2 | 0.0 | 221.7 |
| MARCH WHEELS ONLY | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MAX FOR POSITIONING | 5.0 | +104.2 | 0.0 | 0.0 | 3.3 | +53.5 | 0.0 | 478.3 |
| MEETS IN TIME | 3.7 | +420.3 | 0.0 | 0.0 | 3.7 | +347.5 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 12.3 | +319.0 | 0.0 | 0.0 | 2.3 | +11.1 | 0.0 | 65.0 |
| MISSILES NEXT TURN | 16.0 | +265.0 | 0.0 | 0.0 | 5.7 | +26.7 | 0.0 | 286.7 |
| MISSILES ON ONE TARGET | 0.3 | -1.9 | 0.0 | 0.0 | - | - | - | - |
| MOVE ORDER | - | - | - | - | 3.3 | +0.0 | 249.3 | 41.0 |
| MOVE SPELL SPOT | - | - | - | - | 1.7 | +0.0 | 0.0 | 156.7 |
| MOVE TO CHARGE COMPUTED | 9.7 | +849.8 | 0.0 | 72.3 | 6.0 | +435.3 | 0.0 | 949.0 |
| NEARER NOT NEEDED | 4.7 | +199.7 | 0.0 | 0.0 | 6.0 | +240.4 | 0.0 | 20.0 |
| NEXT CHARGE BY LIST | 5.0 | +613.4 | 0.0 | 72.3 | 3.3 | +284.3 | 0.0 | 698.3 |
| NEXT OBJECTIVE NEARER | - | - | - | - | 0.3 | -2.4 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 2.3 | -113.0 | 350.7 | 0.0 | 1.3 | -50.7 | 338.7 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 0.3 | -0.0 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 7.3 | -257.1 | 0.0 | 0.0 | 4.3 | -336.1 | 0.0 | 77.3 |
| OGRE LOADER SECOND SHOT | 12.3 | +54.6 | 0.0 | 0.0 | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 5.0 | -141.2 | 0.0 | 0.0 | 5.7 | -139.3 | 0.0 | 562.0 |
| ONE JOINT FIGURE | 0.3 | +9.8 | 0.0 | 0.0 | - | - | - | - |
| ONE OBJECTIVE FORMULA | 5.0 | -48.9 | 0.0 | 32.3 | 2.3 | -90.0 | 0.0 | 83.7 |
| ONE PROMISE A TARGET | 0.7 | -19.9 | 0.0 | 0.0 | 0.3 | -26.4 | 0.0 | 128.3 |
| ONE ROUTE | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| OPENS A LANE | 0.3 | +0.2 | 0.0 | 0.0 | - | - | - | - |
| OPENS UP | 0.3 | +8.4 | 20.0 | 0.0 | - | - | - | - |
| OVERRUNS AWAY | - | - | - | - | 1.0 | +9.4 | 219.3 | 0.0 |
| OWN CAST FIRST | 1.3 | -24.9 | 0.0 | 0.0 | - | - | - | - |
| PLAN RESULT | 37.3 | +957.2 | 1139.3 | 498.0 | 40.0 | +64.3 | 253.0 | 1402.0 |
| PROMISE BY ITS OWN SUM | 16.0 | -624.4 | 0.0 | 144.7 | 8.0 | -257.6 | 0.0 | 385.0 |
| PROMISE IN STEPS | 2.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | 1.7 | -12.5 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 552.0 |
| PROMISE READS THE TABLE | 1.3 | -5.6 | 0.0 | 0.0 | 0.7 | -2.6 | 0.0 | 38.7 |
| PROMISE SHOT AWAY | 1.3 | -5.5 | 130.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | 14.0 | +1491.7 | 323.0 | 64.7 | 12.0 | +1800.8 | 238.7 | 159.3 |
| RANDOM MOVE BY FIGURES | - | - | - | - | 3.0 | +36.5 | 0.0 | 113.3 |
| REAL GROUND | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| REDIRECT COUNTER | - | - | - | - | 1.3 | +163.8 | 0.0 | 20.0 |
| REFORMS TO MEET IT | 4.0 | -272.0 | 0.0 | 0.0 | - | - | - | - |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| RISK BY ARC | 2.7 | +87.0 | 350.7 | 0.0 | 1.0 | -71.0 | 219.3 | 0.0 |
| RISK ON THE WAY | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ROUNDS AFTER TERROR | - | - | - | - | 0.7 | -37.5 | 238.7 | 0.0 |
| RUN DOWN | 1.3 | -26.9 | 174.0 | 0.0 | 1.3 | -56.9 | 338.7 | 0.0 |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 1.0 | +36.9 | 0.0 | 60.0 |
| SEARCH SPOT | - | - | - | - | 1.0 | +0.4 | 0.0 | 0.0 |
| SECOND LOOK | 0.7 | +26.8 | 50.3 | 0.0 | - | - | - | - |
| SET CREDITED ONCE | 1.0 | -22.9 | 0.0 | 0.0 | 3.0 | -135.1 | 0.0 | 20.0 |
| SET UP BY THE SET | 3.3 | +23.1 | 0.0 | 0.0 | 3.3 | +106.7 | 0.0 | 20.0 |
| SET UP TOGETHER | - | - | - | - | 1.3 | +4.1 | 0.0 | 256.7 |
| SET-UP ANY TARGET | - | - | - | - | 0.3 | +50.5 | 156.7 | 156.7 |
| SHOOTER COUNTED ONCE | - | - | - | - | 0.3 | -0.9 | 0.0 | 20.0 |
| SHOOTERS ON THE TABLE | 17.0 | +0.0 | 0.0 | 32.3 | 3.0 | +0.0 | 0.0 | 85.0 |
| SHOOTS FROM THE BEST SPOT | 6.7 | +303.5 | 486.3 | 0.0 | 0.7 | +86.5 | 0.0 | 130.0 |
| SHOT OR CHARGE | 1.0 | -28.0 | 313.3 | 0.0 | - | - | - | - |
| SHOT RISK POINTS | 13.0 | -50.5 | 0.0 | 311.0 | 46.7 | +1076.4 | 0.0 | 1445.0 |
| SHOTS AFTER THE MOVES | 6.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 16.7 | +886.4 | 0.0 | 32.3 | 3.0 | +117.8 | 0.0 | 41.0 |
| SPELL SETS UP CHARGE | - | - | - | - | 0.3 | +50.5 | 156.7 | 156.7 |
| SPELL WORTH | 1.7 | +5.6 | 0.0 | 0.0 | 2.0 | +49.8 | 313.3 | 313.3 |
| SPELLS IN THE FIGHT | 1.0 | +2.9 | 156.7 | 0.0 | - | - | - | - |
| SPOT AS THE GAME MOVES | 4.3 | +0.0 | 0.0 | 72.3 | 6.7 | +0.0 | 0.0 | 285.0 |
| STAND AND SHOOT | - | - | - | - | 0.3 | -2.6 | 50.0 | 0.0 |
| STANDS FOR A REASON | - | - | - | - | 3.7 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 43.0 | +0.0 | 2326.0 | 303.3 | 22.0 | +0.0 | 0.0 | 743.0 |
| STAY WORTH | 30.3 | -340.3 | 1317.0 | 97.0 | 3.3 | +30.6 | 0.0 | 41.0 |
| SUPPORT ADDS | 3.0 | +243.3 | 0.0 | 0.0 | 1.3 | +142.0 | 0.0 | 0.0 |
| SUPPORT WORKED OUT | 3.0 | +243.3 | 0.0 | 0.0 | 1.3 | +142.0 | 0.0 | 0.0 |
| SURE REACH TOGETHER | - | - | - | - | 0.7 | +2.4 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 2.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| THE PROMISE ADDS | - | - | - | - | 0.7 | -2.6 | 0.0 | 38.7 |
| THE ROW IN ITS ORDER | 1.7 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 1.0 | +0.0 | 0.0 | 0.0 | 5.3 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 1.7 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 37.7 | +0.0 | 0.0 | 271.0 | 40.7 | +0.0 | 0.0 | 1008.0 |
| TIED UP BY THE SUM | 1.0 | +107.6 | 154.0 | 0.0 | 0.3 | +16.2 | 50.0 | 0.0 |
| TIME ON OUR SIDE | 27.7 | +498.8 | 0.0 | 0.0 | - | - | - | - |
| WAITS AGAIN | 4.7 | +0.0 | 0.0 | 72.3 | 1.3 | +0.0 | 0.0 | 122.3 |
| WHAT THE JOINER ADDS | - | - | - | - | 0.7 | -52.5 | 100.0 | 0.0 |
| WHO FIGHTS | 1.0 | +6.8 | 40.0 | 0.0 | - | - | - | - |
| WHO HITS BACK | - | - | - | - | 0.7 | +191.9 | 0.0 | 0.0 |
| WHOLE FIGHT | - | - | - | - | 0.3 | +25.2 | 50.0 | 0.0 |
| WHOLE FIGHT DANGER | 1.7 | -422.9 | 0.0 | 238.7 | 1.0 | -67.6 | 0.0 | 0.0 |
| WHOLE FIGHT GAIN | 0.3 | +29.1 | 0.0 | 0.0 | - | - | - | - |
| WOUNDS ON THE RANKS | 4.7 | +11.4 | 0.0 | 238.7 | - | - | - | - |

### Rule changes: cora-bb45c30-p31

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 110 | 110 | 76 | 25.33 | +1757 | +23.1 |
| HIS SHOT LIST | 259 | 239 | 60 | 20.00 | +2519 | +42.0 |
| FIVE ACTION | 498 | 477 | 55 | 18.33 | +4382 | +79.7 |
| HOLDER ASSIGNMENT | 60 | 60 | 54 | 18.00 | +3757 | +69.6 |
| HIS SHOTS BY HIS RUN | 240 | 229 | 50 | 16.67 | +892 | +17.8 |
| SHOT RISK POINTS | 179 | 166 | 40 | 13.33 | +2016 | +50.4 |
| OGRE LOADER SECOND SHOT | 37 | 37 | 37 | 12.33 | +164 | +4.4 |
| OFF BEST | 35 | 35 | 35 | 11.67 | -1780 | -50.8 |
| PROMISE BY ITS OWN SUM | 72 | 72 | 31 | 10.33 | -2646 | -85.4 |
| THE TABLE AGAIN | 36 | 36 | 29 | 9.67 | +0 | +0.0 |
| LEGAL CHARGES ONLY | 28 | 28 | 28 | 9.33 | +0 | +0.0 |
| MOVE TO CHARGE COMPUTED | 47 | 34 | 25 | 8.33 | +1112 | +44.5 |
| ARTILLERY RE-ROLL WEIGHED | 23 | 23 | 23 | 7.67 | +0 | +0.0 |
| DEPLOY BY FIGURES | 38 | 38 | 18 | 6.00 | +443 | +24.6 |
| SHOOTS FROM THE BEST SPOT | 22 | 22 | 16 | 5.33 | +83 | +5.2 |
| QUARTER ODDS | 78 | 78 | 15 | 5.00 | +1962 | +130.8 |
| GOAL WALK | 42 | 42 | 14 | 4.67 | +2236 | +159.7 |
| NEXT CHARGE BY LIST | 25 | 19 | 14 | 4.67 | +779 | +55.7 |
| CHARGE LOSSES | 109 | 102 | 12 | 4.00 | +1513 | +126.1 |
| HARD STAY DROPPED | 12 | 12 | 12 | 4.00 | +0 | +0.0 |
| MEETS IN TIME | 22 | 22 | 12 | 4.00 | +535 | +44.6 |
| COVER ONCE | 53 | 35 | 10 | 3.33 | +409 | +40.9 |
| MOVE ORDER | 10 | 10 | 10 | 3.33 | +0 | +0.0 |
| MAX FOR POSITIONING | 25 | 25 | 8 | 2.67 | +6 | +0.8 |
| TIME ON OUR SIDE | 83 | 68 | 8 | 2.67 | +87 | +10.9 |
| CAST JOB | 12 | 12 | 7 | 2.33 | +200 | +28.6 |
| FOUR ROUNDS | 14 | 13 | 7 | 2.33 | +286 | +40.9 |
| GUN MASK | 18 | 17 | 7 | 2.33 | +261 | +37.2 |
| MARCH BY THE SUM | 7 | 7 | 7 | 2.33 | +441 | +63.0 |
| MARCH OF THE TABLE | 7 | 7 | 7 | 2.33 | -833 | -119.1 |
| SET UP BY THE SET | 20 | 20 | 7 | 2.33 | +257 | +36.8 |
| ADVANCE LANE KEPT | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 6 | 6 | 6 | 2.00 | +298 | +49.6 |
| IDLE COST | 62 | 45 | 6 | 2.00 | +78 | +13.0 |
| MISSILES IN THE MOVE | 44 | 29 | 6 | 2.00 | +88 | +14.6 |
| SUPPORT ADDS | 13 | 13 | 6 | 2.00 | +99 | +16.5 |
| SUPPORT WORKED OUT | 13 | 13 | 6 | 2.00 | +99 | +16.5 |
| CANNON SIGHT KEPT | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| HOLDS AMBUSHERS | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| LANE BY FIGURES | 5 | 5 | 5 | 1.67 | +137 | +27.3 |
| MARCH CHECK | 9 | 8 | 5 | 1.67 | +40 | +8.1 |
| RANDOM MOVE BY FIGURES | 9 | 9 | 5 | 1.67 | +110 | +21.9 |
| SHOTS AFTER THE MOVES | 21 | 21 | 5 | 1.67 | +0 | +0.0 |
| NEARER NOT NEEDED | 32 | 32 | 4 | 1.33 | +110 | +27.6 |
| OWN CAST FIRST | 4 | 4 | 4 | 1.33 | -75 | -18.7 |
| PROMISE KNOWS THE FIGHT | 13 | 9 | 4 | 1.33 | -38 | -9.4 |
| PROMISE SHOT AWAY | 4 | 4 | 4 | 1.33 | -16 | -4.1 |
| AFTERMATH IN POINTS | 3 | 3 | 3 | 1.00 | +687 | +229.1 |
| CANNON PLANNED TARGET | 32 | 32 | 3 | 1.00 | +54 | +17.9 |
| CHALLENGE BY POINTS | 3 | 3 | 3 | 1.00 | +124 | +41.5 |
| ONE PROMISE A TARGET | 3 | 3 | 3 | 1.00 | -139 | -46.3 |
| SCREEN BY WHAT IT SAVES | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| TIED UP BY THE SUM | 4 | 4 | 3 | 1.00 | +144 | +48.2 |
| CHAFF IN THE MOVE | 6 | 6 | 2 | 0.67 | +0 | +0.0 |
| CHARGE NOW FIRST | 6 | 6 | 2 | 0.67 | -69 | -34.5 |
| FALLS SHORT | 75 | 70 | 2 | 0.67 | +5 | +2.5 |
| LONE WIZARD KEPT IN | 2 | 2 | 2 | 0.67 | +125 | +62.4 |
| MANOEUVRE | 5 | 5 | 2 | 0.67 | +32 | +16.0 |
| OVERRUNS AWAY | 3 | 3 | 2 | 0.67 | +12 | +6.1 |
| RISK BY ARC | 11 | 10 | 2 | 0.67 | +7 | +3.6 |
| SECOND LOOK | 2 | 2 | 2 | 0.67 | +81 | +40.3 |
| THE ROW IN ITS ORDER | 12 | 2 | 2 | 0.67 | +0 | +0.0 |
| WHO HITS BACK | 2 | 2 | 2 | 0.67 | +511 | +255.7 |
| WHOLE FIGHT DANGER | 8 | 8 | 2 | 0.67 | +22 | +11.0 |
| CASTS FROM BEHIND | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| COMBAT PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| EXACT ROUND | 8 | 8 | 1 | 0.33 | +11 | +10.7 |
| FACES THE THREAT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FIRE IN ORDER | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FRIENDS SHOTS CHECKED | 1 | 1 | 1 | 0.33 | +50 | +49.5 |
| HIS MOVE AND SHOT | 51 | 51 | 1 | 0.33 | +3 | +3.4 |
| JOINT CHARGE NOW | 1 | 1 | 1 | 0.33 | -87 | -87.4 |
| MISSILES NEXT TURN | 65 | 51 | 1 | 0.33 | +29 | +29.0 |
| ONE OBJECTIVE FORMULA | 22 | 18 | 1 | 0.33 | +76 | +76.0 |
| REFUSING RETIRES | 2 | 2 | 1 | 0.33 | -17 | -16.6 |
| SEARCH SPOT | 3 | 3 | 1 | 0.33 | +1 | +1.1 |
| SHOTS IN THE MOVE | 59 | 39 | 1 | 0.33 | +44 | +43.5 |
| SPELLS IN THE FIGHT | 3 | 3 | 1 | 0.33 | +6 | +6.0 |
| STAY WORTH | 101 | 87 | 1 | 0.33 | +1 | +1.3 |
| WHO FIGHTS | 3 | 3 | 1 | 0.33 | +11 | +10.7 |
| WHOLE FIGHT | 1 | 1 | 1 | 0.33 | +11 | +11.0 |
| BACKUP TARGETS | 2 | 2 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 1 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 5 | trace | - | - | - | - |
| CHAMPION KNOWS CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 44 | 43 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 6 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 2 | 1 | 0 | 0.00 | - | - |
| EDGE GIVE GROUND | 3 | 3 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 11 | 10 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 4 | 3 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 39 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 20 | 15 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 9 | 9 | 0 | 0.00 | - | - |
| GIVES UP | 2 | 1 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 18 | 14 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 68 | 61 | 0 | 0.00 | - | - |
| HIS CHARGE DENIED | 1 | 1 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 32 | 27 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 15 | 15 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 15 | 15 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 29 | 22 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 41 | 41 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN RUN | 18 | 18 | 0 | 0.00 | - | - |
| HOLD ODDS | 77 | 77 | 0 | 0.00 | - | - |
| HONEST WORTH | 13 | 12 | 0 | 0.00 | - | - |
| HUNT IN PAIRS | 2 | 2 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 12 | 12 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 2 | 2 | 0 | 0.00 | - | - |
| LONG SHOT | 1 | 1 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 12 | 11 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 2 | not checked | - | - | - | - |
| MARCH OVER CASTS | 14 | 14 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 2 | 2 | 0 | 0.00 | - | - |
| MISSILES ON ONE TARGET | 1 | not checked | - | - | - | - |
| MOVE SPELL SPOT | 5 | not checked | - | - | - | - |
| NEXT OBJECTIVE NEARER | 1 | 1 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 11 | 11 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 1 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 2 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 32 | 23 | 0 | 0.00 | - | - |
| ONE JOINT FIGURE | 1 | not checked | - | - | - | - |
| ONE ROUTE | 2 | 2 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 18 | 18 | 0 | 0.00 | - | - |
| OPENS A LANE | 1 | not checked | - | - | - | - |
| OPENS UP | 1 | 1 | 0 | 0.00 | - | - |
| PLAN RESULT | 232 | trace | - | - | - | - |
| PROMISE IN STEPS | 7 | 7 | 0 | 0.00 | - | - |
| PROMISE READS THE TABLE | 6 | 6 | 0 | 0.00 | - | - |
| REAL GROUND | 2 | 2 | 0 | 0.00 | - | - |
| REDIRECT COUNTER | 4 | 4 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 12 | 12 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 1 | 1 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 2 | 2 | 0 | 0.00 | - | - |
| RUN DOWN | 8 | 8 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 12 | 12 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 4 | 2 | 0 | 0.00 | - | - |
| SET-UP ANY TARGET | 1 | not checked | - | - | - | - |
| SHOOTER COUNTED ONCE | 1 | 1 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 60 | not checked | - | - | - | - |
| SHOT OR CHARGE | 3 | 3 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 1 | not checked | - | - | - | - |
| SPELL WORTH | 11 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 33 | 28 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 1 | 1 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 11 | 10 | 0 | 0.00 | - | - |
| STANDS STILL | 195 | 192 | 0 | 0.00 | - | - |
| SURE REACH TOGETHER | 2 | 2 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 10 | not checked | - | - | - | - |
| THE PROMISE ADDS | 2 | 1 | 0 | 0.00 | - | - |
| THE ROW KEEPS ITS WAY | 19 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 12 | not checked | - | - | - | - |
| THE TABLE BINDS | 235 | not checked | - | - | - | - |
| WAITS AGAIN | 18 | 14 | 0 | 0.00 | - | - |
| WHAT THE JOINER ADDS | 2 | 2 | 0 | 0.00 | - | - |
| WHOLE FIGHT GAIN | 1 | not checked | - | - | - | - |
| WOUNDS ON THE RANKS | 14 | 14 | 0 | 0.00 | - | - |

### Off best figure: cora-bb45c30-p31

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 7.00 | 3.67 | 51.6 |
| PROMISE BY ITS OWN SUM | rule | 7.67 | 2.33 | 88.2 |
| ARMY TABLE | rule | 1.00 | 3.33 | 62.3 |
| MARCH OF THE TABLE | rule | 2.00 | 0.33 | 119.1 |
| OWN CAST FIRST | rule | 1.33 | - | 18.7 |
| PROMISE KNOWS THE FIGHT | rule | 1.33 | - | 9.4 |
| PROMISE SHOT AWAY | rule | 1.33 | - | 4.1 |
| ONE PROMISE A TARGET | rule | 0.67 | 0.33 | 46.3 |
| CHARGE NOW FIRST | rule | 0.67 | - | 34.5 |
| HOLDER ASSIGNMENT | rule | 0.33 | 0.33 | 15.3 |
| RULE SWITCHED OFF | gate | - | 0.67 | 55.4 |
| CANNON PLANNED TARGET | rule | 0.33 | - | 2.3 |
| JOINT CHARGE NOW | rule | 0.33 | - | 87.4 |
| NO REASON | gate | 0.33 | - | 17.4 |
| REFUSING RETIRES | rule | - | 0.33 | 16.6 |

### Plans: cora-bb45c30-p31

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 2.7 | 88% | 386 | 264 | 68% |
| Mine | move | 20.3 | 98% | 1567 | 0 | 0% |
| Mine | shoot | 14.3 | 44% | 823 | 693 | 84% |
| Opponent | charge | 1.0 | 67% | 122 | 64 | 53% |
| Opponent | join | 0.7 | 100% | 23 | 0 | 0% |
| Opponent | move | 36.3 | 92% | 1735 | 0 | 0% |
| Opponent | shoot | 1.3 | 0% | 59 | 0 | 0% |
| Opponent | support | 0.7 | 50% | 63 | 0 | 0% |

### Battle groups: cora-bb45c30-p31

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | REDIRECT COUNTER | 1.3 | 25% | 100% | 0% | - | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: cora-bb45c30-p31

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Character | 9 | 55 (9) | 55 | 0 | 23 | 11% | 2.1 | 87 (2) | 55 (6) | - | 68 (4) | 54 (4) |
| Mine | Clean-up | 2 | 99 (2) | 0 | 99 | 0 | 0% | 2.5 | 0 (1) | 186 (1) | - | 99 (2) | - |
| Mine | Fast Hammer | 4 | 53 (4) | 0 | 53 | 50 | 25% | 2.7 | 0 (2) | 75 (2) | - | 50 (3) | 59 (1) |
| Mine | Holder | 1 | 140 (1) | 0 | 140 | 0 | 0% | 1.0 | 140 (1) | - | - | 140 (1) | - |
| Mine | Shooter | 4 | 45 (4) | 0 | 45 | 18 | 25% | 2.3 | 48 (3) | 31 (1) | - | 65 (3) | 0 (1) |
| Mine | War machine | 6 | 56 (6) | 56 | 0 | 0 | 0% | 1.0 | 52 (2) | 117 (2) | 0 (2) | 103 (1) | 47 (5) |
| Mine | Wizard | 3 | 98 (3) | 98 | 0 | 0 | 0% | 2.7 | 131 (2) | 68 (1) | - | 98 (3) | - |
| Opponent | Chaff | 2 | 100 (2) | 0 | 100 | 50 | 50% | 2.0 | - | 200 (1) | 0 (1) | 100 (2) | - |
| Opponent | Character | 10 | 25 (10) | 25 | 0 | 36 | 50% | 2.8 | 0 (3) | 53 (5) | 0 (2) | 46 (5) | 0 (5) |
| Opponent | Fast Hammer | 9 | 14 (9) | 0 | 14 | 61 | 56% | 3.0 | 0 (2) | 17 (7) | - | 14 (5) | 14 (4) |
| Opponent | Hammer | 3 | 54 (3) | 54 | 0 | 37 | 33% | 5.0 | 52 (2) | 57 (1) | - | 52 (2) | 57 (1) |
| Opponent | Holder | 5 | 11 (5) | 0 | 11 | 14 | 40% | 4.3 | 0 (2) | 0 (1) | 26 (2) | 15 (3) | 0 (2) |
| Opponent | Shooter | 1 | 0 (1) | 0 | 0 | 0 | 0% | 1.0 | - | 0 (1) | - | 0 (1) | - |
| Opponent | Wizard | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | - | 0 (1) | - | 0 (1) |

### Charged fights: cora-bb45c30-p31

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Grand Cathay | 3 | 418 | 351 | 3.3 | 1.0 | 105 | 0 | +105 | 3 of 10 | 6 of 10 | - | +105 |
| Opponent | High Elf Realms | 1 | 0 | 654 | 3.0 | 1.0 | 218 | 48 | +170 | 3 of 3 | 1 of 3 | - | +170 |
| Opponent | Vampire Counts | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Warriors of Chaos | 1 | 0 | 150 | 2.0 | 1.0 | 75 | 0 | +75 | 0 of 2 | 2 of 2 | - | +75 |
| **Opponent** | all armies | 3 | 0 | 268 | 1.7 | 1.0 | 161 | 29 | +132 | 3 of 5 | 3 of 5 | - | +132 |

### Effective charges: cora-bb45c30-p31

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Grand Cathay | 10 | 1 (net +0) | 0 | 2 (net +0) | 1 (net +120) | 1 (net +60) | 3 (net +240) | 2 | 25% (2 of 8) |
| Opponent | High Elf Realms | 3 | 1 (net +654) | 0 | 0 | 0 | 0 | 0 | 2 | 0% (0 of 1) |
| Opponent | Warriors of Chaos | 2 | 0 | 0 | 0 | 0 | 0 | 2 (net +75) | 0 | 0% (0 of 2) |

### Charged fights, damage counted: cora-bb45c30-p31

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 1 | 173 | 129 | +0 | 0 | 29 | -29 | -16.7 |
| Mine | Effective (55-75%) | 2 | 276 | 338 | +0 | 26 | 0 | +26 | +9.5 |
| Mine | 76-89% | 1 | 233 | 120 | +120 | 120 | 0 | +120 | +51.5 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 | 372 | 272 | +240 | 248 | 90 | +158 | +42.4 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 205 | 60 | +60 | 60 | 0 | +60 | +29.3 |
| Mine | No odds | 2 | 352 | 178 | +76 | 76 | 0 | +76 | +21.5 |
| Mine | All fights | 10 | 298 | 216 | +105 | 113 | 30 | +83 | +27.8 |
| Opponent | Long shot (under 50%) | 1 | 489 | 358 | +654 | 654 | 0 | +654 | +133.7 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 116 | 150 | +75 | 75 | 0 | +75 | +64.7 |
| Opponent | No odds | 2 | 316 | 296 | -72 | 39 | 72 | -33 | -10.3 |
| Opponent | All fights | 5 | 271 | 250 | +132 | 176 | 29 | +148 | +54.6 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| cora-bb45c30-p31 | move | 25 | 4 (16%) | 4 (16%) | 0 (0%) | 21 (84%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L1224 |
| Clockwork Compass | Mine | L1224 |
| Elixir of Power | Mine | L1114, L1131 |
| Invocation of Nehek | Opponent | L1224 |
| Opal Amulet | Opponent | L1114 |
| Ring of Doom | Mine | L1114, L1131, L1224 |
| Ring of Doom | Opponent | L1131 |
| Ring of Jet | Mine | L1114, L1131, L1224 |

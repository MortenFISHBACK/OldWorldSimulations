# Doctrine scorecard: cora-bb45c30-p25

### Scorecard: cora-bb45c30-p25

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0102 | 6 | 1 | Mine | no | 0 | - | 0 | 0 | 0 | 0 | 0 | 55 |
| L0102 | 6 | 1 | Opponent | no | 4 | 2 | 0 | 5 | 0 | 0 | 0 | 0 |
| L0118 | 4 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 0 |
| L0118 | 4 | 1 | Opponent | no | 0 | 4 | 2 | 5 | 0 | 0 | 0 | 0 |
| L0135 | 3 | 1 | Mine | no | 7 | - | 0 | 0 | 0 | 0 | 0 | 55 |
| L0135 | 3 | 1 | Opponent | no | 1 | 2 | 2 | 5 | 0 | 0 | 0 | 224 |
| **Average** | | | Mine | 0% | 2.3 | - | 0.0 | 0.3 | 0.0 | 0.0 | 0.0 | 36.7 |
| **Average** | | | Opponent | 0% | 1.7 | 2.7 | 1.3 | 5.0 | 0.0 | 0.0 | 0.0 | 74.7 |

### KPIs: cora-bb45c30-p25

Rules off - Opponent only: ONE RUN A PLAN.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 5) | 0% (0 of 15) | 0% (0 of 20) |
| Winner chose to follow up after the loser gave ground |  | - | - | - |
| Winner chose to pursue after the loser fell back in good order |  | 100% (1 of 1); on the table 100% | - | 100% (1 of 1); on the table 100% |
| Winner chose to pursue after the loser fled |  | 100% (1 of 1); on the table 100% | 80% (4 of 5); on the table 80% | 83% (5 of 6); on the table 83% |
| Winner chose to follow up or pursue (all three) |  | 100% (2 of 2); on the table 100% | 80% (4 of 5); on the table 80% | 86% (6 of 7); on the table 86% |
| Magic missiles tried each own turn | 50%+ | 22% (20 of 90) | 12% (3 of 24) | 20% (23 of 114) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 26% (20 of 78) | 12% (3 of 24) | 23% (23 of 102) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 67% (4 of 6) | 67% (4 of 6) |
| Points that never fought | lower | 52% (2955 of 5700) | 79% (4656 of 5899) | 66% (7611 of 11599) |
|   infantry points that never fought | lower | 53% (1437 of 2703) | 100% (1219 of 1219) | 68% (2656 of 3922) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 47% (7 of 15) | 72% (18 of 25) | 62% (25 of 40) |
| Bound items with a magic missile used (at least once a game) |  | 100% (3 of 3); 2.7 uses a game | 75% (3 of 4); 2.3 uses a game | 86% (6 of 7); 2.5 uses a game |
| Bound items with another spell used |  | 100% (3 of 3); 1.0 uses a game | 0.0 uses a game | 100% (3 of 3); 0.5 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 100% (3 of 3); 1.0 uses a game | 50% (1 of 2); 0.3 uses a game | 80% (4 of 5); 0.7 uses a game |
|   their share of the points of units over 100 pts | lower | 43% (1762 of 4077) | 67% (3291 of 4883) | 56% (5053 of 8960) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 15.0 (64%) | 4.0 (57%) | 19.0 (63%) |
| MARCHED: its unit marched | 2.3 (10%) | 2.0 (29%) | 4.3 (14%) |
| IN COMBAT: engaged in combat | 1.0 (4%) | 0.0 (0%) | 1.0 (3%) |
| REAR RANK: in a rear rank | 0.7 (3%) | 0.0 (0%) | 0.7 (2%) |
| OFF THE TABLE: off the table or not arrived | 3.0 (13%) | 0.0 (0%) | 3.0 (10%) |
| STUPIDITY: Stupidity | 0.7 (3%) | 1.0 (14%) | 1.7 (5%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.7 (3%) | 0.0 (0%) | 0.7 (2%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 10.3 | 2.3 | 6.3 | 7.7 | 1.3 |
| not cast | 7.7 | 7.7 | 9.7 | 30.3 | 42.7 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.3 (5%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 3.7 (48%) | 1.0 (10%) | 19.0 (63%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 4.3 (14%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.3 (4%) | 0.3 (3%) | 1.0 (3%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (2%) | 0.0 (0%) |
| GONE: slain | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (2%) |
| OFF THE TABLE: off the table or not arrived | 1.0 (13%) | 1.0 (13%) | 1.0 (10%) | 3.0 (10%) | 3.7 (9%) |
| STUPIDITY: Stupidity | 0.3 (4%) | 0.0 (0%) | 1.0 (10%) | 1.7 (5%) | 0.7 (2%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (2%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 6.3 (83%) | 2.7 (35%) | 6.3 (66%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 35.3 (83%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 5.7 a game | 1.7 a game | 3.7 a game |
| stood (cast and not dispelled) | 76% (13 of 17) | 100% (5 of 5) | 82% (18 of 22) |
| the unit moved after it | 77% (10 of 13) | 40% (2 of 5) | 67% (12 of 18) |
| it charged on its next turn | 0% (0 of 13) | 0% (0 of 5) | 0% (0 of 18) |
| the enemy charged it first | 8% (1 of 13) | 0% (0 of 5) | 6% (1 of 18) |
| it fought by the end of its next turn | 8% (1 of 13) | 0% (0 of 5) | 6% (1 of 18) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 13) | 0% (0 of 5) | 0% (0 of 18) |
| none of these (no charge, no fight, no charge escaped) | 92% (12 of 13) | 100% (5 of 5) | 94% (17 of 18) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 56% (18 of 32) | 49% (35 of 72) | 51% (53 of 104) |
|   cavalry | - | 75% (9 of 12) | 75% (9 of 12) |
|   character | - | 58% (7 of 12) | 58% (7 of 12) |
|   chariot | - | 42% (5 of 12) | 42% (5 of 12) |
|   infantry | 56% (18 of 32) | 25% (6 of 24) | 43% (24 of 56) |
|   monster | - | 67% (8 of 12) | 67% (8 of 12) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.7 (36%) | 1.7 (14%) | 3.3 (20%) |
| CHARGED: it charged | 0.0 (0%) | 0.7 (5%) | 0.7 (4%) |
| FLEEING: it fled or was fleeing | 0.7 (14%) | 0.0 (0%) | 0.7 (4%) |
| IN COMBAT: it fought this turn or the last | 0.3 (7%) | 0.0 (0%) | 0.3 (2%) |
| NO TARGET IN RANGE | 0.3 (7%) | 7.3 (59%) | 7.7 (45%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.0 (21%) | 0.7 (5%) | 1.7 (10%) |
| SHELTERED: the target was sheltered | 0.7 (14%) | 1.3 (11%) | 2.0 (12%) |
| OTHER BAR | 0.0 (0%) | 0.7 (5%) | 0.7 (4%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 4.7 | 1.7 | 71% | 2.6 pts | 12 pts |
| character | 2.3 | 2.0 | 43% | 6.4 pts | 15 pts |
| chariot | 1.7 | 1.0 | 80% | 4.6 pts | 8 pts |
| infantry | 8.0 | 2.7 | 75% | 4.5 pts | 36 pts |
| monster | 2.7 | 0.3 | 88% | 1.0 pts | 3 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 0.0 | 2.0 | 1.0 |
| Charges that made contact a game | 0.0 | 2.0 | 1.0 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | - | - | - |
|   per unit a game, units carrying another wizard (or one alone) | - | - | - |
|   per unit a game, the other units (no war machines, no joined characters) | 0.00 declared, 0.00 contact (15 units) | 0.19 declared, 0.19 contact (32 units) | 0.13 declared, 0.13 contact (47 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 67% (2 of 3) | - | - | 67% (2 of 3) |
| Character in a unit | 100% (3 of 3) | 75% (6 of 8) | - | 82% (9 of 11) |
| Character on its own | 50% (1 of 2) | 100% (3 of 3) | 0% (0 of 1) | 67% (4 of 6) |
| Chariot | 100% (2 of 2) | - | - | 100% (2 of 2) |
| Infantry | 80% (4 of 5) | 14% (1 of 7) | - | 42% (5 of 12) |
| Monster | 0% (0 of 1) | 100% (1 of 1) | - | 50% (1 of 2) |
| Monstrous | 50% (1 of 2) | 50% (1 of 2) | - | 50% (2 of 4) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 80% (4 of 5); on the table 80% | 19% (21 of 108) | 61% | 52% (11 of 21) | 100% (5 of 5); 3.5 uses a game | 100% (3 of 3); 0.8 uses a game | 80% (4 of 5); 1.0 uses a game |
| Ogre Kingdoms | 1 | - | - | 86% | 86% (6 of 7) | 100% (1 of 1); 1.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 1 | 100% (2 of 2); on the table 100% | 33% (2 of 6) | 65% | 67% (8 of 12) | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (cora-bb45c30-p25, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 60% (3) | - | 60% (3) |
| ...free all their last turn and able to turn (per game) | 1.00 | 0.00 | 1.00 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.67 | 0.00 | 0.67 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.33 | 0.33 |

### Quality by phase: cora-bb45c30-p25

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 0.0 | 1.7 |
| Strategy | Charge objectives carried out (made contact) | - | 40% (2 of 5) |
| Strategy | Shoot objectives carried out (shot that target) | 14% (3 of 21) | 29% (7 of 24) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (1 of 1) | - |
| Strategy | Hexes on a unit its side charged or shot that turn | 0% (0 of 1) | 80% (4 of 5) |
| Strategy | Joined characters whose unit fought | 25% (3 of 12) | 0% (0 of 7) |
| Strategy | Lone characters that fought | 100% (6 of 6) | 33% (1 of 3) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 0.3 | 5.0 |
| Movement | Points that never moved of their own | 36.7 | 74.7 |
| Movement | Fights charged into per game | 0.0 | 2.0 |
| Movement | Charges with odds: long shots (under 50%) | - | 0 of 5 |
| Movement | Charges with odds: sweet spot (55-75%) | - | 1 of 5, net +478 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | - | 0 of 5 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | - | 4 of 5, net +338 |
| Shooting | Shots by shooting units (incl. breath weapons) | 6.0 | 11.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 61% (11 of 18) | 69% (24 of 35) |
| Shooting | Points destroyed by shooting units | 0.0 | 0.0 |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | 4.0 | 0.7 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 0% (0 of 12) | 0% (0 of 2) |
| Magic | Wounds caused by magic missiles | 16.0 | 3.7 |
| Magic | Points destroyed by magic (all spells) | 178.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 6.0 / 0.3 / 1.0 / 0.0 | 2.0 / 1.7 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 11.3 | 40.0 |
| Combat | Points run down | 0.0 | 360.7 |
| Combat | Net points per charged fight, damage counted | - | +277 |
| Combat | Net per 100 charger points, damage counted | - | +154.9 |
| Combat | First round won (charged fights) | - | 67% |
| Combat | Net points per charged fight | - | +300 |
| Combat | Net points per supported fight / lone fight | - / - | - / +300 |
| Combat | Charged fights on a top-3 enemy unit | - | 4 of 6 |
| Game | Points lost | 636.3 | 260.0 |
| Game | VP from objectives | 690.0 | 970.0 |
| Game | Lone holders (player turns) | 2.3 | 1.7 |

- Mine won / drew / lost: 0 / 1 / 2 of 3 ended games (of 3); mean margin (Mine - Opponent) -747 VP
- The side that went first won 1 of 2 games with a winner
- Points traded per game (both sides' losses): 896
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: cora-bb45c30-p25

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 36.7 |
| ARMY TABLE | 6.7 | +132.0 | 0.0 | 123.3 | 22.7 | +33.5 | 0.0 | 0.0 |
| CAST JOB | - | - | - | - | 4.0 | +41.7 | 429.3 | 0.0 |
| CASTER AWAY FROM SCREEN | 1.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 8.0 | +807.2 | 446.7 | 214.7 | 2.0 | +65.4 | 43.3 | 0.0 |
| CASTS AFTER FRIENDS | 4.0 | +0.0 | 0.0 | 118.3 | 1.7 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | 1.0 | +6.9 | 0.0 | 0.0 | 2.0 | +56.0 | 0.0 | 0.0 |
| CHAFF PASSED | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| CHALLENGE BY POINTS | 0.3 | +26.7 | 0.0 | 0.0 | - | - | - | - |
| CHARGE LOSSES | 13.7 | -266.2 | 0.0 | 86.7 | 9.7 | -506.4 | 0.0 | 166.7 |
| CHARGE NOW FIRST | - | - | - | - | 0.7 | +0.0 | 125.7 | 0.0 |
| CLOSES ON WHAT IT BEATS | 2.7 | +0.0 | 0.0 | 43.3 | 13.7 | +0.0 | 0.0 | 140.0 |
| CONVEYANCE SEARCH | 4.7 | +583.6 | 107.3 | 118.3 | 1.0 | +39.2 | 0.0 | 0.0 |
| COVER ONCE | 1.7 | -60.5 | 0.0 | 107.3 | 4.3 | -148.9 | 0.0 | 0.0 |
| DENIED BY THE FIGHT | - | - | - | - | 0.3 | -63.5 | 107.3 | 0.0 |
| DEPLOY BY FIGURES | 5.0 | +41.5 | 0.0 | 0.0 | 10.0 | -145.9 | 0.0 | 74.7 |
| EVASIVE BY THE ODDS | - | - | - | - | 1.0 | +9.6 | 21.7 | 0.0 |
| EXACT ROUND | - | - | - | - | 1.0 | +6.8 | 36.7 | 34.0 |
| FALL BACK GOOD ORDER | - | - | - | - | 1.3 | +2.8 | 249.7 | 34.0 |
| FALLS SHORT | 4.7 | +128.2 | 0.0 | 107.3 | 14.7 | +168.6 | 0.0 | 0.0 |
| FEATURE BUFFS | 12.7 | +561.9 | 0.0 | 113.3 | 1.3 | +50.3 | 0.0 | 0.0 |
| FIGHT TO THE END | - | - | - | - | 0.7 | +5.7 | 107.3 | 34.0 |
| FIVE ACTION | 51.3 | +7407.1 | 530.0 | 804.3 | 104.3 | +4353.3 | 1562.0 | 291.3 |
| FLANK NOT WEIGHED | 1.0 | +0.0 | 0.0 | 107.3 | 4.7 | +0.0 | 0.0 | 0.0 |
| FOUR ROUNDS | - | - | - | - | 1.7 | +50.3 | 268.0 | 34.0 |
| FREED FROM HIS FIGHT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | - | - | - | - | 0.3 | -1.0 | 0.0 | 0.0 |
| GOAL WALK | 4.7 | +628.9 | 0.0 | 0.0 | - | - | - | - |
| GROUND FLIERS | - | - | - | - | 0.3 | +6.1 | 0.0 | 0.0 |
| GUN FIGURES | - | - | - | - | 1.7 | +0.0 | 107.3 | 0.0 |
| HARD STAY DROPPED | 0.7 | +0.0 | 0.0 | 107.3 | 7.0 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 4.7 | +0.0 | 0.0 | 65.0 | 5.7 | +0.0 | 0.0 | 83.3 |
| HIS CHARGE LIST | 1.7 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 2.7 | +0.0 | 0.0 | 43.3 | 5.7 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 3.7 | -38.3 | 0.0 | 73.3 | 3.7 | -109.6 | 0.0 | 0.0 |
| HIS ONE QUARTER | 2.0 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 2.7 | +0.0 | 0.0 | 43.3 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVE | 9.3 | +0.0 | 0.0 | 130.0 | - | - | - | - |
| HIS RANDOM MOVER COMES | 1.7 | +0.0 | 0.0 | 21.7 | - | - | - | - |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 24.3 | +434.2 | 0.0 | 228.3 | 52.0 | +2384.4 | 0.0 | 174.0 |
| HIS SHOTS BY HIS RUN | 28.0 | +236.5 | 0.0 | 258.3 | 38.0 | +795.8 | 0.0 | 234.7 |
| HIS TURN DENIED | - | - | - | - | 0.3 | +14.7 | 107.3 | 0.0 |
| HIS TURN RUN | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 32.0 | +0.0 | 0.0 | 273.3 | 15.7 | +0.0 | 0.0 | 0.0 |
| HOLDER ASSIGNMENT | 15.0 | +1739.3 | 0.0 | 83.3 | 11.7 | +1342.7 | 0.0 | 38.0 |
| HOLDS AMBUSHERS | 1.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | - | - | - | - | 1.3 | -27.1 | 160.7 | 34.0 |
| IDLE COST | 1.3 | -6.3 | 0.0 | 0.0 | 21.3 | -236.1 | 0.0 | 151.3 |
| KEPT FROM ITS LAST STOP | 1.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | - | - | - | - | 0.3 | +0.6 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 11.0 | +0.0 | 11.3 | 208.3 | - | - | - | - |
| LONE WIZARD KEPT IN | 3.0 | +270.0 | 0.0 | 0.0 | 0.7 | +87.5 | 0.0 | 0.0 |
| LONG SHOT | - | - | - | - | 1.0 | +1.8 | 125.7 | 34.0 |
| LOST AFTER ESCAPE | - | - | - | - | 1.0 | +1.0 | 231.3 | 34.0 |
| MANOEUVRE | 1.0 | +10.7 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MARCH BY THE SUM | 0.7 | +15.8 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | 0.3 | +17.4 | 0.0 | 0.0 | 1.3 | +65.4 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 0.7 | +7.0 | 0.0 | 18.3 | 0.3 | +0.5 | 0.0 | 0.0 |
| MEETS IN TIME | 1.7 | +224.8 | 0.0 | 0.0 | 7.7 | +309.7 | 0.0 | 74.7 |
| MISSILES IN THE MOVE | 8.7 | +593.7 | 0.0 | 231.3 | 7.0 | +113.5 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 8.0 | +423.2 | 0.0 | 107.3 | 6.0 | +52.2 | 0.0 | 0.0 |
| MISSILES ON ONE TARGET | 3.3 | -117.5 | 0.0 | 107.3 | 1.0 | -7.4 | 0.0 | 0.0 |
| MOVE ORDER | 0.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 11.3 |
| MOVE SPELL OUT OF RANGE | 1.0 | -57.3 | 0.0 | 118.3 | - | - | - | - |
| MOVE SPELL SPOT | 1.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | - | - | - | - | 1.7 | +104.3 | 0.0 | 0.0 |
| MOVES UNITS SPELL | - | - | - | - | 0.3 | +18.4 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 6.0 | +283.4 | 0.0 | 21.7 | 3.0 | +141.5 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | - | - | - | - | 1.0 | +48.6 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | - | - | - | - | 1.3 | -37.3 | 144.0 | 34.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 3.0 | -5.1 | 0.0 | 118.3 | 1.7 | -2.4 | 0.0 | 0.0 |
| OFF BEST | 1.3 | -6.5 | 0.0 | 0.0 | 1.7 | -20.7 | 0.0 | 0.0 |
| ONE CHECK AFTER THE LAST CHANGE | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 2.3 | -27.0 | 0.0 | 58.3 | 2.7 | -41.4 | 0.0 | 0.0 |
| ONE OBJECTIVE FORMULA | 8.0 | +113.8 | 0.0 | 61.7 | 4.0 | +52.8 | 0.0 | 0.0 |
| ONE PROMISE A TARGET | - | - | - | - | 0.7 | -24.5 | 0.0 | 0.0 |
| ONE ROUTE | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| OPENS A LANE | 0.7 | +1.1 | 83.3 | 0.0 | - | - | - | - |
| OVERRUNS AWAY | - | - | - | - | 0.7 | +22.8 | 36.7 | 0.0 |
| PLAN RESULT | 22.0 | +296.1 | 83.3 | 462.0 | 46.7 | +411.5 | 801.3 | 289.3 |
| PROMISE BY ITS OWN SUM | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | - | - | - | - | 0.3 | -1.0 | 0.0 | 0.0 |
| QUARTER ODDS | 10.7 | +1455.6 | 0.0 | 248.0 | 22.3 | +2240.5 | 372.0 | 0.0 |
| RANDOM MOVE BY FIGURES | - | - | - | - | 2.0 | +88.2 | 0.0 | 0.0 |
| REAL GROUND | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | 0.3 | +25.1 | 0.0 | 0.0 | 3.3 | +56.4 | 0.0 | 11.3 |
| REDIRECT FOR A FRIEND IN REACH | 2.7 | +0.0 | 0.0 | 73.3 | 3.3 | +0.0 | 0.0 | 22.7 |
| REFORMS TO MEET IT | - | - | - | - | 0.3 | -25.5 | 0.0 | 0.0 |
| RESERVE MOVE SPELL | 1.0 | +26.2 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | - | - | - | - | 1.3 | -46.0 | 144.0 | 34.0 |
| RISK ON THE WAY | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| ROUNDS AFTER TERROR | - | - | - | - | 0.3 | -1.4 | 124.0 | 0.0 |
| RUN DOWN | - | - | - | - | 1.3 | -12.3 | 268.0 | 0.0 |
| SCOUT SPOT | 1.0 | +1.2 | 0.0 | 0.0 | 0.7 | +2.1 | 0.0 | 0.0 |
| SCOUT WAITS | 1.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.7 | -110.8 | 0.0 | 0.0 | 2.0 | -283.6 | 0.0 | 0.0 |
| SEARCH SPOT | 1.0 | +43.2 | 0.0 | 0.0 | 0.3 | +1.9 | 0.0 | 0.0 |
| SET-UP ANY TARGET | - | - | - | - | 0.3 | +45.9 | 0.0 | 0.0 |
| SHOOTER COUNTED ONCE | - | - | - | - | 0.7 | -1.3 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | - | - | - | - | 0.3 | +0.3 | 0.0 | 36.7 |
| SHOOTERS ON THE TABLE | 7.0 | +0.0 | 0.0 | 231.3 | 8.7 | +0.0 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 3.3 | +133.1 | 83.3 | 248.0 | 0.7 | +1.3 | 0.0 | 0.0 |
| SHOT OR CHARGE | - | - | - | - | 1.0 | -6.2 | 125.7 | 34.0 |
| SHOT RISK POINTS | 18.7 | -275.4 | 0.0 | 221.7 | 46.3 | +311.0 | 0.0 | 257.3 |
| SHOTS AFTER THE MOVES | 1.7 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 7.0 | +142.1 | 0.0 | 65.0 | 14.0 | +126.1 | 0.0 | 0.0 |
| SPELL SETS UP CHARGE | - | - | - | - | 0.3 | +45.9 | 0.0 | 0.0 |
| SPELL WORTH | 2.0 | +3.8 | 71.7 | 43.3 | 2.3 | +11.9 | 0.0 | 0.0 |
| SPOT AS THE GAME MOVES | 3.3 | +0.0 | 0.0 | 98.3 | 5.3 | +0.0 | 0.0 | 28.3 |
| STANDS FOR A REASON | - | - | - | - | 7.3 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 19.3 | +0.0 | 530.0 | 517.7 | 45.0 | +0.0 | 1294.0 | 11.3 |
| STAY WORTH | 12.0 | +204.6 | 363.3 | 65.0 | 20.7 | +89.4 | 1002.7 | 0.0 |
| STRIKE BY THE ODDS | - | - | - | - | 0.3 | +3.5 | 31.7 | 34.0 |
| STUBBORN BY POINTS | - | - | - | - | 0.3 | +9.9 | 0.0 | 34.0 |
| STUCK PIVOT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 2.7 | +192.0 | 0.0 | 0.0 | - | - | - | - |
| SUPPORT WORKED OUT | 2.7 | +192.0 | 0.0 | 0.0 | - | - | - | - |
| THE DEARER SUM KEEPS ITS PLAN | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 0.3 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 0.7 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 41.7 |
| THE STEP BACK IS MADE | 0.7 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 24.7 | +0.0 | 0.0 | 391.3 | 51.0 | +0.0 | 0.0 | 123.0 |
| TIED UP BY THE SUM | - | - | - | - | 0.3 | +7.8 | 18.3 | 0.0 |
| TIME ON OUR SIDE | 18.3 | +521.9 | 0.0 | 215.0 | 25.7 | +191.3 | 966.0 | 11.3 |
| WAITS AGAIN | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| WHO FIGHTS | - | - | - | - | 0.3 | +3.3 | 0.0 | 34.0 |
| WHOLE FIGHT DANGER | 1.7 | -28.5 | 0.0 | 21.7 | - | - | - | - |
| WOUNDS ON THE RANKS | 5.7 | +128.3 | 0.0 | 0.0 | 1.0 | +41.4 | 0.0 | 0.0 |

### Rule changes: cora-bb45c30-p25

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HOLDER ASSIGNMENT | 80 | 80 | 72 | 24.00 | +4088 | +56.8 |
| HIS SHOT LIST | 229 | 229 | 69 | 23.00 | +858 | +12.4 |
| HIS SHOTS BY HIS RUN | 198 | 198 | 60 | 20.00 | +390 | +6.5 |
| ARMY TABLE | 88 | 88 | 51 | 17.00 | +236 | +4.6 |
| SHOT RISK POINTS | 195 | 195 | 43 | 14.33 | +656 | +15.3 |
| LEGAL CHARGES ONLY | 33 | 33 | 33 | 11.00 | +0 | +0.0 |
| CASTING BLOCK | 30 | 30 | 30 | 10.00 | +1253 | +41.8 |
| DEPLOY BY FIGURES | 45 | 45 | 30 | 10.00 | +432 | +14.4 |
| TIME ON OUR SIDE | 132 | 123 | 26 | 8.67 | +346 | +13.3 |
| HARD STAY DROPPED | 23 | 23 | 23 | 7.67 | +0 | +0.0 |
| REDIRECT FOR A FRIEND IN REACH | 18 | 18 | 18 | 6.00 | +0 | +0.0 |
| THE TABLE AGAIN | 36 | 36 | 16 | 5.33 | +0 | +0.0 |
| FEATURE BUFFS | 42 | 42 | 14 | 4.67 | +216 | +15.4 |
| MEETS IN TIME | 28 | 28 | 14 | 4.67 | +257 | +18.3 |
| QUARTER ODDS | 99 | 99 | 12 | 4.00 | +514 | +42.9 |
| LONE WIZARD KEPT IN | 11 | 11 | 11 | 3.67 | +1073 | +97.5 |
| FALLS SHORT | 58 | 48 | 10 | 3.33 | +213 | +21.3 |
| FIVE ACTION | 467 | 467 | 10 | 3.33 | +610 | +61.0 |
| OFF BEST | 9 | 9 | 9 | 3.00 | -82 | -9.1 |
| STAY WORTH | 98 | 82 | 9 | 3.00 | +81 | +9.0 |
| CAST JOB | 12 | 12 | 8 | 2.67 | +35 | +4.4 |
| CASTER AWAY FROM SCREEN | 8 | 8 | 8 | 2.67 | +0 | +0.0 |
| CHAFF IN THE MOVE | 9 | 9 | 8 | 2.67 | +67 | +8.4 |
| IDLE COST | 68 | 58 | 8 | 2.67 | +83 | +10.3 |
| SHOOTS FROM THE BEST SPOT | 12 | 12 | 8 | 2.67 | +178 | +22.3 |
| GOAL WALK | 14 | 14 | 7 | 2.33 | +1298 | +185.4 |
| WOUNDS ON THE RANKS | 20 | 20 | 7 | 2.33 | +69 | +9.8 |
| MOVE ORDER | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| SCOUT WAITS | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| SUPPORT ADDS | 8 | 8 | 6 | 2.00 | +152 | +25.4 |
| SUPPORT WORKED OUT | 8 | 8 | 6 | 2.00 | +152 | +25.4 |
| ADVANCE LANE KEPT | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| CHARGE LOSSES | 70 | 70 | 5 | 1.67 | +39 | +7.7 |
| HOLDS AMBUSHERS | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| MOVE TO CHARGE COMPUTED | 5 | 5 | 5 | 1.67 | +167 | +33.4 |
| MARCH CHECK | 5 | 5 | 4 | 1.33 | +142 | +35.6 |
| ONE OBJECTIVE FORMULA | 36 | 24 | 4 | 1.33 | +162 | +40.6 |
| RANDOM MOVE BY FIGURES | 6 | 6 | 4 | 1.33 | +264 | +66.1 |
| SEARCH SPOT | 4 | 4 | 4 | 1.33 | +135 | +33.8 |
| NEXT CHARGE BY LIST | 3 | 3 | 3 | 1.00 | +78 | +26.1 |
| REDIRECT COUNTER | 11 | 9 | 3 | 1.00 | +47 | +15.6 |
| RESERVE MOVE SPELL | 3 | 3 | 3 | 1.00 | +78 | +26.2 |
| SHOTS IN THE MOVE | 63 | 40 | 3 | 1.00 | +24 | +8.0 |
| CHAFF PASSED | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| COVER ONCE | 18 | 12 | 2 | 0.67 | +2 | +1.2 |
| MARCH BY THE SUM | 2 | 2 | 2 | 0.67 | +47 | +23.7 |
| MAX FOR POSITIONING | 3 | 3 | 2 | 0.67 | +4 | +1.8 |
| MISSILES IN THE MOVE | 47 | 36 | 2 | 0.67 | +84 | +41.9 |
| MISSILES NEXT TURN | 42 | 32 | 2 | 0.67 | +58 | +29.1 |
| NEARER NOT NEEDED | 27 | 24 | 2 | 0.67 | +63 | +31.5 |
| ONE PROMISE A TARGET | 2 | 2 | 2 | 0.67 | -73 | -36.7 |
| CHALLENGE BY POINTS | 1 | 1 | 1 | 0.33 | +80 | +80.1 |
| EVASIVE BY THE ODDS | 3 | 3 | 1 | 0.33 | +4 | +4.1 |
| FIGHT TO THE END | 2 | 2 | 1 | 0.33 | +14 | +14.5 |
| FOUR ROUNDS | 5 | 5 | 1 | 0.33 | +14 | +14.5 |
| LANE BY FIGURES | 1 | 1 | 1 | 0.33 | +2 | +1.7 |
| LONG SHOT | 3 | 3 | 1 | 0.33 | +12 | +12.0 |
| MANOEUVRE | 5 | 5 | 1 | 0.33 | +32 | +32.1 |
| MOVES UNITS SPELL | 1 | 1 | 1 | 0.33 | +55 | +55.1 |
| OVERRUNS AWAY | 2 | 2 | 1 | 0.33 | +32 | +32.3 |
| SHOOTERS IN TWO RANKS | 1 | 1 | 1 | 0.33 | +1 | +1.0 |
| STRIKE BY THE ODDS | 1 | 1 | 1 | 0.33 | +10 | +10.5 |
| STUBBORN BY POINTS | 1 | 1 | 1 | 0.33 | +30 | +29.6 |
| STUCK PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| THE ROW IN ITS ORDER | 12 | 1 | 1 | 0.33 | +0 | +0.0 |
| CASTS AFTER FRIENDS | 17 | trace | - | - | - | - |
| CHARGE NOW FIRST | 2 | 2 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 49 | 49 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 17 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| EXACT ROUND | 3 | 3 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 4 | 4 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 17 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 1 | 1 | 0 | 0.00 | - | - |
| GROUND FLIERS | 1 | not checked | - | - | - | - |
| GUN FIGURES | 5 | not checked | - | - | - | - |
| HE REFORMS ONCE FREED | 1 | 1 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 31 | 31 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 18 | 18 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 25 | 25 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 22 | 22 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 14 | 14 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 26 | 26 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 28 | 28 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 5 | 5 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 1 | 1 | 0 | 0.00 | - | - |
| HIS TURN RUN | 18 | 18 | 0 | 0.00 | - | - |
| HOLD ODDS | 143 | 143 | 0 | 0.00 | - | - |
| HONEST WORTH | 4 | 4 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 9 | 9 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 3 | 3 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH WHEELS ONLY | 1 | 1 | 0 | 0.00 | - | - |
| MISSILES ON ONE TARGET | 13 | not checked | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 3 | trace | - | - | - | - |
| MOVE SPELL SPOT | 6 | not checked | - | - | - | - |
| NO DOUBLE ROUNDS | 4 | 4 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT TURNED | 1 | 1 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 14 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 4 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 15 | 12 | 0 | 0.00 | - | - |
| ONE ROUTE | 1 | 1 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 18 | 18 | 0 | 0.00 | - | - |
| OPENS A LANE | 2 | 2 | 0 | 0.00 | - | - |
| PLAN RESULT | 206 | trace | - | - | - | - |
| PROMISE BY ITS OWN SUM | 3 | 3 | 0 | 0.00 | - | - |
| PROMISE READS THE TABLE | 1 | 1 | 0 | 0.00 | - | - |
| REAL GROUND | 1 | 1 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 1 | 1 | 0 | 0.00 | - | - |
| RISK BY ARC | 4 | 4 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 1 | 1 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 1 | 1 | 0 | 0.00 | - | - |
| RUN DOWN | 4 | 4 | 0 | 0.00 | - | - |
| SCOUT SPOT | 5 | 5 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 8 | 8 | 0 | 0.00 | - | - |
| SET-UP ANY TARGET | 1 | not checked | - | - | - | - |
| SHOOTER COUNTED ONCE | 2 | 2 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 47 | not checked | - | - | - | - |
| SHOT OR CHARGE | 3 | 3 | 0 | 0.00 | - | - |
| SHOTS AFTER THE MOVES | 14 | 14 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 1 | not checked | - | - | - | - |
| SPELL WORTH | 13 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 26 | 24 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 22 | 22 | 0 | 0.00 | - | - |
| STANDS STILL | 193 | 193 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 1 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 15 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 9 | not checked | - | - | - | - |
| THE TABLE BINDS | 227 | not checked | - | - | - | - |
| TIED UP BY THE SUM | 1 | 1 | 0 | 0.00 | - | - |
| WAITS AGAIN | 2 | 2 | 0 | 0.00 | - | - |
| WHO FIGHTS | 1 | 1 | 0 | 0.00 | - | - |
| WHOLE FIGHT DANGER | 5 | 5 | 0 | 0.00 | - | - |

### Off best figure: cora-bb45c30-p25

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 1.00 | 1.67 | 10.0 |
| ARMY TABLE | rule | 1.00 | 1.00 | 82.2 |
| HOLDER ASSIGNMENT | rule | 0.67 | 1.33 | 8.0 |
| ONE PROMISE A TARGET | rule | - | 0.67 | 36.7 |
| AFTERMATH BAND | gate | 0.33 | - | 1.9 |

### Plans: cora-bb45c30-p25

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | move | 16.3 | 90% | 2081 | 0 | 0% |
| Mine | shoot | 5.3 | 69% | 981 | 296 | 30% |
| Mine | support | 0.3 | 100% | 0 | 0 | 0% |
| Opponent | charge | 1.3 | 75% | 83 | 149 | 179% |
| Opponent | move | 38.0 | 96% | 1161 | 0 | 0% |
| Opponent | shoot | 6.3 | 53% | 264 | 262 | 99% |
| Opponent | support | 1.0 | 100% | 11 | 0 | 0% |

### Battle groups: cora-bb45c30-p25

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 0.3 | 0% | - | - | - | - | - | - | - | - |
| Opponent | REDIRECT COUNTER | 3.3 | 0% | - | - | - | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: cora-bb45c30-p25

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 3 | 0 (3) | 0 | 0 | 67 | 33% | 2.0 | 0 (1) | 0 (1) | 0 (1) | 0 (2) | 0 (1) |
| Mine | Character | 18 | 18 (18) | 18 | 0 | 39 | 17% | 1.7 | - | 11 (9) | 0 (3) | 9 (6) | 8 (6) |
| Mine | Hammer | 6 | 49 (6) | 2 | 47 | 36 | 50% | 3.3 | 75 (1) | 52 (4) | 11 (1) | 40 (4) | 66 (2) |
| Mine | Holder | 3 | 91 (3) | 0 | 91 | 0 | 100% | - | - | 273 (1) | - | 273 (1) | - |
| Mine | Shooter | 6 | 54 (6) | 0 | 54 | 50 | 0% | 1.8 | - | 65 (5) | 0 (1) | 69 (4) | 23 (2) |
| Opponent | Chaff | 6 | 141 (6) | 0 | 141 | 13 | 67% | 4.0 | 0 (3) | 514 (2) | 0 (1) | 141 (6) | - |
| Opponent | Character | 8 | 47 (8) | 47 | 0 | 0 | 25% | 1.3 | 88 (4) | 0 (4) | - | 84 (4) | 0 (4) |
| Opponent | Early | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Fast Hammer | 7 | 34 (7) | 9 | 25 | 28 | 57% | 2.0 | 95 (1) | 0 (3) | 25 (3) | 29 (3) | 36 (4) |
| Opponent | Hammer | 13 | 54 (13) | 51 | 3 | 16 | 38% | 2.4 | - | 77 (8) | 0 (5) | 22 (3) | 65 (10) |
| Opponent | Holder | 1 | 321 (1) | 0 | 321 | 0 | 100% | - | - | 321 (1) | - | - | 321 (1) |
| Opponent | Shooter | 3 | 74 (3) | 0 | 74 | 62 | 67% | 1.0 | 193 (1) | 0 (2) | - | 193 (1) | 0 (2) |
| Opponent | Wizard | 2 | 0 (2) | 0 | 0 | 0 | 100% | - | - | 0 (2) | - | 0 (2) | - |

### Charged fights: cora-bb45c30-p25

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 3 | 178 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Beastmen Brayherds | 1 | 0 | 55 | 1.0 | 1.0 | 55 | 0 | +55 | 0 of 1 | 1 of 1 | - | +55 |
| Opponent | Ogre Kingdoms | 1 | 0 | 807 | 2.0 | 1.0 | 404 | 17 | +386 | 2 of 2 | 1 of 2 | - | +386 |
| Opponent | Wood Elf Realms | 1 | 0 | 1072 | 3.0 | 1.0 | 357 | 34 | +323 | 2 of 3 | 2 of 3 | - | +323 |
| **Opponent** | all armies | 3 | 0 | 645 | 2.0 | 1.0 | 322 | 23 | +300 | 4 of 6 | 4 of 6 | - | +300 |

### Effective charges: cora-bb45c30-p25

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | Beastmen Brayherds | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +55) | 0 | 0% (0 of 1) |
| Opponent | Ogre Kingdoms | 2 | 0 | 0 | 0 | 0 | 0 | 1 (net +807) | 1 | 0% (0 of 1) |
| Opponent | Wood Elf Realms | 3 | 0 | 0 | 1 (net +478) | 0 | 0 | 2 (net +246) | 0 | 33% (1 of 3) |

### Charged fights, damage counted: cora-bb45c30-p25

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | Effective (55-75%) | 1 | 102 | 322 | +478 | 580 | 142 | +438 | +429.9 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 4 | 234 | 188 | +338 | 352 | 38 | +314 | +134.2 |
| Opponent | No odds | 1 | 34 | 836 | -34 | 0 | 34 | -34 | -100.0 |
| Opponent | All fights | 6 | 179 | 319 | +300 | 332 | 55 | +277 | +154.9 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| cora-bb45c30-p25 | move | 6 | 1 (17%) | 1 (17%) | 1 (17%) | 4 (67%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0102, L0118, L0135 |
| Fistful of Laurels | Opponent | L0118 |
| Ring of Doom | Opponent | L0102 |

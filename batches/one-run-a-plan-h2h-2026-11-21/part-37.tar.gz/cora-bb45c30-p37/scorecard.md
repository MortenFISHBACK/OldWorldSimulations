# Doctrine scorecard: cora-bb45c30-p37

### Scorecard: cora-bb45c30-p37

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0106 | 4 | 1 | Mine | no | 5 | - | 0 | 1 | 0 | 0 | 0 | 0 |
| L0106 | 4 | 1 | Opponent | no | 0 | 5 | 0 | 1 | 0 | 0 | 0 | 944 |
| L0122 | 2 | 1 | Mine | - | - | - | 0 | 3 | 1 | 0 | 0 | 0 |
| L0122 | 2 | 1 | Opponent | - | - | 2 | 2 | 3 | 0 | 0 | 0 | 0 |
| L0206 | 2 | 1 | Mine | - | - | - | 0 | 5 | 0 | 0 | 0 | 441 |
| L0206 | 2 | 1 | Opponent | - | - | 3 | 0 | 0 | 0 | 0 | 0 | 663 |
| **Average** | | | Mine | 0% | 5.0 | - | 0.0 | 3.0 | 0.3 | 0.0 | 0.0 | 147.0 |
| **Average** | | | Opponent | 0% | 0.0 | 3.3 | 0.7 | 1.3 | 0.0 | 0.0 | 0.0 | 535.7 |

### KPIs: cora-bb45c30-p37

Rules off - Opponent only: ONE RUN A PLAN.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 10) | 69% (11 of 16) | 42% (11 of 26) |
| Winner chose to follow up after the loser gave ground |  | 67% (2 of 3); on the table 67% | 100% (1 of 1); on the table 100% | 75% (3 of 4); on the table 75% |
| Winner chose to pursue after the loser fell back in good order |  | - | 100% (2 of 2); on the table 100% | 100% (2 of 2); on the table 100% |
| Winner chose to pursue after the loser fled |  | - | 100% (1 of 1); on the table 100% | 100% (1 of 1); on the table 100% |
| Winner chose to follow up or pursue (all three) |  | 67% (2 of 3); on the table 67% | 100% (4 of 4); on the table 100% | 86% (6 of 7); on the table 86% |
| Magic missiles tried each own turn | 50%+ | 51% (46 of 90) | - | 51% (46 of 90) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 64% (46 of 72) | - | 64% (46 of 72) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 83% (5 of 6) | - | 83% (5 of 6) |
| Points that never fought | lower | 47% (2651 of 5699) | 76% (4551 of 6000) | 62% (7202 of 11699) |
|   infantry points that never fought | lower | 56% (1263 of 2239) | 86% (1811 of 2111) | 71% (3074 of 4350) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 38% (6 of 16) | 72% (18 of 25) | 59% (24 of 41) |
| Bound items with a magic missile used (at least once a game) |  | 100% (4 of 4); 4.0 uses a game | 0.0 uses a game | 100% (4 of 4); 2.0 uses a game |
| Bound items with another spell used |  | 50% (1 of 2); 1.3 uses a game | 0.0 uses a game | 50% (1 of 2); 0.7 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 100% (4 of 4); 1.3 uses a game | 0.0 uses a game | 100% (4 of 4); 0.7 uses a game |
|   their share of the points of units over 100 pts | lower | 35% (1389 of 3916) | 68% (3000 of 4382) | 53% (4389 of 8298) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 4.7 (32%) | - | 4.7 (32%) |
| MARCHED: its unit marched | 4.0 (27%) | - | 4.0 (27%) |
| IN COMBAT: engaged in combat | 4.3 (30%) | - | 4.3 (30%) |
| GONE: slain | 1.7 (11%) | - | 1.7 (11%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.3 | 0.3 | 5.7 | 15.3 | 0.3 | 2.0 |
| not cast | 1.7 | 3.7 | 4.3 | 14.7 | 1.7 | 26.0 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (1%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 2.3 (64%) | 0.0 (0%) | 4.7 (32%) | 1.3 (80%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 4.0 (27%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 1.0 (27%) | 2.3 (54%) | 4.3 (30%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | 0.0 (0%) | 0.3 (9%) | 0.7 (15%) | 1.7 (11%) | 0.0 (0%) | 1.7 (6%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (20%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.7 (100%) | 0.0 (0%) | 1.3 (31%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 24.0 (92%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 7.0 a game | 0.0 a game | 3.5 a game |
| stood (cast and not dispelled) | 76% (16 of 21) | - | 76% (16 of 21) |
| the unit moved after it | 50% (8 of 16) | - | 50% (8 of 16) |
| it charged on its next turn | 0% (0 of 16) | - | 0% (0 of 16) |
| the enemy charged it first | 19% (3 of 16) | - | 19% (3 of 16) |
| it fought by the end of its next turn | 12% (2 of 16) | - | 12% (2 of 16) |
| it moved out of a charge the enemy had planned (not charged first) | 6% (1 of 16) | - | 6% (1 of 16) |
| none of these (no charge, no fight, no charge escaped) | 75% (12 of 16) | - | 75% (12 of 16) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 45% (9 of 20) | 61% (115 of 190) | 59% (124 of 210) |
|   cavalry | - | 54% (14 of 26) | 54% (14 of 26) |
|   character | - | 57% (12 of 21) | 57% (12 of 21) |
|   chariot | - | 0% (0 of 1) | 0% (0 of 1) |
|   infantry | 45% (9 of 20) | 57% (38 of 67) | 54% (47 of 87) |
|   monster | - | 82% (9 of 11) | 82% (9 of 11) |
|   war machine | - | 66% (42 of 64) | 66% (42 of 64) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.7 (73%) | 1.0 (4%) | 3.7 (13%) |
| CHARGED: it charged | 0.0 (0%) | 2.0 (8%) | 2.0 (7%) |
| NO TARGET IN RANGE | 0.7 (18%) | 10.0 (40%) | 10.7 (37%) |
| ONLY IN COMBAT: the only targets were in combat | 0.0 (0%) | 2.7 (11%) | 2.7 (9%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.3 (9%) | 4.3 (17%) | 4.7 (16%) |
| SHELTERED: the target was sheltered | 0.0 (0%) | 1.0 (4%) | 1.0 (3%) |
| OTHER BAR | 0.0 (0%) | 4.0 (16%) | 4.0 (14%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 6.0 | 2.7 | 67% | 5.8 pts | 35 pts |
| character | 4.0 | 5.0 | 33% | 10.7 pts | 43 pts |
| infantry | 23.7 | 9.0 | 69% | 3.7 pts | 88 pts |
| monster | 3.0 | 2.0 | 56% | 5.5 pts | 16 pts |
| war machine | 14.0 | 12.7 | 64% | 8.6 pts | 121 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 0.0 | 3.0 | 1.5 |
| Charges that made contact a game | 0.0 | 2.3 | 1.2 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | - | - | - |
|   per unit a game, units carrying another wizard (or one alone) | - | - | - |
|   per unit a game, the other units (no war machines, no joined characters) | 0.00 declared, 0.00 contact (20 units) | 0.33 declared, 0.26 contact (27 units) | 0.19 declared, 0.15 contact (47 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Character in a unit | 67% (2 of 3) | 33% (1 of 3) | - | 50% (3 of 6) |
| Character on its own | 33% (1 of 3) | 33% (1 of 3) | 50% (1 of 2) | 38% (3 of 8) |
| Infantry | 43% (3 of 7) | 57% (4 of 7) | - | 50% (7 of 14) |
| Monster | 80% (4 of 5) | - | - | 80% (4 of 5) |
| War Machines | 88% (7 of 8) | - | - | 88% (7 of 8) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 3 | 67% (2 of 3); on the table 67% | 51% (46 of 90) | 47% | 38% (6 of 16) | 100% (4 of 4); 4.0 uses a game | 50% (1 of 2); 1.3 uses a game | 100% (4 of 4); 1.3 uses a game |
| Dwarfen Mountain Holds | 2 | 100% (1 of 1); on the table 100% | - | 79% | 70% (14 of 20) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Tomb Kings of Khemri | 1 | 100% (3 of 3); on the table 100% | - | 70% | 80% (4 of 5) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (cora-bb45c30-p37, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 0% (0) | - | 0% (0) |
| ...free all their last turn and able to turn (per game) | 0.00 | 0.00 | 0.00 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.00 | 0.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: cora-bb45c30-p37

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 0.7 | 0.7 |
| Strategy | Charge objectives carried out (made contact) | - | 29% (2 of 7) |
| Strategy | Shoot objectives carried out (shot that target) | 40% (4 of 10) | 41% (32 of 78) |
| Strategy | Support requests answered (helper made contact too) | - | 33% (1 of 3) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (1 of 1) | - |
| Strategy | Joined characters whose unit fought | 33% (3 of 9) | 14% (1 of 7) |
| Strategy | Lone characters that fought | 89% (8 of 9) | 67% (2 of 3) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 3.0 | 1.3 |
| Movement | Points that never moved of their own | 147.0 | 535.7 |
| Movement | Fights charged into per game | 0.0 | 1.7 |
| Movement | Charges with odds: long shots (under 50%) | - | 4 of 4, net +150 |
| Movement | Charges with odds: sweet spot (55-75%) | - | 0 of 4 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | - | 0 of 4 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | - | 0 of 4 |
| Shooting | Shots by shooting units (incl. breath weapons) | 3.0 | 26.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 0% (0 of 9) | 51% (40 of 78) |
| Shooting | Points destroyed by shooting units | 24.0 | 181.7 |
| Shooting | War machine shots | - | 14.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | - | 69% (29 of 42) |
| Shooting | Points destroyed by war machines | 0.0 | 10.0 |
| Magic | Magic missiles cast | 9.3 | - |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 36% (10 of 28) | - |
| Magic | Wounds caused by magic missiles | 14.0 | - |
| Magic | Points destroyed by magic (all spells) | 124.7 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.3 / 0.0 / 1.3 / 0.3 | 3.3 / 0.0 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 136.7 | 43.3 |
| Combat | Points run down | 0.0 | 302.3 |
| Combat | Net points per charged fight, damage counted | - | +198 |
| Combat | Net per 100 charger points, damage counted | - | +84.1 |
| Combat | First round won (charged fights) | - | 20% |
| Combat | Net points per charged fight | - | +120 |
| Combat | Net points per supported fight / lone fight | - / - | -175 / +317 |
| Combat | Charged fights on a top-3 enemy unit | - | 3 of 5 |
| Game | Points lost | 509.0 | 343.7 |
| Game | VP from objectives | 663.3 | 726.7 |
| Game | Lone holders (player turns) | 5.0 | 0.0 |

- Mine won / drew / lost: 1 / 1 / 1 of 3 ended games (of 3); mean margin (Mine - Opponent) -344 VP
- The side that went first won 0 of 2 games with a winner
- Points traded per game (both sides' losses): 853
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: cora-bb45c30-p37

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.3 | +174.0 | 0.0 | 90.7 | - | - | - | - |
| ARMY TABLE | 15.0 | +78.3 | 0.0 | 283.3 | 17.0 | +238.7 | 0.0 | 24.0 |
| ASSAILMENT BY POINTS | 0.3 | +1.9 | 0.0 | 0.0 | - | - | - | - |
| BACKUP TARGETS | 0.3 | +1.3 | 0.0 | 0.0 | - | - | - | - |
| BEST PRIZE | - | - | - | - | 0.3 | +2.2 | 10.0 | 0.0 |
| BOMBING RUN | - | - | - | - | 0.3 | +3.0 | 10.0 | 0.0 |
| CANNON PLAN MISSED | - | - | - | - | 0.7 | +0.0 | 90.7 | 0.0 |
| CANNON PLANNED TARGET | - | - | - | - | 14.0 | +180.5 | 446.7 | 186.7 |
| CANNON SIGHT KEPT | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| CASTER AWAY FROM SCREEN | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CASTING BLOCK | 2.7 | +195.3 | 96.0 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | 5.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CATCH FLIERS | 0.3 | +8.0 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | 0.7 | +6.7 | 0.0 | 0.0 | 0.3 | +1.5 | 0.0 | 24.0 |
| CHAFF PASSED | - | - | - | - | 2.7 | +0.0 | 0.0 | 48.0 |
| CHALLENGE BY POINTS | 0.7 | +40.1 | 0.0 | 124.0 | - | - | - | - |
| CHARACTER GUNS | - | - | - | - | 6.7 | +0.0 | 0.0 | 0.0 |
| CHARGE LOSSES | 21.7 | -1027.4 | 0.0 | 432.0 | 10.7 | -542.8 | 0.0 | 38.3 |
| CHARGE NOW FIRST | - | - | - | - | 1.3 | +0.0 | 132.3 | 20.0 |
| CLOSES ON WHAT IT BEATS | 8.7 | +0.0 | 0.0 | 66.7 | 6.7 | +0.0 | 0.0 | 70.0 |
| CONVEYANCE SEARCH | 4.7 | +922.1 | 181.3 | 0.0 | - | - | - | - |
| COVER ONCE | 5.0 | -242.9 | 0.0 | 21.7 | 7.0 | -189.6 | 0.0 | 20.0 |
| DEFENSIVE ARMY | - | - | - | - | 1.0 | +0.0 | 272.0 | 0.0 |
| DENIED BY THE FIGHT | - | - | - | - | 1.0 | -28.7 | 112.3 | 0.0 |
| DEPLOY BY FIGURES | 6.7 | +87.5 | 0.0 | 0.0 | 12.3 | -197.3 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | - | - | - | - | 0.3 | -184.5 | 0.0 | 0.0 |
| EXACT ROUND | - | - | - | - | 1.3 | -3.4 | 50.0 | 35.0 |
| FALL BACK GOOD ORDER | - | - | - | - | 2.3 | +0.0 | 140.7 | 35.0 |
| FALLS SHORT | 16.0 | +429.5 | 0.0 | 301.0 | 10.7 | +88.2 | 0.0 | 48.0 |
| FEATURE BUFFS | 12.3 | +317.9 | 0.0 | 119.7 | 1.3 | +20.7 | 0.0 | 0.0 |
| FIGHT TO THE END | - | - | - | - | 0.7 | +47.0 | 0.0 | 0.0 |
| FIRE IN ORDER | - | - | - | - | 1.0 | +0.0 | 28.3 | 0.0 |
| FIVE ACTION | 62.7 | +6664.7 | 144.0 | 923.3 | 138.3 | +4653.4 | 2357.0 | 879.0 |
| FLANK NOT WEIGHED | 3.3 | +0.0 | 0.0 | 184.7 | 4.0 | +0.0 | 0.0 | 0.0 |
| FOLLOW UP WEIGHED | 0.3 | +61.8 | 0.0 | 0.0 | - | - | - | - |
| FOUR ROUNDS | - | - | - | - | 3.0 | +385.3 | 259.7 | 55.0 |
| FREED FROM HIS FIGHT | 2.3 | +0.0 | 0.0 | 76.7 | 1.3 | +0.0 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | - | - | - | - | 0.7 | -14.7 | 0.0 | 0.0 |
| FRIENDS SHOTS CHECKED | - | - | - | - | 0.3 | +94.7 | 0.0 | 0.0 |
| GIVES UP | - | - | - | - | 0.3 | -3.8 | 0.0 | 0.0 |
| GOAL WALK | 13.3 | +2394.2 | 0.0 | 296.0 | - | - | - | - |
| GUN FIGURES | - | - | - | - | 1.0 | +0.0 | 0.0 | 40.0 |
| HARD STAY DROPPED | 0.3 | +0.0 | 0.0 | 0.0 | 6.7 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 1.3 | +0.0 | 0.0 | 66.7 | 0.7 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 14.0 | +0.0 | 0.0 | 397.3 | 6.0 | +0.0 | 0.0 | 38.3 |
| HIS CHARGE DENIED | - | - | - | - | 1.0 | +12.4 | 56.7 | 0.0 |
| HIS CHARGE LIST | 13.0 | +0.0 | 0.0 | 86.7 | 5.0 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 4.0 | +0.0 | 0.0 | 28.3 | 0.3 | +0.0 | 0.0 | 24.0 |
| HIS MOVE AND SHOT | 7.3 | -30.6 | 0.0 | 133.3 | 1.7 | -63.6 | 0.0 | 0.0 |
| HIS ONE QUARTER | - | - | - | - | 3.7 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 4.7 | +0.0 | 0.0 | 28.3 | 2.3 | +0.0 | 0.0 | 24.0 |
| HIS RANDOM MOVE | - | - | - | - | 11.0 | +0.0 | 0.0 | 80.0 |
| HIS RANDOM MOVER COMES | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 50.3 | +1408.2 | 0.0 | 880.0 | 57.7 | +2725.7 | 0.0 | 284.3 |
| HIS SHOTS BY HIS RUN | 41.0 | +624.6 | 0.0 | 823.3 | 40.0 | +1076.3 | 0.0 | 292.3 |
| HIS TURN DENIED | - | - | - | - | 1.7 | +138.0 | 203.0 | 55.0 |
| HIS TURN RUN | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 33.7 | +0.0 | 0.0 | 582.0 | 14.3 | +0.0 | 0.0 | 0.0 |
| HOLDER ASSIGNMENT | 12.3 | +1264.2 | 0.0 | 213.0 | 9.3 | +1419.5 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | - | - | - | - | 1.3 | -86.3 | 50.0 | 0.0 |
| HUNT IN PAIRS | - | - | - | - | 3.0 | +286.2 | 0.0 | 0.0 |
| IDLE COST | 10.0 | -70.6 | 0.0 | 220.0 | 2.7 | -58.7 | 0.0 | 24.0 |
| JOINT CHARGE NOW | - | - | - | - | 2.0 | +101.9 | 238.0 | 55.0 |
| JOINT KNOWS CHALLENGE | - | - | - | - | 0.3 | -16.4 | 90.7 | 0.0 |
| KEEPS SCOUTS OR AMBUSH | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| KEPT FROM ITS LAST STOP | 4.0 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | - | - | - | - | 0.7 | +18.2 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| LEGAL CHARGES ONLY | 7.3 | +0.0 | 96.0 | 200.7 | 6.7 | +0.0 | 575.0 | 144.0 |
| LONE WIZARD KEPT IN | 2.7 | +247.6 | 0.0 | 0.0 | 0.7 | +60.4 | 0.0 | 0.0 |
| LONG SHOT | - | - | - | - | 0.7 | -10.6 | 119.0 | 0.0 |
| LOST AFTER ESCAPE | - | - | - | - | 1.3 | -0.4 | 119.0 | 35.0 |
| MANOEUVRE | 0.3 | +0.0 | 0.0 | 0.0 | 1.3 | -9.1 | 0.0 | 0.0 |
| MARCH BY THE SUM | 1.7 | +107.3 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | 0.7 | +14.4 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 1.7 | -202.4 | 0.0 | 0.0 | - | - | - | - |
| MARCH WHEELS ONLY | 0.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 3.3 | +61.6 | 0.0 | 93.7 | 2.3 | +64.9 | 0.0 | 0.0 |
| MEETS IN TIME | 3.0 | +105.1 | 0.0 | 0.0 | 7.7 | +68.6 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 7.3 | +352.6 | 0.0 | 235.3 | - | - | - | - |
| MISSILES NEXT TURN | 8.3 | +268.5 | 0.0 | 144.7 | - | - | - | - |
| MISSILES ON ONE TARGET | 2.3 | -66.0 | 0.0 | 181.3 | - | - | - | - |
| MODEL FACING | - | - | - | - | 4.3 | +1384.8 | 0.0 | 40.0 |
| MOVE ORDER | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL NOT WORTH | 0.3 | -0.2 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.7 | -2.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL SPOT | 2.7 | +0.0 | 0.0 | 181.3 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 2.0 | +136.2 | 0.0 | 0.0 | 4.3 | +246.2 | 0.0 | 0.0 |
| MOVES UNITS SPELL | 0.3 | +18.4 | 0.0 | 0.0 | - | - | - | - |
| NEARER NOT NEEDED | 3.7 | +141.6 | 0.0 | 21.7 | 10.7 | +433.8 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 1.3 | +130.8 | 0.0 | 0.0 | 2.7 | +206.7 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | - | - | - | - | 3.0 | -108.9 | 259.7 | 55.0 |
| NO LATE CUT | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OFF BEST | 2.7 | -108.0 | 0.0 | 37.0 | 7.7 | -253.2 | 0.0 | 70.0 |
| ONE CHECK AFTER THE LAST CHANGE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ONE FIGHT FORMULA | 6.0 | -121.7 | 0.0 | 147.3 | 5.7 | -91.3 | 0.0 | 0.0 |
| ONE JOINT FIGURE | - | - | - | - | 0.7 | -113.6 | 0.0 | 35.0 |
| ONE OBJECTIVE FORMULA | 6.7 | +8.2 | 0.0 | 213.0 | 3.7 | -14.9 | 0.0 | 0.0 |
| ONE PROMISE A TARGET | - | - | - | - | 0.3 | +24.2 | 0.0 | 0.0 |
| ONE ROUTE | 0.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PATHS CROSS | 0.3 | +2.4 | 0.0 | 0.0 | - | - | - | - |
| PLAN RESULT | 27.3 | +32.0 | 24.0 | 437.7 | 60.7 | +880.9 | 750.0 | 573.3 |
| PROMISE BELOW ZERO | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE BY ITS OWN SUM | 2.7 | -5.5 | 0.0 | 0.0 | 8.7 | -88.3 | 0.0 | 40.0 |
| PROMISE KNOWS THE FIGHT | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| QUARTER ODDS | 6.0 | +1102.7 | 0.0 | 0.0 | 15.3 | +960.1 | 0.0 | 175.0 |
| RANDOM MOVE BY FIGURES | 2.0 | +25.0 | 0.0 | 0.0 | - | - | - | - |
| REAL GROUND | 0.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | 2.0 | +46.5 | 0.0 | 48.3 | 2.3 | +75.7 | 0.0 | 72.0 |
| REDIRECT FOR A FRIEND IN REACH | 2.3 | +0.0 | 0.0 | 110.7 | 1.0 | +0.0 | 0.0 | 48.0 |
| REDIRECT WEIGHED | - | - | - | - | 0.3 | +2.2 | 10.0 | 0.0 |
| REFORMS TO MEET IT | 0.7 | -1.7 | 0.0 | 0.0 | 0.3 | -13.8 | 0.0 | 0.0 |
| REFUSING RETIRES | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | 0.3 | +2.7 | 0.0 | 0.0 | 1.0 | +11.9 | 0.0 | 24.0 |
| RESERVE MOVE SPELL | 1.3 | +19.2 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | - | - | - | - | 1.7 | +17.4 | 50.0 | 35.0 |
| RISK ON THE WAY | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ROUNDS AFTER TERROR | - | - | - | - | 0.7 | -10.0 | 21.7 | 0.0 |
| RUN DOWN | - | - | - | - | 2.0 | -15.6 | 169.0 | 0.0 |
| SCOUT SPOT | 0.7 | +0.4 | 0.0 | 0.0 | 0.7 | -0.1 | 0.0 | 0.0 |
| SCOUT WAITS | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| SEARCH SPOT | 0.3 | +2.3 | 0.0 | 0.0 | 0.7 | +15.7 | 0.0 | 0.0 |
| SECOND LOOK | - | - | - | - | 0.3 | +6.1 | 0.0 | 35.0 |
| SET CREDITED ONCE | - | - | - | - | 4.3 | -563.6 | 0.0 | 0.0 |
| SET UP BY THE SET | - | - | - | - | 5.7 | +577.6 | 21.7 | 24.0 |
| SET-UP MISSED | 0.3 | +23.8 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | - | - | - | - | 1.7 | +4.0 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 3.0 | +0.0 | 0.0 | 21.7 | 25.0 | +0.0 | 0.0 | 186.7 |
| SHOOTS FROM THE BEST SPOT | 1.3 | +58.9 | 0.0 | 0.0 | 3.3 | +46.0 | 20.0 | 0.0 |
| SHORT GUN FORWARD | - | - | - | - | 2.0 | +0.0 | 0.0 | 0.0 |
| SHOT OR CHARGE | - | - | - | - | 1.3 | -31.8 | 209.7 | 0.0 |
| SHOT RISK POINTS | 34.0 | -306.3 | 0.0 | 508.7 | 41.0 | +916.4 | 0.0 | 362.7 |
| SHOTS AFTER THE MOVES | 1.3 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 3.3 | +107.9 | 0.0 | 21.7 | 44.3 | +930.7 | 0.0 | 325.7 |
| SPELL SETS UP CHARGE | 0.7 | +314.7 | 0.0 | 0.0 | - | - | - | - |
| SPELL WORTH | 0.7 | +4.4 | 0.0 | 0.0 | - | - | - | - |
| SPOT AS THE GAME MOVES | 6.0 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| STAND AND SHOOT | - | - | - | - | 0.3 | -1.6 | 21.7 | 0.0 |
| STANDS FOR A REASON | 0.7 | +0.0 | 0.0 | 54.0 | 4.0 | +0.0 | 0.0 | 48.0 |
| STANDS STILL | 15.7 | +0.0 | 144.0 | 116.7 | 97.0 | +0.0 | 2097.3 | 658.0 |
| STAY WORTH | 2.3 | +17.5 | 0.0 | 0.0 | 62.0 | -323.5 | 969.3 | 360.0 |
| STRIKE BY THE ODDS | 0.3 | +35.6 | 61.7 | 0.0 | 1.0 | +6.3 | 181.3 | 20.0 |
| SUPPORT ADDS | 6.0 | +354.1 | 0.0 | 102.3 | 2.0 | +14.3 | 0.0 | 0.0 |
| SUPPORT NARROWED | - | - | - | - | 0.3 | +0.0 | 90.7 | 20.0 |
| SUPPORT WORKED OUT | 6.0 | +354.1 | 0.0 | 102.3 | 2.0 | +14.3 | 0.0 | 0.0 |
| SURE REACH TOGETHER | 0.3 | +0.7 | 0.0 | 0.0 | 0.3 | +0.8 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 1.3 | +0.0 | 0.0 | 28.3 | 1.3 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 1.7 | +0.0 | 0.0 | 28.3 | 0.7 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 2.0 | +0.0 | 0.0 | 117.7 | 0.7 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 1.7 | +0.0 | 0.0 | 117.7 | 0.7 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 29.7 | +0.0 | 0.0 | 371.0 | 61.7 | +0.0 | 0.0 | 333.7 |
| TIED UP BY THE SUM | - | - | - | - | 0.3 | +31.6 | 21.7 | 0.0 |
| TIME ON OUR SIDE | 6.7 | +154.4 | 0.0 | 95.0 | 52.3 | +443.0 | 0.0 | 99.0 |
| WAITS AGAIN | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | 4.7 | -513.3 | 0.0 | 362.7 | 3.0 | -332.7 | 0.0 | 0.0 |
| WHOLE FIGHT GAIN | - | - | - | - | 0.3 | +18.0 | 90.7 | 0.0 |
| WOUNDS ON THE RANKS | 8.0 | +735.8 | 0.0 | 181.3 | 1.3 | +18.1 | 0.0 | 0.0 |

### Rule changes: cora-bb45c30-p37

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS SHOT LIST | 324 | 316 | 81 | 27.00 | +1231 | +15.2 |
| HIS SHOTS BY HIS RUN | 243 | 235 | 64 | 21.33 | +852 | +13.3 |
| HOLDER ASSIGNMENT | 65 | 65 | 63 | 21.00 | +3770 | +59.8 |
| ARMY TABLE | 96 | 96 | 60 | 20.00 | +953 | +15.9 |
| SHOT RISK POINTS | 225 | 216 | 50 | 16.67 | +888 | +17.8 |
| LEGAL CHARGES ONLY | 42 | 42 | 42 | 14.00 | +0 | +0.0 |
| DEPLOY BY FIGURES | 57 | 57 | 34 | 11.33 | +500 | +14.7 |
| OFF BEST | 31 | 31 | 31 | 10.33 | -1083 | -34.9 |
| TIME ON OUR SIDE | 177 | 165 | 28 | 9.33 | +91 | +3.3 |
| FIVE ACTION | 603 | 592 | 23 | 7.67 | +1071 | +46.5 |
| GOAL WALK | 40 | 40 | 23 | 7.67 | +3782 | +164.4 |
| HARD STAY DROPPED | 21 | 21 | 21 | 7.00 | +0 | +0.0 |
| THE TABLE AGAIN | 36 | 36 | 20 | 6.67 | +0 | +0.0 |
| WOUNDS ON THE RANKS | 28 | 28 | 15 | 5.00 | +622 | +41.5 |
| MODEL FACING | 13 | 13 | 13 | 4.33 | +4154 | +319.6 |
| PROMISE BY ITS OWN SUM | 34 | 34 | 13 | 4.33 | -281 | -21.6 |
| CHARGE LOSSES | 97 | 94 | 12 | 4.00 | +2333 | +194.5 |
| MEETS IN TIME | 32 | 32 | 12 | 4.00 | +122 | +10.1 |
| SHOOTS FROM THE BEST SPOT | 14 | 14 | 11 | 3.67 | +29 | +2.6 |
| CANNON PLANNED TARGET | 42 | 42 | 10 | 3.33 | -21 | -2.1 |
| LONE WIZARD KEPT IN | 10 | 10 | 10 | 3.33 | +924 | +92.4 |
| REDIRECT FOR A FRIEND IN REACH | 10 | 10 | 10 | 3.33 | +0 | +0.0 |
| CHAFF PASSED | 8 | 8 | 8 | 2.67 | +0 | +0.0 |
| ADVANCE LANE KEPT | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| FALLS SHORT | 80 | 61 | 7 | 2.33 | +39 | +5.6 |
| MOVE TO CHARGE COMPUTED | 19 | 15 | 7 | 2.33 | +226 | +32.3 |
| CASTING BLOCK | 8 | 8 | 6 | 2.00 | +32 | +5.4 |
| JOINT CHARGE NOW | 6 | 6 | 6 | 2.00 | +306 | +51.0 |
| MAX FOR POSITIONING | 17 | 16 | 6 | 2.00 | +36 | +6.0 |
| SHORT GUN FORWARD | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| SHOTS IN THE MOVE | 143 | 116 | 6 | 2.00 | +102 | +17.0 |
| SUPPORT ADDS | 24 | 24 | 6 | 2.00 | +205 | +34.1 |
| SUPPORT WORKED OUT | 24 | 24 | 6 | 2.00 | +205 | +34.1 |
| CASTER AWAY FROM SCREEN | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| FEATURE BUFFS | 41 | 41 | 5 | 1.67 | +61 | +12.3 |
| FOUR ROUNDS | 9 | 8 | 5 | 1.67 | +505 | +101.0 |
| MARCH BY THE SUM | 5 | 5 | 5 | 1.67 | +322 | +64.4 |
| MISSILES IN THE MOVE | 22 | 15 | 5 | 1.67 | +222 | +44.4 |
| NEXT CHARGE BY LIST | 12 | 11 | 5 | 1.67 | +222 | +44.3 |
| QUARTER ODDS | 64 | 63 | 5 | 1.67 | +115 | +23.0 |
| RANDOM MOVE BY FIGURES | 6 | 6 | 5 | 1.67 | +75 | +15.0 |
| SHOOTERS IN TWO RANKS | 5 | 5 | 5 | 1.67 | +12 | +2.4 |
| COVER ONCE | 36 | 28 | 4 | 1.33 | +31 | +7.7 |
| HOLDS AMBUSHERS | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| IDLE COST | 38 | 23 | 4 | 1.33 | +44 | +10.9 |
| RESERVE FALL BACK | 4 | 4 | 4 | 1.33 | +44 | +10.9 |
| RESERVE MOVE SPELL | 4 | 4 | 4 | 1.33 | +58 | +14.4 |
| SCOUT WAITS | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| SET UP BY THE SET | 17 | 17 | 4 | 1.33 | +180 | +45.1 |
| STRIKE BY THE ODDS | 4 | 4 | 4 | 1.33 | +125 | +31.4 |
| CANNON SIGHT KEPT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| FIRE IN ORDER | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| SEARCH SPOT | 3 | 3 | 3 | 1.00 | +54 | +18.0 |
| CHALLENGE BY POINTS | 2 | 2 | 2 | 0.67 | +120 | +60.0 |
| HIS MOVE AND SHOT | 27 | 27 | 2 | 0.67 | +0 | +0.0 |
| HIS TURN DENIED | 5 | 4 | 2 | 0.67 | +247 | +123.7 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| LANE BY FIGURES | 2 | 2 | 2 | 0.67 | +55 | +27.4 |
| REDIRECT COUNTER | 13 | 9 | 2 | 0.67 | +66 | +33.0 |
| RISK BY ARC | 5 | 4 | 2 | 0.67 | +32 | +15.8 |
| SHOTS AFTER THE MOVES | 17 | 17 | 2 | 0.67 | +0 | +0.0 |
| STAY WORTH | 193 | 182 | 2 | 0.67 | +2 | +1.1 |
| SURE REACH TOGETHER | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| AFTERMATH IN POINTS | 1 | 1 | 1 | 0.33 | +522 | +522.1 |
| ASSAILMENT BY POINTS | 1 | 1 | 1 | 0.33 | +6 | +5.6 |
| BEST PRIZE | 1 | 1 | 1 | 0.33 | -3 | -2.8 |
| BOMBING RUN | 1 | 1 | 1 | 0.33 | +9 | +9.0 |
| CHARGE NOW FIRST | 4 | 4 | 1 | 0.33 | -21 | -21.3 |
| FOLLOW UP WEIGHED | 1 | 1 | 1 | 0.33 | +185 | +185.4 |
| FRIENDS SHOTS CHECKED | 1 | 1 | 1 | 0.33 | +284 | +284.2 |
| HIS CHARGE DENIED | 3 | 3 | 1 | 0.33 | +11 | +11.1 |
| MISSILES NEXT TURN | 25 | 17 | 1 | 0.33 | +32 | +31.9 |
| MOVE ORDER | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| MOVES UNITS SPELL | 1 | 1 | 1 | 0.33 | +55 | +55.1 |
| ONE FIGHT FORMULA | 35 | 25 | 1 | 0.33 | +0 | +0.0 |
| ONE OBJECTIVE FORMULA | 31 | 22 | 1 | 0.33 | +71 | +70.9 |
| ONE PROMISE A TARGET | 1 | 1 | 1 | 0.33 | +73 | +72.6 |
| PATHS CROSS | 1 | 1 | 1 | 0.33 | +7 | +7.1 |
| REDIRECT WEIGHED | 1 | 1 | 1 | 0.33 | -3 | -2.8 |
| REFUSING RETIRES | 1 | 1 | 1 | 0.33 | +20 | +20.1 |
| SECOND LOOK | 1 | 1 | 1 | 0.33 | +18 | +18.2 |
| SUPPORT NARROWED | 1 | 1 | 1 | 0.33 | -5 | -4.7 |
| THE ROW IN ITS ORDER | 7 | 1 | 1 | 0.33 | +0 | +0.0 |
| TIED UP BY THE SUM | 1 | 1 | 1 | 0.33 | +20 | +19.8 |
| BACKUP TARGETS | 1 | not checked | - | - | - | - |
| CANNON PLAN MISSED | 2 | 2 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 16 | trace | - | - | - | - |
| CATCH FLIERS | 1 | not checked | - | - | - | - |
| CHAFF IN THE MOVE | 3 | 2 | 0 | 0.00 | - | - |
| CHARACTER GUNS | 20 | 20 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 46 | 46 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 14 | not checked | - | - | - | - |
| DEFENSIVE ARMY | 3 | 3 | 0 | 0.00 | - | - |
| DENIED BY THE FIGHT | 3 | 3 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 1 | 1 | 0 | 0.00 | - | - |
| EXACT ROUND | 4 | 3 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 7 | 6 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 2 | 2 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 22 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 11 | 11 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 2 | 2 | 0 | 0.00 | - | - |
| GIVES UP | 1 | 1 | 0 | 0.00 | - | - |
| GUN FIGURES | 3 | not checked | - | - | - | - |
| HE REFORMS ONCE FREED | 6 | 6 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 60 | 59 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 54 | 54 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 13 | 13 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 11 | 11 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 21 | 21 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 33 | 30 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 4 | 2 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN RUN | 18 | 18 | 0 | 0.00 | - | - |
| HOLD ODDS | 144 | 144 | 0 | 0.00 | - | - |
| HONEST WORTH | 4 | 4 | 0 | 0.00 | - | - |
| HUNT IN PAIRS | 9 | 9 | 0 | 0.00 | - | - |
| JOINT KNOWS CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 17 | 17 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 3 | 3 | 0 | 0.00 | - | - |
| LONG SHOT | 2 | 2 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 4 | 3 | 0 | 0.00 | - | - |
| MANOEUVRE | 5 | 5 | 0 | 0.00 | - | - |
| MARCH CHECK | 2 | 2 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 5 | 5 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 4 | 4 | 0 | 0.00 | - | - |
| MISSILES ON ONE TARGET | 7 | not checked | - | - | - | - |
| MOVE SPELL NOT WORTH | 1 | not checked | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 2 | trace | - | - | - | - |
| MOVE SPELL SPOT | 8 | not checked | - | - | - | - |
| NEARER NOT NEEDED | 43 | 42 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 9 | 8 | 0 | 0.00 | - | - |
| NO LATE CUT | 3 | 3 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 1 | not checked | - | - | - | - |
| ONE JOINT FIGURE | 2 | 1 | 0 | 0.00 | - | - |
| ONE ROUTE | 4 | 4 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 18 | 18 | 0 | 0.00 | - | - |
| PLAN RESULT | 264 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE KNOWS THE FIGHT | 4 | 2 | 0 | 0.00 | - | - |
| REAL GROUND | 4 | 4 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 3 | 3 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 4 | 4 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 2 | 2 | 0 | 0.00 | - | - |
| RUN DOWN | 6 | 6 | 0 | 0.00 | - | - |
| SCOUT SPOT | 4 | 4 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 13 | 13 | 0 | 0.00 | - | - |
| SET-UP MISSED | 1 | trace | - | - | - | - |
| SHOOTERS ON THE TABLE | 84 | not checked | - | - | - | - |
| SHOT OR CHARGE | 4 | 4 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 2 | not checked | - | - | - | - |
| SPELL WORTH | 2 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 27 | 27 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 1 | 1 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 14 | 14 | 0 | 0.00 | - | - |
| STANDS STILL | 338 | 334 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 8 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 8 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 7 | not checked | - | - | - | - |
| THE TABLE BINDS | 274 | not checked | - | - | - | - |
| WAITS AGAIN | 5 | 4 | 0 | 0.00 | - | - |
| WHOLE FIGHT DANGER | 23 | 21 | 0 | 0.00 | - | - |
| WHOLE FIGHT GAIN | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: cora-bb45c30-p37

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 2.33 | 7.00 | 35.6 |
| PROMISE BY ITS OWN SUM | rule | 0.67 | 3.67 | 21.6 |
| ARMY TABLE | rule | 1.00 | 1.00 | 23.0 |
| HOLDER ASSIGNMENT | rule | 1.00 | 0.67 | 14.6 |
| CANNON PLANNED TARGET | rule | - | 1.33 | 5.3 |
| RULE SWITCHED OFF | gate | - | 0.67 | 28.0 |
| BEST PRIZE | rule | - | 0.33 | 2.8 |
| CHARGE NOW FIRST | rule | - | 0.33 | 21.3 |
| NO REASON | gate | 0.33 | - | 29.1 |
| REDIRECT WEIGHED | rule | - | 0.33 | 2.8 |
| RESERVE FALL BACK | rule | - | 0.33 | 22.1 |
| SUPPORT NARROWED | rule | - | 0.33 | 4.7 |

### Plans: cora-bb45c30-p37

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | move | 25.3 | 92% | 2537 | 0 | 0% |
| Mine | shoot | 2.0 | 33% | 367 | 32 | 9% |
| Opponent | charge | 3.0 | 56% | 446 | 110 | 25% |
| Opponent | move | 37.3 | 96% | 1362 | 0 | 0% |
| Opponent | shoot | 20.3 | 84% | 391 | 771 | 197% |

### Battle groups: cora-bb45c30-p37

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 2.0 | 33% | 50% | 0% | - | 0% | 0% | 0% | 100% | 0% |
| Opponent | REDIRECT COUNTER | 2.3 | 0% | - | - | - | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: cora-bb45c30-p37

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 4 | 0 (4) | 0 | 0 | 75 | 75% | 2.0 | 0 (2) | - | 0 (2) | 0 (3) | 0 (1) |
| Mine | Character | 15 | 24 (15) | 24 | 0 | 23 | 13% | 3.2 | - | 21 (8) | 25 (2) | 25 (7) | 14 (3) |
| Mine | Clean-up | 3 | 0 (3) | 0 | 0 | 33 | 67% | 2.0 | 0 (1) | 0 (2) | - | 0 (3) | - |
| Mine | Fast Hammer | 2 | 0 (2) | 0 | 0 | 100 | 100% | - | 0 (2) | - | - | 0 (1) | 0 (1) |
| Mine | Hammer | 6 | 45 (6) | 3 | 41 | 37 | 33% | 4.2 | 35 (1) | 53 (3) | 34 (2) | 43 (4) | 47 (2) |
| Mine | Holder | 5 | 49 (5) | 0 | 49 | 0 | 60% | 4.5 | 23 (2) | 195 (1) | 0 (1) | 0 (1) | 82 (3) |
| Mine | Shooter | 2 | 132 (2) | 55 | 77 | 50 | 0% | 1.0 | - | 154 (1) | 111 (1) | 132 (2) | - |
| Mine | Wizard | 3 | 30 (3) | 30 | 0 | 0 | 0% | 2.3 | - | - | 121 (1) | 121 (1) | - |
| Opponent | Chaff | 2 | 0 (2) | 0 | 0 | 100 | 0% | 1.5 | 0 (1) | 0 (1) | - | 0 (2) | - |
| Opponent | Character | 8 | 84 (8) | 84 | 0 | 13 | 38% | 2.0 | 212 (1) | 76 (6) | 0 (1) | 62 (4) | 93 (4) |
| Opponent | Clean-up | 6 | 24 (6) | 7 | 17 | 17 | 0% | 2.8 | 0 (1) | 37 (5) | - | 10 (5) | 66 (1) |
| Opponent | Fast Hammer | 4 | 0 (4) | 0 | 0 | 31 | 50% | 1.5 | 0 (1) | 0 (1) | 0 (2) | 0 (3) | 0 (1) |
| Opponent | Hammer | 3 | 0 (3) | 0 | 0 | 0 | 67% | 5.0 | 0 (1) | 0 (1) | 0 (1) | 0 (2) | 0 (1) |
| Opponent | Holder | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | - | 0 (1) | - | 0 (1) |
| Opponent | Shooter | 10 | 100 (10) | 23 | 77 | 0 | 0% | 2.4 | 348 (2) | 76 (8) | - | 137 (8) | 0 (2) |
| Opponent | War machine | 12 | 2 (12) | 2 | 0 | 37 | 0% | 2.2 | 0 (10) | - | 13 (2) | 0 (2) | 3 (10) |
| Opponent | Wizard | 2 | 0 (2) | 0 | 0 | 0 | 0% | 1.0 | - | 0 (2) | - | - | 0 (2) |

### Charged fights: cora-bb45c30-p37

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 3 | 149 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Dwarfen Mountain Holds | 2 | 260 | 0 | 1.5 | 1.7 | 0 | 117 | -117 | 2 of 3 | 0 of 3 | -175 | +0 |
| Opponent | Tomb Kings of Khemri | 1 | 55 | 952 | 2.0 | 1.0 | 476 | 0 | +476 | 1 of 2 | 1 of 2 | - | +476 |
| **Opponent** | all armies | 3 | 192 | 317 | 1.7 | 1.4 | 190 | 70 | +120 | 3 of 5 | 1 of 5 | -175 | +317 |

### Effective charges: cora-bb45c30-p37

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | Dwarfen Mountain Holds | 3 | 3 (net -117) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 3) |
| Opponent | Tomb Kings of Khemri | 2 | 1 (net +952) | 0 | 0 | 0 | 0 | 0 | 1 | 0% (0 of 1) |

### Charged fights, damage counted: cora-bb45c30-p37

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | Long shot (under 50%) | 4 | 245 | 370 | +150 | 376 | 143 | +234 | +95.3 |
| Opponent | No odds | 1 | 195 | 65 | +0 | 54 | 0 | +54 | +27.8 |
| Opponent | All fights | 5 | 235 | 309 | +120 | 312 | 114 | +198 | +84.1 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| cora-bb45c30-p37 | move | 20 | 0 (0%) | 0 (0%) | 2 (10%) | 18 (90%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0106, L0122 |
| Ring of Doom | Mine | L0206 |

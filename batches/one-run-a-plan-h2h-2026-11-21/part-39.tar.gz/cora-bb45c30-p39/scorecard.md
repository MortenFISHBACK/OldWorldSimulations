# Doctrine scorecard: cora-bb45c30-p39

### Scorecard: cora-bb45c30-p39

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0409 | 1 | 1 | Mine | no | 10 | - | 0 | 1 | 0 | 0 | 0 | 0 |
| L0409 | 1 | 1 | Opponent | no | 1 | - | 0 | 2 | 0 | 0 | 0 | 295 |
| L0425 | 5 | 1 | Mine | yes | - | 2 | 1 | 3 | 0 | 0 | 0 | 65 |
| L0425 | 5 | 1 | Opponent | yes | - | 6 | 1 | 4 | 0 | 0 | 0 | 0 |
| L0512 | 2 | 1 | Mine | - | - | - | 0 | 2 | 0 | 0 | 0 | 430 |
| L0512 | 2 | 1 | Opponent | - | - | 6 | 0 | 1 | 0 | 0 | 0 | 330 |
| **Average** | | | Mine | 50% | 10.0 | 2.0 | 0.3 | 2.0 | 0.0 | 0.0 | 0.0 | 165.0 |
| **Average** | | | Opponent | 50% | 1.0 | 6.0 | 0.3 | 2.3 | 0.0 | 0.0 | 0.0 | 208.3 |

### KPIs: cora-bb45c30-p39

Rules off - Opponent only: ONE RUN A PLAN.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 25% (4 of 16) | 0% (0 of 15) | 13% (4 of 31) |
| Winner chose to follow up after the loser gave ground |  | 100% (3 of 3); on the table 100% | 100% (2 of 2); on the table 100% | 100% (5 of 5); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | 0% (0 of 1); on the table 100% | 100% (1 of 1); on the table 100% | 50% (1 of 2); on the table 100% |
| Winner chose to pursue after the loser fled |  | - | - | - |
| Winner chose to follow up or pursue (all three) |  | 75% (3 of 4); on the table 100% | 100% (3 of 3); on the table 100% | 86% (6 of 7); on the table 100% |
| Magic missiles tried each own turn | 50%+ | 50% (6 of 12) | 33% (12 of 36) | 38% (18 of 48) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 55% (6 of 11) | 44% (12 of 27) | 47% (18 of 38) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | - | - |
| Points that never fought | lower | 73% (4395 of 5998) | 69% (4146 of 5998) | 71% (8541 of 11996) |
|   infantry points that never fought | lower | 73% (1046 of 1424) | 94% (1119 of 1187) | 83% (2165 of 2611) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 61% (14 of 23) | 81% (22 of 27) | 72% (36 of 50) |
| Bound items with a magic missile used (at least once a game) |  | 0.0 uses a game | 100% (3 of 3); 4.0 uses a game | 100% (3 of 3); 2.0 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
|   their share of the points of units over 100 pts | lower | 61% (3144 of 5120) | 81% (4392 of 5442) | 71% (7536 of 10562) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 3.0 (38%) | 3.0 (30%) |
| MARCHED: its unit marched | 1.7 (83%) | 2.0 (25%) | 3.7 (37%) |
| IN COMBAT: engaged in combat | 0.3 (17%) | 0.3 (4%) | 0.7 (7%) |
| GONE: slain | 0.0 (0%) | 2.7 (33%) | 2.7 (27%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 6.7 | 0.7 | 1.7 | 6.0 | 0.3 | 1.0 |
| not cast | 3.3 | 5.3 | 4.3 | 10.0 | 1.7 | 19.0 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (2%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 2.7 (50%) | 2.7 (62%) | 3.0 (30%) | 0.0 (0%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 3.7 (37%) | 0.3 (20%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.0 (0%) | 0.7 (15%) | 0.7 (7%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | 0.3 (10%) | 2.7 (50%) | 0.3 (8%) | 2.7 (27%) | 1.3 (80%) | 2.0 (11%) |
| HELD BACK: the computer weighed it and chose not to cast it | 3.0 (90%) | 0.0 (0%) | 0.7 (15%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 16.7 (88%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.3 a game | 1.3 a game | 0.8 a game |
| stood (cast and not dispelled) | 0% (0 of 1) | 75% (3 of 4) | 60% (3 of 5) |
| the unit moved after it | - | 100% (3 of 3) | 100% (3 of 3) |
| it charged on its next turn | - | 0% (0 of 3) | 0% (0 of 3) |
| the enemy charged it first | - | 0% (0 of 3) | 0% (0 of 3) |
| it fought by the end of its next turn | - | 0% (0 of 3) | 0% (0 of 3) |
| it moved out of a charge the enemy had planned (not charged first) | - | 0% (0 of 3) | 0% (0 of 3) |
| none of these (no charge, no fight, no charge escaped) | - | 100% (3 of 3) | 100% (3 of 3) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 64% (59 of 92) | 69% (47 of 68) | 66% (106 of 160) |
|   cavalry | 67% (8 of 12) | - | 67% (8 of 12) |
|   character | 88% (14 of 16) | 100% (5 of 5) | 90% (19 of 21) |
|   chariot | 29% (7 of 24) | 100% (6 of 6) | 43% (13 of 30) |
|   infantry | 50% (6 of 12) | 60% (15 of 25) | 57% (21 of 37) |
|   monster | - | 67% (4 of 6) | 67% (4 of 6) |
|   war machine | 86% (24 of 28) | 65% (17 of 26) | 76% (41 of 54) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 3.3 (30%) | 1.3 (19%) | 4.7 (26%) |
| MOVED: a war machine that moved | 0.0 (0%) | 0.3 (5%) | 0.3 (2%) |
| NO TARGET IN RANGE | 3.7 (33%) | 1.7 (24%) | 5.3 (30%) |
| ONLY IN COMBAT: the only targets were in combat | 0.3 (3%) | 0.0 (0%) | 0.3 (2%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 3.3 (30%) | 2.7 (38%) | 6.0 (33%) |
| SHELTERED: the target was sheltered | 0.0 (0%) | 0.7 (10%) | 0.7 (4%) |
| OTHER BAR | 0.3 (3%) | 0.3 (5%) | 0.7 (4%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 2.7 | 0.3 | 88% | 7.5 pts | 20 pts |
| character | 7.0 | 1.3 | 81% | 3.6 pts | 25 pts |
| chariot | 4.3 | 4.0 | 54% | 16.2 pts | 70 pts |
| infantry | 9.7 | 2.7 | 76% | 9.7 pts | 94 pts |
| monster | 2.7 | 0.3 | 88% | 6.1 pts | 16 pts |
| war machine | 13.7 | 8.0 | 63% | 21.6 pts | 295 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 1.0 | 1.7 | 1.3 |
| Charges that made contact a game | 0.7 | 1.7 | 1.2 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.50 declared, 0.50 contact (2 units) | 0.33 declared, 0.33 contact (3 units) | 0.40 declared, 0.40 contact (5 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 1.00 declared, 1.00 contact (2 units) | 1.00 declared, 1.00 contact (2 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.09 declared, 0.05 contact (22 units) | 0.11 declared, 0.11 contact (18 units) | 0.10 declared, 0.07 contact (40 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 50% (2 of 4) | 100% (2 of 2) | - | 67% (4 of 6) |
| Character in a unit | 83% (5 of 6) | 100% (1 of 1) | - | 86% (6 of 7) |
| Character on its own | 100% (1 of 1) | 83% (5 of 6) | 50% (2 of 4) | 73% (8 of 11) |
| Chariot | - | 80% (4 of 5) | - | 80% (4 of 5) |
| Infantry | 50% (6 of 12) | 67% (2 of 3) | - | 53% (8 of 15) |
| Monstrous | - | 100% (1 of 1) | - | 100% (1 of 1) |
| War Machines | 100% (5 of 5) | - | - | 100% (5 of 5) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Chaos Dwarfs | 2 | 100% (3 of 3); on the table 100% | 50% (6 of 12) | 76% | 56% (9 of 16) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Dwarfen Mountain Holds | 1 | 0% (0 of 1); on the table 100% | - | 68% | 71% (5 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 1 | - | 58% (7 of 12) | 100% | 83% (10 of 12) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Grand Cathay | 1 | - | 6% (1 of 18) | 75% | 78% (7 of 9) | 100% (3 of 3); 12.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Vampire Counts | 1 | 100% (3 of 3); on the table 100% | 67% (4 of 6) | 32% | 83% (5 of 6) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (cora-bb45c30-p39, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 0% (0) | 50% (1) | 25% (1) |
| ...free all their last turn and able to turn (per game) | 0.00 | 0.33 | 0.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.33 | 0.33 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.33 | 0.00 | 0.33 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.67 | 0.00 | 0.67 |

### Quality by phase: cora-bb45c30-p39

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.7 | 4.0 |
| Strategy | Charge objectives carried out (made contact) | 33% (1 of 3) | 100% (5 of 5) |
| Strategy | Shoot objectives carried out (shot that target) | 43% (19 of 44) | 47% (16 of 34) |
| Strategy | Support requests answered (helper made contact too) | - | 100% (2 of 2) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | - | 100% (1 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | - | 100% (1 of 1) |
| Strategy | Joined characters whose unit fought | 40% (2 of 5) | 17% (1 of 6) |
| Strategy | Lone characters that fought | 33% (2 of 6) | 38% (3 of 8) |
| Movement | Charges halted short of contact | 0.3 | 0.0 |
| Movement | Idle units | 2.0 | 2.3 |
| Movement | Points that never moved of their own | 165.0 | 208.3 |
| Movement | Fights charged into per game | 0.7 | 1.0 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 1 | 0 of 3 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 1 | 2 of 3, net -106 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 1 of 1, net +75 | 0 of 3 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 0 of 1 | 0 of 3 |
| Shooting | Shots by shooting units (incl. breath weapons) | 11.7 | 10.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 57% (20 of 35) | 73% (22 of 30) |
| Shooting | Points destroyed by shooting units | 87.3 | 0.0 |
| Shooting | War machine shots | 8.0 | 5.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 42% (10 of 24) | 41% (7 of 17) |
| Shooting | Points destroyed by war machines | 181.3 | 0.0 |
| Magic | Magic missiles cast | 2.0 | 1.7 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 33% (2 of 6) | 60% (3 of 5) |
| Magic | Wounds caused by magic missiles | 10.0 | 0.7 |
| Magic | Points destroyed by magic (all spells) | 133.7 | 24.3 |
| Magic | Augments / hexes / assailments / vortexes cast | 3.0 / 0.0 / 0.0 / 0.0 | 2.0 / 0.3 / 0.7 / 0.0 |
| Combat | Points destroyed in combat | 95.3 | 63.0 |
| Combat | Points run down | 0.0 | 0.0 |
| Combat | Net points per charged fight, damage counted | +38 | -47 |
| Combat | Net per 100 charger points, damage counted | +9.2 | -11.1 |
| Combat | First round won (charged fights) | 50% | 67% |
| Combat | Net points per charged fight | +38 | -7 |
| Combat | Net points per supported fight / lone fight | - / +38 | -106 / +189 |
| Combat | Charged fights on a top-3 enemy unit | 1 of 2 | 2 of 3 |
| Game | Points lost | 102.3 | 497.7 |
| Game | VP from objectives | 820.0 | 503.3 |
| Game | Lone holders (player turns) | 10.0 | 1.0 |

- Mine won / drew / lost: 3 / 0 / 0 of 3 ended games (of 3); mean margin (Mine - Opponent) +713 VP
- The side that went first won 1 of 3 games with a winner
- Points traded per game (both sides' losses): 600
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: cora-bb45c30-p39

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| ARMY TABLE | 21.3 | -400.9 | 0.0 | 126.0 | 24.0 | +179.9 | 0.0 | 376.7 |
| ARTILLERY RE-ROLL WEIGHED | 0.7 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 110.0 |
| ASSAILMENT BY POINTS | - | - | - | - | 0.3 | +0.5 | 0.0 | 70.3 |
| BACKUP TARGETS | - | - | - | - | 0.3 | +0.7 | 0.0 | 0.0 |
| CANNON PLAN MISSED | 0.3 | +0.0 | 126.3 | 0.0 | - | - | - | - |
| CANNON PLANNED TARGET | 7.7 | +133.2 | 740.7 | 63.3 | 5.7 | +0.0 | 0.0 | 110.0 |
| CANNON SIGHT KEPT | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CAST JOB | 1.3 | +22.9 | 49.0 | 0.0 | 5.0 | +39.6 | 0.0 | 0.0 |
| CASTER AWAY FROM SCREEN | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | 0.7 | +32.5 | 0.0 | 0.0 | - | - | - | - |
| CHAMPION KNOWS CHALLENGE | - | - | - | - | 0.3 | -14.2 | 0.0 | 0.0 |
| CHARACTER GUNS | 0.3 | +0.0 | 0.0 | 0.0 | 4.7 | +0.0 | 0.0 | 0.0 |
| CHARGE LOSSES | 20.0 | -453.5 | 0.0 | 0.0 | 12.3 | -490.7 | 0.0 | 469.7 |
| CHARGE NOT DECLARED | - | - | - | - | 0.3 | +0.0 | 0.0 | 70.3 |
| CHARGE NOW FIRST | 1.3 | +0.0 | 25.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 9.7 | +0.0 | 0.0 | 0.0 | 7.0 | +0.0 | 0.0 | 99.0 |
| COMBAT PIVOT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CONVEYANCE SEARCH | 0.3 | +24.6 | 0.0 | 0.0 | - | - | - | - |
| COVER ONCE | 14.0 | -1216.6 | 0.0 | 94.7 | 6.0 | -476.8 | 0.0 | 126.3 |
| DENIED BY THE FIGHT | - | - | - | - | 0.7 | -4.3 | 0.0 | 0.0 |
| DEPLOY BY FIGURES | 8.7 | +61.0 | 0.0 | 0.0 | 6.3 | +5.3 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | 0.3 | -1.4 | 0.0 | 0.0 | - | - | - | - |
| EXACT ROUND | - | - | - | - | 0.7 | -2.8 | 63.0 | 0.0 |
| FACES THE THREAT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FALL BACK GOOD ORDER | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 63.0 | 0.0 |
| FALLS SHORT | 7.0 | +108.2 | 0.0 | 0.0 | 17.7 | +196.4 | 0.0 | 673.3 |
| FEATURE BUFFS | 2.0 | +4.4 | 0.0 | 0.0 | - | - | - | - |
| FIGHT TO THE END | 0.3 | +16.7 | 0.0 | 0.0 | 0.3 | +9.2 | 0.0 | 0.0 |
| FIVE ACTION | 109.0 | +6336.5 | 2271.3 | 301.3 | 93.7 | +2931.7 | 63.0 | 1749.7 |
| FLANK NOT WEIGHED | 8.0 | +0.0 | 0.0 | 0.0 | 5.3 | +0.0 | 0.0 | 74.0 |
| FOLLOW UP WEIGHED | 0.7 | +6.1 | 0.0 | 0.0 | 0.3 | +58.4 | 0.0 | 0.0 |
| FOUR ROUNDS | 1.0 | +116.6 | 25.0 | 0.0 | 1.7 | +167.1 | 63.0 | 70.3 |
| FREED FROM HIS FIGHT | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FRIEND CHARGES FIRST | - | - | - | - | 0.3 | -1.2 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | - | - | - | - | 2.7 | -3.2 | 0.0 | 0.0 |
| GOAL WALK | 14.0 | +1215.8 | 0.0 | 0.0 | 4.0 | +236.0 | 0.0 | 169.3 |
| GUN FIGURES | 1.3 | +0.0 | 0.0 | 0.0 | 1.7 | +25.8 | 0.0 | 0.0 |
| GUN MASK | 0.3 | +2.9 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HARD STAY DROPPED | 3.0 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS CHARGE BY HIS RUN | 8.7 | +0.0 | 0.0 | 0.0 | 5.7 | +0.0 | 0.0 | 126.3 |
| HIS CHARGE DENIED | - | - | - | - | 0.7 | +3.1 | 0.0 | 70.3 |
| HIS CHARGE LIST | 4.3 | +0.0 | 0.0 | 0.0 | 8.0 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 3.3 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 126.3 |
| HIS MOVE AND SHOT | 4.0 | -18.0 | 0.0 | 0.0 | 2.3 | -26.2 | 0.0 | 15.0 |
| HIS ONE QUARTER | 6.0 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 3.7 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 126.3 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 55.0 | +4421.1 | 0.0 | 126.0 | 49.7 | +3042.4 | 0.0 | 1379.3 |
| HIS SHOTS BY HIS RUN | 36.7 | +789.1 | 0.0 | 0.0 | 32.3 | +651.9 | 0.0 | 1020.7 |
| HIS TURN DENIED | - | - | - | - | 0.7 | +40.7 | 0.0 | 0.0 |
| HIS TURN RUN | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 18.0 | +0.0 | 0.0 | 0.0 | 9.0 | +0.0 | 0.0 | 0.0 |
| HOLDER ASSIGNMENT | 10.3 | +949.1 | 0.0 | 0.0 | 7.3 | +631.5 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 1.0 | -62.3 | 25.0 | 0.0 | 1.0 | -70.6 | 63.0 | 0.0 |
| HUNT IN PAIRS | 0.7 | +59.3 | 0.0 | 0.0 | 2.0 | +330.8 | 0.0 | 198.7 |
| IDLE COST | 5.7 | -113.7 | 0.0 | 0.0 | 11.0 | -174.8 | 0.0 | 589.7 |
| JOINT CHARGE NOW | - | - | - | - | 1.3 | +207.2 | 0.0 | 70.3 |
| JOINT KNOWS CHALLENGE | - | - | - | - | 0.7 | -18.2 | 0.0 | 0.0 |
| KEPT FROM ITS LAST STOP | 1.3 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 1.3 | +64.9 | 0.0 | 0.0 | - | - | - | - |
| LEGAL CHARGES ONLY | 3.7 | +0.0 | 49.0 | 63.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| LONE CHARACTER SAFE SPOT | - | - | - | - | 0.3 | +45.8 | 0.0 | 70.3 |
| LONE WIZARD KEPT IN | - | - | - | - | 0.7 | +30.1 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | - | - | - | - | 1.3 | -7.5 | 63.0 | 0.0 |
| MANOEUVRE | 2.3 | -6.5 | 0.0 | 0.0 | 2.7 | -0.0 | 0.0 | 0.0 |
| MARCH BY THE SUM | 0.7 | +13.9 | 0.0 | 0.0 | 0.3 | +10.1 | 0.0 | 0.0 |
| MARCH CHECK | 1.3 | +48.3 | 0.0 | 0.0 | 3.0 | +221.7 | 0.0 | 126.3 |
| MARCH OF THE TABLE | 0.3 | +44.2 | 0.0 | 0.0 | 0.7 | +31.5 | 0.0 | 126.3 |
| MARCH OVER CASTS | 1.3 | +29.9 | 0.0 | 0.0 | 0.7 | +81.7 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 1.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 1.7 | +86.4 | 0.0 | 0.0 | 2.7 | +70.4 | 0.0 | 198.7 |
| MEETS IN TIME | 5.3 | +153.6 | 0.0 | 0.0 | 2.3 | +33.0 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 2.3 | +87.7 | 0.0 | 0.0 | 9.7 | +83.4 | 0.0 | 126.3 |
| MISSILES NEXT TURN | 3.0 | +63.7 | 0.0 | 0.0 | 11.3 | +83.4 | 0.0 | 252.7 |
| MOVE ORDER | 1.0 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| MOVE SPELL IN RANGE | 3.7 | +131.2 | 0.0 | 0.0 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 1.0 | +78.7 | 0.0 | 0.0 | 2.7 | +87.6 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 9.0 | +389.8 | 0.0 | 0.0 | 10.0 | +446.1 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 1.3 | +55.3 | 0.0 | 0.0 | 2.3 | +85.2 | 0.0 | 0.0 |
| NEXT OBJECTIVE NEARER | - | - | - | - | 0.7 | -20.0 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 0.7 | -1.0 | 25.0 | 0.0 | 1.0 | -58.9 | 63.0 | 0.0 |
| NO LATE CUT | 0.7 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | 0.7 | +2.2 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 5.3 | -261.7 | 0.0 | 31.7 | 5.0 | -127.9 | 0.0 | 271.0 |
| OGRE LOADER SECOND SHOT | - | - | - | - | 1.0 | +0.0 | 0.0 | 55.0 |
| ONE CHECK AFTER THE LAST CHANGE | 1.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 2.7 | -53.1 | 0.0 | 0.0 | 3.7 | -67.6 | 0.0 | 72.3 |
| ONE JOINT FIGURE | - | - | - | - | 0.3 | +23.2 | 0.0 | 70.3 |
| ONE OBJECTIVE FORMULA | 4.0 | +121.6 | 0.0 | 0.0 | 3.0 | -240.0 | 0.0 | 0.0 |
| ONE PROMISE A TARGET | - | - | - | - | 0.3 | +84.8 | 0.0 | 0.0 |
| ONE ROUTE | 1.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| OPENS UP | 0.7 | +49.5 | 25.0 | 0.0 | - | - | - | - |
| OVERRUNS AWAY | 0.3 | +19.7 | 25.0 | 0.0 | 0.3 | +0.2 | 0.0 | 0.0 |
| PATHS CROSS | 0.7 | +34.1 | 0.0 | 0.0 | 0.7 | +8.9 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.3 | -11.1 | 0.0 | 0.0 | - | - | - | - |
| PLAN RESULT | 47.7 | +1219.5 | 223.7 | 238.0 | 43.0 | +49.2 | 0.0 | 729.3 |
| PROMISE BY ITS OWN SUM | 4.7 | -148.3 | 0.0 | 0.0 | 4.3 | -18.4 | 0.0 | 0.0 |
| PROMISE IN STEPS | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | - | - | - | - | 0.3 | -0.8 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | - | - | - | - | 2.3 | -2.0 | 0.0 | 0.0 |
| PROMISE SHOT AWAY | - | - | - | - | 0.7 | -0.1 | 0.0 | 0.0 |
| QUARTER ODDS | 19.3 | +2140.1 | 343.0 | 126.0 | 19.3 | +1308.3 | 63.0 | 217.3 |
| REAL GROUND | 1.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | 2.0 | +143.6 | 0.0 | 0.0 | 0.7 | +93.1 | 0.0 | 25.0 |
| REDIRECT FOR A FRIEND IN REACH | 1.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 15.0 |
| REFORMS TO MEET IT | 0.7 | -0.8 | 0.0 | 0.0 | 0.7 | -20.4 | 0.0 | 0.0 |
| REFUSING RETIRES | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| RISK BY ARC | 1.0 | +38.0 | 25.0 | 0.0 | 1.7 | -25.2 | 63.0 | 70.3 |
| RISK ON THE WAY | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ROUNDS AFTER TERROR | - | - | - | - | 0.3 | -4.3 | 63.0 | 0.0 |
| RUN DOWN | - | - | - | - | 0.7 | -7.6 | 63.0 | 0.0 |
| SCOUT SPOT | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| SCOUT WAITS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 1.3 | -39.2 | 0.0 | 30.0 |
| SEARCH SPOT | 0.7 | +27.4 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| SET CREDITED ONCE | - | - | - | - | 3.7 | -391.5 | 0.0 | 72.3 |
| SET UP BY THE SET | - | - | - | - | 4.0 | +477.3 | 0.0 | 72.3 |
| SET UP TOGETHER | - | - | - | - | 0.3 | +7.3 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.7 | +1.3 | 0.0 | 0.0 | 0.3 | +0.7 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 15.0 | +0.0 | 0.0 | 87.7 | 11.3 | +0.0 | 0.0 | 125.0 |
| SHOOTS FROM THE BEST SPOT | 7.7 | +303.6 | 608.0 | 0.0 | 2.7 | +26.5 | 0.0 | 0.0 |
| SHOT OR CHARGE | - | - | - | - | 0.3 | -0.5 | 0.0 | 0.0 |
| SHOT RISK POINTS | 34.0 | +281.1 | 0.0 | 0.0 | 21.3 | +26.3 | 0.0 | 719.0 |
| SHOTS AFTER THE MOVES | 3.7 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 15.7 | +340.5 | 0.0 | 87.7 | 18.0 | +430.3 | 0.0 | 110.0 |
| SPELL WORTH | 0.3 | +1.7 | 0.0 | 0.0 | 2.0 | +48.5 | 0.0 | 0.0 |
| SPOT AS THE GAME MOVES | 5.0 | +0.0 | 0.0 | 0.0 | 7.3 | +0.0 | 0.0 | 84.7 |
| STAND AND SHOOT | - | - | - | - | 0.3 | -3.3 | 0.0 | 0.0 |
| STANDS FOR A REASON | 2.0 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 64.0 | +0.0 | 2246.3 | 175.3 | 41.0 | +0.0 | 0.0 | 565.7 |
| STAY WORTH | 28.7 | -89.1 | 1336.7 | 263.0 | 28.3 | -259.4 | 0.0 | 330.0 |
| STUBBORN BY POINTS | 0.3 | +52.3 | 0.0 | 0.0 | - | - | - | - |
| STUPIDITY NEXT TURN | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 6.7 | +326.5 | 0.0 | 0.0 | 7.0 | +221.4 | 0.0 | 129.0 |
| SUPPORT NARROWED | 0.3 | +0.0 | 25.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| SUPPORT WORKED OUT | 6.7 | +326.5 | 0.0 | 0.0 | 7.0 | +221.4 | 0.0 | 129.0 |
| SURE REACH TOGETHER | 1.0 | +1.0 | 0.0 | 0.0 | 1.0 | +52.6 | 0.0 | 15.0 |
| THE DEARER SUM KEEPS ITS PLAN | 3.0 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 4.7 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 2.0 | +0.0 | 0.0 | 0.0 | 5.3 | +0.0 | 0.0 | 134.7 |
| THE STEP BACK IS MADE | 1.7 | +0.0 | 0.0 | 0.0 | 4.7 | +0.0 | 0.0 | 25.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 52.3 | +0.0 | 0.0 | 150.7 | 45.3 | +0.0 | 0.0 | 925.0 |
| TIED UP BY THE SUM | 0.7 | +58.3 | 25.0 | 0.0 | - | - | - | - |
| TIME ON OUR SIDE | 38.3 | +438.0 | 30.0 | 24.3 | 18.7 | +180.7 | 0.0 | 0.0 |
| WAITS AGAIN | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| WAR ENGINE JOBS | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WHO HITS BACK | - | - | - | - | 0.3 | +8.9 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | 2.3 | -87.0 | 0.0 | 0.0 | 1.3 | -170.9 | 0.0 | 126.3 |
| WHOLE FIGHT GAIN | - | - | - | - | 1.0 | +73.5 | 0.0 | 70.3 |
| WOUNDS ON THE RANKS | 2.3 | +70.5 | 0.0 | 0.0 | 0.3 | +1.1 | 0.0 | 0.0 |

### Rule changes: cora-bb45c30-p39

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 136 | 136 | 86 | 28.67 | +352 | +4.1 |
| HIS SHOT LIST | 314 | 305 | 84 | 28.00 | +1916 | +22.8 |
| HOLDER ASSIGNMENT | 53 | 53 | 51 | 17.00 | +3116 | +61.1 |
| SHOT RISK POINTS | 166 | 163 | 37 | 12.33 | +1217 | +32.9 |
| HIS SHOTS BY HIS RUN | 207 | 201 | 36 | 12.00 | +302 | +8.4 |
| OFF BEST | 31 | 31 | 31 | 10.33 | -1169 | -37.7 |
| THE TABLE AGAIN | 36 | 36 | 26 | 8.67 | +0 | +0.0 |
| TIME ON OUR SIDE | 171 | 151 | 23 | 7.67 | +107 | +4.7 |
| DEPLOY BY FIGURES | 45 | 45 | 22 | 7.33 | +460 | +20.9 |
| SHOOTS FROM THE BEST SPOT | 31 | 31 | 22 | 7.33 | +171 | +7.8 |
| HARD STAY DROPPED | 17 | 17 | 17 | 5.67 | +0 | +0.0 |
| QUARTER ODDS | 116 | 113 | 16 | 5.33 | +906 | +56.6 |
| FIVE ACTION | 608 | 595 | 15 | 5.00 | +333 | +22.2 |
| LEGAL CHARGES ONLY | 12 | 12 | 12 | 4.00 | +0 | +0.0 |
| SUPPORT ADDS | 41 | 41 | 12 | 4.00 | +116 | +9.7 |
| SUPPORT WORKED OUT | 41 | 41 | 12 | 4.00 | +116 | +9.7 |
| ARTILLERY RE-ROLL WEIGHED | 10 | 10 | 10 | 3.33 | +0 | +0.0 |
| CAST JOB | 19 | 19 | 10 | 3.33 | +22 | +2.2 |
| MARCH CHECK | 13 | 12 | 10 | 3.33 | +300 | +30.1 |
| MEETS IN TIME | 23 | 23 | 10 | 3.33 | +383 | +38.3 |
| CHARGE LOSSES | 97 | 93 | 8 | 2.67 | +791 | +98.8 |
| COVER ONCE | 60 | 41 | 8 | 2.67 | +262 | +32.8 |
| GOAL WALK | 54 | 54 | 8 | 2.67 | +544 | +67.9 |
| MOVE ORDER | 8 | 8 | 8 | 2.67 | +0 | +0.0 |
| PROMISE BY ITS OWN SUM | 27 | 27 | 8 | 2.67 | -500 | -62.5 |
| REDIRECT FOR A FRIEND IN REACH | 8 | 8 | 8 | 2.67 | +0 | +0.0 |
| SET UP BY THE SET | 12 | 12 | 7 | 2.33 | +678 | +96.9 |
| STAY WORTH | 171 | 155 | 6 | 2.00 | +38 | +6.4 |
| ADVANCE LANE KEPT | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| FOUR ROUNDS | 8 | 8 | 5 | 1.67 | +321 | +64.3 |
| MOVE TO CHARGE COMPUTED | 11 | 10 | 5 | 1.67 | +163 | +32.7 |
| CANNON SIGHT KEPT | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| IDLE COST | 50 | 39 | 4 | 1.33 | +29 | +7.3 |
| JOINT CHARGE NOW | 4 | 4 | 4 | 1.33 | +622 | +155.4 |
| LANE BY FIGURES | 4 | 4 | 4 | 1.33 | +195 | +48.6 |
| NEARER NOT NEEDED | 57 | 53 | 4 | 1.33 | +226 | +56.5 |
| NEXT CHARGE BY LIST | 11 | 10 | 4 | 1.33 | +154 | +38.4 |
| PATHS CROSS | 4 | 4 | 4 | 1.33 | +129 | +32.3 |
| SHOTS IN THE MOVE | 101 | 74 | 4 | 1.33 | +90 | +22.5 |
| FOLLOW UP WEIGHED | 3 | 3 | 3 | 1.00 | +194 | +64.5 |
| HUNT IN PAIRS | 8 | 6 | 3 | 1.00 | +364 | +121.3 |
| MARCH BY THE SUM | 3 | 3 | 3 | 1.00 | +72 | +24.1 |
| MARCH OF THE TABLE | 3 | 3 | 3 | 1.00 | -227 | -75.7 |
| OGRE LOADER SECOND SHOT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| SHOOTERS IN TWO RANKS | 3 | 3 | 3 | 1.00 | +6 | +2.0 |
| SHOTS AFTER THE MOVES | 19 | 19 | 3 | 1.00 | +0 | +0.0 |
| SURE REACH TOGETHER | 6 | 6 | 3 | 1.00 | +54 | +17.9 |
| THE ROW IN ITS ORDER | 21 | 3 | 3 | 1.00 | +0 | +0.0 |
| WOUNDS ON THE RANKS | 8 | 8 | 3 | 1.00 | +11 | +3.7 |
| CANNON PLANNED TARGET | 40 | 40 | 2 | 0.67 | +0 | +0.0 |
| CASTS FROM BEHIND | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| CHARGE NOW FIRST | 6 | 6 | 2 | 0.67 | -57 | -28.7 |
| FALLS SHORT | 74 | 62 | 2 | 0.67 | +32 | +15.8 |
| HOLDS AMBUSHERS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| LONE WIZARD KEPT IN | 2 | 2 | 2 | 0.67 | +90 | +45.1 |
| MANOEUVRE | 15 | 15 | 2 | 0.67 | +104 | +51.9 |
| OPENS UP | 2 | 2 | 2 | 0.67 | +39 | +19.7 |
| PROMISE SHOT AWAY | 2 | 2 | 2 | 0.67 | -0 | -0.2 |
| REDIRECT COUNTER | 8 | 7 | 2 | 0.67 | +159 | +79.4 |
| RISK BY ARC | 8 | 8 | 2 | 0.67 | +39 | +19.7 |
| SCOUT WAITS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| SEARCH SPOT | 3 | 3 | 2 | 0.67 | +82 | +41.1 |
| TIED UP BY THE SUM | 2 | 2 | 2 | 0.67 | +39 | +19.7 |
| ASSAILMENT BY POINTS | 1 | 1 | 1 | 0.33 | +1 | +1.4 |
| CASTER AWAY FROM SCREEN | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CHARGE NOT DECLARED | 1 | 1 | 1 | 0.33 | -92 | -91.6 |
| COMBAT PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FACES THE THREAT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| GUN MASK | 3 | 3 | 1 | 0.33 | +1 | +1.4 |
| MISSILES IN THE MOVE | 36 | 25 | 1 | 0.33 | +46 | +46.2 |
| ONE JOINT FIGURE | 1 | 1 | 1 | 0.33 | +19 | +18.7 |
| ONE PROMISE A TARGET | 1 | 1 | 1 | 0.33 | +254 | +254.5 |
| OVERRUNS AWAY | 2 | 2 | 1 | 0.33 | +6 | +6.2 |
| PIVOT GUARDS FLANK | 1 | 1 | 1 | 0.33 | -33 | -33.3 |
| PROMISE KNOWS THE FIGHT | 1 | 1 | 1 | 0.33 | -2 | -2.5 |
| PROMISE READS THE TABLE | 7 | 7 | 1 | 0.33 | +19 | +19.4 |
| SET CREDITED ONCE | 11 | 11 | 1 | 0.33 | +11 | +11.1 |
| STUBBORN BY POINTS | 1 | 1 | 1 | 0.33 | +157 | +156.7 |
| SUPPORT NARROWED | 2 | 2 | 1 | 0.33 | -149 | -149.0 |
| WHO HITS BACK | 1 | 1 | 1 | 0.33 | +16 | +15.8 |
| WHOLE FIGHT GAIN | 3 | 3 | 1 | 0.33 | +19 | +18.7 |
| BACKUP TARGETS | 1 | 1 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 1 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 2 | trace | - | - | - | - |
| CHAFF IN THE MOVE | 2 | 2 | 0 | 0.00 | - | - |
| CHAMPION KNOWS CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| CHARACTER GUNS | 15 | 15 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 50 | 50 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 1 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 1 | 1 | 0 | 0.00 | - | - |
| EXACT ROUND | 2 | 2 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 5 | 5 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 6 | 6 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 2 | 2 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 40 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 3 | 3 | 0 | 0.00 | - | - |
| FRIEND CHARGES FIRST | 1 | 1 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 8 | 8 | 0 | 0.00 | - | - |
| GUN FIGURES | 9 | not checked | - | - | - | - |
| HE REFORMS ONCE FREED | 1 | 1 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 43 | 42 | 0 | 0.00 | - | - |
| HIS CHARGE DENIED | 2 | 2 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 37 | 36 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 17 | 15 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 19 | 19 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 29 | 26 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 20 | 17 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 2 | 2 | 0 | 0.00 | - | - |
| HIS TURN RUN | 18 | 18 | 0 | 0.00 | - | - |
| HOLD ODDS | 81 | 81 | 0 | 0.00 | - | - |
| HONEST WORTH | 6 | 6 | 0 | 0.00 | - | - |
| JOINT KNOWS CHALLENGE | 2 | 2 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 12 | 12 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 1 | not checked | - | - | - | - |
| LOST AFTER ESCAPE | 4 | 4 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 6 | 6 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 9 | 9 | 0 | 0.00 | - | - |
| MAX FOR POSITIONING | 13 | 10 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 43 | 34 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 11 | 6 | 0 | 0.00 | - | - |
| NEXT OBJECTIVE NEARER | 2 | 2 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 5 | 5 | 0 | 0.00 | - | - |
| NO LATE CUT | 7 | 7 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT TURNED | 2 | 2 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 6 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 19 | 9 | 0 | 0.00 | - | - |
| ONE OBJECTIVE FORMULA | 21 | 14 | 0 | 0.00 | - | - |
| ONE ROUTE | 9 | 9 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 18 | 18 | 0 | 0.00 | - | - |
| PLAN RESULT | 272 | trace | - | - | - | - |
| PROMISE IN STEPS | 1 | 1 | 0 | 0.00 | - | - |
| REAL GROUND | 9 | 9 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 4 | 4 | 0 | 0.00 | - | - |
| REFUSING RETIRES | 1 | 1 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 4 | 4 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 1 | 1 | 0 | 0.00 | - | - |
| RUN DOWN | 2 | 2 | 0 | 0.00 | - | - |
| SCOUT SPOT | 2 | 2 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 4 | 4 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 1 | 1 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 79 | not checked | - | - | - | - |
| SHOT OR CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| SPELL WORTH | 7 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 37 | 33 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 1 | 1 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 13 | 13 | 0 | 0.00 | - | - |
| STANDS STILL | 315 | 306 | 0 | 0.00 | - | - |
| STUPIDITY NEXT TURN | 3 | 2 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 14 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 22 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 19 | not checked | - | - | - | - |
| THE TABLE BINDS | 293 | not checked | - | - | - | - |
| WAITS AGAIN | 4 | 4 | 0 | 0.00 | - | - |
| WAR ENGINE JOBS | 2 | 2 | 0 | 0.00 | - | - |
| WHOLE FIGHT DANGER | 11 | 10 | 0 | 0.00 | - | - |

### Off best figure: cora-bb45c30-p39

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 5.00 | 4.00 | 40.6 |
| ARMY TABLE | rule | 3.33 | 1.67 | 76.3 |
| PROMISE BY ITS OWN SUM | rule | 2.00 | 0.67 | 62.5 |
| MARCH OF THE TABLE | rule | 0.33 | 0.67 | 75.7 |
| RULE SWITCHED OFF | gate | - | 1.00 | 22.1 |
| CHARGE NOW FIRST | rule | 0.67 | - | 28.7 |
| HOLDER ASSIGNMENT | rule | 0.33 | 0.33 | 25.9 |
| CHARGE NOT DECLARED | rule | - | 0.33 | 91.6 |
| JOINT CHARGE NOW | rule | - | 0.33 | 28.3 |
| PIVOT GUARDS FLANK | rule | 0.33 | - | 33.3 |
| PROMISE KNOWS THE FIGHT | rule | - | 0.33 | 2.5 |
| SUPPORT NARROWED | rule | 0.33 | - | 149.0 |
| TURN GATE | gate | 0.33 | - | 6.8 |

### Plans: cora-bb45c30-p39

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.0 | 33% | 147 | 28 | 19% |
| Mine | join | 1.0 | 100% | 35 | 0 | 0% |
| Mine | move | 34.0 | 100% | 1899 | 0 | 0% |
| Mine | shoot | 11.7 | 66% | 405 | 1192 | 294% |
| Opponent | charge | 0.7 | 50% | 162 | 0 | 0% |
| Opponent | join | 1.7 | 100% | 93 | 0 | 0% |
| Opponent | move | 31.3 | 96% | 1128 | 0 | 0% |
| Opponent | shoot | 8.7 | 42% | 332 | 49 | 15% |
| Opponent | support | 0.7 | 50% | 0 | 0 | - |

### Battle groups: cora-bb45c30-p39

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 2.0 | 0% | - | - | - | - | - | - | - | - |
| Opponent | REDIRECT COUNTER | 0.7 | 100% | 100% | 50% | 0% | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: cora-bb45c30-p39

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | 0 (1) | - | - | 0 (1) | - |
| Mine | Character | 11 | 35 (11) | 35 | 0 | 3 | 27% | 2.2 | 31 (8) | 51 (3) | - | 48 (8) | 0 (3) |
| Mine | Clean-up | 6 | 92 (6) | 0 | 92 | 0 | 83% | 4.0 | 16 (3) | 148 (2) | 250 (1) | 113 (5) | 0 (1) |
| Mine | Fast Hammer | 1 | 0 (1) | 0 | 0 | 0 | 0% | 1.0 | - | 0 (1) | - | - | 0 (1) |
| Mine | Hammer | 6 | 3 (6) | 3 | 0 | 0 | 33% | 3.5 | 0 (2) | 5 (4) | - | 0 (5) | 15 (1) |
| Mine | Holder | 2 | 76 (2) | 0 | 76 | 68 | 50% | 6.0 | 151 (1) | 0 (1) | - | 76 (2) | - |
| Mine | Shooter | 2 | 21 (2) | 0 | 21 | 0 | 0% | 2.0 | 0 (1) | 42 (1) | - | 21 (2) | - |
| Mine | War machine | 5 | 115 (5) | 115 | 0 | 20 | 0% | 1.2 | 87 (2) | 0 (1) | 199 (2) | - | 115 (5) |
| Opponent | Chaff | 4 | 0 (4) | 0 | 0 | 47 | 50% | 4.5 | 0 (4) | - | - | 0 (3) | 0 (1) |
| Opponent | Character | 9 | 11 (9) | 11 | 0 | 12 | 44% | 3.8 | 25 (3) | 0 (5) | 0 (1) | 14 (5) | 0 (4) |
| Opponent | Clean-up | 2 | 0 (2) | 0 | 0 | 57 | 100% | - | 0 (1) | 0 (1) | - | 0 (1) | 0 (1) |
| Opponent | Fast Hammer | 1 | 0 (1) | 0 | 0 | 0 | 0% | 3.0 | 0 (1) | - | - | - | 0 (1) |
| Opponent | Hammer | 3 | 0 (3) | 0 | 0 | 0 | 33% | 1.5 | - | 0 (3) | - | 0 (2) | 0 (1) |
| Opponent | Holder | 3 | 126 (3) | 14 | 112 | 0 | 33% | 3.5 | - | 163 (2) | 43 (1) | 186 (2) | 0 (1) |
| Opponent | Shooter | 3 | 67 (3) | 0 | 67 | 0 | 0% | 1.0 | - | 173 (1) | 14 (2) | 101 (2) | 0 (1) |
| Opponent | Support | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | War machine | 5 | 0 (5) | 0 | 0 | 23 | 20% | 1.0 | - | - | 0 (5) | - | 0 (5) |
| Opponent | Wizard | 5 | 0 (5) | 0 | 0 | 74 | 20% | 2.8 | 0 (3) | 0 (2) | - | 0 (2) | 0 (3) |

### Charged fights: cora-bb45c30-p39

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaos Dwarfs | 2 | 223 | 38 | 1.0 | 1.0 | 38 | 0 | +38 | 1 of 2 | 1 of 2 | - | +38 |
| Mine | Dwarfen Mountain Holds | 1 | 761 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| **Mine** | all armies | 3 | 402 | 25 | 0.7 | 1.0 | 38 | 0 | +38 | 1 of 2 | 1 of 2 | - | +38 |
| Opponent | Empire of Man | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Grand Cathay | 1 | 73 | 0 | 1.0 | 2.0 | 0 | 0 | +0 | 1 of 1 | 0 of 1 | +0 | - |
| Opponent | Vampire Counts | 1 | 0 | 189 | 2.0 | 1.5 | 94 | 106 | -11 | 1 of 2 | 2 of 2 | -211 | +189 |
| **Opponent** | all armies | 3 | 24 | 63 | 1.0 | 1.7 | 63 | 70 | -7 | 2 of 3 | 2 of 3 | -106 | +189 |

### Effective charges: cora-bb45c30-p39

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaos Dwarfs | 2 | 0 | 0 | 0 | 0 | 1 (net +75) | 0 | 1 | 0% (0 of 1) |
| Opponent | Grand Cathay | 1 | 0 | 0 | 1 (net +0) | 0 | 0 | 0 | 0 | 100% (1 of 1) |
| Opponent | Vampire Counts | 2 | 0 | 0 | 1 (net -211) | 1 (net +189) | 0 | 0 | 0 | 50% (1 of 2) |

### Charged fights, damage counted: cora-bb45c30-p39

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 339 | 75 | +75 | 75 | 0 | +75 | +22.1 |
| Mine | No odds | 1 | 480 | 348 | +0 | 0 | 0 | +0 | +0.0 |
| Mine | All fights | 2 | 410 | 212 | +38 | 38 | 0 | +38 | +9.2 |
| Opponent | Effective (55-75%) | 2 | 390 | 289 | -106 | 15 | 179 | -165 | -42.1 |
| Opponent | 76-89% | 1 | 480 | 139 | +189 | 189 | 0 | +189 | +39.4 |
| Opponent | All fights | 3 | 420 | 239 | -7 | 73 | 120 | -47 | -11.1 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| cora-bb45c30-p39 | move | 9 | 1 (11%) | 1 (11%) | 1 (11%) | 7 (78%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L0425 |
| Clockwork Compass | Opponent | L0512 |
| Invocation of Nehek | Opponent | L0425 |
| Ring of Doom | Opponent | L0512 |
| Ring of Jet | Opponent | L0512 |

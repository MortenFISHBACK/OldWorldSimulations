# Doctrine scorecard: cora-bb45c30-p18

### Scorecard: cora-bb45c30-p18

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0918 | 6 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 125 |
| L0918 | 6 | 1 | Opponent | no | 3 | - | 2 | 2 | 0 | 0 | 0 | 0 |
| L0934 | 4 | 1 | Mine | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 626 |
| L0934 | 4 | 1 | Opponent | no | 6 | 3 | 4 | 5 | 0 | 0 | 0 | 0 |
| L1026 | 6 | 1 | Mine | - | - | - | - | - | - | - | - | - |
| L1026 | 6 | 1 | Opponent | - | - | - | - | - | - | - | - | - |
| **Average** | | | Mine | 0% | 0.0 | - | 0.0 | 1.5 | 0.0 | 0.0 | 0.0 | 375.5 |
| **Average** | | | Opponent | 0% | 4.5 | 3.0 | 3.0 | 3.5 | 0.0 | 0.0 | 0.0 | 0.0 |

### KPIs: cora-bb45c30-p18

Rules off - Mine only: ONE RUN A PLAN.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 40% (4 of 10) | 0% (0 of 10) | 20% (4 of 20) |
| Winner chose to follow up after the loser gave ground |  | 50% (1 of 2); on the table 50% | 100% (4 of 4); on the table 100% | 83% (5 of 6); on the table 83% |
| Winner chose to pursue after the loser fell back in good order |  | - | - | - |
| Winner chose to pursue after the loser fled |  | - | - | - |
| Winner chose to follow up or pursue (all three) |  | 50% (1 of 2); on the table 50% | 100% (4 of 4); on the table 100% | 83% (5 of 6); on the table 83% |
| Magic missiles tried each own turn | 50%+ | 39% (14 of 36) | 0% (0 of 9) | 31% (14 of 45) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 42% (14 of 33) | 0% (0 of 9) | 33% (14 of 42) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | - | - |
| Points that never fought | lower | 75% (2989 of 3998) | 81% (3239 of 3998) | 78% (6228 of 7996) |
|   infantry points that never fought | lower | 57% (815 of 1420) | 100% (670 of 670) | 71% (1485 of 2090) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 71% (17 of 24) | 73% (11 of 15) | 72% (28 of 39) |
| Bound items with a magic missile used (at least once a game) |  | 50% (1 of 2); 0.7 uses a game | 100% (1 of 1); 1.3 uses a game | 67% (2 of 3); 1.0 uses a game |
| Bound items with another spell used |  | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0% (0 of 1); 0.0 uses a game | 0% (0 of 1); 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |
|   their share of the points of units over 100 pts | lower | 73% (2660 of 3668) | 74% (2516 of 3391) | 73% (5176 of 7059) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 5.3 (73%) | 0.0 (0%) | 5.3 (52%) |
| MARCHED: its unit marched | 1.0 (14%) | 1.0 (33%) | 2.0 (19%) |
| IN COMBAT: engaged in combat | 1.0 (14%) | 0.0 (0%) | 1.0 (10%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.7 (22%) | 0.7 (6%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 1.3 (44%) | 1.3 (13%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 2.0 | 0.0 | 4.7 | 0.0 | 0.3 |
| not cast | 2.0 | 4.0 | 10.3 | 2.0 | 8.7 |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 2.0 (50%) | 5.3 (52%) | 1.3 (67%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 2.0 (19%) | 0.3 (17%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.0 (0%) | 1.0 (10%) | 0.3 (17%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 2.0 (100%) | 2.0 (50%) | 0.7 (6%) | 0.0 (0%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 1.3 (13%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 8.7 (100%) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 71% (80 of 112) | 82% (66 of 80) | 76% (146 of 192) |
|   cavalry | - | 83% (10 of 12) | 83% (10 of 12) |
|   character | 100% (11 of 11) | 82% (14 of 17) | 89% (25 of 28) |
|   chariot | 92% (11 of 12) | 100% (11 of 11) | 96% (22 of 23) |
|   infantry | 52% (25 of 48) | 71% (20 of 28) | 59% (45 of 76) |
|   monster | 88% (7 of 8) | 92% (11 of 12) | 90% (18 of 20) |
|   war machine | 79% (26 of 33) | - | 79% (26 of 33) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.7 (25%) | 3.3 (71%) | 6.0 (39%) |
| CHARGED: it charged | 0.0 (0%) | 0.7 (14%) | 0.7 (4%) |
| IN COMBAT: it fought this turn or the last | 1.3 (12%) | 0.0 (0%) | 1.3 (9%) |
| MOVED: a war machine that moved | 1.7 (16%) | 0.0 (0%) | 1.7 (11%) |
| NO TARGET IN RANGE | 2.3 (22%) | 0.0 (0%) | 2.3 (15%) |
| ONLY IN COMBAT: the only targets were in combat | 0.3 (3%) | 0.0 (0%) | 0.3 (2%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.7 (16%) | 0.7 (14%) | 2.3 (15%) |
| SHELTERED: the target was sheltered | 0.7 (6%) | 0.0 (0%) | 0.7 (4%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 6.7 | 0.0 | 100% | 0.0 pts | 0 pts |
| character | 8.3 | 1.7 | 84% | 3.9 pts | 33 pts |
| chariot | 7.3 | 7.0 | 55% | 19.0 pts | 139 pts |
| infantry | 16.3 | 6.3 | 67% | 6.7 pts | 109 pts |
| monster | 8.3 | 0.7 | 92% | 0.6 pts | 5 pts |
| war machine | 8.7 | 5.7 | 69% | 12.9 pts | 112 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 0.7 | 2.7 | 1.7 |
| Charges that made contact a game | 0.7 | 2.3 | 1.5 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.67 declared, 0.67 contact (3 units) | 0.00 declared, 0.00 contact (1 units) | 0.50 declared, 0.50 contact (4 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 0.00 declared, 0.00 contact (1 units) | 0.00 declared, 0.00 contact (1 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.00 declared, 0.00 contact (22 units) | 0.26 declared, 0.23 contact (31 units) | 0.15 declared, 0.13 contact (53 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 50% (1 of 2) | - | - | 50% (1 of 2) |
| Character in a unit | 75% (3 of 4) | 100% (1 of 1) | - | 80% (4 of 5) |
| Character on its own | - | 100% (1 of 1) | 50% (1 of 2) | 67% (2 of 3) |
| Chariot | 100% (2 of 2) | 50% (1 of 2) | - | 75% (3 of 4) |
| Infantry | 50% (5 of 10) | 100% (2 of 2) | - | 58% (7 of 12) |
| Monster | - | 100% (1 of 1) | - | 100% (1 of 1) |
| Monstrous | 50% (1 of 2) | 100% (4 of 4) | - | 83% (5 of 6) |
| War Machines | 83% (5 of 6) | - | - | 83% (5 of 6) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Empire of Man | 2 | 50% (1 of 2); on the table 50% | 54% (13 of 24) | 75% | 71% (17 of 24) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 1 | - | 0% (0 of 6) | 94% | 100% (7 of 7) | 100% (1 of 1); 4.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 1 | 100% (4 of 4); on the table 100% | - | 68% | 50% (4 of 8) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (cora-bb45c30-p18, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 75% (3) | 50% (1) | 67% (4) |
| ...free all their last turn and able to turn (per game) | 1.00 | 0.33 | 1.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 1.00 | 0.00 | 1.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: cora-bb45c30-p18

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.3 | 2.0 |
| Strategy | Charge objectives carried out (made contact) | 100% (1 of 1) | 83% (5 of 6) |
| Strategy | Shoot objectives carried out (shot that target) | 40% (21 of 53) | 76% (22 of 29) |
| Strategy | Support requests answered (helper made contact too) | - | 100% (1 of 1) |
| Strategy | Joined characters whose unit fought | 25% (2 of 8) | 0% (0 of 1) |
| Strategy | Lone characters that fought | 0% (0 of 2) | 33% (1 of 3) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 1.5 | 3.5 |
| Movement | Points that never moved of their own | 375.5 | 0.0 |
| Movement | Fights charged into per game | 0.0 | 3.5 |
| Movement | Charges with odds: long shots (under 50%) | - | 1 of 5, net +0 |
| Movement | Charges with odds: sweet spot (55-75%) | - | 0 of 5 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | - | 0 of 5 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | - | 2 of 5, net +166 |
| Shooting | Shots by shooting units (incl. breath weapons) | 18.0 | 22.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 13% (7 of 54) | 52% (35 of 67) |
| Shooting | Points destroyed by shooting units | 9.0 | 0.0 |
| Shooting | War machine shots | 8.7 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 62% (16 of 26) | - |
| Shooting | Points destroyed by war machines | 73.0 | 0.0 |
| Magic | Magic missiles cast | 1.3 | - |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 0% (0 of 4) | - |
| Magic | Wounds caused by magic missiles | 5.7 | 2.0 |
| Magic | Wounds caused by other spells | 2.0 | - |
| Magic | Points destroyed by magic (all spells) | 18.7 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.0 / 0.0 / 0.3 / 0.0 | 1.3 / 0.0 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 11.3 | 34.7 |
| Combat | Points run down | 0.0 | 75.7 |
| Combat | Net points per charged fight, damage counted | - | +36 |
| Combat | Net per 100 charger points, damage counted | - | +26.3 |
| Combat | First round won (charged fights) | - | 57% |
| Combat | Net points per charged fight | - | +57 |
| Combat | Net points per supported fight / lone fight | - / - | - / +57 |
| Combat | Charged fights on a top-3 enemy unit | - | 1 of 7 |
| Game | Points lost | 393.5 | 168.0 |
| Game | VP from objectives | 545.0 | 850.0 |
| Game | Lone holders (player turns) | 0.0 | 4.5 |

- Mine won / drew / lost: 0 / 0 / 2 of 2 ended games (of 3); mean margin (Mine - Opponent) -530 VP
- The side that went first won 1 of 2 games with a winner
- Points traded per game (both sides' losses): 562
- Games not ended: 1 (L1026-1); findings 1, warnings 0

### Opponent rules: cora-bb45c30-p18

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.3 | +2.5 | 0.0 | 34.7 | - | - | - | - |
| ARMY TABLE | 10.7 | +149.3 | 0.0 | 151.3 | 25.3 | +307.3 | 0.0 | 55.3 |
| ARRIVAL HUNT | - | - | - | - | 0.3 | +15.6 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 4.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CANNON PLAN MISSED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CANNON PLANNED TARGET | 9.0 | +42.5 | 34.0 | 41.7 | - | - | - | - |
| CANNON SIGHT KEPT | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CAST JOB | 2.7 | +74.7 | 0.0 | 0.0 | - | - | - | - |
| CASTER AWAY FROM SCREEN | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | - | - | - | - | 1.3 | +29.1 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | - | - | - | - | 1.7 | +31.4 | 0.0 | 9.0 |
| CHAFF PASSED | 0.3 | -2.4 | 0.0 | 0.0 | - | - | - | - |
| CHALLENGE BY POINTS | 0.3 | +11.3 | 0.0 | 75.7 | - | - | - | - |
| CHARACTER GUNS | 7.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHARGE LOSSES | 15.0 | -515.8 | 0.0 | 151.3 | 19.3 | -779.0 | 0.0 | 0.0 |
| CHARGE NOW FIRST | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 7.7 | +0.0 | 0.0 | 0.0 | 17.0 | +0.0 | 0.0 | 11.3 |
| COVER ONCE | 9.7 | -341.5 | 0.0 | 152.0 | 1.7 | -284.9 | 0.0 | 0.0 |
| DEFENSIVE ARMY | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| DENIED BY THE FIGHT | - | - | - | - | 1.7 | -14.4 | 110.3 | 0.0 |
| DEPLOY BY FIGURES | 9.0 | -55.1 | 0.0 | 0.0 | 9.0 | +40.5 | 0.0 | 0.0 |
| EVASIVE BY THE ODDS | - | - | - | - | 1.0 | +2.0 | 75.7 | 0.0 |
| EXACT ROUND | 0.7 | -0.1 | 0.0 | 0.0 | 1.3 | -14.0 | 34.7 | 0.0 |
| FALL BACK GOOD ORDER | 0.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.1 | 110.3 | 0.0 |
| FALLS SHORT | - | - | - | - | 30.7 | +354.0 | 0.0 | 110.3 |
| FEATURE BUFFS | - | - | - | - | 0.7 | +12.7 | 0.0 | 0.0 |
| FIGHT TO THE END | - | - | - | - | 0.7 | +0.2 | 0.0 | 0.0 |
| FIVE ACTION | 88.0 | +3876.0 | 370.0 | 538.7 | 99.3 | +4820.7 | 447.7 | 281.7 |
| FLANK NOT WEIGHED | 5.3 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 0.0 |
| FOCUS FIRE | 0.3 | +0.2 | 0.0 | 0.0 | - | - | - | - |
| FOLLOW UP WEIGHED | 0.3 | +17.9 | 0.0 | 0.0 | - | - | - | - |
| FOUR ROUNDS | 0.7 | +38.2 | 0.0 | 0.0 | 2.0 | +60.7 | 145.0 | 0.0 |
| FREED FROM HIS FIGHT | 1.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| GIVES UP | 0.3 | -4.3 | 0.0 | 0.0 | - | - | - | - |
| GIVES UP ITS SCREEN | - | - | - | - | 0.3 | -1.8 | 34.7 | 0.0 |
| GOAL WALK | 9.0 | +450.5 | 0.0 | 0.0 | 24.0 | +2203.7 | 0.0 | 0.0 |
| GUN FIGURES | 2.7 | +31.5 | 70.7 | 0.0 | 0.7 | +7.7 | 0.0 | 0.0 |
| GUN MASK | 2.7 | +163.8 | 0.0 | 0.0 | - | - | - | - |
| HARD STAY DROPPED | 3.3 | +0.0 | 0.0 | 75.7 | 5.7 | +0.0 | 0.0 | 61.7 |
| HE REFORMS ONCE FREED | 1.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 9.3 | +0.0 | 0.0 | 0.0 | 5.3 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE LIST | 2.3 | +0.0 | 0.0 | 75.7 | 4.7 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 3.7 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 22.7 |
| HIS MOVE AND SHOT | 1.7 | -5.4 | 0.0 | 0.0 | 6.3 | -55.5 | 0.0 | 74.7 |
| HIS ONE QUARTER | 0.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 4.3 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 22.7 |
| HIS RUN AFTER OUR TURN | 5.0 | +0.0 | 0.0 | 0.0 | 4.7 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 37.3 | +1209.2 | 0.0 | 310.3 | 72.3 | +5255.8 | 0.0 | 121.0 |
| HIS SHOTS BY HIS RUN | 30.3 | +647.7 | 0.0 | 227.0 | 60.7 | +1425.5 | 0.0 | 121.0 |
| HIS TURN DENIED | - | - | - | - | 2.0 | +44.4 | 145.0 | 0.0 |
| HIS TURN RUN | 5.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HOLD ODDS | 13.0 | +0.0 | 0.0 | 0.0 | 16.3 | +0.0 | 0.0 | 0.0 |
| HOLDER ASSIGNMENT | 10.3 | +1089.5 | 0.0 | 34.7 | 13.7 | +1203.7 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 0.7 | -21.5 | 0.0 | 0.0 | 1.7 | -32.0 | 145.0 | 0.0 |
| IDLE COST | - | - | - | - | 21.0 | -310.7 | 0.0 | 11.3 |
| JOINT CHARGE NOW | - | - | - | - | 1.0 | +0.4 | 69.3 | 0.0 |
| KEPT FROM ITS LAST STOP | 5.0 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 0.7 | +15.4 | 0.0 | 0.0 | 1.3 | +93.2 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| LEGAL CHARGES ONLY | 2.3 | +0.0 | 9.0 | 104.0 | 3.0 | +0.0 | 69.3 | 34.0 |
| LONE WIZARD KEPT IN | 1.3 | +43.3 | 0.0 | 0.0 | - | - | - | - |
| LONG SHOT | - | - | - | - | 0.7 | +5.7 | 34.7 | 0.0 |
| LOST AFTER ESCAPE | 0.3 | -0.4 | 0.0 | 0.0 | 1.7 | +0.5 | 145.0 | 0.0 |
| MAKE SURE TOGETHER | - | - | - | - | 1.0 | +6.9 | 0.0 | 0.0 |
| MANOEUVRE | 1.3 | -3.3 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 18.7 |
| MARCH BY THE SUM | 0.7 | +21.5 | 0.0 | 0.0 | 0.3 | +16.9 | 0.0 | 0.0 |
| MARCH CHECK | 1.7 | +83.4 | 0.0 | 0.0 | 0.7 | +34.8 | 0.0 | 0.0 |
| MARCH OF THE TABLE | 0.3 | +6.7 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 0.7 | -19.8 | 0.0 | 0.0 | 0.3 | -0.7 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 4.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 0.7 | +2.0 | 0.0 | 0.0 | 2.0 | +16.5 | 0.0 | 22.7 |
| MEETS IN TIME | 3.7 | +414.2 | 0.0 | 0.0 | 3.7 | +549.1 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 7.7 | +130.0 | 0.0 | 0.0 | 1.3 | +29.1 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 9.3 | +94.5 | 0.0 | 0.0 | 2.3 | +23.4 | 0.0 | 0.0 |
| MOVE ORDER | 0.7 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 11.3 | 11.3 |
| MOVE TO CHARGE COMPUTED | 2.0 | +74.6 | 0.0 | 0.0 | 2.0 | +90.6 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 4.7 | +196.5 | 0.0 | 0.0 | 5.3 | +220.1 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 0.3 | +7.9 | 0.0 | 0.0 | 1.7 | +71.9 | 0.0 | 0.0 |
| NEXT OBJECTIVE NEARER | - | - | - | - | 0.7 | -16.5 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 0.7 | -16.2 | 0.0 | 0.0 | 1.7 | -69.3 | 110.3 | 0.0 |
| NO LATE CUT | 3.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 5.0 | +0.0 | 0.0 | 0.0 | 5.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 5.0 | +0.0 | 0.0 | 0.0 | 5.0 | +0.0 | 0.0 | 0.0 |
| OFF BEST | 4.3 | -90.2 | 0.0 | 0.0 | 4.0 | -20.0 | 0.0 | 45.7 |
| OGRE LOADER SECOND SHOT | 2.7 | +5.4 | 0.0 | 0.0 | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ONE FIGHT FORMULA | 4.0 | -48.9 | 0.0 | 0.0 | 3.0 | -68.5 | 0.0 | 11.3 |
| ONE JOINT FIGURE | - | - | - | - | 0.3 | -6.4 | 34.7 | 0.0 |
| ONE OBJECTIVE FORMULA | 3.0 | +10.0 | 0.0 | 34.7 | 5.7 | -71.0 | 0.0 | 0.0 |
| ONE ROUTE | 4.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| ONE RUN A PLAN | - | - | - | - | 5.0 | +0.0 | 0.0 | 0.0 |
| OVERRUNS AWAY | - | - | - | - | 0.7 | +2.2 | 75.7 | 0.0 |
| PLAN RESULT | 37.0 | +382.9 | 153.3 | 455.3 | 43.7 | +497.6 | 413.0 | 201.3 |
| PROMISE BY ITS OWN SUM | 5.7 | -106.9 | 0.0 | 0.0 | 3.0 | -128.0 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE READS THE TABLE | 0.3 | -16.3 | 0.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | 10.0 | +806.9 | 18.0 | 0.0 | 13.3 | +897.0 | 75.7 | 18.0 |
| REAL GROUND | 4.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| REDIRECT BY WHAT IT STOPS | - | - | - | - | 0.3 | +15.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | - | - | - | - | 5.3 | +295.0 | 0.0 | 0.0 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 5.3 | +22.4 | 0.0 | 40.7 |
| RESERVE FALL BACK | - | - | - | - | 1.3 | +41.5 | 0.0 | 0.0 |
| RISK BY ARC | 0.7 | +36.1 | 0.0 | 0.0 | 1.3 | -54.9 | 75.7 | 0.0 |
| RISK ON THE WAY | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| ROUNDS AFTER TERROR | - | - | - | - | 0.3 | -11.5 | 75.7 | 0.0 |
| RUN DOWN | - | - | - | - | 2.0 | -5.9 | 145.0 | 0.0 |
| SCOUT SPOT | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +7.2 | 0.0 | 0.0 |
| SCOUT WAITS | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 1.7 | -88.7 | 0.0 | 9.0 |
| SEARCH SPOT | 0.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.7 | 0.0 | 0.0 |
| SECOND LOOK | 0.3 | +7.8 | 0.0 | 0.0 | - | - | - | - |
| SET UP BY THE SET | 1.0 | -16.1 | 0.0 | 0.0 | - | - | - | - |
| SET UP TOGETHER | - | - | - | - | 1.0 | +6.9 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.7 | +1.3 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS ON THE TABLE | 18.0 | +0.0 | 0.0 | 152.0 | 10.7 | +0.0 | 0.0 | 89.3 |
| SHOOTS FROM THE BEST SPOT | 2.7 | +35.1 | 0.0 | 0.0 | 3.0 | +13.8 | 0.0 | 0.0 |
| SHOT RISK POINTS | 19.3 | -350.0 | 0.0 | 234.7 | 48.0 | -651.5 | 0.0 | 112.0 |
| SHOTS AFTER THE MOVES | 5.0 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 30.0 | +950.6 | 0.0 | 227.7 | 21.7 | +411.1 | 0.0 | 99.0 |
| SPELL WORTH | - | - | - | - | 2.0 | +21.2 | 0.0 | 0.0 |
| SPOT AS THE GAME MOVES | 3.0 | +0.0 | 0.0 | 0.0 | 7.7 | +0.0 | 0.0 | 20.3 |
| STAND AND SHOOT | - | - | - | - | 0.7 | -3.2 | 34.7 | 0.0 |
| STANDS FOR A REASON | - | - | - | - | 9.3 | +0.0 | 0.0 | 37.3 |
| STANDS STILL | 51.7 | +0.0 | 370.0 | 463.0 | 31.7 | +0.0 | 302.7 | 207.0 |
| STAY WORTH | 47.3 | +486.6 | 246.7 | 304.7 | 31.0 | +387.8 | 302.7 | 259.7 |
| STRIKE BY THE ODDS | - | - | - | - | 0.3 | +0.2 | 0.0 | 11.3 |
| SUPPORT ADDS | 1.0 | +3.8 | 0.0 | 75.7 | 1.3 | +14.4 | 0.0 | 9.0 |
| SUPPORT WORKED OUT | 1.0 | +3.8 | 0.0 | 75.7 | 1.3 | +14.4 | 0.0 | 9.0 |
| SURE REACH TOGETHER | - | - | - | - | 0.7 | +1.6 | 0.0 | 9.0 |
| THE DEARER SUM KEEPS ITS PLAN | 1.3 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| THE PROMISE ADDS | 0.3 | -7.9 | 0.0 | 0.0 | 0.3 | -12.2 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 2.3 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 9.0 |
| THE ROW KEEPS ITS WAY | 2.0 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 1.3 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 5.0 | +0.0 | 0.0 | 0.0 | 5.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 39.3 | +0.0 | 0.0 | 227.7 | 49.0 | +0.0 | 0.0 | 139.7 |
| TIED UP BY THE SUM | 0.3 | +47.5 | 0.0 | 0.0 | 0.3 | +64.5 | 75.7 | 0.0 |
| TIME ON OUR SIDE | 42.3 | +545.3 | 37.3 | 488.7 | - | - | - | - |
| WAITS AGAIN | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| WALKS ON ITS ROUTE | - | - | - | - | 0.3 | -3.3 | 0.0 | 0.0 |
| WAR ENGINE JOBS | - | - | - | - | 5.3 | +0.0 | 302.7 | 123.3 |
| WHO FIGHTS | - | - | - | - | 1.0 | -3.3 | 69.3 | 0.0 |
| WHO HITS BACK | 0.3 | +2.5 | 0.0 | 0.0 | 0.7 | +35.4 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | 1.7 | -69.5 | 0.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT GAIN | - | - | - | - | 0.7 | +16.8 | 34.7 | 0.0 |
| WOUNDS ON THE RANKS | 4.3 | +57.8 | 0.0 | 0.0 | - | - | - | - |

### Rule changes: cora-bb45c30-p18

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS SHOT LIST | 329 | 320 | 143 | 47.67 | +2185 | +15.3 |
| ARMY TABLE | 108 | 108 | 98 | 32.67 | +1334 | +13.6 |
| HIS SHOTS BY HIS RUN | 273 | 264 | 85 | 28.33 | +908 | +10.7 |
| HOLDER ASSIGNMENT | 72 | 72 | 66 | 22.00 | +3379 | +51.2 |
| GOAL WALK | 99 | 98 | 35 | 11.67 | +1403 | +40.1 |
| DEPLOY BY FIGURES | 54 | 54 | 32 | 10.67 | +492 | +15.4 |
| SHOT RISK POINTS | 202 | 194 | 28 | 9.33 | +438 | +15.6 |
| HARD STAY DROPPED | 27 | 27 | 27 | 9.00 | +0 | +0.0 |
| OFF BEST | 25 | 25 | 25 | 8.33 | -331 | -13.2 |
| STAY WORTH | 235 | 216 | 23 | 7.67 | +204 | +8.9 |
| MEETS IN TIME | 22 | 22 | 18 | 6.00 | +1382 | +76.8 |
| TIME ON OUR SIDE | 127 | 106 | 18 | 6.00 | +124 | +6.9 |
| THE TABLE AGAIN | 30 | 30 | 17 | 5.67 | +0 | +0.0 |
| LEGAL CHARGES ONLY | 16 | 16 | 16 | 5.33 | +0 | +0.0 |
| REDIRECT FOR A FRIEND IN REACH | 16 | 16 | 15 | 5.00 | +0 | +0.0 |
| ARTILLERY RE-ROLL WEIGHED | 14 | 14 | 14 | 4.67 | +0 | +0.0 |
| MOVE ORDER | 14 | 14 | 14 | 4.67 | +0 | +0.0 |
| IDLE COST | 63 | 41 | 13 | 4.33 | +81 | +6.2 |
| PROMISE BY ITS OWN SUM | 26 | 26 | 11 | 3.67 | -705 | -64.1 |
| FIVE ACTION | 562 | 547 | 10 | 3.33 | +202 | +20.2 |
| OGRE LOADER SECOND SHOT | 8 | 8 | 8 | 2.67 | +16 | +2.0 |
| CHARGE LOSSES | 103 | 100 | 7 | 2.33 | +131 | +18.7 |
| MOVE TO CHARGE COMPUTED | 12 | 9 | 7 | 2.33 | +89 | +12.7 |
| SHOOTS FROM THE BEST SPOT | 17 | 17 | 7 | 2.33 | +72 | +10.2 |
| FALLS SHORT | 92 | 76 | 6 | 2.00 | +70 | +11.7 |
| GUN MASK | 8 | 8 | 6 | 2.00 | +235 | +39.1 |
| LANE BY FIGURES | 6 | 6 | 6 | 2.00 | +326 | +54.3 |
| MARCH CHECK | 7 | 7 | 5 | 1.67 | +63 | +12.7 |
| MAX FOR POSITIONING | 8 | 6 | 5 | 1.67 | +1 | +0.2 |
| NEXT CHARGE BY LIST | 6 | 5 | 5 | 1.67 | +89 | +17.7 |
| SCOUT WAITS | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| WOUNDS ON THE RANKS | 13 | 13 | 5 | 1.67 | +18 | +3.6 |
| ADVANCE LANE KEPT | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| CAST JOB | 8 | 8 | 4 | 1.33 | +112 | +27.9 |
| LONE WIZARD KEPT IN | 4 | 4 | 4 | 1.33 | +130 | +32.5 |
| QUARTER ODDS | 70 | 69 | 4 | 1.33 | +242 | +60.4 |
| RESERVE FALL BACK | 4 | 4 | 4 | 1.33 | +124 | +31.1 |
| SHOTS IN THE MOVE | 155 | 133 | 4 | 1.33 | +150 | +37.4 |
| CANNON PLANNED TARGET | 27 | 27 | 3 | 1.00 | -23 | -7.7 |
| CANNON SIGHT KEPT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| COVER ONCE | 34 | 26 | 3 | 1.00 | +90 | +30.0 |
| JOINT CHARGE NOW | 3 | 3 | 3 | 1.00 | +1 | +0.4 |
| MARCH BY THE SUM | 3 | 3 | 3 | 1.00 | +115 | +38.4 |
| NEARER NOT NEEDED | 30 | 29 | 3 | 1.00 | +69 | +23.0 |
| WHO HITS BACK | 3 | 3 | 3 | 1.00 | +59 | +19.7 |
| CASTER AWAY FROM SCREEN | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| CASTING BLOCK | 4 | 4 | 2 | 0.67 | +23 | +11.7 |
| FOUR ROUNDS | 8 | 7 | 2 | 0.67 | +45 | +22.6 |
| HIS MOVE AND SHOT | 24 | 21 | 2 | 0.67 | +6 | +2.8 |
| MISSILES NEXT TURN | 35 | 24 | 2 | 0.67 | +1 | +0.5 |
| SEARCH SPOT | 4 | 4 | 2 | 0.67 | +15 | +7.5 |
| SHOOTERS IN TWO RANKS | 2 | 2 | 2 | 0.67 | +4 | +2.0 |
| SUPPORT ADDS | 7 | 7 | 2 | 0.67 | +5 | +2.7 |
| SUPPORT WORKED OUT | 7 | 7 | 2 | 0.67 | +5 | +2.7 |
| SURE REACH TOGETHER | 2 | 2 | 2 | 0.67 | +3 | +1.5 |
| TIED UP BY THE SUM | 2 | 2 | 2 | 0.67 | +45 | +22.6 |
| AFTERMATH IN POINTS | 1 | 1 | 1 | 0.33 | +8 | +7.5 |
| CHAFF PASSED | 1 | 1 | 1 | 0.33 | -7 | -7.1 |
| CHALLENGE BY POINTS | 1 | 1 | 1 | 0.33 | +34 | +33.9 |
| CHARGE NOW FIRST | 3 | 3 | 1 | 0.33 | -43 | -42.9 |
| EVASIVE BY THE ODDS | 3 | 3 | 1 | 0.33 | +0 | +0.0 |
| FOCUS FIRE | 1 | 1 | 1 | 0.33 | +1 | +0.7 |
| FOLLOW UP WEIGHED | 1 | 1 | 1 | 0.33 | +54 | +53.6 |
| HIS TURN DENIED | 6 | 6 | 1 | 0.33 | +19 | +19.1 |
| HOLDS AMBUSHERS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| MANOEUVRE | 10 | 10 | 1 | 0.33 | +3 | +3.1 |
| MARCH OF THE TABLE | 1 | 1 | 1 | 0.33 | -20 | -20.0 |
| MISSILES IN THE MOVE | 27 | 22 | 1 | 0.33 | +0 | +0.0 |
| NEXT OBJECTIVE NEARER | 2 | 1 | 1 | 0.33 | +5 | +4.6 |
| ONE FIGHT FORMULA | 21 | 15 | 1 | 0.33 | +12 | +12.0 |
| OVERRUNS AWAY | 2 | 2 | 1 | 0.33 | +3 | +3.4 |
| PROMISE READS THE TABLE | 1 | 1 | 1 | 0.33 | -38 | -38.1 |
| REDIRECT COUNTER | 16 | 14 | 1 | 0.33 | +39 | +38.7 |
| RISK BY ARC | 6 | 5 | 1 | 0.33 | +42 | +41.8 |
| SCREEN BY WHAT IT SAVES | 5 | 5 | 1 | 0.33 | +17 | +16.7 |
| SECOND LOOK | 1 | 1 | 1 | 0.33 | +23 | +23.4 |
| SET UP BY THE SET | 3 | 3 | 1 | 0.33 | +9 | +9.1 |
| SHOTS AFTER THE MOVES | 27 | 27 | 1 | 0.33 | +0 | +0.0 |
| STRIKE BY THE ODDS | 1 | 1 | 1 | 0.33 | +1 | +0.6 |
| THE ROW IN ITS ORDER | 18 | 1 | 1 | 0.33 | +0 | +0.0 |
| WALKS ON ITS ROUTE | 1 | 1 | 1 | 0.33 | -10 | -9.9 |
| WHOLE FIGHT GAIN | 2 | 2 | 1 | 0.33 | +19 | +19.1 |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 1 | 1 | 0 | 0.00 | - | - |
| CHAFF IN THE MOVE | 5 | 3 | 0 | 0.00 | - | - |
| CHARACTER GUNS | 22 | 22 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 74 | 72 | 0 | 0.00 | - | - |
| DEFENSIVE ARMY | 2 | 2 | 0 | 0.00 | - | - |
| DENIED BY THE FIGHT | 5 | 5 | 0 | 0.00 | - | - |
| EXACT ROUND | 6 | 5 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 6 | 6 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 2 | 2 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 2 | 2 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 27 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 6 | 6 | 0 | 0.00 | - | - |
| GIVES UP | 1 | not checked | - | - | - | - |
| GIVES UP ITS SCREEN | 1 | 1 | 0 | 0.00 | - | - |
| GUN FIGURES | 10 | not checked | - | - | - | - |
| HE REFORMS ONCE FREED | 6 | 6 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 44 | 43 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 21 | 20 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 17 | 14 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 6 | 6 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 23 | 20 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 29 | 29 | 0 | 0.00 | - | - |
| HIS TURN RUN | 15 | 15 | 0 | 0.00 | - | - |
| HOLD ODDS | 88 | 88 | 0 | 0.00 | - | - |
| HONEST WORTH | 7 | 6 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 21 | 21 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 2 | 2 | 0 | 0.00 | - | - |
| LONG SHOT | 2 | 2 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 6 | 5 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 3 | not checked | - | - | - | - |
| MARCH OVER CASTS | 3 | 3 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 14 | 14 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 7 | 6 | 0 | 0.00 | - | - |
| NO LATE CUT | 12 | 12 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 30 | 30 | 0 | 0.00 | - | - |
| NO SECOND RUN | 30 | 30 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 4 | not checked | - | - | - | - |
| ONE JOINT FIGURE | 1 | 1 | 0 | 0.00 | - | - |
| ONE OBJECTIVE FORMULA | 26 | 21 | 0 | 0.00 | - | - |
| ONE ROUTE | 14 | 14 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 15 | 15 | 0 | 0.00 | - | - |
| PLAN RESULT | 242 | trace | - | - | - | - |
| PROMISE KNOWS THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| REAL GROUND | 14 | 14 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 1 | 1 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 2 | 2 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 1 | 1 | 0 | 0.00 | - | - |
| RUN DOWN | 6 | 6 | 0 | 0.00 | - | - |
| SCOUT SPOT | 4 | 4 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 3 | 3 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 86 | not checked | - | - | - | - |
| SPELL WORTH | 6 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 32 | 29 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 2 | 2 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 28 | 26 | 0 | 0.00 | - | - |
| STANDS STILL | 250 | 243 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 10 | not checked | - | - | - | - |
| THE PROMISE ADDS | 2 | 1 | 0 | 0.00 | - | - |
| THE ROW KEEPS ITS WAY | 14 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 10 | not checked | - | - | - | - |
| THE TABLE BINDS | 265 | not checked | - | - | - | - |
| WAITS AGAIN | 3 | 3 | 0 | 0.00 | - | - |
| WAR ENGINE JOBS | 16 | 16 | 0 | 0.00 | - | - |
| WHO FIGHTS | 3 | 3 | 0 | 0.00 | - | - |
| WHOLE FIGHT DANGER | 5 | 5 | 0 | 0.00 | - | - |

### Off best figure: cora-bb45c30-p18

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 4.00 | 2.33 | 15.3 |
| PROMISE BY ITS OWN SUM | rule | 2.67 | 1.00 | 64.1 |
| ARMY TABLE | rule | - | 1.67 | 58.1 |
| HOLDER ASSIGNMENT | rule | 0.67 | 1.00 | 20.0 |
| NO REASON | gate | - | 1.33 | 3.4 |
| CANNON PLANNED TARGET | rule | 0.33 | - | 23.2 |
| CHAFF PASSED | rule | 0.33 | - | 7.1 |
| CHARGE NOW FIRST | rule | 0.33 | - | 42.9 |
| FALLBACK | gate | - | 0.33 | 12.8 |
| JOINT CHARGE NOW | rule | - | 0.33 | 46.6 |
| MARCH OF THE TABLE | rule | 0.33 | - | 20.0 |
| PROMISE READS THE TABLE | rule | 0.33 | - | 38.1 |
| RESERVE FALL BACK | rule | - | 0.33 | 4.3 |
| RULE SWITCHED OFF | gate | 0.33 | - | 13.0 |
| WALKS ON ITS ROUTE | rule | - | 0.33 | 9.9 |

### Plans: cora-bb45c30-p18

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 0.3 | 100% | 10 | 16 | 159% |
| Mine | move | 21.3 | 95% | 892 | 0 | 0% |
| Mine | shoot | 15.3 | 41% | 653 | 367 | 56% |
| Opponent | charge | 1.0 | 67% | 37 | 116 | 315% |
| Opponent | move | 34.3 | 94% | 1591 | 0 | 0% |
| Opponent | shoot | 7.7 | 52% | 504 | 382 | 76% |
| Opponent | support | 0.7 | 100% | 11 | 0 | 0% |

### Battle groups: cora-bb45c30-p18

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | REDIRECT COUNTER | 5.3 | 12% | 100% | 0% | - | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: cora-bb45c30-p18

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Character | 8 | 10 (8) | 10 | 0 | 0 | 25% | 3.2 | 8 (3) | 0 (3) | 32 (2) | 12 (6) | 0 (2) |
| Mine | Clean-up | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | - | 0 (1) | 0 (1) | - |
| Mine | Hammer | 7 | 13 (7) | 13 | 0 | 29 | 29% | 1.4 | 0 (1) | 3 (3) | 26 (3) | 18 (5) | 0 (2) |
| Mine | Shooter | 6 | 115 (6) | 4 | 111 | 33 | 0% | 2.0 | 0 (1) | 244 (2) | 67 (3) | 138 (5) | 0 (1) |
| Mine | War machine | 6 | 5 (6) | 5 | 0 | 17 | 0% | 1.2 | 0 (1) | 7 (4) | 0 (1) | - | 5 (6) |
| Mine | Wizard | 2 | 0 (2) | 0 | 0 | 0 | 0% | 3.0 | - | 0 (2) | - | 0 (2) | - |
| Opponent | Chaff | 7 | 194 (7) | 0 | 194 | 34 | 29% | 3.4 | 179 (2) | 117 (1) | 244 (4) | 194 (7) | - |
| Opponent | Character | 4 | 15 (4) | 15 | 0 | 0 | 0% | 1.5 | - | 31 (2) | 0 (2) | 23 (2) | 0 (2) |
| Opponent | Clean-up | 3 | 55 (3) | 0 | 55 | 0 | 33% | 1.0 | - | 84 (2) | 0 (1) | 55 (3) | - |
| Opponent | Early | 1 | 116 (1) | 116 | 0 | 0 | 0% | 5.0 | - | 116 (1) | - | 116 (1) | - |
| Opponent | Fragile | 1 | 0 (1) | 0 | 0 | 100 | 0% | 2.0 | 0 (1) | - | - | 0 (1) | - |
| Opponent | Hammer | 9 | 7 (9) | 7 | 0 | 12 | 44% | 1.4 | 0 (4) | 18 (3) | 0 (2) | 95 (1) | 0 (8) |
| Opponent | Shooter | 1 | 112 (1) | 0 | 112 | 0 | 0% | 1.0 | - | 112 (1) | - | 112 (1) | - |

### Charged fights: cora-bb45c30-p18

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Empire of Man | 2 | 151 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Ogre Kingdoms | 1 | 0 | 104 | 3.0 | 1.0 | 35 | 11 | +23 | 0 of 3 | 1 of 3 | - | +23 |
| Opponent | Wood Elf Realms | 1 | 0 | 331 | 4.0 | 1.0 | 83 | 0 | +83 | 1 of 4 | 3 of 4 | - | +83 |
| **Opponent** | all armies | 2 | 0 | 218 | 3.5 | 1.0 | 62 | 5 | +57 | 1 of 7 | 4 of 7 | - | +57 |

### Effective charges: cora-bb45c30-p18

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | Ogre Kingdoms | 3 | 0 | 0 | 0 | 1 (net +104) | 0 | 0 | 2 | 0% (0 of 1) |
| Opponent | Wood Elf Realms | 4 | 1 (net +0) | 0 | 0 | 1 (net +0) | 0 | 2 (net +166) | 0 | 0% (0 of 4) |

### Charged fights, damage counted: cora-bb45c30-p18

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | Long shot (under 50%) | 1 | 27 | 104 | +0 | 16 | 9 | +7 | +25.9 |
| Opponent | 76-89% | 2 | 100 | 104 | +52 | 52 | 0 | +52 | +52.3 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 304 | 166 | +166 | 200 | 112 | +88 | +28.8 |
| Opponent | No odds | 2 | 62 | 146 | -17 | 0 | 17 | -17 | -27.4 |
| Opponent | All fights | 7 | 137 | 134 | +57 | 74 | 38 | +36 | +26.3 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| cora-bb45c30-p18 | move | 9 | 1 (11%) | 1 (11%) | 1 (11%) | 7 (78%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L0934, L1026 |
| Fistful of Laurels | Opponent | L0918 |
| Ring of Jet | Mine | L1026 |
| Twice-Blessed Armour | Mine | L1026 |

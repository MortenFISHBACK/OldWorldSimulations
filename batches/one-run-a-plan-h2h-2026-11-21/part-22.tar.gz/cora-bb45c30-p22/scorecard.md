# Doctrine scorecard: cora-bb45c30-p22

### Scorecard: cora-bb45c30-p22

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L1827 | 3 | 1 | Mine | no | 0 | 2 | 4 | 2 | 2 | 0 | 0 | 0 |
| L1827 | 3 | 1 | Opponent | no | 2 | 2 | 8 | 3 | 1 | 0 | 0 | 190 |
| L1927 | 1 | 1 | Mine | no | 1 | 1 | 4 | 1 | 1 | 0 | 0 | 255 |
| L1927 | 1 | 1 | Opponent | no | 3 | 2 | 2 | 4 | 0 | 0 | 0 | 0 |
| L2029 | 1 | 1 | Mine | no | 0 | - | 0 | 4 | 1 | 0 | 0 | 420 |
| L2029 | 1 | 1 | Opponent | no | 4 | 2 | 3 | 2 | 0 | 0 | 0 | 170 |
| **Average** | | | Mine | 0% | 0.3 | 1.5 | 2.7 | 2.3 | 1.3 | 0.0 | 0.0 | 225.0 |
| **Average** | | | Opponent | 0% | 3.0 | 2.0 | 4.3 | 3.0 | 0.3 | 0.0 | 0.0 | 120.0 |

### KPIs: cora-bb45c30-p22

Rules off - Mine only: ONE RUN A PLAN.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 8% (1 of 13) | 0% (0 of 15) | 4% (1 of 28) |
| Winner chose to follow up after the loser gave ground |  | 83% (10 of 12); on the table 92% | 86% (6 of 7); on the table 86% | 84% (16 of 19); on the table 89% |
| Winner chose to pursue after the loser fell back in good order |  | - | 100% (4 of 4); on the table 100% | 100% (4 of 4); on the table 100% |
| Winner chose to pursue after the loser fled |  | 0% (0 of 1); on the table 0% | 71% (5 of 7); on the table 86% | 62% (5 of 8); on the table 75% |
| Winner chose to follow up or pursue (all three) |  | 77% (10 of 13); on the table 85% | 83% (15 of 18); on the table 89% | 81% (25 of 31); on the table 87% |
| Magic missiles tried each own turn | 50%+ | 0% (0 of 24) | 17% (2 of 12) | 6% (2 of 36) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 0% (0 of 9) | 22% (2 of 9) | 11% (2 of 18) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 100% (5 of 5) | 33% (2 of 6) | 64% (7 of 11) |
| Points that never fought | lower | 24% (1448 of 5999) | 33% (1956 of 5999) | 28% (3404 of 11998) |
|   infantry points that never fought | lower | 60% (596 of 993) | 85% (673 of 793) | 71% (1269 of 1786) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 59% (13 of 22) | 42% (8 of 19) | 51% (21 of 41) |
| Bound items with a magic missile used (at least once a game) |  | 100% (1 of 1); 0.7 uses a game | 0.0 uses a game | 100% (1 of 1); 0.3 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0% (0 of 2); 0.0 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |
|   their share of the points of units over 100 pts | lower | 61% (3132 of 5151) | 32% (1592 of 4976) | 47% (4724 of 10127) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 0.7 (8%) | 2.3 (70%) | 3.0 (26%) |
| MARCHED: its unit marched | 1.0 (12%) | 0.0 (0%) | 1.0 (9%) |
| IN COMBAT: engaged in combat | 2.0 (25%) | 0.3 (10%) | 2.3 (21%) |
| REAR RANK: in a rear rank | 0.7 (8%) | 0.0 (0%) | 0.7 (6%) |
| FLEEING: fleeing | 0.3 (4%) | 0.0 (0%) | 0.3 (3%) |
| GONE: slain | 2.7 (33%) | 0.7 (20%) | 3.3 (29%) |
| NOT OFFERED: not in the cast list | 0.7 (8%) | 0.0 (0%) | 0.7 (6%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 2.3 | 2.0 | 0.7 | 0.7 | 5.3 |
| not cast | 9.7 | 8.0 | 11.3 | 3.3 | 26.7 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.3 (9%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.0 (0%) | 3.0 (26%) | 1.0 (30%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 1.0 (9%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.3 (4%) | 2.3 (21%) | 0.0 (0%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 1.3 (14%) | 1.3 (17%) | 0.7 (6%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.3 (3%) | 0.0 (0%) | 0.3 (3%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | 2.7 (28%) | 2.3 (29%) | 3.3 (29%) | 0.7 (20%) | 7.0 (26%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (0%) | 1.0 (12%) | 0.0 (0%) | 1.0 (30%) | 0.0 (0%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.3 (5%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (20%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.7 (6%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 5.3 (55%) | 3.0 (38%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 16.0 (60%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.0 a game | 1.0 a game | 1.0 a game |
| stood (cast and not dispelled) | 0% (0 of 3) | 33% (1 of 3) | 17% (1 of 6) |
| the unit moved after it | - | 100% (1 of 1) | 100% (1 of 1) |
| it charged on its next turn | - | 0% (0 of 1) | 0% (0 of 1) |
| the enemy charged it first | - | 0% (0 of 1) | 0% (0 of 1) |
| it fought by the end of its next turn | - | 0% (0 of 1) | 0% (0 of 1) |
| it moved out of a charge the enemy had planned (not charged first) | - | 0% (0 of 1) | 0% (0 of 1) |
| none of these (no charge, no fight, no charge escaped) | - | 100% (1 of 1) | 100% (1 of 1) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 51% (29 of 57) | 0% (0 of 9) | 44% (29 of 66) |
|   cavalry | - | 0% (0 of 3) | 0% (0 of 3) |
|   character | 57% (4 of 7) | 0% (0 of 6) | 31% (4 of 13) |
|   chariot | 62% (5 of 8) | - | 62% (5 of 8) |
|   infantry | 45% (15 of 33) | - | 45% (15 of 33) |
|   monster | 56% (5 of 9) | - | 56% (5 of 9) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 3.0 (32%) | 0.7 (22%) | 3.7 (30%) |
| CHARGED: it charged | 1.7 (18%) | 1.3 (44%) | 3.0 (24%) |
| FLEEING: it fled or was fleeing | 0.3 (4%) | 0.0 (0%) | 0.3 (3%) |
| IN COMBAT: it fought this turn or the last | 2.3 (25%) | 0.0 (0%) | 2.3 (19%) |
| NO TARGET IN RANGE | 1.0 (11%) | 0.3 (11%) | 1.3 (11%) |
| ONLY IN COMBAT: the only targets were in combat | 0.7 (7%) | 0.3 (11%) | 1.0 (8%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.3 (4%) | 0.3 (11%) | 0.7 (5%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| character | 1.7 | 0.0 | 100% | 0.0 pts | 0 pts |
| chariot | 2.0 | 0.0 | 100% | 0.0 pts | 0 pts |
| infantry | 5.3 | 2.3 | 69% | 20.9 pts | 112 pts |
| monster | 1.7 | 0.0 | 100% | 0.0 pts | 0 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 5.0 | 7.7 | 6.3 |
| Charges that made contact a game | 3.3 | 5.7 | 4.5 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.00 declared, 0.00 contact (1 units) | 0.00 declared, 0.00 contact (2 units) | 0.00 declared, 0.00 contact (3 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 0.75 declared, 0.75 contact (4 units) | 0.75 declared, 0.75 contact (4 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.54 declared, 0.36 contact (28 units) | 0.83 declared, 0.58 contact (24 units) | 0.67 declared, 0.46 contact (52 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 50% (2 of 4) | 67% (2 of 3) | 50% (1 of 2) | 56% (5 of 9) |
| Character in a unit | 67% (4 of 6) | - | - | 67% (4 of 6) |
| Character on its own | 100% (2 of 2) | 33% (1 of 3) | 33% (2 of 6) | 45% (5 of 11) |
| Chariot | 100% (2 of 2) | - | - | 100% (2 of 2) |
| Infantry | 50% (2 of 4) | 0% (0 of 1) | - | 40% (2 of 5) |
| Monster | 0% (0 of 1) | 67% (2 of 3) | - | 50% (2 of 4) |
| Monstrous | - | 25% (1 of 4) | - | 25% (1 of 4) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Ogre Kingdoms | 1 | 71% (5 of 7); on the table 86% | 0% (0 of 6) | 19% | 43% (3 of 7) | 100% (1 of 1); 2.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 1 | 100% (3 of 3); on the table 100% | 0% (0 of 12) | 16% | 75% (6 of 8) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Skaven | 1 | 67% (2 of 3); on the table 67% | 0% (0 of 6) | 38% | 57% (4 of 7) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Vampire Counts | 2 | 82% (14 of 17); on the table 88% | 17% (2 of 12) | 31% | 50% (6 of 12) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 1 | 100% (1 of 1); on the table 100% | - | 37% | 29% (2 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (cora-bb45c30-p22, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 67% (4) | 12% (1) | 36% (5) |
| ...free all their last turn and able to turn (per game) | 1.33 | 0.33 | 1.67 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 1.33 | 0.33 | 1.67 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.33 | 0.33 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: cora-bb45c30-p22

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.7 | 4.0 |
| Strategy | Charge objectives carried out (made contact) | 50% (4 of 8) | 50% (11 of 22) |
| Strategy | Shoot objectives carried out (shot that target) | 75% (3 of 4) | - |
| Strategy | Support requests answered (helper made contact too) | - | 100% (2 of 2) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (1 of 1) | - |
| Strategy | Joined characters whose unit fought | 100% (3 of 3) | 25% (1 of 4) |
| Strategy | Lone characters that fought | 86% (6 of 7) | 80% (8 of 10) |
| Movement | Charges halted short of contact | 0.0 | 0.3 |
| Movement | Idle units | 2.3 | 3.0 |
| Movement | Points that never moved of their own | 225.0 | 120.0 |
| Movement | Fights charged into per game | 2.7 | 5.0 |
| Movement | Charges with odds: long shots (under 50%) | 1 of 5, net +0 | 3 of 14, net +135 |
| Movement | Charges with odds: sweet spot (55-75%) | 2 of 5, net +93 | 2 of 14, net +0 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 5 | 0 of 14 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 of 5, net +75 | 6 of 14, net +352 |
| Shooting | Shots by shooting units (incl. breath weapons) | 10.3 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 61% (19 of 31) | - |
| Shooting | Points destroyed by shooting units | 0.0 | 0.0 |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | - | 0.7 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | - | 0% (0 of 2) |
| Magic | Wounds caused by magic missiles | 0.7 | - |
| Magic | Wounds caused by other spells | 0.3 | 3.0 |
| Magic | Points destroyed by magic (all spells) | 20.0 | 99.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.0 / 0.0 / 2.0 / 0.0 | 0.7 / 0.0 / 1.3 / 0.3 |
| Combat | Points destroyed in combat | 280.7 | 878.3 |
| Combat | Points run down | 0.0 | 102.3 |
| Combat | Net points per charged fight, damage counted | +21 | +238 |
| Combat | Net per 100 charger points, damage counted | +9.9 | +94.3 |
| Combat | First round won (charged fights) | 75% | 60% |
| Combat | Net points per charged fight | +22 | +220 |
| Combat | Net points per supported fight / lone fight | +38 / +17 | +163 / +229 |
| Combat | Charged fights on a top-3 enemy unit | 2 of 8 | 7 of 15 |
| Game | Points lost | 1431.7 | 351.3 |
| Game | VP from objectives | 406.7 | 920.0 |
| Game | Lone holders (player turns) | 0.3 | 3.0 |

- Mine won / drew / lost: 0 / 0 / 3 of 3 ended games (of 3); mean margin (Mine - Opponent) -1767 VP
- The side that went first won 3 of 3 games with a winner
- Points traded per game (both sides' losses): 1783
- Games not ended: 0; findings 1, warnings 0

### Opponent rules: cora-bb45c30-p22

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.7 | +186.8 | 0.0 | 99.0 | 0.3 | +14.9 | 0.0 | 62.0 |
| AFTERMATH WITH FRIENDS | - | - | - | - | 0.7 | +37.4 | 0.0 | 0.0 |
| ARMY TABLE | 23.3 | +500.4 | 0.0 | 608.3 | 17.0 | +96.8 | 0.0 | 263.0 |
| ASSAILMENT BY POINTS | 0.3 | +0.4 | 0.0 | 108.7 | 1.0 | +10.0 | 0.0 | 63.3 |
| CASTER AWAY FROM SCREEN | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | - | - | - | - | 3.0 | +56.4 | 0.0 | 0.0 |
| CHAFF PASSED | 1.0 | -8.5 | 0.0 | 162.0 | - | - | - | - |
| CHALLENGE BY POINTS | 1.0 | +14.4 | 0.0 | 99.0 | - | - | - | - |
| CHAMPION KNOWS CHALLENGE | - | - | - | - | 0.3 | -6.1 | 65.7 | 0.0 |
| CHAMPION TAKES THE CHALLENGE | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CHARGE LOSSES | 6.0 | -655.7 | 0.0 | 408.0 | 7.7 | -200.5 | 0.0 | 260.7 |
| CHARGE NOW FIRST | 1.3 | +0.0 | 113.3 | 0.0 | 3.3 | +0.0 | 529.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 8.7 | +0.0 | 0.0 | 131.3 | 19.3 | +0.0 | 0.0 | 90.7 |
| COMBAT PIVOT | 0.3 | +0.0 | 0.0 | 116.7 | 0.7 | +0.0 | 65.7 | 0.0 |
| CONVEYANCE SEARCH | 0.7 | +58.7 | 64.0 | 31.7 | 1.0 | +10.7 | 0.0 | 0.0 |
| COVER ONCE | 3.3 | -126.6 | 0.0 | 223.7 | 1.3 | -74.3 | 0.0 | 62.0 |
| DENIED BY THE FIGHT | 0.3 | -0.2 | 0.0 | 0.0 | - | - | - | - |
| DEPLOY BY FIGURES | 8.0 | -112.9 | 0.0 | 0.0 | 7.0 | +58.5 | 0.0 | 62.0 |
| DUEL STOPS AT THE KILL | - | - | - | - | 0.3 | -71.9 | 99.0 | 0.0 |
| EDGE GIVE GROUND | 0.3 | +11.8 | 0.0 | 0.0 | 0.3 | +33.4 | 70.0 | 0.0 |
| EXACT ROUND | 2.3 | -6.4 | 212.3 | 0.0 | 5.0 | +25.4 | 604.3 | 62.0 |
| FALL BACK GOOD ORDER | 1.0 | +0.0 | 187.3 | 0.0 | 6.0 | +40.0 | 769.0 | 62.0 |
| FALLS SHORT | - | - | - | - | 15.7 | +134.1 | 0.0 | 191.0 |
| FEATURE BUFFS | 3.0 | +65.5 | 0.0 | 131.3 | 0.7 | +0.7 | 0.0 | 0.0 |
| FIGHT TO THE END | 1.0 | +3.5 | 124.0 | 0.0 | 3.7 | +63.1 | 397.0 | 62.0 |
| FIVE ACTION | 72.3 | +5602.7 | 262.3 | 1625.0 | 87.7 | +7591.9 | 909.0 | 628.0 |
| FLANK NOT WEIGHED | 8.7 | +0.0 | 0.0 | 342.0 | 4.3 | +0.0 | 0.0 | 113.3 |
| FOLLOW UP WEIGHED | 1.3 | +240.5 | 0.0 | 70.0 | 1.3 | +268.3 | 0.0 | 62.0 |
| FOUR ROUNDS | 3.0 | +245.9 | 262.3 | 0.0 | 7.7 | +510.7 | 839.0 | 62.0 |
| FREED FROM HIS FIGHT | 7.3 | +0.0 | 0.0 | 438.7 | 3.7 | +0.0 | 0.0 | 50.0 |
| FRIEND CHARGES FIRST | - | - | - | - | 0.7 | -22.2 | 0.0 | 0.0 |
| GIVES UP | 0.3 | -0.2 | 0.0 | 0.0 | 1.0 | -47.6 | 258.0 | 62.0 |
| GOAL WALK | 13.7 | +1600.6 | 0.0 | 270.0 | 8.0 | +1111.7 | 0.0 | 68.3 |
| GUN FIGURES | 4.3 | +37.6 | 0.0 | 123.3 | - | - | - | - |
| HARD STAY DROPPED | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HE REFORMS ONCE FREED | 6.7 | +0.0 | 0.0 | 353.7 | 2.0 | +0.0 | 0.0 | 50.0 |
| HIS CHARGE BY HIS RUN | 3.7 | +0.0 | 0.0 | 258.3 | 3.3 | +0.0 | 0.0 | 124.0 |
| HIS CHARGE DENIED | 0.3 | +20.5 | 0.0 | 0.0 | 0.3 | +1.5 | 0.0 | 0.0 |
| HIS CHARGE LIST | 4.0 | +0.0 | 0.0 | 153.0 | 0.7 | +0.0 | 0.0 | 50.0 |
| HIS LEGAL MOVES | 2.7 | +0.0 | 0.0 | 116.7 | 4.3 | +0.0 | 0.0 | 124.0 |
| HIS MOVE AND SHOT | 0.7 | -8.3 | 0.0 | 21.7 | 3.3 | -38.4 | 0.0 | 25.0 |
| HIS ONE QUARTER | 4.7 | +0.0 | 0.0 | 222.3 | 8.3 | +0.0 | 0.0 | 50.0 |
| HIS OWN BEST MOVE | 3.0 | +0.0 | 0.0 | 116.7 | 7.7 | +0.0 | 0.0 | 124.0 |
| HIS RANDOM MOVE | 10.0 | +0.0 | 0.0 | 482.7 | 5.7 | +0.0 | 0.0 | 136.7 |
| HIS RANDOM MOVER COMES | 2.7 | +0.0 | 0.0 | 128.0 | 1.7 | +0.0 | 0.0 | 136.7 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 10.3 | +98.9 | 0.0 | 381.3 | 34.0 | +689.3 | 0.0 | 183.3 |
| HIS SHOTS BY HIS RUN | 12.7 | +102.5 | 0.0 | 174.7 | 26.0 | +307.2 | 0.0 | 262.3 |
| HIS TURN DENIED | 0.3 | +0.2 | 63.3 | 0.0 | 1.7 | +17.5 | 154.0 | 62.0 |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HOLD ODDS | 20.0 | +0.0 | 0.0 | 469.0 | 12.0 | +0.0 | 0.0 | 0.0 |
| HOLDER ASSIGNMENT | 10.7 | +925.4 | 0.0 | 208.0 | 7.3 | +958.2 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 0.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 2.3 | -28.2 | 262.3 | 0.0 | 6.7 | -222.2 | 659.0 | 62.0 |
| HUNT RESULT | 0.3 | +64.1 | 63.3 | 0.0 | - | - | - | - |
| HUNT THE GUNS | 0.3 | +64.3 | 63.3 | 0.0 | - | - | - | - |
| IDLE COST | - | - | - | - | 19.0 | -221.7 | 0.0 | 171.7 |
| JOINT CHARGE NOW | 1.0 | -0.5 | 25.0 | 0.0 | 2.0 | +405.4 | 0.0 | 62.0 |
| JOINT KNOWS CHALLENGE | - | - | - | - | 0.3 | -16.3 | 0.0 | 0.0 |
| JOINT LOOK BACK | 0.3 | +10.4 | 0.0 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 3.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 0.3 | +9.3 | 0.0 | 0.0 | 1.3 | +47.7 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| LEGAL CHARGES ONLY | 7.0 | +0.0 | 124.0 | 728.7 | 5.7 | +0.0 | 632.0 | 311.3 |
| LONE CHARACTER SAFE SPOT | - | - | - | - | 0.3 | +0.0 | 0.0 | 20.0 |
| LONE WIZARD KEPT IN | 0.3 | +7.9 | 0.0 | 0.0 | - | - | - | - |
| LONG SHOT | 1.7 | -25.5 | 149.0 | 21.7 | 0.7 | +3.9 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | 1.7 | -1.0 | 187.3 | 0.0 | 5.0 | +19.7 | 567.3 | 62.0 |
| MANOEUVRE | 2.0 | +27.4 | 0.0 | 64.0 | 1.3 | +18.3 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 0.3 | +25.0 | 0.0 | 180.0 | - | - | - | - |
| MARCH WHEELS ONLY | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 2.7 | +29.3 | 0.0 | 0.0 | 2.0 | +27.0 | 0.0 | 93.3 |
| MEETS IN TIME | 5.0 | +381.2 | 0.0 | 0.0 | 3.3 | +411.4 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 1.0 | +51.7 | 0.0 | 0.0 | 1.7 | +3.8 | 0.0 | 63.3 |
| MISSILES NEXT TURN | 2.0 | +27.2 | 0.0 | 180.0 | 2.0 | +2.6 | 0.0 | 63.3 |
| MOVE ORDER | 2.0 | +0.0 | 0.0 | 180.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| MOVE SPELL OUT OF RANGE | 0.3 | -2.2 | 0.0 | 31.7 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 5.3 | +197.8 | 0.0 | 116.7 | 10.7 | +913.4 | 0.0 | 174.0 |
| MOVES UNITS SPELL | 0.3 | +1.4 | 0.0 | 0.0 | - | - | - | - |
| NEARER NOT NEEDED | 8.0 | +362.8 | 0.0 | 129.7 | 3.7 | +143.8 | 0.0 | 40.7 |
| NEXT CHARGE BY LIST | 4.3 | +174.6 | 0.0 | 0.0 | 5.3 | +456.5 | 70.0 | 174.0 |
| NEXT OBJECTIVE NEARER | 0.7 | -15.0 | 0.0 | 0.0 | - | - | - | - |
| NO DOUBLE ROUNDS | 1.7 | -73.7 | 113.3 | 0.0 | 5.3 | -265.0 | 769.0 | 62.0 |
| NO LATE CUT | 1.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 0.3 | -0.2 | 0.0 | 0.0 | 2.0 | -0.7 | 0.0 | 0.0 |
| OFF BEST | 3.3 | -78.0 | 0.0 | 162.0 | 3.3 | -70.9 | 0.0 | 0.0 |
| ONE CHECK AFTER THE LAST CHANGE | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ONE FIGHT FORMULA | 2.0 | -3.9 | 0.0 | 0.0 | 7.7 | -153.3 | 0.0 | 87.0 |
| ONE JOINT FIGURE | 0.3 | +37.3 | 0.0 | 0.0 | 1.7 | -33.7 | 76.0 | 62.0 |
| ONE OBJECTIVE FORMULA | 4.3 | +73.9 | 0.0 | 129.7 | 2.7 | +142.6 | 0.0 | 0.0 |
| ONE PROMISE A TARGET | - | - | - | - | 1.0 | -46.7 | 0.0 | 124.0 |
| ONE ROUTE | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| ONE RUN A PLAN | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS UP | - | - | - | - | 0.7 | +46.5 | 21.7 | 0.0 |
| OVERRUNS AWAY | - | - | - | - | 2.7 | +37.2 | 198.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.3 | -4.9 | 0.0 | 0.0 | 0.7 | -1.2 | 0.0 | 0.0 |
| PLAN RESULT | 35.7 | +302.6 | 274.3 | 1787.0 | 44.7 | +750.9 | 329.0 | 496.7 |
| PROMISE BELOW ZERO | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| PROMISE BY ITS OWN SUM | 7.0 | -138.4 | 0.0 | 317.3 | 11.3 | -464.6 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | 0.7 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 50.0 |
| PROMISE READS THE TABLE | - | - | - | - | 1.0 | -31.1 | 0.0 | 0.0 |
| QUARTER ODDS | 18.0 | +1908.0 | 50.0 | 244.0 | 26.3 | +3360.7 | 403.7 | 50.0 |
| RANDOM MOVE BY FIGURES | 1.7 | +213.1 | 0.0 | 70.0 | 2.0 | +54.5 | 0.0 | 0.0 |
| REAL GROUND | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| REDIRECT BY WHAT IT STOPS | - | - | - | - | 1.0 | +0.5 | 0.0 | 0.0 |
| REDIRECT COUNTER | 4.0 | +82.9 | 0.0 | 0.0 | 4.7 | +119.1 | 0.0 | 50.0 |
| REDIRECT FOR A FRIEND IN REACH | 6.3 | +0.0 | 0.0 | 36.7 | 5.0 | +50.4 | 0.0 | 50.0 |
| REDIRECT WEIGHED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| REFORMS TO MEET IT | 2.7 | -81.9 | 0.0 | 0.0 | - | - | - | - |
| REFUSING RETIRES | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| RISK BY ARC | 3.0 | +99.2 | 262.3 | 0.0 | 6.7 | -122.9 | 760.7 | 62.0 |
| ROUNDS AFTER TERROR | - | - | - | - | 4.0 | -109.3 | 353.7 | 62.0 |
| RUN DOWN | - | - | - | - | 4.7 | -43.3 | 497.3 | 62.0 |
| SAFER THAN THE JOB | - | - | - | - | 0.3 | +3.9 | 0.0 | 0.0 |
| SCOUT SPOT | 0.7 | +1.8 | 0.0 | 0.0 | - | - | - | - |
| SCOUT WAITS | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 1.7 | -120.1 | 0.0 | 0.0 |
| SEARCH SPOT | 0.3 | +25.0 | 0.0 | 180.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| SECOND LOOK | - | - | - | - | 0.3 | +43.7 | 76.0 | 0.0 |
| SELF MOVE SPELL | 1.0 | -2.1 | 0.0 | 217.3 | - | - | - | - |
| SET CREDITED ONCE | - | - | - | - | 1.0 | -45.8 | 0.0 | 0.0 |
| SET UP BY THE SET | 1.3 | +12.1 | 0.0 | 0.0 | 2.3 | -31.4 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 2.3 | +0.0 | 0.0 | 223.3 | 2.7 | +0.0 | 0.0 | 83.3 |
| SHOOTS FROM THE BEST SPOT | 2.7 | +188.7 | 0.0 | 201.7 | 0.3 | +55.3 | 70.0 | 0.0 |
| SHOT RISK POINTS | 2.7 | -10.8 | 0.0 | 21.7 | 18.7 | -62.5 | 0.0 | 207.3 |
| SHOTS AFTER THE MOVES | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SHOTS IN THE MOVE | 7.3 | +234.9 | 0.0 | 205.3 | - | - | - | - |
| SPELL WORTH | 0.7 | +15.7 | 180.0 | 180.0 | 1.0 | +9.9 | 40.0 | 40.0 |
| SPELLS IN THE FIGHT | 0.7 | -1.3 | 63.3 | 0.0 | 0.3 | +1.4 | 70.0 | 0.0 |
| SPOT AS THE GAME MOVES | 11.0 | +0.0 | 0.0 | 265.0 | 9.7 | +0.0 | 0.0 | 156.7 |
| STAND AND SHOOT | - | - | - | - | 1.0 | -21.7 | 122.0 | 0.0 |
| STANDS FOR A REASON | - | - | - | - | 0.7 | +0.0 | 0.0 | 63.3 |
| STANDS STILL | 19.3 | +0.0 | 0.0 | 509.0 | 17.0 | +0.0 | 70.0 | 63.3 |
| STAY WORTH | 5.0 | +58.1 | 0.0 | 145.0 | - | - | - | - |
| STOPS | 0.3 | +0.2 | 63.3 | 0.0 | - | - | - | - |
| STRIKE BY THE ODDS | 2.0 | +11.3 | 0.0 | 0.0 | 1.3 | +1.5 | 0.0 | 87.0 |
| STUPIDITY NEXT TURN | - | - | - | - | 2.7 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 8.7 | +619.2 | 0.0 | 292.0 | 3.3 | +291.1 | 0.0 | 0.0 |
| SUPPORT NARROWED | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| SUPPORT WORKED OUT | 8.7 | +619.2 | 0.0 | 292.0 | 3.3 | +291.1 | 0.0 | 0.0 |
| SURE REACH TOGETHER | - | - | - | - | 0.3 | +0.4 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 1.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| THE PROMISE ADDS | - | - | - | - | 1.0 | -24.9 | 0.0 | 0.0 |
| THE PROMISED MOVE | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE ROW IN ITS ORDER | 6.0 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 20.0 |
| THE ROW KEEPS ITS WAY | 2.3 | +0.0 | 0.0 | 0.0 | 5.3 | +0.0 | 0.0 | 40.7 |
| THE STEP BACK IS MADE | 1.7 | +0.0 | 0.0 | 0.0 | 5.0 | +0.0 | 0.0 | 40.7 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 32.3 | +0.0 | 0.0 | 576.7 | 42.0 | +0.0 | 0.0 | 324.3 |
| TIED UP BY THE SUM | 0.3 | +5.3 | 25.0 | 0.0 | 1.7 | +189.2 | 240.0 | 0.0 |
| TIME ON OUR SIDE | 31.0 | +280.3 | 0.0 | 539.7 | - | - | - | - |
| WAITS AGAIN | 3.3 | +0.0 | 0.0 | 248.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| WHAT THE JOINER ADDS | 1.3 | +67.3 | 248.0 | 0.0 | 1.7 | -139.2 | 0.0 | 0.0 |
| WHO FIGHTS | 0.7 | -2.6 | 0.0 | 0.0 | 1.7 | +35.4 | 154.0 | 0.0 |
| WHO HITS BACK | 0.3 | +52.5 | 0.0 | 0.0 | 0.3 | +22.4 | 0.0 | 0.0 |
| WHOLE FIGHT | 0.7 | -21.7 | 124.0 | 0.0 | 1.0 | +3.8 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | 4.7 | -609.9 | 0.0 | 386.3 | 1.0 | -22.3 | 0.0 | 68.3 |
| WHOLE FIGHT GAIN | 0.3 | +4.2 | 0.0 | 0.0 | 0.7 | +32.7 | 0.0 | 62.0 |
| WOUNDS ON THE RANKS | - | - | - | - | 1.7 | +33.5 | 0.0 | 0.0 |

### Rule changes: cora-bb45c30-p22

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 121 | 121 | 81 | 27.00 | +1888 | +23.3 |
| HOLDER ASSIGNMENT | 54 | 54 | 48 | 16.00 | +3421 | +71.3 |
| LEGAL CHARGES ONLY | 38 | 38 | 38 | 12.67 | +0 | +0.0 |
| FIVE ACTION | 480 | 466 | 35 | 11.67 | +2017 | +57.6 |
| REDIRECT FOR A FRIEND IN REACH | 34 | 34 | 34 | 11.33 | +0 | +0.0 |
| THE TABLE AGAIN | 36 | 36 | 29 | 9.67 | +0 | +0.0 |
| DEPLOY BY FIGURES | 45 | 45 | 26 | 8.67 | +294 | +11.3 |
| PROMISE BY ITS OWN SUM | 55 | 55 | 24 | 8.00 | -1809 | -75.4 |
| MOVE TO CHARGE COMPUTED | 48 | 42 | 23 | 7.67 | +626 | +27.2 |
| OFF BEST | 20 | 20 | 20 | 6.67 | -447 | -22.3 |
| HIS SHOT LIST | 133 | 124 | 19 | 6.33 | +126 | +6.7 |
| GOAL WALK | 65 | 63 | 16 | 5.33 | +1505 | +94.1 |
| FOUR ROUNDS | 32 | 31 | 15 | 5.00 | +967 | +64.5 |
| HIS SHOTS BY HIS RUN | 116 | 111 | 15 | 5.00 | +161 | +10.7 |
| QUARTER ODDS | 133 | 129 | 14 | 4.67 | +1277 | +91.2 |
| SUPPORT ADDS | 36 | 34 | 13 | 4.33 | +874 | +67.2 |
| SUPPORT WORKED OUT | 36 | 34 | 13 | 4.33 | +874 | +67.2 |
| MOVE ORDER | 12 | 12 | 12 | 4.00 | +0 | +0.0 |
| NEXT CHARGE BY LIST | 29 | 27 | 12 | 4.00 | +518 | +43.2 |
| IDLE COST | 57 | 40 | 10 | 3.33 | +42 | +4.2 |
| STRIKE BY THE ODDS | 10 | 10 | 10 | 3.33 | +39 | +3.9 |
| JOINT CHARGE NOW | 9 | 9 | 9 | 3.00 | +1215 | +135.0 |
| FOLLOW UP WEIGHED | 8 | 8 | 8 | 2.67 | +1526 | +190.8 |
| SHOOTS FROM THE BEST SPOT | 9 | 9 | 8 | 2.67 | +151 | +18.9 |
| MEETS IN TIME | 25 | 25 | 7 | 2.33 | +441 | +63.0 |
| RANDOM MOVE BY FIGURES | 11 | 11 | 7 | 2.33 | +802 | +114.6 |
| MAX FOR POSITIONING | 14 | 12 | 6 | 2.00 | +25 | +4.1 |
| WHOLE FIGHT DANGER | 17 | 17 | 6 | 2.00 | +661 | +110.1 |
| CHAFF IN THE MOVE | 9 | 6 | 5 | 1.67 | +5 | +1.0 |
| LANE BY FIGURES | 5 | 5 | 5 | 1.67 | +171 | +34.2 |
| REDIRECT COUNTER | 26 | 15 | 5 | 1.67 | +182 | +36.5 |
| RISK BY ARC | 29 | 28 | 5 | 1.67 | +175 | +34.9 |
| TIED UP BY THE SUM | 6 | 6 | 5 | 1.67 | +238 | +47.7 |
| TIME ON OUR SIDE | 93 | 77 | 5 | 1.67 | +15 | +3.1 |
| ADVANCE LANE KEPT | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| ASSAILMENT BY POINTS | 4 | 4 | 4 | 1.33 | +31 | +7.8 |
| CASTS FROM BEHIND | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| HARD STAY DROPPED | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| HOLDS AMBUSHERS | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| MANOEUVRE | 10 | 10 | 4 | 1.33 | +137 | +34.3 |
| NEARER NOT NEEDED | 35 | 33 | 4 | 1.33 | +91 | +22.9 |
| SHOTS IN THE MOVE | 22 | 16 | 4 | 1.33 | +157 | +39.2 |
| THE ROW IN ITS ORDER | 30 | 4 | 4 | 1.33 | +0 | +0.0 |
| AFTERMATH IN POINTS | 3 | 3 | 3 | 1.00 | +605 | +201.7 |
| CHAFF PASSED | 3 | 3 | 3 | 1.00 | -25 | -8.5 |
| CHALLENGE BY POINTS | 3 | 3 | 3 | 1.00 | +43 | +14.4 |
| CHARGE LOSSES | 41 | 40 | 3 | 1.00 | +314 | +104.8 |
| CHARGE NOW FIRST | 14 | 14 | 3 | 1.00 | -168 | -55.9 |
| COMBAT PIVOT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| FIGHT TO THE END | 14 | 13 | 3 | 1.00 | +68 | +22.6 |
| ONE PROMISE A TARGET | 3 | 3 | 3 | 1.00 | -140 | -46.7 |
| PIVOT GUARDS FLANK | 3 | 3 | 3 | 1.00 | -18 | -6.0 |
| SCOUT WAITS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| SHOT RISK POINTS | 64 | 58 | 3 | 1.00 | +118 | +39.3 |
| WOUNDS ON THE RANKS | 5 | 5 | 3 | 1.00 | +54 | +17.9 |
| AFTERMATH WITH FRIENDS | 2 | 2 | 2 | 0.67 | +112 | +56.1 |
| CASTER AWAY FROM SCREEN | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| COVER ONCE | 14 | 7 | 2 | 0.67 | +25 | +12.7 |
| EDGE GIVE GROUND | 2 | 2 | 2 | 0.67 | +51 | +25.4 |
| EXACT ROUND | 22 | 21 | 2 | 0.67 | +80 | +40.0 |
| HIS CHARGE DENIED | 2 | 2 | 2 | 0.67 | +26 | +13.2 |
| ONE JOINT FIGURE | 6 | 5 | 2 | 0.67 | +34 | +17.1 |
| SET UP BY THE SET | 11 | 10 | 2 | 0.67 | -31 | -15.3 |
| WHAT THE JOINER ADDS | 9 | 9 | 2 | 0.67 | +88 | +44.0 |
| WHO HITS BACK | 2 | 2 | 2 | 0.67 | +60 | +29.8 |
| WHOLE FIGHT GAIN | 3 | 3 | 2 | 0.67 | +64 | +32.2 |
| JOINT LOOK BACK | 1 | 1 | 1 | 0.33 | +31 | +31.2 |
| LONE WIZARD KEPT IN | 1 | 1 | 1 | 0.33 | +24 | +23.8 |
| LONG SHOT | 7 | 7 | 1 | 0.33 | +1 | +1.4 |
| MISSILES IN THE MOVE | 8 | 4 | 1 | 0.33 | +77 | +77.4 |
| MOVES UNITS SPELL | 1 | 1 | 1 | 0.33 | +4 | +4.3 |
| NO DOUBLE ROUNDS | 21 | 20 | 1 | 0.33 | +4 | +4.0 |
| OPENS UP | 2 | 2 | 1 | 0.33 | +4 | +4.0 |
| PROMISE READS THE TABLE | 3 | 3 | 1 | 0.33 | +23 | +23.4 |
| REDIRECT BY WHAT IT STOPS | 3 | 3 | 1 | 0.33 | +0 | +0.0 |
| REDIRECT WEIGHED | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| SAFER THAN THE JOB | 1 | 1 | 1 | 0.33 | +12 | +11.7 |
| SEARCH SPOT | 2 | 2 | 1 | 0.33 | +75 | +75.0 |
| SECOND LOOK | 1 | 1 | 1 | 0.33 | +131 | +131.1 |
| SUPPORT NARROWED | 2 | 2 | 1 | 0.33 | -1 | -1.0 |
| WHO FIGHTS | 7 | 6 | 1 | 0.33 | +3 | +3.4 |
| CASTS AFTER FRIENDS | 1 | trace | - | - | - | - |
| CHAMPION KNOWS CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| CHAMPION TAKES THE CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 84 | 84 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 5 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 1 | 1 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 21 | 20 | 0 | 0.00 | - | - |
| FALLS SHORT | 47 | 37 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 11 | 11 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 39 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 33 | 29 | 0 | 0.00 | - | - |
| FRIEND CHARGES FIRST | 2 | 2 | 0 | 0.00 | - | - |
| GIVES UP | 4 | 4 | 0 | 0.00 | - | - |
| GUN FIGURES | 13 | not checked | - | - | - | - |
| HE REFORMS ONCE FREED | 26 | 22 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 21 | 21 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 14 | 14 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 21 | 21 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 12 | 12 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 39 | 36 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 32 | 30 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 47 | 47 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 13 | 13 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 6 | 5 | 0 | 0.00 | - | - |
| HIS TURN RUN | 18 | 18 | 0 | 0.00 | - | - |
| HOLD ODDS | 96 | 96 | 0 | 0.00 | - | - |
| HONEST WORTH | 27 | 26 | 0 | 0.00 | - | - |
| HUNT RESULT | 1 | trace | - | - | - | - |
| HUNT THE GUNS | 1 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 13 | 13 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 2 | 2 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 1 | not checked | - | - | - | - |
| LOST AFTER ESCAPE | 20 | 19 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 1 | 1 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 4 | 4 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 12 | 7 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 1 | trace | - | - | - | - |
| NEXT OBJECTIVE NEARER | 2 | 2 | 0 | 0.00 | - | - |
| NO LATE CUT | 6 | 6 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 7 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 2 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 29 | 12 | 0 | 0.00 | - | - |
| ONE OBJECTIVE FORMULA | 21 | 13 | 0 | 0.00 | - | - |
| ONE ROUTE | 4 | 4 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 18 | 18 | 0 | 0.00 | - | - |
| OVERRUNS AWAY | 8 | 7 | 0 | 0.00 | - | - |
| PLAN RESULT | 241 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 2 | 2 | 0 | 0.00 | - | - |
| PROMISE KNOWS THE FIGHT | 13 | 11 | 0 | 0.00 | - | - |
| REAL GROUND | 4 | 4 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 8 | 6 | 0 | 0.00 | - | - |
| REFUSING RETIRES | 3 | 3 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 12 | 11 | 0 | 0.00 | - | - |
| RUN DOWN | 14 | 13 | 0 | 0.00 | - | - |
| SCOUT SPOT | 2 | 2 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 5 | 5 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 3 | not checked | - | - | - | - |
| SET CREDITED ONCE | 3 | 2 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 15 | not checked | - | - | - | - |
| SHOTS AFTER THE MOVES | 4 | 4 | 0 | 0.00 | - | - |
| SPELL WORTH | 5 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 3 | 3 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 62 | 55 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 3 | 3 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 2 | 2 | 0 | 0.00 | - | - |
| STANDS STILL | 109 | 106 | 0 | 0.00 | - | - |
| STAY WORTH | 15 | 12 | 0 | 0.00 | - | - |
| STOPS | 1 | 1 | 0 | 0.00 | - | - |
| STUPIDITY NEXT TURN | 8 | 8 | 0 | 0.00 | - | - |
| SURE REACH TOGETHER | 1 | 1 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 6 | not checked | - | - | - | - |
| THE PROMISE ADDS | 3 | 2 | 0 | 0.00 | - | - |
| THE PROMISED MOVE | 2 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 23 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 20 | not checked | - | - | - | - |
| THE TABLE BINDS | 223 | not checked | - | - | - | - |
| WAITS AGAIN | 14 | 13 | 0 | 0.00 | - | - |
| WHOLE FIGHT | 5 | 5 | 0 | 0.00 | - | - |

### Off best figure: cora-bb45c30-p22

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| PROMISE BY ITS OWN SUM | rule | 2.67 | 5.33 | 75.4 |
| ARMY TABLE | rule | 4.33 | 2.00 | 71.8 |
| JOB FIRST | gate | 2.67 | 2.67 | 26.1 |
| JOINT CHARGE NOW | rule | 0.67 | 0.67 | 34.5 |
| CHARGE NOW FIRST | rule | - | 1.00 | 55.9 |
| ONE PROMISE A TARGET | rule | - | 1.00 | 46.7 |
| PIVOT GUARDS FLANK | rule | 0.33 | 0.67 | 6.0 |
| CHAFF PASSED | rule | 0.67 | - | 12.7 |
| FIGHT ORDER BAND | gate | 0.33 | 0.33 | 0.9 |
| HOLDER ASSIGNMENT | rule | 0.67 | - | 30.9 |
| AFTERMATH BAND | gate | 0.33 | - | 0.6 |
| NO REASON | gate | - | 0.33 | 27.4 |
| SET UP BY THE SET | rule | - | 0.33 | 30.7 |
| SUPPORT NARROWED | rule | - | 0.33 | 1.0 |

### Plans: cora-bb45c30-p22

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 3.0 | 44% | 353 | 248 | 70% |
| Mine | move | 31.7 | 86% | 2175 | 0 | 0% |
| Mine | shoot | 1.0 | 33% | 96 | 55 | 57% |
| Opponent | charge | 6.7 | 65% | 1177 | 751 | 64% |
| Opponent | join | 2.3 | 86% | 81 | 0 | 0% |
| Opponent | move | 34.3 | 96% | 2127 | 0 | 0% |
| Opponent | support | 1.3 | 100% | 36 | 0 | 0% |

### Packages: hunt the guns, cora-bb45c30-p22

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.3 | 1 | 0 | 100% | 100% | 0% | 2.0 | 193 | 192 | 100% | 0 |
| Opponent | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Ogre Kingdoms | 1.0 | 1 | 0 | 100% | 100% | 0% | 2.0 | 193 | 192 | 100% | 0 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Vampire Counts | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Warriors of Chaos | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |

### Battle groups: cora-bb45c30-p22

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 4.0 | 8% | 100% | 0% | - | 0% | 0% | 0% | 100% | 0% |
| Opponent | REDIRECT COUNTER | 4.7 | 21% | 33% | 33% | 0% | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: cora-bb45c30-p22

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Mine | Chaff | 7 | 115 (7) | 79 | 36 | 0 | 43% | 3.5 | 120 (6) | 75 (1) | - | 120 (6) | 75 (1) |
| Mine | Character | 7 | 19 (7) | 19 | 0 | 96 | 14% | 1.3 | 0 (1) | 57 (3) | 0 (1) | 30 (3) | 14 (2) |
| Mine | Clean-up | 2 | 13 (2) | 0 | 13 | 84 | 100% | - | 13 (2) | - | - | 0 (1) | 15 (1) |
| Mine | Fast Hammer | 1 | 0 (1) | 0 | 0 | 0 | 0% | 1.0 | - | 0 (1) | - | 0 (1) | - |
| Mine | Hammer | 10 | 20 (10) | 14 | 6 | 96 | 10% | 1.8 | 49 (2) | 20 (5) | 0 (3) | 39 (4) | 9 (6) |
| Mine | Holder | 3 | 36 (3) | 0 | 36 | 46 | 33% | 3.5 | 0 (1) | 66 (2) | - | 36 (3) | - |
| Mine | Shooter | 3 | 0 (3) | 0 | 0 | 67 | 0% | 1.3 | 0 (1) | 0 (2) | - | 0 (2) | 0 (1) |
| Mine | Wizard | 3 | 0 (3) | 0 | 0 | 88 | 0% | 2.0 | - | 0 (1) | - | 0 (1) | - |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Chaff | 9 | 53 (9) | 0 | 53 | 21 | 44% | 4.4 | 0 (4) | 300 (2) | 0 (3) | 150 (4) | 0 (5) |
| Opponent | Character | 10 | 116 (10) | 116 | 0 | 0 | 20% | 3.0 | 50 (4) | 129 (5) | 181 (1) | 117 (5) | 113 (5) |
| Opponent | Clean-up | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Fast Hammer | 8 | 66 (8) | 61 | 5 | 30 | 25% | 2.0 | 0 (2) | 95 (4) | 88 (2) | 68 (5) | 61 (3) |
| Opponent | Hammer | 2 | 103 (2) | 42 | 61 | 0 | 50% | 3.0 | - | 103 (2) | - | 123 (1) | 93 (1) |
| Opponent | Holder | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Support | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Wizard | 4 | 0 (4) | 0 | 0 | 50 | 25% | 1.3 | 0 (1) | 0 (1) | 0 (2) | - | 0 (4) |

### Charged fights: cora-bb45c30-p22

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Ogre Kingdoms | 1 | 60 | 451 | 5.0 | 1.4 | 90 | 0 | +90 | 1 of 5 | 5 of 5 | +38 | +125 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 186 | 3.0 | 1.0 | 62 | 153 | -91 | 1 of 3 | 1 of 3 | - | -91 |
| Mine | Skaven | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| **Mine** | all armies | 3 | 20 | 212 | 2.7 | 1.2 | 80 | 58 | +22 | 2 of 8 | 6 of 8 | +38 | +17 |
| Opponent | Vampire Counts | 2 | 148 | 864 | 6.0 | 1.2 | 144 | 0 | +144 | 4 of 12 | 6 of 12 | +163 | +140 |
| Opponent | Warriors of Chaos | 1 | 0 | 1574 | 3.0 | 1.0 | 525 | 0 | +525 | 3 of 3 | 3 of 3 | - | +525 |
| **Opponent** | all armies | 3 | 99 | 1101 | 5.0 | 1.1 | 220 | 0 | +220 | 7 of 15 | 9 of 15 | +163 | +229 |

### Effective charges: cora-bb45c30-p22

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Ogre Kingdoms | 5 | 1 (net +0) | 0 | 2 (net +93) | 1 (net +190) | 0 | 1 (net +75) | 0 | 40% (2 of 5) |
| Opponent | Vampire Counts | 12 | 3 (net +135) | 0 | 2 (net +0) | 3 (net +187) | 0 | 3 (net +179) | 1 | 18% (2 of 11) |
| Opponent | Warriors of Chaos | 3 | 0 | 0 | 0 | 0 | 0 | 3 (net +525) | 0 | 0% (0 of 3) |

### Charged fights, damage counted: cora-bb45c30-p22

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 1 | 337 | 186 | +0 | 0 | 0 | +0 | +0.0 |
| Mine | Effective (55-75%) | 2 | 251 | 186 | +93 | 93 | 0 | +93 | +37.1 |
| Mine | 76-89% | 1 | 34 | 190 | +190 | 190 | 0 | +190 | +558.8 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 74 | 75 | +75 | 75 | 8 | +66 | +89.9 |
| Mine | No odds | 3 | 251 | 281 | -91 | 62 | 153 | -91 | -36.4 |
| Mine | All fights | 8 | 212 | 208 | +22 | 80 | 59 | +21 | +9.9 |
| Opponent | Long shot (under 50%) | 3 | 236 | 237 | +135 | 221 | 0 | +221 | +93.7 |
| Opponent | Effective (55-75%) | 2 | 245 | 192 | +0 | 0 | 0 | +0 | +0.0 |
| Opponent | 76-89% | 3 | 110 | 211 | +187 | 253 | 16 | +237 | +215.2 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 6 | 345 | 231 | +352 | 352 | 24 | +328 | +95.0 |
| Opponent | No odds | 1 | 186 | 228 | +228 | 228 | 0 | +228 | +122.6 |
| Opponent | All fights | 15 | 252 | 223 | +220 | 251 | 13 | +238 | +94.3 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| cora-bb45c30-p22 | move | 25 | 6 (24%) | 5 (20%) | 2 (8%) | 17 (68%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L1827, L1927 |
| Elixir of Power | Mine | L1927 |
| Fistful of Laurels | Mine | L1827 |
| Invocation of Nehek | Opponent | L1827, L1927 |
| Periapt of Soul Exchange | Mine | L2029 |

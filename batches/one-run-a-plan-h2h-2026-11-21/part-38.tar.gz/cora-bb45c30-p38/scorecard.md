# Doctrine scorecard: cora-bb45c30-p38

### Scorecard: cora-bb45c30-p38

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0222 | 6 | 1 | Mine | no | 3 | 2 | 0 | 4 | 0 | 0 | 0 | 0 |
| L0222 | 6 | 1 | Opponent | no | 2 | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L0307 | 1 | 1 | Mine | yes | 1 | - | 0 | 2 | 0 | 0 | 0 | 675 |
| L0307 | 1 | 1 | Opponent | no | 7 | 5 | 1 | 3 | 0 | 0 | 0 | 375 |
| L0323 | 5 | 1 | Mine | yes | - | 2 | 3 | 3 | 0 | 0 | 0 | 590 |
| L0323 | 5 | 1 | Opponent | yes | - | 4 | 2 | 2 | 1 | 0 | 0 | 185 |
| **Average** | | | Mine | 67% | 2.0 | 2.0 | 1.0 | 3.0 | 0.0 | 0.0 | 0.0 | 421.7 |
| **Average** | | | Opponent | 33% | 4.5 | 3.7 | 2.0 | 2.0 | 0.3 | 0.0 | 0.0 | 186.7 |

### KPIs: cora-bb45c30-p38

Rules off - Opponent only: ONE RUN A PLAN.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 31% (4 of 13) | 0% (0 of 16) | 14% (4 of 29) |
| Winner chose to follow up after the loser gave ground |  | 33% (1 of 3); on the table 33% | 0% (0 of 1); on the table 0% | 25% (1 of 4); on the table 25% |
| Winner chose to pursue after the loser fell back in good order |  | - | 0% (0 of 1); on the table 0% | 0% (0 of 1); on the table 0% |
| Winner chose to pursue after the loser fled |  | 100% (1 of 1); on the table 100% | - | 100% (1 of 1); on the table 100% |
| Winner chose to follow up or pursue (all three) |  | 50% (2 of 4); on the table 50% | 0% (0 of 2); on the table 0% | 33% (2 of 6); on the table 33% |
| Magic missiles tried each own turn | 50%+ | 44% (16 of 36) | 83% (5 of 6) | 50% (21 of 42) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 44% (16 of 36) | 83% (5 of 6) | 50% (21 of 42) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 0% (0 of 3) | - | 0% (0 of 3) |
| Points that never fought | lower | 56% (3281 of 5897) | 69% (4123 of 5999) | 62% (7404 of 11896) |
|   infantry points that never fought | lower | 54% (770 of 1437) | 100% (938 of 938) | 72% (1708 of 2375) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 68% (15 of 22) | 55% (11 of 20) | 62% (26 of 42) |
| Bound items with a magic missile used (at least once a game) |  | 100% (2 of 2); 3.0 uses a game | 0.0 uses a game | 100% (2 of 2); 1.5 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 100% (4 of 4); 1.3 uses a game | 0% (0 of 1); 0.0 uses a game | 80% (4 of 5); 0.7 uses a game |
|   their share of the points of units over 100 pts | lower | 63% (2823 of 4484) | 54% (2494 of 4648) | 58% (5317 of 9132) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 6.0 (90%) | 0.0 (0%) | 6.0 (86%) |
| MARCHED: its unit marched | 0.7 (10%) | 0.3 (100%) | 1.0 (14%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 6.0 | 1.7 | 7.0 | 0.7 | 0.0 |
| not cast | 0.0 | 2.3 | 7.0 | 1.3 | 8.0 |
| NOT CHOSEN: could have been cast at a target | - | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (4%) |
| NO TARGET: no enemy in range, sight and arc it may target | - | 0.0 (0%) | 6.0 (86%) | 0.3 (25%) | 0.0 (0%) |
| MARCHED: its unit marched | - | 0.0 (0%) | 1.0 (14%) | 0.3 (25%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | - | 0.0 (0%) | 0.0 (0%) | 0.7 (50%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | - | 2.3 (100%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | - | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 7.7 (96%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.7 a game | 0.0 a game | 0.8 a game |
| stood (cast and not dispelled) | 60% (3 of 5) | - | 60% (3 of 5) |
| the unit moved after it | 67% (2 of 3) | - | 67% (2 of 3) |
| it charged on its next turn | 0% (0 of 3) | - | 0% (0 of 3) |
| the enemy charged it first | 0% (0 of 3) | - | 0% (0 of 3) |
| it fought by the end of its next turn | 0% (0 of 3) | - | 0% (0 of 3) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 3) | - | 0% (0 of 3) |
| none of these (no charge, no fight, no charge escaped) | 100% (3 of 3) | - | 100% (3 of 3) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 85% (45 of 53) | 65% (72 of 110) | 72% (117 of 163) |
|   cavalry | - | 100% (15 of 15) | 100% (15 of 15) |
|   character | - | 0% (0 of 21) | 0% (0 of 21) |
|   chariot | 67% (14 of 21) | 67% (2 of 3) | 67% (16 of 24) |
|   infantry | - | 75% (44 of 59) | 75% (44 of 59) |
|   war machine | 97% (31 of 32) | 92% (11 of 12) | 95% (42 of 44) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 0.3 (12%) | 1.0 (8%) | 1.3 (9%) |
| CHARGED: it charged | 1.0 (38%) | 2.7 (21%) | 3.7 (24%) |
| IN COMBAT: it fought this turn or the last | 0.3 (12%) | 0.3 (3%) | 0.7 (4%) |
| NO TARGET IN RANGE | 0.3 (12%) | 7.0 (55%) | 7.3 (48%) |
| ONLY IN COMBAT: the only targets were in combat | 0.0 (0%) | 0.7 (5%) | 0.7 (4%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.3 (12%) | 0.7 (5%) | 1.0 (7%) |
| SHELTERED: the target was sheltered | 0.0 (0%) | 0.3 (3%) | 0.3 (2%) |
| OTHER BAR | 0.3 (12%) | 0.0 (0%) | 0.3 (2%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 7.3 | 1.0 | 91% | 1.5 pts | 11 pts |
| chariot | 5.3 | 4.3 | 56% | 18.0 pts | 96 pts |
| infantry | 17.7 | 7.3 | 75% | 6.9 pts | 121 pts |
| war machine | 14.7 | 20.7 | 61% | 44.0 pts | 646 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 2.0 | 4.7 | 3.3 |
| Charges that made contact a game | 2.0 | 1.7 | 1.8 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.00 declared, 0.00 contact (4 units) | 0.00 declared, 0.00 contact (1 units) | 0.00 declared, 0.00 contact (5 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | - | - |
|   per unit a game, the other units (no war machines, no joined characters) | 0.30 declared, 0.30 contact (20 units) | 0.47 declared, 0.17 contact (30 units) | 0.40 declared, 0.22 contact (50 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 100% (3 of 3) | 0% (0 of 1) | - | 75% (3 of 4) |
| Character in a unit | 80% (4 of 5) | 100% (2 of 2) | - | 86% (6 of 7) |
| Character on its own | 100% (1 of 1) | - | 60% (3 of 5) | 67% (4 of 6) |
| Chariot | - | 50% (2 of 4) | - | 50% (2 of 4) |
| Infantry | 0% (0 of 2) | 33% (1 of 3) | - | 20% (1 of 5) |
| Monster | 40% (2 of 5) | - | - | 40% (2 of 5) |
| War Machines | 78% (7 of 9) | 50% (1 of 2) | - | 73% (8 of 11) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 1 | 0% (0 of 1); on the table 0% | 58% (7 of 12) | 18% | 67% (4 of 6) | 100% (2 of 2); 9.0 uses a game | 0.0 uses a game | 100% (2 of 2); 2.0 uses a game |
| Chaos Dwarfs | 2 | 67% (2 of 3); on the table 67% | 38% (9 of 24) | 74% | 69% (11 of 16) | 0.0 uses a game | 0.0 uses a game | 100% (2 of 2); 1.0 uses a game |
| Empire of Man | 1 | - | 83% (5 of 6) | 91% | 80% (8 of 10) | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Tomb Kings of Khemri | 2 | 0% (0 of 2); on the table 0% | - | 58% | 30% (3 of 10) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (cora-bb45c30-p38, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 40% (2) | 0% (0) | 29% (2) |
| ...free all their last turn and able to turn (per game) | 0.67 | 0.00 | 0.67 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.67 | 0.00 | 0.67 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: cora-bb45c30-p38

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 0.7 | 2.7 |
| Strategy | Charge objectives carried out (made contact) | 100% (6 of 6) | 33% (4 of 12) |
| Strategy | Shoot objectives carried out (shot that target) | 50% (22 of 44) | 49% (19 of 39) |
| Strategy | Joined characters whose unit fought | 86% (6 of 7) | 0% (0 of 4) |
| Strategy | Lone characters that fought | 0% (0 of 5) | 43% (3 of 7) |
| Movement | Charges halted short of contact | 0.0 | 0.3 |
| Movement | Idle units | 3.0 | 2.0 |
| Movement | Points that never moved of their own | 421.7 | 186.7 |
| Movement | Fights charged into per game | 1.7 | 1.7 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 5 | 2 of 5, net +0 |
| Movement | Charges with odds: sweet spot (55-75%) | 1 of 5, net +0 | 2 of 5, net +155 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 1 of 5, net +66 | 1 of 5, net +85 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 of 5, net -143 | 0 of 5 |
| Shooting | Shots by shooting units (incl. breath weapons) | 4.7 | 21.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 57% (8 of 14) | 25% (16 of 64) |
| Shooting | Points destroyed by shooting units | 60.0 | 92.0 |
| Shooting | War machine shots | 10.7 | 3.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 34% (11 of 32) | 55% (6 of 11) |
| Shooting | Points destroyed by war machines | 65.0 | 36.7 |
| Magic | Magic missiles cast | 3.0 | 1.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 22% (2 of 9) | 25% (1 of 4) |
| Magic | Wounds caused by magic missiles | 3.7 | 1.7 |
| Magic | Points destroyed by magic (all spells) | 89.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.0 / 0.0 / 0.0 / 0.0 | 5.3 / 0.0 / 0.0 / 0.7 |
| Combat | Points destroyed in combat | 46.0 | 291.7 |
| Combat | Points run down | 0.0 | 28.0 |
| Combat | Net points per charged fight, damage counted | -59 | +21 |
| Combat | Net per 100 charger points, damage counted | -26.6 | +5.6 |
| Combat | First round won (charged fights) | 60% | 60% |
| Combat | Net points per charged fight | -73 | +79 |
| Combat | Net points per supported fight / lone fight | +20 / -96 | - / +79 |
| Combat | Charged fights on a top-3 enemy unit | 2 of 5 | 4 of 5 |
| Game | Points lost | 654.7 | 260.0 |
| Game | VP from objectives | 346.7 | 980.0 |
| Game | Lone holders (player turns) | 2.0 | 4.5 |

- Mine won / drew / lost: 0 / 0 / 3 of 3 ended games (of 3); mean margin (Mine - Opponent) -1028 VP
- The side that went first won 1 of 3 games with a winner
- Points traded per game (both sides' losses): 915
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: cora-bb45c30-p38

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.7 | +198.2 | 0.0 | 103.3 | 0.3 | +11.5 | 0.0 | 24.0 |
| AFTERMATH WITH FRIENDS | - | - | - | - | 0.3 | +45.8 | 0.0 | 65.0 |
| ARMY TABLE | 11.7 | +19.9 | 0.0 | 123.0 | 24.7 | +524.4 | 0.0 | 114.0 |
| ARTILLERY RE-ROLL WEIGHED | 3.7 | +0.0 | 0.0 | 93.3 | 1.3 | +0.0 | 0.0 | 0.0 |
| BEST PRIZE | - | - | - | - | 0.7 | -54.7 | 17.3 | 0.0 |
| CANNON PLAN MISSED | 0.7 | +0.0 | 23.3 | 0.0 | - | - | - | - |
| CANNON PLANNED TARGET | 8.7 | +23.0 | 120.0 | 286.7 | 3.7 | +173.6 | 120.0 | 0.0 |
| CANNON SIGHT KEPT | 1.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 41.7 |
| CARRIES OUT SET-UP | - | - | - | - | 0.3 | +0.0 | 31.7 | 0.0 |
| CAST JOB | 3.3 | +35.1 | 0.0 | 0.0 | 1.7 | +21.3 | 0.0 | 0.0 |
| CASTER AWAY FROM SCREEN | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CASTING BLOCK | 1.3 | +122.7 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | 1.3 | +24.2 | 0.0 | 0.0 | - | - | - | - |
| CHAFF PASSED | - | - | - | - | 0.3 | -0.5 | 56.7 | 0.0 |
| CHARGE LOSSES | 19.3 | -935.1 | 0.0 | 108.7 | 21.0 | -455.2 | 0.0 | 273.3 |
| CHARGE NOW FIRST | 1.3 | +0.0 | 70.0 | 120.7 | 2.0 | +0.0 | 112.7 | 0.0 |
| CLOSES ON WHAT IT BEATS | 11.3 | +0.0 | 0.0 | 87.7 | 13.3 | +0.0 | 0.0 | 46.7 |
| COMBAT PIVOT | - | - | - | - | 1.0 | +0.0 | 206.7 | 0.0 |
| CONVEYANCE SEARCH | 0.7 | +11.8 | 0.0 | 0.0 | - | - | - | - |
| COVER ONCE | 12.7 | -878.3 | 0.0 | 132.3 | 2.0 | -79.2 | 0.0 | 23.3 |
| DEPLOY BY FIGURES | 9.0 | -61.4 | 0.0 | 0.0 | 7.3 | -45.6 | 0.0 | 41.7 |
| ENGINEER BY LORE | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| EXACT ROUND | 2.0 | +32.6 | 159.0 | 224.0 | 3.7 | +32.7 | 355.0 | 0.0 |
| FALL BACK GOOD ORDER | 2.0 | +0.0 | 159.0 | 224.0 | 3.7 | +0.0 | 326.7 | 0.0 |
| FALLS SHORT | 7.3 | +206.2 | 0.0 | 155.7 | 15.0 | +130.2 | 0.0 | 90.7 |
| FEATURE BUFFS | 6.3 | +136.9 | 0.0 | 175.3 | 4.0 | +80.4 | 0.0 | 44.0 |
| FIGHT TO THE END | - | - | - | - | 1.3 | +108.1 | 166.7 | 0.0 |
| FIRE IN ORDER | 0.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 28.3 | 0.0 |
| FIVE ACTION | 91.0 | +2981.9 | 709.0 | 1563.3 | 110.7 | +9445.1 | 1648.3 | 526.0 |
| FLANK NOT WEIGHED | 11.0 | +0.0 | 0.0 | 147.7 | 1.3 | +0.0 | 0.0 | 0.0 |
| FOLLOW UP WEIGHED | 0.3 | +143.3 | 0.0 | 103.3 | - | - | - | - |
| FOUR ROUNDS | 2.0 | +58.1 | 159.0 | 224.0 | 4.7 | +546.5 | 411.0 | 0.0 |
| FREED FROM HIS FIGHT | 2.7 | +0.0 | 0.0 | 45.3 | - | - | - | - |
| FRIEND SHOOTS FIRST | 0.7 | -33.0 | 0.0 | 56.7 | 0.7 | -5.1 | 0.0 | 0.0 |
| GIVES UP | - | - | - | - | 1.3 | -21.9 | 63.3 | 0.0 |
| GOAL WALK | 14.0 | +845.5 | 0.0 | 0.0 | 18.3 | +2093.5 | 0.0 | 116.7 |
| GROUND FLIERS | 0.3 | +3.2 | 0.0 | 0.0 | - | - | - | - |
| GUN FIGURES | 3.0 | +37.4 | 60.0 | 0.0 | - | - | - | - |
| GUN MASK | - | - | - | - | 0.7 | +47.3 | 0.0 | 0.0 |
| HARD STAY DROPPED | 1.7 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 22.0 |
| HE REFORMS ONCE FREED | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS CHARGE BY HIS RUN | 14.0 | +0.0 | 0.0 | 108.7 | 3.7 | +0.0 | 0.0 | 23.3 |
| HIS CHARGE DENIED | 0.3 | +14.3 | 0.0 | 103.3 | 0.7 | +30.3 | 0.0 | 0.0 |
| HIS CHARGE LIST | 8.3 | +0.0 | 0.0 | 165.3 | 1.0 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 3.7 | +0.0 | 0.0 | 54.0 | 5.0 | +0.0 | 0.0 | 48.0 |
| HIS MOVE AND SHOT | 4.7 | -54.4 | 0.0 | 241.3 | 3.0 | -114.5 | 0.0 | 118.7 |
| HIS ONE QUARTER | 4.3 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 8.3 | +0.0 | 0.0 | 128.0 | 6.3 | +0.0 | 0.0 | 48.0 |
| HIS RANDOM MOVE | - | - | - | - | 6.7 | +0.0 | 0.0 | 48.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 51.0 | +1488.9 | 0.0 | 653.3 | 53.3 | +1918.9 | 0.0 | 452.7 |
| HIS SHOTS BY HIS RUN | 47.3 | +782.8 | 0.0 | 629.3 | 50.0 | +755.3 | 0.0 | 502.7 |
| HIS TURN DENIED | 0.3 | +1.4 | 24.0 | 0.0 | 1.0 | +50.0 | 103.3 | 0.0 |
| HIS TURN RUN | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 15.7 | +0.0 | 0.0 | 238.7 | 28.3 | +0.0 | 0.0 | 136.0 |
| HOLDER ASSIGNMENT | 7.3 | +624.4 | 0.0 | 87.7 | 16.3 | +1595.8 | 0.0 | 46.0 |
| HOLDS AMBUSHERS | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 2.0 | -32.5 | 159.0 | 224.0 | 4.3 | -181.7 | 411.0 | 0.0 |
| HUNT IN PAIRS | - | - | - | - | 0.3 | +105.3 | 0.0 | 0.0 |
| IDLE COST | 7.7 | -49.5 | 0.0 | 102.3 | 13.3 | -204.8 | 0.0 | 106.7 |
| JOINT CHARGE NOW | 0.3 | -20.1 | 24.0 | 0.0 | 0.3 | -4.9 | 28.0 | 0.0 |
| KEEP FALLS | 0.7 | +4.7 | 0.0 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | - | - | - | - | 5.3 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | - | - | - | - | 1.3 | +45.8 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 1.3 | +0.0 | 0.0 | 103.3 | 11.7 | +0.0 | 509.3 | 403.0 |
| LONE WIZARD KEPT IN | 0.7 | +17.5 | 0.0 | 0.0 | 1.0 | +78.3 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | 0.3 | -0.0 | 24.0 | 0.0 | 2.0 | +2.9 | 119.3 | 0.0 |
| MAKE SURE TOGETHER | - | - | - | - | 0.7 | +2.9 | 0.0 | 0.0 |
| MANOEUVRE | 2.3 | -4.7 | 0.0 | 0.0 | 1.0 | -18.5 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.7 | +3.9 | 0.0 | 0.0 | - | - | - | - |
| MARCH BY THE SUM | 0.3 | +3.8 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | 1.7 | +58.8 | 0.0 | 54.0 | - | - | - | - |
| MARCH ODDS | - | - | - | - | 0.3 | +22.5 | 0.0 | 0.0 |
| MARCH OF THE TABLE | 0.7 | +3.8 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 0.7 | -5.1 | 0.0 | 0.0 | 0.3 | +22.4 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | - | - | - | - | 1.7 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 3.0 | +52.7 | 0.0 | 54.0 | 2.0 | +23.8 | 0.0 | 0.0 |
| MEETS IN TIME | 3.3 | +203.8 | 0.0 | 0.0 | 1.7 | +142.6 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 6.3 | +161.6 | 0.0 | 54.0 | 1.7 | +45.3 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 8.0 | +100.4 | 0.0 | 54.0 | 1.7 | +38.8 | 0.0 | 0.0 |
| MISSILES ON ONE TARGET | 1.0 | -25.7 | 0.0 | 0.0 | - | - | - | - |
| MOVE ORDER | 1.7 | +0.0 | 28.3 | 28.3 | 1.7 | +0.0 | 24.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 6.0 | +261.5 | 0.0 | 74.0 | 5.7 | +579.9 | 0.0 | 0.0 |
| MOVES UNITS SPELL | 0.3 | +18.4 | 0.0 | 0.0 | - | - | - | - |
| NEARER NOT NEEDED | 6.7 | +335.0 | 0.0 | 87.7 | 10.0 | +436.6 | 0.0 | 22.0 |
| NEXT CHARGE BY LIST | 4.3 | +205.2 | 0.0 | 56.7 | 4.3 | +535.2 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 1.3 | -20.8 | 72.0 | 120.7 | 3.7 | -125.2 | 244.3 | 0.0 |
| NO LATE CUT | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OFF BEST | 4.3 | -146.9 | 0.0 | 90.7 | 8.7 | -350.7 | 31.7 | 23.3 |
| OGRE LOADER SECOND SHOT | 3.7 | +2.5 | 0.0 | 0.0 | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ONE FIGHT FORMULA | 4.0 | -16.0 | 0.0 | 71.3 | 7.0 | -155.1 | 0.0 | 0.0 |
| ONE JOINT FIGURE | - | - | - | - | 0.7 | +107.9 | 103.3 | 0.0 |
| ONE OBJECTIVE FORMULA | 5.0 | +46.8 | 0.0 | 56.0 | 6.3 | +174.8 | 0.0 | 46.0 |
| ONE PROMISE A TARGET | - | - | - | - | 0.7 | -17.5 | 0.0 | 0.0 |
| ONE ROUTE | - | - | - | - | 1.7 | +0.0 | 0.0 | 0.0 |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| OPENS UP | - | - | - | - | 1.3 | +42.8 | 63.3 | 0.0 |
| OVERRUNS AWAY | 1.0 | +88.7 | 89.0 | 206.7 | 1.3 | +12.0 | 87.7 | 0.0 |
| PATHS CROSS | 0.3 | +7.1 | 0.0 | 0.0 | 0.7 | +7.2 | 0.0 | 0.0 |
| PLAN RESULT | 41.3 | +388.7 | 352.3 | 1084.7 | 48.3 | +736.0 | 379.0 | 301.7 |
| PROMISE BELOW ZERO | 1.0 | +0.0 | 0.0 | 17.3 | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE BY ITS OWN SUM | 5.7 | -54.6 | 0.0 | 0.0 | 9.3 | -195.2 | 0.0 | 0.0 |
| PROMISE IN STEPS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | 0.7 | -23.6 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| QUARTER ODDS | 17.0 | +1212.9 | 398.3 | 196.7 | 17.3 | +2140.9 | 310.0 | 130.0 |
| RANDOM MOVE BY FIGURES | 1.0 | +0.0 | 0.0 | 113.3 | - | - | - | - |
| REAL GROUND | - | - | - | - | 1.7 | +0.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | 2.3 | +78.5 | 0.0 | 110.7 | 2.7 | +84.4 | 0.0 | 46.0 |
| REDIRECT FOR A FRIEND IN REACH | 3.0 | +0.0 | 0.0 | 141.3 | 4.3 | +0.0 | 0.0 | 68.0 |
| REDIRECT WEIGHED | - | - | - | - | 1.7 | -29.3 | 64.0 | 0.0 |
| REFORMS TO MEET IT | 0.7 | -0.3 | 0.0 | 0.0 | 2.0 | -75.4 | 0.0 | 0.0 |
| RESERVE FALL BACK | - | - | - | - | 1.3 | +11.7 | 0.0 | 23.3 |
| RESERVE MOVE SPELL | 0.3 | +6.9 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | 2.0 | +13.6 | 159.0 | 224.0 | 3.3 | +16.5 | 222.7 | 0.0 |
| RISK ON THE WAY | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| ROUNDS AFTER TERROR | - | - | - | - | 2.0 | -54.2 | 147.7 | 0.0 |
| RUN DOWN | - | - | - | - | 2.7 | -10.8 | 147.7 | 0.0 |
| SCOUT SPOT | - | - | - | - | 2.0 | +1.8 | 0.0 | 0.0 |
| SCOUT WAITS | - | - | - | - | 2.0 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 1.3 | -172.0 | 0.0 | 0.0 | - | - | - | - |
| SEARCH SPOT | 0.3 | +9.6 | 0.0 | 0.0 | - | - | - | - |
| SECOND LOOK | - | - | - | - | 0.7 | +10.9 | 31.7 | 0.0 |
| SET CREDITED ONCE | - | - | - | - | 1.0 | -323.8 | 0.0 | 0.0 |
| SET UP BY THE SET | 0.3 | -22.6 | 0.0 | 0.0 | 1.3 | +120.6 | 0.0 | 0.0 |
| SET UP TOGETHER | - | - | - | - | 1.3 | +6.5 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | - | - | - | - | 0.3 | +1.3 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 15.7 | +0.0 | 0.0 | 286.7 | 14.0 | +0.0 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 4.0 | +81.7 | 260.0 | 0.0 | 1.0 | +5.7 | 27.0 | 0.0 |
| SHOT OR CHARGE | 0.3 | -0.1 | 0.0 | 0.0 | 0.7 | -5.5 | 0.0 | 0.0 |
| SHOT REPLANNED | 0.3 | +0.0 | 23.3 | 0.0 | - | - | - | - |
| SHOT RISK POINTS | 27.3 | -88.5 | 0.0 | 488.0 | 35.0 | -161.7 | 0.0 | 502.0 |
| SHOTS AFTER THE MOVES | 4.0 | +0.0 | 0.0 | 0.0 | 5.3 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 15.3 | +422.5 | 0.0 | 323.3 | 25.7 | +504.0 | 0.0 | 68.0 |
| SPOT AS THE GAME MOVES | 9.3 | +0.0 | 0.0 | 233.0 | 5.0 | +0.0 | 0.0 | 0.0 |
| STAND AND SHOOT | 0.7 | -0.8 | 48.0 | 0.0 | 0.3 | -3.4 | 103.3 | 0.0 |
| STANDS FOR A REASON | - | - | - | - | 5.0 | +0.0 | 0.0 | 44.0 |
| STANDS STILL | 45.7 | +0.0 | 550.0 | 731.3 | 44.3 | +0.0 | 1237.3 | 197.3 |
| STAY WORTH | 25.0 | -396.2 | 193.3 | 646.7 | 40.0 | +486.7 | 904.7 | 22.0 |
| STRIKE BY THE ODDS | 0.3 | +0.3 | 65.0 | 103.3 | 0.3 | +2.0 | 0.0 | 0.0 |
| STUCK PIVOT | 0.3 | +0.0 | 0.0 | 56.7 | - | - | - | - |
| SUPPORT ADDS | 4.0 | +596.5 | 0.0 | 0.0 | 4.0 | +70.1 | 0.0 | 46.7 |
| SUPPORT NARROWED | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| SUPPORT WORKED OUT | 4.0 | +596.5 | 0.0 | 0.0 | 4.0 | +70.1 | 0.0 | 46.7 |
| SURE REACH TOGETHER | - | - | - | - | 3.7 | +23.4 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 0.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 22.0 |
| THE PROMISE ADDS | 0.3 | -20.8 | 0.0 | 0.0 | - | - | - | - |
| THE PROMISED MOVE | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 5.3 | +0.0 | 0.0 | 56.7 | 1.7 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 1.7 | +0.0 | 0.0 | 77.3 | 1.7 | +0.0 | 0.0 | 23.3 |
| THE ROW READS HIS LAST RUN | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE STEP BACK IS MADE | 1.3 | +0.0 | 0.0 | 31.7 | 1.3 | +0.0 | 0.0 | 23.3 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 43.0 | +0.0 | 0.0 | 576.3 | 52.7 | +0.0 | 0.0 | 263.0 |
| TIED UP BY THE SUM | 1.7 | +96.8 | 135.0 | 224.0 | 1.7 | +127.7 | 56.0 | 0.0 |
| TIME ON OUR SIDE | 22.0 | +284.6 | 0.0 | 31.7 | 21.0 | +232.1 | 27.0 | 24.0 |
| WAITS AGAIN | 1.0 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| WAR ENGINE JOBS | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WEAPON BY POINTS | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| WHO FIGHTS | 0.7 | +0.8 | 48.0 | 0.0 | 1.0 | +13.7 | 63.3 | 0.0 |
| WHO HITS BACK | - | - | - | - | 0.7 | +81.8 | 0.0 | 65.0 |
| WHOLE FIGHT DANGER | 2.3 | -630.2 | 0.0 | 0.0 | - | - | - | - |
| WOUNDS ON THE RANKS | 3.7 | +102.9 | 0.0 | 0.0 | 2.3 | +134.7 | 0.0 | 0.0 |

### Rule changes: cora-bb45c30-p38

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 109 | 109 | 91 | 30.33 | +2018 | +22.2 |
| HIS SHOT LIST | 313 | 306 | 89 | 29.67 | +1498 | +16.8 |
| HOLDER ASSIGNMENT | 71 | 71 | 67 | 22.33 | +3900 | +58.2 |
| HIS SHOTS BY HIS RUN | 292 | 288 | 59 | 19.67 | +576 | +9.8 |
| LEGAL CHARGES ONLY | 39 | 39 | 39 | 13.00 | +0 | +0.0 |
| OFF BEST | 39 | 39 | 39 | 13.00 | -1493 | -38.3 |
| DEPLOY BY FIGURES | 49 | 49 | 32 | 10.67 | +405 | +12.6 |
| FIVE ACTION | 605 | 590 | 27 | 9.00 | +1393 | +51.6 |
| THE TABLE AGAIN | 36 | 36 | 27 | 9.00 | +0 | +0.0 |
| GOAL WALK | 97 | 95 | 23 | 7.67 | +1509 | +65.6 |
| MOVE TO CHARGE COMPUTED | 35 | 31 | 22 | 7.33 | +664 | +30.2 |
| REDIRECT FOR A FRIEND IN REACH | 22 | 22 | 22 | 7.33 | +0 | +0.0 |
| SHOT RISK POINTS | 187 | 180 | 20 | 6.67 | +285 | +14.3 |
| TIME ON OUR SIDE | 129 | 108 | 20 | 6.67 | +88 | +4.4 |
| NEXT CHARGE BY LIST | 26 | 26 | 18 | 6.00 | +628 | +34.9 |
| PROMISE BY ITS OWN SUM | 45 | 45 | 17 | 5.67 | -750 | -44.1 |
| ARTILLERY RE-ROLL WEIGHED | 15 | 15 | 15 | 5.00 | +0 | +0.0 |
| HARD STAY DROPPED | 13 | 13 | 13 | 4.33 | +0 | +0.0 |
| OGRE LOADER SECOND SHOT | 11 | 11 | 11 | 3.67 | +8 | +0.7 |
| FOUR ROUNDS | 20 | 18 | 10 | 3.33 | +587 | +58.7 |
| MOVE ORDER | 10 | 10 | 10 | 3.33 | +0 | +0.0 |
| STAY WORTH | 195 | 174 | 10 | 3.33 | +71 | +7.1 |
| SUPPORT ADDS | 24 | 23 | 8 | 2.67 | +485 | +60.6 |
| SUPPORT WORKED OUT | 24 | 23 | 8 | 2.67 | +485 | +60.6 |
| TIED UP BY THE SUM | 10 | 9 | 7 | 2.33 | +186 | +26.6 |
| CANNON SIGHT KEPT | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| COVER ONCE | 44 | 27 | 6 | 2.00 | +53 | +8.8 |
| MEETS IN TIME | 15 | 15 | 6 | 2.00 | +516 | +86.1 |
| SCOUT WAITS | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| ADVANCE LANE KEPT | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| LONE WIZARD KEPT IN | 5 | 5 | 5 | 1.67 | +288 | +57.5 |
| MARCH CHECK | 5 | 5 | 5 | 1.67 | +51 | +10.2 |
| REDIRECT WEIGHED | 5 | 5 | 5 | 1.67 | +400 | +80.1 |
| CANNON PLANNED TARGET | 37 | 37 | 4 | 1.33 | -107 | -26.8 |
| CHAFF IN THE MOVE | 4 | 4 | 4 | 1.33 | +1 | +0.1 |
| FIRE IN ORDER | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| LANE BY FIGURES | 4 | 4 | 4 | 1.33 | +137 | +34.3 |
| QUARTER ODDS | 103 | 102 | 4 | 1.33 | +373 | +93.2 |
| RESERVE FALL BACK | 4 | 4 | 4 | 1.33 | +35 | +8.8 |
| AFTERMATH IN POINTS | 3 | 3 | 3 | 1.00 | +629 | +209.7 |
| COMBAT PIVOT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| HOLDS AMBUSHERS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| IDLE COST | 63 | 34 | 3 | 1.00 | +57 | +19.0 |
| MISSILES IN THE MOVE | 24 | 15 | 3 | 1.00 | +24 | +8.0 |
| PATHS CROSS | 3 | 3 | 3 | 1.00 | +43 | +14.3 |
| RISK BY ARC | 16 | 14 | 3 | 1.00 | +9 | +2.9 |
| SHOTS AFTER THE MOVES | 28 | 28 | 3 | 1.00 | +0 | +0.0 |
| BEST PRIZE | 2 | 2 | 2 | 0.67 | -164 | -82.0 |
| CAST JOB | 15 | 15 | 2 | 0.67 | +13 | +6.5 |
| CASTER AWAY FROM SCREEN | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| CASTING BLOCK | 4 | 4 | 2 | 0.67 | +163 | +81.6 |
| EXACT ROUND | 17 | 15 | 2 | 0.67 | +17 | +8.4 |
| FEATURE BUFFS | 31 | 31 | 2 | 0.67 | +27 | +13.4 |
| JOINT CHARGE NOW | 2 | 2 | 2 | 0.67 | -75 | -37.5 |
| KEEP FALLS | 2 | 2 | 2 | 0.67 | +64 | +32.0 |
| MANOEUVRE | 10 | 10 | 2 | 0.67 | +9 | +4.5 |
| MARCH OF THE TABLE | 2 | 2 | 2 | 0.67 | -11 | -5.7 |
| MAX FOR POSITIONING | 15 | 10 | 2 | 0.67 | +26 | +13.1 |
| NEARER NOT NEEDED | 50 | 47 | 2 | 0.67 | +78 | +39.1 |
| ONE PROMISE A TARGET | 2 | 2 | 2 | 0.67 | -52 | -26.2 |
| OPENS UP | 4 | 3 | 2 | 0.67 | +18 | +9.1 |
| PROMISE KNOWS THE FIGHT | 3 | 3 | 2 | 0.67 | -71 | -35.4 |
| REDIRECT COUNTER | 15 | 11 | 2 | 0.67 | +100 | +49.9 |
| SECOND LOOK | 2 | 2 | 2 | 0.67 | +33 | +16.4 |
| SHOTS IN THE MOVE | 123 | 93 | 2 | 0.67 | +55 | +27.4 |
| STRIKE BY THE ODDS | 2 | 2 | 2 | 0.67 | +7 | +3.6 |
| WHO HITS BACK | 2 | 2 | 2 | 0.67 | +136 | +68.2 |
| AFTERMATH WITH FRIENDS | 1 | 1 | 1 | 0.33 | +137 | +137.4 |
| CHAFF PASSED | 1 | 1 | 1 | 0.33 | -1 | -1.4 |
| CHARGE LOSSES | 121 | 119 | 1 | 0.33 | +106 | +105.5 |
| CHARGE NOW FIRST | 10 | 10 | 1 | 0.33 | -2 | -2.3 |
| FALLS SHORT | 67 | 50 | 1 | 0.33 | +48 | +48.2 |
| FIGHT TO THE END | 4 | 3 | 1 | 0.33 | +266 | +265.5 |
| FOLLOW UP WEIGHED | 1 | 1 | 1 | 0.33 | +430 | +429.8 |
| HIS CHARGE DENIED | 3 | 2 | 1 | 0.33 | +2 | +1.5 |
| HONEST WORTH | 19 | 17 | 1 | 0.33 | +16 | +15.7 |
| HUNT IN PAIRS | 1 | 1 | 1 | 0.33 | +308 | +308.3 |
| MARCH BY THE SUM | 1 | 1 | 1 | 0.33 | +11 | +11.4 |
| MARCH ODDS | 1 | 1 | 1 | 0.33 | -54 | -53.9 |
| MOVES UNITS SPELL | 1 | 1 | 1 | 0.33 | +55 | +55.1 |
| ONE FIGHT FORMULA | 33 | 16 | 1 | 0.33 | +6 | +5.6 |
| ONE JOINT FIGURE | 2 | 2 | 1 | 0.33 | +266 | +265.5 |
| ONE OBJECTIVE FORMULA | 34 | 29 | 1 | 0.33 | +22 | +21.8 |
| RESERVE MOVE SPELL | 1 | 1 | 1 | 0.33 | +22 | +21.8 |
| SEARCH SPOT | 1 | 1 | 1 | 0.33 | +29 | +28.8 |
| SET UP BY THE SET | 5 | 5 | 1 | 0.33 | +0 | +0.0 |
| SET UP TOGETHER | 4 | 3 | 1 | 0.33 | +0 | +0.0 |
| SHOOTERS IN TWO RANKS | 1 | 1 | 1 | 0.33 | +4 | +4.0 |
| SHOT REPLANNED | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| STUCK PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| SUPPORT NARROWED | 2 | 2 | 1 | 0.33 | -33 | -33.0 |
| SURE REACH TOGETHER | 11 | 8 | 1 | 0.33 | +3 | +3.0 |
| THE ROW IN ITS ORDER | 21 | 1 | 1 | 0.33 | +0 | +0.0 |
| WAR ENGINE JOBS | 5 | 5 | 1 | 0.33 | -10 | -10.0 |
| WEAPON BY POINTS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| WOUNDS ON THE RANKS | 18 | 18 | 1 | 0.33 | +17 | +16.6 |
| CANNON PLAN MISSED | 2 | 2 | 0 | 0.00 | - | - |
| CARRIES OUT SET-UP | 1 | 1 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 74 | 72 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 2 | not checked | - | - | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 17 | 15 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 37 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 8 | 7 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 4 | 4 | 0 | 0.00 | - | - |
| GIVES UP | 4 | 2 | 0 | 0.00 | - | - |
| GROUND FLIERS | 1 | not checked | - | - | - | - |
| GUN FIGURES | 9 | not checked | - | - | - | - |
| GUN MASK | 2 | 2 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 5 | 5 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 53 | 51 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 28 | 26 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 26 | 25 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 23 | 23 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 21 | 20 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 44 | 39 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 20 | 18 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 4 | 4 | 0 | 0.00 | - | - |
| HIS TURN RUN | 18 | 18 | 0 | 0.00 | - | - |
| HOLD ODDS | 132 | 132 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 16 | 16 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 7 | 6 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 2 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 2 | trace | - | - | - | - |
| MARCH OVER CASTS | 3 | 3 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 5 | 5 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 29 | 20 | 0 | 0.00 | - | - |
| MISSILES ON ONE TARGET | 3 | not checked | - | - | - | - |
| NO DOUBLE ROUNDS | 15 | 14 | 0 | 0.00 | - | - |
| NO LATE CUT | 4 | 4 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 3 | not checked | - | - | - | - |
| ONE ROUTE | 5 | 5 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 18 | 18 | 0 | 0.00 | - | - |
| OVERRUNS AWAY | 7 | 6 | 0 | 0.00 | - | - |
| PLAN RESULT | 269 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 4 | 4 | 0 | 0.00 | - | - |
| PROMISE IN STEPS | 2 | 2 | 0 | 0.00 | - | - |
| RANDOM MOVE BY FIGURES | 3 | 3 | 0 | 0.00 | - | - |
| REAL GROUND | 5 | 5 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 8 | 7 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 2 | 2 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 6 | 5 | 0 | 0.00 | - | - |
| RUN DOWN | 8 | 6 | 0 | 0.00 | - | - |
| SCOUT SPOT | 6 | 6 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 4 | 4 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 3 | 3 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 89 | not checked | - | - | - | - |
| SHOOTS FROM THE BEST SPOT | 15 | 15 | 0 | 0.00 | - | - |
| SHOT OR CHARGE | 3 | 3 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 43 | 32 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 3 | 3 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 15 | 15 | 0 | 0.00 | - | - |
| STANDS STILL | 270 | 264 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 6 | not checked | - | - | - | - |
| THE PROMISE ADDS | 1 | 1 | 0 | 0.00 | - | - |
| THE PROMISED MOVE | 2 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 10 | not checked | - | - | - | - |
| THE ROW READS HIS LAST RUN | 1 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 8 | not checked | - | - | - | - |
| THE TABLE BINDS | 287 | not checked | - | - | - | - |
| WAITS AGAIN | 9 | 8 | 0 | 0.00 | - | - |
| WHO FIGHTS | 5 | 4 | 0 | 0.00 | - | - |
| WHOLE FIGHT DANGER | 7 | 7 | 0 | 0.00 | - | - |

### Off best figure: cora-bb45c30-p38

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 3.67 | 8.00 | 42.0 |
| PROMISE BY ITS OWN SUM | rule | 1.67 | 4.00 | 44.1 |
| ARMY TABLE | rule | 0.67 | 1.67 | 55.2 |
| HOLDER ASSIGNMENT | rule | - | 2.00 | 14.3 |
| AFTERMATH BAND | gate | 0.67 | - | 1.6 |
| BEST PRIZE | rule | - | 0.67 | 82.0 |
| JOINT CHARGE NOW | rule | 0.33 | 0.33 | 37.5 |
| MARCH OF THE TABLE | rule | 0.67 | - | 5.7 |
| PROMISE KNOWS THE FIGHT | rule | 0.67 | - | 35.4 |
| RULE SWITCHED OFF | gate | - | 0.67 | 8.9 |
| CANNON PLANNED TARGET | rule | 0.33 | - | 107.0 |
| CHAFF PASSED | rule | - | 0.33 | 1.4 |
| CHARGE NOW FIRST | rule | - | 0.33 | 2.3 |
| MARCH ODDS | rule | - | 0.33 | 53.9 |
| ONE PROMISE A TARGET | rule | - | 0.33 | 52.4 |
| PATHS CROSS | rule | - | 0.33 | 4.1 |
| REDIRECT WEIGHED | rule | - | 0.33 | 13.4 |
| SUPPORT NARROWED | rule | - | 0.33 | 33.0 |
| WAR ENGINE JOBS | rule | 0.33 | - | 10.0 |

### Plans: cora-bb45c30-p38

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 2.0 | 50% | 160 | 108 | 67% |
| Mine | move | 27.3 | 91% | 1448 | 0 | 0% |
| Mine | shoot | 11.3 | 53% | 207 | 281 | 136% |
| Mine | support | 0.7 | 50% | 0 | 0 | 0% |
| Opponent | charge | 4.0 | 58% | 665 | 341 | 51% |
| Opponent | move | 33.7 | 95% | 2676 | 0 | 0% |
| Opponent | shoot | 10.7 | 66% | 685 | 395 | 58% |

### Battle groups: cora-bb45c30-p38

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 2.3 | 29% | 50% | 0% | - | 0% | 0% | 0% | 50% | 50% |
| Opponent | REDIRECT COUNTER | 2.7 | 38% | 100% | 33% | 0% | 50% | 0% | 0% | 50% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: cora-bb45c30-p38

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Mine | Character | 7 | 7 (7) | 7 | 0 | 0 | 29% | 3.4 | 0 (1) | 0 (1) | 8 (5) | 8 (6) | 0 (1) |
| Mine | Clean-up | 4 | 0 (4) | 0 | 0 | 26 | 100% | - | 0 (1) | 0 (3) | - | 0 (3) | 0 (1) |
| Mine | Fast Hammer | 5 | 22 (5) | 22 | 0 | 84 | 40% | 3.3 | - | 46 (3) | 0 (2) | 26 (4) | 0 (1) |
| Mine | Hammer | 9 | 27 (9) | 10 | 16 | 36 | 11% | 2.6 | 0 (1) | 12 (4) | 51 (4) | 36 (7) | 0 (2) |
| Mine | Holder | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | 0 (1) | - | - | - | 0 (1) |
| Mine | War machine | 8 | 17 (8) | 17 | 0 | 52 | 0% | 1.0 | 21 (2) | 20 (5) | 0 (1) | 16 (3) | 17 (5) |
| Mine | Wizard | 5 | 45 (5) | 45 | 0 | 0 | 40% | 3.7 | 229 (1) | 0 (2) | 0 (2) | 108 (2) | 0 (3) |
| Opponent | Chaff | 5 | 9 (5) | 0 | 9 | 60 | 0% | 1.0 | 0 (1) | 11 (4) | - | 9 (5) | - |
| Opponent | Character | 8 | 37 (8) | 37 | 0 | 0 | 50% | 3.5 | 72 (3) | 32 (2) | 0 (3) | 46 (6) | 0 (2) |
| Opponent | Clean-up | 4 | 55 (4) | 0 | 55 | 51 | 100% | - | 0 (2) | 0 (1) | 113 (1) | 65 (3) | 0 (1) |
| Opponent | Fast Hammer | 6 | 21 (6) | 21 | 0 | 17 | 67% | 4.5 | 0 (3) | 41 (3) | - | 22 (2) | 20 (4) |
| Opponent | Holder | 9 | 122 (9) | 14 | 108 | 0 | 22% | 1.6 | 70 (2) | 203 (3) | 118 (3) | 239 (4) | 33 (4) |
| Opponent | Shooter | 2 | 114 (2) | 55 | 59 | 0 | 0% | 1.5 | 59 (1) | 174 (1) | - | 59 (1) | 174 (1) |
| Opponent | War machine | 3 | 29 (3) | 29 | 0 | 33 | 33% | 1.0 | 29 (3) | - | - | 0 (2) | 88 (1) |
| Opponent | Wizard | 3 | 0 (3) | 0 | 0 | 0 | 0% | 1.0 | 0 (1) | 0 (2) | - | 0 (1) | 0 (2) |

### Charged fights: cora-bb45c30-p38

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 1 | 72 | 72 | 2.0 | 1.5 | 36 | 26 | +10 | 0 of 2 | 1 of 2 | +20 | +0 |
| Mine | Chaos Dwarfs | 2 | 285 | 33 | 1.5 | 1.0 | 22 | 150 | -128 | 2 of 3 | 2 of 3 | - | -128 |
| **Mine** | all armies | 3 | 214 | 46 | 1.7 | 1.2 | 28 | 100 | -73 | 2 of 5 | 3 of 5 | +20 | -96 |
| Opponent | Empire of Man | 1 | 110 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 1 of 1 | 0 of 1 | - | +0 |
| Opponent | Tomb Kings of Khemri | 2 | 138 | 198 | 2.0 | 1.0 | 99 | 0 | +99 | 3 of 4 | 3 of 4 | - | +99 |
| **Opponent** | all armies | 3 | 129 | 132 | 1.7 | 1.0 | 79 | 0 | +79 | 4 of 5 | 3 of 5 | - | +79 |

### Effective charges: cora-bb45c30-p38

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 2 | 0 | 0 | 1 (net +0) | 0 | 0 | 1 (net +20) | 0 | 50% (1 of 2) |
| Mine | Chaos Dwarfs | 3 | 0 | 0 | 0 | 0 | 1 (net +66) | 2 (net -225) | 0 | 0% (0 of 3) |
| Opponent | Empire of Man | 1 | 0 | 0 | 1 (net +0) | 0 | 0 | 0 | 0 | 100% (1 of 1) |
| Opponent | Tomb Kings of Khemri | 4 | 2 (net +0) | 0 | 1 (net +310) | 0 | 1 (net +85) | 0 | 0 | 25% (1 of 4) |

### Charged fights, damage counted: cora-bb45c30-p38

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Effective (55-75%) | 1 | 81 | 72 | +0 | 48 | 35 | +13 | +16.4 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 | 241 | 154 | -143 | 79 | 204 | -125 | -51.9 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 310 | 66 | +66 | 66 | 0 | +66 | +21.3 |
| Mine | All fights | 5 | 223 | 120 | -73 | 70 | 130 | -59 | -26.6 |
| Opponent | Long shot (under 50%) | 2 | 436 | 291 | +0 | 22 | 138 | -117 | -26.8 |
| Opponent | Effective (55-75%) | 2 | 314 | 312 | +155 | 189 | 62 | +127 | +40.4 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 411 | 85 | +85 | 85 | 0 | +85 | +20.7 |
| Opponent | All fights | 5 | 382 | 258 | +79 | 101 | 80 | +21 | +5.6 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| cora-bb45c30-p38 | move | 22 | 4 (18%) | 2 (9%) | 0 (0%) | 18 (82%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Ring of Doom | Mine | L0222 |
| Twice-Blessed Armour | Opponent | L0307 |
| Witch Hunter's Ward | Opponent | L0307 |

# Doctrine scorecard: cora-bb45c30-p11

### Scorecard: cora-bb45c30-p11

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L2127 | 3 | 1 | Mine | yes | 8 | - | 1 | 2 | 0 | 0 | 0 | 500 |
| L2127 | 3 | 1 | Opponent | no | 0 | 2 | 2 | 4 | 0 | 0 | 0 | 0 |
| L2231 | 5 | 1 | Mine | yes | - | 3 | 6 | 1 | 0 | 0 | 0 | 0 |
| L2231 | 5 | 1 | Opponent | yes | - | - | 1 | 2 | 0 | 0 | 0 | 170 |
| L2335 | 1 | 1 | Mine | no | 2 | 3 | 5 | 2 | 1 | 0 | 0 | 185 |
| L2335 | 1 | 1 | Opponent | no | 0 | 1 | 3 | 2 | 0 | 0 | 0 | 126 |
| **Average** | | | Mine | 67% | 5.0 | 3.0 | 4.0 | 1.7 | 0.3 | 0.0 | 0.0 | 228.3 |
| **Average** | | | Opponent | 33% | 0.0 | 1.5 | 2.0 | 2.7 | 0.0 | 0.0 | 0.0 | 98.7 |

### KPIs: cora-bb45c30-p11

Rules off - Mine only: ONE RUN A PLAN.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 14% (2 of 14) | 0% (0 of 15) | 7% (2 of 29) |
| Winner chose to follow up after the loser gave ground |  | 100% (1 of 1); on the table 100% | 100% (1 of 1); on the table 100% | 100% (2 of 2); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | - | - | - |
| Winner chose to pursue after the loser fled |  | 100% (1 of 1); on the table 100% | 0% (0 of 1); on the table 0% | 50% (1 of 2); on the table 50% |
| Winner chose to follow up or pursue (all three) |  | 100% (2 of 2); on the table 100% | 50% (1 of 2); on the table 50% | 75% (3 of 4); on the table 75% |
| Magic missiles tried each own turn | 50%+ | 0% (0 of 6) | 28% (5 of 18) | 21% (5 of 24) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 0% (0 of 2) | 28% (5 of 18) | 25% (5 of 20) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 33% (2 of 6) | 55% (6 of 11) | 47% (8 of 17) |
| Points that never fought | lower | 43% (2564 of 5999) | 44% (2634 of 6000) | 43% (5198 of 11999) |
|   infantry points that never fought | lower | 96% (1492 of 1552) | 65% (674 of 1035) | 84% (2166 of 2587) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 58% (11 of 19) | 53% (16 of 30) | 55% (27 of 49) |
| Bound items with a magic missile used (at least once a game) |  | 100% (1 of 1); 0.3 uses a game | 50% (1 of 2); 1.0 uses a game | 67% (2 of 3); 0.7 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
|   their share of the points of units over 100 pts | lower | 48% (2134 of 4484) | 42% (2331 of 5546) | 45% (4465 of 10030) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 3.3 (77%) | 3.3 (53%) |
| MARCHED: its unit marched | 0.7 (33%) | 0.3 (8%) | 1.0 (16%) |
| GONE: slain | 1.3 (67%) | 0.0 (0%) | 1.3 (21%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.3 (8%) | 0.3 (5%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.3 (8%) | 0.3 (5%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 10.7 | 1.7 | 1.7 | 1.7 | 0.3 | 0.0 |
| not cast | 3.3 | 0.3 | 0.3 | 6.3 | 1.7 | 16.0 |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.3 (100%) | 0.0 (0%) | 3.3 (53%) | 0.3 (20%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.0 (16%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | 1.3 (40%) | 0.0 (0%) | 0.0 (0%) | 1.3 (21%) | 0.0 (0%) | 3.0 (19%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (5%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.3 (100%) | 0.3 (5%) | 1.3 (80%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.0 (60%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 13.0 (81%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.0 a game | 1.7 a game | 0.8 a game |
| stood (cast and not dispelled) | - | 60% (3 of 5) | 60% (3 of 5) |
| the unit moved after it | - | 33% (1 of 3) | 33% (1 of 3) |
| it charged on its next turn | - | 0% (0 of 3) | 0% (0 of 3) |
| the enemy charged it first | - | 0% (0 of 3) | 0% (0 of 3) |
| it fought by the end of its next turn | - | 0% (0 of 3) | 0% (0 of 3) |
| it moved out of a charge the enemy had planned (not charged first) | - | 33% (1 of 3) | 33% (1 of 3) |
| none of these (no charge, no fight, no charge escaped) | - | 67% (2 of 3) | 67% (2 of 3) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 73% (72 of 99) | 74% (23 of 31) | 73% (95 of 130) |
|   cavalry | 100% (13 of 13) | 86% (12 of 14) | 93% (25 of 27) |
|   character | 0% (0 of 16) | 43% (3 of 7) | 13% (3 of 23) |
|   chariot | 90% (9 of 10) | - | 90% (9 of 10) |
|   infantry | 83% (50 of 60) | 80% (8 of 10) | 83% (58 of 70) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 0.0 (0%) | 1.3 (50%) | 1.3 (11%) |
| CHARGED: it charged | 3.3 (37%) | 0.7 (25%) | 4.0 (34%) |
| IN COMBAT: it fought this turn or the last | 0.7 (7%) | 0.0 (0%) | 0.7 (6%) |
| NO TARGET IN RANGE | 4.0 (44%) | 0.3 (12%) | 4.3 (37%) |
| ONLY IN COMBAT: the only targets were in combat | 1.0 (11%) | 0.0 (0%) | 1.0 (9%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.0 (0%) | 0.3 (12%) | 0.3 (3%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 13.3 | 0.7 | 95% | 1.6 pts | 22 pts |
| character | 1.0 | 0.0 | 100% | 0.0 pts | 0 pts |
| chariot | 3.0 | 0.7 | 78% | 3.5 pts | 10 pts |
| infantry | 22.3 | 7.3 | 76% | 8.1 pts | 181 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 5.0 | 3.3 | 4.2 |
| Charges that made contact a game | 2.3 | 3.0 | 2.7 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.00 declared, 0.00 contact (1 units) | 0.00 declared, 0.00 contact (2 units) | 0.00 declared, 0.00 contact (3 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 1.50 declared, 1.00 contact (2 units) | 1.50 declared, 1.00 contact (2 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.47 declared, 0.22 contact (32 units) | 0.32 declared, 0.32 contact (22 units) | 0.41 declared, 0.26 contact (54 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 57% (4 of 7) | 0% (0 of 1) | 0% (0 of 1) | 44% (4 of 9) |
| Character in a unit | 71% (5 of 7) | 100% (1 of 1) | 0% (0 of 1) | 67% (6 of 9) |
| Character on its own | 100% (1 of 1) | - | 14% (1 of 7) | 25% (2 of 8) |
| Chariot | 50% (1 of 2) | - | - | 50% (1 of 2) |
| Infantry | 73% (8 of 11) | 100% (1 of 1) | - | 75% (9 of 12) |
| Monster | 50% (3 of 6) | 100% (1 of 1) | - | 57% (4 of 7) |
| Monstrous | 50% (1 of 2) | - | - | 50% (1 of 2) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Skaven | 1 | - | 0% (0 of 6) | 60% | 78% (7 of 9) | 100% (1 of 1); 1.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Tomb Kings of Khemri | 2 | 100% (2 of 2); on the table 100% | - | 34% | 40% (4 of 10) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 1 | 0% (0 of 1); on the table 0% | 0% (0 of 6) | 65% | 50% (3 of 6) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 1 | - | 17% (1 of 6) | 20% | 50% (6 of 12) | 100% (1 of 1); 3.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 1 | 100% (1 of 1); on the table 100% | 67% (4 of 6) | 47% | 58% (7 of 12) | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (cora-bb45c30-p11, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 67% (4) | 67% (2) | 67% (6) |
| ...free all their last turn and able to turn (per game) | 0.67 | 0.33 | 1.00 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.33 | 0.00 | 0.33 |
| ...with the charger already in that arc before they moved (per game) | 0.33 | 0.33 | 0.67 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.33 | 0.33 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: cora-bb45c30-p11

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.0 | 4.0 |
| Strategy | Charge objectives carried out (made contact) | 50% (5 of 10) | 30% (3 of 10) |
| Strategy | Shoot objectives carried out (shot that target) | 55% (11 of 20) | 38% (3 of 8) |
| Strategy | Support requests answered (helper made contact too) | - | 100% (1 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | - | 80% (4 of 5) |
| Strategy | Joined characters whose unit fought | 0% (0 of 5) | 50% (4 of 8) |
| Strategy | Lone characters that fought | 100% (5 of 5) | 40% (2 of 5) |
| Movement | Charges halted short of contact | 0.7 | 0.0 |
| Movement | Idle units | 1.7 | 2.7 |
| Movement | Points that never moved of their own | 228.3 | 98.7 |
| Movement | Fights charged into per game | 2.3 | 2.7 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 6 | 0 of 7 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 6 | 0 of 7 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 4 of 6, net +91 | 2 of 7, net +36 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 of 6, net +170 | 3 of 7, net +315 |
| Shooting | Shots by shooting units (incl. breath weapons) | 26.7 | 8.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 14% (11 of 80) | 62% (15 of 24) |
| Shooting | Points destroyed by shooting units | 15.0 | 48.3 |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | - | 1.7 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | - | 60% (3 of 5) |
| Magic | Wounds caused by magic missiles | - | 2.7 |
| Magic | Points destroyed by magic (all spells) | 0.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 6.0 / 0.0 / 0.0 / 0.0 | 1.3 / 1.7 / 0.0 / 0.3 |
| Combat | Points destroyed in combat | 246.3 | 559.0 |
| Combat | Points run down | 40.0 | 30.7 |
| Combat | Net points per charged fight, damage counted | +80 | +112 |
| Combat | Net per 100 charger points, damage counted | +20.1 | +34.9 |
| Combat | First round won (charged fights) | 86% | 88% |
| Combat | Net points per charged fight | +63 | +118 |
| Combat | Net points per supported fight / lone fight | - / +63 | +540 / +58 |
| Combat | Charged fights on a top-3 enemy unit | 1 of 7 | 4 of 8 |
| Game | Points lost | 609.7 | 348.0 |
| Game | VP from objectives | 910.0 | 656.7 |
| Game | Lone holders (player turns) | 5.0 | 0.0 |

- Mine won / drew / lost: 1 / 1 / 1 of 3 ended games (of 3); mean margin (Mine - Opponent) -48 VP
- The side that went first won 1 of 2 games with a winner
- Points traded per game (both sides' losses): 958
- Games not ended: 0; findings 2, warnings 0

### Opponent rules: cora-bb45c30-p11

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| ARMY TABLE | 33.0 | +750.3 | 0.0 | 361.0 | 23.7 | +192.7 | 0.0 | 205.7 |
| BACKUP TARGETS | 0.3 | +2.5 | 0.0 | 0.0 | 0.3 | +0.3 | 0.0 | 0.0 |
| CAST JOB | - | - | - | - | 2.3 | +5.1 | 54.7 | 0.0 |
| CASTER AWAY FROM SCREEN | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | 1.0 | +26.6 | 0.0 | 0.0 | - | - | - | - |
| CHAFF PASSED | - | - | - | - | 0.3 | -0.6 | 0.0 | 0.0 |
| CHALLENGE BY POINTS | - | - | - | - | 0.7 | +33.6 | 0.0 | 41.7 |
| CHAMPION KNOWS CHALLENGE | 0.3 | -5.6 | 0.0 | 0.0 | - | - | - | - |
| CHARACTER GUNS | 3.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHARGE LOSSES | 17.3 | -607.9 | 0.0 | 560.7 | 21.3 | -868.3 | 0.0 | 216.7 |
| CHARGE NOW FIRST | 2.3 | +0.0 | 178.3 | 65.0 | 1.7 | +0.0 | 248.3 | 34.0 |
| CLOSES ON WHAT IT BEATS | 10.7 | +0.0 | 0.0 | 445.0 | 14.3 | +0.0 | 0.0 | 196.7 |
| COMBAT PIVOT | 0.3 | +0.0 | 0.0 | 70.0 | - | - | - | - |
| CONVEYANCE SEARCH | - | - | - | - | 1.7 | +205.5 | 0.0 | 0.0 |
| COVER ONCE | 9.0 | -429.5 | 0.0 | 265.0 | 9.0 | -377.2 | 0.0 | 160.3 |
| DEFENSIVE FLOOR | 0.3 | -4.3 | 0.0 | 0.0 | - | - | - | - |
| DENIED BY THE FIGHT | 0.7 | -10.4 | 34.0 | 65.0 | - | - | - | - |
| DEPLOY BY FIGURES | 8.0 | +21.9 | 0.0 | 48.3 | 7.7 | +21.5 | 0.0 | 0.0 |
| EVASIVE BY THE ODDS | - | - | - | - | 2.7 | +250.0 | 20.0 | 46.7 |
| EXACT ROUND | 3.7 | +199.1 | 212.3 | 130.0 | 2.7 | +64.7 | 383.7 | 34.0 |
| FACES THE THREAT | - | - | - | - | 0.3 | +38.9 | 0.0 | 0.0 |
| FALL BACK GOOD ORDER | 3.7 | +53.2 | 202.3 | 65.0 | 2.3 | +0.0 | 432.7 | 34.0 |
| FALLS SHORT | 4.0 | +33.9 | 0.0 | 22.0 | 21.3 | +250.8 | 0.0 | 126.7 |
| FEATURE BUFFS | 1.3 | +17.1 | 0.0 | 0.0 | 2.0 | +72.2 | 0.0 | 93.3 |
| FIGHT TO THE END | 0.7 | +7.2 | 0.0 | 0.0 | 0.3 | +0.0 | 48.3 | 0.0 |
| FIRE IN ORDER | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FIVE ACTION | 109.7 | +8621.8 | 708.3 | 1725.7 | 87.0 | +4663.2 | 714.0 | 582.0 |
| FLANK NOT WEIGHED | 7.0 | +0.0 | 0.0 | 251.3 | 7.0 | +0.0 | 0.0 | 41.7 |
| FOLLOW UP WEIGHED | 0.7 | +177.3 | 0.0 | 0.0 | 1.0 | +62.8 | 0.0 | 0.0 |
| FOUR ROUNDS | 5.0 | +432.5 | 259.0 | 130.0 | 3.3 | +167.5 | 594.3 | 34.0 |
| FREED FROM HIS FIGHT | 4.0 | +0.0 | 0.0 | 104.7 | 5.3 | +0.0 | 0.0 | 93.3 |
| GIVES UP | 0.3 | -0.9 | 0.0 | 0.0 | 0.3 | -15.3 | 65.0 | 0.0 |
| GOAL WALK | 15.3 | +1762.0 | 0.0 | 720.0 | 5.3 | +203.2 | 0.0 | 30.0 |
| GUN FIGURES | 2.7 | +1.8 | 0.0 | 43.3 | - | - | - | - |
| HARD STAY DROPPED | 4.0 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 1.3 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 7.7 | +0.0 | 0.0 | 560.7 | 12.7 | +0.0 | 0.0 | 160.0 |
| HIS CHARGE DENIED | 0.7 | +10.9 | 76.0 | 0.0 | 0.3 | +31.3 | 65.0 | 0.0 |
| HIS CHARGE LIST | 7.3 | +0.0 | 0.0 | 21.7 | 3.7 | +0.0 | 0.0 | 93.3 |
| HIS LEGAL MOVES | 5.7 | +0.0 | 0.0 | 375.0 | 6.0 | +0.0 | 0.0 | 84.0 |
| HIS MOVE AND SHOT | 4.0 | -46.1 | 0.0 | 65.0 | 6.7 | -156.2 | 0.0 | 0.0 |
| HIS ONE QUARTER | 11.7 | +0.0 | 0.0 | 274.3 | 8.0 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 7.3 | +0.0 | 0.0 | 375.0 | 8.0 | +0.0 | 0.0 | 152.0 |
| HIS RANDOM MOVE | 22.0 | +0.0 | 0.0 | 259.3 | 6.0 | +0.0 | 0.0 | 15.0 |
| HIS RANDOM MOVER COMES | 8.0 | +0.0 | 0.0 | 129.3 | 2.7 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 40.3 | +594.6 | 0.0 | 415.0 | 54.7 | +1122.7 | 0.0 | 396.0 |
| HIS SHOTS BY HIS RUN | 37.0 | +395.3 | 0.0 | 508.0 | 55.3 | +910.5 | 0.0 | 548.0 |
| HIS TURN DENIED | 0.7 | +11.7 | 0.0 | 65.0 | 0.7 | +6.9 | 96.7 | 0.0 |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HOLD ODDS | 19.3 | +0.0 | 0.0 | 145.3 | 18.0 | +0.0 | 0.0 | 186.7 |
| HOLDER ASSIGNMENT | 13.3 | +1058.4 | 0.0 | 96.7 | 10.3 | +1046.2 | 0.0 | 46.7 |
| HOLDS AMBUSHERS | 1.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 4.3 | -138.5 | 259.0 | 65.0 | 3.0 | -124.3 | 414.3 | 34.0 |
| IDLE COST | 4.0 | -67.4 | 0.0 | 0.0 | 16.3 | -166.4 | 0.0 | 132.7 |
| JOINT CHARGE NOW | - | - | - | - | 0.7 | +128.2 | 360.0 | 0.0 |
| KEPT FROM ITS LAST STOP | 2.0 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 1.3 | +48.6 | 0.0 | 0.0 | 0.7 | +0.4 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 9.7 | +0.0 | 445.7 | 152.7 | 3.3 | +0.0 | 70.0 | 182.0 |
| LONE WIZARD KEPT IN | 1.3 | +77.2 | 0.0 | 0.0 | - | - | - | - |
| LOST AFTER ESCAPE | 1.3 | +4.2 | 0.0 | 65.0 | 1.0 | +2.7 | 79.0 | 0.0 |
| MANOEUVRE | 2.0 | -3.6 | 0.0 | 0.0 | 1.7 | +4.0 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.3 | +9.7 | 0.0 | 0.0 | 0.7 | +1.1 | 0.0 | 0.0 |
| MARCH BY THE SUM | 0.7 | +20.2 | 0.0 | 180.0 | 0.3 | +3.1 | 0.0 | 0.0 |
| MARCH CHECK | - | - | - | - | 0.3 | +22.1 | 0.0 | 0.0 |
| MARCH OF THE TABLE | 0.3 | +49.6 | 0.0 | 180.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| MARCH OVER CASTS | 0.7 | -68.9 | 0.0 | 180.0 | 0.7 | +63.2 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 0.3 | +0.2 | 0.0 | 0.0 | 1.0 | +14.6 | 0.0 | 0.0 |
| MEETS IN TIME | 4.3 | +147.4 | 0.0 | 48.3 | 4.3 | +410.5 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 1.3 | +32.5 | 0.0 | 0.0 | 4.7 | +46.0 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 2.3 | +27.7 | 0.0 | 360.0 | 6.7 | +56.5 | 0.0 | 0.0 |
| MOVE ORDER | 2.7 | +0.0 | 180.0 | 180.0 | 3.7 | +0.0 | 34.0 | 38.0 |
| MOVE TO CHARGE COMPUTED | 8.3 | +1532.2 | 0.0 | 256.3 | 5.7 | +552.2 | 0.0 | 152.0 |
| NEARER NOT NEEDED | 14.0 | +539.0 | 0.0 | 90.0 | 5.7 | +225.3 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 7.0 | +1409.6 | 0.0 | 256.3 | 5.0 | +381.7 | 0.0 | 84.0 |
| NO DOUBLE ROUNDS | 4.7 | -263.9 | 259.0 | 130.0 | 2.7 | -206.6 | 541.7 | 34.0 |
| NO LATE CUT | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 0.3 | -0.2 | 0.0 | 180.0 | - | - | - | - |
| OFF BEST | 5.0 | -147.3 | 34.0 | 22.0 | 6.0 | -105.6 | 0.0 | 0.0 |
| ONE CHECK AFTER THE LAST CHANGE | 0.3 | +0.0 | 0.0 | 30.7 | 0.3 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 2.7 | -52.5 | 0.0 | 65.0 | 7.7 | -110.1 | 0.0 | 80.0 |
| ONE JOINT FIGURE | - | - | - | - | 0.3 | +22.2 | 180.0 | 0.0 |
| ONE OBJECTIVE FORMULA | 7.7 | -72.8 | 0.0 | 96.7 | 5.0 | +65.4 | 0.0 | 46.7 |
| ONE PROMISE A TARGET | 0.3 | -145.3 | 0.0 | 0.0 | 0.7 | -41.2 | 0.0 | 68.0 |
| ONE ROUTE | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| ONE RUN A PLAN | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS UP | 0.7 | +49.9 | 38.0 | 0.0 | 0.3 | +13.5 | 22.0 | 0.0 |
| OVERRUNS AWAY | 1.7 | +11.8 | 121.7 | 65.0 | 0.7 | +9.4 | 113.3 | 0.0 |
| PATHS CROSS | 0.7 | +2.1 | 0.0 | 0.0 | 0.7 | -45.1 | 0.0 | 0.0 |
| PLAN RESULT | 49.7 | +451.1 | 167.0 | 928.7 | 45.3 | +652.7 | 162.3 | 656.0 |
| PROMISE BELOW ZERO | 0.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| PROMISE BY ITS OWN SUM | 9.3 | -219.4 | 0.0 | 0.0 | 6.0 | -161.2 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | 1.7 | -1.3 | 0.0 | 92.0 | 1.7 | -7.0 | 0.0 | 0.0 |
| PROMISE SHOT AWAY | 0.3 | -0.8 | 0.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | 28.7 | +2697.2 | 260.3 | 485.7 | 21.7 | +2443.1 | 191.3 | 0.0 |
| RANDOM MOVE BY FIGURES | 2.0 | +21.5 | 0.0 | 145.0 | 3.7 | +42.5 | 0.0 | 113.3 |
| REAL GROUND | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| REDIRECT BY WHAT IT STOPS | 0.3 | -3.1 | 0.0 | 0.0 | - | - | - | - |
| REDIRECT COUNTER | 3.7 | +166.0 | 0.0 | 110.7 | 0.7 | +13.0 | 0.0 | 0.0 |
| REDIRECT FOR A FRIEND IN REACH | 5.3 | +0.5 | 0.0 | 110.7 | 3.0 | +0.0 | 0.0 | 15.0 |
| REFORMS TO MEET IT | 2.7 | -118.2 | 0.0 | 130.0 | 1.3 | -51.9 | 0.0 | 68.0 |
| RESERVE FALL BACK | 1.7 | +20.4 | 0.0 | 24.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| RISK BY ARC | 3.7 | -34.8 | 202.3 | 65.0 | 2.3 | -74.1 | 515.3 | 34.0 |
| RISK ON THE WAY | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| ROUNDS AFTER TERROR | 2.3 | -31.2 | 126.7 | 130.0 | 0.3 | -8.9 | 30.7 | 0.0 |
| RUN DOWN | 3.3 | -126.2 | 130.3 | 130.0 | 1.3 | -7.4 | 127.3 | 0.0 |
| SCOUT SPOT | 1.3 | +1.1 | 0.0 | 22.0 | - | - | - | - |
| SCOUT WAITS | 1.3 | +0.0 | 0.0 | 22.0 | - | - | - | - |
| SEARCH SPOT | 0.7 | +0.5 | 0.0 | 0.0 | 1.0 | +62.5 | 0.0 | 0.0 |
| SECOND LOOK | 1.3 | +159.3 | 34.0 | 0.0 | - | - | - | - |
| SET CREDITED ONCE | 0.3 | -0.6 | 0.0 | 65.0 | 4.7 | -75.9 | 0.0 | 0.0 |
| SET UP BY THE SET | 1.0 | +3.2 | 0.0 | 65.0 | 6.7 | +68.5 | 0.0 | 0.0 |
| SET-UP MISSED | - | - | - | - | 0.3 | +58.2 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.7 | +3.0 | 0.0 | 0.0 | 0.3 | +0.3 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 6.3 | +0.0 | 0.0 | 24.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 2.7 | +58.1 | 30.0 | 0.0 | - | - | - | - |
| SHOT OR CHARGE | 1.3 | -4.9 | 46.7 | 65.0 | 0.3 | -33.6 | 65.0 | 0.0 |
| SHOT RISK POINTS | 26.3 | -256.2 | 0.0 | 241.0 | 31.0 | -411.4 | 0.0 | 330.0 |
| SHOTS AFTER THE MOVES | 4.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 24.3 | +358.4 | 0.0 | 111.7 | 5.3 | +67.3 | 0.0 | 46.7 |
| SPELL WORTH | 0.3 | +11.9 | 180.0 | 180.0 | 4.0 | +5.8 | 0.0 | 0.0 |
| SPELLS IN THE FIGHT | - | - | - | - | 0.3 | -51.2 | 180.0 | 0.0 |
| SPOT AS THE GAME MOVES | 5.7 | +0.0 | 0.0 | 109.7 | 10.0 | +0.0 | 0.0 | 237.0 |
| STAND AND SHOOT | 1.0 | -7.5 | 46.7 | 0.0 | 0.7 | -1.5 | 70.3 | 0.0 |
| STANDS FOR A REASON | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 46.0 | +0.0 | 449.3 | 257.7 | 29.3 | +0.0 | 119.7 | 0.0 |
| STAY WORTH | 21.3 | +133.2 | 269.3 | 21.7 | 9.3 | +75.3 | 89.0 | 46.7 |
| STRIKE BY THE ODDS | 0.7 | +281.4 | 0.0 | 130.0 | - | - | - | - |
| STUCK PIVOT | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| STUPIDITY NEXT TURN | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 9.3 | +170.3 | 0.0 | 65.0 | 4.3 | +120.8 | 0.0 | 15.0 |
| SUPPORT NARROWED | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 20.0 | 34.0 |
| SUPPORT WORKED OUT | 9.3 | +170.3 | 0.0 | 65.0 | 4.3 | +120.8 | 0.0 | 15.0 |
| THE DEARER SUM KEEPS ITS PLAN | 2.7 | +0.0 | 0.0 | 65.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| THE PROMISE ADDS | - | - | - | - | 0.7 | -66.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 2.3 | +0.0 | 0.0 | 30.7 | 2.7 | +0.0 | 0.0 | 41.7 |
| THE ROW KEEPS ITS WAY | 3.0 | +0.0 | 0.0 | 40.7 | 2.0 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 2.7 | +0.0 | 0.0 | 40.7 | 2.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 50.0 | +0.0 | 0.0 | 725.3 | 44.0 | +0.0 | 0.0 | 217.3 |
| TIED UP BY THE SUM | 2.7 | +335.6 | 259.0 | 0.0 | 1.3 | +151.1 | 135.3 | 0.0 |
| TIME ON OUR SIDE | 45.3 | +364.5 | 0.0 | 589.0 | 6.7 | +41.7 | 0.0 | 0.0 |
| WAITS AGAIN | 1.0 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| WALKS ON ITS ROUTE | 0.3 | -11.4 | 0.0 | 0.0 | - | - | - | - |
| WHO FIGHTS | 0.7 | +78.4 | 0.0 | 65.0 | 0.7 | +11.5 | 68.3 | 34.0 |
| WHOLE FIGHT DANGER | 6.0 | -349.5 | 0.0 | 430.7 | 1.3 | -407.5 | 0.0 | 0.0 |
| WOUNDS ON THE RANKS | - | - | - | - | 5.0 | +153.0 | 0.0 | 0.0 |

### Rule changes: cora-bb45c30-p11

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 170 | 170 | 123 | 41.00 | +2154 | +17.5 |
| HOLDER ASSIGNMENT | 71 | 71 | 65 | 21.67 | +4577 | +70.4 |
| HIS SHOT LIST | 285 | 271 | 49 | 16.33 | +454 | +9.3 |
| HIS SHOTS BY HIS RUN | 277 | 270 | 48 | 16.00 | +593 | +12.4 |
| LEGAL CHARGES ONLY | 39 | 39 | 39 | 13.00 | +0 | +0.0 |
| OFF BEST | 33 | 33 | 33 | 11.00 | -759 | -23.0 |
| DEPLOY BY FIGURES | 47 | 47 | 26 | 8.67 | +299 | +11.5 |
| THE TABLE AGAIN | 36 | 36 | 26 | 8.67 | +0 | +0.0 |
| REDIRECT FOR A FRIEND IN REACH | 25 | 25 | 25 | 8.33 | +0 | +0.0 |
| FIVE ACTION | 590 | 571 | 22 | 7.33 | +1906 | +86.6 |
| MOVE TO CHARGE COMPUTED | 42 | 38 | 22 | 7.33 | +1975 | +89.8 |
| GOAL WALK | 62 | 62 | 21 | 7.00 | +1547 | +73.6 |
| NEXT CHARGE BY LIST | 36 | 36 | 20 | 6.67 | +1947 | +97.3 |
| MOVE ORDER | 19 | 19 | 19 | 6.33 | +0 | +0.0 |
| HARD STAY DROPPED | 18 | 18 | 18 | 6.00 | +0 | +0.0 |
| TIME ON OUR SIDE | 156 | 132 | 17 | 5.67 | +48 | +2.8 |
| QUARTER ODDS | 151 | 149 | 15 | 5.00 | +1499 | +99.9 |
| SHOT RISK POINTS | 172 | 167 | 15 | 5.00 | +134 | +8.9 |
| MEETS IN TIME | 26 | 26 | 13 | 4.33 | +1082 | +83.3 |
| FOUR ROUNDS | 25 | 21 | 12 | 4.00 | +766 | +63.9 |
| CHARGE LOSSES | 116 | 112 | 11 | 3.67 | +862 | +78.4 |
| PROMISE BY ITS OWN SUM | 46 | 46 | 11 | 3.67 | -1142 | -103.8 |
| SUPPORT ADDS | 41 | 39 | 11 | 3.67 | +166 | +15.1 |
| SUPPORT WORKED OUT | 41 | 39 | 11 | 3.67 | +166 | +15.1 |
| ADVANCE LANE KEPT | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| HOLDS AMBUSHERS | 8 | 8 | 8 | 2.67 | +0 | +0.0 |
| IDLE COST | 61 | 37 | 8 | 2.67 | +23 | +2.9 |
| RANDOM MOVE BY FIGURES | 17 | 17 | 8 | 2.67 | +192 | +24.0 |
| SHOOTS FROM THE BEST SPOT | 8 | 8 | 8 | 2.67 | +56 | +7.0 |
| TIED UP BY THE SUM | 12 | 10 | 8 | 2.67 | +486 | +60.8 |
| STAY WORTH | 92 | 84 | 7 | 2.33 | +20 | +2.8 |
| LANE BY FIGURES | 6 | 6 | 6 | 2.00 | +147 | +24.5 |
| RESERVE FALL BACK | 6 | 6 | 6 | 2.00 | +61 | +10.2 |
| FOLLOW UP WEIGHED | 5 | 5 | 5 | 1.67 | +720 | +144.1 |
| SEARCH SPOT | 5 | 5 | 5 | 1.67 | +189 | +37.8 |
| COVER ONCE | 54 | 37 | 4 | 1.33 | +88 | +22.1 |
| LONE WIZARD KEPT IN | 4 | 4 | 4 | 1.33 | +232 | +57.9 |
| PATHS CROSS | 4 | 4 | 4 | 1.33 | -129 | -32.2 |
| PROMISE KNOWS THE FIGHT | 10 | 10 | 4 | 1.33 | -25 | -6.2 |
| SCOUT WAITS | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| SECOND LOOK | 4 | 4 | 4 | 1.33 | +478 | +119.4 |
| SET UP BY THE SET | 23 | 23 | 4 | 1.33 | +235 | +58.7 |
| SHOTS IN THE MOVE | 89 | 67 | 4 | 1.33 | +20 | +5.1 |
| WHOLE FIGHT DANGER | 22 | 22 | 4 | 1.33 | +114 | +28.5 |
| EVASIVE BY THE ODDS | 8 | 8 | 3 | 1.00 | +706 | +235.3 |
| MARCH BY THE SUM | 3 | 3 | 3 | 1.00 | +70 | +23.4 |
| ONE PROMISE A TARGET | 3 | 3 | 3 | 1.00 | -559 | -186.5 |
| SHOOTERS IN TWO RANKS | 3 | 3 | 3 | 1.00 | +10 | +3.3 |
| CASTS FROM BEHIND | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| CHALLENGE BY POINTS | 2 | 2 | 2 | 0.67 | +101 | +50.4 |
| CHARGE NOW FIRST | 12 | 12 | 2 | 0.67 | -27 | -13.5 |
| EXACT ROUND | 19 | 15 | 2 | 0.67 | +352 | +176.1 |
| FIRE IN ORDER | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| HIS TURN DENIED | 4 | 4 | 2 | 0.67 | +6 | +3.2 |
| JOINT CHARGE NOW | 2 | 2 | 2 | 0.67 | +384 | +192.2 |
| MANOEUVRE | 11 | 11 | 2 | 0.67 | +16 | +8.1 |
| MARCH OF THE TABLE | 2 | 2 | 2 | 0.67 | -149 | -74.3 |
| MAX FOR POSITIONING | 4 | 4 | 2 | 0.67 | +6 | +3.2 |
| NO DOUBLE ROUNDS | 22 | 18 | 2 | 0.67 | +35 | +17.4 |
| ONE OBJECTIVE FORMULA | 38 | 27 | 2 | 0.67 | +74 | +36.9 |
| SHOTS AFTER THE MOVES | 15 | 15 | 2 | 0.67 | +0 | +0.0 |
| STRIKE BY THE ODDS | 2 | 2 | 2 | 0.67 | +514 | +256.9 |
| STUCK PIVOT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| WOUNDS ON THE RANKS | 15 | 15 | 2 | 0.67 | +58 | +29.2 |
| CASTER AWAY FROM SCREEN | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CHAFF IN THE MOVE | 3 | 3 | 1 | 0.33 | +0 | +0.4 |
| CHAFF PASSED | 1 | 1 | 1 | 0.33 | -2 | -1.7 |
| COMBAT PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FACES THE THREAT | 1 | 1 | 1 | 0.33 | +117 | +116.7 |
| FALL BACK GOOD ORDER | 18 | 15 | 1 | 0.33 | +47 | +47.3 |
| FALLS SHORT | 76 | 61 | 1 | 0.33 | +22 | +22.2 |
| FIGHT TO THE END | 3 | 2 | 1 | 0.33 | +18 | +18.4 |
| HIS CHARGE DENIED | 3 | 2 | 1 | 0.33 | +51 | +51.0 |
| NEARER NOT NEEDED | 59 | 57 | 1 | 0.33 | +30 | +29.9 |
| ONE FIGHT FORMULA | 31 | 16 | 1 | 0.33 | +0 | +0.3 |
| OPENS UP | 3 | 2 | 1 | 0.33 | +18 | +17.8 |
| OVERRUNS AWAY | 7 | 7 | 1 | 0.33 | +1 | +0.7 |
| PROMISE SHOT AWAY | 1 | 1 | 1 | 0.33 | -2 | -2.4 |
| RISK BY ARC | 18 | 15 | 1 | 0.33 | +18 | +18.4 |
| WALKS ON ITS ROUTE | 1 | 1 | 1 | 0.33 | -34 | -34.3 |
| BACKUP TARGETS | 2 | 2 | 0 | 0.00 | - | - |
| CAST JOB | 7 | 7 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 3 | trace | - | - | - | - |
| CHAMPION KNOWS CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| CHARACTER GUNS | 11 | 11 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 75 | 75 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 5 | not checked | - | - | - | - |
| DEFENSIVE FLOOR | 1 | 1 | 0 | 0.00 | - | - |
| DENIED BY THE FIGHT | 2 | 1 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 10 | 10 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 42 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 28 | 28 | 0 | 0.00 | - | - |
| GIVES UP | 2 | 1 | 0 | 0.00 | - | - |
| GUN FIGURES | 8 | not checked | - | - | - | - |
| HE REFORMS ONCE FREED | 10 | 10 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 61 | 59 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 33 | 33 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 35 | 32 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 32 | 31 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 59 | 59 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 46 | 42 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 84 | 80 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 32 | 31 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN RUN | 18 | 18 | 0 | 0.00 | - | - |
| HOLD ODDS | 112 | 110 | 0 | 0.00 | - | - |
| HONEST WORTH | 22 | 19 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 11 | 9 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 7 | 7 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 3 | trace | - | - | - | - |
| MARCH CHECK | 1 | 1 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 4 | 4 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 1 | 1 | 0 | 0.00 | - | - |
| MISSILES IN THE MOVE | 18 | 10 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 27 | 14 | 0 | 0.00 | - | - |
| NO LATE CUT | 4 | 2 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 1 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 2 | not checked | - | - | - | - |
| ONE JOINT FIGURE | 1 | 1 | 0 | 0.00 | - | - |
| ONE ROUTE | 1 | 1 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 18 | 18 | 0 | 0.00 | - | - |
| PLAN RESULT | 285 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 6 | 6 | 0 | 0.00 | - | - |
| REAL GROUND | 1 | 1 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 1 | 1 | 0 | 0.00 | - | - |
| REDIRECT COUNTER | 13 | 10 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 12 | 12 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 1 | 1 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 8 | 8 | 0 | 0.00 | - | - |
| RUN DOWN | 14 | 12 | 0 | 0.00 | - | - |
| SCOUT SPOT | 4 | 4 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 15 | 15 | 0 | 0.00 | - | - |
| SET-UP MISSED | 1 | trace | - | - | - | - |
| SHOOTERS ON THE TABLE | 29 | not checked | - | - | - | - |
| SHOT OR CHARGE | 5 | 4 | 0 | 0.00 | - | - |
| SPELL WORTH | 13 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 47 | 40 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 5 | 4 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 4 | 4 | 0 | 0.00 | - | - |
| STANDS STILL | 226 | 222 | 0 | 0.00 | - | - |
| STUPIDITY NEXT TURN | 2 | 2 | 0 | 0.00 | - | - |
| SUPPORT NARROWED | 2 | 2 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 11 | not checked | - | - | - | - |
| THE PROMISE ADDS | 2 | 2 | 0 | 0.00 | - | - |
| THE ROW IN ITS ORDER | 15 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 15 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 14 | not checked | - | - | - | - |
| THE TABLE BINDS | 282 | not checked | - | - | - | - |
| WAITS AGAIN | 10 | 9 | 0 | 0.00 | - | - |
| WHO FIGHTS | 4 | 4 | 0 | 0.00 | - | - |

### Off best figure: cora-bb45c30-p11

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 3.00 | 5.00 | 23.5 |
| ARMY TABLE | rule | 3.00 | 4.00 | 44.1 |
| PROMISE BY ITS OWN SUM | rule | 2.33 | 1.33 | 103.8 |
| HOLDER ASSIGNMENT | rule | 1.33 | 1.00 | 13.0 |
| RULE SWITCHED OFF | gate | 2.00 | - | 23.6 |
| PROMISE KNOWS THE FIGHT | rule | 0.33 | 1.00 | 6.2 |
| ONE PROMISE A TARGET | rule | 0.33 | 0.67 | 186.5 |
| CHARGE NOW FIRST | rule | 0.67 | - | 13.5 |
| NO REASON | gate | - | 0.67 | 25.7 |
| AFTERMATH BAND | gate | - | 0.33 | 2.4 |
| CHAFF PASSED | rule | - | 0.33 | 1.7 |
| MARCH OF THE TABLE | rule | 0.33 | - | 148.7 |
| PATHS CROSS | rule | - | 0.33 | 145.0 |
| PROMISE SHOT AWAY | rule | 0.33 | - | 2.4 |
| SET UP BY THE SET | rule | - | 0.33 | 10.1 |
| WALKS ON ITS ROUTE | rule | 0.33 | - | 34.3 |

### Plans: cora-bb45c30-p11

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 4.3 | 46% | 805 | 259 | 32% |
| Mine | move | 40.0 | 96% | 2446 | 0 | 0% |
| Mine | shoot | 5.3 | 56% | 382 | 192 | 50% |
| Opponent | charge | 2.7 | 88% | 351 | 544 | 155% |
| Opponent | join | 5.3 | 100% | 304 | 0 | 0% |
| Opponent | move | 34.7 | 93% | 1301 | 0 | 0% |
| Opponent | shoot | 2.7 | 38% | 141 | 108 | 77% |

### Battle groups: cora-bb45c30-p11

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 3.7 | 9% | 0% | 0% | - | 0% | 0% | 0% | 100% | 0% |
| Opponent | REDIRECT COUNTER | 0.7 | 0% | - | - | - | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: cora-bb45c30-p11

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | - | - | - | - |
| Mine | Chaff | 6 | 67 (6) | 0 | 67 | 82 | 17% | 1.0 | - | 78 (5) | 0 (1) | 78 (5) | 0 (1) |
| Mine | Character | 7 | 32 (7) | 32 | 0 | 22 | 29% | 2.6 | 34 (2) | 0 (1) | 54 (2) | 44 (4) | 0 (1) |
| Mine | Clean-up | 1 | 366 (1) | 0 | 366 | 0 | 100% | - | - | 366 (1) | - | - | 366 (1) |
| Mine | Fast Hammer | 6 | 11 (6) | 11 | 0 | 42 | 50% | 5.0 | 16 (4) | 0 (2) | - | - | 11 (6) |
| Mine | Hammer | 5 | 51 (5) | 31 | 20 | 55 | 20% | 1.8 | 29 (3) | 79 (2) | - | 50 (2) | 52 (3) |
| Mine | Holder | 8 | 67 (8) | 0 | 67 | 15 | 50% | 1.2 | 224 (2) | 31 (4) | - | 224 (2) | 31 (4) |
| Mine | Shooter | 5 | 61 (5) | 11 | 50 | 30 | 0% | 1.4 | 19 (2) | 114 (3) | - | 72 (4) | 0 (1) |
| Mine | Wizard | 3 | 0 (3) | 0 | 0 | 0 | 0% | 1.0 | 0 (2) | 0 (1) | - | 0 (2) | 0 (1) |
| Opponent | Chaff | 4 | 112 (4) | 0 | 112 | 19 | 75% | 2.0 | 150 (3) | - | 0 (1) | 150 (3) | 0 (1) |
| Opponent | Character | 11 | 50 (11) | 50 | 0 | 0 | 36% | 4.0 | 117 (2) | 30 (8) | 0 (1) | 26 (7) | 110 (4) |
| Opponent | Fast Hammer | 6 | 58 (6) | 24 | 34 | 10 | 33% | 2.5 | - | 47 (5) | 133 (1) | 47 (3) | 64 (3) |
| Opponent | Hammer | 8 | 31 (8) | 31 | 0 | 48 | 25% | 4.0 | 0 (3) | 49 (5) | - | 41 (6) | 0 (2) |
| Opponent | Holder | 3 | 0 (3) | 0 | 0 | 29 | 67% | 4.0 | 0 (1) | 0 (2) | - | - | 0 (3) |
| Opponent | Shooter | 3 | 49 (3) | 0 | 49 | 70 | 0% | 1.7 | - | 71 (2) | 0 (1) | 60 (2) | 26 (1) |
| Opponent | Support | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Wizard | 2 | 0 (2) | 0 | 0 | 0 | 0% | 1.0 | 0 (1) | - | 0 (1) | 0 (1) | 0 (1) |

### Charged fights: cora-bb45c30-p11

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Skaven | 1 | 45 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Mine | Tomb Kings of Khemri | 2 | 0 | 318 | 3.5 | 1.0 | 91 | 28 | +63 | 1 of 7 | 6 of 7 | - | +63 |
| **Mine** | all armies | 3 | 15 | 212 | 2.3 | 1.0 | 91 | 28 | +63 | 1 of 7 | 6 of 7 | - | +63 |
| Opponent | Vampire Counts | 1 | 145 | 987 | 4.0 | 1.2 | 247 | 0 | +247 | 2 of 4 | 4 of 4 | +540 | +149 |
| Opponent | Warriors of Chaos | 1 | 0 | 0 | 1.0 | 1.0 | 0 | 120 | -120 | 1 of 1 | 0 of 1 | - | -120 |
| Opponent | Wood Elf Realms | 1 | 0 | 321 | 3.0 | 1.0 | 107 | 81 | +26 | 1 of 3 | 3 of 3 | - | +26 |
| **Opponent** | all armies | 3 | 48 | 436 | 2.7 | 1.1 | 164 | 45 | +118 | 4 of 8 | 7 of 8 | +540 | +58 |

### Effective charges: cora-bb45c30-p11

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Tomb Kings of Khemri | 7 | 0 | 1 (net -195) | 0 | 0 | 4 (net +91) | 1 (net +170) | 1 | 0% (0 of 6) |
| Opponent | Vampire Counts | 4 | 0 | 0 | 0 | 1 (net +92) | 1 (net +145) | 2 (net +375) | 0 | 0% (0 of 4) |
| Opponent | Wood Elf Realms | 3 | 0 | 0 | 0 | 1 (net -42) | 1 (net -74) | 1 (net +195) | 0 | 0% (0 of 3) |

### Charged fights, damage counted: cora-bb45c30-p11

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 50-54% | 1 | 195 | 201 | -195 | 22 | 195 | -173 | -88.5 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 411 | 170 | +170 | 170 | 0 | +170 | +41.4 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 4 | 433 | 120 | +91 | 115 | 0 | +115 | +26.6 |
| Mine | No odds | 1 | 440 | 102 | +102 | 102 | 0 | +102 | +23.2 |
| Mine | All fights | 7 | 397 | 136 | +63 | 108 | 28 | +80 | +20.1 |
| Opponent | 76-89% | 2 | 144 | 102 | +25 | 92 | 56 | +36 | +24.8 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 | 400 | 282 | +315 | 315 | 10 | +305 | +76.2 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 2 | 485 | 106 | +36 | 106 | 70 | +36 | +7.3 |
| Opponent | No odds | 1 | 120 | 431 | -120 | 0 | 159 | -159 | -132.2 |
| Opponent | All fights | 8 | 322 | 212 | +118 | 168 | 55 | +112 | +34.9 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| cora-bb45c30-p11 | move | 20 | 5 (25%) | 3 (15%) | 4 (20%) | 11 (55%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L2127 |
| Invocation of Nehek | Opponent | L2127 |
| Periapt of Soul Exchange | Mine | L2127 |
| Ring of Doom | Opponent | L2231 |
| Storm Daemon (Renegade 2.0) | Mine | L2127 |

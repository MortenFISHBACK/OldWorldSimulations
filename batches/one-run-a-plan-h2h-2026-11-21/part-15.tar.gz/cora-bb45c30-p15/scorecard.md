# Doctrine scorecard: cora-bb45c30-p15

### Scorecard: cora-bb45c30-p15

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0409 | 1 | 1 | Mine | no | 7 | 3 | 1 | 1 | 1 | 0 | 0 | 0 |
| L0409 | 1 | 1 | Opponent | no | 4 | - | 0 | 1 | 0 | 0 | 0 | 456 |
| L0425 | 5 | 1 | Mine | yes | - | 2 | 1 | 4 | 0 | 0 | 0 | 65 |
| L0425 | 5 | 1 | Opponent | no | - | 4 | 4 | 5 | 1 | 0 | 0 | 0 |
| L0512 | 2 | 1 | Mine | - | - | - | 0 | 2 | 0 | 0 | 0 | 380 |
| L0512 | 2 | 1 | Opponent | - | - | 4 | 2 | 1 | 0 | 0 | 0 | 330 |
| **Average** | | | Mine | 50% | 7.0 | 2.5 | 0.7 | 2.3 | 0.3 | 0.0 | 0.0 | 148.3 |
| **Average** | | | Opponent | 0% | 4.0 | 4.0 | 2.0 | 2.3 | 0.3 | 0.0 | 0.0 | 262.0 |

### KPIs: cora-bb45c30-p15

Rules off - Mine only: ONE RUN A PLAN.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 31% (4 of 13) | 0% (0 of 13) | 15% (4 of 26) |
| Winner chose to follow up after the loser gave ground |  | 100% (7 of 7); on the table 100% | - | 100% (7 of 7); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | - | 100% (1 of 1); on the table 100% | 100% (1 of 1); on the table 100% |
| Winner chose to pursue after the loser fled |  | - | 0% (0 of 1); on the table 100% | 0% (0 of 1); on the table 100% |
| Winner chose to follow up or pursue (all three) |  | 100% (7 of 7); on the table 100% | 50% (1 of 2); on the table 100% | 89% (8 of 9); on the table 100% |
| Magic missiles tried each own turn | 50%+ | 75% (9 of 12) | 42% (15 of 36) | 50% (24 of 48) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 82% (9 of 11) | 45% (15 of 33) | 55% (24 of 44) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | - | - |
| Points that never fought | lower | 66% (3980 of 5998) | 54% (3236 of 5998) | 60% (7216 of 11996) |
|   infantry points that never fought | lower | 75% (1065 of 1424) | 84% (998 of 1187) | 79% (2063 of 2611) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 52% (12 of 23) | 70% (19 of 27) | 62% (31 of 50) |
| Bound items with a magic missile used (at least once a game) |  | 0.0 uses a game | 100% (3 of 3); 2.3 uses a game | 100% (3 of 3); 1.2 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
|   their share of the points of units over 100 pts | lower | 49% (2512 of 5120) | 75% (4100 of 5442) | 63% (6612 of 10562) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 4.0 (57%) | 4.0 (50%) |
| MARCHED: its unit marched | 0.7 (67%) | 1.3 (19%) | 2.0 (25%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.7 (10%) | 0.7 (8%) |
| IN COMBAT: engaged in combat | 0.3 (33%) | 1.0 (14%) | 1.3 (17%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 6.3 | 2.3 | 1.7 | 8.0 | 0.7 | 0.7 |
| not cast | 3.7 | 3.7 | 4.3 | 8.0 | 1.3 | 19.3 |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 3.0 (82%) | 3.7 (85%) | 4.0 (50%) | 0.0 (0%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.0 (25%) | 0.3 (25%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (8%) | 0.3 (25%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.7 (18%) | 0.3 (8%) | 1.3 (17%) | 0.3 (25%) | 0.0 (0%) |
| NO CASTS LEFT: every cast used on other spells | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (25%) | 0.0 (0%) |
| GONE: slain | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (2%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (3%) |
| HELD BACK: the computer weighed it and chose not to cast it | 3.7 (100%) | 0.0 (0%) | 0.3 (8%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 18.3 (95%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.0 a game | 1.7 a game | 0.8 a game |
| stood (cast and not dispelled) | - | 80% (4 of 5) | 80% (4 of 5) |
| the unit moved after it | - | 100% (4 of 4) | 100% (4 of 4) |
| it charged on its next turn | - | 25% (1 of 4) | 25% (1 of 4) |
| the enemy charged it first | - | 0% (0 of 4) | 0% (0 of 4) |
| it fought by the end of its next turn | - | 0% (0 of 4) | 0% (0 of 4) |
| it moved out of a charge the enemy had planned (not charged first) | - | 0% (0 of 4) | 0% (0 of 4) |
| none of these (no charge, no fight, no charge escaped) | - | 75% (3 of 4) | 75% (3 of 4) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 67% (72 of 107) | 62% (40 of 64) | 65% (112 of 171) |
|   cavalry | 50% (6 of 12) | - | 50% (6 of 12) |
|   character | 83% (25 of 30) | 100% (2 of 2) | 84% (27 of 32) |
|   chariot | 25% (6 of 24) | 50% (2 of 4) | 29% (8 of 28) |
|   infantry | 77% (10 of 13) | 48% (13 of 27) | 58% (23 of 40) |
|   monster | - | 83% (5 of 6) | 83% (5 of 6) |
|   war machine | 89% (25 of 28) | 72% (18 of 25) | 81% (43 of 53) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.7 (23%) | 0.7 (8%) | 3.3 (17%) |
| FLEEING: it fled or was fleeing | 0.0 (0%) | 0.3 (4%) | 0.3 (2%) |
| IN COMBAT: it fought this turn or the last | 0.3 (3%) | 0.0 (0%) | 0.3 (2%) |
| MOVED: a war machine that moved | 0.0 (0%) | 0.7 (8%) | 0.7 (3%) |
| NO TARGET IN RANGE | 5.3 (46%) | 2.0 (25%) | 7.3 (37%) |
| ONLY IN COMBAT: the only targets were in combat | 0.0 (0%) | 1.3 (17%) | 1.3 (7%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 2.3 (20%) | 1.7 (21%) | 4.0 (20%) |
| SHELTERED: the target was sheltered | 0.3 (3%) | 0.7 (8%) | 1.0 (5%) |
| OTHER BAR | 0.7 (6%) | 0.7 (8%) | 1.3 (7%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 2.0 | 0.3 | 83% | 10.0 pts | 20 pts |
| character | 9.3 | 2.0 | 79% | 8.2 pts | 77 pts |
| chariot | 2.7 | 5.3 | 25% | 14.9 pts | 40 pts |
| infantry | 11.0 | 2.7 | 76% | 9.3 pts | 103 pts |
| monster | 3.0 | 1.3 | 56% | 30.5 pts | 91 pts |
| war machine | 14.3 | 11.3 | 56% | 25.9 pts | 371 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 1.7 | 3.3 | 2.5 |
| Charges that made contact a game | 1.0 | 1.7 | 1.3 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.50 declared, 0.50 contact (2 units) | 1.00 declared, 0.67 contact (3 units) | 0.80 declared, 0.60 contact (5 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 0.50 declared, 0.50 contact (2 units) | 0.50 declared, 0.50 contact (2 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.17 declared, 0.09 contact (23 units) | 0.33 declared, 0.11 contact (18 units) | 0.24 declared, 0.10 contact (41 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 50% (2 of 4) | 100% (2 of 2) | - | 67% (4 of 6) |
| Character in a unit | 80% (4 of 5) | 0% (0 of 1) | - | 67% (4 of 6) |
| Character on its own | 100% (2 of 2) | 50% (3 of 6) | 75% (3 of 4) | 67% (8 of 12) |
| Chariot | - | 80% (4 of 5) | - | 80% (4 of 5) |
| Infantry | 50% (6 of 12) | 67% (2 of 3) | - | 53% (8 of 15) |
| Monstrous | - | 0% (0 of 1) | - | 0% (0 of 1) |
| War Machines | 60% (3 of 5) | - | - | 60% (3 of 5) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Chaos Dwarfs | 2 | 100% (4 of 4); on the table 100% | 75% (9 of 12) | 68% | 50% (8 of 16) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Dwarfen Mountain Holds | 1 | 100% (3 of 3); on the table 100% | - | 63% | 57% (4 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 1 | 0% (0 of 1); on the table 100% | 33% (4 of 12) | 68% | 58% (7 of 12) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Grand Cathay | 1 | - | 33% (6 of 18) | 43% | 67% (6 of 9) | 100% (3 of 3); 7.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Vampire Counts | 1 | 100% (1 of 1); on the table 100% | 83% (5 of 6) | 50% | 100% (6 of 6) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (cora-bb45c30-p15, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 50% (1) | 50% (1) | 50% (2) |
| ...free all their last turn and able to turn (per game) | 0.00 | 0.33 | 0.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.00 | 0.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: cora-bb45c30-p15

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.7 | 4.0 |
| Strategy | Charge objectives carried out (made contact) | 75% (3 of 4) | 50% (5 of 10) |
| Strategy | Shoot objectives carried out (shot that target) | 27% (12 of 44) | 45% (19 of 42) |
| Strategy | Support requests answered (helper made contact too) | - | 100% (2 of 2) |
| Strategy | Hexes on a unit its side charged or shot that turn | - | 100% (1 of 1) |
| Strategy | Joined characters whose unit fought | 50% (2 of 4) | 50% (3 of 6) |
| Strategy | Lone characters that fought | 43% (3 of 7) | 62% (5 of 8) |
| Movement | Charges halted short of contact | 0.7 | 1.0 |
| Movement | Idle units | 2.3 | 2.3 |
| Movement | Points that never moved of their own | 148.3 | 262.0 |
| Movement | Fights charged into per game | 1.0 | 1.0 |
| Movement | Charges with odds: long shots (under 50%) | 1 of 2, net +0 | 0 of 3 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 2 | 1 of 3, net -580 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 2 | 1 of 3, net -434 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 of 2, net +265 | 0 of 3 |
| Shooting | Shots by shooting units (incl. breath weapons) | 15.7 | 7.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 72% (34 of 47) | 64% (14 of 22) |
| Shooting | Points destroyed by shooting units | 15.0 | 193.3 |
| Shooting | War machine shots | 8.3 | 6.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 68% (17 of 25) | 44% (8 of 18) |
| Shooting | Points destroyed by war machines | 55.0 | 159.3 |
| Magic | Magic missiles cast | 2.7 | 2.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 50% (4 of 8) | 57% (4 of 7) |
| Magic | Wounds caused by magic missiles | 5.0 | 3.3 |
| Magic | Points destroyed by magic (all spells) | 84.7 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.7 / 0.0 / 0.0 / 0.0 | 1.0 / 0.3 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 426.3 | 31.7 |
| Combat | Points run down | 0.0 | 0.0 |
| Combat | Net points per charged fight, damage counted | -15 | -217 |
| Combat | Net per 100 charger points, damage counted | -4.7 | -40.3 |
| Combat | First round won (charged fights) | 33% | 33% |
| Combat | Net points per charged fight | +88 | -306 |
| Combat | Net points per supported fight / lone fight | - / +88 | -434 / -242 |
| Combat | Charged fights on a top-3 enemy unit | 2 of 3 | 2 of 3 |
| Game | Points lost | 367.7 | 605.0 |
| Game | VP from objectives | 616.7 | 716.7 |
| Game | Lone holders (player turns) | 7.0 | 4.0 |

- Mine won / drew / lost: 1 / 1 / 1 of 3 ended games (of 3); mean margin (Mine - Opponent) +211 VP
- The side that went first won 0 of 2 games with a winner
- Points traded per game (both sides' losses): 973
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: cora-bb45c30-p15

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| ARMY TABLE | 17.3 | -18.7 | 0.0 | 0.0 | 17.7 | -32.2 | 0.0 | 30.0 |
| ARTILLERY RE-ROLL WEIGHED | 0.7 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | 0.3 | +3.7 | 0.0 | 0.0 | - | - | - | - |
| CANNON PLAN MISSED | 0.3 | +0.0 | 56.0 | 0.0 | - | - | - | - |
| CANNON PLANNED TARGET | 7.3 | +10.1 | 256.7 | 31.7 | 6.3 | +111.9 | 524.3 | 0.0 |
| CANNON SIGHT KEPT | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CAST JOB | 3.0 | +141.6 | 456.0 | 580.0 | 4.7 | +28.9 | 0.0 | 0.0 |
| CASTER AWAY FROM SCREEN | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | 0.3 | +33.3 | 0.0 | 0.0 | - | - | - | - |
| CHALLENGE BY POINTS | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +1.4 | 0.0 | 0.0 |
| CHARACTER GUNS | 0.7 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| CHARGE LOSSES | 13.7 | -857.6 | 0.0 | 378.7 | 11.3 | -509.5 | 0.0 | 289.3 |
| CHARGE NOW FIRST | 1.3 | +0.0 | 475.0 | 0.0 | 1.7 | +0.0 | 63.3 | 0.0 |
| CLOSES ON WHAT IT BEATS | 8.0 | +0.0 | 0.0 | 0.0 | 7.3 | +0.0 | 0.0 | 0.0 |
| COMBAT PIVOT | - | - | - | - | 0.7 | +0.0 | 0.0 | 281.7 |
| CONVEYANCE SEARCH | - | - | - | - | 0.7 | +50.2 | 0.0 | 0.0 |
| COVER ONCE | 11.3 | -1100.7 | 0.0 | 0.0 | 8.0 | -934.5 | 0.0 | 0.0 |
| DENIED BY THE FIGHT | - | - | - | - | 2.3 | -19.6 | 63.3 | 0.0 |
| DEPLOY BY FIGURES | 8.7 | +61.0 | 0.0 | 0.0 | 6.3 | +5.3 | 0.0 | 55.0 |
| DUEL STOPS AT THE KILL | 0.3 | -1.4 | 0.0 | 0.0 | - | - | - | - |
| EXACT ROUND | 0.7 | +12.8 | 88.3 | 113.0 | 2.7 | +58.3 | 63.3 | 0.0 |
| FALL BACK GOOD ORDER | 1.3 | +0.0 | 88.3 | 113.0 | 3.3 | +0.8 | 63.3 | 144.7 |
| FALLS SHORT | 6.7 | +92.3 | 0.0 | 92.7 | 16.0 | +149.2 | 0.0 | 300.3 |
| FEATURE BUFFS | 0.7 | +0.6 | 0.0 | 0.0 | - | - | - | - |
| FIGHT TO THE END | 0.7 | +33.3 | 88.3 | 0.0 | 1.0 | +3.9 | 0.0 | 0.0 |
| FIRE IN ORDER | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| FIVE ACTION | 107.0 | +5855.4 | 1587.7 | 1135.0 | 89.3 | +4141.0 | 2977.3 | 912.7 |
| FLANK NOT WEIGHED | 5.3 | +0.0 | 0.0 | 0.0 | 4.7 | +0.0 | 0.0 | 144.7 |
| FOLLOW UP WEIGHED | 1.3 | +245.5 | 0.0 | 113.0 | - | - | - | - |
| FOUR ROUNDS | 1.7 | +160.2 | 88.3 | 113.0 | 3.3 | +131.4 | 63.3 | 144.7 |
| FREED FROM HIS FIGHT | 2.0 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 0.7 | -34.9 | 0.0 | 0.0 | 2.7 | -3.3 | 0.0 | 144.7 |
| GIVES UP | - | - | - | - | 0.3 | -1.0 | 0.0 | 0.0 |
| GOAL WALK | 11.7 | +891.5 | 0.0 | 0.0 | 4.7 | +247.1 | 0.0 | 169.3 |
| GUN FIGURES | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +20.0 | 0.0 | 0.0 |
| GUN MASK | 1.7 | +43.4 | 0.0 | 0.0 | 0.3 | -6.7 | 0.0 | 0.0 |
| HARD STAY DROPPED | 4.7 | +0.0 | 0.0 | 193.3 | 1.0 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 2.0 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 4.0 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 289.3 |
| HIS CHARGE DENIED | - | - | - | - | 0.3 | +48.4 | 0.0 | 0.0 |
| HIS CHARGE LIST | 7.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 3.7 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 144.7 |
| HIS MOVE AND SHOT | 4.3 | -16.2 | 0.0 | 0.0 | 2.7 | -40.7 | 0.0 | 30.0 |
| HIS ONE QUARTER | 4.0 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 4.3 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 144.7 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 47.7 | +4020.6 | 0.0 | 378.7 | 43.0 | +2553.4 | 0.0 | 738.0 |
| HIS SHOTS BY HIS RUN | 32.0 | +637.1 | 0.0 | 378.7 | 28.3 | +527.7 | 0.0 | 319.3 |
| HIS TURN DENIED | 0.3 | +25.8 | 88.3 | 0.0 | 2.3 | +78.6 | 63.3 | 0.0 |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HOLD ODDS | 13.3 | +0.0 | 0.0 | 0.0 | 9.3 | +0.0 | 0.0 | 0.0 |
| HOLDER ASSIGNMENT | 8.3 | +895.9 | 0.0 | 0.0 | 8.7 | +923.2 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 1.3 | -67.6 | 88.3 | 113.0 | 3.0 | -105.7 | 63.3 | 144.7 |
| HUNT IN PAIRS | 0.3 | +37.8 | 0.0 | 0.0 | 2.0 | +461.9 | 0.0 | 144.7 |
| IDLE COST | 5.7 | -103.1 | 0.0 | 92.7 | 11.3 | -170.5 | 0.0 | 169.3 |
| JOINT CHARGE NOW | - | - | - | - | 1.0 | +193.4 | 0.0 | 144.7 |
| KEPT FROM ITS LAST STOP | 3.3 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 1.3 | +64.9 | 0.0 | 0.0 | - | - | - | - |
| LEGAL CHARGES ONLY | 4.0 | +0.0 | 233.0 | 339.0 | 1.3 | +0.0 | 113.0 | 563.3 |
| LONE WIZARD KEPT IN | - | - | - | - | 0.7 | +30.1 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | 0.3 | -8.0 | 0.0 | 0.0 | 3.0 | -42.2 | 63.3 | 144.7 |
| MAKE SURE TOGETHER | - | - | - | - | 0.7 | +97.4 | 0.0 | 0.0 |
| MANOEUVRE | 2.7 | -36.2 | 0.0 | 0.0 | 2.3 | -4.8 | 0.0 | 56.0 |
| MARCH BY THE SUM | 0.3 | +14.7 | 0.0 | 0.0 | 0.7 | +16.0 | 0.0 | 0.0 |
| MARCH CHECK | 0.3 | +23.1 | 0.0 | 0.0 | 3.3 | +368.7 | 0.0 | 0.0 |
| MARCH OF THE TABLE | 0.3 | +7.4 | 0.0 | 0.0 | 1.0 | +16.9 | 0.0 | 0.0 |
| MARCH OVER CASTS | 0.3 | +1.9 | 0.0 | 0.0 | 0.7 | +34.4 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 1.7 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 3.7 | +181.3 | 0.0 | 193.3 | 3.0 | +80.4 | 0.0 | 159.7 |
| MEETS IN TIME | 5.3 | +153.6 | 0.0 | 0.0 | 2.3 | +33.0 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 3.0 | +162.8 | 0.0 | 386.7 | 8.7 | +141.5 | 0.0 | 200.7 |
| MISSILES NEXT TURN | 3.0 | +83.4 | 0.0 | 193.3 | 11.0 | +139.3 | 0.0 | 200.7 |
| MOVE ORDER | 1.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| MOVE SPELL IN RANGE | 3.7 | +123.1 | 0.0 | 386.7 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 2.7 | +216.6 | 0.0 | 0.0 | 1.7 | +87.0 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 9.7 | +421.2 | 0.0 | 0.0 | 9.7 | +411.4 | 0.0 | 56.0 |
| NEXT CHARGE BY LIST | 1.7 | +120.6 | 386.7 | 0.0 | 1.3 | +79.3 | 0.0 | 0.0 |
| NEXT OBJECTIVE NEARER | - | - | - | - | 0.7 | -20.0 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 1.3 | -69.9 | 88.3 | 113.0 | 2.3 | -167.8 | 63.3 | 0.0 |
| NO LATE CUT | 1.3 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OFF BEST | 2.3 | -66.7 | 0.0 | 113.0 | 4.3 | -135.0 | 0.0 | 144.7 |
| OGRE LOADER SECOND SHOT | - | - | - | - | 2.3 | +0.0 | 0.0 | 0.0 |
| ONE CHALLENGE TEST | - | - | - | - | 0.3 | +87.0 | 0.0 | 0.0 |
| ONE CHECK AFTER THE LAST CHANGE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ONE FIGHT FORMULA | 3.7 | -129.2 | 0.0 | 193.3 | 1.7 | -21.7 | 0.0 | 0.0 |
| ONE JOINT FIGURE | - | - | - | - | 1.0 | +172.8 | 0.0 | 144.7 |
| ONE OBJECTIVE FORMULA | 2.3 | +120.0 | 0.0 | 0.0 | 4.0 | +5.2 | 0.0 | 0.0 |
| ONE ROUTE | 1.7 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| ONE RUN A PLAN | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS UP | 0.3 | +16.7 | 0.0 | 0.0 | - | - | - | - |
| OVERRUNS AWAY | 0.3 | +3.0 | 0.0 | 113.0 | 1.0 | +31.2 | 0.0 | 0.0 |
| PATHS CROSS | 0.3 | +9.4 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.3 | -11.1 | 0.0 | 0.0 | - | - | - | - |
| PLAN RESULT | 47.3 | +1123.5 | 670.3 | 655.7 | 42.0 | +1193.3 | 1036.7 | 720.3 |
| PROMISE BY ITS OWN SUM | 5.3 | -199.7 | 0.0 | 0.0 | 3.3 | -18.5 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | 0.3 | -17.4 | 0.0 | 0.0 | 2.7 | -3.3 | 0.0 | 144.7 |
| QUARTER ODDS | 17.3 | +1757.6 | 490.7 | 113.0 | 16.0 | +957.8 | 1677.3 | 0.0 |
| REAL GROUND | 1.7 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | 1.3 | +152.3 | 0.0 | 0.0 | 0.3 | +52.9 | 0.0 | 0.0 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 1.0 | +0.0 | 0.0 | 15.0 |
| REFORMS TO MEET IT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 144.7 |
| RISK BY ARC | 1.7 | -84.2 | 88.3 | 113.0 | 3.3 | -167.2 | 63.3 | 144.7 |
| ROUNDS AFTER TERROR | 0.3 | -1.0 | 0.0 | 113.0 | 0.3 | +0.3 | 0.0 | 0.0 |
| RUN DOWN | - | - | - | - | 1.3 | -10.0 | 0.0 | 0.0 |
| SCOUT SPOT | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| SCOUT WAITS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 1.3 | -39.2 | 0.0 | 30.0 |
| SEARCH SPOT | 1.3 | +67.7 | 0.0 | 0.0 | 0.3 | +4.1 | 0.0 | 0.0 |
| SECOND LOOK | 0.3 | +22.7 | 0.0 | 113.0 | - | - | - | - |
| SET CREDITED ONCE | - | - | - | - | 3.7 | -243.9 | 0.0 | 289.3 |
| SET UP BY THE SET | 0.7 | +0.0 | 0.0 | 0.0 | 3.7 | +335.8 | 0.0 | 289.3 |
| SET UP TOGETHER | - | - | - | - | 0.7 | +97.4 | 0.0 | 0.0 |
| SET-UP ANY TARGET | - | - | - | - | 0.3 | +19.1 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.7 | +1.3 | 0.0 | 0.0 | 0.3 | +0.7 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 16.3 | +0.0 | 0.0 | 418.3 | 15.0 | +0.0 | 0.0 | 15.0 |
| SHOOTS FROM THE BEST SPOT | 5.3 | +235.7 | 314.0 | 0.0 | 3.3 | +208.0 | 386.7 | 0.0 |
| SHOT OR CHARGE | - | - | - | - | 0.3 | -0.9 | 0.0 | 0.0 |
| SHOT RISK POINTS | 27.3 | +944.7 | 0.0 | 378.7 | 19.0 | -119.3 | 0.0 | 488.7 |
| SHOTS AFTER THE MOVES | 3.3 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 18.0 | +499.3 | 0.0 | 31.7 | 17.0 | +919.2 | 0.0 | 55.0 |
| SPELL SETS UP CHARGE | - | - | - | - | 0.3 | +19.1 | 0.0 | 0.0 |
| SPELL WORTH | 0.3 | +1.7 | 0.0 | 0.0 | 2.0 | +52.9 | 289.3 | 289.3 |
| SPELLS IN THE FIGHT | - | - | - | - | 0.7 | +4.8 | 63.3 | 0.0 |
| SPOT AS THE GAME MOVES | 5.3 | +0.0 | 0.0 | 46.3 | 6.7 | +0.0 | 0.0 | 229.3 |
| STAND AND SHOOT | - | - | - | - | 0.3 | -2.9 | 0.0 | 0.0 |
| STANDS FOR A REASON | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 64.0 | +0.0 | 1499.3 | 736.0 | 45.0 | +0.0 | 2914.0 | 110.0 |
| STAY WORTH | 30.3 | +35.8 | 1185.3 | 386.7 | 30.0 | -146.5 | 1528.0 | 55.0 |
| STRIKE BY THE ODDS | 0.3 | +1.3 | 0.0 | 0.0 | - | - | - | - |
| STUBBORN BY POINTS | 0.3 | +52.3 | 0.0 | 0.0 | - | - | - | - |
| SUPPORT ADDS | 5.3 | +421.5 | 0.0 | 0.0 | 5.3 | +118.3 | 0.0 | 30.0 |
| SUPPORT WORKED OUT | 5.3 | +421.5 | 0.0 | 0.0 | 5.3 | +118.3 | 0.0 | 30.0 |
| THE DEARER SUM KEEPS ITS PLAN | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 5.0 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 2.3 | +0.0 | 0.0 | 46.3 | 4.3 | +0.0 | 0.0 | 84.7 |
| THE STEP BACK IS MADE | 1.7 | +0.0 | 0.0 | 46.3 | 3.0 | +0.0 | 0.0 | 56.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 51.3 | +0.0 | 0.0 | 511.0 | 43.3 | +0.0 | 0.0 | 344.0 |
| TIED UP BY THE SUM | 0.7 | +57.6 | 0.0 | 113.0 | 0.3 | +35.4 | 0.0 | 0.0 |
| TIME ON OUR SIDE | 44.0 | +424.8 | 142.0 | 0.0 | 14.7 | +165.9 | 0.0 | 0.0 |
| TWO OR MORE ARRIVE | - | - | - | - | 0.7 | +17.2 | 0.0 | 0.0 |
| WAITS AGAIN | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WAR ENGINE JOBS | 0.3 | +0.0 | 34.7 | 0.0 | - | - | - | - |
| WHO FIGHTS | - | - | - | - | 0.3 | -30.8 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | 1.3 | -439.8 | 0.0 | 0.0 | 2.0 | -156.3 | 0.0 | 0.0 |
| WHOLE FIGHT GAIN | - | - | - | - | 1.0 | +109.2 | 0.0 | 144.7 |
| WOUNDS ON THE RANKS | 3.0 | +69.3 | 0.0 | 0.0 | 2.0 | +26.1 | 0.0 | 0.0 |

### Rule changes: cora-bb45c30-p15

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 105 | 105 | 79 | 26.33 | +209 | +2.6 |
| HIS SHOT LIST | 272 | 262 | 66 | 22.00 | +1382 | +20.9 |
| HOLDER ASSIGNMENT | 51 | 51 | 49 | 16.33 | +3399 | +69.4 |
| HIS SHOTS BY HIS RUN | 181 | 174 | 39 | 13.00 | +337 | +8.6 |
| SHOT RISK POINTS | 139 | 134 | 30 | 10.00 | +718 | +23.9 |
| TIME ON OUR SIDE | 176 | 165 | 29 | 9.67 | +122 | +4.2 |
| DEPLOY BY FIGURES | 45 | 45 | 22 | 7.33 | +460 | +20.9 |
| SHOOTS FROM THE BEST SPOT | 26 | 26 | 21 | 7.00 | +689 | +32.8 |
| OFF BEST | 20 | 20 | 20 | 6.67 | -605 | -30.3 |
| THE TABLE AGAIN | 36 | 36 | 20 | 6.67 | +0 | +0.0 |
| HARD STAY DROPPED | 17 | 17 | 17 | 5.67 | +0 | +0.0 |
| CAST JOB | 23 | 23 | 16 | 5.33 | +180 | +11.2 |
| FIVE ACTION | 589 | 578 | 16 | 5.33 | +641 | +40.1 |
| LEGAL CHARGES ONLY | 16 | 16 | 16 | 5.33 | +0 | +0.0 |
| ARTILLERY RE-ROLL WEIGHED | 12 | 12 | 12 | 4.00 | +0 | +0.0 |
| GOAL WALK | 49 | 49 | 12 | 4.00 | +529 | +44.1 |
| SUPPORT ADDS | 32 | 31 | 12 | 4.00 | +167 | +14.0 |
| SUPPORT WORKED OUT | 32 | 31 | 12 | 4.00 | +167 | +14.0 |
| MEETS IN TIME | 23 | 23 | 10 | 3.33 | +383 | +38.3 |
| PROMISE BY ITS OWN SUM | 26 | 26 | 10 | 3.33 | -654 | -65.4 |
| QUARTER ODDS | 100 | 99 | 10 | 3.33 | +613 | +61.3 |
| SHOTS IN THE MOVE | 105 | 90 | 10 | 3.33 | +428 | +42.8 |
| MOVE ORDER | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| CHARGE LOSSES | 75 | 71 | 8 | 2.67 | +674 | +84.2 |
| MARCH CHECK | 11 | 11 | 8 | 2.67 | +356 | +44.4 |
| COVER ONCE | 58 | 48 | 7 | 2.33 | +148 | +21.2 |
| FOUR ROUNDS | 15 | 14 | 7 | 2.33 | +322 | +46.1 |
| IDLE COST | 51 | 45 | 7 | 2.33 | +46 | +6.6 |
| MOVE TO CHARGE COMPUTED | 13 | 10 | 7 | 2.33 | +227 | +32.4 |
| OGRE LOADER SECOND SHOT | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| ADVANCE LANE KEPT | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| STAY WORTH | 181 | 174 | 5 | 1.67 | +38 | +7.7 |
| CANNON SIGHT KEPT | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 4 | 4 | 4 | 1.33 | +736 | +184.1 |
| LANE BY FIGURES | 4 | 4 | 4 | 1.33 | +195 | +48.6 |
| MARCH OF THE TABLE | 4 | 4 | 4 | 1.33 | -73 | -18.2 |
| NEARER NOT NEEDED | 58 | 57 | 4 | 1.33 | +226 | +56.5 |
| SEARCH SPOT | 5 | 5 | 4 | 1.33 | +216 | +53.9 |
| SET UP BY THE SET | 13 | 12 | 4 | 1.33 | +302 | +75.5 |
| THE ROW IN ITS ORDER | 24 | 4 | 4 | 1.33 | +0 | +0.0 |
| WOUNDS ON THE RANKS | 15 | 15 | 4 | 1.33 | +69 | +17.4 |
| CANNON PLANNED TARGET | 41 | 41 | 3 | 1.00 | +0 | +0.0 |
| CHARGE NOW FIRST | 9 | 9 | 3 | 1.00 | -148 | -49.3 |
| HUNT IN PAIRS | 7 | 7 | 3 | 1.00 | +649 | +216.2 |
| JOINT CHARGE NOW | 3 | 3 | 3 | 1.00 | +580 | +193.4 |
| MARCH BY THE SUM | 3 | 3 | 3 | 1.00 | +92 | +30.6 |
| MAX FOR POSITIONING | 20 | 18 | 3 | 1.00 | +16 | +5.4 |
| MISSILES IN THE MOVE | 35 | 30 | 3 | 1.00 | +179 | +59.7 |
| NEXT CHARGE BY LIST | 9 | 7 | 3 | 1.00 | +152 | +50.6 |
| REDIRECT FOR A FRIEND IN REACH | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| RISK BY ARC | 15 | 14 | 3 | 1.00 | +78 | +26.2 |
| SHOOTERS IN TWO RANKS | 3 | 3 | 3 | 1.00 | +6 | +2.0 |
| CASTS FROM BEHIND | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| CHALLENGE BY POINTS | 2 | 2 | 2 | 0.67 | +4 | +2.0 |
| COMBAT PIVOT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| FALLS SHORT | 68 | 60 | 2 | 0.67 | +3 | +1.6 |
| HIS TURN DENIED | 8 | 8 | 2 | 0.67 | +62 | +30.9 |
| HOLDS AMBUSHERS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| LONE WIZARD KEPT IN | 2 | 2 | 2 | 0.67 | +90 | +45.1 |
| MANOEUVRE | 15 | 15 | 2 | 0.67 | +30 | +14.9 |
| ONE JOINT FIGURE | 3 | 3 | 2 | 0.67 | +311 | +155.6 |
| PATHS CROSS | 2 | 2 | 2 | 0.67 | +28 | +14.1 |
| PROMISE READS THE TABLE | 9 | 9 | 2 | 0.67 | -0 | -0.2 |
| REDIRECT COUNTER | 5 | 5 | 2 | 0.67 | +22 | +11.2 |
| REFUSING RETIRES | 2 | 2 | 2 | 0.67 | -28 | -14.0 |
| SCOUT WAITS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| TIED UP BY THE SUM | 3 | 2 | 2 | 0.67 | +50 | +25.0 |
| WHOLE FIGHT DANGER | 10 | 10 | 2 | 0.67 | +163 | +81.5 |
| CASTER AWAY FROM SCREEN | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| EXACT ROUND | 10 | 9 | 1 | 0.33 | +17 | +16.9 |
| FIRE IN ORDER | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| HIS CHARGE DENIED | 1 | 1 | 1 | 0.33 | +80 | +80.2 |
| LOST AFTER ESCAPE | 10 | 10 | 1 | 0.33 | +13 | +13.0 |
| ONE CHALLENGE TEST | 1 | 1 | 1 | 0.33 | +178 | +177.9 |
| OPENS UP | 1 | 1 | 1 | 0.33 | +33 | +33.2 |
| OVERRUNS AWAY | 4 | 3 | 1 | 0.33 | +17 | +16.9 |
| PIVOT GUARDS FLANK | 1 | 1 | 1 | 0.33 | -33 | -33.3 |
| SECOND LOOK | 1 | 1 | 1 | 0.33 | +68 | +68.0 |
| STRIKE BY THE ODDS | 1 | 1 | 1 | 0.33 | +4 | +3.8 |
| STUBBORN BY POINTS | 1 | 1 | 1 | 0.33 | +157 | +156.7 |
| WHOLE FIGHT GAIN | 3 | 3 | 1 | 0.33 | +146 | +145.5 |
| BACKUP TARGETS | 1 | not checked | - | - | - | - |
| CANNON PLAN MISSED | 1 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 4 | trace | - | - | - | - |
| CHAFF IN THE MOVE | 1 | 1 | 0 | 0.00 | - | - |
| CHARACTER GUNS | 10 | 10 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 46 | 46 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 2 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 7 | 7 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 1 | 1 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 14 | 13 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 2 | 2 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 5 | 5 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 30 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 16 | 16 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 10 | 9 | 0 | 0.00 | - | - |
| GIVES UP | 1 | 1 | 0 | 0.00 | - | - |
| GUN FIGURES | 4 | not checked | - | - | - | - |
| GUN MASK | 6 | 5 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 14 | 14 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 25 | 24 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 39 | 37 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 22 | 21 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 21 | 20 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 24 | 24 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 24 | 23 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN RUN | 18 | 18 | 0 | 0.00 | - | - |
| HOLD ODDS | 68 | 67 | 0 | 0.00 | - | - |
| HONEST WORTH | 13 | 12 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 20 | 19 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 2 | not checked | - | - | - | - |
| MARCH OVER CASTS | 3 | 3 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 12 | 11 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 42 | 36 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 11 | 8 | 0 | 0.00 | - | - |
| NEXT OBJECTIVE NEARER | 2 | 2 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 11 | 10 | 0 | 0.00 | - | - |
| NO LATE CUT | 10 | 10 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 1 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 16 | 12 | 0 | 0.00 | - | - |
| ONE OBJECTIVE FORMULA | 19 | 14 | 0 | 0.00 | - | - |
| ONE ROUTE | 12 | 11 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 18 | 18 | 0 | 0.00 | - | - |
| PLAN RESULT | 268 | trace | - | - | - | - |
| PROMISE KNOWS THE FIGHT | 4 | 3 | 0 | 0.00 | - | - |
| REAL GROUND | 12 | 11 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 1 | 1 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 2 | 1 | 0 | 0.00 | - | - |
| RUN DOWN | 4 | 4 | 0 | 0.00 | - | - |
| SCOUT SPOT | 2 | 2 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 4 | 4 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 11 | 10 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 2 | 1 | 0 | 0.00 | - | - |
| SET-UP ANY TARGET | 1 | not checked | - | - | - | - |
| SHOOTERS ON THE TABLE | 94 | not checked | - | - | - | - |
| SHOT OR CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| SHOTS AFTER THE MOVES | 22 | 22 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 1 | not checked | - | - | - | - |
| SPELL WORTH | 7 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 36 | 34 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 1 | 1 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 2 | 2 | 0 | 0.00 | - | - |
| STANDS STILL | 327 | 323 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 4 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 20 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 14 | not checked | - | - | - | - |
| THE TABLE BINDS | 284 | not checked | - | - | - | - |
| TWO OR MORE ARRIVE | 2 | not checked | - | - | - | - |
| WAITS AGAIN | 2 | 2 | 0 | 0.00 | - | - |
| WAR ENGINE JOBS | 1 | 1 | 0 | 0.00 | - | - |
| WHO FIGHTS | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: cora-bb45c30-p15

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 1.67 | 3.67 | 24.7 |
| ARMY TABLE | rule | 3.00 | 2.00 | 72.0 |
| PROMISE BY ITS OWN SUM | rule | 2.33 | 1.00 | 65.4 |
| MARCH OF THE TABLE | rule | 0.33 | 1.00 | 18.2 |
| CHARGE NOW FIRST | rule | 0.33 | 0.67 | 49.3 |
| HOLDER ASSIGNMENT | rule | 0.67 | 0.33 | 38.7 |
| NO REASON | gate | - | 0.67 | 45.0 |
| REFUSING RETIRES | rule | 0.33 | 0.33 | 14.0 |
| RULE SWITCHED OFF | gate | 0.67 | - | 60.4 |
| PIVOT GUARDS FLANK | rule | 0.33 | - | 33.3 |

### Plans: cora-bb45c30-p15

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.7 | 20% | 192 | 38 | 20% |
| Mine | join | 1.7 | 100% | 57 | 0 | 0% |
| Mine | move | 32.7 | 98% | 1821 | 0 | 0% |
| Mine | shoot | 11.3 | 56% | 756 | 1086 | 144% |
| Opponent | charge | 2.0 | 33% | 136 | 80 | 59% |
| Opponent | join | 2.0 | 100% | 114 | 0 | 0% |
| Opponent | move | 25.0 | 97% | 1002 | 0 | 0% |
| Opponent | shoot | 12.3 | 68% | 747 | 1113 | 149% |
| Opponent | support | 0.7 | 50% | 0 | 0 | - |

### Battle groups: cora-bb45c30-p15

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 1.3 | 0% | - | - | - | - | - | - | - | - |
| Opponent | REDIRECT COUNTER | 0.3 | 100% | 100% | 0% | - | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: cora-bb45c30-p15

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | 0 (1) | - | - | 0 (1) | - |
| Mine | Character | 11 | 54 (11) | 54 | 0 | 36 | 9% | 2.6 | 40 (8) | 103 (3) | - | 73 (8) | 0 (3) |
| Mine | Clean-up | 6 | 65 (6) | 0 | 65 | 0 | 67% | 4.5 | 16 (3) | 111 (2) | 150 (1) | 79 (5) | 0 (1) |
| Mine | Fast Hammer | 1 | 0 (1) | 0 | 0 | 0 | 0% | 1.0 | - | 0 (1) | - | - | 0 (1) |
| Mine | Hammer | 6 | 3 (6) | 3 | 0 | 0 | 33% | 3.8 | 0 (2) | 5 (4) | - | 0 (5) | 15 (1) |
| Mine | Holder | 2 | 11 (2) | 0 | 11 | 50 | 100% | - | 22 (1) | 0 (1) | - | 11 (2) | - |
| Mine | Shooter | 2 | 30 (2) | 30 | 0 | 0 | 0% | 2.0 | 61 (1) | 0 (1) | - | 30 (2) | - |
| Mine | War machine | 5 | 35 (5) | 35 | 0 | 20 | 0% | 1.0 | 87 (2) | 0 (1) | 0 (2) | - | 35 (5) |
| Opponent | Chaff | 4 | 0 (4) | 0 | 0 | 18 | 100% | - | 0 (4) | - | - | 0 (3) | 0 (1) |
| Opponent | Character | 9 | 5 (9) | 5 | 0 | 58 | 33% | 4.0 | 0 (3) | 10 (5) | 0 (1) | 7 (5) | 0 (4) |
| Opponent | Clean-up | 2 | 27 (2) | 0 | 27 | 57 | 50% | 5.0 | 63 (1) | 0 (1) | - | 63 (1) | 0 (1) |
| Opponent | Fast Hammer | 1 | 0 (1) | 0 | 0 | 0 | 0% | 3.0 | 0 (1) | - | - | - | 0 (1) |
| Opponent | Hammer | 3 | 83 (3) | 83 | 0 | 38 | 33% | 1.5 | - | 83 (3) | - | 118 (2) | 0 (1) |
| Opponent | Holder | 3 | 112 (3) | 0 | 112 | 31 | 33% | 2.0 | - | 163 (2) | - | 103 (1) | 231 (1) |
| Opponent | Shooter | 3 | 58 (3) | 0 | 58 | 33 | 0% | 1.0 | - | 173 (1) | 0 (2) | 87 (2) | 0 (1) |
| Opponent | Support | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | War machine | 5 | 68 (5) | 68 | 0 | 23 | 20% | 1.0 | - | - | 68 (5) | - | 68 (5) |
| Opponent | Wizard | 5 | 0 (5) | 0 | 0 | 0 | 20% | 2.2 | 0 (3) | 0 (2) | - | 0 (2) | 0 (3) |

### Charged fights: cora-bb45c30-p15

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaos Dwarfs | 2 | 150 | 132 | 1.5 | 1.0 | 88 | 0 | +88 | 2 of 3 | 1 of 3 | - | +88 |
| Mine | Dwarfen Mountain Holds | 1 | 165 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| **Mine** | all armies | 3 | 155 | 88 | 1.0 | 1.0 | 88 | 0 | +88 | 2 of 3 | 1 of 3 | - | +88 |
| Opponent | Empire of Man | 1 | 1058 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Grand Cathay | 1 | 0 | 95 | 2.0 | 2.0 | 48 | 217 | -170 | 1 of 2 | 1 of 2 | -434 | +95 |
| Opponent | Vampire Counts | 1 | 0 | 0 | 1.0 | 1.0 | 0 | 580 | -580 | 1 of 1 | 0 of 1 | - | -580 |
| **Opponent** | all armies | 3 | 353 | 32 | 1.0 | 1.7 | 32 | 338 | -306 | 2 of 3 | 1 of 3 | -434 | -242 |

### Effective charges: cora-bb45c30-p15

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaos Dwarfs | 3 | 1 (net +0) | 0 | 0 | 0 | 0 | 1 (net +265) | 1 | 0% (0 of 2) |
| Opponent | Grand Cathay | 2 | 0 | 0 | 0 | 1 (net +95) | 1 (net -434) | 0 | 0 | 0% (0 of 2) |
| Opponent | Vampire Counts | 1 | 0 | 0 | 1 (net -580) | 0 | 0 | 0 | 0 | 100% (1 of 1) |

### Charged fights, damage counted: cora-bb45c30-p15

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 1 | 120 | 189 | +0 | 0 | 60 | -60 | -50.0 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 339 | 265 | +265 | 307 | 291 | +16 | +4.7 |
| Mine | No odds | 1 | 480 | 348 | +0 | 0 | 0 | +0 | +0.0 |
| Mine | All fights | 3 | 313 | 267 | +88 | 102 | 117 | -15 | -4.7 |
| Opponent | Effective (55-75%) | 1 | 480 | 339 | -580 | 214 | 580 | -366 | -76.3 |
| Opponent | 76-89% | 1 | 205 | 95 | +95 | 95 | 0 | +95 | +46.3 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 930 | 239 | -434 | 293 | 672 | -379 | -40.8 |
| Opponent | All fights | 3 | 538 | 224 | -306 | 201 | 417 | -217 | -40.3 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| cora-bb45c30-p15 | move | 9 | 3 (33%) | 1 (11%) | 0 (0%) | 6 (67%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L0425 |
| Clockwork Compass | Opponent | L0512 |
| Invocation of Nehek | Opponent | L0425 |
| Ring of Doom | Opponent | L0512 |
| Ring of Jet | Opponent | L0512 |

# Doctrine scorecard: cora-bb45c30-p9

### Scorecard: cora-bb45c30-p9

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L1527 | 3 | 1 | Mine | no | 6 | 4 | 3 | 1 | 1 | 0 | 0 | 0 |
| L1527 | 3 | 1 | Opponent | no | 3 | 2 | 4 | 2 | 0 | 0 | 0 | 0 |
| L1625 | 5 | 1 | Mine | yes | - | 4 | 1 | 1 | 0 | 0 | 0 | 200 |
| L1625 | 5 | 1 | Opponent | no | - | - | 1 | 4 | 0 | 0 | 0 | 0 |
| L1723 | 1 | 1 | Mine | no | 1 | 2 | 3 | 0 | 0 | 0 | 0 | 0 |
| L1723 | 1 | 1 | Opponent | yes | 6 | 3 | 4 | 2 | 1 | 0 | 0 | 0 |
| **Average** | | | Mine | 33% | 3.5 | 3.3 | 2.3 | 0.7 | 0.3 | 0.0 | 0.0 | 66.7 |
| **Average** | | | Opponent | 33% | 4.5 | 2.5 | 3.0 | 2.7 | 0.3 | 0.0 | 0.0 | 0.0 |

### KPIs: cora-bb45c30-p9

Rules off - Mine only: ONE RUN A PLAN.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 17) | 0% (0 of 16) | 0% (0 of 33) |
| Winner chose to follow up after the loser gave ground |  | 100% (3 of 3); on the table 100% | 50% (1 of 2); on the table 50% | 80% (4 of 5); on the table 80% |
| Winner chose to pursue after the loser fell back in good order |  | - | 100% (3 of 3); on the table 100% | 100% (3 of 3); on the table 100% |
| Winner chose to pursue after the loser fled |  | - | 50% (1 of 2); on the table 50% | 50% (1 of 2); on the table 50% |
| Winner chose to follow up or pursue (all three) |  | 100% (3 of 3); on the table 100% | 71% (5 of 7); on the table 71% | 80% (8 of 10); on the table 80% |
| Magic missiles tried each own turn | 50%+ | - | 67% (12 of 18) | 67% (12 of 18) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | - | 67% (12 of 18) | 67% (12 of 18) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | - | - |
| Points that never fought | lower | 42% (2510 of 6000) | 47% (2814 of 5999) | 44% (5324 of 11999) |
|   infantry points that never fought | lower | 46% (611 of 1332) | 75% (627 of 834) | 57% (1238 of 2166) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 65% (13 of 20) | 59% (10 of 17) | 62% (23 of 37) |
| Bound items with a magic missile used (at least once a game) |  | 100% (2 of 2); 2.3 uses a game | 0.0 uses a game | 100% (2 of 2); 1.2 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 100% (1 of 1); 0.3 uses a game | 0.0 uses a game | 100% (1 of 1); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 66% (3390 of 5135) | 49% (2262 of 4600) | 58% (5652 of 9735) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | - | 2.0 (100%) | 2.0 (100%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 3.0 | 1.7 | 1.7 | 4.0 | 0.3 | 2.3 |
| not cast | 7.0 | 2.3 | 0.3 | 2.0 | 1.7 | 25.7 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.0 (4%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.3 (14%) | 0.0 (0%) | 2.0 (100%) | 0.7 (40%) | 0.0 (0%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 1.3 (57%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (3%) |
| OTHER BAR: another bar (miscast, baggage ...) | 1.0 (14%) | 0.7 (29%) | 0.0 (0%) | 0.0 (0%) | 1.0 (60%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 6.0 (86%) | 0.0 (0%) | 0.3 (100%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 24.0 (94%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.7 a game | 0.0 a game | 0.8 a game |
| stood (cast and not dispelled) | - | - | - |
| the unit moved after it | - | - | - |
| it charged on its next turn | - | - | - |
| the enemy charged it first | - | - | - |
| it fought by the end of its next turn | - | - | - |
| it moved out of a charge the enemy had planned (not charged first) | - | - | - |
| none of these (no charge, no fight, no charge escaped) | - | - | - |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 69% (60 of 87) | 72% (33 of 46) | 70% (93 of 133) |
|   cavalry | 83% (10 of 12) | 100% (12 of 12) | 92% (22 of 24) |
|   character | 44% (4 of 9) | 0% (0 of 11) | 20% (4 of 20) |
|   chariot | 50% (3 of 6) | - | 50% (3 of 6) |
|   infantry | 67% (24 of 36) | 91% (21 of 23) | 76% (45 of 59) |
|   monster | 58% (7 of 12) | - | 58% (7 of 12) |
|   war machine | 100% (12 of 12) | - | 100% (12 of 12) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.0 (22%) | 0.0 (0%) | 2.0 (15%) |
| CHARGED: it charged | 1.3 (15%) | 1.3 (31%) | 2.7 (20%) |
| IN COMBAT: it fought this turn or the last | 1.0 (11%) | 0.0 (0%) | 1.0 (8%) |
| NO TARGET IN RANGE | 3.7 (41%) | 2.3 (54%) | 6.0 (45%) |
| ONLY IN COMBAT: the only targets were in combat | 0.0 (0%) | 0.3 (8%) | 0.3 (2%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.0 (11%) | 0.3 (8%) | 1.3 (10%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 7.3 | 0.0 | 100% | 0.0 pts | 0 pts |
| character | 2.0 | 0.0 | 100% | 0.0 pts | 0 pts |
| chariot | 1.0 | 0.0 | 100% | 0.0 pts | 0 pts |
| infantry | 23.3 | 7.3 | 79% | 7.3 pts | 170 pts |
| monster | 2.3 | 0.0 | 100% | 0.0 pts | 0 pts |
| war machine | 4.0 | 1.7 | 83% | 20.3 pts | 81 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.7 | 3.0 | 3.3 |
| Charges that made contact a game | 2.7 | 2.7 | 2.7 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | - | 0.00 declared, 0.00 contact (3 units) | 0.00 declared, 0.00 contact (3 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.25 declared, 0.00 contact (4 units) | 0.50 declared, 0.50 contact (2 units) | 0.33 declared, 0.17 contact (6 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.50 declared, 0.40 contact (20 units) | 0.31 declared, 0.27 contact (26 units) | 0.39 declared, 0.33 contact (46 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 0% (0 of 3) | 100% (2 of 2) | 50% (1 of 2) | 43% (3 of 7) |
| Character in a unit | 100% (3 of 3) | 100% (1 of 1) | - | 100% (4 of 4) |
| Character on its own | 100% (1 of 1) | 50% (1 of 2) | 56% (5 of 9) | 58% (7 of 12) |
| Chariot | 100% (1 of 1) | - | - | 100% (1 of 1) |
| Infantry | 67% (4 of 6) | 50% (1 of 2) | - | 62% (5 of 8) |
| Monster | 60% (3 of 5) | - | - | 60% (3 of 5) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| High Elf Realms | 1 | 100% (1 of 1); on the table 100% | - | 47% | 57% (4 of 7) | 100% (2 of 2); 7.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | - | - | 48% | 67% (4 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Lizardmen | 1 | 100% (2 of 2); on the table 100% | - | 31% | 71% (5 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Tomb Kings of Khemri | 1 | 0% (0 of 1); on the table 0% | - | 43% | 60% (3 of 5) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 2 | 83% (5 of 6); on the table 83% | 67% (12 of 18) | 49% | 58% (7 of 12) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (cora-bb45c30-p9, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 29% (2) | 62% (5) | 47% (7) |
| ...free all their last turn and able to turn (per game) | 0.67 | 1.00 | 1.67 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.67 | 1.00 | 1.67 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.33 | 0.33 |

### Quality by phase: cora-bb45c30-p9

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.3 | 3.3 |
| Strategy | Charge objectives carried out (made contact) | 50% (5 of 10) | 50% (4 of 8) |
| Strategy | Shoot objectives carried out (shot that target) | 27% (7 of 26) | 18% (3 of 17) |
| Strategy | Support requests answered (helper made contact too) | 0% (0 of 1) | - |
| Strategy | Joined characters whose unit fought | 100% (1 of 1) | 17% (1 of 6) |
| Strategy | Lone characters that fought | 75% (6 of 8) | 50% (4 of 8) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 0.7 | 2.7 |
| Movement | Points that never moved of their own | 66.7 | 0.0 |
| Movement | Fights charged into per game | 2.7 | 2.7 |
| Movement | Charges with odds: long shots (under 50%) | 2 of 7, net +0 | 1 of 7, net +0 |
| Movement | Charges with odds: sweet spot (55-75%) | 1 of 7, net -499 | 0 of 7 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 1 of 7, net +75 | 0 of 7 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 of 7, net +103 | 2 of 7, net +88 |
| Shooting | Shots by shooting units (incl. breath weapons) | 17.7 | 11.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 45% (24 of 53) | 24% (8 of 34) |
| Shooting | Points destroyed by shooting units | 65.0 | 0.0 |
| Shooting | War machine shots | 4.0 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 67% (8 of 12) | - |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | - | 2.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | - | 57% (4 of 7) |
| Magic | Wounds caused by magic missiles | 2.7 | - |
| Magic | Wounds caused by other spells | - | 2.0 |
| Magic | Points destroyed by magic (all spells) | 48.3 | 66.3 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.7 / 0.3 / 0.3 / 0.0 | 2.0 / 0.0 / 1.7 / 0.3 |
| Combat | Points destroyed in combat | 220.7 | 364.0 |
| Combat | Points run down | 0.0 | 42.0 |
| Combat | Net points per charged fight, damage counted | -23 | +91 |
| Combat | Net per 100 charger points, damage counted | -7.3 | +25.6 |
| Combat | First round won (charged fights) | 50% | 50% |
| Combat | Net points per charged fight | -32 | +60 |
| Combat | Net points per supported fight / lone fight | - / -32 | - / +60 |
| Combat | Charged fights on a top-3 enemy unit | 3 of 8 | 3 of 8 |
| Game | Points lost | 541.7 | 334.0 |
| Game | VP from objectives | 453.3 | 840.0 |
| Game | Lone holders (player turns) | 3.5 | 4.5 |

- Mine won / drew / lost: 1 / 0 / 2 of 3 ended games (of 3); mean margin (Mine - Opponent) -636 VP
- The side that went first won 1 of 3 games with a winner
- Points traded per game (both sides' losses): 876
- Games not ended: 0; findings 1, warnings 0

### Opponent rules: cora-bb45c30-p9

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| AFTERMATH IN POINTS | - | - | - | - | 0.3 | +27.0 | 0.0 | 0.0 |
| ARMY TABLE | 18.0 | -106.2 | 0.0 | 106.3 | 28.3 | +702.0 | 0.0 | 389.0 |
| ASSAILMENT BY POINTS | 0.3 | +1.1 | 0.0 | 0.0 | 0.7 | +1.9 | 0.0 | 0.0 |
| BACKUP TARGETS | - | - | - | - | 0.3 | +1.0 | 0.0 | 0.0 |
| CANNON PLAN MISSED | 0.3 | +0.0 | 25.0 | 0.0 | - | - | - | - |
| CANNON PLANNED TARGET | 3.7 | +17.6 | 0.0 | 0.0 | - | - | - | - |
| CAST JOB | 0.3 | +2.2 | 0.0 | 66.3 | 2.0 | +11.3 | 184.7 | 0.0 |
| CASTS AFTER FRIENDS | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CASTS FROM BEHIND | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | - | - | - | - | 2.3 | +84.2 | 0.0 | 50.0 |
| CHAFF PASSED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHALLENGE BY POINTS | 0.3 | +4.7 | 0.0 | 0.0 | - | - | - | - |
| CHAMPION KNOWS CHALLENGE | - | - | - | - | 0.3 | -22.9 | 0.0 | 84.7 |
| CHARGE LOSSES | 15.0 | -647.2 | 0.0 | 580.3 | 18.0 | -765.6 | 0.0 | 206.7 |
| CHARGE NOW FIRST | 1.3 | +0.0 | 25.0 | 186.3 | 1.7 | +0.0 | 108.3 | 0.0 |
| CLOSES ON WHAT IT BEATS | 16.3 | +0.0 | 0.0 | 42.0 | 19.3 | +0.0 | 0.0 | 270.3 |
| COMBAT PIVOT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| COVER ONCE | 20.0 | -1376.4 | 0.0 | 225.3 | 16.0 | -1843.0 | 0.0 | 248.3 |
| DEPLOY BY FIGURES | 7.3 | +4.0 | 0.0 | 0.0 | 7.7 | +7.5 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | - | - | - | - | 0.7 | -16.2 | 66.3 | 0.0 |
| EDGE GIVE GROUND | 0.3 | +5.2 | 0.0 | 20.0 | - | - | - | - |
| EXACT ROUND | 2.7 | +16.9 | 136.0 | 112.3 | 2.0 | -10.8 | 159.0 | 84.7 |
| FALL BACK GOOD ORDER | 2.0 | +0.0 | 136.0 | 258.7 | 2.3 | +8.1 | 225.3 | 0.0 |
| FALLS SHORT | - | - | - | - | 34.0 | +289.1 | 0.0 | 25.0 |
| FEATURE BUFFS | 2.3 | +32.6 | 0.0 | 0.0 | 0.7 | +4.3 | 0.0 | 0.0 |
| FIGHT TO THE END | 1.0 | +15.3 | 0.0 | 20.0 | 1.3 | +22.8 | 100.7 | 84.7 |
| FIRE IN ORDER | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FIVE ACTION | 85.0 | +6370.8 | 580.7 | 1157.0 | 108.3 | +6850.8 | 643.3 | 858.0 |
| FLANK NOT WEIGHED | 14.7 | +0.0 | 0.0 | 391.7 | 12.0 | +0.0 | 0.0 | 248.3 |
| FOLLOW UP WEIGHED | 0.7 | +101.7 | 0.0 | 0.0 | 0.7 | +268.1 | 0.0 | 0.0 |
| FOUR ROUNDS | 3.3 | +297.2 | 220.7 | 278.7 | 3.0 | +298.3 | 225.3 | 84.7 |
| FREED FROM HIS FIGHT | 6.3 | +0.0 | 0.0 | 66.3 | 4.0 | +0.0 | 0.0 | 0.0 |
| FRIEND CHARGES FIRST | - | - | - | - | 0.3 | -0.7 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 0.7 | -4.5 | 0.0 | 0.0 | 4.0 | -53.2 | 0.0 | 0.0 |
| GIVES UP | 0.7 | -14.2 | 0.0 | 0.0 | 1.0 | -13.2 | 117.0 | 84.7 |
| GOAL WALK | 12.0 | +872.0 | 0.0 | 100.3 | 5.7 | +410.9 | 0.0 | 0.0 |
| GUN MASK | 0.7 | -13.7 | 0.0 | 0.0 | - | - | - | - |
| HARD STAY DROPPED | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HE REFORMS ONCE FREED | 5.0 | +0.0 | 0.0 | 66.3 | 4.0 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 13.7 | +0.0 | 0.0 | 580.3 | 15.7 | +0.0 | 0.0 | 206.7 |
| HIS CHARGE DENIED | 1.0 | +42.5 | 0.0 | 0.0 | - | - | - | - |
| HIS CHARGE LIST | 9.7 | +0.0 | 0.0 | 0.0 | 10.3 | +0.0 | 0.0 | 62.0 |
| HIS LEGAL MOVES | 10.0 | +0.0 | 0.0 | 166.3 | 7.7 | +0.0 | 0.0 | 46.7 |
| HIS MOVE AND SHOT | 1.7 | -5.8 | 0.0 | 0.0 | 11.3 | -160.0 | 0.0 | 62.0 |
| HIS ONE QUARTER | 4.7 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 62.0 |
| HIS OWN BEST MOVE | 13.3 | +0.0 | 0.0 | 379.7 | 14.3 | +0.0 | 0.0 | 46.7 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 28.7 | +163.5 | 0.0 | 211.7 | 56.0 | +1239.8 | 0.0 | 208.7 |
| HIS SHOTS BY HIS RUN | 24.3 | +181.1 | 0.0 | 544.3 | 55.3 | +868.4 | 0.0 | 220.7 |
| HIS TURN DENIED | - | - | - | - | 0.3 | +1.1 | 58.3 | 0.0 |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HOLD ODDS | 13.0 | +0.0 | 0.0 | 150.3 | 18.7 | +0.0 | 0.0 | 0.0 |
| HOLDER ASSIGNMENT | 8.7 | +693.0 | 0.0 | 108.3 | 13.3 | +786.1 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 3.0 | -107.4 | 220.7 | 278.7 | 2.7 | -159.7 | 225.3 | 84.7 |
| HUNT IN PAIRS | 0.7 | +9.1 | 0.0 | 0.0 | 2.0 | +41.9 | 0.0 | 0.0 |
| IDLE COST | - | - | - | - | 17.0 | -218.3 | 0.0 | 120.7 |
| JOINT CHARGE NOW | 0.7 | +30.1 | 0.0 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 1.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 1.3 | +33.0 | 0.0 | 0.0 | 1.3 | +56.1 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 12.0 | +0.0 | 368.0 | 167.0 | 8.0 | +0.0 | 256.7 | 231.3 |
| LONE WIZARD KEPT IN | 0.3 | +7.9 | 0.0 | 0.0 | 0.3 | +7.5 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | 1.3 | -3.5 | 0.0 | 186.3 | 2.3 | +9.3 | 167.0 | 84.7 |
| LURE BY WHAT IT DRAWS | - | - | - | - | 1.3 | -99.5 | 0.0 | 50.0 |
| MANOEUVRE | 1.0 | -4.6 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| MARCH OVER CASTS | 0.3 | +104.6 | 0.0 | 0.0 | - | - | - | - |
| MARCH WHEELS ONLY | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 1.0 | +13.6 | 0.0 | 0.0 | 5.0 | +198.0 | 0.0 | 25.0 |
| MEETS IN TIME | 4.0 | +232.5 | 0.0 | 0.0 | 4.3 | +194.0 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 2.3 | +44.4 | 0.0 | 66.3 | 4.7 | +32.8 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 2.3 | +34.4 | 0.0 | 66.3 | 5.0 | +21.1 | 0.0 | 0.0 |
| MOVE ORDER | 2.0 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 49.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 10.3 | +982.2 | 0.0 | 379.7 | 16.3 | +1581.4 | 0.0 | 124.0 |
| MOVES UNITS SPELL | 0.3 | +2.4 | 0.0 | 0.0 | - | - | - | - |
| NEARER NOT NEEDED | 11.3 | +447.8 | 0.0 | 132.3 | 9.0 | +343.3 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 9.0 | +922.7 | 0.0 | 332.7 | 12.0 | +1149.1 | 0.0 | 124.0 |
| NO DOUBLE ROUNDS | 2.7 | -152.3 | 136.0 | 278.7 | 2.7 | -164.4 | 225.3 | 84.7 |
| NO LATE CUT | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 1.0 | -0.7 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 1.7 | -15.6 | 0.0 | 0.0 | 3.7 | -191.7 | 58.3 | 0.0 |
| ONE CHECK AFTER THE LAST CHANGE | - | - | - | - | 0.3 | +0.0 | 0.0 | 62.0 |
| ONE FIGHT FORMULA | 8.7 | -158.2 | 0.0 | 166.3 | 9.3 | -193.5 | 0.0 | 62.0 |
| ONE OBJECTIVE FORMULA | 4.7 | +25.8 | 0.0 | 108.3 | 5.3 | -90.9 | 0.0 | 0.0 |
| ONE PROMISE A TARGET | 0.7 | -42.0 | 0.0 | 0.0 | 2.3 | -2.1 | 0.0 | 0.0 |
| ONE ROUTE | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| ONE RUN A PLAN | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS UP | - | - | - | - | 0.3 | +30.7 | 0.0 | 0.0 |
| OVERRUNS AWAY | - | - | - | - | 0.7 | +114.3 | 117.0 | 0.0 |
| PATHS CROSS | - | - | - | - | 1.0 | +32.7 | 0.0 | 0.0 |
| PLAN RESULT | 39.0 | +188.3 | 177.0 | 889.7 | 53.0 | +480.7 | 225.3 | 619.7 |
| PROMISE BELOW ZERO | 0.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| PROMISE BY ITS OWN SUM | 10.7 | -276.4 | 0.0 | 47.0 | 13.0 | -266.4 | 0.0 | 62.0 |
| PROMISE IN STEPS | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | 1.3 | +0.0 | 0.0 | 0.0 | 2.7 | -8.0 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | 0.3 | -0.6 | 0.0 | 0.0 | 2.7 | -35.4 | 0.0 | 0.0 |
| QUARTER ODDS | 21.0 | +2147.6 | 455.7 | 92.3 | 28.7 | +3269.0 | 184.7 | 482.0 |
| REAL GROUND | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | 1.7 | +38.4 | 0.0 | 0.0 | 6.3 | +802.1 | 0.0 | 50.0 |
| REDIRECT FOR A FRIEND IN REACH | 2.7 | +0.0 | 0.0 | 0.0 | 6.7 | +0.0 | 0.0 | 50.0 |
| REFORMS TO MEET IT | 3.7 | -73.6 | 0.0 | 0.0 | 5.7 | -158.6 | 0.0 | 124.0 |
| REFUSING RETIRES | - | - | - | - | 0.7 | +0.0 | 0.0 | 169.3 |
| RESERVE FALL BACK | 0.3 | +73.6 | 0.0 | 0.0 | 1.3 | +38.8 | 0.0 | 0.0 |
| RISK BY ARC | 3.0 | +152.6 | 136.0 | 278.7 | 2.3 | -111.8 | 225.3 | 84.7 |
| RISK ON THE WAY | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| ROUNDS AFTER TERROR | - | - | - | - | 1.3 | -33.1 | 167.0 | 0.0 |
| RUN DOWN | - | - | - | - | 2.3 | -30.2 | 167.0 | 84.7 |
| SAME CHARGE LATER | 0.3 | -4.4 | 0.0 | 0.0 | - | - | - | - |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 2.7 | -147.7 | 0.0 | 0.0 |
| SEARCH SPOT | - | - | - | - | 1.3 | +18.8 | 0.0 | 0.0 |
| SECOND LOOK | - | - | - | - | 0.3 | +15.7 | 58.3 | 0.0 |
| SELF MOVE SPELL | 2.0 | +242.8 | 0.0 | 0.0 | - | - | - | - |
| SET CREDITED ONCE | - | - | - | - | 6.3 | -193.6 | 0.0 | 0.0 |
| SET UP BY THE SET | 2.0 | +37.1 | 0.0 | 0.0 | 8.7 | +152.2 | 0.0 | 0.0 |
| SET UP TOGETHER | - | - | - | - | 0.3 | +7.2 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 1.0 | +2.0 | 0.0 | 0.0 | 0.3 | +1.7 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 9.0 | +0.0 | 0.0 | 0.0 | 7.3 | +0.0 | 0.0 | 25.0 |
| SHOOTS FROM THE BEST SPOT | 2.0 | +112.0 | 0.0 | 117.3 | 2.7 | +11.2 | 0.0 | 0.0 |
| SHOT OR CHARGE | - | - | - | - | 0.7 | -4.2 | 0.0 | 0.0 |
| SHOT RISK POINTS | 11.7 | -72.8 | 0.0 | 438.0 | 46.7 | -309.1 | 0.0 | 174.0 |
| SHOTS AFTER THE MOVES | 4.7 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 18.3 | +453.8 | 0.0 | 82.7 | 11.3 | +56.6 | 0.0 | 0.0 |
| SPELL WORTH | 0.7 | +7.2 | 0.0 | 0.0 | - | - | - | - |
| SPELLS IN THE FIGHT | 1.0 | +1.7 | 0.0 | 0.0 | - | - | - | - |
| SPOT AS THE GAME MOVES | 6.0 | +0.0 | 0.0 | 47.0 | 12.7 | +0.0 | 0.0 | 124.0 |
| STAND AND SHOOT | - | - | - | - | 0.7 | -2.8 | 58.3 | 0.0 |
| STANDS FOR A REASON | - | - | - | - | 4.0 | +0.0 | 116.7 | 0.0 |
| STANDS STILL | 30.3 | +0.0 | 360.0 | 183.7 | 33.7 | +0.0 | 418.0 | 0.0 |
| STAY WORTH | 10.0 | +7.9 | 180.0 | 24.0 | 10.3 | +50.0 | 116.7 | 0.0 |
| STUBBORN BY POINTS | 0.3 | +17.8 | 84.7 | 0.0 | - | - | - | - |
| STUPIDITY NEXT TURN | 0.3 | +0.0 | 0.0 | 47.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 1.7 | +29.5 | 0.0 | 0.0 | 6.0 | +662.6 | 0.0 | 0.0 |
| SUPPORT NARROWED | 0.7 | +0.0 | 0.0 | 20.0 | 0.7 | +0.0 | 66.3 | 0.0 |
| SUPPORT WORKED OUT | 1.7 | +29.5 | 0.0 | 0.0 | 6.0 | +662.6 | 0.0 | 0.0 |
| SURE REACH TOGETHER | - | - | - | - | 0.3 | +0.6 | 0.0 | 0.0 |
| SWIFTSTRIDE BY POINTS | 0.3 | +35.8 | 0.0 | 0.0 | - | - | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 2.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| THE PROMISE ADDS | - | - | - | - | 1.0 | -43.3 | 0.0 | 0.0 |
| THE PROMISED MOVE | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 3.7 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 1.3 | +0.0 | 0.0 | 66.3 | 2.0 | +0.0 | 0.0 | 25.0 |
| THE ROW READS HIS LAST RUN | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 1.3 | +0.0 | 0.0 | 66.3 | 1.3 | +0.0 | 0.0 | 25.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 39.7 | +0.0 | 0.0 | 357.0 | 56.0 | +0.0 | 0.0 | 411.7 |
| TIED UP BY THE SUM | 1.0 | +111.6 | 74.0 | 92.3 | 1.0 | +128.7 | 117.0 | 0.0 |
| TIME ON OUR SIDE | 36.0 | +538.8 | 0.0 | 415.7 | - | - | - | - |
| WAITS AGAIN | 0.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| WAR ENGINE JOBS | - | - | - | - | 0.7 | +0.0 | 0.0 | 50.0 |
| WEAPON BY POINTS | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| WHAT THE JOINER ADDS | 0.7 | -9.4 | 169.3 | 0.0 | - | - | - | - |
| WHO FIGHTS | 0.3 | +5.2 | 0.0 | 20.0 | 0.7 | -2.0 | 58.7 | 84.7 |
| WHO HITS BACK | - | - | - | - | 0.7 | +118.4 | 0.0 | 0.0 |
| WHOLE FIGHT | 0.3 | -54.7 | 84.7 | 0.0 | - | - | - | - |
| WHOLE FIGHT DANGER | 4.3 | -531.8 | 0.0 | 142.3 | 3.0 | -313.4 | 0.0 | 144.7 |
| WOUNDS ON THE RANKS | 1.0 | +17.4 | 0.0 | 0.0 | 2.7 | +49.1 | 0.0 | 0.0 |

### Rule changes: cora-bb45c30-p9

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 139 | 139 | 90 | 30.00 | +1934 | +21.5 |
| HOLDER ASSIGNMENT | 66 | 66 | 62 | 20.67 | +3668 | +59.2 |
| LEGAL CHARGES ONLY | 60 | 60 | 60 | 20.00 | +0 | +0.0 |
| FIVE ACTION | 580 | 567 | 48 | 16.00 | +3326 | +69.3 |
| HIS SHOT LIST | 254 | 247 | 45 | 15.00 | +306 | +6.8 |
| HIS SHOTS BY HIS RUN | 239 | 232 | 30 | 10.00 | +277 | +9.2 |
| MOVE TO CHARGE COMPUTED | 80 | 72 | 30 | 10.00 | +1578 | +52.6 |
| QUARTER ODDS | 149 | 144 | 30 | 10.00 | +2427 | +80.9 |
| REDIRECT FOR A FRIEND IN REACH | 28 | 28 | 28 | 9.33 | +0 | +0.0 |
| DEPLOY BY FIGURES | 45 | 45 | 25 | 8.33 | +242 | +9.7 |
| THE TABLE AGAIN | 36 | 36 | 25 | 8.33 | +0 | +0.0 |
| NEXT CHARGE BY LIST | 63 | 58 | 22 | 7.33 | +1387 | +63.0 |
| PROMISE BY ITS OWN SUM | 71 | 71 | 21 | 7.00 | -1628 | -77.5 |
| MEETS IN TIME | 25 | 25 | 19 | 6.33 | +1217 | +64.0 |
| SHOT RISK POINTS | 175 | 171 | 17 | 5.67 | +161 | +9.5 |
| COVER ONCE | 108 | 74 | 16 | 5.33 | +282 | +17.6 |
| FOUR ROUNDS | 19 | 18 | 16 | 5.33 | +681 | +42.6 |
| OFF BEST | 16 | 16 | 16 | 5.33 | -622 | -38.9 |
| MOVE ORDER | 14 | 14 | 14 | 4.67 | +0 | +0.0 |
| GOAL WALK | 53 | 53 | 11 | 3.67 | +642 | +58.4 |
| SHOOTS FROM THE BEST SPOT | 14 | 14 | 10 | 3.33 | +135 | +13.5 |
| ONE PROMISE A TARGET | 9 | 9 | 9 | 3.00 | -132 | -14.7 |
| CHARGE LOSSES | 99 | 99 | 8 | 2.67 | +1035 | +129.4 |
| LANE BY FIGURES | 8 | 8 | 8 | 2.67 | +267 | +33.4 |
| RISK BY ARC | 16 | 15 | 8 | 2.67 | +192 | +24.0 |
| SET UP BY THE SET | 32 | 30 | 8 | 2.67 | +291 | +36.4 |
| SUPPORT ADDS | 23 | 23 | 8 | 2.67 | +318 | +39.7 |
| SUPPORT WORKED OUT | 23 | 23 | 8 | 2.67 | +318 | +39.7 |
| CAST JOB | 7 | 7 | 7 | 2.33 | +1 | +0.2 |
| CHAFF IN THE MOVE | 7 | 7 | 6 | 2.00 | +0 | +0.0 |
| IDLE COST | 51 | 36 | 6 | 2.00 | +54 | +9.0 |
| PROMISE KNOWS THE FIGHT | 12 | 10 | 6 | 2.00 | -24 | -4.0 |
| ADVANCE LANE KEPT | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| MAX FOR POSITIONING | 18 | 15 | 5 | 1.67 | +12 | +2.4 |
| RESERVE FALL BACK | 5 | 5 | 5 | 1.67 | +337 | +67.4 |
| TIED UP BY THE SUM | 6 | 5 | 5 | 1.67 | +201 | +40.2 |
| CASTS FROM BEHIND | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 4 | 4 | 4 | 1.33 | +1109 | +277.3 |
| SEARCH SPOT | 4 | 4 | 4 | 1.33 | +56 | +14.1 |
| SHOOTERS IN TWO RANKS | 4 | 4 | 4 | 1.33 | +11 | +2.8 |
| SUPPORT NARROWED | 4 | 4 | 4 | 1.33 | -562 | -140.4 |
| TIME ON OUR SIDE | 108 | 89 | 4 | 1.33 | +2 | +0.4 |
| ASSAILMENT BY POINTS | 3 | 3 | 3 | 1.00 | +9 | +3.0 |
| CHARGE NOW FIRST | 9 | 9 | 3 | 1.00 | -70 | -23.3 |
| FALLS SHORT | 102 | 87 | 3 | 1.00 | +37 | +12.4 |
| HARD STAY DROPPED | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| HOLDS AMBUSHERS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| MISSILES IN THE MOVE | 21 | 14 | 3 | 1.00 | +27 | +9.1 |
| PATHS CROSS | 3 | 3 | 3 | 1.00 | +98 | +32.7 |
| EXACT ROUND | 14 | 13 | 2 | 0.67 | +14 | +7.2 |
| FEATURE BUFFS | 9 | 9 | 2 | 0.67 | +2 | +1.1 |
| FIGHT TO THE END | 7 | 7 | 2 | 0.67 | +9 | +4.3 |
| JOINT CHARGE NOW | 2 | 2 | 2 | 0.67 | +90 | +45.2 |
| LONE WIZARD KEPT IN | 2 | 2 | 2 | 0.67 | +46 | +23.1 |
| LOST AFTER ESCAPE | 11 | 11 | 2 | 0.67 | +9 | +4.3 |
| PROMISE READS THE TABLE | 9 | 9 | 2 | 0.67 | -15 | -7.4 |
| SHOTS AFTER THE MOVES | 19 | 19 | 2 | 0.67 | +0 | +0.0 |
| SHOTS IN THE MOVE | 89 | 59 | 2 | 0.67 | +38 | +18.9 |
| WHO FIGHTS | 3 | 3 | 2 | 0.67 | +17 | +8.5 |
| WHO HITS BACK | 2 | 2 | 2 | 0.67 | +247 | +123.4 |
| WHOLE FIGHT DANGER | 22 | 22 | 2 | 0.67 | +1 | +0.4 |
| WOUNDS ON THE RANKS | 11 | 11 | 2 | 0.67 | +50 | +25.1 |
| AFTERMATH IN POINTS | 1 | 1 | 1 | 0.33 | +81 | +81.1 |
| CANNON PLANNED TARGET | 11 | 11 | 1 | 0.33 | +0 | +0.0 |
| CHAFF PASSED | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CHALLENGE BY POINTS | 1 | 1 | 1 | 0.33 | +14 | +14.0 |
| COMBAT PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| EDGE GIVE GROUND | 1 | 1 | 1 | 0.33 | +1 | +0.9 |
| FIRE IN ORDER | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| HIS CHARGE DENIED | 3 | 3 | 1 | 0.33 | +4 | +4.5 |
| MOVES UNITS SPELL | 1 | 1 | 1 | 0.33 | +7 | +7.3 |
| ONE FIGHT FORMULA | 54 | 26 | 1 | 0.33 | +1 | +1.1 |
| OVERRUNS AWAY | 2 | 1 | 1 | 0.33 | +16 | +16.1 |
| REDIRECT COUNTER | 24 | 22 | 1 | 0.33 | +247 | +246.9 |
| SECOND LOOK | 1 | 1 | 1 | 0.33 | +47 | +47.2 |
| STAY WORTH | 61 | 49 | 1 | 0.33 | +8 | +8.0 |
| STUBBORN BY POINTS | 1 | 1 | 1 | 0.33 | +53 | +53.3 |
| SWIFTSTRIDE BY POINTS | 1 | 1 | 1 | 0.33 | +107 | +107.4 |
| THE ROW IN ITS ORDER | 17 | 1 | 1 | 0.33 | +0 | +0.0 |
| WEAPON BY POINTS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| BACKUP TARGETS | 1 | not checked | - | - | - | - |
| CANNON PLAN MISSED | 1 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 4 | trace | - | - | - | - |
| CHAMPION KNOWS CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 107 | 107 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 2 | 2 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 13 | 12 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 80 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 31 | 29 | 0 | 0.00 | - | - |
| FRIEND CHARGES FIRST | 1 | 1 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 14 | 12 | 0 | 0.00 | - | - |
| GIVES UP | 5 | 4 | 0 | 0.00 | - | - |
| GUN MASK | 2 | 2 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 27 | 27 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 88 | 88 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 60 | 57 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 53 | 51 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 39 | 38 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 27 | 26 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 83 | 79 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 1 | not checked | - | - | - | - |
| HIS TURN RUN | 18 | 18 | 0 | 0.00 | - | - |
| HOLD ODDS | 95 | 95 | 0 | 0.00 | - | - |
| HONEST WORTH | 17 | 16 | 0 | 0.00 | - | - |
| HUNT IN PAIRS | 8 | 4 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 21 | 21 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 2 | 2 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 4 | 4 | 0 | 0.00 | - | - |
| MANOEUVRE | 10 | 10 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 1 | 1 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 3 | 3 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 22 | 16 | 0 | 0.00 | - | - |
| NEARER NOT NEEDED | 61 | 58 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 16 | 15 | 0 | 0.00 | - | - |
| NO LATE CUT | 4 | 4 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT TURNED | 1 | 1 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 3 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 1 | not checked | - | - | - | - |
| ONE OBJECTIVE FORMULA | 30 | 22 | 0 | 0.00 | - | - |
| ONE ROUTE | 3 | 3 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 18 | 18 | 0 | 0.00 | - | - |
| OPENS UP | 1 | 1 | 0 | 0.00 | - | - |
| PLAN RESULT | 276 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 6 | 6 | 0 | 0.00 | - | - |
| PROMISE IN STEPS | 1 | 1 | 0 | 0.00 | - | - |
| REAL GROUND | 3 | 3 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 28 | 25 | 0 | 0.00 | - | - |
| REFUSING RETIRES | 2 | 2 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 3 | 3 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 4 | 4 | 0 | 0.00 | - | - |
| RUN DOWN | 7 | 7 | 0 | 0.00 | - | - |
| SAME CHARGE LATER | 1 | 1 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 8 | 8 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 6 | not checked | - | - | - | - |
| SET CREDITED ONCE | 19 | 17 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 1 | not checked | - | - | - | - |
| SHOOTERS ON THE TABLE | 49 | not checked | - | - | - | - |
| SHOT OR CHARGE | 2 | 2 | 0 | 0.00 | - | - |
| SPELL WORTH | 2 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 3 | 3 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 56 | 50 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 2 | 1 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 12 | 11 | 0 | 0.00 | - | - |
| STANDS STILL | 192 | 188 | 0 | 0.00 | - | - |
| STUPIDITY NEXT TURN | 7 | 7 | 0 | 0.00 | - | - |
| SURE REACH TOGETHER | 1 | 1 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 10 | not checked | - | - | - | - |
| THE PROMISE ADDS | 3 | 2 | 0 | 0.00 | - | - |
| THE PROMISED MOVE | 1 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 10 | not checked | - | - | - | - |
| THE ROW READS HIS LAST RUN | 1 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 8 | not checked | - | - | - | - |
| THE TABLE BINDS | 287 | not checked | - | - | - | - |
| WAITS AGAIN | 5 | 5 | 0 | 0.00 | - | - |
| WAR ENGINE JOBS | 2 | 2 | 0 | 0.00 | - | - |
| WHAT THE JOINER ADDS | 2 | 2 | 0 | 0.00 | - | - |
| WHOLE FIGHT | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: cora-bb45c30-p9

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| PROMISE BY ITS OWN SUM | rule | 3.33 | 3.67 | 77.5 |
| ARMY TABLE | rule | 2.67 | 2.33 | 37.3 |
| JOB FIRST | gate | 1.67 | 3.00 | 43.7 |
| ONE PROMISE A TARGET | rule | 0.67 | 1.00 | 50.5 |
| PROMISE KNOWS THE FIGHT | rule | - | 1.33 | 5.7 |
| SUPPORT NARROWED | rule | 0.67 | 0.67 | 140.4 |
| CHARGE NOW FIRST | rule | 0.67 | 0.33 | 23.3 |
| NO REASON | gate | - | 0.67 | 5.0 |
| PROMISE READS THE TABLE | rule | - | 0.67 | 7.4 |
| HOLDER ASSIGNMENT | rule | - | 0.33 | 1.0 |

### Plans: cora-bb45c30-p9

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 2.7 | 25% | 311 | 81 | 26% |
| Mine | move | 28.3 | 96% | 1688 | 0 | 0% |
| Mine | shoot | 8.0 | 29% | 575 | 107 | 19% |
| Opponent | charge | 2.3 | 86% | 304 | 299 | 98% |
| Opponent | join | 3.0 | 100% | 116 | 0 | 0% |
| Opponent | move | 42.0 | 98% | 2113 | 0 | 0% |
| Opponent | shoot | 3.7 | 45% | 224 | 182 | 81% |
| Opponent | support | 2.0 | 83% | 0 | 0 | - |

### Battle groups: cora-bb45c30-p9

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 1.7 | 0% | - | - | - | - | - | - | - | - |
| Opponent | REDIRECT COUNTER | 6.3 | 11% | 100% | 0% | - | 50% | 0% | 0% | 50% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: cora-bb45c30-p9

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | - | - | - | - |
| Mine | Chaff | 2 | 0 (2) | 0 | 0 | 0 | 0% | 1.0 | - | 0 (2) | - | 0 (1) | 0 (1) |
| Mine | Character | 8 | 15 (8) | 15 | 0 | 33 | 12% | 2.7 | 0 (3) | 26 (4) | 0 (1) | 0 (5) | 35 (3) |
| Mine | Clean-up | 1 | 0 (1) | 0 | 0 | 100 | 0% | 4.0 | 0 (1) | - | - | 0 (1) | - |
| Mine | Fast Hammer | 4 | 27 (4) | 8 | 19 | 21 | 25% | 2.3 | 0 (1) | 34 (3) | - | 128 (1) | 0 (3) |
| Mine | Hammer | 4 | 36 (4) | 36 | 0 | 19 | 25% | 3.0 | 35 (3) | 40 (1) | - | 36 (4) | - |
| Mine | Shooter | 6 | 56 (6) | 29 | 27 | 55 | 0% | 1.3 | 61 (2) | 8 (3) | 271 (1) | 90 (4) | 0 (2) |
| Mine | Support | 3 | 0 (3) | 0 | 0 | 0 | 100% | - | - | 0 (3) | - | 0 (3) | - |
| Mine | War machine | 2 | 0 (2) | 0 | 0 | 0 | 0% | 1.0 | 0 (1) | 0 (1) | - | 0 (2) | - |
| Mine | Wizard | 1 | 0 (1) | 0 | 0 | 0 | 0% | 2.0 | 0 (1) | - | - | 0 (1) | - |
| Opponent | Chaff | 10 | 57 (10) | 0 | 57 | 24 | 60% | 2.5 | 8 (6) | 50 (3) | 364 (1) | 60 (7) | 50 (3) |
| Opponent | Character | 9 | 29 (9) | 29 | 0 | 0 | 56% | 4.2 | 45 (2) | 27 (4) | 19 (3) | 29 (3) | 29 (6) |
| Opponent | Clean-up | 3 | 46 (3) | 0 | 46 | 87 | 0% | 3.7 | 350 (1) | 0 (2) | - | 101 (2) | 0 (1) |
| Opponent | Fast Hammer | 8 | 67 (8) | 58 | 9 | 28 | 50% | 2.2 | 39 (1) | 73 (5) | 81 (2) | 29 (3) | 83 (5) |
| Opponent | Hammer | 1 | 0 (1) | 0 | 0 | 0 | 0% | 2.0 | - | 0 (1) | - | - | 0 (1) |
| Opponent | Holder | 2 | 0 (2) | 0 | 0 | 0 | 0% | 2.0 | - | 0 (1) | 0 (1) | 0 (1) | 0 (1) |
| Opponent | Support | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | 0 (1) | - | - | - | 0 (1) |
| Opponent | Wizard | 5 | 0 (5) | 0 | 0 | 0 | 20% | 2.2 | 0 (3) | 0 (2) | - | 0 (2) | 0 (3) |

### Charged fights: cora-bb45c30-p9

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | High Elf Realms | 1 | 75 | 186 | 3.0 | 1.0 | 62 | 0 | +62 | 1 of 3 | 1 of 3 | - | +62 |
| Mine | Kingdom of Bretonnia | 1 | 0 | 476 | 3.0 | 1.0 | 159 | 92 | +66 | 1 of 3 | 3 of 3 | - | +66 |
| Mine | Lizardmen | 1 | 265 | 0 | 2.0 | 1.0 | 0 | 320 | -320 | 1 of 2 | 0 of 2 | - | -320 |
| **Mine** | all armies | 3 | 113 | 221 | 2.7 | 1.0 | 83 | 115 | -32 | 3 of 8 | 4 of 8 | - | -32 |
| Opponent | Tomb Kings of Khemri | 1 | 0 | 175 | 4.0 | 1.0 | 44 | 0 | +44 | 2 of 4 | 2 of 4 | - | +44 |
| Opponent | Vampire Counts | 2 | 100 | 151 | 2.0 | 1.0 | 76 | 0 | +76 | 1 of 4 | 2 of 4 | - | +76 |
| **Opponent** | all armies | 3 | 66 | 159 | 2.7 | 1.0 | 60 | 0 | +60 | 3 of 8 | 4 of 8 | - | +60 |

### Effective charges: cora-bb45c30-p9

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | High Elf Realms | 3 | 2 (net +0) | 0 | 0 | 0 | 0 | 1 (net +186) | 0 | 0% (0 of 3) |
| Mine | Kingdom of Bretonnia | 3 | 0 | 0 | 0 | 0 | 1 (net +75) | 2 (net +62) | 0 | 0% (0 of 3) |
| Mine | Lizardmen | 2 | 0 | 0 | 1 (net -499) | 0 | 0 | 0 | 1 | 100% (1 of 1) |
| Opponent | Tomb Kings of Khemri | 4 | 0 | 1 (net +0) | 0 | 1 (net +0) | 0 | 1 (net +0) | 1 | 0% (0 of 3) |
| Opponent | Vampire Counts | 4 | 1 (net +0) | 0 | 0 | 2 (net +63) | 0 | 1 (net +176) | 0 | 0% (0 of 4) |

### Charged fights, damage counted: cora-bb45c30-p9

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 2 | 278 | 266 | +0 | 2 | 92 | -90 | -32.5 |
| Mine | Effective (55-75%) | 1 | 399 | 195 | -499 | 98 | 499 | -402 | -100.6 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 | 390 | 196 | +103 | 277 | 123 | +154 | +39.5 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 277 | 75 | +75 | 75 | 0 | +75 | +27.1 |
| Mine | No odds | 1 | 141 | 70 | -141 | 0 | 141 | -141 | -100.0 |
| Mine | All fights | 8 | 318 | 182 | -32 | 126 | 149 | -23 | -7.3 |
| Opponent | Long shot (under 50%) | 1 | 254 | 371 | +0 | 0 | 0 | +0 | +0.0 |
| Opponent | 50-54% | 1 | 440 | 405 | +0 | 347 | 293 | +54 | +12.2 |
| Opponent | 76-89% | 3 | 363 | 136 | +42 | 103 | 0 | +103 | +28.4 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 308 | 180 | +88 | 88 | 0 | +88 | +28.5 |
| Opponent | No odds | 1 | 440 | 175 | +175 | 189 | 0 | +189 | +42.9 |
| Opponent | All fights | 8 | 355 | 215 | +60 | 128 | 37 | +91 | +25.6 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| cora-bb45c30-p9 | move | 31 | 3 (10%) | 3 (10%) | 6 (19%) | 22 (71%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L1527, L1625 |
| Invocation of Nehek | Opponent | L1527, L1625 |
| Ring of Doom | Mine | L1527 |

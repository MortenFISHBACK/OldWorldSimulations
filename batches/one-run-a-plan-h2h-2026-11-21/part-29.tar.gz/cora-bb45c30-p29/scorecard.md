# Doctrine scorecard: cora-bb45c30-p29

### Scorecard: cora-bb45c30-p29

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0717 | 3 | 1 | Mine | no | 0 | 4 | 2 | 3 | 0 | 0 | 0 | 375 |
| L0717 | 3 | 1 | Opponent | yes | 0 | 3 | 1 | 0 | 1 | 0 | 0 | 141 |
| L0733 | 1 | 1 | Mine | no | 9 | 4 | 3 | 0 | 0 | 0 | 0 | 295 |
| L0733 | 1 | 1 | Opponent | no | 0 | 4 | 1 | 6 | 1 | 0 | 0 | 0 |
| L0823 | 1 | 1 | Mine | no | 6 | - | 0 | 1 | 0 | 0 | 0 | 385 |
| L0823 | 1 | 1 | Opponent | no | 0 | 1 | 3 | 3 | 1 | 0 | 0 | 195 |
| **Average** | | | Mine | 0% | 5.0 | 4.0 | 1.7 | 1.3 | 0.0 | 0.0 | 0.0 | 351.7 |
| **Average** | | | Opponent | 33% | 0.0 | 2.7 | 1.7 | 3.0 | 1.0 | 0.0 | 0.0 | 112.0 |

### KPIs: cora-bb45c30-p29

Rules off - Opponent only: ONE RUN A PLAN.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 81% (13 of 16) | 0% (0 of 12) | 46% (13 of 28) |
| Winner chose to follow up after the loser gave ground |  | 67% (2 of 3); on the table 67% | 100% (7 of 7); on the table 100% | 90% (9 of 10); on the table 90% |
| Winner chose to pursue after the loser fell back in good order |  | - | - | - |
| Winner chose to pursue after the loser fled |  | 100% (1 of 1); on the table 100% | 100% (3 of 3); on the table 100% | 100% (4 of 4); on the table 100% |
| Winner chose to follow up or pursue (all three) |  | 75% (3 of 4); on the table 75% | 100% (10 of 10); on the table 100% | 93% (13 of 14); on the table 93% |
| Magic missiles tried each own turn | 50%+ | 50% (6 of 12) | 33% (4 of 12) | 42% (10 of 24) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 75% (6 of 8) | 36% (4 of 11) | 53% (10 of 19) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | - | - |
| Points that never fought | lower | 62% (3738 of 5998) | 55% (3315 of 6000) | 59% (7053 of 11998) |
|   infantry points that never fought | lower | 37% (267 of 715) | 53% (756 of 1418) | 48% (1023 of 2133) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 57% (17 of 30) | 68% (15 of 22) | 62% (32 of 52) |
| Bound items with a magic missile used (at least once a game) |  | 0.0 uses a game | 100% (2 of 2); 2.0 uses a game | 100% (2 of 2); 1.0 uses a game |
| Bound items with another spell used |  | 50% (1 of 2); 0.3 uses a game | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0% (0 of 3); 0.0 uses a game | 0% (0 of 1); 0.0 uses a game | 0% (0 of 4); 0.0 uses a game |
|   their share of the points of units over 100 pts | lower | 53% (2876 of 5389) | 64% (3202 of 5023) | 58% (6078 of 10412) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 2.0 (75%) | 2.0 (43%) |
| MARCHED: its unit marched | 0.7 (33%) | 0.3 (12%) | 1.0 (21%) |
| IN COMBAT: engaged in combat | 0.3 (17%) | 0.0 (0%) | 0.3 (7%) |
| GONE: slain | 1.0 (50%) | 0.3 (12%) | 1.3 (29%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 4.0 | 1.7 | 3.3 | 0.7 | 0.3 |
| not cast | 4.0 | 0.3 | 4.7 | 1.3 | 11.7 |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.3 (100%) | 2.0 (43%) | 0.0 (0%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 1.0 (21%) | 0.3 (25%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.0 (0%) | 0.3 (7%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | 2.7 (67%) | 0.0 (0%) | 1.3 (29%) | 0.3 (25%) | 3.0 (26%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (50%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.3 (33%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 8.7 (74%) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 69% (68 of 98) | 61% (61 of 100) | 65% (129 of 198) |
|   cavalry | 42% (5 of 12) | 62% (10 of 16) | 54% (15 of 28) |
|   character | - | 47% (8 of 17) | 47% (8 of 17) |
|   chariot | 60% (3 of 5) | - | 60% (3 of 5) |
|   infantry | 65% (15 of 23) | 69% (42 of 61) | 68% (57 of 84) |
|   monster | - | 17% (1 of 6) | 17% (1 of 6) |
|   war machine | 78% (45 of 58) | - | 78% (45 of 58) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 4.3 (43%) | 1.0 (8%) | 5.3 (23%) |
| CHARGED: it charged | 0.0 (0%) | 2.3 (18%) | 2.3 (10%) |
| IN COMBAT: it fought this turn or the last | 0.0 (0%) | 0.3 (3%) | 0.3 (1%) |
| MOVED: a war machine that moved | 0.7 (7%) | 0.0 (0%) | 0.7 (3%) |
| NO TARGET IN RANGE | 0.3 (3%) | 4.3 (33%) | 4.7 (20%) |
| ONLY IN COMBAT: the only targets were in combat | 1.3 (13%) | 1.0 (8%) | 2.3 (10%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.0 (10%) | 4.0 (31%) | 5.0 (22%) |
| SHELTERED: the target was sheltered | 1.7 (17%) | 0.0 (0%) | 1.7 (7%) |
| OTHER BAR | 0.7 (7%) | 0.0 (0%) | 0.7 (3%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 6.7 | 3.0 | 70% | 9.6 pts | 64 pts |
| character | 2.7 | 0.7 | 75% | 5.2 pts | 14 pts |
| chariot | 1.0 | 0.7 | 67% | 31.9 pts | 32 pts |
| infantry | 26.7 | 13.3 | 69% | 14.1 pts | 375 pts |
| monster | 0.3 | 0.0 | 100% | 0.0 pts | 0 pts |
| war machine | 15.0 | 13.3 | 58% | 26.8 pts | 402 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 1.7 | 3.0 | 2.3 |
| Charges that made contact a game | 1.7 | 2.0 | 1.8 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.50 declared, 0.50 contact (2 units) | - | 0.50 declared, 0.50 contact (2 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 0.00 declared, 0.00 contact (2 units) | 0.00 declared, 0.00 contact (2 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.17 declared, 0.17 contact (23 units) | 0.32 declared, 0.21 contact (28 units) | 0.25 declared, 0.20 contact (51 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 56% (5 of 9) | 33% (1 of 3) | - | 50% (6 of 12) |
| Character in a unit | 80% (4 of 5) | - | 100% (1 of 1) | 83% (5 of 6) |
| Character on its own | 100% (4 of 4) | 0% (0 of 1) | 50% (3 of 6) | 64% (7 of 11) |
| Chariot | - | 100% (1 of 1) | - | 100% (1 of 1) |
| Infantry | 0% (0 of 2) | 67% (2 of 3) | 0% (0 of 1) | 33% (2 of 6) |
| Monster | 80% (4 of 5) | - | - | 80% (4 of 5) |
| Monstrous | 100% (1 of 1) | - | - | 100% (1 of 1) |
| War Machines | 60% (6 of 10) | - | - | 60% (6 of 10) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Empire of Man | 3 | 75% (3 of 4); on the table 75% | 50% (6 of 12) | 62% | 57% (17 of 30) | 0.0 uses a game | 50% (1 of 2); 0.3 uses a game | 0% (0 of 3); 0.0 uses a game |
| Lizardmen | 1 | 100% (1 of 1); on the table 100% | - | 62% | 71% (5 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Tomb Kings of Khemri | 1 | 100% (5 of 5); on the table 100% | 0% (0 of 6) | 47% | 40% (2 of 5) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 1 | 100% (4 of 4); on the table 100% | 67% (4 of 6) | 58% | 80% (8 of 10) | 100% (2 of 2); 6.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (cora-bb45c30-p29, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 25% (1) | 100% (1) | 40% (2) |
| ...free all their last turn and able to turn (per game) | 0.33 | 0.00 | 0.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.33 | 0.33 |
| ...with the charger already in that arc before they moved (per game) | 0.33 | 0.00 | 0.33 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.33 | 0.33 |

### Quality by phase: cora-bb45c30-p29

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.3 | 2.0 |
| Strategy | Charge objectives carried out (made contact) | 100% (5 of 5) | 43% (3 of 7) |
| Strategy | Shoot objectives carried out (shot that target) | 25% (16 of 65) | 36% (4 of 11) |
| Strategy | Hexes on a unit its side charged or shot that turn | 25% (1 of 4) | - |
| Strategy | Joined characters whose unit fought | 33% (1 of 3) | 25% (1 of 4) |
| Strategy | Lone characters that fought | 30% (3 of 10) | 50% (3 of 6) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 1.3 | 3.0 |
| Movement | Points that never moved of their own | 351.7 | 112.0 |
| Movement | Fights charged into per game | 1.7 | 2.0 |
| Movement | Charges with odds: long shots (under 50%) | 1 of 5, net -457 | 2 of 3, net -55 |
| Movement | Charges with odds: sweet spot (55-75%) | 1 of 5, net +0 | 0 of 3 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 5 | 0 of 3 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 of 5, net -53 | 1 of 3, net +265 |
| Shooting | Shots by shooting units (incl. breath weapons) | 7.7 | 22.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 61% (14 of 23) | 50% (33 of 66) |
| Shooting | Points destroyed by shooting units | 65.0 | 221.0 |
| Shooting | War machine shots | 15.0 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 60% (27 of 45) | - |
| Shooting | Points destroyed by war machines | 316.0 | 0.0 |
| Magic | Magic missiles cast | 2.0 | 0.7 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 50% (3 of 6) | 0% (0 of 2) |
| Magic | Wounds caused by magic missiles | 3.3 | 3.7 |
| Magic | Wounds caused by other spells | 0.3 | - |
| Magic | Points destroyed by magic (all spells) | 36.0 | 93.7 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.0 / 1.3 / 0.3 / 0.0 | 2.7 / 0.0 / 0.0 / 0.7 |
| Combat | Points destroyed in combat | 92.7 | 179.7 |
| Combat | Points run down | 86.0 | 152.3 |
| Combat | Net points per charged fight, damage counted | -65 | +75 |
| Combat | Net per 100 charger points, damage counted | -28.6 | +30.3 |
| Combat | First round won (charged fights) | 60% | 67% |
| Combat | Net points per charged fight | -61 | +48 |
| Combat | Net points per supported fight / lone fight | - / -61 | - / +48 |
| Combat | Charged fights on a top-3 enemy unit | 1 of 5 | 4 of 6 |
| Game | Points lost | 698.3 | 579.0 |
| Game | VP from objectives | 750.0 | 850.0 |
| Game | Lone holders (player turns) | 5.0 | 0.0 |

- Mine won / drew / lost: 0 / 2 / 1 of 3 ended games (of 3); mean margin (Mine - Opponent) -268 VP
- The side that went first won 1 of 1 games with a winner
- Points traded per game (both sides' losses): 1277
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: cora-bb45c30-p29

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 36.0 |
| AFTERMATH IN POINTS | 0.3 | +161.7 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | 18.3 | +186.4 | 0.0 | 51.3 | 28.3 | +566.7 | 0.0 | 227.0 |
| ARRIVAL HUNT | - | - | - | - | 0.3 | +1.0 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 4.3 | +0.0 | 0.0 | 43.3 | - | - | - | - |
| BEST PRIZE | - | - | - | - | 0.3 | +5.7 | 0.0 | 0.0 |
| CANNON PLAN MISSED | 2.3 | +0.0 | 423.3 | 0.0 | - | - | - | - |
| CANNON PLANNED TARGET | 13.7 | +504.9 | 1172.7 | 128.3 | - | - | - | - |
| CANNON SIGHT KEPT | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CAST JOB | 2.0 | +231.7 | 228.0 | 253.3 | - | - | - | - |
| CASTER AWAY FROM SCREEN | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CHARACTER GUNS | - | - | - | - | 5.3 | +0.0 | 0.0 | 0.0 |
| CHARGE LOSSES | 17.7 | -953.3 | 0.0 | 665.3 | 22.0 | -1079.2 | 0.0 | 497.0 |
| CHARGE NOT DECLARED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CHARGE NOW FIRST | 1.7 | +0.0 | 183.7 | 156.7 | 0.3 | +0.0 | 0.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 9.3 | +0.0 | 0.0 | 253.3 | 16.3 | +0.0 | 0.0 | 58.3 |
| COMBAT PIVOT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| COVER ONCE | 10.7 | -666.3 | 0.0 | 332.7 | 8.7 | -544.1 | 0.0 | 284.0 |
| DENIED BY THE FIGHT | 0.7 | -8.6 | 27.7 | 63.0 | - | - | - | - |
| DEPLOY BY FIGURES | 8.7 | -71.5 | 0.0 | 0.0 | 8.7 | +28.7 | 0.0 | 101.0 |
| DUEL STOPS AT THE KILL | 0.3 | -19.9 | 0.0 | 93.7 | 0.3 | -22.9 | 0.0 | 0.0 |
| EDGE GIVE GROUND | 0.3 | +34.5 | 0.0 | 93.7 | - | - | - | - |
| EVASIVE BY THE ODDS | - | - | - | - | 0.3 | +2.5 | 25.7 | 0.0 |
| EXACT ROUND | 0.7 | -3.2 | 86.0 | 63.0 | 1.7 | +35.9 | 170.0 | 65.0 |
| FALL BACK GOOD ORDER | 1.3 | +15.1 | 113.7 | 156.7 | 2.0 | +0.1 | 43.3 | 65.0 |
| FALLBACK BY WORTH | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FALLS SHORT | - | - | - | - | 23.0 | +251.6 | 0.0 | 154.3 |
| FIGHT TO THE END | 0.3 | +3.9 | 0.0 | 93.7 | 1.0 | +23.1 | 0.0 | 65.0 |
| FIRE IN ORDER | 1.7 | +0.0 | 116.7 | 0.0 | - | - | - | - |
| FIVE ACTION | 112.3 | +6971.5 | 3618.0 | 1593.3 | 92.3 | +6992.8 | 544.0 | 1071.0 |
| FLANK NOT WEIGHED | 8.0 | +0.0 | 0.0 | 126.7 | 7.7 | +0.0 | 0.0 | 362.0 |
| FOLLOW UP WEIGHED | 0.7 | +243.8 | 0.0 | 0.0 | 2.0 | +301.3 | 0.0 | 0.0 |
| FOUR ROUNDS | 1.7 | +251.1 | 113.7 | 283.3 | 2.3 | +292.8 | 170.0 | 65.0 |
| FREED FROM HIS FIGHT | 2.0 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| FRIEND CHARGES FIRST | - | - | - | - | 0.3 | -38.1 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 0.7 | -53.3 | 0.0 | 0.0 | 0.3 | -7.1 | 0.0 | 0.0 |
| GIVES UP | - | - | - | - | 0.7 | -16.4 | 0.0 | 65.0 |
| GOAL WALK | 7.0 | +532.4 | 0.0 | 0.0 | 13.7 | +1317.8 | 0.0 | 78.3 |
| GROUND FLIERS | 0.3 | +2.3 | 0.0 | 0.0 | - | - | - | - |
| GUN FIGURES | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| GUN MASK | 2.0 | +95.3 | 0.0 | 0.0 | - | - | - | - |
| HARD STAY DROPPED | 3.0 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 2.0 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| HELPER UNSEEN | 0.3 | +0.0 | 0.0 | 126.7 | - | - | - | - |
| HIS CHARGE BY HIS RUN | 13.0 | +0.0 | 0.0 | 665.3 | 14.0 | +0.0 | 0.0 | 308.3 |
| HIS CHARGE LIST | 4.0 | +0.0 | 0.0 | 0.0 | 5.3 | +0.0 | 0.0 | 90.7 |
| HIS LEGAL MOVES | 4.0 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 1.0 | -6.8 | 0.0 | 253.3 | 2.0 | -36.4 | 0.0 | 6.3 |
| HIS ONE QUARTER | 7.0 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 78.0 |
| HIS OWN BEST MOVE | 6.7 | +0.0 | 0.0 | 0.0 | 4.7 | +0.0 | 0.0 | 27.7 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 46.0 | +1842.5 | 0.0 | 546.7 | 61.7 | +3807.9 | 0.0 | 704.3 |
| HIS SHOTS BY HIS RUN | 32.7 | +927.2 | 0.0 | 716.7 | 48.3 | +1978.1 | 0.0 | 692.7 |
| HIS TURN DENIED | 0.7 | +26.3 | 27.7 | 63.0 | 0.3 | +2.5 | 0.0 | 0.0 |
| HIS TURN RUN | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 19.0 | +0.0 | 0.0 | 158.7 | 22.0 | +0.0 | 0.0 | 244.0 |
| HOLDER ASSIGNMENT | 13.7 | +1296.1 | 0.0 | 105.0 | 15.0 | +1339.0 | 0.0 | 158.0 |
| HOLDS AMBUSHERS | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 1.3 | -48.4 | 113.7 | 156.7 | 1.7 | -82.2 | 43.3 | 65.0 |
| HUNT IN PAIRS | - | - | - | - | 1.0 | +61.9 | 0.0 | 0.0 |
| IDLE COST | - | - | - | - | 13.7 | -219.0 | 0.0 | 129.3 |
| JOINT CHARGE NOW | - | - | - | - | 0.3 | -9.1 | 0.0 | 0.0 |
| KEPT FROM ITS LAST STOP | 6.3 | +0.0 | 0.0 | 158.7 | 1.3 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 0.3 | +17.2 | 0.0 | 0.0 | 1.3 | +85.6 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | 1.3 | +0.0 | 0.0 | 158.7 | - | - | - | - |
| LEGAL CHARGES ONLY | 4.3 | +0.0 | 346.0 | 151.3 | 10.7 | +0.0 | 615.7 | 179.3 |
| LONE WIZARD KEPT IN | 0.3 | +19.8 | 0.0 | 0.0 | 0.3 | +37.5 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | 1.3 | -1.9 | 113.7 | 189.7 | 0.7 | +2.8 | 0.0 | 65.0 |
| MAKE SURE TOGETHER | 0.3 | +1.3 | 0.0 | 0.0 | - | - | - | - |
| MANOEUVRE | 0.7 | +0.0 | 0.0 | 0.0 | 1.3 | -9.6 | 0.0 | 0.0 |
| MARCH AT ESCAPER | - | - | - | - | 0.3 | +4.3 | 0.0 | 36.0 |
| MARCH BY THE SUM | 0.3 | +12.3 | 0.0 | 0.0 | 0.3 | +1.5 | 0.0 | 86.0 |
| MARCH CHECK | - | - | - | - | 1.0 | +38.2 | 0.0 | 36.0 |
| MARCH OF THE TABLE | 0.7 | +22.3 | 0.0 | 126.7 | - | - | - | - |
| MARCH OVER CASTS | 0.3 | -71.7 | 0.0 | 126.7 | 1.0 | +5.8 | 0.0 | 200.0 |
| MARCH WHEELS ONLY | 2.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MAX FOR POSITIONING | 2.3 | +96.2 | 0.0 | 380.0 | 1.3 | +16.6 | 0.0 | 6.3 |
| MEETS IN TIME | 4.3 | +404.6 | 0.0 | 0.0 | 4.0 | +319.6 | 0.0 | 36.0 |
| MISSILES IN THE MOVE | 2.0 | +205.1 | 0.0 | 253.3 | 2.3 | +40.9 | 0.0 | 156.0 |
| MISSILES NEXT TURN | 2.7 | +131.4 | 0.0 | 380.0 | 3.7 | +41.4 | 0.0 | 278.0 |
| MOVE ORDER | 3.3 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 86.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 4.0 | +424.6 | 0.0 | 0.0 | 3.3 | +318.1 | 0.0 | 27.7 |
| NEARER NOT NEEDED | 6.7 | +300.9 | 0.0 | 79.3 | 10.3 | +531.9 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 2.3 | +151.6 | 0.0 | 0.0 | 2.7 | +311.1 | 0.0 | 27.7 |
| NEXT OBJECTIVE NEARER | - | - | - | - | 0.7 | -4.5 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 1.7 | -104.6 | 113.7 | 283.3 | 2.0 | -167.9 | 170.0 | 65.0 |
| NO LATE CUT | 1.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 1.3 | -0.6 | 0.0 | 281.7 | - | - | - | - |
| OFF BEST | 6.0 | -221.1 | 0.0 | 239.0 | 6.0 | -274.4 | 0.0 | 6.3 |
| ONE FIGHT FORMULA | 4.7 | -135.9 | 0.0 | 380.0 | 2.3 | -71.7 | 0.0 | 27.7 |
| ONE JOINT FIGURE | - | - | - | - | 0.3 | +144.8 | 0.0 | 0.0 |
| ONE OBJECTIVE FORMULA | 3.7 | -68.6 | 0.0 | 0.0 | 6.3 | +47.3 | 0.0 | 122.0 |
| ONE PROMISE A TARGET | 0.7 | -101.9 | 0.0 | 0.0 | - | - | - | - |
| ONE ROUTE | 2.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| OVERRUNS AWAY | 0.7 | +14.2 | 86.0 | 93.7 | 0.7 | +28.9 | 126.7 | 0.0 |
| PLAN RESULT | 52.3 | +1488.2 | 663.0 | 1318.3 | 41.7 | +310.7 | 103.3 | 837.0 |
| PROMISE BELOW ZERO | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE BY ITS OWN SUM | 3.3 | -25.8 | 0.0 | 0.0 | 7.3 | -215.6 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | 0.7 | -53.3 | 0.0 | 0.0 | 0.3 | -7.1 | 0.0 | 0.0 |
| PROMISE SHOT AWAY | - | - | - | - | 0.7 | -0.3 | 0.0 | 0.0 |
| QUARTER ODDS | 31.3 | +2163.9 | 1664.0 | 553.3 | 20.7 | +2668.1 | 43.3 | 451.3 |
| REAL GROUND | 2.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| REDIRECT BY WHAT IT STOPS | - | - | - | - | 0.7 | +67.7 | 0.0 | 12.7 |
| REDIRECT COUNTER | - | - | - | - | 1.3 | +40.5 | 0.0 | 19.0 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 3.3 | +98.9 | 0.0 | 31.7 |
| REDIRECT WEIGHED | - | - | - | - | 0.7 | +5.7 | 0.0 | 0.0 |
| REFORMS TO MEET IT | - | - | - | - | 0.7 | -13.4 | 0.0 | 0.0 |
| RESERVE FALL BACK | - | - | - | - | 0.3 | +12.2 | 0.0 | 0.0 |
| RISK BY ARC | 1.3 | +23.5 | 113.7 | 156.7 | 1.7 | -221.8 | 126.7 | 65.0 |
| RISK ON THE WAY | 2.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ROUNDS AFTER TERROR | - | - | - | - | 1.0 | -21.6 | 43.3 | 65.0 |
| RUN DOWN | 1.3 | -10.1 | 113.7 | 156.7 | 1.3 | -11.4 | 170.0 | 65.0 |
| SCOUT SPOT | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +1.8 | 0.0 | 0.0 |
| SCOUT WAITS | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| SEARCH SPOT | 0.7 | +7.8 | 0.0 | 0.0 | 0.7 | -37.9 | 0.0 | 0.0 |
| SET CREDITED ONCE | - | - | - | - | 2.3 | -302.7 | 0.0 | 0.0 |
| SET UP BY THE SET | 1.3 | +59.1 | 0.0 | 0.0 | 3.0 | +106.2 | 0.0 | 0.0 |
| SET UP TOGETHER | 0.3 | +1.3 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | - | - | - | - | 0.7 | +3.0 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 26.0 | +0.0 | 0.0 | 285.0 | 4.7 | +0.0 | 0.0 | 68.0 |
| SHOOTS FROM THE BEST SPOT | 1.3 | +29.9 | 156.0 | 0.0 | 1.3 | +23.1 | 0.0 | 123.3 |
| SHORT GUN FORWARD | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SHOT OR CHARGE | - | - | - | - | 0.7 | -2.5 | 0.0 | 0.0 |
| SHOT RISK POINTS | 26.7 | +14.6 | 0.0 | 412.0 | 40.3 | +713.7 | 0.0 | 676.7 |
| SHOTS AFTER THE MOVES | 5.7 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 24.3 | +1057.4 | 0.0 | 154.0 | 17.7 | +367.6 | 0.0 | 61.7 |
| SPELL WORTH | 0.3 | +3.1 | 28.3 | 28.3 | 3.7 | +59.0 | 86.0 | 156.0 |
| SPELLS IN THE FIGHT | - | - | - | - | 0.3 | -3.2 | 126.7 | 0.0 |
| SPOT AS THE GAME MOVES | 5.7 | +0.0 | 0.0 | 0.0 | 6.7 | +0.0 | 0.0 | 234.0 |
| STAND AND SHOOT | 1.0 | -24.4 | 113.7 | 93.7 | - | - | - | - |
| STANDS FOR A REASON | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 63.7 | +0.0 | 3504.3 | 593.3 | 22.3 | +0.0 | 374.0 | 151.0 |
| STAY WORTH | 51.7 | +445.0 | 2430.0 | 534.0 | 18.0 | +162.5 | 247.3 | 36.0 |
| STRIKE BY THE ODDS | - | - | - | - | 1.0 | +25.8 | 28.3 | 195.0 |
| SUPPORT ADDS | 4.0 | +198.5 | 0.0 | 0.0 | 4.0 | +713.7 | 0.0 | 98.7 |
| SUPPORT NARROWED | 0.3 | +0.0 | 0.0 | 93.7 | - | - | - | - |
| SUPPORT WORKED OUT | 4.0 | +198.5 | 0.0 | 0.0 | 4.0 | +713.7 | 0.0 | 98.7 |
| SURE REACH TOGETHER | 1.3 | +27.5 | 0.0 | 0.0 | 0.3 | +0.7 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 2.3 | +0.0 | 0.0 | 25.7 | 3.0 | +0.0 | 0.0 | 36.0 |
| THE PROMISE ADDS | 0.3 | -0.6 | 0.0 | 0.0 | - | - | - | - |
| THE ROW IN ITS ORDER | 4.3 | +0.0 | 0.0 | 0.0 | 4.7 | +0.0 | 0.0 | 242.0 |
| THE ROW KEEPS ITS WAY | 2.7 | +0.0 | 0.0 | 79.3 | 4.0 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 2.0 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 55.3 | +0.0 | 0.0 | 643.3 | 44.7 | +0.0 | 0.0 | 509.3 |
| TIED UP BY THE SUM | 0.3 | +19.4 | 27.7 | 0.0 | - | - | - | - |
| TIME ON OUR SIDE | 44.3 | +473.3 | 0.0 | 347.7 | - | - | - | - |
| WAITS AGAIN | 1.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| WEAPON BY POINTS | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WHO FIGHTS | - | - | - | - | 0.3 | +26.2 | 0.0 | 65.0 |
| WHO HITS BACK | 0.3 | +74.1 | 0.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT DANGER | 2.7 | -439.0 | 0.0 | 253.3 | 2.3 | -201.7 | 0.0 | 144.3 |
| WHOLE FIGHT GAIN | - | - | - | - | 0.3 | +9.1 | 0.0 | 0.0 |
| WOUNDS ON THE RANKS | 7.3 | +216.0 | 0.0 | 158.7 | 2.0 | +102.6 | 0.0 | 72.0 |

### Rule changes: cora-bb45c30-p29

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 140 | 140 | 95 | 31.67 | +2074 | +21.8 |
| HIS SHOT LIST | 323 | 317 | 83 | 27.67 | +2735 | +33.0 |
| HOLDER ASSIGNMENT | 86 | 86 | 75 | 25.00 | +4111 | +54.8 |
| LEGAL CHARGES ONLY | 45 | 45 | 45 | 15.00 | +0 | +0.0 |
| HIS SHOTS BY HIS RUN | 243 | 237 | 42 | 14.00 | +846 | +20.1 |
| SHOT RISK POINTS | 201 | 195 | 40 | 13.33 | +1680 | +42.0 |
| OFF BEST | 36 | 36 | 36 | 12.00 | -1487 | -41.3 |
| DEPLOY BY FIGURES | 52 | 52 | 33 | 11.00 | +478 | +14.5 |
| FIVE ACTION | 614 | 606 | 30 | 10.00 | +2134 | +71.2 |
| TIME ON OUR SIDE | 133 | 112 | 25 | 8.33 | +90 | +3.6 |
| THE TABLE AGAIN | 36 | 36 | 23 | 7.67 | +0 | +0.0 |
| MOVE ORDER | 19 | 19 | 19 | 6.33 | +0 | +0.0 |
| QUARTER ODDS | 156 | 154 | 16 | 5.33 | +1563 | +97.7 |
| HARD STAY DROPPED | 14 | 14 | 14 | 4.67 | +0 | +0.0 |
| MOVE TO CHARGE COMPUTED | 22 | 22 | 14 | 4.67 | +919 | +65.6 |
| ARTILLERY RE-ROLL WEIGHED | 13 | 13 | 13 | 4.33 | +0 | +0.0 |
| CHARGE LOSSES | 119 | 119 | 13 | 4.33 | +482 | +37.0 |
| GOAL WALK | 62 | 62 | 12 | 4.00 | +488 | +40.7 |
| NEXT CHARGE BY LIST | 15 | 15 | 10 | 3.33 | +235 | +23.5 |
| REDIRECT FOR A FRIEND IN REACH | 10 | 10 | 10 | 3.33 | +245 | +24.5 |
| MEETS IN TIME | 25 | 25 | 9 | 3.00 | +266 | +29.5 |
| WOUNDS ON THE RANKS | 28 | 28 | 9 | 3.00 | +122 | +13.6 |
| COVER ONCE | 58 | 40 | 8 | 2.67 | +348 | +43.5 |
| FOLLOW UP WEIGHED | 8 | 8 | 8 | 2.67 | +1635 | +204.4 |
| PROMISE BY ITS OWN SUM | 32 | 32 | 8 | 2.67 | -724 | -90.5 |
| SUPPORT ADDS | 24 | 22 | 8 | 2.67 | +555 | +69.3 |
| SUPPORT WORKED OUT | 24 | 22 | 8 | 2.67 | +555 | +69.3 |
| ADVANCE LANE KEPT | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| FOUR ROUNDS | 12 | 12 | 6 | 2.00 | +710 | +118.4 |
| STAY WORTH | 209 | 193 | 6 | 2.00 | +10 | +1.7 |
| CANNON SIGHT KEPT | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| FIRE IN ORDER | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| LANE BY FIGURES | 5 | 5 | 5 | 1.67 | +308 | +61.7 |
| SET UP BY THE SET | 13 | 13 | 5 | 1.67 | +206 | +41.3 |
| SHOOTS FROM THE BEST SPOT | 8 | 8 | 5 | 1.67 | +17 | +3.4 |
| CANNON PLANNED TARGET | 41 | 41 | 4 | 1.33 | +0 | +0.0 |
| CAST JOB | 6 | 6 | 4 | 1.33 | +252 | +63.1 |
| SCOUT WAITS | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| IDLE COST | 41 | 27 | 3 | 1.00 | +27 | +9.1 |
| MISSILES IN THE MOVE | 13 | 11 | 3 | 1.00 | +104 | +34.6 |
| SEARCH SPOT | 4 | 4 | 3 | 1.00 | +60 | +19.9 |
| SHOTS AFTER THE MOVES | 25 | 25 | 3 | 1.00 | +0 | +0.0 |
| STRIKE BY THE ODDS | 3 | 3 | 3 | 1.00 | +77 | +25.8 |
| SURE REACH TOGETHER | 5 | 5 | 3 | 1.00 | +28 | +9.4 |
| THE ROW IN ITS ORDER | 27 | 3 | 3 | 1.00 | +0 | +0.0 |
| LONE WIZARD KEPT IN | 2 | 2 | 2 | 0.67 | +172 | +86.0 |
| MANOEUVRE | 6 | 6 | 2 | 0.67 | +29 | +14.6 |
| MARCH BY THE SUM | 2 | 2 | 2 | 0.67 | +42 | +20.8 |
| MARCH CHECK | 3 | 3 | 2 | 0.67 | +73 | +36.4 |
| MARCH OF THE TABLE | 2 | 2 | 2 | 0.67 | -67 | -33.5 |
| MAX FOR POSITIONING | 11 | 10 | 2 | 0.67 | +44 | +22.0 |
| NEARER NOT NEEDED | 51 | 50 | 2 | 0.67 | +65 | +32.5 |
| ONE OBJECTIVE FORMULA | 30 | 24 | 2 | 0.67 | +163 | +81.6 |
| ONE PROMISE A TARGET | 2 | 2 | 2 | 0.67 | -306 | -152.9 |
| OVERRUNS AWAY | 4 | 4 | 2 | 0.67 | +68 | +34.0 |
| PROMISE SHOT AWAY | 2 | 2 | 2 | 0.67 | -1 | -0.4 |
| REDIRECT COUNTER | 4 | 2 | 2 | 0.67 | +103 | +51.6 |
| REDIRECT WEIGHED | 2 | 2 | 2 | 0.67 | +24 | +11.9 |
| SHOOTERS IN TWO RANKS | 2 | 2 | 2 | 0.67 | +9 | +4.5 |
| AFTERMATH IN POINTS | 1 | 1 | 1 | 0.33 | +485 | +485.2 |
| BEST PRIZE | 1 | 1 | 1 | 0.33 | -37 | -37.3 |
| CASTER AWAY FROM SCREEN | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CHARGE NOT DECLARED | 1 | 1 | 1 | 0.33 | -122 | -122.2 |
| CHARGE NOW FIRST | 6 | 6 | 1 | 0.33 | -33 | -33.3 |
| COMBAT PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| EDGE GIVE GROUND | 1 | 1 | 1 | 0.33 | +32 | +32.2 |
| GUN MASK | 6 | 6 | 1 | 0.33 | +44 | +44.0 |
| HIS TURN DENIED | 3 | 3 | 1 | 0.33 | +11 | +10.7 |
| HOLDS AMBUSHERS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| JOINT CHARGE NOW | 1 | 1 | 1 | 0.33 | -27 | -27.4 |
| MISSILES NEXT TURN | 19 | 14 | 1 | 0.33 | +0 | +0.0 |
| ONE FIGHT FORMULA | 21 | 14 | 1 | 0.33 | +21 | +20.9 |
| ONE JOINT FIGURE | 1 | 1 | 1 | 0.33 | +60 | +59.7 |
| RESERVE FALL BACK | 1 | 1 | 1 | 0.33 | +37 | +36.7 |
| RISK BY ARC | 9 | 9 | 1 | 0.33 | +11 | +10.7 |
| SHORT GUN FORWARD | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| SHOTS IN THE MOVE | 126 | 94 | 1 | 0.33 | +157 | +156.8 |
| TIED UP BY THE SUM | 1 | 1 | 1 | 0.33 | +11 | +10.7 |
| WEAPON BY POINTS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| WHO HITS BACK | 1 | 1 | 1 | 0.33 | +222 | +222.3 |
| WHOLE FIGHT DANGER | 15 | 15 | 1 | 0.33 | +5 | +4.7 |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 7 | 7 | 0 | 0.00 | - | - |
| CHARACTER GUNS | 16 | 14 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 77 | 76 | 0 | 0.00 | - | - |
| DENIED BY THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 2 | 2 | 0 | 0.00 | - | - |
| EVASIVE BY THE ODDS | 1 | 1 | 0 | 0.00 | - | - |
| EXACT ROUND | 7 | 7 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 10 | 10 | 0 | 0.00 | - | - |
| FALLBACK BY WORTH | 2 | 2 | 0 | 0.00 | - | - |
| FALLS SHORT | 69 | 66 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 4 | 4 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 47 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 16 | 16 | 0 | 0.00 | - | - |
| FRIEND CHARGES FIRST | 1 | 1 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 3 | 3 | 0 | 0.00 | - | - |
| GIVES UP | 2 | 2 | 0 | 0.00 | - | - |
| GROUND FLIERS | 1 | not checked | - | - | - | - |
| GUN FIGURES | 2 | not checked | - | - | - | - |
| HE REFORMS ONCE FREED | 12 | 12 | 0 | 0.00 | - | - |
| HELPER UNSEEN | 1 | 1 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 81 | 81 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 28 | 28 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 22 | 22 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 9 | 9 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 33 | 32 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 34 | 34 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN RUN | 18 | 18 | 0 | 0.00 | - | - |
| HOLD ODDS | 123 | 123 | 0 | 0.00 | - | - |
| HONEST WORTH | 9 | 9 | 0 | 0.00 | - | - |
| HUNT IN PAIRS | 3 | 2 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 23 | 23 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 4 | 4 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 6 | 6 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 1 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 4 | 4 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 6 | 6 | 0 | 0.00 | - | - |
| NEXT OBJECTIVE NEARER | 2 | 2 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 11 | 11 | 0 | 0.00 | - | - |
| NO LATE CUT | 5 | 5 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT TURNED | 1 | 1 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 4 | not checked | - | - | - | - |
| ONE ROUTE | 6 | 6 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 18 | 18 | 0 | 0.00 | - | - |
| PLAN RESULT | 282 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE KNOWS THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| PROMISE READS THE TABLE | 3 | 3 | 0 | 0.00 | - | - |
| REAL GROUND | 6 | 6 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 2 | 2 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 2 | 2 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 6 | 6 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 3 | 3 | 0 | 0.00 | - | - |
| RUN DOWN | 8 | 8 | 0 | 0.00 | - | - |
| SCOUT SPOT | 4 | 4 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 7 | 7 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 1 | 1 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 92 | not checked | - | - | - | - |
| SHOT OR CHARGE | 2 | 2 | 0 | 0.00 | - | - |
| SPELL WORTH | 12 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 37 | 36 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 3 | 3 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 18 | 18 | 0 | 0.00 | - | - |
| STANDS STILL | 258 | 255 | 0 | 0.00 | - | - |
| SUPPORT NARROWED | 1 | 1 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 16 | not checked | - | - | - | - |
| THE PROMISE ADDS | 1 | 1 | 0 | 0.00 | - | - |
| THE ROW KEEPS ITS WAY | 20 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 15 | not checked | - | - | - | - |
| THE TABLE BINDS | 300 | not checked | - | - | - | - |
| WAITS AGAIN | 9 | 9 | 0 | 0.00 | - | - |
| WHO FIGHTS | 1 | 1 | 0 | 0.00 | - | - |
| WHOLE FIGHT GAIN | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: cora-bb45c30-p29

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 5.67 | 5.33 | 39.6 |
| ARMY TABLE | rule | 2.00 | 3.67 | 89.9 |
| PROMISE BY ITS OWN SUM | rule | 0.67 | 2.00 | 90.5 |
| HOLDER ASSIGNMENT | rule | 1.00 | 1.33 | 25.9 |
| MARCH OF THE TABLE | rule | 0.67 | - | 33.5 |
| ONE PROMISE A TARGET | rule | 0.67 | - | 152.9 |
| RULE SWITCHED OFF | gate | - | 0.67 | 17.1 |
| BEST PRIZE | rule | - | 0.33 | 37.3 |
| CHARGE NOT DECLARED | rule | - | 0.33 | 122.2 |
| CHARGE NOW FIRST | rule | 0.33 | - | 33.3 |
| JOINT CHARGE NOW | rule | - | 0.33 | 27.4 |
| NO REASON | gate | 0.33 | - | 144.6 |
| PROMISE SHOT AWAY | rule | - | 0.33 | 0.6 |
| SET UP BY THE SET | rule | - | 0.33 | 12.7 |

### Plans: cora-bb45c30-p29

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.3 | 50% | 165 | 64 | 39% |
| Mine | join | 3.3 | 90% | 44 | 0 | 0% |
| Mine | move | 30.0 | 96% | 1586 | 0 | 0% |
| Mine | shoot | 17.7 | 70% | 1517 | 1424 | 94% |
| Opponent | charge | 1.7 | 40% | 133 | 166 | 125% |
| Opponent | join | 0.3 | 100% | 3 | 0 | 0% |
| Opponent | move | 36.0 | 94% | 2669 | 0 | 0% |
| Opponent | shoot | 3.3 | 60% | 264 | 145 | 55% |
| Opponent | support | 0.3 | 100% | 58 | 0 | 0% |

### Battle groups: cora-bb45c30-p29

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | REDIRECT COUNTER | 1.3 | 0% | - | - | - | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: cora-bb45c30-p29

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | - | 0 (1) | 0 (1) | - |
| Mine | Character | 12 | 16 (12) | 16 | 0 | 59 | 67% | 2.2 | 12 (7) | 0 (2) | 56 (2) | 29 (6) | 0 (5) |
| Mine | Clean-up | 1 | 55 (1) | 0 | 55 | 0 | 100% | - | - | 55 (1) | - | 55 (1) | - |
| Mine | Fast Hammer | 8 | 58 (8) | 35 | 23 | 28 | 50% | 3.5 | 77 (4) | 17 (3) | 76 (1) | 99 (4) | 11 (4) |
| Mine | Hammer | 2 | 42 (2) | 0 | 42 | 42 | 0% | 1.5 | - | 0 (1) | 73 (1) | 42 (2) | - |
| Mine | Shooter | 5 | 108 (5) | 0 | 108 | 16 | 0% | 1.6 | 117 (2) | 165 (1) | 39 (2) | 142 (3) | 39 (2) |
| Mine | War machine | 10 | 75 (10) | 75 | 0 | 20 | 0% | 1.6 | 27 (8) | 270 (2) | - | 0 (1) | 84 (9) |
| Mine | Wizard | 1 | 0 (1) | 0 | 0 | 100 | 0% | 2.0 | - | - | - | - | - |
| Opponent | Chaff | 4 | 0 (4) | 0 | 0 | 22 | 50% | 1.0 | 0 (3) | 0 (1) | - | 0 (4) | - |
| Opponent | Character | 9 | 32 (9) | 32 | 0 | 14 | 33% | 2.0 | 47 (1) | 52 (5) | 0 (3) | 41 (5) | 18 (4) |
| Opponent | Clean-up | 3 | 0 (3) | 0 | 0 | 0 | 100% | - | 0 (2) | 0 (1) | - | 0 (1) | 0 (2) |
| Opponent | Fast Hammer | 5 | 11 (5) | 11 | 0 | 87 | 60% | 3.0 | 44 (1) | 0 (2) | 0 (2) | 17 (3) | 0 (2) |
| Opponent | Fragile | 3 | 0 (3) | 0 | 0 | 0 | 0% | 5.0 | 0 (3) | - | - | - | 0 (3) |
| Opponent | Hammer | 3 | 0 (3) | 0 | 0 | 61 | 33% | 1.0 | - | 0 (1) | 0 (2) | - | 0 (3) |
| Opponent | Holder | 3 | 227 (3) | 23 | 203 | 0 | 0% | 1.7 | 150 (1) | 261 (2) | - | 362 (2) | 0 (1) |
| Opponent | Shooter | 7 | 143 (7) | 62 | 81 | 34 | 0% | 1.1 | 326 (2) | 125 (3) | 32 (2) | 191 (3) | 88 (4) |
| Opponent | Wizard | 1 | 0 (1) | 0 | 0 | 0 | 0% | 1.0 | - | - | 0 (1) | - | 0 (1) |

### Charged fights: cora-bb45c30-p29

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Empire of Man | 3 | 417 | 114 | 1.7 | 1.0 | 68 | 129 | -61 | 1 of 5 | 3 of 5 | - | -61 |
| Opponent | Lizardmen | 1 | 380 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Tomb Kings of Khemri | 1 | 45 | 480 | 4.0 | 1.0 | 120 | 49 | +71 | 3 of 4 | 2 of 4 | - | +71 |
| Opponent | Wood Elf Realms | 1 | 519 | 0 | 2.0 | 1.0 | 0 | 0 | +0 | 1 of 2 | 2 of 2 | - | +0 |
| **Opponent** | all armies | 3 | 315 | 160 | 2.0 | 1.0 | 80 | 32 | +48 | 4 of 6 | 4 of 6 | - | +48 |

### Effective charges: cora-bb45c30-p29

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Empire of Man | 5 | 1 (net -457) | 1 (net +258) | 1 (net +0) | 0 | 0 | 2 (net -53) | 0 | 20% (1 of 5) |
| Opponent | Tomb Kings of Khemri | 4 | 2 (net -55) | 0 | 0 | 0 | 0 | 1 (net +265) | 1 | 0% (0 of 3) |

### Charged fights, damage counted: cora-bb45c30-p29

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 1 | 380 | 0 | -457 | 81 | 457 | -376 | -98.9 |
| Mine | 50-54% | 1 | 189 | 208 | +258 | 258 | 0 | +258 | +136.5 |
| Mine | Effective (55-75%) | 1 | 181 | 236 | +0 | 51 | 258 | -208 | -114.7 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 189 | 109 | -53 | 103 | 102 | +1 | +0.8 |
| Mine | All fights | 5 | 226 | 132 | -61 | 119 | 184 | -65 | -28.6 |
| Opponent | Long shot (under 50%) | 2 | 318 | 371 | -55 | 105 | 98 | +7 | +2.3 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 431 | 265 | +265 | 310 | 22 | +288 | +66.8 |
| Opponent | No odds | 3 | 144 | 143 | +43 | 50 | 0 | +50 | +34.9 |
| Opponent | All fights | 6 | 250 | 240 | +48 | 112 | 36 | +75 | +30.3 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| cora-bb45c30-p29 | move | 16 | 2 (12%) | 2 (12%) | 2 (12%) | 12 (75%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Horn of the Wild Hunt | Opponent | L0733 |
| Ring of Doom | Opponent | L0733 |
| Twice-Blessed Armour | Mine | L0717, L0733 |
| Witch Hunter's Ward | Mine | L0717, L0733, L0823 |

# Doctrine scorecard: cora-bb45c30-p10

### Scorecard: cora-bb45c30-p10

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L1823 | 5 | 1 | Mine | no | - | - | 3 | 1 | 0 | 0 | 0 | 0 |
| L1823 | 5 | 1 | Opponent | yes | - | 1 | 5 | 2 | 0 | 0 | 0 | 130 |
| L1923 | 3 | 1 | Mine | no | 0 | 1 | 6 | 0 | 1 | 0 | 0 | 255 |
| L1923 | 3 | 1 | Opponent | yes | 6 | 2 | 4 | 1 | 0 | 0 | 0 | 257 |
| L2025 | 3 | 1 | Mine | yes | 3 | - | 1 | 1 | 0 | 0 | 0 | 420 |
| L2025 | 3 | 1 | Opponent | no | 2 | 2 | 5 | 2 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 33% | 1.5 | 1.0 | 3.3 | 0.7 | 0.3 | 0.0 | 0.0 | 225.0 |
| **Average** | | | Opponent | 67% | 4.0 | 1.7 | 4.7 | 1.7 | 0.0 | 0.0 | 0.0 | 129.0 |

### KPIs: cora-bb45c30-p10

Rules off - Mine only: ONE RUN A PLAN.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 15) | 0% (0 of 15) | 0% (0 of 30) |
| Winner chose to follow up after the loser gave ground |  | 100% (10 of 10); on the table 100% | 100% (4 of 4); on the table 100% | 100% (14 of 14); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | - | 50% (1 of 2); on the table 100% | 50% (1 of 2); on the table 100% |
| Winner chose to pursue after the loser fled |  | - | 100% (3 of 3); on the table 100% | 100% (3 of 3); on the table 100% |
| Winner chose to follow up or pursue (all three) |  | 100% (10 of 10); on the table 100% | 89% (8 of 9); on the table 100% | 95% (18 of 19); on the table 100% |
| Magic missiles tried each own turn | 50%+ | 7% (2 of 30) | 39% (7 of 18) | 19% (9 of 48) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 17% (2 of 12) | 39% (7 of 18) | 30% (9 of 30) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 40% (2 of 5) | - | 40% (2 of 5) |
| Points that never fought | lower | 19% (1154 of 5999) | 25% (1501 of 5999) | 22% (2655 of 11998) |
|   infantry points that never fought | lower | 75% (741 of 993) | 64% (661 of 1037) | 69% (1402 of 2030) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 59% (13 of 22) | 38% (6 of 16) | 50% (19 of 38) |
| Bound items with a magic missile used (at least once a game) |  | 100% (1 of 1); 0.7 uses a game | 0.0 uses a game | 100% (1 of 1); 0.3 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 50% (1 of 2); 0.3 uses a game | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 65% (3343 of 5151) | 33% (1500 of 4500) | 50% (4843 of 9651) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 0.3 (4%) | 3.3 (91%) | 3.7 (28%) |
| MARCHED: its unit marched | 1.3 (14%) | 0.3 (9%) | 1.7 (13%) |
| CHARGED: its unit charged | 0.7 (7%) | 0.0 (0%) | 0.7 (5%) |
| IN COMBAT: engaged in combat | 3.3 (36%) | 0.0 (0%) | 3.3 (26%) |
| REAR RANK: in a rear rank | 0.3 (4%) | 0.0 (0%) | 0.3 (3%) |
| GONE: slain | 2.7 (29%) | 0.0 (0%) | 2.7 (21%) |
| NOT OFFERED: not in the cast list | 0.7 (7%) | 0.0 (0%) | 0.7 (5%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 4.7 | 1.3 | 1.7 | 3.0 | 1.3 |
| not cast | 5.3 | 0.7 | 4.3 | 13.0 | 18.7 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.3 (12%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.3 (50%) | 0.0 (0%) | 3.7 (28%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.7 (13%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (5%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 3.3 (26%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 1.0 (19%) | 0.0 (0%) | 1.0 (23%) | 0.3 (3%) | 0.0 (0%) |
| GONE: slain | 2.7 (50%) | 0.0 (0%) | 1.0 (23%) | 2.7 (21%) | 4.3 (23%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.3 (50%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (5%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.7 (31%) | 0.0 (0%) | 2.3 (54%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 12.0 (64%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.0 a game | 1.7 a game | 0.8 a game |
| stood (cast and not dispelled) | - | 40% (2 of 5) | 40% (2 of 5) |
| the unit moved after it | - | 100% (2 of 2) | 100% (2 of 2) |
| it charged on its next turn | - | 0% (0 of 2) | 0% (0 of 2) |
| the enemy charged it first | - | 0% (0 of 2) | 0% (0 of 2) |
| it fought by the end of its next turn | - | 0% (0 of 2) | 0% (0 of 2) |
| it moved out of a charge the enemy had planned (not charged first) | - | 0% (0 of 2) | 0% (0 of 2) |
| none of these (no charge, no fight, no charge escaped) | - | 100% (2 of 2) | 100% (2 of 2) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 52% (31 of 60) | 55% (34 of 62) | 53% (65 of 122) |
|   cavalry | - | 91% (10 of 11) | 91% (10 of 11) |
|   character | 100% (6 of 6) | 0% (0 of 15) | 29% (6 of 21) |
|   chariot | 50% (5 of 10) | - | 50% (5 of 10) |
|   infantry | 32% (11 of 34) | 67% (24 of 36) | 50% (35 of 70) |
|   monster | 90% (9 of 10) | - | 90% (9 of 10) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.3 (14%) | 0.0 (0%) | 1.3 (7%) |
| CHARGED: it charged | 0.3 (3%) | 1.7 (18%) | 2.0 (11%) |
| IN COMBAT: it fought this turn or the last | 0.0 (0%) | 1.7 (18%) | 1.7 (9%) |
| NO TARGET IN RANGE | 3.0 (31%) | 2.7 (29%) | 5.7 (30%) |
| ONLY IN COMBAT: the only targets were in combat | 0.0 (0%) | 2.3 (25%) | 2.3 (12%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 3.3 (34%) | 1.0 (11%) | 4.3 (23%) |
| SHELTERED: the target was sheltered | 0.3 (3%) | 0.0 (0%) | 0.3 (2%) |
| OTHER BAR | 1.3 (14%) | 0.0 (0%) | 1.3 (7%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 4.0 | 0.7 | 83% | 0.9 pts | 4 pts |
| character | 2.0 | 0.0 | 100% | 0.0 pts | 0 pts |
| chariot | 2.0 | 1.7 | 67% | 22.5 pts | 45 pts |
| infantry | 13.3 | 7.0 | 65% | 6.5 pts | 87 pts |
| monster | 3.0 | 0.7 | 89% | 7.2 pts | 22 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.0 | 8.3 | 6.2 |
| Charges that made contact a game | 3.0 | 6.0 | 4.5 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.00 declared, 0.00 contact (1 units) | 0.00 declared, 0.00 contact (2 units) | 0.00 declared, 0.00 contact (3 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 5.00 declared, 3.00 contact (1 units) | 5.00 declared, 3.00 contact (1 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.43 declared, 0.32 contact (28 units) | 0.67 declared, 0.50 contact (30 units) | 0.55 declared, 0.41 contact (58 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | - | 33% (1 of 3) | - | 33% (1 of 3) |
| Character in a unit | 100% (2 of 2) | 0% (0 of 1) | - | 67% (2 of 3) |
| Character on its own | 0% (0 of 3) | 100% (3 of 3) | 43% (3 of 7) | 46% (6 of 13) |
| Chariot | 50% (1 of 2) | - | - | 50% (1 of 2) |
| Infantry | 33% (2 of 6) | - | - | 33% (2 of 6) |
| Monster | 25% (1 of 4) | 67% (2 of 3) | - | 43% (3 of 7) |
| Monstrous | - | 100% (4 of 4) | - | 100% (4 of 4) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Ogre Kingdoms | 1 | 100% (2 of 2); on the table 100% | 0% (0 of 6) | 28% | 86% (6 of 7) | 100% (1 of 1); 2.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 1 | 100% (3 of 3); on the table 100% | 0% (0 of 12) | 0% | 50% (4 of 8) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Skaven | 1 | 100% (5 of 5); on the table 100% | 17% (2 of 12) | 29% | 43% (3 of 7) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Tomb Kings of Khemri | 2 | 80% (4 of 5); on the table 100% | 0% (0 of 6) | 24% | 20% (2 of 10) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 1 | 100% (4 of 4); on the table 100% | 58% (7 of 12) | 27% | 67% (4 of 6) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (cora-bb45c30-p10, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 60% (9) | 50% (1) | 59% (10) |
| ...free all their last turn and able to turn (per game) | 2.33 | 0.00 | 2.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.33 | 0.33 |
| ...with the charger already in that arc before they moved (per game) | 1.00 | 0.00 | 1.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: cora-bb45c30-p10

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.7 | 2.3 |
| Strategy | Charge objectives carried out (made contact) | 75% (3 of 4) | 45% (10 of 22) |
| Strategy | Shoot objectives carried out (shot that target) | 50% (8 of 16) | 44% (8 of 18) |
| Strategy | Support requests answered (helper made contact too) | - | 33% (1 of 3) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 80% (4 of 5) | - |
| Strategy | Hexes on a unit its side charged or shot that turn | - | 33% (1 of 3) |
| Strategy | Joined characters whose unit fought | 100% (2 of 2) | 33% (1 of 3) |
| Strategy | Lone characters that fought | 88% (7 of 8) | 88% (7 of 8) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 0.7 | 1.7 |
| Movement | Points that never moved of their own | 225.0 | 129.0 |
| Movement | Fights charged into per game | 2.7 | 5.0 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 3 | 3 of 12, net +263 |
| Movement | Charges with odds: sweet spot (55-75%) | 2 of 3, net +63 | 1 of 12, net +234 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 3 | 1 of 12, net +185 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 0 of 3 | 6 of 12, net +201 |
| Shooting | Shots by shooting units (incl. breath weapons) | 10.3 | 14.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 42% (13 of 31) | 11% (5 of 44) |
| Shooting | Points destroyed by shooting units | 15.0 | 59.3 |
| Shooting | Points destroyed by war machines | 23.3 | 0.0 |
| Magic | Magic missiles cast | 0.3 | 1.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 0% (0 of 1) | 0% (0 of 4) |
| Magic | Wounds caused by magic missiles | 1.3 | - |
| Magic | Points destroyed by magic (all spells) | 0.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 2.3 / 0.0 / 0.7 / 0.0 | 1.7 / 1.0 / 0.7 / 0.0 |
| Combat | Points destroyed in combat | 458.7 | 795.0 |
| Combat | Points run down | 0.0 | 448.7 |
| Combat | Net points per charged fight, damage counted | +6 | +189 |
| Combat | Net per 100 charger points, damage counted | +4.7 | +53.6 |
| Combat | First round won (charged fights) | 50% | 80% |
| Combat | Net points per charged fight | +9 | +186 |
| Combat | Net points per supported fight / lone fight | +126 / -8 | +368 / +140 |
| Combat | Charged fights on a top-3 enemy unit | 2 of 8 | 9 of 15 |
| Game | Points lost | 1317.0 | 463.7 |
| Game | VP from objectives | 263.3 | 950.0 |
| Game | Lone holders (player turns) | 1.5 | 4.0 |

- Mine won / drew / lost: 0 / 0 / 3 of 3 ended games (of 3); mean margin (Mine - Opponent) -1648 VP
- The side that went first won 2 of 3 games with a winner
- Points traded per game (both sides' losses): 1781
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: cora-bb45c30-p10

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| AFTERMATH WITH FRIENDS | - | - | - | - | 0.7 | +29.4 | 0.0 | 0.0 |
| ARMY TABLE | 23.7 | +313.0 | 0.0 | 725.7 | 14.3 | +45.7 | 0.0 | 85.0 |
| ASSAILMENT BY POINTS | 0.3 | +0.1 | 0.0 | 0.0 | - | - | - | - |
| BACKUP TARGETS | 0.3 | +2.2 | 0.0 | 0.0 | - | - | - | - |
| CAST JOB | - | - | - | - | 0.7 | +3.8 | 64.0 | 0.0 |
| CASTER AWAY FROM SCREEN | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 1.0 | +9.0 | 66.0 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| CHALLENGE BY POINTS | 0.7 | +103.2 | 0.0 | 0.0 | 0.7 | +4.9 | 0.0 | 0.0 |
| CHAMPION KNOWS CHALLENGE | - | - | - | - | 0.7 | -46.2 | 77.3 | 0.0 |
| CHARGE LOSSES | 19.0 | -1320.2 | 0.0 | 1516.0 | 8.0 | -300.1 | 0.0 | 65.0 |
| CHARGE NOW FIRST | 0.3 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 1025.3 | 196.7 |
| CLOSES ON WHAT IT BEATS | 6.3 | +0.0 | 0.0 | 235.7 | 16.3 | +0.0 | 0.0 | 270.7 |
| COMBAT PIVOT | 0.7 | +0.0 | 0.0 | 186.7 | 1.3 | +0.0 | 0.0 | 25.0 |
| CONTINUE AHEAD WEIGHED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | - | - | - | - | 1.3 | +116.5 | 0.0 | 0.0 |
| COVER ONCE | 12.7 | -565.1 | 0.0 | 507.7 | 2.7 | -118.6 | 0.0 | 20.0 |
| DENIED BY THE FIGHT | - | - | - | - | 1.3 | -7.2 | 190.0 | 0.0 |
| DEPLOY BY FIGURES | 7.7 | +43.1 | 0.0 | 0.0 | 7.3 | +33.6 | 0.0 | 23.3 |
| DUEL STOPS AT THE KILL | - | - | - | - | 1.3 | -541.8 | 129.7 | 180.0 |
| EDGE GIVE GROUND | - | - | - | - | 0.3 | +3.6 | 85.0 | 0.0 |
| EXACT ROUND | 0.7 | +2.3 | 22.0 | 11.3 | 5.3 | +6.8 | 1275.0 | 0.0 |
| FALL BACK GOOD ORDER | 1.0 | +0.0 | 22.0 | 24.7 | 5.7 | +0.4 | 1296.3 | 16.7 |
| FALLS SHORT | 3.3 | +27.5 | 0.0 | 272.7 | 13.0 | +147.0 | 0.0 | 52.0 |
| FEATURE BUFFS | 1.0 | +4.3 | 0.0 | 0.0 | 0.7 | +6.9 | 0.0 | 44.0 |
| FIGHT TO THE END | - | - | - | - | 4.0 | +218.8 | 552.0 | 196.7 |
| FIRE IN ORDER | - | - | - | - | 0.3 | +0.0 | 18.3 | 0.0 |
| FIVE ACTION | 71.7 | +4248.6 | 170.0 | 2645.0 | 84.7 | +7394.4 | 2510.0 | 901.3 |
| FLANK NOT WEIGHED | 10.0 | +0.0 | 0.0 | 632.3 | 3.3 | +0.0 | 0.0 | 270.0 |
| FOLLOW UP WEIGHED | 1.3 | +90.0 | 0.0 | 0.0 | 1.3 | +167.1 | 0.0 | 0.0 |
| FOUR ROUNDS | 1.3 | +46.8 | 44.0 | 24.7 | 8.3 | +1061.6 | 1533.3 | 196.7 |
| FREED FROM HIS FIGHT | 6.3 | +0.0 | 0.0 | 36.7 | 4.7 | +0.0 | 0.0 | 25.0 |
| FRIEND SHOOTS FIRST | 1.3 | -8.7 | 0.0 | 0.0 | 1.0 | -4.0 | 11.3 | 0.0 |
| FRIENDS SHOTS CHECKED | - | - | - | - | 0.3 | +14.3 | 0.0 | 0.0 |
| GIVES UP | - | - | - | - | 1.0 | -16.4 | 25.7 | 0.0 |
| GOAL WALK | 9.7 | +643.9 | 0.0 | 254.7 | 6.3 | +380.2 | 0.0 | 50.0 |
| GUN FIGURES | 2.3 | +2.4 | 0.0 | 123.3 | - | - | - | - |
| HARD STAY DROPPED | 2.0 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 3.3 | +0.0 | 0.0 | 36.7 | 1.0 | +0.0 | 0.0 | 0.0 |
| HELPER UNSEEN | - | - | - | - | 0.3 | +0.0 | 11.7 | 0.0 |
| HIS CHARGE BY HIS RUN | 15.3 | +0.0 | 0.0 | 1314.7 | 3.3 | +0.0 | 0.0 | 65.0 |
| HIS CHARGE DENIED | - | - | - | - | 0.7 | +19.5 | 89.7 | 0.0 |
| HIS CHARGE LIST | 8.7 | +0.0 | 0.0 | 339.3 | 0.3 | +0.0 | 0.0 | 22.0 |
| HIS LEGAL MOVES | 4.3 | +0.0 | 0.0 | 143.0 | 4.3 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 3.0 | -34.7 | 0.0 | 121.0 | 4.7 | -88.3 | 0.0 | 60.0 |
| HIS ONE QUARTER | 6.7 | +0.0 | 0.0 | 453.3 | 5.0 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 6.7 | +0.0 | 0.0 | 143.0 | 9.0 | +0.0 | 0.0 | 95.0 |
| HIS RANDOM MOVE | - | - | - | - | 5.3 | +0.0 | 0.0 | 50.0 |
| HIS RANDOM MOVER COMES | - | - | - | - | 5.7 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 36.0 | +355.6 | 0.0 | 1672.3 | 26.7 | +568.7 | 0.0 | 279.0 |
| HIS SHOTS BY HIS RUN | 37.7 | +184.5 | 0.0 | 1864.7 | 25.7 | +507.6 | 0.0 | 431.3 |
| HIS TURN DENIED | 1.0 | +1.9 | 44.0 | 11.3 | 2.7 | +46.5 | 593.7 | 0.0 |
| HIS TURN RUN | 5.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HOLD ODDS | 9.3 | +0.0 | 0.0 | 131.3 | 13.7 | +0.0 | 0.0 | 382.0 |
| HOLDER ASSIGNMENT | 6.0 | +398.5 | 0.0 | 65.7 | 9.0 | +747.3 | 0.0 | 190.0 |
| HOLDS AMBUSHERS | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 1.0 | -2.4 | 44.0 | 11.3 | 7.0 | -321.8 | 1159.7 | 180.0 |
| HUNT IN PAIRS | - | - | - | - | 3.3 | +56.9 | 0.0 | 226.7 |
| IDLE COST | 2.3 | -15.1 | 0.0 | 187.0 | 9.3 | -136.5 | 0.0 | 41.7 |
| JOINT CHARGE NOW | - | - | - | - | 2.0 | +60.7 | 517.0 | 180.0 |
| KEPT FROM ITS LAST STOP | - | - | - | - | 2.0 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 0.3 | +6.3 | 0.0 | 0.0 | 1.7 | +89.0 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 5.3 | +0.0 | 129.3 | 213.0 | 10.7 | +0.0 | 430.7 | 350.3 |
| LONE WIZARD KEPT IN | 0.3 | +16.1 | 0.0 | 0.0 | 0.7 | +39.2 | 0.0 | 0.0 |
| LONG SHOT | 1.0 | -1.8 | 30.0 | 13.3 | 0.7 | +4.8 | 180.0 | 16.7 |
| LOST AFTER ESCAPE | 0.7 | -0.3 | 22.0 | 11.3 | 5.7 | +11.9 | 676.3 | 196.7 |
| LOST CHARGE | - | - | - | - | 0.3 | -1.2 | 85.0 | 0.0 |
| MANOEUVRE | 1.0 | -0.2 | 0.0 | 64.0 | 1.7 | -0.7 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.3 | +1.4 | 0.0 | 0.0 | - | - | - | - |
| MARCH BY THE SUM | 0.7 | +42.7 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | 1.3 | +41.6 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 1.0 | +27.9 | 0.0 | 180.0 | 0.3 | -84.3 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 3.0 | +88.1 | 0.0 | 11.3 | 4.7 | +99.3 | 0.0 | 220.0 |
| MEETS IN TIME | 3.7 | +210.7 | 0.0 | 0.0 | 2.3 | +191.0 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 1.7 | +17.0 | 0.0 | 295.3 | 3.7 | +24.2 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 3.3 | +42.2 | 0.0 | 475.3 | 4.7 | +20.1 | 0.0 | 0.0 |
| MOVE ORDER | 1.7 | +0.0 | 127.3 | 180.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 4.7 | +298.2 | 0.0 | 78.0 | 11.0 | +890.0 | 0.0 | 95.0 |
| MOVES UNITS SPELL | 0.3 | +1.4 | 0.0 | 0.0 | - | - | - | - |
| NEARER NOT NEEDED | 6.7 | +257.5 | 0.0 | 217.0 | 10.3 | +361.1 | 0.0 | 106.0 |
| NEXT CHARGE BY LIST | 1.7 | +92.9 | 0.0 | 78.0 | 6.3 | +445.7 | 22.7 | 95.0 |
| NO DOUBLE ROUNDS | 1.0 | -18.5 | 44.0 | 11.3 | 7.7 | -411.9 | 1467.7 | 180.0 |
| NO LATE CUT | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 5.7 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 5.3 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 1.3 | -0.7 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 1.7 | -54.1 | 0.0 | 0.0 | 6.7 | -167.3 | 64.0 | 62.0 |
| ONE CHALLENGE TEST | - | - | - | - | 1.3 | +101.6 | 129.7 | 180.0 |
| ONE CHECK AFTER THE LAST CHANGE | 1.3 | +0.0 | 0.0 | 91.3 | - | - | - | - |
| ONE FIGHT FORMULA | 4.7 | -54.5 | 0.0 | 397.0 | 8.7 | -180.3 | 0.0 | 285.0 |
| ONE JOINT FIGURE | - | - | - | - | 1.0 | +101.0 | 180.0 | 196.7 |
| ONE OBJECTIVE FORMULA | 3.3 | -18.8 | 0.0 | 65.7 | 3.7 | +5.3 | 0.0 | 86.0 |
| ONE PROMISE A TARGET | - | - | - | - | 0.7 | -5.8 | 11.3 | 0.0 |
| ONE ROUTE | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| ONE RUN A PLAN | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS UP | - | - | - | - | 1.0 | +45.3 | 77.0 | 0.0 |
| OVERRUNS AWAY | 0.7 | +1.2 | 22.0 | 11.3 | 3.7 | +59.8 | 717.0 | 180.0 |
| PERIAPT WORTH | 0.3 | +18.1 | 0.0 | 0.0 | - | - | - | - |
| PLAN RESULT | 36.0 | +82.4 | 81.0 | 1749.7 | 42.3 | +1248.1 | 536.7 | 599.3 |
| PROMISE BELOW ZERO | 0.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| PROMISE BY ITS OWN SUM | 4.0 | -28.7 | 0.0 | 0.0 | 15.7 | -645.2 | 0.0 | 0.0 |
| PROMISE IN STEPS | - | - | - | - | 0.7 | +0.0 | 11.3 | 0.0 |
| PROMISE KNOWS THE FIGHT | - | - | - | - | 4.0 | -4.1 | 22.7 | 0.0 |
| PROMISE READS THE TABLE | 1.3 | -16.5 | 0.0 | 0.0 | 0.3 | -1.9 | 0.0 | 0.0 |
| PROMISE SHOT AWAY | - | - | - | - | 0.7 | -0.6 | 0.0 | 0.0 |
| PURSUES BIG PREY | - | - | - | - | 0.3 | -8.3 | 0.0 | 0.0 |
| QUARTER ODDS | 14.0 | +1537.6 | 0.0 | 609.3 | 21.7 | +3370.7 | 929.3 | 0.0 |
| RANDOM MOVE BY FIGURES | 1.7 | +25.1 | 0.0 | 70.0 | - | - | - | - |
| REAL GROUND | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | 2.7 | +194.5 | 0.0 | 62.7 | 2.7 | +69.5 | 0.0 | 91.0 |
| REDIRECT FOR A FRIEND IN REACH | 3.7 | +0.0 | 0.0 | 96.3 | 4.0 | +0.0 | 0.0 | 118.0 |
| REDIRECT WEIGHED | - | - | - | - | 0.3 | +17.5 | 100.3 | 0.0 |
| REFORMS TO MEET IT | 0.7 | -47.7 | 0.0 | 78.0 | 1.0 | -5.4 | 0.0 | 65.0 |
| REFUSING RETIRES | - | - | - | - | 0.3 | +0.0 | 0.0 | 20.0 |
| RESERVE FALL BACK | - | - | - | - | 0.7 | +19.5 | 0.0 | 22.0 |
| RISK BY ARC | 1.0 | +15.5 | 22.0 | 13.3 | 7.0 | -104.4 | 1341.3 | 196.7 |
| RISK ON THE WAY | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| ROUNDS AFTER TERROR | - | - | - | - | 6.3 | -197.3 | 783.7 | 196.7 |
| RUN DOWN | - | - | - | - | 6.3 | -57.4 | 923.3 | 16.7 |
| SCOUT SPOT | 0.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| SCOUT WAITS | 1.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| SEARCH SPOT | 0.7 | +1.2 | 0.0 | 0.0 | 1.3 | +75.2 | 0.0 | 22.0 |
| SECOND LOOK | - | - | - | - | 1.0 | +72.6 | 162.3 | 0.0 |
| SELF MOVE SPELL | 2.0 | -3.8 | 0.0 | 0.0 | - | - | - | - |
| SET CREDITED ONCE | - | - | - | - | 3.0 | -101.7 | 0.0 | 201.0 |
| SET UP BY THE SET | 0.3 | -9.8 | 0.0 | 0.0 | 3.0 | +41.0 | 0.0 | 201.0 |
| SHOOTERS IN TWO RANKS | - | - | - | - | 0.3 | +1.7 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 4.7 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 2.7 | +72.0 | 30.0 | 51.3 | 3.3 | +92.6 | 256.7 | 0.0 |
| SHOT OR CHARGE | - | - | - | - | 1.3 | -13.7 | 234.0 | 0.0 |
| SHOT RISK POINTS | 20.0 | -115.6 | 0.0 | 692.0 | 15.3 | +74.8 | 0.0 | 235.0 |
| SHOTS AFTER THE MOVES | 2.3 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 12.3 | +273.9 | 0.0 | 466.7 | 12.0 | +168.4 | 0.0 | 328.0 |
| SPELL WORTH | 1.0 | +10.8 | 244.0 | 211.7 | - | - | - | - |
| SPELLS IN THE FIGHT | 0.3 | -6.0 | 0.0 | 0.0 | 0.7 | -41.3 | 295.7 | 0.0 |
| SPOT AS THE GAME MOVES | 9.0 | +0.0 | 0.0 | 318.0 | 5.7 | +0.0 | 0.0 | 130.7 |
| STAND AND SHOOT | - | - | - | - | 1.7 | -12.0 | 340.3 | 0.0 |
| STANDS FOR A REASON | 2.0 | +0.0 | 22.0 | 227.3 | 1.0 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 21.7 | +0.0 | 126.0 | 438.0 | 30.0 | +0.0 | 976.7 | 88.7 |
| STAY WORTH | 8.3 | +36.9 | 22.0 | 214.7 | 18.0 | +159.4 | 344.0 | 306.0 |
| STRIKE BY THE ODDS | - | - | - | - | 1.0 | -5.7 | 115.7 | 88.3 |
| STUPIDITY NEXT TURN | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 9.0 | +1264.4 | 0.0 | 22.7 | 2.0 | +55.5 | 0.0 | 22.0 |
| SUPPORT NARROWED | - | - | - | - | 1.0 | +0.0 | 51.3 | 16.7 |
| SUPPORT WORKED OUT | 9.0 | +1264.4 | 0.0 | 22.7 | 2.0 | +55.5 | 0.0 | 22.0 |
| THE DEARER SUM KEEPS ITS PLAN | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 20.0 |
| THE PROMISE ADDS | 0.7 | -20.3 | 0.0 | 0.0 | 0.3 | -11.2 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 3.7 | +0.0 | 0.0 | 61.7 | 1.0 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 3.7 | +0.0 | 0.0 | 134.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 3.0 | +0.0 | 0.0 | 115.7 | 1.7 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 5.3 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 31.0 | +0.0 | 0.0 | 1160.7 | 39.3 | +0.0 | 0.0 | 331.3 |
| TIED UP BY THE SUM | - | - | - | - | 2.0 | +230.1 | 281.3 | 0.0 |
| TIME ON OUR SIDE | 28.0 | +307.6 | 44.0 | 660.3 | 20.0 | +144.0 | 0.0 | 529.3 |
| WAITS AGAIN | 2.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| WAR ENGINE JOBS | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WHO FIGHTS | 1.0 | +8.7 | 44.0 | 11.3 | 1.3 | +7.2 | 358.0 | 0.0 |
| WHO GETS IN | - | - | - | - | 0.3 | +1.2 | 25.7 | 0.0 |
| WHO HITS BACK | 1.0 | +13.2 | 0.0 | 11.3 | 0.3 | +12.4 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | 5.3 | -1203.3 | 0.0 | 958.0 | 2.7 | -198.9 | 0.0 | 0.0 |
| WHOLE FIGHT GAIN | - | - | - | - | 0.7 | +29.4 | 180.0 | 180.0 |
| WOUNDS ON THE RANKS | 2.7 | +4.2 | 0.0 | 128.0 | - | - | - | - |

### Rule changes: cora-bb45c30-p10

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 114 | 114 | 71 | 23.67 | +405 | +5.7 |
| LEGAL CHARGES ONLY | 48 | 48 | 48 | 16.00 | +0 | +0.0 |
| FIVE ACTION | 469 | 454 | 47 | 15.67 | +2574 | +54.8 |
| HIS SHOT LIST | 188 | 182 | 40 | 13.33 | +172 | +4.3 |
| HOLDER ASSIGNMENT | 45 | 45 | 39 | 13.00 | +1640 | +42.0 |
| MOVE TO CHARGE COMPUTED | 47 | 41 | 31 | 10.33 | +1265 | +40.8 |
| THE TABLE AGAIN | 34 | 34 | 28 | 9.33 | +0 | +0.0 |
| HIS SHOTS BY HIS RUN | 190 | 179 | 26 | 8.67 | +145 | +5.6 |
| OFF BEST | 25 | 25 | 25 | 8.33 | -664 | -26.5 |
| PROMISE BY ITS OWN SUM | 59 | 59 | 23 | 7.67 | -2022 | -87.9 |
| REDIRECT FOR A FRIEND IN REACH | 23 | 23 | 23 | 7.67 | +0 | +0.0 |
| DEPLOY BY FIGURES | 45 | 45 | 19 | 6.33 | +155 | +8.1 |
| QUARTER ODDS | 107 | 102 | 16 | 5.33 | +1607 | +100.4 |
| SUPPORT ADDS | 33 | 33 | 16 | 5.33 | +1449 | +90.5 |
| SUPPORT WORKED OUT | 33 | 33 | 16 | 5.33 | +1449 | +90.5 |
| NEXT CHARGE BY LIST | 24 | 23 | 15 | 5.00 | +768 | +51.2 |
| GOAL WALK | 48 | 46 | 13 | 4.33 | +394 | +30.3 |
| TIME ON OUR SIDE | 144 | 129 | 13 | 4.33 | +56 | +4.3 |
| FOUR ROUNDS | 29 | 28 | 12 | 4.00 | +1456 | +121.3 |
| HARD STAY DROPPED | 12 | 12 | 12 | 4.00 | +0 | +0.0 |
| SHOOTS FROM THE BEST SPOT | 18 | 18 | 11 | 3.67 | +22 | +2.0 |
| COVER ONCE | 46 | 34 | 10 | 3.33 | +152 | +15.2 |
| MAX FOR POSITIONING | 23 | 21 | 10 | 3.33 | +8 | +0.8 |
| MOVE ORDER | 10 | 10 | 10 | 3.33 | +0 | +0.0 |
| SHOT RISK POINTS | 106 | 101 | 9 | 3.00 | +57 | +6.3 |
| SHOTS IN THE MOVE | 73 | 62 | 9 | 3.00 | +111 | +12.3 |
| ADVANCE LANE KEPT | 8 | 8 | 8 | 2.67 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 8 | 8 | 8 | 2.67 | +771 | +96.4 |
| MEETS IN TIME | 18 | 18 | 8 | 2.67 | +507 | +63.4 |
| CHARGE NOW FIRST | 19 | 19 | 7 | 2.33 | -421 | -60.2 |
| SCOUT WAITS | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| COMBAT PIVOT | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| JOINT CHARGE NOW | 6 | 6 | 6 | 2.00 | +182 | +30.4 |
| LANE BY FIGURES | 6 | 6 | 6 | 2.00 | +286 | +47.6 |
| CHARGE LOSSES | 81 | 74 | 5 | 1.67 | +593 | +118.5 |
| CASTER AWAY FROM SCREEN | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| CHALLENGE BY POINTS | 4 | 4 | 4 | 1.33 | +324 | +81.1 |
| EXACT ROUND | 18 | 18 | 4 | 1.33 | +10 | +2.4 |
| PROMISE KNOWS THE FIGHT | 12 | 12 | 4 | 1.33 | -12 | -3.1 |
| TIED UP BY THE SUM | 6 | 6 | 4 | 1.33 | +110 | +27.4 |
| WHO HITS BACK | 4 | 4 | 4 | 1.33 | +61 | +15.3 |
| HOLDS AMBUSHERS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| LONE WIZARD KEPT IN | 3 | 3 | 3 | 1.00 | +166 | +55.3 |
| REDIRECT COUNTER | 16 | 15 | 3 | 1.00 | +57 | +19.0 |
| SEARCH SPOT | 6 | 6 | 3 | 1.00 | +229 | +76.4 |
| SECOND LOOK | 3 | 3 | 3 | 1.00 | +218 | +72.6 |
| STAY WORTH | 79 | 69 | 3 | 1.00 | +26 | +8.7 |
| AFTERMATH WITH FRIENDS | 2 | 2 | 2 | 0.67 | +88 | +44.1 |
| CASTS FROM BEHIND | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| IDLE COST | 35 | 19 | 2 | 0.67 | +4 | +2.1 |
| MARCH BY THE SUM | 2 | 2 | 2 | 0.67 | +128 | +64.1 |
| MARCH CHECK | 4 | 4 | 2 | 0.67 | +17 | +8.6 |
| ONE JOINT FIGURE | 3 | 3 | 2 | 0.67 | +8 | +3.9 |
| ONE PROMISE A TARGET | 2 | 2 | 2 | 0.67 | -17 | -8.7 |
| PROMISE SHOT AWAY | 2 | 2 | 2 | 0.67 | -2 | -0.8 |
| RANDOM MOVE BY FIGURES | 5 | 5 | 2 | 0.67 | +75 | +37.6 |
| RESERVE FALL BACK | 2 | 2 | 2 | 0.67 | +59 | +29.3 |
| RISK BY ARC | 24 | 23 | 2 | 0.67 | +38 | +18.8 |
| STRIKE BY THE ODDS | 3 | 3 | 2 | 0.67 | +4 | +1.8 |
| THE ROW IN ITS ORDER | 14 | 2 | 2 | 0.67 | +0 | +0.0 |
| ASSAILMENT BY POINTS | 1 | 1 | 1 | 0.33 | +0 | +0.2 |
| CAST JOB | 2 | 2 | 1 | 0.33 | +2 | +2.3 |
| CASTING BLOCK | 3 | 3 | 1 | 0.33 | +2 | +1.8 |
| CONTINUE AHEAD WEIGHED | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| EDGE GIVE GROUND | 1 | 1 | 1 | 0.33 | +2 | +1.7 |
| FALLS SHORT | 49 | 42 | 1 | 0.33 | +15 | +14.6 |
| FEATURE BUFFS | 5 | 5 | 1 | 0.33 | +2 | +2.0 |
| FIGHT TO THE END | 12 | 11 | 1 | 0.33 | +2 | +1.7 |
| FIRE IN ORDER | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FRIENDS SHOTS CHECKED | 1 | 1 | 1 | 0.33 | +43 | +43.0 |
| HIS CHARGE DENIED | 2 | 2 | 1 | 0.33 | +28 | +28.3 |
| HIS MOVE AND SHOT | 23 | 22 | 1 | 0.33 | +0 | +0.0 |
| HONEST WORTH | 24 | 23 | 1 | 0.33 | +18 | +17.7 |
| HUNT IN PAIRS | 10 | 6 | 1 | 0.33 | +3 | +3.2 |
| LONG SHOT | 5 | 5 | 1 | 0.33 | +2 | +1.8 |
| LOST AFTER ESCAPE | 19 | 18 | 1 | 0.33 | +1 | +0.6 |
| MANOEUVRE | 8 | 8 | 1 | 0.33 | +4 | +4.1 |
| MOVES UNITS SPELL | 1 | 1 | 1 | 0.33 | +4 | +4.3 |
| NEARER NOT NEEDED | 51 | 48 | 1 | 0.33 | +29 | +29.3 |
| ONE FIGHT FORMULA | 40 | 21 | 1 | 0.33 | +27 | +27.4 |
| ONE OBJECTIVE FORMULA | 21 | 14 | 1 | 0.33 | +48 | +48.1 |
| OPENS UP | 3 | 3 | 1 | 0.33 | +35 | +35.1 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.33 | +54 | +54.4 |
| PURSUES BIG PREY | 1 | 1 | 1 | 0.33 | -25 | -25.0 |
| REDIRECT WEIGHED | 1 | 1 | 1 | 0.33 | +83 | +82.8 |
| SET UP BY THE SET | 10 | 10 | 1 | 0.33 | +31 | +31.3 |
| SHOOTERS IN TWO RANKS | 1 | 1 | 1 | 0.33 | +5 | +5.0 |
| SHOTS AFTER THE MOVES | 15 | 15 | 1 | 0.33 | +0 | +0.0 |
| WHO FIGHTS | 7 | 7 | 1 | 0.33 | +2 | +1.8 |
| WHO GETS IN | 1 | 1 | 1 | 0.33 | +4 | +3.8 |
| WHOLE FIGHT GAIN | 2 | 2 | 1 | 0.33 | +2 | +1.8 |
| WOUNDS ON THE RANKS | 8 | 8 | 1 | 0.33 | +0 | +0.0 |
| BACKUP TARGETS | 1 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 2 | trace | - | - | - | - |
| CHAMPION KNOWS CHALLENGE | 2 | 2 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 68 | 67 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 4 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 4 | 4 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 4 | 3 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 20 | 19 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 40 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 33 | 32 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 7 | 7 | 0 | 0.00 | - | - |
| GIVES UP | 3 | 3 | 0 | 0.00 | - | - |
| GUN FIGURES | 7 | not checked | - | - | - | - |
| HE REFORMS ONCE FREED | 13 | 12 | 0 | 0.00 | - | - |
| HELPER UNSEEN | 1 | 1 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 56 | 53 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 27 | 25 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 26 | 22 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 35 | 30 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 47 | 40 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 16 | 13 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 17 | 14 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 11 | 10 | 0 | 0.00 | - | - |
| HIS TURN RUN | 17 | 17 | 0 | 0.00 | - | - |
| HOLD ODDS | 69 | 69 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 6 | 6 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 2 | 2 | 0 | 0.00 | - | - |
| LOST CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 4 | 4 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 4 | 4 | 0 | 0.00 | - | - |
| MISSILES IN THE MOVE | 16 | 9 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 24 | 15 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 26 | 25 | 0 | 0.00 | - | - |
| NO LATE CUT | 2 | 2 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 35 | 35 | 0 | 0.00 | - | - |
| NO SECOND RUN | 34 | 34 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 4 | not checked | - | - | - | - |
| ONE CHALLENGE TEST | 4 | 3 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 4 | not checked | - | - | - | - |
| ONE ROUTE | 4 | 4 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 18 | 18 | 0 | 0.00 | - | - |
| OVERRUNS AWAY | 13 | 12 | 0 | 0.00 | - | - |
| PLAN RESULT | 235 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 4 | 4 | 0 | 0.00 | - | - |
| PROMISE IN STEPS | 2 | 2 | 0 | 0.00 | - | - |
| PROMISE READS THE TABLE | 5 | 5 | 0 | 0.00 | - | - |
| REAL GROUND | 4 | 4 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 5 | 4 | 0 | 0.00 | - | - |
| REFUSING RETIRES | 1 | 1 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 1 | 1 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 19 | 18 | 0 | 0.00 | - | - |
| RUN DOWN | 19 | 18 | 0 | 0.00 | - | - |
| SCOUT SPOT | 6 | 6 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 6 | not checked | - | - | - | - |
| SET CREDITED ONCE | 9 | 9 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 32 | not checked | - | - | - | - |
| SHOT OR CHARGE | 4 | 4 | 0 | 0.00 | - | - |
| SPELL WORTH | 3 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 3 | 3 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 44 | 41 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 5 | 5 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 9 | 7 | 0 | 0.00 | - | - |
| STANDS STILL | 155 | 152 | 0 | 0.00 | - | - |
| STUPIDITY NEXT TURN | 2 | not checked | - | - | - | - |
| SUPPORT NARROWED | 3 | 3 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 4 | not checked | - | - | - | - |
| THE PROMISE ADDS | 3 | 3 | 0 | 0.00 | - | - |
| THE ROW KEEPS ITS WAY | 20 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 14 | not checked | - | - | - | - |
| THE TABLE BINDS | 211 | not checked | - | - | - | - |
| WAITS AGAIN | 7 | 7 | 0 | 0.00 | - | - |
| WAR ENGINE JOBS | 1 | 1 | 0 | 0.00 | - | - |
| WHOLE FIGHT DANGER | 24 | 22 | 0 | 0.00 | - | - |

### Off best figure: cora-bb45c30-p10

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| PROMISE BY ITS OWN SUM | rule | 0.67 | 7.00 | 87.9 |
| JOB FIRST | gate | 1.00 | 5.67 | 31.4 |
| ARMY TABLE | rule | 2.33 | 0.67 | 91.4 |
| CHARGE NOW FIRST | rule | - | 2.33 | 60.2 |
| PROMISE KNOWS THE FIGHT | rule | - | 1.33 | 3.1 |
| NO REASON | gate | - | 0.67 | 15.1 |
| ONE PROMISE A TARGET | rule | - | 0.67 | 8.7 |
| PROMISE SHOT AWAY | rule | - | 0.67 | 0.8 |
| AFTERMATH BAND | gate | 0.33 | - | 3.8 |
| DEPLOY BY FIGURES | rule | 0.33 | - | 1.1 |
| FIGHT ORDER BAND | gate | - | 0.33 | 0.6 |
| JOINT CHARGE NOW | rule | - | 0.33 | 92.3 |
| PURSUES BIG PREY | rule | - | 0.33 | 25.0 |
| RULE SWITCHED OFF | gate | 0.33 | - | 0.7 |

### Plans: cora-bb45c30-p10

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.3 | 25% | 87 | 26 | 29% |
| Mine | move | 29.7 | 85% | 1989 | 0 | 0% |
| Mine | shoot | 5.0 | 33% | 428 | 57 | 13% |
| Opponent | charge | 7.0 | 67% | 1427 | 1050 | 74% |
| Opponent | join | 2.0 | 100% | 76 | 0 | 0% |
| Opponent | move | 29.7 | 92% | 1474 | 0 | 0% |
| Opponent | shoot | 3.7 | 82% | 429 | 198 | 46% |

### Battle groups: cora-bb45c30-p10

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 2.7 | 25% | 100% | 50% | 0% | 0% | 0% | 0% | 100% | 0% |
| Opponent | REDIRECT COUNTER | 2.7 | 38% | 67% | 0% | - | 33% | 0% | 0% | 67% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: cora-bb45c30-p10

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 1 | 0 (1) | 0 | 0 | 100 | 0% | 6.0 | - | 0 (1) | - | - | 0 (1) |
| Mine | Chaff | 7 | 61 (7) | 61 | 0 | 88 | 14% | 2.2 | 69 (6) | 0 (1) | - | 61 (7) | - |
| Mine | Character | 8 | 27 (8) | 27 | 0 | 104 | 0% | 2.1 | 0 (2) | - | 0 (1) | - | 0 (3) |
| Mine | Clean-up | 4 | 78 (4) | 0 | 78 | 63 | 50% | 5.0 | 62 (2) | 31 (1) | 474 (1) | 125 (1) | 56 (3) |
| Mine | Fast Hammer | 1 | 125 (1) | 125 | 0 | 0 | 0% | 2.0 | 125 (1) | - | - | - | 125 (1) |
| Mine | Hammer | 11 | 13 (11) | 10 | 3 | 78 | 0% | 2.2 | 10 (3) | 15 (7) | 0 (1) | 8 (4) | 15 (7) |
| Mine | Shooter | 3 | 23 (3) | 23 | 0 | 0 | 0% | 2.0 | 0 (2) | 69 (1) | - | 0 (1) | 35 (2) |
| Mine | Wizard | 2 | 25 (2) | 25 | 0 | 0 | 0% | 1.5 | 25 (2) | - | - | - | 25 (2) |
| Opponent | Chaff | 8 | 82 (8) | 7 | 75 | 74 | 12% | 1.9 | 63 (2) | 81 (4) | 106 (2) | 79 (5) | 86 (3) |
| Opponent | Character | 8 | 87 (8) | 87 | 0 | 23 | 12% | 2.6 | 58 (5) | 133 (3) | - | 98 (3) | 80 (5) |
| Opponent | Clean-up | 4 | 43 (4) | 43 | 0 | 13 | 75% | 4.0 | 0 (2) | 57 (2) | - | 0 (2) | 57 (2) |
| Opponent | Fast Hammer | 7 | 123 (7) | 123 | 0 | 21 | 29% | 3.2 | 20 (2) | 201 (5) | - | 194 (4) | 73 (3) |
| Opponent | Holder | 4 | 100 (4) | 21 | 80 | 45 | 0% | 2.0 | 175 (2) | - | 38 (2) | 138 (3) | 0 (1) |
| Opponent | Shooter | 4 | 18 (4) | 18 | 0 | 12 | 0% | 2.0 | 14 (2) | 22 (2) | - | 0 (2) | 24 (2) |
| Opponent | Wizard | 3 | 0 (3) | 0 | 0 | 0 | 33% | 1.5 | 0 (1) | 0 (1) | 0 (1) | - | 0 (3) |

### Charged fights: cora-bb45c30-p10

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Ogre Kingdoms | 1 | 70 | 126 | 2.0 | 1.5 | 63 | 45 | +18 | 1 of 2 | 1 of 2 | +126 | -90 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 387 | 5.0 | 1.0 | 77 | 70 | +7 | 1 of 5 | 3 of 5 | - | +7 |
| Mine | Skaven | 1 | 45 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 0 of 1 | 0 of 1 | - | +0 |
| **Mine** | all armies | 3 | 38 | 171 | 2.7 | 1.1 | 64 | 55 | +9 | 2 of 8 | 4 of 8 | +126 | -8 |
| Opponent | Tomb Kings of Khemri | 2 | 89 | 1140 | 5.5 | 1.2 | 207 | 61 | +146 | 7 of 11 | 9 of 11 | +282 | +116 |
| Opponent | Vampire Counts | 1 | 0 | 1369 | 4.0 | 1.2 | 342 | 48 | +294 | 2 of 4 | 3 of 4 | +540 | +212 |
| **Opponent** | all armies | 3 | 59 | 1216 | 5.0 | 1.2 | 243 | 58 | +186 | 9 of 15 | 12 of 15 | +368 | +140 |

### Effective charges: cora-bb45c30-p10

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Ogre Kingdoms | 2 | 0 | 0 | 1 (net +126) | 0 | 0 | 0 | 1 | 100% (1 of 1) |
| Mine | Orc & Goblin Tribes | 5 | 0 | 0 | 0 | 1 (net +0) | 0 | 0 | 4 | 0% (0 of 1) |
| Mine | Skaven | 1 | 0 | 0 | 1 (net +0) | 0 | 0 | 0 | 0 | 100% (1 of 1) |
| Opponent | Tomb Kings of Khemri | 11 | 2 (net +376) | 0 | 1 (net +234) | 0 | 1 (net +185) | 5 (net +200) | 2 | 11% (1 of 9) |
| Opponent | Vampire Counts | 4 | 1 (net +37) | 0 | 0 | 1 (net +540) | 0 | 1 (net +210) | 1 | 0% (0 of 3) |

### Charged fights, damage counted: cora-bb45c30-p10

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Effective (55-75%) | 2 | 53 | 138 | +63 | 63 | 22 | +41 | +76.9 |
| Mine | 76-89% | 1 | 55 | 66 | +0 | 0 | 0 | +0 | +0.0 |
| Mine | No odds | 5 | 179 | 164 | -11 | 90 | 97 | -6 | -3.6 |
| Mine | All fights | 8 | 132 | 145 | +9 | 72 | 66 | +6 | +4.7 |
| Opponent | Long shot (under 50%) | 3 | 225 | 225 | +263 | 387 | 64 | +323 | +143.2 |
| Opponent | Effective (55-75%) | 1 | 195 | 234 | +234 | 234 | 65 | +169 | +86.7 |
| Opponent | 76-89% | 1 | 548 | 440 | +540 | 540 | 0 | +540 | +98.5 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 6 | 316 | 242 | +201 | 239 | 48 | +191 | +60.5 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 871 | 185 | +185 | 187 | 0 | +187 | +21.5 |
| Opponent | No odds | 3 | 372 | 198 | -57 | 166 | 223 | -57 | -15.3 |
| Opponent | All fights | 15 | 353 | 239 | +186 | 271 | 81 | +189 | +53.6 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| cora-bb45c30-p10 | move | 24 | 7 (29%) | 7 (29%) | 1 (4%) | 16 (67%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L2025 |
| Elixir of Power | Mine | L1923 |
| Fistful of Laurels | Mine | L1823 |
| Invocation of Nehek | Opponent | L2025 |
| Periapt of Soul Exchange | Mine | L2025 |

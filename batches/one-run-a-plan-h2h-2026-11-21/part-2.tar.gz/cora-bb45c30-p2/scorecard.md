# Doctrine scorecard: cora-bb45c30-p2

### Scorecard: cora-bb45c30-p2

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0218 | 2 | 1 | Mine | - | - | - | 0 | 9 | 0 | 0 | 0 | 255 |
| L0218 | 2 | 1 | Opponent | - | - | - | 0 | 6 | 0 | 0 | 0 | 336 |
| L0235 | 1 | 1 | Mine | no | 7 | 6 | 1 | 6 | 0 | 0 | 0 | 0 |
| L0235 | 1 | 1 | Opponent | no | 0 | 6 | 1 | 4 | 0 | 0 | 0 | 125 |
| L0319 | 1 | 1 | Mine | no | 3 | - | 0 | 0 | 0 | 0 | 0 | 335 |
| L0319 | 1 | 1 | Opponent | no | 0 | 2 | 4 | 3 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 0% | 5.0 | 6.0 | 0.3 | 5.0 | 0.0 | 0.0 | 0.0 | 196.7 |
| **Average** | | | Opponent | 0% | 0.0 | 4.0 | 1.7 | 4.3 | 0.0 | 0.0 | 0.0 | 153.7 |

### KPIs: cora-bb45c30-p2

Rules off - Mine only: ONE RUN A PLAN.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 25% (2 of 8) | 0% (0 of 10) | 11% (2 of 18) |
| Winner chose to follow up after the loser gave ground |  | - | - | - |
| Winner chose to pursue after the loser fell back in good order |  | - | - | - |
| Winner chose to pursue after the loser fled |  | 50% (1 of 2); on the table 50% | - | 50% (1 of 2); on the table 50% |
| Winner chose to follow up or pursue (all three) |  | 50% (1 of 2); on the table 50% | - | 50% (1 of 2); on the table 50% |
| Magic missiles tried each own turn | 50%+ | 48% (20 of 42) | 4% (1 of 24) | 32% (21 of 66) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 48% (20 of 42) | 5% (1 of 21) | 33% (21 of 63) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 67% (8 of 12) | - | 67% (8 of 12) |
| Points that never fought | lower | 89% (5184 of 5797) | 86% (5163 of 6000) | 88% (10347 of 11797) |
|   infantry points that never fought | lower | 70% (965 of 1374) | 100% (842 of 842) | 82% (1807 of 2216) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 55% (11 of 20) | 67% (18 of 27) | 62% (29 of 47) |
| Bound items with a magic missile used (at least once a game) |  | 100% (4 of 4); 6.0 uses a game | 50% (1 of 2); 1.3 uses a game | 83% (5 of 6); 3.7 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 80% (4 of 5); 1.3 uses a game | 100% (1 of 1); 0.3 uses a game | 83% (5 of 6); 0.8 uses a game |
|   their share of the points of units over 100 pts | lower | 46% (1873 of 4039) | 62% (3431 of 5515) | 56% (5304 of 9554) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 7.0 (95%) | 1.0 (13%) | 8.0 (53%) |
| MARCHED: its unit marched | 0.3 (5%) | 0.7 (9%) | 1.0 (7%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 3.7 (48%) | 3.7 (24%) |
| GONE: slain | 0.0 (0%) | 1.0 (13%) | 1.0 (7%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 1.3 (17%) | 1.3 (9%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Hexes | Movement spells | Magic missiles | Assailments |
| --- | --- | --- | --- | --- |
| tried | 1.3 | 3.3 | 7.0 | 0.3 |
| not cast | 2.7 | 6.7 | 15.0 | 27.7 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (1%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.7 (25%) | 0.0 (0%) | 8.0 (53%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 1.0 (7%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 2.0 (75%) | 3.7 (55%) | 3.7 (24%) | 0.0 (0%) |
| GONE: slain | 0.0 (0%) | 0.3 (5%) | 1.0 (7%) | 2.0 (7%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 1.3 (9%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 0.0 (0%) | 2.7 (40%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 25.3 (92%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 2.0 a game | 1.3 a game | 1.7 a game |
| stood (cast and not dispelled) | 83% (5 of 6) | 75% (3 of 4) | 80% (8 of 10) |
| the unit moved after it | 60% (3 of 5) | 0% (0 of 3) | 38% (3 of 8) |
| it charged on its next turn | 0% (0 of 5) | 0% (0 of 3) | 0% (0 of 8) |
| the enemy charged it first | 0% (0 of 5) | 0% (0 of 3) | 0% (0 of 8) |
| it fought by the end of its next turn | 0% (0 of 5) | 0% (0 of 3) | 0% (0 of 8) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 5) | 0% (0 of 3) | 0% (0 of 8) |
| none of these (no charge, no fight, no charge escaped) | 100% (5 of 5) | 100% (3 of 3) | 100% (8 of 8) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 78% (28 of 36) | 52% (43 of 82) | 60% (71 of 118) |
|   cavalry | - | 61% (11 of 18) | 61% (11 of 18) |
|   character | - | 64% (7 of 11) | 64% (7 of 11) |
|   chariot | 67% (8 of 12) | 58% (7 of 12) | 62% (15 of 24) |
|   infantry | - | 28% (8 of 29) | 28% (8 of 29) |
|   monster | - | 83% (10 of 12) | 83% (10 of 12) |
|   war machine | 83% (20 of 24) | - | 83% (20 of 24) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.0 (38%) | 3.0 (23%) | 4.0 (26%) |
| CHARGED: it charged | 0.0 (0%) | 0.3 (3%) | 0.3 (2%) |
| MOVED: a war machine that moved | 0.7 (25%) | 0.0 (0%) | 0.7 (4%) |
| NO TARGET IN RANGE | 0.3 (12%) | 6.7 (51%) | 7.0 (45%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.3 (12%) | 0.7 (5%) | 1.0 (6%) |
| SHELTERED: the target was sheltered | 0.0 (0%) | 0.7 (5%) | 0.7 (4%) |
| OTHER BAR | 0.3 (12%) | 1.7 (13%) | 2.0 (13%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 4.7 | 1.7 | 71% | 5.6 pts | 26 pts |
| character | 2.3 | 0.7 | 71% | 8.1 pts | 19 pts |
| chariot | 5.0 | 7.3 | 33% | 32.8 pts | 164 pts |
| infantry | 2.7 | 0.3 | 88% | 2.7 pts | 7 pts |
| monster | 3.3 | 3.0 | 50% | 13.3 pts | 44 pts |
| war machine | 7.0 | 2.0 | 81% | 4.6 pts | 32 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 0.3 | 2.0 | 1.2 |
| Charges that made contact a game | 0.3 | 0.7 | 0.5 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.00 declared, 0.00 contact (2 units) | - | 0.00 declared, 0.00 contact (2 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | - | - |
|   per unit a game, the other units (no war machines, no joined characters) | 0.04 declared, 0.04 contact (25 units) | 0.21 declared, 0.07 contact (29 units) | 0.13 declared, 0.06 contact (54 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 67% (2 of 3) | 100% (1 of 1) | - | 75% (3 of 4) |
| Character in a unit | 80% (4 of 5) | 50% (3 of 6) | - | 64% (7 of 11) |
| Character on its own | 100% (3 of 3) | 100% (2 of 2) | 50% (1 of 2) | 86% (6 of 7) |
| Chariot | 50% (1 of 2) | 0% (0 of 2) | - | 25% (1 of 4) |
| Infantry | 80% (4 of 5) | 33% (1 of 3) | - | 62% (5 of 8) |
| Monster | 100% (2 of 2) | 0% (0 of 1) | - | 67% (2 of 3) |
| Monstrous | 100% (2 of 2) | 25% (1 of 4) | - | 50% (3 of 6) |
| War Machines | 67% (2 of 3) | 0% (0 of 1) | - | 50% (2 of 4) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 2 | - | 67% (20 of 30) | 98% | 67% (8 of 12) | 100% (4 of 4); 9.0 uses a game | 0.0 uses a game | 75% (3 of 4); 1.5 uses a game |
| Chaos Dwarfs | 1 | 50% (1 of 2); on the table 50% | 0% (0 of 12) | 74% | 38% (3 of 8) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Ogre Kingdoms | 1 | - | 0% (0 of 6) | 100% | 57% (4 of 7) | 100% (1 of 1); 4.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 1 | - | 0% (0 of 12) | 80% | 62% (5 of 8) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Wood Elf Realms | 1 | - | 17% (1 of 6) | 78% | 75% (9 of 12) | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (cora-bb45c30-p2, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 100% (2) | 100% (1) | 100% (3) |
| ...free all their last turn and able to turn (per game) | 0.67 | 0.33 | 1.00 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.67 | 0.33 | 1.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: cora-bb45c30-p2

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.3 | 1.3 |
| Strategy | Charge objectives carried out (made contact) | 100% (1 of 1) | 0% (0 of 2) |
| Strategy | Shoot objectives carried out (shot that target) | 56% (15 of 27) | 50% (6 of 12) |
| Strategy | Hexes on a unit its side charged or shot that turn | - | 50% (1 of 2) |
| Strategy | Joined characters whose unit fought | 9% (1 of 11) | 50% (1 of 2) |
| Strategy | Lone characters that fought | 0% (0 of 4) | 14% (1 of 7) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 5.0 | 4.3 |
| Movement | Points that never moved of their own | 196.7 | 153.7 |
| Movement | Fights charged into per game | 0.3 | 0.7 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 1 | - |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 1 | - |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 1 | - |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 of 1, net +0 | - |
| Shooting | Shots by shooting units (incl. breath weapons) | 2.7 | 14.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 75% (6 of 8) | 34% (15 of 44) |
| Shooting | Points destroyed by shooting units | 219.3 | 56.7 |
| Shooting | War machine shots | 6.7 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 75% (15 of 20) | - |
| Shooting | Points destroyed by war machines | 160.7 | 28.3 |
| Magic | Magic missiles cast | 4.0 | 0.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 17% (2 of 12) | 0% (0 of 1) |
| Magic | Wounds caused by magic missiles | 20.3 | 2.0 |
| Magic | Wounds caused by other spells | - | 1.3 |
| Magic | Points destroyed by magic (all spells) | 144.7 | 38.3 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.0 / 0.0 / 0.0 / 0.0 | 0.0 / 0.7 / 0.3 / 0.0 |
| Combat | Points destroyed in combat | 0.0 | 0.0 |
| Combat | Points run down | 0.0 | 0.0 |
| Combat | Net points per charged fight, damage counted | +40 | -82 |
| Combat | Net per 100 charger points, damage counted | +46.5 | -40.3 |
| Combat | First round won (charged fights) | 0% | 0% |
| Combat | Net points per charged fight | +0 | +0 |
| Combat | Net points per supported fight / lone fight | - / +0 | - / +0 |
| Combat | Charged fights on a top-3 enemy unit | 1 of 1 | 1 of 2 |
| Game | Points lost | 153.7 | 493.0 |
| Game | VP from objectives | 766.7 | 990.0 |
| Game | Lone holders (player turns) | 5.0 | 0.0 |

- Mine won / drew / lost: 1 / 1 / 1 of 3 ended games (of 3); mean margin (Mine - Opponent) +161 VP
- The side that went first won 2 of 2 games with a winner
- Points traded per game (both sides' losses): 647
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: cora-bb45c30-p2

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | - | - | - | - | 1.0 | +0.0 | 0.0 | 41.7 |
| ARMY TABLE | 20.7 | +310.3 | 0.0 | 97.0 | 25.0 | +343.7 | 0.0 | 36.7 |
| ARTILLERY RE-ROLL WEIGHED | 2.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| BEST PRIZE | - | - | - | - | 0.3 | -2.8 | 0.0 | 0.0 |
| CANNON PLAN MISSED | 1.3 | +0.0 | 169.3 | 0.0 | - | - | - | - |
| CANNON PLANNED TARGET | 5.7 | +191.4 | 892.0 | 0.0 | - | - | - | - |
| CANNON SIGHT KEPT | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CAST JOB | 2.0 | +4.9 | 0.0 | 0.0 | - | - | - | - |
| CASTER AWAY FROM SCREEN | 1.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 2.3 | +282.2 | 41.7 | 0.0 | 0.7 | +11.4 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 1.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.3 | +31.7 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | 1.0 | +35.0 | 0.0 | 20.0 | 0.7 | +0.4 | 0.0 | 0.0 |
| CHAFF PASSED | 0.3 | -1.0 | 0.0 | 0.0 | 0.3 | -0.8 | 0.0 | 0.0 |
| CHALLENGE BY POINTS | 0.3 | +5.3 | 0.0 | 0.0 | - | - | - | - |
| CHARGE LOSSES | 11.7 | -274.6 | 0.0 | 0.0 | 13.0 | -1085.2 | 0.0 | 348.7 |
| CHARIOT NO STATIC JOB | 0.3 | +0.0 | 0.0 | 28.3 | - | - | - | - |
| CLOSES ON WHAT IT BEATS | 10.7 | +0.0 | 0.0 | 137.3 | 7.7 | +0.0 | 0.0 | 36.7 |
| CONVEYANCE SEARCH | 2.0 | +238.5 | 0.0 | 0.0 | 1.3 | +205.2 | 0.0 | 0.0 |
| COVER ONCE | 4.7 | -299.9 | 0.0 | 0.0 | 4.3 | -185.2 | 0.0 | 0.0 |
| DEPLOY BY FIGURES | 9.7 | +22.3 | 0.0 | 28.3 | 8.3 | +76.7 | 0.0 | 41.7 |
| ELIXIR WORTH | - | - | - | - | 0.3 | +6.3 | 0.0 | 0.0 |
| ENGINEER BY LORE | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| EXACT ROUND | - | - | - | - | 0.3 | +0.1 | 10.0 | 0.0 |
| FALL BACK GOOD ORDER | 0.3 | +1.0 | 0.0 | 28.3 | 0.3 | +0.0 | 10.0 | 0.0 |
| FALLS SHORT | 23.0 | +297.0 | 0.0 | 66.7 | 4.0 | +119.7 | 0.0 | 0.0 |
| FEATURE BUFFS | 11.3 | +498.3 | 0.0 | 20.0 | - | - | - | - |
| FIVE ACTION | 104.3 | +7436.0 | 1752.3 | 396.3 | 100.7 | +6322.1 | 180.0 | 520.7 |
| FLANK NOT WEIGHED | 7.0 | +0.0 | 0.0 | 58.7 | 3.7 | +0.0 | 0.0 | 13.3 |
| FOUR ROUNDS | 0.3 | +39.3 | 0.0 | 28.3 | 0.7 | -9.1 | 10.0 | 0.0 |
| FRIEND SHOOTS FIRST | 0.3 | -1.2 | 0.0 | 28.3 | - | - | - | - |
| GOAL WALK | 8.0 | +1028.3 | 0.0 | 0.0 | 14.0 | +1070.5 | 0.0 | 0.0 |
| GROUND FLIERS | 0.3 | +6.5 | 0.0 | 0.0 | - | - | - | - |
| GUN FIGURES | 1.7 | +30.1 | 114.3 | 0.0 | 1.7 | +38.5 | 28.3 | 0.0 |
| HARD STAY DROPPED | 3.7 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 7.3 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 83.3 |
| HIS CHARGE LIST | 6.0 | +0.0 | 0.0 | 123.3 | 4.0 | +0.0 | 0.0 | 26.7 |
| HIS LEGAL MOVES | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 4.7 | -69.6 | 0.0 | 113.3 | 3.7 | -132.1 | 0.0 | 0.0 |
| HIS ONE QUARTER | 6.7 | +0.0 | 0.0 | 56.7 | 4.7 | +0.0 | 0.0 | 228.7 |
| HIS OWN BEST MOVE | 0.7 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVE | - | - | - | - | 22.3 | +0.0 | 0.0 | 196.0 |
| HIS RANDOM MOVER COMES | - | - | - | - | 0.7 | +0.0 | 0.0 | 26.7 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 69.0 | +2430.1 | 0.0 | 368.0 | 64.7 | +2858.4 | 0.0 | 484.0 |
| HIS SHOTS BY HIS RUN | 59.3 | +1153.3 | 0.0 | 246.7 | 48.0 | +1444.8 | 0.0 | 484.0 |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HOLD ODDS | 33.3 | +0.0 | 0.0 | 80.7 | 21.3 | +0.0 | 0.0 | 228.7 |
| HOLDER ASSIGNMENT | 15.3 | +1583.9 | 0.0 | 40.3 | 14.7 | +1575.3 | 0.0 | 114.3 |
| HOLDS AMBUSHERS | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 0.3 | -0.9 | 0.0 | 28.3 | 0.7 | -24.3 | 10.0 | 0.0 |
| IDLE COST | 18.7 | -102.3 | 0.0 | 28.3 | 4.0 | -51.3 | 0.0 | 18.3 |
| KEPT FROM ITS LAST STOP | 1.3 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 228.7 |
| LANE BY FIGURES | - | - | - | - | 0.7 | +17.7 | 0.0 | 0.0 |
| LONE WIZARD KEPT IN | 1.3 | +116.7 | 0.0 | 0.0 | - | - | - | - |
| LOST AFTER ESCAPE | 0.3 | +0.1 | 0.0 | 28.3 | 0.7 | +1.7 | 10.0 | 0.0 |
| MANOEUVRE | 2.0 | -13.4 | 0.0 | 0.0 | 2.7 | +0.3 | 0.0 | 0.0 |
| MARCH AT ESCAPER | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| MARCH BY THE SUM | 0.3 | +54.1 | 0.0 | 0.0 | 1.0 | +238.8 | 0.0 | 114.3 |
| MARCH CHECK | 0.7 | +22.1 | 0.0 | 0.0 | 2.0 | +97.7 | 0.0 | 114.3 |
| MARCH OVER CASTS | 0.3 | -4.4 | 0.0 | 0.0 | 1.0 | +103.7 | 0.0 | 114.3 |
| MARCH WHEELS ONLY | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 1.3 | +19.0 | 0.0 | 85.0 | 1.0 | +14.7 | 0.0 | 0.0 |
| MEETS IN TIME | 3.3 | +262.7 | 0.0 | 0.0 | 3.0 | +302.4 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 6.7 | +394.5 | 0.0 | 0.0 | 4.3 | +92.0 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 7.0 | +242.7 | 0.0 | 0.0 | 5.0 | +64.7 | 0.0 | 114.3 |
| MISSILES ON ONE TARGET | 1.3 | -114.1 | 0.0 | 0.0 | - | - | - | - |
| MOVE ORDER | 0.7 | +0.0 | 28.3 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| MOVE SPELL NOT WORTH | 0.3 | -0.1 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | - | - | - | - | 1.0 | -18.2 | 0.0 | 0.0 |
| MOVE SPELL SPOT | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 3.0 | +320.4 | 0.0 | 56.7 | 4.3 | +218.7 | 0.0 | 0.0 |
| MOVES UNITS SPELL | 0.7 | +36.7 | 0.0 | 0.0 | 0.3 | +1.4 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 5.0 | +259.1 | 0.0 | 60.7 | 12.0 | +569.5 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 2.3 | +198.6 | 0.0 | 28.3 | 2.7 | +109.5 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 0.3 | -10.6 | 0.0 | 28.3 | 0.7 | -5.3 | 10.0 | 0.0 |
| NO LATE CUT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OFF BEST | 3.0 | -948.9 | 0.0 | 28.3 | 3.0 | -69.3 | 0.0 | 0.0 |
| OGRE LOADER SECOND SHOT | 1.7 | +76.4 | 114.3 | 0.0 | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 3.0 | -31.6 | 0.0 | 113.3 | 3.3 | -90.0 | 0.0 | 0.0 |
| ONE OBJECTIVE FORMULA | 8.3 | -63.2 | 0.0 | 40.3 | 4.7 | -115.6 | 0.0 | 0.0 |
| ONE PROMISE A TARGET | - | - | - | - | 0.3 | -12.0 | 0.0 | 0.0 |
| ONE ROUTE | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| ONE RUN A PLAN | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS A LANE | 0.3 | +1.1 | 0.0 | 0.0 | - | - | - | - |
| OVERRUNS AWAY | 0.3 | +3.7 | 0.0 | 28.3 | - | - | - | - |
| PLAN RESULT | 46.3 | +208.7 | 590.0 | 250.7 | 44.3 | +87.9 | 85.0 | 453.0 |
| PROMISE BY ITS OWN SUM | 5.7 | -2040.4 | 0.0 | 28.3 | 6.7 | -277.9 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | - | - | - | - | 0.3 | -6.1 | 0.0 | 0.0 |
| PROMISE SHOT AWAY | 2.0 | -26.8 | 0.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | 20.0 | +1093.3 | 1600.7 | 113.3 | 16.3 | +2485.7 | 0.0 | 302.0 |
| RANDOM MOVE BY FIGURES | 4.0 | +89.8 | 0.0 | 0.0 | - | - | - | - |
| REAL GROUND | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | 2.0 | +125.7 | 0.0 | 85.0 | 1.3 | -53.2 | 0.0 | 11.3 |
| REDIRECT FOR A FRIEND IN REACH | 3.0 | +0.0 | 0.0 | 56.7 | 3.7 | +0.0 | 0.0 | 22.7 |
| REFORMS TO MEET IT | 1.3 | -55.2 | 0.0 | 56.7 | 2.0 | -11.7 | 0.0 | 0.0 |
| RESERVE FALL BACK | - | - | - | - | 0.3 | +40.4 | 0.0 | 0.0 |
| RISK BY ARC | 0.3 | +1.3 | 0.0 | 28.3 | 0.3 | +0.2 | 10.0 | 0.0 |
| RISK ON THE WAY | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| ROUNDS AFTER TERROR | - | - | - | - | 0.3 | +35.3 | 0.0 | 0.0 |
| RUN DOWN | 0.3 | -12.0 | 0.0 | 28.3 | 0.7 | -4.5 | 10.0 | 0.0 |
| SCOUT SPOT | - | - | - | - | 0.7 | -0.1 | 0.0 | 0.0 |
| SCOUT WAITS | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 1.3 | -19.5 | 0.0 | 20.0 | - | - | - | - |
| SEARCH SPOT | - | - | - | - | 0.3 | +0.8 | 0.0 | 0.0 |
| SET UP TOGETHER | 0.7 | +5.0 | 0.0 | 0.0 | - | - | - | - |
| SET-UP MISSED | - | - | - | - | 0.3 | +8.7 | 0.0 | 0.0 |
| SHOOTER COUNTED ONCE | 0.7 | -2.4 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | - | - | - | - | 0.3 | +0.3 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 9.0 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.0 | +17.6 | 0.0 | 0.0 | - | - | - | - |
| SHOT REPLANNED | 0.3 | +0.0 | 18.3 | 0.0 | - | - | - | - |
| SHOT RISK POINTS | 55.7 | +653.3 | 0.0 | 246.7 | 50.0 | -183.9 | 0.0 | 484.0 |
| SHOTS AFTER THE MOVES | 2.0 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 10.0 | +422.7 | 0.0 | 0.0 | 19.7 | +382.2 | 0.0 | 36.7 |
| SPOT AS THE GAME MOVES | 7.3 | +0.0 | 0.0 | 87.0 | 8.7 | +0.0 | 0.0 | 0.0 |
| STAND AND SHOOT | 0.3 | -2.3 | 0.0 | 28.3 | - | - | - | - |
| STANDS FOR A REASON | 1.3 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 49.3 | +0.0 | 1752.3 | 40.3 | 47.7 | +0.0 | 170.0 | 218.7 |
| STAY WORTH | 21.3 | +142.2 | 609.0 | 0.0 | 22.3 | +126.8 | 113.3 | 73.3 |
| STUCK PIVOT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SUPPORT ADDS | 1.7 | +193.7 | 0.0 | 10.0 | 1.7 | +22.8 | 0.0 | 0.0 |
| SUPPORT NARROWED | - | - | - | - | 0.3 | +0.0 | 10.0 | 0.0 |
| SUPPORT WORKED OUT | 1.7 | +193.7 | 0.0 | 10.0 | 1.7 | +22.8 | 0.0 | 0.0 |
| SURE REACH TOGETHER | 0.3 | +8.8 | 0.0 | 0.0 | 0.3 | +2.7 | 0.0 | 11.3 |
| SWIFTSTRIDE BY POINTS | - | - | - | - | 0.3 | +0.1 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 1.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| THE PROMISED MOVE | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 5.0 | +0.0 | 0.0 | 58.7 | 5.0 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 6.0 | +0.0 | 0.0 | 58.7 | 3.3 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 3.0 | +0.0 | 0.0 | 28.3 | 3.3 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 47.7 | +0.0 | 0.0 | 184.0 | 47.7 | +0.0 | 0.0 | 260.3 |
| TIME ON OUR SIDE | 9.0 | +154.0 | 0.0 | 60.7 | 66.0 | +528.9 | 0.0 | 273.0 |
| WAITS AGAIN | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| WALKS ON ITS ROUTE | - | - | - | - | 0.7 | -35.5 | 0.0 | 0.0 |
| WAR ENGINE JOBS | 1.3 | +0.0 | 228.7 | 0.0 | 0.7 | +0.0 | 56.7 | 0.0 |
| WHO HITS BACK | 0.3 | +43.3 | 0.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT DANGER | 1.0 | -123.1 | 0.0 | 0.0 | 1.3 | -173.0 | 0.0 | 0.0 |
| WOUNDS ON THE RANKS | 4.3 | +226.2 | 0.0 | 0.0 | 5.0 | +1017.9 | 0.0 | 228.7 |

### Rule changes: cora-bb45c30-p2

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS SHOT LIST | 401 | 394 | 122 | 40.67 | +915 | +7.5 |
| HIS SHOTS BY HIS RUN | 322 | 310 | 120 | 40.00 | +1886 | +15.7 |
| SHOT RISK POINTS | 317 | 312 | 106 | 35.33 | +1826 | +17.2 |
| ARMY TABLE | 137 | 137 | 84 | 28.00 | +1123 | +13.4 |
| HOLDER ASSIGNMENT | 90 | 90 | 84 | 28.00 | +4825 | +57.4 |
| DEPLOY BY FIGURES | 54 | 54 | 36 | 12.00 | +491 | +13.6 |
| TIME ON OUR SIDE | 225 | 198 | 32 | 10.67 | +93 | +2.9 |
| THE TABLE AGAIN | 36 | 36 | 25 | 8.33 | +0 | +0.0 |
| HARD STAY DROPPED | 23 | 23 | 23 | 7.67 | +0 | +0.0 |
| QUARTER ODDS | 109 | 107 | 22 | 7.33 | +1214 | +55.2 |
| FIVE ACTION | 615 | 597 | 21 | 7.00 | +1214 | +57.8 |
| REDIRECT FOR A FRIEND IN REACH | 20 | 20 | 20 | 6.67 | +0 | +0.0 |
| OFF BEST | 18 | 18 | 18 | 6.00 | -3055 | -169.7 |
| PROMISE BY ITS OWN SUM | 37 | 37 | 18 | 6.00 | -6955 | -386.4 |
| GOAL WALK | 66 | 65 | 15 | 5.00 | +793 | +52.9 |
| MEETS IN TIME | 19 | 19 | 13 | 4.33 | +889 | +68.4 |
| MISSILES IN THE MOVE | 33 | 26 | 10 | 3.33 | +778 | +77.8 |
| CASTING BLOCK | 9 | 9 | 9 | 3.00 | +218 | +24.2 |
| WOUNDS ON THE RANKS | 28 | 28 | 9 | 3.00 | +869 | +96.6 |
| MOVE ORDER | 8 | 8 | 8 | 2.67 | +0 | +0.0 |
| RANDOM MOVE BY FIGURES | 12 | 12 | 8 | 2.67 | +270 | +33.7 |
| STAY WORTH | 131 | 111 | 8 | 2.67 | +157 | +19.7 |
| ARTILLERY RE-ROLL WEIGHED | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| CASTER AWAY FROM SCREEN | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| FALLS SHORT | 81 | 65 | 6 | 2.00 | +194 | +32.3 |
| PROMISE SHOT AWAY | 6 | 6 | 6 | 2.00 | -80 | -13.4 |
| CHARGE LOSSES | 74 | 73 | 5 | 1.67 | +83 | +16.6 |
| OGRE LOADER SECOND SHOT | 5 | 5 | 5 | 1.67 | +229 | +45.8 |
| CAST JOB | 6 | 6 | 4 | 1.33 | +8 | +2.0 |
| LONE WIZARD KEPT IN | 4 | 4 | 4 | 1.33 | +350 | +87.5 |
| MARCH BY THE SUM | 4 | 4 | 4 | 1.33 | +878 | +219.6 |
| MARCH CHECK | 8 | 8 | 4 | 1.33 | +134 | +33.6 |
| MOVE TO CHARGE COMPUTED | 22 | 15 | 4 | 1.33 | +330 | +82.6 |
| SHOTS AFTER THE MOVES | 12 | 12 | 4 | 1.33 | +0 | +0.0 |
| SHOTS IN THE MOVE | 89 | 66 | 4 | 1.33 | +165 | +41.4 |
| ADVANCE LANE KEPT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| FEATURE BUFFS | 34 | 34 | 3 | 1.00 | +36 | +12.0 |
| HOLDS AMBUSHERS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| MAX FOR POSITIONING | 7 | 7 | 3 | 1.00 | +0 | +0.0 |
| MOVES UNITS SPELL | 3 | 3 | 3 | 1.00 | +114 | +38.2 |
| REDIRECT COUNTER | 10 | 8 | 3 | 1.00 | +224 | +74.6 |
| SCOUT WAITS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| CANNON PLANNED TARGET | 17 | 17 | 2 | 0.67 | +0 | +0.2 |
| CANNON SIGHT KEPT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| CHAFF IN THE MOVE | 5 | 5 | 2 | 0.67 | +9 | +4.7 |
| CHAFF PASSED | 2 | 2 | 2 | 0.67 | -5 | -2.7 |
| LANE BY FIGURES | 2 | 2 | 2 | 0.67 | +53 | +26.6 |
| NEARER NOT NEEDED | 51 | 46 | 2 | 0.67 | +58 | +28.8 |
| NEXT CHARGE BY LIST | 15 | 10 | 2 | 0.67 | +313 | +156.5 |
| ONE OBJECTIVE FORMULA | 39 | 28 | 2 | 0.67 | +50 | +24.9 |
| SURE REACH TOGETHER | 2 | 2 | 2 | 0.67 | +11 | +5.3 |
| WALKS ON ITS ROUTE | 2 | 2 | 2 | 0.67 | -107 | -53.3 |
| BEST PRIZE | 1 | 1 | 1 | 0.33 | -8 | -8.3 |
| CHALLENGE BY POINTS | 1 | 1 | 1 | 0.33 | +16 | +15.8 |
| CHARIOT NO STATIC JOB | 1 | 1 | 1 | 0.33 | -184 | -184.1 |
| COVER ONCE | 27 | 16 | 1 | 0.33 | +14 | +14.5 |
| ELIXIR WORTH | 1 | 1 | 1 | 0.33 | +19 | +18.9 |
| FOUR ROUNDS | 3 | 3 | 1 | 0.33 | +85 | +84.7 |
| IDLE COST | 68 | 55 | 1 | 0.33 | +0 | +0.0 |
| MANOEUVRE | 14 | 14 | 1 | 0.33 | +1 | +1.0 |
| ONE FIGHT FORMULA | 19 | 11 | 1 | 0.33 | +0 | +0.0 |
| ONE PROMISE A TARGET | 1 | 1 | 1 | 0.33 | -36 | -36.0 |
| PROMISE READS THE TABLE | 1 | 1 | 1 | 0.33 | -17 | -16.6 |
| RESERVE FALL BACK | 1 | 1 | 1 | 0.33 | +121 | +121.3 |
| SEARCH SPOT | 1 | 1 | 1 | 0.33 | +2 | +2.3 |
| SHOOTERS IN TWO RANKS | 1 | 1 | 1 | 0.33 | +1 | +1.0 |
| SHOOTS FROM THE BEST SPOT | 3 | 3 | 1 | 0.33 | +2 | +1.7 |
| SHOT REPLANNED | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| STUCK PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| SUPPORT ADDS | 10 | 10 | 1 | 0.33 | +65 | +65.4 |
| SUPPORT WORKED OUT | 10 | 10 | 1 | 0.33 | +65 | +65.4 |
| SWIFTSTRIDE BY POINTS | 1 | 1 | 1 | 0.33 | +0 | +0.2 |
| WHO HITS BACK | 1 | 1 | 1 | 0.33 | +52 | +52.4 |
| WHOLE FIGHT DANGER | 7 | 7 | 1 | 0.33 | +16 | +15.9 |
| CANNON PLAN MISSED | 4 | 4 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 7 | trace | - | - | - | - |
| CATCH FLIERS | 1 | not checked | - | - | - | - |
| CLOSES ON WHAT IT BEATS | 55 | 55 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 10 | not checked | - | - | - | - |
| ENGINEER BY LORE | 2 | 2 | 0 | 0.00 | - | - |
| EXACT ROUND | 1 | 1 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 2 | 2 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 32 | not checked | - | - | - | - |
| FRIEND SHOOTS FIRST | 1 | 1 | 0 | 0.00 | - | - |
| GROUND FLIERS | 1 | not checked | - | - | - | - |
| GUN FIGURES | 10 | not checked | - | - | - | - |
| HIS CHARGE BY HIS RUN | 33 | 32 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 30 | 29 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 4 | 1 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 25 | 24 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 34 | 33 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 14 | 7 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 67 | 63 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 2 | 2 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN RUN | 18 | 18 | 0 | 0.00 | - | - |
| HOLD ODDS | 164 | 164 | 0 | 0.00 | - | - |
| HONEST WORTH | 3 | 3 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 13 | 13 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 3 | 3 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 4 | 4 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 5 | 5 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 36 | 27 | 0 | 0.00 | - | - |
| MISSILES ON ONE TARGET | 4 | not checked | - | - | - | - |
| MOVE SPELL NOT WORTH | 1 | not checked | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 3 | trace | - | - | - | - |
| MOVE SPELL SPOT | 5 | not checked | - | - | - | - |
| NO DOUBLE ROUNDS | 3 | 3 | 0 | 0.00 | - | - |
| NO LATE CUT | 1 | 1 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 2 | not checked | - | - | - | - |
| ONE ROUTE | 5 | 5 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 18 | 18 | 0 | 0.00 | - | - |
| OPENS A LANE | 1 | not checked | - | - | - | - |
| OVERRUNS AWAY | 1 | 1 | 0 | 0.00 | - | - |
| PLAN RESULT | 272 | trace | - | - | - | - |
| REAL GROUND | 5 | 5 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 10 | 7 | 0 | 0.00 | - | - |
| RISK BY ARC | 2 | 2 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 3 | 3 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 1 | 1 | 0 | 0.00 | - | - |
| RUN DOWN | 3 | 3 | 0 | 0.00 | - | - |
| SCOUT SPOT | 2 | 2 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 4 | 4 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 2 | 1 | 0 | 0.00 | - | - |
| SET-UP MISSED | 1 | trace | - | - | - | - |
| SHOOTER COUNTED ONCE | 2 | 2 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 38 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 48 | 45 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 1 | 1 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 10 | 10 | 0 | 0.00 | - | - |
| STANDS STILL | 291 | 281 | 0 | 0.00 | - | - |
| SUPPORT NARROWED | 1 | 1 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 6 | not checked | - | - | - | - |
| THE PROMISED MOVE | 1 | not checked | - | - | - | - |
| THE ROW IN ITS ORDER | 30 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 28 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 19 | not checked | - | - | - | - |
| THE TABLE BINDS | 286 | not checked | - | - | - | - |
| WAITS AGAIN | 3 | 3 | 0 | 0.00 | - | - |
| WAR ENGINE JOBS | 6 | 6 | 0 | 0.00 | - | - |

### Off best figure: cora-bb45c30-p2

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 3.00 | 3.00 | 169.7 |
| PROMISE BY ITS OWN SUM | rule | 2.33 | 3.67 | 386.4 |
| ARMY TABLE | rule | 2.00 | 3.33 | 38.4 |
| HOLDER ASSIGNMENT | rule | 1.00 | 1.00 | 27.9 |
| PROMISE SHOT AWAY | rule | 2.00 | - | 13.4 |
| CHAFF PASSED | rule | 0.33 | 0.33 | 2.7 |
| WALKS ON ITS ROUTE | rule | - | 0.67 | 53.3 |
| BEST PRIZE | rule | - | 0.33 | 8.3 |
| CHARIOT NO STATIC JOB | rule | 0.33 | - | 184.1 |
| ONE PROMISE A TARGET | rule | - | 0.33 | 36.0 |
| PROMISE READS THE TABLE | rule | - | 0.33 | 16.6 |

### Plans: cora-bb45c30-p2

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | move | 38.7 | 97% | 2410 | 0 | 0% |
| Mine | shoot | 7.3 | 55% | 522 | 209 | 40% |
| Mine | support | 0.3 | 0% | 2 | 0 | 0% |
| Opponent | charge | 0.3 | 100% | 6 | 10 | 173% |
| Opponent | move | 41.3 | 95% | 2363 | 0 | 0% |
| Opponent | shoot | 2.7 | 50% | 162 | 78 | 48% |

### Battle groups: cora-bb45c30-p2

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 2.0 | 17% | 0% | 0% | - | 0% | 0% | 0% | 100% | 0% |
| Opponent | REDIRECT COUNTER | 1.3 | 0% | - | - | - | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: cora-bb45c30-p2

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 2 | 0 (2) | 0 | 0 | 50 | 100% | - | - | 0 (2) | - | 0 (2) | - |
| Mine | Character | 11 | 24 (11) | 24 | 0 | 0 | 45% | 2.3 | - | 8 (6) | 44 (5) | 24 (11) | - |
| Mine | Clean-up | 2 | 145 (2) | 0 | 145 | 49 | 50% | 6.0 | 189 (1) | - | 99 (1) | 145 (2) | - |
| Mine | Fast Hammer | 10 | 0 (10) | 0 | 0 | 52 | 90% | 6.0 | 0 (6) | 0 (1) | 0 (3) | 0 (7) | 0 (3) |
| Mine | Hammer | 9 | 67 (9) | 33 | 33 | 0 | 44% | 3.2 | 93 (2) | 48 (4) | 83 (3) | 67 (9) | - |
| Mine | Holder | 2 | 220 (2) | 0 | 220 | 0 | 100% | - | 119 (1) | 321 (1) | - | - | 220 (2) |
| Mine | War machine | 4 | 82 (4) | 82 | 0 | 0 | 0% | 1.2 | 82 (4) | - | - | - | 82 (4) |
| Mine | Wizard | 4 | 0 (4) | 0 | 0 | 0 | 75% | 1.0 | 0 (2) | 0 (1) | 0 (1) | 0 (2) | 0 (2) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Chaff | 8 | 23 (8) | 0 | 23 | 33 | 75% | 5.5 | 47 (3) | 0 (4) | 0 (1) | 25 (7) | 0 (1) |
| Opponent | Character | 7 | 11 (7) | 11 | 0 | 16 | 29% | 2.2 | 26 (1) | 14 (3) | 0 (1) | 11 (3) | 14 (2) |
| Opponent | Clean-up | 3 | 0 (3) | 0 | 0 | 0 | 67% | 2.0 | - | 0 (3) | - | 0 (3) | - |
| Opponent | Fast Hammer | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Hammer | 10 | 76 (10) | 8 | 67 | 12 | 60% | 1.5 | 27 (5) | 137 (4) | 0 (1) | 31 (5) | 109 (5) |
| Opponent | Shooter | 4 | 68 (4) | 16 | 52 | 21 | 0% | 2.2 | 0 (1) | 64 (2) | 129 (1) | 44 (3) | 154 (1) |
| Opponent | Wizard | 2 | 0 (2) | 0 | 0 | 126 | 100% | - | - | - | - | - | - |

### Charged fights: cora-bb45c30-p2

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 2 | 217 | 0 | 0.5 | 1.0 | 0 | 0 | +0 | 1 of 1 | 0 of 1 | - | +0 |
| Mine | Chaos Dwarfs | 1 | 1140 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| **Mine** | all armies | 3 | 525 | 0 | 0.3 | 1.0 | 0 | 0 | +0 | 1 of 1 | 0 of 1 | - | +0 |
| Opponent | Ogre Kingdoms | 1 | 170 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Orc & Goblin Tribes | 1 | 0 | 0 | 2.0 | 1.0 | 0 | 0 | +0 | 1 of 2 | 0 of 2 | - | +0 |
| Opponent | Wood Elf Realms | 1 | 200 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| **Opponent** | all armies | 3 | 123 | 0 | 0.7 | 1.0 | 0 | 0 | +0 | 1 of 2 | 0 of 2 | - | +0 |

### Effective charges: cora-bb45c30-p2

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +0) | 0 | 0% (0 of 1) |

### Charged fights, damage counted: cora-bb45c30-p2

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 85 | 158 | +0 | 40 | 0 | +40 | +46.5 |
| Mine | All fights | 1 | 85 | 158 | +0 | 40 | 0 | +40 | +46.5 |
| Opponent | No odds | 2 | 202 | 204 | +0 | 20 | 101 | -82 | -40.3 |
| Opponent | All fights | 2 | 202 | 204 | +0 | 20 | 101 | -82 | -40.3 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| cora-bb45c30-p2 | move | 12 | 3 (25%) | 2 (17%) | 0 (0%) | 9 (75%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Elixir of Power | Opponent | L0319 |
| Fistful of Laurels | Opponent | L0218 |
| Ring of Doom | Mine | L0218, L0235 |

# Doctrine scorecard: cora-bb45c30-p48

### Scorecard: cora-bb45c30-p48

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L2535 | 3 | 1 | Mine | no | 4 | 4 | 2 | 0 | 1 | 0 | 0 | 168 |
| L2535 | 3 | 1 | Opponent | yes | 7 | 2 | 3 | 2 | 0 | 0 | 0 | 0 |
| L2735 | 5 | 1 | Mine | yes | - | 2 | 3 | 6 | 0 | 0 | 0 | 0 |
| L2735 | 5 | 1 | Opponent | yes | - | 3 | 3 | 4 | 0 | 0 | 0 | 399 |
| L3033 | 3 | 1 | Mine | yes | 0 | 2 | 4 | 1 | 1 | 0 | 0 | 0 |
| L3033 | 3 | 1 | Opponent | no | 0 | 2 | 4 | 3 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 67% | 2.0 | 2.7 | 3.0 | 2.3 | 0.7 | 0.0 | 0.0 | 56.0 |
| **Average** | | | Opponent | 67% | 3.5 | 2.3 | 3.3 | 3.0 | 0.0 | 0.0 | 0.0 | 133.0 |

### KPIs: cora-bb45c30-p48

Rules off - Opponent only: ONE RUN A PLAN.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 13) | 27% (4 of 15) | 14% (4 of 28) |
| Winner chose to follow up after the loser gave ground |  | 100% (4 of 4); on the table 100% | 80% (4 of 5); on the table 80% | 89% (8 of 9); on the table 89% |
| Winner chose to pursue after the loser fell back in good order |  | 100% (1 of 1); on the table 100% | - | 100% (1 of 1); on the table 100% |
| Winner chose to pursue after the loser fled |  | 0% (0 of 1); on the table 0% | 100% (1 of 1); on the table 100% | 50% (1 of 2); on the table 50% |
| Winner chose to follow up or pursue (all three) |  | 83% (5 of 6); on the table 83% | 83% (5 of 6); on the table 83% | 83% (10 of 12); on the table 83% |
| Magic missiles tried each own turn | 50%+ | 29% (7 of 24) | 33% (6 of 18) | 31% (13 of 42) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 33% (7 of 21) | 35% (6 of 17) | 34% (13 of 38) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | - | - |
| Points that never fought | lower | 50% (3024 of 5999) | 47% (2838 of 6000) | 49% (5862 of 11999) |
|   infantry points that never fought | lower | 56% (437 of 780) | 87% (1668 of 1918) | 78% (2105 of 2698) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 78% (14 of 18) | 65% (22 of 34) | 69% (36 of 52) |
| Bound items with a magic missile used (at least once a game) |  | 0.0 uses a game | 50% (2 of 4); 1.3 uses a game | 50% (2 of 4); 0.7 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 100% (1 of 1); 0.3 uses a game | 0% (0 of 1); 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 74% (3538 of 4808) | 61% (3617 of 5962) | 66% (7155 of 10770) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 2.7 (47%) | 2.7 (67%) | 5.3 (55%) |
| MARCHED: its unit marched | 1.3 (24%) | 1.0 (25%) | 2.3 (24%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.3 (8%) | 0.3 (3%) |
| GONE: slain | 1.0 (18%) | 0.0 (0%) | 1.0 (10%) |
| STUPIDITY: Stupidity | 0.7 (12%) | 0.0 (0%) | 0.7 (7%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.3 | 2.3 | 2.7 | 4.3 | 1.7 | 2.0 |
| not cast | 3.7 | 0.7 | 3.3 | 9.7 | 4.3 | 22.0 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.0 (5%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.7 (100%) | 0.3 (10%) | 5.3 (55%) | 2.0 (46%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.3 (24%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.0 (0%) | 0.3 (10%) | 0.3 (3%) | 0.3 (8%) | 0.0 (0%) |
| GONE: slain | 0.0 (0%) | 0.0 (0%) | 0.3 (10%) | 1.0 (10%) | 0.0 (0%) | 2.0 (9%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (7%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.0 (46%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 3.7 (100%) | 0.0 (0%) | 2.3 (70%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 19.0 (86%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.0 a game | 1.7 a game | 1.3 a game |
| stood (cast and not dispelled) | 33% (1 of 3) | 40% (2 of 5) | 38% (3 of 8) |
| the unit moved after it | 100% (1 of 1) | 0% (0 of 2) | 33% (1 of 3) |
| it charged on its next turn | 0% (0 of 1) | 0% (0 of 2) | 0% (0 of 3) |
| the enemy charged it first | 0% (0 of 1) | 0% (0 of 2) | 0% (0 of 3) |
| it fought by the end of its next turn | 0% (0 of 1) | 0% (0 of 2) | 0% (0 of 3) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 1) | 0% (0 of 2) | 0% (0 of 3) |
| none of these (no charge, no fight, no charge escaped) | 100% (1 of 1) | 100% (2 of 2) | 100% (3 of 3) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 0% (0 of 3) | 72% (66 of 92) | 69% (66 of 95) |
|   cavalry | - | 77% (34 of 44) | 77% (34 of 44) |
|   character | 0% (0 of 3) | 68% (13 of 19) | 59% (13 of 22) |
|   infantry | - | 66% (19 of 29) | 66% (19 of 29) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 0.0 (0%) | 4.3 (50%) | 4.3 (45%) |
| CHARGED: it charged | 1.0 (100%) | 2.3 (27%) | 3.3 (34%) |
| IN COMBAT: it fought this turn or the last | 0.0 (0%) | 1.0 (12%) | 1.0 (10%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.0 (0%) | 1.0 (12%) | 1.0 (10%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 16.3 | 1.7 | 92% | 1.8 pts | 29 pts |
| character | 4.7 | 1.3 | 71% | 9.4 pts | 44 pts |
| infantry | 7.7 | 1.7 | 83% | 6.5 pts | 50 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 5.3 | 4.0 | 4.7 |
| Charges that made contact a game | 3.0 | 3.0 | 3.0 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.00 declared, 0.00 contact (4 units) | - | 0.00 declared, 0.00 contact (4 units) |
|   per unit a game, units carrying another wizard (or one alone) | 1.67 declared, 1.00 contact (3 units) | - | 1.67 declared, 1.00 contact (3 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.50 declared, 0.27 contact (22 units) | 0.39 declared, 0.29 contact (31 units) | 0.43 declared, 0.28 contact (53 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 73% (8 of 11) | 100% (2 of 2) | 100% (1 of 1) | 79% (11 of 14) |
| Character in a unit | 100% (3 of 3) | 67% (2 of 3) | 0% (0 of 1) | 71% (5 of 7) |
| Character on its own | 100% (2 of 2) | 100% (3 of 3) | 40% (2 of 5) | 70% (7 of 10) |
| Infantry | 58% (7 of 12) | 67% (2 of 3) | - | 60% (9 of 15) |
| Monster | - | 100% (1 of 1) | - | 100% (1 of 1) |
| Monstrous | 60% (3 of 5) | - | - | 60% (3 of 5) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Vampire Counts | 2 | 80% (4 of 5); on the table 80% | 29% (7 of 24) | 50% | 83% (10 of 12) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 1 | 100% (1 of 1); on the table 100% | - | 52% | 67% (4 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Wood Elf Realms | 3 | 83% (5 of 6); on the table 83% | 33% (6 of 18) | 47% | 65% (22 of 34) | 50% (2 of 4); 1.3 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (cora-bb45c30-p48, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 56% (5) | - | 56% (5) |
| ...free all their last turn and able to turn (per game) | 1.67 | 0.00 | 1.67 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 1.67 | 0.00 | 1.67 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.33 | 0.00 | 0.33 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: cora-bb45c30-p48

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.7 | 0.7 |
| Strategy | Charge objectives carried out (made contact) | 57% (8 of 14) | 57% (4 of 7) |
| Strategy | Shoot objectives carried out (shot that target) | 0% (0 of 2) | 29% (2 of 7) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (2 of 2) | - |
| Strategy | Hexes on a unit its side charged or shot that turn | - | 100% (2 of 2) |
| Strategy | Joined characters whose unit fought | 0% (0 of 3) | 40% (2 of 5) |
| Strategy | Lone characters that fought | 55% (6 of 11) | 100% (3 of 3) |
| Movement | Charges halted short of contact | 0.3 | 0.0 |
| Movement | Idle units | 2.3 | 3.0 |
| Movement | Points that never moved of their own | 56.0 | 133.0 |
| Movement | Fights charged into per game | 3.0 | 3.0 |
| Movement | Charges with odds: long shots (under 50%) | 4 of 8, net -136 | 1 of 6, net +920 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 8 | 1 of 6, net +0 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 1 of 8, net +0 | 0 of 6 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 of 8, net +0 | 3 of 6, net +95 |
| Shooting | Shots by shooting units (incl. breath weapons) | 1.0 | 23.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 0% (0 of 3) | 69% (49 of 71) |
| Shooting | Points destroyed by shooting units | 0.0 | 28.3 |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | 1.0 | 1.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 0% (0 of 3) | 50% (2 of 4) |
| Magic | Wounds caused by magic missiles | - | 1.7 |
| Magic | Wounds caused by other spells | 6.0 | 1.3 |
| Magic | Points destroyed by magic (all spells) | 90.7 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 2.0 / 0.7 / 1.3 / 1.0 | 1.3 / 0.7 / 0.3 / 0.7 |
| Combat | Points destroyed in combat | 112.7 | 558.0 |
| Combat | Points run down | 92.3 | 95.0 |
| Combat | Net points per charged fight, damage counted | -13 | +57 |
| Combat | Net per 100 charger points, damage counted | -5.5 | +21.3 |
| Combat | First round won (charged fights) | 56% | 67% |
| Combat | Net points per charged fight | -34 | +102 |
| Combat | Net points per supported fight / lone fight | - / -34 | - / +102 |
| Combat | Charged fights on a top-3 enemy unit | 2 of 9 | 4 of 9 |
| Game | Points lost | 680.7 | 357.7 |
| Game | VP from objectives | 593.3 | 680.0 |
| Game | Lone holders (player turns) | 2.0 | 3.5 |

- Mine won / drew / lost: 1 / 1 / 1 of 3 ended games (of 3); mean margin (Mine - Opponent) -314 VP
- The side that went first won 0 of 2 games with a winner
- Points traded per game (both sides' losses): 1038
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: cora-bb45c30-p48

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | - | - | - | - | 0.3 | +2.3 | 0.0 | 0.0 |
| ARMY TABLE | 21.3 | +236.5 | 0.0 | 33.3 | 39.3 | +449.5 | 0.0 | 224.0 |
| ASSAILMENT BY POINTS | 0.3 | +2.2 | 0.0 | 0.0 | 0.3 | +0.8 | 0.0 | 0.0 |
| BACKUP TARGETS | 1.0 | +2.1 | 0.0 | 0.0 | - | - | - | - |
| BEST PRIZE | 0.3 | +1.1 | 36.3 | 0.0 | - | - | - | - |
| BLOWS WHERE AIMED | 0.3 | +16.3 | 0.0 | 95.0 | - | - | - | - |
| CAST JOB | 0.7 | +0.7 | 0.0 | 0.0 | - | - | - | - |
| CASTER AWAY FROM SCREEN | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | 9.0 | +240.0 | 0.0 | 45.0 | 0.3 | +27.8 | 0.0 | 0.0 |
| CHAFF PASSED | - | - | - | - | 0.7 | -3.5 | 0.0 | 0.0 |
| CHALLENGE BY POINTS | 0.3 | +20.2 | 0.0 | 84.7 | 1.0 | +64.1 | 0.0 | 36.3 |
| CHARACTER GUNS | - | - | - | - | 6.7 | +0.0 | 0.0 | 0.0 |
| CHARGE LIST READ AGAIN | 0.3 | +1.4 | 0.0 | 32.7 | - | - | - | - |
| CHARGE LOSSES | 21.7 | -769.5 | 0.0 | 434.3 | 5.3 | -505.7 | 0.0 | 367.3 |
| CHARGE NOT DECLARED | 0.3 | +0.0 | 0.0 | 16.7 | - | - | - | - |
| CHARGE NOW FIRST | 2.0 | +0.0 | 244.3 | 133.7 | 2.0 | +0.0 | 336.7 | 0.0 |
| CLOSES ON WHAT IT BEATS | 16.0 | +0.0 | 0.0 | 16.7 | 8.0 | +0.0 | 0.0 | 44.3 |
| COMBAT PIVOT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CONTINUE AHEAD WEIGHED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CONVEYANCE SEARCH | 1.0 | +139.9 | 87.0 | 140.7 | 1.3 | +126.8 | 0.0 | 0.0 |
| COVER ONCE | 7.7 | -367.6 | 0.0 | 49.3 | 10.7 | -295.7 | 0.0 | 116.0 |
| DENIED BY THE FIGHT | 1.0 | -9.1 | 86.0 | 31.7 | - | - | - | - |
| DEPLOY BY FIGURES | 7.0 | +35.9 | 0.0 | 0.0 | 10.0 | -110.5 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | 0.7 | -10.5 | 164.7 | 0.0 | 0.3 | -42.9 | 132.7 | 0.0 |
| EDGE GIVE GROUND | 0.3 | +23.7 | 0.0 | 84.7 | - | - | - | - |
| EXACT ROUND | 3.3 | +18.3 | 86.0 | 315.7 | 2.0 | +16.8 | 144.3 | 0.0 |
| FALL BACK GOOD ORDER | 4.0 | +5.2 | 356.0 | 113.3 | 1.7 | +0.0 | 109.7 | 0.0 |
| FALLBACK BY WORTH | 1.0 | +14.4 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| FALLS SHORT | 21.0 | +256.0 | 0.0 | 315.0 | - | - | - | - |
| FEATURE BUFFS | - | - | - | - | 1.7 | +14.4 | 0.0 | 38.0 |
| FIGHT TO THE END | 1.0 | +12.8 | 0.0 | 84.7 | 0.7 | +15.3 | 49.0 | 0.0 |
| FIRE IN ORDER | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| FIVE ACTION | 80.0 | +5021.4 | 356.0 | 1134.7 | 94.0 | +6939.5 | 502.3 | 1078.0 |
| FLANK NOT WEIGHED | 8.7 | +0.0 | 0.0 | 235.7 | 4.0 | +0.0 | 0.0 | 127.7 |
| FOCUS FIRE | - | - | - | - | 0.3 | +13.2 | 28.3 | 0.0 |
| FOLLOW UP WEIGHED | 1.0 | +246.4 | 0.0 | 49.0 | 2.3 | +285.0 | 0.0 | 0.0 |
| FOUR ROUNDS | 5.3 | +347.0 | 356.0 | 315.7 | 2.7 | +405.6 | 361.7 | 0.0 |
| FREED FROM HIS FIGHT | 5.3 | +0.0 | 0.0 | 265.3 | 5.0 | +0.0 | 0.0 | 206.7 |
| FRIEND CHARGES FIRST | 0.3 | -4.9 | 0.0 | 0.0 | - | - | - | - |
| GIVES UP | 0.7 | -4.0 | 0.0 | 95.0 | 0.3 | -3.3 | 0.0 | 0.0 |
| GIVES UP ITS SCREEN | 0.3 | -5.0 | 0.0 | 15.0 | - | - | - | - |
| GOAL WALK | 6.3 | +473.3 | 0.0 | 0.0 | 19.3 | +1484.9 | 0.0 | 41.7 |
| HARD STAY DROPPED | 0.7 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 52.7 |
| HE REFORMS ONCE FREED | 3.0 | +0.0 | 0.0 | 265.3 | 4.7 | +0.0 | 0.0 | 172.0 |
| HELPER UNSEEN | 0.7 | +0.0 | 0.0 | 31.7 | - | - | - | - |
| HIS CHARGE BY HIS RUN | 13.0 | +0.0 | 0.0 | 265.3 | 4.0 | +0.0 | 0.0 | 367.3 |
| HIS CHARGE DENIED | 0.7 | +33.7 | 0.0 | 111.7 | 0.7 | +34.1 | 84.7 | 0.0 |
| HIS CHARGE LIST | 6.0 | +0.0 | 0.0 | 0.0 | 11.3 | +0.0 | 0.0 | 52.7 |
| HIS LEGAL MOVES | 3.3 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 76.0 |
| HIS MOVE AND SHOT | 3.0 | -35.9 | 0.0 | 0.0 | 1.3 | -24.8 | 0.0 | 0.0 |
| HIS ONE QUARTER | 1.0 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 105.3 |
| HIS OWN BEST MOVE | 11.0 | +0.0 | 0.0 | 0.0 | 7.7 | +0.0 | 0.0 | 112.3 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 60.3 | +1824.4 | 0.0 | 678.3 | 33.3 | +207.6 | 0.0 | 415.3 |
| HIS SHOTS BY HIS RUN | 50.0 | +715.4 | 0.0 | 645.0 | 15.7 | +113.1 | 0.0 | 443.7 |
| HIS TURN DENIED | 1.3 | +66.8 | 124.0 | 37.7 | - | - | - | - |
| HIS TURN RUN | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 14.3 | +0.0 | 0.0 | 376.0 | 16.7 | +0.0 | 0.0 | 577.3 |
| HOLDER ASSIGNMENT | 9.0 | +622.1 | 0.0 | 188.0 | 9.7 | +758.6 | 0.0 | 288.7 |
| HOLDS AMBUSHERS | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HONEST WORTH | 4.3 | -165.3 | 356.0 | 183.0 | 2.7 | -146.3 | 361.7 | 0.0 |
| IDLE COST | 19.0 | -221.9 | 0.0 | 177.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 2.3 | +0.0 | 0.0 | 45.3 | 3.0 | +0.0 | 0.0 | 157.3 |
| LANE BY FIGURES | 0.3 | +4.5 | 0.0 | 0.0 | 0.7 | +50.8 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 3.3 | +0.0 | 0.0 | 407.7 | 16.0 | +0.0 | 806.7 | 173.0 |
| LONE CHARACTER SAFE SPOT | 0.3 | +33.4 | 0.0 | 0.0 | - | - | - | - |
| LONG SHOT | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +2.7 | 25.0 | 0.0 |
| LOST AFTER ESCAPE | 3.0 | +1.4 | 270.0 | 132.7 | 1.0 | -1.4 | 132.7 | 0.0 |
| LURE BY WHAT IT DRAWS | 0.7 | -29.9 | 0.0 | 0.0 | 0.7 | -29.8 | 0.0 | 0.0 |
| MANOEUVRE | 1.7 | +17.4 | 0.0 | 0.0 | 0.7 | -5.0 | 0.0 | 0.0 |
| MARCH BY THE SUM | 0.7 | +76.0 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | - | - | - | - | 2.0 | +67.6 | 0.0 | 172.0 |
| MARCH OF THE TABLE | 0.3 | +11.1 | 0.0 | 0.0 | 0.3 | +5.0 | 0.0 | 0.0 |
| MARCH OVER CASTS | 1.0 | -71.5 | 0.0 | 70.3 | 1.3 | +195.1 | 0.0 | 86.0 |
| MARCH WHEELS ONLY | 2.3 | +0.0 | 0.0 | 45.3 | 1.7 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 2.0 | +6.8 | 0.0 | 15.0 | 1.3 | +21.6 | 0.0 | 86.0 |
| MEETS IN TIME | 4.0 | +174.0 | 0.0 | 0.0 | 5.7 | +191.1 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 3.0 | +52.9 | 0.0 | 98.7 | 5.3 | +179.9 | 0.0 | 138.7 |
| MISSILES NEXT TURN | 5.7 | +14.2 | 0.0 | 197.3 | 6.0 | +132.3 | 0.0 | 224.7 |
| MOVE ORDER | 2.0 | +0.0 | 22.7 | 28.3 | 2.7 | +0.0 | 0.0 | 0.0 |
| MOVE SPELL OUT OF RANGE | - | - | - | - | 2.7 | -55.1 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 11.3 | +1603.9 | 0.0 | 0.0 | 2.3 | +98.3 | 0.0 | 36.3 |
| NEARER NOT NEEDED | 8.0 | +322.2 | 0.0 | 132.7 | 7.0 | +343.4 | 0.0 | 202.7 |
| NEXT CHARGE BY LIST | 10.7 | +1542.7 | 0.0 | 0.0 | 1.0 | +70.7 | 70.3 | 0.0 |
| NEXT OBJECTIVE NEARER | 0.3 | -3.3 | 0.0 | 0.0 | - | - | - | - |
| NO DOUBLE ROUNDS | 5.0 | -295.3 | 356.0 | 299.0 | 2.0 | -140.2 | 158.7 | 0.0 |
| NO LATE CUT | 1.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | - | - | - | - | 2.7 | -4.7 | 0.0 | 0.0 |
| OFF BEST | 5.0 | -140.8 | 0.0 | 28.3 | 5.7 | -127.5 | 0.0 | 38.0 |
| ONE CHALLENGE TEST | 0.3 | +4.1 | 0.0 | 0.0 | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 86.0 |
| ONE FIGHT FORMULA | 6.0 | -100.3 | 0.0 | 95.3 | 2.0 | -33.8 | 0.0 | 0.0 |
| ONE JOINT FIGURE | 0.7 | +14.4 | 0.0 | 31.7 | - | - | - | - |
| ONE OBJECTIVE FORMULA | 3.3 | +13.5 | 0.0 | 165.3 | 3.3 | +52.7 | 0.0 | 86.0 |
| ONE PROMISE A TARGET | 0.7 | -89.1 | 0.0 | 0.0 | - | - | - | - |
| ONE ROUTE | 2.3 | +0.0 | 0.0 | 45.3 | 1.7 | +0.0 | 0.0 | 0.0 |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| OPENS UP | 0.7 | +34.9 | 44.3 | 0.0 | - | - | - | - |
| OVERRUNS AWAY | 2.0 | +10.9 | 232.0 | 49.0 | 0.3 | +8.2 | 25.0 | 0.0 |
| OWN CAST FIRST | 0.3 | -1.1 | 0.0 | 0.0 | - | - | - | - |
| PATHS CROSS | 2.0 | -8.7 | 0.0 | 0.0 | 0.7 | +170.5 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.3 | -31.4 | 0.0 | 0.0 | - | - | - | - |
| PLAN RESULT | 45.3 | +252.6 | 363.3 | 1221.0 | 43.7 | +439.5 | 286.3 | 632.0 |
| PROMISE BELOW ZERO | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE BY ITS OWN SUM | 10.0 | -163.5 | 0.0 | 0.0 | 11.0 | -282.4 | 0.0 | 36.3 |
| PROMISE IN STEPS | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 70.3 | 0.0 |
| PROMISE KNOWS THE FIGHT | 0.3 | -0.3 | 0.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | 22.7 | +2347.4 | 105.3 | 190.7 | 23.3 | +2805.9 | 211.0 | 105.3 |
| REAL GROUND | 2.3 | +0.0 | 0.0 | 45.3 | 1.7 | +0.0 | 0.0 | 0.0 |
| REDIRECT BY WHAT IT STOPS | 1.0 | +27.6 | 0.0 | 0.0 | 2.0 | +24.7 | 0.0 | 12.7 |
| REDIRECT COUNTER | 2.3 | +100.8 | 0.0 | 25.0 | 1.0 | -15.7 | 0.0 | 6.3 |
| REDIRECT FOR A FRIEND IN REACH | 3.0 | +35.5 | 0.0 | 52.7 | 2.0 | +106.1 | 0.0 | 0.0 |
| REDIRECT WEIGHED | 1.0 | +1.1 | 36.3 | 32.7 | 0.3 | +0.0 | 0.0 | 0.0 |
| REFORMS TO MEET IT | 2.7 | -88.1 | 0.0 | 0.0 | 0.3 | -1.4 | 0.0 | 0.0 |
| RESERVE FALL BACK | 0.3 | +8.0 | 0.0 | 0.0 | 0.7 | +246.8 | 0.0 | 0.0 |
| RISK BY ARC | 4.7 | -40.6 | 356.0 | 220.7 | 2.0 | -2.9 | 361.7 | 0.0 |
| RISK ON THE WAY | 1.0 | +0.0 | 0.0 | 45.3 | 0.7 | +0.0 | 0.0 | 0.0 |
| ROUNDS AFTER TERROR | 2.0 | -25.4 | 308.0 | 84.7 | - | - | - | - |
| RUN DOWN | 3.7 | -41.6 | 349.7 | 204.0 | - | - | - | - |
| SAFER THAN THE JOB | 0.3 | +2.3 | 0.0 | 0.0 | - | - | - | - |
| SCREEN BY WHAT IT SAVES | 5.0 | -32.8 | 0.0 | 30.0 | 0.7 | -45.6 | 0.0 | 0.0 |
| SEARCH SPOT | 1.3 | +19.2 | 0.0 | 22.7 | 0.7 | +0.4 | 0.0 | 0.0 |
| SECOND LOOK | 0.3 | +1.4 | 0.0 | 32.7 | 0.3 | +13.4 | 0.0 | 0.0 |
| SET UP BY THE SET | 2.0 | -3.7 | 0.0 | 0.0 | - | - | - | - |
| SET UP TOGETHER | 0.3 | +0.2 | 0.0 | 15.0 | - | - | - | - |
| SET-UP ANY TARGET | 0.3 | +9.4 | 16.7 | 70.3 | 0.7 | +113.7 | 0.0 | 0.0 |
| SET-UP MISSED | - | - | - | - | 0.3 | +53.6 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | - | - | - | - | 0.7 | +0.7 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 2.0 | +0.0 | 0.0 | 70.3 | 2.3 | +0.0 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.0 | +6.8 | 0.0 | 140.7 | 1.3 | +21.8 | 0.0 | 0.0 |
| SHOT OR CHARGE | - | - | - | - | 0.3 | -4.8 | 70.3 | 0.0 |
| SHOT RISK POINTS | 45.3 | -193.7 | 0.0 | 628.3 | 4.0 | +4.3 | 0.0 | 107.3 |
| SHOTS AFTER THE MOVES | - | - | - | - | 2.0 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 0.7 | +16.0 | 0.0 | 0.0 | 21.0 | +262.4 | 0.0 | 334.0 |
| SPELL SETS UP CHARGE | 0.3 | +9.4 | 16.7 | 70.3 | 0.7 | +113.7 | 0.0 | 0.0 |
| SPELL WORTH | 2.0 | +1.9 | 0.0 | 0.0 | 1.3 | +5.0 | 0.0 | 0.0 |
| SPELLS IN THE FIGHT | 0.3 | -11.9 | 0.0 | 22.7 | 0.7 | -12.2 | 0.0 | 0.0 |
| SPOT AS THE GAME MOVES | 13.0 | +0.0 | 0.0 | 265.0 | 4.7 | +0.0 | 0.0 | 113.3 |
| STAND AND SHOOT | 0.7 | -2.5 | 105.3 | 0.0 | - | - | - | - |
| STANDS FOR A REASON | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| STANDS STILL | 15.0 | +0.0 | 0.0 | 140.7 | 40.3 | +0.0 | 140.7 | 165.3 |
| STAY WORTH | - | - | - | - | 14.7 | +74.0 | 140.7 | 217.3 |
| STRIKE BY THE ODDS | 0.3 | +13.3 | 34.7 | 0.0 | - | - | - | - |
| STUPIDITY NEXT TURN | 3.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SUPPORT ADDS | 4.7 | +141.4 | 0.0 | 33.3 | 5.0 | +235.0 | 0.0 | 168.0 |
| SUPPORT NARROWED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| SUPPORT WORKED OUT | 4.7 | +141.4 | 0.0 | 33.3 | 5.0 | +235.0 | 0.0 | 168.0 |
| SURE REACH TOGETHER | - | - | - | - | 0.7 | +1.0 | 0.0 | 6.3 |
| SWIFTSTRIDE BY POINTS | 0.3 | +0.9 | 0.0 | 32.7 | - | - | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 2.0 | +0.0 | 0.0 | 15.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| THE PROMISE ADDS | 0.3 | -81.6 | 0.0 | 0.0 | 0.3 | -10.7 | 70.3 | 0.0 |
| THE ROW IN ITS ORDER | 5.0 | +0.0 | 0.0 | 25.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 4.7 | +0.0 | 0.0 | 190.3 | - | - | - | - |
| THE STEP BACK IS MADE | 1.3 | +0.0 | 0.0 | 25.0 | - | - | - | - |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 43.0 | +0.0 | 0.0 | 452.0 | 45.7 | +0.0 | 0.0 | 504.3 |
| TIED UP BY THE SUM | 2.3 | +307.9 | 209.0 | 32.7 | 0.3 | +41.6 | 70.3 | 0.0 |
| TIME ON OUR SIDE | - | - | - | - | 51.3 | +532.3 | 0.0 | 564.3 |
| WAITS AGAIN | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| WHAT THE JOINER ADDS | - | - | - | - | 0.7 | -18.4 | 98.0 | 0.0 |
| WHO FIGHTS | 1.0 | -35.7 | 0.0 | 132.7 | 0.3 | +0.2 | 25.0 | 0.0 |
| WHO HITS BACK | - | - | - | - | 0.3 | +65.1 | 0.0 | 0.0 |
| WHOLE FIGHT | - | - | - | - | 0.3 | -0.1 | 49.0 | 0.0 |
| WHOLE FIGHT DANGER | 2.3 | -186.9 | 0.0 | 0.0 | 3.3 | -468.8 | 0.0 | 329.3 |
| WOUNDS ON THE RANKS | 3.3 | +66.3 | 0.0 | 265.3 | 1.0 | +46.2 | 0.0 | 0.0 |

### Rule changes: cora-bb45c30-p48

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 182 | 182 | 116 | 38.67 | +1864 | +16.1 |
| LEGAL CHARGES ONLY | 58 | 58 | 58 | 19.33 | +0 | +0.0 |
| HOLDER ASSIGNMENT | 56 | 56 | 49 | 16.33 | +4989 | +101.8 |
| HIS SHOT LIST | 281 | 272 | 47 | 15.67 | +1096 | +23.3 |
| DEPLOY BY FIGURES | 51 | 51 | 35 | 11.67 | +412 | +11.8 |
| OFF BEST | 32 | 32 | 32 | 10.67 | -804 | -25.1 |
| FIVE ACTION | 522 | 503 | 31 | 10.33 | +1808 | +58.3 |
| THE TABLE AGAIN | 36 | 36 | 26 | 8.67 | +0 | +0.0 |
| MOVE TO CHARGE COMPUTED | 41 | 35 | 23 | 7.67 | +1753 | +76.2 |
| HIS SHOTS BY HIS RUN | 197 | 189 | 22 | 7.33 | +296 | +13.5 |
| NEXT CHARGE BY LIST | 35 | 31 | 22 | 7.33 | +1890 | +85.9 |
| HARD STAY DROPPED | 20 | 20 | 20 | 6.67 | +0 | +0.0 |
| PROMISE BY ITS OWN SUM | 63 | 63 | 20 | 6.67 | -1338 | -66.9 |
| CHAFF IN THE MOVE | 28 | 28 | 18 | 6.00 | +88 | +4.9 |
| TIME ON OUR SIDE | 154 | 120 | 17 | 5.67 | +59 | +3.5 |
| FOUR ROUNDS | 24 | 24 | 14 | 4.67 | +670 | +47.9 |
| MOVE ORDER | 14 | 14 | 14 | 4.67 | +0 | +0.0 |
| QUARTER ODDS | 138 | 132 | 14 | 4.67 | +1010 | +72.1 |
| SHOT RISK POINTS | 148 | 143 | 14 | 4.67 | +455 | +32.5 |
| GOAL WALK | 77 | 76 | 13 | 4.33 | +704 | +54.2 |
| IDLE COST | 57 | 41 | 13 | 4.33 | +43 | +3.3 |
| REDIRECT FOR A FRIEND IN REACH | 15 | 15 | 13 | 4.33 | +112 | +8.6 |
| ADVANCE LANE KEPT | 11 | 11 | 11 | 3.67 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 10 | 10 | 10 | 3.33 | +1594 | +159.4 |
| COVER ONCE | 55 | 33 | 9 | 3.00 | +208 | +23.1 |
| MEETS IN TIME | 29 | 29 | 9 | 3.00 | +409 | +45.5 |
| PATHS CROSS | 8 | 8 | 8 | 2.67 | +486 | +60.7 |
| TIED UP BY THE SUM | 8 | 8 | 6 | 2.00 | +209 | +34.8 |
| CHARGE LOSSES | 81 | 76 | 5 | 1.67 | +303 | +60.6 |
| CASTS FROM BEHIND | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| CHALLENGE BY POINTS | 4 | 4 | 4 | 1.33 | +253 | +63.2 |
| CHARGE NOW FIRST | 12 | 12 | 4 | 1.33 | -339 | -84.9 |
| FALLS SHORT | 63 | 50 | 4 | 1.33 | +32 | +8.1 |
| MARCH CHECK | 6 | 6 | 4 | 1.33 | +81 | +20.1 |
| REDIRECT WEIGHED | 4 | 4 | 4 | 1.33 | +138 | +34.6 |
| SCREEN BY WHAT IT SAVES | 17 | 17 | 4 | 1.33 | +19 | +4.6 |
| SEARCH SPOT | 6 | 6 | 4 | 1.33 | +59 | +14.8 |
| SUPPORT ADDS | 29 | 29 | 4 | 1.33 | +122 | +30.4 |
| SUPPORT WORKED OUT | 29 | 29 | 4 | 1.33 | +122 | +30.4 |
| LANE BY FIGURES | 3 | 3 | 3 | 1.00 | +166 | +55.2 |
| MAX FOR POSITIONING | 10 | 9 | 3 | 1.00 | +4 | +1.4 |
| NEARER NOT NEEDED | 45 | 42 | 3 | 1.00 | +88 | +29.5 |
| REDIRECT BY WHAT IT STOPS | 9 | 9 | 3 | 1.00 | +20 | +6.7 |
| RESERVE FALL BACK | 3 | 3 | 3 | 1.00 | +764 | +254.8 |
| ASSAILMENT BY POINTS | 2 | 2 | 2 | 0.67 | +9 | +4.5 |
| CHAFF PASSED | 2 | 2 | 2 | 0.67 | -10 | -5.2 |
| EXACT ROUND | 16 | 16 | 2 | 0.67 | +18 | +8.8 |
| HIS CHARGE DENIED | 4 | 4 | 2 | 0.67 | +62 | +31.0 |
| HIS TURN DENIED | 4 | 4 | 2 | 0.67 | +47 | +23.5 |
| HOLDS AMBUSHERS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| MANOEUVRE | 7 | 7 | 2 | 0.67 | +52 | +26.1 |
| MARCH BY THE SUM | 2 | 2 | 2 | 0.67 | +228 | +114.0 |
| MARCH OF THE TABLE | 2 | 2 | 2 | 0.67 | -48 | -24.2 |
| ONE PROMISE A TARGET | 2 | 2 | 2 | 0.67 | -267 | -133.7 |
| RISK BY ARC | 20 | 20 | 2 | 0.67 | +12 | +6.1 |
| SECOND LOOK | 2 | 2 | 2 | 0.67 | +45 | +22.3 |
| SET UP BY THE SET | 6 | 6 | 2 | 0.67 | +150 | +74.8 |
| SHOOTERS IN TWO RANKS | 2 | 2 | 2 | 0.67 | +2 | +1.0 |
| SHOOTS FROM THE BEST SPOT | 7 | 7 | 2 | 0.67 | +3 | +1.4 |
| SHOTS IN THE MOVE | 65 | 40 | 2 | 0.67 | +32 | +15.9 |
| SURE REACH TOGETHER | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| THE ROW IN ITS ORDER | 20 | 2 | 2 | 0.67 | +0 | +0.0 |
| AFTERMATH IN POINTS | 1 | 1 | 1 | 0.33 | +7 | +6.8 |
| BEST PRIZE | 1 | 1 | 1 | 0.33 | -9 | -8.7 |
| CAST JOB | 2 | 2 | 1 | 0.33 | +0 | +0.0 |
| CASTER AWAY FROM SCREEN | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CHARGE LIST READ AGAIN | 1 | 1 | 1 | 0.33 | +4 | +4.2 |
| CHARGE NOT DECLARED | 1 | 1 | 1 | 0.33 | -98 | -98.5 |
| COMBAT PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CONTINUE AHEAD WEIGHED | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| DUEL STOPS AT THE KILL | 3 | 3 | 1 | 0.33 | +52 | +52.1 |
| FALLBACK BY WORTH | 4 | 4 | 1 | 0.33 | +43 | +43.1 |
| FIRE IN ORDER | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FOCUS FIRE | 1 | 1 | 1 | 0.33 | +40 | +39.7 |
| HONEST WORTH | 21 | 21 | 1 | 0.33 | +52 | +52.1 |
| MISSILES IN THE MOVE | 25 | 20 | 1 | 0.33 | +80 | +80.5 |
| MISSILES NEXT TURN | 35 | 25 | 1 | 0.33 | +0 | +0.0 |
| ONE OBJECTIVE FORMULA | 20 | 14 | 1 | 0.33 | +17 | +17.4 |
| OPENS UP | 2 | 2 | 1 | 0.33 | +4 | +4.2 |
| OVERRUNS AWAY | 7 | 7 | 1 | 0.33 | +21 | +20.7 |
| OWN CAST FIRST | 1 | 1 | 1 | 0.33 | -3 | -3.4 |
| PIVOT GUARDS FLANK | 1 | 1 | 1 | 0.33 | -94 | -94.1 |
| PROMISE KNOWS THE FIGHT | 1 | 1 | 1 | 0.33 | -1 | -0.9 |
| REDIRECT COUNTER | 10 | 6 | 1 | 0.33 | +39 | +38.6 |
| SAFER THAN THE JOB | 1 | 1 | 1 | 0.33 | +7 | +7.0 |
| STAY WORTH | 44 | 30 | 1 | 0.33 | +0 | +0.1 |
| STRIKE BY THE ODDS | 1 | 1 | 1 | 0.33 | +40 | +39.9 |
| SWIFTSTRIDE BY POINTS | 1 | 1 | 1 | 0.33 | +3 | +2.7 |
| WHO HITS BACK | 1 | 1 | 1 | 0.33 | +165 | +164.6 |
| WHOLE FIGHT DANGER | 17 | 15 | 1 | 0.33 | +17 | +17.4 |
| WOUNDS ON THE RANKS | 13 | 13 | 1 | 0.33 | +82 | +81.8 |
| BACKUP TARGETS | 3 | 1 | 0 | 0.00 | - | - |
| BLOWS WHERE AIMED | 1 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 3 | trace | - | - | - | - |
| CHARACTER GUNS | 20 | 20 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 72 | 71 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 7 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 3 | 3 | 0 | 0.00 | - | - |
| EDGE GIVE GROUND | 1 | 1 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 17 | 17 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 5 | 5 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 5 | 5 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 38 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 31 | 31 | 0 | 0.00 | - | - |
| FRIEND CHARGES FIRST | 1 | 1 | 0 | 0.00 | - | - |
| GIVES UP | 3 | 3 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 1 | 1 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 23 | 23 | 0 | 0.00 | - | - |
| HELPER UNSEEN | 2 | 2 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 51 | 47 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 52 | 52 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 28 | 25 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 13 | 11 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 9 | 9 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 56 | 48 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN RUN | 18 | 18 | 0 | 0.00 | - | - |
| HOLD ODDS | 93 | 93 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 16 | 16 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 4 | 4 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 1 | not checked | - | - | - | - |
| LONG SHOT | 4 | 4 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 12 | 12 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 4 | 4 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 7 | 7 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 12 | 12 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 8 | trace | - | - | - | - |
| NEXT OBJECTIVE NEARER | 1 | 1 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 21 | 21 | 0 | 0.00 | - | - |
| NO LATE CUT | 6 | 6 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 8 | not checked | - | - | - | - |
| ONE CHALLENGE TEST | 1 | 1 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 2 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 24 | 10 | 0 | 0.00 | - | - |
| ONE JOINT FIGURE | 2 | 2 | 0 | 0.00 | - | - |
| ONE ROUTE | 12 | 12 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 18 | 18 | 0 | 0.00 | - | - |
| PLAN RESULT | 267 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE IN STEPS | 2 | 2 | 0 | 0.00 | - | - |
| REAL GROUND | 12 | 12 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 9 | 7 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 5 | 5 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 6 | 6 | 0 | 0.00 | - | - |
| RUN DOWN | 11 | 11 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 1 | 1 | 0 | 0.00 | - | - |
| SET-UP ANY TARGET | 3 | not checked | - | - | - | - |
| SET-UP MISSED | 1 | trace | - | - | - | - |
| SHOOTERS ON THE TABLE | 13 | not checked | - | - | - | - |
| SHOT OR CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| SHOTS AFTER THE MOVES | 6 | 6 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 3 | not checked | - | - | - | - |
| SPELL WORTH | 10 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 3 | 3 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 53 | 44 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 2 | 2 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 1 | 1 | 0 | 0.00 | - | - |
| STANDS STILL | 166 | 157 | 0 | 0.00 | - | - |
| STUPIDITY NEXT TURN | 11 | 8 | 0 | 0.00 | - | - |
| SUPPORT NARROWED | 1 | 1 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 9 | not checked | - | - | - | - |
| THE PROMISE ADDS | 2 | 2 | 0 | 0.00 | - | - |
| THE ROW KEEPS ITS WAY | 14 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 4 | not checked | - | - | - | - |
| THE TABLE BINDS | 266 | not checked | - | - | - | - |
| WAITS AGAIN | 2 | 2 | 0 | 0.00 | - | - |
| WHAT THE JOINER ADDS | 2 | 2 | 0 | 0.00 | - | - |
| WHO FIGHTS | 4 | 4 | 0 | 0.00 | - | - |
| WHOLE FIGHT | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: cora-bb45c30-p48

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 4.67 | 5.00 | 21.4 |
| ARMY TABLE | rule | 2.33 | 5.00 | 50.1 |
| PROMISE BY ITS OWN SUM | rule | 1.33 | 5.33 | 66.9 |
| CHARGE NOW FIRST | rule | 0.67 | 0.67 | 84.8 |
| PATHS CROSS | rule | 1.00 | - | 12.6 |
| HOLDER ASSIGNMENT | rule | 0.33 | 0.33 | 15.4 |
| MARCH OF THE TABLE | rule | 0.33 | 0.33 | 24.2 |
| ONE PROMISE A TARGET | rule | 0.67 | - | 133.7 |
| AFTERMATH NEEDS NEXT CHARGE | gate | - | 0.33 | 5.1 |
| BEST PRIZE | rule | 0.33 | - | 8.7 |
| CHAFF PASSED | rule | - | 0.33 | 9.9 |
| CHARGE NOT DECLARED | rule | 0.33 | - | 98.5 |
| NO REASON | gate | 0.33 | - | 176.0 |
| OWN CAST FIRST | rule | 0.33 | - | 3.4 |
| PIVOT GUARDS FLANK | rule | 0.33 | - | 94.1 |
| PROMISE KNOWS THE FIGHT | rule | 0.33 | - | 0.9 |
| RULE SWITCHED OFF | gate | - | 0.33 | 1.7 |

### Plans: cora-bb45c30-p48

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 4.7 | 43% | 596 | 240 | 40% |
| Mine | join | 5.7 | 94% | 242 | 0 | 0% |
| Mine | move | 31.3 | 98% | 1509 | 0 | 0% |
| Mine | shoot | 0.7 | 50% | 0 | 13 | - |
| Mine | support | 3.0 | 100% | 86 | 0 | 0% |
| Opponent | charge | 2.7 | 75% | 426 | 335 | 78% |
| Opponent | move | 38.0 | 96% | 2509 | 0 | 0% |
| Opponent | shoot | 1.3 | 50% | 67 | 105 | 156% |
| Opponent | support | 1.7 | 80% | 81 | 0 | 0% |

### Battle groups: cora-bb45c30-p48

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 2.3 | 14% | 100% | 0% | - | 0% | 0% | 0% | 100% | 0% |
| Opponent | REDIRECT COUNTER | 1.0 | 67% | 50% | 0% | - | 50% | 0% | 0% | 0% | 50% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: cora-bb45c30-p48

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 9 | 69 (9) | 0 | 69 | 44 | 44% | 3.6 | 89 (7) | 0 (1) | 0 (1) | 78 (8) | 0 (1) |
| Mine | Character | 10 | 42 (10) | 42 | 0 | 15 | 50% | 3.2 | 25 (6) | 55 (4) | - | 32 (4) | 47 (6) |
| Mine | Clean-up | 1 | 0 (1) | 0 | 0 | 100 | 0% | 2.0 | 0 (1) | - | - | 0 (1) | - |
| Mine | Fast Hammer | 8 | 2 (8) | 0 | 2 | 49 | 50% | 3.2 | 0 (2) | 0 (4) | 8 (2) | 0 (1) | 2 (7) |
| Mine | Hammer | 2 | 105 (2) | 39 | 66 | 46 | 50% | 4.0 | 121 (1) | 85 (1) | - | 121 (1) | 85 (1) |
| Mine | Holder | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | 0 (1) | - | - | - | 0 (1) |
| Mine | Support | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | 0 (1) | - | - | - | 0 (1) |
| Mine | Wizard | 4 | 0 (4) | 0 | 0 | 54 | 0% | 1.8 | 0 (3) | - | 0 (1) | 0 (2) | 0 (2) |
| Opponent | Chaff | 2 | 0 (2) | 0 | 0 | 50 | 100% | - | 0 (2) | - | - | 0 (2) | - |
| Opponent | Character | 7 | 53 (7) | 53 | 0 | 0 | 0% | 1.1 | 6 (5) | 227 (1) | 0 (1) | 1 (3) | 79 (4) |
| Opponent | Clean-up | 2 | 41 (2) | 0 | 41 | 50 | 0% | 1.5 | 83 (1) | 0 (1) | - | 83 (1) | 0 (1) |
| Opponent | Fast Hammer | 5 | 26 (5) | 9 | 18 | 39 | 0% | 1.4 | 56 (2) | 0 (2) | 0 (1) | 56 (2) | 0 (3) |
| Opponent | Hammer | 11 | 24 (11) | 24 | 0 | 9 | 64% | 3.2 | 0 (3) | 39 (6) | 21 (2) | 72 (2) | 16 (9) |
| Opponent | Shooter | 8 | 39 (8) | 11 | 28 | 52 | 0% | 1.2 | 73 (2) | 39 (5) | 0 (1) | 56 (3) | 32 (5) |
| Opponent | Wizard | 1 | 0 (1) | 0 | 0 | 0 | 0% | 2.0 | - | - | 0 (1) | - | 0 (1) |

### Charged fights: cora-bb45c30-p48

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Vampire Counts | 2 | 136 | 0 | 3.5 | 1.0 | 0 | 23 | -23 | 2 of 7 | 4 of 7 | - | -23 |
| Mine | Warriors of Chaos | 1 | 0 | 236 | 2.0 | 1.0 | 118 | 192 | -74 | 0 of 2 | 1 of 2 | - | -74 |
| **Mine** | all armies | 3 | 91 | 79 | 3.0 | 1.0 | 26 | 61 | -34 | 2 of 9 | 5 of 9 | - | -34 |
| Opponent | Wood Elf Realms | 3 | 28 | 504 | 3.0 | 1.0 | 168 | 66 | +102 | 4 of 9 | 6 of 9 | - | +102 |

### Effective charges: cora-bb45c30-p48

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Vampire Counts | 7 | 3 (net -54) | 0 | 0 | 0 | 1 (net +0) | 3 (net +0) | 0 | 0% (0 of 7) |
| Mine | Warriors of Chaos | 2 | 1 (net -383) | 0 | 0 | 0 | 0 | 0 | 1 | 0% (0 of 1) |
| Opponent | Wood Elf Realms | 9 | 1 (net +920) | 1 (net +22) | 1 (net +0) | 0 | 0 | 3 (net +95) | 3 | 17% (1 of 6) |

### Charged fights, damage counted: cora-bb45c30-p48

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 4 | 112 | 94 | -136 | 14 | 145 | -131 | -117.1 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 | 223 | 136 | +0 | 58 | 0 | +58 | +26.1 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 471 | 114 | +0 | 0 | 0 | +0 | +0.0 |
| Mine | No odds | 1 | 479 | 109 | +236 | 236 | 0 | +236 | +49.3 |
| Mine | All fights | 9 | 230 | 112 | -34 | 52 | 65 | -13 | -5.5 |
| Opponent | Long shot (under 50%) | 1 | 499 | 348 | +920 | 920 | 0 | +920 | +184.4 |
| Opponent | 50-54% | 1 | 102 | 147 | +22 | 147 | 125 | +22 | +21.6 |
| Opponent | Effective (55-75%) | 1 | 499 | 471 | +0 | 0 | 388 | -388 | -77.8 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 | 374 | 180 | +95 | 95 | 0 | +95 | +25.5 |
| Opponent | No odds | 3 | 69 | 212 | -104 | 53 | 160 | -108 | -156.6 |
| Opponent | All fights | 9 | 270 | 238 | +102 | 168 | 110 | +57 | +21.3 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| cora-bb45c30-p48 | move | 16 | 3 (19%) | 2 (12%) | 3 (19%) | 10 (62%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L2535, L2735 |
| Horn of the Wild Hunt | Opponent | L3033 |
| Invocation of Nehek | Mine | L2535, L2735 |
| Ring of Doom | Opponent | L3033 |

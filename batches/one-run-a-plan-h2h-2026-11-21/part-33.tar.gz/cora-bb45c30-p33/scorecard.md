# Doctrine scorecard: cora-bb45c30-p33

### Scorecard: cora-bb45c30-p33

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L1527 | 3 | 1 | Mine | no | 9 | 3 | 3 | 0 | 1 | 0 | 0 | 0 |
| L1527 | 3 | 1 | Opponent | no | 4 | 4 | 3 | 3 | 1 | 0 | 0 | 0 |
| L1625 | 5 | 1 | Mine | yes | - | 3 | 0 | 2 | 0 | 0 | 0 | 100 |
| L1625 | 5 | 1 | Opponent | yes | - | 3 | 4 | 3 | 0 | 0 | 0 | 0 |
| L1723 | 1 | 1 | Mine | no | 0 | 2 | 7 | 0 | 0 | 0 | 0 | 0 |
| L1723 | 1 | 1 | Opponent | yes | 6 | 2 | 6 | 0 | 1 | 0 | 0 | 0 |
| **Average** | | | Mine | 33% | 4.5 | 2.7 | 3.3 | 0.7 | 0.3 | 0.0 | 0.0 | 33.3 |
| **Average** | | | Opponent | 67% | 5.0 | 3.0 | 4.3 | 2.0 | 0.7 | 0.0 | 0.0 | 0.0 |

### KPIs: cora-bb45c30-p33

Rules off - Opponent only: ONE RUN A PLAN.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 16) | 0% (0 of 16) | 0% (0 of 32) |
| Winner chose to follow up after the loser gave ground |  | 100% (4 of 4); on the table 100% | 75% (6 of 8); on the table 88% | 83% (10 of 12); on the table 92% |
| Winner chose to pursue after the loser fell back in good order |  | - | 100% (1 of 1); on the table 100% | 100% (1 of 1); on the table 100% |
| Winner chose to pursue after the loser fled |  | - | 100% (1 of 1); on the table 100% | 100% (1 of 1); on the table 100% |
| Winner chose to follow up or pursue (all three) |  | 100% (4 of 4); on the table 100% | 80% (8 of 10); on the table 90% | 86% (12 of 14); on the table 93% |
| Magic missiles tried each own turn | 50%+ | - | 78% (14 of 18) | 78% (14 of 18) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | - | 67% (8 of 12) | 67% (8 of 12) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | - | - |
| Points that never fought | lower | 24% (1442 of 6000) | 37% (2226 of 5999) | 31% (3668 of 11999) |
|   infantry points that never fought | lower | 66% (875 of 1332) | 38% (316 of 834) | 55% (1191 of 2166) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 60% (12 of 20) | 65% (11 of 17) | 62% (23 of 37) |
| Bound items with a magic missile used (at least once a game) |  | 100% (2 of 2); 2.3 uses a game | 0.0 uses a game | 100% (2 of 2); 1.2 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 100% (1 of 1); 0.3 uses a game | 0.0 uses a game | 100% (1 of 1); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 56% (2884 of 5135) | 54% (2497 of 4600) | 55% (5381 of 9735) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | - | 1.3 (100%) | 1.3 (100%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 3.3 | 2.0 | 1.7 | 4.7 | 0.0 | 4.0 |
| not cast | 6.7 | 2.0 | 0.3 | 1.3 | 2.0 | 24.0 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.0 (4%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.7 (33%) | 0.0 (0%) | 1.3 (100%) | 2.0 (100%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.3 (5%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | 0.3 (5%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.0 (8%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.3 (17%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 1.0 (15%) | 1.0 (50%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 5.0 (75%) | 0.0 (0%) | 0.3 (100%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 21.0 (88%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.7 a game | 0.0 a game | 0.8 a game |
| stood (cast and not dispelled) | - | - | - |
| the unit moved after it | - | - | - |
| it charged on its next turn | - | - | - |
| the enemy charged it first | - | - | - |
| it fought by the end of its next turn | - | - | - |
| it moved out of a charge the enemy had planned (not charged first) | - | - | - |
| none of these (no charge, no fight, no charge escaped) | - | - | - |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 60% (48 of 80) | 65% (26 of 40) | 62% (74 of 120) |
|   cavalry | 100% (8 of 8) | 91% (10 of 11) | 95% (18 of 19) |
|   character | 33% (3 of 9) | 0% (0 of 7) | 19% (3 of 16) |
|   chariot | 33% (2 of 6) | - | 33% (2 of 6) |
|   infantry | 56% (19 of 34) | 73% (16 of 22) | 62% (35 of 56) |
|   monster | 45% (5 of 11) | - | 45% (5 of 11) |
|   war machine | 92% (11 of 12) | - | 92% (11 of 12) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.0 (19%) | 0.0 (0%) | 2.0 (13%) |
| CHARGED: it charged | 2.0 (19%) | 1.0 (21%) | 3.0 (20%) |
| FLEEING: it fled or was fleeing | 0.3 (3%) | 0.0 (0%) | 0.3 (2%) |
| IN COMBAT: it fought this turn or the last | 2.0 (19%) | 0.7 (14%) | 2.7 (17%) |
| MOVED: a war machine that moved | 0.3 (3%) | 0.0 (0%) | 0.3 (2%) |
| NO TARGET IN RANGE | 1.7 (16%) | 1.3 (29%) | 3.0 (20%) |
| ONLY IN COMBAT: the only targets were in combat | 0.7 (6%) | 1.0 (21%) | 1.7 (11%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.7 (16%) | 0.7 (14%) | 2.3 (15%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 6.3 | 0.3 | 95% | 0.2 pts | 1 pts |
| character | 1.7 | 0.3 | 80% | 0.6 pts | 1 pts |
| chariot | 0.7 | 0.0 | 100% | 0.0 pts | 0 pts |
| infantry | 16.3 | 3.3 | 84% | 6.7 pts | 109 pts |
| monster | 1.7 | 0.7 | 60% | 10.8 pts | 18 pts |
| war machine | 3.7 | 2.0 | 64% | 12.0 pts | 44 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 6.7 | 5.3 | 6.0 |
| Charges that made contact a game | 5.7 | 3.3 | 4.5 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | - | 0.00 declared, 0.00 contact (3 units) | 0.00 declared, 0.00 contact (3 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.50 declared, 0.50 contact (2 units) | 1.50 declared, 0.50 contact (2 units) | 1.00 declared, 0.50 contact (4 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.86 declared, 0.73 contact (22 units) | 0.52 declared, 0.36 contact (25 units) | 0.68 declared, 0.53 contact (47 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 33% (1 of 3) | 100% (2 of 2) | 50% (1 of 2) | 57% (4 of 7) |
| Character in a unit | 100% (3 of 3) | 100% (1 of 1) | - | 100% (4 of 4) |
| Character on its own | 100% (1 of 1) | 0% (0 of 2) | 33% (3 of 9) | 33% (4 of 12) |
| Chariot | 100% (1 of 1) | - | - | 100% (1 of 1) |
| Infantry | 83% (5 of 6) | 100% (2 of 2) | - | 88% (7 of 8) |
| Monster | 60% (3 of 5) | - | - | 60% (3 of 5) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| High Elf Realms | 1 | 100% (1 of 1); on the table 100% | - | 0% | 57% (4 of 7) | 100% (2 of 2); 7.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | - | - | 54% | 67% (4 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Lizardmen | 1 | 100% (3 of 3); on the table 100% | - | 18% | 57% (4 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Tomb Kings of Khemri | 1 | 100% (3 of 3); on the table 100% | - | 10% | 40% (2 of 5) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 2 | 71% (5 of 7); on the table 86% | 78% (14 of 18) | 51% | 75% (9 of 12) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (cora-bb45c30-p33, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 50% (3) | 29% (4) | 35% (7) |
| ...free all their last turn and able to turn (per game) | 0.67 | 0.67 | 1.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.33 | 0.33 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.67 | 0.67 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: cora-bb45c30-p33

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.3 | 3.3 |
| Strategy | Charge objectives carried out (made contact) | 69% (11 of 16) | 54% (7 of 13) |
| Strategy | Shoot objectives carried out (shot that target) | 12% (2 of 17) | 22% (2 of 9) |
| Strategy | Support requests answered (helper made contact too) | 100% (2 of 2) | 100% (2 of 2) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | - | 100% (2 of 2) |
| Strategy | Hexes on a unit its side charged or shot that turn | - | 0% (0 of 1) |
| Strategy | Joined characters whose unit fought | 0% (0 of 1) | 17% (1 of 6) |
| Strategy | Lone characters that fought | 100% (8 of 8) | 75% (6 of 8) |
| Movement | Charges halted short of contact | 0.0 | 0.3 |
| Movement | Idle units | 0.7 | 2.0 |
| Movement | Points that never moved of their own | 33.3 | 0.0 |
| Movement | Fights charged into per game | 5.0 | 2.7 |
| Movement | Charges with odds: long shots (under 50%) | 1 of 12, net +0 | 1 of 6, net +0 |
| Movement | Charges with odds: sweet spot (55-75%) | 3 of 12, net +65 | 1 of 6, net +83 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 5 of 12, net +66 | 1 of 6, net +723 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 of 12, net +248 | 1 of 6, net +175 |
| Shooting | Shots by shooting units (incl. breath weapons) | 13.3 | 10.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 58% (23 of 40) | 26% (8 of 31) |
| Shooting | Points destroyed by shooting units | 0.0 | 0.0 |
| Shooting | War machine shots | 3.7 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 73% (8 of 11) | - |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | - | 3.0 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | - | 56% (5 of 9) |
| Magic | Wounds caused by magic missiles | 0.7 | - |
| Magic | Wounds caused by other spells | 0.3 | 3.0 |
| Magic | Points destroyed by magic (all spells) | 16.7 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.7 / 1.0 / 1.0 / 0.0 | 2.0 / 0.3 / 0.3 / 0.0 |
| Combat | Points destroyed in combat | 536.0 | 522.0 |
| Combat | Points run down | 0.0 | 0.0 |
| Combat | Net points per charged fight, damage counted | +75 | +199 |
| Combat | Net per 100 charger points, damage counted | +19.5 | +80.5 |
| Combat | First round won (charged fights) | 80% | 88% |
| Combat | Net points per charged fight | +93 | +200 |
| Combat | Net points per supported fight / lone fight | +204 / +76 | +0 / +267 |
| Combat | Charged fights on a top-3 enemy unit | 6 of 15 | 1 of 8 |
| Game | Points lost | 695.7 | 536.0 |
| Game | VP from objectives | 326.7 | 1136.7 |
| Game | Lone holders (player turns) | 4.5 | 5.0 |

- Mine won / drew / lost: 1 / 0 / 2 of 3 ended games (of 3); mean margin (Mine - Opponent) -1060 VP
- The side that went first won 1 of 3 games with a winner
- Points traded per game (both sides' losses): 1232
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: cora-bb45c30-p33

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| AFTERMATH IN POINTS | - | - | - | - | 0.7 | +67.5 | 0.0 | 0.0 |
| ARMY TABLE | 17.0 | +179.9 | 0.0 | 571.3 | 19.7 | +222.1 | 0.0 | 344.0 |
| ASSAILMENT BY POINTS | 0.3 | +1.1 | 0.0 | 61.7 | 1.3 | +3.7 | 0.0 | 0.0 |
| BACKUP TARGETS | - | - | - | - | 0.3 | +1.0 | 0.0 | 0.0 |
| BEST PRIZE | - | - | - | - | 0.3 | -113.7 | 0.0 | 0.0 |
| CANNON PLANNED TARGET | 3.7 | +17.6 | 0.0 | 0.0 | - | - | - | - |
| CAST JOB | 0.7 | +37.3 | 0.0 | 0.0 | 0.7 | +3.9 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CASTS FROM BEHIND | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | - | - | - | - | 1.3 | +66.8 | 0.0 | 0.0 |
| CHAFF PASSED | 1.3 | +0.0 | 0.0 | 0.0 | 0.3 | -6.8 | 0.0 | 0.0 |
| CHAMPION KNOWS CHALLENGE | 0.3 | -13.9 | 0.0 | 0.0 | - | - | - | - |
| CHARGE LOSSES | 17.0 | -602.1 | 0.0 | 426.3 | 14.3 | -736.0 | 0.0 | 101.3 |
| CHARGE NOT DECLARED | 0.7 | +0.0 | 44.0 | 0.0 | 0.3 | +0.0 | 0.0 | 49.0 |
| CHARGE NOW FIRST | 2.0 | +0.0 | 153.3 | 20.0 | 1.7 | +0.0 | 206.3 | 16.7 |
| CLOSES ON WHAT IT BEATS | 10.3 | +0.0 | 0.0 | 116.7 | 17.0 | +0.0 | 0.0 | 100.7 |
| COMBAT PIVOT | 0.7 | +0.0 | 0.0 | 61.7 | 0.3 | +0.0 | 0.0 | 0.0 |
| COVER ONCE | 11.7 | -623.1 | 0.0 | 165.0 | 10.0 | -969.7 | 0.0 | 150.3 |
| DENIED BY THE FIGHT | - | - | - | - | 0.3 | -2.8 | 58.7 | 0.0 |
| DEPLOY BY FIGURES | 7.3 | +4.0 | 0.0 | 0.0 | 7.7 | +7.5 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | - | - | - | - | 0.3 | -2.8 | 27.7 | 0.0 |
| EDGE GIVE GROUND | - | - | - | - | 0.3 | +5.3 | 45.0 | 65.0 |
| EXACT ROUND | 4.0 | +13.7 | 283.0 | 20.0 | 4.0 | +9.8 | 313.3 | 230.3 |
| FALL BACK GOOD ORDER | 4.0 | +0.0 | 260.0 | 20.0 | 3.3 | +36.3 | 270.3 | 130.7 |
| FALLS SHORT | 1.7 | -3.7 | 0.0 | 27.7 | 18.3 | +240.2 | 0.0 | 102.7 |
| FEATURE BUFFS | 0.7 | +13.9 | 0.0 | 0.0 | - | - | - | - |
| FIGHT TO THE END | 1.7 | +74.3 | 84.7 | 20.0 | 2.0 | +19.0 | 92.7 | 166.3 |
| FIVE ACTION | 73.7 | +5469.1 | 525.7 | 1041.0 | 90.7 | +6341.9 | 426.0 | 1331.0 |
| FLANK NOT WEIGHED | 7.7 | +0.0 | 0.0 | 0.0 | 8.3 | +0.0 | 0.0 | 215.0 |
| FOLLOW UP WEIGHED | 0.3 | +95.3 | 0.0 | 0.0 | 2.0 | +364.3 | 0.0 | 0.0 |
| FOUR ROUNDS | 6.0 | +511.0 | 525.7 | 20.0 | 5.3 | +313.9 | 367.7 | 247.0 |
| FREED FROM HIS FIGHT | 2.3 | +0.0 | 0.0 | 117.3 | 6.7 | +0.0 | 0.0 | 46.7 |
| FRIEND SHOOTS FIRST | 0.7 | -34.7 | 0.0 | 0.0 | - | - | - | - |
| GIVES UP | 1.0 | -11.4 | 18.0 | 0.0 | 0.3 | -16.0 | 0.0 | 0.0 |
| GOAL WALK | 12.7 | +927.1 | 0.0 | 240.0 | 4.7 | +400.4 | 0.0 | 0.0 |
| GUN MASK | 0.3 | -3.3 | 0.0 | 0.0 | - | - | - | - |
| HARD STAY DROPPED | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 43.3 |
| HE REFORMS ONCE FREED | 1.0 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| HELPER UNSEEN | 0.3 | +0.0 | 84.7 | 0.0 | - | - | - | - |
| HIS CHARGE BY HIS RUN | 13.7 | +0.0 | 0.0 | 398.7 | 11.7 | +0.0 | 0.0 | 101.3 |
| HIS CHARGE DENIED | 0.7 | +45.5 | 149.7 | 0.0 | 1.0 | +17.2 | 58.7 | 31.7 |
| HIS CHARGE LIST | 7.7 | +0.0 | 0.0 | 314.7 | 8.3 | +0.0 | 0.0 | 91.3 |
| HIS LEGAL MOVES | 6.0 | +0.0 | 0.0 | 0.0 | 8.0 | +0.0 | 0.0 | 46.7 |
| HIS MOVE AND SHOT | 5.7 | -47.2 | 0.0 | 90.0 | 6.3 | -51.8 | 0.0 | 0.0 |
| HIS ONE QUARTER | 3.0 | +0.0 | 0.0 | 334.0 | 4.0 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 9.7 | +0.0 | 0.0 | 47.0 | 13.3 | +0.0 | 0.0 | 46.7 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 23.7 | +154.6 | 0.0 | 565.7 | 43.3 | +1106.9 | 0.0 | 278.7 |
| HIS SHOTS BY HIS RUN | 17.3 | +102.9 | 0.0 | 549.7 | 46.0 | +714.3 | 0.0 | 254.0 |
| HIS TURN DENIED | 0.3 | +6.1 | 20.0 | 0.0 | 1.3 | +19.3 | 55.3 | 0.0 |
| HIS TURN RUN | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 11.3 | +0.0 | 0.0 | 226.7 | 18.0 | +0.0 | 0.0 | 128.0 |
| HOLDER ASSIGNMENT | 7.7 | +684.4 | 0.0 | 169.3 | 12.3 | +986.0 | 0.0 | 64.0 |
| HOLDS AMBUSHERS | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 6.0 | -265.4 | 525.7 | 20.0 | 4.7 | -179.7 | 367.7 | 215.3 |
| HUNT IN PAIRS | - | - | - | - | 0.7 | +5.1 | 0.0 | 0.0 |
| IDLE COST | 0.3 | -4.1 | 0.0 | 0.0 | 16.0 | -181.8 | 0.0 | 271.3 |
| JOINT CHARGE NOW | 1.7 | +243.7 | 234.3 | 0.0 | 1.3 | +142.5 | 0.0 | 31.7 |
| KEPT FROM ITS LAST STOP | 1.3 | +0.0 | 0.0 | 58.7 | 4.0 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 1.3 | +33.0 | 0.0 | 0.0 | 1.3 | +56.1 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 13.7 | +0.0 | 149.7 | 847.0 | 14.3 | +0.0 | 633.0 | 476.7 |
| LONE WIZARD KEPT IN | 0.3 | +7.9 | 0.0 | 0.0 | 0.3 | +7.5 | 0.0 | 0.0 |
| LONG SHOT | - | - | - | - | 0.3 | +0.3 | 20.0 | 16.7 |
| LOST AFTER ESCAPE | 2.0 | -7.5 | 214.7 | 0.0 | 2.7 | +9.6 | 128.3 | 133.7 |
| LOST CHARGE | 0.3 | -0.7 | 0.0 | 0.0 | - | - | - | - |
| LURE BY WHAT IT DRAWS | - | - | - | - | 0.7 | -49.5 | 0.0 | 0.0 |
| MANOEUVRE | 0.7 | +0.0 | 0.0 | 45.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| MARCH CHECK | 0.3 | +6.5 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 0.3 | +106.2 | 0.0 | 0.0 | - | - | - | - |
| MARCH WHEELS ONLY | 1.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 1.0 | +12.8 | 0.0 | 0.0 | 3.3 | +227.6 | 0.0 | 40.0 |
| MEETS IN TIME | 4.0 | +232.5 | 0.0 | 0.0 | 4.3 | +194.0 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 2.3 | +51.5 | 0.0 | 0.0 | 4.7 | +45.5 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 2.7 | +33.7 | 0.0 | 66.3 | 5.0 | +24.7 | 0.0 | 0.0 |
| MOVE ORDER | 1.7 | +0.0 | 120.0 | 0.0 | 3.0 | +0.0 | 0.0 | 15.0 |
| MOVE TO CHARGE COMPUTED | 8.7 | +564.0 | 0.0 | 47.0 | 12.0 | +1061.4 | 0.0 | 0.0 |
| MOVES UNITS SPELL | 0.3 | +2.4 | 0.0 | 0.0 | - | - | - | - |
| NEARER NOT NEEDED | 8.7 | +311.9 | 0.0 | 99.3 | 8.7 | +299.0 | 0.0 | 22.0 |
| NEXT CHARGE BY LIST | 7.3 | +514.8 | 0.0 | 0.0 | 7.7 | +593.7 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 5.0 | -278.8 | 370.0 | 20.0 | 4.3 | -194.9 | 347.7 | 198.7 |
| NO LATE CUT | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 0.7 | -0.6 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 5.0 | -104.2 | 0.0 | 42.0 | 5.7 | -207.5 | 20.0 | 63.7 |
| ONE CHECK AFTER THE LAST CHANGE | 0.7 | +0.0 | 0.0 | 66.3 | 0.7 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 4.3 | -88.2 | 0.0 | 0.0 | 9.3 | -185.7 | 0.0 | 106.7 |
| ONE JOINT FIGURE | - | - | - | - | 0.7 | -7.1 | 0.0 | 31.7 |
| ONE OBJECTIVE FORMULA | 4.0 | +64.7 | 0.0 | 110.7 | 5.7 | +25.1 | 0.0 | 44.0 |
| ONE PROMISE A TARGET | 1.3 | -35.9 | 0.0 | 0.0 | 1.3 | -48.2 | 0.0 | 0.0 |
| ONE ROUTE | 1.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| OPENS UP | 1.0 | +25.5 | 65.3 | 0.0 | 0.7 | +29.1 | 26.7 | 0.0 |
| OVERRUNS AWAY | 0.7 | +52.2 | 45.3 | 0.0 | 2.0 | +44.2 | 209.7 | 81.7 |
| PATHS CROSS | - | - | - | - | 0.7 | +32.7 | 0.0 | 0.0 |
| PLAN RESULT | 35.0 | +570.1 | 112.0 | 981.0 | 46.0 | +457.8 | 219.0 | 902.0 |
| PROMISE BELOW ZERO | 0.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 84.7 |
| PROMISE BY ITS OWN SUM | 9.3 | -93.4 | 0.0 | 47.0 | 13.0 | -566.2 | 0.0 | 46.7 |
| PROMISE IN STEPS | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE KNOWS THE FIGHT | 0.3 | +0.0 | 0.0 | 0.0 | 2.0 | -5.4 | 0.0 | 0.0 |
| PROMISE SHOT AWAY | - | - | - | - | 0.7 | -0.1 | 0.0 | 40.0 |
| QUARTER ODDS | 17.0 | +2234.3 | 181.0 | 476.7 | 18.7 | +2800.0 | 100.7 | 399.7 |
| REAL GROUND | 1.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | 0.3 | +8.9 | 0.0 | 0.0 | 5.7 | +782.1 | 0.0 | 58.0 |
| REDIRECT FOR A FRIEND IN REACH | 2.3 | +0.0 | 0.0 | 26.7 | 5.7 | +0.0 | 0.0 | 77.0 |
| REDIRECT WEIGHED | - | - | - | - | 0.3 | +10.9 | 0.0 | 65.0 |
| REFORMS TO MEET IT | 3.0 | -77.7 | 0.0 | 0.0 | 3.0 | -9.2 | 0.0 | 0.0 |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 84.7 |
| RESERVE FALL BACK | 1.0 | +27.7 | 0.0 | 0.0 | 1.0 | +41.2 | 0.0 | 22.0 |
| RISK BY ARC | 4.7 | +168.8 | 412.7 | 20.0 | 4.3 | -88.6 | 298.0 | 198.0 |
| RISK ON THE WAY | 0.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| ROUNDS AFTER TERROR | - | - | - | - | 2.3 | -46.2 | 193.3 | 81.7 |
| RUN DOWN | - | - | - | - | 4.0 | -36.7 | 247.7 | 215.3 |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 1.7 | -40.2 | 0.0 | 0.0 |
| SEARCH SPOT | - | - | - | - | 1.3 | +30.9 | 0.0 | 0.0 |
| SECOND LOOK | 0.3 | +20.0 | 0.0 | 0.0 | 1.0 | +65.4 | 109.3 | 16.7 |
| SELF MOVE SPELL | 2.0 | +136.5 | 0.0 | 0.0 | - | - | - | - |
| SET CREDITED ONCE | - | - | - | - | 2.7 | -40.4 | 0.0 | 74.0 |
| SET UP BY THE SET | 1.3 | +12.9 | 0.0 | 0.0 | 4.3 | +118.7 | 0.0 | 74.0 |
| SHOOTERS IN TWO RANKS | 1.0 | +2.0 | 0.0 | 0.0 | 0.3 | +1.7 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 6.0 | +0.0 | 0.0 | 26.7 | 3.0 | +0.0 | 0.0 | 44.0 |
| SHOOTS FROM THE BEST SPOT | - | - | - | - | 1.3 | +16.8 | 0.0 | 48.0 |
| SHOT OR CHARGE | 0.3 | -6.4 | 0.0 | 20.0 | 0.7 | -3.5 | 58.3 | 16.7 |
| SHOT RISK POINTS | 14.3 | -112.8 | 0.0 | 309.7 | 33.7 | -142.3 | 0.0 | 195.0 |
| SHOTS AFTER THE MOVES | 3.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 12.7 | +288.7 | 0.0 | 130.3 | 9.7 | +74.9 | 0.0 | 132.0 |
| SPELL WORTH | 1.0 | +10.1 | 20.0 | 0.0 | - | - | - | - |
| SPELLS IN THE FIGHT | 1.0 | -6.9 | 18.0 | 0.0 | - | - | - | - |
| SPOT AS THE GAME MOVES | 8.0 | +0.0 | 0.0 | 175.3 | 9.3 | +0.0 | 0.0 | 149.7 |
| STAND AND SHOOT | 0.7 | -1.0 | 42.0 | 0.0 | 1.3 | -9.5 | 140.3 | 0.0 |
| STANDS FOR A REASON | - | - | - | - | 2.3 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 19.7 | +0.0 | 0.0 | 53.3 | 18.0 | +0.0 | 58.3 | 247.0 |
| STAY WORTH | 13.0 | +38.9 | 0.0 | 103.7 | 8.3 | +36.7 | 58.3 | 106.0 |
| STRIKE BY THE ODDS | 1.3 | +6.6 | 15.0 | 0.0 | - | - | - | - |
| STUPIDITY NEXT TURN | 0.3 | +0.0 | 0.0 | 47.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 2.3 | +151.4 | 0.0 | 123.3 | 7.3 | +730.8 | 0.0 | 179.7 |
| SUPPORT NARROWED | 0.3 | +0.0 | 0.0 | 20.0 | 0.3 | +0.0 | 0.0 | 16.7 |
| SUPPORT WORKED OUT | 2.3 | +151.4 | 0.0 | 123.3 | 7.3 | +730.8 | 0.0 | 179.7 |
| THE DEARER SUM KEEPS ITS PLAN | 1.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| THE PROMISE ADDS | 0.3 | -27.1 | 0.0 | 0.0 | - | - | - | - |
| THE ROW IN ITS ORDER | 4.0 | +0.0 | 0.0 | 100.7 | 1.7 | +0.0 | 0.0 | 83.0 |
| THE ROW KEEPS ITS WAY | 1.3 | +0.0 | 0.0 | 103.7 | 4.0 | +0.0 | 0.0 | 25.0 |
| THE STEP BACK IS MADE | 1.3 | +0.0 | 0.0 | 103.7 | 2.3 | +0.0 | 0.0 | 25.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 32.7 | +0.0 | 0.0 | 487.0 | 46.0 | +0.0 | 0.0 | 542.0 |
| TIED UP BY THE SUM | 2.0 | +153.9 | 113.3 | 0.0 | 1.0 | +156.8 | 146.7 | 0.0 |
| TIME ON OUR SIDE | 25.7 | +423.5 | 0.0 | 191.7 | 6.7 | +43.7 | 0.0 | 92.0 |
| WAITS AGAIN | - | - | - | - | 1.7 | +0.0 | 0.0 | 0.0 |
| WAR ENGINE JOBS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| WEAPON BY POINTS | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| WHAT THE JOINER ADDS | - | - | - | - | 0.7 | -9.5 | 40.0 | 33.3 |
| WHO FIGHTS | - | - | - | - | 0.7 | +1.0 | 72.7 | 65.0 |
| WHO HITS BACK | 0.7 | +28.1 | 0.0 | 27.7 | 1.0 | +44.3 | 0.0 | 0.0 |
| WHOLE FIGHT | - | - | - | - | 0.3 | +3.0 | 20.0 | 16.7 |
| WHOLE FIGHT DANGER | 4.3 | -489.8 | 0.0 | 116.7 | 3.3 | -501.3 | 0.0 | 101.3 |
| WOUNDS ON THE RANKS | 0.7 | +13.6 | 0.0 | 90.0 | 4.0 | +63.8 | 0.0 | 0.0 |

### Rule changes: cora-bb45c30-p33

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| LEGAL CHARGES ONLY | 84 | 84 | 84 | 28.00 | +0 | +0.0 |
| ARMY TABLE | 110 | 110 | 69 | 23.00 | +856 | +12.4 |
| HOLDER ASSIGNMENT | 60 | 60 | 56 | 18.67 | +3920 | +70.0 |
| HIS SHOT LIST | 201 | 195 | 43 | 14.33 | +323 | +7.5 |
| OFF BEST | 32 | 32 | 32 | 10.67 | -935 | -29.2 |
| FIVE ACTION | 493 | 477 | 30 | 10.00 | +1401 | +46.7 |
| MOVE TO CHARGE COMPUTED | 62 | 56 | 29 | 9.67 | +977 | +33.7 |
| THE TABLE AGAIN | 36 | 36 | 28 | 9.33 | +0 | +0.0 |
| DEPLOY BY FIGURES | 45 | 45 | 25 | 8.33 | +242 | +9.7 |
| PROMISE BY ITS OWN SUM | 67 | 67 | 24 | 8.00 | -1979 | -82.5 |
| REDIRECT FOR A FRIEND IN REACH | 24 | 24 | 24 | 8.00 | +0 | +0.0 |
| HIS SHOTS BY HIS RUN | 190 | 183 | 23 | 7.67 | +237 | +10.3 |
| MEETS IN TIME | 25 | 25 | 19 | 6.33 | +1217 | +64.0 |
| NEXT CHARGE BY LIST | 45 | 44 | 19 | 6.33 | +881 | +46.4 |
| FOUR ROUNDS | 34 | 32 | 15 | 5.00 | +588 | +39.2 |
| GOAL WALK | 52 | 52 | 15 | 5.00 | +720 | +48.0 |
| MOVE ORDER | 14 | 14 | 14 | 4.67 | +0 | +0.0 |
| QUARTER ODDS | 107 | 103 | 13 | 4.33 | +1819 | +139.9 |
| SHOT RISK POINTS | 144 | 137 | 11 | 3.67 | +85 | +7.7 |
| JOINT CHARGE NOW | 9 | 9 | 9 | 3.00 | +1159 | +128.8 |
| CHARGE LOSSES | 94 | 90 | 8 | 2.67 | +765 | +95.6 |
| COVER ONCE | 65 | 45 | 8 | 2.67 | +75 | +9.3 |
| IDLE COST | 49 | 41 | 8 | 2.67 | +67 | +8.3 |
| LANE BY FIGURES | 8 | 8 | 8 | 2.67 | +267 | +33.4 |
| ONE PROMISE A TARGET | 8 | 8 | 8 | 2.67 | -252 | -31.5 |
| TIED UP BY THE SUM | 9 | 8 | 8 | 2.67 | +265 | +33.1 |
| FOLLOW UP WEIGHED | 7 | 7 | 7 | 2.33 | +1379 | +197.0 |
| SUPPORT ADDS | 29 | 26 | 7 | 2.33 | +177 | +25.3 |
| SUPPORT WORKED OUT | 29 | 26 | 7 | 2.33 | +177 | +25.3 |
| RESERVE FALL BACK | 6 | 6 | 6 | 2.00 | +207 | +34.5 |
| RISK BY ARC | 27 | 25 | 6 | 2.00 | +200 | +33.3 |
| ADVANCE LANE KEPT | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| ASSAILMENT BY POINTS | 5 | 5 | 5 | 1.67 | +15 | +2.9 |
| CHAFF PASSED | 5 | 5 | 5 | 1.67 | -20 | -4.1 |
| TIME ON OUR SIDE | 97 | 77 | 5 | 1.67 | +24 | +4.8 |
| WHO HITS BACK | 5 | 5 | 5 | 1.67 | +126 | +25.3 |
| CASTS FROM BEHIND | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| MAX FOR POSITIONING | 13 | 12 | 4 | 1.33 | +5 | +1.2 |
| REDIRECT COUNTER | 18 | 16 | 4 | 1.33 | +219 | +54.9 |
| SEARCH SPOT | 4 | 4 | 4 | 1.33 | +93 | +23.2 |
| SECOND LOOK | 4 | 4 | 4 | 1.33 | +256 | +64.1 |
| SHOOTERS IN TWO RANKS | 4 | 4 | 4 | 1.33 | +11 | +2.8 |
| STRIKE BY THE ODDS | 4 | 4 | 4 | 1.33 | +20 | +5.0 |
| CHAFF IN THE MOVE | 4 | 4 | 3 | 1.00 | +0 | +0.0 |
| CHARGE NOT DECLARED | 3 | 3 | 3 | 1.00 | -885 | -295.0 |
| COMBAT PIVOT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| EXACT ROUND | 24 | 22 | 3 | 1.00 | +22 | +7.5 |
| FIGHT TO THE END | 11 | 10 | 3 | 1.00 | +174 | +58.1 |
| HARD STAY DROPPED | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| HOLDS AMBUSHERS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| OVERRUNS AWAY | 8 | 7 | 3 | 1.00 | +68 | +22.8 |
| AFTERMATH IN POINTS | 2 | 2 | 2 | 0.67 | +202 | +101.2 |
| CAST JOB | 4 | 4 | 2 | 0.67 | +66 | +33.2 |
| CHARGE NOW FIRST | 11 | 11 | 2 | 0.67 | -144 | -72.2 |
| LONE WIZARD KEPT IN | 2 | 2 | 2 | 0.67 | +46 | +23.1 |
| MISSILES IN THE MOVE | 21 | 16 | 2 | 0.67 | +50 | +25.0 |
| ONE OBJECTIVE FORMULA | 29 | 19 | 2 | 0.67 | +265 | +132.3 |
| PATHS CROSS | 2 | 2 | 2 | 0.67 | +98 | +49.0 |
| PROMISE SHOT AWAY | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| SHOOTS FROM THE BEST SPOT | 4 | 4 | 2 | 0.67 | +16 | +8.1 |
| SHOTS AFTER THE MOVES | 14 | 14 | 2 | 0.67 | +0 | +0.0 |
| WHOLE FIGHT DANGER | 23 | 23 | 2 | 0.67 | +76 | +38.0 |
| BEST PRIZE | 1 | 1 | 1 | 0.33 | -341 | -341.0 |
| CANNON PLANNED TARGET | 11 | 11 | 1 | 0.33 | +0 | +0.0 |
| FALLS SHORT | 60 | 49 | 1 | 0.33 | +0 | +0.0 |
| MARCH CHECK | 1 | 1 | 1 | 0.33 | +18 | +17.6 |
| MOVES UNITS SPELL | 1 | 1 | 1 | 0.33 | +7 | +7.3 |
| ONE FIGHT FORMULA | 41 | 18 | 1 | 0.33 | +0 | +0.0 |
| OPENS UP | 5 | 5 | 1 | 0.33 | +7 | +7.2 |
| PROMISE KNOWS THE FIGHT | 7 | 5 | 1 | 0.33 | -16 | -16.1 |
| REDIRECT WEIGHED | 1 | 1 | 1 | 0.33 | +130 | +130.2 |
| SET UP BY THE SET | 17 | 15 | 1 | 0.33 | +20 | +20.0 |
| SHOTS IN THE MOVE | 67 | 46 | 1 | 0.33 | +17 | +16.7 |
| STAY WORTH | 64 | 50 | 1 | 0.33 | +4 | +4.2 |
| SUPPORT NARROWED | 2 | 2 | 1 | 0.33 | -144 | -143.9 |
| THE ROW IN ITS ORDER | 17 | 1 | 1 | 0.33 | +0 | +0.0 |
| WEAPON BY POINTS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| BACKUP TARGETS | 1 | not checked | - | - | - | - |
| CASTS AFTER FRIENDS | 4 | trace | - | - | - | - |
| CHAMPION KNOWS CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 82 | 81 | 0 | 0.00 | - | - |
| DENIED BY THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 1 | 1 | 0 | 0.00 | - | - |
| EDGE GIVE GROUND | 1 | 1 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 22 | 20 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 2 | 2 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 48 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 27 | 26 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 2 | 2 | 0 | 0.00 | - | - |
| GIVES UP | 4 | 3 | 0 | 0.00 | - | - |
| GUN MASK | 1 | 1 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 8 | 8 | 0 | 0.00 | - | - |
| HELPER UNSEEN | 1 | 1 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 76 | 72 | 0 | 0.00 | - | - |
| HIS CHARGE DENIED | 5 | 5 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 48 | 48 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 42 | 37 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 36 | 34 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 21 | 20 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 69 | 63 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 5 | 5 | 0 | 0.00 | - | - |
| HIS TURN RUN | 18 | 18 | 0 | 0.00 | - | - |
| HOLD ODDS | 88 | 88 | 0 | 0.00 | - | - |
| HONEST WORTH | 32 | 30 | 0 | 0.00 | - | - |
| HUNT IN PAIRS | 2 | 1 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 16 | 16 | 0 | 0.00 | - | - |
| LONG SHOT | 1 | not checked | - | - | - | - |
| LOST AFTER ESCAPE | 14 | 14 | 0 | 0.00 | - | - |
| LOST CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 2 | 2 | 0 | 0.00 | - | - |
| MANOEUVRE | 3 | 3 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 1 | 1 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 5 | 5 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 23 | 18 | 0 | 0.00 | - | - |
| NEARER NOT NEEDED | 52 | 49 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 28 | 27 | 0 | 0.00 | - | - |
| NO LATE CUT | 3 | 3 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 2 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 4 | not checked | - | - | - | - |
| ONE JOINT FIGURE | 2 | 2 | 0 | 0.00 | - | - |
| ONE ROUTE | 5 | 5 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 18 | 18 | 0 | 0.00 | - | - |
| PLAN RESULT | 243 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 4 | 4 | 0 | 0.00 | - | - |
| PROMISE IN STEPS | 2 | 2 | 0 | 0.00 | - | - |
| REAL GROUND | 5 | 5 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 18 | 16 | 0 | 0.00 | - | - |
| REFUSING RETIRES | 2 | 2 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 6 | 6 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 7 | 6 | 0 | 0.00 | - | - |
| RUN DOWN | 12 | 11 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 5 | 5 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 6 | not checked | - | - | - | - |
| SET CREDITED ONCE | 8 | 6 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 27 | not checked | - | - | - | - |
| SHOT OR CHARGE | 3 | 3 | 0 | 0.00 | - | - |
| SPELL WORTH | 3 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 3 | 3 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 52 | 42 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 6 | 6 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 7 | 7 | 0 | 0.00 | - | - |
| STANDS STILL | 113 | 108 | 0 | 0.00 | - | - |
| STUPIDITY NEXT TURN | 6 | 5 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 7 | not checked | - | - | - | - |
| THE PROMISE ADDS | 1 | 1 | 0 | 0.00 | - | - |
| THE ROW KEEPS ITS WAY | 16 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 11 | not checked | - | - | - | - |
| THE TABLE BINDS | 236 | not checked | - | - | - | - |
| WAITS AGAIN | 5 | 3 | 0 | 0.00 | - | - |
| WAR ENGINE JOBS | 2 | 2 | 0 | 0.00 | - | - |
| WHAT THE JOINER ADDS | 2 | not checked | - | - | - | - |
| WHO FIGHTS | 2 | 2 | 0 | 0.00 | - | - |
| WHOLE FIGHT | 1 | not checked | - | - | - | - |
| WOUNDS ON THE RANKS | 14 | 14 | 0 | 0.00 | - | - |

### Off best figure: cora-bb45c30-p33

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 3.67 | 4.33 | 33.9 |
| PROMISE BY ITS OWN SUM | rule | 2.67 | 5.33 | 82.5 |
| ARMY TABLE | rule | 2.67 | 3.33 | 35.7 |
| ONE PROMISE A TARGET | rule | 0.67 | 1.33 | 45.1 |
| CHARGE NOT DECLARED | rule | 0.67 | 0.33 | 295.0 |
| FIGHT ORDER BAND | gate | 0.67 | 0.33 | 1.1 |
| JOINT CHARGE NOW | rule | 0.67 | 0.33 | 29.8 |
| CHARGE NOW FIRST | rule | - | 0.67 | 72.2 |
| HOLDER ASSIGNMENT | rule | - | 0.67 | 1.9 |
| RULE SWITCHED OFF | gate | - | 0.67 | 26.3 |
| AFTERMATH BAND | gate | 0.33 | - | 4.7 |
| AFTERMATH NEEDS NEXT CHARGE | gate | - | 0.33 | 59.0 |
| BEST PRIZE | rule | - | 0.33 | 341.0 |
| CHAFF PASSED | rule | - | 0.33 | 20.3 |
| NO REASON | gate | 0.33 | - | 2.3 |
| PROMISE KNOWS THE FIGHT | rule | - | 0.33 | 16.1 |
| SUPPORT NARROWED | rule | - | 0.33 | 143.9 |
| WHO HITS BACK | rule | 0.33 | - | 4.7 |

### Plans: cora-bb45c30-p33

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 4.7 | 86% | 664 | 484 | 73% |
| Mine | move | 25.7 | 94% | 1514 | 0 | 0% |
| Mine | shoot | 4.7 | 21% | 296 | 86 | 29% |
| Opponent | charge | 4.3 | 62% | 409 | 356 | 87% |
| Opponent | join | 2.7 | 100% | 110 | 0 | 0% |
| Opponent | move | 35.0 | 95% | 1835 | 0 | 0% |
| Opponent | shoot | 2.7 | 50% | 299 | 102 | 34% |
| Opponent | support | 1.3 | 100% | 5 | 0 | 0% |

### Battle groups: cora-bb45c30-p33

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 0.3 | 0% | - | - | - | - | - | - | - | - |
| Opponent | REDIRECT COUNTER | 5.7 | 24% | 50% | 50% | 0% | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: cora-bb45c30-p33

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 0% | 3.0 | 0 (1) | - | - | - | 0 (1) |
| Mine | Chaff | 2 | 0 (2) | 0 | 0 | 50 | 0% | 1.0 | - | 0 (2) | - | 0 (1) | 0 (1) |
| Mine | Character | 8 | 57 (8) | 57 | 0 | 27 | 0% | 2.4 | 44 (3) | 42 (4) | 142 (1) | 64 (5) | 47 (3) |
| Mine | Clean-up | 1 | 0 (1) | 0 | 0 | 100 | 0% | 2.0 | 0 (1) | - | - | 0 (1) | - |
| Mine | Fast Hammer | 4 | 23 (4) | 0 | 23 | 41 | 0% | 2.5 | 0 (1) | 28 (3) | - | 106 (1) | 0 (3) |
| Mine | Hammer | 4 | 2 (4) | 2 | 0 | 19 | 50% | 1.5 | 0 (3) | 9 (1) | - | 2 (4) | - |
| Mine | Shooter | 6 | 40 (6) | 0 | 40 | 89 | 0% | 1.3 | 136 (2) | 0 (3) | 0 (1) | 65 (4) | 0 (2) |
| Mine | Support | 3 | 0 (3) | 0 | 0 | 100 | 100% | - | - | - | - | - | - |
| Mine | War machine | 2 | 0 (2) | 0 | 0 | 0 | 0% | 1.0 | 0 (1) | 0 (1) | - | 0 (2) | - |
| Mine | Wizard | 1 | 0 (1) | 0 | 0 | 0 | 0% | 2.0 | 0 (1) | - | - | 0 (1) | - |
| Opponent | Chaff | 10 | 107 (10) | 10 | 97 | 30 | 40% | 2.7 | 47 (6) | 33 (3) | 652 (1) | 136 (7) | 33 (3) |
| Opponent | Character | 9 | 51 (9) | 51 | 0 | 4 | 22% | 3.1 | 0 (2) | 98 (4) | 48 (3) | 105 (3) | 28 (6) |
| Opponent | Clean-up | 3 | 7 (3) | 0 | 7 | 100 | 0% | 3.3 | 50 (1) | 0 (2) | - | 14 (2) | 0 (1) |
| Opponent | Fast Hammer | 8 | 71 (8) | 54 | 17 | 28 | 25% | 3.0 | 71 (1) | 58 (5) | 101 (2) | 46 (3) | 81 (5) |
| Opponent | Hammer | 1 | 0 (1) | 0 | 0 | 127 | 0% | 2.0 | - | 0 (1) | - | - | 0 (1) |
| Opponent | Holder | 2 | 0 (2) | 0 | 0 | 55 | 0% | 3.0 | - | 0 (1) | 0 (1) | 0 (1) | 0 (1) |
| Opponent | Support | 1 | 0 (1) | 0 | 0 | 100 | 0% | 5.0 | - | 0 (1) | - | - | 0 (1) |
| Opponent | Wizard | 5 | 0 (5) | 0 | 0 | 14 | 20% | 1.8 | 0 (3) | 0 (1) | - | 0 (2) | 0 (2) |

### Charged fights: cora-bb45c30-p33

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | High Elf Realms | 1 | 50 | 54 | 5.0 | 1.0 | 11 | 0 | +11 | 3 of 5 | 4 of 5 | - | +11 |
| Mine | Kingdom of Bretonnia | 1 | 0 | 571 | 3.0 | 1.3 | 190 | 0 | +190 | 1 of 3 | 3 of 3 | +349 | +111 |
| Mine | Lizardmen | 1 | 0 | 917 | 7.0 | 1.1 | 131 | 20 | +111 | 2 of 7 | 5 of 7 | +60 | +119 |
| **Mine** | all armies | 3 | 17 | 514 | 5.0 | 1.1 | 103 | 9 | +93 | 6 of 15 | 12 of 15 | +204 | +76 |
| Opponent | Tomb Kings of Khemri | 1 | 0 | 443 | 3.0 | 1.0 | 148 | 0 | +148 | 1 of 3 | 3 of 3 | - | +148 |
| Opponent | Vampire Counts | 2 | 0 | 579 | 2.5 | 1.4 | 232 | 0 | +232 | 0 of 5 | 4 of 5 | +0 | +386 |
| **Opponent** | all armies | 3 | 0 | 534 | 2.7 | 1.2 | 200 | 0 | +200 | 1 of 8 | 7 of 8 | +0 | +267 |

### Effective charges: cora-bb45c30-p33

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | High Elf Realms | 5 | 1 (net +0) | 0 | 2 (net +0) | 0 | 1 (net +54) | 0 | 1 | 50% (2 of 4) |
| Mine | Kingdom of Bretonnia | 3 | 0 | 0 | 0 | 0 | 1 (net +75) | 2 (net +248) | 0 | 0% (0 of 3) |
| Mine | Lizardmen | 7 | 0 | 0 | 1 (net +195) | 1 (net +195) | 3 (net +67) | 0 | 2 | 20% (1 of 5) |
| Opponent | Tomb Kings of Khemri | 3 | 0 | 0 | 1 (net +83) | 0 | 0 | 1 (net +175) | 1 | 50% (1 of 2) |
| Opponent | Vampire Counts | 5 | 1 (net +0) | 0 | 0 | 2 (net +188) | 1 (net +723) | 0 | 1 | 0% (0 of 4) |

### Charged fights, damage counted: cora-bb45c30-p33

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 1 | 432 | 380 | +0 | 0 | 288 | -288 | -66.7 |
| Mine | Effective (55-75%) | 3 | 319 | 247 | +65 | 65 | 0 | +65 | +20.4 |
| Mine | 76-89% | 1 | 405 | 195 | +195 | 195 | 0 | +195 | +48.1 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 462 | 200 | +248 | 248 | 0 | +248 | +53.7 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 5 | 411 | 66 | +66 | 70 | 0 | +70 | +17.0 |
| Mine | No odds | 3 | 346 | 242 | +61 | 108 | 47 | +61 | +17.7 |
| Mine | All fights | 15 | 387 | 185 | +93 | 104 | 29 | +75 | +19.5 |
| Opponent | Long shot (under 50%) | 1 | 95 | 275 | +0 | 0 | 0 | +0 | +0.0 |
| Opponent | Effective (55-75%) | 1 | 70 | 83 | +83 | 83 | 23 | +60 | +85.2 |
| Opponent | 76-89% | 2 | 208 | 188 | +188 | 188 | 19 | +169 | +80.9 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 440 | 175 | +175 | 235 | 11 | +224 | +50.9 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 471 | 126 | +723 | 723 | 0 | +723 | +153.5 |
| Opponent | No odds | 2 | 240 | 122 | +122 | 122 | 0 | +122 | +50.9 |
| Opponent | All fights | 8 | 247 | 160 | +200 | 208 | 9 | +199 | +80.5 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| cora-bb45c30-p33 | move | 34 | 10 (29%) | 7 (21%) | 4 (12%) | 20 (59%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L1527, L1625 |
| Invocation of Nehek | Opponent | L1527, L1625 |
| Ring of Doom | Mine | L1527 |
